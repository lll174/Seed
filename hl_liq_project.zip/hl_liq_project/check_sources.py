#!/usr/bin/env python3
"""
check_sources.py -- Rundum-Funktionstest aller Datenquellen.

Ruft jede Börse mit GENAU den Anfragen auf, die das Projekt benutzt (Anfragetypen,
Parameter, Symbolnamen wie im Code), langsam (Pausen zwischen den Aufrufen, keine
Ratenlimit-Kollision), und prüft je Antwort drei Dinge: Kommt sie an (HTTP, Latenz)?
Hat sie die Form, die der Code erwartet? Enthält der erste Datensatz die FELDER, die der
Code liest? Bei Streams: verbindet er, und kommen binnen der Wartezeit Nachrichten?

Anlass (14.09.2026): Der Binance-Liquidations-Stream lief 13 Tage mit null Nachrichten,
weil Binance die WebSocket-URLs umgestellt hatte -- Handshake ok, Daten nie. "Dienst
läuft" ist keine Aussage über Daten. Dieses Skript stellt die Frage je Aufruf einzeln.

    python3 check_sources.py [--db PFAD] [--coins BTC ETH ...] [--ws-sekunden 20] [--pause 0.8]
                             [--nur hl,binance,coinbase,bybit,okx,cdc,etf]

Läuft nur lesend. Hyperliquid-Gewicht dieser Probe: unter 150 (von 1.200 je Minute).
Dauer etwa 2-4 Minuten. Exit 1, wenn eine Quelle FEHL meldet.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HL_API = "https://api.hyperliquid.xyz/info"
HL_WS = "wss://api.hyperliquid.xyz/ws"
HL_LEADERBOARD = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard"
BNC_F = "https://fapi.binance.com"
BNC_S = "https://api.binance.com"
BNC_WS_NEU = "wss://fstream.binance.com/market/ws/!forceOrder@arr"
BNC_WS_ALT = "wss://fstream.binance.com/ws/!forceOrder@arr"
CB_REST = "https://api.exchange.coinbase.com"
CB_WS = "wss://ws-feed.exchange.coinbase.com"
BYBIT = "https://api.bybit.com/v5/market"
OKX = "https://www.okx.com/api/v5"
CDC = "https://api.crypto.com/exchange/v1/public/"
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0"}

ERGEBNIS: list = []          # (quelle, aufruf, urteil, detail)
PAUSE = 0.8


def urteil(quelle: str, aufruf: str, ok: str, detail: str) -> None:
    ERGEBNIS.append((quelle, aufruf, ok, detail))
    farbe = {"ok": "ok  ", "warn": "!   ", "fehl": "FEHL"}[ok]
    print(f"  {farbe} {aufruf:<44} {detail}", flush=True)
    time.sleep(PAUSE)


def http(url: str, data: dict | None = None, timeout: int = 20, text: bool = False):
    """(Antwort, Latenz s, Fehlertext). POST bei data, sonst GET."""
    body = json.dumps(data).encode() if data is not None else None
    hdr = dict(UA)
    if body is not None:
        hdr["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=hdr)
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        return None, time.time() - t0, f"HTTP {e.code}: {e.read()[:100]!r}"
    except Exception as e:
        return None, time.time() - t0, f"{type(e).__name__}: {e}"
    dt = time.time() - t0
    if text:
        return raw.decode("utf-8", "replace"), dt, None
    try:
        return json.loads(raw), dt, None
    except ValueError:
        return None, dt, f"kein JSON ({len(raw)} Bytes)"


def felder(rec, erwartet: list) -> str:
    """Welche der vom Code gelesenen Felder fehlen im Datensatz?"""
    if not isinstance(rec, dict):
        return "Datensatz ist kein Objekt"
    fehlt = [f for f in erwartet if f not in rec]
    return ("fehlt: " + ", ".join(fehlt)) if fehlt else "Felder vollständig"


def pruefe_liste(quelle, aufruf, data, dt, err, erwartet_felder=None, min_n=1, wo=None, hinweis=""):
    """Gemeinsames Urteil für Listen-Antworten."""
    if err:
        urteil(quelle, aufruf, "fehl", err); return None
    lst = data if wo is None else wo(data)
    if not isinstance(lst, list):
        urteil(quelle, aufruf, "fehl", f"unerwartete Form {type(lst).__name__} nach {dt:.1f} s"); return None
    if not lst:
        # Leere Liste ist bei min_n=0 ein gültiges Ergebnis (keine Orders, keine Fills) --
        # der erste Lauf auf dem Pi brach hier mit IndexError ab.
        urteil(quelle, aufruf, "ok" if min_n == 0 else "warn", f"0 Einträge nach {dt:.1f} s (Felder nicht prüfbar) {hinweis}".strip()); return lst
    if len(lst) < min_n:
        urteil(quelle, aufruf, "warn", f"nur {len(lst)} Einträge nach {dt:.1f} s {hinweis}"); return lst
    f = felder(lst[0], erwartet_felder) if erwartet_felder else ""
    urteil(quelle, aufruf, "fehl" if f.startswith("fehlt") else "ok", f"{len(lst)} Einträge in {dt:.1f} s · {f} {hinweis}".strip())
    return lst


# ---------------------------------------------------------------------------
# Hyperliquid
# ---------------------------------------------------------------------------

def test_hyperliquid(coins: list, db: str | None, ws_sek: int) -> None:
    Q = "Hyperliquid REST"
    print(f"\n{Q} ({HL_API})")
    data, dt, err = http(HL_API, {"type": "meta"})
    if err:
        urteil(Q, "meta", "fehl", err)
    else:
        namen = {u.get("name") for u in (data.get("universe") or [])}
        fehlend = [c for c in coins if c not in namen]
        urteil(Q, "meta", "ok" if not fehlend else "warn",
               f"{len(namen)} Perps in {dt:.1f} s" + (f" · nicht gelistet: {', '.join(fehlend)}" if fehlend else " · alle Coins gelistet"))
    data, dt, err = http(HL_API, {"type": "spotMeta"})
    urteil(Q, "spotMeta", "fehl" if err else "ok", err or f"{len(data.get('tokens') or [])} Token, {len(data.get('universe') or [])} Spot-Paare in {dt:.1f} s")
    data, dt, err = http(HL_API, {"type": "perpDexs"})
    urteil(Q, "perpDexs", "fehl" if err else "ok", err or f"{len([d for d in (data or []) if d])} Dexs in {dt:.1f} s")
    data, dt, err = http(HL_API, {"type": "l2Book", "coin": "BTC"})
    if err:
        urteil(Q, "l2Book BTC", "fehl", err)
    else:
        lv = data.get("levels") or []
        ok = len(lv) == 2 and lv[0] and "px" in lv[0][0] and "sz" in lv[0][0]
        urteil(Q, "l2Book BTC", "ok" if ok else "fehl", f"{len(lv[0]) if lv else 0} Bids / {len(lv[1]) if len(lv) > 1 else 0} Asks in {dt:.1f} s · Felder px, sz, n")
    # Testadresse: der größte Wal aus der Datenbank, sonst überspringen
    addr = None
    if db:
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            r = con.execute("SELECT addr FROM addresses WHERE pos_value > 0 ORDER BY pos_value DESC LIMIT 1").fetchone()
            addr = r[0] if r else None
            con.close()
        except sqlite3.Error as e:
            print(f"     (Datenbank nicht lesbar: {e})")
    if not addr:
        urteil(Q, "clearinghouseState / Orders / Fills", "warn", "keine Testadresse (ohne --db oder addresses leer) -- Kontoabfragen übersprungen")
    else:
        kurz = addr[:8] + "…"
        data, dt, err = http(HL_API, {"type": "clearinghouseState", "user": addr})
        if err:
            urteil(Q, f"clearinghouseState {kurz}", "fehl", err)
        else:
            aps = data.get("assetPositions") or []
            p = (aps[0].get("position") if aps else {}) or {}
            f = felder(p, ["coin", "szi", "liquidationPx", "positionValue", "leverage", "entryPx", "unrealizedPnl"]) if aps else "keine Position (Felder nicht prüfbar)"
            urteil(Q, f"clearinghouseState {kurz}", "fehl" if f.startswith("fehlt") else "ok", f"{len(aps)} Positionen in {dt:.1f} s · {f} · Gewicht 2")
        data, dt, err = http(HL_API, {"type": "spotClearinghouseState", "user": addr})
        urteil(Q, f"spotClearinghouseState {kurz}", "fehl" if err else "ok", err or f"{len(data.get('balances') or [])} Bestände in {dt:.1f} s · Felder coin, total, hold, entryNtl · Gewicht 2")
        data, dt, err = http(HL_API, {"type": "frontendOpenOrders", "user": addr})
        pruefe_liste(Q, f"frontendOpenOrders {kurz}", data, dt, err, ["coin", "side", "limitPx", "sz", "isTrigger", "triggerPx", "orderType"], min_n=0, hinweis="· Gewicht 20")
        data, dt, err = http(HL_API, {"type": "userFillsByTime", "user": addr, "startTime": (int(time.time()) - 86400) * 1000})
        lst = pruefe_liste(Q, f"userFillsByTime {kurz} (24 h)", data, dt, err, ["coin", "px", "sz", "side", "time", "dir", "closedPnl", "fee", "tid"], min_n=0, hinweis="· Gewicht 20 + 1/20")
        if lst:
            t = int(lst[0].get("time", 0))
            urteil(Q, "  Zeitstempel-Einheit der Fills", "ok" if t > 1e11 else "fehl", f"time = {t} ({'Millisekunden, wie erwartet' if t > 1e11 else 'SEKUNDEN -- Code teilt durch 1000, das wäre falsch'})")
    # Leaderboard (eigener Host, keine Gewichtseinheiten)
    data, dt, err = http(HL_LEADERBOARD, timeout=60)
    if err:
        urteil("Hyperliquid Leaderboard", "stats-data leaderboard", "fehl", err)
    else:
        rows = data.get("leaderboardRows") if isinstance(data, dict) else data
        r0 = (rows or [{}])[0]
        wp = {w: v for w, v in (r0.get("windowPerformances") or [])}
        f = felder(r0, ["ethAddress", "accountValue", "windowPerformances"])
        fenster = sorted(wp.keys())
        vlm = "vlm" in (wp.get("month") or {})
        urteil("Hyperliquid Leaderboard", "stats-data leaderboard", "fehl" if f.startswith("fehlt") or not vlm else "ok",
               f"{len(rows or []):,} Zeilen in {dt:.1f} s · {f} · Fenster {fenster} · vlm {'vorhanden' if vlm else 'FEHLT (Edge je Umsatz unmöglich)'}")
    # WebSocket
    test_hl_ws(ws_sek)


def test_hl_ws(ws_sek: int) -> None:
    Q = "Hyperliquid WS"
    print(f"\n{Q} ({HL_WS}), {ws_sek} s")
    try:
        import aiohttp
    except ImportError as e:
        urteil(Q, "aiohttp", "fehl", f"{e} -- Recorder kann nicht laufen"); return

    async def lauf():
        n = {"trades": 0, "l2Book": 0, "activeAssetCtx": 0}; probe = {}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.ws_connect(HL_WS, heartbeat=20, timeout=aiohttp.ClientWSTimeout(ws_close=15.0) if hasattr(aiohttp, "ClientWSTimeout") else 15) as ws:
                    for ch in n:
                        await ws.send_json({"method": "subscribe", "subscription": {"type": ch, "coin": "BTC"}})
                    t_ende = time.time() + ws_sek
                    while time.time() < t_ende:
                        try:
                            msg = await asyncio.wait_for(ws.receive(), timeout=max(0.5, t_ende - time.time()))
                        except asyncio.TimeoutError:
                            break
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            continue
                        d = json.loads(msg.data); ch = d.get("channel"); dat = d.get("data")
                        if ch in n:
                            n[ch] += 1
                            if ch == "trades" and isinstance(dat, list) and dat and ch not in probe:
                                probe[ch] = felder(dat[0], ["coin", "side", "px", "sz", "time", "users"])
                            if ch == "l2Book" and isinstance(dat, dict) and ch not in probe:
                                probe[ch] = felder(dat, ["coin", "levels", "time"])
                            if ch == "activeAssetCtx" and isinstance(dat, dict) and ch not in probe:
                                probe[ch] = felder(dat.get("ctx") or {}, ["funding", "openInterest", "markPx", "oraclePx", "midPx"])
        except Exception as e:
            urteil(Q, "Verbindung", "fehl", f"{type(e).__name__}: {e}"); return
        for ch, k in n.items():
            urteil(Q, f"subscribe {ch} BTC", "ok" if k else "warn", f"{k} Nachrichten in {ws_sek} s · {probe.get(ch, 'noch kein Datensatz zur Feldprüfung')}")
    asyncio.run(lauf())


# ---------------------------------------------------------------------------
# Binance
# ---------------------------------------------------------------------------

def test_binance(coins: list, ws_sek: int) -> None:
    Q = "Binance Futures REST"
    print(f"\n{Q} ({BNC_F})")
    data, dt, err = http(f"{BNC_F}/fapi/v1/ping")
    urteil(Q, "ping", "fehl" if err else "ok", err or f"{dt:.2f} s")
    data, dt, err = http(f"{BNC_F}/fapi/v1/exchangeInfo")
    syms = {}
    if err:
        urteil(Q, "exchangeInfo", "fehl", err)
    else:
        for s_ in data.get("symbols") or []:
            if s_.get("contractType") == "PERPETUAL" and s_.get("quoteAsset") == "USDT" and s_.get("status") == "TRADING":
                syms[s_["baseAsset"]] = s_["symbol"]
        fehl = [c for c in coins if c not in syms]
        urteil(Q, "exchangeInfo", "ok", f"{len(syms)} USDT-Perps in {dt:.1f} s · gelistet: {', '.join(c for c in coins if c in syms)}"
               + (f" · nicht gelistet: {', '.join(fehl)}" if fehl else ""))
    sym = syms.get("BTC", "BTCUSDT")
    for iv, lim in (("1m", 120), ("15m", 100), ("1d", 30)):
        data, dt, err = http(f"{BNC_F}/fapi/v1/klines?symbol={sym}&interval={iv}&limit={lim}")
        if err or not isinstance(data, list) or not data:
            urteil(Q, f"klines {sym} {iv}", "fehl", err or "leer"); continue
        alter = (time.time() * 1000 - int(data[-1][0])) / 60000
        urteil(Q, f"klines {sym} {iv}", "ok", f"{len(data)} Kerzen in {dt:.1f} s · jüngste vor {alter:.0f} min · Zeit in ms (Code teilt durch 1000)")
    data, dt, err = http(f"{BNC_S}/api/v3/klines?symbol={sym}&interval=1d&limit=5")
    urteil("Binance Spot REST", f"klines {sym} 1d (Spot, api.binance.com)", "fehl" if err else "ok", err or f"{len(data)} Tageskerzen in {dt:.1f} s")
    data, dt, err = http(f"{BNC_F}/fapi/v1/depth?symbol={sym}&limit=500")
    urteil(Q, f"depth {sym} 500", "fehl" if err else "ok", err or f"{len(data.get('bids') or [])} Bids / {len(data.get('asks') or [])} Asks in {dt:.1f} s")
    data, dt, err = http(f"{BNC_F}/fapi/v1/premiumIndex?symbol={sym}")
    urteil(Q, f"premiumIndex {sym}", "fehl" if err else ("fehl" if felder(data, ["lastFundingRate", "markPrice"]).startswith("fehlt") else "ok"),
           err or f"Funding {data.get('lastFundingRate')} · {felder(data, ['lastFundingRate', 'markPrice', 'indexPrice'])} in {dt:.1f} s")
    data, dt, err = http(f"{BNC_F}/fapi/v1/openInterest?symbol={sym}")
    urteil(Q, f"openInterest {sym}", "fehl" if err else "ok", err or f"OI {data.get('openInterest')} · {felder(data, ['openInterest', 'time'])} in {dt:.1f} s")
    for pfad, feld in (("/futures/data/openInterestHist", "sumOpenInterestValue"), ("/futures/data/takerlongshortRatio", "buySellRatio"),
                       ("/futures/data/globalLongShortAccountRatio", "longShortRatio"), ("/futures/data/topLongShortPositionRatio", "longShortRatio"),
                       ("/futures/data/topLongShortAccountRatio", "longShortRatio")):
        data, dt, err = http(f"{BNC_F}{pfad}?symbol={sym}&period=5m&limit=3")
        pruefe_liste(Q, f"{pfad.split('/')[-1]} {sym} 5m", data, dt, err, [feld, "timestamp"], hinweis="")
    # Streams: neue URL (seit 23.04.2026 die einzige mit Daten) und alte URL zum Vergleich
    test_ws_zaehlen("Binance WS", f"/market/ws/!forceOrder@arr (NEU)", BNC_WS_NEU, ws_sek, ["e", "E", "o"], lambda d: d.get("o") or {}, ["s", "S", "ap", "l", "q", "T"])
    test_ws_zaehlen("Binance WS", f"/ws/!forceOrder@arr (ALT, seit 23.04.2026 ohne Daten)", BNC_WS_ALT, min(ws_sek, 10), None, None, None, erwarte_stille=True)


def test_ws_zaehlen(Q: str, name: str, url: str, sek: int, top_felder, unter, unter_felder, erwarte_stille: bool = False) -> None:
    try:
        import websockets
    except ImportError as e:
        urteil(Q, name, "fehl", f"websockets fehlt: {e}"); return

    async def lauf():
        n = 0; probe = None
        try:
            async with websockets.connect(url, ping_interval=20, open_timeout=15) as ws:
                t_ende = time.time() + sek
                while time.time() < t_ende:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=max(0.5, t_ende - time.time()))
                    except asyncio.TimeoutError:
                        break
                    n += 1
                    if probe is None and top_felder:
                        d = json.loads(msg); probe = felder(d, top_felder)
                        if unter is not None:
                            probe += " · o: " + felder(unter(d), unter_felder)
        except Exception as e:
            urteil(Q, name, "fehl", f"{type(e).__name__}: {e}"); return
        if erwarte_stille:
            urteil(Q, name, "ok" if n == 0 else "warn", f"{n} Nachrichten in {sek} s ({'wie erwartet: alte URL liefert nichts mehr' if n == 0 else 'liefert doch -- Doku prüfen'})")
        else:
            urteil(Q, name, "ok" if n else "warn", f"{n} Nachrichten in {sek} s" + (f" · {probe}" if probe else " · keine Nachricht zur Feldprüfung (ruhige Minute? länger warten: --ws-sekunden 60)"))
    asyncio.run(lauf())


# ---------------------------------------------------------------------------
# Coinbase, Bybit, OKX, Crypto.com, ETF
# ---------------------------------------------------------------------------

def test_coinbase(coins: list, ws_sek: int) -> None:
    Q = "Coinbase REST"
    print(f"\n{Q} ({CB_REST})")
    data, dt, err = http(f"{CB_REST}/products")
    if err:
        urteil(Q, "products", "fehl", err); return
    ids = {p.get("id") for p in data if isinstance(p, dict) and p.get("status") == "online"}
    gel = [c for c in coins if f"{c}-USD" in ids]; fehl = [c for c in coins if f"{c}-USD" not in ids]
    urteil(Q, "products", "ok", f"{len(ids)} Paare in {dt:.1f} s · gelistet: {', '.join(gel)}" + (f" · nicht gelistet: {', '.join(fehl)}" if fehl else ""))
    pid = "BTC-USD"
    data, dt, err = http(f"{CB_REST}/products/{pid}/stats")
    urteil(Q, f"{pid}/stats", "fehl" if err else "ok", err or f"{felder(data, ['volume', 'last'])} in {dt:.1f} s")
    data, dt, err = http(f"{CB_REST}/products/{pid}/book?level=2")
    urteil(Q, f"{pid}/book?level=2", "fehl" if err else "ok", err or f"{len(data.get('bids') or [])} Bids / {len(data.get('asks') or [])} Asks in {dt:.1f} s")
    data, dt, err = http(f"{CB_REST}/products/{pid}/candles?granularity=60")
    urteil(Q, f"{pid}/candles?granularity=60", "fehl" if err else "ok", err or f"{len(data)} Minutenkerzen in {dt:.1f} s · Zeit in Sekunden")
    try:
        import aiohttp
    except ImportError as e:
        urteil("Coinbase WS", "aiohttp", "fehl", str(e)); return

    async def lauf():
        n = 0; probe = None; maker_hinweis = ""
        try:
            async with aiohttp.ClientSession() as s:
                async with s.ws_connect(CB_WS, heartbeat=20, timeout=aiohttp.ClientWSTimeout(ws_close=15.0) if hasattr(aiohttp, "ClientWSTimeout") else 15) as ws:
                    await ws.send_json({"type": "subscribe", "product_ids": [pid], "channels": ["ticker"]})
                    t_ende = time.time() + ws_sek
                    while time.time() < t_ende:
                        try:
                            msg = await asyncio.wait_for(ws.receive(), timeout=max(0.5, t_ende - time.time()))
                        except asyncio.TimeoutError:
                            break
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            continue
                        d = json.loads(msg.data)
                        if d.get("type") == "ticker":
                            n += 1
                            if probe is None:
                                probe = felder(d, ["price", "last_size", "side", "time", "product_id"])
                                maker_hinweis = " · side = MAKER-Seite (Code invertiert zum Taker)"
        except Exception as e:
            urteil("Coinbase WS", "ticker BTC-USD", "fehl", f"{type(e).__name__}: {e}"); return
        urteil("Coinbase WS", f"ticker {pid}", "ok" if n else "warn", f"{n} Ticks in {ws_sek} s · {probe or 'kein Tick'}{maker_hinweis}")
    asyncio.run(lauf())


def test_bybit(coins: list, ws_sek: int = 20) -> None:
    Q = "Bybit REST"
    print(f"\n{Q} ({BYBIT})")
    for c in coins:
        sym = f"{c}USDT"
        data, dt, err = http(f"{BYBIT}/tickers?category=linear&symbol={sym}")
        lst = ((data or {}).get("result") or {}).get("list") if not err else None
        if err or not lst:
            urteil(Q, f"tickers {sym}", "warn" if not err else "fehl", err or f"nicht gelistet (retCode {(data or {}).get('retCode')}, {(data or {}).get('retMsg')})"); continue
        urteil(Q, f"tickers {sym}", "ok", f"{felder(lst[0], ['lastPrice', 'openInterest', 'openInterestValue', 'fundingRate', 'turnover24h'])} in {dt:.1f} s")
    sym = "BTCUSDT"
    data, dt, err = http(f"{BYBIT}/recent-trade?category=linear&symbol={sym}&limit=500")
    pruefe_liste(Q, f"recent-trade {sym} 500", data, dt, err, ["side", "size", "time"], wo=lambda d: ((d.get("result") or {}).get("list")))
    data, dt, err = http(f"{BYBIT}/account-ratio?category=linear&symbol={sym}&period=5min&limit=1")
    pruefe_liste(Q, f"account-ratio {sym} 5min", data, dt, err, ["buyRatio", "sellRatio"], wo=lambda d: ((d.get("result") or {}).get("list")))
    # Liquidations-Stream (hl_ext): S = Seite der liquidierten Position, Buy = Long
    try:
        import websockets
    except ImportError as e:
        urteil("Bybit WS", "allLiquidation", "fehl", f"websockets fehlt: {e}"); return

    async def lauf():
        n = 0; probe = None
        try:
            async with websockets.connect("wss://stream.bybit.com/v5/public/linear", ping_interval=None, open_timeout=15) as ws:
                for c in coins:
                    await ws.send(json.dumps({"op": "subscribe", "args": [f"allLiquidation.{c}USDT"]})); await asyncio.sleep(0.2)
                t_ende = time.time() + ws_sek; letzter_ping = time.time()
                while time.time() < t_ende:
                    if time.time() - letzter_ping > 15:
                        await ws.send(json.dumps({"op": "ping"})); letzter_ping = time.time()
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=max(0.5, t_ende - time.time()))
                    except asyncio.TimeoutError:
                        break
                    d = json.loads(raw)
                    if d.get("success") is False:
                        probe = f"Abonnement abgelehnt: {str(d)[:100]}"
                    if str(d.get("topic", "")).startswith("allLiquidation."):
                        n += 1
                        if probe is None:
                            x = (d.get("data") or [{}])[0] if isinstance(d.get("data"), list) else d.get("data") or {}
                            probe = felder(x, ["T", "s", "S", "v", "p"])
        except Exception as e:
            urteil("Bybit WS", "allLiquidation (6 Themen)", "fehl", f"{type(e).__name__}: {e}"); return
        urteil("Bybit WS", "allLiquidation (6 Themen)", "ok" if n else "warn", f"{n} Nachrichten in {ws_sek} s · {probe or 'keine Nachricht (ruhige Minute?)'}")
    asyncio.run(lauf())


def test_okx(coins: list) -> None:
    Q = "OKX REST"
    print(f"\n{Q} ({OKX})")
    for c in coins:
        inst = f"{c}-USDT-SWAP"
        data, dt, err = http(f"{OKX}/market/ticker?instId={inst}")
        lst = (data or {}).get("data") if not err else None
        if err or not lst:
            urteil(Q, f"market/ticker {inst}", "warn" if not err else "fehl", err or f"nicht gelistet (code {(data or {}).get('code')}, {(data or {}).get('msg')})"); continue
        urteil(Q, f"market/ticker {inst}", "ok", f"{felder(lst[0], ['last', 'vol24h', 'volCcy24h'])} in {dt:.1f} s")
    inst = "BTC-USDT-SWAP"
    for pfad, feldliste, wo in (
            (f"/public/funding-rate?instId={inst}", ["fundingRate", "nextFundingTime"], None),
            (f"/public/open-interest?instType=SWAP&instId={inst}", ["oi", "oiCcy"], None),
            (f"/public/instruments?instType=SWAP&instId={inst}", ["ctVal", "ctMult"], None),
            ("/rubik/stat/contracts/long-short-account-ratio?ccy=BTC&period=5m", None, None),
            ("/rubik/stat/taker-volume?ccy=BTC&instType=CONTRACTS&period=5m", None, None),
            (f"/public/liquidation-orders?instType=SWAP&uly=BTC-USDT&state=filled&limit=100", ["details"], None)):
        data, dt, err = http(f"{OKX}{pfad}")
        if err:
            urteil(Q, pfad.split("?")[0], "fehl", err); continue
        lst = data.get("data") or []
        if feldliste is None:                       # rubik: Listen von Listen [ts, wert, ...]
            ok = bool(lst) and isinstance(lst[0], list) and len(lst[0]) >= 2
            urteil(Q, pfad.split("?")[0], "ok" if ok else "fehl", f"{len(lst)} Zeilen in {dt:.1f} s · Form [ts, wert, …] {'ok' if ok else 'unerwartet: ' + str(lst[:1])[:80]}")
        else:
            pruefe_liste(Q, pfad.split("?")[0], lst, dt, None, feldliste)


def test_cdc(coins: list) -> None:
    Q = "Crypto.com REST"
    print(f"\n{Q} ({CDC})")
    for c in coins:
        inst = f"{c}USD-PERP"
        data, dt, err = http(f"{CDC}get-tickers?instrument_name={inst}")
        lst = ((data or {}).get("result") or {}).get("data") if not err else None
        if err and "40004" in err:                     # Crypto.com meldet "Invalid instrument_name" per HTTP 400: nicht gelistet
            urteil(Q, f"get-tickers {inst}", "warn", "nicht gelistet (HTTP 400, code 40004 -- der Code führt den Coin als ungelistet)"); continue
        if err or not lst:
            urteil(Q, f"get-tickers {inst}", "warn" if not err else "fehl", err or f"nicht gelistet (code {(data or {}).get('code')})"); continue
        urteil(Q, f"get-tickers {inst}", "ok", f"{felder(lst[0], ['a', 'oi', 'vv', 'h', 'l'])} in {dt:.1f} s")
    inst = "BTCUSD-PERP"
    for meth, params, feldliste in (("get-candlestick", {"instrument_name": inst, "timeframe": "H1"}, ["t", "o", "c", "v"]),
                                    ("get-trades", {"instrument_name": inst, "count": 150}, ["s", "q", "p", "t"]),
                                    ("get-valuations", {"instrument_name": inst, "valuation_type": "mark_price", "count": 1}, ["v", "t"]),
                                    ("get-book", {"instrument_name": inst, "depth": 50}, ["bids", "asks"])):
        data, dt, err = http(f"{CDC}{meth}?{urllib.parse.urlencode(params)}")
        lst = ((data or {}).get("result") or {}).get("data") if not err else None
        pruefe_liste(Q, f"{meth} {inst}", lst, dt, err, feldliste)


def test_etf() -> None:
    Q = "ETF-Flüsse"
    print(f"\n{Q} (farside.co.uk)")
    html, dt, err = http("https://farside.co.uk/btc/", timeout=25, text=True)
    if err:
        urteil(Q, "farside.co.uk/btc/", "fehl", err); return
    tab = "<table" in html.lower(); zahl = "Total" in html or "total" in html
    urteil(Q, "farside.co.uk/btc/", "ok" if tab else "warn", f"{len(html) / 1024:.0f} kB in {dt:.1f} s · Tabelle {'gefunden' if tab else 'NICHT gefunden -- Seitenaufbau geändert?'}")


# ---------------------------------------------------------------------------

def main() -> None:
    global PAUSE
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", help="hl_liq.db (für eine echte Testadresse bei den Kontoabfragen)")
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"])
    p.add_argument("--ws-sekunden", type=int, default=20)
    p.add_argument("--pause", type=float, default=0.8, help="Pause zwischen REST-Aufrufen (s)")
    p.add_argument("--nur", help="Komma-Liste: hl,binance,coinbase,bybit,okx,cdc,etf")
    a = p.parse_args()
    PAUSE = a.pause
    nur = set(a.nur.split(",")) if a.nur else None
    print(f"Rundum-Funktionstest aller Quellen · {time.strftime('%d.%m.%Y %H:%M:%S')} · Coins {' '.join(a.coins)} · Streams je {a.ws_sekunden} s")
    t0 = time.time()
    for key, fn in (("hl", lambda: test_hyperliquid(a.coins, a.db, a.ws_sekunden)), ("binance", lambda: test_binance(a.coins, a.ws_sekunden)),
                    ("coinbase", lambda: test_coinbase(a.coins, a.ws_sekunden)), ("bybit", lambda: test_bybit(a.coins, a.ws_sekunden)),
                    ("okx", lambda: test_okx(a.coins)), ("cdc", lambda: test_cdc(a.coins)), ("etf", test_etf)):
        if nur and key not in nur:
            continue
        try:
            fn()
        except Exception as e:                         # eine kaputte Quelle darf die übrigen nicht verhindern
            urteil(key, "Testlauf", "fehl", f"Abbruch: {type(e).__name__}: {e}")
    print(f"\nZusammenfassung ({time.time() - t0:.0f} s)")
    je = {}
    for q, _, u, _ in ERGEBNIS:
        je.setdefault(q, {"ok": 0, "warn": 0, "fehl": 0})[u] += 1
    for q, z in je.items():
        print(f"  {q:<24} ok {z['ok']:>2} · Hinweise {z['warn']:>2} · FEHL {z['fehl']:>2}")
    fehl = [(q, a_, d) for q, a_, u, d in ERGEBNIS if u == "fehl"]
    if fehl:
        print("\nFEHL im Einzelnen:")
        for q, a_, d in fehl:
            print(f"  {q} · {a_}: {d[:140]}")
    print("\nLesart: 'Hinweise' sind nicht gelistete Coins oder ruhige Streams -- normal. FEHL heißt: der Code liest etwas,")
    print("das nicht (mehr) kommt -- Endpunkt, Feld oder Form. Dann zuerst die Dokumentation der Börse prüfen (Umstellung?).")
    sys.exit(1 if fehl else 0)


if __name__ == "__main__":
    main()
