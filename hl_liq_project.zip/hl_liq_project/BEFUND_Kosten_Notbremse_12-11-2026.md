# BEFUND 12.11.2026 — Kosten des Labors gegen die Messung der Börse; Notbremse lief ohne XMR

Grundlage: zwei Läufe des Nutzers vom 11.11.2026, 23:34 Ortszeit, auf Paket 23.96 (eine Stunde nach dem Einspielen):
**Debug 13** (★ TradeLabor) und **Debug 14** (★ Notbremse). Stand danach: Paket **2026-09-23.97 · 1ae18181ae**
(gebaut 12.11. 00:30). Einzelheiten und Prüfungen: UEBERGABE Abschnitt 3φφφφφ im Paket.

**Nachtrag vom 17.11.2026 in Abschnitt 8** (Debug 14 nach dem Einspielen: XMR zählt wieder; die fehlenden Kurse wurden aber
nicht nachgetragen — Fehler in 23.97, behoben mit Paket 23.109, U266).

Regel des Nutzers (11.11. 22:48): **immer die Debugnummer nennen.** 13 = ★ TradeLabor, 14 = ★ Notbremse,
117 = Logdatei der Notbremse, 114 = Logdatei des Recorders.

## 1. Kurzfassung

- **Notbremse:** lief seit ihrem Start am 23.10. ohne XMR. Im Korb stand ein fest eingetragener Dex-Name („felix“), den es an
  der Börse nicht gibt. Mit 23.97 behoben; Regeln und Schwellen unverändert.
- **Kosten:** Die Börse liefert jetzt je Minute ihren eigenen Ausführungspreis (Impact-Preis). Erste Messung: Das Kostenmodell
  des Labors setzt den Abstand zur Buchmitte bei XMR rund zwölfmal so hoch an wie die Börse. Am Modell ist nichts geändert;
  erst eine Woche messen (**Debug 13 am Mi 18.11.**), dann entscheiden.
- Einen Vorteil hat weiterhin keine Strategie: Vor Kosten liegt das Labor bei −16.615 USD.

## 2. Kosten (Debug 13)

Abstand zur Buchmitte je Seite in bps, Median (90-%-Wert), gleiche Minute, gleiche Ordergröße (Impact-Größe der Börse);
53 Proben je Coin aus 53 aufeinanderfolgenden Minuten; die Börse lieferte das Feld in 318 von 318 Minuten:

| Coin | Größe USD | Börse | Modell des Labors | Modell ÷ Börse | Proben mit 150-bps-Pauschale |
|---|---|---|---|---|---|
| BTC | 20.000 | 0,1 (0,2) | 0,1 (0,2) | ×2,21 | 0 % |
| ETH | 20.000 | 0,2 (0,3) | 0,3 (0,3) | ×1,12 | 0 % |
| ZEC | 6.000 | 0,5 (1,3) | 1,5 (2,6) | ×2,94 | 4 % |
| HYPE | 6.000 | 0,3 (1,2) | 1,2 (2,5) | ×3,57 | 6 % |
| XMR | 6.000 | 4,0 (5,0) | 49,3 (79,6) | ×12,29 | 92 % |

Bilanz je Coin über alle Strategien (USD):

| Coin | Trades | Netto | Gebühren | Abstand | ohne Kosten |
|---|---|---|---|---|---|
| BTC | 3.299 | −27.678 | 23.881 | 1.182 | −2.616 |
| ETH | 3.531 | −25.593 | 23.143 | 1.296 | −1.154 |
| ZEC | 4.664 | −25.599 | 22.882 | 4.598 | +1.880 |
| HYPE | 4.328 | −71.504 | 22.767 | 34.298 | −14.439 |
| XMR | 3.642 | −157.577 | 25.172 | 132.119 | −286 |
| Summe | 19.464 | −307.951 | 117.844 | 173.492 | −16.615 |

XMR: 19 % der Trades, 51 % des Nettoverlusts, 76 % des Abstands. Ohne XMR: 15.822 Trades, −150.374 USD.
Beispiel aus demselben Bericht: Short XMR am 11.11. 23:12 mit 61,1 bps Abstand zur Mitte gebucht.

**Lesart.** Der Recorder sieht nur die obersten 10 Preisstufen des Buchs. Reicht deren Tiefe für die Order nicht, rechnet
das Labor den Rest pauschal mit 150 bps. Bei XMR trifft das 92 % der Proben, während die Börse für dieselbe Order 4 bps meldet.

**Überschlag, kein Ergebnis.** Teilt man den gebuchten Abstand je Coin durch das gemessene Verhältnis, bleiben rund
23.600 statt 173.492 USD Abstand. Das Labor läge dann bei rund −158.000 statt −307.951 USD, XMR bei rund −36.000 statt
−157.577 USD. Die Rangfolge der Strategien würde sich ändern (die Familie Orderfluss, t −22,2, ist zum großen Teil
XMR-Abstand), das Vorzeichen nicht.

**Vorbehalte.**
- Eine Stunde an einem Abend; aufeinanderfolgende Minuten sind keine unabhängigen Proben.
- Verglichen wird bei 6.000 bzw. 20.000 USD; das Labor handelt 10.000 USD je Trade.
- Die Impact-Größe für fremd betriebene Märkte wie XMR ist nicht eigens dokumentiert (die Börse nennt 6.000 USDC für alle
  Märkte außer BTC und ETH).

**Nichts geht verloren:** Die Impact-Preise liegen seit dem 11.11. 22:41 je Minute in `impact_bars`; jede Zweitrechnung lässt
sich rückwirkend ab dann anstellen.

## 3. Notbremse (Debug 14)

- Hinweis „ohne Live-Kurs: XMR seit 11.11. 22:41 (54 Takte)“, also in jedem Takt seit dem Start des Dienstes. Je Takt ein
  HTTP-Fehler, Gewicht 26 statt 6 je Minute. Das Krypto-Maß rechnete mit 8 von 10 Instrumenten: XMR fehlte wegen des Fehlers,
  kPEPE planmäßig (erst seit dem 10.11. im Korb, noch zu wenige Kursschlüsse).
- **Ursache:** Der Dienst suchte den Handelsplatz eines eigenen Coins höchstens einmal und trug danach in jedem Fall fest
  „felix“ ein; der Name wurde täglich übernommen und nie wieder geprüft. Felix führt an der Börse das Kürzel „flx“, sein
  XMR-Markt ist delistet; ein XMR-Markt läuft bei HyENA („hyna:XMR“).
- Die Eichungen vom 23.10. und 01.11. rechneten das Krypto-Maß mit allen fünf eigenen Coins, also mit XMR; im Betrieb fehlte
  XMR. Wie stark das einzelne Auslösungen verschoben hat, ist nicht gemessen.
- **23.97 (U250):** Der Recorder legt bei jedem Start ab, an welchem Markt er jeden Coin führt; die Notbremse nimmt
  denselben Markt. Fehlt die Angabe, wartet sie bis zu 10 Minuten und sucht dann selbst, ohne delistete Märkte. Fehlende
  15-min-Schlüsse (35 Tage) und Minutenkurse (300 Minuten) trägt sie aus den Minutenkerzen des Recorders nach. Ein vorläufiger
  Korb wird alle 10 Minuten neu bestimmt statt erst am nächsten Tag.
- Unverändert offen: 13 Episoden in 30 Tagen bei einem Budget von 4; θ1 an der Klammer. Welt A seit 23.10.: mit Notbremse
  −182.171 USD, ohne −186.816 USD, Unterschied +4.646 USD.

## 4. Nach dem Einspielen von 23.97 prüfen

1. **Debug 14**, zwei Minuten nach dem Einspielen. Erwartet: kein Hinweis „ohne Live-Kurs: XMR“; Zeile
   `Dex: {'XMR': '…'} (Quelle: {'XMR': 'Recorder'}; Symbol: {'XMR': '…:XMR'})`; „G Krypto … (n 9)“; `http_fehler` 0;
   Gewicht der letzten 60 s 6. **Berichtigt am 17.11. (Abschnitt 8):** Die Zeile `Dex` bleibt leer, weil XMR auf dem Pi am
   Hauptmarkt läuft; das ist richtig so.
2. Nur wenn das nicht passt: **Debug 117** (Zeilen „Handelsplatz XMR -> …“ und „Kurse nachgetragen …“).
3. **Debug 13 am Mi 18.11.**: Abschnitt „Abstand zur Buchmitte: Modell des Labors gegen die Messung der Börse“ mit einer
   Woche Proben.

## 5. Entscheidung nach dem 18.11. (dem Nutzer in Klartext zum Anklicken vorlegen)

Hält das Verhältnis über die Woche: Soll neben der bisherigen Bilanz des Labors eine zweite mit den gemessenen Kosten der
Börse stehen? Vorschlag: ja, als Zweitrechnung; Regeln und bisherige Bilanz bleiben, damit laufende Auswertungen gültig
bleiben. Danach gebündelte Orderbücher für die genaue Rechnung bei 10.000 USD. Im Plan als U252.

## 6. Geprüft und nicht geprüft

- Geprüft (Sandbox): Selbsttest der Notbremse 42 von 42, darunter der Stand des Pi nachgebaut (alter Korb, Schlüsse bis
  23.10.); Recorder 4 von 4; ganzer Takt alt gegen neu (Gewicht 26 → 6, XMR zählt ab dem ersten Takt in allen Fenstern);
  20 Mutationen rot; Gesamt-Selbsttest 91 von 91; Update-Probe 19 von 19, auch am gelieferten Zip.
- Nicht geprüft: der Lauf gegen die echte Börse. Welchen Markt der Recorder für XMR auf dem Pi führt, zeigt erst Debug 14
  nach dem Einspielen; die Notbremse übernimmt ihn, gleich wie er heißt.
- **Lücke der Prüfung (erkannt am 17.11., Abschnitt 8):** Der nachgebaute Stand des Pi führte XMR an einem HIP-3-Markt
  („hyna“). Den Fall „XMR am Hauptmarkt“ gab es in keiner Probe; genau dort startete das Nachtragen nicht.

## 7. Für das nächste Paket

- Ein Satz in `KONZEPT_Notbremse.md` (Abschnitt 12) des Pakets 23.97 war ungenau: „mit 8 statt 10 Instrumenten“ las sich,
  als fehlten beide wegen des Fehlers. **Berichtigt mit Paket 23.98** (XMR fehlte wegen des Fehlers, kPEPE planmäßig).
- Dieser Befund liegt seit Paket 23.98 auch im Paket (auf dem Pi ab dem Update danach, weil ein `update.py` neue `.md`-Dateien
  erst kennt, wenn es selbst eingespielt ist).
- U251: Auch die Suche des Recorders überspringt delistete Märkte nicht. Heute ohne Wirkung (er hat einen lebenden XMR-Markt).
- **U266 (17.11., erledigt mit 23.109):** fehlende Kursschlüsse der eigenen Coins unabhängig vom Handelsplatz ergänzen (Abschnitt 8).

## 8. Nachtrag 17.11.2026 — Debug 14 nach dem Einspielen; die Kurse wurden nicht nachgetragen (U266, behoben mit 23.109)

Grundlage: **Debug 14** des Nutzers vom 17.11.2026, 09:53 Ortszeit (Stand 08:53 UTC; auf dem Pi lief 23.105), verglichen mit
Debug 14 vom 11.11. 23:34.

**Erfüllt.** „Ohne Live-Kurs: keines“; 785 Takte, `http_fehler` 0, Gewicht der letzten 60 s 6; „G Krypto … (n 10)“ in allen
vier Fenstern. XMR zählt wieder. Korb: BTC, ETH, HYPE, ZEC, XMR, SOL, NEAR, LIT, XRP, VVV.

**Anders als in Abschnitt 4 angekündigt.** Die Zeile lautet `Dex: {} (Quelle: {}; Symbol: {})`. Nach `korb_bestimmen` steht
ein eigener Coin nur dann ohne Eintrag im Korb, wenn ihn der Hauptmarkt der Börse als nicht delistet führt. XMR läuft auf
dem Pi also am Hauptmarkt, nicht an einem HIP-3-Markt. Die alte Zeile `dex.setdefault("XMR", … "felix")` galt ohne
Bedingung, also auch in diesem Fall; daher der Ausfall vom 23.10. bis 11.11. Die Erwartung in Abschnitt 4 war falsch, das
Verhalten ist richtig.

**Fehler in 23.97 (Fehler des Modells, nicht des Nutzers).** `kurse_nachtragen` startet nur, wenn ein Coin einen neuen
HIP-3-Handelsplatz bekommt (`neu = [c for c in dex …]`). Läuft der Coin am Hauptmarkt, startet es nie. Beleg aus den beiden
Berichten:

| | 11.11. 22:15 UTC | 17.11. 08:30 UTC | neu |
|---|---|---|---|
| BTC, 15-min-Schlüsse | 6.913 | 7.434 | 521 |
| XMR, 15-min-Schlüsse | 4.945 (bis 23.10. 07:00 UTC) | 5.461 | 516 |

XMR hat seit dem 11.11. nur die laufenden Schlüsse dazubekommen. Die rund 1.890 Schlüsse vom 23.10. 07:00 bis 11.11. 23:30
UTC fehlten weiter (19,7 Tage). Die Historie vom 23.10. führt XMR als abgerufen (`15m:XMR 0`) und fragt deshalb nicht noch
einmal.

**Wirkung.** σ von XMR stützte sich auf rund 990 statt 2.880 Schlüsse (zwei Stücke von je rund fünf Tagen). Gemessen ist die
Wirkung nicht. Nach der Bauart ist sie klein: Eine Rendite zählt nur, wenn der Schluss 15 Minuten davor vorliegt (eine Lücke
erzeugt keine falsche Rendite); σ kommt aus dem MAD; das Maß ist der Median über die Instrumente des Korbs; je Gruppe gilt
eine Untergrenze. **Die monatliche Eichung** rechnet Y aus den Minutenkerzen des Recorders, X aber aus `nb_kerze15`: Ohne
Ergänzung hätte XMR in der Eichung vom 01.12. für den 01. bis 11.11. im Krypto-Teil von X gefehlt. (In einer ersten Fassung
dieses Nachtrags stand, die Eichung sei nicht betroffen -- das galt nur für Y.)

**Korrektur (U266, Paket 23.109).** `Dienst.schluesse_ergaenzen`: für jeden eigenen Coin im Korb mit bekanntem Handelsplatz
die fehlenden 15-min-Schlüsse der letzten 35 Tage aus den Minutenkerzen des Recorders -- nur Fehlendes, ohne Netz, bis zum
letzten vollen Intervall; einmal nach dem Start des Dienstes und bei jedem Tageswechsel nach der Bestimmung des Korbs. Kam
etwas dazu, wird σ des Tages neu gerechnet. Debug 14 nennt es in der Zeile „Schlüsse der eigenen Coins … ergänzt“. Probe mit
dem Stand des Pi (XMR am Hauptmarkt, Lücke 23.10.–11.11.): 1.838 von 1.889 Schlüssen ergänzt, 51 ohne Kerze des Recorders.
Erwartet auf dem Pi: XMR mit rund 7.300 Schlüssen.

**Weiter offen, mit neuen Zahlen.**
- 19 Episoden in 30 Tagen (davon 4 der Stufe 2) bei einem Budget von 4 / 1 / 1; am 11.11. waren es 13. θ1 und θ2Y stehen
  an der Klammer. Regel 11.2 des Konzepts: kein Nachstellen innerhalb der Runde.
- Welt A seit 23.10. 09:17: mit Notbremse −264.103 USD, ohne −279.283 USD, Unterschied +15.180 USD (12.11.: +4.646).
  Davon +14.663 USD in den zehn Tagen 08.–17.11.; bis 07.11. waren es +517 USD. Größte Einzelwerte: Termin 03./04.11.
  −11.240 USD, 05.11. +6.932, 14.11. +6.471, 29.10. +6.065 USD.
- Urteil zur Ebene A frühestens nach 90 Tagen, also ab 21.01.2027.

## 9. Nachtrag 19.11.2026 — Messung nach einer Woche, Entscheidung, zweite Bilanz (U252, Paket 23.112)

Grundlage: **Debug 13** aus der Wochenprüfung vom 18.11.2026 19:20 (auf dem Pi lief 23.109), 581 Proben je Coin aus sieben Tagen.

| Coin | Größe USD | Börse Median | Börse 90 % | Modell Median | Modell 90 % | Modell ÷ Börse | mit Pauschale |
|---|---:|---:|---:|---:|---:|---:|---:|
| BTC | 20.000 | 0,08 | 0,65 | 0,16 | 0,33 | ×2,05 | 0 % |
| ETH | 20.000 | 0,28 | 0,86 | 0,30 | 0,32 | ×1,07 | 0 % |
| ZEC | 6.000 | 0,52 | 1,2 | 1,3 | 2,9 | ×2,41 | 7 % |
| HYPE | 6.000 | 0,38 | 1,1 | 1,0 | 2,9 | ×2,74 | 9 % |
| XMR | 6.000 | 3,4 | 5,1 | 4,8 | 49,2 | ×1,42 | 45 % |

Abstand je Seite in bps. Das Verhältnis der ersten Stunde (XMR ×12,3 am 11.11.) hat sich im Median nicht gehalten (×1,42); der
Unterschied sitzt bei XMR im teuren Teil der Verteilung: In 45 % der Proben reicht die erfasste Tiefe der obersten zehn Buchstufen
nicht für 6.000 USD, den Rest rechnet das Modell mit 150 bps. Das Labor rechnet je Trade (beide Seiten) im Mittel: XMR 37 bps,
HYPE 7,9, ZEC 1,9, BTC 0,43, ETH 0,37. Bei BTC und ETH rechnet das Modell im teuren Zehntel eher zu wenig (0,33 gegen 0,65 bps).

Labor am 18.11.: 23.559 Trades, netto −388.624 USD; Gebühren −137.534, Abstand −221.084 (XMR −165.904), Funding −1.616;
ohne Gebühren und Abstand −30.006 USD. **Überschlag aus den Messwerten, keine Bilanz:** Abstand 43.000 (Median) bis 83.000 USD
(90-%-Wert) statt 221.084 -- das Labor stünde bei etwa −211.000 bis −251.000 USD. Kein Vorsprung auch ohne Kosten.

**Entscheidung des Nutzers am 19.11.2026 (zum Anklicken): „Zweite Bilanz daneben“.** Gebaut mit 23.112: Abschnitt „Zweite Bilanz mit
den Abständen der Börse“ in Debug 13 (UEBERGABE 3μμμμμμ). Sie rechnet jeden Trade, der ganz im Messzeitraum liegt, mit dem
Impact-Preis der Minute seiner Ausführung nach und gibt zwei Werte: „niedrig“ und „hoch“, weil die Börse für 20.000 bzw. 6.000 USD
misst und die Order des Labors eine andere Größe hat. Regeln, gebuchte Bilanz und Stufen bleiben. Offen bleibt der zweite Teil von
U252: gebündelte Orderbücher für die genaue Rechnung bei 10.000 USD und der Ersatz der Pauschale.

## Quellen (geöffnet 11./12.11.2026)

- XMR-Markt von Felix, als delistet und inaktiv geführt: https://oakresearch.io/en/hyperliquid/hip-3/markets/flx:XMR
- XMR-Markt bei HyENA: https://oakresearch.io/en/hyperliquid/hip-3/markets/hyna:XMR
- Ende von Felix ab 19.06.2026: https://www.kucoin.com/news/flash/felix-dex-to-shut-down-due-to-usdh-deactivation
- Impact-Größe 20.000 USDC (BTC, ETH) und 6.000 USDC (übrige):
  https://hyperliquid.gitbook.io/hyperliquid-docs/trading/contract-specifications
