# BEFUND 12.11.2026 — Kosten des Labors gegen die Messung der Börse; Notbremse lief ohne XMR

Grundlage: zwei Läufe des Nutzers vom 11.11.2026, 23:34 Ortszeit, auf Paket 23.96 (eine Stunde nach dem Einspielen):
**Debug 13** (★ TradeLabor) und **Debug 14** (★ Notbremse). Stand danach: Paket **2026-09-23.97 · 1ae18181ae**
(gebaut 12.11. 00:30). Einzelheiten und Prüfungen: UEBERGABE Abschnitt 3φφφφφ im Paket.

Regel des Nutzers (11.11. 22:48): **immer die Debugnummer nennen.** 13 = ★ TradeLabor, 14 = ★ Notbremse,
117 = Logdatei der Notbremse, 114 = Logdatei des Recorders.

## 1. Kurzfassung

- **Notbremse:** lief seit ihrem Start am 23.10. ohne XMR. Im Korb stand ein fest eingetragener Dex-Name („felix“), den es an
  der Börse nicht gibt. Mit 23.97 behoben; Regeln und Schwellen unverändert.
- **Kosten:** Die Börse liefert jetzt je Minute ihren eigenen Ausführungspreis (Impact-Preis). Erste Messung: Das Kostenmodell
  des Labors setzt den Abstand zur Buchmitte bei XMR rund zwölfmal so hoch an wie die Börse. Am Modell ist nichts geändert;
  erst eine Woche messen (**Debug 13 am Mi 18.11.**), dann entscheiden.
- Einen Vorteil hat weiterhin keine Strategie: Vor Kosten liegt das Labor bei −16.615 USD.

## 2. Kosten (Debug 13)

Abstand zur Buchmitte je Seite in bps, Median (90-%-Wert), gleiche Minute, gleiche Ordergröße (Impact-Größe der Börse);
53 Proben je Coin aus 53 aufeinanderfolgenden Minuten; die Börse lieferte das Feld in 318 von 318 Minuten:

| Coin | Größe USD | Börse | Modell des Labors | Modell ÷ Börse | Proben mit 150-bps-Pauschale |
|---|---|---|---|---|---|
| BTC | 20.000 | 0,1 (0,2) | 0,1 (0,2) | ×2,21 | 0 % |
| ETH | 20.000 | 0,2 (0,3) | 0,3 (0,3) | ×1,12 | 0 % |
| ZEC | 6.000 | 0,5 (1,3) | 1,5 (2,6) | ×2,94 | 4 % |
| HYPE | 6.000 | 0,3 (1,2) | 1,2 (2,5) | ×3,57 | 6 % |
| XMR | 6.000 | 4,0 (5,0) | 49,3 (79,6) | ×12,29 | 92 % |

Bilanz je Coin über alle Strategien (USD):

| Coin | Trades | Netto | Gebühren | Abstand | ohne Kosten |
|---|---|---|---|---|---|
| BTC | 3.299 | −27.678 | 23.881 | 1.182 | −2.616 |
| ETH | 3.531 | −25.593 | 23.143 | 1.296 | −1.154 |
| ZEC | 4.664 | −25.599 | 22.882 | 4.598 | +1.880 |
| HYPE | 4.328 | −71.504 | 22.767 | 34.298 | −14.439 |
| XMR | 3.642 | −157.577 | 25.172 | 132.119 | −286 |
| Summe | 19.464 | −307.951 | 117.844 | 173.492 | −16.615 |

XMR: 19 % der Trades, 51 % des Nettoverlusts, 76 % des Abstands. Ohne XMR: 15.822 Trades, −150.374 USD.
Beispiel aus demselben Bericht: Short XMR am 11.11. 23:12 mit 61,1 bps Abstand zur Mitte gebucht.

**Lesart.** Der Recorder sieht nur die obersten 10 Preisstufen des Buchs. Reicht deren Tiefe für die Order nicht, rechnet
das Labor den Rest pauschal mit 150 bps. Bei XMR trifft das 92 % der Proben, während die Börse für dieselbe Order 4 bps meldet.

**Überschlag, kein Ergebnis.** Teilt man den gebuchten Abstand je Coin durch das gemessene Verhältnis, bleiben rund
23.600 statt 173.492 USD Abstand. Das Labor läge dann bei rund −158.000 statt −307.951 USD, XMR bei rund −36.000 statt
−157.577 USD. Die Rangfolge der Strategien würde sich ändern (die Familie Orderfluss, t −22,2, ist zum großen Teil
XMR-Abstand), das Vorzeichen nicht.

**Vorbehalte.**
- Eine Stunde an einem Abend; aufeinanderfolgende Minuten sind keine unabhängigen Proben.
- Verglichen wird bei 6.000 bzw. 20.000 USD; das Labor handelt 10.000 USD je Trade.
- Die Impact-Größe für fremd betriebene Märkte wie XMR ist nicht eigens dokumentiert (die Börse nennt 6.000 USDC für alle
  Märkte außer BTC und ETH).

**Nichts geht verloren:** Die Impact-Preise liegen seit dem 11.11. 22:41 je Minute in `impact_bars`; jede Zweitrechnung lässt
sich rückwirkend ab dann anstellen.

## 3. Notbremse (Debug 14)

- Hinweis „ohne Live-Kurs: XMR seit 11.11. 22:41 (54 Takte)“, also in jedem Takt seit dem Start des Dienstes. Je Takt ein
  HTTP-Fehler, Gewicht 26 statt 6 je Minute. Das Krypto-Maß rechnete mit 8 von 10 Instrumenten: XMR fehlte wegen des Fehlers,
  kPEPE planmäßig (erst seit dem 10.11. im Korb, noch zu wenige Kursschlüsse).
- **Ursache:** Der Dienst suchte den Handelsplatz eines eigenen Coins höchstens einmal und trug danach in jedem Fall fest
  „felix“ ein; der Name wurde täglich übernommen und nie wieder geprüft. Felix führt an der Börse das Kürzel „flx“, sein
  XMR-Markt ist delistet; ein XMR-Markt läuft bei HyENA („hyna:XMR“).
- Die Eichungen vom 23.10. und 01.11. rechneten das Krypto-Maß mit allen fünf eigenen Coins, also mit XMR; im Betrieb fehlte
  XMR. Wie stark das einzelne Auslösungen verschoben hat, ist nicht gemessen.
- **23.97 (U250):** Der Recorder legt bei jedem Start ab, an welchem Markt er jeden Coin führt; die Notbremse nimmt
  denselben Markt. Fehlt die Angabe, wartet sie bis zu 10 Minuten und sucht dann selbst, ohne delistete Märkte. Fehlende
  15-min-Schlüsse (35 Tage) und Minutenkurse (300 Minuten) trägt sie aus den Minutenkerzen des Recorders nach. Ein vorläufiger
  Korb wird alle 10 Minuten neu bestimmt statt erst am nächsten Tag.
- Unverändert offen: 13 Episoden in 30 Tagen bei einem Budget von 4; θ1 an der Klammer. Welt A seit 23.10.: mit Notbremse
  −182.171 USD, ohne −186.816 USD, Unterschied +4.646 USD.

## 4. Nach dem Einspielen von 23.97 prüfen

1. **Debug 14**, zwei Minuten nach dem Einspielen. Erwartet: kein Hinweis „ohne Live-Kurs: XMR“; Zeile
   `Dex: {'XMR': '…'} (Quelle: {'XMR': 'Recorder'}; Symbol: {'XMR': '…:XMR'})`; „G Krypto … (n 9)“; `http_fehler` 0;
   Gewicht der letzten 60 s 6.
2. Nur wenn das nicht passt: **Debug 117** (Zeilen „Handelsplatz XMR -> …“ und „Kurse nachgetragen …“).
3. **Debug 13 am Mi 18.11.**: Abschnitt „Abstand zur Buchmitte: Modell des Labors gegen die Messung der Börse“ mit einer
   Woche Proben.

## 5. Entscheidung nach dem 18.11. (dem Nutzer in Klartext zum Anklicken vorlegen)

Hält das Verhältnis über die Woche: Soll neben der bisherigen Bilanz des Labors eine zweite mit den gemessenen Kosten der
Börse stehen? Vorschlag: ja, als Zweitrechnung; Regeln und bisherige Bilanz bleiben, damit laufende Auswertungen gültig
bleiben. Danach gebündelte Orderbücher für die genaue Rechnung bei 10.000 USD. Im Plan als U252.

## 6. Geprüft und nicht geprüft

- Geprüft (Sandbox): Selbsttest der Notbremse 42 von 42, darunter der Stand des Pi nachgebaut (alter Korb, Schlüsse bis
  23.10.); Recorder 4 von 4; ganzer Takt alt gegen neu (Gewicht 26 → 6, XMR zählt ab dem ersten Takt in allen Fenstern);
  20 Mutationen rot; Gesamt-Selbsttest 91 von 91; Update-Probe 19 von 19, auch am gelieferten Zip.
- Nicht geprüft: der Lauf gegen die echte Börse. Welchen Markt der Recorder für XMR auf dem Pi führt, zeigt erst Debug 14
  nach dem Einspielen; die Notbremse übernimmt ihn, gleich wie er heißt.

## 7. Für das nächste Paket

- Ein Satz in `KONZEPT_Notbremse.md` (Abschnitt 12) des Pakets 23.97 war ungenau: „mit 8 statt 10 Instrumenten“ las sich,
  als fehlten beide wegen des Fehlers. **Berichtigt mit Paket 23.98** (XMR fehlte wegen des Fehlers, kPEPE planmäßig).
- Dieser Befund liegt seit Paket 23.98 auch im Paket (auf dem Pi ab dem Update danach, weil ein `update.py` neue `.md`-Dateien
  erst kennt, wenn es selbst eingespielt ist).
- U251: Auch die Suche des Recorders überspringt delistete Märkte nicht. Heute ohne Wirkung (er hat einen lebenden XMR-Markt).

## Quellen (geöffnet 11./12.11.2026)

- XMR-Markt von Felix, als delistet und inaktiv geführt: https://oakresearch.io/en/hyperliquid/hip-3/markets/flx:XMR
- XMR-Markt bei HyENA: https://oakresearch.io/en/hyperliquid/hip-3/markets/hyna:XMR
- Ende von Felix ab 19.06.2026: https://www.kucoin.com/news/flash/felix-dex-to-shut-down-due-to-usdh-deactivation
- Impact-Größe 20.000 USDC (BTC, ETH) und 6.000 USDC (übrige):
  https://hyperliquid.gitbook.io/hyperliquid-docs/trading/contract-specifications
