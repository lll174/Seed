#!/usr/bin/env python3
"""
check_system.py -- Systemdiagnose ohne SSH (23.77): Warum war das Dashboard nicht erreichbar, was lief vor dem letzten Neustart?

  python3 check_system.py [--db hl_liq.db]     Bericht (liest nur)
  python3 check_system.py --selbsttest         Proben auf erfundenen Eingaben (ohne systemd)

Anlass: Am 23.10. war die Weboberfläche nicht erreichbar (Ping ging, Port 8765 nicht); SSH ist auf dem Pi aus, ein Bildschirm hängt nicht
dran. Nach dem Neustart über den Taster lief alles wieder -- die Ursache ist nur noch in den Protokollen zu finden. Dieses Werkzeug läuft
aus der Debug-Konsole und sammelt sie:
  Befund (kurz) · Laufzeit und Dienste · Starts im Journal · vor dem letzten Neustart: Dashboard (Abstürze, letzte Zeilen), Kernel
  (Speicher, Platte/USB, Strom, Hänger), die letzten Zeilen des vorigen Starts (sauber heruntergefahren oder abrupt) · Wächter-Log (Meldungen
  der letzten 24 h, die Prüfungen vor dem Neustart) · CPU- und Temperaturverlauf des Dashboards (Lücken: Dashboard stand oder hing) ·
  Berichte der letzten 24 h (was lief) · Speicher, Platte, Strom, Prozesse jetzt · Update- und Notbremse-Log.
Das Journal des vorigen Starts gibt es nur, wenn journald dauerhaft speichert (/var/log/journal); sonst steht das im Bericht. Lesen darf
es die Gruppe adm (Standardnutzer des Pi); sonst einmal mit sudo (Passwort aus sudo.txt wie beim Update, nur über stdin).

23.78 (U215–U217), nach dem Ausfall vom 23.10. (Dashboard hing knapp 5 h, Ursache offen):
  * Hänger-Abzüge (logs/dashboard_haenger.log: Stapel aller Fäden nach 5 min ohne Antwort und beim SIGABRT von systemd) und die Ausgabe des
    Dashboards (logs/dashboard.log, mit Zeitstempel) -- beides schreibt das Dashboard seit 23.78 selbst.
  * Lücken des Dashboards über 7 Tage aus den Prognosen (alle 15 min je Coin) und über 24 h aus dem Systemverlauf; um die längste Lücke
    (oder --fenster VON BIS): alle Wächter-Prüfungen mit Abständen (Verzögerung = Pi überlastet), Recorder-Meldungen (z. B. Backup) und die
    Lebenszeichen der Dashboard-Teile in den Datenbanken (Prognose, TradeLabor, Welt A, Ausblick, Makro, Aktien, Seite im Browser) gegen
    Recorder und Notbremse-Dienst als eigene Dienste -- stand das ganze Dashboard oder nur ein Teil?
  * --journal-dauerhaft an|aus: Systemprotokoll dauerhaft (höchstens 200 MB) -- nur auf Klick des Nutzers in der Debug-Konsole.

  python3 check_system.py --db hl_liq.db --fenster 2026-10-23T09:31 2026-10-23T14:28     Fenster von Hand
  python3 check_system.py --journal-dauerhaft an|aus                                       braucht sudo.txt
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timedelta

HIER = os.path.dirname(os.path.abspath(__file__))
DIENSTE = ("hl-dashboard", "hl-recorder", "hl-notbremse", "hl-binance", "hl-coinbase", "hl-watchdog")
# Kernel-Zeilen, die einen Ausfall erklären können -- je Art gezählt
KERN_ARTEN = (("Speicher", re.compile(r"out of memory|oom[-_ ]?kill|killed process|oom_reaper", re.I)),
              ("Platte/USB", re.compile(r"i/o error|blk_update_request|buffer i/o|ext4-fs error|usb \S+: usb disconnect|"
                                        r"reset (high|super|full)[- ]?speed usb|uas_eh|sd \S+: \[sd\w\] .*(error|fail)", re.I)),
              ("Strom", re.compile(r"under-?voltage|voltage normali[sz]ed|hwmon.*in0_lcrit", re.I)),
              ("Hänger", re.compile(r"hung_task|blocked for more than|soft lockup|hard lockup|rcu.*stall", re.I)),
              ("Temperatur", re.compile(r"thermal|temperature above|cpu clock throttled", re.I)))
WACHE_KOPF = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) — Gesamtstatus: (\S+)")
BER_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}_[a-z0-9_]+\.txt$")
SAUBER = re.compile(r"systemd-shutdown|Reached target .*(Power[- ]?Off|Reboot|Shutdown|Halt)|System is (powering down|rebooting)|"
                    r"Stopped target .*Multi-User|Journal stopped", re.I)
GEDROSSELT = {0: "Unterspannung jetzt", 1: "Takt gedeckelt jetzt", 2: "gedrosselt jetzt", 3: "Temperaturgrenze jetzt",
              16: "Unterspannung seit dem Start", 17: "Takt gedeckelt seit dem Start", 18: "gedrosselt seit dem Start",
              19: "Temperaturgrenze seit dem Start"}
# 23.78: Lebenszeichen in den Datenbanken -- (Name, Datei neben der Hauptdatenbank, Tabelle, Zeitspalte = Schreibzeit, Teil des Dashboards?)
LEBENSZEICHEN = (("Prognose (alle 15 min je Coin)", "forecasts.db", "forecast", "ts", True),
                 ("TradeLabor Welt B (Ereignisse)", "forecasts.db", "labor_ereignis", "ts", True),
                 ("Welt A (Ereignisse, seit 23.76)", "labor_a.db", "labor_ereignis", "ts", True),
                 ("Ausblick (Prognosen)", "ausblick.db", "au_prognose", "erzeugt", True),
                 ("Makro (Abrufe)", "makro.db", "mk_abruf", "ts", True),
                 ("Aktien (Abrufe)", "aktien.db", "ak_abruf", "ts", True),
                 ("Seite im Browser (Konfluenz; nur bei offener Seite)", "forecasts.db", "konfluenz_log", "ts", True),
                 ("zum Vergleich: Recorder (Kurse, eigener Dienst)", None, "bars", "ts", False),
                 ("zum Vergleich: Notbremse-Dienst (Zustand, eigener Dienst)", "notbremse.db", "nb_zustand", "ts", False))
HAENGER_KOPF = re.compile(r"^== (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (.*)$")
FH_KOPF = re.compile(r"^(Timeout \([\d:.]+\)!|Fatal Python error: .*)$")
FH_FADEN = re.compile(r"^(?:Current thread|Thread) (0x[0-9a-f]+) \(most recent call first\):")
NAMEN_FADEN = re.compile(r"^-- (.+) \(Thread (0x[0-9a-f]+)\)$")
RAHMEN = re.compile(r'^\s+File "([^"]+)", line (\d+),? in (\S+)')
LOG_ZEIT = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) ")
REC_ZEIT = re.compile(r"^\[(\d{2}):(\d{2}):(\d{2})\]")
# Abstand zweier Wächter-Prüfungen, ab dem der Pi selbst als überlastet gilt: Takt 300 s + Prüfdauer (sonst ~2 s; Dashboard hängt: bis 35 s,
# Internet weg: bis ~30 s) -- erst darüber ist es Überlast
WACHE_SPAET_S = 420
JOURNAL_DROPIN = "/etc/systemd/journald.conf.d/90-hl-dauerhaft.conf"
JOURNAL_INHALT = ("# hl_liq_project 23.78 (U217): Systemprotokoll dauerhaft -- eingeschaltet über die Debug-Konsole\n"
                  "# („System: Systemprotokoll dauerhaft speichern -- EINSCHALTEN“), dort auch wieder auszuschalten.\n"
                  "# 90-…: wird nach Voreinstellungen gelesen (etwa einer, die das Protokoll flüchtig hält) und gilt damit.\n"
                  "[Journal]\nStorage=persistent\nSystemMaxUse=200M\nSystemKeepFree=2G\n")


def w(text: str = "") -> None:
    print(text, flush=True)


def _zeit(ts, sek: bool = False) -> str:
    return datetime.fromtimestamp(int(ts)).strftime("%d.%m. %H:%M:%S" if sek else "%d.%m. %H:%M") if ts else "—"


def _dauer(s: float) -> str:
    s = int(s)
    return f"{s // 86_400} d {s % 86_400 // 3600} h" if s >= 86_400 else (f"{s // 3600} h {s % 3600 // 60} min" if s >= 3600 else f"{s // 60} min")


class Umgebung:
    """Befehle, Dateien, Zeit -- in den Proben ersetzt."""
    def __init__(self, root: str = HIER):
        self.root = root

    def sudo_pw(self) -> str | None:
        f = os.path.join(self.root, "sudo.txt")
        try:
            if os.stat(f).st_mode & 0o077:
                return None
            with open(f, errors="replace") as fh:
                return fh.read().strip() or None
        except OSError:
            return None

    def befehl(self, args, timeout: int = 30, sudo: bool = False) -> tuple:
        args = list(args)
        try:
            if sudo:
                pw = self.sudo_pw()
                if not pw:
                    return 1, "kein sudo-Passwort (sudo.txt)"
                r = subprocess.run(["sudo", "-S", "-p", ""] + args, input=pw + "\n", capture_output=True, text=True, timeout=timeout)
            else:
                r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
            return r.returncode, (r.stdout or "") + (r.stderr or "")
        except FileNotFoundError:
            return 127, f"{args[0]}: nicht vorhanden"
        except subprocess.TimeoutExpired:
            return 124, f"{args[0]}: keine Antwort in {timeout} s"
        except OSError as e:
            return 1, f"{args[0]}: {e}"

    def lesen(self, pfad: str, max_bytes: int | None = None) -> str | None:
        try:
            with open(pfad, "rb") as f:
                if max_bytes:
                    f.seek(0, 2)
                    f.seek(max(0, f.tell() - max_bytes))
                return f.read().decode("utf-8", errors="replace")
        except OSError:
            return None

    def jetzt(self) -> float:
        return time.time()

    def boot(self) -> int | None:
        t = self.lesen("/proc/stat") or ""
        m = re.search(r"^btime (\d+)", t, re.M)
        return int(m.group(1)) if m else None

    def dateien(self, ordner: str) -> list:
        try:
            return [(f, os.path.getmtime(os.path.join(ordner, f)), os.path.getsize(os.path.join(ordner, f))) for f in os.listdir(ordner)]
        except OSError:
            return []

    def schreiben(self, pfad: str, text: str) -> bool:
        try:
            os.makedirs(os.path.dirname(pfad), exist_ok=True)
            with open(pfad, "w", encoding="utf-8") as f:
                f.write(text)
            return True
        except OSError:
            return False

    def entfernen(self, pfad: str) -> None:
        try:
            os.unlink(pfad)
        except OSError:
            pass

    def da(self, pfad: str) -> bool:
        return os.path.exists(pfad)

    def db(self, pfad: str):
        """Nur lesend (mode=ro); None, wenn es die Datei nicht gibt."""
        if not os.path.exists(pfad):
            return None
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=15)
        con.execute("PRAGMA busy_timeout=15000")
        return con


# --------------------------------------------------------------------------------------------- Bausteine (in den Proben einzeln geprüft)
def journal(U: Umgebung, args) -> str:
    """journalctl ohne Seitenumbruch; sieht der Nutzer nur seine eigenen Zeilen (nicht in der Gruppe adm), einmal mit sudo."""
    rc, out = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90)
    eng = "not seeing messages from other users" in out or "insufficient permissions" in out
    if (eng or rc not in (0, 1)) and U.sudo_pw():
        rc2, out2 = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90, sudo=True)
        if rc2 == 0:
            out = out2
    return "\n".join(z for z in out.splitlines() if not z.startswith("Hint:") and "Users in groups" not in z and "pass -q to" not in z)


def starts_lesen(text: str) -> list:
    """journalctl --list-boots -> [(Index, Boot-ID, Rest)] (mit oder ohne Kopfzeile)."""
    out = []
    for z in text.splitlines():
        m = re.match(r"^\s*(-?\d+)\s+([0-9a-f]{32})\s+(.*)$", z)
        if m:
            out.append((int(m.group(1)), m.group(2), m.group(3).strip()))
    return out


def kern_zaehlen(zeilen: list) -> tuple:
    """Kernel-Zeilen je Art. -> ({Art: Anzahl}, [passende Zeilen])"""
    n = {a: 0 for a, _ in KERN_ARTEN}; treffer = []
    for z in zeilen:
        for a, rx in KERN_ARTEN:
            if rx.search(z):
                n[a] += 1; treffer.append(z)
                break
    return n, treffer


def sauber_beendet(zeilen: list) -> bool:
    """Ende des vorigen Starts: Herunterfahren im Journal (sauber) oder nicht (abrupt: Strom, Hänger, Taster lang gedrückt)."""
    return any(SAUBER.search(z) for z in zeilen)


def wache_bloecke(text: str) -> list:
    """Wächter-Log -> [(ts, Status, [Zeilen ≠ ok])]."""
    out = []
    for z in text.splitlines():
        m = WACHE_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            out.append([ts, m.group(2), []])
        elif out and (z.startswith("  !    ") or z.startswith("  XXX  ")):
            out[-1][2].append(z.strip())
    return [tuple(b) for b in out]


def verlauf_luecken(eintraege: list, jetzt: float, schwelle: int = 180) -> list:
    """CPU-/Temperaturverlauf des Dashboards (ts, temp, cpu, alle 60 s; gesichert alle 5 min) -> Lücken über `schwelle` s in den letzten 24 h
    [(von, bis, Sekunden)], die längste zuerst; eine Lücke bis jetzt zählt mit."""
    ts = sorted(int(e[0]) for e in eintraege if isinstance(e, (list, tuple)) and e and e[0] and e[0] >= jetzt - 86_400)
    luecken = [(a, b, b - a) for a, b in zip(ts, ts[1:]) if b - a > schwelle]
    if ts and jetzt - ts[-1] > schwelle:
        luecken.append((ts[-1], int(jetzt), int(jetzt) - ts[-1]))
    return sorted(luecken, key=lambda x: -x[2])


def gedrosselt(wert: str) -> list:
    """vcgencmd get_throttled (throttled=0x50005) -> Liste der gesetzten Merkmale."""
    m = re.search(r"0x([0-9a-fA-F]+)", wert or "")
    if not m:
        return ["nicht lesbar"]
    v = int(m.group(1), 16)
    return [t for b, t in GEDROSSELT.items() if v & (1 << b)]


def _unit_datei(U: Umgebung, unit: str, schluessel: str = "StandardOutput") -> str | None:
    _rc, t = U.befehl(["systemctl", "cat", unit], timeout=15)
    m = re.search(rf"^{schluessel}=(?:append:|file:|truncate:)?(\S+)", t or "", re.M)
    return m.group(1) if m else None


# --------------------------------------------------------------------------------------------- 23.78: Hänger, Lücken, Lebenszeichen
def haenger_lesen(text: str) -> list:
    """logs/dashboard_haenger.log -> Einträge {art: start|abzug|timeout|fatal, ts (None bei faulthandler), titel, faeden: [[Kennung, [(Datei,
    Zeile, Funktion), …] neueste zuerst]]}. faulthandler schreibt ohne Zeit und neueste Zeile zuerst; die Abzüge mit Namen (Faden
    „lebenszeichen“) mit Zeit und neueste Zeile zuletzt -- hier vereinheitlicht."""
    out: list = []
    akt = None
    faden = None
    for z in text.splitlines():
        m = HAENGER_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            akt = {"art": "start" if m.group(2).startswith("Dashboard-Start") else "abzug", "ts": ts, "titel": m.group(2).strip(), "faeden": []}
            out.append(akt); faden = None
            continue
        if FH_KOPF.match(z):
            akt = {"art": "timeout" if z.startswith("Timeout") else "fatal", "ts": None, "titel": z.strip(), "faeden": []}
            out.append(akt); faden = None
            continue
        if akt is None:
            continue
        m = FH_FADEN.match(z) or NAMEN_FADEN.match(z)
        if m:
            kennung = m.group(1) if m.re is FH_FADEN else f"{m.group(1)} {m.group(2)}"
            faden = [kennung, []]; akt["faeden"].append(faden)
            continue
        m = RAHMEN.match(z)
        if m and faden is not None:
            faden[1].append((m.group(1), int(m.group(2)), m.group(3)))
    for e in out:
        if e["art"] == "abzug":
            for f in e["faeden"]:
                f[1].reverse()
    return out


def _stelle(rahmen: list) -> str:
    """Wo steht ein Faden? Die neueste Stelle im Projekt (hl_*.py, check_*.py) und, falls anders, die neueste überhaupt."""
    if not rahmen:
        return "?"
    eigen = next((r for r in rahmen if re.match(r"^(hl_|check_|run_all)", os.path.basename(r[0]))), None)
    oben = rahmen[0]
    t = f"{os.path.basename(oben[0])}:{oben[1]} {oben[2]}"
    if eigen and eigen != oben:
        t = f"{os.path.basename(eigen[0])}:{eigen[1]} {eigen[2]} ← darin {t}"
    return t


def log_zeilen(text: str) -> list:
    """dashboard.log (seit 23.78 mit Zeitstempel je Zeile) -> [(ts oder None, Zeile)]."""
    out = []
    for z in text.splitlines():
        m = LOG_ZEIT.match(z)
        ts = None
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                ts = None
        out.append((ts, z))
    return out


def recorder_zeilen(text: str, jetzt: float) -> list:
    """recorder.log hat nur Uhrzeiten („[HH:MM:SS]“, Statuszeile alle 10 min). Das Datum ergibt sich rückwärts vom Ende (jetzt): ist eine
    Uhrzeit rückwärts gelesen später als die folgende, lag Mitternacht dazwischen. Zeilen ohne Zeit gehören zur Zeile davor. -> [(ts, Zeile)]"""
    zeilen = text.splitlines()
    zeiten: list = [None] * len(zeilen)
    tag = datetime.fromtimestamp(jetzt).date()
    jetzt_sek = (datetime.fromtimestamp(jetzt) - datetime.combine(tag, datetime.min.time())).seconds
    folge = None
    for i in range(len(zeilen) - 1, -1, -1):
        m = REC_ZEIT.match(zeilen[i])
        if not m:
            continue
        sek = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
        if (folge is None and sek > jetzt_sek + 300) or (folge is not None and sek > folge + 300):
            tag = tag - timedelta(days=1)
        folge = sek
        zeiten[i] = int(datetime(tag.year, tag.month, tag.day, sek // 3600, sek % 3600 // 60, sek % 60).timestamp())
    out, letzte = [], None
    for i, z in enumerate(zeilen):
        letzte = zeiten[i] if zeiten[i] is not None else letzte
        out.append((letzte, z))
    return out


def wache_bloecke_voll(text: str) -> list:
    """Wächter-Log -> [(ts, Status, [alle Prüfzeilen ohne Einrückung])] -- auch die ok-Zeilen (z. B. Backup)."""
    out = []
    for z in text.splitlines():
        m = WACHE_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            out.append([ts, m.group(2), []])
        elif out and re.match(r"^  (ok |!  |XXX)  ", z):
            out[-1][2].append(z.strip())
    return [tuple(b) for b in out]


def luecken(zeiten: list, schwelle: int, von: float, bis: float) -> list:
    """Lücken über `schwelle` s zwischen aufeinanderfolgenden Zeiten in [von, bis] (eine Lücke bis `bis` zählt mit), längste zuerst."""
    ts = sorted({int(t) for t in zeiten if t and von <= t <= bis})
    lu = [(a, b, b - a) for a, b in zip(ts, ts[1:]) if b - a > schwelle]
    if ts and bis - ts[-1] > schwelle:
        lu.append((ts[-1], int(bis), int(bis) - ts[-1]))
    return sorted(lu, key=lambda x: -x[2])


def lebenszeichen_zaehlen(con, tab: str, spalte: str, a: int, b: int, rand: int = 0, vorlauf: int = 6 * 3600) -> dict | None:
    """Einträge einer Tabelle in der Lücke (a, b): gezählt wird im KERN (a + rand, b − rand) -- die Grenzen einer Lücke sind nur so genau wie
    ihre Quelle (Prognosen alle 15 min: rand 15 min); ein Teil, der bis kurz nach a noch schrieb, zählt so nicht als „lief weiter“.
    Letzter Eintrag bis a + rand, erster ab b − rand; erwartet = Rate der `vorlauf` s vor a × Länge des Kerns.
    Urteil: lief weiter (Einträge im Kern) / stand (≥ 3 erwartet, 0 gefunden) / zu selten für ein Urteil. None: Tabelle fehlt."""
    k0, k1 = a + rand, b - rand
    try:
        q = lambda sql, *arg: con.execute(sql.format(t=tab, s=spalte), arg).fetchone()[0]   # noqa: E731
        vor = q("SELECT MAX({s}) FROM {t} WHERE {s} <= ?", k0)
        n_in = q("SELECT COUNT(*) FROM {t} WHERE {s} > ? AND {s} < ?", k0, k1)
        nach = q("SELECT MIN({s}) FROM {t} WHERE {s} >= ?", k1)
        n_vor = q("SELECT COUNT(*) FROM {t} WHERE {s} >= ? AND {s} < ?", a - vorlauf, a)
    except sqlite3.Error:
        return None
    erwartet = n_vor / vorlauf * max(0, k1 - k0)
    if n_in:
        urteil = "lief weiter"
    elif erwartet >= 3:
        urteil = "stand"
    else:
        urteil = "zu selten für ein Urteil"
    return {"vor": vor, "n_in": int(n_in or 0), "nach": nach, "n_vor": int(n_vor or 0), "erwartet": erwartet, "urteil": urteil}


def zeit_lesen(text: str) -> int:
    """'2026-10-23T09:31', '2026-10-23 09:31[:SS]' oder '23.10.2026 09:31' (Ortszeit) -> Unix-Zeit."""
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            return int(datetime.strptime(text.strip(), fmt).timestamp())
        except ValueError:
            continue
    raise ValueError(f"Zeit nicht lesbar: {text!r} (z. B. 2026-10-23T09:31)")


def _log_ordner(U: Umgebung, db: str | None) -> str | None:
    """Ordner von dashboard.log und dashboard_haenger.log: aus der Unit des Dashboards (seit 23.78), sonst neben watchdog.log, sonst logs/
    neben der Hauptdatenbank."""
    for unit in ("hl-dashboard", "hl-watchdog"):
        p = _unit_datei(U, unit)
        if p:
            return os.path.dirname(p)
    return os.path.join(os.path.dirname(os.path.abspath(db)), "logs") if db else None


def haenger_abschnitt(U: Umgebung, db: str | None, jetzt: float, befund: list) -> None:
    """Hänger-Schutz (Unit), Abzüge der letzten 7 Tage, Lebenszeichen-Meldungen und letzte Zeilen von dashboard.log."""
    w(); w("== Dashboard: Hänger-Schutz, Abzüge und eigenes Log (seit 23.78)")
    _rc, t = U.befehl(["systemctl", "show", "hl-dashboard", "-p", "WatchdogUSec", "-p", "NRestarts", "-p", "Result", "-p", "ExecMainCode",
                       "-p", "ExecMainStatus", "--no-pager"], timeout=15)
    e = dict(z.split("=", 1) for z in (t or "").splitlines() if "=" in z)
    wd = e.get("WatchdogUSec", "")
    an = bool(wd) and wd not in ("0", "infinity", "0s")
    w(f"   Selbstheilung (systemd-Wächter): {'an, ' + wd if an else 'aus (Unit vor 23.78 oder ohne systemd)'}; Neustarts seit dem Start des "
      f"Pi {e.get('NRestarts', '?')}, letztes Ergebnis {e.get('Result', '?')}")
    befund.append(f"Hänger-Schutz: {'an (' + wd + ' ohne Lebenszeichen -> Neustart)' if an else 'aus'}"
                  + (" -- LETZTER NEUSTART DURCH DEN WÄCHTER (Hänger)" if e.get("Result") == "watchdog" else ""))
    ordner = _log_ordner(U, db)
    hp = os.path.join(ordner, "dashboard_haenger.log") if ordner else None
    kand = [hp] if hp else []
    kand.append(os.path.join(U.root, "updates", "dashboard_haenger.log"))
    text, quelle = None, None
    for k in kand:
        text = U.lesen(k, 2_000_000)
        if text:
            quelle = k
            break
    if not text:
        w("   Hänger-Abzüge: keine Datei (" + ", ".join(kand) + ")")
    else:
        ein = haenger_lesen(text)
        letzte_zeit, folge = None, []
        for x in ein:                                       # faulthandler-Abzüge ohne Zeit: nach dem letzten Eintrag mit Zeit
            if x["ts"] is not None:
                letzte_zeit = x["ts"]
            x["nach"] = letzte_zeit
            folge.append(x)
        neu = [x for x in folge if (x["ts"] or x["nach"] or 0) >= jetzt - 7 * 86_400]
        starts = [x for x in neu if x["art"] == "start"]
        abz = [x for x in neu if x["art"] != "start"]
        w(f"   {quelle}: in 7 Tagen {len(starts)} Starts, {len(abz)} Abzüge "
          f"({sum(1 for x in abz if x['art'] == 'fatal')} beim Beenden, {sum(1 for x in abz if x['art'] == 'timeout')} nach 5 min ohne Antwort, "
          f"{sum(1 for x in abz if x['art'] == 'abzug')} mit Namen)")
        for x in neu[-30:]:
            if x["art"] == "start":
                w(f"   {_zeit(x['ts'], True)} {x['titel'][:90]}")
                continue
            wann = _zeit(x["ts"], True) if x["ts"] else f"nach {_zeit(x['nach'], True)}"
            erkl = {"timeout": " (faulthandler: 5 min nach der letzten eigenen Antwort)",
                    "fatal": (" (so beendet systemd nach 15 min ohne Lebenszeichen)" if "Aborted" in x["titel"] else " (Absturz)")}.get(x["art"], "")
            w(f"   {wann} {x['titel'][:110]}{erkl} -- {len(x['faeden'])} Fäden")
            for k_, r_ in x["faeden"][:12]:
                w(f"      {k_[:40]:<40} {_stelle(r_)[:150]}")
        if abz:
            befund.append(f"Hänger-Abzüge in 7 Tagen: {len(abz)} (zuletzt {_zeit(abz[-1]['ts'] or abz[-1]['nach'])}: {abz[-1]['titel'][:60]})")
    lp = os.path.join(ordner, "dashboard.log") if ordner else None
    lt = U.lesen(lp, 1_000_000) if lp else None
    if not lt:
        w(f"   Dashboard-Log: keine Datei ({lp or '—'}) -- vor 23.78 ging die Ausgabe ins Journal")
        return
    zz = log_zeilen(lt)
    leb = [(ts, z) for ts, z in zz if ts and ts >= jetzt - 7 * 86_400 and "Lebenszeichen:" in z]
    w(f"   {lp}: Meldungen „Lebenszeichen“ in 7 Tagen: {len(leb)}")
    for _ts, z in leb[-10:]:
        w("   | " + z[:220])
    w("   Letzte Zeilen:")
    for _ts, z in zz[-25:]:
        w("   | " + z[:220])


def fenster_abschnitt(U: Umgebung, db: str | None, jetzt: float, befund: list, verlauf: list | None, fenster: tuple | None) -> None:
    """Lücken des Dashboards (Prognosen 7 Tage, Systemverlauf 24 h) und um die längste (oder `fenster`): Wächter, Recorder, Lebenszeichen."""
    w(); w("== Lücken des Dashboards (Prognosen alle 15 min je Coin über 7 Tage; Systemverlauf je Minute über 24 h)")
    ordner = os.path.dirname(os.path.abspath(db)) if db else None
    kand = []
    con = U.db(os.path.join(ordner, "forecasts.db")) if ordner else None
    if con is not None:
        try:
            zeiten = [r[0] for r in con.execute("SELECT DISTINCT ts FROM forecast WHERE ts >= ?", (int(jetzt) - 7 * 86_400,))]
        except sqlite3.Error:
            zeiten = []
        finally:
            con.close()
        lp = luecken(zeiten, 45 * 60, jetzt - 7 * 86_400, jetzt)
        w(f"   Prognosen: {len(zeiten)} Zeitpunkte in 7 Tagen, Lücken über 45 min: {len(lp)}")
        for a, b, d in lp[:8]:
            w(f"   Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(d)})")
        kand += [(a, b, d, "Prognosen") for a, b, d in lp]
    else:
        w("   Prognosen: forecasts.db nicht gefunden")
    if verlauf:
        lv = verlauf_luecken(verlauf, jetzt, 15 * 60)
        kand += [(a, b, d, "Systemverlauf") for a, b, d in lv]
    if fenster:
        a, b = fenster
        quelle = "von Hand (--fenster)"
    elif kand:
        a, b, _d, quelle = max(kand, key=lambda x: x[2])
    else:
        w("   keine Lücke über 15 min -- kein Fenster")
        return
    a, b = int(a), int(b)
    rand = {"Prognosen": 900, "Systemverlauf": 300}.get(quelle, min(300, (b - a) // 10))     # so genau sind die Grenzen der Quelle
    w(); w(f"== Um die Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(b - a)}; Quelle: {quelle}): Wächter, Recorder, Lebenszeichen")
    # Wächter: Abstände der Prüfungen (Verzögerung = Pi überlastet) und die Prüfungen um Anfang und Ende
    wlog = _unit_datei(U, "hl-watchdog")
    text = U.lesen(wlog, 3_000_000) if wlog else None
    if text:
        bl = [x for x in wache_bloecke_voll(text) if a - 3600 <= x[0] <= b + 1800]
        drin = [x for x in bl if a - 600 <= x[0] <= b + 600]
        abst = [(y[0] - x[0], y[0]) for x, y in zip(drin, drin[1:])]
        spaet = [(d, t) for d, t in abst if d > WACHE_SPAET_S]
        if abst:
            ds = sorted(d for d, _t in abst)
            w(f"   Wächter: {len(drin)} Prüfungen, Abstand {ds[0] // 60}:{ds[0] % 60:02d} bis {ds[-1] // 60}:{ds[-1] % 60:02d} min (Median "
              f"{ds[len(ds) // 2] // 60}:{ds[len(ds) // 2] % 60:02d}); verzögert (über {WACHE_SPAET_S // 60} min): {len(spaet)}"
              + (" -- " + ", ".join(f"{_zeit(t)} nach {_dauer(d)}" for d, t in spaet[:6]) if spaet else ""))
            befund.append(f"Wächter in der Lücke: {len(drin)} Prüfungen, " + (f"{len(spaet)} verzögert (längster Abstand {_dauer(max(spaet)[0])} "
                                                                            f"um {_zeit(max(spaet)[1])}) -- Pi zeitweise überlastet" if spaet
                                                                            else "keine verzögert -- der Pi selbst war nicht überlastet"))
        dauernd = None
        for x in bl:
            schlecht = {z.split()[1] for z in x[2] if not z.startswith("ok")}
            dauernd = schlecht if dauernd is None else dauernd & schlecht
        dauernd = dauernd or set()
        vorige = None
        for x in bl:
            if not (a - 1800 <= x[0] <= a + 2700 or b - 900 <= x[0] <= b + 900):
                vorige = x[0]
                continue
            schlecht = [z for z in x[2] if not z.startswith("ok")]
            namen = [f"{z.split()[1]} {z.split()[0]}" for z in schlecht if z.split()[1] in dauernd]
            voll = [" ".join(z.split()) for z in schlecht if z.split()[1] not in dauernd]
            backup = [" ".join(z.split()) for z in x[2] if len(z.split()) > 1 and z.split()[1] == "Backup"]
            d = f"+{(x[0] - vorige) // 60}:{(x[0] - vorige) % 60:02d}" if vorige else ""
            w(f"   {_zeit(x[0], True)} {x[1]:<8} {d:>6}  " + " · ".join(namen + voll + [b_ for b_ in backup if b_ not in voll])[:260])
            vorige = x[0]
        if dauernd:
            w(f"   (dauernd nicht ok im Fenster, nur mit Namen: {', '.join(sorted(dauernd))})")
    else:
        w(f"   Wächter-Log nicht gefunden ({wlog or 'Pfad nicht in der Unit'})")
    # Recorder: Meldungen um den Anfang und das Backup davor
    rlog = _unit_datei(U, "hl-recorder")
    rt = U.lesen(rlog, 3_000_000) if rlog else None
    if rt:
        rz = recorder_zeilen(rt, jetzt)
        um = [(t, z) for t, z in rz if t and a - 1800 <= t <= a + 2700]
        bk = [(t, z) for t, z in rz if t and a - 26 * 3600 <= t <= b and "Backup" in z]
        w(f"   Recorder-Log {rlog}: {len(um)} Zeilen von {_zeit(a - 1800)} bis {_zeit(a + 2700)}; Backup-Zeilen seit {_zeit(a - 26 * 3600)}: {len(bk)}")
        for t, z in bk[-6:]:
            w(f"   | {_zeit(t)} {z.strip()[:200]}")
        for t, z in um[-25:]:
            w(f"   | {z.rstrip()[:220]}")
    else:
        w(f"   Recorder-Log nicht gefunden ({rlog or 'Pfad nicht in der Unit'})")
    # Lebenszeichen in den Datenbanken
    w(f"   Lebenszeichen in den Datenbanken, gezählt im Kern der Lücke {_zeit(a + rand, True)} bis {_zeit(b - rand, True)} (je {rand // 60} min Rand: "
      "so genau sind die Grenzen der Quelle). Je Teil: letzter Eintrag davor · Einträge im Kern (erwartet aus den 6 h davor) · erster danach:")
    teile = []
    for name, datei, tab, spalte, dash in LEBENSZEICHEN:
        pfad = db if datei is None else (os.path.join(ordner, datei) if ordner else None)
        con = U.db(pfad) if pfad else None
        if con is None:
            w(f"   {name:<58} Datei fehlt ({os.path.basename(pfad) if pfad else '—'})")
            continue
        try:
            z = lebenszeichen_zaehlen(con, tab, spalte, a, b, rand)
        finally:
            con.close()
        if z is None:
            w(f"   {name:<58} Tabelle {tab} fehlt")
            continue
        teile.append((name, dash, z))
        w(f"   {name:<58} {_zeit(z['vor'], True) if z['vor'] else '—':>15} · {z['n_in']:>6} ({z['erwartet']:.0f}) · "
          f"{_zeit(z['nach'], True) if z['nach'] else '—':<15} -> {z['urteil']}")
    d_stand = [n for n, dash, z in teile if dash and z["urteil"] == "stand"]
    d_lief = [n for n, dash, z in teile if dash and z["urteil"] == "lief weiter"]
    fremd_lief = [n for n, dash, z in teile if not dash and z["urteil"] == "lief weiter"]
    vor_dash = [z["vor"] for n, dash, z in teile if dash and z["vor"]]
    nach_dash = [z["nach"] for n, dash, z in teile if dash and z["nach"]]
    if d_stand and not d_lief:
        urteil = ("Teile des Dashboards standen alle (" + ", ".join(n.split(" (")[0] for n in d_stand) + ")"
                  + ("; eigene Dienste liefen weiter -> das GANZE Dashboard stand (Prozess hing oder war weg)" if fremd_lief else ""))
    elif d_stand and d_lief:
        urteil = ("nur TEILE standen (" + ", ".join(n.split(" (")[0] for n in d_stand) + "), andere liefen weiter ("
                  + ", ".join(n.split(" (")[0] for n in d_lief) + ") -> einzelne Fäden hingen, nicht der ganze Prozess")
    elif d_lief:
        urteil = "Teile des Dashboards liefen weiter (" + ", ".join(n.split(" (")[0] for n in d_lief) + ")"
    else:
        urteil = "kein Urteil (zu wenige Einträge)"
    w(f"   -> {urteil}")
    if vor_dash:
        w(f"   Letztes Lebenszeichen eines Dashboard-Teils vor der Lücke: {_zeit(max(vor_dash), True)}; erstes danach: "
          f"{_zeit(min(nach_dash), True) if nach_dash else '—'}")
    befund.append(f"Lebenszeichen {_zeit(a)}–{_zeit(b)}: {urteil}" + (f"; letztes vor der Lücke {_zeit(max(vor_dash), True)}" if vor_dash else ""))


def journal_dauerhaft(U: Umgebung, an: bool) -> bool:
    """23.78 (U217): Systemprotokoll dauerhaft ein- oder ausschalten -- nur auf Klick des Nutzers. Jeder Schritt mit sudo (Passwort aus
    sudo.txt nur über stdin; keiner der Befehle liest stdin, auch nicht, wenn sudo kein Passwort verlangt). Ein: Einstellung 90-hl-dauerhaft.conf
    (Storage=persistent, höchstens 200 MB, 2 GB bleiben frei), Ordner /var/log/journal, journald neu, bisheriges Protokoll übernehmen.
    Aus: Einstellung und /var/log/journal entfernen, journald neu -- wie vorher."""
    w(f"SYSTEMPROTOKOLL DAUERHAFT -- {'EINSCHALTEN' if an else 'AUSSCHALTEN'} ({datetime.fromtimestamp(U.jetzt()):%d.%m.%Y %H:%M:%S})")
    _rc, t = U.befehl(["systemd-analyze", "cat-config", "systemd/journald.conf"], timeout=20)
    vorher = [z.strip() for z in (t or "").splitlines() if z.startswith("#") and z.strip().endswith(".conf") or z.startswith("Storage=")]
    w("   Bisher: " + (" · ".join(vorher[-6:]) if vorher else "keine Angabe (Voreinstellung)"))
    if not U.sudo_pw():
        w("   FEHLER: kein sudo-Passwort (sudo.txt mit Rechten 600 im Projektordner) -- nichts geändert")
        return False
    tmp = os.path.join(U.root, "updates", "journald_hl_dauerhaft.conf.tmp")
    if an:
        if not U.schreiben(tmp, JOURNAL_INHALT):
            w(f"   FEHLER: {tmp} nicht schreibbar -- nichts geändert")
            return False
        schritte = [(["install", "-D", "-m", "644", tmp, JOURNAL_DROPIN], f"Einstellung {JOURNAL_DROPIN}"),
                    (["mkdir", "-p", "/var/log/journal"], "Ordner /var/log/journal"),
                    (["systemd-tmpfiles", "--create", "--prefix", "/var/log/journal"], "Rechte des Ordners"),
                    (["systemctl", "restart", "systemd-journald"], "journald neu gestartet"),
                    (["journalctl", "--flush"], "bisheriges Protokoll übernommen")]
    else:
        schritte = [(["rm", "-f", JOURNAL_DROPIN], f"Einstellung {JOURNAL_DROPIN} entfernt"),
                    (["rm", "-rf", "--one-file-system", "/var/log/journal"], "gespeicherte Protokolle (/var/log/journal) gelöscht"),
                    (["systemctl", "restart", "systemd-journald"], "journald neu gestartet")]
    gut = True
    try:
        for args, text in schritte:
            rc, out = U.befehl(args, timeout=90, sudo=True)
            w(f"   {'ok   ' if rc == 0 else 'FEHL '} {text}" + ("" if rc == 0 else f" (rc {rc}: {(out or '').strip()[:200]})"))
            if rc != 0:
                gut = False
                break
    finally:
        if an:
            U.entfernen(tmp)
    _rc, t = U.befehl(["systemd-analyze", "cat-config", "systemd/journald.conf"], timeout=20)
    st = [z.strip() for z in (t or "").splitlines() if z.startswith("Storage=")]
    da = U.da("/var/log/journal")
    w(f"   Jetzt: zuletzt gilt {st[-1] if st else 'Storage= (Voreinstellung)'}; /var/log/journal {'vorhanden' if da else 'fehlt'}")
    ziel = (st[-1:] == ["Storage=persistent"] and da) if an else (not da and "Storage=persistent" not in st[-1:])
    if gut and not ziel:
        w("   ACHTUNG: Die Einstellung wirkt nicht wie gewollt (eine später gelesene Datei setzt Storage= anders?) -- Ausgabe oben prüfen")
    w("   Ergebnis: " + ("erledigt" if gut and ziel else "NICHT erledigt"))
    if an and gut and ziel:
        w("   Ab jetzt überlebt das Systemprotokoll Neustarts (höchstens 200 MB). „★ System: letzter Neustart und Ausfälle“ zeigt nach dem nächsten")
        w("   Neustart auch Kernel-Meldungen und die systemd-Zeilen des Dashboards von davor.")
    return gut and ziel


# --------------------------------------------------------------------------------------------- Bericht
def bericht(U: Umgebung, db: str | None = None, fenster: tuple | None = None) -> dict:
    jetzt = U.jetzt(); boot = U.boot(); befund = []
    w(f"SYSTEM: letzter Neustart und Ausfälle -- {datetime.fromtimestamp(jetzt):%d.%m.%Y %H:%M:%S} (Ortszeit des Pi)")
    w(f"   Pi gestartet {_zeit(boot, True)} (läuft seit {_dauer(jetzt - boot) if boot else '?'})")
    befund.append(f"Pi läuft seit {_zeit(boot)} ({_dauer(jetzt - boot) if boot else '?'})")

    w(); w("== Dienste jetzt")
    for u in DIENSTE:
        _rc, t = U.befehl(["systemctl", "show", u, "-p", "ActiveState", "-p", "SubState", "-p", "NRestarts", "-p", "ExecMainStartTimestamp",
                           "-p", "MemoryCurrent", "-p", "Result", "--no-pager"], timeout=15)
        e = dict(z.split("=", 1) for z in (t or "").splitlines() if "=" in z)
        mem = e.get("MemoryCurrent", "")
        w(f"   {u:<14} {e.get('ActiveState', '?')}/{e.get('SubState', '?')}, seit {e.get('ExecMainStartTimestamp') or '—'}, Neustarts "
          f"{e.get('NRestarts', '?')}, Ergebnis {e.get('Result', '?')}" + (f", Speicher {int(mem) / 2 ** 20:.0f} MB" if mem.isdigit() else ""))

    w(); w("== Starts im Journal")
    starts = starts_lesen(journal(U, ["--list-boots"]))
    for i, bid, rest in starts[-5:]:
        w(f"   {i:>3}  {rest}")
    dauerhaft = any(i < 0 for i, _b, _r in starts)
    if not starts:
        w("   keine Liste (journalctl nicht lesbar)")
    elif not dauerhaft:
        w("   Nur der jetzige Start ist gespeichert: Das Journal ist nicht dauerhaft (/var/log/journal fehlt) -- was vor dem Neustart geschah, steht "
          "nur noch im Wächter-Log, im CPU-Verlauf und in den Logdateien der Dienste (unten).")
    befund.append(f"Journal dauerhaft: {'ja' if dauerhaft else 'nein'} ({len(starts)} Starts gespeichert)" if starts
                  else "Journal: nicht lesbar (journalctl fehlt oder keine Rechte)")

    if dauerhaft:
        w(); w("== Vor dem letzten Neustart: Dashboard (Meldungen von systemd)")
        sd = journal(U, ["-b", "-1", "-u", "hl-dashboard", "-t", "systemd", "-o", "short-iso"]).splitlines()
        absturz = [z for z in sd if re.search(r"Main process exited|Failed with result|Scheduled restart job|Killed|core-dump", z)]
        for z in sd[-20:]:
            w("   " + z)
        befund.append(f"Dashboard vor dem Neustart: {len(absturz)} Zeilen zu Absturz/Neustart durch systemd"
                      + (f" (zuletzt: {absturz[-1][:120]})" if absturz else ""))
        w(); w("== Vor dem letzten Neustart: Dashboard (letzte 40 Zeilen seiner Ausgabe)")
        for z in journal(U, ["-b", "-1", "-u", "hl-dashboard", "-n", "40", "-o", "short-iso"]).splitlines():
            w("   " + z[:300])
        w(); w("== Vor dem letzten Neustart: Kernel (Speicher, Platte/USB, Strom, Hänger, Temperatur)")
        kern = journal(U, ["-b", "-1", "-k", "-o", "short-iso"]).splitlines()
        n, treffer = kern_zaehlen(kern)
        for z in treffer[-25:]:
            w("   " + z[:300])
        if not treffer:
            w("   keine solche Zeile")
        befund.append("Kernel vor dem Neustart: " + ", ".join(f"{a} {k}" for a, k in n.items()))
        w(); w("== Vor dem letzten Neustart: die letzten 25 Zeilen des Journals")
        ende = journal(U, ["-b", "-1", "-n", "25", "-o", "short-iso"]).splitlines()
        for z in ende:
            w("   " + z[:300])
        sauber = sauber_beendet(ende)
        befund.append("Voriger Start endete " + ("sauber (Herunterfahren im Journal)" if sauber else
                                                 "ABRUPT -- kein Herunterfahren im Journal (Strom weg, Hänger oder Taster lang gedrückt)"))

    w(); w("== Wächter-Log (Prüfung alle 5 min)")
    wlog = _unit_datei(U, "hl-watchdog")
    text = U.lesen(wlog, 3_000_000) if wlog else None
    if not text:
        w(f"   nicht gefunden ({wlog or 'Pfad nicht in der Unit'})")
    else:
        bl = wache_bloecke(text)
        schlecht = [b for b in bl if b[0] >= jetzt - 86_400 and b[1] != "ok"]
        w(f"   {wlog}: {len(bl)} Prüfungen gelesen, in den letzten 24 h {len(schlecht)} nicht ok")
        for ts, st, z in schlecht[-30:]:
            w(f"   {_zeit(ts)} {st}: " + " · ".join(" ".join(x.split()) for x in z)[:300])
        dash = [b for b in bl if b[0] >= jetzt - 86_400 and any("hl-dashboard" in x for x in b[2])]
        port = [b for b in bl if b[0] >= jetzt - 86_400 and any(x.split()[1:2] == ["Dashboard"] for x in b[2])]   # seit 23.78
        if port:
            befund.append(f"Wächter: Dashboard lief, antwortete aber nicht auf seinem Port in {len(port)} Prüfungen ({_zeit(port[0][0])} bis "
                          f"{_zeit(port[-1][0])}) -- Hänger")
        befund.append("Wächter: hl-dashboard " + (f"nicht aktiv gemeldet {_zeit(dash[0][0])} bis {_zeit(dash[-1][0])} ({len(dash)} Prüfungen)" if dash
                                                  else "nie als nicht aktiv gemeldet (Prozess lief -- also eher hängend als abgestürzt, oder Wächter selbst stand)"))
        if boot:
            vor = [b for b in bl if b[0] < boot][-3:]
            if vor:
                w(f"   Die letzten Prüfungen vor dem Neustart ({_zeit(boot)}):")
                for ts, st, z in vor:
                    w(f"   {_zeit(ts, True)} {st}" + (": " + " · ".join(" ".join(x.split()) for x in z)[:300] if z else ""))
                luecke = boot - vor[-1][0]
                if luecke > 900:
                    w(f"   Danach {_dauer(luecke)} keine Prüfung bis zum Neustart -- der Wächter lief in dieser Zeit nicht (Pi hing oder stand).")
                    befund.append(f"Wächter: letzte Prüfung {_zeit(vor[-1][0])}, danach {_dauer(luecke)} nichts bis zum Neustart (Pi hing oder stand)")

    w(); w("== CPU- und Temperaturverlauf des Dashboards (je Minute, gesichert alle 5 min)")
    kand = [os.path.join(os.path.dirname(os.path.abspath(db)), "sys_history.json")] if db else []
    kand.append(os.path.join(HIER if U.root == HIER else U.root, "updates", "sys_history.json"))
    verlauf, quelle = None, None
    for k in kand:
        t = U.lesen(k)
        if t:
            try:
                verlauf, quelle = json.loads(t), k
                break
            except ValueError:
                continue
    if not verlauf:
        w("   kein Verlauf gefunden (" + ", ".join(kand) + ")")
    else:
        lu = verlauf_luecken(verlauf, jetzt)
        w(f"   {quelle}: {len(verlauf)} Werte; Lücken über 3 min in den letzten 24 h: {len(lu)}")
        for a, b, s in lu[:5]:
            w(f"   Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(s)})")
        mit_mem = [e for e in verlauf if len(e) >= 5 and e[0] >= jetzt - 86_400]
        if mit_mem:                                                          # seit 23.77: frei nutzbar und RSS des Dashboards (MB)
            fr = [e for e in mit_mem if e[3] is not None]; rs = [e for e in mit_mem if e[4] is not None]
            if fr and rs:
                emin = min(fr, key=lambda e: e[3]); emax = max(rs, key=lambda e: e[4])
                w(f"   Arbeitsspeicher in 24 h: frei nutzbar zuletzt {fr[-1][3]} MB, am wenigsten {emin[3]} MB ({_zeit(emin[0])}); Dashboard "
                  f"zuletzt {rs[-1][4]} MB, am meisten {emax[4]} MB ({_zeit(emax[0])})")
                befund.append(f"Speicher im Verlauf: frei am wenigsten {emin[3]} MB ({_zeit(emin[0])}), Dashboard am meisten {emax[4]} MB")
        if lu:
            a = lu[0][0]
            vorher = [e for e in verlauf if a - 900 <= e[0] <= a]
            w("   Die letzten Werte vor der längsten Lücke (Zeit, CPU %, Temperatur, frei, Dashboard): "
              + " · ".join(f"{_zeit(e[0])} {e[2] if e[2] is not None else '—'} % {e[1] if e[1] is not None else '—'} °C"
                           + (f" frei {e[3]} MB, Dashboard {e[4]} MB" if len(e) >= 5 else "") for e in vorher[-10:]))
            befund.append(f"CPU-Verlauf: längste Lücke {_zeit(lu[0][0])} bis {_zeit(lu[0][1])} ({_dauer(lu[0][2])}; bis zu 5 min davor können "
                          "fehlen, weil nur alle 5 min gesichert wird)")
        w("   Eine Lücke heißt: Das Dashboard hat in der Zeit keinen Wert gemessen -- es stand, hing oder der Pi war aus.")

    haenger_abschnitt(U, db, jetzt, befund)                                  # 23.78 (U215)
    fenster_abschnitt(U, db, jetzt, befund, verlauf, fenster)                # 23.78 (U216)

    w(); w("== Berichte und Debug-Läufe der letzten 24 h (was lief)")
    ber = [(f, t, g) for f, t, g in U.dateien(os.path.join(U.root, "berichte")) if BER_NAME.match(f) and t >= jetzt - 86_400]
    for f, t, g in sorted(ber, key=lambda x: x[1])[-25:]:
        w(f"   {_zeit(t)}  {g / 1024:7.0f} kB  {f}")
    if not ber:
        w("   keine")
    lauf = U.lesen(os.path.join(U.root, "updates", "rueckblick_lauf.json"))
    if lauf:
        try:
            lj = json.loads(lauf)
            w(f"   Rückblick im Hintergrund: gestartet {_zeit(lj.get('start'))} ({lj.get('einheit') or 'PID ' + str(lj.get('pid'))})")
        except ValueError:
            pass

    w(); w("== Speicher, Platte, Strom, Last jetzt")
    mi = U.lesen("/proc/meminfo") or ""
    kb = {k: int(v) for k, v in re.findall(r"^(\w+):\s+(\d+) kB", mi, re.M)}
    if kb:
        w(f"   Arbeitsspeicher {kb.get('MemTotal', 0) / 2 ** 20:.1f} GB, frei nutzbar {kb.get('MemAvailable', 0) / 2 ** 20:.1f} GB; Auslagerung "
          f"{(kb.get('SwapTotal', 0) - kb.get('SwapFree', 0)) / 2 ** 20:.2f} von {kb.get('SwapTotal', 0) / 2 ** 20:.2f} GB belegt")
    w(f"   Last (1/5/15 min): {(U.lesen('/proc/loadavg') or '?').split(' ')[:3]}")
    for pfad in ["/"] + ([os.path.dirname(os.path.abspath(db))] if db else []):
        _rc, t = U.befehl(["df", "-h", pfad], timeout=15)
        zz = (t or "").strip().splitlines()
        w(f"   Platte {pfad}: {' '.join(zz[-1].split()) if zz else '?'}")
    _rc, t = U.befehl(["vcgencmd", "get_throttled"], timeout=10)
    merk = gedrosselt(t)
    w(f"   Strom und Takt (vcgencmd get_throttled): {(t or '').strip()} -> {', '.join(merk) if merk else 'nichts auffällig'}")
    if any("Unterspannung" in m for m in merk):
        befund.append("STROM: Unterspannung " + ("jetzt" if "Unterspannung jetzt" in merk else "seit dem Start") + " -- Netzteil oder USB-Platte prüfen")
    _rc, t = U.befehl(["vcgencmd", "measure_temp"], timeout=10)
    w(f"   Temperatur: {(t or '?').strip()}")

    w(); w("== Prozesse nach Arbeitsspeicher")
    _rc, t = U.befehl(["ps", "-eo", "pid,etimes,rss,pcpu,args", "--sort=-rss"], timeout=15)
    for z in (t or "").splitlines()[:13]:
        teile = z.split(None, 4)
        if len(teile) == 5 and teile[0].isdigit():
            prog = " ".join(os.path.basename(x) if "/" in x else x for x in teile[4].split()[:4])
            w(f"   PID {teile[0]:>7}  seit {_dauer(int(teile[1])):>11}  {int(teile[2]) / 1024:7.0f} MB  CPU {teile[3]:>5} %  {prog[:110]}")

    w(); w("== Update und Notbremse")
    t = U.lesen(os.path.join(U.root, "updates", "last_update.log"), 20_000)
    if t:
        w("   Update-Log (letzte Zeilen):")
        for z in t.strip().splitlines()[-8:]:
            w("   | " + z[:200])
    vor = sorted((f, tt) for f, tt, _g in U.dateien(os.path.join(U.root, "updates")) if f.startswith("vor_"))
    if vor:
        w("   Sicherungen vor Updates: " + ", ".join(f"{f} ({_zeit(tt)})" for f, tt in vor[-2:]))
    nlog = _unit_datei(U, "hl-notbremse")
    t = U.lesen(nlog, 20_000) if nlog else None
    if t:
        w(f"   Notbremse-Log {nlog} (letzte Zeilen):")
        for z in t.strip().splitlines()[-12:]:
            w("   | " + z[:200])

    w(); w("== BEFUND (kurz)")
    for b in befund:
        w("   - " + b)
    w(); w("ENDE -- bitte vollständig einfügen")
    return {"befund": befund}


# ============================================================================================= Selbsttest
class _ProbeUmgebung(Umgebung):
    """Erfundene Umgebung: Befehle aus einer Tabelle, Dateien aus einem Wörterbuch."""
    def __init__(self, befehle: dict, dateien: dict, jetzt: float, boot: int, pw: str | None = "probe-pw", ordner: dict | None = None):
        super().__init__("/probe")
        self.tab = befehle; self.files = dateien; self.t = jetzt; self.b = boot; self.pw = pw; self.ordner = ordner or {}; self.aufrufe = []

    def sudo_pw(self):
        return self.pw

    def befehl(self, args, timeout=30, sudo=False):
        args = list(args); self.aufrufe.append((args, sudo))
        for (muster, mit_sudo), antwort in self.tab.items():
            if mit_sudo == sudo and all(m in args for m in muster):
                return antwort
        return 1, ""

    def lesen(self, pfad, max_bytes=None):
        return self.files.get(pfad)

    def jetzt(self):
        return self.t

    def boot(self):
        return self.b

    def dateien(self, ordner):
        return self.ordner.get(ordner, [])


HAENGER_PROBE = """
== 2026-10-23 09:17:20 Dashboard-Start, PID 812 -- Stapel folgen nur bei Hänger oder Absturz

== 2026-10-23 09:33:01 Webserver antwortet nicht (Versuch 2) -- PID 812, 2 Fäden (Abzug mit Namen, neueste Zeile unten)
-- lebenszeichen (Thread 0x00007f20a35fe6c0)
     File "/usr/lib/python3.11/threading.py", line 1002, in _bootstrap
       self._bootstrap_inner()
     File "/home/seed/p/hl_viz.py", line 10092, in run
       lebenszeichen_runde(url, antwort_s, melden, abzug_s, teil)
     File "/home/seed/p/hl_viz.py", line 10052, in lebenszeichen_runde
       faeden_abzug(f"Webserver antwortet nicht (Versuch {LEBT['fehl']})")
-- MainThread (Thread 0x00007f20a5768080)
     File "/home/seed/p/hl_viz.py", line 11020, in <module>
       main()
     File "/home/seed/p/hl_viz.py", line 10144, in serve
       srv.serve_forever()
     File "/usr/lib/python3.11/selectors.py", line 415, in select
       fd_event_list = self._selector.poll(timeout, max_ev)
Timeout (0:05:00)!
Thread 0x00007f20a35fe6c0 (most recent call first):
  File "/home/seed/p/hl_viz.py", line 10026 in lebenszeichen_runde
  File "/home/seed/p/hl_viz.py", line 10092 in run

Thread 0x00007f20a1234567 (most recent call first):
  File "/usr/lib/python3.11/sqlite3/dbapi2.py", line 10 in execute
  File "/home/seed/p/hl_notbremse.py", line 1645 in welt_a_anlegen
  File "/home/seed/p/hl_viz.py", line 8193 in _welt_a_takt

Current thread 0x00007f20a5768080 (most recent call first):
  File "/usr/lib/python3.11/selectors.py", line 415 in select
  File "/usr/lib/python3.11/socketserver.py", line 233 in serve_forever
  File "/home/seed/p/hl_viz.py", line 10144 in serve
Fatal Python error: Aborted

Thread 0x00007f20a35fe6c0 (most recent call first):
  File "/home/seed/p/hl_viz.py", line 10026 in lebenszeichen_runde

Current thread 0x00007f20a5768080 (most recent call first):
  File "/usr/lib/python3.11/selectors.py", line 415 in select
  File "/home/seed/p/hl_viz.py", line 10144 in serve

Extension modules: numpy._core._multiarray_umath (total: 1)

== 2026-10-23 09:48:02 Dashboard-Start, PID 1430 -- Stapel folgen nur bei Hänger oder Absturz
"""


class _ProbeJournal(_ProbeUmgebung):
    """Erfundene Umgebung mit Zustand für --journal-dauerhaft: Was die Befehle tun, ändert, was systemd-analyze danach zeigt."""
    def __init__(self, jetzt, boot, vendor: str = "Storage=volatile", spaeter: str | None = None, fehl_bei: str | None = None, pw="probe-pw"):
        super().__init__({}, {}, jetzt, boot, pw=pw)
        self.vendor = vendor; self.spaeter = spaeter; self.fehl_bei = fehl_bei
        self.dropin = False; self.ordner_da = False; self.geschrieben = {}; self.entfernt = []

    def befehl(self, args, timeout=30, sudo=False):
        args = list(args); self.aufrufe.append((args, sudo))
        if self.fehl_bei and self.fehl_bei in args:
            return 1, "probe: Fehler"
        if args[:2] == ["systemd-analyze", "cat-config"]:
            t = "# /etc/systemd/journald.conf\n[Journal]\n#Storage=auto\n\n# /usr/lib/systemd/journald.conf.d/40-probe.conf\n[Journal]\n" + self.vendor + "\n"
            if self.dropin:
                t += "\n# " + JOURNAL_DROPIN + "\n[Journal]\nStorage=persistent\nSystemMaxUse=200M\n"
            if self.spaeter:
                t += "\n# /etc/systemd/journald.conf.d/99-fremd.conf\n[Journal]\n" + self.spaeter + "\n"
            return 0, t
        if args[0] == "install" and args[-1] == JOURNAL_DROPIN:
            self.dropin = args[-2] in self.geschrieben
        elif args[:2] == ["mkdir", "-p"]:
            self.ordner_da = True
        elif args[:2] == ["rm", "-f"] and args[-1] == JOURNAL_DROPIN:
            self.dropin = False
        elif args[:2] == ["rm", "-rf"]:
            self.ordner_da = False
        return 0, ""

    def schreiben(self, pfad, text):
        self.geschrieben[pfad] = text
        return True

    def entfernen(self, pfad):
        self.entfernt.append(pfad); self.geschrieben.pop(pfad, None)

    def da(self, pfad):
        return self.ordner_da if pfad == "/var/log/journal" else False


def _selbsttest_78(ok, tmp: str) -> None:
    """23.78: Hänger-Abzüge lesen, Recorder-Zeiten über Mitternacht, Lebenszeichen je Tabelle, Fenster Ende zu Ende (ganzes Dashboard stand /
    nur Teile), Systemprotokoll dauerhaft ein/aus mit sudo nur über stdin."""
    import contextlib
    import io
    # C9 Hänger-Datei: Start, Abzug mit Namen (neueste Zeile zuletzt), faulthandler Timeout und Abbruch (neueste zuerst), nächster Start
    e = haenger_lesen(HAENGER_PROBE)
    arten = [x["art"] for x in e]
    st_abzug = {k: _stelle(r) for k, r in e[1]["faeden"]}
    st_to = [_stelle(r) for _k, r in e[2]["faeden"]]
    ok("C9 Hänger-Datei: Starts, Abzug mit Namen, faulthandler-Abzug (Timeout) und Abbruch (Aborted) mit je allen Fäden; Stelle = neueste im Projekt",
       arten == ["start", "abzug", "timeout", "fatal", "start"] and e[1]["ts"] == int(datetime(2026, 10, 23, 9, 33, 1).timestamp())
       and [len(x["faeden"]) for x in e] == [0, 2, 3, 2, 0]
       and st_abzug.get("lebenszeichen 0x00007f20a35fe6c0", "").startswith("hl_viz.py:10052 lebenszeichen_runde")
       and st_abzug.get("MainThread 0x00007f20a5768080") == "hl_viz.py:10144 serve ← darin selectors.py:415 select"
       and st_to[1] == "hl_notbremse.py:1645 welt_a_anlegen ← darin dbapi2.py:10 execute" and e[3]["titel"] == "Fatal Python error: Aborted",
       f"{arten}; {st_to[1]}")
    # C10 Recorder-Log: nur Uhrzeiten -- Datum rückwärts vom Ende, über Mitternacht; Zeilen ohne Zeit gehören zur Zeile davor
    jetzt = int(datetime(2026, 10, 24, 0, 20).timestamp())
    rz = recorder_zeilen("[23:50:00] Adressen 1 | Positionen 2\n[23:59:30] Backup läuft …\n           Backup ok: 3400 MB in 610 s\n"
                         "[00:09:59] Adressen 1 | Positionen 2\n", jetzt)
    rz2 = recorder_zeilen("[23:55:00] Adressen 1\n", jetzt)
    ok("C10 Recorder-Log: Datum über Mitternacht richtig, Zeile ohne Zeit hängt an der davor; letzte Zeile später als jetzt -> Vortag",
       [r[0] for r in rz] == [int(datetime(2026, 10, 23, 23, 50).timestamp()), int(datetime(2026, 10, 23, 23, 59, 30).timestamp()),
                              int(datetime(2026, 10, 23, 23, 59, 30).timestamp()), int(datetime(2026, 10, 24, 0, 9, 59).timestamp())]
       and rz2[0][0] == int(datetime(2026, 10, 23, 23, 55).timestamp()), f"{[_zeit(r[0], True) for r in rz]}")
    # C11 Lebenszeichen je Tabelle
    a = int(datetime(2026, 10, 23, 9, 31).timestamp()); b = int(datetime(2026, 10, 23, 14, 28).timestamp())
    p = os.path.join(tmp, "c11.db"); con = sqlite3.connect(p)
    con.execute("CREATE TABLE t (ts INTEGER)"); con.execute("CREATE TABLE weiter (ts INTEGER)"); con.execute("CREATE TABLE selten (ts INTEGER)")
    con.executemany("INSERT INTO t VALUES (?)", [(t,) for t in range(a - 8 * 3600, a, 900)] + [(t,) for t in range(b + 60, b + 3600, 900)])
    con.executemany("INSERT INTO weiter VALUES (?)", [(t,) for t in range(a - 8 * 3600, b + 3600, 900)])
    con.executemany("INSERT INTO selten VALUES (?)", [(a - 7200,), (b + 100,)])
    con.commit()
    z1 = lebenszeichen_zaehlen(con, "t", "ts", a, b); z2 = lebenszeichen_zaehlen(con, "weiter", "ts", a, b)
    z3 = lebenszeichen_zaehlen(con, "selten", "ts", a, b); z4 = lebenszeichen_zaehlen(con, "fehlt", "ts", a, b)
    con.close()
    ok("C11 Lebenszeichen: alle 15 min und nichts in 5 h -> stand (≈20 erwartet); läuft durch -> lief weiter; selten -> kein Urteil; Tabelle fehlt -> None",
       z1["urteil"] == "stand" and z1["n_in"] == 0 and 19 <= z1["erwartet"] <= 21 and z1["vor"] == a - 900 and z1["nach"] == b + 60
       and z2["urteil"] == "lief weiter" and z2["n_in"] == 19 and z3["urteil"] == "zu selten für ein Urteil" and z4 is None,
       f"{z1['urteil']} ({z1['erwartet']:.1f}), {z2['urteil']} ({z2['n_in']}), {z3['urteil']}, {z4}")
    # C12 Fenster Ende zu Ende: Prognose, TradeLabor, Ausblick, Makro, Aktien stehen; Recorder und Notbremse laufen; Welt A fehlt
    def lage(teil_weiter: bool) -> tuple:
        d = os.path.join(tmp, "teil" if teil_weiter else "ganz")
        os.makedirs(d, exist_ok=True)
        jetzt_ = b + 3 * 3600
        def tab(datei, sql, tabelle, spalte, zeiten):
            c = sqlite3.connect(os.path.join(d, datei)); c.execute(sql)
            c.executemany(f"INSERT INTO {tabelle} ({spalte}) VALUES (?)", [(t,) for t in zeiten]); c.commit(); c.close()
        alle15 = [t for t in range(jetzt_ - 7 * 86_400, jetzt_, 900) if not (a < t < b)]
        tab("forecasts.db", "CREATE TABLE forecast (ts INTEGER, coin TEXT)", "forecast", "ts", alle15)
        c = sqlite3.connect(os.path.join(d, "forecasts.db"))
        c.execute("CREATE TABLE labor_ereignis (ts INTEGER)"); c.execute("CREATE TABLE konfluenz_log (ts INTEGER)")
        c.executemany("INSERT INTO labor_ereignis VALUES (?)", [(t,) for t in range(a - 6 * 3600, b + 3600, 120) if teil_weiter or not (a < t < b)])
        c.commit(); c.close()
        tab("ausblick.db", "CREATE TABLE au_prognose (erzeugt INTEGER)", "au_prognose", "erzeugt", [t for t in range(a - 6 * 3600, jetzt_, 3600) if not a < t < b])
        tab("makro.db", "CREATE TABLE mk_abruf (ts INTEGER)", "mk_abruf", "ts", [t for t in range(a - 6 * 3600, jetzt_, 1800) if not a < t < b])
        tab("aktien.db", "CREATE TABLE ak_abruf (ts INTEGER)", "ak_abruf", "ts", [t for t in range(a - 6 * 3600, jetzt_, 1800) if not a < t < b])
        tab("hl_liq.db", "CREATE TABLE bars (ts INTEGER, coin TEXT)", "bars", "ts", list(range(a - 6 * 3600, jetzt_, 60)))
        tab("notbremse.db", "CREATE TABLE nb_zustand (ts INTEGER)", "nb_zustand", "ts", list(range(a - 6 * 3600, jetzt_, 60)))
        wl = []
        t_, k_ = a - 3600, 0
        while t_ < b + 1800:
            schlecht = ["  !    Abdeckung        BTC 26%", "  XXX  Poller           90 % der Positionen jünger als 1062 min"]
            wl += ["", f"{datetime.fromtimestamp(t_):%Y-%m-%d %H:%M:%S} — Gesamtstatus: KRITISCH", "-" * 62, "  ok   Verbindung      alle"] + schlecht
            wl += (["  ok   Backup          vor 0.1 h, 3400 MB in /m/dbbackup"] if a <= t_ <= a + 900 else [])
            wl += (["  XXX  Dashboard       127.0.0.1:8765 antwortet nicht (TimeoutError), obwohl der Dienst läuft"] if k_ in (20, 21) else [])
            k_ += 1
            t_ += 900 if k_ == 30 else (337 if k_ in (21, 22) else 302)        # eine Prüfung 15 min verzögert; Dashboard hängt: +35 s
        rz_ = [(t, f"[{datetime.fromtimestamp(t):%H:%M:%S}] Adressen 1 | Positionen 2") for t in range(a - 3 * 3600, b + 3600, 600)]
        rz_ += [(a + 30, f"[{datetime.fromtimestamp(a + 30):%H:%M:%S}] Backup läuft …"), (a + 30.5, "           Backup ok: 3400 MB in 610 s")]
        rl = "\n".join(z for _t, z in sorted(rz_))
        befehle = {(("systemctl", "cat", "hl-watchdog"), False): (0, "[Service]\nStandardOutput=append:/l/watchdog.log\n"),
                   (("systemctl", "cat", "hl-recorder"), False): (0, "[Service]\nStandardOutput=append:/l/recorder.log\n"),
                   (("systemctl", "cat", "hl-dashboard"), False): (0, "[Service]\nStandardOutput=append:/l/dashboard.log\n"),
                   (("systemctl", "show", "hl-dashboard", "WatchdogUSec"), False): (0, "WatchdogUSec=15min\nNRestarts=1\nResult=watchdog\n")}
        log = "\n".join(f"{datetime.fromtimestamp(b - 60 + i):%Y-%m-%d %H:%M:%S} " + z for i, z in enumerate(
            ["Lebenszeichen: Webserver antwortet nicht (Versuch 1 seit 14:27:00)", "Dashboard: http://0.0.0.0:8765"]))
        dateien = {"/l/watchdog.log": "\n".join(wl), "/l/recorder.log": rl, "/l/dashboard.log": log,
                   "/l/dashboard_haenger.log": HAENGER_PROBE.replace("2026-10-23 09:", f"{datetime.fromtimestamp(jetzt_ - 3600):%Y-%m-%d} 09:")}
        U = _ProbeUmgebung(befehle, dateien, jetzt_, b)
        puffer = io.StringIO()
        with contextlib.redirect_stdout(puffer):
            erg = bericht(U, os.path.join(d, "hl_liq.db"))
        g0 = max(t for t in alle15 if t <= a); g1 = min(t for t in alle15 if t >= b)
        return puffer.getvalue(), " | ".join(erg["befund"]), f"Lücke {_zeit(g0, True)} bis {_zeit(g1, True)}"
    text, bf, luecke_soll = lage(False)
    ok("C12 Fenster Ende zu Ende: Lücke aus den Prognosen (rund 5 h), Wächter mit Abständen (1 verzögert), Recorder-Backup, Lebenszeichen "
       "-> das GANZE Dashboard stand, eigene Dienste liefen; Welt A fehlt; Hänger-Schutz an, letzter Neustart durch den Wächter",
       luecke_soll in text and "das GANZE Dashboard stand" in bf and "letztes vor der Lücke 23.10. 09:31:00" in bf and "1 verzögert" in bf
       and "Backup läuft" in text and "Datei fehlt (labor_a.db)" in text and "LETZTER NEUSTART DURCH DEN WÄCHTER" in bf
       and "Hänger-Abzüge in 7 Tagen: 3" in bf and "hl_notbremse.py:1645 welt_a_anlegen" in text and "Meldungen „Lebenszeichen“ in 7 Tagen: 1" in text
       and "(dauernd nicht ok im Fenster, nur mit Namen: Abdeckung, Poller)" in text
       and "antwortete aber nicht auf seinem Port in 2 Prüfungen" in bf and "XXX Dashboard 127.0.0.1:8765 antwortet nicht" in text,
       bf[bf.find("Hänger-Schutz"):][:360])
    text2, bf2, _l = lage(True)
    ok("C12b Teil-Hänger: TradeLabor schreibt in der Lücke weiter -> nur TEILE standen, nicht der ganze Prozess",
       "nur TEILE standen" in bf2 and "TradeLabor Welt B" in bf2.split("andere liefen weiter")[-1], bf2[bf2.find("Lebenszeichen"):][:200])
    # C13 Systemprotokoll dauerhaft: ein (Schritte in Reihenfolge, sudo, Passwort nie in den Argumenten, Zwischendatei weg), Fehler hält an,
    # aus, ohne sudo.txt nichts, eine später gelesene Einstellung setzt Storage anders -> nicht erledigt
    j = _ProbeJournal(jetzt, b)
    with contextlib.redirect_stdout(io.StringIO()) as pa:
        r_an = journal_dauerhaft(j, True)
    befehle_an = [a_[0][:2] for a_, s_ in [(x, x[1]) for x in j.aufrufe] if s_]
    sauber = all("probe-pw" not in " ".join(a_) for a_, _s in j.aufrufe)
    with contextlib.redirect_stdout(io.StringIO()):
        r_aus = journal_dauerhaft(j, False)
    j2 = _ProbeJournal(jetzt, b, fehl_bei="systemd-tmpfiles")
    with contextlib.redirect_stdout(io.StringIO()):
        r_fehl = journal_dauerhaft(j2, True)
    j3 = _ProbeJournal(jetzt, b, pw=None)
    with contextlib.redirect_stdout(io.StringIO()):
        r_ohne = journal_dauerhaft(j3, True)
    j4 = _ProbeJournal(jetzt, b, spaeter="Storage=volatile")
    with contextlib.redirect_stdout(io.StringIO()) as p4:
        r_spaet = journal_dauerhaft(j4, True)
    ok("C13 Systemprotokoll dauerhaft: ein (Einstellung, Ordner, Rechte, journald neu, übernehmen; nur mit sudo, Passwort nie in den "
       "Argumenten, Zwischendatei entfernt), aus (Einstellung und Ordner weg); Fehler hält an; ohne sudo.txt nichts; spätere Datei -> nicht erledigt",
       r_an and befehle_an == [["install", "-D"], ["mkdir", "-p"], ["systemd-tmpfiles", "--create"], ["systemctl", "restart"], ["journalctl", "--flush"]]
       and sauber and not j.geschrieben and len(j.entfernt) == 1 and "Storage=persistent" in pa.getvalue() and r_aus and not j.dropin
       and not j.ordner_da and not r_fehl and not any(a_[0] == "systemctl" for a_, _s in j2.aufrufe if _s)
       and not r_ohne and not any(s_ for _a, s_ in j3.aufrufe) and not r_spaet and "ACHTUNG" in p4.getvalue(),
       f"ein {r_an}, aus {r_aus}, Fehler {r_fehl}, ohne Passwort {r_ohne}, spätere Datei {r_spaet}; {befehle_an}")


def selbsttest(verbose: bool = True) -> bool:
    import contextlib
    import io
    pruef = []

    def ok(name, bed, text=""):
        pruef.append(bool(bed))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    t0 = time.time()
    if verbose:
        print("check_system -- Selbsttest (erfundene Eingaben, ohne systemd)", flush=True)
    jetzt = int(datetime(2026, 10, 23, 14, 40).timestamp()); boot = int(datetime(2026, 10, 23, 14, 25).timestamp())
    # Wächter-Log: ok, dann KRITISCH (Dashboard nicht aktiv), dann eine Stunde nichts bis zum Neustart
    log = []
    for k, (st, zeilen) in enumerate((("ok", []), ("KRITISCH", ["  XXX  Dienste          hl-dashboard (activating)"]),
                                      ("WARNUNG", ["  !    Speicherplatz    noch 8 %"]), ("ok", []))):
        ts = boot - 3 * 3600 + k * 300
        log += ["", f"{datetime.fromtimestamp(ts):%Y-%m-%d %H:%M:%S} — Gesamtstatus: {st}", "-" * 62, "  ok   Verbindung      Info 120 ms"] + zeilen
    bl = wache_bloecke("\n".join(log))
    ok("Wächter-Log: Prüfungen und Meldungen ≠ ok erkannt", len(bl) == 4 and bl[1][1] == "KRITISCH" and "hl-dashboard" in bl[1][2][0]
       and bl[2][2] == ["!    Speicherplatz    noch 8 %"] and bl[3][2] == [], f"{[(b[1], len(b[2])) for b in bl]}")
    # Verlauf: jede Minute, Lücke von 47 min, letzte Werte vor 2 min
    v = ([[t, 55.0, 30, 2400 - (t - jetzt + 6 * 3600) // 60 * 10, 700 + (t - jetzt + 6 * 3600) // 60 * 10] for t in range(jetzt - 6 * 3600, jetzt - 3 * 3600, 60)]
         + [[t, 50.0, 12, 5200, 650] for t in range(jetzt - 3 * 3600 + 47 * 60, jetzt - 60, 60)])
    lu = verlauf_luecken(v, jetzt)
    ok("Verlauf: längste Lücke mit Zeit und Dauer; Lücke bis jetzt zählt mit", len(lu) == 1 and lu[0][2] == 48 * 60
       and verlauf_luecken(v[:100], jetzt)[0][1] == jetzt, f"{[(_zeit(a), _zeit(b), _dauer(s)) for a, b, s in lu]}")
    ok("Strom: get_throttled entschlüsselt", gedrosselt("throttled=0x50005") == ["Unterspannung jetzt", "gedrosselt jetzt", "Unterspannung seit dem Start",
                                                                                 "gedrosselt seit dem Start"]
       and gedrosselt("throttled=0x0") == [] and gedrosselt("vcgencmd: nicht vorhanden") == ["nicht lesbar"], f"{gedrosselt('throttled=0x50005')}")
    lb_kopf = ("IDX BOOT ID                          FIRST ENTRY                 LAST ENTRY\n"
               " -1 0123456789abcdef0123456789abcdef Thu 2026-10-22 09:00:01 CEST Fri 2026-10-23 13:02:11 CEST\n"
               "  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST Fri 2026-10-23 14:40:00 CEST")
    st = starts_lesen(lb_kopf); st2 = starts_lesen("  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST—Fri 2026-10-23 14:40:00 CEST")
    ok("Journal: Liste der Starts (mit und ohne Kopfzeile)", [s[0] for s in st] == [-1, 0] and len(st2) == 1 and st2[0][0] == 0,
       f"{[(s[0], s[2][:24]) for s in st]}")
    n, tr = kern_zaehlen(["[  1.0] usb 1-1: USB disconnect, device number 2", "Out of memory: Killed process 1234 (python3)",
                          "hwmon hwmon1: Undervoltage detected!", "INFO: task python3:999 blocked for more than 120 seconds.", "eth0: Link is Up"])
    ok("Kernel: Zeilen je Art gezählt (Speicher, Platte/USB, Strom, Hänger), harmlose nicht", n["Speicher"] == 1 and n["Platte/USB"] == 1
       and n["Strom"] == 1 and n["Hänger"] == 1 and len(tr) == 4, f"{n}")
    ok("Ende des vorigen Starts: sauber gegen abrupt", sauber_beendet(["Oct 23 13:02 systemd-shutdown[1]: Syncing filesystems and block devices."])
       and sauber_beendet(["Reached target System Power Off."]) and not sauber_beendet(["Oct 23 13:02 hl_viz.py[812]: TradeLabor-Takt: 13.0 s"]),
       "systemd-shutdown/Power Off = sauber, sonst abrupt")
    # Journal: ohne Rechte Hinweis → einmal mit sudo; Passwort nie in den Argumenten
    U = _ProbeUmgebung({(("--list-boots",), False): (0, "Hint: You are currently not seeing messages from other users and the system.\n"
                                                        "      Users in groups 'adm', 'systemd-journal' can see all messages.\n" + lb_kopf.splitlines()[2]),
                        (("--list-boots",), True): (0, lb_kopf)}, {}, jetzt, boot)
    t = journal(U, ["--list-boots"])
    ok("Journal: ohne Leserechte einmal mit sudo (Passwort nur über stdin)", len(starts_lesen(t)) == 2 and U.aufrufe[-1][1]
       and "probe-pw" not in " ".join(U.aufrufe[-1][0]) and "Hint" not in t, f"{len(U.aufrufe)} Aufrufe, zuletzt sudo {U.aufrufe[-1][1]}")
    # Ende zu Ende auf erfundener Umgebung
    wlog = "/var/log/hl/watchdog.log"
    befehle = {(("systemctl", "cat", "hl-watchdog"), False): (0, f"[Service]\nStandardOutput=append:{wlog}\n"),
               (("systemctl", "show", "hl-dashboard"), False): (0, "ActiveState=active\nSubState=running\nNRestarts=0\nMemoryCurrent=734003200\n"),
               (("--list-boots",), False): (0, lb_kopf),
               (("-b", "-1", "-u", "hl-dashboard", "-t", "systemd"), False): (0, "2026-10-23T12:10:02+0200 systemd[1]: hl-dashboard.service: Main process exited, "
                                                                               "code=killed, status=9/KILL\n2026-10-23T12:10:22+0200 systemd[1]: "
                                                                               "hl-dashboard.service: Scheduled restart job, restart counter is at 1."),
               (("-b", "-1", "-k"), False): (0, "2026-10-23T12:10:01+0200 kernel: Out of memory: Killed process 812 (python3) total-vm:3123456kB"),
               (("-b", "-1", "-n", "25"), False): (0, "2026-10-23T13:02:11+0200 hl_viz.py[901]: TradeLabor-Takt: 12.1 s"),
               (("vcgencmd", "get_throttled"), False): (0, "throttled=0x50000\n"),
               (("df", "-h"), False): (0, "Filesystem Size Used Avail Use% Mounted on\n/dev/sda1 916G 402G 468G 47% /media/seed/marketdatabase\n")}
    dateien = {wlog: "\n".join(log), "/m/sys_history.json": json.dumps(v), "/proc/meminfo": "MemTotal:  8000000 kB\nMemAvailable: 5000000 kB\n"}
    U2 = _ProbeUmgebung(befehle, dateien, jetzt, boot, ordner={"/probe/berichte": [("2026-10-23_11-58_notbremse_rueckblick_manuell.txt", jetzt - 9000, 4096)]})
    puffer = io.StringIO()
    with contextlib.redirect_stdout(puffer):
        erg = bericht(U2, "/m/hl_liq.db")
    text = puffer.getvalue(); bf = " | ".join(erg["befund"])
    ok("Bericht Ende zu Ende: Befund mit Journal, Absturz durch systemd, Kernel (Speicher), abruptem Ende, Wächter, Lücke, Strom, Berichten",
       "Journal dauerhaft: ja" in bf and "2 Zeilen zu Absturz" in bf and "Speicher 1" in bf and "ABRUPT" in bf and "nicht aktiv gemeldet" in bf
       and "längste Lücke" in bf and "Unterspannung seit dem Start" in bf and "notbremse_rueckblick_manuell" in text and "ENDE" in text
       and "frei am wenigsten 610 MB" in bf and "Dashboard am meisten 2490 MB" in bf and "frei 610 MB, Dashboard 2490 MB" in text,
       bf[:400])
    # ------------------------------------------------------------------------------------------- 23.78
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="cs78_")
    try:
        _selbsttest_78(ok, tmp)
    except Exception as e:                       # eine Ausnahme ist ein Fehler, kein Abbruch der übrigen Ausgabe
        import traceback
        ok("23.78-Proben ohne Ausnahme", False, f"{type(e).__name__}: {e} {traceback.format_exc()[-500:]}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(pruef) and bool(pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(pruef)} von {len(pruef)}, {time.time() - t0:.1f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", default=None, help="Hauptdatenbank (für Platte und Verlauf neben der Datenbank)")
    p.add_argument("--selbsttest", action="store_true", help="Proben auf erfundenen Eingaben")
    p.add_argument("--fenster", nargs=2, metavar=("VON", "BIS"), help="23.78: Fenster von Hand, z. B. 2026-10-23T09:31 2026-10-23T14:28")
    p.add_argument("--journal-dauerhaft", choices=("an", "aus"), help="23.78: Systemprotokoll dauerhaft ein-/ausschalten (sudo.txt)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.journal_dauerhaft:
        sys.exit(0 if journal_dauerhaft(Umgebung(), a.journal_dauerhaft == "an") else 1)
    fenster = None
    if a.fenster:
        try:
            fenster = (zeit_lesen(a.fenster[0]), zeit_lesen(a.fenster[1]))
        except ValueError as e:
            p.error(str(e))
    bericht(Umgebung(), a.db, fenster)


if __name__ == "__main__":
    main()
