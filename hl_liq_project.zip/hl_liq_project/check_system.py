#!/usr/bin/env python3
"""
check_system.py -- Systemdiagnose ohne SSH (23.77): Warum war das Dashboard nicht erreichbar, was lief vor dem letzten Neustart?

  python3 check_system.py [--db hl_liq.db]     Bericht (liest nur)
  python3 check_system.py --selbsttest         Proben auf erfundenen Eingaben (ohne systemd)

Anlass: Am 23.10. war die Weboberfläche nicht erreichbar (Ping ging, Port 8765 nicht); SSH ist auf dem Pi aus, ein Bildschirm hängt nicht
dran. Nach dem Neustart über den Taster lief alles wieder -- die Ursache ist nur noch in den Protokollen zu finden. Dieses Werkzeug läuft
aus der Debug-Konsole und sammelt sie:
  Befund (kurz) · Laufzeit und Dienste · Starts im Journal · vor dem letzten Neustart: Dashboard (Abstürze, letzte Zeilen), Kernel
  (Speicher, Platte/USB, Strom, Hänger), die letzten Zeilen des vorigen Starts (sauber heruntergefahren oder abrupt) · Wächter-Log (Meldungen
  der letzten 24 h, die Prüfungen vor dem Neustart) · CPU- und Temperaturverlauf des Dashboards (Lücken: Dashboard stand oder hing) ·
  Berichte der letzten 24 h (was lief) · Speicher, Platte, Strom, Prozesse jetzt · Update- und Notbremse-Log.
Das Journal des vorigen Starts gibt es nur, wenn journald dauerhaft speichert (/var/log/journal); sonst steht das im Bericht. Lesen darf
es die Gruppe adm (Standardnutzer des Pi); sonst einmal mit sudo (Passwort aus sudo.txt wie beim Update, nur über stdin).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime

HIER = os.path.dirname(os.path.abspath(__file__))
DIENSTE = ("hl-dashboard", "hl-recorder", "hl-notbremse", "hl-binance", "hl-coinbase", "hl-watchdog")
# Kernel-Zeilen, die einen Ausfall erklären können -- je Art gezählt
KERN_ARTEN = (("Speicher", re.compile(r"out of memory|oom[-_ ]?kill|killed process|oom_reaper", re.I)),
              ("Platte/USB", re.compile(r"i/o error|blk_update_request|buffer i/o|ext4-fs error|usb \S+: usb disconnect|"
                                        r"reset (high|super|full)[- ]?speed usb|uas_eh|sd \S+: \[sd\w\] .*(error|fail)", re.I)),
              ("Strom", re.compile(r"under-?voltage|voltage normali[sz]ed|hwmon.*in0_lcrit", re.I)),
              ("Hänger", re.compile(r"hung_task|blocked for more than|soft lockup|hard lockup|rcu.*stall", re.I)),
              ("Temperatur", re.compile(r"thermal|temperature above|cpu clock throttled", re.I)))
WACHE_KOPF = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) — Gesamtstatus: (\S+)")
BER_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}_[a-z0-9_]+\.txt$")
SAUBER = re.compile(r"systemd-shutdown|Reached target .*(Power[- ]?Off|Reboot|Shutdown|Halt)|System is (powering down|rebooting)|"
                    r"Stopped target .*Multi-User|Journal stopped", re.I)
GEDROSSELT = {0: "Unterspannung jetzt", 1: "Takt gedeckelt jetzt", 2: "gedrosselt jetzt", 3: "Temperaturgrenze jetzt",
              16: "Unterspannung seit dem Start", 17: "Takt gedeckelt seit dem Start", 18: "gedrosselt seit dem Start",
              19: "Temperaturgrenze seit dem Start"}


def w(text: str = "") -> None:
    print(text, flush=True)


def _zeit(ts, sek: bool = False) -> str:
    return datetime.fromtimestamp(int(ts)).strftime("%d.%m. %H:%M:%S" if sek else "%d.%m. %H:%M") if ts else "—"


def _dauer(s: float) -> str:
    s = int(s)
    return f"{s // 86_400} d {s % 86_400 // 3600} h" if s >= 86_400 else (f"{s // 3600} h {s % 3600 // 60} min" if s >= 3600 else f"{s // 60} min")


class Umgebung:
    """Befehle, Dateien, Zeit -- in den Proben ersetzt."""
    def __init__(self, root: str = HIER):
        self.root = root

    def sudo_pw(self) -> str | None:
        f = os.path.join(self.root, "sudo.txt")
        try:
            if os.stat(f).st_mode & 0o077:
                return None
            with open(f, errors="replace") as fh:
                return fh.read().strip() or None
        except OSError:
            return None

    def befehl(self, args, timeout: int = 30, sudo: bool = False) -> tuple:
        args = list(args)
        try:
            if sudo:
                pw = self.sudo_pw()
                if not pw:
                    return 1, "kein sudo-Passwort (sudo.txt)"
                r = subprocess.run(["sudo", "-S", "-p", ""] + args, input=pw + "\n", capture_output=True, text=True, timeout=timeout)
            else:
                r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
            return r.returncode, (r.stdout or "") + (r.stderr or "")
        except FileNotFoundError:
            return 127, f"{args[0]}: nicht vorhanden"
        except subprocess.TimeoutExpired:
            return 124, f"{args[0]}: keine Antwort in {timeout} s"
        except OSError as e:
            return 1, f"{args[0]}: {e}"

    def lesen(self, pfad: str, max_bytes: int | None = None) -> str | None:
        try:
            with open(pfad, "rb") as f:
                if max_bytes:
                    f.seek(0, 2)
                    f.seek(max(0, f.tell() - max_bytes))
                return f.read().decode("utf-8", errors="replace")
        except OSError:
            return None

    def jetzt(self) -> float:
        return time.time()

    def boot(self) -> int | None:
        t = self.lesen("/proc/stat") or ""
        m = re.search(r"^btime (\d+)", t, re.M)
        return int(m.group(1)) if m else None

    def dateien(self, ordner: str) -> list:
        try:
            return [(f, os.path.getmtime(os.path.join(ordner, f)), os.path.getsize(os.path.join(ordner, f))) for f in os.listdir(ordner)]
        except OSError:
            return []


# --------------------------------------------------------------------------------------------- Bausteine (in den Proben einzeln geprüft)
def journal(U: Umgebung, args) -> str:
    """journalctl ohne Seitenumbruch; sieht der Nutzer nur seine eigenen Zeilen (nicht in der Gruppe adm), einmal mit sudo."""
    rc, out = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90)
    eng = "not seeing messages from other users" in out or "insufficient permissions" in out
    if (eng or rc not in (0, 1)) and U.sudo_pw():
        rc2, out2 = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90, sudo=True)
        if rc2 == 0:
            out = out2
    return "\n".join(z for z in out.splitlines() if not z.startswith("Hint:") and "Users in groups" not in z and "pass -q to" not in z)


def starts_lesen(text: str) -> list:
    """journalctl --list-boots -> [(Index, Boot-ID, Rest)] (mit oder ohne Kopfzeile)."""
    out = []
    for z in text.splitlines():
        m = re.match(r"^\s*(-?\d+)\s+([0-9a-f]{32})\s+(.*)$", z)
        if m:
            out.append((int(m.group(1)), m.group(2), m.group(3).strip()))
    return out


def kern_zaehlen(zeilen: list) -> tuple:
    """Kernel-Zeilen je Art. -> ({Art: Anzahl}, [passende Zeilen])"""
    n = {a: 0 for a, _ in KERN_ARTEN}; treffer = []
    for z in zeilen:
        for a, rx in KERN_ARTEN:
            if rx.search(z):
                n[a] += 1; treffer.append(z)
                break
    return n, treffer


def sauber_beendet(zeilen: list) -> bool:
    """Ende des vorigen Starts: Herunterfahren im Journal (sauber) oder nicht (abrupt: Strom, Hänger, Taster lang gedrückt)."""
    return any(SAUBER.search(z) for z in zeilen)


def wache_bloecke(text: str) -> list:
    """Wächter-Log -> [(ts, Status, [Zeilen ≠ ok])]."""
    out = []
    for z in text.splitlines():
        m = WACHE_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            out.append([ts, m.group(2), []])
        elif out and (z.startswith("  !    ") or z.startswith("  XXX  ")):
            out[-1][2].append(z.strip())
    return [tuple(b) for b in out]


def verlauf_luecken(eintraege: list, jetzt: float, schwelle: int = 180) -> list:
    """CPU-/Temperaturverlauf des Dashboards (ts, temp, cpu, alle 60 s; gesichert alle 5 min) -> Lücken über `schwelle` s in den letzten 24 h
    [(von, bis, Sekunden)], die längste zuerst; eine Lücke bis jetzt zählt mit."""
    ts = sorted(int(e[0]) for e in eintraege if isinstance(e, (list, tuple)) and e and e[0] and e[0] >= jetzt - 86_400)
    luecken = [(a, b, b - a) for a, b in zip(ts, ts[1:]) if b - a > schwelle]
    if ts and jetzt - ts[-1] > schwelle:
        luecken.append((ts[-1], int(jetzt), int(jetzt) - ts[-1]))
    return sorted(luecken, key=lambda x: -x[2])


def gedrosselt(wert: str) -> list:
    """vcgencmd get_throttled (throttled=0x50005) -> Liste der gesetzten Merkmale."""
    m = re.search(r"0x([0-9a-fA-F]+)", wert or "")
    if not m:
        return ["nicht lesbar"]
    v = int(m.group(1), 16)
    return [t for b, t in GEDROSSELT.items() if v & (1 << b)]


def _unit_datei(U: Umgebung, unit: str, schluessel: str = "StandardOutput") -> str | None:
    _rc, t = U.befehl(["systemctl", "cat", unit], timeout=15)
    m = re.search(rf"^{schluessel}=(?:append:|file:|truncate:)?(\S+)", t or "", re.M)
    return m.group(1) if m else None


# --------------------------------------------------------------------------------------------- Bericht
def bericht(U: Umgebung, db: str | None = None) -> dict:
    jetzt = U.jetzt(); boot = U.boot(); befund = []
    w(f"SYSTEM: letzter Neustart und Ausfälle -- {datetime.fromtimestamp(jetzt):%d.%m.%Y %H:%M:%S} (Ortszeit des Pi)")
    w(f"   Pi gestartet {_zeit(boot, True)} (läuft seit {_dauer(jetzt - boot) if boot else '?'})")
    befund.append(f"Pi läuft seit {_zeit(boot)} ({_dauer(jetzt - boot) if boot else '?'})")

    w(); w("== Dienste jetzt")
    for u in DIENSTE:
        _rc, t = U.befehl(["systemctl", "show", u, "-p", "ActiveState", "-p", "SubState", "-p", "NRestarts", "-p", "ExecMainStartTimestamp",
                           "-p", "MemoryCurrent", "-p", "Result", "--no-pager"], timeout=15)
        e = dict(z.split("=", 1) for z in (t or "").splitlines() if "=" in z)
        mem = e.get("MemoryCurrent", "")
        w(f"   {u:<14} {e.get('ActiveState', '?')}/{e.get('SubState', '?')}, seit {e.get('ExecMainStartTimestamp') or '—'}, Neustarts "
          f"{e.get('NRestarts', '?')}, Ergebnis {e.get('Result', '?')}" + (f", Speicher {int(mem) / 2 ** 20:.0f} MB" if mem.isdigit() else ""))

    w(); w("== Starts im Journal")
    starts = starts_lesen(journal(U, ["--list-boots"]))
    for i, bid, rest in starts[-5:]:
        w(f"   {i:>3}  {rest}")
    dauerhaft = any(i < 0 for i, _b, _r in starts)
    if not starts:
        w("   keine Liste (journalctl nicht lesbar)")
    elif not dauerhaft:
        w("   Nur der jetzige Start ist gespeichert: Das Journal ist nicht dauerhaft (/var/log/journal fehlt) -- was vor dem Neustart geschah, steht "
          "nur noch im Wächter-Log, im CPU-Verlauf und in den Logdateien der Dienste (unten).")
    befund.append(f"Journal dauerhaft: {'ja' if dauerhaft else 'nein'} ({len(starts)} Starts gespeichert)" if starts
                  else "Journal: nicht lesbar (journalctl fehlt oder keine Rechte)")

    if dauerhaft:
        w(); w("== Vor dem letzten Neustart: Dashboard (Meldungen von systemd)")
        sd = journal(U, ["-b", "-1", "-u", "hl-dashboard", "-t", "systemd", "-o", "short-iso"]).splitlines()
        absturz = [z for z in sd if re.search(r"Main process exited|Failed with result|Scheduled restart job|Killed|core-dump", z)]
        for z in sd[-20:]:
            w("   " + z)
        befund.append(f"Dashboard vor dem Neustart: {len(absturz)} Zeilen zu Absturz/Neustart durch systemd"
                      + (f" (zuletzt: {absturz[-1][:120]})" if absturz else ""))
        w(); w("== Vor dem letzten Neustart: Dashboard (letzte 40 Zeilen seiner Ausgabe)")
        for z in journal(U, ["-b", "-1", "-u", "hl-dashboard", "-n", "40", "-o", "short-iso"]).splitlines():
            w("   " + z[:300])
        w(); w("== Vor dem letzten Neustart: Kernel (Speicher, Platte/USB, Strom, Hänger, Temperatur)")
        kern = journal(U, ["-b", "-1", "-k", "-o", "short-iso"]).splitlines()
        n, treffer = kern_zaehlen(kern)
        for z in treffer[-25:]:
            w("   " + z[:300])
        if not treffer:
            w("   keine solche Zeile")
        befund.append("Kernel vor dem Neustart: " + ", ".join(f"{a} {k}" for a, k in n.items()))
        w(); w("== Vor dem letzten Neustart: die letzten 25 Zeilen des Journals")
        ende = journal(U, ["-b", "-1", "-n", "25", "-o", "short-iso"]).splitlines()
        for z in ende:
            w("   " + z[:300])
        sauber = sauber_beendet(ende)
        befund.append("Voriger Start endete " + ("sauber (Herunterfahren im Journal)" if sauber else
                                                 "ABRUPT -- kein Herunterfahren im Journal (Strom weg, Hänger oder Taster lang gedrückt)"))

    w(); w("== Wächter-Log (Prüfung alle 5 min)")
    wlog = _unit_datei(U, "hl-watchdog")
    text = U.lesen(wlog, 3_000_000) if wlog else None
    if not text:
        w(f"   nicht gefunden ({wlog or 'Pfad nicht in der Unit'})")
    else:
        bl = wache_bloecke(text)
        schlecht = [b for b in bl if b[0] >= jetzt - 86_400 and b[1] != "ok"]
        w(f"   {wlog}: {len(bl)} Prüfungen gelesen, in den letzten 24 h {len(schlecht)} nicht ok")
        for ts, st, z in schlecht[-30:]:
            w(f"   {_zeit(ts)} {st}: " + " · ".join(" ".join(x.split()) for x in z)[:300])
        dash = [b for b in bl if b[0] >= jetzt - 86_400 and any("hl-dashboard" in x for x in b[2])]
        befund.append("Wächter: hl-dashboard " + (f"nicht aktiv gemeldet {_zeit(dash[0][0])} bis {_zeit(dash[-1][0])} ({len(dash)} Prüfungen)" if dash
                                                  else "nie als nicht aktiv gemeldet (Prozess lief -- also eher hängend als abgestürzt, oder Wächter selbst stand)"))
        if boot:
            vor = [b for b in bl if b[0] < boot][-3:]
            if vor:
                w(f"   Die letzten Prüfungen vor dem Neustart ({_zeit(boot)}):")
                for ts, st, z in vor:
                    w(f"   {_zeit(ts, True)} {st}" + (": " + " · ".join(" ".join(x.split()) for x in z)[:300] if z else ""))
                luecke = boot - vor[-1][0]
                if luecke > 900:
                    w(f"   Danach {_dauer(luecke)} keine Prüfung bis zum Neustart -- der Wächter lief in dieser Zeit nicht (Pi hing oder stand).")
                    befund.append(f"Wächter: letzte Prüfung {_zeit(vor[-1][0])}, danach {_dauer(luecke)} nichts bis zum Neustart (Pi hing oder stand)")

    w(); w("== CPU- und Temperaturverlauf des Dashboards (je Minute, gesichert alle 5 min)")
    kand = [os.path.join(os.path.dirname(os.path.abspath(db)), "sys_history.json")] if db else []
    kand.append(os.path.join(HIER if U.root == HIER else U.root, "updates", "sys_history.json"))
    verlauf, quelle = None, None
    for k in kand:
        t = U.lesen(k)
        if t:
            try:
                verlauf, quelle = json.loads(t), k
                break
            except ValueError:
                continue
    if not verlauf:
        w("   kein Verlauf gefunden (" + ", ".join(kand) + ")")
    else:
        lu = verlauf_luecken(verlauf, jetzt)
        w(f"   {quelle}: {len(verlauf)} Werte; Lücken über 3 min in den letzten 24 h: {len(lu)}")
        for a, b, s in lu[:5]:
            w(f"   Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(s)})")
        mit_mem = [e for e in verlauf if len(e) >= 5 and e[0] >= jetzt - 86_400]
        if mit_mem:                                                          # seit 23.77: frei nutzbar und RSS des Dashboards (MB)
            fr = [e for e in mit_mem if e[3] is not None]; rs = [e for e in mit_mem if e[4] is not None]
            if fr and rs:
                emin = min(fr, key=lambda e: e[3]); emax = max(rs, key=lambda e: e[4])
                w(f"   Arbeitsspeicher in 24 h: frei nutzbar zuletzt {fr[-1][3]} MB, am wenigsten {emin[3]} MB ({_zeit(emin[0])}); Dashboard "
                  f"zuletzt {rs[-1][4]} MB, am meisten {emax[4]} MB ({_zeit(emax[0])})")
                befund.append(f"Speicher im Verlauf: frei am wenigsten {emin[3]} MB ({_zeit(emin[0])}), Dashboard am meisten {emax[4]} MB")
        if lu:
            a = lu[0][0]
            vorher = [e for e in verlauf if a - 900 <= e[0] <= a]
            w("   Die letzten Werte vor der längsten Lücke (Zeit, CPU %, Temperatur, frei, Dashboard): "
              + " · ".join(f"{_zeit(e[0])} {e[2] if e[2] is not None else '—'} % {e[1] if e[1] is not None else '—'} °C"
                           + (f" frei {e[3]} MB, Dashboard {e[4]} MB" if len(e) >= 5 else "") for e in vorher[-10:]))
            befund.append(f"CPU-Verlauf: längste Lücke {_zeit(lu[0][0])} bis {_zeit(lu[0][1])} ({_dauer(lu[0][2])}; bis zu 5 min davor können "
                          "fehlen, weil nur alle 5 min gesichert wird)")
        w("   Eine Lücke heißt: Das Dashboard hat in der Zeit keinen Wert gemessen -- es stand, hing oder der Pi war aus.")

    w(); w("== Berichte und Debug-Läufe der letzten 24 h (was lief)")
    ber = [(f, t, g) for f, t, g in U.dateien(os.path.join(U.root, "berichte")) if BER_NAME.match(f) and t >= jetzt - 86_400]
    for f, t, g in sorted(ber, key=lambda x: x[1])[-25:]:
        w(f"   {_zeit(t)}  {g / 1024:7.0f} kB  {f}")
    if not ber:
        w("   keine")
    lauf = U.lesen(os.path.join(U.root, "updates", "rueckblick_lauf.json"))
    if lauf:
        try:
            lj = json.loads(lauf)
            w(f"   Rückblick im Hintergrund: gestartet {_zeit(lj.get('start'))} ({lj.get('einheit') or 'PID ' + str(lj.get('pid'))})")
        except ValueError:
            pass

    w(); w("== Speicher, Platte, Strom, Last jetzt")
    mi = U.lesen("/proc/meminfo") or ""
    kb = {k: int(v) for k, v in re.findall(r"^(\w+):\s+(\d+) kB", mi, re.M)}
    if kb:
        w(f"   Arbeitsspeicher {kb.get('MemTotal', 0) / 2 ** 20:.1f} GB, frei nutzbar {kb.get('MemAvailable', 0) / 2 ** 20:.1f} GB; Auslagerung "
          f"{(kb.get('SwapTotal', 0) - kb.get('SwapFree', 0)) / 2 ** 20:.2f} von {kb.get('SwapTotal', 0) / 2 ** 20:.2f} GB belegt")
    w(f"   Last (1/5/15 min): {(U.lesen('/proc/loadavg') or '?').split(' ')[:3]}")
    for pfad in ["/"] + ([os.path.dirname(os.path.abspath(db))] if db else []):
        _rc, t = U.befehl(["df", "-h", pfad], timeout=15)
        zz = (t or "").strip().splitlines()
        w(f"   Platte {pfad}: {' '.join(zz[-1].split()) if zz else '?'}")
    _rc, t = U.befehl(["vcgencmd", "get_throttled"], timeout=10)
    merk = gedrosselt(t)
    w(f"   Strom und Takt (vcgencmd get_throttled): {(t or '').strip()} -> {', '.join(merk) if merk else 'nichts auffällig'}")
    if any("Unterspannung" in m for m in merk):
        befund.append("STROM: Unterspannung " + ("jetzt" if "Unterspannung jetzt" in merk else "seit dem Start") + " -- Netzteil oder USB-Platte prüfen")
    _rc, t = U.befehl(["vcgencmd", "measure_temp"], timeout=10)
    w(f"   Temperatur: {(t or '?').strip()}")

    w(); w("== Prozesse nach Arbeitsspeicher")
    _rc, t = U.befehl(["ps", "-eo", "pid,etimes,rss,pcpu,args", "--sort=-rss"], timeout=15)
    for z in (t or "").splitlines()[:13]:
        teile = z.split(None, 4)
        if len(teile) == 5 and teile[0].isdigit():
            prog = " ".join(os.path.basename(x) if "/" in x else x for x in teile[4].split()[:4])
            w(f"   PID {teile[0]:>7}  seit {_dauer(int(teile[1])):>11}  {int(teile[2]) / 1024:7.0f} MB  CPU {teile[3]:>5} %  {prog[:110]}")

    w(); w("== Update und Notbremse")
    t = U.lesen(os.path.join(U.root, "updates", "last_update.log"), 20_000)
    if t:
        w("   Update-Log (letzte Zeilen):")
        for z in t.strip().splitlines()[-8:]:
            w("   | " + z[:200])
    vor = sorted((f, tt) for f, tt, _g in U.dateien(os.path.join(U.root, "updates")) if f.startswith("vor_"))
    if vor:
        w("   Sicherungen vor Updates: " + ", ".join(f"{f} ({_zeit(tt)})" for f, tt in vor[-2:]))
    nlog = _unit_datei(U, "hl-notbremse")
    t = U.lesen(nlog, 20_000) if nlog else None
    if t:
        w(f"   Notbremse-Log {nlog} (letzte Zeilen):")
        for z in t.strip().splitlines()[-12:]:
            w("   | " + z[:200])

    w(); w("== BEFUND (kurz)")
    for b in befund:
        w("   - " + b)
    w(); w("ENDE -- bitte vollständig einfügen")
    return {"befund": befund}


# ============================================================================================= Selbsttest
class _ProbeUmgebung(Umgebung):
    """Erfundene Umgebung: Befehle aus einer Tabelle, Dateien aus einem Wörterbuch."""
    def __init__(self, befehle: dict, dateien: dict, jetzt: float, boot: int, pw: str | None = "probe-pw", ordner: dict | None = None):
        super().__init__("/probe")
        self.tab = befehle; self.files = dateien; self.t = jetzt; self.b = boot; self.pw = pw; self.ordner = ordner or {}; self.aufrufe = []

    def sudo_pw(self):
        return self.pw

    def befehl(self, args, timeout=30, sudo=False):
        args = list(args); self.aufrufe.append((args, sudo))
        for (muster, mit_sudo), antwort in self.tab.items():
            if mit_sudo == sudo and all(m in args for m in muster):
                return antwort
        return 1, ""

    def lesen(self, pfad, max_bytes=None):
        return self.files.get(pfad)

    def jetzt(self):
        return self.t

    def boot(self):
        return self.b

    def dateien(self, ordner):
        return self.ordner.get(ordner, [])


def selbsttest(verbose: bool = True) -> bool:
    import contextlib
    import io
    pruef = []

    def ok(name, bed, text=""):
        pruef.append(bool(bed))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    t0 = time.time()
    if verbose:
        print("check_system -- Selbsttest (erfundene Eingaben, ohne systemd)", flush=True)
    jetzt = int(datetime(2026, 10, 23, 14, 40).timestamp()); boot = int(datetime(2026, 10, 23, 14, 25).timestamp())
    # Wächter-Log: ok, dann KRITISCH (Dashboard nicht aktiv), dann eine Stunde nichts bis zum Neustart
    log = []
    for k, (st, zeilen) in enumerate((("ok", []), ("KRITISCH", ["  XXX  Dienste          hl-dashboard (activating)"]),
                                      ("WARNUNG", ["  !    Speicherplatz    noch 8 %"]), ("ok", []))):
        ts = boot - 3 * 3600 + k * 300
        log += ["", f"{datetime.fromtimestamp(ts):%Y-%m-%d %H:%M:%S} — Gesamtstatus: {st}", "-" * 62, "  ok   Verbindung      Info 120 ms"] + zeilen
    bl = wache_bloecke("\n".join(log))
    ok("Wächter-Log: Prüfungen und Meldungen ≠ ok erkannt", len(bl) == 4 and bl[1][1] == "KRITISCH" and "hl-dashboard" in bl[1][2][0]
       and bl[2][2] == ["!    Speicherplatz    noch 8 %"] and bl[3][2] == [], f"{[(b[1], len(b[2])) for b in bl]}")
    # Verlauf: jede Minute, Lücke von 47 min, letzte Werte vor 2 min
    v = ([[t, 55.0, 30, 2400 - (t - jetzt + 6 * 3600) // 60 * 10, 700 + (t - jetzt + 6 * 3600) // 60 * 10] for t in range(jetzt - 6 * 3600, jetzt - 3 * 3600, 60)]
         + [[t, 50.0, 12, 5200, 650] for t in range(jetzt - 3 * 3600 + 47 * 60, jetzt - 60, 60)])
    lu = verlauf_luecken(v, jetzt)
    ok("Verlauf: längste Lücke mit Zeit und Dauer; Lücke bis jetzt zählt mit", len(lu) == 1 and lu[0][2] == 48 * 60
       and verlauf_luecken(v[:100], jetzt)[0][1] == jetzt, f"{[(_zeit(a), _zeit(b), _dauer(s)) for a, b, s in lu]}")
    ok("Strom: get_throttled entschlüsselt", gedrosselt("throttled=0x50005") == ["Unterspannung jetzt", "gedrosselt jetzt", "Unterspannung seit dem Start",
                                                                                 "gedrosselt seit dem Start"]
       and gedrosselt("throttled=0x0") == [] and gedrosselt("vcgencmd: nicht vorhanden") == ["nicht lesbar"], f"{gedrosselt('throttled=0x50005')}")
    lb_kopf = ("IDX BOOT ID                          FIRST ENTRY                 LAST ENTRY\n"
               " -1 0123456789abcdef0123456789abcdef Thu 2026-10-22 09:00:01 CEST Fri 2026-10-23 13:02:11 CEST\n"
               "  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST Fri 2026-10-23 14:40:00 CEST")
    st = starts_lesen(lb_kopf); st2 = starts_lesen("  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST—Fri 2026-10-23 14:40:00 CEST")
    ok("Journal: Liste der Starts (mit und ohne Kopfzeile)", [s[0] for s in st] == [-1, 0] and len(st2) == 1 and st2[0][0] == 0,
       f"{[(s[0], s[2][:24]) for s in st]}")
    n, tr = kern_zaehlen(["[  1.0] usb 1-1: USB disconnect, device number 2", "Out of memory: Killed process 1234 (python3)",
                          "hwmon hwmon1: Undervoltage detected!", "INFO: task python3:999 blocked for more than 120 seconds.", "eth0: Link is Up"])
    ok("Kernel: Zeilen je Art gezählt (Speicher, Platte/USB, Strom, Hänger), harmlose nicht", n["Speicher"] == 1 and n["Platte/USB"] == 1
       and n["Strom"] == 1 and n["Hänger"] == 1 and len(tr) == 4, f"{n}")
    ok("Ende des vorigen Starts: sauber gegen abrupt", sauber_beendet(["Oct 23 13:02 systemd-shutdown[1]: Syncing filesystems and block devices."])
       and sauber_beendet(["Reached target System Power Off."]) and not sauber_beendet(["Oct 23 13:02 hl_viz.py[812]: TradeLabor-Takt: 13.0 s"]),
       "systemd-shutdown/Power Off = sauber, sonst abrupt")
    # Journal: ohne Rechte Hinweis → einmal mit sudo; Passwort nie in den Argumenten
    U = _ProbeUmgebung({(("--list-boots",), False): (0, "Hint: You are currently not seeing messages from other users and the system.\n"
                                                        "      Users in groups 'adm', 'systemd-journal' can see all messages.\n" + lb_kopf.splitlines()[2]),
                        (("--list-boots",), True): (0, lb_kopf)}, {}, jetzt, boot)
    t = journal(U, ["--list-boots"])
    ok("Journal: ohne Leserechte einmal mit sudo (Passwort nur über stdin)", len(starts_lesen(t)) == 2 and U.aufrufe[-1][1]
       and "probe-pw" not in " ".join(U.aufrufe[-1][0]) and "Hint" not in t, f"{len(U.aufrufe)} Aufrufe, zuletzt sudo {U.aufrufe[-1][1]}")
    # Ende zu Ende auf erfundener Umgebung
    wlog = "/var/log/hl/watchdog.log"
    befehle = {(("systemctl", "cat", "hl-watchdog"), False): (0, f"[Service]\nStandardOutput=append:{wlog}\n"),
               (("systemctl", "show", "hl-dashboard"), False): (0, "ActiveState=active\nSubState=running\nNRestarts=0\nMemoryCurrent=734003200\n"),
               (("--list-boots",), False): (0, lb_kopf),
               (("-b", "-1", "-u", "hl-dashboard", "-t", "systemd"), False): (0, "2026-10-23T12:10:02+0200 systemd[1]: hl-dashboard.service: Main process exited, "
                                                                               "code=killed, status=9/KILL\n2026-10-23T12:10:22+0200 systemd[1]: "
                                                                               "hl-dashboard.service: Scheduled restart job, restart counter is at 1."),
               (("-b", "-1", "-k"), False): (0, "2026-10-23T12:10:01+0200 kernel: Out of memory: Killed process 812 (python3) total-vm:3123456kB"),
               (("-b", "-1", "-n", "25"), False): (0, "2026-10-23T13:02:11+0200 hl_viz.py[901]: TradeLabor-Takt: 12.1 s"),
               (("vcgencmd", "get_throttled"), False): (0, "throttled=0x50000\n"),
               (("df", "-h"), False): (0, "Filesystem Size Used Avail Use% Mounted on\n/dev/sda1 916G 402G 468G 47% /media/seed/marketdatabase\n")}
    dateien = {wlog: "\n".join(log), "/m/sys_history.json": json.dumps(v), "/proc/meminfo": "MemTotal:  8000000 kB\nMemAvailable: 5000000 kB\n"}
    U2 = _ProbeUmgebung(befehle, dateien, jetzt, boot, ordner={"/probe/berichte": [("2026-10-23_11-58_notbremse_rueckblick_manuell.txt", jetzt - 9000, 4096)]})
    puffer = io.StringIO()
    with contextlib.redirect_stdout(puffer):
        erg = bericht(U2, "/m/hl_liq.db")
    text = puffer.getvalue(); bf = " | ".join(erg["befund"])
    ok("Bericht Ende zu Ende: Befund mit Journal, Absturz durch systemd, Kernel (Speicher), abruptem Ende, Wächter, Lücke, Strom, Berichten",
       "Journal dauerhaft: ja" in bf and "2 Zeilen zu Absturz" in bf and "Speicher 1" in bf and "ABRUPT" in bf and "nicht aktiv gemeldet" in bf
       and "längste Lücke" in bf and "Unterspannung seit dem Start" in bf and "notbremse_rueckblick_manuell" in text and "ENDE" in text
       and "frei am wenigsten 610 MB" in bf and "Dashboard am meisten 2490 MB" in bf and "frei 610 MB, Dashboard 2490 MB" in text,
       bf[:400])
    alles = all(pruef) and bool(pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(pruef)} von {len(pruef)}, {time.time() - t0:.1f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", default=None, help="Hauptdatenbank (für Platte und Verlauf neben der Datenbank)")
    p.add_argument("--selbsttest", action="store_true", help="Proben auf erfundenen Eingaben")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    bericht(Umgebung(), a.db)


if __name__ == "__main__":
    main()
