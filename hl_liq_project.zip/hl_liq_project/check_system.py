#!/usr/bin/env python3
"""
check_system.py -- Systemdiagnose ohne SSH (23.77): Warum war das Dashboard nicht erreichbar, was lief vor dem letzten Neustart?

  python3 check_system.py [--db hl_liq.db]     Bericht (liest nur)
  python3 check_system.py --selbsttest         Proben auf erfundenen Eingaben (ohne systemd)

Anlass: Am 23.10. war die Weboberfläche nicht erreichbar (Ping ging, Port 8765 nicht); SSH ist auf dem Pi aus, ein Bildschirm hängt nicht
dran. Nach dem Neustart über den Taster lief alles wieder -- die Ursache ist nur noch in den Protokollen zu finden. Dieses Werkzeug läuft
aus der Debug-Konsole und sammelt sie:
  Befund (kurz) · Laufzeit und Dienste · Starts im Journal · vor dem letzten Neustart: Dashboard (Abstürze, letzte Zeilen), Kernel
  (Speicher, Platte/USB, Strom, Hänger), die letzten Zeilen des vorigen Starts (sauber heruntergefahren oder abrupt) · Wächter-Log (Meldungen
  der letzten 24 h, die Prüfungen vor dem Neustart) · CPU- und Temperaturverlauf des Dashboards (Lücken: Dashboard stand oder hing) ·
  Berichte der letzten 24 h (was lief) · Speicher, Platte, Strom, Prozesse jetzt · Update- und Notbremse-Log.
Das Journal des vorigen Starts gibt es nur, wenn journald dauerhaft speichert (/var/log/journal); sonst steht das im Bericht. Lesen darf
es die Gruppe adm (Standardnutzer des Pi); sonst einmal mit sudo (Passwort aus sudo.txt wie beim Update, nur über stdin).

23.78 (U215–U217), nach dem Ausfall vom 23.10. (Dashboard hing knapp 5 h, Ursache offen):
  * Hänger-Abzüge (logs/dashboard_haenger.log: Stapel aller Fäden nach 5 min ohne Antwort und beim SIGABRT von systemd) und die Ausgabe des
    Dashboards (logs/dashboard.log, mit Zeitstempel) -- beides schreibt das Dashboard seit 23.78 selbst.
  * Lücken des Dashboards über 7 Tage aus den Prognosen (alle 15 min je Coin) und über 24 h aus dem Systemverlauf; um die längste Lücke
    (oder --fenster VON BIS): alle Wächter-Prüfungen mit Abständen (Verzögerung = Pi überlastet), Recorder-Meldungen (z. B. Backup) und die
    Lebenszeichen der Dashboard-Teile in den Datenbanken (Prognose, TradeLabor, Welt A, Ausblick, Makro, Aktien, Seite im Browser) gegen
    Recorder und Notbremse-Dienst als eigene Dienste -- stand das ganze Dashboard oder nur ein Teil?
  * --journal-dauerhaft an|aus: Systemprotokoll dauerhaft (höchstens 200 MB) -- nur auf Klick des Nutzers in der Debug-Konsole.

  python3 check_system.py --db hl_liq.db --fenster 2026-10-23T09:31 2026-10-23T14:28     Fenster von Hand
  python3 check_system.py --journal-dauerhaft an|aus                                       braucht sudo.txt
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timedelta

HIER = os.path.dirname(os.path.abspath(__file__))
DIENSTE = ("hl-dashboard", "hl-recorder", "hl-notbremse", "hl-binance", "hl-coinbase", "hl-watchdog")
# Kernel-Zeilen, die einen Ausfall erklären können -- je Art gezählt
KERN_ARTEN = (("Speicher", re.compile(r"out of memory|oom[-_ ]?kill|killed process|oom_reaper", re.I)),
              ("Platte/USB", re.compile(r"i/o error|blk_update_request|buffer i/o|ext4-fs error|usb \S+: usb disconnect|"
                                        r"reset (high|super|full)[- ]?speed usb|uas_eh|sd \S+: \[sd\w\] .*(error|fail)", re.I)),
              ("Strom", re.compile(r"under-?voltage|voltage normali[sz]ed|hwmon.*in0_lcrit", re.I)),
              ("Hänger", re.compile(r"hung_task|blocked for more than|soft lockup|hard lockup|rcu.*stall", re.I)),
              ("Temperatur", re.compile(r"thermal|temperature above|cpu clock throttled", re.I)))
WACHE_KOPF = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) — Gesamtstatus: (\S+)")
BER_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}_[a-z0-9_]+\.txt$")
SAUBER = re.compile(r"systemd-shutdown|Reached target .*(Power[- ]?Off|Reboot|Shutdown|Halt)|System is (powering down|rebooting)|"
                    r"Stopped target .*Multi-User|Journal stopped", re.I)
GEDROSSELT = {0: "Unterspannung jetzt", 1: "Takt gedeckelt jetzt", 2: "gedrosselt jetzt", 3: "Temperaturgrenze jetzt",
              16: "Unterspannung seit dem Start", 17: "Takt gedeckelt seit dem Start", 18: "gedrosselt seit dem Start",
              19: "Temperaturgrenze seit dem Start"}
# 23.78: Lebenszeichen in den Datenbanken -- (Name, Datei neben der Hauptdatenbank, Tabelle, Zeitspalte = Schreibzeit, Teil des Dashboards?,
# Bedingung). 23.79: Das TradeLabor schreibt bei Füllungen, Ausstiegen und Grid die Zeit der KERZE, nicht die Zeit des Schreibens, und spielt
# nach einem Neustart die verpassten Kerzen nach (hl_labor._grid_kerzen, Prüfung der Positionen über Kerzen) -- solche Einträge mit Zeit in
# einer Lücke sind kein Lebenszeichen (Bericht vom 23.10. 18:58 sagte deshalb fälschlich „nur Teile standen“). Lebenszeichen sind nur die
# Arten, die immer mit der Zeit des Takts geschrieben werden (now): Limit gesetzt, Storno, Stop nachgezogen, Verfall, Kaskade.
LABOR_TAKT_ARTEN = ("limit", "storno", "stop", "verfallen", "kaskade")
LABOR_TAKT = "art IN (" + ", ".join(f"'{x}'" for x in LABOR_TAKT_ARTEN) + ")"
LEBENSZEICHEN = (("Prognose (alle 15 min je Coin)", "forecasts.db", "forecast", "ts", True, None),
                 ("TradeLabor Welt B (zur Takt-Zeit geschrieben)", "forecasts.db", "labor_ereignis", "ts", True, LABOR_TAKT),
                 ("Welt A (zur Takt-Zeit geschrieben, seit 23.76)", "labor_a.db", "labor_ereignis", "ts", True, LABOR_TAKT),
                 ("Ausblick (Prognosen)", "ausblick.db", "au_prognose", "erzeugt", True, None),
                 ("Makro (Abrufe)", "makro.db", "mk_abruf", "ts", True, None),
                 ("Aktien (Abrufe)", "aktien.db", "ak_abruf", "ts", True, None),
                 ("Seite im Browser (Konfluenz; nur bei offener Seite)", "forecasts.db", "konfluenz_log", "ts", True, None),
                 ("zum Vergleich: Recorder (Kurse, eigener Dienst)", None, "bars", "ts", False, None),
                 ("zum Vergleich: Notbremse-Dienst (Zustand, eigener Dienst)", "notbremse.db", "nb_zustand", "ts", False, None))
HAENGER_KOPF = re.compile(r"^== (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (.*)$")
FH_KOPF = re.compile(r"^(Timeout \([\d:.]+\)!|Fatal Python error: .*)$")
FH_FADEN = re.compile(r"^(?:Current thread|Thread) (0x[0-9a-f]+) \(most recent call first\):")
NAMEN_FADEN = re.compile(r"^-- (.+) \(Thread (0x[0-9a-f]+)\)$")
RAHMEN = re.compile(r'^\s+File "([^"]+)", line (\d+),? in (\S+)')
LOG_ZEIT = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) ")
REC_ZEIT = re.compile(r"^\[(\d{2}):(\d{2}):(\d{2})\]")
# Abstand zweier Wächter-Prüfungen, ab dem der Pi selbst als überlastet gilt: Takt 300 s + Prüfdauer (sonst ~2 s; Dashboard hängt: bis 35 s,
# Internet weg: bis ~30 s) -- erst darüber ist es Überlast
WACHE_SPAET_S = 420
JOURNAL_DROPIN = "/etc/systemd/journald.conf.d/90-hl-dauerhaft.conf"
JOURNAL_INHALT = ("# hl_liq_project 23.78 (U217): Systemprotokoll dauerhaft -- eingeschaltet über die Debug-Konsole\n"
                  "# („System: Systemprotokoll dauerhaft speichern -- EINSCHALTEN“), dort auch wieder auszuschalten.\n"
                  "# 90-…: wird nach Voreinstellungen gelesen (etwa einer, die das Protokoll flüchtig hält) und gilt damit.\n"
                  "[Journal]\nStorage=persistent\nSystemMaxUse=200M\nSystemKeepFree=2G\n")


def w(text: str = "") -> None:
    print(text, flush=True)


def _zeit(ts, sek: bool = False) -> str:
    return datetime.fromtimestamp(int(ts)).strftime("%d.%m. %H:%M:%S" if sek else "%d.%m. %H:%M") if ts else "—"


def _dauer(s: float) -> str:
    s = int(s)
    return f"{s // 86_400} d {s % 86_400 // 3600} h" if s >= 86_400 else (f"{s // 3600} h {s % 3600 // 60} min" if s >= 3600 else f"{s // 60} min")


class Umgebung:
    """Befehle, Dateien, Zeit -- in den Proben ersetzt."""
    def __init__(self, root: str = HIER):
        self.root = root

    def sudo_pw(self) -> str | None:
        f = os.path.join(self.root, "sudo.txt")
        try:
            if os.stat(f).st_mode & 0o077:
                return None
            with open(f, errors="replace") as fh:
                return fh.read().strip() or None
        except OSError:
            return None

    def befehl(self, args, timeout: int = 30, sudo: bool = False) -> tuple:
        args = list(args)
        try:
            if sudo:
                pw = self.sudo_pw()
                if not pw:
                    return 1, "kein sudo-Passwort (sudo.txt)"
                r = subprocess.run(["sudo", "-S", "-p", ""] + args, input=pw + "\n", capture_output=True, text=True, timeout=timeout)
            else:
                r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
            return r.returncode, (r.stdout or "") + (r.stderr or "")
        except FileNotFoundError:
            return 127, f"{args[0]}: nicht vorhanden"
        except subprocess.TimeoutExpired:
            return 124, f"{args[0]}: keine Antwort in {timeout} s"
        except OSError as e:
            return 1, f"{args[0]}: {e}"

    def lesen(self, pfad: str, max_bytes: int | None = None) -> str | None:
        try:
            with open(pfad, "rb") as f:
                if max_bytes:
                    f.seek(0, 2)
                    f.seek(max(0, f.tell() - max_bytes))
                return f.read().decode("utf-8", errors="replace")
        except OSError:
            return None

    def jetzt(self) -> float:
        return time.time()

    def boot(self) -> int | None:
        t = self.lesen("/proc/stat") or ""
        m = re.search(r"^btime (\d+)", t, re.M)
        return int(m.group(1)) if m else None

    def dateien(self, ordner: str) -> list:
        try:
            return [(f, os.path.getmtime(os.path.join(ordner, f)), os.path.getsize(os.path.join(ordner, f))) for f in os.listdir(ordner)]
        except OSError:
            return []

    def schreiben(self, pfad: str, text: str) -> bool:
        try:
            os.makedirs(os.path.dirname(pfad), exist_ok=True)
            with open(pfad, "w", encoding="utf-8") as f:
                f.write(text)
            return True
        except OSError:
            return False

    def entfernen(self, pfad: str) -> None:
        try:
            os.unlink(pfad)
        except OSError:
            pass

    def da(self, pfad: str) -> bool:
        return os.path.exists(pfad)

    def db(self, pfad: str):
        """Nur lesend (mode=ro); None, wenn es die Datei nicht gibt."""
        if not os.path.exists(pfad):
            return None
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=15)
        con.execute("PRAGMA busy_timeout=15000")
        return con


# --------------------------------------------------------------------------------------------- Bausteine (in den Proben einzeln geprüft)
def journal(U: Umgebung, args) -> str:
    """journalctl ohne Seitenumbruch; sieht der Nutzer nur seine eigenen Zeilen (nicht in der Gruppe adm), einmal mit sudo."""
    rc, out = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90)
    eng = "not seeing messages from other users" in out or "insufficient permissions" in out
    if (eng or rc not in (0, 1)) and U.sudo_pw():
        rc2, out2 = U.befehl(["journalctl", "--no-pager"] + list(args), timeout=90, sudo=True)
        if rc2 == 0:
            out = out2
    return "\n".join(z for z in out.splitlines() if not z.startswith("Hint:") and "Users in groups" not in z and "pass -q to" not in z)


def starts_lesen(text: str) -> list:
    """journalctl --list-boots -> [(Index, Boot-ID, Rest)] (mit oder ohne Kopfzeile)."""
    out = []
    for z in text.splitlines():
        m = re.match(r"^\s*(-?\d+)\s+([0-9a-f]{32})\s+(.*)$", z)
        if m:
            out.append((int(m.group(1)), m.group(2), m.group(3).strip()))
    return out


def kern_zaehlen(zeilen: list) -> tuple:
    """Kernel-Zeilen je Art. -> ({Art: Anzahl}, [passende Zeilen])"""
    n = {a: 0 for a, _ in KERN_ARTEN}; treffer = []
    for z in zeilen:
        for a, rx in KERN_ARTEN:
            if rx.search(z):
                n[a] += 1; treffer.append(z)
                break
    return n, treffer


def sauber_beendet(zeilen: list) -> bool:
    """Ende des vorigen Starts: Herunterfahren im Journal (sauber) oder nicht (abrupt: Strom, Hänger, Taster lang gedrückt)."""
    return any(SAUBER.search(z) for z in zeilen)


def wache_bloecke(text: str) -> list:
    """Wächter-Log -> [(ts, Status, [Zeilen ≠ ok])]."""
    out = []
    for z in text.splitlines():
        m = WACHE_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            out.append([ts, m.group(2), []])
        elif out and (z.startswith("  !    ") or z.startswith("  XXX  ")):
            out[-1][2].append(z.strip())
    return [tuple(b) for b in out]


def verlauf_luecken(eintraege: list, jetzt: float, schwelle: int = 180) -> list:
    """CPU-/Temperaturverlauf des Dashboards (ts, temp, cpu, alle 60 s; gesichert alle 5 min) -> Lücken über `schwelle` s in den letzten 24 h
    [(von, bis, Sekunden)], die längste zuerst; eine Lücke bis jetzt zählt mit."""
    ts = sorted(int(e[0]) for e in eintraege if isinstance(e, (list, tuple)) and e and e[0] and e[0] >= jetzt - 86_400)
    luecken = [(a, b, b - a) for a, b in zip(ts, ts[1:]) if b - a > schwelle]
    if ts and jetzt - ts[-1] > schwelle:
        luecken.append((ts[-1], int(jetzt), int(jetzt) - ts[-1]))
    return sorted(luecken, key=lambda x: -x[2])


def gedrosselt(wert: str) -> list:
    """vcgencmd get_throttled (throttled=0x50005) -> Liste der gesetzten Merkmale."""
    m = re.search(r"0x([0-9a-fA-F]+)", wert or "")
    if not m:
        return ["nicht lesbar"]
    v = int(m.group(1), 16)
    return [t for b, t in GEDROSSELT.items() if v & (1 << b)]


def _unit_datei(U: Umgebung, unit: str, schluessel: str = "StandardOutput") -> str | None:
    _rc, t = U.befehl(["systemctl", "cat", unit], timeout=15)
    m = re.search(rf"^{schluessel}=(?:append:|file:|truncate:)?(\S+)", t or "", re.M)
    return m.group(1) if m else None


# --------------------------------------------------------------------------------------------- 23.78: Hänger, Lücken, Lebenszeichen
def haenger_lesen(text: str) -> list:
    """logs/dashboard_haenger.log -> Einträge {art: start|abzug|timeout|fatal, ts (None bei faulthandler), titel, faeden: [[Kennung, [(Datei,
    Zeile, Funktion), …] neueste zuerst]]}. faulthandler schreibt ohne Zeit und neueste Zeile zuerst; die Abzüge mit Namen (Faden
    „lebenszeichen“) mit Zeit und neueste Zeile zuletzt -- hier vereinheitlicht."""
    out: list = []
    akt = None
    faden = None
    for z in text.splitlines():
        m = HAENGER_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            akt = {"art": "start" if m.group(2).startswith("Dashboard-Start") else "abzug", "ts": ts, "titel": m.group(2).strip(), "faeden": []}
            out.append(akt); faden = None
            continue
        if FH_KOPF.match(z):
            akt = {"art": "timeout" if z.startswith("Timeout") else "fatal", "ts": None, "titel": z.strip(), "faeden": []}
            out.append(akt); faden = None
            continue
        if akt is None:
            continue
        m = FH_FADEN.match(z) or NAMEN_FADEN.match(z)
        if m:
            kennung = m.group(1) if m.re is FH_FADEN else f"{m.group(1)} {m.group(2)}"
            faden = [kennung, []]; akt["faeden"].append(faden)
            continue
        m = RAHMEN.match(z)
        if m and faden is not None:
            faden[1].append((m.group(1), int(m.group(2)), m.group(3)))
    for e in out:
        if e["art"] == "abzug":
            for f in e["faeden"]:
                f[1].reverse()
    return out


def _stelle(rahmen: list) -> str:
    """Wo steht ein Faden? Die neueste Stelle im Projekt (hl_*.py, check_*.py) und, falls anders, die neueste überhaupt."""
    if not rahmen:
        return "?"
    eigen = next((r for r in rahmen if re.match(r"^(hl_|check_|run_all)", os.path.basename(r[0]))), None)
    oben = rahmen[0]
    t = f"{os.path.basename(oben[0])}:{oben[1]} {oben[2]}"
    if eigen and eigen != oben:
        t = f"{os.path.basename(eigen[0])}:{eigen[1]} {eigen[2]} ← darin {t}"
    return t


def log_zeilen(text: str) -> list:
    """dashboard.log (seit 23.78 mit Zeitstempel je Zeile) -> [(ts oder None, Zeile)]."""
    out = []
    for z in text.splitlines():
        m = LOG_ZEIT.match(z)
        ts = None
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                ts = None
        out.append((ts, z))
    return out


def recorder_zeilen(text: str, jetzt: float) -> list:
    """recorder.log hat nur Uhrzeiten („[HH:MM:SS]“, Statuszeile alle 10 min). Das Datum ergibt sich rückwärts vom Ende (jetzt): ist eine
    Uhrzeit rückwärts gelesen später als die folgende, lag Mitternacht dazwischen. Zeilen ohne Zeit gehören zur Zeile davor. -> [(ts, Zeile)]"""
    zeilen = text.splitlines()
    zeiten: list = [None] * len(zeilen)
    tag = datetime.fromtimestamp(jetzt).date()
    jetzt_sek = (datetime.fromtimestamp(jetzt) - datetime.combine(tag, datetime.min.time())).seconds
    folge = None
    for i in range(len(zeilen) - 1, -1, -1):
        m = REC_ZEIT.match(zeilen[i])
        if not m:
            continue
        sek = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
        if (folge is None and sek > jetzt_sek + 300) or (folge is not None and sek > folge + 300):
            tag = tag - timedelta(days=1)
        folge = sek
        zeiten[i] = int(datetime(tag.year, tag.month, tag.day, sek // 3600, sek % 3600 // 60, sek % 60).timestamp())
    out, letzte = [], None
    for i, z in enumerate(zeilen):
        letzte = zeiten[i] if zeiten[i] is not None else letzte
        out.append((letzte, z))
    return out


def wache_bloecke_voll(text: str) -> list:
    """Wächter-Log -> [(ts, Status, [alle Prüfzeilen ohne Einrückung])] -- auch die ok-Zeilen (z. B. Backup)."""
    out = []
    for z in text.splitlines():
        m = WACHE_KOPF.match(z)
        if m:
            try:
                ts = int(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp())
            except ValueError:
                continue
            out.append([ts, m.group(2), []])
        elif out and re.match(r"^  (ok |!  |XXX)  ", z):
            out[-1][2].append(z.strip())
    return [tuple(b) for b in out]


def luecken(zeiten: list, schwelle: int, von: float, bis: float) -> list:
    """Lücken über `schwelle` s zwischen aufeinanderfolgenden Zeiten in [von, bis] (eine Lücke bis `bis` zählt mit), längste zuerst."""
    ts = sorted({int(t) for t in zeiten if t and von <= t <= bis})
    lu = [(a, b, b - a) for a, b in zip(ts, ts[1:]) if b - a > schwelle]
    if ts and bis - ts[-1] > schwelle:
        lu.append((ts[-1], int(bis), int(bis) - ts[-1]))
    return sorted(lu, key=lambda x: -x[2])


def lebenszeichen_zaehlen(con, tab: str, spalte: str, a: int, b: int, rand: int = 0, vorlauf: int = 6 * 3600,
                          bedingung: str | None = None) -> dict | None:
    """Einträge einer Tabelle in der Lücke (a, b): gezählt wird im KERN (a + rand, b − rand) -- die Grenzen einer Lücke sind nur so genau wie
    ihre Quelle (Prognosen alle 15 min: rand 15 min); ein Teil, der bis kurz nach a noch schrieb, zählt so nicht als „lief weiter“.
    Letzter Eintrag bis a + rand, erster ab b − rand; erwartet = Rate der `vorlauf` s vor a × Länge des Kerns.
    Urteil: lief weiter (Einträge im Kern) / stand (≥ 3 erwartet, 0 gefunden) / zu selten für ein Urteil. None: Tabelle fehlt.
    `bedingung` (SQL): nur diese Einträge zählen (23.79: beim TradeLabor nur die zur Takt-Zeit geschriebenen Arten)."""
    k0, k1 = a + rand, b - rand
    und = f" AND ({bedingung})" if bedingung else ""
    try:
        q = lambda sql, *arg: con.execute((sql + und).format(t=tab, s=spalte), arg).fetchone()[0]   # noqa: E731
        vor = q("SELECT MAX({s}) FROM {t} WHERE {s} <= ?", k0)
        n_in = q("SELECT COUNT(*) FROM {t} WHERE {s} > ? AND {s} < ?", k0, k1)
        nach = q("SELECT MIN({s}) FROM {t} WHERE {s} >= ?", k1)
        n_vor = q("SELECT COUNT(*) FROM {t} WHERE {s} >= ? AND {s} < ?", a - vorlauf, a)
    except sqlite3.Error:
        return None
    erwartet = n_vor / vorlauf * max(0, k1 - k0)
    if n_in:
        urteil = "lief weiter"
    elif erwartet >= 3:
        urteil = "stand"
    else:
        urteil = "zu selten für ein Urteil"
    return {"vor": vor, "n_in": int(n_in or 0), "nach": nach, "n_vor": int(n_vor or 0), "erwartet": erwartet, "urteil": urteil}


def nachgeholt_pruefen(con, tab: str, spalte: str, a: int, b: int, bedingung: str) -> dict | None:
    """23.79: TradeLabor-Einträge mit MARKTzeit (Füllungen, Ausstiege, Grid: Zeit der Kerze) in der Lücke (a, b) in Schreibreihenfolge (id).
    Live geschrieben steigt ihre Zeit mit der id (je Takt höchstens Minuten zurück). Nach einem Neustart nachgeholt (je Strategie die Kerzen
    seit dem letzten Stand) springt sie zurück -- von der letzten Kerze einer Strategie zur ersten der nächsten -- und Einträge mit Zeit in der
    Lücke stehen hinter Einträgen, deren Zeit schon nach der Lücke liegt. -> {n, rueck (Rücksprünge über 15 min), hinter, urteil}"""
    try:
        zeilen = con.execute(f"SELECT id, {spalte} FROM {tab} WHERE {spalte} > ? AND {spalte} < ? AND NOT ({bedingung}) ORDER BY id",
                             (a, b)).fetchall()
        erste_nach = con.execute(f"SELECT MIN(id) FROM {tab} WHERE {spalte} >= ?", (b,)).fetchone()[0]
    except sqlite3.Error:
        return None
    rueck = sum(1 for (_i1, t1), (_i2, t2) in zip(zeilen, zeilen[1:]) if t2 < t1 - 900)
    hinter = sum(1 for i, _t in zeilen if erste_nach is not None and i > erste_nach)
    if not zeilen:
        urteil = "keine"
    elif rueck or hinter:
        urteil = "nachgeholt (erst nach der Lücke geschrieben)"
    else:
        urteil = "in Schreibreihenfolge gleichmäßig -- kein Zeichen für Nachholen"
    return {"n": len(zeilen), "rueck": rueck, "hinter": hinter, "urteil": urteil}


def zeit_lesen(text: str) -> int:
    """'2026-10-23T09:31', '2026-10-23 09:31[:SS]' oder '23.10.2026 09:31' (Ortszeit) -> Unix-Zeit."""
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            return int(datetime.strptime(text.strip(), fmt).timestamp())
        except ValueError:
            continue
    raise ValueError(f"Zeit nicht lesbar: {text!r} (z. B. 2026-10-23T09:31)")


def _log_ordner(U: Umgebung, db: str | None) -> str | None:
    """Ordner von dashboard.log und dashboard_haenger.log: aus der Unit des Dashboards (seit 23.78), sonst neben watchdog.log, sonst logs/
    neben der Hauptdatenbank."""
    for unit in ("hl-dashboard", "hl-watchdog"):
        p = _unit_datei(U, unit)
        if p:
            return os.path.dirname(p)
    return os.path.join(os.path.dirname(os.path.abspath(db)), "logs") if db else None


def haenger_abschnitt(U: Umgebung, db: str | None, jetzt: float, befund: list) -> None:
    """Hänger-Schutz (Unit), Abzüge der letzten 7 Tage, Lebenszeichen-Meldungen und letzte Zeilen von dashboard.log."""
    w(); w("== Dashboard: Hänger-Schutz, Abzüge und eigenes Log (seit 23.78)")
    _rc, t = U.befehl(["systemctl", "show", "hl-dashboard", "-p", "WatchdogUSec", "-p", "NRestarts", "-p", "Result", "-p", "ExecMainCode",
                       "-p", "ExecMainStatus", "--no-pager"], timeout=15)
    e = dict(z.split("=", 1) for z in (t or "").splitlines() if "=" in z)
    wd = e.get("WatchdogUSec", "")
    an = bool(wd) and wd not in ("0", "infinity", "0s")
    w(f"   Selbstheilung (systemd-Wächter): {'an, ' + wd if an else 'aus (Unit vor 23.78 oder ohne systemd)'}; Neustarts seit dem Start des "
      f"Pi {e.get('NRestarts', '?')}, letztes Ergebnis {e.get('Result', '?')}")
    befund.append(f"Hänger-Schutz: {'an (' + wd + ' ohne Lebenszeichen -> Neustart)' if an else 'aus'}"
                  + (" -- LETZTER NEUSTART DURCH DEN WÄCHTER (Hänger)" if e.get("Result") == "watchdog" else ""))
    ordner = _log_ordner(U, db)
    hp = os.path.join(ordner, "dashboard_haenger.log") if ordner else None
    kand = [hp] if hp else []
    kand.append(os.path.join(U.root, "updates", "dashboard_haenger.log"))
    text, quelle = None, None
    for k in kand:
        text = U.lesen(k, 2_000_000)
        if text:
            quelle = k
            break
    if not text:
        w("   Hänger-Abzüge: keine Datei (" + ", ".join(kand) + ")")
    else:
        ein = haenger_lesen(text)
        letzte_zeit, folge = None, []
        for x in ein:                                       # faulthandler-Abzüge ohne Zeit: nach dem letzten Eintrag mit Zeit
            if x["ts"] is not None:
                letzte_zeit = x["ts"]
            x["nach"] = letzte_zeit
            folge.append(x)
        neu = [x for x in folge if (x["ts"] or x["nach"] or 0) >= jetzt - 7 * 86_400]
        starts = [x for x in neu if x["art"] == "start"]
        abz = [x for x in neu if x["art"] != "start"]
        w(f"   {quelle}: in 7 Tagen {len(starts)} Starts, {len(abz)} Abzüge "
          f"({sum(1 for x in abz if x['art'] == 'fatal')} beim Beenden, {sum(1 for x in abz if x['art'] == 'timeout')} nach 5 min ohne Antwort, "
          f"{sum(1 for x in abz if x['art'] == 'abzug')} mit Namen)")
        for x in neu[-30:]:
            if x["art"] == "start":
                w(f"   {_zeit(x['ts'], True)} {x['titel'][:90]}")
                continue
            wann = _zeit(x["ts"], True) if x["ts"] else f"nach {_zeit(x['nach'], True)}"
            erkl = {"timeout": " (faulthandler: 5 min nach der letzten eigenen Antwort)",
                    "fatal": (" (so beendet systemd nach 15 min ohne Lebenszeichen)" if "Aborted" in x["titel"] else " (Absturz)")}.get(x["art"], "")
            w(f"   {wann} {x['titel'][:110]}{erkl} -- {len(x['faeden'])} Fäden")
            for k_, r_ in x["faeden"][:12]:
                w(f"      {k_[:40]:<40} {_stelle(r_)[:150]}")
        if abz:
            befund.append(f"Hänger-Abzüge in 7 Tagen: {len(abz)} (zuletzt {_zeit(abz[-1]['ts'] or abz[-1]['nach'])}: {abz[-1]['titel'][:60]})")
    lp = os.path.join(ordner, "dashboard.log") if ordner else None
    lt = U.lesen(lp, 1_000_000) if lp else None
    if not lt:
        w(f"   Dashboard-Log: keine Datei ({lp or '—'}) -- vor 23.78 ging die Ausgabe ins Journal")
        return
    zz = log_zeilen(lt)
    leb = [(ts, z) for ts, z in zz if ts and ts >= jetzt - 7 * 86_400 and "Lebenszeichen:" in z]
    w(f"   {lp}: Meldungen „Lebenszeichen“ in 7 Tagen: {len(leb)}")
    for _ts, z in leb[-10:]:
        w("   | " + z[:220])
    w("   Letzte Zeilen:")
    for _ts, z in zz[-25:]:
        w("   | " + z[:220])


def fenster_abschnitt(U: Umgebung, db: str | None, jetzt: float, befund: list, verlauf: list | None, fenster: tuple | None) -> None:
    """Lücken des Dashboards (Prognosen 7 Tage, Systemverlauf 24 h) und um die längste (oder `fenster`): Wächter, Recorder, Lebenszeichen."""
    w(); w("== Lücken des Dashboards (Prognosen alle 15 min je Coin über 7 Tage; Systemverlauf je Minute über 24 h)")
    ordner = os.path.dirname(os.path.abspath(db)) if db else None
    kand = []
    con = U.db(os.path.join(ordner, "forecasts.db")) if ordner else None
    if con is not None:
        try:
            zeiten = [r[0] for r in con.execute("SELECT DISTINCT ts FROM forecast WHERE ts >= ?", (int(jetzt) - 7 * 86_400,))]
        except sqlite3.Error:
            zeiten = []
        finally:
            con.close()
        lp = luecken(zeiten, 45 * 60, jetzt - 7 * 86_400, jetzt)
        w(f"   Prognosen: {len(zeiten)} Zeitpunkte in 7 Tagen, Lücken über 45 min: {len(lp)}")
        for a, b, d in lp[:8]:
            w(f"   Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(d)})")
        kand += [(a, b, d, "Prognosen") for a, b, d in lp]
    else:
        w("   Prognosen: forecasts.db nicht gefunden")
    if verlauf:
        lv = verlauf_luecken(verlauf, jetzt, 15 * 60)
        kand += [(a, b, d, "Systemverlauf") for a, b, d in lv]
    if fenster:
        a, b = fenster
        quelle = "von Hand (--fenster)"
    elif kand:
        a, b, _d, quelle = max(kand, key=lambda x: x[2])
    else:
        w("   keine Lücke über 15 min -- kein Fenster")
        return
    a, b = int(a), int(b)
    rand = {"Prognosen": 900, "Systemverlauf": 300}.get(quelle, min(300, (b - a) // 10))     # so genau sind die Grenzen der Quelle
    w(); w(f"== Um die Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(b - a)}; Quelle: {quelle}): Wächter, Recorder, Lebenszeichen")
    # Wächter: Abstände der Prüfungen (Verzögerung = Pi überlastet) und die Prüfungen um Anfang und Ende
    wlog = _unit_datei(U, "hl-watchdog")
    text = U.lesen(wlog, 3_000_000) if wlog else None
    if text:
        bl = [x for x in wache_bloecke_voll(text) if a - 3600 <= x[0] <= b + 1800]
        drin = [x for x in bl if a - 600 <= x[0] <= b + 600]
        abst = [(y[0] - x[0], y[0]) for x, y in zip(drin, drin[1:])]
        spaet = [(d, t) for d, t in abst if d > WACHE_SPAET_S]
        if abst:
            ds = sorted(d for d, _t in abst)
            w(f"   Wächter: {len(drin)} Prüfungen, Abstand {ds[0] // 60}:{ds[0] % 60:02d} bis {ds[-1] // 60}:{ds[-1] % 60:02d} min (Median "
              f"{ds[len(ds) // 2] // 60}:{ds[len(ds) // 2] % 60:02d}); verzögert (über {WACHE_SPAET_S // 60} min): {len(spaet)}"
              + (" -- " + ", ".join(f"{_zeit(t)} nach {_dauer(d)}" for d, t in spaet[:6]) if spaet else ""))
            befund.append(f"Wächter in der Lücke: {len(drin)} Prüfungen, " + (f"{len(spaet)} verzögert (längster Abstand {_dauer(max(spaet)[0])} "
                                                                            f"um {_zeit(max(spaet)[1])}) -- Pi zeitweise überlastet" if spaet
                                                                            else "keine verzögert -- der Pi selbst war nicht überlastet"))
        dauernd = None
        for x in bl:
            schlecht = {z.split()[1] for z in x[2] if not z.startswith("ok")}
            dauernd = schlecht if dauernd is None else dauernd & schlecht
        dauernd = dauernd or set()
        vorige = None
        for x in bl:
            if not (a - 1800 <= x[0] <= a + 2700 or b - 900 <= x[0] <= b + 900):
                vorige = x[0]
                continue
            schlecht = [z for z in x[2] if not z.startswith("ok")]
            namen = [f"{z.split()[1]} {z.split()[0]}" for z in schlecht if z.split()[1] in dauernd]
            voll = [" ".join(z.split()) for z in schlecht if z.split()[1] not in dauernd]
            backup = [" ".join(z.split()) for z in x[2] if len(z.split()) > 1 and z.split()[1] == "Backup"]
            d = f"+{(x[0] - vorige) // 60}:{(x[0] - vorige) % 60:02d}" if vorige else ""
            w(f"   {_zeit(x[0], True)} {x[1]:<8} {d:>6}  " + " · ".join(namen + voll + [b_ for b_ in backup if b_ not in voll])[:260])
            vorige = x[0]
        if dauernd:
            w(f"   (dauernd nicht ok im Fenster, nur mit Namen: {', '.join(sorted(dauernd))})")
    else:
        w(f"   Wächter-Log nicht gefunden ({wlog or 'Pfad nicht in der Unit'})")
    # Recorder: Meldungen um den Anfang und das Backup davor
    rlog = _unit_datei(U, "hl-recorder")
    rt = U.lesen(rlog, 3_000_000) if rlog else None
    if rt:
        rz = recorder_zeilen(rt, jetzt)
        um = [(t, z) for t, z in rz if t and a - 1800 <= t <= a + 2700]
        bk = [(t, z) for t, z in rz if t and a - 26 * 3600 <= t <= b and "Backup" in z]
        w(f"   Recorder-Log {rlog}: {len(um)} Zeilen von {_zeit(a - 1800)} bis {_zeit(a + 2700)}; Backup-Zeilen seit {_zeit(a - 26 * 3600)}: {len(bk)}")
        for t, z in bk[-6:]:
            w(f"   | {_zeit(t)} {z.strip()[:200]}")
        for t, z in um[-25:]:
            w(f"   | {z.rstrip()[:220]}")
    else:
        w(f"   Recorder-Log nicht gefunden ({rlog or 'Pfad nicht in der Unit'})")
    # Lebenszeichen in den Datenbanken
    w(f"   Lebenszeichen in den Datenbanken, gezählt im Kern der Lücke {_zeit(a + rand, True)} bis {_zeit(b - rand, True)} (je {rand // 60} min Rand: "
      "so genau sind die Grenzen der Quelle). Je Teil: letzter Eintrag davor · Einträge im Kern (erwartet aus den 6 h davor) · erster danach:")
    teile, markt = [], []
    for name, datei, tab, spalte, dash, bedingung in LEBENSZEICHEN:
        pfad = db if datei is None else (os.path.join(ordner, datei) if ordner else None)
        con = U.db(pfad) if pfad else None
        if con is None:
            w(f"   {name:<58} Datei fehlt ({os.path.basename(pfad) if pfad else '—'})")
            continue
        try:
            z = lebenszeichen_zaehlen(con, tab, spalte, a, b, rand, bedingung=bedingung)
            if z is not None and bedingung == LABOR_TAKT:                  # 23.79: die übrigen Einträge -- Marktzeit, kein Lebenszeichen
                m = nachgeholt_pruefen(con, tab, spalte, a, b, bedingung)
                if m:
                    markt.append((name.split(" (")[0], m))
        finally:
            con.close()
        if z is None:
            w(f"   {name:<58} Tabelle {tab} fehlt")
            continue
        teile.append((name, dash, z))
        w(f"   {name:<58} {_zeit(z['vor'], True) if z['vor'] else '—':>15} · {z['n_in']:>6} ({z['erwartet']:.0f}) · "
          f"{_zeit(z['nach'], True) if z['nach'] else '—':<15} -> {z['urteil']}")
    w(f"   (TradeLabor: als Lebenszeichen zählen nur „{', '.join(LABOR_TAKT_ARTEN)}“ -- diese Arten schreibt es immer mit der Zeit des Takts. "
      "Füllungen, Ausstiege und Grid tragen die Zeit der Kerze; nach einem Neustart spielt es die verpassten Kerzen nach.)")
    for nm, m in markt:
        w(f"   {nm} mit Marktzeit in der Lücke: {m['n']} Einträge, in Schreibreihenfolge {m['rueck']} Rücksprünge über 15 min, {m['hinter']} "
          f"hinter dem ersten Eintrag nach der Lücke geschrieben -> {m['urteil']}")
    d_stand = [n for n, dash, z in teile if dash and z["urteil"] == "stand"]
    d_lief = [n for n, dash, z in teile if dash and z["urteil"] == "lief weiter"]
    fremd_lief = [n for n, dash, z in teile if not dash and z["urteil"] == "lief weiter"]
    vor_dash = [z["vor"] for n, dash, z in teile if dash and z["vor"]]
    nach_dash = [z["nach"] for n, dash, z in teile if dash and z["nach"]]
    if d_stand and not d_lief:
        urteil = ("Teile des Dashboards standen alle (" + ", ".join(n.split(" (")[0] for n in d_stand) + ")"
                  + ("; eigene Dienste liefen weiter -> das GANZE Dashboard stand (Prozess hing oder war weg)" if fremd_lief else ""))
    elif d_stand and d_lief:
        urteil = ("nur TEILE standen (" + ", ".join(n.split(" (")[0] for n in d_stand) + "), andere liefen weiter ("
                  + ", ".join(n.split(" (")[0] for n in d_lief) + ") -> einzelne Fäden hingen, nicht der ganze Prozess")
    elif d_lief:
        urteil = "Teile des Dashboards liefen weiter (" + ", ".join(n.split(" (")[0] for n in d_lief) + ")"
    else:
        urteil = "kein Urteil (zu wenige Einträge)"
    w(f"   -> {urteil}")
    if vor_dash:
        w(f"   Letztes Lebenszeichen eines Dashboard-Teils vor der Lücke: {_zeit(max(vor_dash), True)}; erstes danach: "
          f"{_zeit(min(nach_dash), True) if nach_dash else '—'}")
    befund.append(f"Lebenszeichen {_zeit(a)}–{_zeit(b)}: {urteil}" + (f"; letztes vor der Lücke {_zeit(max(vor_dash), True)}" if vor_dash else ""))


# --------------------------------------------------------------------------------------------- 23.80 (U218): Kapazität des Pollers
# Der Recorder fragt die Positionen der Konten in Stufen ab -- hl_recorder.due_addresses prüft in dieser Reihenfolge: gesperrte Konten
# (Masterregel) gar nicht (seit 23.86, U220, Entscheidung Nutzer 26.10.; bis 23.85 alle 6 h ab 25.000 USD als Rang 2 -- bei Überlast nie),
# Elite-Konten im Wal-Takt auch ohne Position (Rang 0), Pool „Aktive Profis“ alle 10 min auch ohne Position (Rang 1, unter 20 Mio), dann
# nach Positionswert: Wale jede Minute (Rang 0), groß alle 3 min (seit 23.86 ab 500.000 USD, vorher 250.000), mittel alle 30 min (Rang 1),
# klein (unter 25.000 USD) seit 23.86 wie leere Adressen nur nach eigenem Handel, sonst höchstens täglich (bis 23.85 alle 2 h, Rang 1).
# Je Runde holt er Rate/12 Adressen: int(65 %) für Konten mit Position, int(25 %) für nie abgefragte (fast immer leer -- der Rest fällt an
# die Konten mit Position), den Rest für leere und kleine Adressen mit neuem Handel. Rang 1 sortiert er nach Überfälligkeit relativ zum
# eigenen Takt: Reicht das Budget nicht, kommt jede Stufe von Rang 1 um denselben Faktor seltener dran. Positionen, deren Abfrage älter
# als 1 h ist, lässt der Snapshot weg. Dieser Teil rechnet nach, wo das Budget hingeht und was Varianten brächten (Modell, keine Messung).
POLLER_STANDARD = {"polls_per_min": 280, "whale_notional": 20e6, "whale_refresh": 60, "hot_notional": 500e3, "hot_refresh": 180,
                   "min_notional": 25e3, "cold_refresh": 1800, "max_pos_age": 3600, "waerme": 1.0, "klein_nach_handel": True}
POLLER_ARGS = {"--polls-per-min": "polls_per_min", "--whale-notional": "whale_notional", "--whale-refresh": "whale_refresh",
               "--hot-notional": "hot_notional", "--hot-refresh": "hot_refresh", "--min-notional": "min_notional",
               "--cold-refresh": "cold_refresh", "--max-pos-age": "max_pos_age"}
POLLER_SCHALTER = {"--klein-regelmaessig": ("klein_nach_handel", False)}     # 23.86: Schalter ohne Wert
POOL_POLL_S = 600                   # hl_recorder.POOL_POLL_S (Probe C17 vergleicht diese Werte mit dem Quelltext des Recorders)
KLEIN_TAGESPRUEFUNG_S = 86_400      # hl_recorder.KLEIN_TAGESPRUEFUNG_S: leere und kleine Konten ohne eigenen Handel höchstens täglich
POOL_HYSTERESE_TAGE = 7             # hl_recorder: Mitglieder des Pools = innerhalb der Hysterese ...
POOL_DECKEL = 600                   # ... höchstens so viele, nach Wochengewinn
STUFEN = ("Wale", "Elite", "groß", "Pool", "mittel", "klein", "gesperrt")
RANG = {"Wale": 0, "Elite": 0, "groß": 1, "Pool": 1, "mittel": 1, "klein": 1, "gesperrt": None}    # None: nicht abgefragt (23.86)
VARIANTEN = (("so wie eingestellt", {}),
             ("‚groß‘ wieder ab 250.000 USD (wie bis 23.85)", {"hot_notional": 250e3}),
             ("kleine Konten wieder alle 2 h (wie bis 23.85)", {"klein_nach_handel": False}),
             ("‚mittel‘ stündlich statt alle 30 min", {"cold_refresh": 3600}),
             ("‚groß‘ alle 5 statt 3 min", {"hot_refresh": 300}))


def poller_einstellungen(unit_text: str | None) -> dict:
    """Einstellungen des Pollers aus der Recorder-Unit (ExecStart), sonst die Standardwerte von hl_recorder. 23.86: auch Schalter ohne
    Wert (--klein-regelmaessig)."""
    e = dict(POLLER_STANDARD)
    m = re.search(r"^ExecStart=(.*)$", unit_text or "", re.M)
    if m:
        a = m.group(1).split()
        for i, x in enumerate(a):
            if x in POLLER_SCHALTER:
                k_, v_ = POLLER_SCHALTER[x]
                e[k_] = v_
            elif x in POLLER_ARGS and i + 1 < len(a):
                try:
                    e[POLLER_ARGS[x]] = float(a[i + 1])
                except ValueError:
                    pass
    return e


def poller_stufe(pv: float, e: dict, sonder: str | None = None) -> str | None:
    """Stufe wie hl_recorder.due_addresses (dort in dieser Reihenfolge geprüft). None = nicht unter den Konten mit Position: leer (nur
    nach eigenem Handel) oder gesperrt unter min_notional. Gesperrte ab min_notional bilden die Stufe „gesperrt“ -- seit 23.86 nur zur
    Anzeige, der Recorder fragt sie nicht mehr ab."""
    if sonder == "gesperrt":
        return "gesperrt" if pv >= e["min_notional"] else None
    if sonder == "Elite":
        return "Elite"
    if sonder == "Pool" and pv < e["whale_notional"]:
        return "Pool"
    if pv <= 0:
        return None
    return "Wale" if pv >= e["whale_notional"] else "groß" if pv >= e["hot_notional"] else "mittel" if pv >= e["min_notional"] else "klein"


def poller_takt(st: str, e: dict) -> float | None:
    """Eingestellter Abstand der Stufe in Sekunden, mal dem Wärme-Faktor des Recorders (bei Hitze dehnt er alle Abstände). None: kein
    regelmäßiger Takt -- gesperrt (seit 23.86 nicht abgefragt) und klein, solange nur nach eigenem Handel."""
    if st == "gesperrt" or (st == "klein" and e.get("klein_nach_handel", True)):
        return None
    return e.get("waerme", 1.0) * {"Wale": e["whale_refresh"], "Elite": e["whale_refresh"], "groß": e["hot_refresh"], "Pool": POOL_POLL_S,
                                   "mittel": e["cold_refresh"], "klein": e["cold_refresh"] * 4}[st]


def poller_anteil_a(polls_per_min: float) -> float:
    """Anteil einer Runde für Konten mit Position: hl_recorder holt max(int(Rate/12), 10) Adressen je Runde, int(65 %) für sie und
    int(25 %) für nie abgefragte -- fast immer leer (am 23.10. 0 bis 31 neue), der Rest fällt an die Konten mit Position. 280/min: 23 je
    Runde, 14 + 5 = 19, also 82,6 %."""
    want = max(int(polls_per_min / 12), 10)
    return (int(want * 0.65) + int(want * 0.25)) / want


def poller_modell(konten: list, e: dict, klein_regelmaessig: bool | None = None, abfragen_min: float | None = None, dex: float = 1.0) -> dict:
    """Modell (beschreibend, keine Messung) wie hl_recorder.due_addresses. `konten` = [(Positionswert, Sonderstufe oder None)]. Bedarf je
    Stufe und Stunde = Konten × 3.600 / Takt; Budget je Stunde = Abfragen je Minute (eingestellt oder gemessen) / Abfragen je Konto (Dexe)
    × 60 × Anteil für Konten mit Position. Die Ränge bekommen das Budget nacheinander: Rang 0 (Wale, Elite) voll, Rang 1 (groß, Pool,
    mittel, klein) um denselben Faktor F gedehnt. „Frisch“ = Anteil der Konten, deren Abfrage höchstens max_pos_age alt ist (Alter
    gleichverteilt im Abstand Takt × F); „frisch (Wert)“ gewichtet mit dem Positionswert: so viel des bekannten Werts erreicht den Snapshot.
    23.86 (U220): Gesperrte werden nicht abgefragt -- kein Bedarf, nicht im Nenner von „frisch“ (eigene Summe „gesperrt_wert“). Kleine Konten
    nur nach eigenem Handel, solange e['klein_nach_handel'] (klein_regelmaessig=None übernimmt die Einstellung): kein regelmäßiger Bedarf,
    „frisch“ unbekannt -- sie zählen als nicht frisch."""
    if klein_regelmaessig is None:
        klein_regelmaessig = not e.get("klein_nach_handel", True)
    e = dict(e, klein_nach_handel=not klein_regelmaessig)
    st = {s_: [0, 0.0] for s_ in STUFEN}
    for pv, so in konten:
        k = poller_stufe(pv, e, so)
        if k:
            st[k][0] += 1
            st[k][1] += max(pv, 0.0)
    takt = {s_: poller_takt(s_, e) for s_ in STUFEN}
    bedarf = {s_: (st[s_][0] * 3600 / takt[s_] if takt[s_] else 0.0) for s_ in STUFEN}
    anteil_a = poller_anteil_a(e["polls_per_min"])
    budget = (e["polls_per_min"] if abfragen_min is None else abfragen_min) / max(dex, 1.0) * 60 * anteil_a
    faktoren, rest = {}, budget
    for rang in (0, 1):
        b = sum(v for s_, v in bedarf.items() if RANG[s_] == rang)
        faktoren[rang] = 1.0 if b <= rest else (b / rest if rest > 0 else float("inf"))
        rest = max(0.0, rest - b)
    abgefragt = [s_ for s_ in STUFEN if RANG[s_] is not None]
    gesamt_wert = sum(st[s_][1] for s_ in abgefragt) or 1.0
    gesamt_n = sum(st[s_][0] for s_ in abgefragt) or 1
    out, frisch_wert, frisch_n = {}, 0.0, 0.0
    for s_ in STUFEN:
        n, v = st[s_]
        if takt[s_] is None:
            intervall, frisch = None, None
        elif faktoren[RANG[s_]] == float("inf"):
            intervall, frisch = float("inf"), 0.0
        else:
            intervall = takt[s_] * faktoren[RANG[s_]]
            frisch = min(1.0, e["max_pos_age"] / intervall)
            frisch_wert += v * frisch
            frisch_n += n * frisch
        out[s_] = {"n": n, "wert": v, "anteil_wert": (v / gesamt_wert) if RANG[s_] is not None else None, "bedarf": bedarf[s_],
                   "intervall": intervall, "frisch": frisch, "rang": RANG[s_]}
    return {"stufen": out, "budget": budget, "bedarf": sum(bedarf.values()), "faktor": faktoren[1], "faktoren": faktoren,
            "frisch_wert": frisch_wert / gesamt_wert, "frisch_n": frisch_n / gesamt_n, "anteil_a": anteil_a, "gesamt_wert": gesamt_wert,
            "gesperrt_wert": st["gesperrt"][1], "gesperrt_n": st["gesperrt"][0], "klein_nach_handel": e["klein_nach_handel"]}


def poller_rueckrechnung(alter: dict, versatz: float | None) -> dict:
    """23.86 (U231): Abstand je Stufe aus dem gemessenen Alter zurückgerechnet. last_poll schreibt der Recorder nur stündlich gesammelt;
    das gespeicherte Alter ist deshalb Versatz V (Zeit seit dem letzten Schreiben, abgelesen am Alter der Wale) plus das Alter beim
    Schreiben, das bei gleichverteilter Phase im Abstand T gleichverteilt ist: Median = V + T/2, 90 % = V + 0,9 T. T = Mittel der beiden
    Schätzungen (nur positive); ab 20 Konten je Stufe. Liefert {Stufe: T in Sekunden}."""
    out = {}
    if versatz is None:
        return out
    for s_, a_ in alter.items():
        a_ = sorted(a_)
        if s_ in ("Wale", "Elite", "gesperrt") or len(a_) < 20:
            continue
        med, p90 = a_[len(a_) // 2], a_[int(len(a_) * 0.9)]
        t = [x for x in (2 * (med - versatz), (p90 - versatz) / 0.9) if x > 0]
        if t:
            out[s_] = sum(t) / len(t)
    return out


def poller_versatz(alter_wale: list) -> float | None:
    """Versatz des stündlichen Schreibens: Median des gespeicherten Alters der Wale (sie kommen jede Minute dran, ihr gespeichertes Alter
    ist die Zeit seit dem letzten Schreiben). Nur, wenn mindestens 5 Wale, das 90-%-Quantil höchstens 5 min über dem Median liegt und der
    Median unter 65 min (sonst schreibt oder fragt der Recorder nicht wie erwartet -- keine Rückrechnung)."""
    a_ = sorted(alter_wale)
    if len(a_) < 5:
        return None
    med, p90 = a_[len(a_) // 2], a_[int(len(a_) * 0.9)]
    return float(med) if p90 - med <= 300 and med < 3900 else None


def poller_gleiche_laufzeit(snap: list, jetzt_up: float | None, start: float | None = None) -> tuple:
    """23.86 (U231): Anteil zu alter Positionen im 7-Tage-Verlauf nur bei ähnlicher Laufzeit des Recorders (± 25 %, mindestens ± 1 h,
    ab 45 min): Der Recorder lädt beim Start keine Positionen, der Snapshot kennt nur seither abgefragte Konten -- der Anteil wächst mit
    der Laufzeit. Snapshots des laufenden Laufs (Start = ts − Laufzeit, ± 120 s) zählen nicht -- sonst vergliche er sich mit sich selbst
    (unabhängige Durchsicht 26.10.). Liefert (Median oder None, Zahl der Snapshots)."""
    if not jetzt_up:
        return None, 0
    spanne = max(3600.0, 0.25 * jetzt_up)
    basis = sorted(r[2] / (r[1] + r[2]) for r in snap if (r[1] or 0) + (r[2] or 0) and (r[4] or 0) >= 2700
                   and abs((r[4] or 0) - jetzt_up) <= spanne and (start is None or abs((r[0] - (r[4] or 0)) - start) > 120))
    return (basis[len(basis) // 2] if basis else None), len(basis)


def poller_pool_anteil(konten_pool: list, m: dict, e: dict, rate: float, dex: float) -> float:
    """23.86 (U231, eigener Fehler aus 23.80): Anteil der Pool-Mitglieder an allen Abfragen des Pollers, gezählt wie der Recorder -- jedes
    Mitglied des Pools, in welcher Stufe es auch abgefragt wird (als Wal oder Elite jede Minute, sonst im gedehnten Pool-Takt; gesperrte
    nie). Bis 23.85 zählte das Modell nur die Stufe „Pool“ und lag deshalb bei 2 % gegen gemessene 10–11 %. `konten_pool` =
    [(Positionswert, Sonderstufe)] der Pool-Mitglieder."""
    je_h = 0.0
    for pv, so in konten_pool:
        k = poller_stufe(pv, e, so)
        z = m["stufen"].get(k) if k else None
        if z and z["intervall"] not in (None, float("inf")) and z["intervall"] > 0:
            je_h += 3600 / z["intervall"]
    return je_h / max(rate / max(dex, 1.0) * 60, 1) * 100


def poller_abstaende_text(abst: dict, m0: dict, snap: list) -> tuple:
    """23.86 (U231): vom Recorder gemessene Abstände je Stufe (meta 'poller_abstaende': letzte volle Stunde, Mittel und Zahl der
    Abstände zwischen zwei erfolgreichen Abfragen) gegen das Modell. Aussagekräftig erst, wenn die Laufzeit am Ende der Stunde mindestens
    das Doppelte des Modell-Abstands ist -- nach einem Neustart misst der Recorder nur Abstände seit dem Start. Leere und kleine Konten
    (nach eigenem Handel) nur beschreibend. 23.86 nach der zweiten Durchsicht: maßgeblich ist die Laufzeit zu BEGINN der Stunde, und sie
    muss das Doppelte des größeren von Modell und Messung erreichen. Liefert (Text oder None, {Stufe: (Mittel s, n, Verhältnis zum
    Modell oder None)})."""
    je = (abst or {}).get("je_stufe") or {}
    if not je:
        return None, {}
    stunde = (abst or {}).get("stunde")
    start = (snap[-1][0] - (snap[-1][4] or 0)) if snap and snap[-1][4] else None
    laufzeit_beginn = (stunde - start) if (stunde and start) else None
    teile, out = [], {}
    for s_ in ("Wale", "Elite", "groß", "Pool", "mittel", "klein", "leer"):
        if s_ not in je:
            continue
        n, mittel = je[s_]
        iv = (m0["stufen"].get(s_) or {}).get("intervall") if s_ in m0["stufen"] else None
        q = (mittel / iv) if iv not in (None, float("inf")) and iv else None
        reif = iv is not None and iv != float("inf") and laufzeit_beginn is not None and laufzeit_beginn >= 2 * max(iv, mittel)
        out[s_] = (mittel, n, q if reif else None)
        if q is not None:
            teile.append(f"{s_} alle {_min(mittel)} (n {n}) gegen Modell {_min(iv)}: " + (f"Verhältnis {q:.2f}" if reif else
                                                                                          "Laufzeit seit dem Neustart zu kurz"))
        else:
            teile.append(f"{s_} alle {_min(mittel)} (n {n}; nach eigenem Handel, kein Takt)" if s_ in ("klein", "leer")
                         else f"{s_} alle {_min(mittel)} (n {n})")
    zeit = datetime.fromtimestamp(stunde).strftime("%d.%m. %H:%M") if stunde else "?"
    return (f"   Abstände gemessen (Recorder, Stunde ab {zeit}; zwischen zwei erfolgreichen Abfragen): " + " · ".join(teile)), out


def _usd(v: float) -> str:
    return f"{v / 1e9:.1f} Mrd" if v >= 1e9 else f"{v / 1e6:.0f} Mio" if v >= 1e6 else f"{v / 1e3:.0f} Tsd"


def _min(s_: float | None) -> str:
    if s_ is None:
        return "—"
    if s_ == float("inf"):
        return "nie"
    return f"{s_ / 3600:.1f} h" if s_ >= 5400 else f"{s_ / 60:.0f} min" if s_ >= 60 else f"{s_:.0f} s"


def _poller_sonder(U: Umgebung, con, db: str, jetzt: int) -> tuple:
    """Sonderstufen wie im Recorder: gesperrt (konto_status 'gesperrt'/'vorlaeufig'; labels.json im Projektordner: "sperre": true sperrt,
    false schützt), Elite (forecasts.db neben der Datenbank, learned 'elite' aller Coins), Pool (pool_accounts in der Hysterese, höchstens
    600 nach Wochengewinn). Vorrang wie in due_addresses: gesperrt vor Elite vor Pool. Liefert ({addr: Stufe}, {Stufe: Anzahl oder Hinweis},
    Menge der Pool-Mitglieder -- 23.86 für die Gegenprobe, die wie der Recorder jedes Mitglied zählt)."""
    info: dict = {}
    gesperrt: set = set()
    try:
        gesperrt = {r[0].lower() for r in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
    except sqlite3.Error:
        info["gesperrt"] = "konto_status fehlt"
    try:
        lab = json.loads(U.lesen(os.path.join(U.root, "labels.json")) or "{}")
        for a, v in (lab.items() if isinstance(lab, dict) else []):
            if isinstance(v, dict) and "sperre" in v:
                if v.get("sperre"):
                    gesperrt.add(a.lower())
                else:
                    gesperrt.discard(a.lower())
    except ValueError:
        info["labels"] = "labels.json nicht lesbar"
    elite: set = set()
    cf = U.db(os.path.join(os.path.dirname(os.path.abspath(db)), "forecasts.db"))
    if cf is None:
        info["Elite"] = "forecasts.db fehlt"
    else:
        try:
            for (v,) in cf.execute("SELECT value FROM learned WHERE key='elite'"):
                try:
                    elite.update(a.lower() for a in json.loads(v) if isinstance(a, str))
                except (ValueError, TypeError):
                    continue
        except sqlite3.Error:
            info["Elite"] = "learned fehlt"
        finally:
            cf.close()
    pool: set = set()
    try:
        pool = {r[0].lower() for r in con.execute("SELECT addr FROM pool_accounts WHERE zuletzt_erfuellt >= ? ORDER BY pnl_7d DESC LIMIT ?",
                                                  (jetzt - POOL_HYSTERESE_TAGE * 86_400, POOL_DECKEL))}
    except sqlite3.Error:
        info["Pool"] = "pool_accounts fehlt"
    sonder = {a: "Pool" for a in pool}
    sonder.update({a: "Elite" for a in elite})
    sonder.update({a: "gesperrt" for a in gesperrt})
    return sonder, info, pool


def _poller_info(jobs: str | None) -> str | None:
    """Text des Adress-Pollers aus meta 'jobs' (JSON, bei 4.000 Zeichen abgeschnitten -- dann per Muster)."""
    if not jobs:
        return None
    try:
        return (json.loads(jobs).get("Adress-Poller") or {}).get("info")
    except (ValueError, AttributeError, TypeError):
        m = re.search(r'"Adress-Poller":\s*\{[^{}]*?"info":\s*"((?:[^"\\]|\\.)*)"', jobs)
        if not m:
            return None
        try:
            return json.loads('"' + m.group(1) + '"')
        except ValueError:
            return m.group(1)


def poller_bericht(U: Umgebung, db: str) -> dict:
    """Debug „Recorder: Poller-Kapazität“ (liest nur): Konten und Positionswert je Stufe (mit Elite, Pool, gesperrt), Bedarf gegen Budget
    (gemessene Rate des Pollers aus api_load), gemessenes Alter aus der Datenbank, Snapshot und Abdeckung gegen ihren Normalwert, Varianten
    im Modell. 23.86 (U220/U231): gesperrte Konten nicht abgefragt, kleine nur nach eigenem Handel, „groß“ ab 500.000 USD; Gegenprobe Pool
    wie der Recorder; vom Recorder gemessene Abstände je Stufe gegen das Modell (Hauptmaß), Abstände aus dem Alter zurückgerechnet (nur
    beschreibend); Anteil zu alter Positionen bei gleicher Laufzeit; Handel je Stufe; Gruppe C und Vorrang nach großem Handel."""
    jetzt = int(U.jetzt())
    w(f"POLLER-KAPAZITÄT -- {datetime.fromtimestamp(jetzt):%d.%m.%Y %H:%M:%S} (liest nur; Modell, keine Messung, wo so bezeichnet)")
    _rc, t = U.befehl(["systemctl", "cat", "hl-recorder"], timeout=15)
    e = poller_einstellungen(t)
    con = U.db(db)
    if con is None:
        w(f"   Datenbank fehlt: {db}")
        return {"ok": False}
    try:
        try:
            r = con.execute("SELECT v FROM meta WHERE k='thermal_interval_factor'").fetchone()
            e["waerme"] = max(1.0, float(r[0])) if r and r[0] else 1.0
        except (sqlite3.Error, ValueError):
            pass
        sonder, s_info, pool = _poller_sonder(U, con, db, jetzt)
        spalten = "addr, pos_value, last_poll, dexes, last_trade"
        try:
            rows = con.execute(f"SELECT {spalten} FROM addresses WHERE pos_value > 0").fetchall()
        except sqlite3.Error:                         # ältere Datenbank ohne Spalte dexes: eine Abfrage je Konto
            spalten = "addr, pos_value, last_poll, '', last_trade"
            rows = con.execute(f"SELECT {spalten} FROM addresses WHERE pos_value > 0").fetchall()
        da = {str(r[0]).lower() for r in rows}
        extra = [a for a in sonder if a not in da]
        for i in range(0, len(extra), 500):
            teil = extra[i:i + 500]
            rows += con.execute(f"SELECT {spalten} FROM addresses WHERE addr IN ({','.join('?' * len(teil))})", teil).fetchall()
        try:                                          # 23.86: leere Adressen, die seit ihrer letzten Abfrage gehandelt haben (Gruppe C)
            leer_wartend = [str(r[0]).lower() for r in con.execute(
                "SELECT addr FROM addresses WHERE pos_value <= 0 AND last_poll > 0 AND last_trade > last_poll * 1000")]
        except sqlite3.Error:
            leer_wartend = []
        try:
            gew = sorted(r[0] for r in con.execute("SELECT weight FROM api_load WHERE quelle='Poller' AND ts >= ? AND ts < ?",
                                                   (jetzt - 3 * 3600, jetzt - 60)))
        except sqlite3.Error:
            gew = []
        try:
            r = con.execute("SELECT v FROM meta WHERE k='jobs'").fetchone()
            info = _poller_info(r[0] if r else None)
        except sqlite3.Error:
            info = None
        try:                                          # 23.86: Größe der drei Gruppen in der letzten Auswahl (meta, alle 10 s geschrieben)
            gruppen = {k_: v_ for k_, v_ in con.execute("SELECT k, v FROM meta WHERE k IN ('poller_due_a','poller_due_b','poller_due_c')")}
            r = con.execute("SELECT v FROM meta WHERE k='poller_abstaende'").fetchone()
            abst_meta = json.loads(r[0]) if r and r[0] else {}
            r = con.execute("SELECT v FROM meta WHERE k='poller_vorrang'").fetchone()
            vorrang_n = int(r[0]) if r and r[0] not in (None, "") else None
        except (sqlite3.Error, ValueError, TypeError):
            gruppen, abst_meta, vorrang_n = {}, {}, None
        try:
            snap = con.execute("SELECT ts, n_positions, n_stale_dropped, backlog, uptime FROM snapshot_meta WHERE ts >= ? ORDER BY ts",
                               (jetzt - 7 * 86_400,)).fetchall()
        except sqlite3.Error:
            snap = []
        try:
            t1 = con.execute("SELECT MAX(ts) FROM coverage").fetchone()[0]
            cov = con.execute("SELECT coin, ratio FROM coverage WHERE ts=?", (t1,)).fetchall() if t1 else []
            hist = con.execute("SELECT c.coin, c.ratio FROM coverage c JOIN snapshot_meta s ON s.ts=c.ts WHERE c.ts >= ? AND s.uptime >= 2700",
                               (jetzt - 7 * 86_400,)).fetchall()
        except sqlite3.Error:
            cov, hist = [], []
    finally:
        con.close()
    konten, alter, nie = [], {s_: [] for s_ in STUFEN}, 0
    konten_pool = []
    handel = {s_: [0, 0] for s_ in STUFEN}            # gehandelt in der letzten Stunde, in 24 h (last_trade, stündlich geschrieben)
    klein_wartend = 0
    dex_summe = dex_gew = 0.0
    for addr, pv, lp, dx, lt in rows:
        a_ = str(addr).lower()
        so = sonder.get(a_)
        pv = float(pv or 0)
        if not lp:
            if so != "gesperrt":
                nie += 1                              # nie abgefragt: eigene Gruppe des Recorders (gesperrte fragt er seit 23.86 gar nicht ab)
            continue
        konten.append((pv, so))
        if a_ in pool:
            konten_pool.append((pv, so))
        k = poller_stufe(pv, e, so)
        if k:
            alter[k].append(jetzt - int(lp))
            lt_s = (lt or 0) / 1000
            handel[k][0] += lt_s >= jetzt - 3600
            handel[k][1] += lt_s >= jetzt - 86_400
            if k == "klein" and e.get("klein_nach_handel", True) and lt_s > lp:
                klein_wartend += 1
            t_ = poller_takt(k, e)
            if t_:
                g = 3600 / t_                         # Abfragen je Konto (Dexe), gewichtet mit dem Bedarf der Stufe
                dex_summe += g * max(1, len(dx.split(","))) if dx else g
                dex_gew += g
    leer_wartend = [a_ for a_ in leer_wartend if sonder.get(a_) not in ("gesperrt", "Elite", "Pool")]
    dex = dex_summe / dex_gew if dex_gew else 1.0
    rate = gew[len(gew) // 2] / 2 if len(gew) >= 60 else None     # Gewicht 2 je Abfrage (clearinghouseState)
    w(f"   Einstellungen ({'aus der Unit' if t and 'ExecStart' in t else 'Standardwerte'}): {e['polls_per_min']:.0f} Abfragen je Minute · Wale ab "
      f"{_usd(e['whale_notional'])} USD alle {_min(e['whale_refresh'])} · groß ab {_usd(e['hot_notional'])} alle {_min(e['hot_refresh'])} · "
      f"mittel ab {_usd(e['min_notional'])} alle {_min(e['cold_refresh'])} · klein "
      + ("nur nach eigenem Handel, sonst höchstens täglich" if e.get("klein_nach_handel", True) else f"alle {_min(e['cold_refresh'] * 4)}")
      + f" · Elite im Wal-Takt · Pool alle {_min(POOL_POLL_S)} · gesperrt: nicht abgefragt (seit 23.86) · Snapshot nimmt Positionen bis "
      f"{_min(e['max_pos_age'])} Alter" + (f" · Wärme-Faktor {e['waerme']:.2f} (alle Abstände gedehnt)" if e["waerme"] > 1 else ""))
    mess = (f"im Median {rate:.0f} Abfragen je Minute (Gewicht/2, Minuten mit Abfragen der letzten 3 h, n={len(gew)})" if rate else
            "zu wenige Minuten in api_load (unter 60) -- Budget aus der Einstellung")
    w(f"   Gemessen: Poller {mess}; je Konto {dex:.2f} Abfragen (Dexe); {nie} Konten noch nie abgefragt (eigene Gruppe)")
    if info:
        w(f"   Letzte Runde laut Recorder: {info}")
    if len(gruppen) == 3:
        want_ = max(int(e["polls_per_min"] / 12), 10)
        n_c_ = want_ - int(want_ * 0.65) - int(want_ * 0.25)
        w(f"   Letzte Auswahl laut Recorder: Gruppe A {gruppen['poller_due_a']} Konten über ihrem Takt · B {gruppen['poller_due_b']} nie "
          f"abgefragt · C {gruppen['poller_due_c']} leere" + (" und kleine" if e.get("klein_nach_handel", True) else "")
          + f" nach eigenem Handel oder Tagesprüfung (je Runde {n_c_} von {want_} Plätzen, bei Drosselung weniger; die zuletzt Handelnden "
          "zuerst)")
    if s_info:
        w("   Hinweis Sonderstufen: " + ", ".join(f"{k}: {v}" for k, v in s_info.items()))
    m0 = poller_modell(konten, e, abfragen_min=rate, dex=dex)
    versatz = poller_versatz(alter["Wale"])
    rueck = poller_rueckrechnung(alter, versatz)
    w()
    w("== Stufen -- Bedarf gegen Budget (Modell; Rang 0 zuerst, Rang 1 gemeinsam gedehnt; gesperrt nicht abgefragt)")
    w(f"   {'Stufe':<9}{'Rang':>5}{'Konten':>9}{'Positionswert':>15}{'Anteil':>8}{'Bedarf/h':>10}{'Modell: alle':>17}{'frisch':>8}   gemessen in der Datenbank*")
    for s_ in STUFEN:
        z = m0["stufen"][s_]
        a_ = sorted(alter[s_])
        gem = (f"Median {_min(a_[len(a_) // 2])}, 90 % {_min(a_[int(len(a_) * 0.9)])}" if a_ else "—")
        if s_ in rueck and m0["stufen"][s_]["intervall"] not in (None, float("inf")):
            gem += f"; zurückgerechnet alle {_min(rueck[s_])}"
        if s_ == "gesperrt":
            modell_txt, frisch_txt, rang_txt, anteil_txt = "nicht abgefragt", "—", "—", "—"
        elif s_ == "klein" and z["intervall"] is None:
            modell_txt, frisch_txt, rang_txt, anteil_txt = "nach Handel", "?", str(z["rang"]), f"{z['anteil_wert'] * 100:.0f}%"
        else:
            modell_txt, frisch_txt, rang_txt = _min(z["intervall"]), f"{(z['frisch'] or 0) * 100:.0f}%", str(z["rang"])
            anteil_txt = f"{z['anteil_wert'] * 100:.0f}%"
        w(f"   {s_:<9}{rang_txt:>5}{z['n']:>9}{_usd(z['wert']):>15}{anteil_txt:>8}{z['bedarf']:>10.0f}{modell_txt:>17}{frisch_txt:>8}   {gem}")
    w(f"   Bedarf {m0['bedarf']:.0f} Konten-Abfragen/h gegen ein Budget von etwa {m0['budget']:.0f}/h für Konten mit Position "
      f"({'gemessene' if rate else 'eingestellte'} Rate / {dex:.2f} Abfragen je Konto × 60 × {m0['anteil_a'] * 100:.1f} % je Runde): Faktor "
      f"{m0['bedarf'] / max(m0['budget'], 1):.1f}. Rang 1 kommt um den Faktor {_faktor(m0['faktoren'][1])} seltener dran als eingestellt.")
    w(f"   Modell: frisch genug für den Snapshot (höchstens {_min(e['max_pos_age'])} alt) sind etwa {m0['frisch_wert'] * 100:.0f} % des "
      f"bekannten Positionswerts ohne Gesperrte und {m0['frisch_n'] * 100:.0f} % der Konten" + (
          f" (gemessen im letzten Snapshot: {snap[-1][1] / max((snap[-1][1] or 0) + (snap[-1][2] or 0), 1) * 100:.0f} % der Positionen drin -- "
          "Positionen der verfolgten Coins, nicht Konten; nur grob vergleichbar)" if snap and snap[-1][1] is not None else "") + "."
      + (" Kleine Konten zählen dabei als nicht frisch (nur nach eigenem Handel abgefragt, Takt unbekannt)."
         if m0["klein_nach_handel"] and m0["stufen"]["klein"]["n"] else ""))
    w("   * last_poll schreibt der Recorder meist stündlich gesammelt (sofort nur bei ≥ 2 % Wertänderung, neu flachen und ersten Abfragen) -- "
      "die gemessenen Alter sind bis zu 1 h zu hoch.")
    gemessen_txt, gemessen = poller_abstaende_text(abst_meta, m0, snap)
    if gemessen_txt:
        w(gemessen_txt)
    rk_ = {s_: v for s_, v in rueck.items() if m0["stufen"][s_]["intervall"] not in (None, float("inf"))}
    if rk_:
        w(f"   Abstände aus dem gespeicherten Alter zurückgerechnet (nur beschreibend, zu kurz verzerrt: Konten mit ≥ 2 % Wertänderung schreibt "
          f"der Recorder sofort, ohne den Versatz von {_min(versatz)}): " + " · ".join(
              f"{s_} {_min(v)} gegen Modell {_min(m0['stufen'][s_]['intervall'])} (Verhältnis {v / m0['stufen'][s_]['intervall']:.2f})"
              for s_, v in rk_.items()))
    elif alter["Wale"]:
        w("   Abstände nicht zurückgerechnet: Das Alter der Wale ergibt keinen eindeutigen Versatz des stündlichen Schreibens.")
    if vorrang_n is not None:
        up_ = snap[-1][4] if snap and snap[-1][4] else None
        w(f"   Vorrang nach großem Handel (leere und kleine Konten mit mindestens 25 Tsd USD Handel seit ihrer letzten Abfrage, Standard von "
          f"--vorrang-ab; vor Rang 1; "
          f"im Modell nicht enthalten): {vorrang_n} Abfragen seit dem Start" + (f", etwa {vorrang_n / (up_ / 3600):.0f} je Stunde"
                                                                              if up_ and up_ >= 3600 else ""))
    # Gegenprobe: Anteil des Pools an den Abfragen (Recorder misst ihn je Runde) gegen das Modell -- seit 23.86 gezählt wie der Recorder
    m_pool = re.search(r"davon Pool \d+ \((\d+) % der letzten 10 min\)", info or "")
    modell_pool = poller_pool_anteil(konten_pool, m0, e, rate or e["polls_per_min"], dex) if konten_pool else None
    if modell_pool is not None:
        w(f"   Gegenprobe Pool (jedes Mitglied, auch als Wal oder Elite abgefragt -- wie der Recorder zählt): Anteil an allen Abfragen des "
          f"Pollers im Modell {modell_pool:.0f} %"
          + (f", gemessen {m_pool.group(1)} % (letzte 10 min laut Recorder)" if m_pool else ", gemessen: keine Angabe in meta 'jobs'"))
    # Formel der Recorder-Statuszeile (seit 23.86 wie das Modell, aber mit der eingestellten Rate)
    S = m0["stufen"]
    ausl = m0["bedarf"] / max(e["polls_per_min"] * 60 * poller_anteil_a(e["polls_per_min"]), 1)
    w(f"   Zum Vergleich die Formel der Recorder-Statuszeile (seit 23.86 wie das Modell, mit der eingestellten Rate "
      f"{e['polls_per_min']:.0f}/min): Auslastung {ausl * 100:.0f} % ({S['Wale']['n']} Wale / {S['Elite']['n']} Elite / {S['Pool']['n']} Pool / "
      f"{S['groß']['n']} groß / {S['mittel']['n']} mittel" + (f" / {S['klein']['n']} klein" if not m0["klein_nach_handel"] else "") + ").")
    w(f"   Gruppe der leeren und kleinen Konten nach eigenem Handel (Stand des stündlichen Schreibens): {len(leer_wartend)} leere"
      + (f" und {klein_wartend} kleine" if m0["klein_nach_handel"] else "") + " haben seit ihrer letzten Abfrage gehandelt.")
    w("   Gehandelt in der letzten Stunde / in 24 h (last_trade, stündlich geschrieben): " + " · ".join(
        f"{s_} {handel[s_][0]} / {handel[s_][1]}" for s_ in ("Wale", "groß", "Pool", "mittel", "klein") if S[s_]["n"]))
    w()
    w("== Snapshot und Abdeckung (gemessen)")
    stale_gleich, n_gleich = (None, 0)
    if snap:
        _ts, n_pos, n_alt, backlog, up = snap[-1]
        ges = (n_pos or 0) + (n_alt or 0)
        stale_gleich, n_gleich = poller_gleiche_laufzeit(snap, up, (_ts - up) if up else None)
        w(f"   Letzter Snapshot: {n_pos} Positionen drin, {n_alt} zu alt ausgelassen ({(n_alt or 0) / max(ges, 1) * 100:.0f} % bei "
          f"{_min(up)} Laufzeit" + (f"; 7-Tage-Median früherer Läufe bei ähnlicher Laufzeit {stale_gleich * 100:.0f} %, n={n_gleich}"
                                    if stale_gleich is not None else "; keine früheren Läufe mit ähnlicher Laufzeit") + f"); überfällig {backlog}")
        w("   Der Anteil zu alter Positionen hängt an der Laufzeit (der Recorder lädt beim Start keine Positionen) und an den Regeln der "
          "Stufen -- verglichen wird nur bei ähnlicher Laufzeit; „überfällig“ zählt seit 23.86 die Konten über ihrem Takt im Speicher.")
    else:
        w("   kein Snapshot-Verlauf (snapshot_meta)")
    if cov:
        je: dict = {}
        for c_, v in hist:
            je.setdefault(c_, []).append(v)
        w("   Abdeckung des Open Interest jetzt (7-Tage-Median): " + " · ".join(
            f"{c_} {v * 100:.0f} %" + (f" ({sorted(je[c_])[len(je[c_]) // 2] * 100:.0f} %)" if je.get(c_) else "") for c_, v in sorted(cov)))
    w()
    w("== Varianten (Modell, beschreibend -- nichts davon ist eingestellt)")
    w(f"   {'Variante':<52}{'Bedarf/h':>10}{'Faktor':>8}{'groß alle':>11}{'mittel alle':>13}{'frisch (Wert)':>15}")
    erg = []
    for name, aend in VARIANTEN:
        m_ = poller_modell(konten, dict(e, **aend), abfragen_min=rate, dex=dex)
        erg.append((name, m_))
        w(f"   {name:<52}{m_['bedarf']:>10.0f}{m_['bedarf'] / max(m_['budget'], 1):>8.1f}{_min(m_['stufen']['groß']['intervall']):>11}"
          f"{_min(m_['stufen']['mittel']['intervall']):>13}{m_['frisch_wert'] * 100:>14.0f}%")
    w()
    w("== BEFUND (kurz)")
    w(f"   - Bedarf {m0['bedarf']:.0f}/h gegen etwa {m0['budget']:.0f}/h: Faktor {m0['bedarf'] / max(m0['budget'], 1):.1f}; groß, Pool und mittel"
      + ("" if m0["klein_nach_handel"] else " und klein") + f" kommen um den Faktor {_faktor(m0['faktoren'][1])} seltener dran als eingestellt.")
    w(f"   - Kleine Konten (unter {_usd(e['min_notional'])} USD): {S['klein']['n']} Konten, {S['klein']['anteil_wert'] * 100:.0f} % des "
      "Positionswerts -- " + ("nur nach eigenem Handel abgefragt (seit 23.86), kein regelmäßiger Bedarf." if m0["klein_nach_handel"] else
                              f"{S['klein']['bedarf'] / max(m0['bedarf'], 1) * 100:.0f} % des Bedarfs."))
    w(f"   - Elite und Pool: {S['Elite']['n']} und {S['Pool']['n']} Konten (auch ohne Position abgefragt), zusammen "
      f"{(S['Elite']['bedarf'] + S['Pool']['bedarf']) / max(m0['bedarf'], 1) * 100:.0f} % des Bedarfs, {(S['Elite']['anteil_wert'] + S['Pool']['anteil_wert']) * 100:.0f} % des Positionswerts.")
    if m0["gesperrt_n"]:
        w(f"   - Gesperrte Konten ab {_usd(e['min_notional'])} USD: {m0['gesperrt_n']} Konten, {_usd(m0['gesperrt_wert'])} USD "
          f"({m0['gesperrt_wert'] / max(m0['gesamt_wert'] + m0['gesperrt_wert'], 1) * 100:.0f} % des gesamten bekannten Positionswerts, Stand "
          "ihrer letzten Abfrage) -- seit 23.86 nicht abgefragt (Entscheidung 26.10.: Hochfrequenzkonten, oft Hedge-Positionen), nicht im Nenner "
          "von „frisch“.")
    beste = max(erg, key=lambda x: x[1]["frisch_wert"])
    if beste[1]["frisch_wert"] - m0["frisch_wert"] < 0.01:
        w(f"   - Im Modell bringt keine Variante mehr als 1 Prozentpunkt frischen Positionswert (jetzt {m0['frisch_wert'] * 100:.0f} %).")
    else:
        w(f"   - Im Modell bringt „{beste[0]}“ am meisten: etwa {beste[1]['frisch_wert'] * 100:.0f} % des Positionswerts frisch (jetzt "
          f"{m0['frisch_wert'] * 100:.0f} %). Ob das stimmt, zeigt erst die Messung nach einer Änderung (Abdeckung, Abstände je Stufe).")
    w(); w("ENDE -- bitte vollständig einfügen")
    return {"ok": True, "modell": m0, "varianten": erg, "einstellungen": e, "rate": rate, "dex": dex, "auslastung": ausl, "rueck": rueck,
            "versatz": versatz, "pool_modell": modell_pool, "stale_gleich": stale_gleich, "n_gleich": n_gleich, "handel": handel,
            "leer_wartend": len(leer_wartend), "klein_wartend": klein_wartend, "nie": nie, "gruppen": gruppen, "gemessen": gemessen,
            "vorrang": vorrang_n}


def _faktor(f_: float) -> str:
    return "∞" if f_ == float("inf") else f"{f_:.1f}"


def journal_dauerhaft(U: Umgebung, an: bool) -> bool:
    """23.78 (U217): Systemprotokoll dauerhaft ein- oder ausschalten -- nur auf Klick des Nutzers. Jeder Schritt mit sudo (Passwort aus
    sudo.txt nur über stdin; keiner der Befehle liest stdin, auch nicht, wenn sudo kein Passwort verlangt). Ein: Einstellung 90-hl-dauerhaft.conf
    (Storage=persistent, höchstens 200 MB, 2 GB bleiben frei), Ordner /var/log/journal, journald neu, bisheriges Protokoll übernehmen.
    Aus: Einstellung und /var/log/journal entfernen, journald neu -- wie vorher."""
    w(f"SYSTEMPROTOKOLL DAUERHAFT -- {'EINSCHALTEN' if an else 'AUSSCHALTEN'} ({datetime.fromtimestamp(U.jetzt()):%d.%m.%Y %H:%M:%S})")
    _rc, t = U.befehl(["systemd-analyze", "cat-config", "systemd/journald.conf"], timeout=20)
    vorher = [z.strip() for z in (t or "").splitlines() if z.startswith("#") and z.strip().endswith(".conf") or z.startswith("Storage=")]
    w("   Bisher: " + (" · ".join(vorher[-6:]) if vorher else "keine Angabe (Voreinstellung)"))
    if not U.sudo_pw():
        w("   FEHLER: kein sudo-Passwort (sudo.txt mit Rechten 600 im Projektordner) -- nichts geändert")
        return False
    tmp = os.path.join(U.root, "updates", "journald_hl_dauerhaft.conf.tmp")
    if an:
        if not U.schreiben(tmp, JOURNAL_INHALT):
            w(f"   FEHLER: {tmp} nicht schreibbar -- nichts geändert")
            return False
        schritte = [(["install", "-D", "-m", "644", tmp, JOURNAL_DROPIN], f"Einstellung {JOURNAL_DROPIN}"),
                    (["mkdir", "-p", "/var/log/journal"], "Ordner /var/log/journal"),
                    (["systemd-tmpfiles", "--create", "--prefix", "/var/log/journal"], "Rechte des Ordners"),
                    (["systemctl", "restart", "systemd-journald"], "journald neu gestartet"),
                    (["journalctl", "--flush"], "bisheriges Protokoll übernommen")]
    else:
        schritte = [(["rm", "-f", JOURNAL_DROPIN], f"Einstellung {JOURNAL_DROPIN} entfernt"),
                    (["rm", "-rf", "--one-file-system", "/var/log/journal"], "gespeicherte Protokolle (/var/log/journal) gelöscht"),
                    (["systemctl", "restart", "systemd-journald"], "journald neu gestartet")]
    gut = True
    try:
        for args, text in schritte:
            rc, out = U.befehl(args, timeout=90, sudo=True)
            w(f"   {'ok   ' if rc == 0 else 'FEHL '} {text}" + ("" if rc == 0 else f" (rc {rc}: {(out or '').strip()[:200]})"))
            if rc != 0:
                gut = False
                break
    finally:
        if an:
            U.entfernen(tmp)
    _rc, t = U.befehl(["systemd-analyze", "cat-config", "systemd/journald.conf"], timeout=20)
    st = [z.strip() for z in (t or "").splitlines() if z.startswith("Storage=")]
    da = U.da("/var/log/journal")
    w(f"   Jetzt: zuletzt gilt {st[-1] if st else 'Storage= (Voreinstellung)'}; /var/log/journal {'vorhanden' if da else 'fehlt'}")
    ziel = (st[-1:] == ["Storage=persistent"] and da) if an else (not da and "Storage=persistent" not in st[-1:])
    if gut and not ziel:
        w("   ACHTUNG: Die Einstellung wirkt nicht wie gewollt (eine später gelesene Datei setzt Storage= anders?) -- Ausgabe oben prüfen")
    w("   Ergebnis: " + ("erledigt" if gut and ziel else "NICHT erledigt"))
    if an and gut and ziel:
        w("   Ab jetzt überlebt das Systemprotokoll Neustarts (höchstens 200 MB). „★ System: letzter Neustart und Ausfälle“ zeigt nach dem nächsten")
        w("   Neustart auch Kernel-Meldungen und die systemd-Zeilen des Dashboards von davor.")
    return gut and ziel


# --------------------------------------------------------------------------------------------- Bericht
def bericht(U: Umgebung, db: str | None = None, fenster: tuple | None = None) -> dict:
    jetzt = U.jetzt(); boot = U.boot(); befund = []
    w(f"SYSTEM: letzter Neustart und Ausfälle -- {datetime.fromtimestamp(jetzt):%d.%m.%Y %H:%M:%S} (Ortszeit des Pi)")
    w(f"   Pi gestartet {_zeit(boot, True)} (läuft seit {_dauer(jetzt - boot) if boot else '?'})")
    befund.append(f"Pi läuft seit {_zeit(boot)} ({_dauer(jetzt - boot) if boot else '?'})")

    w(); w("== Dienste jetzt")
    for u in DIENSTE:
        _rc, t = U.befehl(["systemctl", "show", u, "-p", "ActiveState", "-p", "SubState", "-p", "NRestarts", "-p", "ExecMainStartTimestamp",
                           "-p", "MemoryCurrent", "-p", "Result", "--no-pager"], timeout=15)
        e = dict(z.split("=", 1) for z in (t or "").splitlines() if "=" in z)
        mem = e.get("MemoryCurrent", "")
        w(f"   {u:<14} {e.get('ActiveState', '?')}/{e.get('SubState', '?')}, seit {e.get('ExecMainStartTimestamp') or '—'}, Neustarts "
          f"{e.get('NRestarts', '?')}, Ergebnis {e.get('Result', '?')}" + (f", Speicher {int(mem) / 2 ** 20:.0f} MB" if mem.isdigit() else ""))

    w(); w("== Starts im Journal")
    starts = starts_lesen(journal(U, ["--list-boots"]))
    for i, bid, rest in starts[-5:]:
        w(f"   {i:>3}  {rest}")
    dauerhaft = any(i < 0 for i, _b, _r in starts)
    if not starts:
        w("   keine Liste (journalctl nicht lesbar)")
    elif not dauerhaft:
        w("   Nur der jetzige Start ist gespeichert: Das Journal ist nicht dauerhaft (/var/log/journal fehlt) -- was vor dem Neustart geschah, steht "
          "nur noch im Wächter-Log, im CPU-Verlauf und in den Logdateien der Dienste (unten).")
    befund.append(f"Journal dauerhaft: {'ja' if dauerhaft else 'nein'} ({len(starts)} Starts gespeichert)" if starts
                  else "Journal: nicht lesbar (journalctl fehlt oder keine Rechte)")

    if dauerhaft:
        w(); w("== Vor dem letzten Neustart: Dashboard (Meldungen von systemd)")
        sd = journal(U, ["-b", "-1", "-u", "hl-dashboard", "-t", "systemd", "-o", "short-iso"]).splitlines()
        absturz = [z for z in sd if re.search(r"Main process exited|Failed with result|Scheduled restart job|Killed|core-dump", z)]
        for z in sd[-20:]:
            w("   " + z)
        befund.append(f"Dashboard vor dem Neustart: {len(absturz)} Zeilen zu Absturz/Neustart durch systemd"
                      + (f" (zuletzt: {absturz[-1][:120]})" if absturz else ""))
        w(); w("== Vor dem letzten Neustart: Dashboard (letzte 40 Zeilen seiner Ausgabe)")
        for z in journal(U, ["-b", "-1", "-u", "hl-dashboard", "-n", "40", "-o", "short-iso"]).splitlines():
            w("   " + z[:300])
        w(); w("== Vor dem letzten Neustart: Kernel (Speicher, Platte/USB, Strom, Hänger, Temperatur)")
        kern = journal(U, ["-b", "-1", "-k", "-o", "short-iso"]).splitlines()
        n, treffer = kern_zaehlen(kern)
        for z in treffer[-25:]:
            w("   " + z[:300])
        if not treffer:
            w("   keine solche Zeile")
        befund.append("Kernel vor dem Neustart: " + ", ".join(f"{a} {k}" for a, k in n.items()))
        w(); w("== Vor dem letzten Neustart: die letzten 25 Zeilen des Journals")
        ende = journal(U, ["-b", "-1", "-n", "25", "-o", "short-iso"]).splitlines()
        for z in ende:
            w("   " + z[:300])
        sauber = sauber_beendet(ende)
        befund.append("Voriger Start endete " + ("sauber (Herunterfahren im Journal)" if sauber else
                                                 "ABRUPT -- kein Herunterfahren im Journal (Strom weg, Hänger oder Taster lang gedrückt)"))

    w(); w("== Wächter-Log (Prüfung alle 5 min)")
    wlog = _unit_datei(U, "hl-watchdog")
    text = U.lesen(wlog, 3_000_000) if wlog else None
    if not text:
        w(f"   nicht gefunden ({wlog or 'Pfad nicht in der Unit'})")
    else:
        bl = wache_bloecke(text)
        schlecht = [b for b in bl if b[0] >= jetzt - 86_400 and b[1] != "ok"]
        w(f"   {wlog}: {len(bl)} Prüfungen gelesen, in den letzten 24 h {len(schlecht)} nicht ok")
        for ts, st, z in schlecht[-30:]:
            w(f"   {_zeit(ts)} {st}: " + " · ".join(" ".join(x.split()) for x in z)[:300])
        dash = [b for b in bl if b[0] >= jetzt - 86_400 and any("hl-dashboard" in x for x in b[2])]
        port = [b for b in bl if b[0] >= jetzt - 86_400 and any(x.split()[1:2] == ["Dashboard"] for x in b[2])]   # seit 23.78
        if port:
            befund.append(f"Wächter: Dashboard lief, antwortete aber nicht auf seinem Port in {len(port)} Prüfungen ({_zeit(port[0][0])} bis "
                          f"{_zeit(port[-1][0])}) -- Hänger")
        befund.append("Wächter: hl-dashboard " + (f"nicht aktiv gemeldet {_zeit(dash[0][0])} bis {_zeit(dash[-1][0])} ({len(dash)} Prüfungen)" if dash
                                                  else "nie als nicht aktiv gemeldet (Prozess lief -- also eher hängend als abgestürzt, oder Wächter selbst stand)"))
        if boot:
            vor = [b for b in bl if b[0] < boot][-3:]
            if vor:
                w(f"   Die letzten Prüfungen vor dem Neustart ({_zeit(boot)}):")
                for ts, st, z in vor:
                    w(f"   {_zeit(ts, True)} {st}" + (": " + " · ".join(" ".join(x.split()) for x in z)[:300] if z else ""))
                luecke = boot - vor[-1][0]
                if luecke > 900:
                    w(f"   Danach {_dauer(luecke)} keine Prüfung bis zum Neustart -- der Wächter lief in dieser Zeit nicht (Pi hing oder stand).")
                    befund.append(f"Wächter: letzte Prüfung {_zeit(vor[-1][0])}, danach {_dauer(luecke)} nichts bis zum Neustart (Pi hing oder stand)")

    w(); w("== CPU- und Temperaturverlauf des Dashboards (je Minute, gesichert alle 5 min)")
    kand = [os.path.join(os.path.dirname(os.path.abspath(db)), "sys_history.json")] if db else []
    kand.append(os.path.join(HIER if U.root == HIER else U.root, "updates", "sys_history.json"))
    verlauf, quelle = None, None
    for k in kand:
        t = U.lesen(k)
        if t:
            try:
                verlauf, quelle = json.loads(t), k
                break
            except ValueError:
                continue
    if not verlauf:
        w("   kein Verlauf gefunden (" + ", ".join(kand) + ")")
    else:
        lu = verlauf_luecken(verlauf, jetzt)
        w(f"   {quelle}: {len(verlauf)} Werte; Lücken über 3 min in den letzten 24 h: {len(lu)}")
        for a, b, s in lu[:5]:
            w(f"   Lücke {_zeit(a, True)} bis {_zeit(b, True)} ({_dauer(s)})")
        mit_mem = [e for e in verlauf if len(e) >= 5 and e[0] >= jetzt - 86_400]
        if mit_mem:                                                          # seit 23.77: frei nutzbar und RSS des Dashboards (MB)
            fr = [e for e in mit_mem if e[3] is not None]; rs = [e for e in mit_mem if e[4] is not None]
            if fr and rs:
                emin = min(fr, key=lambda e: e[3]); emax = max(rs, key=lambda e: e[4])
                w(f"   Arbeitsspeicher in 24 h: frei nutzbar zuletzt {fr[-1][3]} MB, am wenigsten {emin[3]} MB ({_zeit(emin[0])}); Dashboard "
                  f"zuletzt {rs[-1][4]} MB, am meisten {emax[4]} MB ({_zeit(emax[0])})")
                befund.append(f"Speicher im Verlauf: frei am wenigsten {emin[3]} MB ({_zeit(emin[0])}), Dashboard am meisten {emax[4]} MB")
        if lu:
            a = lu[0][0]
            vorher = [e for e in verlauf if a - 900 <= e[0] <= a]
            w("   Die letzten Werte vor der längsten Lücke (Zeit, CPU %, Temperatur, frei, Dashboard): "
              + " · ".join(f"{_zeit(e[0])} {e[2] if e[2] is not None else '—'} % {e[1] if e[1] is not None else '—'} °C"
                           + (f" frei {e[3]} MB, Dashboard {e[4]} MB" if len(e) >= 5 else "") for e in vorher[-10:]))
            befund.append(f"CPU-Verlauf: längste Lücke {_zeit(lu[0][0])} bis {_zeit(lu[0][1])} ({_dauer(lu[0][2])}; bis zu 5 min davor können "
                          "fehlen, weil nur alle 5 min gesichert wird)")
        w("   Eine Lücke heißt: Das Dashboard hat in der Zeit keinen Wert gemessen -- es stand, hing oder der Pi war aus.")

    haenger_abschnitt(U, db, jetzt, befund)                                  # 23.78 (U215)
    fenster_abschnitt(U, db, jetzt, befund, verlauf, fenster)                # 23.78 (U216)

    w(); w("== Berichte und Debug-Läufe der letzten 24 h (was lief)")
    ber = [(f, t, g) for f, t, g in U.dateien(os.path.join(U.root, "berichte")) if BER_NAME.match(f) and t >= jetzt - 86_400]
    for f, t, g in sorted(ber, key=lambda x: x[1])[-25:]:
        w(f"   {_zeit(t)}  {g / 1024:7.0f} kB  {f}")
    if not ber:
        w("   keine")
    lauf = U.lesen(os.path.join(U.root, "updates", "rueckblick_lauf.json"))
    if lauf:
        try:
            lj = json.loads(lauf)
            w(f"   Rückblick im Hintergrund: gestartet {_zeit(lj.get('start'))} ({lj.get('einheit') or 'PID ' + str(lj.get('pid'))})")
        except ValueError:
            pass

    w(); w("== Speicher, Platte, Strom, Last jetzt")
    mi = U.lesen("/proc/meminfo") or ""
    kb = {k: int(v) for k, v in re.findall(r"^(\w+):\s+(\d+) kB", mi, re.M)}
    if kb:
        w(f"   Arbeitsspeicher {kb.get('MemTotal', 0) / 2 ** 20:.1f} GB, frei nutzbar {kb.get('MemAvailable', 0) / 2 ** 20:.1f} GB; Auslagerung "
          f"{(kb.get('SwapTotal', 0) - kb.get('SwapFree', 0)) / 2 ** 20:.2f} von {kb.get('SwapTotal', 0) / 2 ** 20:.2f} GB belegt")
    w(f"   Last (1/5/15 min): {(U.lesen('/proc/loadavg') or '?').split(' ')[:3]}")
    for pfad in ["/"] + ([os.path.dirname(os.path.abspath(db))] if db else []):
        _rc, t = U.befehl(["df", "-h", pfad], timeout=15)
        zz = (t or "").strip().splitlines()
        w(f"   Platte {pfad}: {' '.join(zz[-1].split()) if zz else '?'}")
    _rc, t = U.befehl(["vcgencmd", "get_throttled"], timeout=10)
    merk = gedrosselt(t)
    w(f"   Strom und Takt (vcgencmd get_throttled): {(t or '').strip()} -> {', '.join(merk) if merk else 'nichts auffällig'}")
    if any("Unterspannung" in m for m in merk):
        befund.append("STROM: Unterspannung " + ("jetzt" if "Unterspannung jetzt" in merk else "seit dem Start") + " -- Netzteil oder USB-Platte prüfen")
    _rc, t = U.befehl(["vcgencmd", "measure_temp"], timeout=10)
    w(f"   Temperatur: {(t or '?').strip()}")

    w(); w("== Prozesse nach Arbeitsspeicher")
    _rc, t = U.befehl(["ps", "-eo", "pid,etimes,rss,pcpu,args", "--sort=-rss"], timeout=15)
    for z in (t or "").splitlines()[:13]:
        teile = z.split(None, 4)
        if len(teile) == 5 and teile[0].isdigit():
            prog = " ".join(os.path.basename(x) if "/" in x else x for x in teile[4].split()[:4])
            w(f"   PID {teile[0]:>7}  seit {_dauer(int(teile[1])):>11}  {int(teile[2]) / 1024:7.0f} MB  CPU {teile[3]:>5} %  {prog[:110]}")

    w(); w("== Update und Notbremse")
    t = U.lesen(os.path.join(U.root, "updates", "last_update.log"), 20_000)
    if t:
        w("   Update-Log (letzte Zeilen):")
        for z in t.strip().splitlines()[-8:]:
            w("   | " + z[:200])
    vor = sorted((f, tt) for f, tt, _g in U.dateien(os.path.join(U.root, "updates")) if f.startswith("vor_"))
    if vor:
        w("   Sicherungen vor Updates: " + ", ".join(f"{f} ({_zeit(tt)})" for f, tt in vor[-2:]))
    nlog = _unit_datei(U, "hl-notbremse")
    t = U.lesen(nlog, 20_000) if nlog else None
    if t:
        w(f"   Notbremse-Log {nlog} (letzte Zeilen):")
        for z in t.strip().splitlines()[-12:]:
            w("   | " + z[:200])

    w(); w("== BEFUND (kurz)")
    for b in befund:
        w("   - " + b)
    w(); w("ENDE -- bitte vollständig einfügen")
    return {"befund": befund}


# ============================================================================================= Selbsttest
class _ProbeUmgebung(Umgebung):
    """Erfundene Umgebung: Befehle aus einer Tabelle, Dateien aus einem Wörterbuch."""
    def __init__(self, befehle: dict, dateien: dict, jetzt: float, boot: int, pw: str | None = "probe-pw", ordner: dict | None = None):
        super().__init__("/probe")
        self.tab = befehle; self.files = dateien; self.t = jetzt; self.b = boot; self.pw = pw; self.ordner = ordner or {}; self.aufrufe = []

    def sudo_pw(self):
        return self.pw

    def befehl(self, args, timeout=30, sudo=False):
        args = list(args); self.aufrufe.append((args, sudo))
        for (muster, mit_sudo), antwort in self.tab.items():
            if mit_sudo == sudo and all(m in args for m in muster):
                return antwort
        return 1, ""

    def lesen(self, pfad, max_bytes=None):
        return self.files.get(pfad)

    def jetzt(self):
        return self.t

    def boot(self):
        return self.b

    def dateien(self, ordner):
        return self.ordner.get(ordner, [])


HAENGER_PROBE = """
== 2026-10-23 09:17:20 Dashboard-Start, PID 812 -- Stapel folgen nur bei Hänger oder Absturz

== 2026-10-23 09:33:01 Webserver antwortet nicht (Versuch 2) -- PID 812, 2 Fäden (Abzug mit Namen, neueste Zeile unten)
-- lebenszeichen (Thread 0x00007f20a35fe6c0)
     File "/usr/lib/python3.11/threading.py", line 1002, in _bootstrap
       self._bootstrap_inner()
     File "/home/seed/p/hl_viz.py", line 10092, in run
       lebenszeichen_runde(url, antwort_s, melden, abzug_s, teil)
     File "/home/seed/p/hl_viz.py", line 10052, in lebenszeichen_runde
       faeden_abzug(f"Webserver antwortet nicht (Versuch {LEBT['fehl']})")
-- MainThread (Thread 0x00007f20a5768080)
     File "/home/seed/p/hl_viz.py", line 11020, in <module>
       main()
     File "/home/seed/p/hl_viz.py", line 10144, in serve
       srv.serve_forever()
     File "/usr/lib/python3.11/selectors.py", line 415, in select
       fd_event_list = self._selector.poll(timeout, max_ev)
Timeout (0:05:00)!
Thread 0x00007f20a35fe6c0 (most recent call first):
  File "/home/seed/p/hl_viz.py", line 10026 in lebenszeichen_runde
  File "/home/seed/p/hl_viz.py", line 10092 in run

Thread 0x00007f20a1234567 (most recent call first):
  File "/usr/lib/python3.11/sqlite3/dbapi2.py", line 10 in execute
  File "/home/seed/p/hl_notbremse.py", line 1645 in welt_a_anlegen
  File "/home/seed/p/hl_viz.py", line 8193 in _welt_a_takt

Current thread 0x00007f20a5768080 (most recent call first):
  File "/usr/lib/python3.11/selectors.py", line 415 in select
  File "/usr/lib/python3.11/socketserver.py", line 233 in serve_forever
  File "/home/seed/p/hl_viz.py", line 10144 in serve
Fatal Python error: Aborted

Thread 0x00007f20a35fe6c0 (most recent call first):
  File "/home/seed/p/hl_viz.py", line 10026 in lebenszeichen_runde

Current thread 0x00007f20a5768080 (most recent call first):
  File "/usr/lib/python3.11/selectors.py", line 415 in select
  File "/home/seed/p/hl_viz.py", line 10144 in serve

Extension modules: numpy._core._multiarray_umath (total: 1)

== 2026-10-23 09:48:02 Dashboard-Start, PID 1430 -- Stapel folgen nur bei Hänger oder Absturz
"""


class _ProbeJournal(_ProbeUmgebung):
    """Erfundene Umgebung mit Zustand für --journal-dauerhaft: Was die Befehle tun, ändert, was systemd-analyze danach zeigt."""
    def __init__(self, jetzt, boot, vendor: str = "Storage=volatile", spaeter: str | None = None, fehl_bei: str | None = None, pw="probe-pw"):
        super().__init__({}, {}, jetzt, boot, pw=pw)
        self.vendor = vendor; self.spaeter = spaeter; self.fehl_bei = fehl_bei
        self.dropin = False; self.ordner_da = False; self.geschrieben = {}; self.entfernt = []

    def befehl(self, args, timeout=30, sudo=False):
        args = list(args); self.aufrufe.append((args, sudo))
        if self.fehl_bei and self.fehl_bei in args:
            return 1, "probe: Fehler"
        if args[:2] == ["systemd-analyze", "cat-config"]:
            t = "# /etc/systemd/journald.conf\n[Journal]\n#Storage=auto\n\n# /usr/lib/systemd/journald.conf.d/40-probe.conf\n[Journal]\n" + self.vendor + "\n"
            if self.dropin:
                t += "\n# " + JOURNAL_DROPIN + "\n[Journal]\nStorage=persistent\nSystemMaxUse=200M\n"
            if self.spaeter:
                t += "\n# /etc/systemd/journald.conf.d/99-fremd.conf\n[Journal]\n" + self.spaeter + "\n"
            return 0, t
        if args[0] == "install" and args[-1] == JOURNAL_DROPIN:
            self.dropin = args[-2] in self.geschrieben
        elif args[:2] == ["mkdir", "-p"]:
            self.ordner_da = True
        elif args[:2] == ["rm", "-f"] and args[-1] == JOURNAL_DROPIN:
            self.dropin = False
        elif args[:2] == ["rm", "-rf"]:
            self.ordner_da = False
        return 0, ""

    def schreiben(self, pfad, text):
        self.geschrieben[pfad] = text
        return True

    def entfernen(self, pfad):
        self.entfernt.append(pfad); self.geschrieben.pop(pfad, None)

    def da(self, pfad):
        return self.ordner_da if pfad == "/var/log/journal" else False


def _selbsttest_78(ok, tmp: str) -> None:
    """23.78: Hänger-Abzüge lesen, Recorder-Zeiten über Mitternacht, Lebenszeichen je Tabelle, Fenster Ende zu Ende (ganzes Dashboard stand /
    nur Teile), Systemprotokoll dauerhaft ein/aus mit sudo nur über stdin."""
    import contextlib
    import io
    # C9 Hänger-Datei: Start, Abzug mit Namen (neueste Zeile zuletzt), faulthandler Timeout und Abbruch (neueste zuerst), nächster Start
    e = haenger_lesen(HAENGER_PROBE)
    arten = [x["art"] for x in e]
    st_abzug = {k: _stelle(r) for k, r in e[1]["faeden"]}
    st_to = [_stelle(r) for _k, r in e[2]["faeden"]]
    ok("C9 Hänger-Datei: Starts, Abzug mit Namen, faulthandler-Abzug (Timeout) und Abbruch (Aborted) mit je allen Fäden; Stelle = neueste im Projekt",
       arten == ["start", "abzug", "timeout", "fatal", "start"] and e[1]["ts"] == int(datetime(2026, 10, 23, 9, 33, 1).timestamp())
       and [len(x["faeden"]) for x in e] == [0, 2, 3, 2, 0]
       and st_abzug.get("lebenszeichen 0x00007f20a35fe6c0", "").startswith("hl_viz.py:10052 lebenszeichen_runde")
       and st_abzug.get("MainThread 0x00007f20a5768080") == "hl_viz.py:10144 serve ← darin selectors.py:415 select"
       and st_to[1] == "hl_notbremse.py:1645 welt_a_anlegen ← darin dbapi2.py:10 execute" and e[3]["titel"] == "Fatal Python error: Aborted",
       f"{arten}; {st_to[1]}")
    # C10 Recorder-Log: nur Uhrzeiten -- Datum rückwärts vom Ende, über Mitternacht; Zeilen ohne Zeit gehören zur Zeile davor
    jetzt = int(datetime(2026, 10, 24, 0, 20).timestamp())
    rz = recorder_zeilen("[23:50:00] Adressen 1 | Positionen 2\n[23:59:30] Backup läuft …\n           Backup ok: 3400 MB in 610 s\n"
                         "[00:09:59] Adressen 1 | Positionen 2\n", jetzt)
    rz2 = recorder_zeilen("[23:55:00] Adressen 1\n", jetzt)
    ok("C10 Recorder-Log: Datum über Mitternacht richtig, Zeile ohne Zeit hängt an der davor; letzte Zeile später als jetzt -> Vortag",
       [r[0] for r in rz] == [int(datetime(2026, 10, 23, 23, 50).timestamp()), int(datetime(2026, 10, 23, 23, 59, 30).timestamp()),
                              int(datetime(2026, 10, 23, 23, 59, 30).timestamp()), int(datetime(2026, 10, 24, 0, 9, 59).timestamp())]
       and rz2[0][0] == int(datetime(2026, 10, 23, 23, 55).timestamp()), f"{[_zeit(r[0], True) for r in rz]}")
    # C11 Lebenszeichen je Tabelle
    a = int(datetime(2026, 10, 23, 9, 31).timestamp()); b = int(datetime(2026, 10, 23, 14, 28).timestamp())
    p = os.path.join(tmp, "c11.db"); con = sqlite3.connect(p)
    con.execute("CREATE TABLE t (ts INTEGER)"); con.execute("CREATE TABLE weiter (ts INTEGER)"); con.execute("CREATE TABLE selten (ts INTEGER)")
    con.executemany("INSERT INTO t VALUES (?)", [(t,) for t in range(a - 8 * 3600, a, 900)] + [(t,) for t in range(b + 60, b + 3600, 900)])
    con.executemany("INSERT INTO weiter VALUES (?)", [(t,) for t in range(a - 8 * 3600, b + 3600, 900)])
    con.executemany("INSERT INTO selten VALUES (?)", [(a - 7200,), (b + 100,)])
    con.commit()
    z1 = lebenszeichen_zaehlen(con, "t", "ts", a, b); z2 = lebenszeichen_zaehlen(con, "weiter", "ts", a, b)
    z3 = lebenszeichen_zaehlen(con, "selten", "ts", a, b); z4 = lebenszeichen_zaehlen(con, "fehlt", "ts", a, b)
    con.close()
    ok("C11 Lebenszeichen: alle 15 min und nichts in 5 h -> stand (≈20 erwartet); läuft durch -> lief weiter; selten -> kein Urteil; Tabelle fehlt -> None",
       z1["urteil"] == "stand" and z1["n_in"] == 0 and 19 <= z1["erwartet"] <= 21 and z1["vor"] == a - 900 and z1["nach"] == b + 60
       and z2["urteil"] == "lief weiter" and z2["n_in"] == 19 and z3["urteil"] == "zu selten für ein Urteil" and z4 is None,
       f"{z1['urteil']} ({z1['erwartet']:.1f}), {z2['urteil']} ({z2['n_in']}), {z3['urteil']}, {z4}")
    # C12 Fenster Ende zu Ende: Prognose, TradeLabor, Ausblick, Makro, Aktien stehen; Recorder und Notbremse laufen; Welt A fehlt
    def lage(teil_weiter: bool) -> tuple:
        d = os.path.join(tmp, "teil" if teil_weiter else "ganz")
        os.makedirs(d, exist_ok=True)
        jetzt_ = b + 3 * 3600
        def tab(datei, sql, tabelle, spalte, zeiten):
            c = sqlite3.connect(os.path.join(d, datei)); c.execute(sql)
            c.executemany(f"INSERT INTO {tabelle} ({spalte}) VALUES (?)", [(t,) for t in zeiten]); c.commit(); c.close()
        alle15 = [t for t in range(jetzt_ - 7 * 86_400, jetzt_, 900) if not (a < t < b)]
        tab("forecasts.db", "CREATE TABLE forecast (ts INTEGER, coin TEXT)", "forecast", "ts", alle15)
        c = sqlite3.connect(os.path.join(d, "forecasts.db"))
        c.execute("CREATE TABLE labor_ereignis (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, art TEXT)")
        c.execute("CREATE TABLE konfluenz_log (ts INTEGER)")
        ein = lambda t, art: c.execute("INSERT INTO labor_ereignis (ts, art) VALUES (?, ?)", (t, art))   # noqa: E731
        for t in range(a - 6 * 3600, a, 120):                     # vorher live: Takt-Arten und Marktzeit (Kerze eine Minute davor)
            ein(t, "limit" if t % 240 else "stop"); ein(t - 60, "grid")
        if teil_weiter:                                           # das Labor tickt durch die Lücke
            for t in range(a, b, 120):
                ein(t, "limit"); ein(t - 60, "grid")
        else:                                                     # 23.79: Neustart -- ein Takt-Eintrag, dann je Strategie die Kerzen der
            ein(b + 30, "limit")                                  # Lücke nachgeholt (Marktzeit, wie hl_labor._grid_kerzen)
            for art in ("grid", "geschlossen"):
                for t in range(a + 60, b - 60, 600):
                    ein(t, art)
        for t in range(b + 120, b + 3600, 120):
            ein(t, "limit"); ein(t - 60, "grid")
        c.commit(); c.close()
        tab("ausblick.db", "CREATE TABLE au_prognose (erzeugt INTEGER)", "au_prognose", "erzeugt", [t for t in range(a - 6 * 3600, jetzt_, 3600) if not a < t < b])
        tab("makro.db", "CREATE TABLE mk_abruf (ts INTEGER)", "mk_abruf", "ts", [t for t in range(a - 6 * 3600, jetzt_, 1800) if not a < t < b])
        tab("aktien.db", "CREATE TABLE ak_abruf (ts INTEGER)", "ak_abruf", "ts", [t for t in range(a - 6 * 3600, jetzt_, 1800) if not a < t < b])
        tab("hl_liq.db", "CREATE TABLE bars (ts INTEGER, coin TEXT)", "bars", "ts", list(range(a - 6 * 3600, jetzt_, 60)))
        tab("notbremse.db", "CREATE TABLE nb_zustand (ts INTEGER)", "nb_zustand", "ts", list(range(a - 6 * 3600, jetzt_, 60)))
        wl = []
        t_, k_ = a - 3600, 0
        while t_ < b + 1800:
            schlecht = ["  !    Abdeckung        BTC 26%", "  XXX  Poller           90 % der Positionen jünger als 1062 min"]
            wl += ["", f"{datetime.fromtimestamp(t_):%Y-%m-%d %H:%M:%S} — Gesamtstatus: KRITISCH", "-" * 62, "  ok   Verbindung      alle"] + schlecht
            wl += (["  ok   Backup          vor 0.1 h, 3400 MB in /m/dbbackup"] if a <= t_ <= a + 900 else [])
            wl += (["  XXX  Dashboard       127.0.0.1:8765 antwortet nicht (TimeoutError), obwohl der Dienst läuft"] if k_ in (20, 21) else [])
            k_ += 1
            t_ += 900 if k_ == 30 else (337 if k_ in (21, 22) else 302)        # eine Prüfung 15 min verzögert; Dashboard hängt: +35 s
        rz_ = [(t, f"[{datetime.fromtimestamp(t):%H:%M:%S}] Adressen 1 | Positionen 2") for t in range(a - 3 * 3600, b + 3600, 600)]
        rz_ += [(a + 30, f"[{datetime.fromtimestamp(a + 30):%H:%M:%S}] Backup läuft …"), (a + 30.5, "           Backup ok: 3400 MB in 610 s")]
        rl = "\n".join(z for _t, z in sorted(rz_))
        befehle = {(("systemctl", "cat", "hl-watchdog"), False): (0, "[Service]\nStandardOutput=append:/l/watchdog.log\n"),
                   (("systemctl", "cat", "hl-recorder"), False): (0, "[Service]\nStandardOutput=append:/l/recorder.log\n"),
                   (("systemctl", "cat", "hl-dashboard"), False): (0, "[Service]\nStandardOutput=append:/l/dashboard.log\n"),
                   (("systemctl", "show", "hl-dashboard", "WatchdogUSec"), False): (0, "WatchdogUSec=15min\nNRestarts=1\nResult=watchdog\n")}
        log = "\n".join(f"{datetime.fromtimestamp(b - 60 + i):%Y-%m-%d %H:%M:%S} " + z for i, z in enumerate(
            ["Lebenszeichen: Webserver antwortet nicht (Versuch 1 seit 14:27:00)", "Dashboard: http://0.0.0.0:8765"]))
        dateien = {"/l/watchdog.log": "\n".join(wl), "/l/recorder.log": rl, "/l/dashboard.log": log,
                   "/l/dashboard_haenger.log": HAENGER_PROBE.replace("2026-10-23 09:", f"{datetime.fromtimestamp(jetzt_ - 3600):%Y-%m-%d} 09:")}
        U = _ProbeUmgebung(befehle, dateien, jetzt_, b)
        puffer = io.StringIO()
        with contextlib.redirect_stdout(puffer):
            erg = bericht(U, os.path.join(d, "hl_liq.db"))
        g0 = max(t for t in alle15 if t <= a); g1 = min(t for t in alle15 if t >= b)
        return puffer.getvalue(), " | ".join(erg["befund"]), f"Lücke {_zeit(g0, True)} bis {_zeit(g1, True)}"
    text, bf, luecke_soll = lage(False)
    ok("C12 Fenster Ende zu Ende: Lücke aus den Prognosen (rund 5 h), Wächter mit Abständen (1 verzögert), Recorder-Backup, Lebenszeichen "
       "-> das GANZE Dashboard stand, eigene Dienste liefen; Welt A fehlt; Hänger-Schutz an, letzter Neustart durch den Wächter",
       luecke_soll in text and "das GANZE Dashboard stand" in bf and "letztes vor der Lücke 23.10. 09:31:00" in bf
       and "TradeLabor Welt B mit Marktzeit in der Lücke: 60 Einträge, in Schreibreihenfolge 1 Rücksprünge über 15 min, 60 hinter" in text
       and "-> nachgeholt (erst nach der Lücke geschrieben)" in text and "1 verzögert" in bf
       and "Backup läuft" in text and "Datei fehlt (labor_a.db)" in text and "LETZTER NEUSTART DURCH DEN WÄCHTER" in bf
       and "Hänger-Abzüge in 7 Tagen: 3" in bf and "hl_notbremse.py:1645 welt_a_anlegen" in text and "Meldungen „Lebenszeichen“ in 7 Tagen: 1" in text
       and "(dauernd nicht ok im Fenster, nur mit Namen: Abdeckung, Poller)" in text
       and "antwortete aber nicht auf seinem Port in 2 Prüfungen" in bf and "XXX Dashboard 127.0.0.1:8765 antwortet nicht" in text,
       bf[bf.find("Hänger-Schutz"):][:360])
    text2, bf2, _l = lage(True)
    ok("C12b Teil-Hänger: TradeLabor tickt in der Lücke weiter (Takt-Arten) -> nur TEILE standen; Marktzeit-Einträge gleichmäßig geschrieben",
       "nur TEILE standen" in bf2 and "TradeLabor Welt B" in bf2.split("andere liefen weiter")[-1] and "kein Zeichen für Nachholen" in text2,
       bf2[bf2.find("Lebenszeichen"):][:200])
    # C13 Systemprotokoll dauerhaft: ein (Schritte in Reihenfolge, sudo, Passwort nie in den Argumenten, Zwischendatei weg), Fehler hält an,
    # aus, ohne sudo.txt nichts, eine später gelesene Einstellung setzt Storage anders -> nicht erledigt
    j = _ProbeJournal(jetzt, b)
    with contextlib.redirect_stdout(io.StringIO()) as pa:
        r_an = journal_dauerhaft(j, True)
    befehle_an = [a_[0][:2] for a_, s_ in [(x, x[1]) for x in j.aufrufe] if s_]
    sauber = all("probe-pw" not in " ".join(a_) for a_, _s in j.aufrufe)
    with contextlib.redirect_stdout(io.StringIO()):
        r_aus = journal_dauerhaft(j, False)
    j2 = _ProbeJournal(jetzt, b, fehl_bei="systemd-tmpfiles")
    with contextlib.redirect_stdout(io.StringIO()):
        r_fehl = journal_dauerhaft(j2, True)
    j3 = _ProbeJournal(jetzt, b, pw=None)
    with contextlib.redirect_stdout(io.StringIO()):
        r_ohne = journal_dauerhaft(j3, True)
    j4 = _ProbeJournal(jetzt, b, spaeter="Storage=volatile")
    with contextlib.redirect_stdout(io.StringIO()) as p4:
        r_spaet = journal_dauerhaft(j4, True)
    ok("C13 Systemprotokoll dauerhaft: ein (Einstellung, Ordner, Rechte, journald neu, übernehmen; nur mit sudo, Passwort nie in den "
       "Argumenten, Zwischendatei entfernt), aus (Einstellung und Ordner weg); Fehler hält an; ohne sudo.txt nichts; spätere Datei -> nicht erledigt",
       r_an and befehle_an == [["install", "-D"], ["mkdir", "-p"], ["systemd-tmpfiles", "--create"], ["systemctl", "restart"], ["journalctl", "--flush"]]
       and sauber and not j.geschrieben and len(j.entfernt) == 1 and "Storage=persistent" in pa.getvalue() and r_aus and not j.dropin
       and not j.ordner_da and not r_fehl and not any(a_[0] == "systemctl" for a_, _s in j2.aufrufe if _s)
       and not r_ohne and not any(s_ for _a, s_ in j3.aufrufe) and not r_spaet and "ACHTUNG" in p4.getvalue(),
       f"ein {r_an}, aus {r_aus}, Fehler {r_fehl}, ohne Passwort {r_ohne}, spätere Datei {r_spaet}; {befehle_an}")


def _selbsttest_80(ok, tmp: str) -> None:
    """23.80 (U218): Modell der Poller-Kapazität (Bedarf, Ränge, Faktor, Abstände, frischer Wert -- von Hand nachgerechnet), Stufengrenzen
    mit Elite, Pool und gesperrten Konten, Anteil je Runde, Einstellungen aus der Unit, Bericht Ende zu Ende auf erfundener Datenbank,
    Werte gegen den Quelltext des Recorders. 23.86 (U220): gesperrte nicht abgefragt (nicht im Nenner), kleine nur nach eigenem Handel,
    „groß“ ab 500.000 USD, Schalter --klein-regelmaessig; U231: Gegenprobe Pool wie der Recorder, Abstände aus dem Alter zurückgerechnet
    (beschreibend), vom Recorder gemessene Abstände gegen das Modell, Anteil zu alter Positionen bei ähnlicher Laufzeit."""
    import contextlib
    import io
    e = dict(POLLER_STANDARD)
    konten = ([(30e6, None)] * 74 + [(30e6, "Pool")] + [(600e3, None)] * 2000 + [(300e3, None)] * 430 + [(50e3, None)] * 6787
              + [(5e3, None)] * 50_000 + [(0.0, "Elite")] * 20 + [(100e3, "Pool")] * 300 + [(1e6, "gesperrt")] * 40
              + [(10e3, "gesperrt")] * 10 + [(0.0, None)] * 5)
    m = poller_modell(konten, e)
    # von Hand: Budget 280·60·19/23 (23 je Runde, 14 + 5 für Konten mit Position); Rang 0: Wale 75·60 = 4.500 (einer davon Pool über
    # 20 Mio), Elite 20·60 = 1.200; Rang 1: groß (ab 500.000) 2.000·20 = 40.000, Pool 300·6 = 1.800, mittel (430 zwischen 250.000 und
    # 500.000 und 6.787) 7.217·2 = 14.434; klein nur nach eigenem Handel (kein Bedarf); gesperrt nicht abgefragt (kein Bedarf, nicht im
    # Nenner von „frisch“; die 10 unter 25.000 USD sind gar keine Stufe)
    budget = 280 * 60 * 19 / 23
    F = (40_000 + 1_800 + 14_434) / (budget - 5_700)
    W = 75 * 30e6 + 2000 * 600e3 + 430 * 300e3 + 6787 * 50e3 + 50_000 * 5e3 + 300 * 100e3
    frisch = (75 * 30e6 + 2000 * 600e3 * min(1, 3600 / (180 * F)) + 300 * 100e3 * min(1, 3600 / (600 * F))
              + (430 * 300e3 + 6787 * 50e3) * min(1, 3600 / (1800 * F))) / W
    m2 = poller_modell(konten, e, klein_regelmaessig=True)
    F2 = (40_000 + 1_800 + 14_434 + 25_000) / (budget - 5_700)
    m3 = poller_modell(konten, dict(e, waerme=1.5), abfragen_min=200, dex=1.25)
    m4 = poller_modell(konten, dict(e, klein_nach_handel=False))
    S = m["stufen"]
    ok("C14 Modell der Poller-Kapazität von Hand nachgerechnet: Budget 82,6 % der Runde, Rang 0 (Wale, Elite) voll, Rang 1 (groß ab "
       "500.000, Pool, mittel) gemeinsam gedehnt; kleine nur nach eigenem Handel (kein Bedarf, zählen als nicht frisch), gesperrte nicht "
       "abgefragt und nicht im Nenner; frischer Positionswert; mit regelmäßigen kleinen Konten größerer Faktor (Parameter und Einstellung); "
       "gemessene Rate, Dexe und Wärme-Faktor",
       abs(m["budget"] - budget) < 1e-6 and abs(m["bedarf"] - (5_700 + 56_234)) < 1e-6 and abs(m["faktor"] - F) < 1e-9
       and sorted(m["faktoren"]) == [0, 1] and m["faktoren"][0] == 1.0
       and [S[k]["n"] for k in STUFEN] == [75, 20, 2000, 300, 7217, 50_000, 40]
       and S["Wale"]["intervall"] == 60 and S["Elite"]["intervall"] == 60 and abs(S["Pool"]["intervall"] - 600 * F) < 1e-6
       and abs(S["mittel"]["intervall"] - 1800 * F) < 1e-6 and S["klein"]["intervall"] is None and S["klein"]["bedarf"] == 0
       and S["gesperrt"]["intervall"] is None and S["gesperrt"]["bedarf"] == 0 and S["gesperrt"]["anteil_wert"] is None
       and m["gesperrt_wert"] == 40e6 and m["gesperrt_n"] == 40 and abs(m["gesamt_wert"] - W) < 1e-3
       and abs(m["frisch_wert"] - frisch) < 1e-9 and abs(m2["faktor"] - F2) < 1e-9 and abs(m2["stufen"]["klein"]["intervall"] - 7200 * F2) < 1e-6
       and abs(m4["faktor"] - F2) < 1e-9
       and abs(m3["budget"] - 200 / 1.25 * 60 * 19 / 23) < 1e-6 and abs(m3["bedarf"] - (5_700 + 56_234) / 1.5) < 1e-6
       and abs(m3["stufen"]["groß"]["intervall"] - 270 * m3["faktor"]) < 1e-6,
       f"Faktor {m['faktor']:.3f} (von Hand {F:.3f}), mit regelmäßigen kleinen {m2['faktor']:.3f}, frisch {m['frisch_wert'] * 100:.1f} % "
       f"(von Hand {frisch * 100:.1f} %), gemessen 200/min · Dexe 1,25 · Wärme 1,5: Faktor {m3['faktor']:.2f}")
    st_ = [poller_stufe(v, e, so) for v, so in ((20e6, None), (19_999_999, None), (500e3, None), (499_999, None), (250e3, None), (25e3, None),
                                                (24_999, None), (0.0, None), (30e6, "Pool"), (19e6, "Pool"), (0.0, "Pool"), (0.0, "Elite"),
                                                (30e6, "Elite"), (25e3, "gesperrt"), (24_999, "gesperrt"), (30e6, "gesperrt"))]
    jobs = json.dumps({"Recorder": {"last": 1, "info": "x" * 50}, "Adress-Poller": {"last": 2, "takt": 5, "info": "23/23 Adressen je Runde · "
                                                                                   "davon Pool 2 (9 % der letzten 10 min)"}})
    unit_alt = "[Service]\nExecStart=/p/python /r/hl_recorder.py --coins BTC --hot-notional 250000 --klein-regelmaessig --db /d\n"
    ok("C15 Stufengrenzen (genau 20 Mio = Wal, 500.000 = groß, darunter bis 25.000 mittel, darunter klein; Pool unter 20 Mio, Elite immer, "
       "gesperrt nur ab 25.000), Takte (gesperrt keiner, klein nur mit --klein-regelmaessig), Anteil je Runde, Einstellungen aus der Unit "
       "samt Schalter ohne Wert (auch als letztes Wort), Text des Pollers aus meta 'jobs' (auch abgeschnitten)",
       st_ == ["Wale", "groß", "groß", "mittel", "mittel", "mittel", "klein", None, "Wale", "Pool", "Pool", "Elite", "Elite", "gesperrt", None,
               "gesperrt"]
       and poller_takt("gesperrt", e) is None and poller_takt("klein", e) is None and poller_takt("klein", dict(e, klein_nach_handel=False)) == 7200
       and abs(poller_anteil_a(280) - 19 / 23) < 1e-12 and poller_anteil_a(100) == 0.8 and abs(poller_anteil_a(500) - 36 / 41) < 1e-12
       and poller_einstellungen("[Service]\nExecStart=/p/python /r/hl_recorder.py --coins BTC --polls-per-min 300 --hot-refresh 240 "
                                "--max-pos-age 7200 --db /d\n") == dict(e, polls_per_min=300.0, hot_refresh=240.0, max_pos_age=7200.0)
       and poller_einstellungen(unit_alt) == dict(e, hot_notional=250e3, klein_nach_handel=False)
       and poller_einstellungen("[Service]\nExecStart=/p/python /r/hl_recorder.py --db /d --klein-regelmaessig\n") == dict(e, klein_nach_handel=False)
       and poller_einstellungen(None) == e and _poller_info(jobs) == "23/23 Adressen je Runde · davon Pool 2 (9 % der letzten 10 min)"
       and _poller_info(jobs[:-2]) == "23/23 Adressen je Runde · davon Pool 2 (9 % der letzten 10 min)" and _poller_info(None) is None,
       f"{st_[:8]} · Pool/Elite/gesperrt {st_[8:]} · 280/min -> {poller_anteil_a(280) * 100:.1f} %")
    # Ende zu Ende auf erfundener Datenbank (mit Elite, Pool, gesperrten und geschützten Konten, Dexen, Rate des Pollers, Text der Runde)
    d = os.path.join(tmp, "poller"); os.makedirs(d, exist_ok=True)
    dbp = os.path.join(d, "hl_liq.db"); c = sqlite3.connect(dbp)
    c.execute("CREATE TABLE addresses (addr TEXT PRIMARY KEY, first_seen INTEGER, last_trade INTEGER, last_poll INTEGER DEFAULT 0, "
              "notional REAL DEFAULT 0, misses INTEGER DEFAULT 0, dexes TEXT DEFAULT '', pos_value REAL DEFAULT 0)")
    c.execute("CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, "
              "n_stale_dropped INTEGER, age_median INTEGER, age_p90 INTEGER, backlog INTEGER, uptime INTEGER)")
    c.execute("CREATE TABLE coverage (ts INTEGER, coin TEXT, tracked_size REAL, oi REAL, ratio REAL, PRIMARY KEY (ts, coin))")
    c.execute("CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL)")
    c.execute("CREATE TABLE pool_accounts (addr TEXT PRIMARY KEY, seit INTEGER, zuletzt_erfuellt INTEGER, account_value REAL, vlm_1d REAL, "
              "vlm_7d REAL, pnl_7d REAL, roi_7d REAL, name TEXT, aktualisiert INTEGER, pnl_1d REAL, roi_1d REAL, pnl_30d REAL, roi_30d REAL)")
    c.execute("CREATE TABLE api_load (ts INTEGER, quelle TEXT, weight INTEGER, PRIMARY KEY (ts, quelle))")
    c.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    jetzt = int(datetime(2026, 10, 23, 21, 0).timestamp())
    adr = ([(f"a{i}", 30e6, "") for i in range(30)] + [(f"b{i}", 500e3, ",xyz" if i < 100 else "") for i in range(300)]
           + [(f"c{i}", 50e3, "") for i in range(1000)] + [(f"k{i}", 5e3, "") for i in range(2000)] + [(f"e{i}", 0.0, "") for i in range(10)]
           + [(f"p{i}", 100e3, "") for i in range(52)] + [(f"g{i}", 1e6, "") for i in range(21)])
    c.executemany("INSERT INTO addresses (addr, first_seen, last_trade, last_poll, dexes, pos_value) VALUES (?,0,?,?,?,?)",
                  [(a_, (jetzt - 600) * 1000 if a_ in ("k0", "k1", "k2", "k3", "k4", "k5", "k6", "k7", "k8", "k9", "g3", "p7") else
                    (jetzt - 30_000) * 1000 if a_ in ("c0", "c1") else 0, jetzt - (i % 50) * 120 - 30, dx, v) for i, (a_, v, dx) in enumerate(adr)])
    c.executemany("INSERT INTO addresses (addr, first_seen, last_trade, last_poll, pos_value) VALUES (?,0,0,0,50000)", [(f"n{i}",) for i in range(5)])
    # leere Adressen: 7 haben seit ihrer letzten Abfrage gehandelt (Gruppe C), eine nicht; eine gesperrte leere zählt nicht mit
    c.executemany("INSERT INTO addresses (addr, first_seen, last_trade, last_poll, pos_value) VALUES (?,0,?,?,0)",
                  [(f"z{i}", (jetzt - 100) * 1000, jetzt - 3600) for i in range(7)] + [("z7", (jetzt - 7200) * 1000, jetzt - 3600),
                                                                                    ("g21", (jetzt - 100) * 1000, jetzt - 3600)])
    c.executemany("INSERT INTO konto_status VALUES (?,?,'',0,'',0,0)", [(f"g{i}", "gesperrt") for i in range(20)] + [("g20", "vorlaeufig"),
                                                                                                                   ("g21", "gesperrt")])
    c.executemany("INSERT INTO pool_accounts (addr, zuletzt_erfuellt, pnl_7d) VALUES (?,?,?)",
                  [(f"p{i}", jetzt - 86_400 if i < 50 else jetzt - 8 * 86_400, float(i)) for i in range(52)]
                  + [("a1", jetzt - 86_400, 100.0), ("e2", jetzt - 86_400, 101.0), ("g4", jetzt - 86_400, 102.0)])
    c.executemany("INSERT INTO api_load VALUES (?,?,?)", [(jetzt - 3 * 3600 + k * 60, q_, w_) for k in range(180) for q_, w_ in
                                                           (("Poller", 480 if k % 3 == 0 else 500), ("Fills", 100))])
    abst_ = {"stunde": jetzt - 3600, "je_stufe": {"Wale": [1700, 61.0], "groß": [120, 600.0], "Pool": [30, 1500.0], "mittel": [40, 9000.0],
                                               "klein": [5, 300.0], "leer": [80, 200.0]}}
    c.executemany("INSERT INTO meta VALUES (?,?)", [("jobs", jobs), ("thermal_interval_factor", "1.00"), ("poller_due_a", "61000"),
                                                    ("poller_due_b", "3"), ("poller_due_c", "4321"), ("poller_vorrang", "5600"),
                                                    ("poller_abstaende", json.dumps(abst_))])
    # zwei Läufe: der vorige ab jetzt − 123.600 s (Snapshots 0–149, Laufzeit 1,0–25,8 h, 80 % zu alt), der laufende ab jetzt − 28.680 s
    # (Snapshots 157–199, Laufzeit 0,8–7,8 h, 70 %); 150–156 ohne Snapshot (Neustart)
    for k in list(range(150)) + list(range(157, 200)):
        ts = jetzt - (200 - k) * 600
        up = 3600 + 600 * k if k < 150 else ts - (jetzt - 28_680)
        c.execute("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", (ts, 319_000, 9_300, 2_000 if k < 150 else 3_000,
                                                                          8_000 if k < 150 else 7_000, 0, 0, 70_000, up))
        c.execute("INSERT INTO coverage VALUES (?,?,?,?,?)", (ts, "BTC", 1, 1, 0.26))
    c.commit(); c.close()
    cf = sqlite3.connect(os.path.join(d, "forecasts.db"))
    cf.execute("CREATE TABLE learned (coin TEXT, key TEXT, value TEXT, ts INTEGER, PRIMARY KEY (coin, key))")
    cf.executemany("INSERT INTO learned VALUES (?,?,?,0)", [("BTC", "elite", json.dumps([f"E{i}" for i in range(6)])),
                                                           ("ETH", "elite", json.dumps([f"e{i}" for i in range(4, 10)] + [7])), ("BTC", "scores", "{}")])
    cf.commit(); cf.close()
    U = _ProbeUmgebung({(("systemctl", "cat", "hl-recorder"), False): (0, "[Service]\nExecStart=/p/python /r/hl_recorder.py --coins BTC --db /d\n")},
                       {"/probe/labels.json": json.dumps({"g0": {"sperre": False}, "a5": {"sperre": True}, "x": {"name": "y"}})}, jetzt, jetzt - 86_400)
    puffer = io.StringIO()
    with contextlib.redirect_stdout(puffer):
        r = poller_bericht(U, dbp)
    t = puffer.getvalue()
    S = r["modell"]["stufen"] if r.get("ok") else {}
    g = {"Wale": 60, "Elite": 60, "groß": 20, "Pool": 6, "mittel": 2}
    n_soll = {"Wale": 29, "Elite": 10, "groß": 301, "Pool": 50, "mittel": 1002, "klein": 2000, "gesperrt": 21}
    dex_soll = (sum(g[k] * n_soll[k] for k in g) + 100 * 20) / sum(g[k] * n_soll[k] for k in g)
    # Statuszeile von Hand: 29·60 + 10·60 + 50·6 + 301·20 + 1002·2 = 10.664 je Stunde gegen 280·60·19/23 = 13.878 -> 77 %
    # Gegenprobe von Hand: Pool-Mitglieder p0..p49 im Pool-Takt, a1 als Wal (60/h), e2 als Elite (60/h), g4 gesperrt (0) -- gegen alle
    # abgefragten Konten je Stunde, 250 / Dexe · 60 (der Recorder zählt Adressen je Runde, nicht Abfragen)
    F_ = r["modell"]["faktor"] if r.get("ok") else 1.0
    pool_soll = (50 * 3600 / (600 * F_) + 60 + 60) / (250 / dex_soll * 60) * 100
    ok("C16 Bericht Poller-Kapazität Ende zu Ende: Elite aus forecasts.db (Groß-/Kleinschreibung), Pool nur in der Hysterese, gesperrt aus "
       "konto_status und labels.json (auch geschützt), nie abgefragte getrennt, gemessene Rate (Median 250/min), Dexe, Gegenprobe Pool wie "
       "der Recorder (Mitglieder als Wal und Elite mitgezählt, gesperrte nicht), Formel der Statuszeile wie das Modell, Gruppe C (wartende "
       "leere und kleine, ohne Gesperrte), Handel je Stufe, Snapshot bei ähnlicher Laufzeit, Abdeckung, Varianten, Befund",
       r.get("ok") and {k: S[k]["n"] for k in STUFEN} == n_soll and r["rate"] == 250 and abs(r["dex"] - dex_soll) < 1e-9
       and "5 Konten noch nie abgefragt" in t and "Gegenprobe Pool (jedes Mitglied" in t and abs(r["pool_modell"] - pool_soll) < 1e-9
       and "gemessen 9 % (letzte 10 min laut Recorder)" in t and abs(r["auslastung"] - 10_664 / (280 * 60 * 19 / 23)) < 1e-12
       and "Auslastung 77 % (29 Wale / 10 Elite / 50 Pool / 301 groß / 1002 mittel)" in t
       and r["leer_wartend"] == 7 and r["klein_wartend"] == 10 and "7 leere und 10 kleine haben seit ihrer letzten Abfrage gehandelt" in t
       and r["handel"]["klein"] == [10, 10] and r["handel"]["mittel"] == [0, 2] and "klein 10 / 10" in t
       and "Letzter Snapshot: 3000 Positionen drin, 7000 zu alt ausgelassen (70 % bei 7.8 h Laufzeit; 7-Tage-Median früherer Läufe bei ähnlicher "
       "Laufzeit 80 %, n=23); überfällig 70000" in t
       and r["gemessen"].get("groß", (0, 0, 0))[:2] == (600.0, 120) and abs(r["gemessen"]["groß"][2] - 600 / S["groß"]["intervall"]) < 1e-12
       and r["gemessen"]["klein"][2] is None and "klein alle 5 min (n 5; nach eigenem Handel, kein Takt)" in t
       and "Abstände gemessen (Recorder, Stunde ab 23.10. 20:00" in t and r["vorrang"] == 5600
       and "5600 Abfragen seit dem Start, etwa 718 je Stunde" in t
       and "BTC 26 % (26 %)" in t and "so wie eingestellt" in t and "Gesperrte Konten ab 25 Tsd USD: 21 Konten" in t
       and "Kleine Konten (unter 25 Tsd USD): 2000 Konten" in t and "nur nach eigenem Handel, sonst höchstens täglich" in t
       and "gesperrt: nicht abgefragt (seit 23.86)" in t and "nicht abgefragt" in t.split("== Stufen")[1].split("\n   Bedarf ")[0]
       and "Letzte Runde laut Recorder: 23/23 Adressen je Runde" in t and "Rang 2" not in t and "ENDE" in t
       and "Letzte Auswahl laut Recorder: Gruppe A 61000 Konten über ihrem Takt · B 3 nie abgefragt · C 4321 leere und kleine" in t,
       f"{ {k: S[k]['n'] for k in STUFEN} if S else r} · Rate {r.get('rate')} · Dexe {r.get('dex') or 0:.3f} (soll {dex_soll:.3f}) · Pool "
       f"{r.get('pool_modell') or 0:.2f} % (soll {pool_soll:.2f}) · wartend {r.get('leer_wartend')}/{r.get('klein_wartend')}")
    # Werte gegen den Quelltext des Recorders: ändert jemand dort Takte, Stufen oder die Reihenfolge, wird diese Probe rot
    q = open(os.path.join(HIER, "hl_recorder.py"), encoding="utf-8").read()

    def konst(name: str):
        m_ = re.search(rf"^{name} = ([0-9_ *]+)", q, re.M)
        if not m_:
            return None
        v = 1
        for x in m_.group(1).split("*"):
            v *= int(x.strip().replace("_", ""))
        return v

    def arg(name: str):
        m_ = re.search(rf'"{re.escape(name)}", type=\w+, default=([0-9_.]+|[A-Z_]+)', q)
        if not m_:
            return None
        x = m_.group(1)
        return konst(x) if x[0].isalpha() else float(x.replace("_", ""))
    ist = {k: konst(k) for k in ("POOL_POLL_S", "KLEIN_TAGESPRUEFUNG_S", "POOL_HYSTERESE_TAGE", "POOL_DECKEL")}
    soll = {"POOL_POLL_S": POOL_POLL_S, "KLEIN_TAGESPRUEFUNG_S": KLEIN_TAGESPRUEFUNG_S, "POOL_HYSTERESE_TAGE": POOL_HYSTERESE_TAGE,
            "POOL_DECKEL": POOL_DECKEL}
    args_ist = {k: arg(a_) for a_, k in POLLER_ARGS.items()}
    i0 = q.find("    def due_addresses(")
    body = q[i0:q.find("\n    def ", i0 + 10)] if i0 >= 0 else ""
    reihe = [body.find(x) for x in ("if addr in self.gesperrt:", "if not last_poll:", "if addr in elite:",
                                    "if addr in self.pool_addrs and pos_value < c.whale_notional:",
                                    "if pos_value >= c.min_notional or (pos_value > 0 and not klein_c):")]
    teile = ["x_ref = c.cold_refresh * 4 * f", "n_a, n_b = int(limit * 0.65), int(limit * 0.25)", "A.append((0, -overdue, addr))",
             "A.append((1, -overdue, addr))", "for pool in (A, C, B):", "klein_c = getattr(c, \"klein_nach_handel\", True)",
             "elif last_trade / 1000 > last_poll or now - last_poll > KLEIN_TAGESPRUEFUNG_S:",
             "if last_trade / 1000 > last_poll and vorrang_ab > 0 and umsatz.get(addr, 0.0) >= vorrang_ab:",
             "A.append((1, -VORRANG_UEBERFAELLIG + u_, addr)); vorrang.add(addr)", "for u_, addr in V[:max(1, int(limit * VORRANG_ANTEIL))]:"]
    sonst = ["want = max(int(rate / 12), 10)", "if age > self.cfg.max_pos_age:", "SELECT addr FROM pool_accounts WHERE zuletzt_erfuellt >= ? "
             "ORDER BY pnl_7d DESC LIMIT ?", "status IN ('gesperrt','vorlaeufig')", "SELECT value FROM learned WHERE key='elite'",
             '"--klein-regelmaessig", action="store_true"', "klein_nach_handel=not args.klein_regelmaessig",
             "self.seen_address(addr, ts, dex, px * sz)", "VORRANG_UEBERFAELLIG = 1e9", "self.addr_umsatz.pop(addr, None)",
             "self.abstand_messen(addr, now - vorher_ok)", "VORRANG_ANTEIL = 0.10", "self.erfolg_at[addr] = now",
             "age = now - self.erfolg_at.get(addr, self.polled_at.get(addr, 0))", "FEHL_AUSLOESER_MAX = 3",
             '("poller_abstaende", json.dumps(self.abst_letzte, ensure_ascii=False))', '("poller_vorrang", str(self.stats.get("poller_vorrang", 0)))',
             "klein_nach_handel: bool = True", "have = c.polls_per_min * 60 * (int(want * 0.65) + int(want * 0.25)) / want"]
    ok("C17 Werte und Reihenfolge wie im Quelltext des Recorders (Takt des Pools, Tagesprüfung der leeren und kleinen Konten, Pool-Hysterese "
       "und -Deckel, Standardwerte der Aufrufparameter mit „groß“ ab 500.000, Schalter --klein-regelmaessig, Reihenfolge gesperrt -> nie "
       "abgefragt -> Elite -> Pool -> Positionswert, keine Abfrage gesperrter Konten mehr (kein SPERRE_POLL_S, kein Rang 2), Anteile je "
       "Runde, Snapshot-Grenze, Formel der Statuszeile)",
       ist == soll and all(args_ist[k] == POLLER_STANDARD[k] for k in args_ist) and all(i_ >= 0 for i_ in reihe) and reihe == sorted(reihe)
       and all(x in body for x in teile) and "A.append((2, " not in body and konst("SPERRE_POLL_S") is None and "SPERRE_POLL_S" not in body
       and all(x in q for x in sonst),
       f"{ist} · Parameter {sum(args_ist[k] == POLLER_STANDARD[k] for k in args_ist)}/{len(args_ist)} · Reihenfolge {reihe == sorted(reihe)} · "
       f"fehlend {[x for x in teile if x not in body] + [x for x in sonst if x not in q]}")
    # U231: Rückrechnung der Abstände aus dem gespeicherten Alter, von Hand
    V, T = 1080, 1800
    alter = {"Wale": [V + 10 * (j % 3) for j in range(12)], "groß": [V + (j + 0.5) / 100 * T for j in range(100)],
             "mittel": [V + (j + 0.5) / 19 * 7200 for j in range(19)], "gesperrt": [2_000_000] * 30}
    vz = poller_versatz(alter["Wale"])
    rk = poller_rueckrechnung(alter, vz)
    t_soll = (2 * ((50 + 0.5) / 100 * T) + ((90 + 0.5) / 100 * T) / 0.9) / 2
    ok("C18 (U231) Abstand aus dem Alter zurückgerechnet: Versatz = Alter der Wale (nur wenn eng beieinander, mindestens 5 und unter 65 min), "
       "Median = V + T/2 und 90 % = V + 0,9 T, Mittel beider Schätzungen; Stufen unter 20 Konten, Wale, Elite und gesperrte ausgelassen",
       vz == V + 10 and abs(rk.get("groß", 0) - (t_soll - 10 * (2 + 1 / 0.9) / 2)) < 1e-6 and abs(rk["groß"] / T - 1) < 0.02
       and set(rk) == {"groß"} and poller_versatz([V] * 4) is None and poller_versatz([V] * 9 + [V + 400] * 3) is None
       and poller_versatz([4000] * 10) is None and poller_rueckrechnung(alter, None) == {},
       f"Versatz {vz}, groß {rk.get('groß', 0):.1f} s (wahr {T}), Stufen {sorted(rk)}")
    # U231: Gegenprobe Pool wie der Recorder zählt, von Hand
    kp = [(30e6, "Pool")] * 3 + [(0.0, "Elite")] * 2 + [(100e3, "Pool")] * 10 + [(1e6, "gesperrt")]
    mp = poller_modell(kp + [(600e3, None)] * 200, e, abfragen_min=120)
    soll_p = (3 * 60 + 2 * 60 + 10 * 3600 / mp["stufen"]["Pool"]["intervall"]) / (120 * 60) * 100
    alt_p = (10 * 3600 / mp["stufen"]["Pool"]["intervall"]) / (120 * 60) * 100
    ok("C19 (U231) Gegenprobe Pool zählt wie der Recorder: Mitglieder als Wal und Elite im Minutentakt mit, gesperrte nie; bis 23.85 nur die "
       "Stufe „Pool“",
       abs(poller_pool_anteil(kp, mp, e, 120, 1.0) - soll_p) < 1e-9 and poller_pool_anteil(kp, mp, e, 120, 1.0) > 2 * alt_p
       and abs(poller_pool_anteil([(100e3, "Pool")] * 10, mp, e, 120, 1.0) - alt_p) < 1e-9,
       f"{poller_pool_anteil(kp, mp, e, 120, 1.0):.2f} % (von Hand {soll_p:.2f} %; nur die Stufe {alt_p:.2f} %)")
    # U231: Anteil zu alter Positionen nur bei ähnlicher Laufzeit
    sn = ([(0, 50, 50, 0, 3600)] + [(0, 30, 70, 0, 7 * 3600)] + [(0, 20, 80, 0, int(7.5 * 3600))] + [(0, 10, 90, 0, 24 * 3600)] * 5
          + [(0, 0, 0, 0, int(7.2 * 3600))] + [(0, 40, 60, 0, 1800)])
    med_, n_ = poller_gleiche_laufzeit(sn, 7.3 * 3600)
    eigen = [(100_000 + 600 * k, 25, 75, 0, 600 * k + 900) for k in range(40, 50)]   # laufender Lauf: Start 99.100 bei allen
    ok("C20 (U231) Anteil zu alter Positionen im 7-Tage-Verlauf nur bei ähnlicher Laufzeit (± 25 %, mindestens ± 1 h, ab 45 min, ohne leere "
       "Snapshots) und ohne den laufenden Lauf (Start ± 120 s)",
       n_ == 2 and med_ == 0.8 and poller_gleiche_laufzeit(sn, 24 * 3600) == (0.9, 5) and poller_gleiche_laufzeit(sn, None) == (None, 0)
       and poller_gleiche_laufzeit(sn, 100 * 3600) == (None, 0)
       and poller_gleiche_laufzeit(sn + eigen, 7.3 * 3600, 99_100) == (0.8, 2) and poller_gleiche_laufzeit(sn + eigen, 7.3 * 3600)[1] > 2,
       f"bei 7,3 h: Median {med_}, n={n_}; mit eigenem Lauf ohne Ausschluss n={poller_gleiche_laufzeit(sn + eigen, 7.3 * 3600)[1]}")
    # U231: vom Recorder gemessene Abstände -- Verhältnis zum Modell erst, wenn die Laufzeit am Ende der Stunde das Doppelte des Abstands ist
    m21 = {"stufen": {"groß": {"intervall": 1200.0}, "mittel": {"intervall": 9000.0}, "klein": {"intervall": None}}}
    ab21 = {"stunde": 1_800_000_000, "je_stufe": {"groß": [50, 1300.0], "mittel": [10, 8000.0], "klein": [3, 400.0], "leer": [9, 100.0]}}
    t_lang, g_lang = poller_abstaende_text(ab21, m21, [(1_800_003_000, 0, 0, 0, 30_000)])      # Beginn der Stunde: 27.000 s Laufzeit
    t_kurz, g_kurz = poller_abstaende_text(ab21, m21, [(1_800_003_000, 0, 0, 0, 20_000)])      # 17.000 s (am Ende wären es 20.600)
    ab21b = {"stunde": 1_800_000_000, "je_stufe": {"groß": [50, 5000.0]}}
    _t, g_mess = poller_abstaende_text(ab21b, m21, [(1_800_003_000, 0, 0, 0, 10_000)])        # 7.000 s: Messung 5.000 > Modell 1.200
    ok("C21 (U231) gemessene Abstände gegen das Modell: Verhältnis nur, wenn die Laufzeit zu Beginn der Stunde mindestens das Doppelte "
       "des größeren von Modell und Messung ist; leere und kleine ohne Takt nur beschreibend; ohne Messung kein Text",
       abs(g_lang["groß"][2] - 1300 / 1200) < 1e-12 and abs(g_lang["mittel"][2] - 8000 / 9000) < 1e-12 and g_lang["klein"][2] is None
       and abs(g_kurz["groß"][2] - 1300 / 1200) < 1e-12 and g_kurz["mittel"][2] is None and "mittel alle 2.2 h (n 10) gegen Modell 2.5 h: "
       "Laufzeit seit dem Neustart zu kurz" in t_kurz and "leer alle 2 min (n 9; nach eigenem Handel, kein Takt)" in t_lang
       and g_mess["groß"][2] is None
       and poller_abstaende_text({}, m21, []) == (None, {}),
       f"lang {g_lang}; kurz {g_kurz}")


def selbsttest(verbose: bool = True) -> bool:
    import contextlib
    import io
    pruef = []

    def ok(name, bed, text=""):
        pruef.append(bool(bed))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    t0 = time.time()
    if verbose:
        print("check_system -- Selbsttest (erfundene Eingaben, ohne systemd)", flush=True)
    jetzt = int(datetime(2026, 10, 23, 14, 40).timestamp()); boot = int(datetime(2026, 10, 23, 14, 25).timestamp())
    # Wächter-Log: ok, dann KRITISCH (Dashboard nicht aktiv), dann eine Stunde nichts bis zum Neustart
    log = []
    for k, (st, zeilen) in enumerate((("ok", []), ("KRITISCH", ["  XXX  Dienste          hl-dashboard (activating)"]),
                                      ("WARNUNG", ["  !    Speicherplatz    noch 8 %"]), ("ok", []))):
        ts = boot - 3 * 3600 + k * 300
        log += ["", f"{datetime.fromtimestamp(ts):%Y-%m-%d %H:%M:%S} — Gesamtstatus: {st}", "-" * 62, "  ok   Verbindung      Info 120 ms"] + zeilen
    bl = wache_bloecke("\n".join(log))
    ok("Wächter-Log: Prüfungen und Meldungen ≠ ok erkannt", len(bl) == 4 and bl[1][1] == "KRITISCH" and "hl-dashboard" in bl[1][2][0]
       and bl[2][2] == ["!    Speicherplatz    noch 8 %"] and bl[3][2] == [], f"{[(b[1], len(b[2])) for b in bl]}")
    # Verlauf: jede Minute, Lücke von 47 min, letzte Werte vor 2 min
    v = ([[t, 55.0, 30, 2400 - (t - jetzt + 6 * 3600) // 60 * 10, 700 + (t - jetzt + 6 * 3600) // 60 * 10] for t in range(jetzt - 6 * 3600, jetzt - 3 * 3600, 60)]
         + [[t, 50.0, 12, 5200, 650] for t in range(jetzt - 3 * 3600 + 47 * 60, jetzt - 60, 60)])
    lu = verlauf_luecken(v, jetzt)
    ok("Verlauf: längste Lücke mit Zeit und Dauer; Lücke bis jetzt zählt mit", len(lu) == 1 and lu[0][2] == 48 * 60
       and verlauf_luecken(v[:100], jetzt)[0][1] == jetzt, f"{[(_zeit(a), _zeit(b), _dauer(s)) for a, b, s in lu]}")
    ok("Strom: get_throttled entschlüsselt", gedrosselt("throttled=0x50005") == ["Unterspannung jetzt", "gedrosselt jetzt", "Unterspannung seit dem Start",
                                                                                 "gedrosselt seit dem Start"]
       and gedrosselt("throttled=0x0") == [] and gedrosselt("vcgencmd: nicht vorhanden") == ["nicht lesbar"], f"{gedrosselt('throttled=0x50005')}")
    lb_kopf = ("IDX BOOT ID                          FIRST ENTRY                 LAST ENTRY\n"
               " -1 0123456789abcdef0123456789abcdef Thu 2026-10-22 09:00:01 CEST Fri 2026-10-23 13:02:11 CEST\n"
               "  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST Fri 2026-10-23 14:40:00 CEST")
    st = starts_lesen(lb_kopf); st2 = starts_lesen("  0 fedcba9876543210fedcba9876543210 Fri 2026-10-23 14:25:03 CEST—Fri 2026-10-23 14:40:00 CEST")
    ok("Journal: Liste der Starts (mit und ohne Kopfzeile)", [s[0] for s in st] == [-1, 0] and len(st2) == 1 and st2[0][0] == 0,
       f"{[(s[0], s[2][:24]) for s in st]}")
    n, tr = kern_zaehlen(["[  1.0] usb 1-1: USB disconnect, device number 2", "Out of memory: Killed process 1234 (python3)",
                          "hwmon hwmon1: Undervoltage detected!", "INFO: task python3:999 blocked for more than 120 seconds.", "eth0: Link is Up"])
    ok("Kernel: Zeilen je Art gezählt (Speicher, Platte/USB, Strom, Hänger), harmlose nicht", n["Speicher"] == 1 and n["Platte/USB"] == 1
       and n["Strom"] == 1 and n["Hänger"] == 1 and len(tr) == 4, f"{n}")
    ok("Ende des vorigen Starts: sauber gegen abrupt", sauber_beendet(["Oct 23 13:02 systemd-shutdown[1]: Syncing filesystems and block devices."])
       and sauber_beendet(["Reached target System Power Off."]) and not sauber_beendet(["Oct 23 13:02 hl_viz.py[812]: TradeLabor-Takt: 13.0 s"]),
       "systemd-shutdown/Power Off = sauber, sonst abrupt")
    # Journal: ohne Rechte Hinweis → einmal mit sudo; Passwort nie in den Argumenten
    U = _ProbeUmgebung({(("--list-boots",), False): (0, "Hint: You are currently not seeing messages from other users and the system.\n"
                                                        "      Users in groups 'adm', 'systemd-journal' can see all messages.\n" + lb_kopf.splitlines()[2]),
                        (("--list-boots",), True): (0, lb_kopf)}, {}, jetzt, boot)
    t = journal(U, ["--list-boots"])
    ok("Journal: ohne Leserechte einmal mit sudo (Passwort nur über stdin)", len(starts_lesen(t)) == 2 and U.aufrufe[-1][1]
       and "probe-pw" not in " ".join(U.aufrufe[-1][0]) and "Hint" not in t, f"{len(U.aufrufe)} Aufrufe, zuletzt sudo {U.aufrufe[-1][1]}")
    # Ende zu Ende auf erfundener Umgebung
    wlog = "/var/log/hl/watchdog.log"
    befehle = {(("systemctl", "cat", "hl-watchdog"), False): (0, f"[Service]\nStandardOutput=append:{wlog}\n"),
               (("systemctl", "show", "hl-dashboard"), False): (0, "ActiveState=active\nSubState=running\nNRestarts=0\nMemoryCurrent=734003200\n"),
               (("--list-boots",), False): (0, lb_kopf),
               (("-b", "-1", "-u", "hl-dashboard", "-t", "systemd"), False): (0, "2026-10-23T12:10:02+0200 systemd[1]: hl-dashboard.service: Main process exited, "
                                                                               "code=killed, status=9/KILL\n2026-10-23T12:10:22+0200 systemd[1]: "
                                                                               "hl-dashboard.service: Scheduled restart job, restart counter is at 1."),
               (("-b", "-1", "-k"), False): (0, "2026-10-23T12:10:01+0200 kernel: Out of memory: Killed process 812 (python3) total-vm:3123456kB"),
               (("-b", "-1", "-n", "25"), False): (0, "2026-10-23T13:02:11+0200 hl_viz.py[901]: TradeLabor-Takt: 12.1 s"),
               (("vcgencmd", "get_throttled"), False): (0, "throttled=0x50000\n"),
               (("df", "-h"), False): (0, "Filesystem Size Used Avail Use% Mounted on\n/dev/sda1 916G 402G 468G 47% /media/seed/marketdatabase\n")}
    dateien = {wlog: "\n".join(log), "/m/sys_history.json": json.dumps(v), "/proc/meminfo": "MemTotal:  8000000 kB\nMemAvailable: 5000000 kB\n"}
    U2 = _ProbeUmgebung(befehle, dateien, jetzt, boot, ordner={"/probe/berichte": [("2026-10-23_11-58_notbremse_rueckblick_manuell.txt", jetzt - 9000, 4096)]})
    puffer = io.StringIO()
    with contextlib.redirect_stdout(puffer):
        erg = bericht(U2, "/m/hl_liq.db")
    text = puffer.getvalue(); bf = " | ".join(erg["befund"])
    ok("Bericht Ende zu Ende: Befund mit Journal, Absturz durch systemd, Kernel (Speicher), abruptem Ende, Wächter, Lücke, Strom, Berichten",
       "Journal dauerhaft: ja" in bf and "2 Zeilen zu Absturz" in bf and "Speicher 1" in bf and "ABRUPT" in bf and "nicht aktiv gemeldet" in bf
       and "längste Lücke" in bf and "Unterspannung seit dem Start" in bf and "notbremse_rueckblick_manuell" in text and "ENDE" in text
       and "frei am wenigsten 610 MB" in bf and "Dashboard am meisten 2490 MB" in bf and "frei 610 MB, Dashboard 2490 MB" in text,
       bf[:400])
    # ------------------------------------------------------------------------------------------- 23.78
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="cs78_")
    try:
        _selbsttest_78(ok, tmp)
        _selbsttest_80(ok, tmp)
    except Exception as e:                       # eine Ausnahme ist ein Fehler, kein Abbruch der übrigen Ausgabe
        import traceback
        ok("23.78-Proben ohne Ausnahme", False, f"{type(e).__name__}: {e} {traceback.format_exc()[-500:]}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(pruef) and bool(pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(pruef)} von {len(pruef)}, {time.time() - t0:.1f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", default=None, help="Hauptdatenbank (für Platte und Verlauf neben der Datenbank)")
    p.add_argument("--selbsttest", action="store_true", help="Proben auf erfundenen Eingaben")
    p.add_argument("--fenster", nargs=2, metavar=("VON", "BIS"), help="23.78: Fenster von Hand, z. B. 2026-10-23T09:31 2026-10-23T14:28")
    p.add_argument("--journal-dauerhaft", choices=("an", "aus"), help="23.78: Systemprotokoll dauerhaft ein-/ausschalten (sudo.txt)")
    p.add_argument("--poller", action="store_true", help="23.80 (U218): Kapazität des Pollers -- Stufen, Bedarf, Varianten (liest nur)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.journal_dauerhaft:
        sys.exit(0 if journal_dauerhaft(Umgebung(), a.journal_dauerhaft == "an") else 1)
    if a.poller:
        sys.exit(0 if poller_bericht(Umgebung(), a.db or os.path.join(HIER, "hl_liq.db"))["ok"] else 1)
    fenster = None
    if a.fenster:
        try:
            fenster = (zeit_lesen(a.fenster[0]), zeit_lesen(a.fenster[1]))
        except ValueError as e:
            p.error(str(e))
    bericht(Umgebung(), a.db, fenster)


if __name__ == "__main__":
    main()
