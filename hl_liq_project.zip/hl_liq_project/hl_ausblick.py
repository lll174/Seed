#!/usr/bin/env python3
"""
hl_ausblick.py -- Ausblick 4 Wochen (U146): Spannen, Ziellevels mit Wahrscheinlichkeit, geprüfte Gewichte (Version 2026-09-23.66).

Regeln: KONZEPT_Ausblick.md (vorab festgelegt am 11.10.2026, Ergänzung Abschnitt 13 am Abend, vor jedem Lauf auf echten Daten).
Drei feste Teile:
  Breite   HAR-log je Horizont (1/7/14/28 Tage) auf rollierenden 24-h-Tagen an den Ankern 00/06/12/18 UTC, je Ankerstunde ein
           Achsenabschnitt, Neuschätzung je Monat mit Embargo; Zusätze X1–X4 (DVOL, S&P-Schwankung, STLFSI4, VIX) einzeln geprüft
  Form     Bibliothek der echten 28-Tage-Pfade derselben Coins, je auf die damalige Schwankungsprognose normiert, ohne mittleren
           Trend, auf die heutige zurückskaliert -- Spannen und Erreich-Wahrscheinlichkeiten als genaue Anteile, ohne Zufallsziehung;
           der S&P-500-Pfad desselben Fensters als zweite Koordinate (bedingte Szenarien, Stressfächer)
  Richtung 36 Kandidaten (Kurs P1–P10, Derivate D1–D10, Makro M1–M12, Aktien A1–A4 -- das Konzept nannte 31 + 4 = 35, die Tabelle hat
           aber 10 + 10 + 12 = 32 Einträge, ein Zählfehler; maßgeblich ist die Tabelle), Ridge ohne Achsenabschnitt gepoolt über die
           Krypto-Coins, alle 28 Tage neu,
           λ aus geblockter Kreuzvalidierung mit Purging; nur bei offenem Tor (Clark-West und CRPS, Blockbootstrap, beide Hälften)
           verschiebt sie den Fächer
Prüfung: Rückblick außerhalb der Stichprobe ab 01.01.2022 (CRPS, PIT, Deckung, Brier, Zuverlässigkeit, Kalibrierungssteigung),
Vorwärtsbilanz ab dem ersten Tag. Nur lesend aus swing.db, regime.db, hebel.db, makro.db, aktien.db, hl_liq.db; schreibt nur
ausblick.db. Wirkt auf nichts sonst (Zusage bis 25.10.): keine Konfluenz, kein Labor, keine Prognose, kein Treiber.

  python3 hl_ausblick.py --prognose --db <hl_liq.db>     Stand am jüngsten Anker für alle Coins rechnen und speichern
  python3 hl_ausblick.py --rueckblick --db <hl_liq.db>   Rückblick, Walk-forward, Gewichte, Nullläufe, Urteile S1–S4 (bis ~15 min)
  python3 hl_ausblick.py --text --db <hl_liq.db>         Stand aller Coins als Text
  python3 hl_ausblick.py --null-kalibrierung             Wahl des Nullverfahrens auf 100 Null-Universen (13.6, langsam)
  python3 hl_ausblick.py --nachweisgrenze                Trefferquote der Richtungsprüfung je eingepflanzter Stärke (8 Punkt 5, langsam)
  python3 hl_ausblick.py --selbsttest [--nur basis,pfad] Selbsttest (ohne --nur alle Gruppen, einige Minuten)
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import sys
import threading
import time
import zlib
from datetime import date, datetime, timedelta, timezone

import numpy as np

VERSION_MODUL = "2026-09-23.67"
TAG = 86_400
BAR = 1800
ANKER_S = 6 * 3600
JE_TAG = 4                                                     # Anker je Tag (00, 06, 12, 18 UTC)
KERZEN_JE_ANKER = ANKER_S // BAR                               # 12
KERZEN_TAG = TAG // BAR                                        # 48
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")
KRYPTO = ("BTC", "ETH", "HYPE", "ZEC", "XMR")
H_STUETZ = (1, 7, 14, 28)
H_ZIEL = (7, 14, 28)
K_MAX = 28
QUANTILE = (0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95)
Q99 = tuple(round(i / 100, 2) for i in range(1, 100))
OOS_AB = int(datetime(2022, 1, 1, tzinfo=timezone.utc).timestamp())
LIB_AB = int(datetime(2020, 1, 1, tzinfo=timezone.utc).timestamp())
REFIT_TAGE = 28
LAMBDA_GITTER = tuple(float(x) for x in 10 ** np.linspace(-2, 4, 13))
CV_TEILE = 5
M_KAPPE = 0.5
Z_FENSTER, Z_MIN, Z_KAPPE = 730, 365, 4.0
BOOT_REPS = 2000
NULL_K = 100
NULL_K_MAX = 2000                                              # sequentielle Verlängerung (Besag & Clifford 1991), siehe gewichte_pruefen
NULL_STOPP = 10                                                # … bis 10 Überschreitungen oder NULL_K_MAX Surrogate
POOL_MIN_TAGE = 730                                            # kürzer: gepoolte Bibliothek der Krypto-Coins (HYPE)
PAXG_MIN_TAGE = 365
RV_MIN_GUELTIG = 40                                            # von 48 Renditen im 24-h-Block
HAR_MIN_ZEILEN = 800                                           # Anker im Training (≈ 200 Tage wie P0.2)
SCHOCK_R, SCHOCK_RV, SCHOCK_SP, AUSNAHME_S = 5.0, 4.0, 3.0, 24 * 3600
SZEN_X = (-0.15, -0.10, -0.05, 0.05)
SZEN_H = (7, 14, 28)
SZEN_EREIGNIS = (-0.10, 28)
KERN_LAMBDA = 0.35
ESS_MIN = 15.0
KERN_RELEVANT = math.exp(-0.5 * 9.0)                           # Episoden nur aus Fenstern innerhalb von 3 Bandbreiten
T_NU = (3, 4, 6, 8, 12, 20, 50)
US_VERZUG_S = TAG + 14 * 3600                                   # US-Schlussreihe für Handelstag d erst ab d+1 14:00 UTC (13.5)
WOCHE_VERZUG_S = 7 * TAG + 14 * 3600                           # STLFSI4, NFCI: wöchentlich, mit 7 Tagen Versatz
TOUCH_K = (0.5, 1.0, 1.5, 2.0)
# 13.6: Wahl des Nullverfahrens vorab auf Null-Universen (null_kalibrierung). Ergebnis des Laufs in der Sandbox vor dem ersten
# echten Lauf -- wird unten in NULL_WAHL eingetragen; der Selbsttest prüft die Regel auf wenigen Universen.
NULL_WAHL = {"verfahren": "verschiebung", "alpha": 0.05,                                    # 13.6, Regel vorab (null_kalibrierung)
             "stand": "kalibriert 11.10.2026 auf 100 Null-Universen, je 1.200 Tests: Verschiebung 5,4 %, Phasen 4,2 % "
                      "-> Verschiebung (am nächsten an 5 %, höchstens 6 %); Tor offen in 1 von 200"}
PK_STARK = 0.35                                                 # Positivkontrolle des Selbsttests (8 Punkt 5, Nachtrag 11.10.)
NACHWEIS = {"text": "gemessen 11.10.2026 mit der Verschiebung auf je 10 Märkten: Tor 3 von 10, P1 „trägt“ 9 von 10; ab R² 5,9 % "
                    "Tor 9 von 10, ab 10,9 % 10 von 10; Rausch-Kandidaten 0 von 110"}   # nachweisgrenze() (8 Punkt 5)
WORT_VERBOTEN = ("kaufen", "verkaufen", "kaufsignal", "verkaufssignal", "bullisch", "bärisch", "kursziel", "einstieg", "ausstieg")


# ================================================================================================ Spezialfunktionen (ohne SciPy)

_erfc_v = np.vectorize(math.erfc, otypes=[float])


def norm_cdf(x):
    x = np.asarray(x, dtype=float)
    return 0.5 * _erfc_v(-x / math.sqrt(2.0))


def norm_ppf(p):
    """Acklam (2003) mit einem Newton-Schritt; Genauigkeit ≈ 1e-12."""
    p = np.asarray(p, dtype=float)
    a = (-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01,
         2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00,
         2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00)
    pl, ph = 0.02425, 1 - 0.02425
    x = np.empty_like(p)
    lo = p < pl; hi = p > ph; mi = ~(lo | hi)
    q = np.sqrt(-2 * np.log(np.where(lo, p, 0.5)))
    x[lo] = ((((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1))[lo]
    q = np.sqrt(-2 * np.log(np.where(hi, 1 - p, 0.5)))
    x[hi] = (-(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1))[hi]
    q = p - 0.5; r = q * q
    x[mi] = ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
             / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1))[mi]
    e = norm_cdf(x) - p
    u = e * math.sqrt(2 * math.pi) * np.exp(x * x / 2)
    return x - u / (1 + x * u / 2)


def _betainc(a: float, b: float, x):
    """Regularisierte unvollständige Betafunktion I_x(a, b) (Kettenbruch nach Lentz), vektorisiert über x."""
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    with np.errstate(divide="ignore", invalid="ignore"):
        vorne = np.exp(lbeta + a * np.log(np.clip(x, 1e-300, 1)) + b * np.log(np.clip(1 - x, 1e-300, 1)))

    def cf(a_, b_, xx):
        tiny = 1e-300
        qab, qap, qam = a_ + b_, a_ + 1, a_ - 1
        c_ = np.ones_like(xx); d_ = 1 - qab * xx / qap
        d_ = np.where(np.abs(d_) < tiny, tiny, d_); d_ = 1 / d_; h_ = d_.copy()
        for m in range(1, 301):
            m2 = 2 * m
            aa = m * (b_ - m) * xx / ((qam + m2) * (a_ + m2))
            d_ = 1 + aa * d_; d_ = np.where(np.abs(d_) < tiny, tiny, d_)
            c_ = 1 + aa / c_; c_ = np.where(np.abs(c_) < tiny, tiny, c_)
            d_ = 1 / d_; h_ *= d_ * c_
            aa = -(a_ + m) * (qab + m) * xx / ((a_ + m2) * (qap + m2))
            d_ = 1 + aa * d_; d_ = np.where(np.abs(d_) < tiny, tiny, d_)
            c_ = 1 + aa / c_; c_ = np.where(np.abs(c_) < tiny, tiny, c_)
            d_ = 1 / d_; dl = d_ * c_; h_ *= dl
            if np.all(np.abs(dl - 1) < 1e-14):
                break
        return h_
    unten = x < (a + 1) / (a + b + 2)
    if unten.any():
        out[unten] = (vorne * cf(a, b, x) / a)[unten]
    if (~unten).any():
        out[~unten] = (1 - vorne * cf(b, a, 1 - x) / b)[~unten]
    out[x <= 0] = 0.0; out[x >= 1] = 1.0
    return out


def _t_cdf_ganz(x: np.ndarray, nu: int) -> np.ndarray:
    """
    t-Verteilung für ganzzahlige Freiheitsgrade, geschlossen (Abramowitz & Stegun 26.7.3/26.7.4): mit θ = arctan(x/√ν) ist
    A = P(|T| ≤ |x|) für gerade ν = sin θ · Σ_{j=0}^{ν/2−1} c_j cos^{2j} θ (c_0 = 1, c_j = c_{j−1}·(2j−1)/(2j)), für ungerade ν
    = (2/π)·(θ + sin θ cos θ · Σ_{j=0}^{(ν−3)/2} d_j cos^{2j} θ) (d_0 = 1, d_j = d_{j−1}·2j/(2j+1)). 23.66: ersetzt den Kettenbruch
    der unvollständigen Betafunktion auf dem Gitter der Kopula (ν = 3 … 51) -- gleiches Ergebnis (Selbsttest), rund 100-mal schneller.
    """
    th = np.arctan(np.abs(x) / math.sqrt(nu))
    s, c = np.sin(th), np.cos(th)
    c2 = c * c
    if nu % 2 == 0:
        term = np.ones_like(x); summe = term.copy()
        for j in range(1, nu // 2):
            term = term * c2 * (2 * j - 1) / (2 * j); summe += term
        A = s * summe
    else:
        if nu == 1:
            A = 2 * th / math.pi
        else:
            term = np.ones_like(x); summe = term.copy()
            for j in range(1, (nu - 1) // 2):
                term = term * c2 * (2 * j) / (2 * j + 1); summe += term
            A = (2 / math.pi) * (th + s * c * summe)
    halb = 0.5 * (1 - np.clip(A, 0.0, 1.0))
    return np.where(x >= 0, 1 - halb, halb)


def t_cdf(x, nu: float):
    x = np.asarray(x, dtype=float)
    if float(nu).is_integer() and 1 <= nu <= 400:
        return _t_cdf_ganz(x, int(nu))
    t = nu / (nu + x * x)
    halb = 0.5 * _betainc(nu / 2, 0.5, t)
    return np.where(x >= 0, 1 - halb, halb)


def _t_cdf_beta(x, nu: float):
    """Der bisherige Weg über die unvollständige Betafunktion (Selbsttest: gleich der geschlossenen Form)."""
    x = np.asarray(x, dtype=float)
    t = nu / (nu + x * x)
    halb = 0.5 * _betainc(nu / 2, 0.5, t)
    return np.where(x >= 0, 1 - halb, halb)


def t_logpdf(x, nu: float):
    x = np.asarray(x, dtype=float)
    return (math.lgamma((nu + 1) / 2) - math.lgamma(nu / 2) - 0.5 * math.log(nu * math.pi)
            - (nu + 1) / 2 * np.log1p(x * x / nu))


def t_ppf(p, nu: float):
    """Quantil der t-Verteilung: Newton ab dem Normalquantil, mit Bisektion als Sicherung."""
    p = np.clip(np.asarray(p, dtype=float), 1e-12, 1 - 1e-12)
    x = norm_ppf(p)
    lo = np.full_like(x, -1e6); hi = np.full_like(x, 1e6)
    for _ in range(80):
        F = t_cdf(x, nu)
        lo = np.where(F < p, x, lo); hi = np.where(F >= p, x, hi)
        dens = np.exp(t_logpdf(x, nu))
        neu = x - (F - p) / np.maximum(dens, 1e-300)
        bad = ~np.isfinite(neu) | (neu <= lo) | (neu >= hi)
        neu = np.where(bad, 0.5 * (np.clip(lo, -1e3, None) + np.clip(hi, None, 1e3)), neu)
        if np.all(np.abs(neu - x) < 1e-10 * (1 + np.abs(x))):
            x = neu
            break
        x = neu
    return x


def chi2_sf(x: float, k: int) -> float:
    """P(χ²_k > x) über die regularisierte unvollständige Gammafunktion (Reihe bzw. Kettenbruch)."""
    if x <= 0:
        return 1.0
    a = k / 2.0; z = x / 2.0
    if z < a + 1:
        s = 1.0 / a; t = s
        for n in range(1, 500):
            t *= z / (a + n); s += t
            if abs(t) < abs(s) * 1e-15:
                break
        P = s * math.exp(-z + a * math.log(z) - math.lgamma(a))
        return max(0.0, 1.0 - P)
    b = z + 1 - a; c = 1 / 1e-300; d = 1 / b; h = d
    for i in range(1, 500):
        an = -i * (i - a); b += 2
        d = an * d + b; d = 1e-300 if abs(d) < 1e-300 else d
        c = b + an / c; c = 1e-300 if abs(c) < 1e-300 else c
        d = 1 / d; dl = d * c; h *= dl
        if abs(dl - 1) < 1e-15:
            break
    return min(1.0, math.exp(-z + a * math.log(z) - math.lgamma(a)) * h)


def logit_steigung(y: np.ndarray, p: np.ndarray) -> float:
    """Kalibrierungssteigung: logistische Regression des Ereignisses auf logit(p) (Newton/IRLS), Soll 1."""
    ok = np.isfinite(p) & np.isfinite(y)
    y = y[ok].astype(float); p = np.clip(p[ok], 1e-4, 1 - 1e-4)
    if len(y) < 30 or y.min() == y.max():
        return float("nan")
    X = np.column_stack([np.ones(len(y)), np.log(p / (1 - p))])
    b = np.array([0.0, 1.0])
    for _ in range(50):
        eta = np.clip(X @ b, -30, 30); mu = 1 / (1 + np.exp(-eta))
        W = mu * (1 - mu) + 1e-12
        g = X.T @ (y - mu); H = (X * W[:, None]).T @ X
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        b = b + step
        if np.max(np.abs(step)) < 1e-10:
            break
    return float(b[1])


def stat_idx(n: int, block: float, reps: int, seed: int) -> np.ndarray:
    """Stationärer Bootstrap (Politis & Romano 1994), vektorisiert: Indexmatrix (reps, n), Blocklänge geometrisch mit Mittel block."""
    rng = np.random.default_rng(seed)
    neu = rng.random((reps, n)) < 1.0 / max(block, 1.0)
    neu[:, 0] = True
    start = rng.integers(0, n, size=(reps, n))
    pos = np.where(neu, np.arange(n)[None, :], 0)
    letzt = np.maximum.accumulate(pos, axis=1)
    sv = np.take_along_axis(start, letzt, axis=1)
    return (sv + (np.arange(n)[None, :] - letzt)) % n


def boot_p(f: np.ndarray, block: float, reps: int = BOOT_REPS, seed: int = 0) -> dict:
    """Mittel einer Tagesreihe größer 0? Einseitig, stationärer Blockbootstrap der zentrierten Reihe. -> {mittel, p, se, n}."""
    f = np.asarray(f, dtype=float); f = f[np.isfinite(f)]
    n = len(f)
    if n < 30:
        return {"n": n, "mittel": float(np.mean(f)) if n else float("nan"), "p": float("nan"), "se": float("nan")}
    m = float(f.mean())
    idx = stat_idx(n, block, reps, seed)
    bm = f[idx].mean(axis=1)
    p = float((1 + np.sum(bm - m >= m)) / (1 + reps))
    return {"n": n, "mittel": m, "p": p, "se": float(bm.std(ddof=1))}


def crps_ens(x: np.ndarray, y) -> np.ndarray:
    """CRPS einer gleich gewichteten Stichprobe x für eine oder viele Beobachtungen y: E|X−y| − ½·E|X−X'| (genau)."""
    xs = np.sort(np.asarray(x, dtype=float)); N = len(xs)
    if N == 0:
        return np.full(np.shape(y), np.nan)
    i = np.arange(1, N + 1)
    e_xx = 2.0 / (N * N) * float(np.sum((2 * i - N - 1) * xs))
    cs = np.concatenate([[0.0], np.cumsum(xs)])
    y = np.asarray(y, dtype=float)
    k = np.searchsorted(xs, y, side="right")
    s_k = cs[k]
    e_xy = (k * y - s_k + (cs[-1] - s_k) - (N - k) * y) / N
    return e_xy - 0.5 * e_xx


def crps_normal(mu, sig, y):
    z = (np.asarray(y, dtype=float) - mu) / sig
    return sig * (z * (2 * norm_cdf(z) - 1) + 2 * np.exp(-0.5 * z * z) / math.sqrt(2 * math.pi) - 1 / math.sqrt(math.pi))


def gew_quantile(x: np.ndarray, w: np.ndarray, qs) -> np.ndarray:
    """Gewichtete Quantile (Mittelpunktregel der kumulierten Gewichte, linear interpoliert)."""
    o = np.argsort(x); xs = x[o]; ws = w[o]
    cw = np.cumsum(ws); tot = cw[-1]
    if tot <= 0:
        return np.full(len(qs), np.nan)
    mitte = (cw - 0.5 * ws) / tot
    return np.interp(np.asarray(qs, dtype=float), mitte, xs)


def holm(p: list) -> list:
    m = len(p); o = sorted(range(m), key=lambda i: p[i]); out = [1.0] * m; best = 0.0
    for r, i in enumerate(o):
        best = max(best, min(1.0, (m - r) * p[i]))
        out[i] = best
    return out


def qlike(F, S):
    with np.errstate(divide="ignore", invalid="ignore"):
        q = S / F
        return q - np.log(q) - 1


def kendall_tau(a: np.ndarray, b: np.ndarray, max_n: int = 3000) -> float:
    """Kendall τ_b (ohne Bindungen) auf höchstens max_n gleichmäßig ausgedünnten Paaren, paarweise in Blöcken."""
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) > max_n:
        j = np.linspace(0, len(a) - 1, max_n).astype(int); a, b = a[j], b[j]
    n = len(a); s = 0.0
    for i0 in range(0, n, 500):
        da = np.sign(a[i0:i0 + 500, None] - a[None, :]); db = np.sign(b[i0:i0 + 500, None] - b[None, :])
        s += float(np.sum(da * db))
    return s / (n * (n - 1)) if n > 1 else float("nan")


# ================================================================================================ Zeit

def anker_von(ts: int) -> int:
    """Jüngster 6-h-Anker ≤ ts."""
    return int(ts) // ANKER_S * ANKER_S


def halbstunden_anker(ts: int) -> int:
    """Ende der letzten abgeschlossenen 30-min-Kerze ≤ ts (Anker τ der Neuberechnung, 13.1)."""
    return int(ts) // BAR * BAR


def _dt(ts) -> str:
    return "—" if ts is None else datetime.fromtimestamp(int(ts), timezone.utc).strftime("%d.%m.%Y")


def _dtz(ts) -> str:
    return "—" if ts is None else datetime.fromtimestamp(int(ts), timezone.utc).strftime("%d.%m. %H:%M UTC")


def _de(x, nd: int = 1, vz: bool = False) -> str:
    if x is None or not np.isfinite(x):
        return "—"
    s = f"{x:+.{nd}f}" if vz else f"{x:.{nd}f}"
    if s[:1] in "+-" and not any(c in "123456789" for c in s):
        s = s[1:]
    return s.replace(".", ",")


def _px(x) -> str:
    import hl_zyklus as ZY
    return ZY._px(x)


def _pr(x, nd: int = 1) -> str:
    return "—" if x is None or not np.isfinite(x) else _de(x * 100, nd, True) + " %"


# ================================================================================================ Daten: Raster und Anker

def anker_reihen(K: dict, ab: int | None = None) -> dict | None:
    """
    30-min-Kerzen -> 6-h-Anker (00/06/12/18 UTC): je Anker τ der Schluss C (Kerze bis τ), die realisierte Varianz der letzten 24 h
    RV (Summe der quadrierten 30-min-Log-Renditen, mindestens 40 von 48 gültig, hochskaliert) und Hoch/Tief des 24-h-Blocks.
    Jedes Fenster enthält jede Uhrzeit genau einmal (13.1).
    """
    if K is None or len(K["ts"]) < KERZEN_TAG * 60:
        return None
    ts = np.asarray(K["ts"], dtype=np.int64)
    t0 = int(ts[0]) // BAR * BAR
    n = int((int(ts[-1]) - t0) // BAR) + 1
    c = np.full(n, np.nan); h = np.full(n, np.nan); l = np.full(n, np.nan)
    i = ((ts - t0) // BAR).astype(np.int64)
    c[i] = K["c"]; h[i] = np.maximum(K["h"], K["c"]); l[i] = np.minimum(K["l"], K["c"])
    lc = np.log(c)
    r = np.full(n, np.nan); r[1:] = lc[1:] - lc[:-1]
    r2 = np.where(np.isfinite(r), r * r, 0.0); gz = np.isfinite(r).astype(np.int64)
    cs = np.concatenate([[0.0], np.cumsum(r2)]); cg = np.concatenate([[0], np.cumsum(gz)])
    # Anker: τ % 6 h == 0, Kerze bis τ hat Index (τ − BAR − t0)/BAR, braucht 48 Renditen davor
    erst = ((t0 + BAR * (KERZEN_TAG + 1)) + ANKER_S - 1) // ANKER_S * ANKER_S
    if ab is not None:
        erst = max(erst, (int(ab) + ANKER_S - 1) // ANKER_S * ANKER_S)
    letzt = (t0 + (n - 1) * BAR + BAR) // ANKER_S * ANKER_S
    if letzt < erst:
        return None
    tau = np.arange(erst, letzt + 1, ANKER_S, dtype=np.int64)
    ii = ((tau - BAR - t0) // BAR).astype(np.int64)
    ok = (ii >= KERZEN_TAG) & (ii < n)
    tau, ii = tau[ok], ii[ok]
    s = cs[ii + 1] - cs[ii + 1 - KERZEN_TAG]; g = cg[ii + 1] - cg[ii + 1 - KERZEN_TAG]
    with np.errstate(invalid="ignore", divide="ignore"):
        RV = np.where(g >= RV_MIN_GUELTIG, s * KERZEN_TAG / np.maximum(g, 1), np.nan)
    RV = np.where(RV > 0, RV, np.nan)
    from numpy.lib.stride_tricks import sliding_window_view
    hp = np.concatenate([np.full(KERZEN_TAG - 1, np.nan), h]); lp = np.concatenate([np.full(KERZEN_TAG - 1, np.nan), l])
    Wh = sliding_window_view(hp, KERZEN_TAG)[ii]; Wl = sliding_window_view(lp, KERZEN_TAG)[ii]
    with np.errstate(all="ignore"):
        H24 = np.where(np.isfinite(Wh).any(axis=1), np.nanmax(np.where(np.isfinite(Wh), Wh, -np.inf), axis=1), np.nan)
        L24 = np.where(np.isfinite(Wl).any(axis=1), np.nanmin(np.where(np.isfinite(Wl), Wl, np.inf), axis=1), np.nan)
    C = c[ii]
    return {"tau": tau, "C": C, "RV": RV, "H": H24, "L": L24, "stunde": ((tau % TAG) // 3600).astype(np.int64), "n": len(tau),
            "t0_kerze": t0, "c30": c, "r30": r, "letzte_kerze": int(ts[-1])}


def _rueck_mittel(x: np.ndarray, m: int, schritt: int = JE_TAG) -> np.ndarray:
    """Mittel von x[j], x[j−schritt], …, x[j−(m−1)·schritt] (alle gültig), sonst NaN."""
    n = len(x); out = np.full(n, np.nan)
    if n <= (m - 1) * schritt:
        return out
    acc = np.zeros(n - (m - 1) * schritt); ok = np.ones(n - (m - 1) * schritt, dtype=bool)
    for k in range(m):
        seg = x[(m - 1 - k) * schritt: n - k * schritt]
        acc += np.where(np.isfinite(seg), seg, 0.0); ok &= np.isfinite(seg)
    out[(m - 1) * schritt:] = np.where(ok, acc / m, np.nan)
    return out


def _vor_summe(x: np.ndarray, h: int, schritt: int = JE_TAG) -> np.ndarray:
    """Summe von x[j+schritt], …, x[j+h·schritt] (alle gültig), sonst NaN."""
    n = len(x); out = np.full(n, np.nan)
    if n <= h * schritt:
        return out
    acc = np.zeros(n - h * schritt); ok = np.ones(n - h * schritt, dtype=bool)
    for k in range(1, h + 1):
        seg = x[k * schritt: n - (h - k) * schritt]
        acc += np.where(np.isfinite(seg), seg, 0.0); ok &= np.isfinite(seg)
    out[: n - h * schritt] = np.where(ok, acc, np.nan)
    return out


def har_regressoren(A: dict) -> np.ndarray:
    """[Dummies 00/06/12/18, ln RV Tag, ln RV Woche (7 × 24 h), ln RV Monat (30 × 24 h)] je Anker."""
    RV = A["RV"]
    with np.errstate(divide="ignore", invalid="ignore"):
        X = np.column_stack([(A["stunde"] == s).astype(float) for s in (0, 6, 12, 18)]
                            + [np.log(RV), np.log(_rueck_mittel(RV, 7)), np.log(_rueck_mittel(RV, 30))])
    return X


def _monatsanfaenge(t_von: int, t_bis: int) -> list:
    d = datetime.fromtimestamp(t_von, timezone.utc).date().replace(day=1)
    out = []
    while True:
        t = int(datetime(d.year, d.month, 1, tzinfo=timezone.utc).timestamp())
        if t > t_bis + 31 * TAG:
            break
        out.append(t)
        d = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
    return out


def har_walk(A: dict, h: int, extra: np.ndarray | None = None, ab_fit: int | None = None) -> dict:
    """
    HAR-log für Horizont h (Tage) mit monatlicher Neuschätzung: y = ln(Σ RV der nächsten h × 24 h ÷ h) auf die Regressoren (+ extra);
    trainiert nur mit Ankern, deren Ziel vor dem Monatsanfang endet (Embargo); F = h·exp(Xβ + s²/2) für die Anker des Monats.
    -> {F, beta (letzte Schätzung), s2, monate}
    """
    X = har_regressoren(A)
    if extra is not None:
        X = np.column_stack([X, extra])
    S = _vor_summe(A["RV"], h)
    with np.errstate(divide="ignore", invalid="ignore"):
        y = np.log(S / h)
    tau = A["tau"]; n = len(tau)
    F = np.full(n, np.nan)
    gx = np.all(np.isfinite(X), axis=1)
    ziel_ende = tau + h * TAG
    beta = None; s2 = None; n_mon = 0; koeff = []
    mon = _monatsanfaenge(int(tau[0]), int(tau[-1]))
    for T, T_n in zip(mon, mon[1:] + [mon[-1] + 40 * TAG]):
        if T > tau[-1]:
            break
        tr = gx & np.isfinite(y) & (ziel_ende <= T)
        if ab_fit is not None:
            tr &= tau >= ab_fit
        if tr.sum() < HAR_MIN_ZEILEN:
            continue
        Xt = X[tr]; yt = y[tr]
        # Dummies ohne Zeilen (z. B. eine Ankerstunde fehlt ganz) aus der Schätzung nehmen
        aktiv = np.ones(X.shape[1], dtype=bool); aktiv[:4] = Xt[:, :4].sum(axis=0) > 0
        b, *_ = np.linalg.lstsq(Xt[:, aktiv], yt, rcond=None)
        bb = np.zeros(X.shape[1]); bb[aktiv] = b
        if not aktiv[:4].all():
            bb[:4][~aktiv[:4]] = float(np.mean(b[: int(aktiv[:4].sum())]))
        res = yt - Xt @ bb
        beta, s2 = bb, float(np.var(res)); n_mon += 1
        koeff.append((int(T), int(T_n), bb, s2))
        o = (tau >= T) & (tau < T_n) & gx
        F[o] = h * np.exp(X[o] @ bb + s2 / 2)
    return {"F": F, "beta": beta, "s2": s2, "monate": n_mon, "S": S, "X": X, "koeff": koeff}


def koeff_bei(W: dict, tau: int) -> tuple:
    """Koeffizienten des Monats, in dem τ liegt (kausal; die jüngsten Daten können schon im nächsten Monat liegen)."""
    for T, T_n, b, s2 in reversed(W.get("koeff") or []):
        if T <= int(tau):
            return b, s2
    return None, None


def F_pfad(Fs: dict, j=None) -> np.ndarray:
    """ln(F(τ,k)/k) linear in k zwischen den Stützstellen 1, 7, 14, 28 -> F(τ, k) für k = 1 … 28 (Spalten)."""
    hs = np.array(H_STUETZ, dtype=float)
    if np.ndim(Fs[H_STUETZ[0]]) == 0:                          # ein Zeitpunkt (Werte statt Reihen)
        L = np.array([math.log(float(Fs[h]) / h) for h in H_STUETZ])
    else:
        L = np.column_stack([np.log(Fs[h] / h) for h in H_STUETZ])
        if j is not None:
            L = L[j]
    k = np.arange(1, K_MAX + 1, dtype=float)
    if L.ndim == 1:
        return k * np.exp(np.interp(k, hs, L))
    out = np.empty((L.shape[0], K_MAX))
    for i in range(K_MAX):
        kk = k[i]
        jj = np.searchsorted(hs, kk, side="right") - 1
        jj = min(max(jj, 0), len(hs) - 2)
        w = (kk - hs[jj]) / (hs[jj + 1] - hs[jj])
        out[:, i] = kk * np.exp((1 - w) * L[:, jj] + w * L[:, jj + 1])
    return out


# ================================================================================================ Form: Pfad-Bibliothek

def bibliothek(A: dict, Fk: np.ndarray, coin: str = "") -> dict:
    """
    Normierte 28-Tage-Pfade je Ursprung (Anker j): Z = (ln C(j+k) − ln C(j)) ÷ √F(j,k), ZH/ZL mit Hoch/Tief des 24-h-Blocks k;
    F(j,k) ist die damalige Prognose (kausal). Fenster ab 2020, nur vollständig realisierte; ende = Zeitpunkt des letzten Blocks.
    """
    n = A["n"]; lc = np.log(A["C"]); lh = np.log(A["H"]); ll = np.log(A["L"])
    J = np.arange(0, n - K_MAX * JE_TAG)
    J = J[A["tau"][J] >= LIB_AB]
    if not len(J):
        return {"Z": np.zeros((0, K_MAX), np.float32), "ZH": np.zeros((0, K_MAX), np.float32), "ZL": np.zeros((0, K_MAX), np.float32),
                "ende": np.zeros(0, np.int64), "start": np.zeros(0, np.int64), "coin": np.zeros(0, dtype="<U5")}
    kk = np.arange(1, K_MAX + 1) * JE_TAG
    I = J[:, None] + kk[None, :]
    with np.errstate(invalid="ignore", divide="ignore"):
        sq = np.sqrt(Fk[J])
        Z = (lc[I] - lc[J][:, None]) / sq
        ZH = (lh[I] - lc[J][:, None]) / sq
        ZL = (ll[I] - lc[J][:, None]) / sq
    ok = np.all(np.isfinite(Z) & np.isfinite(ZH) & np.isfinite(ZL), axis=1)
    J = J[ok]
    return {"Z": Z[ok].astype(np.float32), "ZH": ZH[ok].astype(np.float32), "ZL": ZL[ok].astype(np.float32),
            "start": A["tau"][J].astype(np.int64), "ende": (A["tau"][J] + K_MAX * TAG).astype(np.int64), "j": J,
            "coin": np.full(len(J), coin, dtype="<U5")}


def bib_verbinden(Bs: list) -> dict:
    keys = ("Z", "ZH", "ZL", "start", "ende", "coin")
    return {k: np.concatenate([B[k] for B in Bs]) for k in keys} if Bs else None


def bib_bis(B: dict, tau: int) -> np.ndarray:
    """Maske der Fenster, die vor τ vollständig realisiert waren (Ende ≤ τ − 1 Tag, wie s + 28 ≤ d − 1)."""
    return B["ende"] <= int(tau) - TAG


def szenarien(B: dict, maske: np.ndarray, Fk_tau: np.ndarray, mu: np.ndarray | None = None) -> dict:
    """
    Pfade der Szenarien für τ: r_k = μ(k) + (Z(s,k) − m̄(k))·√F(τ,k), ebenso Hoch und Tief; m̄ aus derselben Bibliothek.
    Alle Fenster mit gleichem Gewicht. -> {r, hoch_lauf (laufendes Maximum), tief_lauf (laufendes Minimum), mbar, n}
    """
    Z = B["Z"][maske].astype(float); ZH = B["ZH"][maske].astype(float); ZL = B["ZL"][maske].astype(float)
    mbar = Z.mean(axis=0) if len(Z) else np.zeros(K_MAX)
    sq = np.sqrt(np.asarray(Fk_tau, dtype=float))
    m_ = np.zeros(K_MAX) if mu is None else np.asarray(mu, dtype=float)
    r = m_ + (Z - mbar) * sq; hi = m_ + (ZH - mbar) * sq; lo = m_ + (ZL - mbar) * sq
    return {"r": r, "hoch_lauf": np.maximum.accumulate(hi, axis=1), "tief_lauf": np.minimum.accumulate(lo, axis=1), "mbar": mbar,
            "n": len(Z)}


def faecher(S: dict) -> np.ndarray:
    """Quantile 5/10/25/50/75/90/95 % der Log-Rendite je Tag k (28 × 7)."""
    return np.quantile(S["r"], QUANTILE, axis=0).T if S["n"] else np.full((K_MAX, len(QUANTILE)), np.nan)


def erreichen(S: dict, d_ln: float, h: int) -> tuple:
    """Erreich- und Schluss-Wahrscheinlichkeit eines Niveaus im Abstand d_ln = ln(L/P0) bis Tag h."""
    if S["n"] == 0:
        return float("nan"), float("nan")
    if d_ln >= 0:
        return float(np.mean(S["hoch_lauf"][:, h - 1] >= d_ln)), float(np.mean(S["r"][:, h - 1] >= d_ln))
    return float(np.mean(S["tief_lauf"][:, h - 1] <= d_ln)), float(np.mean(S["r"][:, h - 1] <= d_ln))


def drift_pfad(mhat: dict, Fk_tau: np.ndarray) -> np.ndarray:
    """μ(k) aus m̂ je Horizont (nur offene Tore, sonst 0): μ_h(h) = m̂_h·√F(τ,h); linear in k zwischen 0, 7, 14 und 28 Tagen."""
    stuetz = [0.0] + [float(mhat.get(h) or 0.0) * math.sqrt(float(Fk_tau[h - 1])) for h in H_ZIEL]
    return np.interp(np.arange(1, K_MAX + 1), [0] + list(H_ZIEL), stuetz)


# ================================================================================================ S&P 500: Breite und Koordinate

def us_asof(t_beob: np.ndarray, w: np.ndarray, zeiten: np.ndarray, verzug: int = US_VERZUG_S, max_alter: int = 10 * TAG) -> np.ndarray:
    """Wert einer US-Reihe zum Zeitpunkt t: jüngste Beobachtung mit Tag + verzug ≤ t (Kausalität 13.5), höchstens max_alter alt."""
    out = np.full(len(zeiten), np.nan)
    if not len(t_beob):
        return out
    verf = np.asarray(t_beob, dtype=np.int64) + verzug
    j = np.searchsorted(verf, np.asarray(zeiten, dtype=np.int64), side="right") - 1
    ok = j >= 0
    jj = np.clip(j, 0, None)
    ok &= (np.asarray(zeiten) - verf[jj]) <= max_alter
    out[ok] = np.asarray(w, dtype=float)[jj[ok]]
    return out


def sp_breite(SP: dict, VIX: dict | None, VIX3M: dict | None) -> dict:
    """
    Breite des S&P 500 selbst (13.2): mittlere quadrierte Tagesrendite über die Handelstage in (t, t+h] (h = 7/14/28 Kalendertage)
    auf ln RV_S (5 und 20 Tage), ln VIX², ln VIX3M²; Neuschätzung je Monat ab Ende 2016 mit Embargo. Je Handelstag (Zeitpunkt der
    Verfügbarkeit d+1 14:00 UTC) die Prognose der Varianz je Handelstag V_S. -> {t_verf, V (je h), schluss_ts, lp}
    """
    t = np.asarray(SP["ts"], dtype=np.int64); p = np.asarray(SP["w"], dtype=float)
    n = len(t)
    if n < 300:
        return {"n": n}
    lp = np.log(p); r = np.full(n, np.nan); r[1:] = lp[1:] - lp[:-1]
    r2 = r * r
    rv5 = np.full(n, np.nan); rv20 = np.full(n, np.nan)
    for i in range(20, n):
        rv5[i] = np.nanmean(r2[i - 4:i + 1]); rv20[i] = np.nanmean(r2[i - 19:i + 1])
    t_verf = t + US_VERZUG_S
    vix = us_asof(VIX["ts"], VIX["w"], t_verf, US_VERZUG_S) if VIX else np.full(n, np.nan)
    v3 = us_asof(VIX3M["ts"], VIX3M["w"], t_verf, US_VERZUG_S) if VIX3M else np.full(n, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        X = np.column_stack([np.ones(n), np.log(rv5), np.log(rv20), np.log((vix / 100) ** 2 / 252), np.log((v3 / 100) ** 2 / 252)])
    gx = np.all(np.isfinite(X), axis=1)
    if gx.sum() < 300:                                       # ohne VIX: nur die eigene Schwankung
        X = X[:, :3]; gx = np.all(np.isfinite(X), axis=1)
    V = {}
    for h in H_ZIEL:
        y = np.full(n, np.nan); ende = np.full(n, -1, dtype=np.int64)
        for i in range(n):
            j = np.searchsorted(t, t[i] + h * TAG, side="right")
            if j - 1 > i and j <= n:
                y[i] = np.nanmean(r2[i + 1:j]); ende[i] = t[j - 1]
        with np.errstate(divide="ignore"):
            ly = np.log(y)
        Vh = np.full(n, np.nan)
        mon = _monatsanfaenge(int(t[0]), int(t[-1]))
        for T, T_n in zip(mon, mon[1:] + [mon[-1] + 40 * TAG]):
            tr = gx & np.isfinite(ly) & (ende + US_VERZUG_S <= T) & (ende > 0)
            if tr.sum() < 250:
                continue
            b, *_ = np.linalg.lstsq(X[tr], ly[tr], rcond=None)
            s2 = float(np.var(ly[tr] - X[tr] @ b))
            o = gx & (t_verf >= T) & (t_verf < T_n)
            Vh[o] = np.exp(X[o] @ b + s2 / 2)
        V[h] = Vh
    return {"n": n, "t": t, "t_verf": t_verf, "V": V, "lp": lp, "schluss_ts": t + 16 * 3600 + 4 * 3600}


def sp_schluss_zeit(t_tag: np.ndarray) -> np.ndarray:
    """Zeitpunkt des offiziellen Schlusses (16:00 New York) je US-Datum (00:00 UTC des Datums)."""
    from zoneinfo import ZoneInfo
    NY = ZoneInfo("America/New_York")
    out = np.empty(len(t_tag), dtype=np.int64)
    for i, x in enumerate(t_tag):
        d = datetime.fromtimestamp(int(x), timezone.utc).date()
        out[i] = int(datetime(d.year, d.month, d.day, 16, 0, tzinfo=NY).timestamp())
    return out


def sp_koordinate(B: dict, SPB: dict) -> np.ndarray:
    """
    z_S(s,k) = [ln P_S(s+k) − ln P_S(s)] ÷ √F_S(s,k) − m̄_S(k) je Bibliotheksfenster; P_S(t) = letzter offizieller Schluss ≤ t,
    F_S(s,k) = V_S(s) · Zahl der Handelstage in (s, s+k]; ohne Handelstag z_S = 0. m̄_S wird beim Gebrauch abgezogen.
    -> roh (ohne Abzug), NaN wo die S&P-Breite fehlt.
    """
    st = np.asarray(B["start"], dtype=np.int64); N = len(st)
    out = np.full((N, K_MAX), np.nan, dtype=np.float32)
    if not SPB.get("n") or SPB["n"] < 300 or N == 0:
        return out
    tz = sp_schluss_zeit(SPB["t"])
    lp = SPB["lp"]
    V7 = SPB["V"][7]
    js = np.searchsorted(tz, st, side="right") - 1
    jv = np.searchsorted(SPB["t_verf"], st, side="right") - 1
    ok0 = (js >= 0) & (jv >= 0)
    for k in range(1, K_MAX + 1):
        je = np.searchsorted(tz, st + k * TAG, side="right") - 1
        n_td = je - js
        Vh = SPB["V"][7 if k <= 7 else (14 if k <= 14 else 28)]
        v = np.where(ok0, Vh[np.clip(jv, 0, None)], np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            z = np.where(n_td > 0, (lp[np.clip(je, 0, None)] - lp[np.clip(js, 0, None)]) / np.sqrt(v * np.maximum(n_td, 1)), 0.0)
        out[:, k - 1] = np.where(ok0 & np.isfinite(v), z, np.nan)
    return out


def sp_breite_jetzt(SPB: dict, tau: int, h: int) -> float:
    """F_S(τ, h) = V_S(τ) · Handelstage in (τ, τ+h] (Kalender der NYSE)."""
    import hl_aktien as AK
    if not SPB.get("n") or SPB["n"] < 300:
        return float("nan")
    jv = np.searchsorted(SPB["t_verf"], int(tau), side="right") - 1
    if jv < 0:
        return float("nan")
    V = SPB["V"][7 if h <= 7 else (14 if h <= 14 else 28)][jv]
    if not np.isfinite(V):
        return float("nan")
    d0 = datetime.fromtimestamp(int(tau), timezone.utc)
    n_td = 0
    for k in range(0, h + 1):
        dd = (d0 + timedelta(days=k)).date()
        t_schl = AK.ny_ts(dd, 16, 0)
        if AK.handelstag(dd) and int(tau) < t_schl <= int(tau) + h * TAG:
            n_td += 1
    return float(V * max(n_td, 0))


# ================================================================================================ Bedingte Szenarien und Stressfächer (13.4)

def episoden_ess(start: np.ndarray, w: np.ndarray, h: int) -> tuple:
    """
    Episoden-ESS: Fenster mit nennenswertem Gewicht (innerhalb von 3 Bandbreiten), deren Starts weniger als h Tage auseinanderliegen,
    bilden eine Episode; ESS = (Σ W_e)² ÷ Σ W_e². -> (ESS, Anteil der größten Episode, Zahl der Episoden)
    """
    if not len(w) or not (np.max(w) > 0):                    # kein Fenster mit Gewicht (Ereignis nie eingetreten, Kern im fernen Rand)
        return 0.0, float("nan"), 0
    rel = w >= KERN_RELEVANT * w.max()
    o = np.argsort(start[rel]); s = start[rel][o]; ww = w[rel][o]
    neu = np.concatenate([[True], np.diff(s) >= h * TAG])
    e = np.cumsum(neu) - 1
    W = np.bincount(e, weights=ww)
    return float(W.sum() ** 2 / np.sum(W * W)), float(W.max() / W.sum()), int(len(W))


def kopula_t(zb: np.ndarray, zs: np.ndarray) -> dict:
    """t-Kopula auf den Rängen: ρ = sin(π τ_K / 2), Freiheitsgrade per Profil-Likelihood aus T_NU."""
    ok = np.isfinite(zb) & np.isfinite(zs)
    zb, zs = zb[ok], zs[ok]
    n = len(zb)
    if n < 200:
        return {"n": n}
    tau = kendall_tau(zb, zs)
    rho = float(math.sin(math.pi * tau / 2))
    j = np.linspace(0, n - 1, min(n, 3000)).astype(int)
    u = (np.argsort(np.argsort(zb)) + 1) / (n + 1); v = (np.argsort(np.argsort(zs)) + 1) / (n + 1)
    u, v = u[j], v[j]
    best = None
    for nu in T_NU:
        x = t_ppf(u, nu); y = t_ppf(v, nu)
        q = (x * x - 2 * rho * x * y + y * y) / (1 - rho * rho)
        l2 = (math.lgamma((nu + 2) / 2) - math.lgamma(nu / 2) - math.log(nu * math.pi) - 0.5 * math.log(1 - rho * rho)
              - (nu + 2) / 2 * np.log1p(q / nu))
        ll = float(np.sum(l2 - t_logpdf(x, nu) - t_logpdf(y, nu)))
        if best is None or ll > best[1]:
            best = (nu, ll)
    return {"n": n, "tau": tau, "rho": rho, "nu": best[0], "ll": best[1]}


def kopula_bedingt(kop: dict, b_marg: np.ndarray, s_marg: np.ndarray, s_stern: float, ereignis: bool, n_sim: int = 100_000,
                   seed: int = 7) -> np.ndarray:
    """Bedingte Quantile der Krypto-Rendite unter der t-Kopula, über die Randverteilungen der Bibliothek zurückgerechnet."""
    rho, nu = kop["rho"], kop["nu"]
    u_s = float(np.clip(np.mean(s_marg <= s_stern), 1.0 / (len(s_marg) + 1), 1 - 1.0 / (len(s_marg) + 1)))
    if not ereignis:
        ts = float(t_ppf(np.array([u_s]), nu)[0])
        skala = math.sqrt((nu + ts * ts) * (1 - rho * rho) / (nu + 1))
        tb = rho * ts + skala * t_ppf(np.array(QUANTILE), nu + 1)
        ub = t_cdf(tb, nu)
    else:
        # Ereignisform U_S ≤ u*: genau im Ereignis ziehen statt verwerfen -- je Ziehung g = √(χ²_ν/ν), z1 aus der bei g·t* abgeschnittenen
        # Normalverteilung, Gewicht Φ(g·t*) (Likelihood-Quotient). 11.10.: vorher Verwerfen mit rund 2.500 Treffern; die Quantile
        # schwankten je Saat um bis zu 0,15 σ (Selbsttest „Ereignisform“).
        rng = np.random.default_rng(seed)
        t_st = float(t_ppf(np.array([u_s]), nu)[0])
        g = np.sqrt(rng.chisquare(nu, n_sim) / nu)
        P = norm_cdf(g * t_st)
        if not float(np.sum(P)) > 0:
            return np.full(len(QUANTILE), np.nan)
        z1 = norm_ppf(np.clip(rng.random(n_sim) * P, 1e-300, 1.0))
        z2 = rho * z1 + math.sqrt(1 - rho * rho) * rng.standard_normal(n_sim)
        ub = gew_quantile(t_cdf(z2 / g, nu), P, QUANTILE)
    return np.quantile(b_marg, np.clip(ub, 0, 1))


def bedingt(b: np.ndarray, s: np.ndarray, start: np.ndarray, s_stern: float, sig_s: float, h: int, ereignis: bool = False,
            kop: dict | None = None) -> dict:
    """
    „Wenn der S&P 500 in h Tagen um x % steht“: Kerngewichte w = exp(−½[(s − s*)/(λ·σ̂_S,h)]²), lokal-lineare Korrektur,
    gewichtete Quantile, Kish- und Episoden-ESS; unter ESS 15 der Rückfall t-Kopula. Ereignisform: Gewicht 1 für s ≤ s*.
    """
    ok = np.isfinite(b) & np.isfinite(s)
    b, s, start = b[ok], s[ok], start[ok]
    out = {"h": h, "s_stern": s_stern, "ereignis": ereignis}
    if len(b) < 100 or not np.isfinite(sig_s) or sig_s <= 0:
        out["grund"] = "zu wenige Fenster mit S&P-Pfad"; return out
    if ereignis:
        w = (s <= s_stern).astype(float)
        bk = b
    else:
        w = np.exp(-0.5 * ((s - s_stern) / (KERN_LAMBDA * sig_s)) ** 2)
        if w.sum() > 0:
            ws = w.sum(); ms = np.sum(w * s) / ws; mb = np.sum(w * b) / ws
            var = np.sum(w * (s - ms) ** 2)
            beta = np.sum(w * (s - ms) * (b - mb)) / var if var > 0 else 0.0
            bk = b - beta * (s - s_stern)
            out["beta_kern"] = float(beta)
        else:
            bk = b
    kish = float(w.sum() ** 2 / np.sum(w * w)) if np.sum(w * w) > 0 else 0.0
    ess, anteil, n_ep = episoden_ess(start, w, h)
    out.update(kish=kish, ess=ess, groesste=anteil, episoden=n_ep, n=len(b))
    if w.sum() > 0:
        q = gew_quantile(bk, w, QUANTILE)
        out["bib"] = {"q": [float(x) for x in q], "p_tiefer": float(np.sum(w * (bk < 0)) / w.sum())}
    out["methode"] = "bibliothek" if ess >= ESS_MIN and "bib" in out else "kopula"
    if kop and kop.get("nu"):
        qk = kopula_bedingt(kop, b, s, s_stern, ereignis)
        if np.all(np.isfinite(qk)):
            out["kopula"] = {"q": [float(x) for x in qk], "rho": kop["rho"], "nu": kop["nu"]}
    if out["methode"] == "kopula" and "kopula" not in out:
        out["methode"] = "keine"
    return out


def stress_zeitraum(VIX: dict | None) -> tuple | None:
    """365-Tage-Zeitraum seit 2020 mit dem höchsten mittleren ln VIX (vorab aus VIXCLS bestimmt) -> (Start, Ende) in UTC-Sekunden."""
    if not VIX or len(VIX["ts"]) < 400:
        return None
    t = np.asarray(VIX["ts"], dtype=np.int64); w = np.log(np.asarray(VIX["w"], dtype=float))
    m = t >= LIB_AB
    t, w = t[m], w[m]
    best = None
    for i in range(len(t)):
        j = np.searchsorted(t, t[i] + 365 * TAG)
        if j >= len(t):
            break
        v = float(np.mean(w[i:j]))
        if best is None or v > best[0]:
            best = (v, int(t[i]), int(t[i] + 365 * TAG))
    return (best[1], best[2]) if best else None


# ================================================================================================ Richtung: Kandidaten (4.4, 13.5)

KANDIDATEN = (
    ("P1", "Kurs", "Wochenmomentum"), ("P2", "Kurs", "Vierwochenmomentum"), ("P3", "Kurs", "Quartalsmomentum"),
    ("P4", "Kurs", "Tagesumkehr"), ("P5", "Kurs", "Abstand zur 200-Tage-Linie"), ("P6", "Kurs", "Steigung der 50-Tage-Linie"),
    ("P7", "Kurs", "Bein (U141)"), ("P8", "Kurs", "RSI 14"), ("P9", "Kurs", "Marktmomentum (P1 von BTC)"),
    ("P10", "Kurs", "Schwankungslage"),
    ("D1", "Derivate", "Funding-Druck (z30)"), ("D2", "Derivate", "Funding-Niveau 7 T (Jahresrate)"),
    ("D3", "Positionierung", "OI-Änderung 28 T"), ("D4", "Positionierung", "OI-Perzentil 90 T"),
    ("D5", "Positionierung", "Konten (ln Long/Short)"), ("D6", "Positionierung", "Konten-Perzentil 90 T"),
    ("D7", "Positionierung", "Top-Trader nach Positionen (ln)"), ("D8", "Positionierung", "Top-Trader nach Konten (ln)"),
    ("D9", "Positionierung", "Taker (ln, Mittel 7 T)"), ("D10", "Positionierung", "Perp-Anteil am Volumen (BTC, ETH)"),
    ("M1", "Makro", "MVRV-Perzentil"), ("M2", "Makro", "Kurs ÷ Power-Law-Fair-Value (Perzentil)"),
    ("M3", "Makro", "Abstand zum 200-Wochen-MA (Perzentil)"), ("M4", "Makro", "Kurs ÷ Kurzfrist-Kostenbasis − 1"),
    ("M5", "Makro", "MVRV-Z"), ("M6", "Makro", "Puell (Perzentil)"), ("M7", "Makro", "DVOL"), ("M8", "Makro", "Fear & Greed 30 T"),
    ("M9", "Makro", "SSR (Perzentil)"), ("M10", "Makro", "Nettoliquidität, Änderung 4 Wochen"),
    ("M11", "Makro", "Realzins 10 J, Änderung 4 Wochen"), ("M12", "Makro", "Dollar breit, Änderung 4 Wochen"),
    ("A1", "Aktien", "Nasdaq-100-Momentum 1 Woche"), ("A2", "Aktien", "Nasdaq-100-Momentum 4 Wochen"),
    ("A3", "Aktien", "VIX-Laufzeitstruktur ln(VIX/VIX3M)"), ("A4", "Aktien", "Kreditspread Baa − 10 J, Änderung 4 Wochen"),
)
K_NAMEN = tuple(k for k, _, _ in KANDIDATEN)
PAXG_KANDIDATEN = ("P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P10")
MAKRO_SCHLUESSEL = {"M1": "mvrv_pz", "M2": "pl_pz", "M3": "wma_pz", "M4": "sth", "M5": "mvrvz", "M6": "puell_pz", "M7": "dvol",
                    "M8": "fng30", "M9": "ssr_pz", "M10": "netliq4w", "M11": "realzins4w", "M12": "dollar4w"}


def tagesachse(A: dict) -> dict:
    """Die 00-UTC-Anker als Tagesreihe: Tag d = der UTC-Tag, der am Anker endet."""
    j0 = np.nonzero(A["stunde"] == 0)[0]
    return {"j": j0, "tag": (A["tau"][j0] // TAG - 1).astype(np.int64), "C": A["C"][j0], "H": A["H"][j0], "L": A["L"][j0], "n": len(j0)}


def _sma(x: np.ndarray, n: int) -> np.ndarray:
    out = np.full(len(x), np.nan)
    if len(x) < n:
        return out
    ok = np.isfinite(x); cs = np.concatenate([[0.0], np.cumsum(np.where(ok, x, 0.0))]); cn = np.concatenate([[0], np.cumsum(ok)])
    s = cs[n:] - cs[:-n]; c = cn[n:] - cn[:-n]
    out[n - 1:] = np.where(c == n, s / n, np.nan)
    return out


def bein_reihe(c: np.ndarray, X: float) -> dict:
    """
    Directional Change kausal je Tag (Regeln wie hl_zyklus.dc_batch, Schwelle X): Richtung, Start (letztes bestätigtes Extrem),
    laufendes Extrem; Median der abgeschlossenen Beine je Richtung bis zum Tag (das erste Extrem zählt nicht als Beinanfang).
    P7 = Richtung · Größe bisher ÷ Median der abgeschlossenen Beine dieser Richtung (Log-Größen).
    """
    n = len(c); x = np.log(c)
    u, v = math.log(1 + X), -math.log(1 - X)
    out = {"p7": np.full(n, np.nan), "mode": np.zeros(n, dtype=np.int8), "start": np.full(n, np.nan), "ext": np.full(n, np.nan)}
    i0 = next((i for i in range(n) if np.isfinite(x[i])), None)
    if i0 is None:
        return out
    mode = 0; hi = lo = x[i0]
    ext_liste = []                                            # bestätigte Extreme (typ, Wert) in Zeitfolge
    auf, ab = [], []
    start = np.nan
    for t in range(i0 + 1, n):
        xt = x[t]
        if not np.isfinite(xt):
            out["mode"][t] = mode; continue
        if mode >= 0 and xt > hi:
            hi = xt
        if mode <= 0 and xt < lo:
            lo = xt
        top = mode >= 0 and xt <= hi - v
        bot = mode <= 0 and xt >= lo + u and not top
        if top:
            ext_liste.append((1, hi))
            if len(ext_liste) >= 3 and ext_liste[-2][0] == -1:   # abgeschlossene Rallye: Tief (nicht das erste Extrem) -> Hoch
                auf.append(hi - ext_liste[-2][1])
            start = hi; mode = -1; lo = xt
        elif bot:
            ext_liste.append((-1, lo))
            if len(ext_liste) >= 3 and ext_liste[-2][0] == 1:
                ab.append(ext_liste[-2][1] - lo)
            start = lo; mode = 1; hi = xt
        out["mode"][t] = mode
        if mode == 1 and np.isfinite(start) and auf:
            out["p7"][t] = (hi - start) / float(np.median(auf)); out["start"][t] = math.exp(start); out["ext"][t] = math.exp(hi)
        elif mode == -1 and np.isfinite(start) and ab:
            out["p7"][t] = -(start - lo) / float(np.median(ab)); out["start"][t] = math.exp(start); out["ext"][t] = math.exp(lo)
    out["auf"] = auf; out["ab"] = ab
    return out


def _auf_tage(tag: np.ndarray, quelle_tag: np.ndarray, werte: np.ndarray, versatz: int = 0) -> np.ndarray:
    """Werte einer Tagesreihe (Tag q) auf die Tagesachse: am Tag d gilt der Wert von d − versatz."""
    out = np.full(len(tag), np.nan)
    if quelle_tag is None or werte is None or not len(quelle_tag):
        return out
    pos = {int(t): i for i, t in enumerate(quelle_tag)}
    w = np.asarray(werte, dtype=float)
    for i, d in enumerate(tag):
        j = pos.get(int(d) - versatz)
        if j is not None:
            out[i] = w[j]
    return out


def kandidaten_roh(coin: str, D: dict, sig: np.ndarray, ext: dict) -> np.ndarray:
    """Rohwerte der 36 Kandidaten am Tag d (Spalten in K_NAMEN), NaN wo nicht verfügbar. sig = √F(d,1) (HAR, Tag)."""
    import hl_swing as SW
    import hl_zyklus as ZY
    n = D["n"]; C = D["C"]; lc = np.log(C); tag = D["tag"]
    X = np.full((n, len(K_NAMEN)), np.nan)
    col = {k: i for i, k in enumerate(K_NAMEN)}

    def lag(a, k):
        o = np.full(n, np.nan); o[k:] = a[:-k]; return o
    with np.errstate(invalid="ignore", divide="ignore"):
        for k, L in (("P1", 7), ("P2", 28), ("P3", 91), ("P4", 1)):
            X[:, col[k]] = (lc - lag(lc, L)) / (sig * math.sqrt(L))
        ma200 = _sma(C, 200); ma50 = _sma(C, 50)
        X[:, col["P5"]] = np.log(C / ma200) / (sig * math.sqrt(28))
        X[:, col["P6"]] = np.log(ma50 / lag(ma50, 10)) / (sig * math.sqrt(10))
        X[:, col["P7"]] = bein_reihe(C, 0.03 if coin == "PAXG" else 0.10)["p7"]
        X[:, col["P8"]] = (SW.rsi_wilder(C, 14) - 50.0) / 10.0
        ls = np.log(sig); med = np.full(n, np.nan)
        for t in range(365, n):
            w_ = ls[t - 365:t]; w_ = w_[np.isfinite(w_)]
            if len(w_) >= 200:
                med[t] = float(np.median(w_))
        X[:, col["P10"]] = ls - med
    if coin != "PAXG" and ext.get("p1_btc") is not None:
        X[:, col["P9"]] = _auf_tage(tag, ext["p1_btc"][0], ext["p1_btc"][1])
    if coin == "PAXG":
        for k in K_NAMEN:
            if k not in PAXG_KANDIDATEN:
                X[:, col[k]] = np.nan
        return X
    # Derivate (swing.db) und Positionierung (hebel.db)
    fz = ext.get("funding_z"); fd = ext.get("funding_tag")
    if fz is not None:
        X[:, col["D1"]] = _auf_tage(tag, fz[0], fz[1])
    if fd is not None:
        f7 = _sma(np.asarray(fd[1], dtype=float), 7) * 3 * 365
        X[:, col["D2"]] = _auf_tage(tag, fd[0], f7)
    T = ext.get("tafel")
    if T is not None:
        tt = T["tag0"] + np.arange(T["n"])
        with np.errstate(invalid="ignore", divide="ignore"):
            if T.get("oi") is not None:
                oi = np.asarray(T["oi"], dtype=float)
                d3 = np.full(len(oi), np.nan); d3[28:] = np.log(oi[28:] / oi[:-28])
                X[:, col["D3"]] = _auf_tage(tag, tt, d3)
                X[:, col["D4"]] = _auf_tage(tag, tt, ZY.oi_perzentil(oi, 90, 60))
            if T.get("konten") is not None:
                X[:, col["D5"]] = _auf_tage(tag, tt, np.log(T["konten"]))
                X[:, col["D6"]] = _auf_tage(tag, tt, ZY.oi_perzentil(np.asarray(T["konten"], dtype=float), 90, 60))
            if T.get("top_pos") is not None:
                X[:, col["D7"]] = _auf_tage(tag, tt, np.log(T["top_pos"]))
            if T.get("top_konten") is not None:
                X[:, col["D8"]] = _auf_tage(tag, tt, np.log(T["top_konten"]))
            if T.get("taker") is not None:
                X[:, col["D9"]] = _auf_tage(tag, tt, np.log(_sma(np.asarray(T["taker"], dtype=float), 7)))
            if T.get("anteil") is not None:
                X[:, col["D10"]] = _auf_tage(tag, tt, T["anteil"])
    # Makro (marktweit; Wert vom Vortag -- Veröffentlichung, FRED in merkmale schon mit 7 T Versatz)
    for k, sk in MAKRO_SCHLUESSEL.items():
        m = (ext.get("makro") or {}).get(sk)
        if m is not None:
            X[:, col[k]] = _auf_tage(tag, m[0], m[1], versatz=1)
    # Aktien (marktweit; US-Schluss erst ab d+1 14:00 UTC)
    for k in ("A1", "A2", "A3", "A4"):
        a = (ext.get("aktien") or {}).get(k)
        if a is not None:
            X[:, col[k]] = us_asof(a[0], a[1], (tag + 1) * TAG, US_VERZUG_S, max_alter=10 * TAG)
    return X


def aktien_kandidaten(R: dict) -> dict:
    """A1–A4 je US-Handelstag (Zeitstempel = Datum, die Verfügbarkeit regelt us_asof)."""
    out = {}
    nd = R.get("fred:NASDAQ100")
    if nd is not None and len(nd["ts"]) > 80:
        t = nd["ts"]; lp = np.log(nd["w"]); r = np.full(len(lp), np.nan); r[1:] = lp[1:] - lp[:-1]
        sd = np.full(len(lp), np.nan)
        for i in range(60, len(lp)):
            sd[i] = np.nanstd(r[i - 59:i + 1], ddof=1)
        for k, L in (("A1", 5), ("A2", 20)):
            v = np.full(len(lp), np.nan); v[L:] = (lp[L:] - lp[:-L]) / (sd[L:] * math.sqrt(L))
            out[k] = (t, v)
    vx, v3 = R.get("fred:VIXCLS"), R.get("fred:VXVCLS")
    if vx is not None and v3 is not None and len(vx["ts"]) and len(v3["ts"]):
        m = dict(zip(v3["ts"].tolist(), v3["w"].tolist()))
        t = np.array([x for x in vx["ts"] if x in m], dtype=np.int64)
        w = np.array([math.log(a / m[x]) for x, a in zip(vx["ts"], vx["w"]) if x in m])
        out["A3"] = (t, w)
    ba = R.get("fred:BAA10Y")
    if ba is not None and len(ba["ts"]) > 25:
        v = np.full(len(ba["w"]), np.nan); v[20:] = ba["w"][20:] - ba["w"][:-20]
        out["A4"] = (ba["ts"], v)
    return out


def standardisieren(X: np.ndarray) -> tuple:
    """Je Kandidat kausal z-normiert (Mittel und Standardabweichung der 730 Tage bis d), auf ±4 gekappt; unter 365 gültigen Tagen 0
    (neutral). -> (Z, zu_kurz Maske)"""
    n, p = X.shape
    ok = np.isfinite(X)
    x0 = np.where(ok, X, 0.0)
    c1 = np.vstack([np.zeros((1, p)), np.cumsum(x0, axis=0)]); c2 = np.vstack([np.zeros((1, p)), np.cumsum(x0 * x0, axis=0)])
    cn = np.vstack([np.zeros((1, p)), np.cumsum(ok, axis=0)])
    i = np.arange(n); a = np.maximum(0, i + 1 - Z_FENSTER)
    s1 = c1[i + 1] - c1[a]; s2 = c2[i + 1] - c2[a]; nn = cn[i + 1] - cn[a]
    with np.errstate(invalid="ignore", divide="ignore"):
        m = s1 / nn; v = (s2 - nn * m * m) / np.maximum(nn - 1, 1)
        Z = (X - m) / np.sqrt(v)
    kurz = nn < Z_MIN
    Z = np.where(ok & ~kurz & np.isfinite(Z), np.clip(Z, -Z_KAPPE, Z_KAPPE), 0.0)
    return Z, kurz | ~ok


# ================================================================================================ Richtung: Ridge im Walk-forward (4.4)

class Ridge:
    """
    Gepoolter Ridge ohne Achsenabschnitt mit kumulierten Kreuzprodukten je Tag: Neuschätzungen, Kreuzvalidierung mit Purging,
    Weglassen eines Kandidaten und Nullläufe kosten je Neuschätzung nur ein Gleichungssystem der Größe p.
    """

    def __init__(self, tag: np.ndarray, X: np.ndarray, y: np.ndarray, h: int):
        o = np.lexsort((np.arange(len(tag)), tag))
        self.tag = np.asarray(tag)[o].astype(np.int64); self.X = np.asarray(X, dtype=float)[o]; self.y = np.asarray(y, dtype=float)[o]
        self.ordnung = o; self.h = h
        self.d0 = int(self.tag[0]); self.nd = int(self.tag[-1]) - self.d0 + 1
        self.di = self.tag - self.d0
        self.p = self.X.shape[1]
        nd, p = self.nd, self.p
        A = np.empty((nd, p, p))
        for i in range(p):
            for k in range(i, p):
                v = np.bincount(self.di, weights=self.X[:, i] * self.X[:, k], minlength=nd)
                A[:, i, k] = v; A[:, k, i] = v
        b = np.column_stack([np.bincount(self.di, weights=self.X[:, i] * self.y, minlength=nd) for i in range(p)])
        c = np.bincount(self.di, weights=self.y * self.y, minlength=nd); m = np.bincount(self.di, minlength=nd).astype(float)
        self.CA = np.concatenate([np.zeros((1, p, p)), np.cumsum(A, axis=0)]); self.Cb = np.concatenate([np.zeros((1, p)), np.cumsum(b, axis=0)])
        self.Cc = np.concatenate([[0.0], np.cumsum(c)]); self.Cm = np.concatenate([[0.0], np.cumsum(m)])

    def _summe(self, a: int, e: int):
        """Summen über die Tage a … e (Indizes relativ zu d0, eingeschlossen; außerhalb abgeschnitten)."""
        a = max(a, 0); e = min(e, self.nd - 1)
        if e < a:
            p = self.p
            return np.zeros((p, p)), np.zeros(p), 0.0, 0.0
        return (self.CA[e + 1] - self.CA[a], self.Cb[e + 1] - self.Cb[a], self.Cc[e + 1] - self.Cc[a], self.Cm[e + 1] - self.Cm[a])

    def lam_cv(self, e: int) -> float:
        """λ aus 5 zeitlich geblockten Teilen der Trainingstage 0 … e, je h Tage Abstand vor und nach dem Prüfteil (Purging, Embargo)."""
        A_all, b_all, _, n_all = self._summe(0, e)
        if n_all < 50:
            return LAMBDA_GITTER[-1] * max(n_all, 1)
        grenzen = np.linspace(0, e + 1, CV_TEILE + 1).astype(int)
        fehler = np.zeros(len(LAMBDA_GITTER))
        for f in range(CV_TEILE):
            a, z = int(grenzen[f]), int(grenzen[f + 1]) - 1
            if z < a:
                continue
            A_v, b_v, c_v, n_v = self._summe(a, z)
            if n_v == 0:
                continue
            # Purging nur innerhalb der Trainingstage 0 … e (Fund des Selbsttests „Embargo der Richtung“, 11.10.: bis dahin zog der
            # letzte Teil h Tage NACH e ab, die nie addiert waren -- λ hing so von Zielen ab, die bis in den Schätztag reichen)
            A_p, b_p, _, n_p = self._summe(a - self.h, min(z + self.h, e))
            A_t = A_all - A_p; b_t = b_all - b_p; n_t = n_all - n_p
            if n_t < 30:
                continue
            ev, V = np.linalg.eigh(A_t)
            bt = V.T @ b_t
            for li, lam in enumerate(LAMBDA_GITTER):
                w = V @ (bt / (ev + lam * n_all))
                fehler[li] += c_v - 2 * w @ b_v + w @ A_v @ w
        return float(LAMBDA_GITTER[int(np.argmin(fehler))] * n_all)

    def ersatz(self, j: int, neu: np.ndarray) -> tuple:
        """Kumulierte Summen für Spalte j durch neu ersetzt (Originalreihenfolge): Σ x_j'·x_k (mit x_j' an Stelle j), Σ x_j'·y."""
        xs = np.asarray(neu, dtype=float)[self.ordnung]
        Xm = self.X.copy(); Xm[:, j] = xs
        v = np.column_stack([np.bincount(self.di, weights=xs * Xm[:, k], minlength=self.nd) for k in range(self.p)])
        by = np.bincount(self.di, weights=xs * self.y, minlength=self.nd)
        return (j, np.concatenate([np.zeros((1, self.p)), np.cumsum(v, axis=0)]), np.concatenate([[0.0], np.cumsum(by)]), xs)

    def walk(self, ab_tag: int, refit: int = REFIT_TAGE, lams: list | None = None, keep=None, ersatz: tuple | None = None) -> dict:
        """
        Walk-forward: erste Schätzung am Tag ab_tag, dann alle refit Tage. Training: Tage, deren Ziel vor dem Schätztag endet
        (d + h < Schätztag). keep: benutzte Spalten (Weglassen eines Kandidaten); ersatz: Spalte j ersetzt (Nullläufe); lams: λ je
        Neuschätzung fest (sonst Kreuzvalidierung). -> {refits: [(Tag, λ, w)], mhat je Zeile (Originalreihenfolge)}
        """
        keep = np.arange(self.p) if keep is None else np.asarray(keep)
        X = self.X
        if ersatz is not None:
            j, Cv, Cy, xs = ersatz
            X = self.X.copy(); X[:, j] = xs
            jj = int(np.nonzero(keep == j)[0][0]) if j in keep else None
        refits = []; mhat = np.full(len(self.y), np.nan)
        T = ab_tag; k = 0
        letzter = self.d0 + self.nd - 1
        ix = np.ix_(keep, keep)
        while T <= letzter:
            e = min(T - self.h - 1 - self.d0, self.nd - 1)            # Ziel endet am Ende von d + h ≤ T − 1
            if e >= 30:
                lam = lams[k] if lams is not None and k < len(lams) else self.lam_cv(e)
                A = self.CA[e + 1][ix].copy(); b = self.Cb[e + 1][keep].copy()
                if ersatz is not None and jj is not None:
                    A[jj, :] = Cv[e + 1][keep]; A[:, jj] = Cv[e + 1][keep]; b[jj] = Cy[e + 1]
                w = np.linalg.solve(A + lam * np.eye(len(keep)), b)
                refits.append((T, lam, w))
                o = (self.tag >= T) & (self.tag < T + refit)
                if o.any():
                    mhat[o] = np.clip(X[o][:, keep] @ w, -M_KAPPE, M_KAPPE)
            T += refit; k += 1
        out = np.full(len(self.y), np.nan); out[self.ordnung] = mhat
        return {"refits": refits, "mhat": out, "mhat_sortiert": mhat}


def mse_oos(y: np.ndarray, mhat: np.ndarray, maske: np.ndarray) -> float:
    m = maske & np.isfinite(mhat) & np.isfinite(y)
    return float(np.mean((y[m] - mhat[m]) ** 2)) if m.any() else float("nan")


# ================================================================================================ Daten laden (nur lesend)

AK_REIHEN = ("fred:SP500", "fred:NASDAQ100", "fred:VIXCLS", "fred:VXVCLS", "fred:BAA10Y", "fred:STLFSI4", "drb:dvol_btc_h", "drb:dvol_eth_h")


def lade(db: str, coins=COINS, log=None) -> dict:
    """Alles, was der Ausblick liest: 30-min-Kerzen je Coin (Anker), Aktien- und DVOL-Reihen (aktien.db), Makro-Merkmale (makro.db),
    Positionierung (hebel.db), Funding (swing.db). Fehlt eine Quelle, steht der Grund in fehlt; der Rest läuft."""
    import hl_aktien as AK
    import hl_swing as SW
    log = log or (lambda *a: None)
    G = {"coins": {}, "fehlt": [], "R": {}, "db": db}
    con = AK.lesen(AK.aktien_pfad(db))
    if con is None:
        G["fehlt"].append("aktien.db fehlt noch (Aktien-Takt) -- ohne S&P-Koordinate, Aktien-Kandidaten und HAR-X")
    else:
        try:
            for r in AK_REIHEN:
                t, w = AK.reihe(con, r)
                if len(t):
                    G["R"][r] = {"ts": t, "w": w}
            G["xyz_sp"] = AK.kerzen(con, "xyz:SP500:30m", ab=int(time.time()) - 3 * TAG)
        finally:
            con.close()
    # Makro-Merkmale (wie U130) und BTC-DVOL täglich als Ersatz vor dem stündlichen Archiv
    try:
        import hl_makro as MK
        import hl_makro_korr as MKK
        mc = MK.lesen(MK.makro_pfad(db))
        if mc is None:
            G["fehlt"].append("makro.db fehlt -- ohne M1–M12")
        else:
            try:
                D = MK.ableiten(mc)
                t_dv, w_dv = MK.Reihen(mc)("drb:dvol_btc")
                if len(t_dv):
                    G["dvol_btc_tag"] = (t_dv, w_dv)
            finally:
                mc.close()
            if D.get("ok"):
                tage = np.asarray(D["tage"], dtype=np.int64)
                G["makro"] = {k: (tage, np.asarray(a, dtype=float)) for k, _n, a, _h, _s in MKK.merkmale(D) if a is not None}
            else:
                G["fehlt"].append(f"Makro-Daten unvollständig ({D.get('grund')}) -- ohne M1–M12")
    except Exception as e:
        G["fehlt"].append(f"makro.db nicht lesbar ({type(e).__name__}: {e})"[:120])
    try:
        import hl_hebel as HB
        G["tafeln"] = HB.daten_laden(db, log=lambda *a: None).get("tafeln") or {}
    except Exception as e:
        G["tafeln"] = {}; G["fehlt"].append(f"hebel.db nicht lesbar ({type(e).__name__})")
    sw_pfad = SW.swing_pfad(db)
    sw = sqlite3.connect(f"file:{sw_pfad}?mode=ro", uri=True, timeout=10) if os.path.exists(sw_pfad) else None
    try:
        for coin in coins:
            K = AK.kerzen_30m(db, coin)
            A = anker_reihen(K) if K is not None else None
            if A is None:
                G["fehlt"].append(f"{coin}: zu wenige 30-min-Kerzen ({'swing.db' if coin != 'PAXG' else 'regime.db'})"); continue
            e = {"A": A}
            if coin in SW.COINS and sw is not None and K is not None:
                try:
                    F = SW.funding_lesen(sw, coin)
                    Tsw = SW.tagesreihen(K)
                    if Tsw is not None and len(F["ts"]):
                        tage = Tsw["d0"] + np.arange(Tsw["nd"])
                        e["funding_z"] = (tage, SW.Kennzahlen(Tsw, F).fz(30)); e["funding_tag"] = (tage, SW.funding_tage(Tsw, F))
                except sqlite3.Error:
                    pass
            G["coins"][coin] = e
            log(f"  {coin}: {A['n']} Anker bis {_dtz(A['tau'][-1])}")
    finally:
        if sw is not None:
            sw.close()
    return G


def sp_reihen(G: dict) -> dict:
    """S&P-Tagesreihe mit realisierter Varianz (5/20 Tage) je Handelstag."""
    sp = G["R"].get("fred:SP500")
    if sp is None or len(sp["ts"]) < 30:
        return {}
    lp = np.log(sp["w"]); r = np.full(len(lp), np.nan); r[1:] = lp[1:] - lp[:-1]
    r2 = r * r
    rv5 = np.full(len(lp), np.nan); rv20 = np.full(len(lp), np.nan)
    c2 = np.concatenate([[0.0], np.cumsum(np.where(np.isfinite(r2), r2, 0.0))]); cn = np.concatenate([[0], np.cumsum(np.isfinite(r2))])
    for L, out in ((5, rv5), (20, rv20)):
        i = np.arange(L, len(lp)); s = c2[i + 1] - c2[i + 1 - L]; nn = cn[i + 1] - cn[i + 1 - L]
        out[L:] = np.where(nn >= L - 1, s / np.maximum(nn, 1), np.nan)
    return {"ts": sp["ts"], "rv5": rv5, "rv20": rv20}


def x_spalten(coin: str, A: dict, G: dict, zeiten: np.ndarray | None = None) -> dict:
    """Zusätze X1–X4 (13.2) zu den Zeitpunkten (Standard: die Anker des Coins). X1 nicht für PAXG; ETH mit der ETH-DVOL, sonst BTC."""
    t = A["tau"] if zeiten is None else np.asarray(zeiten, dtype=np.int64)
    out = {}
    if coin != "PAXG":
        dv = G["R"].get("drb:dvol_eth_h" if coin == "ETH" else "drb:dvol_btc_h")
        v = us_asof(dv["ts"], dv["w"], t, verzug=3600, max_alter=6 * 3600) if dv is not None else np.full(len(t), np.nan)
        if coin != "ETH" and G.get("dvol_btc_tag") is not None:                # vor dem stündlichen Archiv: Tageswert (Vortag)
            td, wd = G["dvol_btc_tag"]
            vt = us_asof(np.asarray(td) * TAG, wd, t, verzug=TAG, max_alter=3 * TAG)
            v = np.where(np.isfinite(v), v, vt)
        with np.errstate(divide="ignore", invalid="ignore"):
            out["X1"] = np.log((v / 100.0) ** 2)
        S = sp_reihen(G)
        if S:
            with np.errstate(divide="ignore", invalid="ignore"):
                out["X2"] = np.column_stack([np.log(us_asof(S["ts"], S["rv5"], t)), np.log(us_asof(S["ts"], S["rv20"], t))])
        st = G["R"].get("fred:STLFSI4")
        if st is not None:
            out["X3"] = us_asof(st["ts"], st["w"], t, verzug=WOCHE_VERZUG_S, max_alter=21 * TAG)
        vx = G["R"].get("fred:VIXCLS")
        if vx is not None:
            with np.errstate(divide="ignore", invalid="ignore"):
                out["X4"] = 2 * np.log(us_asof(vx["ts"], vx["w"], t))
    return out


def extra_matrix(Xs: dict, wahl: list) -> np.ndarray | None:
    if not wahl:
        return None
    teile = [Xs[k] if Xs[k].ndim == 2 else Xs[k][:, None] for k in wahl if k in Xs]
    return np.column_stack(teile) if teile else None


# ================================================================================================ Speicher (ausblick.db)

SCHEMA = """
CREATE TABLE IF NOT EXISTS au_prognose (coin TEXT NOT NULL, anker INTEGER NOT NULL, erzeugt INTEGER, art TEXT, json TEXT,
    PRIMARY KEY (coin, anker)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS au_vorwaerts (coin TEXT NOT NULL, anker INTEGER NOT NULL, h INTEGER NOT NULL, p0 REAL, F REAL, mhat REAL,
    tor INTEGER, sigma_b1 REAL, q99 TEXT, niveaus TEXT, ausgewertet INTEGER, ergebnis TEXT, PRIMARY KEY (coin, anker, h)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS au_gewichte (stand INTEGER NOT NULL, h INTEGER NOT NULL, gruppe TEXT NOT NULL, refit INTEGER NOT NULL,
    lam REAL, w TEXT, PRIMARY KEY (stand, h, gruppe, refit)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS au_null (stand INTEGER NOT NULL, h INTEGER NOT NULL, gruppe TEXT NOT NULL, kandidat TEXT NOT NULL,
    json TEXT, PRIMARY KEY (stand, h, gruppe, kandidat)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS au_rueckblick (stand INTEGER PRIMARY KEY, dauer REAL, json TEXT);
CREATE TABLE IF NOT EXISTS au_meta (k TEXT PRIMARY KEY, v TEXT);
"""


def ausblick_pfad(db: str) -> str:
    p = os.environ.get("HL_AUSBLICK_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "ausblick.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def lesen(pfad: str) -> sqlite3.Connection | None:
    if not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, check_same_thread=False)


def _tx(con, fn):
    con.execute("BEGIN IMMEDIATE")
    try:
        r = fn()
        con.execute("COMMIT")
        return r
    except BaseException:
        con.execute("ROLLBACK")
        raise


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM au_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def meta_setzen(con, paare: dict) -> None:
    _tx(con, lambda: con.executemany("INSERT INTO au_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                                     [(k, v if isinstance(v, str) else json.dumps(v)) for k, v in paare.items()]))


def _json_meta(con, k: str, standard=None):
    v = meta(con, k)
    if v is None:
        return standard
    try:
        return json.loads(v)
    except ValueError:
        return standard


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, (np.floating,)):
        return float(x) if np.isfinite(x) else None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, np.ndarray):
        return [_ohne_nan(v) for v in x.tolist()]
    if isinstance(x, dict):
        return {str(k): _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_ohne_nan(v) for v in x]
    return x


# ================================================================================================ Vorbereitung je Coin

def breiten(A: dict, Xs: dict, wahl: dict | None = None) -> dict:
    """F je Stützstelle (Walk-forward) mit dem gewählten Modell je Horizont (wahl[h] = Liste der Zusätze, Standard: Grundmodell)."""
    out = {}
    for h in H_STUETZ:
        w = list((wahl or {}).get(str(h)) or (wahl or {}).get(h) or [])
        ex = extra_matrix(Xs, w)
        out[h] = har_walk(A, h, extra=ex)
        out[h]["wahl"] = w
    return out


def vorbereiten(coin: str, G: dict, wahl: dict | None = None) -> dict | None:
    """Anker, Breite (gewähltes Modell), Pfad-Bibliothek, Tagesachse mit Ziel y_h und Kandidaten (roh) für einen Coin."""
    e = G["coins"].get(coin)
    if e is None:
        return None
    A = e["A"]
    Xs = x_spalten(coin, A, G)
    W = breiten(A, Xs, wahl)
    Fs = {h: W[h]["F"] for h in H_STUETZ}
    Fk = F_pfad(Fs)
    B = bibliothek(A, Fk, coin)
    D = tagesachse(A)
    j = D["j"]
    sig = np.sqrt(Fs[1][j])
    ys = {}
    for h in H_ZIEL:
        R = np.full(D["n"], np.nan)
        R[:-h] = np.log(D["C"][h:] / D["C"][:-h])
        ys[h] = R / np.sqrt(Fs[h][j])
    return {"coin": coin, "A": A, "Xs": Xs, "W": W, "Fs": Fs, "Fk": Fk, "B": B, "D": D, "sig": sig, "y": ys,
            "tage_hist": int((A["tau"][-1] - A["tau"][0]) // TAG)}


def kandidaten_alle(V: dict, G: dict) -> dict:
    """Rohkandidaten und standardisierte Kandidaten je Coin (P9 braucht BTC zuerst)."""
    p1 = None
    if "BTC" in V:
        Xb = kandidaten_roh("BTC", V["BTC"]["D"], V["BTC"]["sig"], {})
        p1 = (V["BTC"]["D"]["tag"], Xb[:, K_NAMEN.index("P1")])
    out = {}
    aktien = aktien_kandidaten(G["R"])
    for coin, v in V.items():
        e = G["coins"][coin]
        ext = {"p1_btc": p1, "funding_z": e.get("funding_z"), "funding_tag": e.get("funding_tag"), "tafel": (G.get("tafeln") or {}).get(coin),
               "makro": G.get("makro"), "aktien": aktien}
        Xr = kandidaten_roh(coin, v["D"], v["sig"], ext)
        Z, kurz = standardisieren(Xr)
        out[coin] = {"roh": Xr, "Z": Z, "kurz": kurz}
    return out


def bibliothek_fuer(coin: str, V: dict) -> tuple:
    """Eigene Bibliothek; HYPE unter 730 Tagen die gepoolte der Krypto-Coins; PAXG nur eigene ab 365 Tagen (sonst None)."""
    v = V[coin]
    if coin == "PAXG":
        return (v["B"], "eigene") if v["tage_hist"] >= PAXG_MIN_TAGE else (None, f"PAXG: weniger als {PAXG_MIN_TAGE} Tage Historie")
    if v["tage_hist"] < POOL_MIN_TAGE:
        Bs = [V[c]["B"] for c in KRYPTO if c in V]
        return bib_verbinden(Bs), f"gepoolt ({', '.join(c for c in KRYPTO if c in V)}; eigene Historie {v['tage_hist']} Tage)"
    return v["B"], "eigene"


def regressoren_bei(A: dict, tau: int) -> np.ndarray | None:
    """HAR-Regressoren zu einem beliebigen Halbstundenzeitpunkt τ aus dem 30-min-Raster (Ankerstunde: eigener Achsenabschnitt,
    sonst das Mittel der vier)."""
    r = A["r30"]; t0 = A["t0_kerze"]
    ie = int((int(tau) - BAR - t0) // BAR)
    if ie >= len(r) or ie - 48 * 30 < 0:
        return None
    rv = []
    for m in range(30):
        b = ie - 48 * m; seg = r[b - 47: b + 1]; g = int(np.isfinite(seg).sum())
        rv.append(float(np.nansum(seg * seg) * 48 / g) if g >= RV_MIN_GUELTIG else float("nan"))
    rv = np.array(rv)
    if not np.all(np.isfinite(rv[:7])) or np.sum(np.isfinite(rv)) < 25 or rv[0] <= 0:
        return None
    if int(tau) % ANKER_S == 0:
        d = [1.0 if (int(tau) % TAG) // 3600 == s else 0.0 for s in (0, 6, 12, 18)]
    else:
        d = [0.25] * 4
    return np.array(d + [math.log(rv[0]), math.log(np.mean(rv[:7])), math.log(np.nanmean(rv))])


def F_bei(v: dict, G: dict, tau: int) -> dict | None:
    """F(τ, h) an den Stützstellen mit den jüngsten Koeffizienten des gewählten Modells je Horizont."""
    x0 = regressoren_bei(v["A"], tau)
    if x0 is None:
        return None
    Xs = x_spalten(v["coin"], v["A"], G, zeiten=np.array([tau]))
    out = {}
    for h in H_STUETZ:
        W = v["W"][h]
        beta, s2 = koeff_bei(W, tau)
        if beta is None:
            return None
        ex = extra_matrix(Xs, W["wahl"])
        x = x0 if ex is None else np.concatenate([x0, ex[0]])
        if not np.all(np.isfinite(x)):
            x = x0; beta, s2 = koeff_bei(har_walk(v["A"], h), tau)                     # Zusatz fehlt jetzt: Grundmodell
            if beta is None:
                return None
        out[h] = float(h * math.exp(float(x @ beta) + s2 / 2))
    return out


# ================================================================================================ Prognose am Anker τ (4.7, 13.1, 13.4)

ORDER_ARTEN = ("limit_buy", "limit_sell", "tp_sell", "tp_buy", "stop_sell", "stop_buy")


def niveaus_aus_chartbild(P: dict) -> list:
    """Kandidaten der Ziellevels (4.7): alle Niveaus des Chartbilds, die Bestätigungsschwelle des laufenden Beins, 50/200-Tage-Linie."""
    L = []
    for n in P.get("niveaus") or []:
        if not n.get("px"):
            continue
        art = str(n.get("art") or "")
        L.append({"key": n.get("key"), "name": n.get("name"), "px": float(n["px"]), "art": art, "quelle": n.get("quelle"),
                  "momentaufnahme": art in ORDER_ARTEN or art.startswith("liq_"), "pruef": n.get("pruef"), "farbe": n.get("farbe")})
    for b in (P.get("beine") or [])[:1]:
        if b.get("mode") in (1, -1) and b.get("bestaetigt_ab"):
            X = int(round(float(b.get("X") or 0.1) * 100))
            L.append({"key": "bein", "name": f"{'Rücksetzer' if b['mode'] == 1 else 'Aufschwung'} bestätigt ab (Bein {X} %)",
                      "px": float(b["bestaetigt_ab"]), "art": "bein", "quelle": "Tagesschlüsse", "momentaufnahme": False, "pruef": "bein",
                      "farbe": "#d55181"})
    T = P.get("trend") or {}
    for k, nm in (("ma50_jetzt", "50-Tage-Linie"), ("ma200_jetzt", "200-Tage-Linie")):
        if T.get(k):
            L.append({"key": k[:5], "name": nm, "px": float(T[k]), "art": k[:5], "quelle": "Tagesschlüsse", "momentaufnahme": False,
                      "pruef": "trend", "farbe": "#3987e5" if k.startswith("ma50") else "#c98500"})
    return L


def hl_extreme_seit(db: str, coin: str, tau: int) -> tuple:
    """Hoch und Tief der Hyperliquid-1-min-Kerzen seit τ (für „seit dem Anker erreicht“) und der Schluss bei τ."""
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            r = con.execute("SELECT MAX(high), MIN(low) FROM bars WHERE coin=? AND ts >= ?", (coin, int(tau))).fetchone()
            c = con.execute("SELECT close, ts FROM bars WHERE coin=? AND ts < ? ORDER BY ts DESC LIMIT 1", (coin, int(tau))).fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return None, None, None
    p0 = float(c[0]) if c and c[0] and int(tau) - int(c[1]) <= 300 else None
    return (float(r[0]) if r and r[0] else None), (float(r[1]) if r and r[1] else None), p0


def kandidaten_index(tage: np.ndarray, tau: int) -> int:
    """Index des jüngsten Kandidatentags für den Anker τ: der letzte vollständige UTC-Tag vor τ (Tag ≤ τ // Tag − 1; Tag d endet um
    d+1 00 UTC), bei Lücken der davor; −1 ohne."""
    return int(np.searchsorted(tage, int(tau) // TAG - 1, side="right") - 1)


def sigma_b1(D: dict, bis_i: int) -> float:
    """B1: Schwankung der Tagesrenditen der letzten 365 Tage (Anker zur selben Stunde)."""
    c = D["C"][max(0, bis_i - 365): bis_i + 1]
    r = np.diff(np.log(c)); r = r[np.isfinite(r)]
    return float(np.std(r, ddof=1)) if len(r) > 100 else float("nan")


def prognose_coin(coin: str, v: dict, V: dict, G: dict, tau: int, R_alt: dict, P_chart: dict | None, SPB: dict, kop_cache: dict,
                  jetzt: int, KA: dict | None = None) -> dict:
    """Verteilung, Fächer, Spannen, Ziellevels, Richtung, bedingte Szenarien und Stressfächer für einen Coin am Anker τ."""
    out = {"coin": coin, "anker": int(tau), "erzeugt": int(jetzt), "version": VERSION_MODUL, "fehlt": []}
    Fh = F_bei(v, G, tau)
    if Fh is None:
        out["fehlt"].append("keine HAR-Breite am Anker (zu kurze oder lückenhafte 30-min-Reihe)")
        return out
    Fk = F_pfad(Fh)
    B, b_art = bibliothek_fuer(coin, V)
    if B is None:
        out["fehlt"].append(b_art); return out
    maske = bib_bis(B, tau)
    if maske.sum() < 200:
        out["fehlt"].append(f"Bibliothek zu klein ({int(maske.sum())} Fenster)"); return out
    gruppe = "paxg" if coin == "PAXG" else "krypto"
    tor = ((R_alt.get("tor") or {}).get(gruppe) or {})
    gew = ((R_alt.get("gewichte_jetzt") or {}).get(gruppe) or {})
    mhat = {}; gekappt = False
    if KA is not None and coin in KA:
        i_k = kandidaten_index(v["D"]["tag"], tau)                                             # jüngster abgeschlossener Tag (kausal)
        z = KA[coin]["Z"][max(i_k, 0)]
        namen = PAXG_KANDIDATEN if coin == "PAXG" else K_NAMEN
        zz = np.array([z[K_NAMEN.index(k)] for k in namen])
        for h in H_ZIEL:
            t_ = tor.get(str(h)) or {}
            w = gew.get(str(h))
            if t_.get("offen") and w is not None and len(w) == len(zz):
                m = float(np.dot(w, zz)); gekappt |= abs(m) > M_KAPPE
                mhat[h] = float(np.clip(m, -M_KAPPE, M_KAPPE))
    mu = drift_pfad(mhat, Fk)
    S = szenarien(B, maske, Fk, mu)
    hi_seit, lo_seit, p0_hl = hl_extreme_seit(G["db"], coin, tau)
    j_tau = int(np.searchsorted(v["A"]["tau"], tau, side="right") - 1)
    c_tau = float(v["A"]["c30"][int((tau - BAR - v["A"]["t0_kerze"]) // BAR)])
    p0 = p0_hl if p0_hl else c_tau
    out.update(p0=p0, p0_quelle="Hyperliquid (1-min-Schluss bei τ)" if p0_hl else "Binance-Perp (30-min-Schluss bei τ)",
               F={str(h): Fh[h] for h in H_STUETZ}, sigma_tag=math.sqrt(Fh[1]), mu=[float(x) for x in mu],
               bibliothek={"n": int(S["n"]), "art": b_art, "ab": int(B["start"][maske].min()), "bis": int(B["ende"][maske].max())})
    Q = faecher(S)
    out["faecher"] = [[float(x) for x in row] for row in Q]
    sp = {}
    for h in H_ZIEL:
        q = Q[h - 1]
        sp[str(h)] = {"q": [p0 * math.exp(x) for x in q], "pct": [math.expm1(x) for x in q]}
    out["spannen"] = sp
    q01, q99 = np.quantile(S["r"][:, K_MAX - 1], [0.01, 0.99])
    niv = []
    for L in niveaus_aus_chartbild(P_chart or {}):
        d_ln = math.log(L["px"] / p0)
        if not (q01 <= d_ln <= q99):
            continue
        e = dict(L, abstand=math.expm1(d_ln), seite="oben" if d_ln >= 0 else "unten", p={})
        e["erreicht"] = bool((d_ln >= 0 and hi_seit is not None and hi_seit >= L["px"]) or (d_ln < 0 and lo_seit is not None and lo_seit <= L["px"]))
        if not e["erreicht"]:
            for h in H_ZIEL:
                pe, ps = erreichen(S, d_ln, h)
                e["p"][str(h)] = [pe, ps]
        niv.append(e)
    niv.sort(key=lambda x: -x["px"])
    out["niveaus"] = niv
    # Prüfniveaus (Vorwärtsbilanz, wie 5.1): C · e^{±k·√F(τ,h)}
    pruef = {}
    for h in H_ZIEL:
        z = []
        for k in TOUCH_K:
            for sg in (1, -1):
                d_ln = sg * k * math.sqrt(Fh[h] if h in Fh else Fk[h - 1])
                pe, ps = erreichen(S, d_ln, h)
                z.append([sg * k, pe, ps])
        pruef[str(h)] = z
    out["pruefniveaus"] = pruef
    out["q99"] = {str(h): [float(x) for x in np.quantile(S["r"][:, h - 1], Q99)] for h in H_ZIEL}
    D = v["D"]
    i_d = kandidaten_index(D["tag"], tau)
    out["sigma_b1"] = sigma_b1(D, i_d)
    out["richtung"] = {"tor": tor, "mhat": {str(h): mhat[h] for h in mhat}, "gekappt": gekappt,
                       "stand": R_alt.get("stand"), "staerkster": (R_alt.get("staerkster") or {}).get(gruppe)}
    # bedingte Szenarien und Stressfächer (nur Krypto-Coins, 13.3/13.4)
    if coin != "PAXG" and SPB.get("n", 0) >= 300:
        zS = sp_koordinate({"start": B["start"][maske]}, SPB)
        okS = np.all(np.isfinite(zS), axis=1)
        if okS.sum() >= 200:
            mS = zS[okS].mean(axis=0)
            bed = []; mittel_sS = {}
            st = B["start"][maske]
            for h in SZEN_H:
                FS = sp_breite_jetzt(SPB, tau, h)
                if not np.isfinite(FS) or FS <= 0:
                    continue
                sS = (zS[:, h - 1] - mS[h - 1]) * math.sqrt(FS)           # trendbereinigt (13.3): reine Abhängigkeit, ohne Richtung
                mittel_sS[str(h)] = float(np.mean(sS[okS]))
                bb = S["r"][:, h - 1]
                key = f"{coin}:{h}"
                tag_heute = int(tau) // TAG
                if (kop_cache.get(key) or {}).get("tag") != tag_heute:          # die Kopula ändert sich langsam: einmal je Tag
                    kop_cache[key] = dict(kopula_t(bb[okS], sS[okS]), tag=tag_heute)
                for x in SZEN_X:
                    e = bedingt(bb[okS], sS[okS], st[okS], math.log(1 + x), math.sqrt(FS), h, kop=kop_cache[key])
                    e.update(x=x, art="punkt")
                    bed.append(e)
                if h == SZEN_EREIGNIS[1]:
                    e = bedingt(bb[okS], sS[okS], st[okS], math.log(1 + SZEN_EREIGNIS[0]), math.sqrt(FS), h, ereignis=True, kop=kop_cache[key])
                    e.update(x=SZEN_EREIGNIS[0], art="ereignis")
                    bed.append(e)
            for e in bed:
                for k_ in ("bib", "kopula"):
                    if k_ in e:
                        e[k_]["preis"] = [p0 * math.exp(x) for x in e[k_]["q"]]
            out["bedingt"] = bed
            out["bedingt_s4"] = R_alt.get("s4_urteil")
            out["bedingt_info"] = {"mittel_sS": mittel_sS, "n": int(okS.sum()), "trend_S": [float(x) for x in mS[[6, 13, 27]]]}
        else:
            out["fehlt"].append("bedingte Szenarien: zu wenige Fenster mit S&P-Pfad")
        zr = R_alt.get("stress_zeitraum")
        if zr:
            m2 = maske & (B["start"] >= zr[0]) & (B["start"] < zr[1])
            if m2.sum() >= 100:
                S2 = szenarien(B, m2, Fk, mu)
                Q2 = faecher(S2)
                out["stress"] = {"zeitraum": zr, "n": int(S2["n"]), "spannen": {str(h): {"q": [p0 * math.exp(x) for x in Q2[h - 1]],
                                                                                          "pct": [math.expm1(x) for x in Q2[h - 1]]} for h in H_ZIEL}}
    elif coin != "PAXG":
        out["fehlt"].append("S&P 500 (aktien.db) noch nicht geladen -- ohne bedingte Szenarien")
    return out


def stress_zeile(st: dict) -> str:
    """23.67: Stressfächer klar beschriftet -- die Form der unruhigsten Phase bei heutiger Schwankung (13.4), mit 80 und 90 %."""
    q = st["spannen"]["28"]["q"]
    return (f"   Stressfächer -- Form der unruhigsten Phase seit 2020 ({_dt(st['zeitraum'][0])}–{_dt(st['zeitraum'][1])}) bei heutiger "
            f"Schwankung: 28 T 80 % {_px(q[1])}–{_px(q[5])} · 90 % {_px(q[0])}–{_px(q[6])}")


def s4_satz(s4: dict) -> str:
    """23.67: Stand von S4 (13.9) und -- nachträglich ergänzter Hinweis, keine Regeländerung -- die Kalibrierung unter Aktienstress."""
    if not s4 or s4.get("besteht") is None:
        return "Abhängigkeit im Rückblick noch nicht geprüft."
    t = ("Abhängigkeit im Rückblick belegt" if s4.get("besteht") else "Abhängigkeit im Rückblick nicht belegt") \
        + (f" (p {_de(s4.get('p'), 3)})" if s4.get("p") is not None else "")
    ps = {h: p for h, p in (s4.get("pit_stress") or {}).items() if p is not None}
    schlecht = sorted((int(h), p) for h, p in ps.items() if p < 0.05)
    if schlecht:
        t += "; unter Aktienstress im Rückblick nicht kalibriert (" + ", ".join(f"PIT p {_de(p, 3)} bei {h} T" for h, p in schlecht) + ")"
    return t + "."


def lesart(E: dict, R_alt: dict) -> list:
    """Vier Sätze nur aus den Zahlen (6); ohne Empfehlungswörter, „Ziellevel“ nur im Sinn von 4.7."""
    S = []; coin = E["coin"]
    if E.get("ausnahme"):
        S.append(f"Ausnahmelage seit {_dtz(E['ausnahme']['seit'])}: {E['ausnahme'].get('grund', 'starke Bewegung')} -- die Spanne ist "
                 "sofort breiter gerechnet.")
    sp = (E.get("spannen") or {}).get("28")
    if sp:
        q, pc = sp["q"], sp["pct"]
        tr = (((R_alt.get("s1") or {}).get("deckung") or {}).get(coin) or {}).get("28")
        pr = (((R_alt.get("s1") or {}).get("pruef") or {}).get(coin) or {}).get("28")
        S.append(f"In 4 Wochen liegt {coin} mit 80 % zwischen {_px(q[1])} und {_px(q[5])} ({_pr(pc[1])} / {_pr(pc[5])}), mit 50 % "
                 f"zwischen {_px(q[2])} und {_px(q[4])}; Median {_px(q[3])}. "
                 + (f"Im Rückblick traf das 80-%-Band {_de(tr * 100, 0)} %{deckung_wertung(pr)}." if tr is not None else "Der Rückblick steht noch aus."))
    ri = E.get("richtung") or {}
    offen = [h for h in H_ZIEL if ((ri.get("tor") or {}).get(str(h)) or {}).get("offen")]
    if not R_alt.get("stand"):
        S.append("Richtung noch nicht geprüft (der erste Rückblick steht aus) -- der Fächer ist driftfrei.")
    elif not offen:
        st = ri.get("staerkster")
        S.append("Richtung nicht belegt -- der Fächer ist driftfrei." + (f" Stärkster Kandidat: {st['name']} ({st['status']})." if st else ""))
    else:
        h = offen[0]; m = (ri.get("mhat") or {}).get(str(h))
        seit = ((ri.get("tor") or {}).get(str(h)) or {}).get("seit")
        med = ((E.get("spannen") or {}).get(str(h)) or {}).get("pct", [None] * 7)[3]
        S.append(f"Richtung belegt für {h} Tage (seit {_dt(seit)}): Median {_pr(med)}; m̂ {_de(m, 2, True)}.")
    # die nächsten Niveaus mindestens eine Tagesschwankung entfernt (näher ist das Erreichen fast sicher und sagt nichts), ohne runde
    # Zahlen und ohne das nächste Stop-Cluster ohne Mindestgröße -- wie der Satz „Nächste Niveaus“ des Chartbilds
    sg = float(E.get("sigma_tag") or 0.0)
    nv = [n for n in E.get("niveaus") or [] if not n.get("erreicht") and n.get("art") != "rund" and not str(n.get("key", "")).endswith("_near")
          and abs(math.log1p(n.get("abstand", 0.0))) >= sg]
    oben = min([n for n in nv if n["seite"] == "oben"], key=lambda n: n["px"], default=None)
    unten = max([n for n in nv if n["seite"] == "unten"], key=lambda n: n["px"], default=None)
    teile = []
    for n, wo in ((oben, "nach oben"), (unten, "nach unten")):
        if n and n.get("p"):
            a, b, c = (n["p"].get(str(h), [None])[0] for h in H_ZIEL)
            teile.append(f"{wo} {n['name']} {_px(n['px'])}: in 1/2/4 Wochen erreicht mit {_de((a or 0) * 100, 0)}/{_de((b or 0) * 100, 0)}/"
                         f"{_de((c or 0) * 100, 0)} %")
    if teile:
        s3 = R_alt.get("s3") or {}
        hinweis = ""
        if s3 and not s3.get("bestanden_alle", True):
            hinweis = f" (im Rückblick nicht kalibriert: Steigung {_de(s3.get('steigung_28'), 2)})"
        S.append("Ziellevels: " + "; ".join(teile) + "." + hinweis)
    S.append("Wahrscheinlichkeiten aus der Verteilung, keine Empfehlung.")
    return S


def s1_pruef(S1: dict) -> dict:
    """23.67: je Coin und Horizont gemessene Deckung des 80-%-Bands, ihr Standardfehler und ob sie in 80 % ± 2 SE liegt (5.5)."""
    out = {}
    for h, e in (S1.get("h") or {}).items():
        for coin, d in (e.get("deckung") or {}).items():
            out.setdefault(str(coin), {})[str(h)] = {"d80": d.get("d80"), "se": d.get("se"), "ok": d.get("ok")}
    return out


def s4_pit_stress(S4: dict) -> dict:
    """23.67: p der Rosenblatt-PIT unter Aktienstress je Horizont (13.9) -- für den Hinweis an den bedingten Szenarien."""
    return {str(h): ((e or {}).get("stress") or {}).get("p") for h, e in (S4.get("rosenblatt") or {}).items()}


def deckung_wertung(pr: dict | None) -> str:
    """23.67 (5.5 „Bei Deckung außerhalb der Spanne steht die gemessene Deckung je Coin am Fächer“): Zusatz zur Deckung."""
    if not pr or pr.get("ok") is None or pr.get("d80") is None:
        return ""
    if pr["ok"]:
        return ""
    return " -- zu eng (Soll 80 %)" if pr["d80"] < 0.80 else " -- zu weit (Soll 80 %)"


def _rueckblick_stand(con) -> dict:
    """Was der jüngste Rückblick festgelegt hat (Tor, Gewichte, Breitenwahl, Urteile) -- aus au_meta. 23.67: fehlen die neuen
    Prüfgrößen (Rückblick vor 23.67), werden sie aus dem gespeicherten vollen Rückblick ergänzt."""
    out = {}
    for k in ("tor", "gewichte_jetzt", "breite_wahl", "s1", "s3", "s4_urteil", "stress_zeitraum", "staerkster"):
        out[k] = _json_meta(con, k, None)
    out["stand"] = int(meta(con, "rueckblick_stand", "0") or 0) or None
    s1, s4 = out.get("s1"), out.get("s4_urteil")
    if (isinstance(s1, dict) and "pruef" not in s1) or (isinstance(s4, dict) and "pit_stress" not in s4):
        try:
            z = con.execute("SELECT json FROM au_rueckblick ORDER BY stand DESC LIMIT 1").fetchone()
            voll = json.loads(z[0]) if z else {}
        except (sqlite3.Error, ValueError):
            voll = {}
        if isinstance(s1, dict) and "pruef" not in s1 and voll.get("s1"):
            s1["pruef"] = s1_pruef(voll["s1"])
        if isinstance(s4, dict) and "pit_stress" not in s4 and voll.get("s4"):
            s4["pit_stress"] = s4_pit_stress(voll["s4"])
    return out


def chartbild_daten(db: str, coin: str, live_fn=None) -> dict:
    """Niveaus des Chartbilds (gleiche Regeln, 4.7) mit dem Live-Teil wie im Dashboard; ohne Dashboard-Modul nur die Tageswerte."""
    import hl_chartbild as CB
    live = {}
    if live_fn is None:
        try:
            import hl_viz
            live_fn = hl_viz.chartbild_live
        except Exception:
            live_fn = None
    if live_fn is not None:
        try:
            live = live_fn(db, coin) or {}
        except Exception:
            live = {}
    try:
        return CB.payload(db, coin, live, cache=False)
    except Exception as e:
        return {"fehlt": [f"Chartbild: {type(e).__name__}: {e}"[:120]]}


def prognose(db: str, coins=COINS, jetzt: int | None = None, art: str = "takt", tau_fest: int | None = None, live_fn=None,
             log=None, schreiben: bool = True, G: dict | None = None) -> dict:
    """
    Neuberechnung am Anker τ (13.1): Ende der letzten abgeschlossenen 30-min-Kerze (bzw. tau_fest für die 6-h-Anker der
    Vorwärtsbilanz). Speichert je Coin die Antwort (au_prognose) und an den Ankern 00/06/12/18 UTC die Vorwärtsbilanz.
    """
    log = log or (lambda *a: None)
    t0 = time.time()
    jetzt = int(jetzt or time.time())
    G = G or lade(db, coins, log=log)
    con = verbinden(ausblick_pfad(db)) if schreiben else None
    R_alt = _rueckblick_stand(con) if con is not None else {}
    V = {}
    for c in coins:
        if c in G["coins"]:
            v = vorbereiten(c, G, R_alt.get("breite_wahl"))
            if v is not None:
                V[c] = v
    tor_offen = any(((R_alt.get("tor") or {}).get(g) or {}).get(str(h), {}).get("offen") for g in ("krypto", "paxg") for h in H_ZIEL)
    KA = kandidaten_alle(V, G) if tor_offen else None
    SPB = sp_breite({"ts": G["R"]["fred:SP500"]["ts"], "w": G["R"]["fred:SP500"]["w"]}, G["R"].get("fred:VIXCLS"),
                    G["R"].get("fred:VXVCLS")) if "fred:SP500" in G["R"] else {}
    kop = _json_meta(con, "kopula_cache", {}) if con is not None else {}
    ausn = _json_meta(con, "ausnahme", {}) if con is not None else {}
    erg = {}
    for c, v in V.items():
        letzte = int(v["A"]["letzte_kerze"]) + BAR
        tau = int(tau_fest) if tau_fest is not None else halbstunden_anker(min(jetzt, letzte))
        P = chartbild_daten(db, c, live_fn)
        E = prognose_coin(c, v, V, G, tau, R_alt, P, SPB, kop, jetzt, KA)
        a = (ausn or {}).get(c)
        if a and jetzt - int(a.get("seit", 0)) < AUSNAHME_S:
            E["ausnahme"] = a
        if letzte < jetzt - 3 * 3600:
            E["fehlt"].append(f"30-min-Kerzen zuletzt {_dtz(letzte)} -- Stand vom {_dtz(tau)}")
        E["lesart"] = lesart(E, R_alt) if E.get("spannen") else ["Kein Ausblick: " + "; ".join(E["fehlt"]) if E["fehlt"] else "Kein Ausblick."]
        E["art"] = art
        E["rueckblick"] = {"stand": R_alt.get("stand"), "s1": R_alt.get("s1"), "s3": R_alt.get("s3"), "breite_wahl": R_alt.get("breite_wahl")}
        erg[c] = _ohne_nan(E)
        if con is not None and E.get("spannen"):
            vorwaerts_speichern(con, E, tau)
            _tx(con, lambda: con.execute("INSERT OR REPLACE INTO au_prognose VALUES (?,?,?,?,?)",
                                         (c, int(tau), jetzt, art, json.dumps(erg[c], allow_nan=False))))
    if con is not None:
        meta_setzen(con, {"schock_basis": json.dumps(_ohne_nan(schock_basis(V, G, SPB, erg)))})
        meta_setzen(con, {"kopula_cache": json.dumps(_ohne_nan(kop)), "letzte_prognose": str(jetzt),
                          "letzte_dauer": f"{time.time() - t0:.1f}", "letzte_art": art})
        _tx(con, lambda: con.execute("DELETE FROM au_prognose WHERE anker % ? != 0 AND anker < ?", (ANKER_S, jetzt - 2 * TAG)))
        con.close()
    log(f"Prognose {', '.join(erg)} in {time.time() - t0:.1f} s")
    return {"coins": erg, "fehlt": G["fehlt"], "dauer": time.time() - t0}


def vorwaerts_speichern(con, E: dict, tau: int) -> None:
    """An den 6-h-Ankern: Quantile, Breite, m̂, Tor, B1, Prüf- und gezeigte Niveaus je Horizont (5.6)."""
    if int(tau) % ANKER_S != 0:
        return
    zeilen = []
    for h in H_ZIEL:
        niv = [[n.get("art"), n["px"], (n.get("p") or {}).get(str(h), [None, None])[0], (n.get("p") or {}).get(str(h), [None, None])[1]]
               for n in E.get("niveaus") or [] if not n.get("erreicht")]
        niv += [["pruef", k, pe, ps] for k, pe, ps in (E.get("pruefniveaus") or {}).get(str(h), [])]
        tor = ((E.get("richtung") or {}).get("tor") or {}).get(str(h)) or {}
        zeilen.append((E["coin"], int(tau), h, E["p0"], (E.get("F") or {}).get(str(h)), ((E.get("richtung") or {}).get("mhat") or {}).get(str(h)),
                       int(bool(tor.get("offen"))), E.get("sigma_b1"), json.dumps(_ohne_nan(E["q99"][str(h)])), json.dumps(_ohne_nan(niv)), 0, None))
    _tx(con, lambda: con.executemany("INSERT OR IGNORE INTO au_vorwaerts VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", zeilen))


def vorwaerts_auswerten(db: str, G: dict | None = None, jetzt: int | None = None) -> dict:
    """Vorwärtsbilanz (5.6): realisierte Ziele auswerten -- Deckung 50/80/90, CRPS (aus 99 Quantilen) gegen B1, Erreichen der Niveaus."""
    jetzt = int(jetzt or time.time())
    con = verbinden(ausblick_pfad(db))
    try:
        offen = con.execute("SELECT coin, anker, h, p0, q99, niveaus, sigma_b1 FROM au_vorwaerts WHERE ausgewertet=0 AND anker + h * ? + ? <= ?",
                            (TAG, 3600, jetzt)).fetchall()
        if offen:
            import hl_aktien as AK
            K = {}
            neu = []
            for coin, anker, h, p0, q99, niv, sb1 in offen:
                if coin not in K:
                    K[coin] = AK.kerzen_30m(db, coin)
                k = K[coin]
                if k is None:
                    continue
                ende = anker + h * TAG
                i1 = np.searchsorted(k["ts"], ende - BAR); i0 = np.searchsorted(k["ts"], anker)
                if i1 >= len(k["ts"]) or k["ts"][i1] != ende - BAR or i0 >= i1:
                    continue
                c0 = float(k["c"][i0 - 1]) if i0 > 0 and k["ts"][i0 - 1] == anker - BAR else None
                if not c0:
                    continue
                y = math.log(float(k["c"][i1]) / c0)
                hmax = math.log(float(np.max(k["h"][i0:i1 + 1])) / c0); lmin = math.log(float(np.min(k["l"][i0:i1 + 1])) / c0)
                q = np.array(json.loads(q99), dtype=float)
                tau_q = np.array(Q99)
                pin = np.where(y >= q, tau_q * (y - q), (1 - tau_q) * (q - y))
                crps_q = float(2 * pin.mean())
                crps_b1 = float(crps_normal(0.0, sb1 * math.sqrt(h), np.array([y]))[0]) if sb1 else None
                dek = {str(b): bool(np.quantile(q, 0.5 - b / 200) <= y <= np.quantile(q, 0.5 + b / 200)) for b in (50, 80, 90)}
                nv = []
                for art, px, pe, ps in json.loads(niv or "[]"):
                    if art == "pruef":
                        continue
                    d_ln = math.log(px / p0) if p0 else 0.0
                    getr = bool((d_ln >= 0 and hmax >= d_ln) or (d_ln < 0 and lmin <= d_ln))
                    nv.append([art, pe, getr])
                neu.append((json.dumps({"y": y, "crps": crps_q, "crps_b1": crps_b1, "deckung": dek, "niveaus": nv}), coin, anker, h))
            if neu:
                _tx(con, lambda: con.executemany("UPDATE au_vorwaerts SET ausgewertet=1, ergebnis=? WHERE coin=? AND anker=? AND h=?", neu))
        rows = con.execute("SELECT coin, h, ergebnis FROM au_vorwaerts WHERE ausgewertet=1").fetchall()
    finally:
        con.close()
    bil = {}
    for coin, h, e in rows:
        d = json.loads(e)
        b = bil.setdefault(str(h), {"n": 0, "deckung": {"50": 0, "80": 0, "90": 0}, "crps": 0.0, "crps_b1": 0.0, "n_b1": 0, "niveau": []})
        b["n"] += 1
        for k_ in ("50", "80", "90"):
            b["deckung"][k_] += int(d["deckung"][k_])
        b["crps"] += d["crps"]
        if d.get("crps_b1") is not None:
            b["crps_b1"] += d["crps_b1"]; b["n_b1"] += 1
        b["niveau"] += [(pe, g) for _a, pe, g in d.get("niveaus") or [] if pe is not None]
    for h, b in bil.items():
        n = b["n"]
        b["deckung"] = {k_: v / n for k_, v in b["deckung"].items()}
        b["crps"] = b["crps"] / n; b["crps_b1"] = b["crps_b1"] / b["n_b1"] if b["n_b1"] else None
        pe = np.array([x[0] for x in b["niveau"]], dtype=float); g = np.array([x[1] for x in b["niveau"]], dtype=float)
        b["niveau"] = {"n": int(len(pe)), "brier": float(np.mean((pe - g) ** 2)) if len(pe) else None,
                       "mittel_p": float(pe.mean()) if len(pe) else None, "quote": float(g.mean()) if len(pe) else None}
        b["genug"] = n >= 30
    return bil


# ================================================================================================ Rückblick (5): Breite, Richtung, Tor

def _tageshaelften(tage: np.ndarray) -> np.ndarray:
    """True für die zweite Hälfte (Teilung am mittleren Datum der Spanne)."""
    if not len(tage):
        return np.zeros(0, dtype=bool)
    mitte = (int(tage.min()) + int(tage.max())) / 2.0
    return tage >= mitte


def _mittel_je_tag(tage: np.ndarray, werte: np.ndarray) -> tuple:
    """Mittel über die Coins je Tag -> (Tage, Mittel)."""
    ok = np.isfinite(werte)
    t, w = tage[ok], werte[ok]
    if not len(t):
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    u, inv = np.unique(t, return_inverse=True)
    s = np.bincount(inv, weights=w); c = np.bincount(inv)
    return u, s / c


def _test_tagesreihe(tage: np.ndarray, d: np.ndarray, block: float, seed: int) -> dict:
    """Mittel > 0 (Bootstrap, einseitig) und beide Hälften > 0."""
    u, m = _mittel_je_tag(tage, d)
    erg = boot_p(m, block, BOOT_REPS, seed)
    zw = _tageshaelften(u)
    erg["h1"] = float(np.mean(m[~zw])) if (~zw).any() else float("nan")
    erg["h2"] = float(np.mean(m[zw])) if zw.any() else float("nan")
    erg["haelften"] = bool(erg["h1"] > 0 and erg["h2"] > 0)
    erg["von"] = int(u.min()) if len(u) else None; erg["bis"] = int(u.max()) if len(u) else None
    return erg


def breite_waehlen(G: dict, coins, log) -> dict:
    """
    HAR-X (13.2): je Horizont X1–X4 einzeln gegen das Grundmodell (QLIKE an den 00-UTC-Ankern ab 2022, Differenz je Tag über die
    Coins gemittelt, Blockbootstrap, Holm über 4, beide Hälften); was einzeln besteht, gemeinsam -- schlägt die Kombination das
    Grundmodell ebenso, gilt sie, sonst der beste einzelne. Dazu je VIX-Drittel beschreibend.
    """
    out = {"h": {}, "wahl": {}}
    basis = {}; X_alle = {}
    for c in coins:
        if c not in G["coins"]:
            continue
        A = G["coins"][c]["A"]
        X_alle[c] = x_spalten(c, A, G)
        basis[c] = {h: har_walk(A, h) for h in H_STUETZ}
    vix = G["R"].get("fred:VIXCLS")
    for h in H_STUETZ:
        tests = {}
        for xk in ("X1", "X2", "X3", "X4"):
            tg, dd, vv = [], [], []
            for c in basis:
                if xk not in X_alle[c]:
                    continue
                A = G["coins"][c]["A"]
                W = har_walk(A, h, extra=extra_matrix(X_alle[c], [xk]))
                F0, F1, S = basis[c][h]["F"], W["F"], basis[c][h]["S"]
                m = (A["stunde"] == 0) & (A["tau"] >= OOS_AB) & np.isfinite(F0) & np.isfinite(F1) & np.isfinite(S) & (S > 0)
                tg.append(A["tau"][m] // TAG); dd.append(qlike(F0[m], S[m]) - qlike(F1[m], S[m]))
                vv.append(us_asof(vix["ts"], vix["w"], A["tau"][m]) if vix is not None else np.full(int(m.sum()), np.nan))
            if not tg or sum(len(x) for x in tg) < 200:
                tests[xk] = {"n": int(sum(len(x) for x in tg)), "grund": "zu wenige Tage mit dem Zusatz"}
                continue
            t_all = np.concatenate(tg); d_all = np.concatenate(dd); v_all = np.concatenate(vv)
            e = _test_tagesreihe(t_all, d_all, 2.0 * h, seed=zlib.crc32(f"breite{h}{xk}".encode()))
            if np.isfinite(v_all).sum() > 100:
                q1, q2 = np.nanquantile(v_all, [1 / 3, 2 / 3])
                e["vix_drittel"] = [float(np.nanmean(d_all[v_all <= q1])), float(np.nanmean(d_all[(v_all > q1) & (v_all <= q2)])),
                                    float(np.nanmean(d_all[v_all > q2]))]
            tests[xk] = e
        ks = [k for k in tests if tests[k].get("p") is not None and np.isfinite(tests[k].get("p", float("nan")))]
        ph = holm([tests[k]["p"] for k in ks]) if ks else []
        for k, p_ in zip(ks, ph):
            tests[k]["p_holm"] = p_
            tests[k]["besteht"] = bool(p_ < 0.05 and tests[k]["haelften"] and tests[k]["mittel"] > 0)
        bestanden = [k for k in ks if tests[k].get("besteht")]
        wahl = []
        if len(bestanden) == 1:
            wahl = bestanden
        elif len(bestanden) > 1:
            tg, dd = [], []
            for c in basis:
                ex = extra_matrix(X_alle[c], bestanden)
                if ex is None or ex.shape[1] < len(bestanden):
                    continue
                A = G["coins"][c]["A"]
                W = har_walk(A, h, extra=ex)
                F0, F1, S = basis[c][h]["F"], W["F"], basis[c][h]["S"]
                m = (A["stunde"] == 0) & (A["tau"] >= OOS_AB) & np.isfinite(F0) & np.isfinite(F1) & np.isfinite(S) & (S > 0)
                tg.append(A["tau"][m] // TAG); dd.append(qlike(F0[m], S[m]) - qlike(F1[m], S[m]))
            kom = _test_tagesreihe(np.concatenate(tg), np.concatenate(dd), 2.0 * h, seed=zlib.crc32(f"kombi{h}".encode())) if tg else {}
            kom["besteht"] = bool(kom.get("p", 1) < 0.05 and kom.get("haelften"))
            tests["kombination"] = dict(kom, zusaetze=bestanden)
            wahl = bestanden if kom["besteht"] else [max(bestanden, key=lambda k: tests[k]["mittel"])]
        out["h"][str(h)] = tests
        out["wahl"][str(h)] = wahl
        log(f"  Breite h={h}: " + ", ".join(f"{k} p Holm {_de(tests[k].get('p_holm'), 3)}" for k in ks) + f" -> {'+'.join(wahl) or 'Grundmodell'}")
    return out


def ridge_gruppe(V: dict, KA: dict, gruppe: str, h: int) -> dict | None:
    """Zeilen (Coin, Tag) einer Gruppe für Horizont h: Kandidaten (standardisiert), Ziel y = R_h/√F(d,h)."""
    coins = [c for c in (KRYPTO if gruppe == "krypto" else ("PAXG",)) if c in V and c in KA]
    namen = K_NAMEN if gruppe == "krypto" else PAXG_KANDIDATEN
    idx = [K_NAMEN.index(k) for k in namen]
    tg, X, y, ci = [], [], [], []
    for i, c in enumerate(coins):
        yy = V[c]["y"][h]; Z = KA[c]["Z"][:, idx]; tt = V[c]["D"]["tag"]
        m = np.isfinite(yy)
        tg.append(tt[m]); X.append(Z[m]); y.append(yy[m]); ci.append(np.full(int(m.sum()), i))
    if not tg or sum(len(x) for x in tg) < 500:
        return None
    return {"coins": coins, "namen": namen, "idx": idx, "tag": np.concatenate(tg), "X": np.vstack(X), "y": np.concatenate(y),
            "ci": np.concatenate(ci)}


class _SortEns:
    """Wachsende Bibliothek je Horizont: sortierte standardisierte Werte, damit CRPS und Quantile je Ursprung ohne Sortieren gehen."""

    def __init__(self):
        self.x = np.zeros(0); self.summe = 0.0

    def dazu(self, werte: np.ndarray):
        if len(werte):
            self.x = np.insert(self.x, np.searchsorted(self.x, werte), werte) if len(werte) < 64 else np.sort(np.concatenate([self.x, werte]))
            self.summe += float(np.sum(werte))

    def mittel(self) -> float:
        return self.summe / len(self.x) if len(self.x) else float("nan")

    def crps(self, y_std) -> np.ndarray:
        """CRPS der (schon sortierten) Werte -- wie crps_ens, ohne erneutes Sortieren."""
        xs = self.x; N = len(xs)
        i = np.arange(1, N + 1)
        e_xx = 2.0 / (N * N) * float(np.dot(2 * i - N - 1, xs))
        cs = np.concatenate([[0.0], np.cumsum(xs)])
        y = np.atleast_1d(np.asarray(y_std, dtype=float))
        k = np.searchsorted(xs, y, side="right"); s_k = cs[k]
        return (k * y - s_k + (cs[-1] - s_k) - (N - k) * y) / N - 0.5 * e_xx

    def quantil(self, q) -> np.ndarray:
        return np.quantile(self.x, q)

    def pit(self, y_std: float) -> float:
        return float(np.searchsorted(self.x, y_std, side="right") / len(self.x))


def _sigma365_anker(A: dict) -> np.ndarray:
    """B1: Standardabweichung der 24-h-Renditen derselben Ankerstunde über die letzten 365 Tage (kausal) je Anker."""
    n = A["n"]; lc = np.log(A["C"])
    r = np.full(n, np.nan); r[JE_TAG:] = lc[JE_TAG:] - lc[:-JE_TAG]
    out = np.full(n, np.nan)
    for res in range(JE_TAG):
        idx = np.arange(res, n, JE_TAG)
        x = r[idx]; ok = np.isfinite(x)
        c1 = np.concatenate([[0.0], np.cumsum(np.where(ok, x, 0.0))]); c2 = np.concatenate([[0.0], np.cumsum(np.where(ok, x * x, 0.0))])
        cn = np.concatenate([[0], np.cumsum(ok)])
        i = np.arange(len(idx)); a = np.maximum(0, i + 1 - 365)
        nn = cn[i + 1] - cn[a]; s1 = c1[i + 1] - c1[a]; s2 = c2[i + 1] - c2[a]
        with np.errstate(invalid="ignore", divide="ignore"):
            v = (s2 - s1 * s1 / nn) / np.maximum(nn - 1, 1)
        out[idx] = np.where(nn >= 200, np.sqrt(np.maximum(v, 0)), np.nan)
    return out


def ursprung_auswertung(V: dict, mhat_zeilen: dict, log) -> dict:
    """
    Alle Anker ab 01.01.2022 je Coin und Horizont: CRPS B0 (Bibliothek + HAR), B1 (Normal, Schwankung 365 T) und an den 00-UTC-Ankern
    M (mit Drift m̂); PIT; Deckung 50/80/90. Bibliothek je Ursprung nur aus Fenstern, die davor realisiert waren (sortiert, wachsend).
    """
    rec = {k: [] for k in ("coin", "tau", "stunde", "h", "b0", "b1", "m", "pit", "d50", "d80", "d90", "y", "a", "mhat")}
    for coin, v in V.items():
        B, _art = bibliothek_fuer(coin, V)
        if B is None:
            continue
        o = np.argsort(B["ende"], kind="stable")
        ende = B["ende"][o]; Zs = B["Z"][o]
        A = v["A"]; tau = A["tau"]; lc = np.log(A["C"]); Fk = v["Fk"]
        s365 = _sigma365_anker(A)
        mh = mhat_zeilen.get(coin) or {}
        ens = {h: _SortEns() for h in H_ZIEL}
        zeiger = 0
        J = np.nonzero(tau >= OOS_AB)[0]
        for j in J:
            grenze = tau[j] - TAG
            neu_bis = int(np.searchsorted(ende, grenze, side="right"))
            if neu_bis > zeiger:
                for h in H_ZIEL:
                    ens[h].dazu(Zs[zeiger:neu_bis, h - 1].astype(float))
                zeiger = neu_bis
            if zeiger < 200:
                continue
            stunde = int((tau[j] % TAG) // 3600)
            for h in H_ZIEL:
                jj = j + JE_TAG * h
                if jj >= A["n"] or not np.isfinite(lc[jj]) or not np.isfinite(lc[j]) or not np.isfinite(Fk[j, h - 1]):
                    continue
                y = lc[jj] - lc[j]; a = math.sqrt(Fk[j, h - 1]); E = ens[h]; mb = E.mittel()
                ys = y / a + mb
                b0 = a * float(E.crps(ys)[0])
                b1 = float(crps_normal(0.0, s365[j] * math.sqrt(h), np.array([y]))[0]) if np.isfinite(s365[j]) else float("nan")
                q = E.quantil([0.25, 0.75, 0.10, 0.90, 0.05, 0.95])
                m_ = float("nan"); mm = float("nan")
                if stunde == 0:
                    mm = mh.get(h, {}).get(int(tau[j] // TAG - 1), float("nan"))
                    if np.isfinite(mm):
                        m_ = a * float(E.crps(ys - mm)[0])
                for k_, val in (("coin", coin), ("tau", int(tau[j])), ("stunde", stunde), ("h", h), ("b0", b0), ("b1", b1), ("m", m_),
                                ("pit", E.pit(ys)), ("d50", float(q[0] <= ys <= q[1])), ("d80", float(q[2] <= ys <= q[3])),
                                ("d90", float(q[4] <= ys <= q[5])), ("y", y / a), ("a", a), ("mhat", mm)):
                    rec[k_].append(val)
        log(f"  Rückblick {coin}: {len(J)} Anker, Bibliothek bis {zeiger} Fenster")
    out = {k: np.array(v_) for k, v_ in rec.items()}
    return out


def urteil_s1(U: dict) -> dict:
    """S1 Breite (5.5): CRPS-Gewinn B0 gegen B1 (p < 0,05, gepoolt je Horizont) und Deckung des 80-%-Bands bei BTC und ETH in
    80 % ± 2 SE; dazu je Ankerstunde 06/12/18 dieselben Maße (13.1)."""
    out = {"h": {}, "deckung": {}, "stunde": {}}
    for h in H_ZIEL:
        m0 = (U["h"] == h) & (U["stunde"] == 0) & np.isfinite(U["b0"]) & np.isfinite(U["b1"])
        e = _test_tagesreihe(U["tau"][m0] // TAG, U["b1"][m0] - U["b0"][m0], 2.0 * h, seed=101 + h)
        e["crps_b0"] = float(np.mean(U["b0"][m0])) if m0.any() else None
        e["crps_b1"] = float(np.mean(U["b1"][m0])) if m0.any() else None
        e["gewinn_rel"] = (1 - e["crps_b0"] / e["crps_b1"]) if e["crps_b1"] else None
        dk = {}
        for coin in np.unique(U["coin"][m0]):
            mc = m0 & (U["coin"] == coin)
            hits = U["d80"][mc]
            if len(hits) < 60:
                continue
            idx = stat_idx(len(hits), 2.0 * h, 500, seed=7 + h)
            se = float(hits[idx].mean(axis=1).std(ddof=1))
            dk[str(coin)] = {"d80": float(hits.mean()), "se": se, "d50": float(U["d50"][mc].mean()), "d90": float(U["d90"][mc].mean()),
                             "n": int(len(hits)), "ok": bool(abs(hits.mean() - 0.80) <= 2 * se),
                             "pit": np.histogram(U["pit"][mc], bins=10, range=(0, 1))[0].tolist()}
            out["deckung"].setdefault(str(coin), {})[str(h)] = float(hits.mean())
        e["deckung"] = dk
        e["besteht"] = bool(e.get("p", 1) < 0.05 and all(dk.get(c, {}).get("ok", False) for c in ("BTC", "ETH") if c in dk)
                            and all(c in dk for c in ("BTC", "ETH")))
        out["h"][str(h)] = e
        for st in (6, 12, 18):
            ms = (U["h"] == h) & (U["stunde"] == st) & np.isfinite(U["b0"]) & np.isfinite(U["b1"])
            if ms.sum() < 100:
                continue
            es = _test_tagesreihe(U["tau"][ms] // TAG, U["b1"][ms] - U["b0"][ms], 2.0 * h, seed=301 + h + st)
            dd = {}
            for coin in ("BTC", "ETH"):
                mc = ms & (U["coin"] == coin)
                if mc.sum() >= 60:
                    hits = U["d80"][mc]; idx = stat_idx(len(hits), 2.0 * h, 300, seed=9 + st)
                    se = float(hits[idx].mean(axis=1).std(ddof=1))
                    dd[coin] = {"d80": float(hits.mean()), "se": se, "ok": bool(abs(hits.mean() - 0.8) <= 2 * se)}
            es["deckung"] = dd
            es["besteht"] = bool(es.get("p", 1) < 0.05 and all(x["ok"] for x in dd.values()) and len(dd) == 2)
            out["stunde"].setdefault(str(st), {})[str(h)] = es
    out["bestanden_alle"] = all(out["h"].get(str(h), {}).get("besteht") for h in H_ZIEL)
    return out


def tor_rechnen(U: dict, gruppe_coins: list, h: int, seed: int) -> dict:
    """Tor (4.5): Clark-West f = 2·y·m̂ und CRPS-Gewinn M gegen B0 je Tag über die Coins gemittelt; Bootstrap; beide Hälften; R²_OS."""
    m = (U["h"] == h) & (U["stunde"] == 0) & np.isin(U["coin"], gruppe_coins) & np.isfinite(U["mhat"]) & np.isfinite(U["m"])
    out = {"h": h, "n": int(m.sum())}
    if m.sum() < 200:
        out["grund"] = "zu wenige Tage mit Richtungsprognose"; out["offen"] = False
        return out
    tage = U["tau"][m] // TAG
    cw = _test_tagesreihe(tage, 2 * U["y"][m] * U["mhat"][m], 2.0 * h, seed)
    cr = _test_tagesreihe(tage, U["b0"][m] - U["m"][m], 2.0 * h, seed + 1)
    y = U["y"][m]; mh = U["mhat"][m]
    u, inv = np.unique(tage, return_inverse=True)
    num = np.bincount(inv, weights=(y - mh) ** 2); den = np.bincount(inv, weights=y * y)
    r2 = 1 - num.sum() / den.sum()
    idx = stat_idx(len(u), 2.0 * h, 1000, seed + 2)
    r2b = 1 - num[idx].sum(axis=1) / den[idx].sum(axis=1)
    out.update(cw=cw, crps=cr, r2_os=float(r2), r2_lo=float(np.quantile(r2b, 0.05)), r2_hi=float(np.quantile(r2b, 0.95)))
    out["offen"] = bool(cw.get("p", 1) < 0.05 and cr.get("p", 1) < 0.05 and cw.get("haelften") and cr.get("haelften"))
    return out


def _achse(RGd: dict, j: int) -> tuple:
    """Spalte j der Gruppe je Coin auf einer gemeinsamen Tagesachse (fehlend = 0, neutral) -> (Achse (Coins × L), d0)."""
    d0 = int(RGd["tag"].min()); L = int(RGd["tag"].max()) - d0 + 1
    M = np.zeros((len(RGd["coins"]), L))
    M[RGd["ci"], RGd["tag"] - d0] = RGd["X"][:, j]
    return M, d0


def surrogate(RGd: dict, j: int, verfahren: str, k: int, seed: int, ab: int = 0) -> list:
    """
    Null-Surrogate der Kandidatenspalte j (Zeilenreihenfolge der Gruppe), Nummer ab … ab+k−1: zirkuläre Verschiebung um 365 … L−365
    Tage (ein Versatz für alle Coins; erhält Autokorrelation und Gleichlauf; Reihenfolge der Versätze fest gemischt) oder
    Phasen-Randomisierung mit denselben Phasen für alle Coins (erhält Spektrum und Kreuzspektrum, Prichard & Theiler 1994).
    """
    M, d0 = _achse(RGd, j)
    L = M.shape[1]
    out = []
    if verfahren == "verschiebung":
        if L < 2 * 365 + 10:
            return out
        alle = np.random.default_rng(seed).permutation(np.arange(365, L - 365 + 1))
        for s_ in alle[ab:ab + k]:
            out.append(np.roll(M, int(s_), axis=1)[RGd["ci"], RGd["tag"] - d0])
    else:
        Fm = np.fft.rfft(M, axis=1)
        for i in range(ab, ab + k):
            rng = np.random.default_rng([seed, i])
            th = rng.uniform(0, 2 * np.pi, Fm.shape[1]); th[0] = 0.0
            if L % 2 == 0:
                th[-1] = 0.0
            Ms = np.fft.irfft(Fm * np.exp(1j * th)[None, :], n=L, axis=1)
            out.append(Ms[RGd["ci"], RGd["tag"] - d0])
    return out


def null_p(R: "Ridge", RGd: dict, j: int, d_beob: float, mse_ohne: float, oos: np.ndarray, ab_tag: int, lams: list, verfahren: str,
           seed: int, k0: int = NULL_K) -> dict:
    """
    p des Beitrags gegen die Null: k0 Surrogate (4.6); ohne eine einzige Überschreitung sequentiell weiter (Besag & Clifford 1991) bis
    NULL_STOPP Überschreitungen oder NULL_K_MAX Surrogate. Grund (Nachtrag 11.10.): mit 100 Surrogaten ist das kleinste p 1/101; Holm über
    36 Kandidaten verlangt für den besten p < 0,0014 -- „trägt“ wäre sonst unerreichbar.
    """
    y = RGd["y"]; nul = []

    def dazu(ab, k):
        for xs in surrogate(RGd, j, verfahren, k, seed, ab):
            nul.append(mse_ohne - mse_oos(y, R.walk(ab_tag, lams=lams, ersatz=R.ersatz(j, xs))["mhat"], oos))
    dazu(0, k0)
    if not nul:
        return {"n": 0}
    ueber = int(np.sum(np.array(nul) >= d_beob - 1e-15))
    sequentiell = ueber == 0
    while sequentiell and ueber < NULL_STOPP and len(nul) < NULL_K_MAX:
        n_vor = len(nul)
        dazu(n_vor, min(NULL_K_MAX - n_vor, max(100, n_vor)))
        if len(nul) == n_vor:                                   # keine weiteren Verschiebungen möglich
            break
        ueber = int(np.sum(np.array(nul) >= d_beob - 1e-15))
    nul = np.array(nul)
    p = (ueber / len(nul)) if (sequentiell and ueber >= NULL_STOPP) else (1 + ueber) / (1 + len(nul))
    return {"n": int(len(nul)), "p": float(p), "q95": float(np.quantile(nul, 0.95)), "sequentiell": bool(sequentiell)}


def gewichte_pruefen(RGd: dict, h: int, n_null: int = NULL_K, verfahren: str | None = None, seed: int = 0, log=None) -> dict:
    """
    Ridge im Walk-forward ab 01.01.2022 und je Kandidat (4.6): Gewicht (letzte Schätzung), Spur, Vorzeichenstabilität, Beitrag ΔMSE
    außerhalb der Stichprobe (ohne ihn neu geschätzt), Null aus n_null Surrogaten (λ je Neuschätzung wie im Hauptlauf), Holm über die
    Kandidaten, beide Hälften, Status.
    """
    log = log or (lambda *a: None)
    verfahren = verfahren or NULL_WAHL["verfahren"]
    alpha = float(NULL_WAHL.get("alpha", 0.05))
    R = Ridge(RGd["tag"], RGd["X"], RGd["y"], h)
    ab = OOS_AB // TAG
    W = R.walk(ab)
    lams = [r[1] for r in W["refits"]]
    y = RGd["y"]; tag = RGd["tag"]
    oos = tag >= ab
    zw = np.zeros(len(tag), dtype=bool)
    if oos.any():
        mitte = (int(tag[oos].min()) + int(tag[oos].max())) / 2.0
        zw = tag >= mitte
    mse_m = mse_oos(y, W["mhat"], oos)
    mse_m1 = mse_oos(y, W["mhat"], oos & ~zw); mse_m2 = mse_oos(y, W["mhat"], oos & zw)
    kand = []
    for j, name in enumerate(RGd["namen"]):
        x = RGd["X"][:, j]
        aktiv_oos = float(np.mean(x[oos] != 0)) if oos.any() else 0.0
        akt_tage = tag[(x != 0)]
        e = {"key": name, "familie": dict((k, f) for k, f, _ in KANDIDATEN)[name], "name": dict((k, n) for k, _, n in KANDIDATEN)[name],
             "seit": int(akt_tage.min()) if len(akt_tage) else None, "aktiv_oos": aktiv_oos}
        ws = np.array([r[2][j] for r in W["refits"]]) if W["refits"] else np.zeros(0)
        if len(ws):
            e.update(gewicht=float(ws[-1]), spur=[float(ws.min()), float(ws.mean()), float(ws.max())],
                     vorzeichen=float(np.mean(np.sign(ws) == np.sign(ws[-1]))) if ws[-1] != 0 else None)
        if aktiv_oos < 0.25:
            e["status"] = "zu kurz"; kand.append(e); continue
        keep = np.array([i for i in range(R.p) if i != j])
        Wo = R.walk(ab, lams=lams, keep=keep)
        mse_o = mse_oos(y, Wo["mhat"], oos)
        e["dmse"] = mse_o - mse_m
        e["dmse_h1"] = mse_oos(y, Wo["mhat"], oos & ~zw) - mse_m1; e["dmse_h2"] = mse_oos(y, Wo["mhat"], oos & zw) - mse_m2
        nz = null_p(R, RGd, j, e["dmse"], mse_o, oos, ab, lams, verfahren, seed + 17 * j, n_null)
        e["null_n"] = nz.get("n"); e["p"] = nz.get("p"); e["null_q95"] = nz.get("q95")
        kand.append(e)
    mit_p = [e for e in kand if e.get("p") is not None]
    for e, ph in zip(mit_p, holm([e["p"] for e in mit_p])):
        e["p_holm"] = ph
        if ph < alpha and e["dmse_h1"] > 0 and e["dmse_h2"] > 0 and e["dmse"] > 0:
            e["status"] = "trägt"
        elif e["p"] < alpha:
            e["status"] = "Hinweis"
        else:
            e["status"] = "trägt nicht"
    for e in kand:
        e.setdefault("status", "trägt nicht")
    zeilen_mhat = {}
    for ci, c in enumerate(RGd["coins"]):
        m = (RGd["ci"] == ci) & np.isfinite(W["mhat"])
        zeilen_mhat[c] = dict(zip(tag[m].tolist(), W["mhat"][m].tolist()))
    return {"h": h, "kandidaten": kand, "mse": mse_m, "mse0": float(np.mean(y[oos] ** 2)) if oos.any() else None,
            "refits": [(int(T), float(lam), [float(x) for x in w]) for T, lam, w in W["refits"]], "mhat": zeilen_mhat,
            "verfahren": verfahren, "alpha": alpha, "n_oos": int(oos.sum())}


def staerkster(G_: dict) -> dict | None:
    """Für die Lesart: der Kandidat mit dem kleinsten p (bei 7 Tagen) und sein Status."""
    ks = [e for e in (G_.get("kandidaten") or []) if e.get("p") is not None]
    if not ks:
        return None
    e = min(ks, key=lambda e: (e["p"], -(e.get("dmse") or 0)))
    return {"key": e["key"], "name": e["name"], "status": e["status"], "p": e["p"], "p_holm": e.get("p_holm")}


# ================================================================================================ Rückblick: Ziellevels (S3), gemeinsame Form (S4)

def _swing_niveaus(D: dict, i: int, n: int = 5, tage: int = 365) -> tuple:
    """Swing-Hochs/-Tiefs aus den Tageshochs/-tiefs bis Tag i (bestätigt nach n Tagen) wie das Chartbild: die zwei nächsten je Seite
    innerhalb ±30 % -> (oben, unten)."""
    h, l, c = D["H"], D["L"], D["C"]
    px = c[i]; a = max(n, i - tage)
    hoch, tief = [], []
    for t in range(a, i - n + 1):
        if t - n < 0 or not np.isfinite(h[t]):
            continue
        if h[t] > np.nanmax(h[t - n:t]) and h[t] >= np.nanmax(h[t + 1:t + n + 1]):
            hoch.append(h[t])
        if l[t] < np.nanmin(l[t - n:t]) and l[t] <= np.nanmin(l[t + 1:t + n + 1]):
            tief.append(l[t])
    oben = sorted([x for x in hoch if px < x <= px * 1.3])[:2]
    unten = sorted([x for x in tief if px * 0.7 <= x < px], reverse=True)[:2]
    return oben, unten


def s3_ziellevels(V: dict, log) -> dict:
    """
    S3 (5.1, 5.3): wöchentliche Ursprünge (Montag 00:00 UTC) ab 2022, Prüfniveaus C·e^{±k√F} (k = 0,5/1/1,5/2), die zwei nächsten
    Swing-Niveaus je Seite und die nächsten runden Zahlen; Erreich-Wahrscheinlichkeit aus B0 gegen B1 (Spiegelungsprinzip),
    Erreichen an den Tageshochs/-tiefs. Brier, Brier-Skill, Zuverlässigkeit (10 Klassen), Kalibrierungssteigung.
    """
    import hl_chartbild as CB
    rec = {k: [] for k in ("coin", "tau", "h", "art", "p0", "p1", "ja")}
    for coin, v in V.items():
        B, _ = bibliothek_fuer(coin, V)
        if B is None:
            continue
        A = v["A"]; tau = A["tau"]; lc = np.log(A["C"]); lh = np.log(A["H"]); ll = np.log(A["L"])
        D = v["D"]; s365 = _sigma365_anker(A)
        J = [j for j in range(A["n"]) if tau[j] >= OOS_AB and int(tau[j]) % TAG == 0
             and datetime.fromtimestamp(int(tau[j]), timezone.utc).weekday() == 0]
        for j in J:
            if j + JE_TAG * K_MAX >= A["n"]:
                break
            m = bib_bis(B, tau[j])
            if m.sum() < 200 or not np.all(np.isfinite(v["Fk"][j])):
                continue
            S = szenarien(B, m, v["Fk"][j])
            i_d = int(np.searchsorted(D["tag"], tau[j] // TAG - 1))
            oben, unten = _swing_niveaus(D, i_d) if i_d < D["n"] else ([], [])
            ru, ro, _ = CB.runde(float(A["C"][j]))
            for h in H_ZIEL:
                hl_max = np.nanmax(lh[j + JE_TAG: j + JE_TAG * h + 1: JE_TAG]) - lc[j]
                ll_min = np.nanmin(ll[j + JE_TAG: j + JE_TAG * h + 1: JE_TAG]) - lc[j]
                sq = math.sqrt(v["Fk"][j, h - 1])
                niv = [(f"k{k}", sg * k * sq) for k in TOUCH_K for sg in (1, -1)]
                niv += [("swing", math.log(x / A["C"][j])) for x in oben + unten]
                niv += [("rund", math.log(x / A["C"][j])) for x in (ru, ro) if np.isfinite(x)]
                for art, d_ln in niv:
                    pe, _ps = erreichen(S, d_ln, h)
                    p1 = 2 * (1 - float(norm_cdf(abs(d_ln) / (s365[j] * math.sqrt(h))))) if np.isfinite(s365[j]) else float("nan")
                    ja = float(hl_max >= d_ln) if d_ln >= 0 else float(ll_min <= d_ln)
                    for k_, val in (("coin", coin), ("tau", int(tau[j])), ("h", h), ("art", art), ("p0", pe), ("p1", min(1.0, p1)), ("ja", ja)):
                        rec[k_].append(val)
        log(f"  S3 {coin}: {len(J)} Montage")
    U = {k: np.array(v_) for k, v_ in rec.items()}
    out = {"h": {}}
    for h in H_ZIEL:
        m = (U["h"] == h) & np.isfinite(U["p0"]) & np.isfinite(U["p1"])
        if m.sum() < 100:
            out["h"][str(h)] = {"n": int(m.sum())}; continue
        p0, p1, ja = U["p0"][m], U["p1"][m], U["ja"][m]
        b0 = float(np.mean((p0 - ja) ** 2)); b1 = float(np.mean((p1 - ja) ** 2))
        stg = logit_steigung(ja, p0)
        kl = np.clip((p0 * 10).astype(int), 0, 9)
        zuv = []
        for k_ in range(10):
            mk = kl == k_
            if mk.sum():
                import hl_aktien as AK
                lo, hi = AK.wilson(int(ja[mk].sum()), int(mk.sum()), 1.645)
                zuv.append([k_, int(mk.sum()), float(p0[mk].mean()), float(ja[mk].mean()), lo, hi])
        je_art = {a: {"n": int((U["art"][m] == a).sum()), "p": float(p0[U["art"][m] == a].mean()), "quote": float(ja[U["art"][m] == a].mean())}
                  for a in np.unique(U["art"][m])}
        out["h"][str(h)] = {"n": int(m.sum()), "brier_b0": b0, "brier_b1": b1, "skill": 1 - b0 / b1 if b1 > 0 else None, "steigung": stg,
                            "zuverlaessigkeit": zuv, "je_art": je_art,
                            "besteht": bool(np.isfinite(stg) and 0.8 <= stg <= 1.2 and b1 > 0 and 1 - b0 / b1 > 0)}
    out["bestanden_alle"] = all(out["h"].get(str(h), {}).get("besteht") for h in H_ZIEL)
    out["steigung_28"] = out["h"].get("28", {}).get("steigung")
    return out


def knueppel(u: np.ndarray, lag: int) -> dict:
    """Rohmomenten-Test auf Gleichverteilung (Knüppel 2015): Momente 1–4 von u gegen 1/(k+1), HAC-Kovarianz (Bartlett, lag), χ²(4)."""
    u = u[np.isfinite(u)]; n = len(u)
    if n < 50:
        return {"n": n}
    Z = np.column_stack([u ** k - 1.0 / (k + 1) for k in range(1, 5)])
    m = Z.mean(axis=0); Zc = Z - m
    S = Zc.T @ Zc / n
    for L in range(1, min(lag, n - 1) + 1):
        G = Zc[L:].T @ Zc[:-L] / n
        S += (1 - L / (lag + 1)) * (G + G.T)
    try:
        W = float(n * m @ np.linalg.solve(S, m))
    except np.linalg.LinAlgError:
        return {"n": n}
    return {"n": n, "W": W, "p": chi2_sf(W, 4), "momente": [float(x) for x in m]}


def s4_gemeinsam(V: dict, SPB: dict, G: dict, log, coin: str = "BTC", seed: int = 5) -> dict:
    """
    S4 (13.9): gemeinsame Bibliothek (BTC, S&P) gegen unabhängige Paarung im Variogramm-Score (p = 0,5) auf (BTC, S&P) × (7, 14, 28),
    standardisiert; Rosenblatt-PIT u2 = F̂(b | s) über alle 00-UTC-Ursprünge, insgesamt und unter Aktienstress (u1 < 0,2), mit dem
    Rohmomenten-Test; Deckung des bedingten 80-%-Bands je Aktienzustand.
    """
    if coin not in V or not SPB.get("n") or SPB["n"] < 300:
        return {"grund": "S&P 500 oder BTC fehlt"}
    v = V[coin]; B = v["B"]; A = v["A"]
    zS = sp_koordinate(B, SPB)
    okS = np.all(np.isfinite(zS), axis=1)
    if okS.sum() < 500:
        return {"grund": f"zu wenige Fenster mit S&P-Pfad ({int(okS.sum())})"}
    o = np.argsort(B["ende"], kind="stable")
    tz = sp_schluss_zeit(SPB["t"]); lp = SPB["lp"]
    rng = np.random.default_rng(seed)
    rec = {k: [] for k in ("tag", "vs_g", "vs_u", "u1", "u2_7", "u2_28", "d80_7", "d80_28")}
    tau = A["tau"]; lc = np.log(A["C"])
    for j in np.nonzero((tau >= OOS_AB) & (A["stunde"] == 0))[0]:
        if j + JE_TAG * 28 >= A["n"]:
            break
        m = bib_bis(B, tau[j]) & okS
        if m.sum() < 300:
            continue
        FSh = {h: sp_breite_jetzt(SPB, tau[j], h) for h in H_ZIEL}
        if not all(np.isfinite(FSh[h]) and FSh[h] > 0 for h in H_ZIEL) or not np.all(np.isfinite(v["Fk"][j])):
            continue
        Zb = B["Z"][m].astype(float); zs = zS[m].astype(float)
        mb = Zb.mean(axis=0); ms = zs.mean(axis=0)
        js = np.searchsorted(tz, tau[j], side="right") - 1
        yv, ev = [], []
        for h in H_ZIEL:
            je = np.searchsorted(tz, tau[j] + h * TAG, side="right") - 1
            yb = (lc[j + JE_TAG * h] - lc[j]) / math.sqrt(v["Fk"][j, h - 1]); ys = (lp[je] - lp[js]) / math.sqrt(FSh[h])
            yv += [yb, ys]
            ev += [Zb[:, h - 1] - mb[h - 1], zs[:, h - 1] - ms[h - 1]]
        Y = np.array(yv); E = np.column_stack(ev)
        perm = rng.permutation(len(E))
        Eu = E.copy(); Eu[:, 1::2] = E[perm][:, 1::2]

        def vs(Ens):
            tot = 0.0
            for a_ in range(6):
                for b_ in range(a_ + 1, 6):
                    tot += (abs(Y[a_] - Y[b_]) ** 0.5 - float(np.mean(np.abs(Ens[:, a_] - Ens[:, b_]) ** 0.5))) ** 2
            return tot
        rec["tag"].append(int(tau[j] // TAG)); rec["vs_g"].append(vs(E)); rec["vs_u"].append(vs(Eu))
        rec["u1"].append(float(np.mean(E[:, 5] <= Y[5])))
        for h, ib, is_ in ((7, 0, 1), (28, 4, 5)):
            w = np.exp(-0.5 * ((E[:, is_] - Y[is_]) / KERN_LAMBDA) ** 2)
            sw = w.sum()
            rec[f"u2_{h}"].append(float(np.sum(w * (E[:, ib] <= Y[ib])) / sw) if sw > 0 else float("nan"))
            if sw > 0:
                ql, qh = gew_quantile(E[:, ib], w, [0.10, 0.90])
                rec[f"d80_{h}"].append(float(ql <= Y[ib] <= qh))
            else:
                rec[f"d80_{h}"].append(float("nan"))
    U = {k: np.array(x) for k, x in rec.items()}
    if len(U["tag"]) < 100:
        return {"grund": f"zu wenige Ursprünge ({len(U['tag'])})"}
    vsr = _test_tagesreihe(U["tag"], U["vs_u"] - U["vs_g"], 56.0, seed + 1)
    out = {"n": int(len(U["tag"])), "variogramm": vsr, "besteht": bool(vsr.get("p", 1) < 0.05 and vsr.get("haelften")),
           "rosenblatt": {}, "deckung": {}}
    stress = U["u1"] < 0.2
    for h in (7, 28):
        u2 = U[f"u2_{h}"]
        out["rosenblatt"][str(h)] = {"alle": knueppel(u2, h), "stress": knueppel(u2[stress], h)}
        d = U[f"d80_{h}"]
        out["deckung"][str(h)] = {"stress": float(np.nanmean(d[stress])) if stress.any() else None,
                                  "mitte": float(np.nanmean(d[(U["u1"] >= 0.2) & (U["u1"] <= 0.8)])),
                                  "hoch": float(np.nanmean(d[U["u1"] > 0.8])) if (U["u1"] > 0.8).any() else None}
    log(f"  S4 {coin}: {out['n']} Ursprünge, Variogramm-Gewinn p {_de(vsr.get('p'), 3)} -> {'belegt' if out['besteht'] else 'nicht belegt'}")
    return out


def korrelationen(V: dict, KA: dict, seed: int = 3) -> dict:
    """Reiter „Korrelationen“ (6), ausdrücklich beschreibend: Spearman der Kandidaten untereinander (BTC, 3 Jahre), jeder Kandidat
    gegen die normierte Rendite der folgenden 7/14/28 Tage (Krypto gepoolt, 3 Jahre) mit 90-%-Nullband aus 200 zirkulären
    Verschiebungen, Gleichlauf der Coins (28-Tage-Renditen)."""
    import hl_makro_korr as MKK
    out = {}
    if "BTC" in V and "BTC" in KA:
        D = V["BTC"]["D"]; m = D["tag"] >= D["tag"][-1] - 3 * 365
        X = KA["BTC"]["roh"][m]
        R = np.column_stack([MKK.raenge(np.where(np.isfinite(X[:, i]), X[:, i], np.nanmedian(X[:, i]) if np.isfinite(X[:, i]).any() else 0.0))
                             for i in range(X.shape[1])])
        with np.errstate(invalid="ignore"):
            C = np.corrcoef(R.T)
        out["kandidaten"] = {"namen": list(K_NAMEN), "matrix": [[None if not np.isfinite(x) else round(float(x), 3) for x in row] for row in C]}
    zv = {}
    rng = np.random.default_rng(seed)
    for h in H_ZIEL:
        e = {}
        for i, k in enumerate(K_NAMEN):
            xs, ys = [], []
            for c in KRYPTO:
                if c not in V or c not in KA:
                    continue
                D = V[c]["D"]; mm = (D["tag"] >= D["tag"][-1] - 3 * 365) & np.isfinite(V[c]["y"][h]) & np.isfinite(KA[c]["roh"][:, i])
                if mm.sum() < 60:
                    continue
                xr_ = MKK.raenge(KA[c]["roh"][mm, i]); yr_ = MKK.raenge(V[c]["y"][h][mm])
                if not (np.std(xr_) > 0 and np.std(yr_) > 0):          # konstant im Fenster (z. B. Reihe ruht): kein ρ, keine Warnung
                    continue
                xs.append(xr_); ys.append(yr_)
            if not xs:
                continue
            rho = float(np.mean([np.corrcoef(a, b)[0, 1] for a, b in zip(xs, ys)]))
            nul = []
            for _ in range(200):
                s = int(rng.integers(90, max(91, min(len(a) for a in xs) - 90)))
                nul.append(float(np.mean([np.corrcoef(np.roll(a, s), b)[0, 1] for a, b in zip(xs, ys)])))
            e[k] = {"rho": rho, "null_lo": float(np.quantile(nul, 0.05)), "null_hi": float(np.quantile(nul, 0.95))}
        zv[str(h)] = e
    out["zukunft"] = zv
    rr = {}
    for c in V:
        D = V[c]["D"]; lc = np.log(D["C"]); r28 = np.full(D["n"], np.nan); r28[28:] = lc[28:] - lc[:-28]
        rr[c] = dict(zip(D["tag"].tolist(), r28.tolist()))
    cs = [c for c in COINS if c in rr]
    if cs:
        tage = sorted(set.intersection(*[set(k for k, x in rr[c].items() if np.isfinite(x)) for c in cs]))[-3 * 365:]
        M = np.array([[rr[c][t] for t in tage] for c in cs])
        out["gleichlauf"] = {"coins": cs, "matrix": np.round(np.corrcoef(M), 3).tolist() if len(tage) > 60 else None, "n": len(tage)}
    return out


# ================================================================================================ Rückblick: Ablauf und Speichern

def rueckblick(db: str, log=None, n_null: int = NULL_K, schreiben: bool = True, G: dict | None = None, verfahren: str | None = None,
               jetzt: int | None = None) -> dict:
    """Der wöchentliche Lauf (7, 13): Breite (HAR-X), Richtung (Ridge, Gewichte, Nullläufe), Ursprünge (S1, Tor), Ziellevels (S3),
    gemeinsame Form (S4), Korrelationen, Vorwärtsbilanz. Schreibt nur ausblick.db."""
    log = log or (lambda *a: None)
    t0 = time.time(); jetzt = int(jetzt or time.time())
    G = G or lade(db, log=log)
    coins = [c for c in COINS if c in G["coins"]]
    log(f"Rückblick über {', '.join(coins)} (Nullverfahren {verfahren or NULL_WAHL['verfahren']}, {n_null} Surrogate)")
    BW = breite_waehlen(G, coins, log)
    V = {}
    for c in coins:
        v = vorbereiten(c, G, BW["wahl"])
        if v is not None:
            V[c] = v
    KA = kandidaten_alle(V, G)
    RI = {"krypto": {}, "paxg": {}}; mhat_zeilen = {}
    for gruppe in ("krypto", "paxg"):
        for h in H_ZIEL:
            RGd = ridge_gruppe(V, KA, gruppe, h)
            if RGd is None:
                RI[gruppe][str(h)] = {"grund": "zu wenige Zeilen"}; continue
            t1 = time.time()
            GP = gewichte_pruefen(RGd, h, n_null, verfahren, seed=zlib.crc32(f"{gruppe}{h}".encode()), log=log)
            RI[gruppe][str(h)] = GP
            for c, d in GP["mhat"].items():
                mhat_zeilen.setdefault(c, {})[h] = d
            log(f"  Gewichte {gruppe} h={h}: {len(GP['kandidaten'])} Kandidaten, {sum(1 for e in GP['kandidaten'] if e['status'] == 'trägt')} "
                f"tragen, MSE {_de(GP['mse'], 4)} gegen {_de(GP['mse0'], 4)} (Drift 0), {time.time() - t1:.0f} s")
    U = ursprung_auswertung(V, mhat_zeilen, log)
    S1 = urteil_s1(U)
    con = verbinden(ausblick_pfad(db)) if schreiben else None
    tor_alt = (_json_meta(con, "tor", {}) if con is not None else {}) or {}
    tor = {"krypto": {}, "paxg": {}}
    for gruppe, cs in (("krypto", [c for c in KRYPTO if c in V]), ("paxg", ["PAXG"] if "PAXG" in V else [])):
        for h in H_ZIEL:
            t_ = tor_rechnen(U, cs, h, seed=500 + h) if cs else {"offen": False, "grund": "keine Coins"}
            alt = (tor_alt.get(gruppe) or {}).get(str(h)) or {}
            t_["seit"] = (alt.get("seit") if alt.get("offen") else jetzt) if t_.get("offen") else None
            t_["geprueft"] = jetzt
            tor[gruppe][str(h)] = t_
            log(f"  Tor {gruppe} h={h}: {'OFFEN' if t_.get('offen') else 'zu'} (CW p {_de((t_.get('cw') or {}).get('p'), 3)}, CRPS p "
                f"{_de((t_.get('crps') or {}).get('p'), 3)}, R²_OS {_de(t_.get('r2_os'), 4)})")
    S3 = s3_ziellevels(V, log)
    SPB = sp_breite({"ts": G["R"]["fred:SP500"]["ts"], "w": G["R"]["fred:SP500"]["w"]}, G["R"].get("fred:VIXCLS"),
                    G["R"].get("fred:VXVCLS")) if "fred:SP500" in G["R"] else {}
    S4 = s4_gemeinsam(V, SPB, G, log)
    zr = stress_zeitraum(G["R"].get("fred:VIXCLS"))
    KO = korrelationen(V, KA)
    dauer = time.time() - t0
    erg = {"stand": jetzt, "version": VERSION_MODUL, "dauer": dauer, "coins": list(V), "fehlt": G["fehlt"], "breite": BW,
           "richtung": {g: {h: {k: v_ for k, v_ in d.items() if k != "mhat"} for h, d in RI[g].items()} for g in RI}, "s1": S1, "tor": tor,
           "s3": S3, "s4": S4, "stress_zeitraum": zr, "korrelationen": KO,
           "null_wahl": dict(NULL_WAHL, verfahren=verfahren or NULL_WAHL["verfahren"], n=n_null)}
    if con is not None:
        try:
            erg["vorwaerts"] = vorwaerts_auswerten(db)
        except Exception as e:
            erg["vorwaerts"] = {"fehler": str(e)}
        gj = {g: {h: (d["refits"][-1][2] if d.get("refits") else None) for h, d in RI[g].items()} for g in RI}
        stk = {g: staerkster(RI[g].get("7") or {}) for g in RI}
        meta_setzen(con, {"tor": json.dumps(_ohne_nan(tor)), "gewichte_jetzt": json.dumps(_ohne_nan(gj)), "breite_wahl": json.dumps(BW["wahl"]),
                          "s1": json.dumps(_ohne_nan({"deckung": S1["deckung"], "bestanden_alle": S1["bestanden_alle"],
                                                      "h": {h: {"besteht": e.get("besteht"), "p": e.get("p"), "gewinn_rel": e.get("gewinn_rel")}
                                                            for h, e in S1["h"].items()}, "pruef": s1_pruef(S1)})),
                          "s3": json.dumps(_ohne_nan({"bestanden_alle": S3.get("bestanden_alle"), "steigung_28": S3.get("steigung_28")})),
                          "s4_urteil": json.dumps(_ohne_nan({"besteht": S4.get("besteht"), "p": (S4.get("variogramm") or {}).get("p"),
                                                             "grund": S4.get("grund"), "pit_stress": s4_pit_stress(S4)})),
                          "stress_zeitraum": json.dumps(zr), "staerkster": json.dumps(_ohne_nan(stk)), "rueckblick_stand": str(jetzt),
                          "rueckblick_dauer": f"{dauer:.0f}"})
        _tx(con, lambda: con.execute("INSERT OR REPLACE INTO au_rueckblick VALUES (?,?,?)", (jetzt, dauer, json.dumps(_ohne_nan(erg)))))
        zeilen = [(jetzt, int(h), g, int(T), lam, json.dumps([round(x, 6) for x in w])) for g in RI for h, d in RI[g].items()
                  for T, lam, w in (d.get("refits") or [])]
        _tx(con, lambda: con.executemany("INSERT OR REPLACE INTO au_gewichte VALUES (?,?,?,?,?,?)", zeilen))
        nz = [(jetzt, int(h), g, e["key"], json.dumps(_ohne_nan(e))) for g in RI for h, d in RI[g].items() for e in (d.get("kandidaten") or [])]
        _tx(con, lambda: con.executemany("INSERT OR REPLACE INTO au_null VALUES (?,?,?,?,?)", nz))
        _tx(con, lambda: con.execute("DELETE FROM au_rueckblick WHERE stand NOT IN (SELECT stand FROM au_rueckblick ORDER BY stand DESC LIMIT 12)"))
        con.close()
    log(f"Rückblick fertig in {dauer:.0f} s")
    return erg


# ================================================================================================ Schockregel (13.1) und Takt im Dashboard

def schock_basis(V: dict, G: dict, SPB: dict, erg: dict) -> dict:
    """Was die leichte Schockprüfung braucht: F(τ,1) je Coin aus der letzten Rechnung und die S&P-Varianz je Handelstag."""
    out = {"coins": {}}
    for c, E in erg.items():
        F1 = (E.get("F") or {}).get("1")
        if F1:
            out["coins"][c] = {"F1": F1, "anker": E.get("anker")}
    if SPB.get("n", 0) >= 300:
        jv = np.nonzero(np.isfinite(SPB["V"][7]))[0]
        if len(jv):
            out["FS1"] = float(SPB["V"][7][jv[-1]])
    return out


def _letzte_kerzen(db: str, coin: str, n: int = 13) -> tuple:
    import hl_regime as RG
    import hl_swing as SW
    pfad, tab = (SW.swing_pfad(db), "sw_klines") if coin in SW.COINS else (RG.regime_pfad(db), "rg_klines")
    if not os.path.exists(pfad):
        return None
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=5)
        try:
            rows = con.execute(f"SELECT ts, c FROM {tab} WHERE coin=? ORDER BY ts DESC LIMIT ?", (coin, n)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    if len(rows) < 2:
        return None
    a = np.array(rows[::-1], dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1]


def schock_pruefen(db: str, jetzt: int | None = None, setzen: bool = True) -> list:
    """
    Leichte Prüfung außerhalb des Takts (alle 5 min): (a) letzte 30-min-Rendite |r| > 5·√(F(τ,1)/48); (b) Varianz der letzten 6 h
    > 4 × F(τ,1)·6/24; (c) S&P-500-Perp (xyz) in 6 h > 3·√(F_S·6/24), auch am Wochenende. -> Liste neuer Ausnahmen (Coin, Regel, Grund).
    """
    import hl_aktien as AK
    jetzt = int(jetzt or time.time())
    pfad = ausblick_pfad(db)
    if not os.path.exists(pfad):
        return []
    con = verbinden(pfad)
    try:
        basis = _json_meta(con, "schock_basis", {}) or {}
        ausn = _json_meta(con, "ausnahme", {}) or {}
        neu = []
        for c, b in (basis.get("coins") or {}).items():
            if c in ausn and jetzt - int(ausn[c].get("seit", 0)) < AUSNAHME_S:
                continue
            k = _letzte_kerzen(db, c)
            if k is None or jetzt - int(k[0][-1]) > 2 * 3600:
                continue
            ts, cc = k
            r = np.diff(np.log(cc)); folge = np.diff(ts) == BAR
            r = np.where(folge, r, np.nan)
            F1 = float(b["F1"])
            if np.isfinite(r[-1]) and abs(r[-1]) > SCHOCK_R * math.sqrt(F1 / 48):
                neu.append((c, "a", f"30-min-Bewegung {_pr(math.expm1(r[-1]))} über {SCHOCK_R:.0f} typische Halbstundenbewegungen"))
                continue
            r6 = r[-12:]
            if np.isfinite(r6).sum() >= 10 and np.nansum(r6 * r6) > SCHOCK_RV * F1 * 6 / 24:
                neu.append((c, "b", f"Schwankung der letzten 6 h über dem {SCHOCK_RV:.0f}-Fachen der erwarteten"))
        FS1 = basis.get("FS1")
        if FS1:
            ak = AK.lesen(AK.aktien_pfad(db))
            if ak is not None:
                try:
                    K = AK.kerzen(ak, "xyz:SP500:30m", ab=jetzt - 8 * 3600)
                finally:
                    ak.close()
                if K is not None and len(K["ts"]) >= 12 and jetzt - int(K["ts"][-1]) < 2 * 3600:
                    j6 = np.searchsorted(K["ts"], K["ts"][-1] - 6 * 3600)
                    bew = math.log(K["c"][-1] / K["c"][j6])
                    if abs(bew) > SCHOCK_SP * math.sqrt(FS1 * 6 / 24):
                        for c in (basis.get("coins") or {}):
                            if c != "PAXG" and not (c in ausn and jetzt - int(ausn[c].get("seit", 0)) < AUSNAHME_S):
                                neu.append((c, "c", f"S&P-500-Perp in 6 h {_pr(math.expm1(bew))}"
                                            + ("" if AK.boerse_offen(jetzt) else " (Börse geschlossen, Perp-Stand)")))
        if neu and setzen:
            for c, regel, grund in neu:
                ausn[c] = {"seit": jetzt, "regel": regel, "grund": grund}
            meta_setzen(con, {"ausnahme": json.dumps(ausn)})
        return neu
    finally:
        con.close()


_TAKT = {"gestartet": False, "proc": None, "art": None, "letzte_anfrage": 0.0, "letzter_start": 0.0, "letzte_schockpruefung": 0.0,
         "fehler": None, "laeufe": 0}


def anfrage_merken() -> None:
    """Der Abschnitt wurde im Dashboard angezeigt: solange er offen ist, wird alle 30 min neu gerechnet (13.1)."""
    _TAKT["letzte_anfrage"] = time.time()


def _starte_lauf(db: str, art: str, tau: int | None = None) -> bool:
    import subprocess
    p = _TAKT.get("proc")
    if p is not None and p.poll() is None:
        return False
    log = os.path.join(os.path.dirname(ausblick_pfad(db)), "ausblick_takt.log")
    try:
        if os.path.exists(log) and os.path.getsize(log) > 2_000_000:
            os.replace(log, log + ".1")
    except OSError:
        pass
    if art == "rueckblick":                                     # 7.2: der wöchentliche Lauf, ebenfalls mit nice 10
        cmd = [sys.executable, os.path.abspath(__file__), "--rueckblick", "--db", db]
    else:
        cmd = [sys.executable, os.path.abspath(__file__), "--prognose", "--db", db, "--art", art] + (["--tau", str(int(tau))] if tau else [])
    try:
        f = open(log, "a")
        f.write(f"[{time.strftime('%d.%m. %H:%M:%S')}] Start {art}{' τ ' + _dtz(tau) if tau else ''}\n"); f.flush()
        _TAKT["proc"] = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, preexec_fn=lambda: os.nice(10), cwd=os.path.dirname(os.path.abspath(__file__)))
        f.close()
    except OSError as e:
        _TAKT["fehler"] = f"{type(e).__name__}: {e}"
        return False
    _TAKT["art"] = art; _TAKT["letzter_start"] = time.time(); _TAKT["laeufe"] += 1
    return True


RUECKBLICK_WIEDER_S = 6 * 3600                                 # ein gescheiterter Rückblick wird frühestens nach 6 h wiederholt


def rueckblick_faellig(stand: int, jetzt: float, takt_start: float) -> bool:
    """
    7.2/7.5: der erste Rückblick in der Nacht nach dem Einspielen (01–06 UTC; spätestens 24 h nach dem Start des Takts), danach
    wöchentlich sonntags ab 02:00 UTC, wenn der letzte älter als 5 Tage ist.
    """
    d = datetime.fromtimestamp(jetzt, timezone.utc)
    if not stand:
        return 1 <= d.hour < 6 or jetzt - takt_start >= TAG
    return d.weekday() == 6 and d.hour >= 2 and jetzt - stand > 5 * TAG


def takt_schritt(db: str, jetzt: float | None = None) -> str | None:
    """Ein Schritt des Takts (jede Minute): Rückblick (Nacht, sonntags), 6-h-Anker der Vorwärtsbilanz, Schock, offener Abschnitt (30 min),
    Hintergrund (stündlich). Nach einem Rückblick rechnet die nächste Runde die Prognose sofort mit dem neuen Stand."""
    jetzt = float(jetzt or time.time())
    p = _TAKT.get("proc")
    if p is not None and p.poll() is None:
        if _TAKT.get("art") == "rueckblick" and jetzt - _TAKT["letzte_schockpruefung"] >= 300:
            _TAKT["letzte_schockpruefung"] = jetzt                  # auch während des Rückblicks: die Ausnahme steht sofort, gerechnet
            try:                                                   # wird gleich danach (nach_rueckblick)
                schock_pruefen(db, int(jetzt))
            except Exception as e:
                _TAKT["fehler"] = f"Schockprüfung: {type(e).__name__}: {e}"
        return None
    con = lesen(ausblick_pfad(db))
    letzte = 0.0; max6 = 0; rb_stand = 0
    if con is not None:
        try:
            letzte = float(meta(con, "letzte_prognose", "0") or 0)
            rb_stand = int(meta(con, "rueckblick_stand", "0") or 0)
            r = con.execute("SELECT MAX(anker) FROM au_prognose WHERE anker % ? = 0", (ANKER_S,)).fetchone()
            max6 = int(r[0] or 0)
        except sqlite3.Error:
            pass
        finally:
            con.close()
    if _TAKT.get("art") == "rueckblick" and p is not None and _TAKT.get("nach_rb"):
        _TAKT["nach_rb"] = False
        return "nach_rueckblick" if _starte_lauf(db, "nach_rueckblick") else None
    if rueckblick_faellig(rb_stand, jetzt, float(_TAKT.get("start") or jetzt)) and jetzt - float(_TAKT.get("rb_versuch") or 0) >= RUECKBLICK_WIEDER_S:
        _TAKT["rb_versuch"] = jetzt
        if _starte_lauf(db, "rueckblick"):
            _TAKT["nach_rb"] = True
            return "rueckblick"
    a6 = anker_von(int(jetzt))
    if jetzt >= a6 + 600 and max6 < a6:
        v = _TAKT.setdefault("anker_versuch", {}).get(a6, (0, 0.0))
        if v[0] < 6 and jetzt - v[1] >= 600:                  # fehlt die Kerze am Anker: höchstens alle 10 min, sechsmal
            _TAKT["anker_versuch"] = {a6: (v[0] + 1, jetzt)}
            return "anker" if _starte_lauf(db, "anker", a6) else None
    if jetzt - _TAKT["letzte_schockpruefung"] >= 300:
        _TAKT["letzte_schockpruefung"] = jetzt
        try:
            if schock_pruefen(db, int(jetzt)):
                return "schock" if _starte_lauf(db, "schock") else None
        except Exception as e:
            _TAKT["fehler"] = f"Schockprüfung: {type(e).__name__}: {e}"
    h30 = halbstunden_anker(int(jetzt))
    if jetzt - _TAKT["letzte_anfrage"] < 35 * 60 and letzte < h30 and jetzt >= h30 + 360:
        return "takt" if _starte_lauf(db, "takt") else None
    if jetzt - letzte >= 3600:
        return "stuendlich" if _starte_lauf(db, "stuendlich") else None
    return None


def starten(db: str) -> bool:
    """Takt im Dashboard-Prozess (die Rechnung selbst läuft als eigener Prozess mit nice 10). Nicht für Selbsttest-Datenbanken, aus mit
    HL_AUSBLICK=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_AUSBLICK") == "0":
        return False
    _TAKT["gestartet"] = True; _TAKT["start"] = time.time()

    def schleife():
        time.sleep(120)
        while True:
            try:
                takt_schritt(db)
            except Exception as e:
                _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Ausblick-Takt: {_TAKT['fehler']}", flush=True)
            time.sleep(60)
    threading.Thread(target=schleife, daemon=True, name="ausblick").start()
    return True


# ================================================================================================ Antwort für das Dashboard und Text

_RB_CACHE: dict = {"stand": None, "daten": None, "lock": threading.Lock()}


def rueckblick_lesen(con) -> dict | None:
    """Jüngster Rückblick (zwischengespeichert, bis ein neuer da ist)."""
    r = con.execute("SELECT stand, json FROM au_rueckblick ORDER BY stand DESC LIMIT 1").fetchone()
    if not r:
        return None
    with _RB_CACHE["lock"]:
        if _RB_CACHE["stand"] != r[0]:
            _RB_CACHE["stand"] = r[0]; _RB_CACHE["daten"] = json.loads(r[1])
        return _RB_CACHE["daten"]


def nutzlast(db: str, coin: str, chart: dict | None = None) -> dict:
    """Antwort für /ausblick: jüngste Rechnung des Coins, Rückblick (Gewichte, Bilanz, Korrelationen), Takt-Zustand, Tageskerzen."""
    anfrage_merken()
    coin = (coin or "BTC").upper()[:12]
    out = {"ok": True, "coin": coin, "version": VERSION_MODUL, "jetzt": int(time.time()), "fehlt": []}
    p = _TAKT.get("proc")
    out["takt"] = {"laeuft": bool(p is not None and p.poll() is None), "art": _TAKT.get("art"), "letzter_start": int(_TAKT["letzter_start"]) or None,
                   "fehler": _TAKT.get("fehler")}
    if coin not in COINS:
        out["fehlt"].append(f"{coin}: kein Ausblick (nur {', '.join(COINS)})"); return out
    con = lesen(ausblick_pfad(db))
    if con is None:
        out["fehlt"].append("ausblick.db fehlt noch -- die erste Rechnung folgt wenige Minuten nach dem Start des Dashboards")
    else:
        try:
            r = con.execute("SELECT json, anker, erzeugt, art FROM au_prognose WHERE coin=? ORDER BY anker DESC, erzeugt DESC LIMIT 1",
                            (coin,)).fetchone()
            if r:
                out["prognose"] = json.loads(r[0])
                alt = time.time() - int(r[1])
                if alt > 2 * TAG:
                    out["fehlt"].append(f"Stand vom {_dtz(r[1])} -- älter als 2 Tage")
            else:
                out["fehlt"].append("noch keine Rechnung für diesen Coin")
            R = rueckblick_lesen(con)
            if R:
                out["rueckblick"] = {k: R.get(k) for k in ("stand", "dauer", "breite", "s1", "tor", "s3", "s4", "stress_zeitraum", "null_wahl",
                                                          "vorwaerts", "fehlt")}
                g = "paxg" if coin == "PAXG" else "krypto"
                out["rueckblick"]["gewichte"] = {h: {k: v for k, v in d.items() if k != "refits"} for h, d in (R.get("richtung") or {}).get(g, {}).items()}
                out["rueckblick"]["korrelationen"] = R.get("korrelationen")
            out["meta"] = {"letzte_prognose": meta(con, "letzte_prognose"), "letzte_dauer": meta(con, "letzte_dauer"), "letzte_art": meta(con, "letzte_art"),
                           "rueckblick_stand": meta(con, "rueckblick_stand"), "rueckblick_dauer": meta(con, "rueckblick_dauer")}
        finally:
            con.close()
    if chart and chart.get("tage"):
        T = chart["tage"]; a = max(0, len(T["c"]) - 400)
        out["tage"] = {"t0": T["t0"] + a, **{k: T[k][a:] for k in ("o", "h", "l", "c", "ma50", "ma200")}, "quelle": T.get("quelle")}
        out["kurs"] = chart.get("kurs")
    return _ohne_nan(out)


def text(db: str, coins=COINS) -> str:
    Z = []; a = Z.append
    a(f"★ Ausblick 4 Wochen (U146) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')} · Spannen und Wahrscheinlichkeiten, keine Empfehlung")
    con = lesen(ausblick_pfad(db))
    if con is None:
        a("ausblick.db fehlt noch -- erste Rechnung nach dem Start des Dashboards (Takt) oder mit --prognose."); return "\n".join(Z)
    try:
        a(f"Letzte Rechnung {_dtz(int(float(meta(con, 'letzte_prognose', '0') or 0)) or None)} ({meta(con, 'letzte_art', '—')}, "
          f"{meta(con, 'letzte_dauer', '—')} s) · Rückblick {_dtz(int(meta(con, 'rueckblick_stand', '0') or 0) or None)} "
          f"({meta(con, 'rueckblick_dauer', '—')} s) · Nullverfahren {NULL_WAHL['verfahren']} ({NULL_WAHL['stand']})")
        for c in coins:
            r = con.execute("SELECT json FROM au_prognose WHERE coin=? ORDER BY anker DESC LIMIT 1", (c,)).fetchone()
            a("")
            if not r:
                a(f"== {c}: noch keine Rechnung"); continue
            E = json.loads(r[0])
            a(f"== {c} · Anker {_dtz(E.get('anker'))} · ab {_px(E.get('p0'))} ({E.get('p0_quelle')}) · Bibliothek "
              f"{(E.get('bibliothek') or {}).get('n')} Fenster ({(E.get('bibliothek') or {}).get('art')})")
            for s in E.get("lesart") or []:
                a(f"   {s}")
            for h in H_ZIEL:
                sp = (E.get("spannen") or {}).get(str(h))
                if sp:
                    q = sp["q"]
                    a(f"   {h:>2} T: 90 % {_px(q[0])}–{_px(q[6])} · 80 % {_px(q[1])}–{_px(q[5])} · 50 % {_px(q[2])}–{_px(q[4])} · Median {_px(q[3])}")
            nv = [n for n in E.get("niveaus") or [] if n.get("p")]
            if nv:
                a("   Ziellevels (Erreichen in 1/2/4 W · Schluss jenseits in 4 W):")
                for n in nv[:14]:
                    p_ = n["p"]
                    a(f"     {n['name'][:44]:<44} {_px(n['px']):>10} {_pr(n['abstand']):>9}  "
                      + " / ".join(f"{_de((p_.get(str(h)) or [0])[0] * 100, 0)} %" for h in H_ZIEL)
                      + f" · {_de((p_.get('28') or [0, 0])[1] * 100, 0)} %" + ("  (Momentaufnahme)" if n.get("momentaufnahme") else ""))
            s4 = E.get("bedingt_s4") or {}
            if E.get("bedingt"):
                a(f"   Szenarien mit dem S&P 500 -- {s4_satz(s4)}")
            for e in E.get("bedingt") or []:
                if e.get("art") == "punkt" and e.get("h") == 28:
                    m = e.get("methode"); qq = (e.get("bib") if m == "bibliothek" else e.get("kopula")) or {}
                    if qq.get("preis"):
                        a(f"   Wenn S&P 500 in 28 T {_pr(e['x'], 0)}: 80 % {_px(qq['preis'][1])}–{_px(qq['preis'][5])}, Median {_px(qq['preis'][3])} "
                          f"({m}, Episoden-ESS {_de(e.get('ess'), 1)})")
            st = E.get("stress")
            if st:
                a(stress_zeile(st))
            for f in E.get("fehlt") or []:
                a(f"   fehlt: {f}")
        R = rueckblick_lesen(con)
    finally:
        con.close()
    if R:
        a("")
        a(rueckblick_text(R))
    return "\n".join(Z)


def rueckblick_text(R: dict) -> str:
    Z = []; a = Z.append
    a(f"RÜCKBLICK vom {_dtz(R.get('stand'))} ({_de(R.get('dauer'), 0)} s) · Coins {', '.join(R.get('coins') or [])} · ab {_dt(OOS_AB)} außerhalb der Stichprobe")
    nw = R.get("null_wahl") or {}
    a(f"Nullverfahren {nw.get('verfahren')} (α {nw.get('alpha')}, {nw.get('n')} Surrogate; Wahl: {nw.get('stand')})")
    a(f"Nachweisgrenze der Richtung (synthetische Märkte, eingepflanztes Wochenmomentum mit R² 2,8 %): {NACHWEIS['text']}")
    for f in R.get("fehlt") or []:
        a(f"  fehlt: {f}")
    a("")
    a("BREITE (HAR-X, QLIKE gegen das Grundmodell, Holm über X1–X4, beide Hälften)")
    for h, T in ((R.get("breite") or {}).get("h") or {}).items():
        teile = []
        for k in ("X1", "X2", "X3", "X4"):
            e = T.get(k) or {}
            teile.append(f"{k} {'—' if e.get('p') is None else 'Gewinn ' + _de(e.get('mittel'), 4) + ' p Holm ' + _de(e.get('p_holm'), 3)}"
                         + (" ✓" if e.get("besteht") else ""))
        a(f"  h {h:>2}: " + " · ".join(teile) + f" -> {'+'.join((R['breite'].get('wahl') or {}).get(h) or []) or 'Grundmodell'}")
    S1 = R.get("s1") or {}
    a("")
    a("S1 BREITE (B0 Bibliothek + HAR gegen B1 Normal 365 T; Deckung des 80-%-Bands je Coin)")
    for h, e in (S1.get("h") or {}).items():
        dk = e.get("deckung") or {}
        a(f"  {h:>2} T: CRPS B0 {_de(e.get('crps_b0'), 4)} gegen B1 {_de(e.get('crps_b1'), 4)} (Gewinn {_pr(e.get('gewinn_rel'))}, p {_de(e.get('p'), 3)}) · "
          + " · ".join(f"{c} {_de(d['d80'] * 100, 1)} % ± {_de(d['se'] * 100, 1)}" for c, d in dk.items()) + f" -> {'besteht' if e.get('besteht') else 'besteht nicht'}")
    for st, H in (S1.get("stunde") or {}).items():
        a(f"  Anker {st} UTC: " + " · ".join(f"{h} T {'besteht' if e.get('besteht') else 'nicht'} (p {_de(e.get('p'), 3)})" for h, e in H.items()))
    a("")
    a("S2 RICHTUNG (Tor: Clark-West und CRPS, Blockbootstrap, beide Hälften)")
    for g, T in (R.get("tor") or {}).items():
        for h, t in T.items():
            a(f"  {g:<6} {h:>2} T: {'OFFEN' if t.get('offen') else 'zu'} · CW p {_de((t.get('cw') or {}).get('p'), 3)} · CRPS p "
              f"{_de((t.get('crps') or {}).get('p'), 3)} · R²_OS {_de(t.get('r2_os'), 4)} ({_de(t.get('r2_lo'), 4)}…{_de(t.get('r2_hi'), 4)})"
              + (f" · {t.get('grund')}" if t.get("grund") else ""))
    a("")
    a("GEWICHTE (Krypto gepoolt; je Horizont: Gewicht, Beitrag ΔMSE, p, p Holm, Status)")
    RI = (R.get("richtung") or {}).get("krypto") or {}
    for k, fam, name in KANDIDATEN:
        zeile = f"  {k:<4} {name[:38]:<38}"
        for h in H_ZIEL:
            e = next((x for x in (RI.get(str(h)) or {}).get("kandidaten") or [] if x["key"] == k), None)
            if e is None:
                zeile += " |      —"; continue
            zeile += (f" | {_de(e.get('gewicht'), 3, True):>7} {_de((e.get('dmse') or float('nan')) * 1000, 2, True):>6}‰ p {_de(e.get('p'), 2):>4} "
                      f"{e.get('status', '')[:10]:<10}")
        a(zeile)
    S3 = R.get("s3") or {}
    a("")
    a("S3 ZIELLEVELS (Montage ab 2022, Prüfniveaus, Swing-Niveaus, runde Zahlen)")
    for h, e in (S3.get("h") or {}).items():
        a(f"  {h:>2} T: n {e.get('n')} · Brier {_de(e.get('brier_b0'), 4)} gegen B1 {_de(e.get('brier_b1'), 4)} (Skill {_pr(e.get('skill'))}) · Steigung "
          f"{_de(e.get('steigung'), 2)} -> {'besteht' if e.get('besteht') else 'besteht nicht'}")
    S4 = R.get("s4") or {}
    a("")
    if S4.get("grund"):
        a(f"S4 GEMEINSAME FORM: nicht gerechnet ({S4['grund']})")
    else:
        v = S4.get("variogramm") or {}
        a(f"S4 GEMEINSAME FORM (BTC, S&P): Variogramm-Gewinn {_de(v.get('mittel'), 4)} p {_de(v.get('p'), 3)} Hälften {_de(v.get('h1'), 4)}/{_de(v.get('h2'), 4)} -> "
          f"{'Abhängigkeit im Rückblick belegt' if S4.get('besteht') else 'nicht belegt'} (n {S4.get('n')})")
        for h, e in (S4.get("rosenblatt") or {}).items():
            a(f"  Rosenblatt-PIT {h} T: insgesamt p {_de((e.get('alle') or {}).get('p'), 3)} · unter Aktienstress p {_de((e.get('stress') or {}).get('p'), 3)}"
              f" · Deckung 80 % Stress/Mitte/Hoch {_de(((S4.get('deckung') or {}).get(h) or {}).get('stress'), 2)}/"
              f"{_de(((S4.get('deckung') or {}).get(h) or {}).get('mitte'), 2)}/{_de(((S4.get('deckung') or {}).get(h) or {}).get('hoch'), 2)}")
    VB = R.get("vorwaerts") or {}
    if VB and not VB.get("fehler"):
        a("")
        a("VORWÄRTSBILANZ (an den 6-h-Ankern gespeichert, nach h Tagen ausgewertet)")
        for h, b in VB.items():
            a(f"  {h:>2} T: n {b['n']}{'' if b.get('genug') else ' (noch zu wenige Fälle)'} · Deckung 50/80/90 {_de(b['deckung']['50'] * 100, 0)}/"
              f"{_de(b['deckung']['80'] * 100, 0)}/{_de(b['deckung']['90'] * 100, 0)} % · CRPS {_de(b['crps'], 4)} gegen B1 {_de(b.get('crps_b1'), 4)}")
    return "\n".join(Z)


# ================================================================================================ Null-Universen (13.6) und Positivkontrolle

def _universum(seed: int, n_tage: int = 2450, coins: int = 5, p_rausch: int = 6, phis=(0.9, 0.97, 0.99, 0.995), effekt: float = 0.0,
               h: int = 7, gleich: float = 0.6) -> dict:
    """
    Synthetischer Markt für die Richtungsprüfung: Tagesrenditen (gemeinsamer Faktor, Gleichlauf gleich), Ziel y = normierte Rendite
    der folgenden h Tage (überlappend), zähe Rausch-Kandidaten AR(1) mit φ aus phis (teils marktweit), dazu p_rausch unabhängige.
    effekt > 0 pflanzt m = effekt · P1 ein (P1 = Wochenmomentum, normiert), wie die Positivkontrolle in 8 Punkt 5.
    """
    rng = np.random.default_rng(seed)
    d0 = OOS_AB // TAG - 2 * 365
    f = rng.normal(size=n_tage + h + 10)
    tg, X, y, ci = [], [], [], []
    namen = [f"Z{i}" for i in range(len(phis) + 2 + p_rausch)]
    for c in range(coins):
        e = math.sqrt(gleich) * f + math.sqrt(1 - gleich) * rng.normal(size=len(f))
        cols = []
        for k, ph in enumerate(phis):
            x = np.zeros(n_tage)
            for t in range(1, n_tage):
                x[t] = ph * x[t - 1] + rng.normal() * math.sqrt(1 - ph * ph)
            cols.append(x)
        for ph in (0.99, 0.995):                                          # marktweit (gleich für alle Coins)
            rr = np.random.default_rng(seed * 1000 + int(ph * 1000))
            x = np.zeros(n_tage)
            for t in range(1, n_tage):
                x[t] = ph * x[t - 1] + rr.normal() * math.sqrt(1 - ph * ph)
            cols.append(x)
        for _ in range(p_rausch):
            cols.append(rng.normal(size=n_tage))
        p1 = np.convolve(e, np.ones(7), "full")[:len(e)] / math.sqrt(7)       # Wochenmomentum (bis d), normiert
        Xc = np.column_stack(cols)
        if effekt > 0:
            Xc[:, 0] = p1[:n_tage]
        mu = effekt * Xc[:, 0] if effekt > 0 else np.zeros(n_tage)
        z = np.array([np.sum(e[t + 1:t + h + 1]) / math.sqrt(h) for t in range(n_tage)]) + mu * 1.0
        tg.append(d0 + np.arange(n_tage)); X.append(Xc); y.append(z); ci.append(np.full(n_tage, c))
    Xa = np.vstack(X)
    Z, _ = standardisieren(Xa)                                            # wie echt (rollierend; je Coin wäre genauer -- hier reicht gepoolt)
    return {"coins": [f"C{c}" for c in range(coins)], "namen": namen, "tag": np.concatenate(tg), "X": Z, "y": np.concatenate(y),
            "ci": np.concatenate(ci), "idx": list(range(len(namen)))}


def _pruefe_universum(RGd: dict, h: int, n_null: int, verfahren: str, seed: int) -> dict:
    """Gewichte (wie gewichte_pruefen, mit eigenen Namen) und Tor über die Normalnäherung der Bibliothek (y ist normiert)."""
    import types
    R = Ridge(RGd["tag"], RGd["X"], RGd["y"], h)
    ab = OOS_AB // TAG
    W = R.walk(ab); lams = [r[1] for r in W["refits"]]
    y, tag = RGd["y"], RGd["tag"]; oos = tag >= ab
    mse_m = mse_oos(y, W["mhat"], oos)
    ps = []
    for j in range(R.p):
        keep = np.array([i for i in range(R.p) if i != j])
        mse_o = mse_oos(y, R.walk(ab, lams=lams, keep=keep)["mhat"], oos)
        nz = null_p(R, RGd, j, mse_o - mse_m, mse_o, oos, ab, lams, verfahren, seed + j, n_null)
        ps.append(nz.get("p", 1.0))
    m = oos & np.isfinite(W["mhat"])
    U = {"h": np.full(int(m.sum()), h), "stunde": np.zeros(int(m.sum()), dtype=int), "coin": RGd["ci"][m].astype(str),
         "tau": (tag[m] + 1) * TAG, "y": y[m], "mhat": W["mhat"][m],
         "b0": crps_normal(0.0, 1.0, y[m]), "m": crps_normal(W["mhat"][m], 1.0, y[m])}
    t_ = tor_rechnen(U, list(np.unique(U["coin"])), h, seed)
    ph = holm(ps)
    return {"p": ps, "p_holm": ph, "tor": bool(t_.get("offen")), "r2": t_.get("r2_os")}


def null_kalibrierung(n_universen: int = 100, n_null: int = NULL_K, log=None, horizonte=(7, 28)) -> dict:
    """
    13.6: Fehlurteilsrate (p < 0,05 je Kandidat) beider Nullverfahren auf Null-Universen mit zähen Kandidaten (φ bis 0,995).
    Regel: das Verfahren mit der Rate am nächsten an 5 % und höchstens 6 %; liegen beide darüber, Phasen-Randomisierung mit α = 0,025.
    """
    log = log or (lambda *a: None)
    zaehl = {v: [0, 0] for v in ("verschiebung", "phase")}
    tore = 0; t0 = time.time()
    for u in range(n_universen):
        for h in horizonte:
            RGd = _universum(9000 + u, h=h)
            for v in zaehl:
                r = _pruefe_universum(RGd, h, n_null, v, seed=u * 31 + h)
                zaehl[v][0] += sum(1 for p in r["p"][:6] if p < 0.05); zaehl[v][1] += 6        # die zähen Kandidaten
                if v == "phase":
                    tore += int(r["tor"])
        if (u + 1) % 10 == 0:
            log(f"  {u + 1} Universen: " + ", ".join(f"{v} {z[0] / max(z[1], 1) * 100:.1f} %" for v, z in zaehl.items())
                + f" · {time.time() - t0:.0f} s")
    raten = {v: z[0] / max(z[1], 1) for v, z in zaehl.items()}
    ok = {v: r for v, r in raten.items() if r <= 0.06}
    if ok:
        wahl, alpha = min(ok, key=lambda v: abs(ok[v] - 0.05)), 0.05
    else:
        wahl, alpha = "phase", 0.025
    return {"raten": raten, "n_tests": {v: z[1] for v, z in zaehl.items()}, "wahl": wahl, "alpha": alpha, "tore_offen": tore,
            "tore_n": n_universen * len(horizonte), "dauer": time.time() - t0}


def nachweisgrenze(effekte=(0.17, 0.25, 0.35, 0.5), n_universen: int = 10, n_null: int = NULL_K, log=None, h: int = 7) -> dict:
    """
    8 Punkt 5 (Nachtrag 11.10.): Trefferquote der Richtungsprüfung je eingepflanzter Stärke m = e·P1 (R² = e²/(1+e²)) auf den
    Märkten der Positivkontrolle -- Tor offen, P1 „trägt“, andere „tragen“, R²_OS gegen das Orakel (wahres m). Erreicht e = 0,17
    (R² ≈ 3 %, Wochenmomentum der Literatur) die 80 % nicht, ist die gemessene Kurve die ehrliche Nachweisgrenze.
    """
    log = log or (lambda *a: None)
    out = {}
    for e in effekte:
        z = {"tor": 0, "p1": 0, "andere": 0, "n_andere": 0, "r2": [], "r2_orakel": []}
        t0 = time.time()
        for u in range(n_universen):
            RGd = _universum(700 + u, h=h, effekt=e)
            r = _pruefe_universum(RGd, h, n_null, NULL_WAHL["verfahren"], seed=u)
            z["tor"] += int(r["tor"]); z["p1"] += int(r["p_holm"][0] < NULL_WAHL.get("alpha", 0.05))
            z["andere"] += sum(1 for ph in r["p_holm"][1:] if ph < NULL_WAHL.get("alpha", 0.05)); z["n_andere"] += len(r["p_holm"]) - 1
            z["r2"].append(r["r2"])
            y, tag = RGd["y"], RGd["tag"]; oos = tag >= OOS_AB // TAG
            z["r2_orakel"].append(float(1 - np.sum((y[oos] - e * RGd["X"][oos, 0]) ** 2) / np.sum(y[oos] ** 2)))
        out[str(e)] = dict(z, n=n_universen, r2_wahr=e * e / (1 + e * e), dauer=time.time() - t0)
        log(f"  m = {e}·P1 (R² {e * e / (1 + e * e) * 100:.1f} %): Tor {z['tor']}/{n_universen}, P1 trägt {z['p1']}/{n_universen}, andere "
            f"{z['andere']}/{z['n_andere']} · R²_OS {np.mean(z['r2']) * 100:.2f} % gegen Orakel {np.mean(z['r2_orakel']) * 100:.2f} % · "
            f"{time.time() - t0:.0f} s")
    return out


# ================================================================================================ Selbsttest (ohne Netz)

def _demo_aktien(pfad: str, jetzt: int, seed: int = 3, ab: str = "2016-01-04") -> None:
    """
    Synthetische aktien.db für Selbsttest und Bildschirmfotos: FRED-artige Tagesreihen an NYSE-Handelstagen (Zeitstempel = Datum
    00:00 UTC wie im Archiv) -- S&P 500 mit Trend und Schwankungsregime, Nasdaq-100 (ρ 0,9), VIX und VIX3M aus der wahren
    Schwankung, Baa − 10 J, STLFSI4 freitags.
    """
    import hl_aktien as AK
    rng = np.random.default_rng(seed)
    d = date.fromisoformat(ab); bis = datetime.fromtimestamp(int(jetzt), timezone.utc).date()
    tage = []
    while d <= bis:
        if AK.handelstag(d):
            tage.append(d)
        d += timedelta(days=1)
    n = len(tage)
    u = np.zeros(n)
    for i in range(1, n):
        u[i] = 0.985 * u[i - 1] + rng.normal(0, 0.12)
    sig = 0.0095 * np.exp(u - 0.5 * 0.12 ** 2 / (1 - 0.985 ** 2))
    z = rng.standard_normal(n)
    r_sp = 0.0004 + sig * z
    r_nd = 0.0005 + 1.25 * sig * (0.9 * z + math.sqrt(1 - 0.81) * rng.standard_normal(n))
    sp = 2000.0 * np.exp(np.cumsum(r_sp)); nd = 4400.0 * np.exp(np.cumsum(r_nd))
    vix = 100 * math.sqrt(252) * sig * np.exp(rng.normal(0, 0.05, n)) * 1.1
    v3 = vix * np.exp(0.06 - 0.25 * (u - u.mean()) + rng.normal(0, 0.03, n))
    baa = 2.0 + np.cumsum(rng.normal(0, 0.01, n)) + 2.0 * (sig - sig.mean())
    ts = [AK.tag_ts(x.isoformat()) for x in tage]
    zeilen = []
    for name, w in (("fred:SP500", sp), ("fred:NASDAQ100", nd), ("fred:VIXCLS", vix), ("fred:VXVCLS", v3), ("fred:BAA10Y", baa)):
        zeilen += [(name, t, float(x)) for t, x in zip(ts, w)]
    st = 0.0
    for t, x in zip(tage, sig):
        if x and t.weekday() == 4:
            st = 0.9 * st + 80 * (x - 0.0095) + rng.normal(0, 0.1)
            zeilen.append(("fred:STLFSI4", AK.tag_ts(t.isoformat()), float(st)))
    con = AK.verbinden(pfad)
    try:
        AK.archivieren(con, zeilen, abgerufen=int(jetzt) - 3600)
    finally:
        con.close()


def _demo_umgebung(verz: str, jetzt: int, tage: int = 1100, kurz: dict | None = None) -> dict:
    """Synthetische Datenbanken wie auf dem Pi (hl_chartbild._demo_dbs) und aktien.db daneben; setzt die Umgebungsvariablen der Module
    auf diese Dateien. -> Pfade und die alten Umgebungswerte (für _demo_ende)."""
    import hl_chartbild as CB
    import hl_hebel as HB
    pf = CB._demo_dbs(verz, jetzt=jetzt, tage=tage, kurz=kurz)
    pf["aktien"] = os.path.join(verz, "aktien.db")
    _demo_aktien(pf["aktien"], jetzt)
    # Perp-Tageskerzen <COIN>USDT in hebel.db (wie die Binance-Tagesdateien: nur abgeschlossene Tage), damit hl_hebel Tafeln baut und
    # D3–D10 im Ende-zu-Ende-Lauf und in der Kausalitätsprobe wirklich vorkommen (11.10.: vorher ohne Tafel, D-Kandidaten leer)
    h_ = sqlite3.connect(pf["haupt"]); hb = HB.verbinden(pf["hebel"])
    try:
        heute = int(jetzt) // TAG
        for coin in HB.COINS:
            rows = h_.execute("SELECT ts, open, high, low, close FROM daily_bars WHERE coin=? AND ts < ? ORDER BY ts", (coin, heute * TAG)).fetchall()
            HB._schreiben(hb, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                          [("um", f"{coin}USDT", int(t) // TAG, float(o), float(hh), float(ll), float(c), 1.0, 1e9, 5e8, 1000)
                           for t, o, hh, ll, c in rows])
    finally:
        h_.close(); hb.close()
    alt = CB._mit_umgebung(pf)
    for k in ("HL_AKTIEN_DB", "HL_AUSBLICK_DB"):
        alt[k] = os.environ.pop(k, None)
    return {"pf": pf, "alt": alt}


def _demo_ende(U: dict) -> None:
    import hl_chartbild as CB
    CB._zurueck(U["alt"])


def _demo_abschneiden(quelle: str, ziel: str, tau: int) -> dict:
    """Kopie der Demo-Datenbanken, in der nichts ab τ existiert (Kerzen ab τ, Funding, Positionierung, Makro, Aktien nach τ,
    Tageskerzen -- auch die Perp-Tageskerzen in hebel.db -- ab dem Tag von τ) -- für die Probe „Prognose aus der abgeschnittenen
    Datenbank = Prognose für τ im vollen Lauf“."""
    import shutil
    shutil.rmtree(ziel, ignore_errors=True)
    shutil.copytree(quelle, ziel)
    tau = int(tau)
    for f, sqls in (("swing.db", (("DELETE FROM sw_klines WHERE ts >= ?", tau), ("DELETE FROM sw_funding WHERE ts >= ?", tau))),
                    ("regime.db", (("DELETE FROM rg_klines WHERE ts >= ?", tau),)),
                    ("hebel.db", (("DELETE FROM hb_metrics WHERE ts >= ?", tau), ("DELETE FROM hb_kerzen WHERE tag >= ?", tau // TAG))),
                    ("makro.db", (("DELETE FROM mk_reihe WHERE ts >= ?", tau),)),
                    ("aktien.db", (("DELETE FROM ak_aktuell WHERE ts > ?", tau), ("DELETE FROM ak_wert WHERE ts > ?", tau))),
                    ("hl_liq.db", (("DELETE FROM daily_bars WHERE ts >= ?", tau // TAG * TAG), ("DELETE FROM bars WHERE ts >= ?", tau)))):
        p = os.path.join(ziel, f)
        if not os.path.exists(p):
            continue
        con = sqlite3.connect(p)
        try:
            for q, wert in sqls:
                con.execute(q, (wert,))
            con.commit()
        finally:
            con.close()
    return {k: os.path.join(ziel, os.path.basename(v)) for k, v in
            {"haupt": "hl_liq.db", "swing": "swing.db", "regime": "regime.db", "hebel": "hebel.db", "makro": "makro.db", "aktien": "aktien.db"}.items()}


def _asyn(rng) -> tuple:
    """Synthetische 6-h-Anker mit latenter Schwankung (log-AR(1), 900 Tage) für HAR-X- und Embargo-Proben -> (Anker, latente Reihe)."""
    n_a = 4 * 900
    lat = np.zeros(n_a // 4)
    for d in range(1, len(lat)):
        lat[d] = 0.97 * lat[d - 1] + rng.normal(0, 0.15)
    rv_tag = 0.0009 * np.exp(lat + rng.normal(0, 0.35, len(lat)))
    A = {"tau": OOS_AB - 400 * TAG + np.arange(n_a) * ANKER_S, "stunde": np.tile([0, 6, 12, 18], n_a // 4), "n": n_a}
    A["RV"] = np.repeat(rv_tag, 4) * np.exp(rng.normal(0, 0.05, n_a))
    return A, lat


def _gauss_bib(N: int, seed: int, schritte: int = 48, drift: float = 0.0) -> dict:
    """Bibliothek aus normierter Brownscher Bewegung (Tagesvarianz 1, F(s,k) = k): Schluss, Hoch und Tief je 24-h-Block aus
    schritte Teilschritten. drift: eingepflanzter Trend je Tag (in Einheiten der Tagesschwankung)."""
    rng = np.random.default_rng(seed)
    out = {"Z": np.empty((N, K_MAX), np.float32), "ZH": np.empty((N, K_MAX), np.float32), "ZL": np.empty((N, K_MAX), np.float32)}
    for a in range(0, N, 2000):
        n = min(2000, N - a)
        W = np.cumsum(rng.normal(0, 1 / math.sqrt(schritte), (n, K_MAX * schritte)) + drift / schritte, axis=1)
        B = W.reshape(n, K_MAX, schritte)
        sq = np.sqrt(np.arange(1, K_MAX + 1))
        out["Z"][a:a + n] = B[:, :, -1] / sq
        out["ZH"][a:a + n] = np.maximum(B.max(axis=2), np.concatenate([np.zeros((n, 1)), B[:, :-1, -1]], axis=1)) / sq
        out["ZL"][a:a + n] = np.minimum(B.min(axis=2), np.concatenate([np.zeros((n, 1)), B[:, :-1, -1]], axis=1)) / sq
    out["start"] = np.arange(N, dtype=np.int64) * ANKER_S
    out["ende"] = out["start"] + K_MAX * TAG
    out["coin"] = np.full(N, "T", dtype="<U5")
    return out


SELBSTTEST_GRUPPEN = ("basis", "pfad", "breite", "null", "pk", "kopula", "harx", "kausal", "schock", "takt", "e2e")


def selbsttest(verbose: bool = True, nur: set | None = None) -> bool:
    """
    Selbsttest ohne Netz (8, 13.9). nur: Gruppen (basis, pfad, breite, null, pk, kopula, harx, kausal, schock, takt, e2e) -- für schnelle
    Wiederholungen und die Mutationsläufe; ohne Angabe alle.
    """
    import tempfile
    import shutil
    import hl_regime as RG
    ok_all = [True]; t_start = time.time()

    def _an(gruppe: str) -> bool:
        return nur is None or gruppe in nur

    def ok(name, bed, detail=""):
        ok_all[0] &= bool(bed)
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f" — {detail}" if detail else ""), flush=True)

    if verbose:
        print("Ausblick 4 Wochen (U146) -- Selbsttest: Pfadstatistik, Trend, Breite, Null-Universen, Positivkontrolle, Kausalität, "
              "gleich der Studien, gemeinsame Bibliothek, Kopula, HAR-X, Schockregel, Takt, Ende zu Ende", flush=True)
    if _an('basis'):
        # ------------------------------------------------------------------ 0) Spezialfunktionen gegen Werte von Hand
        ok("Spezialfunktionen: Φ⁻¹(0,975) = 1,959964, t₅-Verteilung (0,9 -> 1,475884), χ²₄ (P > 9,4877 = 0,05), CRPS N(0,1) bei 0 = 0,233695",
           abs(float(norm_ppf(np.array([0.975]))[0]) - 1.959964) < 1e-6 and abs(float(t_ppf(np.array([0.9]), 5)[0]) - 1.475884) < 1e-5
           and abs(chi2_sf(9.4877, 4) - 0.05) < 1e-4 and abs(float(crps_normal(0, 1, np.array([0.0]))[0]) - 0.233695) < 1e-6
           and abs(float(crps_ens(np.array([0.0, 1.0]), np.array([0.5]))[0]) - 0.25) < 1e-12)
        pp_ = np.concatenate([10.0 ** -np.arange(12, 1, -0.5), np.linspace(0.02, 0.98, 97)]); pp_ = np.concatenate([pp_, 1 - pp_[::-1]])
        rt_ = float(np.max(np.abs(norm_cdf(norm_ppf(pp_)) - pp_) / np.minimum(pp_, 1 - pp_)))
        ok("Normalquantil genau: Φ(Φ⁻¹(p)) = p relativ auf 1e-12 für p von 10⁻¹² bis 1 − 10⁻¹² (Acklam mit Halley-Schritt)", rt_ < 1e-12, f"{rt_:.1e}")
        xt_ = np.linspace(-30, 30, 4001)
        abw_t = max(float(np.max(np.abs(t_cdf(xt_, nu_) - _t_cdf_beta(xt_, nu_)))) for nu_ in (1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 20, 21, 50, 51))
        ok("t-Verteilung geschlossen (ganzzahlige ν, A&S 26.7.3/4) = unvollständige Betafunktion (ν 1–51, |x| ≤ 30)", abw_t < 1e-11, f"{abw_t:.1e}")
        # 23.67: Wertung der Deckung (5.5) und Stand von S4 mit dem Hinweis zur Kalibrierung unter Aktienstress
        dw = [deckung_wertung({"d80": 0.57, "se": 0.05, "ok": False}), deckung_wertung({"d80": 0.84, "se": 0.016, "ok": False}),
              deckung_wertung({"d80": 0.81, "se": 0.03, "ok": True}), deckung_wertung(None)]
        s4a = s4_satz({"besteht": True, "p": 0.002, "pit_stress": {"7": 0.017, "14": 0.3, "28": 0.001}})
        s4b = s4_satz({"besteht": False, "p": 0.4, "pit_stress": {"7": 0.2}}); s4c = s4_satz({})
        stz = stress_zeile({"zeitraum": [int(datetime(2020, 2, 24, tzinfo=timezone.utc).timestamp()),
                                         int(datetime(2021, 2, 23, tzinfo=timezone.utc).timestamp())],
                            "spannen": {"28": {"q": [50000, 55000, 60000, 65000, 70000, 75000, 80000]}}})
        ok("Deckung am Fächer: außerhalb 80 % ± 2 SE „zu eng“ bzw. „zu weit“, sonst nichts; S4-Satz nennt Stand und, nur bei PIT p < 0,05 "
           "unter Aktienstress, den Hinweis je Horizont",
           dw == [" -- zu eng (Soll 80 %)", " -- zu weit (Soll 80 %)", "", ""] and s4a.startswith("Abhängigkeit im Rückblick belegt (p 0,002)")
           and "nicht kalibriert (PIT p 0,017 bei 7 T, PIT p 0,001 bei 28 T)" in s4a and "14 T" not in s4a
           and s4b == "Abhängigkeit im Rückblick nicht belegt (p 0,400)." and "noch nicht geprüft" in s4c
           and "Form der unruhigsten Phase seit 2020 (24.02.2020–23.02.2021) bei heutiger Schwankung: 28 T 80 % 55.000–75.000 · 90 % 50.000–80.000"
           in stz,
           f"{dw} | {s4a} | {s4b} | {stz.strip()}")
        S1_bsp = {"h": {"28": {"deckung": {"PAXG": {"d80": 0.565, "se": 0.053, "ok": False}, "BTC": {"d80": 0.831, "se": 0.032, "ok": True}}},
                        "7": {"deckung": {"BTC": {"d80": 0.837, "se": 0.016, "ok": False}}}}}
        tmp_rb = tempfile.mkdtemp(prefix="au_rbst_")
        try:
            con_rb = verbinden(os.path.join(tmp_rb, "ausblick.db"))
            meta_setzen(con_rb, {"s1": json.dumps({"deckung": {"PAXG": {"28": 0.565}}}), "s4_urteil": json.dumps({"besteht": True, "p": 0.002}),
                                 "rueckblick_stand": "1760000000"})
            con_rb.execute("INSERT INTO au_rueckblick VALUES (?,?,?)",
                           (1760000000, 300.0, json.dumps({"s1": S1_bsp, "s4": {"rosenblatt": {"7": {"stress": {"p": 0.017}}, "28": {"stress": {"p": 0.001}}}}})))
            con_rb.commit()
            RS = _rueckblick_stand(con_rb); con_rb.close()
        finally:
            shutil.rmtree(tmp_rb, ignore_errors=True)
        ok("Rückblick vor 23.67: Prüfgrößen (Deckung mit SE und Urteil je Coin, PIT unter Aktienstress) aus dem gespeicherten vollen Rückblick ergänzt",
           ((RS.get("s1") or {}).get("pruef") or {}).get("PAXG", {}).get("28", {}).get("ok") is False
           and ((RS.get("s1") or {}).get("pruef") or {}).get("BTC", {}).get("7", {}).get("se") == 0.016
           and (RS.get("s4_urteil") or {}).get("pit_stress") == {"7": 0.017, "28": 0.001}, f"{RS.get('s1')} {RS.get('s4_urteil')}")
        E_l = {"coin": "BTC", "richtung": {}, "niveaus": [], "sigma_tag": 0.02,
               "spannen": {"28": {"q": [50000, 55000, 60000, 65000, 70000, 75000, 80000], "pct": [-0.2, -0.15, -0.08, 0.0, 0.08, 0.15, 0.2]}}}
        L_eng = lesart(E_l, {"stand": 1760000000, "s1": {"deckung": {"BTC": {"28": 0.57}},
                                                        "pruef": {"BTC": {"28": {"d80": 0.57, "se": 0.05, "ok": False}}}}})
        L_gut = lesart(E_l, {"stand": 1760000000, "s1": {"deckung": {"BTC": {"28": 0.81}},
                                                        "pruef": {"BTC": {"28": {"d80": 0.81, "se": 0.03, "ok": True}}}}})
        ok("Lesart: Deckung im Rückblick mit Wertung am Fächer („57 % -- zu eng (Soll 80 %)“), in der Spanne ohne Zusatz",
           "Im Rückblick traf das 80-%-Band 57 % -- zu eng (Soll 80 %)." in L_eng[0] and "Im Rückblick traf das 80-%-Band 81 %." in L_gut[0],
           L_eng[0][-62:])
        Fst = {1: 0.0004, 7: 0.0035, 14: 0.0063, 28: 0.0140}
        Fp1 = F_pfad(Fst); Fpm = F_pfad({h: np.array([Fst[h], 2 * Fst[h]]) for h in H_STUETZ})
        soll10 = 10 * math.exp((4 / 7) * math.log(Fst[7] / 7) + (3 / 7) * math.log(Fst[14] / 14))
        ok("F-Pfad: an den Stützstellen 1/7/14/28 genau F, dazwischen ln(F/k) linear in k (F(τ,10) von Hand); Einzel- und Matrixweg gleich",
           all(abs(Fp1[h - 1] - Fst[h]) < 1e-15 for h in H_STUETZ) and abs(Fp1[9] - soll10) < 1e-15
           and np.max(np.abs(Fpm[0] - Fp1)) < 1e-15 and np.max(np.abs(Fpm[1] - 2 * Fp1)) < 1e-15, f"F(τ,10) {Fp1[9]:.6f}")
        # Surrogate beider Nullverfahren mechanisch (unabhängig von der Wahl): Verschiebung = derselbe Versatz für alle Coins um
        # 365 … L−365 Tage; Phasen = dieselben Phasen für alle Coins (Betragsspektrum je Coin und Kreuzspektrum bleiben)
        rgs = np.random.default_rng(77); Ls = 1200
        fs_ = np.cumsum(rgs.normal(size=Ls)) * 0.1 + rgs.normal(size=Ls)
        Ms_ = np.vstack([fs_ + 0.5 * rgs.normal(size=Ls) for _ in range(3)])
        tg_s = np.tile(np.arange(Ls), 3) + 20000; ci_s = np.repeat(np.arange(3), Ls)
        RGs = {"coins": ["A", "B", "C"], "tag": tg_s, "ci": ci_s, "X": Ms_.reshape(-1)[:, None]}
        sv_ = surrogate(RGs, 0, "verschiebung", 5, seed=3)
        ok_v = len(sv_) == 5
        for x_ in sv_:
            Mx = x_.reshape(3, Ls)
            treffer = [k for k in range(365, Ls - 365 + 1) if np.array_equal(Mx, np.roll(Ms_, k, axis=1))]
            ok_v &= len(treffer) == 1
        sp_ = surrogate(RGs, 0, "phase", 5, seed=3)
        F0s = np.fft.rfft(Ms_, axis=1); ok_p = len(sp_) == 5
        for x_ in sp_:
            Fx = np.fft.rfft(x_.reshape(3, Ls), axis=1)
            ok_p &= np.allclose(np.abs(Fx), np.abs(F0s), rtol=1e-9, atol=1e-9)
            ok_p &= np.allclose(Fx[0] * np.conj(Fx[1]), F0s[0] * np.conj(F0s[1]), rtol=1e-9, atol=1e-6)
            ok_p &= not np.allclose(x_, Ms_.reshape(-1))
        ok("Surrogate beider Nullverfahren: Verschiebung um denselben Versatz (365 … L−365 Tage) für alle Coins; Phasen mit denselben Phasen "
           "für alle Coins (Betragsspektrum und Kreuzspektrum bleiben, die Reihe ändert sich)", ok_v and ok_p, f"Verschiebung {ok_v}, Phasen {ok_p}")
        ph_ = holm([0.01, 0.04, 0.03, 0.5])
        gq1 = gew_quantile(np.array([1.0, 2.0, 3.0, 4.0]), np.ones(4), [0.5])[0]
        gq2 = gew_quantile(np.array([3.0, 1.0, 2.0]), np.array([1.0, 1.0, 2.0]), [0.5, 0.125])
        ok("Holm von Hand (0,01/0,04/0,03/0,5 -> 0,04/0,09/0,09/0,5); gewichtete Quantile mit der Mittelpunktregel (Median von 1–4 = 2,5)",
           np.allclose(ph_, [0.04, 0.09, 0.09, 0.5], rtol=0, atol=1e-15) and abs(gq1 - 2.5) < 1e-15 and np.allclose(gq2, [2.0, 1.0], rtol=0, atol=1e-15),
           f"Holm {ph_}, Median {gq1}")
    if _an('pfad'):
        # ------------------------------------------------------------------ 1) Pfadstatistik von Hand (8 Punkt 1)
        N = 20000; sig = 0.03
        B = _gauss_bib(N, 1)
        Fk = sig * sig * np.arange(1, K_MAX + 1)
        S = szenarien(B, np.ones(N, dtype=bool), Fk)
        Q = faecher(S)
        soll_q = sig * np.sqrt(np.arange(1, K_MAX + 1))[:, None] * norm_ppf(np.array(QUANTILE))[None, :]
        se_q = sig * np.sqrt(28) * np.sqrt(0.05 * 0.95 / N) / 0.103
        ok("Pfadstatistik: Quantile des Schlusses je Tag = σ√k·Φ⁻¹(q) im Stichprobenfehler (Gauß-Bibliothek, 20.000 Fenster)",
           np.max(np.abs(Q - soll_q)) < 4 * se_q, f"größte Abweichung {np.max(np.abs(Q - soll_q)) / (sig * math.sqrt(28)):.4f} σ√28")
        fehler = []; mono = True; schl = True
        for h in H_ZIEL:
            alt = 1.0
            for k in (0.5, 1.0, 1.5, 2.0, 2.5):
                a = k * sig * math.sqrt(h)
                pe, ps = erreichen(S, a, h)
                soll = 2 * (1 - float(norm_cdf(np.array([(a + 0.5826 * sig * math.sqrt(1 / 48)) / (sig * math.sqrt(h))]))[0]))
                fehler.append(abs(pe - soll)); mono &= pe <= alt + 1e-12; alt = pe; schl &= pe >= ps
                pe2, ps2 = erreichen(S, -a, h); schl &= pe2 >= ps2
        ok("Pfadstatistik: Erreichen ≈ Spiegelungsprinzip 2·P(B_h ≥ a) mit Korrektur für 48 Teilschritte (Broadie-Glasserman-Kou); "
           "Erreichen ≥ Schluss jenseits; monoton in der Entfernung", max(fehler) < 0.012 and mono and schl, f"größte Abweichung {max(fehler):.4f}")
    if _an('pfad'):
        # ------------------------------------------------------------------ 2) Ohne Trend (8 Punkt 2)
        Bd = _gauss_bib(8000, 2, drift=0.3)
        Sd = szenarien(Bd, np.ones(8000, dtype=bool), Fk)
        med = np.median(Sd["r"], axis=0)
        ok("Ohne Trend: Bibliothek mit eingepflanzter Drift (0,3 σ je Tag) -- der Fächer bleibt um den Anker zentriert (Median ≈ 0)",
           np.max(np.abs(med)) < 0.05 * sig * math.sqrt(28) and abs(float(np.mean(Bd["Z"][:, -1]))) > 1.0,
           f"Median 28 T {med[-1] / (sig * math.sqrt(28)):+.4f} σ√28, Mittel der Rohpfade {float(np.mean(Bd['Z'][:, -1])):.2f}")
        mu = drift_pfad({7: 0.2}, Fk)
        S_mu = szenarien(B, np.ones(N, dtype=bool), Fk, mu)
        ok("Drift nur bei offenem Tor: μ(7) = m̂·√F(τ,7), danach zurück auf 0 bei geschlossenen Toren 14/28 (lineare Stützstellen)",
           abs(mu[6] - 0.2 * math.sqrt(Fk[6])) < 1e-12 and abs(mu[27]) < 1e-12 and abs(float(np.median(S_mu["r"][:, 6])) - mu[6]) < 0.05 * sig * math.sqrt(7))

    if _an('breite'):
        # ------------------------------------------------------------------ 3) Breite auf Märkten mit Schwankungsballung (8 Punkt 3)
        import hl_regime as RG
        deck = []; b1_ruhig = []; b1_unruhig = []; verh = {1: [], 7: []}
        for i in range(6):
            K = RG._markt(tage=900, seed=40 + i, sigma_tag=0.03, start=OOS_AB - 500 * TAG)
            A = anker_reihen(K)
            Ws = {h: har_walk(A, h) for h in H_STUETZ}
            for h in verh:
                mv = (A["tau"] >= OOS_AB) & np.isfinite(Ws[h]["F"]) & np.isfinite(Ws[h]["S"])
                verh[h].append(float(np.mean(Ws[h]["S"][mv] / Ws[h]["F"][mv])))
            Fk_ = F_pfad({h: Ws[h]["F"] for h in H_STUETZ})
            v = {"A": A, "Fk": Fk_, "B": bibliothek(A, Fk_, "S"), "D": tagesachse(A), "tage_hist": 900}
            U = ursprung_auswertung({"BTC": v}, {}, lambda *a: None)
            m = (U["h"] == 7) & (U["stunde"] == 0)
            hits = U["d80"][m]
            idx = stat_idx(len(hits), 14.0, 400, seed=i)
            deck.append((float(hits.mean()), float(hits[idx].mean(axis=1).std(ddof=1))))
            s365 = _sigma365_anker(A); j = np.nonzero((A["tau"] >= OOS_AB) & (A["stunde"] == 0))[0]
            j = j[j + 28 < A["n"]]
            y = np.log(A["C"][j + 28] / A["C"][j]); b1 = np.abs(y) <= 1.2816 * s365[j] * math.sqrt(7)
            fz = Fk_[j, 6]; q1, q2 = np.nanquantile(fz, [1 / 3, 2 / 3])
            b1_ruhig.append(float(np.mean(b1[fz <= q1]))); b1_unruhig.append(float(np.mean(b1[fz >= q2])))
        n_ok = sum(1 for d, se in deck if abs(d - 0.80) <= 2 * se)
        ok("Breite: B0 deckt 80 % ± 2 SE in mindestens 5 von 6 Märkten mit Schwankungsballung (t-Innovationen); B1 deckt in ruhigen "
           "Phasen zu viel, in unruhigen zu wenig", n_ok >= 5 and np.mean(b1_ruhig) > 0.85 and np.mean(b1_unruhig) < 0.78,
           f"B0 {[round(d, 3) for d, _ in deck]}, B1 ruhig {np.mean(b1_ruhig):.2f} / unruhig {np.mean(b1_unruhig):.2f}")
        Xh_ = har_regressoren(A)
        jj_ = [j_ for j_ in range(A["n"]) if np.all(np.isfinite(Xh_[j_]))][::37]
        abw_r = max(float(np.max(np.abs(regressoren_bei(A, int(A["tau"][j_])) - Xh_[j_]))) for j_ in jj_)
        ok("Regressoren am Anker aus dem 30-min-Raster (regressoren_bei, für die Prognose) = Regressoren der Schätzung (har_regressoren; "
           "auf 1e-9, Summen in anderer Reihenfolge)", abw_r < 1e-9 and len(jj_) > 50, f"{len(jj_)} Anker, größte Abweichung {abw_r:.1e}")
        v1_, v7_ = float(np.mean(verh[1])), float(np.mean(verh[7]))
        ok("Breite unverzerrt: Mittel realisierte Varianz ÷ Prognose über die 6 Märkte bei 1 und 7 Tagen in 0,95–1,05 (F = h·exp(Xβ + s²/2); "
           "ohne den Lognormal-Ausgleich s²/2 läge es um 1,1–1,2)", abs(v1_ - 1) < 0.05 and abs(v7_ - 1) < 0.05, f"1 T {v1_:.3f}, 7 T {v7_:.3f}")
        K_hl = RG._markt(tage=120, seed=91, sigma_tag=0.03, start=OOS_AB - 200 * TAG)
        A_hl = anker_reihen(K_hl)
        j_hl = A_hl["n"] - 9
        i_e = int((A_hl["tau"][j_hl] - BAR - A_hl["t0_kerze"]) // BAR)
        soll_h = float(np.max(np.maximum(K_hl["h"], K_hl["c"])[i_e - 47:i_e + 1])); soll_l = float(np.min(np.minimum(K_hl["l"], K_hl["c"])[i_e - 47:i_e + 1]))
        ok("Hoch und Tief je 24-h-Block aus den Hochs und Tiefs der 30-min-Kerzen (nicht aus den Schlüssen)",
           abs(A_hl["H"][j_hl] - soll_h) < 1e-9 * soll_h and abs(A_hl["L"][j_hl] - soll_l) < 1e-9 * soll_l
           and float(np.mean(A_hl["H"] > A_hl["C"])) > 0.99, f"Hoch {soll_h:.2f}, Schluss {A_hl['C'][j_hl]:.2f}")
    if _an('null'):
        # ------------------------------------------------------------------ 4) Null-Universen (8 Punkt 4, verkleinert) und 5) Positivkontrolle
        tore = 0; traegt = 0; n_t = 0
        for u in range(10):
            r = _pruefe_universum(_universum(500 + u, h=7), 7, 50, NULL_WAHL["verfahren"], seed=u)
            tore += int(r["tor"]); traegt += sum(1 for ph in r["p_holm"] if ph < 0.05); n_t += len(r["p_holm"])
        # Schranken: Tor je Markt höchstens 5 % -> P(≥ 3 von 10) ≈ 1 %; Holm hält die Familienrate je Markt bei 5 % -> „trägt“ in
        # höchstens 2 Märkten (P(≥ 3) ≈ 1 %). Bis 11.10. stand hier „höchstens 1“ -- bei exakter Rate 5 % in 9 % der Fälle verletzt
        # (Schwanzprüfung 11.10.: 2 von 30 neuen Märkten mit „trägt“, bei beiden Verfahren; KONZEPT_Ausblick.md 12.1)
        ok("Null-Universen (10 Märkte, zähe Kandidaten bis φ 0,995): Tor öffnet höchstens 2-mal, „trägt“ (Holm) höchstens 2-mal von 120",
           tore <= 2 and traegt <= 2, f"Tor {tore} von 10, trägt {traegt} von {n_t}")
    if _an('pk'):
        # ------------------------------------------------------------------ 5) Positivkontrolle (8 Punkt 5)
        tore = 0; p1 = 0; andere = 0; r2 = []
        for u in range(5):
            r = _pruefe_universum(_universum(700 + u, h=7, effekt=PK_STARK), 7, 100, NULL_WAHL["verfahren"], seed=u)
            tore += int(r["tor"]); p1 += int(r["p_holm"][0] < 0.05); andere += sum(1 for ph in r["p_holm"][1:] if ph < 0.05); r2.append(r["r2"])
        ok(f"Positivkontrolle (m = {_de(PK_STARK, 2)}·P1, R² {_de(PK_STARK ** 2 / (1 + PK_STARK ** 2) * 100, 1)} % bei 7 Tagen): Tor offen und P1 „trägt“ "
           f"in mindestens 4 von 5 Märkten, die übrigen höchstens 2 von 55 (Nachweisgrenze bei R² 3 %: {NACHWEIS['text']})",
           tore >= 4 and p1 >= 4 and andere <= 2, f"Tor {tore}/5, P1 {p1}/5, andere {andere}/55, R²_OS {[round(x, 3) for x in r2]}")
    if _an('kopula'):
        # ------------------------------------------------------------------ 13.9: gemeinsame Bibliothek, Kopula, Episoden, Variogramm
        rng = np.random.default_rng(13)
        nf, rho_w, nu_w = 10000, 0.4, 5
        z1 = rng.standard_normal(nf); z2 = rho_w * z1 + math.sqrt(1 - rho_w ** 2) * rng.standard_normal(nf)
        g = np.sqrt(rng.chisquare(nu_w, nf) / nu_w)
        bS, bB = z1 / g, z2 / g                                        # bivariates t (elliptisch): S und B mit ρ, ν = 5
        sd_s = math.sqrt(nu_w / (nu_w - 2))
        starts = np.arange(nf, dtype=np.int64) * 40 * TAG              # weit auseinander: jede ein eigenes Episode
        abw = []; in_se = []
        qs_ = np.array(QUANTILE)

        def _bed_wahr(rho_, s_st_):
            skal_ = math.sqrt((nu_w + s_st_ ** 2) * (1 - rho_ ** 2) / (nu_w + 1))
            w_ = rho_ * s_st_ + skal_ * t_ppf(qs_, nu_w + 1)
            dichte = np.exp(t_logpdf((w_ - rho_ * s_st_) / skal_, nu_w + 1)) / skal_
            return w_, dichte

        for k_ in (2.0, 2.5):
            s_st = -k_ * sd_s
            e = bedingt(bB, bS, starts, s_st, sd_s, 28)
            wahr, dichte = _bed_wahr(rho_w, s_st)
            se_q = np.sqrt(qs_ * (1 - qs_) / e["kish"]) / dichte                  # Stichprobenfehler des Quantils (Kish-ESS)
            d_ = np.array(e["bib"]["q"]) - wahr
            abw.append(float(np.max(np.abs(d_[1:6])) / sd_s)); in_se.append(float(np.max(np.abs(d_[1:6] / se_q[1:6]))))
        ok("Gemeinsame Bibliothek (t-Kopula ρ 0,4, ν 5, 10⁴ Fenster): bedingte Quantile 10–90 % bei s* = −2σ und −2,5σ wie die wahre "
           "bedingte Verteilung im Stichprobenfehler (je Quantil ≤ 3 SE aus der Kish-ESS)", max(in_se) <= 3.0,
           f"größte Abweichung {[round(x, 2) for x in in_se]} SE ({[round(x, 3) for x in abw]} σ)")
        # Kern mit lokal-linearer Korrektur: bei starker Abhängigkeit verschiebt das Kernfenster den Median ohne Korrektur
        rng8 = np.random.default_rng(22)
        y1 = rng8.standard_normal(nf); y2 = 0.8 * y1 + 0.6 * rng8.standard_normal(nf)
        g8 = np.sqrt(rng8.chisquare(nu_w, nf) / nu_w)
        s8, b8 = y1 / g8, y2 / g8
        s_st8 = -2.0 * sd_s
        e8 = bedingt(b8, s8, starts, s_st8, sd_s, 28)
        w8 = np.exp(-0.5 * ((s8 - s_st8) / (KERN_LAMBDA * sd_s)) ** 2)
        roh8 = gew_quantile(b8, w8, QUANTILE)
        wahr8, dichte8 = _bed_wahr(0.8, s_st8)
        se8 = math.sqrt(0.25 / e8["kish"]) / dichte8[3]
        d_korr, d_roh = (e8["bib"]["q"][3] - wahr8[3]) / se8, (roh8[3] - wahr8[3]) / se8
        ok("Kern mit lokal-linearer Korrektur (ρ 0,8, s* = −2σ): bedingter Median im Stichprobenfehler (≤ 3 SE); ohne Korrektur läge er "
           "deutlich daneben (> 3 SE)", abs(d_korr) <= 3.0 and abs(d_roh) > 3.0, f"mit Korrektur {d_korr:+.2f} SE, ohne {d_roh:+.2f} SE")
        w_ = np.array([1.0, 1.0, 0.5, 0.5, 2.0]); st_ = np.array([0, 3, 40, 42, 100]) * TAG
        ess_, anteil_, n_ep = episoden_ess(st_, w_, 28)
        ok("Episoden-ESS von Hand: Starts 0/3, 40/42, 100 Tage bei h = 28 -> Episoden 2, 1, 2 -> ESS 25/9 = 2,78; größte Episode 40 %",
           n_ep == 3 and abs(ess_ - 25 / 9) < 1e-9 and abs(anteil_ - 0.4) < 1e-12, f"{n_ep} Episoden, ESS {ess_:.4f}")
        kop = kopula_t(bB, bS)
        ok("Kopula-Rückfall findet ρ und ν wieder (ρ ± 0,05; ν auf dem Gitter neben 5)", abs(kop["rho"] - rho_w) < 0.05 and kop["nu"] in (4, 6),
           f"ρ {kop['rho']:.3f}, ν {kop['nu']}")
        s_st2 = -2.0 * sd_s
        qk = kopula_bedingt(kop, bB, bS, s_st2, False)
        wahr2, _d2 = _bed_wahr(rho_w, s_st2)
        abw_k = float(np.max(np.abs(qk[1:6] - wahr2[1:6])) / sd_s)
        ok("Kopula-Rückfall: bedingte Quantile 10–90 % bei s* = −2σ wie die wahre bedingte Verteilung (Abweichung unter 0,15 σ)",
           abw_k < 0.15, f"größte Abweichung {abw_k:.3f} σ")
        # Ereignisform „S&P 500 fällt um mindestens x %“: Gewicht 1 für s ≤ s*; Wahrheit aus 2·10⁶ Ziehungen desselben Modells
        rngE = np.random.default_rng(1414)
        zE1 = rngE.standard_normal(2_000_000); zE2 = rho_w * zE1 + math.sqrt(1 - rho_w ** 2) * rngE.standard_normal(2_000_000)
        gE = np.sqrt(rngE.chisquare(nu_w, 2_000_000) / nu_w)
        sE, bE = zE1 / gE, zE2 / gE
        s_ev = -2.0 * sd_s
        condE = bE[sE <= s_ev]
        wahrE = np.quantile(condE, qs_)
        dichteE = 0.02 / (np.quantile(condE, qs_ + 0.01) - np.quantile(condE, qs_ - 0.01))     # Dichte der Wahrheit am Quantil
        eE = bedingt(bB, bS, starts, s_ev, sd_s, 28, ereignis=True, kop=kop)
        nE = int(np.sum(bS <= s_ev))
        se_E = np.sqrt(qs_ * (1 - qs_) / max(nE, 1)) / dichteE                       # Stichprobenfehler des Quantils
        dE_bib = np.abs(np.array(eE["bib"]["q"]) - wahrE)[1:6] / se_E[1:6]
        qE_w = kopula_bedingt({"rho": rho_w, "nu": nu_w}, bE[:400_000], sE[:400_000], s_ev, True)     # Verfahren allein: wahre ρ, ν
        dE_w = float(np.max(np.abs(qE_w - wahrE)[1:6])) / sd_s
        dE_kop = float(np.max(np.abs(np.array(eE["kopula"]["q"]) - wahrE)[1:6])) / sd_s if "kopula" in eE else float("inf")
        ok("Ereignisform (S&P ≤ s*, s* = −2σ): Bibliothek (Gewicht 1 unter s*) im Stichprobenfehler (≤ 3 SE) und Kopula-Rückfall mit wahrem ρ, ν "
           "wie die Wahrheit (2·10⁶ Ziehungen; unter 0,06 σ); mit geschätztem ρ, ν nur beschreibend",
           float(np.max(dE_bib)) <= 3.0 and dE_w < 0.06 and abs(eE["kish"] - nE) < 1e-9 and np.isfinite(dE_kop),
           f"{nE} Fenster unter s*, Bibliothek {float(np.max(dE_bib)):.2f} SE, Kopula mit wahrem ρ, ν {dE_w:.3f} σ, mit geschätztem "
           f"(ρ {kop['rho']:.3f}, ν {kop['nu']}) {dE_kop:.3f} σ")
        # Variogramm: die unabhängige Paarung verliert, wenn die Wahrheit gemeinsam ist
        perm = rng.permutation(nf)
        vs_g, vs_u = [], []
        for t in range(300):
            i = rng.integers(0, nf)
            Y = np.array([bB[i], bS[i]])
            Eg = np.column_stack([bB, bS]); Eu = np.column_stack([bB, bS[perm]])
            for Ens, ziel in ((Eg, vs_g), (Eu, vs_u)):
                ziel.append((abs(Y[0] - Y[1]) ** 0.5 - float(np.mean(np.abs(Ens[:, 0] - Ens[:, 1]) ** 0.5))) ** 2)
        ok("Variogramm-Score: die unabhängige Paarung verliert gegen die gemeinsame Bibliothek (Wahrheit gemeinsam)",
           np.mean(vs_u) > np.mean(vs_g), f"{np.mean(vs_g):.4f} gegen {np.mean(vs_u):.4f}")
        ok("Rohmomenten-Test (Knüppel): gleichverteilte PIT nicht verworfen, schiefe (u²) verworfen",
           knueppel(rng.uniform(size=3000), 5)["p"] > 0.01 and knueppel(rng.uniform(size=3000) ** 2, 5)["p"] < 0.001)
    if _an('harx'):
        # ------------------------------------------------------------------ 13.9: Positivkontrolle HAR-X (X1) und Kausalität der US-Reihen
        rng = np.random.default_rng(1309)
        Asyn, lat = _asyn(rng)
        n_a = Asyn["n"]
        vor = np.concatenate([lat[1:], [lat[-1]]])
        dv = np.repeat(np.exp(0.97 * lat + 0.5 * (vor - 0.97 * lat)), 4)   # „DVOL“ sieht einen Teil der künftigen Schwankung
        gew = []
        for h in (1, 7):
            W0 = har_walk(Asyn, h); W1 = har_walk(Asyn, h, extra=np.log(dv ** 2)[:, None])
            m = (Asyn["stunde"] == 0) & (Asyn["tau"] >= OOS_AB) & np.isfinite(W0["F"]) & np.isfinite(W1["F"]) & np.isfinite(W0["S"])
            e = _test_tagesreihe(Asyn["tau"][m] // TAG, qlike(W0["F"][m], W0["S"][m]) - qlike(W1["F"][m], W0["S"][m]), 2.0 * h, seed=h)
            gew.append((e["mittel"], e["p"]))
        ok("Positivkontrolle HAR-X: eine implizite Schwankung mit Vorwissen gewinnt im QLIKE (p < 0,05 bei 1 und 7 Tagen)",
           all(mn > 0 and p_ < 0.05 for mn, p_ in gew), f"{[(round(a, 4), round(b, 4)) for a, b in gew]}")
        t_b = np.array([20000 * TAG]); w_b = np.array([17.5])
        zt = np.array([20000 * TAG + 16 * 3600 + 4 * 3600, 20001 * TAG + 14 * 3600 - 1, 20001 * TAG + 14 * 3600,
                       20011 * TAG + 14 * 3600, 20011 * TAG + 14 * 3600 + 1])
        ua_ = us_asof(t_b, w_b, zt)
        ok("Kausalität der US-Reihen: der Schluss vom Tag d zählt erst ab d+1 14:00 UTC (nicht nach dem Schluss um 16:00 New York); höchstens "
           "10 Tage alt", np.isnan(ua_[0]) and np.isnan(ua_[1]) and ua_[2] == 17.5 and ua_[3] == 17.5 and np.isnan(ua_[4]))
    if _an('kausal'):
        # ------------------------------------------------------------------ 6) Kausalität der Bausteine (8 Punkt 6, 8 Punkt 9)
        rng = np.random.default_rng(1406)
        Asyn, _lat = _asyn(np.random.default_rng(1309))
        Xn = np.cumsum(rng.normal(0, 1, (1500, 3)), axis=0) * 0.05 + rng.normal(0, 1, (1500, 3))
        Z1, _ = standardisieren(Xn)
        Xm = Xn.copy(); Xm[1000:] = Xm[1000:] * 5 + 3
        Z2, _ = standardisieren(Xm)
        ok("Normierung nur aus der Vergangenheit: spätere Werte ändern die z-Werte davor nicht (auf 1e-12)",
           np.max(np.abs(Z1[:1000] - Z2[:1000])) < 1e-12 and np.max(np.abs(Z1[1000:] - Z2[1000:])) > 0.1)
        d0r = OOS_AB // TAG - 900
        tag_r = d0r + np.arange(1300); Xr = rng.normal(0, 1, (1300, 3)); yr = 0.2 * Xr[:, 0] + rng.normal(0, 1, 1300)
        T_r = d0r + 900
        W_r = Ridge(tag_r, Xr, yr, 7).walk(T_r)
        y_e = yr.copy(); y_e[(tag_r >= T_r - 7) & (tag_r <= T_r - 1)] += 50.0
        W_e = Ridge(tag_r, Xr, y_e, 7).walk(T_r)
        y_f = yr.copy(); y_f[tag_r == T_r - 8] += 50.0
        W_f = Ridge(tag_r, Xr, y_f, 7).walk(T_r)
        ok("Embargo der Richtung: Ziele, die bis in den Schätztag reichen (d + 7 ≥ T), ändern die Schätzung bei T nicht; das letzte erlaubte Ziel schon",
           np.max(np.abs(W_r["refits"][0][2] - W_e["refits"][0][2])) < 1e-12 and W_r["refits"][0][1] == W_e["refits"][0][1]
           and np.max(np.abs(W_r["refits"][0][2] - W_f["refits"][0][2])) > 1e-6)
        W0h = har_walk(Asyn, 7)
        km = len(W0h["koeff"]) // 2
        T_h, Tn_h = W0h["koeff"][km][0], W0h["koeff"][km][1]
        A2h = dict(Asyn); A2h["RV"] = np.where(Asyn["tau"] > T_h, Asyn["RV"] * 2.5, Asyn["RV"])
        W2h = har_walk(A2h, 7)
        b_gl = next(b for T, Tn, b, s2 in W2h["koeff"] if T == T_h)
        b_na = next(b for T, Tn, b, s2 in W2h["koeff"] if T == Tn_h)
        ok("Embargo der Breite: Schwankung nach dem Monatsanfang T ändert die HAR-Schätzung von T nicht, die des Folgemonats schon",
           np.max(np.abs(b_gl - W0h["koeff"][km][2])) < 1e-12 and np.max(np.abs(b_na - W0h["koeff"][km + 1][2])) > 1e-6)
        Xk = rng.normal(0, 1, (1300, 2)); yk = 3.0 * Xk[:, 0] + rng.normal(0, 0.3, 1300)
        mk = Ridge(tag_r, Xk, yk, 7).walk(T_r)["mhat"]
        mk = mk[np.isfinite(mk)]
        ok(f"Kappung: m̂ höchstens ±{_de(M_KAPPE, 1)} je Prognose (eingepflanzt das Sechsfache)", len(mk) > 100 and np.max(np.abs(mk)) <= M_KAPPE + 1e-12
           and np.mean(np.abs(mk) >= M_KAPPE - 1e-12) > 0.3, f"größter Betrag {np.max(np.abs(mk)):.3f}, am Deckel {np.mean(np.abs(mk) >= M_KAPPE - 1e-12) * 100:.0f} %")
        # Blockbootstrap (5.4): Größe bei überlappenden 7-Tage-Zielen (MA(6)) in realistischer Länge -- ohne Block wäre jeder Test
        # dieses Moduls deutlich zu großzügig (gemessen 11.10.: rund 28 % statt 5 %; mit Block 14 rund 7 %, bei 28 Tagen und Block 56 4 %)
        rgb = np.random.default_rng(2026); n_b = 1750; abl = 0
        for i_ in range(150):
            e_ = rgb.normal(size=n_b + 7)
            x_ = np.convolve(e_, np.ones(7), "valid")[:n_b] / math.sqrt(7)
            abl += int(_test_tagesreihe(np.arange(n_b), x_, 14.0, seed=i_)["p"] < 0.05)
        ok("Blockbootstrap (mittlere Blocklänge 2h): überlappende 7-Tage-Ziele ohne Mittelwert (1.750 Tage) -- Ablehnung bei 5 % in "
           "höchstens 12 % von 150 Reihen (ohne Block rund 28 %)", abl / 150 <= 0.12, f"{abl} von 150 ({abl / 1.5:.1f} %)")
        # Tor: beide Hälften (4.5)
        nT = 1200; tg_t = OOS_AB // TAG + np.arange(nT)
        rngt = np.random.default_rng(31)

        def _U(y_):
            return {"h": np.full(nT, 7), "stunde": np.zeros(nT, dtype=int), "coin": np.full(nT, "BTC"), "tau": (tg_t + 1) * TAG, "y": y_,
                    "mhat": np.full(nT, 0.3), "b0": 0.05 + rngt.normal(0, 0.1, nT), "m": np.zeros(nT)}
        tA = tor_rechnen(_U(0.3 + rngt.normal(0, 1, nT)), ["BTC"], 7, seed=5)
        rgc_ = np.random.default_rng(32)                                    # knapper Fall: p nicht am Boden, die Blocklänge zählt
        UC_ = {"h": np.full(nT, 7), "stunde": np.zeros(nT, dtype=int), "coin": np.full(nT, "BTC"), "tau": (tg_t + 1) * TAG,
               "y": 0.04 + rgc_.normal(0, 1, nT), "mhat": np.full(nT, 0.3), "b0": 0.005 + rgc_.normal(0, 0.1, nT), "m": np.zeros(nT)}
        tC = tor_rechnen(UC_, ["BTC"], 7, seed=5)
        pA_cw = _test_tagesreihe(UC_["tau"] // TAG, 2 * UC_["y"] * UC_["mhat"], 14.0, 5)["p"]
        pA_cr = _test_tagesreihe(UC_["tau"] // TAG, UC_["b0"] - UC_["m"], 14.0, 6)["p"]
        yB = np.where(np.arange(nT) < nT // 2, 0.6, -0.05) + rngt.normal(0, 1, nT)
        tB = tor_rechnen(_U(yB), ["BTC"], 7, seed=5)
        ok("Tor verlangt beide Hälften: insgesamt belegt, aber zweite Hälfte negativ -> zu; beide Hälften positiv -> offen; Clark-West und "
           "CRPS mit Blocklänge 2h (gleich dem direkten Aufruf)",
           tA["offen"] and not tB["offen"] and tB["cw"]["p"] < 0.05 and not tB["cw"]["haelften"]
           and tC["cw"]["p"] == pA_cw and tC["crps"]["p"] == pA_cr and 0.002 < pA_cw < 0.9,
           f"A offen {tA['offen']} · B offen {tB['offen']} (CW p {tB['cw']['p']:.4f}, Hälften {tB['cw']['h1']:+.3f}/{tB['cw']['h2']:+.3f}) · "
           f"knapper Fall CW p {tC['cw']['p']:.4f}")
        # Aktien-Kandidaten erst ab d+1 14:00 UTC (13.5): am Tag d gilt der Wert des US-Datums d − 1
        nd_ = 400; tag_a = 20000 + np.arange(nd_)
        Da = {"n": nd_, "C": 100 * np.exp(np.cumsum(rng.normal(0, 0.02, nd_))), "tag": tag_a, "H": None, "L": None}
        t_us = (tag_a - 5) * TAG; w_us = np.arange(nd_, dtype=float) + 0.5
        Xa_ = kandidaten_roh("BTC", Da, np.full(nd_, 0.03), {"aktien": {"A1": (t_us, w_us)}})
        a1 = Xa_[:, K_NAMEN.index("A1")]
        soll_a = np.array([w_us[np.searchsorted(t_us, (d - 1) * TAG, side="right") - 1] if (d - 1) * TAG >= t_us[0] else np.nan for d in tag_a])
        m_a = np.isfinite(soll_a)
        ok("Aktien-Kandidaten mit Verzug: am Tag d (Anker d+1 00 UTC) gilt der US-Schluss vom Datum d − 1, nie der vom Datum d",
           m_a.sum() > 300 and np.array_equal(a1[m_a], soll_a[m_a]))
        # S&P-Koordinate über Handelstage (13.3): Fenster ab Freitag 18:00 UTC über 3 Tage enthalten genau einen Schluss
        import hl_aktien as AK
        d_sp = date(2016, 1, 4); t_sp = []
        while d_sp <= date(2026, 6, 30):
            if AK.handelstag(d_sp):
                t_sp.append(AK.tag_ts(d_sp.isoformat()))
            d_sp += timedelta(days=1)
        t_sp = np.array(t_sp, dtype=np.int64)
        w_sp = 3000 * np.exp(np.cumsum(np.random.default_rng(41).normal(0, 0.01, len(t_sp))))
        SPBt = sp_breite({"ts": t_sp, "w": w_sp}, None, None)
        fr = np.array([AK.tag_ts(x.isoformat()) + 18 * 3600 for x in (date(2020, 1, 3) + timedelta(days=7 * i) for i in range(320))], dtype=np.int64)
        zall_ = sp_koordinate({"start": fr}, SPBt).astype(float)
        zfr = zall_[:, 2]; zfr = zfr[np.isfinite(zfr)]
        zf7 = zall_[:, 6]; zf7 = zf7[np.isfinite(zf7)]
        tau_mo = int(datetime(2026, 6, 8, tzinfo=timezone.utc).timestamp())
        jv_ = int(np.searchsorted(SPBt["t_verf"], tau_mo, side="right") - 1)
        nfs = sp_breite_jetzt(SPBt, tau_mo, 7) / float(SPBt["V"][7][jv_])
        ok("S&P-Koordinate über Handelstage: Freitag 18 UTC + 3 Tage = ein Schluss, + 7 Tage = 5 Schlüsse, Varianz der normierten Rendite "
           "je ≈ 1; eine Woche ab Montag = 5 Handelstage", len(zfr) > 250 and abs(float(np.var(zfr)) - 1) < 0.25 and abs(float(np.var(zf7)) - 1) < 0.25
           and abs(nfs - 5) < 1e-9, f"Varianz {np.var(zfr):.3f} / {np.var(zf7):.3f} (n {len(zfr)}), Handelstage {nfs:.0f}")
        tg_k = np.array([100, 101, 102, 104], dtype=np.int64)               # Tag 103 fehlt
        fall_k = [(kandidaten_index(tg_k, 102 * TAG), 1), (kandidaten_index(tg_k, 103 * TAG - 1), 1), (kandidaten_index(tg_k, 103 * TAG), 2),
                  (kandidaten_index(tg_k, 103 * TAG + 18 * 3600), 2), (kandidaten_index(tg_k, 104 * TAG + 6 * 3600), 2),
                  (kandidaten_index(tg_k, 105 * TAG), 3), (kandidaten_index(tg_k, 100 * TAG), -1)]
        ok("Kandidatentag: am Anker τ gilt der letzte abgeschlossene UTC-Tag (Tag d endet um d+1 00 UTC), bei einer Lücke der davor",
           all(a_ == b_ for a_, b_ in fall_k), f"{[a_ for a_, _ in fall_k]}")
        # Bein wie hl_zyklus (8 Punkt 7)
        import hl_zyklus as ZY
        Cb0 = 100 * np.exp(np.cumsum(np.random.default_rng(5).normal(0, 0.03, 1500)))
        erg_b = []
        for Cb in (Cb0, 1e4 / Cb0):                                       # gespiegelt: das erste Extrem ist einmal ein Hoch, einmal ein Tief
            br = bein_reihe(Cb, 0.10)
            Dz = ZY.dc_batch(np.log(Cb)[None, :], math.log(1.1), -math.log(0.9))
            wechsel = [(t, int(br["mode"][t])) for t in range(1, len(Cb)) if br["mode"][t] != br["mode"][t - 1]]
            dc_ev = [(int(t), -int(ty)) for t, ty in zip(Dz["conf_i"], Dz["typ"])]
            Bz = ZY.beine(Dz)
            soll_auf = sorted((Bz["auf"]["x_hoch"] - Bz["auf"]["x_tief"]).tolist()); soll_ab = sorted((Bz["ab"]["x_hoch"] - Bz["ab"]["x_tief"]).tolist())
            gl_auf = len(br["auf"]) == len(soll_auf) and np.allclose(sorted(br["auf"]), soll_auf, atol=1e-12)
            gl_ab = len(br["ab"]) == len(soll_ab) and np.allclose(sorted(br["ab"]), soll_ab, atol=1e-12)
            erg_b.append((wechsel == dc_ev and gl_auf and gl_ab and len(dc_ev) > 10, len(dc_ev), len(br["auf"]), len(br["ab"]),
                          int(dc_ev[0][1]) if dc_ev else 0))
        ok("Bein wie hl_zyklus: dieselben Wendepunkte (Zeit und Richtung) und dieselben abgeschlossenen Beine wie dc_batch/beine -- auch "
           "gespiegelt (erstes Extrem einmal Hoch, einmal Tief)", all(e_[0] for e_ in erg_b) and {e_[4] for e_ in erg_b} == {1, -1},
           "; ".join(f"{e_[1]} Wendepunkte, {e_[2]} Aufwärts-, {e_[3]} Abwärtsbeine" for e_ in erg_b))
    if _an('schock'):
        # ------------------------------------------------------------------ 13.9: Schockregel
        import tempfile
        import hl_swing as SW
        tmp_s = tempfile.mkdtemp(prefix="au_schock_")
        alt_sw = os.environ.get("HL_SWING_DB"); alt_au = os.environ.pop("HL_AUSBLICK_DB", None)
        try:
            os.environ["HL_SWING_DB"] = os.path.join(tmp_s, "swing.db")
            jetzt_s = int(time.time()) // BAR * BAR
            K0 = RG._markt(tage=320, seed=77, sigma_tag=0.03, start=jetzt_s - 320 * TAG)
            K1 = {k: v.copy() for k, v in K0.items()}
            F1s = 0.03 ** 2
            sprung = math.exp(1.6 * SCHOCK_R * math.sqrt(F1s / 48))
            K1["c"][-1] = K1["c"][-2] * sprung; K1["h"][-1] = max(K1["h"][-1], K1["c"][-1])
            swc = SW.verbinden(os.environ["HL_SWING_DB"])
            SW._schreiben(swc, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                          [("BTC", int(t), float(o), float(hh), float(ll), float(c), 1.0) for t, o, hh, ll, c in
                           zip(K1["ts"][-200:], K1["o"][-200:], K1["h"][-200:], K1["l"][-200:], K1["c"][-200:])])
            swc.close()
            db_s = os.path.join(tmp_s, "hl_liq.db")
            cs_ = verbinden(ausblick_pfad(db_s)); meta_setzen(cs_, {"schock_basis": json.dumps({"coins": {"BTC": {"F1": F1s}}})}); cs_.close()
            jetzt_p = int(K1["ts"][-1]) + BAR + 60
            n1 = schock_pruefen(db_s, jetzt_p); n2 = schock_pruefen(db_s, jetzt_p + 300)
            A0s, A1s = anker_reihen(K0), anker_reihen(K1)
            Wsh = {h: dict(har_walk(A0s, h), wahl=[]) for h in H_STUETZ}
            tau_s = int(K1["ts"][-1]) + BAR
            F0s = F_bei({"A": A0s, "W": Wsh, "coin": "BTC"}, {"R": {}}, tau_s); F1b = F_bei({"A": A1s, "W": Wsh, "coin": "BTC"}, {"R": {}}, tau_s)
            q_ = {h: F1b[h] / F0s[h] for h in (1, 7, 28)}
            ok("Schockregel: eine eingepflanzte 30-min-Bewegung (1,6 × Schwelle) löst genau einmal aus; der Fächer für 7 Tage wird sofort "
               "breiter, für 28 Tage weniger", len(n1) == 1 and n1[0][:2] == ("BTC", "a") and n2 == [] and q_[7] > 1.02 and q_[1] > q_[7] > q_[28] > 1.0,
               f"Auslösungen {len(n1)} + {len(n2)}, Breite ×{q_[1]:.2f} (1 T) / ×{q_[7]:.2f} (7 T) / ×{q_[28]:.3f} (28 T)")
        except Exception as e:
            import traceback
            ok("Schockregel ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        finally:
            if alt_sw is None:
                os.environ.pop("HL_SWING_DB", None)
            else:
                os.environ["HL_SWING_DB"] = alt_sw
            if alt_au is not None:
                os.environ["HL_AUSBLICK_DB"] = alt_au
            shutil.rmtree(tmp_s, ignore_errors=True)
    if _an('takt'):
        # ------------------------------------------------------------------ 7.2/7.5/13.1: Takt (Rückblick nachts und sonntags, Anker, Schock, offen, stündlich)
        def _utc(*a_):
            return int(datetime(*a_, tzinfo=timezone.utc).timestamp())
        so20 = _utc(2026, 10, 11, 20, 0)                                    # Sonntag 20:00 UTC: Takt gestartet, noch kein Rückblick
        so02 = _utc(2026, 10, 18, 2, 0)                                     # Sonntag eine Woche später, 02:00 UTC
        mo2030 = _utc(2026, 10, 12, 20, 30)
        tab_rf = [("ohne Stand, So 20:05, Takt eben gestartet", rueckblick_faellig(0, so20 + 300, so20), False),
                  ("ohne Stand, Mo 01:00", rueckblick_faellig(0, so20 + 5 * 3600, so20), True),
                  ("ohne Stand, Mo 05:59", rueckblick_faellig(0, so20 + 10 * 3600 - 60, so20), True),
                  ("ohne Stand, Mo 06:00", rueckblick_faellig(0, so20 + 10 * 3600, so20), False),
                  ("ohne Stand, Mo 19:59 (Takt 23:59 h alt)", rueckblick_faellig(0, so20 + TAG - 60, so20), False),
                  ("ohne Stand, Mo 20:00 (Takt 24 h alt)", rueckblick_faellig(0, so20 + TAG, so20), True),
                  ("Stand Mo 20:30 (5 T 5,5 h alt), So 02:00", rueckblick_faellig(mo2030, so02, so20), True),
                  ("Stand Mo 20:30, So 01:59", rueckblick_faellig(mo2030, so02 - 60, so20), False),
                  ("Stand Mo 20:30, Sa 03:00", rueckblick_faellig(mo2030, so02 - TAG + 3600, so20), False),
                  ("Stand Mi 03:00 (4 T alt), So 03:00", rueckblick_faellig(_utc(2026, 10, 14, 3, 0), so02 + 3600, so20), False)]
        falsch_rf = [n_ for n_, ist_, soll_ in tab_rf if ist_ != soll_]
        ok("Takt: Rückblick fällig -- erster in der Nacht nach dem Einspielen (01–06 UTC, spätestens 24 h nach dem Start), danach sonntags "
           "ab 02:00 UTC, wenn der letzte älter als 5 Tage ist", not falsch_rf, f"{len(tab_rf)} Fälle" + (f", falsch: {falsch_rf}" if falsch_rf else ""))
        tmp_t = tempfile.mkdtemp(prefix="au_takt_")
        alt_au_t = os.environ.pop("HL_AUSBLICK_DB", None)
        g_ = globals(); alt_fn = (g_["_starte_lauf"], g_["schock_pruefen"]); alt_takt = dict(_TAKT)
        starts_t = []; schock_t = []; antwort_t = []

        class _Proc:
            def __init__(self):
                self.rc = None

            def poll(self):
                return self.rc

        def _fake_start(db_, art, tau=None):
            p_ = _TAKT.get("proc")
            if p_ is not None and p_.poll() is None:
                return False
            _TAKT["proc"] = _Proc(); _TAKT["art"] = art; starts_t.append((art, tau))
            return True

        def _fake_schock(db_, jetzt_=None, setzen=True):
            schock_t.append(int(jetzt_)); return list(antwort_t)
        try:
            db_t = os.path.join(tmp_t, "hl_liq.db")
            con_t = verbinden(ausblick_pfad(db_t))
            g_["_starte_lauf"] = _fake_start; g_["schock_pruefen"] = _fake_schock
            _TAKT.clear()
            _TAKT.update({"gestartet": True, "start": float(so20), "proc": None, "art": None, "letzte_anfrage": 0.0, "letzter_start": 0.0,
                          "letzte_schockpruefung": 0.0, "fehler": None, "laeufe": 0})

            def _schritt(jetzt_, letzte=None, anker=(), fertig=True):
                """Ein Takt-Schritt um jetzt_; vorher: laufender Lauf fertig (fertig), letzte Prognose, vorhandene 6-h-Anker."""
                if fertig and _TAKT.get("proc") is not None:
                    _TAKT["proc"].rc = 0
                if letzte is not None:
                    meta_setzen(con_t, {"letzte_prognose": str(int(letzte))})
                for a_ in anker:
                    _tx(con_t, lambda: con_t.execute("INSERT OR REPLACE INTO au_prognose VALUES ('BTC', ?, ?, 'anker', '{}')", (int(a_), int(a_))))
                return takt_schritt(db_t, float(jetzt_))
            mo = so20 + 4 * 3600                                            # Montag 00:00 UTC
            folge = [("So 20:05: nichts fällig (Schockprüfung läuft)", _schritt(so20 + 300, letzte=so20 - 600, anker=(so20 - 2 * 3600,)), None),
                     ("Mo 01:30: erster Rückblick", _schritt(mo + 90 * 60, letzte=mo + 85 * 60), "rueckblick")]
            n_sch = len(schock_t)
            folge.append(("Mo 01:31: Rückblick läuft -- kein zweiter Lauf, aber Schockprüfung", _schritt(mo + 91 * 60, fertig=False), None))
            sch_waehrend = len(schock_t) - n_sch
            folge.append(("Mo 01:33: Rückblick läuft -- Schockprüfung erst nach 5 min wieder", _schritt(mo + 93 * 60, fertig=False), None))
            sch_2min = len(schock_t) - n_sch - sch_waehrend
            folge.append(("Mo 01:40: Rückblick fertig -> Prognose sofort mit dem neuen Stand", _schritt(mo + 100 * 60), "nach_rueckblick"))
            folge.append(("Mo 02:00: Rückblick (ohne Stand) wieder fällig, aber erst 6 h nach dem Versuch; Anker 00:00 fehlt",
                          _schritt(mo + 2 * 3600, letzte=mo + 100 * 60), "anker"))
            antwort_t.append(("BTC", "a", "Probe"))
            folge.append(("Mo 02:05: Anker-Wiederholung erst nach 10 min; Schock -> Lauf", _schritt(mo + 125 * 60), "schock"))
            antwort_t.clear()
            _TAKT["letzte_anfrage"] = float(mo + 130 * 60)
            folge.append(("Mo 02:12: Abschnitt offen, Halbstunde 02:00 schon gerechnet", _schritt(mo + 132 * 60, letzte=mo + 125 * 60, anker=(mo,)), None))
            folge.append(("Mo 02:37: Abschnitt offen, Halbstunde 02:30 fällig (ab +6 min)", _schritt(mo + 157 * 60), "takt"))
            _TAKT["letzte_anfrage"] = 0.0
            folge.append(("Mo 03:38: Abschnitt zu, letzte Rechnung 61 min alt -> stündlich", _schritt(mo + 218 * 60, letzte=mo + 157 * 60), "stuendlich"))
            folge.append(("Mo 07:31: Rückblick ohne Stand, aber außerhalb 01–06 UTC und Takt erst 11,5 h alt",
                          _schritt(mo + 451 * 60, letzte=mo + 450 * 60, anker=(mo + 6 * 3600,)), None))
            folge.append(("Mo 20:01: Takt 24 h alt, letzter Versuch 18,5 h her -> Rückblick wiederholt",
                          _schritt(so20 + TAG + 60, letzte=so20 + TAG, anker=(mo + 12 * 3600, mo + 18 * 3600)), "rueckblick"))
            folge.append(("Mo 20:02: danach die Prognose", _schritt(so20 + TAG + 120), "nach_rueckblick"))
            meta_setzen(con_t, {"rueckblick_stand": str(mo2030)})
            folge.append(("Sa 03:00: Wochenregel nur sonntags", _schritt(so02 - TAG + 3600, letzte=so02 - TAG + 3540, anker=(so02 - TAG - 2 * 3600,)), None))
            folge.append(("So 02:01: letzter Rückblick 5 T 5,5 h alt -> wöchentlicher Rückblick",
                          _schritt(so02 + 60, letzte=so02, anker=(so02 - 2 * 3600,)), "rueckblick"))
            con_t.close()
            falsch_t = [f"{n_}: {ist_} statt {soll_}" for n_, ist_, soll_ in folge if ist_ != soll_]
            laeufe_t = [a_ for a_, _ in starts_t]
            ok("Takt: Reihenfolge Rückblick -> Prognose mit neuem Stand, Wiederholung nach 6 h, Anker (alle 10 min), Schock (auch während des "
               "Rückblicks, alle 5 min), offener Abschnitt (30 min), stündlich", not falsch_t and sch_waehrend == 1 and sch_2min == 0
               and laeufe_t == ["rueckblick", "nach_rueckblick", "anker", "schock", "takt", "stuendlich", "rueckblick", "nach_rueckblick", "rueckblick"]
               and starts_t[2][1] == mo,
               f"{len(folge)} Schritte, Läufe {laeufe_t}, Schockprüfung während des Rückblicks {sch_waehrend}"
               + (f"; falsch: {falsch_t[:2]}" if falsch_t else ""))
        except Exception as e:
            import traceback
            ok("Takt ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        finally:
            g_["_starte_lauf"], g_["schock_pruefen"] = alt_fn
            _TAKT.clear(); _TAKT.update(alt_takt)
            if alt_au_t is not None:
                os.environ["HL_AUSBLICK_DB"] = alt_au_t
            shutil.rmtree(tmp_t, ignore_errors=True)
    if _an('e2e'):
        # ------------------------------------------------------------------ 8) Ende zu Ende auf Demo-Datenbanken, Kausalität des ganzen Laufs
        import hl_zyklus as ZY
        tmp_d = tempfile.mkdtemp(prefix="au_demo_")
        jetzt_d = int(time.time()) // BAR * BAR - 600
        U_d = None
        try:
            U_d = _demo_umgebung(os.path.join(tmp_d, "voll"), jetzt_d, tage=1100, kurz={"HYPE": 520})
            db_v = U_d["pf"]["haupt"]
            ohne_live = lambda d_, c_: {}
            t_rb = time.time()
            RB = rueckblick(db_v, n_null=20, schreiben=True, jetzt=jetzt_d)
            dauer_rb = time.time() - t_rb
            E = prognose(db_v, jetzt=jetzt_d, live_fn=ohne_live)
            Ec = E["coins"]
            ok("Ende zu Ende: Rückblick (20 Surrogate) und Prognose für alle sechs Coins auf Demo-Datenbanken mit S&P-Archiv",
               set(Ec) == set(COINS) and all(Ec[c].get("spannen") for c in COINS) and RB.get("tor") and RB.get("s1"),
               f"Rückblick {dauer_rb:.0f} s, Prognose {E['dauer']:.1f} s; fehlt: {sorted(set(f for c in COINS for f in Ec[c].get('fehlt') or []))[:2]}")
            mono = all(np.all(np.diff(np.array(Ec[c]["faecher"]), axis=1) >= -1e-12) for c in COINS)
            spann = all(all(np.all(np.diff(Ec[c]["spannen"][str(h)]["q"]) > 0) for h in H_ZIEL) for c in COINS)
            niv_ok = all(all(n["p"][str(h)][0] >= n["p"][str(h)][1] - 1e-12 for h in H_ZIEL) and
                         n["p"]["7"][0] <= n["p"]["14"][0] + 1e-12 <= n["p"]["28"][0] + 2e-12
                         for c in COINS for n in Ec[c].get("niveaus") or [] if n.get("p"))
            n_niv = sum(1 for c in COINS for n in Ec[c].get("niveaus") or [] if n.get("p"))
            ok("Ende zu Ende: Fächer je Tag geordnet, Spannen steigend, je Niveau Erreichen ≥ Schluss jenseits und Erreichen wachsend in h",
               mono and spann and niv_ok and n_niv >= 6, f"{n_niv} Niveaus mit Wahrscheinlichkeiten")
            txt = text(db_v)
            woerter = [w for w in WORT_VERBOTEN for c in COINS for satz in Ec[c].get("lesart") or [] if w in satz.lower()]
            woerter += [w for w in WORT_VERBOTEN if w in txt.lower()]
            ok("Lesart und Text ohne Empfehlungswörter; letzter Satz „Wahrscheinlichkeiten aus der Verteilung, keine Empfehlung.“",
               not woerter and all((Ec[c].get("lesart") or [""])[-1] == "Wahrscheinlichkeiten aus der Verteilung, keine Empfehlung." for c in COINS)
               and "RÜCKBLICK" in txt and "== BTC" in txt, f"gefunden: {sorted(set(woerter)) or 'keine'}")
            pr_ = ((RB.get("s1") or {}).get("h") or {}).get("28", {}).get("deckung") or {}
            soll_w = {c: deckung_wertung({"d80": d_.get("d80"), "se": d_.get("se"), "ok": d_.get("ok")}) for c, d_ in pr_.items()}
            lesart_w = all(((soll_w.get(c) or "") in (Ec[c].get("lesart") or [""])[0 if not Ec[c].get("ausnahme") else 1]) for c in COINS if c in soll_w)
            mit_stress = any(Ec[c].get("stress") for c in COINS)
            ok("Text: Szenarien mit dem Stand von S4 (13.9), Stressfächer (falls berechnet) als „Form … bei heutiger Schwankung“ mit 80 und "
               "90 %; Lesart mit Wertung der Deckung je Coin wie im Rückblick",
               "Szenarien mit dem S&P 500 -- Abhängigkeit im Rückblick" in txt
               and (not mit_stress or ("bei heutiger Schwankung: 28 T 80 %" in txt and " · 90 % " in txt))
               and lesart_w and pr_, f"Wertungen {soll_w}, Stressfächer {'ja' if mit_stress else 'in den Demodaten nicht berechnet'}")
            bed = Ec["BTC"].get("bedingt") or []
            info = Ec["BTC"].get("bedingt_info") or {}
            ok("Bedingte Szenarien (BTC): Vorgaben × Horizonte mit Methode und Episoden-ESS; S&P-Koordinate trendbereinigt (Mittel 0); PAXG ohne",
               len(bed) == len(SZEN_X) * len(SZEN_H) + 1 and all(e.get("methode") in ("bibliothek", "kopula", "keine") for e in bed)
               and info.get("mittel_sS") and all(abs(v_) < 1e-6 for v_ in info["mittel_sS"].values()) and not Ec["PAXG"].get("bedingt"),
               f"{len(bed)} Abfragen, Methoden {sorted(set(e.get('methode') for e in bed))}, Mittel {info.get('mittel_sS')}")
            ok("HYPE unter 730 Tagen mit der gepoolten Bibliothek der Krypto-Coins; PAXG mit eigener Bibliothek und nur seinen 9 Kandidaten",
               str((Ec["HYPE"].get("bibliothek") or {}).get("art", "")).startswith("gepoolt") and (Ec["PAXG"].get("bibliothek") or {}).get("art") == "eigene"
               and [e["key"] for e in ((RB["richtung"].get("paxg") or {}).get("7") or {}).get("kandidaten") or []] == list(PAXG_KANDIDATEN)
               and len(((RB["richtung"].get("krypto") or {}).get("7") or {}).get("kandidaten") or []) == len(K_NAMEN),
               f"HYPE {(Ec['HYPE'].get('bibliothek') or {}).get('art')}, PAXG {(Ec['PAXG'].get('bibliothek') or {}).get('art')}")
            NL = nutzlast(db_v, "BTC", chart={"tage": {"t0": 0, "o": [1.0] * 5, "h": [1.0] * 5, "l": [1.0] * 5, "c": [1.0] * 5, "ma50": [None] * 5,
                                                       "ma200": [None] * 5}, "kurs": 1.0})
            gw = ((NL.get("rueckblick") or {}).get("gewichte") or {}).get("7") or {}
            stati = {e.get("status") for e in gw.get("kandidaten") or []}
            ok("Nutzlast /ausblick: Prognose, Rückblick mit Gewichten (36 Kandidaten, Status), Tor je Horizont, Takt-Zustand, Tageskerzen",
               NL.get("ok") and NL.get("prognose") and len(gw.get("kandidaten") or []) == len(K_NAMEN)
               and stati <= {"trägt", "trägt nicht", "Hinweis", "zu kurz"} and set(((NL["rueckblick"].get("tor") or {}).get("krypto") or {})) == {"7", "14", "28"}
               and "takt" in NL and NL.get("tage"), f"Status {sorted(stati)}")
            P_b = chartbild_daten(db_v, "BTC", ohne_live)
            L_b = niveaus_aus_chartbild(P_b)
            px_cb = {round(float(n["px"]), 6) for n in P_b.get("niveaus") or [] if n.get("px")}
            px_l = {round(n["px"], 6) for n in L_b}
            px_e = {round(n["px"], 6) for n in Ec["BTC"].get("niveaus") or []}
            ok("Niveaus wie im Chartbild: alle Niveaus des Chartbilds sind Kandidaten, der Ausblick zeigt nur Kandidaten",
               px_cb and px_cb <= px_l and px_e <= px_l, f"Chartbild {len(px_cb)}, Kandidaten {len(px_l)}, gezeigt {len(px_e)}")
            # Kausalität des ganzen Laufs: Prognose aus der bei τ abgeschnittenen Datenbank = Prognose für τ im vollen Lauf
            tau_c = anker_von(jetzt_d - 150 * TAG)
            pf_c = _demo_abschneiden(os.path.join(tmp_d, "voll"), os.path.join(tmp_d, "cut"), tau_c)
            G_v = lade(db_v)
            E_v = prognose(db_v, jetzt=tau_c + 900, tau_fest=tau_c, live_fn=ohne_live, schreiben=False, G=G_v)["coins"]
            import hl_chartbild as CB
            alt_c = CB._mit_umgebung(pf_c)
            try:
                os.environ["HL_AKTIEN_DB"] = pf_c["aktien"]
                G_c = lade(pf_c["haupt"])
                E_c = prognose(pf_c["haupt"], jetzt=tau_c + 900, tau_fest=tau_c, live_fn=ohne_live, schreiben=False, G=G_c)["coins"]
            finally:
                os.environ.pop("HL_AKTIEN_DB", None)
                CB._mit_umgebung(U_d["pf"])
            abw_k = 0.0; n_vgl = 0
            for c in COINS:
                for key in ("faecher", "F", "mu"):
                    a_ = np.array(E_v[c][key] if key != "F" else [E_v[c]["F"][str(h)] for h in H_STUETZ], dtype=float)
                    b_ = np.array(E_c[c][key] if key != "F" else [E_c[c]["F"][str(h)] for h in H_STUETZ], dtype=float)
                    abw_k = max(abw_k, float(np.max(np.abs(a_ - b_) / np.maximum(np.abs(a_), 1e-300)))); n_vgl += a_.size
                for e1, e2 in zip(E_v[c].get("bedingt") or [], E_c[c].get("bedingt") or []):
                    for k_ in ("bib", "kopula"):
                        if k_ in e1 or k_ in e2:
                            a_, b_ = np.array(e1[k_]["q"]), np.array(e2[k_]["q"])
                            abw_k = max(abw_k, float(np.max(np.abs(a_ - b_) / np.maximum(np.abs(a_), 1e-300)))); n_vgl += a_.size
            gleich_bed = all(len(E_v[c].get("bedingt") or []) == len(E_c[c].get("bedingt") or []) for c in COINS)
            ok("Kausalität des ganzen Laufs: Prognose aus der bei τ abgeschnittenen Datenbank = Prognose für τ im vollen Lauf (Fächer, Breite, "
               "Drift, bedingte Szenarien; auf 1e-12)", abw_k <= 1e-12 and gleich_bed and n_vgl > 1000,
               f"{n_vgl} Zahlen verglichen, größte relative Abweichung {abw_k:.1e}, τ {_dtz(tau_c)}")
            V_v = {c: vorbereiten(c, G_v) for c in COINS}; V_c = {c: vorbereiten(c, G_c) for c in COINS}
            KA_v = kandidaten_alle(V_v, G_v); KA_c = kandidaten_alle(V_c, G_c)
            abw_z = 0.0; n_z = 0
            for c in COINS:
                t_v, t_c = V_v[c]["D"]["tag"], V_c[c]["D"]["tag"]
                m_ = t_v <= tau_c // TAG - 1
                n_ = int(m_.sum())
                if n_ and len(t_c) >= n_ and np.array_equal(t_v[:n_], t_c[:n_]):
                    abw_z = max(abw_z, float(np.nanmax(np.abs(KA_v[c]["Z"][:n_] - KA_c[c]["Z"][:n_])))); n_z += n_
                else:
                    abw_z = float("inf")
            ok("Kausalität der Kandidaten: die 36 normierten Kandidaten bis τ sind in der abgeschnittenen Datenbank dieselben (auf 1e-12)",
               abw_z <= 1e-12 and n_z > 3000, f"{n_z} Tage × 36, größte Abweichung {abw_z:.1e}")
            T_b = (G_v.get("tafeln") or {}).get("BTC")
            roh_b = KA_v["BTC"]["roh"]; tag_b = V_v["BTC"]["D"]["tag"]
            if T_b is not None and T_b.get("konten") is not None:
                tt_ = T_b["tag0"] + np.arange(T_b["n"]); kp = ZY.oi_perzentil(np.asarray(T_b["konten"], dtype=float), 90, 60)
                pos_ = {int(t): i for i, t in enumerate(tt_)}
                idx_ = [(i, pos_[int(d)]) for i, d in enumerate(tag_b) if int(d) in pos_]
                d5 = np.array([roh_b[i, K_NAMEN.index("D5")] for i, _ in idx_]); s5 = np.log(np.array([T_b["konten"][j] for _, j in idx_], dtype=float))
                d6 = np.array([roh_b[i, K_NAMEN.index("D6")] for i, _ in idx_]); s6 = np.array([kp[j] for _, j in idx_])
                m5 = np.isfinite(s5); m6 = np.isfinite(s6)
                ok("Positionierung wie hl_hebel/hl_zyklus: D5 = ln Konten-Verhältnis desselben Tages, D6 = Perzentil der 90 Tage",
                   len(idx_) > 60 and np.array_equal(np.isfinite(d5), m5) and np.allclose(d5[m5], s5[m5], rtol=0, atol=1e-12) and m5.sum() > 60
                   and np.array_equal(np.isfinite(d6), m6) and np.allclose(d6[m6], s6[m6], rtol=0, atol=1e-12) and m6.sum() > 20,
                   f"{len(idx_)} Tage, davon {int(m5.sum())} mit Konten-Verhältnis, {int(m6.sum())} mit Perzentil")
            else:
                ok("Positionierung wie hl_hebel/hl_zyklus: D5 = ln Konten-Verhältnis desselben Tages, D6 = Perzentil der 90 Tage", False, "keine Tafel")
        except Exception as e:
            import traceback
            tb = traceback.format_exc().splitlines()
            ok("Ende zu Ende ohne Absturz", False, f"{type(e).__name__}: {e} -- {' | '.join(x.strip() for x in tb[-6:-1])}")
        finally:
            if U_d is not None:
                _demo_ende(U_d)
            shutil.rmtree(tmp_d, ignore_errors=True)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok_all[0] else 'NICHT bestanden'} ({time.time() - t_start:.0f} s)"
              + (f" -- nur {', '.join(sorted(nur))}" if nur else ""), flush=True)
    return ok_all[0]


# ================================================================================================ Befehlszeile

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Ausblick 4 Wochen (U146)")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (ausblick.db liegt daneben)")
    ap.add_argument("--prognose", action="store_true")
    ap.add_argument("--art", default="hand")
    ap.add_argument("--tau", type=int, default=None)
    ap.add_argument("--rueckblick", action="store_true")
    ap.add_argument("--null", type=int, default=NULL_K)
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--null-kalibrierung", action="store_true")
    ap.add_argument("--nachweisgrenze", action="store_true", help="Trefferquote der Richtungsprüfung je eingepflanzter Stärke (8 Punkt 5)")
    ap.add_argument("--universen", type=int, default=100)
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--nur", default=None, help="Selbsttest nur dieser Gruppen, mit Komma (basis, pfad, breite, null, pk, kopula, harx, kausal, schock, takt, e2e)")
    a = ap.parse_args(argv)
    if a.selbsttest:
        nur = {g.strip() for g in a.nur.split(",") if g.strip()} if a.nur else None
        unbekannt = sorted((nur or set()) - set(SELBSTTEST_GRUPPEN))
        if unbekannt:
            print("unbekannte Gruppe(n): " + ", ".join(unbekannt) + " -- bekannt: " + ", ".join(SELBSTTEST_GRUPPEN), file=sys.stderr)
            return 2
        return 0 if selbsttest(nur=nur) else 1
    if a.null_kalibrierung:
        print(json.dumps(_ohne_nan(null_kalibrierung(a.universen, log=lambda s: print(s, flush=True))), indent=1))
        return 0
    if a.nachweisgrenze:
        print(json.dumps(_ohne_nan(nachweisgrenze(n_universen=min(a.universen, 20), log=lambda s: print(s, flush=True))), indent=1))
        return 0
    db = a.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db")
    if a.prognose:
        E = prognose(db, art=a.art, tau_fest=a.tau, log=lambda s: print(s, flush=True))
        return 0 if E["coins"] else 1
    if a.rueckblick:
        E = rueckblick(db, log=lambda s: print(s, flush=True), n_null=a.null)
        print(""); print(rueckblick_text(E))
        return 0
    print(text(db))
    return 0


if __name__ == "__main__":
    sys.exit(main())
