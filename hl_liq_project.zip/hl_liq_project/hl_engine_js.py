"""
hl_engine_js.py -- Skript des Reiters „Engine“ im TradeLabor (U241, 23.93; Button „Bremse lösen“ seit 23.94), ausgeliefert unter /engine.js.

Eigene Datei wie hl_volatil_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf den
Helfern der Seite auf ($, getJSON, esc, hm, dmy, labUsd, labFarbe, labSetzen, LAB) und muss deshalb NACH dem Hauptskript geladen
werden. Daten: /labor/engine (hl_engine.stand_lesen, engine.db). Inhalt nach KONZEPT_TradingEngine.md Abschnitt 8: Kopf (Konto, Netto
seit dem Start, größter Rückgang, aktive Strategien, offene Positionen, Ausgelassenes, daneben Labor gesamt und Halten Long im selben
Zeitraum), Tabelle je Strategie (Zustand, seit, Grund in Worten, Wochen, Trades, t ganze Geschichte, t letzte 17 Wochen, Stand der
Überwachung in % der Grenze, Tagesmittel in steigenden und fallenden BTC-Monaten), Protokoll der Entscheidungen, Kontoverlauf als
Tabelle (statt Bild), übernommene Trades, Regeln. Papier: kein echtes Geld, keine Order. Bei gesetzter Bremse ein Button „Bremse lösen“
mit Nachfrage auf der Seite (POST /labor/engine/bremse_loesen?ja=1 mit der Kopfzeile X-HL-Request über postJSON); ein vorgemerktes
Lösen zeigt der Hinweis mit dem Zeitpunkt, ab dem es wirkt (nächste Prüfung um 00:30 UTC).
"""

ENGINE_JS = r"""// 23.93 Trading Engine (U241): Reiter „Engine“ im TradeLabor -- Auswahl belegter Strategien, Papierkonto 100.000 USD (kein echtes Geld).
// Daten: /labor/engine (hl_engine.py, eigene engine.db); gefragt nur, solange der Reiter offen ist (mit dem Takt des Labors).
const ENG={d:null, vorher:false, alle:false, verlauf_alle:false, offen:{}, frage:false, sendet:false, meldung:''};
const ENG_F={aktiv:'#3fb950', pausiert:'#d29922', beobachtet:'#8b949e', beendet:'#6e7681', gescheitert:'#f85149', Bremse:'#f85149', 'läuft':'#3fb950'};
function engZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}).replace('-','−'); }
function engUsd(x){ return x==null||!isFinite(x)?'—':labUsd(x,0); }
function engWirksam(ts){ const P=1800, T=86400; return Math.ceil((ts-P)/T)*T+P; }   // erste Prüfung 00:30 UTC ab ts (wie hl_engine._loesen_wirksam)
function engTagUtc(ts){ return new Date(ts*1000).toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit',year:'2-digit',timeZone:'UTC'}); }
function engCss(){ if($('engcss')) return; const st=document.createElement('style'); st.id='engcss';
 st.textContent=`#sec-labor .enghinweis{border:1px solid #30363d;border-radius:6px;padding:6px 10px;margin:6px 0;color:#e6edf3;font-size:12px;line-height:1.45}
#sec-labor .engwarn{border-color:#d29922;color:#e3b341}
#sec-labor .engbadge{display:inline-block;border:1px solid currentColor;border-radius:10px;padding:0 7px;font-size:11px;font-weight:600;white-space:nowrap;margin:1px 0}
#sec-labor .enggrund{white-space:normal;min-width:220px;max-width:460px;font-size:11px;color:#c9d1d9;line-height:1.35}
#sec-labor .engbalken{display:inline-block;width:46px;height:6px;background:#21262d;border-radius:3px;vertical-align:middle;margin-left:5px;overflow:hidden}
#sec-labor .engbalken i{display:block;height:100%;background:#3987e5}
#sec-labor details.eng{margin:12px 0 4px}
#sec-labor details.eng > summary{cursor:pointer}
#sec-labor .engzeile{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:14px 0 4px}
#sec-labor #engbremse button{margin:6px 6px 0 0}
#sec-labor #engfrage{margin:8px 0 2px;padding:6px 8px;border:1px solid #f85149;border-radius:6px}
@media (max-width:700px){ #sec-labor .engm{display:none} #sec-labor .enggrund{min-width:170px;max-width:260px} }`;
 document.head.appendChild(st); }
async function labEngine(el){ engCss(); let d;
 try{ d=await getJSON('/labor/engine'); }catch(e){ if(!ENG.d) el.innerHTML='<div class="enghinweis engwarn">Trading Engine: keine Antwort vom Dashboard</div>'; return; }
 ENG.d=d; engZeichnen(el); }
// Kurzform für den Kopf des Labors (eigene Zeile „Engine“); d = /labor → engine
function labEngKopf(e){ if(!e) return '—<span class="d">startet mit dem Dashboard (Reiter „Engine“)</span>';
 if(e.fehler) return `—<span class="d">${esc(e.fehler)}</span>`;
 if(!e.begonnen) return `100.000 USD<span class="d">Konto beginnt ${e.start?hm(e.start):'—'} · aktiv ${e.aktiv||0} von ${e.n||0}</span>`;
 return `<span style="color:${labFarbe(e.netto)}">${engUsd(e.netto)} USD</span><span class="d">Konto ${engZ(e.kapital,0)} · aktiv ${e.aktiv||0} von ${e.n||0}${e.bremse?' · <span style="color:#f85149">Bremse gesetzt</span>':''} · Papier</span>`; }
function engZeichnen(el){ el=el||$('labbody'); const d=ENG.d; if(!el||!d||LAB.tab!=='engine') return;
 const di=d.dienst||{};
 if(d.ok===false){ labSetzen(el, `<div class="enghinweis engwarn">Trading Engine: ${esc(d.fehler||'Fehler')}</div>`+engRegeln(d)); return; }
 const S=d.strategien||[];
 if(!S.length){ labSetzen(el, `<div class="enghinweis">${esc(d.hinweis||'Noch kein Stand.')}${di.aus?' — <b>aus</b> (HL_ENGINE=0)':''}${di.fehler?'<br><span style="color:#d29922">'+esc(di.fehler)+'</span>':''}</div>`+engRegeln(d)); return; }
 labSetzen(el, engKopf(d)+engStrategien(d)+engProtokoll(d)+engVerlauf(d)+engTrades(d)+engRegeln(d)); }
function engKopf(d){ const K=d.konto||{}, V=d.vergleich||{}, S=d.strategien||[], n=d.kandidaten!=null?d.kandidaten:S.length, ab=d.abweichung||null, di=d.dienst||{}, A_=K.ausgelassen||{};
 const beob=n-(d.aktiv||0)-(d.pausiert||0);
 let h='';
 if(K.bremse) h+=engBremse(K); else { ENG.frage=false; ENG.meldung=''; }
 if(ab&&ab.gleich===false) h+=`<div class="enghinweis engwarn">Protokoll und Neuberechnung weichen ab: ${ab.nur_im_protokoll} gespeicherte Entscheidung(en) fehlen in der Neuberechnung (z. B. ${esc((ab.beispiel||[]).join(' · '))}).</div>`;
 h+=`<div class="kpi" id="engkpi" style="margin:6px 0 10px">`+[
  ['Engine-Konto', K.begonnen?`<span style="color:${labFarbe(K.netto)}">${engZ(K.kapital,0)} USD</span><span class="d">netto ${engUsd(K.netto)} seit ${hm(K.start)} · Start 100.000 · Papier</span>`
                            :`100.000 USD<span class="d">beginnt ${hm(K.start)} (00:00 UTC) · Papier</span>`],
  ['Größter Rückgang', `${engZ((K.groesster_rueckgang||0)*100,1)} %<span class="d">Höchststand ${engZ(K.hoch,0)} USD · Bremse bei 10 %</span>`],
  ['Strategien', `${d.aktiv||0} aktiv<span class="d">${d.pausiert||0} pausiert · ${beob} beobachtet · ${n} Kandidaten${d.gescheitert?` · <span style="color:${ENG_F.gescheitert}">${d.gescheitert} gescheitert</span>`:''}${d.fruehere?` · ${d.fruehere} frühere Regelversion${d.fruehere>1?'en':''}`:''}</span>`],
  ['Positionen', `${K.offen||0} von 10 offen<span class="d">${K.uebernommen||0} Trades übernommen · ausgelassen: Kapazität ${A_['Kapazität']||0}, Coin ${A_.Coin||0}, Richtung ${A_.Richtung||0}</span>`],
  ['Im selben Zeitraum', K.begonnen?`<span style="color:${labFarbe(V.labor_netto)}">${engUsd(V.labor_netto)} USD</span><span class="d">Labor gesamt (${V.labor_trades||0} Trades, je Strategie und Coin ein Konto) · Kandidaten ungefiltert ${engUsd(V.kandidaten_netto)} · Halten Long ${engUsd(V.halten_long_netto)}</span>`:'—<span class="d">ab dem Start des Kontos</span>'],
  ['Stand', `${hm(d.ts)}<span class="d">alle 10 min neu gerechnet · Ausfalltage ${d.ausfalltage||0}${ab?(ab.gleich?' · Protokoll stimmt':' · <span style="color:#f85149">Protokoll weicht ab</span>'):''}${di.fehler?' · <span style="color:#d29922">'+esc(di.fehler)+'</span>':''}</span>`],
 ].map(([k,v])=>`<div><span>${k}</span><b>${v}</b></div>`).join('')+'</div>';
 return h; }
// 23.94: Hinweis der Bremse mit dem Button „Bremse lösen“ (nur bei gesetzter Bremse; erst nach der Nachfrage auf der Seite gesendet)
function engBremse(K){ const vm=K.loesen_vorgemerkt;
 let h=`<div class="enghinweis engwarn" id="engbremse"><b>Bremse gesetzt</b> seit ${hm(K.bremse_seit)}: das Konto liegt mehr als 10&nbsp;% unter seinem Höchststand. Keine Aufnahme, kein neuer Trade; offene Positionen laufen zu Ende. `;
 if(vm) h+=`<b>Lösen vorgemerkt</b> am ${hm(vm)} — wirkt mit der Prüfung am ${hm(K.loesen_wirksam)} (00:30 UTC); bis dahin bleibt die Bremse gesetzt.`;
 else if(!ENG.frage) h+=`Weiter nur nach deiner Entscheidung:<br><button class="tog off" id="englosen" onclick="ENG.frage=true;ENG.meldung='';engZeichnen()">Bremse lösen …</button>`;
 else h+=`<div id="engfrage" role="alertdialog" aria-labelledby="engfragetext"><div id="engfragetext"><b>Bremse wirklich lösen?</b> Ab der Prüfung am ${hm(engWirksam(Date.now()/1000))} (00:30 UTC) gilt der Kontostand als neuer Höchststand; von der Bremse pausierte Strategien gelten dann als beobachtet, und alle nicht aktiven werden einmal nach (A)/(B) geprüft (nach einer eigenen Pause mit Abkühlung). Papier, kein echtes Geld.</div>`
  +`<button class="tog off" id="engja"${ENG.sendet?' disabled':''} onclick="engLoesen()">Ja, Bremse lösen</button><button class="tog off" id="engnein" onclick="ENG.frage=false;engZeichnen()">Abbrechen</button></div>`;
 if(ENG.meldung) h+=`<div class="sub" id="engmeldung" style="margin:4px 0 0">${esc(ENG.meldung)}</div>`;
 return h+'</div>'; }
async function engLoesen(){ if(ENG.sendet) return; ENG.sendet=true; engZeichnen(); let j;
 try{ j=await postJSON('/labor/engine/bremse_loesen?ja=1'); }catch(e){ j={ok:false, msg:'keine Antwort vom Dashboard'}; }
 ENG.sendet=false; ENG.frage=false; ENG.meldung=(j&&j.msg)||'';
 const el=$('labbody'); if(el&&LAB.tab==='engine') await labEngine(el); }
function engStrategien(d){ const S=(d.strategien||[]).slice(), ord={aktiv:0,pausiert:1,beobachtet:2,beendet:3};
 S.sort((a,b)=>((a.version&&a.version!=='aktuell')-(b.version&&b.version!=='aktuell'))||((ord[a.engine_zustand]||0)-(ord[b.engine_zustand]||0))||String(a.titel||a.name).localeCompare(String(b.titel||b.name),'de'));
 return `<div class="sub" style="margin:4px 0"><b>Strategien</b> — Zustand in der Engine (das Labor handelt alle weiter) · t (A): ganze Geschichte, t (B): letzte 17 Wochen · Überwachung: Pause-Summe in % ihrer Grenze · Ø steigend/fallend: Tagesmittel in USD in Monaten mit steigendem bzw. fallendem BTC · „beendet“: im Labor durch eine neue Regelversion abgelöst (ihre übernommenen Trades bleiben im Konto)</div>`
  +`<div class="labscroll"><table class="w" id="engtab"><tr><th>Strategie</th><th>Zustand</th><th>seit</th><th class="n engm">Wochen</th><th class="n engm">Trades</th><th class="n">t (A)</th><th class="n">t (B)</th><th class="n">Überwachung</th><th class="n engm">Ø steigend</th><th class="n engm">Ø fallend</th><th>Grund</th></tr>`
  +S.map(s=>{ const z=s.engine_zustand||'beobachtet', u=s.ueberwachung, a=u?Math.max(0,(u.anteil||0)*100):null;
   return `<tr data-sid="${esc(s.sid)}" data-zustand="${esc(z)}"><td><b>${esc(s.titel||s.name)}</b><span class="lz">${esc(s.gruppe||'')}</span></td>`
    +`<td><span class="engbadge" style="color:${ENG_F[z]||'#8b949e'}">${esc(z)}</span>${s.gescheitert?` <span class="engbadge" style="color:${ENG_F.gescheitert}">gescheitert</span>`:''}</td>`
    +`<td>${s.seit?dmy(s.seit):'—'}</td><td class="n engm">${s.wochen||0}</td><td class="n engm">${s.trades||0}</td>`
    +`<td class="n">${engZ(s.t_A,2)}</td><td class="n">${engZ(s.t_B,2)}</td>`
    +`<td class="n">${a==null?'—':`${engZ(Math.min(a,999),0)} %<span class="engbalken"><i style="width:${Math.min(100,a).toFixed(0)}%"></i></span>`}</td>`
    +`<td class="n engm" style="color:${labFarbe(s.mittel_auf)}">${engZ(s.mittel_auf,0)}</td><td class="n engm" style="color:${labFarbe(s.mittel_ab)}">${engZ(s.mittel_ab,0)}</td>`
    +`<td><div class="enggrund">${esc(s.grund||'')}</div></td></tr>`; }).join('')+'</table></div>'; }
function engProtokoll(d){ const titel={}; (d.strategien||[]).forEach(s=>{ titel[s.sid]=s.titel||s.name; });
 const alle=d.protokoll||[], nV=alle.filter(e=>e.vorher).length, P=alle.filter(e=>ENG.vorher?e.vorher:!e.vorher).slice().reverse();
 const N_=ENG.alle?Math.min(300,P.length):Math.min(20,P.length);
 let h=`<div class="engzeile"><span class="sub"><b>Entscheidungen</b> — neueste zuerst</span><button class="tog ${ENG.vorher?'off':'on'}" id="engprotseit" onclick="ENG.vorher=false;engZeichnen()">seit dem Start</button>`
  +`<button class="tog ${ENG.vorher?'on':'off'}" id="engprotvorher" onclick="ENG.vorher=true;engZeichnen()">Vorgeschichte (${nV})</button></div>`
  +(ENG.vorher?'<div class="sub" style="margin:0 0 4px">Vorgeschichte: dieselben Regeln auf die Labor-Trades vor dem Start des Kontos — so steht die Engine am ersten Tag nicht leer da (beschreibend).</div>':'');
 if(!P.length) return h+`<div class="sub">${ENG.vorher?'keine':'noch keine Entscheidung seit dem Start des Kontos'}</div>`;
 return h+`<div class="labscroll"><table class="w" id="engprot"><tr><th>Zeit</th><th>Strategie</th><th>alt → neu</th><th>Grund</th></tr>`
  +P.slice(0,N_).map(e=>`<tr><td>${hm(e.ts)}</td><td>${esc(titel[e.sid]||e.name)}</td><td>${esc(e.alt)} → <b style="color:${ENG_F[e.neu]||'#c9d1d9'}">${esc(e.neu)}</b></td><td><div class="enggrund">${esc(e.grund)}</div></td></tr>`).join('')
  +'</table></div>'+(P.length>20?`<div class="sub" style="margin:4px 0"><button class="tog off" id="engprotalle" onclick="ENG.alle=!ENG.alle;engZeichnen()">${ENG.alle?'nur die neuesten 20':'alle '+Math.min(300,P.length)+' zeigen'}</button></div>`:''); }
function engVerlauf(d){ const K=d.konto||{}, V=d.vergleich||{}; if(!K.begonnen) return '';
 const tage={}, add=(arr,k)=>(arr||[]).forEach(z=>{ const o=tage[z[0]]||(tage[z[0]]={}); o[k]=(o[k]||0)+(+z[1]||0); o[k+'n']=(o[k+'n']||0)+(+z[2]||0); });
 add(K.tage_netto,'e'); add(V.labor,'l'); add(V.kandidaten,'k'); add(V.halten_long,'h');
 const T=Object.keys(tage).map(Number).sort((a,b)=>a-b);
 const kopf=`<details class="eng" id="engverlauf"${ENG.offen.verlauf!==false?' open':''} ontoggle="ENG.offen.verlauf=this.open"><summary class="sub"><b>Kontoverlauf</b> — realisiert je UTC-Tag der Schließung, seit dem Start (USD); daneben im selben Zeitraum das Labor gesamt (jede Strategie und jeder Coin ein eigenes Konto), die Kandidaten ungefiltert und Halten Long</summary>`;
 if(!T.length) return kopf+'<div class="sub">noch kein geschlossener Trade seit dem Start</div></details>';
 let ce=0, cl=0, ck=0, ch=0;
 const Z=T.map(t=>{ const o=tage[t]; ce+=o.e||0; cl+=o.l||0; ck+=o.k||0; ch+=o.h||0; return {t, e:o.e||0, en:o.en||0, ce, cl, ck, ch}; }).reverse();
 const n=ENG.verlauf_alle?Z.length:Math.min(14,Z.length);
 return kopf+`<div class="labscroll"><table class="w" id="engverlauftab"><tr><th>Tag</th><th class="n">Engine</th><th class="n">Engine seit Start</th><th class="n">Labor gesamt</th><th class="n engm">Kandidaten ungefiltert</th><th class="n">Halten Long</th></tr>`
  +Z.slice(0,n).map(z=>`<tr><td>${engTagUtc(z.t)}</td><td class="n" style="color:${labFarbe(z.e)}">${engUsd(z.e)}<span class="lz">${z.en} Trades</span></td><td class="n" style="color:${labFarbe(z.ce)}">${engUsd(z.ce)}</td>`
   +`<td class="n" style="color:${labFarbe(z.cl)}">${engUsd(z.cl)}</td><td class="n engm" style="color:${labFarbe(z.ck)}">${engUsd(z.ck)}</td><td class="n" style="color:${labFarbe(z.ch)}">${engUsd(z.ch)}</td></tr>`).join('')
  +'</table></div>'+(Z.length>14?`<div class="sub" style="margin:4px 0"><button class="tog off" id="engverlaufalle" onclick="ENG.verlauf_alle=!ENG.verlauf_alle;engZeichnen()">${ENG.verlauf_alle?'nur 14 Tage':'alle '+Z.length+' Tage'}</button></div>`:'')+'</details>'; }
function engTrades(d){ const L=(d.konto||{}).letzte||[]; if(!L.length) return '';
 return `<details class="eng" id="engtrades"${ENG.offen.trades?' open':''} ontoggle="ENG.offen.trades=this.open"><summary class="sub"><b>Übernommene Trades</b> — die neuesten ${L.length}; gleiche Preise, Kosten und Ausstiege wie im Labor</summary>`
  +`<div class="labscroll"><table class="w" id="engtradetab"><tr><th>eröffnet</th><th>Strategie</th><th>Coin</th><th>Seite</th><th class="engm">geschlossen</th><th class="n">netto USD</th></tr>`
  +L.map(x=>`<tr><td>${hm(x.eroeffnet)}</td><td>${esc(x.name||x.sid)}</td><td><b>${esc(x.coin)}</b></td><td style="color:${x.seite==='long'?'#3fb950':'#f85149'}">${x.seite==='long'?'▲ Long':'▼ Short'}</td>`
   +`<td class="engm">${x.geschlossen?hm(x.geschlossen):'offen'}</td><td class="n" style="color:${labFarbe(x.netto_usd)}">${x.netto_usd==null?'—':engUsd(x.netto_usd)}</td></tr>`).join('')
  +'</table></div></details>'; }
function engRegeln(d){ const R=(d&&d.regeln)||{};
 return `<details class="eng" id="engregeln"${ENG.offen.regeln?' open':''} ontoggle="ENG.offen.regeln=this.open"><summary class="sub"><b>Regeln</b> — vorab festgelegt (KONZEPT_TradingEngine.md, Fassung 3); Papier, kein echtes Geld, keine Order</summary><div class="sub" style="margin:4px 0 6px;max-width:980px">`
  +`Die Engine wählt aus ${R.kandidaten||34} Strategien des Labors (Händler, Prognose, Familien, Ereignisse; höchstens 24 h Haltedauer) die belegten aus und übernimmt nur deren Trades — aus dem Labor ohne Notbremse, mit denselben Preisen, Kosten und Ausstiegen — auf ein gemeinsames Konto: 100.000 USD, 10.000 USD je Trade, höchstens 10 Positionen, 4 je Coin, 6 in dieselbe Richtung; ist kein Platz frei, wird der Trade ausgelassen und gezählt. `
  +`<b>Aufnahme</b> dienstags 00:30 UTC für die Woche bis Sonntag: (A) ganze Geschichte mit mindestens 9 Wochen, t der Wochensummen ≥ 4,0 und beide Hälften positiv, oder (B) die letzten 17 Wochen mit t ≥ 4,5 und beide Hälften positiv; je mindestens 30 Trades. Nach einer Pause frühestens nach 30 Tagen, über (A) nur mit positiver Summe seit der Pause; nach „gescheitert“ nur über (B). `
  +`<b>Pause</b> täglich 00:30 UTC: eine Summe in Handelszeit wächst, wenn die Strategie hinter der Hälfte ihres Vorsprungs bei der Aufnahme bleibt; ihre Grenze ist so gesetzt, dass eine unveränderte Strategie im Mittel erst nach zwei Jahren grundlos pausiert. Ein Tag ohne Trade ändert nichts. Offene Positionen laufen zu Ende. `
  +`<b>„gescheitert“</b> (Bezeichnung, wöchentlich): mindestens 13 Wochen und 90 Tage, t ≤ −3, beide Hälften negativ und das Tagesmittel negativ sowohl in Monaten mit steigendem als auch mit fallendem BTC (je mindestens 28 Tage) — dann liegt es nicht nur an der Marktphase. Das Labor handelt sie weiter; zurück nur über (B), danach zählt „gescheitert“ neu. `
  +`<b>Bremse</b>: fällt das Konto 10 % unter seinen Höchststand, pausiert die Engine alle Strategien; weiter nur nach deiner Entscheidung (Button „Bremse lösen“ im Hinweis oben, nur bei gesetzter Bremse, mit Nachfrage; wirkt ab der nächsten Prüfung um 00:30 UTC). `
  +`Ein Tag zählt erst, wenn alle seine Trades geschlossen sind; ein Tag, an dem das Labor länger als 1 h nicht lief, fehlt (bekannt erst ab dem Einspielen). Ist ein Trade 72 h nach dem Ende seines Tages noch offen, steht die Überwachung: Die Strategie pausiert, bis er geschlossen ist (ohne Abkühlung). Ändert das Labor die Regeln einer Strategie, endet die alte Kennung („beendet“), ihre übernommenen Trades bleiben im Konto; die neue beginnt von vorn. „Aufgenommen“ heißt vorläufig belegt, nicht bewiesen: Ohne jeden Vorsprung nahm die Engine in der Simulation in rund 23 % der Fälle binnen zwei Jahren mindestens eine Strategie grundlos auf (bei wanderndem Erfolg rund 50 %).</div></details>`; }
"""
