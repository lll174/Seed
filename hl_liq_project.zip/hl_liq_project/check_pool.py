#!/usr/bin/env python3
"""
check_pool.py -- Phase 0 des Konzepts "Aktive Profis": Wie groß ist der Kandidatenpool?

Liest die vollständige Leaderboard-Datei von Hyperliquid (dieselbe, die der Recorder stündlich für
die Top-75 lädt; ~40 MB, alle Konten mit Kontowert und PnL/ROI/Umsatz je Fenster) und zählt, ohne
etwas am System zu ändern:

  - Verteilung aller Konten nach Kontowert (>= 1 / 5 / 20 Mio) x Tagesumsatz (>= 100k / 500k / 5 Mio)
  - den Pool nach Konzept: Kontowert >= 1 Mio UND Tagesumsatz >= 500k -- Größe, ROI-Verteilung (7 T),
    Anteil mit positivem Wochengewinn, Überlappung mit der heutigen Top-75-Auswahl, Vault-Anteil
  - die 30 umsatzstärksten Pool-Konten als Stichprobe (Name, Kontowert, Umsatz 1 T, PnL 7 T, ROI 7 T)
  - Kosten des Pools: REST-Nachtrag je 12 h (20 Gewicht je Konto) und geschätzte Stream-Zeilen

    python3 check_pool.py [--min-value 1e6] [--min-vlm 5e5] [--deckel 500] [--db PFAD]
"""
import argparse
import json
import sqlite3
import statistics
import time
import urllib.request

LEADERBOARD_URL = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard"


def lade() -> list:
    req = urllib.request.Request(LEADERBOARD_URL, headers={"User-Agent": "hl_liq_project/check_pool"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as r:
        raw = r.read()
    data = json.loads(raw)
    rows = data.get("leaderboardRows") if isinstance(data, dict) else data
    print(f"Leaderboard-Datei: {len(raw) / 1e6:.1f} MB, {len(rows):,} Konten, geladen in {time.time() - t0:.1f} s")
    return rows


def konto(row) -> dict:
    wp = {w: v for w, v in (row.get("windowPerformances") or [])}
    f = lambda w, k: float((wp.get(w) or {}).get(k) or 0)
    return {"addr": str(row.get("ethAddress", "")).lower(), "name": row.get("displayName") or "",
            "av": float(row.get("accountValue") or 0),
            "vlm_1d": f("day", "vlm"), "vlm_7d": f("week", "vlm"), "vlm_30d": f("month", "vlm"),
            "pnl_1d": f("day", "pnl"), "pnl_7d": f("week", "pnl"), "pnl_30d": f("month", "pnl"),
            "roi_7d": f("week", "roi"), "roi_30d": f("month", "roi"),
            "vault": bool(row.get("isVault") or row.get("vaultAddress") or (row.get("displayName") or "").lower().startswith("vault"))}


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--min-value", type=float, default=1e6, help="Mindest-Kontowert USD (Konzept: 1 Mio)")
    p.add_argument("--min-vlm", type=float, default=5e5, help="Mindest-Tagesumsatz USD (Konzept: 500k)")
    p.add_argument("--deckel", type=int, default=500, help="Deckel nach Umsatz, falls der Pool größer ist")
    p.add_argument("--db", help="Hauptdatenbank (für die Überlappung mit der Top-75-Auswahl)")
    a = p.parse_args()
    rows = lade()
    K = [konto(r) for r in rows]
    K = [k for k in K if k["addr"]]

    print("\n1. Verteilung aller Konten (Kontowert × Tagesumsatz)")
    print(f"   {'Kontowert':<14}{'alle':>8}{'≥100k/T':>10}{'≥500k/T':>10}{'≥5 Mio/T':>10}")
    for lab, lo in (("≥ 1 Mio", 1e6), ("≥ 5 Mio", 5e6), ("≥ 20 Mio", 20e6), ("≥ 100 Mio", 100e6)):
        g = [k for k in K if k["av"] >= lo]
        print(f"   {lab:<14}{len(g):>8}{sum(1 for k in g if k['vlm_1d'] >= 1e5):>10}{sum(1 for k in g if k['vlm_1d'] >= 5e5):>10}{sum(1 for k in g if k['vlm_1d'] >= 5e6):>10}")

    pool = sorted([k for k in K if k["av"] >= a.min_value and k["vlm_1d"] >= a.min_vlm], key=lambda k: -k["vlm_1d"])
    n_vault = sum(1 for k in pool if k["vault"])
    print(f"\n2. Pool nach Konzept: Kontowert ≥ {a.min_value / 1e6:.0f} Mio und Tagesumsatz ≥ {a.min_vlm / 1e3:.0f}k")
    print(f"   {len(pool):,} Konten (davon als Vault erkennbar: {n_vault})"
          + (f" — über dem Deckel {a.deckel}: es zählen die {a.deckel} umsatzstärksten" if len(pool) > a.deckel else ""))
    if pool:
        roi = sorted(k["roi_7d"] for k in pool)
        q = lambda x: roi[min(len(roi) - 1, int(len(roi) * x))]
        print(f"   ROI 7 T: Median {statistics.median(roi) * 100:+.1f} % · Quartile {q(0.25) * 100:+.1f} % / {q(0.75) * 100:+.1f} % · "
              f"positiv: {sum(1 for r in roi if r > 0) / len(roi) * 100:.0f} %")
        print(f"   Wochengewinn > 0: {sum(1 for k in pool if k['pnl_7d'] > 0)} · Umsatz 7 T Median {statistics.median(k['vlm_7d'] for k in pool) / 1e6:.1f} Mio · "
              f"Kontowert Median {statistics.median(k['av'] for k in pool) / 1e6:.1f} Mio")
        # Aktivitäts-Näherung aus der Datei: Umsatz 7 T relativ zum Kontowert (Umschlag) -- passive Halter liegen nahe 0
        umschlag = sorted(k["vlm_7d"] / max(k["av"], 1) for k in pool)
        print(f"   Umschlag 7 T (Umsatz/Kontowert): Median {statistics.median(umschlag):.1f}× · unter 0,5× (eher passiv): "
              f"{sum(1 for u in umschlag if u < 0.5)} Konten")
    if a.db:
        try:
            con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
            last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
            top = {r[0].lower() for r in con.execute("SELECT addr FROM lb_accounts WHERE ts=?", (last,))} if last else set()
            print(f"   Überlappung mit der heutigen Top-75-Auswahl: {sum(1 for k in pool if k['addr'] in top)} von {len(top)}")
            con.close()
        except sqlite3.Error as e:
            print(f"   (Überlappung nicht prüfbar: {e})")

    n_eff = min(len(pool), a.deckel)
    print(f"\n3. Kosten bei {n_eff} Pool-Konten")
    print(f"   REST-Nachtrag closedPnl je 12 h: {n_eff * 20:,} Gewicht (Rang 3) ≈ {n_eff * 20 / 1080:.1f} min des Budgets")
    print(f"   Stream-Fills: 0 Gewicht; Speicher grob {n_eff} Konten × ~50 Fills/Tag × 14 Tage ≈ {n_eff * 50 * 14 / 1000:.0f}k Zeilen")

    print(f"\n4. Stichprobe: die 30 umsatzstärksten Pool-Konten")
    print(f"   {'Konto':<18}{'Kontowert':>11}{'Umsatz 1T':>11}{'PnL 7T':>10}{'ROI 7T':>8}{'Umschlag':>9}  Vault")
    for k in pool[:30]:
        nm = (k["name"][:16] if k["name"] else k["addr"][:6] + "…" + k["addr"][-4:])
        print(f"   {nm:<18}{k['av'] / 1e6:>9.1f} M{k['vlm_1d'] / 1e6:>9.1f} M{k['pnl_7d'] / 1e6:>+8.2f} M{k['roi_7d'] * 100:>+7.1f}%{k['vlm_7d'] / max(k['av'], 1):>8.1f}×  {'ja' if k['vault'] else ''}")
    print("\nLesart: Der Pool ist ein Filter, kein Rang. Umschlag < 0,5× deutet auf Halter, die die Aktivitätsregel (≥ 5 Trades/Tag)")
    print("        später ohnehin aussortiert -- die echte Zählung kommt erst mit den Fills (Phase 1/2).")


if __name__ == "__main__":
    main()
