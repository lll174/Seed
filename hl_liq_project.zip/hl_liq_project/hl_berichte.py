#!/usr/bin/env python3
"""
hl_berichte.py -- Berichtsplan: Läufe „X Minuten nach dem Einspielen“ (U267) und Benachrichtigung über neue Berichte (U268).

Paket 23.109, Auftrag des Nutzers vom 17.11.2026: Neue Pakete sollen ihre Debug-Läufe selbst mitbringen. Das Dashboard kann nicht
wissen, wann ein Paket eingespielt wird -- also zählt der Plan ab dem Einspielen. Der Berichtsplan in hl_viz.py kennt neben
„einmal“ und „woechentlich“ die Art „nach_update“ (Paketversion, Minuten). Sind die Läufe eines Termins fertig, meldet sich das
Dashboard: ein Hinweis oben auf der Seite und, wenn eingerichtet, eine Push-Nachricht aufs Handy über ntfy (Entscheidung des
Nutzers vom 17.11.2026: beides).

Hier liegt, was sich ohne Dashboard prüfen lässt:
  - Versionsvergleich, Erkennen eines Einspielens (Versionswechsel gegen berichte/.stand.json), Fälligkeit der Läufe
  - Prüfung der Planliste (jeder Eintrag genau eine Art, Version lesbar und nicht aus der Zukunft, Minuten, Zeitgrenzen)
  - Benachrichtigung: Thema erzeugen und in accesstokens.json ablegen, Nachricht bauen, senden, Fehlversuche wiederholen,
    Verlauf der letzten Meldungen (berichte/.melden.json)
  - der Text von Debug 151 (Stand des Berichtsplans)

Gesendet wird nur ein kurzer Text: wie viele Berichte, aus welchem Anlass, welche Debug-Nummern. Nie der Inhalt eines Berichts, nie
eine Adresse dieses Rechners. Ohne eingerichtetes Thema wird nichts gesendet. Das Thema ist bei ntfy das gemeinsame Geheimnis von
Sender und Empfänger: Es wird zufällig erzeugt, liegt nur in accesstokens.json und steht in keiner Meldung, keinem Bericht und
keiner Fehlermeldung.

Aufruf: python3 hl_berichte.py --selbsttest
"""
from __future__ import annotations

import json
import os
import re
import secrets
import sys
import time
import urllib.error
import urllib.request

VERSION_MODUL = "2026-09-23.125"

# ---- Läufe nach dem Einspielen (U267)
NACH_UPDATE_MINUTEN = 10                 # Vorgabe: so viele Minuten nach dem Einspielen starten die Läufe eines Pakets
MINUTEN_MAX = 24 * 60
GRENZE_MIN_S, GRENZE_MAX_S = 60, 2 * 3600    # erlaubte eigene Zeitgrenze eines Laufs im Plan
UPDATES_VERLAUF = 10

# ---- Benachrichtigung (U268)
NTFY_SERVER = "https://ntfy.sh"
THEMA_VORSATZ = "hyperbit-"
THEMA_RE = re.compile(r"[A-Za-z0-9_-]{16,64}")   # ntfy erlaubt Buchstaben, Ziffern, _ und -, höchstens 64 Zeichen; hier mindestens 16
MELDEN_VERSUCHE = 5                      # so oft wird eine Meldung versucht, die der Dienst nicht annimmt (je Runde des Plans einmal)
MELDEN_VERLAUF = 10
MELDEN_TIMEOUT_S = 10
TITEL_MAX = 120
TEXT_MAX = 1000                          # ntfy nimmt bis 4.096 Bytes je Nachricht; hier bleibt es weit darunter
NRN_MAX = 8                              # so viele Debug-Nummern nennt eine Meldung höchstens
TOKENS_DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
WOFUER = ("Benachrichtigung über neue Berichte (Push über ntfy; das Thema ist das gemeinsame Geheimnis von Dashboard und Handy-App "
          "-- im Dashboard unter Debug, Berichtsplan, einrichten oder abschalten)")


# ================================================================================================ Version und Einspielen

def version_schluessel(v) -> tuple | None:
    """'2026-09-23.108' -> ('2026-09-23', 108). Die Paketnummer zählt als Zahl (99 vor 100). Nicht lesbar: None."""
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})\.(\d+)", str(v or "").strip())
    return (m.group(1), int(m.group(2))) if m else None


def paket_kurz(v) -> str:
    """'2026-09-23.108' -> '23.108' (so heißen die Pakete im Gespräch). Nicht lesbar: der Text selbst."""
    k = version_schluessel(v)
    return f"{k[0][-2:]}.{k[1]}" if k else str(v or "?")


def minuten(e: dict) -> int:
    """Minuten nach dem Einspielen für einen Eintrag der Art nach_update (Vorgabe NACH_UPDATE_MINUTEN, begrenzt auf 1 … MINUTEN_MAX)."""
    try:
        m = int(e.get("minuten", NACH_UPDATE_MINUTEN))
    except (TypeError, ValueError):
        m = NACH_UPDATE_MINUTEN
    return max(1, min(MINUTEN_MAX, m))


def trifft(paket, von, auf) -> bool:
    """
    Gehört ein Eintrag für `paket` zu dem Einspielen von `von` auf `auf`? Ja, wenn das Einspielen das Paket neu gebracht hat:
    von < paket <= auf. Ist `von` unbekannt (erster Lauf mit diesem Mechanismus, frische Installation), zählt nur das eigene Paket
    -- sonst liefen nach einer Neuinstallation die Läufe aller früheren Pakete auf einmal.
    """
    p, a, v = version_schluessel(paket), version_schluessel(auf), version_schluessel(von)
    if p is None or a is None:
        return False
    if v is None:
        return p == a
    return v < p <= a


def erledigt(e: dict, stand: dict) -> bool:
    """Ein Eintrag der Art nach_update ist erledigt, wenn sein Vermerk mindestens so groß ist wie seine Fälligkeit."""
    f = stand.get(e["id"] + ":faellig")
    return isinstance(f, (int, float)) and (stand.get(e["id"]) or 0) >= f


def update_erkennen(stand: dict, version: str, plan: list, now: int) -> dict | None:
    """
    Vergleicht die Version dieses Rechners mit der zuletzt gesehenen (stand["version"]). Bei einem Wechsel: Einträge der Art
    nach_update, die das Einspielen neu gebracht hat, werden fällig (jetzt + ihre Minuten). Offene Einträge früherer Pakete behalten
    seit 23.125 (U313) ihren Termin, frühestens aber NACH_UPDATE_MINUTEN nach diesem Einspielen (die Dienste starten gerade neu); bis
    23.124 begann ihre Frist neu -- „einen Tag später“ kam so bei täglichem Einspielen nie (vom 20.11. bis zum 25.11.2026).
    Verändert `stand`; der Aufrufer speichert. -> {"von", "auf", "ts", "faellig": [Kennungen]} oder None (kein Wechsel, Version
    nicht lesbar).
    """
    alt = stand.get("version")
    if alt == version or version_schluessel(version) is None:
        return None
    now = int(now)
    faellig = []
    for e in plan:
        if "nach_update" not in e:
            continue
        f = stand.get(e["id"] + ":faellig")
        offen = isinstance(f, (int, float)) and not erledigt(e, stand)
        if trifft(e["nach_update"], alt, version):
            stand[e["id"] + ":faellig"] = now + minuten(e) * 60
            faellig.append(e["id"])
        elif offen:                                                       # 23.125 (U313): Termin behalten, frühestens 10 Minuten nach jetzt
            stand[e["id"] + ":faellig"] = max(int(f), now + NACH_UPDATE_MINUTEN * 60)
            faellig.append(e["id"])
    ev = {"von": alt, "auf": version, "ts": now}
    stand["version"] = version
    stand["update"] = ev
    stand["updates"] = (list(stand.get("updates") or []) + [ev])[-UPDATES_VERLAUF:]
    return dict(ev, faellig=faellig)


def termine_nach_update(e: dict, stand: dict, now: int) -> tuple:
    """(Fälligkeit, wenn sie erreicht ist, sonst None; Fälligkeit, wenn sie noch kommt, sonst None) -- wie _plan_termine in hl_viz."""
    f = stand.get(e["id"] + ":faellig")
    if not isinstance(f, (int, float)):
        return None, None
    f = int(f)
    return (f if f <= now else None), (f if f > now else None)


def plan_pruefen(plan: list, version: str, laeufe_bekannt=None) -> list:
    """Fehler der Planliste als Texte (leer = in Ordnung): Kennungen eindeutig, je Eintrag genau eine Art, nach_update lesbar und nicht
    neuer als dieses Paket, Minuten 1 … MINUTEN_MAX, eigene Zeitgrenzen nur für Läufe des Eintrags und im erlaubten Bereich."""
    f = []
    ids = [e.get("id") for e in plan]
    for i in sorted({i for i in ids if ids.count(i) > 1}, key=str):
        f.append(f"Kennung {i} doppelt")
    vk = version_schluessel(version)
    for e in plan:
        i = e.get("id")
        arten = [k for k in ("einmal", "woechentlich", "nach_update") if k in e]
        if len(arten) != 1:
            f.append(f"{i}: {len(arten)} Arten ({', '.join(arten) or 'keine'}) statt einer")
        if not e.get("laeufe") or not e.get("zweck"):
            f.append(f"{i}: ohne Läufe oder ohne Zweck")
        if laeufe_bekannt is not None:
            fremd = [n for n in e.get("laeufe") or [] if n not in laeufe_bekannt]
            if fremd:
                f.append(f"{i}: unbekannte Läufe {fremd}")
        if "nach_update" in e:
            pk = version_schluessel(e["nach_update"])
            if pk is None:
                f.append(f"{i}: Paketversion {e['nach_update']!r} nicht lesbar")
            elif vk is not None and pk > vk:
                f.append(f"{i}: Paket {e['nach_update']} ist neuer als dieses Paket ({version})")
            m = e.get("minuten", NACH_UPDATE_MINUTEN)
            if not isinstance(m, int) or isinstance(m, bool) or not 1 <= m <= MINUTEN_MAX:
                f.append(f"{i}: Minuten {m!r} außerhalb 1 … {MINUTEN_MAX}")
        elif "minuten" in e:
            f.append(f"{i}: Minuten nur bei der Art nach_update")
        g = e.get("grenze_s")
        if g is not None:
            if not isinstance(g, dict):
                f.append(f"{i}: grenze_s ist keine Zuordnung Lauf -> Sekunden")
            else:
                for n, s in g.items():
                    if n not in (e.get("laeufe") or []):
                        f.append(f"{i}: Zeitgrenze für {n}, der nicht zu den Läufen gehört")
                    if not isinstance(s, int) or isinstance(s, bool) or not GRENZE_MIN_S <= s <= GRENZE_MAX_S:
                        f.append(f"{i}: Zeitgrenze {s!r} für {n} außerhalb {GRENZE_MIN_S} … {GRENZE_MAX_S} s")
    return f


# ================================================================================================ Benachrichtigung über ntfy

def thema_gueltig(t) -> bool:
    return isinstance(t, str) and bool(THEMA_RE.fullmatch(t))


def thema_neu() -> str:
    """Zufälliges Thema: 96 Bit aus dem Zufallsgenerator des Betriebssystems, 33 Zeichen."""
    return THEMA_VORSATZ + secrets.token_hex(12)


def thema_ende(t) -> str:
    """Nur die letzten vier Zeichen -- für Anzeigen und Berichte, die das Thema nicht verraten dürfen."""
    return ("…" + t[-4:]) if thema_gueltig(t) else ""


def _roh_lesen(datei: str) -> tuple:
    """(Inhalt als dict, Fehlertext oder None). Fehlende Datei: ({}, None)."""
    if not os.path.exists(datei):
        return {}, None
    try:
        with open(datei, encoding="utf-8") as f:
            roh = json.load(f)
    except (OSError, ValueError) as e:
        return {}, f"{os.path.basename(datei)} ist nicht lesbar ({type(e).__name__})"
    if not isinstance(roh, dict):
        return {}, f"{os.path.basename(datei)} hat kein JSON-Objekt"
    return roh, None


def einstellung_lesen(datei: str | None = None) -> dict:
    """{"thema": Thema oder "", "server": Adresse des ntfy-Servers} aus accesstokens.json -> "ntfy". Ungültiges zählt als nicht da."""
    roh, _fehler = _roh_lesen(datei or TOKENS_DATEI)
    e = roh.get("ntfy") if isinstance(roh.get("ntfy"), dict) else {}
    thema = e.get("thema") if thema_gueltig(e.get("thema")) else ""
    server = str(e.get("server") or "").strip().rstrip("/")
    if not re.fullmatch(r"https?://[A-Za-z0-9.\-]+(:\d{1,5})?(/[A-Za-z0-9._~/\-]*)?", server):
        server = NTFY_SERVER
    return {"thema": thema, "server": server}


def thema_setzen(thema: str, datei: str | None = None) -> tuple:
    """
    Thema in accesstokens.json -> "ntfy" -> "thema" eintragen; "" entfernt es (Benachrichtigung aus). Übrige Einträge bleiben, die
    Datei wird atomar ersetzt, eine neue Datei bekommt die Rechte 600, eine vorhandene behält ihre. Eine nicht lesbare Datei wird
    nicht überschrieben. -> (ok, Meldung); die Meldung nennt das Thema nie.
    """
    datei = datei or TOKENS_DATEI
    if thema and not thema_gueltig(thema):
        return False, "Thema ungültig: erlaubt sind 16 bis 64 Zeichen aus Buchstaben, Ziffern, _ und -. Nichts geschrieben."
    roh, fehler = _roh_lesen(datei)
    if fehler:
        return False, fehler + " -- nichts überschrieben. Bitte die Datei prüfen."
    eintrag = dict(roh.get("ntfy")) if isinstance(roh.get("ntfy"), dict) else {}
    if thema:
        eintrag["thema"] = thema
        eintrag.setdefault("_wofuer", WOFUER)
        roh["ntfy"] = eintrag
    else:
        eintrag.pop("thema", None)
        if any(not k.startswith("_") for k in eintrag):
            roh["ntfy"] = eintrag                                        # ein eigener Server bleibt eingetragen
        else:
            roh.pop("ntfy", None)
    modus = (os.stat(datei).st_mode & 0o777) if os.path.exists(datei) else 0o600
    tmp = datei + ".tmp"
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(roh, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.chmod(tmp, modus)
        os.replace(tmp, datei)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False, f"{os.path.basename(datei)} nicht schreibbar ({type(e).__name__}). Nichts geändert."
    return True, ("Thema gespeichert." if thema else "Benachrichtigung abgeschaltet, Thema gelöscht.")


def _http_post(url: str, rumpf: bytes, timeout: float) -> tuple:
    """(Status, Antworttext). Ein HTTP-Fehler ist ein Status, kein Absturz; Netzfehler werfen."""
    req = urllib.request.Request(url, data=rumpf, method="POST",
                                 headers={"Content-Type": "application/json; charset=utf-8", "User-Agent": "hl-dashboard/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(2000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            text = e.read(2000).decode("utf-8", "replace")
        except Exception:
            text = ""
        return e.code, text


def senden(thema: str, titel: str, text: str, server: str = NTFY_SERVER, http_fn=None, prio: int = 3,
           tags: tuple = ("page_facing_up",)) -> tuple:
    """
    Eine Nachricht an ein ntfy-Thema: POST an die Wurzel des Servers mit JSON-Rumpf (UTF-8; Umlaute stehen im Rumpf, nicht in
    Kopfzeilen). -> (ok, Fehlertext oder None). Der Fehlertext nennt das Thema nie. Kein gültiges Thema: nichts gesendet.
    """
    if not thema_gueltig(thema):
        return False, "kein gültiges Thema eingerichtet"
    rumpf = json.dumps({"topic": thema, "title": str(titel)[:TITEL_MAX], "message": str(text)[:TEXT_MAX], "tags": list(tags),
                        "priority": int(prio)}, ensure_ascii=False).encode("utf-8")
    try:
        status, antwort = (http_fn or _http_post)(str(server).rstrip("/") + "/", rumpf, MELDEN_TIMEOUT_S)
    except Exception as e:
        return False, f"{type(e).__name__}: {e}".replace(thema, "***")[:160]
    if status == 200:
        return True, None
    return False, f"HTTP {status}: {str(antwort).strip()[:120]}".replace(thema, "***")


def bericht_zeit(name: str) -> int | None:
    """Beginn eines Berichts aus seinem Dateinamen „JJJJ-MM-TT_HH-MM_<lauf>.txt“ (Ortszeit des Rechners, auf die Minute); sonst None."""
    try:
        return int(time.mktime(time.strptime(str(name)[:16], "%Y-%m-%d_%H-%M")))
    except (ValueError, OverflowError):
        return None


def hinweis_beginnen(stand: dict, now) -> bool:
    """
    U268: Ab wann der Hinweis im Kopf der Seite zählt (Vermerk „hinweis_ab“) -- einmal gesetzt, in der ersten Runde des Plans mit
    diesem Code. Berichte von davor lösen keinen Hinweis aus, auch wenn sie nie abgeholt wurden: Sonst stünde nach dem ersten
    Einspielen sofort ein Hinweis über alles da, was sich seit Wochen angesammelt hat. -> True, wenn der Vermerk gerade gesetzt wurde.
    """
    ab = stand.get("hinweis_ab")
    if isinstance(ab, (int, float)) and not isinstance(ab, bool):
        return False
    stand["hinweis_ab"] = int(now)
    return True


def hinweis_zaehlt(name: str, abgeholt, hinweis_ab) -> bool:
    """
    U268: Zählt dieser Bericht für den Hinweis im Kopf der Seite? Ja, wenn er aus dem Plan stammt (kein Handlauf „…_manuell.txt“),
    noch nicht abgeholt ist und in oder nach der Minute begann, in der der Hinweis eingeführt wurde. Ohne Vermerk zählt nichts.
    """
    if not isinstance(hinweis_ab, (int, float)) or isinstance(hinweis_ab, bool):
        return False
    if str(name).endswith("_manuell.txt") or name in (abgeholt or {}):
        return False
    t = bericht_zeit(name)
    return t is not None and t >= (int(hinweis_ab) // 60) * 60


def laeufe_der_runde(eintraege) -> list:
    """
    U276: die Läufe einer Runde -- aller zugleich fälligen Einträge -- ohne Wiederholung, in der Reihenfolge des Plans. Steht ein Lauf
    in mehreren fälligen Einträgen (am 19.11.2026 Debug 143 und 71 in den Einträgen dreier Pakete), startet er einmal.
    """
    namen = []
    for e in eintraege or []:
        for n in (e.get("laeufe") or []):
            if n not in namen:
                namen.append(n)
    return namen


def hinweis_stand(neu_geplant, runde, faellig_offen) -> dict:
    """
    U276: Was der Hinweis im Kopf der Seite zeigt. „Herunterladen“ (Art „bereit“) nur, wenn keine Runde des Plans läuft und kein
    fälliger Eintrag offen ist -- bis 23.112 erschien der Knopf mit dem ersten fertigen Bericht, die übrigen Läufe liefen noch.
      runde = {"gesamt": m, "fertig": k} solange eine Runde läuft -> Art „runde“ (k von m Läufen fertig)
      faellig_offen = Zahl der fälligen, noch nicht gelaufenen Einträge (der Plan wartet, z. B. auf einen Handlauf) -> Art „wartet“
      sonst neu_geplant > 0 -> Art „bereit“ mit der Zahl der Berichte; sonst „nichts“.
    """
    try:
        g = int((runde or {}).get("gesamt") or 0); k = int((runde or {}).get("fertig") or 0)
    except (TypeError, ValueError, AttributeError):
        g = k = 0
    if g > 0:
        return {"art": "runde", "fertig": max(0, min(k, g)), "gesamt": g}
    if int(faellig_offen or 0) > 0:
        return {"art": "wartet", "termine": int(faellig_offen)}
    if int(neu_geplant or 0) > 0:
        return {"art": "bereit", "n": int(neu_geplant)}
    return {"art": "nichts"}


def meldung_bauen(eintrag, nrn: list, n_berichte: int, n_fehler: int) -> tuple:
    """
    (Titel, Text) der Meldung nach einer fertigen Runde des Plans. Enthält: Zahl der Berichte, Anlass, Debug-Nummern (höchstens
    NRN_MAX), Zahl der Läufe mit Fehler, und wo die Berichte im Dashboard zu holen sind. Kein Inhalt eines Berichts, keine Adresse.
    23.113 (U276): eintrag ist ein Eintrag oder die Liste der Einträge einer Runde -- eine Meldung je Runde, wenn alles fertig ist.
    """
    eintraege = list(eintrag) if isinstance(eintrag, (list, tuple)) else [eintrag]
    eins = n_berichte == 1
    titel = f"HyperBit: {n_berichte} neue{'r' if eins else ''} Bericht{'' if eins else 'e'}"
    pakete = []
    for e_ in eintraege:
        if "nach_update" in e_ and paket_kurz(e_["nach_update"]) not in pakete:
            pakete.append(paket_kurz(e_["nach_update"]))
    if pakete and all("nach_update" in e_ for e_ in eintraege):
        if len(pakete) == 1:
            anlass = f"Paket {pakete[0]} ist eingespielt, die Läufe danach sind fertig"
        else:
            anlass = f"Die Pakete {', '.join(pakete[:-1])} und {pakete[-1]} sind eingespielt, die Läufe danach sind fertig"
    elif len(eintraege) > 1:
        anlass = f"{len(eintraege)} Termine des Berichtsplans sind gelaufen"
    elif "woechentlich" in eintraege[0]:
        anlass = "Der Wochentermin des Berichtsplans ist gelaufen"
    else:
        anlass = "Ein Termin des Berichtsplans ist gelaufen"
    nrn = [n for n in nrn if n]
    if nrn:
        anlass += " (Debug " + ", ".join(str(n) for n in nrn[:NRN_MAX]) + (" …" if len(nrn) > NRN_MAX else "") + ")"
    teile = [anlass + "."]
    if n_fehler:
        teile.append(f"{n_fehler} davon mit Fehler oder Abbruch.")
    teile.append("Im Dashboard steht oben der Hinweis mit „Herunterladen“.")
    return titel[:TITEL_MAX], " ".join(teile)[:TEXT_MAX]


def zustand_lesen(ordner: str) -> dict:
    """berichte/.melden.json: {"verlauf": [letzte Meldungen], "offen": Meldung, die der Dienst noch nicht angenommen hat, oder None}."""
    try:
        with open(os.path.join(ordner, ".melden.json"), encoding="utf-8") as f:
            z = json.load(f)
    except (OSError, ValueError):
        z = {}
    if not isinstance(z, dict):
        z = {}
    return {"verlauf": [v for v in (z.get("verlauf") or []) if isinstance(v, dict)][-MELDEN_VERLAUF:],
            "offen": z.get("offen") if isinstance(z.get("offen"), dict) else None}


def zustand_schreiben(ordner: str, z: dict) -> None:
    os.makedirs(ordner, exist_ok=True)
    tmp = os.path.join(ordner, ".melden.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(z, f, ensure_ascii=False)
    os.replace(tmp, os.path.join(ordner, ".melden.json"))


def _versuch(z: dict, m: dict, now: int, einst: dict, http_fn) -> bool:
    """Einen Sendeversuch für die Meldung m buchen: vom Dienst angenommen -> Verlauf; sonst offen, nach MELDEN_VERSUCHE aufgegeben -> Verlauf."""
    ok, fehler = senden(einst["thema"], m["titel"], m["text"], einst["server"], http_fn)
    m = dict(m, versuche=int(m.get("versuche") or 0) + 1)
    if ok or m["versuche"] >= MELDEN_VERSUCHE:
        z["verlauf"] = (z["verlauf"] + [{"ts": int(now), "titel": m["titel"], "ok": bool(ok), "fehler": fehler,
                                         "versuche": m["versuche"]}])[-MELDEN_VERLAUF:]
        z["offen"] = None
    else:
        z["offen"] = dict(m, fehler=fehler, letzter_versuch=int(now))
    return bool(ok)


def melden(ordner: str, titel: str, text: str, now: int, datei: str | None = None, http_fn=None) -> dict:
    """
    Eine Meldung senden. Ohne eingerichtetes Thema geschieht nichts (kein Abruf, kein Eintrag). Scheitert das Senden, bleibt die
    Meldung offen und melden_offen versucht sie wieder; eine ältere offene Meldung wird von der neuen ersetzt (die neue nennt den
    aktuellen Stand). -> {"eingerichtet": bool, "gesendet": bool}
    """
    einst = einstellung_lesen(datei)
    if not einst["thema"]:
        return {"eingerichtet": False, "gesendet": False}
    z = zustand_lesen(ordner)
    ok = _versuch(z, {"titel": titel, "text": text, "seit": int(now), "versuche": 0}, now, einst, http_fn)
    zustand_schreiben(ordner, z)
    return {"eingerichtet": True, "gesendet": ok}


def melden_offen(ordner: str, now: int, datei: str | None = None, http_fn=None) -> bool | None:
    """Eine offene Meldung noch einmal versuchen. -> None (nichts offen oder kein Thema mehr), sonst ob der Dienst sie angenommen hat."""
    z = zustand_lesen(ordner)
    if not z["offen"]:
        return None
    einst = einstellung_lesen(datei)
    if not einst["thema"]:
        z["offen"] = None                                                # abgeschaltet: nichts nachsenden
        zustand_schreiben(ordner, z)
        return None
    ok = _versuch(z, z["offen"], now, einst, http_fn)
    zustand_schreiben(ordner, z)
    return ok


# ================================================================================================ Text von Debug 151

def _zeit(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(int(ts))) if isinstance(ts, (int, float)) and ts else "—"


def stand_text(plan: list, stand: dict, version: str, pruefsumme: str, now: int, neu: int, neu_geplant: int, einstellung: dict,
               zustand: dict, nr_von=None, termine_fn=None, aktiv: bool | None = None, runde: dict | None = None,
               faellig_offen: int = 0) -> str:
    """
    Stand des Berichtsplans als Text (Debug 151): Version, letztes erkanntes Einspielen, Läufe nach dem Einspielen mit Stand, die
    nächsten Termine nach Zeitplan, neue Berichte, Benachrichtigung (ohne das Thema zu nennen) mit den letzten Meldungen.
    nr_von(Lauf) -> Debug-Nummer; termine_fn(Eintrag, now) -> (letzter, nächster) für die Arten einmal und woechentlich.
    """
    nr_von = nr_von or (lambda n: None)
    Z = []; a = Z.append
    a(f"★ Berichtsplan: Stand (U267, U268) · Modul {VERSION_MODUL} · {_zeit(now)} Ortszeit des Rechners")
    a(f"Version auf diesem Rechner: {version} · {pruefsumme}")
    if aktiv is not None:
        a("Der Plan läuft im Dashboard von selbst (jede Minute eine Runde, die erste 90 s nach dem Start)." if aktiv
          else "Der Plan ist in diesem Prozess NICHT aktiv (Selbsttest, HL_BERICHTE=0 oder Aufruf außerhalb des Dashboards) -- "
               "maßgeblich ist der Stand der Datei unten.")
    ev = stand.get("update") if isinstance(stand.get("update"), dict) else None
    if ev:
        a(f"Letztes Einspielen erkannt: {_zeit(ev.get('ts'))} -- von {ev.get('von') or 'unbekannt (erster Lauf mit diesem Plan)'} "
          f"auf {ev.get('auf')}")
    else:
        a("Letztes Einspielen erkannt: noch keines (der Plan vergleicht die Version bei seiner ersten Runde)")
    a("")
    a("Läufe nach dem Einspielen (Art nach_update):")
    n_nu = 0
    for e in plan:
        if "nach_update" not in e:
            continue
        n_nu += 1
        f = stand.get(e["id"] + ":faellig")
        nrn = ", ".join(str(nr_von(n) or n) for n in e.get("laeufe") or [])
        if not isinstance(f, (int, float)):
            zust = ("nicht fällig geworden (das Paket war schon eingespielt, als dieser Plan zum ersten Mal lief)" if ev
                    else "noch nicht geprüft (der Plan hat seit dem Start noch keine Runde gedreht)")
        elif erledigt(e, stand):
            zust = f"erledigt (fällig war {_zeit(f)})"
        elif f > now:
            zust = f"fällig um {_zeit(f)}"
        else:
            zust = f"fällig seit {_zeit(f)} -- läuft oder wartet auf einen laufenden Lauf"
        a(f"  {e['id']}: {minuten(e)} min nach dem Einspielen von {paket_kurz(e['nach_update'])} · {zust} · Debug {nrn}")
        g = e.get("grenze_s") or {}
        if g:
            a("    eigene Zeitgrenze: " + ", ".join(f"Debug {nr_von(n) or n} {s // 60} min" for n, s in g.items()))
    if not n_nu:
        a("  keine im Plan")
    if termine_fn is not None:
        kommend = []
        for e in plan:
            if "nach_update" in e:
                continue
            try:
                _l, nae = termine_fn(e, now)
            except Exception:
                nae = None
            if nae:
                kommend.append((nae, e))
        a("")
        a("Nächste Termine nach Zeitplan:")
        for nae, e in sorted(kommend, key=lambda x: x[0])[:6]:
            a(f"  {_zeit(nae)}  {e['id']} · Debug " + ", ".join(str(nr_von(n) or n) for n in (e.get("laeufe") or [])[:NRN_MAX])
              + (" …" if len(e.get("laeufe") or []) > NRN_MAX else ""))
        if not kommend:
            a("  keine")
    a("")
    a(f"Neue Berichte (noch nicht abgeholt): {neu} -- im Dashboard: Debug → „Neue Berichte“")
    ab = stand.get("hinweis_ab")
    if isinstance(ab, (int, float)) and not isinstance(ab, bool):
        a(f"Hinweis oben auf der Seite: {neu_geplant} (Berichte aus dem Plan seit {_zeit(ab)}, noch nicht abgeholt; „Herunterladen“ dort "
          "liefert genau diese)")
    else:
        a("Hinweis oben auf der Seite: zählt ab der ersten Runde des Plans (ältere Berichte lösen ihn nicht aus)")
    hw = hinweis_stand(neu_geplant, runde, faellig_offen)                 # 23.113 (U276)
    if hw["art"] == "runde":
        a(f"  Gerade läuft eine Runde des Plans: {hw['fertig']} von {hw['gesamt']} Läufen fertig -- „Herunterladen“ erscheint oben erst "
          "danach (seit 23.113).")
    elif hw["art"] == "wartet":
        a(f"  {hw['termine']} fällige{'r' if hw['termine'] == 1 else ''} Termin{'' if hw['termine'] == 1 else 'e'} noch nicht abgeschlossen -- "
          "„Herunterladen“ erscheint oben erst, wenn alle Läufe fertig sind (seit 23.113).")
    else:
        a("  „Herunterladen“ steht oben nur, wenn kein Lauf des Plans läuft und kein fälliger Termin offen ist (seit 23.113); "
          "währenddessen zeigt der Hinweis „k von m Läufen fertig“.")
    thema = (einstellung or {}).get("thema") or ""
    eigen = str((einstellung or {}).get("server") or NTFY_SERVER) != NTFY_SERVER
    if thema:
        a(f"Benachrichtigung aufs Handy (ntfy): eingerichtet · Thema endet auf {thema_ende(thema)} · "
          f"{'über einen eigenen Server' if eigen else 'über ntfy.sh'}")
    else:
        a("Benachrichtigung aufs Handy (ntfy): nicht eingerichtet -- im Dashboard: Debug → Berichtsplan → „Einrichten“. "
          "Der Hinweis oben auf der Seite kommt auch ohne.")
    verlauf = (zustand or {}).get("verlauf") or []
    offen = (zustand or {}).get("offen")
    if offen:
        a(f"  offen: „{offen.get('titel')}“ seit {_zeit(offen.get('seit'))}, {offen.get('versuche')} Versuch(e), zuletzt: "
          f"{offen.get('fehler') or '—'} (höchstens {MELDEN_VERSUCHE} Versuche)")
    for v in verlauf[-5:]:
        a(f"  {_zeit(v.get('ts'))}  „{v.get('titel')}“ -- "
          + ("gesendet (vom Dienst angenommen)" if v.get("ok") else f"NICHT gesendet nach {v.get('versuche')} Versuch(en): {v.get('fehler') or '—'}"))
    if thema and not verlauf and not offen:
        a("  noch keine Meldung zu Berichten gesendet (ein „Test senden“ wird hier nicht vermerkt)")
    a("")
    a("Gesendet wird nur ein kurzer Text (Zahl der Berichte, Anlass, Debug-Nummern), nie der Inhalt eines Berichts und nie eine "
      "Adresse dieses Rechners. Der Weg läuft über "
      + ("den eingetragenen eigenen ntfy-Server" if eigen else "den öffentlichen Dienst ntfy.sh") + "; das Thema ist das gemeinsame Geheimnis.")
    return "\n".join(Z)


# ================================================================================================ Selbsttest

def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_berichte -- Selbsttest (Läufe nach dem Einspielen, Benachrichtigung; ohne Netz, nachgebauter ntfy-Server)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_berichte_test_")
    srv = None
    try:
        V = "2026-09-23."
        # ---- Version
        ok("V1 Versionsschlüssel: Paketnummer als Zahl (99 vor 100), Unlesbares ist None",
           version_schluessel(V + "108") == ("2026-09-23", 108) and version_schluessel(V + "99") < version_schluessel(V + "100")
           and version_schluessel("2026-09-23.108 ") == ("2026-09-23", 108) and version_schluessel("2026-09-22.500") < version_schluessel(V + "1")
           and all(version_schluessel(x) is None for x in ("", None, "23.108", "2026-09-23", "2026-09-23.x", "v2026-09-23.108", 108)),
           f"{version_schluessel(V + '99')} < {version_schluessel(V + '100')}")
        ok("V2 Kurzname des Pakets", paket_kurz(V + "108") == "23.108" and paket_kurz("2026-12-01.7") == "01.7" and paket_kurz("dev") == "dev"
           and paket_kurz(None) == "?", f"{paket_kurz(V + '108')}, {paket_kurz('dev')}")
        ok("V3 trifft: von < Paket <= auf; unbekanntes von nur für das eigene Paket; Unlesbares nie",
           trifft(V + "109", V + "108", V + "109") and trifft(V + "107", V + "105", V + "108") and trifft(V + "108", V + "105", V + "108")
           and not trifft(V + "105", V + "105", V + "108") and not trifft(V + "109", V + "105", V + "108")
           and not trifft(V + "109", V + "109", V + "109") and not trifft(V + "108", V + "109", V + "108")
           and trifft(V + "109", None, V + "109") and not trifft(V + "108", None, V + "109") and not trifft(V + "110", None, V + "109")
           and trifft(V + "100", V + "99", V + "100") and not trifft("x", V + "1", V + "9") and not trifft(V + "5", V + "1", "?"),
           "Grenzen: von ausgeschlossen, auf eingeschlossen")
        ok("V4 Minuten: Vorgabe, eigener Wert, begrenzt, Unsinn -> Vorgabe", minuten({}) == NACH_UPDATE_MINUTEN == 10 and minuten({"minuten": 25}) == 25
           and minuten({"minuten": 0}) == 1 and minuten({"minuten": 10 ** 6}) == MINUTEN_MAX and minuten({"minuten": "x"}) == 10,
           f"Vorgabe {minuten({})}, 0 -> {minuten({'minuten': 0})}, zu groß -> {minuten({'minuten': 10 ** 6})}")
        # ---- Einspielen erkennen
        plan = [{"id": "p105", "nach_update": V + "105", "laeufe": ["a"], "zweck": "z"},
                {"id": "p106", "nach_update": V + "106", "minuten": 5, "laeufe": ["a"], "zweck": "z"},
                {"id": "p107", "nach_update": V + "107", "minuten": 30, "laeufe": ["a", "b"], "zweck": "z"},
                {"id": "p108", "nach_update": V + "108", "laeufe": ["a"], "zweck": "z"},
                {"id": "p109", "nach_update": V + "109", "laeufe": ["a"], "zweck": "z"},
                {"id": "w", "woechentlich": [2, "19:00"], "laeufe": ["a"], "zweck": "z"},
                {"id": "e", "einmal": "2026-11-20 08:00", "laeufe": ["a"], "zweck": "z"}]
        t0 = 1_800_000_000
        st = {"w": 123, "version": V + "108"}
        vorher = json.dumps(st, sort_keys=True)
        ok("U1 kein Wechsel: kein Ereignis, Stand unberührt", update_erkennen(st, V + "108", plan, t0) is None
           and json.dumps(st, sort_keys=True) == vorher, "gleiche Version")
        st = {"w": 123}
        ev = update_erkennen(st, V + "109", plan, t0)
        ok("U2 erster Lauf (keine Version im Stand): nur das eigene Paket wird fällig, Version und Ereignis vermerkt",
           ev == {"von": None, "auf": V + "109", "ts": t0, "faellig": ["p109"]} and st.get("p109:faellig") == t0 + 600
           and not any(k.endswith(":faellig") and k != "p109:faellig" for k in st) and st["version"] == V + "109"
           and st["update"] == {"von": None, "auf": V + "109", "ts": t0} and st["updates"] == [st["update"]] and st["w"] == 123,
           f"fällig {ev and ev['faellig']}, um {st.get('p109:faellig', 0) - t0} s")
        st = {"version": V + "105"}
        ev = update_erkennen(st, V + "108", plan, t0)
        ok("U3 Sprung über mehrere Pakete (105 -> 108): 106, 107, 108 fällig, je mit eigenen Minuten; 105 und 109 nicht",
           ev and ev["faellig"] == ["p106", "p107", "p108"] and st["p106:faellig"] == t0 + 300 and st["p107:faellig"] == t0 + 1800
           and st["p108:faellig"] == t0 + 600 and "p105:faellig" not in st and "p109:faellig" not in st,
           f"{ev and ev['faellig']}; 106 nach {st.get('p106:faellig', 0) - t0} s, 107 nach {st.get('p107:faellig', 0) - t0} s")
        st["p106"] = st["p106:faellig"]                                    # 106 ist gelaufen, 107 und 108 noch nicht
        ev2 = update_erkennen(st, V + "109", plan, t0 + 120)
        ok("U4 zweites Paket kurz danach: Offenes behält seinen Termin, frühestens 10 Minuten nach jetzt (107: 30 Minuten nach dem ersten "
           "Einspielen bleibt; 108 wäre 8 Minuten nach dem zweiten fällig -> 10 Minuten), Erledigtes läuft nicht noch einmal, das neue Paket "
           "kommt dazu",
           ev2 and ev2["faellig"] == ["p107", "p108", "p109"] and ev2["von"] == V + "108" and st["p107:faellig"] == t0 + 1800
           and st["p108:faellig"] == t0 + 120 + 600 and st["p109:faellig"] == t0 + 120 + 600 and st["p106:faellig"] == t0 + 300
           and erledigt(plan[1], st) and not erledigt(plan[2], st) and len(st["updates"]) == 2,
           f"{ev2 and ev2['faellig']}")
        st = {"version": V + "109", "p109": t0, "p109:faellig": t0}
        ev3 = update_erkennen(st, V + "108", plan, t0 + 1000)
        ev4 = update_erkennen(st, V + "109", plan, t0 + 2000)
        ok("U5 zurück auf ein älteres Paket: nichts fällig; danach wieder vor: das Paket läuft erneut",
           ev3 and ev3["faellig"] == [] and st["p109:faellig"] == t0 + 2000 + 600 and ev4 and ev4["faellig"] == ["p109"]
           and not erledigt(plan[4], st), f"zurück {ev3 and ev3['faellig']}, wieder vor {ev4 and ev4['faellig']}")
        plan_u8 = [{"id": "p1tag", "nach_update": V + "113", "minuten": 1440, "laeufe": ["a"], "zweck": "z"},
                   {"id": "p12h", "nach_update": V + "120", "minuten": 720, "laeufe": ["a"], "zweck": "z"},
                   {"id": "pbald", "nach_update": V + "121", "minuten": 30, "laeufe": ["a"], "zweck": "z"},
                   {"id": "pneu", "nach_update": V + "122", "laeufe": ["a"], "zweck": "z"}]
        st = {"version": V + "121", "p1tag:faellig": t0 + 86_400, "p12h:faellig": t0 - 3600, "pbald:faellig": t0 + 599}
        ev8 = update_erkennen(st, V + "122", plan_u8, t0)
        fa8 = (st["p1tag:faellig"], st["p12h:faellig"], st["pbald:faellig"], st["pneu:faellig"])
        for i_ in range(1, 4):                                            # danach jeden Tag ein Paket: „einen Tag später“ kommt trotzdem
            update_erkennen(st, V + str(122 + i_), plan_u8, t0 + i_ * 20_000)
        ok("U8 offene Einträge früherer Pakete (U313, seit 23.125): „einen Tag später“ behält seinen Termin, auch wenn jeden Tag ein Paket "
           "kommt; ein überfälliger (der Rechner war aus) und einer, der in weniger als 10 Minuten käme, laufen 10 Minuten nach dem "
           "Einspielen; das neue Paket wie immer nach seinen Minuten",
           ev8 and ev8["faellig"] == ["p1tag", "p12h", "pbald", "pneu"] and fa8 == (t0 + 86_400, t0 + 600, t0 + 600, t0 + 600)
           and st["p1tag:faellig"] == t0 + 86_400, f"{[f_ - t0 for f_ in fa8]}; nach drei weiteren Paketen {st['p1tag:faellig'] - t0}")
        st = {"version": V + "108"}
        ok("U6 Version dieses Rechners nicht lesbar: kein Ereignis, nichts geschrieben",
           update_erkennen(st, "?", plan, t0) is None and update_erkennen(st, "", plan, t0) is None and st == {"version": V + "108"}, "„?“")
        st = {}
        for i in range(14):
            update_erkennen(st, V + str(200 + i), [], t0 + i)
        ok("U7 Verlauf der Einspielungen: die letzten zehn", len(st["updates"]) == UPDATES_VERLAUF == 10 and st["updates"][-1]["auf"] == V + "213"
           and st["updates"][0]["auf"] == V + "204", f"{len(st['updates'])} Einträge")
        # ---- Fälligkeit
        st = {"p109:faellig": t0 + 600}
        ok("T1 Termine: vor der Fälligkeit (—, f), ab der Fälligkeit (f, —), ohne Fälligkeit (—, —)",
           termine_nach_update(plan[4], st, t0 + 599) == (None, t0 + 600) and termine_nach_update(plan[4], st, t0 + 600) == (t0 + 600, None)
           and termine_nach_update(plan[4], st, t0 + 9999) == (t0 + 600, None) and termine_nach_update(plan[3], st, t0) == (None, None)
           and termine_nach_update(plan[4], {"p109:faellig": "x"}, t0) == (None, None), "Grenze: genau zur Fälligkeit fällig")
        ok("T2 erledigt: Vermerk >= Fälligkeit", not erledigt(plan[4], st) and erledigt(plan[4], dict(st, p109=t0 + 600))
           and not erledigt(plan[4], dict(st, p109=t0 + 599)) and not erledigt(plan[4], {"p109": t0}), "")
        # ---- Planprüfung
        gut = plan_pruefen(plan, V + "109", {"a", "b"})
        schlecht = [
            ([dict(plan[0]), dict(plan[0])], "doppelt"),
            ([dict(plan[4], einmal="2026-11-20 08:00")], "2 Arten"),
            ([{"id": "x", "laeufe": ["a"], "zweck": "z"}], "0 Arten"),
            ([dict(plan[4], nach_update="23.109")], "nicht lesbar"),
            ([dict(plan[4], nach_update=V + "110")], "neuer als dieses Paket"),
            ([dict(plan[4], minuten=0)], "Minuten"),
            ([dict(plan[4], minuten=True)], "Minuten"),
            ([dict(plan[5], minuten=5)], "nur bei der Art nach_update"),
            ([dict(plan[4], grenze_s={"c": 900})], "nicht zu den Läufen"),
            ([dict(plan[4], grenze_s={"a": 30})], "außerhalb"),
            ([dict(plan[4], grenze_s={"a": 7201})], "außerhalb"),
            ([dict(plan[4], grenze_s=900)], "keine Zuordnung"),
            ([dict(plan[4], laeufe=["a", "unbekannt"])], "unbekannte Läufe"),
            ([dict(plan[4], laeufe=[])], "ohne Läufe"),
        ]
        treffer = [(w, plan_pruefen(p, V + "109", {"a", "b"})) for p, w in schlecht]
        ok("P1 Planprüfung: guter Plan ohne Fehler; 14 fehlerhafte Einträge je mit dem passenden Fehler",
           gut == [] and all(any(w in f for f in fl) for w, fl in treffer) and plan_pruefen([dict(plan[4], grenze_s={"a": 60})], V + "109") == []
           and plan_pruefen([dict(plan[4], grenze_s={"a": 7200}, minuten=1440)], V + "109") == [],
           f"gut {gut}; nicht erkannt {[w for w, fl in treffer if not any(w in f for f in fl)] or 'keiner'}")
        # ---- Thema
        t1, t2 = thema_neu(), thema_neu()
        ok("N1 Thema: zufällig, 33 Zeichen, gültig für ntfy (Buchstaben, Ziffern, _ und -, höchstens 64); Kurzes und Fremdes ungültig",
           t1 != t2 and len(t1) == 33 and t1.startswith(THEMA_VORSATZ) and thema_gueltig(t1) and thema_gueltig("A" * 64) and thema_gueltig("a_b-c" * 4)
           and not thema_gueltig("A" * 65) and not thema_gueltig("kurz") and not thema_gueltig("a" * 15) and not thema_gueltig("hyperbit-abc/def-0123456789")
           and not thema_gueltig("hyperbit-ä" + "a" * 20) and not thema_gueltig(None) and not thema_gueltig(12345678901234567890)
           and thema_ende(t1) == "…" + t1[-4:] and thema_ende("kurz") == "", f"Länge {len(t1)}")
        dt = os.path.join(tmp, "accesstokens.json")
        with open(dt, "w", encoding="utf-8") as f:
            json.dump({"fred": {"api_key": "k" * 32, "_wofuer": "FRED"}, "ntfy": {"server": "http://127.0.0.1:1"}}, f)
        os.chmod(dt, 0o640)
        e0 = einstellung_lesen(dt)
        g1 = thema_setzen(t1, dt)
        roh = json.load(open(dt, encoding="utf-8"))
        e1 = einstellung_lesen(dt)
        ok("N2 Thema eintragen: übrige Einträge bleiben, Datei atomar ersetzt, Rechte der vorhandenen Datei bleiben, Meldung ohne Thema",
           e0 == {"thema": "", "server": "http://127.0.0.1:1"} and g1[0] and t1 not in g1[1] and roh["fred"] == {"api_key": "k" * 32, "_wofuer": "FRED"}
           and roh["ntfy"]["thema"] == t1 and roh["ntfy"]["server"] == "http://127.0.0.1:1" and roh["ntfy"]["_wofuer"] == WOFUER
           and e1 == {"thema": t1, "server": "http://127.0.0.1:1"} and not os.path.exists(dt + ".tmp") and os.stat(dt).st_mode & 0o777 == 0o640,
           f"{g1[1]} Rechte {oct(os.stat(dt).st_mode & 0o777)}")
        g2 = thema_setzen("zu kurz", dt); g3 = thema_setzen("", dt)
        roh3 = json.load(open(dt, encoding="utf-8"))
        ok("N3 ungültiges Thema schreibt nichts; Abschalten löscht nur das Thema (der eigene Server bleibt)",
           not g2[0] and g3[0] and "thema" not in roh3["ntfy"] and roh3["ntfy"].get("server") == "http://127.0.0.1:1" and "fred" in roh3
           and einstellung_lesen(dt)["thema"] == "", f"{g2[1][:40]} | {g3[1]}")
        dn = os.path.join(tmp, "neu", "accesstokens.json"); os.makedirs(os.path.dirname(dn))
        g4 = thema_setzen(t2, dn)
        g4b = thema_setzen("", dn)
        ok("N4 neue Datei: Rechte 600, Vorgabe-Server ntfy.sh; nach dem Abschalten bleibt kein leerer Eintrag",
           g4[0] and os.stat(dn).st_mode & 0o777 == 0o600 and g4b[0] and json.load(open(dn, encoding="utf-8")) == {}
           and einstellung_lesen(os.path.join(tmp, "gibt_es_nicht.json")) == {"thema": "", "server": NTFY_SERVER == "https://ntfy.sh" and NTFY_SERVER},
           f"Rechte {oct(os.stat(dn).st_mode & 0o777)}")
        dk = os.path.join(tmp, "kaputt.json")
        open(dk, "w").write("{kaputt")
        g5 = thema_setzen(t1, dk)
        ok("N5 nicht lesbare Datei wird nicht überschrieben", not g5[0] and open(dk).read() == "{kaputt" and einstellung_lesen(dk)["thema"] == ""
           and "nichts überschrieben" in g5[1], g5[1][:60])
        for srv_bad in ("ftp://x", "https://ntfy.sh/?a=b", "javascript:alert(1)", "https://user:pw@ntfy.sh", ""):
            json.dump({"ntfy": {"thema": t1, "server": srv_bad}}, open(dk, "w"))
            if einstellung_lesen(dk)["server"] != NTFY_SERVER:
                ok("N6 unzulässige Serveradresse -> ntfy.sh", False, srv_bad); break
        else:
            json.dump({"ntfy": {"thema": t1, "server": "https://ntfy.example.org:8443/pfad/"}}, open(dk, "w"))
            e_gut = einstellung_lesen(dk)
            json.dump({"ntfy": {"thema": "zu-kurz", "server": "https://ntfy.example.org"}}, open(dk, "w"))
            ok("N6 unzulässige Serveradresse -> ntfy.sh; eigener https-Server mit Port und Pfad gilt; ein ungültiges Thema in der Datei zählt als keines",
               e_gut == {"thema": t1, "server": "https://ntfy.example.org:8443/pfad"}
               and einstellung_lesen(dk) == {"thema": "", "server": "https://ntfy.example.org"}, e_gut["server"])
        # ---- Senden gegen einen nachgebauten ntfy-Server
        emp: list = []
        antwort = {"status": 200}

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                emp.append({"pfad": self.path, "typ": self.headers.get("Content-Type"), "rumpf": self.rfile.read(n),
                            "kopf": {k.lower(): v for k, v in self.headers.items()}})
                body = b'{"id":"x"}' if antwort["status"] == 200 else b'{"code":42901,"error":"limit reached"}'
                self.send_response(antwort["status"]); self.send_header("Content-Length", str(len(body))); self.end_headers()
                self.wfile.write(body)

            def log_message(self, *a):
                pass
        srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{srv.server_address[1]}"
        s_ok = senden(t1, "HyperBit: 3 neue Berichte", "Größe ändern → „Neue Berichte (3)“.", url)
        r0 = json.loads(emp[0]["rumpf"].decode("utf-8")) if emp else {}
        ok("S1 Senden: POST an die Wurzel, JSON mit Thema, Titel, Text (Umlaute und Anführungszeichen unversehrt), Priorität 3, Marke",
           s_ok == (True, None) and len(emp) == 1 and emp[0]["pfad"] == "/" and emp[0]["typ"].startswith("application/json")
           and r0 == {"topic": t1, "title": "HyperBit: 3 neue Berichte", "message": "Größe ändern → „Neue Berichte (3)“.",
                      "tags": ["page_facing_up"], "priority": 3}
           and "title" not in emp[0]["kopf"] and "x-title" not in emp[0]["kopf"], f"{s_ok}, Felder {sorted(r0)}")
        antwort["status"] = 429
        s_429 = senden(t1, "T", "x", url)
        del emp[:]
        s_kein = senden("kurz", "T", "x", url); s_leer = senden("", "T", "x", url)
        s_tot = senden(t1, "T", "x", "http://127.0.0.1:1")
        s_echo = senden(t1, "T", "x", url, http_fn=lambda u, r, t: (500, f"topic {t1} kaputt"))
        s_wurf = senden(t1, "T", "x", url, http_fn=lambda u, r, t: (_ for _ in ()).throw(OSError(f"keine Verbindung zu {t1}")))
        ok("S2 Fehler: HTTP 429 mit Text; kein gültiges Thema -> kein Abruf; Netzfehler als Text; das Thema steht in keinem Fehlertext",
           s_429[0] is False and s_429[1].startswith("HTTP 429: ") and "limit reached" in s_429[1] and s_kein == (False, "kein gültiges Thema eingerichtet")
           and s_leer[0] is False and emp == [] and s_tot[0] is False and s_tot[1] and t1 not in s_tot[1]
           and s_echo == (False, "HTTP 500: topic *** kaputt") and s_wurf == (False, "OSError: keine Verbindung zu ***"),
           f"429: {s_429[1][:40]} | tot: {(s_tot[1] or '')[:50]}")
        lang = senden(t1, "T" * 500, "x" * 5000, url, http_fn=lambda u, r, t: (emp.append(json.loads(r.decode())) or (200, "")))
        ok("S3 Längen begrenzt: Titel 120, Text 1.000 Zeichen", lang[0] and len(emp[-1]["title"]) == TITEL_MAX == 120
           and len(emp[-1]["message"]) == TEXT_MAX == 1000, f"{len(emp[-1]['title'])} / {len(emp[-1]['message'])}")
        # ---- Hinweis im Kopf der Seite: ab wann er zählt und welche Berichte
        th = int(time.mktime((2026, 7, 15, 12, 30, 40, 0, 0, -1)))              # fern jeder Zeitumstellung, in jeder Zeitzone
        nm = lambda ts, lauf="notbremse": time.strftime("%Y-%m-%d_%H-%M", time.localtime(ts)) + f"_{lauf}.txt"
        ok("H1 Beginn eines Berichts aus dem Dateinamen: Ortszeit auf die Minute; anderer Name: nichts",
           bericht_zeit(nm(th)) == th - 40 and bericht_zeit(nm(th, "log_notbremse")) == th - 40 and bericht_zeit("notbremse.txt") is None
           and bericht_zeit("2026-13-40_99-99_x.txt") is None and bericht_zeit("") is None and bericht_zeit(None) is None,
           f"{nm(th)} -> {bericht_zeit(nm(th))}")
        sh: dict = {}
        erst = hinweis_beginnen(sh, th); zweit = hinweis_beginnen(sh, th + 5000)
        sh2 = {"hinweis_ab": "kaputt"}; dritt = hinweis_beginnen(sh2, th + 1.9)
        ok("H2 Vermerk „hinweis_ab“: einmal gesetzt (erste Runde des Plans), später nie verschoben; ein unlesbarer Wert wird ersetzt",
           erst is True and zweit is False and sh == {"hinweis_ab": th} and dritt is True and sh2 == {"hinweis_ab": th + 1},
           f"{sh}")
        ok("H3 was der Hinweis zählt: Berichte aus dem Plan ab der Minute des Vermerks, noch nicht abgeholt -- nicht ältere, nicht Handläufe, "
           "nicht Abgeholte; ohne Vermerk nichts",
           hinweis_zaehlt(nm(th), {}, th) and hinweis_zaehlt(nm(th + 60), {}, th) and hinweis_zaehlt(nm(th - 40), {}, th)
           and not hinweis_zaehlt(nm(th - 41), {}, th) and not hinweis_zaehlt(nm(th - 86400), {}, th)
           and not hinweis_zaehlt(nm(th + 60, "notbremse_manuell"), {}, th) and not hinweis_zaehlt(nm(th + 60), {nm(th + 60): th + 99}, th)
           and hinweis_zaehlt(nm(th + 60), {nm(th + 120): th + 99}, th) and hinweis_zaehlt(nm(th + 60), None, th)
           and not hinweis_zaehlt(nm(th + 60), {}, None) and not hinweis_zaehlt(nm(th + 60), {}, True) and not hinweis_zaehlt(nm(th + 60), {}, "x")
           and not hinweis_zaehlt("ohne_zeit.txt", {}, th), "Grenze: die Minute des Vermerks zählt mit")
        # ---- Meldungstext
        e_nu = plan[4]
        m1 = meldung_bauen(e_nu, [151, 14, 117, 143], 4, 0)
        m2 = meldung_bauen(plan[5], list(range(1, 13)), 12, 2)
        m3 = meldung_bauen(plan[6], [26], 1, 1)
        ok("M1 Meldung nach dem Einspielen: Zahl, Paket, Debug-Nummern, Fundort; ohne Fehler kein Fehlersatz",
           m1 == ("HyperBit: 4 neue Berichte", "Paket 23.109 ist eingespielt, die Läufe danach sind fertig (Debug 151, 14, 117, 143). "
                  "Im Dashboard steht oben der Hinweis mit „Herunterladen“."), m1[1][:70])
        ok("M2 Wochentermin: höchstens acht Nummern, dann „…“; Fehler gezählt. Einzeltermin: Einzahl",
           m2[0] == "HyperBit: 12 neue Berichte" and "(Debug 1, 2, 3, 4, 5, 6, 7, 8 …)" in m2[1] and "Wochentermin" in m2[1]
           and "2 davon mit Fehler oder Abbruch." in m2[1] and m3[0] == "HyperBit: 1 neuer Bericht" and "Ein Termin des Berichtsplans" in m3[1]
           and "1 davon mit Fehler" in m3[1] and "(Debug 26)" in m3[1] and all(m[1].endswith(" Im Dashboard steht oben der Hinweis mit „Herunterladen“.")
                                                                           for m in (m2, m3)), f"{m2[1][:60]} | {m3[0]}")
        # ---- 23.113 (U276): Runde, Hinweis, eine Meldung je Runde
        e_a = {"id": "a", "nach_update": V + "110", "laeufe": ["cockpit_stand", "chartbild_text", "ausblick_text", "niveaus_bilanz"]}
        e_b = {"id": "b", "nach_update": V + "111", "laeufe": ["cockpit_stand", "check_daily", "chartbild_text"]}
        e_c = {"id": "c", "nach_update": V + "112", "laeufe": ["labor", "abdeckung"]}
        ok("R1 Läufe einer Runde ohne Wiederholung, in der Reihenfolge des Plans (19.11.2026: neun Läufe in drei Einträgen, zwei davon doppelt -> sieben)",
           laeufe_der_runde([e_a, e_b, e_c]) == ["cockpit_stand", "chartbild_text", "ausblick_text", "niveaus_bilanz", "check_daily", "labor", "abdeckung"]
           and laeufe_der_runde([e_c]) == ["labor", "abdeckung"] and laeufe_der_runde([]) == [] and laeufe_der_runde([{"id": "x"}]) == [],
           f"{len(laeufe_der_runde([e_a, e_b, e_c]))} von 9")
        ok("R2 Hinweis im Kopf der Seite: läuft eine Runde -> „runde“ mit k von m, auch wenn schon Berichte bereitliegen; fällige Einträge offen -> "
           "„wartet“; sonst mit Berichten „bereit“, ohne „nichts“; eine Runde ohne Läufe oder mit Unsinn zählt als keine",
           hinweis_stand(3, {"gesamt": 7, "fertig": 2}, 0) == {"art": "runde", "fertig": 2, "gesamt": 7}
           and hinweis_stand(0, {"gesamt": 7, "fertig": 0}, 2) == {"art": "runde", "fertig": 0, "gesamt": 7}
           and hinweis_stand(3, {"gesamt": 4, "fertig": 9}, 0)["fertig"] == 4
           and hinweis_stand(3, None, 2) == {"art": "wartet", "termine": 2} and hinweis_stand(3, None, 0) == {"art": "bereit", "n": 3}
           and hinweis_stand(0, None, 0) == {"art": "nichts"} and hinweis_stand(2, {"gesamt": 0, "fertig": 0}, 0) == {"art": "bereit", "n": 2}
           and hinweis_stand(1, {"gesamt": "x"}, 0) == {"art": "bereit", "n": 1} and hinweis_stand(None, "kaputt", None) == {"art": "nichts"},
           f"{hinweis_stand(3, {'gesamt': 7, 'fertig': 2}, 0)}")
        m4 = meldung_bauen([e_a, e_b, e_c], [143, 71, 73, 149, 105, 13, 85], 7, 1)
        m5 = meldung_bauen([e_a], [143], 1, 0)
        m6 = meldung_bauen([plan[5], plan[6]], [1, 26], 2, 0)
        m7 = meldung_bauen([e_a, dict(e_b, nach_update=V + "110")], [143], 2, 0)
        ok("R3 eine Meldung je Runde: mehrere Pakete in einem Satz, Fehler gezählt; ein Eintrag als Liste = wie bisher; gemischte Termine "
           "gezählt; zwei Einträge desselben Pakets nennen es einmal",
           m4 == ("HyperBit: 7 neue Berichte", "Die Pakete 23.110, 23.111 und 23.112 sind eingespielt, die Läufe danach sind fertig "
                  "(Debug 143, 71, 73, 149, 105, 13, 85). 1 davon mit Fehler oder Abbruch. Im Dashboard steht oben der Hinweis mit „Herunterladen“.")
           and m5 == meldung_bauen(e_a, [143], 1, 0) and m5[1].startswith("Paket 23.110 ist eingespielt, die Läufe danach sind fertig (Debug 143).")
           and m6[1].startswith("2 Termine des Berichtsplans sind gelaufen (Debug 1, 26).")
           and m7[1].startswith("Paket 23.110 ist eingespielt, die Läufe danach sind fertig (Debug 143)."), m4[1][:90])
        alle_t = " ".join(m1 + m2 + m3 + m4 + m6)
        ok("M3 Meldungen ohne Thema, ohne Adresse, ohne Pfad", t1 not in alle_t and "http" not in alle_t and "/" not in alle_t and "192." not in alle_t
           and all(len(m[0]) <= TITEL_MAX and len(m[1]) <= TEXT_MAX for m in (m1, m2, m3)), f"{len(alle_t)} Zeichen")
        # ---- Melden mit Verlauf und Wiederholung
        ord_ = os.path.join(tmp, "berichte"); os.makedirs(ord_)
        dm = os.path.join(tmp, "melden_tokens.json")
        del emp[:]; antwort["status"] = 200
        ohne = melden(ord_, "T1", "x", t0, datei=dm)
        ok("L1 ohne Thema: nichts gesendet, kein Zustand geschrieben", ohne == {"eingerichtet": False, "gesendet": False} and emp == []
           and not os.path.exists(os.path.join(ord_, ".melden.json")), str(ohne))
        json.dump({"ntfy": {"thema": t1, "server": url}}, open(dm, "w"))
        mit = melden(ord_, "T2", "Text ä", t0 + 1, datei=dm)
        z = zustand_lesen(ord_)
        ok("L2 mit Thema: gesendet, im Verlauf als gesendet, nichts offen", mit == {"eingerichtet": True, "gesendet": True} and len(emp) == 1
           and z["offen"] is None and z["verlauf"] == [{"ts": t0 + 1, "titel": "T2", "ok": True, "fehler": None, "versuche": 1}],
           f"{mit}, Verlauf {len(z['verlauf'])}")
        antwort["status"] = 503
        aus = melden(ord_, "T3", "x", t0 + 2, datei=dm)
        z = zustand_lesen(ord_)
        ok("L3 Server antwortet nicht mit 200: Meldung bleibt offen (ein Versuch), Verlauf unverändert",
           aus == {"eingerichtet": True, "gesendet": False} and z["offen"] and z["offen"]["titel"] == "T3" and z["offen"]["versuche"] == 1
           and z["offen"]["fehler"].startswith("HTTP 503") and z["offen"]["seit"] == t0 + 2 and len(z["verlauf"]) == 1, str(z["offen"])[:90])
        w1 = melden_offen(ord_, t0 + 60, datei=dm)
        antwort["status"] = 200
        w2 = melden_offen(ord_, t0 + 120, datei=dm)
        z = zustand_lesen(ord_)
        ok("L4 Wiederholung: zweiter Versuch scheitert, dritter kommt an -- im Verlauf mit 3 Versuchen, nichts mehr offen; danach nichts zu tun",
           w1 is False and w2 is True and z["offen"] is None and z["verlauf"][-1] == {"ts": t0 + 120, "titel": "T3", "ok": True, "fehler": None,
                                                                                    "versuche": 3}
           and melden_offen(ord_, t0 + 180, datei=dm) is None, f"{w1}, {w2}, Versuche {z['verlauf'][-1]['versuche']}")
        antwort["status"] = 500
        melden(ord_, "T4", "x", t0 + 200, datei=dm)
        erg = [melden_offen(ord_, t0 + 200 + 60 * i, datei=dm) for i in range(1, 6)]
        z = zustand_lesen(ord_)
        ok("L5 nach fünf Versuchen aufgegeben: im Verlauf als nicht gesendet, nichts mehr offen, kein sechster Abruf",
           erg == [False, False, False, False, None] and z["offen"] is None and z["verlauf"][-1]["titel"] == "T4" and z["verlauf"][-1]["ok"] is False
           and z["verlauf"][-1]["versuche"] == MELDEN_VERSUCHE == 5 and z["verlauf"][-1]["fehler"].startswith("HTTP 500"),
           f"{erg}, {z['verlauf'][-1]}")
        melden(ord_, "T5", "x", t0 + 900, datei=dm)                       # offen (Server liefert 500)
        melden(ord_, "T6", "x", t0 + 901, datei=dm)                       # ersetzt die offene
        z = zustand_lesen(ord_)
        thema_setzen("", dm)
        n_vor = len(emp)
        ab = melden_offen(ord_, t0 + 960, datei=dm)
        ok("L6 neue Meldung ersetzt die offene; nach dem Abschalten wird nichts nachgesendet",
           z["offen"]["titel"] == "T6" and z["offen"]["versuche"] == 1 and ab is None and len(emp) == n_vor and zustand_lesen(ord_)["offen"] is None,
           f"offen war {z['offen']['titel']}")
        json.dump({"ntfy": {"thema": t1, "server": url}}, open(dm, "w")); antwort["status"] = 200
        for i in range(14):
            melden(ord_, f"V{i}", "x", t0 + 2000 + i, datei=dm)
        z = zustand_lesen(ord_)
        roh_z = json.load(open(os.path.join(ord_, ".melden.json"), encoding="utf-8"))
        json.dump({"verlauf": [{"titel": f"A{i}"} for i in range(15)] + ["kein Eintrag"], "offen": "kein Eintrag"},
                  open(os.path.join(ord_, ".melden.json"), "w"))
        z_gross = zustand_lesen(ord_)
        open(os.path.join(ord_, ".melden.json"), "w").write("[kaputt")
        ok("L7 Verlauf: die letzten zehn -- in der Datei und beim Lesen einer größeren Datei; Fremdes darin fällt weg; kaputte Datei zählt als leer",
           len(z["verlauf"]) == MELDEN_VERLAUF == 10 and z["verlauf"][-1]["titel"] == "V13" and z["verlauf"][0]["titel"] == "V4"
           and len(roh_z["verlauf"]) == 10 and roh_z["verlauf"][0]["titel"] == "V4"
           and [v["titel"] for v in z_gross["verlauf"]] == [f"A{i}" for i in range(5, 15)] and z_gross["offen"] is None
           and zustand_lesen(ord_) == {"verlauf": [], "offen": None}, f"{len(z['verlauf'])} Einträge, in der Datei {len(roh_z['verlauf'])}")
        # ---- Text von Debug 151
        st = {"version": V + "109", "update": {"von": V + "108", "auf": V + "109", "ts": t0}, "p109:faellig": t0 + 600,
              "p108:faellig": t0 - 5000, "p108": t0 - 5000, "hinweis_ab": t0 - 50}
        zu = {"verlauf": [{"ts": t0 + 700, "titel": "HyperBit: 4 neue Berichte", "ok": True, "fehler": None, "versuche": 1},
                          {"ts": t0 + 800, "titel": "HyperBit: 1 neuer Bericht", "ok": False, "fehler": "HTTP 500: x", "versuche": 5}],
              "offen": {"titel": "HyperBit: 2 neue Berichte", "seit": t0 + 900, "versuche": 2, "fehler": "URLError: aus"}}
        nr = {"a": 151, "b": 14}.get
        plan_t = [dict(p) for p in plan]; plan_t[4]["grenze_s"] = {"a": 1800}
        tx = stand_text(plan_t, st, V + "109", "abc123", t0 + 100, 5, 3, {"thema": t1, "server": NTFY_SERVER}, zu, nr,
                        lambda e, now: (None, t0 + 86400) if e["id"] == "w" else (None, None), True)
        tx2 = stand_text(plan_t, {}, V + "109", "abc123", t0 + 100, 0, 0, {"thema": "", "server": NTFY_SERVER}, {"verlauf": [], "offen": None}, nr)
        tx3 = stand_text(plan_t, dict(st, p109=t0 + 600), V + "109", "abc123", t0 + 700, 0, 0, {"thema": t1, "server": url},
                         {"verlauf": [], "offen": None}, nr, aktiv=False)
        ok("D1 Text von Debug 151: Version, Einspielen, Läufe mit Stand (fällig um, erledigt, nicht fällig geworden), eigene Zeitgrenze, Termine",
           f"Version auf diesem Rechner: {V}109 · abc123" in tx and f"von {V}108 auf {V}109" in tx and "p109: 10 min nach dem Einspielen von 23.109 · fällig um " in tx
           and "p108: 10 min nach dem Einspielen von 23.108 · erledigt (fällig war " in tx and "p105: 10 min nach dem Einspielen von 23.105 · nicht fällig geworden" in tx
           and "eigene Zeitgrenze: Debug 151 30 min" in tx and "p107: 30 min nach dem Einspielen von 23.107" in tx and "Debug 151, 14" in tx
           and "Nächste Termine nach Zeitplan:" in tx and "  w · Debug 151" in tx.replace(_zeit(t0 + 86400), "")
           and "Neue Berichte (noch nicht abgeholt): 5 -- im Dashboard: Debug → „Neue Berichte“" in tx
           and f"Hinweis oben auf der Seite: 3 (Berichte aus dem Plan seit {_zeit(t0 - 50)}, noch nicht abgeholt; „Herunterladen“ dort liefert genau diese)" in tx
           and "Hinweis oben auf der Seite: zählt ab der ersten Runde des Plans (ältere Berichte lösen ihn nicht aus)" in tx2
           and "Der Plan läuft im Dashboard von selbst" in tx,
           f"{tx.count(chr(10)) + 1} Zeilen")
        ok("D2 Benachrichtigung im Text: nur das Ende des Themas, letzte Meldungen mit Ergebnis, Offenes; ohne Einrichtung der Weg dorthin",
           t1 not in tx and f"Thema endet auf …{t1[-4:]} · über ntfy.sh" in tx and "über den öffentlichen Dienst ntfy.sh;" in tx and "„HyperBit: 4 neue Berichte“ -- gesendet (vom Dienst angenommen)" in tx
           and "„HyperBit: 1 neuer Bericht“ -- NICHT gesendet nach 5 Versuch(en): HTTP 500: x" in tx
           and "offen: „HyperBit: 2 neue Berichte“" in tx and "2 Versuch(e), zuletzt: URLError: aus" in tx
           and "nicht eingerichtet -- im Dashboard: Debug → Berichtsplan → „Einrichten“" in tx2 and "noch keines" in tx2
           and "p109: 10 min nach dem Einspielen von 23.109 · noch nicht geprüft (der Plan hat seit dem Start noch keine Runde gedreht)" in tx2
           and "fällig seit" not in tx2 and t1 not in tx3 and "· über einen eigenen Server" in tx3 and "über den eingetragenen eigenen ntfy-Server;" in tx3
           and "ntfy.sh" not in tx3 and url not in tx3 and "noch keine Meldung zu Berichten gesendet (ein „Test senden“ wird hier nicht vermerkt)" in tx3
           and "p109: 10 min nach dem Einspielen von 23.109 · erledigt" in tx3 and "NICHT aktiv" in tx3, "Thema nicht im Text")
        tx4 = stand_text(plan_t, st, V + "109", "abc123", t0 + 700, 0, 0, {"thema": "", "server": NTFY_SERVER}, {"verlauf": [], "offen": None}, nr)
        ok("D3 fällig, aber noch nicht gelaufen: „fällig seit … läuft oder wartet“", "p109: 10 min nach dem Einspielen von 23.109 · fällig seit " in tx4
           and "läuft oder wartet auf einen laufenden Lauf" in tx4, "")
        arg_d = (plan_t, st, V + "109", "abc123", t0 + 700, 4, 4, {"thema": "", "server": NTFY_SERVER}, {"verlauf": [], "offen": None}, nr, None, None)
        tx5 = stand_text(*arg_d, {"gesamt": 7, "fertig": 3}, 0); tx6 = stand_text(*arg_d, None, 2); tx7 = stand_text(*arg_d, None, 1)
        tx8 = stand_text(*arg_d)
        regel_d = "„Herunterladen“ steht oben nur, wenn kein Lauf des Plans läuft und kein fälliger Termin offen ist (seit 23.113)"
        ok("D4 (U276) Text von Debug 151: läuft eine Runde, steht „3 von 7 Läufen fertig“; sind fällige Termine offen, ihre Zahl (Einzahl und "
           "Mehrzahl); sonst die Regel -- jeweils genau eine der drei Zeilen",
           "Gerade läuft eine Runde des Plans: 3 von 7 Läufen fertig" in tx5 and "2 fällige Termine noch nicht abgeschlossen" in tx6
           and "1 fälliger Termin noch nicht abgeschlossen" in tx7 and regel_d in tx8 and regel_d in tx4
           and all(sum(m_ in t_ for m_ in ("Gerade läuft eine Runde", "noch nicht abgeschlossen", regel_d)) == 1 for t_ in (tx5, tx6, tx7, tx8)),
           "drei Fälle")
        # ---- Vertrag mit dem Paket: das Modul steht in den Listen, sonst fehlt es in Prüfsumme, Sicherung oder Prüfschritt
        hier = os.path.dirname(os.path.abspath(__file__))
        quellen = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as f:
                    quellen[n_] = f.read()
            except OSError:
                quellen[n_] = ""
        ok("K1 Vertrag mit dem Paket: hl_berichte.py in der Prüfsumme (version.py), in Sicherung und Wiederherstellung (update.py), im "
           "Übersetzungs- und im Prüfschritt des Installers; hl_viz bindet das Modul ein",
           '                  "hl_berichte.py",' in quellen["version.py"] and '                 "hl_berichte.py",\n' in quellen["update.py"]
           and 'str(ROOT / "hl_niveaus.py"), str(ROOT / "hl_berichte.py"), ' in quellen["install.py"]
           and '[py, str(ROOT / "hl_berichte.py"), "--selbsttest"]' in quellen["install.py"] and "\nimport hl_berichte as _BR\n" in quellen["hl_viz.py"],
           ", ".join(n_ for n_, q_ in quellen.items() if "hl_berichte" in q_) or "in keiner Liste")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-700:].replace("\n", " | "))
    finally:
        if srv is not None:
            try:
                srv.shutdown(); srv.server_close()
            except Exception:
                pass
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    import argparse
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz (nachgebauter ntfy-Server auf diesem Rechner)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    p.print_help()


if __name__ == "__main__":
    main()
