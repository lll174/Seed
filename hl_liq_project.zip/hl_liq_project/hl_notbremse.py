#!/usr/bin/env python3
"""
hl_notbremse.py -- Notbremse: marktweite Long-Sperre bei Schocks (U206, KONZEPT_Notbremse.md Fassung 1 vom 23.10.2026).

Fallen Krypto und Aktien GEMEINSAM ungewöhnlich (oder bricht Krypto allein mit einer Liquidationswelle ein), sperrt die Notbremse
neue und größere Long-Positionen im TradeLabor -- nur in der Welt A, einer Kopie des Labors; das heutige Labor (Welt B) läuft
unverändert weiter. Schließen ist nie gesperrt, Shorts bleiben frei. Ebene B (Prognosemärkte, Schlagzeilen, KI) folgt mit U207.

Ebene A (Marktsignal), jede Minute bei Sekunde 5 (UTC):
  Körbe     K = eigene Coins ohne PAXG plus die größten Perps des Haupt-Dex nach Open Interest (bis 10, täglich 00:00 UTC, gültig
            ab 4), A = xyz:SP500, xyz:XYZ100 und die Top 10 aus „Aktienmarkt“ (gültig ab 3). VIX, Gold, Öl nur Anzeige.
  Daten     Mids je Minute (allMids je Dex, Gewicht 2) in nb_preis (70 Tage); 15-min-Schlüsse in nb_kerze15 (ohne Löschfrist), beim
            ersten Start aus candleSnapshot (Hintergrund, eigenes Budget) und den eigenen Minutenkerzen.
  Normierung zwei Zeitklassen (Sitzung = NYSE 09:30–16:00 New York, Frühschluss 13:00; außerhalb = alles andere), je Klasse
            v = (1,4826 · MAD)² / 15 aus den nicht überlappenden 15-min-Renditen der 30 Tage vor dem letzten 00:00 UTC (der laufende
            Tag nie), mindestens 60 Renditen; Untergrenze 0,0625 · Median der Gruppe. σ(i, w, t) = √(n_S · v_S + n_A · v_A).
  Maße      z = r / σ (auf ±20 begrenzt); G = Median je Gruppe; X = min über 15/60/240 min von max(G_K, G_A); Y = min über
            5/15/60 min von G_K; Λ = Perzentil der Long-Liquidationen der letzten 15 min unter den 15-min-Summen derselben Zeitklasse
            der 30 Tage davor.
  Stufen    1 Long-Sperre: X ≤ θ1, Termin, Handbremse. 2 Schock: X ≤ θ2X oder Y ≤ θ2Y mit Λ ≥ 0,99, Handbremse „Schock“.
            Schwellen aus dem Alarmbudget (4 / 1 / 1 Episoden je 30 Tage), Startwerte −2,5 / −4,0 / −5,0.
  Ende      Stufe 2 → 1 frühestens 240 min nach der letzten Stufe-2-Bedingung; Stufe 1 → 0 frühestens 120 min nach der letzten
            Bedingung, wenn seit 30 min X und G_K(60) über θ1/2 und Λ unter 0,90 liegen.
Ebene B3  Termine aus notbremse_termine.json (UTC), im Zeitraum Stufe 1. Ebene C: Handbremse im Dashboard (POST mit Kopfzeile).

Tor für das Labor: darf(con, t, seite, art) -- Zustand zum Zeitpunkt des Vorgangs, älter als 180 s oder nicht lesbar = gesperrt.

  python3 hl_notbremse.py --db <hl_liq.db>            Dienst (systemd hl-notbremse)
  python3 hl_notbremse.py --status --db <hl_liq.db>   Zustand als Text
  python3 hl_notbremse.py --selbsttest                Proben 1–11, 14–17 und die Prüfung des Tors (KONZEPT 10)
"""
from __future__ import annotations

import argparse
import ast
import bisect
import json
import math
import os
import random
import sqlite3
import sys
import time
import warnings
from datetime import date, datetime, timedelta, timezone

import numpy as np

import hl_aktien as AK

UTC = timezone.utc
NY = AK.NY
FASSUNG = "Fassung 1 (23.10.2026)"
HL_INFO = "https://api.hyperliquid.xyz/info"

# --------------------------------------------------------------------------------------------- Regeln (KONZEPT 4, vorab festgelegt)
EIGENE = ("BTC", "ETH", "HYPE", "ZEC", "XMR")             # COINS ohne PAXG (Gold)
K_MAX = 10                                                 # Krypto-Korb höchstens so viele Instrumente
K_MIN = 4                                                  # Gruppe gültig ab so vielen Instrumenten mit Daten
A_MIN = 3
XYZ = "xyz"
AKTIEN = ("SP500", "XYZ100", "NVDA", "MSFT", "AAPL", "AMZN", "GOOGL", "META", "AVGO", "TSLA", "LLY", "MU")
ANZEIGE_XYZ = ("VIX",)
OEL_NAMEN = ("CL", "WTI", "BRENT", "OIL", "USOIL", "CRUDE")
GOLD_NAMEN = ("GOLD", "XAU")
W_X = (15, 60, 240)
W_Y = (5, 15, 60)
Z_KAPPE = 20.0
PREIS_MAX_ALTER = 120                                      # ein Mid gilt höchstens so alt (s)
ZUSTAND_MAX_ALTER = 180                                    # älter: Welt A eröffnet keine Longs („Notbremse veraltet“)
SIGMA_TAGE = 30
SIGMA_MIN_N = 60
SIGMA_BODEN = 0.0625                                       # v ≥ 0,0625 · Median der Gruppe (σ ≥ 0,25 · Median)
MAD_FAKTOR = 1.4826
LAM_STUFE2 = 0.99
LAM_FREI = 0.90
STUFE2_MIN_S = 240 * 60
STUFE1_MIN_S = 120 * 60
HYST_S = 30 * 60
RUHE_S = 60 * 60                                           # nach „Sperre aufheben“: nur eine Stufe-2-Bedingung löst neu aus
EPISODE_LUECKE_S = 240 * 60                                # Kalibrierung: Läufe mit weniger Abstand sind eine Episode
BUDGET = {"s1x": 4, "s2x": 1, "s2y": 1}                    # Episoden je 30 Tage
RASTER = tuple(round(-1.50 - 0.05 * k, 2) for k in range(131))    # −1,50 … −8,00
KLAMMER = {"theta1": (-3.5, -1.5), "theta2x": (-6.0, -2.5), "theta2y": (-8.0, -3.0)}
START = {"theta1": -2.5, "theta2x": -4.0, "theta2y": -5.0}
ERSTE_KALIB_BIS = int(datetime(2026, 10, 21, tzinfo=UTC).timestamp()) - 1      # 20.10.2026 23:59:59 UTC -- der 22.10. bleibt ungesehen
ERSTE_KALIB_SIGMA_MIN_TAGE = 10
KALIB_MIN_TAGE = 21
NEUKALIB_TAGE = 60
PREIS_TAGE = 70                                            # nb_preis: 60 Tage Kalibrierung von Y plus Reserve
WACHE_S = 120 * 60                                         # Ebene B (U207) -- hier nur für das Feld „wache“
MANUELL_DAUER = {"1h": 3600, "4h": 4 * 3600, "24h": 86_400, "widerruf": None, "schock4h": 4 * 3600}
GEWICHT_HISTORIE_MIN = 40                                  # candleSnapshot im Hintergrund: höchstens so viel Gewicht je Minute
TAG = 86_400
ARTEN = ("eroeffnen", "vergroessern", "limit_setzen", "limit_fuellen", "grid_kauf", "schliessen", "verkleinern")
BLOCK_LOG_S = 900                                          # derselbe gesperrte Vorgang (Strategie, Coin, Art) höchstens alle 15 min protokolliert

SCHEMA = """
CREATE TABLE IF NOT EXISTS nb_preis (inst TEXT, ts INTEGER, mid REAL, PRIMARY KEY (inst, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS nb_kerze15 (inst TEXT, ts INTEGER, c REAL, PRIMARY KEY (inst, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS nb_sigma (tag INTEGER, inst TEXT, klasse TEXT, v REAL, n INTEGER, quelle TEXT, PRIMARY KEY (tag, inst, klasse));
CREATE TABLE IF NOT EXISTS nb_zustand (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, stufe INTEGER, quelle TEXT, grund TEXT, x REAL,
    y REAL, lam REAL, wache INTEGER, gk_json TEXT, ga_json TEXT, seit INTEGER, frei_ab INTEGER, hinweis TEXT, spiegel INTEGER);
CREATE INDEX IF NOT EXISTS ix_nbz_ts ON nb_zustand(ts);
CREATE TABLE IF NOT EXISTS nb_schwellen (gueltig_ab INTEGER PRIMARY KEY, theta1 REAL, theta2x REAL, theta2y REAL, budget_json TEXT,
    zeitraum TEXT, klammer_json TEXT, info_json TEXT);
CREATE TABLE IF NOT EXISTS nb_episode (id INTEGER PRIMARY KEY AUTOINCREMENT, start INTEGER, ende INTEGER, stufe_max INTEGER, ausloeser TEXT,
    werte_json TEXT, gesperrt_n INTEGER, storniert_n INTEGER, d_usd REAL, varianten_json TEXT, spiegel INTEGER DEFAULT 0, ausgewertet INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_nbe_start ON nb_episode(start);
CREATE TABLE IF NOT EXISTS nb_blockiert (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, welt TEXT, sid TEXT, coin TEXT, seite TEXT,
    art TEXT, preis REAL, grund TEXT);
CREATE INDEX IF NOT EXISTS ix_nbb_ts ON nb_blockiert(ts);
CREATE TABLE IF NOT EXISTS nb_manuell (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, aktion TEXT, dauer_s INTEGER, grund TEXT);
CREATE TABLE IF NOT EXISTS nb_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS nb_tag (tag INTEGER PRIMARY KEY, netto_a REAL, netto_b REAL, d REAL, ts INTEGER);
"""
# Zeitspalten in Sekunden (Probe 16, Audit)
ZEITSPALTEN = {"nb_preis": ("ts",), "nb_kerze15": ("ts",), "nb_sigma": ("tag",), "nb_zustand": ("ts", "seit", "frei_ab"),
               "nb_schwellen": ("gueltig_ab",), "nb_episode": ("start", "ende"), "nb_blockiert": ("ts",), "nb_manuell": ("ts",),
               "nb_tag": ("tag", "ts")}


# --------------------------------------------------------------------------------------------- Pfade, Verbindung
def pfad_neben(db_main: str, name: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(db_main)), name)


def nb_pfad(db_main: str) -> str:
    """notbremse.db neben hl_liq.db (wie makro.db); HL_NOTBREMSE_DB setzt einen anderen Ort (Tests)."""
    return os.environ.get("HL_NOTBREMSE_DB") or pfad_neben(db_main, "notbremse.db")


def labor_a_pfad(store_b: str) -> str:
    """Speicher der Welt A neben dem Prognosespeicher (forecasts.db, darin die Welt B)."""
    return os.environ.get("HL_LABOR_A_DB") or os.path.join(os.path.dirname(os.path.abspath(store_b)), "labor_a.db")


def termine_pfad() -> str:
    return os.environ.get("HL_NOTBREMSE_TERMINE") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "notbremse_termine.json")


def verbinden(pfad: str, nur_lesen: bool = False) -> sqlite3.Connection:
    """Autocommit; geschrieben wird nur in kurzen Transaktionen mit BEGIN IMMEDIATE (schreiben())."""
    if nur_lesen:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, isolation_level=None)
        con.execute("PRAGMA busy_timeout=10000")
        return con
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None)
    con.execute("PRAGMA busy_timeout=30000")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


class schreiben:
    """with schreiben(con): ... -- BEGIN IMMEDIATE, Commit, bei Fehler Rollback (eiserne Regel: Schreiben mit BEGIN IMMEDIATE)."""

    def __init__(self, con):
        self.con = con

    def __enter__(self):
        self.con.execute("BEGIN IMMEDIATE")
        return self.con

    def __exit__(self, typ, wert, tb):
        if typ is None:
            self.con.execute("COMMIT")
        else:
            try:
                self.con.execute("ROLLBACK")
            except sqlite3.Error:
                pass
        return False


def meta_lesen(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM nb_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    if not r or r[0] is None:
        return standard
    try:
        return json.loads(r[0])
    except ValueError:
        return standard


def meta_setzen(con, werte: dict) -> None:
    con.executemany("INSERT OR REPLACE INTO nb_meta VALUES (?,?)", [(k, json.dumps(v)) for k, v in werte.items()])


def _uhr(ts) -> str:
    if ts is None:
        return "—"
    return datetime.fromtimestamp(int(ts), UTC).astimezone().strftime("%d.%m. %H:%M")


def _de(x, nd: int = 1) -> str:
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "—"
    return f"{x:,.{nd}f}".replace(",", "§").replace(".", ",").replace("§", ".")


# --------------------------------------------------------------------------------------------- Zeitklassen (KONZEPT 4.3)
def fruehschluss(d: date) -> bool:
    """NYSE schließt um 13:00 New Yorker Zeit: am Tag nach Thanksgiving, am 24.12. und am 03.07., wenn sie Handelstage sind (der 03.07.
    nur, wenn der 04.07. ein Werktag ist -- fällt er auf einen Samstag, ist der 03.07. selbst Feiertag)."""
    if not AK.handelstag(d):
        return False
    if d.month == 11 and d == AK._nter_wochentag(d.year, 11, 3, 4) + timedelta(days=1):
        return True
    if d.month == 12 and d.day == 24:
        return True
    if d.month == 7 and d.day == 3 and date(d.year, 7, 4).weekday() < 5:
        return True
    return False


_SITZUNG_CACHE: dict = {}


def sitzung(d: date):
    """(Beginn, Ende) der regulären Sitzung am New Yorker Tag d in UTC-Sekunden, sonst None. Beide auf dem 15-min-Raster in UTC."""
    if d in _SITZUNG_CACHE:
        return _SITZUNG_CACHE[d]
    out = None
    if AK.handelstag(d):
        out = (AK.ny_ts(d, 9, 30), AK.ny_ts(d, 13 if fruehschluss(d) else 16, 0))
    if len(_SITZUNG_CACHE) > 20_000:
        _SITZUNG_CACHE.clear()
    _SITZUNG_CACHE[d] = out
    return out


def _ny_datum(t: int) -> date:
    return datetime.fromtimestamp(int(t), NY).date()


def in_sitzung(t: int) -> bool:
    """Liegt die Minute (oder das 15-min-Intervall), die bei t beginnt, in der Sitzung?"""
    s = sitzung(_ny_datum(t))
    return bool(s and s[0] <= t < s[1])


def sitzungsminuten(von: int, bis: int) -> int:
    """Minuten in [von, bis) in der Sitzung (von, bis Vielfache von 60)."""
    n = 0
    d = _ny_datum(von) - timedelta(days=1)
    ende = _ny_datum(bis) + timedelta(days=1)
    while d <= ende:
        s = sitzung(d)
        if s:
            a, b = max(von, s[0]), min(bis, s[1])
            if b > a:
                n += (b - a) // 60
        d += timedelta(days=1)
    return n


def sitzungs_indikator(t0: int, t1: int) -> np.ndarray:
    """1 je Minute in [t0, t1) in der Sitzung, sonst 0 (t0, t1 Vielfache von 60)."""
    n = (t1 - t0) // 60
    s = np.zeros(max(n, 0), dtype=np.int8)
    if n <= 0:
        return s
    d = _ny_datum(t0) - timedelta(days=1)
    ende = _ny_datum(t1) + timedelta(days=1)
    while d <= ende:
        g = sitzung(d)
        if g:
            a, b = max(t0, g[0]), min(t1, g[1])
            if b > a:
                s[(a - t0) // 60:(b - t0) // 60] = 1
        d += timedelta(days=1)
    return s


# --------------------------------------------------------------------------------------------- σ je Instrument und Zeitklasse
def _mad_v(r: np.ndarray) -> float:
    m = float(np.median(r))
    mad = float(np.median(np.abs(r - m)))
    return (MAD_FAKTOR * mad) ** 2 / 15.0


def sigma_aus_kerzen(K: dict, tag: int, tage: int = SIGMA_TAGE, min_tage: int | None = None, gruppen: dict | None = None) -> dict:
    """
    K: {inst: (ts-Array, c-Array)} der 15-min-Schlüsse (c(ts) = Kurs am Ende von [ts, ts + 900)). Renditen r(ts) = ln c(ts) − ln c(ts − 900)
    für [ts, ts + 900) ganz in einer Zeitklasse, aus den `tage` Tagen vor `tag` (00:00 UTC; der Tag selbst nie). min_tage (erste
    Kalibrierung): weniger Tage erlaubt, mindestens so viele vorhanden. Untergrenze je Gruppe. -> {(inst, "S"/"A"): (v, n)}, ungültig: v None.
    """
    von = tag - tage * TAG
    out = {}
    for inst, (ts, c) in K.items():
        if ts is None or not len(ts):
            continue
        m = (ts >= von - 900) & (ts < tag)
        tsi, ci = ts[m], c[m]
        if min_tage is not None:
            erste = int(tsi[0]) if len(tsi) else tag
            if tag - erste < min_tage * TAG:
                for k in ("S", "A"):
                    out[(inst, k)] = (None, 0)
                continue
        if len(tsi) < 2:
            for k in ("S", "A"):
                out[(inst, k)] = (None, 0)
            continue
        idx = {int(t): i for i, t in enumerate(tsi)}
        r_s, r_a = [], []
        for i, t in enumerate(tsi):
            t = int(t)
            if t < von or t >= tag:
                continue
            j = idx.get(t - 900)
            if j is None or ci[j] <= 0 or ci[i] <= 0:
                continue
            r = math.log(ci[i] / ci[j])
            (r_s if in_sitzung(t) else r_a).append(r)
        for k, rr in (("S", r_s), ("A", r_a)):
            out[(inst, k)] = (_mad_v(np.asarray(rr)) if len(rr) >= SIGMA_MIN_N else None, len(rr))
    if gruppen:
        for g, mitglieder in gruppen.items():
            for k in ("S", "A"):
                vs = [out[(i, k)][0] for i in mitglieder if (i, k) in out and out[(i, k)][0]]
                if not vs:
                    continue
                boden = SIGMA_BODEN * float(np.median(vs))
                for i in mitglieder:
                    v, n = out.get((i, k), (None, 0))
                    if v is not None and v < boden:
                        out[(i, k)] = (boden, n)
    return out


def sigma_reihe(t0: int, P15: dict, tage: list, fenster_tage: int = SIGMA_TAGE, min_tage: int | None = None, gruppen: dict | None = None) -> dict:
    """
    Dieselbe Regel wie sigma_aus_kerzen, für viele Tage auf einmal: P15 = {inst: c-Array} auf dem regelmäßigen 15-min-Raster ts = t0 + 900 k
    (c(ts) = Kurs am Ende von [ts, ts + 900)). Für jeden Tag D in `tage` die σ aus den Renditen mit ts in [D − fenster_tage, D).
    -> {D: {(inst, "S"/"A"): v}} (nur gültige)
    """
    out = {int(D): {} for D in tage}
    if not P15:
        return out
    n = len(next(iter(P15.values())))
    ts = t0 + 900 * np.arange(n, dtype=np.int64)
    S = sitzungs_indikator(t0, t0 + 900 * n)[::15].astype(bool) if n else np.zeros(0, dtype=bool)
    erste = {}
    R = {}
    with np.errstate(divide="ignore", invalid="ignore"):
        for inst, c in P15.items():
            r = np.full(n, np.nan)
            r[1:] = np.log(c[1:] / c[:-1])
            R[inst] = r
            ok = np.nonzero(np.isfinite(c))[0]
            erste[inst] = int(ts[ok[0]]) if len(ok) else None
    for D in tage:
        D = int(D)
        lo = max(0, (D - fenster_tage * TAG - t0) // 900); hi = max(0, min(n, (D - t0) // 900))
        for inst, r in R.items():
            if min_tage is not None and (erste[inst] is None or D - erste[inst] < min_tage * TAG):
                continue
            seg = r[lo:hi]; sg = S[lo:hi]
            for k, maske in (("S", sg), ("A", ~sg)):
                x = seg[maske]
                x = x[np.isfinite(x)]
                if len(x) >= SIGMA_MIN_N:
                    out[D][(inst, k)] = _mad_v(x)
        if gruppen:
            for g, mitglieder in gruppen.items():
                for k in ("S", "A"):
                    vs = [out[D][(i, k)] for i in mitglieder if (i, k) in out[D]]
                    if not vs:
                        continue
                    boden = SIGMA_BODEN * float(np.median(vs))
                    for i in mitglieder:
                        if (i, k) in out[D] and out[D][(i, k)] < boden:
                            out[D][(i, k)] = boden
    return out


def sigma_fenster(v_s, v_a, n_s: int, n_a: int):
    """σ(i, w, t) = √(n_S · v_S + n_A · v_A); fehlt ein gebrauchtes v: None."""
    if (n_s and v_s is None) or (n_a and v_a is None):
        return None
    s = (n_s * (v_s or 0.0)) + (n_a * (v_a or 0.0))
    return math.sqrt(s) if s > 0 else None


# --------------------------------------------------------------------------------------------- Maße auf einem Raster (KONZEPT 4.4)
def _ffill(a: np.ndarray, max_schritte: int) -> np.ndarray:
    """Lücken mit dem letzten Wert füllen, höchstens max_schritte Raster weit (ein Mid gilt 120 s)."""
    if max_schritte <= 0:
        return a
    out = a.copy()
    letzt = np.nan; alter = 0
    for k in range(len(out)):
        if np.isfinite(out[k]):
            letzt = out[k]; alter = 0
        elif np.isfinite(letzt) and alter < max_schritte:
            alter += 1; out[k] = letzt
        else:
            letzt = np.nan if alter >= max_schritte else letzt
            alter += 1
    return out


def reihe_masse(t0: int, schritt: int, P: dict, gruppen: dict, V: dict, fenster: dict, nur_ab: int | None = None,
                min_n: dict | None = None) -> dict:
    """
    Raster T[k] = t0 + k · schritt (Sekunden; schritt 60 oder 900). P = {inst: np.array (Kurs zur Zeit T[k], NaN = fehlt)}.
    gruppen = {"K": [...], "A": [...]}; V = {tag: {(inst, "S"/"A"): v}} (die σ, die an jenem Tag gelten); fenster = {"K": (min, ...),
    "A": (min, ...), "X": (...), "Y": (...)}. Für jedes k ab nur_ab: z = r / σ (σ aus den Sitzungs- und den übrigen Minuten des
    Fensters [T − w, T)), G je Gruppe und Fenster (Median, gültig ab min_n Instrumenten), X und Y.
    -> {"T", "G": {(g, w): array}, "N": {(g, w): array}, "X", "Y", "GK60"}
    """
    min_n = min_n or {"K": K_MIN, "A": A_MIN}
    n = len(next(iter(P.values()))) if P else 0
    T = t0 + schritt * np.arange(n, dtype=np.int64)
    k0 = 0 if nur_ab is None else max(0, int((nur_ab - t0) // schritt))
    alle_w = [w for g in ("K", "A") for w in fenster.get(g, ())]
    w_max = max(alle_w) if alle_w else 0
    s0 = t0 - w_max * 60
    S = sitzungs_indikator(s0, t0 + n * schritt + 60)
    C = np.concatenate([[0], np.cumsum(S, dtype=np.int64)])            # C[j] = Sitzungsminuten in [s0, s0 + 60 j)
    tage = (T // TAG) * TAG
    u_tage, inv = np.unique(tage, return_inverse=True)
    vcache: dict = {}

    def varr(inst, k):
        if (inst, k) not in vcache:
            u = np.array([(V.get(int(d)) or {}).get((inst, k)) or np.nan for d in u_tage], dtype=float)
            vcache[(inst, k)] = u[inv] if len(u) else np.full(n, np.nan)
        return vcache[(inst, k)]
    G, N = {}, {}
    ja = np.arange(n)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        for g, mitglieder in gruppen.items():
            mitglieder = [i for i in mitglieder if i in P]
            for w in fenster.get(g, ()):
                L = (w * 60) // schritt
                if L * schritt != w * 60:
                    raise ValueError(f"Fenster {w} min passt nicht auf das Raster {schritt} s")
                lo_idx = np.clip(((T - w * 60) - s0) // 60, 0, len(C) - 1)
                hi_idx = np.clip((T - s0) // 60, 0, len(C) - 1)
                n_s = (C[hi_idx] - C[lo_idx]).astype(float)
                n_a = w - n_s
                Z = np.full((max(len(mitglieder), 1), n), np.nan)
                for r_, inst in enumerate(mitglieder):
                    p = P[inst]
                    vs, va = varr(inst, "S"), varr(inst, "A")
                    fehlt = ((n_s > 0) & ~np.isfinite(vs)) | ((n_a > 0) & ~np.isfinite(va))
                    sig = np.sqrt(np.where(n_s > 0, n_s * np.nan_to_num(vs), 0.0) + np.where(n_a > 0, n_a * np.nan_to_num(va), 0.0))
                    sig = np.where(fehlt | (sig <= 0), np.nan, sig)
                    vor = np.full(n, np.nan)
                    if L < n:
                        vor[L:] = p[:n - L]
                    with np.errstate(divide="ignore", invalid="ignore"):
                        z = np.log(p / vor) / sig
                    z = np.clip(z, -Z_KAPPE, Z_KAPPE)
                    z[ja < k0] = np.nan
                    Z[r_] = z
                cnt = np.sum(np.isfinite(Z), axis=0) if mitglieder else np.zeros(n, dtype=int)
                med = np.nanmedian(Z, axis=0) if mitglieder else np.full(n, np.nan)
                G[(g, w)] = np.where(cnt >= min_n.get(g, 1), med, np.nan); N[(g, w)] = cnt
        X = np.full(n, np.nan)
        for w in fenster.get("X", ()):
            gk, ga = G.get(("K", w)), G.get(("A", w))
            if gk is None or ga is None:
                continue
            m = np.maximum(gk, ga)                                            # beide müssen fallen, maßgeblich der schwächere
            X = np.where(np.isfinite(m) & (~np.isfinite(X) | (m < X)), m, X)
        Y = np.full(n, np.nan)
        for w in fenster.get("Y", ()):
            gk = G.get(("K", w))
            if gk is None:
                continue
            Y = np.where(np.isfinite(gk) & (~np.isfinite(Y) | (gk < Y)), gk, Y)
    return {"T": T, "G": G, "N": N, "X": X, "Y": Y, "GK60": G.get(("K", 60))}


FENSTER_LIVE = {"K": tuple(sorted(set(W_X) | set(W_Y))), "A": W_X, "X": W_X, "Y": W_Y}      # 1-min-Raster
FENSTER_X15 = {"K": W_X, "A": W_X, "X": W_X}                                                   # Kalibrierung X (15-min-Raster)
FENSTER_Y1 = {"K": W_Y, "Y": W_Y}                                                              # Kalibrierung Y (1-min, eigene Coins)


# --------------------------------------------------------------------------------------------- Λ (KONZEPT 4.4)
LIQ_COINS = EIGENE                                         # alle Coins der Tabelle liquidations außer PAXG (der Recorder zeichnet nur diese auf)


def liq_summen(con_main, t_von: int, t_bis: int, raster: int, seite: str = "A") -> dict:
    """Liquidationen (side A = Long liquidiert, B = Short; USD = px·sz) je Rasterintervall [k·raster, (k+1)·raster), alle Coins außer
    PAXG -- je Coin über den Index (coin, ts)."""
    out: dict = {}
    for coin in LIQ_COINS:
        try:
            for t, usd in con_main.execute(f"SELECT (ts / {int(raster)}) * {int(raster)}, SUM(px * sz) FROM liquidations WHERE coin = ? AND ts >= ? "
                                           "AND ts < ? AND side = ? GROUP BY 1", (coin, int(t_von), int(t_bis), seite)):
                out[int(t)] = out.get(int(t), 0.0) + float(usd or 0.0)
        except sqlite3.Error:
            pass
    return out


def liq_15min_summen(con_main, t_von: int, t_bis: int, seite: str = "A") -> dict:
    return liq_summen(con_main, t_von, t_bis, 900, seite)


def lam_referenz(con_main, tag: int, seite: str = "A") -> dict:
    """Nicht überlappende 15-min-Summen der 30 Tage vor `tag` (00:00 UTC), je Zeitklasse sortiert (Intervalle ohne Liquidation = 0)."""
    von = tag - SIGMA_TAGE * TAG
    summen = liq_15min_summen(con_main, von, tag, seite)
    ref = {"S": [], "A": []}
    for t in range(von, tag, 900):
        ref["S" if in_sitzung(t) else "A"].append(summen.get(t, 0.0))
    return {k: sorted(v) for k, v in ref.items()}


def lam_wert(x: float, ref: list) -> float | None:
    """(Anzahl kleinerer + 0,5 · Anzahl gleicher Werte) / Anzahl."""
    if not ref:
        return None
    lo = bisect.bisect_left(ref, x); hi = bisect.bisect_right(ref, x)
    return (lo + 0.5 * (hi - lo)) / len(ref)


def liq_fenster(con_main, t: int, seite: str = "A") -> float:
    """Summe in (t − 15 min, t]."""
    s = 0.0
    for coin in LIQ_COINS:
        try:
            r = con_main.execute("SELECT SUM(px * sz) FROM liquidations WHERE coin = ? AND ts > ? AND ts <= ? AND side = ?",
                                 (coin, int(t) - 900, int(t), seite)).fetchone()
            s += float(r[0] or 0.0)
        except sqlite3.Error:
            pass
    return s


# --------------------------------------------------------------------------------------------- Zustandsmaschine (KONZEPT 4.5, 4.6)
class Maschine:
    """
    Stufen je Minute. Markt (und später Ebene B): Stufe 1 bei X ≤ θ1 (Wache: θ1/2), Stufe 2 bei X ≤ θ2X oder Y ≤ θ2Y mit Λ ≥ 0,99.
    Ende: Stufe 2 → 1 frühestens 240 min nach der letzten Stufe-2-Bedingung; Stufe 1 → 0, wenn seit der letzten Bedingung 120 min
    vergangen sind und seit 30 min X > θ1/2, G_K(60) > θ1/2 (θ1 ohne Wache; undefiniert zählt nicht dagegen) und Λ < 0,90 gelten.
    Termine gelten genau in ihrem Zeitraum, die Handbremse bis zu ihrer Zeit oder bis „Sperre aufheben“ (danach 60 min nur Stufe 2).
    Der Zustand ist ein JSON-fähiges dict (nb_meta „maschine“), damit ein Neustart fortsetzt.
    """

    def __init__(self, st: dict | None = None, spiegel: bool = False):
        st = dict(st or {})
        self.st = {"stufe_m": int(st.get("stufe_m", 0)), "quelle_m": st.get("quelle_m"), "b1": st.get("b1"), "b2": st.get("b2"),
                   "hyst_seit": st.get("hyst_seit"), "lam_seit": st.get("lam_seit"), "ruhe_bis": st.get("ruhe_bis"),
                   "manuell": st.get("manuell"), "seit": st.get("seit"), "stufe": int(st.get("stufe", 0)), "ep_start": st.get("ep_start"),
                   "ep_max": int(st.get("ep_max", 0)), "aktionen_bis": int(st.get("aktionen_bis", 0)), "t_letzt": st.get("t_letzt")}
        self.spiegel = spiegel

    def aktion(self, a: dict) -> None:
        """Handbremse: {ts, aktion, dauer_s, grund}."""
        s = self.st; t = int(a["ts"]); art = a.get("aktion")
        if art == "aufheben":
            s.update(manuell=None, stufe_m=0, quelle_m=None, b1=None, b2=None, hyst_seit=None, lam_seit=None, ruhe_bis=t + RUHE_S)
        elif art in MANUELL_DAUER:
            d = a.get("dauer_s", MANUELL_DAUER[art])
            s["manuell"] = {"stufe": 2 if art == "schock4h" else 1, "seit": t, "bis": (t + int(d)) if d else None, "grund": a.get("grund") or "",
                            "aktion": art}
        s["aktionen_bis"] = max(int(s.get("aktionen_bis") or 0), int(a.get("id") or 0))

    def schritt(self, t: int, m: dict, th: dict, termin: dict | None = None, wache: bool = False) -> dict:
        """m = {X, Y, lam, GK60} (None = undefiniert). -> {stufe, quelle, grund, seit, frei_ab, neu (Episode beginnt), ende (Episode endet)}"""
        s = self.st; t = int(t)
        X, Y, lam, gk60 = m.get("X"), m.get("Y"), m.get("lam"), m.get("GK60")
        man = s.get("manuell")
        if man and man.get("bis") is not None and t >= int(man["bis"]):
            s["manuell"] = man = None
        ruhe = s.get("ruhe_bis") is not None and t < int(s["ruhe_bis"])
        th1 = th["theta1"] / 2.0 if wache else th["theta1"]
        c1 = X is not None and X <= th1
        c2x = X is not None and X <= th["theta2x"]
        c2y = Y is not None and lam is not None and Y <= th["theta2y"] and lam >= LAM_STUFE2
        c2 = c2x or c2y
        if c2:
            s["stufe_m"] = 2; s["b2"] = t; s["b1"] = t; s["quelle_m"] = "markt_x" if c2x else "markt_y"
        elif c1 and not ruhe:
            if s["stufe_m"] < 1:
                s["quelle_m"] = "markt_x"
            s["stufe_m"] = max(s["stufe_m"], 1); s["b1"] = t
        halb = th["theta1"] / 2.0                                            # Hysterese immer mit θ1 ohne Wache
        hyst = (X is None or X > halb) and (gk60 is None or gk60 > halb)
        s["hyst_seit"] = (s.get("hyst_seit") if s.get("hyst_seit") is not None else t) if hyst else None
        lam_ok = lam is None or lam < LAM_FREI
        s["lam_seit"] = (s.get("lam_seit") if s.get("lam_seit") is not None else t) if lam_ok else None
        if s["stufe_m"] == 2 and not c2 and s.get("b2") is not None and t - int(s["b2"]) >= STUFE2_MIN_S:
            s["stufe_m"] = 1
        if (s["stufe_m"] == 1 and not c2 and not (c1 and not ruhe) and s.get("b1") is not None and t - int(s["b1"]) >= STUFE1_MIN_S
                and s.get("hyst_seit") is not None and t - int(s["hyst_seit"]) >= HYST_S
                and s.get("lam_seit") is not None and t - int(s["lam_seit"]) >= HYST_S):
            s["stufe_m"] = 0; s["quelle_m"] = None
        st_t = 1 if (termin and not ruhe) else 0
        st_man = int(man["stufe"]) if man else 0
        stufe = max(s["stufe_m"], st_t, st_man)
        quellen = []
        if man:
            quellen.append(("manuell", st_man))
        if s["stufe_m"]:
            quellen.append((s.get("quelle_m") or "markt_x", s["stufe_m"]))
        if st_t:
            quellen.append(("termin", 1))
        quelle = max(quellen, key=lambda q: q[1])[0] if quellen else None
        vorher = int(s.get("stufe") or 0)
        neu = ende = False
        if stufe >= 1 and vorher == 0:
            s["seit"] = t; s["ep_start"] = t; s["ep_max"] = stufe; neu = True
        elif stufe >= 1:
            s["ep_max"] = max(int(s.get("ep_max") or 0), stufe)
        elif vorher >= 1:
            ende = True; s["seit"] = None
        s["stufe"] = stufe; s["t_letzt"] = t
        frei = []
        if s["stufe_m"] >= 1 and s.get("b1") is not None:
            frei.append(int(s["b1"]) + STUFE1_MIN_S)
        if s["stufe_m"] == 2 and s.get("b2") is not None:
            frei.append(int(s["b2"]) + STUFE2_MIN_S)
        if man:
            frei.append(int(man["bis"]) if man.get("bis") is not None else None)
        if st_t:
            frei.append(int(termin["ende"]))
        frei_ab = None if (None in frei) else (max(frei) if frei else None)
        teile = []
        if c2x:
            teile.append(f"Gleichlauf X {X:+.1f} σ ≤ {th['theta2x']:+.2f}")
        elif c1:
            teile.append(f"Gleichlauf X {X:+.1f} σ ≤ {th1:+.2f}" + (" (Wache)" if wache else ""))
        if c2y:
            teile.append(f"Krypto Y {Y:+.1f} σ ≤ {th['theta2y']:+.2f}, Λ {lam * 100:.1f}. Perzentil")
        if man:
            teile.append("Handbremse " + ("Schock" if st_man == 2 else "Long-Sperre") + (f" bis {_uhr(man['bis'])}" if man.get("bis") else
                                                                                          " bis auf Widerruf") + (f": {man['grund']}" if man.get("grund") else ""))
        if st_t:
            teile.append(f"Termin „{termin.get('name', '')}“ bis {_uhr(termin['ende'])}")
        if ruhe:
            teile.append(f"Ruhefenster nach „Sperre aufheben“ bis {_uhr(s['ruhe_bis'])} (nur Stufe 2 löst aus)")
        if not teile and s["stufe_m"]:
            teile.append("Sperre hält (" + ("Stufe 2 mindestens 240 min" if s["stufe_m"] == 2 else "Freigabe erst nach 120 min ohne Bedingung "
                                            "und 30 min Ruhe") + ")")
        return {"stufe": stufe, "quelle": quelle, "grund": "; ".join(teile), "seit": s.get("seit"), "frei_ab": frei_ab, "neu": neu, "ende": ende,
                "ep_start": s.get("ep_start"), "ep_max": int(s.get("ep_max") or 0), "c1": c1, "c2": c2, "ruhe": ruhe}


def termin_aktiv(termine: list, t: int) -> dict | None:
    for e in termine or []:
        try:
            a, b = int(e["start"]), int(e["ende"])
        except (KeyError, TypeError, ValueError):
            continue
        if a <= t < b:
            return {"name": e.get("name", ""), "start": a, "ende": b}
    return None


def _zeit_lesen(v) -> int | None:
    """UTC: Unix-Sekunden, „2026-11-03T23:00Z“, „2026-11-03T23:00:00+00:00“ oder „2026-11-03 23:00“."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v) if v < 1e11 else None
    s = str(v).strip().replace("Z", "+00:00")
    for fmt in ("%Y-%m-%dT%H:%M%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            d = datetime.strptime(s, fmt)
            if d.tzinfo is None:
                d = d.replace(tzinfo=UTC)
            return int(d.timestamp())
        except ValueError:
            continue
    return None


def termine_lesen(pfad: str | None = None) -> tuple:
    """-> (Termine [{name, start, ende}], Fehlertext). Ungültige Einträge werden genannt, nicht still verworfen."""
    pfad = pfad or termine_pfad()
    try:
        with open(pfad, encoding="utf-8") as f:
            roh = json.load(f)
    except FileNotFoundError:
        return [], None
    except (OSError, ValueError) as e:
        return [], f"{os.path.basename(pfad)}: {type(e).__name__}: {e}"
    liste = roh.get("termine") if isinstance(roh, dict) else roh
    out, fehler = [], []
    for e in liste if isinstance(liste, list) else []:
        if not isinstance(e, dict):
            continue
        a, b = _zeit_lesen(e.get("start")), _zeit_lesen(e.get("ende"))
        if a is None or b is None or b <= a:
            fehler.append(str(e.get("name") or e)[:40])
            continue
        out.append({"name": str(e.get("name") or "Termin")[:80], "start": a, "ende": b})
    return sorted(out, key=lambda e: e["start"]), ("ungültig: " + ", ".join(fehler)) if fehler else None


# --------------------------------------------------------------------------------------------- Kalibrierung (KONZEPT 4.5)
def episoden(T: np.ndarray, bed: np.ndarray, schritt: int, luecke: int = EPISODE_LUECKE_S) -> list:
    """Zusammenhängende Zeitpunkte mit erfüllter Bedingung; Läufe mit weniger als `luecke` Abstand sind eine Episode. -> [(start, ende)]"""
    idx = np.nonzero(bed)[0]
    if not len(idx):
        return []
    out = []
    a = int(T[idx[0]]); b = a
    for k in idx[1:]:
        t = int(T[k])
        if t - b - schritt < luecke:
            b = t
        else:
            out.append((a, b)); a = b = t
    out.append((a, b))
    return out


def schwelle_waehlen(T: np.ndarray, werte: np.ndarray, schritt: int, budget: float, tage: float, zusatz: np.ndarray | None = None) -> dict:
    """θ = größter Rasterwert, bei dem er selbst und alle kleineren das Budget je 30 Tage einhalten (eindeutig, auch wenn sich eine
    lange Episode bei strengerer Schwelle teilt). -> {theta, je30 (bei θ), raten, keiner (kein Wert hält das Budget)}"""
    raten = []
    for th in RASTER:
        bed = np.isfinite(werte) & (werte <= th)
        if zusatz is not None:
            bed &= zusatz
        n = len(episoden(T, bed, schritt))
        raten.append(n * 30.0 / max(tage, 1e-9))
    theta = None; je30 = None
    alle_ok = True
    for th, r in zip(reversed(RASTER), reversed(raten)):                  # von −8,00 aufwärts
        alle_ok = alle_ok and r <= budget + 1e-12
        if alle_ok:
            theta = th; je30 = r
    return {"theta": theta if theta is not None else RASTER[-1], "je30": je30, "keiner": theta is None,
            "raten": dict(zip(RASTER, raten))}


def klammern(roh: dict) -> tuple:
    """Klammern anwenden: θ1 ∈ [−3,5; −1,5]; θ2X ∈ [−6,0; −2,5] und ≤ θ1 − 0,5; θ2Y ∈ [−8,0; −3,0]. -> (Schwellen, Liste an der Klammer)"""
    out = {}; an = []
    for k in ("theta1", "theta2x", "theta2y"):
        lo, hi = KLAMMER[k]
        v = min(max(float(roh[k]), lo), hi)
        if v != float(roh[k]) or v in (lo, hi):
            an.append(k)
        out[k] = v
    if out["theta2x"] > out["theta1"] - 0.5:
        out["theta2x"] = round(max(out["theta1"] - 0.5, KLAMMER["theta2x"][0]), 2)
        if "theta2x" not in an:
            an.append("theta2x")
    return out, an


def kalibrieren(X_reihe: dict | None, Y_reihe: dict | None, budget: dict | None = None) -> dict:
    """
    X_reihe = {T, X, schritt, tage}; Y_reihe = {T, Y, lam, schritt, tage}. Liegen weniger als 21 Tage mit beiden Gruppen vor, gelten die
    Startwerte. -> {theta1, theta2x, theta2y, klammer (Liste), quelle ("kalibriert"/"Startwerte"), info}
    """
    budget = dict(budget or BUDGET)
    info = {"budget": budget}
    if not X_reihe or X_reihe.get("tage", 0) < KALIB_MIN_TAGE:
        info["grund"] = f"zu wenige Tage mit beiden Gruppen ({X_reihe.get('tage', 0) if X_reihe else 0:.1f} < {KALIB_MIN_TAGE})"
        return dict(START, klammer=[], quelle="Startwerte", info=info)
    s1 = schwelle_waehlen(X_reihe["T"], X_reihe["X"], X_reihe["schritt"], budget["s1x"], X_reihe["tage"])
    s2x = schwelle_waehlen(X_reihe["T"], X_reihe["X"], X_reihe["schritt"], budget["s2x"], X_reihe["tage"])
    roh = {"theta1": s1["theta"], "theta2x": s2x["theta"], "theta2y": START["theta2y"]}
    info.update(s1x={"theta": s1["theta"], "je30": s1["je30"], "keiner": s1["keiner"]},
                s2x={"theta": s2x["theta"], "je30": s2x["je30"], "keiner": s2x["keiner"]}, tage_x=X_reihe["tage"])
    wahl = {"s1x": (s1, "theta1"), "s2x": (s2x, "theta2x")}
    if Y_reihe and Y_reihe.get("tage", 0) >= KALIB_MIN_TAGE:
        lam = Y_reihe["lam"]
        s2y = schwelle_waehlen(Y_reihe["T"], Y_reihe["Y"], Y_reihe["schritt"], budget["s2y"], Y_reihe["tage"],
                               zusatz=np.isfinite(lam) & (lam >= LAM_STUFE2))
        roh["theta2y"] = s2y["theta"]
        info.update(s2y={"theta": s2y["theta"], "je30": s2y["je30"], "keiner": s2y["keiner"]}, tage_y=Y_reihe["tage"])
        wahl["s2y"] = (s2y, "theta2y")
    else:
        info["s2y"] = {"grund": "zu wenige Tage für Y -- Startwert"}
    th, an = klammern(roh)
    # 23.77: dazu die Rate bei der WIRKSAMEN Schwelle (nach der Klammer bzw. ohne einen Wert, der das Budget hält). Vorher stand nur die
    # Rate beim Rohwert im Bericht: am Pi zeigte Budget 2 „1,54 je 30 Tage“, wirksam waren bei θ1 = −3,50 (Klammer) aber 3,85 wie bei Budget 4.
    for pfad, (sel, k) in wahl.items():
        info[pfad]["theta_wirksam"] = th[k]
        info[pfad]["je30_wirksam"] = sel["raten"].get(round(float(th[k]), 2))
    return dict(th, klammer=an, quelle="kalibriert", info=info, roh=roh)


# --------------------------------------------------------------------------------------------- Zustand und Tor (KONZEPT 3)
def _zeile_zustand(r) -> dict:
    return {"ts": int(r[0]), "stufe": int(r[1] or 0), "quelle": r[2], "grund": r[3] or "", "x": r[4], "y": r[5], "lam": r[6],
            "wache": bool(r[7]), "seit": r[8], "frei_ab": r[9], "hinweis": r[10] or "", "gk": r[11], "ga": r[12]}


def zustand(con, t: int | None = None) -> dict | None:
    """Jüngste Zeile mit ts ≤ t: {stufe, seit, frei_ab, quelle, grund, x, y, lam, wache, alter_s, ...} oder None."""
    t = int(t if t is not None else time.time())
    try:
        r = con.execute("SELECT ts, stufe, quelle, grund, x, y, lam, wache, seit, frei_ab, hinweis, gk_json, ga_json FROM nb_zustand "
                        "WHERE ts <= ? ORDER BY ts DESC, id DESC LIMIT 1", (t,)).fetchone()
    except sqlite3.Error:
        return None
    if not r:
        return None
    z = _zeile_zustand(r)
    z["alter_s"] = t - z["ts"]
    for k in ("gk", "ga"):
        try:
            z[k] = json.loads(z[k]) if z[k] else {}
        except ValueError:
            z[k] = {}
    return z


def darf(con, t: int, seite: str, art: str, welt_start: int | None = None) -> tuple:
    """Das eine Tor (KONZEPT 2.3): für short, schliessen und verkleinern immer True; sonst nur bei Stufe 0 und höchstens 180 s altem
    Zustand zum Zeitpunkt des Vorgangs. Vor dem Start der Welt A ist A gleich B (True)."""
    if seite != "long" or art in ("schliessen", "verkleinern"):
        return True, ""
    if welt_start is not None and int(t) < int(welt_start):
        return True, ""
    z = zustand(con, t)
    if z is None:
        return False, "Notbremse veraltet (kein Zustand)"
    if z["alter_s"] > ZUSTAND_MAX_ALTER:
        return False, f"Notbremse veraltet ({z['alter_s']} s ohne Zustand)"
    if z["stufe"] >= 1:
        return False, f"Notbremse Stufe {z['stufe']}"
    return True, ""


class Tor:
    """
    Das Tor für das Labor der Welt A, je Takt einmal vorbereitet (alle Zustandszeilen des Zeitraums im Speicher), damit die vielen
    Fragen eines Taktes keine Datenbankabfragen kosten. Gesperrte Vorgänge sammelt es und schreibt sie am Ende des Taktes nach
    nb_blockiert (derselbe Vorgang je Strategie, Coin, Seite und Art höchstens alle 15 min).
    zustaende: für Rückwärtstests eine feste Liste [(ts, stufe, grund)] statt notbremse.db.
    """

    def __init__(self, pfad: str | None, welt: str = "A", welt_start: int | None = None, zustaende: list | None = None,
                 protokollieren: bool = True):
        self.pfad = pfad; self.welt = welt; self.welt_start = welt_start; self.fest = zustaende is not None
        self.zeilen: list = sorted(zustaende or [], key=lambda z: z[0]) if zustaende is not None else []
        self.ts: list = [z[0] for z in self.zeilen]
        self.puffer: list = []; self.zuletzt: dict = {}; self.protokollieren = protokollieren
        self.fehler: str | None = None; self.von = None; self.bis = None; self.zaehler = {"gesperrt": 0, "storniert": 0}
        self.letzte_id = 0

    def vorbereiten(self, t_von: int, t_bis: int) -> None:
        """Zustandszeilen für Fragen in [t_von, t_bis] bereitlegen: neue Zeilen über die id (die Handbremse schreibt mit Sekunden-
        Zeitstempel zwischen die Minutenzeilen des Dienstes), Älteres als t_von verworfen (eine Zeile davor bleibt)."""
        if self.fest:
            return
        von = int(t_von) - ZUSTAND_MAX_ALTER - 60
        if self.von is None or von < self.von:                        # erster Aufruf oder weiter zurück als bisher: alles neu
            self.zeilen = []; self.letzte_id = 0
        self.von, self.bis = von, int(t_bis)
        try:
            if not os.path.exists(self.pfad):
                raise sqlite3.OperationalError("notbremse.db fehlt")
            con = verbinden(self.pfad, nur_lesen=True)
            try:
                if not self.zeilen:
                    vor = con.execute("SELECT id, ts, stufe, grund FROM nb_zustand WHERE ts < ? ORDER BY ts DESC, id DESC LIMIT 1", (von,)).fetchone()
                    rows = ([vor] if vor else []) + con.execute("SELECT id, ts, stufe, grund FROM nb_zustand WHERE ts >= ? ORDER BY id",
                                                                (von,)).fetchall()
                else:
                    rows = con.execute("SELECT id, ts, stufe, grund FROM nb_zustand WHERE id > ? ORDER BY id", (self.letzte_id,)).fetchall()
            finally:
                con.close()
            for r in rows:
                self.letzte_id = max(self.letzte_id, int(r[0]))
                z = (int(r[1]), int(r[2] or 0), r[3] or "", int(r[0]))
                i = bisect.bisect_right([(x[0], x[3]) for x in self.zeilen], (z[0], z[3])) if self.zeilen and z[0] < self.zeilen[-1][0] else len(self.zeilen)
                self.zeilen.insert(i, z)
            j = bisect.bisect_left([x[0] for x in self.zeilen], von)
            if j > 1:
                self.zeilen = self.zeilen[j - 1:]
            self.fehler = None
        except sqlite3.Error as e:
            self.zeilen = []; self.letzte_id = 0; self.von = None; self.fehler = f"notbremse.db nicht lesbar ({type(e).__name__}: {e})"
        self.ts = [z[0] for z in self.zeilen]

    def stufe(self, t: int) -> tuple:
        """-> (Stufe oder None bei veraltet/fehlend, Grund)"""
        if self.welt_start is not None and int(t) < int(self.welt_start):
            return 0, ""
        i = bisect.bisect_right(self.ts, int(t)) - 1
        if i < 0:
            return None, "Notbremse veraltet (" + (self.fehler or "kein Zustand") + ")"
        z = self.zeilen[i]
        if int(t) - int(z[0]) > ZUSTAND_MAX_ALTER:
            return None, f"Notbremse veraltet ({int(t) - int(z[0])} s ohne Zustand)"
        return int(z[1] or 0), (z[2] or "")

    def darf(self, t: int, seite: str, art: str) -> tuple:
        if seite != "long" or art in ("schliessen", "verkleinern"):
            return True, ""
        st, grund = self.stufe(t)
        if st is None:
            return False, grund
        if st >= 1:
            return False, f"Notbremse Stufe {st}"
        return True, ""

    def protokoll(self, ts, sid, coin, seite, art, preis, grund) -> None:
        key = (sid, coin, seite, art)
        if art != "storno":
            self.zaehler["gesperrt"] += 1
            letzt = self.zuletzt.get(key)
            if letzt is not None and 0 <= int(ts) - letzt < BLOCK_LOG_S:
                return
            self.zuletzt[key] = int(ts)
        else:
            self.zaehler["storniert"] += 1
        if self.protokollieren:
            self.puffer.append((int(ts), self.welt, sid, coin, seite, art, preis, grund))

    def schreiben(self) -> None:
        if not self.puffer or self.fest or not self.pfad:
            self.puffer = [] if self.fest else self.puffer
            return
        try:
            con = verbinden(self.pfad)
            try:
                with schreiben(con):
                    con.executemany("INSERT INTO nb_blockiert (ts, welt, sid, coin, seite, art, preis, grund) VALUES (?,?,?,?,?,?,?,?)",
                                    self.puffer)
            finally:
                con.close()
            self.puffer = []
        except sqlite3.Error as e:
            self.fehler = f"nb_blockiert: {type(e).__name__}: {e}"
            if len(self.puffer) > 5000:
                self.puffer = self.puffer[-5000:]


def audit_zeiten(pfad: str) -> list:
    """Probe 16: alle Zeitspalten der nb_*-Tabellen in Sekunden (über 1e11 = Millisekunden). -> Liste der Verstöße."""
    out = []
    try:
        con = verbinden(pfad, nur_lesen=True)
    except sqlite3.Error as e:
        return [f"notbremse.db nicht lesbar: {e}"]
    try:
        for tab, spalten in ZEITSPALTEN.items():
            for sp in spalten:
                try:
                    hi = con.execute(f'SELECT MAX("{sp}") FROM "{tab}"').fetchone()[0]
                except sqlite3.Error:
                    continue
                if hi is not None and hi > 1e11:
                    n = con.execute(f'SELECT COUNT(*) FROM "{tab}" WHERE "{sp}" > 1e11').fetchone()[0]
                    out.append(f"{tab}.{sp}: {hi:,.0f} sieht nach Millisekunden aus ({n} Zeilen)")
    finally:
        con.close()
    return out


# --------------------------------------------------------------------------------------------- Daten lesen (Raster, σ, Λ)
def kerzen15_lesen(con, insts, von: int, bis: int) -> dict:
    """{inst: (ts-Array, c-Array)} aus nb_kerze15 in [von, bis)."""
    out = {}
    for inst in insts:
        rows = con.execute("SELECT ts, c FROM nb_kerze15 WHERE inst=? AND ts>=? AND ts<? ORDER BY ts", (inst, int(von), int(bis))).fetchall()
        out[inst] = (np.array([r[0] for r in rows], dtype=np.int64), np.array([r[1] for r in rows], dtype=float))
    return out


def raster_aus_kerzen(K: dict, t0: int, n: int, schritt: int = 900, versatz: int = 900) -> dict:
    """15-min-Schlüsse auf das Raster T[k] = t0 + k · schritt: der Kurs zur Zeit T ist c(T − versatz) (Schluss von [T − 900, T))."""
    P = {}
    for inst, (ts, c) in K.items():
        a = np.full(n, np.nan)
        if len(ts):
            k = (ts + versatz - t0) // schritt
            m = (k >= 0) & (k < n) & ((ts + versatz - t0) % schritt == 0)
            a[k[m]] = c[m]
        P[inst] = a
    return P


def sigma_laden(con, tage: list, insts=None) -> dict:
    """{tag: {(inst, k): v}} aus nb_sigma."""
    out = {}
    for tg in tage:
        d = {}
        for inst, k, v in con.execute("SELECT inst, klasse, v FROM nb_sigma WHERE tag=?", (int(tg),)):
            if v is not None and (insts is None or inst in insts):
                d[(inst, k)] = float(v)
        out[int(tg)] = d
    return out


def sigma_berechnen(con, tag: int, gruppen: dict, min_tage: int | None = None, quelle: str = "kerze15") -> dict:
    """σ des Tages `tag` aus nb_kerze15 (30 Tage davor) und in nb_sigma schreiben. -> {(inst, k): v}"""
    insts = sorted({i for g in gruppen.values() for i in g})
    K = kerzen15_lesen(con, insts, tag - SIGMA_TAGE * TAG - 900, tag)
    s = sigma_aus_kerzen(K, tag, SIGMA_TAGE, min_tage, gruppen)
    with schreiben(con):
        con.execute("DELETE FROM nb_sigma WHERE tag=?", (int(tag),))
        con.executemany("INSERT INTO nb_sigma VALUES (?,?,?,?,?,?)",
                        [(int(tag), i, k, v, int(n), quelle) for (i, k), (v, n) in s.items()])
    return {k: v for k, (v, _n) in s.items() if v is not None}


def lam_reihe(con_main, T: np.ndarray, seite: str = "A") -> np.ndarray:
    """Λ für jedes T (Minutenraster; Summe der Liquidationen mit Zeit in (T − 900, T], auf ganze Minuten gerundet) mit der Referenz des
    jeweiligen Tages (nicht überlappende 15-min-Summen der 30 Tage davor, je Zeitklasse). Die Liquidationen werden einmal gelesen."""
    if not len(T):
        return np.array([])
    tg0 = (int(T[0]) // TAG) * TAG - SIGMA_TAGE * TAG
    m = liq_summen(con_main, tg0, int(T[-1]) + 60, 60, seite)
    n = (int(T[-1]) + 60 - tg0) // 60 + 1
    a = np.zeros(n)
    for t, usd in m.items():
        k = (t - tg0) // 60
        if 0 <= k < n:
            a[k] += usd
    c = np.concatenate([[0.0], np.cumsum(a)])                         # c[j] = Summe der Minuten [tg0, tg0 + 60 j)
    hi = (T - tg0) // 60 + 1                                           # Minuten bis einschließlich der Minute von T
    x = c[np.clip(hi, 0, len(c) - 1)] - c[np.clip(hi - 15, 0, len(c) - 1)]
    s15 = {}
    for t, usd in m.items():
        s15[(t // 900) * 900] = s15.get((t // 900) * 900, 0.0) + usd
    out = np.full(len(T), np.nan)
    refs: dict = {}
    for k, t in enumerate(T):
        tg = (int(t) // TAG) * TAG
        if tg not in refs:
            ref = {"S": [], "A": []}
            for u in range(tg - SIGMA_TAGE * TAG, tg, 900):
                ref["S" if in_sitzung(u) else "A"].append(s15.get(u, 0.0))
            refs[tg] = {kk: sorted(v) for kk, v in ref.items()}
        v = lam_wert(float(x[k]), refs[tg]["S" if in_sitzung(int(t)) else "A"])
        out[k] = np.nan if v is None else v
    return out


# --------------------------------------------------------------------------------------------- Dienst
class Dienst:
    """
    Der Takt der Notbremse (systemd hl-notbremse): jede Minute bei Sekunde 5 Mids holen, Maße rechnen, Stufe bestimmen und eine Zeile in
    nb_zustand schreiben -- auch wenn nichts auslöst. Daneben: Korb täglich, σ täglich 00:05, erste Kalibrierung nach der Historie,
    Neukalibrierung am 1. um 00:30, Löschfrist nb_preis, Historie im Hintergrund (eigenes Gewichtsbudget, 429 → Pause).
    """

    def __init__(self, db_main: str, nb: str | None = None, http=None, uhr=None, log=None, termine_datei: str | None = None):
        self.db_main = db_main; self.nb = nb or nb_pfad(db_main)
        self.http_fn = http or self._http_netz
        self.uhr = uhr or time.time
        self.log = log or (lambda s: print(s, flush=True))
        self.termine_datei = termine_datei or termine_pfad()
        self.con = verbinden(self.nb)
        self.maschine = Maschine(meta_lesen(self.con, "maschine"))
        self.spiegel = Maschine(meta_lesen(self.con, "spiegel"), spiegel=True)
        self.korb = meta_lesen(self.con, "korb")
        self.gewicht: list = []                     # (t, gewicht, art) der letzten 60 s
        self.hist_pause_bis = 0.0
        self.hist_naechste = 0.0                    # frühester Zeitpunkt der nächsten Historien-Abfrage (40 Gewicht je Minute im Mittel)
        self.sigma: dict = {}                       # tag -> {(inst, k): v}
        self.lamref: dict = {}                      # (tag, seite) -> {"S": [...], "A": [...]}
        self.zaehler = {"takte": 0, "fehler": 0, "mids_fehlen": 0, "http_fehler": 0, "429": 0}
        self.letzter_fehler = None
        self._termine = ([], None, None)            # (Liste, Fehler, mtime)
        self.ep_id = meta_lesen(self.con, "episode_id")
        self.sp_id = meta_lesen(self.con, "spiegel_id")
        self.kalib_pause_bis = 0

    # ---- HTTP mit Gewicht
    def _http_netz(self, body: dict):
        d, err, status = AK.http(HL_INFO, timeout=12, kopf={"User-Agent": "hl-dashboard/1.0 (notbremse)"}, daten=json.dumps(body).encode())
        return d, err, status

    def _gewicht_jetzt(self, art: str | None = None) -> int:
        t = self.uhr()
        self.gewicht = [g for g in self.gewicht if t - g[0] < 60]
        return sum(g[1] for g in self.gewicht if art is None or g[2] == art)

    def anfrage(self, body: dict, gewicht: int, art: str = "live"):
        d, err, status = self.http_fn(body)
        n = len(d) if (body.get("type") == "candleSnapshot" and isinstance(d, list)) else 0
        self.gewicht.append((self.uhr(), gewicht + (math.ceil(n / 60) if n else 0), art))
        if status == 429:
            self.zaehler["429"] += 1; self.hist_pause_bis = self.uhr() + 120
        if err:
            self.zaehler["http_fehler"] += 1
        return d, err

    # ---- Korb (täglich 00:00 UTC)
    def korb_bestimmen(self, t: int) -> dict:
        tag = (t // TAG) * TAG
        alt = self.korb or {}
        dex = dict(alt.get("dex") or {})
        K = [c for c in EIGENE]; A = []; anzeige = ["PAXG"]; oi = {}; hinweise = []
        d, err = self.anfrage({"type": "metaAndAssetCtxs"}, 20)
        haupt = set()
        if not err and isinstance(d, list) and len(d) >= 2 and isinstance(d[0], dict):
            for a, c in zip(d[0].get("universe") or [], d[1] or []):
                name = str((a or {}).get("name") or "")
                if not name or (a or {}).get("isDelisted"):
                    continue
                haupt.add(name)
                try:
                    oi[name] = float(c.get("openInterest") or 0) * float(c.get("markPx") or 0)
                except (TypeError, ValueError, AttributeError):
                    pass
        else:
            hinweise.append(f"Haupt-Dex: {err or 'unerwartete Antwort'}")
        fehlen = [c for c in EIGENE if haupt and c not in haupt and c not in dex]
        if fehlen:
            dd, err2 = self.anfrage({"type": "perpDexs"}, 20)
            for e in (dd or []) if isinstance(dd, list) else []:
                if not isinstance(e, dict) or not e.get("name") or not fehlen:
                    continue
                m, err3 = self.anfrage({"type": "meta", "dex": e["name"]}, 20)
                for a in (m or {}).get("universe", []) if isinstance(m, dict) else []:
                    kurz = str(a.get("name", "")).split(":")[-1].upper()
                    if kurz in fehlen:
                        dex[kurz] = e["name"]; fehlen.remove(kurz)
        if haupt:
            K = [c for c in EIGENE if c in haupt or c in dex]
            for name, _w in sorted(oi.items(), key=lambda x: -x[1]):
                if len(K) >= K_MAX:
                    break
                if name in K or name == "PAXG" or name.startswith("@") or name in EIGENE:
                    continue
                K.append(name)
        else:
            K = list(alt.get("K") or EIGENE)
        x, err4 = self.anfrage({"type": "metaAndAssetCtxs", "dex": XYZ}, 20)
        try:
            stand = AK.xyz_stand_parse(x, XYZ) if not err4 else {}
        except ValueError:
            stand = {}
        if stand:
            A = [f"{XYZ}:{k}" for k in AKTIEN if k in stand and not stand[k].get("delisted")]
            anzeige += [f"{XYZ}:{k}" for k in ANZEIGE_XYZ if k in stand and not stand[k].get("delisted")]
            anzeige += [f"{XYZ}:{k}" for k in OEL_NAMEN + GOLD_NAMEN if k in stand and not stand[k].get("delisted")][:2]
        else:
            A = list(alt.get("A") or [f"{XYZ}:{k}" for k in AKTIEN])
            anzeige = list(alt.get("anzeige") or anzeige)
            hinweise.append(f"xyz: {err4 or 'leere Antwort'}")
        dex.setdefault("XMR", dex.get("XMR") or "felix")
        self.korb = {"tag": tag, "K": K[:K_MAX], "A": A, "anzeige": anzeige, "dex": dex, "oi": {k: round(v) for k, v in oi.items() if k in K},
                     "hinweise": hinweise, "ts": int(t)}
        with schreiben(self.con):
            meta_setzen(self.con, {"korb": self.korb})
        return self.korb

    def _name_api(self, inst: str) -> tuple:
        """(Name für candleSnapshot, Dex) eines Instruments."""
        if ":" in inst:
            return inst, inst.split(":")[0]
        dx = (self.korb or {}).get("dex", {}).get(inst)
        return (f"{dx}:{inst}", dx) if dx else (inst, "")

    # ---- Mids je Minute
    def mids_holen(self, t: int) -> dict:
        korb = self.korb or {}
        insts = list(dict.fromkeys(list(korb.get("K") or EIGENE) + list(korb.get("A") or []) + list(korb.get("anzeige") or [])))
        nach_dex: dict = {}
        for i in insts:
            api, dx = self._name_api(i)
            nach_dex.setdefault(dx, []).append((i, api))
        out = {}
        for dx, liste in nach_dex.items():
            body = {"type": "allMids"} if not dx else {"type": "allMids", "dex": dx}
            d, err = self.anfrage(body, 2)
            if err or not isinstance(d, dict) or not d:
                d2, err2 = self.anfrage({"type": "metaAndAssetCtxs"} if not dx else {"type": "metaAndAssetCtxs", "dex": dx}, 20)
                d = {}
                try:
                    st = AK.xyz_stand_parse(d2, dx) if not err2 else {}
                    for k, e in st.items():
                        px = e.get("mid") or e.get("mark")
                        if px:
                            d[f"{dx}:{k}" if dx else k] = px
                except ValueError:
                    pass
            for inst, api in liste:
                kurz = api.split(":")[-1]
                v = d.get(api) if isinstance(d, dict) else None
                if v is None and isinstance(d, dict):
                    v = d.get(kurz) if dx else None
                try:
                    px = float(v)
                except (TypeError, ValueError):
                    continue
                if px > 0 and math.isfinite(px):
                    out[inst] = px
        return out

    # ---- Historie (erster Start; KONZEPT 4.2)
    def historie_schritt(self, t: int, frist: float) -> int:
        """Höchstens so viele candleSnapshot-Abfragen, wie das Budget (40 Gewicht je Minute) und die Frist erlauben. -> Zahl der Abfragen"""
        h = meta_lesen(self.con, "historie") or {"15m": [], "1m": [], "bars": False, "fertig": False}
        if h.get("fertig") or not self.korb or self.uhr() < self.hist_pause_bis:
            return 0
        insts = list(dict.fromkeys(list(self.korb.get("K") or []) + list(self.korb.get("A") or []) + list(self.korb.get("anzeige") or [])))
        n = 0
        if not h.get("bars"):                                         # eigene Minutenkerzen der Krypto-Coins (kein Netz)
            self.eigene_bars_uebernehmen(t); h["bars"] = True
        for art, tage, dauer in (("15m", 60, 900), ("1m", 4, 60)):
            for inst in insts:
                if inst in h[art]:
                    continue
                if self.uhr() > frist or self.uhr() < self.hist_naechste or self.uhr() < self.hist_pause_bis:
                    with schreiben(self.con):
                        meta_setzen(self.con, {"historie": h})
                    return n
                api, _dx = self._name_api(inst)
                d, err = self.anfrage({"type": "candleSnapshot", "req": {"coin": api, "interval": art, "startTime": (t - tage * TAG) * 1000,
                                                                          "endTime": t * 1000}}, 20, "hist")
                n += 1
                w_ = 20 + math.ceil(len(d) / 60) if isinstance(d, list) else 20
                self.hist_naechste = self.uhr() + w_ * 60.0 / GEWICHT_HISTORIE_MIN
                if err and self.uhr() < self.hist_pause_bis:
                    continue                                          # 429: später noch einmal
                try:
                    k = AK.xyz_kerzen_parse(d, int(self.uhr() * 1000)) if not err else []
                except ValueError:
                    k = []
                with schreiben(self.con):
                    if art == "15m":
                        self.con.executemany("INSERT OR REPLACE INTO nb_kerze15 VALUES (?,?,?)", [(inst, int(x[0]), float(x[4])) for x in k])
                    else:
                        self.con.executemany("INSERT OR IGNORE INTO nb_preis VALUES (?,?,?)", [(inst, int(x[0]) + 60, float(x[4])) for x in k])
                    h[art].append(inst)
                    h.setdefault("n", {})[f"{art}:{inst}"] = len(k)
                    meta_setzen(self.con, {"historie": h})
        h["fertig"] = True; h["fertig_ts"] = int(self.uhr())
        tag = (t // TAG) * TAG
        with schreiben(self.con):
            meta_setzen(self.con, {"historie": h})
            self.con.execute("DELETE FROM nb_sigma WHERE tag=?", (tag,))      # σ des Tages mit der vollen Historie neu rechnen
        self.sigma.pop(tag, None)
        self.log("Notbremse: Historie vollständig (15-min-Schlüsse und 1-min-Kurse)")
        return n

    def eigene_bars_uebernehmen(self, t: int) -> int:
        """15-min-Schlüsse der eigenen Coins aus den Minutenkerzen des Recorders (seit Mitte September), wo candleSnapshot fehlt."""
        try:
            cm = sqlite3.connect(f"file:{self.db_main}?mode=ro", uri=True, timeout=30)
        except sqlite3.Error:
            return 0
        n = 0
        try:
            for coin in EIGENE:
                rows = cm.execute("SELECT (ts / 900) * 900, close FROM bars WHERE coin=? AND ts % 900 = 840 AND close > 0 ORDER BY ts",
                                  (coin,)).fetchall()
                with schreiben(self.con):
                    self.con.executemany("INSERT OR IGNORE INTO nb_kerze15 VALUES (?,?,?)", [(coin, int(a), float(c)) for a, c in rows])
                n += len(rows)
        except sqlite3.Error as e:
            self.log(f"Notbremse: eigene Minutenkerzen: {e}")
        finally:
            cm.close()
        return n

    def kerze15_nachfuehren(self, t: int) -> None:
        """Abgeschlossene 15-min-Intervalle aus nb_preis: c(ts) = Mid zur Minute ts + 900 (oder bis 120 s davor)."""
        bis = (t // 900) * 900 - 900                                   # letztes vollständiges Intervall beginnt hier
        von = int(meta_lesen(self.con, "k15_bis", bis - 900) or (bis - 900))
        if bis <= von:
            return
        zeilen = []
        insts = [r[0] for r in self.con.execute("SELECT DISTINCT inst FROM nb_kerze15")] if not self.korb else \
            list(dict.fromkeys(list(self.korb.get("K") or []) + list(self.korb.get("A") or []) + list(self.korb.get("anzeige") or [])))
        for ts in range(max(von + 900, bis - 96 * 900), bis + 1, 900):     # je Instrument über den Schlüssel (inst, ts), höchstens ein Tag nach
            for inst in insts:
                r = self.con.execute("SELECT mid FROM nb_preis WHERE inst = ? AND ts <= ? AND ts >= ? ORDER BY ts DESC LIMIT 1",
                                     (inst, ts + 900, ts + 900 - PREIS_MAX_ALTER)).fetchone()
                if r:
                    zeilen.append((inst, ts, r[0]))
        with schreiben(self.con):
            self.con.executemany("INSERT OR IGNORE INTO nb_kerze15 VALUES (?,?,?)", zeilen)
            meta_setzen(self.con, {"k15_bis": bis})

    # ---- σ, Λ, Schwellen
    def sigma_fuer(self, tag: int) -> dict:
        if tag in self.sigma:
            return self.sigma[tag]
        d = sigma_laden(self.con, [tag]).get(tag) or {}
        if d:
            self.sigma[tag] = d
        return d

    def gruppen(self) -> dict:
        k = self.korb or {}
        return {"K": list(k.get("K") or EIGENE), "A": list(k.get("A") or [])}

    def schwellen(self, t: int) -> dict:
        r = self.con.execute("SELECT gueltig_ab, theta1, theta2x, theta2y, info_json FROM nb_schwellen WHERE gueltig_ab <= ? "
                             "ORDER BY gueltig_ab DESC LIMIT 1", (int(t),)).fetchone()
        if not r:
            return dict(START, quelle="Startwerte", gueltig_ab=None)
        return {"theta1": r[1], "theta2x": r[2], "theta2y": r[3], "gueltig_ab": r[0], "quelle": (json.loads(r[4] or "{}").get("quelle") or "")}

    def lamref_fuer(self, tag: int, seite: str = "A") -> dict:
        key = (tag, seite)
        if key not in self.lamref:
            try:
                cm = sqlite3.connect(f"file:{self.db_main}?mode=ro", uri=True, timeout=30)
                try:
                    self.lamref[key] = lam_referenz(cm, tag, seite)
                finally:
                    cm.close()
            except sqlite3.Error:
                self.lamref[key] = {"S": [], "A": []}
            for k in [k for k in self.lamref if k[0] < tag - TAG]:
                self.lamref.pop(k, None)
        return self.lamref[key]

    # ---- Maße jetzt
    def masse_jetzt(self, t: int) -> dict:
        g = self.gruppen()
        insts = list(dict.fromkeys(g["K"] + g["A"]))
        w_max = max(W_X)
        t0 = t - w_max * 60 - PREIS_MAX_ALTER                          # zwei Minuten Vorlauf: auch P(t − 240 min) darf 120 s alt sein
        n = (t - t0) // 60 + 1
        P = {i: np.full(n, np.nan) for i in insts}
        for inst, ts, mid in self.con.execute(f"SELECT inst, ts, mid FROM nb_preis WHERE ts >= ? AND ts <= ? AND inst IN ({','.join('?' * len(insts))})",
                                              (t0, t, *insts)):
            k = (int(ts) - t0) // 60
            if (int(ts) - t0) % 60 == 0 and 0 <= k < n:
                P[inst][k] = mid
        for i in insts:                                                # ein Mid gilt höchstens 120 s
            P[i] = _ffill(P[i], PREIS_MAX_ALTER // 60)
        tage = sorted({(t0 // TAG) * TAG, (t // TAG) * TAG})
        V = {}
        for tg in tage:
            v = self.sigma_fuer(tg)
            if not v and tg == (t // TAG) * TAG:                     # 00:00–00:05: die σ des Vortags gelten noch
                v = self.sigma_fuer(tg - TAG)
            V[tg] = v
        R = reihe_masse(t0, 60, P, g, V, FENSTER_LIVE, nur_ab=t)
        k = n - 1
        gk = {str(w): (None if not np.isfinite(R["G"][("K", w)][k]) else round(float(R["G"][("K", w)][k]), 3)) for w in FENSTER_LIVE["K"]}
        ga = {str(w): (None if not np.isfinite(R["G"][("A", w)][k]) else round(float(R["G"][("A", w)][k]), 3)) for w in FENSTER_LIVE["A"]}
        nk = {str(w): int(R["N"][("K", w)][k]) for w in FENSTER_LIVE["K"]}
        na = {str(w): int(R["N"][("A", w)][k]) for w in FENSTER_LIVE["A"]}
        X = float(R["X"][k]) if np.isfinite(R["X"][k]) else None
        Y = float(R["Y"][k]) if np.isfinite(R["Y"][k]) else None
        gk60 = gk.get("60")
        hinweise = []
        jetzt_a = sum(1 for i in g["A"] if np.isfinite(P[i][k]))
        jetzt_k = sum(1 for i in g["K"] if np.isfinite(P[i][k]))
        if g["A"] and jetzt_a < A_MIN:
            hinweise.append("Aktien: keine aktuellen Daten")
        if jetzt_k < K_MIN:
            hinweise.append("Krypto: keine aktuellen Daten")
        if not any(V.values()):
            hinweise.append("Kalibrierung läuft (noch keine σ)")
        tg = (t // TAG) * TAG; lam = lam_s = None
        try:
            cm = sqlite3.connect(f"file:{self.db_main}?mode=ro", uri=True, timeout=30)
            try:
                kl = "S" if in_sitzung(t) else "A"
                lam = lam_wert(liq_fenster(cm, t, "A"), self.lamref_fuer(tg, "A")[kl])
                lam_s = lam_wert(liq_fenster(cm, t, "B"), self.lamref_fuer(tg, "B")[kl])
            finally:
                cm.close()
        except sqlite3.Error:
            hinweise.append("Liquidationen: nicht lesbar")
        if lam is None:
            hinweise.append("Liquidationen: keine Referenz (Λ aus)")
        # Spiegel: X' = −max_w min(G_K, G_A), Y' = −max_w G_K, Λ der Short-Liquidationen
        xs = [min(gk[str(w)], ga[str(w)]) for w in W_X if gk.get(str(w)) is not None and ga.get(str(w)) is not None]
        ys = [gk[str(w)] for w in W_Y if gk.get(str(w)) is not None]
        spiegel = {"X": (-max(xs)) if xs else None, "Y": (-max(ys)) if ys else None, "lam": lam_s, "GK60": (-gk60) if gk60 is not None else None}
        anz = {}
        for inst in (self.korb or {}).get("anzeige") or []:
            r = self.con.execute("SELECT mid FROM nb_preis WHERE inst=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1", (inst, t, t - PREIS_MAX_ALTER)).fetchone()
            if not r:
                continue
            e = {"px": r[0]}
            for w in W_X:
                r2 = self.con.execute("SELECT mid FROM nb_preis WHERE inst=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1",
                                      (inst, t - w * 60, t - w * 60 - PREIS_MAX_ALTER)).fetchone()
                e[str(w)] = round((r[0] / r2[0] - 1) * 100, 3) if r2 and r2[0] else None
            anz[inst] = e
        return {"X": X, "Y": Y, "lam": lam, "GK60": gk60, "gk": {"G": gk, "N": nk}, "ga": {"G": ga, "N": na}, "hinweise": hinweise,
                "spiegel": spiegel, "anzeige": anz}

    # ---- ein Takt
    def termine(self) -> tuple:
        try:
            mt = os.path.getmtime(self.termine_datei)
        except OSError:
            mt = None
        if mt != self._termine[2]:
            liste, fehler = termine_lesen(self.termine_datei)
            self._termine = (liste, fehler, mt)
        return self._termine[0], self._termine[1]

    def takt(self, t: int, mids: dict | None = None) -> dict:
        """Ein Minutenschritt für die Minute t (Vielfaches von 60). mids: für Proben statt des Netzabrufs."""
        t = (int(t) // 60) * 60
        tag = (t // TAG) * TAG
        if not self.korb or int(self.korb.get("tag") or 0) < tag:
            try:
                self.korb_bestimmen(t)
            except Exception as e:                                     # Korb bleibt der alte
                self.log(f"Notbremse: Korb: {type(e).__name__}: {e}")
                if not self.korb:
                    self.korb = {"tag": tag, "K": list(EIGENE), "A": [f"{XYZ}:{k}" for k in AKTIEN], "anzeige": [], "dex": {"XMR": "felix"}}
        if mids is None:
            mids = self.mids_holen(t)
        if not mids:
            self.zaehler["mids_fehlen"] += 1
        with schreiben(self.con):
            self.con.executemany("INSERT OR REPLACE INTO nb_preis VALUES (?,?,?)", [(i, t, float(p)) for i, p in mids.items()])
        if t % TAG >= 300 and tag not in self.sigma and not sigma_laden(self.con, [tag]).get(tag):
            try:
                self.sigma[tag] = sigma_berechnen(self.con, tag, self.gruppen())
            except Exception as e:
                self.log(f"Notbremse: σ: {type(e).__name__}: {e}")
        if t >= int(self.kalib_pause_bis):
            try:
                self.kalibrierung_pruefen(t)
            except Exception as e:                                     # ein Fehler der Kalibrierung hält den Takt nicht an (eine Stunde Pause)
                self.kalib_pause_bis = t + 3600; self.letzter_fehler = f"{_uhr(t)} Kalibrierung: {type(e).__name__}: {e}"
                self.log(f"Notbremse: {self.letzter_fehler}")
        m = self.masse_jetzt(t)
        th = self.schwellen(t)
        for a in self.con.execute("SELECT id, ts, aktion, dauer_s, grund FROM nb_manuell WHERE id > ? AND ts <= ? ORDER BY id",
                                  (int(self.maschine.st.get("aktionen_bis") or 0), t)).fetchall():
            self.maschine.aktion({"id": a[0], "ts": a[1], "aktion": a[2], "dauer_s": a[3], "grund": a[4]})
        termine, t_fehler = self.termine()
        if t_fehler:
            m["hinweise"].append(f"Termine: {t_fehler}")
        z = self.maschine.schritt(t, m, th, termin_aktiv(termine, t))
        zs = self.spiegel.schritt(t, m["spiegel"], th)
        hinweis = "; ".join(m["hinweise"])
        with schreiben(self.con):
            self.con.execute("INSERT INTO nb_zustand (ts, stufe, quelle, grund, x, y, lam, wache, gk_json, ga_json, seit, frei_ab, hinweis, spiegel) "
                             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (t, z["stufe"], z["quelle"], z["grund"], m["X"], m["Y"], m["lam"], 0, json.dumps(m["gk"]), json.dumps(m["ga"]),
                              z["seit"], z["frei_ab"], hinweis, zs["stufe"]))
            self._episode(t, z, m, 0)
            self._episode(t, zs, m["spiegel"], 1)
            meta_setzen(self.con, {"maschine": self.maschine.st, "spiegel": self.spiegel.st, "episode_id": self.ep_id, "spiegel_id": self.sp_id,
                                   "takt": {"ts": t, "zaehler": self.zaehler, "gewicht_60s": self._gewicht_jetzt(), "anzeige": m["anzeige"],
                                            "schwellen": th, "fehler": self.letzter_fehler}})
        self.zaehler["takte"] += 1
        if t % 900 == 60:
            try:
                self.kerze15_nachfuehren(t)
            except sqlite3.Error as e:
                self.log(f"Notbremse: 15-min-Schlüsse: {e}")
        if t % TAG == 600:
            with schreiben(self.con):
                self.con.execute("DELETE FROM nb_preis WHERE ts < ?", (t - PREIS_TAGE * TAG,))
        return dict(z, X=m["X"], Y=m["Y"], lam=m["lam"], hinweis=hinweis)

    def _episode(self, t: int, z: dict, m: dict, spiegel: int) -> None:
        attr = "sp_id" if spiegel else "ep_id"
        eid = getattr(self, attr)
        if z["neu"]:
            werte = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in m.items() if k in ("X", "Y", "lam", "GK60")}
            cur = self.con.execute("INSERT INTO nb_episode (start, ende, stufe_max, ausloeser, werte_json, gesperrt_n, storniert_n, spiegel) "
                                   "VALUES (?,?,?,?,?,0,0,?)", (t, None, z["stufe"], z["quelle"], json.dumps(werte), spiegel))
            setattr(self, attr, cur.lastrowid)
        elif eid is not None and z["stufe"] >= 1:
            self.con.execute("UPDATE nb_episode SET stufe_max = MAX(stufe_max, ?) WHERE id=?", (z["stufe"], eid))
        elif eid is not None and z["ende"]:
            r = self.con.execute("SELECT start FROM nb_episode WHERE id=?", (eid,)).fetchone()
            if r:
                g, s = self.con.execute("SELECT SUM(art<>'storno'), SUM(art='storno') FROM nb_blockiert WHERE ts>=? AND ts<=?", (r[0], t)).fetchone()
                self.con.execute("UPDATE nb_episode SET ende=?, gesperrt_n=?, storniert_n=? WHERE id=?", (t, int(g or 0), int(s or 0), eid))
            setattr(self, attr, None)

    # ---- Kalibrierung (erste nach der Historie, dann monatlich)
    def kalibrierung_pruefen(self, t: int) -> None:
        h = meta_lesen(self.con, "historie") or {}
        hat = self.con.execute("SELECT COUNT(*) FROM nb_schwellen").fetchone()[0]
        if not hat:
            if not h.get("fertig"):
                return
            bis = min(ERSTE_KALIB_BIS, t)
            self.kalibrierung_rechnen(t, bis, erste=True)
            return
        d = datetime.fromtimestamp(t, UTC)
        if d.day == 1 and d.hour == 0 and d.minute >= 30:
            schon = self.con.execute("SELECT 1 FROM nb_schwellen WHERE gueltig_ab >= ?", ((t // TAG) * TAG,)).fetchone()
            if not schon:
                self.kalibrierung_rechnen(t, (t // TAG) * TAG - 1, erste=False)

    def kalibrierung_rechnen(self, t: int, bis: int, erste: bool) -> dict:
        t_start = time.time()
        g = self.gruppen()
        try:
            cm = sqlite3.connect(f"file:{self.db_main}?mode=ro", uri=True, timeout=60)
        except sqlite3.Error as e:
            self.log(f"Notbremse: Kalibrierung: {e}")
            return {}
        try:
            erg = kalibrierung_aus_daten(self.con, cm, g, bis, erste=erste, nb_preis=not erste)
        finally:
            cm.close()
        k = erg["kal"]
        info = dict(k.get("info") or {}, quelle=k["quelle"], erste=erste, dauer_s=round(time.time() - t_start, 1), eigene_coins=erg.get("eigene"),
                    roh=k.get("roh"), zeitraum_x=erg.get("zeitraum_x"), zeitraum_y=erg.get("zeitraum_y"))
        with schreiben(self.con):
            self.con.execute("INSERT OR REPLACE INTO nb_schwellen VALUES (?,?,?,?,?,?,?,?)",
                             (int(t), k["theta1"], k["theta2x"], k["theta2y"], json.dumps(BUDGET), erg.get("zeitraum") or "", json.dumps(k["klammer"]),
                              json.dumps(info, default=float)))
        self.log(f"Notbremse: Kalibrierung ({'erste' if erste else 'monatlich'}, {k['quelle']}): θ1 {k['theta1']:+.2f}, θ2X {k['theta2x']:+.2f}, "
                 f"θ2Y {k['theta2y']:+.2f}" + (f", an der Klammer: {', '.join(k['klammer'])}" if k["klammer"] else ""))
        return k

    def lauf(self) -> None:
        self.log(f"Notbremse ({FASSUNG}): {self.nb}, Hauptdatenbank {self.db_main}")
        while True:
            jetzt = self.uhr()
            naechste = (int(jetzt) // 60 + 1) * 60 + 5
            time.sleep(max(0.5, naechste - jetzt))
            t = int(self.uhr()) // 60 * 60
            try:
                self.takt(t)
                self.letzter_fehler = None
            except Exception as e:
                self.zaehler["fehler"] += 1; self.letzter_fehler = f"{_uhr(t)} {type(e).__name__}: {e}"
                self.log(f"Notbremse-Takt: {self.letzter_fehler}")
            try:
                self.historie_schritt(t, t + 45)
            except Exception as e:
                self.log(f"Notbremse-Historie: {type(e).__name__}: {e}")


def kalibrierung_aus_daten(con_nb, con_main, gruppen: dict, bis: int, erste: bool, nb_preis: bool = False, budget: dict | None = None,
                           tage_max: int = NEUKALIB_TAGE) -> dict:
    """
    X auf dem 15-min-Raster aus nb_kerze15 (σ je Tag aus den Tagen davor; erste Kalibrierung: σ ab 10 Tagen), Y auf dem 1-min-Raster der
    eigenen Coins (Minutenkerzen des Recorders; monatlich zusätzlich nb_preis) mit Λ. Zeitraum: höchstens `tage_max` Tage bis `bis`
    (die erste: alle Daten bis 20.10. 23:59 UTC). -> {kal, zeitraum, eigene, zeitraum_x, zeitraum_y}
    """
    r = con_nb.execute("SELECT MIN(ts) FROM nb_kerze15").fetchone()
    erste_ts = int(r[0]) if r and r[0] is not None else None
    if erste_ts is None:
        return {"kal": kalibrieren(None, None, budget), "zeitraum": "keine Daten"}
    ende_tag = ((bis + 1) // TAG) * TAG                                    # Tage vor diesem 00:00
    min_tage = ERSTE_KALIB_SIGMA_MIN_TAGE if erste else SIGMA_TAGE
    start_tag = ((erste_ts // TAG) + 1) * TAG + min_tage * TAG             # erster Tag mit genug σ-Vorlauf
    if not erste:
        start_tag = max(start_tag, ende_tag - tage_max * TAG)
    if start_tag >= ende_tag:
        return {"kal": kalibrieren(None, None, budget), "zeitraum": "zu wenige Tage für σ"}
    R = reihen_aus_daten(con_nb, con_main, gruppen, start_tag, ende_tag, min_tage if erste else None, nb_preis=nb_preis)
    X_reihe, Y_reihe = R["X_reihe"], R["Y_reihe"]
    kal = kalibrieren(X_reihe, Y_reihe, budget)
    zr = f"{datetime.fromtimestamp(start_tag, UTC):%d.%m.%Y}–{datetime.fromtimestamp(ende_tag - 1, UTC):%d.%m.%Y}"
    return {"kal": kal, "zeitraum": zr, "eigene": R["eigene"], "zeitraum_x": round(X_reihe["tage"], 1),
            "zeitraum_y": round(Y_reihe["tage"], 1) if Y_reihe else 0.0, "X_reihe": X_reihe, "Y_reihe": Y_reihe}


def reihen_aus_daten(con_nb, con_main, gruppen: dict, start_tag: int, ende_tag: int, sigma_min_tage: int | None, nb_preis: bool = False) -> dict:
    """
    Die Reihen der Kalibrierung und des Rückblicks (check_notbremse.py) für [start_tag, ende_tag): X und G(K, 60) auf dem 15-min-Raster aus
    nb_kerze15 (σ je Tag aus den 30 Tagen davor; sigma_min_tage: weniger Tage erlaubt, wie bei der ersten Kalibrierung), Y und Λ auf dem
    1-min-Raster der eigenen Coins (Minutenkerzen des Recorders; nb_preis=True: dazu nb_preis). Der Wert zur Zeit T ist zur Zeit T bekannt
    (15-min-Raster: Schluss von [T − 15 min, T); 1-min-Raster: Schluss der Minute T − 60).
    -> {X_reihe {T, X, GK60, schritt, tage}, Y_reihe {T, Y, lam, schritt, tage} oder None, eigene, V}
    """
    insts = sorted({i for gg in gruppen.values() for i in gg})
    t_k0 = start_tag - SIGMA_TAGE * TAG - 900
    K = kerzen15_lesen(con_nb, insts, t_k0, ende_tag)
    nk = (ende_tag - t_k0) // 900
    P15 = raster_aus_kerzen(K, t_k0, nk, versatz=0)                       # c(ts) auf ts = t_k0 + 900 k
    V = sigma_reihe(t_k0, P15, list(range(start_tag, ende_tag, TAG)), SIGMA_TAGE, sigma_min_tage, gruppen)
    n15 = (ende_tag - start_tag) // 900
    P = raster_aus_kerzen(K, start_tag, n15)
    RX = reihe_masse(start_tag, 900, P, gruppen, V, FENSTER_X15)
    tage_x = float(np.sum(np.isfinite(RX["X"]))) * 900 / TAG
    X_reihe = {"T": RX["T"], "X": RX["X"], "GK60": RX["GK60"], "schritt": 900, "tage": tage_x}
    # Y: eigene Coins auf dem 1-min-Raster
    eigene = [c for c in gruppen.get("K", []) if c in EIGENE]
    n1 = (ende_tag - start_tag) // 60
    P1 = {c: np.full(n1, np.nan) for c in eigene}
    for c in eigene:
        for ts, cl in con_main.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<? AND close > 0", (c, start_tag - 60, ende_tag - 60)):
            k = (int(ts) + 60 - start_tag) // 60                            # Schluss der Minute ts = Kurs zur Zeit ts + 60
            if 0 <= k < n1:
                P1[c][k] = cl
        if nb_preis:
            for ts, mid in con_nb.execute("SELECT ts, mid FROM nb_preis WHERE inst=? AND ts>=? AND ts<?", (c, start_tag, ende_tag)):
                k = (int(ts) - start_tag) // 60
                if 0 <= k < n1:
                    P1[c][k] = mid
        P1[c] = _ffill(P1[c], PREIS_MAX_ALTER // 60)
    Y_reihe = None
    if len(eigene) >= K_MIN:
        RY = reihe_masse(start_tag, 60, P1, {"K": eigene}, V, FENSTER_Y1)
        lam = lam_reihe(con_main, RY["T"], "A")
        tage_y = float(np.sum(np.isfinite(RY["Y"]))) * 60 / TAG
        Y_reihe = {"T": RY["T"], "Y": RY["Y"], "lam": lam, "schritt": 60, "tage": tage_y}
    return {"X_reihe": X_reihe, "Y_reihe": Y_reihe, "eigene": len(eigene), "V": V}


# --------------------------------------------------------------------------------------------- Welt A (KONZEPT 8)
LABOR_TABELLEN = ("labor_strategie", "labor_position", "labor_order", "labor_ereignis", "labor_zustand", "labor_grid_tag", "labor_akku_kauf",
                  "labor_akku_tag", "labor_akku_faktor")


def welt_a_start(store_a: str) -> int | None:
    if not os.path.exists(store_a):
        return None
    try:
        con = sqlite3.connect(f"file:{store_a}?mode=ro", uri=True, timeout=10)
        try:
            r = con.execute("SELECT v FROM labor_zustand WHERE k='welt_a_start'").fetchone()
        finally:
            con.close()
        return int(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError):
        return None


def welt_a_anlegen(store_b: str, store_a: str, now: int, netto_start: dict | None = None) -> tuple:
    """
    Welt A als exakte Kopie der Welt B (alle labor_*-Tabellen: offene Positionen, Orders, Zustände, Historie) -- einmal; danach führt
    sie ihren eigenen Speicher. Gerufen im Takt des Labors zwischen zwei Takten der Welt B (B schreibt dann nicht). -> (Start, neu angelegt)
    """
    import hl_labor
    alt = welt_a_start(store_a)
    if alt:
        return alt, False
    con = sqlite3.connect(store_a, timeout=60)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        hl_labor.schema(con)
        con.commit()
        con.execute("ATTACH DATABASE ? AS b", (store_b,))
        con.execute("BEGIN IMMEDIATE")
        for tab in LABOR_TABELLEN:
            if not con.execute("SELECT 1 FROM b.sqlite_master WHERE type='table' AND name=?", (tab,)).fetchone():
                continue
            sp = [r[1] for r in con.execute(f'PRAGMA b.table_info("{tab}")')]
            ziel = {r[1] for r in con.execute(f'PRAGMA main.table_info("{tab}")')}
            sp = [s for s in sp if s in ziel]
            liste = ", ".join(f'"{s}"' for s in sp)
            con.execute(f'DELETE FROM main."{tab}"')
            con.execute(f'INSERT INTO main."{tab}" ({liste}) SELECT {liste} FROM b."{tab}"')
        con.execute("INSERT OR REPLACE INTO main.labor_zustand VALUES ('welt_a_start', ?)", (str(int(now)),))
        con.execute("INSERT OR REPLACE INTO main.labor_zustand VALUES ('welt_a_start_netto', ?)", (json.dumps(netto_start or {}),))
        con.commit()
        con.execute("DETACH DATABASE b")
    finally:
        con.close()
    return int(now), True


def summe_welt(store: str, preise: dict) -> dict:
    """Ergebnis einer Welt jetzt: realisiert (geschlossene Positionen) + Bestand (offene Positionen zur Mitte, nach Ausstiegsgebühr und
    Funding) + Akkumulation (Wert − eingesetzt) -- gesamt und je Strategie. preise = {coin: mid}."""
    import hl_labor
    out = {"gesamt": 0.0, "realisiert": 0.0, "bestand": 0.0, "akku": 0.0, "je_sid": {}, "ohne_kurs": []}
    if not os.path.exists(store):
        return out
    st = sqlite3.connect(f"file:{store}?mode=ro", uri=True, timeout=30)
    try:
        js = out["je_sid"]
        for sid, s in st.execute("SELECT sid, SUM(netto_usd) FROM labor_position WHERE status='geschlossen' GROUP BY sid"):
            js[sid] = js.get(sid, 0.0) + float(s or 0.0); out["realisiert"] += float(s or 0.0)
        for sid, coin, seite, p_in, menge, geb_ein, fund in st.execute(
                "SELECT sid, coin, seite, preis_ein, menge, gebuehr_ein, funding FROM labor_position WHERE status='offen'"):
            mid = preise.get(coin)
            if not mid:
                out["ohne_kurs"].append(coin); continue
            u = (mid - p_in) * menge * (1 if seite == "long" else -1) - (geb_ein or 0.0) - menge * mid * hl_labor.gebuehr(coin, hl_labor.GEB_TAKER) - (fund or 0.0)
            js[sid] = js.get(sid, 0.0) + u; out["bestand"] += u
        try:
            for sid, coin, usd, menge in st.execute("SELECT sid, coin, SUM(usd), SUM(menge) FROM labor_akku_kauf GROUP BY sid, coin"):
                mid = preise.get(coin)
                if not mid:
                    out["ohne_kurs"].append(coin); continue
                g = float(menge or 0.0) * mid - float(usd or 0.0)
                js[sid] = js.get(sid, 0.0) + g; out["akku"] += g
        except sqlite3.Error:
            pass
    finally:
        st.close()
    out["gesamt"] = out["realisiert"] + out["bestand"] + out["akku"]
    out["ohne_kurs"] = sorted(set(out["ohne_kurs"]))
    return out


def welten_vergleich(store_b: str, store_a: str, preise: dict) -> dict | None:
    """„mit Notbremse X USD · ohne Y USD · Unterschied Z USD (seit TT.MM.)“ und je Strategie der Unterschied A − B (KONZEPT 8)."""
    start = welt_a_start(store_a)
    if not start:
        return None
    A = summe_welt(store_a, preise); B = summe_welt(store_b, preise)
    s0 = None
    try:
        con = sqlite3.connect(f"file:{store_a}?mode=ro", uri=True, timeout=10)
        try:
            r = con.execute("SELECT v FROM labor_zustand WHERE k='welt_a_start_netto'").fetchone()
        finally:
            con.close()
        s0 = (json.loads(r[0]) if r and r[0] else {}).get("gesamt")
    except (sqlite3.Error, ValueError):
        s0 = None
    je = {sid: round(A["je_sid"].get(sid, 0.0) - B["je_sid"].get(sid, 0.0), 2) for sid in set(A["je_sid"]) | set(B["je_sid"])}
    return {"start": start, "mit": round(A["gesamt"] - s0, 2) if s0 is not None else None, "ohne": round(B["gesamt"] - s0, 2) if s0 is not None else None,
            "unterschied": round(A["gesamt"] - B["gesamt"], 2), "a": round(A["gesamt"], 2), "b": round(B["gesamt"], 2),
            "je_sid": {k: v for k, v in je.items() if abs(v) >= 0.005}, "ohne_kurs": sorted(set(A["ohne_kurs"]) | set(B["ohne_kurs"]))}


def tagesstand_schreiben(nb: str, store_b: str, store_a: str, preise: dict, now: int) -> bool:
    """Je UTC-Tag der Stand beider Welten am Tagesende (der letzte Takt des Tages gewinnt) -- daraus D = ΔA − ΔB je Tag (KONZEPT 11.1)."""
    v = welten_vergleich(store_b, store_a, preise)
    if not v:
        return False
    tag = (int(now) // TAG) * TAG
    con = verbinden(nb)
    try:
        with schreiben(con):
            vor = con.execute("SELECT netto_a, netto_b FROM nb_tag WHERE tag < ? ORDER BY tag DESC LIMIT 1", (tag,)).fetchone()
            d = None
            if vor and vor[0] is not None and vor[1] is not None:
                d = (v["a"] - vor[0]) - (v["b"] - vor[1])
            elif int(v["start"]) >= tag:
                d = v["unterschied"]
            con.execute("INSERT OR REPLACE INTO nb_tag VALUES (?,?,?,?,?)", (tag, v["a"], v["b"], d, int(now)))
    finally:
        con.close()
    return True


# --------------------------------------------------------------------------------------------- Auswertung je Episode (KONZEPT 7.2, 11.1)
def _kurs_zu(con_main, coin: str, t: int):
    """Schluss der letzten Minute vor t (Kurs zur Zeit t)."""
    try:
        r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<? AND ts>=? ORDER BY ts DESC LIMIT 1", (coin, int(t), int(t) - 3600)).fetchone()
        return float(r[0]) if r and r[0] else None
    except sqlite3.Error:
        return None


def summe_zu(store: str, con_main, t: int) -> float | None:
    """Ergebnis einer Welt zur Zeit t (Näherung): realisiert bis t + Bestand der zu t offenen Positionen zum Kurs der Minutenkerze (nach
    Ausstiegsgebühr; Funding der offenen anteilig) + Akkumulation bis t zum Kurs von t."""
    import hl_labor
    if not os.path.exists(store):
        return None
    st = sqlite3.connect(f"file:{store}?mode=ro", uri=True, timeout=30)
    try:
        s = float(st.execute("SELECT COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE status='geschlossen' AND geschlossen<=?", (int(t),)).fetchone()[0])
        kurse: dict = {}
        for coin, seite, p_in, menge, geb_ein, fund, ein, zu in st.execute(
                "SELECT coin, seite, preis_ein, menge, gebuehr_ein, funding, eroeffnet, geschlossen FROM labor_position "
                "WHERE eroeffnet<=? AND (geschlossen IS NULL OR geschlossen>?)", (int(t), int(t))):
            if coin not in kurse:
                kurse[coin] = _kurs_zu(con_main, coin, t)
            mid = kurse[coin]
            if not mid:
                continue
            dauer = max(int(zu or time.time()) - int(ein), 1)
            f_ = (fund or 0.0) * min(1.0, max(0.0, (int(t) - int(ein)) / dauer))
            s += (mid - p_in) * menge * (1 if seite == "long" else -1) - (geb_ein or 0.0) - menge * mid * hl_labor.gebuehr(coin, hl_labor.GEB_TAKER) - f_
        try:
            for coin, usd, menge in st.execute("SELECT coin, SUM(usd), SUM(menge) FROM labor_akku_kauf WHERE ts<=? GROUP BY coin", (int(t),)):
                if coin not in kurse:
                    kurse[coin] = _kurs_zu(con_main, coin, t)
                if kurse[coin]:
                    s += float(menge or 0.0) * kurse[coin] - float(usd or 0.0)
        except sqlite3.Error:
            pass
        return s
    finally:
        st.close()


def _sigma15(con_nb, coin: str, t: int):
    """σ eines 15-min-Fensters bis t aus nb_sigma (Klasse je Minute)."""
    tg = (int(t) // TAG) * TAG
    v = {}
    for k, x in con_nb.execute("SELECT klasse, v FROM nb_sigma WHERE tag=? AND inst=?", (tg, coin)):
        v[k] = x
    n_s = sitzungsminuten(int(t) - 900, int(t))
    return sigma_fenster(v.get("S"), v.get("A"), n_s, 15 - n_s)


def varianten_rechnen(con_nb, store_a: str, con_main, t2: int, bis: int) -> dict:
    """
    Bestandsregel bei Stufe 2 im Schatten (KONZEPT 7.2): alle Long-Positionen der Welt A, die zu t2 offen waren (ohne Akkumulation: sie
    verkauft nie), aus den Minutenkerzen bis `bis` (Episodenende + 24 h). V0 = wie geschehen; V1 alle eine Minute nach t2 zum Marktpreis
    schließen; V2 halbieren; V3 Stop auf max(Stop, L15 · (1 − 0,5 · σ(15 min))), bei Grid-Losen die Notlinie ebenso. Nach Gebühren; Funding
    der offenen anteilig; ohne Folgeeffekte (keine neuen Einstiege). -> {n, V0, V1, V2, V3, d1, d2, d3, je}
    """
    import hl_labor
    st = sqlite3.connect(f"file:{store_a}?mode=ro", uri=True, timeout=30)
    try:
        pos = st.execute("SELECT id, sid, coin, preis_ein, menge, notional, gebuehr_ein, funding, eroeffnet, geschlossen, netto_usd, sl, tp, ablauf "
                         "FROM labor_position WHERE seite='long' AND eroeffnet<=? AND (geschlossen IS NULL OR geschlossen>?)", (int(t2), int(t2))).fetchall()
    finally:
        st.close()
    t1 = (int(t2) // 60 + 1) * 60
    summen = {"V0": 0.0, "V1": 0.0, "V2": 0.0, "V3": 0.0}; je = []
    for pid, sid, coin, p_in, menge, nt, geb_ein, fund, ein, zu, netto, sl, tp, ablauf in pos:
        dauer = max(int(zu or time.time()) - int(ein), 1)
        f_bis = lambda t_: (fund or 0.0) * min(1.0, max(0.0, (int(t_) - int(ein)) / dauer))
        geb_t = hl_labor.gebuehr(coin, hl_labor.GEB_TAKER)
        if zu is not None and int(zu) <= int(bis):
            v0 = float(netto or 0.0)
        else:
            px = _kurs_zu(con_main, coin, bis)
            if not px:
                continue
            v0 = (px - p_in) * menge - (geb_ein or 0.0) - menge * px * geb_t - f_bis(bis)
        b = hl_labor.buch_jetzt(con_main, coin, t1)
        if not b:
            continue
        pr1, _bps = hl_labor.taker_preis(b, False, nt)
        v1 = (pr1 - p_in) * menge - (geb_ein or 0.0) - menge * pr1 * geb_t - f_bis(t1)
        v2 = 0.5 * v1 + 0.5 * v0
        k15 = hl_labor.kerzen(con_main, coin, int(t2) // 60 * 60 - 900, int(t2) // 60 * 60)
        l15 = min((k[3] for k in k15), default=None)
        sg = _sigma15(con_nb, coin, t2)
        v3 = v0
        if l15 and sg:
            neu = l15 * (1 - 0.5 * sg)
            stop = max(float(sl), neu) if sl else neu
            if b["mid"] <= stop:
                v3 = v1
            else:
                ende_px = None; ende_t = None
                for ts, o, hi, lo, c in hl_labor.kerzen(con_main, coin, t1, int(bis) // 60 * 60):
                    if lo <= stop:
                        ende_px = min(o, stop); ende_t = ts + 60; art = "stop"; break
                    if tp and hi > tp:
                        ende_px = float(tp); ende_t = ts + 60; art = "ziel"; break
                    if ablauf and ts + 60 >= int(ablauf):
                        ende_px = c; ende_t = ts + 60; art = "zeit"; break
                if ende_px is not None:
                    geb_aus = menge * ende_px * (hl_labor.gebuehr(coin, hl_labor.GEB_MAKER) if art == "ziel" else geb_t)
                    v3 = (ende_px - p_in) * menge - (geb_ein or 0.0) - geb_aus - f_bis(ende_t)
                else:
                    px = _kurs_zu(con_main, coin, bis)
                    v3 = ((px - p_in) * menge - (geb_ein or 0.0) - menge * px * geb_t - f_bis(bis)) if px else v0
        for k, v in (("V0", v0), ("V1", v1), ("V2", v2), ("V3", v3)):
            summen[k] += v
        je.append({"id": pid, "sid": sid, "coin": coin, "V0": round(v0, 2), "V1": round(v1, 2), "V2": round(v2, 2), "V3": round(v3, 2)})
    return {"t2": int(t2), "bis": int(bis), "n": len(je), **{k: round(v, 2) for k, v in summen.items()},
            "d1": round(summen["V1"] - summen["V0"], 2), "d2": round(summen["V2"] - summen["V0"], 2), "d3": round(summen["V3"] - summen["V0"], 2),
            "je": je[:200]}


def episoden_auswerten(nb: str, store_b: str, store_a: str, db_main: str, now: int) -> int:
    """Für beendete Episoden, deren Ende 24 h zurückliegt: D = ΔA − ΔB über Episode + 24 h (Näherung aus Minutenkerzen) und bei Stufe 2 die
    Varianten V1–V3 gegen V0. -> Zahl der ausgewerteten Episoden."""
    if not os.path.exists(nb) or not welt_a_start(store_a):
        return 0
    con = verbinden(nb)
    n = 0
    try:
        offen = con.execute("SELECT id, start, ende, stufe_max FROM nb_episode WHERE spiegel=0 AND ende IS NOT NULL AND ende<=? AND ausgewertet=0 "
                            "ORDER BY start LIMIT 5", (int(now) - TAG,)).fetchall()
        if not offen:
            return 0
        cm = sqlite3.connect(f"file:{db_main}?mode=ro", uri=True, timeout=30)
        try:
            for eid, s, e, smax in offen:
                bis = int(e) + TAG
                a0, a1 = summe_zu(store_a, cm, int(s)), summe_zu(store_a, cm, bis)
                b0, b1 = summe_zu(store_b, cm, int(s)), summe_zu(store_b, cm, bis)
                d = ((a1 - a0) - (b1 - b0)) if None not in (a0, a1, b0, b1) else None
                var = None
                if int(smax or 0) >= 2:
                    r = con.execute("SELECT MIN(ts) FROM nb_zustand WHERE ts>=? AND ts<=? AND stufe>=2", (int(s), int(e))).fetchone()
                    if r and r[0]:
                        var = varianten_rechnen(con, store_a, cm, int(r[0]), bis)
                with schreiben(con):
                    con.execute("UPDATE nb_episode SET d_usd=?, varianten_json=?, ausgewertet=1 WHERE id=?", (d, json.dumps(var) if var else None, eid))
                n += 1
        finally:
            cm.close()
    finally:
        con.close()
    return n


# --------------------------------------------------------------------------------------------- Anzeige und Bericht (KONZEPT 9)
STUFE_NAME = {0: "frei", 1: "Long-Sperre", 2: "Schock"}
QUELLE_NAME = {"markt_x": "Gleichlauf Krypto und Aktien", "markt_y": "Krypto mit Liquidationswelle", "termin": "Termin", "manuell": "Handbremse",
               "ki": "Ebene B"}


def daten(db_main: str, store_b: str | None = None, store_a: str | None = None, preise: dict | None = None, now: int | None = None) -> dict:
    """Alles für Banner, Abschnitt „Notbremse“ und Bericht (Dashboard /notbremse)."""
    now = int(now or time.time())
    nb = nb_pfad(db_main)
    out = {"ts": now, "fassung": FASSUNG, "pfad": nb, "da": os.path.exists(nb), "zustand": None, "hinweise": [], "budget": BUDGET,
           "start_schwellen": START, "klammern": KLAMMER, "w_x": W_X, "w_y": W_Y}
    termine, t_fehler = termine_lesen()
    out["termine"] = [dict(e, aktiv=e["start"] <= now < e["ende"]) for e in termine if e["ende"] > now - 7 * TAG]
    out["termine_datei"] = termine_pfad(); out["termine_fehler"] = t_fehler
    if not out["da"]:
        out["hinweise"].append("notbremse.db fehlt -- der Dienst hl-notbremse ist noch nicht gelaufen")
        return out
    con = verbinden(nb, nur_lesen=True)
    try:
        z = zustand(con, now)
        out["zustand"] = z
        if z is None or z["alter_s"] > ZUSTAND_MAX_ALTER:
            out["veraltet"] = True
            out["hinweise"].append(("Notbremse ohne aktuelle Daten" + (f" (letzter Zustand vor {z['alter_s'] // 60} min)" if z else "")
                                    + " -- Welt A eröffnet keine Longs; Dienst hl-notbremse prüfen"))
        if z and z["stufe"] >= 1 and z.get("seit") and now - int(z["seit"]) >= TAG:
            out["hinweise"].append("Sperre seit 24 h, bitte prüfen"); out["lang"] = True
        out["verlauf"] = [{"ts": r[0], "stufe": r[1], "x": r[2], "y": r[3], "lam": r[4]} for r in con.execute(
            "SELECT ts, stufe, x, y, lam FROM nb_zustand WHERE ts>=? AND ts<=? ORDER BY ts", (now - 6 * 3600, now))]
        sw = con.execute("SELECT gueltig_ab, theta1, theta2x, theta2y, zeitraum, klammer_json, info_json FROM nb_schwellen ORDER BY gueltig_ab DESC").fetchall()
        out["schwellen"] = [{"gueltig_ab": r[0], "theta1": r[1], "theta2x": r[2], "theta2y": r[3], "zeitraum": r[4], "klammer": json.loads(r[5] or "[]"),
                             "info": json.loads(r[6] or "{}")} for r in sw]
        out["schwellen_jetzt"] = out["schwellen"][0] if out["schwellen"] else dict(START, quelle="Startwerte")
        if not out["schwellen"]:
            out["hinweise"].append("Kalibrierung läuft -- bis dahin die Startwerte")
        out["korb"] = meta_lesen(con, "korb"); out["historie"] = meta_lesen(con, "historie"); out["takt"] = meta_lesen(con, "takt")
        out["episoden"] = [{"id": r[0], "start": r[1], "ende": r[2], "stufe_max": r[3], "ausloeser": r[4], "werte": json.loads(r[5] or "{}"),
                            "gesperrt_n": r[6], "storniert_n": r[7], "d_usd": r[8], "varianten": json.loads(r[9]) if r[9] else None}
                           for r in con.execute("SELECT id, start, ende, stufe_max, ausloeser, werte_json, gesperrt_n, storniert_n, d_usd, varianten_json "
                                                "FROM nb_episode WHERE spiegel=0 ORDER BY start DESC LIMIT 30")]
        for e in out["episoden"]:
            if e["ende"] is None:
                g, s = con.execute("SELECT SUM(art<>'storno'), SUM(art='storno') FROM nb_blockiert WHERE ts>=?", (e["start"],)).fetchone()
                e["gesperrt_n"], e["storniert_n"] = int(g or 0), int(s or 0)
        out["episoden_30t"] = {"s1": con.execute("SELECT COUNT(*) FROM nb_episode WHERE spiegel=0 AND start>=?", (now - 30 * TAG,)).fetchone()[0],
                               "s2": con.execute("SELECT COUNT(*) FROM nb_episode WHERE spiegel=0 AND stufe_max>=2 AND start>=?", (now - 30 * TAG,)).fetchone()[0],
                               "spiegel": con.execute("SELECT COUNT(*) FROM nb_episode WHERE spiegel=1 AND start>=?", (now - 30 * TAG,)).fetchone()[0]}
        out["manuell"] = [{"ts": r[0], "aktion": r[1], "dauer_s": r[2], "grund": r[3]}
                          for r in con.execute("SELECT ts, aktion, dauer_s, grund FROM nb_manuell ORDER BY id DESC LIMIT 10")]
        out["blockiert_24h"] = [{"sid": r[0], "art": r[1], "n": r[2]} for r in con.execute(
            "SELECT sid, art, COUNT(*) FROM nb_blockiert WHERE ts>=? GROUP BY sid, art ORDER BY COUNT(*) DESC LIMIT 12", (now - TAG,))]
        out["tage"] = [{"tag": r[0], "a": r[1], "b": r[2], "d": r[3]} for r in con.execute("SELECT tag, netto_a, netto_b, d FROM nb_tag ORDER BY tag DESC LIMIT 30")]
    finally:
        con.close()
    if store_b and store_a:
        try:
            out["welten"] = welten_vergleich(store_b, store_a, preise or {})
        except sqlite3.Error as e:
            out["welten"] = None; out["hinweise"].append(f"Welt A: {e}")
    return out


def banner_text(d: dict) -> str | None:
    z = d.get("zustand")
    if d.get("veraltet") or z is None:
        return "Notbremse ohne aktuelle Daten, neue Longs gesperrt (Welt A)" if d.get("da") else None
    if z["stufe"] < 1:
        return None
    gk, ga = (z.get("gk") or {}).get("G") or {}, (z.get("ga") or {}).get("G") or {}
    teile = [f"NOTBREMSE Stufe {z['stufe']}" + (f" seit {_uhr(z['seit'])}" if z.get("seit") else "")]
    if z.get("quelle") in ("termin", "manuell") and z.get("grund"):
        teile.append(str(z["grund"])[:140])
    elif z.get("quelle") == "markt_y" and z.get("y") is not None:
        teile.append(f"Krypto allein {_de(z['y'])} σ")
    if gk.get("60") is not None and ga.get("60") is not None:
        teile.append(f"Gleichlauf Krypto {_de(gk['60'])} σ, Aktien {_de(ga['60'])} σ (60 min)")
    if z.get("lam") is not None and z["lam"] >= LAM_FREI:
        teile.append(f"Long-Liquidationen {_de(z['lam'] * 100)}. Perzentil")
    teile.append("neue Longs gesperrt")
    teile.append(f"frühestens frei {_uhr(z['frei_ab'])}" if z.get("frei_ab") else "bis auf Widerruf")
    if d.get("lang"):
        teile.append("seit 24 h, bitte prüfen")
    return " · ".join(teile)


def bericht_zeilen(db_main: str, store_b: str | None, store_a: str | None, preise: dict | None = None, now: int | None = None) -> list:
    """Abschnitt „Notbremse“ im Bericht ★ TradeLabor (KONZEPT 9)."""
    d = daten(db_main, store_b, store_a, preise, now)
    z = [f"NOTBREMSE (U206, {FASSUNG}; wirkt nur in Welt A, Welt B ist das TradeLabor wie bisher)"]
    if not d["da"]:
        return z + ["  notbremse.db fehlt -- Dienst hl-notbremse noch nicht gelaufen"]
    zz = d.get("zustand")
    if zz:
        z.append(f"  Zustand {_uhr(zz['ts'])} (vor {zz['alter_s']} s): Stufe {zz['stufe']} ({STUFE_NAME.get(zz['stufe'], '?')})"
                 + (f", Quelle {QUELLE_NAME.get(zz['quelle'], zz['quelle'])}" if zz.get("quelle") else "")
                 + (f", seit {_uhr(zz['seit'])}" if zz.get("seit") else "") + (f" — {zz['grund']}" if zz.get("grund") else ""))
        z.append(f"  X {_de(zz['x'], 2)} · Y {_de(zz['y'], 2)} · Λ {_de((zz['lam'] or 0) * 100 if zz.get('lam') is not None else None)} %"
                 + (f" · Hinweis: {zz['hinweis']}" if zz.get("hinweis") else ""))
        for g, nm in (("gk", "Krypto"), ("ga", "Aktien")):
            G = (zz.get(g) or {}).get("G") or {}; Nn = (zz.get(g) or {}).get("N") or {}
            z.append(f"  G {nm}: " + " · ".join(f"{w} min {_de(G.get(w), 2)} σ (n {Nn.get(w, 0)})" for w in sorted(G, key=int)))
    for h in d["hinweise"]:
        z.append(f"  HINWEIS: {h}")
    sj = d.get("schwellen_jetzt") or {}
    z.append(f"  Schwellen: θ1 {_de(sj.get('theta1'), 2)}, θ2X {_de(sj.get('theta2x'), 2)}, θ2Y {_de(sj.get('theta2y'), 2)}"
             + (f" (gültig ab {_uhr(sj['gueltig_ab'])}, {sj.get('zeitraum') or ''}" + (f", an der Klammer: {', '.join(sj['klammer'])}" if sj.get("klammer") else "") + ")"
                if sj.get("gueltig_ab") else " (Startwerte, Kalibrierung läuft)"))
    e30 = d.get("episoden_30t") or {}
    z.append(f"  Episoden in 30 Tagen: {e30.get('s1', 0)} (davon Stufe 2: {e30.get('s2', 0)}; Budget {BUDGET['s1x']} / {BUDGET['s2x']} / {BUDGET['s2y']}); "
             f"Spiegel (Aufwärtsschock, nur gezählt): {e30.get('spiegel', 0)}")
    for e in (d.get("episoden") or [])[:10]:
        v = e.get("varianten") or {}
        z.append(f"    {_uhr(e['start'])}–{_uhr(e['ende']) if e['ende'] else 'läuft'}: Stufe {e['stufe_max']}, {QUELLE_NAME.get(e['ausloeser'], e['ausloeser'])}, "
                 f"{e.get('gesperrt_n') or 0} gesperrt, {e.get('storniert_n') or 0} storniert"
                 + (f", D {_de(e['d_usd'], 0)} USD" if e.get("d_usd") is not None else "")
                 + (f", V1−V0 {_de(v.get('d1'), 0)} · V2−V0 {_de(v.get('d2'), 0)} · V3−V0 {_de(v.get('d3'), 0)} USD ({v.get('n')} Longs)" if v else ""))
    w = d.get("welten")
    if w:
        z.append(f"  Welt A seit {_uhr(w['start'])}: mit Notbremse {_de(w['mit'], 0)} USD · ohne {_de(w['ohne'], 0)} USD · Unterschied "
                 f"{_de(w['unterschied'], 0)} USD" + (f" (ohne Kurs: {', '.join(w['ohne_kurs'])})" if w.get("ohne_kurs") else ""))
        grosse = sorted(w["je_sid"].items(), key=lambda kv: -abs(kv[1]))[:8]
        if grosse:
            z.append("  Unterschied je Strategie (A − B): " + " · ".join(f"{k.split('@')[0]} {_de(v, 0)}" for k, v in grosse))
    tg = [x for x in (d.get("tage") or []) if x.get("d") is not None]
    if tg:
        z.append("  D je Tag (A − B): " + " · ".join(f"{datetime.fromtimestamp(x['tag'], UTC):%d.%m.} {_de(x['d'], 0)}" for x in tg[:10]))
    if d.get("termine"):
        z.append("  Termine: " + " · ".join(f"{e['name']} {_uhr(e['start'])}–{_uhr(e['ende'])}" + (" (aktiv)" if e["aktiv"] else "") for e in d["termine"]))
    return z


def status_text(db_main: str) -> str:
    return "\n".join(bericht_zeilen(db_main, None, None))


def preise_jetzt(db_main: str, coins=None) -> dict:
    """{coin: Schluss der letzten Minutenkerze} für Bericht und Vergleich der Welten außerhalb des Labor-Takts."""
    if coins is None:
        import hl_labor
        coins = hl_labor.COINS
    out = {}
    try:
        cm = sqlite3.connect(f"file:{db_main}?mode=ro", uri=True, timeout=30)
        try:
            for c in coins:
                px = _kurs_zu(cm, c, int(time.time()) + 60)
                if px:
                    out[c] = px
        finally:
            cm.close()
    except sqlite3.Error:
        pass
    return out


def banner_daten(db_main: str, now: int | None = None) -> dict:
    """Leichter Stand für das Banner auf jedem Reiter (eine Abfrage): Stufe, seit, frei ab, Grund, veraltet, Text."""
    now = int(now or time.time())
    nb = nb_pfad(db_main)
    d = {"ts": now, "da": os.path.exists(nb), "zustand": None, "veraltet": False}
    if d["da"]:
        try:
            con = verbinden(nb, nur_lesen=True)
            try:
                z = zustand(con, now)
            finally:
                con.close()
        except sqlite3.Error:
            z = None
        d["zustand"] = z
        d["veraltet"] = z is None or z["alter_s"] > ZUSTAND_MAX_ALTER
        if z and z["stufe"] >= 1 and z.get("seit") and now - int(z["seit"]) >= TAG:
            d["lang"] = True
    d["text"] = banner_text(d)
    d["stufe"] = None if d["veraltet"] else (d["zustand"] or {}).get("stufe", 0)
    return d


def handbremse(db_main: str, aktion: str, grund: str = "", now: int | None = None) -> dict:
    """Handbremse (Ebene C, KONZEPT 6): Eintrag in nb_manuell und sofort eine Zustandszeile mit Quelle „manuell“ (Sekunden-Zeitstempel
    zwischen den Minutenzeilen des Dienstes; das Labor liest sie über die id) -- der Dienst übernimmt die Aktion in seine Zustandsmaschine
    mit seinem nächsten Takt. „aufheben“ hebt auch eine Marktsperre auf; danach 60 min Ruhefenster (nur Stufe 2 löst neu aus)."""
    if aktion not in MANUELL_DAUER and aktion != "aufheben":
        return {"ok": False, "msg": "unbekannte Aktion"}
    now = int(now or time.time())
    grund = " ".join(str(grund or "").split())[:200]
    nb = nb_pfad(db_main)
    con = verbinden(nb)
    try:
        with schreiben(con):
            dauer = MANUELL_DAUER.get(aktion)
            con.execute("INSERT INTO nb_manuell (ts, aktion, dauer_s, grund) VALUES (?,?,?,?)", (now, aktion, dauer, grund))
            z = zustand(con, now) or {}
            alt = int(z.get("stufe") or 0) if z and z.get("alter_s", 1e9) <= ZUSTAND_MAX_ALTER else 0
            if aktion == "aufheben":
                stufe, seit, frei = 0, None, None
                text = "Sperre aufgehoben (Handbremse)" + (f": {grund}" if grund else "") + f"; Ruhefenster bis {_uhr(now + RUHE_S)} (nur Stufe 2 löst aus)"
            else:
                stufe = max(alt, 2 if aktion == "schock4h" else 1)
                seit = z.get("seit") if alt >= 1 and z.get("seit") else now
                frei = (now + int(dauer)) if dauer else None
                text = ("Handbremse " + ("Schock" if aktion == "schock4h" else "Long-Sperre") + (f" bis {_uhr(frei)}" if frei else " bis auf Widerruf")
                        + (f": {grund}" if grund else ""))
            con.execute("INSERT INTO nb_zustand (ts, stufe, quelle, grund, x, y, lam, wache, gk_json, ga_json, seit, frei_ab, hinweis, spiegel) "
                        "VALUES (?,?,?,?,?,?,?,0,?,?,?,?,?,0)",
                        (now, stufe, "manuell", text, z.get("x"), z.get("y"), z.get("lam"), json.dumps(z.get("gk") or {}), json.dumps(z.get("ga") or {}),
                         seit, frei, "Handbremse (der Dienst übernimmt sie mit seinem nächsten Takt)"))
    finally:
        con.close()
    return {"ok": True, "aktion": aktion, "stufe": stufe, "msg": text}


# ============================================================================================= Selbsttest (KONZEPT 10)
def _synth(seed: int, t_start: int, tage: int, schritt: int = 60, n_k: int = 10, n_a: int = 6, nu: int = 3, rho: float = 0.5,
           sig_k: float = 0.0006, sig_a: float = 0.0002, profil_k: float = 1.3, profil_a: float = 3.0, rho_a: float | None = None) -> dict:
    """Synthetischer Markt: n_k Krypto- und n_a Aktieninstrumente mit gemeinsamem Faktor, t-verteilten Renditen (ν) und Tagesprofil (Aktien in
    der Sitzung profil_a-mal so beweglich wie außerhalb). Kurs zur Zeit t_start + schritt · k. -> {inst: Array}"""
    rng = np.random.default_rng(seed)
    n = tage * TAG // schritt
    S = sitzungs_indikator(t_start, t_start + n * schritt)
    if schritt != 60:
        S = S[::schritt // 60]
    S = S[:n].astype(bool)
    skal = math.sqrt(nu / (nu - 2))
    f = rng.standard_t(nu, n) / skal
    out = {}
    for name, anz, sg, pr, rh in (("K", n_k, sig_k, profil_k, rho), ("xyz:A", n_a, sig_a, profil_a, rho if rho_a is None else rho_a)):
        for i in range(anz):
            e = rng.standard_t(nu, n) / skal
            s = sg * math.sqrt(schritt / 60) * np.where(S, pr, 1.0)
            r = s * (rh * f + math.sqrt(1 - rh * rh) * e)
            out[f"{name}{i}"] = 100.0 * np.exp(np.cumsum(r))
    return out


def _hauptdb_liq(pfad: str, t_von: int, t_bis: int, seed: int = 5, spitzen: list | None = None) -> None:
    """Hauptdatenbank mit Tabelle liquidations: kleine Long- und Short-Liquidationen etwa alle 5 min (Referenz für Λ), dazu Spitzen
    [(t, usd, seite)]."""
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("CREATE TABLE IF NOT EXISTS liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, "
                      "tid INTEGER PRIMARY KEY); CREATE INDEX IF NOT EXISTS ix_liq_coin_ts ON liquidations(coin, ts);"
                      "CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, "
                      "PRIMARY KEY (ts, coin));")
    rows = []; tid = 1
    for t in range(t_von, t_bis, 300):
        for seite in ("A", "B"):
            if rng.random() < 0.6:
                rows.append((t + rng.randrange(300), "BTC", "0x1", "event", 100.0, 100.0, rng.uniform(50, 1500), seite, tid)); tid += 1
    for t, usd, seite in spitzen or []:
        rows.append((int(t), "ETH", "0x2", "event", 100.0, 100.0, usd / 100.0, seite, tid)); tid += 1
    con.executemany("INSERT INTO liquidations VALUES (?,?,?,?,?,?,?,?,?)", rows)
    con.commit(); con.close()


class _Probe:
    """Ein Dienst auf synthetischen Daten: 15-min-Schlüsse der 31 Tage vor dem Probetag, Mids je Minute aus dem Markt (mit Eingriffen)."""

    def __init__(self, tmp: str, name: str, markt: dict, t_start: int, tag_probe: int, spitzen: list | None = None):
        self.tmp = tmp
        self.nb = os.path.join(tmp, f"{name}_nb.db"); self.db = os.path.join(tmp, f"{name}_m.db")
        for p in (self.nb, self.db):
            for s in ("", "-wal", "-shm"):
                if os.path.exists(p + s):
                    os.remove(p + s)
        self.m = {k: v.copy() for k, v in markt.items()}; self.t_start = t_start; self.tag = tag_probe
        _hauptdb_liq(self.db, tag_probe - 32 * TAG, tag_probe + TAG, spitzen=spitzen)
        self.D = Dienst(self.db, nb=self.nb, http=lambda body: (None, "Probe ohne Netz", None), uhr=lambda: float(self.uhr_t), log=lambda s: None,
                        termine_datei=os.path.join(tmp, f"{name}_termine.json"))
        self.uhr_t = tag_probe
        K = [k for k in self.m if not k.startswith("xyz:")]; A = [k for k in self.m if k.startswith("xyz:")]
        self.D.korb = {"tag": tag_probe, "K": K, "A": A, "anzeige": [], "dex": {}}
        zeilen = []
        for inst, p in self.m.items():
            for ts in range(tag_probe - 31 * TAG, tag_probe, 900):
                k = (ts + 900 - t_start) // 60
                if 0 <= k < len(p):
                    zeilen.append((inst, ts, float(p[k])))
        with schreiben(self.D.con):
            self.D.con.executemany("INSERT INTO nb_kerze15 VALUES (?,?,?)", zeilen)
            meta_setzen(self.D.con, {"historie": {"fertig": True, "15m": [], "1m": []}})
            self.D.con.execute("INSERT INTO nb_schwellen VALUES (?,?,?,?,?,?,?,?)", (tag_probe - TAG, START["theta1"], START["theta2x"], START["theta2y"],
                                                                                      json.dumps(BUDGET), "Probe", "[]", json.dumps({"quelle": "Startwerte"})))
        self.fehlt: dict = {}                                         # Minute -> Instrumente ohne Mid

    def mids(self, t: int) -> dict:
        k = (t - self.t_start) // 60
        return {i: float(p[k]) for i, p in self.m.items() if 0 <= k < len(p) and i not in self.fehlt.get(t, ())}

    def vorlauf(self, t_von: int, t_bis: int) -> None:
        """nb_preis für [t_von, t_bis) direkt füllen (ohne Takte)."""
        zeilen = [(i, t, v) for t in range(t_von, t_bis, 60) for i, v in self.mids(t).items()]
        with schreiben(self.D.con):
            self.D.con.executemany("INSERT OR REPLACE INTO nb_preis VALUES (?,?,?)", zeilen)

    def lauf(self, t_von: int, t_bis: int) -> list:
        out = []
        for t in range(t_von, t_bis, 60):
            self.uhr_t = t + 5
            z = self.D.takt(t, mids=self.mids(t))
            out.append((t, z["stufe"], z.get("X"), z.get("Y"), z.get("lam"), z.get("hinweis") or "", z.get("quelle")))
        return out

    def sigma15(self, inst: str, klasse: str = "S") -> float:
        v = sigma_laden(self.D.con, [self.tag]).get(self.tag, {}).get((inst, klasse))
        return math.sqrt(15 * v) if v else float("nan")

    def eingriff(self, insts, t0: int, minuten: int, ziel_log: dict) -> None:
        """Ab t0 linear über `minuten` um ziel_log[inst] (log) verschieben, danach auf dem neuen Niveau weiter."""
        for i in insts:
            p = self.m[i]; k0 = (t0 - self.t_start) // 60
            for j in range(k0, len(p)):
                anteil = min(1.0, (j - k0) / minuten)
                p[j] *= math.exp(ziel_log[i] * anteil)


def _probe_markt(tmp: str, ok) -> None:
    """Proben 1–5 (Sitzung, Startwerte der Schwellen) über den ganzen Weg: Mids → Maße → Stufe."""
    t_start = int(datetime(2026, 8, 10, tzinfo=UTC).timestamp())           # Montag
    tag = t_start + 31 * TAG                                                # Donnerstag, 10.09.2026: Handelstag
    s_beginn = sitzung(_ny_datum(tag + 15 * 3600))[0]
    markt = _synth(41, t_start, 32)
    K = [k for k in markt if not k.startswith("xyz:")]; A = [k for k in markt if k.startswith("xyz:")]
    t_s = s_beginn + 90 * 60                                                # Schock 90 min nach Sitzungsbeginn

    # Probe 1: Gleichlauf-Schock 6 σ(15) in 15 min
    P = _Probe(tmp, "p1", markt, t_start, tag)
    P.vorlauf(t_s - 6 * 3600 - 250 * 60, t_s - 6 * 3600)
    P.lauf(tag + 300, tag + 360)                                            # σ des Tages rechnen lassen (00:05)
    P.eingriff(K + A, t_s, 15, {i: -6 * P.sigma15(i) for i in K + A})
    r = P.lauf(t_s - 6 * 3600, t_s + 30 * 60)
    vor = [x for x in r if x[0] < t_s]; nach = [x for x in r if x[0] >= t_s]
    erst = next((x for x in nach if x[1] >= 1), None); s2 = next((x for x in nach if x[1] >= 2), None)
    ok("Probe 1: Gleichlauf-Schock 6 σ(15) in 15 min", all(x[1] == 0 for x in vor) and erst and erst[1] == 1 and s2 and s2[0] - t_s <= 16 * 60,
       f"6 h davor Stufe 0 ({sum(x[1] > 0 for x in vor)} Minuten gesperrt); Stufe 1 nach {(erst[0] - t_s) // 60 if erst else '—'} min "
       f"(X {_de(erst[2], 2) if erst else '—'}), Stufe 2 nach {(s2[0] - t_s) // 60 if s2 else '—'} min (X {_de(s2[2], 2) if s2 else '—'})")

    # Probe 2: langsamer Abverkauf −3 σ(240) über 4 h
    P = _Probe(tmp, "p2", markt, t_start, tag)
    t2 = s_beginn + 30 * 60
    P.vorlauf(t2 - 250 * 60, t2 - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    sig240 = {i: math.sqrt(240) * P.sigma15(i) / math.sqrt(15) for i in K + A}
    P.eingriff(K + A, t2, 240, {i: -3 * sig240[i] for i in K + A})
    r = P.lauf(t2 - 60 * 60, t2 + 300 * 60)
    st_ = [x[1] for x in r if x[0] >= t2]
    xmin = min((x[2] for x in r if x[2] is not None), default=None)
    ok("Probe 2: langsamer Abverkauf −3 σ(240) über 4 h", max(st_) == 1 and 2 not in st_,
       f"höchste Stufe {max(st_)}, kleinstes X {_de(xmin, 2)} (θ1 {START['theta1']}, θ2X {START['theta2x']})")

    # Probe 3: ein Coin −40 %, der Rest ruhig
    P = _Probe(tmp, "p3", markt, t_start, tag)
    P.vorlauf(t_s - 250 * 60, t_s - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    P.eingriff([K[0]], t_s, 5, {K[0]: math.log(0.6)})
    r = P.lauf(t_s - 60 * 60, t_s + 120 * 60)
    ok("Probe 3: Einzelwert −40 % → Stufe 0", all(x[1] == 0 for x in r), f"höchste Stufe {max(x[1] for x in r)}, kleinstes Y "
       f"{_de(min((x[3] for x in r if x[3] is not None), default=None), 2)}")
    # Probe 3b: ein Aktienwert −40 %, dazu fällt der Krypto-Korb breit um 4 σ(15) -- der Median der Aktien bleibt ruhig, kein Gleichlauf
    P = _Probe(tmp, "p3b", markt, t_start, tag)
    P.vorlauf(t_s - 250 * 60, t_s - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    P.eingriff(K, t_s, 15, {i: -4 * P.sigma15(i) for i in K})
    P.eingriff([A[0]], t_s, 5, {A[0]: math.log(0.6)})
    r = P.lauf(t_s - 60 * 60, t_s + 120 * 60)
    ok("Probe 3b: ein Aktienwert −40 % bei fallendem Krypto-Korb → Stufe 0 (Median: die Hälfte des Korbs muss fallen)", all(x[1] == 0 for x in r),
       f"höchste Stufe {max(x[1] for x in r)}, kleinstes X {_de(min((x[2] for x in r if x[2] is not None), default=None), 2)}, kleinstes Y "
       f"{_de(min((x[3] for x in r if x[3] is not None), default=None), 2)}")

    # Probe 4: nur Krypto −6 σ(15) in 15 min; Λ niedrig → 0, Λ = 0,995 → 2
    P = _Probe(tmp, "p4a", markt, t_start, tag)
    P.vorlauf(t_s - 250 * 60, t_s - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    P.eingriff(K, t_s, 15, {i: -6 * P.sigma15(i) for i in K})
    ra = P.lauf(t_s - 60 * 60, t_s + 60 * 60)
    spitze = [(t_s + 600 + 30 * k, 4e6, "A") for k in range(6)]               # weit über allen 15-min-Summen der 30 Tage
    P = _Probe(tmp, "p4b", markt, t_start, tag, spitzen=spitze)
    P.vorlauf(t_s - 250 * 60, t_s - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    P.eingriff(K, t_s, 15, {i: -6 * P.sigma15(i) for i in K})
    rb = P.lauf(t_s - 60 * 60, t_s + 60 * 60)
    ymin = min((x[3] for x in ra if x[3] is not None), default=None)
    lmax = max((x[4] for x in rb if x[4] is not None), default=None)
    ok("Probe 4: nur Krypto -- Λ niedrig Stufe 0, Λ hoch Stufe 2", max(x[1] for x in ra) == 0 and max(x[1] for x in rb) == 2
       and next(x for x in rb if x[1] == 2)[6] == "markt_y",
       f"Λ niedrig: höchste Stufe {max(x[1] for x in ra)} (kleinstes Y {_de(ymin, 2)}); Λ bis {_de(lmax * 100 if lmax else None)} %: höchste Stufe "
       f"{max(x[1] for x in rb)} ({next((x[6] for x in rb if x[1] == 2), '—')})")

    # Probe 5: Datenlücke -- Aktien seit 150 s ohne Wert, dabei ein Gleichlauf-Schock
    P = _Probe(tmp, "p5", markt, t_start, tag)
    P.vorlauf(t_s - 250 * 60, t_s - 60 * 60)
    P.lauf(tag + 300, tag + 360)
    P.eingriff(K + A, t_s, 3, {i: -6 * P.sigma15(i) for i in K + A})
    for t in range(t_s - 60, t_s + 600, 60):                                  # ab einer Minute vor dem Schock keine Aktien-Mids
        P.fehlt[t] = set(A)
    r = P.lauf(t_s - 30 * 60, t_s + 5 * 60)
    gap = [x for x in r if x[0] >= t_s + 120]
    ok("Probe 5: Datenlücke Aktien → X undefiniert, kein Auslösen, Hinweis", gap and all(x[2] is None and x[1] == 0 for x in gap)
       and all("Aktien: keine aktuellen Daten" in x[5] for x in gap),
       f"{len(gap)} Minuten ohne Aktien: X {[x[2] for x in gap][:2]}, Stufe {max((x[1] for x in gap), default='—')}, Hinweis „{gap[0][5] if gap else ''}“")


def _probe_maschine(ok) -> None:
    """Proben 6, 7 und 14 (Zustand): Hysterese, Mindestdauer, Handbremse und Ruhefenster -- an der Zustandsmaschine."""
    th = dict(START); t0 = 1_800_000_000
    M = Maschine(); ep = 0; st = []
    for k in range(600):
        t = t0 + 60 * k
        x = (START["theta1"] - 0.1 if (k // 10) % 2 == 0 else START["theta1"] + 0.1) if k < 180 else 0.0
        z = M.schritt(t, {"X": x, "Y": None, "lam": 0.2, "GK60": x}, th)
        ep += int(z["neu"]); st.append(z["stufe"])
    letzte_b = max(k for k in range(180) if (k // 10) % 2 == 0)
    frei = next(k for k in range(180, 600) if st[k] == 0)
    M = Maschine(); st_h = []                                                # X bleibt 3 h zwischen θ1 und θ1/2: frei erst 30 min danach
    for k in range(400):
        x = START["theta1"] - 0.2 if k < 10 else (START["theta1"] + 0.3 if k < 190 else 0.0)
        st_h.append(M.schritt(t0 + 60 * k, {"X": x, "Y": None, "lam": 0.2, "GK60": x}, th)["stufe"])
    frei_h = next(k for k in range(10, 400) if st_h[k] == 0)
    ok("Probe 6: Hysterese -- X pendelt 3 h um θ1 → genau eine Episode; bleibt X zwischen θ1 und θ1/2, hält die Sperre",
       ep == 1 and frei - letzte_b >= 120 and frei_h >= 190 + 30,
       f"{ep} Episode(n); frei {frei - letzte_b} min nach der letzten Bedingung; X 3 h zwischen θ1 und θ1/2: frei in Minute {frei_h} "
       "(X über θ1/2 ab Minute 190)")
    M = Maschine(); st = []
    for k in range(600):
        x = START["theta2x"] - 0.5 if 10 <= k < 15 else 0.0
        st.append(M.schritt(t0 + 60 * k, {"X": x, "Y": None, "lam": 0.2, "GK60": x}, th)["stufe"])
    ende2 = next(k for k in range(15, 600) if st[k] < 2)
    M = Maschine(); st1 = []
    for k in range(400):
        x = START["theta1"] - 0.2 if 10 <= k < 15 else 0.0
        st1.append(M.schritt(t0 + 60 * k, {"X": x, "Y": None, "lam": 0.2, "GK60": x}, th)["stufe"])
    ende1 = next(k for k in range(15, 400) if st1[k] == 0)
    M = Maschine(); st1b = []
    for k in range(400):                                                     # Freigabe erst nach 30 min Λ < 0,90
        x = START["theta1"] - 0.2 if 10 <= k < 15 else 0.0
        lam = 0.95 if k < 200 else 0.2
        st1b.append(M.schritt(t0 + 60 * k, {"X": x, "Y": None, "lam": lam, "GK60": x}, th)["stufe"])
    ende1b = next(k for k in range(15, 400) if st1b[k] == 0)
    ok("Probe 7: Mindestdauer Stufe 2 (240 min) und Stufe 1 (120 min, 30 min Ruhe)", ende2 - 14 >= 240 and ende1 - 14 >= 120 and ende1b - 200 >= 30,
       f"Stufe 2 bis {ende2 - 14} min nach der letzten Bedingung; Stufe 1 bis {ende1 - 14} min; mit Λ ≥ 0,9 bis Minute 200: frei {ende1b - 200} min danach")
    # Probe 14 (Zustand): Handbremse 1 h, aufheben, Ruhefenster -- zwei Wege nach dem Aufheben
    def weg(x_fn):
        M_ = Maschine(); o_ = []
        for k in range(240):
            t = t0 + 60 * k
            if k == 10:
                M_.aktion({"id": 1, "ts": t, "aktion": "1h", "grund": "Probe"})
            if k == 30:
                M_.aktion({"id": 2, "ts": t, "aktion": "aufheben"})
            x = x_fn(k)
            z = M_.schritt(t, {"X": x, "Y": None, "lam": 0.2, "GK60": x}, th)
            o_.append((k, z["stufe"], z["quelle"]))
        return o_
    out = weg(lambda k: START["theta1"] - 0.3 if (40 <= k < 60 or 100 <= k < 105) else 0.0)
    out2 = weg(lambda k: START["theta2x"] - 0.3 if 60 <= k < 62 else 0.0)
    ok("Probe 14: Handbremse → Stufe 1; aufheben → 0; 60 min nur Stufe 2", out[10][1] == 1 and out[10][2] == "manuell" and all(o[1] == 1 for o in out[10:30])
       and out[30][1] == 0 and all(o[1] == 0 for o in out[30:90]) and out[100][1] == 1 and out2[60][1] == 2,
       f"Handbremse {out[10][1]} ({out[10][2]}), aufgehoben {out[30][1]}; X ≤ θ1 im Ruhefenster: Stufe {max(o[1] for o in out[40:60])}; "
       f"nach dem Ruhefenster X ≤ θ1: Stufe {out[100][1]}; X ≤ θ2X im Ruhefenster: Stufe {out2[60][1]}")
    # Termin: genau im Zeitraum Stufe 1
    M = Maschine(); tt = {"name": "Probe", "start": t0 + 600, "ende": t0 + 1200}
    s = [M.schritt(t0 + 60 * k, {"X": 0.0, "Y": None, "lam": 0.2, "GK60": 0.0}, th, termin_aktiv([tt], t0 + 60 * k))["stufe"] for k in range(30)]
    ok("Termin (B3): im Zeitraum Stufe 1, danach frei", s[9] == 0 and all(x == 1 for x in s[10:20]) and s[20] == 0, f"Stufen {s[8:22]}")


def _probe_kalibrierung(ok) -> None:
    """Probe 15: 20 Läufe ohne Schocks, je 60 Tage Kalibrierung und 60 Tage Prüfung (15-min-Raster), Budget 4 → im Mittel 3–6 Episoden je
    30 Prüftage."""
    raten = []; thetas = []
    t_start = int(datetime(2026, 3, 2, tzinfo=UTC).timestamp())
    for lauf in range(20):
        m = _synth(1000 + lauf, t_start, 150, schritt=900)
        P15 = {k: v for k, v in m.items()}                                 # Kurs zur Zeit t_start + 900 k = c(ts = t_start + 900 (k − 1))
        gruppen = {"K": [k for k in m if not k.startswith("xyz:")], "A": [k for k in m if k.startswith("xyz:")]}
        tage = list(range(t_start + 30 * TAG, t_start + 150 * TAG, TAG))
        Pk = {k: np.concatenate([v[1:], [np.nan]]) for k, v in P15.items()}  # c(ts) = Kurs zur Zeit ts + 900
        V = sigma_reihe(t_start, Pk, tage, SIGMA_TAGE, None, gruppen)
        R = reihe_masse(t_start + 30 * TAG, 900, {k: v[30 * 96:] for k, v in P15.items()}, gruppen, V, FENSTER_X15)
        T, X = R["T"], R["X"]
        kal = T < t_start + 90 * TAG
        s = schwelle_waehlen(T[kal], X[kal], 900, BUDGET["s1x"], float(np.sum(np.isfinite(X[kal]))) * 900 / TAG)
        th, _an = klammern({"theta1": s["theta"], "theta2x": -6.0, "theta2y": -8.0})
        pr = ~kal
        n = len(episoden(T[pr], np.isfinite(X[pr]) & (X[pr] <= th["theta1"]), 900))
        tage_p = float(np.sum(np.isfinite(X[pr]))) * 900 / TAG
        raten.append(n * 30.0 / tage_p); thetas.append(th["theta1"])
    mittel = float(np.mean(raten))
    ok("Probe 15: Kalibrierung -- Budget 4 hält außerhalb der Stichprobe (3–6 je 30 Tage)", 3.0 <= mittel <= 6.0,
       f"20 Läufe: im Mittel {_de(mittel, 2)} Episoden je 30 Prüftage (Spanne {_de(min(raten), 1)}–{_de(max(raten), 1)}), θ1 im Mittel "
       f"{_de(float(np.mean(thetas)), 2)} ({_de(min(thetas), 2)} bis {_de(max(thetas), 2)})")
    # 23.77: Rate bei der wirksamen Schwelle. 30 Tage, 10 Dellen auf −3,60 und 3 auf −4,20 (je eine Stunde, 2 Tage Abstand): Budget 4 wählt
    # roh −3,65 (3 Episoden), die Klammer setzt θ1 = −3,50 -- dort liegen 13 Episoden; Y ohne einen Wert, der das Budget 1 hält (5 Tiefs auf
    # −9 mit Λ = 1) → θ2Y = −8,00 mit 5 Episoden je 30 Tage. Bericht und Abschnitt zeigen die wirksame Rate.
    T = np.arange(t_start, t_start + 30 * TAG, 900, dtype=np.int64)
    X = np.zeros(len(T))
    for j in range(13):
        a = (j * 2 * TAG + TAG) // 900
        X[a:a + 4] = -3.6 if j < 10 else -4.2
    T1 = np.arange(t_start, t_start + 30 * TAG, 60, dtype=np.int64)
    Y = np.zeros(len(T1)); lam = np.zeros(len(T1))
    for j in range(5):
        a = (j * 6 * TAG + TAG // 2) // 60
        Y[a:a + 5] = -9.0; lam[a:a + 5] = 1.0
    k = kalibrieren({"T": T, "X": X, "schritt": 900, "tage": 30.0}, {"T": T1, "Y": Y, "lam": lam, "schritt": 60, "tage": 30.0})
    i1, i2y = k["info"]["s1x"], k["info"]["s2y"]
    ok("Kalibrierung: Rate bei der wirksamen Schwelle (nach der Klammer; kein Wert hält das Budget)",
       k["theta1"] == -3.5 and i1["theta"] == -3.65 and abs(i1["je30"] - 3.0) < 1e-9 and abs(i1["je30_wirksam"] - 13.0) < 1e-9
       and k["theta2y"] == -8.0 and i2y["keiner"] and i2y["je30"] is None and abs(i2y["je30_wirksam"] - 5.0) < 1e-9,
       f"θ1 roh {i1['theta']} ({i1['je30']} je 30 Tage) → wirksam {k['theta1']} ({i1['je30_wirksam']}); θ2Y {k['theta2y']}: kein Wert hält das "
       f"Budget ({i2y['keiner']}), wirksam {i2y['je30_wirksam']} je 30 Tage")


def _probe_zeitklassen(ok) -> None:
    """Probe 17: Über 60 Tage liegt der Anteil der Minuten mit G(A, 15) ≤ θ1 in der Sitzung und außerhalb höchstens um den Faktor 2 auseinander;
    mit einer Klasse für alles (Gegenprobe) ist er in der Sitzung mehr als fünfmal so hoch. Dazu σ eines Fensters 30 min nach Börsenschluss
    von Hand."""
    t_start = int(datetime(2026, 4, 6, tzinfo=UTC).timestamp())
    m = _synth(77, t_start, 90, schritt=60, n_k=0, n_a=6, rho_a=0.85)       # Aktien untereinander eng verbunden (Index und Schwergewichte)
    gruppen = {"A": list(m)}
    t15 = t_start
    P15 = {k: v[15::15][:90 * 96] for k, v in m.items()}                  # c(ts) = Kurs zur Zeit ts + 900 (Index 15 k + 15)
    tage = list(range(t_start + 30 * TAG, t_start + 90 * TAG, TAG))
    anteile = {}
    for name, gepoolt in (("mit Klassen", False), ("eine Klasse", True)):
        V = sigma_reihe(t15, P15, tage, SIGMA_TAGE, None, gruppen)
        if gepoolt:                                                          # Gegenprobe: alle Renditen in einer Klasse
            for D in tage:
                lo = (D - SIGMA_TAGE * TAG - t15) // 900; hi = (D - t15) // 900
                for i, c in P15.items():
                    r = np.log(c[1:] / c[:-1])[max(lo - 1, 0):hi - 1]
                    r = r[np.isfinite(r)]
                    v = _mad_v(r)
                    V[D][(i, "S")] = v; V[D][(i, "A")] = v
        k0 = 30 * 1440
        R = reihe_masse(t_start + 30 * TAG, 60, {k: v[k0:] for k, v in m.items()}, gruppen, V, {"A": (15,)})
        G = R["G"][("A", 15)]; T = R["T"]
        S = sitzungs_indikator(int(T[0]), int(T[-1]) + 60).astype(bool)
        f = np.isfinite(G)
        a_s = float(np.mean(G[f & S] <= START["theta1"])); a_a = float(np.mean(G[f & ~S] <= START["theta1"]))
        anteile[name] = (a_s, a_a)
    q_mit = anteile["mit Klassen"][0] / max(anteile["mit Klassen"][1], 1e-12)
    q_ohne = anteile["eine Klasse"][0] / max(anteile["eine Klasse"][1], 1e-12)
    schluss = sitzung(date(2026, 10, 22))[1]
    v_s, v_a = 4e-8, 1e-8
    n_s = sitzungsminuten(schluss + 1800 - 240 * 60, schluss + 1800)
    soll = math.sqrt(210 * v_s + 30 * v_a)
    ist = sigma_fenster(v_s, v_a, n_s, 240 - n_s)
    # dasselbe Fenster durch reihe_masse: ein Instrument, Kurs 100 → 100·e^r, z = r / σ
    T_e = schluss + 1800; t0_ = T_e - 240 * 60; r_ = 0.004
    p_ = np.full(241, np.nan); p_[0] = 100.0; p_[240] = 100.0 * math.exp(r_)
    tg_ = (T_e // TAG) * TAG
    Rz = reihe_masse(t0_, 60, {"i": p_}, {"A": ["i"]}, {tg_: {("i", "S"): v_s, ("i", "A"): v_a}, tg_ - TAG: {("i", "S"): v_s, ("i", "A"): v_a}},
                     {"A": (240,)}, min_n={"A": 1})
    z_ist = float(Rz["G"][("A", 240)][240])
    ok("Probe 17: Zeitklassen -- Anteil G(A,15) ≤ θ1 in und außerhalb der Sitzung", 0.5 <= q_mit <= 2.0 and q_ohne > 5.0 and n_s == 210 and abs(ist - soll) < 1e-15
       and abs(z_ist - r_ / soll) < 1e-9,
       f"mit Klassen: Sitzung {anteile['mit Klassen'][0] * 100:.2f} %, außerhalb {anteile['mit Klassen'][1] * 100:.2f} % (Faktor {q_mit:.2f}); "
       f"eine Klasse: Faktor {q_ohne:.1f}; Fenster 30 min nach Schluss: {n_s} Sitzungsminuten, σ = √(210 · v_S + 30 · v_A), z im Raster "
       f"{z_ist:.4f} gegen {r_ / soll:.4f} von Hand")


def _probe_zeitstempel(tmp: str, ok) -> None:
    """Probe 16: alle Zeitspalten in Sekunden; eine Millisekunden-Zeile macht den Audit rot."""
    p = os.path.join(tmp, "p16_nb.db")
    con = verbinden(p)
    with schreiben(con):
        con.execute("INSERT INTO nb_zustand (ts, stufe) VALUES (?, 0)", (1_800_000_000,))
        con.execute("INSERT INTO nb_blockiert (ts, welt, sid, coin, seite, art) VALUES (?, 'A', 's', 'BTC', 'long', 'eroeffnen')", (1_800_000_060,))
    v1 = audit_zeiten(p)
    with schreiben(con):
        con.execute("INSERT INTO nb_zustand (ts, stufe) VALUES (?, 0)", (1_800_000_000_000,))
    v2 = audit_zeiten(p)
    con.close()
    ok("Probe 16: Zeitstempel in Sekunden, Millisekunden-Zeile macht den Audit rot", not v1 and v2 and "nb_zustand.ts" in v2[0], f"vorher {v1 or 'sauber'}; danach {v2}")


# --------------------------------------------------------------------------------------------- Proben 8–11: Tor und Welt A im Labor
def _labor_store(LB, F, pfad: str, info: dict, T0: int) -> None:
    """Prognosespeicher wie im Selbsttest des Labors: Treiber mit eingebauter Kante (Wale), Rauschen (Leaderboard), Prognosen."""
    kurs = info["kurs"]
    st = F.store_connect(pfad)
    rng = random.Random(3); drv = []; fc = []
    for t in range(T0, T0 + 5 * 86_400, 900):
        p0 = kurs.get(t // 60 * 60); p4 = kurs.get((t + 4 * 3600) // 60 * 60)
        if not p0 or not p4:
            continue
        richtig = rng.random() < 0.85
        s = (1 if p4 > p0 else -1) * (1 if richtig else -1) * 0.8
        drv += [(t, "AAA", "Wal-Flow 30 min", s), (t, "AAA", "Leaderboard-Flow 60 min", max(-1, min(1, rng.gauss(0, 0.6))))]
        fc.append((t, "AAA", p0, 0.0, p0, p0, json.dumps({"p_up_v2": 0.5, "kalib2": {"version": 2}, "fusion": {"p_4": 0.47}, "kosten": {"er_4": 0.0123}}),
                   0.5, 0.5))
    st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
    st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, buy_px, sell_px, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?)", fc)
    st.commit(); st.close()


def _nb_schreiben(pfad: str, von: int, bis: int, stufe_fn) -> None:
    """Zustandszeilen je Minute [von, bis) mit stufe_fn(ts) -> Stufe."""
    con = verbinden(pfad)
    with schreiben(con):
        con.executemany("INSERT INTO nb_zustand (ts, stufe, quelle, grund) VALUES (?,?,?,?)",
                        [(t, stufe_fn(t), "probe" if stufe_fn(t) else None, f"Probe Stufe {stufe_fn(t)}" if stufe_fn(t) else "") for t in range(von, bis, 60)])
    con.close()


def _dump(pfad: str) -> str:
    con = sqlite3.connect(pfad)
    try:
        return "\n".join(con.iterdump())
    finally:
        con.close()


def _probe_labor(tmp: str, ok) -> None:
    import copy
    import hl_forecast as F
    import hl_labor as LB
    T0 = 1_790_006_400 - 6 * 86_400
    db = os.path.join(tmp, "lab_m.db")
    info = LB._probe_datenbank(db, T0, 5)
    nur = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "docht_fangen", "kaskade_umkehr", "kaskade_fortsetzung", "zufall", "halten_long")
    schritt = 300; t_von = T0 + 86_400; t_bis = T0 + 5 * 86_400 - 300; T_A = t_von + 2 * 3600
    af = os.path.join(tmp, "lab_af.db")
    # Lauf 1: Welt B allein (ohne Notbremse)
    sp1 = os.path.join(tmp, "lab_b1.db"); _labor_store(LB, F, sp1, info, T0)
    L1 = LB.Labor(db, sp1, coins=("AAA",), nur=nur, adressfluss=af)
    t = t_von
    while t < t_bis:
        L1.zyklus(t); t += schritt
    d1 = _dump(sp1)
    # Sperrfenster aus Lauf 1 wählen: B eröffnet darin Long und Short, bei Beginn liegt ein Long-Limit, ein offener Long schließt darin
    st1 = sqlite3.connect(sp1)
    pos = st1.execute("SELECT sid, coin, seite, eroeffnet, geschlossen, art_ein FROM labor_position").fetchall()
    ords = st1.execute("SELECT seite, erstellt, erledigt FROM labor_order").fetchall()
    st1.close()
    fenster = None
    for s in range(T_A + 3600, T0 + 4 * 86_400, 1800):
        e = s + 4 * 3600
        a = any(p[2] == "long" and s <= p[3] < e and str(p[5]).startswith("Markt") for p in pos)
        b = any(p[2] == "short" and s <= p[3] < e for p in pos)
        c = any(o[0] == "long" and o[1] < s and (o[2] is None or o[2] > s) for o in ords)
        d = any(p[2] == "long" and p[3] < s and p[4] is not None and s <= p[4] < e for p in pos)
        if a and b and c and d:
            fenster = (s, e); break
    ok("Proben 8/10: Sperrfenster mit Long, Short, Long-Limit und offenem Long gefunden", fenster is not None,
       f"{_uhr(fenster[0]) if fenster else '—'} bis {_uhr(fenster[1]) if fenster else '—'} (Lauf 1, {len(pos)} Positionen)")
    if not fenster:
        return
    s, e = fenster
    nb = os.path.join(tmp, "lab_nb.db")
    _nb_schreiben(nb, T0, T0 + 5 * 86_400, lambda ts: 1 if s <= ts < e else 0)
    # Lauf 2: Welt B und Welt A (Start als Kopie von B um T_A)
    sp2 = os.path.join(tmp, "lab_b2.db"); _labor_store(LB, F, sp2, info, T0)
    spa = os.path.join(tmp, "lab_a.db")
    L2 = LB.Labor(db, sp2, coins=("AAA",), nur=nur, adressfluss=af); LA = None
    t = t_von; fehler = []
    while t < t_bis:                                                       # wie im Dashboard: Welt A entsteht nach einem Takt der Welt B als
        L2.zyklus(t)                                                       # Kopie und rechnet ab dem nächsten Takt mit
        if LA is not None:
            LA.zyklus(t, E_von=L2.letzte)
        elif t >= T_A:
            start, neu = welt_a_anlegen(sp2, spa, t, {"gesamt": 0.0})
            LA = LB.Labor(db, spa, coins=("AAA",), nur=nur, adressfluss=af, welt="A", tor=Tor(nb, "A", welt_start=start))
            LA.z = copy.deepcopy(L2.z)
        t += schritt
    fehler = L2.fehler + (LA.fehler if LA else [])
    d2 = _dump(sp2)
    ok("Probe 10: Welt B byte-gleich mit einem Lauf ohne Notbremse", d1 == d2 and not fehler, f"Dump {len(d1):,} Zeichen, "
       f"{'gleich' if d1 == d2 else 'ANDERS'}; Fehler {fehler[-2:] or 'keine'}".replace(",", "."))
    sa = sqlite3.connect(spa); sb = sqlite3.connect(sp2); sn = sqlite3.connect(nb)
    try:
        sp_ = "sid, coin, seite, eroeffnet, preis_ein, notional, art_ein, geschlossen, preis_aus, netto_usd"
        pa = sa.execute(f"SELECT {sp_} FROM labor_position ORDER BY eroeffnet, id").fetchall()
        pb = sb.execute(f"SELECT {sp_} FROM labor_position ORDER BY eroeffnet, id").fetchall()
        long_neu = [p for p in pa if p[2] == "long" and s <= p[3] < e]
        short_neu = [p for p in pa if p[2] == "short" and s <= p[3] < e]
        zu_a = sorted(p for p in pa if p[2] == "long" and p[3] < s and p[7] is not None and s <= p[7] < e)
        zu_b = sorted(p for p in pb if p[2] == "long" and p[3] < s and p[7] is not None and s <= p[7] < e)
        ord_neu = sa.execute("SELECT COUNT(*) FROM labor_order WHERE seite='long' AND erstellt>=? AND erstellt<?", (s, e)).fetchone()[0]
        storno = sa.execute("SELECT COUNT(*), MIN(erledigt), MAX(erledigt) FROM labor_order WHERE seite='long' AND status='storniert' AND erstellt<? "
                            "AND erledigt>=? AND erledigt<?", (s, s, s + 2 * schritt)).fetchone()
        offen_bei_s = sb.execute("SELECT COUNT(*) FROM labor_order WHERE seite='long' AND erstellt<? AND (erledigt IS NULL OR erledigt>?)", (s, s)).fetchone()[0]
        blk = sn.execute("SELECT art, COUNT(*) FROM nb_blockiert WHERE ts>=? AND ts<? GROUP BY art", (s, e)).fetchall()
        ev_nb = sa.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='notbremse' AND ts>=? AND ts<?", (s, e)).fetchone()[0]
        ok("Probe 8: Tor in Stufe 1 -- kein Long, kein Long-Limit, Limits storniert; Short, Stop und Ziel gehen durch",
           not long_neu and ord_neu == 0 and storno[0] >= 1 and storno[0] == offen_bei_s and short_neu and zu_a and zu_a == zu_b
           and any(b_[0] == "eroeffnen" for b_ in blk) and ev_nb >= 1 and darf_frei_test(),
           f"Welt A im Fenster: {len(long_neu)} Longs, {ord_neu} neue Long-Limits, {storno[0]} von {offen_bei_s} Long-Limits storniert "
           f"(um {_uhr(storno[1]) if storno[1] else '—'}), {len(short_neu)} Shorts eröffnet, {len(zu_a)} vorher offene Longs geschlossen "
           f"(in B {len(zu_b)}, gleich: {zu_a == zu_b}); protokolliert {dict(blk)}")
        vor_a = [p for p in pa if p[3] < s]; vor_b = [p for p in pb if p[3] < s]
        oa = sorted(sa.execute("SELECT sid, coin, seite, preis, erstellt FROM labor_order WHERE erstellt<?", (s,)).fetchall())
        ob = sorted(sb.execute("SELECT sid, coin, seite, preis, erstellt FROM labor_order WHERE erstellt<?", (s,)).fetchall())
        # nach dem Beginn: jede Abweichung je Strategie und Coin folgt einem protokollierten Vorgang der Bremse
        abw = []
        for key in sorted({(p[0], p[1]) for p in pa + pb}):
            fa = [(p[3], p[2]) for p in pa if (p[0], p[1]) == key]; fb = [(p[3], p[2]) for p in pb if (p[0], p[1]) == key]
            if fa == fb:
                continue
            i = next((k for k in range(min(len(fa), len(fb))) if fa[k] != fb[k]), min(len(fa), len(fb)))
            t_diff = min([x[0] for x in (fa[i:i + 1] + fb[i:i + 1])] or [0])
            erst = sn.execute("SELECT MIN(ts) FROM nb_blockiert WHERE sid=? AND coin=?", key).fetchone()[0]
            abw.append((key[0].split("@")[0], t_diff, erst, erst is not None and erst <= t_diff))
        ok("Probe 10: bis zur ersten Sperre gleich, danach nur durch protokollierte Vorgänge abweichend",
           vor_a == vor_b and oa == ob and all(x[3] for x in abw) and abw,
           f"vor dem Fenster: {len(vor_a)} Positionen und {len(oa)} Orders gleich ({vor_a == vor_b and oa == ob}); danach {len(abw)} Strategien "
           f"abweichend, jede nach einem Eintrag in nb_blockiert: {all(x[3] for x in abw)} " + "; ".join(f"{x[0]}" for x in abw[:6]))
    finally:
        sa.close(); sb.close(); sn.close()
    _probe_labor_veraltet(tmp, ok, LB, F, db, info, T0, nur, af)
    _probe_labor_zeitpunkt(tmp, ok, LB, F, db, info, T0, af)
    _probe_labor_grid(tmp, ok, LB, F)


def darf_frei_test() -> bool:
    """Schließen, Verkleinern und Shorts gehen immer durch -- auch ohne jeden Zustand."""
    T = Tor(None, "A", zustaende=[(0, 2, "Probe")])
    return all(T.darf(10, s_, a_)[0] for s_, a_ in (("short", "eroeffnen"), ("short", "limit_setzen"), ("long", "schliessen"), ("long", "verkleinern"))) \
        and not T.darf(10, "long", "eroeffnen")[0]


def _probe_labor_veraltet(tmp, ok, LB, F, db, info, T0, nur, af) -> None:
    """Probe 11: Zustand älter als 180 s → Welt A eröffnet keine Longs, Welt B unverändert."""
    import copy
    nb = os.path.join(tmp, "lab11_nb.db"); sp = os.path.join(tmp, "lab11_b.db"); spa = os.path.join(tmp, "lab11_a.db")
    _labor_store(LB, F, sp, info, T0)
    t_von = T0 + 86_400; T_A = t_von + 3600; t_ende = T0 + 2 * 86_400; t_bis = T0 + 3 * 86_400
    _nb_schreiben(nb, T0, t_ende, lambda ts: 0)                                # danach schreibt der Dienst nichts mehr
    L = LB.Labor(db, sp, coins=("AAA",), nur=nur, adressfluss=af); LA = None
    t = t_von; veraltet = 0
    while t < t_bis:
        L.zyklus(t)
        if LA is not None:
            LA.zyklus(t, E_von=L.letzte)
            if t > t_ende + ZUSTAND_MAX_ALTER:
                veraltet += sum(1 for v in LA.status.values() if "veraltet" in str(v.get("blockiert") or ""))
        elif t >= T_A:
            start, _neu = welt_a_anlegen(sp, spa, t, {})
            LA = LB.Labor(db, spa, coins=("AAA",), nur=nur, adressfluss=af, welt="A", tor=Tor(nb, "A", welt_start=start)); LA.z = copy.deepcopy(L.z)
        t += 300
    sa = sqlite3.connect(spa); sb = sqlite3.connect(sp)
    la = sa.execute("SELECT COUNT(*) FROM labor_position WHERE seite='long' AND eroeffnet>?", (t_ende + ZUSTAND_MAX_ALTER,)).fetchone()[0]
    lb = sb.execute("SELECT COUNT(*) FROM labor_position WHERE seite='long' AND eroeffnet>?", (t_ende + ZUSTAND_MAX_ALTER,)).fetchone()[0]
    sh = sa.execute("SELECT COUNT(*) FROM labor_position WHERE seite='short' AND eroeffnet>?", (t_ende + ZUSTAND_MAX_ALTER,)).fetchone()[0]
    sa.close(); sb.close()
    ok("Probe 11: Zustand älter als 180 s → Welt A ohne neue Longs, Welt B unverändert", la == 0 and lb >= 1 and veraltet >= 1,
       f"nach dem Ausfall: Welt A {la} Longs ({sh} Shorts), Welt B {lb} Longs; Anzeige „Notbremse veraltet“ in {veraltet} Strategie-Takten")


def _probe_labor_zeitpunkt(tmp, ok, LB, F, db, info, T0, af) -> None:
    """Probe 9: Eine Limit-Füllung, die das Labor über Kerzen nachholt und die in den Sperrzeitraum fällt, wird verworfen; eine Füllung eine
    Minute vor der Sperre bleibt."""
    con = sqlite3.connect(db)
    k = con.execute("SELECT ts, low FROM bars WHERE coin='AAA' AND ts>=? AND ts<? ORDER BY ts", (T0 + 86_400 + 3600, T0 + 2 * 86_400)).fetchall()
    con.close()
    m_f = None
    for i in range(30, len(k)):
        vor = min(x[1] for x in k[i - 30:i])
        if k[i][1] < vor * 0.9995:
            m_f, low_f, min_vor = k[i][0], k[i][1], vor; break
    if m_f is None:
        ok("Probe 9: Zeitpunkt des Vorgangs", False, "kein neues 30-min-Tief im Probemarkt gefunden"); return
    preis = (low_f + min_vor) / 2
    S_docht = next(s_ for s_ in LB.strategien() if s_["name"] == "docht_fangen")
    erg = {}
    for fall, beginn in (("in der Sperre", m_f), ("eine Minute davor", m_f + 60)):
        sp = os.path.join(tmp, f"lab9_{beginn}_b.db"); spa = os.path.join(tmp, f"lab9_{beginn}_a.db"); nb = os.path.join(tmp, f"lab9_{beginn}_nb.db")
        _labor_store(LB, F, sp, info, T0)
        _nb_schreiben(nb, m_f - 3600, m_f + 3600, lambda ts, b_=beginn: 1 if ts >= b_ else 0)
        L = LB.Labor(db, sp, coins=("AAA",), nur=("docht_fangen",), adressfluss=af)
        jetzt = m_f + 180
        L.zyklus(m_f - 2400)
        start, _neu = welt_a_anlegen(sp, spa, m_f - 2400, {})
        con = sqlite3.connect(spa)
        con.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten_s, "
                    "geprueft_bis) VALUES (?,?,?,?,?,?,'offen','Probe','{}',0.01,0.01,NULL,NULL,3600,?)",
                    (S_docht["sid"], "AAA", "long", preis, m_f - 1800, m_f + 4 * 3600, m_f - 1800))
        con.commit(); con.close()
        LA = LB.Labor(db, spa, coins=("AAA",), nur=("docht_fangen",), adressfluss=af, welt="A", tor=Tor(nb, "A", welt_start=start))
        L.zyklus(jetzt); LA.zyklus(jetzt, E_von=L.letzte)
        c = sqlite3.connect(spa)
        p = c.execute("SELECT eroeffnet, preis_ein FROM labor_position WHERE sid=? AND seite='long'", (S_docht["sid"],)).fetchall()
        o = c.execute("SELECT status FROM labor_order WHERE grund='Probe'").fetchone()
        ev = c.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='notbremse' AND text LIKE '%Füllung%verworfen%'").fetchone()[0]
        c.close()
        erg[fall] = (p, o[0] if o else None, ev)
    a, b = erg["in der Sperre"], erg["eine Minute davor"]
    ok("Probe 9: Zeitpunkt des Vorgangs -- nachgeholte Füllung in der Sperre verworfen, eine Minute davor bleibt",
       not a[0] and a[1] == "storniert" and a[2] == 1 and len(b[0]) == 1 and b[0][0][0] == m_f + 30 and b[1] == "gefuellt",
       f"Füllung um {_uhr(m_f + 30)} bei {preis:.6g}: Sperre ab {_uhr(m_f)} → {len(a[0])} Positionen, Order {a[1]}, Ereignis {a[2]}; "
       f"Sperre ab {_uhr(m_f + 60)} → {len(b[0])} Position (eröffnet {_uhr(b[0][0][0]) if b[0] else '—'}), Order {b[1]}")


def _probe_labor_grid(tmp, ok, LB, F) -> None:
    """Probe 8 (Grid): In der Sperre kein Grid-Kauf-Los und keine Kauf-Limits; Verkäufe (Verkleinern) und Grid Short gehen weiter."""
    import copy
    db = os.path.join(tmp, "grid_nb_m.db"); T0 = 1_790_006_400 - 13 * 86_400
    LB._grid_markt(db, T0, 12)
    nur = ("grid_long", "grid_short")
    sp = os.path.join(tmp, "grid_nb_b.db"); spa = os.path.join(tmp, "grid_nb_a.db"); nb = os.path.join(tmp, "grid_nb_nb.db")
    F.store_connect(sp).close()
    t_von = T0 + 7 * 86_400; T_A = t_von + 2 * 3600; s = t_von + 10 * 3600; e = s + 4 * 3600; t_bis = t_von + 86_400
    _nb_schreiben(nb, t_von - 3600, t_bis + 3600, lambda ts: 1 if s <= ts < e else 0)
    af = os.path.join(tmp, "grid_nb_af.db")
    L = LB.Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=af); LA = None
    t = t_von
    while t < t_bis:
        L.zyklus(t)
        if LA is not None:
            LA.zyklus(t, E_von=L.letzte)
        elif t >= T_A:
            start, _neu = welt_a_anlegen(sp, spa, t, {})
            LA = LB.Labor(db, spa, coins=("GRD",), nur=nur, adressfluss=af, welt="A", tor=Tor(nb, "A", welt_start=start)); LA.z = copy.deepcopy(L.z)
        t += 120
    sid = {s_["regeln"]["richtung"]: s_["sid"] for s_ in LA.grid_strategien}
    sa = sqlite3.connect(spa); sb = sqlite3.connect(sp)
    q_auf = "SELECT COUNT(*) FROM labor_position WHERE sid=? AND eroeffnet>=? AND eroeffnet<?"
    q_zu = "SELECT COUNT(*) FROM labor_position WHERE sid=? AND geschlossen>=? AND geschlossen<? AND grund_aus LIKE 'Grid-Ziel%'"
    la_auf = sa.execute(q_auf, (sid["long"], s, e)).fetchone()[0]; lb_auf = sb.execute(q_auf, (sid["long"], s, e)).fetchone()[0]
    la_zu = sa.execute(q_zu, (sid["long"], s, e)).fetchone()[0]
    sha = sa.execute(q_auf, (sid["short"], s, e)).fetchone()[0]; shb = sb.execute(q_auf, (sid["short"], s, e)).fetchone()[0]
    o_neu = sa.execute("SELECT COUNT(*) FROM labor_order WHERE sid=? AND erstellt>=? AND erstellt<?", (sid["long"], s, e)).fetchone()[0]
    o_st = sa.execute("SELECT COUNT(*) FROM labor_order WHERE sid=? AND status='storniert' AND erledigt>=? AND erledigt<?", (sid["long"], s, s + 300)).fetchone()[0]
    nach = sa.execute(q_auf, (sid["long"], e, t_bis)).fetchone()[0]
    sa.close(); sb.close()
    ok("Probe 8 (Grid): in der Sperre kein Grid-Kauf-Los, Kauf-Limits storniert; Verkäufe und Grid Short laufen",
       la_auf == 0 and lb_auf >= 1 and la_zu >= 1 and sha >= 1 and sha == shb and o_neu == 0 and o_st >= 1 and nach >= 1,
       f"Grid Long in der Sperre: Welt A {la_auf} Käufe (B {lb_auf}), {la_zu} Verkäufe, {o_neu} neue Kauf-Limits, {o_st} storniert; Grid Short "
       f"A {sha} / B {shb} Verkaufs-Lose; nach der Sperre kauft Grid Long wieder ({nach} Lose)")


# --------------------------------------------------------------------------------------------- Prüfung des Tors im Labor-Code (KONZEPT 10.3)
def tor_statisch(pfad: str | None = None) -> list:
    """Liest hl_labor.py mit ast (nicht den eigenen Quelltext): Positionen nur über _eroeffnen, _eroeffnen ruft das Tor, jeder Eintrag in
    labor_order und labor_akku_kauf und jeder Grid-Kauf steht hinter dem Tor. -> Liste der Befunde (leer = in Ordnung)"""
    if pfad is None:
        import hl_labor
        pfad = hl_labor.__file__
    baum = ast.parse(open(pfad, encoding="utf-8").read())
    klasse = next((n for n in baum.body if isinstance(n, ast.ClassDef) and n.name == "Labor"), None)
    if klasse is None:
        return ["Klasse Labor fehlt"]
    meth = {f.name: f for f in klasse.body if isinstance(f, ast.FunctionDef)}

    def texte(f):
        out = []
        for n in ast.walk(f):
            if isinstance(n, ast.Constant) and isinstance(n.value, str):
                out.append(n.value)
        return " ".join(out)

    def aufrufe(f):
        out = set()
        for n in ast.walk(f):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
                v = n.func.value
                if isinstance(v, ast.Name) and v.id == "self":
                    out.add(n.func.attr)
                elif isinstance(v, ast.Attribute) and isinstance(v.value, ast.Name) and v.value.id == "self" and v.attr == "tor":
                    out.add(f"tor.{n.func.attr}")
        return out

    def tor(f):
        a = aufrufe(f)
        return "_tor" in a or "tor.darf" in a
    befunde = []
    for name, f in meth.items():
        if "INSERT INTO labor_position" in texte(f) and name != "_eroeffnen":
            befunde.append(f"{name}: legt Positionen an, nicht über _eroeffnen")
    if "_eroeffnen" not in meth or "_tor" not in aufrufe(meth["_eroeffnen"]):
        befunde.append("_eroeffnen ruft das Tor nicht")
    helfer = {"_grid_order", "_grid_los_auf", "_eroeffnen"}
    for name, f in meth.items():
        if name in helfer:
            continue
        t_ = texte(f); a = aufrufe(f)
        braucht = ("INSERT INTO labor_order" in t_ or "INSERT INTO labor_akku_kauf" in t_ or a & helfer)
        if braucht and not tor(f):
            befunde.append(f"{name}: Order, Kauf oder Position ohne Tor")
    return befunde


def _probe_sigma(ok) -> None:
    """σ: die Regel je Tag (Dienst) und die Regel für Reihen (Kalibrierung, Rückblick) geben dasselbe; der laufende Tag geht nie ein
    (eigene Probe zu KONZEPT 10.2: ein Schock am Tag D verändert das σ des Tages D nicht -- in beiden Rechenwegen)."""
    rng = np.random.default_rng(1); t0 = 1_786_000_000 // TAG * TAG; n = 40 * 96
    c = 100 * np.exp(np.cumsum(rng.standard_t(3, n) * 0.002)); c2 = 50 * np.exp(np.cumsum(rng.standard_t(3, n) * 0.001))
    ts = t0 + 900 * np.arange(n); D = t0 + 35 * TAG
    s1 = sigma_aus_kerzen({"a": (ts, c), "b": (ts, c2)}, D, 30, None, {"g": ["a", "b"]})
    s2 = sigma_reihe(t0, {"a": c, "b": c2}, [D], 30, None, {"g": ["a", "b"]})[D]
    ok("σ: Regel je Tag = Regel für Reihen (je Klasse, mit Untergrenze)", all(abs((s1[k][0] or 0) - s2.get(k, 0)) < 1e-18 for k in s1) and len(s1) == 4,
       " · ".join(f"{k[0]}/{k[1]} {math.sqrt(15 * s1[k][0]) * 100:.3f} %" for k in sorted(s1)))
    k_d = (D - t0) // 900                                                  # ab 00:00 des Tages D: Schock und wilde Schwankung
    cs, c2s = c.copy(), c2.copy()
    cs[k_d:] *= np.exp(np.cumsum(rng.standard_t(3, n - k_d) * 0.03)) * 0.7; c2s[k_d:] *= 0.6
    s1s = sigma_aus_kerzen({"a": (ts, cs), "b": (ts, c2s)}, D, 30, None, {"g": ["a", "b"]})
    s2s = sigma_reihe(t0, {"a": cs, "b": c2s}, [D], 30, None, {"g": ["a", "b"]})[D]
    ok("σ ohne den laufenden Tag: ein Schock am Tag D ändert das σ des Tages D nicht (beide Rechenwege)",
       all(s1s[k][0] == s1[k][0] for k in s1) and all(s2s.get(k) == s2.get(k) for k in s2),
       f"vorher a/S {math.sqrt(15 * s1[('a', 'S')][0]) * 100:.4f} %, mit Schock am Tag D {math.sqrt(15 * s1s[('a', 'S')][0]) * 100:.4f} %")


def _probe_freigabe_y(ok) -> None:
    """Eigene Probe zu KONZEPT 10.2: Die Freigabe prüft X und G(K, 60), nicht Y -- ein kurzes 5-min-Zucken von Y nach 3 h Sperre hält die
    Freigabe nicht auf."""
    th = dict(START); t0 = 1_800_000_000
    erg = {}
    for fall, zucken in (("ohne", False), ("mit", True)):
        M = Maschine(); st = []
        for k in range(480):
            x = START["theta1"] - 0.3 if k < 180 else 0.0                    # 3 h Sperre über X, dann ruhig
            y = -2.0 if (zucken and 280 <= k < 285) else 0.0                # kurz vor der Freigabe: Y zuckt 5 min unter θ1/2 (keine Stufe 2)
            st.append(M.schritt(t0 + 60 * k, {"X": x, "Y": y, "lam": 0.2, "GK60": x}, th)["stufe"])
        erg[fall] = next(k for k in range(180, 480) if st[k] == 0)
    ok("Freigabe über X und G(K, 60), nicht über Y: ein 5-min-Zucken von Y nach 3 h Sperre hält sie nicht auf", erg["ohne"] == erg["mit"],
       f"frei nach Minute {erg['ohne']} ohne, {erg['mit']} mit Zucken")


def _probe_netz(tmp: str, ok) -> None:
    """Gespeicherte Antworten im Format der Doku (KONZEPT 4.2: „die Sandbox prüft mit gespeicherten Antworten“): Korb aus metaAndAssetCtxs
    (Haupt-Dex, OI · Kurs, ohne PAXG und Spot-Namen), XMR über perpDexs/meta auf „felix“, Aktien aus metaAndAssetCtxs „xyz“; Mids je Dex
    (allMids, Schlüssel mit und ohne Präfix); Historie über candleSnapshot (15 min nach nb_kerze15, 1 min nach nb_preis, offene Kerze nicht)
    mit Gewichtsbudget (Mittel höchstens 40 je Minute) und Pause nach 429."""
    t = int(datetime(2026, 10, 23, 0, 10, tzinfo=UTC).timestamp())
    uhr = {"t": float(t)}
    main_uni = [{"name": n} for n in ("BTC", "ETH", "HYPE", "ZEC", "PAXG", "SOL", "XRP", "DOGE", "@107", "SUI", "LINK", "AVAX", "kPEPE", "TRUMP")]
    oi = {"BTC": 30000, "ETH": 500000, "HYPE": 9e6, "ZEC": 2e5, "PAXG": 9e5, "SOL": 4e6, "XRP": 3e8, "DOGE": 4e9, "@107": 9e12, "SUI": 2e8, "LINK": 2e7,
          "AVAX": 1e7, "kPEPE": 3e9, "TRUMP": 1e6}
    px = {"BTC": 81500.0, "ETH": 3000.0, "HYPE": 40.0, "ZEC": 300.0, "PAXG": 4100.0, "SOL": 180.0, "XRP": 2.5, "DOGE": 0.2, "@107": 1.0, "SUI": 3.0,
          "LINK": 15.0, "AVAX": 25.0, "kPEPE": 0.01, "TRUMP": 8.0}
    xyz_uni = [{"name": f"xyz:{k}"} for k in ("SP500", "XYZ100", "NVDA", "MSFT", "AAPL", "AMZN", "GOOGL", "META", "AVGO", "TSLA", "LLY", "MU", "VIX", "MSTR")]
    abrufe: list = []
    zaehler = {"429": 0}

    def kerzen(coin, iv, start_ms, end_ms):
        schritt = 900_000 if iv == "15m" else 60_000
        a = max(start_ms, end_ms - 5000 * schritt) // schritt * schritt
        return [{"t": k, "T": k + schritt - 1, "s": coin, "i": iv, "o": "1.0", "h": "1.1", "l": "0.9", "c": f"{1 + (k // schritt) % 7 / 100:.2f}",
                 "v": "10", "n": 3} for k in range(a, end_ms + schritt, schritt)]           # die letzte Kerze ist noch offen

    def http(body):
        abrufe.append(dict(body, _uhr=uhr["t"])); typ = body.get("type"); dx = body.get("dex")
        if typ == "candleSnapshot" and body["req"]["coin"] == "xyz:MU" and zaehler["429"] == 0:
            zaehler["429"] += 1
            return None, "HTTP 429", 429
        if typ == "metaAndAssetCtxs" and not dx:
            return [{"universe": main_uni}, [{"openInterest": str(oi[a["name"]]), "markPx": str(px[a["name"]]), "midPx": str(px[a["name"]])}
                                             for a in main_uni]], None, 200
        if typ == "metaAndAssetCtxs" and dx == "xyz":
            return [{"universe": xyz_uni}, [{"markPx": "100.0", "midPx": "100.5", "oraclePx": "100.0", "openInterest": "1000"} for _ in xyz_uni]], None, 200
        if typ == "perpDexs":
            return [None, {"name": "xyz", "fullName": "XYZ"}, {"name": "felix", "fullName": "Felix"}], None, 200
        if typ == "meta" and dx == "felix":
            return {"universe": [{"name": "felix:XMR", "szDecimals": 2}]}, None, 200
        if typ == "meta":
            return {"universe": []}, None, 200
        if typ == "allMids" and not dx:
            return {k: str(v) for k, v in px.items()}, None, 200
        if typ == "allMids" and dx == "xyz":
            return {a["name"]: "101.0" for a in xyz_uni}, None, 200
        if typ == "allMids" and dx == "felix":
            return {"XMR": "345.6"}, None, 200                                  # Schlüssel ohne Präfix: wird auch erkannt
        if typ == "candleSnapshot":
            r = body["req"]
            return kerzen(r["coin"], r["interval"], r["startTime"], r["endTime"]), None, 200
        return None, f"unbekannt {typ}", 400
    D = Dienst(os.path.join(tmp, "netz_m.db"), nb=os.path.join(tmp, "netz_nb.db"), http=http, uhr=lambda: uhr["t"], log=lambda s_: None,
               termine_datei=os.path.join(tmp, "netz_termine.json"))
    sqlite3.connect(D.db_main).executescript("CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, "
                                             "volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));")
    k = D.korb_bestimmen(t)
    m = D.mids_holen(t)
    ok("Antworten der API (gespeichert): Korb, Dex von XMR, Mids je Dex",
       k["K"][:5] == ["BTC", "ETH", "HYPE", "ZEC", "XMR"] and "PAXG" not in k["K"] and "@107" not in k["K"] and len(k["K"]) == K_MAX
       and k["K"][5:] == ["DOGE", "XRP", "SOL", "SUI", "LINK"] and k["dex"].get("XMR") == "felix" and len(k["A"]) == 12 and "xyz:VIX" in k["anzeige"]
       and "xyz:MSTR" not in k["A"] + k["anzeige"] and m.get("XMR") == 345.6 and m.get("xyz:SP500") == 101.0 and m.get("BTC") == 81500.0
       and len(m) == len(set(k["K"] + k["A"] + k["anzeige"])),
       f"K {k['K']}, Dex {k['dex']}, A {len(k['A'])}, Anzeige {k['anzeige']}; Mids {len(m)} (XMR {m.get('XMR')}, SP500 {m.get('xyz:SP500')})")
    gewicht: list = []
    for schritt in range(400):                                                 # 400 Minuten Takt, Historie im Rest jeder Minute
        uhr["t"] = float(t + 60 * schritt + 5)
        n = D.historie_schritt(t + 60 * schritt, t + 60 * schritt + 45)
        gewicht.append(sum(g[1] for g in D.gewicht if g[2] == "hist" and uhr["t"] - g[0] < 60) if n else 0)
        if (meta_lesen(D.con, "historie") or {}).get("fertig"):
            break
    h = meta_lesen(D.con, "historie") or {}
    n15 = D.con.execute("SELECT COUNT(DISTINCT inst), COUNT(*), MAX(ts) FROM nb_kerze15").fetchone()
    n1 = D.con.execute("SELECT COUNT(DISTINCT inst), MAX(ts) FROM nb_preis").fetchone()
    snaps = [a for a in abrufe if a.get("type") == "candleSnapshot"]
    abruf_zeit = {(a["req"]["coin"], a["req"]["interval"]): a["_uhr"] for a in snaps}             # der letzte (erfolgreiche) Abruf je Instrument
    offen = []                                                                 # keine Kerze, die zur Zeit ihres Abrufs noch offen war
    for inst, mx in D.con.execute("SELECT inst, MAX(ts) FROM nb_kerze15 GROUP BY inst"):
        if mx + 900 > abruf_zeit.get((D._name_api(inst)[0], "15m"), 0):
            offen.append(("15m", inst))
    for inst, mx in D.con.execute("SELECT inst, MAX(ts) FROM nb_preis GROUP BY inst"):
        if mx > abruf_zeit.get((D._name_api(inst)[0], "1m"), 0):
            offen.append(("1m", inst))
    dauer_min = schritt + 1
    mittel = sum(20 + math.ceil(len(kerzen(a["req"]["coin"], a["req"]["interval"], a["req"]["startTime"], a["req"]["endTime"])) / 60) for a in snaps) / max(dauer_min, 1)
    insts = len(set(k["K"] + k["A"] + k["anzeige"]))
    ok("Historie über candleSnapshot: 15-min-Schlüsse und 1-min-Kurse, offene Kerze nicht, Budget im Mittel ≤ 40 je Minute, Pause nach 429",
       h.get("fertig") and n15[0] == insts and n1[0] == insts and not offen and mittel <= GEWICHT_HISTORIE_MIN + 1e-9
       and zaehler["429"] == 1 and "xyz:MU" in h.get("15m", []),
       f"{len(snaps)} Abfragen in {dauer_min} min (Gewicht im Mittel {mittel:.1f} je Minute), 15 min: {n15[0]} Instrumente / {n15[1]} Schlüsse "
       f"(jüngster {_uhr(n15[2])}), 1 min: {n1[0]} Instrumente; offene Kerzen {offen[:3] or 'keine'}; 429 einmal, danach nachgeholt")


GRUPPEN_PROBEN = ("sigma", "maschine", "zeitstempel", "zeitklassen", "kalibrierung", "markt", "labor", "tor", "termine", "netz")


def selbsttest(verbose: bool = True, nur: tuple | None = None) -> bool:
    """Alle Proben (KONZEPT 10.1, außer 12 und 13: Ebene B kommt mit U207); nur: einzelne Gruppen (Mutationen, Fehlersuche)."""
    import tempfile
    import shutil
    pruef = []
    nur = tuple(nur or GRUPPEN_PROBEN)

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_notbremse_test_")
    alt_env = {k: os.environ.get(k) for k in ("HL_NOTBREMSE_DB", "HL_LABOR_A_DB", "HL_NOTBREMSE_TERMINE")}
    t_start = time.time()
    if verbose:
        print("Notbremse -- Selbsttest (KONZEPT_Notbremse.md 10: Proben 1–11, 14–17, Prüfung des Tors)"
              + ("" if nur == GRUPPEN_PROBEN else f" -- nur {', '.join(nur)}"), flush=True)
    try:
        if "sigma" in nur:
            _probe_sigma(ok)
        if "maschine" in nur:
            _probe_maschine(ok)
            _probe_freigabe_y(ok)
        if "zeitstempel" in nur:
            _probe_zeitstempel(tmp, ok)
        if "zeitklassen" in nur:
            _probe_zeitklassen(ok)
        if "kalibrierung" in nur:
            _probe_kalibrierung(ok)
        if "markt" in nur:
            _probe_markt(tmp, ok)
        if "labor" in nur:
            _probe_labor(tmp, ok)
        if "tor" in nur:
            bef = tor_statisch()
            ok("Prüfung des Tors (ast über hl_labor.py)", not bef, "; ".join(bef) or "Positionen nur über _eroeffnen, _eroeffnen ruft das Tor, "
               "Orders, Käufe und Grid-Käufe hinter dem Tor")
        if "netz" in nur:
            _probe_netz(tmp, ok)
        if "termine" in nur:
            p_t = os.path.join(tmp, "termine.json")
            with open(p_t, "w", encoding="utf-8") as f:
                json.dump([{"name": "US-Wahlnacht", "start": "2026-11-03T23:00Z", "ende": "2026-11-04T08:00Z"}, {"name": "kaputt", "start": "gestern"}], f)
            tl, tf = termine_lesen(p_t)
            ok("Termine lesen (UTC), ungültige genannt", len(tl) == 1 and tl[0]["start"] == int(datetime(2026, 11, 3, 23, tzinfo=UTC).timestamp())
               and tf and "kaputt" in tf, f"{tl} · {tf}")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-600:].replace("\n", " | "))
    finally:
        for k, v in alt_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description="Notbremse (U206): marktweite Long-Sperre bei Schocks")
    p.add_argument("--db", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db"), help="Hauptdatenbank (hl_liq.db)")
    p.add_argument("--status", action="store_true", help="Zustand, Schwellen, Episoden als Text")
    p.add_argument("--selbsttest", action="store_true", help="Proben 1–11, 14–17 und die Prüfung des Tors (temporäre Dateien, kein Netz)")
    p.add_argument("--nur", default="", help="mit --selbsttest: nur diese Gruppen, z. B. markt,labor (" + ", ".join(GRUPPEN_PROBEN) + ")")
    args = p.parse_args()
    if args.selbsttest:
        nur = tuple(x.strip() for x in args.nur.split(",") if x.strip()) or None
        if nur and any(x not in GRUPPEN_PROBEN for x in nur):
            sys.exit(f"unbekannte Gruppe: {', '.join(x for x in nur if x not in GRUPPEN_PROBEN)}")
        sys.exit(0 if selbsttest(nur=nur) else 1)
    if args.status:
        print(status_text(args.db)); return
    Dienst(args.db).lauf()


if __name__ == "__main__":
    main()
