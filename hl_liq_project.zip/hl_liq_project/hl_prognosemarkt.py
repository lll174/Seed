#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prognosemärkte (U235): Kalshi, Polymarket und Hyperliquid HIP-4 als Daten.

Archiv mit Abrufzeit, Rückblick auf abgelaufene Märkte, vorab festgelegte Auswertung
(KONZEPT_Prognosemaerkte.md). Nur lesen: kein Konto, kein Schlüssel, kein Handel.
Wirkt auf nichts im übrigen System (Konzept 9).

Aufbau dieser Datei:
  1. Zeit und Kennungen (ET mit Sommerzeit, Polymarket-Slugs, Kalshi-Ticker)
  2. Zahlen (Festkomma-Preise; einseitige Bücher ungültig)
  3. Parser je Plattform (tolerant; der Erstlauf auf dem Pi prüft die echten Formate)
  4. Leiter -> Verteilung (isotone Regression, Klassen auf dem Veröffentlichungsraster, Median, Streuung)
  5. Spotmodell (driftfrei in der Log-Rendite), Spotreihe und HAR-Schwankung (Nachtrag R9)
  6. Statistik (Brier-Zugewinn, Ränge, Spearman mit Permutation, Kalibrierung)
  7. Speicher prognosemarkt.db (BEGIN IMMEDIATE; gleiche Werte erzeugen keine Zeile; Ergebnisse als Fassungen)
  8. Abruf (Takt je Quelle, Pausen, Protokoll; Hyperliquid mit eigenem Deckel von 20 Gewicht je Minute, Nachtrag 13.2)
  9. Reihen, Familien, Live-Takt (23.89, U236: HIP-4 nach Gewichtsplan und nur Krypto-Preisbinäre der Projekt-Coins;
     Polymarket-Kennungen ohne Orderbuch ruhen; KONZEPT_Prognosemaerkte.md Nachtrag 13.4)
 10. Rückblick in Schritten mit Cursor (wartet auf den Stichtag aus dem Erstlauf)
 11. Auswertung H1–H3 nach Nachtrag 13.1: Zählung bis zur Freigabe, Prüfungen vor dem Urteil, ein gemeinsames Urteil
 12. Berichte und Nutzlast (Spot-Echo nur zur Anzeige, Nachtrag 13.2)
 13. Selbsttest und Mutationen
 14. Erstlauf, Dienst-Thread (aus mit HL_PM=0), Befehlszeile
"""

from __future__ import annotations

import contextlib
import functools
import json
import math
import os
import random
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from array import array
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

UTC = timezone.utc
ET = ZoneInfo("America/New_York")

# Mutationsschalter für den Selbsttest (Konzept 8.2). Im Betrieb immer None.
_MUT: str | None = None
_ET_FEST = timezone(timedelta(hours=-4))  # nur für die Mutation „ET mit festem Versatz“

# ---------------------------------------------------------------------------
# 1. Zeit und Kennungen
# ---------------------------------------------------------------------------

MONATE_EN = ["january", "february", "march", "april", "may", "june", "july",
             "august", "september", "october", "november", "december"]
MONATE_KALSHI = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

# Polymarket-Kurznamen in berechneten Auf/Ab-Slugs und Langnamen in Text-Slugs.
PM_KURZ = {"BTC": "btc", "ETH": "eth", "HYPE": "hype", "SOL": "sol", "XRP": "xrp"}
PM_LANG = {"BTC": "bitcoin", "ETH": "ethereum", "HYPE": "hyperliquid", "SOL": "solana", "XRP": "xrp"}


def utc_ts(dt: datetime) -> int:
    """Unix-Sekunden eines zeitzonenbehafteten Zeitpunkts."""
    if dt.tzinfo is None:
        raise ValueError("Zeitpunkt ohne Zeitzone")
    return int(dt.timestamp())


def von_ts(ts: float) -> datetime:
    return datetime.fromtimestamp(ts, UTC)


def et(ts: float) -> datetime:
    """Unix-Sekunden -> Ortszeit New York (mit Sommerzeit)."""
    return datetime.fromtimestamp(ts, _ET_FEST if _MUT == "et_fester_versatz" else ET)


def et_zu_ts(jahr: int, monat: int, tag: int, stunde: int = 0, minute: int = 0) -> int:
    """Wandzeit New York -> Unix-Sekunden. Mehrdeutige Stunde (Rückstellung) = erste Stunde (fold=0)."""
    zone = _ET_FEST if _MUT == "et_fester_versatz" else ET
    return utc_ts(datetime(jahr, monat, tag, stunde, minute, tzinfo=zone))


def fenster_beginn(ts: float, laenge_s: int) -> int:
    """Beginn des UTC-Rasterfensters (15 min = 900 s), in dem ts liegt."""
    return int(ts) - int(ts) % laenge_s


def et_4h_beginn(ts: float) -> int:
    """Beginn des 4-h-Fensters im Raster der New-Yorker Wandzeit (0, 4, 8, 12, 16, 20 Uhr ET)."""
    t = et(ts)
    h = t.hour - t.hour % 4
    return et_zu_ts(t.year, t.month, t.day, h, 0)


def pm_slug_updown(coin: str, art: str, beginn_ts: int) -> str:
    """Berechneter Slug der wiederkehrenden Polymarket-Auf/Ab-Märkte (15m, 4h; 5m wird nie genutzt).

    Die Zahl ist der Fensterbeginn in Unix-Sekunden (Recherche 27.10., aus Beispielen abgeleitet)."""
    erlaubt = ("15m", "4h", "5m") if _MUT == "fuenf_min_zugelassen" else ("15m", "4h")
    if art not in erlaubt:
        raise ValueError("nur 15m und 4h haben berechnete Slugs (5m nie, Regel 1.4)")
    return f"{PM_KURZ[coin]}-updown-{art}-{int(beginn_ts)}"


def _stunde12(h: int) -> str:
    h12 = h % 12 or 12
    return f"{h12}{'am' if h < 12 else 'pm'}"


def pm_slug_stunde(coin: str, beginn_ts: int) -> str:
    """Stündlicher Auf/Ab-Markt, z. B. 'bitcoin-up-or-down-september-26-2026-9pm-et' (Beginn der Stunde in ET)."""
    t = et(beginn_ts)
    return f"{PM_LANG[coin]}-up-or-down-{MONATE_EN[t.month - 1]}-{t.day}-{t.year}-{_stunde12(t.hour)}-et"


def pm_slug_tag(coin: str, tag: date) -> str:
    """Täglicher Auf/Ab-Markt, z. B. 'bitcoin-up-or-down-on-september-2-2026'."""
    return f"{PM_LANG[coin]}-up-or-down-on-{MONATE_EN[tag.month - 1]}-{tag.day}-{tag.year}"


def pm_slug_ueber(coin: str, tag: date) -> str:
    """Tägliche Schwellenleiter, z. B. 'bitcoin-above-on-october-27-2026'."""
    return f"{PM_LANG[coin]}-above-on-{MONATE_EN[tag.month - 1]}-{tag.day}-{tag.year}"


def pm_slug_beruehrt_tag(coin: str, tag: date) -> str:
    return f"what-price-will-{PM_LANG[coin]}-hit-on-{MONATE_EN[tag.month - 1]}-{tag.day}-{tag.year}"


def pm_slug_beruehrt_monat(coin: str, jahr: int, monat: int) -> str:
    return f"what-price-will-{PM_LANG[coin]}-hit-in-{MONATE_EN[monat - 1]}-{jahr}"


def pm_slug_beruehrt_jahr(coin: str, jahr: int) -> str:
    return f"what-price-will-{PM_LANG[coin]}-hit-before-{jahr + 1}"


_KALSHI_DATUM = re.compile(r"^(\d{2})([A-Z]{3})(\d{2})(\d{2})?(\d{2})?$")


def kalshi_ticker_zerlegen(ticker: str) -> dict:
    """Zerlegt 'KXBTC15M-26OCT271200-00', 'KXBTCD-26MAY0817-T64499.99', 'KXCPI-25APR', 'KXBTCY-27JAN0100-B107500'.

    Gibt Reihe, Ereignis, Termin in ET (falls ablesbar, als Unix-Sekunden) und die Schwelle (Art T/B) zurück.
    Nur Gegenprobe zu den API-Feldern floor_strike/cap_strike/close_time, nie alleinige Quelle."""
    teile = ticker.split("-")
    aus = {"reihe": teile[0], "ereignis": "-".join(teile[:2]) if len(teile) > 1 else teile[0],
           "termin_ts": None, "schwelle_art": None, "schwelle": None}
    if len(teile) > 1:
        m = _KALSHI_DATUM.match(teile[1])
        if m:
            jj, mon, tt, hh, mm = m.groups()
            if mon in MONATE_KALSHI:
                try:
                    aus["termin_ts"] = et_zu_ts(2000 + int(jj), MONATE_KALSHI.index(mon) + 1, int(tt),
                                                int(hh) if hh else 0, int(mm) if mm else 0)
                except ValueError:
                    aus["termin_ts"] = None
                aus["termin_genau"] = hh is not None
    if len(teile) > 2:
        s = teile[2]
        if s[:1] in ("T", "B"):
            try:
                aus["schwelle_art"] = s[0]
                aus["schwelle"] = float(s[1:])
            except ValueError:
                aus["schwelle_art"] = None
    return aus


# ---------------------------------------------------------------------------
# 2. Zahlen
# ---------------------------------------------------------------------------

def preis(x) -> int | None:
    """Preis in 1/10.000 $ als ganze Zahl. Akzeptiert '0.5600', 0.56, Decimal; None/'' -> None.

    Kalshi liefert Festkomma-Zeichenketten (seit 07/2026 auch Teilcent); Polymarket Zahlen oder Texte."""
    if x is None or x == "":
        return None
    try:
        d = Decimal(str(x))
    except (InvalidOperation, ValueError):
        return None
    if d.is_nan() or d < 0 or d > 1:
        return None
    return int((d * 10000).to_integral_value())


def preis_cent(x) -> int | None:
    """Älteres Kalshi-Format in Cent (ganze Zahl 0..100) -> 1/10.000 $."""
    if x is None or x == "":
        return None
    try:
        v = Decimal(str(x))
    except (InvalidOperation, ValueError):
        return None
    if v < 0 or v > 100:
        return None
    return int((v * 100).to_integral_value())


def zahl(x) -> float | None:
    if x is None or x == "":
        return None
    try:
        v = float(Decimal(str(x)))
    except (InvalidOperation, ValueError):
        return None
    return v if math.isfinite(v) else None


def mitte(geld: int | None, brief: int | None, max_spread: int = 400) -> int | None:
    """Mitte aus Geld und Brief (1/10.000 $); None, wenn eine Seite fehlt oder der Spread zu weit ist (Konzept 6.1)."""
    if geld is None or brief is None or brief < geld or geld <= 0 or brief >= 10000:
        return None
    if brief - geld > max_spread and _MUT != "spread_filter_aus":
        return None
    return (geld + brief) // 2 if (geld + brief) % 2 == 0 else int(round((geld + brief) / 2))


def iso_ts(s) -> int | None:
    """ISO-8601 ('2026-10-27T16:00:00Z', mit Bruchteilen) -> Unix-Sekunden."""
    if not s:
        return None
    if isinstance(s, (int, float)):
        return int(s)
    t = str(s).strip().replace("Z", "+00:00")
    t = re.sub(r"(\.\d{6})\d+", r"\1", t)  # Nanosekunden kürzen (fromisoformat kennt höchstens 6 Stellen)
    try:
        dt = datetime.fromisoformat(t)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return int(dt.timestamp())


# ---------------------------------------------------------------------------
# 3. Parser
# ---------------------------------------------------------------------------

def _erstes(d: dict, *namen):
    for n in namen:
        if isinstance(d, dict) and d.get(n) not in (None, ""):
            return d.get(n)
    return None


def kalshi_markt(d: dict) -> dict:
    """Ein Markt aus /markets oder /historical/markets, vereinheitlicht."""
    ticker = d.get("ticker")
    z = kalshi_ticker_zerlegen(ticker or "")
    geld = preis(_erstes(d, "yes_bid_dollars"))
    if geld is None and d.get("yes_bid") is not None:
        geld = preis_cent(d.get("yes_bid"))
    brief = preis(_erstes(d, "yes_ask_dollars"))
    if brief is None and d.get("yes_ask") is not None:
        brief = preis_cent(d.get("yes_ask"))
    letzter = preis(_erstes(d, "last_price_dollars"))
    if letzter is None and d.get("last_price") is not None:
        letzter = preis_cent(d.get("last_price"))
    ergebnis = (d.get("result") or "").lower()
    return {
        "plattform": "kalshi",
        "markt": ticker,
        "ereignis": d.get("event_ticker") or z["ereignis"],
        "reihe": (d.get("series_ticker") or z["reihe"] or "").upper(),
        "titel": d.get("title") or d.get("yes_sub_title") or "",
        "untertitel": d.get("yes_sub_title") or d.get("subtitle") or "",
        "status": d.get("status"),
        "strike_typ": d.get("strike_type"),
        "unten": zahl(d.get("floor_strike")),
        "oben": zahl(d.get("cap_strike")),
        "beginn": iso_ts(d.get("open_time")),
        "ende": iso_ts(_erstes(d, "close_time", "expected_expiration_time")),
        "ablauf": iso_ts(_erstes(d, "expiration_time", "latest_expiration_time", "expected_expiration_time")),
        "regeln": d.get("rules_primary") or "",
        "geld": geld,
        "brief": brief,
        "letzter": letzter,
        "oi": zahl(_erstes(d, "open_interest_fp", "open_interest")),
        "volumen": zahl(_erstes(d, "volume_fp", "volume")),
        "ergebnis": 1 if ergebnis == "yes" else (0 if ergebnis == "no" else None),
        "ergebnis_roh": ergebnis or None,
        "wert": zahl(d.get("expiration_value")),
        "ticker_termin": z.get("termin_ts"),
    }


def _ohlc_schluss(teil) -> int | None:
    """Schlusswert eines OHLC-Teils einer Kalshi-Kerze, tolerant gegenüber Feldnamen (Dollar oder Cent)."""
    if not isinstance(teil, dict):
        return None
    v = preis(_erstes(teil, "close_dollars", "close_price_dollars"))
    if v is None:
        c = _erstes(teil, "close", "close_price")
        if c is not None:
            v = preis(c) if isinstance(c, str) and "." in c else preis_cent(c)
    return v


def kalshi_kerzen(d: dict, periode_s: int = 60) -> list[dict]:
    """Kerzen aus /candlesticks: Ende der Periode (Unix), Geld/Brief/Preis zum Schluss, Volumen, OI.

    Semantik (Nachtrag R1): Eine Kerze mit Ende t umfasst (t − Periode, t]; ihr Schluss ist der letzte Wert bis t. Gespeichert
    wird t, das Ende."""
    aus = []
    for k in d.get("candlesticks") or []:
        t = k.get("end_period_ts")
        if t is None:
            continue
        if _MUT == "kerze_beginn_kalshi":
            t = int(t) - periode_s
        aus.append({
            "ts": int(t),
            "geld": _ohlc_schluss(k.get("yes_bid")),
            "brief": _ohlc_schluss(k.get("yes_ask")),
            "preis": _ohlc_schluss(k.get("price")),
            "volumen": zahl(_erstes(k, "volume_fp", "volume")),
            "oi": zahl(_erstes(k, "open_interest_fp", "open_interest")),
        })
    aus.sort(key=lambda r: r["ts"])
    return aus


def _json_liste(x) -> list:
    """Polymarket liefert Listen teils als JSON-Text ('[\"Yes\",\"No\"]')."""
    if x is None:
        return []
    if isinstance(x, list):
        return x
    try:
        v = json.loads(x)
        return v if isinstance(v, list) else []
    except (TypeError, ValueError):
        return []


def gamma_markt(m: dict, ereignis: dict | None = None) -> dict:
    """Ein Markt aus Gamma (v1 mit clobTokenIds, v2 mit positionIds), vereinheitlicht.

    Die Kennung für Kurse ist die des ersten Ausgangs (Ja bzw. Auf)."""
    version = str(m.get("version") or ("v2" if m.get("positionIds") else "v1")).lower()
    if version not in ("v1", "v2"):
        version = "v2" if m.get("positionIds") else "v1"
    if _MUT == "v2_uebersehen":
        version = "v1"
        kennungen = _json_liste(m.get("clobTokenIds"))
    else:
        kennungen = _json_liste(m.get("positionIds") if version == "v2" else m.get("clobTokenIds"))
        if not kennungen:
            kennungen = _json_liste(m.get("clobTokenIds")) or _json_liste(m.get("positionIds"))
    ausgaenge = [str(a) for a in _json_liste(m.get("outcomes"))]
    # Index des Ausgangs „Ja“ bzw. „Auf“ (Reihenfolge der Listen ist nicht zugesichert)
    ja = 0
    for i, a in enumerate(ausgaenge):
        if a.strip().lower() in ("yes", "up", "ja"):
            ja = i
            break
    nein = 1 - ja if len(ausgaenge) == 2 else (1 if ja == 0 else 0)
    kurse = [zahl(p) for p in _json_liste(m.get("outcomePrices"))]
    geschlossen = bool(m.get("closed"))
    erg = None
    if geschlossen and len(kurse) >= 2 and None not in (kurse[ja], kurse[nein]):
        if kurse[ja] >= 0.99 and kurse[nein] <= 0.01:
            erg = 1
        elif kurse[ja] <= 0.01 and kurse[nein] >= 0.99:
            erg = 0
    status = m.get("resolutionStatus") or m.get("umaResolutionStatus")
    return {
        "plattform": "polymarket",
        "markt": m.get("conditionId") or m.get("id"),
        "slug": m.get("slug"),
        "ereignis": (ereignis or {}).get("slug") or m.get("eventSlug"),
        "titel": m.get("question") or (ereignis or {}).get("title") or "",
        "version": version,
        "kennung_ja": str(kennungen[ja]) if len(kennungen) > ja else None,
        "kennung_nein": str(kennungen[nein]) if len(kennungen) > nein else None,
        "ausgaenge": ausgaenge,
        "beginn": iso_ts(m.get("eventStartTime") or m.get("startDate") or (ereignis or {}).get("startDate")),
        "ende": iso_ts(m.get("endDate") or (ereignis or {}).get("endDate")),
        "geschlossen": geschlossen,
        "aufgeloest": str(status).lower() == "resolved" if status else None,
        "ergebnis": erg,
        "geld": preis(m.get("bestBid")),
        "brief": preis(m.get("bestAsk")),
        "letzter": preis(m.get("lastTradePrice")),
        "regeln": m.get("description") or (ereignis or {}).get("description") or "",
        "schwelle": zahl(m.get("groupItemThreshold")),
        "gruppe": m.get("groupItemTitle"),
    }


def gamma_ereignis(e: dict) -> list[dict]:
    return [gamma_markt(m, e) for m in (e.get("markets") or [])]


def pm_verlauf(d) -> list[tuple[int, int]]:
    """Preisverlauf: CLOB {'history':[{'t','p'}]} oder Data API v2 (Hülle mit 'data'/'history'). -> [(ts, preis)]."""
    if isinstance(d, dict):
        reihe = d.get("history")
        if reihe is None and isinstance(d.get("data"), (list, dict)):
            reihe = d["data"].get("history") if isinstance(d["data"], dict) else d["data"]
    else:
        reihe = d
    aus = []
    for p in reihe or []:
        t = p.get("t") if isinstance(p, dict) else None
        v = preis(p.get("p")) if isinstance(p, dict) else None
        if t is not None and v is not None:
            aus.append((int(t), v))
    aus.sort()
    return aus


def hip4_beschreibung(text: str) -> dict:
    """Beschreibung eines HIP-4-Ausgangs -> Felder. Drei Formate (das zweite und dritte zeigte erst der Erstlauf, U236):
    'class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d' (Krypto-Preisbinär),
    'perp:xyz:LLY|priceDescription:1-minute candle|seconds:300|threshold:1450|time:20261030-1335' (Perp eines anderen Dex,
    etwa eine Aktie; Klasse 'perpSchwelle') und 'participant:Buffalo Bills' (Teilnehmer, etwa Sport; Klasse 'teilnehmer')."""
    felder = {}
    for teil in (text or "").split("|"):
        if ":" in teil:
            k, v = teil.split(":", 1)
            felder[k.strip()] = v.strip()
    klasse, basis = felder.get("class"), felder.get("underlying")
    if not klasse and "perp" in felder:
        klasse, basis = "perpSchwelle", basis or felder["perp"].split(":")[-1]
    elif not klasse and "participant" in felder:
        klasse = "teilnehmer"
    ziel = zahl(felder.get("targetPrice")) if felder.get("targetPrice") is not None else zahl(felder.get("threshold"))
    aus = {"klasse": klasse, "basis": basis, "ziel": ziel, "periode": felder.get("period"), "ablauf": None}
    exp = felder.get("expiry") or felder.get("time")
    if exp:
        m = re.match(r"^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})$", exp)
        if m:
            j, mo, t, h, mi = (int(x) for x in m.groups())
            aus["ablauf"] = utc_ts(datetime(j, mo, t, h, mi, tzinfo=UTC))
    return aus


def hip4_ausgaenge(d) -> list[dict]:
    """outcomeMeta -> offene Ausgänge mit Kennungen für Buch ('#10·n') und Asset-ID (100.000.000 + Kodierung)."""
    liste = d.get("outcomes") if isinstance(d, dict) else d
    aus = []
    for o in liste or []:
        try:
            n = int(o.get("outcome"))
        except (TypeError, ValueError):
            continue
        b = hip4_beschreibung(o.get("description") or "")
        aus.append({"plattform": "hip4", "markt": f"#{10 * n}", "ausgang": n, "name": o.get("name"),
                    "beschreibung": o.get("description"), **b})
    return aus


def hip4_nummer(markt) -> int | None:
    """'#20' -> 2 (die Kennung des Buchs ist 10 · Ausgang)."""
    try:
        return int(str(markt)[1:]) // 10
    except (TypeError, ValueError):
        return None


HIP4_COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")   # U236: nur Krypto-Preisbinäre dieser Coins im Takt


def hip4_relevant(o: dict) -> bool:
    """U236: Bücher und Abrechnung im Takt nur für Krypto-Preisbinäre der Projekt-Coins; Aktien-Perps und Teilnehmer werden nur
    abgelegt (der eigene Deckel reicht nicht für 361 Bücher je Minute)."""
    if _MUT == "hip4_alle_buecher":
        return True
    return o.get("klasse") == "priceBinary" and str(o.get("basis") or "").upper() in HIP4_COINS


def hip4_abgerechnet(d: dict) -> dict:
    """settledOutcome -> Anteil für Ja und Abrechnungskurs (aus 'price:79980')."""
    anteil = zahl(d.get("settleFraction"))
    kurs = None
    det = str(d.get("details") or "")
    m = re.search(r"price:([0-9.]+)", det)
    if m:
        kurs = zahl(m.group(1))
    erg = None
    if anteil is not None:
        erg = 1 if anteil >= 0.999 else (0 if anteil <= 0.001 else None)
    return {"anteil": anteil, "kurs": kurs, "ergebnis": erg}


def hl_buch_mitte(d) -> tuple[int | None, int | None]:
    """l2Book {'levels':[[bids],[asks]]} -> (bestes Geld, bester Brief) in 1/10.000 (Reihenfolge nicht vorausgesetzt)."""
    try:
        bids, asks = d.get("levels")[0], d.get("levels")[1]
    except (AttributeError, TypeError, IndexError):
        return None, None
    g = [preis(e.get("px")) for e in bids or [] if isinstance(e, dict)]
    b = [preis(e.get("px")) for e in asks or [] if isinstance(e, dict)]
    g = [x for x in g if x is not None]
    b = [x for x in b if x is not None]
    return (max(g) if g else None), (min(b) if b else None)


def kalshi_buch(d: dict) -> tuple[int | None, int | None]:
    """Kalshi-Orderbuch (nur Gebote beider Seiten) -> (bestes Ja-Geld, bester Ja-Brief) in 1/10.000 $.

    Ja-Brief = 1 − bestes Nein-Gebot. Felder 'orderbook_fp' {'yes_dollars': [[preis, menge], …], 'no_dollars': …},
    älter 'orderbook' {'yes': [[cent, menge]], 'no': …}."""
    ob = (d or {}).get("orderbook_fp") or (d or {}).get("orderbook") or {}

    def beste(liste, dollar: bool):
        best = None
        for e in liste or []:
            try:
                p = preis(e[0]) if dollar else preis_cent(e[0])
            except (TypeError, IndexError, KeyError):
                continue
            if p is not None and (best is None or p > best):
                best = p
        return best
    if "yes_dollars" in ob or "no_dollars" in ob:
        ja, nein = beste(ob.get("yes_dollars"), True), beste(ob.get("no_dollars"), True)
    else:
        ja, nein = beste(ob.get("yes"), False), beste(ob.get("no"), False)
    return ja, (10000 - nein if nein is not None else None)


def pm_buch(d: dict) -> tuple[int | None, int | None]:
    """CLOB /book {'bids':[{'price','size'}], 'asks':[…]} -> (bestes Geld, bester Brief); Sortierung egal."""
    def ext(liste, f):
        w = [preis(e.get("price")) for e in liste or [] if isinstance(e, dict)]
        w = [x for x in w if x is not None]
        return f(w) if w else None
    return ext((d or {}).get("bids"), max), ext((d or {}).get("asks"), min)


def zeit(v) -> int | None:
    """Zeitangabe tolerant: Unix-Sekunden, -Millisekunden (Zahl oder Ziffernfolge) oder ISO-Text -> Unix-Sekunden."""
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)) or (isinstance(v, str) and v.strip().isdigit()):
        x = int(float(v))
        return x // 1000 if x > 10 ** 11 else x
    return iso_ts(v)


def kalshi_grenze(d: dict) -> int | None:
    """/historical/cutoff -> market_settled_ts (Unix): davor abgerechnete Märkte liegen nur unter /historical/*."""
    return zeit((d or {}).get("market_settled_ts"))


def coinbase_kerzen(d) -> list[tuple[int, float, float, float, float]]:
    """Coinbase /products/{id}/candles: [[Beginn, tief, hoch, eröffnung, schluss, volumen], …] (neueste zuerst) -> aufsteigend
    [(Beginn, o, h, l, c)]."""
    aus = []
    for k in d or []:
        try:
            aus.append((int(k[0]) - (60 if _MUT == "kerze_beginn_spot" else 0), float(k[3]), float(k[2]), float(k[1]),
                        float(k[4])))
        except (TypeError, ValueError, IndexError):
            continue
    aus.sort()
    return aus


def binance_kerzen(d) -> list[tuple[int, float, float, float, float]]:
    """Binance /klines -> [(Beginn der Minute in Unix-Sekunden, o, h, l, c)]."""
    aus = []
    for k in d or []:
        try:
            aus.append((int(k[0]) // 1000 - (60 if _MUT == "kerze_beginn_spot" else 0), float(k[1]), float(k[2]),
                        float(k[3]), float(k[4])))
        except (TypeError, ValueError, IndexError):
            continue
    return aus


# ---------------------------------------------------------------------------
# 4. Leiter -> Verteilung
# ---------------------------------------------------------------------------

def _pava_fallend(werte: list[float]) -> list[float]:
    """Isotone Regression (gleiche Gewichte): nächste fallende Folge im Sinn der kleinsten Quadrate."""
    bloecke = []  # [summe, anzahl]
    for v in werte:
        bloecke.append([v, 1])
        while len(bloecke) > 1 and bloecke[-2][0] / bloecke[-2][1] < bloecke[-1][0] / bloecke[-1][1]:
            s, n = bloecke.pop()
            bloecke[-1][0] += s
            bloecke[-1][1] += n
    aus = []
    for s, n in bloecke:
        aus.extend([s / n] * n)
    return aus


def leiter_verteilung(schwellen: list[tuple[float, float]]) -> dict | None:
    """Schwellen [(K, P(X > K))] -> monotone Überlebensfunktion, Median, 16/84-%-Punkte, Streuung.

    Ja-Preise einer 'über K'-Leiter sind (risikoneutrale) Wahrscheinlichkeiten P(X > K). Nicht monotone Werte
    (Spreads, alte Kurse) werden per isotoner Regression geglättet. Quantile linear zwischen Schwellen;
    liegt ein Quantil außerhalb der Leiter, ist es None (keine Extrapolation)."""
    pts = sorted((float(k), float(p)) for k, p in schwellen if k is not None and p is not None)
    if len(pts) < 2:
        return None
    ks = [k for k, _ in pts]
    if len(set(ks)) != len(ks):
        return None
    roh = [min(1.0, max(0.0, p)) for _, p in pts]
    ueber = roh if _MUT == "vf_nicht_monoton" else _pava_fallend(roh)

    def quantil(q: float):
        # gesucht: K mit P(X > K) = 1 − q
        ziel = 1.0 - q
        for i in range(len(ks) - 1):
            a, b = ueber[i], ueber[i + 1]
            if a >= ziel >= b:
                if a == b:
                    return (ks[i] + ks[i + 1]) / 2
                return ks[i] + (a - ziel) / (a - b) * (ks[i + 1] - ks[i])
        return None

    med = quantil(0.5)
    q16 = quantil(0.1587)
    q84 = quantil(0.8413)
    s = (q84 - q16) / 2 if (q16 is not None and q84 is not None) else None
    return {"schwellen": ks, "ueber": ueber, "median": med, "q16": q16, "q84": q84, "streuung": s,
            "geglaettet": any(abs(u - p) > 1e-12 for u, (_, p) in zip(ueber, pts))}


# ---------------------------------------------------------------------------
# 5. Spotmodell (Konzept 6.1)
# ---------------------------------------------------------------------------

def phi(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def p_auf(log_rendite_seit_beginn: float, sigma_rest: float) -> float:
    """P(Schluss ≥ Startkurs) bei driftfreier Normalverteilung der restlichen Log-Rendite.

    Vor dem Fensterbeginn (Rendite 0) genau 0,5."""
    if sigma_rest is None or sigma_rest <= 0:
        return 1.0 if log_rendite_seit_beginn > 0 else (0.0 if log_rendite_seit_beginn < 0 else 0.5)
    return phi(log_rendite_seit_beginn / sigma_rest)


def p_ueber(spot: float, schwelle: float, sigma_tau: float) -> float:
    """P(S_T > K) bei driftfreier Log-Rendite (Median = S), für alle Familien gleich (Nachtrag R9)."""
    if spot <= 0 or schwelle <= 0:
        raise ValueError("Kurs und Schwelle müssen positiv sein")
    if sigma_tau <= 0:
        return 1.0 if spot > schwelle else 0.0
    return phi(math.log(spot / schwelle) / sigma_tau)


def p_beruehrt(spot: float, schwelle: float, sigma_tau: float) -> float:
    """P(Pfad berührt K bis T) nach Spiegelung (driftfrei, stetig): 2·P(jenseits von K), höchstens 1."""
    if spot <= 0 or schwelle <= 0:
        raise ValueError("Kurs und Schwelle müssen positiv sein")
    if sigma_tau <= 0:
        return 1.0 if spot == schwelle else 0.0
    d = abs(math.log(schwelle / spot)) / sigma_tau
    return min(1.0, 2.0 * phi(-d))


# ---------------------------------------------------------------------------
# 6. Statistik (Konzept 6.2)
# ---------------------------------------------------------------------------

def brier_zugewinn(p_basis: float, p_markt: float, y: int) -> float:
    """g = (p_Basis − y)² − (p_Markt − y)²; positiv heißt: der Markt ist besser."""
    return (p_basis - y) ** 2 - (p_markt - y) ** 2


def raenge(werte: list[float]) -> list[float]:
    """Ränge mit gemittelten Gleichständen (1-basiert)."""
    idx = sorted(range(len(werte)), key=lambda i: werte[i])
    r = [0.0] * len(werte)
    i = 0
    while i < len(idx):
        j = i
        while j + 1 < len(idx) and werte[idx[j + 1]] == werte[idx[i]]:
            j += 1
        mittelrang = (i + j) / 2 + 1
        for k in range(i, j + 1):
            r[idx[k]] = mittelrang
        i = j + 1
    return r


def pearson(x: list[float], y: list[float]) -> float | None:
    n = len(x)
    if n < 3:
        return None
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    sxx = sum((a - mx) ** 2 for a in x)
    syy = sum((b - my) ** 2 for b in y)
    if sxx <= 0 or syy <= 0:
        return None
    return sxy / math.sqrt(sxx * syy)


def spearman(x: list[float], y: list[float]) -> float | None:
    if len(x) != len(y) or len(x) < 3:
        return None
    return pearson(raenge(x), raenge(y))


def spearman_permutation(x: list[float], y: list[float], ziehungen: int = 10000, saat: int = 235,
                         seite: str = "negativ") -> dict:
    """Spearman ρ mit Permutationsnull (x wird vertauscht). seite 'negativ': p für ρ < 0; 'positiv'; 'beide'."""
    rho = spearman(x, y)
    if rho is None:
        return {"rho": None, "p": None, "n": len(x)}
    rx, ry = raenge(x), raenge(y)
    rng = random.Random(saat)
    rx = list(rx)
    zaehler = 0
    for _ in range(ziehungen):
        rng.shuffle(rx)
        r = pearson(rx, ry)
        if r is None:
            continue
        if seite == "negativ" and r <= rho:
            zaehler += 1
        elif seite == "positiv" and r >= rho:
            zaehler += 1
        elif seite == "beide" and abs(r) >= abs(rho):
            zaehler += 1
    return {"rho": rho, "p": (1 + zaehler) / (1 + ziehungen), "n": len(x)}


def _logit(p: float) -> float:
    p = min(1 - 1e-4, max(1e-4, p))
    return math.log(p / (1 - p))


def kalibrierung(p: list[float], y: list[int], schritte: int = 50) -> dict:
    """Logistische Regression y ~ a + b·logit(p) (Newton); b = 1 und a = 0 heißt kalibriert."""
    n = len(p)
    if n < 20 or len(set(y)) < 2:
        return {"a": None, "b": None, "n": n}
    x = [_logit(v) for v in p]
    a, b = 0.0, 1.0
    for _ in range(schritte):
        ga = gb = haa = hab = hbb = 0.0
        for xi, yi in zip(x, y):
            z = a + b * xi
            q = 1.0 / (1.0 + math.exp(-z)) if z > -700 else 0.0
            w = q * (1 - q)
            ga += yi - q
            gb += (yi - q) * xi
            haa += w
            hab += w * xi
            hbb += w * xi * xi
        det = haa * hbb - hab * hab
        if det <= 1e-12:
            break
        da = (hbb * ga - hab * gb) / det
        db = (haa * gb - hab * ga) / det
        a += da
        b += db
        if abs(da) < 1e-9 and abs(db) < 1e-9:
            break
    return {"a": a, "b": b, "n": n}


def zuverlaessigkeit(p: list[float], y: list[int], klassen: int = 10) -> list[dict]:
    """Zuverlässigkeit in gleich breiten Klassen: mittlere Vorhersage, beobachtete Quote, Wilson-90-%-Intervall."""
    aus = []
    z = 1.6449
    for i in range(klassen):
        lo, hi = i / klassen, (i + 1) / klassen
        sel = [(pi, yi) for pi, yi in zip(p, y) if (lo <= pi < hi) or (i == klassen - 1 and pi == 1.0)]
        if not sel:
            continue
        n = len(sel)
        k = sum(yi for _, yi in sel)
        q = k / n
        den = 1 + z * z / n
        zen = (q + z * z / (2 * n)) / den
        halb = z * math.sqrt(q * (1 - q) / n + z * z / (4 * n * n)) / den
        aus.append({"klasse": i, "p": sum(pi for pi, _ in sel) / n, "quote": q, "n": n,
                    "lo": max(0.0, zen - halb), "hi": min(1.0, zen + halb)})
    return aus


# ---------------------------------------------------------------------------
# 5b. Spotreihe und kausale Schwankung (Nachtrag 13.1)
# ---------------------------------------------------------------------------

RASTER = 1800  # 30-min-Raster der Schwankung


class SpotReihe:
    """1-min-Kerzen eines Coins mit kausalen Abfragen. Kerze = (Beginn, o, h, l, c); ihr Schluss gilt bei Beginn + 60 s.

    Tagesvarianz = Mittel der realisierten 30-min-Varianz über 1, 7 und 30 Tage, nur aus Intervallen, die bis t0 abgeschlossen
    sind; für Fenster unter einem Tag zusätzlich der Tagesprofil-Faktor des 30-min-Slots (letzte 28 Tage, zu 1 geschrumpft).
    Es wird nichts geschätzt, was aus späteren Daten lernen könnte. Speicher als Felder (array), auch für Jahre an Minuten."""

    def __init__(self, kerzen=()):
        k = sorted((int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4])) for x in kerzen if x[4] is not None)
        self.n = 0
        self.g0 = 0
        self.m = 0
        self.basis = 0
        if not k:
            return
        self._anlegen(k[0][0], k[-1][0])
        for x in k:
            self._setzen(x)
        self._raster()

    def _anlegen(self, erster: int, letzter: int) -> None:
        self.basis = int(erster) - int(erster) % 60
        self.m = (int(letzter) - self.basis) // 60 + 1
        nan = float("nan")
        self.o = array("d", [nan]) * self.m
        self.h = array("d", [nan]) * self.m
        self.lo = array("d", [nan]) * self.m
        self.c = array("d", [nan]) * self.m
        self._erster, self._letzter = int(erster), int(letzter)

    def _setzen(self, x) -> None:
        t = int(x[0])
        if t % 60 or x[4] is None:
            return
        i = (t - self.basis) // 60
        if 0 <= i < self.m:
            self.o[i], self.h[i], self.lo[i], self.c[i] = float(x[1]), float(x[2]), float(x[3]), float(x[4])

    def _raster(self) -> None:
        self.g0 = (self._erster // RASTER + 1) * RASTER
        g1 = ((self._letzter + 60) // RASTER) * RASTER
        n = max(0, (g1 - self.g0) // RASTER + 1)
        self.n = n
        self.r2 = array("d", [0.0]) * n
        self.da = array("b", [0]) * n
        for i in range(n):
            t = self.g0 + i * RASTER
            a, b = self.schluss(t - RASTER), self.schluss(t)
            if a and b and a > 0 and b > 0:
                r = math.log(b / a)
                self.r2[i] = r * r
                self.da[i] = 1
        self.S = array("d", [0.0]) * (n + 1)
        self.N = array("l", [0]) * (n + 1)
        for i in range(n):
            self.S[i + 1] = self.S[i] + self.r2[i]
            self.N[i + 1] = self.N[i] + self.da[i]

    def _i(self, beginn: int) -> int | None:
        if self.m == 0 or int(beginn) % 60:
            return None
        i = (int(beginn) - self.basis) // 60
        if i < 0 or i >= self.m or self.c[i] != self.c[i]:
            return None
        return i

    def schluss(self, t: int) -> float | None:
        """Kurs bei t = Schluss der Minute, die bei t endet (Nachtrag R1)."""
        i = self._i(int(t) - (0 if _MUT == "spot_enthaltende_kerze" else 60))
        return self.c[i] if i is not None else None

    def schluss_bis(self, t: int, max_alter: int = 300) -> float | None:
        """Jüngster Schluss mit Kerzenende ≤ t, höchstens max_alter Sekunden alt."""
        t = int(t) - int(t) % 60
        for a in range(0, max_alter + 1, 60):
            v = self.schluss(t - a)
            if v is not None:
                return v
        return None

    @classmethod
    def aus_db(cls, con, coin: str, quelle: str, von: int, bis: int) -> "SpotReihe":
        """Direkt aus pm_spot, ohne Zwischenliste (auch für Jahre an Minuten)."""
        r = con.execute("SELECT MIN(ts), MAX(ts) FROM pm_spot WHERE coin=? AND quelle=? AND ts>=? AND ts<?",
                        (coin, quelle, int(von), int(bis))).fetchone()
        obj = cls()
        if not r or r[0] is None:
            return obj
        obj._anlegen(r[0], r[1])
        for x in con.execute("SELECT ts, o, h, l, c FROM pm_spot WHERE coin=? AND quelle=? AND ts>=? AND ts<?",
                             (coin, quelle, int(von), int(bis))):
            obj._setzen(x)
        obj._raster()
        return obj

    def typisch(self, beginn: int) -> float | None:
        """(o+h+l+c)/4 der Minute ab beginn — Näherung für ein 60-s-Mittel (Kalshi/CF)."""
        i = self._i(beginn)
        return (self.o[i] + self.h[i] + self.lo[i] + self.c[i]) / 4.0 if i is not None else None

    def _idx(self, t0: int) -> int:
        """Index des letzten Rasterpunkts ≤ t0; Intervall i umfasst [g0 + (i−1)·R, g0 + i·R)."""
        return (int(t0) // RASTER * RASTER - self.g0) // RASTER

    def _rv(self, i_bis: int, anzahl: int):
        a = max(0, i_bis - anzahl + 1)
        b = min(self.n - 1, i_bis)
        if self.n == 0 or b < a:
            return 0.0, 0
        return self.S[b + 1] - self.S[a], self.N[b + 1] - self.N[a]

    def sigma2_tag(self, t0: int) -> float | None:
        """Varianz der Log-Rendite je Tag aus Daten bis t0; None, wenn in einem Teil weniger als 90 % der Intervalle da sind."""
        if _MUT == "sigma_zukunft":
            t0 = int(t0) + 86400
        if self.n == 0:
            return None
        i = self._idx(t0)
        if i < 0 or i >= self.n:
            return None
        teile = []
        for tage in (1, 7, 30):
            soll = 48 * tage
            s, n = self._rv(i, soll)
            if i - soll + 1 < 0 or n < 0.9 * soll:
                return None
            teile.append(s / n * 48)
        return sum(teile) / 3.0

    def faktor(self, beginn: int, t0: int, tage: int = 28, schrumpf: float = 14.0) -> float:
        """Tagesprofil: Varianz im 30-min-Slot von `beginn` relativ zum Mittel aller Slots (letzte 28 Tage bis t0)."""
        if self.n == 0:
            return 1.0
        i = min(self._idx(t0), self.n - 1)
        if i < 1:
            return 1.0
        s_all, n_all = self._rv(i, 48 * tage)
        if n_all < 48 or s_all <= 0:
            return 1.0
        m_all = s_all / n_all
        slot = (int(beginn) // RASTER) % 48
        slot_i = ((self.g0 + (i - 1) * RASTER) // RASTER) % 48
        j = i - (slot_i - slot) % 48
        s = 0.0
        n = 0
        while j >= 0 and j > i - 48 * tage:
            if self.da[j]:
                s += self.r2[j]
                n += 1
            j -= 48
        f = (s + schrumpf * m_all) / ((n + schrumpf) * m_all)
        return min(3.0, max(0.33, f))


class Schwankung:
    """σ für H2 (Nachtrag R9): log-HAR mit 1-Tages-Prognose, Koeffizienten monatlich auf Daten vor dem Neuschätzdatum
    (wachsendes Fenster ab Beginn der Spotreihe), Eingänge nur aus 30-min-Intervallen mit Ende ≤ t₀; dazu Wochentagsfaktor
    (gleiche Wochenphase der letzten 26 Wochen) und Makrotagsfaktor (frühere Termine), beide geschrumpft und begrenzt."""

    def __init__(self, spot: SpotReihe, termine: list[int] | None = None):
        self.sp = spot
        self.termine = sorted(termine or [])
        self._koef: dict[int, tuple | None] = {}
        self.rv: dict[int, float] = {}
        if not spot.n:
            return
        d_a = (spot.g0 - RASTER) // 86400
        d_b = (spot.g0 + (spot.n - 1) * RASTER) // 86400
        for d in range(d_a, d_b + 1):
            i0 = (d * 86400 - spot.g0) // RASTER + 1
            s, n = spot._rv(i0 + 47, 48)
            if n >= 43 and i0 >= 0:
                self.rv[d] = s * 48.0 / n

    def _merkmale(self, d: int):
        """log RV (1, 7, 30 Tage) aus Tagen ≤ d; None bei Lücken."""
        if d not in self.rv:
            return None
        w = [self.rv[x] for x in range(d - 6, d + 1) if x in self.rv]
        m = [self.rv[x] for x in range(d - 29, d + 1) if x in self.rv]
        if len(w) < 6 or len(m) < 27 or min(w + m) <= 0:
            return None
        return (math.log(self.rv[d]), math.log(sum(w) / len(w)), math.log(sum(m) / len(m)))

    def _fit(self, grenze: int | None) -> tuple | None:
        """OLS log RV[D] ~ 1 + Merkmale(D − 1) über alle D, deren Tag vor `grenze` endete (None = ganze Reihe)."""
        X, Y = [], []
        for D in sorted(self.rv):
            if grenze is not None and (D + 1) * 86400 > grenze:
                break
            f = self._merkmale(D - 1)
            if f is None or self.rv[D] <= 0:
                continue
            X.append((1.0,) + f)
            Y.append(math.log(self.rv[D]))
        if len(Y) < 120:
            return None
        k = 4
        A = [[sum(x[i] * x[j] for x in X) for j in range(k)] for i in range(k)]
        b = [sum(x[i] * y for x, y in zip(X, Y)) for i in range(k)]
        for i in range(k):                       # Gauß-Elimination mit Pivot
            p = max(range(i, k), key=lambda r: abs(A[r][i]))
            A[i], A[p], b[i], b[p] = A[p], A[i], b[p], b[i]
            if abs(A[i][i]) < 1e-12:
                return None
            for r in range(i + 1, k):
                f = A[r][i] / A[i][i]
                for c in range(i, k):
                    A[r][c] -= f * A[i][c]
                b[r] -= f * b[i]
        beta = [0.0] * k
        for i in reversed(range(k)):
            beta[i] = (b[i] - sum(A[i][c] * beta[c] for c in range(i + 1, k))) / A[i][i]
        res = [y - sum(bj * xj for bj, xj in zip(beta, x)) for x, y in zip(X, Y)]
        s2 = sum(r * r for r in res) / max(1, len(res) - k)
        return tuple(beta) + (s2,)

    def koeffizienten(self, t0: int):
        """Koeffizienten der letzten monatlichen Neuschätzung vor t0 (Daten bis zum Monatsersten)."""
        if _MUT == "har_ganze_stichprobe":
            return self._koef.setdefault(-1, self._fit(None))
        d = datetime.fromtimestamp(int(t0), UTC)
        grenze = utc_ts(datetime(d.year, d.month, 1, tzinfo=UTC))
        if grenze not in self._koef:
            self._koef[grenze] = self._fit(grenze)
        return self._koef[grenze]

    def sigma2_tag(self, t0: int) -> float | None:
        """Varianz der nächsten 24 h; Eingänge rollierend aus Intervallen mit Ende ≤ t0. Ohne Fit (unter 120 Tagen): gleiche
        Gewichte."""
        sp = self.sp
        i = sp._idx(t0) + (1 if _MUT == "har_label" else 0)
        if sp.n == 0 or i < 0 or i >= sp.n:
            return None
        teile = []
        for tage in (1, 7, 30):
            s, n = sp._rv(i, 48 * tage)
            if i - 48 * tage + 1 < 0 or n < 0.9 * 48 * tage:
                return None
            teile.append(s / n * 48)
        k = self.koeffizienten(t0)
        if k is None or min(teile) <= 0:
            return sum(teile) / 3.0
        lf = k[0] + k[1] * math.log(teile[0]) + k[2] * math.log(teile[1]) + k[3] * math.log(teile[2])
        return math.exp(lf + k[4] / 2.0)

    def _rv_fenster(self, a: int, tau: int) -> float | None:
        sp = self.sp
        i_a = -(-(a - sp.g0) // RASTER) + 1
        i_b = (a + tau - sp.g0) // RASTER
        soll = i_b - i_a + 1
        if soll <= 0 or i_a < 0 or i_b >= sp.n:
            return None
        s, n = sp._rv(i_b, soll)
        return s * soll / n if n >= 0.9 * soll else None

    def _mittel(self, t0: int, tau: int, tage: int = 182) -> float | None:
        i = self.sp._idx(t0)
        s, n = self.sp._rv(i, 48 * tage)
        if n < 0.8 * 48 * tage:
            return None
        return s / n * 48 * (tau / 86400.0)

    def wochentag_faktor(self, t0: int, tau: int) -> float:
        basis = self._mittel(t0, tau)
        werte = [v for v in (self._rv_fenster(t0 - w * 604800, tau) for w in range(1, 27)) if v is not None]
        if not basis or not werte:
            return 1.0
        f = (sum(werte) / len(werte)) / basis
        f = (len(werte) * f + 10.0) / (len(werte) + 10.0)
        return min(2.0, max(0.5, f))

    def makro_faktor(self, t0: int, tau: int) -> float:
        im = [t for t in self.termine if t0 <= t < t0 + tau]
        basis = self._mittel(t0, tau)
        if not im or not basis:
            return 1.0
        abstand = im[0] - t0
        werte = []
        for t in self.termine:
            a = t - abstand
            if a + tau > t0 or t < t0 - 730 * 86400:
                continue
            v = self._rv_fenster(a, tau)
            if v is not None:
                werte.append(v)
        if not werte:
            return 1.0
        f = (sum(werte) / len(werte)) / basis
        f = (len(werte) * f + 5.0) / (len(werte) + 5.0)
        return min(3.0, max(0.5, f))

    def sigma2(self, t0: int, tau: int) -> float | None:
        """Varianz der Log-Rendite über (t0, t0 + tau]: HAR × τ/1 Tag × Wochentags- × Makrotagsfaktor."""
        v = self.sigma2_tag(t0)
        if v is None:
            return None
        return v * (tau / 86400.0) * self.wochentag_faktor(t0, tau) * self.makro_faktor(t0, tau)


def p_schwelle(art: str, unten, oben, spot: float, sigma_tau: float) -> float | None:
    """Ja-Wahrscheinlichkeit im Spotmodell nach Kalshi-`strike_type` (greater…, less…, between)."""
    a = (art or "").lower()
    if a.startswith("greater") and unten is not None:
        return p_ueber(spot, unten, sigma_tau)
    if a.startswith("less") and oben is not None:
        return 1.0 - p_ueber(spot, oben, sigma_tau)
    if a == "between" and unten is not None and oben is not None:
        return max(0.0, p_ueber(spot, unten, sigma_tau) - p_ueber(spot, oben, sigma_tau))
    return None


def p_spot_aufab(spot: SpotReihe, beginn: int, ende: int, t0: int, mittel: bool = True) -> float | None:
    """Spotmodell für einen Auf/Ab-Markt zum Zeitpunkt t0 (Konzept 6.1, Nachtrag 13.1).

    mittel=True (Kalshi, CF-60-s-Mittel): Bezug = typischer Kurs der Minute vor Beginn; vor deren Beginn genau 0,5; innerhalb
    dieser Minute nicht rechenbar (None). Restvarianz um 40 s gekürzt (Mittel der letzten Minute statt Punktkurs).
    mittel=False (Punktkurse): bis einschließlich Beginn genau 0,5."""
    if mittel:
        if t0 <= beginn - 60:
            return 0.5
        if t0 < beginn:
            return None
        ref, abzug = spot.typisch(beginn - 60), 40
    else:
        if t0 <= beginn:
            return 0.5
        ref, abzug = spot.schluss(beginn), 0
    s = spot.schluss(t0)
    v = spot.sigma2_tag(t0)
    if ref is None or s is None or v is None or ref <= 0 or s <= 0:
        return None
    rest = ende - t0 - abzug
    if rest <= 0:
        return None
    return p_auf(math.log(s / ref), math.sqrt(v / 86400.0 * spot.faktor(beginn, t0) * rest))


# ---------------------------------------------------------------------------
# 7. Speicher (prognosemarkt.db)
# ---------------------------------------------------------------------------

SCHEMA = (
    """CREATE TABLE IF NOT EXISTS pm_markt(
        plattform TEXT NOT NULL, markt TEXT NOT NULL, ereignis TEXT, reihe TEXT, titel TEXT, art TEXT, basis TEXT,
        strike_typ TEXT, unten REAL, oben REAL, beginn INTEGER, ende INTEGER, handel_ab INTEGER, ablauf INTEGER,
        abrechnung TEXT, regeln TEXT, version TEXT, kennung_ja TEXT, kennung_nein TEXT, slug TEXT,
        erstmals INTEGER NOT NULL, zuletzt INTEGER NOT NULL, PRIMARY KEY(plattform, markt))""",
    """CREATE INDEX IF NOT EXISTS pm_markt_reihe ON pm_markt(plattform, reihe, ende)""",
    """CREATE TABLE IF NOT EXISTS pm_markt_aenderung(
        plattform TEXT, markt TEXT, ts INTEGER, feld TEXT, alt TEXT, neu TEXT)""",
    """CREATE TABLE IF NOT EXISTS pm_kurs(
        plattform TEXT NOT NULL, markt TEXT NOT NULL, ts INTEGER NOT NULL, quelle TEXT NOT NULL,
        geld INTEGER, brief INTEGER, mitte INTEGER, letzter INTEGER, oi REAL, bis INTEGER NOT NULL, abruf INTEGER NOT NULL,
        PRIMARY KEY(plattform, markt, ts, quelle)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS pm_ergebnis(
        plattform TEXT NOT NULL, markt TEXT NOT NULL, fassung INTEGER NOT NULL, ergebnis INTEGER, anteil REAL,
        wert REAL, ts INTEGER, abruf INTEGER NOT NULL, roh TEXT, PRIMARY KEY(plattform, markt, fassung))""",
    """CREATE TABLE IF NOT EXISTS pm_buch(
        plattform TEXT NOT NULL, markt TEXT NOT NULL, ts INTEGER NOT NULL, roh BLOB,
        PRIMARY KEY(plattform, markt, ts)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS pm_spot(
        coin TEXT NOT NULL, quelle TEXT NOT NULL, ts INTEGER NOT NULL, o REAL, h REAL, l REAL, c REAL, abruf INTEGER,
        PRIMARY KEY(coin, quelle, ts)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS pm_ueberraschung(
        reihe TEXT NOT NULL, termin INTEGER NOT NULL, ereignis TEXT, stand_ts INTEGER, quelle TEXT, median REAL,
        streuung REAL, n_schwellen INTEGER, spread_mittel REAL, ist REAL, ist_alfred REAL, u REAL, z REAL,
        r30_btc REAL, r30_davor REAL, r30_vorwoche REAL, r30_eth REAL, berechnet INTEGER, PRIMARY KEY(reihe, termin))""",
    """CREATE TABLE IF NOT EXISTS pm_auswertung(
        pruefung TEXT NOT NULL, lauf INTEGER NOT NULL, n INTEGER, tage INTEGER, mass REAL, lo REAL, hi REAL, p REAL,
        p_holm REAL, h1 REAL, h2 REAL, urteil TEXT, endgueltig INTEGER DEFAULT 0, version TEXT, details TEXT,
        PRIMARY KEY(pruefung, lauf))""",
    """CREATE TABLE IF NOT EXISTS pm_abruf(
        ts INTEGER, quelle TEXT, pfad TEXT, code INTEGER, ms INTEGER, bytes INTEGER, fehler TEXT)""",
    """CREATE INDEX IF NOT EXISTS pm_abruf_ts ON pm_abruf(ts)""",
    """CREATE TABLE IF NOT EXISTS pm_meta(schluessel TEXT PRIMARY KEY, wert TEXT)""",
    """CREATE TABLE IF NOT EXISTS pm_rb(
        teil TEXT NOT NULL, schluessel TEXT NOT NULL, erledigt INTEGER NOT NULL DEFAULT 0, info TEXT,
        PRIMARY KEY(teil, schluessel)) WITHOUT ROWID""",
)

MARKT_FELDER = ("ereignis", "reihe", "titel", "art", "basis", "strike_typ", "unten", "oben", "beginn", "ende", "handel_ab",
                "ablauf", "abrechnung", "regeln", "version", "kennung_ja", "kennung_nein", "slug")


@contextlib.contextmanager
def schreiben(con: sqlite3.Connection):
    """Schreibtransaktion mit BEGIN IMMEDIATE (eiserne Regel)."""
    con.execute("BEGIN IMMEDIATE")
    try:
        yield con
    except BaseException:
        con.execute("ROLLBACK")
        raise
    else:
        con.execute("COMMIT")


def verbinden(pfad: str) -> sqlite3.Connection:
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA busy_timeout=30000")
    with schreiben(con):
        for s in SCHEMA:
            con.execute(s)
    return con


def _gleich(a, b) -> bool:
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) <= 1e-9 * max(1.0, abs(float(a)))
    return str(a) == str(b)


def markt_speichern(con, m: dict, abruf: int) -> None:
    """Einfügen oder ergänzen. Ein geänderter Wert wird übernommen und mit dem alten Wert in pm_markt_aenderung festgehalten."""
    alt = con.execute("SELECT " + ",".join(MARKT_FELDER) + " FROM pm_markt WHERE plattform=? AND markt=?",
                      (m["plattform"], m["markt"])).fetchone()
    if alt is None:
        con.execute("INSERT INTO pm_markt(plattform, markt, " + ",".join(MARKT_FELDER) + ", erstmals, zuletzt) VALUES ("
                    + ",".join("?" * (len(MARKT_FELDER) + 4)) + ")",
                    (m["plattform"], m["markt"], *[m.get(f) for f in MARKT_FELDER], int(abruf), int(abruf)))
        return
    neu = []
    for f, a in zip(MARKT_FELDER, alt):
        v = m.get(f)
        if v is None or v == "":
            neu.append(a)
            continue
        if a is not None and a != "" and not _gleich(a, v):
            con.execute("INSERT INTO pm_markt_aenderung VALUES (?,?,?,?,?,?)",
                        (m["plattform"], m["markt"], int(abruf), f, str(a)[:2000], str(v)[:2000]))
        neu.append(v)
    con.execute("UPDATE pm_markt SET " + ",".join(f + "=?" for f in MARKT_FELDER) + ", zuletzt=? WHERE plattform=? AND markt=?",
                (*neu, int(abruf), m["plattform"], m["markt"]))


def kurs_speichern(con, plattform: str, markt: str, ts: int, quelle: str, geld, brief, letzter=None, oi=None,
                   abruf: int | None = None) -> bool:
    """Eine Beobachtung speichern. Live: gleiche Werte wie die letzte Live-Zeile verlängern nur deren `bis`."""
    ts = int(ts)
    abruf = int(abruf if abruf is not None else ts)
    if quelle == "live" and _MUT != "doppelt_geschrieben":
        r = con.execute("SELECT ts, geld, brief, letzter, oi FROM pm_kurs WHERE plattform=? AND markt=? AND quelle='live' "
                        "ORDER BY ts DESC LIMIT 1", (plattform, markt)).fetchone()
        if r and ts >= r[0] and (r[1], r[2], r[3]) == (geld, brief, letzter) and _gleich(r[4], oi):
            con.execute("UPDATE pm_kurs SET bis=? WHERE plattform=? AND markt=? AND ts=? AND quelle='live' AND bis<?",
                        (ts, plattform, markt, r[0], ts))
            return False
    m = None
    if geld is not None and brief is not None and brief >= geld:
        m = (geld + brief) // 2
    cur = con.execute("INSERT OR IGNORE INTO pm_kurs VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                      (plattform, markt, ts, quelle, geld, brief, m, letzter, oi, ts, abruf))
    return cur.rowcount > 0


def ergebnis_speichern(con, plattform: str, markt: str, ergebnis, anteil, wert, ts, abruf: int, roh=None) -> bool:
    """Ergebnis als neue Fassung, wenn es sich von der letzten unterscheidet; gleiches Ergebnis erzeugt keine Zeile."""
    r = con.execute("SELECT fassung, ergebnis, anteil, wert FROM pm_ergebnis WHERE plattform=? AND markt=? "
                    "ORDER BY fassung DESC LIMIT 1", (plattform, markt)).fetchone()
    if r and r[1] == ergebnis and _gleich(r[2], anteil) and _gleich(r[3], wert):
        return False
    con.execute("INSERT INTO pm_ergebnis VALUES (?,?,?,?,?,?,?,?,?)",
                (plattform, markt, (r[0] + 1) if r else 1, ergebnis, anteil, wert, ts, int(abruf),
                 json.dumps(roh, ensure_ascii=False)[:4000] if roh is not None else None))
    return True


def spot_speichern(con, coin: str, kerzen, quelle: str, abruf: int) -> int:
    """Nur abgeschlossene Minuten (Beginn + 60 ≤ Abrufzeit)."""
    n = 0
    for (t, o, h, lo, c) in kerzen:
        if t + 60 > abruf:
            continue
        n += con.execute("INSERT OR IGNORE INTO pm_spot VALUES (?,?,?,?,?,?,?,?)",
                         (coin, quelle, int(t), o, h, lo, c, int(abruf))).rowcount
    return n


def spot_laden(con, coin: str, von: int, bis: int, quelle: str | None = None) -> SpotReihe:
    q = SPOT_QUELLE.get(coin, ("", ""))[0] if quelle is None else quelle
    if _MUT == "spotquelle_gewechselt" and coin == "BTC" and int(von) < 1_785_000_000:
        q = "binance"
    return SpotReihe.aus_db(con, coin, q, von, bis)


def meta(con, schluessel: str, standard=None):
    r = con.execute("SELECT wert FROM pm_meta WHERE schluessel=?", (schluessel,)).fetchone()
    if r is None:
        return standard
    try:
        return json.loads(r[0])
    except (TypeError, ValueError):
        return r[0]


def meta_setzen(con, schluessel: str, wert) -> None:
    """Nur innerhalb von `schreiben(con)` aufrufen."""
    con.execute("INSERT INTO pm_meta VALUES (?,?) ON CONFLICT(schluessel) DO UPDATE SET wert=excluded.wert",
                (schluessel, json.dumps(wert, ensure_ascii=False)))


# ---------------------------------------------------------------------------
# 8. Abruf (nur lesen; je Quelle Takt, Pausen mit Verdopplung, Protokoll)
# ---------------------------------------------------------------------------

UA = "hl-dashboard/1.0 (prognosemarkt)"
NAME = "Prognosemärkte (U235)"
HL_GEWICHT_JE_MINUTE = 20      # eigener Deckel (Nachtrag 13.2), siehe LokalesGewicht
HOSTS = {
    "kalshi": "https://external-api.kalshi.com/trade-api/v2",
    "pm_gamma": "https://gamma-api.polymarket.com",
    "pm_clob": "https://clob.polymarket.com",
    "pm_data": "https://data-api.polymarket.com",
    "hl": "https://api.hyperliquid.xyz/info",
    "binance": "https://api.binance.com/api/v3/klines",
    "binance_perp": "https://fapi.binance.com/fapi/v1/klines",
}
TAKT_JE_S = {"kalshi": 2.0, "pm_gamma": 4.0, "pm_clob": 5.0, "pm_data": 3.0, "hl": 2.0, "binance": 4.0,
             "binance_perp": 4.0}
HL_GEWICHT = {"outcomeMeta": 20, "settledOutcome": 20, "l2Book": 2, "candleSnapshot": 20}
# U236: Gewichtsplan für HIP-4. Ein Schritt nur bei leerem 60-s-Fenster (Abrufe mit 20 Gewicht brauchen das ganze Fenster);
# reihum Meta (höchstens alle HIP4_META_S), Bücher, Abrechnung bzw. Rückblick.
HIP4_ZYKLUS = ("meta", "buch", "abrechnung", "buch", "abrechnung")
HIP4_META_S = 300
HIP4_ABRECHNUNG_S = 600          # ein Ausgang ohne Ergebnis wird frühestens nach so vielen Sekunden erneut abgefragt
PM_OHNE_BUCH_S = 6 * 3600        # U236: Polymarket-Kennung ohne Orderbuch (404) ruht so lange
# Spotquelle je Coin (Nachtrag 13.1): eine Quelle für Rückblick und Live, nie gemischt.
SPOT_QUELLE = {"BTC": ("coinbase", "BTC-USD"), "ETH": ("coinbase", "ETH-USD"), "ZEC": ("binance", "ZECUSDT"),
               "HYPE": ("binance_perp", "HYPEUSDT")}
HOSTS["coinbase"] = "https://api.exchange.coinbase.com"
TAKT_JE_S["coinbase"] = 3.0
ECHO_QUELLE = ("binance", "BTCUSDT")   # zweite Börse für die Nullprobe H2 (R12)
SPOT_VORLAUF_TAGE = {"BTC": 400}       # BTC: Vorlauf für das HAR (≥ 120 Tage Schätzung + 30 Tage Merkmale + Puffer)


def urllib_transport(methode: str, url: str, body: bytes | None, kopf: dict, timeout: float):
    req = urllib.request.Request(url, data=body, headers=kopf, method=methode)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        try:
            daten = e.read()
        except Exception:  # noqa: BLE001 — Fehlertext ist Beiwerk
            daten = b""
        return e.code, daten


class LokalesGewicht:
    """Eigener Gewichtsdeckel für Hyperliquid (Nachtrag 13.2): Die Rangfolge des Systems lebt nur im Recorder-Prozess (asyncio),
    der dort 1.080 der 1.200 Gewichtseinheiten je Minute und IP nutzt. Die übrigen Prozesse teilen sich den Rest mit eigenem
    Deckel, wie die Notbremse. Geplant waren im Mittel rund 12 je Minute; der Erstlauf zeigte 361 Ausgänge statt weniger
    Krypto-Ausgänge, deshalb seit 23.89 (U236) ein Gewichtsplan im Takt (HIP4_ZYKLUS) und Bücher nur für relevante Ausgänge."""

    def __init__(self, je_minute: int = 20, uhr=time.time):
        self.je_minute = je_minute
        self.uhr = uhr
        self.verbraucht: list[tuple[float, int]] = []

    def _fenster(self) -> int:
        jetzt = self.uhr()
        self.verbraucht = [(t, g) for t, g in self.verbraucht if jetzt - t < 60]
        return sum(g for _, g in self.verbraucht)

    def frei(self) -> int:
        """U236: Gewicht, das im gleitenden 60-s-Fenster noch frei ist."""
        return self.je_minute - self._fenster()

    def __call__(self, gewicht: int, rang: str = "prognosemarkt") -> bool:
        if self._fenster() + gewicht > self.je_minute:
            return False
        self.verbraucht.append((self.uhr(), gewicht))
        return True


class Abrufer:
    """GET/POST mit Takt je Quelle. Code < 0: nicht abgerufen (−1 Pause, −2 kein Gewicht, −3 kein JSON, −4 Netzfehler).

    Pausen (Konzept 4, Nachtrag 13.1): 429 → 60 s, verdoppelt bis 15 min; drei Fehler in Folge (5xx, Netz, 403/451) → 15 min,
    verdoppelt bis 6 h. 404 und 400/422 sind Antworten, keine Störung der Quelle."""

    def __init__(self, transport=None, uhr=time.time, schlafen=time.sleep, hl_gewicht=None, timeout: float = 20):
        self.transport = transport or urllib_transport
        self.uhr = uhr
        self.schlafen = schlafen
        self.hl_gewicht = hl_gewicht or LokalesGewicht(je_minute=HL_GEWICHT_JE_MINUTE, uhr=uhr)
        self.timeout = timeout
        self.naechst: dict[str, float] = {}
        self.pause_bis: dict[str, float] = {}
        self.pause_s: dict[tuple[str, str], float] = {}
        self.folge: dict[str, int] = {}
        self.zaehler: dict[tuple[str, str], int] = {}
        self.log: list[tuple] = []

    def pausiert(self, quelle: str) -> bool:
        return self.uhr() < self.pause_bis.get(quelle, 0.0)

    def hl_frei(self) -> int:
        """U236: freies Hyperliquid-Gewicht im eigenen 60-s-Fenster; ein Deckel ohne Abfrage (nur Selbsttest) gilt als leer."""
        f = getattr(self.hl_gewicht, "frei", None)
        return int(f()) if callable(f) else HL_GEWICHT_JE_MINUTE

    def _pause(self, quelle: str, art: str, start: float, hoechst: float) -> None:
        alt = self.pause_s.get((quelle, art))
        s = start if not alt else min(hoechst, alt * 2)
        self.pause_s[(quelle, art)] = s
        self.pause_bis[quelle] = self.uhr() + s

    def _zaehle(self, quelle: str, art: str) -> None:
        self.zaehler[(quelle, art)] = self.zaehler.get((quelle, art), 0) + 1

    def holen(self, quelle: str, pfad: str = "", params: dict | None = None, body=None, hl_art: str | None = None):
        if self.pausiert(quelle):
            self._zaehle(quelle, "pausiert")
            return -1, None
        if quelle == "hl" and not self.hl_gewicht(HL_GEWICHT.get(hl_art or "", 20)):
            self._zaehle(quelle, "kein_gewicht")
            return -2, None
        jetzt = self.uhr()
        warte = self.naechst.get(quelle, 0.0) - jetzt
        if warte > 0:
            self.schlafen(warte)
            jetzt = self.uhr()
        self.naechst[quelle] = jetzt + 1.0 / TAKT_JE_S[quelle]
        url = HOSTS[quelle] + pfad
        if params:
            url += "?" + urllib.parse.urlencode([(k, v) for k, v in params.items() if v is not None], doseq=True)
        kopf = {"User-Agent": UA, "Accept": "application/json"}
        roh_body = None
        if body is not None:
            roh_body = json.dumps(body).encode("utf-8")
            kopf["Content-Type"] = "application/json"
        start = time.monotonic()
        code, roh, fehler, daten = 0, b"", None, None
        try:
            code, roh = self.transport("POST" if body is not None else "GET", url, roh_body, kopf, self.timeout)
        except Exception as e:  # noqa: BLE001 — jeder Netzfehler zählt als Störung der Quelle
            code, fehler = -4, (type(e).__name__ + ": " + str(e))[:200]
        ms = int((time.monotonic() - start) * 1000)
        if code == 200:
            try:
                daten = json.loads((roh or b"null").decode("utf-8") or "null")
            except (ValueError, UnicodeDecodeError) as e:
                code, fehler = -3, ("JSON: " + str(e))[:200]
        if code == 200:
            self.folge[quelle] = 0
            self.pause_s.pop((quelle, "429"), None)
            self.pause_s.pop((quelle, "fehler"), None)
            self._zaehle(quelle, "ok")
        elif code in (404, 400, 422):
            self.folge[quelle] = 0
            self._zaehle(quelle, str(code))
        elif code == 429:
            self._zaehle(quelle, "429")
            self._pause(quelle, "429", 60.0, 900.0)
        else:
            self._zaehle(quelle, "gesperrt" if code in (403, 451) else "fehler")
            self.folge[quelle] = self.folge.get(quelle, 0) + 1
            if self.folge[quelle] >= 3:
                self._pause(quelle, "fehler", 900.0, 21600.0)
        self.log.append((int(jetzt), quelle, (pfad or (hl_art or ""))[:200], code, ms, len(roh or b""), fehler))
        return code, daten

    def log_schreiben(self, con) -> None:
        """Protokoll in pm_abruf (innerhalb von schreiben(con))."""
        if self.log:
            con.executemany("INSERT INTO pm_abruf VALUES (?,?,?,?,?,?,?)", self.log)
            self.log = []


# ---------------------------------------------------------------------------
# 9. Reihen, Familien und Live-Takt (Konzept 2 und 4)
# ---------------------------------------------------------------------------

# Kalshi-Reihen. art: aufab | schwelle | spanne | beruehrung | makro | ereignis. takt in s; fenster = nur Ablauf ≤ jetzt + fenster.
KALSHI_REIHEN = {
    "KXBTC15M": {"art": "aufab", "basis": "BTC", "dauer": 900, "takt": 60},
    "KXETH15M": {"art": "aufab", "basis": "ETH", "dauer": 900, "takt": 60},
    "KXHYPE15M": {"art": "aufab", "basis": "HYPE", "dauer": 900, "takt": 60},
    "KXZEC15M": {"art": "aufab", "basis": "ZEC", "dauer": 900, "takt": 60},
    "KXBTCD": {"art": "schwelle", "basis": "BTC", "takt": 300, "fenster": 172800},
    "KXETHD": {"art": "schwelle", "basis": "ETH", "takt": 300, "fenster": 172800},
    "KXBTC": {"art": "spanne", "basis": "BTC", "takt": 300, "fenster": 172800},
    "KXETH": {"art": "spanne", "basis": "ETH", "takt": 300, "fenster": 172800},
    "KXGOLDD": {"art": "schwelle", "basis": "GOLD", "takt": 300, "fenster": 172800},
    "KXGOLDH": {"art": "schwelle", "basis": "GOLD", "takt": 300, "fenster": 172800},
    "KXBTCMAXY": {"art": "beruehrung", "basis": "BTC", "takt": 3600},
    "KXBTCMINY": {"art": "beruehrung", "basis": "BTC", "takt": 3600},
    "KXBTCMAX150": {"art": "beruehrung", "basis": "BTC", "takt": 3600},
    "KXBTCY": {"art": "spanne", "basis": "BTC", "takt": 3600},
    "KXETHY": {"art": "spanne", "basis": "ETH", "takt": 3600},
    "KXCPI": {"art": "makro", "takt": 900, "schritt": 0.1, "alt": ["CPI"]},
    "KXCPIYOY": {"art": "makro", "takt": 900, "schritt": 0.1, "alt": ["CPIYOY"]},
    "KXU3": {"art": "makro", "takt": 900, "schritt": 0.1, "alt": ["U3"]},
    "KXPAYROLLS": {"art": "makro", "takt": 900, "schritt": None, "alt": ["PAYROLLS"]},
    "KXJOBLESSCLAIMS": {"art": "makro", "takt": 900, "schritt": None, "alt": ["JOBLESS"]},
    "KXGDP": {"art": "makro", "takt": 900, "schritt": 0.1, "alt": ["GDP"]},
    "KXFED": {"art": "makro", "takt": 900, "schritt": 0.25, "alt": ["FED"]},
    "KXFEDDECISION": {"art": "ereignis", "takt": 900, "alt": ["FEDDECISION"]},
    "KXRATECUTCOUNT": {"art": "ereignis", "takt": 3600},
    "KXRECSSNBER": {"art": "ereignis", "takt": 3600},
}
# Polymarket-Auf/Ab-Familien (nie 5 min, Regel 1.4): Dauer, Coins, Abrechnung auf Punktkurs.
PM_AUFAB = {"15m": (900, ("BTC", "ETH", "HYPE")), "1h": (3600, ("BTC", "ETH")), "4h": (14400, ("BTC", "ETH")),
            "tag": (86400, ("BTC", "ETH"))}
# Makro- und Ereignisfamilien für die Polymarket-Suche (Konzept 2.2); andere Treffer sind nur Vorschläge (Entscheidung 3).
PM_SUCHE = {"makro": ("fed decision", "fomc", "inflation", "cpi", "unemployment", "payrolls", "recession"),
            "ereignis": ("clarity act",)}
SCHLAGWORTE_VORSCHLAG = ("bitcoin", "ethereum", "hyperliquid", "zcash", "monero", "gold", "cpi", "inflation", "payrolls",
                         "unemployment", "fed", "fomc", "recession", "clarity", "stablecoin", "sec", "etf", "shutdown",
                         "tariff")


def _zahl_aus_text(s) -> float | None:
    """Erste Zahl in einem Text ('↑ 130,000', '$120K', '4.5%') -> float (k/K = Tausend, m/M = Million)."""
    if s is None:
        return None
    m = re.search(r"(-?\d[\d,]*\.?\d*)\s*([kKmM])?", str(s))
    if not m:
        return None
    try:
        v = float(m.group(1).replace(",", ""))
    except ValueError:
        return None
    if m.group(2) in ("k", "K"):
        v *= 1000
    elif m.group(2) in ("m", "M"):
        v *= 1_000_000
    return v


def pm_leiter_richtung(m: dict) -> tuple[str | None, float | None]:
    """Strike einer Polymarket-Leiter aus Gruppentitel oder Frage: ('greater'|'less', K)."""
    text = " ".join(str(x) for x in (m.get("gruppe"), m.get("titel")) if x)
    k = _zahl_aus_text(m.get("gruppe")) or _zahl_aus_text(m.get("titel"))
    t = text.lower()
    if "↓" in text or " dip" in t or "below" in t or " fall" in t:
        return "less", k
    return "greater", k


def pm_aufab_kandidaten(jetzt: int) -> list[dict]:
    """Berechnete Auf/Ab-Märkte: laufende und nächste Fenster je Familie und Coin (Konzept 2.2)."""
    aus = []
    dauer, coins = PM_AUFAB["15m"]
    b = fenster_beginn(jetzt, 900)
    for coin in coins:
        for k in (0, 1, 2):
            s = b + k * 900
            aus.append({"slug": pm_slug_updown(coin, "15m", s), "basis": coin, "familie": "15m", "beginn": s, "ende": s + 900})
    for coin in PM_AUFAB["1h"][1]:
        b = fenster_beginn(jetzt, 3600)
        for k in (0, 1):
            s = b + k * 3600
            aus.append({"slug": pm_slug_stunde(coin, s), "basis": coin, "familie": "1h", "beginn": s, "ende": s + 3600})
    for coin in PM_AUFAB["4h"][1]:
        starts = {et_4h_beginn(jetzt), et_4h_beginn(jetzt + 14400), fenster_beginn(jetzt, 14400),
                  fenster_beginn(jetzt, 14400) + 14400}
        for s in sorted(starts):
            aus.append({"slug": pm_slug_updown(coin, "4h", s), "basis": coin, "familie": "4h", "beginn": s, "ende": s + 14400})
    heute = et(jetzt).date()
    for coin in PM_AUFAB["tag"][1]:
        for tag in (heute, heute + timedelta(days=1)):
            vt = tag - timedelta(days=1)
            aus.append({"slug": pm_slug_tag(coin, tag), "basis": coin, "familie": "tag",
                        "beginn": et_zu_ts(vt.year, vt.month, vt.day, 12, 0), "ende": et_zu_ts(tag.year, tag.month, tag.day, 12, 0)})
    return aus


def pm_leiter_kandidaten(jetzt: int) -> list[dict]:
    """Leitern: täglich 'above' (12:00 ET), tägliche/monatliche/jährliche Berührungsleitern."""
    t = et(jetzt)
    heute = t.date()
    aus = []
    for coin in ("BTC", "ETH"):
        for tag in (heute, heute + timedelta(days=1)):
            aus.append({"slug": pm_slug_ueber(coin, tag), "basis": coin, "art": "schwelle",
                        "ende": et_zu_ts(tag.year, tag.month, tag.day, 12, 0)})
            aus.append({"slug": pm_slug_beruehrt_tag(coin, tag), "basis": coin, "art": "beruehrung", "ende": None})
        aus.append({"slug": pm_slug_beruehrt_monat(coin, t.year, t.month), "basis": coin, "art": "beruehrung", "ende": None})
        if t.day >= 25:
            nm = (t.month % 12) + 1
            aus.append({"slug": pm_slug_beruehrt_monat(coin, t.year + (1 if nm == 1 else 0), nm), "basis": coin,
                        "art": "beruehrung", "ende": None})
        aus.append({"slug": pm_slug_beruehrt_jahr(coin, t.year), "basis": coin, "art": "beruehrung", "ende": None})
    aus.append({"slug": pm_slug_beruehrt_jahr("HYPE", t.year), "basis": "HYPE", "art": "beruehrung", "ende": None})
    aus.append({"slug": "what-price-will-hyperliquid-hit-in-" + str(t.year), "basis": "HYPE", "art": "beruehrung",
                "ende": None})
    return aus


def _zlib(obj) -> bytes:
    import zlib
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 6)


class Takt:
    """Live-Takt (Konzept 4). Ein Aufruf von schritt() erledigt alle fälligen Aufgaben; Fehler einer Aufgabe stoppen nichts."""

    def __init__(self, con, abrufer: Abrufer, uhr=time.time):
        self.con = con
        self.ab = abrufer
        self.uhr = uhr
        self.zuletzt: dict[str, float] = {}
        self.makro_zuletzt = 0.0
        self.hip4_offen: dict[int, dict] = {}       # U236: nur relevante offene Ausgänge (Bücher, Abrechnung)
        self.hip4_alle: set[int] = set()            # alle Ausgänge der letzten Meta (der Rückblick lässt sie aus)
        self.hip4_meta_ts = 0.0                     # letzte erfolgreiche outcomeMeta
        self.hip4_i = 0                             # Stelle im Gewichtsplan HIP4_ZYKLUS
        self.hip4_rr = 0                            # Bücher reihum
        self.hip4_versuch: dict[str, float] = {}    # letzte Abfrage je abzurechnendem Ausgang
        self.ohne_buch: dict[str, float] = {}       # U236: Polymarket-Kennungen ohne Orderbuch (404) -> Zeitpunkt
        self.aufgaben = [
            ("kalshi_15m", 60, self.kalshi_15m),
            ("kalshi_tag", 300, self.kalshi_tag),
            ("kalshi_makro", 60, self.kalshi_makro),
            ("kalshi_lang", 3600, self.kalshi_lang),
            ("kalshi_abschluss", 600, self.kalshi_abschluss),
            ("pm_entdecken", 300, self.pm_entdecken),
            ("pm_aufab_kurse", 60, self.pm_aufab_kurse),
            ("pm_leitern", 300, self.pm_leitern),
            ("pm_suche", 604800, self.pm_suche),
            ("pm_abschluss", 900, self.pm_abschluss),
            ("hip4", 0, self.hip4_takt),              # U236: Gewichtsplan statt Meta alle 5 min und Bücher jede Minute
            ("spot", 60, self.spot_live),          # 23.88: jede Minute (Spot-Echo im Überblick höchstens 2–3 min alt)
            ("wartung", 86400, self.wartung),
        ]

    def schritt(self) -> list[str]:
        erledigt = []
        for name, takt, f in self.aufgaben:
            jetzt = self.uhr()
            if jetzt - self.zuletzt.get(name, 0.0) < takt:
                continue
            self.zuletzt[name] = jetzt
            try:
                f()
            except Exception as e:  # noqa: BLE001 — eine Aufgabe darf den Takt nie anhalten
                with schreiben(self.con):
                    meta_setzen(self.con, "fehler_" + name, {"ts": int(jetzt), "fehler": (type(e).__name__ + ": " + str(e))[:300]})
            erledigt.append(name)
        with schreiben(self.con):
            self.ab.log_schreiben(self.con)
        return erledigt

    # --- Kalshi ---------------------------------------------------------------------------------------------------

    def _kalshi_liste(self, params: dict, seiten: int = 20) -> list[dict]:
        aus, cursor = [], None
        for _ in range(seiten):
            code, d = self.ab.holen("kalshi", "/markets", dict(params, limit=1000, cursor=cursor))
            if code != 200 or not isinstance(d, dict):
                break
            aus.extend(d.get("markets") or [])
            cursor = d.get("cursor")
            if not cursor:
                break
        return aus

    def _kalshi_speichern(self, reihe: str, maerkte: list[dict], abruf: int, kurs: bool = True) -> list[dict]:
        return kalshi_maerkte_speichern(self.con, reihe, maerkte, abruf, kurs)

    def kalshi_15m(self) -> None:
        for reihe, cfg in KALSHI_REIHEN.items():
            if cfg["art"] == "aufab":
                ms = self._kalshi_liste({"series_ticker": reihe, "status": "open"}, seiten=2)
                self._kalshi_speichern(reihe, ms, int(self.uhr()))

    def kalshi_tag(self) -> None:
        jetzt = int(self.uhr())
        for reihe, cfg in KALSHI_REIHEN.items():
            if cfg.get("fenster"):
                ms = self._kalshi_liste({"series_ticker": reihe, "status": "open", "max_close_ts": jetzt + cfg["fenster"]})
                self._kalshi_speichern(reihe, ms, int(self.uhr()))

    def _termin_reihen(self, jetzt: int) -> set[str]:
        """Makro-Reihen mit Handelsschluss heute zwischen 07:00 und 10:30 ET (Veröffentlichungstag)."""
        t = et(jetzt)
        a = et_zu_ts(t.year, t.month, t.day, 7, 0)
        b = et_zu_ts(t.year, t.month, t.day, 10, 30)
        return {r for (r,) in self.con.execute(
            "SELECT DISTINCT reihe FROM pm_markt WHERE plattform='kalshi' AND art='makro' AND ende BETWEEN ? AND ?", (a, b))}

    def kalshi_makro(self) -> None:
        jetzt = int(self.uhr())
        t = et(jetzt)
        heute = self._termin_reihen(jetzt)
        phase = bool(heute) and (t.hour, t.minute) >= (7, 30) and (t.hour, t.minute) <= (8, 35)
        alle_faellig = jetzt - self.makro_zuletzt >= 900
        if not phase and not alle_faellig:
            return
        if alle_faellig:
            self.makro_zuletzt = jetzt
        for reihe, cfg in KALSHI_REIHEN.items():
            if cfg["art"] not in ("makro", "ereignis") or cfg.get("takt", 900) > 900:
                continue
            if not alle_faellig and reihe not in heute:
                continue
            ms = self._kalshi_speichern(reihe, self._kalshi_liste({"series_ticker": reihe, "status": "open"}), int(self.uhr()))
            if phase and reihe in heute:
                self._makro_buecher(reihe, ms)

    def _makro_buecher(self, reihe: str, maerkte: list[dict]) -> None:
        """Orderbuch der drei Schwellen nächst dem Median (Konzept 4) – nur am Veröffentlichungstag."""
        pkt = [((m["unten"] if m["unten"] is not None else m["oben"]), mitte(m["geld"], m["brief"]) / 10000.0, m["markt"])
               for m in maerkte if (m["strike_typ"] or "").startswith("greater") and mitte(m["geld"], m["brief"]) is not None
               and (m["unten"] is not None or m["oben"] is not None)]
        v = leiter_verteilung([(k, p) for k, p, _ in pkt]) if len(pkt) >= 2 else None
        if not v or v["median"] is None:
            return
        for _, _, tk in sorted(pkt, key=lambda x: abs(x[0] - v["median"]))[:3]:
            code, d = self.ab.holen("kalshi", "/markets/" + urllib.parse.quote(tk) + "/orderbook")
            if code == 200 and isinstance(d, dict):
                g, b = kalshi_buch(d)
                abruf = int(self.uhr())
                with schreiben(self.con):
                    kurs_speichern(self.con, "kalshi", tk, abruf, "buch", g, b, None, None, abruf)
                    self.con.execute("INSERT OR IGNORE INTO pm_buch VALUES (?,?,?,?)", ("kalshi", tk, abruf, _zlib(d)))

    def kalshi_lang(self) -> None:
        for reihe, cfg in KALSHI_REIHEN.items():
            if cfg.get("takt") == 3600:
                self._kalshi_speichern(reihe, self._kalshi_liste({"series_ticker": reihe, "status": "open"}), int(self.uhr()))

    def kalshi_abschluss(self) -> None:
        """Abgelaufene Kalshi-Märkte: Ergebnis holen; 15-min- und Makro-Märkte bekommen ihre 1-min-Kerzen (Quelle k1m)."""
        jetzt = int(self.uhr())
        offen = self.con.execute(
            "SELECT m.reihe, MIN(m.ende) FROM pm_markt m WHERE m.plattform='kalshi' AND m.ende < ? AND m.ende > ? "
            "AND NOT EXISTS (SELECT 1 FROM pm_ergebnis e WHERE e.plattform='kalshi' AND e.markt=m.markt) GROUP BY m.reihe",
            (jetzt - 120, jetzt - 14 * 86400)).fetchall()
        for reihe, ab in offen:
            ms = self._kalshi_liste({"series_ticker": reihe, "status": "settled", "min_close_ts": int(ab) - 1}, seiten=5)
            gesp = self._kalshi_speichern(reihe, ms, int(self.uhr()), kurs=False)
            cfg = KALSHI_REIHEN.get(reihe, {})
            for m in gesp:
                if m["ergebnis"] is None:
                    continue
                if cfg.get("art") == "aufab":
                    kalshi_kerzen_holen(self.con, self.ab, reihe, m["markt"], m["beginn"] - 300, m["ende"], 1, "k1m", None)
                elif cfg.get("art") == "makro":
                    termin = makro_termin(m["ende"])
                    if termin:
                        kalshi_kerzen_holen(self.con, self.ab, reihe, m["markt"], termin - 5400, termin + 5400, 1, "k1m", None)
                elif reihe == "KXBTCD" and m["ende"] and et(m["ende"]).hour == 17:
                    kalshi_kerzen_holen(self.con, self.ab, reihe, m["markt"], m["ende"] - 172800, m["ende"], 60, "k60m", None)

    # --- Polymarket -----------------------------------------------------------------------------------------------

    def _gamma_ereignis(self, slug: str) -> tuple[dict | None, str]:
        """Ereignis per Slug; ohne Treffer zweiter Versuch mit version=v2 (Protokoll V2, Konzept 2.2)."""
        code, d = self.ab.holen("pm_gamma", "/events/slug/" + urllib.parse.quote(slug))
        if code == 200 and isinstance(d, dict) and d.get("markets"):
            return d, "v1"
        code2, d2 = self.ab.holen("pm_gamma", "/events/slug/" + urllib.parse.quote(slug), {"version": "v2"})
        if code2 == 200 and isinstance(d2, dict) and d2.get("markets"):
            return d2, "v2"
        return None, str(code)

    def _pm_speichern(self, e: dict, vorgabe: dict, abruf: int) -> list[dict]:
        aus = []
        with schreiben(self.con):
            for m in gamma_ereignis(e):
                if not m["markt"]:
                    continue
                m.update({k: v for k, v in vorgabe.items() if v is not None and k != "slug"})
                m["slug"] = m.get("slug") or vorgabe.get("slug")
                if m.get("art") in ("schwelle", "beruehrung"):
                    st, k = pm_leiter_richtung(m)
                    m["strike_typ"] = st
                    if st == "less":
                        m["oben"] = k
                    else:
                        m["unten"] = k
                if m.get("art") == "aufab":
                    m["strike_typ"] = "aufab"
                m["abrechnung"] = "polymarket"
                m["ablauf"] = m.get("ablauf") or m.get("ende")
                markt_speichern(self.con, m, abruf)
                if m.get("ergebnis") is not None:
                    ergebnis_speichern(self.con, "polymarket", m["markt"], m["ergebnis"], None, None, m.get("ende"), abruf,
                                       {"outcomePrices": "geschlossen"})
                aus.append(m)
        return aus

    def pm_entdecken(self) -> None:
        """Auf/Ab-Fenster alle 5 min, Leitern alle 30 min (neue Strikes); Slugs ohne Treffer 30 min nicht erneut."""
        jetzt = int(self.uhr())
        fehl = getattr(self, "fehlslug", {})
        self.fehlslug = {s: t for s, t in fehl.items() if jetzt - t < 1800}
        for k in pm_aufab_kandidaten(jetzt):
            if k["slug"] in self.fehlslug or self.con.execute(
                    "SELECT 1 FROM pm_markt WHERE plattform='polymarket' AND slug=?", (k["slug"],)).fetchone():
                continue
            e, _ = self._gamma_ereignis(k["slug"])
            if e:
                self._pm_speichern(e, {"art": "aufab", "basis": k["basis"], "reihe": "PM" + k["familie"],
                                       "beginn": k["beginn"], "ende": k["ende"], "slug": k["slug"]}, int(self.uhr()))
            else:
                self.fehlslug[k["slug"]] = jetzt
        if jetzt - self.zuletzt.get("pm_leiter_entdecken", 0.0) < 1800:
            return
        self.zuletzt["pm_leiter_entdecken"] = jetzt
        for k in pm_leiter_kandidaten(jetzt):
            if k["slug"] in self.fehlslug:
                continue
            e, _ = self._gamma_ereignis(k["slug"])
            if e:
                self._pm_speichern(e, {"art": k["art"], "basis": k["basis"], "reihe": "PM" + k["art"], "slug": k["slug"]},
                                   int(self.uhr()))
            else:
                self.fehlslug[k["slug"]] = jetzt

    def _pm_buecher(self, maerkte: list[tuple[str, str]]) -> None:
        """Bücher je Ja-Kennung; zuerst Sammelabruf POST /books (bis 20), sonst einzeln. U236: Eine Kennung, deren Einzelabruf 404
        brachte (kein Orderbuch, etwa vorzeitig entschieden), ruht PM_OHNE_BUCH_S -- im Erstlauf waren 6.409 von 9.241 Abrufen
        solche 404."""
        jetzt = self.uhr()
        self.ohne_buch = {k: t for k, t in self.ohne_buch.items() if jetzt - t < PM_OHNE_BUCH_S}
        if _MUT != "ohne_buch_nicht_auslassen":
            for _, tok in maerkte:
                if str(tok) in self.ohne_buch:
                    self.ab._zaehle("pm_clob", "ohne_buch_ruht")
            maerkte = [(m, k) for m, k in maerkte if str(k) not in self.ohne_buch]
        for i in range(0, len(maerkte), 20):
            teil = maerkte[i:i + 20]
            code, d = self.ab.holen("pm_clob", "/books", body=[{"token_id": tok} for _, tok in teil])
            buecher = {}
            if code == 200 and isinstance(d, list):
                for b in d:
                    if isinstance(b, dict):
                        buecher[str(b.get("asset_id") or b.get("token_id") or "")] = b
            for markt, tok in teil:
                b = buecher.get(str(tok))
                if b is None:
                    c1, b = self.ab.holen("pm_clob", "/book", {"token_id": tok})
                    if c1 == 404:
                        self.ohne_buch[str(tok)] = self.uhr()
                    if c1 != 200 or not isinstance(b, dict):
                        continue
                g, br = pm_buch(b)
                abruf = int(self.uhr())
                with schreiben(self.con):
                    kurs_speichern(self.con, "polymarket", markt, abruf, "live", g, br, preis(b.get("last_trade_price")),
                                   None, abruf)

    def pm_aufab_kurse(self) -> None:
        jetzt = int(self.uhr())
        zeilen = self.con.execute(
            "SELECT markt, kennung_ja FROM pm_markt WHERE plattform='polymarket' AND art='aufab' AND beginn<=? AND ende>? "
            "AND kennung_ja IS NOT NULL", (jetzt + 1200, jetzt)).fetchall()
        self._pm_buecher([(m, k) for m, k in zeilen])

    def pm_leitern(self) -> None:
        jetzt = int(self.uhr())
        lauf = int(self.zuletzt.get("pm_leitern_15", 0))
        alle = jetzt - lauf >= 900
        if alle:
            self.zuletzt["pm_leitern_15"] = jetzt
        # U236: Märkte mit Ergebnis (vorzeitig entschieden, etwa eine erreichte Kursmarke) haben kein Buch mehr
        ohne_erg = "" if _MUT == "ohne_buch_nicht_auslassen" else (
            " AND NOT EXISTS (SELECT 1 FROM pm_ergebnis e WHERE e.plattform='polymarket' AND e.markt=pm_markt.markt)")
        zeilen = self.con.execute(
            "SELECT markt, kennung_ja, ende FROM pm_markt WHERE plattform='polymarket' AND art IN "
            "('schwelle','beruehrung','spanne','makro','ereignis') AND (ende IS NULL OR ende>?) AND kennung_ja IS NOT NULL"
            + ohne_erg, (jetzt,)).fetchall()
        wahl = [(m, k) for m, k, e in zeilen if alle or (e is not None and e - jetzt <= 172800)]
        self._pm_buecher(wahl)

    def pm_suche(self) -> None:
        """Wöchentlich: Makro/Ereignis-Familien aufnehmen (Konzept 2.2); übrige Treffer nur als Vorschlag (Entscheidung 3)."""
        jetzt = int(self.uhr())
        vorschlaege = {}
        for wort in SCHLAGWORTE_VORSCHLAG:
            code, d = self.ab.holen("pm_gamma", "/public-search", {"q": wort})
            if code != 200 or not isinstance(d, dict):
                continue
            for e in d.get("events") or []:
                titel = str(e.get("title") or "").lower()
                ende = iso_ts(e.get("endDate"))
                if ende is not None and ende < jetzt:
                    continue
                art = next((a for a, ws in PM_SUCHE.items() if any(w in titel for w in ws)), None)
                if art and e.get("markets"):
                    self._pm_speichern(e, {"art": art, "reihe": "PM" + art}, jetzt)
                elif e.get("slug"):
                    vorschlaege[e["slug"]] = {"titel": e.get("title"), "ende": ende, "wort": wort}
        with schreiben(self.con):
            meta_setzen(self.con, "vorschlaege_polymarket", {"ts": jetzt, "liste": list(vorschlaege.items())[:200]})

    def pm_abschluss(self) -> None:
        """Abgelaufene Polymarket-Märkte: Ergebnis aus Gamma, 1-min-Verlauf (innerhalb von 7 Tagen) als Quelle p1m."""
        jetzt = int(self.uhr())
        zeilen = self.con.execute(
            "SELECT m.markt, m.kennung_ja, m.beginn, m.ende FROM pm_markt m WHERE m.plattform='polymarket' AND m.ende < ? "
            "AND m.ende > ? AND NOT EXISTS (SELECT 1 FROM pm_ergebnis e WHERE e.plattform='polymarket' AND e.markt=m.markt) "
            "LIMIT 60", (jetzt - 600, jetzt - 6 * 86400)).fetchall()
        for markt, tok, beginn, ende in zeilen:
            code, d = self.ab.holen("pm_gamma", "/markets", {"condition_ids": markt, "closed": "true"})
            liste = d if isinstance(d, list) else (d.get("markets") if isinstance(d, dict) else None)
            if code == 200 and liste:
                m = gamma_markt(liste[0])
                if m["ergebnis"] is not None:
                    with schreiben(self.con):
                        ergebnis_speichern(self.con, "polymarket", markt, m["ergebnis"], None, None, ende, int(self.uhr()),
                                           {"outcomePrices": "geschlossen"})
            if tok and beginn:
                pm_verlauf_holen(self.con, self.ab, markt, tok, beginn - 3600, ende, 1, "p1m")

    # --- Hyperliquid HIP-4 (U236: Gewichtsplan) ------------------------------------------------------------------

    def hip4_takt(self) -> None:
        """U236: Hyperliquid nach Plan statt nach Uhr. Ein Schritt nur bei leerem 60-s-Fenster, denn outcomeMeta und
        settledOutcome kosten je 20 Gewicht -- so viel wie der ganze eigene Deckel. Reihum (HIP4_ZYKLUS): Meta (höchstens alle
        HIP4_META_S), Bücher der relevanten Ausgänge, Abrechnung abgelaufener relevanter Ausgänge, sonst ein Schritt des
        HIP-4-Rückblicks. Bis 23.88 lief die Abrechnung direkt nach der Meta im vollen Fenster und bekam nie Gewicht (eigener
        Fehler; der Selbsttest lief mit unbegrenztem Gewicht)."""
        for _ in range(len(HIP4_ZYKLUS)):
            if self.ab.hl_frei() < HL_GEWICHT_JE_MINUTE:
                return
            art = HIP4_ZYKLUS[self.hip4_i % len(HIP4_ZYKLUS)]
            self.hip4_i += 1
            if art == "meta":
                if self.hip4_meta_ts and self.uhr() - self.hip4_meta_ts < HIP4_META_S:
                    continue
                genutzt = self.hip4_meta()
            elif art == "buch":
                genutzt = self.hip4_buch()
            else:
                genutzt = self._hip4_abrechnen_eins() or self._hip4_rueckblick_eins()
            if genutzt:
                return

    def hip4_meta(self) -> bool:
        """outcomeMeta: alle Ausgänge ablegen, relevante für Bücher und Abrechnung merken; nicht mehr geführte schließen.
        True, wenn Gewicht verbraucht wurde."""
        code, d = self.ab.holen("hl", body={"type": "outcomeMeta"}, hl_art="outcomeMeta")
        if code in (-1, -2):
            return False
        if code != 200:
            return True
        abruf = int(self.uhr())
        self.hip4_meta_ts = abruf
        relevant, alle = {}, set()
        with schreiben(self.con):
            for o in hip4_ausgaenge(d):
                m = {"plattform": "hip4", "markt": o["markt"], "titel": o.get("name") or "", "regeln": o.get("beschreibung"),
                     "basis": o.get("basis"), "art": "schwelle" if o.get("klasse") == "priceBinary" else "ereignis",
                     "reihe": "HIP4" + (o.get("klasse") or ""), "strike_typ": "greater" if o.get("ziel") else None,
                     "unten": o.get("ziel"), "ende": o.get("ablauf"), "ablauf": o.get("ablauf"), "abrechnung": "hl_mark"}
                markt_speichern(self.con, m, abruf)
                alle.add(o["ausgang"])
                if hip4_relevant(o):
                    relevant[o["ausgang"]] = m
            # Ausgänge, die outcomeMeta nicht mehr führt, sind geschlossen (Ende = jetzt). Bis 23.88 blieben die ohne Ablauf
            # (Aktien-Perps, Teilnehmer) für immer „offen“ (Erstlauf am 28.10.: 639).
            for (mk,) in self.con.execute("SELECT markt FROM pm_markt WHERE plattform='hip4' AND (ende IS NULL OR ende>?)",
                                          (abruf,)).fetchall():
                n = hip4_nummer(mk)
                if n is not None and n not in alle:
                    self.con.execute("UPDATE pm_markt SET ende=?, zuletzt=? WHERE plattform='hip4' AND markt=?", (abruf, abruf, mk))
            if meta(self.con, "hip4_abzurechnen"):
                meta_setzen(self.con, "hip4_abzurechnen", [])      # Warteliste aus 23.88 (nie abgearbeitet) entfällt
        self.hip4_offen, self.hip4_alle = relevant, alle
        if _MUT == "hip4_abrechnung_nach_meta":
            self._hip4_abrechnen_eins()
        return True

    def _hip4_abrechnen_eins(self) -> bool:
        """Ein abgelaufener relevanter Ausgang ohne Ergebnis, den outcomeMeta nicht mehr führt: settledOutcome (höchstens alle
        HIP4_ABRECHNUNG_S je Ausgang, bis 14 Tage nach dem Ablauf). True, wenn abgefragt."""
        jetzt = self.uhr()
        if not self.hip4_meta_ts:
            return False
        if _MUT == "hip4_abrechnung_nach_meta" and jetzt - self.hip4_meta_ts > 1:
            return False                                             # Mutation: wie 23.88 nur direkt nach der Meta
        platz = ",".join("?" * len(HIP4_COINS))
        for (mk,) in self.con.execute(
                "SELECT m.markt FROM pm_markt m WHERE m.plattform='hip4' AND m.reihe='HIP4priceBinary' AND upper(m.basis) IN ("
                + platz + ") AND m.ende IS NOT NULL AND m.ende<=? AND m.ende>? AND NOT EXISTS (SELECT 1 FROM pm_ergebnis e "
                "WHERE e.plattform='hip4' AND e.markt=m.markt) ORDER BY m.ende",
                (*HIP4_COINS, int(jetzt), int(jetzt) - 14 * 86400)).fetchall():
            n = hip4_nummer(mk)
            if n is None or n in self.hip4_alle or jetzt - self.hip4_versuch.get(mk, 0.0) < HIP4_ABRECHNUNG_S:
                continue
            code, d = self.ab.holen("hl", body={"type": "settledOutcome", "outcome": n}, hl_art="settledOutcome")
            if code in (-1, -2):
                return False
            self.hip4_versuch[mk] = jetzt
            if code == 200 and isinstance(d, dict) and d:
                e = hip4_abgerechnet(d)
                with schreiben(self.con):
                    ergebnis_speichern(self.con, "hip4", mk, e["ergebnis"], e["anteil"], e["kurs"], None, int(self.uhr()), d)
            return True
        return False

    def _hip4_rueckblick_eins(self) -> bool:
        """Ein Schritt des HIP-4-Rückblicks (Ergebnisse aller Ausgänge seit dem Start, settledOutcome je Kennung). Seit 23.89 im
        Gewichtsplan des Takts; der Teil 'hip4' im Rückblick-Faden wartet nur (kein Leerlauf). Gleiche Regeln wie dort: Fehler
        zählen, nach 20 in Folge abgebrochen. True, wenn abgefragt."""
        if stichtag(self.con) is None or not self.hip4_meta_ts:
            return False
        st = meta(self.con, "rb:hip4", {}) or {}
        if st.get("fertig"):
            return False
        if "max" not in st:
            st.update(max=max(self.hip4_alle or {0}), i=0)
        i = int(st.get("i", 0))
        while i <= int(st["max"]) and i in self.hip4_alle:
            i += 1
        if i > int(st["max"]):
            st.update(i=i, fertig=True, fertig_ts=int(self.uhr()))
            with schreiben(self.con):
                meta_setzen(self.con, "rb:hip4", st)
            return False
        code, d = self.ab.holen("hl", body={"type": "settledOutcome", "outcome": i}, hl_art="settledOutcome")
        if code in (-1, -2):
            return False
        if code == 200 and isinstance(d, dict) and d:
            e = hip4_abgerechnet(d)
            with schreiben(self.con):
                ergebnis_speichern(self.con, "hip4", "#" + str(10 * i), e["ergebnis"], e["anteil"], e["kurs"], None,
                                   int(self.uhr()), d)
            st["n"] = int(st.get("n", 0)) + 1
        if code in (200, 400, 404, 422):
            st.update(i=i + 1, fehler=0)
        else:
            st["fehler"] = int(st.get("fehler", 0)) + 1
            if st["fehler"] >= 20:
                st.update(fertig=True, abgebrochen="20 Fehler in Folge")
        st["schritte"] = int(st.get("schritte", 0)) + 1
        if st.get("fertig"):
            st["fertig_ts"] = int(self.uhr())
        with schreiben(self.con):
            meta_setzen(self.con, "rb:hip4", st)
        return True

    def hip4_buch(self) -> bool:
        """Bücher der relevanten offenen Ausgänge reihum, so viele wie das freie Gewicht erlaubt (je 2). True, wenn abgefragt."""
        liste = sorted(self.hip4_offen.items())
        if not liste:
            return False
        n = max(1, self.ab.hl_frei() // HL_GEWICHT["l2Book"])
        start = self.hip4_rr % len(liste)
        genutzt = False
        for k, (_, m) in enumerate((liste[start:] + liste[:start])[:n]):
            code, d = self.ab.holen("hl", body={"type": "l2Book", "coin": m["markt"]}, hl_art="l2Book")
            if code in (-1, -2):
                break
            genutzt = True
            self.hip4_rr = (start + k + 1) % len(liste)
            if code == 200 and isinstance(d, dict):
                g, b = hl_buch_mitte(d)
                abruf = int(self.uhr())
                with schreiben(self.con):
                    kurs_speichern(self.con, "hip4", m["markt"], abruf, "live", g, b, None, None, abruf)
        return genutzt

    # --- Spot und Wartung -----------------------------------------------------------------------------------------

    def spot_live(self) -> None:
        """Laufende Minuten nachladen (höchstens 7 Tage zurück; ältere Lücken füllt der Rückblick nicht nach, sie zählen
        in der Auswertung als „kein_spot“)."""
        jetzt = int(self.uhr())
        for coin in SPOT_QUELLE:
            spot_nachladen(self.con, self.ab, coin, jetzt - 7 * 86400, jetzt)

    def wartung(self) -> None:
        with schreiben(self.con):
            self.con.execute("DELETE FROM pm_abruf WHERE ts < ?", (int(self.uhr()) - 90 * 86400,))


def kalshi_maerkte_speichern(con, reihe: str, maerkte: list[dict], abruf: int, kurs: bool = True) -> list[dict]:
    """Kalshi-Märkte einordnen und speichern; Live-Kurs (Quelle live) nur mit kurs=True; Ergebnis, falls abgerechnet."""
    cfg = KALSHI_REIHEN.get(reihe, {})
    aus = []
    with schreiben(con):
        for roh in maerkte:
            m = kalshi_markt(roh)
            if not m["markt"]:
                continue
            kalshi_einordnen(m, reihe, cfg)
            markt_speichern(con, m, abruf)
            if kurs and (m["geld"] is not None or m["brief"] is not None or m["letzter"] is not None):
                kurs_speichern(con, "kalshi", m["markt"], abruf, "live", m["geld"], m["brief"], m["letzter"], m["oi"], abruf)
            if m["ergebnis"] is not None:
                ergebnis_speichern(con, "kalshi", m["markt"], m["ergebnis"], None, m["wert"], m["ablauf"], abruf,
                                   {"result": m["ergebnis_roh"], "expiration_value": m["wert"]})
            aus.append(m)
    return aus


def kalshi_einordnen(m: dict, reihe: str, cfg: dict) -> None:
    """Art, Basis und Fensterbeginn setzen. 15-min-Reihen: Beginn = Schluss − 900 s (Handelsbeginn steht in handel_ab)."""
    m["reihe"] = reihe
    m["art"] = cfg.get("art")
    m["basis"] = cfg.get("basis")
    m["abrechnung"] = "kalshi"
    m["handel_ab"] = m.get("beginn")
    if cfg.get("dauer") and m.get("ende"):
        m["beginn"] = m["ende"] - cfg["dauer"]


def makro_termin(schluss: int | None) -> int | None:
    """Veröffentlichung 08:30 ET am Tag des Handelsschlusses, wenn dieser zwischen 07:00 und 10:30 ET liegt; sonst None."""
    if not schluss:
        return None
    t = et(schluss)
    if not ((7, 0) <= (t.hour, t.minute) <= (10, 30)):
        return None
    return et_zu_ts(t.year, t.month, t.day, 8, 30)


def kalshi_kerzen_holen(con, ab: Abrufer, reihe: str, markt: str, von: int, bis: int, periode: int, quelle: str,
                        grenze: int | None, ende: int | None = None) -> int:
    """Kerzen eines Markts holen und als Beobachtungen speichern (Zeitpunkt = Periodenende). Gibt die Zahl neuer Zeilen
    zurück, −1 bei Fehler. Vor der Archivgrenze zuerst /historical/…, sonst der Live-Pfad; bei 404 der andere."""
    params = {"start_ts": int(von), "end_ts": int(bis), "period_interval": int(periode)}
    pfade = ["/series/" + reihe + "/markets/" + urllib.parse.quote(markt) + "/candlesticks",
             "/historical/markets/" + urllib.parse.quote(markt) + "/candlesticks"]
    if grenze and ende and ende < grenze:
        pfade.reverse()
    for pfad in pfade:
        code, d = ab.holen("kalshi", pfad, params)
        if code == 404:
            continue
        if code != 200 or not isinstance(d, dict):
            return -1
        abruf = int(ab.uhr())
        n = 0
        with schreiben(con):
            for k in kalshi_kerzen(d, int(periode) * 60):
                n += kurs_speichern(con, "kalshi", markt, k["ts"], quelle, k["geld"], k["brief"], k["preis"], k["oi"], abruf)
            meta_setzen(con, "kerzen:" + quelle + ":" + markt, {"ts": abruf, "n": n, "pfad": pfad[:12]})
        return n
    return -1


def pm_verlauf_holen(con, ab: Abrufer, markt: str, token: str, von: int, bis: int, fidelity: int, quelle: str) -> int:
    """Polymarket-Verlauf (CLOB /prices-history; leer → Data API v2 mit 5-min-Eimern, Quelle p5m). `p` ist undokumentiert
    (Mitte oder letzter Handel) und wird als letzter Kurs gespeichert, nie als Geld/Brief."""
    code, d = ab.holen("pm_clob", "/prices-history", {"market": token, "startTs": int(von), "endTs": int(bis),
                                                      "fidelity": int(fidelity)})
    eimer = 60 * int(fidelity)
    reihe = pm_verlauf(d) if code == 200 else []
    if not reihe:
        code, d = ab.holen("pm_data", "/v2/prices-history", {"token_id": token, "start": int(von), "end": int(bis),
                                                             "bucket_seconds": 300})
        reihe = pm_verlauf(d) if code == 200 else []
        quelle, eimer = "p5m", 300
    # Nachtrag R1: Punkt gilt als am Eimerbeginn beschriftet mit dem Wert am Eimerende → gespeichert mit Ende = t + Eimer
    reihe = [(ts + eimer, p) for ts, p in reihe]
    abruf = int(ab.uhr())
    n = 0
    with schreiben(con):
        for ts, p in reihe:
            n += kurs_speichern(con, "polymarket", markt, ts, quelle, None, None, p, None, abruf)
    return n


def _spot_abruf(ab: Abrufer, quelle: str, symbol: str, von: int, bis: int):
    """Ein Abruf 1-min-Kerzen ab `von`: (HTTP-Code, Kerzen, nächster Beginn, falls leer)."""
    if quelle == "coinbase":
        ende = min(int(bis), int(von) + 299 * 60)
        code, d = ab.holen("coinbase", "/products/" + symbol + "/candles",
                           {"granularity": 60, "start": von_ts(von).strftime("%Y-%m-%dT%H:%M:%SZ"),
                            "end": von_ts(ende).strftime("%Y-%m-%dT%H:%M:%SZ")})
        return code, (coinbase_kerzen(d) if code == 200 else []), ende + 60
    code, d = ab.holen(quelle, "", {"symbol": symbol, "interval": "1m", "startTime": int(von) * 1000,
                                    "endTime": int(bis) * 1000, "limit": 1000})
    return code, (binance_kerzen(d) if code == 200 else []), int(von) + 60000


def spot_abschnitt(con, ab: Abrufer, coin: str, von: int, bis: int, quelle: str | None = None,
                   symbol: str | None = None) -> tuple[int, int]:
    """Ein Abruf ab `von`: (neue Zeilen oder −1 bei Fehler, nächster Beginn). Leere Antwort springt weiter."""
    q, sym = (quelle, symbol) if quelle else SPOT_QUELLE[coin]
    code, k, weiter = _spot_abruf(ab, q, sym, von, bis)
    if code != 200:
        return -1, int(von)
    if not k:
        return 0, weiter
    with schreiben(con):
        n = spot_speichern(con, coin, k, q, int(ab.uhr()))
    return n, max(k[-1][0] + 60, int(von) + 60)


def spot_nachladen(con, ab: Abrufer, coin: str, von: int, bis: int, max_abrufe: int = 50) -> int:
    """Laufende Minuten ab dem jüngsten gespeicherten Stand (frühestens `von`) bis `bis`."""
    quelle = SPOT_QUELLE[coin][0]
    r = con.execute("SELECT MAX(ts) FROM pm_spot WHERE coin=? AND quelle=? AND ts>=?", (coin, quelle, int(von))).fetchone()
    ab_ts = max(int(von), (r[0] + 60) if r and r[0] else int(von))
    neu = 0
    for _ in range(max_abrufe):
        if ab_ts + 60 > bis:
            break
        n, weiter = spot_abschnitt(con, ab, coin, ab_ts, bis)
        if n < 0:
            break
        neu += n
        if weiter <= ab_ts:
            break
        ab_ts = weiter
    return neu


# ---------------------------------------------------------------------------
# 10. Rückblick (Konzept 5): kleine Schritte, höchstens ein Abruf je Schritt, Stand in pm_meta und pm_rb
# ---------------------------------------------------------------------------

MAKRO_RUECKBLICK = ("KXCPI", "KXCPIYOY", "KXU3", "KXPAYROLLS", "KXFED", "KXFEDDECISION", "KXGDP", "KXJOBLESSCLAIMS")
KURZ_RUECKBLICK = ("KXBTC15M", "KXETH15M", "KXHYPE15M", "KXZEC15M")


def rb_merken(con, teil: str, schluessel: str, info: str | None = None) -> None:
    con.execute("INSERT OR IGNORE INTO pm_rb VALUES (?,?,0,?)", (teil, schluessel, info))


def rb_erledigt(con, teil: str, schluessel: str, info: str | None = None) -> None:
    con.execute("INSERT INTO pm_rb VALUES (?,?,1,?) ON CONFLICT(teil, schluessel) DO UPDATE SET erledigt=1, "
                "info=COALESCE(excluded.info, pm_rb.info)", (teil, schluessel, info))


def rb_offen(con, teil: str, limit: int = 1) -> list[tuple[str, str | None]]:
    return con.execute("SELECT schluessel, info FROM pm_rb WHERE teil=? AND erledigt=0 ORDER BY schluessel LIMIT ?",
                       (teil, limit)).fetchall()


class Rueckblick:
    """Rückblick in Teilen; Reihenfolge: Grenze → Listen (Makro, 15 min, Tagesleiter) → Spot → Renditen H3 → Kerzen Makro →
    Kerzen BTC 15 min → Kerzen Tagesleiter → übrige Coins → Polymarket → HIP-4. Ein Teil ist fertig, wenn nichts mehr offen ist;
    nach 20 Fehlern in Folge wird er mit Vermerk abgebrochen (im Bericht)."""

    def __init__(self, con, abrufer: Abrufer, uhr=time.time):
        self.con = con
        self.ab = abrufer
        self.uhr = uhr
        t = [("grenze", "kalshi", self.t_grenze)]
        for r in MAKRO_RUECKBLICK:
            t.append(("liste:" + r, "kalshi", functools.partial(self.t_liste, r, r)))
            for alt in KALSHI_REIHEN[r].get("alt", []):
                t.append(("liste:" + alt, "kalshi", functools.partial(self.t_liste, alt, r)))
        for r in KURZ_RUECKBLICK:
            t.append(("liste:" + r, "kalshi", functools.partial(self.t_liste, r, r)))
        t.append(("ereignisse:KXBTCD", "kalshi", self.t_ereignisse_btcd))
        for coin in ("BTC", "ETH", "HYPE", "ZEC"):
            t.append(("spot:" + coin, SPOT_QUELLE[coin][0], functools.partial(self.t_spot, coin)))
        t.append(("h3_rendite", "binance_perp", self.t_h3_rendite))
        t.append(("spot_echo", ECHO_QUELLE[0], self.t_spot_echo))
        t.append(("kerzen:makro", "kalshi", self.t_kerzen_makro))
        t.append(("kerzen:KXBTC15M", "kalshi", functools.partial(self.t_kerzen_15m, "KXBTC15M")))
        t.append(("kerzen:KXBTCD", "kalshi", self.t_kerzen_btcd))
        for r in KURZ_RUECKBLICK[1:]:
            t.append(("kerzen:" + r, "kalshi", functools.partial(self.t_kerzen_15m, r)))
        t.append(("pm_aufab", "pm_gamma", self.t_pm_aufab))
        t.append(("hip4", "hl", self.t_hip4))
        self.teile = t

    # Ablauf ----------------------------------------------------------------------------------------------------------

    def schritt(self) -> bool:
        """Ein Schritt im ersten unfertigen Teil. False, wenn alles fertig ist, dessen Quelle pausiert oder der Stichtag (R2,
        gesetzt im Erstlauf) fehlt."""
        if stichtag(self.con) is None:
            return False
        for name, quelle, f in self.teile:
            st = meta(self.con, "rb:" + name, {}) or {}
            if st.get("fertig"):
                continue
            if self.ab.pausiert(quelle):
                return False
            try:
                neu = f(dict(st)) or dict(st)
            except Exception as e:  # noqa: BLE001 — ein Formatfehler zählt als Fehler des Teils, der Dienst läuft weiter
                neu = self._fehler(dict(st))
                with schreiben(self.con):
                    meta_setzen(self.con, "fehler_rb:" + name, {"ts": int(self.uhr()), "fehler": (type(e).__name__ + ": "
                                                                                                    + str(e))[:300]})
            if neu.pop("_warten", False):
                return False          # U236: Teil wartet (HIP-4 im Takt) -- kein Schritt, kein Schreiben, Runde endet
            if neu.pop("_f", False):
                neu["fehler"] = int(st.get("fehler", 0)) + 1
                if neu["fehler"] >= 20:
                    neu["fertig"] = True
                    neu["abgebrochen"] = "20 Fehler in Folge"
            else:
                neu["fehler"] = 0
            neu["schritte"] = int(st.get("schritte", 0)) + 1
            if neu.get("fertig") and not st.get("fertig"):
                neu["fertig_ts"] = int(self.uhr())
            with schreiben(self.con):
                meta_setzen(self.con, "rb:" + name, neu)
            return True
        return False

    def stand(self) -> list[dict]:
        aus = []
        for name, quelle, _ in self.teile:
            st = meta(self.con, "rb:" + name, {}) or {}
            aus.append({"teil": name, "quelle": quelle, **{k: v for k, v in st.items() if k in
                        ("fertig", "schritte", "fehler", "abgebrochen", "n", "n_live", "n_hist", "fertig_ts", "hinweis")}})
        return aus

    @staticmethod
    def _fehler(st: dict) -> dict:
        st["_f"] = True
        return st

    def _grenze(self) -> int | None:
        return (meta(self.con, "kalshi_grenze", {}) or {}).get("grenze")

    # Teile -------------------------------------------------------------------------------------------------------------

    def t_grenze(self, st: dict) -> dict:
        code, d = self.ab.holen("kalshi", "/historical/cutoff")
        if code == 200 and isinstance(d, dict):
            with schreiben(self.con):
                meta_setzen(self.con, "kalshi_grenze", {"ts": int(self.uhr()), "grenze": kalshi_grenze(d), "roh": d})
            st["fertig"] = True
        elif code in (400, 404, 422):
            st.update(fertig=True, hinweis="keine Archivgrenze (" + str(code) + ")")
        else:
            return self._fehler(st)
        return st

    def t_liste(self, serie: str, reihe: str, st: dict) -> dict:
        stufe = st.get("stufe", "live")
        abruf = int(self.uhr())
        if stufe in ("live", "hist"):
            pfad = "/markets" if stufe == "live" else "/historical/markets"
            params = {"series_ticker": serie, "limit": 1000, "cursor": st.get("cursor")}
            if stufe == "live":
                params["status"] = "settled"
            code, d = self.ab.holen("kalshi", pfad, params)
            if code == 200 and isinstance(d, dict):
                alle = d.get("markets") or []
                ms = [m for m in alle if str(m.get("ticker", "")).startswith(serie + "-")]
                if stufe == "hist" and alle and not ms:
                    st.update(stufe="ereignisse", cursor=None)
                    return st
                kalshi_maerkte_speichern(self.con, reihe, ms, abruf, kurs=False)
                st["n_" + stufe] = int(st.get("n_" + stufe, 0)) + len(ms)
                st["cursor"] = d.get("cursor") or None
                if not st["cursor"]:
                    if stufe == "live":
                        st["stufe"] = "hist"
                    else:
                        st["fertig"] = True
            elif code in (400, 422):
                st.update(stufe="hist" if stufe == "live" else "ereignisse", cursor=None)
            elif code == 404:
                if stufe == "live":
                    st.update(stufe="hist", cursor=None)
                else:
                    st["fertig"] = True
            else:
                return self._fehler(st)
            return st
        teil = "ereignis:" + serie
        if not st.get("liste_fertig"):
            code, d = self.ab.holen("kalshi", "/events", {"series_ticker": serie, "limit": 200, "cursor": st.get("cursor")})
            if code == 200 and isinstance(d, dict):
                with schreiben(self.con):
                    for e in d.get("events") or []:
                        if e.get("event_ticker"):
                            rb_merken(self.con, teil, e["event_ticker"])
                st["cursor"] = d.get("cursor") or None
                if not st["cursor"]:
                    st["liste_fertig"] = True
            elif code in (400, 404, 422):
                st["liste_fertig"] = True
            else:
                return self._fehler(st)
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        e = offen[0][0]
        code, d = self.ab.holen("kalshi", "/historical/markets", {"event_ticker": e, "limit": 1000})
        if code == 200 and isinstance(d, dict):
            kalshi_maerkte_speichern(self.con, reihe, d.get("markets") or [], abruf, kurs=False)
            st["n_hist"] = int(st.get("n_hist", 0)) + len(d.get("markets") or [])
        elif code not in (400, 404, 422):
            return self._fehler(st)
        with schreiben(self.con):
            rb_erledigt(self.con, teil, e)
        return st

    def t_ereignisse_btcd(self, st: dict) -> dict:
        """Tagesleiter: nur Ereignisse mit Ablauf 17:00 ET (H2)."""
        teil = "ereignis:KXBTCD17"
        jetzt = int(self.uhr())
        if not st.get("liste_fertig"):
            code, d = self.ab.holen("kalshi", "/events", {"series_ticker": "KXBTCD", "limit": 200, "cursor": st.get("cursor")})
            if code == 200 and isinstance(d, dict):
                with schreiben(self.con):
                    for e in d.get("events") or []:
                        z = kalshi_ticker_zerlegen(str(e.get("event_ticker") or ""))
                        if z.get("termin_ts") and z.get("termin_genau") and et(z["termin_ts"]).hour == 17 \
                                and z["termin_ts"] < jetzt - 600:
                            rb_merken(self.con, teil, e["event_ticker"])
                st["cursor"] = d.get("cursor") or None
                if not st["cursor"]:
                    st["liste_fertig"] = True
            elif code in (400, 404, 422):
                st["liste_fertig"] = True
            else:
                return self._fehler(st)
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        e = offen[0][0]
        z = kalshi_ticker_zerlegen(e)
        grenze = self._grenze()
        pfade = ["/markets", "/historical/markets"]
        if grenze and (z.get("termin_ts") or 0) < grenze:
            pfade.reverse()
        for pfad in pfade:
            code, d = self.ab.holen("kalshi", pfad, {"event_ticker": e, "limit": 1000})
            if code == 200 and isinstance(d, dict) and d.get("markets"):
                kalshi_maerkte_speichern(self.con, "KXBTCD", d["markets"], jetzt, kurs=False)
                st["n"] = int(st.get("n", 0)) + len(d["markets"])
                break
            if code not in (200, 400, 404, 422):
                return self._fehler(st)
        with schreiben(self.con):
            rb_erledigt(self.con, teil, e)
        return st

    def t_spot(self, coin: str, st: dict) -> dict:
        """1-min-Spot ab 32 Tagen vor dem ersten Markt (BTC: ab 400 Tagen davor, für das HAR) bis zum Stichtag + 3 Tage, mit
        eigenem Cursor (Live-Daten füllen keine Lücke vor)."""
        bis = min(int(self.uhr()) - 120, int(stichtag(self.con) or self.uhr()) + 3 * 86400)
        if "ab" not in st:
            r = self.con.execute("SELECT MIN(beginn) FROM pm_markt WHERE plattform='kalshi' AND basis=? AND art IN "
                                 "('aufab','schwelle') AND reihe IN ('KXBTC15M','KXETH15M','KXHYPE15M','KXZEC15M','KXBTCD')",
                                 (coin,)).fetchone()
            vor = SPOT_VORLAUF_TAGE.get(coin, 32) * 86400
            von = (r[0] if r and r[0] else int(self.uhr()) - 120 * 86400) - vor
            st["von"] = st["ab"] = max(von, int(self.uhr()) - 5 * 365 * 86400) // 60 * 60
        n, naechst = spot_abschnitt(self.con, self.ab, coin, int(st["ab"]), bis)
        if n < 0:
            return self._fehler(st)
        st["n"] = int(st.get("n", 0)) + n
        st["ab"] = naechst
        if naechst >= bis - 60:
            st["fertig"] = True
        return st

    def t_spot_echo(self, st: dict) -> dict:
        """Zweite Börse für die Nullprobe H2 (R12): Binance BTCUSDT 1 min um jeden möglichen Prüfzeitpunkt (24/18/12/6 h)."""
        teil = "spot_echo"
        if not st.get("liste"):
            with schreiben(self.con):
                for ereignis, zeilen in _btcd_ereignisse(self.con).items():
                    ende = int(max(r[5] for r in zeilen))
                    for L in H2_VORLAEUFE:
                        rb_merken(self.con, teil, ereignis + ":" + str(L), str(ende - L))
            st["liste"] = True
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        t0 = int(offen[0][1])
        n, _ = spot_abschnitt(self.con, self.ab, "BTC", t0 - 600, t0 + 60, ECHO_QUELLE[0], ECHO_QUELLE[1])
        if n < 0:
            return self._fehler(st)
        with schreiben(self.con):
            rb_erledigt(self.con, teil, offen[0][0], str(n))
        return st

    def t_h3_rendite(self, st: dict) -> dict:
        """Binance-Perp-30-min-Kerzen je Makro-Termin für BTC und ETH (Quelle perp30): Beginn 08:00, 08:30, 09:00 ET und die
        08:30-Kerze eine Woche früher (Placebo b, R10). Gespeichert mit ihrem Beginn."""
        teil = "h3_rendite"
        if not st.get("liste"):
            termine = sorted({makro_termin(e) for (e,) in self.con.execute(
                "SELECT DISTINCT ende FROM pm_markt WHERE plattform='kalshi' AND art='makro' AND ende < ?",
                (stichtag(self.con) or 0,))} - {None})
            with schreiben(self.con):
                for t in termine:
                    for coin in ("BTC", "ETH"):
                        rb_merken(self.con, teil, coin + ":" + str(t) + ":0", str(t - 1800))
                        rb_merken(self.con, teil, coin + ":" + str(t) + ":w", str(t - 7 * 86400))
            st.update(liste=True, n=len(termine))
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        coin = offen[0][0].split(":")[0]
        start = int(offen[0][1])
        code, d = self.ab.holen("binance_perp", "", {"symbol": coin + "USDT", "interval": "30m",
                                                     "startTime": start * 1000, "limit": 3})
        if code == 200:
            jetzt = int(self.uhr())
            with schreiben(self.con):
                for ts, o, h, lo, c in binance_kerzen(d):
                    if ts % 1800 == 0 and ts + 1800 <= jetzt:
                        self.con.execute("INSERT OR IGNORE INTO pm_spot VALUES (?,?,?,?,?,?,?,?)",
                                         (coin, "perp30", ts, o, h, lo, c, jetzt))
                rb_erledigt(self.con, teil, offen[0][0], "ok")
        elif code in (400, 404):
            with schreiben(self.con):
                rb_erledigt(self.con, teil, offen[0][0], "fehlt")
        else:
            return self._fehler(st)
        return st

    def _kerzen_markt(self, st: dict, teil: str, sql: str, params: tuple, fenster) -> dict:
        r = self.con.execute(sql, params).fetchone()
        if not r:
            st["fertig"] = True
            return st
        reihe, markt, beginn, ende = r
        von, bis, periode, quelle = fenster(beginn, ende)
        if von is None:
            with schreiben(self.con):
                rb_erledigt(self.con, teil, markt, "kein Zeitfenster")
            return st
        n = kalshi_kerzen_holen(self.con, self.ab, kalshi_ticker_zerlegen(markt)["reihe"], markt, von, bis, periode, quelle,
                                self._grenze(), ende)
        if n < 0:
            return self._fehler(st)
        with schreiben(self.con):
            rb_erledigt(self.con, teil, markt, str(n))
        st["n"] = int(st.get("n", 0)) + 1
        return st

    def t_kerzen_makro(self, st: dict) -> dict:
        def fenster(beginn, ende):
            t = makro_termin(ende)
            return (t - 5400, t + 5400, 1, "k1m") if t else (None, None, None, None)
        sql = ("SELECT m.reihe, m.markt, m.beginn, m.ende FROM pm_markt m WHERE m.plattform='kalshi' AND m.art='makro' "
               "AND m.ende < ? AND EXISTS (SELECT 1 FROM pm_ergebnis e WHERE e.plattform='kalshi' AND e.markt=m.markt) AND "
               "NOT EXISTS (SELECT 1 FROM pm_rb r WHERE r.teil=? AND r.schluessel=m.markt) ORDER BY (m.reihe<>'KXCPI'), m.ende "
               "LIMIT 1")
        return self._kerzen_markt(st, "kerzen:makro", sql, (stichtag(self.con) or 0, "kerzen:makro"), fenster)

    def t_kerzen_15m(self, reihe: str, st: dict) -> dict:
        teil = "kerzen:" + reihe
        sql = ("SELECT m.reihe, m.markt, m.beginn, m.ende FROM pm_markt m WHERE m.plattform='kalshi' AND m.reihe=? "
               "AND m.ende < ? AND EXISTS (SELECT 1 FROM pm_ergebnis e WHERE e.plattform='kalshi' AND e.markt=m.markt) AND "
               "NOT EXISTS (SELECT 1 FROM pm_rb r WHERE r.teil=? AND r.schluessel=m.markt) ORDER BY m.ende LIMIT 1")
        return self._kerzen_markt(st, teil, sql, (reihe, stichtag(self.con) or 0, teil), lambda b, e: (b - 300, e, 1, "k1m"))

    def t_kerzen_btcd(self, st: dict) -> dict:
        """Alle Schwellen jedes 17:00-ET-Ereignisses vor dem Stichtag: 60-min-Kerzen der letzten 48 h (R9)."""
        teil = "kerzen:KXBTCD"
        if not st.get("liste"):
            with schreiben(self.con):
                for ereignis, zeilen in _btcd_ereignisse(self.con).items():
                    for r in zeilen:
                        rb_merken(self.con, teil, r[0], str(int(r[5])))
            st["liste"] = True
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        markt, ende = offen[0][0], int(offen[0][1])
        n = kalshi_kerzen_holen(self.con, self.ab, "KXBTCD", markt, ende - 172800, ende, 60, "k60m", self._grenze(), ende)
        if n < 0:
            return self._fehler(st)
        with schreiben(self.con):
            rb_erledigt(self.con, teil, markt, str(n))
        st["n"] = int(st.get("n", 0)) + 1
        return st

    def t_pm_aufab(self, st: dict) -> dict:
        """Polymarket 4 h (ET-Raster) und Tag, BTC und ETH, letzte 60 Tage: Ergebnis und 5-min-Verlauf (p5m), beschreibend."""
        teil = "pm_aufab"
        jetzt = int(self.uhr())
        if not st.get("liste"):
            heute = et(jetzt).date()
            with schreiben(self.con):
                for d in range(1, 61):
                    tag = heute - timedelta(days=d)
                    vt = tag - timedelta(days=1)
                    for coin in ("BTC", "ETH"):
                        b_tag = et_zu_ts(vt.year, vt.month, vt.day, 12, 0)
                        e_tag = et_zu_ts(tag.year, tag.month, tag.day, 12, 0)
                        rb_merken(self.con, teil, pm_slug_tag(coin, tag),
                                  json.dumps({"basis": coin, "familie": "tag", "beginn": b_tag, "ende": e_tag}))
                        for h in (0, 4, 8, 12, 16, 20):
                            b = et_zu_ts(tag.year, tag.month, tag.day, h, 0)
                            rb_merken(self.con, teil, pm_slug_updown(coin, "4h", b),
                                      json.dumps({"basis": coin, "familie": "4h", "beginn": b, "ende": b + 14400}))
            st["liste"] = True
            return st
        offen = rb_offen(self.con, teil)
        if not offen:
            st["fertig"] = True
            return st
        slug, info = offen[0]
        k = json.loads(info or "{}")
        r = self.con.execute("SELECT markt, kennung_ja FROM pm_markt WHERE plattform='polymarket' AND slug=?",
                             (slug,)).fetchone()
        if r is None:
            takt = Takt(self.con, self.ab, self.uhr)
            e, _ = takt._gamma_ereignis(slug)
            if e:
                takt._pm_speichern(e, {"art": "aufab", "basis": k.get("basis"), "reihe": "PM" + str(k.get("familie")),
                                       "beginn": k.get("beginn"), "ende": k.get("ende"), "slug": slug}, jetzt)
            else:
                with schreiben(self.con):
                    rb_erledigt(self.con, teil, slug, "fehlt")
            return st
        markt, tok = r
        if tok:
            pm_verlauf_holen(self.con, self.ab, markt, tok, int(k.get("beginn", 0)) - 3600, int(k.get("ende", 0)), 5, "p5m")
        with schreiben(self.con):
            rb_erledigt(self.con, teil, slug, "ok")
        return st

    def t_hip4(self, st: dict) -> dict:
        """HIP-4: Ergebnisse aller Ausgänge seit Start (settledOutcome je Kennung); Kurse gibt es rückwirkend nicht. Seit 23.89
        (U236) schreitet dieser Teil im Gewichtsplan des Takts voran (Takt._hip4_rueckblick_eins): settledOutcome kostet 20 Gewicht,
        so viel wie der ganze eigene Deckel. Hier wartet er nur -- bis 23.88 hätte er bei fehlendem Gewicht leer weitergezählt
        und bei jedem Versuch geschrieben (Leerlauf im Rückblick-Faden)."""
        if _MUT == "rb_leerlauf":
            return st
        return {**st, "_warten": True}


# ---------------------------------------------------------------------------
# 11. Auswertung (Konzept 6 mit Nachtrag 13.1, R1–R15; vorab festgelegt)
# ---------------------------------------------------------------------------

REIBUNG = 0.0225                 # Gebühr 1,75 ¢ + halber Spread 0,5 ¢ um 50 % (Regel 1.5)
MIN_N = {"H1": 4000, "H2": 100, "H3": 30}
MIN_TAGE = {"H1": 60, "H2": 60, "H3": 0}
GEWICHT = {"H1": 0.25, "H2": 0.25, "H3": 0.5}   # gewichteter Holm (R5)
H1_FENSTER = (300, 60)           # Zustand: jüngste gültige Kerze mit Ende in [B − 300 s, B − 60 s] (R7)
H2_VORLAEUFE = (86400, 64800, 43200, 21600)   # 24, 18, 12, 6 h (R9)
SHUTDOWN_2025 = ("KXCPI-25SEP", "KXCPI-25OCT", "KXCPI-25NOV", "KXCPIYOY-25SEP", "KXCPIYOY-25OCT", "KXCPIYOY-25NOV")
RB_TEILE_URTEIL = ("kerzen:makro", "kerzen:KXBTC15M", "kerzen:KXBTCD", "spot:BTC", "h3_rendite", "spot_echo")
VERSION_AUSWERTUNG = "U235-2"


def stichtag(con) -> int | None:
    """Stichtag des Rückblicks (R2): Zeit des Erstlaufs. Ohne Erstlauf kein Urteil."""
    if _MUT == "kein_stichtag":
        return 4_000_000_000
    return (meta(con, "stichtag", {}) or {}).get("ts")


def ergebnisse(con, plattform: str) -> dict[str, tuple]:
    """Jüngste Fassung je Markt: {markt: (ergebnis, wert, fassung)}."""
    return {m: (e, w, f) for m, e, w, f in con.execute(
        "SELECT e.markt, e.ergebnis, e.wert, e.fassung FROM pm_ergebnis e JOIN (SELECT markt, MAX(fassung) AS f FROM "
        "pm_ergebnis WHERE plattform=? GROUP BY markt) x ON e.markt=x.markt AND e.fassung=x.f WHERE e.plattform=?",
        (plattform, plattform))}


def zustand(con, plattform: str, markt: str, von: int, bis: int, quelle: str):
    """Jüngster gültiger Kurs (Ende ≤ bis, ≥ von) als (ts, p_M) – Nachtrag R1: nur Werte, deren Zeitraum bis `bis` endete.
    Live: Antwort bis `bis` empfangen und bis mindestens `von` bestätigt."""
    if _MUT == "quellen_vermischt":
        zeilen = con.execute("SELECT ts, geld, brief FROM pm_kurs WHERE plattform=? AND markt=? AND ts<=? AND bis>=? "
                             "ORDER BY ts DESC LIMIT 20", (plattform, markt, int(bis), int(von))).fetchall()
    elif quelle == "live":
        zeilen = con.execute("SELECT ts, geld, brief FROM pm_kurs WHERE plattform=? AND markt=? AND quelle='live' AND ts<=? "
                             "AND bis>=? ORDER BY ts DESC LIMIT 20", (plattform, markt, int(bis), int(von))).fetchall()
    else:
        zeilen = con.execute("SELECT ts, geld, brief FROM pm_kurs WHERE plattform=? AND markt=? AND quelle=? AND ts<=? "
                             "AND ts>=? ORDER BY ts DESC LIMIT 20", (plattform, markt, quelle, int(bis), int(von))).fetchall()
    for ts, g, b in zeilen:
        m = mitte(g, b)
        if m is not None:
            return int(ts), m / 10000.0
    return None


def h1_zustand(con, plattform: str, markt: str, beginn: int, quelle: str):
    """H1 (R7): jüngste gültige Kerze mit Ende in [B − 300 s, B − 60 s]; p_S = 0,5 genau."""
    bis = int(beginn) - H1_FENSTER[1]
    if _MUT == "t0_im_bezug":
        bis = int(beginn)
    elif _MUT == "kurs_nach_t0":
        bis = int(beginn) + 60
    return zustand(con, plattform, markt, int(beginn) - H1_FENSTER[0], bis, quelle)


def _maerkte_rueckblick(con, plattform: str, reihe: str, vorwaerts: bool = False):
    st = stichtag(con)
    if st is None:
        return []
    op = ">=" if vorwaerts else "<"
    return con.execute("SELECT markt, beginn, ende FROM pm_markt WHERE plattform=? AND reihe=? AND beginn IS NOT NULL AND "
                       "ende IS NOT NULL AND ende " + op + " ? ORDER BY beginn", (plattform, reihe, st)).fetchall()


def zaehlung_h1(con, reihe: str = "KXBTC15M", quelle: str = "k1m") -> dict:
    """Ohne Ergebnisse (R4): Fenster mit gültigem Kurs vor dem Beginn, Tage, Anteile bei B − 60 und B − 120 s."""
    z = {"maerkte": 0, "mit_kurs": 0, "tage": 0}
    tage = set()
    for markt, beginn, _ in _maerkte_rueckblick(con, "kalshi", reihe):
        z["maerkte"] += 1
        if h1_zustand(con, "kalshi", markt, beginn, quelle):
            z["mit_kurs"] += 1
            tage.add(int(beginn) // 86400)
    z["tage"] = len(tage)
    return z


def faelle_h1(con, reihe: str = "KXBTC15M", quelle: str = "k1m", vorwaerts: bool = False, versatz: int | None = None):
    """Fälle für H1: d = p_M − 0,5, y, g. versatz (s nach B) nur für die Positivkontrolle „B + 10 min“."""
    erg = ergebnisse(con, "kalshi")
    z = {"maerkte": 0, "ohne_ergebnis": 0, "kein_kurs_vor_beginn": 0}
    faelle = []
    for markt, beginn, ende in _maerkte_rueckblick(con, "kalshi", reihe, vorwaerts):
        z["maerkte"] += 1
        e = erg.get(markt)
        if not e or e[0] not in (0, 1):
            z["ohne_ergebnis"] += 1
            continue
        if versatz is None:
            w = h1_zustand(con, "kalshi", markt, beginn, quelle)
        else:
            w = zustand(con, "kalshi", markt, int(beginn) + versatz - 240, int(beginn) + versatz, quelle)
        if not w:
            z["kein_kurs_vor_beginn"] += 1
            continue
        p = w[1]
        faelle.append({"ts": int(beginn), "d": p - 0.5, "y": int(e[0]), "p_m": p, "p_s": 0.5,
                       "g": brier_zugewinn(0.5, p, e[0])})
    z["faelle"] = len(faelle)
    return faelle, z


def _tagesaggregate(faelle: list[dict], art: str) -> list[tuple]:
    """[(tag, n, s1, s2, s12)] je UTC-Tag. art 'kov': s1 = Σd, s2 = Σy, s12 = Σd·y; art 'mittel': s1 = Σwert."""
    tage: dict[int, list] = {}
    for f in faelle:
        t = int(f["ts"]) if _MUT == "bootstrap_ohne_tage" else int(f["ts"]) // 86400
        a = tage.setdefault(t, [0, 0.0, 0.0, 0.0])
        a[0] += 1
        if art == "kov":
            a[1] += f["d"]
            a[2] += f["y"]
            a[3] += f["d"] * f["y"]
        else:
            a[1] += f["wert"]
    return [(t, a[0], a[1], a[2], a[3]) for t, a in sorted(tage.items())]


def _theta(art: str, n, s1, s2, s12) -> float:
    if art == "mittel":
        return s1 / n
    return s12 / n - (s1 / n) * (s2 / n)


def _psi(art: str, bloecke, n_ges, s1g, s2g, th) -> float:
    """Studentisierung: Standardfehler aus den linearisierten Blockbeiträgen."""
    tot = 0.0
    if art == "mittel":
        for n, a, _, _ in bloecke:
            tot += (a - th * n) ** 2
    else:
        dq, yq = s1g / n_ges, s2g / n_ges
        for n, a, b, ab in bloecke:
            tot += (ab - yq * a - dq * b + n * dq * yq - n * th) ** 2
    return math.sqrt(tot) / n_ges


def block_bootstrap(tage: list[tuple], art: str = "kov", ziehungen: int = 9999, block: int = 7, saat: int = 235) -> dict:
    """Studentisierter, zentrierter Blockbootstrap über Tage (R6): zirkuläre 7-Tage-Blöcke, p = (1 + #{T* ≥ T}) ÷ (B + 1),
    einseitig für θ > 0. Dazu ein 90-%-Intervall (Perzentil-t)."""
    k = len(tage)
    leer = {"n": sum(t[1] for t in tage), "tage": k, "mass": None, "se": None, "p": None, "lo": None, "hi": None}
    if k < 2:
        return leer
    n_g = sum(t[1] for t in tage)
    s1g = sum(t[2] for t in tage)
    s2g = sum(t[3] for t in tage)
    s12g = sum(t[4] for t in tage)
    th = _theta(art, n_g, s1g, s2g, s12g)
    b = min(block, k)
    orig = []
    for j in range(0, k, b):
        teil = tage[j:j + b]
        orig.append((sum(x[1] for x in teil), sum(x[2] for x in teil), sum(x[3] for x in teil), sum(x[4] for x in teil)))
    se0 = _psi(art, orig, n_g, s1g, s2g, th)
    if se0 <= 0:
        return dict(leer, mass=th, se=se0)
    T = th / se0
    kreis = []
    for st in range(k):
        teil = [tage[(st + i) % k] for i in range(b)]
        kreis.append((sum(x[1] for x in teil), sum(x[2] for x in teil), sum(x[3] for x in teil), sum(x[4] for x in teil)))
    nb = -(-k // b)
    rng = random.Random(saat)
    groesser = 0
    perz = 0
    ts_stern = []
    for _ in range(ziehungen):
        bl = [kreis[rng.randrange(k)] for _ in range(nb)]
        n = sum(x[0] for x in bl)
        s1 = sum(x[1] for x in bl)
        s2 = sum(x[2] for x in bl)
        s12 = sum(x[3] for x in bl)
        t_st = _theta(art, n, s1, s2, s12)
        se_st = _psi(art, bl, n, s1, s2, t_st)
        if t_st <= 0:
            perz += 1
        if se_st <= 0:
            continue
        tt = (t_st - th) / se_st
        ts_stern.append(tt)
        if tt >= T:
            groesser += 1
    p = (1 + groesser) / (ziehungen + 1)
    if _MUT == "bootstrap_perzentil":
        p = perz / ziehungen
    ts_stern.sort()
    q = (lambda a: ts_stern[min(len(ts_stern) - 1, int(a * len(ts_stern)))]) if ts_stern else (lambda a: 0.0)
    return {"n": n_g, "tage": k, "mass": th, "se": se0, "T": T, "p": p, "lo": th - q(0.95) * se0, "hi": th - q(0.05) * se0}


def haelften_median(faelle: list[dict], art: str) -> tuple:
    """Hälften am Median-Datum der Fälle (R6): (θ erste Hälfte, θ zweite Hälfte, n1, n2)."""
    f = sorted(faelle, key=lambda x: x["ts"])
    k = len(f) // 2
    aus = []
    for teil in (f[:k], f[k:]):
        if len(teil) < 2:
            aus.append(None)
            continue
        agg = _tagesaggregate(teil, art)
        aus.append(_theta(art, sum(a[1] for a in agg), sum(a[2] for a in agg), sum(a[3] for a in agg), sum(a[4] for a in agg)))
    return aus[0], aus[1], k, len(f) - k


def holm_gewichtet(p: dict, w: dict) -> dict:
    """Gewichteter Holm (R5): angepasste p-Werte; Gewichte auf die prüfbaren Tests normiert."""
    gueltig = {k: v for k, v in p.items() if v is not None}
    aus = {k: None for k in p}
    if _MUT == "holm_weg":
        return dict(p)
    if not gueltig:
        return aus
    summe = sum(w[k] for k in gueltig)
    gew = {k: w[k] / summe for k in gueltig}
    rest = set(gueltig)
    vorher = 0.0
    for k in sorted(gueltig, key=lambda x: gueltig[x] / gew[x]):
        wert = min(1.0, max(vorher, gueltig[k] * sum(gew[j] for j in rest) / gew[k]))
        aus[k] = wert
        vorher = wert
        rest.discard(k)
    return aus


def urteil(e: dict, p_holm, min_n: int, richtung: str = "positiv", min_tage: int = 0) -> str:
    """Vorab festgelegte Regel: angepasstes p < 0,05, richtiges Vorzeichen, beide Hälften (jede ≥ 40 % der Mindestzahl),
    Mindestzahl und Mindesttage."""
    if ((e.get("n") or 0) < min_n or (e.get("tage") or 0) < min_tage) and _MUT != "mindestzahl_ignoriert":
        return "nicht prüfbar"
    if p_holm is None or e.get("mass") is None:
        return "nicht prüfbar"
    h1, h2 = e.get("h1"), e.get("h2")
    halb_ok = h1 is not None and h2 is not None and min(e.get("n1") or 0, e.get("n2") or 0) >= 0.4 * min_n
    if richtung == "positiv":
        ok = p_holm < 0.05 and e["mass"] > 0
        halb_ok = halb_ok and h1 > 0 and h2 > 0
    else:
        ok = p_holm < 0.05 and e["mass"] < 0
        halb_ok = halb_ok and h1 < 0 and h2 < 0
    if _MUT != "haelften_ignoriert":
        ok = ok and halb_ok
    return "belegt" if ok else "nicht belegt"


def pruefe_h1(faelle: list[dict], ziehungen: int = 9999) -> dict:
    e = block_bootstrap(_tagesaggregate(faelle, "kov"), "kov", ziehungen)
    e["h1"], e["h2"], e["n1"], e["n2"] = haelften_median(faelle, "kov")
    nenner = sum((f["p_s"] - f["y"]) ** 2 for f in faelle)
    e["g"] = (sum(f["g"] for f in faelle) / len(faelle)) if faelle else None
    e["skill"] = (100.0 * sum(f["g"] for f in faelle) / nenner) if nenner > 0 else None
    meinung = [f for f in faelle if abs(f["d"]) > REIBUNG]
    e["treffer"] = (sum(1 for f in meinung if (f["d"] > 0) == (f["y"] == 1)) / len(meinung)) if meinung else None
    e["n_meinung"] = len(meinung)
    return e


# --- H2 -----------------------------------------------------------------------------------------------------------------

def _btcd_ereignisse(con, vorwaerts: bool = False) -> dict[str, list]:
    st = stichtag(con)
    if st is None:
        return {}
    op = ">=" if vorwaerts else "<"
    ereignisse: dict[str, list] = {}
    for row in con.execute("SELECT markt, ereignis, strike_typ, unten, oben, ende, handel_ab FROM pm_markt WHERE "
                           "plattform='kalshi' AND reihe='KXBTCD' AND ende IS NOT NULL AND ende " + op + " ?", (st,)):
        if et(int(row[5])).hour == 17:
            ereignisse.setdefault(row[1], []).append(row)
    return ereignisse


def h2_vorlauf(con, quelle: str = "k60m") -> dict:
    """Vorlauf nach Abdeckung, ohne Ergebnisse (R9): 24 h, wenn ≥ 80 % der Ereignisse dort einen gültigen Kurs haben, sonst der
    längste von 18, 12, 6 h mit derselben Regel."""
    ev = _btcd_ereignisse(con)
    anteile = {}
    for L in H2_VORLAEUFE:
        mit = 0
        for zeilen in ev.values():
            ende = int(max(r[5] for r in zeilen))
            t0 = ende - L
            if any(zustand(con, "kalshi", r[0], t0 - 3600, t0, quelle) for r in zeilen):
                mit += 1
        anteile[L] = mit / len(ev) if ev else 0.0
    wahl = next((L for L in H2_VORLAEUFE if anteile[L] >= 0.8), None)
    return {"vorlauf": wahl, "anteile": anteile, "ereignisse": len(ev)}


def _gewichte_abstand(ks: list[float]) -> list[float]:
    """Gewicht je Schwelle = halber Abstand zu den Nachbarn (diskrete CRPS-Differenz), normiert."""
    n = len(ks)
    if n == 1:
        return [1.0]
    w = []
    for i in range(n):
        links = ks[i] - ks[i - 1] if i > 0 else ks[i + 1] - ks[i]
        rechts = ks[i + 1] - ks[i] if i < n - 1 else ks[i] - ks[i - 1]
        w.append((links + rechts) / 2.0)
    s = sum(w)
    return [x / s for x in w]


def _btc_schwankung(con, bis: int):
    """Eine Spotreihe (Coinbase BTC-USD) und ein HAR für die ganze Stichprobe – kein Quellenwechsel (R9)."""
    q = SPOT_QUELLE["BTC"][0]
    r = con.execute("SELECT MIN(ts) FROM pm_spot WHERE coin='BTC' AND quelle=?", (q,)).fetchone()
    if not r or r[0] is None:
        return SpotReihe(), None
    sp = spot_laden(con, "BTC", r[0], bis)
    return sp, Schwankung(sp, makro_termine(con))


def faelle_h2(con, vorlauf: int, quelle: str = "k60m", echo: bool = False, vorwaerts: bool = False,
              nur_zaehlen: bool = False, spot=None):
    """H2: je 17:00-ET-Ereignis ein Fall (gewichtetes Tagesmittel von g über die zulässigen Schwellen).
    echo=True (Nullprobe R12): „Markt“ = dasselbe Modell mit dem Spot einer zweiten Börse (Binance) statt des Kalshi-Kurses."""
    erg = {} if nur_zaehlen else ergebnisse(con, "kalshi")
    ev = _btcd_ereignisse(con, vorwaerts)
    z = {"ereignisse": len(ev), "kein_spot": 0, "keine_schwelle": 0}
    termine = makro_termine(con)
    bis = max([int(max(r[5] for r in zz)) for zz in ev.values()] or [0]) + 86400
    sp_b, sw = spot if spot is not None else _btc_schwankung(con, bis)
    faelle, einzeln = [], []
    for ereignis, zeilen in sorted(ev.items(), key=lambda kv: max(r[5] for r in kv[1])):
        ende = int(max(r[5] for r in zeilen))
        t0 = ende - vorlauf
        s = sp_b.schluss_bis(t0, 300)
        v = sw.sigma2(t0, vorlauf) if sw is not None else None
        if s is None or v is None:
            z["kein_spot"] += 1
            continue
        sig_tau = math.sqrt(v)
        s_auswahl = sp_b.schluss_bis(ende, 300) if _MUT == "auswahl_bei_ablauf" else s
        s_echo = None
        if echo:
            s_echo = spot_laden(con, "BTC", t0 - 600, t0 + 60, ECHO_QUELLE[0]).schluss_bis(t0, 300)
            if s_echo is None:
                z["kein_spot"] += 1
                continue
        kand = []
        for markt, _, art, unten, oben, _, handel_ab in zeilen:
            k = unten if unten is not None else oben
            if not k or k <= 0 or s_auswahl is None:
                continue
            if _MUT != "schwelle_nach_t0":
                if handel_ab is not None and int(handel_ab) > t0:
                    continue
                w = zustand(con, "kalshi", markt, t0 - 3600, t0, quelle)
            else:
                w = zustand(con, "kalshi", markt, t0 - 3600, t0 + 7200, quelle)
            if not w or abs(math.log(k / s_auswahl)) > 2 * sig_tau:
                continue
            kand.append((k, markt, art, unten, oben, w[1]))
        if not kand:
            z["keine_schwelle"] += 1
            continue
        if nur_zaehlen:
            faelle.append({"ts": ende, "n_schwellen": len(kand)})
            continue
        kand.sort()
        gew = _gewichte_abstand([x[0] for x in kand])
        g_tag, gw = 0.0, 0.0
        for (k, markt, art, unten, oben, pm), wk in zip(kand, gew):
            e = erg.get(markt)
            if not e or e[0] not in (0, 1):
                continue
            ps = p_schwelle(art, unten, oben, s, sig_tau)
            if echo:
                pm = p_schwelle(art, unten, oben, s_echo, sig_tau)
            if ps is None or pm is None:
                continue
            g = brier_zugewinn(ps, pm, e[0])
            g_tag += wk * g
            gw += wk
            einzeln.append({"ts": ende, "p_m": pm, "p_s": ps, "y": int(e[0]), "g": g, "k": k, "s": s, "sig": sig_tau,
                            "markt": markt, "t0": t0})
        if gw > 0:
            faelle.append({"ts": ende, "wert": g_tag / gw, "n_schwellen": len(kand),
                           "termin": any(t0 <= t < ende for t in termine), "wochenende": et(t0).weekday() >= 4})
    z["faelle"] = len(faelle)
    return faelle, z, einzeln


def pruefe_h2(faelle: list[dict], einzeln: list[dict], ziehungen: int = 9999) -> dict:
    e = block_bootstrap(_tagesaggregate(faelle, "mittel"), "mittel", ziehungen)
    e["h1"], e["h2"], e["n1"], e["n2"] = haelften_median(faelle, "mittel")
    nenner = sum((f["p_s"] - f["y"]) ** 2 for f in einzeln)
    e["skill"] = (100.0 * sum(f["g"] for f in einzeln) / nenner) if nenner > 0 else None
    e["schwellen"] = len(einzeln)
    return e


# --- H3 -----------------------------------------------------------------------------------------------------------------

def makro_termine(con) -> list[int]:
    """Veröffentlichungen (08:30 ET) und Fed-Beschlüsse (Handelsschluss) aus den Kalshi-Makroreihen – nur Metadaten."""
    aus = set()
    for reihe, ende in con.execute("SELECT DISTINCT reihe, ende FROM pm_markt WHERE plattform='kalshi' AND art IN "
                                   "('makro','ereignis') AND ende IS NOT NULL"):
        t = makro_termin(int(ende))
        if t:
            aus.add(t)
        elif reihe in ("KXFED", "KXFEDDECISION") and 13 <= et(int(ende)).hour <= 15:
            aus.add(int(ende))
    return sorted(aus)


def _leiter_punkt(art: str, unten, oben, p: float, schritt) -> tuple[float, float] | None:
    """Punkt (Klassengrenze, P(X > Grenze)). Auf dem Raster: Klassen [v − Schritt/2, v + Schritt/2) (R10)."""
    a = (art or "").lower()
    h = (schritt / 2.0) if schritt else 0.0
    if _MUT == "leiter_bin_verschoben":
        h += schritt or 0.0

    def raster(k):
        return bool(schritt) and abs(k / schritt - round(k / schritt)) < 1e-6
    if a == "greater" and unten is not None:
        return (unten + h if raster(unten) else unten), p
    if a == "greater_or_equal" and unten is not None:
        return (unten - h if raster(unten) else unten), p
    if a == "less" and oben is not None:
        return (oben - h if raster(oben) else oben), 1.0 - p
    if a == "less_or_equal" and oben is not None:
        return (oben + h if raster(oben) else oben), 1.0 - p
    return None


def h3_kursquelle(con, reihe: str = "KXCPI", quelle: str = "k1m") -> dict:
    """Eine Kursquelle für alle Termine (R10): Mitte, wenn 1-min-Geld/Brief bei ≥ 90 % der Termine vorliegt, sonst letzte
    Trades für alle. Entscheidung ohne Ergebnisse."""
    gruppen = _makro_gruppen(con, reihe)
    mit, n = 0, 0
    for ereignis, (termin, zeilen) in gruppen.items():
        n += 1
        schluss = min(min(int(r[5]) for r in zeilen), termin)
        if sum(1 for r in zeilen if zustand(con, "kalshi", r[0], schluss - 3600, schluss, quelle)) >= 4:
            mit += 1
    return {"art": "mitte" if n and mit / n >= 0.9 else "trade", "anteil_mitte": (mit / n) if n else None, "termine": n}


def _makro_gruppen(con, reihe: str) -> dict:
    """Termine einer Reihe vor dem Stichtag, nach Metadaten bereinigt (R10)."""
    st = stichtag(con)
    if st is None:
        return {}
    gruppen: dict[str, list] = {}
    for row in con.execute("SELECT markt, ereignis, strike_typ, unten, oben, ende FROM pm_markt WHERE plattform='kalshi' "
                           "AND reihe=? AND ende IS NOT NULL AND ende < ?", (reihe, st)):
        gruppen.setdefault(row[1], []).append(row)
    aus = {}
    for ereignis, zeilen in gruppen.items():
        if any(str(ereignis).startswith(x) for x in SHUTDOWN_2025):
            continue
        termine = [makro_termin(int(r[5])) for r in zeilen]
        termine = [t for t in termine if t]
        if not termine:
            continue
        aus[ereignis] = (max(set(termine), key=termine.count), zeilen)
    return aus


def _letzter_trade(con, markt: str, von: int, bis: int, quelle: str):
    r = con.execute("SELECT ts, letzter FROM pm_kurs WHERE plattform='kalshi' AND markt=? AND quelle=? AND ts<=? AND ts>=? "
                    "AND letzter IS NOT NULL ORDER BY ts DESC LIMIT 1", (markt, quelle, int(bis), int(von))).fetchone()
    return (int(r[0]), r[1] / 10000.0) if r else None


def ueberraschungen_berechnen(con, reihe: str = "KXCPI", quelle: str = "k1m", kursart: str = "mitte") -> dict:
    """Je Termin: Leiter zum letzten gültigen Kurs vor min(Handelsschluss, 08:30 ET), höchstens 60 min alt → m, s;
    u = x − m (primär), z = u ÷ s (beschreibend, s ≥ 0,05). Renditen: Kerze mit Beginn 08:30 ET, Placebos 08:00 und Vorwoche."""
    schritt = KALSHI_REIHEN.get(reihe, {}).get("schritt")
    erg = ergebnisse(con, "kalshi")
    z = {"termine": 0, "zu_wenig_schwellen": 0, "quantil_ausserhalb": 0, "kein_istwert": 0, "ok": 0}
    jetzt = int(time.time())
    with schreiben(con):
        for ereignis, (termin, zeilen) in _makro_gruppen(con, reihe).items():
            z["termine"] += 1
            punkte, stand, ist = [], None, None
            for markt, _, art, unten, oben, ende in zeilen:
                e = erg.get(markt)
                if e and e[1] is not None:
                    ist = e[1]
                schluss = min(int(ende), termin)
                if _MUT == "leiter_nach_termin":
                    schluss = termin + 600
                w = (zustand(con, "kalshi", markt, schluss - 3600, schluss, quelle) if kursart == "mitte"
                     else _letzter_trade(con, markt, schluss - 3600, schluss, quelle))
                if not w:
                    continue
                pkt = _leiter_punkt(art, unten, oben, w[1], schritt)
                if pkt:
                    punkte.append(pkt)
                    stand = max(stand or 0, w[0])
            if len(punkte) < 4:
                z["zu_wenig_schwellen"] += 1
                continue
            v = leiter_verteilung(punkte)
            if not v or v["median"] is None or v["q16"] is None or v["q84"] is None:
                z["quantil_ausserhalb"] += 1
                continue
            if ist is None:
                z["kein_istwert"] += 1
                continue
            u = (v["median"] - ist) if _MUT == "u_vorzeichen" else (ist - v["median"])
            zz = u / max(v["streuung"] or 0.0, 0.05)

            def rendite(coin, beginn):
                k = con.execute("SELECT o, c FROM pm_spot WHERE coin=? AND quelle='perp30' AND ts=?", (coin, beginn)).fetchone()
                return math.log(k[1] / k[0]) if k and k[0] and k[1] else None
            b30 = termin - 1800 if _MUT == "rendite_davor" else termin
            con.execute("INSERT OR REPLACE INTO pm_ueberraschung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (reihe, termin, ereignis, stand, quelle + ":" + kursart, v["median"], v["streuung"], len(punkte),
                         None, ist, None, u, zz, rendite("BTC", b30), rendite("BTC", termin - 1800),
                         rendite("BTC", termin - 7 * 86400), rendite("ETH", termin), jetzt))
            z["ok"] += 1
    return z


def pruefe_h3(con, reihe: str = "KXCPI", perm: int = 10000, spalte: str = "r30_btc") -> dict:
    zeilen = con.execute("SELECT termin, u, " + spalte + " FROM pm_ueberraschung WHERE reihe=? AND u IS NOT NULL AND "
                         + spalte + " IS NOT NULL ORDER BY termin", (reihe,)).fetchall()
    x = [r[1] for r in zeilen]
    y = [r[2] for r in zeilen]
    n = len(x)
    if n < 3:
        return {"n": n, "tage": n, "mass": None, "p": None, "h1": None, "h2": None}
    sp = spearman_permutation(x, y, perm, seite="negativ")
    k = n // 2
    return {"n": n, "tage": n, "mass": sp["rho"], "p": sp["p"], "h1": spearman(x[:k], y[:k]) if k >= 3 else None,
            "h2": spearman(x[k:], y[k:]) if n - k >= 3 else None, "n1": k, "n2": n - k}


# --- Freigabe, Prüfungen vor dem Urteil, gemeinsames Urteil -------------------------------------------------------------

def abdeckung(con, teil: str) -> dict:
    """R3: Anteil erledigter (geholt oder mit Grund gescheitert) unter den gelisteten Arbeitsschritten eines Teils."""
    st = meta(con, "rb:" + teil, {}) or {}
    r = con.execute("SELECT COUNT(*), SUM(erledigt) FROM pm_rb WHERE teil=?", (teil,)).fetchone()
    n, e = (r[0] or 0), (r[1] or 0)
    return {"fertig": bool(st.get("fertig")), "liste": n, "erledigt": e, "anteil": (e / n) if n else 1.0,
            "abgebrochen": st.get("abgebrochen")}


def freigabe(con) -> tuple[bool, str]:
    """Gemeinsames Urteil erst, wenn Stichtag gesetzt und alle Teile fertig mit ≥ 95 % Abdeckung sind (R2–R5)."""
    if stichtag(con) is None:
        return False, "kein Stichtag (Erstlauf fehlt)"
    fehlend = []
    for t in RB_TEILE_URTEIL:
        a = abdeckung(con, t)
        if not a["fertig"] or a["anteil"] < 0.95:
            fehlend.append(t)
    if _MUT == "urteile_einzeln" and len(fehlend) < len(RB_TEILE_URTEIL):
        return True, ""
    return (not fehlend), ("offen: " + ", ".join(fehlend) if fehlend else "")


def pruefungen_vor_urteil(con, f1: list[dict], einzeln2: list[dict], vorlauf: int | None, welten: int = 200,
                          ziehungen: int = 999) -> list[tuple[str, bool, str]]:
    """R12: Positivkontrollen und Nullproben auf echten Daten; alle müssen bestehen."""
    aus = []
    fb, _ = faelle_h1(con, versatz=600)
    e = block_bootstrap(_tagesaggregate(fb, "kov"), "kov", ziehungen)
    aus.append(("H1 Markt bei B + 10 min", (e.get("T") or 0) > 5, "T " + _de(e.get("T"), 1) + ", n " + str(e.get("n"))))
    erg = ergebnisse(con, "kalshi")
    gleich = {">": 0, ">=": 0}
    n = 0
    for markt, unten in con.execute("SELECT markt, unten FROM pm_markt WHERE plattform='kalshi' AND reihe='KXBTC15M' "
                                    "AND unten IS NOT NULL"):
        e2 = erg.get(markt)
        if e2 and e2[1] is not None and e2[0] in (0, 1):
            n += 1
            gleich[">"] += int((e2[1] > unten) == (e2[0] == 1))
            gleich[">="] += int((e2[1] >= unten) == (e2[0] == 1))
    beste = max(gleich.values()) / n if n else None
    aus.append(("H1 floor_strike/expiration_value ergeben result", n == 0 or beste >= 0.999,
                ("nicht geliefert" if n == 0 else _pz(beste, 2) + " von " + str(n))))
    kal_p, kal_y = [], []
    for markt, ende in con.execute("SELECT markt, ende FROM pm_markt WHERE plattform='kalshi' AND reihe='KXBTCD' AND "
                                   "ende < ?", (stichtag(con) or 0,)):
        e2 = erg.get(markt)
        if not e2 or e2[0] not in (0, 1):
            continue
        for L in (3600, 7200, 10800, 14400, 18000, 21600):
            w = zustand(con, "kalshi", markt, int(ende) - L - 3600, int(ende) - L, "k60m")
            if w and 0.02 < w[1] < 0.98:
                kal_p.append(w[1])
                kal_y.append(int(e2[0]))
    k = kalibrierung(kal_p, kal_y)
    aus.append(("H2 Kalibrierungssteigung 1–6 h", k["b"] is not None and 0.8 <= k["b"] <= 1.25,
                "b " + _de(k["b"], 2) + ", n " + str(k["n"])))
    fehler = [abs(r[1] - r[0]) for r in con.execute(
        "SELECT median, ist FROM pm_ueberraschung WHERE reihe='KXCPI' AND termin BETWEEN ? AND ?",
        (utc_ts(datetime(2022, 1, 1, tzinfo=UTC)), utc_ts(datetime(2026, 1, 1, tzinfo=UTC))))]
    mae = sum(fehler) / len(fehler) if fehler else None
    aus.append(("H3 Fehler des Kalshi-Medians 2022–2025", mae is not None and 0.04 <= mae <= 0.09,
                "MAE " + _de(mae, 3) + ", n " + str(len(fehler))))
    a = [abs(r[0]) for r in con.execute("SELECT r30_btc FROM pm_ueberraschung WHERE reihe='KXCPI' AND r30_btc IS NOT NULL")]
    b = [abs(r[0]) for r in con.execute("SELECT r30_vorwoche FROM pm_ueberraschung WHERE reihe='KXCPI' AND "
                                        "r30_vorwoche IS NOT NULL")]
    v = (sum(a) / len(a)) / (sum(b) / len(b)) if a and b and sum(b) > 0 else None
    aus.append(("H3 |Rendite| an CPI-Tagen ≥ 1,5 × Vorwoche", v is not None and v >= 1.5, "Faktor " + _de(v, 2)))
    # Nullproben auf echten Ergebnisfolgen (H1) und mit Spot-Echo (H2)
    if f1:
        sd = math.sqrt(sum(f["d"] ** 2 for f in f1) / len(f1)) or 0.01
        belegt = 0
        for w in range(welten):
            rng = random.Random(9000 + w)
            tage = sorted({f["ts"] // 86400 for f in f1})
            je_tag: dict[int, list] = {}
            for f in f1:
                je_tag.setdefault(f["ts"] // 86400, []).append(f)
            neu = []
            nb = -(-len(tage) // 7)
            for j in range(nb):
                st = rng.randrange(len(tage))
                for i in range(7):
                    t = tage[(st + i) % len(tage)]
                    for f in je_tag[t]:
                        neu.append({"ts": (j * 7 + i) * 86400 + f["ts"] % 86400, "d": rng.gauss(0.0, sd), "y": f["y"]})
            ee = block_bootstrap(_tagesaggregate(neu, "kov"), "kov", ziehungen, saat=w)
            ee["h1"], ee["h2"], ee["n1"], ee["n2"] = haelften_median(neu, "kov")
            belegt += urteil(ee, ee["p"], MIN_N["H1"], min_tage=MIN_TAGE["H1"]) == "belegt"
        grenze = 0.05 + 2.326 * math.sqrt(0.05 * 0.95 / welten)
        aus.append(("Nullprobe H1 auf echten Ergebnisfolgen", belegt / welten <= grenze, _pz(belegt / welten)))
    if vorlauf and einzeln2:
        echo, _, _ = faelle_h2(con, vorlauf, echo=True)
        if len(echo) >= 2:
            echo.sort(key=lambda f: f["ts"])
            werte = [f["wert"] for f in echo]
            k = len(werte)
            wn = min(welten, 100)
            belegt = 0
            for w in range(wn):
                rng = random.Random(7000 + w)
                neu = []
                for j in range(-(-k // 7)):
                    st = rng.randrange(k)
                    for i in range(7):
                        neu.append({"ts": (j * 7 + i) * 86400, "wert": werte[(st + i) % k]})
                ee = block_bootstrap(_tagesaggregate(neu, "mittel"), "mittel", ziehungen, saat=w)
                ee["h1"], ee["h2"], ee["n1"], ee["n2"] = haelften_median(neu, "mittel")
                belegt += urteil(ee, ee["p"], MIN_N["H2"], min_tage=MIN_TAGE["H2"]) == "belegt"
            grenze = 0.05 + 2.326 * math.sqrt(0.05 * 0.95 / wn)
            aus.append(("Nullprobe H2 Spot-Echo (Binance statt Coinbase)", belegt / wn <= grenze, _pz(belegt / wn)))
    return aus


def auswerten(con, lauf: int | None = None, ziehungen: int = 9999, perm: int = 10000) -> dict:
    """Vor dem Urteil nur Zählung (R4). Danach einmal das gemeinsame Urteil (R5) mit Prüfungen vor dem Urteil (R12); später
    nur noch Anzeige des Urteils und – nach R11 – die Vorwärtsrunde."""
    lauf = int(lauf or time.time())
    frueher = con.execute("SELECT MIN(lauf) FROM pm_auswertung WHERE endgueltig=1").fetchone()[0]
    if frueher:
        return {"lauf": lauf, "urteil_vom": frueher, "phase": "urteil"}
    zaehl = {"H1": zaehlung_h1(con)}
    vl = h2_vorlauf(con)
    zaehl["H2_vorlauf"] = vl
    if vl["vorlauf"]:
        f2z, z2z, _ = faelle_h2(con, vl["vorlauf"], nur_zaehlen=True)
        zaehl["H2"] = {"tage": len(f2z), **z2z}
    qa = h3_kursquelle(con)
    zaehl["H3_quelle"] = qa
    ok, grund = freigabe(con)
    with schreiben(con):
        meta_setzen(con, "zaehlung", {"lauf": lauf, "zaehlung": zaehl, "freigabe": ok, "grund": grund})
    if not ok:
        return {"lauf": lauf, "phase": "zaehlung", "zaehlung": zaehl, "grund": grund}
    f1, z1 = faelle_h1(con)
    e1 = pruefe_h1(f1, ziehungen)
    e1["zaehler"] = z1
    e2, einzeln2 = {"n": 0, "tage": 0, "mass": None, "p": None}, []
    if vl["vorlauf"]:
        f2, z2, einzeln2 = faelle_h2(con, vl["vorlauf"])
        e2 = pruefe_h2(f2, einzeln2, ziehungen)
        e2["zaehler"] = z2
    z3 = ueberraschungen_berechnen(con, "KXCPI", "k1m", qa["art"])
    e3 = pruefe_h3(con, "KXCPI", perm)
    e3["zaehler"] = z3
    pa = pruefe_h3(con, "KXCPI", perm, "r30_davor")
    pb = pruefe_h3(con, "KXCPI", perm, "r30_vorwoche")
    plac_ok = all(x.get("mass") is None or min(x["p"], 1 - x["p"] + 1.0 / (perm + 1)) * 2 > 0.05 for x in (pa, pb))
    e3["placebo"] = {"davor": pa.get("mass"), "vorwoche": pb.get("mass"), "bestanden": plac_ok}
    vor = pruefungen_vor_urteil(con, f1, einzeln2, vl["vorlauf"])
    alle_ok = all(b for _, b, _ in vor)
    pruef = {"H1": e1, "H2": e2, "H3": e3}
    testbar = {k: e["p"] for k, e in pruef.items() if (e.get("n") or 0) >= MIN_N[k] and (e.get("tage") or 0) >= MIN_TAGE[k]
               and e.get("p") is not None and (k != "H3" or plac_ok)}
    ph = holm_gewichtet({k: testbar.get(k) for k in pruef}, GEWICHT)
    with schreiben(con):
        if con.execute("SELECT 1 FROM pm_auswertung WHERE endgueltig=1 LIMIT 1").fetchone():
            return {"lauf": lauf, "phase": "urteil", "hinweis": "Urteil schon von einem anderen Lauf geschrieben"}
        meta_setzen(con, "pruefungen_vor_urteil", {"lauf": lauf, "liste": vor})
        for k, e in pruef.items():
            e["p_holm"] = ph.get(k)
            if not alle_ok:
                e["urteil"] = "kein Urteil (Prüfung vor dem Urteil nicht bestanden)"
            elif k == "H3" and not plac_ok:
                e["urteil"] = "ungültig (Placebo nicht null)"
            else:
                e["urteil"] = urteil(e, ph.get(k), MIN_N[k], "negativ" if k == "H3" else "positiv", MIN_TAGE[k])
            details = {x: e.get(x) for x in ("se", "T", "g", "skill", "treffer", "n_meinung", "n1", "n2", "zaehler",
                                             "schwellen", "placebo")}
            con.execute("INSERT OR REPLACE INTO pm_auswertung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (k, lauf, e.get("n"), e.get("tage"), e.get("mass"), e.get("lo"), e.get("hi"),
                         e.get("p") if alle_ok else None, e.get("p_holm") if alle_ok else None,
                         e.get("h1") if alle_ok else None, e.get("h2") if alle_ok else None, e["urteil"],
                         1 if alle_ok else 0, VERSION_AUSWERTUNG,
                         json.dumps(details if alle_ok else {"zaehler": e.get("zaehler")}, ensure_ascii=False, default=str)))
    aus = {"lauf": lauf, "phase": "urteil" if alle_ok else "pruefung_nicht_bestanden", "vor_urteil": vor, **pruef}
    if alle_ok:
        aus["beschreibend"] = beschreibend(con, f1, einzeln2, ziehungen)
        with schreiben(con):
            meta_setzen(con, "beschreibend", {"lauf": lauf, "werte": aus["beschreibend"]})
    return aus


def beschreibend(con, f1: list[dict], einzeln2: list[dict], ziehungen: int = 2000) -> dict:
    """R13: nur Effektgrößen mit Blockintervall, ohne p-Werte, erst nach dem Urteil."""
    b: dict = {}
    for reihe in ("KXETH15M", "KXHYPE15M", "KXZEC15M"):
        f, zz = faelle_h1(con, reihe)
        e = block_bootstrap(_tagesaggregate(f, "kov"), "kov", ziehungen) if f else {"n": 0}
        b[reihe] = {"n": e.get("n"), "c": e.get("mass"), "lo": e.get("lo"), "hi": e.get("hi"), "zaehler": zz}
    if f1:
        b["kalibrierung_H1"] = kalibrierung([f["p_m"] for f in f1], [f["y"] for f in f1])
        alt = [f for f in f1 if f["ts"] < 1_784_764_800]   # vor 23.07.2026: ganze Cent
        neu = [f for f in f1 if f["ts"] >= 1_784_764_800]
        for name, teil in (("tick_cent", alt), ("tick_teilcent", neu)):
            if teil:
                e = block_bootstrap(_tagesaggregate(teil, "kov"), "kov", ziehungen)
                b[name] = {"n": e["n"], "c": e["mass"], "lo": e["lo"], "hi": e["hi"]}
    if einzeln2:
        b["kalibrierung_H2_markt"] = kalibrierung([f["p_m"] for f in einzeln2], [f["y"] for f in einzeln2])
        b["kalibrierung_H2_modell"] = kalibrierung([f["p_s"] for f in einzeln2], [f["y"] for f in einzeln2])
        b["lagetest_H2"] = lagetest(einzeln2)
    for reihe in ("KXU3", "KXPAYROLLS", "KXCPIYOY"):
        ueberraschungen_berechnen(con, reihe, "k1m")
        e = pruefe_h3(con, reihe, 2000)
        b["makro_" + reihe] = {"n": e.get("n"), "rho": e.get("mass")}
    return b


def lagetest(einzeln: list[dict]) -> dict | None:
    """Markt gegen ein Mischmodell aus Median des Modells (S bei t0) und der Breite der Leiter: Gewinn = Richtungsanteil."""
    tage: dict[int, list] = {}
    for f in einzeln:
        tage.setdefault(f["t0"], []).append(f)
    g = []
    for t0, liste in tage.items():
        pts = [(f["k"], f["p_m"]) for f in liste if 0.0 < f["p_m"] < 1.0]
        v = leiter_verteilung(pts) if len(pts) >= 2 else None
        if not v or not v["q16"] or not v["q84"] or v["q16"] <= 0:
            continue
        sig_m = (math.log(v["q84"]) - math.log(v["q16"])) / 2.0
        if sig_m <= 0:
            continue
        for f in liste:
            ph = p_ueber(f["s"], f["k"], sig_m)
            g.append((f["ts"], brier_zugewinn(ph, f["p_m"], f["y"])))
    if not g:
        return None
    return {"n": len(g), "g_mittel": sum(x for _, x in g) / len(g)}


def beobachtungen_im_fenster(con, plattform: str, markt: str, beginn: int, ende: int, quelle: str) -> list[tuple[int, float]]:
    """Beobachtungen im Fenster (beginn, ende − 60]: die letzte Minute zählt nie (Regel 1.4)."""
    grenze = int(ende) if _MUT == "letzte_minute" else int(ende) - 60
    aus = []
    for ts, geld, brief in con.execute("SELECT ts, geld, brief FROM pm_kurs WHERE plattform=? AND markt=? AND quelle=? AND "
                                       "ts>? AND ts<=? ORDER BY ts", (plattform, markt, quelle, int(beginn), grenze)):
        m = mitte(geld, brief)
        if m is not None:
            aus.append((int(ts), m / 10000.0))
    return aus


# ---------------------------------------------------------------------------
# 12. Berichte und Nutzlast
# ---------------------------------------------------------------------------

def _de(x, stellen: int = 3) -> str:
    if x is None:
        return "–"
    if isinstance(x, float) and x != x:
        return "–"
    return f"{x:,.{stellen}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _pz(x, stellen: int = 1) -> str:
    return "–" if x is None else _de(100.0 * x, stellen) + " %"


def _uhr(ts) -> str:
    return "–" if not ts else von_ts(int(ts)).strftime("%d.%m.%Y %H:%M UTC")


def _vor_min(jetzt, ts) -> str:
    """Alter in ganzen Minuten, nie negativ (U236: eine Antwort Sekunden nach der Berichtszeit ergab „vor -0 min“)."""
    return _de(max(0.0, (int(jetzt) - int(ts)) / 60.0), 0)


_IP_MUSTER = re.compile(r'"ip"\s*:\s*"[^"]*"\s*,?\s*')


def ohne_ip(text: str) -> str:
    """U236: die öffentliche IP-Adresse aus der Geoblock-Antwort von Polymarket entfernen (Ausgabe und gespeicherter Erstlauf)."""
    if _MUT == "ip_ausgeben":
        return str(text)
    return _IP_MUSTER.sub("", str(text))


def geoblock_kurz(d):
    """U236: von der Geoblock-Antwort nur Sperre, Land und Region (ohne IP-Adresse)."""
    if _MUT == "ip_ausgeben" or not isinstance(d, dict):
        return d
    return {k: d.get(k) for k in ("blocked", "country", "region") if k in d}


def erstlauf_ohne_ip(con) -> bool:
    """U236: den gespeicherten Erstlauf (pm_meta 'erstlauf') von der IP-Adresse befreien. True, wenn geändert."""
    el = meta(con, "erstlauf", {}) or {}
    t = el.get("text")
    if not t:
        return False
    neu = [ohne_ip(x) for x in t] if isinstance(t, list) else ohne_ip(t)
    if neu == t:
        return False
    el["text"] = neu
    with schreiben(con):
        meta_setzen(con, "erstlauf", el)
    return True


TITEL = {"H1": "H1 Kalshi BTC 15 min: Kurs vor dem Fensterbeginn (B − 60 s) gegen 50 %",
         "H2": "H2 Kalshi-Tagesleiter 17:00 ET: Verteilungsgüte gegen das beste kausale Modell (kein Richtungstest)",
         "H3": "H3 Kalshi-Inflationsüberraschung (CPI m/m, u = x − m) gegen BTC 08:30–09:00 ET"}


def holm_text(con, lauf) -> str:
    """Gewichte des Holm-Verfahrens im Kopf des Urteils: R5 normiert auf die prüfbaren Tests (U236: der Kopf nannte bis 23.88
    immer die ursprünglichen Gewichte)."""
    pruefbar = [pr for pr in ("H1", "H2", "H3") if (con.execute(
        "SELECT p_holm FROM pm_auswertung WHERE pruefung=? AND lauf=?", (pr, lauf)).fetchone() or (None,))[0] is not None]
    if not pruefbar or len(pruefbar) == 3:
        return "gewichteter Holm: H3 0,5, H1 0,25, H2 0,25"
    s = sum(GEWICHT[k] for k in pruefbar)
    return ("gewichteter Holm, auf die prüfbaren Tests normiert: " + ", ".join(k + " " + _de(GEWICHT[k] / s, 2) for k in pruefbar)
            + "; nicht prüfbar: " + ", ".join(k for k in ("H1", "H2", "H3") if k not in pruefbar))


def bericht_auswertung(con) -> str:
    z = ["★ Prognosemärkte: Auswertung (U235, " + VERSION_AUSWERTUNG + ")"]
    st = stichtag(con)
    z.append("Stichtag des Rückblicks: " + (_uhr(st) if st else "noch nicht gesetzt (Erstlauf fehlt)") + ". Keine Prüfung wirkt "
             "auf Prognosen, Treiber oder Labor.")
    endg = con.execute("SELECT MIN(lauf) FROM pm_auswertung WHERE endgueltig=1").fetchone()[0]
    pv = meta(con, "pruefungen_vor_urteil", {}) or {}
    if not endg:
        zl = meta(con, "zaehlung", {}) or {}
        z.append("Phase: Zählung. Bis zum gemeinsamen Urteil stehen hier nur Anzahlen und Abdeckung (Nachtrag R4).")
        zz = zl.get("zaehlung") or {}
        h1 = zz.get("H1") or {}
        if h1:
            z.append("  H1: " + _de(h1.get("mit_kurs", 0), 0) + " von " + _de(h1.get("maerkte", 0), 0) + " Fenstern mit gültigem "
                     "Kurs vor dem Beginn, an " + str(h1.get("tage", 0)) + " Tagen (nötig: 4.000 Fenster und 60 Tage).")
        vl = zz.get("H2_vorlauf") or {}
        if vl:
            z.append("  H2: Vorlauf " + (str(vl["vorlauf"] // 3600) + " h" if vl.get("vorlauf") else "keiner erreicht 80 %")
                     + "; Abdeckung " + ", ".join(str(int(k) // 3600) + " h " + _pz(v, 0) for k, v in
                                                   (vl.get("anteile") or {}).items()) + "; Ereignisse " + str(vl.get("ereignisse", 0))
                     + ((", davon mit zulässigen Schwellen " + str((zz.get("H2") or {}).get("tage", 0))) if zz.get("H2") else "")
                     + " (nötig: 100).")
        q = zz.get("H3_quelle") or {}
        if q:
            z.append("  H3: " + str(q.get("termine", 0)) + " Termine nach Ausschlüssen; Kursquelle " + str(q.get("art"))
                     + " (Mitte bei " + _pz(q.get("anteil_mitte"), 0) + " der Termine; nötig ≥ 90 %).")
        z.append("  Freigabe des Urteils: " + ("ja" if zl.get("freigabe") else "nein – " + str(zl.get("grund") or "–")) + ".")
        if pv.get("liste"):
            z.append("Prüfungen vor dem Urteil (Lauf " + _uhr(pv.get("lauf")) + "):")
            for name, ok, wert in pv["liste"]:
                z.append("  " + ("bestanden " if ok else "NICHT bestanden ") + name + ": " + str(wert))
            z.append("  Ohne alle Prüfungen kein Urteil; der Grund wird vor einem neuen Lauf als Nachtrag behoben.")
        return "\n".join(z)
    z.append("Gemeinsames Urteil vom " + _uhr(endg) + " (" + holm_text(con, endg) + ").")
    for pr in ("H1", "H2", "H3"):
        row = con.execute("SELECT n, tage, mass, lo, hi, p, p_holm, h1, h2, urteil, details FROM pm_auswertung WHERE "
                          "pruefung=? AND lauf=?", (pr, endg)).fetchone()
        if not row:
            continue
        n, tage, mass, lo, hi, p, ph, h1, h2, urt, det = row
        d = json.loads(det or "{}")
        z.append("")
        z.append(TITEL[pr])
        if pr == "H3":
            z.append("  n = " + str(n or 0) + " Termine; Spearman ρ = " + _de(mass) + ", p (Permutation, einseitig) = " + _de(p, 4)
                     + ", angepasst " + _de(ph, 4) + "; Hälften ρ = " + _de(h1) + " / " + _de(h2) + ".")
            pl = d.get("placebo") or {}
            z.append("  Placebos: ρ gegen 08:00–08:30 ET " + _de(pl.get("davor")) + ", gegen Vorwoche " + _de(pl.get("vorwoche"))
                     + (" (bestanden)" if pl.get("bestanden") else " (NICHT bestanden)") + ".")
        else:
            mass_name = "Kovarianz c" if pr == "H1" else "mittlerer gewichteter Brier-Zugewinn je Tag"
            z.append("  n = " + _de(n or 0, 0) + (" Fenster" if pr == "H1" else " Ereignistage") + " an " + _de(tage or 0, 0)
                     + " Tagen; " + mass_name + " " + _de(mass, 6) + " (90 %: " + _de(lo, 6) + " bis " + _de(hi, 6)
                     + "), p einseitig " + _de(p, 4) + ", angepasst " + _de(ph, 4) + "; Hälften " + _de(h1, 6) + " / "
                     + _de(h2, 6) + ".")
            if pr == "H1":
                z.append("  Effektgrößen: Brier-Zugewinn " + _de(d.get("g"), 6) + ", Skill " + _de(d.get("skill"), 2)
                         + " %, Trefferquote außerhalb des Reibungsbands " + _pz(d.get("treffer")) + " (n = "
                         + str(d.get("n_meinung") or 0) + ").")
            else:
                z.append("  Brier-Skill gegen das Modell (alle Schwellen) " + _de(d.get("skill"), 2) + " %; Schwellen "
                         + str(d.get("schwellen") or 0) + ".")
        zz = d.get("zaehler") or {}
        if zz:
            z.append("  Ausfälle: " + ", ".join(k + " " + str(v) for k, v in zz.items()) + ".")
        z.append("  Urteil: " + str(urt) + ".")
    if pv.get("liste"):
        z.append("")
        z.append("Prüfungen vor dem Urteil: " + "; ".join(name + " " + str(wert) for name, ok, wert in pv["liste"]) + ".")
    b = (meta(con, "beschreibend", {}) or {}).get("werte")
    if b:
        z.append("")
        z.append("Beschreibend (ohne p-Werte, Nachtrag R13): " + json.dumps(b, ensure_ascii=False, default=str)[:1500])
    return "\n".join(z)


def bericht_stand(con, rb: "Rueckblick | None" = None, jetzt: int | None = None) -> str:
    jetzt = int(jetzt or time.time())
    z = ["★ Prognosemärkte: Stand und Quellen (" + _uhr(jetzt) + ")"]
    for plattform, art, n, offen in con.execute(
            "SELECT plattform, art, COUNT(*), SUM(CASE WHEN ende IS NULL OR ende > ? THEN 1 ELSE 0 END) FROM pm_markt "
            "GROUP BY plattform, art ORDER BY plattform, art", (jetzt,)):
        z.append("  " + plattform + " " + str(art) + ": " + _de(n, 0) + " Märkte, davon offen " + _de(offen or 0, 0))
    z.append("Abrufe der letzten 24 h je Quelle (ok / 404 / 429 / gesperrt / Fehler, mittlere Dauer):")
    for quelle, ok, n404, n429, gesp, fehl, ms in con.execute(
            "SELECT quelle, SUM(code=200), SUM(code=404), SUM(code=429), SUM(code IN (403,451)), "
            "SUM(code NOT IN (200,404,429,403,451,400,422)), AVG(ms) FROM pm_abruf WHERE ts>? GROUP BY quelle", (jetzt - 86400,)):
        z.append("  " + quelle + ": " + " / ".join(str(int(x or 0)) for x in (ok, n404, n429, gesp, fehl)) + ", ⌀ "
                 + _de(ms or 0, 0) + " ms" + ("  ← mögliche Sperre (Region?)" if gesp else ""))
    for (schluessel, wert) in con.execute("SELECT schluessel, wert FROM pm_meta WHERE schluessel LIKE 'fehler_%'"):
        w = json.loads(wert)
        if jetzt - int(w.get("ts", 0)) < 86400:
            z.append("  Fehler " + schluessel[7:] + " " + _uhr(w.get("ts")) + ": " + str(w.get("fehler")))
    z.append("Frische der Live-Kurse (jüngster Kurs je Plattform):")
    for plattform, ts in con.execute("SELECT plattform, MAX(ts) FROM pm_kurs WHERE quelle='live' GROUP BY plattform"):
        z.append("  " + plattform + ": " + _uhr(ts) + " (vor " + _vor_min(jetzt, ts) + " min)")
    if rb is not None:
        z.append("Rückblick:")
        for t in rb.stand():
            z.append("  " + t["teil"] + ": " + ("fertig" if t.get("fertig") else "läuft" if t.get("schritte") else "wartet") + ", Schritte "
                     + str(t.get("schritte", 0)) + (", " + str(t.get("abgebrochen")) if t.get("abgebrochen") else "")
                     + (", " + str(t.get("hinweis")) if t.get("hinweis") else ""))
    for name, (n,) in (("pm_kurs", con.execute("SELECT COUNT(*) FROM pm_kurs").fetchone()),
                       ("pm_spot", con.execute("SELECT COUNT(*) FROM pm_spot").fetchone())):
        z.append("Zeilen " + name + ": " + _de(n, 0))
    dz = meta(con, "abruf_zustand", {}) or {}
    z.append("Dienst im Dashboard: " + ("letzter Zustand " + _uhr(dz["ts"]) + " (vor " + _vor_min(jetzt, dz["ts"])
                                        + " min; älter als 5 min heißt: Takt steht oder Dashboard ohne den Dienst)"
                                        if dz.get("ts") else "noch kein Zustand (Takt beginnt 60 s nach dem Start des Dashboards)")
             + ("; pausiert: " + ", ".join(q + " bis " + _uhr(t) for q, t in sorted((dz.get("pausen") or {}).items()))
                if dz.get("pausen") else ""))
    el = meta(con, "erstlauf", {}) or {}
    if el.get("text"):
        z.append("Erstlauf (Formatprüfung, R15) vom " + _uhr(el.get("ts")) + ":")
        z.extend("  " + ohne_ip(str(x)) for x in (el["text"] if isinstance(el["text"], list) else str(el["text"]).splitlines())[1:])
    else:
        z.append("Erstlauf: noch nicht gelaufen (Stichtag " + (_uhr(stichtag(con)) if stichtag(con) else "fehlt") + ")")
    return "\n".join(z)


def makro_erwartung(con, reihe: str = "KXCPI") -> dict | None:
    """Erwartung vor dem nächsten Termin aus den jüngsten Live-Kursen der offenen Leiter (ohne Ergebnisse)."""
    jetzt = int(time.time())
    zeilen = con.execute("SELECT markt, strike_typ, unten, oben, ende FROM pm_markt WHERE plattform='kalshi' AND reihe=? AND "
                         "ende > ? ORDER BY ende", (reihe, jetzt)).fetchall()
    if not zeilen:
        return None
    naechst = min(r[4] for r in zeilen)
    punkte = []
    for markt, art, unten, oben, ende in zeilen:
        if ende != naechst:
            continue
        w = zustand(con, "kalshi", markt, jetzt - 3600, jetzt, "live")
        if w:
            pkt = _leiter_punkt(art, unten, oben, w[1], KALSHI_REIHEN.get(reihe, {}).get("schritt"))
            if pkt:
                punkte.append(pkt)
    v = leiter_verteilung(punkte) if len(punkte) >= 4 else None
    return {"reihe": reihe, "termin": makro_termin(naechst), "median": v["median"] if v else None,
            "streuung": v["streuung"] if v else None, "schwellen": len(punkte)}


LE_STEIGUNG = ((7 * 86400, 30 * 86400, 1.09), (30 * 86400, 10 ** 10, 1.36))   # Regel 1.6: Krypto-Steigungen nach Le 2026


def rekalibriert(p: float | None, rest_s: float | None) -> float | None:
    """Regel 1.6: lange Horizonte zusätzlich rekalibriert anzeigen (Rohwert immer daneben); nie in Prüfungen."""
    if p is None or rest_s is None or not 0.0 < p < 1.0:
        return None
    for a, b, k in LE_STEIGUNG:
        if a <= rest_s < b:
            return 1.0 / (1.0 + math.exp(-k * _logit(p)))
    return None


def _live(con, plattform: str, markt: str, t: int, frisch: int = 900):
    """Live-Wert bei t: (ts, Mitte oder letzter Kurs, Spread); None, wenn älter als `frisch`."""
    r = con.execute("SELECT ts, geld, brief, letzter, bis FROM pm_kurs WHERE plattform=? AND markt=? AND quelle='live' AND ts<=? "
                    "ORDER BY ts DESC LIMIT 1", (plattform, markt, int(t))).fetchone()
    if not r or (r[4] or r[0]) < int(t) - frisch:
        return None
    m = mitte(r[1], r[2])
    p = (m / 10000.0) if m is not None else ((r[3] / 10000.0) if r[3] is not None else None)
    spread = ((r[2] - r[1]) / 10000.0) if r[1] is not None and r[2] is not None else None
    return {"ts": int(r[0]), "bis": int(r[4] or r[0]), "p": p, "spread": spread, "nur_letzter": m is None}


def _spot_jetzt(con, coin: str, jetzt: int):
    q = SPOT_QUELLE.get(coin, ("", ""))[0]
    r = con.execute("SELECT ts, c FROM pm_spot WHERE coin=? AND quelle=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                    (coin, q, jetzt)).fetchone()
    return {"kurs": r[1], "ts": int(r[0]) + 60, "quelle": q} if r else None


def _spot_modell(con, coin: str, jetzt: int):
    """Spot-Echo für die Anzeige (Nachtrag R8: nach dem Beginn nur beschreibend, immer neben einem Spot-Echo): 1-min-Spot der letzten
    31 Tage aus pm_spot, Zeitpunkt t_s = Ende der jüngsten Spotminute (höchstens 5 min alt). (SpotReihe, t_s, Quelle) oder None."""
    q = SPOT_QUELLE.get(coin, ("", ""))[0]
    if not q:
        return None
    r = con.execute("SELECT MAX(ts) FROM pm_spot WHERE coin=? AND quelle=? AND ts<=?", (coin, q, int(jetzt))).fetchone()
    if not r or r[0] is None or int(r[0]) + 60 < int(jetzt) - 300:
        return None
    t_s = min(int(jetzt), int(r[0]) + 60)
    sp = SpotReihe.aus_db(con, coin, q, int(jetzt) - 31 * 86400, int(jetzt) + 1)
    if sp.sigma2_tag(t_s) is None or sp.schluss_bis(t_s) is None:
        return None
    return sp, t_s, q


def _p_spot_leiter(m, art: str, strike_typ: str, unten, oben, ende) -> float | None:
    """Ja-Wahrscheinlichkeit einer Schwelle, Spanne oder Berührung im Spotmodell zum Zeitpunkt t_s (nur Anzeige)."""
    if not m or not ende:
        return None
    sp, t_s, _q = m
    s, v = sp.schluss_bis(t_s), sp.sigma2_tag(t_s)
    if s is None or v is None or ende <= t_s:
        return None
    st = math.sqrt(v / 86400.0 * (int(ende) - t_s))
    try:
        if art == "beruehrung":
            k = unten if unten is not None else oben
            return p_beruehrt(s, k, st) if k else None
        return p_schwelle(strike_typ, unten, oben, s, st)
    except ValueError:
        return None


def nutzlast(con, jetzt: int | None = None, tab: str = "ueberblick") -> dict:
    """Daten für den Abschnitt „PM Prognosemärkte“ (Konzept 7). Vor dem gemeinsamen Urteil keine Größe, die Kurse mit
    Ergebnissen verbindet (R4): Bilanz nur als Zählung, Makro nur die Erwartung vor dem Termin."""
    jetzt = int(jetzt or time.time())
    endg = con.execute("SELECT MIN(lauf) FROM pm_auswertung WHERE endgueltig=1").fetchone()[0]
    st = stichtag(con)
    aus: dict = {"ok": True, "tab": tab, "stand": jetzt, "urteil_vom": endg, "stichtag": st,
                 "hinweis": "Echo des Spots, kein Signal – solange keine Prüfung belegt ist. Nur lesen; wirkt auf nichts.",
                 "version": VERSION_AUSWERTUNG}
    modelle: dict = {}

    def modell(coin):
        if coin not in modelle:
            try:
                modelle[coin] = _spot_modell(con, coin, jetzt)
            except Exception:  # noqa: BLE001 — das Echo ist nur Anzeige; ohne Spot bleibt die Spalte leer
                modelle[coin] = None
        return modelle[coin]
    if tab == "ueberblick":
        zeilen = []
        for plattform, markt, reihe, basis, beginn, ende, unten, titel in con.execute(
                "SELECT plattform, markt, reihe, basis, beginn, ende, unten, titel FROM pm_markt WHERE art='aufab' AND ende>? AND "
                "beginn<=? ORDER BY basis, reihe, beginn LIMIT 80", (jetzt, jetzt + 1800)):
            w = _live(con, plattform, markt, jetzt, 300)
            m = modell(basis)
            zeilen.append({"plattform": plattform, "markt": markt, "reihe": reihe, "basis": basis, "beginn": beginn, "ende": ende,
                           "laeuft": beginn <= jetzt, "p": w["p"] if w else None, "spread": w["spread"] if w else None,
                           "ts": w["ts"] if w else None, "bezug": unten if plattform == "kalshi" else None,
                           "p_s": p_spot_aufab(m[0], beginn, ende, m[1], mittel=(plattform == "kalshi")) if m else None,
                           "spot_ts": m[1] if m else None})
        hip = []
        for markt, basis, unten, ende, st_ in con.execute("SELECT markt, basis, unten, ende, strike_typ FROM pm_markt WHERE "
                                                          "plattform='hip4' AND art='schwelle' AND ende>? ORDER BY ende LIMIT 6", (jetzt,)):
            w = _live(con, "hip4", markt, jetzt, 300)
            m = modell(basis)
            hip.append({"markt": markt, "basis": basis, "ziel": unten, "ende": ende, "p": w["p"] if w else None,
                        "ts": w["ts"] if w else None, "p_s": _p_spot_leiter(m, "schwelle", st_ or "greater", unten, None, ende),
                        "spot_ts": m[1] if m else None})
        aus.update(fenster=zeilen, hip4=hip, spot={c: _spot_jetzt(con, c, jetzt) for c in ("BTC", "ETH")},
                   hinweis_spot="Spotmodell: driftfrei aus dem 1-min-Spot (Quelle in der Spotzeile) und der Schwankung der letzten "
                                "1, 7 und 30 Tage, zum Zeitpunkt der jüngsten Spotminute; vor dem Beginn genau 50 % (Kalshi: bis zur "
                                "Mittelungsminute). Ein Ja-Kurs nahe dem Spotmodell ist ein Echo des Spots.")
    elif tab == "krypto":
        leitern = []
        for plattform, reihe, ereignis, art, ende, basis in con.execute(
                "SELECT plattform, reihe, ereignis, art, MIN(ende), MAX(basis) FROM pm_markt WHERE art IN ('schwelle','beruehrung',"
                "'spanne') AND ende>? AND plattform IN ('kalshi','polymarket') GROUP BY plattform, ereignis ORDER BY MIN(ende) LIMIT 12",
                (jetzt,)):
            pkt = []
            m = modell(basis)
            for markt, st_, unten, oben, titel, ende_m in con.execute(
                    "SELECT markt, strike_typ, unten, oben, titel, ende FROM pm_markt WHERE plattform=? AND ereignis=? ORDER BY "
                    "COALESCE(unten, oben)", (plattform, ereignis)):
                w = _live(con, plattform, markt, jetzt, 3600)
                if not w or w["p"] is None:
                    continue
                pkt.append({"k": unten if unten is not None else oben, "art": st_, "p": w["p"], "spread": w["spread"],
                            "ts": w["ts"], "p_rekal": rekalibriert(w["p"], (ende or jetzt) - jetzt),
                            "p_s": _p_spot_leiter(m, art, st_, unten, oben, ende_m or ende)})
            if pkt:
                leitern.append({"plattform": plattform, "reihe": reihe, "ereignis": ereignis, "art": art, "ende": ende, "basis": basis,
                                "rest_tage": ((ende or jetzt) - jetzt) / 86400.0, "punkte": pkt[:60],
                                "spot_ts": m[1] if m else None})
        aus.update(leitern=leitern, spot={c: _spot_jetzt(con, c, jetzt) for c in ("BTC", "ETH")},
                   hinweis_rekal="Rekalibriert nach Le 2026 (Krypto, 1 Woche–1 Monat Steigung 1,09, darüber 1,36; für 2021–2025 in "
                                 "der Stichprobe geschätzt). Rohwert immer daneben; Prüfungen nutzen nur Rohwerte.")
    elif tab == "makro":
        aus["erwartung"] = [x for x in (makro_erwartung(con, r) for r in ("KXCPI", "KXCPIYOY", "KXU3", "KXPAYROLLS")) if x]
        if endg:
            aus["termine"] = [dict(zip(("reihe", "termin", "median", "streuung", "ist", "u", "z", "r30_btc"), x)) for x in con.execute(
                "SELECT reihe, termin, median, streuung, ist, u, z, r30_btc FROM pm_ueberraschung ORDER BY termin DESC LIMIT 40")]
        else:
            aus["termine_hinweis"] = "Überraschungen und Renditen erst nach dem gemeinsamen Urteil (Nachtrag R4)."
    elif tab == "ereignisse":
        ev = []
        for plattform, ereignis, reihe, ende in con.execute(
                "SELECT plattform, ereignis, reihe, MIN(ende) FROM pm_markt WHERE art IN ('ereignis','makro') AND (ende IS NULL OR "
                "ende>?) GROUP BY plattform, ereignis ORDER BY MIN(ende) LIMIT 30", (jetzt,)):
            ms = []
            for markt, titel, unten, oben in con.execute("SELECT markt, titel, unten, oben FROM pm_markt WHERE plattform=? AND "
                                                         "ereignis=? LIMIT 12", (plattform, ereignis)):
                w = _live(con, plattform, markt, jetzt, 3600)
                if not w:
                    continue
                w1 = _live(con, plattform, markt, jetzt - 3600, 3600)
                w24 = _live(con, plattform, markt, jetzt - 86400, 3600)
                ms.append({"markt": markt, "titel": titel, "schwelle": unten if unten is not None else oben, "p": w["p"],
                           "spread": w["spread"], "ts": w["ts"], "d1h": (w["p"] - w1["p"]) if w1 and w1["p"] is not None
                           and w["p"] is not None else None,
                           "d24h": (w["p"] - w24["p"]) if w24 and w24["p"] is not None and w["p"] is not None else None})
            if ms:
                ev.append({"plattform": plattform, "ereignis": ereignis, "reihe": reihe, "ende": ende, "maerkte": ms})
        aus["ereignisse"] = ev
    elif tab == "bilanz":
        if endg:
            aus["urteil"] = [dict(zip(("pruefung", "n", "tage", "mass", "lo", "hi", "p", "p_holm", "h1", "h2", "urteil", "details"), x))
                             for x in con.execute("SELECT pruefung, n, tage, mass, lo, hi, p, p_holm, h1, h2, urteil, details FROM "
                                                  "pm_auswertung WHERE lauf=? ORDER BY pruefung", (endg,))]
            for u in aus["urteil"]:
                u["details"] = json.loads(u["details"] or "{}")
            aus["beschreibend"] = (meta(con, "beschreibend", {}) or {}).get("werte")
        else:
            aus["zaehlung"] = meta(con, "zaehlung", {}) or {}
        aus["vor_urteil"] = (meta(con, "pruefungen_vor_urteil", {}) or {}).get("liste")
        aus["titel"] = TITEL
    elif tab == "rueckblick":
        aus["teile"] = Rueckblick(con, None).stand()
        aus["abdeckung"] = {t: abdeckung(con, t) for t in RB_TEILE_URTEIL}
        aus["erstlauf"] = (meta(con, "erstlauf", {}) or {}).get("ts")
        aus["grenze"] = (meta(con, "kalshi_grenze", {}) or {}).get("grenze")
    elif tab == "daten":
        q = []
        for quelle, ok, n404, n429, gesp, fehl, ms, letzt in con.execute(
                "SELECT quelle, SUM(code=200), SUM(code=404), SUM(code=429), SUM(code IN (403,451)), "
                "SUM(code NOT IN (200,404,429,403,451,400,422)), AVG(ms), MAX(ts) FROM pm_abruf WHERE ts>? GROUP BY quelle "
                "ORDER BY quelle", (jetzt - 86400,)):
            q.append({"quelle": quelle, "ok": ok or 0, "fehlt": n404 or 0, "zu_viele": n429 or 0, "gesperrt": gesp or 0,
                      "fehler": fehl or 0, "ms": ms, "letzter": letzt})
        gew = sum(HL_GEWICHT.get(pf, 20) for (pf,) in con.execute("SELECT pfad FROM pm_abruf WHERE quelle='hl' AND ts>?",
                                                                   (jetzt - 3600,))) / 60.0
        frisch = [{"plattform": pl, "ts": ts} for pl, ts in con.execute(
            "SELECT plattform, MAX(ts) FROM pm_kurs WHERE quelle='live' AND ts>? GROUP BY plattform", (jetzt - 7 * 86400,))]
        fehler = []
        for schluessel, wert in con.execute("SELECT schluessel, wert FROM pm_meta WHERE schluessel LIKE 'fehler_%'"):
            w = json.loads(wert)
            if jetzt - int(w.get("ts", 0)) < 86400:
                fehler.append({"aufgabe": schluessel[7:], "ts": w.get("ts"), "fehler": w.get("fehler")})
        aus.update(quellen=q, hl_gewicht_je_minute=gew, hl_deckel=HL_GEWICHT_JE_MINUTE, frische=frisch, fehler=fehler,
                   zustand=meta(con, "abruf_zustand", {}), zeilen={t: con.execute("SELECT COUNT(*) FROM " + t).fetchone()[0]
                                                                  for t in ("pm_markt", "pm_kurs", "pm_spot", "pm_ergebnis")})
    return aus


# ---------------------------------------------------------------------------
# 13. Selbsttest (Konzept 8.1) und Mutationen (8.2)
# ---------------------------------------------------------------------------

MUTATIONEN = ("kurs_nach_t0", "t0_im_bezug", "sigma_zukunft", "spread_filter_aus", "letzte_minute", "fuenf_min_zugelassen",
              "et_fester_versatz", "v2_uebersehen", "vf_nicht_monoton", "u_vorzeichen", "bootstrap_ohne_tage",
              "bootstrap_perzentil", "haelften_ignoriert", "holm_weg", "mindestzahl_ignoriert", "quellen_vermischt",
              "doppelt_geschrieben", "kerze_beginn_kalshi", "kerze_beginn_spot", "spot_enthaltende_kerze",
              "spotquelle_gewechselt", "har_label", "har_ganze_stichprobe", "schwelle_nach_t0", "auswahl_bei_ablauf",
              "leiter_nach_termin", "leiter_bin_verschoben", "rendite_davor", "urteile_einzeln", "kein_stichtag",
              # 23.89 (U236)
              "hip4_alle_buecher", "hip4_abrechnung_nach_meta", "rb_leerlauf", "ohne_buch_nicht_auslassen", "ip_ausgeben")
T_BASIS = 1_780_000_000 - 1_780_000_000 % 86400


def _welt(rng: random.Random, art: str, tage: int = 63, je_tag: int = 96, staerke: float = 0.032) -> list[dict]:
    """Synthetische H1-Fenster (p_S = 0,5) ohne Datenbank.
    ohne:    Markt ohne Wissen (Rauschen, unabhängig von y) → E[c] = 0, Größe des Tests.
    haufen:  Tagestrend in y und Tagesverzerrung des Markts, unabhängig → E[c] = 0, starke Tageshaufen.
    wissen:  kalibrierter Markt mit Effektivwert von p_M − 0,5 = staerke (Positivkontrolle)."""
    faelle = []
    for d in range(tage):
        trend = rng.choice((-0.1, 0.1))
        bias = rng.gauss(0.0, 0.03)
        for j in range(je_tag):
            ts = T_BASIS + d * 86400 + j * 900
            if art == "ohne":
                y = 1 if rng.random() < 0.5 else 0
                p = min(0.99, max(0.01, round(0.5 + rng.gauss(0.0, 0.02), 4)))
            elif art == "haufen":
                y = 1 if rng.random() < 0.5 + trend else 0
                p = min(0.99, max(0.01, round(0.5 + bias + rng.gauss(0.0, 0.01), 4)))
            else:
                q = phi(staerke * math.sqrt(2 * math.pi) * rng.gauss(0.0, 1.0))
                y = 1 if rng.random() < q else 0
                p = min(0.99, max(0.01, round(q, 4)))
            faelle.append({"ts": ts, "d": p - 0.5, "y": y, "p_m": p, "p_s": 0.5, "g": brier_zugewinn(0.5, p, y)})
    return faelle


def _rate(art: str, welten: int, ziehungen: int, saat: int = 235, modus: str = "urteil") -> float:
    """modus 'groesse': Anteil p < 0,05 (Größe des Bootstrap-Tests); 'urteil': Anteil „belegt“ nach der Regel von H1 mit dem
    Bonferroni-Anteil α·0,25 (p × 4 als angepasstes p)."""
    treffer = 0
    for w in range(welten):
        f = _welt(random.Random(saat * 1000 + w), art)
        e = block_bootstrap(_tagesaggregate(f, "kov"), "kov", ziehungen, saat=saat + w)
        if modus == "groesse":
            treffer += e["p"] is not None and e["p"] < 0.05
            continue
        e["h1"], e["h2"], e["n1"], e["n2"] = haelften_median(f, "kov")
        treffer += urteil(e, min(1.0, 4 * e["p"]), MIN_N["H1"], min_tage=MIN_TAGE["H1"]) == "belegt"
    return treffer / welten


def _synthetische_spot(rng: random.Random, beginn: int, tage: int, sigma_tag: float = 0.02, s0: float = 80000.0):
    """1-min-Kerzen als Zufallspfad mit Tagesvolatilität sigma_tag (Wochenende ×0,6)."""
    s = s0
    k = []
    for i in range(tage * 1440):
        t = beginn + i * 60
        sd = sigma_tag / math.sqrt(1440) * (0.6 if datetime.fromtimestamp(t, UTC).weekday() >= 5 else 1.0)
        o = s
        a = o * math.exp(rng.gauss(0, sd / math.sqrt(2)))
        c = a * math.exp(rng.gauss(0, sd / math.sqrt(2)))
        k.append((t, o, max(o, a, c), min(o, a, c), c))
        s = c
    return k


def selbsttest(welten: int = 200, ziehungen: int = 999, still: bool = False) -> list[tuple[str, bool, str]]:
    """Prüfungen ohne Netz. Gibt [(Name, bestanden, Hinweis)] zurück."""
    erg: list[tuple[str, bool, str]] = []

    def pruef(name: str, bed: bool, hinweis: str = "") -> None:
        erg.append((name, bool(bed), hinweis))

    def sicher(name: str, f) -> None:
        try:
            f()
        except Exception as e:  # noqa: BLE001 — eine Ausnahme ist ein roter Test
            erg.append((name, False, "Ausnahme " + type(e).__name__ + ": " + str(e)[:200]))

    def a():
        pruef("ET 12:00 vor/nach 01.11.2026", et_zu_ts(2026, 10, 31, 12, 0) == utc_ts(datetime(2026, 10, 31, 16, 0, tzinfo=UTC))
              and et_zu_ts(2026, 11, 2, 12, 0) == utc_ts(datetime(2026, 11, 2, 17, 0, tzinfo=UTC)))
        pruef("ET 17:00 und 08:30 vor/nach Umstellung",
              et_zu_ts(2026, 10, 30, 17, 0) == utc_ts(datetime(2026, 10, 30, 21, 0, tzinfo=UTC))
              and et_zu_ts(2026, 11, 3, 8, 30) == utc_ts(datetime(2026, 11, 3, 13, 30, tzinfo=UTC)))
        so = [d for d in range(8, 15) if date(2027, 3, d).weekday() == 6][0]
        pruef("ET Sommerzeit 2027 (zweiter Sonntag im März)", so == 14
              and et_zu_ts(2027, 3, 15, 12, 0) == utc_ts(datetime(2027, 3, 15, 16, 0, tzinfo=UTC))
              and et_zu_ts(2027, 3, 13, 12, 0) == utc_ts(datetime(2027, 3, 13, 17, 0, tzinfo=UTC)))
        pruef("ET Umstellung in der Stichprobe (06.11.2022)",
              et_zu_ts(2022, 11, 4, 8, 30) == utc_ts(datetime(2022, 11, 4, 12, 30, tzinfo=UTC))
              and et_zu_ts(2022, 11, 7, 8, 30) == utc_ts(datetime(2022, 11, 7, 13, 30, tzinfo=UTC)))
        t = utc_ts(datetime(2026, 11, 2, 3, 0, tzinfo=UTC))
        pruef("4-h-Raster ET nach Umstellung", et_4h_beginn(t) == utc_ts(datetime(2026, 11, 2, 1, 0, tzinfo=UTC)))
        pruef("Slug 15 min", pm_slug_updown("BTC", "15m", 1783197900) == "btc-updown-15m-1783197900")
        try:
            pm_slug_updown("BTC", "5m", 1783197900)
            pruef("5-min-Märkte gesperrt", False)
        except ValueError:
            pruef("5-min-Märkte gesperrt", True)
        pruef("5-min nicht in den Familien", "5m" not in PM_AUFAB and all(
            "-5m-" not in k["slug"] for k in pm_aufab_kandidaten(1783197900)))
        pruef("Slug Stunde", pm_slug_stunde("BTC", et_zu_ts(2026, 9, 26, 21, 0)) == "bitcoin-up-or-down-september-26-2026-9pm-et")
        pruef("Slug Tag", pm_slug_tag("BTC", date(2026, 9, 2)) == "bitcoin-up-or-down-on-september-2-2026")
        pruef("Slug above", pm_slug_ueber("BTC", date(2026, 10, 27)) == "bitcoin-above-on-october-27-2026")
        z1 = kalshi_ticker_zerlegen("KXBTC15M-26OCT271200-00")
        pruef("Ticker 15 min", z1["reihe"] == "KXBTC15M" and z1["termin_ts"] == utc_ts(datetime(2026, 10, 27, 16, 0, tzinfo=UTC)))
        z2 = kalshi_ticker_zerlegen("KXBTCD-26MAY0817-T64499.99")
        pruef("Ticker Tagesleiter", z2["termin_ts"] == utc_ts(datetime(2026, 5, 8, 21, 0, tzinfo=UTC))
              and z2["schwelle_art"] == "T" and abs(z2["schwelle"] - 64499.99) < 1e-9)
        pruef("Makro-Termin", makro_termin(et_zu_ts(2026, 11, 13, 8, 25)) == et_zu_ts(2026, 11, 13, 8, 30)
              and makro_termin(et_zu_ts(2026, 11, 13, 14, 0)) is None)
    sicher("A Zeit", a)

    def b():
        pruef("Preis Festkomma", preis("0.5600") == 5600 and preis("0.0001") == 1 and preis("1.5") is None
              and preis_cent(56) == 5600 and preis(None) is None)
        pruef("Einseitige Bücher ungültig", mitte(0, 100) is None and mitte(9950, 10000) is None and mitte(None, 5000) is None
              and mitte(5000, 5100) == 5050)
        m = kalshi_markt({"ticker": "KXBTC15M-26OCT271200-00", "yes_bid_dollars": "0.5400", "yes_ask_dollars": "0.5600",
                          "close_time": "2026-10-27T16:00:00Z", "open_time": "2026-10-27T15:45:00Z", "result": "yes",
                          "floor_strike": 80454.55, "strike_type": "greater"})
        pruef("Kalshi Markt", m["geld"] == 5400 and m["brief"] == 5600 and m["ergebnis"] == 1 and m["unten"] == 80454.55
              and m["ende"] == utc_ts(datetime(2026, 10, 27, 16, 0, tzinfo=UTC)))
        m2 = kalshi_markt({"ticker": "X-1", "yes_bid": 54, "yes_ask": 56, "result": "no"})
        pruef("Kalshi alte Cent-Felder", m2["geld"] == 5400 and m2["brief"] == 5600 and m2["ergebnis"] == 0)
        k = kalshi_kerzen({"candlesticks": [
            {"end_period_ts": 120, "yes_bid": {"close_dollars": "0.51"}, "yes_ask": {"close_dollars": "0.53"}},
            {"end_period_ts": 60, "yes_bid": {"close": 50}, "yes_ask": {"close": 52}}]})
        pruef("Kalshi Kerzen mit Periodenende", [x["ts"] for x in k] == [60, 120] and k[0]["geld"] == 5000 and k[1]["brief"] == 5300)
        g1 = gamma_markt({"conditionId": "0xa", "clobTokenIds": "[\"111\", \"222\"]", "outcomes": "[\"Up\", \"Down\"]",
                          "outcomePrices": "[\"1\", \"0\"]", "closed": True})
        pruef("Gamma v1", g1["kennung_ja"] == "111" and g1["ergebnis"] == 1 and g1["version"] == "v1")
        g2 = gamma_markt({"conditionId": "0xb", "version": "v2", "positionIds": ["333", "444"], "outcomes": ["No", "Yes"],
                          "outcomePrices": ["0", "1"], "closed": True})
        pruef("Gamma v2 (positionIds, Reihenfolge)", g2["kennung_ja"] == "444" and g2["ergebnis"] == 1 and g2["version"] == "v2")
        h = hip4_beschreibung("class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d")
        pruef("HIP-4 Beschreibung", h["ziel"] == 78213 and h["basis"] == "BTC"
              and h["ablauf"] == utc_ts(datetime(2026, 5, 4, 6, 0, tzinfo=UTC)))
        ha = hip4_abgerechnet({"settleFraction": "1", "details": "price:79980"})
        pruef("HIP-4 Abrechnung", ha["ergebnis"] == 1 and ha["kurs"] == 79980)
        pruef("HIP-4 Kennung", hip4_ausgaenge({"outcomes": [{"outcome": 3, "description": "class:priceBinary"}]})[0]["markt"]
              == "#30")
        pruef("Kalshi Buch", kalshi_buch({"orderbook_fp": {"yes_dollars": [["0.54", "10"], ["0.55", "3"]],
                                                           "no_dollars": [["0.44", "5"]]}}) == (5500, 5600))
        pruef("Polymarket Buch", pm_buch({"bids": [{"price": "0.54"}, {"price": "0.55"}],
                                          "asks": [{"price": "0.57"}, {"price": "0.56"}]}) == (5500, 5600))
        pruef("HL Buch", hl_buch_mitte({"levels": [[{"px": "0.41"}, {"px": "0.42"}], [{"px": "0.45"}, {"px": "0.44"}]]})
              == (4200, 4400))
        pruef("Zeitformen", zeit(1_780_000_000_000) == 1_780_000_000 and zeit("1780000000") == 1_780_000_000
              and zeit("2026-05-04T06:00:00.123456789Z") == utc_ts(datetime(2026, 5, 4, 6, 0, tzinfo=UTC)))
        pruef("Binance Kerzen (Beginn)", binance_kerzen([[1780000000000, "1", "2", "0.5", "1.5", "9"]])
              == [(1780000000, 1.0, 2.0, 0.5, 1.5)])
        pruef("Coinbase Kerzen (Beginn, aufsteigend)", coinbase_kerzen([[1780000060, 0.5, 2, 1, 1.5, 9], [1780000000, 1, 3, 2, 2.5, 1]])
              == [(1780000000, 2.0, 3.0, 1.0, 2.5), (1780000060, 1.0, 2.0, 0.5, 1.5)])
        st, kk = pm_leiter_richtung({"gruppe": "↓ 95,000", "titel": "Will Bitcoin dip to $95,000?"})
        pruef("Leiter-Richtung", st == "less" and kk == 95000 and pm_leiter_richtung({"gruppe": "130K"})[1] == 130000)
    sicher("B Parser", b)

    def c():
        ks = [0.05 * i for i in range(1, 12)]
        v = leiter_verteilung([(k, 1 - phi((k - 0.3) / 0.1)) for k in ks])
        pruef("Leiter Median/Streuung", abs(v["median"] - 0.3) < 0.006 and abs(v["streuung"] - 0.1) < 0.012)
        v2 = leiter_verteilung([(1, 0.9), (2, 0.6), (3, 0.7), (4, 0.2), (5, 0.25)])
        pruef("Leiter monoton", all(v2["ueber"][i] >= v2["ueber"][i + 1] - 1e-12 for i in range(4)) and v2["geglaettet"])
        pruef("Klassen auf dem 0,1-Raster", _leiter_punkt("greater", 0.2, None, 0.6, 0.1) == (0.25, 0.6)
              and _leiter_punkt("greater", 0.25, None, 0.6, 0.1) == (0.25, 0.6)
              and _leiter_punkt("greater_or_equal", 0.3, None, 0.6, 0.1) == (0.25, 0.6))
        v3 = leiter_verteilung([(1, 0.95), (2, 0.9), (3, 0.8), (4, 0.7)])
        pruef("Quantil außerhalb der Schwellen → ungültig", v3["q84"] is None or v3["q16"] is None)
    sicher("C Leiter", c)

    def d():
        pruef("Spotmodell driftfrei", p_auf(0.0, 0.01) == 0.5 and p_ueber(100, 100, 0.02) == 0.5
              and abs(p_beruehrt(100, 110, 0.05) - p_beruehrt(100, 100 / 1.1, 0.05)) < 1e-12)
        rng = random.Random(7)
        k = _synthetische_spot(rng, T_BASIS, 40, 0.02)
        sp = SpotReihe(k)
        t0 = T_BASIS + 35 * 86400 + 600
        pruef("Schluss bei t = Kerze, die bei t endet", sp.schluss(t0) == next(x[4] for x in k if x[0] == t0 - 60))
        v = sp.sigma2_tag(t0)
        pruef("Schwankung kausal geschätzt", v is not None and 0.6 < math.sqrt(v) / 0.02 < 1.25, _de(math.sqrt(v) if v else None, 4))
        beginn = t0 - t0 % 900 + 900
        sp_bis = SpotReihe([x for x in k if x[0] + 60 <= beginn + 60])
        voll = p_spot_aufab(sp, beginn, beginn + 900, beginn + 60)
        pruef("Kein Blick in die Zukunft (Spotmodell)", voll is not None and voll == p_spot_aufab(sp_bis, beginn, beginn + 900,
                                                                                                   beginn + 60))
        pruef("Kein Blick in die Zukunft (Schwankung)", sp.sigma2_tag(beginn) == sp_bis.sigma2_tag(beginn))
        k2 = _synthetische_spot(random.Random(8), T_BASIS, 200, 0.02)
        sw = Schwankung(SpotReihe(k2))
        t1 = T_BASIS + 190 * 86400 + 3600
        sw_bis = Schwankung(SpotReihe([x for x in k2 if x[0] + 60 <= t1]))
        a1, a2 = sw.sigma2(t1, 86400), sw_bis.sigma2(t1, 86400)
        pruef("HAR: Daten nach t0 ändern nichts", a1 is not None and a2 is not None and abs(a1 - a2) < 1e-15 * max(a1, 1e-12),
              _de(a1, 8) + " / " + _de(a2, 8))
        kf = sw.koeffizienten(t1)
        pruef("HAR geschätzt (≥ 120 Tage vor dem Monatsersten)", kf is not None and 0.3 < math.sqrt(sw.sigma2_tag(t1)) / 0.02 < 1.6)
        wf = sw.wochentag_faktor(T_BASIS + 186 * 86400, 86400)
        pruef("Wochentagsfaktor begrenzt", 0.5 <= wf <= 2.0, _de(wf, 2))
    sicher("D Spotmodell und HAR", d)

    def e():
        hh = holm_gewichtet({"H1": 0.01, "H2": 0.04, "H3": 0.03}, GEWICHT)
        pruef("Gewichteter Holm", abs(hh["H1"] - 0.04) < 1e-12 and abs(hh["H3"] - 0.045) < 1e-12 and abs(hh["H2"] - 0.045) < 1e-12,
              str(hh))
        e_ok = {"n": 5000, "tage": 80, "mass": 0.01, "h1": 0.01, "h2": 0.01, "n1": 2500, "n2": 2500}
        pruef("Holm verhindert Urteil", all(urteil(e_ok, pv, MIN_N["H1"], min_tage=60) != "belegt"
                                            for pv in holm_gewichtet({"H1": 0.03, "H2": 0.04, "H3": 0.2}, GEWICHT).values()))
        pruef("Ränge mit Gleichstand", raenge([3, 1, 3, 2]) == [3.5, 1.0, 3.5, 2.0])
        agg = _tagesaggregate([{"ts": T_BASIS + 60, "d": 0.1, "y": 1}, {"ts": T_BASIS + 50000, "d": 0.2, "y": 0},
                               {"ts": T_BASIS + 86400, "d": 0.0, "y": 1}], "kov")
        pruef("Tagesblöcke: Fenster eines UTC-Tags bilden einen Block", [a[1] for a in agg] == [2, 1])
        x = list(range(12))
        pruef("Spearman Permutation", spearman_permutation(x, [-v for v in x], 2000)["p"] < 0.01
              and spearman_permutation(x, x, 2000)["p"] > 0.9)
        pruef("Hälftenregel", urteil(dict(e_ok, h2=-0.001), 0.001, MIN_N["H1"], min_tage=60) == "nicht belegt")
        pruef("Hälften mit genug Fällen", urteil(dict(e_ok, n1=1000), 0.001, MIN_N["H1"], min_tage=60) == "nicht belegt")
        pruef("Mindestzahl und Mindesttage", urteil(dict(e_ok, n=500), 0.0001, MIN_N["H1"], min_tage=60) == "nicht prüfbar"
              and urteil(dict(e_ok, tage=30), 0.0001, MIN_N["H1"], min_tage=60) == "nicht prüfbar")
        pruef("H3-Richtung", urteil({"n": 64, "tage": 64, "mass": -0.4, "h1": -0.3, "h2": -0.5, "n1": 32, "n2": 32}, 0.001, 30,
                                    "negativ") == "belegt"
              and urteil({"n": 64, "tage": 64, "mass": -0.4, "h1": -0.3, "h2": 0.1, "n1": 32, "n2": 32}, 0.001, 30,
                         "negativ") == "nicht belegt")
        f = _welt(random.Random(5), "wissen", staerke=0.08)
        bb = block_bootstrap(_tagesaggregate(f, "kov"), "kov", 499)
        pruef("Bootstrap-p zentriert (≥ 1/(B+1))", bb["p"] >= 1 / 500 and bb["mass"] > 0, _de(bb["p"], 4))
        h1, h2, n1, n2 = haelften_median(f, "kov")
        pruef("Hälften am Median-Datum", n1 == n2 == len(f) // 2 and h1 is not None and h2 is not None)
        rng = random.Random(3)
        p = [rng.random() for _ in range(4000)]
        y = [1 if rng.random() < q else 0 for q in p]
        k1 = kalibrierung(p, y)
        k2 = kalibrierung([0.5 + 0.5 * (q - 0.5) for q in p], y)
        pruef("Kalibrierungssteigung", 0.85 < k1["b"] < 1.15 and 1.7 < k2["b"] < 3.5, _de(k1["b"], 2) + " / " + _de(k2["b"], 2))
    sicher("E Statistik", e)

    def f():
        def grenze_oben(p0):
            return p0 + 2.326 * math.sqrt(p0 * (1 - p0) / welten)
        r = _rate("ohne", welten, ziehungen, modus="groesse")
        pruef("Nullprobe Markt ohne Wissen (Größe bei α 0,05)", r <= grenze_oben(0.05), _pz(r))
        r = _rate("haufen", welten, ziehungen, modus="groesse")
        pruef("Nullprobe Tageshaufen (Größe bei α 0,05)", r <= grenze_oben(0.05), _pz(r))
        r = _rate("ohne", welten, ziehungen)
        pruef("Nullprobe Markt ohne Wissen (Urteil)", r <= grenze_oben(0.0125), _pz(r))
        r = _rate("wissen", welten, ziehungen)
        pruef("Positivkontrolle (Effektivwert 3,2 Punkte, 6.048 Fenster, 63 Tage)", r >= 0.8 - 2.326 * math.sqrt(0.16 / welten), _pz(r))
    sicher("F Null/Positiv", f)

    def g():
        con = verbinden(":memory:")
        with schreiben(con):
            kurs_speichern(con, "kalshi", "M", 100, "live", 5000, 5200, None, None, 100)
            kurs_speichern(con, "kalshi", "M", 160, "live", 5000, 5200, None, None, 160)
            kurs_speichern(con, "kalshi", "M", 220, "live", 5100, 5200, None, None, 220)
        rows = con.execute("SELECT ts, bis FROM pm_kurs WHERE markt='M' ORDER BY ts").fetchall()
        pruef("Gleiche Werte → keine neue Zeile", rows == [(100, 160), (220, 220)], str(rows))
        with schreiben(con):
            a1 = ergebnis_speichern(con, "kalshi", "M", 1, None, 0.3, 1, 1)
            a2 = ergebnis_speichern(con, "kalshi", "M", 1, None, 0.3, 1, 2)
            a3 = ergebnis_speichern(con, "kalshi", "M", 0, None, 0.3, 1, 3)
        pruef("Ergebnis-Fassungen", (a1, a2, a3) == (True, False, True) and ergebnisse(con, "kalshi")["M"][2] == 2)
        with schreiben(con):
            markt_speichern(con, {"plattform": "kalshi", "markt": "R", "regeln": "alt"}, 1)
            markt_speichern(con, {"plattform": "kalshi", "markt": "R", "regeln": "neu"}, 2)
        pruef("Regeltext-Änderung festgehalten", con.execute("SELECT alt, neu FROM pm_markt_aenderung").fetchall() == [("alt", "neu")])
        b0 = T_BASIS + 33 * 86400
        stich = b0 + 50 * 900
        with schreiben(con):
            meta_setzen(con, "stichtag", {"ts": stich})
            for i in range(56):
                beginn = b0 + i * 900
                mk = "KXBTC15M-T" + str(i)
                markt_speichern(con, {"plattform": "kalshi", "markt": mk, "reihe": "KXBTC15M", "art": "aufab",
                                      "beginn": beginn, "ende": beginn + 900}, 1)
                ergebnis_speichern(con, "kalshi", mk, i % 2, None, None, beginn + 900, 1)
                fall = i % 7
                if fall == 0:      # gültig bei B − 60 → 0,51
                    kurs_speichern(con, "kalshi", mk, beginn - 60, "k1m", 5000, 5200, None, None, 1)
                elif fall == 1:    # nur B − 120 gültig (frisch genug) → 0,54
                    kurs_speichern(con, "kalshi", mk, beginn - 120, "k1m", 5300, 5500, None, None, 1)
                elif fall == 2:    # nur B − 360 (zu alt)
                    kurs_speichern(con, "kalshi", mk, beginn - 360, "k1m", 5300, 5500, None, None, 1)
                elif fall == 3:    # gültig erst bei B (Ende = B, in der Mittelungsminute) und B + 60
                    kurs_speichern(con, "kalshi", mk, beginn, "k1m", 7000, 7100, None, None, 1)
                    kurs_speichern(con, "kalshi", mk, beginn + 60, "k1m", 7000, 7100, None, None, 1)
                elif fall == 4:    # Spread 10 ¢ bei B − 60
                    kurs_speichern(con, "kalshi", mk, beginn - 60, "k1m", 4500, 5500, None, None, 1)
                elif fall == 5:    # nur ein Live-Wert vor dem Beginn (andere Quelle)
                    kurs_speichern(con, "kalshi", mk, beginn - 90, "live", 5000, 5100, None, None, 1)
                else:              # einseitiges Buch
                    kurs_speichern(con, "kalshi", mk, beginn - 60, "k1m", 0, 5100, None, None, 1)
        fa, zz = faelle_h1(con)
        pw = sorted({round(x["p_m"], 4) for x in fa})
        pruef("H1-Zustand: Fenster, Alter, Spread, Quelle, Stichtag", zz["maerkte"] == 49 and len(fa) == 14 and pw == [0.51, 0.54],
              str(zz) + " " + str(pw))
        im = beobachtungen_im_fenster(con, "kalshi", "KXBTC15M-T3", b0 + 3 * 900, b0 + 4 * 900, "k1m")
        with schreiben(con):
            kurs_speichern(con, "kalshi", "KXBTC15M-T3", b0 + 4 * 900, "k1m", 9900, 9950, None, None, 1)
        pruef("Letzte Minute zählt nie", im == beobachtungen_im_fenster(con, "kalshi", "KXBTC15M-T3", b0 + 3 * 900,
                                                                        b0 + 4 * 900, "k1m"))
        # Freigabe nur gemeinsam
        with schreiben(con):
            for t in RB_TEILE_URTEIL:
                meta_setzen(con, "rb:" + t, {"fertig": t != "kerzen:KXBTCD"})
        pruef("Gemeinsames Urteil erst, wenn alle Teile fertig sind", freigabe(con)[0] is False)
        # H3 von Hand: Leiter vor 08:30, Kerze nach 08:30 ignoriert, Rendite der 08:30-Kerze, Shutdown-Ausschluss
        termin = et_zu_ts(2026, 9, 11, 8, 30)
        with schreiben(con):
            meta_setzen(con, "stichtag", {"ts": termin + 86400})
            for ereignis in ("KXCPI-26AUG", "KXCPI-25OCT"):
                for kk in (0.0, 0.1, 0.2, 0.3, 0.4, 0.5):
                    mk = ereignis + "-T" + str(kk)
                    p = 1 - phi((kk + 0.05 - 0.27) / 0.1)
                    markt_speichern(con, {"plattform": "kalshi", "markt": mk, "reihe": "KXCPI", "ereignis": ereignis,
                                          "art": "makro", "strike_typ": "greater", "unten": kk, "ende": termin - 300}, 1)
                    gg = int(round(p * 10000)) - 50
                    kurs_speichern(con, "kalshi", mk, termin - 600, "k1m", gg, gg + 100, None, None, 1)
                    kurs_speichern(con, "kalshi", mk, termin + 300, "k1m", 100, 200, None, None, 1)
                    ergebnis_speichern(con, "kalshi", mk, 1 if kk < 0.4 else 0, None, 0.4, termin, 1)
            con.execute("INSERT INTO pm_spot VALUES ('BTC','perp30',?,100.0,101.0,98.0,99.0,1)", (termin,))
            con.execute("INSERT INTO pm_spot VALUES ('BTC','perp30',?,100.0,103.0,99.0,102.0,1)", (termin - 1800,))
        zz3 = ueberraschungen_berechnen(con, "KXCPI", "k1m")
        r = con.execute("SELECT median, streuung, u, r30_btc, r30_davor FROM pm_ueberraschung WHERE reihe='KXCPI'").fetchall()
        pruef("H3 von Hand (u = x − m, Kerze 08:30, nichts nach 08:30, Shutdown aus)", len(r) == 1 and abs(r[0][0] - 0.27) < 0.01
              and abs(r[0][2] - 0.13) < 0.01 and abs(r[0][3] - math.log(0.99)) < 1e-12 and abs(r[0][4] - math.log(1.02)) < 1e-12,
              str(r) + " " + str(zz3))
        # H2: Zulässigkeit der Schwellen (bis t0 notiert, Abstand bei t0), Spotquelle
        ende = et_zu_ts(*datetime.fromtimestamp(T_BASIS + 150 * 86400, UTC).timetuple()[:3], 17, 0)
        t0 = ende - 86400
        k2 = [(t, o * 1.1, h * 1.1, lo * 1.1, c * 1.1) if t >= t0 else (t, o, h, lo, c)
              for t, o, h, lo, c in _synthetische_spot(random.Random(9), T_BASIS, 160, 0.02)]
        with schreiben(con):
            spot_speichern(con, "BTC", k2, "coinbase", T_BASIS + 400 * 86400)
            spot_speichern(con, "BTC", [(t, o * 1.01, h * 1.01, lo * 1.01, c * 1.01) for t, o, h, lo, c in k2[:200000]], "binance",
                           T_BASIS + 400 * 86400)
        pruef("Eine Spotquelle (Coinbase) für die ganze Stichprobe",
              spot_laden(con, "BTC", T_BASIS, T_BASIS + 86400).schluss(T_BASIS + 3600) == next(x[4] for x in k2 if x[0] == T_BASIS + 3540))
        s0 = SpotReihe(k2).schluss(t0)
        with schreiben(con):
            meta_setzen(con, "stichtag", {"ts": ende + 86400})
            for j, f_k in enumerate((0.985, 0.99, 1.0, 1.01, 1.015, 1.5)):
                mk = "KXBTCD-X-T" + str(j)
                markt_speichern(con, {"plattform": "kalshi", "markt": mk, "reihe": "KXBTCD", "ereignis": "KXBTCD-X",
                                      "art": "schwelle", "strike_typ": "greater", "unten": s0 * f_k, "ende": ende,
                                      "handel_ab": (t0 + 600) if j == 1 else (t0 - 7200)}, 1)
                kurs_speichern(con, "kalshi", mk, (t0 + 3600) if j == 3 else t0, "k60m", 4000, 4200, None, None, 1)
                ergebnis_speichern(con, "kalshi", mk, 1, None, None, ende, 1)
        _, zz2, ein = faelle_h2(con, 86400)
        pruef("H2: nur bis t0 notierte, nahe Schwellen", sorted(x["markt"] for x in ein) == ["KXBTCD-X-T0", "KXBTCD-X-T2",
                                                                                             "KXBTCD-X-T4"],
              str(sorted(x["markt"] for x in ein)) + " " + str(zz2))
        con.close()
    sicher("G Datenbank", g)

    def h():
        uhr = [1_780_000_000.0]
        antworten = []

        def transport(methode, url, body, kopf, timeout):
            if not antworten:
                raise OSError("kein Netz")
            code, daten = antworten.pop(0)
            return code, json.dumps(daten).encode()
        ab = Abrufer(transport=transport, uhr=lambda: uhr[0], schlafen=lambda s: uhr.__setitem__(0, uhr[0] + s))
        antworten.append((429, {"error": "too many requests"}))
        c1, _ = ab.holen("kalshi", "/markets")
        pruef("429 → Pause 60 s", c1 == 429 and abs(ab.pause_bis["kalshi"] - uhr[0] - 60) < 1.5 and ab.holen("kalshi")[0] == -1)
        uhr[0] += 61
        antworten.extend([(500, {}), (500, {}), (500, {})])
        for _ in range(3):
            ab.holen("kalshi", "/x")
        pruef("3 Fehler → Pause 15 min", abs(ab.pause_bis["kalshi"] - uhr[0] - 900) < 2)
        uhr[0] += 901
        antworten.append((500, {}))
        ab.holen("kalshi", "/x")
        pruef("Pause verdoppelt", abs(ab.pause_bis["kalshi"] - uhr[0] - 1800) < 2)
        antworten.extend([(403, {}), (404, {})])
        ab.holen("pm_gamma", "/x")
        c4, _ = ab.holen("pm_gamma", "/y")
        pruef("403 gezählt, 404 ohne Pause", ab.zaehler.get(("pm_gamma", "gesperrt")) == 1 and c4 == 404
              and not ab.pausiert("pm_gamma"))
        con = verbinden(":memory:")
        rb = Rueckblick(con, ab, uhr=lambda: uhr[0])
        pruef("Rückblick wartet auf den Stichtag", rb.schritt() is False)
        uhr[0] += 30000
        ab.pause_bis.clear()
        ab.pause_s.clear()
        ab.folge.clear()
        with schreiben(con):
            meta_setzen(con, "stichtag", {"ts": int(uhr[0])})
        antworten.extend([(200, {"market_settled_ts": 1_779_000_000}),
                          (200, {"markets": [{"ticker": "KXCPI-26JAN-T0.2", "result": "yes", "close_time": "2026-02-11T13:25:00Z"}],
                                 "cursor": "c2"}),
                          (200, {"markets": [{"ticker": "KXCPI-26FEB-T0.2", "result": "no", "close_time": "2026-03-11T12:25:00Z"}],
                                 "cursor": ""}),
                          (200, {"markets": [], "cursor": ""})])
        for _ in range(4):
            rb.schritt()
        st = meta(con, "rb:liste:KXCPI", {})
        pruef("Rückblick mit Cursor", st.get("fertig") and st.get("n_live") == 2 and (meta(con, "kalshi_grenze", {}) or {}).get(
            "grenze") == 1_779_000_000, str(st))
        rb2 = Rueckblick(con, ab, uhr=lambda: uhr[0])

        def kaputt(_st):
            raise KeyError("feld_fehlt")
        rb2.teile = [("probe_kaputt", "kalshi", kaputt)]
        weiter = all(rb2.schritt() for _ in range(3))
        st_k, fk = meta(con, "rb:probe_kaputt", {}), meta(con, "fehler_rb:probe_kaputt", {})
        pruef("Rückblick: Ausnahme in einem Teil hält den Dienst nicht an (als Fehler gezählt, Grund in pm_meta)",
              weiter and st_k.get("fehler") == 3 and "KeyError" in str(fk.get("fehler")), str(st_k))
        for _ in range(17):
            rb2.schritt()
        st_k = meta(con, "rb:probe_kaputt", {})
        pruef("… nach 20 Ausnahmen in Folge abgebrochen, mit Vermerk", st_k.get("fertig") and st_k.get("abgebrochen"), str(st_k))
        with schreiben(con):
            meta_setzen(con, "erstlauf", {"ts": int(uhr[0]), "text": ["Prognosemärkte: Erstlauf", "Probezeile A", "Probezeile B"]})
        bs = bericht_stand(con, rb, int(uhr[0]))
        pruef("Stand zeigt Erstlauf und Dienst", "  Probezeile A" in bs and "Erstlauf (Formatprüfung" in bs
              and "Dienst im Dashboard: noch kein Zustand" in bs and "fehler_rb" not in bs and "Fehler rb:probe_kaputt" in bs, bs[-300:])
        tk = Takt(con, ab, uhr=lambda: uhr[0])
        antworten.append((200, {"outcomes": [{"outcome": 1, "name": "BTC", "description":
                                              "class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d"}]}))
        tk.hip4_meta()
        pruef("HIP-4 Liste gespeichert", con.execute("SELECT unten, strike_typ FROM pm_markt WHERE plattform='hip4'").fetchone()
              == (78213.0, "greater"))
        con.close()
    sicher("H Abruf", h)
    sicher("I Ende zu Ende (Ersatz-Netz)", lambda: _ende_zu_ende(pruef))
    sicher("J U236 (23.89)", lambda: _u236_pruefungen(pruef))
    if not still:
        for name, ok, hinweis in erg:
            print(("ok    " if ok else "ROT   ") + name + (" — " + hinweis.replace("\n", " | ")[:400] if hinweis else ""))
    return erg


def _u236_pruefungen(pruef) -> None:
    """23.89 (U236): Befunde des ersten Betriebs auf dem Pi -- mit ECHTEM Gewichtsdeckel und simulierter Uhr (der Selbsttest bis
    23.88 lief mit unbegrenztem Gewicht und konnte die fehlende Abrechnung nicht zeigen)."""
    t0 = utc_ts(datetime(2026, 10, 28, 12, 0, tzinfo=UTC))

    # 1. Beschreibungsformate und Auswahl
    h2 = hip4_beschreibung("perp:xyz:LLY|priceDescription:1-minute candle|seconds:300|threshold:1450|time:20261030-1335")
    h3 = hip4_beschreibung("participant:Buffalo Bills")
    hb = hip4_beschreibung("class:priceBinary|underlying:ETH|expiry:20261029-0600|targetPrice:3900|period:1d")
    pruef("U236 HIP-4: zweites und drittes Beschreibungsformat gelesen; relevant nur Krypto-Preisbinäre der Projekt-Coins",
          h2["klasse"] == "perpSchwelle" and h2["basis"] == "LLY" and h2["ziel"] == 1450
          and h2["ablauf"] == utc_ts(datetime(2026, 10, 30, 13, 35, tzinfo=UTC)) and h3["klasse"] == "teilnehmer"
          and h3["ablauf"] is None and hip4_relevant(hb) and not hip4_relevant(h2) and not hip4_relevant(h3)
          and not hip4_relevant({"klasse": "priceBinary", "basis": "DOGE"}), str((h2, h3)))

    # 2. Gewichtsplan mit echtem Deckel: 3 relevante, 50 irrelevante Ausgänge, 45 min simuliert
    uhr = [float(t0)]
    aufrufe: list[tuple] = []
    ausgaenge = {1: "class:priceBinary|underlying:BTC|expiry:20261028-1230|targetPrice:80000|period:1d",   # Ablauf nach 30 min
                 2: "class:priceBinary|underlying:ETH|expiry:20261029-0600|targetPrice:3900|period:1d",
                 3: "class:priceBinary|underlying:HYPE|expiry:20261029-0600|targetPrice:40|period:1d"}
    for n in range(10, 60):
        ausgaenge[n] = ("perp:xyz:S%d|priceDescription:1-minute candle|seconds:300|threshold:100|time:20261030-1335" % n
                        if n % 2 else "participant:Team %d" % n)

    def hl_netz(methode, url, body, kopf, timeout):
        b = json.loads(body)
        aufrufe.append((uhr[0], b["type"], b.get("coin") if b["type"] == "l2Book" else b.get("outcome")))
        if b["type"] == "outcomeMeta":
            weg = {1} if uhr[0] >= t0 + 1800 else set()
            if uhr[0] >= t0 + 1200:
                weg.add(11)                                  # ein Aktien-Perp verschwindet ohne Ablauf
            return 200, json.dumps({"outcomes": [{"outcome": n, "name": str(n), "description": d}
                                                 for n, d in ausgaenge.items() if n not in weg]}).encode()
        if b["type"] == "l2Book":
            return 200, json.dumps({"levels": [[{"px": "0.40"}], [{"px": "0.42"}]]}).encode()
        if b["type"] == "settledOutcome":
            return 200, json.dumps({"settleFraction": "1", "details": "price:80100"}).encode()
        return 200, b"[]"

    gew = LokalesGewicht(je_minute=HL_GEWICHT_JE_MINUTE, uhr=lambda: uhr[0])
    ab = Abrufer(transport=hl_netz, uhr=lambda: uhr[0], schlafen=lambda s: uhr.__setitem__(0, uhr[0] + s), hl_gewicht=gew)
    con = verbinden(":memory:")
    with schreiben(con):
        meta_setzen(con, "stichtag", {"ts": t0 - 3600})
    tk = Takt(con, ab, uhr=lambda: uhr[0])
    while uhr[0] < t0 + 45 * 60:
        tk.hip4_takt()
        uhr[0] += 10
    metas = [t for t, typ, _ in aufrufe if typ == "outcomeMeta"]
    luecke = max((b - a for a, b in zip(metas, metas[1:])), default=9999)
    buecher = [k for _, typ, k in aufrufe if typ == "l2Book"]
    je_buch = {k: buecher.count(k) for k in ("#10", "#20", "#30")}
    abgerechnet = con.execute("SELECT ergebnis FROM pm_ergebnis WHERE plattform='hip4' AND markt='#10'").fetchone()
    perp_ende = con.execute("SELECT ende FROM pm_markt WHERE plattform='hip4' AND markt='#110'").fetchone()
    st = meta(con, "rb:hip4", {}) or {}
    ohne = ab.zaehler.get(("hl", "kein_gewicht"), 0)
    pruef("U236 HIP-4 mit echtem Deckel (20 je Minute, 45 min simuliert): Meta höchstens alle 400 s, Bücher nur relevante und "
          "reihum, abgelaufener Ausgang abgerechnet, verschwundener Aktien-Perp geschlossen, Rückblick schreitet voran, kein "
          "Abruf ohne Gewicht",
          len(metas) >= 7 and luecke <= 400 and set(buecher) <= {"#10", "#20", "#30"} and min(je_buch.values()) >= 5
          and abgerechnet == (1,) and perp_ende is not None and perp_ende[0] is not None and perp_ende[0] <= uhr[0]
          and int(st.get("schritte", 0)) >= 3 and int(st.get("n", 0)) >= 1 and ohne == 0,
          "Meta " + str(len(metas)) + " (Lücke " + str(int(luecke)) + " s), Bücher " + str(je_buch) + " von " + str(len(buecher))
          + ", fremde " + str(sorted(set(buecher) - {"#10", "#20", "#30"})[:3]) + ", abgerechnet " + str(abgerechnet)
          + ", Perp-Ende " + str(perp_ende) + ", Rückblick " + str({k: st.get(k) for k in ("schritte", "n", "i", "max")})
          + ", ohne Gewicht " + str(ohne))
    con.close()

    # 3. Rückblick-Faden: Teil hip4 wartet ohne Leerlauf
    con = verbinden(":memory:")
    uhr2 = [float(t0)]
    rb = Rueckblick(con, Abrufer(transport=lambda *a: (599, b""), uhr=lambda: uhr2[0], schlafen=lambda s: None),
                    uhr=lambda: uhr2[0])
    with schreiben(con):
        meta_setzen(con, "stichtag", {"ts": t0 - 3600})
        for name, _, _ in rb.teile:
            if name != "hip4":
                meta_setzen(con, "rb:" + name, {"fertig": True})
    erg = [rb.schritt() for _ in range(5)]
    st = meta(con, "rb:hip4", {}) or {}
    pruef("U236 Rückblick: Teil hip4 wartet auf den Takt -- kein Schritt, kein Schreiben, die Runde endet",
          erg == [False] * 5 and not st.get("schritte"), str(erg) + " " + str(st))
    con.close()

    # 4. Polymarket: Kennung ohne Orderbuch ruht, entschiedene Leiter nicht abgefragt
    uhr3 = [float(t0)]
    einzeln: list[str] = []
    sammel: list[str] = []

    def pm_netz(methode, url, body, kopf, timeout):
        u = urllib.parse.urlparse(url)
        if u.path.endswith("/books"):
            toks = [x["token_id"] for x in json.loads(body)]
            sammel.extend(toks)
            return 200, json.dumps([{"asset_id": t, "bids": [{"price": "0.49"}], "asks": [{"price": "0.51"}]}
                                    for t in toks if t != "999"]).encode()
        if u.path.endswith("/book"):
            einzeln.append(dict(urllib.parse.parse_qsl(u.query)).get("token_id"))
            return 404, b'{"error": "No orderbook exists for the requested token id"}'
        return 200, b"[]"

    ab = Abrufer(transport=pm_netz, uhr=lambda: uhr3[0], schlafen=lambda s: uhr3.__setitem__(0, uhr3[0] + s))
    con = verbinden(":memory:")
    with schreiben(con):
        for mk, tok in (("0xa", "111"), ("0xb", "999"), ("0xc", "555")):
            con.execute("INSERT INTO pm_markt (plattform, markt, art, kennung_ja, ende, erstmals, zuletzt) VALUES "
                        "('polymarket', ?, 'beruehrung', ?, ?, ?, ?)", (mk, tok, t0 + 86400, t0, t0))
        ergebnis_speichern(con, "polymarket", "0xc", 1, None, None, t0 + 86400, t0, {"outcomePrices": "geschlossen"})
    tk = Takt(con, ab, uhr=lambda: uhr3[0])
    for _ in range(3):
        tk.pm_leitern()
        uhr3[0] += 400
    n111 = con.execute("SELECT COUNT(*) FROM pm_kurs WHERE plattform='polymarket' AND markt='0xa'").fetchone()[0]
    pruef("U236 Polymarket: Kennung ohne Orderbuch ruht 6 h, entschiedene Leiter wird nicht mehr abgefragt",
          einzeln == ["999"] and "555" not in sammel and ab.zaehler.get(("pm_clob", "ohne_buch_ruht")) == 2 and n111 >= 1,
          "einzeln " + str(einzeln) + ", Sammelabruf " + str(sammel) + ", ruht " + str(ab.zaehler.get(("pm_clob", "ohne_buch_ruht"))))
    con.close()

    # 5. Stand: Alter nie negativ; IP-Adresse weder angezeigt noch gespeichert
    con = verbinden(":memory:")
    with schreiben(con):
        kurs_speichern(con, "kalshi", "X", t0 + 5, "live", 4900, 5100, None, None, t0 + 5)
        meta_setzen(con, "abruf_zustand", {"ts": t0 + 3})
        meta_setzen(con, "erstlauf", {"ts": t0, "text": ["Prognosemärkte: Erstlauf", 'Polymarket Geoblock: HTTP 200 {"blocked": '
                                                         'true, "ip": "198.51.100.9", "country": "DE", "region": "BE"}']})
    bs = bericht_stand(con, None, t0)
    geaendert = erstlauf_ohne_ip(con)
    pruef("U236 Stand: Alter nie negativ; IP-Adresse weder angezeigt noch nach dem Aufräumen gespeichert",
          "vor -0" not in bs and "vor 0 min" in bs and "198.51.100.9" not in bs and geaendert
          and "198.51.100.9" not in json.dumps(meta(con, "erstlauf", {})) and '"country": "DE"' in bs, bs[-260:])
    con.close()

    # 6. Kopf des Urteils: Gewichte auf die prüfbaren Tests normiert
    con = verbinden(":memory:")
    with schreiben(con):
        for pr, ph in (("H1", None), ("H2", 0.03), ("H3", 0.01)):
            con.execute("INSERT INTO pm_auswertung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (pr, 100, 10, 10, 0.1, 0.0, 0.2, ph, ph, 0.1, 0.1, "x", 1, VERSION_AUSWERTUNG, "{}"))
    t = holm_text(con, 100)
    pruef("U236 Kopf des Urteils nennt die normierten Gewichte (R5)", "H2 0,33" in t and "H3 0,67" in t
          and "nicht prüfbar: H1" in t, t)
    con.close()


def _ersatz_netz(jetzt: int):
    """Ersatz für alle Quellen (nur Selbsttest): plausible Antworten je Pfad, deterministisch."""
    def kurs(ts):
        return 80000.0 * math.exp(0.02 * math.sin(ts / 50000.0) + 0.003 * math.sin(ts / 997.0))

    def k15(i, status):
        ende = (jetzt - jetzt % 900) - i * 900
        t = et(ende)
        tk = "KXBTC15M-" + t.strftime("%y") + MONATE_KALSHI[t.month - 1] + t.strftime("%d%H%M") + "-00"
        return {"ticker": tk, "event_ticker": tk[:-3], "close_time": von_ts(ende).isoformat(), "open_time":
                von_ts(ende - 900).isoformat(), "yes_bid_dollars": "0.4900", "yes_ask_dollars": "0.5100", "status": status,
                "result": ("yes" if i % 2 else "no") if status == "settled" else "", "floor_strike": kurs(ende - 900),
                "strike_type": "greater"}

    def cpi(i):
        termin = et_zu_ts(2026, 10, 15, 8, 30)
        return {"ticker": "KXCPI-26SEP-T" + str(round(0.1 * i, 1)), "event_ticker": "KXCPI-26SEP", "strike_type": "greater",
                "floor_strike": round(0.1 * i, 1), "close_time": von_ts(termin - 300).isoformat(), "result":
                "yes" if 0.1 * i < 0.3 else "no", "expiration_value": "0.3", "status": "settled"}

    def btcd(i):
        ende = et_zu_ts(2026, 10, 26, 17, 0)
        k = 79000 + 500 * i
        return {"ticker": "KXBTCD-26OCT2617-T" + str(k - 0.01), "event_ticker": "KXBTCD-26OCT2617", "strike_type": "greater",
                "floor_strike": k - 0.01, "close_time": von_ts(ende).isoformat(), "open_time": von_ts(ende - 90000).isoformat(),
                "result": "yes" if kurs(ende) > k else "no", "status": "settled"}

    def antwort(methode, url, body):
        u = urllib.parse.urlparse(url)
        q = dict(urllib.parse.parse_qsl(u.query))
        pfad, host = u.path, u.netloc
        if host == "external-api.kalshi.com":
            if pfad.endswith("/historical/cutoff"):
                return 200, {"market_settled_ts": jetzt - 30 * 86400}
            if pfad.endswith("/candlesticks"):
                a, b, per = int(q["start_ts"]), int(q["end_ts"]), int(q["period_interval"]) * 60
                return 200, {"candlesticks": [{"end_period_ts": t, "yes_bid": {"close_dollars": "0.4800"},
                                               "yes_ask": {"close_dollars": "0.5100"}, "price": {"close_dollars": None}}
                                              for t in range(a - a % per + per, b + 1, per)]}
            if pfad.endswith("/orderbook"):
                return 200, {"orderbook_fp": {"yes_dollars": [["0.48", "5"]], "no_dollars": [["0.50", "5"]]}}
            if pfad.endswith("/markets/trades"):
                return 200, {"trades": [], "cursor": ""}
            if pfad.endswith("/events"):
                if q.get("series_ticker") == "KXBTCD":
                    return 200, {"events": [{"event_ticker": "KXBTCD-26OCT2617"}, {"event_ticker": "KXBTCD-26OCT2610"}],
                                 "cursor": ""}
                return 200, {"events": [], "cursor": ""}
            if pfad.endswith("/markets") or pfad.endswith("/historical/markets"):
                r = q.get("series_ticker") or ""
                if q.get("event_ticker") == "KXBTCD-26OCT2617" and pfad.endswith("/markets"):
                    return 200, {"markets": [btcd(i) for i in range(6)], "cursor": ""}
                if "historical" in pfad:
                    return 200, {"markets": [], "cursor": ""}
                if r == "KXBTC15M":
                    st = q.get("status", "open")
                    return 200, {"markets": [k15(i, st) for i in ((-1,) if st == "open" else range(1, 4))], "cursor": ""}
                if r == "KXCPI" and q.get("status") == "settled":
                    return 200, {"markets": [cpi(i) for i in range(6)], "cursor": ""}
                return 200, {"markets": [], "cursor": ""}
            return 404, {}
        if host == "gamma-api.polymarket.com":
            if pfad.startswith("/events/slug/"):
                slug = pfad.rsplit("/", 1)[1]
                return 200, {"slug": slug, "title": slug, "markets": [{"conditionId": "0x" + slug[-12:], "clobTokenIds":
                             "[\"" + str(abs(hash(slug)) % 10 ** 9) + "\", \"2\"]", "outcomes": "[\"Up\", \"Down\"]",
                             "outcomePrices": "[\"0.5\", \"0.5\"]", "question": "↑ 120,000", "groupItemTitle": "120,000"}]}
            if pfad == "/public-search":
                return 200, {"events": []}
            return 200, []
        if host == "clob.polymarket.com":
            if pfad == "/books":
                return 200, [{"asset_id": x["token_id"], "bids": [{"price": "0.49"}], "asks": [{"price": "0.51"}]}
                             for x in json.loads(body)]
            if pfad == "/book":
                return 200, {"bids": [{"price": "0.49"}], "asks": [{"price": "0.51"}]}
            if pfad == "/prices-history":
                return 200, {"history": [{"t": int(q["startTs"]) + 60 * i, "p": 0.5} for i in range(3)]}
            return 200, {"mid": "0.5"}
        if host == "data-api.polymarket.com":
            return 200, {"history": []}
        if host == "api.hyperliquid.xyz":
            b = json.loads(body)
            if b["type"] == "outcomeMeta":      # U236: alle drei Formate wie im Erstlauf am 28.10.
                return 200, {"outcomes": [{"outcome": 2, "name": "BTC", "description":
                                           "class:priceBinary|underlying:BTC|expiry:20261028-0600|targetPrice:80000|period:1d"},
                                          {"outcome": 5, "name": "LLY", "description": "perp:xyz:LLY|priceDescription:1-minute "
                                           "candle|seconds:300|threshold:1450|time:20261030-1335"},
                                          {"outcome": 7, "name": "Bills", "description": "participant:Buffalo Bills"}]}
            if b["type"] == "l2Book":
                return 200, {"levels": [[{"px": "0.40"}], [{"px": "0.42"}]]}
            if b["type"] == "settledOutcome":
                return 200, {"settleFraction": "0", "details": "price:79000"}
            return 200, []
        if host == "api.exchange.coinbase.com" and pfad.endswith("/candles"):
            a = iso_ts(q["start"])
            e = min(iso_ts(q["end"]), jetzt - 60)
            a -= a % 60
            return 200, [[t, kurs(t) * 0.9995, kurs(t) * 1.0005, kurs(t), kurs(t + 60), 1.0] for t in range(e - e % 60, a - 1, -60)]
        if host == "api.binance.com" and pfad == "/api/v3/time":
            return 200, {"serverTime": jetzt * 1000}
        if host in ("api.binance.com", "fapi.binance.com"):
            iv = {"1m": 60, "30m": 1800}[q["interval"]]
            a = int(q.get("startTime", (jetzt - 120) * 1000)) // 1000
            a -= a % iv
            e = min(int(q.get("endTime", jetzt * 1000)) // 1000, jetzt)
            n = min(int(q.get("limit", 500)), max(0, (e - a) // iv + 1))
            return 200, [[(a + i * iv) * 1000, str(kurs(a + i * iv)), str(kurs(a + i * iv) * 1.0005), str(kurs(a + i * iv) * 0.9995),
                          str(kurs(a + i * iv + iv)), "1"] for i in range(n)]
        if host == "polymarket.com":           # U236: mit IP-Adresse wie die echte Antwort (Adresse aus dem Dokumentationsbereich)
            return 200, {"blocked": True, "ip": "192.0.2.77", "country": "DE", "region": "BE"}
        return 404, {}

    def transport(methode, url, body, kopf, timeout):
        code, daten = antwort(methode, url, body)
        return code, json.dumps(daten).encode("utf-8")
    return transport


def _ende_zu_ende(pruef) -> None:
    """Takt, Rückblick, Auswertung, Berichte, Nutzlast und Erstlauf gegen das Ersatz-Netz: nichts darf abbrechen."""
    jetzt = utc_ts(datetime(2026, 10, 27, 18, 0, tzinfo=UTC))
    uhr = [float(jetzt)]
    ab = Abrufer(transport=_ersatz_netz(jetzt), uhr=lambda: uhr[0], schlafen=lambda s: uhr.__setitem__(0, uhr[0] + s),
                 hl_gewicht=lambda g, rang="": True)
    con = verbinden(":memory:")
    txt = erstlauf(con, ab, jetzt=jetzt)
    pruef("Erstlauf (Ersatz-Netz) setzt den Stichtag", stichtag(con) == jetzt and "HIP-4 outcomeMeta: HTTP 200" in txt
          and "Kalshi Archivgrenze: HTTP 200" in txt and "Uhrabweichung" in txt, txt[-300:])
    gespeichert = json.dumps(meta(con, "erstlauf", {}), ensure_ascii=False)
    pruef("U236 Erstlauf ohne IP-Adresse (Ausgabe und gespeicherter Text), Sperre und Land bleiben",
          "192.0.2.77" not in txt and "192.0.2.77" not in gespeichert and '"blocked": true' in txt and '"country": "DE"' in txt,
          str([x for x in txt.splitlines() if "Geoblock" in x][:1]))
    tk = Takt(con, ab, uhr=lambda: uhr[0])
    tk.schritt()
    uhr[0] += 61                # U236: HIP-4 nach Plan -- erst die Meta, im nächsten Schritt die Bücher
    tk.schritt()
    fehler = [k for (k,) in con.execute("SELECT schluessel FROM pm_meta WHERE schluessel LIKE 'fehler_%'")]
    pruef("Takt ohne Fehler", not fehler, ", ".join(fehler) + " " + str([meta(con, f) for f in fehler])[:300])
    pruef("Takt speichert Kalshi, Polymarket, HIP-4", {r[0] for r in con.execute("SELECT DISTINCT plattform FROM pm_kurs")}
          >= {"kalshi", "polymarket", "hip4"})
    rb = Rueckblick(con, ab, uhr=lambda: uhr[0])
    alt_vorlauf = dict(SPOT_VORLAUF_TAGE)
    SPOT_VORLAUF_TAGE["BTC"] = 40          # nur hier: Leitungsprobe, nicht HAR
    try:
        for _ in range(20000):
            if not rb.schritt():
                break
    finally:
        SPOT_VORLAUF_TAGE.clear()
        SPOT_VORLAUF_TAGE.update(alt_vorlauf)
    for _ in range(60):         # U236: der HIP-4-Rückblick schreitet im Gewichtsplan des Takts voran
        if (meta(con, "rb:hip4", {}) or {}).get("fertig"):
            break
        uhr[0] += 61
        tk.hip4_takt()
    offen = [t["teil"] for t in rb.stand() if not t.get("fertig")]
    abgebrochen = [t["teil"] for t in rb.stand() if t.get("abgebrochen")]
    pruef("Rückblick läuft durch", not offen and not abgebrochen, "offen " + str(offen) + " abgebrochen " + str(abgebrochen))
    pruef("Rückblick: Kerzen 15 min, Tagesleiter, Makro", all(con.execute(
        "SELECT COUNT(*) FROM pm_kurs WHERE quelle=?", (q,)).fetchone()[0] > 0 for q in ("k1m", "k60m")))
    v = (meta(con, "rb:spot:BTC", {}) or {}).get("von")
    n_spot = con.execute("SELECT COUNT(*) FROM pm_spot WHERE coin='BTC' AND quelle=? AND ts>=?", (SPOT_QUELLE["BTC"][0],
                                                                                              v or 0)).fetchone()[0]
    pruef("Spot lückenlos ab Rückblickbeginn (trotz Live-Daten)", v is not None and n_spot >= (jetzt - 180 - v) // 60 - 2,
          str(n_spot) + " von " + str((jetzt - v) // 60 if v else 0))
    a = auswerten(con, lauf=jetzt, ziehungen=200, perm=200)
    pruef("Auswertung läuft (Freigabe, Prüfungen vor dem Urteil)", a.get("phase") in ("pruefung_nicht_bestanden", "urteil"),
          str(a.get("phase")) + " " + str(a.get("grund", "")) + " " + str([x for x in a.get("vor_urteil", []) if not x[1]])[:300])
    keine = con.execute("SELECT COUNT(*) FROM pm_auswertung WHERE endgueltig=1").fetchone()[0]
    pruef("Ohne bestandene Prüfungen kein Urteil und keine Zahlen", a.get("phase") == "urteil" or (
        keine == 0 and con.execute("SELECT COUNT(*) FROM pm_auswertung WHERE p IS NOT NULL").fetchone()[0] == 0))
    t1, t2 = bericht_auswertung(con), bericht_stand(con, rb)
    with schreiben(con):   # ein Fenster, das erst in 10 min beginnt: Spotmodell genau 50 %
        con.execute("INSERT OR IGNORE INTO pm_markt (plattform, markt, reihe, art, basis, beginn, ende, unten, erstmals, zuletzt) "
                    "VALUES ('kalshi', 'KXBTC15M-PROBE-VOR', 'KXBTC15M', 'aufab', 'BTC', ?, ?, 80000.0, ?, ?)",
                    (jetzt + 600, jetzt + 1500, jetzt, jetzt))
    nl = {t: nutzlast(con, jetzt, t) for t in ("ueberblick", "krypto", "makro", "ereignisse", "bilanz", "rueckblick", "daten")}
    pruef("Berichte und Nutzlast (alle Reiter)", "H1" in t1 and "Rückblick" in t2 and all(
        isinstance(json.dumps(_ohne_nan(v), allow_nan=False), str) for v in nl.values()) and nl["ueberblick"]["fenster"]
        and nl["daten"]["quellen"], str({k: len(json.dumps(v, default=str)) for k, v in nl.items()}))
    pruef("Vor dem Urteil keine Ergebnisgrößen in der Nutzlast (R4)", a.get("phase") == "urteil" or (
        "urteil" not in nl["bilanz"] and "termine" not in nl["makro"] and "zaehlung" in nl["bilanz"]))
    fe = nl["ueberblick"]["fenster"]
    vorher = [z for z in fe if z["plattform"] == "kalshi" and z.get("spot_ts") and z["spot_ts"] <= z["beginn"] - 60]
    mit = [z for z in fe if z.get("p_s") is not None]
    m = _spot_modell(con, "BTC", jetzt)
    hand = None
    if m:
        s_, v_ = m[0].schluss_bis(m[1]), m[0].sigma2_tag(m[1])
        hand = (_p_spot_leiter(m, "schwelle", "greater", s_ * 1.01, None, m[1] + 86400),
                p_ueber(s_, s_ * 1.01, math.sqrt(v_ / 86400.0 * 86400)),
                _p_spot_leiter(m, "beruehrung", "greater", s_ * 0.97, None, m[1] + 86400),
                p_beruehrt(s_, s_ * 0.97, math.sqrt(v_)))
    pruef("Spot-Echo im Überblick und an Leitern (nur Anzeige): Spotmodell da, vor der Mittelungsminute genau 50 %, Schwelle und "
          "Berührung wie von Hand", mit and all(z["p_s"] == 0.5 for z in vorher) and hand and abs(hand[0] - hand[1]) < 1e-12
          and abs(hand[2] - hand[3]) < 1e-12 and 0.0 < hand[1] < 0.5,
          str(len(mit)) + " von " + str(len(fe)) + " Fenstern, vor dem Beginn " + str([z["p_s"] for z in vorher][:4]) + ", Hand " + str(hand))
    con.close()


def mutationen_pruefen(welten: int = 20, ziehungen: int = 199) -> list[tuple[str, bool, list[str]]]:
    """Jede Mutation muss mindestens eine Prüfung rot machen (Konzept 8.2)."""
    global _MUT
    aus = []
    for m in MUTATIONEN:
        _MUT = m
        try:
            rot = [n for n, ok, _ in selbsttest(welten, ziehungen, still=True) if not ok]
        finally:
            _MUT = None
        aus.append((m, bool(rot), rot))
    return aus


# ---------------------------------------------------------------------------
# 14. Erstlauf (8.4), Dienst und Befehlszeile
# ---------------------------------------------------------------------------

HOSTS["pm_web"] = "https://polymarket.com"
TAKT_JE_S["pm_web"] = 1.0
HOSTS["binance_zeit"] = "https://api.binance.com/api/v3/time"
TAKT_JE_S["binance_zeit"] = 1.0


def erstlauf(con, ab: Abrufer | None = None, jetzt: int | None = None) -> str:
    """Formatprüfung auf dem Pi (Nachtrag R15): nur Anzahlen, Anteile und Beispiele, keine Ergebnisse. Setzt beim ersten Lauf
    den Stichtag des Rückblicks (R2). Ergebnis in pm_meta 'erstlauf' und als Text."""
    ab = ab or Abrufer()
    jetzt = int(jetzt or time.time())
    z = ["Prognosemärkte: Erstlauf " + _uhr(jetzt)]
    roh: dict = {}

    def kurz(d, n=600):
        return json.dumps(d, ensure_ascii=False, default=str)[:n]

    if stichtag(con) is None:
        with schreiben(con):
            meta_setzen(con, "stichtag", {"ts": jetzt, "gesetzt": "Erstlauf"})
    z.append("Stichtag des Rückblicks: " + _uhr(stichtag(con)) + " (Märkte mit Handelsschluss davor; R2)")
    t_a = time.time()
    code, d = ab.holen("binance_zeit")
    t_b = time.time()
    if code == 200 and isinstance(d, dict) and d.get("serverTime"):
        z.append("Uhrabweichung des Pi gegen Binance: " + _de(d["serverTime"] / 1000.0 - (t_a + t_b) / 2.0, 2) + " s (Rundlauf "
                 + _de(t_b - t_a, 2) + " s)")
    else:
        z.append("Uhrabweichung: Binance-Zeit nicht erreichbar (HTTP " + str(code) + ")")

    code, d = ab.holen("kalshi", "/historical/cutoff")
    z.append("Kalshi Archivgrenze: HTTP " + str(code) + " " + kurz(d, 300))
    for reihe in ("KXBTC15M", "KXETH15M", "KXHYPE15M", "KXZEC15M", "KXBTCD", "KXCPI", "KXFED", "KXGOLDD", "KXBTCMAXY"):
        code, d = ab.holen("kalshi", "/markets", {"series_ticker": reihe, "status": "open", "limit": 5})
        ms = (d or {}).get("markets") or [] if isinstance(d, dict) else []
        zeile = "Kalshi " + reihe + ": HTTP " + str(code) + ", offen (Probe) " + str(len(ms))
        if ms:
            m = kalshi_markt(ms[0])
            roh[reihe] = ms[0]
            zeile += ", Felder " + ",".join(sorted(ms[0].keys()))[:300]
            if m["ende"] and m["beginn"]:
                zeile += "; Handelsbeginn " + _de((m["ende"] - m["beginn"]) / 60.0, 1) + " min vor Schluss"
            if reihe == "KXCPI" and m["ende"]:
                zeile += "; Schluss " + et(m["ende"]).strftime("%d.%m. %H:%M ET")
        z.append(zeile)
    code, d = ab.holen("kalshi", "/markets", {"series_ticker": "KXBTC15M", "status": "settled", "limit": 30,
                                              "max_close_ts": stichtag(con)})
    ms = (d or {}).get("markets") or [] if isinstance(d, dict) else []
    vor60 = vor120 = probe = 0
    for roh_m in ms[:30]:
        mm = kalshi_markt(roh_m)
        kalshi_einordnen(mm, "KXBTC15M", KALSHI_REIHEN["KXBTC15M"])
        if not mm["beginn"]:
            continue
        ck, kd2 = ab.holen("kalshi", "/series/KXBTC15M/markets/" + mm["markt"] + "/candlesticks",
                           {"start_ts": mm["beginn"] - 360, "end_ts": mm["beginn"] + 120, "period_interval": 1})
        if ck != 200:
            continue
        probe += 1
        kk = {k["ts"]: k for k in kalshi_kerzen(kd2)}
        vor60 += int(mitte((kk.get(mm["beginn"] - 60) or {}).get("geld"), (kk.get(mm["beginn"] - 60) or {}).get("brief")) is not None)
        vor120 += int(mitte((kk.get(mm["beginn"] - 120) or {}).get("geld"), (kk.get(mm["beginn"] - 120) or {}).get("brief"))
                      is not None)
    z.append("Kalshi 15 min vor dem Beginn (entscheidet, ob H1 prüfbar ist): gültiger Kurs bei B − 60 s in " + str(vor60)
             + " und bei B − 120 s in " + str(vor120) + " von " + str(probe) + " Probefenstern")
    if ms:
        z.append("  Beispiel floor_strike " + str(ms[0].get("floor_strike")) + ", expiration_value " + str(ms[0].get("expiration_value"))
                 + ", Regeln: " + str(ms[0].get("rules_primary") or "")[:300])
    if ms:
        m = kalshi_markt(ms[0])
        cfg = KALSHI_REIHEN["KXBTC15M"]
        kalshi_einordnen(m, "KXBTC15M", cfg)
        c2, kd = ab.holen("kalshi", "/series/KXBTC15M/markets/" + m["markt"] + "/candlesticks",
                          {"start_ts": m["beginn"] - 600, "end_ts": m["ende"], "period_interval": 1})
        kerzen = kalshi_kerzen(kd, 60) if c2 == 200 else []
        c3, td = ab.holen("kalshi", "/markets/trades", {"ticker": m["markt"], "limit": 1000})
        trades = (td or {}).get("trades") or [] if isinstance(td, dict) else []
        z.append("Kalshi Kerzen abgerechneter Markt: HTTP " + str(c2) + ", " + str(len(kerzen)) + " Kerzen, erste Kerze "
                 + (_de((kerzen[0]["ts"] - m["beginn"]) / 60.0, 0) + " min nach Fensterbeginn" if kerzen else "–")
                 + "; Trades HTTP " + str(c3) + ", " + str(len(trades)))
        treffer = 0
        for k in kerzen:
            vor = [t for t in trades if k["ts"] - 60 < (iso_ts(t.get("created_time")) or 0) <= k["ts"]]
            if vor and k["preis"] is not None:
                letzt = max(vor, key=lambda t: iso_ts(t.get("created_time")) or 0)
                treffer += int(preis(letzt.get("yes_price_dollars")) == k["preis"])
        z.append("  Zeitstempel = Periodenende? Schlusskurs der Kerze = letzter Trade in (ts−60, ts]: " + str(treffer)
                 + " Treffer (muss > 0 sein, sonst Semantik prüfen)")
        roh["kerze"] = (kd or {}).get("candlesticks", [])[:2] if isinstance(kd, dict) else None
    code, d = ab.holen("kalshi", "/historical/markets", {"series_ticker": "KXCPI", "limit": 5})
    ms = (d or {}).get("markets") or [] if isinstance(d, dict) else []
    z.append("Kalshi Archiv KXCPI: HTTP " + str(code) + ", " + str(len(ms)) + " Märkte, Filter wirkt: "
             + str(all(str(x.get("ticker", "")).startswith("KXCPI-") for x in ms)) + ", ältester Schluss "
             + (_uhr(min(iso_ts(x.get("close_time")) or jetzt for x in ms)) if ms else "–"))
    for alt in ("CPI", "FED", "U3"):
        code, d = ab.holen("kalshi", "/markets", {"series_ticker": alt, "limit": 3})
        n = len((d or {}).get("markets") or []) if isinstance(d, dict) else 0
        z.append("Kalshi Altname " + alt + ": HTTP " + str(code) + ", " + str(n) + " Märkte")
    code, d = ab.holen("pm_web", "/api/geoblock")
    z.append("Polymarket Geoblock: HTTP " + str(code) + " " + kurz(geoblock_kurz(d), 300))   # U236: ohne IP-Adresse
    for k in pm_aufab_kandidaten(jetzt)[:3] + [x for x in pm_aufab_kandidaten(jetzt) if x["familie"] in ("4h", "1h", "tag")][:8] \
            + pm_leiter_kandidaten(jetzt)[:4]:
        c1, d1 = ab.holen("pm_gamma", "/events/slug/" + k["slug"])
        c2, d2 = ab.holen("pm_gamma", "/events/slug/" + k["slug"], {"version": "v2"})
        n1 = len((d1 or {}).get("markets") or []) if isinstance(d1, dict) else 0
        n2 = len((d2 or {}).get("markets") or []) if isinstance(d2, dict) else 0
        z.append("Polymarket " + k["slug"] + ": ohne version HTTP " + str(c1) + " (" + str(n1) + " Märkte), v2 HTTP " + str(c2)
                 + " (" + str(n2) + ")")
        if n1 and "pm_beispiel" not in roh:
            roh["pm_beispiel"] = d1["markets"][0]
    if roh.get("pm_beispiel"):
        gm = gamma_markt(roh["pm_beispiel"])
        c1, b1 = ab.holen("pm_clob", "/book", {"token_id": gm["kennung_ja"]})
        c2, h2 = ab.holen("pm_clob", "/prices-history", {"market": gm["kennung_ja"], "startTs": jetzt - 7200, "endTs": jetzt,
                                                         "fidelity": 1})
        c3, h3 = ab.holen("pm_data", "/v2/prices-history", {"token_id": gm["kennung_ja"], "start": jetzt - 86400, "end": jetzt,
                                                            "bucket_seconds": 300})
        c4, m4 = ab.holen("pm_clob", "/midpoint", {"token_id": gm["kennung_ja"]})
        z.append("Polymarket Buch HTTP " + str(c1) + " " + str(pm_buch(b1) if c1 == 200 else "") + "; Verlauf 1 min HTTP "
                 + str(c2) + " (" + str(len(pm_verlauf(h2)) if c2 == 200 else 0) + " Punkte); Data v2 HTTP " + str(c3) + " ("
                 + str(len(pm_verlauf(h3)) if c3 == 200 else 0) + "); Mitte HTTP " + str(c4) + " " + kurz(m4, 100)
                 + " (p im Verlauf gegen Mitte vergleichen)")
    code, d = ab.holen("pm_data", "/v2/status")
    z.append("Polymarket Data v2 Status: HTTP " + str(code) + " " + kurz(d, 200))
    def hl(body, art):
        """Hyperliquid mit eigenem Deckel (Nachtrag 13.2): bei fehlendem Gewicht bis zu zweimal 31 s warten."""
        for _ in range(3):
            c, dd = ab.holen("hl", body=body, hl_art=art)
            if c != -2:
                return c, dd
            time.sleep(31)
        return c, dd
    code, d = hl({"type": "outcomeMeta"}, "outcomeMeta")
    aus = hip4_ausgaenge(d) if code == 200 else []
    z.append("HIP-4 outcomeMeta: HTTP " + str(code) + ", " + str(len(aus)) + " Ausgänge " + kurz([o.get("beschreibung") for o in aus[:3]], 400))
    if aus:
        c1, b1 = hl({"type": "l2Book", "coin": aus[0]["markt"]}, "l2Book")
        c2, k2 = hl({"type": "candleSnapshot", "req": {"coin": aus[0]["markt"], "interval": "1h", "startTime": (jetzt - 86400) * 1000,
                                                       "endTime": jetzt * 1000}}, "candleSnapshot")
        z.append("HIP-4 Buch HTTP " + str(c1) + " " + str(hl_buch_mitte(b1) if c1 == 200 else "") + "; candleSnapshot mit # HTTP "
                 + str(c2) + " (" + (str(len(k2)) if isinstance(k2, list) else "–") + " Kerzen)")
    for coin, (q, sym) in list(SPOT_QUELLE.items()) + [("BTC (Echo)", ECHO_QUELLE)]:
        code, kk, _ = _spot_abruf(ab, q, sym, jetzt - 600, jetzt - 60)
        z.append("Spot " + coin + " (" + q + " " + sym + "): HTTP " + str(code) + ", " + str(len(kk)) + " Kerzen")
    code, kk, _ = _spot_abruf(ab, "coinbase", "BTC-USD", utc_ts(datetime(2023, 1, 2, tzinfo=UTC)),
                              utc_ts(datetime(2023, 1, 2, 1, 0, tzinfo=UTC)))
    z.append("Coinbase BTC-USD Januar 2023: HTTP " + str(code) + ", " + str(len(kk)) + " Kerzen (Abdeckung der Spotquelle)")
    for reihe in ("KXBTCD", "KXCPI"):
        code, d = ab.holen("kalshi", "/markets", {"series_ticker": reihe, "status": "settled", "limit": 5})
        for x in ((d or {}).get("markets") or [])[:2] if isinstance(d, dict) else []:
            mm = kalshi_markt(x)
            z.append("Kalshi " + reihe + " abgerechnet: " + str(mm["markt"]) + ", Schluss " + (et(mm["ende"]).strftime("%d.%m.%Y %H:%M ET")
                     if mm["ende"] else "–") + ", gelistet " + (_de((mm["ende"] - mm["beginn"]) / 3600.0, 1) + " h vorher"
                                                                if mm["ende"] and mm["beginn"] else "–")
                     + ", strike_type " + str(mm["strike_typ"]) + ", expiration_value " + str(x.get("expiration_value")))
    code, d = ab.holen("binance_perp", "", {"symbol": "BTCUSDT", "interval": "30m", "startTime": 1623760200000, "limit": 1})
    z.append("Binance Perp 30 min Juni 2021: HTTP " + str(code) + " " + kurz(d, 120))
    with schreiben(con):
        meta_setzen(con, "erstlauf", {"ts": jetzt, "text": z, "roh": {k: kurz(v, 3000) for k, v in roh.items()}})
        ab.log_schreiben(con)
    return "\n".join(z)


def pfad(db: str) -> str:
    """prognosemarkt.db liegt neben der Hauptdatenbank (wie makro.db); HL_PM_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_PM_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "prognosemarkt.db")


def lesen(p: str):
    """Nur-Lese-Verbindung für Anzeige und Berichte; None, wenn die Datei fehlt."""
    if not p or not os.path.exists(p):
        return None
    con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=10,
                          check_same_thread=False)
    con.execute("PRAGMA busy_timeout=10000")
    return con


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, dict):
        return {k: _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_ohne_nan(v) for v in x]
    return x


def payload_json(p: str, tab: str = "ueberblick", jetzt: int | None = None) -> bytes:
    """/prognosemarkt?tab=…: Nutzlast als JSON; bei jedem Fehler eine Antwort mit Grund (nie eine leere Seite)."""
    try:
        con = lesen(p)
        if con is None:
            return json.dumps({"ok": False, "tab": tab, "fehlt": ["prognosemarkt.db fehlt noch – der Takt legt sie rund 60 s nach dem "
                                                                    "Start des Dashboards an (aus mit HL_PM=0)."]},
                              ensure_ascii=False).encode()
        try:
            d = nutzlast(con, jetzt, tab)
        finally:
            con.close()
        return json.dumps(_ohne_nan(d), ensure_ascii=False, allow_nan=False).encode()
    except Exception as e:  # noqa: BLE001 — die Seite bekommt immer eine Antwort
        return json.dumps({"ok": False, "tab": tab, "fehlt": [("Prognosemärkte: " + type(e).__name__ + ": " + str(e))[:300]]},
                          ensure_ascii=False).encode()


_TAKT = {"gestartet": False, "stop": None}


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen (Nachtrag R2, Konzept 4). Nicht für Selbsttest-Datenbanken; aus mit HL_PM=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_PM") == "0":
        return False
    _TAKT["gestartet"] = True
    _TAKT["stop"] = threading.Event()
    starte(pfad(db), stop=_TAKT["stop"])
    return True


def starte(db_pfad: str, hl_gewicht=None, stop: threading.Event | None = None, verzoegerung: float = 60.0):
    """Eigener Thread „prognosemarkt“ im Dashboard-Prozess. Nach 60 s: beim ersten Start der Erstlauf (setzt den Stichtag), dann je
    Runde der Takt, danach Rückblick-Schritte bis 10 s; Zustand der Quellen jede Minute in pm_meta; Auswertung einmal am Tag."""
    if os.environ.get("HL_PM", "1") == "0" or not db_pfad or db_pfad == ":memory:":
        return None
    stop = stop or threading.Event()

    def lauf():
        if stop.wait(verzoegerung):
            return
        try:
            con = verbinden(db_pfad)
        except Exception as e:  # noqa: BLE001 — z. B. Laufwerk nicht eingehängt: melden, nicht still sterben
            print("Prognosemärkte: " + db_pfad + " nicht nutzbar: " + type(e).__name__ + ": " + str(e)[:200], flush=True)
            return
        ab = Abrufer(hl_gewicht=hl_gewicht)
        if not meta(con, "erstlauf"):
            try:
                erstlauf(con, ab)
            except Exception as e:  # noqa: BLE001
                with schreiben(con):
                    meta_setzen(con, "fehler_erstlauf", {"ts": int(time.time()), "fehler": (type(e).__name__ + ": " + str(e))[:300]})
        try:
            erstlauf_ohne_ip(con)      # U236: Erstlauf aus 23.88 enthielt die IP-Adresse des Anschlusses
        except Exception:  # noqa: BLE001 — nur Aufräumen, der Dienst läuft weiter
            pass
        takt = Takt(con, ab)
        rb = Rueckblick(con, ab)
        while not stop.is_set():
            try:
                runde(con, ab, takt, rb, stop)
            except Exception as e:  # noqa: BLE001 — der Dienst läuft weiter (z. B. Datenbank kurz gesperrt); Grund in pm_meta
                try:
                    with schreiben(con):
                        meta_setzen(con, "fehler_dienst", {"ts": int(time.time()), "fehler": (type(e).__name__ + ": " + str(e))[:300]})
                except Exception:  # noqa: BLE001
                    print("Prognosemärkte: " + type(e).__name__ + ": " + str(e)[:200], flush=True)
                stop.wait(60)

    zustand_ = {"letzte_auswertung": time.time() - 86400 + 3600 + verzoegerung,   # erste Auswertung 1 h nach dem Start des Takts
                "letzter_zustand": 0.0}

    def runde(con, ab, takt, rb, stop):
        takt.schritt()
        ende = time.time() + 10
        while time.time() < ende and not stop.is_set():
            if not rb.schritt():
                break
        with schreiben(con):
            ab.log_schreiben(con)
            if time.time() - zustand_["letzter_zustand"] >= 60:
                zustand_["letzter_zustand"] = time.time()
                meta_setzen(con, "abruf_zustand", {"ts": int(time.time()), "pausen": {q: int(t) for q, t in ab.pause_bis.items()
                                                                                      if t > time.time()},
                                                   "zaehler": {q + ":" + k: n for (q, k), n in ab.zaehler.items()}})
        if time.time() - zustand_["letzte_auswertung"] > 86400:
            zustand_["letzte_auswertung"] = time.time()
            try:
                auswerten(con)
            except Exception as e:  # noqa: BLE001
                with schreiben(con):
                    meta_setzen(con, "fehler_auswertung", {"ts": int(time.time()), "fehler": (type(e).__name__ + ": " + str(e))[:300]})
        stop.wait(max(1.0, ende - time.time()))
    t = threading.Thread(target=lauf, name="prognosemarkt", daemon=True)
    t.start()
    return t


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Prognosemärkte (U235): Kalshi, Polymarket, HIP-4 – nur lesen")
    ap.add_argument("--db", default=None, help="Hauptdatenbank (hl_liq.db); prognosemarkt.db liegt daneben")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--mutationen", action="store_true")
    ap.add_argument("--erstlauf", action="store_true", help="Formatprüfung erneut (setzt den Stichtag nur, wenn er fehlt)")
    ap.add_argument("--stand", action="store_true")
    ap.add_argument("--auswertung", action="store_true", help="Zählung bzw. das gemeinsame Urteil, sobald freigegeben")
    ap.add_argument("--rueckblick", type=int, default=0, metavar="SCHRITTE")
    ap.add_argument("--takt", type=int, default=0, metavar="SEKUNDEN")
    ap.add_argument("--nutzlast", default=None, metavar="TAB")
    a = ap.parse_args(argv)
    if a.selbsttest:
        t0 = time.time()
        erg = selbsttest()
        rot = [n for n, ok, _ in erg if not ok]
        print(("Selbsttest bestanden: " if not rot else "Selbsttest ROT: ") + str(len(erg) - len(rot)) + " von " + str(len(erg))
              + " (" + _de(time.time() - t0, 0) + " s)")
        return 1 if rot else 0
    if a.mutationen:
        aus = mutationen_pruefen()
        for m, rot, welche in aus:
            print(("rot    " if rot else "NICHT ROT ") + m + (" — " + ", ".join(welche[:4]) if welche else ""))
        print(str(sum(1 for _, r, _ in aus if r)) + " von " + str(len(aus)) + " Mutationen rot")
        return 0 if all(r for _, r, _ in aus) else 1
    if not a.db:
        ap.error("--db fehlt (Pfad der Hauptdatenbank)")
    p = pfad(a.db)
    if a.nutzlast:
        print(payload_json(p, a.nutzlast).decode())
        return 0
    con = verbinden(p)
    if a.erstlauf:
        print(erstlauf(con))
    if a.rueckblick:
        rb = Rueckblick(con, Abrufer())
        for _ in range(a.rueckblick):
            if not rb.schritt():
                break
        with schreiben(con):
            rb.ab.log_schreiben(con)
        print(bericht_stand(con, rb))
    if a.takt:
        ab = Abrufer()
        takt = Takt(con, ab)
        ende = time.time() + a.takt
        while time.time() < ende:
            print(_uhr(time.time()) + " " + ", ".join(takt.schritt()))
            time.sleep(5)
    if a.auswertung:
        auswerten(con)
        print(bericht_auswertung(con))
    if a.stand:
        print(bericht_stand(con, Rueckblick(con, None)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
