# UPDATE-PLAN — Hyperliquid-Analysesystem (lebendes Dokument)

**Zweck:** Ein Ort für alles Offene. Wird zu Beginn jeder Sitzung gelesen und am Ende aktualisiert.
Nichts wird nur im Chat vereinbart — was nicht hier steht, existiert nicht.
**Stand:** 23.09.2026, 10:00, nach Version 2026-09-23.8 (Pi laut Nutzer: 23.6; 23.7/23.8 bereit) · **Pi-Stand laut Nutzer:** 22.19 (Abschnitt A am 23.09. 02:43 bestanden: Quellen grün, keine Fehler, LB 82 s/17,5 s, 15 Gesperrte, Fills-Stream 668 Konten).

## Regeln für dieses Dokument

1. **Sitzungsbeginn:** Abschnitt A (Prüfungen) abarbeiten, dann Abschnitt B (Reihenfolge) — der oberste
   offene Punkt ist der nächste. Abweichungen nur mit Grund in der Spalte „Notiz".
2. **Sitzungsende:** Status jedes angefassten Punkts setzen (`offen` → `in Arbeit` → `erledigt vX` oder
   `verworfen: Grund`), neue Punkte anhängen, Version und Datum oben aktualisieren, Datei ins Paket.
3. **Jeder Punkt hat ein Abnahmekriterium.** Ohne Kriterium kein „erledigt".
4. **Paketname ist immer `hl_liq_project.zip`** (Update-System des Pi verlangt ihn); Version und Prüfsumme stehen in `version.py` und in der Antwort.
5. Prioritäten: **P0** Datenbasis/Korrektheit · **P1** Messung/Kalibrierung · **P2** Kontenstatistik ·
   **P3** Betrieb/Sicherheit · **P4** Verbesserungen · **W** wiederkehrend.

---

## A. Prüfungen zu Sitzungsbeginn (jedes Mal)

| # | Prüfung | Wie | Soll |
|---|---|---|---|
| A1 | Version auf dem Pi = geliefertes Paket | Systemkachel „Version" | Version · Prüfsumme identisch |
| A2 | Keine Fehler im Zeitplan | Netzwerkstatus, Zeile „Keine Aufgabe hat einen Fehler gemeldet" | grün |
| A3 | Budget und Takte | Ratengrenze ~90 % des Deckels, Leaderboard-Stände ≤ 2 min, Fills ≤ 15 min, Poller-Pool-Anteil | im Rahmen |
| A4 | Selbsttest auf dem Pi (nach jedem Update) | Debug „Rundum-Funktionstest" | 20/20 |
| A5 | Nulltest inkl. Positivkontrolle | `hl_forecast.py --nulltest` | Nulltest grün; Positivkontrolle: Stand notieren (bis K2-Neubau „NICHT LERNFÄHIG") |
| A6 | Neue Sperren | Debug „Masterregel Sperre" | Liste plausibel (Maschinen), keine echten Trader |

---

## B. Reihenfolge der offenen Arbeiten

### Nächste Sitzung (23.09., morgens)

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U1 | P0 | **Probe P2 (K1)**: `SELECT method, COUNT(*), COUNT(DISTINCT user) FROM liquidations WHERE ts > strftime('%s','now')-86400 GROUP BY method` | 24 h nach 22.18 | beobachtete Zeilen von ≤ 10 Konten; abgeleitete Zeilen > 0 | offen | Beleg, dass K1 wirkt |
| U2 | P0 | **Probe P1 (H2)**: Coinbase-Seite live prüfen (Skript im Audit v10, Abschnitt 9) | Netz des Pi, 5 min | Ergebnis notieren; bei Widerspruch zur Maker-Annahme: Vorzeichen prüfen | offen | matches-Kanal ist seit 22.18 aktiv |
| U3 | P2 | **Aktive Profis, Phase 2 (Bewertung)** — ERLEDIGT v23.1: `hl_profis.py` (Bündelung aus pool_fills_hourly, Gewinn 7 T = HL pnl_7d, Exit-/Entry-Lift mit Placebo 200 und n_eff über 12-h-Blöcke, Bot ≤ 4 h Lücke, Reaktionszeit, bester Coin), Nulltest+Positivtest als Selbsttest-Schritt 21, `check_profis.py` — `hl_profis.py`: gebündelte Trades/Tag (5 ≤ n ≤ 150), Gewinn 7 T > 0, Exit-Lift und Entry-Lift (2 %/12 h, Placebo 200 Ziehungen, n_eff über 12-h-Blöcke, t ≥ 1), Reaktionszeit, bester Coin, Bot-Marke (längster Trade-Abstand ≤ 4 h über 7 T), ROI 12 h (einzahlungsbereinigt), Nulltest Exit-Lift | 24 h Stream-Fills seit 22.7 (**Debug „★ Aktive Profis: Pool zählen" zuerst laufen lassen** — Block 2b zeigt die echte Trades/Tag-Verteilung) | Nulltest Exit-Lift ≈ 0 auf Rauschen, positiv mit Kante; Bündelungsprobe; Bot-Probe | erledigt v23.1 | Konzept §5–7. **Befund 22.09. 20:48 (23 h Daten):** 669 im Pool (472 aktuell erfüllt + Hysterese), 241 mit Fills in unseren Coins, **124 mit 5–150 Trades/Tag** (Median 7), 19 über 150, 428 ohne Fills = handeln andere Coins (Stream nur für die 6 verfolgten Coins abonniert) → Aktivität ist DEFINIERT als Trades/Tag auf den verfolgten Coins. Gesperrte aus der Bewertung ausschließen (stehen mit alten Stundenzeilen noch in „über der Grenze"). Sperrliste 22:49: 11 Maschinen (2.020–15.036 Fills/Tag), keine echten Trader. |
| U4 | P2 | **Aktive Profis, Phase 3 (Dashboard)** — ERLEDIGT v23.1: Abschnitt 10 zeigt Karten der Qualifizierten (Rang eingefroren alle 12 h, Kennzahlen stündlich, letzte 5 Trades gebündelt, [bot trader], HypurrScan), Pool-Tabelle darunter — Abschnitt 10 wird die Liste der 20 Qualifizierten mit Karten: Rang nach ROI 12 h (Stempel 00/12 UTC), letzte 5 Trades (Zeit, Coin, Perp/Spot, long/short, open/close/reduce, Betrag, Kurs, closedPnl, „seither"), [bot trader], HypurrScan-Link; Vorschau-Tabelle bleibt als Reiter „Pool" | U3 | 20 Karten rendern, Trades live, Rangstempel sichtbar | erledigt v23.1 (Browser-Probe: Karte + 5 Trades) | Töne bei Trades der 20: später (U14) |
| U3b | P2 | Profis: nach zwei Wochen Pool-Beobachtung auf die strenge Qualifikation umstellen (Exit- UND Entry-Lift > 0 mit t ≥ 1); bis dahin Variante 2 (Entry-Lift darf nicht signifikant negativ sein, t ≤ −1 schließt aus) | 14 Tage ab 22.09. | Entscheidung Nutzer nach Blick auf die Entry-Lifts der Qualifizierten | offen | v23.2 |
| U5 | P2 | REST-Nachtrag closedPnl für den Pool alle 12 h — ERLEDIGT v23.3: Task `Pool-Fills` (Pool minus Auswahl minus Gesperrte, Rang 3, Budget min(15.000, 30 je Konto), Vielhandler-/Sperrregel wie Leaderboard-Fills, Cursor lb_cursor); `hl_profis.roi_12h` = Summe closedPnl 12 h plus Delta uPnL, relativ zum Kontowert; Rang nach eigener 12-h-ROI, Konten ohne Nachtrag nach HL roi_1d (`rang_quelle` je Konto, `rang_basis` in der Kopfzeile) (Rang 3, Vielhandler-Regel, Gesperrte nie) | U3 | Kosten unter 15.000 Gewicht je 12 h, Zeile Pool-Fills im Zeitplan | erledigt v23.3 (Probe: pnl_12h 40.000 = 4 mal 5.000 plus 20.000, ROI 2 %) | erster Lauf 10 min nach dem Neustart, dann alle 12 h |

### Danach (P1 — Messung)

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U6 | P1 | **Konzept K2-Neubau** — ERLEDIGT v23.4 als Modul-Doku in `hl_kalib.py` und README (Nutzer: setz es alles um): L2-Logit auf standardisierten Treibern, ohne Nenner 19,4 und ohne β, Achsenabschnitt; λ per geblockter Kreuzvalidierung mit Lücke/Embargo; MAX_TRAIN nach Zeit (90 T) mit Vektorisierung; Toleranz-Labels/Enthaltung (M7); eine Prognose je Fenster (M10); Zielgröße sign(p_up − 0,5) (H6); Scores auf [−1;1] ohne Prior-Vorfaktor (H7); Zuverlässigkeitsdiagramm | — | Doku im Modul | erledigt v23.4 | Prüfung durch Audit weiter sinnvoll |
| U7 | P1 | **K2-Neubau umsetzen** — ERLEDIGT v23.4 im SCHATTEN: `hl_kalib.py`, stündliche Kalibrierung je Coin/Horizont im Lernzyklus, `p_up_v2` in jeder Prognose, direkte Bilanz v1/v2 in score_forecasts, Kachel, Schalter (`kalib2_aktiv`), Debug-Einträge, Selbsttest-Schritt 22 | Snapshot forecasts.db vor dem Umschalten | **Positivkontrolle im Nulltest wird Tor:** Kante 0,65 → p_up 0,60–0,70, Kante 0,50 → Gewicht ≈ 0; Nulltest grün; Zuverlässigkeitsdiagramm ±KI; Laufzeit auf dem Pi < 60 s je Coin | erledigt v23.4 (Schatten); Tor bestanden: 63,4 % / Rauschen 0,6 Punkte | Umschalten = U7b |
| U7b | P1 | **v2 aktivieren** (Debug Kalibrierung v2 AKTIVIEREN; Spalte Gew. v2 in der Treibertabelle seit v23.6), wenn die direkte Bilanz v2 >= v1 (Quote und Brier-Skill, n >= 100 4-h-Faelle) und die Zuverlaessigkeit stimmt (vorhergesagt ~ eingetreten in den besetzten Zehnteln) | 1-2 Wochen Schatten ab 23.09. | Kachel Kalibrierung v2 zeigt v2 >= v1 | offen | Rueckfall: Debug zurueck in den Schatten |
| U25 | P1 | **Konstellationen und Vorbedingungen** — Stufe 1 ERLEDIGT v23.7: `hl_konstellation.py` (Paare der 15 gewichtigsten Treiber: bedingte 4-h-Quote bei gemeinsamem Ausschlag |Score| >= 0,3 mit Wilson, Basis, Lift, z, Auswahl-Effekt ausgewiesen; Vorbedingungen: Treiberprofile vor Bewegungen >= 3 % binnen 24 h, Ereignisse zusammengefasst, Basis = alle Bloecke), stuendlich im Lernzyklus, Anzeige unter der Elite-Tabelle, Nulltest = Selbsttest-Schritt 23; taegliche Historie `konstellation_hist` und `stabil()` (z >= 2 an >= 14 Tagen) als Kandidatenliste fuer Stufe 2 (v23.8). **Stufe 2 offen:** Interaktionsterme x*y in v2 fuer Paare, die ueber Wochen z >= 2 halten (mit L2 und Kreuzvalidierung) | 90 Tage Daten fuer Paare | Stufe 1: Nulltest gruen; Stufe 2: Positivkontrolle mit konstruierter Interaktion | Stufe 1 erledigt, Stufe 2 offen | Nutzerfrage 23.09. |
| U8 | P1 | **H10 Bilanz der Kauf-/Verkaufsempfehlungen**: Füllung 4–12 h, Rendite 4/12/24 h, Vergleich Markt/nie, Gebühren (Maker/Taker), advised ja/nein | — | Kachel mit n, Quote, Netto nach Kosten | offen | wirtschaftlich wichtigster Punkt (Audit §8) |
| U9 | P1 | H11 Magnet-Pfad nur bei z ≥ 2 des Lifts; Placebo driftbereinigt in magnet_stats | — | Nulltest Magnet grün | offen | |

### P2 — Kontenstatistik

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U10 | P2 | H8 Rest: Benjamini-Hochberg über alle Konten, Aufnahme in die Elite erst nach OOS-Bestätigung (Folgewoche Vorlauf > 0, n ≥ 5), `score_test` als Freigabe des Treibers | — | Nullsimulation: Fehlalarme ≤ nominal | offen | Block-t seit 22.18 |
| U11 | P2 | M3 Hedge-Regel: nur Short-Korb oder nachweisbare Gegenposition | — | Harness-Szenario | offen | |
| U12 | P2 | M8: Pool-Deckel nach Aktivität statt pnl_7d; Folge-PnL roh nach Gebühren ausweisen | U3 | Anzeige | offen | |
| U13 | P2 | Elite des Treibers auf die Profis-Liste umstellen | U3/U4, 4 Wochen Beobachtung | Entscheidung Nutzer | offen | |
| U14 | P4 | Töne/Signale bei Trades der 20 Profis | U4 | Browser-Probe | offen | |
| U15 | P2 | Klasse „Market-Maker" auch aus Aktivität ableiten (wirkt in Wale/Smart Money) | U3 | Harness | offen | Vorschlag vom 22.09. |
| U16 | P2 | Pool-Hysterese Etappe 2: 7 → 30 Tage (`POOL_HYSTERESE_TAGE`) | 4 Wochen Betrieb | Entscheidung Nutzer | offen | |

### P3 — Betrieb und Sicherheit

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U17 | P3 | S2 Paket-Signatur/Prüfsumme vor dem Entpacken in update.py (Prüfsumme aus version.py gesondert veröffentlichen) | — | Update mit falscher Prüfsumme wird abgelehnt | offen | |
| U18 | P3 | S3 sudoers NOPASSWD nur für die systemctl-Befehle, sudo.txt entfernen | Nutzer (Root) | Restore/Update ohne Passwortdatei | offen | Betriebsentscheidung |
| U19 | P3 | S1 Token für POST-Routen (zusätzlich zur Host-Allowlist) | — | POST ohne Token abgelehnt | offen | optional |
| U20 | P3 | M11 Rest: stille `except: pass` zählen und in /system zeigen | — | Zähler sichtbar | offen | store_forecast seit 22.18 |
| U21 | P3 | M13: Backup-Generationen auf ein zweites Gerät | Nutzer (Ziel) | backup.json zeigt Ziel | offen | |
| U22 | P3 | H13: Bybit als Referenz für Liquidations-Intensitäten, Binance nur Zählsignal, OKX-Kappungen zählen | — | Harness | offen | |
| U23 | P3 | M5 Funding-Intervalle je Kontrakt (Binance fundingInfo, Bybit instruments-info, OKX fundingTime) | Probe P7 | Spread korrekt auf 8 h normiert | offen | |
| U24 | P4 | N3, N4, N6, N9, N10, M12 (Eröffnungszeitpunkt aus Stream-Fills) | — | je Punkt | offen | Sammelposten |

### W — Wiederkehrend

| ID | Takt | Punkt | Werkzeug |
|---|---|---|---|
| W1 | wöchentlich | Elite prüfen (Beleg, Gewinn-/Aktivitätsschranke, WEICHT AB) | Debug „Elite-Positionierung prüfen" |
| W2 | wöchentlich | Pool zählen, Trades/Tag-Verteilung, Sperren | Debug „Aktive Profis: Pool zählen", „Masterregel Sperre" |
| W3 | wöchentlich | Treiber-Bilanz: Lift/z je Treiber, OOS-Spalte ab 25 Blöcken | Treibertabelle |
| W4 | nach 8–12 Wochen | Kalibrierung auf forecast_drivers (72/168 h) — nach U7 neu bewerten | — |
| W5 | nach 8 Wochen | Goldene Regel prüfen: ρ(Vorlauf), ρ(Größe) > 2 SE im Wochenmittel (Audit §8.3) | score_test |
| W6 | monatlich | Lint (pyflakes offline nicht verfügbar: eigene Namensprüfung), 170 stille excepts abbauen | — |

---

## C. Erledigt (Kurzliste, Details in UEBERGABE)

22.09.: Audit v10 P0 (K1, H1, H2-Kanal, H3, H4, H5, H8-Block-t, H9, H12, M1, M2, M6, M9, M11-Teil, M12, M13, N1, N2, N5, N7, N8, S1, S4) · Masterregel Sperre · Aktivitätsschranke Elite · Aktive Profis Phase 0/1 + Vorschau · Treiber-Signale (Pfeile/Blitze/Töne) · HypurrScan-Links · Gewinn-Schranke · Lift-Bilanz · weights_hist · Version/Prüfsumme · Begrenzer mit Rang und Reserve.
21.09.: Elite t_4h-Fehler · Look-ahead im Vorlauf · CPU (Ereignis-Auslöser, Varianz-Cache, Liquidationen in SQL) · Tabs · CPU je Dienst.

## D. Verworfen

- Proposal Stufe 2/3 (Rev. 2) als Umsetzungsgrundlage — ersetzt durch den K2-Neubau (U6/U7); die Familien-Idee (Stufe 3) geht im Neubau als gemeinsame Schätzung auf.
- Nenner je Fall (Stufe 1, Rev. 1) — Audit v9.
