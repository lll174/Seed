# UPDATE-PLAN — Hyperliquid-Analysesystem (lebendes Dokument)

**Zweck:** Ein Ort für alles Offene. Wird zu Beginn jeder Sitzung gelesen und am Ende aktualisiert.
Nichts wird nur im Chat vereinbart — was nicht hier steht, existiert nicht.
**Stand:** 23.09.2026, 14:50, Version 2026-09-23.15 (Dokumente nachgetragen: U41 und U37 auf dem Pi bestätigt, U40 zur Hälfte). **Einstieg für neue Sitzungen: PROJEKTUEBERGABE_OPUS55_23-09-2026.md** · **Pi-Stand laut Nutzer:** 23.15 (seit 23.09., 14:13).

## Regeln für dieses Dokument

1. **Sitzungsbeginn:** Abschnitt A (Prüfungen) abarbeiten, dann Abschnitt B (Reihenfolge) — der oberste
   offene Punkt ist der nächste. Abweichungen nur mit Grund in der Spalte „Notiz".
2. **Sitzungsende:** Status jedes angefassten Punkts setzen (`offen` → `in Arbeit` → `erledigt vX` oder
   `verworfen: Grund`), neue Punkte anhängen, Version und Datum oben aktualisieren, Datei ins Paket.
3. **Jeder Punkt hat ein Abnahmekriterium.** Ohne Kriterium kein „erledigt".
4. **Paketname ist immer `hl_liq_project.zip`** (Update-System des Pi verlangt ihn); Version und Prüfsumme stehen in `version.py` und in der Antwort.
5. Prioritäten: **P0** Datenbasis/Korrektheit · **P1** Messung/Kalibrierung · **P2** Kontenstatistik ·
   **P3** Betrieb/Sicherheit · **P4** Verbesserungen · **W** wiederkehrend.

---

## A. Prüfungen zu Sitzungsbeginn (jedes Mal)

| # | Prüfung | Wie | Soll |
|---|---|---|---|
| A1 | Version auf dem Pi = geliefertes Paket | Systemkachel „Version" | Version · Prüfsumme identisch (seit 23.11 umfasst die Prüfsumme auch alle Werkzeuge check_*, db_size, make_treiber_pdf*) |
| A2 | Keine Fehler im Zeitplan | Netzwerkstatus, Zeile „Keine Aufgabe hat einen Fehler gemeldet" | grün |
| A3 | Budget und Takte | Ratengrenze ~90 % des Deckels, Leaderboard-Stände ≤ 2 min, Fills ≤ 15 min, Poller-Pool-Anteil | im Rahmen |
| A4 | Quellen nach jedem Update | Debug „★ Rundum-Funktionstest aller Quellen" (check_sources, ~3 min) | in jeder Quelle „FEHL 0"; Hinweise sind normal (nicht gelistete Coins, ruhige Streams). Hinweis: Das ist NICHT der 23-Schritte-Selbsttest (der hat keinen Debug-Eintrag, siehe A7/U30) |
| A5 | Nulltest inkl. Positivkontrolle | Debug „Nulltest der Statistik" und „Kalibrierung v2 (K2-Neubau): Positivkontrolle/Nulltest v2" | Nulltest grün; v1: „NICHT LERNFÄHIG" (bis U7b erwartet); v2: „Tor: BESTANDEN" (Kante 0,65 → p 0,60–0,70) |
| A6 | Neue Sperren | Debug „Masterregel Sperre" | Liste plausibel (Maschinen), keine echten Trader |
| A7 | Selbsttest vor jeder Lieferung (Sandbox, durch Claude) | `python3 install.py --selftest`, Nulltests v1/v2, `node --check`, Namensprüfung (symtable/AST) | 23/23, Nulltests grün, JS ok, keine undefinierten Namen |


**Letzter Lauf Abschnitt A — 23.09. (Opus 5.5):** Sandbox (A7) auf 23.11: Selbsttest 23/23, Nulltests grün, JS ok,
Namensprüfung fand U28 (behoben 23.11). **Pi 12:16–12:25 auf 23.11:**

| # | Ergebnis |
|---|---|
| A1 | ✓ 2026-09-23.11 · 6d711de558 |
| A2 | ✓ keine Aufgabe mit Fehler. Aber: Schreibsperre beim Recorder-Start 48,9 s gehalten („INSERT OR IGNORE INTO addresses …“, Binance 1 Frist überschritten) → U32, behoben 23.12 |
| A3 | ✓ 1.082/min = 100 % des Deckels, 0 × 429; Leaderboard 120 s (17,2 s); Poller 23/23; Pool-Anteil 10,4 %. REST-Nachtrag Median 17 min (schlechtestes 0,5 h), 10 min nach dem Neustart: knapp über 15 min, beim nächsten A erneut |
| A4 | ✓ FEHL 0 in allen 13 Quellen (Hinweise: Bybit-Stream ruhig; XMR/PAXG bei OKX, ZEC/XMR bei Crypto.com nicht gelistet). Lücke: Coinbase wurde am ticker geprüft, der Dienst liest seit 22.18 matches, und die Seiten-Angabe war eine feste Ausgabe → 23.12 prüft matches und misst die Seite (U2) |
| A5 | ✓ Nulltest bestanden; v1 NICHT LERNFÄHIG (0,65 → 50,6 %); v2 Tor BESTANDEN (0,65 → 63,7 %, Rauschen +1,1 Punkte) |
| A6 | ⚠ 30 gesperrt, 19 davon neu seit 23.09. 02:02 (nach 22.18), fast alle knapp über der Grenze (2.007–2.492); darunter HLP Strategy A/B (Protokoll-Vaults, zu Recht). Ob echte Trader dabei sind, zeigt der Beleg je Sperre (check_sperre 1b, ab 23.12) → U31 |

**Nachlauf 13:25 (Pi auf 23.13):** P2 bestanden (0 beobachtete Konten, 35 abgeleitete Liquidationen von 33 Konten → U1 erledigt).
Längster Sperr-Halter 11,8 s statt 48,9 s (U32 wirkt), aber 76-mal über 1 s, stets „UPDATE addresses SET last_poll=?, notional=0 …“
→ U37. REST-Nachtrag der Auswahl Median 33 min (Soll ≤ 15), weil Pool-Fills nach jedem Neustart lief → U40. API in einer Minute
1.143 von 1.080 (106 % des Deckels, 0 × 429) → U38. VOLLBERICHT zeigte Lücken ab 01.01.1970 → U39. Crypto.com-Reihe
10 min ohne Zeile („Fluss unterbrochen?“) — beim nächsten A erneut ansehen.

**Nachlauf 14:47 (Pi auf 23.15, 34 min nach dem Start):** U37 bestätigt (Halter Ø 11 ms, 3-mal über 1 s, längster 4,2 s);
1.082/min = 100 % des Deckels, 0 × 429; 35 Gesperrte, keine neuen; Crypto.com-Reihe läuft wieder; keine Fehler. Beobachten: die
Orders-Runde dauert 305 s (12:16: 94 s, 13:25: 232 s) bei vollem Budget — gelb markiert, kein Fehler.

---

## B. Reihenfolge der offenen Arbeiten

### Nächste Sitzung (23.09., morgens)

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U1 | P0 | **Probe P2 (K1)**: Liquidationen 24 h nach Methode — im Debug „★ VOLLBERICHT“ (Zeile „Probe P2“) | 24 h nach 22.18 | beobachtete Konten ≤ 10; abgeleitete Zeilen > 0 | erledigt 23.09. 13:25: 0 beobachtete Konten, 35 abgeleitete Zeilen von 33 Konten | K1 wirkt: die Ableitung läuft für alle Konten |
| U2 | P0 | **Probe P1 (H2)**: Coinbase-Seite — als MESSUNG im Rundum-Funktionstest (A4): Tick-Regel auf matches und Vergleich ticker/matches je trade_id | Netz des Pi | A4-Zeile „Seite von side (Probe P1)“ = ok | erledigt 23.09. 13:56: matches.side = Maker-Seite (Tick-Regel 38 von 41, 93 %), Umkehr richtig; ticker.side = TAKER-Seite (0 von 99 gleich) → H2 bestätigt: bis zur Umstellung war der Spot-Taker-Flow vertauscht → U41 | läuft bei jedem A4 mit |
| U3 | P2 | **Aktive Profis, Phase 2 (Bewertung)** — ERLEDIGT v23.1: `hl_profis.py` (Bündelung aus pool_fills_hourly, Gewinn 7 T = HL pnl_7d, Exit-/Entry-Lift mit Placebo 200 und n_eff über 12-h-Blöcke, Bot ≤ 4 h Lücke, Reaktionszeit, bester Coin), Nulltest+Positivtest als Selbsttest-Schritt 21, `check_profis.py` — `hl_profis.py`: gebündelte Trades/Tag (5 ≤ n ≤ 150), Gewinn 7 T > 0, Exit-Lift und Entry-Lift (2 %/12 h, Placebo 200 Ziehungen, n_eff über 12-h-Blöcke, t ≥ 1), Reaktionszeit, bester Coin, Bot-Marke (längster Trade-Abstand ≤ 4 h über 7 T), ROI 12 h (einzahlungsbereinigt), Nulltest Exit-Lift | 24 h Stream-Fills seit 22.7 (**Debug „★ Aktive Profis: Pool zählen" zuerst laufen lassen** — Block 2b zeigt die echte Trades/Tag-Verteilung) | Nulltest Exit-Lift ≈ 0 auf Rauschen, positiv mit Kante; Bündelungsprobe; Bot-Probe | erledigt v23.1 | Konzept §5–7. **Befund 22.09. 20:48 (23 h Daten):** 669 im Pool (472 aktuell erfüllt + Hysterese), 241 mit Fills in unseren Coins, **124 mit 5–150 Trades/Tag** (Median 7), 19 über 150, 428 ohne Fills = handeln andere Coins (Stream nur für die 6 verfolgten Coins abonniert) → Aktivität ist DEFINIERT als Trades/Tag auf den verfolgten Coins. Gesperrte aus der Bewertung ausschließen (stehen mit alten Stundenzeilen noch in „über der Grenze"). Sperrliste 22:49: 11 Maschinen (2.020–15.036 Fills/Tag), keine echten Trader. |
| U4 | P2 | **Aktive Profis, Phase 3 (Dashboard)** — ERLEDIGT v23.1: Abschnitt 10 zeigt Karten der Qualifizierten (Rang eingefroren alle 12 h, Kennzahlen stündlich, letzte 5 Trades gebündelt, [bot trader], HypurrScan), Pool-Tabelle darunter — Abschnitt 10 wird die Liste der 20 Qualifizierten mit Karten: Rang nach ROI 12 h (Stempel 00/12 UTC), letzte 5 Trades (Zeit, Coin, Perp/Spot, long/short, open/close/reduce, Betrag, Kurs, closedPnl, „seither"), [bot trader], HypurrScan-Link; Vorschau-Tabelle bleibt als Reiter „Pool" | U3 | 20 Karten rendern, Trades live, Rangstempel sichtbar | erledigt v23.1 (Browser-Probe: Karte + 5 Trades) | Töne bei Trades der 20: später (U14) |
| U3b | P2 | Profis: nach zwei Wochen Pool-Beobachtung auf die strenge Qualifikation umstellen (Exit- UND Entry-Lift > 0 mit t ≥ 1); bis dahin Variante 2 (Entry-Lift darf nicht signifikant negativ sein, t ≤ −1 schließt aus) | 14 Tage ab 22.09. | Entscheidung Nutzer nach Blick auf die Entry-Lifts der Qualifizierten | offen | v23.2 |
| U5 | P2 | REST-Nachtrag closedPnl für den Pool alle 12 h — ERLEDIGT v23.3: Task `Pool-Fills` (Pool minus Auswahl minus Gesperrte, Rang 3, Budget min(15.000, 30 je Konto), Vielhandler-/Sperrregel wie Leaderboard-Fills, Cursor lb_cursor); `hl_profis.roi_12h` = Summe closedPnl 12 h plus Delta uPnL, relativ zum Kontowert; Rang nach eigener 12-h-ROI, Konten ohne Nachtrag nach HL roi_1d (`rang_quelle` je Konto, `rang_basis` in der Kopfzeile) (Rang 3, Vielhandler-Regel, Gesperrte nie) | U3 | Kosten unter 15.000 Gewicht je 12 h, Zeile Pool-Fills im Zeitplan | erledigt v23.3 (Probe: pnl_12h 40.000 = 4 mal 5.000 plus 20.000, ROI 2 %) | erster Lauf 10 min nach dem Neustart, dann alle 12 h |

### Danach (P1 — Messung)

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U6 | P1 | **Konzept K2-Neubau** — ERLEDIGT v23.4 als Modul-Doku in `hl_kalib.py` und README (Nutzer: setz es alles um): L2-Logit auf standardisierten Treibern, ohne Nenner 19,4 und ohne β, Achsenabschnitt; λ per geblockter Kreuzvalidierung mit Lücke/Embargo; MAX_TRAIN nach Zeit (90 T) mit Vektorisierung; Toleranz-Labels/Enthaltung (M7); eine Prognose je Fenster (M10); Zielgröße sign(p_up − 0,5) (H6); Scores auf [−1;1] ohne Prior-Vorfaktor (H7); Zuverlässigkeitsdiagramm | — | Doku im Modul | erledigt v23.4 | Prüfung durch Audit weiter sinnvoll |
| U7 | P1 | **K2-Neubau umsetzen** — ERLEDIGT v23.4 im SCHATTEN: `hl_kalib.py`, stündliche Kalibrierung je Coin/Horizont im Lernzyklus, `p_up_v2` in jeder Prognose, direkte Bilanz v1/v2 in score_forecasts, Kachel, Schalter (`kalib2_aktiv`), Debug-Einträge, Selbsttest-Schritt 22 | Snapshot forecasts.db vor dem Umschalten | **Positivkontrolle im Nulltest wird Tor:** Kante 0,65 → p_up 0,60–0,70, Kante 0,50 → Gewicht ≈ 0; Nulltest grün; Zuverlässigkeitsdiagramm ±KI; Laufzeit auf dem Pi < 60 s je Coin | erledigt v23.4 (Schatten); Tor bestanden: 63,4 % / Rauschen 0,6 Punkte | Umschalten = U7b |
| U7b | P1 | **v2 aktivieren** (Debug Kalibrierung v2 AKTIVIEREN; Spalte Gew. v2 in der Treibertabelle seit v23.6), wenn die direkte Bilanz v2 >= v1 (Quote und Brier-Skill, n >= 100 4-h-Faelle) und die Zuverlaessigkeit stimmt (vorhergesagt ~ eingetreten in den besetzten Zehnteln) | 1-2 Wochen Schatten ab 23.09. | Kachel Kalibrierung v2 zeigt v2 >= v1 | offen | Rueckfall: Debug zurueck in den Schatten |
| U29 | P1 | **OOF-Brier-Skill von v2 ist auf Rauschen negativ verzerrt** (12 Seeds: Mittel −0,034, 11 von 12 < 0; OOF-Quote dagegen unverzerrt, Mittel 51,0 %; die 38 % im Tor-Lauf sind Seed-Rauschen). Ursache: Referenz ist die Klimatologie der GESAMTEN Stichprobe, das OOF-Modell kennt sie nicht. Korrektur: Referenz = Achsenabschnitt-Modell mit denselben Folds (OOF-Klimatologie) | vor U7b | Nulltest: OOF-Brier-Skill auf Rauschen im Mittel ≈ 0 (|Mittel| < 0,01 über 12 Seeds) | offen | bis dahin: Werte bis etwa −0,05 in der v2-Kachel sind Rauschniveau |
| U25 | P1 | **Konstellationen und Vorbedingungen** — Stufe 1 ERLEDIGT v23.7: `hl_konstellation.py` (Paare der 15 gewichtigsten Treiber: bedingte 4-h-Quote bei gemeinsamem Ausschlag |Score| >= 0,3 mit Wilson, Basis, Lift, z, Auswahl-Effekt ausgewiesen; Vorbedingungen: Treiberprofile vor Bewegungen >= 3 % binnen 24 h, Ereignisse zusammengefasst, Basis = alle Bloecke), stuendlich im Lernzyklus, Anzeige unter der Elite-Tabelle, Nulltest = Selbsttest-Schritt 23; taegliche Historie `konstellation_hist` und `stabil()` (z >= 2 an >= 14 Tagen) als Kandidatenliste fuer Stufe 2 (v23.8). **Stufe 2 offen:** Interaktionsterme x*y in v2 fuer Paare, die ueber Wochen z >= 2 halten (mit L2 und Kreuzvalidierung) | 90 Tage Daten fuer Paare | Stufe 1: Nulltest gruen; Stufe 2: Positivkontrolle mit konstruierter Interaktion | Stufe 1 erledigt, Stufe 2 offen | Nutzerfrage 23.09. |
| U26 | P0 | **Leaderboard-Flow zeigte 11:20 0,00 Mio von 0 Konten in 60 min** (vorher nie), Gegen-Flow dadurch ohne Daten: Ausfall oder ruhige Stunde? Pruefen mit Debug Leaderboard pruefen und Abschnitt Leaderboard (Leaderboard-Flow live, Letzte Aenderungen) | Ausgaben vom Nutzer | Ereignisse in lb_events der letzten Stunde vorhanden und im Treiber sichtbar | geschlossen v23.10: kein Fehler (Leaderboard-Diagnose 11:35: 2 BTC-Aenderungen in 6 h, 1 Ereignis; nur 6 der Top-75 halten BTC) | ruhige Stunde |
| U28 | P0 | **NameError in `on_user_event`** (Namensprüfung 23.09.): `hashlib` im tid-Rückfall (N5) ohne Import. Wirkung: Liquidations-Fill ohne tid → NameError → WS-Neuaufbau, Liquidation verloren | — | Namensprüfung ohne Fund; Probe: Fill ohne tid wird gespeichert | erledigt v23.11 | selten (Fills tragen fast immer tid), aber jeder Fall reißt alle Feeds kurz ab |
| U31 | P0 | **Masterregel auf gebündelte Trades** — Entscheidung Nutzer 23.09.: Option (a), > 300 gebündelte Trades (je Coin, Minute, Richtung) in 24 h, dieselbe Einheit wie die Elite-Schranke. Zählung im Stream je Konto und Stunde (`fill_zaehler_h.n_trades`, Mengen statt Summen), dazu gespeicherte Fills aller Coins (lb_fills); es gilt das Maximum. Alte Fills-Sperren einmalig neu bewertet, sobald 24 volle Stunden Zählung vorliegen: ≤ 300 → Status „frei“ (Grund im Protokoll), darüber bleibt die Sperre | 25 h nach dem Einspielen | Probe: Maschine (400 Minuten) gesperrt, Trader (2.500 Fills in 50 Minuten) nicht; Neubewertung gibt ≤ 300 frei, > 300 bleibt; auf dem Pi: Debug „Masterregel Sperre“ zeigt Zählung und nach 25 h das Ergebnis der Neubewertung | erledigt v23.13 | Sperren bleiben dauerhaft; die Neubewertung ist einmalig, weil die Basis wechselte · 13:22: 3 Sperren nach der neuen Regel (365–398 gebündelte Trades aus gespeicherten Fills); Beleg der 32 alten Sperren (Untergrenze): 15 über 300, 15 darunter, 2 ohne Werte; Neubewertung am 24.09. gegen 13:00–13:15 |
| U32 | P0 | **Schreibsperre 48,9 s beim Recorder-Start** (A2): `pool_laden` fügte Adressen ohne Commit ein; Transaktion und Sperre aller Dienste (hl_dbcoord) blieben über Symbolauflösung und ersten Leaderboard-Zyklus offen | — | Probe: nach `pool_laden` keine offene Transaktion; auf dem Pi nach dem nächsten Neustart kein Halter > 5 s | erledigt v23.12 (Probe: vorher offen/0 Adressen sichtbar, nachher geschlossen/600 sichtbar) | trat auch stündlich bei neuen Pool-Konten auf · auf dem Pi bestätigt 13:25: längster Halter 11,8 s statt 48,9 s (Rest: U37) |
| U37 | P0 | **Schreibsperre über die Poll-Runde** (Netzwerkstatus 13:25: 76-mal über 1 s, bis 11,8 s, stets „UPDATE addresses SET last_poll=?, notional=0, pos_value=0 …“): Fand der Poller bei einer Adresse KEINE Position mehr, schrieb er sofort — mitten in der Runde; Transaktion und Sperre aller Dienste blieben bis `flush_round` über die übrigen Netzaufrufe offen. Die übrigen Pfade puffern seit 14.09., dieser war übersehen | — | Probe: nach `poll_address` keine offene Transaktion; auf dem Pi: Halter über 1 s selten, keiner über 5 s | erledigt v23.14 (Probe: 23.13 offen, 23.14 geschlossen; Null-Stand korrekt geschrieben, jüngster Stand je Adresse gewinnt) · **auf dem Pi bestätigt 14:47** (34 min nach 23.15): Halter Ø 11 ms statt 234 ms, 3-mal über 1 s statt 76-mal, längster 4,2 s (wal_checkpoint), die Poll-Anweisung ist verschwunden; Binance wartet Ø 0,2 ms (max 10) statt 108 ms (max 1.200) |
| U34 | P0 | **Selbsttest-Tore flackerten**: Positivkontrolle v2 (hl_kalib) und Konstellations-Nulltest bauten ihr synthetisches Szenario an `time.time()` (4-h-Raster, Kanten-Zuordnung je Block) — bei unverändertem Code je 5 von 24 Viertelstunden FEHL (gemessen; p_up bei Kante 0,65 zwischen 56,8 und 65,7 %). Aufgefallen, weil der Selbsttest von 23.13 in genau diesen beiden unveränderten Modulen durchfiel | — | gleiche Ausgabe zu jeder Uhrzeit; Selbsttest 23/23 | erledigt v23.13 (fester Zeitpunkt, Tor über 5 feste Szenarien: v2 Mittel 60,7 %, Konstellation gepoolt +2,5 pp) | ein Tor, das jedes fünfte Mal zufällig rot ist, ist kein Tor |
| U35 | P1 | **Tor der Positivkontrolle v2 neu fassen**: Das absolute Fenster p_up 0,60–0,70 vermischt Basisrate und Treiberbeitrag (Szenario-Basis 45,6–60,6 % → p_up 57,3–67,0 %); das Mittel 60,7 % liegt nur 0,7 Punkte über der Grenze. Vorschlag: Tor auf den Log-Odds-Beitrag des Treibers gegen den wahren Wert log(0,65/0,35) = 0,62, basisratenunabhängig, Schwelle aus der Schrumpfung der 1-SE-Regel begründet | vor U7b | Tor mit mathematischer Begründung, deterministisch | offen | Entscheidung vor dem Umschalten auf v2 |
| U27 | P4 | **Flow-Treiber auf Basis der qualifizierten Profis** (Positionsaenderungen der Top-20-Profis in 60 min, Nulltest-Pflicht, kleiner Prior) statt nur der 6 BTC-Halter der Gewinnspitze | 2 Wochen Profis-Daten | Nulltest gruen, Lift-Bilanz nach 4 Wochen | offen | Vorschlag 23.09. |
| U8 | P1 | **H10 Bilanz der Kauf-/Verkaufsempfehlungen**: Füllung 4–12 h, Rendite 4/12/24 h, Vergleich Markt/nie, Gebühren (Maker/Taker), advised ja/nein | — | Kachel mit n, Quote, Netto nach Kosten | offen | wirtschaftlich wichtigster Punkt (Audit §8) |
| U9 | P1 | H11 Magnet-Pfad nur bei z ≥ 2 des Lifts; Placebo driftbereinigt in magnet_stats | — | Nulltest Magnet grün | offen | |

### P2 — Kontenstatistik

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U10 | P2 | H8 Rest: Benjamini-Hochberg über alle Konten, Aufnahme in die Elite erst nach OOS-Bestätigung (Folgewoche Vorlauf > 0, n ≥ 5), `score_test` als Freigabe des Treibers | — | Nullsimulation: Fehlalarme ≤ nominal | offen | Block-t seit 22.18 |
| U11 | P2 | M3 Hedge-Regel: nur Short-Korb oder nachweisbare Gegenposition | — | Harness-Szenario | offen | |
| U12 | P2 | M8: Pool-Deckel nach Aktivität statt pnl_7d; Folge-PnL roh nach Gebühren ausweisen | U3 | Anzeige | offen | |
| U13 | P2 | Elite des Treibers auf die Profis-Liste umstellen | U3/U4, 4 Wochen Beobachtung | Entscheidung Nutzer | offen | |
| U14 | P4 | Töne/Signale bei Trades der 20 Profis | U4 | Browser-Probe | offen | |
| U15 | P2 | Klasse „Market-Maker" auch aus Aktivität ableiten (wirkt in Wale/Smart Money) | U3 | Harness | offen | Vorschlag vom 22.09. |
| U16 | P2 | Pool-Hysterese Etappe 2: 7 → 30 Tage (`POOL_HYSTERESE_TAGE`) | 4 Wochen Betrieb | Entscheidung Nutzer | offen | |

### P3 — Betrieb und Sicherheit

| ID | Prio | Punkt | Abhängigkeit | Abnahme | Status | Notiz |
|---|---|---|---|---|---|---|
| U17 | P3 | S2 Paket-Signatur/Prüfsumme vor dem Entpacken in update.py (Prüfsumme aus version.py gesondert veröffentlichen) | — | Update mit falscher Prüfsumme wird abgelehnt | offen | |
| U18 | P3 | S3 sudoers NOPASSWD nur für die systemctl-Befehle, sudo.txt entfernen | Nutzer (Root) | Restore/Update ohne Passwortdatei | offen | Betriebsentscheidung |
| U19 | P3 | S1 Token für POST-Routen (zusätzlich zur Host-Allowlist) | — | POST ohne Token abgelehnt | offen | optional |
| U20 | P3 | M11 Rest: stille `except: pass` zählen und in /system zeigen | — | Zähler sichtbar | offen | store_forecast seit 22.18 |
| U21 | P3 | M13: Backup-Generationen auf ein zweites Gerät | Nutzer (Ziel) | backup.json zeigt Ziel | offen | |
| U22 | P3 | H13: Bybit als Referenz für Liquidations-Intensitäten, Binance nur Zählsignal, OKX-Kappungen zählen | — | Harness | offen | |
| U23 | P3 | M5 Funding-Intervalle je Kontrakt (Binance fundingInfo, Bybit instruments-info, OKX fundingTime) | Probe P7 | Spread korrekt auf 8 h normiert | offen | |
| U24 | P4 | N3, N4, N6, N9, N10, M12 (Eröffnungszeitpunkt aus Stream-Fills) | — | je Punkt | offen | Sammelposten |
| U30 | P3 | Debug-Eintrag „Selbsttest (install.py --selftest)", damit A7 auch auf dem Pi läuft (Python 3.13, echte Bibliotheken) | — | Lauf aus der Konsole 23/23 | offen | optional; ~5 min CPU, startet kurz einen Test-Server auf Port 8799 |
| U38 | P3 | **Begrenzer kann über 1.200/min springen**: Deckel 1.080/min plus Eimer 180 (Hauptbudget) plus Reserve 216 — nach einer ruhigen Phase theoretisch bis 1.476 Gewicht in 60 s. Gemessen 13:12: 1.143 von 1.080 (106 %), 0 × 429 | — | Summe der Eimer so, dass Deckel + Eimer ≤ 1.200 (z. B. je 60), Probe mit Lastspitze | offen | bisher ohne 429; Änderung am Kern des Begrenzers, deshalb erst nach Beobachtung |
| U39 | P4 | Übersprungene Zeiträume (`lb_gaps`) begannen bei neuen Konten bei 0 — VOLLBERICHT: „01.01 01:00 bis 23.09 (497.264 h)“ | — | Lücke beginnt beim jüngsten geholten Fill; Altzeilen als „Beginn unbekannt“ | erledigt v23.14 | 28 Altzeilen werden beim nächsten Sprung des Kontos ersetzt |
| U40 | P1 | **Pool-Fills nach jedem Neustart**: lief 10 min nach jedem Start (bis 15.000 Gewicht, ~11 min, Rang 3) und verdrängte den Nachtrag der 75 Auswahl-Konten (13:25: Median 33 min, schlechtestes 1 h) — sechs Updates am 23.09. = sechs Läufe | — | Start 12 h nach dem letzten Lauf (in `meta` gespeichert); VOLLBERICHT trennt Abholstand „Auswahl (15 min)“ und „Pool (12 h)“ | erledigt v23.14 (Probe: letzter Lauf vor 1 h → Wartezeit 10 min + 11 h; ohne Stand → nach 10 min) | nächstes A: Auswahl-Median ≤ 15 min · 14:47: Pool-Fills lief nach dem 23.15-Start noch einmal (528 s) — der Lauf von 23.14 brach beim Einspielen ab und hatte sich nicht gemerkt; jetzt gespeichert (nächster ~02:30). **Beleg steht aus:** beim nächsten Start muss die Zeile „Pool-Fills“ „nächster Lauf in … h“ zeigen. Nachtrag-Median 17 min (13:25: 33), 14 min nach Ende des Pool-Laufs |
| U41 | P1 | **Vertauschter Spot-Taker-Flow bis zur matches-Umstellung** (U2: im ticker ist `side` die Taker-Seite, der Dienst kehrte sie um): buy/sell in `cb_bars` vom Start des Coinbase-Dienstes bis 22.18/22.19 vertauscht. Umstellzeitpunkt aus den Daten (Kursänderung und Netto-Flow je Minute: vorher gegenläufig, nachher gleichläufig; Präfixsummen, Schnitt auf die Minute), vom Coinbase-Dienst beim Start bestimmt (`cb_meta` 'seite_umstellung'). Davor: buy/sell beim Lesen getauscht (Z-Referenz 7 Tage), Treiber-Scores aus v1-Kalibrierung/Bilanz, v2-Training und Konstellationen herausgenommen (nicht umgeschrieben) | — | Probe: Schnitt auf 1 min genau (Gleichlauf 0,22 → 0,79); nie vertauscht → keine; Rauschen → unklar; Z-Wert = wahrer Z-Wert; v1/v2/Konstellationen nur noch Fälle nach dem Schnitt | erledigt v23.15 | auf dem Pi: Debug „Coinbase: Seiten-Umstellung (U41)“ — Zeitpunkt muss vor 02:43 am 23.09. liegen (22.19 lief da schon) · **auf dem Pi bestätigt 14:17:** Schnitt 22.09. 22:27; Gleichlauf vorher 0,356 (57.866 Minuten), nachher 0,63 (3.869) — Spiegelbild, also reine Vertauschung; je Stunde 29–38 % → 57–67 %, Stunde des Schnitts 48 % |
| U42 | P4 | Datenquellen-Tabelle: Bybit, OKX und Crypto.com (live) stehen mit „erwartet unter 60 s“, werden aber nur beim Chart-Abruf geholt; ihr Zustand folgt aus ok/Fehler, nicht aus dem Alter — „vor 8 min“ ist dort normal, die Spalte irreführend | — | Anzeige „beim Abruf“ statt „unter 60 s“ | offen | kosmetisch, mit der nächsten Codeänderung |
| U36 | P3 | `hl_forecast.py --nulltest` baut sein Szenario ebenfalls an `time.time()` — bisher nie durchgefallen, aber ungeprüft: Flackern über 24 Zeitpunkte messen, sonst fester Zeitpunkt wie U34 | — | Messung | offen | Laufzeit ~50 s je Lauf |
| U33 | P4 | Coinbase `last_match` (letzter Handel VOR dem Abo, bei jedem Neuverbinden erneut) zählte als frischer Handel | — | Code | erledigt v23.12 | Volumen doppelt; alter Kurs in der Minutenkerze ruhiger Paare |

### W — Wiederkehrend

| ID | Takt | Punkt | Werkzeug |
|---|---|---|---|
| W1 | wöchentlich | Elite prüfen (Beleg, Gewinn-/Aktivitätsschranke, WEICHT AB) | Debug „Elite-Positionierung prüfen" |
| W2 | wöchentlich | Pool zählen, Trades/Tag-Verteilung, Sperren | Debug „Aktive Profis: Pool zählen", „Masterregel Sperre" |
| W3 | wöchentlich | Treiber-Bilanz: Lift/z je Treiber, OOS-Spalte ab 25 Blöcken | Treibertabelle |
| W4 | nach 8–12 Wochen | Kalibrierung auf forecast_drivers (72/168 h) — nach U7 neu bewerten | — |
| W5 | nach 8 Wochen | Goldene Regel prüfen: ρ(Vorlauf), ρ(Größe) > 2 SE im Wochenmittel (Audit §8.3) | score_test |
| W6 | monatlich | Lint (pyflakes offline nicht verfügbar: eigene Namensprüfung), 170 stille excepts abbauen | — |

---

## C. Erledigt (Kurzliste, Details in UEBERGABE)

23.09. (Opus 5.5, 14:50, nur Dokumente): U41 und U37 auf dem Pi bestätigt; U40 zur Hälfte (Beleg beim nächsten Start).
23.09. (Opus 5.5, v23.15): U2 bestätigt (Coinbase-Seite gemessen) · U41 vertauschter Spot-Taker-Flow vor der Umstellung korrigiert.
23.09. (Opus 5.5, v23.14): U1 bestätigt (P2) · U37 Sperre über die Poll-Runde · U39 Lückenbeginn · U40 Pool-Fills nach Neustart · VOLLBERICHT trennt Auswahl/Pool.
23.09. (Opus 5.5, v23.13): U31 Masterregel auf gebündelte Trades > 300/24 h (Entscheidung Nutzer (a)), einmalige Neubewertung der alten Sperren · U34 Selbsttest-Tore deterministisch.
23.09. (Opus 5.5, v23.12): Abschnitt A auf dem Pi · U32 Schreibsperre beim Start · Coinbase-Test auf matches mit Seitenmessung (U2) · U33 last_match · Beleg je Sperre (check_sperre 1b) · Probe P2 im VOLLBERICHT (U1).
23.09. (Opus 5.5): Abschnitt A Sandbox-Teil · U28 hashlib-Import (NameError-Risiko im Liquidations-Pfad) · Prüfsumme inkl. Werkzeuge (v23.11).
22.09.: Audit v10 P0 (K1, H1, H2-Kanal, H3, H4, H5, H8-Block-t, H9, H12, M1, M2, M6, M9, M11-Teil, M12, M13, N1, N2, N5, N7, N8, S1, S4) · Masterregel Sperre · Aktivitätsschranke Elite · Aktive Profis Phase 0/1 + Vorschau · Treiber-Signale (Pfeile/Blitze/Töne) · HypurrScan-Links · Gewinn-Schranke · Lift-Bilanz · weights_hist · Version/Prüfsumme · Begrenzer mit Rang und Reserve.
21.09.: Elite t_4h-Fehler · Look-ahead im Vorlauf · CPU (Ereignis-Auslöser, Varianz-Cache, Liquidationen in SQL) · Tabs · CPU je Dienst.

## D. Verworfen

- Proposal Stufe 2/3 (Rev. 2) als Umsetzungsgrundlage — ersetzt durch den K2-Neubau (U6/U7); die Familien-Idee (Stufe 3) geht im Neubau als gemeinsame Schätzung auf.
- Nenner je Fall (Stufe 1, Rev. 1) — Audit v9.
