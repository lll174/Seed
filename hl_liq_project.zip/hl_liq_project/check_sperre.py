#!/usr/bin/env python3
"""
check_sperre.py -- Masterregel Sperre: Wer ist gesperrt, warum, seit wann -- wer wurde freigegeben -- wer steht davor?

Regel seit 23.13 (Entscheidung Nutzer 23.09.): mehr als 300 GEBÜNDELTE Trades (je Coin, Minute und Richtung) in
24 h. Bis 23.12 galt: mehr als 2.000 Fills -- Fills sind Ausführungen, keine Entscheidungen (eine große Market-Order
erzeugt Dutzende Fills). Die Sperren der alten Regel werden einmalig neu bewertet, sobald 24 volle Stunden
Trade-Zählung vorliegen (Recorder, sperre_neubewertung). Seit 23.29 zuerst vorläufig (Tag 1), dauerhaft erst beim zweiten
Tag binnen 7 Tagen. 23.37: gespeicherte Fills zählen nur ab 2.500 USD (vorher auch die kleinen Fills der Darwin-Liste),
Sperren seit 29.09. einmalig neu bewertet (sperre_neubewertung_kleinfills). 23.38: Freigaben ohne ein einziges mitgezähltes
kleines Bündel einmalig zurückgenommen (sperre_kleinfill_korrektur).

  python3 check_sperre.py --db PFAD [--grenze 300]
"""
import argparse
import json
import os
import sqlite3
import time


def _t(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(ts or 0))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--grenze", type=int, default=300, help="gebündelte Trades in 24 h")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    now = int(time.time())

    def q(sql, args=()):
        try:
            return con.execute(sql, args).fetchall()
        except sqlite3.OperationalError:
            return []

    kcols = {r[1] for r in q("PRAGMA table_info(konto_status)")}
    tt = "trades_tag" if "trades_tag" in kcols else "NULL"
    rows = q(f"SELECT addr, status, grund, seit, quelle, fills_tag, {tt} FROM konto_status ORDER BY seit DESC")
    gesperrt = [r for r in rows if r[1] == "gesperrt"]
    vorlaeufig = [r for r in rows if r[1] == "vorlaeufig"]
    frei = [r for r in rows if r[1] == "frei"]
    namen = {}
    for tab in ("pool_accounts", "lb_names"):
        for r_ in q(f"SELECT lower(addr), name FROM {tab}"):
            if r_[1] and r_[0] not in namen:
                namen[r_[0]] = str(r_[1])[:18]
    nm = lambda addr: (namen.get(str(addr).lower()) or (addr[:6] + "…" + addr[-4:]))
    man = {}
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels.json"), encoding="utf-8") as f:
            man = {k.lower(): v.get("sperre") for k, v in json.load(f).items() if isinstance(v, dict) and "sperre" in v}
    except (OSError, ValueError):
        pass
    zcols = {r[1] for r in q("PRAGMA table_info(fill_zaehler_h)")}
    hat_trades = "n_trades" in zcols
    jetzt: dict = {}                                               # Konto -> (gebündelte Trades 24 h, Fills 24 h), Stream
    for addr, t_, n_ in q(f"SELECT addr, SUM({'COALESCE(n_trades, 0)' if hat_trades else '0'}), SUM(n) FROM fill_zaehler_h "
                          "WHERE stunde >= ? GROUP BY addr", (now - 86400,)):
        jetzt[addr.lower()] = (int(t_ or 0), int(n_ or 0))

    print(f"Masterregel: > {a.grenze} gebündelte Trades (je Coin, Minute und Richtung) in 24 h -> dauerhaft gesperrt")
    print("(seit 23.13; bis 23.12: > 2.000 Fills). Manuell über labels.json \"sperre\": true/false.")
    t0 = q("SELECT MIN(stunde) FROM fill_zaehler_h WHERE n_trades IS NOT NULL") if hat_trades else []
    t0 = t0[0][0] if t0 and t0[0][0] else None
    nb = q("SELECT v FROM meta WHERE k='masterregel_neubewertung'")
    if nb:
        try:
            d = json.loads(nb[0][0])
        except (TypeError, ValueError):
            d = {}
        print(f"Neubewertung der alten Sperren: erledigt {_t(d.get('ts'))} -- {d.get('geprueft', '?')} geprüft, "
              f"{d.get('frei', '?')} freigegeben, {d.get('bleibt', '?')} bleiben gesperrt")
    elif t0:
        print(f"Trade-Zählung seit {_t(t0)}; Neubewertung der alten Sperren ab {_t(t0 + 3600 + 86400)} (nach 24 vollen Stunden)")
    else:
        print("Trade-Zählung beginnt mit dem ersten Fill-Lauf nach dem Update (23.13); Neubewertung rund 25 h danach")

    kf = q("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'")
    if kf:
        try:
            d = json.loads(kf[0][0])
        except (TypeError, ValueError):
            d = {}
        fr = d.get("frei") or []; zr = d.get("zurueckgenommen") or []
        print(f"Neubewertung 23.37 (Zählfehler Kleinfills der Darwin-Liste, Sperren seit 29.09.): erledigt {_t(d.get('ts'))} -- "
              f"{d.get('geprueft', '?')} geprüft, {len(fr)} freigegeben, {len(d.get('bleibt') or [])} bleiben"
              + (f", {len(zr)} Freigaben am {_t(d.get('korrektur_ts'))} zurückgenommen (23.38)" if zr else ""))
        for e in fr:
            print(f"   frei: {nm(e.get('addr', '')):<18} {e.get('dann', '?')} gebündelte Trades vor der Sperre ohne Kleinfills"
                  + (f", mit ihnen {e['alle']}" if e.get("alle") is not None else "") + f", {e.get('klein', '?')} Bündel mit kleinen Fills (war {e.get('status', '?')})")
        for e in zr:
            print(f"   zurückgenommen: {nm(e.get('addr', '')):<18} kein kleines Bündel mitgezählt -- die Sperre war kein Zählfehler; "
                  f"wieder {e.get('wieder', '?')} seit {_t(e.get('seit'))}")
    else:
        print("Neubewertung 23.37 (Zählfehler Kleinfills): steht aus -- läuft beim nächsten Fill-Lauf des Recorders")

    print(f"\n0. Vorläufig ausgeschlossen (Tag 1 über der Grenze; dauerhaft erst bei einem zweiten Tag binnen 7 Tagen): {len(vorlaeufig)} Konten")
    for r in vorlaeufig[:80]:
        tj = jetzt.get(r[0].lower())
        print(f"   {nm(r[0]):<18} seit {_t(r[3])} · jetzt {tj[0] if tj else '—'} Trades (Stream) · {r[2]}")

    print(f"\n1. Gesperrt: {len(gesperrt)} Konten" + (f" · labels.json: {sum(1 for v in man.values() if v)} manuell gesperrt, "
                                                    f"{sum(1 for v in man.values() if v is False)} geschützt" if man else ""))
    print("   Konto          seit          Quelle        Trades 24 h jetzt · Grund")
    for r in gesperrt[:80]:
        tj = jetzt.get(r[0].lower())
        tj_t = f"{tj[0]:>5}" if tj else "    —"
        print(f"   {nm(r[0]):<18} {_t(r[3])}  {str(r[4]):<12} {tj_t}  {r[2]}")
    if len(gesperrt) > 80:
        print(f"   … und {len(gesperrt) - 80} weitere")
    if frei:
        print(f"\n1a. Freigegeben (Neubewertungen, abgelaufene vorläufige): {len(frei)} Konten")
        for r in frei[:80]:
            print(f"   {nm(r[0]):<18} {_t(r[3])}  {r[2]}")

    alte = [r for r in gesperrt if r[6] is None and r[4] == "auto"]
    if alte:
        print(f"\n1b. Alte Sperren (Fills-Regel), {len(alte)} Konten -- Beleg aus den 24 h VOR der Sperre (pool_fills_hourly: gespeicherte")
        print("    Fills ab 2.500 USD, Trades gebündelt je Coin/Minute/Richtung -- also Untergrenze). Endgültig entscheidet die")
        print("    Neubewertung mit der Stream-Zählung (alle Fills der verfolgten Coins).")
        for r in alte[:80]:
            addr = r[0].lower(); seit = int(r[3] or 0)
            pz = q("SELECT SUM(n_fills), SUM(n_trades), SUM(buy_usd + sell_usd), COUNT(DISTINCT stunde) FROM pool_fills_hourly "
                   "WHERE stunde >= ? AND stunde < ? AND lower(addr)=?", (seit - 86400, seit, addr))
            pz = pz[0] if pz else (None, None, None, 0)
            std = pz[3] or 0
            if not std:
                print(f"   {addr[:6]}…{addr[-4:]}  keine Stundenwerte vor der Sperre (nicht in Auswahl/Pool)")
                continue
            tpt = (pz[1] or 0) * 24 / std
            je = (pz[0] or 0) / (pz[1] or 1)
            lage = f"über {a.grenze} -> bleibt gesperrt" if tpt > a.grenze else f"unter {a.grenze} (vorläufig)"
            print(f"   {addr[:6]}…{addr[-4:]}  gespeichert {pz[0] or 0:>5} Fills · {pz[1] or 0:>4} Trades (≈ {tpt:.0f}/Tag aus {std} h, "
                  f"{je:.1f} Fills je Trade) · Umsatz {(pz[2] or 0) / 1e6:,.1f} Mio · {lage}" + (" (wenige Stunden)" if std < 6 else ""))

    print(f"\n2. Nahe der Grenze (nicht gesperrt): gebündelte Trades 24 h -- Stream (verfolgte Coins, alle Fills) und gespeicherte")
    print("   Fills (alle Coins der Leaderboard-Konten, ab 2.500 USD); es gilt das Maximum")
    gs = {r[0].lower() for r in gesperrt}
    lb = {r[0]: (int(r[1] or 0), int(r[2] or 0)) for r in q(
        "SELECT lower(addr), COUNT(*), COUNT(DISTINCT coin || ':' || market || ':' || ((ts / 60) * 2 + COALESCE(buy, 0))) "
        "FROM lb_fills WHERE ts >= ? AND notional >= 2497.5 GROUP BY 1", (now - 86400,))}      # 23.37: wie der Recorder, ohne Kleinfills
    konten = set(jetzt) | set(lb)
    liste = []
    gs |= {r[0].lower() for r in vorlaeufig}
    for addr in konten:
        if addr in gs:
            continue
        t_s, n_s = jetzt.get(addr, (0, 0)); n_l, t_l = lb.get(addr, (0, 0))
        liste.append((max(t_s, t_l), t_s, t_l, n_s, addr))
    liste.sort(reverse=True)
    for tmax, t_s, t_l, n_s, addr in liste[:20]:
        marke = " <-- über der Grenze (wird beim nächsten Fill-Lauf gesperrt)" if tmax > a.grenze else (" (nahe)" if tmax > a.grenze * 0.7 else "")
        print(f"   {nm(addr):<18} {t_s:>5} Trades (Stream) · {t_l:>4} Trades (gespeichert) · {n_s:>6} Fills (Stream){marke}")
    if not liste:
        print("   keine Zählerwerte")

    print("\n3. Wirkung einer Sperre: kein Verhaltenssignal (Wale, Flows, Scores, Elite), keine Order-Abfrage, keine Fill-Speicherung,")
    print("   Leaderboard-Zyklus überspringt das Konto; Positionen bis 23.85 alle 6 h (Liquidationsstufe, bei Überlast nie erreicht), seit 23.86")
    print("   gar nicht mehr abgefragt (U220, Entscheidung 26.10.).")
    con.close()


if __name__ == "__main__":
    main()
