#!/usr/bin/env python3
"""
check_sperre.py -- Masterregel Sperre: Wer ist gesperrt, warum, seit wann -- und wer steht kurz davor?

  python3 check_sperre.py --db PFAD [--grenze 2000]
"""
import argparse
import json
import os
import sqlite3
import time


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--grenze", type=int, default=2000)
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    now = int(time.time())
    try:
        rows = con.execute("SELECT addr, status, grund, seit, quelle, fills_tag FROM konto_status ORDER BY seit DESC").fetchall()
    except sqlite3.OperationalError:
        rows = []
    man = {}
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels.json"), encoding="utf-8") as f:
            man = {k.lower(): v.get("sperre") for k, v in json.load(f).items() if isinstance(v, dict) and "sperre" in v}
    except (OSError, ValueError):
        pass
    print(f"Masterregel: > {a.grenze} Fills an einem Tag -> dauerhaft gesperrt (automatisch); manuell über labels.json \"sperre\": true/false\n")
    print(f"1. Gesperrt (Tabelle konto_status): {len(rows)} Konten" + (f" · manuell in labels.json: {sum(1 for v in man.values() if v)} gesperrt, {sum(1 for v in man.values() if v is False)} geschützt" if man else ""))
    for r in rows[:60]:
        print(f"   {r[0][:6]}…{r[0][-4:]}  {r[1]:<9} seit {time.strftime('%d.%m. %H:%M', time.localtime(r[3] or 0))}  {r[4]:<7} {r[2]}")
    if len(rows) > 60:
        print(f"   … und {len(rows) - 60} weitere")
    print("\n2. Aktivste Konten der letzten 24 h (Rohfills, nur gespeicherte Konten) -- nahe der Grenze?")
    try:
        top = con.execute("SELECT lower(addr), COUNT(*) FROM lb_fills WHERE ts >= ? GROUP BY 1 ORDER BY 2 DESC LIMIT 15", (now - 86400,)).fetchall()
        for addr, n in top:
            marke = " <-- über der Grenze (wird beim nächsten Fill-Lauf gesperrt)" if n > a.grenze else (" (nahe)" if n > a.grenze * 0.7 else "")
            print(f"   {addr[:6]}…{addr[-4:]}  {n:>6} Fills{marke}")
        if not top:
            print("   keine Fills in 24 h")
    except sqlite3.OperationalError as e:
        print(f"   ({e})")
    print("\n3. Wirkung einer Sperre: kein Verhaltenssignal (Wale, Flows, Scores, Elite), keine Order-Abfrage, keine Fill-Speicherung,")
    print("   Leaderboard-Zyklus überspringt das Konto; Positionen nur alle 6 h (Liquidationsstufe) für die Heatmap.")
    con.close()


if __name__ == "__main__":
    main()
