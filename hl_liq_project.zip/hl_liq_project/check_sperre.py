#!/usr/bin/env python3
"""
check_sperre.py -- Masterregel Sperre: Wer ist gesperrt, warum, seit wann -- und wer steht kurz davor?

  python3 check_sperre.py --db PFAD [--grenze 2000]
"""
import argparse
import json
import os
import sqlite3
import time


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--grenze", type=int, default=2000)
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    now = int(time.time())
    try:
        rows = con.execute("SELECT addr, status, grund, seit, quelle, fills_tag FROM konto_status ORDER BY seit DESC").fetchall()
    except sqlite3.OperationalError:
        rows = []
    man = {}
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels.json"), encoding="utf-8") as f:
            man = {k.lower(): v.get("sperre") for k, v in json.load(f).items() if isinstance(v, dict) and "sperre" in v}
    except (OSError, ValueError):
        pass
    print(f"Masterregel: > {a.grenze} Fills in 24 h -> dauerhaft gesperrt (automatisch; seit 22.18 rollierend und ALLE Fills, vorher nur Fills ab 2.500 USD je UTC-Tag); manuell über labels.json \"sperre\": true/false\n")
    print(f"1. Gesperrt (Tabelle konto_status): {len(rows)} Konten" + (f" · manuell in labels.json: {sum(1 for v in man.values() if v)} gesperrt, {sum(1 for v in man.values() if v is False)} geschützt" if man else ""))
    for r in rows[:60]:
        print(f"   {r[0][:6]}…{r[0][-4:]}  {r[1]:<9} seit {time.strftime('%d.%m. %H:%M', time.localtime(r[3] or 0))}  {r[4]:<7} {r[2]}")
    if len(rows) > 60:
        print(f"   … und {len(rows) - 60} weitere")
    # 23.12 (A6, Plan U31): Fills sind AUSFÜHRUNGEN, keine Entscheidungen -- eine große Market-Order oder ein TWAP
    # erzeugt Dutzende Fills. Beleg je Sperre: gebündelte Trades (Minute x Richtung) in den 24 h VOR der Sperre.
    print("\n1b. Beleg je Sperre (24 h vor der Sperre): alle Fills = Zähler der Regel (fill_zaehler_h, seit 22.18) · gespeichert =")
    print("    Fills ab 2.500 USD · Trades = gebündelt je Minute und Richtung (aus den gespeicherten Fills, also Untergrenze)")
    print("    Einordnung: > 300 Trades/Tag Maschinen-Muster (Elite-Schranke) · < 150 Trader-Muster (Pool-Grenze) · dazwischen unklar")
    zaehl = {"Maschinen-Muster": 0, "Trader-Muster": 0, "unklar": 0, "ohne Beleg": 0}
    for r in rows[:60]:
        addr = r[0].lower(); seit = int(r[3] or 0)
        alle = None
        try:
            z = con.execute("SELECT SUM(n) FROM fill_zaehler_h WHERE addr=? AND stunde >= ? AND stunde <= ?", (addr, seit - 86400, seit)).fetchone()
            alle = z[0] if z else None
        except sqlite3.OperationalError:
            pass
        try:
            pz = con.execute("SELECT SUM(n_fills), SUM(n_trades), SUM(buy_usd + sell_usd), COUNT(DISTINCT stunde) FROM pool_fills_hourly "
                             "WHERE stunde >= ? AND stunde < ? AND lower(addr)=?", (seit - 86400, seit, addr)).fetchone()
        except sqlite3.OperationalError:
            pz = None
        std = (pz[3] if pz else 0) or 0
        alle_t = f"{alle:>6}" if alle is not None else "     —"
        if not std:
            zaehl["ohne Beleg"] += 1
            print(f"   {addr[:6]}…{addr[-4:]}  alle {alle_t} · keine Stundenwerte vor der Sperre (nicht in Auswahl/Pool)")
            continue
        tpt = (pz[1] or 0) * 24 / std
        einordnung = "Maschinen-Muster" if tpt > 300 else ("Trader-Muster" if tpt < 150 else "unklar")
        zaehl[einordnung] += 1
        je = (pz[0] or 0) / (pz[1] or 1)
        print(f"   {addr[:6]}…{addr[-4:]}  alle {alle_t} · gespeichert {pz[0] or 0:>5} · Trades {pz[1] or 0:>4} (≈ {tpt:.0f}/Tag aus {std} h, "
              f"{je:.1f} Fills je Trade) · Umsatz {(pz[2] or 0) / 1e6:,.1f} Mio · {einordnung}" + (" (wenige Stunden)" if std < 6 else ""))
    print("   Summe: " + " · ".join(f"{k} {v}" for k, v in zaehl.items()))
    print("   Lesart: Trader-Muster = wenige Entscheidungen in vielen Fills -- dann ist die Sperre fraglich; Schutz über")
    print("   labels.json \"sperre\": false. Die Rohfills Gesperrter sind gelöscht, die Stundenwerte oben bleiben.")

    print("\n2. Nahe der Grenze: Zähler der Regel (ALLE Fills, rollierend 24 h) -- dazu gespeicherte Fills und gebündelte Trades")
    gesperrt_ = {r[0].lower() for r in rows}
    try:
        top = [x for x in con.execute("SELECT addr, SUM(n) FROM fill_zaehler_h WHERE stunde >= ? GROUP BY addr ORDER BY 2 DESC LIMIT 100",
                                      (now - 86400,)).fetchall() if x[0].lower() not in gesperrt_][:20]     # Gesperrte stehen in 1b
    except sqlite3.OperationalError:
        top = []
    try:
        gesp = {r[0]: (r[1], r[2]) for r in con.execute("SELECT lower(addr), COUNT(*), COUNT(DISTINCT (ts/60)*2 + COALESCE(buy,0)) FROM lb_fills "
                                                          "WHERE ts >= ? GROUP BY 1", (now - 86400,))}
    except sqlite3.OperationalError:
        gesp = {}
    for addr, n in top:
        g = gesp.get(addr.lower(), (0, 0))
        marke = " <-- über der Grenze" if n > a.grenze else (" (nahe)" if n > a.grenze * 0.7 else "")
        print(f"   {addr[:6]}…{addr[-4:]}  {n:>6} Fills (alle) · {g[0]:>5} gespeichert · {g[1]:>4} Trades{marke}")
    if not top:
        print("   keine Zählerwerte (fill_zaehler_h fehlt oder leer)")
    print("\n3. Wirkung einer Sperre: kein Verhaltenssignal (Wale, Flows, Scores, Elite), keine Order-Abfrage, keine Fill-Speicherung,")
    print("   Leaderboard-Zyklus überspringt das Konto; Positionen nur alle 6 h (Liquidationsstufe) für die Heatmap.")
    con.close()


if __name__ == "__main__":
    main()
