"""
hl_makro_js.py -- Skript des Makro-Abschnitts im Dashboard (U121, 23.47), ausgeliefert unter /makro.js.

Eigene Datei statt im großen Seiten-Text von hl_viz: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text kaum.
Baut auf den Helfern der Seite auf ($, getJSON, esc, hideTip) und muss deshalb NACH dem Hauptskript geladen werden.
Ein generischer SVG-Chart (mkZeichne): Fadenkreuz mit allen Reihen am Tag, Legende ab zwei Reihen, Tabellenansicht je Chart,
keine zweite y-Achse; Farben in fester Reihenfolge, für die dunkle Chartfläche geprüft (Kurs neutral, Farbe folgt dem Treiber).
Seit 23.54 (U132) die Kursleiste: unter jedem Kennzahl-Chart der Kurs in BTC-Orange in einem eigenen Feld (eigene log. Skala,
dieselbe Zeitachse, gemeinsames Fadenkreuz, Spalte in der Tabelle), Schalter „BTC-Kurs“ in der Filterzeile.
"""

MAKRO_JS = r"""// 23.47 Makro-Chart (U121): Wo steht der Markt im mittel- und langfristigen Zyklus? Positionen statt Signale.
// Daten: /makro?tab=..&coin=.. (hl_makro.py, eigene makro.db). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist.
// Farben: Kategorien in fester Reihenfolge (validiert für die dunkle Chartfläche #01030a), Kurs neutral; Farbe folgt dem Treiber.
// 23.54 (U132): Kursleiste -- unter jedem Kennzahl-Chart der Kurs (BTC-Orange) in einem eigenen Feld mit eigener log. Skala auf
// derselben Zeitachse, gemeinsames Fadenkreuz. Nie als zweite Achse im selben Feld: deren Skalierung ist frei wählbar und erzeugt
// Gleichlauf, wo keiner ist. Charts in USD zeigen den Kurs schon selbst (neutral) und bekommen keine Leiste.
const MK={tab:'ueberblick', bereich:'4j', coin:'BTC', kurs:true, lf:'1j', aus:{}, cache:{}, laeuft:{}, specs:{}, tabelle:{}, n:0,
 szen:{geraet:'s21xp', jth:13.5, ct:7.5, waehrung:'USD', aufschlag:0}};
try{ const s_=JSON.parse(localStorage.getItem('hl_makro')||'{}'); ['tab','bereich','coin','lf'].forEach(k=>{ if(s_[k]) MK[k]=s_[k]; }); if(typeof s_.kurs==='boolean') MK.kurs=s_.kurs;
 if(s_.szen&&typeof s_.szen==='object') Object.assign(MK.szen, s_.szen);
 if(s_.aus&&typeof s_.aus==='object') Object.keys(s_.aus).forEach(k=>{ if(s_.aus[k]===true&&/^[a-z0-9]{1,24}$/.test(k)) MK.aus[k]=true; }); }catch(e){}
function mkMerken(){ try{ localStorage.setItem('hl_makro', JSON.stringify({tab:MK.tab, bereich:MK.bereich, coin:MK.coin, kurs:MK.kurs, lf:MK.lf, aus:MK.aus, szen:MK.szen})); }catch(e){} }
const MK_TABS=[['ueberblick','Überblick'],['bewertung','Bewertung'],['trend','Trend'],['langfrist','24 Monate'],['kohorten','Kohorten'],['miner','Miner'],
 ['hebel','Hebel & Stimmung'],['fluss','Kapitalfluss'],['makro','Makro'],['daten','Daten']];
const MK_BEREICH=[['1j','1 J',365],['2j','2 J',730],['4j','4 J',1461],['8j','8 J',2922],['alles','Alles',0]];
const MK_F=['#3987e5','#d95926','#199e70','#c98500','#d55181','#008300','#9085e9','#e66767'];
const MK_KURS='#c9d1d9', MK_GRID='#161b22', MK_REF='#30363d', MK_MUTED='#8b949e', MK_FLAECHE='#01030a';
// Kursleiste (23.54): BTC-Orange auf Wunsch des Nutzers -- nur im eigenen Feld, nie neben #d95926/#c98500 in derselben Fläche
// (Prüfskript: normal ΔE 14,6 bzw. 9,0, als Kategorie zu nah); Kennung über Lage und Beschriftung, nicht über die Farbe allein.
const MK_BTC='#f7931a';
// 23.128 (U322): Farbe der Linie „Märkte-Modell“ -- geprüft mit dem Prüfskript auf der dunklen Fläche gegen Blau, Grün und Gelbbraun des
// Charts „24 Monate“ (alle Paare: normal ΔE ≥ 20,0, Farbsehschwäche ≥ 10,1; gegen das Neutral der Kurs-Linien 31,9). Das Neutral der
// Markt-Schicht ginge hier nicht: Die Linie liefe fast auf „Kurs bleibt“.
const MK_PMM='#ad51a7';
const MK_FARBE={RP:MK_F[0], WMA:MK_F[1], FV:MK_F[2], STH:MK_F[3], TMM:MK_F[4], MINER:MK_F[5], DELTA:MK_F[6], LTH:MK_F[7]};
const MK_RAMPE=['#9ec5f4','#86b6ef','#6da7ec','#5598e7','#3987e5','#2a78d6','#256abf','#1c5cab'];
const MK_COINS_MVRV=['BTC','ETH','ZEC'], MK_COINS_WMA=['BTC','ETH','ZEC','XMR'];

// ---------- Zahlen und Datum (Dezimalkomma) ----------
function mkZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}); }
function mkUsd(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x);
 if(a>=1e12) return mkZ(x/1e12,2)+' Bio'; if(a>=1e9) return mkZ(x/1e9,a>=1e11?0:1)+' Mrd'; if(a>=1e6) return mkZ(x/1e6,1)+' Mio';
 if(a>=1000) return mkZ(x,0); if(a>=1) return mkZ(x,2); return mkZ(x,4); }
function mkPct(x,d){ return x==null||!isFinite(x)?'—':(x>0?'+':x<0?'−':'')+mkZ(Math.abs(x)*100,d==null?1:d)+' %'; }
function mkPp(x,d){ return x==null||!isFinite(x)?'—':(x<0?'−':'')+mkZ(Math.abs(x),d==null?1:d)+' %'; }
function mkX(d){ return x=>x==null||!isFinite(x)?'—':(x<0?'−':'')+mkZ(Math.abs(x),d); }
function mkDatum(tag){ const d=new Date(tag*864e5); return String(d.getUTCDate()).padStart(2,'0')+'.'+String(d.getUTCMonth()+1).padStart(2,'0')+'.'+d.getUTCFullYear(); }
function mkMonat(tag){ const d=new Date(tag*864e5); return ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'][d.getUTCMonth()]+' '+String(d.getUTCFullYear()).slice(2); }

// ---------- Reihen: täglich {t0, v} oder unregelmäßig {t:[Tage], v} ----------
function mkS(o){ return o&&o.v&&o.v.length?{t0:o.t0, v:o.v}:null; }
function mkSt(t,v){ return t&&t.length?{t:t, v:v}:null; }
function mkErster(s){ if(!s) return null; if(s.t){ for(let i=0;i<s.t.length;i++) if(s.v[i]!=null) return s.t[i]; return null; }
 for(let i=0;i<s.v.length;i++) if(s.v[i]!=null) return s.t0+i; return null; }
function mkLetzt(s){ if(!s) return null; if(s.t){ for(let i=s.t.length-1;i>=0;i--) if(s.v[i]!=null) return {tag:s.t[i], v:s.v[i]}; return null; }
 for(let i=s.v.length-1;i>=0;i--) if(s.v[i]!=null) return {tag:s.t0+i, v:s.v[i]}; return null; }
function mkWert(s,tag,maxAbstand){ if(!s) return null;
 if(s.t){ const t=s.t; let lo=0, hi=t.length-1; if(hi<0) return null;
  while(lo<hi){ const m=(lo+hi+1)>>1; if(t[m]<=tag) lo=m; else hi=m-1; }
  for(let i=lo;i>=0&&tag-t[i]<=(maxAbstand||8);i--) if(t[i]<=tag&&s.v[i]!=null) return s.v[i];
  return null; }
 const i=tag-s.t0; if(i<0||i>=s.v.length+3) return null;
 for(let k=0;k<=(maxAbstand==null?3:maxAbstand);k++){ const j=i-k; if(j>=0&&j<s.v.length&&s.v[j]!=null) return s.v[j]; }
 return null; }
// 23.67 (U153): streng -- der Wert der jüngsten Stützstelle ≤ tag, auch wenn er fehlt (eine Lücke zeigt „—“ statt des Vormonats)
function mkWertStrikt(s,tag,maxAbstand){ if(!s||!s.t) return mkWert(s,tag,maxAbstand); const t=s.t; let lo=0, hi=t.length-1; if(hi<0||t[0]>tag) return null;
 while(lo<hi){ const m=(lo+hi+1)>>1; if(t[m]<=tag) lo=m; else hi=m-1; }
 return tag-t[lo]<=(maxAbstand||8)?s.v[lo]:null; }
function mkMap(s,f){ return s?(s.t?{t:s.t, v:s.v.map((v,i)=>v==null?null:f(v,s.t[i]))}:{t0:s.t0, v:s.v.map((v,i)=>v==null?null:f(v,s.t0+i))}):null; }
function mkKombi(a,b,f){ if(!a||!b) return null; const t0=Math.max(a.t0,b.t0), t1=Math.min(a.t0+a.v.length,b.t0+b.v.length); if(t1<=t0) return null;
 const v=new Array(t1-t0); for(let t=t0;t<t1;t++){ const x=a.v[t-a.t0], y=b.v[t-b.t0]; v[t-t0]=x==null||y==null?null:f(x,y); } return {t0, v}; }
function mkSma(s,n,minN){ if(!s) return null; minN=minN||n; const v=s.v, out=new Array(v.length).fill(null); let sum=0,k=0;
 for(let i=0;i<v.length;i++){ if(v[i]!=null){ sum+=v[i]; k++; } if(i>=n&&v[i-n]!=null){ sum-=v[i-n]; k--; } if(v[i]!=null&&k>=minN) out[i]=sum/k; }
 return {t0:s.t0, v:out}; }
function mkVerlauf(s){ return s?{t0:s.t0, v:s.v}:null; }

// ---------- Achsen ----------
function mkSchritte(lo,hi,n){ const roh=(hi-lo)/(n||5); if(!(roh>0)) return [lo]; const mag=Math.pow(10,Math.floor(Math.log10(roh)));
 const st=[1,2,2.5,5,10].map(f=>f*mag).find(s=>s>=roh)||10*mag; const out=[]; for(let v=Math.ceil(lo/st)*st; v<=hi+st*1e-9; v+=st) out.push(+v.toPrecision(12)); return out; }
function mkLogSchritte(lo,hi){ const out=[]; const e0=Math.floor(Math.log10(lo)), e1=Math.ceil(Math.log10(hi)), dek=Math.log10(hi/lo);
 const fs=dek>4?[1]:dek>2?[1,3]:dek>0.8?[1,2,5]:[1,1.5,2,3,5,7];
 for(let e=e0;e<=e1;e++) fs.forEach(f=>{ const v=f*Math.pow(10,e); if(v>=lo*0.999&&v<=hi*1.001) out.push(v); });
 if(out.length<2){ const m=Math.sqrt(lo*hi); out.push(+m.toPrecision(2)); } return out; }
function mkXSchritte(x0,x1){ const tage=x1-x0, out=[]; const d0=new Date(x0*864e5);
 if(tage>3*365){ const sprung=tage>9*365?2:1; for(let j=d0.getUTCFullYear()+1;;j+=sprung){ const t=Date.UTC(j,0,1)/864e5; if(t>x1) break; out.push([t,String(j)]); } }
 else{ const sprung=tage>540?3:tage>200?2:1; let j=d0.getUTCFullYear(), m=d0.getUTCMonth()+1; if(m>11){ m=0; j++; }
  while(true){ const t=Date.UTC(j,m,1)/864e5; if(t>x1) break; if(m%sprung===0) out.push([t,mkMonat(t)]); m++; if(m>11){ m=0; j++; } } }
 return out; }

// ---------- generischer Chart ----------
// sp: {titel, unter, h, log, fmt, reihen:[{n, s, c, w, d (Strich), fmt, nurTip, ende, band:[lo,hi]}], linien:[{y,t}], zonen:[{a,b,t}],
//      marken:[{tag, y, t, c, form}], quelle, x0, x1, xTage (Halving-Achse), y0 (einschließen), ymin, ymax, tabelle,
//      kurs (Kursreihe für die Kursleiste, 23.54), kursName}
// 23.116 (U279): xFest:[x0,x1] (fester Zeitraum statt des Schalters „Zeitraum“), Reihe: kurz (Name in der Legende), lo (Deckkraft des
//      Legendenfelds eines Bands), vlinien: links (Beschriftung links der Linie), dy (tiefer), halo; xmarken:[{tag}] (Striche unten),
//      xTicks(x0,x1,Breite) (eigene Marken der Zeitachse), endenMax (Endbeschriftungen bis zu so vielen Reihen statt 4)
// 23.117 (U297): Reihe: schalt (Kennung aus a–z und 0–9) -- ihr Eintrag in der Legende ist ein Knopf, der die Reihe aus- und einblendet
//      (MK.aus, gemerkt). Ausgeblendet zählt sie nicht für die Achse, wird nicht gezeichnet und fehlt im Fadenkreuz; die Tabelle zeigt sie weiter.
// 23.121 (U280 Teil 2b): Reihe: leitern:[{niveau, punkte:[{tag, lab, t, zeilen}]}] -- je Punkt eine Raute am Ort (Tag, Niveau), Punkte
//      einer Leiter mit einer gepunkteten Linie verbunden, „lab“ als Zahl am Punkt (nur mit Platz); spannen-Eintrag: raute (Mitte als
//      Raute statt Punkt); xmarken: form ('hoch'|'gleich'|'runter'|'offen') -- ein Zeichen über dem Strich, schalt blendet es mit aus
function mkAus(r){ return !!(r&&r.schalt&&MK.aus[r.schalt]); }
function mkSchalt(id,k){ if(MK.aus[k]) delete MK.aus[k]; else MK.aus[k]=true; mkMerken();
 document.querySelectorAll('.mkleg [data-schalt]').forEach(b=>{ if(b.getAttribute('data-schalt')!==k) return;
  b.classList.toggle('aus',!!MK.aus[k]); b.setAttribute('aria-pressed',MK.aus[k]?'false':'true'); });
 const tb=$('mkschalt-'+k); if(tb){ tb.className='tog '+(MK.aus[k]?'off':'on'); tb.setAttribute('aria-pressed',MK.aus[k]?'false':'true'); }   // 23.128
 mkZeichne(id); }
function mkFigur(id, sp){ MK.specs[id]=sp;
 const leg=(sp.reihen||[]).filter(r=>r.n&&!r.nurTip&&!r.ohneLeg&&(r.s||r.band||r.spannen||r.leitern));   // 23.128: ohneLeg -- zweites Stück einer Linie
 const legInnen=r=>r.leitern
   ?`<svg width="24" height="12" style="vertical-align:middle;margin-right:4px"><line x1="0" y1="6" x2="24" y2="6" stroke="${r.c}" stroke-width="1.2" stroke-dasharray="1.5,3.5"/><path d="M12,1.5L16.5,6L12,10.5L7.5,6Z" fill="${MK_FLAECHE}" stroke="${r.c}" stroke-width="1.3"/></svg>${esc(r.kurz||r.n)}`
   :r.spannen
   ?`<svg width="12" height="14" style="vertical-align:middle;margin-right:4px"><line x1="6" y1="1" x2="6" y2="13" stroke="${r.c}" stroke-width="1.1"/><line x1="6" y1="4" x2="6" y2="10" stroke="${r.c}" stroke-width="3.2"/><circle cx="6" cy="7" r="1.5" fill="${MK_FLAECHE}"/></svg>${esc(r.kurz||r.n)}`
   :r.band&&!r.s
   ?`<span class="sw" style="background:${r.c};opacity:${r.lo||.35}"></span>${esc(r.kurz||r.n)}`
   :`<svg width="18" height="8" style="vertical-align:middle;margin-right:4px"><line x1="0" y1="4" x2="18" y2="4" stroke="${r.c}" stroke-width="2"${r.d?` stroke-dasharray="${r.d}"`:''}/></svg>${esc(r.kurz||r.n)}`;
 const legende=leg.length>=2||(leg.length===1&&sp.legendeImmer)?`<div class="leg mkleg">${leg.map(r=>r.schalt
   ?`<button type="button" class="mkschalt${mkAus(r)?' aus':''}" data-schalt="${esc(r.schalt)}" aria-pressed="${mkAus(r)?'false':'true'}" title="${esc(r.n)} – antippen blendet die Linie aus und wieder ein" onclick="mkSchalt('${id}','${esc(r.schalt)}')">${legInnen(r)}</button>`
   :`<span>${legInnen(r)}</span>`).join('')}</div>`:'';
 return `<div class="mkfig"><div class="mkkopf"><b>${esc(sp.titel)}</b>${sp.unter?` <span class="sub">${sp.unter}</span>`:''}`
  +`<button class="mktab" onclick="mkTabelleUm('${id}')">${MK.tabelle[id]?'Chart':'Tabelle'}</button></div>${legende}<div id="${id}" class="mkplot"></div>`
  +`<div id="${id}-tab" class="mktabelle"></div>${sp.quelle||sp.fuss?`<div class="mkquelle">${sp.fuss?sp.fuss+(sp.quelle?' · ':''):''}${sp.quelle?'Quelle: '+sp.quelle:''}</div>`:''}</div>`; }
function mkTabelleUm(id){ MK.tabelle[id]=!MK.tabelle[id]; const sp=MK.specs[id]; if(!sp) return;
 const b=document.querySelector(`[onclick="mkTabelleUm('${id}')"]`); if(b) b.textContent=MK.tabelle[id]?'Chart':'Tabelle'; mkZeichne(id); }
function mkBereich(sp){ const bt=MK_BEREICH.find(b=>b[0]===MK.bereich)||MK_BEREICH[2];
 if(sp.xFest) return [sp.xFest[0], sp.xFest[1]];                      // 23.116: Reiter „24 Monate“ -- eigener Rückblick, fester Blick voraus
 let x1=-Infinity, x0=Infinity;
 (sp.reihen||[]).forEach(r=>{ if(r.zukunft) return; [r.s,...(r.band||[])].forEach(s=>{ if(!s) return; const l=mkLetzt(s), e=mkErster(s); if(l) x1=Math.max(x1,l.tag); if(e!=null) x0=Math.min(x0,e); }); });
 if(!isFinite(x1)) return null;
 if(sp.x1!=null) x1=sp.x1; if(sp.xTage) return [sp.x0||0, x1];
 if(bt[2]) x0=Math.max(x0, x1-bt[2]); if(sp.x0!=null) x0=Math.max(x0, sp.x0);
 if(sp.zukunft) x1+=sp.zukunft;                                       // Prognose rechts vom letzten Datentag
 return x1>x0?[x0,x1]:null; }
function mkKursReihe(sp){ return MK.kurs&&sp&&sp.kurs&&!sp.xTage?sp.kurs:null; }
// 23.121 (U280 Teil 2b): Zeichen über einem Strich der Zeitachse -- was der Markt für den Termin erwartet. Neutral, keine Statusfarbe:
// Dreieck nach oben (hoch), Balken (gleich), Dreieck nach unten (runter), hohle Raute (offen).
function mkXForm(x,y,m){ const c=m.c||MK_MUTED, t=`<title>${esc(m.t||'')}</title>`, k=`class="mkxf" data-form="${esc(m.form)}"`;
 if(m.form==='hoch') return `<path ${k} d="M${(x-4).toFixed(1)},${y+3}L${(x+4).toFixed(1)},${y+3}L${x.toFixed(1)},${y-4}Z" fill="${c}">${t}</path>`;
 if(m.form==='runter') return `<path ${k} d="M${(x-4).toFixed(1)},${y-3}L${(x+4).toFixed(1)},${y-3}L${x.toFixed(1)},${y+4}Z" fill="${c}">${t}</path>`;
 if(m.form==='gleich') return `<rect ${k} x="${(x-4).toFixed(1)}" y="${y-1.5}" width="8" height="3" fill="${c}">${t}</rect>`;
 return `<path ${k} d="M${x.toFixed(1)},${y-4}L${(x+4).toFixed(1)},${y}L${x.toFixed(1)},${y+4}L${(x-4).toFixed(1)},${y}Z" fill="${MK_FLAECHE}" stroke="${c}" stroke-width="1.2">${t}</path>`; }
function mkZeichne(id){ const sp=MK.specs[id], el=$(id); if(!sp||!el) return;
 const tabEl=$(id+'-tab');
 const br=mkBereich(sp);
 if(!br){ el.innerHTML='<div class="sub mkleer">Noch keine Daten für diesen Chart (Quelle noch nicht abgerufen oder Historie zu kurz).</div>'; if(tabEl) tabEl.innerHTML=''; return; }
 const [x0,x1]=br;
 // 23.54: Kursleiste im Zeitraum des Charts (x0..x1 kommen nur aus den eigenen Reihen -- der Kurs verlängert die Achse nie)
 const kurs=mkKursReihe(sp), kursName=sp.kursName||'Kurs BTC';
 if(MK.tabelle[id]){ el.innerHTML=''; if(tabEl) tabEl.innerHTML=mkTabelleHtml(sp,x0,x1,kurs,kursName); return; }
 if(tabEl) tabEl.innerHTML='';
 const KP=kurs?Math.max(46,Math.round((sp.h||240)*0.28)):0, G=kurs?8:0;
 const W=Math.max(280,(el.clientWidth||600)), H=(sp.h||240)+G+KP, L=6, R=64, T=10, B=20, pw=W-L-R, ph=(sp.h||240)-T-B;
 const T2=T+ph+G, unten=kurs?T2+KP:T+ph;
 const X=t=>L+(t-x0)/Math.max(1,x1-x0)*pw;
 // y-Bereich aus den sichtbaren Werten
 let lo=Infinity, hi=-Infinity; const nimm=v=>{ if(v!=null&&isFinite(v)&&(!sp.log||v>0)){ if(v<lo) lo=v; if(v>hi) hi=v; } };
 const besuche=(s,f)=>{ if(!s) return; if(s.t){ for(let i=0;i<s.t.length;i++) if(s.t[i]>=x0&&s.t[i]<=x1) f(s.v[i]); }
  else{ const a=Math.max(0,x0-s.t0), b=Math.min(s.v.length-1,x1-s.t0); for(let i=a;i<=b;i++) f(s.v[i]); } };
 (sp.reihen||[]).forEach(r=>{ if(r.nurTip||r.ohneSkala||mkAus(r)) return; besuche(r.s,nimm); (r.band||[]).forEach(s=>besuche(s,nimm));
  (r.spannen||[]).forEach(p=>{ if(p.tag>=x0&&p.tag<=x1){ nimm(p.lo); nimm(p.hi); } });
  (r.leitern||[]).forEach(l=>{ if(l.punkte.some(p=>p.tag>=x0&&p.tag<=x1)) nimm(l.niveau); }); });
 (sp.marken||[]).forEach(m=>{ if(m.tag>=x0&&m.tag<=x1) nimm(m.y); });
 if(sp.y0!=null) nimm(sp.y0); (sp.linien||[]).forEach(l=>{ if(l.skala) nimm(l.y); });
 if(sp.ymin!=null) lo=sp.log?Math.max(sp.ymin,1e-12):sp.ymin; if(sp.ymax!=null) hi=sp.ymax;
 if(!isFinite(lo)||!isFinite(hi)){ el.innerHTML='<div class="sub mkleer">Keine Werte im gewählten Zeitraum.</div>'; return; }
 if(hi===lo){ hi=sp.log?hi*1.1:hi+1; lo=sp.log?lo/1.1:lo-1; }
 let Y; if(sp.log){ const a=Math.log(lo), b=Math.log(hi), pad=(b-a)*0.04; const a2=a-pad, b2=b+pad; Y=v=>T+(b2-Math.log(v))/(b2-a2)*ph; lo=Math.exp(a2); hi=Math.exp(b2); }
 else{ const pad=(hi-lo)*0.05; if(sp.ymin==null) lo-=pad; if(sp.ymax==null) hi+=pad; Y=v=>T+(hi-v)/(hi-lo)*ph; }
 const fmt=sp.fmt||mkUsd;
 let s=`<svg width="${W}" height="${H}" style="display:block;background:${MK_FLAECHE};border:1px solid #21262d;border-radius:6px">`;
 // Zonen (Zeitspannen) als neutrale Wäsche mit Beschriftung im Tooltip
 (sp.zonen||[]).forEach(z=>{ const a=Math.max(x0,z.a), b=Math.min(x1,z.b); if(b<a) return; s+=`<rect x="${X(a).toFixed(1)}" y="${T}" width="${Math.max(1,X(b+1)-X(a)).toFixed(1)}" height="${unten-T}" fill="${z.c||'#8b949e'}" opacity="${z.o||0.09}"/>`; });
 // Gitter und Achsenbeschriftung rechts
 const ticks=sp.log?mkLogSchritte(lo,hi):mkSchritte(lo,hi,sp.ticks||5);
 ticks.forEach(v=>{ if(v<lo||v>hi) return; const y=Y(v).toFixed(1); s+=`<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" stroke="${MK_GRID}"/><text x="${W-R+4}" y="${(+y+3).toFixed(1)}" fill="${MK_MUTED}" font-size="10">${(sp.tickFmt||fmt)(v)}</text>`; });
 const xt=sp.xTage?[0,365,730,1095,1460].filter(t=>t<=x1).map(t=>[t,'Tag '+t]):sp.xTicks?sp.xTicks(x0,x1,pw):mkXSchritte(x0,x1);
 xt.forEach(([t,txt])=>{ const x=X(t); if(x<L+2||x>W-R-2) return; s+=`<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${T}" y2="${unten}" stroke="${MK_GRID}"/><text x="${(x+3).toFixed(1)}" y="${H-6}" fill="${MK_MUTED}" font-size="10">${txt}</text>`; });
 // Bezugslinien (Definitionen, keine Schwellen)
 (sp.linien||[]).forEach(l=>{ if(l.y<lo||l.y>hi) return; const y=Y(l.y).toFixed(1); s+=`<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" stroke="${l.c||MK_REF}" stroke-width="1"/>`
  +(l.t?`<text x="${L+4}" y="${(+y-3).toFixed(1)}" fill="${MK_MUTED}" font-size="10" paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3">${esc(l.t)}</text>`:''); });
 (sp.vlinien||[]).forEach(l=>{ if(l.tag<x0||l.tag>x1) return; const x=X(l.tag).toFixed(1); s+=`<line x1="${x}" x2="${x}" y1="${T}" y2="${unten}" stroke="${l.c||MK_REF}" stroke-dasharray="2,3"/>`
  +(l.t?`<text x="${(+x+(l.links?-3:3)).toFixed(1)}" y="${T+10+(l.dy||0)}" fill="${MK_MUTED}" font-size="10"${l.links?' text-anchor="end"':''}${l.halo?` paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3"`:''}>${esc(l.t)}</text>`:''); });
 (sp.xmarken||[]).forEach(m=>{ if(m.tag<x0||m.tag>x1) return; const x=X(m.tag).toFixed(1); s+=`<line class="mkxm" x1="${x}" x2="${x}" y1="${unten-6}" y2="${unten}" stroke="${m.c||MK_MUTED}" stroke-width="1.5"/>`;
  if(m.form&&!(m.schalt&&MK.aus[m.schalt])) s+=mkXForm(+x, unten-12, m); });
 // Bänder
 (sp.reihen||[]).forEach(r=>{ if(!r.band||mkAus(r)) return; const [a,b]=r.band; const pa=mkPunkte(a,x0,x1,X,Y,pw,true), pb=mkPunkte(b,x0,x1,X,Y,pw,true);
  if(pa.length<2||pb.length<2) return; s+=`<path d="M${pa.map(p=>p[0]+','+p[1]).join('L')}L${pb.reverse().map(p=>p[0]+','+p[1]).join('L')}Z" fill="${r.c}" opacity="${r.o||0.1}" stroke="none"/>`; });
 // Linien
 const enden=[];
 (sp.reihen||[]).forEach(r=>{ if(!r.s||r.nurTip||mkAus(r)) return; const d=mkPfad(r.s,x0,x1,X,Y,pw,sp.log);
  if(d) s+=`<path d="${d}" fill="none" stroke="${r.c}" stroke-width="${r.w||1.6}" stroke-linejoin="round" stroke-linecap="round"${r.d?` stroke-dasharray="${r.d}"`:''}${r.o?` opacity="${r.o}"`:''}/>`;
  if(r.ende){ const l=mkLetzt(r.s); if(l&&l.tag>=x0&&l.tag<=x1&&(!sp.log||l.v>0)) enden.push({x:X(l.tag), y:Y(Math.min(hi,Math.max(lo,l.v))), t:r.ende===true?r.n:r.ende, c:r.c}); } });
 // Spannen (23.118): je Eintrag ein Zeichen am Tag -- dünner Strich lo bis hi, dicker q1 bis q3, Punkt an der Mitte; Rand in Flächenfarbe
 (sp.reihen||[]).forEach(r=>{ if(!r.spannen||mkAus(r)) return; r.spannen.forEach(p=>{ if(p.tag<x0||p.tag>x1||p.m==null||p.q1==null||p.q3==null||(sp.log&&!(p.lo>0))) return;
  const x=X(p.tag).toFixed(1), yy=v=>Y(Math.min(hi,Math.max(lo,v))).toFixed(1);
  s+=`<g class="mkspanne${p.raute?' mkpmspanne':''}"><line x1="${x}" y1="${yy(p.lo)}" x2="${x}" y2="${yy(p.hi)}" stroke="${MK_FLAECHE}" stroke-width="3" stroke-linecap="round" opacity="0.7"/>`
   +`<line x1="${x}" y1="${yy(p.lo)}" x2="${x}" y2="${yy(p.hi)}" stroke="${r.c}" stroke-width="1.1" stroke-linecap="round"/>`
   +`<line x1="${x}" y1="${yy(p.q1)}" x2="${x}" y2="${yy(p.q3)}" stroke="${r.c}" stroke-width="3.2" opacity="0.85"/>`
   +(p.raute?`<path d="M${x},${(+yy(p.m)-3.6).toFixed(1)}L${(+x+3.6).toFixed(1)},${yy(p.m)}L${x},${(+yy(p.m)+3.6).toFixed(1)}L${(+x-3.6).toFixed(1)},${yy(p.m)}Z" fill="${MK_FLAECHE}" stroke="${r.c}" stroke-width="1.2"><title>${esc(p.t||'')}</title></path>`
    :`<circle cx="${x}" cy="${yy(p.m)}" r="2.4" fill="${MK_FLAECHE}" stroke="${r.c}" stroke-width="1.2"><title>${esc(p.t||'')}</title></circle>`)+`</g>`; }); });
 // Leitern (23.121): Punkte der Prognosemärkte -- Raute am Ort (Tag, Niveau); Punkte desselben Niveaus verbindet eine gepunktete Linie. Die Zahl
 // am Punkt nur mit Platz: je Leiter zuerst der späteste Punkt, dann die übrigen von spät nach früh; keine Zahl, die näher als 30 px
 // (waagrecht) und 12 px (senkrecht) an einer schon gesetzten läge
 (sp.reihen||[]).forEach(r=>{ if(!r.leitern||mkAus(r)) return; const erst=[], dann=[], gesetzt=[];
  r.leitern.forEach(l=>{ if(l.niveau==null||(sp.log&&!(l.niveau>0))||l.niveau<lo||l.niveau>hi) return;
   const pp=l.punkte.filter(p=>p.tag>=x0&&p.tag<=x1); if(!pp.length) return; const y=Y(l.niveau);
   if(pp.length>1) s+=`<line class="mkpmlinie" x1="${X(pp[0].tag).toFixed(1)}" x2="${X(pp[pp.length-1].tag).toFixed(1)}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${r.c}" stroke-width="1.2" stroke-dasharray="1.5,3.5" stroke-linecap="round"/>`;
   pp.forEach(p=>{ const x=X(p.tag); s+=`<path class="mkpmpunkt" d="M${x.toFixed(1)},${(y-4.5).toFixed(1)}L${(x+4.5).toFixed(1)},${y.toFixed(1)}L${x.toFixed(1)},${(y+4.5).toFixed(1)}L${(x-4.5).toFixed(1)},${y.toFixed(1)}Z" fill="${MK_FLAECHE}" stroke="${r.c}" stroke-width="1.4"><title>${esc(p.t||'')}</title></path>`; });
   erst.push({x:X(pp[pp.length-1].tag), y, lab:pp[pp.length-1].lab}); for(let i=pp.length-2;i>=0;i--) dann.push({x:X(pp[i].tag), y, lab:pp[i].lab}); });
  erst.concat(dann).forEach(w=>{ if(!w.lab) return; const rechts=w.x>W-R-16, lx=rechts?w.x+4:w.x, ly=w.y-8>=T+9?w.y-8:w.y+15;
   if(gesetzt.some(g=>Math.abs(g.x-lx)<30&&Math.abs(g.y-ly)<12)) return; gesetzt.push({x:lx, y:ly});
   s+=`<text class="mkpmlab" x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" fill="${MK_KURS}" font-size="10" text-anchor="${rechts?'end':'middle'}" paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3">${esc(w.lab)}</text>`; }); });
 // Marken
 (sp.marken||[]).forEach(m=>{ if(m.tag<x0||m.tag>x1||m.y==null||(sp.log&&m.y<=0)) return; const x=X(m.tag), y=Y(Math.min(hi,Math.max(lo,m.y)));
  if(m.form==='dreieck') s+=`<path d="M${(x-4).toFixed(1)},${(y+6).toFixed(1)}L${(x+4).toFixed(1)},${(y+6).toFixed(1)}L${x.toFixed(1)},${(y-1).toFixed(1)}Z" fill="${m.c||MK_KURS}" stroke="${MK_FLAECHE}" stroke-width="1.5"><title>${esc(m.t||'')}</title></path>`;
  else if(m.form==='dreieck_ab') s+=`<path d="M${(x-4).toFixed(1)},${(y-6).toFixed(1)}L${(x+4).toFixed(1)},${(y-6).toFixed(1)}L${x.toFixed(1)},${(y+1).toFixed(1)}Z" fill="${m.c||MK_KURS}" stroke="${MK_FLAECHE}" stroke-width="1.5"><title>${esc(m.t||'')}</title></path>`;
  else s+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="4" fill="${m.c||MK_KURS}" stroke="${MK_FLAECHE}" stroke-width="2"><title>${esc(m.t||'')}</title></circle>`;
  if(m.lab) s+=`<text x="${(x+6).toFixed(1)}" y="${(y-5).toFixed(1)}" fill="${MK_MUTED}" font-size="10" paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3">${esc(m.lab)}</text>`; });
 // Endbeschriftung (nur wenn Platz)
 // Endbeschriftung nur bei höchstens 4 beschrifteten Reihen und genug Breite (sonst Legende und Fadenkreuz); Halo in Flächenfarbe
 if(enden.length<=(sp.endenMax||4)&&W>=520){ enden.sort((a,b)=>a.y-b.y); const gesetzt=[]; enden.forEach(e=>{
  const rechts=e.x>W-R-70, x=rechts?W-R-4:e.x+5, breit=6*String(e.t).length, a=rechts?x-breit:x, b=rechts?x:x+breit;   // 23.128: auch waagrecht
  if(gesetzt.some(g=>Math.abs(e.y-g.y)<13&&a<g.b+4&&g.a<b+4)) return; gesetzt.push({y:e.y, a, b}); s+=`<text x="${x.toFixed(1)}" y="${(e.y-5).toFixed(1)}" fill="${MK_MUTED}" font-size="10" text-anchor="${rechts?'end':'start'}" paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3">${esc(e.t)}</text>`; }); }
 // Kursleiste (23.54): eigenes Feld unter dem Chart, eigene log. Skala, dieselbe Zeitachse
 if(kurs){ let klo=Infinity, khi=-Infinity; besuche(kurs,v=>{ if(v!=null&&isFinite(v)&&v>0){ if(v<klo) klo=v; if(v>khi) khi=v; } });
  s+=`<g class="mkkurs"><line x1="${L}" x2="${W-R}" y1="${T2-G/2}" y2="${T2-G/2}" stroke="${MK_REF}"/>`;
  if(isFinite(klo)&&isFinite(khi)){ if(khi===klo){ khi*=1.1; klo/=1.1; }
   const a=Math.log(klo), b=Math.log(khi), pad=(b-a)*0.06, a2=a-pad, b2=b+pad, Y2=v=>T2+(b2-Math.log(v))/(b2-a2)*KP;
   let kt=mkLogSchritte(Math.exp(a2),Math.exp(b2)); if(kt.length>3){ const k=Math.ceil(kt.length/3); kt=kt.filter((_,i)=>i%k===0); }
   kt.forEach(v=>{ const y=Y2(v); if(y<T2||y>T2+KP) return; s+=`<line x1="${L}" x2="${W-R}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${MK_GRID}"/><text x="${W-R+4}" y="${(y+3).toFixed(1)}" fill="${MK_MUTED}" font-size="10">${mkUsd(v)}</text>`; });
   const d=mkPfad(kurs,x0,x1,X,Y2,pw,true);
   if(d) s+=`<path class="mkkurslinie" d="${d}" fill="none" stroke="${MK_BTC}" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"/>`; }
  s+=`<line x1="${L+4}" x2="${L+16}" y1="${T2+7}" y2="${T2+7}" stroke="${MK_BTC}" stroke-width="2"/><text x="${L+20}" y="${T2+11}" fill="${MK_MUTED}" font-size="10" paint-order="stroke" stroke="${MK_FLAECHE}" stroke-width="3">${esc(kursName)} · log. Skala${isFinite(klo)?'':' · keine Kursdaten im Zeitraum'}</text></g>`; }
 s+=`<line class="mkkreuz" x1="0" x2="0" y1="${T}" y2="${unten}" stroke="#58a6ff" stroke-width="1" opacity="0"/>`
  +`<rect class="mkhit" x="${L}" y="${T}" width="${pw}" height="${unten-T}" fill="transparent" style="cursor:crosshair;touch-action:pan-y"/></svg>`;
 el.innerHTML=s;
 const hit=el.querySelector('.mkhit'), kreuz=el.querySelector('.mkkreuz');
 const zeige=ev=>{ const r=hit.getBoundingClientRect(); const px=ev.clientX-r.left+L; const tag=Math.round(x0+(px-L)/pw*(x1-x0));   // 23.121: an der Trefferfläche gemessen (das Bild hat 1 px Rahmen)
  if(tag<x0||tag>x1){ kreuz.setAttribute('opacity','0'); hideTip(); return; }
  const x=X(tag).toFixed(1); kreuz.setAttribute('x1',x); kreuz.setAttribute('x2',x); kreuz.setAttribute('opacity','0.7');
  const tpp=(x1-x0)/Math.max(1,pw);   // 23.121: Tage je Pixel -- der Fangbereich von Zeichen und Terminen richtet sich auch nach der Breite des Bilds
  const zeilen=[]; (sp.reihen||[]).forEach(rr=>{ if(!rr.s||rr.ohneTip||mkAus(rr)) return; const v=(rr.strikt?mkWertStrikt:mkWert)(rr.s,tag,rr.s.t?(rr.maxAbstand||8):3); if(v==null) return;
   zeilen.push([`<span style="display:inline-block;width:12px;height:2px;background:${rr.c};vertical-align:middle;margin-right:5px"></span>${esc(rr.n)}`, (rr.fmt||fmt)(v)]); });
  (sp.reihen||[]).forEach(rr=>{ if(!rr.spannen||mkAus(rr)) return; let b=null; rr.spannen.forEach(p=>{ if(Math.abs(p.tag-tag)<=Math.max(rr.fang||4,5*tpp)&&(!b||Math.abs(p.tag-tag)<Math.abs(b.tag-tag))) b=p; });
   if(b) (b.zeilen||[]).forEach(z=>zeilen.push([`<span style="display:inline-block;width:3px;height:10px;background:${rr.c};vertical-align:middle;margin:0 9px 0 5px"></span>${esc(z[0])}`, esc(z[1])])); });
  (sp.reihen||[]).forEach(rr=>{ if(!rr.leitern||mkAus(rr)) return; rr.leitern.forEach(l=>{ let b=null; l.punkte.forEach(p=>{ if(Math.abs(p.tag-tag)<=Math.max(rr.fang||4,5*tpp)&&(!b||Math.abs(p.tag-tag)<Math.abs(b.tag-tag))) b=p; });
   if(b) (b.zeilen||[]).forEach(z=>zeilen.push([`<span style="display:inline-block;width:6px;height:6px;border:1.3px solid ${rr.c};transform:rotate(45deg);vertical-align:middle;margin:0 8px 0 4px"></span>${esc(z[0])}`, esc(z[1])])); }); });
  if(kurs){ const v=mkWert(kurs,tag,kurs.t?8:3); if(v!=null) zeilen.push([`<span style="display:inline-block;width:12px;height:2px;background:${MK_BTC};vertical-align:middle;margin-right:5px"></span>${esc(kursName)}`, mkUsd(v)+' USD']); }
  (sp.zonen||[]).forEach(z=>{ if(tag>=z.a&&tag<=z.b&&z.t) zeilen.push(['', esc(z.t)]); });
  (sp.tipExtra?sp.tipExtra(tag,tpp):[]).forEach(z=>zeilen.push(z));
  if(!zeilen.length){ hideTip(); return; }
  mkTip(ev, sp.xTage?`Tag ${tag} nach dem Halving`:mkDatum(tag), zeilen); };
 hit.addEventListener('pointermove', zeige); hit.addEventListener('pointerdown', zeige);
 hit.addEventListener('pointerleave', ()=>{ kreuz.setAttribute('opacity','0'); hideTip(); }); }
function mkTip(ev, titel, zeilen){ const t=$('tip'); if(!t) return;
 t.innerHTML=`<div class="t">${titel}</div>`+zeilen.map(z=>`<div class="r"><i>${z[0]}</i><b style="color:#e6edf3">${z[1]}</b></div>`).join('');
 t.style.display='block'; const w=t.offsetWidth, h=t.offsetHeight; let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14; if(y<8) y=ev.clientY+18; x=Math.max(6,Math.min(x,innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; } t.style.left=x+'px'; t.style.top=y+'px'; }
// Punkte im sichtbaren Bereich, je Pixelspalte Minimum und Maximum (Spitzen bleiben sichtbar)
function mkPunkte(s,x0,x1,X,Y,pw,ohneLuecke){ const out=[]; if(!s) return out;
 const roh=[]; if(s.t){ for(let i=0;i<s.t.length;i++) if(s.t[i]>=x0&&s.t[i]<=x1) roh.push([s.t[i],s.v[i]]); }
 else{ const a=Math.max(0,x0-s.t0), b=Math.min(s.v.length-1,x1-s.t0); for(let i=a;i<=b;i++) roh.push([s.t0+i,s.v[i]]); }
 const dicht=roh.length>pw*2; let spalte=null, mn=null, mx=null;
 const raus=()=>{ if(mn){ if(mn[2]<=mx[2]){ out.push(mn); if(mx!==mn) out.push(mx); } else { out.push(mx); out.push(mn); } } mn=mx=null; };
 for(let k=0;k<roh.length;k++){ const [t,v]=roh[k]; if(v==null||!isFinite(v)){ if(!ohneLuecke){ raus(); out.push(null); } continue; }
  const x=X(t), y=Y(v); if(!isFinite(y)) continue; const p=[+x.toFixed(1), +y.toFixed(1), k];
  if(!dicht){ out.push(p); continue; }
  const sp_=Math.round(x); if(sp_!==spalte){ raus(); spalte=sp_; }
  if(!mn){ mn=p; mx=p; } else { if(p[1]>mn[1]) mn=p; if(p[1]<mx[1]) mx=p; } }
 raus(); return out; }
function mkPfad(s,x0,x1,X,Y,pw,log){ const pts=mkPunkte(log?mkMap(s,v=>v>0?v:null):s,x0,x1,X,Y,pw,false); let d='', an=false;
 pts.forEach(p=>{ if(!p){ an=false; return; } d+=(an?'L':'M')+p[0]+','+p[1]; an=true; }); return d; }
function mkTabelleHtml(sp,x0,x1,kurs,kursName){ const reihen=(sp.reihen||[]).filter(r=>r.s&&r.n&&!r.ohneTab).concat(kurs?[{n:kursName||'Kurs BTC', s:kurs, fmt:v=>mkUsd(v)}]:[]);
 const stellen=[]; if(sp.xTage){ for(let t=x0;t<=x1;t+=30) stellen.push(t); }
 else{ let d=new Date(x1*864e5), schritt=(x1-x0)>12*365?3:1; let j=d.getUTCFullYear(), m=d.getUTCMonth();
  stellen.push(x1); while(stellen.length<160){ const t=Date.UTC(j,m,1)/864e5-1; if(t<x0) break; if(t<x1) stellen.push(t); m-=schritt; while(m<0){ m+=12; j--; } } }
 if(!sp.xTage) stellen.reverse();
 return `<div class="mkscroll"><table class="w"><tr><th>${sp.xTage?'Tag':'Datum'}</th>${reihen.map(r=>`<th class="n">${esc(r.n)}</th>`).join('')}</tr>`
  +stellen.map(t=>`<tr><td>${sp.xTage?t:mkDatum(t)}</td>${reihen.map(r=>`<td class="n">${(r.fmt||sp.fmt||mkUsd)((r.strikt?mkWertStrikt:mkWert)(r.s,t,r.s.t?40:6))}</td>`).join('')}</tr>`).join('')+'</table></div>'; }

// ---------- Laden, Tabs, Bereich ----------
function mkOffen(){ const p=$('sec-makro'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function mkLeiste(){ const el=$('mkbar'); if(!el) return;
 const coinListe=MK.tab==='bewertung'?MK_COINS_MVRV:MK.tab==='trend'?MK_COINS_WMA:null;
 el.innerHTML=`<div id="mktabs">${MK_TABS.map(([k,n])=>`<button class="tog ${k===MK.tab?'on':'off'}" onclick="mkTab('${k}')">${n}</button>`).join('')}</div>`
  +(MK.tab==='daten'?'':MK.tab==='langfrist'?mkLfLeiste():`<div class="mkzeile"><span class="lbl">Zeitraum</span>${MK_BEREICH.map(([k,n])=>`<button class="tog ${k===MK.bereich?'on':'off'}" onclick="mkBereichSetzen('${k}')">${n}</button>`).join('')}`
  +(coinListe?`<span class="lbl" style="margin-left:10px">Coin</span>${coinListe.map(c=>`<button class="tog ${c===MK.coin?'on':'off'}" onclick="mkCoin('${c}')">${c}</button>`).join('')}`:'')
  +`<button id="mkkursbtn" class="tog ${MK.kurs?'on':'off'}" style="margin-left:10px" onclick="mkKursUm()" title="Kurs als eigene Leiste unter jedem Kennzahl-Chart: gleiche Zeitachse, eigene log. Skala, gemeinsames Fadenkreuz. Gleichlauf im Bild ist kein Beleg -- viele Kennzahlen sind aus dem Kurs gerechnet.">BTC-Kurs</button>`
  +`<span id="mkstand" class="sub" style="margin-left:auto"></span></div>`); }
function mkKursUm(){ MK.kurs=!MK.kurs; mkMerken(); const b=$('mkkursbtn'); if(b) b.className='tog '+(MK.kurs?'on':'off');
 Object.keys(MK.specs).forEach(id=>{ if($(id)) mkZeichne(id); }); }
function mkTab(k){ MK.tab=k; if(k==='bewertung'&&!MK_COINS_MVRV.includes(MK.coin)) MK.coin='BTC'; mkMerken(); mkLeiste(); mkLaden(false); }
function mkBereichSetzen(k){ MK.bereich=k; mkMerken(); mkLeiste();
 // Tabs mit Text je Zeitraum (Signale; 23.51 Überblick: Überschrift der kleinen Charts) neu aufbauen, sonst nur neu zeichnen
 if(['ueberblick','bewertung','trend','kohorten','miner'].includes(MK.tab)){ const c=MK.cache[MK.tab+'|'+((MK.tab==='bewertung'||MK.tab==='trend')?MK.coin:'BTC')]; if(c){ mkZeigen(c.d); return; } }
 Object.keys(MK.specs).forEach(id=>{ if($(id)) mkZeichne(id); }); }
function mkCoin(c){ MK.coin=c; mkMerken(); mkLeiste(); mkLaden(false); }
async function mkLaden(zwang){ if(!mkOffen()) return; const el=$('mkbody'); if(!el) return;
 if(!$('mktabs')) mkLeiste();
 const coin=(MK.tab==='bewertung'||MK.tab==='trend')?MK.coin:'BTC', key=MK.tab+'|'+coin, c=MK.cache[key];
 if(c&&!zwang&&Date.now()-c.zeit<600000){ mkZeigen(c.d); return; }
 if(MK.laeuft[key]) return; MK.laeuft[key]=true; el.style.opacity=c?'0.55':'1';
 try{ const d=await getJSON('/makro?tab='+MK.tab+'&coin='+encodeURIComponent(coin)); MK.cache[key]={d, zeit:Date.now()};
  if(MK.tab+'|'+((MK.tab==='bewertung'||MK.tab==='trend')?MK.coin:'BTC')===key) mkZeigen(d); }
 catch(e){ if(!c) el.innerHTML='<div class="sub">Makro-Daten nicht erreichbar.</div>'; }
 finally{ MK.laeuft[key]=false; el.style.opacity='1'; } }
function mkZeigen(d){ const el=$('mkbody'); if(!el) return; MK.specs={}; if(d&&d.geraete) MK.geraete=d.geraete; if(typeof hideTip==='function') hideTip();
 const st=$('mkstand'); if(st) st.textContent=d&&d.ok&&d.n?`Daten bis ${mkDatum(d.d0+d.n-1)} · Tagesschluss UTC`:'';
 if(!d||!d.ok){ el.innerHTML=`<div class="sub" style="margin:8px 0">${esc((d&&d.grund)||'keine Daten')}</div>`+(MK.tab==='daten'||MK.tab==='langfrist'?'':'<div class="sub">Tipp: Debug „Makro: jetzt abrufen“ startet den ersten Abruf sofort; der Makro-Takt beginnt 90 s nach dem Start des Dashboards.</div>'); return; }
 const f={ueberblick:mkUeberblick, bewertung:mkBewertung, trend:mkTrend, langfrist:mkLangfrist, kohorten:mkKohorten, miner:mkMiner, hebel:mkHebel, fluss:mkFluss, makro:mkMakro, daten:mkDaten}[MK.tab];
 const teile=f?f(d):[]; el.innerHTML=teile.map(t=>t.html).join('');
 teile.forEach(t=>(t.ids||[]).forEach(id=>mkZeichne(id))); }
function mkFig(sp){ const id='mkc'+(++MK.n); return {html:mkFigur(id,sp), ids:[id]}; }
function mkText(html){ return {html, ids:[]}; }
function mkQ(d,k){ return (d.quellen||{})[k]||k; }
function mkHalvingLinien(d){ return (d.halvings||[]).map(h=>({tag:Date.parse(h)/864e5, t:'Halving'})); }

// ---------- Überblick: Zonenkarte und Kostenbasen ----------
function mkEinheit(z,v){ if(v==null||!isFinite(v)) return '—'; if(z.fmt==='pct') return mkPct(v,1); if(z.fmt==='x0') return mkZ(v,0); if(z.fmt==='x1') return mkZ(v,1);
 if(z.fmt==='musd') return (v<0?'−':'')+mkZ(Math.abs(v),0)+' Mio USD'; return (v<0?'−':'')+mkZ(Math.abs(v),2); }
function mkBalken(pz){ if(pz==null||!isFinite(pz)) return '<span class="sub">—</span>';
 return `<span class="mkbalken" title="Perzentil ${mkZ(pz,1)}"><span class="mkspur"></span><span class="mkmitte"></span><span class="mkpunkt" style="left:calc(${Math.max(0,Math.min(100,pz))}% - 4px)"></span></span> <span class="mkpz">${mkZ(pz,0)}</span>`; }
const MK_DATIV={'unterstes Zehntel':'untersten Zehntel','unteres Drittel':'unteren Drittel','mittleres Drittel':'mittleren Drittel','oberes Drittel':'oberen Drittel','oberstes Zehntel':'obersten Zehntel'};
function mkZusammenfassung(Z){ const g=k=>Z.find(z=>z.key===k); const teile=[];
 const mv=g('mvrv'); if(mv&&mv.pz!=null) teile.push(`Bewertung im ${MK_DATIV[mv.einordnung]||mv.einordnung||'—'} ihrer Historie (MVRV ${mkZ(mv.jetzt!=null?mv.jetzt:mv.wert,2)}, ${mkZ(mv.jetzt_pz!=null?mv.jetzt_pz:mv.pz,0)}. Perzentil)`);
 const pl=g('pl'); if(pl&&pl.pz!=null) teile.push(`Power Law ${mkZ(pl.jetzt!=null?pl.jetzt:pl.wert,2)}× Fair Value (${mkZ(pl.jetzt_pz!=null?pl.jetzt_pz:pl.pz,0)}. Perzentil)`);
 const sth=g('sth'), tmm=g('tmm'); const lage=z=>z?((z.jetzt!=null?z.jetzt:z.wert)>=0?'über':'unter'):null;
 if(sth||tmm) teile.push(`Kurs ${[sth?lage(sth)+' der Kurzfrist-Kostenbasis':null, tmm?lage(tmm)+' dem True Market Mean':null].filter(Boolean).join(' und ')}`);
 const wm=g('wma'); if(wm) teile.push(`${mkPct(wm.jetzt!=null?wm.jetzt:wm.wert,0)} zum 200-Wochen-MA`);
 const hv=g('halving'); if(hv) teile.push(`Tag ${mkZ(hv.wert,0)} nach dem Halving`);
 return teile.join(' · ')+'. Positionen der eigenen Historie; Kauf- und Verkaufssignale je Chart mit Bilanz in den Tabs Bewertung, Trend, Kohorten und Miner.'; }
function mkUeberblick(d){ const Z=d.zonen||[], r=d.r||{}, lv=d.live&&d.live.btc;
 const karten=`<div class="mkkarten">${Z.map(z=>{ const pz=z.jetzt_pz!=null?z.jetzt_pz:z.pz, w=z.fmt==='text'?'':(z.jetzt!=null?mkEinheit(z,z.jetzt)+' <span class="sub">jetzt</span>':mkEinheit(z,z.wert));
   return `<div class="mkkarte"><div class="mkk1"><b>${esc(z.name)}</b><span>${w}</span></div>${pz!=null?`<div class="mkk2">${mkBalken(pz)} <span>${esc(z.einordnung||'')}</span></div>`:''}`
    +`<div class="lz">${esc(z.text||'')}${z.text&&z.bezug?' · ':''}${esc(z.bezug||'')}${z.tag?' · Stand '+mkDatum(z.tag):''}</div></div>`; }).join('')}</div>`;
 const tab=karten+`<div class="mkscroll mkzonenwrap"><table class="w mkzonen"><tr><th>Treiber</th><th class="n">Tagesschluss</th><th class="n">jetzt</th><th>Lage (Perzentil 0–100)</th><th>Bezug</th><th>Einordnung</th></tr>`
  +Z.map(z=>`<tr><td>${esc(z.name)}<div class="lz">${esc(z.text||'')}</div></td><td class="n">${z.fmt==='text'?'':mkEinheit(z,z.wert)}<div class="lz">${z.tag?mkDatum(z.tag):''}</div></td>`
   +`<td class="n">${z.jetzt!=null?mkEinheit(z,z.jetzt):''}</td><td>${mkBalken(z.jetzt_pz!=null?z.jetzt_pz:z.pz)}</td><td class="sub">${esc(z.bezug||'')}</td><td class="sub">${esc(z.einordnung||'')}</td></tr>`).join('')+'</table></div>';
 const P=mkS(r.P), fit=d.fit||{};
 const fv=P&&fit.b?{t0:P.t0, v:P.v.map((_,i)=>Math.pow(10,fit.a+fit.b*Math.log10(P.t0+i-14247)))}:null;
 const kosten=mkKosten(d, mkS(r.ME), mkS(r.EURUSD), MK.szen.jth, MK.szen.ct);
 const teile=[mkText(`<div class="mksatz">${esc(mkZusammenfassung(Z))}${lv?` <span class="sub">(jetzt mit Live-Kurs ${mkUsd(lv)} USD)</span>`:''}</div>`+tab
  +`<div class="sub" style="margin:6px 0 12px">Perzentil = Rang des Werts unter allen eigenen Werten seit dem genannten Beginn (0 tiefster, 100 höchster), am Tag t nur mit Daten bis t berechnet. Feste Schwellen aus 2013–2021 gibt es hier bewusst nicht: Sie haben 2025/26 oben und unten versagt.</div>`
  +`<div class="sub" style="margin:-6px 0 12px">Kursleiste (Schalter „BTC-Kurs“): unter jedem Kennzahl-Chart der Kurs in Orange, eigene log. Skala, dieselbe Zeitachse, gemeinsames Fadenkreuz. Gleichlauf im Bild ist kein Beleg: Viele Kennzahlen sind aus dem Kurs gerechnet (MVRV, Puell, Abstand zum 200-Wochen-MA …) und laufen deshalb mit ihm. Ob eine Kennzahl die <i>künftige</i> Rendite vorhersagt, misst „Makro × Kurs“ (Debug, U130).</div>`), mkMini(d,Z)];
 teile.push(mkFig({titel:'Kurs und Kostenbasen', unter:'log. Skala · Bänder statt Signale', h:300, log:true,
  reihen:[{n:'Kurs BTC', s:P, c:MK_KURS, w:1.4, ende:'Kurs'}, {n:'Realized Price', s:mkS(r.RP), c:MK_FARBE.RP, ende:true},
   {n:'200-Wochen-MA', s:mkS(r.WMA), c:MK_FARBE.WMA, ende:true}, {n:'Power-Law-Fair-Value', s:fv, c:MK_FARBE.FV, d:'5,4', ende:'Fair Value'},
   {n:'Kurzfrist-Kostenbasis', s:mkS(r.STH), c:MK_FARBE.STH, ende:'STH'}, {n:`Stromkosten ${mkGeraetName()} ${mkZ(MK.szen.ct,1)} ct`, s:kosten, c:MK_FARBE.MINER, ende:'Strom'}],
  vlinien:mkHalvingLinien(d), quelle:`${mkQ(d,'cm')} · ${mkQ(d,'bgm')} · ${mkQ(d,'bc')}`}));
 return teile; }

// ---------- Überblick: die Reihe hinter jeder Zahl der Zonenkarte als kleiner Chart (23.51) ----------
// Kleine Vielfache: je Indikator ein Chart, eine Reihe (Titel benennt sie, keine Legende), Bezugslinie, Punkt = letzter Tagesschluss.
const MK_MINI={
 mvrv:{log:true, ref:1, c:MK_F[0], q:'cm', u:'1 = Kurs auf dem Realized Price'},
 pl:{log:true, ref:1, c:MK_FARBE.FV, q:'cm', u:'1 = Kurs auf dem Fair Value (Anpassung bis zum Vormonat)'},
 wma:{ref:0, c:MK_FARBE.WMA, q:'cm', u:'0 = Kurs auf dem 200-Wochen-MA'},
 sth:{ref:0, c:MK_FARBE.STH, q:'bgm', u:'Kurs ÷ Linie − 1 · Linie frei mit 7 Tagen Verzug'},
 tmm:{ref:0, c:MK_FARBE.TMM, q:'bgm', u:'Kurs ÷ Linie − 1 · Linie frei mit 7 Tagen Verzug'},
 mvrvz:{ref:0, c:MK_F[2], q:'cm', u:'0 = Marktkap. gleich realisierte Kap.'},
 puell:{log:true, ref:1, c:MK_F[3], q:'cm', u:'1 = Emission in USD auf dem Jahresmittel'},
 miner:{log:true, ref:1, c:MK_FARBE.MINER, q:'cm', u:'1 = Kurs auf den Stromkosten · nur 4 Jahre (fester Gerätetyp)'},
 ribbons:{ref:0, c:MK_F[0], q:'cm', fmt:v=>mkPct(v,1), u:'Hashrate SMA 30 ÷ SMA 60 − 1 · Flächen: Kapitulation über der Rauschschwelle'},
 fng:{ref:50, c:MK_F[3], q:'fng', ymin:0, ymax:100, u:'30-Tage-Mittel · 50 = neutral'},
 funding:{ref:0, c:MK_F[0], q:'bnc', u:'30-Tage-Mittel, % p. a.'},
 oi:{c:MK_F[1], q:'bnc', u:'Open Interest ÷ Marktkap. in %'},
 dvol:{c:MK_F[6], q:'drb', u:'implizite Volatilität, 30 Tage'},
 ssr:{log:true, c:MK_F[2], q:['llama','cm'], u:'BTC-Marktkap. ÷ Stablecoins'},
 etf:{ref:0, c:MK_F[0], q:'farside', u:'Summe 30 Tage, Achse in Mio USD', tick:v=>mkZ(v,0)}};
function mkMini(d,Z){ const M=d.mini||{}, zon=d.mini_zonen||{}, P=mkS((d.r||{}).P);
 const figs=Z.filter(z=>M[z.key]&&MK_MINI[z.key]).map(z=>{ const c=MK_MINI[z.key], s=mkSt(M[z.key].t,M[z.key].v), l=mkLetzt(s);
  const fmt=c.fmt||(v=>mkEinheit(z,v)), pz=z.jetzt_pz!=null?z.jetzt_pz:z.pz;
  const lade=pz==null&&/lädt/.test(z.bezug||'')?` · ${z.bezug} (${String(z.text||'').split(' – ')[0]})`:'';    // OI-Archiv (23.50)
  const kopf=`${l?fmt(l.v)+' am '+mkDatum(l.tag):'—'}${pz!=null?` · Perzentil ${mkZ(pz,0)}`:''}${lade}`;
  return mkFig({titel:z.name, unter:kopf, fuss:c.u, h:140, log:!!c.log, fmt, tickFmt:c.tick, ymin:c.ymin, ymax:c.ymax,
   reihen:[{n:z.name, s, c:c.c}], linien:c.ref!=null?[{y:c.ref}]:[],
   zonen:(zon[z.key]||[]).map(x=>({a:x.a, b:x.b, c:MK_F[7], o:0.14, t:'Kapitulation (über der Rauschschwelle)'})),
   marken:l?[{tag:l.tag, y:l.v, c:c.c, t:`${z.name}: ${fmt(l.v)} am ${mkDatum(l.tag)}`}]:[], kurs:P,
   quelle:(Array.isArray(c.q)?c.q:[c.q]).map(k=>mkQ(d,k)).join(' · ')}); });
 if(!figs.length) return mkText('');
 return {html:`<h3 class="mkh3">Verlauf je Indikator · Zeitraum ${mkBerName()}</h3><div class="sub" style="margin:0 0 2px">Die Reihe hinter jeder Zahl der Tabelle; Punkt = letzter Tagesschluss. `
  +`Die letzten zwei Jahre täglich, davor jeder siebte Tag. Jeder Chart hat seine eigene Skala${MK.kurs?'; darunter der BTC-Kurs auf derselben Zeitachse (Schalter „BTC-Kurs“ oben)':''}.</div><div class="mkgrid">${figs.map(f=>f.html).join('')}</div>`,
  ids:figs.flatMap(f=>f.ids)}; }

// ---------- Signale (U126): Abweichung zur Referenzlinie, Rückblick, Live-Signal, Bilanz, Prognose ----------
// Rückblick-Marken sind erst im Nachhinein bekannt; Live-Signal nur aus Daten bis zum Tag (Perzentil im Zeitraum ≤ 10 / ≥ 90).
const MK_KAUF='#3fb950', MK_VERK='#f85149';
const MK_SIGFARBE={rp:MK_FARBE.RP, delta:MK_FARBE.DELTA, pl:MK_FARBE.FV, wma:MK_FARBE.WMA, sth:MK_FARBE.STH, tmm:MK_FARBE.TMM, lth:MK_FARBE.LTH, miner:MK_FARBE.MINER, puell:MK_F[3]};
function mkSig(d,key){ return (d.signale||[]).find(b=>b.key===key)||null; }
function mkSigF(b){ return b&&b.fenster?(b.fenster[MK.bereich]||null):null; }
function mkBerName(){ const bt=MK_BEREICH.find(b=>b[0]===MK.bereich); return bt?bt[1]:MK.bereich; }
function mkPctY(y,dz){ return y==null||!isFinite(y)?'—':mkPct(Math.expm1(y),dz==null?0:dz); }
function mkSigWert(b,v){ if(v==null||!isFinite(v)) return '—'; return b.key==='puell'?mkZ(v,2):mkUsd(v)+' USD'; }
function mkHw(x){ return x==null||!isFinite(x)?'∞':mkZ(x,0); }
function mkSigHaupt(sp,b,wertS){ const f=mkSigF(b); if(!f||!b.q||!wertS) return sp; const q=mkS(b.q);
 const med=Math.exp(f.median), ref=mkKombi(wertS,q,(w,x)=>w/x);
 if(ref){ const a=Math.max(ref.t0,f.von); const v=ref.v.slice(a-ref.t0).map(x=>x==null?null:x*med);
  sp.reihen=(sp.reihen||[]).concat([{n:`Median ${mkBerName()} (${mkPctY(f.median)} ${b.ref_zu||'zur Referenz'})`, s:{t0:a, v}, c:MK_MUTED, d:'2,3', w:1.2}]); }
 sp.marken=(sp.marken||[]).concat(f.punkte.map(p=>({tag:p.tag, y:mkWert(wertS,p.tag,3), c:p.art==='kauf'?MK_KAUF:MK_VERK, form:p.art==='kauf'?'dreieck':'dreieck_ab',
  t:`Rückblick ${mkBerName()}: idealer ${p.art==='kauf'?'Kauf':'Verkauf'} am ${mkDatum(p.tag)} (${mkPctY(p.y)} ${b.ref_zu||'zur Referenz'}) – erst im Nachhinein bekannt`})));
 sp.unter=(sp.unter?sp.unter+' · ':'')+`Dreiecke ▲▼: ideale Wendepunkte im Rückblick (${mkBerName()}), gepunktet: Median`;
 return sp; }
function mkSigFig(d,b){ if(!b) return mkText(''); const farbe=MK_SIGFARBE[b.key]||MK_F[0], f=mkSigF(b);
 const kursS=(b.coin&&b.coin!=='BTC'&&d.w&&d.w.P)?mkS(d.w.P):mkS((d.r||{}).P);       // 23.54: Kurs des Coins dieses Signals
 if(!f) return mkText(`<div class="sub" style="margin:10px 0">${esc(b.name)}: im Zeitraum ${mkBerName()} nicht berechnet – ${b.key==='miner'?'fester Gerätetyp ist über mehr als 4 Jahre kein Maßstab':'Historie kürzer als der Zeitraum'}.</div>`);
 const q=mkS(b.q), sch=f.schwelle||{}, T=f.jetzt.tag;
 const st=(arr)=>arr&&arr.length?{t:arr.map((_,i)=>sch.t0+i*sch.k), v:arr.map(y=>y==null?null:Math.exp(y))}:null;
 const pr=f.prognose; let pm=null, plo=null, phi=null;
 if(pr&&pr.h&&pr.h.length){ const t=[T].concat(pr.h.map(h=>T+h.tage)), y0=Math.exp(f.jetzt.y);
  pm={t, v:[y0].concat(pr.h.map(h=>Math.exp(h.y)))}; plo={t, v:[y0].concat(pr.h.map(h=>Math.exp(h.lo)))}; phi={t, v:[y0].concat(pr.h.map(h=>Math.exp(h.hi)))}; }
 const zonen=(f.laeufe||[]).map(z=>({a:z.a, b:z.b, c:z.art==='kauf'?MK_KAUF:MK_VERK, o:0.13, t:z.art==='kauf'?'Live-Kaufzone (Perzentil ≤ 10 im Zeitraum, damals bekannt)':'Live-Verkaufszone (Perzentil ≥ 90, damals bekannt)'}));
 const marken=(f.punkte||[]).map(p=>({tag:p.tag, y:Math.exp(p.y), c:p.art==='kauf'?MK_KAUF:MK_VERK, form:p.art==='kauf'?'dreieck':'dreieck_ab',
  t:`Rückblick: idealer ${p.art==='kauf'?'Kauf':'Verkauf'} am ${mkDatum(p.tag)}, ${mkPctY(p.y)} – erst im Nachhinein bekannt`}));
 const fmt=v=>mkPct(v-1,0);
 return mkFig({titel:`Signal: ${b.name}${b.coin!=='BTC'?' ('+esc(b.coin)+')':''}`, unter:`Abweichung in % (log. Skala) · Zeitraum ${mkBerName()} · Flächen: Live-Signal damals · gestrichelt rechts: Prognose mit 80-%-Band`,
  h:230, log:true, fmt, tickFmt:fmt, zukunft:365, zonen, marken, kurs:kursS, kursName:'Kurs '+(b.coin||'BTC'),
  reihen:[{band:[plo,phi], n:'Prognose 80 %', c:farbe, o:0.14, zukunft:true}, {n:'Abweichung', s:q, c:farbe, w:1.6},
   {n:'Kaufschwelle P10 (gleitend)', s:st(sch.kauf), c:MK_KAUF, d:'4,3', w:1.1}, {n:'Verkaufsschwelle P90 (gleitend)', s:st(sch.verkauf), c:MK_VERK, d:'4,3', w:1.1},
   {n:'Prognose: Rückkehr zum Median', s:pm, c:farbe, d:'2,3', w:1.6, zukunft:true, ohneTip:true}],
  linien:[{y:1, t:`0 % = ${b.ref_name}`}, {y:Math.exp(f.median), t:`Median ${mkBerName()} ${mkPctY(f.median)}`, c:MK_MUTED}],
  tipExtra:tag=>{ if(!pr||tag<=T) return []; const h=pr.h.find(x=>T+x.tage>=tag)||pr.h[pr.h.length-1];
   return [['Prognose (Rückkehr zum Median)', `${mkPctY(h.y)} · ${mkSigWert(b,h.wert)}`], ['80-%-Band', `${mkSigWert(b,h.wert_lo)} – ${mkSigWert(b,h.wert_hi)}`]]; },
  quelle:`eigene Rechnung aus ${mkQ(d,b.tab==='kohorten'?'bgm':'cm')}`}); }
function mkSigText(d,b){ if(!b) return mkText(''); const f=mkSigF(b); if(!f) return mkText('');
 const g=f.grenzen||{}, j=f.jetzt||{}, pr=f.prognose;
 const live=f.signal?`<b style="color:${f.signal==='kauf'?MK_KAUF:MK_VERK}">${f.signal==='kauf'?'▲ Kaufzone':'▼ Verkaufszone'}</b> seit ${mkDatum(f.seit)}`:'kein Live-Signal';
 let h=`<div class="mksatz"><b>${mkPctY(j.y)}</b> ${esc(b.ref_zu||'zur Referenz')} (Stand ${mkDatum(j.tag)}) · Perzentil im Zeitraum ${mkBerName()}: ${j.pz==null?'—':mkZ(j.pz,0)} · Median ${mkPctY(f.median)} · ${live} `
  +`<span class="sub">(Kauf unter ${mkPctY(g.kauf)}, Verkauf über ${mkPctY(g.verkauf)})</span></div>`;
 h+=`<div class="sub">Rückblick ${mkBerName()}: tiefster Stand ${mkPctY(f.min.y)} am ${mkDatum(f.min.tag)}, höchster ${mkPctY(f.max.y)} am ${mkDatum(f.max.tag)} · ${f.punkte.length} ideale Wendepunkte (Mindestwende ${mkZ(Math.expm1(f.theta)*100,0)} %) – erst im Nachhinein bekannt, kein Signal.</div>`;
 const zelle=v=>!v?'—':v.zu_wenig?`<span class="sub">zu wenige Episoden (${v.episoden})</span>`
  :`${mkPct(v.mittel,0)} <span class="sub">(${v.episoden} Ep.)</span>${v.belegt?' <b style="color:'+MK_KAUF+'">belegt</b>':''}`;
 const band=v=>!v||v.zu_wenig?'':`<span class="sub">${mkPct(v.zufall_lo,0)} … ${mkPct(v.zufall_hi,0)}</span>`;
 const hz=Object.keys(f.bilanz||{}).sort((a,b)=>a-b);
 if(hz.length) h+=`<details class="mkdetails"><summary class="sub">Bilanz des Live-Signals, nachgerechnet (Zeitraum ${mkBerName()}, alle Jahre): ${f.belegt} von ${f.tests} Tests belegt – zufällig zu erwarten etwa ${mkZ(f.tests*0.05,1)}</summary>`
  +`<div class="mkscroll"><table class="w"><tr><th>Horizont</th><th class="n">nach Kauf-Einstieg</th><th class="n">Zufall 95 %</th><th class="n">nach Verkauf-Einstieg</th><th class="n">Zufall 95 %</th><th class="n">alle Tage</th></tr>`
  +hz.map(k=>{ const x=f.bilanz[k]; return `<tr><td>${k} T</td><td class="n">${zelle(x.kauf)}</td><td class="n">${band(x.kauf)}</td><td class="n">${zelle(x.verkauf)}</td><td class="n">${band(x.verkauf)}</td><td class="n">${mkPct(x.alle,0)}</td></tr>`; }).join('')
  +`</table></div><div class="sub">Episode = Signaltage mit höchstens 30 Tagen Abstand; gemessen ab dem ersten Signaltag. Zufall: gleich viele Tage zufällig je ±(Horizont + 365) Tage um jeden Einstieg; belegt erst bei p < 0,025 (am Zufallsweg kalibriert: rund 5 % Fehlurteile). Bei Verkauf zählt eine Rendite unter dem Zufallsband.</div></details>`;
 if(pr){ const pf=pr.pruefung||{};
  h+=`<div class="sub" style="margin-top:6px">Prognose: Rückkehr zum Median ${mkPctY(pr.mu)} mit Halbwertszeit ${mkHw(pr.halbwert)} Tagen (90 %: ${mkHw(pr.halbwert_lo)}–${mkHw(pr.halbwert_hi)}); `
   +`${pr.belegt?'Rückkehr statistisch belegt':'<b>Rückkehr nicht belegt</b>'} (Dickey-Fuller t ${mkX(2)(pr.t_df)}, nötig unter −2,86). Band aus den eigenen Prognosefehlern der letzten Jahre.</div>`
   +`<div class="mkscroll"><table class="w"><tr><th>in</th><th class="n">Abweichung</th><th class="n">${b.key==='puell'?'Puell':'Kurs'}</th><th class="n">80-%-Band</th><th class="n">Band traf im Rückblick</th><th class="n">Fehler gegen „bleibt“</th></tr>`
   +pr.h.map(x=>{ const p_=pf[String(x.tage)]||{}; const abd=p_.abdeckung==null?'<span class="sub">zu wenige Prüfungen</span>':mkZ(p_.abdeckung*100,0)+' % <span class="sub">(Soll 80)</span>';
    return `<tr><td>${x.tage} T</td><td class="n">${mkPctY(x.y)}</td><td class="n"><b>${mkSigWert(b,x.wert)}</b></td><td class="n">${mkSigWert(b,x.wert_lo)} – ${mkSigWert(b,x.wert_hi)}</td><td class="n">${abd}</td><td class="n">${p_.vs_naiv==null?'—':mkPct(p_.vs_naiv,0)}</td></tr>`; }).join('')
   +`</table></div>`; }
 return mkText(h); }
// Live gegen Nachrechnung (Archiv mk_signal): stimmt der nachgerechnete Live-Stand mit dem, was an dem Tag zu sehen war?
function mkNachText(N){ const dS=s=>s?String(s).split('-').reverse().join('.'):'—';
 if(!N||!N.archiv) return 'Ob die Nachrechnung dem entspricht, was live zu sehen war, prüft das Archiv der Live-Signale (ein Tagesstand je Tag) – es ist noch leer.';
 if(!N.n) return `Ob die Nachrechnung dem entspricht, was live zu sehen war, prüft das Archiv der Live-Signale (seit ${dS(N.seit)}) – prüfbar ab dem zweiten Archivtag.`;
 if(N.gleich===N.n&&N.signal_gleich===N.n) return `Geprüft: ${N.n} archivierte Live-Werte aus ${N.tage} Tagen (seit ${dS(N.seit)}) stimmen mit der Nachrechnung überein.`;
 return `<b style="color:#d29922">Live gegen Nachrechnung: ${N.n-Math.min(N.gleich,N.signal_gleich)} von ${N.n} archivierten Werten weichen ab</b> (größte Abweichung ${mkZ(N.max,1)} Perzentilpunkte; ${esc((N.paare_abweichend||[]).join(', '))}) – eine Quelle hat alte Werte geändert, die Bilanz zeigt dann nicht genau, was live zu sehen war.`; }
function mkSigUebersicht(d){ const B=d.signale||[]; const reg=d.signal_regeln||{};
 if(!B.length) return mkText(reg.fehler?`<div class="sub" style="color:#d29922">⚠ Signale nicht gerechnet: ${esc(reg.fehler)}</div>`:'');
 const zeilen=B.map(b=>{ const f=mkSigF(b); if(!f) return {b, leer:true};
  const pr=f.prognose, h12=pr&&pr.h?pr.h.find(x=>x.tage===365):null; return {b, f, h12}; });
 const sig=f=>f.signal?`<b style="color:${f.signal==='kauf'?MK_KAUF:MK_VERK}">${f.signal==='kauf'?'▲ Kauf':'▼ Verkauf'}</b>`:'<span class="sub">—</span>';
 const karten=`<div class="mkkarten">${zeilen.map(z=>z.leer?`<div class="mkkarte"><div class="mkk1"><b>${esc(z.b.name)}</b><span class="sub">nicht im Zeitraum</span></div></div>`
  :`<div class="mkkarte"><div class="mkk1"><b>${esc(z.b.name)}</b><span>${mkPctY(z.f.jetzt.y)}</span></div><div class="mkk2">${mkBalken(z.f.jetzt.pz)} ${sig(z.f)}</div>`
   +`<div class="lz">Median ${mkPctY(z.f.median)} · 12 Monate: ${z.h12?mkSigWert(z.b,z.h12.wert)+' ('+mkSigWert(z.b,z.h12.wert_lo)+' – '+mkSigWert(z.b,z.h12.wert_hi)+')':'—'} · belegt ${z.f.belegt} von ${z.f.tests}</div></div>`).join('')}</div>`;
 const tab=`<div class="mkscroll mkzonenwrap"><table class="w mkzonen"><tr><th>Chart</th><th class="n">Abweichung heute</th><th>Perzentil im Zeitraum</th><th>Live-Signal</th><th class="n">Median</th><th class="n">Prognose 12 Monate (80 %)</th><th class="n">Bilanz belegt</th></tr>`
  +zeilen.map(z=>z.leer?`<tr><td>${esc(z.b.name)}</td><td colspan="6" class="sub">im Zeitraum ${mkBerName()} nicht berechnet</td></tr>`
   :`<tr><td>${esc(z.b.name)}<div class="lz">Stand ${mkDatum(z.f.jetzt.tag)}</div></td><td class="n">${mkPctY(z.f.jetzt.y)}</td><td>${mkBalken(z.f.jetzt.pz)}</td><td>${sig(z.f)}</td><td class="n">${mkPctY(z.f.median)}</td>`
    +`<td class="n">${z.h12?mkSigWert(z.b,z.h12.wert)+'<div class="lz">'+mkSigWert(z.b,z.h12.wert_lo)+' – '+mkSigWert(z.b,z.h12.wert_hi)+'</div>':'—'}</td><td class="n">${z.f.belegt} von ${z.f.tests}</td></tr>`).join('')+'</table></div>';
 return mkText(`<h3 class="mkh3">Signale im Zeitraum ${mkBerName()}</h3>${karten}${tab}`
  +`<div class="sub" style="margin:4px 0 12px">Live-Signal: Abweichung zur Referenzlinie im untersten Zehntel (Kauf) oder obersten Zehntel (Verkauf) der letzten ${mkBerName()} – nur mit Daten bis zum jeweiligen Tag, so wie es damals sichtbar gewesen wäre. ${mkNachText(reg.nachrechnung)} `
  +`Die Dreiecke ▲▼ in den Charts sind ideale Punkte im Rückblick. „Belegt“ zählt, wie oft die Rendite nach Signalen über dem Zufall lag; bei vielen Tests ist etwa jeder zwanzigste zufällig belegt. Kein Anlagerat.</div>`); }

// ---------- Bewertung ----------
function mkBewertung(d){ const r=d.r||{}, P=mkS(r.P), MV=mkS(r.MVRV), btc=MK.coin==='BTC', bRp=mkSig(d,'rp'), bDe=mkSig(d,'delta');
 const nupl=mkMap(MV,v=>1-1/v);
 const marken=[]; (d.extreme||[]).forEach(e=>{ marken.push({tag:e.max_tag, y:e.max, c:MK_F[1], lab:mkZ(e.max,2), t:`Epochen-Hoch ${mkZ(e.max,2)} am ${mkDatum(e.max_tag)}${e.laufend?' (laufende Epoche, bisher)':''}`});
  marken.push({tag:e.min_tag, y:e.min, c:MK_F[0], lab:mkZ(e.min,2), t:`Epochen-Tief ${mkZ(e.min,2)} am ${mkDatum(e.min_tag)}${e.laufend?' (bisher)':''}`}); });
 let letzt_=-99; const div=(d.divergenz||[]).filter(x=>{ if(x.tag-letzt_<14) return false; letzt_=x.tag; return true; })
  .map(x=>({tag:x.tag, y:x.mvrv, c:MK_F[4], form:'dreieck', t:`${mkDatum(x.tag)}: neues Kurshoch, MVRV ${mkZ(x.unter*100,0)} % unter dem Epochen-Hoch (Hypothese, ungetestet)`}));
 return [
  mkText(`<div class="sub" style="margin:4px 0 8px">Realized Price = Wert aller Münzen zum Preis ihrer letzten Bewegung je Münze (Coin Metrics: Marktkapitalisierung ÷ MVRV ÷ Angebot). MVRV = Kurs ÷ Realized Price; NUPL = 1 − 1/MVRV. ${btc?'':`<b>${esc(MK.coin)}</b>: gleiche Rechnung mit den Daten dieses Coins.`}</div>`),
  mkSigUebersicht(d),
  mkFig(mkSigHaupt({titel:`Kurs und Realized Price ${btc?'BTC':esc(MK.coin)}`, unter:'log. Skala', h:260, log:true,
   reihen:[{n:'Kurs', s:P, c:MK_KURS, w:1.4}, {n:'Realized Price', s:mkS(r.RP), c:MK_FARBE.RP, ende:true}, ...(btc?[{n:'Delta Price', s:mkS(r.DELTA), c:MK_FARBE.DELTA, d:'4,3', ende:true}]:[])],
   vlinien:btc?mkHalvingLinien(d):[], quelle:mkQ(d,'cm')}, bRp, P)),
  mkSigFig(d,bRp), mkSigText(d,bRp), mkSigFig(d,bDe), mkSigText(d,bDe),
  mkFig({titel:'MVRV', unter:btc?'Punkte: Hoch und Tief je Halving-Epoche (Amplitude schrumpft) · Dreiecke: neues Kurshoch ohne neues Bewertungshoch':'', h:230, log:true, fmt:mkX(2), y0:1, kurs:P, kursName:'Kurs '+MK.coin,
   reihen:[{n:'MVRV', s:MV, c:MK_F[0]}, {n:'NUPL', s:nupl, c:MK_F[0], nurTip:true, fmt:mkX(3)}], linien:[{y:1, t:'1 = Kurs auf Realized Price'}], marken:btc?marken.concat(div):[], quelle:mkQ(d,'cm')}),
  mkFig({titel:'MVRV als Perzentil der eigenen Historie', unter:'kausal · 0 tiefster, 100 höchster Wert bis zu diesem Tag', h:190, fmt:v=>mkZ(v,0), ymin:0, ymax:100, kurs:P, kursName:'Kurs '+MK.coin,
   reihen:[{n:'seit Beginn', s:mkS(r.PZ), c:MK_F[0]}, {n:'letzte 4 Jahre', s:mkS(r.PZ4), c:MK_F[1], d:'5,3'}], linien:[{y:50, t:'Median'}], quelle:mkQ(d,'cm')}),
  mkFig({titel:'MVRV-Z (expandierendes σ)', unter:'(Marktkap. − realisierte Kap.) ÷ Streuung der Marktkap. bis zu diesem Tag', h:190, fmt:mkX(2), kurs:P, kursName:'Kurs '+MK.coin,
   reihen:[{n:'MVRV-Z', s:mkS(r.Z), c:MK_F[2]}], linien:[{y:0}], quelle:mkQ(d,'cm')})]; }

// ---------- Trend ----------
function mkTrend(d){ const r=d.r||{}, P=mkS(r.P), fit=d.fit||{}, w=d.w||{}, bPl=mkSig(d,'pl'), bWm=mkSig(d,'wma');
 const fvf=t=>Math.pow(10,fit.a+fit.b*Math.log10(t-14247));
 const fv=P&&fit.b?{t0:P.t0, v:P.v.map((_,i)=>fvf(P.t0+i))}:null;
 const band=q=>P&&fit.b?{t0:P.t0, v:P.v.map((_,i)=>fvf(P.t0+i)*Math.pow(10,fit[q]))}:null;
 const par=(d.parameter||[]).filter(p=>p.monat>='2014-01');
 const zyk=(d.zyklen||[]).map((z,i)=>({n:'Halving '+z.halving.slice(0,4), s:{t0:0, v:z.werte}, c:MK_F[i]||MK_KURS, w:i===(d.zyklen.length-1)?2.2:1.4, fmt:v=>mkZ(v,2)+'×', ende:z.halving.slice(0,4)}));
 const coinTxt=MK.coin==='BTC'?'BTC':esc(MK.coin);
 return [
  mkSigUebersicht(d),
  mkFig(mkSigHaupt({titel:'Power Law: Kurs, Fair Value und Residuenbänder', unter:`log. Skala · log10(Kurs) = ${mkZ(fit.a,3)} + ${mkZ(fit.b,3)} · log10(Tage seit Genesis), Anpassung über alle Tage`, h:290, log:true,
   reihen:[{band:[band('q5'),band('q95')], n:'5–95 % der Residuen', c:MK_FARBE.FV, o:0.08}, {band:[band('q25'),band('q75')], n:'25–75 %', c:MK_FARBE.FV, o:0.14},
    {n:'Kurs BTC', s:P, c:MK_KURS, w:1.4}, {n:'Fair Value', s:fv, c:MK_FARBE.FV, ende:true}], quelle:mkQ(d,'cm')}, bPl, P)),
  mkSigFig(d,bPl), mkSigText(d,bPl),
  mkFig({titel:'Power-Law-Residuum als Perzentil (kausal)', unter:'je Monat mit der Anpassung bis zum Vormonat · Lage in σ im Tooltip', h:190, fmt:v=>mkZ(v,0), ymin:0, ymax:100, kurs:P,
   reihen:[{n:'Perzentil', s:mkS(r.PZ), c:MK_FARBE.FV}, {n:'Lage in σ', s:mkS(r.SIG), c:MK_FARBE.FV, nurTip:true, fmt:v=>(v<0?'−':'+')+mkZ(Math.abs(v),2)+' σ'}],
   linien:[{y:50, t:'Median'}], quelle:mkQ(d,'cm')}),
  mkText(par.length?`<details class="mkdetails"><summary class="sub">Exponent über die Zeit (versioniert, Anpassung bis Monatsbeginn) — zuletzt b = ${mkZ(par[par.length-1].b,3)}</summary><div class="mkscroll"><table class="w"><tr><th>Anpassung bis</th><th class="n">Exponent b</th><th class="n">a</th><th class="n">σ (log10)</th><th class="n">Tage</th></tr>`
   +par.slice().reverse().map(p=>`<tr><td>${p.monat}</td><td class="n">${mkZ(p.b,3)}</td><td class="n">${mkZ(p.a,3)}</td><td class="n">${mkZ(p.sd,3)}</td><td class="n">${mkZ(p.n,0)}</td></tr>`).join('')+'</table></div></details>':''),
  mkFig(mkSigHaupt({titel:`200-Wochen-Durchschnitt ${coinTxt}`, unter:'log. Skala · 199 abgeschlossene Wochen (Sonntag UTC) plus laufender Kurs', h:240, log:true,
   reihen:[{n:'Kurs', s:mkS(w.P), c:MK_KURS, w:1.4}, {n:'200-Wochen-MA', s:mkS(w.WMA), c:MK_FARBE.WMA, ende:true}], quelle:mkQ(d,'cm')}, bWm, mkS(w.P))),
  mkSigFig(d,bWm), mkSigText(d,bWm),
  mkFig({titel:`Abstand zum 200-Wochen-MA ${coinTxt}`, unter:'Tiefs 2015–2026 lagen zwischen −34 % und +0,5 % (Zone, keine Linie)', h:180, fmt:v=>mkPct(v,0), kurs:mkS(w.P), kursName:'Kurs '+MK.coin,
   reihen:[{n:'Abstand', s:mkS(w.AB), c:MK_FARBE.WMA}, ...(w.ABPZ?[{n:'Perzentil', s:mkS(w.ABPZ), c:MK_FARBE.WMA, nurTip:true, fmt:v=>mkZ(v,0)}]:[])], linien:[{y:0}], quelle:mkQ(d,'cm')}),
  mkFig({titel:'Halving-Zyklen übereinander', unter:`Kurs ÷ Kurs am Halving-Tag, log. Skala · heute Tag ${d.halving_tag} · frühere Hochs nach 368, 525, 546, 534 Tagen (Zeitachse, kein Fahrplan)`, h:250, log:true, xTage:true, x0:0, x1:1460,
   fmt:v=>mkZ(v,v>=10?0:2)+'×', reihen:zyk, linien:[{y:1}], quelle:mkQ(d,'cm')})]; }

// ---------- Kohorten (BGeometrics, letzte 4 Jahre) ----------
function mkKohorten(d){ const r=d.r||{}, P=mkS(r.P), STH=mkS(r.STH), bSt=mkSig(d,'sth'), bTm=mkSig(d,'tmm'), bLt=mkSig(d,'lth');
 const zonen=[]; if(P&&STH){ let an=null; const q=mkKombi(P,STH,(p,s)=>p<s?1:0);
  if(q) q.v.forEach((v,i)=>{ const t=q.t0+i; if(v===1&&an==null) an=t; if(v!==1&&an!=null){ zonen.push({a:an,b:t-1,t:'Kurs unter der Kurzfrist-Kostenbasis'}); an=null; } }); if(an!=null) zonen.push({a:an, b:q.t0+q.v.length-1, t:'Kurs unter der Kurzfrist-Kostenbasis'}); }
 const q=mkQ(d,'bgm');
 return [
  mkText(`<div class="sub" style="margin:4px 0 8px">Kostenbasen der Kohorten aus UTXO-Daten (BGeometrics, frei: letzte 4 Jahre ohne die jüngsten 7 Tage – Echtzeit nur im Abo; 15 Abrufe am Tag). Kurzfristhalter = Münzen jünger als 155 Tage. Unter der Kurzfrist-Kostenbasis liegt der Großteil der neuen Käufer im Verlust (graue Flächen; laut Recherche 2026 ab Februar bis spätestens 23.09.).</div>`),
  mkSigUebersicht(d),
  mkFig(mkSigHaupt({titel:'Kurs und Kostenbasen der Halter', unter:'log. Skala · grau: Kurs unter der Kurzfrist-Kostenbasis', h:270, log:true, x0:mkErster(STH)!=null?mkErster(STH)-30:null,
   reihen:[{n:'Kurs BTC', s:P, c:MK_KURS, w:1.4}, {n:'Kurzfrist-Kostenbasis (STH)', s:STH, c:MK_FARBE.STH, ende:'STH'}, {n:'True Market Mean', s:mkS(r.TMM), c:MK_FARBE.TMM, ende:'TMM'},
    {n:'Langfrist-Kostenbasis (LTH)', s:mkS(r.LTH), c:MK_FARBE.LTH, ende:'LTH'}], zonen, quelle:q}, bSt, P)),
  mkSigFig(d,bSt), mkSigText(d,bSt), mkSigFig(d,bTm), mkSigText(d,bTm), mkSigFig(d,bLt), mkSigText(d,bLt),
  mkFig({titel:'STH-MVRV (Kurs ÷ Kurzfrist-Kostenbasis)', h:180, fmt:mkX(2), kurs:P, reihen:[{n:'STH-MVRV', s:mkS(r.STHMV), c:MK_FARBE.STH}, {n:'Perzentil (4 J)', s:mkS(r.STHMVPZ), c:MK_FARBE.STH, nurTip:true, fmt:v=>mkZ(v,0)}],
   linien:[{y:1, t:'1 = Kurs auf der Kostenbasis'}], quelle:q}),
  mkFig({titel:'aSOPR und LTH-SOPR (7-Tage-Mittel)', unter:'< 1: Münzen werden im Mittel mit Verlust bewegt', h:190, fmt:mkX(3), kurs:P,
   reihen:[{n:'aSOPR', s:mkSma(mkS(r.ASOPR),7,5), c:MK_F[0]}, {n:'LTH-SOPR', s:mkSma(mkS(r.LSOPR),7,5), c:MK_F[7]}], linien:[{y:1}], quelle:q}),
  mkFig({titel:'AVIV (aktive Bewertung)', unter:'z-Wert der eigenen Historie im Tooltip', h:180, fmt:mkX(3), kurs:P,
   reihen:[{n:'AVIV', s:mkS(r.AVIV), c:MK_F[4]}, {n:'z-Wert', s:mkS(r.AVIVZ), c:MK_F[4], nurTip:true, fmt:mkX(2)}], linien:[{y:1}], quelle:q}),
  mkFig({titel:'Realisierte Verluste (7-Tage-Mittel)', unter:'USD je Tag · Kapitulation zeigt sich als Spitze', h:180, fmt:mkUsd, kurs:P,
   reihen:[{n:'realisierte Verluste', s:mkSma(mkS(r.RLOSS),7,5), c:MK_F[7]}], quelle:q})]; }

// ---------- Miner ----------
function mkGeraetName(){ const g=(MK.geraete||[]).find(x=>x.id===MK.szen.geraet); return g?g.name.replace(/ \d.*$/,''):`${mkZ(MK.szen.jth,1)} J/TH`; }
function mkKosten(d, ME, EUR, jth, ct){ if(!ME) return null; const auf=1+(+MK.szen.aufschlag||0)/100;
 if(MK.szen.waehrung==='EUR'){ if(!EUR) return null; return mkKombi(ME,EUR,(e,fx)=>jth*ct/100*fx*e*auf); }
 return mkMap(ME,e=>jth*ct/100*e*auf); }
function mkSzenario(feld,wert){ if(feld==='geraet'){ const g=(MK.geraete||[]).find(x=>x.id===wert); MK.szen.geraet=wert; if(g) MK.szen.jth=g.jth; }
 else{ const v=parseFloat(String(wert).replace(',','.')); if(feld==='waehrung') MK.szen.waehrung=wert; else if(isFinite(v)&&v>=0) MK.szen[feld]=v; }
 mkMerken(); const k=MK.cache[MK.tab+'|BTC']; if(k) mkZeigen(k.d); }
function mkMiner(d){ MK.geraete=d.geraete||MK.geraete||[]; const r=d.r||{}, P=mkS(r.P), ME=mkS(r.ME), EUR=mkS(r.EURUSD), S=MK.szen, bMi=mkSig(d,'miner'), bPu=mkSig(d,'puell');
 const basis=mkKosten(d,ME,EUR,S.jth,S.ct), lo=mkKosten(d,ME,EUR,S.jth,Math.max(0.5,S.ct-2.5)), hi=mkKosten(d,ME,EUR,S.jth,S.ct+2.5), alt=mkKosten(d,ME,EUR,21.5,S.ct);
 const verh=mkKombi(P,basis,(p,k)=>p/k);
 const H30=mkS(r.H30), H60=mkS(r.H60), HR=mkS(r.HR), DIFF=mkS(r.DIFF);
 const echt=(d.episoden||[]).filter(e=>e.echt), flach=(d.episoden||[]).length-echt.length;
 const zonen=echt.map(e=>({a:e.von, b:e.bis, t:`Kapitulation: ${e.tage} Tage, Tiefe ${mkPct(e.tiefe,1)} (Rauschschwelle ${mkZ(e.schwelle*100,1)} %)`}));
 const marken=[]; echt.forEach(e=>{ if(e.erholt) marken.push({tag:e.erholt, y:mkWert(H30,e.erholt,3), c:MK_F[2], t:`Erholung ${mkDatum(e.erholt)} (SMA30 wieder über SMA60)`});
  if(e.signal) marken.push({tag:e.signal, y:mkWert(H30,e.signal,3), c:MK_F[1], form:'dreieck', t:`Kaufsignal nach Capriole ${mkDatum(e.signal)} (Kurs-SMA10 > SMA20)`}); });
 const ribbon=(d.ribbon||[]).map((n,i)=>({n:`SMA ${n}`, s:mkSma(DIFF,n), c:MK_RAMPE[i], w:1.2}));
 let breite=null; if(ribbon.length&&DIFF){ const v=DIFF.v.map((_,i)=>{ let a=Infinity,b=-Infinity; for(const rr of ribbon){ const x=rr.s.v[i]; if(x==null) return null; a=Math.min(a,x); b=Math.max(b,x); } return b/a-1; }); breite={t0:DIFF.t0, v}; }
 const geraete=(MK.geraete||[]).map(g=>`<option value="${g.id}"${g.id===S.geraet?' selected':''}>${esc(g.name)}</option>`).join('')+`<option value="frei"${S.geraet==='frei'?' selected':''}>eigener Wert</option>`;
 const kopf=`<div class="mkzeile mkszen"><span class="lbl">Szenario</span><select onchange="mkSzenario('geraet',this.value)">${geraete}</select>`
  +`<label class="lbl">J/TH <input type="number" step="0.5" min="1" value="${S.jth}" onchange="MK.szen.geraet='frei';mkSzenario('jth',this.value)"></label>`
  +`<label class="lbl">Strom ct/kWh <input type="number" step="0.5" min="0" value="${S.ct}" onchange="mkSzenario('ct',this.value)"></label>`
  +`<select onchange="mkSzenario('waehrung',this.value)"><option value="USD"${S.waehrung==='USD'?' selected':''}>US-Cent</option><option value="EUR"${S.waehrung==='EUR'?' selected':''}>Euro-Cent</option></select>`
  +`<label class="lbl">Aufschlag % <input type="number" step="5" min="0" value="${S.aufschlag||0}" onchange="mkSzenario('aufschlag',this.value)" title="sonstige Kosten (Kühlung, Betrieb, Abschreibung) als Aufschlag auf den Strom; 0 = nur Strom"></label></div>`
  +`<div class="sub" style="margin:2px 0 8px">Stromkosten je BTC = J/TH × Strompreis × erwartete Hashes je Block (Difficulty × 2³²) ÷ (Emission + Gebühren je Block). Ausgangsszenario des Nutzers: Antminer S21 XP (13,5 J/TH) bei 7,5 ct/kWh; Euro-Cent werden mit dem Tageskurs EUR/USD (FRED) umgerechnet. Szenario, keine Messung der tatsächlichen Kosten der Miner.</div>`;
 const kl=mkLetzt(basis), vl=mkLetzt(verh);
 const ohneEur=S.waehrung==='EUR'&&!EUR?`<div class="sub" style="color:#d29922;margin:0 0 8px">⚠ Euro-Cent braucht den Tageskurs EUR/USD (FRED DEXUSEU), der noch fehlt – FRED-Schlüssel siehe Tab „Daten“. Bis dahin rechnet nur US-Cent.</div>`:'';
 return [mkText(kopf+ohneEur+(kl?`<div class="mksatz">Stromkosten heute (${mkDatum(kl.tag)}): <b>${mkUsd(kl.v)} USD je BTC</b>${vl?` · Kurs ÷ Kosten ${mkZ(vl.v,2)}`:''} · ältere Flotte S19 XP: ${mkUsd((mkLetzt(alt)||{}).v)} USD</div>`:'')),
  mkSigUebersicht(d),
  mkFig(mkSigHaupt({titel:'Kurs und Stromkosten je BTC', unter:`log. Skala · Band: Strompreis ${mkZ(Math.max(0.5,S.ct-2.5),1)}–${mkZ(S.ct+2.5,1)} ct`, h:280, log:true,
   reihen:[{band:[lo,hi], n:`Strompreis ± 2,5 ct`, c:MK_FARBE.MINER, o:0.12}, {n:'Kurs BTC', s:P, c:MK_KURS, w:1.4}, {n:`${mkGeraetName()} (${mkZ(S.jth,1)} J/TH, ${mkZ(S.ct,1)} ct)`, s:basis, c:MK_FARBE.MINER, w:2, ende:'Szenario'},
    {n:'S19 XP (21,5 J/TH)', s:alt, c:MK_F[1], d:'5,4', ende:'S19 XP'}], vlinien:mkHalvingLinien(d), quelle:`${mkQ(d,'cm')} · ${mkQ(d,'bc')} · ${mkQ(d,'fred')}`}, bMi, P)),
  mkSigFig(d,bMi), mkSigText(d,bMi),
  mkFig({titel:'Kurs ÷ Stromkosten (Szenario)', unter:'1 = Kurs auf den Stromkosten des Szenarios', h:180, log:true, fmt:mkX(2), kurs:P, reihen:[{n:'Kurs ÷ Kosten', s:verh, c:MK_FARBE.MINER}], linien:[{y:1}], quelle:mkQ(d,'cm')}),
  mkFig(mkSigHaupt({titel:'Puell Multiple', unter:'Tagesemission in USD ÷ 365-Tage-Mittel · Perzentil innerhalb der Halving-Epoche im Tooltip', h:190, log:true, fmt:mkX(2), kurs:P,
   reihen:[{n:'Puell', s:mkS(r.PUELL), c:MK_F[3]}, {n:'Perzentil in der Epoche', s:mkS(r.PUELLPZ), c:MK_F[3], nurTip:true, fmt:v=>mkZ(v,0)}], linien:[{y:1}], vlinien:mkHalvingLinien(d), quelle:mkQ(d,'cm')}, bPu, mkS(r.PUELL))),
  mkSigFig(d,bPu), mkSigText(d,bPu),
  mkFig({titel:'Hash Ribbons', unter:`grau: Kapitulation (SMA30 unter SMA60, tiefer als die Rauschschwelle 3 σ/√60 der Tageshashrate) · Punkt: Erholung · Dreieck: Kaufsignal nach Capriole · ${flach} flache Kreuzungen im Rauschen ohne Fläche`, h:230, log:true, fmt:v=>mkZ(v/1e6,1)+' EH/s',
   tickFmt:v=>mkZ(v/1e6,0)+' EH', kurs:P, reihen:[{n:'Hashrate', s:HR, c:MK_MUTED, w:0.8, o:0.5, fmt:v=>mkZ(v/1e6,1)+' EH/s'}, {n:'SMA 30', s:H30, c:MK_F[0], fmt:v=>mkZ(v/1e6,1)+' EH/s'}, {n:'SMA 60', s:H60, c:MK_F[1], fmt:v=>mkZ(v/1e6,1)+' EH/s'}],
   zonen, marken, quelle:mkQ(d,'cm')}),
  mkFig({titel:'Difficulty Ribbon', unter:'gleitende Mittel der Difficulty über 9 bis 200 Tage (hell kurz, dunkel lang)', h:220, log:true, fmt:v=>mkZ(v/1e12,1)+' T', kurs:P, reihen:ribbon, quelle:mkQ(d,'bc')}),
  mkFig({titel:'Breite des Difficulty Ribbons', unter:'größtes ÷ kleinstes Mittel − 1 · eng = Miner unter Druck', h:160, fmt:v=>mkPct(v,1), kurs:P, reihen:[{n:'Breite', s:breite, c:MK_RAMPE[4]}], linien:[{y:0}], quelle:mkQ(d,'bc')})]; }

// ---------- Hebel und Stimmung ----------
// 23.50: Das Binance-Archiv (Open Interest ab 2020) lädt rückwärts, ein Tag je Takt -- solange es läuft, ein Hinweis unter dem Chart
function mkOiArchiv(a){ if(!a||a.fertig||!(a.lueckenhaft||a.offen)) return mkText('');
 const dS=s=>s?String(s).split('-').reverse().join('.'):'—';
 const ab=(a.abschnitte||[]).map(x=>`${dS(x.von)}–${dS(x.bis)}`).join(', ');
 return mkText(`<div class="sub" style="color:#d29922;margin:-2px 0 10px">Binance-Archiv lädt noch, jüngste Tage zuerst: ${mkZ(a.tage,0)} von ${mkZ(a.soll,0)} Tagen seit 01.09.2020 da`
  +`${ab?` (${a.n_abschnitte>4?'… ':''}${ab})`:''}${a.offen?` – es fehlen noch ${mkZ(a.offen,0)} Tage, bei einem Tag je ${a.takt_s||20} s etwa ${mkZ(a.eta_h,1)} h`:''}. `
  +`Bis dahin hat der Chart Lücken; das Perzentil in der Zonenkarte kommt erst mit der ganzen Historie.</div>`); }
// 23.68 (U158): CryptoQuant-Anteil der Perpetuals am BTC-Volumen aller Börsen mit der 95-%-Linie (Regel S5, vorab festgelegt;
// KONZEPT_Hebel.md 14) -- nur Anzeige, wirkt auf nichts
function mkCq(c, P){ if(!c||!c.t||!c.t.length) return mkText('<div class="sub mkcqleer" style="margin:2px 0 10px">Anteil der Perpetuals am BTC-Volumen aller Börsen (CryptoQuant, U158): noch keine Tage – den kostenlosen Schlüssel im Tab „Daten“ eintragen; der Hebel-Takt ruft dann einmal am Tag nach 01:00 UTC ab.</div>');
 return mkFig({titel:'Anteil der Perpetuals am BTC-Volumen, alle Börsen', unter:`Perps ÷ (Perps + Spot) in BTC je UTC-Tag · Linie 95 % = Regel S5 (vorab festgelegt, U158), an ${mkZ(c.ab95,0)} von ${mkZ(c.t.length,0)} Tagen erreicht · nur Anzeige`, h:180,
  fmt:v=>mkZ(v*100,1)+' %', kurs:P, reihen:[{n:'Anteil', s:mkSt(c.t,c.v), c:MK_F[5], maxAbstand:3}], linien:[{y:c.schwelle||0.95, skala:true, t:'95 %'}],
  quelle:'CryptoQuant (kostenloser Schlüssel, 30 Tage je Abruf)'}); }
function mkHebel(d){ const r=d.r||{}; const rsi=d.rsi?mkSt(d.rsi.t,d.rsi.v):null, P=mkS(r.P);
 return [
  mkFig({titel:'Funding Binance BTCUSDT', unter:'Tagessumme der Raten, auf ein Jahr hochgerechnet · Linie: 30-Tage-Mittel', h:200, fmt:v=>mkPp(v,1), kurs:P,
   reihen:[{n:'täglich', s:mkS(r.FUND), c:MK_MUTED, w:0.8, o:0.6}, {n:'30-Tage-Mittel', s:mkS(r.FUND30), c:MK_F[0], w:2}], linien:[{y:0}], quelle:mkQ(d,'bnc')}),
  mkFig({titel:'Open Interest ÷ Marktkapitalisierung', unter:'Binance BTCUSDT-Perp, Stand zu Tagesbeginn UTC · USD-Wert im Tooltip', h:180, fmt:v=>mkPp(v,2), kurs:P,
   reihen:[{n:'OI ÷ Marktkap.', s:mkS(r.OIMC), c:MK_F[1]}, {n:'Open Interest', s:mkS(r.OI), c:MK_F[1], nurTip:true, fmt:v=>mkUsd(v)+' USD'}], quelle:mkQ(d,'bnc')}),
  mkOiArchiv(d.oi_archiv),
  mkCq(d.cq_anteil, P),
  mkFig({titel:'DVOL — implizite Volatilität BTC (30 Tage)', h:180, fmt:v=>mkZ(v,1), kurs:P, reihen:[{n:'DVOL', s:mkS(r.DVOL), c:MK_F[6]}, {n:'Perzentil', s:mkS(r.DVOLPZ), c:MK_F[6], nurTip:true, fmt:v=>mkZ(v,0)}], quelle:mkQ(d,'drb')}),
  mkFig({titel:'Fear & Greed Index', unter:'kurzfristig gebaut (Volatilität und Momentum gegen 30/90 Tage) · Linie: 30-Tage-Mittel', h:190, fmt:v=>mkZ(v,0), ymin:0, ymax:100, kurs:P,
   reihen:[{n:'täglich', s:mkS(r.FNG), c:MK_MUTED, w:0.8, o:0.6}, {n:'30-Tage-Mittel', s:mkS(r.FNG30), c:MK_F[3], w:2}], linien:[{y:50}], quelle:mkQ(d,'fng')}),
  mkFig({titel:'Wochen-RSI (14)', unter:'Sonntagsschlüsse · 2025 höchstens ~70 statt > 90 wie 2013, 2017, Anfang 2021', h:170, fmt:v=>mkZ(v,0), ymin:0, ymax:100, kurs:P,
   reihen:[{n:'RSI', s:rsi, c:MK_F[2], maxAbstand:7}], linien:[{y:30},{y:70},{y:50}], quelle:mkQ(d,'cm')})]; }

// ---------- Kapitalfluss ----------
function mkFluss(d){ const r=d.r||{}, P=mkS(r.P);
 return [
  mkFig({titel:'Stablecoin-Angebot', unter:'alle an Währungen gebundenen Stablecoins in USD, log. Skala', h:200, log:true, kurs:P, reihen:[{n:'Stablecoins', s:mkS(r.STABLE), c:MK_F[2]}], quelle:mkQ(d,'llama')}),
  mkFig({titel:'Stablecoin Supply Ratio (BTC-Marktkap. ÷ Stablecoins)', unter:'niedrig = viel „trockenes Pulver“ relativ zu BTC · Perzentil im Tooltip', h:190, log:true, fmt:mkX(2), kurs:P,
   reihen:[{n:'SSR', s:mkS(r.SSR), c:MK_F[2]}, {n:'Perzentil', s:mkS(r.SSRPZ), c:MK_F[2], nurTip:true, fmt:v=>mkZ(v,0)}], quelle:`${mkQ(d,'llama')} · ${mkQ(d,'cm')}`}),
  mkFig({titel:'ETF-Nettoflüsse kumuliert', unter:'Mio USD seit Start (BTC 11.01.2024)', h:210, fmt:v=>mkUsd(v*1e6), kurs:P,
   reihen:[{n:'BTC-ETFs', s:mkS(r.ETFBK), c:MK_F[0], ende:'BTC'}, {n:'ETH-ETFs', s:mkS(r.ETFEK), c:MK_F[6], ende:'ETH'}], linien:[{y:0}], quelle:mkQ(d,'farside')}),
  mkFig({titel:'ETF-Nettoflüsse, Summe 30 Tage', h:180, fmt:v=>mkUsd(v*1e6), kurs:P,
   reihen:[{n:'BTC-ETFs', s:mkS(r.ETFB30), c:MK_F[0]}, {n:'ETH-ETFs', s:mkS(r.ETFE30), c:MK_F[6]}], linien:[{y:0}], quelle:mkQ(d,'farside')})]; }

// 23.127 (U316): Zielspanne der Fed im Chart „Leitzins“ -- Fläche zwischen Unter- und Obergrenze in der Farbe der Linie (dieselbe Größe,
// keine Statusfarbe), die Grenzen im Fadenkreuz und in der Tabelle; Punkte als Treppe aus hl_makro.fed_stand. Darüber der Satz zum Entscheid
// (vorläufig aus der Erklärung der Fed, bis FRED den Tag am Morgen danach führt) und der nächste Termin in Ortszeit.
function mkZielReihen(m){ const z=m.ziel; if(!z||!z.t||z.t.length<2) return [];
 return [{band:[mkSt(z.t,z.u),mkSt(z.t,z.o)], n:'Zielspanne der Fed', c:MK_F[0], o:0.16},
  {n:'Zielspanne der Fed, obere Grenze', s:mkSt(z.t,z.o), c:MK_F[0], nurTip:true, strikt:true, maxAbstand:8},
  {n:'Zielspanne der Fed, untere Grenze', s:mkSt(z.t,z.u), c:MK_F[0], nurTip:true, strikt:true, maxAbstand:8}]; }
function mkSpanne(u,o){ return mkZ(u,2)+'–'+mkZ(o,2)+' %'; }
// vorläufiger Entscheid: ein Zeichen am ersten gültigen Tag an der neuen Obergrenze (Dreieck auf/ab, Punkt bei „unverändert“) -- am rechten
// Rand wäre die neue Stufe sonst nur einen Tag breit; mit der Bestätigung durch FRED fällt das Zeichen weg
function mkFedMarke(f){ const v=f&&f.vorl; if(!v||v.wirksam==null||v.o==null) return [];
 return [{tag:v.wirksam, y:v.o, c:MK_F[0], form:v.aktion==='erhöht'?'dreieck':v.aktion==='gesenkt'?'dreieck_ab':null,
  t:`Fed-Entscheid ${mkDatum(v.tag)}: Zielspanne ${mkSpanne(v.u,v.o)}, vorläufig (gültig ab ${mkDatum(v.wirksam)})`}]; }
function mkFedText(f){ if(!f) return ''; const z=[], v=f.vorl, j=f.jetzt;
 if(v) z.push(`<b class="mkfedvorl">Fed-Entscheid ${mkDatum(v.tag)}: Zielspanne ${mkSpanne(v.u,v.o)}${v.aktion?' ('+esc(v.aktion)+(v.schritt?' um '+mkZ(v.schritt,2)+' Prozentpunkte':'')+')':''}</b>`
  +` – vorläufig aus der Erklärung der Fed (gelesen ${esc(mkTermin(v.ts))}), FRED bestätigt am Morgen danach`);
 else if(j) z.push(`Zielspanne der Fed ${mkSpanne(j.u,j.o)} seit ${mkDatum(j.seit)}`);
 if(f.naechster) z.push(`nächster Entscheid ${esc(mkTermin(f.naechster))}`);
 return z.join(' · '); }
// ---------- Makro ----------
function mkMakro(d){ const M=d.makro||{}, P=mkS((d.r||{}).P), teile=[mkText(`<div class="sub" style="margin:4px 0 8px">Makro als Kulisse, nicht als Zeitgeber: Für keine dieser Reihen fand die Recherche einen außerhalb der Stichprobe belegten Vorlauf vor BTC. Unter jeder Reihe die rollierende Korrelation ihrer Wochenänderung mit der BTC-Wochenrendite (M2: Monate). Das graue Band ±2/√n ist, was der Zufall allein liefert.</div>`)];
 const fmtE=(e)=>e==='%'?v=>mkPp(v,2):e==='Bio USD'?v=>mkZ(v,2)+' Bio':v=>mkZ(v,1);
 ['netliq','global','m2','realzins','dollar','hy','leitzins'].forEach(k=>{ const m=M[k]; if(!m) return;
  const s=mkSt(m.t,m.v), kk=mkSt(m.t,m.k), ab=m.monatlich?40:9;
  const band=m.band||0.28, bt=m.t&&m.t.length?{t:m.t, v:m.t.map(()=>band)}:null, bu=bt?{t:m.t, v:m.t.map(()=>-band)}:null;
  const x0m=mkErster(s);
  const zr=k==='leitzins'?mkZielReihen(m):[], ft=k==='leitzins'?mkFedText(m.fed):'';       // 23.127 (U316)
  teile.push(mkFig({titel:m.titel, unter:[esc(m.regime||''), ft].filter(Boolean).join(' · '), h:170, fmt:fmtE(m.einheit), x0:x0m, kurs:P,
   reihen:[...zr, {n:m.titel, s, c:MK_F[0], maxAbstand:ab}], marken:k==='leitzins'&&zr.length?mkFedMarke(m.fed):[],
   quelle:k==='hy'?mkQ(d,'fred_hy'):zr.length?mkQ(d,'fred')+' · '+mkQ(d,'fed'):mkQ(d,'fred')}));
  teile.push(mkFig({titel:`Korrelation mit BTC (${m.monatlich?'24 Monate':'52 Wochen'})`, h:110, fmt:mkX(2), ymin:-1, ymax:1, ticks:2, x0:x0m,
   reihen:[{band:[bu,bt], n:'Zufallsband', c:MK_MUTED, o:0.12}, {n:'Korrelation', s:kk, c:MK_F[1], maxAbstand:ab}], linien:[{y:0}]})); });
 if(teile.length===1) teile.push(mkText('<div class="sub">Noch keine Makrodaten (FRED wird zweimal am Tag abgerufen).</div>'));
 mkUsa(d, P).forEach(t=>teile.push(t));
 return teile; }
// 23.67 (U153): Arbeitsmarkt und Preise der USA (FRED; nur Anzeige, wirkt auf nichts). Je Chart eine Größe (nie zwei Einheiten in
// einem Feld), Kursleiste wie überall, darunter die Korrelation mit BTC. Lücken bleiben Lücken (Oktober 2025 nicht erhoben).
function mkTermin(ts){ if(!ts) return '—'; const d=new Date(ts*1000);
 return d.toLocaleDateString('de-DE',{weekday:'short', day:'2-digit', month:'2-digit'})+' '+d.toLocaleTimeString('de-DE',{hour:'2-digit', minute:'2-digit'})+' Uhr'; }
function mkUsaFmt(m){ const nk=m.nk==null?1:m.nk; return m.einheit==='%'?(m.null?v=>(v>0?'+':'')+mkPp(v,nk):v=>mkPp(v,nk)):m.einheit==='Tsd.'?(m.null?v=>(v>0?'+':v<0?'−':'')+mkZ(Math.abs(v),0)+' Tsd.':v=>mkZ(v,0)+' Tsd.'):v=>mkZ(v,1); }
function mkUsa(d,P){ const U=d.usa||{}, R=U.reihen||{}, keys=['alq','stellen','antraege','preise_jahr','preise_monat'].filter(k=>R[k]);
 if(!keys.length) return U.fehler?[mkText(`<div class="sub">USA: Arbeitsmarkt und Preise -- Rechnung gescheitert: ${esc(U.fehler)}</div>`)]:[];
 const V=U.vierzehn||[], LT=U.luecke_text||{};
 const out=[mkText(`<h3 class="mkh3" id="mkusa">USA: Arbeitsmarkt und Preise</h3><div class="sub" style="margin:4px 0 8px">Nur Anzeige, wirkt auf nichts. `
  +`Bewegt wird der Kurs an solchen Tagen von der Überraschung gegenüber der Erwartung; die Erwartungswerte gibt es frei nicht. `
  +`Alle Termine um 8:30 New York (hier in Ortszeit). <b>Termine der nächsten 14 Tage:</b> ${V.length?V.map(t=>{ const r_=(U.datentag_reihen||{})[t.name], z_=r_&&typeof dtKurz==='function'?dtKurz(U.datentage, r_):'';
   return `${esc(mkTermin(t.ts))} ${esc(t.name)}${z_?' — '+esc(z_):''}`; }).join(' · '):'keine bekannt'}</div>`)];
 keys.forEach(k=>{ const m=R[k];
  const reihen=(m.linien||[]).map((l,i)=>({n:l.n, s:mkSt(m.t,l.v), c:MK_F[i], maxAbstand:m.monatlich?40:9, strikt:true, ende:(m.linien.length>1&&l.kurz)?l.kurz:false}));
  const ersten=reihen.map(r=>mkErster(r.s)).filter(x=>x!=null), x0m=ersten.length?Math.min(...ersten):null;
  const nt=(m.termine||[]).filter(n=>(U.naechste||{})[n]).map(n=>`nächster Termin ${esc(n)}: ${esc(mkTermin(U.naechste[n]))}`).join(' · ');
  const lk=(m.luecken||[]).map(x=>{ const [j,mo]=x.split('-'); return `${['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'][+mo-1]} ${j}${LT[x]?' '+LT[x]:''}`; });
  const fuss=lk.length?`Lücke: ${esc(lk.join(', '))} -- nicht gefüllt; eine Rate über die Lücke fehlt`:'';
  out.push(mkFig({titel:m.titel, unter:[m.unter?esc(m.unter):'', nt].filter(Boolean).join(' · '), h:170, fmt:mkUsaFmt(m), x0:x0m, kurs:P, reihen,
   linien:m.null?[{y:0}]:[], quelle:mkQ(d,'fred_usa'), fuss}));
  if(m.k){ const kt=m.kt||m.t, kk=mkSt(kt,m.k), band=m.band||0.28, bt=kt&&kt.length?{t:kt, v:kt.map(()=>band)}:null, bu=bt?{t:kt, v:kt.map(()=>-band)}:null;
   out.push(mkFig({titel:`Korrelation mit BTC (${m.monatlich?'24 Monate':'52 Wochen'})`, unter:esc(m.regime||''), h:110, fmt:mkX(2), ymin:-1, ymax:1, ticks:2, x0:x0m,
    reihen:[{band:[bu,bt], n:'Zufallsband', c:MK_MUTED, o:0.12}, {n:'Korrelation', s:kk, c:MK_F[1], maxAbstand:m.monatlich?40:9}], linien:[{y:0}]})); } });
 return out; }

// ---------- 24 Monate (U279, 23.116): Hauptfächer, Linien zum Vergleich, Zeitachse, Vorwärtsbilanz ----------
// Alle Zahlen und Sätze kommen fertig von hl_langfrist.chart_stand (dieselbe Antwort wie Debug 156); hier wird nur gezeichnet.
// Farben: drei Töne der geprüften Reihe, die sich auch paarweise alle tragen (Prüfskript, dunkle Fläche, alle Paare: normal ΔE ≥ 19,8,
// Farbsehschwäche ≥ 8,4) -- Fächer blau (zwei Deckkräfte), Power Law grün (Fair Value durchgezogen, Mitte der Sicht „Trend“ gestrichelt),
// frühere Zyklen gelbbraun (drei Stricharten). Kurs, „Kurs bleibt“ und das Band des Ausblicks neutral. Violett neben Blau und Orange
// neben Gelbbraun fielen im Prüfskript durch (ΔE 9,8 und 10,6) und fehlen deshalb. Keine Statusfarben, keine zweite Achse; die Ränder
// des Fächers stehen im Fadenkreuz und in der Tabelle.
// 23.121 (U280 Teil 2b, KONZEPT_Langfrist.md 9.5): Prognosemärkte in der neutralen Farbe der Markt-Schicht (wie die Zeichen der Optionen; keine
// neue Farbe) -- Rauten mit der rohen Wahrscheinlichkeit, gepunktete Linie je Niveau; Zeichen der Fed über den Strichen der Zeitachse.
const MK_LF=[['6m','6 M',183],['1j','1 J',365],['2j','2 J',730],['4j','4 J',1460]];
function mkLfLeiste(){ return `<div class="mkzeile"><span class="lbl">Verlauf davor</span>${MK_LF.map(([k,n])=>`<button class="tog ${k===MK.lf?'on':'off'}" onclick="mkLfVor('${k}')">${n}</button>`).join('')}`
  +`<button id="mkschalt-lfpmm" class="tog ${MK.aus.lfpmm?'off':'on'}" style="margin-left:10px${MK.lfpmmDa?'':';display:none'}" aria-pressed="${MK.aus.lfpmm?'false':'true'}" onclick="mkLfPmmUm()" title="Märkte-Modell: die Mitte aus allen Prognosemärkten ein- und ausblenden (dasselbe wie der Eintrag in der Legende)">Märkte-Modell</button>`
  +`<span id="mkstand" class="sub" style="margin-left:auto"></span></div>`; }
// 23.128 (U322, PM27): der Knopf oben schaltet dieselbe Linie wie der Eintrag „Märkte-Modell“ in der Legende; die Wahl bleibt gemerkt
function mkLfPmmUm(){ if(MK.aus.lfpmm) delete MK.aus.lfpmm; else MK.aus.lfpmm=true; mkMerken();
 const b=$('mkschalt-lfpmm'); if(b){ b.className='tog '+(MK.aus.lfpmm?'off':'on'); b.setAttribute('aria-pressed',MK.aus.lfpmm?'false':'true'); }
 document.querySelectorAll('.mkleg [data-schalt="lfpmm"]').forEach(x=>{ x.classList.toggle('aus',!!MK.aus.lfpmm); x.setAttribute('aria-pressed',MK.aus.lfpmm?'false':'true'); });
 Object.keys(MK.specs).forEach(id=>{ if($(id)) mkZeichne(id); }); }
function mkLfVor(k){ MK.lf=k; mkMerken(); mkLeiste(); const c=MK.cache['langfrist|BTC']; if(c) mkZeigen(c.d); else mkLaden(false); }
function mkLfDatum(tag){ return mkDatum(tag).replace(/\.20(\d\d)$/,'.$1'); }
// Beschriftung der Zeitachse nach der Breite: so viele Monatsmarken, wie Platz haben (auf dem Handy Jahre)
function mkLfXt(x0,x1,pw){ const max=Math.max(2,Math.floor(pw/52)), mon=(x1-x0)/30.44, sprung=[1,2,3,6,12].find(s=>mon/s<=max)||24;
 const out=[], d0=new Date(x0*864e5); let j=d0.getUTCFullYear(), m=d0.getUTCMonth()+1; if(m>11){ m=0; j++; }
 while(true){ const t=Date.UTC(j,m,1)/864e5; if(t>x1) break; if((j*12+m)%sprung===0) out.push([t, sprung>=12?String(j):mkMonat(t)]); m++; if(m>11){ m=0; j++; } }
 return out; }
function mkLangfrist(d){ const T=d.texte||{}, o=d.stichtag, F=d.fan||{}, MI=d.mitte||{}, TE=d.termine||{}, hv=TE.halving||{}, H=d.horizonte||[], tab=d.tabelle||{};
 const vor=(MK_LF.find(b=>b[0]===MK.lf)||MK_LF[1])[2], S=v=>v&&v.length?{t0:o, v}:null, au=d.ausblick&&d.ausblick.ok?d.ausblick:null, strich=['','6,3','2,3'];
 const op=d.optionen||{}, opP=(op.ok&&op.punkte)||[], opU=v=>v!=null?mkUsd(v):'außerhalb', opB=(a,b)=>opU(a)+' – '+opU(b)+' USD';
 const pm=d.prognosemarkt||{}, pmL=(pm.ok&&pm.leitern)||[], pmZ=(pm.ok&&pm.spannen&&pm.spannen.zeichen)||[], pmM=(pm.ok&&pm.marken)||[], pmRand=(e,a,b)=>e.q[a]!=null?e.q[a]:e.q[b];
 // 23.128 (U322, PM25): Märkte-Modell -- die Zahlen kommen fertig aus hl_langfrist.pm_modell_stand (je Tag ab d0); hier wird nur zerlegt
 const pmm=d.pm_modell&&d.pm_modell.ok&&(d.pm_modell.mitte||[]).length?d.pm_modell:null;
 MK.lfpmmDa=!!pmm; { const tb=$('mkschalt-lfpmm'); if(tb) tb.style.display=pmm?'':'none'; }      // der Knopf oben nur, wenn es eine Linie gibt
 const pmmStueck=(a,b)=>({t0:a, v:pmm.mitte.slice(a-pmm.d0, b-pmm.d0+1)});
 const pmmTeile=!pmm?[]:pmm.ende_fest!=null&&pmm.ende_fest>=pmm.ende?[{s:pmmStueck(pmm.d0,pmm.ende), d:null}]
  :pmm.ende_fest!=null?[{s:pmmStueck(pmm.d0,pmm.ende_fest), d:null},{s:pmmStueck(pmm.ende_fest,pmm.ende), d:'6,4'}]:[{s:pmmStueck(pmm.d0,pmm.ende), d:'6,4'}];
 const pmmName='Märkte-Modell: die Mitte aus allen Prognosemärkten (je 50 % darüber und darunter) – Preise von Wetten, roh';
 const pmmReihen=pmmTeile.map((x,i)=>({n:pmmName, kurz:'Märkte-Modell', s:x.s, c:MK_PMM, w:1.8, d:x.d, schalt:'lfpmm', ohneTip:true, ohneTab:true,
  ohneLeg:i>0, ende:i===pmmTeile.length-1?'Märkte':false})).concat(pmm?[{n:'Märkte-Modell (Mitte)', s:pmmStueck(pmm.d0,pmm.ende), c:MK_PMM, nurTip:true, ohneTip:true, schalt:'lfpmm'}]:[]);
 const rand=(k,n)=>({n, s:S(F[k]), c:MK_F[0], nurTip:true});
 const reihen=[rand('90','90-%-Rand'), rand('75','75-%-Rand'), rand('50','Mitte des Fächers'), rand('25','25-%-Rand'), rand('10','10-%-Rand'),
  {n:'80-%-Band des Fächers', kurz:'80 %', band:[S(F['10']),S(F['90'])], c:MK_F[0], o:0.17, lo:0.3},
  {n:'50-%-Band des Fächers', kurz:'50 %', band:[S(F['25']),S(F['75'])], c:MK_F[0], o:0.2, lo:0.62},
  ...(au?[{n:'Ausblick, erste 4 Wochen (80 %)', kurz:'Ausblick 4 Wochen', band:[mkSt(au.t,au.q['10']),mkSt(au.t,au.q['90'])], c:MK_KURS, o:0.3, lo:0.45}]:[]),
  {n:'Kurs BTC', kurz:'Kurs', s:mkS(d.kurs_reihe), c:MK_KURS, w:1.5},
  {n:'Mitte „ohne Richtung“ (Kurs bleibt)', kurz:'Kurs bleibt', s:S(MI.A), c:MK_KURS, w:1.2, d:'3,4'},
  {n:'Mitte „Trend“', kurz:'Trend', s:S(MI.B), c:MK_FARBE.FV, w:1.7, d:'7,3', ende:'Trend'},
  {n:'Fair Value (Power Law)', kurz:'Fair Value', s:mkS(d.fv), c:MK_FARBE.FV, w:1.2, ende:'Fair Value'},
  ...(d.zyklen||[]).map((z,i)=>({n:'wie nach dem Halving '+z.jahr, kurz:'wie '+z.jahr, s:mkSt(z.t,z.v), c:MK_F[3], w:1.1, d:strich[i%3], o:0.8, maxAbstand:7, ende:'wie '+z.jahr, schalt:'lfz'+String(z.jahr).replace(/[^0-9]/g,'')})),
  ...(opP.length?[{n:'Optionen (Deribit): Ränder je Verfalltag, risikoneutral', kurz:'Optionen', c:MK_KURS, schalt:'lfopt', fang:6,
    spannen:opP.map(pk=>({tag:pk.tag, lo:pk.q10!=null?pk.q10:pk.q25, hi:pk.q90!=null?pk.q90:pk.q75, q1:pk.q25, q3:pk.q75, m:pk.q50, t:'Optionen, Verfall '+mkDatum(pk.tag),
     zeilen:[['Optionen '+mkDatum(pk.tag)+': Mitte',opU(pk.q50)+' USD'],['Optionen 10 bis 90 %',opB(pk.q10,pk.q90)],['Optionen 25 bis 75 %',opB(pk.q25,pk.q75)],['Optionen: Terminkurs',opU(pk.termin)+' USD']]}))}]:[]),
  ...(pmL.length||pmZ.length?[{n:'Prognosemärkte (Kalshi, Polymarket): wie wahrscheinlich der Kurs das Niveau bis zur Frist erreicht – Preise von Wetten, roh', kurz:'Prognosemärkte', c:MK_KURS, schalt:'lfpm', fang:6,
    leitern:pmL.map(l=>({niveau:l.niveau, punkte:l.punkte.map(q=>({tag:q.tag, lab:q.lab, zeilen:q.zeilen, t:q.zeilen&&q.zeilen[0]?q.zeilen[0][0]+': '+q.zeilen[0][1]:''}))})),
    spannen:pmZ.map(e=>({tag:e.tag, lo:pmRand(e,'10','25'), hi:pmRand(e,'90','75'), q1:e.q['25'], q3:e.q['75'], m:e.q['50'], raute:true, zeilen:e.zeilen, t:e.zeilen&&e.zeilen[0]?e.zeilen[0][0]+': '+e.zeilen[0][1]:''}))}]:[]),
  ...pmmReihen];
 const vl=[{tag:o, t:'Stichtag', links:true, halo:true}];
 if(hv.ok) vl.push({tag:Math.round((hv.von+hv.bis)/2), t:'Halving', links:true, halo:true}); else if(hv.nominal) vl.push({tag:hv.nominal, t:'Halving', links:true, halo:true});
 if(TE.wahl) vl.push({tag:TE.wahl, t:'US-Wahl', links:true, halo:true, dy:13});
 const fed=TE.fed||[];
 const sp={titel:'BTC in USD: Fächer über 24 Monate', unter:'log. Skala · Szenarien, keine geprüfte Prognose', h:320, log:true, legendeImmer:true,
  xFest:[o-vor, o+H[H.length-1]], xTicks:mkLfXt, endenMax:6, reihen, vlinien:vl,
  xmarken:fed.map(t=>{ const m=pmM.find(x=>x.tag===t); return m?{tag:t, form:m.richtung, schalt:'lfpm', t:'Fed-Entscheid '+mkDatum(t)+' – der Markt (Kalshi): '+m.name}:{tag:t}; }),
  zonen:hv.ok?[{a:hv.von, b:hv.bis, o:0.22, t:'Halving voraussichtlich '+mkDatum(hv.von)+' bis '+mkDatum(hv.bis)}]:[],
  tipExtra:(tag,tpp)=>{ const z=[], nah=Math.max(2,4*(tpp||0)); if(tag>o) z.push(['Tage ab dem Stichtag', mkZ(tag-o,0)]);   // 23.121: Termine im Umkreis von 2 Tagen, mindestens 4 px
   let f=null; fed.forEach(t=>{ if(Math.abs(t-tag)<=nah&&(f==null||Math.abs(t-tag)<Math.abs(f-tag))) f=t; });
   if(f!=null){ z.push(['Fed-Entscheid', mkDatum(f)]); const m=pmM.find(x=>x.tag===f);
    if(m&&!MK.aus.lfpm) (m.zeilen||[]).forEach(r=>z.push([esc(r[0]), esc(r[1])])); }
   if(TE.wahl&&Math.abs(TE.wahl-tag)<=nah) z.push(['US-Wahl', mkDatum(TE.wahl)]);
   if(pmm&&!MK.aus.lfpmm&&tag>=pmm.d0&&tag<=pmm.ende){ const i=tag-pmm.d0, nurB=pmm.ende_fest==null||tag>pmm.ende_fest,   // 23.128 (U322, PM27)
     strich=`<span style="display:inline-block;width:12px;height:2px;background:${MK_PMM};vertical-align:middle;margin-right:5px"></span>`;
    z.push([strich+'Märkte-Modell: Mitte'+(nurB?' (nur aus Berührungen)':''), mkUsd(pmm.mitte[i])+' USD']);
    z.push([strich+'Märkte-Modell: 25 bis 75 %', mkUsd(pmm.q25[i])+' – '+mkUsd(pmm.q75[i])+' USD']);
    if(pmm.rekal_reihe) z.push([strich+'Märkte-Modell: rekalibriert', mkUsd(pmm.rekal_reihe[i])+' USD']); }
   return z; },
  fuss:'Fächer: bis '+H[0]+' Tage wächst die Breite mit der Wurzel der Zeit, danach sind die Stützstellen ('+H.join(', ')+' Tage) gerade verbunden · frühere Zyklen: ein Wert je Woche – ein Tipp auf „wie …“ in der Legende blendet die Linie aus und wieder ein · Optionen je Verfalltag: Strich 10 bis 90 %, Balken 25 bis 75 %, Punkt = Mitte (ebenso schaltbar) · Rauten: Prognosemärkte – wie wahrscheinlich der Kurs das Niveau bis zu diesem Tag erreicht (roh; gepunktete Linie = ein Niveau, mehrere Fristen; ebenso schaltbar) · kleine Striche unten: Fed-Entscheide; ein Zeichen darüber, wo der Markt eng ist: ▲ Erhöhung, ▬ keine Änderung, ▼ Senkung, ◇ offen · Linie „Märkte“: das Märkte-Modell – die Mitte aus allen Prognosemärkten, durchgezogen, solange Märkte den Kurs am Tag nennen, danach gestrichelt (nur aus Berührungen); schaltbar in der Legende und oben', quelle:'Coin Metrics (Kurs, Tagesschluss UTC); eigene Rechnung'};
 const zs='style="padding:4px 4px;font-size:11.5px"';
 const zeile=(name,f)=>`<tr><td ${zs}>${name}</td>${H.map(x=>`<td class="n" ${zs}>${f(tab[x]||{q:[]})}</td>`).join('')}</tr>`;
 const tabelle=`<h3 class="mkh3">Der Fächer an den Stützstellen (USD)</h3><div class="mkscroll"><table class="w mklf"><tr><th ${zs}>Tage</th>${H.map(x=>`<th class="n" ${zs}>${x}</th>`).join('')}</tr>`
  +zeile('Zieltag',e=>mkLfDatum(e.ziel))+zeile('90 %',e=>mkUsd(e.q[4]))+zeile('75 %',e=>mkUsd(e.q[3]))+zeile('<b>Mitte</b>',e=>'<b>'+mkUsd(e.q[2])+'</b>')
  +zeile('25 %',e=>mkUsd(e.q[1]))+zeile('10 %',e=>mkUsd(e.q[0]))
  +zeile('<span class="sub">Trend</span>',e=>mkUsd(e.B))+zeile('<span class="sub">Kurs bleibt</span>',e=>mkUsd(e.A))+zeile('<span class="sub">Fair Value</span>',e=>mkUsd(e.fv))
  +zeile('<span class="sub" title="Mitte aus allen Prognosemärkten; „—“: keine Frist reicht so weit">Märkte-Modell</span>',e=>e.pm!=null?mkUsd(e.pm):'—')
  +(d.zyklen||[]).map((z,i)=>zeile('<span class="sub">wie '+z.jahr+'</span>',e=>mkUsd((e.zyklen||[])[i]))).join('')+'</table></div>';
 const satz=t=>t?`<div class="sub mklfsatz" style="margin:6px 0">${esc(t).replace(/ -- /g,' – ')}</div>`:'';
 const fl=(T.fassungen||[]).concat(T.bilanz_zeilen||[]);
 const fass=fl.length?`<details class="mkdetails"><summary class="sub">Gespeicherte Fassungen und Zwischenbilanz (${(d.fassungen||[]).length})</summary>${fl.map(satz).join('')}</details>`:'';
 return [mkText(`<div class="mksatz mklfkopf" style="margin:6px 0 2px"><b>${esc(T.titel||'')}.</b> ${esc(T.kopf||'').replace(/ -- /g,' – ')}</div>`),
  mkFig(sp),
  mkText(tabelle+satz(T.rueckblick)+satz(T.zyklen)+satz(T.ausblick)+satz(T.optionen)+satz(T.prognosemarkt)+satz(T.pm_vergleich)+satz(T.pm_spannen)+satz(T.pm_modell)+satz(T.fed)+satz(T.termine)+satz(T.bilanz)+fass+satz(T.stand)+satz(T.fehlt)
   +`<div class="sub" style="margin:6px 0 12px">Dieselben Zahlen als Text: Debug ${esc(String(d.debug))} · die Vorprüfung dazu: Debug ${esc(String(d.debug_urteil))}.</div>`)]; }

// ---------- Daten ----------
function mkDaten(d){ const D=d.daten||{}; if(D.fehlt) return [mkText('<div class="sub">makro.db fehlt noch.</div>')];
 const zeit=t=>t?new Date(t*1000).toLocaleString('de-DE',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'nie';
 const jetztS=Date.now()/1000;
 const ziele=(D.ziele||[]).map(z=>`<tr><td>${esc(z.quelle)}</td><td>${esc(z.ziel)}</td><td>${zeit(z.ok)}</td><td>${z.voll?'ja':'—'}</td></tr>`
  +(z.fehler?`<tr><td colspan="4" style="white-space:normal;color:#d29922;padding-top:0;font-size:11px;line-height:1.35">⚠ ${esc(z.fehler)}${z.pause>jetztS?` · nächster Versuch ${esc(zeit(z.pause).split(', ').pop())}`:''}</td></tr>`:'')).join('');
 const f=D.fred||{}, fz=f.ziele||12, fok=f.ok||0;
 const fred=f.schluessel
  ?`<div class="sub">FRED: offizielle API mit Schlüssel (${f.umgebung?'Umgebungsvariable FRED_API_KEY':'accesstokens.json'}) · ${fok} von ${fz} Reihen abgerufen${f.haengt?` · ${f.haengt} ohne Antwort`:''}</div>`
  :`<div class="sub" style="white-space:normal;color:${fok<fz?'#d29922':'inherit'}">${fok<fz?'⚠ ':''}FRED ohne Schlüssel (fredgraph.csv): ${fok} von ${fz} Reihen abgerufen${f.haengt?`, ${f.haengt} ohne Antwort`:''}. fredgraph.csv antwortet seit Mitte August 2026 vielerorts nicht (nicht nur hier). Abhilfe: kostenlosen Schlüssel holen (<a href="${esc(f.seite||'')}" target="_blank" rel="noopener">${esc(f.seite||'')}</a>) und hier eintragen.</div>`;
 const fredForm=(!f.schluessel||fok<fz)?`<div class="mkzeile mkfred"><input id="mkfredkey" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="40" placeholder="FRED-Schlüssel (32 Zeichen)" aria-label="FRED-Schlüssel">`
  +`<button class="tog" onclick="mkFredSchluessel()">prüfen und speichern</button><span id="mkfredaus" class="sub"></span></div>`:'';
 // 23.68 (U158): CryptoQuant-Schlüssel neben dem FRED-Schlüssel -- der Schlüssel steht nie in der Antwort
 const q=D.cq||{}, qZeit=t=>t?new Date(t*1000).toLocaleString('de-DE',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
 const cqZeile=q.schluessel
  ?`<div class="sub mkcq" style="white-space:normal">CryptoQuant (U158, Anteil der Perps am BTC-Volumen): Schlüssel aus ${esc(q.herkunft||'')} · ${q.tage?`${mkZ(q.tage,0)} Tage (${mkDatum(q.von)} bis ${mkDatum(q.bis)}), zuletzt ${mkZ((q.letzter||0)*100,1)} %`:'noch keine Tage'}${q.ok_ts?` · letzter Abruf ${esc(qZeit(q.ok_ts))}`:''}${q.fehler?`<br><span style="color:#d29922">⚠ ${esc(q.fehler)}${q.pause_bis>jetztS?` · nächster Versuch ${esc(qZeit(q.pause_bis).split(', ').pop())}`:''}</span>`:''}</div>`
  :`<div class="sub mkcq" style="white-space:normal">CryptoQuant (U158): ohne Schlüssel kein Abruf. Den kostenlosen Schlüssel (Stufe Basic, <a href="${esc(q.seite||'https://cryptoquant.com/apis')}" target="_blank" rel="noopener">${esc(q.seite||'https://cryptoquant.com/apis')}</a>) hier eintragen; dann einmal am Tag nach 01:00 UTC je 30 Tage Spot und Perpetual.</div>`;
 const cqForm=(!q.schluessel||q.fehler)?`<div class="mkzeile mkcqform"><input id="mkcqkey" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="256" placeholder="CryptoQuant-Schlüssel (kostenlos)" aria-label="CryptoQuant-Schlüssel (kostenlos)">`
  +`<button class="tog" onclick="mkCqSchluessel()">prüfen und speichern</button><span id="mkcqaus" class="sub"></span></div>`:'';
 const reihen=(D.reihen||[]).map(r=>`<tr><td class="mono">${esc(r.reihe)}</td>`
  +`<td class="n" style="color:${r.alt?'#d29922':'inherit'}">${r.alter!=null?(r.alt?'⚠ ':'')+mkZ(r.alter,0)+' T':''}</td><td class="n">${r.grenze!=null?mkZ(r.grenze,0)+' T':'—'}</td>`
  +`<td class="n">${mkZ(r.n,0)}</td><td>${esc(r.von)}</td><td>${esc(r.bis)}</td></tr>`).join('');
 const b=D.bgm||{}, a=D.archiv||{}, st=D.stand||{}, za=D.zu_alt||[], fe=D.fehlen||[];
 const liste=xs=>esc(xs.slice(0,12).join(', '))+(xs.length>12?` … (+${xs.length-12})`:'');
 const frisch=(za.length||fe.length)
  ?`<div class="sub" style="color:#d29922">⚠ ${za.length?`Zu alt (${za.length}): ${liste(za)}`:''}${za.length&&fe.length?' · ':''}${fe.length?`Fehlt nach erfolgreichem Abruf (${fe.length}): ${liste(fe)} · Metrik oder Feld verschwunden?`:''}</div>`
  :`<div class="sub">Frische: alle ${(D.reihen||[]).length} Reihen innerhalb ihrer Grenze, keine erwartete Reihe fehlt.</div>`;
 return [mkText(`<div class="mksatz">makro.db ${mkZ(D.groesse_mb,1)} MB · Datenversion ${esc(D.version||'—')} · Archiv der Tagesstände: ${st.tage||0} Tage${st.tage?` (${esc(st.von)} bis ${esc(st.bis)})`:''}</div>`+frisch+fred+fredForm+cqZeile+cqForm
  +`<div class="sub">BGeometrics heute ${b.tag||0}/${b.je_tag||14}, letzte Stunde ${b.stunde||0}/${b.je_stunde||7} (frei: 15 am Tag, 8 je Stunde; Werte enden ${D.bgm_verzug||7} Tage vor heute, Echtzeit nur im Abo) · Binance-OI-Archiv ${a.fertig?'vollständig':'läuft rückwärts, jüngste Tage zuerst (bei '+esc(String(a.cursor||'—').split('-').reverse().join('.'))+')'}${a.abdeckung?`: ${mkZ(a.abdeckung.tage,0)} von ${mkZ(a.abdeckung.soll,0)} Tagen seit 01.09.2020${!a.fertig&&a.abdeckung.offen?`, noch ${mkZ(a.abdeckung.offen,0)} (etwa ${mkZ(a.abdeckung.eta_h,1)} h)`:''}`:''}, ${a.fehlend||0} fehlend (404)${a.fehler?' · '+esc(a.fehler):''}${D.gegenprobe_hr!=null?` · Hashrate Coin Metrics ÷ Blockchain.com ${mkZ(D.gegenprobe_hr,3)}`:''}</div>`
  +`<h3 class="mkh3">Abrufe je Quelle (Zeit lokal)</h3><div class="mkscroll"><table class="w"><tr><th>Quelle</th><th>Ziel</th><th>letzter Erfolg</th><th>Historie</th></tr>${ziele}</table></div>`
  +`<h3 class="mkh3">Reihen in makro.db</h3><div class="mkscroll"><table class="w"><tr><th>Reihe</th><th class="n">Alter</th><th class="n">Grenze</th><th class="n">Tage</th><th>von</th><th>bis</th></tr>${reihen}</table></div>`
  +`<div class="sub" style="margin-top:8px">Lizenzen: Coin Metrics CC BY-NC 4.0 (Namensnennung, nicht kommerziell) · alternative.me: Quellenangabe neben dem Chart · ICE-Daten (Hochzinsspread) nicht weitergeben · Farside und BGeometrics nur privat.</div>`)]; }

async function mkFredSchluessel(){ const el=$('mkfredkey'), aus=$('mkfredaus'); if(!el||!aus) return; const k=(el.value||'').trim().toLowerCase();
 if(!/^[a-z0-9]{32}$/.test(k)){ aus.textContent='⚠ Der Schlüssel hat 32 Zeichen (a–z, 0–9).'; return; }
 aus.textContent='prüfe bei FRED …';
 try{ const r=await fetch('/makro/fred_schluessel',{method:'POST',headers:{'X-HL-Request':'1','Content-Type':'application/json'},body:JSON.stringify({schluessel:k})});
  const j=await r.json(); aus.textContent=(j.ok?'✓ ':'⚠ ')+(j.meldung||j.error||''); if(j.ok) el.value=''; }
 catch(e){ aus.textContent='⚠ '+e; } }

async function mkCqSchluessel(){ const el=$('mkcqkey'), aus=$('mkcqaus'); if(!el||!aus) return; const k=(el.value||'').trim();
 if(!/^[A-Za-z0-9._~+\/=-]{16,256}$/.test(k)){ aus.textContent='⚠ Der Schlüssel hat 16 bis 256 Zeichen ohne Leerzeichen.'; return; }
 aus.textContent='prüfe bei CryptoQuant …';
 try{ const r=await fetch('/makro/cq_schluessel',{method:'POST',headers:{'X-HL-Request':'1','Content-Type':'application/json'},body:JSON.stringify({schluessel:k})});
  const j=await r.json(); aus.textContent=(j.ok?'✓ ':'⚠ ')+(j.meldung||j.error||''); if(j.ok) el.value=''; }
 catch(e){ aus.textContent='⚠ '+e; } }

// ---------- Start ----------
function mkStart(){ if(!$('sec-makro')) return; mkLeiste(); mkLaden(false);
 setInterval(()=>{ if(mkOffen()) mkLaden(false); }, 120000);
 let rz=null; addEventListener('resize',()=>{ clearTimeout(rz); rz=setTimeout(()=>{ if(mkOffen()) Object.keys(MK.specs).forEach(id=>{ if($(id)) mkZeichne(id); }); },250); }); }
mkStart();
"""
