#!/usr/bin/env python3
"""
Extrem-Wende (U226, KONZEPT_Wende.md; Version 2026-09-23.83): die Strategie aus dem Video „Range Deviation plus Ribbon Flip“
(BTC, 8-h-Kerzen) nachgebaut -- Studie auf der Historie und dieselben Funktionen für das TradeLabor.

Regeln (KONZEPT 1–2): 8-h-Kerzen (UTC 00/08/16) aus den 30-min-Kerzen der Binance-USDT-Perpetuals in swing.db. Rot = Hoch unter den
höchsten 10 % des Fensters der 765 Kerzen bis zur Flip-Kerze, blau = Tief unter den tiefsten 10 % (Lesart A Rang oder B Spanne).
Flip = EMA 8 kreuzt EMA 89 (Schlüsse; Wechsel der Lage). Short: seit dem letzten bullischen Flip mindestens eine rote Kerze, dann
bärischer Flip -> Einstieg zum Schluss, Stop 0,1 % über dem höchsten Hoch der roten Kerzen; Long gespiegelt. Hauptregel: Ziel 1R
(Limit), Stop (Markt), höchstens 120 Tage. Urteil (KONZEPT 3, beim Bau geändert und kalibriert): H1 Treffer gegen dieselben Trades,
gemeinsam verschoben, mit dem Stop-Abstand nach der Schwankung skaliert; H2 Gewinn nach Kosten mit Gruppen überlappender Trades;
beide Hälften; mindestens 30 Trades in 20 Gruppen; Datenende fest am Stichtag 27.10.2026.

Liest nur (swing.db); schreibt nichts. Berührt weder hl_liq.db noch Fusion, v3, Kaskaden oder die übrigen Labor-Strategien.

  python3 hl_wende.py --studie --db <hl_liq.db>   Debug „★ Wende: Extrem-Wende nach Video (BTC 8 h, U226)“
  python3 hl_wende.py --stand --db <hl_liq.db>    nur der Stand jetzt (schnell)
  python3 hl_wende.py --selbsttest                Proben ohne Netz
  python3 hl_wende.py --kalibrieren N [--variante V] [--teil k/m]   Nullmärkte für H1 (KONZEPT 3.3), lange
"""
from __future__ import annotations

import argparse
import calendar
import hashlib
import math
import os
import sqlite3
import sys
import time

import numpy as np

import hl_regime as RG
import hl_swing as SW

VERSION_MODUL = "2026-09-23.83"
COIN = "BTC"
BAR = 1800
K8 = 8 * 3600
PRO_K8 = K8 // BAR                     # 16 Kerzen à 30 min
VOLL_MIN = 14
TAG = 86400
FENSTER = 765
ANTEIL = 0.10
EMA_KURZ = 8
EMA_LANG = 89
STOP_PUFFER = 0.001
ZIEL_R = 1.0
MAX_TAGE = 120
EIN_FENSTER_S = 3600
LESARTEN = ("rang", "spanne")
LESART_TXT = {"rang": "A (Rang)", "spanne": "B (Spanne)"}
ALPHA = 0.05                           # H2
ALPHA_H1 = 0.038                       # H1 (KONZEPT 3.8/3.9): Kalibrierung 25.10. -- Schranke 6,5 % verfehlt (Drift/Regime/Lesart B 6,8–8,8 %),
#                                        darum das 5-%-Quantil der Null-p ohne Drift (1.000 Märkte: 0,0387), abgerundet
MIN_TRADES = 30
MIN_GRUPPEN = 20
RISIKO_VIDEO = 0.02
STUFEN = (0.5, 1.0, 1.5, 2.0, 3.0, 5.0)
FAST_SOFORT_K = 6                      # „praktisch sofort ausgestoppt“: binnen 6 Kerzen (2 Tage) …
FAST_SOFORT_R = 0.5                    # … ohne je +0,5R erreicht zu haben
RV_KERZEN = 480                        # Schwankung beim Einstieg: 10 Tage 30-min-Renditen davor (KONZEPT 3.3)
RV_MIN = 240
A_MIN, A_MAX = 0.0005, 0.9             # Grenzen des skalierten Stop-Abstands verschobener Trades
LABOR_TAGE = 600                       # so viele Tage liest das Labor (765 Kerzen = 255 Tage, dazu der Vorlauf der EMA 89)
LABOR_RAND = 0.0005                    # Labor: Stop mindestens 5 bps vom Kurs und mindestens die Hälfte des Abstands am Schluss
FENSTER_EMPF = (500, 765, 1050)
FENSTER_PRUEF = 1050                   # Video: mit 1.050 Kerzen wäre das aktuelle Short-Signal keins gewesen
SLIP = SW.SLIP_BPS.get(COIN, SW.SLIP_STANDARD) / 1e4
GEB_TAKER = SW.GEB_TAKER
GEB_MAKER = SW.GEB_MAKER
GRUND = ("Ziel", "Stop", "Zeit", "Gegen-Flip", "offen")
VARIANTEN = (("ziel1", "Hauptregel: Ziel 1R"), ("ziel2", "Ziel 2R"), ("ziel3", "Ziel 3R"), ("laufen120", "bis zum Stop (höchstens 120 Tage)"),
             ("gegenflip", "Gegen-Flip (höchstens 120 Tage)"))
BAENDER = ((0.0, 0.05), (0.05, 0.10), (0.10, 0.15), (0.15, 0.25), (0.25, 9.9))

# Die Regeln für Historie und Labor (KONZEPT 2 und 5). Das Labor friert sie (mit der Lesart) in seiner Kennung ein; wende_v zählt
# Änderungen am Code, die Signale ändern (Goldprobe im Selbsttest) -- dann neue Kennung.
REGELN = {"art": "wende", "coin": COIN, "tf_s": K8, "fenster": FENSTER, "anteil": ANTEIL, "ema_kurz": EMA_KURZ, "ema_lang": EMA_LANG,
          "stop_puffer": STOP_PUFFER, "ziel_r": ZIEL_R, "max_tage": MAX_TAGE, "ein_fenster_s": EIN_FENSTER_S, "wende_v": 1}


def _t(y: int, m: int, d: int) -> int:
    return calendar.timegm((y, m, d, 0, 0, 0))


START_VIDEO = _t(2021, 11, 1)          # Hauptprüfung: Flip-Kerzen ab hier (Beginn der Kerze, KONZEPT 2.10)
ENDE_VIDEO = _t(2026, 10, 18)          # Zählung „35 Signale“ bis einschließlich 17.10.2026 (KONZEPT 3.1)
STICHTAG = _t(2026, 10, 27)            # Datenende des Urteils (KONZEPT 3.7): fest, spätere Läufe urteilen gleich
LUECKE = (_t(2025, 10, 14), _t(2026, 10, 15))   # „das erste [Short-Signal] seit dem Short am Allzeithoch“: keins dazwischen
# Die sechs im Video genannten Trades (KONZEPT 1 und 3.1); Datum einer Flip-Kerze = UTC-Datum ihres Beginns. Trade 6: Einstieg aus
# 1R/2R/3R des Videos abgeleitet ((87.457 + 76.952) ÷ 2), Trade 1 ebenso bestätigt ((126.315 + 97.100) ÷ 2) -- dort ±0,5 %.
VIDEO_TRADES = (
    {"nr": 1, "seite": "short", "von": _t(2025, 10, 11), "bis": _t(2025, 10, 14), "einstieg": 111700.0, "tol": 0.005, "stop": 126315.0,
     "text": "Short, Flip 12.10.2025, Einstieg rund 111.700, Stop 126.315", "neben": "lief über 3R"},
    {"nr": 2, "seite": "long", "von": _t(2023, 1, 7), "bis": _t(2023, 1, 10), "einstieg": 16900.0, "abstand": (1.5, 3.5),
     "text": "Long, Flip 08.01.2023, Einstieg rund 16.900, Stop gut 2 % darunter", "neben": "nie ausgestoppt"},
    {"nr": 3, "seite": "short", "von": _t(2024, 6, 1), "bis": _t(2024, 7, 1), "einstieg": 66400.0, "abstand": (4.0, 7.0),
     "text": "Short, Juni 2024, Einstieg rund 66.400, Stop gut 5 % darüber", "neben": "fast 5R im Plus, Monate später am Stop"},
    {"nr": 4, "seite": "long", "von": _t(2026, 3, 20), "bis": _t(2026, 4, 1), "einstieg": 71300.0,
     "text": "Long, Ende März 2026, Einstieg rund 71.300", "neben": "zwei Tage später ausgestoppt"},
    {"nr": 5, "seite": "long", "von": _t(2026, 7, 1), "bis": _t(2026, 8, 1), "einstieg": 64100.0, "abstand": (8.5, 11.5),
     "text": "Long, Juli 2026, Einstieg rund 64.100, Stop 10 % darunter", "neben": "bis +36 % (gut 3,5R), nicht ausgestoppt"},
    {"nr": 6, "seite": "short", "von": _t(2026, 10, 15), "bis": _t(2026, 10, 18), "einstieg": 82205.0, "tol": 0.005, "stop": 87457.0,
     "text": "Short, Flip 16.10.2026, Einstieg rund 82.205, Stop 87.457", "neben": "das aktuelle Signal"},
)
VIDEO_ZAHL, VIDEO_LONG, VIDEO_SHORT = 35, 16, 19
TOL_EINSTIEG, TOL_STOP, TOL_ZAHL, MIN_GEFUNDEN = 0.015, 0.005, 5, 5


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    return RG._de(x, nd, vz)


def _datum(ts) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(ts))) if ts is not None else "—"


def _zeit(ts) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.gmtime(int(ts))) if ts is not None else "—"


def _px(x) -> str:
    if x is None or not np.isfinite(x):
        return "—"
    return f"{x:,.0f}".replace(",", ".") if abs(x) >= 1000 else _de(x, 2)


def _pz(p) -> str:
    if p is None or not np.isfinite(p):
        return "—"
    return "< 0,001" if p < 0.001 else _de(p, 3)


def _tsd(n) -> str:
    return f"{int(n):,}".replace(",", ".")


def _proz(a, b, nd: int = 0) -> str:
    return _de(100.0 * a / b, nd) + " %" if b else "—"


# ================================================================================================ Kerzen, EMA, Flips, Schwankung

def _sauber(K: dict):
    ts = np.asarray(K["ts"], dtype=np.int64)
    o, h, l, c = (np.asarray(K[k], dtype=float) for k in ("o", "h", "l", "c"))
    ok = (np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c) & (o > 0) & (h > 0) & (l > 0) & (c > 0)
          & (ts % BAR == 0))
    ts, o, h, l, c = ts[ok], o[ok], h[ok], l[ok], c[ok]
    s = np.argsort(ts, kind="stable")
    ts, o, h, l, c = ts[s], o[s], h[s], l[s], c[s]
    eind = np.concatenate([[True], np.diff(ts) > 0]) if len(ts) else np.zeros(0, dtype=bool)
    ts, o, h, l, c = ts[eind], o[eind], h[eind], l[eind], c[eind]
    return ts, o, np.maximum(h, np.maximum(o, c)), np.minimum(l, np.minimum(o, c)), c


def ema(x: np.ndarray, n: int) -> np.ndarray:
    """EMA mit α = 2/(n+1), Startwert der erste Wert (KONZEPT 2.2)."""
    x = np.asarray(x, dtype=float); out = np.empty(len(x))
    if not len(x):
        return out
    a = 2.0 / (n + 1.0); e = float(x[0])
    for i in range(len(x)):
        e = float(x[i]) if i == 0 else a * float(x[i]) + (1.0 - a) * e
        out[i] = e
    return out


def flips(e_kurz: np.ndarray, e_lang: np.ndarray) -> np.ndarray:
    """
    Flips (KONZEPT 2.2): Lage = Vorzeichen von EMA kurz − EMA lang, ein Gleichstand ändert die Lage nicht; Flip an T, wenn die Lage
    an T wechselt: −1 bärisch (vorher über, jetzt unter), +1 bullisch. So wechseln sich Flips immer ab, auch nach einem Gleichstand.
    """
    d = np.asarray(e_kurz, dtype=float) - np.asarray(e_lang, dtype=float)
    s = np.sign(d).astype(np.int8); f = np.zeros(len(d), dtype=np.int8)
    if len(d) < 2:
        return f
    nz = s != 0
    idx = np.where(nz, np.arange(len(s)), 0); np.maximum.accumulate(idx, out=idx)
    lage = s[idx].copy(); lage[np.cumsum(nz) == 0] = 0
    wechsel = np.zeros(len(s), dtype=bool)
    wechsel[1:] = (lage[1:] != lage[:-1]) & (lage[1:] != 0) & (lage[:-1] != 0)
    f[wechsel] = lage[wechsel]
    return f


def daten(K: dict, F: dict | None = None, bis: int | None = None, R: dict = REGELN) -> dict | None:
    """
    30-min-Kerzen -> Datensatz (KONZEPT 2.1): die Kerzen selbst (Ausführung), die abgeschlossenen 8-h-Kerzen (Eröffnung der ersten,
    Schluss der letzten vorhandenen 30-min-Kerze, Hoch/Tief über alle; voll = ≥ 14 von 16 samt erster und letzter; fehlt eine 8-h-Kerze
    ganz, läuft die Reihe über die vorhandenen), EMA und Flips, Summen für die Schwankung vor jedem Einstieg. bis: nur 30-min-Kerzen,
    die bis dahin abgeschlossen sind (Stichtag, Labor, Kausalitätsprobe).
    """
    ts, o, h, l, c = _sauber(K)
    if bis is not None:
        m = ts + BAR <= int(bis)
        ts, o, h, l, c = ts[m], o[m], h[m], l[m], c[m]
    if not len(ts):
        return None
    ende = int(ts[-1]) + BAR
    per = ts // K8
    up, i0 = np.unique(per, return_index=True)
    i1 = np.append(i0[1:], len(ts))
    zu = (up + 1) * K8 <= ende                                      # nur abgeschlossene 8-h-Kerzen
    up, i0, i1 = up[zu], i0[zu], i1[zu]
    if not len(up):
        return None
    k_ts = (up * K8).astype(np.int64)
    hh, ll = h[:i1[-1]], l[:i1[-1]]
    k_h = np.maximum.reduceat(hh, i0); k_l = np.minimum.reduceat(ll, i0)
    k_o = o[i0]; k_c = c[i1 - 1]; nb = i1 - i0
    voll = (nb >= VOLL_MIN) & (ts[i0] == k_ts) & (ts[i1 - 1] == k_ts + K8 - BAR)
    e_k = ema(k_c, int(R["ema_kurz"])); e_l = ema(k_c, int(R["ema_lang"]))
    fl = flips(e_k, e_l)
    r = np.zeros(len(c)); okr = np.zeros(len(c), dtype=bool)
    r[1:] = np.diff(np.log(c)); okr[1:] = np.diff(ts) == BAR
    D = {"ts": ts, "o": o, "h": h, "l": l, "c": c, "ende": ende, "n": len(ts),
         "k_ts": k_ts, "k_o": k_o, "k_h": k_h, "k_l": k_l, "k_c": k_c, "k_nb": nb, "k_voll": voll, "k_i0": i0, "k_i1": i1,
         "n8": len(k_ts), "e_kurz": e_k, "e_lang": e_l, "flip": fl, "flip_idx": np.nonzero(fl)[0], "F": F,
         "luecken8": int(np.sum(np.diff(k_ts) != K8)) if len(k_ts) > 1 else 0,
         "rv_cs": np.concatenate([[0.0], np.cumsum(np.where(okr, r * r, 0.0))]), "rv_cn": np.concatenate([[0], np.cumsum(okr)])}
    if F is not None and len(F.get("ts", [])):
        D["f_ts"] = np.asarray(F["ts"], dtype=np.int64)
        D["f_cs"] = np.concatenate([[0.0], np.cumsum(np.asarray(F["rate"], dtype=float))])
    return D


def sigma_an(D: dict, j0) -> np.ndarray:
    """Schwankung je 30 min vor dem Einstieg zur Eröffnung der Kerze j0: Wurzel aus dem Mittel der quadrierten Renditen der 480 Kerzen
    davor (10 Tage; nur bei 30 min Abstand, mindestens 240) -- endet am Schluss der Flip-Kerze, also kausal (KONZEPT 3.3)."""
    j0 = np.asarray(j0, dtype=np.int64); a = np.maximum(j0 - RV_KERZEN, 0)
    s = D["rv_cs"][j0] - D["rv_cs"][a]; n = D["rv_cn"][j0] - D["rv_cn"][a]
    return np.where(n >= RV_MIN, np.sqrt(s / np.maximum(n, 1)), np.nan)


def _funding(D: dict, t_a, t_b) -> np.ndarray:
    """Summe der Funding-Raten mit Zeitpunkt in (t_a, t_b] (wie hl_swing._funding_summe), vektorisiert."""
    t_a = np.asarray(t_a, dtype=np.int64); t_b = np.asarray(t_b, dtype=np.int64)
    if "f_ts" not in D:
        return np.zeros(np.broadcast(t_a, t_b).shape)
    a = np.searchsorted(D["f_ts"], t_a, side="right"); b = np.searchsorted(D["f_ts"], t_b, side="right")
    return np.where(t_b > t_a, D["f_cs"][b] - D["f_cs"][a], 0.0)


# ================================================================================================ Extreme und Signale

def schwellen(D: dict, T: int, fenster: int, lesart: str, anteil: float):
    """Schwellen für rot (Hoch) und blau (Tief) im Fenster W_T der `fenster` Kerzen bis einschließlich T (KONZEPT 2.3, 2.4)."""
    a = T - fenster + 1
    if a < 0 or T >= D["n8"]:
        return None
    hw = D["k_h"][a:T + 1]; lw = D["k_l"][a:T + 1]
    if lesart == "rang":
        return float(np.quantile(hw, 1.0 - anteil)), float(np.quantile(lw, anteil))
    H = float(hw.max()); L = float(lw.min())
    return L + (1.0 - anteil) * (H - L), L + anteil * (H - L)


def _farbe_eigen(D: dict, fenster: int, lesart: str, anteil: float) -> tuple:
    """Lesart „je Kerze“ (nur beschreibend, KONZEPT 4.6): rot/blau jeder Kerze i mit ihrem eigenen Fenster [i − fenster + 1, i] --
    ohne Nachfärben. Gemerkt je Datensatz."""
    key = ("_farbe", fenster, lesart, anteil)
    if key in D:
        return D[key]
    n = D["n8"]; rot = np.zeros(n, dtype=bool); blau = np.zeros(n, dtype=bool)
    if n >= fenster:
        Wh = np.lib.stride_tricks.sliding_window_view(D["k_h"], fenster); Wl = np.lib.stride_tricks.sliding_window_view(D["k_l"], fenster)
        if lesart == "rang":
            th = np.quantile(Wh, 1.0 - anteil, axis=1); tl = np.quantile(Wl, anteil, axis=1)
        else:
            Hm = Wh.max(axis=1); Lm = Wl.min(axis=1); th = Lm + (1.0 - anteil) * (Hm - Lm); tl = Lm + anteil * (Hm - Lm)
        rot[fenster - 1:] = D["k_h"][fenster - 1:] >= th; blau[fenster - 1:] = D["k_l"][fenster - 1:] <= tl
    D[key] = (rot, blau)
    return D[key]


def signal_an(D: dict, T: int, R: dict = REGELN, lesart: str = "rang", ohne_extrem: bool = False, fenster_art: str = "T",
              stop_art: str = "alle") -> dict | None:
    """
    Signal an der 8-h-Kerze T (KONZEPT 2.5) oder None -- nutzt nur Kerzen bis T. Flip an T (nur volle Kerze); b = Flip davor (die
    Flips wechseln sich ab, also ein Gegen-Flip); Kandidaten b < i ≤ T im Fenster; rot (Short) bzw. blau (Long) nach der Lesart;
    Stop 0,1 % jenseits des Extrems der roten bzw. blauen Kerzen (= Extrem seit b im Fenster, denn die extremste Kerze ist dann rot).
    Nur beschreibend (4.6): fenster_art „i“ färbt jede Kerze mit ihrem eigenen Fenster; stop_art „block“ nimmt nur den letzten
    zusammenhängenden roten bzw. blauen Block; ohne_extrem (Kontrolle 4.5): jede Kerze zählt.
    """
    if T < 0 or T >= D["n8"]:
        return None
    f = int(D["flip"][T])
    if f == 0 or not D["k_voll"][T]:
        return None
    fenster = int(R["fenster"]); anteil = float(R["anteil"])
    s = schwellen(D, T, fenster, lesart, anteil)
    if s is None:
        return None
    fi = D["flip_idx"]; p = int(np.searchsorted(fi, T)) - 1
    b = int(fi[p]) if p >= 0 else -1
    a = max(b + 1, T - fenster + 1)
    w = D["k_h"][a:T + 1] if f < 0 else D["k_l"][a:T + 1]
    if ohne_extrem:
        sel = np.ones(len(w), dtype=bool)
    elif fenster_art == "i":
        rot, blau = _farbe_eigen(D, fenster, lesart, anteil); sel = (rot if f < 0 else blau)[a:T + 1].copy()
    else:
        sel = w >= s[0] if f < 0 else w <= s[1]
    if not sel.any():
        return None
    if stop_art == "block":                                                # nur der letzte zusammenhängende Block
        letzt = len(sel) - 1 - int(np.argmax(sel[::-1])); erst = letzt
        while erst - 1 >= 0 and sel[erst - 1]:
            erst -= 1
        sel = np.zeros(len(sel), dtype=bool); sel[erst:letzt + 1] = True
    if f < 0:
        j = int(np.argmax(np.where(sel, w, -np.inf))); ext = float(w[j]); stop = ext * (1.0 + float(R["stop_puffer"])); seite = "short"
    else:
        j = int(np.argmin(np.where(sel, w, np.inf))); ext = float(w[j]); stop = ext * (1.0 - float(R["stop_puffer"])); seite = "long"
    schluss = float(D["k_c"][T])
    return {"T": int(T), "k_ts": int(D["k_ts"][T]), "t_flip": int(D["k_ts"][T]) + K8, "seite": seite, "stop": stop, "extrem": ext,
            "i_extrem": a + j, "n_extrem": int(sel.sum()), "schluss": schluss, "b": b, "lesart": lesart,
            "schwelle": s[0] if f < 0 else s[1], "abstand_schluss": abs(schluss - stop) / schluss}


def signale(D: dict, R: dict = REGELN, lesart: str = "rang", ohne_extrem: bool = False, ab_ts: int | None = None,
            bis_ts: int | None = None, fenster_art: str = "T", stop_art: str = "alle") -> list:
    """Alle Signale (Flip-Kerzen mit Beginn in [ab_ts, bis_ts)) mit dem Einstieg zur Eröffnung der ersten 30-min-Kerze nach dem
    Schluss (KONZEPT 2.6); kein Trade (Feld „kein“), wenn noch keine Kerze danach da ist, die erste erst mehr als 60 min nach dem
    Schluss beginnt (wie im Labor) oder ihre Eröffnung schon jenseits des Stops liegt."""
    out = []
    for T in D["flip_idx"]:
        T = int(T)
        if ab_ts is not None and D["k_ts"][T] < ab_ts:
            continue
        if bis_ts is not None and D["k_ts"][T] >= bis_ts:
            continue
        s = signal_an(D, T, R, lesart, ohne_extrem, fenster_art, stop_art)
        if s is None:
            continue
        j0 = int(np.searchsorted(D["ts"], s["t_flip"], side="left"))
        if j0 >= D["n"]:
            s.update(j0=None, einstieg=None, kein="noch keine Kerze nach dem Schluss")
        elif int(D["ts"][j0]) - s["t_flip"] > int(R["ein_fenster_s"]):
            s.update(j0=None, einstieg=None, kein=f"erste Kerze erst {(int(D['ts'][j0]) - s['t_flip']) // 60} min nach dem Schluss")
        else:
            mid = float(D["o"][j0]); sv = 1 if s["seite"] == "long" else -1
            s.update(j0=j0, einstieg=mid, t_in=int(D["ts"][j0]), abstand=abs(mid - s["stop"]) / mid,
                     kein=("Einstieg jenseits des Stops" if (sv > 0 and mid <= s["stop"]) or (sv < 0 and mid >= s["stop"]) else None))
        out.append(s)
    return out


# ================================================================================================ Erste Passage (schnell)

class Passage:
    """
    Erste Passage auf den 30-min-Kerzen für viele Startpunkte zugleich: Tabelle der Block-Maxima (Hoch) und -Minima (Tief) über
    2^k Kerzen, binäres Vorrücken über Blöcke ohne Treffer. hoch(): erster Index j ≥ start mit h[j] > s (strikt) bzw. ≥ s; tief()
    gespiegelt; n, wenn keiner. max_bereich/min_bereich: Maximum bzw. Minimum über [a, b).
    """

    def __init__(self, h: np.ndarray, l: np.ndarray):
        self.n = len(h); self.mx = [np.asarray(h, dtype=float)]; self.mn = [np.asarray(l, dtype=float)]
        k = 1
        while (1 << k) <= self.n:
            s = 1 << (k - 1); p = self.mx[-1]; q = self.mn[-1]
            self.mx.append(np.maximum(p[:len(p) - s], p[s:])); self.mn.append(np.minimum(q[:len(q) - s], q[s:]))
            k += 1

    def _vor(self, tab, start, schwelle, kein_treffer):
        pos = np.minimum(np.asarray(start, dtype=np.int64).copy(), self.n)
        sw = np.broadcast_to(np.asarray(schwelle, dtype=float), pos.shape)
        for k in range(len(tab) - 1, -1, -1):
            w = 1 << k
            ok = pos + w <= self.n
            if not ok.any():
                continue
            m = tab[k][np.where(ok, pos, 0)]
            pos = np.where(ok & kein_treffer(m, sw), pos + w, pos)
        return pos

    def hoch(self, start, schwelle, strikt: bool) -> np.ndarray:
        return self._vor(self.mx, start, schwelle, (lambda m, s: m <= s) if strikt else (lambda m, s: m < s))

    def tief(self, start, schwelle, strikt: bool) -> np.ndarray:
        return self._vor(self.mn, start, schwelle, (lambda m, s: m >= s) if strikt else (lambda m, s: m > s))

    def _bereich(self, tab, a, b, fn):
        a = np.asarray(a, dtype=np.int64); b = np.asarray(b, dtype=np.int64)
        L = np.maximum(b - a, 1)
        k = np.frexp(L.astype(float))[1] - 1
        out = np.empty(len(a))
        for kk in np.unique(k):
            m = k == kk; arr = tab[int(kk)]
            out[m] = fn(arr[a[m]], arr[b[m] - (1 << int(kk))])
        return out

    def max_bereich(self, a, b) -> np.ndarray:
        return self._bereich(self.mx, a, b, np.maximum)

    def min_bereich(self, a, b) -> np.ndarray:
        return self._bereich(self.mn, a, b, np.minimum)


def _j_stop(P: Passage, j0, stop, sv: int):
    """Erste Kerze ab der Einstiegskerze, die den Stop erreicht (Long: Tief ≤ Stop; Short: Hoch ≥ Stop)."""
    return P.tief(j0, stop, strikt=False) if sv > 0 else P.hoch(j0, stop, strikt=False)


def _j_ziel(P: Passage, j0, ziel, sv: int):
    """Erste Kerze nach der Einstiegskerze, die DURCH das Ziel läuft (Long: Hoch > Ziel; Short: Tief < Ziel) -- wie ein Limit im Labor."""
    j1 = np.asarray(j0, dtype=np.int64) + 1
    return P.hoch(j1, ziel, strikt=True) if sv > 0 else P.tief(j1, ziel, strikt=True)


def ausgang(D: dict, P: Passage, j0, mid, stop, sv: int, art: str, ziel_r: float = ZIEL_R, jg=None, max_tage: int | None = MAX_TAGE):
    """
    Ausgang je Trade (KONZEPT 2.8, 4.3) für Trades gleicher Richtung sv: art „ziel“ (Ziel ziel_r R als Limit, Stop), „stop“ (bis zum
    Stop laufen lassen), „gegenflip“ (zur Eröffnung nach dem Schluss des nächsten Gegen-Flips, Index jg); höchstens max_tage Tage, dann
    zur Eröffnung (None: ohne Grenze). In der Einstiegskerze zählt nur der Stop; Stop und Ziel in einer Kerze: Stop; Lücke über den
    Stop: Eröffnung. Rückgabe: Index, Grund (0 Ziel, 1 Stop, 2 Zeit, 3 Gegen-Flip, 4 offen), Ausstieg (Mitte), Zeit des Ausstiegs.
    """
    j0 = np.asarray(j0, dtype=np.int64); mid = np.asarray(mid, dtype=float); stop = np.asarray(stop, dtype=float)
    n = P.n; o, c, ts = D["o"], D["c"], D["ts"]
    R = np.abs(mid - stop)
    js = _j_stop(P, j0, stop, sv)
    jt = (np.searchsorted(ts, ts[np.minimum(j0, n - 1)] + int(max_tage) * TAG, side="left") if max_tage is not None
          else np.full(len(j0), n, dtype=np.int64))
    if art == "ziel":
        jx = _j_ziel(P, j0, mid + sv * ziel_r * R, sv); gx = 0
    elif art == "stop":
        jx = np.full(len(j0), n, dtype=np.int64); gx = 0
    elif art == "gegenflip":
        jx = np.asarray(jg, dtype=np.int64); gx = 3
    else:
        raise ValueError(art)
    g = np.full(len(j0), 4, dtype=np.int64); j = np.full(len(j0), n, dtype=np.int64)
    if art == "gegenflip":                                                  # Ausstieg zur Eröffnung von jg: vor dem Stop in dieser Kerze
        xi = (jx <= js) & (jx < jt) & (jx < n)
    else:                                                                   # Ziel in derselben Kerze wie der Stop: Stop
        xi = (jx < js) & (jx < jt) & (jx < n)
    st = ~xi & (js < jt) & (js < n)
    ze = ~xi & ~st & (jt < n)
    g[xi] = gx; j[xi] = jx[xi]; g[st] = 1; j[st] = js[st]; g[ze] = 2; j[ze] = jt[ze]
    jj = np.minimum(j, n - 1)
    stop_px = np.where(j == j0, stop, np.minimum(o[jj], stop) if sv > 0 else np.maximum(o[jj], stop))
    aus = np.where(g == 0, mid + sv * ziel_r * R, np.where(g == 1, stop_px, np.where(g == 4, c[n - 1], o[jj])))
    t_aus = np.where((g == 0) | (g == 1), ts[jj] + BAR, np.where(g == 4, D["ende"], ts[jj]))
    return j, g, aus, t_aus


def r_werte(D: dict, j0, mid, stop, sv: int, g, aus, t_aus) -> dict:
    """R je Trade vor Kosten (Kurs) und nach Kosten (KONZEPT 2.7, 2.8): Einstieg Taker mit Abstand zur Mitte, Ziel Maker ohne Abstand,
    Stop/Zeit/Gegen-Flip Taker mit Abstand, offen zum letzten Schluss ohne Kosten; Funding auf das Notional (Longs zahlen positive)."""
    j0 = np.asarray(j0, dtype=np.int64); mid = np.asarray(mid, dtype=float); stop = np.asarray(stop, dtype=float)
    R = np.abs(mid - stop)
    px_in = mid * (1 + sv * SLIP); geb_in = GEB_TAKER * px_in
    px_aus = np.where((g == 0) | (g == 4), aus, aus * (1 - sv * SLIP))
    geb_aus = np.where(g == 0, GEB_MAKER * px_aus, np.where(g == 4, 0.0, GEB_TAKER * px_aus))
    fund = sv * _funding(D, D["ts"][np.minimum(j0, D["n"] - 1)], t_aus) * px_in
    pnl = sv * (px_aus - px_in) - geb_in - geb_aus - fund
    return {"kurs": sv * (aus - mid) / R, "netto": pnl / R, "abstand": (sv * (px_aus - px_in) - sv * (aus - mid)) / R,
            "gebuehren": -(geb_in + geb_aus) / R, "funding": -fund / R}


def mfe(D: dict, P: Passage, j0, mid, stop, sv: int, max_tage: int | None = None) -> np.ndarray:
    """Bestes Zwischenhoch in R vom Einstieg bis vor die Stop-Kerze (bzw. bis zur Zeitgrenze oder zum Datenende) -- „perfekt“ geht nur
    im Nachhinein (KONZEPT 4.2: Obergrenze)."""
    j0 = np.asarray(j0, dtype=np.int64); mid = np.asarray(mid, dtype=float); stop = np.asarray(stop, dtype=float)
    R = np.abs(mid - stop); js = _j_stop(P, j0, stop, sv)
    b = np.minimum(js, P.n)
    if max_tage is not None:
        b = np.minimum(b, np.searchsorted(D["ts"], D["ts"][np.minimum(j0, P.n - 1)] + int(max_tage) * TAG, side="left"))
    leer = b <= j0
    bb = np.maximum(b, j0 + 1)
    m = P.max_bereich(j0, bb) if sv > 0 else P.min_bereich(j0, bb)
    x = (m - mid) / R if sv > 0 else (mid - m) / R
    return np.where(leer, 0.0, np.maximum(x, 0.0))


def _gegenflip_index(D: dict, T8, sv: int) -> np.ndarray:
    """Index der 30-min-Kerze nach dem Schluss des nächsten Flips gegen die Position nach der 8-h-Kerze T8 (n, wenn keiner)."""
    T8 = np.asarray(T8, dtype=np.int64)
    gegen = np.nonzero(D["flip"] == (-1 if sv > 0 else 1))[0]
    if not len(gegen):
        return np.full(len(T8), D["n"], dtype=np.int64)
    p = np.searchsorted(gegen, T8, side="right")
    hat = p < len(gegen)
    t = np.where(hat, D["k_ts"][gegen[np.minimum(p, len(gegen) - 1)]] + K8, 0)
    jg = np.searchsorted(D["ts"], t, side="left")
    return np.where(hat, jg, D["n"])


def _einzel(D: dict, P: Passage, j0, mid, stop, sv: int, art: str, zr: float = 1.0, jg=None, max_tage: int | None = MAX_TAGE) -> dict:
    j, g, aus, ta = ausgang(D, P, j0, mid, stop, sv, art, zr, jg=jg, max_tage=max_tage)
    rw = r_werte(D, j0, mid, stop, sv, g, aus, ta)
    return {"j": int(j[0]), "g": int(g[0]), "aus": float(aus[0]), "t_aus": int(ta[0]), **{k: float(v[0]) for k, v in rw.items()}}


def trades_rechnen(D: dict, P: Passage, sigs: list) -> list:
    """Jedes Signal mit Einstieg ein Trade (KONZEPT 2.9): Hauptregel und Varianten (120 Tage), „laufen lassen“ und MFE ohne Grenze für
    den Vergleich mit dem Video (4.2), Stufen, „praktisch sofort ausgestoppt“, Schwankung beim Einstieg, Kerzen-Befunde (4.10)."""
    out = []
    for s in sigs:
        if s.get("j0") is None or s.get("kein"):
            continue
        sv = 1 if s["seite"] == "long" else -1
        j0 = np.array([s["j0"]]); mid = np.array([s["einstieg"]]); st = np.array([s["stop"]])
        R = abs(s["einstieg"] - s["stop"])
        t = dict(s, sv=sv, R=R)
        for key, art, zr, mt in (("ziel1", "ziel", 1.0, MAX_TAGE), ("ziel2", "ziel", 2.0, MAX_TAGE), ("ziel3", "ziel", 3.0, MAX_TAGE),
                                 ("laufen120", "stop", 1.0, MAX_TAGE), ("laufen", "stop", 1.0, None)):
            t[key] = _einzel(D, P, j0, mid, st, sv, art, zr, max_tage=mt)
        t["gegenflip"] = _einzel(D, P, j0, mid, st, sv, "gegenflip", jg=_gegenflip_index(D, [s["T"]], sv), max_tage=MAX_TAGE)
        js = int(_j_stop(P, j0, st, sv)[0]); jt = int(np.searchsorted(D["ts"], s["t_in"] + MAX_TAGE * TAG, side="left"))
        t["mfe"] = float(mfe(D, P, j0, mid, st, sv)[0])
        jl = {L: int(_j_ziel(P, j0, mid + sv * L * R, sv)[0]) for L in STUFEN}
        t["stufen"] = {L: jl[L] < js for L in STUFEN}
        t["stufen120"] = {L: jl[L] < min(js, jt) for L in STUFEN}
        t["js"] = js
        t["fast_sofort"] = bool(js < P.n and js - s["j0"] < FAST_SOFORT_K * PRO_K8 and t["mfe"] < FAST_SOFORT_R)
        t["im_stop"] = bool(js < P.n)
        t["stop_einstiegskerze"] = js == s["j0"]
        t["gleichstand"] = jl[1.0] == js and js < P.n
        t["sigma"] = float(sigma_an(D, j0)[0])
        out.append(t)
    return out


# ================================================================================================ Verschiebung und Statistik

def zufall_pool(D: dict, ab_ts: int, ende_puffer_tage: int = MAX_TAGE) -> np.ndarray:
    """8-h-Kerzen, deren Schluss ein verschobener Einstieg sein darf (KONZEPT 3.3): Beginn ab ab_ts, Schluss + 120 Tage < Datenende
    (strikt: die Kerze zur Zeitgrenze liegt in den Daten, KONZEPT 8.4), volle Kerze und Einstiegskerze höchstens 60 min nach dem Schluss
    wie bei echten Signalen (2.1, 2.6) -- so endet jeder verschobene Trade (Ziel, Stop oder Zeit)."""
    t_close = D["k_ts"] + K8
    ok = (D["k_ts"] >= ab_ts) & (t_close + ende_puffer_tage * TAG < D["ende"]) & D["k_voll"]
    idx = np.nonzero(ok)[0]
    j0 = np.searchsorted(D["ts"], t_close[idx], side="left")
    gut = j0 < D["n"]
    gut[gut] = D["ts"][j0[gut]] - t_close[idx[gut]] <= EIN_FENSTER_S
    return idx[gut]


def verschiebungen(D: dict, ab_ts: int, T_echt) -> dict | None:
    """
    Die Nullverteilung (KONZEPT 3.3, beim Bau geändert): alle Trades des Urteils gemeinsam um τ Kerzen verschoben, im Kreis über die
    Spanne der erlaubten Einstiege (zufall_pool), Kreisabstand |τ| ≥ 120 Tage -- so behalten die verschobenen Trades die Überlappung der
    echten (gleiche Abstände zueinander) und ihre Richtung. Rückgabe: Spanne, τ, Position je Trade (die Trades des Urteils liegen in
    der Spanne: Stichtag-Grenze, KONZEPT 3.7).
    """
    pool = zufall_pool(D, ab_ts); L = len(pool); mk = int(MAX_TAGE * TAG // K8)
    if L <= 2 * mk + 1:
        return None
    return {"pool": pool, "taus": np.arange(mk, L - mk + 1), "pos": np.searchsorted(pool, np.asarray(T_echt, dtype=np.int64)), "L": L}


def _trades_an(D: dict, P: Passage, t: dict, T8, j0, alle: bool = False, skala: bool = True) -> dict:
    """
    Dieselbe Regel wie Trade t an anderen Einstiegen (8-h-Kerzen T8, Einstiegskerzen j0): gleiche Richtung, Ziel 1R, 120 Tage; der
    Stop-Abstand in Einheiten der Schwankung vor dem Einstieg wie beim echten Trade (a × σ_neu ÷ σ_echt, in [0,05 %, 90 %]; skala
    False: derselbe Abstand in %, nur beschreibend). alle: dazu die Mittel der Varianten und Stufen mit 120 Tagen (4.3, 4.4).
    """
    sv = t["sv"]; mid = D["o"][j0]; a = np.full(len(j0), float(t["abstand"])); ohne = 0
    if skala:
        s_neu = sigma_an(D, j0); s_alt = float(t.get("sigma", float("nan")))
        if np.isfinite(s_alt) and s_alt > 0:
            a = np.where(np.isfinite(s_neu), np.clip(a * s_neu / s_alt, A_MIN, A_MAX), a)
            ohne = int(np.sum(~np.isfinite(s_neu)))                       # ohne σ (unter 240 Renditen): Abstand unskaliert, gezählt
        else:
            ohne = len(j0)
    stop = mid * (1 - sv * a)
    j, g, aus, ta = ausgang(D, P, j0, mid, stop, sv, "ziel", 1.0)
    out = {"treffer": g == 0, "erledigt": g != 4, "zeit": g == 2, "a": a, "ohne_sigma": ohne}
    if alle:
        M = {}
        rw = r_werte(D, j0, mid, stop, sv, g, aus, ta)
        M["ziel1"] = {k: float(np.mean(rw[k])) for k in ("kurs", "netto")}
        for key, art, zr in (("ziel2", "ziel", 2.0), ("ziel3", "ziel", 3.0), ("laufen120", "stop", 1.0)):
            j_, g_, aus_, ta_ = ausgang(D, P, j0, mid, stop, sv, art, zr)
            rw = r_werte(D, j0, mid, stop, sv, g_, aus_, ta_)
            M[key] = {k: float(np.mean(rw[k])) for k in ("kurs", "netto")}
        jg = _gegenflip_index(D, T8, sv)
        j_, g_, aus_, ta_ = ausgang(D, P, j0, mid, stop, sv, "gegenflip", jg=jg)
        rw = r_werte(D, j0, mid, stop, sv, g_, aus_, ta_)
        M["gegenflip"] = {k: float(np.mean(rw[k])) for k in ("kurs", "netto")}
        js = _j_stop(P, j0, stop, sv); R = np.abs(mid - stop)
        jt = np.searchsorted(D["ts"], D["ts"][np.minimum(j0, P.n - 1)] + MAX_TAGE * TAG, side="left")
        out["mittel"] = M
        out["stufen120"] = {L: float(np.mean(_j_ziel(P, j0, mid + sv * L * R, sv) < np.minimum(js, jt))) for L in STUFEN}
    return out


def poisson_binomial(ps) -> np.ndarray:
    """Verteilung der Trefferzahl bei unabhängigen Trades mit Trefferwahrscheinlichkeiten ps (exakt gefaltet)."""
    d = np.array([1.0])
    for p in ps:
        p = float(min(max(p, 0.0), 1.0))
        d = np.concatenate([d * (1.0 - p), [0.0]]) + np.concatenate([[0.0], d * p])
    return d


def p_mindestens(d: np.ndarray, x: int) -> float:
    return float(d[int(x):].sum()) if 0 <= int(x) < len(d) else (1.0 if int(x) <= 0 else 0.0)


def t_quantil(q: float, df: float) -> float:
    """Einseitiges Quantil der t-Verteilung (q > 0,5) durch Bisektion über RG.t_p2."""
    lo, hi = 0.0, 50.0
    ziel = 2.0 * (1.0 - q)
    for _ in range(100):
        m = 0.5 * (lo + hi)
        if RG.t_p2(m, df) > ziel:
            lo = m
        else:
            hi = m
    return 0.5 * (lo + hi)


def _phi(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def cluster_ids(tr: list) -> np.ndarray:
    """Gruppen überlappender Trades (Haltezeit der Hauptregel vom Einstieg bis zum Ausstieg): Trades einer Gruppe hängen am selben
    Kursweg und zählen im Standardfehler nicht als unabhängig (KONZEPT 3.4)."""
    o = sorted(range(len(tr)), key=lambda i: tr[i]["t_in"]); ids = np.zeros(len(tr), dtype=np.int64); g = -1; ende = -1
    for i in o:
        a_ = tr[i]["t_in"]; b_ = tr[i]["ziel1"]["t_aus"]
        if a_ >= ende:
            g += 1; ende = b_
        else:
            ende = max(ende, b_)
        ids[i] = g
    return ids


def t_cluster(x, ids) -> dict:
    """Mittel > 0, einseitig, mit Cluster-robustem Standardfehler (G Gruppen, G − 1 Freiheitsgrade, Faktor G/(G−1)); 90-%-Intervall.
    Mit lauter Einzelgruppen genau der gewöhnliche t-Test (Σ(x−m)²/n² · n/(n−1) = s²/n, n − 1 Freiheitsgrade)."""
    x = np.asarray(x, dtype=float); n = len(x); nan = float("nan")
    if n < 2:
        return {"n": n, "G": n, "mittel": float(x.mean()) if n else nan, "t": nan, "p": nan, "lo": nan, "hi": nan}
    _, inv = np.unique(np.asarray(ids), return_inverse=True); G = int(inv.max()) + 1
    m = float(x.mean())
    if G < 2:
        return {"n": n, "G": G, "mittel": m, "t": nan, "p": nan, "lo": nan, "hi": nan}
    S = np.bincount(inv, weights=x - m, minlength=G)
    se = math.sqrt(float((S ** 2).sum()) / (n * n) * G / (G - 1))
    if se <= 0:
        return {"n": n, "G": G, "mittel": m, "t": nan, "p": nan, "lo": m, "hi": m}
    t = m / se; p2 = RG.t_p2(t, G - 1); q = t_quantil(0.95, G - 1)
    return {"n": n, "G": G, "mittel": m, "t": t, "p": (p2 / 2 if t > 0 else 1 - p2 / 2), "lo": m - q * se, "hi": m + q * se}


def h1_verschiebung(treffer_echt, H: np.ndarray, alpha: float = ALPHA_H1) -> dict:
    """
    H1 (KONZEPT 3.3): X = Treffer der echten Trades; Nullverteilung X_τ = Treffer derselben Trades, gemeinsam verschoben (H: Treffer je
    Trade und τ). p = (1 + #{X_τ ≥ X}) ÷ (1 + N_τ). Trennschärfe: kleinste Trefferzahl mit p < α und die Wahrscheinlichkeit dafür bei
    p0 + 5 bzw. + 9 Prozentpunkten (Normalnäherung mit der Streuung der X_τ). Zum Vergleich p bei unabhängigen Trades (Poisson-binomial).
    """
    nan = float("nan"); n = int(H.shape[0]); X = int(np.sum(treffer_echt)); Xt = H.sum(axis=0); N = len(Xt)
    if not n or not N:
        return {"n": n, "x": X, "erwartet": nan, "sd": nan, "p": nan, "x_krit": None, "macht": {0.05: nan, 0.09: nan}, "p0_mittel": nan,
                "N": N, "p_unabhaengig": nan}
    p = float((1 + np.sum(Xt >= X)) / (1 + N))
    x_k = next((k for k in range(n + 1) if (1 + np.sum(Xt >= k)) / (1 + N) < alpha), None)
    E = float(Xt.mean()); sd = float(Xt.std(ddof=1)) if N > 1 else 0.0
    macht = {dp: (1.0 - _phi((x_k - 0.5 - (E + n * dp)) / sd) if (x_k is not None and sd > 0) else nan) for dp in (0.05, 0.09)}
    p0 = H.mean(axis=1)
    return {"n": n, "x": X, "erwartet": E, "sd": sd, "p": p, "x_krit": x_k, "macht": macht, "p0_mittel": float(p0.mean()), "N": N,
            "p_unabhaengig": p_mindestens(poisson_binomial(p0), X)}


def _haelften(tr: list, H: np.ndarray) -> list:
    """KONZEPT 3.5: zeitliche Hälften (bei ungerader Zahl gehört der mittlere Trade zur ersten); erwartet = Mittel über die
    Verschiebungen derselben Trades."""
    n = len(tr)
    if not n:
        return []
    o = np.argsort([t["t_flip"] for t in tr], kind="stable"); m = (n + 1) // 2
    out = []
    for idx in (o[:m], o[m:]):
        x = sum(1 for i in idx if tr[i]["ziel1"]["g"] == 0)
        e = float(H[idx].sum(axis=0).mean()) if len(idx) and H.shape[1] else float("nan")
        out.append({"n": len(idx), "x": x, "erwartet": e, "ok": bool(len(idx)) and bool(np.isfinite(e)) and x >= e})
    return out


def urteil_bed(h1: dict, h2: dict, hf: list, n: int, G: int = MIN_GRUPPEN) -> tuple:
    """KONZEPT 3.6: „bestätigt“ nur, wenn H1 (p < α_H1), H2 (p < 0,05 und Mittel > 0) und beide Hälften gelten; unter 30 Trades oder
    unter 20 Gruppen „nicht prüfbar“. Wörtlich: „auf der Stichprobe des Videos bestätigt“ (KONZEPT 3.6, Hinweis B3 der Durchsicht)."""
    bed = {"h1": bool(np.isfinite(h1["p"]) and h1["p"] < ALPHA_H1), "h2": bool(np.isfinite(h2["p"]) and h2["p"] < ALPHA and h2["mittel"] > 0),
           "haelften": bool(len(hf) == 2 and all(h["ok"] for h in hf)), "n": n >= MIN_TRADES and G >= MIN_GRUPPEN}
    return bed, ("nicht prüfbar" if not bed["n"] else ("bestätigt" if all(bed.values()) else "nicht bestätigt"))


# ================================================================================================ Nachrechnen der Video-Trades

def _finden(sigs: list) -> list:
    gef = []
    for v in VIDEO_TRADES:
        kand = []
        for s in sigs:
            if s["seite"] != v["seite"] or not (v["von"] <= s["k_ts"] < v["bis"]) or s.get("einstieg") is None:
                continue
            if abs(s["einstieg"] / v["einstieg"] - 1.0) > v.get("tol", TOL_EINSTIEG):
                continue
            if "stop" in v and abs(s["stop"] / v["stop"] - 1.0) > TOL_STOP:
                continue
            if "abstand" in v and not (v["abstand"][0] <= s["abstand"] * 100.0 <= v["abstand"][1]):
                continue
            kand.append(s)
        best = min(kand, key=lambda s_: abs(s_["einstieg"] / v["einstieg"] - 1.0)) if kand else None
        nah = [s for s in sigs if s["seite"] == v["seite"] and v["von"] - 20 * TAG <= s["k_ts"] < v["bis"] + 20 * TAG]
        gef.append({"v": v, "s": best, "nah": min(nah, key=lambda s_: abs(s_["k_ts"] - v["von"])) if nah else None})
    return gef


def nachrechnen(sigs: list, sigs_pruef: list | None = None) -> dict:
    """KONZEPT 3.1: die sechs genannten Trades suchen; die Zahl der Signale vom 01.11.2021 bis 17.10.2026 gegen 35 (16/19); kein
    Short-Signal zwischen Trade 1 und Trade 6 („das erste seit dem Short am Allzeithoch“); mit 1.050 Kerzen ist Trade 6 kein Signal
    (sigs_pruef: dieselbe Lesart mit Fenster 1.050; bestanden nur, wenn Trade 6 mit 765 Kerzen gefunden ist -- zweite Durchsicht M3)."""
    gef = _finden(sigs)
    zeit = [s for s in sigs if START_VIDEO <= s["k_ts"] < ENDE_VIDEO]
    n_l = sum(1 for s in zeit if s["seite"] == "long"); n_s = len(zeit) - n_l
    n_g = sum(1 for g in gef if g["s"] is not None)
    luecke = not any(s["seite"] == "short" and LUECKE[0] <= s["k_ts"] < LUECKE[1] for s in sigs)
    pruef = None if sigs_pruef is None else (gef[5]["s"] is not None and _finden(sigs_pruef)[5]["s"] is None)     # 8.4 (M3)
    return {"trades": gef, "gefunden": n_g, "zahl": len(zeit), "long": n_l, "short": n_s, "luecke": luecke, "pruef1050": pruef,
            "abweichung": abs(len(zeit) - VIDEO_ZAHL) + abs(n_l - VIDEO_LONG) + abs(n_s - VIDEO_SHORT),
            "nachgebaut": n_g >= MIN_GEFUNDEN and abs(len(zeit) - VIDEO_ZAHL) <= TOL_ZAHL}


def lesart_waehlen(nach: dict) -> str:
    """KONZEPT 3.2 (nach der Durchsicht ergänzt, vor jedem Lauf): mehr gefundene Trades; dann kein Short in der Lücke; dann die Probe mit
    1.050 Kerzen; dann die kleinere Abweichung |n − 35| + |Long − 16| + |Short − 19|; dann A. Bekommt nur das Nachrechnen."""
    return max(LESARTEN, key=lambda la: (nach[la]["gefunden"], bool(nach[la]["luecke"]), bool(nach[la]["pruef1050"]),
                                         -nach[la]["abweichung"], la == "rang"))


# ================================================================================================ Studie

def _konto(R: list) -> dict:
    """Summe R × 2 % (einfach addiert wie im Video, kein Konto); Rückgang in R über die geschlossenen Trades in Ausstiegsfolge."""
    if not R:
        return {"summe_R": 0.0, "konto": 0.0, "dd": 0.0, "ohne_besten": 0.0}
    r = np.asarray(R, dtype=float); k = np.concatenate([[0.0], np.cumsum(r)])
    return {"summe_R": float(r.sum()), "konto": float(r.sum()) * RISIKO_VIDEO * 100, "dd": float(np.max(np.maximum.accumulate(k) - k)),
            "ohne_besten": float(r.sum() - r.max()) * RISIKO_VIDEO * 100}


def sorted_r(tr: list, key: str) -> list:
    return [t[key]["netto"] for t in sorted(tr, key=lambda t_: t_[key].get("t_aus", t_["t_in"])) if t[key]["g"] != 4]


def labor_abgleich(tr: list) -> dict:
    """KONZEPT 4.9: Signale, die das Labor (eine Position je Strategie) wegen einer offenen Position ausgelassen hätte (Hauptregel)."""
    frei = -1; aus = []
    for t in sorted(tr, key=lambda t_: t_["t_in"]):
        if t["t_in"] < frei:
            aus.append(t); continue
        frei = t["ziel1"]["t_aus"] if t["ziel1"]["g"] != 4 else 2 ** 62
    return {"ausgelassen": aus}


def urteils_signale(sigs: list, D: dict, ab_ts: int = START_VIDEO) -> list:
    """KONZEPT 3.7: Signale des Urteils -- Flip-Kerze beginnt ab ab_ts und schließt mehr als 120 Tage vor dem Datenende (feste Grenze,
    unabhängig vom Ausgang; strikt, damit die Kerze zur Zeitgrenze in den Daten liegt und jeder Trade mit Ziel, Stop oder Zeit endet --
    zweite Durchsicht M1, KONZEPT 8.4)."""
    return [s for s in sigs if s["k_ts"] >= ab_ts and s["t_flip"] + MAX_TAGE * TAG < D["ende"]]


def auswerten(D: dict, P: Passage, sigs: list, beschreibend: bool = True, ab_ts: int = START_VIDEO, skala: bool = True) -> dict:
    """Hauptregel mit H1/H2/Hälften/Mindestzahlen (KONZEPT 3.3–3.6) auf den Signalen sigs (vorher urteils_signale) und, wenn
    beschreibend, die Varianten und Stufen gegen dieselben Trades in den Verschiebungen (4.3, 4.4), mit Cluster-robusten Intervallen;
    dazu H1 ohne Skalierung (beschreibend) und die Befunde zur Kalibrierung (4.10)."""
    tr = trades_rechnen(D, P, sigs)
    erl = [t for t in tr if t["ziel1"]["g"] != 4]
    Vs = verschiebungen(D, ab_ts, [t["T"] for t in erl]) if erl else None
    nN = len(Vs["taus"]) if Vs else 0
    H = np.zeros((len(erl), nN), dtype=bool); Hu = np.zeros((len(erl), nN), dtype=bool); Z = np.zeros((len(erl), nN), dtype=bool)
    zuf = []; offen_v = 0; ohne_s = 0
    for k, t in enumerate(erl):
        T8 = Vs["pool"][(Vs["pos"][k] + Vs["taus"]) % Vs["L"]]
        j0 = np.searchsorted(D["ts"], D["k_ts"][T8] + K8, side="left")
        z = _trades_an(D, P, t, T8, j0, beschreibend, skala=skala)
        H[k] = z["treffer"] & z["erledigt"]; Z[k] = z["zeit"]; offen_v += int(np.sum(~z["erledigt"])); ohne_s += z["ohne_sigma"]; zuf.append(z)
        if beschreibend:
            Hu[k] = _trades_an(D, P, t, T8, j0, False, skala=False)["treffer"]
    h1 = h1_verschiebung([t["ziel1"]["g"] == 0 for t in erl], H)
    ids = cluster_ids(erl) if erl else np.zeros(0, dtype=np.int64)
    h2 = t_cluster([t["ziel1"]["netto"] for t in erl], ids)
    hf = _haelften(erl, H)
    G = int(len(set(ids.tolist())))
    bed, urteil = urteil_bed(h1, h2, hf, len(erl), G)
    A = {"trades": tr, "erledigt": erl, "offen": [t for t in tr if t["ziel1"]["g"] == 4], "h1": h1, "h2": h2, "haelften": hf,
         "bed": bed, "urteil": urteil, "verschiebungen": nN, "offen_verschoben": offen_v, "ohne_sigma": ohne_s, "gruppen": G,
         "p0": H.mean(axis=1) if nN else np.zeros(len(erl)), "H": H}
    if beschreibend and erl and nN:
        A["h1_unskaliert"] = h1_verschiebung([t["ziel1"]["g"] == 0 for t in erl], Hu)
        V = {}
        for key, _txt in VARIANTEN:
            echt_k = np.array([t[key]["kurs"] for t in erl]); echt_n = np.array([t[key]["netto"] for t in erl])
            zk = np.array([z["mittel"][key]["kurs"] for z in zuf]); zn = np.array([z["mittel"][key]["netto"] for z in zuf])
            V[key] = {"n": len(erl), "treffer": sum(1 for t in erl if t[key].get("g") == 0) if key.startswith("ziel") else None,
                      "kurs": float(echt_k.mean()), "netto": float(echt_n.mean()), "zufall_kurs": float(zk.mean()),
                      "zufall_netto": float(zn.mean()), "vorteil": t_cluster(echt_n - zn, ids), "konto": _konto(sorted_r(erl, key))}
        A["varianten"] = V
        S = {}
        for L in STUFEN:
            x = np.array([1.0 if t["stufen120"][L] else 0.0 for t in erl]); e = np.array([z["stufen120"][L] for z in zuf])
            S[L] = {"x": int(x.sum()), "n": len(erl), "zufall": float(e.mean()), "abstand": t_cluster(x - e, ids)}
        A["stufen"] = S
        A["zerlegung"] = {k: float(np.mean([t["ziel1"][k] for t in erl])) for k in ("kurs", "abstand", "gebuehren", "funding", "netto")}
        # Befunde (4.10): Schwankung beim Einstieg, Zeitgrenze je Stop-Band, Überlappung, Kerzen-Befunde
        sig_echt = np.array([t["sigma"] for t in erl]); sig_pool = sigma_an(D, np.searchsorted(D["ts"], D["k_ts"][Vs["pool"]] + K8))
        band = []
        for lo, hi in BAENDER:
            m_ = np.array([lo <= t["abstand"] < hi for t in erl])
            if m_.any():
                band.append({"lo": lo, "hi": hi, "n": int(m_.sum()), "zeit_echt": float(np.mean([erl[i]["ziel1"]["g"] == 2 for i in np.nonzero(m_)[0]])),
                             "zeit_versch": float(Z[m_].mean())})
        paare_gleich = paare_gegen = 0
        for i in range(len(erl)):
            for j in range(i + 1, len(erl)):
                a_, b_ = erl[i], erl[j]
                if a_["t_in"] < b_["ziel1"]["t_aus"] and b_["t_in"] < a_["ziel1"]["t_aus"]:
                    if a_["seite"] == b_["seite"]:
                        paare_gleich += 1
                    else:
                        paare_gegen += 1
        A["befunde"] = {"sigma_echt": float(np.nanmedian(sig_echt)), "sigma_pool": float(np.nanmedian(sig_pool)), "baender": band,
                        "paare_gleich": paare_gleich, "paare_gegen": paare_gegen,
                        "in_gruppen": int(sum(1 for g_ in np.bincount(ids) if g_ >= 2)),
                        "stop_einstieg": sum(1 for t in erl if t["stop_einstiegskerze"]), "gleichstand": sum(1 for t in erl if t["gleichstand"])}
    return A


def lage_jetzt(D: dict, R: dict, lesart: str) -> dict:
    """KONZEPT 4.8: Lage seit dem letzten Flip an der letzten 8-h-Kerze -- wäre der nächste Flip ein Signal, mit welchem Stop?"""
    T = D["n8"] - 1
    d = float(D["e_kurz"][T] - D["e_lang"][T]); lage = "bullisch" if d > 0 else ("bärisch" if d < 0 else "gleich")
    fi = D["flip_idx"]; b = int(fi[-1]) if len(fi) else -1
    s = schwellen(D, T, int(R["fenster"]), lesart, float(R["anteil"]))
    out = {"T": T, "k_ts": int(D["k_ts"][T]), "schluss": float(D["k_c"][T]), "lage": lage, "seit": int(D["k_ts"][b]) + K8 if b >= 0 else None,
           "e_kurz": float(D["e_kurz"][T]), "e_lang": float(D["e_lang"][T])}
    if s is not None:
        a = max(b + 1, T - int(R["fenster"]) + 1)
        if d > 0:                                                              # nächster Flip wäre bärisch: rote Kerzen seit b?
            w = D["k_h"][a:T + 1]; sel = w >= s[0]
            out["naechster"] = {"seite": "short", "n": int(sel.sum()), "extrem": float(w[sel].max()) if sel.any() else None,
                                "stop": float(w[sel].max()) * (1 + R["stop_puffer"]) if sel.any() else None, "schwelle": s[0]}
        elif d < 0:
            w = D["k_l"][a:T + 1]; sel = w <= s[1]
            out["naechster"] = {"seite": "long", "n": int(sel.sum()), "extrem": float(w[sel].min()) if sel.any() else None,
                                "stop": float(w[sel].min()) * (1 - R["stop_puffer"]) if sel.any() else None, "schwelle": s[1]}
    return out


def video_vergleich(tr: list, letzt_flip: int | None = None) -> dict:
    """KONZEPT 4.2: die Signale vor dem jüngsten wie im Video gezählt (ohne Kosten, dann mit Kosten; ohne Zeitgrenze wie im Video).
    letzt_flip: Flip-Zeit des jüngsten Signals, auch wenn es keinen Trade hatte (sonst der jüngste Trade; zweite Durchsicht N5)."""
    if letzt_flip is None:
        letzt_flip = max((t["t_flip"] for t in tr), default=0)
    tr = sorted((t for t in tr if t["t_flip"] < letzt_flip), key=lambda t: t["t_flip"])
    if not tr:
        return {}
    out = {"n": len(tr), "ein_r": sum(1 for t in tr if t["stufen"][1.0]), "zwei_r": sum(1 for t in tr if t["stufen"][2.0]),
           "fast_sofort": sum(1 for t in tr if t["fast_sofort"]), "im_stop": sum(1 for t in tr if t["im_stop"])}
    for art in ("kurs", "netto"):
        perf = [t["mfe"] for t in tr]; lauf = [t["laufen"][art] for t in tr]
        out[art] = {"perfekt": float(np.sum(perf)) * RISIKO_VIDEO * 100, "laufen": float(np.sum(lauf)) * RISIKO_VIDEO * 100,
                    "laufen_ohne_besten": (float(np.sum(lauf)) - float(np.max(lauf))) * RISIKO_VIDEO * 100,
                    "bester": max(tr, key=lambda t: t["laufen"][art])}
    return out


def studie_rechnen(K: dict, F: dict | None, jetzt: int | None = None, log=lambda s: None, empf: bool = True) -> dict:
    """Die ganze Studie (KONZEPT 3 und 4) auf den 30-min-Kerzen K und dem Funding F."""
    t0 = time.time(); lz = {}
    D = daten(K, F, bis=jetzt)
    if D is None or D["n8"] < FENSTER + 10:
        return {"fehler": "zu wenige Kerzen", "D": D}
    P = Passage(D["h"], D["l"]); lz["daten"] = time.time() - t0
    log(f"{D['n']} Kerzen à 30 min, {D['n8']} Kerzen à 8 h")
    sig = {la: signale(D, REGELN, la) for la in LESARTEN}
    sig_p = {la: signale(D, dict(REGELN, fenster=FENSTER_PRUEF), la, ab_ts=LUECKE[1]) for la in LESARTEN}
    nach = {la: nachrechnen(sig[la], sig_p[la]) for la in LESARTEN}
    wahl = lesart_waehlen(nach); lz["signale"] = time.time() - t0
    log(f"Lesart {LESART_TXT[wahl]} gewählt (gefunden A {nach['rang']['gefunden']}, B {nach['spanne']['gefunden']})")
    # Urteil (KONZEPT 3.7): Daten bis zum Stichtag, Signale ab 01.11.2021, die 120 Tage vor dem Datenende geschlossen haben
    vorlaeufig = D["ende"] < STICHTAG
    Du = D if vorlaeufig or D["ende"] == STICHTAG else daten(K, F, bis=STICHTAG)
    Pu = P if Du is D else Passage(Du["h"], Du["l"])
    sig_u = urteils_signale(signale(Du, REGELN, wahl), Du) if Du is not D else urteils_signale(sig[wahl], Du)
    A = auswerten(Du, Pu, sig_u, beschreibend=True); lz["haupt"] = time.time() - t0
    log(f"Urteil: {len(A['erledigt'])} Trades in {A['gruppen']} Gruppen, {A['urteil']}" + (" (vorläufig)" if vorlaeufig else ""))
    # beschreibend auf allen Daten: alle Signale ab 01.11.2021 (auch die jüngsten und offenen)
    alle_tr = trades_rechnen(D, P, sig[wahl])
    haupt_tr = [t for t in alle_tr if t["k_ts"] >= START_VIDEO]
    p0 = {t["T"]: float(p_) for t, p_ in zip(A["erledigt"], A["p0"])}
    for t in haupt_tr:
        t["p0"] = p0.get(t["T"]); t["im_urteil"] = t["T"] in p0
    # vor dem Zeitraum des Videos (B3): dieselbe Prüfung beschreibend, Verschiebung über die ganze Spanne
    vor_sig = [s for s in sig[wahl] if s["k_ts"] < START_VIDEO and s["t_flip"] + MAX_TAGE * TAG <= Du["ende"]]
    vor = auswerten(Du, Pu, vor_sig, beschreibend=False, ab_ts=int(Du["k_ts"][0]))
    kontrolle = auswerten(Du, Pu, urteils_signale(signale(Du, REGELN, wahl, ohne_extrem=True), Du), beschreibend=False)
    lz["kontrolle"] = time.time() - t0
    E = {}
    if empf:
        reihen = [(la, fe, "T", "alle") for la in LESARTEN for fe in FENSTER_EMPF] + [(la, FENSTER, "i", "alle") for la in LESARTEN] \
                 + [(la, FENSTER, "T", "block") for la in LESARTEN]
        for la, fe, fa, sa in reihen:
            R_ = dict(REGELN, fenster=fe)
            s_ = sig[la] if (fe == FENSTER and fa == "T" and sa == "alle") else signale(D, R_, la, fenster_art=fa, stop_art=sa)
            n_ = nachrechnen(s_)
            su = s_ if Du is D else signale(Du, R_, la, fenster_art=fa, stop_art=sa)
            a_ = auswerten(Du, Pu, urteils_signale(su, Du), beschreibend=False)
            E[(la, fe, fa, sa)] = {"signale": n_["zahl"], "gefunden": n_["gefunden"], "luecke": n_["luecke"], "n": len(a_["erledigt"]),
                                   "x": a_["h1"]["x"], "erwartet": a_["h1"]["erwartet"], "netto": a_["h2"]["mittel"]}
        lz["empf"] = time.time() - t0
    stand = lage_jetzt(D, REGELN, wahl)
    sig_ab = [s for s in sig[wahl] if s["k_ts"] >= START_VIDEO]
    letzt_sig = max(sig_ab, key=lambda s_: s_["t_flip"]) if sig_ab else None
    if alle_tr:
        stand["letzter"] = max(alle_tr, key=lambda t_: t_["t_flip"])
    if letzt_sig is not None and letzt_sig.get("kein"):
        stand["letztes_kein"] = letzt_sig                                  # jüngstes Signal ohne Trade (zweite Durchsicht N5)
    pruef = hashlib.sha1("|".join(f"{s['k_ts']}:{s['seite']}:{s['stop']:.2f}" for s in sig_u).encode()).hexdigest()[:12]
    lz["gesamt"] = time.time() - t0
    return {"D": {k: D[k] for k in ("n", "n8", "ende", "luecken8")} | {"von": int(D["ts"][0]), "k_nicht_voll": int((~D["k_voll"]).sum()),
            "funding": int(len(D.get("f_ts", [])))}, "ende_urteil": Du["ende"], "vorlaeufig": vorlaeufig, "nach": nach, "wahl": wahl,
            "haupt": A, "alle": haupt_tr, "vor": vor, "kontrolle": kontrolle, "empf": E, "stand": stand,
            "vergleich": video_vergleich(haupt_tr, letzt_sig["t_flip"] if letzt_sig else None), "abgleich": labor_abgleich(haupt_tr),
            "pruefsumme": pruef, "laufzeit": lz, "signale": sig_ab}


# ================================================================================================ Bericht

def _sig_zeile(t: dict) -> str:
    z1 = t["ziel1"]; g = GRUND[z1["g"]]
    p0 = t.get("p0")
    return (f"  {_zeit(t['k_ts'])}  {t['seite']:<5} Einstieg {_px(t['einstieg']):>8}  Stop {_px(t['stop']):>8} ({_de(t['abstand'] * 100, 1)} %)  "
            f"1R: {g:<6} {_de(z1['netto'], 2, True):>6} R  bis Stop: {_de(t['laufen']['kurs'], 1, True):>6} R"
            f"{' (offen)' if t['laufen']['g'] == 4 else ''}  bestes {_de(t['mfe'], 1)} R"
            + (f"  p0 {_de(p0 * 100, 0)} %" if p0 is not None else ("  (nicht im Urteil)" if "im_urteil" in t else "")))


def bericht_text(V: dict, kopf_extra: str = "") -> str:
    if V.get("fehler"):
        return f"★ Wende (U226): {V['fehler']}"
    D = V["D"]; A = V["haupt"]; w = V["wahl"]; z = []
    z.append(f"★ Wende: Extrem-Wende nach Video (BTC 8 h, U226) — Version {VERSION_MODUL}{kopf_extra}")
    z.append("Regeln vorab: KONZEPT_Wende.md (25.10.2026, beim Bau geändert und kalibriert vor jedem Lauf auf echten Daten). Liest nur "
             "swing.db (Binance-USDT-Perpetual BTC, 30-min-Kerzen).")
    z.append(f"Daten: {_zeit(D['von'])} bis {_zeit(D['ende'])} UTC, {_tsd(D['n'])} Kerzen à 30 min, {_tsd(D['n8'])} à 8 h "
             f"(nicht voll {D['k_nicht_voll']}, Lücken {D['luecken8']}); Funding {_tsd(D['funding'])} Zahlungen.")
    z.append(f"Prüfsumme der Signale im Urteil: {V['pruefsumme']}")
    nw = V["nach"][w]
    if not nw["nachgebaut"]:                                                   # KONZEPT 3.2 (zweite Durchsicht M4)
        z.append(f"ACHTUNG: Die gewählte Lesart {LESART_TXT[w]} hat die Video-Trades nicht nachgebaut ({nw['gefunden']} von 6 gefunden, "
                 f"{nw['zahl']} Signale statt 35) -- das Urteil gilt für unsere Fassung der Regeln, nicht für die des Videos.")
    z.append("")
    z.append("1. Nachrechnen der Video-Trades (Positivkontrolle, KONZEPT 3.1) und Wahl der Lesart (3.2)")
    for la in LESARTEN:
        n = V["nach"][la]
        z.append(f"   Lesart {LESART_TXT[la]}: {n['gefunden']} von 6 gefunden; {n['zahl']} Signale 01.11.2021–17.10.2026 ({n['long']} Long, "
                 f"{n['short']} Short; Video 35: 16/19); kein Short zwischen Trade 1 und 6: {'ja' if n['luecke'] else 'nein'}; Trade 6 "
                 f"mit 765, nicht mit 1.050 Kerzen: {'ja' if n['pruef1050'] else 'nein'} → {'nachgebaut' if n['nachgebaut'] else 'nicht nachgebaut'}")
    z.append(f"   Gewählt: Lesart {LESART_TXT[w]}" + ("" if V["nach"][w]["nachgebaut"] else
             " — auch sie weicht ab: das Urteil gilt für unsere Fassung der Regeln"))
    for g in V["nach"][w]["trades"]:
        v = g["v"]; s = g["s"]
        if s:
            z.append(f"   {v['nr']}. {v['text']}: gefunden — Flip {_zeit(s['k_ts'])}, Einstieg {_px(s['einstieg'])}, Stop {_px(s['stop'])} "
                     f"({_de(s['abstand'] * 100, 1)} %); Video: {v['neben']}")
        else:
            nah = g["nah"]
            z.append(f"   {v['nr']}. {v['text']}: nicht gefunden" + (f" (nächstes: {nah['seite']} {_zeit(nah['k_ts'])}, Einstieg "
                     f"{_px(nah.get('einstieg'))}, Stop {_px(nah['stop'])})" if nah else " (kein Signal derselben Richtung in der Nähe)"))
    z.append("")
    h1, h2 = A["h1"], A["h2"]
    titel = {"bestätigt": "AUF DER STICHPROBE DES VIDEOS BESTÄTIGT", "nicht bestätigt": "NICHT BESTÄTIGT", "nicht prüfbar": "NICHT PRÜFBAR"}
    z.append(f"2. Urteil — Hauptregel Ziel 1R, Lesart {LESART_TXT[w]}, Flip-Kerzen ab 01.11.2021, Datenende {_zeit(V['ende_urteil'])} UTC: "
             f"{titel[A['urteil']]}" + (" (VORLÄUFIG: Stichtag 27.10.2026 noch nicht erreicht)" if V["vorlaeufig"] else "")
             + ("" if nw["nachgebaut"] else " -- über unsere Fassung der Regeln (nicht nachgebaut)"))
    if A["offen"]:                                                             # KONZEPT 3.7: darf nicht vorkommen (zweite Durchsicht M1)
        z.append(f"   ACHTUNG: {len(A['offen'])} Trade(s) des Urteils ohne Ausgang (Lücke in den Daten am Ende?) -- nicht gezählt; das "
                 "verletzt die feste Grenze (KONZEPT 3.7)")
    z.append(f"   {h1['n']} Trades (Schluss der Flip-Kerze mehr als 120 Tage vor dem Datenende) in {A['gruppen']} Gruppen überlappender "
             f"Trades; Treffer {h1['x']} ({_proz(h1['x'], h1['n'])}), in den Verschiebungen erwartet {_de(h1['erwartet'], 1)} "
             f"({_de(h1['p0_mittel'] * 100, 0)} %, Streuung {_de(h1['sd'], 1)}) — H1 p {_pz(h1['p'])} (einseitig, {_tsd(h1['N'])} "
             f"Verschiebungen um mindestens 120 Tage, Stop-Abstand nach der Schwankung skaliert; Schwelle {_de(ALPHA_H1, 3)}) "
             f"{'✓' if A['bed']['h1'] else '✗'}")
    hu = A.get("h1_unskaliert")
    z.append("   beschreibend: " + (f"ohne Skalierung (gleicher Abstand in %) p {_pz(hu['p'])} bei {_de(hu['erwartet'], 1)} erwarteten Treffern; "
                                    if hu else "") + f"unabhängig gerechnet (Poisson-binomial) p {_pz(h1['p_unabhaengig'])}")
    z.append(f"   Ø R netto je Trade {_de(h2['mittel'], 2, True)} (90 %: {_de(h2['lo'], 2, True)} … {_de(h2['hi'], 2, True)}; "
             f"{h2['G']} Gruppen), t {_de(h2['t'], 2)}, H2 p {_pz(h2['p'])} {'✓' if A['bed']['h2'] else '✗'}")
    if A["haelften"]:
        z.append("   Hälften: " + "; ".join(f"{i + 1}.: {h['x']} Treffer gegen {_de(h['erwartet'], 1)} erwartet ({h['n']} Trades)"
                                            for i, h in enumerate(A["haelften"])) + f" {'✓' if A['bed']['haelften'] else '✗'}")
    z.append(f"   Mindestzahl 30 Trades in 20 Gruppen: {'✓' if A['bed']['n'] else '✗'}")
    if h1["x_krit"] is not None:
        z.append(f"   Trennschärfe: H1 wäre ab {h1['x_krit']} Treffern erfüllt ({_proz(h1['x_krit'], h1['n'])}); Wahrscheinlichkeit dafür bei "
                 f"p0 + 5 Pp. {_de(h1['macht'][0.05] * 100, 0)} %, bei p0 + 9 Pp. {_de(h1['macht'][0.09] * 100, 0)} % (Video: rund 5 Pp. "
                 "besser als Zufall)")
    z.append("   „Bestätigt“ hieße: auf der Stichprobe, auf der der Autor das Setup gezeigt hat, nicht von Glück zu trennen -- ein unabhängiger "
             "Beleg sind erst die Signale vor November 2021 (8.) und das Labor. „Nicht bestätigt“ heißt nicht: widerlegt.")
    z.append("")
    vv = V["vergleich"]
    if vv:
        z.append(f"3. Vergleich mit dem Video (die {vv['n']} Signale ab November 2021 vor dem jüngsten; Video: 34; ohne Zeitgrenze wie dort)")
        z.append(f"   mindestens 1R vor dem Stop {vv['ein_r']} (Video 20), mindestens 2R {vv['zwei_r']} (Video 9), praktisch sofort "
                 f"ausgestoppt {vv['fast_sofort']} (Video 8), laufen gelassen irgendwann im Stop {vv['im_stop']} (Video 29)")
        for art, txt in (("kurs", "ohne Kosten (wie im Video)"), ("netto", "mit Kosten")):
            q = vv[art]; b = q["bester"]
            z.append(f"   {txt}, Summe R × 2 % (einfach addiert, kein Konto): " + (f"perfekt (Obergrenze im Nachhinein) "
                     f"{_de(q['perfekt'], 0, True)} % (Video über +700 %), " if art == "kurs" else "") + f"bis zum Stop laufen lassen "
                     f"{_de(q['laufen'], 0, True)} % (Video rund +350 %), ohne den besten Trade ({b['seite']} {_datum(b['k_ts'])}) "
                     f"{_de(q['laufen_ohne_besten'], 0, True)} % (Video über −20 %)")
        z.append("")
    if A.get("varianten"):
        z.append("4. Ausstiege im Vergleich (Trades des Urteils, alle höchstens 120 Tage; verschoben = dieselben Trades in den Verschiebungen)")
        z.append(f"   {'Variante':<34}{'Treffer':>8}{'Ø R Kurs':>10}{'Ø R netto':>11}{'verschoben':>12}{'Vorteil (90 %)':>26}"
                 f"{'Summe R':>9}{'Σ R × 2 %':>11}{'Rückg. R':>10}")
        for key, txt in VARIANTEN:
            q = A["varianten"][key]; v_ = q["vorteil"]; k = q["konto"]
            z.append(f"   {txt:<34}{(str(q['treffer']) if q['treffer'] is not None else '—'):>8}{_de(q['kurs'], 2, True):>10}"
                     f"{_de(q['netto'], 2, True):>11}{_de(q['zufall_netto'], 2, True):>12}"
                     f"{(_de(v_['mittel'], 2, True) + ' (' + _de(v_['lo'], 2, True) + ' … ' + _de(v_['hi'], 2, True) + ')'):>26}"
                     f"{_de(k['summe_R'], 1, True):>9}{(_de(k['konto'], 0, True) + ' %'):>11}{_de(k['dd'], 1):>10}")
        z.append("   Σ R × 2 %: einfach addiert wie im Video, kein Konto (Trades überlappen); Rückgang über die geschlossenen Trades in "
                 "Ausstiegsfolge. Intervalle mit Gruppen überlappender Trades.")
        z.append("")
        z.append("5. Treffer je Stufe vor dem Stop (höchstens 120 Tage) gegen die Verschiebungen (Video: bis 1R rund 5 Punkte besser, "
                 "danach Münzwurf)")
        for L, q in A["stufen"].items():
            a_ = q["abstand"]
            z.append(f"   {_de(L, 1)} R: {q['x']} von {q['n']} = {_proz(q['x'], q['n'])}, verschoben {_de(q['zufall'] * 100, 0)} %, Abstand "
                     f"{_de(a_['mittel'] * 100, 0, True)} Punkte (90 %: {_de(a_['lo'] * 100, 0, True)} … {_de(a_['hi'] * 100, 0, True)})")
        z.append("")
    K_ = V["kontrolle"]
    z.append(f"6. Kontrolle „Flip ohne Extrem“ (jeder Flip, Hauptregel, gleiche Spanne): {K_['h1']['n']} Trades, Treffer {K_['h1']['x']} "
             f"({_proz(K_['h1']['x'], K_['h1']['n'])}) gegen {_de(K_['h1']['erwartet'], 1)} erwartet, Ø R netto {_de(K_['h2']['mittel'], 2, True)} "
             f"— die Strategie: {h1['x']} von {h1['n']} gegen {_de(h1['erwartet'], 1)}, Ø {_de(h2['mittel'], 2, True)} R")
    z.append("")
    if V["empf"]:
        z.append("7. Empfindlichkeit (nur beschreibend; ohne p, weil hier viele Varianten nebeneinander stehen)")
        z.append(f"   {'Lesart':<12}{'Fenster':>8}{'Färbung':>9}{'Stop':>8}{'Signale':>9}{'gefunden':>10}{'Lücke':>7}{'Trades':>8}"
                 f"{'Treffer':>9}{'erwartet':>10}{'Ø R netto':>11}")
        for (la, fe, fa, sa), q in V["empf"].items():
            z.append(f"   {LESART_TXT[la]:<12}{fe:>8}{('je Kerze' if fa == 'i' else 'bei T'):>9}{('Block' if sa == 'block' else 'alle'):>8}"
                     f"{q['signale']:>9}{q['gefunden']:>10}{('ja' if q['luecke'] else 'nein'):>7}{q['n']:>8}{q['x']:>9}"
                     f"{_de(q['erwartet'], 1):>10}{_de(q['netto'], 2, True):>11}")
        best = max(V["empf"].items(), key=lambda kv: (kv[1]["gefunden"], kv[1]["luecke"]))
        if best[1]["gefunden"] > V["nach"][w]["gefunden"]:
            la, fe, fa, sa = best[0]
            z.append(f"   HINWEIS: die Variante {LESART_TXT[la]}, Fenster {fe}, Färbung {'je Kerze' if fa == 'i' else 'bei T'}, Stop "
                     f"{'Block' if sa == 'block' else 'alle'} trifft {best[1]['gefunden']} Video-Trades (die gewählte {V['nach'][w]['gefunden']}) "
                     "-- das Urteil bleibt bei der gewählten; ein Wechsel wäre ein eigener Plan-Punkt (KONZEPT 4.6)")
        z.append("")
    vo = V["vor"]
    z.append(f"8. Vor dem Zeitraum des Videos (ab der 765. Kerze bis Oktober 2021, außerhalb der Stichprobe des Autors; Erwartung: mehr "
             f"Treffer als verschoben): {vo['h1']['n']} Trades, Treffer {vo['h1']['x']} gegen {_de(vo['h1']['erwartet'], 1)} erwartet, "
             f"p {_pz(vo['h1']['p'])} (beschreibend), Ø R netto {_de(vo['h2']['mittel'], 2, True)}")
    for t in vo["trades"]:
        z.append(_sig_zeile(t))
    z.append("")
    z.append(f"9. Signalliste ab 01.11.2021 (Lesart {LESART_TXT[w]}; Zeit = Beginn der Flip-Kerze, UTC; alle Daten bis jetzt)")
    for t in sorted(V["alle"], key=lambda t_: t_["t_flip"]):
        z.append(_sig_zeile(t))
    for s in [s for s in V["signale"] if s.get("kein")]:
        z.append(f"  {_zeit(s['k_ts'])}  {s['seite']:<5} kein Trade: {s['kein']}")
    z.append("")
    st = V["stand"]
    z.append(f"10. Stand jetzt (letzte 8-h-Kerze {_zeit(st['k_ts'])} UTC, Schluss {_px(st['schluss'])})")
    z.append(f"   Ribbon {st['lage']}" + (f" seit {_zeit(st['seit'])}" if st.get("seit") else "") + f" (EMA 8 {_px(st['e_kurz'])}, EMA 89 {_px(st['e_lang'])})")
    nx = st.get("naechster")
    if nx:
        farbe = "rote" if nx["seite"] == "short" else "blaue"
        z.append(f"   seit dem letzten Flip {nx['n']} {farbe} Kerzen (Schwelle {_px(nx['schwelle'])})" +
                 (f" → der nächste Flip wäre ein {nx['seite'].capitalize()}-Signal, Stop {_px(nx['stop'])} (das Fenster wandert mit)"
                  if nx["n"] else " → der nächste Flip wäre kein Signal"))
    lk = st.get("letztes_kein")
    if lk:
        z.append(f"   jüngstes Signal: {lk['seite']} {_zeit(lk['k_ts'])}, kein Trade ({lk['kein']})")
    lt = st.get("letzter")
    if lt:
        z1 = lt["ziel1"]; R = lt["R"]; sv = lt["sv"]
        haupt = (f"offen ({_de(z1['netto'], 2, True)} R netto zum letzten Schluss)" if z1["g"] == 4 else
                 f"{GRUND[z1['g']]} am {_zeit(z1['t_aus'])} ({_de(z1['netto'], 2, True)} R netto)")
        z.append(f"   {'jüngster Trade' if lk else 'jüngstes Signal'}: {lt['seite']} {_zeit(lt['k_ts'])}, Einstieg {_px(lt['einstieg'])}, Stop {_px(lt['stop'])}, 1R "
                 f"{_px(lt['einstieg'] + sv * R)}, 2R {_px(lt['einstieg'] + 2 * sv * R)}, 3R {_px(lt['einstieg'] + 3 * sv * R)}; Hauptregel "
                 f"{haupt}; bestes Zwischenhoch {_de(lt['mfe'], 2)} R")
    z.append("")
    ab = V["abgleich"]["ausgelassen"]
    z.append(f"11. Labor-Abgleich: {len(ab)} Signale ab November 2021 hätte das Labor (eine Position je Strategie) wegen einer offenen "
             f"Position ausgelassen" + (": " + ", ".join(f"{t['seite']} {_datum(t['k_ts'])}" for t in ab) if ab else "")
             + ". Die Labor-Trades selbst liest die Studie nicht: Das Labor handelt erst seit dem Einspielen (Welt B; Welt A sperrt "
             "Longs); dieselbe Prüfung auf den Labor-Trades folgt ab 30 Trades (KONZEPT 3.6).")
    if A.get("zerlegung"):
        q = A["zerlegung"]
        z.append(f"   Zerlegung je Trade (Hauptregel, Ø in R): Kurs {_de(q['kurs'], 3, True)}, Abstand zur Mitte {_de(q['abstand'], 3, True)}, "
                 f"Gebühren {_de(q['gebuehren'], 3, True)}, Funding {_de(q['funding'], 3, True)} = netto {_de(q['netto'], 3, True)}")
    bf = A.get("befunde")
    if bf:
        z.append("")
        z.append("12. Befunde zur Prüfung (KONZEPT 4.10)")
        z.append(f"   Schwankung je 30 min vor dem Einstieg (Median): Signale {_de(bf['sigma_echt'] * 100, 3)} %, alle erlaubten Einstiege "
                 f"{_de(bf['sigma_pool'] * 100, 3)} % -- darum skaliert die Verschiebung den Stop-Abstand")
        z.append("   Zeitgrenze (120 Tage) je Stop-Abstand: " + "; ".join(
            f"{_de(b_['lo'] * 100, 0)}–{_de(min(b_['hi'], 9.9) * 100, 0) if b_['hi'] < 9 else '…'} %: {b_['n']} Trades, Zeit {_de(b_['zeit_echt'] * 100, 0)} % "
            f"(verschoben {_de(b_['zeit_versch'] * 100, 0)} %)" for b_ in bf["baender"]))
        z.append(f"   Überlappung: {bf['paare_gleich']} Paare gleicher Richtung, {bf['paare_gegen']} gegensätzlicher; {bf['in_gruppen']} Gruppen mit "
                 f"mehreren Trades; Stop schon in der Einstiegskerze {bf['stop_einstieg']}, Ziel und Stop in derselben Kerze {bf['gleichstand']}")
        z.append(f"   verschobene Einstiege ohne Schwankungswert (unter 240 Renditen; Abstand dann unskaliert): {_tsd(A['ohne_sigma'])} von "
                 f"{_tsd(len(A['erledigt']) * A['verschiebungen'])}")
    z.append("")
    z.append("Laufzeit: " + ", ".join(f"{k} {_de(v, 1)} s" for k, v in V["laufzeit"].items()))
    return "\n".join(z)


def studie(db: str, jetzt: int | None = None) -> str:
    """Debug „★ Wende“: liest swing.db neben der Hauptdatenbank (nur lesend) und rechnet die Studie."""
    t0 = time.time(); pfad = SW.swing_pfad(db)
    print(f"Wende-Studie: Daten in {pfad}", flush=True)
    if not os.path.exists(pfad):
        return f"★ Wende (U226): swing.db fehlt ({pfad}) — der Swing-Takt im Dashboard lädt die Historie."
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        K = SW.kerzen_lesen(con, COIN); F = SW.funding_lesen(con, COIN)
    finally:
        con.close()
    if K is None:
        return "★ Wende (U226): keine BTC-Kerzen in swing.db"
    print(f"  {len(K['ts']):,} Kerzen gelesen ({time.time() - t0:.1f} s); rechnen …".replace(",", "."), flush=True)
    V = studie_rechnen(K, F, jetzt=jetzt, log=lambda s: print(f"  {time.time() - t0:6.1f} s  {s}", flush=True))
    return bericht_text(V, f" · Lauf {_zeit(jetzt or time.time())} UTC")


# ================================================================================================ Labor-Anbindung

_LABOR_CACHE: dict = {}


def _licht(s: dict | None) -> dict | None:
    """Was das Labor von einem Signal braucht (klein: die Welt A bekommt E je Takt als Kopie)."""
    if not s:
        return None
    return {k: s[k] for k in ("seite", "stop", "extrem", "n_extrem", "k_ts", "t_flip", "schluss", "abstand_schluss", "lesart")}


def labor_daten(pfad: str, now: int) -> dict:
    """
    Für hl_labor: Lage und Signale beider Lesarten an der letzten abgeschlossenen 8-h-Kerze vor now, aus den BTC-Kerzen der letzten
    LABOR_TAGE Tage in swing.db (nur lesend). Neu gerechnet nur bei einer neuen 8-h-Kerze; zurück kommt nur Kleines (keine Reihen).
    frisch = diese Kerze ist eben geschlossen (Ende = jüngste 8-h-Grenze ≤ now) und das ist höchstens EIN_FENSTER_S her.
    """
    if not os.path.exists(pfad):
        return {"ok": False, "grund": "swing.db fehlt noch (der Swing-Takt lädt die Historie)"}
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=5)
        try:
            stand = con.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=? AND ts<=?", (COIN, int(now) - BAR)).fetchone()[0]
            if stand is None:
                return {"ok": False, "grund": f"noch keine Kerzen für {COIN} in swing.db"}
            stand = int(stand)
            k8_ende = ((stand + BAR) // K8) * K8                                  # Ende der letzten abgeschlossenen 8-h-Kerze
            c_ = _LABOR_CACHE.get(pfad)
            if c_ and c_[0] == k8_ende:
                W = c_[1]
            else:
                rows = con.execute("SELECT ts, o, h, l, c, v FROM sw_klines WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
                                   (COIN, k8_ende - LABOR_TAGE * TAG, k8_ende)).fetchall()
                if not rows:
                    return {"ok": False, "grund": "noch keine abgeschlossene 8-h-Kerze in swing.db"}
                a_ = np.array(rows, dtype=float)
                D = daten({"ts": a_[:, 0].astype(np.int64), "o": a_[:, 1], "h": a_[:, 2], "l": a_[:, 3], "c": a_[:, 4]}, None)
                if D is None or D["n8"] < FENSTER:
                    return {"ok": False, "grund": f"zu wenige 8-h-Kerzen ({0 if D is None else D['n8']} von {FENSTER})"}
                T = D["n8"] - 1
                W = {"ok": True, "T": T, "t_schluss": int(D["k_ts"][T]) + K8, "stand": stand,
                     "signal": {la: _licht(signal_an(D, T, REGELN, la)) for la in LESARTEN},
                     "lage": {la: lage_jetzt(D, REGELN, la) for la in LESARTEN}}
                _LABOR_CACHE[pfad] = (k8_ende, W)
        finally:
            con.close()
    except sqlite3.Error as e:
        return {"ok": False, "grund": f"swing.db nicht lesbar: {e}"}
    t_s = W["t_schluss"]
    return dict(W, frisch=t_s == (int(now) // K8) * K8 and int(now) - t_s <= EIN_FENSTER_S)


def status_text(R: dict, W: dict, now: int) -> str:
    """Was die Strategie sieht (Live-Tafel)."""
    if not W or not W.get("ok"):
        return (W or {}).get("grund") or "keine 8-h-Kerzen"
    la = R.get("lesart", "rang"); st = (W.get("lage") or {}).get(la) or {}
    t = f"8 h bis {time.strftime('%d.%m. %H:%M', time.gmtime(W['t_schluss']))} UTC · Ribbon {st.get('lage', '—')}" + (
        f" seit {time.strftime('%d.%m. %H:%M', time.gmtime(st['seit']))}" if st.get("seit") else "")
    nx = st.get("naechster")
    if nx:
        farbe = "rote" if nx["seite"] == "short" else "blaue"
        t += f", seitdem {nx['n']} {farbe} Kerzen" + (f" → nächster Flip {nx['seite'].capitalize()}, Stop {_px(nx['stop'])}" if nx["n"]
                                                     else " → nächster Flip kein Signal")
    s = (W.get("signal") or {}).get(la)
    if s and W.get("frisch"):
        t += f" · SIGNAL {s['seite']} (Stop {_px(s['stop'])})"
    return t


# ================================================================================================ Nullmärkte (Kalibrierung, KONZEPT 3.3)

def markt_1min(seed: int, start: int = _t(2020, 1, 1), ende: int = STICHTAG, drift_tag: float = 0.0, vol_sd: float = 0.4,
               phi: float = 0.985, vol_mittel: float = 0.028, p0: float = 7200.0) -> dict:
    """
    Nullmarkt wie in der Durchsicht (Anhang): 1-min-Log-Renditen, Tagesschwankung log-AR(1) (Mittel 2,8 %/Tag, φ 0,985, Streuung des
    Logs 0,4), Kurs ein Martingal (μ = −σ²/2 je Schritt) oder mit fester Drift je Tag; zu 30-min-Kerzen mit echtem Hoch und Tief.
    """
    rng = np.random.default_rng(seed); tage = int((ende - start) // TAG)
    e = rng.normal(0.0, vol_sd * math.sqrt(1.0 - phi * phi), tage); x = np.empty(tage); x[0] = rng.normal(0.0, vol_sd)
    for d in range(1, tage):
        x[d] = phi * x[d - 1] + e[d]
    s_min = np.repeat(vol_mittel * np.exp(x - 0.5 * vol_sd * vol_sd) / math.sqrt(1440.0), 1440)
    r = (-0.5 * s_min * s_min + drift_tag / 1440.0) + s_min * rng.standard_normal(tage * 1440)
    lp = math.log(p0) + np.cumsum(r)
    m = lp.reshape(-1, 30); vor = np.concatenate([[math.log(p0)], lp[:-1]]).reshape(-1, 30)[:, 0]
    return {"ts": start + BAR * np.arange(m.shape[0], dtype=np.int64), "o": np.exp(vor), "h": np.exp(np.maximum(m.max(axis=1), vor)),
            "l": np.exp(np.minimum(m.min(axis=1), vor)), "c": np.exp(m[:, -1])}


def null_lauf(seed: int, drift_tag: float = 0.0, vol_sd: float = 0.4, lesart: str = "rang", skala: bool = True, start: int = _t(2020, 1, 1),
              ende: int = STICHTAG, ab_ts: int = START_VIDEO) -> dict:
    """Ein Nullmarkt durch die ganze Urteilsrechnung (Signale, Grenze, Verschiebung, Skalierung): p von H1, Urteil, Treffer."""
    D = daten(markt_1min(seed, start, ende, drift_tag, vol_sd)); P = Passage(D["h"], D["l"])
    A = auswerten(D, P, urteils_signale(signale(D, REGELN, lesart), D, ab_ts), beschreibend=False, ab_ts=ab_ts, skala=skala)
    return {"p": A["h1"]["p"], "urteil": A["urteil"], "n": A["h1"]["n"], "x": A["h1"]["x"], "e": A["h1"]["erwartet"], "G": A["gruppen"],
            "p2": A["h2"]["p"], "m2": A["h2"]["mittel"]}


def kalibrieren(anzahl: int, variante: str = "null", teil: tuple = (0, 1), seed0: int = 900_000, log=print) -> dict:
    """KONZEPT 3.3/6: Anteil p < α von H1 und Anteil „bestätigt“ auf Nullmärkten; Varianten null (ohne Drift), auf/ab (±0,05 %/Tag),
    regime (Streuung des Logs 0,6), spanne (Lesart B), unskaliert (ohne Skalierung, zum Vergleich). teil (k, m): jeder m-te Markt ab k."""
    par = {"null": {}, "auf": {"drift_tag": 0.0005}, "ab": {"drift_tag": -0.0005}, "regime": {"vol_sd": 0.6}, "spanne": {"lesart": "spanne"},
           "unskaliert": {"skala": False}}[variante]
    res = []; t0 = time.time()
    for i in range(teil[0], anzahl, teil[1]):
        r = null_lauf(seed0 + i, **par); res.append(r)
        if len(res) % 25 == 0:
            log(f"  {len(res)} Märkte, {time.time() - t0:.0f} s")
    p = np.array([r["p"] for r in res], dtype=float); ok = np.isfinite(p)
    return {"variante": variante, "n": int(ok.sum()), "h1": float(np.mean(p[ok] < ALPHA_H1)) if ok.any() else float("nan"),
            "h1_005": float(np.mean(p[ok] < 0.05)) if ok.any() else float("nan"),
            "q05": float(np.quantile(p[ok], 0.05)) if ok.any() else float("nan"),
            "bestaetigt": float(np.mean([r["urteil"] == "bestätigt" for r in res])), "mittel_p": float(np.mean(p[ok])) if ok.any() else float("nan"),
            "ueberschuss": float(np.mean([r["x"] - r["e"] for r in res if np.isfinite(r["e"])])), "trades": float(np.mean([r["n"] for r in res])),
            "p_roh": p.tolist()}


# ================================================================================================ Selbsttest (ohne Netz)

_T0 = 1_609_459_200                    # 01.01.2021 00:00 UTC (8-h-Grenze)
# Goldprobe (KONZEPT 5, Durchsicht D5): Prüfsumme der Signale beider Lesarten auf einem festen erfundenen Weg -- ändert ein Umbau die
# Signale, schlägt sie an; dann wende_v erhöhen (neue Kennung im Labor) und die Werte hier neu setzen.
GOLD = {"rang": "f13be5df49eaaf28", "spanne": "c91562ff093511f2"}


def _weg(seed: int, tage: int = 1100, sig0: float = 0.004, start: int = _T0, p0: float = 30000.0) -> dict:
    """Erfundener Kursweg in 30-min-Kerzen ohne Drift (schnell, für die Proben außer dem Nulltest): Schwankung mit langsamen Regimes,
    t-verteilte Renditen, Dochte."""
    rng = np.random.default_rng(seed); n = int(tage) * 48
    lv = np.cumsum(rng.normal(0, 0.02, n)); lv = lv - np.convolve(lv, np.ones(2000) / 2000, mode="same")
    sig = sig0 * np.exp(0.6 * np.tanh(lv))
    r = rng.standard_t(4, n) / math.sqrt(2.0) * sig
    c = p0 * np.exp(np.cumsum(r)); o = np.concatenate([[p0], c[:-1]])
    h = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 1, n)) * sig * 0.6)
    l = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 1, n)) * sig * 0.6)
    return {"ts": start + BAR * np.arange(n, dtype=np.int64), "o": o, "h": h, "l": l, "c": c}


def _k8_weg(preise, t0: int = _T0, spanne: float = 0.002) -> dict:
    """30-min-Kerzen aus einer Folge von 8-h-Preisen: je 8 h 16 gleiche Kerzen (Eröffnung = Schluss = Preis, Hoch/Tief ± spanne)."""
    p = np.repeat(np.asarray(preise, dtype=float), PRO_K8)
    return {"ts": t0 + BAR * np.arange(len(p), dtype=np.int64), "o": p.copy(), "h": p * (1 + spanne), "l": p * (1 - spanne), "c": p.copy()}


def _gold(lesart: str) -> str:
    D = daten(_weg(77, tage=1500))
    return hashlib.sha1("|".join(f"{s['k_ts']}:{s['seite']}:{s['stop']:.6f}" for s in signale(D, REGELN, lesart)).encode()).hexdigest()[:16]


def _probe_kerzen(ok) -> None:
    ts, o, h, l, c = [], [], [], [], []
    for p_, fehlt in ((0, ()), (1, (5, 6)), (2, (0,)), (3, (15,)), (4, tuple(range(8, 16)))):
        for i in range(16):
            if i in fehlt:
                continue
            b = 100.0 + 10 * p_ + i
            ts.append(_T0 + p_ * K8 + i * BAR); o.append(b); h.append(b + 0.5); l.append(b - 0.5); c.append(b + 0.25)
    K = {"ts": ts, "o": o, "h": h, "l": l, "c": c}
    D = daten(K); D2 = daten(K, bis=_T0 + 2 * K8 + 3 * BAR)
    ohne = {k: [v for v, t in zip(K[k], ts) if not (_T0 + K8 <= t < _T0 + 2 * K8)] for k in K}       # Periode 1 fehlt ganz
    D3 = daten(ohne)
    ok("8-h-Kerzen: Ausrichtung 00/08/16 UTC, Eröffnung/Schluss/Hoch/Tief, „voll“ (≥ 14 samt erster und letzter; ohne erste bzw. "
       "letzte nicht voll), offene Kerze am Ende und Kerzen nach „bis“ nicht dabei; fehlt eine 8-h-Kerze ganz, läuft die Reihe weiter",
       D["n8"] == 4 and list(D["k_ts"]) == [_T0, _T0 + K8, _T0 + 2 * K8, _T0 + 3 * K8] and D["k_o"][0] == 100 and D["k_c"][0] == 115.25
       and D["k_h"][0] == 115.5 and D["k_l"][0] == 99.5 and list(D["k_nb"]) == [16, 14, 15, 15]
       and list(D["k_voll"]) == [True, True, False, False] and D["k_c"][3] == 144.25
       and D["k_o"][2] == 121 and D["k_h"][1] == 125.5 and D["ende"] == _T0 + 4 * K8 + 8 * BAR and D2["n8"] == 2
       and D3["n8"] == 3 and D3["luecken8"] == 1 and list(D3["k_ts"]) == [_T0, _T0 + 2 * K8, _T0 + 3 * K8],
       f"n8 {D['n8']}, nb {list(D['k_nb'])}, voll {list(D['k_voll'])}, bis → {D2['n8']}, ohne Periode 1 → {D3['n8']}/{D3['luecken8']}")


def _probe_ema_flips(ok) -> None:
    x = np.array([3.0, 5.0, 4.0, 10.0, 7.0]); a = 2.0 / 9.0
    w = (1 - a) ** 4 * x[0] + sum(a * (1 - a) ** (4 - i) * x[i] for i in range(1, 5))
    e = ema(x, 8)

    def f_(d):
        return [int(v) for v in flips(np.array(d, dtype=float), np.zeros(len(d)))]
    ok("EMA (α = 2/(n+1), Start erster Wert) gegen die Gewichte von Hand; Flips nur bei Wechsel der Lage, Gleichstand an T oder T−1 "
       "ändert nichts",
       e[0] == 3.0 and abs(e[-1] - w) < 1e-12 and f_([1, 0, -1]) == [0, 0, -1] and f_([1, 1, -1]) == [0, 0, -1] and f_([-1, 0, 1]) == [0, 0, 1]
       and f_([1, 0, 1]) == [0, 0, 0] and f_([-1, 0, -1]) == [0, 0, 0] and f_([-1, 1, -1, 1]) == [0, 1, -1, 1] and f_([0, 0, 1, -1]) == [0, 0, 0, -1]
       and f_([1, 1, 0]) == [0, 0, 0], f"EMA {e[-1]:.12f} gegen {w:.12f}")


def _probe_schwellen(ok) -> None:
    hs = np.arange(1.0, 11.0); ls = hs - 0.5
    D = {"k_h": hs, "k_l": ls, "n8": 10}
    ra = schwellen(D, 9, 10, "rang", 0.10); sp = schwellen(D, 9, 10, "spanne", 0.10)
    ok("Lesarten von Hand: A = 90-%-Quantil der Hochs (9,1) bzw. 10-%-Quantil der Tiefs (1,4); B = Tief + 0,9 bzw. 0,1 der Spanne; "
       "Fenster unvollständig → keine Schwelle",
       abs(ra[0] - 9.1) < 1e-12 and abs(ra[1] - 1.4) < 1e-12 and abs(sp[0] - (0.5 + 0.9 * 9.5)) < 1e-12 and abs(sp[1] - (0.5 + 0.1 * 9.5)) < 1e-12
       and schwellen(D, 8, 10, "rang", 0.10) is None, f"A {ra}, B {sp}")


def _D_hand(k_h, flip: dict, n: int = 40) -> dict:
    """Kleiner 8-h-Datensatz von Hand für Grenzfälle: Hochs k_h, Tiefs 90, Schlüsse 95, Flips {Index: ±1}."""
    f = np.zeros(n, dtype=np.int8)
    for i, v in flip.items():
        f[i] = v
    return {"k_h": np.asarray(k_h, dtype=float), "k_l": np.full(n, 90.0), "k_c": np.full(n, 95.0), "k_voll": np.ones(n, dtype=bool),
            "flip": f, "flip_idx": np.nonzero(f)[0], "k_ts": _T0 + K8 * np.arange(n, dtype=np.int64), "n8": n}


def _probe_grenzen(ok) -> None:
    R = dict(REGELN, fenster=20); T = 35
    basis = 100.0 - 0.001 * np.arange(40)
    def s_(hs, b=25, la="rang"):
        return signal_an(_D_hand(hs, {b: 1, T: -1}), T, R, la)
    h1 = basis.copy(); h1[25] = 120.0; h1[24] = 119.0                       # rot nur an b (und davor)
    h2 = basis.copy(); h2[35] = 120.0; h2[20] = 119.0                       # rot nur an T
    h3 = basis.copy(); h3[16] = 120.0; h3[17] = 119.0                       # rot an der ersten Kerze des Fensters (T − 19)
    h4 = basis.copy(); h4[15] = 120.0; h4[16] = 119.0; h4[17] = 118.9       # höchstes Hoch knapp vor dem Fenster (T − 20)
    h5 = basis.copy(); h5[20] = 120.0
    thr = schwellen(_D_hand(h5, {25: 1, T: -1}), T, 20, "spanne", 0.10)[0]
    h5[30] = thr                                                             # genau auf der Schwelle (Lesart B)
    a1, a2, a3, a4 = s_(h1), s_(h2), s_(h3, b=10), s_(h4, b=10)
    a5 = s_(h5, la="spanne")
    # Einstieg später als 60 min nach dem Schluss und Einstieg jenseits des Stops (Historie wie Labor)
    p, K = _konstrukt(); D = daten(K); s0 = next(x for x in signale(D, REGELN, "rang") if x["seite"] == "short")
    j0 = s0["j0"]; spaet = {k: np.concatenate([np.asarray(v)[:j0], np.asarray(v)[j0 + 4:]]) for k, v in K.items()}
    jen = {k: np.array(v, dtype=np.int64 if k == "ts" else float) for k, v in K.items()}
    jen["o"][j0] = s0["stop"] * 1.01; jen["h"][j0] = max(jen["h"][j0], jen["o"][j0])
    k_sp = next(x for x in signale(daten(spaet), REGELN, "rang") if x["T"] == s0["T"])
    k_je = next(x for x in signale(daten(jen), REGELN, "rang") if x["T"] == s0["T"])
    ok("Grenzfälle von Hand: rote Kerze nur an b zählt nicht, nur an T zählt; erste Kerze des Fensters zählt, die davor nicht; Hoch genau "
       "auf der Schwelle zählt; erste Kerze erst 2 h nach dem Schluss → kein Einstieg; Eröffnung jenseits des Stops → kein Einstieg",
       a1 is None and a2 is not None and abs(a2["stop"] - 120.12) < 1e-9 and a3 is not None and abs(a3["stop"] - 120.12) < 1e-9
       and a4 is not None and abs(a4["stop"] - 119.119) < 1e-9 and a5 is not None and abs(a5["stop"] - thr * 1.001) < 1e-9
       and k_sp["kein"] and "min nach dem Schluss" in k_sp["kein"] and k_je["kein"] == "Einstieg jenseits des Stops",
       f"b {a1 and a1['stop']}, T {a2 and a2['stop']}, Fensteranfang {a3 and a3['stop']}, davor {a4 and a4['stop']}, Schwelle "
       f"{a5 and a5['stop']} ({thr}), spät „{k_sp['kein']}“, jenseits „{k_je['kein']}“")


def _konstrukt() -> tuple:
    """8-h-Preise: Anstieg, Spitze (rote Kerzen), Fall (bärischer Flip = Short), Boden, Erholung (bullischer Flip = Long), Fall ohne
    neue rote Kerzen (bärischer Flip ohne Signal)."""
    p = [100.0 * math.exp(0.001 * k) for k in range(900)]
    p += [p[-1] * (1 + 0.01 * (k + 1)) for k in range(10)]                          # 900–909 Spitze
    p += [p[909] * math.exp(-0.01 * (k + 1)) for k in range(150)]                   # 910–1059 Fall
    p += [p[-1] * (1 + 0.004 * math.sin(k / 3.0)) for k in range(30)]              # 1060–1089 Boden
    p += [p[1089] * math.exp(0.006 * (k + 1)) for k in range(80)]                   # 1090–1169 Erholung
    p += [p[1169] * math.exp(-0.006 * (k + 1)) for k in range(120)]                 # 1170–1289 Fall
    return p, _k8_weg(p)


def _probe_signal(ok) -> None:
    p, K = _konstrukt()
    D = daten(K); fi = [int(i) for i in D["flip_idx"] if i >= FENSTER - 1]
    S = [signal_an(D, T, REGELN, "rang") for T in fi]
    sh = [s for s in S if s and s["seite"] == "short"]; lo = [s for s in S if s and s["seite"] == "long"]
    s1 = sh[0] if sh else None; s2 = lo[0] if lo else None
    erw_stop = 1.001 * 1.002 * p[909]
    boden = min(p[910:1170]) * (1 - 0.002)
    sig_ = signale(D, REGELN, "rang")
    e1 = next((s for s in sig_ if s1 and s["T"] == s1["T"]), None)
    ok("Konstruiertes Signal von Hand: Spitze → bärischer Flip = Short mit Stop 1,001 × höchstes Hoch der roten Kerzen; Boden → "
       "bullischer Flip = Long mit Stop 0,999 × tiefstes Tief der blauen; späterer bärischer Flip ohne rote Kerze = kein Signal; "
       "Einstieg zur Eröffnung nach dem Schluss",
       len(fi) >= 3 and s1 is not None and abs(s1["stop"] / erw_stop - 1) < 1e-12 and s1["i_extrem"] == 909 and s1["T"] > 909
       and s2 is not None and s2["T"] > s1["T"] and abs(s2["stop"] / (0.999 * boden) - 1) < 1e-12
       and S[-1] is None and int(D["flip"][fi[-1]]) == -1 and e1 is not None and e1["einstieg"] == p[s1["T"] + 1]
       and e1["j0"] == (s1["T"] + 1) * PRO_K8,
       f"Flips {fi[:6]}, Short {s1 and (s1['T'], round(s1['stop'], 4))} (erwartet {erw_stop:.4f}), Long {s2 and (s2['T'], round(s2['stop'], 4))}, "
       f"letzter Flip {fi[-1] if fi else None}: {S[-1] if S else None}")


def _probe_varianten(ok) -> None:
    """Beschreibende Varianten (4.6): Stop nur aus dem letzten roten Block; Färbung je Kerze mit eigenem Fenster (ohne Nachfärben)."""
    R = dict(REGELN, fenster=20); T = 35
    hs = 100.0 - 0.001 * np.arange(40); hs[28] = 120.0; hs[29] = 119.0; hs[33] = 118.5; hs[34] = 118.0   # zwei rote Blöcke seit b = 25
    D = _D_hand(hs, {25: 1, T: -1})
    a = signal_an(D, T, R, "spanne"); b = signal_an(D, T, R, "spanne", stop_art="block")
    hi = 100.0 - 0.001 * np.arange(40); hi[14] = 130.0; hi[30] = 125.0
    Di = _D_hand(hi, {25: 1, T: -1})
    a_t = signal_an(Di, T, R, "spanne"); a_i = signal_an(Di, T, R, "spanne", fenster_art="i")
    rot_i, _ = _farbe_eigen(Di, 20, "spanne", 0.10)
    ok("Varianten von Hand: Stop „alle“ = höchstes rotes Hoch seit dem Gegen-Flip (120), „Block“ = letzter zusammenhängender roter Block "
       "(118,5); Kerze 30 (125) ist im Fenster bei T rot, in ihrem eigenen Fenster nicht (dort liegt noch das Hoch 130 von Kerze 14)",
       a is not None and abs(a["stop"] - 120.12) < 1e-9 and b is not None and abs(b["stop"] - 118.5 * 1.001) < 1e-9
       and a_t is not None and abs(a_t["stop"] - 125.125) < 1e-9 and a_i is None and not bool(rot_i[30]),
       f"alle {a and a['stop']}, Block {b and b['stop']}, bei T {a_t and a_t['stop']}, je Kerze {a_i}, rot je Kerze {list(np.nonzero(rot_i)[0])}")


def _probe_kausal(ok) -> None:
    K = _weg(11, tage=900); D = daten(K); rng = np.random.default_rng(5); fehler = []; n = 0
    for la in LESARTEN:
        sig_ = signale(D, REGELN, la)
        for s in sig_[:: max(1, len(sig_) // 6)]:
            j0 = s["j0"]
            if j0 is None:
                continue
            K2 = {k: np.array(v, dtype=float if k != "ts" else np.int64) for k, v in K.items()}
            f_ = np.exp(np.cumsum(rng.normal(0, 0.01, len(K2["ts"]) - j0)))
            for k in ("o", "h", "l", "c"):
                K2[k][j0:] = K2[k][j0:] * f_ * (1.03 if k == "h" else 1.0)
            D2 = daten(K2); s2 = signal_an(D2, s["T"], REGELN, la); n += 1
            if not s2 or s2["seite"] != s["seite"] or s2["stop"] != s["stop"] or s2["extrem"] != s["extrem"]:
                fehler.append((la, s["T"]))
            if abs(float(sigma_an(D2, [j0])[0]) - float(sigma_an(D, [j0])[0])) > 1e-15:
                fehler.append(("sigma", s["T"]))
    ok("Kausalität: alle Kerzen ab dem Einstieg beliebig verändert → Signal, Seite, Extrem, Stop an T und die Schwankung vor dem Einstieg "
       "gleich (beide Lesarten)", n >= 6 and not fehler, f"{n} Signale geprüft, abweichend {fehler[:3]}")


def _probe_passage(ok) -> None:
    rng = np.random.default_rng(3); n = 3000
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, n))); h = c * (1 + np.abs(rng.normal(0, 0.003, n))); l = c * (1 - np.abs(rng.normal(0, 0.003, n)))
    P = Passage(h, l); st = rng.integers(0, n + 5, 4000); sw = c[np.minimum(st, n - 1)] * np.exp(rng.normal(0, 0.05, len(st)))
    st = np.minimum(st, n)

    def ref(arr, s0, x, cmp):
        for j in range(int(s0), n):
            if cmp(arr[j], x):
                return j
        return n
    f = 0
    for strikt in (True, False):
        a = P.hoch(st, sw, strikt); b = P.tief(st, sw, strikt)
        for i in range(0, len(st), 7):
            if a[i] != ref(h, st[i], sw[i], (lambda u, v: u > v) if strikt else (lambda u, v: u >= v)):
                f += 1
            if b[i] != ref(l, st[i], sw[i], (lambda u, v: u < v) if strikt else (lambda u, v: u <= v)):
                f += 1
    aa = rng.integers(0, n - 1, 500); bb = np.minimum(n, aa + rng.integers(1, 2000, 500))
    mx = P.max_bereich(aa, bb); mn = P.min_bereich(aa, bb)
    f2 = sum(1 for i in range(500) if mx[i] != h[aa[i]:bb[i]].max() or mn[i] != l[aa[i]:bb[i]].min())
    ok("Erste Passage (Block-Tabelle, binäres Vorrücken) gleich einer einfachen Schleife (strikt und nicht strikt, Start am Ende); "
       "Bereichs-Maximum/-Minimum gleich np.max/np.min", f == 0 and f2 == 0, f"Abweichungen {f} bzw. {f2}")


def _hand_kerzen(spur: list, t0: int = _T0) -> dict:
    """Einstieg zur Eröffnung von Kerze 0 bei 100; spur = (o, h, l, c) je Kerze ab dem Einstieg."""
    ts = t0 + BAR * np.arange(len(spur), dtype=np.int64)
    a = np.array(spur, dtype=float)
    return {"ts": ts, "o": a[:, 0], "h": a[:, 1], "l": a[:, 2], "c": a[:, 3]}


def _hand_D(K: dict, F: dict | None = None) -> dict:
    ts, o, h, l, c = _sauber(K)
    D = {"ts": ts, "o": o, "h": h, "l": l, "c": c, "n": len(ts), "ende": int(ts[-1]) + BAR}
    if F is not None:
        D["f_ts"] = np.asarray(F["ts"], dtype=np.int64); D["f_cs"] = np.concatenate([[0.0], np.cumsum(F["rate"])])
    return D


def _probe_handel(ok) -> None:
    def lauf(spur, sv=1, stop=95.0, art="ziel", zr=1.0, F=None, tage=MAX_TAGE, jg=None):
        D = _hand_D(_hand_kerzen(spur), F); P = Passage(D["h"], D["l"])
        j, g, aus, ta = ausgang(D, P, [0], [100.0], [stop], sv, art, zr, jg=jg, max_tage=tage)
        rw = r_werte(D, [0], [100.0], [stop], sv, g, aus, ta)
        return int(j[0]), GRUND[int(g[0])], float(aus[0]), int(ta[0]), {k: float(v[0]) for k, v in rw.items()}
    ruhig = (100.0, 100.5, 99.5, 100.0)
    a = lauf([(100, 106, 99, 100), (100, 105, 99, 100), (100, 105.01, 99, 105)] + [ruhig] * 3)
    b = lauf([ruhig, (100, 106, 94, 100)] + [ruhig] * 3)
    cg = lauf([ruhig, (90, 91, 89, 90)] + [ruhig] * 3)
    d = lauf([(100, 101, 94, 99)] + [ruhig] * 3)
    e = lauf([ruhig] * 400, tage=5)
    e2 = lauf([ruhig] * 400, art="stop", tage=5)
    g_ = lauf([ruhig] * 10)
    g2 = lauf([ruhig] * 10, art="stop", tage=None)
    s_ = lauf([ruhig, (100, 100.5, 94.99, 100), (100, 106, 99, 100)] + [ruhig] * 3, sv=-1, stop=105.0)
    gf = lauf([ruhig, ruhig, (99, 99.5, 94, 95)] + [ruhig] * 3, art="gegenflip", jg=np.array([2]))
    F = {"ts": np.array([_T0 + 2 * BAR]), "rate": np.array([0.0001])}
    k_ = lauf([(100, 101, 99, 100), (100, 104, 99, 104), (104, 105.5, 103, 105)] + [ruhig] * 3, F=F)
    px_in = 100 * (1 + SLIP); pnl = 105 - px_in - GEB_TAKER * px_in - GEB_MAKER * 105 - 0.0001 * px_in
    ok("Handel von Hand: Ziel nur durchlaufen (gleich reicht nicht) und nicht in der Einstiegskerze; Stop und Ziel in einer Kerze → Stop; "
       "Lücke über den Stop → Eröffnung; Stop in der Einstiegskerze; Zeitgrenze → Eröffnung (auch „bis zum Stop“); ohne Grenze und ohne "
       "Ausgang „offen“ zum letzten Schluss ohne Ausstiegskosten; Short gespiegelt; Gegen-Flip zur Eröffnung vor dem Stop derselben Kerze; "
       "Kosten und Funding von Hand",
       a[:3] == (2, "Ziel", 105.0) and a[3] == _T0 + 3 * BAR and abs(a[4]["kurs"] - 1.0) < 1e-12
       and b[:3] == (1, "Stop", 95.0) and abs(b[4]["kurs"] + 1.0) < 1e-12
       and cg[:3] == (1, "Stop", 90.0) and abs(cg[4]["kurs"] + 2.0) < 1e-12
       and d[:3] == (0, "Stop", 95.0)
       and e[1] == "Zeit" and e[0] == 5 * 48 and e[3] == _T0 + 5 * TAG and abs(e[4]["kurs"]) < 1e-12 and e2[1] == "Zeit"
       and g_[1] == "offen" and g2[1] == "offen" and g_[2] == 100.0 and abs(g_[4]["gebuehren"] + GEB_TAKER * px_in / 5.0) < 1e-12
       and s_[:3] == (1, "Ziel", 95.0) and abs(s_[4]["kurs"] - 1.0) < 1e-12
       and gf[:3] == (2, "Gegen-Flip", 99.0)
       and k_[1] == "Ziel" and abs(k_[4]["netto"] - pnl / 5.0) < 1e-12 and abs(k_[4]["funding"] + 0.0001 * px_in / 5.0) < 1e-12,
       f"{a[:3]} {b[:3]} {cg[:3]} {d[:3]} {e[:2]} {e2[:2]} {g_[:3]} {g2[:2]} {s_[:3]} {gf[:3]} netto {k_[4]['netto']:.6f} gegen {pnl / 5:.6f}")


def _probe_mfe_stufen(ok) -> None:
    spur = [(100, 101, 99.5, 100), (100, 103, 99, 102), (102, 107.6, 101, 107), (107, 107.2, 94, 95)] + [(95, 95.5, 94.5, 95)] * 3
    D = _hand_D(_hand_kerzen(spur)); P = Passage(D["h"], D["l"])
    m = float(mfe(D, P, [0], [100.0], [95.0], 1)[0])
    js = int(_j_stop(P, [0], [95.0], 1)[0])
    st = {L: bool(int(_j_ziel(P, [0], [100.0 + L * 5.0], 1)[0]) < js) for L in STUFEN}
    ok("Bestes Zwischenhoch bis vor die Stop-Kerze (7,6 ÷ 5 = 1,52 R) und Stufen vor dem Stop (0,5/1/1,5 R ja, 2 R nein)",
       abs(m - 1.52) < 1e-12 and js == 3 and st == {0.5: True, 1.0: True, 1.5: True, 2.0: False, 3.0: False, 5.0: False}, f"MFE {m}, Stop {js}, {st}")


def _probe_gegenflip(ok) -> None:
    D = {"flip": np.array([0, 1, 0, -1, 0, 1, 0, -1, 0], dtype=np.int8), "k_ts": _T0 + K8 * np.arange(9, dtype=np.int64),
         "ts": _T0 + BAR * np.arange(9 * PRO_K8, dtype=np.int64), "n": 9 * PRO_K8}
    g_l = _gegenflip_index(D, [1, 3, 7], 1); g_s = _gegenflip_index(D, [3, 5], -1)
    D0 = dict(D, flip=np.zeros(9, dtype=np.int8))
    ok("Gegen-Flip: Long → nächster bärischer Flip, Short → nächster bullischer, Ausstieg zur Eröffnung nach seinem Schluss; keiner → Ende",
       list(g_l) == [4 * PRO_K8, 8 * PRO_K8, D["n"]] and list(g_s) == [6 * PRO_K8, D["n"]] and list(_gegenflip_index(D0, [1], 1)) == [D["n"]],
       f"{list(g_l)} {list(g_s)}")


def _probe_statistik(ok) -> None:
    pb = poisson_binomial([0.5, 0.5]); rng = np.random.default_rng(1); ps = rng.uniform(0.2, 0.8, 20)
    sim = (rng.random((40000, 20)) < ps).sum(axis=1)
    d = poisson_binomial(ps); x = int(round(ps.sum())) + 3
    ids = cluster_ids([{"t_in": a_, "ziel1": {"t_aus": b_}} for a_, b_ in ((0, 10), (5, 15), (20, 30), (25, 26), (40, 50))])
    x6 = np.array([0.5, -1.0, 1.2, 0.3, -0.4, 0.9]); tc = t_cluster(x6, np.arange(6))
    m_ = x6.mean(); se_ = x6.std(ddof=1) / math.sqrt(6); t_ = m_ / se_
    du = t_cluster(np.repeat(x6, 2), np.repeat(np.arange(6), 2))
    H = rng.random((30, 999)) < 0.5; Xt = H.sum(axis=0)
    h_top = h1_verschiebung([True] * 30, H); h_mit = h1_verschiebung([True] * int(np.median(Xt)) + [False] * (30 - int(np.median(Xt))), H)
    xk = h_top["x_krit"]
    ok("Statistik: Poisson-binomial von Hand und gegen Simulation; Gruppen überlappender Trades; Cluster-t mit Einzelgruppen = t-Test, "
       "mit doppelten Trades = t-Test der einzelnen; H1-Rang (alle Treffer → 1/(N+1)), kritische Trefferzahl (p < α)",
       np.allclose(pb, [0.25, 0.5, 0.25]) and abs(p_mindestens(d, x) - float(np.mean(sim >= x))) < 0.01 and list(ids) == [0, 0, 1, 1, 2]
       and abs(tc["t"] - t_) < 1e-9 and tc["G"] == 6 and abs(du["t"] - t_) < 1e-9 and du["G"] == 6
       and abs(h_top["p"] - 1 / 1000) < 1e-12 and 0.3 < h_mit["p"] < 0.7
       and (1 + np.sum(Xt >= xk)) / 1000 < ALPHA_H1 <= (1 + np.sum(Xt >= xk - 1)) / 1000,
       f"PB {pb}, Tail {p_mindestens(d, x):.4f} gegen {float(np.mean(sim >= x)):.4f}, ids {list(ids)}, t {tc['t']:.4f}/{du['t']:.4f} gegen "
       f"{t_:.4f}, p {h_top['p']:.4f}/{h_mit['p']:.3f}, x_krit {xk}")
    H4 = np.array([[1, 1, 1, 1], [0, 1, 1, 1], [0, 0, 0, 1]], dtype=bool)            # X_τ = 1, 2, 2, 3
    h4 = h1_verschiebung([True, True, False], H4)
    tr4 = [{"t_flip": i, "ziel1": {"g": 0 if i in (0, 3) else 1}} for i in range(5)]
    H5 = np.array([[1, 0], [1, 1], [0, 0], [1, 1], [0, 0]], dtype=bool)
    hf5 = _haelften(tr4, H5)
    _, u_ok = urteil_bed({"p": ALPHA_H1 * 0.99}, {"p": 0.04, "mittel": 0.1}, [{"ok": True}, {"ok": True}], 30, 20)
    _, u_n = urteil_bed({"p": 0.001}, {"p": 0.001, "mittel": 0.1}, [{"ok": True}, {"ok": True}], 29, 25)
    _, u_g = urteil_bed({"p": 0.001}, {"p": 0.001, "mittel": 0.1}, [{"ok": True}, {"ok": True}], 40, 19)
    _, u_a = urteil_bed({"p": ALPHA_H1}, {"p": 0.001, "mittel": 0.1}, [{"ok": True}, {"ok": True}], 40, 30)
    _, u_m = urteil_bed({"p": 0.001}, {"p": 0.001, "mittel": -0.1}, [{"ok": True}, {"ok": True}], 40, 30)
    _, u_h = urteil_bed({"p": 0.001}, {"p": 0.001, "mittel": 0.1}, [{"ok": True}, {"ok": False}], 40, 30)
    ok("Urteil und Hälften von Hand: H1 p = (1 + #{X_τ ≥ X}) ÷ (1 + N) (X = 2 bei X_τ 1, 2, 2, 3 → 0,8); Hälften mit dem Mittel ihrer "
       "Verschiebungen; bestätigt nur mit allen Bedingungen (p streng unter der Schwelle, Mittel > 0, beide Hälften, ab 30 Trades in 20 Gruppen)",
       abs(h4["p"] - 0.8) < 1e-12 and h4["x_krit"] is None and [h["n"] for h in hf5] == [3, 2] and [h["x"] for h in hf5] == [1, 1]
       and abs(hf5[0]["erwartet"] - 1.5) < 1e-12 and abs(hf5[1]["erwartet"] - 1.0) < 1e-12 and [h["ok"] for h in hf5] == [False, True]
       and u_ok == "bestätigt" and u_n == "nicht prüfbar" and u_g == "nicht prüfbar" and u_a == "nicht bestätigt" and u_m == "nicht bestätigt"
       and u_h == "nicht bestätigt",
       f"p {h4['p']}, Hälften {[(h['n'], h['x'], h['erwartet']) for h in hf5]}, Urteile {u_ok}/{u_n}/{u_g}/{u_a}/{u_m}/{u_h}")


def _probe_verschiebung(ok) -> None:
    Kw = _weg(51, tage=1300); D = daten(Kw); P = Passage(D["h"], D["l"])
    sig_ = [s for s in urteils_signale(signale(D, REGELN, "rang"), D) if s.get("j0") is not None and not s.get("kein")]
    tr = trades_rechnen(D, P, sig_[:3]); erl = [t for t in tr if t["ziel1"]["g"] != 4]
    Vs = verschiebungen(D, START_VIDEO, [t["T"] for t in erl]); mk = int(MAX_TAGE * TAG // K8)
    A2 = auswerten(D, P, [sig_[0], dict(sig_[0])], beschreibend=False)
    pool = zufall_pool(D, START_VIDEO)
    T_ = int(pool[len(pool) // 2]); tc = int(D["k_ts"][T_]) + K8                # 2 h ohne 30-min-Kerzen nach dem Schluss von T_
    m_ = ~((np.asarray(Kw["ts"]) >= tc) & (np.asarray(Kw["ts"]) < tc + 4 * BAR))
    pg = set(zufall_pool(daten({k: np.asarray(v)[m_] for k, v in Kw.items()}), START_VIDEO).tolist())
    pool_regel = (T_ not in pg) and ((T_ + 1) not in pg) and ((T_ - 1) in pg) and ((T_ + 2) in pg)
    E_ = int(D["ende"]); rand = urteils_signale([{"k_ts": START_VIDEO, "t_flip": E_ - MAX_TAGE * TAG},
                                                 {"k_ts": START_VIDEO, "t_flip": E_ - MAX_TAGE * TAG - K8}], {"ende": E_})
    # dieselbe Regel an anderen Einstiegen, von Hand (ohne Skalierung): Einstieg 100, Abstand 1 % → Stop 99, Ziel 1R 101 (2R 102)
    ruhig = (100.0, 100.2, 99.8, 100.0)
    K1 = _hand_kerzen([ruhig, (100, 100.3, 99.4, 100), (100, 101.5, 99.9, 101.4)] + [(101.4, 101.6, 101.2, 101.4)] * 4)
    K2 = _hand_kerzen([ruhig, (100, 100.3, 98.5, 99), (99, 101.5, 98.9, 101.4)] + [(101.4, 101.6, 101.2, 101.4)] * 4)

    def an(K_, sv):
        D_ = _hand_D(K_)
        return bool(_trades_an(D_, Passage(D_["h"], D_["l"]), {"sv": sv, "abstand": 0.01}, np.array([0]), np.array([0]),
                               skala=False)["treffer"][0])
    hand = (an(K1, 1), an(K2, 1), an(K1, -1))
    D3 = _hand_D(_hand_kerzen([ruhig] * (MAX_TAGE * 48 + 10)))            # 120 Tage ohne Ziel und Stop -> Zeit, kein Treffer
    z3 = _trades_an(D3, Passage(D3["h"], D3["l"]), {"sv": 1, "abstand": 0.01}, np.array([0]), np.array([0]), skala=False)
    zeit3 = (bool(z3["treffer"][0]), bool(z3["zeit"][0]), bool(z3["erledigt"][0]))
    # Skalierung: σ vor dem neuen Einstieg doppelt so groß → doppelter Abstand (in den Grenzen)
    rng = np.random.default_rng(8); n = 4000; sig = np.where(np.arange(n) < 2000, 0.002, 0.004)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 1, n) * sig))
    Ds = _hand_D({"ts": _T0 + BAR * np.arange(n), "o": np.concatenate([[100.0], c[:-1]]), "h": c * 1.0005, "l": c * 0.9995, "c": c})
    r = np.zeros(n); r[1:] = np.diff(np.log(c)); Ds["rv_cs"] = np.concatenate([[0.0], np.cumsum(r * r)]); Ds["rv_cn"] = np.arange(n + 1)
    s1, s2 = float(sigma_an(Ds, [1990])[0]), float(sigma_an(Ds, [3990])[0])
    Ps = Passage(Ds["h"], Ds["l"])
    z = _trades_an(Ds, Ps, {"sv": 1, "abstand": 0.02, "sigma": s1}, np.array([0, 0]), np.array([1990, 3990]))
    z_k = _trades_an(Ds, Ps, {"sv": 1, "abstand": 0.02, "sigma": s1}, np.array([0, 0]), np.array([100, 3990]))      # vor 100: kein σ
    z_n = _trades_an(Ds, Ps, {"sv": 1, "abstand": 0.02, "sigma": float("nan")}, np.array([0, 0]), np.array([1990, 3990]))
    rueck = (z["ohne_sigma"], z_k["ohne_sigma"], abs(z_k["a"][0] - 0.02) < 1e-12, z_n["ohne_sigma"], bool(np.allclose(z_n["a"], 0.02)))
    ok("Verschiebung: |τ| im Kreis mindestens 120 Tage, alle Trades gemeinsam (zwei gleiche Trades haben in jeder Verschiebung dasselbe "
       "Ergebnis), Einstiege nur, wo 120 Tage Daten folgen, Trades des Urteils in der Spanne; verschobene Trades enden alle; an anderen "
       "Einstiegen dieselbe Richtung, Ziel 1R und der Stop-Abstand nach der Schwankung skaliert (von Hand); nach 120 Tagen ohne Ziel und "
       "Stop: Zeit, kein Treffer; Grenze strikt (Flip-Schluss genau 120 Tage vor dem Ende zählt nicht); Pool ohne nicht volle Kerzen und "
       "ohne Einstieg später als 60 min, die Trades des Urteils genau darin; ohne σ unskaliert und gezählt",
       Vs is not None and int(Vs["taus"][0]) == mk and int(Vs["taus"][-1]) == Vs["L"] - mk and bool(np.all(Vs["pos"] < Vs["L"]))
       and A2["verschiebungen"] > 0 and A2["offen_verschoben"] == 0 and bool(np.array_equal(A2["H"][0], A2["H"][1]))
       and int(D["k_ts"][pool[-1]]) + K8 + MAX_TAGE * TAG < D["ende"] and int(D["k_ts"][pool[0]]) >= START_VIDEO
       and bool(np.array_equal(Vs["pool"][Vs["pos"]], [t["T"] for t in erl])) and pool_regel
       and [r_["t_flip"] for r_ in rand] == [E_ - MAX_TAGE * TAG - K8]
       and hand == (True, False, False) and zeit3 == (False, True, True)
       and 1.7 < s2 / s1 < 2.3 and abs(z["a"][0] - 0.02) < 1e-12 and abs(z["a"][1] - 0.02 * s2 / s1) < 1e-12 and rueck == (0, 1, True, 2, True),
       f"τ {Vs and (int(Vs['taus'][0]), int(Vs['taus'][-1]), Vs['L'])}, offen {A2['offen_verschoben']}, von Hand {hand}, Zeit {zeit3}, "
       f"σ {s1:.5f}/{s2:.5f}, a {list(np.round(z['a'], 5))}, Pool-Regel {pool_regel}, Grenze {len(rand)}, ohne σ {rueck}")


def _probe_nachrechnen(ok) -> None:
    def sg(v, f_e=1.0, f_s=None, abst=None, dt=0):
        e = v["einstieg"] * f_e
        if f_s is not None:
            st = v["stop"] * f_s
        elif abst is not None:
            st = e * (1 - abst / 100) if v["seite"] == "long" else e * (1 + abst / 100)
        elif "stop" in v:
            st = v["stop"]
        else:
            lo_, hi_ = v.get("abstand", (2.0, 2.0)); a_ = (lo_ + hi_) / 2
            st = e * (1 - a_ / 100) if v["seite"] == "long" else e * (1 + a_ / 100)
        return {"seite": v["seite"], "k_ts": v["von"] + TAG + dt, "einstieg": e, "stop": st, "abstand": abs(e - st) / e}
    V = VIDEO_TRADES
    alle = [sg(v) for v in V]
    knapp = [sg(V[0], f_e=1.0049), sg(V[1], abst=3.4), sg(V[2], f_e=0.986), sg(V[3]), sg(V[4], abst=8.6), sg(V[5], f_s=1.0049)]
    daneben = [sg(V[0], f_e=1.006), sg(V[1], abst=3.6), sg(V[2], dt=40 * TAG), sg(dict(V[3], seite="short")), sg(V[4], abst=8.4),
               sg(V[5], f_s=1.0051)]
    fueller = [{"seite": "long" if i < 16 - 3 else "short", "k_ts": START_VIDEO + 10 * TAG + i * 40 * TAG, "einstieg": 100.0, "stop": 90.0,
                "abstand": 0.1} for i in range(35 - 6)]
    fueller = [f_ for f_ in fueller if not (f_["seite"] == "short" and LUECKE[0] <= f_["k_ts"] < LUECKE[1])]
    n1 = nachrechnen(alle + fueller, []); n2 = nachrechnen(knapp); n3 = nachrechnen(daneben, [sg(V[5])])
    luecke = nachrechnen(alle + [{"seite": "short", "k_ts": LUECKE[0] + 10 * TAG, "einstieg": 1.0, "stop": 1.1, "abstand": 0.1}])
    tol = nachrechnen([sg(V[3], f_e=1.014), sg(V[2], f_e=1.016)])            # allgemeine Toleranz 1,5 %: 1,4 % ja, 1,6 % nein
    leer = nachrechnen(daneben, [])                                           # Trade 6 weder bei 765 noch bei 1.050: Probe nicht bestanden

    def w(*q):
        return lesart_waehlen({"rang": dict(zip(("gefunden", "luecke", "pruef1050", "abweichung"), q[0])),
                               "spanne": dict(zip(("gefunden", "luecke", "pruef1050", "abweichung"), q[1]))})
    w1 = w((4, True, True, 0), (5, False, False, 30)); w2 = w((5, False, True, 0), (5, True, False, 9))
    w3 = w((5, True, False, 0), (5, True, True, 9)); w4 = w((5, True, True, 9), (5, True, True, 3)); w5 = w((5, True, True, 3), (5, True, True, 3))
    ok("Nachrechnen der Video-Trades: alle sechs gefunden, 35 Signale (16/19), kein Short in der Lücke → nachgebaut; knapp innerhalb der "
       "Toleranzen gefunden (Trade 1 und 6: Einstieg ±0,5 %, sonst ±1,5 %), knapp außerhalb nicht; Short in der Lücke erkannt; Probe mit "
       "1.050 Kerzen (nur bestanden, wenn Trade 6 mit 765 Kerzen gefunden ist); "
       "Wahl der Lesart nur nach gefunden, Lücke, 1.050-Probe, Abweichung, dann A",
       n1["gefunden"] == 6 and n1["zahl"] == 35 and n1["long"] == 16 and n1["nachgebaut"] and n1["luecke"] and n1["pruef1050"]
       and n1["abweichung"] == 0 and n2["gefunden"] == 6 and n3["gefunden"] == 0 and n3["pruef1050"] is False and not luecke["luecke"]
       and tol["trades"][3]["s"] is not None and tol["trades"][2]["s"] is None and leer["pruef1050"] is False
       and (w1, w2, w3, w4, w5) == ("spanne", "spanne", "spanne", "spanne", "rang"),
       f"{n1['gefunden']}/{n1['zahl']}/{n1['long']}/{n1['luecke']}/{n1['pruef1050']}/{n1['abweichung']}, knapp {n2['gefunden']}, daneben "
       f"{n3['gefunden']}, Toleranz 1,4/1,6 % {tol['trades'][3]['s'] is not None}/{tol['trades'][2]['s'] is not None}, Wahl {w1} {w2} {w3} {w4} {w5}")


def _probe_abgleich(ok) -> None:
    def t_(a, b, g=0):
        return {"t_in": a, "t_flip": a - 10, "seite": "long", "k_ts": a - 100, "ziel1": {"t_aus": b, "g": g}}
    tr = [t_(100, 200), t_(150, 160), t_(200, 300), t_(250, 260), t_(400, 0, 4), t_(500, 600)]
    aus = labor_abgleich(tr)["ausgelassen"]
    tv = [dict(t_(100 * i + 50, 0), t_flip=i, stufen={1.0: True, 2.0: i % 2 == 0}, fast_sofort=False, im_stop=True, mfe=1.0,
               laufen={"kurs": float(i), "netto": float(i)}) for i in range(5)]
    vv = video_vergleich(tv); vv2 = video_vergleich(tv, letzt_flip=10)       # jüngstes Signal (t_flip 10) ohne Trade: alle fünf zählen
    ok("Labor-Abgleich von Hand (eine Position je Strategie: was während einer offenen Position kommt, entfällt; eine offene bleibt offen); "
       "Vergleich mit dem Video ohne das jüngste Signal (auch wenn es keinen Trade hatte)",
       [t["t_in"] for t in aus] == [150, 250, 500] and vv["n"] == 4 and vv["zwei_r"] == 2 and abs(vv["kurs"]["laufen"] - 6 * 2.0) < 1e-12
       and abs(vv["kurs"]["laufen_ohne_besten"] - 3 * 2.0) < 1e-12 and vv2["n"] == 5,
       f"ausgelassen {[t['t_in'] for t in aus]}, Vergleich n {vv['n']}/{vv2['n']}")


def _swing_db(pfad: str, K: dict) -> None:
    con = SW.verbinden(pfad)
    try:
        SW._schreiben(con, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                      [(COIN, int(t), float(o), float(h), float(l), float(c), 1.0) for t, o, h, l, c in zip(K["ts"], K["o"], K["h"], K["l"], K["c"])])
    finally:
        con.close()


def _probe_labor(ok, tmp: str) -> None:
    K = _weg(21, tage=1200); pfad = os.path.join(tmp, "swing.db"); _swing_db(pfad, K)
    D = daten(K)
    sig_ = [s for s in signale(D, REGELN, "rang") if s["k_ts"] > K["ts"][0] + 700 * TAG and s.get("j0") is not None]
    s = sig_[0] if sig_ else None
    fehler = []
    if s:
        _LABOR_CACHE.clear()
        W1 = labor_daten(pfad, s["t_flip"] + 300)
        W2 = labor_daten(pfad, s["t_flip"] + EIN_FENSTER_S + 60)
        _LABOR_CACHE.clear()
        W0 = labor_daten(pfad, s["t_flip"] - 60)
        s1 = (W1.get("signal") or {}).get("rang")
        if not (W1.get("ok") and W1["frisch"] and W1["t_schluss"] == s["t_flip"] and s1 and s1["seite"] == s["seite"]
                and abs(s1["stop"] - s["stop"]) < 1e-9 and abs(s1["abstand_schluss"] - s["abstand_schluss"]) < 1e-12):
            fehler.append(("frisch", W1.get("frisch"), s1 and s1["stop"], s["stop"]))
        if not (W2.get("ok") and not W2["frisch"]):
            fehler.append("nach 60 min noch frisch")
        if not (W0.get("ok") and W0["t_schluss"] == s["t_flip"] - K8):
            fehler.append("vor dem Schluss schon die neue Kerze")
        gross = [k for k, v in W1.items() if isinstance(v, np.ndarray)] + [k for k, v in (W1.get("lage") or {}).items()
                                                                          if any(isinstance(x, np.ndarray) for x in v.values())]
        if gross:
            fehler.append(f"Reihen im Labor-Eingang: {gross}")
        for la in LESARTEN:
            if not status_text(dict(REGELN, lesart=la), W1, s["t_flip"] + 300):
                fehler.append("Status leer")
    leer = labor_daten(os.path.join(tmp, "fehlt.db"), int(K["ts"][-1]))
    ok("Labor-Daten: gleiche Signale wie die Historie (Seite, Stop, Abstand am Schluss) aus den letzten 600 Tagen; frisch nur bis 60 min "
       "nach dem Schluss; vor dem Schluss die Kerze davor; nur Kleines im Eingang (Welt A kopiert ihn je Takt); ohne swing.db ein Grund",
       s is not None and not fehler and not leer["ok"] and leer.get("grund"), f"Signal {s and (_zeit(s['k_ts']), s['seite'])}, Fehler {fehler}")


def _probe_ende_zu_ende(ok, tmp: str) -> None:
    K = _weg(31, tage=2500, start=_t(2020, 1, 1)); pfad = os.path.join(tmp, "e2e"); os.makedirs(pfad, exist_ok=True)
    _swing_db(os.path.join(pfad, "swing.db"), K)
    db = os.path.join(pfad, "hl_liq.db")
    jetzt = int(K["ts"][-1]) + BAR
    t0 = time.time(); r1 = studie(db, jetzt=jetzt); t1 = time.time() - t0; r2 = studie(db, jetzt=jetzt)
    r1 = "\n".join(z for z in r1.split("\n") if not z.startswith("Laufzeit")); r2 = "\n".join(z for z in r2.split("\n") if not z.startswith("Laufzeit"))
    teile = ["1. Nachrechnen", "2. Urteil", "3. Vergleich mit dem Video", "4. Ausstiege", "5. Treffer je Stufe", "6. Kontrolle",
             "7. Empfindlichkeit", "8. Vor dem Zeitraum", "9. Signalliste", "10. Stand jetzt", "11. Labor-Abgleich", "12. Befunde",
             "Prüfsumme der Signale im Urteil"]
    fehlt = [t for t in teile if t not in r1]
    con = sqlite3.connect(os.path.join(pfad, "swing.db"))
    try:
        V = studie_rechnen(SW.kerzen_lesen(con, COIN), SW.funding_lesen(con, COIN), jetzt=jetzt, empf=False)
        V2 = studie_rechnen(SW.kerzen_lesen(con, COIN), SW.funding_lesen(con, COIN), jetzt=jetzt - 5 * TAG, empf=False)
    finally:
        con.close()
    A = V["haupt"]
    kopf = ("ACHTUNG: Die gewählte Lesart" in r1 and "über unsere Fassung der Regeln (nicht nachgebaut)" in r1) if not V["nach"][V["wahl"]]["nachgebaut"] \
        else "ACHTUNG: Die gewählte Lesart" not in r1
    zr = (all(t["k_ts"] >= START_VIDEO and t["t_flip"] + MAX_TAGE * TAG < STICHTAG for t in A["trades"]) and V["ende_urteil"] == STICHTAG
          and not V["vorlaeufig"] and all(t["k_ts"] < START_VIDEO for t in V["vor"]["trades"]) and len(V["vor"]["trades"]) > 0
          and V["vergleich"]["n"] == len(V["alle"]) - 1 and not A["offen"] and len(V["alle"]) > len(A["trades"])
          and V2["pruefsumme"] == V["pruefsumme"] and V2["haupt"]["h1"]["x"] == A["h1"]["x"] and kopf)
    ok("Ende zu Ende auf einer erfundenen swing.db (6,8 Jahre): alle Teile des Berichts, gleiche Daten → gleicher Bericht; Urteil fest bis "
       "zum Stichtag (ein späterer Lauf urteilt gleich), nur Trades, die 120 Tage vor dem Stichtag begannen; davor beschreibend; "
       "Video-Vergleich ohne das jüngste Signal; „nicht nachgebaut“ im Kopf und in der Urteilszeile",
       not fehlt and r1 == r2 and "Traceback" not in r1 and zr, f"fehlt {fehlt}, Zeiträume {zr}, {t1:.1f} s, {len(r1)} Zeichen")


def _probe_null(ok) -> None:
    """Nulltest (KONZEPT 6, kurz): 60 Nullmärkte aus 1-min-Wegen (wie die Kalibrierung, aber 3,5 Jahre) -- H1 nicht deutlich über α_H1,
    Treffer im Mittel wie in den Verschiebungen. Die lange Kalibrierung (--kalibrieren, ≥ 1.000 Märkte) steht in KONZEPT 3.8/3.9."""
    p1, d1 = [], []
    for s in range(60):
        r = null_lauf(4000 + s, start=_t(2020, 1, 1), ende=_t(2023, 7, 1), ab_ts=_t(2021, 1, 1))
        if r["n"] >= 5 and np.isfinite(r["p"]):
            p1.append(r["p"]); d1.append(r["x"] - r["e"])
    p1 = np.array(p1); r1 = float(np.mean(p1 < ALPHA_H1)); md = float(np.mean(d1)); se = float(np.std(d1, ddof=1) / math.sqrt(len(d1)))
    ok(f"Nulltest: 60 Nullmärkte (1-min-Wege, Schwankung log-AR(1)) -- Anteil p < α_H1 ({_de(ALPHA_H1, 3)}) bei H1 höchstens 12 %, Treffer "
       "im Mittel wie in den Verschiebungen (|Überschuss| < 3 Standardfehler)", len(p1) >= 50 and r1 <= 0.12 and abs(md) < 3 * se + 1e-9,
       f"{len(p1)} Märkte: p<α_H1 {r1:.2f}, Überschuss {md:+.2f} ± {se:.2f}")


def _einpflanzen(K: dict, j0: int, sv: int, abstand: float, staerke: float = 0.8, kerzen: int = 96) -> dict:
    """Vorteil ab Kerze j0: der Kurs wandert binnen `kerzen` Kerzen um staerke·R in Signalrichtung (dauerhaft) -- ändert nur Kerzen ab j0."""
    n = len(K["ts"]); r = np.zeros(n)
    r[j0:] = np.minimum(1.0, (np.arange(n - j0) + 1) / kerzen) * sv * staerke * abstand
    f_ = np.exp(r); f_o = np.concatenate([[1.0], f_[:-1]])
    o = np.asarray(K["o"]) * f_o; c = np.asarray(K["c"]) * f_
    return {"ts": K["ts"], "o": o, "c": c, "h": np.maximum(np.asarray(K["h"]) * np.maximum(f_, f_o), np.maximum(o, c)),
            "l": np.minimum(np.asarray(K["l"]) * np.minimum(f_, f_o), np.minimum(o, c))}


def _probe_positiv(ok) -> None:
    """Positivkontrolle: nach jedem Signal -- der Reihe nach auf dem schon veränderten Weg gesucht, damit jedes gezählte Signal seinen
    Vorteil hat -- wandert der Kurs binnen 2 Tagen um 0,8R in Signalrichtung -> H1 meist erfüllt; der Abstand der Trefferquote zu den
    Verschiebungen wird berichtet."""
    treffer = 0; ns = []; hub = []
    for s in range(12):
        K = _weg(3000 + s, tage=2000); letzt = -1
        for _ in range(400):
            D = daten(K)
            nx = next((x for x in signale(D, REGELN, "rang") if x["T"] > letzt and x.get("j0") is not None and not x.get("kein")), None)
            if nx is None:
                break
            K = _einpflanzen(K, nx["j0"], 1 if nx["seite"] == "long" else -1, nx["abstand"]); letzt = nx["T"]
        D = daten(K); P = Passage(D["h"], D["l"])
        A = auswerten(D, P, urteils_signale(signale(D, REGELN, "rang"), D), beschreibend=False)
        h = A["h1"]; ns.append((h["n"], h["x"])); treffer += int(np.isfinite(h["p"]) and h["p"] < ALPHA_H1)
        if h["n"]:
            hub.append(h["x"] / h["n"] - h["erwartet"] / h["n"])
    ok("Positivkontrolle: Vorteil nach jedem Signal eingepflanzt (der Reihe nach, kausal) → H1 in mindestens 11 von 12 Wegen erfüllt",
       treffer >= 11, f"{treffer} von 12, (Trades, Treffer) {ns}, Abstand zur Verschiebung Ø {np.mean(hub) * 100:+.0f} Pp.")
    if hub:
        ok(f"Positivkontrolle: eingepflanzter Vorteil gemessen (Ø {np.mean(hub) * 100:+.0f} Prozentpunkte Treffer über den Verschiebungen)",
           np.mean(hub) > 0.15, f"{np.mean(hub) * 100:+.1f} Pp.")


def _probe_gold(ok) -> None:
    g = {la: _gold(la) for la in LESARTEN}
    ok("Goldprobe: Signale beider Lesarten auf dem festen Weg unverändert (sonst wende_v erhöhen, neue Kennung im Labor)",
       g == GOLD, f"jetzt {g}, gespeichert {GOLD}")


def probe(verbose: bool = True, schnell: bool = False) -> tuple:
    import tempfile
    erg = []

    def ok(name, bed, text=""):
        erg.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f"  ({text})" if text and not bed else ""), flush=True)
    tmp = tempfile.mkdtemp(prefix="wende_test_")
    try:
        for f in (_probe_kerzen, _probe_ema_flips, _probe_schwellen, _probe_grenzen, _probe_signal, _probe_varianten, _probe_kausal,
                  _probe_passage, _probe_handel, _probe_mfe_stufen, _probe_gegenflip, _probe_statistik, _probe_verschiebung,
                  _probe_nachrechnen, _probe_abgleich, _probe_gold):
            try:
                f(ok)
            except Exception as e:  # noqa: BLE001
                import traceback
                ok(f"{f.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        for f in (_probe_labor, _probe_ende_zu_ende):
            try:
                f(ok, tmp)
            except Exception as e:  # noqa: BLE001
                import traceback
                ok(f"{f.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        for f in (() if schnell else (_probe_null, _probe_positiv)):
            try:
                f(ok)
            except Exception as e:  # noqa: BLE001
                import traceback
                ok(f"{f.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
        _LABOR_CACHE.clear()
    return sum(1 for e in erg if e[1]), len(erg)


def selbsttest() -> bool:
    t0 = time.time()
    print(f"Selbsttest hl_wende (Version {VERSION_MODUL})", flush=True)
    a, n = probe()
    print(f"Ergebnis: {'bestanden' if a == n else 'NICHT bestanden'} ({a} von {n}, {time.time() - t0:.1f} s)", flush=True)
    return a == n


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--studie", action="store_true")
    ap.add_argument("--stand", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--kalibrieren", type=int, default=0)
    ap.add_argument("--variante", default="null")
    ap.add_argument("--teil", default="0/1")
    ap.add_argument("--seed", type=int, default=900_000)               # Gegenprobe der Schwelle mit frischen Märkten (KONZEPT 3.9)
    ap.add_argument("--db", default=None)
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.kalibrieren:
        k, m = (int(x) for x in a.teil.split("/"))
        import json
        r = kalibrieren(a.kalibrieren, a.variante, (k, m), seed0=a.seed)
        print(json.dumps(r))
        return 0
    if a.studie or a.stand:
        if not a.db:
            print("--db fehlt"); return 2
        if a.stand:
            W = labor_daten(SW.swing_pfad(a.db), int(time.time()))
            for la in LESARTEN:
                print(f"Lesart {LESART_TXT[la]}: {status_text(dict(REGELN, lesart=la), W, int(time.time()))}")
            return 0
        print(studie(a.db), flush=True)
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
