# AUDIT Gesamt 11.11.2026 — Code, Logik, Inhalt (Paket 2026-09-23.95 · b63b650a9b)

Kurzfassung für die Umsetzung. Der ausführliche Bericht mit Begründungen und Tabellen liegt als Claude-Doc vor:
https://claude.ai/artifact/MPw1Ua7kciDHddLHrBqaLh

Grundlage: Export `hl_liq_export_2026-11-11` (Code, Doku, Berichte vom Pi bis 08.11., 77 Bildschirmfotos). Die Datenbanken des
Pi lagen nicht bei; Zahlen zu Treffern und Labor stammen aus den Berichten (Wochenbündel 04.11., Engine 05.11., Volatilität 30.10.).

## 0. Nachtrag 11.11. abends — Sammeldatei `berichte_2026-11-11_20-30_1d.txt` (19:00–19:20, Paket 23.95)

Gezielt gelesen: Vollbericht, Empfehlungen (U8), Fusion, kalib2, Magnet-Test, Anker, Konfluenz, Labor, Abdeckung, Engine,
Volatilität und Prognosemärkte (Auswertung). Nicht enthalten: Notbremse → N3 nicht nachgeprüft. Der Ausblick kam als Debug 73
nach (siehe unten).

| Größe | 04.11. | 11.11. |
|---|---|---|
| Labor netto (USD), Trades | −239.788, 16.209 | −306.547, 19.341 |
| Gebühren / Abstand / vor Kosten (USD) | 99.914 / 136.307 / −3.387 | 117.418 / 173.527 / −15.436 |
| Anteil XMR an Verlust / Abstand / Trades | 49 % / 75 % / 19 % | 51 % / 76 % / 19 % |
| Familie Orderfluss (USD, t) | −62.847, −19,9 | −79.112, −22,1 (davon XMR −68.858) |
| Kauf-/Verkaufspreise (Trades, %/Trade, t) | 465, −0,244, −2,8 | 540, −0,278, −3,3 |
| Funding-Extrem (USD, t) | +5.780, +1,8 | +3.634, +0,6 |
| Familie Funding / Familie Analog (USD) | +4.606 / +2.434 | +4.273 / +26 |
| BTC 4 h: Treffer, Basis, n_eff, Brier-Skill | 49 %, 52 %, 324, −0,4 % | 50 %, 51 %, 355, −0,3 % |
| BTC 24 h: Treffer, n_eff | 53 %, 54 | 53 %, 60 |
| v1-Gewichte gelernt | 2 von 36 | 0 von 36 |
| Heatmap: Positionen zu alt | 60–80 % | 85 % (128.273 von 150.597; Alter Median 11,5 Tage) |

- **XMR:** von rund −66.800 USD der Woche 58 % aus XMR; Abstand je XMR-Trade in der Woche 49 bps; halber Spread XMR laut
  Fusion-Bericht 0,589 bps.
- **Gegen Münzwurf** (positiv = schlechter; 4 h / 24 h, alle Blöcke): Fusion +0,0052 ± 0,0036 / +0,0220 ± 0,0083; Basisrate
  +0,0095 ± 0,0044 / +0,0399 ± 0,0106; v1 −0,0001 ± 0,0013 / +0,0030 ± 0,0030; v2 +0,0057 / +0,0253; v3 +0,0055 / +0,0385;
  Analog −0,0015 ± 0,0052 / −0,0010 ± 0,0076. Kostenschwelle BTC: 4 h 58,9/52,9 %, 24 h 53,5/51,1 %.
- **v2:** BTC 24 h n 50, Prior-Anteil 0,75 (U196). Direkte Bilanz 4 h: v2 in allen Coins unter der Basisrate (BTC −0,0180 bei
  OOF +0,0223) → OOF-Vorsprung trägt live nicht. U7b in keinem Coin erfüllt.
- **Engine:** 34 beobachtet, 0 aufgenommen; t (A): Familie Analog 1,91, Funding-Extrem 1,37, Familie Orderfluss −9,27.
- **Neu, Sicherung:** täglich 25,5 GB auf die SD-Karte des Systems (`/`, 117 GB, 51 GB frei); frei 54,4 GB, nächste Sicherung
  braucht 30,9 GB; bei +0,3 GB/Tag je Stand reicht das noch rund 3–4 Wochen. Betriebssystem und Sicherung auf derselben Karte.
- **Neu, API-Budget:** 920 von 1.080 je Minute belegt (Poller 70 %, Orders 28 %) → gebündelte Bücher für N1 über WebSocket-Abos,
  nicht über REST.
- **Berichtigung des Audits:** DVOL wird bereits gesammelt und ist als V4 geprüft (30.10.: nicht belegt, p 0,1758); Prognosemärkte
  (U235) ohne Urteil abgeschlossen (H2: Brier-Skill gegen das Modell −0,59 %). S6 zurückgestuft.
- **Levels (für den Wochenplan):** Magnet-Test 64,7 Tage: alle Klassen „nicht belegt“; BTC 1 h große Cluster berührt 10,6 % statt
  6,2 % (+4,2 ± 2,1), ETH +3,4 ± 2,3, BTC 4 h −3,1 ± 2,0. Nullmodell an Zufallsniveaus gut kalibriert. Anker BTC: Beleg nein.
  Konfluenz-Zonen: 46 erreicht, danach 4 h in Zonenrichtung 46 % (Zufall 46 %).
- **Ausblick, Debug 73 (11.11. 20:41; Rückblick 08.11., ab 2022 außerhalb der Stichprobe), vollständig gelesen:**
  - Spanne S1: CRPS-Gewinn gegen B1 7 T +1,5 % (p 0,002), 14 T +0,4 % (p 0,181), 28 T −0,7 % (p 0,804). Deckung 80 % (7 T): BTC
    84,0, ETH 80,4, HYPE 80,7, XMR 82,9, ZEC 79,0, PAXG 67,4 (28 T: 58,0) → PAXG zu eng.
    **Berichtigung 12.11.:** Hier fehlte das Urteil. Debug 73 nennt für alle drei Horizonte „besteht nicht“: Die Gesamtprüfung S1
    verlangt den Vorsprung und die Deckung von BTC und ETH in 80 % ± 2 Standardfehler; bei 7 Tagen liegt BTC mit 84,0 % ± 1,7
    darüber (Band etwas zu weit). Belegt ist der Vorsprung bei 7 Tagen, nicht die Spanne als Ganzes. `KONZEPT_Cockpit.md` führte
    sie deshalb zu Unrecht als „belegt“ (dort Abschnitt 10; berichtigt mit Paket 23.99).
  - Richtung S2: Tor zu bei 7/14/28 T; R²_OS −0,0133 / −0,0175 / −0,0201 (bei 7 und 14 T Intervall unter 0). Alle 36 „trägt
    nicht“ außer D8 Top-Trader nach Konten (Hinweis, p 0,04 bei 7 und 28 T); D5 Konten p 0,10/0,09/0,08, D6 p 0,08 bei 14 T —
    alle mit negativem Gewicht (Gegenanzeiger, Familie von H1). Momentum P1–P3 p 0,11–0,42; Abstand MA 200 p 0,33–0,60;
    Steigung MA 50 p 0,75–0,91.
  - Ziellevels S3 (n 15.412; Prüfniveaus, Swing, runde Zahlen): Brier-Skill +6,2 % / +3,7 % / +1,5 %, Steigung 0,96 / 0,92 /
    0,89 → besteht. Die Wahrscheinlichkeiten hängen nur vom Abstand ab (zwei Niveaus beim selben Kurs = dieselbe Zahl); eine
    Bilanz je Niveau-Art fehlt im Rückblick und in der Vorwärtsbilanz, obwohl `au_vorwaerts` Art, Wahrscheinlichkeit und
    „erreicht“ speichert (`hl_ausblick.py` 1994–2062).
  - Vorwärtsbilanz: 7 T n 492, Deckung 50/80/90 = 59/88/95 %; 14 T n 324, 53/94/96 % (stark überlappend).
  - Folgerung: messbarer Vorsprung bei 7 Tagen, bei 28 Tagen kaum noch; kein Trendmodell. Nächster Schritt für Levels:
    S3 je Niveau-Art und „Schluss jenseits nach Erreichen“ (hält/bricht), vorab festgelegt; Konten-Positionierung nur vorwärts
    oder auf anderen Coins neu prüfen (dieselben Daten sind schon getestet).
- **Wunsch des Nutzers 11.11. 20:25:** Schwerpunkt weg von 4 h, hin zu Trend über Wochen und Levels. Vorschlag: Ausblick als
  Hauptanzeige; Bilanz je Niveau-Art, Wochen-Magnettest, Verhalten nach dem Erreichen; eine neue vorab festgelegte Trend-Runde auf
  der längsten Historie. Siehe `BEWERTUNG_Wochenhorizont_27-10-2026.md` (Richtung 7 Tage nicht belegt, Ziellevels bestehen).

## 1. Kurzfazit

- Code handwerklich sauber: 72 Python-Dateien, rund 104.000 Zeilen; 40 Selbst- und Nulltests und `install.py --selftest-isoliert`
  (89 Prüfungen) in der Sandbox grün; alle Dateien kompilieren; flake8 F = 60 (Ausgangswert).
- 8 neue Befunde (N1–N8), 2 mit hoher Wirkung. U196–U205 und U23 aus dem Audit vom 22.10. weiter offen.
- Richtung über 4 h und 24 h: kein belegter Vorsprung, in keinem Coin, mit keinem Modell. BTC 4 h 49 % (44–55) bei Basisrate 52 %,
  n_eff 324, Brier-Skill −0,4 %.
- Labor: −239.609 USD netto auf 16.206 Trades; davon Gebühren 99.914 und Abstand rund 136.307. Vor Kosten rund −3.400 USD = null.
- Belegt und nutzbar: Niveau der Schwankung (V1), kalibrierte Spannen, Hebel-Warnung H1, Varianz an Datentagen, Wochenendfaktor.
- Ziel „Glaskugel“ erreichbar als geprüfte Verteilung (Fächer, Erreichwahrscheinlichkeiten, Risikoampel) plus wenige bedingte
  Signale mit wirtschaftlicher Begründung — nicht als Richtungsansage für Stunden.

## 2. Neue Befunde

| Nr. | Schwere | Befund | Fundstelle | Abhilfe |
|---|---|---|---|---|
| N1 | hoch | Buchtiefe nur aus den obersten 10 Preisstufen; Labor rechnet alles dahinter pauschal mit ≥ 150 bps | `hl_recorder.py` 1727–1728 (`levels[..][:10]`), `hl_labor.py` 424–439 (Zeile 438) | `impactPxs` mitschreiben; gebündelte Bücher (`l2Book` mit `nSigFigs` 5/4/3, je höchstens 20 Stufen); Pauschale ersetzen; bis dahin Statistik zusätzlich ohne XMR |
| N2 | hoch | „Optimaler Kaufpreis/Verkaufspreis“ wird angezeigt, obwohl die Laborstrategie damit belegt verliert | `hl_forecast.py` 2212 ff., `hl_viz.py` 3880–3881 | umbenennen und Laborbilanz daneben, oder abschalten; Ersatz: Erreichwahrscheinlichkeiten |
| N3 | mittel | Notbremse seit dem Start (23.10.) ohne Live-Kurse für XMR: Korb „K (10)“ rechnet mit 9 | `hl_notbremse.py` 1162–1195 (stilles `continue`), 1414 (`mids_fehlen` nur bei leerer Antwort) | Zähler und Warnung je Instrument; Ursache (vermutlich Name `felix:XMR`) am Pi klären |
| N4 | mittel | Treiber „Orderbuch“ zeigt „±50 bps“, misst aber die obersten 10 Stufen (BTC geschätzt ±1–2 bps) | `hl_forecast.py` 1798 | nach N1 als neuer Treiber mit neuer Kennung starten |
| N5 | mittel | Band und „Konfidenz“ der Hauptprognose nie geprüft; Band wird nicht gespeichert | `hl_forecast.py` 131, `compute_forecast` | geprüftes HAR-/Ausblick-Band zeigen; Band und Pfad speichern; „Konfidenz“ → „Einigkeit der Treiber“ |
| N6 | mittel | Gewicht Modell/Analog folgt dem Rauschen; Deckel 30–70 % endet ab n_eff 50 | `hl_viz.py` 9824–9841 | fest 50/50 oder Fusion |
| N7 | mittel | `score_test` („goldene Regel“) wird wöchentlich überschrieben; keine Historie, kein Bericht, kein Urteil | `hl_viz.py` 9807 | Zeitreihe, Wochenbericht, vorab festgelegtes Urteil |
| N8 | niedrig | Heatmap speichert alle Coins aller Konten (198,8 Mio. Zeilen, +119.000/h; DB 23,6 GB, +0,34 GB/Tag) | `hl_recorder.py` 3201, 3846 ff. | filtern oder Altdaten verdichten; Anteil fremder Coins am Pi zählen |

### Nachweise zu N1

Nachrechnung mit `hl_labor._auswirkung_bps`, Order 10.000 USD, wenn die Bänder nur die sichtbare Tiefe D enthalten:

| D (USD) | bps je Seite | bps Ein + Aus |
|---|---|---|
| 4.000 | 92,1 | 184,2 |
| 7.500 | 41,4 | 82,9 |
| 10.000 | 5,2 | 10,5 |
| 20.000 | 2,9 | 5,8 |

Laborbericht 04.11.: XMR in der Familie Orderfluss 65,6 und 84,7 bps Abstand (Ein + Aus) → passt zu D ≈ 7.500 USD. Mit dreimal so
viel Tiefe hinter den 10 Stufen wären es 7–15 bps je Seite. Die echten Kosten sind nicht gemessen.

Zerlegung je Coin (Tabelle „Je Strategie und Coin“, Abstand aus Mittelwerten zurückgerechnet, USD):

| Coin | Trades | Netto | Gebühren | Abstand | Vor Kosten |
|---|---|---|---|---|---|
| BTC | 2.736 | −23.600 | 20.137 | 1.034 | −2.429 |
| ETH | 3.006 | −25.338 | 19.744 | 1.076 | −4.518 |
| ZEC | 3.887 | −12.798 | 18.999 | 3.300 | +9.501 |
| HYPE | 3.540 | −59.635 | 19.519 | 28.157 | −11.958 |
| XMR | 3.037 | −118.238 | 21.514 | 102.740 | +6.017 |
| Alle | 16.206 | −239.609 | 99.914 | 136.307 | −3.387 |

XMR: 75 % der Abstandskosten, 49 % des Verlusts, 19 % der Trades. Familie Orderfluss: −55.088 von −62.847 USD aus XMR; vor Kosten in
jedem Coin bei null → t −19,9 ist ein Kostenmaß, U242 („Gegenregel“) kann entfallen. Das einzige „belegt“ der Volumenstudie vom
08.11. (`familie_orderfluss` RV) ist vermutlich ein Kosteneffekt (mehr Volumen → mehr sichtbare Tiefe → weniger Pauschale);
Gegenprobe: dieselbe Auswertung ohne XMR.

`impactPxs`: Die Börse meldet im Marktkontext den mittleren Ausführungspreis für 20.000 USDC (BTC, ETH) bzw. 6.000 USDC (übrige)
auf dem vollen Buch. `on_ctx` (`hl_recorder.py` ab 1769, Feed `activeAssetCtx`) speichert mark, oracle, mid, funding, oi, premium —
`impactPxs` nicht; im ganzen Paket kommt das Feld nicht vor. Vor dem Einbau prüfen, ob es im WebSocket-Kontext mitkommt (im
REST-Abruf `metaAndAssetCtxs` ist es enthalten).

### Nachweise zu N2, N5, N6

- N2: Strategie „Kauf-/Verkaufspreise der Prognose“ 04.11.: 465 Trades, 61 % Treffer, −0,244 %/Trade, −11.344 USD, t −2,8.
  Beispiel aus dem Bericht: Ziel 0,78 %, Stopp 2,9 % → nötig wären 79 % Treffer. Bilanz U8 (11.11.): Limit − Markt +0,07 %
  (95 %: −0,02 … +0,16; n 358), nach Füllung 4 h −0,02 % → kein belegter Vorteil des Limits, kaum Negativauslese.
- N5: Bandfaktor 1,3 − 0,6 × Konfidenz → nominelle Abdeckung 77 % (Konfidenz 0,15), 72 % (0,37), 65 % (0,60), 55 % (0,90).
  Geprüfte Bänder im Projekt: HAR 50 % → 51–54 %, 90 % → 89,5–91,7 %; Ausblick BTC 19.10.: 80 % → 83 %.
- N6: Simulation mit zwei Münzwurf-Modellen: Gewicht außerhalb 30–70 % in 49,4 % (n_eff 50), 46,2 % (100), 38,0 % (200),
  28,6 % (400) der Fälle. Pi 04.11. BTC: Modell 43 %, Analog 59 %, n_eff rund 46 → Gewicht ohne Deckel 0,13.

## 3. Offene Altbefunde (Stand 23.95)

| Plan | Prio | Befund | Bemerkung |
|---|---|---|---|
| U196 | P1 | v2 lernt aus `forecast` (60 Tage Vorhalt) bei `TRAIN_TAGE` 90 | Frist „vor dem 10.11.“ verstrichen; ab etwa 13.11. schneidet die Löschung ab; 24 h: Prior-Anteil 1 − n/200 ≥ 0,70 (04.11.: n 45 → 0,775) |
| U200 | P1 | Regel für die v2-Aktivierung ohne Signifikanztest | — |
| U197 | P2 | v1-Label ohne 120-s-Frische | `hl_forecast.py` 699 (Zeile 240 hat die Grenze) |
| U198 | P2 | Vorlauf-Paare in `hl_score.vorlauf` verrutschen | nachgestellt: 236 Schritte mit r4, 216 mit allen Horizonten; mit 3-h-Lücke 108 von 206 Werten im falschen Block; t 0,96 statt 1,17 und −1,08 statt −1,54 (Schwellen 1,0 und −1,5) |
| U204, U205 | P2 | Studien Rücklauf nach Liquidationswellen, informierte große Fills | nicht begonnen |
| U199, U202 | P3 | Statistik der Bilanzen; Robustheitsstellen | — |
| U23 | P3 | Funding-Intervalle je Kontrakt | `hl_ext.py` 219, 254 speichern ungeprüft als 8-h-Satz; kein `fundingInterval` im Paket; Binance (seit 02.05.2025) und Bybit (seit 30.10.2025, BTC/ETH zunächst ausgenommen) rechnen bei Grenztreffer stündlich ab → Faktor bis 8 in Extremlagen |
| U201, U203 | P4 | Doku Prior-Summe; Kleinfill-Sperren | — |

## 4. Logik — Kernaussagen

- **Nachweisgrenze** (einseitig 5 %, Trennschärfe 80 %): wahre Quote 52 % → 3.862 unabhängige Fälle (1,8 Jahre 4-h-Blöcke eines
  Coins), 53 % → 1.715, 55 % → 616, 57 % → 313. Für t ≥ 4 (Engine): 10.000 / 4.444 / 1.600 / 816. Heute BTC 4 h n_eff 324 → SE 2,8
  Punkte, nachweisbar ab etwa 57 %. „2 von 36 Gewichten gelernt“ und „0 von 34 aufgenommen“ sind erwartbar.
- **Kostenschwelle BTC** (Taker/Maker): 1 h 69,0/56,2 %; 4 h 59,3/53,1 %; 12 h 55,5/51,8 %; 24 h 54,0/51,3 %; 1 Woche rund 51,5 %;
  4 Wochen rund 50,8 %. Echte 55 % über 4 h mit Taker: −0,04 %/Trade; über 24 h: +0,02 %.
- **Gegen Münzwurf** (Log-Verlust − ln 2, positiv = schlechter; 4 h / 24 h): Fusion +0,0065 ± 0,0040 / +0,0230 ± 0,0093;
  Basisrate +0,0104 ± 0,0050 / +0,0425 ± 0,0118; v1 −0,0003 ± 0,0014 / +0,0013 ± 0,0033; v2 +0,0062 / +0,0307; v3 +0,0076 / +0,0434;
  Analog +0,0024 ± 0,0054 / −0,0060 ± 0,0084.
- **Vorzeichen:** v1 beschneidet Gewichte auf 0 bis 2 × Prior. v2/v3: „7-Tage-Drift“ in allen Coins und Horizonten negativ,
  „Direktionale Wale“ und „MA 200 Tage“ überwiegend negativ, Familie „Trend lang“ −0,12 bis −0,56.
- **Konstante Treiber:** „MA 200 Tage“ sättigt ab 10 % Abstand (+0,6), „MA 50 Wochen“ (+0,5); bei HYPE, XMR, ZEC konstant, bei BTC
  Mitte Oktober ebenfalls (15,2 % über MA 200). Gehören als Regime-Schalter in den Wochenhorizont.
- **Labor:** netto positiv nur 3 von 49: Funding-Extrem +5.780 USD (107 Trades, 39 Blöcke, t +1,8), Familie Funding +4.606 (t +1,1),
  Familie Analog +2.434 (t +1,3).
- **Notbremse:** 5 Markt-Episoden in 12 Tagen bei Budget 4/30 Tage (erwartet 1,6; p 2,4 %); θ1 am Anschlag −3,50. Terminregel
  sperrt nur Longs, belegt ist aber Varianz (CPI × 2,45, NFP × 1,9), keine Richtung. Welt A − B: +1.867 USD (04.11. morgens),
  −6.132 USD (04.11. abends).
- **Poller/Heatmap:** Reihenfolge nach Größe statt nach Nähe zum Liquidationspreis; Abdeckung BTC 25–29 % des OI; 60–80 % der
  bekannten Positionen im Schnappschuss zu alt; 107 gesperrte Konten (36 % des bekannten Positionswerts) fehlen;
  Cross-Margin-Liquidationspreise gelten nur bei stillstehenden Nachbarpositionen.

## 5. Inhalt — belegt und nicht belegt

Belegt: V1 Niveau der Schwankung (QLIKE-Gewinn 0,0753, p 0,0015, p Holm 0,0292); kalibrierte Bänder; H1 (Binance-Kontenquote ≥ 3:
Rücksetzer in 7 Tagen 20,3 % statt 7,3 %, p Holm 0,012); Datentage; Wochenende (Varianzfaktor 0,68).

Nicht belegt: Richtung 4 h/24 h; „goldene Regel“ (Smart Money 47 %, Elite-Positionierung 39 % Treffer; „Smart Money folgen“
−17.425 USD, t −3,5); ETF-Flüsse als Vorlauf (38 %); Volumenfilter A1/A2; V2–V4; Wahrscheinlichkeit „volatile Woche“ in der
Mitte zu selbstsicher (45 % → 34 %, 55 % → 45 %).

Literatur (Quellen unten) deckt sich damit: ETF-Flüsse folgen dem Kurs; Bestenlisten wiederholen sich nicht verlässlich;
kurzfristige Umkehr existiert, liegt aber in den Kosten; Funding-Extreme drehen nur bedingt; Kaskaden haben kein Einzelsignal,
durchgehend nur sinkende Varianz des Taker-Flusses (= `varianz_kompression`); implizite Volatilität verbessert HAR über 1–24 h um
1,5–3,8 % (im Projekt über Wochen als V4 mit DVOL nicht belegt).

## 6. Stufenplan

- **Stufe 0 — Messgerät reparieren** (grob 1–2 Wochen): N1 (impactPxs, gebündelte Bücher, Pauschale), U196, U197, U198, U23, N3,
  N2 und N6 entfernen, N5 Band ersetzen und speichern, N7 Historie. Tor: Selbsttests und neue Proben grün; Labor und Engine mit
  neuen Kosten neu ausgewiesen; ab hier neue Zählung für Urteile.
- **Stufe 1 — Glaskugel als Verteilung** (grob 2–4 Wochen Bau, 8 Wochen Probe): Fächer 1 Tag/1 Woche/4 Wochen aus HAR mit adaptiver
  konformer Nachstellung, jede Trefferquote sichtbar; Erreichwahrscheinlichkeit je Kurs samt mittlerem Verlauf nach dem Erreichen;
  Risikoampel (H1, Datentag, Wochenende, Varianz-Kompression, Liquidationsdichte) mit Basisraten. Tor: Rückrechnung ≥ 2 Jahre,
  Abdeckung höchstens 3 Punkte neben dem Soll; live innerhalb von 2 Standardfehlern. Der Ausblick wird Hauptanzeige.
- **Stufe 2 — bedingte Signale**, jede Studie vorab festgelegt (Nullmodell, Positivkontrolle, Kostenschwelle, Holm über die Familie),
  danach 8 Wochen Engine:
  - S1 Funding-Extrem bedingt nach Aufwärts-/Abwärtstag (Binance-Funding seit 2020) — Einschätzung mittel
  - S2 Rücklauf nach Liquidationswellen (U204) — gut
  - S3 Fragilität: H1 × OI-Perzentil × Liquidationsdichte → Rücksetzer in 7 Tagen — gut
  - S4 Goldene Regel, Schlussurteil (U205, N7) — gering; danach Thema schließen
  - S5 Querschnitt aller Perps (Momentum, Kurzfrist-Umkehr, Funding-Carry), netto — offen
  - S6 Schwankung plus: stündliche implizite Volatilität über 1–24 h — gering bis mittel (über Wochen ist DVOL als V4 schon
    geprüft: nicht belegt; Prognosemärkte U235 ohne Urteil)

Rechnerische Hebel: Verteilung statt rauf/runter; Priors auf Binance-Historie schätzen statt setzen; Familien statt 36
Einzelgewichten; Breite (alle Perps) statt sechs korrelierter Coins; Hauptprognose auf 24 h und 1 Woche; Maker statt Taker
(4 h: 53,1 statt 59,3 %).

## 7. Maßnahmenliste

**Stand Paket 23.96 (11.11. nachts):** Von den sieben Sofort-Punkten sind gebaut: 1 (Impact-Preise je Minute in `impact_bars`, Vergleich Modell gegen Börse im Labor-Bericht; U246), 2 nur für das Labor (Bilanz je Coin und „ohne XMR“ im Labor-Bericht; U249), 3 nur der Zähler (Notbremse meldet Instrumente ohne Live-Kurs; U247), 4 (U196), 5 (U197), 6 (U198), 7 als Umbenennung („… nach Modell“; U248). **Offen aus der Sofort-Liste:** Engine und Volumenstudie ohne XMR; Ursache des fehlenden XMR-Kurses in der Notbremse (braucht den Notbremse-Bericht vom Pi); Entscheidung des Nutzers, ob Kauf- und Verkaufspreis ganz abgeschaltet werden.

**Stand Paket 23.97 (12.11.):** **N3** ist mit Debug 14 vom 11.11. 23:34 bestätigt und behoben (U250). Ursache war nicht der Name des Marktes, sondern der fest eingetragene Dex-Name „felix“, den es an der Börse nicht gibt (Felix heißt dort „flx“, sein XMR-Markt ist delistet); die Notbremse nimmt jetzt den Markt des Recorders und trägt die fehlenden Kurse aus den Minutenkerzen nach. **N1**, erste Messung (Debug 13 vom 11.11., eine Stunde, 53 Proben je Coin): Die Börse liefert die Impact-Preise; der Abstand je Seite liegt bei XMR im Median bei 4,0 bps gegen 49,3 bps im Modell des Labors (×12,3; 92 % der Proben mit der 150-bps-Pauschale), bei HYPE ×3,6, ZEC ×2,9, BTC ×2,2, ETH ×1,1. Die Richtung von N1 ist damit gemessen, die Höhe erst nach einer Woche Proben (Debug 13 am 18.11.); die Entscheidung über Schritt 2 steht als U252 im Plan. Die Tabelle in Abschnitt 2 und die Liste unten zeigen den Stand vom 11.11.

**Stand Paket 23.98 (12.11.):** Das Cockpit (U245) ist in seiner ersten Stufe gebaut: oben auf der Hauptseite, nur mit Belegtem (farbige Lampen) und Gemessenem (blau); AI-Prognose mit Kauf- und Verkaufspreis, Konfluenz, Treiberfamilien, TradeLabor, Wale und Bestenlisten stehen in der eingeklappten Gruppe „Werkstatt · nicht belegt“. Der Kurs-Rechner (Stufe C2) fehlt noch. Beim Bau gefunden und behoben: Dem Abschnitt „Aktualisierung“ fehlte ein `</div>`. Neue Beobachtung (U253): Die Schockprüfung des Ausblicks überspringt ihre Regeln still, wenn Kerzen fehlen.

Sofort:
1. `impactPxs` in `on_ctx` mitschreiben, einen Tag gegen die Laborkosten vergleichen (N1)
2. Labor und Engine zusätzlich ohne XMR; Volumenstudie ohne XMR gegenrechnen (N1)
3. Notbremse: Zähler je Instrument, XMR-Ursache klären (N3)
4. U196: v2 aus `forecast_slim` und `forecast_drivers`, Löschfrist dort aufheben
5. U197: 120-s-Frische für v1-Labels
6. U198: Vorlauf-Paare je Schritt bilden (`hl_score.py` 160–162)
7. „Optimaler Kaufpreis/Verkaufspreis“ umbenennen oder abschalten (N2)

Danach: gebündelte Bücher und neue Bänder, Pauschale ersetzen (N1); Treiber „Orderbuch“ neu (N4); U23; Band ersetzen und speichern
(N5); Ensemble-Regel ersetzen (N6); `score_test` mit Historie (N7); U200, U199; Notbremse-Terminregel für beide Seiten und Eichung;
Heatmap filtern, Poller nach Liquidationsnähe (N8); Marktkontext aller Perps je Minute sammeln (für S5); MA 200 Tage, MA 50 Wochen
und ETF-Flüsse aus dem 4-h-Bias nehmen.

Später: Stufe 1 und 2; U202, U201, U203; Härtung vor echtem Geld (Anmeldung, signierte Updates, kein Passwort im Klartext).

## 8. Nicht geprüft

Rohdaten des Pi; laufender Betrieb und Browser-Proben; Studienmodule (Makro, Aktien, Chartbild, Zyklen, Swing, Wende, Hebel,
Regime, Volumen, Prognosemärkte, Ausblick) nur über ihre Selbsttests; Bildschirmfotos 9 von 77 (alle Oktober).

## 9. Quellen (geöffnet 11.11.2026)

- Hyperliquid Docs, Fees: https://hyperliquid.gitbook.io/hyperliquid-docs/trading/fees
- Hyperliquid Docs, Contract specifications (Impact-Notional): https://hyperliquid.gitbook.io/hyperliquid-docs/trading/contract-specifications
- l2Book (20 Stufen, nSigFigs): https://docs.chainstack.com/reference/hyperliquid-info-l2-book
- Binance, Funding-Abrechnung ab 02.05.2025: https://www.binance.com/en/support/announcement/3243c81a35bd4f0c86a37315c3dc96cc
- Bybit, dynamische Abrechnungsfrequenz: https://www.aap.com.au/aapreleases/cision20251029ae09993
- DWF Labs zu ETF-Flüssen (694 Handelstage; Korrelation 0,54 davor, 0,03 danach): https://cointelegraph.com/news/bitcoin-etf-flows-follow-price-trends-dwf-labs
- hyperliquid-copytrade-study (389 Trader, Urteil NO-GO): https://github.com/Dennim89/hyperliquid-copytrade-study
- Kaskaden, sieben Ereignisse: https://arxiv.org/abs/2607.27070
- 15-Minuten-Umkehr in den Kosten (183 Binance-Paare; 1,3 bp brutto gegen 5 bp Kosten): https://arxiv.org/abs/2608.21888
- Faktoren im Querschnitt: https://arxiv.org/abs/2510.14435
- Stündliche Bitcoin-Optionen gegen HAR: https://www.sciencedirect.com/science/article/abs/pii/S1544612326013814
- Prognosemärkte und Schwankung: https://arxiv.org/html/2604.01431v1
- Nur Kurzfassung gelesen: Shek, bedingte Umkehr nach Funding-Extremen (274 Ereignisse; +1,88 % an Aufwärtstagen, −1,74 % an
  Abwärtstagen): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7520320 ; Castellanos Macias, Retail-Kosten:
  https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7085378
