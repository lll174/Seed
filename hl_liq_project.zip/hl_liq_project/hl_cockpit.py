#!/usr/bin/env python3
"""
hl_cockpit.py -- Cockpit des Dashboards (U245, KONZEPT_Cockpit.md; Stufe C1, Paket 23.98)

Auftrag des Nutzers (11.11.2026 20:58): „Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen
Indikatoren.“ Entscheidungen vom 12.11. (zum Anklicken): Cockpit oben auf der Hauptseite; ein Coin groß und ein Streifen mit allen
sechs; Unbelegtes in die „Werkstatt“; der Kurs-Rechner (Stufe C2) darf einen Kurs im Browser merken.

Regel: Ein Instrument bekommt nur, was belegt (Klasse A: ein vorab festgelegter Test ist bestanden) oder sauber gemessen ist
(Klasse B: ein Messwert, keine Vorhersage). Jedes Instrument nennt seinen Beleg und seinen Stand. Kein Pfeil, kein Empfehlungswort.
Das Cockpit RECHNET NICHTS NEUES außer Perzentilen und Abständen zum jetzigen Kurs: Es liest die Ergebnisse der Module
  hl_ausblick   Spanne 7/14/28 Tage, Ziellevels mit Erreich-Wahrscheinlichkeit, Ausnahmelage, Rückblick (Trefferquoten)
  hl_volatil    erwartete Schwankung (HAR), realisierte Schwankung 7/30 Tage, DVOL, Urteil V1, Datenprobe Wochenende
  hl_chartbild  Binance-Positionierung (Kontenquote = Regel H1, Open Interest) mit Perzentil gegen 90 Tagesstände, Funding-Druck
  hl_makro      Termine Verbraucherpreise und Arbeitsmarktbericht, Stand der Datentage-Studie
  hl_fusion     mittlere Bewegung E|r| und nötige Trefferquote (Kostenschwelle)
  hl_aktien     Kerzen des S&P-500-Perp -- nur für die Frage, ob die Aktien-Regel des Ausblicks gerade geprüft wird
und ändert nichts: nur lesende Zugriffe, keine Prognose, kein Urteil, kein Labor.

Lampen (Schwellen fest und vorab, KONZEPT_Cockpit 4):
  Hebel       Kontenquote Binance ≥ 3 (hl_chartbild.KONTEN_SCHWELLE, Regel H1)                      -> Hinweis
  Termin      Verbraucherpreise oder Arbeitsmarktbericht: 24 h davor                                -> Hinweis
              von der Veröffentlichung bis 2 h danach, wenn die Datentage-Studie „belegt“ meldet     -> Warnung (sonst Hinweis)
              (ist kein kommender Termin bekannt: grau -- „kein Termin bekannt“ heißt nicht „kein Termin“)
  Wochenende  Samstag oder Sonntag (UTC, wie die Tageswerte der Volatilität)                         -> Hinweis (ruhiger)
  Aktien      Ausnahmelage (c) des Ausblicks: S&P-500-Perp in 6 h über 3 typische Bewegungen, 24 h   -> Hinweis
              („aus“ nur, wenn die Regel nachweislich geprüft wird: Basis vorhanden, letzte Kerze des S&P-500-Perp jünger als
              2 h, letzte Rechnung des Ausblicks jünger als 3 h; sonst grau)
  Schwankung  erwartete Schwankung der nächsten 7 Tage im Perzentil gegen 365 Tage: ab 0,80          -> Hinweis, ab 0,95 Warnung
              (Farbe nur, wenn das Urteil V1 der Volatilität „belegt“ lautet; sonst neutral; Tageswerte älter als 3 Tage: grau)

Aufrufe:  hl_cockpit.py --selbsttest | --text [--db PFAD] [--coin BTC]
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import sys
import time

VERSION_MODUL = "2026-09-23.98"
TAG = 86_400
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")

# ---- Schwellen der Lampen (fest und vorab; eine Änderung ist eine neue Fassung mit Datum)
TERMIN_VOR_S = 24 * 3600
TERMIN_NACH_S = 2 * 3600                       # das Fenster der Datentage-Studie (U154): zwei Stunden nach 8:30 New York
SCHWANKUNG_GELB = 0.80
SCHWANKUNG_ROT = 0.95
PERZ_TAGE = 365                                # Vergleichszeitraum der Schwankung
# ---- Frische: älter -> das Instrument wird grau und nennt seinen Stand
FRISCH_KURS_S = 300
FRISCH_AUSBLICK_S = 2 * TAG                    # wie hl_ausblick.nutzlast („älter als 2 Tage“)
FRISCH_SCHWANKUNG_TAGE = 3                     # wie hl_volatil.nutzlast (Prognose nur, wenn der Ursprung höchstens 3 Tage alt ist)
# ---- Lampe „Aktien“: „aus“ gilt nur, solange die Regel (c) des Ausblicks nachweislich geprüft wird
AKTIEN_REIHE = "xyz:SP500:30m"                 # die Reihe, die hl_ausblick.schock_pruefen liest
AKTIEN_KERZE_S = 2 * 3600                      # wie dort: die letzte Kerze des S&P-500-Perp muss jünger als 2 h sein …
AKTIEN_KERZEN_MIN = 12                         # … und es braucht mindestens 12 Kerzen in den letzten 8 h
AKTIEN_RECHNUNG_S = 3 * 3600                   # die Prüfung läuft im Takt des Ausblicks (stündliche Rechnung): älter als 3 h = Takt steht
LEVELS_JE_SEITE = 3
WORT_VERBOTEN = ("kaufen", "verkaufen", "kaufsignal", "verkaufssignal", "bullisch", "bärisch", "kursziel", "einstieg", "ausstieg",
                 "empfehl", "long gehen", "short gehen")
WOCHENTAGE = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
SATZ_RICHTUNG = "Richtung nicht belegt. Das Cockpit zeigt Spanne, Risiko und Wahrscheinlichkeiten."
BELEG_KOSTEN = ("Rechnung, kein Test: nötige Trefferquote = 1/2 + Kosten ÷ (2 × mittlere Bewegung); Kosten = Gebühr je Seite "
                "(Taker dazu der halbe Spread), hin und zurück.")
BELEG_ER = ("Mittlere absolute Bewegung der letzten 30 Tage. Gegen die eingetretene Bewegung geprüft (Bericht „Fusion“ vom "
            "11.11.2026: Verhältnis 1,02 ± 0,05).")
BELEG_MESSWERT = "Messwert, keine Vorhersage. Perzentil gegen die letzten 90 Tagesstände."



# ================================================================================================ kleine Helfer

def _zahl(x):
    """float oder None (NaN, unendlich, kein Wert -> None)."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _de(x, nd: int = 1, vz: bool = False) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    s = f"{v:+.{nd}f}" if vz else f"{v:.{nd}f}"
    return s.replace(".", ",").replace("-", "−")


def _px(x) -> str:
    """Kurs mit deutscher Tausenderteilung; Nachkommastellen nach Größe."""
    v = _zahl(x)
    if v is None:
        return "—"
    nd = 0 if abs(v) >= 1000 else 2 if abs(v) >= 10 else 4
    s = f"{v:,.{nd}f}"
    return s.replace(",", "§").replace(".", ",").replace("§", ".").replace("-", "−")


def _pc(x, nd: int = 1, vz: bool = False) -> str:
    v = _zahl(x)
    return "—" if v is None else _de(v * 100, nd, vz) + " %"


def _p(p) -> str:
    """p-Wert: unter 0,001 als „< 0,001“, sonst drei Stellen."""
    v = _zahl(p)
    return "—" if v is None else ("< 0,001" if v < 0.001 else _de(v, 3))


def _datum(ts) -> str:
    v = _zahl(ts)
    return "—" if v is None else time.strftime("%d.%m. %H:%M UTC", time.gmtime(int(v)))


def _tag_datum(tag) -> str:
    v = _zahl(tag)
    return "—" if v is None else time.strftime("%d.%m.%Y", time.gmtime(int(v) * TAG))


def perzentil(x, werte) -> float | None:
    """Mittelrang von x unter den Werten (wie hl_chartbild.perzentil): mindestens 60 endliche, nicht alle gleich; sonst None."""
    v = _zahl(x)
    w = [u for u in (_zahl(a) for a in (werte or [])) if u is not None]
    if v is None or len(w) < 60 or max(w) == min(w):
        return None
    kleiner = sum(1 for a in w if a < v); gleich = sum(1 for a in w if a == v)
    return (kleiner + 0.5 * gleich) / len(w)


def _lampe(key, name, zustand, wort, wert, detail, beleg, klasse="A", **mehr) -> dict:
    d = {"key": key, "name": name, "zustand": zustand, "wort": wort, "wert": wert, "detail": detail, "beleg": beleg, "klasse": klasse}
    d.update(mehr)
    return d


# ================================================================================================ Lampen (reine Funktionen)

def lampe_hebel(coin: str, konten: dict | None, schwelle: float, beleg: str, fehlt: str = "") -> dict:
    """Regel H1: Kontenquote Binance (Long- zu Short-Konten) ≥ Schwelle. konten = Eintrag aus hl_chartbild.positionierung."""
    name = "Hebel"
    w = _zahl((konten or {}).get("wert"))
    if w is None:
        return _lampe("hebel", name, "grau", "kein Wert", "—", fehlt or f"Für {coin} liegt keine frische Kontenquote von Binance vor.", beleg)
    art = (konten or {}).get("art") or ""
    stand = (konten or {}).get("ts") or ((int((konten or {}).get("tag")) + 1) * TAG if (konten or {}).get("tag") is not None else None)
    if w >= schwelle:
        return _lampe("hebel", name, "hinweis", "Hinweis", f"{_de(w, 2)} ≥ {_de(schwelle, 0)}",
                      f"Kontenquote Binance {_de(w, 2)}: Auf ein Short-Konto kommen {_de(w, 2)} Long-Konten ({art}). Ab {_de(schwelle, 0)} "
                      "folgte in 7 Tagen häufiger ein Rücksetzer.", beleg, stand=stand, zahl=w)
    return _lampe("hebel", name, "aus", "aus", f"{_de(w, 2)} von {_de(schwelle, 0)}",
                  f"Kontenquote Binance {_de(w, 2)} ({art}); die Regel greift ab {_de(schwelle, 0)}.", beleg, stand=stand, zahl=w)


def lampe_termin(termine: list | None, naechste: dict | None, stand: dict | None, jetzt: int, geladen: bool = True) -> dict:
    """
    termine: [{"reihe": "CPIAUCSL"|"UNRATE", "name": …, "ts": Veröffentlichung in UTC-Sekunden}] (hl_makro.datentag_info);
    naechste: {Name: ts} der nächsten Termine (hl_makro.usa_termine); stand: Datentage-Studie {"H1": {"belegt", "abs_verh"}, "H2": …}.
    """
    name = "Termin"
    kuerzel = {"CPIAUCSL": "H1", "UNRATE": "H2"}
    teile = []
    for k, n_ in (("H1", "Verbraucherpreise"), ("H2", "Arbeitsmarktbericht")):
        h = (stand or {}).get(k) or {}
        if h.get("belegt") is True and _zahl(h.get("abs_verh")):
            teile.append(f"{n_} rund {_de(h['abs_verh'], 1)}-mal")
    beleg = ("Datentage-Studie (U154), belegt: in den zwei Stunden nach der Veröffentlichung waren die Kursausschläge von BTC und ETH "
             "im Mittel größer als an anderen Werktagen (" + ", ".join(teile) + "). Keine Richtung.") if teile else \
        "Datentage-Studie (U154): noch kein Stand mit „belegt“ -- die Lampe zeigt nur den Termin."
    if not geladen:
        return _lampe("termin", name, "grau", "kein Wert", "—", "Die Termine der USA sind noch nicht geladen (makro.db).", beleg)
    aktiv = None
    for t in sorted(termine or [], key=lambda e: e.get("ts") or 0):
        ts = _zahl(t.get("ts"))
        if ts is None or t.get("reihe") not in kuerzel:
            continue
        if ts - TERMIN_VOR_S <= jetzt < ts + TERMIN_NACH_S:
            aktiv = t; break
    if aktiv:
        ts = int(aktiv["ts"]); h = (stand or {}).get(kuerzel[aktiv["reihe"]]) or {}
        belegt = h.get("belegt") is True and bool(_zahl(h.get("abs_verh")))
        if jetzt >= ts:
            zus = (f" In den zwei Stunden danach waren die Kursausschläge im Mittel rund {_de(h['abs_verh'], 1)}-mal so groß."
                   if belegt else "")
            return _lampe("termin", name, "warnung" if belegt else "hinweis", "läuft", aktiv["name"],
                          f"{aktiv['name']} der USA: veröffentlicht, das Fenster der Studie läuft bis zwei Stunden danach.{zus}",
                          beleg, ts=ts, ts_ende=ts + TERMIN_NACH_S)
        return _lampe("termin", name, "hinweis", "Hinweis", aktiv["name"],
                      f"{aktiv['name']} der USA in weniger als 24 Stunden.", beleg, ts=ts)
    kommend = sorted((int(v), k) for k, v in (naechste or {}).items()
                     if k in ("Verbraucherpreise", "Arbeitsmarktbericht") and _zahl(v) and v >= jetzt)
    if kommend:
        ohne = [n_ for n_ in ("Verbraucherpreise", "Arbeitsmarktbericht") if n_ not in {k for _, k in kommend}]
        return _lampe("termin", name, "aus", "aus", kommend[0][1], f"Nächster Termin: {kommend[0][1]} der USA."
                      + (f" Für {ohne[0]} ist kein kommender Termin bekannt." if ohne else ""), beleg, ts=kommend[0][0])
    # kein kommender Termin bekannt: Das ist kein „aus“ -- der Kalender kann leer oder veraltet sein
    return _lampe("termin", name, "grau", "kein Wert", "keiner bekannt",
                  "Kein kommender Termin für Verbraucherpreise oder Arbeitsmarktbericht bekannt -- der Kalender der Veröffentlichungen "
                  "ist leer oder veraltet (Abschnitt „Makro“).", beleg)


def lampe_wochenende(jetzt: int, faktor: float | None = None) -> dict:
    """Samstag oder Sonntag nach UTC (die Tageswerte der Volatilität sind UTC-Tage)."""
    wt = time.gmtime(int(jetzt)).tm_wday
    f = _zahl(faktor)
    beleg = (f"Datenprobe der Volatilität: Varianz an Samstagen und Sonntagen im Mittel das {_de(f, 2)}-Fache der Werktage (BTC und ETH "
             "seit 2020). Ein Messwert, kein Test." if f is not None else
             "Datenprobe der Volatilität steht noch aus (erwartet: am Wochenende ruhiger).")
    if wt >= 5:
        return _lampe("wochenende", "Wochenende", "hinweis", "an", WOCHENTAGE[wt],
                      "Wochenende (UTC): Die Schwankung ist an diesen Tagen im Mittel kleiner"
                      + (f" (Varianz × {_de(f, 2)})." if f is not None else "."), beleg, klasse="B")
    return _lampe("wochenende", "Wochenende", "aus", "aus", WOCHENTAGE[wt], "Werktag (UTC).", beleg, klasse="B")


def lampe_aktien(coin: str, ausnahme: dict | None, jetzt: int, dauer_s: int, text: str = "", s4: dict | None = None,
                 pruefung: dict | None = None) -> dict:
    """Ausnahmelage (c) des Ausblicks (hl_ausblick.schock_pruefen): S&P-500-Perp in 6 h über 3 typische Bewegungen; gilt 24 h.
    pruefung: Ergebnis von aktien_pruefung (wird die Regel gerade geprüft?). Ohne Nachweis gibt es kein „aus“, nur „kein Wert“."""
    p = _zahl(((s4 or {}).get("variogramm") or {}).get("p")) if s4 else None
    if s4 and s4.get("besteht") is True:
        beleg = ("Abhängigkeit vom S&P 500 im Rückblick des Ausblicks belegt" + (f" (p {_p(p)})" if p is not None else "")
                 + ". Die Lampe zeigt die Ausnahmelage des Ausblicks; unter Aktienstress ist die Spanne nicht geprüft kalibriert.")
    elif s4 and s4.get("besteht") is False:
        beleg = ("Abhängigkeit vom S&P 500 im jüngsten Rückblick nicht belegt" + (f" (p {_p(p)})" if p is not None else "")
                 + ". Die Lampe zeigt nur die Ausnahmelage des Ausblicks.")
    else:
        beleg = "Abhängigkeit vom S&P 500: der Rückblick des Ausblicks steht noch aus. Die Lampe zeigt nur die Ausnahmelage."
    if coin == "PAXG":
        return _lampe("aktien", "Aktien", "grau", "gilt nicht", "—", "Für PAXG (Gold) wird die Aktien-Regel nicht angewendet.", beleg)
    a = ausnahme or {}
    seit = _zahl(a.get("seit"))
    if a.get("regel") == "c" and seit is not None and 0 <= jetzt - seit < dauer_s:
        bew = _zahl(a.get("bewegung"))
        return _lampe("aktien", "Aktien", "hinweis", "Hinweis", "S&P " + (_pc(bew, 1, True) if bew is not None else "bewegt"),
                      text or "Der S&P-500-Perp hat sich in 6 Stunden ungewöhnlich stark bewegt.", beleg, ts=int(seit), ts_ende=int(seit) + dauer_s)
    pr = pruefung or {}
    if a.get("regel") in ("a", "b") and seit is not None and 0 <= jetzt - seit < dauer_s:
        # hl_ausblick.schock_pruefen setzt (c) nicht, solange für den Coin schon eine Ausnahmelage gilt
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      f"Für {coin} gilt schon eine Ausnahmelage aus der eigenen Bewegung (sie steht unter dem Kernsatz). Solange sie "
                      "gilt, setzt der Ausblick die Aktien-Regel für diesen Coin nicht.", beleg, ts_ende=int(seit) + dauer_s)
    if pr.get("ok") is not True:
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      pr.get("grund") or "Ob der Ausblick die Aktien-Regel gerade prüft, ist nicht bekannt.", beleg, stand=pr.get("kerze_ts"))
    if pr.get("coins") is not None and coin not in pr["coins"]:
        # schock_pruefen setzt (c) nur für Coins, die in der letzten Rechnung des Ausblicks stehen
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      f"Für {coin} steht in der letzten Rechnung des Ausblicks keine Basis -- die Aktien-Regel wird für diesen Coin nicht gesetzt.",
                      beleg, stand=pr.get("kerze_ts"))
    return _lampe("aktien", "Aktien", "aus", "aus", "keine Ausnahme",
                  "Keine Ausnahmelage aus dem S&P-500-Perp in den letzten 24 Stunden; die Regel wird laufend geprüft.", beleg,
                  stand=pr.get("kerze_ts"))


def aktien_pruefung(fs1, kerzen_n: int | None, kerze_ts, rechnung_ts, jetzt: int, coins=None) -> dict:
    """
    Wird die Regel (c) gerade geprüft? Dieselben Bedingungen wie in hl_ausblick.schock_pruefen: Basis FS1 vorhanden, mindestens
    12 Kerzen des S&P-500-Perp in den letzten 8 h, die letzte jünger als 2 h. Dazu: Die Prüfung läuft im Takt des Ausblicks -- ist
    dessen letzte Rechnung älter als 3 h, steht der Takt. coins: die Coins der Basis (nur für sie setzt die Regel eine Ausnahme).
    -> {"ok", "grund", "kerze_ts", "rechnung_ts", "coins"}
    """
    kt = _zahl(kerze_ts); rt = _zahl(rechnung_ts)
    out = {"ok": False, "grund": "", "kerze_ts": int(kt) if kt is not None else None, "rechnung_ts": int(rt) if rt else None,
           "coins": sorted(coins) if coins is not None else None}
    if not _zahl(fs1):
        out["grund"] = ("Dem Ausblick fehlt die Basis für die Aktien-Regel (die typische Tagesbewegung des S&P 500 aus seiner letzten "
                        "Rechnung) -- die Regel wird nicht geprüft.")
    elif kt is None or int(kerzen_n or 0) < AKTIEN_KERZEN_MIN:
        out["grund"] = ("Vom S&P-500-Perp liegen in den letzten 8 Stunden zu wenige Kerzen vor"
                        + (f" (letzte {_datum(kt)})" if kt is not None else "") + " -- die Aktien-Regel wird gerade nicht geprüft.")
    elif jetzt - kt >= AKTIEN_KERZE_S:
        out["grund"] = f"Die letzte Kerze des S&P-500-Perp ist von {_datum(kt)} -- die Aktien-Regel wird gerade nicht geprüft."
    elif not rt or jetzt - rt > AKTIEN_RECHNUNG_S:
        out["grund"] = ("Die letzte Rechnung des Ausblicks ist " + (f"von {_datum(rt)}" if rt else "nicht bekannt")
                        + " -- sein Takt, in dem die Aktien-Regel geprüft wird, steht offenbar.")
    else:
        out["ok"] = True
    return out


def lampe_schwankung(pz: float | None, v1: str | None, quelle: str, wert_pa: float | None, fehlt: str = "", stand: str = "") -> dict:
    """pz: Perzentil der erwarteten (sonst der realisierten) Schwankung gegen 365 Tage. Farbe nur bei Urteil V1 „belegt“.
    stand: Satz zum Stand der Tageswerte (steht im Detail)."""
    belegt = v1 == "belegt"
    beleg = ("Niveau der Schwankung über 1–4 Wochen: belegt (Urteil V1 der Volatilität)." if belegt else
             "Niveau der Schwankung: noch kein Urteil „belegt“ (V1) -- die Lampe bleibt neutral und zeigt nur das Perzentil.")
    if pz is None:
        return _lampe("schwankung", "Schwankung", "grau", "kein Wert", "—", fehlt or "Keine Schwankungswerte für diesen Coin.", beleg)
    txt = f"{_de(pz * 100, 0)}. Perzentil"
    detail = (f"{quelle} {_de(wert_pa, 1)} % pro Jahr: höher als an {_de(pz * 100, 0)} % der Tage der letzten {PERZ_TAGE} Tage."
              + (" " + stand if stand else ""))
    if not belegt or quelle.startswith("Realisierte"):
        return _lampe("schwankung", "Schwankung", "aus", "neutral", txt, detail, beleg, klasse="B", pz=pz)
    if pz >= SCHWANKUNG_ROT:
        return _lampe("schwankung", "Schwankung", "warnung", "hoch", txt, detail, beleg, pz=pz)
    if pz >= SCHWANKUNG_GELB:
        return _lampe("schwankung", "Schwankung", "hinweis", "erhöht", txt, detail, beleg, pz=pz)
    return _lampe("schwankung", "Schwankung", "aus", "aus", txt, detail, beleg, pz=pz)


# ================================================================================================ Instrumente (reine Funktionen)

def spanne_bauen(coin: str, prognose: dict | None, rueckblick: dict | None, kurs: float | None, jetzt: int) -> dict:
    """Spannen 7/14/28 Tage aus der jüngsten Rechnung des Ausblicks; Trefferquote des 80-%-Bands aus dem Rückblick (S1)."""
    out = {"h": {}, "fehlt": [], "frisch": False, "anker": None, "p0": None, "kurs": _zahl(kurs)}
    P = prognose or {}
    sp = P.get("spannen") or {}
    if not sp:
        out["fehlt"].append("Noch keine Rechnung des Ausblicks für diesen Coin.")
        out["beleg"] = "Ausblick: noch keine Spanne."
        return out
    out["anker"] = P.get("anker"); out["p0"] = _zahl(P.get("p0"))
    alter = jetzt - int(P.get("anker") or 0)
    out["frisch"] = alter <= FRISCH_AUSBLICK_S
    if not out["frisch"]:
        out["fehlt"].append(f"Stand vom {_datum(P.get('anker'))} -- älter als 2 Tage.")
    S1 = ((rueckblick or {}).get("s1") or {}).get("h") or {}
    lo = hi = None
    for h in ("7", "14", "28"):
        q = [(_zahl(x)) for x in ((sp.get(h) or {}).get("q") or [])]
        if len(q) != 7 or any(x is None for x in q):
            continue
        e = S1.get(h) or {}
        d = ((e.get("deckung") or {}).get(coin) or {})
        tr = _zahl(d.get("d80"))
        gew = _zahl(e.get("gewinn_rel")); p = _zahl(e.get("p"))
        if not S1:
            vermerk = "Rückblick steht aus"
        elif e.get("besteht") is True or (e.get("besteht") is None and p is not None and p < 0.05 and (gew or 0) > 0):
            vermerk = (f"traf {_de(tr * 100, 0)} %" if tr is not None else "geprüft")
            if tr is not None and d.get("ok") is False:                      # wie hl_ausblick.deckung_wertung
                vermerk += " (zu eng)" if tr < 0.80 else " (zu weit)"
        elif h == "28":
            vermerk = "nur Rahmen"
        else:
            vermerk = "Vorsprung offen"
        out["h"][h] = {"q": q, "treffer": tr, "se": _zahl(d.get("se")), "gewinn": gew, "p": p,
                       "besteht": e.get("besteht") if "besteht" in e else None, "vermerk": vermerk}
        lo = q[0] if lo is None else min(lo, q[0]); hi = q[6] if hi is None else max(hi, q[6])
    if lo is not None:
        k = out["kurs"] or out["p0"]
        if k:
            lo, hi = min(lo, k), max(hi, k)
        rand = (hi - lo) * 0.04
        out["skala"] = [lo - rand, hi + rand]
    e7 = S1.get("7") or {}
    if e7:
        d7 = ((e7.get("deckung") or {}).get(coin) or {})
        out["beleg"] = ("Geprüft im Rückblick des Ausblicks (außerhalb der Stichprobe): über 7 Tage "
                        + ("schlägt die Spanne das einfache Vergleichsmodell" if (_zahl(e7.get("gewinn_rel")) or 0) > 0 and (_zahl(e7.get("p")) or 1) < 0.05
                           else "ist ein Vorsprung gegen das einfache Vergleichsmodell nicht belegt")
                        + f" (Gewinn {_pc(e7.get('gewinn_rel'), 1, True)}, p {_p(e7.get('p'))})"
                        + (f"; das 80-%-Band traf bei {coin} {_de((_zahl(d7.get('d80')) or 0) * 100, 0)} %." if _zahl(d7.get("d80")) is not None else "."))
    else:
        out["beleg"] = "Der Rückblick des Ausblicks steht noch aus -- die Spanne ist noch nicht geprüft."
    return out


def levels_bauen(prognose: dict | None, rueckblick: dict | None, kurs: float | None, je_seite: int = LEVELS_JE_SEITE) -> dict:
    """Die nächsten Niveaus über und unter dem JETZIGEN Kurs aus der jüngsten Rechnung des Ausblicks. Die Wahrscheinlichkeiten gelten
    ab dem Anker; ein Niveau, das seit dem Anker durchlaufen wurde, erscheint nicht mehr (es wird gezählt)."""
    P = prognose or {}
    p0 = _zahl(P.get("p0")); k = _zahl(kurs) or p0
    out = {"oben": [], "unten": [], "kurs": k, "p0": p0, "anker": P.get("anker"), "durchlaufen": 0, "fehlt": []}
    S3 = ((rueckblick or {}).get("s3") or {}).get("h") or {}
    e7 = S3.get("7") or {}
    if e7:
        out["beleg"] = ("Erreich-Wahrscheinlichkeiten im Rückblick geprüft: über 7 Tage Brier-Skill "
                        f"{_pc(e7.get('skill'), 1, True)}, Steigung {_de(e7.get('steigung'), 2)} "
                        f"({'besteht' if e7.get('besteht') else 'besteht nicht'}). Die Zahl folgt allein aus dem Abstand; die Art des "
                        "Niveaus ist nicht geprüft.")
    else:
        out["beleg"] = "Der Rückblick des Ausblicks steht noch aus -- die Wahrscheinlichkeiten sind noch nicht geprüft."
    if not k or not P.get("niveaus"):
        out["fehlt"].append("Keine Niveaus aus dem Ausblick.")
        return out
    oben, unten = [], []
    for n in P.get("niveaus") or []:
        px = _zahl(n.get("px")); p = n.get("p") or {}
        if px is None or not p or px <= 0:
            continue
        p7 = _zahl((p.get("7") or [None])[0]); p14 = _zahl((p.get("14") or [None])[0])
        if p7 is None or p14 is None:
            continue
        if p0 and ((px - p0) * (px - k) < 0 or px == k):
            out["durchlaufen"] += 1                                  # lag über dem Anker und liegt jetzt unter dem Kurs (oder umgekehrt)
            continue
        e = {"name": str(n.get("name") or "")[:60], "px": px, "abstand": px / k - 1.0, "p7": p7, "p14": p14,
             "momentaufnahme": bool(n.get("momentaufnahme")), "art": n.get("art") or ""}
        (oben if px > k else unten).append(e)
    oben.sort(key=lambda e: e["px"]); unten.sort(key=lambda e: -e["px"])
    out["oben"] = oben[:je_seite][::-1]                              # in der Anzeige: das fernste oben, das nächste direkt über dem Kurs
    out["unten"] = unten[:je_seite]
    return out


def schwankung_bauen(vol: dict | None, er4: float | None, jetzt: int) -> dict:
    """vol: Ergebnis von schwankung_lesen (hl_volatil). -> Instrument „Schwankung“ mit Perzentil gegen 365 Tage."""
    V = vol or {}
    out = {"erwartet": _zahl(V.get("erwartet")), "real7": _zahl(V.get("real7")), "real30": _zahl(V.get("real30")), "dvol": _zahl(V.get("dvol")),
           "er4": _zahl(er4), "modell": V.get("modell_text"), "ursprung": V.get("ursprung"), "v1": V.get("v1"), "stand_tag": V.get("bis"),
           "fehlt": list(V.get("fehlt") or []), "pz": None, "pz_von": None, "skala_max": None}
    bis = _zahl(V.get("bis"))
    # Frische: Tageswerte höchstens 3 Tage alt (wie schwankung_lesen); sonst wird das Instrument blass und die Lampe grau
    out["frisch"] = bis is not None and int(jetzt) // TAG - int(bis) <= FRISCH_SCHWANKUNG_TAGE
    if bis is not None and not out["frisch"] and not any("Tageswerte nur bis" in f for f in out["fehlt"]):
        out["fehlt"].append(f"Tageswerte nur bis {_tag_datum(bis)}.")
    out["stand_text"] = ("" if bis is None else f"Stand: Tageswerte bis {_tag_datum(bis)} (UTC)"
                         + (f", Prognose vom {_tag_datum(V.get('ursprung'))}" if out["erwartet"] is not None and _zahl(V.get("ursprung")) is not None else "")
                         + ".")
    reihe = V.get("vi7_reihe") or []
    if out["erwartet"] is not None:
        out["pz"] = perzentil(out["erwartet"], reihe[-PERZ_TAGE:]); out["pz_von"] = "Erwartete Schwankung (7 Tage)"; anz = out["erwartet"]
    elif out["real7"] is not None:
        out["pz"] = perzentil(out["real7"], reihe[-PERZ_TAGE - 1:-1]); out["pz_von"] = "Realisierte Schwankung (7 Tage)"; anz = out["real7"]
    else:
        anz = None
    out["anzeige"] = anz
    endlich = [u for u in (_zahl(a) for a in reihe[-PERZ_TAGE:]) if u is not None]
    if anz is not None:
        out["skala_max"] = float(max([anz * 1.15] + ([max(endlich)] if endlich else []) + [20.0]))
    v1 = V.get("v1")
    out["beleg"] = ("Niveau der Schwankung belegt (Urteil V1 der Volatilität"
                    + (f", p Holm {_de(V.get('v1_p_holm'), 4)}" if _zahl(V.get("v1_p_holm")) is not None else "") + "). "
                    if v1 == "belegt" else "Niveau der Schwankung: noch kein Urteil „belegt“ (V1). ") \
        + ("„In 4 h typisch“: " + BELEG_ER if out["er4"] is not None else "")
    return out


def messwerte_bauen(lage: dict | None, funding: dict | None, schwelle: float, coin: str = "") -> list:
    """Klasse B: Open Interest und Kontenquote (Binance) mit Perzentil gegen 90 Tagesstände, Funding-Druck. Neutral, keine Wertung."""
    L = lage or {}
    out = []
    for key, name, nd in (("oi", "Open Interest (Binance)", None), ("konten", "Kontenquote (Binance)", 2)):
        e = L.get(key) or {}
        w = _zahl(e.get("wert"))
        z = {"key": key, "name": name, "wert": w, "pz": _zahl(e.get("pz")), "art": e.get("art") or "",
             "stand": e.get("ts"), "stand_tag": _tag_datum(e["tag"]) if e.get("ts") is None and e.get("tag") is not None else None}
        if key == "konten":
            z["marke"] = schwelle; z["text"] = _de(w, 2) if w is not None else "—"
        else:
            z["text"] = "—" if w is None else f"{_px(w)} {coin}".strip()
        out.append(z)
    f = funding or {}
    out.append({"key": "funding", "name": "Funding-Druck (Binance, 30 Tage)", "wert": _zahl(f.get("z")), "pz": None,
                "text": _de(f.get("z"), 1, True) if _zahl(f.get("z")) is not None else "—", "art": "z-Wert",
                "stand": None, "stand_tag": _tag_datum(f["tag"]) if f.get("tag") is not None else None})
    return out


def kosten_bauen(ks: dict | None) -> dict:
    """Nötige Trefferquote für 4 und 24 Stunden aus hl_fusion.kostenschwelle (flache Schlüssel er_h, p_taker_h, p_maker_h)."""
    K = ks or {}
    out = {"zeilen": [], "taker": _zahl(K.get("taker")), "maker": _zahl(K.get("maker")), "halbspread_bps": _zahl(K.get("halbspread_bps")),
           "stand": K.get("ts"), "tage": K.get("tage"), "beleg": BELEG_KOSTEN, "fehlt": []}
    for h in (4, 24):
        pt, pm, er = _zahl(K.get(f"p_taker_{h}")), _zahl(K.get(f"p_maker_{h}")), _zahl(K.get(f"er_{h}"))
        if er is None or pt is None or pm is None:
            continue
        out["zeilen"].append({"h": h, "er": er, "taker": pt, "maker": pm})
    if not out["zeilen"]:
        out["fehlt"].append("Noch zu wenige Minutenkerzen für die mittlere Bewegung (mindestens 3 Tage).")
    return out


def satz_bauen(coin: str, spanne: dict, ausnahme_text: str = "") -> dict:
    """Kernsatz aus der 7-Tage-Spanne; ohne Richtung."""
    e = (spanne.get("h") or {}).get("7")
    if e:
        q = e["q"]
        text = f"In 7 Tagen liegt {coin} mit 80 % zwischen {_px(q[1])} und {_px(q[5])}."
    else:
        text = f"Für {coin} liegt noch keine Spanne aus dem Ausblick vor."
    if e and not spanne.get("frisch"):
        text += " Der Stand ist älter als 2 Tage."
    return {"text": text, "zusatz": SATZ_RICHTUNG, "ausnahme": ausnahme_text or None}


def bauen(Q: dict) -> dict:
    """
    Reine Zusammenstellung aus den gelesenen Quellen Q (siehe quellen_lesen): coin, jetzt, kurs {px, ts}, ausblick {prognose,
    rueckblick, fehlt}, ausnahme, ausnahme_dauer, ausnahme_text, aktien_pruefung, vol, kosten, termine, naechste, datentag_stand,
    termine_geladen, lage, funding, konten_schwelle, konten_beleg, wochenende_faktor. Nichts wird geschätzt: was fehlt, steht in „fehlt“.
    """
    coin = Q["coin"]; jetzt = int(Q["jetzt"])
    K = Q.get("kurs") or {}
    px = _zahl(K.get("px")); kts = K.get("ts")
    kurs_frisch = px is not None and kts is not None and jetzt - int(kts) <= FRISCH_KURS_S
    A = Q.get("ausblick") or {}
    P = A.get("prognose"); R = A.get("rueckblick")
    a = Q.get("ausnahme") or {}
    aktiv = _zahl(a.get("seit")) is not None and 0 <= jetzt - a["seit"] < int(Q.get("ausnahme_dauer") or TAG)
    spanne = spanne_bauen(coin, P, R, px if kurs_frisch else None, jetzt)
    levels = levels_bauen(P, R, px if kurs_frisch else None)
    levels["frisch"] = bool(spanne.get("frisch"))                    # dieselbe Rechnung des Ausblicks wie die Spanne
    if (levels["oben"] or levels["unten"]) and not levels["frisch"]:
        levels["fehlt"].append(f"Stand vom {_datum(levels.get('anker'))} -- älter als 2 Tage.")
    ks = Q.get("kosten") or {}
    schw = schwankung_bauen(Q.get("vol"), ks.get("er_4"), jetzt)
    schwelle = float(Q.get("konten_schwelle") or 3.0)
    lage = Q.get("lage") or {}
    lampen = [
        lampe_hebel(coin, lage.get("konten"), schwelle, Q.get("konten_beleg") or "", "; ".join(lage.get("fehlt") or [])),
        lampe_termin(Q.get("termine"), Q.get("naechste"), Q.get("datentag_stand"), jetzt, bool(Q.get("termine_geladen", True))),
        lampe_wochenende(jetzt, Q.get("wochenende_faktor")),
        lampe_aktien(coin, a, jetzt, int(Q.get("ausnahme_dauer") or TAG), Q.get("ausnahme_text") or "", (R or {}).get("s4"),
                     Q.get("aktien_pruefung")),
        lampe_schwankung(schw["pz"] if schw["frisch"] else None, schw.get("v1"), schw.get("pz_von") or "", schw.get("anzeige"),
                         "; ".join(schw["fehlt"]), schw.get("stand_text") or ""),
    ]
    out = {"ok": True, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL,
           "kopf": {"kurs": px, "kurs_ts": kts, "frisch": bool(kurs_frisch), "quelle": K.get("quelle") or ""},
           "satz": satz_bauen(coin, spanne, (Q.get("ausnahme_text") or "") if (aktiv and a.get("regel") in ("a", "b")) else ""),
           "lampen": lampen, "schwankung": schw, "spanne": spanne, "levels": levels,
           "messwerte": messwerte_bauen(lage, Q.get("funding"), schwelle, coin), "messwerte_beleg": BELEG_MESSWERT,
           "kosten": kosten_bauen(ks), "fehlt": list(A.get("fehlt") or []) + list(Q.get("fehlt") or [])}
    return out


def kern(coin: str, Q: dict) -> dict:
    """Schmale Fassung je Coin für den Streifen: 80-%-Spanne der 7 Tage (in % zum Anker) und die Zustände der fünf Lampen."""
    d = bauen(Q)
    e = (d["spanne"]["h"] or {}).get("7")
    p0 = d["spanne"].get("p0")
    return {"coin": coin, "lo": (e["q"][1] / p0 - 1.0) if e and p0 else None, "hi": (e["q"][5] / p0 - 1.0) if e and p0 else None,
            "lampen": [l["zustand"] for l in d["lampen"]], "frisch": bool(d["spanne"].get("frisch"))}


# ================================================================================================ Quellen lesen (nur lesend)

def _ro(pfad: str | None):
    if not pfad or not os.path.exists(pfad):
        return None
    try:
        return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    except sqlite3.Error:
        return None


def kurs_lesen(con, coin: str) -> dict:
    """Jüngster 1-min-Schluss aus den Minutenkerzen des Recorders."""
    if con is None:
        return {}
    try:
        r = con.execute("SELECT ts, close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
    except sqlite3.Error:
        return {}
    if not r or not r[1]:
        return {}
    return {"px": float(r[1]), "ts": int(r[0]) + 60, "quelle": "Hyperliquid (1-min-Kerze)"}


def schwankung_lesen(con, coin: str, jetzt: int) -> dict:
    """
    Aus volatil.db mit den Funktionen von hl_volatil (dieselben Regeln wie der Abschnitt „Volatilität“): erwartete Schwankung der
    ersten Woche (Prognose nur, wenn der Ursprung höchstens 3 Tage alt ist), realisierte 7/30 Tage, DVOL, Urteil V1, die Reihe der
    realisierten 7-Tage-Schwankung für das Perzentil. -> {} mit „fehlt“, wenn nichts da ist.
    """
    import hl_volatil as VL
    out = {"fehlt": [], "vi7_reihe": []}
    if coin not in VL.COINS:
        out["fehlt"].append(f"Für {coin} rechnet die Volatilität nicht (nur {', '.join(VL.COINS)}).")
        return out
    if con is None:
        out["fehlt"].append("volatil.db fehlt noch.")
        return out
    heute = int(jetzt) // TAG
    rows = con.execute("SELECT tag, vi7, vi30 FROM vl_tag WHERE coin=? AND tag BETWEEN ? AND ? ORDER BY tag",
                       (coin, heute - PERZ_TAGE - 40, heute)).fetchall()
    if not rows:
        out["fehlt"].append(f"Noch keine Tageswerte der Volatilität für {coin}.")
        return out
    bis = int(rows[-1][0])
    out["bis"] = bis
    out["vi7_reihe"] = [VL._runde(r[1]) for r in rows]
    out["real7"] = VL._runde(rows[-1][1]); out["real30"] = VL._runde(rows[-1][2])
    if heute - bis > FRISCH_SCHWANKUNG_TAGE:
        out["fehlt"].append(f"Tageswerte nur bis {_tag_datum(bis)}.")
    if coin in VL.DVOL_COINS:
        dv = VL._dvol_anzeige(con, coin, bis - 3, bis)
        if dv:
            out["dvol"] = VL._runde(dv[max(dv)])
    uz = VL.urteil_zeilen(con, True, VL.PRUEFUNGEN)
    u = {z["pruefung"]: z["urteil"] for z in uz}
    out["v1"] = u.get("V1")
    out["v1_p_holm"] = next((z.get("p_holm") for z in uz if z["pruefung"] == "V1"), None)
    modell = VL.anzeige_modell(coin, u)
    D, zeilen = VL.letzte_prognose(con, coin, modell)
    if not zeilen and modell == "M+":
        modell = "M"
        D, zeilen = VL.letzte_prognose(con, coin, modell)
    if zeilen and D is not None and D >= heute - FRISCH_SCHWANKUNG_TAGE:
        out["erwartet"] = VL._runde(VL.ann(zeilen[0][3])); out["ursprung"] = int(D)
        out["modell"] = modell; out["modell_text"] = VL.MODELL_TEXT.get(modell, modell)
    else:
        out["fehlt"].append("Keine frische Prognose der Schwankung" + (f" (letzte vom {_tag_datum(D)})" if D is not None else "") + ".")
    return out


def wochenende_faktor(con) -> float | None:
    """„Faktor 0,68“ aus der Datenprobe Wochenende der Volatilität (vl_meta pruefungen_vor_urteil)."""
    if con is None:
        return None
    import hl_volatil as VL
    try:
        liste = (VL.meta(con, "pruefungen_vor_urteil", {}) or {}).get("liste") or []
    except sqlite3.Error:
        return None
    for z in liste:
        if isinstance(z, (list, tuple)) and len(z) >= 3 and str(z[0]).startswith("Datenprobe Wochenende"):
            t = str(z[2]).replace("Faktor", "").strip().replace(",", ".")
            return _zahl(t)
    return None


def quellen_lesen(db: str, coin: str, jetzt: int | None = None, gemeinsam: dict | None = None, mit_ausblick_meldung: bool = True,
                  schmal: bool = False) -> dict:
    """Alle Quellen eines Coins lesen. Jede Quelle für sich: Scheitert eine, bleibt der Rest, der Grund steht in „fehlt“.
    gemeinsam: für alle Coins gleiche Teile (Termine, Ausnahmen, Wochenend-Faktor), damit der Streifen sie nur einmal liest.
    schmal: nur, was Lampen und 7-Tage-Spanne brauchen (für den Streifen) -- ohne Kostenschwelle und ohne den Tagesteil des Chartbilds."""
    import hl_ausblick as AU
    import hl_chartbild as CB
    jetzt = int(jetzt or time.time())
    Q = {"coin": coin, "jetzt": jetzt, "fehlt": [], "konten_schwelle": float(CB.KONTEN_SCHWELLE), "ausnahme_dauer": int(AU.AUSNAHME_S)}
    pk = CB.PRUEFSTAND.get("konten") or ("", "")
    Q["konten_beleg"] = f"{pk[1]} ({pk[0]}, Stand {CB.PRUEFSTAND_STAND})"
    G = gemeinsam if gemeinsam is not None else gemeinsam_lesen(db, jetzt)
    for k in ("termine", "naechste", "datentag_stand", "termine_geladen", "wochenende_faktor", "aktien_pruefung"):
        Q[k] = G.get(k)
    Q["fehlt"] += list(G.get("fehlt") or [])
    a = (G.get("ausnahmen") or {}).get(coin)
    if isinstance(a, dict):
        Q["ausnahme"] = a
        try:
            Q["ausnahme_text"] = AU.ausnahme_text(a)
        except Exception:
            Q["ausnahme_text"] = ""
    con = _ro(db)
    try:
        Q["kurs"] = kurs_lesen(con, coin)
        try:
            if coin in CB.HB.COINS:
                Q["lage"] = {k: ({kk: vv for kk, vv in v.items() if kk != "verlauf"} if isinstance(v, dict) else v)
                             for k, v in CB.positionierung(coin, db, con, jetzt).items()}
            else:
                Q["lage"] = {"fehlt": [f"Für {coin} gibt es keine Binance-Positionierung."]}
        except Exception as e:
            Q["lage"] = {"fehlt": [f"Positionierung: {type(e).__name__}"]}
        if not schmal:
            try:
                import hl_fusion
                Q["kosten"] = hl_fusion.kostenschwelle(con, coin, jetzt) if con is not None else None
            except Exception as e:
                Q["fehlt"].append(f"Kostenschwelle: {type(e).__name__}: {e}"[:160])
    finally:
        if con is not None:
            con.close()
    try:
        if mit_ausblick_meldung:
            NL = AU.nutzlast(db, coin, None)                             # meldet dem Takt „Abschnitt offen“ (wie der Abschnitt Ausblick)
            Q["ausblick"] = {"prognose": NL.get("prognose"), "rueckblick": NL.get("rueckblick"), "fehlt": list(NL.get("fehlt") or [])}
        else:
            Q["ausblick"] = {"prognose": _prognose_lesen(db, coin), "rueckblick": G.get("rueckblick"), "fehlt": []}
    except Exception as e:
        Q["ausblick"] = {"fehlt": [f"Ausblick: {type(e).__name__}: {e}"[:160]]}
    try:
        import hl_volatil as VL
        vc = VL.lesen(VL.pfad(db))
        try:
            Q["vol"] = schwankung_lesen(vc, coin, jetzt)
        finally:
            if vc is not None:
                vc.close()
    except Exception as e:
        Q["vol"] = {"fehlt": [f"Volatilität: {type(e).__name__}: {e}"[:160]], "vi7_reihe": []}
    try:
        if coin in CB.COINS and not schmal:
            E = CB._memo((db, coin, jetzt // TAG), lambda: CB.tagesteil(db, coin, jetzt))
            f = E.get("funding")
            Q["funding"] = {k: v for k, v in f.items() if _zahl(v) is not None} if isinstance(f, dict) else None
    except Exception:
        Q["funding"] = None
    return Q


def _prognose_lesen(db: str, coin: str) -> dict | None:
    """Jüngste Rechnung des Ausblicks für einen Coin, ohne dem Takt „Abschnitt offen“ zu melden (für den Streifen)."""
    import hl_ausblick as AU
    con = AU.lesen(AU.ausblick_pfad(db))
    if con is None:
        return None
    try:
        r = con.execute("SELECT json FROM au_prognose WHERE coin=? ORDER BY anker DESC, erzeugt DESC LIMIT 1", (coin,)).fetchone()
        return json.loads(r[0]) if r else None
    except (sqlite3.Error, ValueError):
        return None
    finally:
        con.close()


def gemeinsam_lesen(db: str, jetzt: int) -> dict:
    """Für alle Coins gleiche Quellen: Termine und Stand der Datentage (makro.db), Ausnahmen, Rückblick und Basis der Schockprüfung
    (ausblick.db), Kerzen des S&P-500-Perp (aktien.db; nur für die Frage, ob die Aktien-Regel geprüft wird), Wochenend-Faktor
    (volatil.db)."""
    G = {"fehlt": [], "termine": [], "naechste": {}, "datentag_stand": None, "termine_geladen": False, "ausnahmen": {},
         "wochenende_faktor": None, "rueckblick": None, "aktien_pruefung": None}
    try:
        import hl_makro as MK
        mp = MK.makro_pfad(db)
        d = MK.datentag_info(mp, jetzt)
        G["termine"] = d.get("termine") or []; G["datentag_stand"] = d.get("stand")
        mc = MK.lesen(mp)
        if mc is not None:
            try:
                u = MK.usa_termine(mc, jetzt)
                G["naechste"] = u.get("naechste") or {}; G["termine_geladen"] = bool(u.get("n"))
            finally:
                mc.close()
    except Exception as e:
        G["fehlt"].append(f"Termine: {type(e).__name__}: {e}"[:160])
    try:
        import hl_ausblick as AU
        ac = AU.lesen(AU.ausblick_pfad(db))
        if ac is not None:
            try:
                G["ausnahmen"] = AU._json_meta(ac, "ausnahme", {}) or {}
                R = AU.rueckblick_lesen(ac)
                if R:
                    G["rueckblick"] = {k: R.get(k) for k in ("stand", "s1", "s3", "s4")}
                basis = AU._json_meta(ac, "schock_basis", {}) or {}
                fs1 = basis.get("FS1"); basis_coins = list((basis.get("coins") or {}).keys())
                rechnung = _zahl(AU.meta(ac, "letzte_prognose", "0"))
            finally:
                ac.close()
            # Wird die Aktien-Regel (c) gerade geprüft? Dieselbe Reihe und dieselben Bedingungen wie hl_ausblick.schock_pruefen
            import hl_aktien as AK
            kn, kts = 0, None
            ak = AK.lesen(AK.aktien_pfad(db))
            if ak is not None:
                try:
                    K = AK.kerzen(ak, AKTIEN_REIHE, ab=jetzt - 8 * 3600)
                finally:
                    ak.close()
                if K is not None and len(K["ts"]):
                    kn, kts = int(len(K["ts"])), int(K["ts"][-1])
            G["aktien_pruefung"] = aktien_pruefung(fs1, kn, kts, rechnung, jetzt, basis_coins)
        else:
            G["aktien_pruefung"] = {"ok": False, "grund": "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt).", "kerze_ts": None,
                                    "rechnung_ts": None, "coins": []}
    except Exception as e:
        G["fehlt"].append(f"Ausblick (Ausnahmen): {type(e).__name__}: {e}"[:160])
    try:
        import hl_volatil as VL
        vc = VL.lesen(VL.pfad(db))
        if vc is not None:
            try:
                G["wochenende_faktor"] = wochenende_faktor(vc)
            finally:
                vc.close()
    except Exception:
        pass
    return G


def nutzlast(db: str, coin: str = "BTC", jetzt: int | None = None) -> dict:
    """Antwort für /cockpit: das volle Cockpit des gewählten Coins und der Streifen mit allen sechs."""
    jetzt = int(jetzt or time.time())
    coin = (coin or "BTC").upper()[:12]
    if coin not in COINS:
        return {"ok": False, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL, "fehlt": [f"{coin}: kein Cockpit (nur {', '.join(COINS)})"]}
    t0 = time.time()
    G = gemeinsam_lesen(db, jetzt)
    out = bauen(quellen_lesen(db, coin, jetzt, G, mit_ausblick_meldung=True))
    streifen = []
    for c in COINS:
        try:
            if c == coin:
                e = (out["spanne"]["h"] or {}).get("7"); p0 = out["spanne"].get("p0")
                streifen.append({"coin": c, "lo": (e["q"][1] / p0 - 1.0) if e and p0 else None, "hi": (e["q"][5] / p0 - 1.0) if e and p0 else None,
                                 "lampen": [l["zustand"] for l in out["lampen"]], "frisch": bool(out["spanne"].get("frisch"))})
            else:
                streifen.append(kern(c, quellen_lesen(db, c, jetzt, G, mit_ausblick_meldung=False, schmal=True)))
        except Exception as e:                                           # ein Coin darf den Streifen nicht verhindern
            streifen.append({"coin": c, "lo": None, "hi": None, "lampen": [], "frisch": False, "fehler": f"{type(e).__name__}"})
    out["streifen"] = streifen
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return _ohne_nan(out)


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, dict):
        return {str(k): _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_ohne_nan(v) for v in x]
    try:
        import numpy as np
        if isinstance(x, np.generic):
            return _ohne_nan(x.item())
        if isinstance(x, np.ndarray):
            return [_ohne_nan(v) for v in x.tolist()]
    except ImportError:
        pass
    return x


def payload_json(db: str, coin: str = "BTC", jetzt: int | None = None) -> bytes:
    """/cockpit?coin=…: immer eine Antwort mit Grund, nie eine leere Seite."""
    try:
        return json.dumps(nutzlast(db, coin, jetzt), ensure_ascii=False, allow_nan=False).encode()
    except Exception as e:
        return json.dumps({"ok": False, "coin": coin, "version": VERSION_MODUL, "fehlt": [f"Cockpit: {type(e).__name__}: {e}"[:300]]},
                          ensure_ascii=False).encode()


# ================================================================================================ Seite ordnen (Cockpit oben, Werkstatt, Betrieb)

# Reihenfolge der Abschnitte der Hauptseite (Entscheidungen des Nutzers vom 12.11.2026): oben das Cockpit, darunter die bisherigen
# Abschnitte; was keinen bestandenen Test hat, steht in der eingeklappten Gruppe „Werkstatt“; Netzwerk, Aktualisierung, Debug und
# System bilden die Gruppe „Betrieb“. Ein Abschnitt steigt auf, indem sein Schlüssel von SEITE_WERKSTATT nach SEITE_HAUPT wandert --
# erst nach einem bestandenen, vorab festgelegten Test (KONZEPT_Cockpit.md 8). Der Text der Abschnitte in hl_viz bleibt unberührt.
SEITE_HAUPT = ("chart", "chartbild", "ausblick", "volatil", "notbremse", "makro", "prognosemarkt", "orders", "heat", "depth")
SEITE_WERKSTATT = ("signal", "forecast", "familien", "labor", "whales", "leaderboard", "lbact", "lbact48", "pool")
SEITE_BETRIEB = ("network", "update", "debug", "system")
SEITE_NAMEN = {"network": "Netzwerk", "cockpit": "Cockpit"}
_PANEL = '<div class="panel" id="sec-'
_ENDE = '<div id="taskbar"'
_KPI = '<div class="kpi" id="kpi"></div>\n'

COCKPIT_PANEL = """<div class="panel" id="sec-cockpit" data-sec="cockpit">
 <h2 class="sech" onclick="toggleSec('cockpit')"><span class="num">CK</span><span class="ttl">Cockpit — Spanne, Risiko, Levels</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Das Cockpit zeigt nur, was einen vorab festgelegten Test bestanden hat (farbige Lampen) oder
  sauber gemessen ist (blau, ohne Wertung). Jede Anzeige nennt ihren Beleg und ihren Stand; ist eine Quelle zu alt, wird die Anzeige
  blass und sagt das. Formen der Lampen: Ring = aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert. Die Richtung
  des Kurses ist für kein Zeitfenster belegt -- deshalb gibt es hier keinen Pfeil. Spanne und Levels stammen aus dem Abschnitt
  „Ausblick“, die Schwankung aus „Volatilität“, die Kontenquote aus „Chartbild“, die Kosten aus der Kostenschwelle der Fusion; das
  Cockpit rechnet nichts Neues. Ein Streifen mit allen sechs Coins schaltet den Coin der ganzen Seite um. Was keinen bestandenen
  Test hat, steht weiter unten in der „Werkstatt“.</div>
 <div id="ckbody"><div class="sub">lädt …</div></div>
 </div>
</div>

"""
WERKSTATT_TEXT = ("Hier steht, was keinen bestandenen Test hat oder noch geprüft wird: die Prognose der Richtung mit ihren Preisen, die "
                  "Konfluenz, Wale und Bestenlisten als Richtungsanzeiger, das TradeLabor (sein Kostenmodell wird gerade gegen die Börse "
                  "gemessen) und die bisherige Kennzahlenleiste. Alles arbeitet unverändert weiter -- es steht nur nicht mehr in der "
                  "Hauptansicht. Ein Abschnitt kommt nach oben, sobald er einen vorab festgelegten Test besteht.")
BETRIEB_TEXT = "Netzwerk, Aktualisierung, Debug und System mit Backup und Speicherorten."
GRUPPEN_CSS = """<style id="grp_css">
 .gruppe{margin-top:30px;border-top:1px solid #30363d;padding-top:12px}
 h2.grph{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin:0;min-height:44px}
 h2.grph .ttl{flex:1} h2.grph .grpz{font-size:11px;font-weight:400;color:#8b949e} h2.grph .chev{color:#8b949e;font-size:12px;transition:transform .15s;flex:none}
 .gruppe.zu .grpbody{display:none} .gruppe.zu h2.grph .chev{transform:rotate(-90deg)}
 .gruppe .grptext{margin:6px 0 0;max-width:900px}
 .gruppe{scroll-margin-top:96px} .nav a.grp{border-style:dashed}
 @media (max-width:700px){ .gruppe{scroll-margin-top:120px} }
</style>
"""
# Einmalig beim ersten Laden nach dem Umbau: bisherige Abschnitte eingeklappt, Cockpit offen, beide Gruppen zu. Muss VOR applySec() laufen.
ERSTLAUF_JS = """<script>
// 23.98 (U245 Stufe C1): einmal je Browser -- das Cockpit steht oben, alles Bisherige eingeklappt darunter (Entscheidung des Nutzers 12.11.2026)
try{ if(!localStorage.getItem('hl_cockpit_v1')){ var st_={}; %s.forEach(function(k){ st_[k]=true; }); st_.cockpit=false;
 localStorage.setItem('hl_sec', JSON.stringify(st_)); localStorage.setItem('hl_grp', JSON.stringify({werkstatt:true, betrieb:true}));
 localStorage.setItem('hl_cockpit_v1', String(Date.now())); } }catch(e){}
</script>
"""
GRUPPEN_JS = """<script>
// 23.98 (U245 Stufe C1): Gruppen „Werkstatt“ und „Betrieb“ ein- und ausklappen, Zustand im Browser gemerkt (hl_grp: true = zu).
function grpZustand(){ try{ return JSON.parse(localStorage.getItem('hl_grp')||'{}'); }catch(e){ return {}; } }
function grpAnwenden(){ const st=grpZustand(); document.querySelectorAll('.gruppe[data-grp]').forEach(g=>g.classList.toggle('zu', st[g.dataset.grp]!==false)); }
function grpNeuZeichnen(g){ setTimeout(()=>{ try{ if(typeof load==='function') load(); }catch(e){}
  const lab=g.querySelector('#sec-labor'); if(lab&&!lab.classList.contains('closed')&&typeof laborLaden==='function'){ try{ laborLaden(true); }catch(e){} } }, 60); }
function grpSchalten(k, auf){ const g=document.getElementById('grp-'+k); if(!g) return;
 const zu=auf===true?false:!g.classList.contains('zu'); g.classList.toggle('zu', zu);
 const st=grpZustand(); st[k]=zu; try{ localStorage.setItem('hl_grp', JSON.stringify(st)); }catch(e){}
 if(!zu) grpNeuZeichnen(g); }
function grpOeffneFuer(id){ const el=document.getElementById(id); if(!el) return; const g=el.closest('.gruppe'); if(g&&g.classList.contains('zu')) grpSchalten(g.dataset.grp, true); }
// Ein Link auf einen Abschnitt klappt ihn auch auf (seit dem Umbau sind die bisherigen Abschnitte zunächst eingeklappt)
function grpAbschnittAuf(id){ const p=document.getElementById(id); if(!p||!p.classList.contains('panel')||!p.classList.contains('closed')||!p.dataset.sec||typeof toggleSec!=='function') return;
 toggleSec(p.dataset.sec); if(p.dataset.sec==='cockpit'&&typeof ckLaden==='function') setTimeout(()=>ckLaden(true),80); }
document.addEventListener('click', e=>{ const a=e.target&&e.target.closest?e.target.closest('a[href^="#sec-"],a[href^="#grp-"]'):null; if(!a) return;
 const id=a.getAttribute('href').slice(1); if(id.indexOf('grp-')===0) grpSchalten(id.slice(4), true); else { grpOeffneFuer(id); grpAbschnittAuf(id); } }, true);
grpAnwenden();
if(location.hash&&location.hash.length>1) grpOeffneFuer(location.hash.slice(1));
</script>
"""


def _gruppe(key: str, titel: str, text_: str, inhalt: str, n: int) -> str:
    return (f'<div class="gruppe zu" id="grp-{key}" data-grp="{key}">\n'
            f' <h2 class="grph" onclick="grpSchalten(\'{key}\')"><span class="ttl">{titel}</span>'
            f'<span class="grpz">{n} Abschnitte</span><span class="chev">▾</span></h2>\n'
            f' <div class="grpbody">\n <div class="sub grptext">{text_}</div>\n{inhalt}</div>\n</div>\n\n')


def seite_ordnen(html: str) -> str:
    """
    Die Hauptseite neu ordnen: Cockpit oben, bisherige Abschnitte darunter, Gruppen „Werkstatt“ (mit der Kennzahlenleiste) und
    „Betrieb“; neue Navigationsleiste; Skript /cockpit.js. Arbeitet auf dem fertigen Seitentext von hl_viz und ändert keinen Abschnitt.
    Zweimal angewendet = einmal angewendet. Jede Abweichung vom erwarteten Aufbau ist ein ValueError (hl_viz liefert dann die
    ungeordnete Seite aus und meldet es).
    """
    import re
    if 'id="sec-cockpit"' in html:
        return html
    for marke, n in ((_KPI, 1), (_ENDE, 1), ("</head>", 1), ("<body>", 1), ("</body></html>", 1)):
        if html.count(marke) != n:
            raise ValueError(f"Seite: Marke {marke.strip()[:30]!r} {html.count(marke)}-mal statt {n}-mal")
    i0 = html.find(_PANEL); i1 = html.find(_ENDE)
    if i0 < 0 or i1 < i0 or html.find(_KPI) > i0:
        raise ValueError("Seite: Abschnitte oder Kennzahlenleiste nicht an der erwarteten Stelle")
    kopf, region, rest = html[:i0], html[i0:i1], html[i1:]
    starts = [m.start() for m in re.finditer(re.escape(_PANEL), region)] + [len(region)]
    bloecke: dict = {}
    for a, b in zip(starts, starts[1:]):
        blk = region[a:b]
        key = re.match(re.escape(_PANEL) + r'(\w+)" data-sec="(\w+)"', blk)
        if not key or key.group(1) != key.group(2):
            raise ValueError(f"Seite: Abschnitt ohne Schlüssel bei Zeichen {i0 + a}")
        if key.group(1) in bloecke:
            raise ValueError(f"Seite: Abschnitt {key.group(1)} doppelt")
        if len(re.findall(r"<div\b", blk)) != blk.count("</div>"):
            raise ValueError(f"Seite: Abschnitt {key.group(1)} ist nicht in sich geschlossen (div)")
        bloecke[key.group(1)] = blk
    bekannt = set(SEITE_HAUPT) | set(SEITE_WERKSTATT) | set(SEITE_BETRIEB)
    haupt = [k for k in SEITE_HAUPT if k in bloecke] + [k for k in bloecke if k not in bekannt]       # Unbekanntes bleibt sichtbar
    werk = [k for k in SEITE_WERKSTATT if k in bloecke]; betr = [k for k in SEITE_BETRIEB if k in bloecke]
    # Navigationsleiste: Namen aus der bisherigen Leiste
    nav = re.search(r'<nav class="nav">.*?</nav>', kopf, re.S)
    if not nav:
        raise ValueError("Seite: Navigationsleiste fehlt")
    namen = dict(SEITE_NAMEN)
    for m in re.finditer(r'<a href="#sec-(\w+)"[^>]*>(.*?)</a>', nav.group(0)):
        namen[m.group(1)] = m.group(2)
    link = lambda k, kl="": f'<a href="#sec-{k}"{kl}>{namen.get(k, k)}</a>'
    nav_neu = ('<nav class="nav">\n  ' + link("cockpit") + "".join(link(k) for k in haupt)
               + '\n  <a href="#grp-werkstatt" class="dim grp" title="Abschnitte ohne bestandenen Test">Werkstatt</a>' + "".join(link(k, ' class="dim"') for k in werk)
               + '\n  <a href="#grp-betrieb" class="dim grp" title="Netzwerk, Aktualisierung, Debug, System">Betrieb</a>' + "".join(link(k, ' class="dim"') for k in betr)
               + '\n  <a class="dim" onclick="toggleAll()" style="margin-left:auto" title="alle Abschnitte ein- oder ausklappen">alle ▾/▸</a>\n </nav>')
    kopf = kopf.replace(nav.group(0), nav_neu).replace(_KPI, "")
    einleitung = re.search(r'<div class="sub" style="margin:8px 0 0">Echte Positionen.*?</div>\n', kopf, re.S)   # der Hinweis zur Seite: unter das Cockpit
    if einleitung and "<div" not in einleitung.group(0)[5:]:
        kopf = kopf.replace(einleitung.group(0), "")
    else:
        einleitung = None
    kopf = kopf.replace("</head>", GRUPPEN_CSS + "</head>").replace("<body>", "<body>\n" + ERSTLAUF_JS % json.dumps(sorted(bloecke)))
    mitte = (COCKPIT_PANEL + (einleitung.group(0) + "\n" if einleitung else "") + "".join(bloecke[k] for k in haupt)
             + _gruppe("werkstatt", "Werkstatt · nicht belegt", WERKSTATT_TEXT, _KPI + "".join(bloecke[k] for k in werk), len(werk))
             + _gruppe("betrieb", "Betrieb", BETRIEB_TEXT, "".join(bloecke[k] for k in betr), len(betr)))
    rest = rest.replace("</body></html>", GRUPPEN_JS + '<script src="/cockpit.js"></script></body></html>')
    return kopf + mitte + rest


# ================================================================================================ Text (Debug-Lauf)

def text(db: str, coins=COINS, jetzt: int | None = None) -> str:
    """Das Cockpit als Text: je Coin dieselben Zahlen wie auf der Seite, mit Stand und Beleg."""
    jetzt = int(jetzt or time.time())
    Z = []; a = Z.append
    a(f"★ Cockpit (U245) · Modul {VERSION_MODUL} · {_datum(jetzt)} · Spanne, Risiko und Wahrscheinlichkeiten, keine Richtung")
    a("Lampen: aus · Hinweis · Warnung · grau (kein Wert). Schwellen: Kontenquote ≥ 3; Termin 24 h davor bis 2 h danach; Schwankung ab "
      f"dem {int(SCHWANKUNG_GELB * 100)}. Perzentil Hinweis, ab dem {int(SCHWANKUNG_ROT * 100)}. Warnung; Aktien = Ausnahmelage (c) des Ausblicks. "
      "Ohne frische Quelle oder ohne laufende Prüfung ist eine Lampe grau, nicht aus.")
    G = gemeinsam_lesen(db, jetzt)
    belege: list = []
    for c in coins:
        try:
            d = _ohne_nan(bauen(quellen_lesen(db, c, jetzt, G, mit_ausblick_meldung=False)))
        except Exception as e:
            a(""); a(f"== {c}: {type(e).__name__}: {e}"); continue
        if not belege:
            belege = list(dict.fromkeys(l["beleg"] for l in d["lampen"]))
        k = d["kopf"]
        a("")
        a(f"== {c} · Kurs {_px(k['kurs'])} ({'frisch' if k['frisch'] else 'nicht frisch'}, Stand {_datum(k['kurs_ts'])})")
        a(f"   {d['satz']['text']} {d['satz']['zusatz']}")
        if d["satz"].get("ausnahme"):
            a(f"   {d['satz']['ausnahme']}")
        for l in d["lampen"]:
            a(f"   Lampe {l['name']:<11} {l['zustand']:<8} {l['wert']} -- {l['detail']}")
        s = d["schwankung"]
        a(f"   Schwankung: erwartet 7 T {_de(s['erwartet'])} % p. a. ({s.get('modell') or 'keine Prognose'}), realisiert 7 T {_de(s['real7'])} · "
          f"30 T {_de(s['real30'])} · DVOL {_de(s['dvol'])} · Perzentil {('—' if s['pz'] is None else _de(s['pz'] * 100, 0) + '.')} "
          f"({s.get('pz_von') or '—'}) · in 4 h typisch ± {_pc(s['er4'], 2)}" + (f" · {s['stand_text']}" if s.get("stand_text") else "")
          + ("" if s.get("frisch") or s.get("stand_tag") is None else " -- NICHT FRISCH"))
        sp = d["spanne"]
        for h in ("7", "14", "28"):
            e = (sp["h"] or {}).get(h)
            if e:
                q = e["q"]
                a(f"   Spanne {h:>2} T: 90 % {_px(q[0])}–{_px(q[6])} · 80 % {_px(q[1])}–{_px(q[5])} · 50 % {_px(q[2])}–{_px(q[4])} · {e['vermerk']}")
        a(f"   Stand der Spanne: Anker {_datum(sp.get('anker'))}, Kurs am Anker {_px(sp.get('p0'))}" + ("" if sp.get("frisch") else " -- NICHT FRISCH"))
        lv = d["levels"]
        for seite, liste in (("oben", lv["oben"]), ("unten", lv["unten"])):
            for n in liste:
                a(f"   Level {seite:<5} {n['name'][:40]:<40} {_px(n['px']):>10} {_pc(n['abstand'], 1, True):>8}  1 W {_de(n['p7'] * 100, 0)} % · "
                  f"2 W {_de(n['p14'] * 100, 0)} %" + ("  (Momentaufnahme)" if n["momentaufnahme"] else ""))
        if lv.get("durchlaufen"):
            a(f"   {lv['durchlaufen']} Niveau(s) seit dem Anker durchlaufen -- nicht mehr gezeigt")
        for m in d["messwerte"]:
            stand_m = _datum(m["stand"]) if m.get("stand") else (f"Tagesstand {m['stand_tag']}" if m.get("stand_tag") else "ohne Stand")
            a(f"   Messwert {m['name']:<34} {m['text'] or '—':<16} Perzentil {('—' if m['pz'] is None else _de(m['pz'] * 100, 0) + '.')} "
              + ("(kein Wert)" if m.get("wert") is None else f"({m['art'] or '—'}; {stand_m})"))
        for z in d["kosten"]["zeilen"]:
            a(f"   Kosten {z['h']:>2} h: mittlere Bewegung {_pc(z['er'], 2)} -> nötige Trefferquote Taker {_pc(z['taker'], 1)} · Maker {_pc(z['maker'], 1)}")
        if d["kosten"]["zeilen"]:
            a(f"   Stand der Kosten: {_datum(d['kosten'].get('stand'))}, mittlere Bewegung der letzten {d['kosten'].get('tage') or '—'} Tage")
        for f in list(dict.fromkeys((d.get("fehlt") or []) + sp["fehlt"] + s["fehlt"] + lv["fehlt"] + d["kosten"]["fehlt"])):
            a(f"   fehlt: {f}")
    a("")
    a("Belege: " + (" | ".join(belege) if belege else "—"))
    ap = G.get("aktien_pruefung") or {}
    a("Aktien-Regel des Ausblicks: " + ("wird geprüft" if ap.get("ok") else "wird NICHT geprüft -- " + (ap.get("grund") or "Grund unbekannt"))
      + f" (letzte Kerze des S&P-500-Perp {_datum(ap.get('kerze_ts'))}, letzte Rechnung des Ausblicks {_datum(ap.get('rechnung_ts'))})")
    return "\n".join(Z)


# ================================================================================================ Selbsttest

def _probe_quellen(jetzt: int, coin: str = "BTC") -> dict:
    """Quellen von Hand, in der Form der echten Module (hl_ausblick.nutzlast, hl_chartbild.positionierung, hl_fusion.kostenschwelle)."""
    p0 = 60_000.0
    q7 = [p0 * f for f in (0.88, 0.90, 0.95, 1.00, 1.05, 1.10, 1.13)]
    sp = {"7": {"q": q7, "pct": [x / p0 - 1 for x in q7]},
          "14": {"q": [p0 * f for f in (0.84, 0.87, 0.93, 1.00, 1.07, 1.14, 1.18)]},
          "28": {"q": [p0 * f for f in (0.78, 0.82, 0.90, 1.00, 1.11, 1.22, 1.28)]}}
    niveaus = [{"name": "runde Zahl (5.000er-Schritt)", "px": 65_000.0, "art": "rund", "momentaufnahme": False,
                "p": {"7": [0.52, 0.27], "14": [0.66, 0.33], "28": [0.76, 0.34]}},
               {"name": "Swing-Hoch", "px": 61_000.0, "art": "swing", "momentaufnahme": False, "p": {"7": [0.90, 0.5], "14": [0.94, 0.5], "28": [0.97, 0.5]}},
               {"name": "Buy-Stops", "px": 60_500.0, "art": "orders", "momentaufnahme": True, "p": {"7": [0.95, 0.5], "14": [0.97, 0.5], "28": [0.99, 0.5]}},
               {"name": "Bein 10 %", "px": 68_000.0, "art": "bein", "momentaufnahme": False, "p": {"7": [0.21, 0.1], "14": [0.39, 0.2], "28": [0.52, 0.2]}},
               {"name": "weit oben", "px": 72_000.0, "art": "rund", "momentaufnahme": False, "p": {"7": [0.05, 0.02], "14": [0.12, 0.05], "28": [0.25, 0.1]}},
               {"name": "200-Tage-Linie", "px": 58_000.0, "art": "ma", "momentaufnahme": False, "p": {"7": [0.61, 0.3], "14": [0.72, 0.4], "28": [0.80, 0.4]}},
               {"name": "Sell-Stops", "px": 59_500.0, "art": "orders", "momentaufnahme": True, "p": {"7": [0.93, 0.5], "14": [0.96, 0.5], "28": [0.98, 0.5]}},
               {"name": "ohne Wahrscheinlichkeit", "px": 59_000.0, "art": "x", "p": None}]
    R = {"stand": jetzt - 3 * TAG,
         "s1": {"h": {"7": {"gewinn_rel": 0.015, "p": 0.002, "besteht": True, "deckung": {coin: {"d80": 0.84, "se": 0.028}}},
                      "14": {"gewinn_rel": 0.004, "p": 0.181, "besteht": False, "deckung": {coin: {"d80": 0.82, "se": 0.03}}},
                      "28": {"gewinn_rel": -0.007, "p": 0.804, "besteht": False, "deckung": {coin: {"d80": 0.79, "se": 0.04}}}}},
         "s3": {"h": {"7": {"n": 15412, "skill": 0.062, "steigung": 0.96, "besteht": True}}},
         "s4": {"besteht": True, "variogramm": {"p": 0.003}}}
    vi7 = [30.0 + (i * 37 % 100) * 0.4 for i in range(PERZ_TAGE + 30)]            # 30,0 … 69,6, alle Werte mehrfach
    return {"coin": coin, "jetzt": jetzt, "fehlt": [], "konten_schwelle": 3.0, "konten_beleg": "Konten ≥ 3: belegt (Probe).",
            "ausnahme_dauer": TAG, "kurs": {"px": 60_200.0, "ts": jetzt - 30, "quelle": "Probe"},
            "ausblick": {"prognose": {"coin": coin, "anker": jetzt - 1800, "p0": p0, "spannen": sp, "niveaus": niveaus}, "rueckblick": R, "fehlt": []},
            "vol": {"erwartet": 45.7, "real7": 44.0, "real30": 36.0, "dvol": 39.5, "v1": "belegt", "v1_p_holm": 0.0292, "bis": jetzt // TAG - 1,
                    "ursprung": jetzt // TAG - 1, "modell_text": "M (log-HAR)", "vi7_reihe": vi7, "fehlt": []},
            "kosten": {"ts": jetzt - 600, "tage": 30, "taker": 0.00045, "maker": 0.00015, "halbspread_bps": 0.1, "er_4": 0.0051, "er_24": 0.0131,
                       "p_taker_4": 0.589, "p_maker_4": 0.529, "p_taker_24": 0.535, "p_maker_24": 0.511},
            "termine": [], "naechste": {"Verbraucherpreise": jetzt + 20 * TAG, "Arbeitsmarktbericht": jetzt + 9 * TAG, "Erstanträge": jetzt + TAG},
            "datentag_stand": {"erzeugt": jetzt - 5 * TAG, "von": "2020-01-01", "H1": {"belegt": True, "abs_verh": 2.45}, "H2": {"belegt": True, "abs_verh": 1.9}},
            "termine_geladen": True, "wochenende_faktor": 0.68,
            "aktien_pruefung": aktien_pruefung(0.0001, 16, jetzt - 1500, jetzt - 1900, jetzt),
            "lage": {"fehlt": [], "oi": {"wert": 109_231.0, "ts": jetzt - 300, "art": "live", "pz": 0.52},
                     "konten": {"wert": 1.57, "ts": jetzt - 300, "art": "live", "pz": 0.22}},
            "funding": {"rate": 0.00022, "rate_ts": jetzt - 3600, "z": 0.69, "tag": jetzt // TAG - 1}}


def selbsttest(verbose: bool = True) -> bool:
    import copy
    pruef = []

    def ok(name, bed, wert=""):
        pruef.append((name, bool(bed), str(wert)))

    # Mittwoch 11.11.2026 12:00 UTC als fester Zeitpunkt (kein Wochenende, kein Termin)
    import calendar
    jetzt = calendar.timegm((2026, 11, 11, 12, 0, 0))
    Q = _probe_quellen(jetzt)
    d = bauen(copy.deepcopy(Q))
    L = {l["key"]: l for l in d["lampen"]}

    # ---- 1) Abgleich: jede Zahl gleich der Quelle
    sp = d["spanne"]; P = Q["ausblick"]["prognose"]
    ok("Abgleich Spanne: Quantile 7/14/28 Tage gleich der Rechnung des Ausblicks, Trefferquote gleich dem Rückblick",
       all(sp["h"][h]["q"] == P["spannen"][h]["q"] for h in ("7", "14", "28")) and sp["h"]["7"]["treffer"] == 0.84 and sp["p0"] == P["p0"]
       and sp["anker"] == P["anker"] and sp["kurs"] == 60_200.0,
       f"7 T 80 %: {_px(sp['h']['7']['q'][1])}–{_px(sp['h']['7']['q'][5])}, traf {sp['h']['7']['treffer']}")
    ok("Vermerk je Horizont: 7 Tage „traf 84 %“, 14 Tage „Vorsprung offen“, 28 Tage „nur Rahmen“ (wie die Urteile des Rückblicks)",
       sp["h"]["7"]["vermerk"] == "traf 84 %" and sp["h"]["14"]["vermerk"] == "Vorsprung offen" and sp["h"]["28"]["vermerk"] == "nur Rahmen",
       " · ".join(sp["h"][h]["vermerk"] for h in ("7", "14", "28")))
    ok("Kernsatz aus der 80-%-Spanne der 7 Tage, mit dem Satz „Richtung nicht belegt“",
       d["satz"]["text"] == "In 7 Tagen liegt BTC mit 80 % zwischen 54.000 und 66.000." and d["satz"]["zusatz"] == SATZ_RICHTUNG
       and d["satz"]["ausnahme"] is None, d["satz"]["text"])
    s = d["schwankung"]
    pz_hand = (sum(1 for a in Q["vol"]["vi7_reihe"][-PERZ_TAGE:] if a < 45.7) + 0.5 * sum(1 for a in Q["vol"]["vi7_reihe"][-PERZ_TAGE:] if a == 45.7)) / PERZ_TAGE
    ok("Abgleich Schwankung: erwartet, realisiert 7/30 Tage, DVOL und 4-h-Bewegung gleich den Quellen; Perzentil von Hand (Mittelrang, 365 Tage)",
       s["erwartet"] == 45.7 and s["real7"] == 44.0 and s["real30"] == 36.0 and s["dvol"] == 39.5 and s["er4"] == 0.0051
       and abs(s["pz"] - pz_hand) < 1e-12 and s["pz_von"].startswith("Erwartete"), f"Perzentil {s['pz']:.4f} (von Hand {pz_hand:.4f})")
    w90 = [float(i) for i in range(1, 91)]
    try:
        import hl_chartbild as CB_
        import random as _rnd
        rz = _rnd.Random(5); reihe_z = [round(rz.random() * 50, 1) for _ in range(200)]
        gleich_cb = all(abs(perzentil(x_, reihe_z) - float(CB_.perzentil(x_, __import__("numpy").array(reihe_z)))) < 1e-12 for x_ in (0.0, 12.5, reihe_z[7], reihe_z[99], 60.0))
    except ImportError:
        gleich_cb = True
    ok("Perzentil: Mittelrang (45 unter 1…90 -> 0,4944; gleiche Werte halb gezählt), unter 60 Werten oder bei lauter gleichen kein Wert; "
       "dieselbe Regel wie hl_chartbild.perzentil",
       abs(perzentil(45.0, w90) - 44.5 / 90) < 1e-12 and perzentil(45.0, w90[:59]) is None and perzentil(1.0, [1.0] * 90) is None
       and perzentil(None, w90) is None and gleich_cb, f"{perzentil(45.0, w90):.4f}; gleich dem Chartbild: {gleich_cb}")
    ok("Beleg der Spanne nennt Gewinn, p und Trefferquote des Coins aus dem Rückblick; ein p unter 0,001 steht als „< 0,001“",
       "Gewinn +1,5 %, p 0,002" in sp["beleg"] and "traf bei BTC 84 %" in sp["beleg"] and _p(0.0004) == "< 0,001" and _p(0.0292) == "0,029" and _p(None) == "—",
       sp["beleg"][:160])
    k = d["kosten"]
    ok("Abgleich Kosten: nötige Trefferquote 4 h und 24 h, Taker und Maker, gleich der Kostenschwelle der Fusion",
       [(z["h"], z["taker"], z["maker"], z["er"]) for z in k["zeilen"]] == [(4, 0.589, 0.529, 0.0051), (24, 0.535, 0.511, 0.0131)]
       and k["taker"] == 0.00045 and k["maker"] == 0.00015, str(k["zeilen"]))
    m = {x["key"]: x for x in d["messwerte"]}
    ok("Abgleich Messwerte: Open Interest und Kontenquote mit dem Perzentil der Positionierung, Funding-Druck als z-Wert, Marke bei 3",
       m["oi"]["pz"] == 0.52 and m["konten"]["wert"] == 1.57 and m["konten"]["pz"] == 0.22 and m["konten"]["marke"] == 3.0
       and m["funding"]["wert"] == 0.69 and m["funding"]["pz"] is None, f"Konten {m['konten']['text']}, Funding {m['funding']['text']}")
    q_tag = copy.deepcopy(Q); q_tag["lage"]["oi"] = {"wert": 100_000.0, "tag": jetzt // 86_400 - 1, "art": "Tagesstand", "pz": 0.5}
    m_tag = {x["key"]: x for x in bauen(q_tag)["messwerte"]}
    ok("Jedes Instrument nennt seinen Stand: Messwerte mit Zeitpunkt (live) oder UTC-Tag (Tagesstand, Funding-Druck), Schwankung mit dem "
       "Tag der Tageswerte und der Prognose, Kosten mit Zeitpunkt und Fenster, Hebel-Lampe mit dem Zeitpunkt der Kontenquote",
       m["oi"]["stand"] == jetzt - 300 and m["oi"]["stand_tag"] is None and m["konten"]["stand"] == jetzt - 300
       and m["funding"]["stand"] is None and m["funding"]["stand_tag"] == "10.11.2026" and m_tag["oi"]["stand"] is None
       and m_tag["oi"]["stand_tag"] == "10.11.2026" and s["stand_text"] == "Stand: Tageswerte bis 10.11.2026 (UTC), Prognose vom 10.11.2026."
       and k["stand"] == jetzt - 600 and k["tage"] == 30 and L["hebel"]["stand"] == jetzt - 300
       and "Tageswerte bis 10.11.2026" in L["schwankung"]["detail"] and L["aktien"]["stand"] == jetzt - 1500,
       f"{s['stand_text']} | Funding {m['funding']['stand_tag']} | Kosten {_datum(k['stand'])}")

    # ---- 2) Levels
    lv = d["levels"]
    ok("Levels: je Seite die drei nächsten zum jetzigen Kurs, oben das fernste zuerst; Abstand zum jetzigen Kurs; Niveau ohne "
       "Wahrscheinlichkeit fehlt",
       [n["px"] for n in lv["oben"]] == [65_000.0, 61_000.0, 60_500.0] and [n["px"] for n in lv["unten"]] == [59_500.0, 58_000.0]
       and abs(lv["oben"][-1]["abstand"] - (60_500 / 60_200 - 1)) < 1e-12 and lv["oben"][-1]["p7"] == 0.95 and lv["oben"][-1]["p14"] == 0.97
       and lv["oben"][-1]["momentaufnahme"] is True and lv["durchlaufen"] == 0,
       f"oben {[n['px'] for n in lv['oben']]}, unten {[n['px'] for n in lv['unten']]}")
    Q2 = copy.deepcopy(Q); Q2["kurs"]["px"] = 60_700.0
    lv2 = bauen(Q2)["levels"]
    ok("Levels: ein Niveau, das seit dem Anker durchlaufen wurde (60.500 bei Kurs 60.700, Anker 60.000), wird nicht mehr gezeigt, nur gezählt",
       60_500.0 not in [n["px"] for n in lv2["oben"] + lv2["unten"]] and lv2["durchlaufen"] == 1 and [n["px"] for n in lv2["oben"]] == [68_000.0, 65_000.0, 61_000.0],
       f"oben {[n['px'] for n in lv2['oben']]}, durchlaufen {lv2['durchlaufen']}")

    # ---- 3) Lampen an ihren Schwellen
    ok("Grundzustand (Mittwoch, kein Termin, Kontenquote 1,57): Hebel, Termin, Wochenende und Aktien aus",
       [L[k_]["zustand"] for k_ in ("hebel", "termin", "wochenende", "aktien")] == ["aus"] * 4 and L["termin"]["wert"] == "Arbeitsmarktbericht"
       and L["termin"]["ts"] == jetzt + 9 * TAG and L["wochenende"]["wert"] == "Mi", {k_: v["zustand"] for k_, v in L.items()})

    def lampe(key, **aend):
        q = copy.deepcopy(Q)
        for pfad, wert in aend.items():
            ziel = q; teile = pfad.split("__")
            for t in teile[:-1]:
                ziel = ziel[t]
            ziel[teile[-1]] = wert
        return next(l for l in bauen(q)["lampen"] if l["key"] == key)
    h299, h300 = lampe("hebel", lage__konten__wert=2.99), lampe("hebel", lage__konten__wert=3.0)
    ok("Hebel: Kontenquote 2,99 aus, 3,00 Hinweis (Regel H1, Schwelle 3); ohne Wert grau",
       h299["zustand"] == "aus" and h300["zustand"] == "hinweis" and h300["wert"] == "3,00 ≥ 3"
       and lampe("hebel", lage__konten={})["zustand"] == "grau", f"{h299['wert']} -> {h299['zustand']}, {h300['wert']} -> {h300['zustand']}")
    cpi = lambda ts: [{"reihe": "CPIAUCSL", "name": "Verbraucherpreise", "ts": ts}]
    t_vor24 = lampe("termin", termine=cpi(jetzt + 86_400)); t_vor24p = lampe("termin", termine=cpi(jetzt + 86_460))   # feste Zahlen: 24 h, 2 h
    t_jetzt = lampe("termin", termine=cpi(jetzt)); t_nach = lampe("termin", termine=cpi(jetzt - 7_140))
    t_ende = lampe("termin", termine=cpi(jetzt - 7_200))
    ok("Termin: genau 24 h davor Hinweis, eine Minute früher aus; ab der Veröffentlichung Warnung (Studie belegt) bis unter 2 h danach, dann aus",
       t_vor24["zustand"] == "hinweis" and t_vor24p["zustand"] == "aus" and t_jetzt["zustand"] == "warnung" and t_nach["zustand"] == "warnung"
       and t_ende["zustand"] == "aus" and t_jetzt["ts_ende"] == jetzt + 7_200,
       f"24 h davor {t_vor24['zustand']}, +1 min {t_vor24p['zustand']}, jetzt {t_jetzt['zustand']}, 1 h 59 danach {t_nach['zustand']}, 2 h danach {t_ende['zustand']}")
    t_unbelegt = lampe("termin", termine=cpi(jetzt), datentag_stand={"H1": {"belegt": False, "abs_verh": 2.4}})
    t_ppi = lampe("termin", termine=[{"reihe": "PPIFIS", "name": "Erzeugerpreise", "ts": jetzt + 3600}])
    ok("Termin: ohne „belegt“ der Studie nur Hinweis statt Warnung; Erzeugerpreise lösen nichts aus; ohne geladene Termine grau",
       t_unbelegt["zustand"] == "hinweis" and "noch kein Stand" in t_unbelegt["beleg"] and t_ppi["zustand"] == "aus"
       and lampe("termin", termine_geladen=False)["zustand"] == "grau", f"unbelegt {t_unbelegt['zustand']}, Erzeugerpreise {t_ppi['zustand']}")
    t_ohne = lampe("termin", naechste={"Erstanträge": jetzt + TAG}); t_einer = lampe("termin", naechste={"Verbraucherpreise": jetzt + 20 * TAG})
    t_vorbei = lampe("termin", naechste={"Verbraucherpreise": jetzt - 3 * TAG, "Arbeitsmarktbericht": jetzt - TAG})
    ok("Termin: ist kein kommender Termin bekannt (Kalender leer oder nur Vergangenes), ist die Lampe grau statt aus; fehlt nur eine der "
       "beiden Reihen, bleibt sie aus und nennt die fehlende",
       t_ohne["zustand"] == "grau" and t_ohne["wert"] == "keiner bekannt" and t_vorbei["zustand"] == "grau" and t_einer["zustand"] == "aus"
       and "Für Arbeitsmarktbericht ist kein kommender Termin bekannt" in t_einer["detail"] and "kein kommender Termin bekannt" not in L["termin"]["detail"],
       f"keiner: {t_ohne['zustand']}; nur Vergangenes: {t_vorbei['zustand']}; einer: {t_einer['zustand']} -- {t_einer['detail']}")
    fr, sa, so, mo = (lampe_wochenende(jetzt + n * TAG, 0.68) for n in (2, 3, 4, 5))
    ok("Wochenende: Freitag aus, Samstag und Sonntag (UTC) Hinweis, Montag aus; der Faktor steht im Beleg",
       [x["zustand"] for x in (fr, sa, so, mo)] == ["aus", "hinweis", "hinweis", "aus"] and [x["wert"] for x in (fr, sa, so, mo)] == ["Fr", "Sa", "So", "Mo"]
       and "0,68" in sa["beleg"] and "0,68" in sa["detail"], " · ".join(f"{x['wert']} {x['zustand']}" for x in (fr, sa, so, mo)))
    a_c = {"regel": "c", "seit": jetzt - 3600, "bewegung": -0.021, "offen": True}
    ak = lampe("aktien", ausnahme=a_c, ausnahme_text="Ausnahmelage seit …: S&P-500-Perp in 6 h −2,1 % -- nur ein Hinweis.")
    ak_alt = lampe("aktien", ausnahme=dict(a_c, seit=jetzt - TAG))
    ak_a = bauen(dict(copy.deepcopy(Q), ausnahme={"regel": "a", "seit": jetzt - 600, "bewegung": 0.03}, ausnahme_text="Ausnahmelage seit …: 30-min-Bewegung"))
    ak_a_l = next(l for l in ak_a["lampen"] if l["key"] == "aktien")
    ok("Aktien: Ausnahmelage (c) des Ausblicks -> Hinweis mit der S&P-Bewegung, nach 24 h aus („keine Ausnahme“); PAXG grau",
       ak["zustand"] == "hinweis" and ak["wert"] == "S&P −2,1 %" and ak["ts_ende"] == jetzt - 3600 + 86_400 and ak_alt["zustand"] == "aus"
       and ak_alt["wert"] == "keine Ausnahme" and L["aktien"]["wert"] == "keine Ausnahme"
       and bauen(_probe_quellen(jetzt, "PAXG"))["lampen"][3]["zustand"] == "grau", f"{ak['wert']}; nach 24 h {ak_alt['zustand']}")
    ok("Aktien: gilt für den Coin schon eine Ausnahmelage (a) aus der eigenen Bewegung, setzt der Ausblick (c) nicht -- die Lampe ist "
       "grau statt aus, die Ausnahme steht als Zeile unter dem Kernsatz",
       ak_a_l["zustand"] == "grau" and "eigenen Bewegung" in ak_a_l["detail"] and (ak_a["satz"]["ausnahme"] or "").startswith("Ausnahmelage")
       and lampe("aktien", ausnahme={"regel": "a", "seit": jetzt - 86_400, "bewegung": 0.03})["zustand"] == "aus", ak_a_l["detail"][:120])
    # feste Zahlen: Kerze jünger als 2 h (7.200 s), mindestens 12 Kerzen, Rechnung höchstens 3 h (10.800 s) alt
    p_ok = aktien_pruefung(0.0001, 12, jetzt - 7_199, jetzt - 10_800, jetzt)
    p_kerze = aktien_pruefung(0.0001, 12, jetzt - 7_200, jetzt - 60, jetzt); p_wenig = aktien_pruefung(0.0001, 11, jetzt - 60, jetzt - 60, jetzt)
    p_takt = aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 10_801, jetzt); p_basis = aktien_pruefung(None, 16, jetzt - 60, jetzt - 60, jetzt)
    p_keine = aktien_pruefung(0.0001, 0, None, jetzt - 60, jetzt); p_nie = aktien_pruefung(0.0001, 16, jetzt - 60, 0, jetzt)
    ok("Aktien-Regel nachweisbar geprüft: an den Grenzen (Kerze 1 h 59 min 59 s alt, 12 Kerzen, Rechnung genau 3 h alt) ja; Kerze 2 h alt, "
       "11 Kerzen, Rechnung 3 h 1 s alt, keine Basis, keine Kerze oder nie gerechnet -> nein, jeweils mit Grund",
       p_ok["ok"] is True and not p_ok["grund"] and [x["ok"] for x in (p_kerze, p_wenig, p_takt, p_basis, p_keine, p_nie)] == [False] * 6
       and "letzte Kerze" in p_kerze["grund"] and "zu wenige Kerzen" in p_wenig["grund"] and "Takt" in p_takt["grund"] and "Basis" in p_basis["grund"]
       and "zu wenige Kerzen" in p_keine["grund"] and "nicht bekannt" in p_nie["grund"] and p_ok["kerze_ts"] == jetzt - 7_199,
       f"Kerze 2 h: {p_kerze['grund'][:70]} | Takt: {p_takt['grund'][:60]}")
    ak_grau = lampe("aktien", aktien_pruefung=p_kerze); ak_unbek = lampe("aktien", aktien_pruefung=None)
    ak_c_trotz = lampe("aktien", ausnahme=a_c, aktien_pruefung=p_takt)
    ak_fremd = lampe("aktien", aktien_pruefung=aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 60, jetzt, ["ETH", "XMR"]))
    ak_drin = lampe("aktien", aktien_pruefung=aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 60, jetzt, ["ETH", "BTC"]))
    ok("Aktien: ohne Nachweis, dass die Regel geprüft wird, gibt es kein „aus“ -- die Lampe ist grau und nennt den Grund; ebenso, wenn "
       "der Coin nicht in der Basis der Regel steht; eine schon gesetzte Ausnahmelage (c) bleibt ein Hinweis",
       ak_grau["zustand"] == "grau" and ak_grau["wort"] == "kein Wert" and ak_grau["detail"] == p_kerze["grund"] and ak_unbek["zustand"] == "grau"
       and "nicht bekannt" in ak_unbek["detail"] and ak_c_trotz["zustand"] == "hinweis" and ak_fremd["zustand"] == "grau"
       and "Für BTC steht in der letzten Rechnung" in ak_fremd["detail"] and ak_drin["zustand"] == "aus",
       f"{ak_grau['zustand']}: {ak_grau['detail'][:90]}")

    def schw(pz_ziel, v1="belegt", erwartet=True):
        q = copy.deepcopy(Q)
        q["vol"]["vi7_reihe"] = [float(i) for i in range(1, 1001)][-PERZ_TAGE:]       # 636 … 1000, je einmal
        wert = 635.5 + pz_ziel * PERZ_TAGE                                         # zwischen zwei Werten: Perzentil = Anzahl kleinerer ÷ 365
        q["vol"]["v1"] = v1
        if erwartet:
            q["vol"]["erwartet"] = wert
        else:
            q["vol"]["erwartet"] = None; q["vol"]["real7"] = wert; q["vol"]["vi7_reihe"] = q["vol"]["vi7_reihe"] + [wert]
        return next(l for l in bauen(q)["lampen"] if l["key"] == "schwankung")
    s79, s80, s94, s95 = schw(291 / 365), schw(292 / 365), schw(346 / 365), schw(347 / 365)
    ok("Schwankung: Perzentil 0,797 aus, 0,800 Hinweis, 0,948 Hinweis, 0,951 Warnung (Schwellen 0,80 und 0,95; 292 bzw. 347 von 365 Tagen)",
       [x["zustand"] for x in (s79, s80, s94, s95)] == ["aus", "hinweis", "hinweis", "warnung"] and abs(s80["pz"] - 0.8) < 1e-12,
       " · ".join(f"{x['pz']:.3f} {x['zustand']}" for x in (s79, s80, s94, s95)))
    s_neutral = schw(0.99, v1=None); s_real = schw(0.99, erwartet=False)
    ok("Schwankung: ohne Urteil „belegt“ (V1) und ohne Prognose (nur realisiert) bleibt die Lampe neutral, auch im 99. Perzentil",
       s_neutral["zustand"] == "aus" and s_neutral["wort"] == "neutral" and s_neutral["klasse"] == "B" and "noch kein Urteil" in s_neutral["beleg"]
       and s_real["zustand"] == "aus" and s_real["wort"] == "neutral", f"ohne Urteil: {s_neutral['wort']}; nur realisiert: {s_real['wort']}")
    q_alt = copy.deepcopy(Q); q_alt["vol"]["bis"] = jetzt // 86_400 - 4                     # feste Zahl: Tageswerte 4 Tage alt
    q_grenze = copy.deepcopy(Q); q_grenze["vol"]["bis"] = jetzt // 86_400 - 3
    d_alt, d_grenze = bauen(q_alt), bauen(q_grenze)
    ok("Schwankung: Tageswerte 4 Tage alt -> Instrument nicht frisch (nennt „Tageswerte nur bis …“), Lampe grau statt Farbe; 3 Tage alt "
       "noch frisch",
       d_alt["schwankung"]["frisch"] is False and any("Tageswerte nur bis 07.11.2026" in f for f in d_alt["schwankung"]["fehlt"])
       and d_alt["lampen"][4]["zustand"] == "grau" and "Tageswerte nur bis" in d_alt["lampen"][4]["detail"]
       and d_grenze["schwankung"]["frisch"] is True and d_grenze["lampen"][4]["zustand"] != "grau" and d["schwankung"]["frisch"] is True,
       f"4 Tage: {d_alt['lampen'][4]['zustand']} ({d_alt['schwankung']['fehlt']}); 3 Tage: {d_grenze['lampen'][4]['zustand']}")

    # ---- 4) Frische und fehlende Quellen
    Q3 = copy.deepcopy(Q); Q3["ausblick"]["prognose"]["anker"] = jetzt - 172_860; Q3["kurs"]["ts"] = jetzt - 360     # feste Zahlen: 2 Tage, 5 min
    d3 = bauen(Q3)
    Q3b = copy.deepcopy(Q); Q3b["ausblick"]["prognose"]["anker"] = jetzt - 172_800; Q3b["kurs"]["ts"] = jetzt - 300
    d3b = bauen(Q3b)
    ok("Frische: Spanne älter als 2 Tage und Kurs älter als 5 min -> nicht frisch, mit Stand; genau an der Grenze noch frisch; ohne frischen "
       "Kurs zählen die Abstände der Levels ab dem Anker",
       d3["spanne"]["frisch"] is False and "älter als 2 Tage" in " ".join(d3["spanne"]["fehlt"]) and d3["kopf"]["frisch"] is False
       and d3["levels"]["kurs"] == 60_000.0 and "älter als 2 Tage" in d3["satz"]["text"] and d3b["spanne"]["frisch"] is True and d3b["kopf"]["frisch"] is True
       and d3["levels"]["frisch"] is False and "älter als 2 Tage" in " ".join(d3["levels"]["fehlt"]) and d3b["levels"]["frisch"] is True
       and not d3b["levels"]["fehlt"] and d["levels"]["frisch"] is True,
       f"{(d3['spanne']['fehlt'] or ['kein Hinweis'])[0]} | Kurs frisch {d3['kopf']['frisch']}")
    leer = bauen({"coin": "XMR", "jetzt": jetzt})
    ok("Leere Quellen (frisches System): Antwort ohne Ausnahme; nur die Lampe Wochenende hat einen Zustand (aus), alle anderen sind grau "
       "-- ohne Quelle gibt es kein „aus“; jedes Instrument nennt, was fehlt",
       leer["ok"] and leer["spanne"]["fehlt"] and leer["levels"]["fehlt"] and leer["kosten"]["fehlt"] and leer["schwankung"]["pz"] is None
       and leer["schwankung"]["frisch"] is False and leer["levels"]["frisch"] is False
       and [l["zustand"] for l in leer["lampen"]] == ["grau", "grau", "aus", "grau", "grau"] and "noch keine Spanne" in leer["satz"]["text"],
       [l["zustand"] for l in leer["lampen"]])
    js = json.dumps(_ohne_nan(bauen(dict(copy.deepcopy(Q), vol=dict(Q["vol"], real30=float("nan"))))), allow_nan=False)
    ok("Antwort ist JSON ohne NaN (auch wenn eine Quelle NaN liefert)", '"real30": null' in js, f"{len(js)} Zeichen")
    kn = kern("BTC", copy.deepcopy(Q))
    ok("Streifen: 80-%-Spanne der 7 Tage in % zum Anker und die fünf Lampenzustände",
       abs(kn["lo"] + 0.10) < 1e-12 and abs(kn["hi"] - 0.10) < 1e-12 and kn["lampen"] == [l["zustand"] for l in d["lampen"]] and len(kn["lampen"]) == 5,
       f"{_pc(kn['lo'], 0, True)} / {_pc(kn['hi'], 0, True)} · {kn['lampen']}")

    # ---- 5) Wortprobe
    alle = json.dumps([bauen(copy.deepcopy(Q)), ak_a, d3, leer, t_jetzt, h300, sa, ak, s95, d_alt, t_ohne, t_einer, ak_grau, ak_unbek,
                       ak_fremd, p_kerze, p_wenig, p_takt, p_basis, p_keine, p_nie], ensure_ascii=False).lower()
    treffer = [w for w in WORT_VERBOTEN if w in alle]
    pfeile = [z for z in "↑↓▲▼⬆⬇➚➘" if z in alle]
    ok("Wortprobe: keine Empfehlungswörter und kein Pfeil in den Texten des Cockpits", not treffer and not pfeile, f"gefunden: {treffer + pfeile or 'nichts'}")

    # ---- 5b) Seite ordnen (Kleinbild der Hauptseite)
    mini = ('<html><head><style>x</style></head><body>\n<div class="top"><nav class="nav">\n  <a href="#sec-chart">Chart</a><a href="#sec-signal">Konfluenz</a>'
            '<a href="#sec-system" class="dim">System</a>\n  <a class="dim" onclick="toggleAll()">alle</a>\n </nav></div>\n<div class="kpi" id="kpi"></div>\n'
            + "".join(f'<div class="panel" id="sec-{k}" data-sec="{k}">\n <h2>{k}</h2><div class="body">Inhalt {k}</div>\n</div>\n\n'
                      for k in ("chart", "signal", "neu", "labor", "network", "system"))
            + '<div id="taskbar"></div>\n<script>function applySec(){}</script>\n</body></html>')
    geo = seite_ordnen(mini)
    folge = [m_ for m_ in __import__("re").findall(r'id="(sec-\w+|grp-\w+|kpi)"', geo)]
    ok("Seite ordnen: Cockpit zuerst, Unbekanntes bleibt in der Hauptansicht, Werkstatt mit Kennzahlenleiste, Betrieb am Ende; jeder "
       "Abschnitt genau einmal; zweimal angewendet = einmal",
       folge == ["sec-cockpit", "sec-chart", "sec-neu", "grp-werkstatt", "kpi", "sec-signal", "sec-labor", "grp-betrieb", "sec-network", "sec-system"]
       and seite_ordnen(geo) == geo and all(geo.count(f'Inhalt {k}') == 1 for k in ("chart", "signal", "neu", "labor", "network", "system"))
       and len(__import__("re").findall(r"<div\b", geo)) == geo.count("</div>"), " > ".join(folge))
    nav_g = geo[geo.index('<nav class="nav">'):geo.index("</nav>")]
    ok("Seite ordnen: Navigationsleiste mit Cockpit, Hauptabschnitten, Werkstatt und Betrieb in dieser Reihenfolge; Namen der bisherigen "
       "Leiste; Erstlauf-Skript vor dem Hauptskript, Gruppen-Skript und /cockpit.js am Ende",
       __import__("re").findall(r'href="#(\w+-\w+)"', nav_g) == ["sec-cockpit", "sec-chart", "sec-neu", "grp-werkstatt", "sec-signal", "sec-labor", "grp-betrieb",
                                                               "sec-network", "sec-system"]
       and ">Konfluenz</a>" in nav_g and ">Netzwerk</a>" in nav_g and "toggleAll()" in nav_g
       and geo.index("hl_cockpit_v1") < geo.index("function applySec") < geo.index("function grpSchalten") < geo.index('<script src="/cockpit.js">')
       and '["chart", "labor", "network", "neu", "signal", "system"]' in geo, __import__("re").findall(r'href="#(\w+-\w+)"', nav_g))
    fehler = []
    for name, kaputt in (("Abschnitt doppelt", mini.replace('id="sec-neu" data-sec="neu"', 'id="sec-chart" data-sec="chart"')),
                         ("Abschnitt nicht geschlossen", mini.replace("Inhalt labor</div>\n</div>", "Inhalt labor</div>")),
                         ("Kennzahlenleiste fehlt", mini.replace('<div class="kpi" id="kpi"></div>\n', "")),
                         ("Navigationsleiste fehlt", mini.replace('<nav class="nav">', '<nav>'))):
        try:
            seite_ordnen(kaputt); fehler.append(name)
        except ValueError:
            pass
    ok("Seite ordnen: doppelter oder nicht geschlossener Abschnitt, fehlende Kennzahlenleiste oder Navigationsleiste -> ValueError (hl_viz "
       "liefert dann die ungeordnete Seite)", not fehler, f"ohne Fehler durchgelaufen: {fehler or 'keiner'}")

    # ---- 6) Vertrag mit den Modulen: echte Formen (Demo-Datenbanken der Module, ohne Netz)
    try:
        _vertrag(ok)
    except Exception as e:
        import traceback
        ok("Vertrag mit den Modulen ohne Ausnahme", False, f"{type(e).__name__}: {e} | {traceback.format_exc().splitlines()[-3].strip()}")

    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    if verbose:
        print("Cockpit -- Selbsttest (KONZEPT_Cockpit.md 6: Abgleich, Frische, Wortprobe, Schwellen der Lampen, Vertrag mit den Modulen)")
        for name, gut, wert in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name}" + (f"  {wert[:230]}" if wert else ""))
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(1 for p_ in pruef if p_[1])} von {len(pruef)})")
    return alles


def _vertrag(ok) -> None:
    """
    Die Quellen mit den echten Funktionen der Module auf deren Demo-Datenbanken lesen (hl_chartbild._demo_dbs über
    hl_ausblick._demo_umgebung): Prognose des Ausblicks gerechnet, Volatilität mit Tageswerten und einer von Hand eingetragenen
    Prognosezeile (über hl_volatil._prognose_zeilen, also in der echten Form), Positionierung aus hebel.db. Dann nutzlast() gegen die
    Zahlen der Module selbst. Lehre aus 23.97: Eine Probe auf einer selbst erdachten Welt beweist die Form der echten nicht.
    """
    import shutil
    import tempfile
    import hl_ausblick as AU
    import hl_chartbild as CB
    import hl_volatil as VL
    tmp = tempfile.mkdtemp(prefix="cockpit_vertrag_")
    alt_env = {k: os.environ.get(k) for k in ("HL_AKTIEN_DB",)}
    U = None
    try:
        jetzt = int(time.time()) // AU.BAR * AU.BAR - 600
        U = AU._demo_umgebung(os.path.join(tmp, "voll"), jetzt, tage=800, kurz={"HYPE": 520})
        db = U["pf"]["haupt"]
        AU.prognose(db, jetzt=jetzt, live_fn=lambda d_, c_: {})
        vc = VL.verbinden(VL.pfad(db))
        try:
            VL.tage_aktualisieren(vc, VL.quellen(db)["swing"], jetzt)
            heute = jetzt // TAG
            bis = vc.execute("SELECT MAX(tag) FROM vl_tag WHERE coin='BTC'").fetchone()[0]
            v_tag = (52.0 / 100.0) ** 2 / 365.0                                    # 52 % p. a. als Tagesvarianz
            pr = [{"woche": k, "mu": math.log(v_tag), "sigma": 0.3, "sigma_quelle": "probe", "sigma_fenster": 0.3, "v": v_tag * (1 + 0.01 * k),
                   "v_b0": v_tag, "v_b365": v_tag, "v_ewma": v_tag, "schwelle": v_tag * 2, "p": 0.2, "p_grund": 0.2, "p_markov": 0.2, "zustand": 0,
                   "x": [0.0], "pfad": [v_tag] * 7} for k in (1, 2, 3, 4)]
            with VL.schreiben(vc):
                VL._einfuegen(vc, [], VL._prognose_zeilen("BTC", int(bis), "M", pr, "tag", jetzt))
            NV = VL._ohne_nan(VL.nutzlast(vc, "chart", "BTC", jetzt))
        finally:
            vc.close()
        N = nutzlast(db, "BTC", jetzt)
        NA = AU.nutzlast(db, "BTC", None)
        P = NA["prognose"]
        ok("Vertrag Ausblick: Spanne des Cockpits gleich hl_ausblick.nutzlast (alle sieben Quantile, drei Horizonte), Anker und Kurs am Anker",
           all(N["spanne"]["h"][h]["q"] == [float(x) for x in P["spannen"][h]["q"]] for h in ("7", "14", "28")) and N["spanne"]["anker"] == P["anker"]
           and N["spanne"]["p0"] == P["p0"] and N["spanne"]["frisch"] is True,
           f"7 T 80 %: {_px(N['spanne']['h']['7']['q'][1])}–{_px(N['spanne']['h']['7']['q'][5])}; Vermerk {N['spanne']['h']['7']['vermerk']}")
        px_cockpit = {round(n["px"], 6) for n in N["levels"]["oben"] + N["levels"]["unten"]}
        px_ausblick = {round(float(n["px"]), 6): n for n in P["niveaus"] if n.get("p")}
        gleich_p = all(abs(n["p7"] - px_ausblick[round(n["px"], 6)]["p"]["7"][0]) < 1e-12 and abs(n["p14"] - px_ausblick[round(n["px"], 6)]["p"]["14"][0]) < 1e-12
                       for n in N["levels"]["oben"] + N["levels"]["unten"])
        ok("Vertrag Ausblick: jedes Level des Cockpits ist ein Niveau des Ausblicks mit denselben Wahrscheinlichkeiten (1 und 2 Wochen)",
           px_cockpit and px_cockpit <= set(px_ausblick) and gleich_p, f"{len(px_cockpit)} Levels von {len(px_ausblick)} Niveaus mit Wahrscheinlichkeit")
        w1 = NV["prognose"]["wochen"][0] if NV.get("prognose") else {}
        s = N["schwankung"]
        ok("Vertrag Volatilität: erwartete Schwankung gleich Woche 1 von hl_volatil.nutzlast, realisierte 7 und 30 Tage gleich dem letzten "
           "Wert der Reihen, Modelltext gleich",
           NV.get("prognose") and s["erwartet"] == w1.get("mitte") and s["real7"] == NV["reihe"]["vi7"][-1] and s["real30"] == NV["reihe"]["vi30"][-1]
           and s["modell"] == NV["prognose"]["modell_text"] and s["pz"] is not None,
           f"erwartet {s['erwartet']} (Abschnitt {w1.get('mitte')}), real 7 T {s['real7']} ({NV['reihe']['vi7'][-1]}), Perzentil {s['pz']}")
        con = CB._ro(db)
        try:
            Lg = CB.positionierung("BTC", db, con, jetzt)
        finally:
            con.close()
        m = {x["key"]: x for x in N["messwerte"]}
        hebel = N["lampen"][0]
        ok("Vertrag Chartbild: Kontenquote, Open Interest und ihre Perzentile gleich hl_chartbild.positionierung; die Hebel-Lampe rechnet mit "
           "derselben Zahl und der Schwelle des Chartbilds; XMR und PAXG ohne Absturz",
           abs(m["konten"]["wert"] - float(Lg["konten"]["wert"])) < 1e-12 and abs(m["konten"]["pz"] - float(Lg["konten"]["pz"])) < 1e-12
           and abs(m["oi"]["pz"] - float(Lg["oi"]["pz"])) < 1e-12 and abs(hebel["zahl"] - float(Lg["konten"]["wert"])) < 1e-12
           and (hebel["zustand"] == "hinweis") == (float(Lg["konten"]["wert"]) >= CB.KONTEN_SCHWELLE)
           and nutzlast(db, "XMR", jetzt)["ok"] and nutzlast(db, "PAXG", jetzt)["lampen"][0]["zustand"] == "grau",
           f"Konten {m['konten']['text']} (Perzentil {m['konten']['pz']:.3f}), Lampe {hebel['zustand']}")
        ok("Vertrag Streifen: sechs Coins in fester Reihenfolge, je mit Spanne und fünf Lampen; der gewählte Coin gleich dem vollen Cockpit",
           [e["coin"] for e in N["streifen"]] == list(COINS) and all(len(e["lampen"]) == 5 and e["lo"] is not None for e in N["streifen"])
           and N["streifen"][0]["lampen"] == [l["zustand"] for l in N["lampen"]],
           " · ".join(f"{e['coin']} {_pc(e['lo'], 0, True)}/{_pc(e['hi'], 0, True)}" for e in N["streifen"]))
        import hl_makro as MK
        mc = sqlite3.connect(U["pf"]["makro"], isolation_level=None)       # hl_makro.termine_schreiben öffnet seine Transaktion selbst
        try:
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('release:CPIAUCSL', ?)", (json.dumps({"id": 10}),))
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('release:UNRATE', ?)", (json.dumps({"id": 50}),))
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('datentage:stand', ?)",
                       (json.dumps({"erzeugt": jetzt - 5 * TAG, "von": "2020-01-01", "H1": {"belegt": True, "abs_verh": 2.45}, "H2": {"belegt": True, "abs_verh": 1.9}}),))
            tag_cpi = (jetzt // TAG + 1) * TAG; tag_job = (jetzt // TAG + 9) * TAG
            MK.termine_schreiben(mc, 10, [tag_cpi], jetzt); MK.termine_schreiben(mc, 50, [tag_job], jetzt)
        finally:
            mc.close()
        ts_cpi = MK.ny830_utc(tag_cpi)
        G1 = gemeinsam_lesen(db, ts_cpi - 3600); G2 = gemeinsam_lesen(db, ts_cpi + 600); G3 = gemeinsam_lesen(db, ts_cpi - 3 * TAG)
        l1 = lampe_termin(G1["termine"], G1["naechste"], G1["datentag_stand"], ts_cpi - 3600, G1["termine_geladen"])
        l2 = lampe_termin(G2["termine"], G2["naechste"], G2["datentag_stand"], ts_cpi + 600, G2["termine_geladen"])
        l3 = lampe_termin(G3["termine"], G3["naechste"], G3["datentag_stand"], ts_cpi - 3 * TAG, G3["termine_geladen"])
        ok("Vertrag Makro: Termine aus mk_termin (hl_makro.datentag_info und usa_termine) -- eine Stunde vor den Verbraucherpreisen Hinweis mit "
           "der Zeit 8:30 New York, zehn Minuten danach Warnung (Studie belegt), drei Tage davor aus mit dem nächsten Termin",
           l1["zustand"] == "hinweis" and l1["ts"] == ts_cpi and l1["wert"] == "Verbraucherpreise" and l2["zustand"] == "warnung" and l2["ts_ende"] == ts_cpi + 7_200
           and "2,5-mal" in l2["detail"] and l3["zustand"] == "aus" and l3["ts"] == ts_cpi and G1["termine_geladen"] is True,
           f"davor {l1['zustand']} ({_datum(l1.get('ts'))}), danach {l2['zustand']}, drei Tage davor {l3['zustand']} ({l3['wert']})")
        hc = sqlite3.connect(db)
        try:
            for c_, w_ in (("ETH", 2.99), ("ZEC", 3.0)):
                hc.execute("INSERT OR REPLACE INTO bnc_metrics VALUES (?, ?, 'global_ls_account', ?)", (jetzt - 60, c_, w_))
            hc.commit()
        finally:
            hc.close()
        vc = VL.verbinden(VL.pfad(db))
        try:
            bis_e = vc.execute("SELECT MAX(tag) FROM vl_tag WHERE coin='ETH'").fetchone()[0]
            with VL.schreiben(vc):
                VL._einfuegen(vc, [], VL._prognose_zeilen("ETH", int(bis_e) - 10, "M", pr, "tag", jetzt))
        finally:
            vc.close()
        NE = nutzlast(db, "ETH", jetzt); NZ = nutzlast(db, "ZEC", jetzt)
        ok("Vertrag an den Grenzen: Kontenquote 2,99 (frische Zeile in bnc_metrics) -> Hebel aus, 3,00 -> Hinweis; eine zehn Tage alte "
           "Prognose der Schwankung wird nicht gezeigt (dann zählt die realisierte, Lampe neutral)",
           NE["lampen"][0]["zustand"] == "aus" and abs(NE["lampen"][0]["zahl"] - 2.99) < 1e-9 and NZ["lampen"][0]["zustand"] == "hinweis"
           and NE["schwankung"]["erwartet"] is None and NE["schwankung"]["pz_von"].startswith("Realisierte") and NE["lampen"][4]["wort"] == "neutral"
           and any("Keine frische Prognose" in f_ for f_ in NE["schwankung"]["fehlt"]),
           f"ETH {NE['lampen'][0]['wert']} {NE['lampen'][0]['zustand']}, ZEC {NZ['lampen'][0]['wert']} {NZ['lampen'][0]['zustand']}; ETH Schwankung: {NE['schwankung']['fehlt']}")
        t = text(db, jetzt=jetzt)
        ok("Text (Debug-Lauf): je Coin Kurs, Kernsatz, fünf Lampen, Schwankung, Spannen, Stände; am Ende Belege und ob die Aktien-Regel "
           "geprüft wird; ohne Empfehlungswörter",
           all(f"== {c} " in t for c in COINS) and t.count("Lampe Hebel") == 6 and "Spanne  7 T" in t and not [w for w in WORT_VERBOTEN if w in t.lower()]
           and t.count("Stand: Tageswerte bis") >= 5 and "Tagesstand " in t and t.count("\nBelege: ") == 1 and "Konten ≥ 3" in t.split("\nBelege: ")[1]
           and "\nAktien-Regel des Ausblicks: wird NICHT geprüft -- Vom S&P-500-Perp liegen" in t
           and "NICHT FRISCH" not in t.split("== PAXG ")[1] and t.split("== PAXG ")[1].count("(kein Wert)") >= 2 and "grau, nicht aus" in t,
           f"{len(t.splitlines())} Zeilen; {t.splitlines()[-1][:110]}")
        # Aktien-Regel: Kerzen des S&P-500-Perp in der echten Form (hl_aktien.kerzen_schreiben), die Regel selbst setzt die Ausnahme
        import hl_aktien as AK
        g_ohne = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
        akc = AK.verbinden(AK.aktien_pfad(db))
        try:
            kerze = lambda ts_: (ts_, 5000.0, 5000.0, 5000.0, 5000.0, 1.0)
            # 5 Kerzen von vor 9–11 h und 11 aus den letzten 5,5 h: 16 Zeilen, aber nur 11 im 8-h-Fenster der Regel
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [kerze(jetzt - (22 - i) * 1800) for i in range(5)] + [kerze(jetzt - (11 - i) * 1800) for i in range(11)], jetzt)
            letzte_k = jetzt - 1800
            g_11 = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [kerze(jetzt - (16 - i) * 1800) for i in range(5)], jetzt)      # 8 h bis 6 h zurück: jetzt 16 im Fenster
            g_mit = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
            g_2h = gemeinsam_lesen(db, letzte_k + 7_200)["aktien_pruefung"]; g_159 = gemeinsam_lesen(db, letzte_k + 7_199)["aktien_pruefung"]
            l_ruhig = nutzlast(db, "BTC", jetzt)["lampen"][3]
            vor_schock = AU.schock_pruefen(db, jetzt, setzen=False)
            jetzt_s = jetzt + 3600
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [(jetzt, 5000.0, 5000.0, 4900.0, 4900.0, 1.0), (jetzt + 1800, 4900.0, 4900.0, 4900.0, 4900.0, 1.0)], jetzt_s)
        finally:
            akc.close()
        neu_c = [x for x in AU.schock_pruefen(db, jetzt_s) if x[1] == "c"]         # die Regel des Ausblicks setzt die Ausnahmelage
        NS = nutzlast(db, "BTC", jetzt_s); l_c = NS["lampen"][3]
        ok("Vertrag Aktien-Regel: ohne Kerzen des S&P-500-Perp ist die Lampe grau, ebenso mit nur 11 Kerzen im 8-h-Fenster (ältere "
           "zählen nicht); mit 16 Kerzen (hl_aktien.kerzen_schreiben) aus und „geprüft“, 2 h nach der letzten Kerze wieder grau (1 s davor "
           "nicht); ein Sprung von −2 % lässt hl_ausblick.schock_pruefen die Ausnahmelage (c) setzen, die Lampe zeigt sie als Hinweis; "
           "PAXG bleibt „gilt nicht“",
           g_ohne["ok"] is False and "zu wenige Kerzen" in g_ohne["grund"] and g_11["ok"] is False and "zu wenige Kerzen" in g_11["grund"]
           and g_11["kerze_ts"] == letzte_k and g_mit["ok"] is True and g_mit["kerze_ts"] == letzte_k and "BTC" in (g_mit["coins"] or [])
           and g_2h["ok"] is False and g_159["ok"] is True and l_ruhig["zustand"] == "aus" and not [x for x in vor_schock if x[1] == "c"]
           and any(x[0] == "BTC" for x in neu_c) and l_c["zustand"] == "hinweis" and l_c["wert"] == "S&P −2,0 %" and l_c["ts"] == jetzt_s
           and nutzlast(db, "PAXG", jetzt_s)["lampen"][3]["wort"] == "gilt nicht" and NS["streifen"][1]["lampen"][3] == "hinweis",
           f"ohne Kerzen: {g_ohne['grund'][:50]}… | mit: ok {g_mit['ok']} | Schock: {[(x[0], x[1]) for x in neu_c][:3]} -> Lampe {l_c['zustand']} {l_c['wert']}")
        leer_db = os.path.join(tmp, "leer", "hl_liq.db")
        os.makedirs(os.path.dirname(leer_db))
        sqlite3.connect(leer_db).close()
        alt = CB._mit_umgebung({k: os.path.join(tmp, "leer", os.path.basename(v)) for k, v in U["pf"].items()})
        os.environ["HL_AKTIEN_DB"] = os.path.join(tmp, "leer", "aktien.db")
        try:
            NL = json.loads(payload_json(leer_db, "BTC", jetzt))
        finally:
            CB._mit_umgebung(U["pf"]); os.environ["HL_AKTIEN_DB"] = U["pf"]["aktien"]
        ok("Leeres System (keine der Datenbanken vorhanden): /cockpit antwortet mit ok, grauen Lampen und Gründen statt mit einem Fehler",
           NL.get("ok") is True and NL["spanne"]["fehlt"] and NL["lampen"][0]["zustand"] == "grau" and len(NL["streifen"]) == 6
           and [l["zustand"] for l in NL["lampen"]] in (["grau", "grau", "aus", "grau", "grau"], ["grau", "grau", "hinweis", "grau", "grau"])
           and "ausblick.db fehlt" in NL["lampen"][3]["detail"],
           f"Lampen {[l['zustand'] for l in NL['lampen']]}; fehlt {NL['spanne']['fehlt'][:1]}")
    finally:
        try:
            if U is not None and hasattr(AU, "_demo_ende"):
                AU._demo_ende(U)
        except Exception:
            pass
        for k, v in alt_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    if "--selbsttest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--text" in sys.argv:
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        coins_ = (sys.argv[sys.argv.index("--coin") + 1].upper(),) if "--coin" in sys.argv else COINS
        print(text(db_, coins_))
        sys.exit(0)
    print(__doc__)
