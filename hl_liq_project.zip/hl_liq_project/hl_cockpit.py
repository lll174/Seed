#!/usr/bin/env python3
"""
hl_cockpit.py -- Cockpit des Dashboards (U245, KONZEPT_Cockpit.md; Stufe C1, Paket 23.98)

Auftrag des Nutzers (11.11.2026 20:58): „Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen
Indikatoren.“ Entscheidungen vom 12.11. (zum Anklicken): Cockpit oben auf der Hauptseite; ein Coin groß und ein Streifen mit allen
sechs; Unbelegtes in die „Werkstatt“; der Kurs-Rechner (Stufe C2) darf einen Kurs im Browser merken.

Regel: Ein Instrument bekommt nur, was belegt (Klasse A: ein vorab festgelegter Test ist bestanden) oder sauber gemessen ist
(Klasse B: ein Messwert, keine Vorhersage). Jedes Instrument nennt seinen Beleg und seinen Stand. Kein Pfeil, kein Empfehlungswort.
Das Cockpit RECHNET NICHTS NEUES außer Perzentilen, Abständen zum jetzigen Kurs und dem Kurs-Rechner (seit 23.105, siehe unten): Es
liest die Ergebnisse der Module
  hl_ausblick   Spanne 7/14/28 Tage, Ziellevels mit Erreich-Wahrscheinlichkeit, Ausnahmelage, Rückblick (Trefferquoten)
  hl_volatil    erwartete Schwankung (HAR), realisierte Schwankung 7/30 Tage, DVOL, Urteil V1, Datenprobe Wochenende
  hl_chartbild  Binance-Positionierung (Kontenquote = Regel H1, Open Interest) mit Perzentil gegen 90 Tagesstände, Funding-Druck
  hl_makro      Termine Verbraucherpreise und Arbeitsmarktbericht, Stand der Datentage-Studie
  hl_fusion     mittlere Bewegung E|r| und nötige Trefferquote (Kostenschwelle)
  hl_aktien     Kerzen des S&P-500-Perp -- nur für die Frage, ob die Aktien-Regel des Ausblicks gerade geprüft wird
und ändert nichts: nur lesende Zugriffe, keine Prognose, kein Urteil, kein Labor.

Lampen (Schwellen fest und vorab, KONZEPT_Cockpit 4):
  Hebel       Kontenquote Binance ≥ 3 (hl_chartbild.KONTEN_SCHWELLE, Regel H1)                      -> Hinweis
  Termin      Verbraucherpreise oder Arbeitsmarktbericht: 24 h davor                                -> Hinweis
              von der Veröffentlichung bis 2 h danach, wenn die Datentage-Studie „belegt“ meldet     -> Warnung (sonst Hinweis)
              (ist kein kommender Termin bekannt: grau -- „kein Termin bekannt“ heißt nicht „kein Termin“)
  Wochenende  Samstag oder Sonntag (UTC, wie die Tageswerte der Volatilität)                         -> Hinweis (ruhiger)
  Aktien      Ausnahmelage (c) des Ausblicks: S&P-500-Perp in 6 h über 3 typische Bewegungen, 24 h   -> Hinweis
              („aus“ nur, wenn die Regel nachweislich geprüft wird: Basis vorhanden, letzte Kerze des S&P-500-Perp jünger als
              2 h, letzte Rechnung des Ausblicks jünger als 3 h; sonst grau)
  Schwankung  erwartete Schwankung der nächsten 7 Tage im Perzentil gegen 365 Tage: ab 0,80          -> Hinweis, ab 0,95 Warnung
              (Farbe nur, wenn das Urteil V1 der Volatilität „belegt“ lautet; sonst neutral; Tageswerte älter als 3 Tage: grau)

Seit 23.104 (U260) dazu die Karte „Unstaking · Verlauf“ (nur ETH, gemessen): Schlange der Abzüge und ETH-Kurs je UTC-Tag mit den
Wellen der Prüfung der Kursfolge als Marken -- Antwort unter /cockpit/unstaking (verlauf_nutzlast), Reihen aus hl_staking_studie.verlauf.

Seit 23.105 (U245 Stufe C2) der Kurs-Rechner: Für einen eingetippten Kurs die Wahrscheinlichkeit, dass er vom JETZIGEN Kurs aus berührt
wird -- in 1 und 4 Stunden mit dem Nullmodell des Magnet-Tests (hl_magnet/hl_kaskade, U110; c und τ je Coin, Schwankung der letzten
7 Tage aus hl_anker.Markt), in 7 und 14 Tagen aus der Verteilung des laufenden Hochs und Tiefs der jüngsten Rechnung des Ausblicks
(hl_ausblick.erreichen_aus_lauf). Antwort unter /cockpit/rechner (rechner_nutzlast). Die Zahl folgt allein aus Abstand und Schwankung.
Gemerkte Kurse liegen nur im Browser des Nutzers; der Server speichert sie nicht.

Seit 23.108 (U245 Stufe C2, Rest; KONZEPT_Cockpit.md 14) vier gemessene Teile (Klasse B, neutral, ohne Vorhersage):
  Funding (Hyperliquid)   jüngster Satz je Stunde aus ctx_bars, Perzentil gegen die Stundenwerte der letzten 90 Tage
  Taker-Varianz           dieselbe Zahl wie in der Prognose (hl_indikatoren.varianz_kompression): letzte volle Stunde gegen 30 Tage,
                          das unterste Zehntel ist markiert -- in der Literatur ein Vorläufer von Kaskaden im Mittel, im Projekt nicht geprüft
  Liquidationsdichte      jüngster Schnappschuss der Heatmap: Positionswert mit Liquidationspreis bis 3 % vom Kurs in Stufen von 0,5 %,
                          mit Abdeckung des Open Interest und dem Anteil der zu alten Positionen
  Betrieb                 Lampe: Warnung, wenn ein eingerichteter Dienst nicht läuft (systemctl wie der Wächter); Hinweis bei API-Gewicht
                          ab 93 % des harten Limits (Schwelle des Wächters -- der Recorder nutzt planmäßig 90 %) oder Backup älter als 36 h

Seit 23.110 (U269, Wunsch des Nutzers vom 17.11.2026) die Karte „Durchschnittslinien“ (Klasse B, gemessen): 50- und 200-Tage-Linie je Coin
-- Wert nach dem letzten vollen Tag (einfacher Durchschnitt der Tagesschlüsse aus hl_chartbild.trendlage, dieselben Zahlen wie im
Chartbild und wie die Niveaus des Ausblicks), Abstand des jetzigen Kurses, Richtung jeder Linie, Lage der Linien zueinander und --
wenn der Ausblick die Linie als Niveau führt -- seine Erreich-Wahrscheinlichkeit für 1 und 2 Wochen. Der Beleg nennt den Prüfstand der
Regel (U141 B2) und das Urteil der Niveau-Arten (U244, hl_niveaus); dieses Urteil steht seitdem auch im Beleg der Karte „Levels“.
Seit 23.111 (U270, Entscheidung des Nutzers vom 18.11.2026) zeigt die Karte beide Rechnungen, die es im Dashboard gibt: groß den Wert
wie im Live-Chart und in der Kachel „MA 200 Tage“ (hl_viz.load_mas -- der heutige Tag zählt mit dem jetzigen Kurs mit), klein den Wert
nach dem letzten Tagesschluss (Chartbild, Ausblick, „Levels“).

Aufrufe:  hl_cockpit.py --selbsttest | --text [--db PFAD] [--coin BTC]
"""
from __future__ import annotations

import calendar
import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import threading
import time

VERSION_MODUL = "2026-09-23.111"
TAG = 86_400
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")

# ---- Schwellen der Lampen (fest und vorab; eine Änderung ist eine neue Fassung mit Datum)
TERMIN_VOR_S = 24 * 3600
TERMIN_NACH_S = 2 * 3600                       # das Fenster der Datentage-Studie (U154): zwei Stunden nach 8:30 New York
SCHWANKUNG_GELB = 0.80
SCHWANKUNG_ROT = 0.95
PERZ_TAGE = 365                                # Vergleichszeitraum der Schwankung
# ---- Frische: älter -> das Instrument wird grau und nennt seinen Stand
FRISCH_KURS_S = 300
FRISCH_AUSBLICK_S = 2 * TAG                    # wie hl_ausblick.nutzlast („älter als 2 Tage“)
FRISCH_SCHWANKUNG_TAGE = 3                     # wie hl_volatil.nutzlast (Prognose nur, wenn der Ursprung höchstens 3 Tage alt ist)
# ---- Lampe „Aktien“: „aus“ gilt nur, solange die Regel (c) des Ausblicks nachweislich geprüft wird
AKTIEN_REIHE = "xyz:SP500:30m"                 # die Reihe, die hl_ausblick.schock_pruefen liest
AKTIEN_KERZE_S = 2 * 3600                      # wie dort: die letzte Kerze des S&P-500-Perp muss jünger als 2 h sein …
AKTIEN_KERZEN_MIN = 12                         # … und es braucht mindestens 12 Kerzen in den letzten 8 h
AKTIEN_RECHNUNG_S = 3 * 3600                   # die Prüfung läuft im Takt des Ausblicks (stündliche Rechnung): älter als 3 h = Takt steht
LEVELS_JE_SEITE = 3
WORT_VERBOTEN = ("kaufen", "verkaufen", "kaufsignal", "verkaufssignal", "bullisch", "bärisch", "kursziel", "einstieg", "ausstieg",
                 "empfehl", "long gehen", "short gehen")
WOCHENTAGE = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
SATZ_RICHTUNG = "Richtung nicht belegt. Das Cockpit zeigt Spanne, Risiko und Wahrscheinlichkeiten."
BELEG_KOSTEN = ("Rechnung, kein Test: nötige Trefferquote = 1/2 + Kosten ÷ (2 × mittlere Bewegung); Kosten = Gebühr je Seite "
                "(Taker dazu der halbe Spread), hin und zurück.")
BELEG_ER = ("Mittlere absolute Bewegung der letzten 30 Tage. Gegen die eingetretene Bewegung geprüft (Bericht „Fusion“ vom "
            "11.11.2026: Verhältnis 1,02 ± 0,05).")
BELEG_MESSWERT = ("Messwert, keine Vorhersage. Perzentil gegen die letzten 90 Tagesstände; Funding (Hyperliquid) und Taker-Varianz "
                  "nennen ihren Vergleichszeitraum in der Zeile.")
# ---- 23.108 (U245 Stufe C2, Rest): Funding (Hyperliquid), Taker-Varianz, Liquidationsdichte, Betrieb
FUNDING_TAGE = 90                              # Vergleichszeitraum des Hyperliquid-Fundings: die Werte zur vollen Stunde
FUNDING_MIN_TAGE = 14                          # ein Perzentil gibt es ab so vielen Tagen Verlauf …
FUNDING_MIN_N = 240                            # … und so vielen Stundenwerten
FRISCH_FUNDING_S = 900                         # jüngster Wert höchstens 15 min alt (wie der Wächter: „Markpreis-Feed still“ nach 900 s)
TAKER_TAGE = 30                                # wie hl_indikatoren.varianz_kompression
TAKER_DEZIL = 0.10                             # unterstes Zehntel: dort weitet die Prognose ihr Band („komprimiert“)
TAKER_NOTE = ("Markiert ist das unterste Zehntel. In der Literatur ist eine sinkende Varianz des Taker-Flusses der einzige durchgehende "
              "Vorläufer von Kaskaden -- im Mittel, nicht im Einzelfall (Audit vom 11.11.2026, Abschnitt 5). Im Projekt ist das nicht geprüft.")
LIQ_BREITE = 0.03                              # Liquidationsdichte: Liquidationspreise bis 3 % unter und über dem Kurs
LIQ_STUFE = 0.005                              # ein Balken je 0,5 %
LIQ_ALTER_S = 3600                             # hl_recorder.Settings.max_pos_age: ältere Positionen gehen nicht in den Schnappschuss
FRISCH_LIQ_S = 1800                            # Schnappschuss höchstens 30 min alt (Takt 10 min; wie hl_chartbild.FRISCH["heatmap"])
LIQ_NAME_UNTEN = "Long-Liquidationen darunter"  # Beschriftung der Seiten -- vom Server, das Skript der Seite trägt keine Positionswörter
LIQ_NAME_OBEN = "Short-Liquidationen darüber"
BELEG_LIQ = ("Gemessen, keine Vorhersage: Summe der Positionswerte bekannter Konten, deren Liquidationspreis in der Stufe liegt "
             "(unter dem Kurs Long-, darüber Short-Positionen). Erfasst ist nur ein Teil des Marktes -- die Balken sind eine Untergrenze.")
API_HINWEIS = 0.93                             # Hinweis ab 93 % des harten Limits -- die Warnschwelle des Wächters (hl_watchdog.run_checks)
FRISCH_API_S = 1800                            # der Recorder schreibt das Gewicht bei jedem Schnappschuss (alle 10 min)
BACKUP_HINWEIS_H = 36                          # Hinweis, wenn die letzte Sicherung älter ist (KONZEPT_Cockpit.md 4)
DIENSTE = ("hl-recorder", "hl-dashboard", "hl-binance", "hl-coinbase", "hl-notbremse", "hl-watchdog")      # die Dienste aus install.py
DIENST_CACHE_S = 30                            # so lange gilt eine Abfrage der Dienste
DIENST_BESTAETIGT_S = 60                       # erst so lange nach der ersten Sichtung „nicht aktiv“ wird aus dem Hinweis eine Warnung
BELEG_BETRIEB = ("Gemessen. Warnung: Ein eingerichteter Dienst läuft nicht. Hinweis: API-Gewicht ab 93 % des Limits der Börse (der Recorder "
                 "nutzt planmäßig 90 %) oder letzte Sicherung älter als 36 Stunden. Einzelheiten im Bereich Betrieb.")
BELEG_UNSTAKING = ("Gemessen an der Kette, keine Vorhersage: Jeder angemeldete Abzug aus dem Ethereum-Staking hat seinen festen "
                   "Zeitpunkt.")                # dahinter steht der Satz zur Prüfung der Kursfolge (pruefung_bauen, seit 23.101)
UNSTAKING_TAGE = 14                            # so viele Tage des Kalenders zeigt die Karte, der Rest als Summe
# ---- 23.104 (U260) Karte „Unstaking · Verlauf“
VERLAUF_LUECKE_TAGE = 3                        # fehlt die Schlange so viele Tage in Folge, zeigt der Verlauf dort „keine Daten“ statt einer Linie
VERLAUF_BEREICHE = (("3m", "3 Monate", 92), ("1j", "1 Jahr", 366))      # wählbare Ausschnitte (Tage bis heute); dazu immer „alles“
VERLAUF_START = "1j"                           # Ausschnitt beim Öffnen
VERLAUF_TITEL = "Schlange der Abzüge und ETH-Kurs"
# 23.105 (U245 Stufe C2): Kurs-Rechner -- Wahrscheinlichkeit, dass ein eingetippter Kurs vom JETZIGEN Kurs aus berührt wird
# Fristen: Schlüssel, Name, Kurzform (Spalte der Karte), Satzteil, Zahl, Einheit (h = Nullmodell des Magnet-Tests, d = Verteilung des Ausblicks)
RECHNER_FRISTEN = (("1h", "1 Stunde", "1 h", "in 1 Stunde", 1, "h"), ("4h", "4 Stunden", "4 h", "in 4 Stunden", 4, "h"),
                   ("7d", "7 Tage", "7 Tage", "in 7 Tagen", 7, "d"), ("14d", "14 Tage", "14 Tage", "in 14 Tagen", 14, "d"))
RECHNER_ARTEN = (("liq", "Liquidation"), ("stopp", "Stopp"), ("limit", "Limit"), ("marke", "Marke"))     # Namen der gemerkten Kurse
RECHNER_MERKEN = 6                             # so viele Kurse merkt die Karte je Coin (im Browser des Nutzers)
RECHNER_MAX_KURSE = 8                          # so viele Kurse rechnet eine Anfrage höchstens
RECHNER_FAKTOR = 5.0                           # gerechnet wird zwischen einem Fünftel und dem Fünffachen des jetzigen Kurses
RECHNER_SIGMA_GEPRUEFT = 3.0                   # das Nullmodell ist an Zufallsniveaus bis 3 σ der Frist geprüft (hl_magnet.ZUFALL_X)
RECHNER_ABSTAND_GEPRUEFT = 0.30                # die Prüfung S3 des Ausblicks reicht bis 30 % Abstand (Swing-Niveaus, hl_ausblick._swing_niveaus)
RECHNER_ZUFALL_FEHLER = 1                      # so viele der Zufallsabstände dürfen außerhalb von 2 Standardfehlern liegen; mehr -> „ungenauer“
RECHNER_TEXT_ABSTAENDE = (-0.10, -0.05, -0.02, -0.01, 0.01, 0.02, 0.05, 0.10)      # Beispielkurse im Debug-Text (relativ zum jetzigen Kurs)
RECHNER_NOTE_SIGMA = "nicht geprüft, weil der Kurs weiter weg liegt als {x} übliche Schwankungen dieser Frist"
RECHNER_NOTE_ABSTAND = "nicht geprüft, weil der Kurs weiter weg liegt als {x} %"
RECHNER_NOTE_MONOTON = "mindestens so hoch wie bei der kürzeren Frist (Stunden und Tage rechnen mit getrennten Modellen)"
# Trefferquote des 80-%-Bands für den Coin außerhalb der Toleranz (Rückblick S1, dieselbe Wertung wie an der Spanne): Folge für die Tage
RECHNER_NOTE_BAND = "Für {coin} ist die Spanne des Ausblicks im Rückblick {wort} (das 80-%-Band traf {x}) -- {folge}"
RECHNER_BAND_FOLGE = {"zu eng": "der Kurs verließ das Band öfter als erwartet, diese Wahrscheinlichkeiten können zu niedrig sein",
                      "zu weit": "der Kurs blieb öfter im Band als erwartet, diese Wahrscheinlichkeiten können zu hoch sein"}
RECHNER_BELEG_ALLG = ("Die Zahl folgt allein aus Abstand und Schwankung -- nicht aus der Art des Niveaus und nicht aus einer Richtung. "
                      "„Berührt“ heißt: Der Kurs erreicht die Marke mindestens einmal; ob er darüber hinaus schließt, sagt die Zahl nicht. "
                      "Für eine Liquidation zählt der Mark-Preis der Börse, nicht der hier gezeigte Kurs.")
RECHNER_BELEG_KOPF = ("Gerechnet aus Abstand und Schwankung, ohne Richtung: Stunden mit dem Nullmodell des Magnet-Tests, Tage mit der "
                      "Verteilung des Ausblicks. „Berührt“ heißt: mindestens einmal erreicht.")
RECHNER_BELEG_SCHLUSS = "Nur aus Abstand und Schwankung, keine Richtung."



# ================================================================================================ kleine Helfer

def _zahl(x):
    """float oder None (NaN, unendlich, kein Wert -> None)."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _de(x, nd: int = 1, vz: bool = False) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    s = f"{v:+.{nd}f}" if vz else f"{v:.{nd}f}"
    return s.replace(".", ",").replace("-", "−")


def _px(x) -> str:
    """Kurs mit deutscher Tausenderteilung; Nachkommastellen nach Größe."""
    v = _zahl(x)
    if v is None:
        return "—"
    nd = 0 if abs(v) >= 1000 else 2 if abs(v) >= 10 else 4
    s = f"{v:,.{nd}f}"
    return s.replace(",", "§").replace(".", ",").replace("§", ".").replace("-", "−")


def _pc(x, nd: int = 1, vz: bool = False) -> str:
    v = _zahl(x)
    return "—" if v is None else _de(v * 100, nd, vz) + " %"


def _p(p) -> str:
    """p-Wert: unter 0,001 als „< 0,001“, sonst drei Stellen."""
    v = _zahl(p)
    return "—" if v is None else ("< 0,001" if v < 0.001 else _de(v, 3))


def pz_zahl(pz) -> int | None:
    """
    Perzentil als ganze Zahl für die Anzeige -- abgeschnitten, nicht gerundet (23.99): „80.“ steht nur da, wenn die Schwelle 0,80
    erreicht ist. Gerundet zeigte ZEC am 12.11.2026 „80. Perzentil“ bei 0,796 und die Lampe „aus“. „Höher als an n % der Tage“ bleibt
    abgeschnitten wahr; 100 heißt: höher als alle Werte des Fensters. Das 1e-9 gleicht die Gleitkommazahl aus
    (0,29 · 100 = 28,999999999999996 wäre sonst 28).
    """
    v = _zahl(pz)
    return None if v is None else max(0, min(100, int(math.floor(v * 100.0 + 1e-9))))


def deckung_zusatz(d: dict | None, kurz: bool = False) -> str:
    """Zusatz zur gemessenen Deckung des 80-%-Bands, wie hl_ausblick.deckung_wertung: außerhalb von 80 % ± 2 Standardfehler „zu eng“
    oder „zu weit“; sonst nichts. kurz: „ (zu weit)“ statt „ -- zu weit (Soll 80 %)“."""
    d = d or {}
    tr = _zahl(d.get("d80"))
    if tr is None or d.get("ok") is None or d.get("ok"):
        return ""
    wort = "zu eng" if tr < 0.80 else "zu weit"
    return f" ({wort})" if kurz else f" -- {wort} (Soll 80 %)"


def _datum(ts) -> str:
    v = _zahl(ts)
    return "—" if v is None else time.strftime("%d.%m. %H:%M UTC", time.gmtime(int(v)))


def _tag_datum(tag) -> str:
    v = _zahl(tag)
    return "—" if v is None else time.strftime("%d.%m.%Y", time.gmtime(int(v) * TAG))


def perzentil(x, werte) -> float | None:
    """Mittelrang von x unter den Werten (wie hl_chartbild.perzentil): mindestens 60 endliche, nicht alle gleich; sonst None."""
    v = _zahl(x)
    w = [u for u in (_zahl(a) for a in (werte or [])) if u is not None]
    if v is None or len(w) < 60 or max(w) == min(w):
        return None
    kleiner = sum(1 for a in w if a < v); gleich = sum(1 for a in w if a == v)
    return (kleiner + 0.5 * gleich) / len(w)


def _lampe(key, name, zustand, wort, wert, detail, beleg, klasse="A", **mehr) -> dict:
    d = {"key": key, "name": name, "zustand": zustand, "wort": wort, "wert": wert, "detail": detail, "beleg": beleg, "klasse": klasse}
    d.update(mehr)
    return d


# ================================================================================================ Lampen (reine Funktionen)

def lampe_hebel(coin: str, konten: dict | None, schwelle: float, beleg: str, fehlt: str = "") -> dict:
    """Regel H1: Kontenquote Binance (Long- zu Short-Konten) ≥ Schwelle. konten = Eintrag aus hl_chartbild.positionierung."""
    name = "Hebel"
    w = _zahl((konten or {}).get("wert"))
    if w is None:
        return _lampe("hebel", name, "grau", "kein Wert", "—", fehlt or f"Für {coin} liegt keine frische Kontenquote von Binance vor.", beleg)
    art = (konten or {}).get("art") or ""
    stand = (konten or {}).get("ts") or ((int((konten or {}).get("tag")) + 1) * TAG if (konten or {}).get("tag") is not None else None)
    if w >= schwelle:
        return _lampe("hebel", name, "hinweis", "Hinweis", f"{_de(w, 2)} ≥ {_de(schwelle, 0)}",
                      f"Kontenquote Binance {_de(w, 2)}: Auf ein Short-Konto kommen {_de(w, 2)} Long-Konten ({art}). Ab {_de(schwelle, 0)} "
                      "folgte in 7 Tagen häufiger ein Rücksetzer.", beleg, stand=stand, zahl=w)
    return _lampe("hebel", name, "aus", "aus", f"{_de(w, 2)} von {_de(schwelle, 0)}",
                  f"Kontenquote Binance {_de(w, 2)} ({art}); die Regel greift ab {_de(schwelle, 0)}.", beleg, stand=stand, zahl=w)


def lampe_termin(termine: list | None, naechste: dict | None, stand: dict | None, jetzt: int, geladen: bool = True) -> dict:
    """
    termine: [{"reihe": "CPIAUCSL"|"UNRATE", "name": …, "ts": Veröffentlichung in UTC-Sekunden}] (hl_makro.datentag_info);
    naechste: {Name: ts} der nächsten Termine (hl_makro.usa_termine); stand: Datentage-Studie {"H1": {"belegt", "abs_verh"}, "H2": …}.
    """
    name = "Termin"
    kuerzel = {"CPIAUCSL": "H1", "UNRATE": "H2"}
    teile = []
    for k, n_ in (("H1", "Verbraucherpreise"), ("H2", "Arbeitsmarktbericht")):
        h = (stand or {}).get(k) or {}
        if h.get("belegt") is True and _zahl(h.get("abs_verh")):
            teile.append(f"{n_} rund {_de(h['abs_verh'], 1)}-mal")
    beleg = ("Datentage-Studie (U154), belegt: in den zwei Stunden nach der Veröffentlichung waren die Kursausschläge von BTC und ETH "
             "im Mittel größer als an anderen Werktagen (" + ", ".join(teile) + "). Keine Richtung.") if teile else \
        "Datentage-Studie (U154): noch kein Stand mit „belegt“ -- die Lampe zeigt nur den Termin."
    if not geladen:
        return _lampe("termin", name, "grau", "kein Wert", "—", "Die Termine der USA sind noch nicht geladen (makro.db).", beleg)
    aktiv = None
    for t in sorted(termine or [], key=lambda e: e.get("ts") or 0):
        ts = _zahl(t.get("ts"))
        if ts is None or t.get("reihe") not in kuerzel:
            continue
        if ts - TERMIN_VOR_S <= jetzt < ts + TERMIN_NACH_S:
            aktiv = t; break
    if aktiv:
        ts = int(aktiv["ts"]); h = (stand or {}).get(kuerzel[aktiv["reihe"]]) or {}
        belegt = h.get("belegt") is True and bool(_zahl(h.get("abs_verh")))
        if jetzt >= ts:
            zus = (f" In den zwei Stunden danach waren die Kursausschläge im Mittel rund {_de(h['abs_verh'], 1)}-mal so groß."
                   if belegt else "")
            return _lampe("termin", name, "warnung" if belegt else "hinweis", "läuft", aktiv["name"],
                          f"{aktiv['name']} der USA: veröffentlicht, das Fenster der Studie läuft bis zwei Stunden danach.{zus}",
                          beleg, ts=ts, ts_ende=ts + TERMIN_NACH_S)
        return _lampe("termin", name, "hinweis", "Hinweis", aktiv["name"],
                      f"{aktiv['name']} der USA in weniger als 24 Stunden.", beleg, ts=ts)
    kommend = sorted((int(v), k) for k, v in (naechste or {}).items()
                     if k in ("Verbraucherpreise", "Arbeitsmarktbericht") and _zahl(v) and v >= jetzt)
    if kommend:
        ohne = [n_ for n_ in ("Verbraucherpreise", "Arbeitsmarktbericht") if n_ not in {k for _, k in kommend}]
        return _lampe("termin", name, "aus", "aus", kommend[0][1], f"Nächster Termin: {kommend[0][1]} der USA."
                      + (f" Für {ohne[0]} ist kein kommender Termin bekannt." if ohne else ""), beleg, ts=kommend[0][0])
    # kein kommender Termin bekannt: Das ist kein „aus“ -- der Kalender kann leer oder veraltet sein
    return _lampe("termin", name, "grau", "kein Wert", "keiner bekannt",
                  "Kein kommender Termin für Verbraucherpreise oder Arbeitsmarktbericht bekannt -- der Kalender der Veröffentlichungen "
                  "ist leer oder veraltet (Abschnitt „Makro“).", beleg)


def lampe_wochenende(jetzt: int, faktor: float | None = None) -> dict:
    """Samstag oder Sonntag nach UTC (die Tageswerte der Volatilität sind UTC-Tage)."""
    wt = time.gmtime(int(jetzt)).tm_wday
    f = _zahl(faktor)
    beleg = (f"Datenprobe der Volatilität: Varianz an Samstagen und Sonntagen im Mittel das {_de(f, 2)}-Fache der Werktage (BTC und ETH "
             "seit 2020). Ein Messwert, kein Test." if f is not None else
             "Datenprobe der Volatilität steht noch aus (erwartet: am Wochenende ruhiger).")
    if wt >= 5:
        return _lampe("wochenende", "Wochenende", "hinweis", "an", WOCHENTAGE[wt],
                      "Wochenende (UTC): Die Schwankung ist an diesen Tagen im Mittel kleiner"
                      + (f" (Varianz × {_de(f, 2)})." if f is not None else "."), beleg, klasse="B")
    return _lampe("wochenende", "Wochenende", "aus", "aus", WOCHENTAGE[wt], "Werktag (UTC).", beleg, klasse="B")


def lampe_aktien(coin: str, ausnahme: dict | None, jetzt: int, dauer_s: int, text: str = "", s4: dict | None = None,
                 pruefung: dict | None = None) -> dict:
    """Ausnahmelage (c) des Ausblicks (hl_ausblick.schock_pruefen): S&P-500-Perp in 6 h über 3 typische Bewegungen; gilt 24 h.
    pruefung: Ergebnis von aktien_pruefung (wird die Regel gerade geprüft?). Ohne Nachweis gibt es kein „aus“, nur „kein Wert“."""
    p = _zahl(((s4 or {}).get("variogramm") or {}).get("p")) if s4 else None
    if s4 and s4.get("besteht") is True:
        beleg = ("Abhängigkeit vom S&P 500 im Rückblick des Ausblicks belegt" + (f" (p {_p(p)})" if p is not None else "")
                 + ". Die Lampe zeigt die Ausnahmelage des Ausblicks; unter Aktienstress ist die Spanne nicht geprüft kalibriert.")
    elif s4 and s4.get("besteht") is False:
        beleg = ("Abhängigkeit vom S&P 500 im jüngsten Rückblick nicht belegt" + (f" (p {_p(p)})" if p is not None else "")
                 + ". Die Lampe zeigt nur die Ausnahmelage des Ausblicks.")
    else:
        beleg = "Abhängigkeit vom S&P 500: der Rückblick des Ausblicks steht noch aus. Die Lampe zeigt nur die Ausnahmelage."
    if coin == "PAXG":
        return _lampe("aktien", "Aktien", "grau", "gilt nicht", "—", "Für PAXG (Gold) wird die Aktien-Regel nicht angewendet.", beleg)
    a = ausnahme or {}
    seit = _zahl(a.get("seit"))
    if a.get("regel") == "c" and seit is not None and 0 <= jetzt - seit < dauer_s:
        bew = _zahl(a.get("bewegung"))
        return _lampe("aktien", "Aktien", "hinweis", "Hinweis", "S&P " + (_pc(bew, 1, True) if bew is not None else "bewegt"),
                      text or "Der S&P-500-Perp hat sich in 6 Stunden ungewöhnlich stark bewegt.", beleg, ts=int(seit), ts_ende=int(seit) + dauer_s)
    pr = pruefung or {}
    if a.get("regel") in ("a", "b") and seit is not None and 0 <= jetzt - seit < dauer_s:
        # hl_ausblick.schock_pruefen setzt (c) nicht, solange für den Coin schon eine Ausnahmelage gilt
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      f"Für {coin} gilt schon eine Ausnahmelage aus der eigenen Bewegung (sie steht unter dem Kernsatz). Solange sie "
                      "gilt, setzt der Ausblick die Aktien-Regel für diesen Coin nicht.", beleg, ts_ende=int(seit) + dauer_s)
    if pr.get("ok") is not True:
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      pr.get("grund") or "Ob der Ausblick die Aktien-Regel gerade prüft, ist nicht bekannt.", beleg, stand=pr.get("kerze_ts"))
    if pr.get("coins") is not None and coin not in pr["coins"]:
        # schock_pruefen setzt (c) nur für Coins, die in der letzten Rechnung des Ausblicks stehen
        return _lampe("aktien", "Aktien", "grau", "kein Wert", "—",
                      f"Für {coin} steht in der letzten Rechnung des Ausblicks keine Basis -- die Aktien-Regel wird für diesen Coin nicht gesetzt.",
                      beleg, stand=pr.get("kerze_ts"))
    return _lampe("aktien", "Aktien", "aus", "aus", "keine Ausnahme",
                  "Keine Ausnahmelage aus dem S&P-500-Perp in den letzten 24 Stunden; die Regel wird laufend geprüft.", beleg,
                  stand=pr.get("kerze_ts"))


def aktien_pruefung(fs1, kerzen_n: int | None, kerze_ts, rechnung_ts, jetzt: int, coins=None) -> dict:
    """
    Wird die Regel (c) gerade geprüft? Dieselben Bedingungen wie in hl_ausblick.schock_pruefen: Basis FS1 vorhanden, mindestens
    12 Kerzen des S&P-500-Perp in den letzten 8 h, die letzte jünger als 2 h. Dazu: Die Prüfung läuft im Takt des Ausblicks -- ist
    dessen letzte Rechnung älter als 3 h, steht der Takt. coins: die Coins der Basis (nur für sie setzt die Regel eine Ausnahme).
    -> {"ok", "grund", "kerze_ts", "rechnung_ts", "coins"}
    """
    kt = _zahl(kerze_ts); rt = _zahl(rechnung_ts)
    out = {"ok": False, "grund": "", "kerze_ts": int(kt) if kt is not None else None, "rechnung_ts": int(rt) if rt else None,
           "coins": sorted(coins) if coins is not None else None}
    if not _zahl(fs1):
        out["grund"] = ("Dem Ausblick fehlt die Basis für die Aktien-Regel (die typische Tagesbewegung des S&P 500 aus seiner letzten "
                        "Rechnung) -- die Regel wird nicht geprüft.")
    elif kt is None or int(kerzen_n or 0) < AKTIEN_KERZEN_MIN:
        out["grund"] = ("Vom S&P-500-Perp liegen in den letzten 8 Stunden zu wenige Kerzen vor"
                        + (f" (letzte {_datum(kt)})" if kt is not None else "") + " -- die Aktien-Regel wird gerade nicht geprüft.")
    elif jetzt - kt >= AKTIEN_KERZE_S:
        out["grund"] = f"Die letzte Kerze des S&P-500-Perp ist von {_datum(kt)} -- die Aktien-Regel wird gerade nicht geprüft."
    elif not rt or jetzt - rt > AKTIEN_RECHNUNG_S:
        out["grund"] = ("Die letzte Rechnung des Ausblicks ist " + (f"von {_datum(rt)}" if rt else "nicht bekannt")
                        + " -- sein Takt, in dem die Aktien-Regel geprüft wird, steht offenbar.")
    else:
        out["ok"] = True
    return out


def lampe_schwankung(pz: float | None, v1: str | None, quelle: str, wert_pa: float | None, fehlt: str = "", stand: str = "") -> dict:
    """pz: Perzentil der erwarteten (sonst der realisierten) Schwankung gegen 365 Tage. Farbe nur bei Urteil V1 „belegt“.
    stand: Satz zum Stand der Tageswerte (steht im Detail)."""
    belegt = v1 == "belegt"
    beleg = ("Niveau der Schwankung über 1–4 Wochen: belegt (Urteil V1 der Volatilität)." if belegt else
             "Niveau der Schwankung: noch kein Urteil „belegt“ (V1) -- die Lampe bleibt neutral und zeigt nur das Perzentil.")
    if pz is None:
        return _lampe("schwankung", "Schwankung", "grau", "kein Wert", "—", fehlt or "Keine Schwankungswerte für diesen Coin.", beleg)
    txt = f"{pz_zahl(pz)}. Perzentil"
    detail = (f"{quelle} {_de(wert_pa, 1)} % pro Jahr: höher als an {pz_zahl(pz)} % der Tage der letzten {PERZ_TAGE} Tage."
              + (" " + stand if stand else ""))
    if not belegt or quelle.startswith("Realisierte"):
        return _lampe("schwankung", "Schwankung", "aus", "neutral", txt, detail, beleg, klasse="B", pz=pz)
    if pz >= SCHWANKUNG_ROT:
        return _lampe("schwankung", "Schwankung", "warnung", "hoch", txt, detail, beleg, pz=pz)
    if pz >= SCHWANKUNG_GELB:
        return _lampe("schwankung", "Schwankung", "hinweis", "erhöht", txt, detail, beleg, pz=pz)
    return _lampe("schwankung", "Schwankung", "aus", "aus", txt, detail, beleg, pz=pz)


# ================================================================================================ Instrumente (reine Funktionen)

def spanne_bauen(coin: str, prognose: dict | None, rueckblick: dict | None, kurs: float | None, jetzt: int) -> dict:
    """Spannen 7/14/28 Tage aus der jüngsten Rechnung des Ausblicks; Trefferquote des 80-%-Bands aus dem Rückblick (S1)."""
    out = {"h": {}, "fehlt": [], "frisch": False, "anker": None, "p0": None, "kurs": _zahl(kurs)}
    P = prognose or {}
    sp = P.get("spannen") or {}
    if not sp:
        out["fehlt"].append("Noch keine Rechnung des Ausblicks für diesen Coin.")
        out["beleg"] = "Ausblick: noch keine Spanne."
        return out
    out["anker"] = P.get("anker"); out["p0"] = _zahl(P.get("p0"))
    alter = jetzt - int(P.get("anker") or 0)
    out["frisch"] = alter <= FRISCH_AUSBLICK_S
    if not out["frisch"]:
        out["fehlt"].append(f"Stand vom {_datum(P.get('anker'))} -- älter als 2 Tage.")
    S1 = ((rueckblick or {}).get("s1") or {}).get("h") or {}
    lo = hi = None
    for h in ("7", "14", "28"):
        q = [(_zahl(x)) for x in ((sp.get(h) or {}).get("q") or [])]
        if len(q) != 7 or any(x is None for x in q):
            continue
        e = S1.get(h) or {}
        d = ((e.get("deckung") or {}).get(coin) or {})
        tr = _zahl(d.get("d80"))
        gew = _zahl(e.get("gewinn_rel")); p = _zahl(e.get("p"))
        # Zwei getrennte Aussagen (23.99): die gemessene Trefferquote des Bands für DIESEN Coin und der Vorsprung des Fächers gegen
        # das Vergleichsmodell. Die Gesamtprüfung S1 des Ausblicks („besteht“) verlangt den Vorsprung UND die Deckung von BTC und ETH
        # zugleich; sie steht im Beleg, entscheidet aber nicht über die Beschriftung des einzelnen Balkens. Bis 23.98 tat sie das --
        # auf dem Pi stand bei 7 Tagen „Vorsprung offen“, obwohl der Vorsprung belegt war (p 0,002).
        if not S1:
            vermerk = "Rückblick steht aus"
        elif tr is None:
            vermerk = "Trefferquote nicht gemessen"
        else:
            vermerk = f"traf {_de(tr * 100, 0)} %" + deckung_zusatz(d, kurz=True)
        vorsprung = None if not e else ("belegt" if p is not None and p < 0.05 and (gew or 0) > 0
                                        else ("keiner" if gew is not None and gew <= 0 else "offen"))
        out["h"][h] = {"q": q, "treffer": tr, "se": _zahl(d.get("se")), "deckung_ok": d.get("ok") if "ok" in d else None, "gewinn": gew, "p": p,
                       "vorsprung": vorsprung, "besteht": e.get("besteht") if "besteht" in e else None, "vermerk": vermerk}
        lo = q[0] if lo is None else min(lo, q[0]); hi = q[6] if hi is None else max(hi, q[6])
    if lo is not None:
        k = out["kurs"] or out["p0"]
        if k:
            lo, hi = min(lo, k), max(hi, k)
        rand = (hi - lo) * 0.04
        out["skala"] = [lo - rand, hi + rand]
    if S1:
        teile = []
        for h in ("7", "14", "28"):
            e = out["h"].get(h)
            if not e or not e.get("vorsprung"):
                continue
            g = f"Gewinn {_pc(e['gewinn'], 1, True)}"
            teile.append(f"{h} Tage belegt ({g}, p {_p(e['p'])})" if e["vorsprung"] == "belegt"
                         else (f"{h} Tage keiner ({g})" if e["vorsprung"] == "keiner" else f"{h} Tage nicht belegt ({g}, p {_p(e['p'])})"))
        beleg = "Rückblick des Ausblicks, außerhalb der Stichprobe."
        if teile:
            beleg += " Vorsprung gegen das einfache Vergleichsmodell: " + " · ".join(teile) + "."
        e7 = out["h"].get("7") or {}
        if e7.get("treffer") is not None:
            beleg += (f" Das 80-%-Band für 7 Tage traf bei {coin} {_de(e7['treffer'] * 100, 1)} %"
                      + (f" ± {_de(e7['se'] * 100, 1)}" if e7.get("se") is not None else "")
                      + deckung_zusatz({"d80": e7["treffer"], "ok": e7.get("deckung_ok")}) + ".")
        s7 = S1.get("7") or {}
        if "besteht" in s7:
            # die Gründe aus denselben Größen, aus denen hl_ausblick das Urteil bildet (p < 0,05; Deckung von BTC und ETH in 80 % ± 2 SE)
            gruende = []
            p7 = _zahl(s7.get("p"))
            if p7 is None or p7 >= 0.05:
                gruende.append("der Vorsprung ist nicht belegt")
            for c in ("BTC", "ETH"):
                dc = (s7.get("deckung") or {}).get(c)
                if not dc:
                    gruende.append(f"für {c} fehlt die Deckung")
                elif not dc.get("ok", False):
                    t_ = _zahl(dc.get("d80")); se_ = _zahl(dc.get("se"))
                    gruende.append(f"das Band von {c} ist {'zu eng' if (t_ or 0) < 0.80 else 'zu weit'} ({_de((t_ or 0) * 100, 1)} %"
                                   + (f" ± {_de(se_ * 100, 1)}" if se_ is not None else "") + ")")
            beleg += (" Gesamtprüfung S1 des Ausblicks für 7 Tage (Vorsprung und Deckung bei BTC und ETH zugleich): "
                      + ("besteht." if s7.get("besteht") else "besteht nicht" + (" -- " + "; ".join(gruende) if gruende else "") + "."))
        out["beleg"] = beleg
    else:
        out["beleg"] = "Der Rückblick des Ausblicks steht noch aus -- die Spanne ist noch nicht geprüft."
    return out


def levels_bauen(prognose: dict | None, rueckblick: dict | None, kurs: float | None, je_seite: int = LEVELS_JE_SEITE,
                 niveaus: dict | None = None) -> dict:
    """Die nächsten Niveaus über und unter dem JETZIGEN Kurs aus der jüngsten Rechnung des Ausblicks. Die Wahrscheinlichkeiten gelten
    ab dem Anker; ein Niveau, das seit dem Anker durchlaufen wurde, erscheint nicht mehr (es wird gezählt). niveaus (seit 23.110): das
    Urteil der Niveau-Arten aus niveaus_urteil_lesen -- der Beleg nennt es."""
    P = prognose or {}
    p0 = _zahl(P.get("p0")); k = _zahl(kurs) or p0
    out = {"oben": [], "unten": [], "kurs": k, "p0": p0, "anker": P.get("anker"), "durchlaufen": 0, "fehlt": []}
    S3 = ((rueckblick or {}).get("s3") or {}).get("h") or {}
    e7 = S3.get("7") or {}
    if e7:
        out["beleg"] = ("Erreich-Wahrscheinlichkeiten im Rückblick geprüft: über 7 Tage Brier-Skill "
                        f"{_pc(e7.get('skill'), 1, True)}, Steigung {_de(e7.get('steigung'), 2)} "
                        f"({'besteht' if e7.get('besteht') else 'besteht nicht'}). " + niveau_art_satz(niveaus))
    else:
        out["beleg"] = "Der Rückblick des Ausblicks steht noch aus -- die Wahrscheinlichkeiten sind noch nicht geprüft."
    if not k or not P.get("niveaus"):
        out["fehlt"].append("Keine Niveaus aus dem Ausblick.")
        return out
    oben, unten = [], []
    for n in P.get("niveaus") or []:
        px = _zahl(n.get("px")); p = n.get("p") or {}
        if px is None or not p or px <= 0:
            continue
        p7 = _zahl((p.get("7") or [None])[0]); p14 = _zahl((p.get("14") or [None])[0])
        if p7 is None or p14 is None:
            continue
        if p0 and ((px - p0) * (px - k) < 0 or px == k):
            out["durchlaufen"] += 1                                  # lag über dem Anker und liegt jetzt unter dem Kurs (oder umgekehrt)
            continue
        e = {"name": str(n.get("name") or "")[:60], "px": px, "abstand": px / k - 1.0, "p7": p7, "p14": p14,
             "momentaufnahme": bool(n.get("momentaufnahme")), "art": n.get("art") or ""}
        (oben if px > k else unten).append(e)
    oben.sort(key=lambda e: e["px"]); unten.sort(key=lambda e: -e["px"])
    out["oben"] = oben[:je_seite][::-1]                              # in der Anzeige: das fernste oben, das nächste direkt über dem Kurs
    out["unten"] = unten[:je_seite]
    return out


def schwankung_bauen(vol: dict | None, er4: float | None, jetzt: int) -> dict:
    """vol: Ergebnis von schwankung_lesen (hl_volatil). -> Instrument „Schwankung“ mit Perzentil gegen 365 Tage."""
    V = vol or {}
    out = {"erwartet": _zahl(V.get("erwartet")), "real7": _zahl(V.get("real7")), "real30": _zahl(V.get("real30")), "dvol": _zahl(V.get("dvol")),
           "er4": _zahl(er4), "modell": V.get("modell_text"), "ursprung": V.get("ursprung"), "v1": V.get("v1"), "stand_tag": V.get("bis"),
           "fehlt": list(V.get("fehlt") or []), "pz": None, "pz_n": None, "pz_von": None, "skala_max": None}
    bis = _zahl(V.get("bis"))
    # Frische: Tageswerte höchstens 3 Tage alt (wie schwankung_lesen); sonst wird das Instrument blass und die Lampe grau
    out["frisch"] = bis is not None and int(jetzt) // TAG - int(bis) <= FRISCH_SCHWANKUNG_TAGE
    if bis is not None and not out["frisch"] and not any("Tageswerte nur bis" in f for f in out["fehlt"]):
        out["fehlt"].append(f"Tageswerte nur bis {_tag_datum(bis)}.")
    out["stand_text"] = ("" if bis is None else f"Stand: Tageswerte bis {_tag_datum(bis)} (UTC)"
                         + (f", Prognose vom {_tag_datum(V.get('ursprung'))}" if out["erwartet"] is not None and _zahl(V.get("ursprung")) is not None else "")
                         + ".")
    reihe = V.get("vi7_reihe") or []
    if out["erwartet"] is not None:
        out["pz"] = perzentil(out["erwartet"], reihe[-PERZ_TAGE:]); out["pz_von"] = "Erwartete Schwankung (7 Tage)"; anz = out["erwartet"]
        out["pz_n"] = pz_zahl(out["pz"])
    elif out["real7"] is not None:
        out["pz"] = perzentil(out["real7"], reihe[-PERZ_TAGE - 1:-1]); out["pz_von"] = "Realisierte Schwankung (7 Tage)"; anz = out["real7"]
        out["pz_n"] = pz_zahl(out["pz"])
    else:
        anz = None
    out["anzeige"] = anz
    endlich = [u for u in (_zahl(a) for a in reihe[-PERZ_TAGE:]) if u is not None]
    if anz is not None:
        out["skala_max"] = float(max([anz * 1.15] + ([max(endlich)] if endlich else []) + [20.0]))
    v1 = V.get("v1")
    out["beleg"] = ("Niveau der Schwankung belegt (Urteil V1 der Volatilität"
                    + (f", p Holm {_de(V.get('v1_p_holm'), 4)}" if _zahl(V.get("v1_p_holm")) is not None else "") + "). "
                    if v1 == "belegt" else "Niveau der Schwankung: noch kein Urteil „belegt“ (V1). ") \
        + ("„In 4 h typisch“: " + BELEG_ER if out["er4"] is not None else "")
    return out


def messwerte_bauen(lage: dict | None, funding: dict | None, schwelle: float, coin: str = "", funding_hl: dict | None = None,
                    taker: dict | None = None, jetzt: int | None = None) -> list:
    """Klasse B: Open Interest und Kontenquote (Binance) mit Perzentil gegen 90 Tagesstände, Funding-Druck; seit 23.108 dazu das Funding
    von Hyperliquid (Perzentil gegen die Stundenwerte der letzten 90 Tage) und die Varianz des Taker-Flusses. Neutral, keine Wertung."""
    L = lage or {}
    out = []
    for key, name, nd in (("oi", "Open Interest (Binance)", None), ("konten", "Kontenquote (Binance)", 2)):
        e = L.get(key) or {}
        w = _zahl(e.get("wert"))
        z = {"key": key, "name": name, "wert": w, "pz": _zahl(e.get("pz")), "pz_n": pz_zahl(e.get("pz")), "art": e.get("art") or "",
             "stand": e.get("ts"), "stand_tag": _tag_datum(e["tag"]) if e.get("ts") is None and e.get("tag") is not None else None}
        if key == "konten":
            z["marke"] = schwelle; z["text"] = _de(w, 2) if w is not None else "—"
        else:
            z["text"] = "—" if w is None else f"{_px(w)} {coin}".strip()
        out.append(z)
    f = funding or {}
    out.append({"key": "funding", "name": "Funding-Druck (Binance, 30 Tage)", "wert": _zahl(f.get("z")), "pz": None, "pz_n": None,
                "text": _de(f.get("z"), 1, True) if _zahl(f.get("z")) is not None else "—", "art": "z-Wert",
                "stand": None, "stand_tag": _tag_datum(f["tag"]) if f.get("tag") is not None else None})
    out.append(funding_hl_zeile(funding_hl, int(jetzt or time.time())))                    # 23.108 (U245 Stufe C2, Rest)
    out.append(dict(taker_zeile(taker), note=TAKER_NOTE))
    return out


def kosten_bauen(ks: dict | None) -> dict:
    """Nötige Trefferquote für 4 und 24 Stunden aus hl_fusion.kostenschwelle (flache Schlüssel er_h, p_taker_h, p_maker_h)."""
    K = ks or {}
    out = {"zeilen": [], "taker": _zahl(K.get("taker")), "maker": _zahl(K.get("maker")), "halbspread_bps": _zahl(K.get("halbspread_bps")),
           "stand": K.get("ts"), "tage": K.get("tage"), "beleg": BELEG_KOSTEN, "fehlt": []}
    for h in (4, 24):
        pt, pm, er = _zahl(K.get(f"p_taker_{h}")), _zahl(K.get(f"p_maker_{h}")), _zahl(K.get(f"er_{h}"))
        if er is None or pt is None or pm is None:
            continue
        out["zeilen"].append({"h": h, "er": er, "taker": pt, "maker": pm})
    if not out["zeilen"]:
        out["fehlt"].append("Noch zu wenige Minutenkerzen für die mittlere Bewegung (mindestens 3 Tage).")
    return out


def _eth(x) -> str:
    v = _zahl(x)
    return "—" if v is None else f"{v:,.0f}".replace(",", ".").replace("-", "−")


def _usd(x) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    if abs(v) >= 1e9:
        return f"{_de(v / 1e9, 2)} Mrd. USD"
    if abs(v) >= 1e6:
        return f"{_de(v / 1e6, 0)} Mio. USD"
    return f"{_eth(v)} USD"


def _pos(n) -> str:
    """Zahl der Positionen mit Einzahl: „1 Position“, sonst „n Positionen“ (23.109; Debug 143 vom 17.11.2026 schrieb „1 Positionen“)."""
    return "1 Position" if n == 1 else f"{n} Positionen"


def _usd1(x) -> str:
    """USD-Betrag kurz, Millionen mit einer Stelle (die Balken der Liquidationsdichte liegen oft bei wenigen Millionen)."""
    v = _zahl(x)
    if v is None:
        return "—"
    a = abs(v)
    if a >= 1e9:
        return f"{_de(v / 1e9, 2)} Mrd. USD"
    if a >= 1e6:
        return f"{_de(v / 1e6, 1)} Mio. USD"
    if a >= 1e3:
        return f"{_de(v / 1e3, 0)} Tsd. USD"
    return f"{_de(v, 0)} USD"


def _tag_utc(ts) -> str:
    t = time.gmtime(int(ts))
    return f"{WOCHENTAGE[t.tm_wday]} {t.tm_mday:02d}.{t.tm_mon:02d}."


def _iso_datum(t) -> str | None:
    """„2026-10-25“ -> „25.10.2026“; alles andere -> None (dann nennt der Text kein Datum, statt eines zu erfinden)."""
    t = str(t or "")
    if len(t) == 10 and t[4] == "-" and t[7] == "-" and (t[:4] + t[5:7] + t[8:]).isdigit():
        return f"{t[8:10]}.{t[5:7]}.{t[:4]}"
    return None


def pruefung_bauen(P: dict | None) -> dict:
    """
    23.101 (U255): das gespeicherte Urteil der vorab festgelegten Prüfung „Folgt auf große Abzüge ein Kursrückgang?“
    (hl_staking_studie.kurz) in zwei Sätzen -- kurz für die Karte, lang für den Beleg. Hier wird nichts gerechnet und nichts gefärbt:
    Auch ein „belegt“ bleibt Text, bis die Warnlampe eigens festgelegt ist (KONZEPT_Unstaking.md 6).
    """
    nr = 147
    if isinstance(P, dict) and _zahl(P.get("debug")) is not None:
        nr = int(P["debug"])
    frage = "Folgt darauf ein Kursrückgang?"
    if not isinstance(P, dict) or not P.get("da"):
        return {"da": False, "urteil": None, "ts": None, "kurz": f"{frage} Noch nicht geprüft (Debug {nr} rechnet die Prüfung).",
                "lang": ("Ob auf große Abzüge Kursrückgänge folgen, ist noch nicht geprüft: Die Prüfung ist vorab festgelegt "
                         f"(KONZEPT_Unstaking.md 6) und rechnet einmal mit Debug {nr} -- bis dahin ohne Warnfarbe.")}
    u = str(P.get("urteil") or "")
    tag = time.strftime("%d.%m.%Y", time.gmtime(int(P["ts"]))) if _zahl(P.get("ts")) is not None else "—"
    A, B = P.get("A") or {}, P.get("B") or {}
    faelle = f"{int(A.get('n') or 0)} Fälle nach der Anmeldung, {int(B.get('n') or 0)} nach der Freigabe"
    # 23.102: letzter bewerteter Tag -- die Karte sagt, bis wohin das Urteil reicht. Anlass: Debug 147 vom 15.11.2026 rechnete mit einer
    # Tagesdatei, die am 25.10. endete; ohne diese Angabe las sich „Geprüft am 15.11.“ so, als sei die Welle vom November mitgeprüft.
    wb = _iso_datum(P.get("daten_bis"))
    wann = f"Geprüft am {tag}" + (f" (Wellen bis {wb})" if wb else "")
    kopf = f"Ob auf große Abzüge Kursrückgänge folgen, ist geprüft ({tag}, Regeln vorab festgelegt" + (f", Wellen bis {wb}" if wb else "") + "): "
    if u == "belegt":
        wo = [(n_, e_) for n_, e_ in (("nach der Anmeldung", A), ("nach der Freigabe", B)) if e_.get("urteil") == "belegt"]
        kurz = f"{frage} {wann}: belegt ({' und '.join(n_ for n_, _e in wo) or '—'})."
        teile = [f"{n_} lag ETH in den 7 Tagen im Mittel {_de(abs(_zahl(e_.get('diff'))) * 100, 1)} %-Punkte schwächer gegen BTC als sonst"
                 for n_, e_ in wo if _zahl(e_.get("diff")) is not None]
        lang = kopf + "belegt -- " + "; ".join(teile) + ". Die Warnlampe dazu wird eigens festgelegt -- bis dahin ohne Warnfarbe."
    elif u == "nicht belegt":
        g = [v for v in (_zahl(A.get("grenze")), _zahl(B.get("grenze"))) if v is not None]
        kurz = f"{frage} {wann}: nicht belegt."
        lang = (kopf + f"nicht belegt ({faelle})."
                + (f" Ein Nachteil unter rund {_de(max(g) * 100, 1)} % wäre mit diesen Daten oft nicht zu erkennen." if g else "")
                + " Deshalb ohne Warnfarbe.")
    elif u == "zu wenige Fälle":
        kurz = f"{frage} Zu wenige Fälle für ein Urteil (Stand {tag}" + (f", Wellen bis {wb}" if wb else "") + ")."
        lang = (f"Ob auf große Abzüge Kursrückgänge folgen, lässt sich noch nicht beurteilen ({tag}): {faelle}, nötig sind "
                f"{int(_zahl(P.get('min_faelle')) or 8)}. Deshalb ohne Warnfarbe.")
    else:
        kurz = f"{frage} Prüfung vom {tag} ohne gültiges Urteil."
        lang = (f"Die Prüfung, ob auf große Abzüge Kursrückgänge folgen, gab am {tag} kein gültiges Urteil (ihre Nullprobe ist nicht "
                "bestanden). Deshalb ohne Warnfarbe.")
    if P.get("aktuell") is False:
        kurz += f" Ältere Fassung der Regeln -- Debug {nr} rechnet neu."
        lang += f" Das Urteil stammt aus einer älteren Fassung der Regeln; Debug {nr} rechnet neu."
    return {"da": True, "urteil": u or None, "ts": P.get("ts"), "kurz": kurz, "lang": lang}


def unstaking_bauen(U: dict | None, kurs: float | None, jetzt: int, pruefung: dict | None = None) -> dict | None:
    """
    Klasse B (gemessen; 23.100, U254): angemeldete Abzüge aus dem Ethereum-Staking mit dem Zeitpunkt, den die Kette ihnen zugeteilt hat
    (hl_staking.nutzlast). Neutral, ohne Warnfarbe. Gerechnet wird hier nichts außer Summe je Tag, Anteil am Tagesdurchsatz, Anteil
    des Abziehers und dem Wert in USD zum frischen Kurs. Seit 23.101 steht daneben das gespeicherte Urteil der Prüfung der Kursfolge
    (pruefung_bauen) -- als Text. None = kein Instrument (anderer Coin).
    """
    if not isinstance(U, dict):
        return None
    pr = pruefung_bauen(pruefung)
    out = {"ok": bool(U.get("ok")), "quelle": U.get("quelle"), "stand": U.get("stand"), "geschaetzt": bool(U.get("geschaetzt")),
           "fehlt": list(U.get("fehlt") or []), "hinweise": list(U.get("hinweise") or []), "beleg": BELEG_UNSTAKING + " " + pr["lang"],
           "pruefung": pr, "tage": [],
           "abzieher": [], "gross": None, "satz": "", "tage_mehr": 0, "tage_mehr_eth": 0.0}
    if not out["ok"]:
        return out
    px = _zahl(kurs)
    usd = lambda e: (e * px if e is not None and px is not None else None)        # noqa: E731
    summe = _zahl(U.get("summe_eth")); voll = _zahl(U.get("voll_eth")); konsol = _zahl(U.get("konsol_eth"))
    durch = float(_zahl(U.get("durchsatz_tag_eth")) or 57_600.0)
    schwelle = float(_zahl(U.get("schwelle_tag_eth")) or durch / 2)
    K = [k for k in (U.get("kalender") or []) if isinstance(k, (list, tuple)) and len(k) == 3]
    for t, v, p in K[:UNSTAKING_TAGE]:
        e = float(v or 0.0) + float(p or 0.0)
        out["tage"].append({"ts": int(t), "tag": _tag_utc(t), "eth": round(e, 3), "teil": round(float(p or 0.0), 3),
                            "anteil": max(0.0, min(1.0, e / durch)), "gross": e >= schwelle})
    rest = K[UNSTAKING_TAGE:]
    out["tage_mehr"] = len(rest)
    out["tage_mehr_eth"] = round(sum(float(k[1] or 0.0) + float(k[2] or 0.0) for k in rest), 3)
    g = U.get("gross")
    if isinstance(g, dict) and _zahl(g.get("eth")) is not None and g.get("von_ts") is not None and g.get("bis_ts") is not None:
        out["gross"] = {"von_ts": int(g["von_ts"]), "bis_ts": int(g["bis_ts"]), "von": _tag_utc(g["von_ts"]), "bis": _tag_utc(g["bis_ts"]),
                        "tage": g.get("tage"), "eth": float(g["eth"]), "usd": usd(float(g["eth"]))}
        out["satz"] = ("Nächste große Freigabe: " + out["gross"]["von"]
                       + (f" bis {out['gross']['bis']}" if int(g["bis_ts"]) != int(g["von_ts"]) else "") + f" · {_eth(g['eth'])} ETH"
                       + (f" (≈ {_usd(usd(float(g['eth'])))})" if px is not None else "") + ".")
    else:
        out["satz"] = f"Keine große Freigabe angemeldet: kein Tag ab {_eth(schwelle)} ETH."
    for a in (U.get("adressen") or [])[:3]:
        e = _zahl(a.get("eth")); adr = str(a.get("adresse") or "")
        if e is None or a.get("von_ts") is None or a.get("bis_ts") is None:
            continue
        out["abzieher"].append({"adresse": adr, "kurz": (adr[:6] + "…" + adr[-4:]) if len(adr) > 12 else adr, "eth": e,
                                "anteil": (e / voll if voll else None), "von_ts": int(a["von_ts"]), "bis_ts": int(a["bis_ts"]),
                                "von": _tag_utc(a["von_ts"]), "bis": _tag_utc(a["bis_ts"])})
    E = U.get("eintritt") or {}
    lt = _zahl(U.get("lauf_tage"))
    out.update({"summe_eth": summe, "voll_eth": voll, "teil_eth": _zahl(U.get("teil_eth")), "konsol_eth": konsol, "usd": usd(summe),
                "usd_text": _usd(usd(summe)) if usd(summe) is not None else None, "ende_ts": U.get("ende_ts"),
                "schlange_ende_ts": U.get("schlange_ende_ts"), "durchsatz": durch, "schwelle": schwelle, "lauf_tage": lt,
                "eintritt_eth": _zahl(E.get("eth")), "eintritt_tag": E.get("tag")})
    # 23.102: Die Tagesdatei der Quelle kann stehenbleiben (seit 25.10.2026). Dann fehlt die Gegenseite -- die Karte sagt es; die Dauer
    # des Auszahlungslaufs bleibt brauchbar (die Zahl der Validatoren ändert sich langsam), nennt aber den Tag ihrer Zahl.
    td = U.get("tagesdatei") if isinstance(U.get("tagesdatei"), dict) else {}
    td_tag = _iso_datum(td.get("tag")) if td.get("frisch") is False else None
    out["auszahlung"] = ("„Frei ab“ heißt: Von da an darf die Kette auszahlen. Teilabzüge kommen dann sofort, Vollabzüge "
                         + (f"binnen bis zu {_de(lt, 1)} Tagen danach" + (f" (Zahl der Validatoren vom {td_tag})" if td_tag else "") + "."
                            if lt else "mit dem Auszahlungslauf danach.")
                         + f" Je Tag verlassen höchstens {_eth(durch)} ETH das Staking.")
    tg = str(E.get("tag") or "")
    tg = f"{tg[8:10]}.{tg[5:7]}." if len(tg) == 10 and tg[4] == "-" and tg[7] == "-" else tg
    out["gegenseite"] = (f"Gegenseite: {_eth(E.get('eth'))} ETH warten darauf, gestakt zu werden (Tagesstand {tg})."
                         if _zahl(E.get("eth")) is not None else
                         (f"Gegenseite (ETH, das auf das Staking wartet): zurzeit kein Wert, weil die Tagesdatei der Quelle am {td_tag} endet."
                          if td_tag else None))
    out["nicht_gezaehlt"] = (f"Nicht mitgezählt: {_eth(konsol)} ETH in Zusammenlegungen -- sie bleiben gestakt." if konsol and konsol >= 1 else None)
    return out


def _pz_log(x, nd: int = 1) -> str | None:
    """Log-Rendite als Prozentzahl mit Vorzeichen, ohne das Zeichen % -- so, wie Debug 147 sie je Welle zeigt. None -> None."""
    v = _zahl(x)
    if v is None:
        return None
    t = f"{abs(v * 100.0):.{nd}f}"
    if float(t) == 0:
        return t.replace(".", ",")
    return ("+" if v > 0 else "−") + t.replace(".", ",")


def _tag_nr_iso(t) -> int | None:
    """„2026-10-25“ -> Tagesnummer (Tage seit 01.01.1970, UTC); alles andere -> None."""
    try:
        return calendar.timegm(time.strptime(str(t), "%Y-%m-%d")) // TAG
    except (ValueError, OverflowError):
        return None


def _spanne_de(a: int, b: int) -> str:
    """Zwei Tagesnummern als Zeitraum: „26.10.–14.11.2026“, über einen Jahreswechsel mit beiden Jahren, ein einzelner Tag allein."""
    ta, tb = time.gmtime(int(a) * TAG), time.gmtime(int(b) * TAG)
    if int(a) == int(b):
        return time.strftime("%d.%m.%Y", tb)
    return (time.strftime("%d.%m.", ta) if ta.tm_year == tb.tm_year else time.strftime("%d.%m.%Y", ta)) + "–" + time.strftime("%d.%m.%Y", tb)


def verlauf_bauen(V: dict | None, jetzt: int) -> dict:
    """
    23.104 (U260), Klasse B (gemessen): Antwort für die Karte „Unstaking · Verlauf“ aus den Reihen von hl_staking_studie.verlauf --
    je UTC-Tag die Schlange der Abzüge (q: Tagesdatei; k: eigene Messung am Knoten) und der ETH-Kurs (px), die Wellen des
    gespeicherten Urteils mit fertigem Text, die Zeiträume ohne Daten, die wählbaren Ausschnitte und die Sätze unter dem Bild.
    Gerechnet wird nichts außer der Lage (Index des Tages ab d0), Rundung und Lücken. Keine Farbe, kein Urteil; was fehlt, steht in
    „fehlt“. Die Renditen je Welle sind die des Urteils (Log-Renditen in %, wie in Debug 147).
    """
    out = {"ok": False, "jetzt": int(jetzt), "version": VERSION_MODUL, "fehlt": [], "hinweise": []}
    if not isinstance(V, dict) or not V.get("ok"):
        out["fehlt"] = list((V or {}).get("fehlt") or ["Verlauf: keine Daten."])
        return out
    d0, d1 = int(V["von_D"]), int(V["bis_D"])
    n = d1 - d0 + 1
    if n < 2:
        out["fehlt"] = ["Der Verlauf braucht mindestens zwei Tage."]
        return out
    q: list = [None] * n
    px: list = [None] * n
    for D, v in (V.get("tagesdatei") or {}).items():
        w = _zahl(v)
        if w is not None and d0 <= int(D) <= d1:
            q[int(D) - d0] = int(round(w))
    for D, v in (V.get("kurs") or {}).items():
        w = _zahl(v)
        if w is not None and w > 0 and d0 <= int(D) <= d1:
            px[int(D) - d0] = round(w, 2)
    KN = {int(D): int(round(w)) for D, w in ((D, _zahl(v)) for D, v in (V.get("knoten") or {}).items()) if w is not None and d0 <= int(D) <= d1}
    k = None
    if KN:
        k = {"ab": min(KN) - d0, "w": [KN.get(D) for D in range(min(KN), max(KN) + 1)]}
    hat = [q[i] is not None or (d0 + i) in KN for i in range(n)]
    if not any(hat):
        out["fehlt"] = ["Der Verlauf hat keinen Tag mit einer Schlange."]
        return out
    luecken = []
    i = 0
    while i < n:                                                          # Folgen von Tagen ohne Schlange; ab VERLAUF_LUECKE_TAGE eine Lücke
        if hat[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and not hat[j + 1]:
            j += 1
        if j - i + 1 >= VERLAUF_LUECKE_TAGE:
            luecken.append([i, j])
        i = j + 1
    aus = [_tag_nr_iso(t) for t in (V.get("ausgeschlossen") or [])][:2]
    luecken_text = [_spanne_de(d0 + a, d0 + b)
                    + (" (laut Quelle falsche Einheit)" if len(aus) == 2 and None not in aus and aus[0] <= d0 + a and d0 + b <= aus[1] else "")
                    for a, b in luecken]
    hz = int(_zahl(V.get("horizont")) or 7)
    wellen = []
    for w in V.get("wellen") or []:
        a = _zahl((w or {}).get("a"))
        if a is None or not d0 <= int(a) <= d1:
            continue                                                      # eine Welle außerhalb der Reihe hätte im Bild keinen Ort
        zu, sch = _zahl(w.get("zuwachs")), _zahl(w.get("schlange"))
        e7, y7 = _pz_log(w.get("a_eth7")), _pz_log(w.get("a_y7"))
        nr = str(w.get("nr")) if w.get("nr") is not None else "—"
        text = (f"Welle {nr}, gemessen am {_tag_datum(a)}: Schlange gegen den Vortag "
                + (f"+{_eth(zu)} ETH" if zu is not None else "gewachsen") + (f" (auf {_eth(sch)} ETH)" if sch is not None else "") + ". "
                + (f"ETH in den {hz} Tagen danach {e7} %, gegen BTC {y7} %." if e7 is not None and y7 is not None else
                   (f"Das Fenster von {hz} Tagen war bei der Prüfung noch offen." if w.get("a_stand") == "offen" else
                    f"Für die {hz} Tage danach fehlt der Kurs.")))
        wellen.append({"nr": nr, "i": int(a) - d0, "tag": _tag_datum(a), "zuwachs": zu, "text": text,
                       "zeile": [nr, _tag_datum(a), ("+" + _eth(zu)) if zu is not None else "—", e7 or "·", y7 or "·"]})
    U = V.get("urteil") if isinstance(V.get("urteil"), dict) else None
    schwelle = _zahl(V.get("schwelle_eth")); ruhe = _zahl(V.get("ruhe_tage"))
    if U is None:
        satz = "Wellen sind noch nicht markiert: Die Prüfung der Kursfolge ist noch nicht gerechnet (Debug 147 rechnet sie einmal)."
    else:
        tag = time.strftime("%d.%m.%Y", time.gmtime(int(U["ts"]))) if _zahl(U.get("ts")) is not None else "—"
        if not wellen:
            satz = f"Die Prüfung vom {tag} nennt in diesen Daten keine Welle."
        else:
            satz = (f"Markiert sind die {len(wellen)} Wellen der Prüfung vom {tag}: Tage, zu deren Beginn die Schlange gegen den Vortag um "
                    f"mindestens {_eth(schwelle)} ETH gewachsen war"
                    + (f" (eine neue Welle zählt erst nach {int(ruhe)} ruhigen Tagen)" if ruhe is not None else "") + ".")
            A = U.get("A") if isinstance(U.get("A"), dict) else {}
            m, alle = _pz_log(A.get("mittel"), 2), _pz_log(U.get("alle_y7"), 2)
            if m is not None and alle is not None and A.get("n"):
                satz += (f" In den {hz} Tagen danach lag ETH gegen BTC im Mittel bei {m} %"
                         + (f" ({int(A['n'])} Wellen gewertet)" if int(A["n"]) != len(wellen) else "") + f", über alle Tage bei {alle} %.")
                if U.get("urteil") == "kein Urteil":
                    satz += " Die Prüfung gab dazu kein gültiges Urteil."
                elif A.get("urteil") in ("belegt", "nicht belegt"):
                    satz += (f" Der Unterschied ist {A['urteil']}" + (f" (p nach Holm {_p(A.get('p_holm'))})" if _zahl(A.get("p_holm")) is not None else "") + ".")
                else:
                    satz += " Für ein Urteil sind es zu wenige Fälle."
        if U.get("aktuell") is False:
            satz += " Das Urteil stammt aus einer älteren Fassung der Regeln."
    # 23.106 (U259): zweite Prüfung (U255/2) -- neue Wellen der eigenen Messung mit Marke und Text, ohne Kursfolge; dazu ihr Zähler
    N = V.get("neu") if isinstance(V.get("neu"), dict) else None
    angemeldet = V.get("knoten_art") == "angemeldet"
    n_alt = len(wellen)
    if N is not None:
        noetig = int(_zahl(N.get("noetig")) or 0)
        for w in N.get("faelle") or []:
            a = _zahl((w or {}).get("a"))
            if a is None or int(a) < d0 or int(a) > d1:               # außerhalb der Reihe: kein Ort im Bild
                continue
            zu, sm = _zahl(w.get("zuwachs")), _zahl(w.get("angemeldet"))
            nr = "N" + (str(w.get("nr")) if w.get("nr") is not None else "")
            text = (f"Neue Welle {w.get('nr') if w.get('nr') is not None else '—'}" + (f" von {noetig}" if noetig else "")
                    + f" für die zweite Prüfung, gemessen am {_tag_datum(a)}: angemeldete Abzüge gegen den Vortag "
                    + (f"+{_eth(zu)} ETH" if zu is not None else "gewachsen") + (f" (auf {_eth(sm)} ETH)" if sm is not None else "")
                    + ". Ihre Kursfolge steht erst mit dem Urteil der zweiten Prüfung hier.")
            wellen.append({"neu": True, "nr": nr, "i": int(a) - d0, "tag": _tag_datum(a), "zuwachs": zu, "text": text,
                           "zeile": [nr, _tag_datum(a), ("+" + _eth(zu)) if zu is not None else "—", "·", "·"]})
        satz += (f" Zweite Prüfung, vorab festgelegt am {N.get('festgelegt') or '—'}: Sie zählt nur neue Wellen der eigenen Messung und wird "
                 f"einmal gerechnet, sobald {noetig} davon bewertet sind -- bisher {int(_zahl(N.get('erkannt')) or 0)}.")
        if N.get("faellig"):
            satz += " Sie ist fällig; ihre Rechnung steht noch aus."
        elif _zahl(N.get("frei_ab_D")) is not None:
            satz += f" Eine neue Welle kann frühestens am {_tag_datum(N['frei_ab_D'])} beginnen."
        if len(wellen) > n_alt:
            satz += " Neue Wellen tragen einen offenen Kreis; ihre Kursfolge steht erst mit dem Urteil der zweiten Prüfung hier."
    td = V.get("td") if isinstance(V.get("td"), dict) else None
    kn = V.get("kn") if isinstance(V.get("kn"), dict) else None
    teile = []
    if td and any(v is not None for v in q):
        teile.append(f"Schlange bis {_iso_datum(td.get('bis')) or '—'}: Tagesdatei von validatorqueue.com"
                     + (" (ob sie seit Mai 2025 Zusammenlegungen mitzählt, ist offen)" if str(td.get("bis") or "") >= str(V.get("pectra_ab") or "9") else "")
                     + ".")
    if kn and k is not None and angemeldet:                               # 23.106: Summe statt Schlange (auch nach EIP-8061 aussagekräftig)
        teile.append(f"Ab {_iso_datum(kn.get('von')) or '—'}: eigene Messung am Knoten -- angemeldete Abzüge, die noch nicht frei sind "
                     "(Schlange, Sperrfrist und Teilabzüge; ohne Zusammenlegungen). Das ist mehr als die Schlange allein.")
    elif kn and k is not None:
        teile.append(f"Ab {_iso_datum(kn.get('von')) or '—'}: eigene Messung am Knoten (Vollabzüge in der Schlange, ohne Sperrfrist und ohne "
                     "Zusammenlegungen).")
    teile.append("Je UTC-Tag die erste Messung.")
    if luecken_text:
        teile.append("Grau = keine Daten: " + ", ".join(luecken_text[:4])
                     + (f" und {len(luecken_text) - 4} weitere" if len(luecken_text) > 4 else "") + ".")
    if any(v is not None for v in px):
        teile.append("Kurs: ETH zu Beginn des UTC-Tags (30-min-Kerzen der Binance-Perpetuals).")
    teile.append("Gemessen, keine Vorhersage: Der Verlauf allein belegt keinen Zusammenhang.")
    achse_q = "Schlange der Abzüge in ETH"
    if angemeldet and k is not None:
        achse_q = (f"Abzüge in ETH: bis {_iso_datum((td or {}).get('bis')) or '—'} Schlange, ab {_tag_datum(min(KN))} angemeldet"
                   if any(v is not None for v in q) else "Angemeldete Abzüge in ETH, noch nicht frei")
    bereiche = [{"key": key, "name": name, "tage": tage} for key, name, tage in VERLAUF_BEREICHE if tage < n]
    bereiche.append({"key": "alles", "name": "alles", "tage": n})
    letzter = max(i for i in range(n) if hat[i])
    out.update({"ok": True, "d0": d0, "n": n, "q": q, "k": k, "px": px, "wellen": wellen, "luecken": luecken, "luecken_text": luecken_text,
                "luecke_tage": VERLAUF_LUECKE_TAGE, "bereiche": bereiche,
                "start": VERLAUF_START if any(b["key"] == VERLAUF_START for b in bereiche) else "alles",
                "titel": VERLAUF_TITEL, "achse_q": achse_q, "achse_px": "ETH-Kurs in USD, zu Beginn jedes UTC-Tags",
                "satz": satz, "quellen": " ".join(teile),
                "liste_kopf": ["Nr.", "gemessen am", "Zuwachs ETH", f"ETH {hz} T", "gegen BTC"],
                "liste_hinweis": (f"ETH {hz} T = Kurs von ETH in den {hz} Tagen ab dem Tag der Messung, in %; gegen BTC = dasselbe abzüglich "
                                  "BTC (die Zielgröße der Prüfung). Dieselben Zahlen wie in Debug 147."
                                  + (" N = neue Welle der eigenen Messung; ihre Kursfolge steht erst mit dem Urteil der zweiten Prüfung hier."
                                     if len(wellen) > n_alt else "")),
                "von": _tag_datum(d0), "bis": _tag_datum(d1), "td_bis": _iso_datum((td or {}).get("bis")) if any(v is not None for v in q) else None,
                "kn_von": _tag_datum(min(KN)) if KN else None, "tage_q": sum(1 for v in q if v is not None), "tage_k": len(KN),
                "tage_px": sum(1 for v in px if v is not None), "letzter": letzter, "hinweise": list(V.get("hinweise") or [])})
    out.update({"k_name": "Angemeldet" if angemeldet and k is not None else None, "wellen_alt": n_alt, "wellen_neu": len(wellen) - n_alt,
                "neu": ({"regel": N.get("regel"), "noetig": int(_zahl(N.get("noetig")) or 0), "erkannt": int(_zahl(N.get("erkannt")) or 0),
                         "faellig": bool(N.get("faellig"))} if N is not None else None)})
    return out


def verlauf_nutzlast(db: str, jetzt: int | None = None) -> dict:
    """Antwort für /cockpit/unstaking (23.104, U260): die Karte „Unstaking · Verlauf“. Immer eine Antwort mit Grund, nie ein Fehler."""
    jetzt = int(jetzt or time.time())
    t0 = time.time()
    try:
        import hl_staking_studie as SS
        V = SS.verlauf(db, jetzt)
    except Exception as e:
        return {"ok": False, "jetzt": jetzt, "version": VERSION_MODUL, "fehlt": [f"Verlauf: {type(e).__name__}: {e}"[:200]], "hinweise": []}
    out = verlauf_bauen(V, jetzt)
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return _ohne_nan(out)


def verlauf_json(db: str, jetzt: int | None = None) -> bytes:
    """/cockpit/unstaking: gültiges JSON ohne NaN; die Reihen ohne Leerzeichen (rund 1.300 Tage)."""
    try:
        return json.dumps(verlauf_nutzlast(db, jetzt), ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()
    except Exception as e:
        return json.dumps({"ok": False, "version": VERSION_MODUL, "fehlt": [f"Verlauf: {type(e).__name__}: {e}"[:300]], "hinweise": []},
                          ensure_ascii=False).encode()


def verlauf_text(B: dict) -> list:
    """Zeilen für Debug 143: was die Karte „Unstaking · Verlauf“ zeigt -- Umfang der Reihen, Zeiträume ohne Daten, letzter Tag, Wellen."""
    if not B.get("ok"):
        return ["   Unstaking Verlauf: kein Wert -- " + " ".join(B.get("fehlt") or ["Grund unbekannt"])]
    start = next((b["name"] for b in B["bereiche"] if b["key"] == B["start"]), "—")
    Z = [f"   Unstaking Verlauf (Karte „Unstaking · Verlauf“): {_eth(B['n'])} Tage vom {B['von']} bis {B['bis']} · Schlange aus der Tagesdatei "
         f"an {_eth(B['tage_q'])} Tagen" + (f" (bis {B['td_bis']})" if B.get("td_bis") else "") + f" · eigene Messung an {_eth(B['tage_k'])} "
         + ("Tag" if B["tage_k"] == 1 else "Tagen")
         + (f" (ab {B['kn_von']})" if B.get("kn_von") else "") + f" · ETH-Kurs an {_eth(B['tage_px'])} Tagen · {B.get('wellen_alt', len(B['wellen']))} Wellen markiert"
         + (f" und {B['wellen_neu']} neue" if B.get("wellen_neu") else "") +
         f" · Ausschnitt beim Öffnen: {start}"]
    if B["luecken_text"]:
        Z.append("   Unstaking Verlauf, keine Daten: " + ", ".join(B["luecken_text"]))
    i = B["letzter"]
    eigen = B["q"][i] is None
    wert = B["k"]["w"][i - B["k"]["ab"]] if eigen else B["q"][i]
    summe = eigen and bool(B.get("k_name"))                               # 23.106: die eigene Messung ist die Summe „angemeldet“
    Z.append(f"   Unstaking Verlauf, letzter Tag mit {'Wert' if summe else 'Schlange'}: {_tag_datum(B['d0'] + i)} · {_eth(wert)} ETH "
             f"({('eigene Messung: angemeldet, noch nicht frei' if summe else 'eigene Messung') if eigen else 'Tagesdatei'}) · "
             f"ETH-Kurs {(_px(B['px'][i]) + ' USD') if B['px'][i] is not None else 'kein Wert'}")
    Z.append("   Unstaking Verlauf: " + B["satz"])
    for h in B["hinweise"]:
        Z.append("   Unstaking Verlauf, Hinweis: " + h)
    return Z


# ================================================================================================ Kurs-Rechner (23.105, U245 Stufe C2)

def rechner_kopf() -> dict:
    """Feste Angaben der Karte „Kurs-Rechner“ für das Skript: Fristen, Namen der gemerkten Kurse, Grenzen -- eine Quelle für Seite
    und Selbsttest."""
    return {"fristen": [[f[0], f[1], f[2]] for f in RECHNER_FRISTEN], "arten": [list(a) for a in RECHNER_ARTEN], "merken": RECHNER_MERKEN,
            "max": RECHNER_MAX_KURSE, "faktor": RECHNER_FAKTOR, "beleg": RECHNER_BELEG_KOPF,
            "hinweis": "Der Rechner zeigt, wie wahrscheinlich ein Kurs vom jetzigen Kurs aus berührt wird.",
            "merk_kurz": "Merken als (bleibt in diesem Browser)",
            "merk_hinweis": "Gemerkte Kurse bleiben in diesem Browser. Zum Rechnen gehen sie an dein Dashboard; dort werden sie nicht gespeichert."}


def _rechner_p_text(p, lage: str = "innen") -> str:
    """Wahrscheinlichkeit als Text in ganzen Prozent, kaufmännisch gerundet. Unter 0,5 % (oder nur als Schranke bekannt) „unter 1 %“,
    ab 99,5 % „über 99 %“ -- 0 % und 100 % stehen nie da."""
    v = _zahl(p)
    if v is None or lage == "fehlt":
        return "—"
    if lage == "unter" or v < 0.005:
        return "unter 1 %"
    if lage == "ueber" or v >= 0.995:
        return "über 99 %"
    return f"{max(1, min(99, int(math.floor(v * 100.0 + 0.5))))} %"


def _rechner_stellen(abstand) -> int:
    """Nachkommastellen des Abstands: zwei, solange er auf zwei Stellen gerundet unter 1 % bleibt („0,40 %“ … „0,99 %“), sonst eine
    („1,0 %“) -- „1,00 %“ steht nie da."""
    return 2 if abs(float(abstand)) < 0.00995 else 1


def _rechner_liste(namen: list) -> str:
    """„1 h“, „1 h und 4 h“, „1 h, 4 h und 7 Tage“."""
    n = [str(x) for x in namen]
    return n[0] if len(n) == 1 else ", ".join(n[:-1]) + " und " + n[-1] if n else ""


def _rechner_s3_text(s3: dict | None) -> str:
    teile = []
    for h in ("7", "14"):
        e = (s3 or {}).get(h) or {}
        if _zahl(e.get("skill")) is not None and _zahl(e.get("steigung")) is not None:
            teile.append(f"über {h} Tage Brier-Skill {_pc(e.get('skill'), 1, True)}, Steigung {_de(e.get('steigung'), 2)} "
                         f"({'besteht' if e.get('besteht') else 'besteht nicht'})")
    if not teile:
        return "Der Rückblick des Ausblicks steht noch aus -- diese Wahrscheinlichkeiten sind noch nicht geprüft."
    return "Im Rückblick über alle Coins zusammen geprüft (S3): " + "; ".join(teile) + "."


def rechner_bauen(G: dict, kurse) -> dict:
    """
    Reine Rechnung aus der Grundlage G (rechner_grundlage) für eine Liste von Kursen. Je Kurs und Frist die Wahrscheinlichkeit, dass er
    vom JETZIGEN Kurs aus berührt wird:
      1 h, 4 h     Nullmodell des Magnet-Tests (U110): hl_kaskade.p_ueber(|ln(Kurs/jetzt)|, c, σ₄ₕ·√(h/4), τ) -- c und τ je Coin und Frist
      7, 14 Tage   Verteilung des laufenden Hochs (Kurs darüber) oder Tiefs (Kurs darunter) aus der jüngsten Rechnung des Ausblicks
                   (hl_ausblick.erreichen_aus_lauf), angelegt am jetzigen Kurs
    Eine längere Frist kann nie unwahrscheinlicher sein als eine kürzere: Wo die Modelle das verletzen, gilt der Wert der kürzeren
    Frist -- mit Vermerk, sobald sich die gezeigte Zahl dadurch ändert. Der jetzige Kurs selbst ist erreicht. Nichts wird geschätzt: Was nicht rechenbar ist, bleibt leer und
    nennt den Grund. Vermerke je Kurs, wo er außerhalb des geprüften Bereichs liegt.
    """
    import hl_ausblick as AU
    import hl_kaskade as KK
    coin = str(G.get("coin") or ""); jetzt = int(G.get("jetzt") or 0)
    P = _zahl(G.get("kurs")); frisch = bool(G.get("kurs_frisch")) and P is not None and P > 0
    sig4 = _zahl(G.get("sig4")); sig4 = sig4 if sig4 and sig4 > 0 else None
    kurz = G.get("kurz") or {}; lauf = G.get("lauf") or None
    sig_max = float(G.get("sigma_geprueft") or RECHNER_SIGMA_GEPRUEFT)
    n_f = len(RECHNER_FRISTEN)
    bereit = [bool(frisch and (kurz.get(f[0]) and sig4 if f[5] == "h" else lauf and ((lauf.get("h") or {}).get(str(f[4]))))) for f in RECHNER_FRISTEN]
    out = {"ok": True, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL, "kurs": P, "kurs_ts": G.get("kurs_ts"), "kurs_frisch": frisch,
           "fristen": [[f[0], f[1], f[2], b] for f, b in zip(RECHNER_FRISTEN, bereit)], "zeilen": [], "beleg_kurz": "", "belege": [],
           "beleg_allg": "", "hinweise": [], "fehlt": []}
    note_sigma = RECHNER_NOTE_SIGMA.format(x=f"{sig_max:g}".replace(".", ","))
    note_abstand = RECHNER_NOTE_ABSTAND.format(x=int(round(RECHNER_ABSTAND_GEPRUEFT * 100)))
    alle = list(kurse or [])
    if len(alle) > RECHNER_MAX_KURSE:
        out["hinweise"].append(f"Gerechnet sind die ersten {RECHNER_MAX_KURSE} von {len(alle)} Kursen der Anfrage.")
    for x in alle[:RECHNER_MAX_KURSE]:
        z = {"px": None, "px_text": "—", "ok": False, "grund": None, "abstand": None, "abstand_text": "", "lage": "", "p": [None] * n_f,
             "p_text": ["—"] * n_f, "hinweise": [], "satz": ""}
        out["zeilen"].append(z)
        L = _zahl(x)
        if L is None or L <= 0:
            z["grund"] = "Kein gültiger Kurs."; continue
        z["px"] = L; z["px_text"] = _px(L)
        if not frisch:
            z["grund"] = "Kein frischer Kurs."; continue
        if not (P / RECHNER_FAKTOR <= L <= P * RECHNER_FAKTOR):
            z["grund"] = f"Außerhalb des Bereichs des Rechners ({_px(P / RECHNER_FAKTOR)} bis {_px(P * RECHNER_FAKTOR)})."; continue
        d = math.log(L / P); gleich = abs(d) < 1e-12
        z["ok"] = True; z["abstand"] = 0.0 if gleich else L / P - 1.0
        z["lage"] = "der jetzige Kurs" if gleich else ("über dem Kurs" if d > 0 else "unter dem Kurs")
        z["abstand_text"] = "" if gleich else _pc(abs(z["abstand"]), _rechner_stellen(z["abstand"]))
        roh = [None] * n_f; lagen = ["fehlt"] * n_f; noten: dict = {}
        for i, (key, name, kz, satzteil, zahl, einheit) in enumerate(RECHNER_FRISTEN):
            if not bereit[i]:
                continue
            if gleich:
                roh[i], lagen[i] = 1.0, "innen"
            elif einheit == "h":
                m = kurz[key]; sig_h = sig4 * math.sqrt(zahl / 4.0)
                roh[i], lagen[i] = float(KK.p_ueber(abs(d), float(m["c"]), sig_h, float(m["tau"]))), "innen"
                if abs(d) > sig_max * sig_h:
                    noten.setdefault(note_sigma, []).append(kz)
            else:
                p, lage = AU.erreichen_aus_lauf(lauf["h"], d, zahl)
                if lage != "fehlt" and _zahl(p) is not None:
                    roh[i], lagen[i] = float(p), lage
                    if abs(z["abstand"]) > RECHNER_ABSTAND_GEPRUEFT + 1e-9:        # die Grenze selbst zählt noch als geprüft
                        noten.setdefault(note_abstand, []).append(kz)
        bisher = None; lage_bisher = "innen"                             # eine längere Frist ist nie unwahrscheinlicher als eine kürzere
        for i in range(n_f):
            if roh[i] is None:
                continue
            if bisher is not None and roh[i] < bisher - 1e-12:
                if _rechner_p_text(roh[i], lagen[i]) != _rechner_p_text(bisher, lage_bisher):       # Vermerk nur, wenn sich die gezeigte Zahl ändert
                    noten.setdefault(RECHNER_NOTE_MONOTON, []).append(RECHNER_FRISTEN[i][2])
                roh[i], lagen[i] = bisher, lage_bisher
            else:
                bisher, lage_bisher = roh[i], lagen[i]
        z["p"] = roh
        z["p_text"] = ["erreicht" if gleich and roh[i] is not None else _rechner_p_text(roh[i], lagen[i]) for i in range(n_f)]
        z["hinweise"] = [f"{_rechner_liste(namen)}: {note}." for note, namen in noten.items()]
        teile = [f"{f[3]} {t}" for f, t, p in zip(RECHNER_FRISTEN, z["p_text"], roh) if p is not None]
        if gleich:
            z["satz"] = f"{z['px_text']} ist der jetzige Kurs."
        else:
            z["satz"] = (f"{z['px_text']} liegt {z['abstand_text']} {z['lage']}. "
                         + ("Wahrscheinlichkeit, dass der Kurs berührt wird: " + ", ".join(teile) + "." if teile else "Keine Frist ist rechenbar."))
    # Gründe für fehlende Fristen
    if not frisch:
        out["fehlt"].append((f"Kein Kurs für {coin}" if P is None else f"Der Kurs ist nicht frisch (Stand {_datum(G.get('kurs_ts'))})")
                            + " -- der Rechner rechnet nur vom jetzigen Kurs.")
    else:
        gruende: dict = {}
        for f, b in zip(RECHNER_FRISTEN, bereit):
            if b:
                continue
            if f[5] == "h":
                g = ((G.get("kurz_fehlt") or {}).get(f[0]) if not kurz.get(f[0]) else None) or G.get("sig4_fehlt") or "kein Wert."
            else:
                g = G.get("lauf_fehlt") or "kein Wert."
            gruende.setdefault(str(g), []).append(f[1])
        out["fehlt"] += [f"{_rechner_liste(namen)}: {g}" for g, namen in gruende.items()]
    # Belege
    stunden = [(f, kurz[f[0]]) for f, b in zip(RECHNER_FRISTEN, bereit) if b and f[5] == "h"]
    if stunden:
        m0 = stunden[0][1]
        probe = ", ".join(f"über {f[2]} {m['zufall_ok']} von {m['zufall_n']}" for f, m in stunden if m.get("zufall_n"))
        out["belege"].append(
            f"{_rechner_liste([f[1] for f, _m in stunden])}: Nullmodell des Magnet-Tests (U110) mit der Schwankung der letzten 7 Tage "
            f"(über 4 Stunden {_pc(sig4, 2)}). "
            + (f"An Zufallsniveaus geprüft -- innerhalb von 2 Standardfehlern lagen {probe} Abständen" if probe else "Die Probe an Zufallsniveaus fehlt")
            + (f" ({_de(m0.get('tage'), 0)} Tage, Rechnung vom {_datum(m0.get('ts'))})." if _zahl(m0.get("tage")) is not None else "."))
        for f, m in stunden:
            if not m.get("zufall_n"):
                out["hinweise"].append(f"Über {f[1]} fehlt für {coin} die Probe des Nullmodells an Zufallsniveaus.")
            elif m["zufall_n"] - m["zufall_ok"] > RECHNER_ZUFALL_FEHLER:
                out["hinweise"].append(f"Über {f[1]} ist das Nullmodell für {coin} ungenauer: nur {m['zufall_ok']} von {m['zufall_n']} Abständen "
                                       "innerhalb von 2 Standardfehlern.")
    tage = [f for f, b in zip(RECHNER_FRISTEN, bereit) if b and f[5] == "d"]
    if tage:
        out["belege"].append(f"{_rechner_liste([f[1] for f in tage])}: Verteilung aus der Rechnung des Ausblicks vom {_datum(lauf.get('anker'))}, "
                             f"angelegt am jetzigen Kurs. {_rechner_s3_text(G.get('s3'))}")
    # Trefferquote des 80-%-Bands für DIESEN Coin (Rückblick S1; die Prüfung S3 der Erreich-Wahrscheinlichkeiten läuft nur über alle
    # Coins zusammen): außerhalb von 80 % ± 2 Standardfehler steht bei den Tagen ein Hinweis mit der Folge. Die Zahlen bleiben, wie sie sind.
    for wort, folge in RECHNER_BAND_FOLGE.items():
        tr = [(f, (G.get("deckung") or {}).get(str(f[4])) or {}) for f in tage]
        tr = [(f, d_) for f, d_ in tr if deckung_zusatz(d_, kurz=True) == f" ({wort})"]
        if tr:
            out["hinweise"].append(f"{_rechner_liste([f[1] for f, _d in tr])}: "
                                   + RECHNER_NOTE_BAND.format(coin=coin, wort=wort, folge=folge,
                                                              x=_rechner_liste([_de(_zahl(d_.get("d80")) * 100, 0) + " %" for _f, d_ in tr])) + ".")
    out["beleg_allg"] = (RECHNER_BELEG_ALLG + f" Geprüft sind Abstände bis {f'{sig_max:g}'.replace('.', ',')} übliche Schwankungen der Frist "
                         f"(σ, bei den Stunden) und bis {int(round(RECHNER_ABSTAND_GEPRUEFT * 100))} % (bei den Tagen).")
    # Kurzfassung des Belegs: steht immer unter den Zahlen
    kurz_b = []
    if stunden:
        probe_k = ", ".join(f"{f[2]} {m['zufall_ok']} von {m['zufall_n']}" for f, m in stunden if m.get("zufall_n"))
        kurz_b.append(f"Stunden: Nullmodell an Zufallsniveaus geprüft ({probe_k} innerhalb von 2 Standardfehlern)." if probe_k
                      else "Stunden: Nullmodell ohne Probe an Zufallsniveaus.")
    if tage:
        s3 = G.get("s3") or {}
        s3_k = [f"{f[1]} {'besteht' if (s3.get(str(f[4])) or {}).get('besteht') else 'besteht nicht'}" for f in tage
                if _zahl((s3.get(str(f[4])) or {}).get("skill")) is not None]
        kurz_b.append(f"Tage: im Rückblick über alle Coins geprüft ({', '.join(s3_k)})." if s3_k else "Tage: noch nicht geprüft (der Rückblick steht aus).")
    out["beleg_kurz"] = " ".join(kurz_b + [RECHNER_BELEG_SCHLUSS])
    return out


def satz_bauen(coin: str, spanne: dict, ausnahme_text: str = "") -> dict:
    """Kernsatz aus der 7-Tage-Spanne; ohne Richtung."""
    e = (spanne.get("h") or {}).get("7")
    if e:
        q = e["q"]
        text = f"In 7 Tagen liegt {coin} mit 80 % zwischen {_px(q[1])} und {_px(q[5])}."
        if e.get("treffer") is not None:                                 # wie hl_ausblick: „Im Rückblick traf das 80-%-Band 84 % -- zu weit“
            text += (f" Im Rückblick traf dieses Band {_de(e['treffer'] * 100, 0)} %"
                     + deckung_zusatz({"d80": e["treffer"], "ok": e.get("deckung_ok")}) + ".")
    else:
        text = f"Für {coin} liegt noch keine Spanne aus dem Ausblick vor."
    if e and not spanne.get("frisch"):
        text += " Der Stand ist älter als 2 Tage."
    return {"text": text, "zusatz": SATZ_RICHTUNG, "ausnahme": ausnahme_text or None}


def bauen(Q: dict) -> dict:
    """
    Reine Zusammenstellung aus den gelesenen Quellen Q (siehe quellen_lesen): coin, jetzt, kurs {px, ts}, ausblick {prognose,
    rueckblick, fehlt}, ausnahme, ausnahme_dauer, ausnahme_text, aktien_pruefung, vol, kosten, termine, naechste, datentag_stand,
    termine_geladen, lage, funding, konten_schwelle, konten_beleg, wochenende_faktor; seit 23.108 funding_hl, taker, liqdichte,
    magnet_satz; seit 23.110 linien, trend_beleg, niveaus_urteil. Nichts wird geschätzt: was fehlt, steht in „fehlt“.
    """
    coin = Q["coin"]; jetzt = int(Q["jetzt"])
    K = Q.get("kurs") or {}
    px = _zahl(K.get("px")); kts = K.get("ts")
    kurs_frisch = px is not None and kts is not None and jetzt - int(kts) <= FRISCH_KURS_S
    A = Q.get("ausblick") or {}
    P = A.get("prognose"); R = A.get("rueckblick")
    a = Q.get("ausnahme") or {}
    aktiv = _zahl(a.get("seit")) is not None and 0 <= jetzt - a["seit"] < int(Q.get("ausnahme_dauer") or TAG)
    spanne = spanne_bauen(coin, P, R, px if kurs_frisch else None, jetzt)
    nv = Q.get("niveaus_urteil")
    levels = levels_bauen(P, R, px if kurs_frisch else None, niveaus=nv)
    levels["frisch"] = bool(spanne.get("frisch"))                    # dieselbe Rechnung des Ausblicks wie die Spanne
    if (levels["oben"] or levels["unten"]) and not levels["frisch"]:
        levels["fehlt"].append(f"Stand vom {_datum(levels.get('anker'))} -- älter als 2 Tage.")
    ks = Q.get("kosten") or {}
    schw = schwankung_bauen(Q.get("vol"), ks.get("er_4"), jetzt)
    schwelle = float(Q.get("konten_schwelle") or 3.0)
    lage = Q.get("lage") or {}
    lampen = [
        lampe_hebel(coin, lage.get("konten"), schwelle, Q.get("konten_beleg") or "", "; ".join(lage.get("fehlt") or [])),
        lampe_termin(Q.get("termine"), Q.get("naechste"), Q.get("datentag_stand"), jetzt, bool(Q.get("termine_geladen", True))),
        lampe_wochenende(jetzt, Q.get("wochenende_faktor")),
        lampe_aktien(coin, a, jetzt, int(Q.get("ausnahme_dauer") or TAG), Q.get("ausnahme_text") or "", (R or {}).get("s4"),
                     Q.get("aktien_pruefung")),
        lampe_schwankung(schw["pz"] if schw["frisch"] else None, schw.get("v1"), schw.get("pz_von") or "", schw.get("anzeige"),
                         "; ".join(schw["fehlt"]), schw.get("stand_text") or ""),
    ]
    out = {"ok": True, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL,
           "kopf": {"kurs": px, "kurs_ts": kts, "frisch": bool(kurs_frisch), "quelle": K.get("quelle") or ""},
           "satz": satz_bauen(coin, spanne, (Q.get("ausnahme_text") or "") if (aktiv and a.get("regel") in ("a", "b")) else ""),
           "lampen": lampen, "schwankung": schw, "spanne": spanne, "levels": levels,
           "messwerte": messwerte_bauen(lage, Q.get("funding"), schwelle, coin, Q.get("funding_hl"), Q.get("taker"), jetzt),
           "messwerte_beleg": BELEG_MESSWERT,
           "liqdichte": liqdichte_bauen(Q.get("liqdichte"), px if kurs_frisch else None, jetzt, coin, Q.get("magnet_satz") or ""),
           "kosten": kosten_bauen(ks), "fehlt": list(A.get("fehlt") or []) + list(Q.get("fehlt") or []),
           "rechner": rechner_kopf()}                                  # 23.105: feste Angaben der Karte „Kurs-Rechner“; gerechnet wird unter /cockpit/rechner
    # 23.110 (U269): Durchschnittslinien -- Abstand nur mit frischem Kurs, Erreich-Wahrscheinlichkeit nur aus einer frischen Rechnung
    out["linien"] = linien_bauen(Q.get("linien"), px if kurs_frisch else None, P, bool(spanne.get("frisch")), nv, Q.get("trend_beleg") or "")
    # 23.100 (U254): nur ETH -- angemeldete Abzüge aus dem Staking; Wert in USD nur mit frischem Kurs
    out["unstaking"] = (unstaking_bauen(Q.get("unstaking"), px if kurs_frisch else None, jetzt, Q.get("unstaking_pruefung"))
                        if coin == "ETH" else None)
    if out["unstaking"] and out["unstaking"]["ok"] and out["unstaking"]["satz"]:
        out["satz"]["unstaking"] = "Unstaking (gemessen): " + out["unstaking"]["satz"]     # der Termin steht auch oben, unter dem Kernsatz
    return out


def kern(coin: str, Q: dict) -> dict:
    """Schmale Fassung je Coin für den Streifen: 80-%-Spanne der 7 Tage (in % zum Anker) und die Zustände der fünf Lampen."""
    d = bauen(Q)
    e = (d["spanne"]["h"] or {}).get("7")
    p0 = d["spanne"].get("p0")
    return {"coin": coin, "lo": (e["q"][1] / p0 - 1.0) if e and p0 else None, "hi": (e["q"][5] / p0 - 1.0) if e and p0 else None,
            "lampen": [l["zustand"] for l in d["lampen"]], "frisch": bool(d["spanne"].get("frisch"))}


# ---- 23.110 (U269): Karte „Durchschnittslinien“ -- 50- und 200-Tage-Linie (Klasse B, gemessen); seit 23.111 mit beiden Rechnungen
# je Linie: Schlüssel (wie hl_chartbild.trendlage), Tage, Name, Art-Kennung des Niveaus in der Rechnung des Ausblicks
LINIEN = (("ma50", 50, "50-Tage-Linie", "ma50_"), ("ma200", 200, "200-Tage-Linie", "ma200"))
LINIEN_AUF = 0.0005                            # Abstand unter 0,05 % (gerundet 0,0 %): „Kurs auf der Linie“
BELEG_LINIEN = ("Gemessen, keine Vorhersage: einfacher Durchschnitt von 50 und 200 Tagen (Tageswechsel 00:00 UTC). Groß steht der Wert mit "
                "dem heutigen Tag zum jetzigen Kurs -- so rechnen der Live-Chart und die Kachel „MA 200 Tage“; auf ihn bezieht sich der "
                "Abstand. Klein steht der Wert nach dem letzten Tagesschluss -- so rechnen Chartbild, Ausblick und „Levels“; auf ihn "
                "beziehen sich Richtung, Lage und Erreich-Wahrscheinlichkeit.")
LINIEN_OHNE_KURS = "Stand nach Tagesschluss -- ohne frischen Kurs kein Wert mit dem heutigen Tag"
LINIEN_NICHT_WIDERLEGT = "„Nicht belegt“ heißt: mit diesen Daten nicht zu zeigen -- nicht widerlegt."


# ================================================================================================ 23.110: Durchschnittslinien
# Karte „Durchschnittslinien“ (U269, Wunsch des Nutzers vom 17.11.2026): 50- und 200-Tage-Linie je Coin. Die Werte kommen aus dem
# Tagesteil des Chartbilds (hl_chartbild.trendlage: einfacher Durchschnitt der Tagesschlüsse) -- dieselben Zahlen wie im Chartbild
# und wie die Niveaus „50-Tage-Linie“ und „200-Tage-Linie“ des Ausblicks. Klasse B (gemessen): neutral, mit Stand und Beleg.
# Seit 23.111 (Entscheidung des Nutzers vom 18.11.2026, „Beide Werte zeigen“): Groß steht der Wert, wie ihn der Live-Chart und die
# Kachel „MA 200 Tage“ rechnen (hl_viz.load_mas: der heutige Tag zählt mit dem jetzigen Kurs mit), klein der Wert nach dem letzten
# Tagesschluss. Im Dashboard gab es beide Rechnungen schon; 23.110 zeigte nur die zweite und sagte das nicht.

def _richtung(reihe) -> tuple:
    """Vorzeichen der jüngsten Änderung einer Reihe und seit wie vielen Schritten es gilt -- (+1 | −1, Schritte); (None, None), wenn die
    letzten beiden Werte fehlen oder gleich sind. Dieselbe Regel wie hl_chartbild.trendlage für die 50-Tage-Linie."""
    try:
        n = len(reihe)
    except TypeError:
        return None, None
    if n < 2:
        return None, None
    a, b = _zahl(reihe[n - 1]), _zahl(reihe[n - 2])
    if a is None or b is None or a == b:
        return None, None
    s = 1 if a > b else -1; k = 0
    for j in range(n - 1, 0, -1):
        x, y = _zahl(reihe[j]), _zahl(reihe[j - 1])
        if x is None or y is None or ((x > y) - (x < y)) != s:
            break
        k += 1
    return s, k


def linien_lesen(E: dict | None) -> dict:
    """
    Die Durchschnittslinien aus dem Tagesteil des Chartbilds (hl_chartbild.tagesteil): Wert der 50- und der 200-Tage-Linie nach dem
    letzten vollen Tag, Richtung jeder Linie, Lage der beiden zueinander mit dem Tag des letzten Wechsels, Stand und Quelle der
    Tageskerzen, Zahl der Tage ohne Kerze unter den letzten 200 (dort gilt der Schluss des Vortags). Zeigt das Chartbild keinen Trend
    (keine oder zu alte Tageskerzen), steht sein Grund in „fehlt“.
    """
    if not isinstance(E, dict):
        return {"fehlt": ["Tagesteil des Chartbilds nicht lesbar."]}
    T = E.get("trend"); D = E.get("tage") or {}
    if not isinstance(T, dict) or T.get("tag") is None:
        gr = [str(f) for f in (E.get("fehlt") or []) if str(f).startswith("Tageskerzen")]
        return {"fehlt": gr or ["Keine Tageskerzen."]}
    out = {"tag": int(T["tag"]), "n_tage": int(T.get("n_tage") or 0), "schluss": _zahl(T.get("schluss")), "quelle": str(D.get("quelle") or ""),
           "alter_tage": max(0, int(D.get("alter_tage") or 0)), "gefuellt": None, "fehlt": []}
    for key, _tage, _name, _art in LINIEN:
        out[key] = _zahl(T.get(key + "_jetzt"))
        s, k = _richtung(T.get(key)) if out[key] is not None else (None, None)
        out[key + "_richtung"] = s; out[key + "_seit"] = k
    try:                                                                 # Summe der letzten n − 1 Tagesschlüsse: mit dem jetzigen Kurs als n-tem Wert
        c = D["c"]; n = len(c)                                           # ergibt sie den Durchschnitt, den der Live-Chart zeigt (hl_viz.load_mas)
        for key, tage, _name, _art in LINIEN:
            out[key + "_rest"] = float(sum(float(x) for x in c[n - (tage - 1):])) if out[key] is not None and n >= tage else None
    except (KeyError, TypeError, ValueError):
        for key, _tage, _name, _art in LINIEN:
            out[key + "_rest"] = None
    out["lage"] = int(T["lage50_200"]) if T.get("lage50_200") in (1, -1) else None
    out["kreuz_tag"] = int(T["kreuz_tag"]) if out["lage"] is not None and T.get("kreuz_tag") is not None else None
    try:                                                                 # ein aufgefüllter Tag: Eröffnung = Hoch = Tief = Schluss = Schluss des Vortags
        o, h, l, c = D["o"], D["h"], D["l"], D["c"]
        n = len(c)
        out["gefuellt"] = sum(1 for i in range(max(1, n - LINIEN[-1][1]), n) if o[i] == h[i] == l[i] == c[i] == c[i - 1])
    except (KeyError, TypeError, IndexError):
        pass
    return out


def niveaus_urteil_lesen(db: str) -> dict:
    """
    Urteil der Niveau-Arten (U244) in der Kurzform von hl_niveaus.kurz -- für die Belege der Karten „Levels“ und „Durchschnittslinien“:
    ob es ein Urteil gibt, sein Datum, der Satz der Lesart und je Linie der Text der Spalte „Bilanz der Art“ des Ausblicks (ohne die
    vorangestellte Kennung). Das Urteil fasst die Krypto-Coins zusammen (hl_ausblick.KRYPTO), Gold ist nicht dabei.
    """
    import hl_ausblick as AU
    import hl_niveaus as NVM
    k = NVM.kurz(db)
    linien = {}
    for _key, _tage, _name, art in LINIEN:
        t = str((k.get("arten") or {}).get(art) or ""); kenn = str(NVM.ART_ZU.get(art) or "") + " · "
        linien[art] = t[len(kenn):] if t.startswith(kenn) else t
    return {"da": bool(k.get("da")), "debug": int(k.get("debug") or NVM.DEBUG_NR), "regel": k.get("regel"), "stand": k.get("stand"),
            "satz": str(k.get("satz") or ""), "ohne_wirkung": k.get("satz") == NVM.SATZ_OHNE, "coins": list(AU.KRYPTO), "linien": linien}


def _ts_tag(ts) -> str:
    v = _zahl(ts)
    return "—" if v is None else time.strftime("%d.%m.%Y", time.gmtime(int(v)))


def niveau_art_satz(nv: dict | None) -> str:
    """Schluss des Belegs der Karte „Levels“: Die Erreich-Wahrscheinlichkeit folgt aus dem Abstand -- und was die Prüfung der Niveau-Arten
    (U244, niveaus_urteil_lesen) dazu sagt. Bis 23.109 stand dort fest „die Art des Niveaus ist nicht geprüft“; seit dem Urteil vom
    17.11.2026 stimmte das nicht mehr."""
    kopf = "Die Zahl folgt allein aus dem Abstand"
    if not isinstance(nv, dict):
        return kopf + "."
    nr = nv.get("debug") or 149
    if not nv.get("da"):
        return f"{kopf}; die Art des Niveaus ist noch nicht geprüft (U244, Debug {nr})."
    if not nv.get("ohne_wirkung"):
        return f"{kopf}. {str(nv.get('satz') or '').strip()} (U244, Debug {nr})"
    return f"{kopf}; für keine Art von Niveau ist eine eigene Wirkung belegt (U244, Urteil vom {_ts_tag(nv.get('stand'))}, Debug {nr})."


def linien_niveau_beleg(nv: dict | None) -> str:
    """Satz zum Urteil der Niveau-Arten (U244) für die beiden Linien -- aus niveaus_urteil_lesen. Ohne Urteil sagt er das."""
    if not isinstance(nv, dict):
        return ""
    nr = nv.get("debug") or 149
    if not nv.get("da"):
        return f"Als Niveau noch nicht geprüft (U244, Debug {nr}) -- das Urteil rechnet der Rückblick des Ausblicks."
    teile = [f"{name} {t}" for _key, _tage, name, art in LINIEN for t in [str((nv.get("linien") or {}).get(art) or "")] if t]
    if not teile:
        return ""
    coins = ", ".join(str(c) for c in (nv.get("coins") or []))
    return (f"Als Niveau geprüft (U244, Debug {nr}, Urteil vom {_ts_tag(nv.get('stand'))}; 7 Tage" + (f"; {coins} zusammen" if coins else "")
            + "): " + "; ".join(teile) + ". " + LINIEN_NICHT_WIDERLEGT)


def linien_bauen(L: dict | None, kurs: float | None, prognose: dict | None, ausblick_frisch: bool, niveaus: dict | None = None,
                 trend_beleg: str = "") -> dict:
    """
    Reine Zusammenstellung der Karte „Durchschnittslinien“ aus linien_lesen (L), dem frischen Kurs (sonst None), der jüngsten Rechnung
    des Ausblicks (prognose; ausblick_frisch wie bei Spanne und Levels) und dem Urteil der Niveau-Arten. Je Linie zwei Werte (seit
    23.111): px_live = (Summe der letzten n − 1 Tagesschlüsse + jetziger Kurs) ÷ n, wie der Live-Chart -- er steht groß (haupt_text),
    und auf ihn bezieht sich der Abstand; px = der Wert nach dem letzten Tagesschluss -- er steht klein daneben (neben). Ohne frischen
    Kurs gibt es nur den zweiten. Dazu der Abstand des
    JETZIGEN Kurses zur Linie, Richtung der Linie und -- nur wenn der Ausblick diese Linie als Niveau führt und sie seit seiner Rechnung
    weder erreicht noch durchlaufen wurde -- die Erreich-Wahrscheinlichkeit für 1 und 2 Wochen (dieselben Zahlen wie in „Levels“ und im
    Ausblick; rechnete der Ausblick mit einem anderen Stand der Linie, steht dieser dabei). Nichts wird geschätzt: Was fehlt, nennt
    seinen Grund. Die Texte der Karte (lage, richtung, p_text) entstehen hier -- das Skript der Seite setzt sie nur.
    """
    out = {"ok": False, "zeilen": [], "lage": "", "stand_tag": None, "stand": "", "hinweise": [], "fehlt": [],
           "beleg": " ".join(t for t in (BELEG_LINIEN, trend_beleg or "", linien_niveau_beleg(niveaus)) if t)}
    if not isinstance(L, dict) or L.get("fehlt") or L.get("tag") is None:
        out["fehlt"] = [str(f) for f in ((L.get("fehlt") if isinstance(L, dict) else None) or ["Keine Tageskerzen."])]
        return out
    P = prognose or {}
    p0 = _zahl(P.get("p0")); k = _zahl(kurs); k = k if k and k > 0 else None
    arten = [x[3] for x in LINIEN]; nach_art: dict = {}
    for n in P.get("niveaus") or []:
        a = str((n or {}).get("art") or "")
        if a in arten and a not in nach_art:
            nach_art[a] = n
    for key, tage, name, art in LINIEN:
        px = _zahl(L.get(key)); px = px if px and px > 0 else None
        z = {"key": key, "name": name, "tage": tage, "px": px, "px_text": _px(px), "px_live": None, "px_live_text": "", "haupt_text": _px(px),
             "neben": "", "abstand": None, "lage": "", "richtung": "", "p7": None, "p14": None, "p_grund": "", "p_hinweis": "", "p_text": "",
             "fehlt": ""}
        out["zeilen"].append(z)
        if px is None:
            z["fehlt"] = f"Für die {name} fehlen noch Tage ({int(L.get('n_tage') or 0)} von {tage})."
            continue
        s, seit = L.get(key + "_richtung"), L.get(key + "_seit")
        if s in (1, -1) and seit:
            z["richtung"] = f"Linie {'steigt' if s > 0 else 'fällt'} seit {int(seit)} Tag{'' if int(seit) == 1 else 'en'}"
        rest = _zahl(L.get(key + "_rest"))
        if k is None:
            z["lage"] = "Abstand zum Kurs: kein frischer Kurs"; z["neben"] = LINIEN_OHNE_KURS
        else:
            if rest is not None:                                         # wie der Live-Chart: der heutige Tag zählt mit dem jetzigen Kurs mit
                z["px_live"] = (rest + k) / tage; z["px_live_text"] = _px(z["px_live"])
                z["haupt_text"] = z["px_live_text"]; z["neben"] = f"nach Tagesschluss {z['px_text']}"
            else:
                z["neben"] = "Stand nach Tagesschluss"
            z["abstand"] = k / (z["px_live"] or px) - 1.0
            z["lage"] = ("Kurs auf der Linie" if abs(z["abstand"]) < LINIEN_AUF
                         else f"Kurs {_pc(abs(z['abstand']), 1)} {'darüber' if z['abstand'] > 0 else 'darunter'}")
        n = nach_art.get(art) or {}
        npx = _zahl(n.get("px")); p = n.get("p") or {}
        p7, p14 = (_zahl((p.get(h_) or [None])[0]) for h_ in ("7", "14"))
        if not P.get("niveaus") and _zahl(P.get("anker")) is None:
            z["p_grund"] = "keine Rechnung des Ausblicks"
        elif not ausblick_frisch:
            z["p_grund"] = "die Rechnung des Ausblicks ist älter als 2 Tage"
        elif npx is None or npx <= 0:
            z["p_grund"] = "nicht unter den Niveaus des Ausblicks (er führt nur Niveaus innerhalb seiner 98-%-Spanne für 4 Wochen)"
        elif n.get("erreicht") or p7 is None or p14 is None:
            z["p_grund"] = "seit der Rechnung des Ausblicks erreicht"
        elif k is not None and p0 and ((npx - p0) * (npx - k) < 0 or npx == k):       # ohne frischen Kurs nicht zu sagen: die Zahl gilt ab dem Anker
            z["p_grund"] = "seit der Rechnung des Ausblicks durchlaufen"
        else:
            z["p7"] = p7; z["p14"] = p14
            if _px(npx) != z["px_text"]:
                z["p_hinweis"] = f"gerechnet für {_px(npx)}, den Stand der Linie bei der Rechnung des Ausblicks"
            elif z["px_live"] is not None:
                z["p_hinweis"] = "gilt für den Stand nach Tagesschluss"
        z["p_text"] = (f"Erreich-Wahrscheinlichkeit: 1 Woche {_de(z['p7'] * 100, 0)} % · 2 Wochen {_de(z['p14'] * 100, 0)} %"
                       + (f" ({z['p_hinweis']})" if z["p_hinweis"] else "")) if z["p7"] is not None else f"Ohne Erreich-Wahrscheinlichkeit: {z['p_grund']}"
    if L.get("lage") in (1, -1):
        out["lage"] = (f"Nach dem letzten Tagesschluss liegt die 50-Tage-Linie {'über' if L['lage'] > 0 else 'unter'} der 200-Tage-Linie"
                       + (f", seit dem {_tag_datum(L['kreuz_tag'])}" if L.get("kreuz_tag") is not None else "") + ".")
        lv = [z_["px_live"] for z_ in out["zeilen"]]
        if None not in lv and lv[0] != lv[1] and (lv[0] > lv[1]) != (L["lage"] > 0):       # mit dem heutigen Kurs steht es umgekehrt
            out["lage"] += f" Mit dem heutigen Kurs gerechnet liegt sie {'darüber' if lv[0] > lv[1] else 'darunter'}."
    out["stand_tag"] = int(L["tag"])
    out["stand"] = f"Tagesschlüsse bis {_tag_datum(L['tag'])} (UTC)" + (f", Quelle {L['quelle']}" if L.get("quelle") else "")
    alter = int(L.get("alter_tage") or 0)
    if alter > 0:
        out["hinweise"].append(f"Der jüngste Tagesschluss fehlt noch ({alter} Tag{'' if alter == 1 else 'e'} Rückstand; die Tageskerzen lädt "
                               "hl_binance alle 6 Stunden).")
    gef = int(L.get("gefuellt") or 0)
    if gef > 0:
        out["hinweise"].append(f"Unter den letzten {LINIEN[-1][1]} Tagen {'ist' if gef == 1 else 'sind'} {gef} ohne Tageskerze -- dort gilt der "
                               "Schluss des Vortags.")
    out["ok"] = True
    return out


def linien_text(Ln: dict | None) -> list:
    """Die Karte „Durchschnittslinien“ als Zeilen des Textberichts (Debug 143) -- dieselben Zahlen wie auf der Seite; der Beleg steht im
    Bericht einmal am Ende."""
    if not isinstance(Ln, dict):
        return []
    if not Ln.get("ok"):
        return ["   Durchschnitt: kein Wert -- " + " ".join(Ln.get("fehlt") or ["Grund unbekannt"])]
    Z = []
    for z in Ln["zeilen"]:
        if z.get("px") is None:
            Z.append(f"   Durchschnitt {z['name']:<15} {'—':>10}  {z['fehlt']}")
            continue
        p = (f"1 W {_de(z['p7'] * 100, 0)} % · 2 W {_de(z['p14'] * 100, 0)} %" + (f" ({z['p_hinweis']})" if z.get("p_hinweis") else "")
             if z.get("p7") is not None and z.get("p14") is not None else f"ohne Erreich-Wahrscheinlichkeit: {z['p_grund']}")
        Z.append(f"   Durchschnitt {z['name']:<15} {z['haupt_text']:>10}  {z['neben']} · {z['lage']}" + (f" · {z['richtung']}" if z["richtung"] else "")
                 + f" · {p}")
    if Ln.get("lage"):
        Z.append(f"   Durchschnitt Lage: {Ln['lage']}")
    Z.append(f"   Durchschnitt Stand: {Ln['stand']}" + "".join(f" -- {h}" for h in Ln.get("hinweise") or []))
    return Z


# ================================================================================================ 23.108: Rest von Stufe C2
# Markt-Messwerte „Funding (Hyperliquid)“ und „Varianz des Taker-Flusses“, Karte „Liquidationsdichte“, Betriebslampe. Alles Klasse B
# (gemessen): neutral, mit Zahl, Stand und Vergleichsbasis. Lesen und Bauen getrennt -- die Bau-Funktionen sind rein.

def funding_hl_lesen(con, coin: str, jetzt: int) -> dict:
    """
    Funding von Hyperliquid aus ctx_bars (der Recorder schreibt je Minute den laufenden Satz je Stunde): der jüngste Wert der letzten
    zwei Tage und die Werte zur vollen Stunde der letzten FUNDING_TAGE Tage. Die Stunden werden über den Primärschlüssel (ts, coin)
    einzeln gesucht -- die Tabelle wächst um 1.440 Zeilen je Coin und Tag und wird nicht durchlaufen.
    """
    out: dict = {"fehlt": [], "reihe": []}
    if con is None:
        out["fehlt"].append("Datenbank des Recorders fehlt")
        return out
    jetzt = int(jetzt)
    try:
        r = con.execute("SELECT ts, funding FROM ctx_bars WHERE ts >= ? AND ts <= ? AND coin = ? AND funding IS NOT NULL ORDER BY ts DESC LIMIT 1",
                        (jetzt - 2 * TAG, jetzt, coin)).fetchone()
        if r:
            out["wert"] = float(r[1]); out["ts"] = int(r[0]) + 60        # die Zeile gilt für ihre Minute (wie der Kurs: Ende der Minute)
        letzte = (jetzt // 3600) * 3600
        stunden = list(range(letzte - FUNDING_TAGE * TAG, letzte + 1, 3600))
        reihe = []
        for i in range(0, len(stunden), 400):
            teil = stunden[i:i + 400]
            reihe += con.execute(f"SELECT ts, funding FROM ctx_bars WHERE coin = ? AND ts IN ({','.join('?' * len(teil))}) AND funding IS NOT NULL",
                                 [coin] + teil).fetchall()
        out["reihe"] = sorted((int(t), float(f)) for t, f in reihe)
    except sqlite3.Error as e:
        out["fehlt"].append(f"Funding (Hyperliquid) nicht lesbar ({type(e).__name__})")
    return out


def funding_hl_zeile(F: dict | None, jetzt: int) -> dict:
    """Zeile „Funding (Hyperliquid)“: jüngster Satz je Stunde, Perzentil gegen die Stundenwerte der letzten FUNDING_TAGE Tage."""
    F = F or {}; jetzt = int(jetzt)
    z = {"key": "funding_hl", "name": "Funding (Hyperliquid)", "wert": None, "pz": None, "pz_n": None, "text": "—", "art": "",
         "stand": None, "stand_tag": None, "basis": "", "fehlt": ""}
    w = _zahl(F.get("wert")); ts = _zahl(F.get("ts"))
    if w is None or ts is None:
        z["fehlt"] = "; ".join(F.get("fehlt") or []) or "kein Wert in den letzten zwei Tagen"
        return z
    if jetzt - int(ts) > FRISCH_FUNDING_S:
        z["fehlt"] = f"letzter Wert vom {_datum(ts)} -- älter als {FRISCH_FUNDING_S // 60} Minuten"
        return z
    z.update(wert=w, stand=int(ts), art="live", pa=w * 24 * 365,
             text=f"{_de(w * 100, 4, True)} %/h · {_de(w * 24 * 365 * 100, 1, True)} % p. a.")
    reihe = [(int(t), v) for t, v in ((a, _zahl(b)) for a, b in (F.get("reihe") or []))
             if v is not None and jetzt - FUNDING_TAGE * TAG - 3600 <= int(t) <= jetzt]
    n = len(reihe)
    tage = int((max(t for t, _ in reihe) - min(t for t, _ in reihe)) // TAG) if n else 0
    z["n"] = n; z["tage"] = tage
    if tage < FUNDING_MIN_TAGE:
        z["basis"] = f"Perzentil ab {FUNDING_MIN_TAGE} Tagen Verlauf (bisher {tage})"
        return z
    if n < FUNDING_MIN_N:
        z["basis"] = f"Perzentil ab {FUNDING_MIN_N} Stundenwerten (bisher {n})"
        return z
    pz = perzentil(w, [v for _, v in reihe])
    if pz is None:
        z["basis"] = "ohne Perzentil: alle Vergleichswerte sind gleich"
        return z
    z.update(pz=pz, pz_n=pz_zahl(pz),
             basis=f"{_eth(n)} Stundenwerte aus {tage} Tagen" + ("" if tage >= FUNDING_TAGE else f" (Ziel {FUNDING_TAGE})"))
    return z


def taker_lesen(con, coin: str) -> dict:
    """
    Varianz des Taker-Flusses, dieselbe Zahl wie in der Prognose (hl_indikatoren.varianz_kompression): Streuung der 10-s-Salden
    (Taker-Käufe minus Taker-Verkäufe in USD) der letzten vollen Stunde, als Perzentil gegen die Stunden der letzten TAKER_TAGE Tage.
    Die Verteilung hält das Modul je Coin und Tag im Speicher; im Dashboard teilt sich das Cockpit diesen Speicher mit der Prognose.
    """
    if con is None:
        return {"fehlt": ["Datenbank des Recorders fehlt"]}
    stunde = (int(time.time()) // 3600) * 3600
    try:
        import hl_indikatoren as IND
        r = IND.varianz_kompression(con, coin, TAKER_TAGE)
    except Exception as e:
        return {"fehlt": [f"Taker-Varianz: {type(e).__name__}"]}
    if not r or _zahl(r.get("pct")) is None:
        return {"fehlt": ["zu wenige 10-s-Daten (nötig: 7 Tage Verlauf, 100 volle Stunden, die letzte Stunde zur Hälfte belegt)"]}
    return {"pz": float(r["pct"]), "ts": stunde, "fehlt": []}


def taker_zeile(T: dict | None) -> dict:
    """Zeile „Varianz des Taker-Flusses“: Perzentil der letzten vollen Stunde; das unterste Zehntel ist auf der Skala markiert."""
    T = T or {}
    z = {"key": "taker_var", "name": "Varianz des Taker-Flusses", "wert": None, "pz": None, "pz_n": None, "text": "—", "art": "",
         "stand": None, "stand_tag": None, "basis": "", "fehlt": "", "zone": TAKER_DEZIL, "im_dezil": None}
    pz = _zahl(T.get("pz"))
    if pz is None or not 0.0 <= pz <= 1.0:
        z["fehlt"] = "; ".join(T.get("fehlt") or []) or "kein Wert"
        return z
    unten = pz < TAKER_DEZIL                                           # wie die Prognose: „komprimiert“ nur unter dem 10. Perzentil
    z.update(wert=pz, pz=pz, pz_n=pz_zahl(pz), art="letzte volle Stunde", stand=_zahl(T.get("ts")) and int(T["ts"]), im_dezil=bool(unten),
             text="im untersten Zehntel" if unten else "nicht im untersten Zehntel", basis=f"Stunden der letzten {TAKER_TAGE} Tage (Hyperliquid)")
    return z


def magnet_satz(m: dict | None, grund: str = "") -> str:
    """Ein Satz zum Stand des Magnet-Tests (U110) für die Karte „Liquidationsdichte“: was er für diesen Coin belegt -- aus der
    gespeicherten Rechnung, nicht aus dem Gedächtnis."""
    if not isinstance(m, dict):
        return "Ob der Kurs solche Cluster anzieht, prüft der Magnet-Test (Debug 51). " + (grund or "Seine Rechnung liegt nicht vor.")
    bel, offen = [], []
    for h in sorted((m.get("h") or {}), key=lambda x: _zahl(x) or 0):
        v = m["h"][h] or {}
        if v.get("zu_wenig") or not v.get("klassen"):
            offen.append(f"{h} h")
            continue
        bel += [f"{h} h {n}" for n, r in v["klassen"].items() if isinstance(r, dict) and r.get("belegt")]
    stand = f"Stand {_datum(m.get('ts'))}"
    if bel:
        return f"Magnet-Test (Debug 51, {stand}): Anziehung belegt für {', '.join(bel)}; sonst nicht."
    if offen and len(offen) == len(m.get("h") or {}):
        return f"Magnet-Test (Debug 51, {stand}): noch zu wenige Fälle für ein Urteil."
    return (f"Magnet-Test (Debug 51, {stand}): Dass der Kurs solche Cluster anzieht, ist für keine Größenklasse belegt"
            + (f" (für {', '.join(offen)} noch zu wenige Fälle)." if offen else "."))


def liqdichte_lesen(con, coin: str, jetzt: int) -> dict:
    """
    Jüngster Schnappschuss der Heatmap (der Recorder schreibt ihn alle 10 Minuten): Zellen des Coins, Abdeckung des Open Interest,
    Zahl der eingegangenen und der wegen Alters ausgelassenen Positionen. Maßgeblich ist der jüngste Schnappschuss ÜBERHAUPT
    (snapshot_meta) -- hat der Coin darin keine Zelle, ist die Dichte null und nicht „veraltet“.
    """
    out: dict = {"fehlt": [], "zeilen": []}
    if con is None:
        out["fehlt"].append("Datenbank des Recorders fehlt")
        return out
    jetzt = int(jetzt)
    try:
        ts = None
        try:
            m = con.execute("SELECT ts, n_positions, n_stale_dropped, age_median FROM snapshot_meta WHERE ts <= ? AND n_positions IS NOT NULL "
                            "ORDER BY ts DESC LIMIT 1", (jetzt,)).fetchone()
        except sqlite3.Error:
            m = None
        if m:
            ts = int(m[0])
            out["positionen"] = {"drin": _zahl(m[1]), "alt": _zahl(m[2]), "alter_median_s": _zahl(m[3])}
        else:
            r = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin = ? AND ts <= ?", (coin, jetzt)).fetchone()
            ts = int(r[0]) if r and r[0] else None
        if ts is None:
            out["fehlt"].append("noch kein Schnappschuss der Heatmap")
            return out
        out["ts"] = ts
        out["zeilen"] = [(float(b), str(s), float(n or 0.0), int(k or 0)) for b, s, n, k in
                         con.execute("SELECT bucket_px, side, notional, n_pos FROM heatmap WHERE coin = ? AND ts = ?", (coin, ts)) if b]
        try:
            c = con.execute("SELECT ratio, tracked_size, oi FROM coverage WHERE ts = ? AND coin = ?", (ts, coin)).fetchone()
        except sqlite3.Error:
            c = None
        if c and _zahl(c[0]) is not None:
            out["abdeckung"] = {"anteil": float(c[0]), "erfasst": _zahl(c[1]), "oi": _zahl(c[2])}
    except sqlite3.Error as e:
        out["fehlt"].append(f"Heatmap nicht lesbar ({type(e).__name__})")
    return out


def liqdichte_bauen(L: dict | None, kurs: float | None, jetzt: int, coin: str = "", magnet: str = "") -> dict:
    """
    Karte „Liquidationsdichte“: Positionswert bekannter Konten, deren Liquidationspreis höchstens LIQ_BREITE vom Kurs entfernt liegt,
    in Stufen von LIQ_STUFE. Unter dem Kurs zählen nur Long-, darüber nur Short-Positionen; eine Zelle auf der falschen Seite (der
    Kurs ist seit der Abfrage über sie hinweggegangen) steht als „überholt“ in einer eigenen Zahl, nicht in den Balken.
    """
    L = L or {}; jetzt = int(jetzt)
    out: dict = {"ok": False, "frisch": False, "coin": coin, "stand": None, "kurs": _zahl(kurs), "breite": LIQ_BREITE, "stufe": LIQ_STUFE,
                 "balken": [], "summe_unten": None, "summe_oben": None, "n_unten": 0, "n_oben": 0, "groesster": None, "ueberholt_usd": 0.0,
                 "ueberholt_n": 0, "abdeckung": None, "alt_anteil": None, "alt_n": None, "bekannt_n": None, "alter_median_s": None,
                 "fehlt": list(L.get("fehlt") or []), "beleg": BELEG_LIQ, "magnet": magnet or "",
                 "name_unten": LIQ_NAME_UNTEN, "name_oben": LIQ_NAME_OBEN}
    ts = _zahl(L.get("ts"))
    if ts is None:
        if not out["fehlt"]:
            out["fehlt"].append("noch kein Schnappschuss der Heatmap")
        return out
    out["stand"] = int(ts)
    ab = L.get("abdeckung") or {}
    if _zahl(ab.get("anteil")) is not None:
        out["abdeckung"] = float(ab["anteil"])
    po = L.get("positionen") or {}
    drin, alt = _zahl(po.get("drin")), _zahl(po.get("alt"))
    if drin is not None and alt is not None and drin + alt > 0:
        out.update(alt_anteil=alt / (drin + alt), alt_n=int(alt), bekannt_n=int(drin + alt))
    out["alter_median_s"] = _zahl(po.get("alter_median_s"))
    out["frisch"] = jetzt - int(ts) <= FRISCH_LIQ_S
    if not out["frisch"]:
        out["fehlt"].append(f"Schnappschuss vom {_datum(ts)} -- älter als {FRISCH_LIQ_S // 60} Minuten.")
    px = _zahl(kurs)
    if px is None or px <= 0:
        out["fehlt"].append("Ohne frischen Kurs keine Abstände.")
        return out
    stufen = int(round(LIQ_BREITE / LIQ_STUFE))
    B = [{"von": (i - stufen) * LIQ_STUFE, "bis": (i - stufen + 1) * LIQ_STUFE, "seite": "long" if i < stufen else "short", "usd": 0.0, "n": 0}
         for i in range(2 * stufen)]
    eps = 1e-9
    for b, s, usd, n in (L.get("zeilen") or []):
        b = _zahl(b); usd = _zahl(usd) or 0.0
        if b is None or b <= 0 or usd <= 0:
            continue
        rel = b / px - 1.0
        if abs(rel) > LIQ_BREITE + eps:
            continue
        unten = rel < 0 or (rel == 0 and s == "long")
        if (unten and s != "long") or (not unten and s != "short"):
            out["ueberholt_usd"] += usd; out["ueberholt_n"] += int(n or 0)
            continue
        if unten:                                                        # Stufen unter dem Kurs: [von, bis) -- die kursferne Grenze gehört dazu
            i = max(0, min(stufen - 1, stufen + int(math.floor(rel / LIQ_STUFE + eps))))
        else:                                                            # Stufen über dem Kurs: (von, bis]
            i = max(stufen, min(2 * stufen - 1, stufen + int(math.ceil(rel / LIQ_STUFE - eps)) - 1))
        B[i]["usd"] += usd; B[i]["n"] += int(n or 0)
    out["balken"] = B
    out["summe_unten"] = sum(x["usd"] for x in B[:stufen]); out["summe_oben"] = sum(x["usd"] for x in B[stufen:])
    out["n_unten"] = sum(x["n"] for x in B[:stufen]); out["n_oben"] = sum(x["n"] for x in B[stufen:])
    g = max(B, key=lambda x: x["usd"])
    out["groesster"] = g["usd"] if g["usd"] > 0 else None
    out["ok"] = True
    return out


def liqdichte_text(D: dict | None) -> list:
    """Die Karte als Textzeilen (Debug 143) -- dieselben Zahlen wie auf der Seite."""
    D = D or {}
    kopf = "   Liquidationsdichte"
    if not D.get("ok"):
        return [f"{kopf}: kein Wert -- " + " ".join(D.get("fehlt") or ["Grund unbekannt"])]
    pr = lambda x: _de(x * 100, 1, x != 0)
    Z = [f"{kopf} ± {_de(D['breite'] * 100, 0)} % um {_px(D['kurs'])}: {LIQ_NAME_UNTEN} {_usd1(D['summe_unten'])} ({_pos(D['n_unten'])}) · "
         f"{LIQ_NAME_OBEN} {_usd1(D['summe_oben'])} ({_pos(D['n_oben'])}) · Stand {_datum(D['stand'])}"
         + ("" if D.get("frisch") else " -- NICHT FRISCH")]
    Z.append(f"{kopf} Stufen: " + " · ".join(f"{pr(b['von'])}…{pr(b['bis'])} %: {_usd1(b['usd'])}" for b in D["balken"]))
    teile = []
    if D.get("abdeckung") is not None:
        teile.append(f"erfasst {_de(D['abdeckung'] * 100, 0)} % des Open Interest")
    if D.get("alt_anteil") is not None:
        teile.append(f"{_de(D['alt_anteil'] * 100, 0)} % der bekannten Positionen ({_eth(D['alt_n'])} von {_eth(D['bekannt_n'])}, alle Coins) "
                     f"seit über {LIQ_ALTER_S // 60} Minuten nicht abgefragt und nicht enthalten")
    if D.get("ueberholt_n") or D.get("ueberholt_usd"):
        teile.append(f"überholt und nicht gezeigt: {_usd1(D['ueberholt_usd'])} ({_pos(D['ueberholt_n'])})")
    if teile:
        Z.append(f"{kopf} Abdeckung: " + " · ".join(teile))
    for f in D.get("fehlt") or []:
        Z.append(f"{kopf} fehlt: {f}")
    if D.get("magnet"):
        Z.append(f"{kopf} Beleg: {D['beleg']} {D['magnet']}")
    else:
        Z.append(f"{kopf} Beleg: {D['beleg']}")
    return Z


# ------------------------------------------------------------------------------------------------ Betrieb (Lampe B11)

_BETRIEB = {"lock": threading.Lock(), "ts": 0.0, "wert": None, "aus_seit": {}}


def _systemctl(*args) -> str | None:
    """Erste Zeile der Antwort von systemctl; None, wenn es systemctl hier nicht gibt oder der Aufruf scheitert."""
    try:
        r = subprocess.run(["systemctl", *args], capture_output=True, text=True, timeout=4)
    except (OSError, subprocess.SubprocessError):
        return None
    zeilen = (r.stdout or "").strip().splitlines()
    return zeilen[0].strip() if zeilen else ""


def dienste_lesen(lauf=None) -> dict:
    """
    Zustand der Dienste des Projekts, gefragt wie der Wächter (hl_watchdog.run_checks): nur eingerichtete Dienste zählen
    (systemctl is-enabled), „active“ heißt läuft. lauf (Selbsttest): Ersatz für den Aufruf von systemctl.
    """
    if lauf is None:
        if not shutil.which("systemctl"):
            return {"pruefbar": False, "grund": "auf diesem Rechner gibt es kein systemd", "liste": []}
        lauf = _systemctl
    liste = []
    for u in DIENSTE:
        e = lauf("is-enabled", u)
        if e is None:
            return {"pruefbar": False, "grund": "systemctl antwortet nicht", "liste": []}
        if e not in ("enabled", "enabled-runtime"):
            continue                                                     # nicht eingerichtet -- zählt nicht (wie beim Wächter)
        a = lauf("is-active", u)
        if a is None:                                                    # hängt systemctl, wird nicht jeder Dienst einzeln abgewartet
            return {"pruefbar": False, "grund": "systemctl antwortet nicht", "liste": []}
        liste.append({"name": u, "zustand": a or "unbekannt"})
    if not liste:
        return {"pruefbar": False, "grund": "kein Dienst des Projekts ist eingerichtet", "liste": []}
    return {"pruefbar": True, "grund": "", "liste": liste}


def api_lesen(con) -> dict:
    """API-Gewicht der letzten Minute, wie es der Recorder bei jedem Schnappschuss in meta schreibt (dieselben Schlüssel wie der Wächter)."""
    if con is None:
        return {}
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN ('api_weight_1m','api_weight_budget','api_weight_limit','api_weight_ts','rate_limited')"))
    except sqlite3.Error:
        return {}
    if "api_weight_1m" not in rows:
        return {}
    z = lambda k, ersatz=None: _zahl(rows.get(k)) if _zahl(rows.get(k)) is not None else ersatz
    return {"gewicht": z("api_weight_1m"), "deckel": z("api_weight_budget", 1080.0), "limit": z("api_weight_limit", 1200.0),
            "ts": z("api_weight_ts"), "abgewiesen": z("rate_limited")}


def backup_lesen(db: str, con) -> dict:
    """Ergebnis der letzten Sicherung aus backup.json im Backup-Ordner (den trägt der Recorder in meta ein; sonst „dbbackup“ neben der Datenbank)."""
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    if con is not None:
        try:
            r = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
            if r and r[0]:
                bdir = r[0]
        except sqlite3.Error:
            pass
    try:
        with open(os.path.join(bdir, "backup.json"), encoding="utf-8") as f:
            st = json.load(f)
    except (OSError, ValueError):
        return {"da": False, "ordner": bdir}
    if not isinstance(st, dict):
        return {"da": False, "ordner": bdir}
    return {"da": True, "ordner": bdir, "ok": bool(st.get("ok")), "ts": _zahl(st.get("ts")), "fehler": str(st.get("error") or "")[:160]}


def betrieb_lesen(db: str, jetzt: int | None = None, lauf=None) -> dict:
    """Die drei Quellen der Betriebslampe. Ohne lauf höchstens alle DIENST_CACHE_S Sekunden neu (systemctl kostet je Dienst zwei Aufrufe)."""
    jetzt = int(jetzt or time.time())
    if lauf is None:
        with _BETRIEB["lock"]:
            hit = _BETRIEB["wert"]
            if hit is not None and hit.get("db") == db and 0 <= time.time() - _BETRIEB["ts"] < DIENST_CACHE_S:
                return hit
    out: dict = {"db": db, "gelesen": jetzt}
    try:
        out["dienste"] = dienste_lesen(lauf)
    except Exception as e:
        out["dienste"] = {"pruefbar": False, "grund": f"{type(e).__name__}", "liste": []}
    con = _ro(db)
    try:
        out["api"] = api_lesen(con)
        out["backup"] = backup_lesen(db, con)
    except Exception as e:
        out.setdefault("api", {}); out.setdefault("backup", {"da": False, "fehler": f"{type(e).__name__}"})
    finally:
        if con is not None:
            con.close()
    if lauf is None:
        with _BETRIEB["lock"]:
            _BETRIEB["wert"] = out; _BETRIEB["ts"] = time.time()
    return out


def betrieb_bauen(B: dict | None, jetzt: int, aus_seit: dict | None = None, bestaetigt_s: int = DIENST_BESTAETIGT_S) -> dict:
    """
    Betriebslampe (KONZEPT_Cockpit.md 4 und 14): Warnung, wenn ein eingerichteter Dienst nicht läuft; Hinweis bei API-Gewicht ab
    API_HINWEIS des harten Limits oder wenn die letzte Sicherung älter als BACKUP_HINWEIS_H Stunden ist. Ein Dienst, der eben erst als
    „nicht aktiv“ gesehen wurde, ist bestaetigt_s Sekunden lang nur ein Hinweis -- beim Neustart nach einem Update ist jeder Dienst
    kurz inaktiv. aus_seit: {Dienst: Zeitpunkt der ersten Sichtung}; die Funktion pflegt das Wörterbuch (ohne Angabe das des Moduls).
    """
    B = B or {}; jetzt = int(jetzt)
    aus_seit = _BETRIEB["aus_seit"] if aus_seit is None else aus_seit
    Z = []; gruende = []; rot = False; gelb = False
    # ---- Dienste
    D = B.get("dienste") or {}
    if not D.get("pruefbar"):
        Z.append({"key": "dienste", "name": "Dienste", "zustand": "grau", "text": "nicht prüfbar: " + (D.get("grund") or "Grund unbekannt")})
    else:
        liste = D.get("liste") or []
        steht, startet, neu = [], [], []
        for e in liste:
            name = str(e.get("name") or "?"); zs = str(e.get("zustand") or "unbekannt")
            if zs == "active":
                aus_seit.pop(name, None)
                continue
            if zs in ("activating", "reloading"):
                aus_seit.pop(name, None); startet.append(name)
                continue
            seit = aus_seit.setdefault(name, jetzt)
            (steht if jetzt - seit >= bestaetigt_s else neu).append((name, zs))
        for name in [k for k in aus_seit if k not in {str(e.get("name")) for e in liste}]:
            aus_seit.pop(name, None)
        kurz = lambda n: n.replace("hl-", "")
        laufen = len(liste) - len(steht) - len(startet) - len(neu)
        text_ = f"{laufen} von {len(liste)} eingerichteten laufen"
        if steht:
            rot = True; gruende.append("Dienst läuft nicht: " + ", ".join(kurz(n) for n, _ in steht))
            text_ += " · läuft nicht: " + ", ".join(f"{n} ({zs})" for n, zs in steht)
        if neu:
            gelb = True; gruende.append("Dienst nicht aktiv: " + ", ".join(kurz(n) for n, _ in neu))
            text_ += " · eben nicht aktiv (wird bestätigt): " + ", ".join(f"{n} ({zs})" for n, zs in neu)
        if startet:
            gelb = True; gruende.append("Dienst startet: " + ", ".join(kurz(n) for n in startet))
            text_ += " · startet: " + ", ".join(startet)
        Z.append({"key": "dienste", "name": "Dienste", "zustand": "warnung" if steht else "hinweis" if (neu or startet) else "aus", "text": text_,
                  "n": len(liste), "laufen": laufen})
    # ---- API-Gewicht
    A = B.get("api") or {}
    gew, limit, deckel, ats = _zahl(A.get("gewicht")), _zahl(A.get("limit")), _zahl(A.get("deckel")), _zahl(A.get("ts"))
    if gew is None or not limit or limit <= 0:
        Z.append({"key": "api", "name": "API-Gewicht", "zustand": "grau", "text": "kein Wert (der Recorder hat noch keinen Schnappschuss geschrieben)"})
    elif ats is None or jetzt - int(ats) > FRISCH_API_S:
        Z.append({"key": "api", "name": "API-Gewicht", "zustand": "grau",
                  "text": f"Stand {_datum(ats)} -- älter als {FRISCH_API_S // 60} Minuten, nicht gewertet"})
    else:
        anteil = gew / limit
        hoch = anteil >= API_HINWEIS
        if hoch:
            gelb = True; gruende.append("API-Gewicht")
        Z.append({"key": "api", "name": "API-Gewicht", "zustand": "hinweis" if hoch else "aus", "anteil": anteil, "stand": int(ats),
                  "text": f"{_eth(gew)} von {_eth(limit)} je Minute = {_de(math.floor(anteil * 100 + 1e-9), 0)} % des Limits (Hinweis ab {_de(API_HINWEIS * 100, 0)} %"
                          + (f"; Deckel des Recorders {_eth(deckel)}" if deckel else "") + ")"
                          + (f" · {_eth(A['abgewiesen'])} Abweisungen (429) seit dem Start des Recorders" if _zahl(A.get("abgewiesen")) else "")})
    # ---- Backup
    K = B.get("backup") or {}
    if not K.get("da"):
        Z.append({"key": "backup", "name": "Backup", "zustand": "grau", "text": "noch keine Sicherung gefunden" + (f" ({K['ordner']})" if K.get("ordner") else "")})
    elif not K.get("ok"):
        gelb = True; gruende.append("Backup")
        Z.append({"key": "backup", "name": "Backup", "zustand": "hinweis", "stand": K.get("ts") and int(K["ts"]),
                  "text": "letzte Sicherung fehlgeschlagen" + (f": {K['fehler']}" if K.get("fehler") else "")})
    elif _zahl(K.get("ts")) is None:
        Z.append({"key": "backup", "name": "Backup", "zustand": "grau", "text": "Zeitpunkt der letzten Sicherung unbekannt"})
    else:
        alter_h = (jetzt - float(K["ts"])) / 3600.0
        alt = alter_h > BACKUP_HINWEIS_H
        if alt:
            gelb = True; gruende.append("Backup alt")
        Z.append({"key": "backup", "name": "Backup", "zustand": "hinweis" if alt else "aus", "alter_h": alter_h, "stand": int(K["ts"]),
                  "text": f"vor {_de(max(0.0, alter_h), 1)} h (Hinweis ab {BACKUP_HINWEIS_H} h)"})
    zustand = "warnung" if rot else "hinweis" if gelb else "grau" if all(z["zustand"] == "grau" for z in Z) else "aus"
    wort = {"warnung": "Warnung", "hinweis": "Hinweis", "grau": "nicht prüfbar", "aus": "ohne Hinweis"}[zustand]
    return {"zustand": zustand, "wort": wort, "gruende": gruende, "zeilen": Z, "stand": jetzt, "beleg": BELEG_BETRIEB}


def betrieb_text(Bt: dict | None) -> list:
    """Die Betriebslampe als Textzeilen (Debug 143)."""
    Bt = Bt or {}
    if not Bt.get("zeilen"):
        return ["Betrieb: kein Wert"]
    Z = [f"Betrieb: {Bt.get('wort') or '—'}" + (f" ({'; '.join(Bt['gruende'])})" if Bt.get("gruende") else "") + f" · Stand {_datum(Bt.get('stand'))}"]
    wort = {"aus": "kein Hinweis", "hinweis": "Hinweis", "warnung": "Warnung", "grau": "ohne Wert"}       # nicht „aus“: „Dienste aus“ läse sich falsch
    for z in Bt["zeilen"]:
        Z.append(f"   {z['name']:<12} {wort.get(z['zustand'], z['zustand']):<12} {z['text']}"
                 + (f" · {'gesichert' if z['key'] == 'backup' else 'Stand'} {_datum(z['stand'])}" if z.get("stand") and z["zustand"] != "grau" else ""))
    Z.append("   " + (Bt.get("beleg") or ""))
    return Z


# ================================================================================================ Quellen lesen (nur lesend)

def _ro(pfad: str | None):
    if not pfad or not os.path.exists(pfad):
        return None
    try:
        return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    except sqlite3.Error:
        return None


def kurs_lesen(con, coin: str) -> dict:
    """Jüngster 1-min-Schluss aus den Minutenkerzen des Recorders."""
    if con is None:
        return {}
    try:
        r = con.execute("SELECT ts, close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
    except sqlite3.Error:
        return {}
    if not r or not r[1]:
        return {}
    return {"px": float(r[1]), "ts": int(r[0]) + 60, "quelle": "Hyperliquid (1-min-Kerze)"}


def schwankung_lesen(con, coin: str, jetzt: int) -> dict:
    """
    Aus volatil.db mit den Funktionen von hl_volatil (dieselben Regeln wie der Abschnitt „Volatilität“): erwartete Schwankung der
    ersten Woche (Prognose nur, wenn der Ursprung höchstens 3 Tage alt ist), realisierte 7/30 Tage, DVOL, Urteil V1, die Reihe der
    realisierten 7-Tage-Schwankung für das Perzentil. -> {} mit „fehlt“, wenn nichts da ist.
    """
    import hl_volatil as VL
    out = {"fehlt": [], "vi7_reihe": []}
    if coin not in VL.COINS:
        out["fehlt"].append(f"Für {coin} rechnet die Volatilität nicht (nur {', '.join(VL.COINS)}).")
        return out
    if con is None:
        out["fehlt"].append("volatil.db fehlt noch.")
        return out
    heute = int(jetzt) // TAG
    rows = con.execute("SELECT tag, vi7, vi30 FROM vl_tag WHERE coin=? AND tag BETWEEN ? AND ? ORDER BY tag",
                       (coin, heute - PERZ_TAGE - 40, heute)).fetchall()
    if not rows:
        out["fehlt"].append(f"Noch keine Tageswerte der Volatilität für {coin}.")
        return out
    bis = int(rows[-1][0])
    out["bis"] = bis
    out["vi7_reihe"] = [VL._runde(r[1]) for r in rows]
    out["real7"] = VL._runde(rows[-1][1]); out["real30"] = VL._runde(rows[-1][2])
    if heute - bis > FRISCH_SCHWANKUNG_TAGE:
        out["fehlt"].append(f"Tageswerte nur bis {_tag_datum(bis)}.")
    if coin in VL.DVOL_COINS:
        dv = VL._dvol_anzeige(con, coin, bis - 3, bis)
        if dv:
            out["dvol"] = VL._runde(dv[max(dv)])
    uz = VL.urteil_zeilen(con, True, VL.PRUEFUNGEN)
    u = {z["pruefung"]: z["urteil"] for z in uz}
    out["v1"] = u.get("V1")
    out["v1_p_holm"] = next((z.get("p_holm") for z in uz if z["pruefung"] == "V1"), None)
    modell = VL.anzeige_modell(coin, u)
    D, zeilen = VL.letzte_prognose(con, coin, modell)
    if not zeilen and modell == "M+":
        modell = "M"
        D, zeilen = VL.letzte_prognose(con, coin, modell)
    if zeilen and D is not None and D >= heute - FRISCH_SCHWANKUNG_TAGE:
        out["erwartet"] = VL._runde(VL.ann(zeilen[0][3])); out["ursprung"] = int(D)
        out["modell"] = modell; out["modell_text"] = VL.MODELL_TEXT.get(modell, modell)
    else:
        out["fehlt"].append("Keine frische Prognose der Schwankung" + (f" (letzte vom {_tag_datum(D)})" if D is not None else "") + ".")
    return out


def wochenende_faktor(con) -> float | None:
    """„Faktor 0,68“ aus der Datenprobe Wochenende der Volatilität (vl_meta pruefungen_vor_urteil)."""
    if con is None:
        return None
    import hl_volatil as VL
    try:
        liste = (VL.meta(con, "pruefungen_vor_urteil", {}) or {}).get("liste") or []
    except sqlite3.Error:
        return None
    for z in liste:
        if isinstance(z, (list, tuple)) and len(z) >= 3 and str(z[0]).startswith("Datenprobe Wochenende"):
            t = str(z[2]).replace("Faktor", "").strip().replace(",", ".")
            return _zahl(t)
    return None


def quellen_lesen(db: str, coin: str, jetzt: int | None = None, gemeinsam: dict | None = None, mit_ausblick_meldung: bool = True,
                  schmal: bool = False, store: str | None = None) -> dict:
    """Alle Quellen eines Coins lesen. Jede Quelle für sich: Scheitert eine, bleibt der Rest, der Grund steht in „fehlt“.
    gemeinsam: für alle Coins gleiche Teile (Termine, Ausnahmen, Wochenend-Faktor), damit der Streifen sie nur einmal liest.
    schmal: nur, was Lampen und 7-Tage-Spanne brauchen (für den Streifen) -- ohne Kostenschwelle und ohne den Tagesteil des Chartbilds."""
    import hl_ausblick as AU
    import hl_chartbild as CB
    jetzt = int(jetzt or time.time())
    Q = {"coin": coin, "jetzt": jetzt, "fehlt": [], "konten_schwelle": float(CB.KONTEN_SCHWELLE), "ausnahme_dauer": int(AU.AUSNAHME_S)}
    pk = CB.PRUEFSTAND.get("konten") or ("", "")
    Q["konten_beleg"] = f"{pk[1]} ({pk[0]}, Stand {CB.PRUEFSTAND_STAND})"
    G = gemeinsam if gemeinsam is not None else gemeinsam_lesen(db, jetzt)
    for k in ("termine", "naechste", "datentag_stand", "termine_geladen", "wochenende_faktor", "aktien_pruefung", "niveaus_urteil"):
        Q[k] = G.get(k)
    Q["fehlt"] += list(G.get("fehlt") or [])
    a = (G.get("ausnahmen") or {}).get(coin)
    if isinstance(a, dict):
        Q["ausnahme"] = a
        try:
            Q["ausnahme_text"] = AU.ausnahme_text(a)
        except Exception:
            Q["ausnahme_text"] = ""
    con = _ro(db)
    try:
        Q["kurs"] = kurs_lesen(con, coin)
        try:
            if coin in CB.HB.COINS:
                Q["lage"] = {k: ({kk: vv for kk, vv in v.items() if kk != "verlauf"} if isinstance(v, dict) else v)
                             for k, v in CB.positionierung(coin, db, con, jetzt).items()}
            else:
                Q["lage"] = {"fehlt": [f"Für {coin} gibt es keine Binance-Positionierung."]}
        except Exception as e:
            Q["lage"] = {"fehlt": [f"Positionierung: {type(e).__name__}"]}
        if not schmal:
            try:
                import hl_fusion
                Q["kosten"] = hl_fusion.kostenschwelle(con, coin, jetzt) if con is not None else None
            except Exception as e:
                Q["fehlt"].append(f"Kostenschwelle: {type(e).__name__}: {e}"[:160])
            # 23.108 (U245 Stufe C2, Rest): drei gemessene Quellen aus der Datenbank des Recorders -- jede für sich
            for k_, fn_ in (("funding_hl", lambda: funding_hl_lesen(con, coin, jetzt)), ("taker", lambda: taker_lesen(con, coin)),
                            ("liqdichte", lambda: liqdichte_lesen(con, coin, jetzt))):
                try:
                    Q[k_] = fn_()
                except Exception as e:
                    Q[k_] = {"fehlt": [f"{type(e).__name__}: {e}"[:160]]}
    finally:
        if con is not None:
            con.close()
    if not schmal:
        try:                                                             # Stand des Magnet-Tests für die Karte „Liquidationsdichte“
            Q["magnet_satz"] = magnet_satz(*_magnet_lesen(coin, jetzt, store))
        except Exception as e:
            Q["magnet_satz"] = magnet_satz(None, f"({type(e).__name__})")
    try:
        if mit_ausblick_meldung:
            NL = AU.nutzlast(db, coin, None)                             # meldet dem Takt „Abschnitt offen“ (wie der Abschnitt Ausblick)
            Q["ausblick"] = {"prognose": NL.get("prognose"), "rueckblick": NL.get("rueckblick"), "fehlt": list(NL.get("fehlt") or [])}
        else:
            Q["ausblick"] = {"prognose": _prognose_lesen(db, coin), "rueckblick": G.get("rueckblick"), "fehlt": []}
    except Exception as e:
        Q["ausblick"] = {"fehlt": [f"Ausblick: {type(e).__name__}: {e}"[:160]]}
    try:
        import hl_volatil as VL
        vc = VL.lesen(VL.pfad(db))
        try:
            Q["vol"] = schwankung_lesen(vc, coin, jetzt)
        finally:
            if vc is not None:
                vc.close()
    except Exception as e:
        Q["vol"] = {"fehlt": [f"Volatilität: {type(e).__name__}: {e}"[:160]], "vi7_reihe": []}
    E = None
    try:
        if coin in CB.COINS and not schmal:
            E = CB._memo((db, coin, jetzt // TAG), lambda: CB.tagesteil(db, coin, jetzt))
            f = E.get("funding")
            Q["funding"] = {k: v for k, v in f.items() if _zahl(v) is not None} if isinstance(f, dict) else None
    except Exception:
        Q["funding"] = None
    if not schmal:                                                       # 23.110 (U269): Durchschnittslinien aus demselben Tagesteil des Chartbilds
        try:
            Q["linien"] = linien_lesen(E)
        except Exception as e:
            Q["linien"] = {"fehlt": [f"Durchschnittslinien: {type(e).__name__}: {e}"[:160]]}
        pt = CB.PRUEFSTAND.get("trend") or ("", "")
        Q["trend_beleg"] = f"Als Regel geprüft ({pt[0]}, Stand {CB.PRUEFSTAND_STAND}): {pt[1]}" if pt[1] else ""
    if coin == "ETH" and not schmal:                                     # 23.100 (U254): eigene staking.db, nur lesen
        try:
            import hl_staking as ST
            Q["unstaking"] = ST.nutzlast(ST.pfad(db), jetzt)
        except Exception as e:
            Q["unstaking"] = {"ok": False, "fehlt": [f"Unstaking: {type(e).__name__}: {e}"[:160]]}
        try:                                                             # 23.101 (U255): gespeichertes Urteil der Prüfung der Kursfolge
            import hl_staking_studie as SS
            Q["unstaking_pruefung"] = SS.kurz(SS.ST.pfad(db))
        except Exception:
            Q["unstaking_pruefung"] = None                               # dann steht in der Karte „noch nicht geprüft“
    return Q


def _prognose_lesen(db: str, coin: str) -> dict | None:
    """Jüngste Rechnung des Ausblicks für einen Coin, ohne dem Takt „Abschnitt offen“ zu melden (für den Streifen)."""
    import hl_ausblick as AU
    con = AU.lesen(AU.ausblick_pfad(db))
    if con is None:
        return None
    try:
        r = con.execute("SELECT json FROM au_prognose WHERE coin=? ORDER BY anker DESC, erzeugt DESC LIMIT 1", (coin,)).fetchone()
        return json.loads(r[0]) if r else None
    except (sqlite3.Error, ValueError):
        return None
    finally:
        con.close()


def gemeinsam_lesen(db: str, jetzt: int) -> dict:
    """Für alle Coins gleiche Quellen: Termine und Stand der Datentage (makro.db), Ausnahmen, Rückblick und Basis der Schockprüfung
    (ausblick.db), Kerzen des S&P-500-Perp (aktien.db; nur für die Frage, ob die Aktien-Regel geprüft wird), Wochenend-Faktor
    (volatil.db); seit 23.110 das Urteil der Niveau-Arten (U244, ausblick.db über hl_niveaus)."""
    G = {"fehlt": [], "termine": [], "naechste": {}, "datentag_stand": None, "termine_geladen": False, "ausnahmen": {},
         "wochenende_faktor": None, "rueckblick": None, "aktien_pruefung": None, "niveaus_urteil": None}
    try:                                                                 # 23.110: ohne lesbares Urteil nennen die Belege keines
        G["niveaus_urteil"] = niveaus_urteil_lesen(db)
    except Exception:
        pass
    try:
        import hl_makro as MK
        mp = MK.makro_pfad(db)
        d = MK.datentag_info(mp, jetzt)
        G["termine"] = d.get("termine") or []; G["datentag_stand"] = d.get("stand")
        mc = MK.lesen(mp)
        if mc is not None:
            try:
                u = MK.usa_termine(mc, jetzt)
                G["naechste"] = u.get("naechste") or {}; G["termine_geladen"] = bool(u.get("n"))
            finally:
                mc.close()
    except Exception as e:
        G["fehlt"].append(f"Termine: {type(e).__name__}: {e}"[:160])
    try:
        import hl_ausblick as AU
        ac = AU.lesen(AU.ausblick_pfad(db))
        if ac is not None:
            try:
                G["ausnahmen"] = AU._json_meta(ac, "ausnahme", {}) or {}
                R = AU.rueckblick_lesen(ac)
                if R:
                    G["rueckblick"] = {k: R.get(k) for k in ("stand", "s1", "s3", "s4")}
                basis = AU._json_meta(ac, "schock_basis", {}) or {}
                fs1 = basis.get("FS1"); basis_coins = list((basis.get("coins") or {}).keys())
                rechnung = _zahl(AU.meta(ac, "letzte_prognose", "0"))
            finally:
                ac.close()
            # Wird die Aktien-Regel (c) gerade geprüft? Dieselbe Reihe und dieselben Bedingungen wie hl_ausblick.schock_pruefen
            import hl_aktien as AK
            kn, kts = 0, None
            ak = AK.lesen(AK.aktien_pfad(db))
            if ak is not None:
                try:
                    K = AK.kerzen(ak, AKTIEN_REIHE, ab=jetzt - 8 * 3600)
                finally:
                    ak.close()
                if K is not None and len(K["ts"]):
                    kn, kts = int(len(K["ts"])), int(K["ts"][-1])
            G["aktien_pruefung"] = aktien_pruefung(fs1, kn, kts, rechnung, jetzt, basis_coins)
        else:
            G["aktien_pruefung"] = {"ok": False, "grund": "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt).", "kerze_ts": None,
                                    "rechnung_ts": None, "coins": []}
    except Exception as e:
        G["fehlt"].append(f"Ausblick (Ausnahmen): {type(e).__name__}: {e}"[:160])
    try:
        import hl_volatil as VL
        vc = VL.lesen(VL.pfad(db))
        if vc is not None:
            try:
                G["wochenende_faktor"] = wochenende_faktor(vc)
            finally:
                vc.close()
    except Exception:
        pass
    return G


def nutzlast(db: str, coin: str = "BTC", jetzt: int | None = None) -> dict:
    """Antwort für /cockpit: das volle Cockpit des gewählten Coins und der Streifen mit allen sechs."""
    jetzt = int(jetzt or time.time())
    coin = (coin or "BTC").upper()[:12]
    if coin not in COINS:
        return {"ok": False, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL, "fehlt": [f"{coin}: kein Cockpit (nur {', '.join(COINS)})"]}
    t0 = time.time()
    G = gemeinsam_lesen(db, jetzt)
    out = bauen(quellen_lesen(db, coin, jetzt, G, mit_ausblick_meldung=True))
    streifen = []
    for c in COINS:
        try:
            if c == coin:
                e = (out["spanne"]["h"] or {}).get("7"); p0 = out["spanne"].get("p0")
                streifen.append({"coin": c, "lo": (e["q"][1] / p0 - 1.0) if e and p0 else None, "hi": (e["q"][5] / p0 - 1.0) if e and p0 else None,
                                 "lampen": [l["zustand"] for l in out["lampen"]], "frisch": bool(out["spanne"].get("frisch"))})
            else:
                streifen.append(kern(c, quellen_lesen(db, c, jetzt, G, mit_ausblick_meldung=False, schmal=True)))
        except Exception as e:                                           # ein Coin darf den Streifen nicht verhindern
            streifen.append({"coin": c, "lo": None, "hi": None, "lampen": [], "frisch": False, "fehler": f"{type(e).__name__}"})
    out["streifen"] = streifen
    try:                                                                 # 23.108 (U245 Stufe C2, Rest): Betriebslampe -- für alle Coins gleich
        out["betrieb"] = betrieb_bauen(betrieb_lesen(db, jetzt), jetzt)
    except Exception as e:
        out["betrieb"] = {"zustand": "grau", "wort": "nicht prüfbar", "gruende": [], "zeilen": [], "stand": jetzt, "beleg": BELEG_BETRIEB,
                          "fehler": f"{type(e).__name__}: {e}"[:160]}
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return _ohne_nan(out)


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, dict):
        return {str(k): _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_ohne_nan(v) for v in x]
    try:
        import numpy as np
        if isinstance(x, np.generic):
            return _ohne_nan(x.item())
        if isinstance(x, np.ndarray):
            return [_ohne_nan(v) for v in x.tolist()]
    except ImportError:
        pass
    return x


def payload_json(db: str, coin: str = "BTC", jetzt: int | None = None) -> bytes:
    """/cockpit?coin=…: immer eine Antwort mit Grund, nie eine leere Seite."""
    try:
        return json.dumps(nutzlast(db, coin, jetzt), ensure_ascii=False, allow_nan=False).encode()
    except Exception as e:
        return json.dumps({"ok": False, "coin": coin, "version": VERSION_MODUL, "fehlt": [f"Cockpit: {type(e).__name__}: {e}"[:300]]},
                          ensure_ascii=False).encode()


# ================================================================================================ Kurs-Rechner: Quellen lesen, Antwort, Text

def _magnet_lesen(coin: str, jetzt: int, store: str | None = None) -> tuple:
    """(Modell, Grund): gespeicherte Rechnung des Magnet-Tests (learned coin/„magnet“ im Prognosespeicher) -- nur lesend geöffnet, sonst
    wie hl_magnet.modell_laden: höchstens hl_magnet.MODELL_ALTER alt (gezählt ab dem Speichern) und nur aus der Modellversion des Moduls."""
    import hl_magnet as MG
    sc = _ro(store or MG.F.STORE)
    if sc is None:
        return None, "Der Prognosespeicher fehlt noch."
    try:
        r = sc.execute("SELECT value, updated FROM learned WHERE coin=? AND key='magnet'", (coin,)).fetchone()
    except sqlite3.Error as e:
        return None, f"Der Prognosespeicher ist nicht lesbar ({type(e).__name__})."
    finally:
        sc.close()
    takt = "Er rechnet alle 6 Stunden im Dashboard, erstmals 20 Minuten nach dem Start."
    if not r:
        return None, f"Der Magnet-Test hat für {coin} noch nicht gerechnet. {takt}"
    if int(jetzt) - int(r[1] or 0) > MG.MODELL_ALTER:
        return None, f"Die letzte Rechnung des Magnet-Tests für {coin} ist älter als {MG.MODELL_ALTER // TAG} Tage (vom {_datum(r[1])}). {takt}"
    try:
        m = json.loads(r[0])
    except (TypeError, ValueError):
        return None, "Die Rechnung des Magnet-Tests ist nicht lesbar."
    if not isinstance(m, dict) or m.get("version") != MG.VERSION:
        return None, "Die Rechnung des Magnet-Tests stammt aus einer anderen Modellversion."
    if m.get("fehler"):
        return None, f"Der Magnet-Test meldet einen Fehler: {str(m['fehler'])[:120]}"
    return m, ""


def rechner_grundlage(db: str, coin: str, jetzt: int | None = None, store: str | None = None) -> dict:
    """
    Alles, was der Kurs-Rechner für einen Coin braucht -- nur lesen, jede Quelle für sich:
      kurs, kurs_ts, kurs_frisch   jüngste Minutenkerze des Recorders (frisch bis 5 Minuten)
      sig4                         Schwankung über 4 Stunden aus den 15-min-Renditen der letzten 7 Tage (hl_anker.Markt, wie im Magnet-Test)
      kurz {1h, 4h}                Nullmodell des Magnet-Tests je Frist: c, τ, Probe an Zufallsniveaus (innerhalb von 2 Standardfehlern)
      lauf                         Verteilung des laufenden Hochs und Tiefs aus der jüngsten Rechnung des Ausblicks (höchstens 2 Tage alt)
      s3                           Prüfung der Erreich-Wahrscheinlichkeiten im Rückblick des Ausblicks (über alle Coins zusammen)
      deckung {7, 14}              Trefferquote des 80-%-Bands für diesen Coin im Rückblick (S1), mit Standardfehler und Wertung
    Was fehlt, steht mit Grund in sig4_fehlt, kurz_fehlt und lauf_fehlt.
    """
    jetzt = int(jetzt or time.time())
    G = {"coin": coin, "jetzt": jetzt, "kurs": None, "kurs_ts": None, "kurs_frisch": False, "sig4": None, "sig4_fehlt": None, "kurz": {},
         "kurz_fehlt": {}, "lauf": None, "lauf_fehlt": None, "s3": {}, "deckung": {}, "sigma_geprueft": RECHNER_SIGMA_GEPRUEFT}
    con = _ro(db)
    try:
        K_ = kurs_lesen(con, coin)
        G["kurs"] = _zahl(K_.get("px")); G["kurs_ts"] = K_.get("ts")
        G["kurs_frisch"] = bool(G["kurs"] and G["kurs_ts"] is not None and jetzt - int(G["kurs_ts"]) <= FRISCH_KURS_S)
        if con is not None and G["kurs_frisch"]:
            try:
                import hl_anker
                G["sig4"] = _zahl(hl_anker.Markt(con, coin, jetzt - TAG, jetzt).sigma(jetzt))
            except Exception as e:
                G["sig4_fehlt"] = f"Schwankung über 4 Stunden: {type(e).__name__}: {e}"[:160]
            if not G["sig4"] and not G["sig4_fehlt"]:
                G["sig4_fehlt"] = ("Für die Schwankung über 4 Stunden fehlen Minutenkerzen (gebraucht werden die letzten 7 Tage, mindestens "
                                   "die Hälfte davon).")
    finally:
        if con is not None:
            con.close()
    try:
        import hl_magnet as MG
        G["sigma_geprueft"] = float(max(MG.ZUFALL_X))
        M, grund = _magnet_lesen(coin, jetzt, store)
    except Exception as e:
        M, grund = None, f"Magnet-Test: {type(e).__name__}: {e}"[:160]
    for key, name, kz, satzteil, zahl, einheit in RECHNER_FRISTEN:
        if einheit != "h":
            continue
        if M is None:
            G["kurz_fehlt"][key] = grund; continue
        m = (M.get("h") or {}).get(str(zahl)) or {}
        c, tau = _zahl(m.get("c0")), _zahl(m.get("tau0"))
        if m.get("zu_wenig") or c is None or tau is None or c <= 0 or tau < 0:
            G["kurz_fehlt"][key] = (f"Für das Nullmodell über {name} hat der Magnet-Test zu wenige Blöcke"
                                    + (f" ({m.get('n_bloecke')})" if m.get("n_bloecke") is not None else "") + ".")
            continue
        zf = [z for z in (m.get("zufall") or []) if isinstance(z, (list, tuple)) and len(z) >= 4 and all(_zahl(v) is not None for v in z[:4])]
        okz = [abs(z[2] - z[1]) <= 2 * z[3] for z in zf if z[3]]                  # dieselbe Regel wie hl_magnet.stand_text
        G["kurz"][key] = {"h": zahl, "c": c, "tau": tau, "zufall_ok": int(sum(okz)), "zufall_n": len(okz), "tage": _zahl(m.get("tage")),
                          "n_bloecke": m.get("n_bloecke"), "ts": M.get("ts")}
    try:
        import hl_ausblick as AU
        ac = AU.lesen(AU.ausblick_pfad(db))
        if ac is None:
            G["lauf_fehlt"] = "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."
        else:
            try:
                L = AU.lauf_lesen(ac, coin)
                R = AU.rueckblick_lesen(ac) or {}
            finally:
                ac.close()
            G["s3"] = (R.get("s3") or {}).get("h") or {}
            S1_ = (R.get("s1") or {}).get("h") or {}
            G["deckung"] = {h_: ((S1_.get(h_) or {}).get("deckung") or {}).get(coin) or {} for h_ in ("7", "14")}
            if L is None:
                G["lauf_fehlt"] = ("Die Verteilung für diese Fristen liegt noch nicht vor -- sie entsteht mit der nächsten Rechnung des "
                                   "Ausblicks (stündlich).")
            elif jetzt - int(L["anker"]) > FRISCH_AUSBLICK_S:
                G["lauf_fehlt"] = f"Die Rechnung des Ausblicks ist älter als 2 Tage (vom {_datum(L['anker'])})."
            else:
                G["lauf"] = L
    except Exception as e:
        G["lauf_fehlt"] = f"Ausblick: {type(e).__name__}: {e}"[:160]
    return G


def rechner_kurse(text) -> tuple:
    """„61500,58000.5“ -> ([61500.0, 58000.5], Zahl der unlesbaren Angaben). Das Skript schickt Zahlen mit Punkt; getrennt wird mit Komma
    oder Semikolon. Leere Stücke zählen nicht."""
    gut, schlecht = [], 0
    for t in str(text or "").replace(";", ",").split(","):
        t = t.strip()
        if not t:
            continue
        try:
            v = float(t)
        except ValueError:
            schlecht += 1; continue
        if math.isfinite(v):
            gut.append(v)
        else:
            schlecht += 1
    return gut, schlecht


def rechner_nutzlast(db: str, coin: str = "BTC", kurse=None, jetzt: int | None = None, store: str | None = None, abstaende=None) -> dict:
    """Antwort für /cockpit/rechner: je Kurs die Wahrscheinlichkeit, ihn in 1 und 4 Stunden, 7 und 14 Tagen zu berühren. abstaende (nur
    für den Debug-Text): statt fester Kurse Abstände zum jetzigen Kurs."""
    jetzt = int(jetzt or time.time())
    coin = (coin or "BTC").upper()[:12]
    if coin not in COINS:
        return {"ok": False, "coin": coin, "jetzt": jetzt, "version": VERSION_MODUL, "fehlt": [f"{coin}: kein Kurs-Rechner (nur {', '.join(COINS)})"]}
    t0 = time.time()
    G = rechner_grundlage(db, coin, jetzt, store)
    if kurse is None and abstaende and G.get("kurs_frisch") and G.get("kurs"):
        kurse = [G["kurs"] * (1.0 + float(a_)) for a_ in abstaende]
    out = rechner_bauen(G, kurse or [])
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return _ohne_nan(out)


def rechner_json(db: str, coin: str = "BTC", kurs_text: str = "", jetzt: int | None = None, store: str | None = None) -> bytes:
    """/cockpit/rechner?coin=…&kurs=…: immer eine Antwort mit Grund, nie eine leere Seite."""
    try:
        kurse, schlecht = rechner_kurse(kurs_text)
        d = rechner_nutzlast(db, coin, kurse, jetzt, store)
        if schlecht and d.get("ok"):
            d["hinweise"] = list(d.get("hinweise") or []) + [f"{schlecht} Angabe{'n' if schlecht != 1 else ''} der Anfrage nicht lesbar."]
        return json.dumps(d, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()
    except Exception as e:
        return json.dumps({"ok": False, "coin": coin, "version": VERSION_MODUL, "fehlt": [f"Kurs-Rechner: {type(e).__name__}: {e}"[:300]]},
                          ensure_ascii=False).encode()


def rechner_text(R: dict | None) -> list:
    """Zeilen für den Debug-Text (Debug 143): Beispielkurse um den jetzigen Kurs mit ihren Wahrscheinlichkeiten, dazu Gründe, Hinweise und
    die Belege des Coins. Der allgemeine Beleg steht einmal am Ende des Texts."""
    if not R or R.get("ok") is False:
        return ["   Kurs-Rechner: kein Wert -- " + " ".join((R or {}).get("fehlt") or ["Grund unbekannt"])]
    Z = []
    gut = [z for z in R.get("zeilen") or [] if z.get("ok")]
    if gut:
        Z.append(f"   Kurs-Rechner (vom jetzigen Kurs {_px(R.get('kurs'))} aus; Wahrscheinlichkeit, berührt zu werden; Spalten: "
                 + " · ".join(f[2] for f in R.get("fristen") or []) + "):")
        for z in gut:
            abst = "jetziger Kurs" if not z["abstand_text"] else _pc(z["abstand"], _rechner_stellen(z["abstand"]), True)
            Z.append(f"   Kurs-Rechner {z['px_text']:>10} {abst:>9}  " + " · ".join(f"{t_:>9}" for t_ in z["p_text"])
                     + ("   (" + " ".join(z["hinweise"]) + ")" if z["hinweise"] else ""))
    Z += [f"   Kurs-Rechner {z.get('px_text') or '—'}: {z.get('grund') or 'kein Wert'}" for z in R.get("zeilen") or [] if not z.get("ok")]
    Z += [f"   Kurs-Rechner fehlt: {f_}" for f_ in R.get("fehlt") or []]
    Z += [f"   Kurs-Rechner Hinweis: {h_}" for h_ in R.get("hinweise") or []]
    Z += [f"   Kurs-Rechner Beleg: {b_}" for b_ in R.get("belege") or []]
    return Z or ["   Kurs-Rechner: kein Wert"]


# ================================================================================================ Seite ordnen (Cockpit oben, Werkstatt, Betrieb)

# Reihenfolge der Abschnitte der Hauptseite (Entscheidungen des Nutzers vom 12.11.2026): oben das Cockpit, darunter die bisherigen
# Abschnitte; was keinen bestandenen Test hat, steht in der eingeklappten Gruppe „Werkstatt“; Netzwerk, Aktualisierung, Debug und
# System bilden die Gruppe „Betrieb“. Ein Abschnitt steigt auf, indem sein Schlüssel von SEITE_WERKSTATT nach SEITE_HAUPT wandert --
# erst nach einem bestandenen, vorab festgelegten Test (KONZEPT_Cockpit.md 8). Der Text der Abschnitte in hl_viz bleibt unberührt.
SEITE_HAUPT = ("chart", "chartbild", "ausblick", "volatil", "notbremse", "makro", "prognosemarkt", "orders", "heat", "depth")
SEITE_WERKSTATT = ("signal", "forecast", "familien", "labor", "whales", "leaderboard", "lbact", "lbact48", "pool")
SEITE_BETRIEB = ("network", "update", "debug", "system")
SEITE_NAMEN = {"network": "Netzwerk", "cockpit": "Cockpit"}
_PANEL = '<div class="panel" id="sec-'
_ENDE = '<div id="taskbar"'
_KPI = '<div class="kpi" id="kpi"></div>\n'

COCKPIT_PANEL = """<div class="panel" id="sec-cockpit" data-sec="cockpit">
 <h2 class="sech" onclick="toggleSec('cockpit')"><span class="num">CK</span><span class="ttl">Cockpit — Spanne, Risiko, Levels</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Das Cockpit zeigt nur, was einen vorab festgelegten Test bestanden hat (farbige Lampen) oder
  sauber gemessen ist (blau, ohne Wertung). Jede Anzeige nennt ihren Beleg und ihren Stand; ist eine Quelle zu alt, wird die Anzeige
  blass und sagt das. Formen der Lampen: Ring = aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert. Die Richtung
  des Kurses ist für kein Zeitfenster belegt -- deshalb gibt es hier keinen Pfeil. Spanne und Levels stammen aus dem Abschnitt
  „Ausblick“, die Schwankung aus „Volatilität“, die Kontenquote aus „Chartbild“, die Kosten aus der Kostenschwelle der Fusion; das
  Cockpit rechnet nichts Neues außer dem Kurs-Rechner: Er zeigt für einen eingetippten Kurs, wie wahrscheinlich er vom jetzigen Kurs aus
  in 1 und 4 Stunden, 7 und 14 Tagen berührt wird -- allein aus Abstand und Schwankung, nicht aus einer Richtung; gemerkte Kurse bleiben
  in diesem Browser. Bei ETH zeigt die Karte „Unstaking“ die angemeldeten Abzüge aus dem Ethereum-Staking mit ihrem Termin
  (an der Kette gemessen; ob danach der Kurs fällt, klärt eine vorab festgelegte Prüfung -- ihr Urteil steht in der Karte), und die
  Karte „Unstaking · Verlauf“ die Schlange der Abzüge und den ETH-Kurs je Tag mit den Wellen dieser Prüfung als Marken. Ein Streifen mit allen sechs Coins schaltet den Coin der ganzen Seite um. Was keinen bestandenen
  Test hat, steht weiter unten in der „Werkstatt“.</div>
 <div id="ckbody"><div class="sub">lädt …</div></div>
 </div>
</div>

"""
WERKSTATT_TEXT = ("Hier steht, was keinen bestandenen Test hat oder noch geprüft wird: die Prognose der Richtung mit ihren Preisen, die "
                  "Konfluenz, Wale und Bestenlisten als Richtungsanzeiger, das TradeLabor (sein Kostenmodell wird gerade gegen die Börse "
                  "gemessen) und die bisherige Kennzahlenleiste. Alles arbeitet unverändert weiter -- es steht nur nicht mehr in der "
                  "Hauptansicht. Ein Abschnitt kommt nach oben, sobald er einen vorab festgelegten Test besteht.")
BETRIEB_TEXT = "Netzwerk, Aktualisierung, Debug und System mit Backup und Speicherorten."
GRUPPEN_CSS = """<style id="grp_css">
 .gruppe{margin-top:30px;border-top:1px solid #30363d;padding-top:12px}
 h2.grph{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin:0;min-height:44px}
 h2.grph .ttl{flex:1} h2.grph .grpz{font-size:11px;font-weight:400;color:#8b949e} h2.grph .chev{color:#8b949e;font-size:12px;transition:transform .15s;flex:none}
 .gruppe.zu .grpbody{display:none} .gruppe.zu h2.grph .chev{transform:rotate(-90deg)}
 .gruppe .grptext{margin:6px 0 0;max-width:900px}
 .gruppe{scroll-margin-top:96px} .nav a.grp{border-style:dashed}
 @media (max-width:700px){ .gruppe{scroll-margin-top:120px} }
</style>
"""
# Einmalig beim ersten Laden nach dem Umbau: bisherige Abschnitte eingeklappt, Cockpit offen, beide Gruppen zu. Muss VOR applySec() laufen.
ERSTLAUF_JS = """<script>
// 23.98 (U245 Stufe C1): einmal je Browser -- das Cockpit steht oben, alles Bisherige eingeklappt darunter (Entscheidung des Nutzers 12.11.2026)
try{ if(!localStorage.getItem('hl_cockpit_v1')){ var st_={}; %s.forEach(function(k){ st_[k]=true; }); st_.cockpit=false;
 localStorage.setItem('hl_sec', JSON.stringify(st_)); localStorage.setItem('hl_grp', JSON.stringify({werkstatt:true, betrieb:true}));
 localStorage.setItem('hl_cockpit_v1', String(Date.now())); } }catch(e){}
</script>
"""
GRUPPEN_JS = """<script>
// 23.98 (U245 Stufe C1): Gruppen „Werkstatt“ und „Betrieb“ ein- und ausklappen, Zustand im Browser gemerkt (hl_grp: true = zu).
function grpZustand(){ try{ return JSON.parse(localStorage.getItem('hl_grp')||'{}'); }catch(e){ return {}; } }
function grpAnwenden(){ const st=grpZustand(); document.querySelectorAll('.gruppe[data-grp]').forEach(g=>g.classList.toggle('zu', st[g.dataset.grp]!==false)); }
function grpNeuZeichnen(g){ setTimeout(()=>{ try{ if(typeof load==='function') load(); }catch(e){}
  const lab=g.querySelector('#sec-labor'); if(lab&&!lab.classList.contains('closed')&&typeof laborLaden==='function'){ try{ laborLaden(true); }catch(e){} } }, 60); }
function grpSchalten(k, auf){ const g=document.getElementById('grp-'+k); if(!g) return;
 const zu=auf===true?false:!g.classList.contains('zu'); g.classList.toggle('zu', zu);
 const st=grpZustand(); st[k]=zu; try{ localStorage.setItem('hl_grp', JSON.stringify(st)); }catch(e){}
 if(!zu) grpNeuZeichnen(g); }
function grpOeffneFuer(id){ const el=document.getElementById(id); if(!el) return; const g=el.closest('.gruppe'); if(g&&g.classList.contains('zu')) grpSchalten(g.dataset.grp, true); }
// Ein Link auf einen Abschnitt klappt ihn auch auf (seit dem Umbau sind die bisherigen Abschnitte zunächst eingeklappt)
function grpAbschnittAuf(id){ const p=document.getElementById(id); if(!p||!p.classList.contains('panel')||!p.classList.contains('closed')||!p.dataset.sec||typeof toggleSec!=='function') return;
 toggleSec(p.dataset.sec); if(p.dataset.sec==='cockpit'&&typeof ckLaden==='function') setTimeout(()=>ckLaden(true),80); }
document.addEventListener('click', e=>{ const a=e.target&&e.target.closest?e.target.closest('a[href^="#sec-"],a[href^="#grp-"]'):null; if(!a) return;
 const id=a.getAttribute('href').slice(1); if(id.indexOf('grp-')===0) grpSchalten(id.slice(4), true); else { grpOeffneFuer(id); grpAbschnittAuf(id); } }, true);
grpAnwenden();
if(location.hash&&location.hash.length>1) grpOeffneFuer(location.hash.slice(1));
</script>
"""


def _gruppe(key: str, titel: str, text_: str, inhalt: str, n: int) -> str:
    return (f'<div class="gruppe zu" id="grp-{key}" data-grp="{key}">\n'
            f' <h2 class="grph" onclick="grpSchalten(\'{key}\')"><span class="ttl">{titel}</span>'
            f'<span class="grpz">{n} Abschnitte</span><span class="chev">▾</span></h2>\n'
            f' <div class="grpbody">\n <div class="sub grptext">{text_}</div>\n{inhalt}</div>\n</div>\n\n')


def seite_ordnen(html: str) -> str:
    """
    Die Hauptseite neu ordnen: Cockpit oben, bisherige Abschnitte darunter, Gruppen „Werkstatt“ (mit der Kennzahlenleiste) und
    „Betrieb“; neue Navigationsleiste; Skript /cockpit.js. Arbeitet auf dem fertigen Seitentext von hl_viz und ändert keinen Abschnitt.
    Zweimal angewendet = einmal angewendet. Jede Abweichung vom erwarteten Aufbau ist ein ValueError (hl_viz liefert dann die
    ungeordnete Seite aus und meldet es).
    """
    import re
    if 'id="sec-cockpit"' in html:
        return html
    for marke, n in ((_KPI, 1), (_ENDE, 1), ("</head>", 1), ("<body>", 1), ("</body></html>", 1)):
        if html.count(marke) != n:
            raise ValueError(f"Seite: Marke {marke.strip()[:30]!r} {html.count(marke)}-mal statt {n}-mal")
    i0 = html.find(_PANEL); i1 = html.find(_ENDE)
    if i0 < 0 or i1 < i0 or html.find(_KPI) > i0:
        raise ValueError("Seite: Abschnitte oder Kennzahlenleiste nicht an der erwarteten Stelle")
    kopf, region, rest = html[:i0], html[i0:i1], html[i1:]
    starts = [m.start() for m in re.finditer(re.escape(_PANEL), region)] + [len(region)]
    bloecke: dict = {}
    for a, b in zip(starts, starts[1:]):
        blk = region[a:b]
        key = re.match(re.escape(_PANEL) + r'(\w+)" data-sec="(\w+)"', blk)
        if not key or key.group(1) != key.group(2):
            raise ValueError(f"Seite: Abschnitt ohne Schlüssel bei Zeichen {i0 + a}")
        if key.group(1) in bloecke:
            raise ValueError(f"Seite: Abschnitt {key.group(1)} doppelt")
        if len(re.findall(r"<div\b", blk)) != blk.count("</div>"):
            raise ValueError(f"Seite: Abschnitt {key.group(1)} ist nicht in sich geschlossen (div)")
        bloecke[key.group(1)] = blk
    bekannt = set(SEITE_HAUPT) | set(SEITE_WERKSTATT) | set(SEITE_BETRIEB)
    haupt = [k for k in SEITE_HAUPT if k in bloecke] + [k for k in bloecke if k not in bekannt]       # Unbekanntes bleibt sichtbar
    werk = [k for k in SEITE_WERKSTATT if k in bloecke]; betr = [k for k in SEITE_BETRIEB if k in bloecke]
    # Navigationsleiste: Namen aus der bisherigen Leiste
    nav = re.search(r'<nav class="nav">.*?</nav>', kopf, re.S)
    if not nav:
        raise ValueError("Seite: Navigationsleiste fehlt")
    namen = dict(SEITE_NAMEN)
    for m in re.finditer(r'<a href="#sec-(\w+)"[^>]*>(.*?)</a>', nav.group(0)):
        namen[m.group(1)] = m.group(2)
    link = lambda k, kl="": f'<a href="#sec-{k}"{kl}>{namen.get(k, k)}</a>'
    nav_neu = ('<nav class="nav">\n  ' + link("cockpit") + "".join(link(k) for k in haupt)
               + '\n  <a href="#grp-werkstatt" class="dim grp" title="Abschnitte ohne bestandenen Test">Werkstatt</a>' + "".join(link(k, ' class="dim"') for k in werk)
               + '\n  <a href="#grp-betrieb" class="dim grp" title="Netzwerk, Aktualisierung, Debug, System">Betrieb</a>' + "".join(link(k, ' class="dim"') for k in betr)
               + '\n  <a class="dim" onclick="toggleAll()" style="margin-left:auto" title="alle Abschnitte ein- oder ausklappen">alle ▾/▸</a>\n </nav>')
    kopf = kopf.replace(nav.group(0), nav_neu).replace(_KPI, "")
    einleitung = re.search(r'<div class="sub" style="margin:8px 0 0">Echte Positionen.*?</div>\n', kopf, re.S)   # der Hinweis zur Seite: unter das Cockpit
    if einleitung and "<div" not in einleitung.group(0)[5:]:
        kopf = kopf.replace(einleitung.group(0), "")
    else:
        einleitung = None
    kopf = kopf.replace("</head>", GRUPPEN_CSS + "</head>").replace("<body>", "<body>\n" + ERSTLAUF_JS % json.dumps(sorted(bloecke)))
    mitte = (COCKPIT_PANEL + (einleitung.group(0) + "\n" if einleitung else "") + "".join(bloecke[k] for k in haupt)
             + _gruppe("werkstatt", "Werkstatt · nicht belegt", WERKSTATT_TEXT, _KPI + "".join(bloecke[k] for k in werk), len(werk))
             + _gruppe("betrieb", "Betrieb", BETRIEB_TEXT, "".join(bloecke[k] for k in betr), len(betr)))
    rest = rest.replace("</body></html>", GRUPPEN_JS + '<script src="/cockpit.js"></script></body></html>')
    return kopf + mitte + rest


# ================================================================================================ Text (Debug-Lauf)

def text(db: str, coins=COINS, jetzt: int | None = None, store: str | None = None, betrieb: dict | None = None) -> str:
    """Das Cockpit als Text: je Coin dieselben Zahlen wie auf der Seite, mit Stand und Beleg. store (nur Selbsttest): Prognosespeicher,
    aus dem der Kurs-Rechner das Nullmodell des Magnet-Tests liest (sonst der des Dashboards). betrieb (nur Selbsttest): gelesene
    Quellen der Betriebslampe in der Form von betrieb_lesen statt der Abfrage dieses Rechners."""
    jetzt = int(jetzt or time.time())
    Z = []; a = Z.append
    a(f"★ Cockpit (U245) · Modul {VERSION_MODUL} · {_datum(jetzt)} · Spanne, Risiko und Wahrscheinlichkeiten, keine Richtung")
    a("Lampen: aus · Hinweis · Warnung · grau (kein Wert). Schwellen: Kontenquote ≥ 3; Termin 24 h davor bis 2 h danach; Schwankung ab "
      f"dem {int(SCHWANKUNG_GELB * 100)}. Perzentil Hinweis, ab dem {int(SCHWANKUNG_ROT * 100)}. Warnung; Aktien = Ausnahmelage (c) des Ausblicks. "
      "Ohne frische Quelle oder ohne laufende Prüfung ist eine Lampe grau, nicht aus.")
    G = gemeinsam_lesen(db, jetzt)
    belege: list = []
    rechner_allg = ""
    linien_beleg = ""
    for c in coins:
        try:
            d = _ohne_nan(bauen(quellen_lesen(db, c, jetzt, G, mit_ausblick_meldung=False, store=store)))
        except Exception as e:
            a(""); a(f"== {c}: {type(e).__name__}: {e}"); continue
        if not belege:
            belege = list(dict.fromkeys(l["beleg"] for l in d["lampen"]))
        k = d["kopf"]
        a("")
        a(f"== {c} · Kurs {_px(k['kurs'])} ({'frisch' if k['frisch'] else 'nicht frisch'}, Stand {_datum(k['kurs_ts'])})")
        a(f"   {d['satz']['text']} {d['satz']['zusatz']}")
        if d["satz"].get("ausnahme"):
            a(f"   {d['satz']['ausnahme']}")
        for l in d["lampen"]:
            a(f"   Lampe {l['name']:<11} {l['zustand']:<8} {l['wert']} -- {l['detail']}"
              + (f" Zeitpunkt: {_datum(l['ts'])}." if l["key"] == "termin" and l.get("ts") else ""))
        s = d["schwankung"]
        a(f"   Schwankung: erwartet 7 T {_de(s['erwartet'])} % p. a. ({s.get('modell') or 'keine Prognose'}), realisiert 7 T {_de(s['real7'])} · "
          f"30 T {_de(s['real30'])} · DVOL {_de(s['dvol'])} · Perzentil {('—' if s['pz'] is None else str(pz_zahl(s['pz'])) + '.')} "
          f"({s.get('pz_von') or '—'}) · in 4 h typisch ± {_pc(s['er4'], 2)}" + (f" · {s['stand_text']}" if s.get("stand_text") else "")
          + ("" if s.get("frisch") or s.get("stand_tag") is None else " -- NICHT FRISCH"))
        sp = d["spanne"]
        for h in ("7", "14", "28"):
            e = (sp["h"] or {}).get(h)
            if e:
                q = e["q"]
                a(f"   Spanne {h:>2} T: 90 % {_px(q[0])}–{_px(q[6])} · 80 % {_px(q[1])}–{_px(q[5])} · 50 % {_px(q[2])}–{_px(q[4])} · {e['vermerk']}"
                  + (f" · Vorsprung {e['vorsprung']}" if e.get("vorsprung") else ""))
        a(f"   Stand der Spanne: Anker {_datum(sp.get('anker'))}, Kurs am Anker {_px(sp.get('p0'))}" + ("" if sp.get("frisch") else " -- NICHT FRISCH"))
        if sp.get("beleg"):
            a(f"   Beleg der Spanne: {sp['beleg']}")
        lv = d["levels"]
        for seite, liste in (("oben", lv["oben"]), ("unten", lv["unten"])):
            for n in liste:
                a(f"   Level {seite:<5} {n['name'][:40]:<40} {_px(n['px']):>10} {_pc(n['abstand'], 1, True):>8}  1 W {_de(n['p7'] * 100, 0)} % · "
                  f"2 W {_de(n['p14'] * 100, 0)} %" + ("  (Momentaufnahme)" if n["momentaufnahme"] else ""))
        if lv.get("durchlaufen"):
            a(f"   {lv['durchlaufen']} Niveau(s) seit dem Anker durchlaufen -- nicht mehr gezeigt")
        Z.extend(linien_text(d.get("linien")))                           # 23.110 (U269): dieselben Zahlen wie die Karte „Durchschnittslinien“
        linien_beleg = linien_beleg or (d.get("linien") or {}).get("beleg") or ""
        try:                                                             # 23.105: dieselbe Rechnung wie /cockpit/rechner, für feste Abstände zum Kurs
            RK = rechner_nutzlast(db, c, None, jetzt, store, abstaende=RECHNER_TEXT_ABSTAENDE)
            Z.extend(rechner_text(RK))
            rechner_allg = rechner_allg or RK.get("beleg_allg") or ""
        except Exception as e:
            a(f"   Kurs-Rechner: {type(e).__name__}: {e}"[:200])
        for m in d["messwerte"]:
            stand_m = _datum(m["stand"]) if m.get("stand") else (f"Tagesstand {m['stand_tag']}" if m.get("stand_tag") else "ohne Stand")
            a(f"   Messwert {m['name']:<34} {m['text'] or '—':<16} Perzentil {('—' if m['pz'] is None else str(pz_zahl(m['pz'])) + '.')} "
              + ("(kein Wert" + (f": {m['fehlt']}" if m.get("fehlt") else "") + ")" if m.get("wert") is None
                 else f"({m['art'] or '—'}; {stand_m}" + (f"; {'gegen ' if m['pz'] is not None else ''}{m['basis']}" if m.get("basis") else "") + ")"))
        Z.extend(liqdichte_text(d.get("liqdichte")))                     # 23.108: dieselben Zahlen wie die Karte „Liquidationsdichte“
        for z in d["kosten"]["zeilen"]:
            a(f"   Kosten {z['h']:>2} h: mittlere Bewegung {_pc(z['er'], 2)} -> nötige Trefferquote Taker {_pc(z['taker'], 1)} · Maker {_pc(z['maker'], 1)}")
        if d["kosten"]["zeilen"]:
            a(f"   Stand der Kosten: {_datum(d['kosten'].get('stand'))}, mittlere Bewegung der letzten {d['kosten'].get('tage') or '—'} Tage")
        un = d.get("unstaking")
        if un is not None and not un["ok"]:
            a("   Unstaking: kein Wert -- " + " ".join(un["fehlt"] or ["Grund unbekannt"]))
        elif un is not None:
            a(f"   Unstaking: {_eth(un['summe_eth'])} ETH angemeldet" + (f" (≈ {un['usd_text']})" if un.get("usd_text") else "")
              + (f", alles frei bis {_datum(un['ende_ts'])}" if un.get("ende_ts") else ", nichts steht aus") + f" · {un['satz']}"
              + f" · Quelle {'Beacon-Knoten' if un['quelle'] == 'knoten' else 'Tagesdatei, geschätzt'}, Stand {_datum(un['stand'])}")
            if un["tage"]:
                a("   Unstaking Kalender „frei ab“ (UTC-Tage, ETH): " + " · ".join(f"{t_['tag']} {_eth(t_['eth'])}" + ("*" if t_["gross"] else "") for t_ in un["tage"])
                  + (f" · später {_eth(un['tage_mehr_eth'])} an {un['tage_mehr']} Tagen" if un["tage_mehr"] else "") + "   (* = Tag ab " + _eth(un["schwelle"]) + " ETH)")
            for z_ in un["abzieher"]:
                a(f"   Unstaking Abzieher: {z_['adresse']} {_eth(z_['eth'])} ETH" + (f" ({_de(z_['anteil'] * 100, 0)} % der Vollabzüge)" if z_.get("anteil") is not None else "")
                  + f", frei {z_['von']} bis {z_['bis']}")
            for z_ in (un.get("nicht_gezaehlt"), un.get("gegenseite")):
                if z_:
                    a(f"   Unstaking: {z_}")
        if un is not None:
            a("   Unstaking, Prüfung der Kursfolge (U255): " + un["pruefung"]["kurz"])
            for z_ in un["hinweise"]:
                a(f"   Unstaking Hinweis: {z_}")
            Z.extend(verlauf_text(verlauf_nutzlast(db, jetzt)))               # 23.104 (U260): dieselbe Antwort wie /cockpit/unstaking
        for f in list(dict.fromkeys((d.get("fehlt") or []) + sp["fehlt"] + s["fehlt"] + lv["fehlt"] + d["kosten"]["fehlt"])):
            a(f"   fehlt: {f}")
    a("")
    if rechner_allg:
        a("Kurs-Rechner: " + rechner_allg)
    a("Belege: " + (" | ".join(belege) if belege else "—"))
    a("Messwerte: " + BELEG_MESSWERT + " Taker-Varianz: " + TAKER_NOTE)
    if linien_beleg:
        a("Durchschnittslinien: " + linien_beleg)
    try:                                                                 # 23.108: Betriebslampe -- im Text ohne Wartezeit (ein Lauf sieht jeden Dienst nur einmal)
        Z.extend(betrieb_text(betrieb_bauen(betrieb if betrieb is not None else betrieb_lesen(db, jetzt), jetzt, {}, 0)))
        a("   In der Pille der Seite stehen dazu die Hinweise des Abschnitts System (Backup fehlgeschlagen, Platz am Ziel, Datenbank).")
    except Exception as e:
        a(f"Betrieb: {type(e).__name__}: {e}"[:200])
    ap = G.get("aktien_pruefung") or {}
    a("Aktien-Regel des Ausblicks: " + ("wird geprüft" if ap.get("ok") else "wird NICHT geprüft -- " + (ap.get("grund") or "Grund unbekannt"))
      + f" (letzte Kerze des S&P-500-Perp {_datum(ap.get('kerze_ts'))}, letzte Rechnung des Ausblicks {_datum(ap.get('rechnung_ts'))})")
    return "\n".join(Z)


# ================================================================================================ Selbsttest

def _probe_quellen(jetzt: int, coin: str = "BTC") -> dict:
    """Quellen von Hand, in der Form der echten Module (hl_ausblick.nutzlast, hl_chartbild.positionierung, hl_fusion.kostenschwelle)."""
    p0 = 60_000.0
    q7 = [p0 * f for f in (0.88, 0.90, 0.95, 1.00, 1.05, 1.10, 1.13)]
    sp = {"7": {"q": q7, "pct": [x / p0 - 1 for x in q7]},
          "14": {"q": [p0 * f for f in (0.84, 0.87, 0.93, 1.00, 1.07, 1.14, 1.18)]},
          "28": {"q": [p0 * f for f in (0.78, 0.82, 0.90, 1.00, 1.11, 1.22, 1.28)]}}
    niveaus = [{"name": "runde Zahl (5.000er-Schritt)", "px": 65_000.0, "art": "rund", "momentaufnahme": False,
                "p": {"7": [0.52, 0.27], "14": [0.66, 0.33], "28": [0.76, 0.34]}},
               {"name": "Swing-Hoch", "px": 61_000.0, "art": "swing", "momentaufnahme": False, "p": {"7": [0.90, 0.5], "14": [0.94, 0.5], "28": [0.97, 0.5]}},
               {"name": "Buy-Stops", "px": 60_500.0, "art": "orders", "momentaufnahme": True, "p": {"7": [0.95, 0.5], "14": [0.97, 0.5], "28": [0.99, 0.5]}},
               {"name": "Bein 10 %", "px": 68_000.0, "art": "bein", "momentaufnahme": False, "p": {"7": [0.21, 0.1], "14": [0.39, 0.2], "28": [0.52, 0.2]}},
               {"name": "weit oben", "px": 72_000.0, "art": "rund", "momentaufnahme": False, "p": {"7": [0.05, 0.02], "14": [0.12, 0.05], "28": [0.25, 0.1]}},
               {"name": "200-Tage-Linie", "px": 58_000.0, "art": "ma200", "momentaufnahme": False, "p": {"7": [0.61, 0.3], "14": [0.72, 0.4], "28": [0.80, 0.4]}},
               {"name": "Sell-Stops", "px": 59_500.0, "art": "orders", "momentaufnahme": True, "p": {"7": [0.93, 0.5], "14": [0.96, 0.5], "28": [0.98, 0.5]}},
               {"name": "ohne Wahrscheinlichkeit", "px": 59_000.0, "art": "x", "p": None}]
    def dk(**werte):                                                 # Deckung je Coin: (Trefferquote, Standardfehler) -> wie hl_ausblick.s1_breite
        return {c: {"d80": t, "se": se, "ok": bool(abs(t - 0.80) <= 2 * se)} for c, (t, se) in werte.items()}
    # Zahlen und Urteile des Pi (Debug 73 vom 11.11.2026): bei 7 Tagen ist der Vorsprung belegt, das Band von BTC aber zu weit --
    # die Gesamtprüfung S1 lautet für alle drei Horizonte „besteht nicht“. Zwei Werte sind um 0,001 verschoben (BTC 14 Tage 84,5 ->
    # 84,6; XMR 28 Tage 84,5 -> 84,6), damit die Rundung auf ganze Prozent in den Proben eindeutig ist.
    R = {"stand": jetzt - 3 * TAG,
         "s1": {"h": {"7": {"gewinn_rel": 0.015, "p": 0.002, "besteht": False,
                            "deckung": dk(BTC=(0.840, 0.017), ETH=(0.804, 0.016), HYPE=(0.807, 0.036), PAXG=(0.674, 0.039), XMR=(0.829, 0.017), ZEC=(0.790, 0.017))},
                      "14": {"gewinn_rel": 0.004, "p": 0.181, "besteht": False,
                             "deckung": dk(BTC=(0.846, 0.020), ETH=(0.801, 0.021), HYPE=(0.845, 0.052), PAXG=(0.660, 0.045), XMR=(0.824, 0.024), ZEC=(0.786, 0.024))},
                      "28": {"gewinn_rel": -0.007, "p": 0.804, "besteht": False,
                             "deckung": dk(BTC=(0.834, 0.033), ETH=(0.786, 0.035), HYPE=(0.822, 0.067), PAXG=(0.580, 0.054), XMR=(0.846, 0.026), ZEC=(0.777, 0.037))}}},
         "s3": {"h": {"7": {"n": 15412, "skill": 0.062, "steigung": 0.96, "besteht": True}}},
         "s4": {"besteht": True, "variogramm": {"p": 0.003}}}
    vi7 = [30.0 + (i * 37 % 100) * 0.4 for i in range(PERZ_TAGE + 30)]            # 30,0 … 69,6, alle Werte mehrfach
    return {"coin": coin, "jetzt": jetzt, "fehlt": [], "konten_schwelle": 3.0, "konten_beleg": "Konten ≥ 3: belegt (Probe).",
            "ausnahme_dauer": TAG, "kurs": {"px": 60_200.0, "ts": jetzt - 30, "quelle": "Probe"},
            "ausblick": {"prognose": {"coin": coin, "anker": jetzt - 1800, "p0": p0, "spannen": sp, "niveaus": niveaus}, "rueckblick": R, "fehlt": []},
            "vol": {"erwartet": 45.7, "real7": 44.0, "real30": 36.0, "dvol": 39.5, "v1": "belegt", "v1_p_holm": 0.0292, "bis": jetzt // TAG - 1,
                    "ursprung": jetzt // TAG - 1, "modell_text": "M (log-HAR)", "vi7_reihe": vi7, "fehlt": []},
            "kosten": {"ts": jetzt - 600, "tage": 30, "taker": 0.00045, "maker": 0.00015, "halbspread_bps": 0.1, "er_4": 0.0051, "er_24": 0.0131,
                       "p_taker_4": 0.589, "p_maker_4": 0.529, "p_taker_24": 0.535, "p_maker_24": 0.511},
            "termine": [], "naechste": {"Verbraucherpreise": jetzt + 20 * TAG, "Arbeitsmarktbericht": jetzt + 9 * TAG, "Erstanträge": jetzt + TAG},
            "datentag_stand": {"erzeugt": jetzt - 5 * TAG, "von": "2020-01-01", "H1": {"belegt": True, "abs_verh": 2.45}, "H2": {"belegt": True, "abs_verh": 1.9}},
            "termine_geladen": True, "wochenende_faktor": 0.68,
            "aktien_pruefung": aktien_pruefung(0.0001, 16, jetzt - 1500, jetzt - 1900, jetzt),
            "lage": {"fehlt": [], "oi": {"wert": 109_231.0, "ts": jetzt - 300, "art": "live", "pz": 0.52},
                     "konten": {"wert": 1.57, "ts": jetzt - 300, "art": "live", "pz": 0.22}},
            "funding": {"rate": 0.00022, "rate_ts": jetzt - 3600, "z": 0.69, "tag": jetzt // TAG - 1},
            # 23.108 (Rest von Stufe C2), in der Form von funding_hl_lesen, taker_lesen und liqdichte_lesen: 1.600 Stundenwerte in zehn
            # gleich großen Klassen (0,00025 … 0,0025 %/h), der jüngste Wert 0,0024 %/h liegt über neun Klassen -> 90. Perzentil
            "funding_hl": {"wert": 2.4e-5, "ts": jetzt - 40, "fehlt": [],
                           "reihe": [(jetzt // 3600 * 3600 - 3600 * i, (i % 10 + 1) * 2.5e-6) for i in range(1600)]},
            "taker": {"pz": 0.0716, "ts": jetzt // 3600 * 3600, "fehlt": []},
            # Zellen der Heatmap zum Kurs 60.200: (Preis, Seite, USD, Positionen) -- drei Long-Zellen darunter, drei Short-Zellen darüber,
            # zwei auf der falschen Seite (überholt), zwei jenseits von 3 %
            "liqdichte": {"ts": jetzt - 240, "fehlt": [], "abdeckung": {"anteil": 0.27, "erfasst": 540.0, "oi": 1000.0},
                          "positionen": {"drin": 22_324.0, "alt": 128_273.0, "alter_median_s": 990_000.0},
                          "zeilen": [(60_200.0 * 0.996, "long", 1.2e6, 4), (60_200.0 * 0.988, "long", 3.0e6, 9), (60_200.0 * 0.973, "long", 0.5e6, 2),
                                     (60_200.0 * 1.003, "short", 0.8e6, 3), (60_200.0 * 1.017, "short", 2.5e6, 7), (60_200.0 * 1.029, "short", 0.4e6, 1),
                                     (60_200.0 * 1.002, "long", 0.6e6, 2), (60_200.0 * 0.999, "short", 0.1e6, 1),
                                     (60_200.0 * 0.965, "long", 9e6, 30), (60_200.0 * 1.04, "short", 9e6, 30)]},
            "magnet_satz": magnet_satz({"ts": jetzt - 7200, "h": {h_: {"klassen": {n_: {"belegt": False} for n_ in ("klein", "mittel", "groß")}}
                                                                  for h_ in ("1", "4")}}),
            # 23.110 (U269), in der Form von linien_lesen und niveaus_urteil_lesen: Stand nach dem letzten vollen Tag; die 200-Tage-Linie
            # führt der Ausblick als Niveau (58.000, siehe oben), die 50-Tage-Linie nicht
            "linien": {"tag": jetzt // TAG - 1, "n_tage": 800, "schluss": 60_050.0, "quelle": "binance", "alter_tage": 0, "gefuellt": 0, "fehlt": [],
                       "ma50": 61_300.0, "ma50_richtung": -1, "ma50_seit": 12, "ma200": 58_000.0, "ma200_richtung": 1, "ma200_seit": 140,
                       # 23.111: Summe der letzten 49 und 199 Tagesschlüsse -- mit dem Kurs 60.200 als heutigem Tag: 61.250 und 58.020
                       "ma50_rest": 3_002_300.0, "ma200_rest": 11_543_800.0,
                       "lage": 1, "kreuz_tag": jetzt // TAG - 192},
            "trend_beleg": "Als Regel geprüft (Probe): über der 200-Tage-Linie nicht sicherer als Halten.",
            "niveaus_urteil": {"da": True, "debug": 149, "regel": "U244/1", "stand": jetzt - 2 * TAG, "ohne_wirkung": True,
                               "satz": "Niveau-Arten ohne belegte Wirkung — die Zahl folgt allein aus dem Abstand.",
                               "coins": ["BTC", "ETH", "HYPE", "ZEC", "XMR"],
                               "linien": {"ma50_": "erreicht 34 % bei 36 % erwartet (n 1.234) · Anziehung nicht belegt · Halten nicht belegt",
                                          "ma200": "erreicht 21 % bei 22 % erwartet (n 987) · Anziehung nicht belegt · Halten nicht belegt"}}}


def _probe_verlauf() -> tuple:
    """Reihen von Hand in der Form von hl_staking_studie.verlauf (500 Tage ab 04.10.2024) und der Zeitpunkt dazu -- für die Proben zum
    Verlauf hier und im Selbsttest des Dashboards (dort zeichnet das Skript dieselbe Reihe)."""
    D0v = 20000                                                          # 04.10.2024; Reihe von 500 Tagen bis 15.02.2026
    iso_v = lambda D_: time.strftime("%Y-%m-%d", time.gmtime(D_ * TAG))  # noqa: E731
    U_v = {"regel": "U255/1", "aktuell": True, "ts": 20772 * TAG + 12000, "urteil": "nicht belegt",
           "A": {"n": 18, "mittel": -0.0148, "diff": -0.0100, "negativ": 14, "p": 0.211, "p_holm": 0.422, "urteil": "nicht belegt"},
           "alle_y7": -0.0048, "daten_bis": "2025-11-07"}
    V_h = {"ok": True, "von_D": D0v, "bis_D": D0v + 499, "heute_D": D0v + 499,
           # Tagesdatei: Tage 0–399 ohne 100–114 (15 Tage, die ausgeschlossene Zeit), ohne 200–201 (2 Tage) und ohne 300–302 (3 Tage); dazu Tag 429
           "tagesdatei": {**{D0v + i: 1000.0 + 10 * i + 0.4 for i in range(400) if not 100 <= i <= 114 and i not in (200, 201) and not 300 <= i <= 302},
                          D0v + 429: 5289.6},                                # gerundet 5.290 (abgeschnitten wären es 5.289)
           "knoten": {D0v + 429: 9999.0, D0v + 430: 5000.4, D0v + 431: 6000.6, D0v + 433: 7000.0},        # eigene Messung; Tag 432 fehlt
           "kurs": {D0v + i: 2000.0 + i + 0.123456 for i in range(500) if i != 250},
           "wellen": [{"nr": 1, "a": D0v + 50, "b": D0v + 52, "zuwachs": 88_128.0, "schlange": 89_920.0, "ausloeser": 1, "a_stand": "gewertet",
                       "b_stand": "gewertet", "a_y7": -0.0312, "a_eth7": 0.0149, "b_y7": 0.0444, "b_eth7": 0.0555},
                      {"nr": 2, "a": D0v + 320, "b": D0v + 321, "zuwachs": 60_000.4, "schlange": 61_000.6, "ausloeser": 2, "a_stand": "gewertet",
                       "b_stand": "gewertet", "a_y7": 0.0, "a_eth7": -0.0004, "b_y7": 0.01, "b_eth7": 0.02},
                      {"nr": 3, "a": D0v + 390, "b": None, "zuwachs": 568_436.0, "schlange": 773_447.0, "ausloeser": 3, "a_stand": "offen",
                       "b_stand": None, "a_y7": None, "a_eth7": None, "b_y7": None, "b_eth7": None},
                      {"nr": 4, "a": D0v + 395, "b": None, "zuwachs": 70_000.0, "schlange": None, "ausloeser": 1, "a_stand": "ohne Kurs",
                       "b_stand": None, "a_y7": None, "a_eth7": None, "b_y7": None, "b_eth7": None},
                      {"nr": 5, "a": D0v - 10, "b": D0v - 8, "zuwachs": 60_000.0, "schlange": 61_000.0, "a_stand": "gewertet", "a_y7": 0.01, "a_eth7": 0.01},
                      {"nr": 6, "a": None, "zuwachs": 1.0}],
           "urteil": U_v, "td": {"von": iso_v(D0v), "bis": iso_v(D0v + 429), "n": 381, "fehlen": 5, "ausgeschlossen": 15},
           "kn": {"von": iso_v(D0v + 429), "bis": iso_v(D0v + 433), "n": 4}, "schwelle_eth": 57600, "ruhe_tage": 14, "horizont": 7,
           "ausgeschlossen": [iso_v(D0v + 100), iso_v(D0v + 114)], "pectra_ab": "2025-05-22", "hinweise": ["Kurs: Probe."]}
    return V_h, (D0v + 499) * TAG + 3600


def _probe_rechner(jetzt: int, coin: str = "BTC") -> tuple:
    """Grundlage des Kurs-Rechners von Hand, in der Form von rechner_grundlage: Kurs 60.000, σ über 4 Stunden 1,2 %, Nullmodelle in der
    Größe des Pi (1 h: c 0,74, τ 0,6, 8 von 8 Zufallsabständen; 4 h: c 0,78, τ 0,6, 7 von 8), Verteilung der Tage aus einer Gauß-Bibliothek
    von hl_ausblick (3 % je Tag, 4.000 Fenster), Prüfung S3 wie im Rückblick des Pi, Trefferquote des Bands in der Toleranz -- für die Proben hier und im Selbsttest des
    Dashboards. -> (G, S); S sind die Szenarien, für die Gegenprobe mit der vollen Rechnung erreichen()."""
    import numpy as np
    import hl_ausblick as AU
    n_ = 4000; sig = 0.03
    S = AU.szenarien(AU._gauss_bib(n_, 7), np.ones(n_, dtype=bool), sig * sig * np.arange(1, AU.K_MAX + 1))
    G = {"coin": coin, "jetzt": jetzt, "kurs": 60_000.0, "kurs_ts": jetzt - 30, "kurs_frisch": True, "sig4": 0.012, "sig4_fehlt": None,
         "kurz": {"1h": {"h": 1, "c": 0.74, "tau": 0.6, "zufall_ok": 8, "zufall_n": 8, "tage": 64.7, "n_bloecke": 1546, "ts": jetzt - 3 * 3600},
                  "4h": {"h": 4, "c": 0.78, "tau": 0.6, "zufall_ok": 7, "zufall_n": 8, "tage": 64.5, "n_bloecke": 388, "ts": jetzt - 3 * 3600}},
         "kurz_fehlt": {}, "lauf": {"anker": jetzt - 1800, "p0": 59_900.0, "erzeugt": jetzt - 1700, "n": n_, "h": AU.lauf_quantile(S)}, "lauf_fehlt": None,
         "s3": {"7": {"n": 15495, "skill": 0.063, "steigung": 0.96, "besteht": True}, "14": {"n": 15495, "skill": 0.037, "steigung": 0.92, "besteht": True}},
         "deckung": {"7": {"d80": 0.804, "se": 0.016, "ok": True}, "14": {"d80": 0.801, "se": 0.021, "ok": True}},     # in der Toleranz (wie ETH auf dem Pi)
         "sigma_geprueft": RECHNER_SIGMA_GEPRUEFT}
    return G, S


def selbsttest(verbose: bool = True) -> bool:
    import copy
    pruef = []

    def ok(name, bed, wert=""):
        pruef.append((name, bool(bed), str(wert)))

    # Mittwoch 11.11.2026 12:00 UTC als fester Zeitpunkt (kein Wochenende, kein Termin)
    import calendar
    jetzt = calendar.timegm((2026, 11, 11, 12, 0, 0))
    Q = _probe_quellen(jetzt)
    d = bauen(copy.deepcopy(Q))
    L = {l["key"]: l for l in d["lampen"]}

    # ---- 1) Abgleich: jede Zahl gleich der Quelle
    sp = d["spanne"]; P = Q["ausblick"]["prognose"]
    ok("Abgleich Spanne: Quantile 7/14/28 Tage gleich der Rechnung des Ausblicks, Trefferquote gleich dem Rückblick",
       all(sp["h"][h]["q"] == P["spannen"][h]["q"] for h in ("7", "14", "28")) and sp["h"]["7"]["treffer"] == 0.84 and sp["p0"] == P["p0"]
       and sp["anker"] == P["anker"] and sp["kurs"] == 60_200.0,
       f"7 T 80 %: {_px(sp['h']['7']['q'][1])}–{_px(sp['h']['7']['q'][5])}, traf {sp['h']['7']['treffer']}")
    sp_e = bauen(_probe_quellen(jetzt, "ETH"))["spanne"]; sp_p = bauen(_probe_quellen(jetzt, "PAXG"))["spanne"]
    ok("Vermerk je Horizont = gemessene Trefferquote des Coins, mit „(zu weit)“ oder „(zu eng)“ außerhalb von 80 % ± 2 Standardfehler -- "
       "auch wenn die Gesamtprüfung S1 „besteht nicht“ lautet (Zahlen des Pi vom 11.11.: BTC 7 Tage 84,0 % ± 1,7)",
       [sp["h"][h]["vermerk"] for h in ("7", "14", "28")] == ["traf 84 % (zu weit)", "traf 85 % (zu weit)", "traf 83 %"]
       and [sp_e["h"][h]["vermerk"] for h in ("7", "14", "28")] == ["traf 80 %", "traf 80 %", "traf 79 %"]
       and [sp_p["h"][h]["vermerk"] for h in ("7", "14", "28")] == ["traf 67 % (zu eng)", "traf 66 % (zu eng)", "traf 58 % (zu eng)"]
       and sp["h"]["7"]["besteht"] is False and sp["h"]["7"]["deckung_ok"] is False and sp_e["h"]["7"]["deckung_ok"] is True,
       "BTC " + " · ".join(sp["h"][h]["vermerk"] for h in ("7", "14", "28")) + " | PAXG " + sp_p["h"]["7"]["vermerk"])
    q_p05 = copy.deepcopy(Q); q_p05["ausblick"]["rueckblick"]["s1"]["h"]["7"]["p"] = 0.05           # feste Zahl: p genau 0,05 ist nicht belegt
    q_p049 = copy.deepcopy(Q); q_p049["ausblick"]["rueckblick"]["s1"]["h"]["14"]["p"] = 0.049
    ok("Vorsprung je Horizont aus Gewinn und p des Rückblicks, getrennt von der Trefferquote: 7 Tage belegt (p 0,002), 14 Tage offen "
       "(p 0,181), 28 Tage keiner (Gewinn −0,7 %); p genau 0,05 gilt nicht als belegt, 0,049 schon",
       [sp["h"][h]["vorsprung"] for h in ("7", "14", "28")] == ["belegt", "offen", "keiner"]
       and bauen(q_p05)["spanne"]["h"]["7"]["vorsprung"] == "offen" and bauen(q_p049)["spanne"]["h"]["14"]["vorsprung"] == "belegt",
       " · ".join(f"{h} T {sp['h'][h]['vorsprung']}" for h in ("7", "14", "28")))
    q_ohne = copy.deepcopy(Q); del q_ohne["ausblick"]["rueckblick"]["s1"]["h"]["7"]["deckung"]["BTC"]
    q_gut = copy.deepcopy(Q); q_gut["ausblick"]["rueckblick"]["s1"]["h"]["7"]["deckung"]["BTC"] = {"d80": 0.81, "se": 0.017, "ok": True}
    q_gut["ausblick"]["rueckblick"]["s1"]["h"]["7"]["besteht"] = True
    sp_gut = bauen(q_gut)["spanne"]; sp_ohne = bauen(q_ohne)["spanne"]; sp_p05 = bauen(q_p05)["spanne"]
    ok("Beleg der Spanne nennt die Gesamtprüfung S1 des Ausblicks mit ihren Gründen: „besteht nicht -- das Band von BTC ist zu weit "
       "(84,0 % ± 1,7)“; ohne belegten Vorsprung auch diesen Grund; fehlt die Deckung eines Coins, steht „Trefferquote nicht gemessen“; "
       "besteht die Prüfung, steht „besteht.“",
       sp["beleg"].endswith("Gesamtprüfung S1 des Ausblicks für 7 Tage (Vorsprung und Deckung bei BTC und ETH zugleich): besteht nicht -- "
                            "das Band von BTC ist zu weit (84,0 % ± 1,7).")
       and "Das 80-%-Band für 7 Tage traf bei BTC 84,0 % ± 1,7 -- zu weit (Soll 80 %)." in sp["beleg"]
       and "7 Tage belegt (Gewinn +1,5 %, p 0,002) · 14 Tage nicht belegt (Gewinn +0,4 %, p 0,181) · 28 Tage keiner (Gewinn −0,7 %)." in sp["beleg"]
       and "besteht nicht -- der Vorsprung ist nicht belegt; das Band von BTC ist zu weit" in sp_p05["beleg"]
       and sp_gut["beleg"].endswith("zugleich): besteht.") and sp_gut["h"]["7"]["vermerk"] == "traf 81 %"
       and sp_ohne["h"]["7"]["vermerk"] == "Trefferquote nicht gemessen" and "für BTC fehlt die Deckung" in sp_ohne["beleg"]
       and "Im Rückblick" not in bauen(q_ohne)["satz"]["text"] and sp_e["beleg"].count("das Band von BTC ist zu weit") == 1
       and "traf bei ETH 80,4 % ± 1,6." in sp_e["beleg"], sp["beleg"][-150:])
    ok("Kernsatz aus der 80-%-Spanne der 7 Tage mit der gemessenen Trefferquote des Bands (wie der Kernsatz des Ausblicks) und dem Satz "
       "„Richtung nicht belegt“",
       d["satz"]["text"] == "In 7 Tagen liegt BTC mit 80 % zwischen 54.000 und 66.000. Im Rückblick traf dieses Band 84 % -- zu weit (Soll 80 %)."
       and bauen(_probe_quellen(jetzt, "ETH"))["satz"]["text"].endswith("Im Rückblick traf dieses Band 80 %.")
       and bauen(q_gut)["satz"]["text"].endswith("Im Rückblick traf dieses Band 81 %.") and d["satz"]["zusatz"] == SATZ_RICHTUNG
       and d["satz"]["ausnahme"] is None, d["satz"]["text"])
    s = d["schwankung"]
    pz_hand = (sum(1 for a in Q["vol"]["vi7_reihe"][-PERZ_TAGE:] if a < 45.7) + 0.5 * sum(1 for a in Q["vol"]["vi7_reihe"][-PERZ_TAGE:] if a == 45.7)) / PERZ_TAGE
    ok("Abgleich Schwankung: erwartet, realisiert 7/30 Tage, DVOL und 4-h-Bewegung gleich den Quellen; Perzentil von Hand (Mittelrang, 365 Tage)",
       s["erwartet"] == 45.7 and s["real7"] == 44.0 and s["real30"] == 36.0 and s["dvol"] == 39.5 and s["er4"] == 0.0051
       and abs(s["pz"] - pz_hand) < 1e-12 and s["pz_von"].startswith("Erwartete"), f"Perzentil {s['pz']:.4f} (von Hand {pz_hand:.4f})")
    w90 = [float(i) for i in range(1, 91)]
    try:
        import hl_chartbild as CB_
        import random as _rnd
        rz = _rnd.Random(5); reihe_z = [round(rz.random() * 50, 1) for _ in range(200)]
        gleich_cb = all(abs(perzentil(x_, reihe_z) - float(CB_.perzentil(x_, __import__("numpy").array(reihe_z)))) < 1e-12 for x_ in (0.0, 12.5, reihe_z[7], reihe_z[99], 60.0))
    except ImportError:
        gleich_cb = True
    ok("Perzentil: Mittelrang (45 unter 1…90 -> 0,4944; gleiche Werte halb gezählt), unter 60 Werten oder bei lauter gleichen kein Wert; "
       "dieselbe Regel wie hl_chartbild.perzentil",
       abs(perzentil(45.0, w90) - 44.5 / 90) < 1e-12 and perzentil(45.0, w90[:59]) is None and perzentil(1.0, [1.0] * 90) is None
       and perzentil(None, w90) is None and gleich_cb, f"{perzentil(45.0, w90):.4f}; gleich dem Chartbild: {gleich_cb}")
    ok("Beleg der Spanne nennt Gewinn, p und Trefferquote des Coins aus dem Rückblick; ein p unter 0,001 steht als „< 0,001“",
       "Gewinn +1,5 %, p 0,002" in sp["beleg"] and "traf bei BTC 84,0 %" in sp["beleg"] and _p(0.0004) == "< 0,001" and _p(0.0292) == "0,029" and _p(None) == "—",
       sp["beleg"][:160])
    # Perzentil in der Anzeige: abgeschnitten, damit Zahl und Lampe sich nie widersprechen (Pi 12.11.: ZEC „80. Perzentil“ und „aus“)
    alle_pz = sorted({(2 * k + 1) / (2 * n) for n in range(60, 366) for k in range(n)} | {k / n for n in range(60, 366) for k in range(n)})
    wider = [x for x in alle_pz if (pz_zahl(x) >= 80) != (x >= SCHWANKUNG_GELB) or (pz_zahl(x) >= 95) != (x >= SCHWANKUNG_ROT)]
    l796 = lampe_schwankung(0.7959, "belegt", "Erwartete Schwankung (7 Tage)", 134.0); l80 = lampe_schwankung(0.80, "belegt", "Erwartete Schwankung (7 Tage)", 134.0)
    l95 = lampe_schwankung(0.95, "belegt", "Erwartete Schwankung (7 Tage)", 134.0); l9499 = lampe_schwankung(0.9499, "belegt", "Erwartete Schwankung (7 Tage)", 134.0)
    ok("Perzentil in der Anzeige abgeschnitten, nicht gerundet: 0,7959 -> „79.“ und Lampe aus, 0,80 -> „80.“ und Hinweis, 0,9499 -> „94.“ "
       "und Hinweis, 0,95 -> „95.“ und Warnung, 0,9944 -> „99.“, 1,0 -> „100.“ (höher als alle); 0,29, 0,57 und 0,58 bleiben 29, 57 und 58 "
       "(Gleitkomma: 0,29 · 100 = 28,999999999999996); über alle Mittelränge für 60 bis 365 Werte widersprechen sich Zahl und Lampe nie",
       [pz_zahl(x) for x in (0.7959, 0.80, 0.9499, 0.95, 0.9944, 1.0, 0.0, None)] == [79, 80, 94, 95, 99, 100, 0, None] and not wider
       and [pz_zahl(x) for x in (0.29, 0.57, 0.58)] == [29, 57, 58] and pz_zahl(1.7) == 100 and pz_zahl(-0.2) == 0
       and (l796["wert"], l796["zustand"]) == ("79. Perzentil", "aus") and (l80["wert"], l80["zustand"]) == ("80. Perzentil", "hinweis")
       and (l9499["wert"], l9499["zustand"]) == ("94. Perzentil", "hinweis") and (l95["wert"], l95["zustand"]) == ("95. Perzentil", "warnung")
       and "höher als an 79 % der Tage" in l796["detail"] and d["schwankung"]["pz_n"] == pz_zahl(d["schwankung"]["pz"])
       and [m_["pz_n"] for m_ in d["messwerte"]] == [52, 22, None, 90, 7],
       f"{len(alle_pz)} Perzentile geprüft, Widersprüche {len(wider)}; 0,7959 -> {l796['wert']} ({l796['zustand']})")
    k = d["kosten"]
    ok("Abgleich Kosten: nötige Trefferquote 4 h und 24 h, Taker und Maker, gleich der Kostenschwelle der Fusion",
       [(z["h"], z["taker"], z["maker"], z["er"]) for z in k["zeilen"]] == [(4, 0.589, 0.529, 0.0051), (24, 0.535, 0.511, 0.0131)]
       and k["taker"] == 0.00045 and k["maker"] == 0.00015, str(k["zeilen"]))
    m = {x["key"]: x for x in d["messwerte"]}
    ok("Abgleich Messwerte: Open Interest und Kontenquote mit dem Perzentil der Positionierung, Funding-Druck als z-Wert, Marke bei 3",
       m["oi"]["pz"] == 0.52 and m["konten"]["wert"] == 1.57 and m["konten"]["pz"] == 0.22 and m["konten"]["marke"] == 3.0
       and m["funding"]["wert"] == 0.69 and m["funding"]["pz"] is None, f"Konten {m['konten']['text']}, Funding {m['funding']['text']}")
    q_tag = copy.deepcopy(Q); q_tag["lage"]["oi"] = {"wert": 100_000.0, "tag": jetzt // 86_400 - 1, "art": "Tagesstand", "pz": 0.5}
    m_tag = {x["key"]: x for x in bauen(q_tag)["messwerte"]}
    ok("Jedes Instrument nennt seinen Stand: Messwerte mit Zeitpunkt (live) oder UTC-Tag (Tagesstand, Funding-Druck), Schwankung mit dem "
       "Tag der Tageswerte und der Prognose, Kosten mit Zeitpunkt und Fenster, Hebel-Lampe mit dem Zeitpunkt der Kontenquote",
       m["oi"]["stand"] == jetzt - 300 and m["oi"]["stand_tag"] is None and m["konten"]["stand"] == jetzt - 300
       and m["funding"]["stand"] is None and m["funding"]["stand_tag"] == "10.11.2026" and m_tag["oi"]["stand"] is None
       and m_tag["oi"]["stand_tag"] == "10.11.2026" and s["stand_text"] == "Stand: Tageswerte bis 10.11.2026 (UTC), Prognose vom 10.11.2026."
       and k["stand"] == jetzt - 600 and k["tage"] == 30 and L["hebel"]["stand"] == jetzt - 300
       and "Tageswerte bis 10.11.2026" in L["schwankung"]["detail"] and L["aktien"]["stand"] == jetzt - 1500,
       f"{s['stand_text']} | Funding {m['funding']['stand_tag']} | Kosten {_datum(k['stand'])}")

    # ---- 2) Levels
    lv = d["levels"]
    ok("Levels: je Seite die drei nächsten zum jetzigen Kurs, oben das fernste zuerst; Abstand zum jetzigen Kurs; Niveau ohne "
       "Wahrscheinlichkeit fehlt",
       [n["px"] for n in lv["oben"]] == [65_000.0, 61_000.0, 60_500.0] and [n["px"] for n in lv["unten"]] == [59_500.0, 58_000.0]
       and abs(lv["oben"][-1]["abstand"] - (60_500 / 60_200 - 1)) < 1e-12 and lv["oben"][-1]["p7"] == 0.95 and lv["oben"][-1]["p14"] == 0.97
       and lv["oben"][-1]["momentaufnahme"] is True and lv["durchlaufen"] == 0,
       f"oben {[n['px'] for n in lv['oben']]}, unten {[n['px'] for n in lv['unten']]}")
    Q2 = copy.deepcopy(Q); Q2["kurs"]["px"] = 60_700.0
    lv2 = bauen(Q2)["levels"]
    ok("Levels: ein Niveau, das seit dem Anker durchlaufen wurde (60.500 bei Kurs 60.700, Anker 60.000), wird nicht mehr gezeigt, nur gezählt",
       60_500.0 not in [n["px"] for n in lv2["oben"] + lv2["unten"]] and lv2["durchlaufen"] == 1 and [n["px"] for n in lv2["oben"]] == [68_000.0, 65_000.0, 61_000.0],
       f"oben {[n['px'] for n in lv2['oben']]}, durchlaufen {lv2['durchlaufen']}")

    # ---- 3) Lampen an ihren Schwellen
    ok("Grundzustand (Mittwoch, kein Termin, Kontenquote 1,57): Hebel, Termin, Wochenende und Aktien aus",
       [L[k_]["zustand"] for k_ in ("hebel", "termin", "wochenende", "aktien")] == ["aus"] * 4 and L["termin"]["wert"] == "Arbeitsmarktbericht"
       and L["termin"]["ts"] == jetzt + 9 * TAG and L["wochenende"]["wert"] == "Mi", {k_: v["zustand"] for k_, v in L.items()})

    def lampe(key, **aend):
        q = copy.deepcopy(Q)
        for pfad, wert in aend.items():
            ziel = q; teile = pfad.split("__")
            for t in teile[:-1]:
                ziel = ziel[t]
            ziel[teile[-1]] = wert
        return next(l for l in bauen(q)["lampen"] if l["key"] == key)
    h299, h300 = lampe("hebel", lage__konten__wert=2.99), lampe("hebel", lage__konten__wert=3.0)
    ok("Hebel: Kontenquote 2,99 aus, 3,00 Hinweis (Regel H1, Schwelle 3); ohne Wert grau",
       h299["zustand"] == "aus" and h300["zustand"] == "hinweis" and h300["wert"] == "3,00 ≥ 3"
       and lampe("hebel", lage__konten={})["zustand"] == "grau", f"{h299['wert']} -> {h299['zustand']}, {h300['wert']} -> {h300['zustand']}")
    cpi = lambda ts: [{"reihe": "CPIAUCSL", "name": "Verbraucherpreise", "ts": ts}]
    t_vor24 = lampe("termin", termine=cpi(jetzt + 86_400)); t_vor24p = lampe("termin", termine=cpi(jetzt + 86_460))   # feste Zahlen: 24 h, 2 h
    t_jetzt = lampe("termin", termine=cpi(jetzt)); t_nach = lampe("termin", termine=cpi(jetzt - 7_140))
    t_ende = lampe("termin", termine=cpi(jetzt - 7_200))
    ok("Termin: genau 24 h davor Hinweis, eine Minute früher aus; ab der Veröffentlichung Warnung (Studie belegt) bis unter 2 h danach, dann aus",
       t_vor24["zustand"] == "hinweis" and t_vor24p["zustand"] == "aus" and t_jetzt["zustand"] == "warnung" and t_nach["zustand"] == "warnung"
       and t_ende["zustand"] == "aus" and t_jetzt["ts_ende"] == jetzt + 7_200,
       f"24 h davor {t_vor24['zustand']}, +1 min {t_vor24p['zustand']}, jetzt {t_jetzt['zustand']}, 1 h 59 danach {t_nach['zustand']}, 2 h danach {t_ende['zustand']}")
    t_unbelegt = lampe("termin", termine=cpi(jetzt), datentag_stand={"H1": {"belegt": False, "abs_verh": 2.4}})
    t_ppi = lampe("termin", termine=[{"reihe": "PPIFIS", "name": "Erzeugerpreise", "ts": jetzt + 3600}])
    ok("Termin: ohne „belegt“ der Studie nur Hinweis statt Warnung; Erzeugerpreise lösen nichts aus; ohne geladene Termine grau",
       t_unbelegt["zustand"] == "hinweis" and "noch kein Stand" in t_unbelegt["beleg"] and t_ppi["zustand"] == "aus"
       and lampe("termin", termine_geladen=False)["zustand"] == "grau", f"unbelegt {t_unbelegt['zustand']}, Erzeugerpreise {t_ppi['zustand']}")
    t_ohne = lampe("termin", naechste={"Erstanträge": jetzt + TAG}); t_einer = lampe("termin", naechste={"Verbraucherpreise": jetzt + 20 * TAG})
    t_vorbei = lampe("termin", naechste={"Verbraucherpreise": jetzt - 3 * TAG, "Arbeitsmarktbericht": jetzt - TAG})
    ok("Termin: ist kein kommender Termin bekannt (Kalender leer oder nur Vergangenes), ist die Lampe grau statt aus; fehlt nur eine der "
       "beiden Reihen, bleibt sie aus und nennt die fehlende",
       t_ohne["zustand"] == "grau" and t_ohne["wert"] == "keiner bekannt" and t_vorbei["zustand"] == "grau" and t_einer["zustand"] == "aus"
       and "Für Arbeitsmarktbericht ist kein kommender Termin bekannt" in t_einer["detail"] and "kein kommender Termin bekannt" not in L["termin"]["detail"],
       f"keiner: {t_ohne['zustand']}; nur Vergangenes: {t_vorbei['zustand']}; einer: {t_einer['zustand']} -- {t_einer['detail']}")
    fr, sa, so, mo = (lampe_wochenende(jetzt + n * TAG, 0.68) for n in (2, 3, 4, 5))
    ok("Wochenende: Freitag aus, Samstag und Sonntag (UTC) Hinweis, Montag aus; der Faktor steht im Beleg",
       [x["zustand"] for x in (fr, sa, so, mo)] == ["aus", "hinweis", "hinweis", "aus"] and [x["wert"] for x in (fr, sa, so, mo)] == ["Fr", "Sa", "So", "Mo"]
       and "0,68" in sa["beleg"] and "0,68" in sa["detail"], " · ".join(f"{x['wert']} {x['zustand']}" for x in (fr, sa, so, mo)))
    a_c = {"regel": "c", "seit": jetzt - 3600, "bewegung": -0.021, "offen": True}
    ak = lampe("aktien", ausnahme=a_c, ausnahme_text="Ausnahmelage seit …: S&P-500-Perp in 6 h −2,1 % -- nur ein Hinweis.")
    ak_alt = lampe("aktien", ausnahme=dict(a_c, seit=jetzt - TAG))
    ak_a = bauen(dict(copy.deepcopy(Q), ausnahme={"regel": "a", "seit": jetzt - 600, "bewegung": 0.03}, ausnahme_text="Ausnahmelage seit …: 30-min-Bewegung"))
    ak_a_l = next(l for l in ak_a["lampen"] if l["key"] == "aktien")
    ok("Aktien: Ausnahmelage (c) des Ausblicks -> Hinweis mit der S&P-Bewegung, nach 24 h aus („keine Ausnahme“); PAXG grau",
       ak["zustand"] == "hinweis" and ak["wert"] == "S&P −2,1 %" and ak["ts_ende"] == jetzt - 3600 + 86_400 and ak_alt["zustand"] == "aus"
       and ak_alt["wert"] == "keine Ausnahme" and L["aktien"]["wert"] == "keine Ausnahme"
       and bauen(_probe_quellen(jetzt, "PAXG"))["lampen"][3]["zustand"] == "grau", f"{ak['wert']}; nach 24 h {ak_alt['zustand']}")
    ok("Aktien: gilt für den Coin schon eine Ausnahmelage (a) aus der eigenen Bewegung, setzt der Ausblick (c) nicht -- die Lampe ist "
       "grau statt aus, die Ausnahme steht als Zeile unter dem Kernsatz",
       ak_a_l["zustand"] == "grau" and "eigenen Bewegung" in ak_a_l["detail"] and (ak_a["satz"]["ausnahme"] or "").startswith("Ausnahmelage")
       and lampe("aktien", ausnahme={"regel": "a", "seit": jetzt - 86_400, "bewegung": 0.03})["zustand"] == "aus", ak_a_l["detail"][:120])
    # feste Zahlen: Kerze jünger als 2 h (7.200 s), mindestens 12 Kerzen, Rechnung höchstens 3 h (10.800 s) alt
    p_ok = aktien_pruefung(0.0001, 12, jetzt - 7_199, jetzt - 10_800, jetzt)
    p_kerze = aktien_pruefung(0.0001, 12, jetzt - 7_200, jetzt - 60, jetzt); p_wenig = aktien_pruefung(0.0001, 11, jetzt - 60, jetzt - 60, jetzt)
    p_takt = aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 10_801, jetzt); p_basis = aktien_pruefung(None, 16, jetzt - 60, jetzt - 60, jetzt)
    p_keine = aktien_pruefung(0.0001, 0, None, jetzt - 60, jetzt); p_nie = aktien_pruefung(0.0001, 16, jetzt - 60, 0, jetzt)
    ok("Aktien-Regel nachweisbar geprüft: an den Grenzen (Kerze 1 h 59 min 59 s alt, 12 Kerzen, Rechnung genau 3 h alt) ja; Kerze 2 h alt, "
       "11 Kerzen, Rechnung 3 h 1 s alt, keine Basis, keine Kerze oder nie gerechnet -> nein, jeweils mit Grund",
       p_ok["ok"] is True and not p_ok["grund"] and [x["ok"] for x in (p_kerze, p_wenig, p_takt, p_basis, p_keine, p_nie)] == [False] * 6
       and "letzte Kerze" in p_kerze["grund"] and "zu wenige Kerzen" in p_wenig["grund"] and "Takt" in p_takt["grund"] and "Basis" in p_basis["grund"]
       and "zu wenige Kerzen" in p_keine["grund"] and "nicht bekannt" in p_nie["grund"] and p_ok["kerze_ts"] == jetzt - 7_199,
       f"Kerze 2 h: {p_kerze['grund'][:70]} | Takt: {p_takt['grund'][:60]}")
    ak_grau = lampe("aktien", aktien_pruefung=p_kerze); ak_unbek = lampe("aktien", aktien_pruefung=None)
    ak_c_trotz = lampe("aktien", ausnahme=a_c, aktien_pruefung=p_takt)
    ak_fremd = lampe("aktien", aktien_pruefung=aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 60, jetzt, ["ETH", "XMR"]))
    ak_drin = lampe("aktien", aktien_pruefung=aktien_pruefung(0.0001, 16, jetzt - 60, jetzt - 60, jetzt, ["ETH", "BTC"]))
    ok("Aktien: ohne Nachweis, dass die Regel geprüft wird, gibt es kein „aus“ -- die Lampe ist grau und nennt den Grund; ebenso, wenn "
       "der Coin nicht in der Basis der Regel steht; eine schon gesetzte Ausnahmelage (c) bleibt ein Hinweis",
       ak_grau["zustand"] == "grau" and ak_grau["wort"] == "kein Wert" and ak_grau["detail"] == p_kerze["grund"] and ak_unbek["zustand"] == "grau"
       and "nicht bekannt" in ak_unbek["detail"] and ak_c_trotz["zustand"] == "hinweis" and ak_fremd["zustand"] == "grau"
       and "Für BTC steht in der letzten Rechnung" in ak_fremd["detail"] and ak_drin["zustand"] == "aus",
       f"{ak_grau['zustand']}: {ak_grau['detail'][:90]}")

    def schw(pz_ziel, v1="belegt", erwartet=True):
        q = copy.deepcopy(Q)
        q["vol"]["vi7_reihe"] = [float(i) for i in range(1, 1001)][-PERZ_TAGE:]       # 636 … 1000, je einmal
        wert = 635.5 + pz_ziel * PERZ_TAGE                                         # zwischen zwei Werten: Perzentil = Anzahl kleinerer ÷ 365
        q["vol"]["v1"] = v1
        if erwartet:
            q["vol"]["erwartet"] = wert
        else:
            q["vol"]["erwartet"] = None; q["vol"]["real7"] = wert; q["vol"]["vi7_reihe"] = q["vol"]["vi7_reihe"] + [wert]
        return next(l for l in bauen(q)["lampen"] if l["key"] == "schwankung")
    s79, s80, s94, s95 = schw(291 / 365), schw(292 / 365), schw(346 / 365), schw(347 / 365)
    ok("Schwankung: Perzentil 0,797 aus, 0,800 Hinweis, 0,948 Hinweis, 0,951 Warnung (Schwellen 0,80 und 0,95; 292 bzw. 347 von 365 Tagen)",
       [x["zustand"] for x in (s79, s80, s94, s95)] == ["aus", "hinweis", "hinweis", "warnung"] and abs(s80["pz"] - 0.8) < 1e-12,
       " · ".join(f"{x['pz']:.3f} {x['zustand']}" for x in (s79, s80, s94, s95)))
    s_neutral = schw(0.99, v1=None); s_real = schw(0.99, erwartet=False)
    ok("Schwankung: ohne Urteil „belegt“ (V1) und ohne Prognose (nur realisiert) bleibt die Lampe neutral, auch im 99. Perzentil",
       s_neutral["zustand"] == "aus" and s_neutral["wort"] == "neutral" and s_neutral["klasse"] == "B" and "noch kein Urteil" in s_neutral["beleg"]
       and s_real["zustand"] == "aus" and s_real["wort"] == "neutral", f"ohne Urteil: {s_neutral['wort']}; nur realisiert: {s_real['wort']}")
    q_alt = copy.deepcopy(Q); q_alt["vol"]["bis"] = jetzt // 86_400 - 4                     # feste Zahl: Tageswerte 4 Tage alt
    q_grenze = copy.deepcopy(Q); q_grenze["vol"]["bis"] = jetzt // 86_400 - 3
    d_alt, d_grenze = bauen(q_alt), bauen(q_grenze)
    ok("Schwankung: Tageswerte 4 Tage alt -> Instrument nicht frisch (nennt „Tageswerte nur bis …“), Lampe grau statt Farbe; 3 Tage alt "
       "noch frisch",
       d_alt["schwankung"]["frisch"] is False and any("Tageswerte nur bis 07.11.2026" in f for f in d_alt["schwankung"]["fehlt"])
       and d_alt["lampen"][4]["zustand"] == "grau" and "Tageswerte nur bis" in d_alt["lampen"][4]["detail"]
       and d_grenze["schwankung"]["frisch"] is True and d_grenze["lampen"][4]["zustand"] != "grau" and d["schwankung"]["frisch"] is True,
       f"4 Tage: {d_alt['lampen'][4]['zustand']} ({d_alt['schwankung']['fehlt']}); 3 Tage: {d_grenze['lampen'][4]['zustand']}")

    # ---- 4) Frische und fehlende Quellen
    Q3 = copy.deepcopy(Q); Q3["ausblick"]["prognose"]["anker"] = jetzt - 172_860; Q3["kurs"]["ts"] = jetzt - 360     # feste Zahlen: 2 Tage, 5 min
    d3 = bauen(Q3)
    Q3b = copy.deepcopy(Q); Q3b["ausblick"]["prognose"]["anker"] = jetzt - 172_800; Q3b["kurs"]["ts"] = jetzt - 300
    d3b = bauen(Q3b)
    ok("Frische: Spanne älter als 2 Tage und Kurs älter als 5 min -> nicht frisch, mit Stand; genau an der Grenze noch frisch; ohne frischen "
       "Kurs zählen die Abstände der Levels ab dem Anker",
       d3["spanne"]["frisch"] is False and "älter als 2 Tage" in " ".join(d3["spanne"]["fehlt"]) and d3["kopf"]["frisch"] is False
       and d3["levels"]["kurs"] == 60_000.0 and "älter als 2 Tage" in d3["satz"]["text"] and d3b["spanne"]["frisch"] is True and d3b["kopf"]["frisch"] is True
       and d3["levels"]["frisch"] is False and "älter als 2 Tage" in " ".join(d3["levels"]["fehlt"]) and d3b["levels"]["frisch"] is True
       and not d3b["levels"]["fehlt"] and d["levels"]["frisch"] is True,
       f"{(d3['spanne']['fehlt'] or ['kein Hinweis'])[0]} | Kurs frisch {d3['kopf']['frisch']}")
    leer = bauen({"coin": "XMR", "jetzt": jetzt})
    ok("Leere Quellen (frisches System): Antwort ohne Ausnahme; nur die Lampe Wochenende hat einen Zustand (aus), alle anderen sind grau "
       "-- ohne Quelle gibt es kein „aus“; jedes Instrument nennt, was fehlt",
       leer["ok"] and leer["spanne"]["fehlt"] and leer["levels"]["fehlt"] and leer["kosten"]["fehlt"] and leer["schwankung"]["pz"] is None
       and leer["schwankung"]["frisch"] is False and leer["levels"]["frisch"] is False
       and [l["zustand"] for l in leer["lampen"]] == ["grau", "grau", "aus", "grau", "grau"] and "noch keine Spanne" in leer["satz"]["text"],
       [l["zustand"] for l in leer["lampen"]])
    js = json.dumps(_ohne_nan(bauen(dict(copy.deepcopy(Q), vol=dict(Q["vol"], real30=float("nan"))))), allow_nan=False)
    ok("Antwort ist JSON ohne NaN (auch wenn eine Quelle NaN liefert)", '"real30": null' in js, f"{len(js)} Zeichen")
    kn = kern("BTC", copy.deepcopy(Q))
    ok("Streifen: 80-%-Spanne der 7 Tage in % zum Anker und die fünf Lampenzustände",
       abs(kn["lo"] + 0.10) < 1e-12 and abs(kn["hi"] - 0.10) < 1e-12 and kn["lampen"] == [l["zustand"] for l in d["lampen"]] and len(kn["lampen"]) == 5,
       f"{_pc(kn['lo'], 0, True)} / {_pc(kn['hi'], 0, True)} · {kn['lampen']}")

    # ---- 4c) Unstaking (23.100, U254): gemessen, neutral, nur ETH
    tag0 = jetzt // TAG * TAG                                                # Mittwoch 11.11.2026
    U_k = {"ok": True, "quelle": "knoten", "stand": jetzt - 1200, "frisch": True, "geschaetzt": False, "fehlt": [], "hinweise": [],
           "voll_eth": 250_000.0, "teil_eth": 50_000.0, "summe_eth": 300_000.0, "konsol_eth": 190_000.0,
           "ende_ts": jetzt + 6 * TAG + 3600, "schlange_ende_ts": jetzt + 5 * TAG, "durchsatz_tag_eth": 57_600, "schwelle_tag_eth": 28_800,
           "kalender": [[tag0, 20_000.0, 5_000.0], [tag0 + TAG, 28_800.0, 0.0], [tag0 + 2 * TAG, 52_000.0, 7_600.0],
                        [tag0 + 3 * TAG, 28_799.0, 0.0]] + [[tag0 + (4 + i) * TAG, 1_000.0, 0.0] for i in range(14)],
           "gross": {"von_ts": tag0 + TAG, "bis_ts": tag0 + 2 * TAG, "tage": 2, "eth": 86_400.0},
           "adressen": [{"adresse": "0x" + "ab" * 20, "eth": 125_000.0, "n": 61, "von_ts": tag0 + TAG + 100, "bis_ts": tag0 + 3 * TAG + 100}],
           "eintritt": {"eth": 904_393.0, "tage": 15.7, "tag": "2026-11-11", "ts": tag0}, "lauf_tage": 6.91}
    un = unstaking_bauen(copy.deepcopy(U_k), 2_000.0, jetzt)
    ok("Unstaking, Abgleich: Summe, Ende, Kalender (14 Tage, der Rest als Summe) und Abzieher gleich der Quelle; Wert in USD = ETH × Kurs",
       un["ok"] and un["summe_eth"] == 300_000.0 and un["ende_ts"] == U_k["ende_ts"] and un["usd"] == 6e8 and un["usd_text"] == "600 Mio. USD" and _usd(1.5e9) == "1,50 Mrd. USD" and _usd(950.0) == "950 USD"
       and len(un["tage"]) == UNSTAKING_TAGE and [t_["eth"] for t_ in un["tage"][:4]] == [25_000.0, 28_800.0, 59_600.0, 28_799.0]
       and un["tage"][0]["teil"] == 5_000.0 and un["tage_mehr"] == 4 and un["tage_mehr_eth"] == 4_000.0
       and abs(sum(t_["eth"] for t_ in un["tage"]) + un["tage_mehr_eth"] - sum(k_[1] + k_[2] for k_ in U_k["kalender"])) < 1e-6
       and un["abzieher"][0]["kurz"] == "0xabab…abab" and un["abzieher"][0]["anteil"] == 0.5 and un["abzieher"][0]["von"] == "Do 12.11."
       and un["abzieher"][0]["bis"] == "Sa 14.11.",
       f"{_eth(un['summe_eth'])} ETH ≈ {un['usd_text']}; {len(un['tage'])} Tage + {un['tage_mehr']}; Abzieher {un['abzieher'][0]['kurz']} {un['abzieher'][0]['anteil']}")
    ok("Unstaking, Schwelle: ein Tag zählt ab 28.800 ETH als groß (28.799 nicht); der Balken ist der Anteil am Tagesdurchsatz, höchstens voll "
       "(59.600 ETH an einem Tag = voller Balken)",
       [t_["gross"] for t_ in un["tage"][:4]] == [False, True, True, False] and un["tage"][1]["anteil"] == 0.5 and un["tage"][2]["anteil"] == 1.0
       and abs(un["tage"][0]["anteil"] - 25_000 / 57_600) < 1e-12 and un["schwelle"] == 28_800.0 and un["durchsatz"] == 57_600.0,
       f"{[(t_['tag'], t_['gross'], round(t_['anteil'], 2)) for t_ in un['tage'][:4]]}")
    ok("Unstaking, Satz: nennt den Termin der nächsten großen Freigabe mit Menge und Wert; ohne solche Tage sagt er das mit der Schwelle",
       un["satz"] == "Nächste große Freigabe: Do 12.11. bis Fr 13.11. · 86.400 ETH (≈ 173 Mio. USD)."
       and un["gross"]["von"] == "Do 12.11." and un["gross"]["usd"] == 172_800_000.0
       and unstaking_bauen(dict(U_k, gross={"von_ts": tag0, "bis_ts": tag0, "tage": 1, "eth": 30_000.0}), None, jetzt)["satz"]
       == "Nächste große Freigabe: Mi 11.11. · 30.000 ETH."
       and unstaking_bauen(dict(U_k, gross=None), 2_000.0, jetzt)["satz"] == "Keine große Freigabe angemeldet: kein Tag ab 28.800 ETH.",
       un["satz"])
    un_ohne = unstaking_bauen(copy.deepcopy(U_k), None, jetzt)
    un_g = unstaking_bauen(dict(U_k, quelle="tagesdatei", geschaetzt=True, teil_eth=None, konsol_eth=None, adressen=[], lauf_tage=None,
                                hinweise=["Der Beacon-Knoten liefert keinen frischen Stand; Kalender aus der Tagesdatei geschätzt."]), 2_000.0, jetzt)
    un_fehlt = unstaking_bauen({"ok": False, "fehlt": ["staking.db fehlt noch."]}, 2_000.0, jetzt)
    ok("Unstaking, ohne Quelle kein Wert: ohne frischen Kurs kein USD-Betrag; Ersatz aus der Tagesdatei ist als Schätzung gekennzeichnet; "
       "ohne Stand nur die Gründe; anderer Coin = kein Instrument",
       un_ohne["usd"] is None and un_ohne["usd_text"] is None and "USD" not in un_ohne["satz"] and un_ohne["summe_eth"] == 300_000.0
       and un_g["geschaetzt"] and un_g["quelle"] == "tagesdatei" and un_g["nicht_gezaehlt"] is None and un_g["abzieher"] == []
       and "mit dem Auszahlungslauf danach" in un_g["auszahlung"] and len(un_g["hinweise"]) == 1
       and un_fehlt["ok"] is False and un_fehlt["fehlt"] == ["staking.db fehlt noch."] and un_fehlt["tage"] == [] and "summe_eth" not in un_fehlt
       and unstaking_bauen(None, 2_000.0, jetzt) is None,
       f"ohne Kurs: {un_ohne['satz']} | geschätzt: {un_g['auszahlung'][:60]}…")
    ok("Unstaking, Texte: Auszahlung (Teilabzüge sofort, Vollabzüge binnen der Laufdauer, Höchstdurchsatz), Gegenseite und die nicht "
       "mitgezählten Zusammenlegungen",
       un["auszahlung"] == ("„Frei ab“ heißt: Von da an darf die Kette auszahlen. Teilabzüge kommen dann sofort, Vollabzüge binnen bis zu "
                            "6,9 Tagen danach. Je Tag verlassen höchstens 57.600 ETH das Staking.")
       and un["gegenseite"] == "Gegenseite: 904.393 ETH warten darauf, gestakt zu werden (Tagesstand 11.11.)."
       and un["nicht_gezaehlt"] == "Nicht mitgezählt: 190.000 ETH in Zusammenlegungen -- sie bleiben gestakt."
       and un["beleg"] == BELEG_UNSTAKING + " " + pruefung_bauen(None)["lang"] and "noch nicht geprüft" in un["beleg"]
       and "ohne Warnfarbe" in un["beleg"], un["gegenseite"])
    td_alt = {"tag": "2026-10-25", "ts": tag0 - 17 * TAG, "frisch": False, "alt_tage": 17, "eintritt_eth": 1_309_352.0}
    U_alt = {k_: v_ for k_, v_ in U_k.items() if k_ != "eintritt"}
    un_alt = unstaking_bauen(dict(U_alt, tagesdatei=td_alt), 2_000.0, jetzt)
    un_alt0 = unstaking_bauen(dict(U_alt, tagesdatei=td_alt, lauf_tage=None), 2_000.0, jetzt)
    un_frisch = unstaking_bauen(dict(U_k, tagesdatei=dict(td_alt, tag="2026-11-11", frisch=True, alt_tage=0)), 2_000.0, jetzt)
    ok("Unstaking, stehengebliebene Tagesdatei (23.102; wie seit 25.10.2026): Die Karte lässt die Gegenseite nicht still weg, sondern sagt, "
       "dass der Wert fehlt und bis wann die Quelle reicht -- den alten Wert zeigt sie nicht; die Dauer des Auszahlungslaufs nennt den Tag "
       "ihrer Zahl; Stand und Kalender vom Knoten bleiben; mit frischer Tagesdatei alles wie bisher; ohne Angabe zur Tagesdatei kein Satz",
       un_alt["ok"] and un_alt["summe_eth"] == 300_000.0 and len(un_alt["tage"]) == UNSTAKING_TAGE
       and un_alt["gegenseite"] == ("Gegenseite (ETH, das auf das Staking wartet): zurzeit kein Wert, weil die Tagesdatei der Quelle am "
                                    "25.10.2026 endet.")
       and "1.309.352" not in str(un_alt) and un_alt["eintritt_eth"] is None
       and un_alt["auszahlung"] == ("„Frei ab“ heißt: Von da an darf die Kette auszahlen. Teilabzüge kommen dann sofort, Vollabzüge binnen bis "
                                    "zu 6,9 Tagen danach (Zahl der Validatoren vom 25.10.2026). Je Tag verlassen höchstens 57.600 ETH das Staking.")
       and "mit dem Auszahlungslauf danach." in un_alt0["auszahlung"] and "Zahl der Validatoren" not in un_alt0["auszahlung"]
       and un_frisch["gegenseite"] == un["gegenseite"] and un_frisch["auszahlung"] == un["auszahlung"]
       and unstaking_bauen(dict(U_alt), 2_000.0, jetzt)["gegenseite"] is None
       and unstaking_bauen(dict(U_alt, tagesdatei=dict(td_alt, tag="kaputt")), 2_000.0, jetzt)["gegenseite"] is None
       and _iso_datum("2026-10-25") == "25.10.2026" and _iso_datum("25.10.2026") is None and _iso_datum(None) is None
       and _iso_datum("2026-1o-25") is None, un_alt["gegenseite"])
    # ---- 4d) Prüfung der Kursfolge (23.101, U255): das gespeicherte Urteil als Text, ohne Farbe
    P_nb = {"da": True, "regel": "U255/1", "aktuell": True, "ts": 20772 * TAG + 8 * 3600, "urteil": "nicht belegt", "debug": 147, "min_faelle": 8,
            "A": {"n": 14, "urteil": "nicht belegt", "diff": -0.012, "p": 0.21, "p_holm": 0.42, "grenze": 0.045},
            "B": {"n": 13, "urteil": "nicht belegt", "diff": 0.004, "p": 0.6, "p_holm": 0.6, "grenze": 0.05}}
    pr0 = pruefung_bauen(None); pr_nb = pruefung_bauen(P_nb)
    pr_b = pruefung_bauen(dict(P_nb, urteil="belegt", A=dict(P_nb["A"], urteil="belegt", diff=-0.031, p_holm=0.012)))
    pr_w = pruefung_bauen(dict(P_nb, urteil="zu wenige Fälle", A=dict(P_nb["A"], n=5, urteil="zu wenige Fälle"),
                               B=dict(P_nb["B"], n=4, urteil="zu wenige Fälle")))
    pr_k = pruefung_bauen(dict(P_nb, urteil="kein Urteil")); pr_alt = pruefung_bauen(dict(P_nb, aktuell=False))
    un_p = unstaking_bauen(copy.deepcopy(U_k), 2_000.0, jetzt, P_nb)
    P_bis = dict(P_nb, daten_bis="2026-10-25")                               # 23.102: die Prüfung reicht nur bis zum Ende ihrer Daten
    pr_bis = pruefung_bauen(P_bis)
    pr_bis_b = pruefung_bauen(dict(P_bis, urteil="belegt", A=dict(P_nb["A"], urteil="belegt", diff=-0.031, p_holm=0.012)))
    pr_bis_w = pruefung_bauen(dict(P_bis, urteil="zu wenige Fälle", A=dict(P_nb["A"], n=5), B=dict(P_nb["B"], n=4)))
    ok("Prüfung der Kursfolge, Reichweite (23.102): Karte und Beleg nennen den letzten bewerteten Tag („Wellen bis …“) -- bei jedem "
       "Urteil; fehlt die Angabe oder ist sie kein Datum, steht keines da",
       pr_bis["kurz"] == "Folgt darauf ein Kursrückgang? Geprüft am 15.11.2026 (Wellen bis 25.10.2026): nicht belegt."
       and pr_bis["lang"] == ("Ob auf große Abzüge Kursrückgänge folgen, ist geprüft (15.11.2026, Regeln vorab festgelegt, Wellen bis "
                              "25.10.2026): nicht belegt (14 Fälle nach der Anmeldung, 13 nach der Freigabe). Ein Nachteil unter rund 5,0 % "
                              "wäre mit diesen Daten oft nicht zu erkennen. Deshalb ohne Warnfarbe.")
       and pr_bis_b["kurz"] == "Folgt darauf ein Kursrückgang? Geprüft am 15.11.2026 (Wellen bis 25.10.2026): belegt (nach der Anmeldung)."
       and "Regeln vorab festgelegt, Wellen bis 25.10.2026): belegt -- " in pr_bis_b["lang"]
       and pr_bis_w["kurz"] == "Folgt darauf ein Kursrückgang? Zu wenige Fälle für ein Urteil (Stand 15.11.2026, Wellen bis 25.10.2026)."
       and pruefung_bauen(dict(P_nb, daten_bis="irgendwann"))["kurz"] == pr_nb["kurz"]
       and pruefung_bauen(dict(P_nb, daten_bis=None))["lang"] == pr_nb["lang"] and "Wellen bis" not in pr_nb["kurz"] + pr_nb["lang"]
       and unstaking_bauen(copy.deepcopy(U_k), 2_000.0, jetzt, P_bis)["beleg"].endswith(pr_bis["lang"]), pr_bis["kurz"])
    ok("Prüfung der Kursfolge (U255) im Cockpit: ohne Urteil „noch nicht geprüft“ mit der Debug-Nummer; mit Urteil Datum und Wortlaut -- "
       "nicht belegt mit Fallzahlen und der größeren Nachweisgrenze, belegt mit dem Unterschied nur der belegten Frage, zu wenige Fälle "
       "mit der nötigen Zahl; immer „ohne Warnfarbe“; ein Urteil einer älteren Fassung ist gekennzeichnet; auch ohne Stand steht das Urteil da",
       pr0 == {"da": False, "urteil": None, "ts": None, "kurz": "Folgt darauf ein Kursrückgang? Noch nicht geprüft (Debug 147 rechnet die Prüfung).",
               "lang": ("Ob auf große Abzüge Kursrückgänge folgen, ist noch nicht geprüft: Die Prüfung ist vorab festgelegt "
                        "(KONZEPT_Unstaking.md 6) und rechnet einmal mit Debug 147 -- bis dahin ohne Warnfarbe.")}
       and pruefung_bauen({"da": False, "debug": 147}) == pr0
       and pr_nb["kurz"] == "Folgt darauf ein Kursrückgang? Geprüft am 15.11.2026: nicht belegt."
       and pr_nb["lang"] == ("Ob auf große Abzüge Kursrückgänge folgen, ist geprüft (15.11.2026, Regeln vorab festgelegt): nicht belegt "
                             "(14 Fälle nach der Anmeldung, 13 nach der Freigabe). Ein Nachteil unter rund 5,0 % wäre mit diesen Daten "
                             "oft nicht zu erkennen. Deshalb ohne Warnfarbe.")
       and pr_b["kurz"] == "Folgt darauf ein Kursrückgang? Geprüft am 15.11.2026: belegt (nach der Anmeldung)."
       and "nach der Anmeldung lag ETH in den 7 Tagen im Mittel 3,1 %-Punkte schwächer gegen BTC als sonst." in pr_b["lang"]
       and "nach der Freigabe lag" not in pr_b["lang"] and "Die Warnlampe dazu wird eigens festgelegt -- bis dahin ohne Warnfarbe." in pr_b["lang"]
       and pr_w["kurz"] == "Folgt darauf ein Kursrückgang? Zu wenige Fälle für ein Urteil (Stand 15.11.2026)."
       and "5 Fälle nach der Anmeldung, 4 nach der Freigabe, nötig sind 8." in pr_w["lang"]
       and pr_k["kurz"] == "Folgt darauf ein Kursrückgang? Prüfung vom 15.11.2026 ohne gültiges Urteil." and "Nullprobe" in pr_k["lang"]
       and pr_alt["kurz"] == pr_nb["kurz"] + " Ältere Fassung der Regeln -- Debug 147 rechnet neu."
       and all("ohne Warnfarbe" in x_["lang"] and x_["da"] == (x_ is not pr0) for x_ in (pr0, pr_nb, pr_b, pr_w, pr_k))
       and [x_["urteil"] for x_ in (pr_nb, pr_b, pr_w, pr_k)] == ["nicht belegt", "belegt", "zu wenige Fälle", "kein Urteil"]
       and un_p["pruefung"] == pr_nb and un_p["beleg"] == BELEG_UNSTAKING + " " + pr_nb["lang"] and un["pruefung"] == pr0
       and unstaking_bauen({"ok": False, "fehlt": ["x"]}, None, jetzt, P_nb)["pruefung"] == pr_nb
       and unstaking_bauen({"ok": False, "fehlt": ["x"]}, None, jetzt, P_nb)["beleg"].endswith(pr_nb["lang"]),
       pr_nb["kurz"])
    Q_eth = _probe_quellen(jetzt, "ETH"); Q_eth["unstaking"] = copy.deepcopy(U_k)
    d_eth = bauen(copy.deepcopy(Q_eth)); Q_btc_u = copy.deepcopy(Q); Q_btc_u["unstaking"] = copy.deepcopy(U_k)
    Q_alt_kurs = copy.deepcopy(Q_eth); Q_alt_kurs["kurs"]["ts"] = jetzt - FRISCH_KURS_S - 1
    ok("Unstaking im Cockpit: nur bei ETH (bei BTC auch dann nicht, wenn die Quelle etwas liefert); USD zum Kurs des Kopfes, mit altem Kurs keiner; "
       "ohne Quelle bei ETH kein Instrument",
       d_eth["unstaking"]["ok"] and d_eth["unstaking"]["usd"] == 300_000.0 * d_eth["kopf"]["kurs"] and bauen(Q_btc_u)["unstaking"] is None
       and d["unstaking"] is None and bauen(Q_alt_kurs)["unstaking"]["usd"] is None and bauen(_probe_quellen(jetzt, "ETH"))["unstaking"] is None
       and len(d_eth["lampen"]) == 5
       and d_eth["satz"]["unstaking"] == "Unstaking (gemessen): " + d_eth["unstaking"]["satz"] and d_eth["satz"]["unstaking"].startswith("Unstaking (gemessen): Nächste große Freigabe: Do 12.11.")
       and "unstaking" not in d["satz"] and "unstaking" not in bauen(Q_btc_u)["satz"]
       and "unstaking" not in bauen(dict(copy.deepcopy(Q_eth), unstaking={"ok": False, "fehlt": ["staking.db fehlt noch."]}))["satz"]
       and d_eth["unstaking"]["pruefung"] == pr0 and bauen(dict(copy.deepcopy(Q_eth), unstaking_pruefung=P_nb))["unstaking"]["pruefung"] == pr_nb
       and "lampe" not in json.dumps(pr_b).lower().replace("warnlampe dazu wird eigens", "")
       and len(bauen(dict(copy.deepcopy(Q_eth), unstaking_pruefung=dict(P_nb, urteil="belegt")))["lampen"]) == 5,
       f"ETH {d_eth['unstaking']['usd_text']}, BTC {bauen(copy.deepcopy(Q_btc_u))['unstaking']}; oben: {d_eth['satz'].get('unstaking')}")

    # ---- 4e) Verlauf (23.104, U260): Antwort für die Karte „Unstaking · Verlauf“ -- gemessen, ohne Farbe, ohne Urteil
    V_h, jv = _probe_verlauf()
    D0v, U_v = V_h["von_D"], V_h["urteil"]
    iso_v = lambda D_: time.strftime("%Y-%m-%d", time.gmtime(D_ * TAG))  # noqa: E731

    def vmit(**kw):
        v_ = copy.deepcopy(V_h); v_.update(kw)
        return verlauf_bauen(v_, jv)
    vb = verlauf_bauen(copy.deepcopy(V_h), jv)
    ok("Verlauf, Reihen: je Tag ab dem ersten die Schlange aus der Tagesdatei (gerundet, fehlende Tage leer), die eigene Messung ab ihrem "
       "ersten Tag (ein fehlender Tag darin bleibt leer), der ETH-Kurs auf zwei Stellen; Umfang und letzter Tag mit einer Schlange",
       vb["ok"] and vb["d0"] == D0v and vb["n"] == 500 and len(vb["q"]) == len(vb["px"]) == 500
       and [vb["q"][i_] for i_ in (0, 1, 99, 100, 114, 115, 199, 200, 201, 202, 299, 300, 302, 303, 399, 400, 428, 429, 430)]
       == [1000, 1010, 1990, None, None, 2150, 2990, None, None, 3020, 3990, None, None, 4030, 4990, None, None, 5290, None]
       and vb["k"] == {"ab": 429, "w": [9999, 5000, 6001, None, 7000]}
       and [vb["px"][i_] for i_ in (0, 1, 249, 250, 251, 499)] == [2000.12, 2001.12, 2249.12, None, 2251.12, 2499.12]
       and vb["tage_q"] == 381 and vb["tage_k"] == 4 and vb["tage_px"] == 499 and vb["letzter"] == 433
       and (vb["von"], vb["bis"], vb["td_bis"], vb["kn_von"]) == ("04.10.2024", "15.02.2026", "07.12.2025", "07.12.2025"),
       f"{vb['n']} Tage, eigene Messung {vb['k']}, letzter Tag {vb['letzter']}")
    ok("Verlauf, keine Daten: Fehlt die Schlange drei Tage oder länger in Folge, ist das ein Zeitraum ohne Daten (zwei fehlende Tage "
       "nicht) -- auch am Ende bis heute; die ausgeschlossene Zeit trägt ihren Grund; ein Zeitraum über den Jahreswechsel nennt beide Jahre",
       VERLAUF_LUECKE_TAGE == 3 and vb["luecke_tage"] == 3 and vb["luecken"] == [[100, 114], [300, 302], [400, 428], [434, 499]]
       and vb["luecken_text"] == ["12.01.–26.01.2025 (laut Quelle falsche Einheit)", "31.07.–02.08.2025", "08.11.–06.12.2025", "12.12.2025–15.02.2026"]
       and vmit(ausgeschlossen=[])["luecken_text"][0] == "12.01.–26.01.2025"
       and vmit(ausgeschlossen=[iso_v(D0v + 101), iso_v(D0v + 114)])["luecken_text"][0] == "12.01.–26.01.2025"
       and _spanne_de(D0v, D0v) == "04.10.2024" and _tag_nr_iso("2026-10-25") == 20751 and _tag_nr_iso("kaputt") is None and _tag_nr_iso(None) is None,
       f"{vb['luecken']} {vb['luecken_text']}")
    w_ = vb["wellen"]
    ok("Verlauf, Wellen: nur die Fälle des Urteils, die in der Reihe liegen, an ihrem Tag; der Text nennt Tag, Zuwachs und Stand der Schlange "
       "und die Renditen der 7 Tage ab der Anmeldung (nicht der Freigabe) so, wie Debug 147 sie zeigt (Vorzeichen, eine Stelle, keine "
       "negative Null); ein offenes Fenster und ein fehlender Kurs stehen als Satz da; die Zeile der Liste trägt dieselben Zahlen",
       [x_["i"] for x_ in w_] == [50, 320, 390, 395] and [x_["nr"] for x_ in w_] == ["1", "2", "3", "4"]
       and w_[0]["text"] == ("Welle 1, gemessen am 23.11.2024: Schlange gegen den Vortag +88.128 ETH (auf 89.920 ETH). ETH in den 7 Tagen "
                             "danach +1,5 %, gegen BTC −3,1 %.")
       and w_[0]["zeile"] == ["1", "23.11.2024", "+88.128", "+1,5", "−3,1"] and w_[1]["zeile"] == ["2", "20.08.2025", "+60.000", "0,0", "0,0"]
       and w_[1]["text"].endswith("(auf 61.001 ETH). ETH in den 7 Tagen danach 0,0 %, gegen BTC 0,0 %.")
       and w_[2]["text"] == ("Welle 3, gemessen am 29.10.2025: Schlange gegen den Vortag +568.436 ETH (auf 773.447 ETH). Das Fenster von 7 "
                             "Tagen war bei der Prüfung noch offen.") and w_[2]["zeile"][3:] == ["·", "·"]
       and w_[3]["text"] == "Welle 4, gemessen am 03.11.2025: Schlange gegen den Vortag +70.000 ETH. Für die 7 Tage danach fehlt der Kurs."
       and vb["liste_kopf"] == ["Nr.", "gemessen am", "Zuwachs ETH", "ETH 7 T", "gegen BTC"] and "Dieselben Zahlen wie in Debug 147." in vb["liste_hinweis"]
       and (_pz_log(0.0149), _pz_log(-0.0312), _pz_log(-0.0004), _pz_log(0.0), _pz_log(None), _pz_log(-0.0148, 2), _pz_log(1.23456))
       == ("+1,5", "−3,1", "0,0", "0,0", None, "−1,48", "+123,5"),
       f"{[x_['zeile'] for x_ in w_]}")
    satz_v = ("Markiert sind die 4 Wellen der Prüfung vom 15.11.2026: Tage, zu deren Beginn die Schlange gegen den Vortag um mindestens "
              "57.600 ETH gewachsen war (eine neue Welle zählt erst nach 14 ruhigen Tagen). In den 7 Tagen danach lag ETH gegen BTC im Mittel "
              "bei −1,48 % (18 Wellen gewertet), über alle Tage bei −0,48 %.")
    vb_k = vmit(urteil=dict(U_v, urteil="kein Urteil"))
    vb_b = vmit(urteil=dict(U_v, urteil="belegt", A=dict(U_v["A"], urteil="belegt", p_holm=0.012)))
    vb_w = vmit(urteil=dict(U_v, urteil="zu wenige Fälle", A=dict(U_v["A"], urteil="zu wenige Fälle", n=4, p_holm=None)))
    vb_ohne = vmit(urteil=None, wellen=[])
    ok("Verlauf, Satz unter dem Bild: Zahl der markierten Wellen, Tag der Prüfung, die Regel der Welle, Mittel nach den Wellen und über "
       "alle Tage und das Urteil der Frage A mit p nach Holm -- als Text, auch bei „belegt“; ein Gesamturteil „kein Urteil“ geht vor; zu "
       "wenige Fälle, eine ältere Fassung der Regeln, ein Urteil ohne Welle und die noch nicht gerechnete Prüfung stehen als Satz da",
       vb["satz"] == satz_v + " Der Unterschied ist nicht belegt (p nach Holm 0,422)."
       and vb_k["satz"] == satz_v + " Die Prüfung gab dazu kein gültiges Urteil."
       and vb_b["satz"] == satz_v + " Der Unterschied ist belegt (p nach Holm 0,012)."
       and vb_w["satz"] == satz_v.replace(" (18 Wellen gewertet)", "") + " Für ein Urteil sind es zu wenige Fälle."
       and vmit(urteil=dict(U_v, aktuell=False))["satz"] == vb["satz"] + " Das Urteil stammt aus einer älteren Fassung der Regeln."
       and vmit(wellen=[])["satz"] == "Die Prüfung vom 15.11.2026 nennt in diesen Daten keine Welle."
       and vb_ohne["satz"] == "Wellen sind noch nicht markiert: Die Prüfung der Kursfolge ist noch nicht gerechnet (Debug 147 rechnet sie einmal)."
       and vb_ohne["wellen"] == [] and "farbe" not in json.dumps(vb_b).lower() and "lampe" not in json.dumps(vb_b).lower(),
       vb["satz"][-60:])
    quellen_v = ("Schlange bis 07.12.2025: Tagesdatei von validatorqueue.com (ob sie seit Mai 2025 Zusammenlegungen mitzählt, ist offen). Ab "
                 "07.12.2025: eigene Messung am Knoten (Vollabzüge in der Schlange, ohne Sperrfrist und ohne Zusammenlegungen). Je UTC-Tag die "
                 "erste Messung. Grau = keine Daten: 12.01.–26.01.2025 (laut Quelle falsche Einheit), 31.07.–02.08.2025, 08.11.–06.12.2025, "
                 "12.12.2025–15.02.2026. Kurs: ETH zu Beginn des UTC-Tags (30-min-Kerzen der Binance-Perpetuals). Gemessen, keine Vorhersage: "
                 "Der Verlauf allein belegt keinen Zusammenhang.")
    vb_ku = vmit(kurs={})
    vb_eig = vmit(tagesdatei={}, td=None, von_D=D0v + 429)
    vb_frueh = vmit(td=dict(V_h["td"], bis="2025-05-21"))
    ok("Verlauf, Quellen unter dem Bild: woher die Schlange bis wann kommt und ab wann die eigene Messung gilt, der offene Punkt der "
       "Zusammenlegungen (nur, wenn die Tagesdatei über den 22.05.2025 hinausreicht), die Zeiträume ohne Daten, die Herkunft des Kurses "
       "(nur, wenn es einen gibt) und der Satz, dass der Verlauf nichts belegt; Hinweise der Quelle werden weitergereicht",
       vb["quellen"] == quellen_v and vb["hinweise"] == ["Kurs: Probe."]
       and vb_ku["tage_px"] == 0 and vb_ku["px"] == [None] * 500 and "Kurs: ETH zu Beginn" not in vb_ku["quellen"]
       and vb_ku["quellen"].endswith("12.12.2025–15.02.2026. Gemessen, keine Vorhersage: Der Verlauf allein belegt keinen Zusammenhang.")
       and vb_eig["ok"] and vb_eig["n"] == 71 and vb_eig["td_bis"] is None and vb_eig["k"] == {"ab": 0, "w": [9999, 5000, 6001, None, 7000]}
       and vb_eig["quellen"].startswith("Ab 07.12.2025: eigene Messung am Knoten") and vb_eig["luecken"] == [[5, 70]] and vb_eig["letzter"] == 4
       and vb_eig["wellen"] == [] and "ist offen" not in vb_frueh["quellen"]
       and vb_frueh["quellen"].startswith("Schlange bis 21.05.2025: Tagesdatei von validatorqueue.com. Ab 07.12.2025:"),
       vb["quellen"][:80])
    neu_v = {"ok": True, "regel": "U255/2", "festgelegt": "16.11.2026", "noetig": 8, "erkannt": 2, "bewertet": 1, "frei_ab_D": None,
             "faellig": False, "start": None, "stichtag_D": None,
             "faelle": [{"nr": 1, "a": D0v + 431, "b": D0v + 432, "zuwachs": 66_777.4, "angemeldet": 315_000.2, "a_zu": True, "b_zu": True},
                        {"nr": 2, "a": D0v + 499, "b": None, "zuwachs": None, "angemeldet": None},
                        {"nr": 3, "a": D0v + 600, "zuwachs": 60_000.0}, {"nr": 4, "a": None}]}       # außerhalb der Reihe und ohne Tag: kein Ort
    vb_n = vmit(knoten_art="angemeldet", neu=neu_v)
    vb_n0 = vmit(knoten_art="angemeldet", neu=dict(neu_v, erkannt=0, faelle=[], frei_ab_D=D0v + 520))
    vb_nf = vmit(knoten_art="angemeldet", neu=dict(neu_v, erkannt=9, faelle=[], faellig=True, frei_ab_D=D0v + 520))
    vb_na = vmit(knoten_art="angemeldet")
    zweite_v = (" Zweite Prüfung, vorab festgelegt am 16.11.2026: Sie zählt nur neue Wellen der eigenen Messung und wird einmal gerechnet, "
                "sobald 8 davon bewertet sind -- bisher ")

    def sicher_v(fn, ersatz):                                            # eine Ausnahme in der Probe ist ein Fehlschlag, kein Abbruch
        try:
            return fn()
        except Exception:  # noqa: BLE001
            return ersatz
    tn = sicher_v(lambda: verlauf_text(vb_n), ["Ausnahme"] * 4)
    tv0 = sicher_v(lambda: verlauf_text(vb), ["Ausnahme"] * 4)
    ok("Verlauf, zweite Prüfung (23.106, U259): Neue Wellen der eigenen Messung stehen hinter den Wellen des Urteils -- mit eigener "
       "Nummer (N1 …), Tag, Zuwachs und einem Text ohne Kursfolge; in der Liste stehen an ihrer Stelle Punkte; was außerhalb der Reihe "
       "liegt, hat keinen Ort; der Satz unter dem Bild nennt die Regel in einem Satz und den Zähler, dazu den frühesten Tag einer "
       "neuen Welle oder „fällig“; ohne die Angaben der zweiten Prüfung bleibt alles, wie es war",
       sicher_v(lambda: ([w_["nr"] for w_ in vb_n["wellen"]] == ["1", "2", "3", "4", "N1", "N2"] and vb_n["wellen_alt"] == 4 and vb_n["wellen_neu"] == 2
       and vb_n["wellen"][:4] == vb["wellen"] and all("neu" not in w_ for w_ in vb["wellen"])
       and vb_n["wellen"][4] == {"nr": "N1", "i": 431, "tag": "09.12.2025", "zuwachs": 66_777.4, "neu": True,
                                 "text": ("Neue Welle 1 von 8 für die zweite Prüfung, gemessen am 09.12.2025: angemeldete Abzüge gegen den "
                                          "Vortag +66.777 ETH (auf 315.000 ETH). Ihre Kursfolge steht erst mit dem Urteil der zweiten "
                                          "Prüfung hier."),
                                 "zeile": ["N1", "09.12.2025", "+66.777", "·", "·"]}
       and vb_n["wellen"][5]["i"] == 499 and vb_n["wellen"][5]["zeile"] == ["N2", "15.02.2026", "—", "·", "·"]
       and "gegen den Vortag gewachsen. Ihre Kursfolge" in vb_n["wellen"][5]["text"]
       and not any("%" in w_["text"] for w_ in vb_n["wellen"][4:])
       and vb_n["satz"] == vb["satz"] + zweite_v + ("2. Neue Wellen tragen einen offenen Kreis; ihre Kursfolge steht erst mit dem Urteil der "
                                                    "zweiten Prüfung hier.")
       and vb_n0["satz"] == vb["satz"] + zweite_v + "0. Eine neue Welle kann frühestens am 08.03.2026 beginnen." and vb_n0["wellen"] == vb["wellen"]
       and vb_nf["satz"] == vb["satz"] + zweite_v + "9. Sie ist fällig; ihre Rechnung steht noch aus."
       and vb_n["neu"] == {"regel": "U255/2", "noetig": 8, "erkannt": 2, "faellig": False} and vb_nf["neu"]["faellig"] is True
       and vb_n["liste_hinweis"].endswith(" N = neue Welle der eigenen Messung; ihre Kursfolge steht erst mit dem Urteil der zweiten Prüfung hier.")
       and vb_n0["liste_hinweis"] == vb["liste_hinweis"] and vb_na["satz"] == vb["satz"] and vb_na["wellen"] == vb["wellen"]
       and vb["neu"] is None and vb["wellen_alt"] == 4 and vb["wellen_neu"] == 0 and vb["k_name"] is None
       and vmit(neu=dict(neu_v, faelle=neu_v["faelle"][:1]), wellen=[], urteil=None)["satz"].startswith(
           "Wellen sind noch nicht markiert: Die Prüfung der Kursfolge ist noch nicht gerechnet (Debug 147 rechnet sie einmal)." + zweite_v + "2.")), False),
       sicher_v(lambda: vb_n["satz"][-150:], "Ausnahme"))
    ok("Verlauf, eigene Messung als Summe (23.106): Meldet die Quelle „angemeldet“, sagen Quellenzeile, Feldname, Ablesewort und "
       "Debug-Text, dass die eigene Messung die angemeldeten Abzüge zeigt (Schlange, Sperrfrist, Teilabzüge) -- mit beiden Daten im "
       "Feldnamen; ohne Tagesdatei heißt das Feld nur „Angemeldete Abzüge“; ohne die Meldung bleibt der bisherige Wortlaut",
       sicher_v(lambda: (vb_n["quellen"] == quellen_v.replace("eigene Messung am Knoten (Vollabzüge in der Schlange, ohne Sperrfrist und ohne Zusammenlegungen).",
                                            "eigene Messung am Knoten -- angemeldete Abzüge, die noch nicht frei sind (Schlange, Sperrfrist "
                                            "und Teilabzüge; ohne Zusammenlegungen). Das ist mehr als die Schlange allein.")
       and vb_n["quellen"] != quellen_v and vb_n["achse_q"] == "Abzüge in ETH: bis 07.12.2025 Schlange, ab 07.12.2025 angemeldet"
       and vb_n["k_name"] == "Angemeldet" and vb_n["k"] == vb["k"] and vb_n["q"] == vb["q"]
       and vmit(knoten_art="angemeldet", tagesdatei={}, td=None, von_D=D0v + 429)["achse_q"] == "Angemeldete Abzüge in ETH, noch nicht frei"
       and vmit(knoten_art="angemeldet", knoten={}, kn=None)["achse_q"] == "Schlange der Abzüge in ETH"
       and vmit(knoten_art="angemeldet", knoten={}, kn=None)["k_name"] is None
       and vmit(knoten_art="schlange")["quellen"] == quellen_v and vmit(knoten_art="schlange")["achse_q"] == "Schlange der Abzüge in ETH"
       and " · 4 Wellen markiert und 2 neue · Ausschnitt beim Öffnen: 1 Jahr" in tn[0]
       and tn[2].startswith("   Unstaking Verlauf, letzter Tag mit Wert: 11.12.2025 · 7.000 ETH (eigene Messung: angemeldet, noch nicht frei) · ETH-Kurs ")
       and tn[3] == "   Unstaking Verlauf: " + vb_n["satz"]
       and " · 4 Wellen markiert · Ausschnitt beim Öffnen: 1 Jahr" in tv0[0]
       and tv0[2].startswith("   Unstaking Verlauf, letzter Tag mit Schlange: 11.12.2025 · 7.000 ETH (eigene Messung) · ETH-Kurs ")), False),
       sicher_v(lambda: f"{vb_n['achse_q']} | {tn[2][:95]}", "Ausnahme"))
    ok("Verlauf, Ausschnitte und Texte: 3 Monate (92 Tage), 1 Jahr (366 Tage) und alles, beim Öffnen 1 Jahr; ein Ausschnitt erscheint nur, "
       "wenn die Reihe länger ist; Titel und Namen der beiden Felder",
       vb["bereiche"] == [{"key": "3m", "name": "3 Monate", "tage": 92}, {"key": "1j", "name": "1 Jahr", "tage": 366},
                          {"key": "alles", "name": "alles", "tage": 500}] and vb["start"] == "1j"
       and vb_eig["bereiche"] == [{"key": "alles", "name": "alles", "tage": 71}] and vb_eig["start"] == "alles"
       and [b_["key"] for b_ in vmit(von_D=D0v + 300)["bereiche"]] == ["3m", "alles"] and vmit(von_D=D0v + 300)["start"] == "alles"
       and [b_["key"] for b_ in vmit(von_D=D0v + 133)["bereiche"]] == ["3m", "1j", "alles"]
       and [b_["key"] for b_ in vmit(von_D=D0v + 134)["bereiche"]] == ["3m", "alles"]
       and vb["titel"] == "Schlange der Abzüge und ETH-Kurs" and vb["achse_q"] == "Schlange der Abzüge in ETH"
       and vb["achse_px"] == "ETH-Kurs in USD, zu Beginn jedes UTC-Tags",
       f"{[b_['key'] for b_ in vb['bereiche']]} Start {vb['start']}")

    def vt(B_):                                                          # eine Ausnahme im Text ist ein Fehlschlag der Probe, kein Abbruch
        try:
            return verlauf_text(B_)
        except Exception as e_:  # noqa: BLE001
            return [f"Ausnahme: {type(e_).__name__}: {e_}"] * 3
    tv = vt(vb)
    ok("Verlauf im Debug-Text (143): Umfang der Reihen, Zeiträume ohne Daten, letzter Tag mit Schlange (Quelle und Kurs), der Satz und die "
       "Hinweise; ohne Kurs steht „kein Wert“; ohne Verlauf der Grund",
       tv == ["   Unstaking Verlauf (Karte „Unstaking · Verlauf“): 500 Tage vom 04.10.2024 bis 15.02.2026 · Schlange aus der Tagesdatei an "
              "381 Tagen (bis 07.12.2025) · eigene Messung an 4 Tagen (ab 07.12.2025) · ETH-Kurs an 499 Tagen · 4 Wellen markiert · Ausschnitt "
              "beim Öffnen: 1 Jahr",
              "   Unstaking Verlauf, keine Daten: 12.01.–26.01.2025 (laut Quelle falsche Einheit), 31.07.–02.08.2025, 08.11.–06.12.2025, "
              "12.12.2025–15.02.2026",
              "   Unstaking Verlauf, letzter Tag mit Schlange: 11.12.2025 · 7.000 ETH (eigene Messung) · ETH-Kurs 2.433 USD",
              "   Unstaking Verlauf: " + vb["satz"], "   Unstaking Verlauf, Hinweis: Kurs: Probe."]
       and vt(vb_ku)[2].endswith("7.000 ETH (eigene Messung) · ETH-Kurs kein Wert")
       and vt(vmit(knoten={D0v + 430: 5000.0}))[0].count("eigene Messung an 1 Tag (ab 08.12.2025)") == 1
       and vt(vmit(knoten={}, kn=None))[2] == "   Unstaking Verlauf, letzter Tag mit Schlange: 07.12.2025 · 5.290 ETH (Tagesdatei) · ETH-Kurs 2.429 USD"
       and vt({"ok": False, "fehlt": ["staking.db fehlt noch."]}) == ["   Unstaking Verlauf: kein Wert -- staking.db fehlt noch."],
       tv[2])
    ok("Verlauf ohne Daten: keine Quelle, eine Absage der Quelle und eine Reihe von nur einem Tag geben eine Antwort mit Grund statt leerer "
       "Reihen; die Antwort ist gültiges JSON ohne NaN",
       verlauf_bauen(None, jv) == {"ok": False, "jetzt": jv, "version": VERSION_MODUL, "fehlt": ["Verlauf: keine Daten."], "hinweise": []}
       and verlauf_bauen({"ok": False, "fehlt": ["staking.db fehlt noch."]}, jv)["fehlt"] == ["staking.db fehlt noch."]
       and vmit(bis_D=D0v)["fehlt"] == ["Der Verlauf braucht mindestens zwei Tage."] and "q" not in vmit(bis_D=D0v)
       and vmit(bis_D=D0v + 1)["ok"] and vmit(bis_D=D0v + 1)["n"] == 2
       and vmit(tagesdatei={}, knoten={})["fehlt"] == ["Der Verlauf hat keinen Tag mit einer Schlange."]
       and vmit(tagesdatei={D0v + 3: float("nan")}, knoten={D0v + 4: None})["ok"] is False
       and "NaN" not in json.dumps(_ohne_nan(vb), allow_nan=False) and json.loads(json.dumps(_ohne_nan(vb), allow_nan=False)) == vb,
       f"{verlauf_bauen(None, jv)['fehlt']}")

    Rr = R_u = R_alt = R_ohne = R_nix = Rm = rk = {}; Re = {"zeilen": []}; Rg = []; tr = []      # für die Wortprobe, falls die Proben abbrechen
    try:
        # ---- 4f) Kurs-Rechner (23.105, U245 Stufe C2): Wahrscheinlichkeit, dass ein Kurs vom jetzigen Kurs aus berührt wird
        import hl_ausblick as AU_r
        import hl_kaskade as KK_r
        Gr, Sr = _probe_rechner(jetzt)
        Pr = Gr["kurs"]; Lr = Gr["lauf"]["h"]
        dr = (-0.12, -0.05, -0.02, -0.006, 0.004, 0.015, 0.04, 0.10)
        Rr = rechner_bauen(copy.deepcopy(Gr), [Pr * math.exp(x) for x in dr])
        soll_std = lambda x_, key_, h_: KK_r.p_ueber(abs(x_), Gr["kurz"][key_]["c"], Gr["sig4"] * math.sqrt(h_ / 4.0), Gr["kurz"][key_]["tau"])   # noqa: E731
        abw_std = max(abs(z_["p"][i_] - soll_std(x_, key_, h_)) for z_, x_ in zip(Rr["zeilen"], dr) for i_, (key_, h_) in enumerate((("1h", 1), ("4h", 4))))
        ok("Kurs-Rechner, Abgleich Stunden: Die Wahrscheinlichkeit über 1 und 4 Stunden ist genau das Nullmodell des Magnet-Tests "
           "(hl_kaskade.p_ueber) mit Abstand zum jetzigen Kurs, c und τ der Frist und σ über 4 Stunden × √(h ÷ 4) -- über 1 Stunde also "
           "mit der halben Schwankung; oben und unten gleich",
           abw_std < 1e-12 and len(Rr["zeilen"]) == 8 and all(z_["ok"] for z_ in Rr["zeilen"])
           and abs(rechner_bauen(Gr, [Pr * math.exp(0.01)])["zeilen"][0]["p"][0] - rechner_bauen(Gr, [Pr * math.exp(-0.01)])["zeilen"][0]["p"][0]) < 1e-12
           and abs(soll_std(0.006, "1h", 1) - soll_std(0.012, "1h", 4)) < 1e-12 and soll_std(0.006, "1h", 1) < soll_std(0.006, "4h", 4)
           and not any("mindestens" in n_ for z_ in Rr["zeilen"] for n_ in z_["hinweise"]),
           f"größte Abweichung {abw_std:.1e}; bei −0,6 %: 1 h {_rechner_p_text(Rr['zeilen'][3]['p'][0])}, 4 h {_rechner_p_text(Rr['zeilen'][3]['p'][1])}")
        spiegel = [abs(rechner_bauen(dict(Gr, kurz={"1h": dict(Gr["kurz"]["1h"], c=1.0, tau=0.0)}), [Pr * math.exp(k_ * 0.006)])["zeilen"][0]["p"][0] - math.erfc(k_ / math.sqrt(2.0)))
                   for k_ in (1.0, 2.0, 3.0)]
        ok("Kurs-Rechner, Rechnung von Hand: mit c = 1 und τ = 0 gibt das Nullmodell das Spiegelungsprinzip -- 1 σ 31,7 %, 2 σ 4,6 %, 3 σ 0,27 %",
           max(spiegel) < 1e-12 and abs(math.erfc(1 / math.sqrt(2.0)) - 0.3173) < 1e-4, f"größte Abweichung {max(spiegel):.1e}")
        abw_tag = max(abs(z_["p"][i_] - AU_r.erreichen_aus_lauf(Lr, x_, h_)[0]) for z_, x_ in zip(Rr["zeilen"], dr) for i_, h_ in ((2, 7), (3, 14)))
        abw_genau = max(abs(z_["p"][i_] - AU_r.erreichen(Sr, x_, h_)[0]) for z_, x_ in zip(Rr["zeilen"], dr) for i_, h_ in ((2, 7), (3, 14)))
        nur_hoch = rechner_bauen(dict(Gr, lauf=dict(Gr["lauf"], h={k_: {"hoch": v_["hoch"]} for k_, v_ in Lr.items()})), [Pr * math.exp(0.04), Pr * math.exp(-0.04)])
        ok("Kurs-Rechner, Abgleich Tage: 7 und 14 Tage sind genau hl_ausblick.erreichen_aus_lauf für den Abstand zum JETZIGEN Kurs (nicht zum "
           "Kurs der Rechnung) und weichen von der vollen Rechnung erreichen() höchstens 0,5 Punkte + 1/N ab; ein Kurs über dem jetzigen liest das "
           "laufende Hoch, einer darunter das Tief; 14 Tage nie unter 7 Tagen",
           abw_tag < 1e-12 and abw_genau <= 0.005 + 1.0 / Sr["n"] and all(z_["p"][3] >= z_["p"][2] for z_ in Rr["zeilen"])
           and nur_hoch["zeilen"][0]["p"][2] is not None and nur_hoch["zeilen"][1]["p"][2] is None and nur_hoch["zeilen"][1]["p_text"][2] == "—"
           and Gr["lauf"]["p0"] != Pr, f"gegen erreichen(): größte Abweichung {abw_genau:.4f}; +4 %: 7 T {Rr['zeilen'][6]['p_text'][2]}, 14 T {Rr['zeilen'][6]['p_text'][3]}")
        raster_r = [0.0004 * 1.13 ** i_ for i_ in range(56)]                      # 0,04 % … 33 % über und unter dem Kurs
        mono_r = []; frist_r = []
        for sg_ in (1, -1):
            alt_r = [1.0] * 4
            for i0_ in range(0, len(raster_r), RECHNER_MAX_KURSE):
                for z_ in rechner_bauen(Gr, [Pr * math.exp(sg_ * a_) for a_ in raster_r[i0_:i0_ + RECHNER_MAX_KURSE]])["zeilen"]:
                    mono_r.append(all(p_ is not None and 0.0 <= p_ <= a0_ + 1e-12 for p_, a0_ in zip(z_["p"], alt_r)))
                    frist_r.append(all(p_ is not None for p_ in z_["p"]) and all(z_["p"][i_] <= z_["p"][i_ + 1] + 1e-12 for i_ in range(3)))
                    alt_r = [p_ if p_ is not None else 0.0 for p_ in z_["p"]]
        ok("Kurs-Rechner, Eigenschaft über 112 Kurse (0,04 % bis 33 % über und unter dem Kurs): Mit wachsendem Abstand fällt die "
           "Wahrscheinlichkeit in jeder Frist oder bleibt gleich, mit längerer Frist steigt sie oder bleibt gleich; alle Werte zwischen 0 und 1",
           len(mono_r) == 112 and all(mono_r) and all(frist_r), f"{sum(mono_r)} von {len(mono_r)} fallend, {sum(frist_r)} von {len(frist_r)} steigend")
        Rj = rechner_bauen(Gr, [Pr, Pr * (1 + 1e-13), Pr * 1.0000001])["zeilen"]
        ok("Kurs-Rechner, jetziger Kurs: Er ist erreicht -- alle vier Fristen 100 %, als „erreicht“ geschrieben, ohne Abstand und ohne Vermerk; "
           "schon ein Zehnmillionstel daneben wird gerechnet (über 99 %)",
           Rj[0]["p"] == [1.0] * 4 and Rj[0]["p_text"] == ["erreicht"] * 4 and Rj[0]["lage"] == "der jetzige Kurs" and Rj[0]["abstand"] == 0.0
           and Rj[0]["abstand_text"] == "" and Rj[0]["hinweise"] == [] and Rj[0]["satz"] == "60.000 ist der jetzige Kurs." and Rj[1]["p"] == [1.0] * 4
           and Rj[2]["lage"] == "über dem Kurs" and Rj[2]["p_text"][:2] == ["über 99 %"] * 2 and Rj[2]["p"][0] < 1.0, f"{Rj[0]['p_text']} · daneben {Rj[2]['p_text']}")
        G_mono = dict(copy.deepcopy(Gr), sig4=0.2)                            # sehr unruhige Stunden gegen ruhige Tage: die Modelle widersprechen sich
        Rm = rechner_bauen(G_mono, [Pr * math.exp(0.05)])["zeilen"][0]
        Rm2 = rechner_bauen(dict(G_mono, sig4=0.4, kurz={"1h": Gr["kurz"]["1h"]}), [Pr * math.exp(0.05)])["zeilen"][0]
        roh7 = AU_r.erreichen_aus_lauf(Lr, 0.05, 7)[0]
        G_schwanz = dict(Gr, kurz={"1h": Gr["kurz"]["1h"], "4h": dict(Gr["kurz"]["4h"], tau=0.3)})      # wie HYPE auf dem Pi: τ 0,6 über 1 h, 0,3 über 4 h
        Rt = rechner_bauen(G_schwanz, [Pr * math.exp(0.12)])["zeilen"][0]
        roh4 = KK_r.p_ueber(math.log(Rt["px"] / Pr), 0.78, Gr["sig4"], 0.3)
        ok("Kurs-Rechner, längere Frist nie unwahrscheinlicher: Liefert das Modell der Tage weniger als das der Stunden, gilt der Wert der "
           "kürzeren Frist und der Kurs trägt den Vermerk dazu; fehlt eine Frist, zählt die nächste kürzere; ohne Widerspruch kein Vermerk; "
           "ändert die Berichtigung die gezeigte Zahl nicht (weit entfernter Kurs, beide „unter 1 %“), bleibt der Vermerk weg",
           Rm["p"][0] < Rm["p"][1] and Rm["p"][2] == Rm["p"][1] == Rm["p"][3] and roh7 < Rm["p"][1] - 0.05
           and Rm["hinweise"] == ["7 Tage und 14 Tage: " + RECHNER_NOTE_MONOTON + "."]
           and Rm2["p"][1] is None and Rm2["p"][2] == Rm2["p"][0] > roh7 and Rm2["hinweise"][0].startswith("7 Tage")
           and not any(RECHNER_NOTE_MONOTON in n_ for z_ in Rr["zeilen"] for n_ in z_["hinweise"])
           and roh4 < Rt["p"][0] and Rt["p"][1] == Rt["p"][0] and Rt["p_text"][:2] == ["unter 1 %"] * 2 and not any(RECHNER_NOTE_MONOTON in n_ for n_ in Rt["hinweise"]),
           f"Stunden {Rm['p_text'][:2]}, Tage roh {_rechner_p_text(roh7)} -> {Rm['p_text'][2:]}; weit weg: 4 h roh {roh4:.1e} -> {Rt['p'][1]:.1e}, ohne Vermerk")
        eng = {k_: {"hoch": [x_ * 0.01 for x_ in v_["hoch"]], "tief": [x_ * 0.01 for x_ in v_["tief"]]} for k_, v_ in Lr.items()}   # Tage fast ohne Bewegung
        Rl = rechner_bauen(dict(Gr, lauf=dict(Gr["lauf"], h=eng)), [Pr * math.exp(0.012)])["zeilen"][0]
        roh7_l = AU_r.erreichen_aus_lauf(eng, 0.012, 7)
        ok("Kurs-Rechner, längere Frist nie unwahrscheinlicher, Schranke: Kennt das Modell der Tage nur die Schranke „unter 0,5 %“, das der "
           "Stunden aber einen Wert darüber, dann steht bei den Tagen der Wert der Stunden als Zahl -- nicht „unter 1 %“ -- mit Vermerk",
           roh7_l == (AU_r.LAUF_Q[0], "unter") and Rl["p"][1] > 0.02 and Rl["p"][2] == Rl["p"][3] == Rl["p"][1]
           and Rl["p_text"][2] == Rl["p_text"][3] == Rl["p_text"][1] != "unter 1 %" and Rl["hinweise"] == ["7 Tage und 14 Tage: " + RECHNER_NOTE_MONOTON + "."],
           f"4 h {Rl['p_text'][1]}, Tage roh {roh7_l} -> {Rl['p_text'][2:]}")
        dk_p = {"7": {"d80": 0.674, "se": 0.039, "ok": False}, "14": {"d80": 0.660, "se": 0.045, "ok": False}}      # PAXG auf dem Pi (Debug 73, 11.11.)
        dk_b = {"7": {"d80": 0.840, "se": 0.017, "ok": False}, "14": {"d80": 0.846, "se": 0.020, "ok": True}}       # zu weit; 14 Tage hier in der Toleranz
        R_dp = rechner_bauen(dict(Gr, coin="PAXG", deckung=dk_p), [Pr * 0.97]); R_db = rechner_bauen(dict(Gr, deckung=dk_b), [Pr * 0.97])
        R_d0 = rechner_bauen(dict(Gr, deckung={}), [Pr * 0.97]); R_dl = rechner_bauen(dict(Gr, deckung=dk_p, lauf=None, lauf_fehlt="Grund L."), [Pr * 0.97])
        R_d7 = rechner_bauen(dict(Gr, deckung=dk_p, lauf=dict(Gr["lauf"], h={"7": Lr["7"]})), [Pr * 0.97])
        R_dn = rechner_bauen(dict(Gr, deckung={"7": {"d80": 0.70, "se": 0.06}, "14": {"d80": None, "se": 0.02, "ok": False}}), [Pr * 0.97])
        ok("Kurs-Rechner, Trefferquote des Bands je Coin: Liegt das 80-%-Band des Ausblicks für den Coin im Rückblick außerhalb von 80 % ± 2 "
           "Standardfehler (dieselbe Wertung wie an der Spanne), steht bei den Tagen ein Hinweis mit der Folge -- zu eng: die "
           "Wahrscheinlichkeiten können zu niedrig sein (PAXG auf dem Pi: 67 % und 66 %); zu weit: sie können zu hoch sein; nur für Fristen, "
           "die gerechnet sind; in der Toleranz, ohne Wertung oder ohne Rückblick kein Hinweis; die Zahlen selbst bleiben dieselben",
           R_dp["hinweise"] == ["7 Tage und 14 Tage: Für PAXG ist die Spanne des Ausblicks im Rückblick zu eng (das 80-%-Band traf 67 % und 66 %) -- "
                                "der Kurs verließ das Band öfter als erwartet, diese Wahrscheinlichkeiten können zu niedrig sein."]
           and R_db["hinweise"] == ["7 Tage: Für BTC ist die Spanne des Ausblicks im Rückblick zu weit (das 80-%-Band traf 84 %) -- der Kurs blieb "
                                    "öfter im Band als erwartet, diese Wahrscheinlichkeiten können zu hoch sein."]
           and R_d7["hinweise"][0].startswith("7 Tage: Für BTC ist die Spanne des Ausblicks im Rückblick zu eng (das 80-%-Band traf 67 %) -- ")
           and len(R_d7["hinweise"]) == 1 and R_d0["hinweise"] == [] and R_dl["hinweise"] == [] and R_dn["hinweise"] == [] and Rr["hinweise"] == []
           and R_dp["zeilen"][0]["p"] == R_d0["zeilen"][0]["p"] == R_db["zeilen"][0]["p"] and "   Kurs-Rechner Hinweis: " + R_dp["hinweise"][0] in rechner_text(R_dp),
           f"{R_dp['hinweise']} | {R_db['hinweise']}")
        s1h = Gr["sig4"] * 0.5; s4h = Gr["sig4"]
        Rg = rechner_bauen(Gr, [Pr * math.exp(3.0 * s1h - 1e-9), Pr * math.exp(3.0 * s1h + 1e-9), Pr * math.exp(-3.0 * s4h + 1e-9), Pr * math.exp(-3.0 * s4h - 1e-9),
                                Pr * 1.3, Pr * 1.3000001, Pr * 0.7, Pr * 0.6999999])["zeilen"]
        n_sig = RECHNER_NOTE_SIGMA.format(x="3"); n_abs = RECHNER_NOTE_ABSTAND.format(x=30)
        ok("Kurs-Rechner, Vermerk außerhalb des geprüften Bereichs: weiter als 3 übliche Schwankungen der Frist (Stunden, je Frist für sich) "
           "und weiter als 30 % (Tage) -- an der Grenze selbst noch ohne Vermerk; die Zahl steht trotzdem da",
           Rg[0]["hinweise"] == [] and Rg[1]["hinweise"] == [f"1 h: {n_sig}."] and Rg[2]["hinweise"] == [f"1 h: {n_sig}."]
           and Rg[3]["hinweise"] == [f"1 h und 4 h: {n_sig}."] and Rg[4]["hinweise"] == [f"1 h und 4 h: {n_sig}."]
           and Rg[5]["hinweise"] == [f"1 h und 4 h: {n_sig}.", f"7 Tage und 14 Tage: {n_abs}."] and Rg[6]["hinweise"] == [f"1 h und 4 h: {n_sig}."]
           and Rg[7]["hinweise"][1] == f"7 Tage und 14 Tage: {n_abs}." and all(p_ is not None for p_ in Rg[5]["p"])
           and rechner_bauen(dict(Gr, sigma_geprueft=2.5), [Pr * math.exp(2.6 * s4h)])["zeilen"][0]["hinweise"] == ["1 h und 4 h: " + RECHNER_NOTE_SIGMA.format(x="2,5") + "."],
           f"{Rg[5]['hinweise']}")
        pt = _rechner_p_text
        ok("Kurs-Rechner, Zahl als Text: ganze Prozent, kaufmännisch gerundet; unter 0,5 % „unter 1 %“, ab 99,5 % „über 99 %“ -- nie 0 % oder "
           "100 %; eine Schranke der Verteilung („unter“, „ueber“) wird als Schranke geschrieben; ohne Wert ein Strich",
           [pt(0.0049), pt(0.005), pt(0.0149), pt(0.015), pt(0.125), pt(0.5), pt(0.9949), pt(0.995), pt(1.0), pt(0.0), pt(1e-30)]
           == ["unter 1 %", "1 %", "1 %", "2 %", "13 %", "50 %", "99 %", "über 99 %", "über 99 %", "unter 1 %", "unter 1 %"]
           and [pt(0.005, "unter"), pt(0.995, "ueber"), pt(0.3, "fehlt"), pt(None), pt(float("nan")), pt("x")] == ["unter 1 %", "über 99 %", "—", "—", "—", "—"],
           f"{pt(0.0049)} · {pt(0.125)} · {pt(0.995)}")
        z5 = Rr["zeilen"][1]; z04 = Rr["zeilen"][4]
        abst_t = [z_["abstand_text"] for z_ in rechner_bauen(Gr, [Pr * 0.99, Pr * 1.01, Pr * (1 - 0.00994), Pr * (1 + 0.00997), Pr * 1.0004, Pr * 1.25])["zeilen"]]
        ok("Kurs-Rechner, Zeile: Kurs im deutschen Format, Abstand ohne Vorzeichen mit „über“ oder „unter dem Kurs“ (unter 1 % mit zwei "
           "Nachkommastellen -- „0,99 %“, dann „1,0 %“, nie „1,00 %“), Satz mit allen vier Fristen; die Antwort ist gültiges JSON ohne NaN",
           z5["px_text"] == _px(Pr * math.exp(-0.05)) and z5["abstand_text"] == "4,9 %" and z5["lage"] == "unter dem Kurs" and abs(z5["abstand"] - (math.exp(-0.05) - 1)) < 1e-12
           and z04["abstand_text"] == "0,40 %" and z04["lage"] == "über dem Kurs"
           and abst_t == ["1,0 %", "1,0 %", "0,99 %", "1,0 %", "0,04 %", "25,0 %"]
           and z5["satz"] == (f"{z5['px_text']} liegt 4,9 % unter dem Kurs. Wahrscheinlichkeit, dass der Kurs berührt wird: in 1 Stunde {z5['p_text'][0]}, "
                              f"in 4 Stunden {z5['p_text'][1]}, in 7 Tagen {z5['p_text'][2]}, in 14 Tagen {z5['p_text'][3]}.")
           and Rr["fristen"] == [["1h", "1 Stunde", "1 h", True], ["4h", "4 Stunden", "4 h", True], ["7d", "7 Tage", "7 Tage", True], ["14d", "14 Tage", "14 Tage", True]]
           and Rr["kurs"] == Pr and Rr["coin"] == "BTC" and Rr["fehlt"] == [] and Rr["hinweise"] == []
           and json.loads(json.dumps(_ohne_nan(Rr), allow_nan=False)) == _ohne_nan(Rr), z5["satz"])
        Re = rechner_bauen(Gr, [0, -5, None, "abc", float("nan"), Pr / 5.0000001, Pr * 5.0000001, Pr / 5, Pr * 5, Pr, Pr])
        ok("Kurs-Rechner, Grenzen der Eingabe: null, negativ, leer, Text und NaN sind kein gültiger Kurs; gerechnet wird nur zwischen einem "
           "Fünftel und dem Fünffachen des jetzigen Kurses (die Grenzen selbst zählen dazu); höchstens 8 Kurse je Anfrage, der Rest mit Hinweis",
           [z_["grund"] for z_ in Re["zeilen"][:5]] == ["Kein gültiger Kurs."] * 5 and all(not z_["ok"] and z_["p"] == [None] * 4 for z_ in Re["zeilen"][:7])
           and Re["zeilen"][5]["grund"] == Re["zeilen"][6]["grund"] == "Außerhalb des Bereichs des Rechners (12.000 bis 300.000)."
           and Re["zeilen"][7]["ok"] and len(Re["zeilen"]) == 8 and Re["hinweise"] == ["Gerechnet sind die ersten 8 von 11 Kursen der Anfrage."]
           and rechner_bauen(Gr, [Pr * 5])["zeilen"][0]["ok"] and rechner_bauen(Gr, [])["zeilen"] == [] and rechner_bauen(Gr, None)["hinweise"] == [],
           f"{Re['zeilen'][5]['grund']} | {Re['hinweise']}")
        R_alt = rechner_bauen(dict(Gr, kurs_frisch=False), [Pr * 0.9]); R_ohne = rechner_bauen(dict(Gr, kurs=None, kurs_ts=None, kurs_frisch=False), [Pr * 0.9])
        R_o4 = rechner_bauen(dict(Gr, kurz={"1h": Gr["kurz"]["1h"]}, kurz_fehlt={"4h": "Für das Nullmodell über 4 Stunden hat der Magnet-Test zu wenige Blöcke (72)."}), [Pr * 0.99])
        R_os = rechner_bauen(dict(Gr, sig4=None, sig4_fehlt="Für die Schwankung über 4 Stunden fehlen Minutenkerzen."), [Pr * 0.99])
        R_ol = rechner_bauen(dict(Gr, lauf=None, lauf_fehlt="Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."), [Pr * 0.99])
        R_o14 = rechner_bauen(dict(Gr, lauf=dict(Gr["lauf"], h={"7": Lr["7"]})), [Pr * 0.99])
        R_nix = rechner_bauen(dict(Gr, kurz={}, kurz_fehlt={"1h": "Der Prognosespeicher fehlt noch.", "4h": "Der Prognosespeicher fehlt noch."}, lauf=None, lauf_fehlt="Grund L."), [Pr * 0.99])
        ok("Kurs-Rechner, ohne Quelle kein Wert: ohne frischen Kurs rechnet nichts (der Rechner rechnet nur vom jetzigen Kurs); fehlt das "
           "Nullmodell einer Frist, die Schwankung über 4 Stunden oder die Verteilung der Tage, bleiben genau diese Fristen leer und der Grund "
           "steht da -- die anderen rechnen weiter; nichts wird geschätzt",
           R_alt["zeilen"][0]["ok"] is False and R_alt["zeilen"][0]["grund"] == "Kein frischer Kurs." and R_alt["fristen"][0][3] is False
           and R_alt["fehlt"] == [f"Der Kurs ist nicht frisch (Stand {_datum(jetzt - 30)}) -- der Rechner rechnet nur vom jetzigen Kurs."] and R_alt["belege"] == []
           and R_ohne["fehlt"] == ["Kein Kurs für BTC -- der Rechner rechnet nur vom jetzigen Kurs."]
           and R_o4["zeilen"][0]["p"][1] is None and R_o4["zeilen"][0]["p"][0] is not None and R_o4["zeilen"][0]["p_text"][1] == "—"
           and [f_[3] for f_ in R_o4["fristen"]] == [True, False, True, True] and R_o4["fehlt"] == ["4 Stunden: Für das Nullmodell über 4 Stunden hat der Magnet-Test zu wenige Blöcke (72)."]
           and "in 4 Stunden" not in R_o4["zeilen"][0]["satz"] and R_o4["belege"][0].startswith("1 Stunde: Nullmodell")
           and [f_[3] for f_ in R_os["fristen"]] == [False, False, True, True] and R_os["fehlt"] == ["1 Stunde und 4 Stunden: Für die Schwankung über 4 Stunden fehlen Minutenkerzen."]
           and len(R_os["belege"]) == 1 and R_os["belege"][0].startswith("7 Tage und 14 Tage:")
           and [f_[3] for f_ in R_ol["fristen"]] == [True, True, False, False] and R_ol["fehlt"] == ["7 Tage und 14 Tage: Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."]
           and [f_[3] for f_ in R_o14["fristen"]] == [True, True, True, False] and R_o14["fehlt"] == ["14 Tage: kein Wert."] and R_o14["belege"][1].startswith("7 Tage: Verteilung")
           and R_nix["zeilen"][0]["ok"] and R_nix["zeilen"][0]["p"] == [None] * 4 and R_nix["zeilen"][0]["satz"].endswith("unter dem Kurs. Keine Frist ist rechenbar.")
           and R_nix["fehlt"] == ["1 Stunde und 4 Stunden: Der Prognosespeicher fehlt noch.", "7 Tage und 14 Tage: Grund L."] and R_nix["belege"] == []
           and R_nix["beleg_kurz"] == RECHNER_BELEG_SCHLUSS, f"{R_o4['fehlt']} | {R_nix['fehlt']}")
        G_u = copy.deepcopy(Gr); G_u["kurz"]["1h"]["zufall_ok"] = 5; G_u["kurz"]["4h"]["zufall_n"] = 0; G_u["kurz"]["4h"]["zufall_ok"] = 0
        R_u = rechner_bauen(G_u, [Pr * 0.99]); R_s0 = rechner_bauen(dict(Gr, s3={}), [Pr * 0.99])
        R_s1 = rechner_bauen(dict(Gr, s3={"7": {"skill": -0.01, "steigung": 0.7, "besteht": False}}), [Pr * 0.99])
        ok("Kurs-Rechner, Belege: die Stunden nennen die Schwankung über 4 Stunden, die Probe an Zufallsniveaus je Frist und das Alter der "
           "Rechnung; die Tage den Stand der Rechnung des Ausblicks und die Prüfung S3 mit Skill, Steigung und Urteil; dazu die Kurzfassung. "
           "Liegt mehr als einer der Zufallsabstände außerhalb von 2 Standardfehlern, heißt das Nullmodell „ungenauer“ (7 von 8: kein Hinweis); "
           "fehlt die Probe oder der Rückblick, steht das da",
           Rr["belege"] == ["1 Stunde und 4 Stunden: Nullmodell des Magnet-Tests (U110) mit der Schwankung der letzten 7 Tage (über 4 Stunden 1,20 %). An "
                            "Zufallsniveaus geprüft -- innerhalb von 2 Standardfehlern lagen über 1 h 8 von 8, über 4 h 7 von 8 Abständen (65 Tage, "
                            f"Rechnung vom {_datum(jetzt - 3 * 3600)}).",
                            f"7 Tage und 14 Tage: Verteilung aus der Rechnung des Ausblicks vom {_datum(jetzt - 1800)}, angelegt am jetzigen Kurs. Im "
                            "Rückblick über alle Coins zusammen geprüft (S3): über 7 Tage Brier-Skill +6,3 %, Steigung 0,96 (besteht); über 14 Tage Brier-Skill +3,7 %, Steigung 0,92 (besteht)."]
           and Rr["beleg_kurz"] == ("Stunden: Nullmodell an Zufallsniveaus geprüft (1 h 8 von 8, 4 h 7 von 8 innerhalb von 2 Standardfehlern). Tage: im "
                                    "Rückblick über alle Coins geprüft (7 Tage besteht, 14 Tage besteht). " + RECHNER_BELEG_SCHLUSS)
           and Rr["beleg_allg"] == RECHNER_BELEG_ALLG + " Geprüft sind Abstände bis 3 übliche Schwankungen der Frist (σ, bei den Stunden) und bis 30 % (bei den Tagen)."
           and R_u["hinweise"] == ["Über 1 Stunde ist das Nullmodell für BTC ungenauer: nur 5 von 8 Abständen innerhalb von 2 Standardfehlern.",
                                   "Über 4 Stunden fehlt für BTC die Probe des Nullmodells an Zufallsniveaus."]
           and "lagen über 1 h 5 von 8 Abständen" in R_u["belege"][0] and "Stunden: Nullmodell an Zufallsniveaus geprüft (1 h 5 von 8 innerhalb" in R_u["beleg_kurz"]
           and R_s0["belege"][1].endswith("Der Rückblick des Ausblicks steht noch aus -- diese Wahrscheinlichkeiten sind noch nicht geprüft.")
           and "Tage: noch nicht geprüft (der Rückblick steht aus)." in R_s0["beleg_kurz"]
           and R_s1["belege"][1].endswith("Im Rückblick über alle Coins zusammen geprüft (S3): über 7 Tage Brier-Skill −1,0 %, Steigung 0,70 (besteht nicht).")
           and "(7 Tage besteht nicht)." in R_s1["beleg_kurz"], Rr["beleg_kurz"])
        ok("Kurs-Rechner, Anfrage lesen: Zahlen mit Punkt, getrennt mit Komma oder Semikolon; Leeres zählt nicht, Unlesbares und Unendliches "
           "wird gezählt und nicht gerechnet",
           rechner_kurse("61500,58000.5") == ([61500.0, 58000.5], 0) and rechner_kurse(" 1e3 ; 2 ,, abc, inf, nan, -4 ") == ([1000.0, 2.0, -4.0], 3)
           and rechner_kurse("") == ([], 0) and rechner_kurse(None) == ([], 0) and rechner_kurse("61.500,5") == ([61.5, 5.0], 0), f"{rechner_kurse(' 1e3 ; 2 ,, abc, inf, nan, -4 ')}")
        tr = rechner_text(Rr)
        ok("Kurs-Rechner, Text für Debug 143: Kopf mit dem jetzigen Kurs und den vier Spalten, je Kurs Abstand mit Vorzeichen und die vier "
           "Zahlen, Vermerke in Klammern, dann Gründe, Hinweise und Belege des Coins; eine Absage und eine Antwort ohne Kurs geben den Grund",
           tr[0] == "   Kurs-Rechner (vom jetzigen Kurs 60.000 aus; Wahrscheinlichkeit, berührt zu werden; Spalten: 1 h · 4 h · 7 Tage · 14 Tage):"
           and len(tr) == 1 + 8 + 2 and tr[1].startswith(f"   Kurs-Rechner {_px(Pr * math.exp(-0.12)):>10}   −11,3 %  ") and tr[1].endswith(f"(1 h und 4 h: {n_sig}.)")
           and tr[5] == f"   Kurs-Rechner {_px(Pr * math.exp(0.004)):>10}   +0,40 %  " + " · ".join(f"{t_:>9}" for t_ in Rr["zeilen"][4]["p_text"])
           and tr[-2] == "   Kurs-Rechner Beleg: " + Rr["belege"][0] and tr[-1] == "   Kurs-Rechner Beleg: " + Rr["belege"][1]
           and rechner_text(R_u)[-4:-2] == ["   Kurs-Rechner Hinweis: " + h_ for h_ in R_u["hinweise"]]
           and rechner_text(R_alt) == [f"   Kurs-Rechner {_px(Pr * 0.9)}: Kein frischer Kurs.", "   Kurs-Rechner fehlt: " + R_alt["fehlt"][0]]
           and rechner_text(rechner_bauen(Gr, [Pr]))[1].startswith("   Kurs-Rechner     60.000 jetziger Kurs   erreicht ·")
           and rechner_text({"ok": False, "fehlt": ["DOGE: kein Kurs-Rechner"]}) == ["   Kurs-Rechner: kein Wert -- DOGE: kein Kurs-Rechner"]
           and rechner_text(None) == ["   Kurs-Rechner: kein Wert -- Grund unbekannt"]
           and rechner_text(rechner_bauen(dict(Gr, s3={}), []))[0].startswith("   Kurs-Rechner Beleg: 1 Stunde und 4 Stunden"), tr[1])
        rk = rechner_kopf()
        ok("Kurs-Rechner, feste Angaben für die Karte: vier Fristen, vier Namen zum Merken (Liquidation zuerst), höchstens 6 gemerkte Kurse je "
           "Coin und 8 je Anfrage, Bereich Faktor 5; die Antwort von /cockpit trägt sie",
           rk["fristen"] == [["1h", "1 Stunde", "1 h"], ["4h", "4 Stunden", "4 h"], ["7d", "7 Tage", "7 Tage"], ["14d", "14 Tage", "14 Tage"]]
           and rk["arten"] == [["liq", "Liquidation"], ["stopp", "Stopp"], ["limit", "Limit"], ["marke", "Marke"]] and rk["merken"] == 6 and rk["max"] == 8
           and rk["faktor"] == 5.0 and rk["beleg"] == RECHNER_BELEG_KOPF and "in diesem Browser" in rk["merk_hinweis"] and "nicht gespeichert" in rk["merk_hinweis"]
           and d["rechner"] == rk and RECHNER_MERKEN + 1 <= RECHNER_MAX_KURSE, f"{rk['arten']}")

    except Exception as e_r:                            # eine Ausnahme ist ein Fehler der Probe, kein Abbruch des Selbsttests
        ok("Kurs-Rechner: die Proben der Rechnung laufen ohne Ausnahme durch", False, f"{type(e_r).__name__}: {e_r}")
    # ---- 4f) Rest von Stufe C2 (23.108): Funding (Hyperliquid), Taker-Varianz, Liquidationsdichte, Betrieb
    try:
        c2_alle = _c2_proben(ok, jetzt)
    except Exception as e_c:                            # eine Ausnahme ist ein Fehler der Probe, kein Abbruch des Selbsttests
        import traceback
        c2_alle = []
        ok("Rest von Stufe C2: die Proben laufen ohne Ausnahme durch", False, f"{type(e_c).__name__}: {e_c} | {traceback.format_exc().splitlines()[-3].strip()}")
    # ---- 4g) Durchschnittslinien (23.110, U269)
    try:
        li_alle = _linien_proben(ok, jetzt)
    except Exception as e_l:                            # eine Ausnahme ist ein Fehler der Probe, kein Abbruch des Selbsttests
        import traceback
        li_alle = []
        ok("Durchschnittslinien: die Proben laufen ohne Ausnahme durch", False, f"{type(e_l).__name__}: {e_l} | {traceback.format_exc().splitlines()[-3].strip()}")
    # ---- 5) Wortprobe
    alle = json.dumps([c2_alle, li_alle, Rr, R_u, R_alt, R_ohne, R_nix, Rm, Rg, Re["zeilen"], rk, tr, vb, vb_k, vb_b, vb_w, vb_ohne, vb_ku, vb_eig, tv, un, un_ohne, un_g, un_fehlt, pr0, pr_nb, pr_b, pr_w, pr_k, pr_alt, d_eth, bauen(copy.deepcopy(Q)), ak_a, d3, leer, t_jetzt, h300, sa, ak, s95, d_alt, t_ohne, t_einer, ak_grau, ak_unbek,
                       ak_fremd, p_kerze, p_wenig, p_takt, p_basis, p_keine, p_nie], ensure_ascii=False).lower()
    treffer = [w for w in WORT_VERBOTEN if w in alle]
    pfeile = [z for z in "↑↓▲▼⬆⬇➚➘" if z in alle]
    ok("Wortprobe: keine Empfehlungswörter und kein Pfeil in den Texten des Cockpits", not treffer and not pfeile, f"gefunden: {treffer + pfeile or 'nichts'}")

    # ---- 5b) Seite ordnen (Kleinbild der Hauptseite)
    mini = ('<html><head><style>x</style></head><body>\n<div class="top"><nav class="nav">\n  <a href="#sec-chart">Chart</a><a href="#sec-signal">Konfluenz</a>'
            '<a href="#sec-system" class="dim">System</a>\n  <a class="dim" onclick="toggleAll()">alle</a>\n </nav></div>\n<div class="kpi" id="kpi"></div>\n'
            + "".join(f'<div class="panel" id="sec-{k}" data-sec="{k}">\n <h2>{k}</h2><div class="body">Inhalt {k}</div>\n</div>\n\n'
                      for k in ("chart", "signal", "neu", "labor", "network", "system"))
            + '<div id="taskbar"></div>\n<script>function applySec(){}</script>\n</body></html>')
    geo = seite_ordnen(mini)
    folge = [m_ for m_ in __import__("re").findall(r'id="(sec-\w+|grp-\w+|kpi)"', geo)]
    ok("Seite ordnen: Cockpit zuerst, Unbekanntes bleibt in der Hauptansicht, Werkstatt mit Kennzahlenleiste, Betrieb am Ende; jeder "
       "Abschnitt genau einmal; zweimal angewendet = einmal",
       folge == ["sec-cockpit", "sec-chart", "sec-neu", "grp-werkstatt", "kpi", "sec-signal", "sec-labor", "grp-betrieb", "sec-network", "sec-system"]
       and seite_ordnen(geo) == geo and all(geo.count(f'Inhalt {k}') == 1 for k in ("chart", "signal", "neu", "labor", "network", "system"))
       and len(__import__("re").findall(r"<div\b", geo)) == geo.count("</div>"), " > ".join(folge))
    nav_g = geo[geo.index('<nav class="nav">'):geo.index("</nav>")]
    ok("Seite ordnen: Navigationsleiste mit Cockpit, Hauptabschnitten, Werkstatt und Betrieb in dieser Reihenfolge; Namen der bisherigen "
       "Leiste; Erstlauf-Skript vor dem Hauptskript, Gruppen-Skript und /cockpit.js am Ende",
       __import__("re").findall(r'href="#(\w+-\w+)"', nav_g) == ["sec-cockpit", "sec-chart", "sec-neu", "grp-werkstatt", "sec-signal", "sec-labor", "grp-betrieb",
                                                               "sec-network", "sec-system"]
       and ">Konfluenz</a>" in nav_g and ">Netzwerk</a>" in nav_g and "toggleAll()" in nav_g
       and geo.index("hl_cockpit_v1") < geo.index("function applySec") < geo.index("function grpSchalten") < geo.index('<script src="/cockpit.js">')
       and '["chart", "labor", "network", "neu", "signal", "system"]' in geo, __import__("re").findall(r'href="#(\w+-\w+)"', nav_g))
    fehler = []
    for name, kaputt in (("Abschnitt doppelt", mini.replace('id="sec-neu" data-sec="neu"', 'id="sec-chart" data-sec="chart"')),
                         ("Abschnitt nicht geschlossen", mini.replace("Inhalt labor</div>\n</div>", "Inhalt labor</div>")),
                         ("Kennzahlenleiste fehlt", mini.replace('<div class="kpi" id="kpi"></div>\n', "")),
                         ("Navigationsleiste fehlt", mini.replace('<nav class="nav">', '<nav>'))):
        try:
            seite_ordnen(kaputt); fehler.append(name)
        except ValueError:
            pass
    ok("Seite ordnen: doppelter oder nicht geschlossener Abschnitt, fehlende Kennzahlenleiste oder Navigationsleiste -> ValueError (hl_viz "
       "liefert dann die ungeordnete Seite)", not fehler, f"ohne Fehler durchgelaufen: {fehler or 'keiner'}")

    # ---- 6) Vertrag mit den Modulen: echte Formen (Demo-Datenbanken der Module, ohne Netz)
    try:
        _vertrag(ok)
    except Exception as e:
        import traceback
        ok("Vertrag mit den Modulen ohne Ausnahme", False, f"{type(e).__name__}: {e} | {traceback.format_exc().splitlines()[-3].strip()}")

    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    if verbose:
        print("Cockpit -- Selbsttest (KONZEPT_Cockpit.md 6: Abgleich, Frische, Wortprobe, Schwellen der Lampen, Vertrag mit den Modulen; "
              "seit 23.108 Funding, Taker-Varianz, Liquidationsdichte, Betrieb)")
        for name, gut, wert in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name}" + (f"  {wert[:230]}" if wert else ""))
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(1 for p_ in pruef if p_[1])} von {len(pruef)})")
    return alles


def _linien_proben(ok, jetzt: int) -> list:
    """Proben zur Karte „Durchschnittslinien“ (23.110, U269) auf Quellen von Hand -- reine Funktionen; die echten Formen der Module prüft
    _vertrag. Gibt die gebauten Teile für die Wortprobe zurück."""
    import copy
    Q = _probe_quellen(jetzt)
    d = bauen(copy.deepcopy(Q)); Ln = d["linien"]; z50, z200 = Ln["zeilen"]
    L = Q["linien"]; P = Q["ausblick"]["prognose"]; nv = Q["niveaus_urteil"]
    ok("Durchschnittslinien, Abgleich: Wert nach Tagesschluss gleich der Quelle (61.300, 58.000); Wert wie im Live-Chart von Hand: "
       "(3.002.300 + 60.200) ÷ 50 = 61.250 und (11.543.800 + 60.200) ÷ 200 = 58.020 -- er steht groß, der andere daneben; Abstand = "
       "jetziger Kurs ÷ großer Wert − 1 (60.200 ÷ 61.250 − 1 = −1,71 %; 60.200 ÷ 58.020 − 1 = +3,76 %), Richtung, Lage der Linien "
       "zueinander mit Datum, Stand und Quelle",
       Ln["ok"] is True and [z["key"] for z in Ln["zeilen"]] == ["ma50", "ma200"] and z50["px"] == 61_300.0 and z200["px"] == 58_000.0
       and z50["px_text"] == "61.300" and z200["px_text"] == "58.000" and z50["px_live"] == 61_250.0 and z200["px_live"] == 58_020.0
       and (z50["haupt_text"], z50["neben"]) == ("61.250", "nach Tagesschluss 61.300")
       and (z200["haupt_text"], z200["neben"]) == ("58.020", "nach Tagesschluss 58.000")
       and abs(z50["abstand"] - (-1050.0 / 61250.0)) < 1e-12 and abs(z200["abstand"] - (2180.0 / 58020.0)) < 1e-12
       and z50["lage"] == "Kurs 1,7 % darunter" and z200["lage"] == "Kurs 3,8 % darüber"
       and z50["richtung"] == "Linie fällt seit 12 Tagen" and z200["richtung"] == "Linie steigt seit 140 Tagen"
       and Ln["lage"] == "Nach dem letzten Tagesschluss liegt die 50-Tage-Linie über der 200-Tage-Linie, seit dem 03.05.2026."
       and Ln["stand"] == "Tagesschlüsse bis 10.11.2026 (UTC), Quelle binance" and Ln["stand_tag"] == jetzt // TAG - 1
       and Ln["hinweise"] == [] and Ln["fehlt"] == [],
       f"{z50['haupt_text']} ({z50['neben']}) {z50['lage']} · {z200['haupt_text']} ({z200['neben']}) {z200['lage']} | {Ln['lage']}")
    lv200 = next((n for n in d["levels"]["unten"] if n["name"] == "200-Tage-Linie"), {})
    ok("Durchschnittslinien, Erreich-Wahrscheinlichkeit: dieselben Zahlen wie in „Levels“ und in der Rechnung des Ausblicks (200-Tage-Linie "
       "61 % · 72 %); die 50-Tage-Linie führt der Ausblick nicht als Niveau -- keine Zahl, mit Grund",
       z200["p7"] == 0.61 and z200["p14"] == 0.72 and (z200["p7"], z200["p14"]) == (lv200.get("p7"), lv200.get("p14")) and z200["p_grund"] == ""
       and z200["p_hinweis"] == "gilt für den Stand nach Tagesschluss" and z50["p7"] is None and z50["p14"] is None
       and z50["p_grund"] == "nicht unter den Niveaus des Ausblicks (er führt nur Niveaus innerhalb seiner 98-%-Spanne für 4 Wochen)"
       and z200["p_text"] == "Erreich-Wahrscheinlichkeit: 1 Woche 61 % · 2 Wochen 72 % (gilt für den Stand nach Tagesschluss)"
       and z50["p_text"] == "Ohne Erreich-Wahrscheinlichkeit: " + z50["p_grund"],
       f"200: {z200['p7']} · {z200['p14']}; 50: {z50['p_grund']}")

    def lb(kurs=60_200.0, frisch=True, P_=P, L_=L):
        return linien_bauen(copy.deepcopy(L_), kurs, copy.deepcopy(P_), frisch, nv, Q["trend_beleg"])

    def mit(px=None, **felder):                                          # Rechnung des Ausblicks mit geändertem Niveau „200-Tage-Linie“
        P2 = copy.deepcopy(P)
        for n in P2["niveaus"]:
            if n.get("art") == "ma200":
                n.update(felder)
                if px is not None:
                    n["px"] = px
        return P2
    alt = lb(frisch=False)["zeilen"][1]
    err = lb(P_=mit(erreicht=True, p={}))["zeilen"][1]                   # so meldet der Ausblick ein erreichtes Niveau: ohne Zahlen
    err2 = lb(P_=mit(erreicht=True))["zeilen"][1]; err3 = lb(P_=mit(p={}))["zeilen"][1]
    durch = lb(kurs=57_900.0)["zeilen"][1]                              # am Anker (60.000) lag der Kurs über dem Niveau, jetzt darunter
    gleich = lb(kurs=58_000.0)["zeilen"][1]
    knapp = lb(kurs=58_000.01)["zeilen"][1]
    anders = lb(P_=mit(px=57_940.0))["zeilen"][1]
    keine = lb(P_={})["zeilen"][1]; keine2 = lb(P_=None)["zeilen"][1]
    ohne_niv = lb(P_=dict(P, niveaus=[]))["zeilen"][1]                   # Rechnung da, aber ohne Niveaus
    okurs = lb(kurs=None)["zeilen"]
    ok("Durchschnittslinien, Grenzen der Erreich-Wahrscheinlichkeit: Rechnung älter als 2 Tage -> keine Zahl; vom Ausblick als erreicht "
       "gemeldet -> keine; seit der Rechnung durchlaufen (am Anker 60.000 darüber, jetzt 57.900 darunter) oder Kurs genau auf dem Niveau "
       "-> keine, einen Cent darüber -> Zahl; rechnete der Ausblick mit 57.940 statt 58.000, steht die Zahl mit diesem Stand; ohne "
       "Rechnung und ohne Niveaus je der eigene Grund; ohne frischen Kurs bleibt die Zahl (sie gilt ab dem Anker)",
       alt["p7"] is None and alt["p14"] is None and alt["p_grund"] == "die Rechnung des Ausblicks ist älter als 2 Tage"
       and err["p7"] is None and err["p_grund"] == "seit der Rechnung des Ausblicks erreicht" == err2["p_grund"] == err3["p_grund"]
       and err2["p7"] is None and err3["p7"] is None
       and durch["p7"] is None and durch["p_grund"] == "seit der Rechnung des Ausblicks durchlaufen" and durch["lage"] == "Kurs 0,2 % darunter"
       and gleich["p7"] is None and gleich["p_grund"] == "seit der Rechnung des Ausblicks durchlaufen" and gleich["lage"] == "Kurs auf der Linie"
       and knapp["p7"] == 0.61 and knapp["p_grund"] == ""
       and anders["p7"] == 0.61 and anders["p14"] == 0.72 and anders["px"] == 58_000.0 and anders["p_grund"] == ""
       and anders["p_hinweis"] == "gerechnet für 57.940, den Stand der Linie bei der Rechnung des Ausblicks"
       and anders["p_text"] == "Erreich-Wahrscheinlichkeit: 1 Woche 61 % · 2 Wochen 72 % (gerechnet für 57.940, den Stand der Linie bei der Rechnung des Ausblicks)"
       and alt["p_text"] == "Ohne Erreich-Wahrscheinlichkeit: die Rechnung des Ausblicks ist älter als 2 Tage"
       and keine["p_grund"] == "keine Rechnung des Ausblicks" == keine2["p_grund"] and keine["p7"] is None
       and ohne_niv["p_grund"].startswith("nicht unter den Niveaus des Ausblicks") and ohne_niv["p7"] is None
       and okurs[1]["p7"] == 0.61 and okurs[1]["abstand"] is None and okurs[1]["lage"] == "Abstand zum Kurs: kein frischer Kurs" == okurs[0]["lage"]
       and okurs[1]["p_hinweis"] == "" and okurs[1]["p_text"] == "Erreich-Wahrscheinlichkeit: 1 Woche 61 % · 2 Wochen 72 %",
       f"alt: {alt['p_grund']} | durchlaufen: {durch['p_grund']} | anders: {anders['p_hinweis']}")
    L10 = dict(L, ma50=10_000.0, ma200=10_000.0, ma50_rest=None, ma200_rest=None)      # ohne Summe der Vortage: Abstand zum Wert nach Tagesschluss
    g = {k_: linien_bauen(dict(L10), k_, None, False)["zeilen"][0]["lage"] for k_ in (10_004.9, 10_005.1, 9_994.9, 9_995.1, 10_000.0)}
    ok("Durchschnittslinien, Abstand: unter 0,05 % (gerundet 0,0 %) heißt es „Kurs auf der Linie“, ab da steht die Zahl mit „darüber“ oder "
       "„darunter“ -- ohne Vorzeichen und ohne Pfeil",
       g[10_004.9] == "Kurs auf der Linie" == g[9_995.1] == g[10_000.0] and g[10_005.1] == "Kurs 0,1 % darüber" and g[9_994.9] == "Kurs 0,1 % darunter",
       f"{g}")
    kurz_ = linien_bauen(dict(L, ma200=None, ma200_rest=None, ma200_richtung=None, ma200_seit=None, n_tage=150, lage=None, kreuz_tag=None),
                         60_200.0, P, True)
    kein = linien_bauen({"fehlt": ["Tageskerzen zuletzt am 05.11.2026 -- Trend, Bein und Swings ausgeblendet"]}, 60_200.0, P, True)
    nix = linien_bauen(None, 60_200.0, P, True)
    ok("Durchschnittslinien ohne Daten: Mit 150 Tagen steht die 50-Tage-Linie, die 200-Tage-Linie nennt „fehlen noch Tage (150 von 200)“ "
       "und der Satz zur Lage entfällt; zeigt das Chartbild keinen Trend (Tageskerzen zu alt), steht sein Grund statt einer Zahl; ohne "
       "Quelle „Keine Tageskerzen.“",
       kurz_["ok"] is True and kurz_["zeilen"][0]["px"] == 61_300.0 and kurz_["zeilen"][1]["px"] is None and kurz_["zeilen"][1]["px_text"] == "—"
       and kurz_["zeilen"][1]["fehlt"] == "Für die 200-Tage-Linie fehlen noch Tage (150 von 200)." and kurz_["zeilen"][1]["p7"] is None
       and kurz_["zeilen"][1]["lage"] == "" and kurz_["lage"] == "" and kurz_["zeilen"][0]["fehlt"] == "" and kurz_["zeilen"][1]["p_text"] == ""
       and kurz_["zeilen"][1]["haupt_text"] == "—" and kurz_["zeilen"][1]["neben"] == "" and kurz_["zeilen"][0]["haupt_text"] == "61.250"
       and kein["ok"] is False and kein["zeilen"] == [] and kein["fehlt"] == ["Tageskerzen zuletzt am 05.11.2026 -- Trend, Bein und Swings ausgeblendet"]
       and nix["ok"] is False and nix["fehlt"] == ["Keine Tageskerzen."] and bool(kein["beleg"]) and bool(nix["beleg"]),
       f"{kurz_['zeilen'][1]['fehlt']} | {kein['fehlt']} | {nix['fehlt']}")
    h1 = linien_bauen(dict(L, alter_tage=1), 60_200.0, P, True)
    h2 = linien_bauen(dict(L, alter_tage=2, gefuellt=1), 60_200.0, P, True)
    h3 = linien_bauen(dict(L, gefuellt=3), 60_200.0, P, True)
    r1 = linien_bauen(dict(L, ma50_seit=1, ma200_seit=1, ma200_richtung=None), 60_200.0, P, True)["zeilen"]
    ok("Durchschnittslinien, Hinweise: fehlt der jüngste Tagesschluss, steht der Rückstand in Tagen (Einzahl und Mehrzahl); Tage ohne Kerze "
       "unter den letzten 200 werden genannt (dort gilt der Schluss des Vortags); Richtung in der Einzahl „seit 1 Tag“, ohne Richtung "
       "(letzter Wert gleich dem davor) nur der Abstand",
       h1["hinweise"] == ["Der jüngste Tagesschluss fehlt noch (1 Tag Rückstand; die Tageskerzen lädt hl_binance alle 6 Stunden)."]
       and h2["hinweise"] == ["Der jüngste Tagesschluss fehlt noch (2 Tage Rückstand; die Tageskerzen lädt hl_binance alle 6 Stunden).",
                              "Unter den letzten 200 Tagen ist 1 ohne Tageskerze -- dort gilt der Schluss des Vortags."]
       and h3["hinweise"] == ["Unter den letzten 200 Tagen sind 3 ohne Tageskerze -- dort gilt der Schluss des Vortags."] and h1["ok"] is True
       and r1[0]["richtung"] == "Linie fällt seit 1 Tag" and r1[1]["richtung"] == "" and r1[1]["lage"] == "Kurs 3,8 % darüber",
       f"{h1['hinweise']} {h3['hinweise']}")
    nan = float("nan")
    r = [_richtung(x) for x in ([1, 2, 3], [3, 2, 1, 0.5], [1, 2, 2], [nan, 1, 2], [1, nan, 2, 3], [5], [], None, [2, 1, 3], [1, 3, 2], [1, 2, nan])]
    ok("Richtung einer Linie: Vorzeichen der jüngsten Änderung und seit wie vielen Tagen es gilt; gleich gebliebener oder fehlender "
       "letzter Wert -> keine Richtung; eine Lücke in der Reihe beendet die Zählung",
       r == [(1, 2), (-1, 3), (None, None), (1, 1), (1, 1), (None, None), (None, None), (None, None), (1, 1), (-1, 1), (None, None)], f"{r}")
    c = [100.0 + i for i in range(260)]                                  # 260 Tage, steigend
    o = list(c); h = [x + 1 for x in c]; l = [x - 1 for x in c]
    for i in (59, 60, 257):                                              # drei Tage ohne Kerze (aufgefüllt mit dem Schluss des Vortags) -- Tag 59 ist der
        c[i] = c[i - 1]; o[i] = h[i] = l[i] = c[i]                      # 201. von hinten und zählt nicht mehr, Tag 60 der 200. und zählt
    o[200] = h[200] = l[200] = c[200]                                    # ein echter Tag ohne Bewegung, aber nicht auf dem Schluss des Vortags: zählt nicht
    m50 = [nan] * 49 + [sum(c[i - 49:i + 1]) / 50 for i in range(49, 260)]
    m200 = [nan] * 199 + [sum(c[i - 199:i + 1]) / 200 for i in range(199, 260)]
    E = {"fehlt": ["Schwankungsband: swing.db fehlt"],
         "trend": {"ma50": m50, "ma200": m200, "tag": 20_759, "schluss": c[-1], "ma50_jetzt": m50[-1], "ma200_jetzt": m200[-1], "n_tage": 260,
                   "lage50_200": 1, "kreuz_tag": 20_700, "steigung50": 1, "seit50": 210},
         "tage": {"quelle": "binance", "alter_tage": 1, "o": o, "h": h, "l": l, "c": c, "gefuellt": 3}}
    Ll = linien_lesen(E)
    E_alt = {"fehlt": ["Tageskerzen zuletzt am 05.11.2026 -- Trend, Bein und Swings ausgeblendet", "Schwankungsband: swing.db fehlt"]}
    E_kurz = {"fehlt": [], "trend": {"ma50": m50[:120], "ma200": [nan] * 120, "tag": 20_619, "schluss": c[119], "ma50_jetzt": m50[119],
                                     "ma200_jetzt": nan, "n_tage": 120}, "tage": {"quelle": "binance", "alter_tage": 0}}
    Lk = linien_lesen(E_kurz)
    ok("Durchschnittslinien lesen (Form von hl_chartbild.tagesteil, von Hand): Werte der Linien, Richtung mit Tagen, Lage mit Tag des "
       "Wechsels, Stand, Quelle, Rückstand; die Summe der letzten 49 und 199 Tagesschlüsse (für den Wert mit dem heutigen Tag); von den "
       "Tagen ohne Kerze zählen nur die unter den letzten 200; ohne Trend nur der Grund des Chartbilds zu den Tageskerzen; mit 120 Tagen "
       "keine 200-Tage-Linie und keine Lage; ohne die Reihe der Schlüsse keine Summe",
       Ll["ma50"] == m50[-1] and Ll["ma200"] == m200[-1] and abs(Ll["ma50"] - sum(c[-50:]) / 50) < 1e-9 and Ll["tag"] == 20_759 and Ll["n_tage"] == 260
       and (Ll["ma50_richtung"], Ll["ma200_richtung"]) == (1, 1) and Ll["ma50_seit"] == 210 and Ll["ma200_seit"] == 60
       and Ll["lage"] == 1 and Ll["kreuz_tag"] == 20_700 and Ll["quelle"] == "binance" and Ll["alter_tage"] == 1 and Ll["gefuellt"] == 2 and Ll["fehlt"] == []
       and abs(Ll["ma50_rest"] - sum(c[-49:])) < 1e-9 and abs(Ll["ma200_rest"] - sum(c[-199:])) < 1e-9 and len(c[-49:]) == 49
       and Lk["ma50_rest"] is None and Lk["ma200_rest"] is None
       and linien_lesen(E_alt) == {"fehlt": ["Tageskerzen zuletzt am 05.11.2026 -- Trend, Bein und Swings ausgeblendet"]}
       and linien_lesen({"fehlt": ["Schwankungsband: x"]}) == {"fehlt": ["Keine Tageskerzen."]}
       and linien_lesen(None) == {"fehlt": ["Tagesteil des Chartbilds nicht lesbar."]}
       and Lk["ma50"] == m50[119] and Lk["ma200"] is None and Lk["ma200_richtung"] is None and Lk["ma200_seit"] is None and Lk["lage"] is None
       and Lk["kreuz_tag"] is None and Lk["gefuellt"] is None and Lk["ma50_seit"] == 70,
       f"50: {Ll['ma50']:.2f} seit {Ll['ma50_seit']}, 200: {Ll['ma200']:.2f} seit {Ll['ma200_seit']}, ohne Kerze {Ll['gefuellt']}")
    b = Ln["beleg"]
    nv_offen = {"da": False, "debug": 149, "linien": {}, "coins": ["BTC"]}
    nv_wirk = dict(nv, ohne_wirkung=False, satz="Niveau-Art mit belegter Wirkung: runde Zahl wird nach dem Erreichen seltener überschritten (hält) "
                                                "(-9,0 Punkte bei 7 Tagen) -- Art belegt seit 15.11.2026.")
    ok("Durchschnittslinien, Beleg: erst „Gemessen, keine Vorhersage …“ mit beiden Rechnungen (groß wie der Live-Chart, klein nach Tagesschluss), dann der Prüfstand der Regel "
       "(aus dem Chartbild), dann das Urteil der Niveau-Arten für beide Linien mit Datum, Coins und dem Satz „nicht belegt heißt nicht "
       "widerlegt“; ohne Urteil „noch nicht geprüft“; ohne lesbares Urteil nur die ersten Teile",
       b == (BELEG_LINIEN + " Als Regel geprüft (Probe): über der 200-Tage-Linie nicht sicherer als Halten. Als Niveau geprüft (U244, Debug 149, "
             "Urteil vom 09.11.2026; 7 Tage; BTC, ETH, HYPE, ZEC, XMR zusammen): 50-Tage-Linie erreicht 34 % bei 36 % erwartet (n 1.234) · "
             "Anziehung nicht belegt · Halten nicht belegt; 200-Tage-Linie erreicht 21 % bei 22 % erwartet (n 987) · Anziehung nicht belegt · "
             "Halten nicht belegt. " + LINIEN_NICHT_WIDERLEGT)
       and linien_niveau_beleg(nv_offen) == "Als Niveau noch nicht geprüft (U244, Debug 149) -- das Urteil rechnet der Rückblick des Ausblicks."
       and linien_niveau_beleg(None) == "" and linien_niveau_beleg(dict(nv, linien={})) == ""
       and linien_niveau_beleg(dict(nv, coins=[])).startswith("Als Niveau geprüft (U244, Debug 149, Urteil vom 09.11.2026; 7 Tage): 50-Tage-Linie ")
       and linien_bauen(L, 60_200.0, P, True)["beleg"] == BELEG_LINIEN
       and BELEG_LINIEN.startswith("Gemessen, keine Vorhersage: einfacher Durchschnitt von 50 und 200 Tagen (Tageswechsel 00:00 UTC). Groß steht der Wert "
                                   "mit dem heutigen Tag zum jetzigen Kurs -- so rechnen der Live-Chart und die Kachel „MA 200 Tage“")
       and "Klein steht der Wert nach dem letzten Tagesschluss -- so rechnen Chartbild, Ausblick und „Levels“" in BELEG_LINIEN,
       b[len(BELEG_LINIEN):][:170])
    lvb = d["levels"]["beleg"]
    ok("Levels, Beleg (23.110): Der Schluss nennt das Urteil der Niveau-Arten statt des alten Satzes „die Art des Niveaus ist nicht geprüft“ "
       "-- mit Urteil ohne Wirkung „für keine Art von Niveau ist eine eigene Wirkung belegt“ mit Datum und Debug-Nummer; ohne Urteil „noch "
       "nicht geprüft“; mit belegter Wirkung der Satz der Niveau-Prüfung; ohne lesbares Urteil nur „folgt allein aus dem Abstand“",
       lvb.endswith("(besteht). Die Zahl folgt allein aus dem Abstand; für keine Art von Niveau ist eine eigene Wirkung belegt (U244, Urteil vom "
                    "09.11.2026, Debug 149).") and "ist nicht geprüft" not in lvb
       and niveau_art_satz(nv_offen) == "Die Zahl folgt allein aus dem Abstand; die Art des Niveaus ist noch nicht geprüft (U244, Debug 149)."
       and niveau_art_satz(nv_wirk) == "Die Zahl folgt allein aus dem Abstand. " + nv_wirk["satz"] + " (U244, Debug 149)"
       and niveau_art_satz(None) == "Die Zahl folgt allein aus dem Abstand."
       and levels_bauen(P, Q["ausblick"]["rueckblick"], 60_200.0)["beleg"].endswith("(besteht). Die Zahl folgt allein aus dem Abstand.")
       and levels_bauen(P, None, 60_200.0, niveaus=nv)["beleg"] == "Der Rückblick des Ausblicks steht noch aus -- die Wahrscheinlichkeiten sind "
                                                                   "noch nicht geprüft.", lvb[-130:])
    tz = linien_text(Ln)
    ok("Durchschnittslinien, Textfassung (Debug 143): je Linie Wert, Abstand, Richtung und Erreich-Wahrscheinlichkeit oder Grund; Lage; Stand "
       "-- dieselben Zahlen wie die Karte; ohne Wert der Grund; fehlende Linie mit Strich; Hinweise hinter dem Stand",
       tz == ["   Durchschnitt 50-Tage-Linie       61.250  nach Tagesschluss 61.300 · Kurs 1,7 % darunter · Linie fällt seit 12 Tagen · ohne "
              "Erreich-Wahrscheinlichkeit: nicht unter den Niveaus des Ausblicks (er führt nur Niveaus innerhalb seiner 98-%-Spanne für 4 Wochen)",
              "   Durchschnitt 200-Tage-Linie      58.020  nach Tagesschluss 58.000 · Kurs 3,8 % darüber · Linie steigt seit 140 Tagen · 1 W 61 % · "
              "2 W 72 % (gilt für den Stand nach Tagesschluss)",
              "   Durchschnitt Lage: Nach dem letzten Tagesschluss liegt die 50-Tage-Linie über der 200-Tage-Linie, seit dem 03.05.2026.",
              "   Durchschnitt Stand: Tagesschlüsse bis 10.11.2026 (UTC), Quelle binance"]
       and linien_text(kein) == ["   Durchschnitt: kein Wert -- Tageskerzen zuletzt am 05.11.2026 -- Trend, Bein und Swings ausgeblendet"]
       and linien_text(kurz_)[1] == "   Durchschnitt 200-Tage-Linie           —  Für die 200-Tage-Linie fehlen noch Tage (150 von 200)."
       and len(linien_text(kurz_)) == 3
       and linien_text(lb(P_=mit(px=57_940.0)))[1].endswith("· 1 W 61 % · 2 W 72 % (gerechnet für 57.940, den Stand der Linie bei der Rechnung des Ausblicks)")
       and linien_text(h1)[-1].endswith("Quelle binance -- Der jüngste Tagesschluss fehlt noch (1 Tag Rückstand; die Tageskerzen lädt hl_binance alle 6 Stunden).")
       and linien_text(None) == [] and linien_text({"ok": False}) == ["   Durchschnitt: kein Wert -- Grund unbekannt"], tz[1] if len(tz) > 1 else tz)
    q_schmal = copy.deepcopy(Q)
    for k_ in ("linien", "trend_beleg", "niveaus_urteil"):
        q_schmal.pop(k_)
    d_s = bauen(q_schmal)
    q_ak = copy.deepcopy(Q); q_ak["kurs"]["ts"] = jetzt - FRISCH_KURS_S - 1
    d_ak = bauen(q_ak)
    q_al = copy.deepcopy(Q); q_al["ausblick"]["prognose"]["anker"] = jetzt - FRISCH_AUSBLICK_S - 1
    d_al = bauen(q_al)
    ok("Durchschnittslinien im Cockpit: Quellen ohne den Tagesteil (wie für den Streifen) geben die Karte mit Grund statt eines Fehlers; ein "
       "Kurs älter als 5 Minuten gibt keinen Abstand (die Werte der Linien bleiben); eine Rechnung des Ausblicks älter als 2 Tage gibt "
       "keine Erreich-Wahrscheinlichkeit -- wie bei „Levels“",
       d_s["linien"]["ok"] is False and d_s["linien"]["fehlt"] == ["Keine Tageskerzen."] and d_s["linien"]["beleg"] == BELEG_LINIEN
       and d_s["levels"]["beleg"].endswith("Die Zahl folgt allein aus dem Abstand.")
       and d_ak["linien"]["ok"] is True and [z["abstand"] for z in d_ak["linien"]["zeilen"]] == [None, None] and d_ak["linien"]["zeilen"][1]["px"] == 58_000.0
       and d_ak["linien"]["zeilen"][1]["p7"] == 0.61 and d_ak["linien"]["zeilen"][1]["haupt_text"] == "58.000"
       and d_ak["linien"]["zeilen"][1]["neben"] == LINIEN_OHNE_KURS == "Stand nach Tagesschluss -- ohne frischen Kurs kein Wert mit dem heutigen Tag"
       and d_ak["linien"]["zeilen"][1]["px_live"] is None
       and d_al["linien"]["zeilen"][1]["p7"] is None and d_al["linien"]["zeilen"][1]["p_grund"] == "die Rechnung des Ausblicks ist älter als 2 Tage"
       and d_al["levels"]["frisch"] is False and abs(d_al["linien"]["zeilen"][1]["abstand"] - 2180.0 / 58020.0) < 1e-12,
       f"{d_s['linien']['fehlt']} | {d_ak['linien']['zeilen'][1]['lage']} | {d_al['linien']['zeilen'][1]['p_grund']}")
    # 23.111: beide Rechnungen -- nach Tagesschluss liegt die 50-Tage-Linie knapp über der 200-Tage-Linie (58.010 gegen 58.000), mit dem
    # heutigen Kurs darunter: (2.839.300 + 60.200) ÷ 50 = 57.990 gegen 58.020
    Lf = dict(L, ma50=58_010.0, ma50_rest=2_839_300.0)
    fl = linien_bauen(dict(Lf), 60_200.0, P, True); fl_ohne = linien_bauen(dict(Lf), None, P, True)
    fu = linien_bauen(dict(L, lage=-1, ma50=57_990.0, ma50_rest=2_841_800.0), 60_200.0, P, True)        # umgekehrt: (2.841.800 + 60.200) ÷ 50 = 58.040
    o_rest = linien_bauen(dict(L, ma50_rest=None, ma200_rest=None), 60_200.0, P, True)["zeilen"]
    ok("Durchschnittslinien, beide Rechnungen (23.111): Der große Wert zählt den heutigen Tag mit dem jetzigen Kurs mit, der kleine nicht; "
       "steht es mit dem heutigen Kurs umgekehrt (50-Tage-Linie nach Tagesschluss über der 200-Tage-Linie, mit heute darunter), sagt der "
       "Satz zur Lage beides; ohne frischen Kurs nur der Stand nach Tagesschluss, ohne den zweiten Satz; ohne die Summe der Vortage "
       "bleibt der Wert nach Tagesschluss groß und der Abstand gilt ihm",
       fl["zeilen"][0]["px_live"] == 57_990.0 and fl["zeilen"][0]["haupt_text"] == "57.990" and fl["zeilen"][0]["neben"] == "nach Tagesschluss 58.010"
       and fl["lage"] == ("Nach dem letzten Tagesschluss liegt die 50-Tage-Linie über der 200-Tage-Linie, seit dem 03.05.2026. Mit dem heutigen "
                          "Kurs gerechnet liegt sie darunter.")
       and fl_ohne["lage"] == "Nach dem letzten Tagesschluss liegt die 50-Tage-Linie über der 200-Tage-Linie, seit dem 03.05.2026."
       and fl_ohne["zeilen"][0]["haupt_text"] == "58.010" and fl_ohne["zeilen"][0]["neben"] == LINIEN_OHNE_KURS
       and fu["zeilen"][0]["px_live"] == 58_040.0
       and fu["lage"] == ("Nach dem letzten Tagesschluss liegt die 50-Tage-Linie unter der 200-Tage-Linie, seit dem 03.05.2026. Mit dem heutigen "
                          "Kurs gerechnet liegt sie darüber.")
       and Ln["lage"].count("Mit dem heutigen Kurs") == 0
       and [(z_["haupt_text"], z_["neben"], z_["px_live"]) for z_ in o_rest] == [("61.300", "Stand nach Tagesschluss", None),
                                                                                ("58.000", "Stand nach Tagesschluss", None)]
       and abs(o_rest[1]["abstand"] - 2200.0 / 58000.0) < 1e-12 and o_rest[1]["p_hinweis"] == "" and o_rest[0]["lage"] == "Kurs 1,8 % darunter",
       f"{fl['zeilen'][0]['haupt_text']} ({fl['zeilen'][0]['neben']}) | {fl['lage'][-52:]}")
    return [Ln, lb(frisch=False), lb(kurs=57_900.0), lb(P_=mit(px=57_940.0), kurs=None), kurz_, kein, nix, h2, h3, tz, d_s["linien"], fl, fu, o_rest,
            niveau_art_satz(nv_offen), niveau_art_satz(nv_wirk), linien_niveau_beleg(nv_offen)]


def _c2_proben(ok, jetzt: int) -> list:
    """
    Proben zum Rest von Stufe C2 (23.108): Funding (Hyperliquid), Taker-Varianz, Liquidationsdichte, Betrieb -- von Hand gerechnet, an
    den Grenzen und auf temporären Datenbanken; ohne Netz und ohne den echten Zustand der Dienste dieses Rechners. Gibt die gebauten
    Texte für die Wortprobe zurück.
    """
    import copy
    import shutil as _sh
    import tempfile
    alle: list = []
    Q = _probe_quellen(jetzt)
    d = bauen(copy.deepcopy(Q)); alle.append(d)
    m = {x["key"]: x for x in d["messwerte"]}
    fh, tv = m.get("funding_hl") or {}, m.get("taker_var") or {}
    ok("Messwerte seit 23.108: fünf Zeilen in fester Reihenfolge (Open Interest, Kontenquote, Funding-Druck, Funding Hyperliquid, "
       "Taker-Varianz); Beispiel: Funding +0,0024 %/h = +21,0 % p. a. im 90. Perzentil von 1.600 Stundenwerten aus 66 Tagen, "
       "Taker-Varianz im 7. Perzentil und damit im untersten Zehntel; jede neue Zeile nennt ihre Vergleichsbasis und ihren Stand",
       [x["key"] for x in d["messwerte"]] == ["oi", "konten", "funding", "funding_hl", "taker_var"]
       and fh.get("text") == "+0,0024 %/h · +21,0 % p. a." and fh.get("pz") == 0.9 and fh.get("pz_n") == 90
       and fh.get("basis") == "1.600 Stundenwerte aus 66 Tagen (Ziel 90)" and fh.get("stand") == jetzt - 40 and fh.get("art") == "live"
       and tv.get("pz_n") == 7 and tv.get("im_dezil") is True and tv.get("text") == "im untersten Zehntel" and tv.get("zone") == 0.10
       and tv.get("note") == TAKER_NOTE and tv.get("stand") == jetzt and tv.get("basis") == "Stunden der letzten 30 Tage (Hyperliquid)"
       and d["messwerte_beleg"] == BELEG_MESSWERT and "basis" not in m["oi"] and "basis" not in m["konten"],
       f"{fh.get('text')} · {fh.get('pz_n')}. · {fh.get('basis')} | Taker {tv.get('pz_n')}. {tv.get('text')}")
    # ---- Funding (Hyperliquid): Perzentil von Hand
    T0 = jetzt // 3600 * 3600
    r480 = [(T0 - 3600 * i, 1e-5 if i % 2 else 3e-5) for i in range(480)]                 # 20 Tage: 240 Werte 0,0010 %/h, 240 Werte 0,0030 %/h
    zf = lambda w, reihe=r480, ts=None: funding_hl_zeile({"wert": w, "ts": jetzt - 30 if ts is None else ts, "reihe": reihe, "fehlt": []}, jetzt)
    alle += [zf(2e-5), zf(-1e-5)]
    ok("Funding (Hyperliquid), Perzentil von Hand: 240 Stundenwerte zu 0,0010 %/h und 240 zu 0,0030 %/h -- ein Wert dazwischen liegt im "
       "50. Perzentil, einer gleich dem oberen im 75. (gleiche Werte zählen halb), gleich dem unteren im 25., über allen im 100., unter "
       "allen im 0.; Text mit vier Stellen je Stunde und dem Jahreswert (Satz × 24 × 365)",
       [zf(w)["pz"] for w in (2e-5, 3e-5, 1e-5, 4e-5, 0.0)] == [0.5, 0.75, 0.25, 1.0, 0.0]
       and zf(2e-5)["text"] == "+0,0020 %/h · +17,5 % p. a." and zf(-1e-5)["text"] == "−0,0010 %/h · −8,8 % p. a." and zf(-1e-5)["pz"] == 0.0
       and zf(2e-5)["basis"] == "480 Stundenwerte aus 19 Tagen (Ziel 90)" and abs(zf(2e-5)["pa"] - 0.1752) < 1e-12,
       f"{[zf(w)['pz'] for w in (2e-5, 3e-5, 1e-5, 4e-5, 0.0)]} · {zf(2e-5)['text']}")
    r13 = [(T0 - 3600 * i, (i % 10) * 1e-6) for i in range(13 * 24 + 23)]                 # 335 Werte über 13 Tage und 22 Stunden
    r14 = [(T0 - 3600 * i, (i % 10) * 1e-6) for i in range(14 * 24 + 1)]                  # 337 Werte über genau 14 Tage
    r239 = [(T0 - 7200 * i, (i % 10) * 1e-6) for i in range(239)]                         # 239 Werte über 19 Tage
    r240 = r239 + [(T0 - 7200 * 239, 0.0)]
    r90 = [(T0 - 3600 * i, (i % 10) * 1e-6) for i in range(90 * 24 + 1)]                  # volle 90 Tage
    ok("Funding (Hyperliquid), Mindestmenge: ein Perzentil gibt es erst ab 14 Tagen Verlauf und 240 Stundenwerten -- darunter steht der "
       "Wert mit dem Grund; bei vollen 90 Tagen entfällt der Zusatz „Ziel 90“",
       zf(5e-6, r13)["pz"] is None and zf(5e-6, r13)["basis"] == "Perzentil ab 14 Tagen Verlauf (bisher 13)" and zf(5e-6, r13)["wert"] == 5e-6
       and zf(5e-6, r14)["pz"] is not None and zf(5e-6, r14)["basis"] == "337 Stundenwerte aus 14 Tagen (Ziel 90)"
       and zf(5e-6, r239)["pz"] is None and zf(5e-6, r239)["basis"] == "Perzentil ab 240 Stundenwerten (bisher 239)"
       and zf(5e-6, r240)["pz"] is not None and zf(5e-6, r90)["basis"] == "2.161 Stundenwerte aus 90 Tagen",
       f"{zf(5e-6, r13)['basis']} | {zf(5e-6, r239)['basis']} | {zf(5e-6, r90)['basis']}")
    r_gleich = [(T0 - 3600 * i, 1.25e-5) for i in range(480)]
    r_alt = r480 + [(T0 - 3600 * (91 * 24 + i), 9e-4) for i in range(1000)]                # 1.000 Werte, älter als 90 Tage: zählen nicht
    z_alt = funding_hl_zeile({"wert": 2e-5, "ts": jetzt - FRISCH_FUNDING_S - 1, "reihe": r480}, jetzt)
    z_leer = funding_hl_zeile({"fehlt": ["Funding (Hyperliquid) nicht lesbar (OperationalError)"], "reihe": []}, jetzt)
    alle += [z_alt, z_leer, funding_hl_zeile(None, jetzt)]
    ok("Funding (Hyperliquid), Frische und Grenzen: Ein Wert, der genau 15 Minuten alt ist, gilt; eine Sekunde älter steht „kein Wert“ mit "
       "dem Stand. Sind alle Vergleichswerte gleich, gibt es kein Perzentil; Werte älter als 90 Tage zählen nicht; ohne Quelle steht der Grund",
       zf(2e-5, r480, jetzt - FRISCH_FUNDING_S)["wert"] == 2e-5 and z_alt["wert"] is None and z_alt["pz"] is None
       and z_alt["fehlt"] == f"letzter Wert vom {_datum(jetzt - FRISCH_FUNDING_S - 1)} -- älter als 15 Minuten" and z_alt["text"] == "—"
       and zf(1.25e-5, r_gleich)["pz"] is None and zf(1.25e-5, r_gleich)["basis"] == "ohne Perzentil: alle Vergleichswerte sind gleich"
       and zf(2e-5, r_alt)["pz"] == 0.5 and zf(2e-5, r_alt)["n"] == 480
       and z_leer["fehlt"] == "Funding (Hyperliquid) nicht lesbar (OperationalError)" and z_leer["wert"] is None
       and funding_hl_zeile(None, jetzt)["fehlt"] == "kein Wert in den letzten zwei Tagen" and FRISCH_FUNDING_S == 900,
       f"{z_alt['fehlt']} | {zf(1.25e-5, r_gleich)['basis']}")
    # ---- Taker-Varianz
    t99, t10, t_kein, t_aus = taker_zeile({"pz": 0.0999, "ts": T0}), taker_zeile({"pz": 0.10, "ts": T0}), taker_zeile({"fehlt": ["zu wenige 10-s-Daten"]}), taker_zeile({"pz": 1.2})
    alle += [t99, t10, t_kein, t_aus, TAKER_NOTE, BELEG_MESSWERT]
    ok("Taker-Varianz an der Grenze: 0,0999 liegt im untersten Zehntel („9. Perzentil“), 0,10 nicht mehr („10.“) -- dieselbe Grenze, an der "
       "die Prognose ihr Band weitet; ohne Wert oder mit einem Wert außerhalb von 0 bis 1 steht der Grund; der Hinweis sagt, dass der "
       "Zusammenhang im Projekt nicht geprüft ist",
       t99["im_dezil"] is True and t99["pz_n"] == 9 and t99["text"] == "im untersten Zehntel" and t10["im_dezil"] is False and t10["pz_n"] == 10
       and t10["text"] == "nicht im untersten Zehntel" and t_kein["wert"] is None and t_kein["fehlt"] == "zu wenige 10-s-Daten"
       and t_aus["wert"] is None and t_aus["fehlt"] == "kein Wert" and taker_zeile(None)["fehlt"] == "kein Wert" and TAKER_DEZIL == 0.10
       and "nicht geprüft" in TAKER_NOTE and "im Mittel, nicht im Einzelfall" in TAKER_NOTE, f"{t99['text']} · {t10['text']}")
    # ---- Liquidationsdichte von Hand (Kurs 60.200)
    lq = d["liqdichte"]; B = lq.get("balken") or []
    usd = [round(b["usd"]) for b in B]
    ok("Liquidationsdichte von Hand (Kurs 60.200): zwölf Stufen je 0,5 % von −3 % bis +3 %; unter dem Kurs zählen nur Long-, darüber nur "
       "Short-Positionen (4,7 und 3,7 Mio. USD, 15 und 11 Positionen); Zellen auf der falschen Seite des Kurses stehen als „überholt“ "
       "(0,7 Mio. USD, 3 Positionen), Zellen jenseits von 3 % zählen nicht; Abdeckung 27 %, zu alt 128.273 von 150.597 = 85 %",
       lq.get("ok") is True and lq.get("frisch") is True and len(B) == 12 and [round(b["von"] * 1000) for b in B] == list(range(-30, 30, 5))
       and [b["seite"] for b in B] == ["long"] * 6 + ["short"] * 6
       and usd == [500_000, 0, 0, 3_000_000, 0, 1_200_000, 800_000, 0, 0, 2_500_000, 0, 400_000] and [b["n"] for b in B] == [2, 0, 0, 9, 0, 4, 3, 0, 0, 7, 0, 1]
       and round(lq["summe_unten"]) == 4_700_000 and round(lq["summe_oben"]) == 3_700_000 and (lq["n_unten"], lq["n_oben"]) == (15, 11)
       and round(lq["ueberholt_usd"]) == 700_000 and lq["ueberholt_n"] == 3 and lq["abdeckung"] == 0.27 and lq["alt_n"] == 128_273
       and lq["bekannt_n"] == 150_597 and abs(lq["alt_anteil"] - 128_273 / 150_597) < 1e-12 and lq["stand"] == jetzt - 240 and lq["kurs"] == 60_200.0
       and round(lq["groesster"]) == 3_000_000 and lq["beleg"] == BELEG_LIQ and "keine Größenklasse belegt" in lq["magnet"]
       and (lq["name_unten"], lq["name_oben"]) == ("Long-Liquidationen darunter", "Short-Liquidationen darüber"),
       f"Stufen {usd}; überholt {lq.get('ueberholt_usd')}")
    lz = lambda zeilen, kurs=100.0, ts=None: liqdichte_bauen({"ts": jetzt - 60 if ts is None else ts, "zeilen": zeilen, "fehlt": []}, kurs, jetzt, "BTC")
    idx = lambda D_: [i for i, b in enumerate(D_["balken"]) if b["usd"] > 0]
    g = lz([(97.0, "long", 1.0, 1), (96.99, "long", 5.0, 1), (99.5, "long", 2.0, 1), (99.49, "long", 4.0, 1), (100.5, "short", 8.0, 1), (100.51, "short", 16.0, 1),
            (103.0, "short", 32.0, 1), (103.01, "short", 64.0, 1), (100.0, "long", 128.0, 1), (100.0, "short", 256.0, 1)])
    alle += [g, liqdichte_text(lq), liqdichte_text(g)]
    ok("Liquidationsdichte an den Grenzen (Kurs 100): −3,00 % gehört zur äußersten Stufe, −3,01 % nicht mehr; −0,50 % gehört zur Stufe am "
       "Kurs, −0,51 % zur nächsten; oben spiegelbildlich (+0,50 % / +0,51 %, +3,00 % / +3,01 %); eine Zelle genau am Kurs zählt auf ihrer Seite",
       [b["usd"] for b in g["balken"]] == [1.0, 0, 0, 0, 4.0, 130.0, 264.0, 16.0, 0, 0, 0, 32.0] and g["ueberholt_n"] == 0
       and g["summe_unten"] == 135.0 and g["summe_oben"] == 312.0, f"{[b['usd'] for b in g['balken']]}")
    alt_g = lz([(98.8, "long", 5.0, 2)], ts=jetzt - FRISCH_LIQ_S - 1); frisch_g = lz([(98.8, "long", 5.0, 2)], ts=jetzt - FRISCH_LIQ_S)
    ohne_k = lz([(98.8, "long", 5.0, 2)], kurs=None); leer_g = liqdichte_bauen(None, 100.0, jetzt, "BTC"); null_g = lz([(99.0, "long", 0.0, 2), (99.0, "long", -3.0, 1), (0.0, "long", 9.0, 1)])
    alle += [alt_g, ohne_k, leer_g, liqdichte_text(alt_g), liqdichte_text(ohne_k), liqdichte_text(leer_g), BELEG_LIQ]
    ok("Liquidationsdichte, Frische: Ein Schnappschuss, der genau 30 Minuten alt ist, gilt; eine Sekunde älter ist die Karte „nicht frisch“ "
       "und nennt den Stand (die Balken bleiben, grau). Ohne frischen Kurs gibt es keine Balken, ohne Schnappschuss nur den Grund; Zellen "
       "ohne Betrag zählen nicht",
       frisch_g["frisch"] is True and not frisch_g["fehlt"] and alt_g["frisch"] is False and alt_g["ok"] is True and idx(alt_g) == [3]
       and alt_g["fehlt"] == [f"Schnappschuss vom {_datum(jetzt - FRISCH_LIQ_S - 1)} -- älter als 30 Minuten."]
       and ohne_k["ok"] is False and ohne_k["balken"] == [] and ohne_k["fehlt"] == ["Ohne frischen Kurs keine Abstände."] and ohne_k["stand"] == jetzt - 60
       and leer_g["ok"] is False and leer_g["fehlt"] == ["noch kein Schnappschuss der Heatmap"] and leer_g["stand"] is None
       and null_g["ok"] is True and idx(null_g) == [] and null_g["groesster"] is None and FRISCH_LIQ_S == 1800, f"{alt_g['fehlt']} | {ohne_k['fehlt']}")
    q_alt = copy.deepcopy(Q); q_alt["kurs"]["ts"] = jetzt - FRISCH_KURS_S - 1
    d_alt = bauen(q_alt)
    tl = liqdichte_text(lq)
    ok("Liquidationsdichte im Cockpit: Abstände nur vom frischen Kurs (ist der Kurs älter als 5 Minuten, steht der Grund statt der Balken); "
       "der Streifen der sechs Coins liest die Karte nicht; die Textfassung (Debug 143) nennt Summen, alle zwölf Stufen, Abdeckung und Beleg",
       d_alt["liqdichte"]["ok"] is False and "Ohne frischen Kurs keine Abstände." in d_alt["liqdichte"]["fehlt"]
       and bauen({"coin": "BTC", "jetzt": jetzt})["liqdichte"]["ok"] is False and len(tl) == 4
       and tl[0] == ("   Liquidationsdichte ± 3 % um 60.200: Long-Liquidationen darunter 4,7 Mio. USD (15 Positionen) · Short-Liquidationen "
                     f"darüber 3,7 Mio. USD (11 Positionen) · Stand {_datum(jetzt - 240)}")
       and tl[1].startswith("   Liquidationsdichte Stufen: −3,0…−2,5 %: 500 Tsd. USD · −2,5…−2,0 %: 0 USD · ") and tl[1].count(" %: ") == 12
       and "−0,5…0,0 %: 1,2 Mio. USD · 0,0…+0,5 %: 800 Tsd. USD" in tl[1] and tl[1].endswith("+2,5…+3,0 %: 400 Tsd. USD")
       and tl[2] == ("   Liquidationsdichte Abdeckung: erfasst 27 % des Open Interest · 85 % der bekannten Positionen (128.273 von 150.597, alle "
                     "Coins) seit über 60 Minuten nicht abgefragt und nicht enthalten · überholt und nicht gezeigt: 700 Tsd. USD (3 Positionen)")
       and tl[3] == f"   Liquidationsdichte Beleg: {BELEG_LIQ} {lq['magnet']}"
       and liqdichte_text(leer_g) == ["   Liquidationsdichte: kein Wert -- noch kein Schnappschuss der Heatmap"]
       and liqdichte_text(None) == ["   Liquidationsdichte: kein Wert -- Grund unbekannt"] and liqdichte_text(alt_g)[0].endswith(" -- NICHT FRISCH"), tl[0])
    tl1 = liqdichte_text(dict(lq, n_unten=1, n_oben=0, ueberholt_n=1))
    ok("Liquidationsdichte, Textfassung: Einzahl -- „1 Position“, „0 Positionen“ (23.109)",
       "Long-Liquidationen darunter 4,7 Mio. USD (1 Position) · Short-Liquidationen darüber 3,7 Mio. USD (0 Positionen) · Stand" in tl1[0]
       and tl1[2].endswith("überholt und nicht gezeigt: 700 Tsd. USD (1 Position)") and "1 Positionen" not in " ".join(tl1)
       and _pos(1) == "1 Position" and _pos(2) == "2 Positionen" and _pos(0) == "0 Positionen" and _pos(11) == "11 Positionen", tl1[0][-90:])
    kl = lambda **b: {"klassen": {n: {"belegt": bool(b.get(n))} for n in ("klein", "mittel", "groß")}}
    ms0 = magnet_satz({"ts": jetzt - 7200, "h": {"1": kl(), "4": kl()}}); ms1 = magnet_satz({"ts": jetzt - 7200, "h": {"4": kl(mittel=True), "1": kl(groß=True)}})
    ms2 = magnet_satz({"ts": jetzt - 7200, "h": {"1": {"n_bloecke": 3, "zu_wenig": True}, "4": {"zu_wenig": True}}})
    ms3 = magnet_satz({"ts": jetzt - 7200, "h": {"1": kl(), "4": {"zu_wenig": True}}}); ms4 = magnet_satz(None, "Der Prognosespeicher fehlt noch.")
    alle += [ms0, ms1, ms2, ms3, ms4, magnet_satz(None)]
    ok("Satz zum Magnet-Test in der Karte „Liquidationsdichte“ folgt der gespeicherten Rechnung: nichts belegt, einzelne Klassen belegt "
       "(nach Frist geordnet), zu wenige Fälle; fehlt die Rechnung, steht der Grund -- nie ein Urteil aus dem Gedächtnis",
       ms0 == f"Magnet-Test (Debug 51, Stand {_datum(jetzt - 7200)}): Dass der Kurs solche Cluster anzieht, ist für keine Größenklasse belegt."
       and ms1 == f"Magnet-Test (Debug 51, Stand {_datum(jetzt - 7200)}): Anziehung belegt für 1 h groß, 4 h mittel; sonst nicht."
       and ms2 == f"Magnet-Test (Debug 51, Stand {_datum(jetzt - 7200)}): noch zu wenige Fälle für ein Urteil."
       and ms3.endswith("ist für keine Größenklasse belegt (für 4 h noch zu wenige Fälle).")
       and ms4 == "Ob der Kurs solche Cluster anzieht, prüft der Magnet-Test (Debug 51). Der Prognosespeicher fehlt noch."
       and magnet_satz(None).endswith("Seine Rechnung liegt nicht vor."), ms1)
    # ---- Betrieb: reine Regeln
    alles_an = {"pruefbar": True, "grund": "", "liste": [{"name": u, "zustand": "active"} for u in DIENSTE]}
    api = lambda gew, ts=None, limit=1200.0: {"gewicht": gew, "deckel": 1080.0, "limit": limit, "ts": jetzt - 300 if ts is None else ts, "abgewiesen": 0.0}
    bk = lambda h, gut=True: {"da": True, "ordner": "/x", "ok": gut, "ts": jetzt - h * 3600, "fehler": "" if gut else "Platz reicht nicht"}
    bb = lambda D_=alles_an, A_=None, K_=None, seit=None, warte=DIENST_BESTAETIGT_S, t=jetzt: betrieb_bauen(
        {"dienste": D_, "api": api(1046.0) if A_ is None else A_, "backup": bk(14.0) if K_ is None else K_}, t, {} if seit is None else seit, warte)
    zs = lambda Bt: {z_["key"]: z_ for z_ in Bt["zeilen"]}
    b0 = bb(); alle += [b0, betrieb_text(b0), BELEG_BETRIEB]
    ok("Betrieb ohne Auffälligkeit: sechs von sechs Diensten laufen, API-Gewicht 1.046 von 1.200 je Minute (87 % des Limits), Backup vor 14 "
       "Stunden -- „ohne Hinweis“, keine Gründe; jede Zeile mit Zahl und Schwelle",
       b0["zustand"] == "aus" and b0["wort"] == "ohne Hinweis" and b0["gruende"] == [] and [z_["key"] for z_ in b0["zeilen"]] == ["dienste", "api", "backup"]
       and zs(b0)["dienste"]["text"] == "6 von 6 eingerichteten laufen" and zs(b0)["dienste"]["zustand"] == "aus"
       and zs(b0)["api"]["text"] == "1.046 von 1.200 je Minute = 87 % des Limits (Hinweis ab 93 %; Deckel des Recorders 1.080)"
       and zs(b0)["backup"]["text"] == "vor 14,0 h (Hinweis ab 36 h)" and zs(b0)["backup"]["stand"] == jetzt - 14 * 3600 and b0["beleg"] == BELEG_BETRIEB
       and b0["stand"] == jetzt, f"{b0['wort']}: {[z_['text'] for z_ in b0['zeilen']]}")
    a_929, a_93, a_alt, a_frisch = bb(A_=api(1115.0)), bb(A_=api(1116.0)), bb(A_=api(1190.0, jetzt - FRISCH_API_S - 1)), bb(A_=api(1190.0, jetzt - FRISCH_API_S))
    a_429 = bb(A_=dict(api(900.0), abgewiesen=12.0)); a_leer = bb(A_={})
    alle += [a_93, a_alt, a_429, a_leer]
    ok("Betrieb, API-Gewicht an der Schwelle des Wächters: 1.115 von 1.200 (92,9 %) ohne Hinweis und als „92 %“ gezeigt, 1.116 (93,0 %) mit "
       "Hinweis und „93 %“ -- Zahl und Lampe widersprechen sich nie; ein Stand älter als 30 Minuten wird nicht gewertet (grau), genau 30 "
       "Minuten gelten; Abweisungen der Börse stehen als Zahl dabei, ohne die Lampe zu ändern",
       a_929["zustand"] == "aus" and "= 92 % des Limits" in zs(a_929)["api"]["text"] and a_93["zustand"] == "hinweis" and a_93["gruende"] == ["API-Gewicht"]
       and "= 93 % des Limits" in zs(a_93)["api"]["text"] and zs(a_93)["api"]["zustand"] == "hinweis" and a_alt["zustand"] == "aus"
       and zs(a_alt)["api"]["zustand"] == "grau" and "nicht gewertet" in zs(a_alt)["api"]["text"] and a_frisch["zustand"] == "hinweis"
       and a_429["zustand"] == "aus" and zs(a_429)["api"]["text"].endswith(" · 12 Abweisungen (429) seit dem Start des Recorders")
       and zs(a_leer)["api"]["zustand"] == "grau" and a_leer["zustand"] == "aus" and API_HINWEIS == 0.93 and FRISCH_API_S == 1800,
       f"{zs(a_929)['api']['text']} | {zs(a_93)['api']['text']}")
    k_36, k_361, k_fehl, k_ohne = bb(K_=bk(36.0)), bb(K_=bk(36.01)), bb(K_=bk(3.0, False)), bb(K_={"da": False, "ordner": "/mnt/usb/dbbackup"})
    alle += [k_361, k_fehl, k_ohne]
    ok("Betrieb, Backup: genau 36 Stunden alt ohne Hinweis, darüber „Backup alt“; eine fehlgeschlagene Sicherung ist ein Hinweis mit dem "
       "Grund; ohne Sicherung steht „noch keine Sicherung gefunden“ ohne Alarm (grau)",
       k_36["zustand"] == "aus" and k_361["zustand"] == "hinweis" and k_361["gruende"] == ["Backup alt"] and zs(k_361)["backup"]["text"] == "vor 36,0 h (Hinweis ab 36 h)"
       and k_fehl["zustand"] == "hinweis" and k_fehl["gruende"] == ["Backup"] and zs(k_fehl)["backup"]["text"] == "letzte Sicherung fehlgeschlagen: Platz reicht nicht"
       and k_ohne["zustand"] == "aus" and zs(k_ohne)["backup"]["zustand"] == "grau"
       and zs(k_ohne)["backup"]["text"] == "noch keine Sicherung gefunden (/mnt/usb/dbbackup)" and BACKUP_HINWEIS_H == 36,
       f"{zs(k_361)['backup']['text']} | {zs(k_fehl)['backup']['text']}")
    def mit(**zust):
        return {"pruefbar": True, "grund": "", "liste": [{"name": u, "zustand": zust.get(u.replace("hl-", ""), "active")} for u in DIENSTE]}
    seit: dict = {}
    s1 = bb(D_=mit(binance="failed"), seit=seit, t=jetzt); s2 = bb(D_=mit(binance="failed"), seit=seit, t=jetzt + DIENST_BESTAETIGT_S - 1)
    s3 = bb(D_=mit(binance="failed"), seit=seit, t=jetzt + DIENST_BESTAETIGT_S); seit_mitte = dict(seit)
    s4 = bb(D_=mit(), seit=seit, t=jetzt + 200); seit_ende = dict(seit)
    s5 = bb(D_=mit(recorder="activating", coinbase="reloading"), seit={}); s6 = bb(D_=mit(binance="inactive", watchdog="unbekannt"), seit={}, warte=0)
    s7 = bb(D_=mit(binance="failed"), A_=api(1150.0), K_=bk(40.0), seit={}, warte=0)
    alle += [s1, s3, s5, s6, s7, betrieb_text(s7), betrieb_text(s5)]
    ok("Betrieb, Dienste: Ein eingerichteter Dienst, der nicht „active“ ist, ist beim ersten Sehen ein Hinweis („eben nicht aktiv“) und wird "
       "nach 60 Sekunden zur Warnung -- beim Neustart nach einem Update ist jeder Dienst kurz inaktiv; läuft er wieder, erlischt beides. "
       "„activating“ und „reloading“ sind ein Hinweis „startet“. Ohne Wartezeit (Debug 143) gilt die Warnung sofort; Warnung geht vor Hinweis "
       "und nennt alle Gründe",
       s1["zustand"] == "hinweis" and s1["gruende"] == ["Dienst nicht aktiv: binance"] and s2["zustand"] == "hinweis" and s3["zustand"] == "warnung"
       and s3["wort"] == "Warnung" and s3["gruende"] == ["Dienst läuft nicht: binance"] and seit_mitte == {"hl-binance": jetzt}
       and zs(s3)["dienste"]["text"] == "5 von 6 eingerichteten laufen · läuft nicht: hl-binance (failed)" and zs(s3)["dienste"]["zustand"] == "warnung"
       and zs(s1)["dienste"]["text"] == "5 von 6 eingerichteten laufen · eben nicht aktiv (wird bestätigt): hl-binance (failed)"
       and s4["zustand"] == "aus" and seit_ende == {}
       and s5["zustand"] == "hinweis" and s5["gruende"] == ["Dienst startet: recorder, coinbase"]
       and zs(s5)["dienste"]["text"] == "4 von 6 eingerichteten laufen · startet: hl-recorder, hl-coinbase"
       and s6["zustand"] == "warnung" and s6["gruende"] == ["Dienst läuft nicht: binance, watchdog"]
       and s7["zustand"] == "warnung" and s7["gruende"] == ["Dienst läuft nicht: binance", "API-Gewicht", "Backup alt"] and DIENST_BESTAETIGT_S == 60,
       f"{s1['gruende']} -> {s3['gruende']} | {s5['gruende']} | {s7['gruende']}")
    n_p = bb(D_={"pruefbar": False, "grund": "auf diesem Rechner gibt es kein systemd", "liste": []}); n_alle = bb(D_={"pruefbar": False, "grund": "x", "liste": []}, A_={}, K_={"da": False})
    tx = betrieb_text(s7)
    alle += [n_p, n_alle, betrieb_text(n_p), betrieb_text(None)]
    ok("Betrieb, nicht prüfbar: Ohne systemd ist die Zeile „Dienste“ grau, die Lampe folgt API-Gewicht und Backup; ist nichts prüfbar, steht "
       "„nicht prüfbar“ -- nie „ohne Hinweis“. Textfassung (Debug 143): Kopfzeile mit Wort und Gründen, drei Zeilen mit „kein Hinweis“, "
       "„Hinweis“, „Warnung“ oder „ohne Wert“ (nie „aus“ -- „Dienste aus“ läse sich falsch), Beleg",
       n_p["zustand"] == "aus" and zs(n_p)["dienste"]["zustand"] == "grau" and zs(n_p)["dienste"]["text"] == "nicht prüfbar: auf diesem Rechner gibt es kein systemd"
       and n_alle["zustand"] == "grau" and n_alle["wort"] == "nicht prüfbar" and len(tx) == 5
       and tx[0] == f"Betrieb: Warnung (Dienst läuft nicht: binance; API-Gewicht; Backup alt) · Stand {_datum(jetzt)}"
       and tx[1] == "   Dienste      Warnung      5 von 6 eingerichteten laufen · läuft nicht: hl-binance (failed)"
       and tx[2] == f"   API-Gewicht  Hinweis      1.150 von 1.200 je Minute = 95 % des Limits (Hinweis ab 93 %; Deckel des Recorders 1.080) · Stand {_datum(jetzt - 300)}"
       and tx[3] == f"   Backup       Hinweis      vor 40,0 h (Hinweis ab 36 h) · gesichert {_datum(jetzt - 40 * 3600)}" and tx[4] == "   " + BELEG_BETRIEB
       and betrieb_text(None) == ["Betrieb: kein Wert"] and betrieb_text(n_p)[1] == "   Dienste      ohne Wert    nicht prüfbar: auf diesem Rechner gibt es kein systemd"
       and betrieb_text(n_p)[2].startswith("   API-Gewicht  kein Hinweis 1.046 von 1.200 je Minute = 87 % des Limits"),
       tx[0])
    # ---- Leser: Dienste über einen Ersatz für systemctl, API-Gewicht und Backup aus temporären Dateien
    rufe: list = []
    def lauf(befehl, dienst, _z={"hl-recorder": ("enabled", "active"), "hl-dashboard": ("enabled-runtime", "active"), "hl-binance": ("enabled", "failed"),
                                 "hl-coinbase": ("disabled", "inactive"), "hl-notbremse": ("", ""), "hl-watchdog": ("enabled", "")}):
        rufe.append((befehl, dienst)); return _z[dienst][0 if befehl == "is-enabled" else 1]
    dl = dienste_lesen(lauf)
    rufe_h: list = []
    dl_h = dienste_lesen(lambda b_, u_: (rufe_h.append((b_, u_)), "enabled" if b_ == "is-enabled" else None)[1])
    ok("Dienste lesen wie der Wächter: nur eingerichtete Dienste zählen (is-enabled „enabled“ oder „enabled-runtime“) -- ein abgeschalteter "
       "oder nie eingerichteter Dienst ist kein Alarm und wird nicht nach seinem Zustand gefragt; eine leere Antwort heißt „unbekannt“; "
       "antwortet systemctl nicht (auch mitten in der Abfrage -- dann wird nicht jeder Dienst einzeln abgewartet) oder ist kein Dienst "
       "eingerichtet, ist nichts prüfbar",
       dl == {"pruefbar": True, "grund": "", "liste": [{"name": "hl-recorder", "zustand": "active"}, {"name": "hl-dashboard", "zustand": "active"},
                                                       {"name": "hl-binance", "zustand": "failed"}, {"name": "hl-watchdog", "zustand": "unbekannt"}]}
       and [r_ for r_ in rufe if r_[0] == "is-active"] == [("is-active", u) for u in ("hl-recorder", "hl-dashboard", "hl-binance", "hl-watchdog")]
       and [r_[1] for r_ in rufe if r_[0] == "is-enabled"] == list(DIENSTE)
       and dienste_lesen(lambda b_, u_: None) == {"pruefbar": False, "grund": "systemctl antwortet nicht", "liste": []}
       and dl_h == {"pruefbar": False, "grund": "systemctl antwortet nicht", "liste": []} and rufe_h == [("is-enabled", "hl-recorder"), ("is-active", "hl-recorder")]
       and dienste_lesen(lambda b_, u_: "disabled") == {"pruefbar": False, "grund": "kein Dienst des Projekts ist eingerichtet", "liste": []},
       f"{[(e_['name'], e_['zustand']) for e_ in dl['liste']]}")
    tmp = tempfile.mkdtemp(prefix="cockpit_c2_")
    try:
        db = os.path.join(tmp, "h.db"); bdir = os.path.join(tmp, "sicherung"); os.makedirs(bdir)
        c = sqlite3.connect(db)
        c.executescript("""CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT);
            CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin)) WITHOUT ROWID;
            CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER, PRIMARY KEY (ts, coin, bucket_px, side)) WITHOUT ROWID;
            CREATE TABLE coverage (ts INTEGER, coin TEXT, tracked_size REAL, oi REAL, ratio REAL, PRIMARY KEY (ts, coin)) WITHOUT ROWID;
            CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, n_stale_dropped INTEGER,
                                        age_median INTEGER, age_p90 INTEGER, backlog INTEGER, uptime INTEGER);""")
        c.executemany("INSERT INTO meta VALUES (?,?)", [("api_weight_1m", "1143"), ("api_weight_budget", "1080"), ("api_weight_limit", "1200"),
                                                        ("api_weight_ts", str(jetzt - 120)), ("rate_limited", "3"), ("backup_dir", bdir)])
        # Funding: volle Stunden der letzten 3 Tage (Wert = Stunde modulo 7), dazwischen Minuten, ein fremder Coin, ein leerer Wert, eine Zeile in der Zukunft
        zeilen = [(T0 - 3600 * i, "BTC", 1.0, 1.0, 1.0, (i % 7) * 1e-6, 5.0, 0.0) for i in range(72)]
        zeilen += [(T0 - 3600 * i + 60 * k, "BTC", 1.0, 1.0, 1.0, 9e-4, 5.0, 0.0) for i in range(1, 72) for k in (1, 30, 59)]
        zeilen += [(T0 - 3600 * i, "ETH", 1.0, 1.0, 1.0, 5e-4, 5.0, 0.0) for i in range(72)]
        zeilen += [(T0 - 3600 * 80, "BTC", 1.0, 1.0, 1.0, None, 5.0, 0.0), (T0 - 3600 * 24 * 91, "BTC", 1.0, 1.0, 1.0, 7e-4, 5.0, 0.0),
                   (jetzt + 600, "BTC", 1.0, 1.0, 1.0, 8e-4, 5.0, 0.0), (T0 - 3600 * 24 * 3, "ZEC", 1.0, 1.0, 1.0, 2e-6, 5.0, 0.0)]
        c.executemany("INSERT OR REPLACE INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", zeilen)
        # Heatmap: älterer und jüngster Schnappschuss; der jüngste ohne Zelle für ETH; danach nur noch eine Neustart-Zeile ohne Zahlen
        alt_ts, neu_ts = jetzt - 900, jetzt - 300
        c.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", [(alt_ts, "BTC", 59_000.0, "long", 9e6, 9), (alt_ts, "ETH", 2_900.0, "long", 4e6, 4),
                                                                    (neu_ts, "BTC", 59_900.0, "long", 2e6, 5), (neu_ts, "BTC", 60_500.0, "short", 1e6, 2)])
        c.executemany("INSERT INTO coverage VALUES (?,?,?,?,?)", [(alt_ts, "BTC", 1.0, 2.0, 0.25), (neu_ts, "BTC", 540.0, 1000.0, 0.27), (alt_ts, "ETH", 1.0, 2.0, 0.19)])
        c.executemany("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", [(alt_ts, 1, 1, 100, 300, 50, 60, 0, 900), (neu_ts, 1, 1, 22_324, 128_273, 990_000, 2_000_000, 0, 1500)])
        c.execute("INSERT INTO snapshot_meta (ts, uptime) VALUES (?, ?)", (jetzt - 60, 5))
        c.commit(); c.close()
        ro = _ro(db)
        try:
            F = funding_hl_lesen(ro, "BTC", jetzt); F_z = funding_hl_lesen(ro, "ZEC", jetzt); F_x = funding_hl_lesen(ro, "XMR", jetzt)
            Lb = liqdichte_lesen(ro, "BTC", jetzt); Le = liqdichte_lesen(ro, "ETH", jetzt); A = api_lesen(ro); K0 = backup_lesen(db, ro)
        finally:
            ro.close()
        ok("Funding (Hyperliquid) aus ctx_bars lesen: nur die Werte zur vollen Stunde der letzten 90 Tage und nur der gefragte Coin (72 "
           "Stunden; Minuten dazwischen, fremde Coins, leere Werte und eine Zeile älter als 90 Tage bleiben draußen); der jüngste Wert ist "
           "die letzte Zeile bis jetzt, nie eine aus der Zukunft; liegt er länger als zwei Tage zurück, gibt es keinen",
           len(F["reihe"]) == 72 and F["reihe"][-1] == (T0, 0.0) and F["reihe"][0] == (T0 - 3600 * 71, (71 % 7) * 1e-6) and F["wert"] == 0.0 and F["ts"] == T0 + 60
           and all(t_ % 3600 == 0 and v_ < 1e-5 for t_, v_ in F["reihe"]) and not F["fehlt"]
           and F_z["reihe"] == [(T0 - 3600 * 24 * 3, 2e-6)] and "wert" not in F_z and F_x == {"fehlt": [], "reihe": []}
           and funding_hl_zeile(F_z, jetzt)["fehlt"] == "kein Wert in den letzten zwei Tagen"
           and funding_hl_lesen(None, "BTC", jetzt)["fehlt"] == ["Datenbank des Recorders fehlt"], f"{len(F['reihe'])} Stunden, jüngster Wert {F.get('wert')} von {_datum(F.get('ts'))}")
        ok("Liquidationsdichte lesen: maßgeblich ist der jüngste vollständige Schnappschuss (eine Neustart-Zeile ohne Zahlen zählt nicht); "
           "BTC mit seinen zwei Zellen, Abdeckung 27 % und 128.273 zu alten von 150.597 Positionen; ETH hat im jüngsten Schnappschuss keine "
           "Zelle -- die Dichte ist dann null mit dem frischen Stand, nicht der alte Schnappschuss",
           Lb.get("ts") == neu_ts and sorted(Lb["zeilen"]) == [(59_900.0, "long", 2e6, 5), (60_500.0, "short", 1e6, 2)] and (Lb.get("abdeckung") or {}).get("anteil") == 0.27
           and Lb.get("positionen") == {"drin": 22_324.0, "alt": 128_273.0, "alter_median_s": 990_000.0} and not Lb["fehlt"]
           and Le.get("ts") == neu_ts and Le["zeilen"] == [] and "abdeckung" not in Le
           and liqdichte_bauen(Le, 3_000.0, jetzt, "ETH")["ok"] is True and liqdichte_bauen(Le, 3_000.0, jetzt, "ETH")["summe_unten"] == 0
           and liqdichte_lesen(None, "BTC", jetzt)["fehlt"] == ["Datenbank des Recorders fehlt"], f"BTC {Lb['zeilen']} · ETH {Le['zeilen']} · Stand {_datum(Lb.get('ts'))}")
        c = sqlite3.connect(db); c.execute("DROP TABLE snapshot_meta"); c.execute("DROP TABLE coverage"); c.commit(); c.close()
        ro = _ro(db)
        try:
            Lo = liqdichte_lesen(ro, "ETH", jetzt); Lx = liqdichte_lesen(ro, "XMR", jetzt)
        finally:
            ro.close()
        ok("Liquidationsdichte lesen auf einem alten Stand der Datenbank (ohne snapshot_meta und coverage): der jüngste Schnappschuss des "
           "Coins aus der Heatmap, ohne Abdeckung; ein Coin ohne jede Zelle meldet „noch kein Schnappschuss“",
           Lo["ts"] == alt_ts and Lo["zeilen"] == [(2_900.0, "long", 4e6, 4)] and "abdeckung" not in Lo and "positionen" not in Lo and not Lo["fehlt"]
           and Lx["fehlt"] == ["noch kein Schnappschuss der Heatmap"] and "ts" not in Lx, f"ETH Stand {_datum(Lo.get('ts'))}")
        with open(os.path.join(bdir, "backup.json"), "w", encoding="utf-8") as f:
            json.dump({"ok": True, "ts": jetzt - 41 * 3600, "size": 3.1e9}, f)
        ro = _ro(db)
        try:
            K1 = backup_lesen(db, ro)
        finally:
            ro.close()
        with open(os.path.join(bdir, "backup.json"), "w", encoding="utf-8") as f:
            f.write("{kaputt")
        K2 = backup_lesen(db, None); K3 = backup_lesen(os.path.join(tmp, "anders", "x.db"), None)
        Bl = betrieb_lesen(db, jetzt, lauf)
        with open(os.path.join(bdir, "backup.json"), "w", encoding="utf-8") as f:
            json.dump({"ok": True, "ts": jetzt - 41 * 3600, "size": 3.1e9}, f)
        Bl2 = betrieb_lesen(db, jetzt, lauf); Bt = betrieb_bauen(Bl2, jetzt, {}, 0)
        alle += [Bt, betrieb_text(Bt)]
        ok("Betrieb lesen: API-Gewicht aus meta (dieselben Schlüssel wie der Wächter), Backup aus backup.json im eingetragenen Ordner (sonst "
           "„dbbackup“ neben der Datenbank; eine unlesbare Datei gilt als „keine Sicherung“); zusammen: Dienst binance läuft nicht, "
           "API-Gewicht 1.143 von 1.200 = 95 %, Backup 41 Stunden alt -- Warnung mit drei Gründen",
           A == {"gewicht": 1143.0, "deckel": 1080.0, "limit": 1200.0, "ts": float(jetzt - 120), "abgewiesen": 3.0} and K0 == {"da": False, "ordner": bdir}
           and K1 == {"da": True, "ordner": bdir, "ok": True, "ts": float(jetzt - 41 * 3600), "fehler": ""} and K2 == {"da": False, "ordner": os.path.join(tmp, "dbbackup")}
           and K3["ordner"] == os.path.join(tmp, "anders", "dbbackup") and Bl["backup"] == {"da": False, "ordner": bdir} and Bl["api"] == A
           and Bt["zustand"] == "warnung" and Bt["gruende"] == ["Dienst läuft nicht: binance, watchdog", "API-Gewicht", "Backup alt"]
           and "= 95 % des Limits" in zs(Bt)["api"]["text"] and "3 Abweisungen (429)" in zs(Bt)["api"]["text"] and api_lesen(None) == {},
           f"{Bt['gruende']}")
        e1 = betrieb_lesen(db, jetzt); e2 = betrieb_lesen(db, jetzt); N = nutzlast(db, "BTC", jetzt)
        txt = text(db, ("BTC",), jetzt, os.path.join(tmp, "kein_speicher.db"), betrieb=Bl2)
        with _BETRIEB["lock"]:
            _BETRIEB["ts"] = time.time() - DIENST_CACHE_S - 1
        e3 = betrieb_lesen(db, jetzt)
        with _BETRIEB["lock"]:
            _BETRIEB["wert"] = None; _BETRIEB["aus_seit"].clear()
        alle += [N.get("betrieb"), N.get("liqdichte"), N.get("messwerte")]
        ok("Betrieb im Dashboard: Die Abfrage der Dienste gilt 30 Sekunden (zwei Aufrufe liefern denselben Stand, danach wird neu gefragt); "
           "die Antwort von /cockpit trägt die Lampe „betrieb“ mit drei Zeilen und die Karte „liqdichte“ -- auf diesem Rechner mit dem, "
           "was hier prüfbar ist, ohne Absturz",
           e1 is e2 and e3 is not e1 and DIENST_CACHE_S == 30 and isinstance(N.get("betrieb"), dict)
           and N["betrieb"]["zustand"] in ("aus", "hinweis", "warnung", "grau") and [z_["key"] for z_ in N["betrieb"]["zeilen"]] == ["dienste", "api", "backup"]
           and "= 95 % des Limits" in zs(N["betrieb"])["api"]["text"] and isinstance(N.get("liqdichte"), dict) and "ok" in N["liqdichte"]
           and [x["key"] for x in N["messwerte"]][-2:] == ["funding_hl", "taker_var"],
           f"Betrieb hier: {(N.get('betrieb') or {}).get('wort')} ({[z_.get('text') for z_ in (N.get('betrieb') or {}).get('zeilen') or []][:1]})")
        nm = {x["key"]: x for x in N["messwerte"]}
        for k_ in ("funding_hl", "taker_var"):
            nm.setdefault(k_, {"wert": "fehlt", "text": "", "basis": "", "fehlt": "", "note": ""})
        ok("Cockpit liest die neuen Quellen aus der Datenbank des Recorders (Antwort von /cockpit auf der temporären Datenbank): Funding "
           "mit Wert und dem Grund für das fehlende Perzentil (72 Stunden Verlauf), Taker-Varianz ohne 10-s-Daten mit dem Grund, "
           "Liquidationsdichte mit dem Stand des Schnappschusses und -- weil diese Datenbank keinen Kurs hat -- dem Grund statt der Balken, "
           "dazu der Satz zum Magnet-Test; die Textfassung (Debug 143) trägt dieselben Zeilen und die Betriebslampe ohne Wartezeit",
           nm["funding_hl"]["wert"] == 0.0 and nm["funding_hl"]["text"] == "+0,0000 %/h · +0,0 % p. a." and nm["funding_hl"]["basis"] == "Perzentil ab 14 Tagen Verlauf (bisher 2)"
           and nm["taker_var"]["wert"] is None and nm["taker_var"]["fehlt"].startswith("zu wenige 10-s-Daten") and nm["taker_var"]["note"] == TAKER_NOTE
           and N["liqdichte"]["ok"] is False and N["liqdichte"]["stand"] == neu_ts and N["liqdichte"]["fehlt"] == ["Ohne frischen Kurs keine Abstände."]
           and N["liqdichte"]["magnet"].startswith(("Ob der Kurs solche Cluster anzieht, prüft der Magnet-Test (Debug 51).", "Magnet-Test (Debug 51, Stand "))
           and "   Messwert Funding (Hyperliquid)" in txt and "Perzentil — (live; " in txt and "; Perzentil ab 14 Tagen Verlauf (bisher 2))" in txt
           and "   Messwert Varianz des Taker-Flusses" in txt and "(kein Wert: zu wenige 10-s-Daten" in txt
           and "   Liquidationsdichte: kein Wert -- Ohne frischen Kurs keine Abstände." in txt
           and "Ob der Kurs solche Cluster anzieht, prüft der Magnet-Test (Debug 51). Der Prognosespeicher fehlt noch." not in txt
           and f"\nMesswerte: {BELEG_MESSWERT} Taker-Varianz: {TAKER_NOTE}\n" in txt
           and "\nBetrieb: Warnung (Dienst läuft nicht: binance, watchdog; API-Gewicht; Backup alt) · Stand " in txt
           and "\n   Dienste      Warnung      2 von 4 eingerichteten laufen · läuft nicht: hl-binance (failed), hl-watchdog (unbekannt)\n" in txt
           and "\n   In der Pille der Seite stehen dazu die Hinweise des Abschnitts System" in txt and txt.count("\nBetrieb: ") == 1,
           f"{nm['funding_hl']['text']} · {nm['funding_hl']['basis']} | {N['liqdichte']['fehlt']}")
        # ---- Taker-Varianz: dieselbe Zahl wie die Prognose, auf 10-s-Daten um die echte Uhrzeit (das Modul rechnet mit der Uhr des Rechners)
        import hl_indikatoren as IND
        import random as _rnd
        db2 = os.path.join(tmp, "t.db"); c = sqlite3.connect(db2)
        c.execute("CREATE TABLE bars10 (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, vol_buy REAL, vol_sell REAL, trades INTEGER, "
                  "n_liq INTEGER, liq_notional REAL, max_sz REAL, PRIMARY KEY (ts, coin)) WITHOUT ROWID")
        echt = int(time.time()); h0 = echt // 3600 * 3600; rn = _rnd.Random(108); z10 = []
        for coin_, letzte in (("TQ1", 0.02), ("TL1", 9.0)):                               # letzte volle Stunde: sehr ruhig bzw. sehr lebhaft
            t_ = h0 - 8 * TAG
            while t_ < h0 + 3600:                                                     # auch die laufende Stunde: die Probe hängt nicht an der vollen Stunde
                sk = letzte if t_ >= h0 - 3600 else 0.5 + (((t_ // 3600) * 7919) % 100) / 100.0
                z10.append((t_, coin_, 100.0, 100.0, 100.0, 100.0, abs(rn.gauss(0, 1)) * sk, abs(rn.gauss(0, 1)) * sk, 3, 0, 0.0, 0.0)); t_ += 10
        z10 += [(h0 - 3600 + 10 * i, "TK1", 100.0, 100.0, 100.0, 100.0, 1.0, 2.0, 3, 0, 0.0, 0.0) for i in range(360)]      # nur eine Stunde Verlauf
        c.executemany("INSERT INTO bars10 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", z10); c.commit(); c.close()
        ro = _ro(db2)
        try:
            echt_fn = IND.varianz_kompression; tage_gefragt: list = []
            IND.varianz_kompression = lambda con_, coin_, days=30: (tage_gefragt.append(days), echt_fn(con_, coin_, days))[1]
            try:
                tq, tl_, tk = taker_lesen(ro, "TQ1"), taker_lesen(ro, "TL1"), taker_lesen(ro, "TK1")
            finally:
                IND.varianz_kompression = echt_fn
            iq, il = IND.varianz_kompression(ro, "TQ1", TAKER_TAGE), IND.varianz_kompression(ro, "TL1", TAKER_TAGE)
        finally:
            ro.close()
            for k_ in [k_ for k_ in IND._VAR_CACHE if k_[0] in ("TQ1", "TL1", "TK1")]:
                IND._VAR_CACHE.pop(k_, None)
        ok("Vertrag Taker-Varianz: dieselbe Zahl wie in der Prognose (hl_indikatoren.varianz_kompression, 30 Tage) -- eine sehr ruhige letzte "
           "Stunde liegt im untersten Zehntel, eine sehr lebhafte ganz oben; der Stand ist das Ende der letzten vollen Stunde; mit nur einer "
           "Stunde Verlauf gibt es keinen Wert, sondern den Grund",
           iq is not None and il is not None and tq.get("pz") == iq["pct"] and tl_.get("pz") == il["pct"] and tq["pz"] < TAKER_DEZIL and tl_["pz"] > 0.9
           and tq["ts"] in (h0, h0 + 3600) and taker_zeile(tq)["im_dezil"] is True and taker_zeile(tl_)["im_dezil"] is False
           and (iq["kompression"] > 0) and il["kompression"] == 0 and "pz" not in tk and tk["fehlt"][0].startswith("zu wenige 10-s-Daten")
           and taker_lesen(None, "BTC")["fehlt"] == ["Datenbank des Recorders fehlt"] and TAKER_TAGE == 30 and tage_gefragt == [30, 30, 30],
           f"ruhig {tq.get('pz')}, lebhaft {tl_.get('pz')}")
    finally:
        _sh.rmtree(tmp, ignore_errors=True)
    # ---- Verträge: Schwellen und Namen stimmen mit den Modulen überein, die sie festlegen
    import dataclasses
    import inspect
    import re as _re
    import hl_chartbild as CB
    import hl_recorder as RC
    import hl_watchdog as WD
    wq = inspect.getsource(WD.run_checks)
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "install.py"), encoding="utf-8") as f:
        inst = f.read()
    einheiten = sorted(set(_re.findall(r'\(out / "(hl-[a-z]+)\.service"\)', inst)))
    felder = {f_.name: f_.default for f_ in dataclasses.fields(RC.Settings)}
    mem = sqlite3.connect(":memory:")
    try:
        mem.executescript(RC.SCHEMA)
        spalten = {t_: [r_[1] for r_ in mem.execute(f"PRAGMA table_info({t_})")] for t_ in ("ctx_bars", "heatmap", "coverage", "snapshot_meta", "meta", "bars10")}
    finally:
        mem.close()
    ok("Vertrag Betrieb und Recorder: die Schwelle des API-Gewichts ist die Warnschwelle des Wächters (93 % des harten Limits, dort „pct < 93“); "
       "der Wächter fragt die Dienste mit is-enabled und is-active wie das Cockpit; die sechs Dienste sind genau die aus install.py; "
       "Altersgrenze der Positionen 60 Minuten und Schnappschuss alle 10 Minuten wie im Recorder; die gelesenen Spalten gibt es im Schema; "
       "die Frische der Heatmap ist die des Chartbilds",
       "OK if pct < 93 else" in wq and "pct = used / limit * 100" in wq and '"is-enabled"' in wq and '"is-active"' in wq and '("enabled", "enabled-runtime")' in wq
       and einheiten == sorted(DIENSTE) and len(DIENSTE) == 6 and felder.get("max_pos_age") == LIQ_ALTER_S and felder.get("snapshot_sec") == 600
       and FRISCH_LIQ_S >= 2 * felder.get("snapshot_sec") and FRISCH_API_S >= 2 * felder.get("snapshot_sec") and abs(felder.get("bucket_pct") - LIQ_STUFE / 2) < 1e-12
       and {"ts", "coin", "funding"} <= set(spalten["ctx_bars"]) and {"ts", "coin", "bucket_px", "side", "notional", "n_pos"} <= set(spalten["heatmap"])
       and {"ts", "coin", "ratio", "tracked_size", "oi"} <= set(spalten["coverage"]) and {"ts", "n_positions", "n_stale_dropped", "age_median"} <= set(spalten["snapshot_meta"])
       and spalten["meta"] == ["k", "v"] and {"ts", "coin", "close", "vol_buy", "vol_sell"} <= set(spalten["bars10"])
       and FRISCH_LIQ_S == CB.FRISCH["heatmap"] and LIQ_BREITE == 0.03 and LIQ_STUFE == 0.005 and FUNDING_TAGE == 90,
       f"Dienste {einheiten}; max_pos_age {felder.get('max_pos_age')}, Raster {felder.get('bucket_pct')}")
    return alle


def _vertrag(ok) -> None:
    """
    Die Quellen mit den echten Funktionen der Module auf deren Demo-Datenbanken lesen (hl_chartbild._demo_dbs über
    hl_ausblick._demo_umgebung): Prognose des Ausblicks gerechnet, Volatilität mit Tageswerten und einer von Hand eingetragenen
    Prognosezeile (über hl_volatil._prognose_zeilen, also in der echten Form), Positionierung aus hebel.db. Dann nutzlast() gegen die
    Zahlen der Module selbst. Lehre aus 23.97: Eine Probe auf einer selbst erdachten Welt beweist die Form der echten nicht.
    """
    import shutil
    import tempfile
    import hl_ausblick as AU
    import hl_chartbild as CB
    import hl_volatil as VL
    tmp = tempfile.mkdtemp(prefix="cockpit_vertrag_")
    alt_env = {k: os.environ.get(k) for k in ("HL_AKTIEN_DB",)}
    U = None
    try:
        jetzt = int(time.time()) // AU.BAR * AU.BAR - 600
        U = AU._demo_umgebung(os.path.join(tmp, "voll"), jetzt, tage=800, kurz={"HYPE": 520})
        db = U["pf"]["haupt"]
        AU.prognose(db, jetzt=jetzt, live_fn=lambda d_, c_: {})
        vc = VL.verbinden(VL.pfad(db))
        try:
            VL.tage_aktualisieren(vc, VL.quellen(db)["swing"], jetzt)
            heute = jetzt // TAG
            bis = vc.execute("SELECT MAX(tag) FROM vl_tag WHERE coin='BTC'").fetchone()[0]
            v_tag = (52.0 / 100.0) ** 2 / 365.0                                    # 52 % p. a. als Tagesvarianz
            pr = [{"woche": k, "mu": math.log(v_tag), "sigma": 0.3, "sigma_quelle": "probe", "sigma_fenster": 0.3, "v": v_tag * (1 + 0.01 * k),
                   "v_b0": v_tag, "v_b365": v_tag, "v_ewma": v_tag, "schwelle": v_tag * 2, "p": 0.2, "p_grund": 0.2, "p_markov": 0.2, "zustand": 0,
                   "x": [0.0], "pfad": [v_tag] * 7} for k in (1, 2, 3, 4)]
            with VL.schreiben(vc):
                VL._einfuegen(vc, [], VL._prognose_zeilen("BTC", int(bis), "M", pr, "tag", jetzt))
            NV = VL._ohne_nan(VL.nutzlast(vc, "chart", "BTC", jetzt))
        finally:
            vc.close()
        N = nutzlast(db, "BTC", jetzt)
        NA = AU.nutzlast(db, "BTC", None)
        P = NA["prognose"]
        ok("Vertrag Ausblick: Spanne des Cockpits gleich hl_ausblick.nutzlast (alle sieben Quantile, drei Horizonte), Anker und Kurs am Anker",
           all(N["spanne"]["h"][h]["q"] == [float(x) for x in P["spannen"][h]["q"]] for h in ("7", "14", "28")) and N["spanne"]["anker"] == P["anker"]
           and N["spanne"]["p0"] == P["p0"] and N["spanne"]["frisch"] is True,
           f"7 T 80 %: {_px(N['spanne']['h']['7']['q'][1])}–{_px(N['spanne']['h']['7']['q'][5])}; Vermerk {N['spanne']['h']['7']['vermerk']}")
        # S1 in der Form, die hl_ausblick.urteil_s1 selbst erzeugt -- aus zwei kleinen Welten: (1) Vorsprung deutlich, das Band von
        # BTC aber zu weit (90 %): das Urteil des Moduls lautet „besteht nicht“ (der Fall des Pi vom 11.11.); (2) BTC trifft 80 %.
        import numpy as np
        def s1_welt(btc_treffer_jede: int) -> dict:
            n_t = 400; tage_ = np.arange(n_t); teile = {k_: [] for k_ in ("h", "stunde", "b0", "b1", "tau", "coin", "d80", "d50", "d90", "pit")}
            for h_ in AU.H_ZIEL:
                for c_, jede in (("BTC", btc_treffer_jede), ("ETH", 5)):
                    teile["h"].append(np.full(n_t, h_)); teile["stunde"].append(np.zeros(n_t, dtype=int)); teile["tau"].append(tage_ * TAG)
                    teile["coin"].append(np.array([c_] * n_t)); teile["b0"].append(0.050 + 0.002 * np.sin(tage_ * 0.7))
                    teile["b1"].append(0.052 + 0.002 * np.sin(tage_ * 0.7 + 0.3))
                    teile["d80"].append((tage_ % jede != 0).astype(float)); teile["d50"].append((tage_ % 2 == 0).astype(float))
                    teile["d90"].append((tage_ % 10 != 0).astype(float)); teile["pit"].append((tage_ % 100) / 100.0 + 0.005)
            return AU.urteil_s1({k_: np.concatenate(v_) for k_, v_ in teile.items()})
        S1w, S1g = s1_welt(10), s1_welt(5)                               # BTC trifft 90 % (zu weit) bzw. 80 %
        PRw = AU.s1_pruef(S1w); PRg = AU.s1_pruef(S1g)
        kurz_ = {"": "", " -- zu eng (Soll 80 %)": " (zu eng)", " -- zu weit (Soll 80 %)": " (zu weit)"}
        Pw = {"anker": jetzt, "p0": 100.0, "spannen": {h_: {"q": [80.0, 85.0, 93.0, 100.0, 107.0, 115.0, 120.0]} for h_ in ("7", "14", "28")}}
        spw = spanne_bauen("BTC", Pw, {"s1": S1w}, 100.0, jetzt); spg = spanne_bauen("BTC", Pw, {"s1": S1g}, 100.0, jetzt)
        spe = spanne_bauen("ETH", Pw, {"s1": S1w}, 100.0, jetzt)
        soll_w = {h_: f"traf {AU._de(PRw['BTC'][h_]['d80'] * 100, 0)} %" + kurz_[AU.deckung_wertung(PRw["BTC"][h_])] for h_ in ("7", "14", "28")}
        satz_w = satz_bauen("BTC", spw)["text"]
        ok("Vertrag Ausblick, Form von hl_ausblick.urteil_s1: Vorsprung deutlich, Band von BTC zu weit (90 %) -> das Modul urteilt „besteht "
           "nicht“; das Cockpit zeigt trotzdem „traf 90 % (zu weit)“ und „Vorsprung belegt“ und nennt im Beleg Urteil und Grund; Vermerk "
           "und Kernsatz mit der Wertung von hl_ausblick.deckung_wertung; trifft BTC 80 %, lautet der Beleg „besteht.“",
           S1w["h"]["7"]["besteht"] is False and S1w["h"]["7"]["p"] < 0.05 and S1w["h"]["7"]["gewinn_rel"] > 0 and S1g["h"]["7"]["besteht"] is True
           and {h_: spw["h"][h_]["vermerk"] for h_ in ("7", "14", "28")} == soll_w and soll_w["7"] == "traf 90 % (zu weit)"
           and spw["h"]["7"]["vorsprung"] == "belegt" and "zugleich): besteht nicht -- das Band von BTC ist zu weit (90,0 % ± " in spw["beleg"]
           and spe["h"]["7"]["vermerk"] == "traf 80 %" and spg["h"]["7"]["vermerk"] == "traf 80 %" and spg["beleg"].endswith("zugleich): besteht.")
           and satz_w.endswith(f"Im Rückblick traf dieses Band {AU._de(PRw['BTC']['7']['d80'] * 100, 0)} %{AU.deckung_wertung(PRw['BTC']['7'])}.")
           and satz_w.endswith("90 % -- zu weit (Soll 80 %).") and N["spanne"]["h"]["7"]["vermerk"] == "Rückblick steht aus",
           f"Modul: besteht {S1w['h']['7']['besteht']} (p {S1w['h']['7']['p']:.4f}, Gewinn {S1w['h']['7']['gewinn_rel']:+.3f}); Cockpit: "
           f"{spw['h']['7']['vermerk']} · Vorsprung {spw['h']['7']['vorsprung']}")
        px_cockpit = {round(n["px"], 6) for n in N["levels"]["oben"] + N["levels"]["unten"]}
        px_ausblick = {round(float(n["px"]), 6): n for n in P["niveaus"] if n.get("p")}
        gleich_p = all(abs(n["p7"] - px_ausblick[round(n["px"], 6)]["p"]["7"][0]) < 1e-12 and abs(n["p14"] - px_ausblick[round(n["px"], 6)]["p"]["14"][0]) < 1e-12
                       for n in N["levels"]["oben"] + N["levels"]["unten"])
        ok("Vertrag Ausblick: jedes Level des Cockpits ist ein Niveau des Ausblicks mit denselben Wahrscheinlichkeiten (1 und 2 Wochen)",
           px_cockpit and px_cockpit <= set(px_ausblick) and gleich_p, f"{len(px_cockpit)} Levels von {len(px_ausblick)} Niveaus mit Wahrscheinlichkeit")
        try:
            # ---- Kurs-Rechner (23.105, U245 Stufe C2): Tage aus der Rechnung des Ausblicks dieser Demo-Welt
            import hl_anker
            import hl_kaskade as KK
            import hl_magnet as MG
            store_r = os.path.join(tmp, "prognosen_rechner.db")
            GR0 = rechner_grundlage(db, "BTC", jetzt, store_r)
            ac_r = AU.lesen(AU.ausblick_pfad(db))
            try:
                Lb_r = AU.lauf_lesen(ac_r, "BTC")
            finally:
                ac_r.close()
            kurs_r = GR0["kurs"] or 1.0
            niv_r = [n for n in P["niveaus"] if n.get("p")][:RECHNER_MAX_KURSE]
            px_r = [float(kurs_r * n["px"] / P["p0"]) for n in niv_r]              # derselbe Abstand, vom jetzigen Kurs aus
            RN = rechner_nutzlast(db, "BTC", px_r, jetzt, store_r)
            # Im Raster höchstens 0,5 Punkte + 1/N; jenseits des Rasters zeigt der Rechner die Schranke (0,5 % oder 99,5 %), die volle Rechnung
            # liegt dann jenseits davon -- auch das sind höchstens 0,5 Punkte + 1/N
            tol_rn = 0.005 + 1.0 / max(int((Lb_r or {}).get("n") or 0), 1) + 1e-9
            abw_rn = [abs((z["p"][i_] if z["p"][i_] is not None else 9.0) - n["p"][h_][0]) for z, n in zip(RN["zeilen"], niv_r) for i_, h_ in ((2, "7"), (3, "14"))]
            RNJ = json.loads(rechner_json(db, "BTC", ",".join(repr(x_) for x_ in px_r) + ";abc", jetzt, store_r).decode("utf-8"))
            G_alt2 = rechner_grundlage(db, "BTC", int(P["anker"]) + FRISCH_AUSBLICK_S + 1, store_r)
            G_noch = rechner_grundlage(db, "BTC", int(P["anker"]) + FRISCH_AUSBLICK_S, store_r)
            t_r = text(db, coins=("BTC",), jetzt=jetzt, store=store_r)
            zl_r = [z_ for z_ in t_r.splitlines() if z_.startswith("   Kurs-Rechner")]
            ok("Vertrag Kurs-Rechner, Tage (hl_ausblick.prognose auf der Demo-Welt): Die Prognose legt die Verteilung des laufenden Hochs und "
               "Tiefs ab (nicht in ihrer Antwort), der Rechner liest sie -- für jedes Niveau der Rechnung, im selben Abstand vom jetzigen Kurs, "
               "dieselbe Wahrscheinlichkeit wie hl_ausblick (7 und 14 Tage, auf höchstens 0,5 Punkte + 1/N); der Beleg nennt den Anker; "
               "/cockpit/rechner liefert dasselbe als JSON und zählt Unlesbares; ohne Prognosespeicher und ohne genug Minutenkerzen bleiben die "
               "Stunden leer und nennen den Grund; eine Rechnung des Ausblicks, die älter als 2 Tage ist, gilt nicht (genau 2 Tage: noch ja); "
               "der Debug-Text zeigt acht Beispielkurse, den Grund, den Beleg und einmal den allgemeinen Satz",
               Lb_r is not None and GR0["lauf"] == Lb_r and Lb_r["anker"] == P["anker"] and "lauf" not in P and GR0["kurs_frisch"] and kurs_r > 1
               and len(niv_r) >= 6 and len(abw_rn) == 2 * len(niv_r) and max(abw_rn) <= tol_rn and int(Lb_r.get("n") or 0) >= 100
               and [f_[3] for f_ in RN["fristen"]] == [False, False, True, True] and GR0["sig4"] is None and "fehlen Minutenkerzen" in GR0["sig4_fehlt"]
               and RN["fehlt"] == ["1 Stunde und 4 Stunden: Der Prognosespeicher fehlt noch."] and not os.path.exists(store_r)
               and len(RN["belege"]) == 1 and f"Rechnung des Ausblicks vom {_datum(P['anker'])}, angelegt am jetzigen Kurs." in RN["belege"][0]
               and RN["belege"][0].endswith("noch nicht geprüft.")
               and RNJ["zeilen"] == RN["zeilen"] and RNJ["hinweise"] == ["1 Angabe der Anfrage nicht lesbar."] and RNJ["kurs"] == kurs_r
               and G_alt2["lauf"] is None and "älter als 2 Tage" in (G_alt2["lauf_fehlt"] or "") and G_noch["lauf"] == Lb_r
               and len(zl_r) == 1 + 8 + 1 + 1 and zl_r[0].startswith("   Kurs-Rechner (vom jetzigen Kurs ") and "  +10,0 %  " in zl_r[8] and "  −10,0 %  " in zl_r[1]
               and " −1,0 %  " in zl_r[4] and " +1,0 %  " in zl_r[5] and not any("1,00 %" in z_ for z_ in zl_r)
               and zl_r[9] == "   Kurs-Rechner fehlt: 1 Stunde und 4 Stunden: Der Prognosespeicher fehlt noch." and zl_r[10].startswith("   Kurs-Rechner Beleg: 7 Tage und 14 Tage:")
               and t_r.count("\nKurs-Rechner: " + RECHNER_BELEG_ALLG) == 1 and t_r.splitlines()[-1].startswith("Aktien-Regel des Ausblicks:"),
               f"{len(niv_r)} Niveaus, größte Abweichung {max(abw_rn):.4f}; {RN['fehlt']}; {zl_r[8][:80] if len(zl_r) > 8 else zl_r}")
            # ---- Kurs-Rechner, Stunden: Probe-Markt der Kaskaden-Gleichung (30 Tage Minutenkerzen), Nullmodell vom Magnet-Test selbst gerechnet
            m_db = os.path.join(tmp, "markt", "hl_liq.db"); os.makedirs(os.path.dirname(m_db))
            con_m, now_m = KK._probe_markt(m_db, 5, tage=30, y_wahr=0.0, kl_median=0.01)
            try:
                MG.kalibrieren(con_m, "BTC", now_m, path=store_r)
                sig4_m = hl_anker.Markt(con_m, "BTC", now_m - TAG, now_m).sigma(now_m)
                px_m = float(con_m.execute("SELECT close FROM bars WHERE coin='BTC' ORDER BY ts DESC LIMIT 1").fetchone()[0])
            finally:
                con_m.close()
            ML = MG.modell_laden("BTC", store_r) or {"h": {"1": {}, "4": {}}}
            vor_r = open(store_r, "rb").read()
            GM = rechner_grundlage(m_db, "BTC", now_m, store_r)
            pk_se = []; pk_oof = []; pk_gleich = []; RP = {}
            for i_, (h_, key_) in enumerate(((1, "1"), (4, "4"))):
                sig_h = (sig4_m or 0.0) * math.sqrt(h_ / 4.0); mh = ML["h"][key_]
                RP = rechner_nutzlast(m_db, "BTC", [px_m * math.exp(x_ * sig_h) for x_ in MG.ZUFALL_X], now_m, store_r)
                for z_, (x_, p_oof, y_, se_) in zip(RP["zeilen"], mh.get("zufall") or []):
                    pk_se.append(abs(z_["p"][i_] - y_) / se_); pk_oof.append(abs(z_["p"][i_] - p_oof))
                    pk_gleich.append(abs(z_["p"][i_] - KK.p_ueber(x_ * sig_h, mh["c0"], sig_h, mh["tau0"])))
            unveraendert_r = open(store_r, "rb").read() == vor_r
            zf_ok = {k_: sum(1 for _x, p_, y_, se_ in ML["h"][h_].get("zufall") or [] if se_ and abs(y_ - p_) <= 2 * se_) for k_, h_ in (("1h", "1"), ("4h", "4"))}
            ok("Vertrag Kurs-Rechner, Stunden (Probe-Markt, Nullmodell von hl_magnet.kalibrieren gerechnet): Der Rechner liest c, τ und die Probe "
               "an Zufallsniveaus wie hl_magnet.modell_laden, die Schwankung über 4 Stunden wie hl_anker.Markt und den Kurs aus der jüngsten "
               "Minutenkerze; seine Zahl ist hl_kaskade.p_ueber. Positivkontrolle (KONZEPT_Cockpit 6 Punkt 6): An den acht Zufallsabständen "
               "trifft der Rechner die im Markt eingetretene Berührquote auf höchstens 2,5 Standardfehler und die Vorhersage des Tests auf "
               "höchstens 2 Punkte -- über 1 und über 4 Stunden; der Prognosespeicher wird dabei nicht verändert",
               sig4_m and GM["sig4"] == sig4_m and GM["kurs"] == px_m and GM["kurs_frisch"] and set(GM["kurz"]) == {"1h", "4h"}
               and all(GM["kurz"][k_]["c"] == ML["h"][h_]["c0"] and GM["kurz"][k_]["tau"] == ML["h"][h_]["tau0"] and GM["kurz"][k_]["ts"] == ML["ts"]
                       and GM["kurz"][k_]["zufall_n"] == 8 and GM["kurz"][k_]["zufall_ok"] == zf_ok[k_] for k_, h_ in (("1h", "1"), ("4h", "4")))
               and GM["sigma_geprueft"] == max(MG.ZUFALL_X) == RECHNER_SIGMA_GEPRUEFT and len(pk_se) == 16 and max(pk_gleich) < 1e-12
               and max(pk_se) <= 2.5 and max(pk_oof) <= 0.02 and unveraendert_r
               and RP.get("fehlt") == ["7 Tage und 14 Tage: Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."]
               and "(über 4 Stunden " + _pc(sig4_m, 2) + ")" in RP["belege"][0] and f"über 1 h {zf_ok['1h']} von 8, über 4 h {zf_ok['4h']} von 8 Abständen" in RP["belege"][0],
               f"σ über 4 h {_pc(sig4_m, 2)}; c {GM['kurz'].get('1h', {}).get('c')} / {GM['kurz'].get('4h', {}).get('c')}; gegen die Berührquote höchstens "
               f"{max(pk_se or [9]):.2f} Standardfehler, gegen die Vorhersage höchstens {max(pk_oof or [9]) * 100:.1f} Punkte")
            echt_r = int(time.time())
            alt_m = _magnet_lesen("BTC", echt_r + MG.MODELL_ALTER + 60, store_r); frisch_m = _magnet_lesen("BTC", echt_r + MG.MODELL_ALTER - 60, store_r)
            MG.F.learned_save("BTC", "magnet", dict(ML, version=MG.VERSION + 100), path=store_r)
            fremd_m = _magnet_lesen("BTC", now_m, store_r); fremd_ml = MG.modell_laden("BTC", store_r)
            MG.F.learned_save("BTC", "magnet", {"version": MG.VERSION, "coin": "BTC", "ts": now_m, "fehler": "ValueError: Probe"}, path=store_r)
            fehler_m = _magnet_lesen("BTC", now_m, store_r)
            MG.F.learned_save("BTC", "magnet", dict(ML, h=dict(ML["h"], **{"4": {"n_bloecke": 72, "zu_wenig": True}})), path=store_r)
            G_zw = rechner_grundlage(m_db, "BTC", now_m, store_r)
            # „zu wenig“ gilt auch, wenn die Frist trotzdem Werte trägt; die Probe an Zufallsniveaus zählt wie hl_magnet.stand_text:
            # innerhalb von 2 Standardfehlern, Einträge ohne Standardfehler oder ohne vier Zahlen zählen nicht
            zf_hand = [[1.0, 0.20, 0.25, 0.02], [2.0, 0.05, 0.05, 0.01], [3.0, 0.01, 0.031, 0.01], [0.5, 0.5, 0.5, 0.0], ["x", 1, 2, 3], [1.0, 0.2]]
            MG.F.learned_save("BTC", "magnet", dict(ML, h={"1": dict(ML["h"]["1"], zufall=zf_hand),
                                                           "4": dict(ML["h"]["4"], zu_wenig=True, n_bloecke=72)}), path=store_r)
            G_zw2 = rechner_grundlage(m_db, "BTC", now_m, store_r)
            kts_m = int(GM["kurs_ts"] or 0)                                     # Frische des Kurses: bis 5 Minuten, danach rechnet der Rechner nicht
            G_kf = rechner_grundlage(m_db, "BTC", kts_m + FRISCH_KURS_S, store_r); G_ka = rechner_grundlage(m_db, "BTC", kts_m + FRISCH_KURS_S + 1, store_r)
            R_ka = rechner_nutzlast(m_db, "BTC", [px_m * 1.001], kts_m + FRISCH_KURS_S + 1, store_r)
            MG.F.learned_save("BTC", "magnet", ML, path=store_r)
            kein_m = _magnet_lesen("ETH", now_m, store_r); ohne_m = _magnet_lesen("BTC", now_m, os.path.join(tmp, "gibt_es_nicht.db"))
            ok("Vertrag Kurs-Rechner, Nullmodell lesen: älter als 3 Tage (gezählt ab dem Speichern) gilt nicht, eine Minute davor schon; eine "
               "andere Modellversion gilt nicht (wie hl_magnet.modell_laden); ein gemeldeter Fehler des Tests steht als Grund da; hat eine Frist zu "
               "wenige Blöcke, fehlt nur sie (auch wenn sie trotzdem Werte trägt); die Probe an Zufallsniveaus zählt innerhalb von 2 "
               "Standardfehlern, wie im Magnet-Test; ein Coin ohne Rechnung und ein fehlender Prognosespeicher nennen den Grund -- der fehlende "
               "Speicher wird nicht angelegt; ein Kurs gilt bis 5 Minuten als frisch, danach rechnet der Rechner nicht",
               alt_m[0] is None and "älter als 3 Tage" in alt_m[1] and frisch_m == (ML, "")
               and fremd_m == (None, "Die Rechnung des Magnet-Tests stammt aus einer anderen Modellversion.") and fremd_ml is None
               and fehler_m == (None, "Der Magnet-Test meldet einen Fehler: ValueError: Probe")
               and set(G_zw["kurz"]) == {"1h"} and G_zw["kurz_fehlt"] == {"4h": "Für das Nullmodell über 4 Stunden hat der Magnet-Test zu wenige Blöcke (72)."}
               and set(G_zw2["kurz"]) == {"1h"} and G_zw2["kurz_fehlt"] == G_zw["kurz_fehlt"] and _zahl(ML["h"]["4"].get("c0")) is not None
               and (G_zw2["kurz"]["1h"]["zufall_n"], G_zw2["kurz"]["1h"]["zufall_ok"]) == (3, 1)
               and G_kf["kurs_frisch"] is True and G_kf["sig4"] and G_ka["kurs_frisch"] is False and G_ka["sig4"] is None and G_ka["kurs"] == px_m
               and R_ka["zeilen"][0]["grund"] == "Kein frischer Kurs." and R_ka["zeilen"][0]["p"] == [None] * 4
               and R_ka["fehlt"] == [f"Der Kurs ist nicht frisch (Stand {_datum(kts_m)}) -- der Rechner rechnet nur vom jetzigen Kurs."]
               and kein_m[0] is None and kein_m[1].startswith("Der Magnet-Test hat für ETH noch nicht gerechnet.") and ohne_m == (None, "Der Prognosespeicher fehlt noch.")
               and not os.path.exists(os.path.join(tmp, "gibt_es_nicht.db")), f"{alt_m[1][:70]} | {fehler_m[1]} | {G_zw['kurz_fehlt']}")
        except Exception as e_r:                            # eine Ausnahme ist ein Fehler der Probe, kein Abbruch des Selbsttests
            ok("Vertrag Kurs-Rechner: die Proben laufen ohne Ausnahme durch", False, f"{type(e_r).__name__}: {e_r}")
        w1 = NV["prognose"]["wochen"][0] if NV.get("prognose") else {}
        s = N["schwankung"]
        ok("Vertrag Volatilität: erwartete Schwankung gleich Woche 1 von hl_volatil.nutzlast, realisierte 7 und 30 Tage gleich dem letzten "
           "Wert der Reihen, Modelltext gleich",
           NV.get("prognose") and s["erwartet"] == w1.get("mitte") and s["real7"] == NV["reihe"]["vi7"][-1] and s["real30"] == NV["reihe"]["vi30"][-1]
           and s["modell"] == NV["prognose"]["modell_text"] and s["pz"] is not None,
           f"erwartet {s['erwartet']} (Abschnitt {w1.get('mitte')}), real 7 T {s['real7']} ({NV['reihe']['vi7'][-1]}), Perzentil {s['pz']}")
        con = CB._ro(db)
        try:
            Lg = CB.positionierung("BTC", db, con, jetzt)
        finally:
            con.close()
        m = {x["key"]: x for x in N["messwerte"]}
        hebel = N["lampen"][0]
        ok("Vertrag Chartbild: Kontenquote, Open Interest und ihre Perzentile gleich hl_chartbild.positionierung; die Hebel-Lampe rechnet mit "
           "derselben Zahl und der Schwelle des Chartbilds; XMR und PAXG ohne Absturz",
           abs(m["konten"]["wert"] - float(Lg["konten"]["wert"])) < 1e-12 and abs(m["konten"]["pz"] - float(Lg["konten"]["pz"])) < 1e-12
           and abs(m["oi"]["pz"] - float(Lg["oi"]["pz"])) < 1e-12 and abs(hebel["zahl"] - float(Lg["konten"]["wert"])) < 1e-12
           and (hebel["zustand"] == "hinweis") == (float(Lg["konten"]["wert"]) >= CB.KONTEN_SCHWELLE)
           and nutzlast(db, "XMR", jetzt)["ok"] and nutzlast(db, "PAXG", jetzt)["lampen"][0]["zustand"] == "grau",
           f"Konten {m['konten']['text']} (Perzentil {m['konten']['pz']:.3f}), Lampe {hebel['zustand']}")
        ok("Vertrag Streifen: sechs Coins in fester Reihenfolge, je mit Spanne und fünf Lampen; der gewählte Coin gleich dem vollen Cockpit",
           [e["coin"] for e in N["streifen"]] == list(COINS) and all(len(e["lampen"]) == 5 and e["lo"] is not None for e in N["streifen"])
           and N["streifen"][0]["lampen"] == [l["zustand"] for l in N["lampen"]],
           " · ".join(f"{e['coin']} {_pc(e['lo'], 0, True)}/{_pc(e['hi'], 0, True)}" for e in N["streifen"]))
        import hl_makro as MK
        mc = sqlite3.connect(U["pf"]["makro"], isolation_level=None)       # hl_makro.termine_schreiben öffnet seine Transaktion selbst
        try:
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('release:CPIAUCSL', ?)", (json.dumps({"id": 10}),))
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('release:UNRATE', ?)", (json.dumps({"id": 50}),))
            mc.execute("INSERT OR REPLACE INTO mk_meta VALUES ('datentage:stand', ?)",
                       (json.dumps({"erzeugt": jetzt - 5 * TAG, "von": "2020-01-01", "H1": {"belegt": True, "abs_verh": 2.45}, "H2": {"belegt": True, "abs_verh": 1.9}}),))
            tag_cpi = (jetzt // TAG + 1) * TAG; tag_job = (jetzt // TAG + 9) * TAG
            MK.termine_schreiben(mc, 10, [tag_cpi], jetzt); MK.termine_schreiben(mc, 50, [tag_job], jetzt)
        finally:
            mc.close()
        ts_cpi = MK.ny830_utc(tag_cpi)
        G1 = gemeinsam_lesen(db, ts_cpi - 3600); G2 = gemeinsam_lesen(db, ts_cpi + 600); G3 = gemeinsam_lesen(db, ts_cpi - 3 * TAG)
        l1 = lampe_termin(G1["termine"], G1["naechste"], G1["datentag_stand"], ts_cpi - 3600, G1["termine_geladen"])
        l2 = lampe_termin(G2["termine"], G2["naechste"], G2["datentag_stand"], ts_cpi + 600, G2["termine_geladen"])
        l3 = lampe_termin(G3["termine"], G3["naechste"], G3["datentag_stand"], ts_cpi - 3 * TAG, G3["termine_geladen"])
        ok("Vertrag Makro: Termine aus mk_termin (hl_makro.datentag_info und usa_termine) -- eine Stunde vor den Verbraucherpreisen Hinweis mit "
           "der Zeit 8:30 New York, zehn Minuten danach Warnung (Studie belegt), drei Tage davor aus mit dem nächsten Termin",
           l1["zustand"] == "hinweis" and l1["ts"] == ts_cpi and l1["wert"] == "Verbraucherpreise" and l2["zustand"] == "warnung" and l2["ts_ende"] == ts_cpi + 7_200
           and "2,5-mal" in l2["detail"] and l3["zustand"] == "aus" and l3["ts"] == ts_cpi and G1["termine_geladen"] is True,
           f"davor {l1['zustand']} ({_datum(l1.get('ts'))}), danach {l2['zustand']}, drei Tage davor {l3['zustand']} ({l3['wert']})")
        hc = sqlite3.connect(db)
        try:
            for c_, w_ in (("ETH", 2.99), ("ZEC", 3.0)):
                hc.execute("INSERT OR REPLACE INTO bnc_metrics VALUES (?, ?, 'global_ls_account', ?)", (jetzt - 60, c_, w_))
            hc.commit()
        finally:
            hc.close()
        vc = VL.verbinden(VL.pfad(db))
        try:
            bis_e = vc.execute("SELECT MAX(tag) FROM vl_tag WHERE coin='ETH'").fetchone()[0]
            with VL.schreiben(vc):
                VL._einfuegen(vc, [], VL._prognose_zeilen("ETH", int(bis_e) - 10, "M", pr, "tag", jetzt))
        finally:
            vc.close()
        NE = nutzlast(db, "ETH", jetzt); NZ = nutzlast(db, "ZEC", jetzt)
        ok("Vertrag an den Grenzen: Kontenquote 2,99 (frische Zeile in bnc_metrics) -> Hebel aus, 3,00 -> Hinweis; eine zehn Tage alte "
           "Prognose der Schwankung wird nicht gezeigt (dann zählt die realisierte, Lampe neutral)",
           NE["lampen"][0]["zustand"] == "aus" and abs(NE["lampen"][0]["zahl"] - 2.99) < 1e-9 and NZ["lampen"][0]["zustand"] == "hinweis"
           and NE["schwankung"]["erwartet"] is None and NE["schwankung"]["pz_von"].startswith("Realisierte") and NE["lampen"][4]["wort"] == "neutral"
           and any("Keine frische Prognose" in f_ for f_ in NE["schwankung"]["fehlt"]),
           f"ETH {NE['lampen'][0]['wert']} {NE['lampen'][0]['zustand']}, ZEC {NZ['lampen'][0]['wert']} {NZ['lampen'][0]['zustand']}; ETH Schwankung: {NE['schwankung']['fehlt']}")
        t = text(db, jetzt=jetzt)
        ok("Text (Debug-Lauf): je Coin Kurs, Kernsatz, fünf Lampen, Schwankung, Spannen, Stände; am Ende Belege und ob die Aktien-Regel "
           "geprüft wird; ohne Empfehlungswörter",
           all(f"== {c} " in t for c in COINS) and t.count("Lampe Hebel") == 6 and "Spanne  7 T" in t and not [w for w in WORT_VERBOTEN if w in t.lower()]
           and t.count("Stand: Tageswerte bis") >= 5 and "Tagesstand " in t and t.count("\nBelege: ") == 1 and "Konten ≥ 3" in t.split("\nBelege: ")[1]
           and "\nAktien-Regel des Ausblicks: wird NICHT geprüft -- Vom S&P-500-Perp liegen" in t
           and "NICHT FRISCH" not in t.split("== PAXG ")[1] and t.split("== PAXG ")[1].count("(kein Wert)") >= 2 and "grau, nicht aus" in t
           and t.count("   Beleg der Spanne: ") == 6 and t.count(" · Rückblick steht aus") >= 15
           and t.count(" Zeitpunkt: ") == sum(1 for c_ in COINS for l_ in nutzlast(db, c_, jetzt)["lampen"] if l_["key"] == "termin" and l_.get("ts")),
           f"{len(t.splitlines())} Zeilen; {t.splitlines()[-1][:110]}")
        ok("Text (Debug-Lauf) mit Durchschnittslinien (23.110): je Coin die Zeilen der 50- und der 200-Tage-Linie und ihr Stand; am Ende "
           "einmal der Beleg mit dem Prüfstand der Regel aus dem Chartbild und dem Stand der Prüfung als Niveau",
           t.count("   Durchschnitt 50-Tage-Linie ") == 6 and t.count("   Durchschnitt 200-Tage-Linie ") == 6
           and t.count("   Durchschnitt Stand: Tagesschlüsse bis ") == 6
           and t.count("   Durchschnitt Lage: Nach dem letzten Tagesschluss liegt die 50-Tage-Linie ") == 6
           and len([z_ for z_ in t.splitlines() if z_.startswith("   Durchschnitt ") and "  nach Tagesschluss " in z_]) == 12
           and t.count("\nDurchschnittslinien: " + BELEG_LINIEN + " Als Regel geprüft (U141 B2, Stand ") == 1
           and "Als Niveau noch nicht geprüft (U244, Debug 149)" in t.split("\nDurchschnittslinien: ")[1].splitlines()[0]
           and t.index("\nMesswerte: ") < t.index("\nDurchschnittslinien: ") < t.index("\nBetrieb"),
           next((z_ for z_ in t.splitlines() if z_.startswith("   Durchschnitt 200-Tage-Linie")), "keine Zeile")[:150])
        acr = AU.verbinden(AU.ausblick_pfad(db))
        try:                                                              # Rückblick mit dem S1 aus hl_ausblick.urteil_s1 (BTC-Band zu weit) ablegen
            with acr:
                acr.execute("INSERT OR REPLACE INTO au_rueckblick VALUES (?,?,?)", (jetzt - 60, 1.0, json.dumps(AU._ohne_nan({"stand": jetzt - 60, "s1": S1w}))))
        finally:
            acr.close()
        N_rb = nutzlast(db, "BTC", jetzt); t_rb = text(db, coins=("BTC", "ETH"), jetzt=jetzt)
        zeile7 = next((z_ for z_ in t_rb.splitlines() if z_.startswith("   Spanne  7 T:")), "")
        ok("Vertrag Ausblick, Rückblick aus der Datenbank: Seite (über hl_ausblick.nutzlast) und Debug-Text (eigene Lesung) zeigen "
           "denselben Vermerk „traf 90 % (zu weit)“, „Vorsprung belegt“ und im Beleg „besteht nicht“ -- auch im Kernsatz",
           N_rb["spanne"]["h"]["7"]["vermerk"] == "traf 90 % (zu weit)" and N_rb["spanne"]["h"]["7"]["vorsprung"] == "belegt"
           and zeile7.endswith("· traf 90 % (zu weit) · Vorsprung belegt") and t_rb.count("zugleich): besteht nicht -- das Band von BTC ist zu weit") == 2
           and N_rb["satz"]["text"].endswith("Im Rückblick traf dieses Band 90 % -- zu weit (Soll 80 %).")
           and f"   {N_rb['satz']['text']} " in t_rb and "traf bei ETH 80,0 % ± " in t_rb.split("== ETH ")[1],
           f"Seite: {N_rb['spanne']['h']['7']['vermerk']} · {N_rb['spanne']['h']['7']['vorsprung']} | Text: …{zeile7[-52:]}")
        # 23.105: derselbe Rückblick erreicht den Kurs-Rechner -- Hinweis bei den Tagen für BTC (Band zu weit), keiner für ETH
        try:
            store_rb = os.path.join(tmp, "prognosen_rechner.db")
            G_rb = rechner_grundlage(db, "BTC", jetzt, store_rb); G_re = rechner_grundlage(db, "ETH", jetzt, store_rb)
            R_rb = rechner_nutzlast(db, "BTC", [(G_rb["kurs"] or 1.0) * 0.97], jetzt, store_rb)
            R_re = rechner_nutzlast(db, "ETH", [(G_re["kurs"] or 1.0) * 0.97], jetzt, store_rb)
            band_rb = [h_ for h_ in R_rb["hinweise"] if "Spanne des Ausblicks" in h_]
            # je Frist die eigene Trefferquote: ein jüngerer Rückblick mit 86 % über 14 Tage, danach wieder entfernt
            S1x = json.loads(json.dumps(AU._ohne_nan(S1w))); S1x["h"]["14"]["deckung"]["BTC"]["d80"] = 0.86
            acx = AU.verbinden(AU.ausblick_pfad(db))
            try:
                with acx:
                    acx.execute("INSERT OR REPLACE INTO au_rueckblick VALUES (?,?,?)", (jetzt - 30, 1.0, json.dumps({"stand": jetzt - 30, "s1": S1x})))
                R_rx = rechner_nutzlast(db, "BTC", [(G_rb["kurs"] or 1.0) * 0.97], jetzt, store_rb)
            finally:
                with acx:
                    acx.execute("DELETE FROM au_rueckblick WHERE stand=?", (jetzt - 30,))
                acx.close()
            band_rx = [h_ for h_ in R_rx["hinweise"] if "Spanne des Ausblicks" in h_]
            G_rz = rechner_grundlage(db, "BTC", jetzt, store_rb)
            ok("Vertrag Kurs-Rechner, Trefferquote des Bands aus dem Rückblick in der Datenbank (S1 in der Form von hl_ausblick.urteil_s1): "
               "Der Rechner liest für den Coin dieselbe Deckung wie die Spanne; für BTC (Band zu weit, 90 %) steht bei 7 und 14 Tagen der "
               "Hinweis, für ETH (80 %) keiner; jede Frist trägt ihre eigene Trefferquote (ein jüngerer Rückblick mit 86 % über 14 Tage: "
               "„90 % und 86 %“; danach gilt wieder der vorige); Debug 143 nennt den Hinweis",
               G_rb["deckung"]["7"] == S1w["h"]["7"]["deckung"]["BTC"] and G_rb["deckung"]["14"] == S1w["h"]["14"]["deckung"]["BTC"]
               and G_re["deckung"]["7"] == S1w["h"]["7"]["deckung"]["ETH"]
               and band_rb == ["7 Tage und 14 Tage: Für BTC ist die Spanne des Ausblicks im Rückblick zu weit (das 80-%-Band traf 90 % und 90 %) -- "
                               "der Kurs blieb öfter im Band als erwartet, diese Wahrscheinlichkeiten können zu hoch sein."]
               and not [h_ for h_ in R_re["hinweise"] if "Spanne des Ausblicks" in h_] and [f_[3] for f_ in R_rb["fristen"]][2:] == [True, True]
               and t_rb.count("   Kurs-Rechner Hinweis: " + (band_rb or ["?"])[0]) == 1
               and len(band_rx) == 1 and "(das 80-%-Band traf 90 % und 86 %)" in band_rx[0] and G_rz["deckung"] == G_rb["deckung"],
               f"{band_rb} | jünger: {[h_[60:120] for h_ in band_rx]} | ETH {R_re['hinweise']}")
        except Exception as e_r:                                            # eine Ausnahme ist ein Fehler der Probe, kein Abbruch des Selbsttests
            ok("Vertrag Kurs-Rechner, Trefferquote des Bands: die Probe läuft ohne Ausnahme durch", False, f"{type(e_r).__name__}: {e_r}")
        # Aktien-Regel: Kerzen des S&P-500-Perp in der echten Form (hl_aktien.kerzen_schreiben), die Regel selbst setzt die Ausnahme
        import hl_aktien as AK
        g_ohne = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
        akc = AK.verbinden(AK.aktien_pfad(db))
        try:
            kerze = lambda ts_: (ts_, 5000.0, 5000.0, 5000.0, 5000.0, 1.0)
            # 5 Kerzen von vor 9–11 h und 11 aus den letzten 5,5 h: 16 Zeilen, aber nur 11 im 8-h-Fenster der Regel
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [kerze(jetzt - (22 - i) * 1800) for i in range(5)] + [kerze(jetzt - (11 - i) * 1800) for i in range(11)], jetzt)
            letzte_k = jetzt - 1800
            g_11 = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [kerze(jetzt - (16 - i) * 1800) for i in range(5)], jetzt)      # 8 h bis 6 h zurück: jetzt 16 im Fenster
            g_mit = gemeinsam_lesen(db, jetzt)["aktien_pruefung"]
            g_2h = gemeinsam_lesen(db, letzte_k + 7_200)["aktien_pruefung"]; g_159 = gemeinsam_lesen(db, letzte_k + 7_199)["aktien_pruefung"]
            l_ruhig = nutzlast(db, "BTC", jetzt)["lampen"][3]
            vor_schock = AU.schock_pruefen(db, jetzt, setzen=False)
            jetzt_s = jetzt + 3600
            AK.kerzen_schreiben(akc, AKTIEN_REIHE, [(jetzt, 5000.0, 5000.0, 4900.0, 4900.0, 1.0), (jetzt + 1800, 4900.0, 4900.0, 4900.0, 4900.0, 1.0)], jetzt_s)
        finally:
            akc.close()
        neu_c = [x for x in AU.schock_pruefen(db, jetzt_s) if x[1] == "c"]         # die Regel des Ausblicks setzt die Ausnahmelage
        NS = nutzlast(db, "BTC", jetzt_s); l_c = NS["lampen"][3]
        ok("Vertrag Aktien-Regel: ohne Kerzen des S&P-500-Perp ist die Lampe grau, ebenso mit nur 11 Kerzen im 8-h-Fenster (ältere "
           "zählen nicht); mit 16 Kerzen (hl_aktien.kerzen_schreiben) aus und „geprüft“, 2 h nach der letzten Kerze wieder grau (1 s davor "
           "nicht); ein Sprung von −2 % lässt hl_ausblick.schock_pruefen die Ausnahmelage (c) setzen, die Lampe zeigt sie als Hinweis; "
           "PAXG bleibt „gilt nicht“",
           g_ohne["ok"] is False and "zu wenige Kerzen" in g_ohne["grund"] and g_11["ok"] is False and "zu wenige Kerzen" in g_11["grund"]
           and g_11["kerze_ts"] == letzte_k and g_mit["ok"] is True and g_mit["kerze_ts"] == letzte_k and "BTC" in (g_mit["coins"] or [])
           and g_2h["ok"] is False and g_159["ok"] is True and l_ruhig["zustand"] == "aus" and not [x for x in vor_schock if x[1] == "c"]
           and any(x[0] == "BTC" for x in neu_c) and l_c["zustand"] == "hinweis" and l_c["wert"] == "S&P −2,0 %" and l_c["ts"] == jetzt_s
           and nutzlast(db, "PAXG", jetzt_s)["lampen"][3]["wort"] == "gilt nicht" and NS["streifen"][1]["lampen"][3] == "hinweis",
           f"ohne Kerzen: {g_ohne['grund'][:50]}… | mit: ok {g_mit['ok']} | Schock: {[(x[0], x[1]) for x in neu_c][:3]} -> Lampe {l_c['zustand']} {l_c['wert']}")
        # Unstaking (23.100): staking.db mit den echten Funktionen von hl_staking gefüllt -- Antworten in der Form der Beacon-API
        import hl_staking as ST
        alt_st = os.environ.pop("HL_STAKING_DB", None)
        try:
            st_p = ST.pfad(db)
            NE0 = nutzlast(db, "ETH", jetzt)                             # noch ohne staking.db
            VL0 = verlauf_nutzlast(db, jetzt); VJ0 = json.loads(verlauf_json(db, jetzt).decode("utf-8"))      # 23.104: der Verlauf ebenso
            WS = ST._probe_welt(jetzt); e0_ = WS["e0"]
            WS["schlange"]["data"] += [{"index": str(20_000 + i), "balance": str(2048 * ST.GWEI), "status": "active_exiting",
                                        "validator": {"withdrawal_credentials": "0x01" + "00" * 11 + "dd" * 20,
                                                      "effective_balance": str(2048 * ST.GWEI), "slashed": False,
                                                      "exit_epoch": str(e0_ + 225 + i * 8), "withdrawable_epoch": str(e0_ + 225 + i * 8 + 256)}}
                                       for i in range(60)]
            stc = ST.verbinden(st_p)
            try:
                ST.lauf_einmal(stc, ST._probe_transport(WS, ST._probe_tagesdatei(jetzt)), jetzt, erzwungen=True)
            finally:
                stc.close()
            SN = ST.nutzlast(st_p, jetzt)
            NE1 = nutzlast(db, "ETH", jetzt); NB1 = nutzlast(db, "BTC", jetzt)
            t_st = text(db, coins=("BTC", "ETH"), jetzt=jetzt)
            NE_alt = nutzlast(db, "ETH", jetzt + ST.FRISCH_KNOTEN_S + 1)  # Knotenstand zu alt: Ersatz aus der Tagesdatei, als Schätzung
            # 23.102: Tagesdatei 21 Tage alt (wie auf dem Pi am 15.11.2026), Knoten frisch -- eigene staking.db, dieselbe Hauptdatenbank
            p_steht = os.path.join(tmp, "steht_staking.db")
            stc2 = ST.verbinden(p_steht)
            try:
                ST.lauf_einmal(stc2, ST._probe_transport(ST._probe_welt(jetzt), ST._probe_tagesdatei(jetzt, letzter_vor=21)), jetzt, erzwungen=True)
            finally:
                stc2.close()
            os.environ["HL_STAKING_DB"] = p_steht
            try:
                SN_st = ST.nutzlast(p_steht, jetzt)
                NE_st = nutzlast(db, "ETH", jetzt); t_steht = text(db, coins=("ETH",), jetzt=jetzt)
            finally:
                del os.environ["HL_STAKING_DB"]
        finally:
            if alt_st is not None:
                os.environ["HL_STAKING_DB"] = alt_st
        u1 = NE1["unstaking"]
        zeilen_u = [z_ for z_ in t_st.splitlines() if z_.startswith("   Unstaking")]
        ok("Vertrag Unstaking (hl_staking, Antworten in der Form der Beacon-API): ohne staking.db steht der Grund da; danach zeigt das "
           "Cockpit bei ETH dieselbe Summe, dasselbe Ende, denselben Kalender, dieselbe große Freigabe und denselben Abzieher wie "
           "hl_staking.nutzlast; bei BTC nichts; der Debug-Text nennt dieselben Zahlen; drei Stunden später gilt nur noch die Schätzung "
           "aus der Tagesdatei",
           NE0["unstaking"]["ok"] is False and "staking.db fehlt" in NE0["unstaking"]["fehlt"][0]
           and SN["ok"] and SN["quelle"] == "knoten" and u1["ok"] and u1["quelle"] == "knoten" and u1["summe_eth"] == SN["summe_eth"]
           and u1["ende_ts"] == SN["ende_ts"] and [t_["eth"] for t_ in u1["tage"]] == [round(k_[1] + k_[2], 3) for k_ in SN["kalender"][:UNSTAKING_TAGE]]
           and SN["gross"] is not None and u1["gross"]["eth"] == SN["gross"]["eth"] and u1["gross"]["von_ts"] == SN["gross"]["von_ts"]
           and [z_["adresse"] for z_ in u1["abzieher"]] == ["0x" + "dd" * 20] and u1["abzieher"][0]["eth"] == 122_880.0
           and u1["konsol_eth"] == 96.0 and u1["eintritt_eth"] == 900_000.0 and NB1.get("unstaking") is None
           and len(zeilen_u) >= 4 and f"   Unstaking: {_eth(SN['summe_eth'])} ETH angemeldet" in t_st and "0x" + "dd" * 20 + " 122.880 ETH" in t_st
           and "Unstaking" not in t_st.split("== ETH ")[0] and u1["satz"] in t_st and not [w for w in WORT_VERBOTEN if w in " ".join(zeilen_u).lower()]
           and NE_alt["unstaking"]["ok"] and NE_alt["unstaking"]["quelle"] == "tagesdatei" and NE_alt["unstaking"]["geschaetzt"]
           and NE_alt["unstaking"]["summe_eth"] == 115_200.0 and NE_alt["unstaking"]["abzieher"] == [],
           f"{_eth(u1['summe_eth'])} ETH, {len(u1['tage'])} Tage, {u1['satz']} | später: {NE_alt['unstaking']['quelle']} {_eth(NE_alt['unstaking']['summe_eth'])}")
        u_st = NE_st["unstaking"]
        tag_st = time.strftime("%d.%m.%Y", time.gmtime(jetzt - 21 * TAG))      # dieser Teil läuft mit der echten Uhr: Daten aus `jetzt`
        ok("Vertrag Unstaking bei stehengebliebener Tagesdatei (23.102; hl_staking mit einer Tagesdatei, deren letzter Tag 21 Tage "
           "zurückliegt, Knoten frisch): Die Karte zeigt den Stand des Knotens, nennt statt der Gegenseite deren Fehlen mit dem letzten Tag "
           "der Quelle und bei der Dauer des Auszahlungslaufs den Tag der Zahl; der Debug-Text sagt dasselbe; mit frischer Tagesdatei "
           "steht die Gegenseite da",
           SN_st["ok"] and SN_st["quelle"] == "knoten" and SN_st["tagesdatei"]["frisch"] is False and SN_st["tagesdatei"]["alt_tage"] == 21
           and u_st["ok"] and u_st["quelle"] == "knoten" and u_st["summe_eth"] == SN_st["summe_eth"] and u_st["eintritt_eth"] is None
           and u_st["gegenseite"] == ("Gegenseite (ETH, das auf das Staking wartet): zurzeit kein Wert, weil die Tagesdatei der Quelle "
                                      f"am {tag_st} endet.")
           and f"binnen bis zu 6,9 Tagen danach (Zahl der Validatoren vom {tag_st})." in u_st["auszahlung"]
           and "   Unstaking: " + u_st["gegenseite"] in t_steht and "900.000" not in " ".join(z_ for z_ in t_steht.splitlines() if "Unstaking" in z_)
           and u1["gegenseite"] == ("Gegenseite: 900.000 ETH warten darauf, gestakt zu werden (Tagesstand "
                                    + time.strftime("%d.%m.", time.gmtime(jetzt)) + ").")
           and "Zahl der Validatoren vom" not in u1["auszahlung"],
           f"{u_st['gegenseite']} | {u_st['auszahlung'][88:170]}")
        # Prüfung der Kursfolge (23.101): Urteil mit den echten Funktionen von hl_staking_studie gerechnet und gespeichert
        import hl_staking_studie as SS
        alt_st = os.environ.pop("HL_STAKING_DB", None)
        alt_sw = os.environ.get("HL_SWING_DB")
        try:
            o_p = os.path.join(tmp, "pruefung"); os.makedirs(o_p)
            WP = SS._probe_welt(o_p, saat=2)
            sqlite3.connect(WP["db"]).close()
            jetzt_w = (WP["ende_D"] + 1) * TAG + 8 * 3600
            NP0 = nutzlast(WP["db"], "ETH", jetzt_w)
            os.environ["HL_SWING_DB"] = WP["swing"]
            try:
                SS.bericht(WP["db"], mit_abruf=False, jetzt=jetzt_w, laeufe_null=100, laeufe_kontrolle=30)
            finally:
                if alt_sw is None:
                    os.environ.pop("HL_SWING_DB", None)
                else:
                    os.environ["HL_SWING_DB"] = alt_sw
            KZ = SS.kurz(SS.ST.pfad(WP["db"]))
            NP1 = nutzlast(WP["db"], "ETH", jetzt_w); NPB = nutzlast(WP["db"], "BTC", jetzt_w)
            t_p = text(WP["db"], coins=("ETH",), jetzt=jetzt_w)
            # 23.104 (U260): Verlauf aus denselben Dateien -- dazu ein Stand des Knotens (eigene Tagesreihe) und die Kerzen dieser Welt
            stc3 = ST.verbinden(ST.pfad(WP["db"]))
            try:
                ST.lauf_knoten(stc3, ST.Abruf(ST._probe_transport(ST._probe_welt(jetzt_w)), frist_s=30), jetzt_w)
                reihe_w = ST.tagesreihe_lesen(stc3)
            finally:
                stc3.close()
            os.environ["HL_SWING_DB"] = WP["swing"]
            try:
                VS = SS.verlauf(WP["db"], jetzt_w); VN = verlauf_nutzlast(WP["db"], jetzt_w)
                VJ = json.loads(verlauf_json(WP["db"], jetzt_w).decode("utf-8"))
                t_v = text(WP["db"], coins=("BTC", "ETH"), jetzt=jetzt_w)
                echt_verlauf = SS.verlauf
                try:
                    SS.verlauf = lambda *a_, **k_: (_ for _ in ()).throw(RuntimeError("Probe <x>"))
                    VX = verlauf_nutzlast(WP["db"], jetzt_w); VXJ = json.loads(verlauf_json(WP["db"], jetzt_w).decode("utf-8"))
                finally:
                    SS.verlauf = echt_verlauf
            finally:
                if alt_sw is None:
                    os.environ.pop("HL_SWING_DB", None)
                else:
                    os.environ["HL_SWING_DB"] = alt_sw
            G_w = SS.gespeichert(ST.pfad(WP["db"]))
        finally:
            if alt_st is not None:
                os.environ["HL_STAKING_DB"] = alt_st
        ok("Vertrag Prüfung der Kursfolge (hl_staking_studie, Urteil auf einer erfundenen Welt gerechnet): vor dem ersten Lauf steht in der "
           "Karte „noch nicht geprüft“; danach das gespeicherte Urteil mit Datum und denselben Fallzahlen wie hl_staking_studie.kurz; "
           "der Debug-Text nennt es; bei BTC nichts",
           NP0["unstaking"]["pruefung"]["da"] is False and "noch nicht geprüft" in NP0["unstaking"]["beleg"] and KZ["da"] and KZ["aktuell"]
           and KZ["urteil"] == "nicht belegt" and KZ["debug"] == 147 and NP1["unstaking"]["pruefung"] == pruefung_bauen(KZ)
           and NP1["unstaking"]["pruefung"]["urteil"] == "nicht belegt"
           and f"nicht belegt ({KZ['A']['n']} Fälle nach der Anmeldung, {KZ['B']['n']} nach der Freigabe)" in NP1["unstaking"]["beleg"]
           and KZ["daten_bis"] == "2026-11-10"
           and ("   Unstaking, Prüfung der Kursfolge (U255): Folgt darauf ein Kursrückgang? Geprüft am 11.11.2026 (Wellen bis 10.11.2026): "
                "nicht belegt.") in t_p
           and NPB.get("unstaking") is None,
           f"{NP1['unstaking']['pruefung']['kurz']} | A {KZ['A']['n']} Fälle, Grenze {KZ['A']['grenze']}")
        Dw, Ew = WP["D0"], WP["ende_D"]
        zl_v = [z_ for z_ in t_v.splitlines() if z_.startswith("   Unstaking Verlauf")]
        ok("Vertrag Verlauf (23.104; hl_staking_studie.verlauf auf der erfundenen Welt, dazu ein Stand des Knotens): Die Antwort für die "
           "Karte trägt je Tag dieselbe Schlange wie die Welt (die 15 ausgeschlossenen Tage leer und als Zeitraum ohne Daten), denselben "
           "ETH-Kurs und die eigene Messung an ihrem Tag; die Wellen sind die Fälle des gespeicherten Urteils an ihrem Tag, mit denselben "
           "Zahlen wie in Debug 147; /cockpit/unstaking liefert dasselbe als JSON; der Debug-Text nennt den Verlauf nur bei ETH; ohne "
           "staking.db und bei einem Fehler der Quelle steht der Grund da",
           VS["ok"] and VN["ok"] and VN["d0"] == Dw and VN["n"] == Ew + 2 - Dw == 901 and len(VN["q"]) == 901
           and all(VN["q"][D_ - Dw] == int(round(WP["Q"][D_])) for D_ in range(Dw, Ew + 1) if not SS.U0 <= D_ <= SS.U1)
           and all(VN["q"][D_ - Dw] is None for D_ in range(SS.U0, SS.U1 + 1)) and VN["q"][900] is None
           and all(VN["px"][D_ - Dw] == round(WP["P"]["ETH"][D_], 2) for D_ in range(Dw, Ew + 2))
           and len(reihe_w) == 1 and VN["k"] == {"ab": 900, "w": [int(round(ST.angemeldet_eth(reihe_w[0])))]} and VN["letzter"] == 900
           and ST.angemeldet_eth(reihe_w[0]) > reihe_w[0]["schlange_eth"] > 0 and VN.get("k_name") == "Angemeldet" and VS.get("knoten_art") == "angemeldet"
           and (VS.get("neu") or {}).get("regel") == "U255/2" and VN.get("neu") == {"regel": "U255/2", "noetig": 8, "erkannt": 0, "faellig": False}
           and VN.get("wellen_alt") == len(VN["wellen"]) and VN.get("wellen_neu") == 0
           and "Zweite Prüfung, vorab festgelegt am 16.11.2026: Sie zählt nur neue Wellen der eigenen Messung" in VN["satz"]
           and VN["achse_q"] == "Abzüge in ETH: bis 10.11.2026 Schlange, ab 11.11.2026 angemeldet"
           and VN["luecken"] == [[SS.U0 - Dw, SS.U1 - Dw]] and VN["luecken_text"] == ["07.05.–21.05.2025 (laut Quelle falsche Einheit)"]
           and G_w is not None and len(VN["wellen"]) == len(G_w["faelle"]) == len(WP["A"]) > 10
           and [w_["i"] for w_ in VN["wellen"]] == [a_ - Dw for a_ in WP["A"]]
           and all(w_["zeile"] == [str(f_["nr"]), SS.datum(f_["a"]), "+" + _eth(f_["zuwachs"]), SS._pz(f_["a_eth7"], 1), SS._pz(f_["a_y7"], 1)]
                   for w_, f_ in zip(VN["wellen"], G_w["faelle"]))
           and f"Markiert sind die {len(WP['A'])} Wellen der Prüfung vom 11.11.2026:" in VN["satz"]
           and f"im Mittel bei {SS._pz(G_w['A']['mittel'])} %, über alle Tage bei {SS._pz(G_w['alle']['y7'])} %. Der Unterschied ist nicht belegt" in VN["satz"]
           and {k_: v_ for k_, v_ in VJ.items() if k_ != "rechenzeit_ms"} == {k_: v_ for k_, v_ in VN.items() if k_ != "rechenzeit_ms"}
           and len(zl_v) == 4 and zl_v[0] == ("   Unstaking Verlauf (Karte „Unstaking · Verlauf“): 901 Tage vom " + SS.datum(Dw) + " bis 11.11.2026 · "
                                             "Schlange aus der Tagesdatei an 885 Tagen (bis 10.11.2026) · eigene Messung an 1 Tag (ab 11.11.2026) · "
                                             f"ETH-Kurs an 901 Tagen · {len(WP['A'])} Wellen markiert · Ausschnitt beim Öffnen: 1 Jahr")
           and zl_v[1] == "   Unstaking Verlauf, keine Daten: 07.05.–21.05.2025 (laut Quelle falsche Einheit)"
           and zl_v[2].startswith("   Unstaking Verlauf, letzter Tag mit Wert: 11.11.2026 · " + _eth(ST.angemeldet_eth(reihe_w[0]))
                                  + " ETH (eigene Messung: angemeldet, noch nicht frei) · ETH-Kurs ")
           and zl_v[3] == "   Unstaking Verlauf: " + VN["satz"] and "Unstaking" not in t_v.split("== ETH ")[0]
           and not [w for w in WORT_VERBOTEN if w in " ".join(zl_v).lower()]
           and VL0["ok"] is False and "staking.db fehlt" in VL0["fehlt"][0] and VJ0["ok"] is False and VJ0["fehlt"] == VL0["fehlt"]
           and VX["ok"] is False and VX["fehlt"] == ["Verlauf: RuntimeError: Probe <x>"] and VXJ["fehlt"] == VX["fehlt"],
           f"{VN['n']} Tage, {len(VN['wellen'])} Wellen, eigene Messung {VN['k']}; {zl_v[0][-60:] if zl_v else 'keine Zeile'}")
        leer_db = os.path.join(tmp, "leer", "hl_liq.db")
        os.makedirs(os.path.dirname(leer_db))
        sqlite3.connect(leer_db).close()
        alt = CB._mit_umgebung({k: os.path.join(tmp, "leer", os.path.basename(v)) for k, v in U["pf"].items()})
        os.environ["HL_AKTIEN_DB"] = os.path.join(tmp, "leer", "aktien.db")
        try:
            NL = json.loads(payload_json(leer_db, "BTC", jetzt))
            RL = json.loads(rechner_json(leer_db, "BTC", "50000", jetzt, os.path.join(tmp, "leer", "prognosen.db")))
            RLx = json.loads(rechner_json(leer_db, "DOGE", "1", jetzt, os.path.join(tmp, "leer", "prognosen.db")))
        finally:
            CB._mit_umgebung(U["pf"]); os.environ["HL_AKTIEN_DB"] = U["pf"]["aktien"]
        ok("Leeres System (keine der Datenbanken vorhanden): /cockpit antwortet mit ok, grauen Lampen und Gründen statt mit einem Fehler",
           NL.get("ok") is True and NL["spanne"]["fehlt"] and NL["lampen"][0]["zustand"] == "grau" and len(NL["streifen"]) == 6
           and [l["zustand"] for l in NL["lampen"]] in (["grau", "grau", "aus", "grau", "grau"], ["grau", "grau", "hinweis", "grau", "grau"])
           and "ausblick.db fehlt" in NL["lampen"][3]["detail"],
           f"Lampen {[l['zustand'] for l in NL['lampen']]}; fehlt {NL['spanne']['fehlt'][:1]}")
        ok("Leeres System: /cockpit/rechner antwortet ebenfalls mit Gründen statt mit einem Fehler -- kein Kurs, also keine Rechnung; ein "
           "fremder Coin bekommt eine Absage",
           RL.get("ok") is True and RL["zeilen"][0]["ok"] is False and RL["zeilen"][0]["grund"] == "Kein frischer Kurs."
           and RL["fehlt"] == ["Kein Kurs für BTC -- der Rechner rechnet nur vom jetzigen Kurs."] and [f_[3] for f_ in RL["fristen"]] == [False] * 4
           and RLx.get("ok") is False and RLx["fehlt"] == ["DOGE: kein Kurs-Rechner (nur BTC, ETH, HYPE, ZEC, XMR, PAXG)"], f"{RL.get('fehlt')}")
        # ---- 23.110 (U269): Durchschnittslinien -- echte Formen von hl_chartbild.tagesteil, hl_ausblick.prognose und hl_niveaus.kurz
        import numpy as np
        import hl_niveaus as NVM
        ok("Leeres System: Die Karte „Durchschnittslinien“ nennt den Grund des Chartbilds (keine Tageskerzen) statt einer Zahl; ihr Beleg "
           "sagt, dass die Linien als Niveau noch nicht geprüft sind",
           NL["linien"]["ok"] is False and NL["linien"]["zeilen"] == [] and NL["linien"]["fehlt"][0].startswith("Tageskerzen: ")
           and "Als Niveau noch nicht geprüft (U244, Debug 149)" in NL["linien"]["beleg"] and NL["linien"]["beleg"].startswith(BELEG_LINIEN),
           f"{NL['linien']['fehlt']}")
        G_l = gemeinsam_lesen(db, jetzt)
        fehler_l = []; mit_p = ohne_niveau = mit_abstand = 0
        for c_ in COINS:
            Dc = _ohne_nan(bauen(quellen_lesen(db, c_, jetzt, G_l, mit_ausblick_meldung=False)))
            Lc = Dc["linien"]
            Ec = CB.tagesteil(db, c_, jetzt); Tc = Ec["trend"]; cc = [float(x) for x in Ec["tage"]["c"]]
            Pc = AU.nutzlast(db, c_, None).get("prognose") or {}
            nach = {str(n_.get("art")): n_ for n_ in Pc.get("niveaus") or []}
            kurs_c = Dc["kopf"]["kurs"] if Dc["kopf"]["frisch"] else None
            if not Lc["ok"] or len(Lc["zeilen"]) != 2:
                fehler_l.append(f"{c_}: Karte ohne Wert {Lc.get('fehlt')}"); continue
            for z_, (key_, tage_, _name, art_) in zip(Lc["zeilen"], LINIEN):
                hand = sum(cc[-tage_:]) / tage_
                if z_["px"] is None or abs(z_["px"] / hand - 1.0) > 1e-9 or abs(z_["px"] / float(Tc[key_ + "_jetzt"]) - 1.0) > 1e-12:
                    fehler_l.append(f"{c_} {key_}: Wert {z_['px']} gegen {hand} von Hand")
                if kurs_c:
                    mit_abstand += 1
                    live = (sum(cc[-(tage_ - 1):]) + kurs_c) / tage_     # wie der Live-Chart: der heutige Tag zählt mit dem jetzigen Kurs
                    if (z_["px_live"] is None or abs(z_["px_live"] / live - 1.0) > 1e-9 or z_["abstand"] is None
                            or abs(z_["abstand"] - (kurs_c / live - 1.0)) > 1e-9 or z_["haupt_text"] != _px(live)
                            or z_["neben"] != "nach Tagesschluss " + _px(hand)):
                        fehler_l.append(f"{c_} {key_}: mit heute {z_['px_live']} gegen {live} von Hand; Abstand {z_['abstand']}; {z_['neben']}")
                n_ = nach.get(art_)
                if n_ is None:
                    ohne_niveau += 1
                    if z_["p7"] is not None or not z_["p_grund"].startswith("nicht unter den Niveaus des Ausblicks"):
                        fehler_l.append(f"{c_} {key_}: ohne Niveau im Ausblick, aber {z_['p7']} / {z_['p_grund']}")
                elif z_["p7"] is not None:
                    mit_p += 1
                    if (z_["p7"] != float(n_["p"]["7"][0]) or z_["p14"] != float(n_["p"]["14"][0]) or abs(float(n_["px"]) / z_["px"] - 1.0) > 1e-9
                            or z_["p_hinweis"] != ("gilt für den Stand nach Tagesschluss" if kurs_c else "") or z_["p_grund"]):
                        fehler_l.append(f"{c_} {key_}: Wahrscheinlichkeit {z_['p7']} gegen {n_['p'].get('7')} ({z_['p_hinweis']})")
                elif not z_["p_grund"]:
                    fehler_l.append(f"{c_} {key_}: weder Zahl noch Grund")
            s50, k50 = Tc.get("steigung50"), Tc.get("seit50")
            soll_r = "" if s50 not in (1, -1) else f"Linie {'steigt' if s50 > 0 else 'fällt'} seit {k50} Tag{'' if k50 == 1 else 'en'}"
            if (Lc["zeilen"][0]["richtung"] != soll_r or Lc["stand_tag"] != int(Tc["tag"]) or Lc["stand_tag"] != jetzt // TAG - 1
                    or (("über" if Tc["lage50_200"] > 0 else "unter") + " der 200-Tage-Linie") not in Lc["lage"]
                    or (Tc.get("kreuz_tag") is not None and ("seit dem " + _tag_datum(Tc["kreuz_tag"])) not in Lc["lage"])
                    or not Lc["stand"].endswith(", Quelle " + str(Ec["tage"]["quelle"])) or Lc["hinweise"]):
                fehler_l.append(f"{c_}: Richtung, Stand oder Lage -- {Lc['zeilen'][0]['richtung']} (Soll {soll_r}) | {Lc['stand']} | {Lc['lage']} | {Lc['hinweise']}")
        ok("Vertrag Durchschnittslinien (23.110, 23.111): für alle sechs Coins sind die Werte nach Tagesschluss gleich dem Mittel der letzten 50 "
           "und 200 Tagesschlüsse (von Hand aus hl_chartbild.tagesteil) und gleich hl_chartbild.trendlage; der große Wert ist (Summe der "
           "letzten 49 bzw. 199 Schlüsse + Kurs) ÷ 50 bzw. 200; Abstand = Kurs ÷ großer Wert − 1; Richtung der 50-Tage-Linie, "
           "Stand (gestern), Quelle und Lage wie im Chartbild; führt der Ausblick die Linie als Niveau (Art-Kennungen ma50_ und ma200), "
           "steht dieselbe Erreich-Wahrscheinlichkeit, sonst der Grund -- beides kommt in der Probewelt vor; die Antwort von /cockpit trägt "
           "die Karte",
           not fehler_l and mit_p >= 1 and ohne_niveau >= 1 and mit_abstand >= 2 and N["linien"]["ok"] is True and len(N["linien"]["zeilen"]) == 2
           and N["linien"]["beleg"].startswith(BELEG_LINIEN + " Als Regel geprüft (U141 B2, Stand " + CB.PRUEFSTAND_STAND + "): " + CB.PRUEFSTAND["trend"][1]
                                               + " Als Niveau noch nicht geprüft (U244, Debug 149)"),
           f"{mit_p} Linien mit Wahrscheinlichkeit, {ohne_niveau} nicht unter den Niveaus, {mit_abstand} mit Abstand; Fehler: {fehler_l[:3] or 'keine'}")
        nv0 = niveaus_urteil_lesen(db)
        ac_n = AU.verbinden(AU.ausblick_pfad(db))
        try:
            ac_n.execute(NVM.TABELLE)
            NVM._setzen(ac_n, "urteil", jetzt - 3 * TAG, {"regel": NVM.REGEL, "stand": jetzt - 3 * TAG, "h": {str(NVM.H_PRIM): {
                "A": {"arten": {a_: {"n": 1200 + i_, "quote": 0.34, "erw": 0.36, "urteil": "nicht belegt"} for i_, a_ in enumerate(NVM.ARTEN)}},
                "B": {"arten": {a_: {"urteil": "nicht belegt"} for a_ in NVM.ARTEN}}}}})
        finally:
            ac_n.close()
        nv1 = niveaus_urteil_lesen(db)
        D1 = bauen(quellen_lesen(db, "PAXG", jetzt, gemeinsam_lesen(db, jetzt), mit_ausblick_meldung=False))
        wann_n = time.strftime("%d.%m.%Y", time.gmtime(jetzt - 3 * TAG))
        ok("Vertrag Niveau-Arten (hl_niveaus.kurz, U244): ohne Urteil „noch kein Urteil“; mit einem gespeicherten Urteil (Tabelle au_niveaus, "
           "Text von hl_niveaus) steht je Linie „erreicht … % bei … % erwartet (n …) · Anziehung nicht belegt · Halten nicht belegt“ ohne die "
           "vorangestellte Kennung, mit Datum und den fünf Krypto-Coins (auch in der Karte für Gold); der Beleg der Levels sagt dann „für "
           "keine Art von Niveau ist eine eigene Wirkung belegt“",
           nv0["da"] is False and nv0["linien"] == {"ma50_": "noch kein Urteil (folgt mit dem nächsten Rückblick)",
                                                    "ma200": "noch kein Urteil (folgt mit dem nächsten Rückblick)"} and nv0["debug"] == 149
           and nv1["da"] is True and nv1["ohne_wirkung"] is True and nv1["stand"] == jetzt - 3 * TAG and nv1["coins"] == ["BTC", "ETH", "HYPE", "ZEC", "XMR"]
           and nv1["linien"] == {"ma50_": "erreicht 34 % bei 36 % erwartet (n 1.202) · Anziehung nicht belegt · Halten nicht belegt",
                                 "ma200": "erreicht 34 % bei 36 % erwartet (n 1.203) · Anziehung nicht belegt · Halten nicht belegt"}
           and (f"Als Niveau geprüft (U244, Debug 149, Urteil vom {wann_n}; 7 Tage; BTC, ETH, HYPE, ZEC, XMR zusammen): 50-Tage-Linie erreicht 34 % "
                "bei 36 % erwartet (n 1.202) · Anziehung nicht belegt · Halten nicht belegt; 200-Tage-Linie erreicht 34 % bei 36 % erwartet "
                "(n 1.203) · Anziehung nicht belegt · Halten nicht belegt. " + LINIEN_NICHT_WIDERLEGT) in D1["linien"]["beleg"]
           and niveau_art_satz(nv1) == f"Die Zahl folgt allein aus dem Abstand; für keine Art von Niveau ist eine eigene Wirkung belegt (U244, Urteil vom {wann_n}, Debug 149)."
           and ("steht noch aus" in D1["levels"]["beleg"] or D1["levels"]["beleg"].endswith(niveau_art_satz(nv1))),
           f"{nv1['linien'].get('ma50_')} | {D1['levels']['beleg'][-90:]}")
        ac_n = AU.verbinden(AU.ausblick_pfad(db))
        try:                                                             # dasselbe Urteil mit einem belegten Halten der runden Zahlen
            Ub = NVM.stand_lesen(db)["urteil"]; Ub.pop("gespeichert", None)
            Ub["h"][str(NVM.H_PRIM)]["B"]["arten"]["rund"] = {"urteil": "belegt", "gamma": -0.5, "ame": -9.0}
            NVM._setzen(ac_n, "urteil", jetzt - 3 * TAG, Ub)
        finally:
            ac_n.close()
        nv2 = niveaus_urteil_lesen(db)
        ok("Vertrag Niveau-Arten mit belegter Wirkung: Meldet hl_niveaus eine Art mit belegter Wirkung, gilt das Urteil nicht als „ohne "
           "Wirkung“ und der Beleg der Levels nennt den Satz der Niveau-Prüfung; die Zeilen der beiden Linien bleiben „nicht belegt“",
           nv2["da"] is True and nv2["ohne_wirkung"] is False
           and niveau_art_satz(nv2).startswith("Die Zahl folgt allein aus dem Abstand. Niveau-Art mit belegter Wirkung: runde Zahl wird nach dem "
                                               "Erreichen seltener überschritten (hält) (-9,0 Punkte bei 7 Tagen) -- Art belegt seit " + wann_n)
           and niveau_art_satz(nv2).endswith(" (U244, Debug 149)") and nv2["linien"] == nv1["linien"], niveau_art_satz(nv2)[-150:])
        Lk_ = linien_lesen({"fehlt": [], "trend": CB.trendlage({"c": np.array([100.0 + 0.5 * i_ for i_ in range(120)]), "tag0": 20_500}),
                            "tage": {"quelle": "Probe", "alter_tage": 0}})
        Kk = linien_bauen(Lk_, 161.975, None, False)
        ok("Vertrag kurze Reihe: hl_chartbild.trendlage auf 120 Tagen gibt für die 200-Tage-Linie keinen Wert (NaN) -- die Karte zeigt die "
           "50-Tage-Linie und nennt für die 200-Tage-Linie „fehlen noch Tage (120 von 200)“",
           Lk_["ma200"] is None and abs(Lk_["ma50"] - sum(100.0 + 0.5 * i_ for i_ in range(70, 120)) / 50) < 1e-9 and Lk_["ma50_richtung"] == 1
           and Lk_["ma50_seit"] == 70 and Lk_["lage"] is None and Lk_["tag"] == 20_619 and Kk["ok"] is True
           and Kk["zeilen"][1]["fehlt"] == "Für die 200-Tage-Linie fehlen noch Tage (120 von 200)." and Kk["lage"] == ""
           and Kk["zeilen"][0]["lage"] == "Kurs 10,0 % darüber", f"50: {Lk_['ma50']}, 200: {Lk_['ma200']}; {Kk['zeilen'][1]['fehlt']}")
    finally:
        try:
            if U is not None and hasattr(AU, "_demo_ende"):
                AU._demo_ende(U)
        except Exception:
            pass
        for k, v in alt_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    if "--selbsttest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--text" in sys.argv:
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        coins_ = (sys.argv[sys.argv.index("--coin") + 1].upper(),) if "--coin" in sys.argv else COINS
        print(text(db_, coins_))
        sys.exit(0)
    print(__doc__)
