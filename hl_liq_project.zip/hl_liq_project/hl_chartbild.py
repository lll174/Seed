#!/usr/bin/env python3
"""
Chartbild (U143 Stufe 1): die Lage je Coin in Worten -- Trend, Bein, Niveaus, Schwankung, Positionierung (Version 2026-09-23.66).

Regeln in KONZEPT_Chartbild.md (10.10.2026, Befunde 11.10.). Eine Anzeige, kein Signal: Die Studien U141, U142 und U110 haben für
die Bausteine kein belegtes Timing gezeigt -- mit einer Ausnahme seit dem endgültigen U142-Lauf (11.10.): Konten ≥ 3 gingen häufiger
einem Rücksetzer in 7 Tagen voraus (H1, ein Risikohinweis, keine Vorhersage). Jede Zeile nennt ihren Prüfstand. Nur lesend aus hl_liq.db (daily_bars, bars, heatmap,
trigger_orders über die Funktionen des Dashboards, bnc_metrics), swing.db, regime.db (PAXG), hebel.db und makro.db; schreibt nichts.
Wirkt auf nichts anderes: kein Treiber, keine Konfluenz, kein Labor, keine Prognose.

  python3 hl_chartbild.py --text --db <hl_liq.db>   Lage aller Coins als Text (Debug „Chartbild: Lage aller Coins als Text“)
  python3 hl_chartbild.py --selbsttest              Bausteine von Hand, gleich der Studien, Kausalität, Band-Kontrolle, Lesart, Ende zu Ende
  python3 hl_chartbild.py --demo <ordner>           synthetische Datenbanken für Bildschirmfotos (nur Test)
"""
from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import time

import numpy as np

import hl_hebel as HB
import hl_makro as MK
import hl_regime as RG
import hl_swing as SW
import hl_zyklus as ZY

VERSION_MODUL = "2026-09-23.66"
TAG = 86400
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")
SCHWELLEN = ZY.SCHWELLEN                                   # 10/20/30 % wie U141 Teil A
SCHWELLEN_GOLD = ZY.SCHWELLEN_GOLD                         # 3/5/10 % für PAXG
CHART_TAGE = 730                                           # so viele Tage gehen an die Seite (sichtbar 3–24 Monate)
PIVOT_N = 5                                                # Swing-Hoch: über den 5 Tagen davor, mindestens so hoch wie die 5 danach
PIVOT_TAGE = 365
ORDER_BEREICH = 0.30                                       # wie keyLevels() im Live-Chart
LIQ_UNTEN, LIQ_OBEN = 0.88, 1.15                           # wie load_chart (Liquidationsmarken)
LIQ_TRAEGT = 0.5                                           # ab dem halben Stundenvolumen (durchgezogene Linie im Live-Chart)
HAR_TAGE = RG.HIST_TAGE                                    # 1.096 Tage wie die Regime-Vorprüfung P0.2
HAR_H = (1, 7)
TREFFER_TAGE = 365
TREFFER_MIN = 90                                           # Trefferquote erst ab 90 Prognosetagen (sonst zu verrauscht)
PERZ_FENSTER, PERZ_MIN = 90, 60
SNAPSHOT_ALTER = HB.SNAPSHOT_MAX_ALTER                     # Tagesstand: jüngste Stundenzeile ≤ Tagesende, höchstens 2 h alt
FRISCH = {"tage": 3, "kurs": 900, "orders": 6 * 3600, "heatmap": 1800, "har": 2 * TAG, "funding": 3 * TAG, "archiv": 4 * TAG,
          "live": 3 * 3600, "fng": 3 * TAG}
CACHE_S = 600
KONTEN_SCHWELLE = 3.0                                      # U142 H1 (belegt 11.10.): Konten long/short ≥ 3
WORT_VERBOTEN = ("kaufen", "verkaufen", "kaufsignal", "verkaufssignal", "bullisch", "bärisch", "kursziel", "einstieg", "ausstieg")

# Prüfstände (KONZEPT_Chartbild.md 3.7): fest mit Datum, jede neue Auswertung aktualisiert sie mit dem nächsten Paket.
PRUEFSTAND_STAND = "11.10.2026"
PRUEFSTAND = {
    "trend": ("U141 B2", "Über der 200-Tage-Linie (T200) war nicht sicherer als Halten (ΔSR +0,20, p Holm 0,52)."),
    "bein": ("U141 A", "Rallyes und Rücksetzer wie ein Zufallsweg mit derselben Drift und Schwankung (p Holm 0,89/0,89/0,93): "
                       "der Median beschreibt, er ist kein Ziel."),
    "rsi": ("U141 C3", "RSI ≥ 80 vor Rücksetzern: kein Effekt (RR 1,01)."),
    "funding": ("U141 C2", "Funding-Druck ≥ 2 vor Rücksetzern: eher weniger (RR 0,67), nicht belegt."),
    "oi": ("U141 C1", "OI-Perzentil ≥ 0,90 vor Rücksetzern: Hinweis (RR 1,60), nicht belegt."),
    "fng": ("U141 C4", "Fear & Greed ≥ 80 vor Rücksetzern: eher weniger (RR 0,37), nicht belegt."),
    "konten": ("U142 H1", "Konten ≥ 3 vor einem Rücksetzer in 7 Tagen: belegt (RR 2,77; 20 % nach dem Signal gegen 7 % sonst, "
                          "p Holm 0,012, beide Hälften) -- ein Risikohinweis: in rund 4 von 5 Fällen folgte kein Rücksetzer."),
    "top_pos": ("U142 H2", "Top-Trader-Regel und Richtung des nächsten Tages: nicht belegt (p Holm 0,38); die Regel steht fast immer "
                           "auf „Kauf“."),
    "liq": ("U110", "Anziehung der Liquidationscluster bisher nicht belegt (Urteil ab 25.10.)."),
    "orders": ("U143 Stufe 2", "Wände, Take-Profits und Stops der Großkonten: ungeprüft."),
    "swing": ("U143 Stufe 2", "Swing-Hochs und -Tiefs: ungeprüft."),
    "rund": ("Literatur", "Runde Zahlen bei BTC ohne Renditemuster (Urquhart 2017); hier ungeprüft."),
    "band": ("U138 P0.2", "HAR schlägt EWMA bei 1 Tag in allen sechs Coins; das 80-%-Band hielt bei BTC, ETH und HYPE (79,5–84,4 %), "
                          "bei ZEC (74–76 %), XMR (76–77 %) und PAXG (69–72 %) war es zu schmal."),
}
BAND_P02 = {"BTC": "hielt in P0.2", "ETH": "hielt in P0.2", "HYPE": "hielt in P0.2", "ZEC": "in P0.2 zu schmal: 74–76 %",
            "XMR": "in P0.2 zu schmal: 76–77 %", "PAXG": "in P0.2 zu schmal: 69–72 %"}
FNG_KLASSE = ((24, "extreme Angst"), (44, "Angst"), (55, "neutral"), (75, "Gier"), (100, "extreme Gier"))

# Niveau-Arten: Schlüssel, Name, Prüfstand, Farbe (wie im Live-Chart)
ORDER_ARTEN = (("support", "limit_buy", -1, "best", "Kaufwand (Support)", "#39d3ff"),
               ("resistance", "limit_sell", 1, "best", "Verkaufswand (Resistance)", "#c678dd"),
               ("tp_long", "tp_sell", 1, "best", "Take-Profits der Longs", "#8b949e"),
               ("tp_short", "tp_buy", -1, "best", "Take-Profits der Shorts", "#8b949e"),
               ("stop_sell", "stop_sell", -1, "best", "Sell-Stops (größtes Cluster)", "#e04b4b"),
               ("stop_sell_near", "stop_sell", -1, "nearest", "Sell-Stops (nächstes Cluster)", "#e04b4b"),
               ("stop_buy", "stop_buy", 1, "best", "Buy-Stops (größtes Cluster)", "#3ba55d"),
               ("stop_buy_near", "stop_buy", 1, "nearest", "Buy-Stops (nächstes Cluster)", "#3ba55d"))


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    """23.66: gerundete Null ohne Vorzeichen („0,0 σ“ statt „-0,0 σ“ bzw. „+0,0“)."""
    t = RG._de(x, nd, vz)
    if t[:1] in "+-" and not any(c in "123456789" for c in t):
        t = t[1:]
    return t


def _px(x) -> str:
    return ZY._px(x)


def _dt(tag) -> str:
    return ZY._dt(tag)


def _pr(x, nd: int = 1, vz: bool = True) -> str:
    """Anteil als Prozent (x = 0,05 -> „+5,0 %“)."""
    if x is None or not np.isfinite(x):
        return "—"
    return _de(float(x) * 100.0, nd, vz) + " %"


def _tage(k: int) -> str:
    return f"{k} {'Tag' if k == 1 else 'Tagen'}"


def _usd(x) -> str:
    if x is None or not np.isfinite(x):
        return "—"
    a = abs(x)
    if a >= 1e9:
        return _de(x / 1e9, 2) + " Mrd"
    if a >= 1e6:
        return _de(x / 1e6, 1) + " Mio"
    if a >= 1e3:
        return _de(x / 1e3, 0) + " Tsd"
    return _de(x, 0)


def _g(x, sig: int = 6):
    """Zahl für JSON: endlich und auf sig Stellen gerundet, sonst None."""
    if x is None:
        return None
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(xf):
        return None
    return float(f"{xf:.{sig}g}")


def _liste(a, sig: int = 6) -> list:
    return [_g(v, sig) for v in np.asarray(a, dtype=float)]


def _ohne_nan(o):
    if isinstance(o, float):
        return None if not math.isfinite(o) else o
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, dict):
        return {str(k): _ohne_nan(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_ohne_nan(v) for v in o]
    return o


def fng_klasse(v) -> str:
    if v is None or not np.isfinite(v):
        return "—"
    for grenze, name in FNG_KLASSE:
        if v <= grenze:
            return name
    return FNG_KLASSE[-1][1]


# ================================================================================================ Lesen (nur lesend)

def _ro(pfad: str | None):
    if not pfad or not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, check_same_thread=False)


def tageskerzen(con, coin: str, jetzt: int) -> dict:
    """
    Abgeschlossene Tageskerzen aus daily_bars (vor 00:00 UTC heute) auf lückenloser Achse (hl_zyklus.achse: Lücken bis 3 Tage
    aufgefüllt, nach längeren beginnt die Reihe neu). Aufgefüllte Tage: Eröffnung = Hoch = Tief = Schluss des Vortags.
    """
    heute = int(jetzt) // TAG
    if con is None:
        return {"fehlt": "Hauptdatenbank nicht lesbar"}
    try:
        rows = con.execute("SELECT ts, open, high, low, close, source FROM daily_bars WHERE coin=? AND ts < ? ORDER BY ts",
                           (coin, heute * TAG)).fetchall()
    except sqlite3.Error as e:
        return {"fehlt": f"daily_bars nicht lesbar ({type(e).__name__})"}
    if not rows:
        return {"fehlt": "keine Tageskerzen in daily_bars (hl_binance lädt sie alle 6 h)"}
    a = np.array([[float(x) if x is not None else np.nan for x in r[:5]] for r in rows], dtype=float)
    quelle = rows[-1][5] or "—"
    ok = np.all(np.isfinite(a[:, 1:5]), axis=1) & np.all(a[:, 1:5] > 0, axis=1)
    a = a[ok]
    if not len(a):
        return {"fehlt": "keine gültigen Tageskerzen"}
    tag = (a[:, 0] // TAG).astype(np.int64)
    ax = ZY.achse(tag, a[:, 4])
    if ax is None:
        return {"fehlt": "keine gültigen Tageskerzen"}
    t0 = int(ax["tag0"]); c = ax["c"]; n = len(c)
    o = np.full(n, np.nan); h = np.full(n, np.nan); l_ = np.full(n, np.nan)
    i = tag - t0; m = (i >= 0) & (i < n)
    o[i[m]] = a[m, 1]; h[i[m]] = a[m, 2]; l_[i[m]] = a[m, 3]
    leer = ~np.isfinite(o)
    o[leer] = c[leer]; h[leer] = c[leer]; l_[leer] = c[leer]
    h = np.maximum(h, np.maximum(o, c)); l_ = np.minimum(l_, np.minimum(o, c))
    letzter = t0 + n - 1
    return {"tag0": t0, "n": n, "o": o, "h": h, "l": l_, "c": c, "quelle": quelle, "gefuellt": int(ax["gefuellt"]),
            "lange_luecken": ax["lange_luecken"], "letzter_tag": letzter, "alter_tage": heute - 1 - letzter}


def kerzen30(coin: str, db: str, jetzt: int) -> dict:
    """30-min-Kerzen der letzten HAR_TAGE Tage: swing.db (BTC, ETH, ZEC, XMR, HYPE), regime.db (PAXG); dazu Funding (swing.db)."""
    ab = int(jetzt) - (HAR_TAGE + 1) * TAG
    if coin in SW.COINS:
        pfad = SW.swing_pfad(db); name = "swing.db"
    elif coin in RG.COINS:
        pfad = RG.regime_pfad(db); name = "regime.db"
    else:
        return {"fehlt": f"keine 30-min-Kerzen für {coin}"}
    con = _ro(pfad)
    if con is None:
        return {"fehlt": f"{name} fehlt"}
    try:
        if name == "swing.db":
            K = SW.kerzen_lesen(con, coin, ab=ab)
            F = SW.funding_lesen(con, coin, ab=int(jetzt) - 120 * TAG)
        else:
            rows = con.execute("SELECT ts, o, h, l, c, v FROM rg_klines WHERE coin=? AND ts>=? ORDER BY ts", (coin, ab)).fetchall()
            K = None
            if rows:
                a = np.array(rows, dtype=float)
                K = {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}
            F = None
    except sqlite3.Error as e:
        return {"fehlt": f"{name} nicht lesbar ({type(e).__name__})"}
    finally:
        con.close()
    if K is None or not len(K["ts"]):
        return {"fehlt": f"keine 30-min-Kerzen für {coin} in {name}"}
    return {"K": K, "F": F if F is not None and len(F["ts"]) else None, "quelle": name, "letzte": int(K["ts"][-1])}


# ================================================================================================ Bausteine

def sma(c: np.ndarray, n: int) -> np.ndarray:
    c = np.asarray(c, dtype=float); out = np.full(len(c), np.nan)
    if len(c) >= n:
        cs = np.concatenate([[0.0], np.cumsum(c)])
        out[n - 1:] = (cs[n:] - cs[:-n]) / n
    return out


def trendlage(D: dict) -> dict:
    """SMA 50/200, Abstand zur 200-Tage-Linie, Steigung der 50-Tage-Linie (seit k Tagen), Lage 50 zu 200 und letzter Wechsel."""
    c = D["c"]; n = len(c); d = n - 1; t0 = D["tag0"]
    ma50 = sma(c, 50); ma200 = sma(c, 200)
    out = {"ma50": ma50, "ma200": ma200, "tag": t0 + d, "schluss": float(c[d]), "ma50_jetzt": float(ma50[d]), "ma200_jetzt": float(ma200[d]),
           "n_tage": n}
    out["abstand200"] = float(c[d] / ma200[d] - 1.0) if np.isfinite(ma200[d]) else float("nan")
    out["abstand50"] = float(c[d] / ma50[d] - 1.0) if np.isfinite(ma50[d]) else float("nan")
    if d >= 1 and np.isfinite(ma50[d]) and np.isfinite(ma50[d - 1]) and ma50[d] != ma50[d - 1]:
        s = int(np.sign(ma50[d] - ma50[d - 1])); k = 0
        for j in range(d, 0, -1):
            if not (np.isfinite(ma50[j]) and np.isfinite(ma50[j - 1])) or int(np.sign(ma50[j] - ma50[j - 1])) != s:
                break
            k += 1
        out["steigung50"] = s; out["seit50"] = k
    if np.isfinite(ma50[d]) and np.isfinite(ma200[d]):
        sg = np.where(np.isfinite(ma50) & np.isfinite(ma200), np.sign(ma50 - ma200), 0.0)
        jetzt_s = int(sg[d]); out["lage50_200"] = jetzt_s
        j = d
        while j > 0 and sg[j - 1] == jetzt_s:
            j -= 1
        if j > 0 and sg[j - 1] != 0:
            out["kreuz_tag"] = t0 + j; out["kreuz_art"] = "golden" if jetzt_s > 0 else "death"
    return out


def beine_stand(D: dict, schwellen=SCHWELLEN) -> list:
    """Je Schwelle wie U141 Teil A: laufendes Bein (hl_zyklus._dc_stand), abgeschlossene Beine (zyklen_beschreiben), Zickzack."""
    c = D["c"]; n = len(c); t0 = D["tag0"]
    R = {"c": c, "n": n, "tag0": t0}; Xl = np.log(c)[None, :]; jahre = (n - 1) / 365.25
    out = []
    for X in schwellen:
        u, v = math.log(1 + X), -math.log(1 - X)
        Dd = ZY.dc_batch(Xl, u, v, i0=0)
        Bn = ZY.beine(Dd)
        info = ZY.zyklen_beschreiben(Bn, 0, jahre, X)
        st = ZY._dc_stand(Dd, R, X)
        e = {"X": X, "mode": int(st.get("mode", 0)), "bestaetigt_ab": st.get("bestaetigt_ab"), "schluss": float(c[-1]), "tag": t0 + n - 1,
             "n_auf": info["n"], "med_auf": info["groesse"], "q_auf": info["groesse_q"], "dauer_auf": info["dauer"],
             "dauer_auf_q": info["dauer_q"], "n_ab": info["n_ab"], "med_ab": info["tiefe"], "q_ab": info["tiefe_q"],
             "dauer_ab": info["dauer_ab"], "dauer_ab_q": info["dauer_ab_q"], "jahre": jahre,
             "zickzack": [(int(t0 + i), float(math.exp(x)), int(ty)) for i, x, ty in zip(Dd["ext_i"], Dd["ext_x"], Dd["typ"])]}
        if e["mode"] == 1:
            e.update(start_tag=st.get("tief_tag"), start_px=st.get("tief"), extrem_tag=st.get("hoch_tag"), extrem_px=st.get("hoch"))
        elif e["mode"] == -1:
            e.update(start_tag=st.get("hoch_tag"), start_px=st.get("hoch"), extrem_tag=st.get("tief_tag"), extrem_px=st.get("tief"))
        if e.get("start_px") and e.get("extrem_px"):
            e["groesse_bisher"] = e["extrem_px"] / e["start_px"] - 1.0
            e["vom_extrem"] = float(c[-1]) / e["extrem_px"] - 1.0
            e["alter_tage"] = (t0 + n - 1) - int(e["start_tag"])
        out.append(e)
    return out


def swings(D: dict, n: int = PIVOT_N, tage: int = PIVOT_TAGE) -> dict:
    """Swing-Hoch: Hoch über den n Tagen davor und mindestens so hoch wie die n Tage danach (erst dann bestätigt); Tief spiegelbildlich."""
    h, l_ = D["h"], D["l"]; N = len(h); a = max(n, N - tage)
    hoch, tief = [], []
    for t in range(a, N - n):
        if h[t] > np.max(h[t - n:t]) and h[t] >= np.max(h[t + 1:t + n + 1]):
            hoch.append((D["tag0"] + t, float(h[t])))
        if l_[t] < np.min(l_[t - n:t]) and l_[t] <= np.min(l_[t + 1:t + n + 1]):
            tief.append((D["tag0"] + t, float(l_[t])))
    return {"hoch": hoch, "tief": tief}


def runde(px: float) -> tuple:
    """Nächste runde Zahl darunter und darüber. Schritt nach der führenden Ziffer: 1, 2 oder 5 Einheiten der zweiten Stelle
    (BTC um 62.000: 5.000; ETH um 2.400: 200; ZEC um 52: 5) -- immer 4–10 % des Kurses."""
    if not px or not np.isfinite(px) or px <= 0:
        return (float("nan"), float("nan"), float("nan"))
    e = math.floor(math.log10(px)); lead = px / 10.0 ** e
    s = (1.0 if lead < 2 else (2.0 if lead < 5 else 5.0)) * 10.0 ** (e - 1)
    k = px / s
    unten = math.floor(k + 1e-12) * s; oben = math.ceil(k - 1e-12) * s
    if unten >= px * (1 - 1e-12):
        unten -= s
    if oben <= px * (1 + 1e-12):
        oben += s
    return (float(unten), float(oben), float(s))


def _schritt(s_: float) -> str:
    """Schritt der runden Zahlen lesbar: ganze Zahlen ohne Nachkommastellen (5.000, 200, 5, 2), darunter so viele Stellen wie nötig."""
    if s_ >= 1:
        return ZY._tausend(round(s_))
    return _de(s_, max(1, -math.floor(math.log10(s_) + 1e-12)))


def perzentil(x, w) -> float:
    """Mittelrang von x unter den Werten w (wie hl_zyklus.oi_perzentil): mindestens PERZ_MIN endliche, nicht alle gleich."""
    w = np.asarray(w, dtype=float); w = w[np.isfinite(w)]
    if x is None or not np.isfinite(x) or len(w) < PERZ_MIN or w.max() - w.min() <= 1e-12 * max(1.0, abs(w.max())):
        return float("nan")
    return float((np.sum(w < x) + 0.5 * np.sum(w == x)) / len(w))


def har_jetzt(P: dict, h: int, d: int | None = None) -> dict | None:
    """
    HAR-log wie hl_regime.har_prognosen (P0.2), einmal geschätzt für den Prognosetag d (Standard: letzter Tag mit voller RV und
    Schluss): Schätztage d' mit Ziel d'+1 … d'+h ≤ d (dieselbe Sperre), Prognose F = h · e^(X_d·β + s²/2), Band aus den 10-/90-%-
    Quantilen der standardisierten h-Tage-Renditen der Schätztage. Am Vortag eines Bewertungsmonats gleich har_prognosen.
    """
    RV = P["RV"]; nt = P["n_tage"]; xe = P["xe"]
    if d is None:
        idx = np.nonzero(np.isfinite(RV) & np.isfinite(xe))[0]
        if not len(idx):
            return None
        d = int(idx[-1])
    if d < 0 or d >= nt:
        return None
    rv = RG._ffill(RV)
    with np.errstate(divide="ignore", invalid="ignore"):
        X = np.column_stack([np.ones(nt), np.log(rv), np.log(RG._rollmittel(rv, 7)), np.log(RG._rollmittel(rv, 30))])
    ziel = RG._vorwaerts_summe(RV, h)
    with np.errstate(divide="ignore", invalid="ignore"):
        y = np.log(ziel / h)
    r_h = np.full(nt, np.nan); r_h[: nt - h] = xe[h:] - xe[: nt - h]
    tr = np.arange(29, max(29, d - h + 1))
    tr = tr[np.all(np.isfinite(X[tr]), axis=1) & np.isfinite(y[tr])] if len(tr) else tr
    if len(tr) < 200 or not np.all(np.isfinite(X[d])) or not np.isfinite(xe[d]):
        return None
    beta, *_ = np.linalg.lstsq(X[tr], y[tr], rcond=None)
    res = y[tr] - X[tr] @ beta
    s2e = float(np.var(res))
    z_tr = r_h[tr] / np.sqrt(h * np.exp(X[tr] @ beta + s2e / 2))
    z_tr = z_tr[np.isfinite(z_tr)]
    if len(z_tr) < 100:
        return None
    F = float(h * np.exp(X[d] @ beta + s2e / 2))
    return {"d": d, "F": F, "q_lo": float(np.quantile(z_tr, 0.10)), "q_hi": float(np.quantile(z_tr, 0.90)), "n_schaetz": int(len(tr)),
            "basis_x": float(xe[d])}


def trefferquote(P: dict, h: int, tage: int = TREFFER_TAGE, breite: float = 1.0) -> dict:
    """Rollierend wie P0.2 (har_prognosen): Anteil der letzten `tage` Prognosetage, an denen die h-Tage-Rendite im Band lag."""
    F_har, q_lo, q_hi, r_h, _ = RG.har_prognosen(P, h)
    nt = P["n_tage"]; ab = max(0, nt - h - tage)
    ok = np.isfinite(F_har) & np.isfinite(r_h) & np.isfinite(q_lo) & np.isfinite(q_hi)
    ok[:ab] = False
    n = int(ok.sum())
    if n < TREFFER_MIN:
        return {"n": n, "treffer": float("nan"), "se": float("nan")}
    sw = np.sqrt(F_har[ok])
    hit = (r_h[ok] >= breite * q_lo[ok] * sw) & (r_h[ok] <= breite * q_hi[ok] * sw)
    return {"n": n, "treffer": float(hit.mean()), "se": float(math.sqrt(0.16 * h / n))}


def band(P: dict, coin: str) -> dict:
    """80-%-Band für den Schluss in 1 und 7 Tagen ab dem letzten vollen Tag (Schluss 00:00 UTC), mit Trefferquote der letzten 365 Tage."""
    out = {"p02": BAND_P02.get(coin, "—")}
    for h in HAR_H:
        J = har_jetzt(P, h)
        if J is None:
            out[f"h{h}"] = None
            continue
        sw = math.sqrt(J["F"]); b = math.exp(J["basis_x"])
        T = trefferquote(P, h)
        out[f"h{h}"] = {"lo": b * math.exp(J["q_lo"] * sw), "hi": b * math.exp(J["q_hi"] * sw), "F": J["F"], "sigma": sw,
                        "q_lo": J["q_lo"], "q_hi": J["q_hi"], "treffer": T["treffer"], "n": T["n"], "se": T["se"]}
        out["basis_tag"] = P["tag0"] + J["d"]; out["basis_px"] = b
    if out.get("h1"):
        out["sigma_tag"] = out["h1"]["sigma"]
    return out


def funding_druck(K: dict, F: dict | None) -> dict:
    """Funding-Druck z30 wie U141 C2 (hl_swing.Kennzahlen.fz) am letzten vollen Tag; dazu die jüngste Rate."""
    if F is None or not len(F["ts"]):
        return {"fehlt": "kein Funding in swing.db"}
    T = SW.tagesreihen(K)
    if T is None:
        return {"fehlt": "keine Tagesreihe"}
    fz = SW.Kennzahlen(T, F).fz(30)
    ok = np.nonzero(T["voll"] & np.isfinite(fz))[0]
    out = {"rate": float(F["rate"][-1]), "rate_ts": int(F["ts"][-1])}
    if len(ok):
        d = int(ok[-1]); out.update(z=float(fz[d]), tag=int(T["d0"] + d))
    return out


def tagesstaende(ts: np.ndarray, werte: np.ndarray, tag_a: int, tag_e: int) -> np.ndarray:
    """Tagesende-Stand je Tag tag_a … tag_e: jüngste Zeile ≤ Ende des Tags, höchstens SNAPSHOT_ALTER alt (wie hl_hebel.tafel_bauen)."""
    tage = np.arange(tag_a, tag_e + 1, dtype=np.int64); ziel = (tage + 1) * TAG
    out = np.full(len(tage), np.nan)
    if not len(ts):
        return out
    j = np.searchsorted(ts, ziel, side="right") - 1; jj = np.clip(j, 0, None)
    ok = (j >= 0) & (ts[jj] >= ziel - SNAPSHOT_ALTER)
    out[ok] = werte[jj[ok]]
    return out


def positionierung(coin: str, db: str, con_haupt, jetzt: int) -> dict:
    """OI (Coins), Konten, Top-Trader nach Positionen: Tagesstände aus hebel.db, live aus bnc_metrics; Perzentil gegen 90 Tagesstände."""
    heute = int(jetzt) // TAG; out = {"fehlt": []}
    staende = {}
    con = _ro(HB.hebel_pfad(db))
    if con is None:
        out["fehlt"].append("hebel.db fehlt")
    else:
        try:
            rows = con.execute("SELECT ts, oi, konten, top_pos FROM hb_metrics WHERE coin=? AND ts >= ? ORDER BY ts",
                               (coin, (heute - 130) * TAG)).fetchall()
        except sqlite3.Error as e:
            rows = []; out["fehlt"].append(f"hebel.db nicht lesbar ({type(e).__name__})")
        finally:
            con.close()
        if rows:
            a = np.array([[np.nan if x is None else float(x) for x in r] for r in rows], dtype=float)
            ts = a[:, 0].astype(np.int64)
            for k, sp in (("oi", 1), ("konten", 2), ("top_pos", 3)):
                staende[k] = tagesstaende(ts, a[:, sp], heute - 125, heute - 1)
            out["archiv_bis"] = int(ts[-1])
        elif not out["fehlt"]:
            out["fehlt"].append(f"keine metrics für {coin} in hebel.db")
    live = {}
    if con_haupt is not None:
        for metric, k in (("open_interest", "oi"), ("global_ls_account", "konten"), ("top_ls_position", "top_pos")):
            try:
                r = con_haupt.execute("SELECT ts, value FROM bnc_metrics WHERE coin=? AND metric=? AND ts >= ? AND ts < 100000000000 "
                                      "ORDER BY ts DESC LIMIT 1", (coin, metric, int(jetzt) - FRISCH["live"])).fetchone()
            except sqlite3.Error:
                r = None
            if r and r[1] is not None:
                live[k] = (int(r[0]), float(r[1]))
    for k in ("oi", "konten", "top_pos"):
        s = staende.get(k)
        e: dict = {}
        if k in live:
            e.update(wert=live[k][1], ts=live[k][0], art="live")
            if s is not None:
                e["pz"] = perzentil(live[k][1], s[-PERZ_FENSTER:])
        elif s is not None and np.isfinite(s).any():
            i = int(np.nonzero(np.isfinite(s))[0][-1])
            if (len(s) - 1 - i) * TAG <= FRISCH["archiv"]:
                e.update(wert=float(s[i]), tag=heute - len(s) + i, art="Tagesstand")
                e["pz"] = perzentil(float(s[i]), s[max(0, i - PERZ_FENSTER):i])
        if s is not None:
            e["verlauf"] = s
        out[k] = e
    return out


def fear_greed(db: str, jetzt: int) -> dict:
    con = MK.lesen(MK.makro_pfad(db))
    if con is None:
        return {"fehlt": "makro.db fehlt"}
    try:
        t, w = MK.Reihen(con)("fng:wert")
    except sqlite3.Error as e:
        return {"fehlt": f"makro.db nicht lesbar ({type(e).__name__})"}
    finally:
        con.close()
    ok = np.isfinite(w)
    if not ok.any():
        return {"fehlt": "kein Fear & Greed in makro.db"}
    i = int(np.nonzero(ok)[0][-1]); tag = int(t[i]); v = float(w[i])
    if (int(jetzt) // TAG - tag) * TAG > FRISCH["fng"]:
        return {"fehlt": f"Fear & Greed zuletzt am {_dt(tag)}"}
    return {"wert": v, "tag": tag, "klasse": fng_klasse(v)}


# ================================================================================================ Niveaus

def _niveau(key, name, px_n, px, sig, usd=None, n=None, quelle="", alter_s=None, pruef="", farbe="#8b949e", art="") -> dict:
    d = px_n / px - 1.0
    return {"key": key, "name": name, "px": float(px_n), "dist": d, "seite": "oben" if px_n > px else "unten",
            "sigma": (math.log(px_n / px) / sig) if sig and np.isfinite(sig) and sig > 0 else float("nan"),
            "usd": usd, "n": n, "quelle": quelle, "alter_s": alter_s, "pruef": pruef, "farbe": farbe, "art": art}


def niveaus(live: dict, px: float, sig: float, sw: dict | None, jetzt: int) -> tuple:
    """Alle Niveaus mit Abstand in % und σ, nach Preis von oben nach unten; dazu die Gründe fehlender Arten."""
    L = []; fehlt = []
    if not px or not np.isfinite(px):
        return L, ["kein Kurs"]
    st = (live or {}).get("stops") or {}
    S = [s for s in (st.get("clusters") or []) if s.get("px") and abs(s["px"] / px - 1) <= ORDER_BEREICH]
    # 23.66: Mindestgröße für das größte LIQUIDATIONScluster -- ½ Stundenvolumen wie beim „nächsten“ und wie die durchgezogene Linie im
    # Live-Chart (LIQ_TRAEGT). Am 11.10. standen 16 USD (XMR) und 317 USD (PAXG) als „größtes Cluster“ in der Tabelle: Rauschen.
    # Orders der Großkonten bleiben wie im Live-Chart (keyLevels) ohne Mindestgröße -- ein ½-Stundenvolumen-Maßstab hätte bei BTC
    # fast alle Wände (0,7–13 Mio gegen ein Stundenvolumen um 100 Mio) verdeckt.
    vol = float(((live or {}).get("depth") or {}).get("vol_1h") or 0.0)
    mindest = LIQ_TRAEGT * vol if vol > 0 else None
    alt = (int(jetzt) - int(st["ts"])) if st.get("ts") else None
    if (live or {}).get("fehler_stops"):
        fehlt.append(f"Orders der Großkonten nicht lesbar ({live['fehler_stops']})")
    elif not S:
        fehlt.append("keine Orders der Großkonten innerhalb ±30 %" if st.get("n_whales") else "keine Order-Abfragen der Großkonten")
    elif alt is not None and alt > FRISCH["orders"]:
        fehlt.append(f"Orders der Großkonten zuletzt vor {_de(alt / 3600, 1)} h"); S = []
    for key, kind, sign, wie, name, farbe in ORDER_ARTEN:
        cand = [s for s in S if s.get("kind") == kind and np.sign(s["px"] - px) == sign]
        if not cand:
            continue
        s = max(cand, key=lambda x: x.get("notional") or 0) if wie == "best" else min(cand, key=lambda x: abs(x["px"] - px))
        if wie == "nearest" and any(l_["px"] == s["px"] and l_["art"] == kind for l_ in L):
            continue
        L.append(_niveau(key, name, s["px"], px, sig, usd=s.get("notional"), n=s.get("addrs") or s.get("n"),
                         quelle=f"Großkonten (Hyperliquid), {st.get('n_whales') or 0} Konten abgefragt", alter_s=alt, pruef="orders",
                         farbe=farbe, art=kind))
    dp = (live or {}).get("depth")
    if (live or {}).get("fehler_depth"):
        fehlt.append(f"Heatmap nicht lesbar ({live['fehler_depth']})")
    elif not dp or not dp.get("rows"):
        fehlt.append("kein Heatmap-Stand (Liquidationscluster)")
    else:
        alt_h = int(jetzt) - int(dp.get("ts") or 0)
        if alt_h > FRISCH["heatmap"]:
            fehlt.append(f"Heatmap-Stand vor {_de(alt_h / 60, 0)} min")
        else:
            vol = float(dp.get("vol_1h") or 0.0)
            for seite, side, vergleich, name, farbe in (("unten", "long", lambda p: LIQ_UNTEN * px < p < px, "Long-Liquidationen", "#e04b4b"),
                                                        ("oben", "short", lambda p: px < p < LIQ_OBEN * px, "Short-Liquidationen", "#3ba55d")):
                R = [r for r in dp["rows"] if r.get("side") == side and r.get("bucket_px") and vergleich(r["bucket_px"]) and (r.get("notional") or 0) > 0]
                if not R:
                    continue
                g = max(R, key=lambda r: r["notional"])
                if mindest is None or g["notional"] < mindest:      # 23.66: Mindestgröße wie oben
                    fehlt.append(f"{name}: kein nennenswertes Cluster ("
                                 + (f"größtes {_usd(g['notional'])} USD unter ½ Stundenvolumen {_usd(mindest)} USD)" if mindest is not None
                                    else "Stundenvolumen fehlt, ohne Maßstab nicht gezeigt)"))
                    continue
                L.append(_niveau(f"liq_{side}", f"{name} (größtes Cluster)", g["bucket_px"], px, sig, usd=g["notional"], n=g.get("n_pos"),
                                 quelle="Heatmap (Hyperliquid-Positionen)", alter_s=alt_h, pruef="liq", farbe=farbe, art=f"liq_{side}"))
                if vol > 0:
                    T_ = [r for r in R if r["notional"] >= LIQ_TRAEGT * vol]
                    if T_:
                        nah = min(T_, key=lambda r: abs(r["bucket_px"] - px))
                        if nah["bucket_px"] != g["bucket_px"]:
                            L.append(_niveau(f"liq_{side}_nah", f"{name} (nächstes ≥ ½ Stundenvolumen)", nah["bucket_px"], px, sig,
                                             usd=nah["notional"], n=nah.get("n_pos"), quelle="Heatmap (Hyperliquid-Positionen)", alter_s=alt_h,
                                             pruef="liq", farbe=farbe, art=f"liq_{side}"))
    if sw:
        nah = lambda p_: abs(p_ / px - 1) <= ORDER_BEREICH                    # wie die Orders: höchstens ±30 %
        oben = sorted([s for s in sw["hoch"] if s[1] > px and nah(s[1])], key=lambda s: s[1])[:2]
        unten = sorted([s for s in sw["tief"] if s[1] < px and nah(s[1])], key=lambda s: -s[1])[:2]
        for i, (t, p) in enumerate(oben):
            L.append(_niveau(f"swing_hoch_{i}", f"Swing-Hoch vom {_dt(t)}", p, px, sig, quelle="Tageskerzen", pruef="swing",
                             farbe="#c9d1d9", art="swing_hoch"))
        for i, (t, p) in enumerate(unten):
            L.append(_niveau(f"swing_tief_{i}", f"Swing-Tief vom {_dt(t)}", p, px, sig, quelle="Tageskerzen", pruef="swing",
                             farbe="#c9d1d9", art="swing_tief"))
    u_, o_, s_ = runde(px)
    if np.isfinite(u_):
        L.append(_niveau("rund_unten", f"runde Zahl ({_schritt(s_)}er-Schritt)", u_, px, sig, quelle="Rechnung", pruef="rund", farbe="#6e7681", art="rund"))
        L.append(_niveau("rund_oben", f"runde Zahl ({_schritt(s_)}er-Schritt)", o_, px, sig, quelle="Rechnung", pruef="rund", farbe="#6e7681", art="rund"))
    L.sort(key=lambda x: -x["px"])
    return L, fehlt


# ================================================================================================ Zusammensetzen

_MEMO: dict = {"lock": threading.Lock(), "items": {}}


def _memo(key, fn, ttl: float = CACHE_S):
    with _MEMO["lock"]:
        hit = _MEMO["items"].get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    v = fn()
    with _MEMO["lock"]:
        _MEMO["items"][key] = (time.time(), v)
        if len(_MEMO["items"]) > 48:
            alt = min(_MEMO["items"], key=lambda k: _MEMO["items"][k][0]); _MEMO["items"].pop(alt, None)
    return v


def tagesteil(db: str, coin: str, jetzt: int) -> dict:
    """Alles, was sich höchstens einmal am Tag ändert (Tageskerzen, Trend, Beine, Swings, Band, Funding, Fear & Greed)."""
    E: dict = {"fehlt": [], "nicht": []}
    con = _ro(db)
    try:
        D = tageskerzen(con, coin, jetzt)
    finally:
        if con is not None:
            con.close()
    if "fehlt" in D:
        E["fehlt"].append(f"Tageskerzen: {D['fehlt']}")
    elif D["alter_tage"] > FRISCH["tage"]:
        E["fehlt"].append(f"Tageskerzen zuletzt am {_dt(D['letzter_tag'])} -- Trend, Bein und Swings ausgeblendet")
    else:
        E["tage"] = D
        E["trend"] = trendlage(D)
        E["beine"] = beine_stand(D, SCHWELLEN_GOLD if coin == "PAXG" else SCHWELLEN)
        E["swings"] = swings(D)
        E["rsi"] = SW.rsi_wilder(D["c"], 14)
        r = np.full(D["n"], np.nan); r[1:] = np.diff(np.log(D["c"]))
        E["sigma_ewma"] = float(ZY.sigma_batch(r[None, :])[0][-1])
    K = kerzen30(coin, db, jetzt)
    if "fehlt" in K:
        E["fehlt"].append(f"Schwankungsband: {K['fehlt']}")
    elif int(jetzt) - K["letzte"] > FRISCH["har"]:
        E["fehlt"].append(f"Schwankungsband: 30-min-Kerzen zuletzt {time.strftime('%d.%m. %H:%M', time.gmtime(K['letzte']))} UTC ({K['quelle']})")
    else:
        try:
            P = RG.vorbereiten(K["K"])
            B = band(P, coin)
            if not B.get("h1") and not B.get("h7"):
                E["fehlt"].append("Schwankungsband: Historie zu kurz für das HAR (mindestens rund 230 Tage)")
            else:
                B["quelle"] = K["quelle"]; E["band"] = B
        except Exception as e:                                 # das Band darf den Rest nie verhindern
            E["fehlt"].append(f"Schwankungsband: {type(e).__name__}: {e}"[:160])
        if K.get("F") is not None:
            f = funding_druck(K["K"], K["F"])
            if "fehlt" not in f and int(jetzt) - f["rate_ts"] <= FRISCH["funding"]:
                E["funding"] = f
    if coin == "PAXG":                                       # bewusst nicht gezeigt (KONZEPT_Chartbild.md 3.6) -- keine Lücke
        E["nicht"] += ["Funding-Druck: PAXG ohne Perp-Funding in swing.db", "Fear & Greed: Krypto-Stimmungsindex, für Gold nicht gezeigt"]
    else:
        if "funding" not in E:
            E["fehlt"].append("Funding-Druck: keine frischen Funding-Daten in swing.db")
        g = fear_greed(db, jetzt)
        if "fehlt" in g:
            E["fehlt"].append(f"Fear & Greed: {g['fehlt']}")
        else:
            E["fng"] = g
    return E


def berechnen(db: str, coin: str, live: dict | None, jetzt: int | None = None, cache: bool = True) -> dict:
    t_start = time.time()
    jetzt = int(jetzt or time.time()); live = live or {}
    heute = jetzt // TAG
    E = dict(_memo((db, coin, heute), lambda: tagesteil(db, coin, jetzt)) if cache else tagesteil(db, coin, jetzt))
    E["fehlt"] = list(E.get("fehlt") or []); E["nicht"] = list(E.get("nicht") or [])
    px = live.get("kurs"); kts = live.get("kurs_ts")
    if px and kts and jetzt - int(kts) <= FRISCH["kurs"]:
        E["kurs"] = {"px": float(px), "ts": int(kts), "quelle": "Hyperliquid (1-min-Kerze)"}
    elif "tage" in E:
        E["kurs"] = {"px": float(E["tage"]["c"][-1]), "ts": int((E["tage"]["letzter_tag"] + 1) * TAG), "quelle": "letzter Tagesschluss"}
        E["fehlt"].append("Kurs jetzt: keine frische 1-min-Kerze -- Abstände zum letzten Tagesschluss")
    sig = (E.get("band") or {}).get("sigma_tag") or E.get("sigma_ewma")
    p = (E.get("kurs") or {}).get("px")
    if p:
        L, f = niveaus(live, p, sig, E.get("swings"), jetzt)
        E["niveaus"] = L; E["fehlt"] += [f"Niveaus: {x}" for x in f]
    con = _ro(db)
    try:
        if coin in HB.COINS:
            E["lage"] = positionierung(coin, db, con, jetzt)
        else:
            E["lage"] = {"fehlt": []}; E["nicht"].append(f"Positionierung: keine Binance-Positionierung für {coin} (OI, Konten, Top-Trader)")
    finally:
        if con is not None:
            con.close()
    E["coin"] = coin; E["jetzt"] = jetzt
    E["lesart"] = lesart(E)
    E["rechenzeit_ms"] = int((time.time() - t_start) * 1000)
    return E


def payload(db: str, coin: str, live: dict | None, jetzt: int | None = None, cache: bool = True) -> dict:
    """Antwort für die Seite (JSON-tauglich, ohne NaN)."""
    coin = (coin or "BTC").upper()[:12]
    if coin not in COINS:
        return {"ok": True, "coin": coin, "fehlt": [f"{coin}: kein Chartbild (nur {', '.join(COINS)})"], "lesart": [], "version": VERSION_MODUL}
    E = berechnen(db, coin, live, jetzt, cache)
    out = {"ok": True, "coin": coin, "version": VERSION_MODUL, "jetzt": E["jetzt"], "kurs": E.get("kurs"), "fehlt": E["fehlt"], "nicht_gezeigt": E["nicht"],
           "lesart": E["lesart"], "pruef": {k: list(v) for k, v in PRUEFSTAND.items()}, "pruef_stand": PRUEFSTAND_STAND,
           "rechenzeit_ms": E["rechenzeit_ms"]}
    D = E.get("tage")
    if D:
        a = max(0, D["n"] - CHART_TAGE); T = E["trend"]
        out["tage"] = {"t0": D["tag0"] + a, "o": _liste(D["o"][a:]), "h": _liste(D["h"][a:]), "l": _liste(D["l"][a:]), "c": _liste(D["c"][a:]),
                       "ma50": _liste(T["ma50"][a:]), "ma200": _liste(T["ma200"][a:]), "rsi": _liste(E["rsi"][a:], 4),
                       "quelle": D["quelle"], "letzter_tag": D["letzter_tag"], "gefuellt": D["gefuellt"], "n_gesamt": D["n"]}
        out["trend"] = {k: v for k, v in T.items() if k not in ("ma50", "ma200")}
        out["rsi"] = {"wert": float(E["rsi"][-1]) if np.isfinite(E["rsi"][-1]) else None, "tag": D["letzter_tag"]}
        out["beine"] = [{k: v for k, v in b.items() if k != "zickzack"} for b in E["beine"]]
        b0 = E["beine"][0]
        t_ab = D["tag0"] + a
        vor = [z for z in b0["zickzack"] if z[0] < t_ab]
        out["zickzack"] = [[t, _g(p_), ty] for t, p_, ty in vor[-1:] + [z for z in b0["zickzack"] if z[0] >= t_ab]]
        out["swings"] = {"hoch": [[t, _g(p_)] for t, p_ in E["swings"]["hoch"]], "tief": [[t, _g(p_)] for t, p_ in E["swings"]["tief"]]}
    if E.get("band"):
        out["band"] = E["band"]
    if E.get("funding"):
        out["funding"] = E["funding"]
    if E.get("fng"):
        out["fng"] = E["fng"]
    if E.get("niveaus") is not None:
        out["niveaus"] = E["niveaus"]
    lg = E.get("lage") or {}
    out["lage"] = {k: {kk: (_liste(vv[-PERZ_FENSTER:]) if kk == "verlauf" else vv) for kk, vv in v.items()} if isinstance(v, dict) else v
                   for k, v in lg.items()}
    return _ohne_nan(out)


def payload_json(db: str, coin: str, live: dict | None) -> bytes:
    try:
        return json.dumps(payload(db, coin, live), ensure_ascii=False).encode()
    except Exception as e:                                      # nie eine kaputte Seite
        return json.dumps({"ok": False, "coin": coin, "fehlt": [f"Chartbild-Fehler: {type(e).__name__}: {e}"[:300]], "lesart": []},
                          ensure_ascii=False).encode()


# ================================================================================================ Lesart

def lesart(E: dict) -> list:
    """Fünf bis sechs Sätze in fester Reihenfolge nur aus den Zahlen (KONZEPT_Chartbild.md 4); fehlt ein Baustein, fehlt sein Satz."""
    S = []; coin = E.get("coin", "")
    T = E.get("trend")
    if T:
        if np.isfinite(T.get("abstand200", float("nan"))):
            s = (f"{coin} schloss am {_dt(T['tag'])} {_pr(abs(T['abstand200']), 1, False)} {'über' if T['abstand200'] > 0 else 'unter'} "
                 f"der 200-Tage-Linie ({_px(T['ma200_jetzt'])})")
        else:
            s = f"Für die 200-Tage-Linie fehlen noch Tage ({T['n_tage']} von 200)"
        if T.get("steigung50"):
            s += f"; die 50-Tage-Linie {'steigt' if T['steigung50'] > 0 else 'fällt'} seit {_tage(T['seit50'])}"
        S.append(s + ".")
    B = (E.get("beine") or [None])[0]
    if B and B.get("mode") in (1, -1) and B.get("start_px"):
        X = int(round(B["X"] * 100))
        if B["mode"] == 1:
            # 23.66: „Schluss“ statt „Hoch/Tief“ -- das Bein rechnet auf Tagesschlüssen (wie U141), die Swing-Punkte auf Hochs und Tiefs
            s = (f"Bein (Schwelle {X} %): aufwärts seit dem tiefsten Schluss {_px(B['start_px'])} am {_dt(B['start_tag'])} "
                 f"({_pr(B['groesse_bisher'], 1)} bis zum höchsten Schluss {_px(B['extrem_px'])}); ein Rücksetzer gilt ab "
                 f"{_px(B['bestaetigt_ab'])} (Schluss) als bestätigt.")
            if B.get("n_auf"):
                s += (f" Abgeschlossene Rallyes: Median {_pr(math.expm1(B['med_auf']), 0)} in {_tage(int(round(B['dauer_auf'])))} "
                      f"(n {B['n_auf']}) -- Größen wie ein Zufallsweg (U141), kein Ziel.")
        else:
            s = (f"Bein (Schwelle {X} %): abwärts seit dem höchsten Schluss {_px(B['start_px'])} am {_dt(B['start_tag'])} "
                 f"({_pr(B['groesse_bisher'], 1)} bis zum tiefsten Schluss {_px(B['extrem_px'])}); ein Aufschwung gilt ab "
                 f"{_px(B['bestaetigt_ab'])} (Schluss) als bestätigt.")
            if B.get("n_ab"):
                s += (f" Abgeschlossene Rücksetzer: Median {_pr(math.expm1(B['med_ab']), 0)} in {_tage(int(round(B['dauer_ab'])))} "
                      f"(n {B['n_ab']}) -- Größen wie ein Zufallsweg (U141), kein Ziel.")
        S.append(s)
    L = [l_ for l_ in (E.get("niveaus") or []) if l_["art"] != "rund" and not str(l_.get("key", "")).endswith("_near")]   # ohne Mindestgröße nicht im Satz
    nah_u = max([l_ for l_ in L if l_["seite"] == "unten"], key=lambda l_: l_["px"], default=None)
    nah_o = min([l_ for l_ in L if l_["seite"] == "oben"], key=lambda l_: l_["px"], default=None)
    if nah_u or nah_o:
        def nv(l_):
            sg = f", {_de(l_['sigma'], 1, True)} σ" if np.isfinite(l_.get("sigma", float("nan"))) else ""
            return f"{l_['name']} {_px(l_['px'])} ({_pr(l_['dist'], 1)}{sg})"
        teile = ([f"darunter {nv(nah_u)}"] if nah_u else []) + ([f"darüber {nv(nah_o)}"] if nah_o else [])
        S.append("Nächste Niveaus: " + ", ".join(teile) + " -- alle ungeprüft (Stufe 2).")
    Bd = E.get("band") or {}
    h1, h7 = Bd.get("h1"), Bd.get("h7")
    if h1 or h7:
        teile = []
        if h1:
            teile.append(f"nächster Tagesschluss {_px(h1['lo'])}–{_px(h1['hi'])}")
        if h7:
            teile.append(f"in 7 Tagen {_px(h7['lo'])}–{_px(h7['hi'])}")
        tr = [f"{_de(x['treffer'] * 100, 0)} %" for x in (h1, h7) if x and np.isfinite(x.get("treffer", float("nan")))]
        s = f"Erwartete Spanne (80 %, ab dem Schluss {_px(Bd.get('basis_px'))}): " + ", ".join(teile)
        if tr:
            s += f"; das Band traf in den letzten 365 Tagen {' bzw. '.join(tr)} (Soll 80 %, {Bd.get('p02', '—')})"
        S.append(s + ".")
    teile = []
    rsi = E.get("rsi")
    if rsi is not None and len(rsi) and np.isfinite(rsi[-1]):
        teile.append(f"RSI {_de(rsi[-1], 0)}")
    f = E.get("funding")
    if f and np.isfinite(f.get("z", float("nan"))):
        teile.append(f"Funding-Druck {_de(f['z'], 1, True)}")
    lg = E.get("lage") or {}
    for k, name in (("oi", "OI"), ("konten", "Konten")):
        e = lg.get(k) or {}
        if e.get("wert") is not None:
            pz = e.get("pz")
            wert = f" {_de(e['wert'], 2)}" if k == "konten" else ""
            teile.append(f"{name}{wert}" + (f" im {_de(pz * 100, 0)}. Perzentil der 90 Tage" if pz is not None and np.isfinite(pz) else ""))
    g = E.get("fng")
    if g:
        teile.append(f"Fear & Greed {_de(g['wert'], 0)} ({g['klasse']})")
    if teile:
        # 23.66: seit dem endgültigen U142-Lauf (11.10.) ist die Kontenregel belegt (H1) -- der alte Satz „keiner belegt“ war falsch
        kw = (lg.get("konten") or {}).get("wert")
        if kw is not None and np.isfinite(kw):
            erf = (f"hier erfüllt ({_de(kw, 2)} ≥ 3)" if kw >= KONTEN_SCHWELLE else f"hier nicht erfüllt ({_de(kw, 2)} unter 3)")
            S.append("Daneben: " + "; ".join(teile) + " -- belegt ist davon nur die Kontenregel (U142 H1: nach Konten ≥ 3 folgte ein "
                     f"Rücksetzer in 7 Tagen in 20 % statt 7 % der Fälle, in rund 4 von 5 Fällen keiner), {erf}; die übrigen ohne "
                     "belegtes Timing.")
        else:
            S.append("Daneben: " + "; ".join(teile) + " -- keiner dieser Werte hat in U141/U142 ein Timing belegt.")
    S.append("Lagebeschreibung, kein Signal.")
    return S


# ================================================================================================ Text (Debug-Bericht)

def text(db: str, coins=COINS, live_fn=None) -> str:
    Z = []; a = Z.append
    a(f"★ Chartbild (U143 Stufe 1) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}")
    a("Lage je Coin in Worten -- kein Signal. Prüfstände Stand " + PRUEFSTAND_STAND + " (KONZEPT_Chartbild.md 3.7).")
    a("")
    for coin in coins:
        live = live_fn(db, coin) if live_fn else {}
        P = payload(db, coin, live, cache=False)
        k = P.get("kurs") or {}
        a(f"{coin} · Kurs {_px(k.get('px'))} · {k.get('quelle', '—')} · Rechenzeit {P.get('rechenzeit_ms')} ms")
        for s in P.get("lesart") or []:
            a(f"  - {s}")
        for nv in (P.get("niveaus") or []):
            a(f"     {nv['name']:<52} {_px(nv['px']):>10}  {_pr(nv['dist'], 1):>8}  {(_de(nv['sigma'], 1, True) + ' σ') if nv.get('sigma') is not None else '—':>8}"
              f"  {_usd(nv['usd']) if nv.get('usd') else '':>9}  {PRUEFSTAND[nv['pruef']][0]}")
        for f in P.get("fehlt") or []:
            a(f"     fehlt: {f}")
        for f in P.get("nicht_gezeigt") or []:
            a(f"     bewusst nicht gezeigt: {f}")
        a("")
    a("Prüfstände:")
    for k, (wo, was) in PRUEFSTAND.items():
        a(f"  {wo:<14} {was}")
    return "\n".join(Z)


# ================================================================================================ Demo-Daten (Selbsttest, Bildschirmfotos)

DEMO = {"BTC": (62000.0, 0.025), "ETH": (2400.0, 0.032), "HYPE": (38.0, 0.05), "ZEC": (52.0, 0.045), "XMR": (310.0, 0.035),
        "PAXG": (2650.0, 0.008)}
_DEMO_SCHEMA = """
CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER,
    PRIMARY KEY (ts, coin)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER,
    PRIMARY KEY (ts, coin, bucket_px, side)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS trigger_orders (ts INTEGER, addr TEXT, coin TEXT, oid INTEGER, side TEXT, order_type TEXT, is_trigger INTEGER,
    trigger_px REAL, limit_px REAL, size REAL, notional REAL, reduce_only INTEGER, is_tpsl INTEGER, kind TEXT,
    PRIMARY KEY (ts, oid)) WITHOUT ROWID;
"""


def _demo_dbs(verz: str, coins=COINS, jetzt: int | None = None, tage: int = 1100, saat: int = 11, kurz: dict | None = None) -> dict:
    """Synthetische hl_liq.db, swing.db, regime.db, hebel.db und makro.db wie auf dem Pi (Schwankungsregime aus hl_regime._markt)."""
    import hl_binance as BN
    jetzt = int(jetzt or time.time()); heute = jetzt // TAG
    os.makedirs(verz, exist_ok=True)
    pf = {k: os.path.join(verz, f) for k, f in (("haupt", "hl_liq.db"), ("swing", "swing.db"), ("regime", "regime.db"),
                                                 ("hebel", "hebel.db"), ("makro", "makro.db"))}
    h = sqlite3.connect(pf["haupt"]); h.executescript(BN.SCHEMA); h.executescript(_DEMO_SCHEMA)
    sw = SW.verbinden(pf["swing"]); rg = RG.verbinden(pf["regime"]); hb = HB.verbinden(pf["hebel"]); mk = MK.verbinden(pf["makro"])
    oid = 1
    for i, coin in enumerate(coins):
        rng = np.random.default_rng(saat * 7 + i)
        p_end, sig = DEMO[coin]; n_t = int((kurz or {}).get(coin, tage))
        K = RG._markt(tage=n_t, seed=saat + i, sigma_tag=sig, start=(heute - n_t) * TAG)
        # heute bis jetzt weiter (30 min), damit die Kerzen frisch sind
        n_heute = max(1, (jetzt - heute * TAG) // 1800)
        r = rng.normal(0, sig / math.sqrt(48), n_heute)
        c_h = K["c"][-1] * np.exp(np.cumsum(r)); o_h = np.concatenate([[K["c"][-1]], c_h[:-1]])
        for k, v in (("ts", heute * TAG + np.arange(n_heute) * 1800), ("o", o_h), ("h", np.maximum(o_h, c_h) * 1.001),
                     ("l", np.minimum(o_h, c_h) * 0.999), ("c", c_h), ("v", np.ones(n_heute))):
            K[k] = np.concatenate([K[k], v])
        f = p_end / K["c"][-1]
        for k in ("o", "h", "l", "c"):
            K[k] = K[k] * f
        zeilen = [(coin, int(t), float(o), float(hh), float(ll), float(c), 1.0) for t, o, hh, ll, c in zip(K["ts"], K["o"], K["h"], K["l"], K["c"])]
        if coin == "PAXG":
            RG.kerzen_schreiben(rg, coin, [z[1:] for z in zeilen])
        else:
            SW._schreiben(sw, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)", zeilen)
            fts = np.arange((heute - 130) * TAG, jetzt, 8 * 3600)
            SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)",
                          [(coin, int(t), float(0.0001 + 0.00008 * rng.normal())) for t in fts])
        # Tageskerzen (mit der laufenden Kerze heute, wie hl_binance sie speichert)
        tag = K["ts"] // TAG; tage_u = np.unique(tag); dz = []
        for t in tage_u:
            m = tag == t
            dz.append((int(t * TAG), coin, float(K["o"][m][0]), float(K["h"][m].max()), float(K["l"][m].min()), float(K["c"][m][-1]), 1.0,
                       "Demo (synthetisch)"))
        h.executemany("INSERT OR REPLACE INTO daily_bars VALUES (?,?,?,?,?,?,?,?)", dz)
        px = float(K["c"][-1])
        h.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)",
                      [(int((jetzt // 60 - k) * 60), coin, px, px, px, px * float(math.exp(rng.normal(0, 0.0004))),
                        float(4e6 * (px / 62000.0) ** 0.5 / 60.0 / px * (1 + 0.002 * k)), 10) for k in range(120)][::-1])   # 23.66: Stundenvolumen ≈ 4 Mio USD (BTC), passend zu den Clustern
        # Liquidationscluster und Orders der Großkonten um den Kurs
        hz = []
        for k in list(range(-24, 0)) + list(range(1, 31)):
            b = px * (1 + 0.005 * k); side = "long" if k < 0 else "short"
            hz.append((jetzt - 60, coin, float(b), side, float(1e6 * (p_end / 62000.0) ** 0.5 * math.exp(rng.normal(0, 1.1))), int(rng.integers(1, 40))))
        h.executemany("INSERT OR REPLACE INTO heatmap VALUES (?,?,?,?,?,?)", hz)
        arten = (("limit_buy", "B", "Limit", -1), ("limit_sell", "A", "Limit", 1), ("stop_sell", "A", "Stop Market", -1),
                 ("stop_buy", "B", "Stop Market", 1), ("tp_sell", "A", "Take Profit Market", 1), ("tp_buy", "B", "Take Profit Market", -1))
        tz = []
        for j in range(60):
            kind, side, ot, sg = arten[j % len(arten)]
            p = px * (1 + sg * float(rng.uniform(0.004, 0.15))); notional = float(2e5 * math.exp(rng.normal(0, 1.2)))
            trig = ot != "Limit"
            tz.append((jetzt - int(rng.integers(60, 3 * 3600)), f"0x{rng.integers(0, 2**63):016x}{j:04d}", coin, oid, side, ot, int(trig),
                       p if trig else None, None if trig else p, notional / p, notional, int(kind.startswith(("stop", "tp"))), int(kind.startswith("tp")), kind))
            oid += 1
        h.executemany("INSERT OR REPLACE INTO trigger_orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", tz)
        if coin in HB.COINS:
            th = np.arange((heute - 130) * TAG, heute * TAG + 1, 3600)
            oi = 1e5 * (p_end / 62000.0) ** -0.5 * np.exp(np.cumsum(rng.normal(0, 0.004, len(th))))
            konten = np.exp(math.log(1.9) + 0.25 * np.sin(np.arange(len(th)) / 300.0) + rng.normal(0, 0.03, len(th)))
            top = np.exp(math.log(1.6) + 0.2 * np.cos(np.arange(len(th)) / 400.0) + rng.normal(0, 0.03, len(th)))
            HB._schreiben(hb, "INSERT OR REPLACE INTO hb_metrics VALUES (?,?,?,?,?,?,?,?)",
                          [(coin, int(t), float(o), float(o * px), float(k_ * 0.9), float(tp), float(k_), 1.0) for t, o, k_, tp in zip(th, oi, konten, top)])
            h.executemany("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)",
                          [(jetzt - 300, coin, "open_interest", float(oi[-1] * 1.01)), (jetzt - 300, coin, "global_ls_account", float(konten[-1])),
                           (jetzt - 300, coin, "top_ls_position", float(top[-1]))])
    fng = [("fng:wert", int((heute - k) * TAG), float(np.clip(50 + 25 * math.sin(k / 23.0), 5, 95)), jetzt) for k in range(1, 400)]
    mk.execute("BEGIN IMMEDIATE"); mk.executemany("INSERT OR REPLACE INTO mk_reihe VALUES (?,?,?,?)", fng); mk.execute("COMMIT")
    h.commit(); h.close()
    for c_ in (sw, rg, hb, mk):
        c_.close()
    return pf


def _mit_umgebung(pf: dict):
    """Umgebungsvariablen auf die Demo-Datenbanken (HL_SWING_DB usw.); liefert die alten Werte zum Zurücksetzen."""
    alt = {k: os.environ.get(k) for k in ("HL_SWING_DB", "HL_REGIME_DB", "HL_HEBEL_DB", "HL_MAKRO_DB")}
    os.environ.update({"HL_SWING_DB": pf["swing"], "HL_REGIME_DB": pf["regime"], "HL_HEBEL_DB": pf["hebel"], "HL_MAKRO_DB": pf["makro"]})
    return alt


def _zurueck(alt: dict) -> None:
    for k, v in alt.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


# ================================================================================================ Selbsttest (ohne Netz)

def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name:<76} {text}", flush=True)
    t0 = time.time()
    for fn in (_probe_bausteine, _probe_niveaus, _probe_studie, _probe_kausal, _probe_band, _probe_lesart, _probe_frische, _probe_ende_zu_ende):
        try:
            fn(ok)
        except Exception as e:
            import traceback
            tb = traceback.format_exc().splitlines()
            ok(f"{fn.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {tb[-3].strip() if len(tb) >= 3 else ''}")
    return all(p[1] for p in pruef), pruef, time.time() - t0


def _probe_bausteine(ok) -> None:
    c = np.arange(1.0, 301.0)
    s50 = sma(c, 50)
    ok("SMA: Mittel der letzten n Schlüsse, davor leer", np.isnan(s50[48]) and s50[49] == 25.5 and s50[299] == 275.5)
    D = {"tag0": 20000, "c": c[:250]}
    T = trendlage(D)
    ok("Trend: steigende Reihe -> 50-Tage-Linie steigt seit 200 Tagen, über der 200-Tage-Linie, kein Wechsel vor Beginn",
       T["steigung50"] == 1 and T["seit50"] == 200 and T["abstand200"] > 0 and T["lage50_200"] == 1 and "kreuz_tag" not in T,
       f"{T.get('steigung50')}, {T.get('seit50')}, {T.get('lage50_200')}")
    c2 = np.concatenate([np.linspace(100, 200, 300), np.linspace(200, 120, 160)])
    T2 = trendlage({"tag0": 20000, "c": c2})
    m50, m200 = sma(c2, 50), sma(c2, 200)
    sgn = np.sign(m50 - m200); wechsel = [j for j in range(200, len(c2)) if np.isfinite(sgn[j - 1]) and sgn[j] != sgn[j - 1] and sgn[j - 1] != 0]
    ok("Trend: Anstieg, dann Fall -> Death Cross am Tag des Vorzeichenwechsels (gegen Brute Force), 50-Tage-Linie fällt",
       T2.get("kreuz_art") == "death" and T2.get("kreuz_tag") == 20000 + wechsel[-1] and T2["steigung50"] == -1 and T2["abstand200"] < 0,
       f"{T2.get('kreuz_art')} {T2.get('kreuz_tag')} gegen {20000 + wechsel[-1] if wechsel else None}")
    n = 60; hh = np.full(n, 10.0); ll = np.full(n, 9.0)
    hh[20] = 12.0; ll[40] = 8.0; hh[57] = 13.0                          # Spitze an Tag 57: erst 2 Tage danach -> unbestätigt
    sw = swings({"tag0": 100, "h": hh, "l": ll, "c": (hh + ll) / 2})
    ok("Swings: Hoch über den 5 Tagen davor und ≥ den 5 danach; in den letzten 5 Tagen noch nicht bestätigt",
       sw["hoch"] == [(120, 12.0)] and sw["tief"] == [(140, 8.0)], f"{sw}")
    fall = {62000.0: (60000.0, 65000.0), 60000.0: (55000.0, 65000.0), 120000.0: (110000.0, 130000.0), 2400.0: (2200.0, 2600.0),
            52.3: (50.0, 55.0), 0.95: (0.9, 1.0), 310.0: (300.0, 320.0), 100.0: (90.0, 110.0)}
    erg = {p: runde(p)[:2] for p in fall}
    ok("Runde Zahlen: Schritt 1/2/5 der zweiten Stelle (4–10 % des Kurses), die nächste darunter und darüber, auch genau auf einer",
       all(abs(erg[p][0] - fall[p][0]) < 1e-9 and abs(erg[p][1] - fall[p][1]) < 1e-9 for p in fall), f"{erg}")
    ok("Runde Zahlen: Schritt lesbar (5.000, 200, 5, 2, 0,05)", [_schritt(runde(p)[2]) for p in (62000.0, 2650.0, 52.3, 38.0, 0.95)]
       == ["5.000", "200", "5", "2", "0,05"], f"{[_schritt(runde(p)[2]) for p in (62000.0, 2650.0, 52.3, 38.0, 0.95)]}")
    w = np.arange(1.0, 91.0)
    ok("Perzentil: Mittelrang unter den 90 Tagesständen (45 -> 0,4944), unter 60 Werten oder konstant leer",
       abs(perzentil(45.0, w) - 44.5 / 90) < 1e-12 and np.isnan(perzentil(45.0, w[:59])) and np.isnan(perzentil(1.0, np.ones(90))))
    ts = np.arange(10 * 24) * 3600 + 20000 * TAG; v = np.arange(len(ts), dtype=float)
    weg = np.isin(ts, [(20000 + 3) * TAG, (20000 + 6) * TAG, (20000 + 6) * TAG - 3600, (20000 + 6) * TAG - 7200])
    st = tagesstaende(ts[~weg], v[~weg], 20000, 20008)
    soll = [24, 48, 71, 96, 120, np.nan, 168, 192, 216]
    ok("Tagesstand: Zeile 00:00 des Folgetags; fehlt sie, gilt 23:00; mehr als 2 h alt -> leer (wie hl_hebel)",
       len(st) == 9 and all((np.isnan(a) and np.isnan(b)) or a == b for a, b in zip(st, soll)), f"{list(st)}")
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE daily_bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, source TEXT)")
    zeilen = [((20000 + k) * TAG, "BTC", 100.0 + k, (102.0 if k != 7 else 99.5) + k, 99.0 + k, 101.0 + k, 1.0, "Test") for k in range(10) if k != 4]
    zeilen += [((20000 + k) * TAG, "ETH", 10.0, 11.0, 9.0, 10.0 + k, 1.0, "Test") for k in list(range(5)) + list(range(10, 15))]
    zeilen += [((20012 + 0) * TAG, "BTC", 500.0, 600.0, 400.0, 550.0, 1.0, "Test")]          # laufender Tag: zählt nicht
    con.executemany("INSERT INTO daily_bars VALUES (?,?,?,?,?,?,?,?)", zeilen)
    Dk = tageskerzen(con, "BTC", 20012 * TAG + 3600); Dl = tageskerzen(con, "ETH", 20016 * TAG)
    ok("Tageskerzen: Lücke von 1 Tag aufgefüllt (Eröffnung = Hoch = Tief = Schluss des Vortags), laufender Tag ohne Wirkung; nach "
       "mehr als 3 Tagen Lücke beginnt die Reihe neu; ein Hoch unter dem Schluss (Datenfehler) wird auf den Schluss angehoben",
       Dk["n"] == 10 and Dk["tag0"] == 20000 and Dk["gefuellt"] == 1 and Dk["o"][4] == Dk["h"][4] == Dk["l"][4] == Dk["c"][4] == Dk["c"][3] == 104.0
       and Dk["letzter_tag"] == 20009 and Dk["alter_tage"] == 2 and Dk["h"][5] == 107.0 and Dk["h"][7] == 108.0 and Dk["l"][7] == 106.0
       and Dl["tag0"] == 20010 and Dl["n"] == 5,
       f"BTC n {Dk['n']}, aufgefüllt {Dk['gefuellt']}, Tag 4 {Dk['o'][4]}/{Dk['c'][4]}; ETH ab {Dl.get('tag0')} n {Dl.get('n')}")
    con.close()
    ok("Fear & Greed: Klassen an den Grenzen (24/25, 44/45, 55/56, 75/76)",
       [fng_klasse(x) for x in (24, 25, 44, 45, 55, 56, 75, 76)] == ["extreme Angst", "Angst", "Angst", "neutral", "neutral", "Gier", "Gier",
                                                                     "extreme Gier"])


def _probe_niveaus(ok) -> None:
    jetzt = 20000 * TAG + 12 * 3600; px = 100.0
    cl = [{"kind": "limit_buy", "px": 95.0, "notional": 5e6, "addrs": 3}, {"kind": "limit_buy", "px": 90.0, "notional": 8e6, "addrs": 2},
          {"kind": "stop_sell", "px": 97.0, "notional": 1e6, "addrs": 1}, {"kind": "stop_sell", "px": 93.0, "notional": 3e6, "addrs": 4},
          {"kind": "limit_sell", "px": 140.0, "notional": 9e9, "addrs": 1}, {"kind": "tp_sell", "px": 108.0, "notional": 2e6, "addrs": 2}]
    rows = [{"bucket_px": 96.0, "side": "long", "notional": 2e6, "n_pos": 5}, {"bucket_px": 92.0, "side": "long", "notional": 6e6, "n_pos": 9},
            {"bucket_px": 104.0, "side": "short", "notional": 1e6, "n_pos": 2}, {"bucket_px": 110.0, "side": "short", "notional": 4e6, "n_pos": 3},
            {"bucket_px": 80.0, "side": "long", "notional": 9e9, "n_pos": 1}]
    live = {"stops": {"clusters": cl, "ts": jetzt - 600, "n_whales": 12}, "depth": {"rows": rows, "ts": jetzt - 120, "vol_1h": 3e6}}
    sw = {"hoch": [(19990, 103.0), (19980, 106.0), (19970, 109.0)], "tief": [(19985, 94.0), (19950, 60.0)]}
    L, f = niveaus(live, px, 0.02, sw, jetzt)
    by = {l_["key"]: l_ for l_ in L}
    ok("Niveaus: je Art das größte innerhalb ±30 % (wie keyLevels), das nächste Stop-Cluster, außerhalb ±30 % nichts",
       by["support"]["px"] == 90.0 and by["stop_sell"]["px"] == 93.0 and by["stop_sell_near"]["px"] == 97.0 and "resistance" not in by
       and by["tp_long"]["px"] == 108.0, f"{sorted(by)}")
    ok("Niveaus: Liquidationscluster -12 %/+15 %: je Seite das größte und das nächste ≥ ½ Stundenvolumen (ohne Doppel)",
       by["liq_long"]["px"] == 92.0 and by["liq_long_nah"]["px"] == 96.0 and by["liq_short"]["px"] == 110.0 and "liq_short_nah" not in by,
       f"{[(k, v['px']) for k, v in by.items() if k.startswith('liq')]}")
    ok("Niveaus: zwei nächste Swing-Hochs darüber, ein Swing-Tief darunter (das bei −40 % nicht, wie die Orders höchstens ±30 %), "
       "runde Zahlen 90/110; Abstand in % und σ; sortiert",
       [by[k]["px"] for k in ("swing_hoch_0", "swing_hoch_1", "swing_tief_0", "rund_unten", "rund_oben")] == [103.0, 106.0, 94.0, 90.0, 110.0]
       and "swing_tief_1" not in by
       and abs(by["support"]["dist"] + 0.10) < 1e-12 and abs(by["support"]["sigma"] - math.log(0.9) / 0.02) < 1e-9
       and [l_["px"] for l_ in L] == sorted([l_["px"] for l_ in L], reverse=True) and not f, f"{len(L)} Niveaus, fehlt {f}")
    live3 = {"stops": {"clusters": cl, "ts": jetzt - 600, "n_whales": 12}, "depth": {"rows": rows, "ts": jetzt - 120, "vol_1h": 10e6}}
    L3, f3 = niveaus(live3, px, 0.02, None, jetzt)
    by3 = {l_["key"]: l_ for l_ in L3}
    ok("Niveaus 23.66: größtes Liquidationscluster erst ab ½ Stundenvolumen (6 Mio ≥ 5 Mio ja, 4 Mio nein -> „kein nennenswertes Cluster“ "
       "mit Größe und Maßstab); Orders ohne Mindestgröße wie im Live-Chart",
       by3.get("liq_long", {}).get("px") == 92.0 and "liq_short" not in by3 and "liq_long_nah" not in by3
       and any("Short-Liquidationen: kein nennenswertes Cluster (größtes 4,0 Mio USD unter ½ Stundenvolumen 5,0 Mio USD)" in x for x in f3)
       and by3.get("stop_sell_near", {}).get("px") == 97.0 and by3.get("tp_long", {}).get("px") == 108.0, f"{sorted(by3)} {f3}")
    live4 = {"stops": {"clusters": cl, "ts": jetzt - 600, "n_whales": 12}, "depth": {"rows": rows, "ts": jetzt - 120, "vol_1h": 0}}
    L4, f4 = niveaus(live4, px, 0.02, None, jetzt)
    ok("Niveaus 23.66: ohne Stundenvolumen kein Liquidationscluster (ohne Maßstab), mit Grund; Orders bleiben",
       not [l_ for l_ in L4 if l_["art"].startswith("liq")] and sum("ohne Maßstab" in x for x in f4) == 2
       and any(l_["key"] == "support" for l_ in L4), f"{f4}")
    live2 = {"stops": {"clusters": cl, "ts": jetzt - 7 * 3600, "n_whales": 12}, "depth": {"rows": rows, "ts": jetzt - 3600, "vol_1h": 3e6}}
    L2, f2 = niveaus(live2, px, 0.02, None, jetzt)
    ok("Niveaus: Orders älter als 6 h und Heatmap älter als 30 min werden nicht gezeigt, mit Grund",
       not [l_ for l_ in L2 if l_["art"] not in ("rund",)] and len(f2) == 2, f"{f2}")


def _probe_studie(ok) -> None:
    c = np.array([100 + 3 * k for k in range(11)] + [126, 122, 118, 114, 110] + [113, 116, 119, 122, 125], dtype=float)
    D = {"tag0": 20000, "c": c, "n": len(c)}
    b = beine_stand(D, (0.10,))[0]
    ok("Bein von Hand (10 %): 100 → 130 → 110 → 125: aufwärts seit dem Tief 110 (Tag 15), Rücksetzer bestätigt ab 112,5",
       b["mode"] == 1 and abs(b["start_px"] - 110.0) < 1e-9 and b["start_tag"] == 20015 and abs(b["extrem_px"] - 125.0) < 1e-9
       and abs(b["bestaetigt_ab"] - 112.5) < 1e-9
       and abs(b["groesse_bisher"] - (125 / 110 - 1)) < 1e-12 and b["n_ab"] == 1 and abs(b["med_ab"] - math.log(110 / 130)) < 1e-12 and b["n_auf"] == 0,
       f"Modus {b['mode']}, Start {b.get('start_px')} ({b.get('start_tag')}), Extrem {b.get('extrem_px')}, ab {b.get('bestaetigt_ab')}")
    zz = [(t, round(p, 6), ty) for t, p, ty in b["zickzack"]]
    ok("Zickzack: bestätigte Extreme in Zeitfolge (Tief 100, Hoch 130, Tief 110)", zz == [(20000, 100.0, -1), (20010, 130.0, 1), (20015, 110.0, -1)], f"{zz}")
    rng = np.random.default_rng(4)
    cc = 100 * np.exp(np.cumsum(rng.normal(0, 0.03, 1500)))
    R = {"c": cc, "n": len(cc), "tag0": 18000}
    st = ZY._dc_stand(ZY.dc_batch(np.log(cc)[None, :], math.log(1.2), -math.log(0.8)), R, 0.2)
    bb = beine_stand({"tag0": 18000, "c": cc}, (0.2,))[0]
    info = ZY.zyklen_beschreiben(ZY.beine(ZY.dc_batch(np.log(cc)[None, :], math.log(1.2), -math.log(0.8))), 0, (len(cc) - 1) / 365.25, 0.2)
    ok("Bein gleich der Studie: Stand und Statistik wie hl_zyklus (_dc_stand, zyklen_beschreiben) auf derselben Reihe",
       bb["mode"] == st["mode"] and bb["bestaetigt_ab"] == st["bestaetigt_ab"] and bb["n_auf"] == info["n"] and bb["med_auf"] == info["groesse"]
       and bb["dauer_ab"] == info["dauer_ab"], f"Modus {bb['mode']}, {bb['n_auf']} Rallyes")
    P = RG.vorbereiten(RG._markt(tage=900, seed=5, sigma_tag=0.03))
    mt = RG._monat_tage(P); a_d = mt[3][0]
    gleich = []
    for h in HAR_H:
        F_har, ql, qh, _, _ = RG.har_prognosen(P, h)
        J = har_jetzt(P, h, d=a_d - 1)
        gleich.append(J is not None and abs(J["F"] / F_har[a_d - 1] - 1) < 1e-10 and abs(J["q_lo"] - ql[a_d - 1]) < 1e-12 and abs(J["q_hi"] - qh[a_d - 1]) < 1e-12)
    ok("HAR gleich P0.2: Prognose und Bandquantile am Vortag eines Bewertungsmonats wie hl_regime.har_prognosen (1 und 7 Tage)",
       all(gleich), f"{gleich}")


def _probe_kausal(ok) -> None:
    P = RG.vorbereiten(RG._markt(tage=800, seed=9, sigma_tag=0.03))
    d = P["n_tage"] - 40
    P2 = dict(P); P2["RV"] = P["RV"].copy(); P2["xe"] = P["xe"].copy()
    P2["RV"][d + 1:] *= 4.0; P2["xe"][d + 1:] += 0.3
    erg = [(har_jetzt(P, h, d), har_jetzt(P2, h, d)) for h in HAR_H]
    ok("Kausalität HAR: Daten nach dem Prognosetag geändert -> Prognose und Band am Tag d gleich",
       all(a is not None and b is not None and a["F"] == b["F"] and a["q_lo"] == b["q_lo"] and a["q_hi"] == b["q_hi"] for a, b in erg))
    rng = np.random.default_rng(3); c = 100 * np.exp(np.cumsum(rng.normal(0, 0.03, 400)))
    hh = c * 1.01; ll = c * 0.99
    d = 330
    A = {"tag0": 20000, "c": c[:d + 1], "h": hh[:d + 1], "l": ll[:d + 1]}
    c2 = c.copy(); c2[d + 1:] *= 1.5
    B = {"tag0": 20000, "c": c2[:d + 1], "h": (c2 * 1.01)[:d + 1], "l": (c2 * 0.99)[:d + 1]}
    ok("Kausalität Tageswerte: Trend, Bein und Swings am Tag d hängen nur an den Tagen bis d",
       trendlage(A)["ma50_jetzt"] == trendlage(B)["ma50_jetzt"] and beine_stand(A)[0]["bestaetigt_ab"] == beine_stand(B)[0]["bestaetigt_ab"]
       and swings(A) == swings(B))


def _probe_band(ok) -> None:
    # Kalibrierung (kalib_band.py, 20 Märkte): 1 T Mittel 0,803 (sd 0,020), 7 T 0,791 (sd 0,034) -- einzelne Märkte streuen um
    # ± 2 sd; geprüft wird deshalb das Mittel über acht vorab gewählte Märkte (Saaten 100–107) gegen 80 % ± 2 SE des Mittels.
    m1, m7 = [], []
    for seed in range(100, 108):
        P = RG.vorbereiten(RG._markt(tage=1100, seed=seed, sigma_tag=0.03))
        m1.append(trefferquote(P, 1)["treffer"]); m7.append(trefferquote(P, 7)["treffer"])
    m1, m7 = np.array(m1), np.array(m7)
    se1, se7 = m1.std(ddof=1) / math.sqrt(len(m1)), m7.std(ddof=1) / math.sqrt(len(m7))
    ok("Band-Kontrolle: acht synthetische Märkte mit wechselnder Schwankung -> 80-%-Band trifft im Mittel 80 % ± 2 SE (1 und 7 Tage)",
       abs(m1.mean() - 0.80) <= 2 * se1 and abs(m7.mean() - 0.80) <= 2 * se7,
       f"1 T {_de(m1.mean() * 100, 1)} % ± {_de(se1 * 100, 1)}, 7 T {_de(m7.mean() * 100, 1)} % ± {_de(se7 * 100, 1)}")
    B = band(P, "BTC"); F1 = B["h1"]; F7 = B["h7"]; r_ = np.diff(P["xe"][-61:]); r_ = r_[np.isfinite(r_)]
    breite_ok = all(abs(math.log(x["hi"] / B["basis_px"]) - x["q_hi"] * x["sigma"]) < 1e-9 and abs(math.log(x["lo"] / B["basis_px"]) - x["q_lo"] * x["sigma"]) < 1e-9
                    and abs(x["sigma"] - math.sqrt(x["F"])) < 1e-12 for x in (F1, F7))
    ok("Band: Grenzen = Schluss · e^(Quantil · √F), 7 Tage deutlich breiter als 1 Tag, σ (1 Tag) in der Größe der Tagesrenditen",
       breite_ok and F7["sigma"] > 1.8 * F1["sigma"] and 0.5 < F1["sigma"] / r_.std() < 2.0,
       f"σ 1 T {_de(F1['sigma'] * 100, 2)} %, 7 T {_de(F7['sigma'] * 100, 2)} %, Tagesrenditen {_de(r_.std() * 100, 2)} %")
    F_har, ql, qh, r_h, _ = RG.har_prognosen(P, 1); nt = P["n_tage"]
    zaehl = np.isfinite(F_har) & np.isfinite(r_h) & np.isfinite(ql) & np.isfinite(qh); zaehl[:max(0, nt - 1 - TREFFER_TAGE)] = False
    T1 = trefferquote(P, 1)
    ok("Trefferquote: nur die Prognosetage der letzten 365 Tage (Zählung von Hand)", T1["n"] == int(zaehl.sum()) and 0 < T1["n"] <= 365,
       f"n {T1['n']} gegen {int(zaehl.sum())}")
    th = trefferquote(P, 1, breite=0.5)
    ok("Band-Kontrolle: ein Band mit halber Breite trifft deutlich weniger (Trefferquote erkennt ein falsches Band)",
       th["treffer"] < 0.80 - 5 * th["se"], f"{_de(th['treffer'] * 100, 1)} % (letzter der acht Märkte)")


def _probe_lesart(ok) -> None:
    E = {"coin": "BTC", "trend": {"abstand200": 0.081, "ma200_jetzt": 57300.0, "steigung50": 1, "seit50": 12, "n_tage": 1800, "tag": 20368},
         "beine": [{"X": 0.1, "mode": 1, "start_px": 58200.0, "start_tag": 20368, "extrem_px": 66000.0, "groesse_bisher": 0.134, "bestaetigt_ab": 59400.0,
                    "n_auf": 48, "med_auf": math.log(1.24), "dauer_auf": 14.2}],
         "niveaus": [{"name": "Verkaufswand (Resistance)", "px": 64000.0, "dist": 0.019, "sigma": 0.8, "seite": "oben", "art": "limit_sell"},
                     {"name": "Sell-Stops (nächstes Cluster)", "px": 62700.0, "dist": -0.002, "sigma": -0.1, "seite": "unten", "art": "stop_sell",
                      "key": "stop_sell_near"},
                     {"name": "runde Zahl (5.000er-Schritt)", "px": 60000.0, "dist": -0.04, "sigma": -1.6, "seite": "unten", "art": "rund"},
                     {"name": "Kaufwand (Support)", "px": 61500.0, "dist": -0.021, "sigma": -0.9, "seite": "unten", "art": "limit_buy"}],
         "band": {"basis_px": 62800.0, "p02": "hielt in P0.2", "h1": {"lo": 61400.0, "hi": 64300.0, "treffer": 0.81},
                  "h7": {"lo": 58700.0, "hi": 66900.0, "treffer": 0.79}},
         "rsi": np.array([np.nan, 58.2]), "funding": {"z": 0.4}, "lage": {"oi": {"wert": 1e5, "pz": 0.72}, "konten": {"wert": 1.92, "pz": 0.4}},
         "fng": {"wert": 62.0, "klasse": "Gier"}}
    S = lesart(E); t = " ".join(S)
    ok("Lesart: sechs Sätze in fester Reihenfolge aus den Zahlen (Trend, Bein, Niveaus, Spanne, Daneben, kein Signal)",
       len(S) == 6 and S[0].startswith("BTC schloss am 07.10.2025 8,1 % über der 200-Tage-Linie (57.300); die 50-Tage-Linie steigt seit 12 Tagen")
       and "aufwärts seit dem tiefsten Schluss 58.200" in S[1] and "bis zum höchsten Schluss 66.000" in S[1] and "Median +24 %" in S[1] and "kein Ziel" in S[1]
       and "darunter Kaufwand (Support) 61.500 (−2,1 %" in S[2].replace("-", "−") and "darüber Verkaufswand" in S[2] and "62.700" not in S[2]
       and "61.400–64.300" in S[3] and "81 % bzw. 79 %" in S[3] and "RSI 58" in S[4] and "Fear & Greed 62 (Gier)" in S[4]
       and S[5] == "Lagebeschreibung, kein Signal.", " | ".join(S)[:400])
    ok("Lesart 23.66: Daneben nennt die belegte Kontenregel (U142 H1) und ob sie erfüllt ist (1,92: nicht erfüllt); kein „keiner belegt“ mehr",
       "belegt ist davon nur die Kontenregel (U142 H1" in S[4] and "hier nicht erfüllt (1,92 unter 3)" in S[4] and "keiner dieser Werte" not in S[4], S[4])
    Ek = dict(E, lage={"konten": {"wert": 3.2, "pz": 0.98}})
    Sk = lesart(Ek)
    Eo = dict(E, lage={"oi": {"wert": 1e5, "pz": 0.72}})
    So = lesart(Eo)
    ok("Lesart 23.66: Konten 3,20 -> „hier erfüllt“; ohne Kontenwert (z. B. PAXG) bleibt „keiner dieser Werte … belegt“",
       "hier erfüllt (3,20 ≥ 3)" in Sk[4] and "keiner dieser Werte hat in U141/U142 ein Timing belegt" in So[4], Sk[4] + " | " + So[4])
    En = dict(E, niveaus=[{"name": "runde Zahl", "px": 85.0, "dist": -0.0001, "sigma": -0.004, "seite": "unten", "art": "limit_buy"}])
    Sn = lesart(En)
    ok("Lesart 23.66: gerundete Null ohne Vorzeichen („0,0 σ“, „0,0 %“ statt „-0,0“)", "(0,0 %, 0,0 σ)" in Sn[2] and "-0,0" not in Sn[2], Sn[2])
    ok("Lesart: keine Wörter einer Empfehlung", not any(w in t.lower() for w in WORT_VERBOTEN))
    E2 = {"coin": "ETH", "trend": {"abstand200": -0.05, "ma200_jetzt": 2600.0, "steigung50": -1, "seit50": 1, "n_tage": 900, "tag": 20368},
          "beine": [{"X": 0.1, "mode": -1, "start_px": 2900.0, "start_tag": 20360, "extrem_px": 2300.0, "groesse_bisher": -0.207, "bestaetigt_ab": 2530.0,
                     "n_ab": 30, "med_ab": math.log(0.8), "dauer_ab": 9.0}]}
    S2 = lesart(E2)
    ok("Lesart: unter der Linie, fallend, Bein abwärts; fehlende Bausteine ohne Satz",
       len(S2) == 3 and "unter der 200-Tage-Linie" in S2[0] and "fällt seit 1 Tag" in S2[0] and "abwärts seit dem höchsten Schluss 2.900" in S2[1] and "bis zum tiefsten Schluss 2.300" in S2[1]
       and "Median −20 %" in S2[1].replace("-", "−") and S2[2] == "Lagebeschreibung, kein Signal.", " | ".join(S2))


def _probe_frische(ok) -> None:
    tmp = tempfile.mkdtemp(prefix="cb_leer_")
    alt = _mit_umgebung({k: os.path.join(tmp, f"{k}.db") for k in ("swing", "regime", "hebel", "makro")})
    try:
        P = payload(os.path.join(tmp, "hl_liq.db"), "BTC", {}, cache=False)
        s = json.dumps(P, allow_nan=False)
        ok("Ohne jede Datenbank: Antwort ohne Absturz, jeder fehlende Baustein mit Grund, nur der Schlusssatz, JSON ohne NaN",
           P["ok"] and P["lesart"] == ["Lagebeschreibung, kein Signal."] and len(P["fehlt"]) >= 4 and "tage" not in P, f"{len(P['fehlt'])} Gründe")
        P2 = payload(os.path.join(tmp, "hl_liq.db"), "DOGE", {}, cache=False)
        ok("Unbekannter Coin: Hinweis statt Fehler", P2["ok"] and "kein Chartbild" in P2["fehlt"][0])
        pf = _demo_dbs(os.path.join(tmp, "alt"), coins=("BTC",), jetzt=int(time.time()) - 9 * TAG, tage=500)
        _zurueck(alt); alt = _mit_umgebung(pf)
        P3 = payload(pf["haupt"], "BTC", {}, cache=False)
        ok("Alte Daten (9 Tage): Tageskerzen, Band und Fear & Greed ausgeblendet, mit Datum im Grund",
           "tage" not in P3 and "band" not in P3 and "fng" not in P3 and any("zuletzt am" in f for f in P3["fehlt"])
           and any("30-min-Kerzen zuletzt" in f for f in P3["fehlt"]), " | ".join(P3["fehlt"])[:300])
    finally:
        _zurueck(alt)
        shutil.rmtree(tmp, ignore_errors=True)


def _probe_ende_zu_ende(ok) -> None:
    """Synthetische Datenbanken wie auf dem Pi -> Live-Teil wie im Dashboard (hl_viz.chartbild_live) -> Antwort je Coin."""
    import hl_viz
    tmp = tempfile.mkdtemp(prefix="cb_e2e_"); jetzt = int(time.time())
    pf = _demo_dbs(tmp, coins=("BTC", "HYPE", "PAXG"), jetzt=jetzt, tage=1100, kurz={"HYPE": 420})
    alt = _mit_umgebung(pf)
    try:
        P = {c: payload(pf["haupt"], c, hl_viz.chartbild_live(pf["haupt"], c), cache=False) for c in ("BTC", "HYPE", "PAXG")}
        B = P["BTC"]; s = json.dumps(B, allow_nan=False)
        arten = {n["art"] for n in B.get("niveaus") or []}
        ok("Ende zu Ende BTC: Tageskerzen, Trend, drei Beine, Swings, Band 1/7 T mit Trefferquote, Funding-Druck, Fear & Greed, Lage",
           len(B["tage"]["c"]) == CHART_TAGE and B["trend"].get("ma200_jetzt") and len(B["beine"]) == 3 and B["band"]["h1"]["treffer"] is not None
           and B["band"]["h7"]["lo"] < B["band"]["h1"]["lo"] < B["band"]["basis_px"] < B["band"]["h1"]["hi"] < B["band"]["h7"]["hi"]
           and B["funding"].get("z") is not None and B["fng"]["klasse"] and B["lage"]["oi"].get("pz") is not None
           and B["lage"]["konten"].get("art") == "live" and not B["fehlt"], f"{len(s) // 1024} kB, fehlt {B['fehlt']}")
        t0c = B["tage"]["t0"]; zz = B["zickzack"]; lt = B["tage"]["letzter_tag"]
        sw_t = [t for t, _ in B["swings"]["hoch"] + B["swings"]["tief"]]
        ok("Ende zu Ende BTC: Funding-Druck am letzten vollen Tag, RSI gleich Wilder auf den gelieferten Schlüssen, Zickzack ab dem "
           "Chartfenster samt dem einen Punkt davor, Swings nur aus den letzten 365 Tagen und erst nach 5 Tagen bestätigt",
           B["funding"]["tag"] == jetzt // TAG - 1 and abs(SW.rsi_wilder(np.array(B["tage"]["c"]), 14)[-1] - B["rsi"]["wert"]) < 0.05
           and zz[0][0] < t0c <= zz[1][0] and all(z[0] >= t0c for z in zz[1:]) and sw_t and min(sw_t) > lt - PIVOT_TAGE and max(sw_t) <= lt - PIVOT_N,
           f"Funding {B['funding']['tag']}, RSI {B['rsi']['wert']:.2f}, Zickzack ab {zz[0][0]} (Fenster {t0c}), Swings {min(sw_t)}–{max(sw_t)}")
        ok("Ende zu Ende BTC: Niveaus aus Orders, Liquidationsclustern, Swings und runden Zahlen; die laufende Kerze heute zählt nicht",
           {"limit_buy", "limit_sell", "liq_long", "liq_short", "rund"} <= arten and B["tage"]["letzter_tag"] == jetzt // TAG - 1
           and len(B["lesart"]) == 6, f"{sorted(arten)}")
        H = P["HYPE"]
        ok("Ende zu Ende HYPE (420 Tage): Band ohne Trefferquote (zu kurz), 200-Tage-Linie vorhanden",
           H["band"]["h1"] is not None and H["band"]["h1"]["treffer"] is None and H["trend"].get("ma200_jetzt") is not None, f"fehlt {H['fehlt']}")
        X = P["PAXG"]
        ok("Ende zu Ende PAXG: Band aus regime.db, Beine mit 3/5/10 %, ohne Funding, Positionierung und Fear & Greed -- als „bewusst "
           "nicht gezeigt“ mit Grund, nicht als Lücke; runde Zahl im 200er-Schritt",
           X["band"]["quelle"] == "regime.db" and [b["X"] for b in X["beine"]] == [0.03, 0.05, 0.1] and "funding" not in X and "fng" not in X
           and len(X["nicht_gezeigt"]) == 3 and not X["fehlt"] and any(n["name"] == "runde Zahl (200er-Schritt)" for n in X["niveaus"]),
           f"fehlt {X['fehlt']}, nicht gezeigt {X['nicht_gezeigt']}")
        alle = " ".join(" ".join(p["lesart"]) for p in P.values()).lower()
        ok("Ende zu Ende: keine Wörter einer Empfehlung in allen Lesarten, JSON ohne NaN", not any(w in alle for w in WORT_VERBOTEN)
           and all(json.dumps(p, allow_nan=False) for p in P.values()))
        lv = hl_viz.chartbild_live(pf["haupt"], "BTC"); lv["kurs_ts"] = jetzt - 2 * FRISCH["kurs"]
        Bk = payload(pf["haupt"], "BTC", lv, cache=False)
        ok("Kurs ohne frische 1-min-Kerze (30 min alt): Abstände zum letzten Tagesschluss, mit Grund",
           Bk["kurs"]["quelle"] == "letzter Tagesschluss" and abs(Bk["kurs"]["px"] / B["tage"]["c"][-1] - 1) < 1e-5
           and any("keine frische 1-min-Kerze" in f for f in Bk["fehlt"]), f"{Bk['kurs']}")
        con = sqlite3.connect(pf["haupt"]); heute = jetzt // TAG
        con.execute("UPDATE bnc_metrics SET ts = ts - 4 * 3600"); con.commit(); con.close()
        Bt = payload(pf["haupt"], "BTC", hl_viz.chartbild_live(pf["haupt"], "BTC"), cache=False)
        ch = sqlite3.connect(pf["hebel"]); rr = np.array(ch.execute("SELECT ts, konten FROM hb_metrics WHERE coin='BTC' ORDER BY ts").fetchall(), dtype=float); ch.close()
        st_ = tagesstaende(rr[:, 0].astype(np.int64), rr[:, 1], heute - 125, heute - 1); i_ = int(np.nonzero(np.isfinite(st_))[0][-1])
        kt = Bt["lage"]["konten"]
        ok("Positionierung ohne frische Live-Zeile (4 h alt): Tagesstand von gestern, Perzentil gegen die 90 Stände davor (von Hand)",
           kt.get("art") == "Tagesstand" and kt.get("tag") == heute - 1 and kt["wert"] == float(st_[i_])
           and abs(kt["pz"] - perzentil(float(st_[i_]), st_[max(0, i_ - PERZ_FENSTER):i_])) < 1e-12 and Bt["lage"]["oi"].get("art") == "Tagesstand",
           f"{kt.get('art')} {kt.get('tag')} Perzentil {kt.get('pz')}")
        con = sqlite3.connect(pf["haupt"])
        con.execute("UPDATE daily_bars SET close = close * 10, high = high * 10 WHERE coin='BTC' AND ts=?", (heute * TAG,)); con.commit(); con.close()
        B2 = payload(pf["haupt"], "BTC", hl_viz.chartbild_live(pf["haupt"], "BTC"), cache=False)
        ok("Kausalität: die laufende Tageskerze (heute) ändert Trend, Bein und Swings nicht",
           B2["trend"] == B["trend"] and B2["beine"] == B["beine"] and B2["swings"] == B["swings"])
        t_ = time.time(); payload(pf["haupt"], "BTC", hl_viz.chartbild_live(pf["haupt"], "BTC"), cache=True)
        t1 = time.time(); payload(pf["haupt"], "BTC", hl_viz.chartbild_live(pf["haupt"], "BTC"), cache=True); t2 = time.time()
        ok("Zwischenspeicher: zweite Anfrage ohne Tagesrechnung (unter 0,2 s)", t2 - t1 < 0.2, f"{_de((t1 - t_) * 1000, 0)} ms -> {_de((t2 - t1) * 1000, 0)} ms")
        leer = os.path.join(tmp, "nur_bars.db"); cl = sqlite3.connect(leer)
        cl.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
        cl.execute("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", (jetzt - 60, "BTC", 1.0, 1.0, 1.0, 62000.0, 1.0, 1)); cl.commit(); cl.close()
        lv0 = hl_viz.chartbild_live(leer, "BTC")
        Lf, ff = niveaus(lv0, 62000.0, 0.03, None, jetzt)
        alt_ls = hl_viz.load_stops
        def _kaputt(*a, **k):
            raise ValueError("Probe")
        hl_viz.load_stops = _kaputt
        try:
            lv1 = hl_viz.chartbild_live(pf["haupt"], "BTC")
        finally:
            hl_viz.load_stops = alt_ls
        L1, f1 = niveaus(lv1, lv1.get("kurs") or 1.0, 0.03, None, jetzt)
        ok("Live-Teil je Teil für sich: ohne Heatmap-Tabelle bleibt der Kurs („Heatmap nicht lesbar“ mit Grund); scheitert die "
           "Order-Abfrage, bleiben Kurs und Liquidationscluster („Orders der Großkonten nicht lesbar“)",
           lv0.get("kurs") == 62000.0 and lv0.get("fehler_depth") and any(f.startswith("Heatmap nicht lesbar") for f in ff)
           and {l_["art"] for l_ in Lf} == {"rund"} and lv1.get("kurs") and lv1.get("fehler_stops") == "ValueError: Probe"
           and any(f.startswith("Orders der Großkonten nicht lesbar") for f in f1) and {"liq_long", "liq_short"} <= {l_["art"] for l_ in L1},
           f"{ff} | {f1}")
        txt = text(pf["haupt"], ("BTC", "PAXG"), live_fn=hl_viz.chartbild_live)
        ok("Text-Bericht: alle Coins mit Lesart, Niveaus und Prüfständen", "★ Chartbild" in txt and "BTC · Kurs" in txt and "PAXG · Kurs" in txt
           and "Prüfstände:" in txt, f"{len(txt.splitlines())} Zeilen")
    finally:
        _zurueck(alt)
        shutil.rmtree(tmp, ignore_errors=True)


def selbsttest() -> bool:
    print("Chartbild (U143 Stufe 1) -- Selbsttest: Bausteine von Hand, Niveaus, gleich der Studien (U141, P0.2), Kausalität, Band-Kontrolle, "
          "Lesart, Frische, Ende zu Ende", flush=True)
    alles, _, dauer = probe(True)
    print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({dauer:.0f} s)", flush=True)
    return alles


# ================================================================================================ Aufruf

def main() -> int:
    ap = argparse.ArgumentParser(description="Chartbild (U143 Stufe 1): Lage je Coin in Worten, kein Signal")
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--demo", default=None, help="Ordner für synthetische Datenbanken (nur Test und Bildschirmfotos)")
    ap.add_argument("--db", default=os.environ.get("HL_DB", "hl_liq.db"))
    ap.add_argument("--coin", default=None)
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.demo:
        pf = _demo_dbs(a.demo)
        print(json.dumps(pf, indent=1))
        return 0
    if a.text:
        import hl_viz
        print(text(a.db, (a.coin.upper(),) if a.coin else COINS, live_fn=hl_viz.chartbild_live), flush=True)
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
