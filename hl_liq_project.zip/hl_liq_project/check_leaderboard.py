#!/usr/bin/env python3
"""
Diagnose Leaderboard: Was steht in der Datenbank, und was sagt die API live?

  python3 check_leaderboard.py            # Datenbank aus der Unit, 5 Live-Abfragen (Gewicht 10)
  python3 check_leaderboard.py --live 0   # ohne Live-Abfragen

Prüft: (1) jüngster Durchgang, Konten mit/ohne Positionen; (2) Rohformat des
Leaderboards (windowPerformances-Fenster, Feldnamen); (3) clearinghouseState
live für Konten, die laut Datenbank keine Position haben -- stimmt das?
"""
import argparse, json, re, sqlite3, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def db_path() -> str:
    for unit in ("/etc/systemd/system/hl-recorder.service",):
        try:
            m = re.search(r"--db\s+(\S+)", Path(unit).read_text())
            if m:
                return m.group(1)
        except OSError:
            pass
    return str(ROOT / "hl_liq.db")


def get_json(url, data=None, timeout=30):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "hl-check/1.0", **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def main():
    p = argparse.ArgumentParser(); p.add_argument("--db", default=db_path()); p.add_argument("--live", type=int, default=5)
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True); con.row_factory = sqlite3.Row
    print(f"Datenbank: {a.db}\n")
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        print("Tabelle lb_accounts fehlt — Recorder-Version zu alt oder noch nie gelaufen."); return
    if not last:
        print("Noch kein Leaderboard-Durchgang in der Datenbank."); return
    rows = con.execute("SELECT rank, addr, name, account_value, pnl_30d, n_positions FROM lb_accounts WHERE ts=? ORDER BY rank", (last,)).fetchall()
    n_pos = con.execute("SELECT COUNT(*) FROM lb_positions WHERE ts=?", (last,)).fetchone()[0]
    with_pos = sum(1 for r in rows if r["n_positions"])
    print(f"1) Jüngster Durchgang {time.strftime('%d.%m. %H:%M', time.localtime(last))} ({int(time.time() - last) // 60} min alt): "
          f"{len(rows)} Konten, {with_pos} davon mit Positionen, {n_pos} Positionen gesamt")
    cycles = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_accounts").fetchone()[0]
    trend = con.execute("SELECT COUNT(*) FROM lb_trend").fetchone()[0]
    print(f"   Durchgänge bisher {cycles} · Trendzeilen {trend}")
    print(f"   {'Rang':>4} {'Konto':<16} {'Kontowert':>12} {'PnL 30 T':>12} {'Pos.':>5}  Name")
    for r in rows[:15]:
        print(f"   {r['rank']:>4} {r['addr'][:8]}…{r['addr'][-4:]:<4}  {r['account_value']:>12,.0f} {r['pnl_30d']:>12,.0f} {r['n_positions']:>5}  {r['name'] or ''}")
    print()
    print("2) Leaderboard-Rohformat (erste Zeile):")
    try:
        lb = get_json("https://stats-data.hyperliquid.xyz/Mainnet/leaderboard", timeout=90)
        lrows = lb.get("leaderboardRows") if isinstance(lb, dict) else lb
        first = (lrows or [{}])[0]
        print(f"   Zeilen {len(lrows or [])} · Schlüssel {sorted(first.keys())}")
        wp = first.get("windowPerformances")
        print(f"   windowPerformances: {json.dumps(wp)[:300]}")
        wins = [w for w, _ in (wp or [])]
        print(f"   Fenster: {wins}  ->  {'ok, month vorhanden' if 'month' in wins else 'PROBLEM: kein Fenster month — Parser erwartet month'}")
        top = sorted(((float(dict(r.get('windowPerformances') or {}).get('month', {}).get('pnl') or 0), r) for r in lrows), key=lambda x: -x[0])[:3]
        print("   Top 3 nach 30-Tage-PnL laut Rohdaten:", [(round(v / 1e6, 1), r.get('ethAddress', '')[:10]) for v, r in top])
    except Exception as e:
        print(f"   Leaderboard nicht ladbar: {e}")
    print()
    if a.live:
        zero = [r for r in rows if not r["n_positions"]][:a.live]
        print(f"3) Live-Gegenprobe clearinghouseState für {len(zero)} Konten ohne Position laut Datenbank (Gewicht {2 * len(zero)}):")
        for r in zero:
            try:
                st = get_json("https://api.hyperliquid.xyz/info", data=json.dumps({"type": "clearinghouseState", "user": r["addr"]}).encode())
                ap = st.get("assetPositions", []) if isinstance(st, dict) else None
                if ap is None:
                    print(f"   #{r['rank']:<3} {r['addr'][:10]}…  Antwort ohne assetPositions: {str(st)[:120]}")
                else:
                    coins = [(x.get('position', {}).get('coin'), x.get('position', {}).get('szi')) for x in ap]
                    print(f"   #{r['rank']:<3} {r['addr'][:10]}…  live {len(ap)} Positionen {coins[:4]}  Kontowert {float(st.get('marginSummary', {}).get('accountValue') or 0):,.0f}"
                          + ("   <- DB sagt 0: Abfrage im Recorder scheiterte" if ap else "   (stimmt: flat)"))
            except Exception as e:
                print(f"   #{r['rank']:<3} {r['addr'][:10]}…  Fehler: {e}")
            time.sleep(0.5)
    print("\nRecorder-Journal, letzte Leaderboard-Zeilen:  journalctl -u hl-recorder | grep -i leaderboard | tail -5")


if __name__ == "__main__":
    main()
