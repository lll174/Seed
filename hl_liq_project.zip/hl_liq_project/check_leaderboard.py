#!/usr/bin/env python3
"""
Diagnose Leaderboard: Was steht in der Datenbank, und was sagt die API live?

  python3 check_leaderboard.py            # Datenbank aus der Unit, 5 Live-Abfragen (Gewicht 10)
  python3 check_leaderboard.py --live 0   # ohne Live-Abfragen

Prüft: (1) jüngster Durchgang, Konten mit/ohne Positionen; (2) Rohformat des
Leaderboards (windowPerformances-Fenster, Feldnamen); (3) clearinghouseState
live für Konten, die laut Datenbank keine Position haben -- stimmt das?
"""
import argparse, json, re, sqlite3, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def db_path() -> str:
    for unit in ("/etc/systemd/system/hl-recorder.service",):
        try:
            m = re.search(r"--db\s+(\S+)", Path(unit).read_text())
            if m:
                return m.group(1)
        except OSError:
            pass
    return str(ROOT / "hl_liq.db")


def get_json(url, data=None, timeout=30):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "hl-check/1.0", **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def main():
    p = argparse.ArgumentParser(); p.add_argument("--db", default=db_path()); p.add_argument("--live", type=int, default=5)
    p.add_argument("--coin", default="BTC")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True); con.row_factory = sqlite3.Row
    print(f"Datenbank: {a.db}\n")
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        print("Tabelle lb_accounts fehlt — Recorder-Version zu alt oder noch nie gelaufen."); return
    if not last:
        print("Noch kein Leaderboard-Durchgang in der Datenbank."); return
    rows = con.execute("SELECT rank, addr, name, account_value, pnl_30d, n_positions FROM lb_accounts WHERE ts=? ORDER BY rank", (last,)).fetchall()
    n_pos = con.execute("SELECT COUNT(*) FROM lb_positions WHERE ts=?", (last,)).fetchone()[0]
    with_pos = sum(1 for r in rows if r["n_positions"])
    print(f"1) Jüngster Durchgang {time.strftime('%d.%m. %H:%M', time.localtime(last))} ({int(time.time() - last) // 60} min alt): "
          f"{len(rows)} Konten, {with_pos} davon mit Positionen, {n_pos} Positionen gesamt")
    cycles = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_accounts").fetchone()[0]
    trend = con.execute("SELECT COUNT(*) FROM lb_trend").fetchone()[0]
    print(f"   Durchgänge bisher {cycles} · Trendzeilen {trend}")
    print(f"   {'Rang':>4} {'Konto':<16} {'Perp-Wert':>12} {'PnL 30 T':>12} {'Pos.':>5}  Name   (Rang = unter den Konten MIT Perp-Positionen)")
    for r in rows[:15]:
        print(f"   {r['rank']:>4} {r['addr'][:8]}…{r['addr'][-4:]:<4}  {r['account_value']:>12,.0f} {r['pnl_30d']:>12,.0f} {r['n_positions']:>5}  {r['name'] or ''}")
    print()
    print("2) Leaderboard-Rohformat (erste Zeile):")
    try:
        lb = get_json("https://stats-data.hyperliquid.xyz/Mainnet/leaderboard", timeout=90)
        lrows = lb.get("leaderboardRows") if isinstance(lb, dict) else lb
        first = (lrows or [{}])[0]
        print(f"   Zeilen {len(lrows or [])} · Schlüssel {sorted(first.keys())}")
        wp = first.get("windowPerformances")
        print(f"   windowPerformances: {json.dumps(wp)[:300]}")
        wins = [w for w, _ in (wp or [])]
        print(f"   Fenster: {wins}  ->  {'ok, month vorhanden' if 'month' in wins else 'PROBLEM: kein Fenster month — Parser erwartet month'}")
        top = sorted(((float(dict(r.get('windowPerformances') or {}).get('month', {}).get('pnl') or 0), r) for r in lrows), key=lambda x: -x[0])[:3]
        print("   Top 3 nach 30-Tage-PnL laut Rohdaten:", [(round(v / 1e6, 1), r.get('ethAddress', '')[:10]) for v, r in top])
    except Exception as e:
        print(f"   Leaderboard nicht ladbar: {e}")
    print()
    if a.live:
        ohne = [r for r in rows if not r["n_positions"]]
        zero = (ohne or rows)[:a.live]
        print(f"3) Live-Gegenprobe clearinghouseState für {len(zero)} Konten "
              f"({'Konten OHNE Positionen laut Datenbank' if ohne else 'die größten, da alle Konten Positionen haben'}, Gewicht {2 * len(zero)}):")
        for r in zero:
            try:
                st = get_json("https://api.hyperliquid.xyz/info", data=json.dumps({"type": "clearinghouseState", "user": r["addr"]}).encode())
                ap = st.get("assetPositions", []) if isinstance(st, dict) else None
                if ap is None:
                    print(f"   #{r['rank']:<3} {r['addr'][:10]}…  Antwort ohne assetPositions: {str(st)[:120]}")
                else:
                    coins = [(x.get('position', {}).get('coin'), x.get('position', {}).get('szi')) for x in ap]
                    # Live gegen den gespeicherten Stand halten -- die Meldung verglich früher
                    # blind gegen null und behauptete auch dann einen Fehler, wenn beides stimmte.
                    n_db = r["n_positions"] or 0
                    if len(ap) == n_db:
                        urteil = "   (stimmt mit der Datenbank überein)"
                    elif n_db == 0:
                        urteil = "   <- Datenbank sagt 0: Abfrage im Recorder scheiterte"
                    else:
                        urteil = f"   <- ABWEICHUNG: Datenbank {n_db}, live {len(ap)}"
                    print(f"   #{r['rank']:<3} {r['addr'][:10]}…  live {len(ap)} Positionen {coins[:4]}  "
                          f"Kontowert {float(st.get('marginSummary', {}).get('accountValue') or 0):,.0f}" + urteil)
            except Exception as e:
                print(f"   #{r['rank']:<3} {r['addr'][:10]}…  Fehler: {e}")
            time.sleep(0.5)
    try:
        teil_ereignisse(con, a.coin if hasattr(a, "coin") else "BTC")
    except Exception as e:
        print(f"\n4) Ereignisprüfung fehlgeschlagen: {type(e).__name__}: {e}")
    print("\nRecorder-Journal, letzte Leaderboard-Zeilen:  journalctl -u hl-recorder | grep -i leaderboard | tail -5")




def teil_ereignisse(con, coin: str) -> None:
    """
    Warum entstehen (keine) Ereignisse? Die Ereignisse werden aus dem Vergleich zweier
    Positionsstände abgeleitet. Hier wird derselbe Vergleich noch einmal direkt auf den
    gespeicherten Ständen gerechnet -- unabhängig vom Recorder. Damit lässt sich trennen:

      * Es gab Größenänderungen über der Schwelle, aber kein Ereignis  -> Fehler im Recorder
      * Alle Änderungen lagen unter der Schwelle                       -> der Markt ist ruhig
      * Es gibt gar keine aufeinanderfolgenden Stände                  -> die Abfrage läuft nicht
    """
    import time as _t
    now = int(_t.time())
    print(f"\n4) Warum (keine) Ereignisse in {coin}? Vergleich der gespeicherten Stände")
    try:
        stände = [r[0] for r in con.execute(
            "SELECT DISTINCT ts FROM lb_positions WHERE ts > ? ORDER BY ts", (now - 6 * 3600,))]
    except sqlite3.Error as e:
        print(f"   lb_positions nicht lesbar: {e}")
        return
    if len(stände) < 2:
        print(f"   nur {len(stände)} Stand/Stände in 6 h — die Leaderboard-Abfrage läuft nicht")
        return
    print(f"   {len(stände)} Stände in 6 h · Abstand im Mittel {(stände[-1]-stände[0])/max(len(stände)-1,1)/60:.1f} min")

    schwelle = 25_000.0
    änderungen = []          # (delta_usd, ts, addr, von, nach)
    ohne_ereignis = []
    for a, b in zip(stände[:-1], stände[1:]):
        va = {r[0]: (r[1], abs(r[2] or 0.0), r[3] or 0.0) for r in con.execute(
            "SELECT addr, side, size, mark_px FROM lb_positions WHERE ts=? AND coin=?", (a, coin))}
        vb = {r[0]: (r[1], abs(r[2] or 0.0), r[3] or 0.0) for r in con.execute(
            "SELECT addr, side, size, mark_px FROM lb_positions WHERE ts=? AND coin=?", (b, coin))}
        for addr, (seite_b, sz_b, mark) in vb.items():
            alt = va.get(addr)
            if not alt:
                continue
            seite_a, sz_a, _ = alt
            if seite_a != seite_b:
                delta = (sz_a + sz_b) * (mark or 0)
            else:
                delta = (sz_b - sz_a) * (mark or 0)
            if abs(delta) < 1:
                continue
            änderungen.append((delta, b, addr, sz_a, sz_b))
            if abs(delta) >= schwelle:
                treffer = con.execute(
                    "SELECT COUNT(*) FROM lb_events WHERE addr=? AND coin=? AND ts BETWEEN ? AND ?",
                    (addr, coin, b - 60, b + 60)).fetchone()[0]
                if not treffer:
                    ohne_ereignis.append((delta, b, addr))
    if not änderungen:
        n_halten = len({r[0] for r in con.execute(
            "SELECT addr FROM lb_positions WHERE ts=? AND coin=?", (stände[-1], coin))})
        print(f"   KEINE einzige Größenänderung in 6 h · {n_halten} Konten halten {coin}")
        print(f"   -> die Top-Konten haben ihre {coin}-Position unverändert gelassen")
        return
    änderungen.sort(key=lambda x: -abs(x[0]))
    über = [x for x in änderungen if abs(x[0]) >= schwelle]
    print(f"   {len(änderungen)} Größenänderungen · davon {len(über)} über {schwelle:,.0f} USD")
    print(f"   Die zehn größten:")
    for delta, ts, addr, sz_a, sz_b in änderungen[:10]:
        print(f"     {_t.strftime('%d.%m %H:%M', _t.localtime(ts))} {addr[:8]}…{addr[-4:]} "
              f"{sz_a:.4f} -> {sz_b:.4f} = {delta:+,.0f} USD{'  (über der Schwelle)' if abs(delta) >= schwelle else ''}")
    ev = con.execute("SELECT COUNT(*) FROM lb_events WHERE coin=? AND ts > ?", (coin, now - 6 * 3600)).fetchone()[0]
    print(f"   Aufgezeichnete Ereignisse in 6 h: {ev}")
    if ohne_ereignis:
        print(f"   FEHLER: {len(ohne_ereignis)} Änderungen über der Schwelle OHNE Ereignis:")
        for delta, ts, addr in ohne_ereignis[:5]:
            print(f"     {_t.strftime('%d.%m %H:%M', _t.localtime(ts))} {addr[:10]}… {delta:+,.0f} USD")
    elif über:
        print("   -> jede Änderung über der Schwelle hat ein Ereignis erzeugt: in Ordnung")
    else:
        print(f"   -> alle Änderungen lagen unter {schwelle:,.0f} USD: der Markt ist ruhig, kein Fehler")


if __name__ == "__main__":
    main()
