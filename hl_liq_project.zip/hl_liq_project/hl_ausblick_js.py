"""
hl_ausblick_js.py -- Skript des Abschnitts „AU Ausblick 4 Wochen“ im Dashboard (U146, 23.66), ausgeliefert unter /ausblick.js.

Eigene Datei wie hl_chartbild_js (node --check, A7). Baut auf den Helfern der Seite auf ($, getJSON, esc, hideTip, #tip) und wird NACH
dem Hauptskript und /chartbild.js geladen. Daten: /ausblick?coin=.. (hl_ausblick.nutzlast) und für den Reiter „Aktienmarkt“
/aktienmarkt (hl_aktien.nutzlast). Gefragt wird nur, solange der Abschnitt offen und sichtbar ist; jede Anfrage meldet dem Takt
„Abschnitt offen“ (Neuberechnung alle 30 min, 13.1).

Bild: Tageskerzen wie im Chartbild (log. Skala, hohl = Plus, gefüllt = Minus), rechts der Linie „Anker“ der Fächer der nächsten 28 Tage
(Quantile 5–95 %, 10–90 %, 25–75 %, Median) in einem neutralen Ton, gestaffelt nach Deckkraft; Marken +1/+2/+4 Wochen mit der
80-%-Spanne; die Niveaus als Linien ab dem Anker mit Nummer, Name und der Wahrscheinlichkeit, sie in 4 Wochen zu erreichen (Nummern wie
in der Tabelle, nie Farbe allein). Der Stressfächer steht als gestrichelte Klammern daneben (Form statt Farbe: alle freien Farbtöne
kollidieren mit den Niveau-Farben, Prüfskript), seit 23.68 (U156) rechts davon gepunktete Klammern in der Größe der Stressphase; rechts
der Marke +4 W bleiben dafür 16 px frei (bis 23.67 lag die Klammer bei +4 W außerhalb des Zeichenbereichs und war abgeschnitten). Fadenkreuz: Vergangenheit -> Kerze, Zukunft -> Quantile des Tages k, nahe an einem
Niveau -> seine Wahrscheinlichkeiten. Tabelle statt Bild schaltbar. Keine Empfehlung: Wahrscheinlichkeiten einer geprüften
Verteilung mit ihrer Bilanz daneben.
"""

AUSBLICK_JS = r"""// 23.66 Ausblick 4 Wochen (U146): Spannen und Wahrscheinlichkeiten aus einer geprüften Verteilung -- keine Empfehlung.
// Daten: /ausblick?coin=.. (hl_ausblick.py), Reiter „Aktienmarkt“: /aktienmarkt (hl_aktien.py). Nur solange der Abschnitt offen ist.
const AU={bereich:0, tabelle:false, sch:{f90:true, f80:true, f50:true, niveaus:true, stress:true}, reiter:'spannen', gwh:'7', szen:null,
 cache:{}, laeuft:{}, d:null, geo:null, ak:null, akZeit:0, akLaeuft:false};
try{ const s_=JSON.parse(localStorage.getItem('hl_ausblick')||'{}'); if([90,180,365].includes(+s_.bereich)) AU.bereich=+s_.bereich;
 if(s_.sch&&typeof s_.sch==='object') Object.keys(AU.sch).forEach(k=>{ if(typeof s_.sch[k]==='boolean') AU.sch[k]=s_.sch[k]; });
 if(typeof s_.reiter==='string') AU.reiter=s_.reiter; if(['7','14','28'].includes(s_.gwh)) AU.gwh=s_.gwh; }catch(e){}
if(!AU.bereich) AU.bereich=innerWidth<700?90:180;
function auMerken(){ try{ localStorage.setItem('hl_ausblick', JSON.stringify({bereich:AU.bereich, sch:AU.sch, reiter:AU.reiter, gwh:AU.gwh})); }catch(e){} }
const AU_BEREICH=[[90,'3 M'],[180,'6 M'],[365,'12 M']];
const AU_SCH=[['f90','90 %'],['f80','80 %'],['f50','50 %'],['niveaus','Niveaus'],['stress','Stress']];
const AU_REITER=[['spannen','Spannen'],['ziel','Ziellevels'],['gewichte','Gewichte'],['bilanz','Bilanz'],['korr','Korrelationen'],['aktien','Aktienmarkt'],['fehlt','Was fehlt']];
const AU_Q=[0.05,0.10,0.25,0.50,0.75,0.90,0.95];
const AU_RAND=16;                     // px rechts der Marke +4 W: gestrichelte (+6) und gepunktete (+12) Klammern
const AU_F={kerze:'#8b949e', faecher:'#c9d1d9', median:'#e6edf3', kurs:'#e6edf3', grid:'#161b22', ref:'#30363d', muted:'#8b949e', text:'#c9d1d9',
 flaeche:'#01030a', zone:'#0a0e15', stress:'#c9d1d9', bein:'#d55181', ma50:'#3987e5', ma200:'#c98500'};
const AU_FARBE={bein:AU_F.bein, ma50:AU_F.ma50, ma200:AU_F.ma200};

// ---------- Zahlen und Datum (Dezimalkomma, echtes Minus) ----------
function auZ(x,d){ if(x==null||!isFinite(x)) return '—'; const t=(+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d});
 return /[1-9]/.test(t)?t.replace('-','−'):t.replace('-',''); }        // echtes Minuszeichen; gerundete Null ohne Vorzeichen
function auPx(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return auZ(x, a>=1000?0:a>=100?1:a>=1?2:4); }
function auV(x,d){ if(x==null||!isFinite(x)) return '—'; const t=auZ(Math.abs(x),d); return (/[1-9]/.test(t)?(x>0?'+':'−'):'')+t; }
function auPct(x,d){ return x==null||!isFinite(x)?'—':auV(x*100,d==null?1:d)+'\u00a0%'; }
function auPr(x,d){ return x==null||!isFinite(x)?'—':auZ(x*100,d==null?0:d)+'\u00a0%'; }
function auP(x){ if(x==null||!isFinite(x)) return '—'; return x<0.001?'< 0,001':auZ(x, x<0.01?4:3); }
function auDatum(ts){ if(!ts) return '—'; const d=new Date(ts*1000); return String(d.getUTCDate()).padStart(2,'0')+'.'+String(d.getUTCMonth()+1).padStart(2,'0')+'.'+d.getUTCFullYear(); }
function auTagDatum(tag){ return tag==null?'—':auDatum(tag*86400); }
function auKurz(ts){ const d=new Date(ts*1000); return String(d.getUTCDate()).padStart(2,'0')+'.'+String(d.getUTCMonth()+1).padStart(2,'0')+'.'; }
function auZeit(ts){ if(!ts) return '—'; const d=new Date(ts*1000); return auKurz(ts)+' '+String(d.getUTCHours()).padStart(2,'0')+':'+String(d.getUTCMinutes()).padStart(2,'0')+' UTC'; }
function auKuerzen(t,n){ return t.length<=n?t:t.slice(0,n-1).trimEnd()+'…'; }
function auMonat(tag){ const d=new Date(tag*864e5); return ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'][d.getUTCMonth()]+' '+String(d.getUTCFullYear()).slice(2); }
function auAlter(s){ if(s==null||!isFinite(s)) return '—'; if(s<90) return 'vor '+Math.max(0,Math.round(s))+' s'; if(s<5400) return 'vor '+Math.round(s/60)+' min';
 if(s<172800) return 'vor '+auZ(s/3600,1)+' h'; return 'vor '+auZ(s/86400,1)+' Tagen'; }
function auMinus(s){ return String(s).replace(/(^|[\s(\/])-(?=\d)/g,'$1−'); }
function auSchritte(lo,hi,n){ const roh=(hi-lo)/(n||5); if(!(roh>0)) return {w:[lo], st:1}; const mag=Math.pow(10,Math.floor(Math.log10(roh)));
 const st=[1,2,2.5,5,10].map(f=>f*mag).find(s=>s>=roh)||10*mag; const out=[]; for(let v=Math.ceil(lo/st)*st; v<=hi+st*1e-9; v+=st) out.push(+v.toPrecision(12));
 return {w:out, st}; }
function auTickFmt(st){ const s_=String(+(+st).toPrecision(6)), i=s_.indexOf('.'), nd=s_.includes('e')?4:i<0?0:Math.min(4,s_.length-i-1); return v=>auZ(v,nd); }
function auVerteilen(P, oben, unten, abst){
 for(let i=0;i<P.length;i++) P[i].ly=Math.max(P[i].y, i?P[i-1].ly+abst:oben);
 for(let i=P.length-1;i>=0;i--){ const g=i===P.length-1?unten:P[i+1].ly-abst; if(P[i].ly>g) P[i].ly=g; }
 for(let i=0;i<P.length;i++) if(P[i].ly<oben) P[i].ly=oben; }
function auNr(nr,farbe){ return `<span class="aunr" style="border-color:${farbe||'#8b949e'}">${nr}</span>`; }
function auStatus(s){ const k={'trägt':'#3fb950','Hinweis':'#d29922','trägt nicht':'#8b949e','zu kurz':'#6e7681'}[s]||'#8b949e';
 return `<span class="austat" style="border-color:${k};color:${k}">${esc(s||'—')}</span>`; }
function auJa(b){ return b==null?'—':b?'<span style="color:#3fb950">ja</span>':'<span style="color:#d29922">nein</span>'; }
function auFarbe(n){ return n.farbe||AU_FARBE[n.art]||AU_FARBE[n.key]||'#8b949e'; }

// ---------- Laden ----------
function auOffen(){ const p=$('sec-ausblick'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function auCoin(){ const c=$('coin'); return ((c&&c.value)||'BTC').toUpperCase(); }
async function auLaden(zwang){ if(!auOffen()) return; const el=$('aubody'); if(!el) return;
 if(!$('auzeile')) auLeiste();
 const coin=auCoin(), c=AU.cache[coin];
 if(c&&!zwang&&Date.now()-c.zeit<110000){ if(AU.d!==c.d) auZeigen(c.d); return; }
 if(AU.laeuft[coin]) return; AU.laeuft[coin]=true; if(AU.d) el.style.opacity='0.55';
 try{ const d=await getJSON('/ausblick?coin='+encodeURIComponent(coin)); AU.cache[coin]={d, zeit:Date.now()}; if(auCoin()===coin) auZeigen(d); }
 catch(e){ if(!c&&auCoin()===coin) el.innerHTML='<div class="sub">Ausblick nicht erreichbar.</div>'; }
 finally{ AU.laeuft[coin]=false; el.style.opacity='1'; } }
function auLeiste(){ const el=$('aubar'); if(!el) return;
 el.innerHTML=`<div class="auzeile" id="auzeile"><span class="lbl">Rückblick</span>${AU_BEREICH.map(([k,n])=>`<button class="tog ${k===AU.bereich?'on':'off'}" onclick="auBereich(${k})">${n}</button>`).join('')}`
  +`<span class="lbl auab">Ebenen</span>${AU_SCH.map(([k,n])=>`<button class="tog ${AU.sch[k]?'on':'off'}" onclick="auSchicht('${k}')">${n}</button>`).join('')}`
  +`<button class="tog autabbtn ${AU.tabelle?'on':'off'}" onclick="auTabelleUm()" title="Fächer je Tag als Tabelle statt Bild">Tabelle</button></div>`; }
function auBereich(k){ AU.bereich=k; auMerken(); auLeiste(); auZeichne(); }
function auSchicht(k){ AU.sch[k]=!AU.sch[k]; auMerken(); auLeiste(); auZeichne(); }
function auTabelleUm(){ AU.tabelle=!AU.tabelle; auLeiste(); auZeichne(); }
function auReiterUm(k){ AU.reiter=k; auMerken(); auReiter(); if(k==='aktien') auAkLaden(false); }
function auGwH(h){ AU.gwh=h; auMerken(); auReiter(); }
function auSzen(i){ AU.szen=AU.szen===i?null:i; auSzenario(); }

// ---------- Kopf, Lesart, Szenario, Reiter ----------
function auZeigen(d){ const el=$('aubody'); if(!el) return; AU.d=d; if(typeof hideTip==='function') hideTip();
 const P=d&&d.prognose;
 if(!d||!d.ok||!P||!P.spannen){ const F=((d&&d.fehlt)||[]).concat((P&&P.fehlt)||[]);
  el.innerHTML=`<div class="sub" style="margin:8px 0">${esc((F.length?F:['Noch keine Rechnung für diesen Coin -- der Takt rechnet wenige Minuten nach dem Start des Dashboards, danach alle 30 min, solange dieser Abschnitt offen ist.']).join(' · '))}</div>`+auTakt(d); return; }
 const alt=d.jetzt&&P.anker?d.jetzt-P.anker:null, rb=d.rueckblick||{};
 const kopf=`<div class="aukopf"><b>${esc(d.coin)}</b> · Anker <b>${auZeit(P.anker)}</b> (${auAlter(alt)}) · ab <b>${auPx(P.p0)}</b> <span class="lzi">${esc(P.p0_quelle||'')}</span>`
  +` · Bibliothek ${auZ((P.bibliothek||{}).n,0)} Fenster (${esc((P.bibliothek||{}).art||'—')})`
  +` · Rückblick ${rb.stand?auZeit(rb.stand):'<b>steht noch aus</b> (erster Lauf in der Nacht nach dem Einspielen)'}${rb.null_wahl?` · Nullverfahren ${esc(rb.null_wahl.verfahren||'—')}`:''}</div>`;
 const aus=P.ausnahme?`<div class="auausnahme">Ausnahmelage seit ${auZeit(P.ausnahme.seit)}: ${esc(auMinus(P.ausnahme.grund||''))} -- die Spanne ist sofort breiter gerechnet (24 h).</div>`:'';
 const les=P.lesart||[];
 const lesart=`<ul class="aulesart">${les.map((s,i)=>`<li${i===les.length-1?' class="schluss"':''}>${esc(auMinus(s))}</li>`).join('')}</ul>`;
 el.innerHTML=kopf+aus+lesart+`<div id="auleg" class="leg auleg"></div><div id="auplot" class="auplot"></div><div id="auplottab" class="auscroll autabelle"></div>`
  +`<div class="sub aunote">Rechts der Linie „Anker“: die Verteilung der nächsten 28 Tage aus der Pfad-Bibliothek (gleiche Gewichte, heutige Breite). Bänder 90/80/50 %, Linie = Median. ${((P.richtung||{}).mhat&&Object.keys(P.richtung.mhat).length)?'Mit Drift aus der belegten Richtung.':'Ohne Drift: die Richtung ist nicht belegt.'} Niveaus mit Nummer wie in „Ziellevels“ -- Momentaufnahmen (Orders, Liquidationscluster) gelten nur jetzt.</div>`
  +`<div id="auszen" class="auszen"></div><div id="aureiter" class="aureiter"></div><div id="auinhalt"></div>`+auTakt(d);
 auZeichne(); auSzenario(); auReiter(); }
function auTakt(d){ const t=(d&&d.takt)||{}, m=(d&&d.meta)||{};
 return `<div class="aufuss">Modul ${esc((d&&d.version)||'—')} · letzte Rechnung ${m.letzte_prognose?auZeit(+m.letzte_prognose):'—'} (${esc(m.letzte_art||'—')}, ${esc(m.letzte_dauer||'—')} s)`
  +` · Takt ${t.laeuft?'<b>rechnet gerade</b> ('+esc(t.art||'')+')':'bereit'}${t.fehler?' · Fehler: '+esc(t.fehler):''} · Rückblick ${m.rueckblick_stand?auZeit(+m.rueckblick_stand)+' ('+esc(m.rueckblick_dauer||'—')+' s)':'—'}`
  +` · Regeln: KONZEPT_Ausblick.md · Debug „Ausblick: Stand aller Coins als Text“</div>`; }
function auSzenario(){ const el=$('auszen'), d=AU.d; if(!el||!d||!d.prognose) return; const P=d.prognose, B=P.bedingt||[];
 if(d.coin==='PAXG'){ el.innerHTML=''; return; }
 if(!B.length){ el.innerHTML=`<div class="sub">Szenarien mit dem S&amp;P 500: ${esc(((P.fehlt||[]).find(x=>/S&P|aktien/.test(x)))||'noch nicht verfügbar')}</div>`; return; }
 const kn=B.map((e,i)=>`<button class="tog ${AU.szen===i?'on':'off'}" onclick="auSzen(${i})" title="${e.art==='ereignis'?'Ereignis: S&P in 28 Tagen höchstens ':'S&P in '+e.h+' Tagen bei '}${auPct(e.x,0)}">${e.art==='ereignis'?'≤ ':''}${auPct(e.x,0)} · ${e.h} T</button>`).join('');
 const s4=P.bedingt_s4||{};
 let h=`<div class="auszenkopf"><span class="lbl">Wenn der S&amp;P 500 …</span>${kn}</div>`
  +`<div class="sub">Abhängigkeit im Rückblick (S4): ${s4.besteht==null?'noch nicht geprüft':s4.besteht?'<b>belegt</b>':'nicht belegt'}${s4.p!=null?` (p ${auP(s4.p)})`:''}${auS4Stress(s4)}. Aus der gemeinsamen Bibliothek (Kern, lokal-linear) ab einer Episoden-ESS von 15, sonst aus der t-Kopula; der unbedingte Fächer bleibt daneben.</div>`;
 if(AU.szen!=null&&B[AU.szen]){ const e=B[AU.szen], sp=(P.spannen||{})[String(e.h)]||{}, u=sp.q||[];
  const zeile=(nm,q)=>q&&q.preis?`<tr><td>${nm}</td><td class="n">${auPx(q.preis[1])} – ${auPx(q.preis[5])}</td><td class="n">${auPct(Math.expm1(q.q[1]),1)} / ${auPct(Math.expm1(q.q[5]),1)}</td><td class="n">${auPx(q.preis[2])} – ${auPx(q.preis[4])}</td><td class="n">${auPx(q.preis[3])} <span class="lzi">${auPct(Math.expm1(q.q[3]),1)}</span></td><td class="n">${q.p_tiefer!=null?auPr(q.p_tiefer,0):'—'}</td></tr>`:'';
  h+=`<div class="auscroll"><table class="w"><tr><th>${e.art==='ereignis'?`S&amp;P ≤ ${auPct(e.x,0)} in ${e.h} Tagen`:`S&amp;P ${auPct(e.x,0)} in ${e.h} Tagen`}</th><th class="n">80 %</th><th class="n">in %</th><th class="n">50 %</th><th class="n">Median</th><th class="n">tiefer als heute</th></tr>`
   +(e.bib?zeile(`Bibliothek${e.methode==='bibliothek'?' (gilt)':''}<span class="lz">Episoden-ESS ${auZ(e.ess,1)} · größte Episode ${auPr(e.groesste,0)} · Kish ${auZ(e.kish,0)}${e.beta_kern!=null?' · β im Kern '+auZ(e.beta_kern,2):''}</span>`, e.bib):'')
   +(e.kopula?zeile(`t-Kopula${e.methode==='kopula'?' (gilt)':''}<span class="lz">ρ ${auZ(e.kopula.rho,2)} · ν ${e.kopula.nu}</span>`, e.kopula):'')
   +(u.length?`<tr class="aujetzt"><td>ohne Bedingung (Fächer)</td><td class="n">${auPx(u[1])} – ${auPx(u[5])}</td><td class="n">${auPct(sp.pct[1],1)} / ${auPct(sp.pct[5],1)}</td><td class="n">${auPx(u[2])} – ${auPx(u[4])}</td><td class="n">${auPx(u[3])}</td><td class="n">—</td></tr>`:'')
   +`</table></div><div class="sub">${e.methode==='keine'?'Weder Bibliothek (ESS unter 15) noch Kopula verfügbar. ':''}Stehen beide Antworten da, ist ihr Abstand ein Maß der Modellunsicherheit. Beschreibt die gemeinsame Verteilung der Vergangenheit, keine Vorhersage des S&amp;P 500.</div>`; }
 el.innerHTML=h; }
function auReiter(){ const k=$('aureiter'), el=$('auinhalt'), d=AU.d; if(!k||!el||!d) return;
 k.innerHTML=AU_REITER.map(([r,n])=>`<button class="tog ${AU.reiter===r?'on':'off'}" onclick="auReiterUm('${r}')">${n}</button>`).join('');
 const f={spannen:auSpannen, ziel:auZiel, gewichte:auGewichte, bilanz:auBilanz, korr:auKorr, aktien:auAktien, fehlt:auFehlt}[AU.reiter]||auSpannen;
 try{ el.innerHTML=f(d); }catch(e){ el.innerHTML=`<div class="sub">Reiter nicht darstellbar: ${esc(String(e))}</div>`; } }
// 23.67: Hinweis an den Szenarien, wenn die Rosenblatt-PIT unter Aktienstress im Rückblick nicht gleichverteilt war (p < 0,05) --
// nachträglich ergänzt, ändert kein Urteil (KONZEPT_Ausblick.md 12.2)
function auS4Stress(s4){ const ps=Object.entries((s4&&s4.pit_stress)||{}).filter(([h,p])=>p!=null&&p<0.05).sort((a,b)=>+a[0]-+b[0]);
 return ps.length?`; <b>unter Aktienstress im Rückblick nicht kalibriert</b> (${ps.map(([h,p])=>`PIT p ${auP(p)} bei ${h} T`).join(', ')})`:''; }
function auSpannen(d){ const P=d.prognose, sp=P.spannen||{}, F=P.F||{}, st=P.stress, rb=d.rueckblick||{}, wahl=((rb.breite||{}).wahl)||{};
 const kopf=`<tr><th>Horizont</th>${AU_Q.map(q=>`<th class="n">${q===0.5?'Median':auZ(q*100,0)+' %'}</th>`).join('')}<th class="n">σ</th></tr>`;
 const z=h=>{ const s=sp[String(h)]; if(!s) return ''; const sig=F[String(h)]?Math.sqrt(F[String(h)]):null;
  return `<tr><td>${h===7?'1 Woche':h===14?'2 Wochen':'4 Wochen'}<span class="lz">bis ${auKurz(P.anker+h*86400)}</span></td>${s.q.map((x,i)=>`<td class="n">${auPx(x)}<span class="lz">${auPct(s.pct[i],1)}</span></td>`).join('')}<td class="n">${sig!=null?auZ(sig*100,1)+' %':'—'}</td></tr>`; };
 let h=`<div class="auscroll"><table class="w">${kopf}${[7,14,28].map(z).join('')}</table></div>`;
 if(st&&st.spannen) h+=`<h3 class="auh3">Stressfächer — Form der unruhigsten Phase seit 2020 (${auDatum(st.zeitraum[0])} – ${auDatum(st.zeitraum[1])}, ${auZ(st.n,0)} Fenster), bei heutiger Schwankung</h3><div class="sub">Er übernimmt die Form der Bewegungen jener Zeit, nicht ihre Größe: Die Breite ist die von heute. Weil die Wege damals dicke Ränder hatten, kann die Mitte schmaler ausfallen als beim normalen Fächer.</div><div class="auscroll"><table class="w">${kopf}`
  +[7,14,28].map(hh=>{ const s=st.spannen[String(hh)]; return s?`<tr><td>${hh} Tage</td>${s.q.map((x,i)=>`<td class="n">${auPx(x)}<span class="lz">${auPct(s.pct[i],1)}</span></td>`).join('')}<td></td></tr>`:''; }).join('')+`</table></div>`;
 if(P.stress_groesse) h+=auStressGroesse(P.stress_groesse);
 const w=Object.entries(wahl).map(([hh,x])=>`${hh} T: ${(x||[]).length?x.join('+'):'Grundmodell'}`).join(' · ');
 h+=`<div class="sub">Breite F(τ, h) aus HAR-log an den 6-h-Ankern (Tag/Woche/Monat der 24-h-Schwankung)${w?' · Modell je Stützstelle: '+esc(w):''}. σ = √F, die Spannweite einer Normalverteilung wäre ±1,28 σ für 80 %; der Fächer nimmt die Form aus den echten Pfaden (Ballungen, dicke Ränder). Prozente zum Startpreis ${auPx(P.p0)}.</div>`;
 return h; }
// 23.68 (U156, KONZEPT_Ausblick 13.14): Szenario in der Größe der unruhigsten Phase -- die tatsächlichen Wege der eigenen Fenster jener
// Zeit ohne deren Trend, am heutigen Startpreis; 80 und 90 % bei 7/14/28 Tagen und das Verhältnis der Breite zur heutigen. Kein Modell.
function auStressGroesse(sg){ const titel=`Szenario: so weit gingen die Wege in der unruhigsten Phase seit 2020 (${auDatum(sg.zeitraum[0])} – ${auDatum(sg.zeitraum[1])}), ohne deren Trend — kein Modell für heute`;
 if(sg.hinweis||!sg.spannen) return `<h3 class="auh3 ausg">${titel}</h3><div class="sub ausghinweis">${esc(sg.hinweis||'nicht berechnet')}.</div>`;
 const z=hh=>{ const s=sg.spannen[String(hh)]; if(!s) return '';
  const sp=(i,j)=>`<td class="n">${auPx(s.q[i])} – ${auPx(s.q[j])}<span class="lz">${auPct(s.pct[i],1)} / ${auPct(s.pct[j],1)}</span></td>`;
  return `<tr><td>${hh} Tage<span class="lz">bis ${auKurz(AU.d.prognose.anker+hh*86400)}</span></td>${sp(1,5)}${sp(0,6)}</tr>`; };
 const v=sg.verhaeltnis_28;
 return `<h3 class="auh3 ausg">${titel}</h3><div class="sub">Die tatsächlichen Wege der ${auZ(sg.n,0)} eigenen Fenster jener Zeit, nicht auf die damalige Schwankung umgerechnet; abgezogen ist nur ihr mittlerer Trend. Am heutigen Startpreis ${auPx(AU.d.prognose.p0)} angesetzt.${v!=null&&isFinite(v)?` <b>Damals ${auZ(v,1)}-mal so breit wie heute</b> (80 %, 28 Tage).`:''} Wirkt auf nichts: nicht auf Rückblick, Bilanz, Ziellevels oder Szenarien.</div>`
  +`<div class="auscroll"><table class="w ausgtab"><tr><th>Horizont</th><th class="n">80 %</th><th class="n">90 %</th></tr>${[7,14,28].map(z).join('')}</table></div>`; }
function auZiel(d){ const P=d.prognose, NV=P.niveaus||[];
 if(!NV.length) return '<div class="sub">Keine Niveaus im Bereich der Verteilung (1 %–99 % nach 4 Wochen).</div>';
 let z='', jetzt=false;
 NV.forEach((n,i)=>{ if(!jetzt&&n.px<P.p0){ z+=`<tr class="aujetzt"><td></td><td>Start (Anker)</td><td class="n">${auPx(P.p0)}</td><td class="n">0 %</td><td colspan="5"></td></tr>`; jetzt=true; }
  const p=n.p||{}, e=h=>p[String(h)]?auPr(p[String(h)][0],0):'—';
  z+=`<tr><td>${auNr(i+1,auFarbe(n))}</td><td>${esc(n.name)}<span class="lz">${esc(n.quelle||'')}${n.momentaufnahme?' · Momentaufnahme':''}</span></td><td class="n">${auPx(n.px)}</td><td class="n">${auPct(n.abstand,1)}</td>`
   +(n.erreicht?`<td class="n" colspan="4">seit dem Anker erreicht</td>`:`<td class="n">${e(7)}</td><td class="n">${e(14)}</td><td class="n">${e(28)}</td><td class="n">${p['28']?auPr(p['28'][1],0):'—'}</td>`)
   +`<td>${esc(n.pruef||'')}</td></tr>`; });
 if(!jetzt) z+=`<tr class="aujetzt"><td></td><td>Start (Anker)</td><td class="n">${auPx(P.p0)}</td><td class="n">0 %</td><td colspan="5"></td></tr>`;
 const s3=((d.rueckblick||{}).s3||{}).h||{};
 const pr=P.pruefniveaus||{};
 const prz=['7','14','28'].map(h=>`<tr><td>${h} Tage</td>${(pr[h]||[]).map(x=>`<td class="n">${auV(x[0],1)} σ: ${auPr(x[1],0)}</td>`).join('')}</tr>`).join('');
 return `<div class="auscroll"><table class="w"><tr><th>Nr.</th><th>Niveau</th><th class="n">Preis</th><th class="n">Abstand</th><th class="n">erreicht in 1 W</th><th class="n">2 W</th><th class="n">4 W</th><th class="n">Schluss jenseits in 4 W</th><th>Prüfstand</th></tr>${z}</table></div>`
  +`<div class="sub">„Erreicht“ = das laufende Hoch (Tief) eines Pfads berührt das Niveau bis zum Tag; „Schluss jenseits“ = der Kurs steht am Ende darüber (darunter). Aus derselben Verteilung wie der Fächer, ohne Annahme, dass Niveaus anziehen oder abweisen (U110/U141: nicht belegt).`
  +(Object.keys(s3).length?` Rückblick S3 (Montage seit 2022, Prüfniveaus k·√F, Swings, runde Zahlen): ${['7','14','28'].map(h=>s3[h]&&s3[h].n?`${h} T Skill ${auZ(s3[h].skill,3)}, Steigung ${auZ(s3[h].steigung,2)} ${s3[h].besteht?'(kalibriert)':'(nicht kalibriert)'}`:'').filter(Boolean).join(' · ')}.`:' Der Rückblick S3 steht noch aus.')+`</div>`
  +`<details class="audetails"><summary>Prüfniveaus der Vorwärtsbilanz (±k·σ ab dem Anker: Erreichen)</summary><div class="auscroll"><table class="w">${prz}</table></div></details>`; }
function auGewichte(d){ const rb=d.rueckblick||{}, G=(rb.gewichte||{})[AU.gwh]||{}, K=G.kandidaten||[], gr=d.coin==='PAXG'?'paxg':'krypto', T=((rb.tor||{})[gr]||{});
 const kn=['7','14','28'].map(h=>`<button class="tog ${AU.gwh===h?'on':'off'}" onclick="auGwH('${h}')">${h} Tage</button>`).join('');
 if(!rb.stand) return `<div class="auzeile">${kn}</div><div class="sub">Der erste Rückblick steht noch aus (Takt: in der Nacht nach dem Einspielen, danach sonntags ab 02:00 UTC).</div>`;
 const t=T[AU.gwh]||{};
 const torTxt=`Tor ${AU.gwh} T: <b>${t.offen?'offen':'zu'}</b>${t.offen&&t.seit?' seit '+auDatum(t.seit):''} · Clark-West p ${auP((t.cw||{}).p)} (Hälften ${auJa((t.cw||{}).haelften)}) · CRPS p ${auP((t.crps||{}).p)} (Hälften ${auJa((t.crps||{}).haelften)}) · R²_OS ${auPct(t.r2_os,2)} (90 %: ${auPct(t.r2_lo,2)} bis ${auPct(t.r2_hi,2)})`;
 const z=K.map(e=>`<tr><td>${esc(e.key)}<span class="lz">${esc(e.name)}</span></td><td>${esc(e.familie)}</td><td class="n">${auV(e.gewicht,3)}</td><td class="n">${e.spur?auV(e.spur[0],3)+' … '+auV(e.spur[2],3):'—'}</td>`
  +`<td class="n">${e.vorzeichen!=null?auPr(e.vorzeichen,0):'—'}</td><td class="n">${e.dmse!=null?auV(e.dmse*1e4,2):'—'}</td><td class="n">${auP(e.p)}<span class="lz">${e.null_n?e.null_n+' Surrogate':''}</span></td><td class="n">${auP(e.p_holm)}</td>`
  +`<td class="n">${e.dmse_h1!=null?(e.dmse_h1>0?'+':'−')+' / '+(e.dmse_h2>0?'+':'−'):'—'}</td><td>${auStatus(e.status)}</td><td>${e.seit!=null?auTagDatum(e.seit):'—'}<span class="lz">aktiv ${auPr(e.aktiv_oos,0)}</span></td></tr>`).join('');
 return `<div class="auzeile">${kn}</div><div class="sub">${torTxt}</div><div class="auscroll"><table class="w"><tr><th>Kandidat</th><th>Familie</th><th class="n">Gewicht</th><th class="n">Spur</th><th class="n">Vorzeichen stabil</th><th class="n">Beitrag ΔMSE ×10⁻⁴</th><th class="n">p</th><th class="n">p Holm</th><th class="n">Hälften</th><th>Status</th><th>seit</th></tr>${z}</table></div>`
  +`<div class="sub">Gepoolter Ridge ohne Achsenabschnitt, Walk-forward ab 01.01.2022 alle 28 Tage (Embargo bis zum Zielende). Beitrag = Verschlechterung außerhalb der Stichprobe, wenn der Kandidat fehlt; p gegen ${esc(G.verfahren||'—')}-Surrogate (α ${auZ(G.alpha,3)}), Holm über alle Kandidaten. „Trägt“ nur mit p Holm unter α und positivem Beitrag in beiden Hälften. Gewichte wirken nur bei offenem Tor.</div>`; }
function auBilanz(d){ const rb=d.rueckblick||{};
 if(!rb.stand) return '<div class="sub">Der erste Rückblick steht noch aus.</div>';
 const S1=rb.s1||{}, h1=S1.h||{}; let h='';
 h+=`<h3 class="auh3">S1 Breite — CRPS des Fächers (B0) gegen eine Normalverteilung mit der Schwankung der letzten 365 Tage (B1)</h3><div class="auscroll"><table class="w"><tr><th>Horizont</th><th class="n">CRPS B0</th><th class="n">CRPS B1</th><th class="n">Gewinn</th><th class="n">p</th><th class="n">Hälften</th><th>Deckung 80 % je Coin (Soll 80 % ± 2 SE)</th><th>besteht</th></tr>`
  +['7','14','28'].map(k=>{ const e=h1[k]||{}, dk=e.deckung||{};
   return `<tr><td>${k} Tage</td><td class="n">${auZ(e.crps_b0,4)}</td><td class="n">${auZ(e.crps_b1,4)}</td><td class="n">${auPct(e.gewinn_rel,1)}</td><td class="n">${auP(e.p)}</td><td class="n">${auJa(e.haelften)}</td>`
    +`<td>${Object.entries(dk).map(([c,x])=>`${esc(c)} ${auPr(x.d80,0)}${x.ok?'':' ✗'}`).join(' · ')||'—'}</td><td>${auJa(e.besteht)}</td></tr>`; }).join('')+`</table></div>`;
 const stn=S1.stunde||{};
 if(Object.keys(stn).length) h+=`<div class="sub">Untertägige Anker (13.1): ${Object.entries(stn).map(([s,x])=>`${s} UTC ${['7','14','28'].map(k=>x[k]?`${k} T ${x[k].besteht?'✓':'✗'}`:'').filter(Boolean).join(' ')}`).join(' · ')}</div>`;
 const Tg=rb.tor||{};
 h+=`<h3 class="auh3">Tor der Richtung (Clark-West und CRPS-Gewinn, beide Hälften)</h3><div class="auscroll"><table class="w"><tr><th>Gruppe</th><th>Horizont</th><th>Tor</th><th class="n">CW p</th><th class="n">CRPS p</th><th class="n">R²_OS</th><th class="n">n</th></tr>`
  +['krypto','paxg'].map(g=>['7','14','28'].map(k=>{ const t=(Tg[g]||{})[k]||{}; return `<tr><td>${g==='krypto'?'Krypto':'PAXG'}</td><td>${k} T</td><td>${t.offen?'<b>offen</b>'+(t.seit?' seit '+auDatum(t.seit):''):'zu'}${t.grund?'<span class="lz">'+esc(t.grund)+'</span>':''}</td><td class="n">${auP((t.cw||{}).p)}</td><td class="n">${auP((t.crps||{}).p)}</td><td class="n">${auPct(t.r2_os,2)}</td><td class="n">${t.n!=null?auZ(t.n,0):'—'}</td></tr>`; }).join('')).join('')+`</table></div>`;
 const S3=(rb.s3||{}).h||{};
 h+=`<h3 class="auh3">S3 Ziellevels — Erreich-Wahrscheinlichkeiten im Rückblick (Montage seit 2022)</h3><div class="auscroll"><table class="w"><tr><th>Horizont</th><th class="n">n</th><th class="n">Brier Fächer</th><th class="n">Brier Normal</th><th class="n">Skill</th><th class="n">Steigung (Soll 1)</th><th>besteht</th></tr>`
  +['7','14','28'].map(k=>{ const e=S3[k]||{}; return `<tr><td>${k} T</td><td class="n">${auZ(e.n,0)}</td><td class="n">${auZ(e.brier_b0,4)}</td><td class="n">${auZ(e.brier_b1,4)}</td><td class="n">${auZ(e.skill,3)}</td><td class="n">${auZ(e.steigung,2)}</td><td>${auJa(e.besteht)}</td></tr>`; }).join('')+`</table></div>`;
 const S4=rb.s4||{}, v=S4.variogramm||{};
 h+=`<h3 class="auh3">S4 Gemeinsame Form mit dem S&amp;P 500</h3><div class="sub">${S4.grund?esc(S4.grund):`Variogramm-Gewinn ${auZ(v.mittel,4)} (p ${auP(v.p)}, Hälften ${auZ(v.h1,4)} / ${auZ(v.h2,4)}) → Abhängigkeit ${S4.besteht?'<b>belegt</b>':'nicht belegt'} (${auZ(S4.n,0)} Ursprünge)`}`
  +Object.entries(S4.rosenblatt||{}).map(([k,e])=>` · Rosenblatt-PIT ${k} T: p ${auP((e.alle||{}).p)}, unter Aktienstress p ${auP((e.stress||{}).p)}`).join('')+`</div>`;
 const VB=rb.vorwaerts||{};
 if(Object.keys(VB).length&&!VB.fehler) h+=`<h3 class="auh3">Vorwärtsbilanz (an den 6-h-Ankern gespeichert, nach h Tagen ausgewertet)</h3><div class="auscroll"><table class="w"><tr><th>Horizont</th><th class="n">n</th><th class="n">Deckung 50/80/90</th><th class="n">CRPS</th><th class="n">gegen B1</th><th class="n">Niveaus: mittleres p / Quote</th></tr>`
  +Object.entries(VB).map(([k,b])=>`<tr><td>${k} T${b.genug?'':' <span class="lzi">(noch wenige)</span>'}</td><td class="n">${auZ(b.n,0)}</td><td class="n">${auPr(b.deckung['50'],0)} / ${auPr(b.deckung['80'],0)} / ${auPr(b.deckung['90'],0)}</td><td class="n">${auZ(b.crps,4)}</td><td class="n">${auZ(b.crps_b1,4)}</td><td class="n">${b.niveau&&b.niveau.n?auPr(b.niveau.mittel_p,0)+' / '+auPr(b.niveau.quote,0)+' (n '+b.niveau.n+')':'—'}</td></tr>`).join('')+`</table></div>`;
 const BR=(rb.breite||{}).h||{};
 h+=`<h3 class="auh3">Breite HAR-X: Zusätze gegen das Grundmodell (QLIKE, Holm über X1–X4, beide Hälften)</h3><div class="auscroll"><table class="w"><tr><th>Stützstelle</th>${['X1','X2','X3','X4'].map(x=>`<th>${x}</th>`).join('')}<th>Wahl</th></tr>`
  +Object.entries(BR).map(([k,T])=>`<tr><td>${k} T</td>${['X1','X2','X3','X4'].map(x=>{ const e=T[x]||{}; return `<td>${e.p_holm!=null?`${auV(e.mittel,4)} · p Holm ${auP(e.p_holm)} ${e.besteht?'✓':''}`:esc(e.grund||'—')}</td>`; }).join('')}<td>${esc((((rb.breite||{}).wahl||{})[k]||[]).join('+')||'Grundmodell')}</td></tr>`).join('')+`</table></div>`
  +`<div class="sub">X1 implizite Volatilität (DVOL), X2 Schwankung des S&amp;P 500 (5/20 Tage), X3 Finanzstress (STLFSI4), X4 ln VIX². Rückblick ${auZeit(rb.stand)}, ${auZ(rb.dauer,0)} s.</div>`;
 return h; }
function auKorr(d){ const K=(d.rueckblick||{}).korrelationen;
 if(!K) return '<div class="sub">Der erste Rückblick steht noch aus.</div>';
 let h='<div class="sub"><b>Beschreibend</b> -- belegt ist nur, was die Gewichtsprüfung besteht (Reiter „Gewichte“). Spearman der letzten 3 Jahre.</div>';
 const Z=K.zukunft||{};
 const namen=Object.keys(Z['7']||{});
 if(namen.length) h+=`<h3 class="auh3">Kandidat gegen die normierte Rendite der folgenden Tage (Krypto gepoolt) mit 90-%-Nullband aus 200 zirkulären Verschiebungen</h3><div class="auscroll"><table class="w"><tr><th>Kandidat</th>${['7','14','28'].map(k=>`<th class="n">${k} T</th>`).join('')}</tr>`
  +namen.map(n=>`<tr><td>${esc(n)}</td>${['7','14','28'].map(k=>{ const e=(Z[k]||{})[n]; if(!e) return '<td class="n">—</td>'; const aus=e.rho<e.null_lo||e.rho>e.null_hi;
   return `<td class="n">${aus?'<b>':''}${auV(e.rho,3)}${aus?'</b>':''}<span class="lz">Null ${auV(e.null_lo,3)} … ${auV(e.null_hi,3)}</span></td>`; }).join('')}</tr>`).join('')+`</table></div><div class="sub">Fett = außerhalb des Nullbands (bei 36 × 3 Zellen erwartet man rund 11 allein aus Zufall).</div>`;
 const M=(K.kandidaten||{}).matrix, N=(K.kandidaten||{}).namen||[];
 if(M){ const paare=[]; for(let i=0;i<N.length;i++) for(let j=i+1;j<N.length;j++) if(M[i][j]!=null) paare.push([Math.abs(M[i][j]),M[i][j],N[i],N[j]]);
  paare.sort((a,b)=>b[0]-a[0]);
  h+=`<h3 class="auh3">Die engsten Paare der Kandidaten untereinander (BTC)</h3><div class="sub">${paare.slice(0,12).map(p=>`${esc(p[2])}–${esc(p[3])} ${auV(p[1],2)}`).join(' · ')||'—'}</div>`; }
 const GL=K.gleichlauf;
 if(GL&&GL.matrix) h+=`<h3 class="auh3">Gleichlauf der Coins (28-Tage-Renditen, ${auZ(GL.n,0)} Tage)</h3><div class="auscroll"><table class="w"><tr><th></th>${GL.coins.map(c=>`<th class="n">${esc(c)}</th>`).join('')}</tr>`
  +GL.coins.map((c,i)=>`<tr><td>${esc(c)}</td>${GL.matrix[i].map((x,j)=>`<td class="n">${i===j?'—':auZ(x,2)}</td>`).join('')}</tr>`).join('')+`</table></div>`;
 return h; }
function auFehlt(d){ const P=d.prognose||{}, F=(d.fehlt||[]).concat(P.fehlt||[]).concat(((d.rueckblick||{}).fehlt)||[]);
 return F.length?`<ul class="aufehlt">${[...new Set(F)].map(x=>`<li>${esc(auMinus(x))}</li>`).join('')}</ul>`:'<div class="sub">Nichts -- alle Quellen vorhanden.</div>'; }

// ---------- Reiter Aktienmarkt (/aktienmarkt, beschreibend) ----------
async function auAkLaden(zwang){ if(AU.akLaeuft) return; if(AU.ak&&!zwang&&Date.now()-AU.akZeit<300000){ if(AU.reiter==='aktien') auReiter(); return; }
 AU.akLaeuft=true;
 try{ AU.ak=await getJSON('/aktienmarkt'); AU.akZeit=Date.now(); }catch(e){ AU.ak={ok:false, fehlt:['Aktienmarkt nicht erreichbar']}; }
 finally{ AU.akLaeuft=false; if(AU.reiter==='aktien') auReiter(); } }
function auAktien(){ const A=AU.ak;
 if(!A) return '<div class="sub">lädt …</div>';
 let h=`<div class="sub"><b>Beschreibend, nicht geprüft</b> -- der Aktienmarkt liefert dem Ausblick eine Koordinate (Szenarien) und einen Maßstab (Breite), keine Richtung (RECHERCHE_Aktienmarkt). ${A.boerse_offen?'US-Börse offen.':'US-Börse geschlossen: Werte der Perps sind Perp-Stände.'}</div>`;
 const BW=(A.barometer||{}).werte||{};
 if(Object.keys(BW).length) h+=`<h3 class="auh3">Barometer rund um die Uhr (Hyperliquid xyz, ${A.barometer.ts?auZeit(A.barometer.ts):'—'})</h3><div class="auscroll"><table class="w"><tr><th>Wert</th><th class="n">Stand</th><th class="n">zum Vortag</th></tr>`
  +Object.entries(BW).map(([k,e])=>`<tr><td>${esc(k)}</td><td class="n">${auPx(e.mark)}</td><td class="n">${auPct(e.aend,1)}</td></tr>`).join('')+`</table></div>`
  +(((A.barometer||{}).eingestellt||[]).length?`<div class="sub">Eingestellt auf xyz und deshalb nicht gezeigt (letzter Kurs eingefroren): ${A.barometer.eingestellt.map(esc).join(', ')}</div>`:'');
 const GL=A.gleichlauf||{};
 if(Object.keys(GL).length){ h+=`<h3 class="auh3">Gleichlauf mit dem S&amp;P 500 (Tagesrenditen, Kurs zum S&amp;P-Schluss 16:00 New York; 90-%-Intervall Blockbootstrap)</h3><div class="auscroll"><table class="w"><tr><th>Coin</th><th class="n">60 T</th><th class="n">120 T</th><th class="n">260 T</th><th class="n">Beta ab / auf</th><th>fiel an … von … S&amp;P-Verlusttagen (260 T · seit 2020)</th></tr>`;
  Object.entries(GL).forEach(([c,g])=>{ const r=k=>g[k]&&g[k].r!=null?`${auZ(g[k].r,2)}<span class="lz">${auZ(g[k].lo,2)} … ${auZ(g[k].hi,2)}</span>`:'—';
   const t=(x,s)=>x&&x[s]&&x[s].n?`${x[s].k} von ${x[s].n} (${auPr(x[s].k/x[s].n,0)})`:'—';
   h+=`<tr><td>${esc(c)}</td><td class="n">${r('60')}</td><td class="n">${r('120')}</td><td class="n">${r('260')}</td><td class="n">${auZ(g.beta_ab,2)} / ${auZ(g.beta_auf,2)}</td>`
    +`<td>S&amp;P &lt; 0: ${t(g.tafel_260,'0.0')} · ${t(g.tafel_2020,'0.0')}<span class="lz">S&amp;P &lt; −1 %: ${t(g.tafel_260,'-0.01')} · ${t(g.tafel_2020,'-0.01')}</span></td></tr>`; });
  h+=`</table></div><div class="sub">„Immer“ wäre 100 % -- die Tafel zeigt, wie nah die Verlusttage herankommen (Studie U147 im Debug: Bedingungen bis −3 %, Wochen, 4 Wochen, Vorlauf).</div>`; }
 const S=A.stress||{};
 const sz=[['vix','VIX'],['vix3m','VIX3M'],['vvix','VVIX (Cboe)'],['vix9d','VIX9D (Cboe)'],['hy','Hochzinsspread'],['baa10y','Baa − 10 J'],['stlfsi','STLFSI4'],['nfci','NFCI'],['sp','S&P 500'],['ndx','Nasdaq-100']]
  .filter(([k])=>S[k]&&S[k].wert!=null).map(([k,n])=>`<tr><td>${esc(n)}</td><td class="n">${auZ(S[k].wert,2)}</td><td class="n">${S[k].pz!=null?auPr(S[k].pz,0):'—'}</td><td class="n">${S[k].abstand_hoch!=null?auPct(S[k].abstand_hoch,1):'—'}</td><td>${S[k].ts?auDatum(S[k].ts):'—'}<span class="lz">seit ${S[k].seit?auDatum(S[k].seit):'—'}</span></td></tr>`).join('');
 if(sz) h+=`<h3 class="auh3">Stress${S.vix_vix3m?` · VIX/VIX3M ${auZ(S.vix_vix3m,2)} ${S.vix_vix3m>1?'(invertiert)':''}`:''}</h3><div class="auscroll"><table class="w"><tr><th>Reihe</th><th class="n">Wert</th><th class="n">Perzentil im Archiv</th><th class="n">Abstand zum 252-T-Hoch</th><th>Stand</th></tr>${sz}</table></div>`;
 const E=A.etf||{}, CF=A.cftc||{}, FI=A.finra||{}, MS=A.strategy||{};
 let k='';
 // 23.68 (U165): unvollständige Tage (ein Fonds ohne Zahl, der am Vortag eine hatte) markiert; Summen nur über vollständige Tage
 if((E.tage||[]).length){ const e0=E.tage[0], uv=E.tage.slice(1,3).filter(t=>(t.fehlt||[]).length), Z=E.zaehlung||{};
  k+=`<tr><td>Spot-ETF-Flüsse (Farside)</td><td class="n">${auV(e0.mio_usd,0)} Mio${(e0.fehlt||[]).length?`<span class="lz" style="color:#d29922">unvollständig (fehlt: ${esc(e0.fehlt.join(', '))})</span>`:''}</td>`
   +`<td>5 T ${auV(E.summe5,0)} Mio (${E.voll5!=null?E.voll5:'—'} vollständige Tage) · 20 T ${auV(E.summe20,0)} Mio (${E.voll20!=null?E.voll20:'—'} vollständige Tage)`
   +`<span class="lz">Tag ${auDatum(e0.ts)}, abgerufen ${auZeit(e0.abgerufen)}${e0.fassungen>1?', '+e0.fassungen+' Fassungen (revidiert)':''}`
   +`${uv.map(t=>` · ${auDatum(t.ts)} unvollständig (fehlt: ${esc(t.fehlt.join(', '))})`).join('')}${(E.eingestellt||[]).length?` · eingestellt (keine Zahl an 4 Handelstagen): ${esc(E.eingestellt.join(', '))}`:''}`
   +`${Z.n?` · jüngster Tag beim Abruf unvollständig: ${Z.unvollstaendig} von ${Z.n} Abrufen`:''}</span></td></tr>`; }
 Object.entries(CF).forEach(([code,e])=>{ if(e.ts) k+=`<tr><td>CFTC ${esc(e.name)}</td><td class="n">${e.lev_netto!=null?auV(e.lev_netto,0):'—'}</td><td>Leveraged Funds netto${e.am_netto!=null?' · Asset Manager netto '+auV(e.am_netto,0):''}<span class="lz">Stand ${auDatum(e.ts)}${e.oi!=null?' · OI '+auZ(e.oi,0):''}</span></td></tr>`; });
 Object.entries(FI).forEach(([s,e])=>{ k+=`<tr><td>Leerverkaufsquote ${esc(s)} (FINRA)</td><td class="n">${auPr(e.quote5,0)}</td><td>5 Handelstage<span class="lz">letzter Tag ${auPr(e.quote1,0)}, ${auDatum(e.ts)}</span></td></tr>`; });
 if(MS.btc!=null) k+=`<tr><td>Strategy: BTC-Bestand (SEC 8-K)</td><td class="n">${auZ(MS.btc,0)}</td><td>${MS.netto_woche!=null?'zuletzt '+auV(MS.netto_woche,0)+' BTC':''}${MS.mstr?` · MSTR ${auPx(MS.mstr)}`:''}${MS.strc?` · STRC ${auPx(MS.strc)} (${auPct(MS.strc_nennwert,1)} zum Nennwert 100)`:''}<span class="lz">Stand ${MS.btc_ts?auDatum(MS.btc_ts):'—'}</span></td></tr>`;
 if(k) h+=`<h3 class="auh3">Krypto-Aktien und Positionierung</h3><div class="auscroll"><table class="w"><tr><th>Größe</th><th class="n">Wert</th><th>Einordnung</th></tr>${k}</table></div>`;
 const ST=(A.struktur||{}).top10||[];
 if(ST.length) h+=`<h3 class="auh3">Die zehn größten Werte (xyz, Abstand zum Hoch seit der Listung) · Mittel ${auPct(A.struktur.mittel_abstand,1)}</h3><div class="sub">${ST.map(t=>`${esc(t.k)} ${auPct(t.abstand,1)}`).join(' · ')}</div>`;
 const Q=A.quellen||[];
 if(Q.length) h+=`<details class="audetails"><summary>Datenquellen (Stand je Quelle)</summary><div class="auscroll"><table class="w"><tr><th>Quelle</th><th>zuletzt ok</th><th>Fehler</th></tr>`
  +Q.map(q=>`<tr><td>${esc(q.name)}${q.optional?' <span class="lzi">(optional)</span>':''}</td><td>${q.ok?auZeit(q.ok):'—'}${q.info?'<span class="lz">'+esc(q.info)+'</span>':''}</td><td>${q.fehler?esc(q.fehler):'—'}${q.pause_bis&&q.pause_bis*1000>Date.now()?'<span class="lz">Pause bis '+auZeit(q.pause_bis)+'</span>':''}</td></tr>`).join('')+`</table></div></details>`;
 if((A.fehlt||[]).length) h+=`<ul class="aufehlt">${A.fehlt.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`;
 return h; }

// ---------- Legende ----------
function auLegende(modus){ const el=$('auleg'); if(!el) return; if(!modus){ el.innerHTML=''; return; }
 const li=(c,dash,w)=>`<svg width="20" height="8" aria-hidden="true"><line x1="1" y1="4" x2="19" y2="4" stroke="${c}" stroke-width="${w||2}"${dash?` stroke-dasharray="${dash}"`:''}/></svg>`;
 const T=[];
 if(modus.kerzen) T.push(`<span><svg width="24" height="12" aria-hidden="true"><rect x="2.5" y="2.5" width="6" height="7" fill="none" stroke="${AU_F.kerze}"/><rect x="14" y="2" width="7" height="8" fill="${AU_F.kerze}"/></svg>Tageskerze: hohl = Plus, gefüllt = Minus</span>`);
 else T.push(`<span>${li(AU_F.kerze,'',1.5)}Tagesschluss</span>`);
 const band=o=>`<svg width="20" height="12" aria-hidden="true"><rect x="1" y="2" width="18" height="8" fill="${AU_F.faecher}" opacity="${o}"/></svg>`;
 if(modus.f90) T.push(`<span>${band(0.10)}90 %</span>`); if(modus.f80) T.push(`<span>${band(0.2)}80 %</span>`); if(modus.f50) T.push(`<span>${band(0.34)}50 %</span>`);
 T.push(`<span>${li(AU_F.median,'',1.6)}Median</span>`);
 if(modus.stress) T.push(`<span><svg width="20" height="12" aria-hidden="true"><path d="M5,1L10,1L10,11L5,11" fill="none" stroke="${AU_F.stress}" stroke-dasharray="2,2"/></svg>Stressfächer 80 % (gestrichelt)</span>`);
 if(modus.sg) T.push(`<span><svg width="20" height="12" aria-hidden="true"><path d="M5,1L10,1L10,11L5,11" fill="none" stroke="${AU_F.stress}" stroke-width="1.4" stroke-dasharray="1,2"/></svg>Größe der Stressphase 80 % (gepunktet)</span>`);
 if(modus.niveaus) T.push(`<span>${auNr(1,'#39d3ff')} Niveaus mit Erreichen in 4 W</span>`);
 T.push(`<span>${li(AU_F.kurs,'3,3',1)}Start (Anker)</span>`);
 el.innerHTML=T.join(''); }

// ---------- Bild ----------
function auFaecherTabelle(P){ const F=P.faecher||[], z=[];
 F.forEach((q,i)=>{ const k=i+1; z.push(`<tr><td>+${k} ${k===1?'Tag':'Tage'}<span class="lz">${auKurz(P.anker+k*86400)}</span></td>${q.map(x=>`<td class="n">${auPx(P.p0*Math.exp(x))}<span class="lz">${auPct(Math.expm1(x),1)}</span></td>`).join('')}</tr>`); });
 return `<table class="w"><tr><th>Tag</th>${AU_Q.map(q=>`<th class="n">${q===0.5?'Median':auZ(q*100,0)+' %'}</th>`).join('')}</tr>${z.join('')}</table>`; }
function auZeichne(){ const d=AU.d, el=$('auplot'), tabEl=$('auplottab'); if(!d||!el||!d.prognose) return; if(typeof hideTip==='function') hideTip();
 const P=d.prognose, F=P.faecher||[], T=d.tage;
 if(AU.tabelle){ el.innerHTML=''; if(tabEl) tabEl.innerHTML=auFaecherTabelle(P); auLegende(null); return; }
 if(tabEl) tabEl.innerHTML='';
 if(!F.length){ el.innerHTML='<div class="sub auleer">Kein Fächer -- die Gründe stehen unter „Was fehlt“.</div>'; auLegende(null); return; }
 const W=Math.max(300,el.clientWidth||600), breit=W>=700, NVall=(P.niveaus||[]).map((n,i)=>Object.assign({nr:i+1},n));
 const L=6, R=breit?62:52, LC=breit&&AU.sch.niveaus&&NVall.length?(W>=1100?250:220):0, nameMax=W>=1100?24:18, T_=10, PH=breit?360:280, B=20, H=T_+PH+B, pwGes=W-L-R-LC;
 const tAnker=P.anker/86400, n=T&&T.c?T.c.length:0, t0=T?T.t0:Math.floor(tAnker)-AU.bereich;
 const ber=Math.min(AU.bereich, n||AU.bereich), a=Math.max(0,n-ber), ta=t0+a, tEnde=tAnker+28;
 // 23.68: rechts der Marke +4 W bleiben AU_RAND px frei für die Klammern (bis 23.67: 0,6 Tage -- die Klammer bei +4 W lag außerhalb)
 const xa=ta, pd=(pwGes-AU_RAND)/(tEnde-xa), X=t=>L+(t-xa)*pd, xAnker=X(tAnker), xRechts=L+pwGes, kerzen=pd>=4;
 const preis=(k,qi)=>P.p0*Math.exp(F[k-1][qi]);
 const qi_lo=AU.sch.f90?0:AU.sch.f80?1:AU.sch.f50?2:3, qi_hi=6-qi_lo;
 let lo=Infinity, hi=-Infinity; const nimm=v=>{ if(v!=null&&isFinite(v)&&v>0){ if(v<lo) lo=v; if(v>hi) hi=v; } };
 for(let i=a;i<n;i++){ nimm(T.h[i]); nimm(T.l[i]); }
 nimm(P.p0); for(let k=1;k<=28;k++){ nimm(preis(k,qi_lo)); nimm(preis(k,qi_hi)); }
 const st=AU.sch.stress&&P.stress&&P.stress.spannen?P.stress:null;
 if(st) [7,14,28].forEach(h=>{ const s=st.spannen[String(h)]; if(s){ nimm(s.q[1]); nimm(s.q[5]); } });
 const sg=AU.sch.stress&&P.stress_groesse&&P.stress_groesse.spannen?P.stress_groesse:null;          // 23.68 (U156)
 if(sg) [7,14,28].forEach(h=>{ const s=sg.spannen[String(h)]; if(s){ nimm(s.q[1]); nimm(s.q[5]); } });
 if(!isFinite(lo)){ el.innerHTML='<div class="sub auleer">Keine Werte.</div>'; return; }
 const la=Math.log(lo), lb=Math.log(hi), pad=Math.max((lb-la)*0.05,0.01), y0=la-pad, y1=lb+pad;
 const Y=v=>T_+(y1-Math.log(v))/(y1-y0)*PH, yLo=Math.exp(y0), yHi=Math.exp(y1), f1=v=>v.toFixed(1);
 let s=`<svg width="${W}" height="${H}" role="img" aria-label="Ausblick ${esc(d.coin)}: ${ber} Tage Kerzen und der Fächer der nächsten 28 Tage" style="display:block;background:${AU_F.flaeche};border:1px solid #21262d;border-radius:6px">`
  +`<defs><clipPath id="auclip"><rect x="${L}" y="${T_}" width="${f1(pwGes)}" height="${PH}"/></clipPath></defs>`;
 s+=`<rect x="${f1(xAnker)}" y="${T_}" width="${f1(xRechts-xAnker)}" height="${PH}" fill="${AU_F.zone}"/>`;
 const yt=auSchritte(yLo,yHi,breit?6:5), yf=auTickFmt(yt.st);
 yt.w.forEach(v=>{ const y=Y(v); if(y<T_+3||y>T_+PH-3) return; s+=`<line x1="${L}" x2="${W-R}" y1="${f1(y)}" y2="${f1(y)}" stroke="${AU_F.grid}"/><text x="${W-R+4}" y="${f1(y+3)}" fill="${AU_F.muted}" font-size="10">${yf(v)}</text>`; });
 // Monatsmarken in der Vergangenheit, Wochenmarken in der Zukunft
 { const d0=new Date(ta*864e5); let j=d0.getUTCFullYear(), m=d0.getUTCMonth()+1; if(m>11){ m=0; j++; } const sprung=ber>200?2:1;
  while(true){ const t=Date.UTC(j,m,1)/864e5; if(t>tAnker-10) break; const x=X(t); if(xAnker-x<76) break; if(m%sprung===0&&x>L+2) s+=`<line x1="${f1(x)}" x2="${f1(x)}" y1="${T_}" y2="${T_+PH}" stroke="${AU_F.grid}"/><text x="${f1(x+3)}" y="${H-6}" fill="${AU_F.muted}" font-size="10">${auMonat(t)}</text>`; m++; if(m>11){ m=0; j++; } } }
 { const belegt=[[xAnker-36,xAnker-1]];                                   // „Anker“ steht rechtsbündig links der Linie
  [28,14,7].forEach(k=>{ const x=X(tAnker+k), a_=x-13, b_=x+13; s+=`<line x1="${f1(x)}" x2="${f1(x)}" y1="${T_}" y2="${T_+PH}" stroke="${AU_F.ref}" stroke-dasharray="2,4"/>`;
   if(!belegt.some(([u,v])=>a_<v+3&&b_>u-3)){ belegt.push([a_,b_]); s+=`<text x="${f1(x)}" y="${H-6}" fill="${AU_F.muted}" font-size="10" text-anchor="middle">+${k/7} W</text>`; } }); }
 s+=`<line x1="${f1(xAnker)}" x2="${f1(xAnker)}" y1="${T_}" y2="${T_+PH}" stroke="${AU_F.ref}" stroke-dasharray="3,3"/><text x="${f1(xAnker-3)}" y="${H-6}" fill="${AU_F.muted}" font-size="10" text-anchor="end">Anker</text>`;
 s+=`<g clip-path="url(#auclip)">`;
 // Kerzen
 if(n){ if(kerzen){ const bw=Math.max(2,Math.min(11,pd*0.64));
   for(let i=a;i<n;i++){ const o=T.o[i], h=T.h[i], l=T.l[i], c=T.c[i]; if(o==null||c==null||h==null||l==null) continue;
    const x=X(t0+i+0.5), yo=Y(o), yc=Y(c), top=Math.min(yo,yc), bot=Math.max(yo,yc), hh=Math.max(1,bot-top), xs=f1(x);
    s+=`<line x1="${xs}" x2="${xs}" y1="${f1(Y(h))}" y2="${f1(top)}" stroke="${AU_F.kerze}"/><line x1="${xs}" x2="${xs}" y1="${f1(bot)}" y2="${f1(Y(l))}" stroke="${AU_F.kerze}"/>`;
    s+=c>=o?`<rect x="${f1(x-bw/2+0.5)}" y="${f1(top)}" width="${f1(Math.max(1,bw-1))}" height="${f1(hh)}" fill="${AU_F.flaeche}" stroke="${AU_F.kerze}"/>`
           :`<rect x="${f1(x-bw/2)}" y="${f1(top)}" width="${f1(bw)}" height="${f1(hh)}" fill="${AU_F.kerze}"/>`; } }
  else{ let pc='', an=false; for(let i=a;i<n;i++){ if(T.c[i]!=null){ pc+=(an?'L':'M')+f1(X(t0+i+0.5))+','+f1(Y(T.c[i])); an=true; } else an=false; }
   s+=`<path d="${pc}" fill="none" stroke="${AU_F.kerze}" stroke-width="1.3" stroke-linejoin="round"/>`; } }
 // Fächer: Bänder vom Anker aus (Start = p0), gestaffelt nach Deckkraft
 const band=(qa,qb,op)=>{ const ob=[[xAnker,Y(P.p0)]], un=[]; for(let k=1;k<=28;k++){ ob.push([X(tAnker+k),Y(preis(k,qb))]); un.push([X(tAnker+k),Y(preis(k,qa))]); }
  return `<path d="M${ob.map(q=>f1(q[0])+','+f1(q[1])).join('L')}L${un.reverse().map(q=>f1(q[0])+','+f1(q[1])).join('L')}Z" fill="${AU_F.faecher}" opacity="${op}"/>`; };
 if(AU.sch.f90) s+=band(0,6,0.10); if(AU.sch.f80) s+=band(1,5,0.10); if(AU.sch.f50) s+=band(2,4,0.14);
 { let pm=`M${f1(xAnker)},${f1(Y(P.p0))}`; for(let k=1;k<=28;k++) pm+=`L${f1(X(tAnker+k))},${f1(Y(preis(k,3)))}`; s+=`<path d="${pm}" fill="none" stroke="${AU_F.median}" stroke-width="1.6"/>`; }
 // Stressfächer: gestrichelte Klammern (80 %) bei +1/+2/+4 Wochen
 if(st) [7,14,28].forEach(h=>{ const sp=st.spannen[String(h)]; if(!sp) return; const x=X(tAnker+h)+6, ya=Y(sp.q[5]), yu=Y(sp.q[1]);
  s+=`<path d="M${f1(x-4)},${f1(ya)}L${f1(x)},${f1(ya)}L${f1(x)},${f1(yu)}L${f1(x-4)},${f1(yu)}" fill="none" stroke="${AU_F.stress}" stroke-width="1.4" stroke-dasharray="3,2"/>`; });
 // 23.68 (U156): Größe der Stressphase -- gepunktete Klammern (80 %) rechts neben denen des Stressfächers
 if(sg) [7,14,28].forEach(h=>{ const sp=sg.spannen[String(h)]; if(!sp) return; const x=X(tAnker+h)+12, ya=Y(sp.q[5]), yu=Y(sp.q[1]);
  s+=`<path d="M${f1(x-4)},${f1(ya)}L${f1(x)},${f1(ya)}L${f1(x)},${f1(yu)}L${f1(x-4)},${f1(yu)}" fill="none" stroke="${AU_F.stress}" stroke-width="1.4" stroke-dasharray="1,2"/>`; });
 // 80-%-Marken an +1/+2/+4 Wochen
 [7,14,28].forEach(k=>{ const x=f1(X(tAnker+k)), ya=f1(Y(preis(k,5))), yu=f1(Y(preis(k,1)));
  s+=`<line x1="${x}" x2="${x}" y1="${ya}" y2="${yu}" stroke="${AU_F.faecher}" stroke-width="1.5" opacity="0.9"/><line x1="${f1(+x-3)}" x2="${f1(+x+3)}" y1="${ya}" y2="${ya}" stroke="${AU_F.faecher}"/><line x1="${f1(+x-3)}" x2="${f1(+x+3)}" y1="${yu}" y2="${yu}" stroke="${AU_F.faecher}"/>`; });
 // Niveaus ab dem Anker
 const NV=AU.sch.niveaus?NVall:[], sicht=NV.filter(l=>l.px>=yLo&&l.px<=yHi);
 sicht.forEach(l=>{ const y=f1(Y(l.px)); s+=`<line x1="${f1(xAnker)}" x2="${f1(xRechts)}" y1="${y}" y2="${y}" stroke="${auFarbe(l)}" stroke-width="1.3"${l.momentaufnahme?' stroke-dasharray="4,3"':''} opacity="0.85"/>`; });
 // Start (Anker)
 { const yk=Y(P.p0); s+=`<line x1="${L}" x2="${f1(xRechts)}" y1="${f1(yk)}" y2="${f1(yk)}" stroke="${AU_F.kurs}" stroke-dasharray="3,3" opacity="0.45"/><circle cx="${f1(xAnker)}" cy="${f1(yk)}" r="3" fill="${AU_F.kurs}" stroke="${AU_F.flaeche}" stroke-width="1.5"/>`; }
 s+=`</g>`;
 // Beschriftung der 80-%-Marken (breit)
 if(breit) [7,14,28].forEach(k=>{ const x=X(tAnker+k), ya=Y(preis(k,5)), yu=Y(preis(k,1));
  s+=`<text x="${f1(x)}" y="${f1(Math.max(T_+10,ya-5))}" fill="${AU_F.text}" font-size="9.5" text-anchor="middle" paint-order="stroke" stroke="${AU_F.flaeche}" stroke-width="3">${auPx(preis(k,5))}</text>`
   +`<text x="${f1(x)}" y="${f1(Math.min(T_+PH-3,yu+12))}" fill="${AU_F.text}" font-size="9.5" text-anchor="middle" paint-order="stroke" stroke="${AU_F.flaeche}" stroke-width="3">${auPx(preis(k,1))}</text>`; });
 // Niveau-Beschriftung: breit in der Spalte rechts, schmal nur die Nummer
 const lab=sicht.map(l=>({l, y:Y(l.px)})).sort((p,q)=>p.y-q.y); auVerteilen(lab, T_+7, T_+PH-7, 13);
 const badge=(x,y,nr,farbe)=>`<rect x="${f1(x)}" y="${f1(y-6.5)}" width="17" height="13" rx="3" fill="${AU_F.flaeche}" stroke="${farbe}"/><text x="${f1(x+8.5)}" y="${f1(y+3.5)}" fill="${AU_F.text}" font-size="9" text-anchor="middle">${nr}</text>`;
 lab.forEach(p=>{ const l=p.l, p4=l.erreicht?'erreicht':(l.p&&l.p['28']?auPr(l.p['28'][0],0):'—');
  if(LC){ const x0=xRechts+4; s+=`<path d="M${f1(xRechts)},${f1(p.y)}L${f1(x0)},${f1(p.ly)}" stroke="${auFarbe(l)}" fill="none" opacity="0.7"/>`+badge(x0,p.ly,l.nr,auFarbe(l))
    +`<text class="aulab" data-name="${esc(String(l.name))}" data-px="${auPx(l.px)}" x="${f1(x0+21)}" y="${f1(p.ly+3.5)}" fill="${AU_F.text}" font-size="10">${esc(auKuerzen(String(l.name),nameMax))} ${auPx(l.px)} <tspan fill="${AU_F.muted}">4 W ${p4}</tspan><title>${esc(l.name)} · ${esc(l.quelle||'')}</title></text>`; }
  else{ const x0=xRechts-19; if(Math.abs(p.ly-p.y)>1) s+=`<path d="M${f1(x0-6)},${f1(p.y)}L${f1(x0)},${f1(p.ly)}" stroke="${auFarbe(l)}" fill="none" opacity="0.7"/>`; s+=badge(x0,p.ly,l.nr,auFarbe(l)); } });
 const ob_=NV.filter(l=>l.px>yHi).length, un_=NV.filter(l=>l.px<yLo).length;
 if(ob_) s+=`<text x="${f1(LC?xRechts+6:xRechts-4)}" y="${T_+10}" fill="${AU_F.muted}" font-size="9" text-anchor="${LC?'start':'end'}">▲ ${ob_} weitere darüber (Ziellevels)</text>`;
 if(un_) s+=`<text x="${f1(LC?xRechts+6:xRechts-4)}" y="${T_+PH-4}" fill="${AU_F.muted}" font-size="9" text-anchor="${LC?'start':'end'}">▼ ${un_} weitere darunter (Ziellevels)</text>`;
 { const yk=Y(P.p0); if(yk>=T_&&yk<=T_+PH) s+=`<rect x="${W-R+1}" y="${f1(yk-7)}" width="${R-3}" height="14" rx="3" fill="${AU_F.kurs}"/><text x="${W-R+4}" y="${f1(yk+3.5)}" fill="${AU_F.flaeche}" font-size="10" font-weight="600">${auPx(P.p0)}</text>`; }
 s+=`<line class="aukreuz" x1="0" x2="0" y1="${T_}" y2="${T_+PH}" stroke="#58a6ff" opacity="0"/><line class="aukreuzy" x1="${L}" x2="${f1(xRechts)}" y1="0" y2="0" stroke="#58a6ff" stroke-dasharray="3,3" opacity="0"/>`
  +`<rect class="auhit" x="${L}" y="${T_}" width="${f1(pwGes)}" height="${PH}" fill="transparent" style="cursor:crosshair;touch-action:pan-y"/></svg>`;
 el.innerHTML=s;
 // Beschriftung der Niveaus endet vor der Preisachse: gemessen, Name notfalls weiter gekürzt (Schriftbreite je Gerät verschieden)
 el.querySelectorAll('text.aulab').forEach(t=>{ const nm=t.getAttribute('data-name')||'', px=t.getAttribute('data-px')||'', x=+t.getAttribute('x');
  let k=nameMax; try{ while(k>6&&x+t.getComputedTextLength()>W-R-4){ k--; t.firstChild.nodeValue=auKuerzen(nm,k)+' '+px+' '; } }catch(e){} });
 AU.geo={X, Y, L, pd, xa, T_, PH, tAnker, t0, n, a, ta, lab, y0, y1};
 auLegende({kerzen:kerzen&&n>0, f90:AU.sch.f90, f80:AU.sch.f80, f50:AU.sch.f50, stress:!!st, sg:!!sg, niveaus:AU.sch.niveaus&&sicht.length});
 const svg=el.querySelector('svg'), hit=el.querySelector('.auhit'), kr=el.querySelector('.aukreuz'), kry=el.querySelector('.aukreuzy');
 const zeige=ev=>{ const r=svg.getBoundingClientRect(), px=ev.clientX-r.left, py=ev.clientY-r.top, g=AU.geo;
  const t=g.xa+(px-g.L)/g.pd; kry.setAttribute('y1',f1(py)); kry.setAttribute('y2',f1(py)); kry.setAttribute('opacity','0.5');
  const Z=[]; let titel;
  if(t<g.tAnker){ const tag=Math.floor(t), i=tag-g.t0; if(!n||i<g.a||i>=n){ kr.setAttribute('opacity','0'); hideTip(); return; }
   const x=f1(g.X(tag+0.5)); kr.setAttribute('x1',x); kr.setAttribute('x2',x); kr.setAttribute('opacity','0.7');
   titel=`${auTagDatum(tag)} (Tageskerze)`; Z.push(['Eröffnung',auPx(T.o[i])],['Hoch',auPx(T.h[i])],['Tief',auPx(T.l[i])],['Schluss',auPx(T.c[i])]); }
  else{ const k=Math.max(1,Math.min(28,Math.round(t-g.tAnker))); const x=f1(g.X(g.tAnker+k)); kr.setAttribute('x1',x); kr.setAttribute('x2',x); kr.setAttribute('opacity','0.7');
   titel=`+${k} ${k===1?'Tag':'Tage'} nach dem Anker (${auZeit(P.anker+k*86400)})`;
   [[6,'95 %'],[5,'90 %'],[4,'75 %'],[3,'Median'],[2,'25 %'],[1,'10 %'],[0,'5 %']].forEach(([qi,nm])=>Z.push([nm, `${auPx(preis(k,qi))} <span style="color:#8b949e">(${auPct(Math.expm1(F[k-1][qi]),1)})</span>`])); }
  const v=Math.exp(g.y1-(py-g.T_)/g.PH*(g.y1-g.y0)); Z.push(['Zeiger', auPx(v)+` <span style="color:#8b949e">(${auPct(v/P.p0-1,1)} zum Start)</span>`]);
  g.lab.filter(p=>Math.abs(p.y-py)<7).slice(0,2).forEach(p=>{ const l=p.l, q=l.p||{};
   Z.push([auNr(l.nr,auFarbe(l))+' ', esc(l.name)+' '+auPx(l.px)+(l.erreicht?' · seit dem Anker erreicht':` · erreicht in 1/2/4 W ${['7','14','28'].map(h=>q[h]?auPr(q[h][0],0):'—').join(' / ')}`)]); });
  auTip(ev, titel, Z); };
 hit.addEventListener('pointermove', zeige); hit.addEventListener('pointerdown', zeige);
 hit.addEventListener('pointerleave', ()=>{ kr.setAttribute('opacity','0'); kry.setAttribute('opacity','0'); hideTip(); }); }
function auTip(ev, titel, zeilen){ const t=$('tip'); if(!t) return;
 t.innerHTML=`<div class="t">${titel}</div>`+zeilen.map(z=>`<div class="r"><i>${z[0]}</i><b style="color:#e6edf3">${z[1]}</b></div>`).join('');
 t.style.display='block'; const w=t.offsetWidth, h=t.offsetHeight; let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14; if(y<8) y=ev.clientY+18; x=Math.max(6,Math.min(x,innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; } t.style.left=x+'px'; t.style.top=y+'px'; }

// ---------- Start ----------
function auCss(){ if($('aucss')) return; const st=document.createElement('style'); st.id='aucss';
 st.textContent=`#sec-ausblick .auzeile,#sec-ausblick .aureiter,#sec-ausblick .auszenkopf{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0 8px}
 #sec-ausblick button.tog{min-width:0;padding:4px 9px}
 #sec-ausblick .lbl{font-size:10px;color:#8b949e;text-transform:uppercase;letter-spacing:.4px;margin-right:2px}
 #sec-ausblick .auab{margin-left:10px} #sec-ausblick .autabbtn{margin-left:auto}
 #sec-ausblick .aukopf{font-size:11px;color:#8b949e;margin:6px 0 4px;line-height:1.5} #sec-ausblick .aukopf b{color:#e6edf3}
 #sec-ausblick .auausnahme{margin:6px 0;padding:6px 10px;border:1px solid #d29922;border-radius:6px;color:#e3b341;font-size:12px}
 #sec-ausblick .aulesart{margin:6px 0 10px;padding:8px 12px 8px 26px;background:#0d1117;border:1px solid #21262d;border-radius:6px}
 #sec-ausblick .aulesart li{font-size:12.5px;color:#c9d1d9;line-height:1.55;margin:3px 0}
 #sec-ausblick .aulesart li.schluss{list-style:none;margin-left:-14px;color:#8b949e;font-size:11px;margin-top:6px}
 #sec-ausblick .auleg{margin:4px 0 6px} #sec-ausblick .auleg span{display:inline-flex;align-items:center;gap:4px}
 #sec-ausblick .auplot{width:100%} #sec-ausblick .aunote{margin:5px 0 4px}
 #sec-ausblick .auszen{margin:10px 0 4px;padding:8px 10px;border:1px solid #21262d;border-radius:6px;background:#0d1117}
 #sec-ausblick .aureiter{margin-top:14px;border-top:1px solid #21262d;padding-top:10px}
 #sec-ausblick .auscroll{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #sec-ausblick .autabelle{max-height:440px;overflow-y:auto}
 #sec-ausblick h3.auh3{font-size:12px;color:#e6edf3;margin:16px 0 4px;font-weight:600}
 #sec-ausblick table.w td{vertical-align:top}
 #sec-ausblick .lz{display:block;font-size:10px;color:#8b949e;white-space:normal;max-width:300px;line-height:1.35;margin-top:1px}
 #sec-ausblick .lzi{font-size:10px;color:#8b949e}
 #sec-ausblick .aunr,#tip .aunr{display:inline-block;min-width:13px;padding:0 3px;border:1px solid;border-radius:4px;font-size:10px;line-height:14px;text-align:center;color:#c9d1d9;background:#01030a;font-style:normal}
 #sec-ausblick .austat{display:inline-block;padding:0 5px;border:1px solid;border-radius:9px;font-size:10px;line-height:15px;white-space:nowrap}
 #sec-ausblick tr.aujetzt td{background:#161b22;color:#e6edf3;font-weight:600}
 #sec-ausblick .auleer{padding:18px 8px;border:1px dashed #21262d;border-radius:6px}
 #sec-ausblick .audetails{margin:12px 0 4px} #sec-ausblick .audetails summary{cursor:pointer;color:#c9d1d9;font-size:12px}
 #sec-ausblick .aufehlt li{font-size:11px;color:#8b949e;line-height:1.5;margin:2px 0}
 #sec-ausblick .aufuss{font-size:10px;color:#6e7681;margin-top:12px}
 @media (max-width:700px){ #sec-ausblick .aulesart{padding:8px 10px 8px 22px} #sec-ausblick .aulesart li{font-size:12px}
  #sec-ausblick button.tog{padding:6px 10px} #sec-ausblick .auab{margin-left:0} #sec-ausblick .autabbtn{margin-left:0} }`;
 document.head.appendChild(st); }
function auStart(){ if(!$('sec-ausblick')) return; auCss(); auLeiste();
 let n_=0; const warte=()=>{ const c=$('coin'); if((c&&c.options.length)||++n_>40) auLaden(false); else setTimeout(warte,300); }; warte();
 const c=$('coin'); if(c) c.addEventListener('change',()=>{ AU.szen=null; if(auOffen()) auLaden(false); });
 setInterval(()=>{ if(auOffen()) auLaden(false); }, 120000);
 document.addEventListener('visibilitychange',()=>{ if(auOffen()) auLaden(false); });
 let rz=null; addEventListener('resize',()=>{ clearTimeout(rz); rz=setTimeout(()=>{ if(auOffen()&&AU.d) auZeichne(); },250); }); }
auStart();
"""
