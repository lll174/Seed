#!/usr/bin/env python3
"""
install.py — Einrichtung des Hyperliquid-Recorders auf Raspberry Pi 5 / Debian Trixie.

Legt eine virtuelle Umgebung an, installiert die Abhängigkeiten, prüft die
Umgebung und fährt anschließend einen echten Selbsttest über alle Skripte.

    python3 install.py                 # komplette Einrichtung
    python3 install.py --check         # nur prüfen, nichts verändern
    python3 install.py --selftest      # nur die Skripte testen
    python3 install.py --systemd       # zusätzlich Dienste einrichten

Warum ein venv: Debian Trixie markiert die System-Python-Installation als
"externally managed" (PEP 668). Ein direktes pip install schlägt fehl, und
--break-system-packages kann apt-Pakete beschädigen. Das venv umgeht beides.
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
PROJECT_FILES = ["hl_recorder.py", "hl_viz.py", "hl_backtest.py",
                 "hl_binance.py", "hl_timestats.py", "hl_watchdog.py", "run_all.py",
                 "requirements.txt"]

APT_PACKAGES = [
    "python3-venv",      # auf Trixie nicht immer vorinstalliert
    "python3-dev",
    "build-essential",   # nur Fallback, falls ein Wheel fehlt
    "libopenblas-dev",   # numpy-Performance auf ARM
    "pkg-config",
    "libfreetype6-dev",  # matplotlib-Fallback
    "libpng-dev",
]

OK, WARN, FAIL = "  [ok]  ", "  [!]   ", "  [FEHLER] "


def hr(title: str) -> None:
    print(f"\n{title}\n" + "-" * 62)


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def venv_python() -> Path:
    """Interpreter des venv, sonst der aktuelle (für --selftest ohne venv)."""
    p = VENV / "bin" / "python"
    return p if p.exists() else Path(sys.executable)


# ---------------------------------------------------------------------------
# 1. Umgebung prüfen
# ---------------------------------------------------------------------------

def check_environment() -> list[str]:
    hr("1. Umgebung")
    problems: list[str] = []

    v = sys.version_info
    if v >= (3, 11):
        print(f"{OK}Python {v.major}.{v.minor}.{v.micro}")
    else:
        print(f"{FAIL}Python {v.major}.{v.minor} — mindestens 3.11 nötig")
        problems.append("Python zu alt")

    arch = platform.machine()
    print(f"{OK}Architektur {arch}"
          if arch in ("aarch64", "arm64", "x86_64")
          else f"{WARN}Architektur {arch} — ungetestet")
    if arch in ("armv7l", "armv6l"):
        print(f"{WARN}32-Bit-System. Für den Pi 5 das 64-Bit-OS verwenden, "
              "sonst fehlen Wheels und alles wird kompiliert.")

    osr = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line:
                k, _, val = line.partition("=")
                osr[k] = val.strip('"')
    except OSError:
        pass
    name = osr.get("PRETTY_NAME", "unbekannt")
    if osr.get("VERSION_CODENAME") == "trixie":
        print(f"{OK}{name}")
    else:
        print(f"{WARN}{name} — Skript ist auf Trixie ausgelegt, "
              "läuft aber auf jedem Debian/Ubuntu mit Python ≥ 3.11")

    # Pi-Modell
    try:
        model = Path("/proc/device-tree/model").read_text().strip("\x00").strip()
        print(f"{OK}{model}")
    except OSError:
        print(f"{WARN}Kein Raspberry Pi erkannt (kein Problem)")

    # RAM
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal"):
                gb = int(line.split()[1]) / 1_048_576
                print(f"{OK}RAM {gb:.1f} GB" if gb >= 1.8
                      else f"{WARN}RAM {gb:.1f} GB — knapp, aber machbar")
                break
    except OSError:
        pass

    # Plattenplatz
    free = shutil.disk_usage(ROOT).free / 1e9
    if free >= 5:
        print(f"{OK}Freier Speicher {free:.1f} GB")
    else:
        print(f"{WARN}Nur {free:.1f} GB frei — die Datenbank wächst um "
              "rund 0,4 GB pro Monat bei drei Coins")

    # Schreibmedium: SD-Karte verschleißt bei Dauerschreiben
    try:
        src = run(["findmnt", "-no", "SOURCE", "--target", str(ROOT)]).stdout.strip()
        if "mmcblk" in src:
            print(f"{WARN}Projekt liegt auf der SD-Karte ({src}).")
            print("        Der Recorder schreibt dauerhaft. Für Monatsbetrieb "
                  "besser eine USB-SSD nehmen und --db dorthin legen.")
        elif src:
            print(f"{OK}Schreibmedium {src}")
    except (OSError, FileNotFoundError):
        pass

    # Zeitsynchronisation — Timestamps sind die halbe Datenqualität
    r = run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    if r.returncode == 0:
        if r.stdout.strip() == "yes":
            print(f"{OK}Systemzeit per NTP synchronisiert")
        else:
            print(f"{WARN}Zeit NICHT synchronisiert. Ohne korrekte Uhr sind die "
                  "aufgezeichneten Zeitstempel unbrauchbar.")
            print("        Beheben mit: sudo timedatectl set-ntp true")
            problems.append("Zeit nicht synchron")

    # PEP 668
    stdlib = Path(sysconfig.get_paths()["stdlib"])
    if (stdlib / "EXTERNALLY-MANAGED").exists():
        print(f"{OK}PEP-668-System erkannt — venv wird verwendet")

    # Projektdateien
    missing = [f for f in PROJECT_FILES if not (ROOT / f).exists()]
    if missing:
        print(f"{FAIL}Fehlende Dateien: {', '.join(missing)}")
        problems.append("Projektdateien fehlen")
    else:
        print(f"{OK}Alle {len(PROJECT_FILES)} Projektdateien vorhanden")

    return problems


# ---------------------------------------------------------------------------
# 2. Systempakete
# ---------------------------------------------------------------------------

def install_apt(skip: bool) -> None:
    hr("2. Systempakete")
    if skip:
        print("        übersprungen (--no-apt)")
        return
    if not shutil.which("apt-get"):
        print(f"{WARN}kein apt — Schritt übersprungen")
        return

    missing = [p for p in APT_PACKAGES
               if run(["dpkg-query", "-W", "-f=${Status}", p]).stdout != "install ok installed"]
    if not missing:
        print(f"{OK}Alle Systempakete vorhanden")
        return

    print(f"        Nachzuinstallieren: {' '.join(missing)}")
    sudo = [] if os.geteuid() == 0 else ["sudo"]
    if sudo and not shutil.which("sudo"):
        print(f"{WARN}kein sudo. Bitte manuell: apt install {' '.join(missing)}")
        return
    print("        (Passwortabfrage möglich)")
    r = subprocess.run(sudo + ["apt-get", "install", "-y"] + missing)
    print(f"{OK}Systempakete installiert" if r.returncode == 0
          else f"{WARN}apt meldete einen Fehler — Installation läuft evtl. trotzdem")


# ---------------------------------------------------------------------------
# 3. venv + Python-Pakete
# ---------------------------------------------------------------------------

def install_python() -> bool:
    hr("3. Virtuelle Umgebung und Pakete")

    if not VENV.exists():
        print(f"        Erstelle {VENV} …")
        r = run([sys.executable, "-m", "venv", str(VENV)])
        if r.returncode != 0:
            print(f"{FAIL}venv fehlgeschlagen:\n{r.stderr}")
            print("        Abhilfe: sudo apt install python3-venv")
            return False
    print(f"{OK}venv unter {VENV}")

    py = str(VENV / "bin" / "python")
    run([py, "-m", "pip", "install", "--upgrade", "pip", "wheel", "--quiet"])

    print("        Installiere Abhängigkeiten (auf dem Pi ein paar Minuten) …")
    t0 = time.time()
    r = subprocess.run([py, "-m", "pip", "install", "-r",
                        str(ROOT / "requirements.txt")])
    if r.returncode != 0:
        print(f"{FAIL}pip fehlgeschlagen. Häufigste Ursache: fehlendes Wheel für "
              "diese Architektur. Dann build-essential und python3-dev nachinstallieren.")
        return False
    print(f"{OK}Pakete installiert ({time.time()-t0:.0f}s)")

    # Versionen ausgeben
    code = (
        "import numpy,pandas,matplotlib,websockets,aiohttp,sqlite3,sys;"
        "print('python  ',sys.version.split()[0]);"
        "print('numpy   ',numpy.__version__);"
        "print('pandas  ',pandas.__version__);"
        "print('mpl     ',matplotlib.__version__);"
        "print('websockets',websockets.__version__);"
        "print('aiohttp ',aiohttp.__version__);"
        "print('sqlite  ',sqlite3.sqlite_version)"
    )
    r = run([py, "-c", code])
    if r.returncode != 0:
        print(f"{FAIL}Importtest fehlgeschlagen:\n{r.stderr}")
        return False
    for line in r.stdout.strip().splitlines():
        print(f"{OK}{line}")
    return True


# ---------------------------------------------------------------------------
# 4. Selbsttest
# ---------------------------------------------------------------------------

def selftest_isoliert() -> bool:
    """
    U30 (23.29): Selbsttest aus der Debug-Konsole auf dem Pi -- mit dessen Python und Bibliotheken, aber in einer KOPIE
    des Projektordners und mit eigenem Prognosespeicher (HL_FORECAST_DB). Ohne diese Trennung würde die Test-Instanz des
    Dashboards über die systemd-Einheit den echten Prognosespeicher finden und synthetische Prognosen hineinschreiben;
    labels_cache.json und sys_history.json im Projektordner wären ebenfalls betroffen.
    """
    import shutil, tempfile
    tmp = tempfile.mkdtemp(prefix="hl_selbsttest_")
    try:
        ziel = Path(tmp) / "projekt"
        shutil.copytree(ROOT, ziel, ignore=shutil.ignore_patterns("*.db", "*.db-wal", "*.db-shm", "*.db.*", "berichte", "__pycache__", "*.log",
                                                                   "labels_cache.json", "sys_history.json", "speicherorte.json", "venv", ".venv",
                                                                   "dbbackup", "*.zip", "backup*", "_selftest*"))
        env = dict(os.environ, HL_FORECAST_DB=str(Path(tmp) / "forecasts_selbsttest.db"))
        env.pop("HL_DB", None)
        for k in ("HL_LOGDIR", "NOTIFY_SOCKET", "WATCHDOG_PID", "WATCHDOG_USEC"):   # 23.78: geerbt vom Dashboard -- die Test-Instanz
            env.pop(k, None)                                                         # schreibt nicht in die echten Logs, meldet nichts
        print(f"Selbsttest in einer Kopie ({ziel}), eigener Prognosespeicher -- echte Daten bleiben unberührt", flush=True)
        r = subprocess.run([str(venv_python()), str(ziel / "install.py"), "--selftest"], cwd=str(ziel), env=env)
        return r.returncode == 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def selftest() -> bool:
    hr("4. Selbsttest")
    py = str(venv_python())
    db = ROOT / "_selftest.db"
    png = ROOT / "_selftest.png"
    for f in (db, png):
        f.unlink(missing_ok=True)

    steps = [
        ("Syntax aller Skripte",
         [py, "-m", "compileall", "-q",
          str(ROOT / "hl_recorder.py"), str(ROOT / "hl_viz.py"),
          str(ROOT / "hl_backtest.py"), str(ROOT / "hl_binance.py"),
          str(ROOT / "hl_timestats.py"), str(ROOT / "hl_watchdog.py"),
          str(ROOT / "hl_forecast.py"), str(ROOT / "hl_coinbase.py"), str(ROOT / "hl_score.py"), str(ROOT / "hl_ext.py"), str(ROOT / "hl_dbcoord.py"), str(ROOT / "hl_indikatoren.py"), str(ROOT / "version.py"), str(ROOT / "hl_profis.py"), str(ROOT / "hl_kalib.py"), str(ROOT / "hl_konstellation.py"), str(ROOT / "hl_familien.py"), str(ROOT / "hl_anker.py"), str(ROOT / "hl_labor.py"), str(ROOT / "hl_adressfluss.py"), str(ROOT / "hl_fusion.py"), str(ROOT / "hl_kaskade.py"), str(ROOT / "hl_magnet.py"), str(ROOT / "hl_makro.py"), str(ROOT / "hl_makro_js.py"), str(ROOT / "hl_makro_signal.py"), str(ROOT / "hl_makro_korr.py"), str(ROOT / "hl_regime.py"), str(ROOT / "hl_swing.py"), str(ROOT / "hl_zyklus.py"), str(ROOT / "hl_hebel.py"), str(ROOT / "hl_chartbild.py"), str(ROOT / "hl_chartbild_js.py"), str(ROOT / "hl_aktien.py"), str(ROOT / "hl_ausblick.py"), str(ROOT / "hl_ausblick_js.py"), str(ROOT / "hl_datentage.py"),
          str(ROOT / "hl_notbremse.py"), str(ROOT / "check_notbremse.py"), str(ROOT / "check_system.py"), str(ROOT / "hl_volumen.py"),
          str(ROOT / "hl_wende.py"), str(ROOT / "hl_prognosemarkt.py"), str(ROOT / "hl_prognosemarkt_js.py"),
          str(ROOT / "hl_volatil.py"), str(ROOT / "hl_volatil_js.py"), str(ROOT / "hl_engine.py"), str(ROOT / "hl_engine_js.py"),
          str(ROOT / "hl_cockpit.py"), str(ROOT / "hl_cockpit_js.py"), str(ROOT / "hl_staking.py"), str(ROOT / "hl_staking_studie.py"),
          str(ROOT / "hl_niveaus.py"), str(ROOT / "hl_berichte.py"), str(ROOT / "hl_optionen.py"), str(ROOT / "hl_langfrist.py"),
          str(ROOT / "hl_rtakt.py"), str(ROOT / "hl_marktschicht.py"), str(ROOT / "hl_radar.py"), str(ROOT / "hl_radar_js.py"), str(ROOT / "hl_radar_regeln.py"),
          str(ROOT / "run_all.py")]),
        # Nulltest: die gesamte Statistikstrecke auf reinem Rauschen. Das Soll kommt aus der
        # Mathematik (Quote 50 %, Magnet-Lift 1, Gewichte beim Prior), nicht aus dem heutigen
        # Ergebnis -- ein Test, der keinen Fehler festschreiben kann.
        ("Nulltest der Statistik",
         [py, str(ROOT / "hl_forecast.py"), "--nulltest"]),
        # Konto-Score: drei synthetische Konten mit echtem Vorlauf müssen die Elite stellen
        ("Konto-Score (hl_score)",
         [py, str(ROOT / "hl_score.py")]),
        # Fremdbörsen-Sammler: Parser und Seitenlogik gegen dokumentierte Beispielnachrichten
        ("Fremdbörsen-Reihen (hl_ext)",
         [py, str(ROOT / "hl_ext.py")]),
        # Schreibkoordination: vier Prozesse gleichzeitig, mit Koordination kein "database is locked"
        ("Schreibkoordination (hl_dbcoord)",
         [py, str(ROOT / "hl_dbcoord.py")]),
        # Alle Treiber mit Soll-Szenarien: Vorzeichen, Skalierung, Sättigung, Sperren
        ("Treiber-Funktionstest (check_treiber)",
         [py, str(ROOT / "check_treiber.py")]),
        ("Aktive Profis: Nulltest, Glückstest, Darwin-Regeln v3 (hl_profis)",
         [py, str(ROOT / "hl_profis.py"), "--nulltest"]),
        ("Kalibrierung v2: Positivkontrolle als Tor (hl_kalib)",
         [py, str(ROOT / "hl_kalib.py"), "--nulltest"]),
        # 23.86 (U230): direkte Bilanz v1/v2 im Bericht „Kalibrierung v2: Stand“ -- dieselbe Rechnung wie die Kachel, Zahl der U7b-Regel
        ("Kalibrierung v2: direkte Bilanz v1/v2 im Bericht wie die Kachel, Zahl der U7b-Regel (hl_kalib, U230)",
         [py, str(ROOT / "hl_kalib.py"), "--selbsttest-bilanz"]),
        # 23.42 (KONZEPT_Fusion.md): v3 über Coins geteilt mit eigenem Tor (Positivkontrolle, Rauschen, Gleichlauf, Teilen, Abweichung je Coin),
        # Mischung der Experten (Grenze ln M auch feindlich und mit Schläfern, Regimewechsel, prequential), Kostenschwelle gegen die Theorie
        ("Fusion, v3, Kostenschwelle: Tor, Grenze ln M, Teilen über Coins, Münzwurf-Vergleich, Kriterium 5 mit Abstand (hl_fusion)",
         [py, str(ROOT / "hl_fusion.py"), "--nulltest"]),
        # 23.43 (KONZEPT_Fusion.md, Stufe 2b): Kaskaden-Gleichung -- geschlossene Form gegen den Fixpunkt, Positivkontrolle (Y wird
        # gefunden), Nulltest, Störfaktor (nur der Seitenspiegel trennt ihn von echten Kaskaden), Live-Stand und Treiber
        ("Kaskaden-Gleichung: Positivkontrolle, Placebo, Seitenspiegel (hl_kaskade)",
         [py, str(ROOT / "hl_kaskade.py"), "--nulltest"]),
        ("Magnet-Test: Positivkontrolle Anziehung, Nulltest, Fallen für Spiegel, Placebo und Seitenausgleich (hl_magnet)",
         [py, str(ROOT / "hl_magnet.py"), "--nulltest"]),
        # 23.47 (U121): Makro-Chart -- je Treiber Positivkontrolle und Nulltest, Kausalität aller Rangreihen, Parser gegen die
        # Antwortformate der Quellen, Zeitplan mit Budget (BGeometrics) und Archiv (Binance), Nutzlast je Tab; ohne Netz
        ("Makro-Chart: Positivkontrollen, Nulltests, Kausalität, Parser, Zeitplan (hl_makro)",
         [py, str(ROOT / "hl_makro.py"), "--selbsttest"]),
        # 23.49 (U126): Makro-Signale -- rollierende Perzentile kausal (gegen Brute Force), Rückblick-Wendepunkte,
        # Bilanz mit Episoden und lokalem Placebo (Positivkontrolle und Nulltest auf Zufallspfaden), Prognose
        # mit empirischem Band (Positivkontrolle AR(1), Nulltest Random Walk), Referenz-Fortschreibung; ohne Netz
        ("Makro-Signale: Positivkontrollen, Nulltests, Kausalität, Rückblick, Prognose (hl_makro_signal)",
         [py, str(ROOT / "hl_makro_signal.py"), "--selbsttest"]),
        # 23.52 (U130): Makro × Kurs -- Phasen-Null auf Zufallswegen kalibriert (Nulltest), Positivkontrolle, Ära, Hälften, Nachrechnung
        ("Makro × Kurs, Teil A und B (U130) und SSR-Nachrechnung (U229): Phasen-Null, Placebo, Nulltests, Positivkontrollen, Falle (hl_makro_korr)",
         [py, str(ROOT / "hl_makro_korr.py"), "--selbsttest"]),
        # 23.59 (U138): Regime-Modul Phase 0 -- Bausteine, Laden ohne Netz, Kausalität, Nulltests und Positivkontrollen P0.1–P0.9;
        # 23.60: K3 je Stunde verglichen (driftneutral) -- Drift-Null mit genauer Gleichheit und Positivkontrolle K3
        ("Regime Phase 0: Nulltests, Positivkontrollen, Kausalität (hl_regime)",
         [py, str(ROOT / "hl_regime.py"), "--selbsttest"]),
        # 23.61 (U140): Swing-Trades -- Tageskerzen und Kennzahlen gegen Brute Force, Ausführung von Hand, Kausalität und Labor-Ausschnitt,
        # Laden ohne Netz, Nulltest, Positivkontrollen S1–S4 (ohne Netz)
        ("Swing: Nulltest, Positivkontrollen, Kausalität, Ausführung (hl_swing)",
         [py, str(ROOT / "hl_swing.py"), "--selbsttest"]),
        # 23.62 (U141): Zyklus-Studie -- Directional Change, RSI, Dip-Regeln gleich dem Labor (hl_swing), Kausalität, Nulltests und
        # Positivkontrollen der vorab festgelegten Urteile (ohne Netz)
        ("Zyklen: Nulltests, Positivkontrollen, Dip-Regeln gleich dem Labor (hl_zyklus)",
         [py, str(ROOT / "hl_zyklus.py"), "--selbsttest"]),
        # 23.63 (U142): Hebel-Studie -- Parser des Binance-Archivs, Laden und Sicherung ohne Netz, Tafel kausal, Ereignisse von Hand,
        # Verschiebungen, Urteile, Abgleich Archiv gegen Live, Nulltest und Positivkontrollen H1–H4 (ohne Netz)
        ("Hebel: Nulltest, Positivkontrollen H1–H4, Laden ohne Netz, Kausalität; seit 23.68 CryptoQuant-Abruf und S5 ohne Netz (hl_hebel)",
         [py, str(ROOT / "hl_hebel.py"), "--selbsttest"]),
        # 23.65 (U143 Stufe 1): Chartbild -- Bausteine von Hand, Niveaus, gleich der Studien (Bein wie U141, Band wie P0.2), Kausalität,
        # Band-Kontrolle auf acht synthetischen Märkten, Lesart ohne Empfehlungswörter, Frische, Ende zu Ende über hl_viz (ohne Netz)
        ("Chartbild: Bausteine, gleich der Studien, Kausalität, Band-Kontrolle (hl_chartbild)",
         [py, str(ROOT / "hl_chartbild.py"), "--selbsttest"]),
        ("Aktien-Archiv: Kalender, Parser, Archiv mit Fassungen, Schutzschalter, U147, K1/K2; seit 23.69 Strategy-Tabelle, Plausibilität, "
         "Neulesen (hl_aktien)",
         [py, str(ROOT / "hl_aktien.py"), "--selbsttest"]),
        # 23.105 (U245 Stufe C2): Verteilung des laufenden Hochs und Tiefs für den Kurs-Rechner des Cockpits -- Erreichen aus den
        # abgelegten Quantilen gleich erreichen() (Gruppe „pfad“), Ablage je Coin in au_meta „lauf“ statt in au_prognose (Gruppe „e2e“)
        ("Ausblick 4 Wochen: Pfadstatistik, Größe der Stressphase (23.68), Breite, Null, Positivkontrolle, Kausalität, Ende zu Ende; "
         "seit 23.69 Fenster der Stressphase, Regel (c) und ihre Zählung (hl_ausblick, einige Minuten)",
         [py, str(ROOT / "hl_ausblick.py"), "--selbsttest"]),
        ("Datentage: Fenster von Hand, Vergleichstage, Null, Positivkontrolle, Nullprobe, Ende zu Ende (hl_datentage)",
         [py, str(ROOT / "hl_datentage.py"), "--selbsttest"]),
        # 23.81 (U221, KONZEPT_Volumen.md 10): Volumen-Studie -- RV und TS von Hand (Tagesart in der Mitte des Fensters), Kausalität,
        # Gültigkeit (BTC-Lücke, fragliche Minute, Mindestzahl Trades), Seitenprüfung, t0 bei Limit, Drittel je Schicht, Holm/BH, Null mit
        # Abstand vom Median, Verschiebung der fertigen Reihen, Positiv-/Negativkontrollen, Störgrößen, Pool fest, Teil B über hl_swing,
        # Urteil erst am 08.11., Markteffekt, Ende zu Ende auf erfundenen Datenbanken
        ("Volumen-Studie: Rechnung von Hand, Kausalität, Null, Störgrößen, Kontrollen, Teil B, Ende zu Ende (hl_volumen, rund 1 min)",
         [py, str(ROOT / "hl_volumen.py"), "--selbsttest"]),
        # 23.83 (U226, KONZEPT_Wende.md 6): Extrem-Wende nach Video -- Kerzen, EMA/Flips, Lesarten, Signal und Handel von Hand, Kausalität,
        # erste Passage gegen eine Schleife, Statistik, Nachrechnen der Video-Trades, Labor-Daten, Ende zu Ende, Nulltest, Positivkontrolle
        ("Extrem-Wende: Signal und Handel von Hand, Kausalität, Nulltest, Positivkontrolle, Nachrechnen, Labor-Daten, Ende zu Ende "
         "(hl_wende, rund 1 min)",
         [py, str(ROOT / "hl_wende.py"), "--selbsttest"]),
        # 23.88 (U235, KONZEPT_Prognosemaerkte.md mit Nachtrag 13.1): Prognosemärkte -- Zeitachsen (ET, Sommerzeit), Parser je Quelle,
        # Kausalität (Wert erst nach Periodenende), Block-Bootstrap mit Positivkontrolle und Nullprobe, gewichteter Holm, Abruf-Pausen,
        # Rückblick mit Cursor und Ausnahmen, Ende zu Ende gegen ein Ersatz-Netz, Nutzlast ohne Ergebnisgrößen vor dem Urteil (R4)
        ("Prognosemärkte: Zeitachsen, Parser, Kausalität, Bootstrap, Holm, Pausen, Rückblick, Ende zu Ende, R4 (hl_prognosemarkt, rund 1 min)",
         [py, str(ROOT / "hl_prognosemarkt.py"), "--selbsttest"]),
        # 23.90 (U237, KONZEPT_Volatilitaet.md mit Nachtrag 13): Volatilität -- Tages-RV gleich hl_swing, Index und Schwelle von Hand,
        # HAR und σ außerhalb von Hand, Kausalität (Tage, DVOL-Stunden, Termine), Kalenderfaktoren, Bootstrap, Holm, Schnitt-Test V1,
        # Ende zu Ende mit Tor vor dem Urteil (schnelle Fassung; die Größenmessung läuft im Debug-Lauf 136)
        ("Volatilität: Tages-RV, Index, Schwelle, HAR, σ, Kausalität, Kalender, Bootstrap, Holm, Ende zu Ende (hl_volatil, rund 30 s)",
         [py, str(ROOT / "hl_volatil.py"), "--selbsttest", "--schnell"]),
        # 23.93 (U241, KONZEPT_TradingEngine.md Fassung 3): Trading Engine -- Rechnung von Hand (Tagessumme, vollständige Tage, Wochen,
        # t, Siegmund, Überwachung in Handelszeit, Bezug, Monatsart, Ausfall), Regeln (A)/(B), Abkühlung, „gescheitert“, Rückkehr, Konto
        # (Kapazität, Coin, Richtung, Bremse, Limit-Order), Kausalität, Ende zu Ende über Dateien, Nullprobe und Positivkontrollen
        ("Trading Engine: Rechnung von Hand, Regeln, Konto, Bremse und ihr Lösen, Kausalität, Ende zu Ende, Nullprobe, Positivkontrollen (hl_engine, rund 15 s)",
         [py, str(ROOT / "hl_engine.py"), "--selbsttest", "--schnell"]),
        # 23.68 (U168): Vollbericht -- jede Tabelle eine Vollzählung (Spur), Teilausgabe nach Abbruch, gleiche Zahlen wie die
        # Nachrechnung, Zeitbudget mit der Heatmap zuletzt, Kontrolle im Rückblick (auch Millisekunden), Kopfzusatz im Berichtsplan
        ("Vollbericht: eine Zählung je Tabelle, Teilausgabe, Zeitbudget, Kontrolle (check_report)",
         [py, str(ROOT / "check_report.py"), "--selbsttest"]),
        # 23.68 (U159): Abdeckung der Heatmap im Verlauf -- Nachrechnung aus coverage, Neustart zur richtigen Zeit, Tag 1 gegen danach
        ("Abdeckung der Heatmap im Verlauf: Nachrechnung, Neustart, Tag 1 gegen danach (check_abdeckung)",
         [py, str(ROOT / "check_abdeckung.py"), "--selbsttest"]),
        ("Konstellationen/Vorbedingungen: Nulltest und Probe der Ereigniserkennung U131 (hl_konstellation)",
         [py, str(ROOT / "hl_konstellation.py"), "--nulltest"]),
        ("Treiberfamilien: Positivkontrollen, Rauschen, Hygiene, Stufen (hl_familien)",
         [py, str(ROOT / "hl_familien.py"), "--nulltest"]),
        ("Heatmap-Anker: Magnet belegt, Rauschen und Trendfalle nicht (hl_anker)",
         [py, str(ROOT / "hl_anker.py"), "--nulltest"]),
        # 23.33: TradeLabor auf synthetischem Markt -- Ausführung, Gebühren, Positiv-/Negativkontrolle, Kaskade, Darwin, Docht, Neustart;
        # 23.40: Grid Long/Short (Range, Kapitaldeckel, Rallye halten, Crash-Notausstieg, Trendfilter, Neustart im Halten, Sicherungspunkt)
        # 23.69 (U180): Akkumulation (Regel von Hand, Bilanz, Vergleich, Rückblick = Live, Zufallswege, Ende zu Ende im Labor);
        # 23.70 (U184): Startkauf, Rückrechnung ab dem Start des Coins im Labor (von Hand, = Live, Neustart), 5.000 USD
        # 23.72 (U186): Korrekturkauf A4 (von Hand, Referenz, = Live, eigene Spur, Coin über der Sperre, späte Tageskerzen)
        # 23.74 (U189): Faktor gegenüber BTC (von Hand, aus swing.db ohne Zukunft, Gleichwertigkeit, fest, Beträge, Schwellen-Tabelle)
        ("TradeLabor: Ausführung, Kontrollen, Kaskade, Darwin, Elite, Grid, Akkumulation mit Startkauf, Rückrechnung, Korrekturkauf und Faktor gegenüber BTC (hl_labor)",
         [py, str(ROOT / "hl_labor.py"), "--selbsttest"]),
        # 23.76 (U206, KONZEPT_Notbremse.md 10): Notbremse -- Proben 1–11 und 14–17 (Gleichlauf-Schock, Abverkauf, Einzelwert, nur Krypto,
        # Datenlücke, Hysterese, Mindestdauer, Tor in Welt A, Zeitpunkt des Vorgangs, zwei Welten mit Welt B byte-gleich, veraltet,
        # Handbremse, Kalibrierung, Zeitstempel, Zeitklassen) und die Prüfung des Tors im Labor-Code (ast); dazu das Debug-Werkzeug
        # (Zerlegung von Hand, t0, Rückblick, Kausalität des Rückwärtstests mit Ködern, Positivkontrolle) und die Handbremse im Dashboard
        ("Notbremse: Proben 1–11 und 14–17, Tor im Labor-Code (hl_notbremse, rund 2 min)",
         [py, str(ROOT / "hl_notbremse.py"), "--selbsttest"]),
        ("Notbremse-Werkzeug: Zerlegung, t0, Rückblick, Rückwärtstest kausal, Positivkontrolle; seit 23.77 Rückblick im Hintergrund, "
         "Speicherwächter, Rate an der Klammer (check_notbremse)",
         [py, str(ROOT / "check_notbremse.py"), "--selbsttest"]),
        # 23.77: Systemdiagnose ohne SSH -- Wächter-Log, Lücken im Verlauf, Strom, Journal (mit sudo-Rückfall), Ende des vorigen Starts
        # 23.80 (U218): dazu das Modell der Poller-Kapazität (von Hand nachgerechnet) und seine Werte gegen den Quelltext des Recorders;
        # 23.86 (U220/U231): Gesperrte nicht abgefragt, kleine nach eigenem Handel, „groß“ ab 500.000, Gegenprobe Pool wie der Recorder,
        # vom Recorder gemessene Abstände gegen das Modell, Abstände aus dem Alter zurückgerechnet (beschreibend), Anteil zu alter Positionen
        # bei ähnlicher Laufzeit
        ("Systemdiagnose: Wächter-Log, Verlauf, Strom, Journal, Ende des vorigen Starts; seit 23.80 Poller-Kapazität, seit 23.86 neue Stufen, "
         "gemessene Abstände und Gegenprobe wie der Recorder (check_system)",
         [py, str(ROOT / "check_system.py"), "--selbsttest"]),
        ("Dashboard: Notbremse -- Handbremse nur per POST, Banner, Abschnitt; seit 23.77 Debug-Einträge Rückblick im Hintergrund und "
         "Systemdiagnose (hl_viz)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-notbremse"]),
        # 23.78 (U215): Selbstheilung bei Hängern -- Lebenszeichen nur mit Antwort, Abzüge, Ende zu Ende mit nachgebautem systemd
        ("Dashboard: Selbstheilung bei Hängern -- /lebt, WATCHDOG=1 nur mit Antwort, Stapel nach 1,5 s und beim SIGABRT, nachgebautes systemd "
         "(hl_viz, rund 30 s)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-lebt"]),
        # 23.80 (U218): Poller und Abdeckung gegen den eigenen Normalwert statt fester Schwellen (Wächter stand dauernd auf KRITISCH)
        ("Wächter: Dashboard antwortet auf seinem Port; seit 23.80 Poller und Abdeckung gegen den eigenen Normalwert (hl_watchdog)",
         [py, str(ROOT / "hl_watchdog.py"), "--selbsttest"]),
        ("Adress-Strom: Nehmer/Geber, TWAP, Vorhalt, Deckel (hl_adressfluss)",
         [py, str(ROOT / "hl_adressfluss.py"), "--selbsttest"]),
        # 23.34: Fills der Darwin-Liste ohne Mindestbetrag, Deckel, Richtung, pool_fills_hourly unverändert
        ("Recorder: Fills der Darwin-Liste und der Elite (hl_recorder)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-fills"]),
        # 23.35: Wal-Stand im 6-h-Fenster, Einzelflug gegen Anfragestau (Dauerlast 29./30.09.); 23.36: Exposure ohne Gesperrte
        ("Dashboard: Last-Schutz und Wal-Stand (hl_viz)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-last"]),
        # 23.68 (U166): Felder der /chart-Nutzlast je Quelle gleich (ausgenommen x_vol eingetretener Marken), FVG-Mindestgröße und
        # Abstände im Binance-Modus; ohne Netz (Attrappe der Binance-Tiefe)
        ("Dashboard: Quellen im Vergleich -- Felder, FVG-Mindestgröße, Abstände (hl_viz)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-quellen"]),
        # 23.36: Recorder-Start liest den Wal-Zustand aus 24 h statt der ganzen Tabelle; Gesperrte ohne Scheinpositionen
        ("Recorder: Start mit Wal-Zustand (hl_recorder)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-start"]),
        # 23.37: Masterregel zählt gespeicherte Fills nur ab 2.500 USD; Sperren seit 29.09. einmalig neu bewertet;
        # 23.38: nur mit nachvollzogener Sperre freigeben, falsche Freigaben (ohne kleines Bündel) einmalig zurücknehmen
        ("Recorder: Masterregel ohne Kleinfills, Rücknahme falscher Freigaben (hl_recorder)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-sperre"]),
        # 23.38: API-Gewicht hart gedeckelt (gleitendes 60-s-Fenster), Begrenzer in virtueller Zeit unter der Last vom 30.09.
        ("Recorder: API-Gewicht hart gedeckelt (hl_recorder)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-gewicht"]),
        # 23.82 (U222): späte Trades ergänzen geschriebene Minuten und 10-s-Stücke statt sie zu ersetzen, Halten nach Börsenzeit,
        # (Zeit, tid) entdoppelt, Wiederholungen nie doppelt, Neustart mit Marke u222_hw_ms, Schreibtakt :03, :13, …; Zufallsfolge gegen die
        # Wahrheit
        ("Recorder: späte und doppelte Trades in Minuten-Bars und 10-s-Stücken (hl_recorder, U222)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-bars"]),
        # 23.66 (U145): zwei Sicherungen derselben Datenbank gleichzeitig (update.py und Recorder, 11.10.) -- Sperre, eigene
        # Zwischendateien, Warten und Übernehmen, Absturz eines Halters, Altlasten, backup.json immer ganz, Nebendatenbanken;
        # 23.95 (U243): zwei Generationen (alte .2 vor der Platzprüfung weg), Laufwerk nicht eingehängt, Ordner nicht anlegbar,
        # backup_laeuft, Schleife des Recorders (neuer Pfad binnen Sekunden, auch während einer laufenden Sicherung)
        # 23.103 (U257): staking.db unter den Nebendatenbanken; Inhalt jeder Kopie und voriger Stand (.1); Muster aus der einen Liste
        ("Backup: Sperre, Zwischendateien, zwei Generationen, Ziel nicht eingehängt, Schleife des Recorders (hl_recorder, U145/U243)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-backup"]),
        ("Recorder: first_seen in ms, Audit der Wal-Lebenszyklen und Audit-Uhr (hl_recorder, U149/U150)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-audit"]),
        # 23.75 (Audit v10 vom 22.10.): H-1 Abo-Grenze 10 auch ohne Befehlszeile; M-3 Messung der Fill-Nacharbeit
        ("Recorder: Abo-Grenze und Messung der Fill-Nacharbeit (hl_recorder, Audit v10 vom 22.10.)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-v10"]),
        # 23.86 (U220, Entscheidung Nutzer 26.10.): Gesperrte nie abgefragt, „groß“ ab 500.000 USD, kleine Konten nur nach eigenem Handel;
        # Statuszeile mit derselben Formel wie der Bericht „Poller-Kapazität“; Simulation 2 h unter Überlast
        ("Recorder: Auswahl des Pollers -- Gesperrte nie, „groß“ ab 500.000, kleine nach eigenem Handel, Statuszeile (hl_recorder, U220)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-poller"]),
        # 23.96 (U246, Audit 11.11. N1): Impact-Preise der Börse je Minute in eigener Tabelle; ctx_bars bleibt bei acht Spalten
        ("Recorder: Impact-Preise der Börse je Minute, ctx_bars unverändert (hl_recorder, U246)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-impact"]),
        # 23.97 (U250): der Recorder legt seine Symbole ab, die Notbremse liest denselben Markt (bis 23.96 fester Dex-Name „felix“)
        ("Recorder: Zuordnung der Symbole für die Notbremse (hl_recorder, U250)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-symbole"]),
        # 23.112 (U272): Größe der wegen Alters ausgelassenen Positionen je Coin als Meta-Wert -- nur gemessen, der Stand bleibt
        ("Recorder: Größe der wegen Alters ausgelassenen Positionen je Coin, Stand unverändert (hl_recorder, U272)",
         [py, str(ROOT / "hl_recorder.py"), "--selbsttest-ausgelassen"]),
        # 23.75 (Audit v10 vom 22.10.): M-5 Aktionen nur per POST, M-6 Chart-Zeitraum je Kerzengröße, N-5 ein Sichtbarkeits-Listener
        ("Dashboard: Aktionen nur per POST, Chart-Zeitraum, ein Sichtbarkeits-Listener (hl_viz, Audit v10 vom 22.10.)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-v10"]),
        # 23.95 (U243): Backup-Pfad ändern -- erst prüfen, dann anlegen; Laufwerk eingehängt, FAT, Platz für zwei Generationen, alter
        # Ort, „Alte Backups löschen“ ohne lebende Dateien, „Jetzt sichern“ nicht doppelt, Ordnerauswahl mit Sonderzeichen, Server, Seite
        ("Dashboard: Speicherorte -- Backup-Pfad ändern, Prüfungen, alter Ort, Jetzt sichern, Server, Seite (hl_viz, U243)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-speicher"]),
        # 23.84 (U227): feste Nummern der Debug-Läufe (Nutzer 25.10.) -- jede Nummer genau einmal, vergebene Nummern unverändert, Menü,
        # Berichtsköpfe, Berichtsplan, Debug-Liste (Lauf 125 echt über den Server), Seite
        # 23.109 (U267, U268): im selben Schritt der Planmodus „nach dem Einspielen“ (Probeplan mit drei Paketen: Erkennen, Fälligkeit,
        # eigene Zeitgrenze, kein zweiter Lauf, kein Verfall) und die Benachrichtigung (Einrichten nur per POST mit Kopfzeile, Thema nie in
        # /berichte oder Lauf 151, Meldung nach dem Termin an einen nachgebauten ntfy-Server, Wiederholung je Runde, Abschalten) sowie das
        # Skript der Seite in node (Hinweis im Kopf, Zeilen des Plans, Anleitung, Nachfrage vor dem Abschalten)
        ("Dashboard: Debug-Nummern -- feste Nummer je Lauf, Menü, Berichtsköpfe, Berichtsplan mit Läufen nach dem Einspielen und Benachrichtigung, Debug-Liste (hl_viz, U227, U267, U268)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-debugnr"]),
        # 23.109 (U267, U268): das Modul hinter dem Planmodus und der Benachrichtigung -- Versionsvergleich (99 vor 100), Erkennen des
        # Einspielens (erster Lauf, Sprung über mehrere Pakete, zwei Pakete kurz nacheinander, zurück und wieder vor), Fälligkeit,
        # Planprüfung, Thema erzeugen und in accesstokens.json ablegen (übrige Schlüssel bleiben), Senden an einen nachgebauten
        # ntfy-Server, Fehlertexte ohne Thema, Wiederholung und Aufgeben nach fünf Versuchen, Text von Lauf 151
        ("Berichtsplan: Läufe nach dem Einspielen, Benachrichtigung über ntfy -- Erkennen, Fälligkeit, Planprüfung, Thema, Senden, Wiederholung (hl_berichte, U267, U268, wenige Sekunden)",
         [py, str(ROOT / "hl_berichte.py"), "--selbsttest"]),
        # 23.113 (U278, KONZEPT_Langfrist.md 9): Erstlauf der Optionen -- Kennungen von Deribit und OCC, Kennzahlen je Verfalltag von Hand
        # (Terminkurs, Seiten, Spanne am Geld), Grenzen der Regel 9.2, Handelszeit, der ganze Bericht mit nachgebautem Abruf, Störungen
        # (403, Zeitüberschreitung, HTML, abgeschnittenes JSON), unerwartetes Format, 400 Zufallsproben; der Lauf speichert nichts
        ("Optionen: Erstlauf für den 24-Monats-Chart -- Deribit und IBIT lesen, Kennzahlen je Verfalltag, Regel 9.2, Störungen, unerwartetes Format (hl_optionen, U278, wenige Sekunden)",
         [py, str(ROOT / "hl_optionen.py"), "--selbsttest"]),
        # 23.115 (U277, KONZEPT_Langfrist.md 3 bis 8 und 11): Vorprüfung zum 24-Monats-Chart auf erzeugten Reihen -- kein Blick voraus
        # (volle gegen abgeschnittene Reihe, mit zwei Gegenproben), gleich mit U126, CRPS, Mischung, Vorzeichenwechsel-Test und die drei
        # Bedingungen der Ablösung an gebauten Fällen, Regel B3, Deckung, Alarm, Gewichte von G, zehn kleine Welten, gleiche Rechnung für
        # Chart und Rückrechnung, Urteil; dazu der Lauf an einer erzeugten makro.db (Ablage des Urteils, spätere Läufe, halbe Daten)
        # 23.116 (U279, KONZEPT_Langfrist.md 10 und 10a): dazu der Chart -- ohne Urteil kein Chart, gleiche Rechnung wie die
        # Vorprüfung, Linien (Fair Value, frühere Zyklen), Halving aus der Blockzählung, Anschluss des Ausblicks, Termine,
        # Monatsfassungen (Start, einmal je Monatserstem, kein Blick voraus, unveränderlich), Vorwärtsbilanz, Texte, Antwort der Seite
        ("Langfrist: 24-Monats-Chart -- Vorprüfung (Regeln auf erzeugten Reihen, Ablage des Urteils, Bericht) und Chart (gleiche Rechnung, Linien, Zeitachse, Monatsfassungen, Vorwärtsbilanz), Vertrag mit dem Paket (hl_langfrist, U277/U279, rund 1 min)",
         [py, str(ROOT / "hl_langfrist.py"), "--selbsttest"]),
        # 23.115 (Vorarbeit zu U287): Messung der Recorder-Runden -- Regeln der Messung an nachgestellten Läufen (gleichmäßige Runden,
        # lange Runde, eigene Pause des Messfadens, Neustart des Recorders, verstellte Uhr), Ablage, Aufgaben, der echte Faden an einer
        # echten Datenbank (nur lesen), fehlende Datenbank, Schnappschuss-Runden, Bericht
        ("Recorder: Messung der Runden -- Lebenszeichen lesen, Abstände und Alter, Neustarts, Ablage, Schnappschuss-Runden ohne den Schnappschuss beim Beenden (U294), Aufgaben mit Zwischenständen je Lauf einmal (U296), Bericht; nur lesen (hl_rtakt, U287, wenige Sekunden)",
         [py, str(ROOT / "hl_rtakt.py"), "--selbsttest"]),
        # 23.118 (U280, U292): Optionen-Schicht des 24-Monats-Charts -- Terminkurs aus der Parität, Ränder aus den Preisen an erzeugten
        # Ketten (bekannte, schiefe und verrauschte Verteilung), Fälligkeit des Abrufs, Ablage, Stand für den Chart, Text
        ("Markt-Schicht: Optionen von Deribit für den 24-Monats-Chart -- Terminkurs aus der Parität, Ränder aus den Preisen an erzeugten Ketten, Fälligkeit und Ablage des Tagesabrufs, Stand für den Chart, Text; seit 23.120 dazu die Prognosemärkte für den Chart als Text an einer erzeugten prognosemarkt.db (Debug 159, nur lesen); ohne Netz (hl_marktschicht, U280/U292, wenige Sekunden)",
         [py, str(ROOT / "hl_marktschicht.py"), "--selbsttest"]),
        # 23.87 (U232): Volumenbalken im Live-Chart (Wunsch des Nutzers 26.10.) -- Börse je Kerze auf jedem Weg, Summen, Rechnung der
        # Balken mit node, Schalter, Band, Tooltip
        ("Dashboard: Volumenbalken im Live-Chart -- Börse je Kerze, Summen, Rechnung der Balken, Schalter, Band (hl_viz, U232)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-volumen"]),
        # 23.88 (U235): Abschnitt Prognosemärkte -- Endpunkte je Reiter, R4 über den Server (Tor zu vor, offen nach dem Urteil), fehlende
        # und kaputte Datei, Skript mit node, keine Kauf- oder Verkaufswörter, Seite, Dienst aus im Selbsttest, kein Projektmodul, Debug
        ("Dashboard: Prognosemärkte -- Endpunkte, R4, Skript, Seite, Dienst, Debug-Läufe 129–133 (hl_viz, U235)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-prognosemarkt"]),
        ("Dashboard: Volatilität -- Endpunkte, Tor vor dem Urteil, Skript, Seite, Dienst, Debug-Läufe 134–137 (hl_viz, U237)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-volatil"]),
        ("Dashboard: Trading Engine -- Endpunkte, Kopf, Skript, Seite, Dienst, Sicherung, Debug-Läufe 138–141, Button „Bremse lösen“ (hl_viz, U241)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-engine"]),
        # 23.98 (U245 Stufe C1, KONZEPT_Cockpit.md 6): Cockpit -- Abgleich jeder Zahl mit ihrer Quelle, Schwellen der fünf Lampen an
        # ihren Grenzen, Frische (ohne Quelle kein „aus“), Wortprobe, Ordnung der Seite; Vertrag mit Ausblick, Volatilität, Chartbild,
        # Makro und der Aktien-Regel auf den Demo-Datenbanken der Module (echte Formen, kein Netz)
        # 23.104 (U260): Karte „Unstaking · Verlauf“ -- Antwort aus einer Beispielreihe (Reihen, Zeiträume ohne Daten ab drei Tagen, Wellen
        # mit Text und Zeile, Sätze, Ausschnitte), Zeilen in Debug 143, Vertrag mit hl_staking_studie.verlauf; im Dashboard-Schritt
        # darunter: /cockpit/unstaking und die Zeichnung im nachgebauten Dokument (Ausschnitte, Antippen, Tasten, Liste, Laden)
        # 23.105 (U245 Stufe C2): Karte „Kurs-Rechner“ -- Stunden gleich dem Nullmodell des Magnet-Tests (hl_kaskade.p_ueber), Tage gleich
        # hl_ausblick.erreichen_aus_lauf, längere Frist nie unwahrscheinlicher, Grenzen und Vermerke, ohne Quelle kein Wert; Vertrag: Tage
        # auf der Demo-Welt des Ausblicks, Stunden mit Positivkontrolle auf einem Probe-Markt (Nullmodell von hl_magnet gerechnet); im
        # Dashboard-Schritt darunter: /cockpit/rechner und die Karte im nachgebauten Dokument (Eingabe lesen, Merken, Abfragen, Tippen)
        # 23.108 (U245 Stufe C2, Rest): Funding (Hyperliquid) mit Perzentil von Hand, Mindestmenge und Frische; Taker-Varianz an der Grenze
        # des untersten Zehntels und gleich hl_indikatoren.varianz_kompression; Liquidationsdichte von Hand, an den Stufengrenzen, nicht
        # frisch, ohne Kurs, Leser auf einer temporären Datenbank (jüngster vollständiger Schnappschuss, alter Stand ohne snapshot_meta);
        # Betriebslampe: API-Gewicht 92,9 / 93,0 %, Backup 36 h, Dienst nicht aktiv erst Hinweis und nach 60 s Warnung, nicht prüfbar;
        # Vertrag: Schwelle und Abfrage wie hl_watchdog, Dienste wie install.py, Altersgrenze und Spalten wie hl_recorder; im
        # Dashboard-Schritt darunter: die Karten im nachgebauten Dokument (zwölf Balken, Auswahl, Pille aus Server und Seite)
        # 23.110 (U269): Karte „Durchschnittslinien“ (50- und 200-Tage-Linie) -- Werte, Abstand zum jetzigen Kurs und Richtung von Hand;
        # Erreich-Wahrscheinlichkeit gleich „Levels“ und an ihren Grenzen (alte Rechnung, erreicht, durchlaufen, anderer Stand der Linie);
        # fehlende Tage, kein Trend, Hinweise; Beleg mit dem Urteil der Niveau-Arten (auch im Beleg der „Levels“); Vertrag: Werte gleich
        # dem Mittel der Tagesschlüsse aus hl_chartbild.tagesteil und gleich trendlage, Niveaus des Ausblicks (ma50_, ma200), Text von
        # hl_niveaus.kurz mit einem gespeicherten Urteil; im Dashboard-Schritt darunter: die Karte im nachgebauten Dokument
        # 23.111 (U270): je Linie beide Werte -- groß wie im Live-Chart (Summe der letzten 49 bzw. 199 Tagesschlüsse + jetziger Kurs),
        # klein nach Tagesschluss; im Dashboard-Schritt der Vertrag mit hl_viz.load_mas (Kachel „MA 200 Tage“, Linien im Chart)
        ("Cockpit: Abgleich mit den Quellen, Schwellen der Lampen, Frische, Wortprobe, Ordnung der Seite, Kurs-Rechner, Funding, Taker-Varianz, Liquidationsdichte, Betrieb, Durchschnittslinien, Vertrag mit den Modulen (hl_cockpit, U245, U269, rund 15 s)",
         [py, str(ROOT / "hl_cockpit.py"), "--selbsttest"]),
        ("Dashboard: Cockpit -- Endpunkte, Skript, Zeichnung, Ordnung der Seite mit Werkstatt und Betrieb, Betriebs-Pille und Karte „Betrieb“, Karte „Liquidationsdichte“, Karte „Durchschnittslinien“, Debug-Läufe 143–144 (hl_viz, U245, U269)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-cockpit"]),
        # 23.122 (U307, KONZEPT_Risikoradar.md): Risikoradar -- Zahlen und Rundung, Faktor gegenüber BTC, Grundrisiko aus der abgelegten
        # Verteilung des Ausblicks (gegen hl_ausblick selbst), Stufen mit Hysterese, Achsen an ihren Grenzen (grau mit Grund), Druck-Index,
        # Alarm mit Sperrzeit und Entwarnung, Hinweis Kontenquote, Push an einen nachgebauten Server (kein Thema im Fehlertext), Takt,
        # Rückblick mit gebauten Fällen (eine richtig gestufte Zahl besteht, drei Arten von Fehlern fallen mit Grund durch), Sperre;
        # im Dashboard-Schritt darunter: Adressen der Karte, Einstellung nur per POST mit Kopfzeile, Skript in node, Ton und Ansage
        # 23.123: dazu die Nachkalibrierung (Regel K: Anpassung von Hand, Monatsgrenzen, Kausalität, Folge je Zahl), das Urteil der Regeln in
        # Karte und Bericht, der Grund einer grauen Achse Umfeld, die Rechenzeit in Debug 160 und im Takt
        # 23.124: dazu der Aufschlag für belegte Zeichen (Regel A: Aufteilung und Reihe von Hand, Vergleich mit der Zahl ohne Aufschlag, eine
        # erfundene Welt ganz durchgerechnet, Karte, Alarmtext, Takt) und die 48-Stunden-Zahl als große Zahl der Karte
        ("Risikoradar: Zahlen, Faktor, Grundrisiko, Stufen, Achsen, Alarm, Push an einen nachgebauten Server, Takt, Rückblick mit Nachkalibrierung und Aufschlag, Sperre (hl_radar, U307, rund 8 s)",
         [py, str(ROOT / "hl_radar.py"), "--selbsttest"]),
        # 23.123 (U308, KONZEPT_Risikoradar.md 5 und 13): Prüfung der Regeln R1 bis R7 -- Perzentile und Ereignisse von Hand, jede Regel
        # an ihrer Grenze, Termine aus makro.db und dem Fed-Kalender, Risikoverhältnis nach Schichten gegen eine Gegenrechnung, Null aus
        # 672 Verschiebungen, Holm, Kalenderhälften, Urteil an den Grenzen; erfundene Märkte (ohne Effekt, mit eingepflanztem Effekt,
        # die Falle „nur unruhige Tage“); Ende zu Ende auf erzeugten Dateien: rechnet, legt ab, rechnet nicht still neu
        # 23.124: dazu der Aufschlag (Zustand je Tag, Chancenverhältnis und Faktoren von Hand, kein Blick voraus, Stand für die Karte)
        ("Risikoradar: Prüfung der Regeln R1 bis R7 -- Regeln von Hand, Statistik, erfundene Märkte, Ende zu Ende ohne stilles Neurechnen, Aufschlag (hl_radar_regeln, U308, rund 30 s, auf dem Pi länger)",
         [py, str(ROOT / "hl_radar_regeln.py"), "--selbsttest"]),
        ("Dashboard: Risikoradar -- Adressen der Karte, Einstellung per POST, Skript, Zeichnung (48 Stunden groß, Aufschlag), Ton und Ansage, Ordnung der Seite (hl_viz, U307)",
         [py, str(ROOT / "hl_viz.py"), "--selbsttest-radar"]),
        # 23.100 (U254, KONZEPT_Unstaking.md 7): Unstaking bei Ethereum -- Zeitrechnung der Kette, Listen des Beacon-Knotens in Stücken
        # gelesen, Zusammenlegungen abgezogen, Kalender „frei ab“, große Freigabe, Ersatz aus der Tagesdatei, Fehlerfälle; der echte
        # Abruf (urllib, gzip, HTTP-Fehler) gegen einen Webserver auf diesem Rechner -- ohne Netz
        # 23.102: eigene Tagesreihe aus dem Knoten (erste Messung je UTC-Tag), stehengebliebene Tagesdatei (Alter, kein Abgleich,
        # Laufdauer mit dem Tag ihrer Zahl), Tage mit Abbau über dem Tagesdurchsatz, Nachstellung des Stands vom 15.11.2026
        # 23.106 (U259): Tagesbeginn (Messung vor 03:00 UTC), Summe „angemeldet“, Nachholen alle 5 Minuten, Zeilen der Tagesreihe in Debug 145
        ("Unstaking: Zeitrechnung, Listen des Beacon-Knotens, Zusammenlegungen abgezogen, Kalender, große Freigabe, Ersatz, Fehlerfälle, echter Abruf lokal, Tagesreihe mit Nachholen zu Tagesbeginn (hl_staking, U254, rund 2 s)",
         [py, str(ROOT / "hl_staking.py"), "--selbsttest"]),
        # 23.101 (U255, KONZEPT_Unstaking.md 6, 6a und 7): Prüfung der Kursfolge -- Fälle A und B von Hand, drei echte Zeilen der
        # Tagesdatei, Kurs zu Tagesbeginn und Zielgröße, Kreistest gegen eine Gegenrechnung ohne numpy, Holm, Urteil an den Grenzen,
        # Nullprobe mit Gegenprobe, Fundquote (abgekürzte gegen volle Rechnung), drei Welten Ende zu Ende, kein stilles Neurechnen
        # 23.102: Ende der Daten im Bericht -- „nicht in den Daten“ statt „keine Welle“, Vermerk beim Urteil, Schlange am Vortag
        # 23.104 (U260): Reihen für den Verlauf im Cockpit -- Kurs zu Tagesbeginn aus zwei Kerzen je Tag (gleich kurse_lesen), Schlange wie
        # die Prüfung sie liest, eigene Tagesreihe, Wellen des gespeicherten Urteils; nur lesen
        # 23.106 (U259, KONZEPT_Unstaking.md 6c): zweite Prüfung, vorab festgelegt -- eigene Reihe (nur Tage vor 03:00 UTC, Summe „angemeldet“),
        # Fälle von Hand und gegen die erste Regel auf Zufallsreihen, Stichtag, Stand wie am 16.11.2026, Bericht ohne Kursfolgen neuer
        # Wellen, Tage mit zu schnellem Abbau der Tagesdatei (Zacke, Delle); gerechnet wird die zweite Prüfung hier nicht
        ("Unstaking, Prüfung der Kursfolge: Fälle, Zielgröße, Kreistest, Holm, Urteil, Nullprobe, Positivkontrolle, Speichern ohne stilles Neurechnen, zweite Prüfung (Fälle, Zähler, Stichtag) (hl_staking_studie, U255, rund 15 s)",
         [py, str(ROOT / "hl_staking_studie.py"), "--selbsttest"]),
        # 23.107 (U244, KONZEPT_Niveaus.md): Bilanz je Niveau-Art -- Fälle dreier Ursprünge von Hand (Niveaus, pe, ps, ja, z), Abgleich mit S3
        # (n und Brier genau), Kausalität, Bein-Schwelle gegen hl_chartbild, Regression und Randeffekt von Hand, Holm, Hälften, Spiegel,
        # vertauschte Etiketten, eingepflanztes Halten Ende zu Ende, ein Urteil statt vieler, Sperre bei abweichendem S3, Vorwärtszählung
        ("Niveaus, Bilanz je Art: Fälle von Hand, Abgleich mit S3, Kausalität, Regression, Holm, Hälften, Spiegel, eingepflanzter Effekt, ein Urteil statt vieler, Vorwärtszählung (hl_niveaus, U244, rund 30 s)",
         [py, str(ROOT / "hl_niveaus.py"), "--selbsttest"]),
        ("Datenbank + Simulation",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--simulate"]),
        ("Statusabfrage",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--status"]),
        ("Cluster-Analyse (pandas/numpy)",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--analyze",
          "--coin", "BTC"]),
        ("Datenbank-Audit (mit Einheiten-Invarianten)",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--audit"]),
        ("Heatmap zeichnen (matplotlib)",
         [py, str(ROOT / "hl_viz.py"), "--db", str(db), "--coin", "BTC",
          "--hours", "48", "--out", str(png)]),
        ("Backtest-Engine",
         [py, str(ROOT / "hl_backtest.py"), "--synthetic"]),
        ("Binance-Parser",
         [py, str(ROOT / "hl_binance.py"), "--selftest"]),
        ("Wächter",
         [py, "-c",
          f"import subprocess,sys,json;"
          f"r=subprocess.run([{py!r},{str(ROOT / 'hl_watchdog.py')!r},"
          f"'--db',{str(db)!r},'--once','--json'],capture_output=True,text=True);"
          f"d=json.loads(r.stdout);"
          f"sys.exit(0 if d.get('checks') else 1)"]),
        ("Zeit-Heatmap",
         [py, str(ROOT / "hl_timestats.py"), "--db", str(db), "--simulate",
          "--years", "1", "--thresholds", "0.01"]),
    ]

    ok = True
    for label, cmd in steps:
        t0 = time.time()
        r = run(cmd)
        if r.returncode == 0:
            print(f"{OK}{label:<34} {time.time()-t0:5.1f}s")
        else:
            print(f"{FAIL}{label}")
            print((r.stderr or r.stdout).strip()[-700:])
            ok = False

    if png.exists() and png.stat().st_size > 10_000:
        print(f"{OK}{'PNG erzeugt':<34} {png.stat().st_size/1024:5.0f} kB")
    else:
        print(f"{FAIL}PNG wurde nicht erzeugt")
        ok = False

    # Dashboard: Server starten und alle Endpunkte abfragen
    import json as _json
    import urllib.request
    proc = subprocess.Popen(
        [py, str(ROOT / "hl_viz.py"), "--db", str(db), "--serve", "--port", "8799"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(3)
        checks = [
            ("/", lambda b: b.startswith(b"<!doctype html")),
            ("/coins", lambda b: isinstance(_json.loads(b), list)),
            ("/data?coin=BTC&hours=6", lambda b: "grid" in _json.loads(b)),
            ("/chart?coin=BTC&agg=5&minutes=720",
             lambda b: len(_json.loads(b).get("candles", [])) > 0),
            ("/labor", lambda b: "strategien" in _json.loads(b) and "gesamt" in _json.loads(b)),                 # 23.33 TradeLabor
            ("/labor/daten?coin=BTC", lambda b: "zeilen" in _json.loads(b)),
            ("/labor/chart?coin=BTC&h=24", lambda b: "kurs" in _json.loads(b)),
            ("/makro?tab=ueberblick", lambda b: "ok" in _json.loads(b) and "tab" in _json.loads(b)),          # 23.47 Makro-Chart (ohne makro.db: Hinweis)
            ("/makro.js", lambda b: b"function mkZeichne" in b),
            ("/prognosemarkt?tab=ueberblick", lambda b: "ok" in _json.loads(b) and "tab" in _json.loads(b)),  # 23.88 Prognosemärkte (ohne Datei: Grund)
            ("/prognosemarkt.js", lambda b: b"function pmZeigen" in b),
            ("/volatil?tab=chart&coin=BTC", lambda b: "ok" in _json.loads(b) and "tab" in _json.loads(b)),  # 23.90 Volatilität (ohne Datei: Grund)
            ("/volatil.js", lambda b: b"function vlZeigen" in b),
            ("/labor/engine", lambda b: _json.loads(b).get("ok") is True and "strategien" in _json.loads(b)),  # 23.93 Trading Engine (ohne Datei: Hinweis)
            ("/engine.js", lambda b: b"function labEngine" in b),
            ("/chartbild?coin=BTC", lambda b: _json.loads(b).get("ok") is True and "lesart" in _json.loads(b)),   # 23.65 Chartbild (Selbsttest-DB: Gründe statt Bild)
            ("/chartbild.js", lambda b: b"function cbZeichne" in b),
            ("/ausblick?coin=BTC", lambda b: _json.loads(b).get("ok") is True and "takt" in _json.loads(b)),   # 23.66 Ausblick (Selbsttest-DB: Gründe statt Fächer)
            ("/ausblick.js", lambda b: b"function auZeichne" in b),
            ("/aktienmarkt", lambda b: _json.loads(b).get("kennzeichnung") == "beschreibend, nicht geprüft"),
            ("/cockpit?coin=BTC", lambda b: _json.loads(b).get("ok") is True and len(_json.loads(b).get("lampen") or []) == 5),  # 23.98 Cockpit (Selbsttest-DB: Gründe statt Zahlen)
            ("/cockpit.js", lambda b: b"function ckZeichne" in b and b"function ckRechner" in b),
            ("/cockpit/rechner?coin=BTC&kurs=50000", lambda b: _json.loads(b).get("ok") is True and len(_json.loads(b).get("zeilen") or []) == 1  # 23.105 Kurs-Rechner
             and len(_json.loads(b).get("fristen") or []) == 4),                                                # (Selbsttest-DB: Gründe statt Zahlen)
            ("/cockpit/radar?coin=BTC", lambda b: _json.loads(b).get("ok") is True and len(_json.loads(b).get("achsen") or []) == 8  # 23.122 Risikoradar
             and set(_json.loads(b).get("ereignis") or {}) == {"e7", "e2"} and b"NaN" not in b),                # (Selbsttest-DB: Gründe statt Zahlen)
            ("/radar.js", lambda b: b"function rdKarte" in b and b"function rdMelden" in b),
            ("/cockpit/radar/meldungen", lambda b: _json.loads(b).get("ok") is True and _json.loads(b).get("meldungen") == []),
        ]
        for path, valid in checks:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:8799{path}", timeout=15) as resp:
                    body = resp.read()
                if resp.status == 200 and valid(body):
                    print(f"{OK}{'Dashboard ' + path.split('?')[0]:<34} "
                          f"{len(body)/1024:5.0f} kB")
                else:
                    print(f"{FAIL}Dashboard {path}: unerwartete Antwort "
                          f"({resp.status}, {len(body)} Bytes)")
                    ok = False
            except Exception as e:
                print(f"{FAIL}Dashboard {path}: {e}")
                ok = False
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()

    for f in (db, png, ROOT / f"{db.name}-wal", ROOT / f"{db.name}-shm"):
        f.unlink(missing_ok=True)
    return ok


# ---------------------------------------------------------------------------
# 5. systemd
# ---------------------------------------------------------------------------

RECORDER_UNIT = """[Unit]
Description=Hyperliquid Liquidation Recorder
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_recorder.py --coins {coins} --db {db}{bak}
Restart=always
RestartSec=20
Environment=PYTHONUNBUFFERED=1
StandardOutput=append:{logdir}/recorder.log
StandardError=append:{logdir}/recorder.log

[Install]
WantedBy=multi-user.target
"""

# 23.76 (U206): Wants=hl-notbremse.service -- startet das Dashboard, startet systemd die Notbremse mit. So läuft der neue Dienst
# auch nach einem Update mit einer älteren update.py, die ihn in ihrer Dienstliste noch nicht kennt (sie aktiviert neue Units nur).
DASH_UNIT = """[Unit]
Description=Hyperliquid Liquidation Dashboard
After=network-online.target
Wants=hl-notbremse.service

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_viz.py --serve --host 0.0.0.0 --port 8765 --db {db}
Environment=PYTHONUNBUFFERED=1
Restart=always
RestartSec=20
# 23.78 (U215): Selbstheilung bei Hängern (Ausfall vom 23.10.: Prozess lebte, Port 8765 antwortete knapp 5 h nicht). Das Dashboard meldet
# WATCHDOG=1 nur, wenn es seine eigene Seite /lebt abrufen kann; bleibt das aus (WatchdogSec), beendet systemd es mit SIGABRT (faulthandler
# schreibt dabei die Stapel aller Fäden nach dashboard_haenger.log) und startet es neu. Kein Speicherabbild (1 GB) auf die SD-Karte.
# 23.114 (U286): 3 Minuten statt 15 -- am 19.11.2026 hing das Dashboard, und der Nutzer startete den Pi neu, bevor die 15 Minuten um
# waren. Das Dashboard fragt sich bei 3 Minuten alle 45 s selbst (bleiben drei Abfragen in Folge ohne Antwort, folgt der Abbruch); in
# den 7 Tagen vor dem 20.11.2026 meldete es keine einzige ausgebliebene Antwort (Debug 20).
WatchdogSec=180
NotifyAccess=main
LimitCORE=0
Environment=HL_LOGDIR={logdir}
StandardOutput=append:{logdir}/dashboard.log
StandardError=append:{logdir}/dashboard.log

[Install]
WantedBy=multi-user.target
"""


WATCHDOG_UNIT = """[Unit]
Description=Recorder Watchdog
After=network.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
# Alarmton laeuft ueber die Audioausgabe (HDMI, USB-Audio, DAC-HAT).
# Der Pi 5 hat KEINEN eingebauten Lautsprecher und keine Klinkenbuchse.
# Weitere Optionen nach Bedarf:
#   --led         ACT-LED (der Dienst muss dafuer als root laufen)
#   --ntfy DEIN-TOPIC  --heartbeat https://hc-ping.com/DEINE-UUID
ExecStart={py} {root}/hl_watchdog.py --db {db} --interval 300 --alarm-interval 120
Restart=always
RestartSec=30
Environment=PYTHONUNBUFFERED=1
StandardOutput=append:{logdir}/watchdog.log
StandardError=append:{logdir}/watchdog.log

[Install]
WantedBy=multi-user.target
"""


# Die Coin-Liste steht EINMAL hier und geht an alle Dienste. Vorher hatte der
# Coinbase-Dienst eine eigene: Er zeichnete SOL, XRP und DOGE auf, die nie angezeigt
# werden, und ließ HYPE, PAXG, XMR und ZEC aus -- genau die Coins, die im Dashboard
# stehen. Spot-Prämie und Spot-Flow gab es damit nur für BTC und ETH.
COINS = ["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"]

BNC_UNIT = """[Unit]
Description=Binance Liquidation Stream
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_binance.py --db {db}
Restart=always
RestartSec=20
Environment=PYTHONUNBUFFERED=1
StandardOutput=append:{logdir}/binance.log
StandardError=append:{logdir}/binance.log

[Install]
WantedBy=multi-user.target
"""


CB_UNIT = """[Unit]
Description=Coinbase Spot Feed (Praemie, Taker-Flow, Orderbuch)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_coinbase.py --db {db} --coins {coins}
Restart=always
RestartSec=20
Environment=PYTHONUNBUFFERED=1
StandardOutput=append:{logdir}/coinbase.log
StandardError=append:{logdir}/coinbase.log

[Install]
WantedBy=multi-user.target
"""


# 23.76 (U206, KONZEPT_Notbremse.md): Notbremse -- jede Minute Mids beider Körbe, Maße, Stufe; eigene Datei notbremse.db neben der
# Datenbank. Wirkt nur über das Tor der Welt A im TradeLabor (im Dashboard-Prozess).
NB_UNIT = """[Unit]
Description=Notbremse (marktweite Long-Sperre fuer das TradeLabor, Welt A)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_notbremse.py --db {db}
Restart=always
RestartSec=20
Environment=PYTHONUNBUFFERED=1
StandardOutput=append:{logdir}/notbremse.log
StandardError=append:{logdir}/notbremse.log

[Install]
WantedBy=multi-user.target
"""


def enable_systemd() -> bool:
    """Units nach /etc/systemd/system kopieren und aktivieren."""
    out = ROOT / "systemd"
    units = sorted(out.glob("*.service"))
    if not units:
        print(f"{FAIL}Keine Unit-Dateien gefunden")
        return False
    sudo = [] if os.geteuid() == 0 else ["sudo"]
    if sudo and not shutil.which("sudo"):
        print(f"{WARN}kein sudo — bitte manuell kopieren und aktivieren")
        return False
    names = [u.stem for u in units]
    print("        Installiere Dienste (Passwortabfrage möglich) …")
    steps = [
        sudo + ["cp"] + [str(u) for u in units] + ["/etc/systemd/system/"],
        sudo + ["systemctl", "daemon-reload"],
        sudo + ["systemctl", "enable", "--now"] + names,
    ]
    for cmd in steps:
        if subprocess.run(cmd).returncode != 0:
            print(f"{FAIL}Fehlgeschlagen: {' '.join(cmd)}")
            return False
    print(f"{OK}Aktiviert und gestartet: {', '.join(names)}")
    print(f"{OK}Starten künftig automatisch beim Booten")
    time.sleep(3)
    for n in names:
        r = run(["systemctl", "is-active", n])
        state = r.stdout.strip() or "unbekannt"
        print(f"{OK if state == 'active' else WARN}{n:<22} {state}")
    return True


def setup_systemd(db_path: str, backup_dir: str | None = None,
                  log_dir: str | None = None) -> None:
    hr("5. systemd-Dienste")
    user = os.environ.get("SUDO_USER") or os.environ.get("USER") or "pi"
    py = str(VENV / "bin" / "python")
    logdir = log_dir or str(ROOT)
    os.makedirs(logdir, exist_ok=True)
    ctx = {"user": user, "root": str(ROOT), "py": py, "db": db_path, "logdir": logdir,
           "coins": " ".join(COINS),
           "bak": f" --backup-dir {backup_dir}" if backup_dir else ""}
    if backup_dir:
        print(f"  Backup-Ordner: {backup_dir}")
    if log_dir:
        print(f"  Logdateien:    {logdir}")

    out = ROOT / "systemd"
    out.mkdir(exist_ok=True)
    (out / "hl-recorder.service").write_text(RECORDER_UNIT.format(**ctx))
    (out / "hl-dashboard.service").write_text(DASH_UNIT.format(**ctx))
    (out / "hl-binance.service").write_text(BNC_UNIT.format(**ctx))
    # Coinbase listet nur die großen Coins gegen USD; nicht gelistete fallen im Dienst
    # still heraus, deshalb dieselbe Coin-Liste wie der Recorder.
    (out / "hl-coinbase.service").write_text(CB_UNIT.format(**ctx))
    (out / "hl-notbremse.service").write_text(NB_UNIT.format(**ctx))           # 23.76 (U206)
    (out / "hl-watchdog.service").write_text(WATCHDOG_UNIT.format(**ctx))
    print(f"{OK}Unit-Dateien in {out}")
    print("\n        Aktivieren mit:")
    print(f"          sudo cp {out}/*.service /etc/systemd/system/")
    print("          sudo systemctl daemon-reload")
    print("          sudo systemctl enable --now hl-recorder hl-dashboard hl-binance hl-coinbase hl-notbremse hl-watchdog")
    print("\n        Kontrolle:")
    print("          systemctl status hl-recorder")
    print(f"          tail -f {ROOT}/recorder.log")
    print("\n        Der Dashboard-Dienst lauscht auf 0.0.0.0 ohne Passwort.")
    print("        Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Einrichtung für Raspberry Pi 5 / Trixie")
    p.add_argument("--check", action="store_true", help="nur prüfen")
    p.add_argument("--selftest", action="store_true", help="nur Skripte testen")
    p.add_argument("--selftest-isoliert", action="store_true", help="Selbsttest in einer Kopie des Projektordners (für das Dashboard, U30)")
    p.add_argument("--no-apt", action="store_true")
    p.add_argument("--systemd", action="store_true",
                   help="Unit-Dateien erzeugen")
    p.add_argument("--enable", action="store_true",
                   help="Unit-Dateien erzeugen UND aktivieren (Autostart)")
    p.add_argument("--units-only", action="store_true",
                   help="nur die Unit-Dateien neu erzeugen (für update.py)")
    p.add_argument("--backup-dir", default=None,
                   help="Backup-Ordner für den Recorder (Standard: neben der Datenbank)")
    p.add_argument("--log-dir", default=None,
                   help="Ordner für recorder.log, binance.log, watchdog.log (Standard: Projektordner)")
    p.add_argument("--db", default=str(ROOT / "hl_liq.db"),
                   help="Pfad der Datenbank für die systemd-Dienste")
    args = p.parse_args()

    print("=" * 62)
    print(" Hyperliquid Liquidations-Recorder — Einrichtung")
    print("=" * 62)

    if args.selftest_isoliert:
        sys.exit(0 if selftest_isoliert() else 1)
    if args.selftest:
        sys.exit(0 if selftest() else 1)
    if args.units_only:
        setup_systemd(args.db, args.backup_dir, args.log_dir)
        sys.exit(0)

    problems = check_environment()
    if args.check:
        print("\nNur Prüflauf, nichts verändert.")
        sys.exit(1 if problems else 0)
    if "Python zu alt" in problems or "Projektdateien fehlen" in problems:
        print("\nAbbruch: kritische Voraussetzungen fehlen.")
        sys.exit(1)

    install_apt(args.no_apt)
    if not install_python():
        sys.exit(1)

    ok = selftest()
    if args.systemd or args.enable:
        setup_systemd(args.db)
        if args.enable:
            enable_systemd()

    hr("Ergebnis")
    if ok:
        print(f"{OK}Alles funktioniert.\n")
        print("        Alles auf einmal starten (Vordergrund):")
        print(f"          {VENV}/bin/python run_all.py --host 0.0.0.0")
        print("\n        Dauerbetrieb mit Autostart beim Booten:")
        print("          python3 install.py --enable")
        print("\n        Der Recorder braucht Wochen, bis die Daten aussagekräftig sind.")
    else:
        print(f"{FAIL}Selbsttest fehlgeschlagen — Ausgaben oben prüfen.")
        sys.exit(1)


if __name__ == "__main__":
    main()
