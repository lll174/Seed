#!/usr/bin/env python3
"""
install.py — Einrichtung des Hyperliquid-Recorders auf Raspberry Pi 5 / Debian Trixie.

Legt eine virtuelle Umgebung an, installiert die Abhängigkeiten, prüft die
Umgebung und fährt anschließend einen echten Selbsttest über alle Skripte.

    python3 install.py                 # komplette Einrichtung
    python3 install.py --check         # nur prüfen, nichts verändern
    python3 install.py --selftest      # nur die Skripte testen
    python3 install.py --systemd       # zusätzlich Dienste einrichten

Warum ein venv: Debian Trixie markiert die System-Python-Installation als
"externally managed" (PEP 668). Ein direktes pip install schlägt fehl, und
--break-system-packages kann apt-Pakete beschädigen. Das venv umgeht beides.
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
PROJECT_FILES = ["hl_recorder.py", "hl_viz.py", "hl_backtest.py",
                 "hl_binance.py", "hl_timestats.py", "hl_watchdog.py", "run_all.py",
                 "requirements.txt"]

APT_PACKAGES = [
    "python3-venv",      # auf Trixie nicht immer vorinstalliert
    "python3-dev",
    "build-essential",   # nur Fallback, falls ein Wheel fehlt
    "libopenblas-dev",   # numpy-Performance auf ARM
    "pkg-config",
    "libfreetype6-dev",  # matplotlib-Fallback
    "libpng-dev",
]

OK, WARN, FAIL = "  [ok]  ", "  [!]   ", "  [FEHLER] "


def hr(title: str) -> None:
    print(f"\n{title}\n" + "-" * 62)


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def venv_python() -> Path:
    """Interpreter des venv, sonst der aktuelle (für --selftest ohne venv)."""
    p = VENV / "bin" / "python"
    return p if p.exists() else Path(sys.executable)


# ---------------------------------------------------------------------------
# 1. Umgebung prüfen
# ---------------------------------------------------------------------------

def check_environment() -> list[str]:
    hr("1. Umgebung")
    problems: list[str] = []

    v = sys.version_info
    if v >= (3, 11):
        print(f"{OK}Python {v.major}.{v.minor}.{v.micro}")
    else:
        print(f"{FAIL}Python {v.major}.{v.minor} — mindestens 3.11 nötig")
        problems.append("Python zu alt")

    arch = platform.machine()
    print(f"{OK}Architektur {arch}"
          if arch in ("aarch64", "arm64", "x86_64")
          else f"{WARN}Architektur {arch} — ungetestet")
    if arch in ("armv7l", "armv6l"):
        print(f"{WARN}32-Bit-System. Für den Pi 5 das 64-Bit-OS verwenden, "
              "sonst fehlen Wheels und alles wird kompiliert.")

    osr = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line:
                k, _, val = line.partition("=")
                osr[k] = val.strip('"')
    except OSError:
        pass
    name = osr.get("PRETTY_NAME", "unbekannt")
    if osr.get("VERSION_CODENAME") == "trixie":
        print(f"{OK}{name}")
    else:
        print(f"{WARN}{name} — Skript ist auf Trixie ausgelegt, "
              "läuft aber auf jedem Debian/Ubuntu mit Python ≥ 3.11")

    # Pi-Modell
    try:
        model = Path("/proc/device-tree/model").read_text().strip("\x00").strip()
        print(f"{OK}{model}")
    except OSError:
        print(f"{WARN}Kein Raspberry Pi erkannt (kein Problem)")

    # RAM
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal"):
                gb = int(line.split()[1]) / 1_048_576
                print(f"{OK}RAM {gb:.1f} GB" if gb >= 1.8
                      else f"{WARN}RAM {gb:.1f} GB — knapp, aber machbar")
                break
    except OSError:
        pass

    # Plattenplatz
    free = shutil.disk_usage(ROOT).free / 1e9
    if free >= 5:
        print(f"{OK}Freier Speicher {free:.1f} GB")
    else:
        print(f"{WARN}Nur {free:.1f} GB frei — die Datenbank wächst um "
              "rund 0,4 GB pro Monat bei drei Coins")

    # Schreibmedium: SD-Karte verschleißt bei Dauerschreiben
    try:
        src = run(["findmnt", "-no", "SOURCE", "--target", str(ROOT)]).stdout.strip()
        if "mmcblk" in src:
            print(f"{WARN}Projekt liegt auf der SD-Karte ({src}).")
            print("        Der Recorder schreibt dauerhaft. Für Monatsbetrieb "
                  "besser eine USB-SSD nehmen und --db dorthin legen.")
        elif src:
            print(f"{OK}Schreibmedium {src}")
    except (OSError, FileNotFoundError):
        pass

    # Zeitsynchronisation — Timestamps sind die halbe Datenqualität
    r = run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    if r.returncode == 0:
        if r.stdout.strip() == "yes":
            print(f"{OK}Systemzeit per NTP synchronisiert")
        else:
            print(f"{WARN}Zeit NICHT synchronisiert. Ohne korrekte Uhr sind die "
                  "aufgezeichneten Zeitstempel unbrauchbar.")
            print("        Beheben mit: sudo timedatectl set-ntp true")
            problems.append("Zeit nicht synchron")

    # PEP 668
    stdlib = Path(sysconfig.get_paths()["stdlib"])
    if (stdlib / "EXTERNALLY-MANAGED").exists():
        print(f"{OK}PEP-668-System erkannt — venv wird verwendet")

    # Projektdateien
    missing = [f for f in PROJECT_FILES if not (ROOT / f).exists()]
    if missing:
        print(f"{FAIL}Fehlende Dateien: {', '.join(missing)}")
        problems.append("Projektdateien fehlen")
    else:
        print(f"{OK}Alle {len(PROJECT_FILES)} Projektdateien vorhanden")

    return problems


# ---------------------------------------------------------------------------
# 2. Systempakete
# ---------------------------------------------------------------------------

def install_apt(skip: bool) -> None:
    hr("2. Systempakete")
    if skip:
        print("        übersprungen (--no-apt)")
        return
    if not shutil.which("apt-get"):
        print(f"{WARN}kein apt — Schritt übersprungen")
        return

    missing = [p for p in APT_PACKAGES
               if run(["dpkg-query", "-W", "-f=${Status}", p]).stdout != "install ok installed"]
    if not missing:
        print(f"{OK}Alle Systempakete vorhanden")
        return

    print(f"        Nachzuinstallieren: {' '.join(missing)}")
    sudo = [] if os.geteuid() == 0 else ["sudo"]
    if sudo and not shutil.which("sudo"):
        print(f"{WARN}kein sudo. Bitte manuell: apt install {' '.join(missing)}")
        return
    print("        (Passwortabfrage möglich)")
    r = subprocess.run(sudo + ["apt-get", "install", "-y"] + missing)
    print(f"{OK}Systempakete installiert" if r.returncode == 0
          else f"{WARN}apt meldete einen Fehler — Installation läuft evtl. trotzdem")


# ---------------------------------------------------------------------------
# 3. venv + Python-Pakete
# ---------------------------------------------------------------------------

def install_python() -> bool:
    hr("3. Virtuelle Umgebung und Pakete")

    if not VENV.exists():
        print(f"        Erstelle {VENV} …")
        r = run([sys.executable, "-m", "venv", str(VENV)])
        if r.returncode != 0:
            print(f"{FAIL}venv fehlgeschlagen:\n{r.stderr}")
            print("        Abhilfe: sudo apt install python3-venv")
            return False
    print(f"{OK}venv unter {VENV}")

    py = str(VENV / "bin" / "python")
    run([py, "-m", "pip", "install", "--upgrade", "pip", "wheel", "--quiet"])

    print("        Installiere Abhängigkeiten (auf dem Pi ein paar Minuten) …")
    t0 = time.time()
    r = subprocess.run([py, "-m", "pip", "install", "-r",
                        str(ROOT / "requirements.txt")])
    if r.returncode != 0:
        print(f"{FAIL}pip fehlgeschlagen. Häufigste Ursache: fehlendes Wheel für "
              "diese Architektur. Dann build-essential und python3-dev nachinstallieren.")
        return False
    print(f"{OK}Pakete installiert ({time.time()-t0:.0f}s)")

    # Versionen ausgeben
    code = (
        "import numpy,pandas,matplotlib,websockets,aiohttp,sqlite3,sys;"
        "print('python  ',sys.version.split()[0]);"
        "print('numpy   ',numpy.__version__);"
        "print('pandas  ',pandas.__version__);"
        "print('mpl     ',matplotlib.__version__);"
        "print('websockets',websockets.__version__);"
        "print('aiohttp ',aiohttp.__version__);"
        "print('sqlite  ',sqlite3.sqlite_version)"
    )
    r = run([py, "-c", code])
    if r.returncode != 0:
        print(f"{FAIL}Importtest fehlgeschlagen:\n{r.stderr}")
        return False
    for line in r.stdout.strip().splitlines():
        print(f"{OK}{line}")
    return True


# ---------------------------------------------------------------------------
# 4. Selbsttest
# ---------------------------------------------------------------------------

def selftest() -> bool:
    hr("4. Selbsttest")
    py = str(venv_python())
    db = ROOT / "_selftest.db"
    png = ROOT / "_selftest.png"
    for f in (db, png):
        f.unlink(missing_ok=True)

    steps = [
        ("Syntax aller Skripte",
         [py, "-m", "compileall", "-q",
          str(ROOT / "hl_recorder.py"), str(ROOT / "hl_viz.py"),
          str(ROOT / "hl_backtest.py"), str(ROOT / "hl_binance.py"),
          str(ROOT / "hl_timestats.py"), str(ROOT / "hl_watchdog.py"),
          str(ROOT / "run_all.py")]),
        ("Datenbank + Simulation",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--simulate"]),
        ("Statusabfrage",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--status"]),
        ("Cluster-Analyse (pandas/numpy)",
         [py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--analyze",
          "--coin", "BTC"]),
        ("Heatmap zeichnen (matplotlib)",
         [py, str(ROOT / "hl_viz.py"), "--db", str(db), "--coin", "BTC",
          "--hours", "48", "--out", str(png)]),
        ("Backtest-Engine",
         [py, str(ROOT / "hl_backtest.py"), "--synthetic"]),
        ("Binance-Parser",
         [py, str(ROOT / "hl_binance.py"), "--selftest"]),
        ("Wächter",
         [py, "-c",
          f"import subprocess,sys,json;"
          f"r=subprocess.run([{py!r},{str(ROOT / 'hl_watchdog.py')!r},"
          f"'--db',{str(db)!r},'--once','--json'],capture_output=True,text=True);"
          f"d=json.loads(r.stdout);"
          f"sys.exit(0 if d.get('checks') else 1)"]),
        ("Zeit-Heatmap",
         [py, str(ROOT / "hl_timestats.py"), "--db", str(db), "--simulate",
          "--years", "1", "--thresholds", "0.01"]),
    ]

    ok = True
    for label, cmd in steps:
        t0 = time.time()
        r = run(cmd)
        if r.returncode == 0:
            print(f"{OK}{label:<34} {time.time()-t0:5.1f}s")
        else:
            print(f"{FAIL}{label}")
            print((r.stderr or r.stdout).strip()[-700:])
            ok = False

    if png.exists() and png.stat().st_size > 10_000:
        print(f"{OK}{'PNG erzeugt':<34} {png.stat().st_size/1024:5.0f} kB")
    else:
        print(f"{FAIL}PNG wurde nicht erzeugt")
        ok = False

    # Dashboard: Server starten und alle Endpunkte abfragen
    import json as _json
    import urllib.request
    proc = subprocess.Popen(
        [py, str(ROOT / "hl_viz.py"), "--db", str(db), "--serve", "--port", "8799"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(3)
        checks = [
            ("/", lambda b: b.startswith(b"<!doctype html")),
            ("/coins", lambda b: isinstance(_json.loads(b), list)),
            ("/data?coin=BTC&hours=6", lambda b: "grid" in _json.loads(b)),
            ("/chart?coin=BTC&agg=5&minutes=720",
             lambda b: len(_json.loads(b).get("candles", [])) > 0),
        ]
        for path, valid in checks:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:8799{path}", timeout=15) as resp:
                    body = resp.read()
                if resp.status == 200 and valid(body):
                    print(f"{OK}{'Dashboard ' + path.split('?')[0]:<34} "
                          f"{len(body)/1024:5.0f} kB")
                else:
                    print(f"{FAIL}Dashboard {path}: unerwartete Antwort "
                          f"({resp.status}, {len(body)} Bytes)")
                    ok = False
            except Exception as e:
                print(f"{FAIL}Dashboard {path}: {e}")
                ok = False
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()

    for f in (db, png, ROOT / f"{db.name}-wal", ROOT / f"{db.name}-shm"):
        f.unlink(missing_ok=True)
    return ok


# ---------------------------------------------------------------------------
# 5. systemd
# ---------------------------------------------------------------------------

RECORDER_UNIT = """[Unit]
Description=Hyperliquid Liquidation Recorder
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_recorder.py --coins BTC ETH HYPE ZEC XMR --db {db}
Restart=always
RestartSec=20
StandardOutput=append:{root}/recorder.log
StandardError=append:{root}/recorder.log

[Install]
WantedBy=multi-user.target
"""

DASH_UNIT = """[Unit]
Description=Hyperliquid Liquidation Dashboard
After=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_viz.py --serve --host 0.0.0.0 --port 8765 --db {db}
Restart=always
RestartSec=20

[Install]
WantedBy=multi-user.target
"""


WATCHDOG_UNIT = """[Unit]
Description=Recorder Watchdog
After=network.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
# Alarmton laeuft ueber die Audioausgabe (HDMI, USB-Audio, DAC-HAT).
# Der Pi 5 hat KEINEN eingebauten Lautsprecher und keine Klinkenbuchse.
# Weitere Optionen nach Bedarf:
#   --led         ACT-LED (der Dienst muss dafuer als root laufen)
#   --ntfy DEIN-TOPIC  --heartbeat https://hc-ping.com/DEINE-UUID
ExecStart={py} {root}/hl_watchdog.py --db {db} --interval 300 --alarm-interval 120
Restart=always
RestartSec=30
StandardOutput=append:{root}/watchdog.log
StandardError=append:{root}/watchdog.log

[Install]
WantedBy=multi-user.target
"""


BNC_UNIT = """[Unit]
Description=Binance Liquidation Stream
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
WorkingDirectory={root}
ExecStart={py} {root}/hl_binance.py --db {db}
Restart=always
RestartSec=20
StandardOutput=append:{root}/binance.log
StandardError=append:{root}/binance.log

[Install]
WantedBy=multi-user.target
"""


def enable_systemd() -> bool:
    """Units nach /etc/systemd/system kopieren und aktivieren."""
    out = ROOT / "systemd"
    units = sorted(out.glob("*.service"))
    if not units:
        print(f"{FAIL}Keine Unit-Dateien gefunden")
        return False
    sudo = [] if os.geteuid() == 0 else ["sudo"]
    if sudo and not shutil.which("sudo"):
        print(f"{WARN}kein sudo — bitte manuell kopieren und aktivieren")
        return False
    names = [u.stem for u in units]
    print("        Installiere Dienste (Passwortabfrage möglich) …")
    steps = [
        sudo + ["cp"] + [str(u) for u in units] + ["/etc/systemd/system/"],
        sudo + ["systemctl", "daemon-reload"],
        sudo + ["systemctl", "enable", "--now"] + names,
    ]
    for cmd in steps:
        if subprocess.run(cmd).returncode != 0:
            print(f"{FAIL}Fehlgeschlagen: {' '.join(cmd)}")
            return False
    print(f"{OK}Aktiviert und gestartet: {', '.join(names)}")
    print(f"{OK}Starten künftig automatisch beim Booten")
    time.sleep(3)
    for n in names:
        r = run(["systemctl", "is-active", n])
        state = r.stdout.strip() or "unbekannt"
        print(f"{OK if state == 'active' else WARN}{n:<22} {state}")
    return True


def setup_systemd(db_path: str) -> None:
    hr("5. systemd-Dienste")
    user = os.environ.get("SUDO_USER") or os.environ.get("USER") or "pi"
    py = str(VENV / "bin" / "python")
    ctx = {"user": user, "root": str(ROOT), "py": py, "db": db_path}

    out = ROOT / "systemd"
    out.mkdir(exist_ok=True)
    (out / "hl-recorder.service").write_text(RECORDER_UNIT.format(**ctx))
    (out / "hl-dashboard.service").write_text(DASH_UNIT.format(**ctx))
    (out / "hl-binance.service").write_text(BNC_UNIT.format(**ctx))
    (out / "hl-watchdog.service").write_text(WATCHDOG_UNIT.format(**ctx))
    print(f"{OK}Unit-Dateien in {out}")
    print("\n        Aktivieren mit:")
    print(f"          sudo cp {out}/*.service /etc/systemd/system/")
    print("          sudo systemctl daemon-reload")
    print("          sudo systemctl enable --now hl-recorder hl-dashboard hl-binance hl-watchdog")
    print("\n        Kontrolle:")
    print("          systemctl status hl-recorder")
    print(f"          tail -f {ROOT}/recorder.log")
    print("\n        Der Dashboard-Dienst lauscht auf 0.0.0.0 ohne Passwort.")
    print("        Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Einrichtung für Raspberry Pi 5 / Trixie")
    p.add_argument("--check", action="store_true", help="nur prüfen")
    p.add_argument("--selftest", action="store_true", help="nur Skripte testen")
    p.add_argument("--no-apt", action="store_true")
    p.add_argument("--systemd", action="store_true",
                   help="Unit-Dateien erzeugen")
    p.add_argument("--enable", action="store_true",
                   help="Unit-Dateien erzeugen UND aktivieren (Autostart)")
    p.add_argument("--db", default=str(ROOT / "hl_liq.db"),
                   help="Pfad der Datenbank für die systemd-Dienste")
    args = p.parse_args()

    print("=" * 62)
    print(" Hyperliquid Liquidations-Recorder — Einrichtung")
    print("=" * 62)

    if args.selftest:
        sys.exit(0 if selftest() else 1)

    problems = check_environment()
    if args.check:
        print("\nNur Prüflauf, nichts verändert.")
        sys.exit(1 if problems else 0)
    if "Python zu alt" in problems or "Projektdateien fehlen" in problems:
        print("\nAbbruch: kritische Voraussetzungen fehlen.")
        sys.exit(1)

    install_apt(args.no_apt)
    if not install_python():
        sys.exit(1)

    ok = selftest()
    if args.systemd or args.enable:
        setup_systemd(args.db)
        if args.enable:
            enable_systemd()

    hr("Ergebnis")
    if ok:
        print(f"{OK}Alles funktioniert.\n")
        print("        Alles auf einmal starten (Vordergrund):")
        print(f"          {VENV}/bin/python run_all.py --host 0.0.0.0")
        print("\n        Dauerbetrieb mit Autostart beim Booten:")
        print("          python3 install.py --enable")
        print("\n        Der Recorder braucht Wochen, bis die Daten aussagekräftig sind.")
    else:
        print(f"{FAIL}Selbsttest fehlgeschlagen — Ausgaben oben prüfen.")
        sys.exit(1)


if __name__ == "__main__":
    main()
