#!/usr/bin/env python3
"""
hl_makro.py -- Makro-Chart (U121, Version 2026-09-23.47): Wo steht der Markt im mittel- und langfristigen Zyklus?

Grundlage: RECHERCHE_Makro_Chart_05-10-2026.md (Bericht „Kostenbasis verortet den Zyklus, feste Schwellen versagen“) und
KONZEPT_Makro.md. Gebaut wird alles aus Stufe 1 und Stufe 2, was KOSTENLOS ist, jeder Treiber mit eigenem Chart, dazu die
Miner-Kostenbasis (Szenario Antminer S21 XP, 13,5 J/TH, 7,5 ct/kWh) auf Wunsch des Nutzers (05.10.2026).

Regeln aus dem Bericht, hier fest eingebaut:
  * POSITIONEN STATT SIGNALE: Perzentile der eigenen Historie, Bänder, Regimelinien. Keine festen Schwellen aus 2013-2021
    (MVRV 3,7/1, NUPL 0,75/0, Puell 4/0,5 ...): 2025/26 oben und unten verfehlt (Amplitudenkompression).
  * KAUSAL: Jede Zeitreihe, die einen Rang oder eine Anpassung enthält (Perzentile, Power Law, MVRV-Z, AVIV-z), nutzt am
    Tag t nur Daten bis t. Der Selbsttest hängt extreme Zukunftsdaten an und verlangt die Vergangenheit bitgleich.
  * EINE QUELLE JE REIHE, Methodik offen, Abrufe archiviert (makro.db wächst; Fenster wie BGeometrics 4 Jahre oder der
    FRED-Hochzinsspread 3 Jahre verschwinden sonst).
  * MAKRO NUR ALS KULISSE: Liquidität, Zinsen, Dollar mit rollierender Korrelation zu BTC und Regimelabel, kein
    verschobener M2-Lag.

Eigene Datenbank makro.db NEBEN der Hauptdatenbank (Wunsch des Nutzers: Entlastung von hl_liq.db). Geschrieben wird nur
hier, im Makro-Takt des Dashboards (ein Thread, ein Schreiber, jede Transaktion mit BEGIN IMMEDIATE); das Dashboard liest
nur. Die Hauptdatenbank wird nur gelesen (Live-Kurs aus bars, ETF-Flüsse nicht -- die kommen eigenständig von Farside).

Quellen (alle frei; Lizenzen in QUELLEN_TEXT, Anzeige unter jedem Chart):
  Coin Metrics Community API   Kurs, Marktkap., MVRV, Angebot, Emission, Gebühren, Blöcke, Hashrate (BTC, ETH, ZEC, XMR)
  FRED (fredgraph.csv)         Fed-Bilanz, TGA, Reverse Repo, M2, Realzins, Dollar, Hochzinsspread, Leitzins, EZB, BoJ, FX;
                               seit 23.67 (U153) Arbeitslosenquote, Stellen, Erstanträge, Verbraucher- und Erzeugerpreise mit
                               Fassungen (mk_fassung), Erstveröffentlichungen aus ALFRED und Veröffentlichungsterminen (mk_termin)
  alternative.me               Fear & Greed Index
  DefiLlama                    Stablecoin-Angebot
  Blockchain.com               Difficulty (Miner-Kosten, Difficulty Ribbon), Hashrate als Gegenprobe
  Deribit                      DVOL (implizite Volatilität BTC)
  Binance                      Funding (BTCUSDT, Tagessumme), Open Interest (30 Tage REST, Archiv ab 2020 per data.binance.vision)
  Farside                      ETF-Nettoflüsse BTC und ETH seit Januar 2024
  BGeometrics (bitcoin-data)   Kurzfrist-/Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV,
                               realisierte Verluste -- frei: 15 Abrufe/Tag, 8/Stunde, letzte 4 Jahre (Budget hier 14 und 7)

Seit 23.127 (U316): Abruf nach Bekanntgabe -- an den Terminen der Behörden (FRED fred/release/dates) holt der Takt die Reihe ab 5 min nach
der Uhrzeit alle 5 min, bis die neue Zahl da ist; Fed-Entscheid über den Feed und die Erklärung der Fed (Zielspanne, vorläufig bis FRED
sie am Morgen danach führt). Der 12-h-Takt bleibt.

Debug: python3 hl_makro.py --stand --db PFAD · --abrufen --db PFAD [--quelle cm] · --selbsttest · --termine --db PFAD (Debug 168) ·
       --selbsttest-termine (Debug 169)
"""
from __future__ import annotations

import bisect
import csv
import io
import json
import math
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone

import numpy as np

VERSION = 1
NAME = "Makro-Chart"
TAG = 86_400
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0 (makro)"}
GENESIS_TAG = 14_247                                    # 2009-01-03 in Tagen seit 1970 (Genesis-Block)
HALVINGS = ("2012-11-28", "2016-07-09", "2020-05-11", "2024-04-20")
CM_BASIS = "https://community-api.coinmetrics.io/v4"
CM_METRIKEN = {
    "btc": ("PriceUSD", "CapMrktCurUSD", "CapMVRVCur", "SplyCur", "HashRate", "IssTotNtv", "IssTotUSD", "FeeTotNtv", "BlkCnt"),
    "eth": ("PriceUSD", "CapMrktCurUSD", "CapMVRVCur", "SplyCur"),
    "zec": ("PriceUSD", "CapMrktCurUSD", "CapMVRVCur", "SplyCur"),
    "xmr": ("PriceUSD", "CapMrktCurUSD", "SplyCur"),
}
FRED = {
    "WALCL": "Fed-Bilanz (Mio USD, wöchentlich)",
    "WTREGEN": "Schatzamtskonto TGA (Mio USD, Wochenmittel)",
    "RRPONTSYD": "Reverse Repo (Mrd USD, täglich)",
    "M2SL": "US-Geldmenge M2 (Mrd USD, monatlich)",
    "DFII10": "Realzins 10 Jahre (%, täglich)",
    "DTWEXBGS": "Dollar breit (Index, täglich)",
    "BAMLH0A0HYM2": "Hochzinsspread ICE BofA (%, täglich, nur 3 Jahre)",
    "DFF": "Leitzins effektiv (%, täglich)",
    "ECBASSETSW": "EZB-Bilanz (Mio EUR, wöchentlich)",
    "JPNASSETS": "BoJ-Bilanz (100 Mio JPY, monatlich)",
    "DEXUSEU": "USD je EUR (täglich)",
    "DEXJPUS": "JPY je USD (täglich)",
    # 23.127 (U316): Zielspanne der Fed für den Chart „Leitzins“ (FRED, Release „FOMC Press Release“; gültig ab dem Tag nach dem Entscheid)
    "DFEDTARU": "Zielspanne der Fed, obere Grenze (%, täglich)",
    "DFEDTARL": "Zielspanne der Fed, untere Grenze (%, täglich)",
    # 23.67 (U153, Entscheidung des Nutzers 11.10.): Arbeitsmarkt und Preise der USA -- nur Anzeige, mit Fassungen (mk_fassung)
    "UNRATE": "Arbeitslosenquote (%, monatlich)",
    "PAYEMS": "Stellen außerhalb der Landwirtschaft (Tsd., monatlich)",
    "ICSA": "Erstanträge auf Arbeitslosenhilfe (wöchentlich, Woche bis Samstag)",
    "CPIAUCNS": "Verbraucherpreise gesamt, nicht bereinigt (Index)",
    "CPILFENS": "Verbraucherpreise ohne Lebensmittel und Energie, nicht bereinigt (Index)",
    "PPIFID": "Erzeugerpreise Endnachfrage, nicht bereinigt (Index)",
    "CPIAUCSL": "Verbraucherpreise gesamt, bereinigt (Index)",
    "CPILFESL": "Verbraucherpreise ohne Lebensmittel und Energie, bereinigt (Index)",
    "PPIFIS": "Erzeugerpreise Endnachfrage, bereinigt (Index)",
}
FRED_USA = ("UNRATE", "PAYEMS", "ICSA", "CPIAUCNS", "CPILFENS", "PPIFID", "CPIAUCSL", "CPILFESL", "PPIFIS")
# Termine (U153): die Veröffentlichung, zu der die Reihe gehört, gibt den Termin; alle vier um 8:30 New York. Die Nummer der
# Veröffentlichung kommt aus fred/series/release (nicht von Hand), gemerkt in mk_meta „release:<Reihe>“.
USA_TERMIN_REIHEN = {"UNRATE": "Arbeitsmarktbericht", "ICSA": "Erstanträge", "CPIAUCSL": "Verbraucherpreise", "PPIFIS": "Erzeugerpreise"}
FRED_SERIES_RELEASE = "https://api.stlouisfed.org/fred/series/release"
FRED_RELEASE_DATES = "https://api.stlouisfed.org/fred/release/dates"
ALFRED_ZEITRAUM = ("1776-07-04", "9999-12-31")          # FRED-Konvention für „alle Fassungen“ (frühester/spätester Echtzeitpunkt)
TERMINE_AB = "2019-01-01"                               # Termine ab hier (für U154 ab 2020 nötig)
USA_LUECKE = {"2025-10": "nicht erhoben (Stillstand der US-Regierung 01.10.–12.11.2025)"}
BGM_BASIS = "https://bitcoin-data.com/v1/"
BGM = ("sth-realized-price", "true-market-mean", "lth-realized-price", "sth-mvrv", "lth-sopr", "asopr", "aviv", "realized-loss")
BGM_JE_STUNDE = 7                                       # frei: 8 je Stunde -- eine Reserve
BGM_JE_TAG = 14                                         # frei: 15 je Tag
BGM_ABSTAND_S = 8 * 60
FARSIDE = {"btc": "https://farside.co.uk/bitcoin-etf-flow-all-data/", "eth": "https://farside.co.uk/ethereum-etf-flow-all-data/"}
OI_ARCHIV_START = "2020-09-01"
OI_ARCHIV_URL = "https://data.binance.vision/data/futures/um/daily/metrics/BTCUSDT/BTCUSDT-metrics-{tag}.zip"
PAUSE_S = 1.0
MVRV_ANLAUF_TAGE = 180                                  # erstes halbes Jahr einer MVRV-Reihe: Anlauf der realisierten Kapitalisierung (BTC: 146 am 18.07.2010)
START_VERZUG_S = 90
TAKT_S = 20
NEU_RECHNEN_S = 600                                     # Dashboard-Zwischenspeicher: höchstens alle 10 min neu rechnen
MINER_GERAETE = (("s21xp", "Antminer S21 XP (Luft) 13,5 J/TH", 13.5), ("s21xph", "Antminer S21 XP Hydro 12 J/TH", 12.0),
                 ("s21pro", "Antminer S21 Pro 15 J/TH", 15.0), ("s21", "Antminer S21 17,5 J/TH", 17.5),
                 ("s19xp", "Antminer S19 XP 21,5 J/TH", 21.5), ("s19jpro", "Antminer S19j Pro 29,5 J/TH", 29.5))
MINER_STANDARD = {"geraet": "s21xp", "jth": 13.5, "ct": 7.5, "waehrung": "USD", "aufschlag": 0.0}

QUELLEN_TEXT = {
    "cm": "Coin Metrics Community (CC BY-NC 4.0)",
    "fred": "FRED, Federal Reserve Bank of St. Louis",
    "fred_hy": "ICE BofA über FRED -- nur private Anzeige, keine Weitergabe",
    "fng": "Fear & Greed Index: alternative.me",
    "llama": "DefiLlama",
    "bc": "Blockchain.com",
    "drb": "Deribit DVOL",
    "bnc": "Binance (BTCUSDT-Perp)",
    "farside": "Farside Investors (privat)",
    "bgm": "BGeometrics, bitcoin-data.com (frei: letzte 4 Jahre ohne die jüngsten 7 Tage)",
    "fred_usa": "FRED (BLS; Erstanträge: U.S. Employment and Training Administration)",
    "fred1": "ALFRED (Archiv der Erstveröffentlichungen, Federal Reserve Bank of St. Louis)",
    "fredtermin": "FRED-Veröffentlichungstermine (Termine der Behörden)",
    "fed": "Federal Reserve Board (Erklärungen des FOMC; gemeinfrei)",
}
BGM_VERZUG_TAGE = 7                                     # frei: Echtzeit (letzte 7 Tage) nur im Abo

# FRED (23.48): fredgraph.csv ohne Schlüssel antwortet vom Pi nicht (05.10.: alle 12 Reihen „The read operation timed out“ nach je
# 45 s); seit Mitte August 2026 auch anderswo beobachtet (Verbindung offen, Antwort kommt nie). Der offizielle Weg ist die API mit
# kostenlosem Schlüssel (32 Zeichen, a-z0-9, fredaccount.stlouisfed.org/apikeys). Schlüssel: Umgebungsvariable FRED_API_KEY oder
# accesstokens.json -> "fred" -> "api_key" (update.py überschreibt die Datei nie). Ohne Schlüssel bleibt fredgraph.csv als Versuch.
FRED_API = "https://api.stlouisfed.org/fred/series/observations"
FRED_SCHLUESSEL_SEITE = "https://fredaccount.stlouisfed.org/apikeys"
TOKENS_DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
FRED_TIMEOUT_CSV = 15
FRED_TIMEOUT_API = 20

# Frische je Reihe (Abnahme U121): höchstes Alter des letzten Werts in Tagen (heute UTC minus letzter Tag). Verschwindet eine
# Metrik aus dem freien Katalog oder ändert eine Seite ihr Format, scheitert oft kein Abruf -- die Reihe bleibt nur stehen; das
# zeigt allein ihr Alter. Grenzen großzügig: Coin-Metrics-Bewertung erst bei T−2, Wochenenden, Feiertage, FRED-Wechselkurse und
# Dollarindex wöchentlich veröffentlicht (H.10), Fed-Bilanz und TGA wöchentlich (H.4.1), M2 und BoJ monatlich mit rund vier
# Wochen Verzug und auf den Monatsersten datiert.
# 23.48: BGeometrics 9 statt 6 -- die freie API liefert die jüngsten 7 Tage nicht („delayed“: „Real-time data (last 7 days)
# requires an active subscription“, am 05.10. an /v1/sth-realized-price/last gelesen); der Pi zeigte deshalb Fehlalarme (7 T > 6).
FRISCHE_TAGE = {"cm": 5, "fng": 4, "llama": 4, "bc": 5, "drb": 4, "bnc": 4, "fs": 7, "bgm": 9, "fred": 10}
FRISCHE_FRED = {"DTWEXBGS": 14, "DEXUSEU": 14, "DEXJPUS": 14, "WALCL": 14, "WTREGEN": 14, "ECBASSETSW": 21, "M2SL": 100, "JPNASSETS": 100,
                # 23.67 (U153): Monatsreihen auf den Ersten datiert, vor dem nächsten Termin rund 65–75 Tage alt (wie M2);
                # Erstanträge: Woche bis Samstag, Veröffentlichung 5 Tage später, dazu Feiertage (wie STLFSI4)
                "UNRATE": 100, "PAYEMS": 100, "CPIAUCNS": 100, "CPILFENS": 100, "PPIFID": 100, "CPIAUCSL": 100, "CPILFESL": 100,
                "PPIFIS": 100, "ICSA": 16}


def frische_grenze(reihe: str) -> int | None:
    """Höchstes erlaubtes Alter des letzten Werts in Tagen; None = ohne Grenze (unbekannte Quelle)."""
    quelle, _, rest = reihe.partition(":")
    if quelle == "fred":
        return FRISCHE_FRED.get(rest, FRISCHE_TAGE["fred"])
    return FRISCHE_TAGE.get(quelle)


def erwartete_reihen(quelle: str, ziel: str) -> tuple:
    """Reihen, die ein erfolgreicher Abruf dieses Ziels liefern muss (BGeometrics: Präfix, irgendein Feld)."""
    if quelle == "cm":
        return tuple(f"cm:{ziel}:{m}" for m in CM_METRIKEN.get(ziel, ()))
    return {"fred": (f"fred:{ziel}",), "fng": ("fng:wert",), "llama": ("llama:stable_usd",),
            "bc": ("bc:difficulty",) if ziel == "difficulty" else ("bc:hashrate",), "drb": (f"drb:dvol_{ziel.lower()}",),
            "bnc": ("bnc:funding_btc_tag", "bnc:funding_btc_n") if ziel == "funding" else ("bnc:oi_btc_usd", "bnc:oi_btc_coins"),
            "farside": (f"fs:etf_{ziel}",), "bgm": (f"bgm:{ziel}:",)}.get(quelle, ())


# ================================================================================================ Zeit und Zahlen

def tag_ts(s: str) -> int | None:
    """'JJJJ-MM-TT' -> Mitternacht UTC in Sekunden."""
    try:
        return int(datetime(int(s[0:4]), int(s[5:7]), int(s[8:10]), tzinfo=timezone.utc).timestamp())
    except (ValueError, TypeError, IndexError):
        return None


def ts_tag(ts) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(int(ts)))


def _wert(v) -> float | None:
    """Zahl aus Text oder Zahl; '', '.', None, NaN -> None."""
    if v is None or isinstance(v, bool):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _ganz(v) -> int | None:
    x = _wert(v)
    return int(x) if x is not None else None


def _sek(v) -> int | None:
    """Zeitstempel in Sekunden; Millisekunden (> 1e11) werden erkannt (Projektregel 1)."""
    x = _ganz(v)
    if x is None or x <= 0:
        return None
    return x // 1000 if x > 100_000_000_000 else x


def _zahl(x, d: int = 2) -> str:
    return "—" if x is None or not math.isfinite(x) else f"{x:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


# ================================================================================================ Datenbank

SCHEMA = """
CREATE TABLE IF NOT EXISTS mk_reihe (reihe TEXT NOT NULL, ts INTEGER NOT NULL, wert REAL, abgerufen INTEGER,
    PRIMARY KEY (reihe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_abruf (ts INTEGER, quelle TEXT, ziel TEXT, ok INTEGER, zeilen INTEGER, ms INTEGER, fehler TEXT);
CREATE INDEX IF NOT EXISTS ix_mk_abruf ON mk_abruf(quelle, ts);
CREATE TABLE IF NOT EXISTS mk_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS mk_stand (tag TEXT NOT NULL, kennzahl TEXT NOT NULL, wert REAL, berechnet INTEGER,
    PRIMARY KEY (tag, kennzahl)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_pl (monat TEXT PRIMARY KEY, a REAL, b REAL, sd REAL, n INTEGER, berechnet INTEGER);
CREATE TABLE IF NOT EXISTS mk_signal (tag TEXT NOT NULL, paar TEXT NOT NULL, fenster TEXT NOT NULL, signal TEXT, pz REAL, abweichung REAL,
    median REAL, prognose_365 REAL, berechnet INTEGER, PRIMARY KEY (tag, paar, fenster)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_fassung (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, wert REAL, art TEXT,
    PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_termin (release INTEGER NOT NULL, tag INTEGER NOT NULL, abgerufen INTEGER, PRIMARY KEY (release, tag)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_terminabruf (reihe TEXT NOT NULL, termin INTEGER NOT NULL, versuche INTEGER, erster INTEGER, letzter INTEGER,
    da INTEGER, wie TEXT, PRIMARY KEY (reihe, termin)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mk_fed (tag INTEGER NOT NULL, link TEXT NOT NULL, titel TEXT, pub INTEGER, abgerufen INTEGER, quelle TEXT,
    aktion TEXT, schritt REAL, unten REAL, oben REAL, wirksam INTEGER, fehler TEXT, PRIMARY KEY (tag, link)) WITHOUT ROWID;
"""


def makro_pfad(db: str) -> str:
    """makro.db liegt neben der Hauptdatenbank (wie forecasts.db und adressfluss.db); HL_MAKRO_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_MAKRO_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "makro.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung (nur der Makro-Takt und --abrufen). Autocommit; jede Schreibtransaktion beginnt mit BEGIN IMMEDIATE."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def lesen(pfad: str) -> sqlite3.Connection | None:
    """Nur lesen; legt NICHTS an (eine fehlende Datei bleibt fehlend -- wichtig für Selbsttest-Instanzen)."""
    if not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, check_same_thread=False)


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM mk_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def _meta_setzen(con, paare: dict) -> None:
    """In einer EIGENEN Transaktion (BEGIN IMMEDIATE)."""
    con.execute("BEGIN IMMEDIATE")
    try:
        con.executemany("INSERT INTO mk_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                        [(k, str(v)) for k, v in paare.items()])
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise


def schreiben(con, zeilen: list, jetzt: int | None = None) -> int:
    """
    Zeilen (reihe, ts, wert) einfügen oder ändern -- nur wenn der Wert sich ändert (Revisionen bekommen einen neuen
    Abrufzeitpunkt, gleiche Werte bleiben unberührt). Liefert die Zahl neuer oder geänderter Zeilen; zählt die
    Datenversion hoch, wenn etwas neu ist. Eine Transaktion, BEGIN IMMEDIATE (Projektregel seit 23.41).
    """
    if not zeilen:
        return 0
    jetzt = int(jetzt if jetzt is not None else time.time())
    daten = [(str(r), int(t), float(w), jetzt) for r, t, w in zeilen if w is not None and math.isfinite(w)]
    con.execute("BEGIN IMMEDIATE")
    try:
        vorher = con.total_changes
        con.executemany("INSERT INTO mk_reihe(reihe, ts, wert, abgerufen) VALUES (?,?,?,?) "
                        "ON CONFLICT(reihe, ts) DO UPDATE SET wert=excluded.wert, abgerufen=excluded.abgerufen "
                        "WHERE mk_reihe.wert IS NOT excluded.wert", daten)
        neu = con.total_changes - vorher
        if neu:
            v = int(meta(con, "version", "0") or 0) + 1
            con.execute("INSERT INTO mk_meta VALUES ('version', ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (str(v),))
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return neu


def fassungen_schreiben(con, zeilen: list, jetzt: int | None = None, art: str = "abruf") -> int:
    """
    23.67 (U153): Fassungen der Reihen aus FRED_USA. `mk_reihe` überschreibt einen geänderten Wert (Schlüssel reihe, ts); hier
    bekommt jede neue oder geänderte Zahl eine eigene Zeile mit Abrufzeit -- gleiche Werte keine (wie `ak_wert` in aktien.db).
    Zeilen (reihe, ts, wert); art „abruf“ (eigener Abruf) oder „erst“ (Erstveröffentlichung aus ALFRED, siehe erst_schreiben).
    """
    jetzt = int(jetzt if jetzt is not None else time.time())
    daten = [(str(rr), int(t), float(w)) for rr, t, w in zeilen if w is not None and math.isfinite(w)]
    if not daten:
        return 0
    letzt = {}
    for rr in sorted({x[0] for x in daten}):
        for t, w in con.execute("SELECT f.ts, f.wert FROM mk_fassung f JOIN (SELECT ts, MAX(abgerufen) AS m FROM mk_fassung WHERE reihe=? "
                                "GROUP BY ts) j ON f.ts = j.ts AND f.abgerufen = j.m WHERE f.reihe=?", (rr, rr)):
            letzt[(rr, int(t))] = w
    neu = [(rr, t, jetzt, w, art) for rr, t, w in daten if letzt.get((rr, t)) != w]
    if not neu:
        return 0
    con.execute("BEGIN IMMEDIATE")
    try:
        con.executemany("INSERT OR IGNORE INTO mk_fassung VALUES (?,?,?,?,?)", neu)
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return len(neu)


def erst_schreiben(con, zeilen: list) -> int:
    """23.67 (U153): Erstveröffentlichungen aus ALFRED (reihe, ts, veröffentlicht, wert) als Fassung „erst“ mit dem Zeitpunkt der
    Veröffentlichung (8:30 New York des Tags). Schon vorhandene Zeilen bleiben (INSERT OR IGNORE)."""
    daten = [(str(rr), int(t), int(v), float(w), "erst") for rr, t, v, w in zeilen if w is not None and math.isfinite(w)]
    if not daten:
        return 0
    con.execute("BEGIN IMMEDIATE")
    try:
        vorher = con.total_changes
        con.executemany("INSERT OR IGNORE INTO mk_fassung VALUES (?,?,?,?,?)", daten)
        n = con.total_changes - vorher
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return n


def termine_schreiben(con, release: int, tage: list, jetzt: int | None = None) -> int:
    """23.67 (U153): Termine einer Veröffentlichung (UTC-Mitternacht des Tags). Vergangene bleiben; künftige, die in der neuen
    Antwort fehlen (verschoben), fallen weg. -> Zahl neuer Termine."""
    jetzt = int(jetzt if jetzt is not None else time.time())
    heute = jetzt // TAG * TAG
    neu_set = {int(t) for t in tage}
    con.execute("BEGIN IMMEDIATE")
    try:
        alt = {int(t) for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=?", (int(release),))}
        weg = [t for t in alt if t >= heute and t not in neu_set]
        con.executemany("DELETE FROM mk_termin WHERE release=? AND tag=?", [(int(release), t) for t in weg])
        con.executemany("INSERT OR IGNORE INTO mk_termin VALUES (?,?,?)", [(int(release), t, jetzt) for t in sorted(neu_set - alt)])
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return len(neu_set - alt)


def ny830_utc(tag: int) -> int:
    """8:30 New York am Kalendertag `tag` (UTC-Mitternacht in Sekunden) -> Unix-Zeit (Sommer-/Winterzeit richtig)."""
    from zoneinfo import ZoneInfo
    d = datetime.fromtimestamp(int(tag), timezone.utc).date()
    return int(datetime(d.year, d.month, d.day, 8, 30, tzinfo=ZoneInfo("America/New_York")).timestamp())


def protokoll(con, quelle: str, ziel: str, ok: bool, zeilen: int, ms: int, fehler: str = "") -> None:
    con.execute("BEGIN IMMEDIATE")
    try:
        con.execute("INSERT INTO mk_abruf VALUES (?,?,?,?,?,?,?)", (int(time.time()), quelle, ziel, int(bool(ok)), int(zeilen),
                                                                    int(ms), (fehler or "")[:240]))
        con.execute("DELETE FROM mk_abruf WHERE ts < ?", (int(time.time()) - 90 * TAG,))
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise


def letzter_tag(con, reihe: str) -> int | None:
    r = con.execute("SELECT MAX(ts) FROM mk_reihe WHERE reihe=?", (reihe,)).fetchone()
    return int(r[0]) if r and r[0] is not None else None


# ================================================================================================ Netz

def http(url: str, timeout: int = 30, art: str = "json"):
    """(Inhalt, Fehlertext) -- wirft nie. art: json | text | bytes."""
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            roh = r.read()
    except urllib.error.HTTPError as e:
        try:
            rest = e.read()[:160].decode("utf-8", "replace")
        except Exception:
            rest = ""
        return None, f"HTTP {e.code}: {rest}".strip()
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"
    if art == "bytes":
        return roh, None
    text = roh.decode("utf-8", "replace")
    if art == "text":
        return text, None
    try:
        return json.loads(text), None
    except ValueError:
        return None, "kein JSON: " + text[:80].replace("\n", " ")


# ================================================================================================ Parser (reine Funktionen)

def cm_url(asset: str, metriken, start: str | None = None) -> str:
    q = {"assets": asset, "metrics": ",".join(metriken), "frequency": "1d", "page_size": "10000", "paging_from": "start"}
    if start:
        q["start_time"] = start
    return f"{CM_BASIS}/timeseries/asset-metrics?" + urllib.parse.urlencode(q, safe=",")


def cm_parse(d) -> tuple:
    """Coin Metrics v4: {"data":[{"asset","time","PriceUSD":"..."}], "next_page_url"}. Fehlende Metriken fehlen als Schlüssel."""
    zeilen = []
    for z in (d or {}).get("data") or [] if isinstance(d, dict) else []:
        if not isinstance(z, dict):
            continue
        asset = str(z.get("asset", "")).lower()
        t = tag_ts(str(z.get("time", ""))[:10])
        if not asset or t is None:
            continue
        for k, v in z.items():
            if k in ("asset", "time"):
                continue
            w = _wert(v)
            if w is not None:
                zeilen.append((f"cm:{asset}:{k}", t, w))
    return zeilen, (d.get("next_page_url") if isinstance(d, dict) else None)


def fred_url(sid: str, start: str) -> str:
    return f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={sid}&cosd={start}"


def fred_parse(sid: str, text: str) -> list:
    """fredgraph.csv: Kopf 'observation_date,ID' (früher 'DATE,ID'); fehlende Werte '' oder '.'."""
    zeilen = []
    for z in csv.reader(io.StringIO(text or "")):
        if len(z) < 2:
            continue
        t = tag_ts(z[0].strip()[:10])
        w = _wert(z[1].strip())
        if t is not None and w is not None:
            zeilen.append((f"fred:{sid}", t, w))
    return zeilen


def fred_api_url(sid: str, start: str, schluessel: str) -> str:
    q = {"series_id": sid, "api_key": schluessel, "file_type": "json", "observation_start": start}
    return FRED_API + "?" + urllib.parse.urlencode(q)


def fred_api_parse(sid: str, d) -> list:
    """FRED-API (JSON): {"observations": [{"date": "2026-10-01", "value": "6650000.0", ...}]}; fehlende Werte '.'."""
    zeilen = []
    for o in (d.get("observations") or []) if isinstance(d, dict) else []:
        if not isinstance(o, dict):
            continue
        t = tag_ts(str(o.get("date") or "")[:10])
        w = _wert(o.get("value"))
        if t is not None and w is not None:
            zeilen.append((f"fred:{sid}", t, w))
    return zeilen


def alfred_url(sid: str, schluessel: str, start: str = "2008-01-01") -> str:
    """23.67 (U153): Erstveröffentlichung je Beobachtung (output_type 4 „Initial Release Only“) über den ganzen Echtzeitraum."""
    q = {"series_id": sid, "api_key": schluessel, "file_type": "json", "observation_start": start,
         "realtime_start": ALFRED_ZEITRAUM[0], "realtime_end": ALFRED_ZEITRAUM[1], "output_type": "4"}
    return FRED_API + "?" + urllib.parse.urlencode(q)


def alfred_erst_parse(sid: str, d) -> list:
    """ALFRED (output_type 4): {"observations": [{"realtime_start", "realtime_end", "date", "value"}]} -> (reihe, ts, veröffentlicht, wert);
    veröffentlicht = 8:30 New York am Tag realtime_start; fehlende Werte '.' fallen weg."""
    if not isinstance(d, dict) or not isinstance(d.get("observations"), list):
        raise ValueError("unerwartetes Format (ALFRED)")
    out = []
    for o in d["observations"]:
        if not isinstance(o, dict):
            continue
        t, rt, w = tag_ts(str(o.get("date") or "")), tag_ts(str(o.get("realtime_start") or "")), _wert(o.get("value"))
        if t is None or rt is None or w is None:
            continue
        out.append((f"fred:{sid}", t, ny830_utc(rt), w))
    return out


def series_release_url(sid: str, schluessel: str) -> str:
    return FRED_SERIES_RELEASE + "?" + urllib.parse.urlencode({"series_id": sid, "api_key": schluessel, "file_type": "json"})


def series_release_parse(d) -> tuple:
    """fred/series/release: {"releases": [{"id": 10, "name": "Consumer Price Index", ...}]} -> (id, Name)."""
    rel = d.get("releases") if isinstance(d, dict) else None
    if not isinstance(rel, list) or not rel or not isinstance(rel[0], dict) or _ganz(rel[0].get("id")) is None:
        raise ValueError("unerwartetes Format (series/release)")
    return int(_ganz(rel[0]["id"])), str(rel[0].get("name") or "")


def release_dates_url(release: int, schluessel: str, ab: str | None = None) -> str:
    """Alle Termine ab TERMINE_AB (23.127: oder ab `ab`), auch künftige (include_release_dates_with_no_data, sonst fehlen sie)."""
    q = {"release_id": int(release), "api_key": schluessel, "file_type": "json", "realtime_start": ab or TERMINE_AB, "realtime_end": "9999-12-31",
         "include_release_dates_with_no_data": "true", "sort_order": "asc", "limit": "10000"}
    return FRED_RELEASE_DATES + "?" + urllib.parse.urlencode(q)


def release_dates_parse(d) -> list:
    """fred/release/dates: {"release_dates": [{"release_id": 10, "date": "2026-10-14"}, ...]} -> sortierte UTC-Mitternächte."""
    rd = d.get("release_dates") if isinstance(d, dict) else None
    if not isinstance(rd, list):
        raise ValueError("unerwartetes Format (release/dates)")
    return sorted({t for e in rd if isinstance(e, dict) for t in [tag_ts(str(e.get("date") or ""))] if t is not None})


def fred_schluessel_lesen(datei: str | None = None) -> str:
    """Kostenloser FRED-API-Schlüssel: Umgebungsvariable FRED_API_KEY, sonst accesstokens.json -> "fred" -> "api_key"; sonst ""."""
    k = (os.environ.get("FRED_API_KEY") or "").strip()
    if k:
        return k
    datei = datei or TOKENS_DATEI                                         # zur Laufzeit (Selbsttest lenkt um)
    try:
        with open(datei, encoding="utf-8") as f:
            d = json.load(f)
        return str((d.get("fred") or {}).get("api_key") or "").strip()
    except (OSError, ValueError, AttributeError):
        return ""


def _geschwaerzt(text: str, schluessel: str) -> str:
    """Der Schlüssel erscheint nie in Fehlertexten, Protokoll oder Anzeige."""
    text = str(text or "")
    if schluessel:
        text = text.replace(schluessel, "***")
    return re.sub(r"(api_key=)[^&\s\"']+", r"\1***", text)


def _netzfehler(text: str) -> bool:
    """Keine HTTP-Antwort: Zeitüberschreitung oder Verbindungsfehler -- der Host antwortet nicht (Abbruch je Quelle und Runde)."""
    t = str(text or "")
    if re.search(r"\bHTTP \d{3}\b", t):
        return False
    t = t.lower()
    return any(s in t for s in ("timed out", "timeout", "urlerror", "connection", "remotedisconnected", "ssl", "name or service",
                                "temporary failure", "network is unreachable", "no route to host"))


def fred_schluessel_einrichten(schluessel: str, makro_db: str | None = None, datei: str | None = None, http_fn=None) -> tuple:
    """
    -> (ok, Meldung). Für --fred-schluessel und das Feld im Tab „Daten“ (POST /makro/fred_schluessel): Schlüssel prüfen
    (Format, ein Probeabruf), in accesstokens.json eintragen (übrige Einträge bleiben, Datei wird atomar ersetzt) und die
    FRED-Pausen in makro.db zurücksetzen, damit der Takt sofort abruft. Ein vom Server abgelehnter Schlüssel wird nicht
    geschrieben; bei einem Netzfehler im Probeabruf wird er mit Warnung geschrieben. Der Schlüssel steht nie in der Meldung.
    """
    datei = datei or TOKENS_DATEI
    k = (schluessel or "").strip()
    if not re.fullmatch(r"[a-z0-9]{32}", k):
        return False, f"FRED-Schlüssel ungültig: erwartet 32 Zeichen a-z und 0-9 (bekommen: {len(k)} Zeichen). Nichts geschrieben."
    maske = k[:4] + "…" + k[-2:]
    start = ts_tag(time.time() - 14 * TAG)
    d, err = (http_fn or http)(fred_api_url("DFF", start, k), timeout=FRED_TIMEOUT_API, art="json")
    if err and not _netzfehler(err):
        return False, f"FRED lehnt den Schlüssel {maske} ab: {_geschwaerzt(err, k)[:160]}. Nichts geschrieben."
    n = len(fred_api_parse("DFF", d)) if not err else 0
    if not err and not n:
        return False, f"FRED-Probeabruf mit {maske} ohne Werte: {_geschwaerzt(json.dumps(d)[:120], k)}. Nichts geschrieben."
    roh: dict = {}
    if os.path.exists(datei):
        try:
            with open(datei, encoding="utf-8") as f:
                roh = json.load(f)
        except ValueError as e:
            return False, f"{os.path.basename(datei)} ist kein gültiges JSON ({e}) -- nichts überschrieben. Bitte die Datei prüfen."
        if not isinstance(roh, dict):
            return False, f"{os.path.basename(datei)} hat kein JSON-Objekt -- nichts überschrieben."
    eintrag = roh.get("fred") if isinstance(roh.get("fred"), dict) else {}
    eintrag["api_key"] = k
    eintrag.setdefault("_wofuer", "FRED-Makroreihen im Makro-Chart (api.stlouisfed.org; kostenloser Schlüssel: " + FRED_SCHLUESSEL_SEITE + ")")
    roh["fred"] = eintrag
    tmp = datei + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(roh, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, datei)
    z = [f"FRED-Schlüssel {maske} in {os.path.basename(datei)} eingetragen. Probeabruf: "
         + (f"{n} Werte des Leitzinses (DFF) seit {start}." if not err else f"Netzfehler ({_geschwaerzt(err, k)[:100]}) -- Schlüssel trotzdem gespeichert.")]
    if (os.environ.get("FRED_API_KEY") or "").strip():
        z.append("Hinweis: Die Umgebungsvariable FRED_API_KEY ist gesetzt und hat Vorrang vor der Datei.")
    if makro_db and os.path.exists(makro_db):
        con = verbinden(makro_db)
        try:
            paare = {}
            for (kk,) in con.execute("SELECT k FROM mk_meta WHERE k LIKE 'pause:fred:%' OR k LIKE 'fehlversuche:fred:%'"):
                paare[kk] = 0
            if paare:
                _meta_setzen(con, paare)
        finally:
            con.close()
        z.append("FRED-Pausen zurückgesetzt: Der Makro-Takt ruft binnen einer Minute ab, die Charts folgen binnen rund 10 Minuten.")
    return True, " ".join(z)


def fng_parse(d) -> list:
    """alternative.me: {"data":[{"value":"40","timestamp":"1551157200"}]} (Sekunden, Tagesbeginn UTC)."""
    zeilen = []
    for z in (d or {}).get("data") or [] if isinstance(d, dict) else []:
        t = _sek(z.get("timestamp")) if isinstance(z, dict) else None
        w = _wert(z.get("value")) if isinstance(z, dict) else None
        if t and w is not None:
            zeilen.append(("fng:wert", t // TAG * TAG, w))
    return zeilen


def llama_parse(d) -> list:
    """DefiLlama /stablecoincharts/all: [{"date":"1511913600","totalCirculatingUSD":{"peggedUSD":..,"peggedEUR":..}}]."""
    zeilen = []
    for z in d if isinstance(d, list) else []:
        if not isinstance(z, dict):
            continue
        t = _sek(z.get("date"))
        usd = z.get("totalCirculatingUSD")
        if not t or not isinstance(usd, dict):
            continue
        s = sum(w for w in (_wert(x) for x in usd.values()) if w is not None)
        if s > 0:
            zeilen.append(("llama:stable_usd", t // TAG * TAG, s))
    return zeilen


def bc_parse(name: str, d) -> list:
    """Blockchain.com Charts: {"values":[{"x":1230940800,"y":1.0}]}; Nullwerte der Frühzeit fallen weg."""
    zeilen = []
    for z in (d or {}).get("values") or [] if isinstance(d, dict) else []:
        t = _sek(z.get("x")) if isinstance(z, dict) else None
        w = _wert(z.get("y")) if isinstance(z, dict) else None
        if t and w is not None and w > 0:
            zeilen.append((f"bc:{name}", t // TAG * TAG, w))
    return zeilen


def drb_parse(waehrung: str, d) -> tuple:
    """Deribit get_volatility_index_data: {"result":{"data":[[ts_ms, open, high, low, close]], "continuation": ts|null}}."""
    r = (d or {}).get("result") or {} if isinstance(d, dict) else {}
    zeilen = []
    for z in r.get("data") or []:
        if not isinstance(z, (list, tuple)) or len(z) < 5:
            continue
        t = _sek(z[0]); w = _wert(z[4])
        if t and w is not None:
            zeilen.append((f"drb:dvol_{waehrung.lower()}", t // TAG * TAG, w))
    return zeilen, r.get("continuation")


def bnc_funding_parse(d) -> dict:
    """Binance /fapi/v1/fundingRate: [{"fundingTime": ms, "fundingRate": "0.0001"}] -> {Tag (s): [Raten]}."""
    je_tag: dict = {}
    for z in d if isinstance(d, list) else []:
        if not isinstance(z, dict):
            continue
        t = _sek(z.get("fundingTime")); r = _wert(z.get("fundingRate"))
        if t and r is not None:
            je_tag.setdefault(t // TAG * TAG, {})[t] = r                # je Zeitpunkt einmal (Seiten überlappen)
    return je_tag


def bnc_oi_parse(d) -> list:
    """Binance /futures/data/openInterestHist (period=1d): [{"sumOpenInterest","sumOpenInterestValue","timestamp": ms}]."""
    zeilen = []
    for z in d if isinstance(d, list) else []:
        if not isinstance(z, dict):
            continue
        t = _sek(z.get("timestamp")); usd = _wert(z.get("sumOpenInterestValue")); n = _wert(z.get("sumOpenInterest"))
        if t and usd is not None and usd > 0:
            zeilen.append(("bnc:oi_btc_usd", t // TAG * TAG, usd))
            if n is not None:
                zeilen.append(("bnc:oi_btc_coins", t // TAG * TAG, n))
    return zeilen


def oi_archiv_parse(tag: str, roh: bytes) -> list:
    """
    data.binance.vision Tagesdatei (ZIP mit CSV, 5-min-Zeilen): create_time,symbol,sum_open_interest,sum_open_interest_value,...
    Genommen wird die FRÜHESTE Zeile des Tages -- wie der REST-Endpunkt (period=1d) den Stand zu Tagesbeginn UTC.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(roh)) as z:
            namen = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not namen:
                return []
            text = z.read(namen[0]).decode("utf-8", "replace")
    except (zipfile.BadZipFile, KeyError, OSError):
        return []
    beste = None
    for z in csv.DictReader(io.StringIO(text)):
        zeit = (z.get("create_time") or "").strip()
        if not zeit.startswith(tag):
            continue
        usd = _wert(z.get("sum_open_interest_value")); n = _wert(z.get("sum_open_interest"))
        if usd is None or usd <= 0:
            continue
        if beste is None or zeit < beste[0]:
            beste = (zeit, usd, n)
    if not beste:
        return []
    t = tag_ts(tag)
    zeilen = [("bnc:oi_btc_usd", t, beste[1])]
    if beste[2] is not None:
        zeilen.append(("bnc:oi_btc_coins", t, beste[2]))
    return zeilen


_MONATE = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def farside_parse(coin: str, html: str) -> list:
    """
    Farside-Tabelle (wie hl_ext): erste Zelle '11 Jan 2024', letzte Zelle Summe in Mio USD, Klammern = negativ,
    '-' = keine Daten (NICHT null, Audit v3 L7). Zeilen ohne Datum (Total, Average, Maximum, Minimum) fallen weg.
    """
    zeilen = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html or "", re.S):
        cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip()
                 for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
        if len(cells) < 3:
            continue
        m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
        if not m or m.group(2) not in _MONATE:
            continue
        tot = cells[-1].replace(",", "").strip()
        if tot in ("-", "", "–", "—"):
            continue
        neg = tot.startswith("(")
        w = _wert(tot.strip("()"))
        if w is None:
            continue
        t = tag_ts(f"{m.group(3)}-{_MONATE[m.group(2)]:02d}-{int(m.group(1)):02d}")
        if t is not None:
            zeilen.append((f"fs:etf_{coin}", t, -w if neg else w))
    return zeilen


def bgm_parse(endpunkt: str, d) -> list:
    """
    BGeometrics: [{"d":"2022-07-09","unixTs":1657324800,"<metrik>":0.9794}] -- der Name des Wertfelds hängt am Endpunkt und
    ist nicht dokumentiert; deshalb wird JEDES Zahlenfeld als eigene Reihe bgm:<endpunkt>:<feld> gespeichert.
    """
    zeilen = []
    liste = d if isinstance(d, list) else ([d] if isinstance(d, dict) else [])
    for z in liste:
        if not isinstance(z, dict):
            continue
        t = _sek(z.get("unixTs")) or tag_ts(str(z.get("d") or z.get("date") or "")[:10])
        if not t:
            continue
        t = t // TAG * TAG
        for k, v in z.items():
            if k in ("d", "unixTs", "date", "time", "timestamp", "theDay"):
                continue
            w = _wert(v)
            if w is not None:
                zeilen.append((f"bgm:{endpunkt}:{k}", t, w))
    return zeilen


# ================================================================================================ Abruf mit Zeitplan

# ================================================================================================ 23.127 (U316): Abruf nach Bekanntgabe
#
# Wunsch des Nutzers (26.11.2026): Die Makro-Charts zeigen neue Zahlen erst Stunden nach der Bekanntgabe. Der 12-h-Takt bleibt; dazu
# holt der Takt jede Reihe an ihrem Termin, sobald die Zahl da ist. Termine kommen automatisch aus den Datenquellen:
#   * FRED fred/release/dates (die Kalender der Behörden, auch künftige Termine) je Veröffentlichung -- wie seit 23.67 für die USA;
#   * Fed-Entscheide aus den Kalshi-Märkten (Handelsschluss am Entscheidungstag) und der eingebauten Liste (hl_volatil.FOMC).
# Die Uhrzeit gibt keine API her; sie steht hier je Reihe (New York) mit Beleg. FRED führt die Zahl 2026 so viel später
# (Stempel „Updated“ der FRED-Seiten, Chicagoer Zeit): Erstanträge 3–18 min, Verbraucherpreise 35–42 min, Stellen 54–61 min (einmal
# 2 h 13 min), Erzeugerpreise 1 h 42 min bis 2 h 28 min, Fed-Bilanz H.4.1 1–3 min, M2 (H.6) 1 min, Dollar und Wechselkurse (H.10)
# 1–8 min (einmal 53 min), Realzins und Leitzins (H.15) 1 min (einmal 50 min), Reverse Repo 14:02 New York.
# Ablauf am Termin: erster Abruf 5 min nach der Uhrzeit, dann alle 5 min, bis die jüngste Beobachtung der Reihe nach der Uhrzeit
# geschrieben wurde (die neue Zahl), höchstens 4 h. Danach wieder der 12-h-Takt. Nur mit FRED-Schlüssel (Termine gibt es nur so).
TERMIN_UHRZEIT = {
    # BLS (Verbraucherpreise, Erzeugerpreise, Arbeitsmarktbericht) und DOL (Erstanträge): 8:30 New York
    "CPIAUCSL": (8, 30), "CPIAUCNS": (8, 30), "CPILFESL": (8, 30), "CPILFENS": (8, 30), "PPIFIS": (8, 30), "PPIFID": (8, 30),
    "UNRATE": (8, 30), "PAYEMS": (8, 30), "ICSA": (8, 30),
    # Federal Reserve Board: H.4.1 (Fed-Bilanz, Schatzamtskonto) donnerstags 16:30, H.6 (M2) 13:00, H.10 (Dollar, Wechselkurse)
    # montags 16:15, H.15 (Realzins, Leitzins effektiv) werktags 16:15 -- FRED 2026 je 1 bis 3 min danach
    "WALCL": (16, 30), "WTREGEN": (16, 30), "M2SL": (13, 0),
    "DTWEXBGS": (16, 15), "DEXUSEU": (16, 15), "DEXJPUS": (16, 15), "DFII10": (16, 15), "DFF": (16, 15),
    # New York Fed, Reverse Repo: FRED führt die Zahl 2026 um 14:02 New York (13:02 Chicago)
    "RRPONTSYD": (14, 0),
}
# Zielspanne der Fed: FRED nimmt den Entscheid erst am Tag danach (gültig ab dann), täglich gegen 8:01 New York (7:01 Chicago)
TERMIN_NACH_FED = ("DFEDTARU", "DFEDTARL")
TERMIN_NACH_FED_UHRZEIT = (8, 0)
# Ohne belegten festen Zeitpunkt -- bleiben im 12-h-Takt (und zeigen ohnehin Wochen- bzw. Monatswerte):
TERMIN_OHNE = {"BAMLH0A0HYM2": "ICE BofA: FRED führt den Vortag am Morgen danach, 2026 zwischen 8:09 und 12:45 Chicago",
               "ECBASSETSW": "EZB: wöchentlich, FRED einmal 11:02 Chicago am Dienstag gesehen",
               "JPNASSETS": "Bank of Japan: monatlich, FRED einmal 20:11 Chicago gesehen"}
TERMIN_NAME = {"CPIAUCSL": "Verbraucherpreise", "CPIAUCNS": "Verbraucherpreise", "CPILFESL": "Verbraucherpreise", "CPILFENS": "Verbraucherpreise",
               "PPIFIS": "Erzeugerpreise", "PPIFID": "Erzeugerpreise", "UNRATE": "Arbeitsmarktbericht", "PAYEMS": "Arbeitsmarktbericht",
               "ICSA": "Erstanträge", "WALCL": "Fed-Bilanz (H.4.1)", "WTREGEN": "Fed-Bilanz (H.4.1)", "M2SL": "Geldmenge M2 (H.6)",
               "DTWEXBGS": "Dollar und Wechselkurse (H.10)", "DEXUSEU": "Dollar und Wechselkurse (H.10)", "DEXJPUS": "Dollar und Wechselkurse (H.10)",
               "DFII10": "Zinsen (H.15)", "DFF": "Zinsen (H.15)", "RRPONTSYD": "Reverse Repo (New York Fed)",
               "DFEDTARU": "Zielspanne (FRED, Tag nach dem Entscheid)", "DFEDTARL": "Zielspanne (FRED, Tag nach dem Entscheid)"}
TERMIN_ERSTER_S = 300                   # erster Abruf 5 min nach der Uhrzeit
TERMIN_TAKT_S = 300                     # dann alle 5 min ...
TERMIN_FENSTER_S = 4 * 3600             # ... höchstens 4 h lang
TERMIN_KURZ_AB = 60 * TAG               # Termine der übrigen Veröffentlichungen ab 60 Tagen vor heute (die vier der USA wie bisher ab 2019)

# Fed-Entscheid: die Erklärung des FOMC um 14:00 New York. Gemeinfrei („Unless otherwise indicated, information on Board's website is
# in the public domain … Please cite to the Board“). Der Feed „Monetary Policy“ führt sie als „Federal Reserve issues FOMC statement“;
# die Seite trägt seit Jahren die Adresse monetaryJJJJMMTTa.htm (28.10.2026: monetary20261028a.htm). Gültig ist die neue Spanne ab
# dem Tag danach („Effective October 29, 2026“ in der Implementation Note vom 28.10.2026).
FED_RSS = "https://www.federalreserve.gov/feeds/press_monetary.xml"
FED_SEITE = "https://www.federalreserve.gov/newsevents/pressreleases/monetary{tag}a.htm"
FED_UHRZEIT = (14, 0)
FED_ERSTER_S = 30                       # erster Abruf 30 s nach 14:00
FED_TAKT_ERST_S = 60                    # in der ersten halben Stunde jede Minute,
FED_TAKT_ERST_DAUER_S = 1800
FED_TAKT_S = 300                        # danach alle 5 min,
FED_FENSTER_S = 3 * 3600                # bis 17:00 New York; FRED bestätigt am Morgen danach
FED_SEITE_NACH_S = 600                  # führt der Feed die Erklärung 10 min nach 14:00 noch nicht: die Seite direkt
FED_REGEL_S = 3600                      # außerhalb der Termine: Feed einmal je Stunde (auch unangekündigte Entscheide)
FED_ERKLAERUNG_TITEL = re.compile(r"\bFOMC statement\s*$", re.I)
FED_AKTION = {"maintain": "unverändert", "keep": "unverändert", "raise": "erhöht", "increase": "erhöht", "lower": "gesenkt",
              "reduce": "gesenkt", "set": "festgelegt"}
_FED_ZAHL = r"(\d+(?: ?- ?\d/\d)?|\d/\d)"
_FED_SATZ = re.compile(r"decided to (maintain|keep|raise|increase|lower|reduce|set) the target range for the federal funds rate"
                       r"(?: by " + _FED_ZAHL + r" percentage points?)? (?:at|to) " + _FED_ZAHL + r" to " + _FED_ZAHL + r" percent", re.I)
_FED_SPANNE = re.compile(r"(?:in a|the) target range (?:of|at) " + _FED_ZAHL + r" to " + _FED_ZAHL + r" percent", re.I)
_MONATE_EN = {m: i for i, m in enumerate(["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                                          "November", "December"], 1)}
_FED_DATUM = re.compile(r"\b(" + "|".join(_MONATE_EN) + r") (\d{1,2}), (\d{4})\b")
_FED_CACHE: dict = {"pfad": None, "ts": 0.0, "wert": None}
FED_CACHE_S = 600


def ny_utc(tag: int, stunde: int, minute: int = 0) -> int:
    """Wandzeit New York am Kalendertag `tag` (UTC-Mitternacht in Sekunden) -> Unix-Zeit (Sommer-/Winterzeit richtig)."""
    from zoneinfo import ZoneInfo
    d = datetime.fromtimestamp(int(tag), timezone.utc).date()
    return int(datetime(d.year, d.month, d.day, int(stunde), int(minute), tzinfo=ZoneInfo("America/New_York")).timestamp())


def ny_tag(ts) -> int:
    """Kalendertag in New York zum Zeitpunkt ts -> UTC-Mitternacht dieses Datums (wie mk_termin)."""
    from zoneinfo import ZoneInfo
    d = datetime.fromtimestamp(int(ts), ZoneInfo("America/New_York")).date()
    return int(datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp())


# ---------------------------------------------------------------------------------------------- Feed und Erklärung (reine Funktionen)

def fed_zahl(s) -> float | None:
    """„3-3/4“ -> 3,75 · „4“ -> 4 · „1/4“ -> 0,25 · „0“ -> 0; sonst None."""
    s = re.sub(r"\s", "", str(s or ""))
    m = re.fullmatch(r"(\d+)-(\d)/(\d)", s)
    if m:
        return int(m.group(1)) + int(m.group(2)) / int(m.group(3))
    m = re.fullmatch(r"(\d)/(\d)", s)
    if m:
        return int(m.group(1)) / int(m.group(2))
    return float(s) if re.fullmatch(r"\d+(?:\.\d+)?", s) else None


def fed_text_rein(html_text: str) -> str:
    """Seite -> Fließtext: ohne Skripte, Stile und Tags, Entitäten aufgelöst, Bindestriche (auch der geschützte U+2011) und
    geschützte Leerzeichen vereinheitlicht."""
    import html as _html
    s = re.sub(r"(?is)<(script|style)\b.*?</\1\s*>", " ", html_text or "")
    s = re.sub(r"(?s)<[^>]*>", " ", s)
    s = _html.unescape(s)
    s = s.translate({0x2010: "-", 0x2011: "-", 0x2012: "-", 0x2013: "-", 0x2212: "-", 0xA0: " ", 0x202F: " ", 0x2009: " ", 0xAD: ""})
    return re.sub(r"\s+", " ", s).strip()


def fed_erklaerung_parse(html_text: str) -> dict:
    """Erklärung des FOMC -> {"aktion", "schritt", "unten", "oben", "datum" (UTC-Mitternacht oder None), "fehler"}. Gelesen wird der Satz
    „… decided to maintain|raise|lower the target range for the federal funds rate [by X percentage point] at|to A to B percent“;
    ersatzweise „… target range of A to B percent“ (Implementation Note). Plausibel: 0 ≤ A < B ≤ 25 und B − A = 0,25 (seit 12/2008)."""
    t = fed_text_rein(html_text)
    out = {"aktion": None, "schritt": None, "unten": None, "oben": None, "datum": None, "fehler": None}
    m = _FED_DATUM.search(t)
    if m:
        out["datum"] = tag_ts(f"{int(m.group(3)):04d}-{_MONATE_EN[m.group(1)]:02d}-{int(m.group(2)):02d}")
    s = _FED_SATZ.search(t)
    if s:
        out["aktion"] = FED_AKTION.get(s.group(1).lower(), s.group(1).lower())
        out["schritt"] = fed_zahl(s.group(2)) if s.group(2) else None
        u, o = fed_zahl(s.group(3)), fed_zahl(s.group(4))
    else:
        s2 = _FED_SPANNE.search(t)
        if not s2:
            out["fehler"] = "kein Satz zur Zielspanne gefunden"
            return out
        u, o = fed_zahl(s2.group(1)), fed_zahl(s2.group(2))
    if u is None or o is None or not (0 <= u < o <= 25) or abs((o - u) - 0.25) > 1e-6:
        out["fehler"] = f"Spanne {u}–{o} unplausibel"
        return out
    out["unten"], out["oben"] = float(u), float(o)
    return out


def fed_rss_parse(text: str) -> list:
    """Feed (RSS 2.0) -> [{"titel", "link", "pub"}], neueste zuerst. Mit Ausdrücken statt XML-Parser (kein Auflösen fremder Entitäten);
    CDATA, Entitäten und ein vorangestelltes BOM sind erlaubt. Kein <rss>/<channel>: ValueError."""
    import html as _html
    from email.utils import parsedate_to_datetime
    s = (text or "").lstrip("﻿")
    if not re.search(r"<rss\b", s) or not re.search(r"<channel\b", s):
        raise ValueError("kein RSS (rss/channel fehlt)")

    def feld(block, name):
        m = re.search(rf"(?is)<{name}\b[^>]*>(.*?)</{name}\s*>", block)
        if not m:
            return ""
        v = m.group(1).strip()
        c = re.fullmatch(r"(?s)<!\[CDATA\[(.*)\]\]>", v)
        return (c.group(1) if c else _html.unescape(v)).strip()
    out = []
    for block in re.findall(r"(?is)<item\b[^>]*>(.*?)</item\s*>", s):
        titel, link, pd = feld(block, "title"), feld(block, "link") or feld(block, "guid"), feld(block, "pubDate")
        try:
            pub = int(parsedate_to_datetime(pd).timestamp()) if pd else None
        except (TypeError, ValueError, IndexError):
            pub = None
        if titel and link:
            out.append({"titel": re.sub(r"\s+", " ", titel), "link": link, "pub": pub})
    out.sort(key=lambda e: -(e["pub"] or 0))
    return out


# ---------------------------------------------------------------------------------------------- Termine der Fed-Entscheide

def pm_pfad_neben(pfad: str) -> str:
    """prognosemarkt.db neben makro.db (wie hl_prognosemarkt.pm_pfad); HL_PM_DB lenkt um."""
    return os.environ.get("HL_PM_DB") or os.path.join(os.path.dirname(os.path.abspath(pfad)), "prognosemarkt.db")


def fed_kalshi_tage(pm_pfad: str) -> tuple:
    """Fed-Entscheide aus den Kalshi-Märkten KXFEDDECISION und KXFED (prognosemarkt.db, nur lesen): Handelsschluss zwischen 13:00 und
    15:59 New York (am Entscheidungstag 13:55) -> Tag (UTC-Mitternacht des Datums in New York). -> (Tage, Fehler oder None)"""
    if not pm_pfad or not os.path.exists(pm_pfad):
        return [], "prognosemarkt.db fehlt"
    try:
        con = sqlite3.connect(f"file:{pm_pfad}?mode=ro", uri=True, timeout=5)
        try:
            zeilen = con.execute("SELECT DISTINCT ende FROM pm_markt WHERE plattform='kalshi' AND reihe IN ('KXFEDDECISION', 'KXFED') "
                                 "AND ende IS NOT NULL").fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [], f"prognosemarkt.db: {e}"
    from zoneinfo import ZoneInfo
    tz = ZoneInfo("America/New_York"); aus = set(); kaputt = 0
    for (ende,) in zeilen:
        e = _sek(ende)
        if not e:
            continue
        try:
            t = datetime.fromtimestamp(e, tz)
        except (ValueError, OverflowError, OSError):                      # unmöglicher Zeitstempel: diese Zeile nicht, die übrigen schon
            kaputt += 1; continue
        if 13 <= t.hour <= 15:
            aus.add(int(datetime(t.year, t.month, t.day, tzinfo=timezone.utc).timestamp()))
    return sorted(aus), (f"{kaputt} Handelsschluss unlesbar" if kaputt else None)


def fed_tage_alle(pfad: str, frisch: bool = False) -> dict:
    """Fed-Entscheide: eingebaute Liste (hl_volatil.FOMC) und Kalshi, gemeinsam die Vereinigung -- ein Tag zu viel kostet nur ein paar
    Abrufe des Feeds, ein fehlender verzögert bis zum nächsten stündlichen Blick. Zwischengespeichert 10 min."""
    jetzt = time.time()
    with _CACHE["lock"]:
        if not frisch and _FED_CACHE["pfad"] == pfad and _FED_CACHE["wert"] is not None and jetzt - _FED_CACHE["ts"] < FED_CACHE_S:
            return _FED_CACHE["wert"]
    fehler = None
    try:
        import hl_volatil as _VL
        liste = sorted({int(t) * TAG for t in _VL.fed_tage()})
    except Exception as e:                                                  # die Liste darf fehlen, Kalshi allein reicht
        liste, fehler = [], f"eingebaute Liste nicht lesbar ({type(e).__name__})"
    kalshi, k_fehler = fed_kalshi_tage(pm_pfad_neben(pfad))
    alle = sorted(set(liste) | set(kalshi))
    k_min = min(kalshi) if kalshi else None
    k_max = max(kalshi) if kalshi else None
    wert = {"liste": liste, "kalshi": kalshi, "alle": alle, "fehler": fehler, "kalshi_fehler": k_fehler,
            # verglichen nur im Zeitraum, den Kalshi abdeckt (ältere und spätere Sitzungen führt Kalshi nicht)
            "nur_liste": [t for t in liste if k_min is not None and k_min <= t <= k_max and t not in set(kalshi)],
            "nur_kalshi": [t for t in kalshi if t not in set(liste)]}
    with _CACHE["lock"]:
        _FED_CACHE.update(pfad=pfad, ts=jetzt, wert=wert)
    return wert


# ---------------------------------------------------------------------------------------------- Fenster und Stand

def release_ids(con) -> dict:
    """{Reihe: FRED-Release-Nummer} aus mk_meta „release:<Reihe>“ (fred/series/release, gemerkt)."""
    out = {}
    for k, v in con.execute("SELECT k, v FROM mk_meta WHERE k LIKE 'release:%'"):
        try:
            out[k.split(":", 1)[1]] = int(json.loads(v).get("id"))
        except (ValueError, TypeError, AttributeError):
            continue
    return out


def termin_zeitpunkte(con, sid: str, von: int, bis: int, fed: list | None = None, ids: dict | None = None) -> list:
    """Termine (Unix-Zeit der Uhrzeit) der Reihe sid mit Kalendertag in [von, bis] (UTC-Mitternächte): aus mk_termin über ihr
    Release, für die Zielspanne der Tag nach jedem Fed-Entscheid. Ohne Uhrzeit (TERMIN_OHNE) keine."""
    if sid in TERMIN_NACH_FED:
        h, m = TERMIN_NACH_FED_UHRZEIT
        return [ny_utc(t + TAG, h, m) for t in (fed or []) if von <= t + TAG <= bis]
    if sid not in TERMIN_UHRZEIT:
        return []
    rid = (ids if ids is not None else release_ids(con)).get(sid)
    if rid is None:
        return []
    h, m = TERMIN_UHRZEIT[sid]
    return [ny_utc(int(t), h, m) for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=? AND tag BETWEEN ? AND ? ORDER BY tag",
                                                          (int(rid), int(von), int(bis)))]


def termin_fenster(con, jetzt: float, fed: list | None = None) -> dict:
    """Aktive Fenster: {Reihe: Termin} mit Termin + 5 min ≤ jetzt < Termin + 4 h (der jüngste, wenn zwei offen wären)."""
    ids = release_ids(con)
    heute = int(jetzt) // TAG * TAG
    out = {}
    for sid in (*TERMIN_UHRZEIT, *TERMIN_NACH_FED):
        offen = [t for t in termin_zeitpunkte(con, sid, heute - 2 * TAG, heute + TAG, fed, ids)
                 if t + TERMIN_ERSTER_S <= jetzt < t + TERMIN_FENSTER_S]
        if offen:
            out[sid] = max(offen)
    return out


def termin_da(con, sid: str, termin: int) -> int | None:
    """Ist die neue Zahl da? Die jüngste Beobachtung der Reihe wurde nach der Uhrzeit des Termins geschrieben -> Zeit des Schreibens."""
    r = con.execute("SELECT abgerufen FROM mk_reihe WHERE reihe=? ORDER BY ts DESC LIMIT 1", (f"fred:{sid}",)).fetchone()
    return int(r[0]) if r and r[0] is not None and int(r[0]) >= int(termin) else None


def _version_hoch(con) -> None:
    """Datenversion +1 in einer eigenen Transaktion -- das Dashboard rechnet dann neu (wie nach neuen Werten in schreiben())."""
    con.execute("BEGIN IMMEDIATE")
    try:
        v = int(meta(con, "version", "0") or 0) + 1
        con.execute("INSERT INTO mk_meta VALUES ('version', ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (str(v),))
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise


def fed_zeilen(con, n: int = 8) -> list:
    """Die jüngsten gelesenen Erklärungen aus mk_fed (neueste zuerst)."""
    try:
        rows = con.execute("SELECT tag, link, titel, pub, abgerufen, quelle, aktion, schritt, unten, oben, wirksam, fehler FROM mk_fed "
                           "ORDER BY tag DESC, abgerufen DESC LIMIT ?", (int(n),)).fetchall()
    except sqlite3.Error:
        return []
    k = ("tag", "link", "titel", "pub", "abgerufen", "quelle", "aktion", "schritt", "unten", "oben", "wirksam", "fehler")
    return [dict(zip(k, r)) for r in rows]


def neu_rechnen_noetig(erg: dict, letzte_rechnung: float, jetzt: float, archiv_tag, heute) -> bool:
    """Makro-Takt: neu rechnen, wenn neue Werte da sind und die letzte Rechnung 10 min her ist, einmal je Tag -- und seit 23.127 SOFORT,
    wenn ein Abruf nach Termin oder die Erklärung der Fed eine neue Zahl brachte (sonst wartet die Anzeige bis zu 10 min)."""
    if erg.get("termin_neu"):
        return True
    return bool((erg.get("neu_ohne_archiv") and jetzt - letzte_rechnung > NEU_RECHNEN_S) or (archiv_tag != heute and jetzt - letzte_rechnung > 300))


def fed_stand(con, R, wochen=None) -> dict:
    """Zielspanne der Fed für den Chart „Leitzins“: FRED DFEDTARU/DFEDTARL (täglich, gültig ab dem Tag nach dem Entscheid) und -- bis FRED
    den Tag führt -- die vorläufige Spanne aus der Erklärung (mk_fed). Punkte als Treppe: je Sonntag (Wochenraster des Charts) und je
    Wechsel der Tag davor (alt) und der Tag selbst (neu), dazu der letzte Tag. Tage in Tagen seit 1970."""
    tu, wu = R("fred:DFEDTARU"); tl, wl = R("fred:DFEDTARL")
    ob = {int(t): float(w) for t, w in zip(tu, wu)}; un = {int(t): float(w) for t, w in zip(tl, wl)}
    tage = sorted(set(ob) & set(un))
    stufen = []                                                                # (ab Tag, unten, oben)
    for t in tage:
        if not stufen or (un[t], ob[t]) != stufen[-1][1:]:
            stufen.append((t, un[t], ob[t]))
    fred_bis = tage[-1] if tage else None
    zeilen = [z for z in fed_zeilen(con, 8) if z["unten"] is not None]
    vorl = None
    if zeilen:
        z = zeilen[0]; w = int(z["wirksam"] or (int(z["tag"]) + TAG)) // TAG
        if fred_bis is None or w > fred_bis:
            vorl = {"tag": int(z["tag"]) // TAG, "wirksam": w, "u": float(z["unten"]), "o": float(z["oben"]), "aktion": z["aktion"],
                    "schritt": z["schritt"], "ts": int(z["abgerufen"] or 0), "quelle": z["quelle"], "link": z["link"]}
            if not stufen or w > stufen[-1][0]:
                if not stufen or (vorl["u"], vorl["o"]) != stufen[-1][1:]:
                    stufen.append((w, vorl["u"], vorl["o"]))
    if not stufen:
        return {"t": [], "u": [], "o": [], "jetzt": None, "vorl": vorl, "fred_bis": fred_bis}
    ende = max([x for x in (fred_bis, vorl["wirksam"] if vorl else None) if x is not None])
    ab = [s[0] for s in stufen]
    punkte = {int(t) for t in (wochen if wochen is not None else []) if ab[0] <= int(t) <= ende}
    for s in stufen[1:]:
        punkte.update((s[0] - 1, s[0]))
    punkte.update((ab[0], ende))
    t_ = sorted(p for p in punkte if ab[0] <= p <= ende)
    stufe = [stufen[bisect.bisect_right(ab, p) - 1] for p in t_]
    letzte = stufen[-1]
    return {"t": t_, "u": [s[1] for s in stufe], "o": [s[2] for s in stufe], "fred_bis": fred_bis, "vorl": vorl,
            "jetzt": {"u": letzte[1], "o": letzte[2], "seit": letzte[0], "quelle": "Erklärung der Fed (vorläufig)" if vorl else "FRED"}}


# ---------------------------------------------------------------------------------------------- Debug 168

def _uhr_ort(ts) -> str:
    """„Do 03.12. 14:30“ in Ortszeit des Pi (wie tag_kurz)."""
    return tag_kurz(ts) if ts else "—"


def _tag_de(ts) -> str:
    """UTC-Mitternacht -> „26.01.2028“."""
    return time.strftime("%d.%m.%Y", time.gmtime(int(ts)))


def _dauer(s) -> str:
    s = int(round(s))
    if s < 60:
        return f"{s} s"
    if s < 3600:
        return f"{s // 60} min"
    return f"{s // 3600} h {s % 3600 // 60:02d} min"


def termin_ausnahme_lesen(con, jetzt: float, tage: int = 7):
    """Letzte Ausnahme der Schicht nach Termin (meta fehler:termin) -> (Zeitpunkt, Text), wenn jünger als „tage“, sonst None."""
    try:
        v = meta(con, "fehler:termin") or ""
    except sqlite3.Error:
        return None
    ts_, _, txt_ = v.partition(" ")
    if not ts_.isdigit() or int(ts_) <= jetzt - tage * TAG:
        return None
    return int(ts_), txt_


def termin_text(pfad: str, jetzt: float | None = None) -> str:
    """Debug 168: Abruf nach Bekanntgabe -- Regel, Termine je Veröffentlichung, die letzten Abrufe nach Termin mit Verzug, Fed-Entscheid
    (Termine aus Liste und Kalshi, Feed, gelesene Erklärungen gegen FRED, Zielspanne). Liest nur."""
    jetzt = float(time.time() if jetzt is None else jetzt)
    z = [f"★ Makro: Abruf nach Bekanntgabe (U316, Debug 168) · Stand {time.strftime('%d.%m.%Y %H:%M', time.localtime(jetzt))} · {pfad}",
         "Regel: Der 12-h-Takt bleibt. Dazu an jedem Termin ab 5 min nach der Uhrzeit alle 5 min, bis die neue Zahl da ist, höchstens 4 h; "
         "danach rechnet das Dashboard sofort neu. Fed-Entscheid: Feed der Fed ab 14:00:30 New York jede Minute, nach 30 min alle 5 min, bis 17:00; "
         "sonst einmal je Stunde. Zeiten hier in Ortszeit."]
    con = lesen(pfad)
    if con is None:
        return "\n".join(z + ["", "makro.db fehlt (der Makro-Takt legt sie 90 s nach dem Start des Dashboards an)."])
    try:
        schluessel = bool(fred_schluessel_lesen())
        ids = release_ids(con)
        F = fed_tage_alle(pfad, frisch=True)
        heute = int(jetzt) // TAG * TAG
        ok_t = meta(con, "ok:fredtermin:usa")
        z.append(f"FRED-Schlüssel: {'da' if schluessel else 'FEHLT -- ohne Schlüssel keine Termine und kein Abruf nach Termin (nur der 12-h-Takt)'} · "
                 f"Termine zuletzt geholt: {_uhr_ort(float(ok_t)) if ok_t and float(ok_t) > 0 else 'noch nie'}")
        tf = meta(con, "termin_fehler")
        if tf:
            z.append(f"  Termine mit Fehler (die übrigen gelten): {tf}")
        aus_ = termin_ausnahme_lesen(con, jetzt)
        if aus_:
            z.append(f"  AUSNAHME in der Schicht nach Termin {_uhr_ort(aus_[0])}: {aus_[1]} -- die Runde lief ohne sie weiter "
                     "(12-h-Takt, Feed stündlich). Bitte melden.")
        z.append("")
        z.append("Termine je Veröffentlichung (Uhrzeit New York -> hier):")
        gruppen: dict = {}
        for sid in (*TERMIN_UHRZEIT, *TERMIN_NACH_FED):
            gruppen.setdefault((TERMIN_NAME.get(sid, sid), ids.get(sid)), []).append(sid)
        for (name, rid), sids in gruppen.items():
            ts = termin_zeitpunkte(con, sids[0], heute - TAG, heute + 60 * TAG, F["alle"], ids)
            kuenftig = [t for t in ts if t + TERMIN_FENSTER_S > jetzt]
            h, m = TERMIN_NACH_FED_UHRZEIT if sids[0] in TERMIN_NACH_FED else TERMIN_UHRZEIT[sids[0]]
            offen = [t for t in kuenftig if t + TERMIN_ERSTER_S <= jetzt < t + TERMIN_FENSTER_S]
            if sids[0] in TERMIN_NACH_FED:
                herkunft = "Tag nach jedem Fed-Entscheid"
            elif rid is None:
                herkunft = "Release noch nicht bestimmt"
            else:
                herkunft = f"FRED-Release {rid}"
            z.append(f"  {name:<44} {h:02d}:{m:02d} New York · {', '.join(sids)} · {herkunft} · "
                     + (f"FENSTER OFFEN seit {_uhr_ort(offen[0])}" if offen else
                        f"nächster {_uhr_ort(kuenftig[0])}" if kuenftig else "kein Termin in den nächsten 60 Tagen"))
        z.append("  Ohne belegten festen Zeitpunkt (nur der 12-h-Takt): "
                 + " · ".join(f"{k_} ({v_})" for k_, v_ in TERMIN_OHNE.items()))
        z.append("")
        try:
            rows = con.execute("SELECT reihe, termin, versuche, erster, letzter, da, wie FROM mk_terminabruf WHERE termin >= ? "
                               "ORDER BY termin DESC, reihe LIMIT 60", (int(jetzt) - 30 * TAG,)).fetchall()
        except sqlite3.Error:
            rows = []
        z.append(f"Abrufe nach Termin, letzte 30 Tage ({len(rows)}{', die jüngsten 60' if len(rows) >= 60 else ''}):")
        if not rows:
            z.append("  noch keine (der erste Termin nach dem Einspielen kommt; Liste oben)")
        verzug: dict = {}
        for reihe, termin, versuche, erster, letzter, da, wie in rows:
            if da:
                if wie == "takt":
                    was = f"Zahl schon über den 12-h-Takt da ({_uhr_ort(da)})"
                else:
                    was = f"Zahl da {time.strftime('%H:%M', time.localtime(da))} -- {_dauer(da - termin)} nach der Uhrzeit, {versuche} Abruf{'e' if versuche != 1 else ''}"
                    verzug.setdefault(reihe, []).append(da - termin)
                    if reihe == "fed:erklaerung":
                        was += f" ({'Feed' if wie == 'rss' else 'Seite direkt'})"
            elif int(termin) + TERMIN_FENSTER_S > jetzt and reihe != "fed:erklaerung":
                was = f"läuft: {versuche} Abruf{'e' if versuche != 1 else ''}, noch keine neue Zahl"
            elif reihe == "fed:erklaerung" and int(termin) + FED_FENSTER_S > jetzt:
                was = f"läuft: {versuche} Abruf{'e' if versuche != 1 else ''}, noch keine Erklärung"
            else:
                was = f"KEINE neue Zahl im Fenster ({versuche} Abrufe bis {time.strftime('%H:%M', time.localtime(letzter)) if letzter else '—'})"
            z.append(f"  {_uhr_ort(termin)}  {reihe.replace('fed:erklaerung', 'Fed-Erklärung'):<14} {was}")
        if verzug:
            z.append("  Median der Verzüge (Uhrzeit bis Zahl im Speicher): "
                     + " · ".join(f"{k_.replace('fed:erklaerung', 'Fed-Erklärung')} {_dauer(float(np.median(v_)))} (n {len(v_)})"
                                  for k_, v_ in sorted(verzug.items())))
        z.append("")
        # ---- Fed-Entscheid
        z.append("Fed-Entscheid (Erklärung des FOMC um 14:00 New York):")
        kuenftig = [t for t in F["alle"] if ny_utc(t, *FED_UHRZEIT) + FED_FENSTER_S > jetzt]
        ab_heute = [t for t in F["liste"] if t >= heute]
        z.append(f"  Termine: eingebaute Liste {len(ab_heute)} ab heute"
                 + (f" (bis {_tag_de(ab_heute[-1])})" if ab_heute else "") + " · Kalshi "
                 + (f"{len(F['kalshi'])} Tage (zuletzt {', '.join(_tag_de(t) for t in F['kalshi'][-4:])})"
                    if F["kalshi"] else f"keine ({F['kalshi_fehler'] or 'keine Märkte KXFEDDECISION/KXFED'})")
                 + f" · gemeinsam {len([t for t in F['alle'] if t >= heute])} ab heute")
        if F["fehler"]:
            z.append(f"  {F['fehler']}")
        if F["nur_kalshi"] or F["nur_liste"]:
            z.append("  ABWEICHUNG Liste/Kalshi (beide werden abgefragt): "
                     + (f"nur bei Kalshi {', '.join(_tag_de(t) for t in F['nur_kalshi'])}" if F["nur_kalshi"] else "")
                     + (" · " if F["nur_kalshi"] and F["nur_liste"] else "")
                     + (f"nur in der Liste {', '.join(_tag_de(t) for t in F['nur_liste'])}" if F["nur_liste"] else ""))
        elif F["kalshi"]:
            z.append("  Liste und Kalshi stimmen im Zeitraum von Kalshi überein")
        if kuenftig:
            t_n = ny_utc(kuenftig[0], *FED_UHRZEIT)
            z.append(f"  nächster: {_uhr_ort(t_n)} -- Feed ab {time.strftime('%H:%M:%S', time.localtime(t_n + FED_ERSTER_S))} jede Minute, "
                     f"ab {time.strftime('%H:%M', time.localtime(t_n + FED_TAKT_ERST_DAUER_S))} alle 5 min, bis "
                     f"{time.strftime('%H:%M', time.localtime(t_n + FED_FENSTER_S))}; FRED-Zielspanne am Morgen danach ab "
                     f"{time.strftime('%H:%M', time.localtime(ny_utc(kuenftig[0] + TAG, *TERMIN_NACH_FED_UHRZEIT) + TERMIN_ERSTER_S))}")
        try:
            rss = json.loads(meta(con, "fed:rss") or "null")
        except ValueError:
            rss = None
        fe = meta(con, "fehler:fed:rss") or ""
        ok_f = meta(con, "ok:fed:rss")
        z.append(f"  Feed {FED_RSS}: " + (f"zuletzt gelesen {_uhr_ort(rss['ts'])}, {rss['n']} Einträge, {rss.get('erkl', 0)} Erklärungen des FOMC darin"
                                          if isinstance(rss, dict) and rss.get("ts") else "noch nie gelesen")
                 + (f" · FEHLER {fe}" if fe else "")
                 + ("" if not ok_f or float(ok_f) <= 0 else f" · letzter Erfolg {_uhr_ort(float(ok_f))}"))
        zeilen = fed_zeilen(con, 6)
        if not zeilen:
            z.append("  Erklärungen gelesen: noch keine")
        else:
            z.append("  Erklärungen gelesen (neueste zuerst; gültig ab dem Tag danach, verglichen mit FRED DFEDTARU/DFEDTARL):")
            for e in zeilen:
                w_ = int(e["wirksam"] or (int(e["tag"]) + TAG))
                if e["unten"] is None:
                    z.append(f"    {_tag_de(e['tag'])} NICHT GELESEN: {e['fehler']} · {e['link']}")
                    continue
                fo = con.execute("SELECT wert FROM mk_reihe WHERE reihe='fred:DFEDTARU' AND ts=?", (w_,)).fetchone()
                fu = con.execute("SELECT wert FROM mk_reihe WHERE reihe='fred:DFEDTARL' AND ts=?", (w_,)).fetchone()
                vgl = ("FRED noch ohne diesen Tag" if not fo or not fu else
                       "FRED gleich" if abs(fo[0] - e["oben"]) < 1e-9 and abs(fu[0] - e["unten"]) < 1e-9 else
                       f"ABWEICHUNG: FRED {_zahl(fu[0])}–{_zahl(fo[0])} %")
                z.append(f"    {_tag_de(e['tag'])} Zielspanne {_zahl(e['unten'])}–{_zahl(e['oben'])} % ({e['aktion'] or 'Implementation Note'}"
                         + (f" um {_zahl(e['schritt'])} Prozentpunkte" if e["schritt"] else "") + f") ab {_tag_de(w_)} · gelesen "
                         f"{_uhr_ort(e['abgerufen'])} über {'den Feed' if e['quelle'] == 'rss' else 'die Seite direkt'} · {vgl}")
        Rr = Reihen(con)
        S = fed_stand(con, Rr)
        if S.get("jetzt"):
            j = S["jetzt"]
            z.append(f"  Zielspanne jetzt: {_zahl(j['u'])}–{_zahl(j['o'])} % seit {_tag_de(j['seit'] * TAG)} ({j['quelle']}"
                     + (f"; FRED bis {_tag_de(S['fred_bis'] * TAG)}" if S.get("fred_bis") else "; noch nichts von FRED") + ")")
        else:
            z.append("  Zielspanne: noch keine Werte (FRED DFEDTARU/DFEDTARL werden mit dem ersten Takt geholt)")
    finally:
        con.close()
    return "\n".join(z)


class Makro:
    """
    Abruf aller Quellen nach Zeitplan, je Ziel eigener Zustand in mk_meta (ok:, versuch:, fehler:, pause:, voll:).
    Erster Abruf je Ziel holt die ganze Historie (voll:), danach nur das jüngste Stück mit Überlappung (Revisionen).
    Fehler: Pause 15 min, verdoppelt bis 6 h. http und uhr sind austauschbar (Selbsttest ohne Netz, mit springender Uhr).
    """

    ZIELE = (
        # quelle, ziel, Abstand in s
        *[("cm", a, 6 * 3600) for a in CM_METRIKEN],
        *[("fred", s, 12 * 3600) for s in FRED],
        *[("fred1", s, 30 * TAG) for s in FRED_USA],        # 23.67 (U153): Erstveröffentlichungen (ALFRED), monatlich nachgesehen
        ("fredtermin", "usa", 24 * 3600),                     # 23.67 (U153): Veröffentlichungstermine; 23.127: aller Reihen mit Uhrzeit
        ("fed", "rss", FED_REGEL_S),                          # 23.127 (U316): Feed der Fed stündlich, am Entscheidungstag jede Minute
        ("fng", "wert", 6 * 3600),
        ("llama", "stable_usd", 12 * 3600),
        ("bc", "difficulty", 12 * 3600),
        ("bc", "hash-rate", 24 * 3600),
        ("drb", "BTC", 12 * 3600),
        ("bnc", "funding", 8 * 3600),
        ("bnc", "oi", 12 * 3600),
        ("farside", "btc", 12 * 3600),
        ("farside", "eth", 12 * 3600),
    )

    def __init__(self, pfad: str, http_fn=None, uhr=None, pause_s: float = PAUSE_S, fred_schluessel: str | None = None):
        self.pfad = pfad
        self.http = http_fn or http
        self.uhr = uhr or time.time
        self.pause_s = pause_s
        self.con = verbinden(pfad)
        self.letzte_runde: dict = {}
        self.fred_schluessel = fred_schluessel          # None: bei jedem Abruf aus Umgebung/accesstokens.json lesen; "": keiner
        self.letzter_fehler = ""
        self._fenster: dict = {}                        # 23.127 (U316): offene Fenster dieser Runde {Reihe: Termin}
        self._termin_fertig: set = set()                # (Reihe, Termin) mit neuer Zahl -- nicht noch einmal prüfen
        self.termin_ausnahme: str | None = None         # letzte Ausnahme der Schicht nach Termin in dieser Runde (Text)

    def _fred_key(self) -> str:
        return fred_schluessel_lesen() if self.fred_schluessel is None else self.fred_schluessel

    # -- Zustand ---------------------------------------------------------------------------------------------
    def _m(self, k, standard=None):
        return meta(self.con, k, standard)

    def faellig(self, quelle: str, ziel: str, abstand: int) -> bool:
        jetzt = self.uhr()
        if float(self._m(f"pause:{quelle}:{ziel}", "0") or 0) > jetzt:
            return False
        return jetzt - float(self._m(f"ok:{quelle}:{ziel}", "0") or 0) >= abstand

    def _erfolg(self, quelle, ziel, n, ms, voll=False):
        paare = {f"ok:{quelle}:{ziel}": int(self.uhr()), f"fehler:{quelle}:{ziel}": "", f"fehlversuche:{quelle}:{ziel}": 0,
                 f"pause:{quelle}:{ziel}": 0}
        if voll:
            paare[f"voll:{quelle}:{ziel}"] = 1
        _meta_setzen(self.con, paare)
        protokoll(self.con, quelle, ziel, True, n, ms)

    def _fehler(self, quelle, ziel, text, ms):
        n = int(self._m(f"fehlversuche:{quelle}:{ziel}", "0") or 0) + 1
        pause = min(6 * 3600, 900 * 2 ** (n - 1))
        _meta_setzen(self.con, {f"fehler:{quelle}:{ziel}": f"{ts_tag(self.uhr())} {time.strftime('%H:%M', time.gmtime(self.uhr()))} UTC: {text}"[:240],
                                f"fehlversuche:{quelle}:{ziel}": n, f"pause:{quelle}:{ziel}": int(self.uhr() + pause),
                                f"versuch:{quelle}:{ziel}": int(self.uhr())})
        protokoll(self.con, quelle, ziel, False, 0, ms, text)

    def _holen(self, url, art="json", timeout=30):
        d, err = self.http(url, timeout=timeout, art=art)
        if self.pause_s:
            time.sleep(self.pause_s)
        return d, err

    # -- Ziele ----------------------------------------------------------------------------------------------
    def lauf(self, quelle: str, ziel: str) -> tuple:
        """Ein Ziel abrufen und schreiben -> (neue Zeilen, voll?). Wirft RuntimeError mit Grund."""
        voll = not self._m(f"voll:{quelle}:{ziel}")
        heute = int(self.uhr()) // TAG * TAG
        if quelle == "cm":
            letzt = letzter_tag(self.con, f"cm:{ziel}:PriceUSD")
            start = "2009-01-01" if voll or letzt is None else ts_tag(letzt - 14 * TAG)
            url, zeilen, seiten = cm_url(ziel, CM_METRIKEN[ziel], start), [], 0
            while url and seiten < 20:
                d, err = self._holen(url, timeout=60)
                if err:
                    raise RuntimeError(err)
                z, url = cm_parse(d)
                zeilen += z; seiten += 1
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            return schreiben(self.con, zeilen), voll
        if quelle == "fred":
            letzt = letzter_tag(self.con, f"fred:{ziel}")
            start = "2008-01-01" if voll or letzt is None else ts_tag(letzt - 400 * TAG)
            k = self._fred_key()
            if k:                                                        # 23.48: offizielle API mit kostenlosem Schlüssel
                d, err = self._holen(fred_api_url(ziel, start, k), timeout=FRED_TIMEOUT_API)
                if err:
                    raise RuntimeError("API: " + _geschwaerzt(err, k)[:150] + (" -- Schlüssel prüfen" if re.search(r"\bHTTP 40[03]\b", err) else ""))
                zeilen = fred_api_parse(ziel, d)
                if not zeilen:
                    raise RuntimeError("API: keine Zeilen (" + _geschwaerzt(json.dumps(d)[:60], k) + ")")
            else:                                                        # ohne Schlüssel: fredgraph.csv (hängt seit 08/2026 oft)
                text, err = self._holen(fred_url(ziel, start), art="text", timeout=FRED_TIMEOUT_CSV)
                if err:
                    raise RuntimeError(err + (" (ohne Schlüssel)" if _netzfehler(err) else ""))
                zeilen = fred_parse(ziel, text)
                if not zeilen:
                    raise RuntimeError("keine Zeilen (" + (text or "")[:60].replace("\n", " ") + ")")
            if self._m("fred_weg") != ("api" if k else "csv"):
                _meta_setzen(self.con, {"fred_weg": "api" if k else "csv"})
            if ziel in FRED_USA:                                         # 23.67 (U153): Fassungen mit Abrufzeit
                fassungen_schreiben(self.con, zeilen, int(self.uhr()))
            return schreiben(self.con, zeilen, int(self.uhr())), voll      # 23.127: Abrufzeit von der Uhr des Takts (Abruf nach Termin)
        if quelle == "fred1":                                            # 23.67 (U153): Erstveröffentlichungen aus ALFRED
            k = self._fred_key()
            if not k:
                raise RuntimeError("braucht den FRED-Schlüssel (ALFRED nur über die API)")
            d, err = self._holen(alfred_url(ziel, k), timeout=FRED_TIMEOUT_API * 2)
            if err:
                raise RuntimeError("ALFRED: " + _geschwaerzt(err, k)[:150])
            zeilen = alfred_erst_parse(ziel, d)
            if not zeilen:
                raise RuntimeError("ALFRED: keine Zeilen")
            return erst_schreiben(self.con, zeilen), voll
        if quelle == "fredtermin":                                       # 23.67 (U153): Termine der vier Veröffentlichungen
            k = self._fred_key()                                         # 23.127 (U316): dazu jeder Reihe mit Uhrzeit (TERMIN_UHRZEIT)
            if not k:
                raise RuntimeError("braucht den FRED-Schlüssel")
            ids, fehler = {}, []
            for sid in (*USA_TERMIN_REIHEN, *[s_ for s_ in TERMIN_UHRZEIT if s_ not in USA_TERMIN_REIHEN]):
                us_ = sid in USA_TERMIN_REIHEN                           # die vier wie bisher: ein Fehler ist ein Fehler des Ziels
                gemerkt = self._m(f"release:{sid}")
                if gemerkt:
                    try:
                        ids[sid] = json.loads(gemerkt); continue
                    except ValueError:
                        pass
                d, err = self._holen(series_release_url(sid, k))
                if err:
                    if us_:
                        raise RuntimeError(f"series/release {sid}: " + _geschwaerzt(err, k)[:120])
                    fehler.append(f"series/release {sid}: " + _geschwaerzt(err, k)[:80]); continue
                try:
                    rid, name = series_release_parse(d)
                except ValueError as e_:
                    if us_:
                        raise
                    fehler.append(f"series/release {sid}: {e_}"); continue
                ids[sid] = {"id": rid, "name": name}
                _meta_setzen(self.con, {f"release:{sid}": json.dumps(ids[sid])})
            us = {int(ids[s_]["id"]) for s_ in USA_TERMIN_REIHEN if s_ in ids}
            n = 0
            for rid in sorted({int(v["id"]) for v in ids.values()}):
                d, err = self._holen(release_dates_url(rid, k) if rid in us else release_dates_url(rid, k, ab=ts_tag(heute - TERMIN_KURZ_AB)))
                if err:
                    if rid in us:
                        raise RuntimeError(f"release/dates {rid}: " + _geschwaerzt(err, k)[:120])
                    fehler.append(f"release/dates {rid}: " + _geschwaerzt(err, k)[:80]); continue
                try:
                    tage = release_dates_parse(d)
                except ValueError as e_:
                    if rid in us:
                        raise
                    fehler.append(f"release/dates {rid}: {e_}"); continue
                if not tage:
                    if rid in us:
                        raise RuntimeError(f"release/dates {rid}: keine Termine")
                    fehler.append(f"release/dates {rid}: keine Termine"); continue
                n += termine_schreiben(self.con, rid, tage, int(self.uhr()))
            _meta_setzen(self.con, {"termin_fehler": " · ".join(fehler)[:400]})
            return n, voll
        if quelle == "fed":                                              # 23.127 (U316): Feed und Erklärung der Fed
            return self._fed_lauf(), voll
        if quelle == "fng":
            d, err = self._holen(f"https://api.alternative.me/fng/?limit={0 if voll else 40}&format=json")
            if err:
                raise RuntimeError(err)
            zeilen = fng_parse(d)
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            return schreiben(self.con, zeilen), voll
        if quelle == "llama":
            d, err = self._holen("https://stablecoins.llama.fi/stablecoincharts/all", timeout=60)
            if err:
                raise RuntimeError(err)
            zeilen = llama_parse(d)
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            return schreiben(self.con, zeilen), voll
        if quelle == "bc":
            spanne = "all" if voll else "90days"
            d, err = self._holen(f"https://api.blockchain.info/charts/{ziel}?timespan={spanne}&sampled=false&format=json", timeout=60)
            if err:
                raise RuntimeError(err)
            zeilen = bc_parse("difficulty" if ziel == "difficulty" else "hashrate", d)
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            return schreiben(self.con, zeilen), voll
        if quelle == "drb":
            letzt = letzter_tag(self.con, f"drb:dvol_{ziel.lower()}")
            von = tag_ts("2021-03-01") if voll or letzt is None else letzt - 30 * TAG
            ende, zeilen = (heute + TAG) * 1000, []
            for _ in range(12):
                d, err = self._holen(f"https://www.deribit.com/api/v2/public/get_volatility_index_data?currency={ziel}"
                                     f"&start_timestamp={von * 1000}&end_timestamp={ende}&resolution=1D")
                if err:
                    raise RuntimeError(err)
                z, weiter = drb_parse(ziel, d)
                zeilen += z
                if not weiter or not z or int(weiter) <= von * 1000:
                    break
                ende = int(weiter)
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            return schreiben(self.con, zeilen), voll
        if quelle == "bnc" and ziel == "funding":
            letzt = letzter_tag(self.con, "bnc:funding_btc_tag")
            von = tag_ts("2019-09-01") if voll or letzt is None else letzt - 3 * TAG
            je_tag: dict = {}
            for _ in range(40):
                d, err = self._holen(f"https://fapi.binance.com/fapi/v1/fundingRate?symbol=BTCUSDT&startTime={von * 1000}&limit=1000")
                if err:
                    raise RuntimeError(err)
                teil = bnc_funding_parse(d)
                for t, ev in teil.items():
                    je_tag.setdefault(t, {}).update(ev)
                if not isinstance(d, list) or len(d) < 1000:
                    break
                von = max(max(ev) for ev in teil.values()) + 1
            # nur abgeschlossene Tage (UTC): ein halber Tag hätte eine zu kleine Tagessumme
            zeilen = [("bnc:funding_btc_tag", t, sum(ev.values())) for t, ev in je_tag.items() if t < heute]
            zeilen += [("bnc:funding_btc_n", t, float(len(ev))) for t, ev in je_tag.items() if t < heute]
            if not zeilen:
                raise RuntimeError("keine abgeschlossenen Tage")
            return schreiben(self.con, zeilen), voll
        if quelle == "bnc" and ziel == "oi":
            d, err = self._holen("https://fapi.binance.com/futures/data/openInterestHist?symbol=BTCUSDT&period=1d&limit=30")
            if err:
                raise RuntimeError(err)
            zeilen = bnc_oi_parse(d)
            if not zeilen:
                raise RuntimeError("keine Zeilen")
            erster = min(t for r, t, w in zeilen if r == "bnc:oi_btc_usd")
            _meta_setzen(self.con, {"oi_rest_erster": erster})
            return schreiben(self.con, zeilen), voll
        if quelle == "farside":
            html, err = self._holen(FARSIDE[ziel], art="text", timeout=45)
            if err:
                raise RuntimeError(err)
            zeilen = farside_parse(ziel, html)
            if not zeilen:
                raise RuntimeError("keine Tabellenzeilen erkannt")
            return schreiben(self.con, zeilen), voll
        if quelle == "bgm":
            letzt = self.con.execute("SELECT MAX(ts) FROM mk_reihe WHERE reihe LIKE ?", (f"bgm:{ziel}:%",)).fetchone()[0]
            url = BGM_BASIS + ziel + ("" if voll or letzt is None else f"?startday={ts_tag(int(letzt) - 14 * TAG)}")
            d, err = self._holen(url, timeout=60)
            if err:
                raise RuntimeError(err)
            zeilen = bgm_parse(ziel, d)
            if not zeilen:
                raise RuntimeError("keine Zeilen (" + json.dumps(d)[:60] + ")")
            return schreiben(self.con, zeilen), voll
        raise RuntimeError(f"unbekanntes Ziel {quelle}:{ziel}")

    # -- 23.127 (U316): Abruf nach Bekanntgabe --------------------------------------------------------------------------------
    def _sicher(self, wo: str, fn, ersatz=None):
        """Die Schicht nach Termin darf den Takt nicht anhalten: Eine Ausnahme dort wird vermerkt (meta fehler:termin, Debug 168 und
        Makro-Stand), die Runde läuft weiter wie ohne diese Schicht (12-h-Takt, Feed stündlich)."""
        try:
            return fn()
        except Exception as e:
            self.termin_ausnahme = f"{wo}: {type(e).__name__}: {e}"[:200]
            try:
                _meta_setzen(self.con, {"fehler:termin": f"{int(self.uhr())} {self.termin_ausnahme}"})
            except Exception:
                pass
            return ersatz

    def _fed_merken(self, fed_f) -> None:
        """Erklärung gelesen: im Protokoll der Termine vermerken, wann und woher (Feed oder Seite direkt)."""
        if self._fed_hat(fed_f[1]):
            r_ = self.con.execute("SELECT abgerufen, quelle FROM mk_fed WHERE tag=? AND unten IS NOT NULL ORDER BY abgerufen LIMIT 1",
                                  (int(fed_f[1]),)).fetchone()
            self._termin_merken("fed:erklaerung", fed_f[0], int(r_[0]), r_[1])

    def _fed_tage(self) -> dict:
        return fed_tage_alle(self.pfad)

    def _termin_fenster_runde(self, nur) -> dict:
        """Offene Fenster dieser Runde -- nur für FRED-Reihen und nur mit Schlüssel (ohne gibt es keine Termine)."""
        if nur not in (None, "fred") or not self._fred_key():
            return {}
        return termin_fenster(self.con, self.uhr(), self._fed_tage()["alle"])

    def _termin_merken(self, reihe: str, termin: int, da: int, wie: str) -> None:
        self._termin_fertig.add((reihe, int(termin)))
        self.con.execute("BEGIN IMMEDIATE")
        try:
            self.con.execute("INSERT INTO mk_terminabruf VALUES (?,?,0,NULL,NULL,?,?) ON CONFLICT(reihe, termin) DO UPDATE SET "
                             "da=excluded.da, wie=excluded.wie WHERE mk_terminabruf.da IS NULL", (reihe, int(termin), int(da), wie))
            self.con.execute("DELETE FROM mk_terminabruf WHERE termin < ?", (int(self.uhr()) - 400 * TAG,))
            self.con.execute("COMMIT")
        except BaseException:
            self.con.execute("ROLLBACK")
            raise

    def _termin_versuch(self, reihe: str, termin: int) -> None:
        jetzt = int(self.uhr())
        self.con.execute("BEGIN IMMEDIATE")
        try:
            self.con.execute("INSERT INTO mk_terminabruf VALUES (?,?,1,?,?,NULL,NULL) ON CONFLICT(reihe, termin) DO UPDATE SET "
                             "versuche=mk_terminabruf.versuche+1, letzter=excluded.letzter, erster=COALESCE(mk_terminabruf.erster, excluded.erster)",
                             (reihe, int(termin), jetzt, jetzt))
            self.con.execute("COMMIT")
        except BaseException:
            self.con.execute("ROLLBACK")
            raise

    def termin_faellig(self, sid: str) -> bool:
        """Offenes Fenster, die neue Zahl noch nicht da, keine Fehlerpause, letzter Abruf nach Termin mindestens 5 min her. Ist die Zahl
        schon da (über den 12-h-Takt geholt), wird das vermerkt und nichts abgerufen."""
        termin = self._fenster.get(sid)
        if termin is None or (sid, int(termin)) in self._termin_fertig:
            return False
        da = termin_da(self.con, sid, termin)
        if da is not None:
            self._termin_merken(sid, termin, da, "takt")
            return False
        jetzt = self.uhr()
        if float(self._m(f"pause:fred:{sid}", "0") or 0) > jetzt:
            return False
        return jetzt - float(self._m(f"termin_versuch:{sid}", "0") or 0) >= TERMIN_TAKT_S

    def _release_fehlt(self) -> bool:
        """Termine sofort nachholen, wenn einer Reihe mit Uhrzeit das Release fehlt (nach dem Einspielen) -- höchstens einmal je Stunde."""
        jetzt = self.uhr()
        if float(self._m("pause:fredtermin:usa", "0") or 0) > jetzt:
            return False
        if jetzt - max(float(self._m("ok:fredtermin:usa", "0") or 0), float(self._m("versuch:fredtermin:usa", "0") or 0)) < 3600:
            return False
        ids = release_ids(self.con)
        return any(s_ not in ids for s_ in TERMIN_UHRZEIT)

    def _fed_hat(self, tag: int) -> bool:
        return self.con.execute("SELECT 1 FROM mk_fed WHERE tag=? AND unten IS NOT NULL LIMIT 1", (int(tag),)).fetchone() is not None

    def _fed_fenster(self, jetzt: float):
        """(14:00 New York, Tag) des Fed-Entscheids, dessen Fenster offen ist und dessen Erklärung noch fehlt; sonst None."""
        for t in reversed(self._fed_tage()["alle"]):
            t_f = ny_utc(t, *FED_UHRZEIT)
            if t_f + FED_ERSTER_S > jetzt:
                continue
            if jetzt < t_f + FED_FENSTER_S and not self._fed_hat(t):
                return t_f, t
            break
        return None

    def fed_faellig(self, abstand: int) -> bool:
        """Im Fenster eines Fed-Entscheids jede Minute (nach 30 min alle 5 min) -- auch nach einem Fehler, ohne die Pause von 15 min;
        sonst stündlich mit den üblichen Pausen."""
        jetzt = self.uhr()
        f = self._fed_fenster(jetzt)
        if f is not None:
            letzt = max(float(self._m("ok:fed:rss", "0") or 0), float(self._m("versuch:fed:rss", "0") or 0))
            return jetzt - letzt >= (FED_TAKT_ERST_S if jetzt < f[0] + FED_TAKT_ERST_DAUER_S else FED_TAKT_S)
        if float(self._m("pause:fed:rss", "0") or 0) > jetzt:
            return False
        return jetzt - float(self._m("ok:fed:rss", "0") or 0) >= abstand

    def _fed_seite(self, link: str, titel: str, pub, quelle: str, tag) -> int:
        """Eine Erklärung lesen und in mk_fed schreiben -> 1, wenn die Spanne gelesen wurde. Über die Adresse: 404 heißt „noch nicht da“."""
        html_, err = self._holen(link, art="text", timeout=20)
        if err:
            if quelle == "adresse" and err.startswith("HTTP 404"):
                return 0
            E = {"aktion": None, "schritt": None, "unten": None, "oben": None, "datum": None, "fehler": str(err)[:160]}
        else:
            E = fed_erklaerung_parse(html_)
        tag_ = tag if tag is not None else E.get("datum")
        if tag_ is None:
            return 0
        jetzt = int(self.uhr())
        self.con.execute("BEGIN IMMEDIATE")
        try:
            self.con.execute("INSERT INTO mk_fed VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tag, link) DO UPDATE SET titel=excluded.titel, "
                             "pub=COALESCE(excluded.pub, mk_fed.pub), abgerufen=excluded.abgerufen, quelle=excluded.quelle, aktion=excluded.aktion, "
                             "schritt=excluded.schritt, unten=excluded.unten, oben=excluded.oben, wirksam=excluded.wirksam, fehler=excluded.fehler "
                             "WHERE mk_fed.unten IS NULL",
                             (int(tag_), link, titel or "Federal Reserve issues FOMC statement", pub, jetzt, quelle, E["aktion"], E["schritt"],
                              E["unten"], E["oben"], int(tag_) + TAG, E["fehler"]))
            self.con.execute("COMMIT")
        except BaseException:
            self.con.execute("ROLLBACK")
            raise
        return 1 if E["unten"] is not None else 0

    def _fed_lauf(self) -> int:
        """Feed lesen; jede noch nicht gelesene Erklärung der letzten 60 Tage holen. Am Entscheidungstag ab 14:10 die Seite direkt, wenn
        der Feed sie nicht führt; beim ersten Lauf einmal die Seite des letzten Entscheids (Gegenprobe des Lesens auf dem Pi)."""
        jetzt = int(self.uhr())
        text, err = self._holen(FED_RSS, art="text", timeout=20)
        eintraege = []
        if not err:
            try:
                eintraege = fed_rss_parse(text)
            except ValueError as e_:
                err = str(e_)
        erkl = [e_ for e_ in eintraege if FED_ERKLAERUNG_TITEL.search(e_["titel"])]
        if not err:
            _meta_setzen(self.con, {"fed:rss": json.dumps({"ts": jetzt, "n": len(eintraege), "erkl": len(erkl)})})
        gelesen = {l_ for (l_,) in self.con.execute("SELECT link FROM mk_fed WHERE unten IS NOT NULL")}
        neu = 0
        for e_ in erkl:
            if e_["link"] in gelesen or (e_["pub"] or 0) < jetzt - 60 * TAG:
                continue
            neu += self._fed_seite(e_["link"], e_["titel"], e_["pub"], "rss", ny_tag(e_["pub"]) if e_["pub"] else None)
        f = self._sicher("Fed-Fenster", lambda: self._fed_fenster(jetzt), None)           # ohne Fed-Tage: der Feed allein
        if f is not None and jetzt >= f[0] + FED_SEITE_NACH_S and not self._fed_hat(f[1]):
            neu += self._fed_seite(FED_SEITE.format(tag=ts_tag(f[1]).replace("-", "")), "", None, "adresse", f[1])
        tage_ = None if self._m("fed:gegenprobe") else self._sicher("Fed-Tage", self._fed_tage, None)
        if tage_ is not None:                                              # Gegenprobe erst, wenn die Fed-Tage lesbar sind
            if self.con.execute("SELECT 1 FROM mk_fed WHERE unten IS NOT NULL LIMIT 1").fetchone() is None:
                vorbei = [t for t in tage_["alle"] if ny_utc(t, *FED_UHRZEIT) + FED_SEITE_NACH_S <= jetzt]
                if vorbei:
                    neu += self._fed_seite(FED_SEITE.format(tag=ts_tag(vorbei[-1]).replace("-", "")), "", None, "adresse", vorbei[-1])
            _meta_setzen(self.con, {"fed:gegenprobe": jetzt})
        if neu:
            _version_hoch(self.con)
        if err and not neu:
            raise RuntimeError(f"Feed der Fed: {err}"[:200])
        return neu

    def _ein_ziel(self, quelle, ziel) -> int:
        t0 = time.time()
        self.letzter_fehler = ""
        try:
            n, voll = self.lauf(quelle, ziel)
        except Exception as e:
            self.letzter_fehler = _geschwaerzt(str(e) if isinstance(e, RuntimeError) else f"{type(e).__name__}: {e}",
                                               self._fred_key() if quelle in ("fred", "fred1", "fredtermin") else "")
            self._fehler(quelle, ziel, self.letzter_fehler, int((time.time() - t0) * 1000))
            return -1
        self._erfolg(quelle, ziel, n, int((time.time() - t0) * 1000), voll=voll)
        return n

    # -- BGeometrics: Budget ----------------------------------------------------------------------------------
    def bgm_budget(self) -> dict:
        jetzt = self.uhr()
        try:
            liste = [float(x) for x in json.loads(self._m("bgm_aufrufe", "[]") or "[]")]
        except ValueError:
            liste = []
        mitternacht = int(jetzt) // TAG * TAG
        stunde = sum(1 for x in liste if x > jetzt - 3600)
        tag = sum(1 for x in liste if x >= mitternacht)
        letzt = max(liste) if liste else 0.0
        return {"stunde": stunde, "tag": tag, "letzt": letzt, "liste": [x for x in liste if x > jetzt - TAG],
                "frei": stunde < BGM_JE_STUNDE and tag < BGM_JE_TAG and jetzt - letzt >= BGM_ABSTAND_S}

    def bgm_schritt(self) -> int | None:
        """Höchstens EIN BGeometrics-Abruf je Aufruf, nur im Budget; der Versuch zählt (auch ein Fehler kostet ein Kontingent)."""
        b = self.bgm_budget()
        if not b["frei"]:
            return None
        for ep in BGM:
            if self.faellig("bgm", ep, 24 * 3600):
                _meta_setzen(self.con, {"bgm_aufrufe": json.dumps(b["liste"] + [round(self.uhr(), 1)])})
                return self._ein_ziel("bgm", ep)
        return None

    # -- Binance-Archiv: Open Interest ab 2020 ----------------------------------------------------------------
    def oi_archiv_schritt(self) -> int | None:
        """
        Eine Tagesdatei je Aufruf (Takt 20 s), RÜCKWÄRTS: vom Tag vor den REST-Daten (30 Tage) bis 01.09.2020. Tage, die schon da
        sind (REST, ein Vorwärtslauf bis 23.49), werden übersprungen. 23.50: Bis 23.49 lief das Archiv ab 2020 VORWÄRTS -- die
        Zeiträume 1 J bis 4 J blieben bis zum Schluss (rund 12 h) leer, der Chart zeigte nur die 30 REST-Tage am rechten Rand
        (Bild des Nutzers 05.10. 16:04). Jetzt kommen die jüngsten Jahre zuerst: 1 J nach rund 2 h, 4 J nach rund 8 h.
        """
        if self._m("oi_archiv_fertig") == "1":
            return None
        jetzt = self.uhr()
        if float(self._m("pause:oi_archiv:-", "0") or 0) > jetzt:
            return None
        erster_rest = self._m("oi_rest_erster")
        start = tag_ts(OI_ARCHIV_START)
        ende = int(erster_rest) if erster_rest else (int(jetzt) // TAG - 2) * TAG      # ausschließlich
        cursor = min(int(self._m("oi_archiv_rueck", "0") or 0) or ende - TAG, ende - TAG)
        while cursor >= start and self.con.execute("SELECT 1 FROM mk_reihe WHERE reihe='bnc:oi_btc_usd' AND ts=?", (cursor,)).fetchone():
            cursor -= TAG
        if cursor < start:
            if erster_rest:
                _meta_setzen(self.con, {"oi_archiv_fertig": 1, "oi_archiv_rueck": cursor})
            return None
        tag = ts_tag(cursor)
        t0 = time.time()
        roh, err = self.http(OI_ARCHIV_URL.format(tag=tag), timeout=30, art="bytes")
        ms = int((time.time() - t0) * 1000)
        if err and err.startswith("HTTP 404"):
            fehlend = int(self._m("oi_archiv_fehlend", "0") or 0) + 1
            _meta_setzen(self.con, {"oi_archiv_rueck": cursor - TAG, "oi_archiv_fehlend": fehlend})
            return 0
        if err:
            n = int(self._m("fehlversuche:oi_archiv:-", "0") or 0) + 1
            _meta_setzen(self.con, {"pause:oi_archiv:-": int(jetzt + min(6 * 3600, 900 * 2 ** (n - 1))), "fehlversuche:oi_archiv:-": n,
                                    "fehler:oi_archiv:-": f"{tag}: {err}"[:240]})
            protokoll(self.con, "oi_archiv", tag, False, 0, ms, err)
            return -1
        zeilen = oi_archiv_parse(tag, roh)
        n = schreiben(self.con, zeilen) if zeilen else 0
        _meta_setzen(self.con, {"oi_archiv_rueck": cursor - TAG, "fehlversuche:oi_archiv:-": 0, "fehler:oi_archiv:-": "",
                                "oi_archiv_tage": int(self._m("oi_archiv_tage", "0") or 0) + (1 if zeilen else 0)})
        return n

    # -- Runde --------------------------------------------------------------------------------------------------
    def runde(self, nur: str | None = None, erzwingen: bool = False, archiv: bool = True) -> dict:
        """Alle fälligen Ziele einmal (nur: eine Quelle); dann höchstens ein BGeometrics-Abruf und eine Archivdatei."""
        erg = {"neu": 0, "neu_ohne_archiv": 0, "termin_neu": 0, "ziele": {}}
        # 23.48: Antwortet ein Host nicht (Zeitüberschreitung, Verbindungsfehler), werden die übrigen Ziele DERSELBEN Quelle in
        # dieser Runde übersprungen und pausieren mit. Vorher blockierten 12 FRED-Reihen × 45 s den Takt 9 Minuten je Runde
        # (Pi 05.10. 11:53–12:02): BGeometrics und OI-Archiv standen so lange still. HTTP-Fehler einer Reihe sperren nichts.
        tot: dict = {}
        mit_schluessel = None
        self.termin_ausnahme = None                                        # 23.127 (U316): offene Fenster nach Termin; eine Ausnahme
        self._fenster = self._sicher("Fenster", lambda: self._termin_fenster_runde(nur), {})   # dieser Schicht hält die Runde nicht an
        for quelle, ziel, abstand in self.ZIELE:
            if nur and quelle != nur:
                continue
            if quelle in ("fred1", "fredtermin"):                         # 23.67: ALFRED und Termine nur mit FRED-Schlüssel
                if mit_schluessel is None:
                    mit_schluessel = bool(self._fred_key())
                if not mit_schluessel:
                    continue
            termin = (quelle == "fred" and not erzwingen and ziel in self._fenster
                      and bool(self._sicher("fällig", lambda: self.termin_faellig(ziel), False)))
            if quelle == "fed":                                            # nach einer Ausnahme: nach dem Abstand wie jedes Ziel
                f_ = True if erzwingen else self._sicher("Fed fällig", lambda: self.fed_faellig(abstand), None)
                faellig_ = self.faellig(quelle, ziel, abstand) if f_ is None else f_
            elif quelle == "fredtermin":
                faellig_ = erzwingen or self.faellig(quelle, ziel, abstand) or bool(self._sicher("Release fehlt", self._release_fehlt, False))
            else:
                faellig_ = erzwingen or termin or self.faellig(quelle, ziel, abstand)
            if faellig_:
                if quelle in tot:
                    self._fehler(quelle, ziel, f"übersprungen: {quelle} antwortete in dieser Runde nicht ({tot[quelle][:80]})", 0)
                    erg["ziele"][f"{quelle}:{ziel}"] = -1
                    continue
                fed_f = self._sicher("Fed-Fenster", lambda: self._fed_fenster(self.uhr()), None) if quelle == "fed" else None
                if termin:
                    self._sicher("Versuch", lambda: (_meta_setzen(self.con, {f"termin_versuch:{ziel}": int(self.uhr())}),
                                                     self._termin_versuch(ziel, self._fenster[ziel])))
                if fed_f is not None:
                    self._sicher("Versuch", lambda: self._termin_versuch("fed:erklaerung", fed_f[0]))
                n = self._ein_ziel(quelle, ziel)
                erg["ziele"][f"{quelle}:{ziel}"] = n
                if termin:
                    da = self._sicher("Zahl da", lambda: termin_da(self.con, ziel, self._fenster[ziel]), None)
                    if da is not None:
                        self._sicher("merken", lambda: self._termin_merken(ziel, self._fenster[ziel], da, "termin"))
                        erg["termin_neu"] += max(n, 0)
                if quelle == "fed":
                    if fed_f is not None:
                        self._sicher("Erklärung merken", lambda: self._fed_merken(fed_f))
                    erg["termin_neu"] += max(n, 0)
                if n < 0 and _netzfehler(self.letzter_fehler):
                    tot[quelle] = self.letzter_fehler
                if n > 0:
                    erg["neu"] += n; erg["neu_ohne_archiv"] += n
        if nur in (None, "bgm"):
            n = self.bgm_schritt()
            if n is not None:
                erg["ziele"]["bgm"] = n
                if n > 0:
                    erg["neu"] += n; erg["neu_ohne_archiv"] += n
        if archiv and nur in (None, "oi_archiv"):
            n = self.oi_archiv_schritt()
            if n is not None:
                erg["ziele"]["oi_archiv"] = n
                if n > 0:
                    erg["neu"] += n
        self.letzte_runde = erg
        return erg


# ================================================================================================ Rechnung (reine Funktionen)

def sma(x: np.ndarray, n: int, min_n: int | None = None) -> np.ndarray:
    """Gleitendes Mittel über n Tage; Lücken zählen nicht; NaN, solange weniger als min_n Werte im Fenster liegen."""
    x = np.asarray(x, dtype=float)
    min_n = n if min_n is None else min_n
    ok = np.isfinite(x)
    c = np.concatenate([[0.0], np.cumsum(np.where(ok, x, 0.0))])
    k = np.concatenate([[0], np.cumsum(ok)])
    i = np.arange(len(x)); lo = np.maximum(0, i - n + 1)
    s = c[i + 1] - c[lo]; m = k[i + 1] - k[lo]
    out = np.where(m >= min_n, s / np.maximum(m, 1), np.nan)
    out[~ok] = np.nan
    return out


def summe_fenster(x: np.ndarray, n: int) -> np.ndarray:
    """Summe der gültigen Werte der letzten n Tage (fehlende = 0); NaN nur, wenn das Fenster ganz leer ist."""
    x = np.asarray(x, dtype=float); ok = np.isfinite(x)
    c = np.concatenate([[0.0], np.cumsum(np.where(ok, x, 0.0))]); k = np.concatenate([[0], np.cumsum(ok)])
    i = np.arange(len(x)); lo = np.maximum(0, i - n + 1)
    return np.where(k[i + 1] - k[lo] > 0, c[i + 1] - c[lo], np.nan)


def _rang(sl: list, v: float) -> float:
    n = len(sl)
    lo = bisect.bisect_left(sl, v); hi = bisect.bisect_right(sl, v)
    return 100.0 * (lo + 0.5 * (hi - lo - 1)) / (n - 1)


def perzentil_expandierend(x: np.ndarray, min_n: int = 365) -> np.ndarray:
    """
    Rang des heutigen Werts unter allen Werten BIS HEUTE (0 = tiefster, 100 = höchster; Gleichstände gemittelt).
    Kausal: der Wert am Tag t hängt nur von x[0..t] ab. Vor min_n gültigen Werten NaN (zu wenig Historie).
    """
    out = np.full(len(x), np.nan); sl: list = []
    for i, v in enumerate(np.asarray(x, dtype=float)):
        if not math.isfinite(v):
            continue
        bisect.insort(sl, v)
        if len(sl) >= max(2, min_n):
            out[i] = _rang(sl, v)
    return out


def perzentil_rollierend(x: np.ndarray, fenster: int = 1461, min_n: int = 365) -> np.ndarray:
    """Wie perzentil_expandierend, aber nur über die letzten `fenster` Tage (4 Jahre = ein Zyklus)."""
    x = np.asarray(x, dtype=float)
    out = np.full(len(x), np.nan); sl: list = []
    for i, v in enumerate(x):
        if i >= fenster:
            alt = x[i - fenster]
            if math.isfinite(alt):
                del sl[bisect.bisect_left(sl, alt)]
        if not math.isfinite(v):
            continue
        bisect.insort(sl, v)
        if len(sl) >= max(2, min_n):
            out[i] = _rang(sl, v)
    return out


def rang_in(werte: np.ndarray, v: float) -> float | None:
    """Rang eines EINZELNEN Werts (z. B. live) unter einer Historie, gleiche Konvention wie oben (der Wert zählt mit)."""
    w = np.sort(np.asarray(werte, dtype=float)[np.isfinite(werte)])
    if v is None or not math.isfinite(v) or len(w) < 2:
        return None
    lo = int(np.searchsorted(w, v, "left")); hi = int(np.searchsorted(w, v, "right"))
    n = len(w) + 1
    return 100.0 * (lo + 0.5 * (hi - lo)) / (n - 1)


def z_expandierend(x: np.ndarray, min_n: int = 365) -> np.ndarray:
    """(x − Mittel bis heute) / Streuung bis heute (Welford, Population); kausal."""
    out = np.full(len(x), np.nan); n = 0; mu = 0.0; m2 = 0.0
    for i, v in enumerate(np.asarray(x, dtype=float)):
        if not math.isfinite(v):
            continue
        n += 1; d = v - mu; mu += d / n; m2 += d * (v - mu)
        if n >= min_n and m2 > 0:
            out[i] = (v - mu) / math.sqrt(m2 / n)
    return out


def streuung_expandierend(x: np.ndarray) -> np.ndarray:
    """Streuung (Population) aller Werte bis heute; kausal."""
    out = np.full(len(x), np.nan); n = 0; mu = 0.0; m2 = 0.0
    for i, v in enumerate(np.asarray(x, dtype=float)):
        if not math.isfinite(v):
            continue
        n += 1; d = v - mu; mu += d / n; m2 += d * (v - mu)
        if n >= 2:
            out[i] = math.sqrt(m2 / n)
    return out


def mittel_expandierend(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float); ok = np.isfinite(x)
    c = np.cumsum(np.where(ok, x, 0.0)); k = np.cumsum(ok)
    out = np.where(k > 0, c / np.maximum(k, 1), np.nan)
    out[~ok] = np.nan
    return out


def ffill(x: np.ndarray, max_luecke: int) -> np.ndarray:
    """Fehlende Werte mit dem letzten gültigen füllen, höchstens max_luecke Tage weit (Wochen-/Monatsreihen auf Tage)."""
    x = np.asarray(x, dtype=float).copy(); letzt = None; seit = 0
    for i in range(len(x)):
        if math.isfinite(x[i]):
            letzt = x[i]; seit = 0
        elif letzt is not None and seit < max_luecke:
            seit += 1; x[i] = letzt
        else:
            seit += 1
    return x


def wochentag(tage: np.ndarray) -> np.ndarray:
    """Montag = 0 … Sonntag = 6 (1.1.1970 war ein Donnerstag)."""
    return (np.asarray(tage, dtype=np.int64) + 3) % 7


def wma200(tage: np.ndarray, p: np.ndarray, wochen: int = 200) -> np.ndarray:
    """
    200-Wochen-Durchschnitt wie im Wochenchart: Mittel der letzten 199 ABGESCHLOSSENEN Wochenschlüsse (Sonntag UTC) plus
    des heutigen Kurses als Schluss der laufenden Woche. Am Sonntag ist das genau das Mittel der letzten 200 Sonntage.
    """
    tage = np.asarray(tage, dtype=np.int64); p = np.asarray(p, dtype=float)
    so = (wochentag(tage) == 6) & np.isfinite(p)
    so_idx = np.nonzero(so)[0]
    c = np.concatenate([[0.0], np.cumsum(p[so_idx])])
    out = np.full(len(p), np.nan)
    k = np.searchsorted(so_idx, np.arange(len(p)), "left")          # Zahl der Sonntage strikt VOR Tag i
    for i in range(len(p)):
        if not math.isfinite(p[i]) or k[i] < wochen - 1:
            continue
        out[i] = (c[k[i]] - c[k[i] - (wochen - 1)] + p[i]) / wochen
    return out


def wochen_schluss(tage: np.ndarray, p: np.ndarray) -> tuple:
    """Sonntagsschlüsse (abgeschlossene Wochen) -> (Tage, Werte)."""
    tage = np.asarray(tage, dtype=np.int64); p = np.asarray(p, dtype=float)
    m = (wochentag(tage) == 6) & np.isfinite(p)
    return tage[m], p[m]


def rsi_wilder(x: np.ndarray, n: int = 14) -> np.ndarray:
    """RSI nach Wilder (Startwert: einfaches Mittel der ersten n Änderungen, dann Glättung 1/n)."""
    x = np.asarray(x, dtype=float); out = np.full(len(x), np.nan)
    if len(x) <= n:
        return out
    d = np.diff(x); g = np.maximum(d, 0); v = np.maximum(-d, 0)
    ag = g[:n].mean(); av = v[:n].mean()
    for i in range(n, len(x)):
        if i > n:
            ag = (ag * (n - 1) + g[i - 1]) / n; av = (av * (n - 1) + v[i - 1]) / n
        out[i] = 100.0 if av == 0 and ag > 0 else (50.0 if av == 0 else 100.0 - 100.0 / (1.0 + ag / av))
    return out


def korrelation_rollierend(a: np.ndarray, b: np.ndarray, fenster: int, min_n: int) -> np.ndarray:
    """Pearson-Korrelation der letzten `fenster` Paare (beide gültig); NaN unter min_n Paaren."""
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float); out = np.full(len(a), np.nan)
    for i in range(len(a)):
        lo = max(0, i - fenster + 1)
        x = a[lo:i + 1]; y = b[lo:i + 1]; m = np.isfinite(x) & np.isfinite(y)
        if m.sum() < min_n:
            continue
        x = x[m]; y = y[m]; sx = x.std(); sy = y.std()
        if sx > 0 and sy > 0:
            out[i] = float(((x - x.mean()) * (y - y.mean())).mean() / (sx * sy))
    return out


def halving_tage() -> list:
    return [tag_ts(h) // TAG for h in HALVINGS]


def epoche(tage: np.ndarray) -> np.ndarray:
    """0 = vor dem ersten Halving, 1 = 2012–2016, … (Tag des Halvings gehört zur neuen Epoche)."""
    return np.searchsorted(np.array(halving_tage()), np.asarray(tage, dtype=np.int64), "right")


def powerlaw_monatlich(tage: np.ndarray, p: np.ndarray, erster_monat: str = "2011-01") -> dict:
    """
    Power Law log10(Kurs) = a + b · log10(Tage seit Genesis), KAUSAL: Für jeden Monat ab erster_monat wird mit allen Tagen
    VOR dem Monatsersten angepasst (Kleinste Quadrate); mit diesen Parametern bekommt jeder Tag des Monats sein Residuum,
    seine Lage in σ (Streuung der Residuen der Anpassung) und sein Perzentil unter allen Residuen bis zu diesem Tag.
    Liefert die Reihen und die Parameter je Monat (Exponent b mit Datum -- versioniert).
    """
    tage = np.asarray(tage, dtype=np.int64); p = np.asarray(p, dtype=float)
    n_all = len(p)
    ok = np.isfinite(p) & (p > 0) & (tage > GENESIS_TAG)
    x = np.where(ok, np.log10(np.maximum(tage - GENESIS_TAG, 1)), np.nan)
    y = np.where(ok, np.log10(np.where(ok, p, 1.0)), np.nan)
    rest = np.full(n_all, np.nan); sig = np.full(n_all, np.nan); pz = np.full(n_all, np.nan); fv = np.full(n_all, np.nan)
    # kumulierte Summen für die Anpassung über den Präfix
    xv = np.where(ok, x, 0.0); yv = np.where(ok, y, 0.0)
    cn = np.concatenate([[0], np.cumsum(ok)]); cx = np.concatenate([[0.0], np.cumsum(xv)]); cy = np.concatenate([[0.0], np.cumsum(yv)])
    cxx = np.concatenate([[0.0], np.cumsum(xv * xv)]); cxy = np.concatenate([[0.0], np.cumsum(xv * yv)])
    parameter = []
    # Monatsgrenzen auf der Achse
    monate = np.array([ts_tag(int(t) * TAG)[:7] for t in tage])
    grenzen = [i for i in range(n_all) if i == 0 or monate[i] != monate[i - 1]]
    grenzen.append(n_all)
    for g0, g1 in zip(grenzen[:-1], grenzen[1:]):
        monat = monate[g0]
        if monat < erster_monat:
            continue
        n = cn[g0]
        if n < 100:
            continue
        sx, sy, sxx, sxy = cx[g0], cy[g0], cxx[g0], cxy[g0]
        nenner = n * sxx - sx * sx
        if nenner <= 0:
            continue
        b = (n * sxy - sx * sy) / nenner
        a = (sy - b * sx) / n
        r_pre = (y[:g0] - (a + b * x[:g0]))
        r_pre = r_pre[np.isfinite(r_pre)]
        sd = float(np.sqrt(np.mean(r_pre ** 2))) if len(r_pre) else float("nan")
        parameter.append({"monat": monat, "a": float(a), "b": float(b), "sd": sd, "n": int(n)})
        sl = sorted(r_pre.tolist())
        for i in range(g0, g1):
            fv[i] = 10 ** (a + b * math.log10(max(int(tage[i]) - GENESIS_TAG, 1)))
            if not ok[i]:
                continue
            r = float(y[i] - (a + b * x[i]))
            bisect.insort(sl, r)
            rest[i] = r; sig[i] = r / sd if sd and sd > 0 else np.nan
            if len(sl) >= 365:
                pz[i] = _rang(sl, r)
    return {"rest": rest, "sigma": sig, "pz": pz, "fv_kausal": fv, "parameter": parameter}


def powerlaw_fit(tage: np.ndarray, p: np.ndarray) -> dict:
    """Anpassung über ALLE übergebenen Tage (beschreibend: Linie und Bänder im Chart) mit Quantilen der Residuen."""
    tage = np.asarray(tage, dtype=np.int64); p = np.asarray(p, dtype=float)
    ok = np.isfinite(p) & (p > 0) & (tage > GENESIS_TAG)
    x = np.log10(tage[ok] - GENESIS_TAG); y = np.log10(p[ok])
    if len(x) < 100:
        return {}
    b, a = np.polyfit(x, y, 1)
    r = y - (a + b * x)
    q = {f"q{k}": float(np.quantile(r, k / 100)) for k in (5, 25, 50, 75, 95)}
    return dict(a=float(a), b=float(b), sd=float(np.sqrt(np.mean(r ** 2))), n=int(len(x)), **q)


RIBBON_K = 3.0          # Rauschschwelle der Hash Ribbons in Einheiten σ/√60 (Simulation reines Rauschen: 0,7 % der Episoden darüber)


def hash_ribbons(tage: np.ndarray, hr: np.ndarray, p: np.ndarray) -> dict:
    """
    Hash Ribbons (Capriole 2019): Kapitulation, solange SMA30(Hashrate) < SMA60; Erholung beim Kreuz zurück nach oben;
    „Kaufsignal“ nach Capriole am ersten Tag danach, an dem SMA10(Kurs) > SMA20(Kurs). Je Episode Dauer und Tiefe
    (größte Lücke SMA30/SMA60 − 1).
    RAUSCHSCHWELLE (23.47): Die Tageshashrate von Coin Metrics schwankt durch Blockglück um rund 9 % (σ der Abweichung vom
    7-Tage-Mittel × √(7/6)). Bei reinem Rauschen ist SMA30/SMA60 − 1 etwa normal mit σ/√60; SMA30 fällt dann ständig kurz unter
    SMA60. „Echt“ ist eine Episode erst, wenn ihre Tiefe RIBBON_K · σ/√60 überschreitet (σ aus den 365 Tagen vor ihrem Beginn) --
    in der Simulation mit reinem Rauschen trifft das 0,7 % der Episoden (bei 2,5: 2,9 %). Flache Kreuzungen bleiben sichtbar
    gezählt, bekommen aber weder Fläche noch Signal.
    """
    h30 = sma(hr, 30); h60 = sma(hr, 60); p10 = sma(p, 10); p20 = sma(p, 20)
    with np.errstate(invalid="ignore", divide="ignore"):
        abw = np.log(np.asarray(hr, dtype=float) / sma(hr, 7, 5))
    kap = np.where(np.isfinite(h30) & np.isfinite(h60), h30 < h60, False)
    episoden = []; i = 0; n = len(hr)
    while i < n:
        if kap[i]:
            j = i
            while j < n and kap[j]:
                j += 1
            tiefe = float(np.nanmin(h30[i:j] / h60[i:j] - 1)) if j > i else 0.0
            vor = abw[max(0, i - 365):i]; vor = vor[np.isfinite(vor)]
            sigma = float(np.std(vor) * math.sqrt(7 / 6)) if len(vor) >= 60 else float("nan")
            schwelle = RIBBON_K * sigma / math.sqrt(60) if math.isfinite(sigma) else None          # zu wenig Vorlauf: kein Urteil
            erholt = j if j < n else None
            signal = None
            if erholt is not None:
                for k in range(erholt, n):
                    if kap[k]:
                        break
                    if math.isfinite(p10[k]) and math.isfinite(p20[k]) and p10[k] > p20[k]:
                        signal = k; break
            episoden.append({"von": int(tage[i]), "bis": int(tage[j - 1]), "tage": int(j - i), "tiefe": tiefe,
                             "schwelle": schwelle, "echt": bool(schwelle is not None and tiefe <= -schwelle),
                             "erholt": int(tage[erholt]) if erholt is not None else None,
                             "signal": int(tage[signal]) if signal is not None else None})
            i = j
        else:
            i += 1
    return {"h30": h30, "h60": h60, "kap": kap, "episoden": episoden}


RIBBON = (9, 14, 25, 40, 60, 90, 128, 200)


def difficulty_ribbon(diff: np.ndarray) -> dict:
    smas = {n: sma(diff, n) for n in RIBBON}
    m = np.vstack([smas[n] for n in RIBBON])
    with np.errstate(invalid="ignore", divide="ignore"):
        breite = np.where(np.all(np.isfinite(m), axis=0), m.max(axis=0) / m.min(axis=0) - 1, np.nan)
    return {"smas": smas, "breite": breite}


def miner_einheit(diff: np.ndarray, iss: np.ndarray, fee: np.ndarray, blk: np.ndarray) -> np.ndarray:
    """
    Stromkosten je BTC für 1 J/TH und 1 USD/kWh (USD/BTC): erwartete Hashes je Block = Difficulty · 2^32;
    Energie je Block = J/TH · Hashes / 1e12 / 3,6e6 kWh; Erlös je Block = (Emission + Gebühren) / Blöcke (7-Tage-Summen).
    Kosten (USD/BTC) = J/TH · Strompreis (USD/kWh) · Einheit. Prüfwert: D 1,318e14, Erlös 3,16 BTC -> 49.761.
    """
    iss = np.asarray(iss, float); fee = np.asarray(fee, float); blk = np.asarray(blk, float)
    ok = np.isfinite(iss) & np.isfinite(fee) & np.isfinite(blk) & (blk > 0)       # Zähler und Nenner über dieselben Tage
    with np.errstate(invalid="ignore", divide="ignore"):
        erl = summe_fenster(np.where(ok, iss + fee, np.nan), 7) / summe_fenster(np.where(ok, blk, np.nan), 7)
        e = np.asarray(diff, dtype=float) * 2 ** 32 / 1e12 / 3.6e6 / erl
    return np.where(np.isfinite(e) & (e > 0), e, np.nan)


def epochen_extreme(tage: np.ndarray, x: np.ndarray) -> list:
    """Maximum und Minimum je Halving-Epoche (beschreibend); die laufende Epoche mit „bisher“."""
    ep = epoche(tage); out = []
    for e in sorted(set(ep.tolist())):
        m = (ep == e) & np.isfinite(x)
        if m.sum() < 30:
            continue
        idx = np.nonzero(m)[0]
        i_max = idx[np.argmax(x[idx])]; i_min = idx[np.argmin(x[idx])]
        out.append({"epoche": int(e), "max_tag": int(tage[i_max]), "max": float(x[i_max]), "min_tag": int(tage[i_min]),
                    "min": float(x[i_min]), "laufend": bool(e == ep[-1])})
    return out


def divergenzen(tage: np.ndarray, p: np.ndarray, mvrv: np.ndarray, abstand: float = 0.05) -> list:
    """
    Bewertungsdivergenz (ungetestete Hypothese aus dem Bericht): ein neues Kurshoch der Epoche, während MVRV mindestens
    `abstand` unter seinem bisherigen Epochenhoch liegt. Kausal (laufende Maxima seit Epochenbeginn).
    """
    ep = epoche(tage); out = []; letzte_e = None; maxp = maxm = -math.inf
    for i in range(len(p)):
        if ep[i] != letzte_e:
            letzte_e = ep[i]; maxp = maxm = -math.inf
        if not (math.isfinite(p[i]) and math.isfinite(mvrv[i])):
            continue
        maxm = max(maxm, mvrv[i])
        if p[i] >= maxp:
            maxp = p[i]
            if maxm > 0 and mvrv[i] < (1 - abstand) * maxm and i > 0:
                out.append({"tag": int(tage[i]), "kurs": float(p[i]), "mvrv": float(mvrv[i]), "unter": float(1 - mvrv[i] / maxm)})
    return out


def _woche_werte(sonntage: np.ndarray, tage: np.ndarray, werte: np.ndarray, max_alter: int) -> np.ndarray:
    """Je Sonntag der letzte Wert am oder vor diesem Tag, höchstens max_alter Tage alt."""
    tage = np.asarray(tage, dtype=np.int64); werte = np.asarray(werte, dtype=float)
    m = np.isfinite(werte); tage = tage[m]; werte = werte[m]
    out = np.full(len(sonntage), np.nan)
    if not len(tage):
        return out
    k = np.searchsorted(tage, sonntage, "right") - 1
    for j, i in enumerate(k):
        if i >= 0 and sonntage[j] - tage[i] <= max_alter:
            out[j] = werte[i]
    return out


# ================================================================================================ Gesamtrechnung

class Reihen:
    """Rohreihen aus makro.db (Tage seit 1970, Werte)."""

    def __init__(self, con):
        self.con = con; self._c: dict = {}
        self.namen = [r[0] for r in con.execute("SELECT DISTINCT reihe FROM mk_reihe")]

    def __call__(self, name: str) -> tuple:
        if name not in self._c:
            rows = self.con.execute("SELECT ts, wert FROM mk_reihe WHERE reihe=? ORDER BY ts", (name,)).fetchall()
            if rows:
                a = np.array(rows, dtype=float)
                self._c[name] = ((a[:, 0] // TAG).astype(np.int64), a[:, 1])
            else:
                self._c[name] = (np.zeros(0, dtype=np.int64), np.zeros(0))
        return self._c[name]

    def bgm_feld(self, endpunkt: str) -> str | None:
        """Das Wertfeld eines BGeometrics-Endpunkts: bevorzugt der Name, der zum Endpunkt passt, sonst das erste."""
        felder = sorted(n for n in self.namen if n.startswith(f"bgm:{endpunkt}:"))
        if not felder:
            return None
        schluessel = endpunkt.replace("-", "").lower()
        for f in felder:
            if f.split(":", 2)[2].replace("_", "").lower() == schluessel:
                return f
        for f in felder:
            if f.split(":", 2)[2].lower() not in ("price", "btcprice", "close", "pricebtc"):
                return f
        return felder[0]


def _auf(achse0: int, n: int, tage: np.ndarray, werte: np.ndarray) -> np.ndarray:
    out = np.full(n, np.nan)
    i = np.asarray(tage, dtype=np.int64) - achse0
    m = (i >= 0) & (i < n)
    out[i[m]] = np.asarray(werte, dtype=float)[m]
    return out


def _ohne_anlauf(mv: np.ndarray) -> np.ndarray:
    """MVRV der ersten MVRV_ANLAUF_TAGE nach dem ersten Wert verwerfen: Coin Metrics bewertet ältere Münzen zum ersten Kurs
    der Reihe, die realisierte Kapitalisierung läuft erst an (BTC: MVRV 146 am 18.07.2010, ab August unter 10, im November 2010
    noch 8,2). Ein halbes Jahr Anlauf; BTC gilt damit ab 14.01.2011 -- die Zyklustabelle des Berichts beginnt ebenfalls 2011."""
    mv = np.asarray(mv, dtype=float).copy()
    g = np.nonzero(np.isfinite(mv))[0]
    if len(g):
        mv[: g[0] + MVRV_ANLAUF_TAGE] = np.nan
    return mv


def oi_abdeckung(con) -> dict:
    """
    23.50: Open Interest ab 01.09.2020 -- vorhandene Tage, Abschnitte ohne Lücke, fehlende Tage und wie viele das Archiv noch holt
    (fehlende Tage unterhalb des Rückwärts-Cursors; darüber liegen nur 404-Tage, die es nicht nochmals versucht). Dauer bei einem
    Tag je Takt (20 s) -- eine Annahme, keine Messung.
    """
    start = tag_ts(OI_ARCHIV_START) // TAG
    try:
        tage = [int(r[0]) // TAG for r in con.execute("SELECT ts FROM mk_reihe WHERE reihe='bnc:oi_btc_usd' AND ts >= ? ORDER BY ts",
                                                       (start * TAG,))]
        m = dict(con.execute("SELECT k, v FROM mk_meta WHERE k LIKE 'oi_archiv%' OR k = 'oi_rest_erster'").fetchall())
    except sqlite3.Error:
        tage, m = [], {}
    abschnitte: list = []
    for t in tage:
        if abschnitte and t == abschnitte[-1][1] + 1:
            abschnitte[-1][1] = t; abschnitte[-1][2] += 1
        else:
            abschnitte.append([t, t, 1])
    fertig = m.get("oi_archiv_fertig") == "1"
    soll = (tage[-1] - start + 1) if tage else 0
    rueck = int(m["oi_archiv_rueck"]) // TAG if m.get("oi_archiv_rueck") else None
    if rueck is None and m.get("oi_rest_erster"):
        rueck = int(m["oi_rest_erster"]) // TAG - 1
    da = set(tage)
    offen = 0 if fertig or rueck is None else sum(1 for t in range(start, rueck + 1) if t not in da)
    fehlen = max(0, soll - len(tage))
    return {"tage": len(tage), "soll": soll, "fehlen": fehlen, "offen": offen, "fertig": fertig,
            "lueckenhaft": not fertig and fehlen > max(10, 0.02 * soll),
            "rueck": ts_tag(rueck * TAG) if rueck is not None and rueck >= start else None,
            "fehlend_404": int(m.get("oi_archiv_fehlend", 0) or 0), "eta_h": round(offen * TAKT_S / 3600, 1), "takt_s": TAKT_S,
            "abschnitte": [{"von": ts_tag(a * TAG), "bis": ts_tag(b * TAG), "n": n} for a, b, n in abschnitte[-4:]],
            "n_abschnitte": len(abschnitte)}


def ableiten(con, heute_tag: int | None = None) -> dict:
    """Alle Treiber auf der Tagesachse ab dem ersten BTC-Kurs (18.07.2010) bis zum jüngsten Datentag."""
    R = Reihen(con)
    t_p, w_p = R("cm:btc:PriceUSD")
    if len(t_p) < 400:
        return {"ok": False, "grund": "zu wenig BTC-Kursdaten (Coin Metrics noch nicht abgerufen)", "namen": R.namen}
    heute_tag = heute_tag if heute_tag is not None else int(time.time()) // TAG
    d0 = int(t_p[0])
    ende = int(t_p[-1])
    for name in R.namen:
        if name.startswith(("fng:", "drb:", "bnc:funding", "llama:", "bgm:", "fs:", "bc:difficulty")):
            tt, _ = R(name)
            if len(tt):
                ende = max(ende, min(int(tt[-1]), heute_tag))
    n = ende - d0 + 1
    tage = np.arange(d0, ende + 1, dtype=np.int64)
    A = lambda name: _auf(d0, n, *R(name))
    out: dict = {"ok": True, "d0": d0, "n": n, "tage": tage, "namen": R.namen, "R": R}

    # --- Bewertung BTC ---------------------------------------------------------------------------------------
    P = A("cm:btc:PriceUSD"); MC = A("cm:btc:CapMrktCurUSD"); MV = _ohne_anlauf(A("cm:btc:CapMVRVCur")); S = A("cm:btc:SplyCur")
    with np.errstate(invalid="ignore", divide="ignore"):
        RC = MC / MV
        RP = RC / S
        NUPL = 1 - 1 / MV
    AC = mittel_expandierend(MC)
    with np.errstate(invalid="ignore", divide="ignore"):
        DP = (RC - AC) / S
    out.update(P=P, MC=MC, MVRV=MV, S=S, RC=RC, RP=RP, NUPL=NUPL, DELTA=DP)
    out["MVRV_PZ"] = perzentil_expandierend(MV, 365)
    out["MVRV_PZ4"] = perzentil_rollierend(MV, 1461, 365)
    with np.errstate(invalid="ignore", divide="ignore"):
        out["MVRV_Z"] = (MC - RC) / streuung_expandierend(MC)
    out["MVRV_Z"][: min(n, 365)] = np.nan
    out["EXTREME"] = epochen_extreme(tage, MV)
    out["DIVERGENZ"] = divergenzen(tage, P, MV)

    # --- Trend --------------------------------------------------------------------------------------------------
    pl = powerlaw_monatlich(tage, P)
    out["PL"] = pl
    out["PL_FIT"] = powerlaw_fit(tage, P)
    f = out["PL_FIT"]
    if f:
        out["FV"] = 10 ** (f["a"] + f["b"] * np.log10(np.maximum(tage - GENESIS_TAG, 1)))
    else:
        out["FV"] = np.full(n, np.nan)
    out["WMA"] = wma200(tage, P)
    with np.errstate(invalid="ignore", divide="ignore"):
        out["WMA_ABST"] = P / out["WMA"] - 1
    out["WMA_ABST_PZ"] = perzentil_expandierend(out["WMA_ABST"], 365)
    st, sw = wochen_schluss(tage, P)
    out["RSI_W"] = {"tage": st, "werte": rsi_wilder(sw, 14)}

    # --- Kohorten (BGeometrics) ---------------------------------------------------------------------------------
    bg = {}
    for ep in BGM:
        feld = R.bgm_feld(ep)
        bg[ep] = A(feld) if feld else np.full(n, np.nan)
        out.setdefault("BGM_FELD", {})[ep] = feld
    out["BGM"] = bg
    out["AVIV_Z"] = z_expandierend(bg["aviv"], 180)
    out["STH_MVRV_PZ"] = perzentil_expandierend(bg["sth-mvrv"], 180)

    # --- Miner --------------------------------------------------------------------------------------------------
    iss_usd = A("cm:btc:IssTotUSD")
    out["PUELL"] = iss_usd / sma(iss_usd, 365)
    ep_ = epoche(tage); pz = np.full(n, np.nan)
    for e in sorted(set(ep_.tolist())):
        m = ep_ == e
        pz[m] = perzentil_expandierend(out["PUELL"][m], 30)
    out["PUELL_PZ"] = pz
    HR = A("cm:btc:HashRate")
    out["HR"] = HR
    out["RIBBONS"] = hash_ribbons(tage, HR, P)
    diff = ffill(A("bc:difficulty"), 20)
    out["DIFF"] = diff
    out["DRIBBON"] = difficulty_ribbon(diff)
    out["MINER_E"] = miner_einheit(diff, A("cm:btc:IssTotNtv"), A("cm:btc:FeeTotNtv"), A("cm:btc:BlkCnt"))
    out["EURUSD"] = ffill(A("fred:DEXUSEU"), 7)
    with np.errstate(invalid="ignore", divide="ignore"):
        kosten = MINER_STANDARD["jth"] * MINER_STANDARD["ct"] / 100 * out["MINER_E"]
        out["MINER_VERH"] = P / kosten
    hr_bc = A("bc:hashrate")
    with np.errstate(invalid="ignore", divide="ignore"):
        out["HR_GEGENPROBE"] = sma(HR, 7, 5) / sma(hr_bc, 7, 5)

    # --- Hebel und Stimmung --------------------------------------------------------------------------------------
    fund = A("bnc:funding_btc_tag") * 365 * 100                     # Tagessumme der Raten -> % p. a.
    out["FUNDING"] = fund; out["FUNDING30"] = sma(fund, 30, 20)
    out["FUNDING30_PZ"] = perzentil_expandierend(out["FUNDING30"], 365)
    oi = A("bnc:oi_btc_usd")
    with np.errstate(invalid="ignore", divide="ignore"):
        out["OI_MC"] = oi / MC * 100
    out["OI"] = oi
    out["OI_MC_PZ"] = perzentil_expandierend(out["OI_MC"], 365)
    out["OI_ABDECKUNG"] = oi_abdeckung(con)                         # 23.50: Archiv lädt noch? (Chart-Hinweis, Zonenkarte)
    out["DVOL"] = A("drb:dvol_btc"); out["DVOL_PZ"] = perzentil_expandierend(out["DVOL"], 180)
    fng = A("fng:wert"); out["FNG"] = fng; out["FNG30"] = sma(fng, 30, 20)
    out["FNG30_PZ"] = perzentil_expandierend(out["FNG30"], 365)

    # --- Kapitalfluss ---------------------------------------------------------------------------------------------
    stab = A("llama:stable_usd"); out["STABLE"] = stab
    with np.errstate(invalid="ignore", divide="ignore"):
        out["SSR"] = MC / stab
    out["SSR_PZ"] = perzentil_expandierend(out["SSR"], 365)
    for c in ("btc", "eth"):
        fl = A(f"fs:etf_{c}")
        if np.isfinite(fl).any():
            erst = int(np.nonzero(np.isfinite(fl))[0][0])
            kum = np.full(n, np.nan); kum[erst:] = np.cumsum(np.where(np.isfinite(fl[erst:]), fl[erst:], 0.0))
        else:
            kum = np.full(n, np.nan)
        out[f"ETF_{c.upper()}"] = fl; out[f"ETF_{c.upper()}_KUM"] = kum; out[f"ETF_{c.upper()}_30"] = summe_fenster(fl, 30)

    # --- Halving-Zyklen -------------------------------------------------------------------------------------------
    zyklen = []
    for h in halving_tage():
        i0 = h - d0
        if i0 < 0 or i0 >= n or not math.isfinite(P[i0]):
            continue
        i1 = min(n, i0 + 1461)
        zyklen.append({"halving": ts_tag(h * TAG), "werte": P[i0:i1] / P[i0]})
    out["ZYKLEN"] = zyklen
    letzter_h = max([h for h in halving_tage() if h <= ende] or [halving_tage()[0]])
    out["HALVING_TAG"] = int(ende - letzter_h)

    # --- Makro (Wochenbasis, Sonntage) -------------------------------------------------------------------------------
    out["MAKRO"] = makro_rechnen(R, tage, P)
    # --- 23.67 (U153): Arbeitsmarkt und Preise der USA (nur Anzeige) ---------------------------------------------------
    try:
        so_tage, so_p = wochen_schluss(tage, P)
        btc_w = np.concatenate([[np.nan], np.diff(np.log(so_p))]) if len(so_p) else np.array([])
        out["USA"] = usa_rechnen(R, tage, P, so_tage, btc_w)
    except Exception as e:                                                   # ein Fehler hier reißt die übrigen Charts nicht mit
        out["USA"] = {}; out["USA_FEHLER"] = f"{type(e).__name__}: {e}"
    out["USA_TERMINE"] = usa_termine(con)
    try:                                                                     # 23.127 (U316): Zielspanne der Fed für den Chart „Leitzins“
        out["FED"] = fed_stand(con, R, (out.get("MAKRO") or {}).get("tage"))
    except Exception as e:                                                   # reißt die übrigen Charts nicht mit
        out["FED"] = {"fehler": f"{type(e).__name__}: {e}"}

    # --- weitere Coins: Bewertung und 200-Wochen-MA ------------------------------------------------------------------
    coins = {}
    for c in ("eth", "zec", "xmr"):
        tc, pc = R(f"cm:{c}:PriceUSD")
        if len(tc) < 400:
            continue
        cd0 = int(tc[0]); cn = int(min(tc[-1], ende)) - cd0 + 1
        ctage = np.arange(cd0, cd0 + cn, dtype=np.int64)
        Ac = lambda name: _auf(cd0, cn, *R(name))
        cp = Ac(f"cm:{c}:PriceUSD"); cmc = Ac(f"cm:{c}:CapMrktCurUSD"); cmv = _ohne_anlauf(Ac(f"cm:{c}:CapMVRVCur")); cs = Ac(f"cm:{c}:SplyCur")
        e = {"d0": cd0, "n": cn, "P": cp, "WMA": wma200(ctage, cp)}
        with np.errstate(invalid="ignore", divide="ignore"):
            e["WMA_ABST"] = cp / e["WMA"] - 1
        if np.isfinite(cmv).sum() > 400:
            with np.errstate(invalid="ignore", divide="ignore"):
                crc = cmc / cmv
                e.update(MVRV=cmv, RP=crc / cs, MVRV_PZ=perzentil_expandierend(cmv, 365), MVRV_PZ4=perzentil_rollierend(cmv, 1461, 365),
                         MVRV_Z=(cmc - crc) / streuung_expandierend(cmc))
            e["MVRV_Z"][: min(cn, 365)] = np.nan
        coins[c.upper()] = e
    out["COINS"] = coins
    return out


def makro_rechnen(R: Reihen, tage: np.ndarray, P: np.ndarray) -> dict:
    """
    Makro als Kulisse: Wochenwerte je Sonntag, Veränderung je Woche (Mengen logarithmisch, Zinsen/Spreads als Differenz),
    rollierende Korrelation mit der BTC-Wochenrendite (52 Wochen, mindestens 40 Paare; M2 monatlich: 24 Monate).
    Regimelabel aus jüngster Korrelation, Mittel 2020–2022 und dem Zufallsband ±2/√n.
    """
    so_tage, so_p = wochen_schluss(tage, P)
    if len(so_tage) < 60:
        return {}
    btc_r = np.concatenate([[np.nan], np.diff(np.log(so_p))])
    W = lambda name, alter: _woche_werte(so_tage, *R(name), alter)
    walcl = W("fred:WALCL", 10); tga = W("fred:WTREGEN", 10); rrp = W("fred:RRPONTSYD", 7)
    rrp = np.where(np.isfinite(rrp), rrp, np.where(so_tage < tag_ts("2013-09-23") // TAG, 0.0, np.nan))   # ON RRP erst ab 2013
    netliq = (walcl - tga - rrp * 1000) / 1e6                                                              # Bio USD
    ecb = W("fred:ECBASSETSW", 10); eur = W("fred:DEXUSEU", 7); boj = W("fred:JPNASSETS", 45); jpy = W("fred:DEXJPUS", 7)
    glob = (walcl + ecb * eur + boj * 100 / jpy) / 1e6
    reihen = {
        "netliq": {"titel": "US-Nettoliquidität (Fed-Bilanz − TGA − Reverse Repo)", "einheit": "Bio USD", "werte": netliq, "art": "log"},
        "global": {"titel": "Globaler Liquiditätsproxy Fed + EZB + BoJ (Veränderung zum Vorjahr)", "einheit": "%", "werte": glob, "art": "log", "yoy": True},
        "realzins": {"titel": "Realzins 10 Jahre (TIPS)", "einheit": "%", "werte": W("fred:DFII10", 7), "art": "diff"},
        "dollar": {"titel": "Dollar breit (Handelsgewichtet)", "einheit": "Index", "werte": W("fred:DTWEXBGS", 7), "art": "log"},
        "hy": {"titel": "Hochzinsspread (ICE BofA US High Yield)", "einheit": "%", "werte": W("fred:BAMLH0A0HYM2", 7), "art": "diff"},
        "leitzins": {"titel": "Leitzins effektiv (Fed Funds)", "einheit": "%", "werte": W("fred:DFF", 7), "art": "diff"},
    }
    out = {"tage": so_tage, "btc_r": btc_r}
    alt = (so_tage >= tag_ts("2020-01-01") // TAG) & (so_tage < tag_ts("2023-01-01") // TAG)
    for k, r in reihen.items():
        w = r["werte"]
        with np.errstate(invalid="ignore", divide="ignore"):
            if r.get("yoy"):
                anz = np.full(len(w), np.nan); anz[52:] = (w[52:] / w[:-52] - 1) * 100
            else:
                anz = w
            ch = np.concatenate([[np.nan], np.diff(np.log(w)) if r["art"] == "log" else np.diff(w)])
        kor = korrelation_rollierend(ch, btc_r, 52, 40)
        r.update(anzeige=anz, korr=kor, **_regime(kor, alt, 52))
        out[k] = r
    # M2 monatlich: Veränderung zum Vorjahr; Korrelation der Monatsänderungen mit der BTC-Monatsrendite über 24 Monate
    tm, wm = R("fred:M2SL")
    if len(tm) > 30:
        btc_m = _woche_werte(tm, tage, P, 7)                                   # Kurs am Monatsersten (M2SL ist auf den Ersten datiert)
        with np.errstate(invalid="ignore", divide="ignore"):
            yoy = np.full(len(wm), np.nan); yoy[12:] = (wm[12:] / wm[:-12] - 1) * 100
            ch = np.concatenate([[np.nan], np.diff(np.log(wm))]); br = np.concatenate([[np.nan], np.diff(np.log(btc_m))])
        kor = korrelation_rollierend(ch, br, 24, 18)
        altm = (tm >= tag_ts("2020-01-01") // TAG) & (tm < tag_ts("2023-01-01") // TAG)
        out["m2"] = {"titel": "US-Geldmenge M2 (Veränderung zum Vorjahr)", "einheit": "%", "tage": tm, "anzeige": yoy, "korr": kor,
                     "monatlich": True, **_regime(kor, altm, 24)}
    return out


def _monat_von_tag(tage) -> np.ndarray:
    """Tage seit 1970 -> Monate seit 1970-01 (0 = Januar 1970)."""
    return np.asarray(tage, dtype=np.int64).astype("datetime64[D]").astype("datetime64[M]").astype(np.int64)


def _tag_von_monat(monate) -> np.ndarray:
    return np.asarray(monate, dtype=np.int64).astype("datetime64[M]").astype("datetime64[D]").astype(np.int64)


def monatsgitter(t: np.ndarray, w: np.ndarray, m0: int | None = None, m1: int | None = None) -> tuple:
    """Monatsreihe (auf den Ersten datiert) auf ein lückenloses Monatsgitter; fehlende Monate NaN (nie gefüllt).
    -> (Monate, Werte)."""
    m = _monat_von_tag(t)
    if not len(m):
        return np.array([], dtype=np.int64), np.array([])
    m0 = int(m.min()) if m0 is None else m0; m1 = int(m.max()) if m1 is None else m1
    g = np.arange(m0, m1 + 1, dtype=np.int64); v = np.full(len(g), np.nan)
    ok = (m >= m0) & (m <= m1)
    v[m[ok] - m0] = np.asarray(w, dtype=float)[ok]
    return g, v


def _versatz(v: np.ndarray, k: int) -> np.ndarray:
    out = np.full(len(v), np.nan)
    if k < len(v):
        out[k:] = v[:-k]
    return out


def usa_rechnen(R, tage: np.ndarray, P: np.ndarray, so_tage: np.ndarray | None = None, btc_w: np.ndarray | None = None) -> dict:
    """
    23.67 (U153): Arbeitsmarkt und Preise der USA (nur Anzeige). Monatsreihen auf dem Monatsgitter: Vorjahresrate wie BLS aus den
    nicht bereinigten Reihen, Monatsrate aus den bereinigten, Stellen als Veränderung zum Vormonat mit 3-Monats-Mittel; Lücken
    bleiben NaN (eine Rate über eine Lücke fehlt). Erstanträge wöchentlich als 4-Wochen-Mittel (nur bei vier lückenlosen Wochen).
    Korrelation wie M2 (Monatsänderung gegen BTC-Monatsrendite, 24 Monate) bzw. wie die Wochenreihen (52 Wochen).
    """
    out = {}
    M = {sid: R(f"fred:{sid}") for sid in FRED_USA}
    mon = [sid for sid in FRED_USA if sid != "ICSA" and len(M[sid][0])]
    if mon:
        m0 = min(int(_monat_von_tag(M[s][0]).min()) for s in mon); m1 = max(int(_monat_von_tag(M[s][0]).max()) for s in mon)
        g = np.arange(m0, m1 + 1, dtype=np.int64); gt = _tag_von_monat(g)
        V = {s: monatsgitter(*M[s], m0, m1)[1] for s in mon}
        btc_m = _woche_werte(gt, tage, P, 7)                                    # Kurs am Monatsersten
        with np.errstate(invalid="ignore", divide="ignore"):
            br = np.log(btc_m) - _versatz(np.log(btc_m), 1)
        altm = (gt >= tag_ts("2020-01-01") // TAG) & (gt < tag_ts("2023-01-01") // TAG)

        def luecken(s):
            v = V[s]; ok = np.nonzero(np.isfinite(v))[0]
            if not len(ok):
                return []
            return [str(np.datetime64(int(g[i]), "M")) for i in range(ok[0], ok[-1] + 1) if not np.isfinite(v[i])]

        def eintrag(key, titel, einheit, linien, korr_ch=None, unter="", quelle="fred_usa", termine=(), null=False, nk=1):
            e = {"titel": titel, "einheit": einheit, "tage": gt, "linien": linien, "monatlich": True, "unter": unter,
                 "quelle": quelle, "termine": list(termine), "null": null, "nk": nk}
            lk = sorted({x for ln in linien for x in ln.get("luecken", [])})
            e["luecken"] = lk
            if korr_ch is not None:
                kor = korrelation_rollierend(korr_ch, br, 24, 18)
                e.update(korr=kor, **_regime(kor, altm, 24))
            out[key] = e

        with np.errstate(invalid="ignore", divide="ignore"):
            if "UNRATE" in V:
                u = V["UNRATE"]
                eintrag("alq", "Arbeitslosenquote", "%", [{"n": "Arbeitslosenquote", "v": u, "luecken": luecken("UNRATE")}],
                        korr_ch=u - _versatz(u, 1), termine=("Arbeitsmarktbericht",))
            if "PAYEMS" in V:
                p = V["PAYEMS"]; d = p - _versatz(p, 1)
                d3 = (d + _versatz(d, 1) + _versatz(d, 2)) / 3
                eintrag("stellen", "Neue Stellen je Monat (außerhalb der Landwirtschaft)", "Tsd.",
                        [{"n": "Veränderung zum Vormonat", "v": d, "kurz": "Monat", "luecken": luecken("PAYEMS")},
                         {"n": "3-Monats-Mittel", "v": d3, "kurz": "3 M"}],
                        korr_ch=d, termine=("Arbeitsmarktbericht",), null=True,
                        unter="Stellen werden zweimal nachträglich korrigiert und einmal im Jahr neu verankert")
            jahr = [(s, n) for s, n in (("CPIAUCNS", "Verbraucherpreise"), ("CPILFENS", "ohne Lebensmittel und Energie"),
                                        ("PPIFID", "Erzeugerpreise")) if s in V]
            if jahr:
                eintrag("preise_jahr", "Preise: Vorjahresrate (wie BLS, nicht bereinigt)", "%",
                        [{"n": n, "v": (V[s] / _versatz(V[s], 12) - 1) * 100, "kurz": n.split()[0], "luecken": luecken(s)} for s, n in jahr],
                        termine=("Verbraucherpreise", "Erzeugerpreise"), null=True)
            monat = [(s, n) for s, n in (("CPIAUCSL", "Verbraucherpreise"), ("CPILFESL", "ohne Lebensmittel und Energie"),
                                         ("PPIFIS", "Erzeugerpreise")) if s in V]
            if monat:
                mm = {s: (V[s] / _versatz(V[s], 1) - 1) * 100 for s, _ in monat}
                k0 = monat[0][0]
                eintrag("preise_monat", "Preise: Veränderung zum Vormonat (saisonbereinigt)", "%",
                        [{"n": n, "v": mm[s], "kurz": n.split()[0], "luecken": luecken(s)} for s, n in monat],
                        korr_ch=np.log(V[k0]) - _versatz(np.log(V[k0]), 1), termine=("Verbraucherpreise", "Erzeugerpreise"), null=True, nk=2)
    t_i, w_i = M["ICSA"]
    if len(t_i) >= 8 and so_tage is not None and btc_w is not None:
        t_i = np.asarray(t_i, dtype=np.int64); w_i = np.asarray(w_i, dtype=float)
        a4 = np.full(len(w_i), np.nan)
        for i in range(3, len(w_i)):
            if t_i[i] - t_i[i - 3] == 21:                                       # vier aufeinanderfolgende Wochen
                a4[i] = float(np.mean(w_i[i - 3:i + 1])) / 1000
        aw = _woche_werte(so_tage, t_i, w_i, 7)                                 # Sonntag -> Samstag davor
        with np.errstate(invalid="ignore", divide="ignore"):
            ch = np.log(aw) - _versatz(np.log(aw), 1)
        kor = korrelation_rollierend(ch, btc_w, 52, 40)
        altw = (so_tage >= tag_ts("2020-01-01") // TAG) & (so_tage < tag_ts("2023-01-01") // TAG)
        out["antraege"] = {"titel": "Erstanträge auf Arbeitslosenhilfe (4-Wochen-Mittel)", "einheit": "Tsd.", "tage": t_i,
                           "linien": [{"n": "4-Wochen-Mittel", "v": a4}], "monatlich": False, "unter": "", "quelle": "fred_usa",
                           "termine": ["Erstanträge"], "null": False, "luecken": [],
                           "korr": kor, "korr_tage": so_tage, **_regime(kor, altw, 52)}
    return out


def usa_termine(con, jetzt: float | None = None) -> dict:
    """23.67 (U153): Termine aus mk_termin mit den Namen der Reihen (USA_TERMIN_REIHEN): nächster je Veröffentlichung, die der
    nächsten 14 Tage, Zahl der gespeicherten. Uhrzeit 8:30 New York (alle vier)."""
    jetzt = time.time() if jetzt is None else jetzt
    namen = {}
    for sid, de in USA_TERMIN_REIHEN.items():
        try:
            rid = int(json.loads(meta(con, f"release:{sid}") or "{}").get("id"))
        except (ValueError, TypeError):
            continue
        namen[rid] = de
    out = {"naechste": {}, "vierzehn": [], "n": 0, "namen": {str(k): v for k, v in namen.items()}}
    try:
        zeilen = con.execute("SELECT release, tag FROM mk_termin ORDER BY tag").fetchall()
    except sqlite3.Error:
        return out
    out["n"] = sum(1 for rid, _t in zeilen if rid in namen)               # 23.127: nur die vier der USA (mk_termin führt jetzt mehr)
    for rid, tag in zeilen:
        if rid not in namen:
            continue
        ts = ny830_utc(int(tag))
        if ts >= jetzt:
            out["naechste"].setdefault(namen[rid], ts)
            if ts <= jetzt + 14 * TAG:
                out["vierzehn"].append({"name": namen[rid], "ts": ts})
    return out


# 23.68 (U172): Hinweis an Datentagen -- nur an Tagen mit Verbraucherpreisen oder Arbeitsmarktbericht (Effekt belegt, U154);
# Erzeugerpreise und Erstanträge ohne Hinweis (kein Effekt gemessen). Nur Anzeige, wirkt auf nichts.
DATENTAG_REIHEN = {"CPIAUCSL": "H1", "UNRATE": "H2"}
DATENTAG_NACH_S = 2 * 3600            # bis zwei Stunden nach 8:30 New York (das Fenster der Studie, 8:30–10:30)


def datentag_stand(con) -> dict | None:
    """Stand der Datentage-Studie (mk_meta „datentage:stand“, abgelegt von hl_datentage --studie) oder None."""
    try:
        st = json.loads(meta(con, "datentage:stand") or "null")
    except (ValueError, TypeError):
        return None
    return st if isinstance(st, dict) else None


def datentag_info(pfad: str, jetzt: float | None = None) -> dict:
    """
    23.68 (U172): Termine mit Verbraucherpreisen oder Arbeitsmarktbericht von 3 h vor jetzt bis 2 Tage danach (8:30 New York in
    UTC) und der Stand der Studie. Welcher Tag „heute“ ist (ab 00:00 Ortszeit) und dass der Hinweis 2 h nach dem Termin endet,
    entscheidet die Seite in der Zeitzone des Geräts.
    """
    jetzt = time.time() if jetzt is None else jetzt
    out = {"termine": [], "stand": None, "nach_s": DATENTAG_NACH_S, "jetzt": int(jetzt)}
    con = lesen(pfad)
    if con is None:
        return out
    try:
        out["stand"] = datentag_stand(con)
        for sid, h in DATENTAG_REIHEN.items():
            try:
                rid = int(json.loads(meta(con, f"release:{sid}") or "{}").get("id"))
            except (ValueError, TypeError):
                continue
            try:
                tage = [int(t) for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=? AND tag BETWEEN ? AND ? ORDER BY tag",
                                                       (rid, int(jetzt) - 2 * TAG, int(jetzt) + 3 * TAG))]
            except sqlite3.Error:
                tage = []
            for t in tage:
                ts = ny830_utc(t)
                if jetzt - DATENTAG_NACH_S - 3600 <= ts <= jetzt + 2 * TAG:
                    out["termine"].append({"reihe": sid, "h": h, "name": USA_TERMIN_REIHEN[sid], "ts": ts})
    finally:
        con.close()
    out["termine"].sort(key=lambda e: (e["ts"], e["reihe"]))
    return out


def _regime(kor: np.ndarray, alt_maske: np.ndarray, fenster: int) -> dict:
    gueltig = np.nonzero(np.isfinite(kor))[0]
    jetzt = float(kor[gueltig[-1]]) if len(gueltig) else None
    alt = float(np.nanmean(kor[alt_maske])) if np.isfinite(kor[alt_maske]).any() else None
    band = 2 / math.sqrt(fenster)
    if jetzt is None:
        text = "zu wenig Daten für eine Korrelation"
    else:
        einheit = "Monate" if fenster == 24 else "Wochen"
        text = f"Korrelation {fenster} {einheit}: {jetzt:+.2f}".replace(".", ",")
        text += " — innerhalb des Zufallsbands ±" + f"{band:.2f}".replace(".", ",") + ", kein belegter Zusammenhang" if abs(jetzt) < band else ""
        if alt is not None:
            text += f"; 2020–2022 im Mittel {alt:+.2f}".replace(".", ",")
            if jetzt * alt < 0 and abs(jetzt) >= band and abs(alt) >= band:
                text += " — Vorzeichen gedreht"
    return {"korr_jetzt": jetzt, "korr_alt": alt, "band": band, "regime": text}


# ================================================================================================ Zonenkarte

def _letzt(x: np.ndarray, tage: np.ndarray) -> tuple:
    g = np.nonzero(np.isfinite(x))[0]
    if not len(g):
        return None, None
    return float(x[g[-1]]), int(tage[g[-1]])


def _einordnung(pz: float | None) -> str:
    if pz is None:
        return ""
    if pz < 10:
        return "unterstes Zehntel"
    if pz < 33.3:
        return "unteres Drittel"
    if pz < 66.7:
        return "mittleres Drittel"
    if pz < 90:
        return "oberes Drittel"
    return "oberstes Zehntel"


def _seit(x: np.ndarray, tage: np.ndarray, min_n: int = 0) -> str:
    """Bezug eines Perzentils: erster Tag, ab dem es gilt (min_n gültige Werte), als „seit MM/JJJJ“."""
    g = np.nonzero(np.isfinite(x))[0]
    if len(g) <= min_n:
        return ""
    return "seit " + time.strftime("%m/%Y", time.gmtime(int(tage[g[min_n]]) * TAG))


def zonenkarte(D: dict, live: dict | None = None) -> list:
    """Je Treiber: jüngster Wert, Perzentil der eigenen Historie (Bezug genannt), Datum, Einordnung; „jetzt“ mit Live-Kurs."""
    if not D.get("ok"):
        return []
    tage = D["tage"]; zeilen = []
    lp = (live or {}).get("btc")

    def zeile(key, name, wert, tag, pz, bezug, fmt, jetzt=None, jetzt_pz=None, text=""):
        zeilen.append({"key": key, "name": name, "wert": wert, "tag": tag, "pz": pz, "bezug": bezug, "fmt": fmt,
                       "jetzt": jetzt, "jetzt_pz": jetzt_pz, "einordnung": _einordnung(pz if jetzt_pz is None else jetzt_pz), "text": text})

    # MVRV und Realized Price
    mv, t = _letzt(D["MVRV"], tage); pz, _ = _letzt(D["MVRV_PZ"], tage); rp, _ = _letzt(D["RP"], tage)
    if mv is not None:
        j = lp / rp if lp and rp else None
        zeile("mvrv", "MVRV (Kurs ÷ Realized Price)", mv, t, pz, _seit(D["MVRV"], tage), "x2", j, rang_in(D["MVRV"], j) if j else None,
              f"Realized Price {_zahl(rp, 0)} USD · NUPL {_zahl(1 - 1 / mv, 2)}")
    # Power Law: Wert und Perzentil kausal (Anpassung bis Vormonat); „jetzt“ mit denselben Parametern
    r, t = _letzt(D["PL"]["rest"], tage); pz, _ = _letzt(D["PL"]["pz"], tage); s, _ = _letzt(D["PL"]["sigma"], tage)
    if r is not None:
        j = jpz = None
        par = D["PL"]["parameter"][-1] if D["PL"]["parameter"] else None
        if lp and par:
            heute = int(time.time()) // TAG
            j = lp / 10 ** (par["a"] + par["b"] * math.log10(heute - GENESIS_TAG))
            jpz = rang_in(D["PL"]["rest"], math.log10(j))
        zeile("pl", "Power Law: Kurs ÷ Fair Value", 10 ** r, t, pz, _seit(D["PL"]["pz"], tage), "x2", j, jpz,
              (f"Lage {s:+.2f} σ".replace(".", ",") if s is not None else "") + (f" · Exponent {par['b']:.3f}".replace(".", ",") if par else ""))
    # 200-Wochen-MA
    a, t = _letzt(D["WMA_ABST"], tage); pz, _ = _letzt(D["WMA_ABST_PZ"], tage); wma, _ = _letzt(D["WMA"], tage)
    if a is not None:
        j = lp / wma - 1 if lp and wma else None
        zeile("wma", "Abstand zum 200-Wochen-MA", a, t, pz, _seit(D["WMA_ABST_PZ"], tage), "pct", j,
              rang_in(D["WMA_ABST"], j) if j is not None else None, f"200-Wochen-MA {_zahl(wma, 0)} USD")
    # Regimelinien (BGeometrics)
    for ep, key, name in (("sth-realized-price", "sth", "Kurzfrist-Kostenbasis (STH)"), ("true-market-mean", "tmm", "True Market Mean")):
        lin, t = _letzt(D["BGM"][ep], tage)
        if lin is not None:
            p_t = D["P"][t - D["d0"]] if 0 <= t - D["d0"] < D["n"] else float("nan")
            ueber = p_t / lin - 1 if math.isfinite(p_t) else None
            j = lp / lin - 1 if lp else None
            lage = j if j is not None else ueber
            zeile(key, name, ueber, t, None, "Regime: Kurs darüber oder darunter", "pct", j, None,
                  f"Linie {_zahl(lin, 0)} USD · Kurs {'darüber' if lage is not None and lage >= 0 else 'darunter'}"
                  + (" (live)" if j is not None else "") + f" · Linie frei mit {BGM_VERZUG_TAGE} Tagen Verzug")
    # MVRV-Z
    z, t = _letzt(D["MVRV_Z"], tage)
    if z is not None:
        zeile("mvrvz", "MVRV-Z (expandierendes σ)", z, t, rang_in(D["MVRV_Z"][:t - D["d0"]], z), _seit(D["MVRV_Z"], tage), "x2")
    # Puell
    pu, t = _letzt(D["PUELL"], tage); pz, _ = _letzt(D["PUELL_PZ"], tage)
    if pu is not None:
        zeile("puell", "Puell Multiple", pu, t, pz, "in der Epoche seit " + time.strftime("%d.%m.%Y", time.gmtime(halving_tage()[-1] * TAG)), "x2")
    # Miner
    mvh, t = _letzt(D["MINER_VERH"], tage); e, _ = _letzt(D["MINER_E"], tage)
    if mvh is not None:
        # KEIN Perzentil: ein fester Gerätetyp über die ganze Historie ist kein Vergleichsmaßstab (2011 kostete ein BTC mit
        # heutiger Technik fast nichts) -- die Zahl sagt nur, wie weit der Kurs über den Stromkosten dieses Szenarios liegt
        k = MINER_STANDARD["jth"] * MINER_STANDARD["ct"] / 100 * e if e else None
        k19 = 21.5 * MINER_STANDARD["ct"] / 100 * e if e else None
        j = lp / k if lp and k else None
        zeile("miner", "Kurs ÷ Stromkosten S21 XP (7,5 US-ct/kWh)", mvh, t, None, "Szenario, kein Perzentil", "x2", j, None,
              (f"Stromkosten {_zahl(k, 0)} USD je BTC · S19 XP {_zahl(k19, 0)} USD" if k else ""))
    # Hash Ribbons
    ep_ = D["RIBBONS"]["episoden"]; kap = D["RIBBONS"]["kap"]
    g = np.nonzero(np.isfinite(D["RIBBONS"]["h30"]))[0]
    if len(g):
        i = g[-1]
        echt = [e for e in ep_ if e["echt"]]
        d_ = lambda t: time.strftime("%d.%m.%Y", time.gmtime(t * TAG))
        if kap[i] and ep_ and ep_[-1]["echt"]:
            e = ep_[-1]
            txt = f"Kapitulation seit {d_(e['von'])} ({e['tage']} Tage, Tiefe {e['tiefe'] * 100:+.1f} %, Rauschschwelle {e['schwelle'] * 100:.1f} %)".replace(".", ",", 2)
        elif kap[i] and ep_:
            e = ep_[-1]
            txt = (f"SMA30 unter SMA60 seit {d_(e['von'])}, aber im Rauschen (Tiefe {e['tiefe'] * 100:+.1f} %, Schwelle "
                   + (f"{e['schwelle'] * 100:.1f} %)" if e["schwelle"] is not None else "noch unbekannt)")).replace(".", ",")
        elif echt:
            e = echt[-1]
            txt = (f"keine Kapitulation; letzte {d_(e['von'])} bis {d_(e['bis'])}"
                   + (f", Kaufsignal nach Capriole {d_(e['signal'])}" if e.get("signal") else ""))
        else:
            txt = "keine Kapitulation über der Rauschschwelle"
        zeile("ribbons", "Hash Ribbons", None, int(tage[i]), None, "Zustand", "text", None, None, txt)
    # Stimmung und Hebel
    for key, name, arr, pzarr, fmt in (("fng", "Fear & Greed (30-Tage-Mittel)", "FNG30", "FNG30_PZ", "x0"),
                                       ("funding", "Funding Binance (30 Tage, % p. a.)", "FUNDING30", "FUNDING30_PZ", "x1"),
                                       ("oi", "Open Interest Binance ÷ Marktkap. (%)", "OI_MC", "OI_MC_PZ", "x2"),
                                       ("dvol", "DVOL (implizite Volatilität BTC)", "DVOL", "DVOL_PZ", "x0"),
                                       ("ssr", "Stablecoin Supply Ratio", "SSR", "SSR_PZ", "x1")):
        v, t = _letzt(D[arr], tage); pz, _ = _letzt(D[pzarr], tage)
        if v is None:
            continue
        ab = D.get("OI_ABDECKUNG") or {}
        if key == "oi" and ab.get("lueckenhaft"):                     # 23.50: kein Perzentil aus einer lückenhaften Historie
            zeile(key, name, v, t, None, "Binance-Archiv lädt noch", fmt, None, None,
                  f"{_zahl(ab['tage'], 0)} von {_zahl(ab['soll'], 0)} Tagen seit 01.09.2020 – Perzentil erst mit der ganzen Historie")
        else:
            zeile(key, name, v, t, pz, _seit(D[pzarr], tage), fmt)
    v, t = _letzt(D["ETF_BTC_30"], tage)
    if v is not None:
        zeile("etf", "ETF-Nettoflüsse BTC (30 Tage)", v, t, None, "Summe, Mio USD", "musd")
    zeile("halving", "Tage seit dem Halving (20.04.2024)", float(D["HALVING_TAG"]), int(tage[-1]), None,
          "Tops früher nach 368, 525, 546, 534 Tagen", "x0", None, None, "Zeitachse, kein Signal")
    return zeilen


# ================================================================================================ Nutzlast fürs Dashboard

def _l(a, sig: int = 5) -> list:
    out = []
    for v in np.asarray(a, dtype=float).tolist():
        out.append(None if v is None or not math.isfinite(v) else float(f"{v:.{sig}g}"))
    return out


def _tl(tage) -> list:
    return [int(t) for t in np.asarray(tage).tolist()]


TABS = ("ueberblick", "bewertung", "trend", "kohorten", "miner", "hebel", "fluss", "makro", "daten")
_CACHE: dict = {"lock": threading.Lock(), "pfad": None, "version": None, "D": None, "ts": 0.0, "nutz": {}, "rechnet": False}
# 23.49 (U126): Signale je Paar und Zeitraum -- einmal je Datentag gerechnet (hl_makro_signal, einige Sekunden), eigenes Schloss
_SIG: dict = {"lock": threading.Lock(), "D_id": None, "tag": None, "S": None, "ts": 0.0, "fehler": None}
SIGNAL_TABS = ("bewertung", "trend", "kohorten", "miner")


def signale(D: dict | None) -> dict | None:
    """Signale zum Datensatz D (Zwischenspeicher je Datentag und Datensatz; Einzelflug). Fehler -> None (Charts laufen weiter)."""
    if not D or not D.get("ok"):
        return None
    tag = int(D["tage"][-1])
    with _SIG["lock"]:
        if _SIG["S"] is not None and _SIG["tag"] == tag and (_SIG["D_id"] == id(D) or time.time() - _SIG["ts"] < 6 * 3600):
            return _SIG["S"]
        try:
            import hl_makro_signal
            S = hl_makro_signal.alle_signale(D)
            _SIG.update(S=S, tag=tag, D_id=id(D), ts=time.time(), fehler=None)
        except Exception as e:                                           # nie die Charts mitreißen
            _SIG.update(fehler=f"{type(e).__name__}: {e}")
            return _SIG["S"]
        return S


def signale_archivieren(con, S: dict | None, jetzt: int | None = None) -> int:
    """Tagesstand der Signale EINMAL je Datentag (INSERT OR IGNORE): revisionsfrei, für die spätere Bilanz der Live-Signale."""
    if not S:
        return 0
    import hl_makro_signal
    jetzt = int(jetzt if jetzt is not None else time.time())
    zeilen = [z + (jetzt,) for z in hl_makro_signal.tagesstand(S)]
    if not zeilen:
        return 0
    con.execute("BEGIN IMMEDIATE")
    try:
        vorher = con.total_changes
        con.executemany("INSERT OR IGNORE INTO mk_signal VALUES (?,?,?,?,?,?,?,?,?)", zeilen)
        n = con.total_changes - vorher
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return n


def signal_nachrechnung(pfad: str, S: dict | None) -> dict | None:
    """23.49 (U126): Live gegen Nachrechnung -- Archiv mk_signal gegen die heutige Rechnung (hl_makro_signal.nachrechnung);
    zwischengespeichert je Signalstand und Archivgröße. Keine Datei, keine Tabelle (ältere makro.db) -> None."""
    if not S:
        return None
    con = lesen(pfad)
    if con is None:
        return None
    try:
        anzahl, seit = con.execute("SELECT COUNT(*), MIN(tag) FROM mk_signal").fetchone()
        schluessel = (id(S), anzahl)
        if _SIG.get("nach_key") == schluessel:
            return _SIG.get("nach")
        zeilen = con.execute("SELECT tag, paar, fenster, signal, pz FROM mk_signal").fetchall()
    except sqlite3.Error:
        return None
    finally:
        con.close()
    import hl_makro_signal
    N = hl_makro_signal.nachrechnung(S, zeilen) or {"n": 0}
    N.update(seit=seit, archiv=anzahl)
    _SIG.update(nach_key=schluessel, nach=N)
    return N


def _daten(pfad: str) -> tuple:
    """(D, Fehler) -- gerechnet höchstens alle NEU_RECHNEN_S, sonst aus dem Zwischenspeicher; Einzelflug per Schloss."""
    con = lesen(pfad)
    if con is None:
        return None, "makro.db fehlt noch -- der Makro-Takt legt sie wenige Minuten nach dem Start des Dashboards an"
    try:
        version = meta(con, "version", "0")
        with _CACHE["lock"]:
            frisch = _CACHE["pfad"] == pfad and _CACHE["D"] is not None
            if frisch and (_CACHE["version"] == version or time.time() - _CACHE["ts"] < NEU_RECHNEN_S):
                return _CACHE["D"], None
            D = ableiten(con)
            _CACHE.update(pfad=pfad, version=version, D=D, ts=time.time(), nutz={})
            return D, None
    except sqlite3.Error as e:
        return None, f"makro.db: {e}"
    finally:
        con.close()


def datensatz(pfad: str) -> tuple:
    """(D, Fehler) wie für die Reiter des Makro-Charts -- für Module, die auf demselben Datensatz rechnen (23.116: hl_langfrist)."""
    return _daten(pfad)


def nutzlast(pfad: str, tab: str, coin: str = "BTC", live: dict | None = None) -> dict:
    tab = tab if tab in TABS else "ueberblick"
    coin = (coin or "BTC").upper()
    D, fehler = _daten(pfad)
    kopf = {"ok": False, "tab": tab, "coin": coin, "version": VERSION, "quellen": QUELLEN_TEXT, "miner": MINER_STANDARD,
            "geraete": [{"id": g, "name": n, "jth": j} for g, n, j in MINER_GERAETE], "halvings": list(HALVINGS)}
    if tab == "daten":
        kopf.update(ok=True, daten=daten_tab(pfad, D))
        return kopf
    if D is None or not D.get("ok"):
        kopf["grund"] = fehler or (D or {}).get("grund") or "keine Daten"
        return kopf
    schluessel = (tab, coin)
    with _CACHE["lock"]:
        teil = _CACHE["nutz"].get(schluessel)
    if teil is None:
        teil = _tab_daten(D, tab, coin)
        with _CACHE["lock"]:
            _CACHE["nutz"][schluessel] = teil
    kopf.update(ok=True, d0=D["d0"], n=D["n"], **teil)
    if tab in SIGNAL_TABS:                                               # 23.49 (U126)
        import hl_makro_signal
        S = signale(D)
        kopf["signale"] = hl_makro_signal.bloecke(S, tab, coin)
        kopf["signal_regeln"] = {"kauf_pz": hl_makro_signal.KAUF_PZ, "verkauf_pz": hl_makro_signal.VERKAUF_PZ, "horizonte": list(hl_makro_signal.HORIZONTE),
                                 "p_belegt": hl_makro_signal.P_BELEGT, "stand": S["tag"] if S else None, "fehler": _SIG["fehler"],
                                 "nachrechnung": signal_nachrechnung(pfad, S)}
    if tab == "hebel":                                                # 23.50: Hinweis unter dem OI-Chart, solange das Archiv lädt
        kopf["oi_archiv"] = D.get("OI_ABDECKUNG")
        kopf["cq_anteil"] = cq_chart_neben(pfad)                         # 23.68 (U158): CryptoQuant-Anteil mit der 95-%-Linie
    if tab == "makro" and isinstance(kopf.get("usa"), dict):           # 23.67 (U153): Termine je Abruf frisch (nicht aus dem Speicher)
        con_t = lesen(pfad)
        if con_t is not None:
            try:
                TT = usa_termine(con_t)
                st_ = datentag_stand(con_t)                                 # 23.68 (U172): dieselben Zahlen wie der Hinweis
            finally:
                con_t.close()
            kopf["usa"] = dict(kopf["usa"], naechste=TT.get("naechste", {}), vierzehn=TT.get("vierzehn", []), datentage=st_,
                               datentag_reihen={USA_TERMIN_REIHEN[s_]: s_ for s_ in DATENTAG_REIHEN})
    if tab == "makro" and isinstance(kopf.get("makro"), dict) and isinstance(kopf["makro"].get("leitzins"), dict):   # 23.127 (U316)
        lz = dict(kopf["makro"]["leitzins"])
        try:                                                                 # der nächste Entscheid; der Tab hängt nicht an ihm
            jetzt_ = time.time()
            con_f = lesen(pfad)
            gelesen_ = {int(z_["tag"]) for z_ in (fed_zeilen(con_f, 4) if con_f is not None else []) if z_["unten"] is not None}
            if con_f is not None:
                con_f.close()
            nx = next((ny_utc(t_, *FED_UHRZEIT) for t_ in fed_tage_alle(pfad)["alle"]
                       if ny_utc(t_, *FED_UHRZEIT) + FED_FENSTER_S > jetzt_ and t_ not in gelesen_), None)
            lz["fed"] = dict(lz.get("fed") or {}, naechster=nx)
        except Exception as e:
            lz["fed"] = dict(lz.get("fed") or {}, naechster=None, fehler=f"{type(e).__name__}: {e}"[:120])
        kopf["makro"] = dict(kopf["makro"], leitzins=lz)
    if tab == "ueberblick":
        kopf["zonen"] = zonenkarte(D, live)
        kopf["live"] = live
    return kopf


def _r(a, sig: int = 5, d0: int = 0) -> dict | None:
    """Tagesreihe kompakt: {"t0": erster Tag mit Wert (Tage seit 1970), "v": [...]} -- führende und folgende Lücken fallen weg."""
    a = np.asarray(a, dtype=float); g = np.nonzero(np.isfinite(a))[0]
    if not len(g):
        return None
    i0, i1 = int(g[0]), int(g[-1]) + 1
    return {"t0": int(d0 + i0), "v": _l(a[i0:i1], sig)}


MINI_TAEGLICH = 730                                     # kleine Charts im Überblick: jüngste 2 Jahre täglich, davor jeder 7. Tag
MINI_MINER_TAGE = 1461                                  # Miner-Verhältnis nur 4 Jahre (fester Gerätetyp, wie die Signale)


def _mini(a, d0: int, taeglich: int = MINI_TAEGLICH, letzte: int | None = None, sig: int = 4) -> dict | None:
    """
    23.51: Reihe für die kleinen Charts im Überblick -- die jüngsten `taeglich` Tage täglich, davor jeder 7. Tag (Stand des Tages,
    rückwärts von der Grenze gezählt; kein Mittel, damit jeder Punkt ein echter Tageswert ist). `letzte`: nur so viele Tage.
    -> {"t": [Tage seit 1970], "v": [...]} ohne Lücken-Werte, oder None.
    """
    a = np.asarray(a, dtype=float); n = len(a)
    if letzte:
        a = np.where(np.arange(n) >= n - letzte, a, np.nan)
    grenze = max(0, n - taeglich)
    idx = np.concatenate([np.arange(grenze - 1, -1, -7)[::-1], np.arange(grenze, n)]).astype(int)
    idx = idx[np.isfinite(a[idx])]
    if not len(idx):
        return None
    t, v = [], []
    vorher = None
    for i in idx.tolist():
        if vorher is not None and i - vorher > 8:                   # Lücke (z. B. OI-Archiv lädt noch): Linie unterbrechen, nicht überbrücken
            t.append(int(d0 + vorher + 1)); v.append(None)
        t.append(int(d0 + i)); v.append(float(f"{a[i]:.{sig}g}"))
        vorher = i
    return {"t": t, "v": v}


def mini_reihen(D: dict) -> dict:
    """23.51: je Zeile der Zonenkarte die Reihe hinter der Zahl (Schlüssel wie die Zonenkarte; Halving ohne Chart)."""
    P = np.asarray(D["P"], dtype=float); bg = D["BGM"]; rb = D["RIBBONS"]
    with np.errstate(invalid="ignore", divide="ignore"):
        reihen = {"mvrv": D["MVRV"], "pl": np.power(10.0, np.asarray(D["PL"]["rest"], dtype=float)), "wma": D["WMA_ABST"],
                  "sth": P / np.asarray(bg["sth-realized-price"], dtype=float) - 1, "tmm": P / np.asarray(bg["true-market-mean"], dtype=float) - 1,
                  "mvrvz": D["MVRV_Z"], "puell": D["PUELL"], "ribbons": np.asarray(rb["h30"], dtype=float) / np.asarray(rb["h60"], dtype=float) - 1,
                  "fng": D["FNG30"], "funding": D["FUNDING30"], "oi": D["OI_MC"], "dvol": D["DVOL"], "ssr": D["SSR"], "etf": D["ETF_BTC_30"]}
    out = {k: _mini(v, D["d0"]) for k, v in reihen.items()}
    out["miner"] = _mini(D["MINER_VERH"], D["d0"], letzte=MINI_MINER_TAGE)
    return {k: v for k, v in out.items() if v}


def _tab_daten(D: dict, tab: str, coin: str) -> dict:
    """Nutzlast je Tab. Seit 23.54 trägt jeder Chart-Tab den BTC-Kurs als r.P (Kursleiste unter den Kennzahl-Charts; in
    Bewertung mit anderem Coin dessen Kurs, in Trend zusätzlich w.P des Coins)."""
    d0 = D["d0"]
    R = lambda a, sig=5: _r(a, sig, d0)
    if tab == "ueberblick":
        return {"r": {"P": R(D["P"]), "RP": R(D["RP"]), "WMA": R(D["WMA"]), "STH": R(D["BGM"]["sth-realized-price"]),
                      "TMM": R(D["BGM"]["true-market-mean"]), "ME": R(D["MINER_E"]), "EURUSD": R(D["EURUSD"], 4)},
                "fit": D["PL_FIT"],
                # 23.51: die Reihen hinter den Zahlen der Zonenkarte als kleine Charts; Kapitulationen der Hash Ribbons als Flächen
                "mini": mini_reihen(D),
                "mini_zonen": {"ribbons": [{"a": int(e["von"]), "b": int(e["bis"])} for e in D["RIBBONS"]["episoden"] if e.get("echt")]}}
    if tab == "bewertung":
        coins = [c for c, e in D["COINS"].items() if "MVRV" in e]
        if coin != "BTC" and coin in coins:
            c = D["COINS"][coin]; Rc = lambda a, sig=5: _r(a, sig, c["d0"])
            return {"r": {"P": Rc(c["P"]), "RP": Rc(c["RP"]), "MVRV": Rc(c["MVRV"], 4), "PZ": Rc(c["MVRV_PZ"], 3),
                          "PZ4": Rc(c["MVRV_PZ4"], 3), "Z": Rc(c["MVRV_Z"], 3)}, "coin_ok": True, "coins_mvrv": coins}
        return {"r": {"P": R(D["P"]), "RP": R(D["RP"]), "DELTA": R(D["DELTA"]), "MVRV": R(D["MVRV"], 4), "PZ": R(D["MVRV_PZ"], 3),
                      "PZ4": R(D["MVRV_PZ4"], 3), "Z": R(D["MVRV_Z"], 3)},
                "extreme": D["EXTREME"], "divergenz": D["DIVERGENZ"], "coin_ok": coin == "BTC", "coins_mvrv": coins}
    if tab == "trend":
        pl = D["PL"]
        par = [p for p in pl["parameter"] if p["monat"].endswith("-01")] + pl["parameter"][-1:]
        teil = {"r": {"P": R(D["P"]), "PZ": R(pl["pz"], 3), "SIG": R(pl["sigma"], 3)}, "fit": D["PL_FIT"],
                "parameter": [dict(p, b=round(p["b"], 4), a=round(p["a"], 4), sd=round(p["sd"], 4)) for p in par],
                "zyklen": [{"halving": z["halving"], "werte": _l(z["werte"], 4)} for z in D["ZYKLEN"]],
                "halving_tag": D["HALVING_TAG"], "coins_wma": ["BTC"] + list(D["COINS"])}
        if coin != "BTC" and coin in D["COINS"]:
            c = D["COINS"][coin]; Rc = lambda a, sig=5: _r(a, sig, c["d0"])
            teil["w"] = {"P": Rc(c["P"]), "WMA": Rc(c["WMA"]), "AB": Rc(c["WMA_ABST"], 4)}
        else:
            teil["w"] = {"P": R(D["P"]), "WMA": R(D["WMA"]), "AB": R(D["WMA_ABST"], 4), "ABPZ": R(D["WMA_ABST_PZ"], 3)}
        return teil
    if tab == "kohorten":
        bg = D["BGM"]
        return {"r": {"P": R(D["P"]), "STH": R(bg["sth-realized-price"]), "LTH": R(bg["lth-realized-price"]), "TMM": R(bg["true-market-mean"]),
                      "STHMV": R(bg["sth-mvrv"], 4), "STHMVPZ": R(D["STH_MVRV_PZ"], 3), "ASOPR": R(bg["asopr"], 4),
                      "LSOPR": R(bg["lth-sopr"], 4), "AVIV": R(bg["aviv"], 4), "AVIVZ": R(D["AVIV_Z"], 3), "RLOSS": R(bg["realized-loss"])},
                "felder": D["BGM_FELD"]}
    if tab == "miner":
        rb = D["RIBBONS"]
        return {"r": {"P": R(D["P"]), "ME": R(D["MINER_E"]), "EURUSD": R(D["EURUSD"], 4), "PUELL": R(D["PUELL"], 4),
                      "PUELLPZ": R(D["PUELL_PZ"], 3), "HR": R(D["HR"], 4), "H30": R(rb["h30"], 4), "H60": R(rb["h60"], 4), "DIFF": R(D["DIFF"], 4)},
                "episoden": rb["episoden"], "ribbon": list(RIBBON)}
    if tab == "hebel":
        rw = D["RSI_W"]
        return {"r": {"P": R(D["P"]), "FUND": R(D["FUNDING"], 4), "FUND30": R(D["FUNDING30"], 4), "OIMC": R(D["OI_MC"], 4), "OI": R(D["OI"]),
                      "DVOL": R(D["DVOL"], 4), "DVOLPZ": R(D["DVOL_PZ"], 3), "FNG": R(D["FNG"], 3), "FNG30": R(D["FNG30"], 3)},
                "rsi": {"t": _tl(rw["tage"]), "v": _l(rw["werte"], 4)}}
    if tab == "fluss":
        return {"r": {"P": R(D["P"]), "STABLE": R(D["STABLE"]), "SSR": R(D["SSR"], 4), "SSRPZ": R(D["SSR_PZ"], 3),
                      "ETFB": R(D["ETF_BTC"], 4), "ETFBK": R(D["ETF_BTC_KUM"]), "ETFB30": R(D["ETF_BTC_30"]),
                      "ETFE": R(D["ETF_ETH"], 4), "ETFEK": R(D["ETF_ETH_KUM"]), "ETFE30": R(D["ETF_ETH_30"])}}
    if tab == "makro":
        M = D["MAKRO"]; out = {}
        for k in ("netliq", "global", "m2", "realzins", "dollar", "hy", "leitzins"):
            if not M or k not in M:
                continue
            r = M[k]
            t = r.get("tage", M["tage"])
            out[k] = {"titel": r["titel"], "einheit": r["einheit"], "t": _tl(t), "v": _l(r["anzeige"], 5), "k": _l(r["korr"], 3),
                      "regime": r["regime"], "korr_jetzt": r["korr_jetzt"], "korr_alt": r["korr_alt"], "band": r["band"],
                      "monatlich": bool(r.get("monatlich"))}
        U = D.get("USA") or {}; usa = {}
        for k, e in U.items():
            eintrag = {"titel": e["titel"], "einheit": e["einheit"], "t": _tl(e["tage"]), "monatlich": e["monatlich"], "unter": e.get("unter", ""),
                       "quelle": e.get("quelle"), "termine": e.get("termine", []), "null": e.get("null", False), "luecken": e.get("luecken", []),
                       "nk": e.get("nk", 1),
                       "linien": [{"n": ln["n"], "kurz": ln.get("kurz"), "v": _l(ln["v"], 5)} for ln in e["linien"]]}
            if e.get("korr") is not None:
                kt = e.get("korr_tage", e["tage"])
                eintrag.update(kt=_tl(kt), k=_l(e["korr"], 3), regime=e["regime"], korr_jetzt=e["korr_jetzt"], korr_alt=e["korr_alt"], band=e["band"])
            usa[k] = eintrag
        F_ = D.get("FED") or {}
        if "leitzins" in out and F_.get("t"):                              # 23.127 (U316): Treppe der Zielspanne und der Entscheid
            out["leitzins"]["ziel"] = {"t": [int(x) for x in F_["t"]], "u": [float(x) for x in F_["u"]], "o": [float(x) for x in F_["o"]]}
            out["leitzins"]["fed"] = {"jetzt": F_.get("jetzt"), "vorl": F_.get("vorl")}
        TT = D.get("USA_TERMINE") or {}
        return {"makro": out, "r": {"P": R(D["P"])},                  # 23.54: Kurs für die Kursleiste unter jeder Reihe
                "usa": {"reihen": usa, "naechste": TT.get("naechste", {}), "vierzehn": TT.get("vierzehn", []), "luecke_text": USA_LUECKE,
                        "fehler": D.get("USA_FEHLER")}}
    return {}


def _hebel_neben(pfad: str) -> str:
    """23.68 (U158): hebel.db liegt neben makro.db und hl_liq.db (HL_HEBEL_DB lenkt um, wie hl_hebel.hebel_pfad)."""
    import hl_hebel
    return hl_hebel.hebel_pfad(os.path.join(os.path.dirname(os.path.abspath(pfad)), "hl_liq.db"))


def cq_stand_neben(pfad: str) -> dict:
    """23.68 (U158): Stand des CryptoQuant-Abrufs für den Tab „Daten“ (nur lesend; ohne Schlüssel im Text). Fehler -> leer."""
    try:
        import hl_hebel
        return hl_hebel.cq_stand(_hebel_neben(pfad))
    except Exception as e:
        return {"schluessel": False, "tage": 0, "modulfehler": f"{type(e).__name__}"[:60]}


def cq_chart_neben(pfad: str) -> dict | None:
    """23.68 (U158): Reihe D für den Tab „Hebel & Stimmung“ (nur lesend); ohne Daten None."""
    try:
        import hl_hebel
        return hl_hebel.cq_chart(_hebel_neben(pfad))
    except Exception:
        return None


def daten_tab(pfad: str, D: dict | None, jetzt: float | None = None) -> dict:
    """
    Quellen, Zeilen, erster/letzter Tag, letzter Abruf, Fehler, BGeometrics-Budget, Archiv, Power-Law-Parameter.
    Frische (Abnahme U121): je Reihe Alter des letzten Werts gegen ihre Grenze (`frische_grenze`) -> „zu_alt“; dazu „fehlen“:
    Reihen, die ein schon erfolgreich abgerufenes Ziel liefern müsste, die es aber nicht gibt (Metrik oder Feld verschwunden).
    """
    con = lesen(pfad)
    if con is None:
        return {"fehlt": True}
    jetzt = time.time() if jetzt is None else jetzt
    heute = int(jetzt) // TAG
    try:
        reihen = []
        for r, n, a, b, ab in con.execute("SELECT reihe, COUNT(*), MIN(ts), MAX(ts), MAX(abgerufen) FROM mk_reihe GROUP BY reihe ORDER BY reihe"):
            g = frische_grenze(r); alter = heute - int(b) // TAG
            reihen.append({"reihe": r, "n": n, "von": ts_tag(a), "bis": ts_tag(b), "abgerufen": ab, "alter": alter, "grenze": g,
                           "alt": g is not None and alter > g})
        namen = {r["reihe"] for r in reihen}
        m = dict(con.execute("SELECT k, v FROM mk_meta").fetchall())
        ziele = []; fehlen = []
        for quelle, ziel, abstand in Makro.ZIELE + tuple(("bgm", ep, 24 * 3600) for ep in BGM):
            ok_ts = int(float(m.get(f"ok:{quelle}:{ziel}", 0) or 0))
            ziele.append({"quelle": quelle, "ziel": ziel, "ok": ok_ts,
                          "fehler": m.get(f"fehler:{quelle}:{ziel}", ""), "voll": m.get(f"voll:{quelle}:{ziel}") == "1",
                          "pause": int(float(m.get(f"pause:{quelle}:{ziel}", 0) or 0))})
            if ok_ts:                                                    # erst nach einem erfolgreichen Abruf ist Fehlen ein Befund
                for e in erwartete_reihen(quelle, ziel):
                    if not (any(n_.startswith(e) for n_ in namen) if e.endswith(":") else e in namen):
                        fehlen.append(e + "*" if e.endswith(":") else e)
        try:
            aufrufe = [float(x) for x in json.loads(m.get("bgm_aufrufe", "[]") or "[]")]
        except ValueError:
            aufrufe = []
        ab = oi_abdeckung(con)
        archiv = {"cursor": ab["rueck"], "richtung": "rückwärts", "fertig": m.get("oi_archiv_fertig") == "1",
                  "tage": int(m.get("oi_archiv_tage", 0) or 0), "fehlend": int(m.get("oi_archiv_fehlend", 0) or 0),
                  "fehler": m.get("fehler:oi_archiv:-", ""), "abdeckung": ab}
        stand_tage = con.execute("SELECT COUNT(DISTINCT tag), MIN(tag), MAX(tag) FROM mk_stand").fetchone()
        pl = [dict(zip(("monat", "a", "b", "sd", "n"), r)) for r in con.execute("SELECT monat, a, b, sd, n FROM mk_pl ORDER BY monat")]
        groesse = os.path.getsize(pfad) if os.path.exists(pfad) else 0
        fred_ok = [z for z in ziele if z["quelle"] == "fred" and z["ok"]]
        fred_haengt = [z for z in ziele if z["quelle"] == "fred" and _netzfehler(z["fehler"])]
        fred = {"schluessel": bool(fred_schluessel_lesen()), "umgebung": bool((os.environ.get("FRED_API_KEY") or "").strip()),
                "weg": m.get("fred_weg") or "", "ok": len(fred_ok), "haengt": len(fred_haengt), "ziele": len(FRED),
                "seite": FRED_SCHLUESSEL_SEITE, "befehl": ".venv/bin/python hl_makro.py --db <hl_liq.db> --fred-schluessel <SCHLÜSSEL>"}
        return {"reihen": reihen, "ziele": ziele, "version": m.get("version"), "groesse_mb": round(groesse / 1e6, 2),
                "zu_alt": [r["reihe"] for r in reihen if r["alt"]], "fehlen": fehlen, "fred": fred, "bgm_verzug": BGM_VERZUG_TAGE,
                "cq": cq_stand_neben(pfad),                                       # 23.68 (U158)
                "bgm": {"stunde": sum(1 for x in aufrufe if x > jetzt - 3600), "tag": sum(1 for x in aufrufe if x >= int(jetzt) // TAG * TAG),
                        "je_stunde": BGM_JE_STUNDE, "je_tag": BGM_JE_TAG},
                "archiv": archiv, "stand": {"tage": stand_tage[0], "von": stand_tage[1], "bis": stand_tage[2]},
                "pl": pl[-36:], "bgm_felder": (D or {}).get("BGM_FELD") if D and D.get("ok") else None,
                "gegenprobe_hr": _letzt(D["HR_GEGENPROBE"], D["tage"])[0] if D and D.get("ok") else None}
    finally:
        con.close()


def payload_json(pfad: str, tab: str, coin: str, live: dict | None = None) -> bytes:
    try:
        d = nutzlast(pfad, tab, coin, live)
    except Exception as e:
        d = {"ok": False, "tab": tab, "grund": f"Fehler: {type(e).__name__}: {e}"}
    return json.dumps(d, separators=(",", ":"), allow_nan=False, default=_json_default).encode()


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        f = float(o)
        return f if math.isfinite(f) else None
    if isinstance(o, np.ndarray):
        return _l(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    raise TypeError(type(o).__name__)


# ================================================================================================ Archiv und Takt

def archivieren(con, D: dict, jetzt: int | None = None) -> int:
    """
    Tagesstand der Zonenkarte und Power-Law-Parameter je Monat EINMAL speichern (INSERT OR IGNORE): der Stand, den der Chart
    an diesem Tag zeigte -- revisionsfrei, für eine eigene Bilanz außerhalb der Stichprobe (Bericht, Fazit).
    """
    if not D or not D.get("ok"):
        return 0
    jetzt = int(jetzt if jetzt is not None else time.time())
    tag = ts_tag(jetzt)
    zeilen = []
    for z in zonenkarte(D):
        if z["wert"] is not None and isinstance(z["wert"], (int, float)) and math.isfinite(z["wert"]):
            zeilen.append((tag, z["key"], float(z["wert"]), jetzt))
        if z["pz"] is not None and math.isfinite(z["pz"]):
            zeilen.append((tag, z["key"] + "_pz", float(z["pz"]), jetzt))
        if z.get("tag"):
            zeilen.append((tag, z["key"] + "_datentag", float(z["tag"]), jetzt))
    pl = [(p["monat"], p["a"], p["b"], p["sd"], p["n"], jetzt) for p in D["PL"]["parameter"]]
    con.execute("BEGIN IMMEDIATE")
    try:
        vorher = con.total_changes
        con.executemany("INSERT OR IGNORE INTO mk_stand VALUES (?,?,?,?)", zeilen)
        con.executemany("INSERT OR IGNORE INTO mk_pl VALUES (?,?,?,?,?,?)", pl)
        n = con.total_changes - vorher
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise
    return n


_TAKT: dict = {"gestartet": False, "fehler": None, "letzte": None, "laeufe": 0}


def _schleife(pfad: str) -> None:
    time.sleep(START_VERZUG_S)
    try:
        m = Makro(pfad)
    except Exception as e:
        _TAKT["fehler"] = f"Start: {type(e).__name__}: {e}"
        print(f"Makro-Takt: {_TAKT['fehler']}", flush=True)
        return
    letzte_rechnung = 0.0; archiv_tag = None
    while True:
        try:
            erg = m.runde()
            _TAKT["letzte"] = {"ts": int(time.time()), **{k: v for k, v in erg.items() if k != "ziele"},
                               "ziele": {k: v for k, v in erg["ziele"].items() if v}}
            _TAKT["laeufe"] += 1; _TAKT["fehler"] = None
            try:                                                            # 23.118 (U280): Tagesabruf der Optionen, wenn er fällig ist
                import hl_marktschicht as _ms
                _TAKT["optionen"] = _ms.takt_schritt(pfad)
            except Exception as e:                                          # der Makro-Takt hängt nicht an dieser Schicht
                _TAKT["optionen"] = {"fehler": f"{type(e).__name__}: {e}"}
            heute = ts_tag(time.time())
            if neu_rechnen_noetig(erg, letzte_rechnung, time.time(), archiv_tag, heute):          # 23.127 (U316): nach Termin sofort
                con = lesen(pfad)
                try:
                    version = meta(con, "version", "0")
                    D = ableiten(con)
                finally:
                    con.close()
                letzte_rechnung = time.time()
                with _CACHE["lock"]:                                     # das Dashboard muss nicht noch einmal rechnen
                    _CACHE.update(pfad=pfad, version=version, D=D, ts=time.time(), nutz={})
                if D.get("ok"):
                    archivieren(m.con, D); archiv_tag = heute
                    signale_archivieren(m.con, signale(D))                  # 23.49: einmal je Datentag gerechnet, Tagesstand bleibt
                    try:                                                    # 23.116 (U279): fällige Monatsfassung des 24-Monats-Charts
                        import hl_langfrist as _lf
                        _TAKT["langfrist"] = _lf.takt_schritt(pfad, D)
                    except Exception as e:                                  # der Makro-Takt hängt nicht am Chart
                        _TAKT["langfrist"] = {"fehler": f"{type(e).__name__}: {e}"}
            if erg["neu_ohne_archiv"]:
                print(f"[{time.strftime('%H:%M:%S')}] Makro: {erg['neu_ohne_archiv']} neue Werte "
                      f"({', '.join(k for k, v in erg['ziele'].items() if v and v > 0)})", flush=True)
        except Exception as e:
            _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
            print(f"Makro-Takt: {_TAKT['fehler']}", flush=True)
        time.sleep(TAKT_S)


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen. Nicht für Selbsttest-Datenbanken; aus mit HL_MAKRO=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_MAKRO") == "0":
        return False
    _TAKT["gestartet"] = True
    threading.Thread(target=_schleife, args=(makro_pfad(db),), daemon=True, name="makro").start()
    return True


# ================================================================================================ Stand als Text (Debug)

def fred_text(f: dict) -> str:
    """Eine Zeile zum FRED-Weg für Stand und Daten-Tab."""
    if f.get("schluessel"):
        return (f"FRED: offizielle API mit Schlüssel ({'Umgebungsvariable FRED_API_KEY' if f.get('umgebung') else 'accesstokens.json'}); "
                f"{f.get('ok', 0)} von {f.get('ziele', 0)} Reihen abgerufen" + (f", {f['haengt']} ohne Antwort" if f.get("haengt") else ""))
    return (f"FRED: OHNE Schlüssel über fredgraph.csv -- {f.get('ok', 0)} von {f.get('ziele', 0)} Reihen abgerufen"
            + (f", {f['haengt']} ohne Antwort" if f.get("haengt") else "")
            + f". fredgraph.csv antwortet seit Mitte August 2026 vielerorts nicht. Abhilfe: kostenlosen Schlüssel holen ({f.get('seite')}) "
              f"und im Makro-Tab „Daten“ eintragen oder im Projektordner: {f.get('befehl')}")


def stand_text(pfad: str, jetzt: float | None = None) -> str:
    z = [f"{NAME} -- Stand {time.strftime('%d.%m.%Y %H:%M')} · {pfad}"]
    con = lesen(pfad)
    if con is None:
        return z[0] + "\n  makro.db fehlt (der Makro-Takt legt sie 90 s nach dem Start des Dashboards an)."
    con.close()
    D, fehler = _daten(pfad)
    T = daten_tab(pfad, D, jetzt)
    z.append(f"  Datei {T['groesse_mb']} MB · Datenversion {T['version']} · Archiv {T['stand']['tage'] or 0} Tage"
             f"{' (' + str(T['stand']['von']) + ' bis ' + str(T['stand']['bis']) + ')' if T['stand']['tage'] else ''}")
    alt_ = {r["reihe"]: r for r in T["reihen"] if r["alt"]}
    if not alt_ and not T["fehlen"]:
        z.append(f"  Frische: alle {len(T['reihen'])} Reihen innerhalb ihrer Grenze; keine erwartete Reihe fehlt")
    else:
        if alt_:
            z.append(f"  Frische: ZU ALT {len(alt_)} von {len(T['reihen'])} -- "
                     + ", ".join(f"{k} ({r['alter']} T, Grenze {r['grenze']})" for k, r in alt_.items()))
        if T["fehlen"]:
            z.append(f"  FEHLT nach erfolgreichem Abruf ({len(T['fehlen'])}): " + ", ".join(T["fehlen"]) + " -- Metrik oder Feld verschwunden?")
    z.append("  " + fred_text(T["fred"]))
    z.append("  " + termin_kurz(pfad, jetzt))                              # 23.127 (U316): Abruf nach Bekanntgabe (Einzelheiten Debug 168)
    z.append(f"  BGeometrics frei: die jüngsten {BGM_VERZUG_TAGE} Tage nur im Abo -- Kohortenwerte enden {BGM_VERZUG_TAGE} Tage vor heute (kein Fehler)")
    z.append("")
    z.append("  Quellen je Ziel (ok = letzter Erfolg UTC, voll = Historie geholt):")
    for q in T["ziele"]:
        ok = time.strftime("%d.%m. %H:%M", time.gmtime(q["ok"])) if q["ok"] else "nie"
        z.append(f"    {q['quelle'] + ':' + q['ziel']:<28} ok {ok:<12} {'voll' if q['voll'] else '    '}"
                 + (f"  FEHLER {q['fehler']}" if q["fehler"] else "")
                 + (f"  Pause bis {time.strftime('%H:%M', time.gmtime(q['pause']))} UTC" if q["pause"] > time.time() else ""))
    b = T["bgm"]; a = T["archiv"]
    z.append(f"  BGeometrics: {b['stunde']}/{b['je_stunde']} in der letzten Stunde, {b['tag']}/{b['je_tag']} heute (frei 8/h, 15/Tag)")
    ab = a.get("abdeckung") or {}
    z.append(f"  Binance-OI-Archiv: {'fertig' if a['fertig'] else 'läuft rückwärts (jüngste Tage zuerst), bei ' + str(a['cursor'])}, "
             f"{_zahl(ab.get('tage'), 0)} von {_zahl(ab.get('soll'), 0)} Tagen seit 01.09.2020 da"
             + ("" if a["fertig"] else f", noch {_zahl(ab.get('offen'), 0)} offen (etwa {_zahl(ab.get('eta_h'), 1)} h bei einem Tag je {TAKT_S} s)")
             + f"; Archiv {a['tage']} Tage geholt, {a['fehlend']} fehlend (404)"
             + (f" · Abschnitte: " + ", ".join(f"{x['von']}–{x['bis']}" for x in ab.get("abschnitte", [])) if ab.get("n_abschnitte", 0) > 1 else "")
             + (f" · {a['fehler']}" if a["fehler"] else ""))
    z.append("")
    z.append(f"  Reihen ({len(T['reihen'])}):")
    for r in T["reihen"]:
        z.append(f"    {r['reihe']:<40} {r['n']:>6}  {r['von']} bis {r['bis']}"
                 + (f"  ZU ALT ({r['alter']} T > {r['grenze']})" if r["alt"] else ""))
    if D is None or not D.get("ok"):
        z.append("")
        z.append(f"  Treiber: {fehler or (D or {}).get('grund')}")
        return "\n".join(z)
    z.append("")
    z.append("  Zonenkarte (Perzentil der eigenen Historie, KEIN Signal):")
    for r in zonenkarte(D):
        w = r["wert"]
        wt = ("—" if w is None else (f"{w * 100:+.1f} %".replace(".", ",") if r["fmt"] in ("pct", "pct_regime") else _zahl(w, 2)))
        pz = "" if r["pz"] is None else f"{r['pz']:5.1f}. Pz".replace(".", ",")
        z.append(f"    {r['name']:<42} {wt:>12} {pz:>10}  {ts_tag(r['tag'] * TAG) if r['tag'] else ''}  {r['text']}")
    f = D["PL_FIT"]
    if f:
        z.append("")
        z.append(f"  Power Law über alle Tage: b = {f['b']:.3f}, a = {f['a']:.3f}, σ = {f['sd']:.3f} (log10), n = {f['n']}".replace(".", ","))
        par = D["PL"]["parameter"]
        for p in [p for p in par if p["monat"].endswith("-01")][-6:] + par[-1:]:
            z.append(f"    Anpassung bis {p['monat']}: b = {p['b']:.3f} (n {p['n']})".replace(".", ","))
    if T.get("gegenprobe_hr") is not None:
        z.append(f"  Gegenprobe Hashrate Coin Metrics ÷ Blockchain.com (7 Tage): {T['gegenprobe_hr']:.3f}".replace(".", ","))
    if T.get("bgm_felder"):
        z.append("  BGeometrics-Felder: " + ", ".join(f"{k} -> {(v or '—').split(':')[-1]}" for k, v in T["bgm_felder"].items()))
    S = signale(D)
    z += [""] + signal_text(S, signal_nachrechnung(pfad, S))
    z += [""] + usa_text(pfad, D)
    return "\n".join(z)


def termin_kurz(pfad: str, jetzt: float | None = None) -> str:
    """23.127 (U316): eine Zeile für den Stand -- Abrufe nach Termin der letzten 7 Tage und der nächste Fed-Entscheid."""
    jetzt = float(time.time() if jetzt is None else jetzt)
    con = lesen(pfad)
    if con is None:
        return "Abruf nach Bekanntgabe: makro.db fehlt"
    try:
        try:
            r = con.execute("SELECT COUNT(*), SUM(da IS NOT NULL AND wie != 'takt'), SUM(da IS NULL AND termin < ?) FROM mk_terminabruf "
                            "WHERE termin >= ?", (int(jetzt) - TERMIN_FENSTER_S, int(jetzt) - 7 * TAG)).fetchone()
        except sqlite3.Error:
            r = (0, 0, 0)
        aus_ = termin_ausnahme_lesen(con, jetzt)
        F = fed_tage_alle(pfad)
    finally:
        con.close()
    nx = next((t for t in F["alle"] if ny_utc(t, *FED_UHRZEIT) + FED_FENSTER_S > jetzt), None)
    return (f"Abruf nach Bekanntgabe (U316): 7 Tage {int(r[0] or 0)} Termine, {int(r[1] or 0)} mit Zahl über den Abruf nach Termin, "
            f"{int(r[2] or 0)} ohne neue Zahl im Fenster · nächster Fed-Entscheid {tag_kurz(ny_utc(nx, *FED_UHRZEIT)) if nx else '—'} · "
            + (f"AUSNAHME {tag_kurz(aus_[0])} (Takt lief weiter) · " if aus_ else "") + "Einzelheiten Debug 168")


WOCHENTAGE = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")


def tag_kurz(t: float) -> str:
    """23.68 (U169): „Do 15.10. 14:30“ in Ortszeit -- deutscher Wochentag unabhängig von der Spracheinstellung des Systems
    (strftime('%a') gab auf dem Pi „Thu“)."""
    lt = time.localtime(t)
    return f"{WOCHENTAGE[lt.tm_wday]} {time.strftime('%d.%m. %H:%M', lt)}"


def korr_zeile(e: dict) -> str:
    """
    23.68 (U169): Korrelation mit BTC im Text mit ihrem Zufallsband und dem Urteil wie im Dashboard (`_regime`): innerhalb
    ±2/√n „kein belegter Zusammenhang“, sonst „außerhalb des Zufallsbands“. Bisher stand nur die Zahl da.
    """
    r, b = e.get("korr_jetzt"), e.get("band")
    if r is None:
        return ""
    if b is None or not math.isfinite(b):
        return f" · Korrelation mit BTC {_zahl(r, 2)}"
    fenster = "24 Monate" if e.get("monatlich") else "52 Wochen"
    urteil = "kein belegter Zusammenhang" if abs(r) < b else "außerhalb des Zufallsbands"
    return f" · Korrelation mit BTC {_zahl(r, 2)} ({fenster}, Zufallsband ±{_zahl(b, 2)}, {urteil})"


def usa_text(pfad: str, D: dict | None) -> list:
    """23.67 (U153): Arbeitsmarkt und Preise der USA im Stand -- jüngster Wert je Chart, Fassungen, Erstveröffentlichungen, Termine."""
    z = ["  USA: ARBEITSMARKT UND PREISE (U153, nur Anzeige -- wirkt auf nichts)"]
    con = lesen(pfad)
    if con is None:
        return z + ["    makro.db fehlt"]
    try:
        try:
            fa = dict(con.execute("SELECT art, COUNT(*) FROM mk_fassung GROUP BY art").fetchall())
            je = {r_: (n_, e_) for r_, n_, e_ in con.execute("SELECT reihe, COUNT(*), SUM(art='erst') FROM mk_fassung GROUP BY reihe")}
        except sqlite3.Error:
            fa, je = {}, {}
        TT = usa_termine(con)
        m_ = dict(con.execute("SELECT k, v FROM mk_meta WHERE k LIKE 'release:%' OR k LIKE 'ok:fred1:%' OR k LIKE 'ok:fredtermin:%'").fetchall())
    finally:
        con.close()
    U = (D or {}).get("USA") or {}
    if (D or {}).get("USA_FEHLER"):
        z.append(f"    Rechnung: FEHLER {D['USA_FEHLER']}")
    for k, e in U.items():
        teile = []
        for ln in e["linien"]:
            v = np.asarray(ln["v"], dtype=float); ok = np.nonzero(np.isfinite(v))[0]
            if len(ok):
                tag = int(e["tage"][ok[-1]])
                teile.append(f"{ln['n']} {_zahl(float(v[ok[-1]]), 2 if e['einheit'] == '%' else 1)} {e['einheit']} ({ts_tag(tag * TAG)[:7] if e['monatlich'] else ts_tag(tag * TAG)})")
        z.append(f"    {e['titel']}: " + ("; ".join(teile) if teile else "noch keine Werte")
                 + (f" · Lücken {', '.join(e['luecken'])}" if e.get("luecken") else "")
                 + korr_zeile(e))
    z.append(f"    Fassungen in mk_fassung: {fa.get('abruf', 0)} aus eigenen Abrufen, {fa.get('erst', 0)} Erstveröffentlichungen (ALFRED)"
             + (" -- je Reihe: " + ", ".join(f"{r_.split(':')[1]} {n_}" for r_, (n_, _e) in sorted(je.items())) if je else ""))
    ids = {k_.split(":", 1)[1]: v_ for k_, v_ in m_.items() if k_.startswith("release:") and k_.split(":", 1)[1] in USA_TERMIN_REIHEN}
    z.append(f"    Termine in mk_termin: {TT.get('n', 0)} · Veröffentlichungen: "
             + (", ".join(f"{USA_TERMIN_REIHEN.get(s_, s_)}: FRED-Release {json.loads(v_).get('id')} „{json.loads(v_).get('name')}“" for s_, v_ in sorted(ids.items())) or "noch nicht bestimmt"))
    if TT.get("naechste"):
        z.append("    nächste Termine (8:30 New York, hier in Ortszeit): "
                 + " · ".join(f"{n_} {tag_kurz(t_)}" for n_, t_ in sorted(TT["naechste"].items(), key=lambda x: x[1])))
    else:
        z.append("    nächste Termine: noch keine (der Takt holt sie einmal am Tag mit dem FRED-Schlüssel)")
    return z


def nachrechnung_text(N: dict | None) -> str:
    """Eine Zeile „Live gegen Nachrechnung“ für Stand und Bericht."""
    if not N or not N.get("archiv"):
        return "  Live gegen Nachrechnung: Archiv mk_signal noch leer (der Takt schreibt den Tagesstand einmal je Tag)"
    kopf = f"  Live gegen Nachrechnung (Archiv seit {N.get('seit')}, {N['archiv']} Zeilen): "
    if not N.get("n"):
        return kopf + "noch kein früherer Tag -- prüfbar ab dem zweiten Archivtag"
    z = (kopf + f"{N['n']} Werte aus {N['tage']} Tagen, Perzentil gleich {N['gleich']} (± {_zahl(N['toleranz'], 2)}), Signal gleich "
         f"{N['signal_gleich']}, größte Abweichung {_zahl(N['max'], 2)} Pz" + (f", {N['fehlt']} ohne Nachrechnung" if N.get("fehlt") else ""))
    if N["gleich"] < N["n"] or N["signal_gleich"] < N["n"]:
        z += (" -- ABWEICHUNG: die Quelle hat alte Werte geändert (oder ein Blick nach vorn); die Bilanz zeigt dann nicht ganz, was live zu "
              "sehen war. Beispiele: " + "; ".join(f"{b['tag']} {b['paar']} {b['fenster']}: {_zahl(b['archiv'], 2)} -> {_zahl(b['neu'], 2)}"
                                                  + (f" ({b['signal_archiv'] or '—'} -> {b['signal_neu'] or '—'})" if b['signal_archiv'] != b['signal_neu'] else "")
                                                  for b in N.get("beispiele", [])[:3]))
    return z


def signal_summe(S: dict | None) -> dict:
    """
    23.56 (U135): Bilanz über alle Paare und Zeiträume -- ein einzelnes „belegt“ liest sich wie ein Beleg; bei vielen Tests liefert
    der Zufall nach der Kalibrierung (hl_makro_signal.FEHLURTEILE, KONZEPT_Makro 9.4) selbst einige. Dazu die Live-Signale und
    davon die, deren eigene Seite (Kauf bzw. Verkauf) in mindestens einem Horizont belegt ist.
    """
    import hl_makro_signal
    bel = tests = 0; live = []; live_bel = []
    for b in ((S or {}).get("paare") or {}).values():
        for name, f in (b.get("fenster") or {}).items():
            bel += int(f.get("belegt") or 0); tests += int(f.get("tests") or 0)
            if f.get("signal"):
                eintrag = f"{b.get('name')} ({b.get('coin')}) {name}"
                live.append((f["signal"], eintrag))
                if any(((bb or {}).get(f["signal"]) or {}).get("belegt") for bb in (f.get("bilanz") or {}).values()):
                    live_bel.append(eintrag)
    lo, hi = (tests * q for q in hl_makro_signal.FEHLURTEILE)
    return {"belegt": bel, "tests": tests, "zufall_lo": lo, "zufall_hi": hi, "live": len(live),
            "live_kauf": sum(1 for s_, _ in live if s_ == "kauf"), "live_verkauf": sum(1 for s_, _ in live if s_ == "verkauf"),
            "live_belegt": live_bel}


def signal_summe_text(G: dict) -> str:
    z_ = (lambda v: f"{v:.0f}") if G["zufall_hi"] >= 10 else (lambda v: f"{v:.1f}".replace(".", ","))
    return (f"  Zusammen: belegt {G['belegt']} von {G['tests']} Tests -- der Zufall allein liefert nach der Kalibrierung (3–5 % Fehlurteile je "
            f"Test) etwa {z_(G['zufall_lo'])}–{z_(G['zufall_hi'])}; ein einzelnes „belegt“ ist ein Hinweis, kein Timing. Live jetzt "
            f"{G['live']} Signale ({G['live_kauf']} Kauf, {G['live_verkauf']} Verkauf), davon mit belegter Bilanz ihrer Seite: "
            f"{len(G['live_belegt'])}" + (f" ({'; '.join(G['live_belegt'])})" if G["live_belegt"] else ""))


def signal_text(S: dict | None, N: dict | None = None) -> list:
    """23.49 (U126): Signale im Stand -- je Paar und Zeitraum Lage, Live-Signal, belegte Bilanz, Prognose 365 T mit Prüfung."""
    if not S:
        return ["  Signale: nicht gerechnet" + (f" ({_SIG['fehler']})" if _SIG.get("fehler") else "")]
    z = [f"  Signale (U126) -- Stand {ts_tag(S['tag'] * TAG)}, gerechnet in {S['dauer_s']} s. Live: Perzentil im Zeitraum ≤ 10 Kauf, ≥ 90 Verkauf "
         f"(nur Daten bis zum Tag). Bilanz über Episoden gegen Zufallstage, belegt bei p < 0,025:"]
    pct = lambda y: "—" if y is None else f"{math.expm1(y) * 100:+.0f} %"
    for key, b in S["paare"].items():
        z.append(f"    {b['name']} ({b['coin']}):")
        for name, f in b["fenster"].items():
            bel = []
            for h, bb in f["bilanz"].items():
                for s_ in ("kauf", "verkauf"):
                    v = bb.get(s_) or {}
                    if v.get("belegt"):
                        bel.append(f"{s_} {h} T {v['mittel'] * 100:+.0f} % (p {v['p']:.3f}, {v['episoden']} Ep.)")
            pr = f.get("prognose") or {}
            h365 = [h for h in pr.get("h", []) if h["tage"] == 365]
            pf = ((pr.get("pruefung") or {}).get("365") or {})
            abd = "—" if pf.get("abdeckung") is None else f"{pf['abdeckung'] * 100:.0f} %"
            live = f"LIVE {f['signal'].upper()} seit {ts_tag(f['seit'] * TAG)}" if f["signal"] else "kein Signal"
            pz_ = f["jetzt"]["pz"]
            zeile = (f"      {name:<5} jetzt {pct(f['jetzt']['y'])} (Perzentil {'—' if pz_ is None else round(pz_)}) · Median {pct(f['median'])} · {live} · "
                     f"belegt: {', '.join(bel) if bel else 'nichts'} ({f['belegt']} von {f['tests']} Tests)")
            hw = pr.get("halbwert")
            if h365 and h365[0].get("wert") is not None:
                nk = 2 if b["key"] == "puell" else 0                      # Puell um 1, sonst Kurse
                zeile += (f" · 365 T: {_zahl(h365[0]['wert'], nk)} [{_zahl(h365[0]['wert_lo'], nk)}–{_zahl(h365[0]['wert_hi'], nk)}]"
                          + (f", Halbwertszeit {hw:.0f} T" if hw is not None and math.isfinite(hw) else ", keine Rückkehr gemessen")
                          + (" (Rückkehr belegt)" if pr.get("belegt") else "") + f", Band traf im Rückblick {abd}")
            z.append(zeile)
    z.append(signal_summe_text(signal_summe(S)))                              # 23.56 (U135)
    z.append(nachrechnung_text(N))
    return z


# ================================================================================================ Selbsttest

def _zeigen(pruef: list, verbose: bool) -> None:
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<64} {txt}")


def _gleich(a, b) -> bool:
    """Bitgleich, NaN gleich NaN."""
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    return a.shape == b.shape and bool(np.all((a == b) | (np.isnan(a) & np.isnan(b))))


def testdaten(pfad: str, n_tage: int = 2600, seed: int = 11, bis_tag: int | None = None) -> None:
    """
    Synthetische makro.db für alle Quellen (deterministisch): BTC mit Power-Law-Trend (b = 5,8) und Zyklus, MVRV als
    Kurs ÷ geglättete Kostenbasis, Hashrate mit Kapitulationsphase, Makroreihen als Zufallswege. Nur für Selbsttests.
    """
    rng = np.random.default_rng(seed)
    bis_tag = bis_tag if bis_tag is not None else tag_ts("2026-09-30") // TAG
    tage = np.arange(bis_tag - n_tage + 1, bis_tag + 1)
    x = np.log10(tage - GENESIS_TAG)
    zyklus = 0.35 * np.sin(2 * np.pi * (tage - tag_ts("2013-06-01") // TAG) / 1461)
    rausch = np.zeros(len(tage))
    for i in range(1, len(tage)):
        rausch[i] = 0.97 * rausch[i - 1] + rng.normal(0, 0.02)
    p = 10 ** (-17.0 + 5.8 * x + zyklus + rausch)
    rp = np.empty(len(p)); rp[0] = p[0] * 0.6
    for i in range(1, len(p)):
        rp[i] = rp[i - 1] + (p[i] - rp[i - 1]) / 300
    s = 19e6 + np.arange(len(p)) * 400.0
    mc = p * s; mv = p / rp
    hr = 5e8 * np.exp(np.arange(len(p)) / 900)
    hr[n_tage - 400:n_tage - 330] *= 0.85                                            # Kapitulation
    hr = hr * np.exp(rng.normal(0, 0.03, len(p)))
    Z = []
    for i, t in enumerate(tage):
        ts = int(t) * TAG
        Z += [("cm:btc:PriceUSD", ts, p[i]), ("cm:btc:CapMrktCurUSD", ts, mc[i]), ("cm:btc:CapMVRVCur", ts, mv[i]),
              ("cm:btc:SplyCur", ts, s[i]), ("cm:btc:HashRate", ts, hr[i]), ("cm:btc:BlkCnt", ts, 144.0),
              ("cm:btc:IssTotNtv", ts, 450.0), ("cm:btc:FeeTotNtv", ts, 5.0), ("cm:btc:IssTotUSD", ts, 450.0 * p[i]),
              ("bc:difficulty", ts, hr[i] * 1e12 * 600 / 2 ** 32), ("bc:hashrate", ts, hr[i]),
              ("cm:eth:PriceUSD", ts, p[i] / 30), ("cm:eth:CapMrktCurUSD", ts, mc[i] / 5), ("cm:eth:CapMVRVCur", ts, mv[i] * 0.9),
              ("cm:eth:SplyCur", ts, 1.2e8), ("cm:xmr:PriceUSD", ts, p[i] / 200)]
        if i >= n_tage - 1400:
            Z += [("fng:wert", ts, float(50 + 30 * math.sin(i / 40))), ("drb:dvol_btc", ts, float(60 + 10 * math.sin(i / 30))),
                  ("bnc:funding_btc_tag", ts, 0.0003), ("bnc:oi_btc_usd", ts, mc[i] * 0.01), ("llama:stable_usd", ts, 1e11 + i * 1e8),
                  ("bgm:sth-realized-price:sthRealizedPrice", ts, float(np.mean(p[max(0, i - 155):i + 1]))),
                  ("bgm:true-market-mean:trueMarketMean", ts, float(np.mean(p[max(0, i - 400):i + 1]))),
                  ("bgm:lth-realized-price:lthRealizedPrice", ts, float(rp[i])), ("bgm:sth-mvrv:sthMvrv", ts, float(p[i] / np.mean(p[max(0, i - 155):i + 1]))),
                  ("bgm:lth-sopr:lthSopr", ts, 1.5), ("bgm:asopr:asopr", ts, 1.0), ("bgm:aviv:aviv", ts, float(mv[i])),
                  ("bgm:realized-loss:realizedLoss", ts, 2e8)]
            if (int(t) + 3) % 7 < 5:
                Z += [("fs:etf_btc", ts, 100.0), ("fs:etf_eth", ts, -10.0)]
        wd = (int(t) + 3) % 7
        if wd == 2:
            Z += [("fred:WALCL", ts, 7e6 + i * 100.0), ("fred:WTREGEN", ts, 8e5), ("fred:ECBASSETSW", ts, 6e6)]
        Z += [("fred:RRPONTSYD", ts, 100.0), ("fred:DFII10", ts, 1.5 + 0.5 * math.sin(i / 90)), ("fred:DTWEXBGS", ts, 120 + rng.normal(0, 1)),
              ("fred:DFF", ts, 4.0), ("fred:DEXUSEU", ts, 1.1), ("fred:DEXJPUS", ts, 150.0)]
        if ts_tag(ts).endswith("-01"):
            Z += [("fred:M2SL", ts, 20000.0 * (1.004 ** (i / 30))), ("fred:JPNASSETS", ts, 7e6)]
            # 23.67 (U153): Arbeitsmarkt und Preise; Oktober 2025 fehlt wie in Wirklichkeit (Quote und Verbraucherpreise)
            if ts >= tag_ts("2008-01-01"):
                mo = i / 30.44
                luecke = ts_tag(ts)[:7] == "2025-10"
                if not luecke:
                    Z += [("fred:UNRATE", ts, round(4.5 + 1.5 * math.sin(mo / 20), 1)), ("fred:CPIAUCNS", ts, 210.0 * 1.0022 ** mo * (1 + 0.002 * math.sin(mo * 0.52))),
                          ("fred:CPIAUCSL", ts, 210.0 * 1.0022 ** mo), ("fred:CPILFENS", ts, 215.0 * 1.002 ** mo), ("fred:CPILFESL", ts, 215.0 * 1.002 ** mo)]
                Z += [("fred:PAYEMS", ts, 140000.0 + 120.0 * mo + 300 * math.sin(mo / 7)), ("fred:PPIFID", ts, 100.0 * 1.0018 ** mo),
                      ("fred:PPIFIS", ts, 100.0 * 1.0018 ** mo)]
        if wd == 5 and ts >= tag_ts("2008-01-05"):                                       # Samstag (Woche bis Samstag)
            Z += [("fred:ICSA", ts, 220000.0 + 20000 * math.sin(i / 25))]
    con = verbinden(pfad)
    try:
        schreiben(con, Z)
    finally:
        con.close()


def mathe_probe(verbose: bool = True) -> tuple:
    """Je Treiber Positivkontrolle und Nulltest auf festen oder synthetischen Reihen (Soll aus der Mathematik)."""
    pruef = []
    rng = np.random.default_rng(3)
    # --- Perzentil (expandierend, rollierend) -------------------------------------------------------------------------
    auf = perzentil_expandierend(np.arange(500.0), 100); ab = perzentil_expandierend(-np.arange(500.0), 100)
    konst = perzentil_expandierend(np.full(300, 7.0), 50)
    x = rng.normal(0, 1, 600); x[-1] = x.max() + 1; spitze = perzentil_expandierend(x, 100)[-1]
    letzte = np.array([perzentil_expandierend(rng.normal(0, 1, 400), 100)[-1] for _ in range(400)])
    dez = np.histogram(letzte, bins=10, range=(0, 100.0001))[0] / len(letzte)
    se = 100 / math.sqrt(12) / math.sqrt(len(letzte))
    ok = (np.nanmin(auf[99:]) == 100 and np.nanmax(ab[99:]) == 0 and np.allclose(konst[49:], 50) and spitze == 100
          and abs(letzte.mean() - 50) < 3 * se and np.all(np.abs(dez - 0.1) < 3 * math.sqrt(0.09 / len(letzte))))
    pruef.append(("Perzentil: steigend 100, fallend 0, Spitze 100, gleich 50; Rauschen gleichverteilt", bool(ok),
                  f"Rauschen Mittel {letzte.mean():.1f} (Soll 50 ± {3 * se:.1f}), Zehntel {dez.min():.3f}–{dez.max():.3f}".replace(".", ",")))
    y = rng.normal(0, 1, 900); y2 = y.copy(); y2[700:] = 1e6
    ok = (_gleich(perzentil_expandierend(y, 100)[:700], perzentil_expandierend(y2, 100)[:700])
          and _gleich(perzentil_rollierend(y, 365, 100)[:700], perzentil_rollierend(y2, 365, 100)[:700]))
    w = np.concatenate([np.full(400, 10.0), np.arange(400.0) / 100])          # Höhe 10 liegt > 1 Fenster zurück
    roll = perzentil_rollierend(w, 365, 100)[-1]; exp_ = perzentil_expandierend(w, 100)[-1]
    pruef.append(("Perzentil kausal (Zukunft ändert die Vergangenheit nicht), Fenster wirkt", bool(ok and roll == 100 and exp_ < 51),
                  f"rollierend {roll:.0f}, expandierend {exp_:.0f} (alte Höhe außerhalb des Fensters)".replace(".", ",")))
    # --- Realized Price, NUPL, MVRV-Z, Delta Price (Formeln) --------------------------------------------------------
    mc = np.array([100.0, 120, 90, 150]); mv = np.array([2.0, 2.4, 1.5, 1.0]); s = np.array([10.0, 10, 10, 10])
    rc = mc / mv; rp = rc / s; nupl = 1 - 1 / mv
    z = (mc - rc) / streuung_expandierend(mc); ac = mittel_expandierend(mc); dp = (rc - ac) / s
    ok = (np.allclose(rp, [5, 5, 6, 15]) and np.allclose(nupl, [0.5, 1 - 1 / 2.4, 1 / 3, 0]) and abs(z[3]) < 1e-12
          and abs(z[1] - (120 - 50) / np.std(mc[:2])) < 1e-9 and np.allclose(dp, (rc - np.cumsum(mc) / np.arange(1, 5)) / 10))
    pruef.append(("Realized Price, NUPL, MVRV-Z, Delta Price: Formeln; MVRV 1 -> Z 0, NUPL 0", bool(ok),
                  f"RP {rp.tolist()}, Z(MVRV=1) {z[3]:.0f}".replace(".", ",")))
    # --- Power Law: Exponent gefunden, ohne Trend kein Exponent, kausal --------------------------------------------
    tage = np.arange(tag_ts("2011-01-01") // TAG, tag_ts("2026-06-30") // TAG)
    rausch = np.zeros(len(tage))
    for i in range(1, len(tage)):
        rausch[i] = 0.98 * rausch[i - 1] + rng.normal(0, 0.03)
    p = 10 ** (-17.0 + 5.8 * np.log10(tage - GENESIS_TAG) + rausch)
    pl = powerlaw_monatlich(tage, p); b_last = pl["parameter"][-1]["b"]
    flach = powerlaw_monatlich(tage, 10 ** (3 + rausch))["parameter"][-1]["b"]
    p2 = p.copy(); k = len(tage) - 300; p2[k:] *= 50
    pl2 = powerlaw_monatlich(tage, p2)
    monat_k = ts_tag(int(tage[k]) * TAG)[:7]
    vor = [q for q in pl["parameter"] if q["monat"] <= monat_k]; vor2 = [q for q in pl2["parameter"] if q["monat"] <= monat_k]
    grenze = next(i for i, t in enumerate(tage) if ts_tag(int(t) * TAG)[:7] == monat_k)
    kausal = vor == vor2 and _gleich(pl["pz"][:grenze], pl2["pz"][:grenze]) and _gleich(pl["rest"][:grenze], pl2["rest"][:grenze])
    hoch = p.copy(); hoch[-1] *= 10 ** (4 * pl["parameter"][-1]["sd"]); pz_hoch = powerlaw_monatlich(tage, hoch)["pz"][-1]
    ok = abs(b_last - 5.8) < 0.1 and abs(flach) < 0.5 and kausal and pz_hoch > 99
    pruef.append(("Power Law: b = 5,8 gefunden, ohne Trend b ≈ 0, kausal, 4 σ -> Perzentil > 99", bool(ok),
                  f"b {b_last:.3f}, flach {flach:+.3f}, 4-σ-Tag {pz_hoch:.1f}. Pz, kausal {'ja' if kausal else 'NEIN'}".replace(".", ",")))
    # --- 200-Wochen-MA ------------------------------------------------------------------------------------------------
    t2 = np.arange(tag_ts("2015-01-01") // TAG, tag_ts("2020-01-01") // TAG)
    konstant = wma200(t2, np.full(len(t2), 5.0)); rampe = t2.astype(float)
    wr = wma200(t2, rampe)
    so = np.nonzero(wochentag(t2) == 6)[0]; i = so[-1]
    soll_so = rampe[so[-200:]].mean()
    mitte = so[-1] - 3; k_ = np.searchsorted(so, mitte, "left")
    soll_mitte = (rampe[so[k_ - 199:k_]].sum() + rampe[mitte]) / 200
    ok = np.allclose(konstant[np.isfinite(konstant)], 5.0) and np.isfinite(konstant).sum() > 300 and abs(wr[i] - soll_so) < 1e-9 and abs(wr[mitte] - soll_mitte) < 1e-9
    pruef.append(("200-Wochen-MA: konstant = Kurs, Sonntag = Mittel der 200 Sonntage, Wochenmitte mit Tageskurs", bool(ok),
                  f"Sonntag {wr[i]:.2f} = {soll_so:.2f}".replace(".", ",")))
    # --- Puell --------------------------------------------------------------------------------------------------------
    iss = np.full(800, 900.0); iss[500:] = 450.0
    pu = iss / sma(iss, 365); kon = np.full(800, 3.0) / sma(np.full(800, 3.0), 365)
    ok = abs(pu[500] - 450 / ((364 * 900 + 450) / 365)) < 1e-9 and np.allclose(kon[364:], 1.0) and pu[499] == 1.0
    pruef.append(("Puell: gleiche Emission -> 1, Halbierung -> 0,5", bool(ok), f"nach Halbierung {pu[500]:.4f}".replace(".", ",")))
    # --- Hash Ribbons ------------------------------------------------------------------------------------------------
    n = 700; tg = np.arange(20000, 20000 + n)
    h = 100 * np.exp(rng.normal(0, 0.03, n)); h[400:460] *= 0.85
    preis = np.concatenate([np.linspace(100, 80, 460), np.linspace(80, 120, n - 460)])
    rb = hash_ribbons(tg, h, preis); ep = [e for e in rb["episoden"] if e["echt"]]
    flach_ = [e for _ in range(20) for e in hash_ribbons(tg, 1e8 * np.exp(rng.normal(0, 0.08, n)), np.full(n, 100.0))["episoden"] if e["schwelle"]]
    anteil = np.mean([e["echt"] for e in flach_]) if flach_ else 1.0
    ok = (len(ep) == 1 and ep[0]["von"] - 20000 in range(400, 425) and ep[0]["signal"] is not None and ep[0]["erholt"] is not None
          and anteil <= 0.03 and len(flach_) > 100)
    pruef.append(("Hash Ribbons: Rückgang 15 % echt mit Erholung und Signal; reines Rauschen (σ 8 %) fast nie über der Schwelle", bool(ok),
                  (f"Tiefe {ep[0]['tiefe'] * 100:+.1f} % > Schwelle {ep[0]['schwelle'] * 100:.1f} %; Rauschen: {anteil * 100:.1f} % von "
                   f"{len(flach_)} Episoden echt (Soll ≈ 0,7 %)").replace(".", ",") if ep else f"echte Episoden: {len(ep)}"))
    dr0 = difficulty_ribbon(np.full(400, 5.0))["breite"]; d1 = np.full(400, 5.0); d1[300:] = 4.0
    dr1 = difficulty_ribbon(d1)["breite"]
    ok = np.allclose(dr0[199:], 0) and np.nanmax(dr1) > 0.05
    pruef.append(("Difficulty Ribbon: konstant -> Breite 0; Rückgang -> Breite > 5 %", bool(ok), f"Breite max {np.nanmax(dr1) * 100:.1f} %".replace(".", ",")))
    # --- Miner-Kosten ------------------------------------------------------------------------------------------------
    D_ = np.full(10, 1.318e14); iss_ = np.full(10, 450.0); fee_ = np.full(10, 5.04); blk_ = np.full(10, 144.0)
    u = miner_einheit(D_, iss_, fee_, blk_)[-1]; kosten = 13.5 * 0.075 * u
    u2 = miner_einheit(D_ * 2, iss_, fee_, blk_)[-1]
    soll_u = 1.318e14 * 2 ** 32 / 1e12 / 3.6e6 / (455.04 / 144)
    ok = abs(u - soll_u) < 1e-6 * soll_u and abs(kosten - 50_383) < 15 and abs(u2 / u - 2) < 1e-12
    pruef.append(("Miner-Kosten: D 1,318e14, Erlös 3,16 BTC/Block, 13,5 J/TH, 7,5 ct -> ~50.383 USD; linear in D", bool(ok),
                  f"Einheit {u:,.0f}, Kosten {kosten:,.0f} USD je BTC".replace(",", ".")))
    # --- Halving, Epochen, Divergenz ----------------------------------------------------------------------------------
    ok = (tag_ts("2025-10-06") // TAG - halving_tage()[-1] == 534 and epoche(np.array([tag_ts("2012-11-27") // TAG]))[0] == 0
          and epoche(np.array([tag_ts("2012-11-28") // TAG]))[0] == 1)
    pruef.append(("Halving: 06.10.2025 ist Tag 534; Halving-Tag gehört zur neuen Epoche", bool(ok), "Tops früher 525, 546, 534"))
    tg = np.arange(tag_ts("2021-01-01") // TAG, tag_ts("2021-12-31") // TAG)
    pr = np.concatenate([np.linspace(30e3, 60e3, 100), np.linspace(60e3, 40e3, 100), np.linspace(40e3, 70e3, len(tg) - 200)])
    mvr = np.concatenate([np.linspace(2, 4, 100), np.linspace(4, 2.5, 100), np.linspace(2.5, 3.0, len(tg) - 200)])
    dv = divergenzen(tg, pr, mvr); dv0 = divergenzen(tg, pr, pr / 15e3)
    ok = len(dv) > 0 and dv[-1]["unter"] > 0.2 and not dv0
    pruef.append(("Bewertungsdivergenz: neues Kurshoch bei MVRV 25 % unter Hoch erkannt; MVRV ∝ Kurs -> keine", bool(ok),
                  f"{len(dv)} Tage, zuletzt {dv[-1]['unter'] * 100:.0f} % unter dem Hoch".replace(".", ",") if dv else "keine"))
    # --- Funding, RSI, Korrelation, Liquidität ----------------------------------------------------------------------
    jt = bnc_funding_parse([{"fundingTime": 1700000000000 + k * 8 * 3600 * 1000, "fundingRate": "0.0001"} for k in range(9)]
                           + [{"fundingTime": 1700000000000, "fundingRate": "0.0001"}])
    tage_s = sorted(jt); summen = [sum(jt[t].values()) for t in tage_s]
    ok = any(abs(sm * 365 * 100 - 10.95) < 1e-9 for sm in summen) and all(len(jt[t]) <= 3 for t in tage_s)
    pruef.append(("Funding: 3 × 0,01 % am Tag -> 10,95 % p. a.; doppelte Zeitpunkte zählen einmal", bool(ok),
                  f"Tagessummen {[round(sm * 1e4, 2) for sm in summen]} Basispunkte".replace(".", ",")))
    r_auf = rsi_wilder(np.arange(1.0, 60.0))[-1]; r_ab = rsi_wilder(np.arange(60.0, 1.0, -1))[-1]
    r_wechsel = rsi_wilder(np.array([10.0 + (k % 2) for k in range(200)]))[-1]
    # Wilders Rechenbeispiel (StockCharts, RSI 14): 70,53 66,32 66,55 69,41 66,36 57,97
    ref = rsi_wilder(np.array([44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4245, 45.8433, 46.0826, 45.8931, 46.0328,
                               45.614, 46.282, 46.282, 46.0028, 46.0328, 46.4116, 46.2222, 45.6439]), 14)[14:]
    ok = r_auf == 100 and r_ab == 0 and abs(r_wechsel - 50) < 2 and np.allclose(np.round(ref, 2), [70.53, 66.32, 66.55, 69.41, 66.36, 57.97])
    pruef.append(("Wochen-RSI: Wilders Rechenbeispiel exakt; steigend 100, fallend 0, Wechsel ≈ 50", bool(ok),
                  f"Beispiel {', '.join(f'{x:.2f}' for x in ref[:3])} …; Wechsel {r_wechsel:.1f}".replace(".", ",")))
    a_ = rng.normal(0, 1, 200)
    k1 = korrelation_rollierend(a_, a_, 52, 40)[-1]; k2 = korrelation_rollierend(a_, -a_, 52, 40)[-1]
    nullk = np.array([korrelation_rollierend(rng.normal(0, 1, 52), rng.normal(0, 1, 52), 52, 40)[-1] for _ in range(400)])
    ok = abs(k1 - 1) < 1e-12 and abs(k2 + 1) < 1e-12 and abs(nullk.mean()) < 3 * nullk.std() / math.sqrt(400) + 0.01 and 0.10 < nullk.std() < 0.18
    pruef.append(("Korrelation 52 W: gleich +1, gespiegelt −1; unabhängig Mittel ≈ 0, Streuung ≈ 1/√51", bool(ok),
                  f"unabhängig {nullk.mean():+.3f} ± {nullk.std():.3f} (Soll 0 ± 0,14)".replace(".", ",")))
    reg = _regime(np.array([np.nan, 0.05]), np.array([True, False]), 52)
    ok = "kein belegter Zusammenhang" in reg["regime"] and reg["band"] == 2 / math.sqrt(52)
    reg2 = _regime(np.array([0.6, -0.5]), np.array([True, False]), 52)
    ok = ok and "Vorzeichen gedreht" in reg2["regime"]
    pruef.append(("Regimelabel: |r| im Zufallsband -> kein Zusammenhang; Vorzeichenwechsel benannt", bool(ok), reg2["regime"]))
    z_ = z_expandierend(np.concatenate([np.full(200, 1.0) + rng.normal(0, 0.01, 200), [2.0]]), 100)
    ok = z_[-1] > 10 and abs(np.nanmean(z_expandierend(rng.normal(0, 1, 2000), 100))) < 0.3
    pruef.append(("AVIV-z (expandierend): Ausreißer z > 10, Rauschen im Mittel ≈ 0", bool(ok), f"Ausreißer z {z_[-1]:.0f}".replace(".", ",")))
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def parser_probe(verbose: bool = True) -> tuple:
    """Parser gegen die dokumentierten bzw. am 05.10.2026 gelesenen Antwortformate, mit Randfällen."""
    pruef = []
    d = {"data": [{"asset": "xmr", "time": "2026-10-03T00:00:00.000000000Z", "CapMrktCurUSD": "10173821620.24", "PriceUSD": "555.46",
                   "SplyCur": "18315920.86"}, {"asset": "btc", "time": "2026-10-04T00:00:00.000000000Z", "PriceUSD": "86520.80", "CapMVRVCur": None}],
         "next_page_token": "x", "next_page_url": "https://community-api.coinmetrics.io/v4/next"}
    z, url = cm_parse(d)
    ok = (sorted(r[0] for r in z) == ["cm:btc:PriceUSD", "cm:xmr:CapMrktCurUSD", "cm:xmr:PriceUSD", "cm:xmr:SplyCur"]
          and all(r[1] % TAG == 0 for r in z) and url.endswith("/next") and cm_parse({"data": []})[1] is None)
    pruef.append(("Coin Metrics: Zeichenketten, fehlende Metrik, null, nächste Seite", bool(ok), f"{len(z)} Werte"))
    u = cm_url("btc", ("PriceUSD", "CapMVRVCur"), "2026-09-20")
    ok = "paging_from=start" in u and "page_size=10000" in u and "metrics=PriceUSD,CapMVRVCur" in u and "start_time=2026-09-20" in u
    pruef.append(("Coin Metrics: Adresse mit paging_from=start, Seitengröße 10.000", bool(ok), u.split("?")[1][:70]))
    text = "observation_date,WALCL\n2026-09-24,6650000\n2026-10-01,\n2026-10-02,.\nDATE,X\n2026-10-08,6660000.5\n"
    z = fred_parse("WALCL", text)
    ok = [w for _, _, w in z] == [6650000.0, 6660000.5] and z[0][1] == tag_ts("2026-09-24")
    pruef.append(("FRED: Kopf observation_date/DATE, fehlende Werte leer und '.'", bool(ok), f"{len(z)} Werte"))
    d = {"realtime_start": "2026-10-05", "realtime_end": "2026-10-05", "count": 4, "offset": 0, "limit": 100000,
         "observations": [{"realtime_start": "2026-10-05", "realtime_end": "2026-10-05", "date": "2026-09-24", "value": "6650000"},
                          {"realtime_start": "2026-10-05", "realtime_end": "2026-10-05", "date": "2026-10-01", "value": "."},
                          {"date": "2026-10-08", "value": "6660000.5"}, "kaputt"]}
    z = fred_api_parse("WALCL", d)
    u = fred_api_url("WALCL", "2008-01-01", "a" * 32)
    ok = (z == [("fred:WALCL", tag_ts("2026-09-24"), 6650000.0), ("fred:WALCL", tag_ts("2026-10-08"), 6660000.5)]
          and fred_api_parse("WALCL", {"error_code": 400, "error_message": "Bad Request."}) == [] and fred_api_parse("WALCL", None) == []
          and u.startswith("https://api.stlouisfed.org/fred/series/observations?") and "series_id=WALCL" in u and "file_type=json" in u
          and "observation_start=2008-01-01" in u)
    pruef.append(("FRED-API (JSON): observations, '.' fehlt, Fehlerantwort leer; Adresse mit series_id/file_type", bool(ok), f"{len(z)} Werte"))
    z = fng_parse({"name": "Fear and Greed Index", "data": [{"value": "65", "value_classification": "Greed", "timestamp": "1791072000",
                                                             "time_until_update": "43413"}, {"value": "67", "timestamp": "1790985600"}],
                   "metadata": {"error": None}})
    ok = z == [("fng:wert", 1791072000, 65.0), ("fng:wert", 1790985600, 67.0)]
    pruef.append(("alternative.me: Werte und Zeit als Text, Sekunden", bool(ok), "65 / 67"))
    z = llama_parse([{"date": "1511913600", "totalCirculating": {"peggedUSD": 109970}, "totalCirculatingUSD": {"peggedUSD": 110105}},
                     {"date": "1791072000", "totalCirculatingUSD": {"peggedUSD": 3.0e11, "peggedEUR": 7.0e8}}, {"date": "1557619200"}])
    ok = z == [("llama:stable_usd", 1511913600, 110105.0), ("llama:stable_usd", 1791072000, 3.007e11)]
    pruef.append(("DefiLlama: alle Bindungen in USD summiert, Einträge ohne Summe fallen weg", bool(ok), f"{len(z)} Tage"))
    z = bc_parse("difficulty", {"status": "ok", "name": "Difficulty", "values": [{"x": 1230940800, "y": 1.0}, {"x": 1231027200, "y": 0.0},
                                                                                {"x": 1379203200, "y": 1.12628548666347E8}]})
    ok = z == [("bc:difficulty", 1230940800, 1.0), ("bc:difficulty", 1379203200, 112628548.666347)]
    pruef.append(("Blockchain.com: Nullwerte der Frühzeit fallen weg, E-Schreibweise", bool(ok), f"{len(z)} Werte"))
    z, w = drb_parse("BTC", {"jsonrpc": "2.0", "result": {"data": [[1758931200000, 36.55, 36.87, 36.35, 36.42], [1759017600000, 36.42, 36.83, 35.71, 35.86]],
                                                           "continuation": None}})
    ok = z == [("drb:dvol_btc", 1758931200, 36.42), ("drb:dvol_btc", 1759017600, 35.86)] and w is None
    pruef.append(("Deribit DVOL: Schlusswert, Millisekunden -> Sekunden", bool(ok), "36,42 / 35,86"))
    z = bnc_oi_parse([{"symbol": "BTCUSDT", "sumOpenInterest": "80000.5", "sumOpenInterestValue": "6900000000.1", "timestamp": "1790985600000"}])
    ok = z == [("bnc:oi_btc_usd", 1790985600, 6900000000.1), ("bnc:oi_btc_coins", 1790985600, 80000.5)]
    pruef.append(("Binance Open Interest (REST, 1 Tag)", bool(ok), "USD und BTC"))
    puffer = io.BytesIO()
    with zipfile.ZipFile(puffer, "w") as zf:
        zf.writestr("BTCUSDT-metrics-2021-03-05.csv", "create_time,symbol,sum_open_interest,sum_open_interest_value,count_toptrader_long_short_ratio\n"
                    "2021-03-05 00:05:00,BTCUSDT,61000.1,2950000000.5,1.1\n2021-03-05 00:00:00,BTCUSDT,60000.0,2900000000.0,1.0\n"
                    "2021-03-05 23:55:00,BTCUSDT,62000.0,3000000000.0,1.2\n")
    z = oi_archiv_parse("2021-03-05", puffer.getvalue())
    ok = z == [("bnc:oi_btc_usd", tag_ts("2021-03-05"), 2900000000.0), ("bnc:oi_btc_coins", tag_ts("2021-03-05"), 60000.0)] and oi_archiv_parse("2021-03-05", b"kein zip") == []
    pruef.append(("Binance-Archiv (ZIP/CSV): früheste Zeile des Tages, kaputtes ZIP -> nichts", bool(ok), "00:00-Stand"))
    html = ("<table><tr><th>Date</th><th>IBIT</th><th>Total</th></tr><tr><td>11 Jan 2024</td><td>111.7</td><td>655.3</td></tr>"
            "<tr><td>12 Jan 2024</td><td>(95.1)</td><td>(1,203.0)</td></tr><tr><td>15 Jan 2024</td><td>-</td><td>-</td></tr>"
            "<tr><td>Total</td><td>1</td><td>2</td></tr><tr><td>16 Jan 2024</td><td>0.0</td><td>0.0</td></tr></table>")
    z = farside_parse("btc", html)
    ok = [w for _, _, w in z] == [655.3, -1203.0, 0.0] and z[1][1] == tag_ts("2024-01-12")
    pruef.append(("Farside: Klammern negativ, Tausenderkomma, '-' keine Daten, Summenzeilen fallen weg", bool(ok), "655,3 / −1.203 / 0"))
    z = bgm_parse("sth-realized-price", [{"d": "2022-07-09", "unixTs": 1657324800, "sthRealizedPrice": 0.9794},
                                         {"d": "2022-07-10", "unixTs": "1657411200000", "sthRealizedPrice": "0.9455", "btcPrice": "20000"},
                                         {"d": "2022-07-11", "sthRealizedPrice": None}])
    ok = (("bgm:sth-realized-price:sthRealizedPrice", 1657324800, 0.9794) in z and ("bgm:sth-realized-price:sthRealizedPrice", 1657411200, 0.9455) in z
          and ("bgm:sth-realized-price:btcPrice", 1657411200, 20000.0) in z and len(z) == 3)
    pruef.append(("BGeometrics: jedes Zahlenfeld eine Reihe, ms erkannt, Text-Zahlen, null fällt weg", bool(ok), f"{len(z)} Werte"))
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


class _FalschesNetz:
    """Antwortet je Adresse wie die Quellen (kleine Ausschnitte), zählt Aufrufe; Fehler auf Wunsch."""

    def __init__(self):
        self.aufrufe: list = []; self.fehler: dict = {}; self.oi_404 = set(); self.termine: dict = {}; self.usa_wert: dict = {}

    def __call__(self, url, timeout=30, art="json"):
        self.aufrufe.append(url)
        for muster, err in self.fehler.items():
            if muster in url:
                return None, err
        heute = tag_ts("2026-10-05")
        if "coinmetrics" in url:
            asset = re.search(r"assets=(\w+)", url).group(1)
            zeilen = [{"asset": asset, "time": ts_tag(heute - k * TAG) + "T00:00:00.000000000Z", "PriceUSD": str(100 + k)} for k in range(3)]
            return {"data": zeilen}, None
        if "fredgraph" in url:
            sid = re.search(r"id=(\w+)", url).group(1)
            return f"observation_date,{sid}\n2026-09-30,1.5\n2026-10-01,1.6\n", None
        if "fred/series/release" in url:                                  # 23.67 (U153)
            sid = re.search(r"series_id=(\w+)", url).group(1)
            rid = {"UNRATE": 50, "ICSA": 180, "CPIAUCSL": 10, "PPIFIS": 46}.get(sid, 999)
            return {"releases": [{"id": rid, "name": f"Release {rid}", "press_release": True}]}, None
        if "fred/release/dates" in url:
            rid = int(re.search(r"release_id=(\d+)", url).group(1))
            tage = self.termine.get(rid, ["2025-12-18", "2026-09-11", "2026-10-14", "2026-11-13"])
            if "include_release_dates_with_no_data=true" not in url:          # wie die echte API: künftige nur mit dem Schalter
                tage = [t for t in tage if t <= "2026-10-13"]
            return {"release_dates": [{"release_id": rid, "date": t} for t in tage]}, None
        if "api.stlouisfed.org" in url and "output_type=4" in url:        # ALFRED: Erstveröffentlichung
            sid = re.search(r"series_id=(\w+)", url).group(1)
            return {"observations": [{"realtime_start": "2026-09-11", "realtime_end": "2026-10-13", "date": "2026-08-01", "value": "1.4"},
                                     {"realtime_start": "2026-10-14", "realtime_end": "9999-12-31", "date": "2026-09-01", "value": "."}]}, None
        if "api.stlouisfed.org" in url:
            sid = re.search(r"series_id=(\w+)", url).group(1)
            return {"observations": [{"date": "2026-09-30", "value": str(self.usa_wert.get(sid, 1.5))}, {"date": "2026-10-01", "value": "."},
                                     {"date": "2026-10-02", "value": "1.7"}]}, None
        if "alternative.me" in url:
            return {"data": [{"value": "40", "timestamp": str(heute)}]}, None
        if "stablecoins.llama" in url:
            return [{"date": str(heute), "totalCirculatingUSD": {"peggedUSD": 3e11}}], None
        if "blockchain.info" in url:
            return {"values": [{"x": heute, "y": 1.3e14}]}, None
        if "deribit" in url:
            return {"result": {"data": [[heute * 1000, 40, 41, 39, 40.5]], "continuation": None}}, None
        if "fundingRate" in url:
            return [{"fundingTime": (heute - TAG) * 1000 + k * 8 * 3600 * 1000, "fundingRate": "0.0001"} for k in range(4)], None
        if "openInterestHist" in url:
            return [{"sumOpenInterest": "1", "sumOpenInterestValue": "7e9", "timestamp": str((heute - k * TAG) * 1000)} for k in range(30)], None
        if "farside" in url:
            return "<tr><td>02 Oct 2026</td><td>1</td><td>(12.5)</td></tr>", None
        if "bitcoin-data.com" in url:
            ep = url.split("/v1/")[1].split("?")[0]
            return [{"d": ts_tag(heute), "unixTs": heute, ep.replace("-", "_"): 1.23}], None
        if "data.binance.vision" in url:
            tag = re.search(r"metrics-(\d{4}-\d{2}-\d{2})", url).group(1)
            if tag in self.oi_404:
                return None, "HTTP 404: Not Found"
            puffer = io.BytesIO()
            with zipfile.ZipFile(puffer, "w") as zf:
                zf.writestr("x.csv", f"create_time,symbol,sum_open_interest,sum_open_interest_value\n{tag} 00:00:00,BTCUSDT,1,5e9\n")
            return puffer.getvalue(), None
        return None, "HTTP 404: unbekannt"


def abruf_probe(verbose: bool = True) -> tuple:
    """Zeitplan mit falschem Netz und springender Uhr: voller Erstabruf, Pausen nach Fehlern, BGeometrics-Budget, Archiv."""
    import shutil
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="mk_abruf_")
    try:
        uhr = [float(tag_ts("2026-10-05") + 6 * 3600)]
        netz = _FalschesNetz(); netz.fehler["id=DFF"] = "HTTP 503: kaputt"
        m = Makro(os.path.join(tmp, "makro.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel="")   # ohne Schlüssel: fredgraph.csv
        e1 = m.runde(archiv=False)
        voll = ("start_time=2009-01-01" in " ".join(u for u in netz.aufrufe if "coinmetrics" in u) and any("limit=0" in u for u in netz.aufrufe)
                and any("timespan=all" in u for u in netz.aufrufe) and any("cosd=2008-01-01" in u for u in netz.aufrufe))
        fehler_ok = e1["ziele"].get("fred:DFF") == -1 and "503" in (meta(m.con, "fehler:fred:DFF") or "")
        n1 = len(netz.aufrufe); e2 = m.runde(archiv=False)
        zweite = netz.aufrufe[n1:]
        nichts = (len(zweite) <= 1 and not any("id=DFF" in u for u in zweite)          # höchstens ein BGeometrics-Abruf; DFF wartet
                  and float(meta(m.con, "pause:fred:DFF")) >= uhr[0] + 900 - 1)       # 15 min Pause nach dem ersten Fehler
        pruef.append(("Erstabruf: ganze Historie je Quelle; Fehler einer Reihe hält die anderen nicht an", bool(voll and fehler_ok),
                      f"{n1} Abrufe, Fehler FRED DFF gemerkt"))
        uhr[0] += 13 * 3600; netz.fehler.clear(); n2 = len(netz.aufrufe)
        e3 = m.runde(archiv=False)
        neu = netz.aufrufe[n2:]
        inkr = (any("coinmetrics" in u and "start_time=2026-09" in u for u in neu) and any("limit=40" in u for u in neu)
                and any("timespan=90days" in u for u in neu) and any("id=DFF" in u for u in neu))
        pruef.append(("Danach nur das jüngste Stück mit Überlappung; nach der Pause wird der Fehler nachgeholt", bool(nichts and inkr),
                      f"zweite Runde sofort: {len(netz.aufrufe) - n1 - (len(netz.aufrufe) - n2)} Abrufe, nach 13 h: {len(neu)}"))
        f_tage = [r[0] for r in m.con.execute("SELECT ts FROM mk_reihe WHERE reihe='bnc:funding_btc_tag' ORDER BY ts")]
        ok = f_tage == [tag_ts("2026-10-04")] and abs(m.con.execute("SELECT wert FROM mk_reihe WHERE reihe='bnc:funding_btc_tag'").fetchone()[0] - 0.0003) < 1e-12
        pruef.append(("Funding: nur abgeschlossene Tage (UTC), Tagessumme", bool(ok), f"Tage {[ts_tag(t) for t in f_tage]}"))
        # BGeometrics-Budget: 3 Stunden lang jede Minute fragen
        zeiten = []
        for k in range(180):
            uhr[0] += 60; vorher = len(netz.aufrufe)
            m.bgm_schritt()
            if len(netz.aufrufe) > vorher:
                zeiten.append(uhr[0])
        je_h = max(sum(1 for t in zeiten if s <= t < s + 3600) for s in zeiten) if zeiten else 0
        abstand = min(np.diff(zeiten)) if len(zeiten) > 1 else 9999
        alle = {ep for ep in BGM if meta(m.con, f"voll:bgm:{ep}") == "1"}
        ok = je_h <= BGM_JE_STUNDE and abstand >= BGM_ABSTAND_S and alle == set(BGM)
        pruef.append(("BGeometrics: höchstens 7 je Stunde, 8 min Abstand, jeder Endpunkt einmal am Tag", bool(ok),
                      f"{len(zeiten)} Abrufe in 3 h, höchstens {je_h} je Stunde, Abstand ≥ {abstand / 60:.0f} min"))
        b = m.bgm_budget(); m2_ = sum(1 for x in b["liste"] if x >= int(uhr[0]) // TAG * TAG)
        zweiter = Makro(m.pfad, http_fn=netz, uhr=lambda: uhr[0], fred_schluessel="")
        ok = m2_ <= BGM_JE_TAG and zweiter.bgm_budget()["tag"] == b["tag"]                  # Budget überlebt den Neustart
        zweiter.con.close()
        # Grenzen direkt: 7 Abrufe in der letzten Stunde oder 14 heute sperren, 8 min Abstand sperrt
        jetzt_ = uhr[0]; mitternacht = int(jetzt_) // TAG * TAG
        for liste, soll in (([jetzt_ - 3500 + k * 400 for k in range(7)], False), ([mitternacht + 60 + k * 600 for k in range(14) if mitternacht + 60 + k * 600 < jetzt_ - 3700], None),
                            ([jetzt_ - 300], False), ([jetzt_ - 600], True)):
            if soll is None:
                soll = len(liste) < BGM_JE_TAG
            _meta_setzen(m.con, {"bgm_aufrufe": json.dumps(liste)})
            ok = ok and m.bgm_budget()["frei"] == soll
        pruef.append(("BGeometrics: 7 je Stunde, 14 je Tag (UTC), 8 min Abstand sperren; Budget überlebt den Neustart", bool(ok),
                      f"heute {b['tag']} Abrufe"))
        # Archiv (23.50): RÜCKWÄRTS ab dem Tag vor den REST-Daten, jüngste Tage zuerst; ein früherer Vorwärtslauf (bis 23.49, hier
        # 01.09.2020–24.08.2026 schon da, alter Cursor 25.08.) wird übersprungen; 404 zählt als fehlend; dann fertig
        vorher = [("bnc:oi_btc_usd", t, 5e9) for t in range(tag_ts(OI_ARCHIV_START), tag_ts("2026-08-25"), TAG)]
        schreiben(m.con, vorher)
        _meta_setzen(m.con, {"oi_archiv_cursor": tag_ts("2026-08-25")})
        netz.oi_404.add("2026-08-27")
        rest0 = int(meta(m.con, "oi_rest_erster"))
        a0 = len(netz.aufrufe); schritte = 0; mitte = None
        while meta(m.con, "oi_archiv_fertig") != "1" and schritte < 60:
            m.oi_archiv_schritt(); schritte += 1
            if schritte == 3:
                mitte = oi_abdeckung(m.con)
        reihenfolge = [re.search(r"metrics-(\d{4}-\d{2}-\d{2})", u).group(1) for u in netz.aufrufe[a0:] if "data.binance.vision" in u]
        soll_r = [ts_tag(t) for t in range(rest0 - TAG, tag_ts("2026-08-24"), -TAG)]
        geholt = {ts_tag(r[0]) for r in m.con.execute("SELECT ts FROM mk_reihe WHERE reihe='bnc:oi_btc_usd' AND ts < ?", (rest0,))}
        ab = oi_abdeckung(m.con)
        ok = (meta(m.con, "oi_archiv_fertig") == "1" and reihenfolge == soll_r and "2026-08-27" not in geholt
              and int(meta(m.con, "oi_archiv_fehlend")) == 1 and ab["fertig"] and ab["offen"] == 0 and ab["fehlen"] == 1
              and not ab["lueckenhaft"] and ab["n_abschnitte"] == 2 and mitte and mitte["offen"] == len(soll_r) - 3 and mitte["n_abschnitte"] == 2)
        pruef.append(("Binance-Archiv: rückwärts ab den REST-Daten (jüngste zuerst), Vorwärtslauf übersprungen, 404 als fehlend, fertig",
                      bool(ok), f"{len(reihenfolge)} Abrufe {reihenfolge[0] if reihenfolge else '—'} … {reihenfolge[-1] if reihenfolge else '—'}, "
                      f"{schritte} Schritte, nach 3: noch {mitte['offen'] if mitte else '—'} offen"))
        # Schreiben: gleich bleibt gleich, Revision zählt
        v0 = meta(m.con, "version"); n_gleich = schreiben(m.con, [("test:x", tag_ts("2026-10-01"), 1.0)])
        v1 = meta(m.con, "version"); n_wieder = schreiben(m.con, [("test:x", tag_ts("2026-10-01"), 1.0)])
        n_rev = schreiben(m.con, [("test:x", tag_ts("2026-10-01"), 2.0)])
        ok = n_gleich == 1 and n_wieder == 0 and n_rev == 1 and meta(m.con, "version") != v1 and v1 != v0
        pruef.append(("Schreiben: gleicher Wert unverändert, Revision zählt, Datenversion steigt", bool(ok), f"{n_gleich}/{n_wieder}/{n_rev}"))
        m.con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def gesamt_probe(verbose: bool = True) -> tuple:
    """Ganze Rechnung auf synthetischen Daten: Werte gegen Handrechnung, Kausalität aller Rangreihen, Nutzlast je Tab, Archiv."""
    import shutil
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="mk_gesamt_")
    try:
        pfad = os.path.join(tmp, "makro.db")
        testdaten(pfad)
        con = lesen(pfad); D = ableiten(con, heute_tag=tag_ts("2026-09-30") // TAG); con.close()
        i = D["n"] - 10
        rc = D["MC"][i] / D["MVRV"][i]
        ok = (D["ok"] and abs(D["RP"][i] - rc / D["S"][i]) < 1e-9 * D["RP"][i]
              and abs(D["MVRV_Z"][i] - (D["MC"][i] - rc) / np.std(D["MC"][:i + 1][np.isfinite(D["MC"][:i + 1])])) < 1e-9
              and abs(D["DELTA"][i] - (rc - np.nanmean(D["MC"][:i + 1])) / D["S"][i]) < 1e-6 * abs(D["DELTA"][i])
              and abs(D["FUNDING"][i] - 10.95) < 1e-9 and abs(D["SSR"][i] - D["MC"][i] / D["STABLE"][i]) < 1e-9 * D["SSR"][i]
              and abs(D["PUELL"][i] - 450 * D["P"][i] / np.mean(450 * D["P"][i - 364:i + 1])) < 1e-9 * D["PUELL"][i]
              and np.all(np.isnan(D["MVRV"][:MVRV_ANLAUF_TAGE])) and np.isfinite(D["MVRV"][MVRV_ANLAUF_TAGE]))
        pruef.append(("Gesamtrechnung: RP, MVRV-Z, Delta, Puell, Funding, SSR gegen Handrechnung; MVRV-Anlauf verworfen", bool(ok),
                      f"{D['n']} Tage, Power Law b {D['PL']['parameter'][-1]['b']:.3f}".replace(".", ",")))
        # Kausalität: extreme Zukunft anhängen, Vergangenheit bitgleich
        con = verbinden(pfad)
        grenze_tag = tag_ts("2026-06-01") // TAG
        zeilen = [(r, t, w * 50) for r, t, w in con.execute("SELECT reihe, ts, wert FROM mk_reihe WHERE ts >= ?", (grenze_tag * TAG,))]
        schreiben(con, zeilen); con.close()
        con = lesen(pfad); D2 = ableiten(con, heute_tag=tag_ts("2026-09-30") // TAG); con.close()
        g = grenze_tag - D["d0"]
        kausal = ("MVRV_PZ", "MVRV_PZ4", "MVRV_Z", "DELTA", "WMA", "WMA_ABST_PZ", "PUELL", "PUELL_PZ", "FUNDING30_PZ", "DVOL_PZ", "FNG30_PZ",
                  "SSR_PZ", "AVIV_Z", "STH_MVRV_PZ", "OI_MC_PZ", "MINER_E")
        falsch = [k for k in kausal if not _gleich(D[k][:g], D2[k][:g])]
        for k in ("pz", "rest", "sigma"):
            if not _gleich(D["PL"][k][:g - 31], D2["PL"][k][:g - 31]):
                falsch.append("PL." + k)
        pruef.append(("Kausal: Zukunft × 50 ändert keine Rang-, Z- oder Power-Law-Reihe davor", not falsch,
                      "alle 19 Reihen bitgleich" if not falsch else "verändert: " + ", ".join(falsch)))
        # Nutzlast je Tab: gültiges JSON ohne NaN, erwartete Schlüssel
        _CACHE.update(pfad=None, D=None, nutz={})
        groessen = {}; fehlt = []
        for tab in TABS:
            for coin in (("BTC", "ETH", "XMR") if tab in ("bewertung", "trend") else ("BTC",)):
                b = payload_json(pfad, tab, coin, {"btc": 90000.0, "ts": 0})
                d = json.loads(b); groessen[tab] = max(groessen.get(tab, 0), len(b))
                if not d.get("ok"):
                    fehlt.append(f"{tab}/{coin}: {d.get('grund')}")
        d = json.loads(payload_json(pfad, "ueberblick", "BTC", {"btc": 90000.0}))
        z_keys = {z["key"] for z in d.get("zonen", [])}
        ok = not fehlt and {"mvrv", "pl", "wma", "sth", "tmm", "miner", "puell", "fng", "funding", "dvol", "ssr", "halving"} <= z_keys
        pruef.append(("Nutzlast: alle Tabs und Coins gültig (kein NaN), Zonenkarte vollständig", bool(ok),
                      "; ".join(fehlt) if fehlt else f"größter Tab {max(groessen.values()) // 1024} kB, Zonen {len(z_keys)}"))
        # 23.54 (U132): Kursleiste -- jeder Chart-Tab trägt den Kurs; JEDER Punkt gleich der Ableitung am selben Tag (BTC; in
        # Bewertung und Trend mit anderem Coin dessen Kurs), Lücken bleiben Lücken
        def _kurs_abw(r_, arr, d0_):
            if not r_ or not r_.get("v"):
                return "fehlt"
            for i_, v_ in enumerate(r_["v"]):
                j_ = r_["t0"] + i_ - d0_
                w_ = float(arr[j_]) if 0 <= j_ < len(arr) else float("nan")
                if v_ is None:
                    if math.isfinite(w_):
                        return f"Lücke am {ts_tag((r_['t0'] + i_) * TAG)}"
                    continue
                if not (math.isfinite(w_) and abs(v_ - w_) <= 1e-4 * abs(w_)):
                    return f"{ts_tag((r_['t0'] + i_) * TAG)}: {v_} gegen {w_}"
            j_ = r_["t0"] - d0_
            if j_ > 0 and np.any(np.isfinite(np.asarray(arr[:j_], dtype=float))):
                return "beginnt zu spät"
            j1_ = r_["t0"] + len(r_["v"]) - d0_
            if j1_ < len(arr) and np.any(np.isfinite(np.asarray(arr[max(j1_, 0):], dtype=float))):
                return "endet zu früh"
            return None
        kurs_fehl = []; kurs_n = 0
        for tab in ("ueberblick", "bewertung", "trend", "kohorten", "miner", "hebel", "fluss", "makro"):
            dk = json.loads(payload_json(pfad, tab, "BTC", {"btc": 90000.0, "ts": 0}))
            a_ = _kurs_abw((dk.get("r") or {}).get("P"), D2["P"], D2["d0"]); kurs_n += 1
            if a_:
                kurs_fehl.append(f"{tab}: {a_}")
        for tab, feld in (("bewertung", "r"), ("trend", "w")):
            dk = json.loads(payload_json(pfad, tab, "ETH", {"btc": 90000.0, "ts": 0}))
            c_ = (D2.get("COINS") or {}).get("ETH")
            a_ = _kurs_abw((dk.get(feld) or {}).get("P"), c_["P"], c_["d0"]) if c_ else "ETH fehlt in der Ableitung"
            kurs_n += 1
            if a_:
                kurs_fehl.append(f"{tab}/ETH: {a_}")
        pruef.append(("Kursleiste: jeder Chart-Tab trägt den Kurs, jeder Punkt gleich der Ableitung (BTC; Bewertung/Trend mit ETH: Kurs ETH)",
                      not kurs_fehl, "; ".join(kurs_fehl[:3]) if kurs_fehl else f"{kurs_n} Nutzlasten geprüft"))
        # 23.51: kleine Charts im Überblick -- je Zeile der Zonenkarte (ohne Halving) die Reihe; letzter Punkt = Zahl der Tabelle
        # (Tag und Wert); jüngste 730 Tage täglich, davor Abstand 7; eine Lücke unterbricht die Linie (null), statt sie zu überbrücken
        du = json.loads(payload_json(pfad, "ueberblick", "BTC", {"btc": 90000.0}))
        mini = du.get("mini") or {}
        zk = {z["key"]: z for z in du.get("zonen", [])}
        fehl_m = sorted(set(zk) - {"halving"} - set(mini))
        abw_m = []
        for k, m_ in mini.items():
            z_ = zk.get(k)
            if not z_:
                abw_m.append(f"{k} ohne Zeile"); continue
            letzt_i = max(i for i, v in enumerate(m_["v"]) if v is not None)
            if m_["t"][letzt_i] != z_["tag"] or (isinstance(z_["wert"], (int, float)) and abs(m_["v"][letzt_i] - z_["wert"]) > 1e-3 * max(1.0, abs(z_["wert"]))):
                abw_m.append(f"{k}: {m_['t'][letzt_i]}/{m_['v'][letzt_i]} gegen {z_['tag']}/{z_['wert']}")
        x_ = np.arange(2000, dtype=float); x_[1500:1520] = np.nan                     # Lücke im täglichen Teil
        mm = _mini(x_, 1000)
        tt_ = mm["t"]; abst = [b_ - a_ for a_, b_ in zip(tt_, tt_[1:])]
        luecke = [i for i, v in enumerate(mm["v"]) if v is None]
        m4 = _mini(x_, 1000, letzte=100)
        ok_f = (tt_[-1] == 2999 and all(a_ == 7 for a_ in abst[:abst.index(1)]) and tt_.index(1000 + 2000 - 730) > 0
                and len(luecke) == 1 and mm["t"][luecke[0]] == 1000 + 1500 and m4["t"][0] == 1000 + 1900 and len(m4["t"]) == 100)
        mi_ = mini.get("miner") or {"t": [0]}
        ok_f = ok_f and mi_["t"][0] >= mi_["t"][-1] - MINI_MINER_TAGE                 # Miner nur 4 Jahre (fester Gerätetyp)
        # jeder Punkt = Wert der Reihe hinter der Zeile an diesem Tag (nicht nur der letzte) -- gegen die Ableitung nachgerechnet
        with np.errstate(invalid="ignore", divide="ignore"):
            soll_r = {"mvrv": D2["MVRV"], "pl": 10 ** np.asarray(D2["PL"]["rest"]), "wma": D2["WMA_ABST"], "mvrvz": D2["MVRV_Z"], "puell": D2["PUELL"],
                      "sth": D2["P"] / D2["BGM"]["sth-realized-price"] - 1, "tmm": D2["P"] / D2["BGM"]["true-market-mean"] - 1,
                      "ribbons": D2["RIBBONS"]["h30"] / D2["RIBBONS"]["h60"] - 1, "fng": D2["FNG30"], "funding": D2["FUNDING30"], "oi": D2["OI_MC"],
                      "dvol": D2["DVOL"], "ssr": D2["SSR"], "etf": D2["ETF_BTC_30"], "miner": D2["MINER_VERH"]}
        for k, arr in soll_r.items():
            m_ = mini.get(k)
            if not m_:
                continue
            for t_, v_ in zip(m_["t"], m_["v"]):
                w_ = arr[t_ - D2["d0"]] if 0 <= t_ - D2["d0"] < len(arr) else float("nan")
                if v_ is not None and not (math.isfinite(w_) and abs(v_ - w_) <= 1e-3 * max(1e-9, abs(w_))):
                    abw_m.append(f"{k} am {ts_tag(t_ * TAG)}: {v_} gegen {w_}"); break
        ok = not fehl_m and not abw_m and len(mini) >= 14 and ok_f and du.get("mini_zonen") is not None
        pruef.append(("Überblick: kleiner Chart je Zeile der Zonenkarte, letzter Punkt = Zahl der Tabelle; Wochen/Tage, Lücke unterbrochen", bool(ok),
                      ("fehlt: " + ", ".join(fehl_m) + " " if fehl_m else "") + ("; ".join(abw_m[:3]) if abw_m else f"{len(mini)} Reihen")
                      + ("" if ok_f else " · Format falsch")))
        # 23.49 (U126): Signale je Tab -- jedes Paar mit Referenzlinie da, Zeiträume bis zur Historie, Tagesstand einmal je Tag
        soll = {"bewertung": {"rp", "delta"}, "trend": {"pl", "wma"}, "kohorten": {"sth", "tmm", "lth"}, "miner": {"miner", "puell"}}
        fehl_sig = []
        for tab, keys in soll.items():
            ds = json.loads(payload_json(pfad, tab, "BTC", {"btc": 90000.0, "ts": 0}))
            ist = {b_["key"] for b_ in ds.get("signale", [])}
            if ist != keys or any(not b_.get("fenster") for b_ in ds.get("signale", [])):
                fehl_sig.append(f"{tab}: {sorted(ist)}")
            if not isinstance((ds.get("signal_regeln") or {}).get("nachrechnung"), dict) or "archiv" not in ds["signal_regeln"]["nachrechnung"]:
                fehl_sig.append(f"{tab}: Nachrechnung fehlt in der Nutzlast")
        S_ = signale(D2)
        con_ = verbinden(pfad)
        a1 = signale_archivieren(con_, S_, jetzt=tag_ts("2026-10-05")); a2 = signale_archivieren(con_, S_, jetzt=tag_ts("2026-10-05") + 600)
        con_.close()
        mi = (S_ or {}).get("paare", {}).get("miner:BTC", {}).get("fenster", {})
        ok = not fehl_sig and a1 > 20 and a2 == 0 and set(mi) <= {"1j", "2j", "4j"}
        pruef.append(("Signale: alle Paare je Tab, Miner nur bis 4 J, Tagesstand einmal je Tag", bool(ok),
                      "; ".join(fehl_sig) if fehl_sig else f"{len((S_ or {}).get('paare', {}))} Paare, {a1} Zeilen, dann {a2}"))
        # 23.56 (U135): Summenzeile der Signal-Bilanz im Stand -- Summe über alle Paare und Zeiträume, Zufallserwartung, Live-Signale
        # mit belegter EIGENER Seite (ein belegter Kauf zählt bei einem Verkaufssignal nicht)
        import hl_makro_signal as _ms
        G_ = signal_summe(S_)
        bel_ = sum(f_["belegt"] for b_ in S_["paare"].values() for f_ in b_["fenster"].values())
        tst_ = sum(f_["tests"] for b_ in S_["paare"].values() for f_ in b_["fenster"].values())
        liv_ = sum(1 for b_ in S_["paare"].values() for f_ in b_["fenster"].values() if f_["signal"])
        zeilen_s = signal_text(S_)
        bil_ = lambda k_, v_: {"90": {"kauf": {"belegt": k_}, "verkauf": {"belegt": v_}}}
        S_k = {"paare": {"x": {"name": "X", "coin": "BTC", "fenster": {
                   "1j": {"signal": "verkauf", "belegt": 1, "tests": 6, "bilanz": bil_(False, True)},
                   "2j": {"signal": "verkauf", "belegt": 1, "tests": 6, "bilanz": bil_(True, False)}}},
               "y": {"name": "Y", "coin": "ETH", "fenster": {
                   "alles": {"signal": "kauf", "belegt": 0, "tests": 4, "bilanz": {"90": {"kauf": {"belegt": False}}}},
                   "4j": {"signal": None, "belegt": 2, "tests": 6, "bilanz": bil_(True, True)}}}}}
        t_k = signal_summe_text(signal_summe(S_k))
        ok = (G_["belegt"] == bel_ and G_["tests"] == tst_ and G_["live"] == liv_ and tst_ > 0
              and signal_summe_text(G_) in zeilen_s and zeilen_s.index(signal_summe_text(G_)) == len(zeilen_s) - 2
              and abs(G_["zufall_lo"] - tst_ * _ms.FEHLURTEILE[0]) < 1e-9 and abs(G_["zufall_hi"] - tst_ * _ms.FEHLURTEILE[1]) < 1e-9
              and "belegt 4 von 22 Tests" in t_k and "etwa 0,7–1,1;" in t_k and "Live jetzt 3 Signale (1 Kauf, 2 Verkauf)" in t_k
              and t_k.endswith("davon mit belegter Bilanz ihrer Seite: 1 (X (BTC) 1j)"))
        pruef.append(("Stand: Summenzeile der Signal-Bilanz (alle Paare und Zeiträume, Zufallserwartung, Live mit belegter eigener Seite)", bool(ok),
                      f"Testdaten belegt {G_['belegt']} von {G_['tests']}, live {G_['live']}; Konstrukt: {t_k.strip()[:60]}…"))
        # Kausalität der GANZEN Kette (Ableitung und Signal): Zukunft × 50 ändert kein Perzentil davor -- in keinem Paar und Zeitraum
        import hl_makro_signal
        S_1 = hl_makro_signal.alle_signale(D)
        anders = []; vergl = 0
        for paar, e1 in S_1["_pz"].items():
            e2 = (S_ or {}).get("_pz", {}).get(paar)
            if not e2 or e2["d0"] != e1["d0"] or set(e2["fenster"]) != set(e1["fenster"]):
                anders.append(f"{paar} (Zeiträume)")
                continue
            for fen, a_ in e1["fenster"].items():
                vergl += 1
                if not _gleich(a_[:grenze_tag - e1["d0"]], e2["fenster"][fen][:grenze_tag - e1["d0"]]):
                    anders.append(f"{paar}/{fen}")
        pruef.append(("Signale kausal über die ganze Kette: Zukunft × 50 ändert kein Perzentil davor (alle Paare, alle Zeiträume)",
                      not anders and vergl >= 40, ("verändert: " + ", ".join(anders[:6])) if anders else f"{vergl} Perzentil-Reihen bitgleich"))
        # Live gegen Nachrechnung über die ganze Kette: Stand vom 01.05. (Datei nur bis dahin) archivieren, heute nachrechnen -> gleich;
        # Revision einer Quelle (BTC-MVRV der 120 Tage davor × 1,3) -> abweichend, und nur in den Paaren, die BTC-MVRV nutzen
        x_tag = tag_ts("2026-05-01") // TAG

        def kopie(name: str, sql: str, par: tuple) -> str:
            ziel = os.path.join(tmp, name)
            q_, z_ = sqlite3.connect(pfad), sqlite3.connect(ziel)
            q_.backup(z_); q_.close()
            z_.execute(sql, par); z_.commit(); z_.close()
            return ziel

        con = lesen(kopie("bis.db", "DELETE FROM mk_reihe WHERE ts > ?", (x_tag * TAG,)))
        D_x = ableiten(con, heute_tag=x_tag); con.close()
        S_x = hl_makro_signal.alle_signale(D_x)
        archiv_ts = x_tag * TAG + 20 * 3600
        con_ = verbinden(pfad); a_x = signale_archivieren(con_, S_x, jetzt=archiv_ts); con_.close()
        N_ = signal_nachrechnung(pfad, S_)
        con = lesen(kopie("rev.db", "UPDATE mk_reihe SET wert = wert * 1.3 WHERE reihe = 'cm:btc:CapMVRVCur' AND ts >= ? AND ts < ?",
                          ((x_tag - 120) * TAG, x_tag * TAG)))
        D_r = ableiten(con, heute_tag=tag_ts("2026-09-30") // TAG); con.close()
        con = lesen(pfad)
        zeilen_x = con.execute("SELECT tag, paar, fenster, signal, pz FROM mk_signal WHERE berechnet = ?", (archiv_ts,)).fetchall()
        con.close()
        N_r = hl_makro_signal.nachrechnung(hl_makro_signal.alle_signale(D_r), zeilen_x)
        txt_n = nachrechnung_text(N_)
        ok = (a_x > 20 and N_ and N_["n"] >= 20 and N_["gleich"] == N_["n"] and N_["signal_gleich"] == N_["n"] and N_["heute"] == a1
              and N_["archiv"] == a1 + a_x and "ABWEICHUNG" not in txt_n and N_r and N_r["gleich"] < N_r["n"]
              and "rp:BTC" in N_r["paare_abweichend"] and set(N_r["paare_abweichend"]) <= {"rp:BTC", "delta:BTC"}
              and "ABWEICHUNG" in nachrechnung_text(dict(N_r, archiv=a_x, seit="2026-05-01")))
        pruef.append(("Live gegen Nachrechnung: Stand vom 01.05. = Nachrechnung heute; Revision der Quelle erkannt, nur in den MVRV-Paaren", bool(ok),
                      (f"{N_['gleich']} von {N_['n']} gleich; nach Revision {N_r['gleich']} von {N_r['n']}, abweichend nur "
                       + ", ".join(N_r["paare_abweichend"])) if N_ and N_r else "—"))
        # 23.50: OI-Archiv lädt noch (Testdaten erst ab 12/2022, Archiv nicht fertig) -> Hinweis in der Nutzlast „Hebel“, kein
        # Perzentil in der Zonenkarte; Archiv fertig -> Perzentil wieder da
        _CACHE.update(pfad=None, D=None, nutz={})
        dh = json.loads(payload_json(pfad, "hebel", "BTC", None)).get("oi_archiv") or {}
        oz = [z for z in json.loads(payload_json(pfad, "ueberblick", "BTC", {"btc": 90000.0})).get("zonen", []) if z["key"] == "oi"]
        con_ = verbinden(pfad); _meta_setzen(con_, {"oi_archiv_fertig": 1}); con_.close()
        con = lesen(pfad); D3 = ableiten(con, heute_tag=tag_ts("2026-09-30") // TAG); con.close()
        oz2 = [z for z in zonenkarte(D3) if z["key"] == "oi"]
        con_ = verbinden(pfad); con_.execute("DELETE FROM mk_meta WHERE k='oi_archiv_fertig'"); con_.commit(); con_.close()
        _CACHE.update(pfad=None, D=None, nutz={})
        ok = (dh.get("lueckenhaft") and 0 < dh.get("tage", 0) < dh.get("soll", 0) and oz and oz[0]["pz"] is None and "lädt" in oz[0]["bezug"]
              and oz2 and oz2[0]["pz"] is not None and not D3["OI_ABDECKUNG"]["lueckenhaft"] and D3["OI_ABDECKUNG"]["fertig"])
        pruef.append(("OI-Archiv lädt: Hinweis in der Nutzlast, kein Perzentil aus lückenhafter Historie; fertig -> Perzentil da", bool(ok),
                      f"{dh.get('tage')} von {dh.get('soll')} Tagen, Zonenkarte {oz[0]['pz'] if oz else '—'} -> "
                      f"{round(oz2[0]['pz']) if oz2 and oz2[0]['pz'] is not None else '—'}"))
        d = json.loads(payload_json(os.path.join(tmp, "fehlt", "makro.db"), "ueberblick", "BTC"))
        ok = not d["ok"] and "fehlt" in d.get("grund", "") and not os.path.exists(os.path.join(tmp, "fehlt"))
        pruef.append(("Fehlende makro.db: Hinweis statt Fehler, nichts wird angelegt", bool(ok), d.get("grund", "")[:60]))
        con = verbinden(pfad)
        n1 = archivieren(con, D2, jetzt=tag_ts("2026-10-05")); n2 = archivieren(con, D2, jetzt=tag_ts("2026-10-05") + 3600)
        n3 = archivieren(con, D2, jetzt=tag_ts("2026-10-06"))
        con.close()
        ok = n1 > 10 and n2 == 0 and n3 > 0
        pruef.append(("Archiv: Tagesstand einmal je Tag (revisionsfrei), Power-Law-Parameter je Monat", bool(ok), f"{n1}, dann {n2}, Folgetag {n3}"))
        ok = makro_pfad("/a/b/hl_liq.db") == "/a/b/makro.db" and not starten(os.path.join(tmp, "_selftest.db"))
        pruef.append(("makro.db neben der Hauptdatenbank; kein Takt für Selbsttest-Datenbanken", bool(ok), "/a/b/makro.db"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def frische_probe(verbose: bool = True) -> tuple:
    """
    Abnahme U121 „Frische-Alarm“: eine stehengebliebene Reihe wird gemeldet, eine monatliche FRED-Reihe mit normalem Verzug nicht,
    eine Wochenend-Lücke bei Farside nicht; eine Reihe, die ein erfolgreich abgerufenes Ziel liefern müsste, fehlt -> gemeldet;
    ein Ziel ohne erfolgreichen Abruf -> kein Befund (noch nicht abgerufen). Feste Uhr.
    """
    import shutil
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="mk_frisch_")
    try:
        pfad = os.path.join(tmp, "makro.db")
        jetzt = tag_ts("2026-10-05") + 15 * 3600
        heute = jetzt // TAG
        con = verbinden(pfad)
        alter = {"cm:btc:PriceUSD": 1, "cm:btc:CapMVRVCur": 9, "fred:M2SL": 80, "fred:DFF": 12, "fred:DEXUSEU": 11,
                 "fs:etf_btc": 4, "bgm:asopr:asopr": 2, "xyz:unbekannt": 400,
                 "bgm:sth-mvrv:sthMvrv": 8, "bgm:lth-sopr:lthSopr": 10}         # 23.48: BGeometrics frei mit 7 Tagen Verzug -> Grenze 9
        schreiben(con, [(r, (heute - a - k) * TAG, 1.0 + k) for r, a in alter.items() for k in range(3)], jetzt=jetzt)
        _meta_setzen(con, {"ok:cm:btc": jetzt - 3600, "ok:fred:M2SL": jetzt - 3600, "ok:bgm:asopr": jetzt - 3600, "ok:bgm:aviv": jetzt - 3600})
        con.close()
        T = daten_tab(pfad, None, jetzt=jetzt)
        a = {r["reihe"]: r for r in T["reihen"]}
        soll_alt = ["bgm:lth-sopr:lthSopr", "cm:btc:CapMVRVCur", "fred:DFF"]
        ok = (T["zu_alt"] == soll_alt and a["cm:btc:CapMVRVCur"]["alter"] == 9 and a["cm:btc:CapMVRVCur"]["grenze"] == 5
              and not a["fred:M2SL"]["alt"] and not a["fred:DEXUSEU"]["alt"] and not a["fs:etf_btc"]["alt"] and not a["bgm:sth-mvrv:sthMvrv"]["alt"]
              and a["xyz:unbekannt"]["grenze"] is None and not a["xyz:unbekannt"]["alt"])
        pruef.append(("Frische: stehengebliebene Reihe gemeldet, Monatswert/Wochenende/BGeometrics-Verzug nicht", bool(ok),
                      "zu alt: " + ", ".join(T["zu_alt"]) + f" · M2 {a['fred:M2SL']['alter']} T (Grenze {a['fred:M2SL']['grenze']})"))
        soll_fehlt = [f"cm:btc:{m}" for m in CM_METRIKEN["btc"] if m not in ("PriceUSD", "CapMVRVCur")] + ["bgm:aviv:*"]
        txt = stand_text(pfad, jetzt=jetzt)
        ok = (T["fehlen"] == soll_fehlt and "fng:wert" not in T["fehlen"] and "fred:DFF" not in T["fehlen"]
              and "ZU ALT 3 von 10" in txt and "FEHLT nach erfolgreichem Abruf (8)" in txt and "FRED: OHNE Schlüssel" in txt)
        pruef.append(("Fehlt nach erfolgreichem Abruf gemeldet, nie abgerufen nicht; Stand zeigt beides", bool(ok),
                      f"fehlen {len(T['fehlen'])}: {', '.join(T['fehlen'][:3])} …"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def fred_probe(verbose: bool = True) -> tuple:
    """
    23.48: FRED über die API mit Schlüssel (Adresse, Zeilen, Weg), Schlüssel nie im Fehlertext, Abbruch je Quelle bei
    Zeitüberschreitung (eine Zeitüberschreitung statt zwölf, andere Quellen laufen weiter), HTTP-Fehler sperren nichts,
    Schlüssel aus Umgebung vor Datei, Einrichten über --fred-schluessel (Format, Ablehnung, übrige Einträge, Pausen zurück).
    """
    import shutil
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="mk_fred_")
    env_alt = os.environ.pop("FRED_API_KEY", None)
    k = "0123456789abcdef0123456789abcdef"
    try:
        uhr = [float(tag_ts("2026-10-05") + 6 * 3600)]
        # a) mit Schlüssel: alle 12 Reihen über die API
        netz = _FalschesNetz()
        m = Makro(os.path.join(tmp, "a.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        e = m.runde(nur="fred", archiv=False)
        api = [u for u in netz.aufrufe if "api.stlouisfed.org" in u]
        n_ = m.con.execute("SELECT COUNT(*) FROM mk_reihe WHERE reihe LIKE 'fred:%'").fetchone()[0]
        ok = (len(api) == len(FRED) and not any("fredgraph" in u for u in netz.aufrufe) and all("observation_start=2008-01-01" in u for u in api)
              and n_ == 2 * len(FRED) and meta(m.con, "fred_weg") == "api" and all(v > 0 for v in e["ziele"].values()))
        pruef.append(("FRED mit Schlüssel: alle Reihen über die API, ganze Historie, '.' fällt weg", bool(ok), f"{len(api)} API-Abrufe, {n_} Werte"))
        # b) Schlüssel nie im Fehlertext
        netz.fehler = {"series_id=DFF": f'HTTP 400: {{"error_message":"Bad Request. api_key={k} is not registered"}}'}
        uhr[0] += 13 * 3600
        m.runde(nur="fred", archiv=False)
        f_ = meta(m.con, "fehler:fred:DFF") or ""
        prot = " ".join(r[0] or "" for r in m.con.execute("SELECT fehler FROM mk_abruf"))
        ok = k not in f_ and k not in prot and "Schlüssel prüfen" in f_ and "***" in f_ and (meta(m.con, "ok:fred:WALCL") or "0") != "0"
        pruef.append(("FRED: Schlüssel nie in Fehler oder Protokoll; abgelehnt -> „Schlüssel prüfen“", bool(ok), f_.split("UTC: ", 1)[-1][:72]))
        m.con.close()
        # c) ohne Schlüssel, fredgraph hängt: eine Zeitüberschreitung, die übrigen FRED-Ziele pausieren mit, andere Quellen laufen
        netz = _FalschesNetz(); netz.fehler = {"fredgraph": "TimeoutError: The read operation timed out"}
        m = Makro(os.path.join(tmp, "c.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel="")
        e = m.runde(archiv=False)
        fg = [u for u in netz.aufrufe if "fredgraph" in u]
        pausen = [float(meta(m.con, f"pause:fred:{s}") or 0) for s in FRED]
        ok = (len(fg) == 1 and all(e["ziele"].get(f"fred:{s}") == -1 for s in FRED) and min(pausen) >= uhr[0] + 900 - 1
              and any("alternative.me" in u for u in netz.aufrufe) and any("bitcoin-data.com" in u for u in netz.aufrufe)
              and "übersprungen" in (meta(m.con, "fehler:fred:DEXJPUS") or "") and "(ohne Schlüssel)" in (meta(m.con, "fehler:fred:WALCL") or ""))
        pruef.append(("Host antwortet nicht: eine Zeitüberschreitung je Quelle und Runde, Rest pausiert, andere Quellen laufen", bool(ok),
                      f"fredgraph {len(fg)}× statt {len(FRED)}×, Pause ≥ 15 min"))
        m.con.close()
        # d) HTTP-Fehler einer Reihe sperrt die anderen nicht
        netz = _FalschesNetz(); netz.fehler = {"id=WALCL": "HTTP 503: kaputt"}
        m = Makro(os.path.join(tmp, "d.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel="")
        e = m.runde(nur="fred", archiv=False)
        ok = (len([u for u in netz.aufrufe if "fredgraph" in u]) == len(FRED) and e["ziele"]["fred:WALCL"] == -1
              and sum(1 for v in e["ziele"].values() if v > 0) == len(FRED) - 1 and meta(m.con, "fred_weg") == "csv"
              and not _netzfehler("HTTP 504: upstream connect error or disconnect/reset before headers. reset reason: connection timeout")
              and _netzfehler("URLError: <urlopen error timed out>")
              and _netzfehler("RemoteDisconnected: Remote end closed connection without response"))
        pruef.append(("HTTP-Fehler einer Reihe sperrt die Quelle nicht (auch ein 504 mit „timeout“ im Text ist eine Antwort)", bool(ok), "11 von 12 abgerufen"))
        m.con.close()
        # e) Schlüssel lesen: Umgebung vor Datei, kaputte Datei -> keiner
        datei = os.path.join(tmp, "accesstokens.json")
        with open(datei, "w", encoding="utf-8") as f:
            json.dump({"_hinweis": "x", "coinglass": {"api_key": "cg"}, "fred": {"api_key": " " + k + " "}}, f)
        aus_datei = fred_schluessel_lesen(datei)
        os.environ["FRED_API_KEY"] = "f" * 32
        aus_env = fred_schluessel_lesen(datei)
        del os.environ["FRED_API_KEY"]
        with open(os.path.join(tmp, "kaputt.json"), "w") as f:
            f.write("{kein json")
        ok = aus_datei == k and aus_env == "f" * 32 and fred_schluessel_lesen(os.path.join(tmp, "kaputt.json")) == "" and fred_schluessel_lesen(os.path.join(tmp, "fehlt.json")) == ""
        pruef.append(("Schlüssel: Umgebungsvariable vor accesstokens.json, Leerzeichen weg, kaputte Datei -> keiner", bool(ok), "FRED_API_KEY > Datei"))
        # f) Einrichten: Format, Ablehnung, übrige Einträge bleiben, Pausen zurück; der Schlüssel steht nie in der Meldung
        mdb = os.path.join(tmp, "f.db"); con = verbinden(mdb)
        _meta_setzen(con, {"pause:fred:WALCL": 9e9, "fehlversuche:fred:WALCL": 5, "pause:cm:btc": 9e9}); con.close()
        n1, t1 = fred_schluessel_einrichten("ZU-KURZ", mdb, datei, http_fn=_FalschesNetz())
        abgelehnt = _FalschesNetz(); abgelehnt.fehler = {"api.stlouisfed.org": f"HTTP 400: Bad Request api_key={'e' * 32}"}
        n2, t2 = fred_schluessel_einrichten("e" * 32, mdb, datei, http_fn=abgelehnt)
        unveraendert = fred_schluessel_lesen(datei) == k
        n3, t3 = fred_schluessel_einrichten("b" * 32, mdb, datei, http_fn=_FalschesNetz())
        with open(datei, encoding="utf-8") as f:
            roh = json.load(f)
        con = verbinden(mdb)
        p_w, p_cm = float(meta(con, "pause:fred:WALCL")), float(meta(con, "pause:cm:btc")); con.close()
        haengt = _FalschesNetz(); haengt.fehler = {"api.stlouisfed.org": "TimeoutError: The read operation timed out"}
        n4, t4 = fred_schluessel_einrichten("c" * 32, None, datei, http_fn=haengt)
        with open(os.path.join(tmp, "kaputt.json"), encoding="utf-8") as f:
            vorher = f.read()
        n5, t5 = fred_schluessel_einrichten("d" * 32, None, os.path.join(tmp, "kaputt.json"), http_fn=_FalschesNetz())
        with open(os.path.join(tmp, "kaputt.json"), encoding="utf-8") as f:
            nachher = f.read()
        alle_t = " ".join((t1, t2, t3, t4, t5))
        ok = (not n1 and not n2 and unveraendert and n3 and roh["fred"]["api_key"] == "b" * 32 and roh["coinglass"]["api_key"] == "cg"
              and roh["_hinweis"] == "x" and p_w == 0 and p_cm == 9e9 and n4 and "trotzdem gespeichert" in t4 and fred_schluessel_lesen(datei) == "c" * 32
              and not n5 and vorher == nachher and not any(x * 32 in alle_t for x in "ebcd") and not os.path.exists(datei + ".tmp")
              and "lehnt den Schlüssel" in t2 and "zurückgesetzt" in t3)
        pruef.append(("--fred-schluessel: falsches Format und Ablehnung schreiben nichts; übrige Einträge bleiben; Pausen zurück", bool(ok),
                      "Netzfehler im Probeabruf: mit Warnung gespeichert; kaputte Datei bleibt unberührt"))
    finally:
        if env_alt is not None:
            os.environ["FRED_API_KEY"] = env_alt
        else:
            os.environ.pop("FRED_API_KEY", None)
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def usa_probe(verbose: bool = True) -> tuple:
    """23.67 (U153): Fassungen, Erstveröffentlichungen, Termine (Abruf ohne Netz), Rechnung mit Lücke, Nutzlast, Frische."""
    import shutil
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="mk_usa_")
    k = "0123456789abcdef0123456789abcdef"
    try:
        con = verbinden(os.path.join(tmp, "f.db"))
        t1 = tag_ts("2026-08-01")
        a = fassungen_schreiben(con, [("fred:PAYEMS", t1, 159000.0)], 1000)
        b = fassungen_schreiben(con, [("fred:PAYEMS", t1, 159000.0)], 2000)
        c = fassungen_schreiben(con, [("fred:PAYEMS", t1, 159022.0), ("fred:PAYEMS", t1 + 31 * TAG, 159044.0)], 3000)
        d = fassungen_schreiben(con, [("fred:PAYEMS", t1, 159022.0)], 4000)
        zeilen = con.execute("SELECT ts, abgerufen, wert, art FROM mk_fassung ORDER BY ts, abgerufen").fetchall()
        e = erst_schreiben(con, [("fred:PAYEMS", t1, 900, 158990.0)]); e2 = erst_schreiben(con, [("fred:PAYEMS", t1, 900, 158990.0)])
        f = fassungen_schreiben(con, [("fred:PAYEMS", t1, 159022.0)], 5000)            # die jüngste Fassung bleibt maßgeblich
        con.close()
        ok = (a, b, c, d, e, e2, f) == (1, 0, 2, 0, 1, 0, 0) and zeilen == [(t1, 1000, 159000.0, "abruf"), (t1, 3000, 159022.0, "abruf"),
                                                                          (t1 + 31 * TAG, 3000, 159044.0, "abruf")]
        pruef.append(("Fassungen: gleicher Wert keine Zeile, Korrektur eine neue (alte bleibt); Erstveröffentlichung einmal, früher datiert",
                      bool(ok), f"{(a, b, c, d, e, e2, f)} {zeilen}"))
        z1, z2, z3 = ny830_utc(tag_ts("2026-10-14")), ny830_utc(tag_ts("2026-11-06")), ny830_utc(tag_ts("2026-10-28"))
        ok = (z1 == tag_ts("2026-10-14") + 12 * 3600 + 1800 and z2 == tag_ts("2026-11-06") + 13 * 3600 + 1800
              and z3 == tag_ts("2026-10-28") + 12 * 3600 + 1800)
        pruef.append(("Termin 8:30 New York in UTC mit Sommerzeit: 14.10. 12:30, 28.10. 12:30 (in Berlin schon Winterzeit: 13:30), 06.11. 13:30",
                      bool(ok), f"{ts_tag(z1)} {time.strftime('%H:%M', time.gmtime(z1))} · {time.strftime('%H:%M', time.gmtime(z3))} · {time.strftime('%H:%M', time.gmtime(z2))}"))
        al = alfred_erst_parse("UNRATE", {"observations": [{"realtime_start": "2026-10-02", "realtime_end": "9999-12-31", "date": "2026-09-01", "value": "4.2"},
                                                            {"realtime_start": "2025-12-16", "date": "2025-10-01", "value": "."}]})
        sr = series_release_parse({"releases": [{"id": 50, "name": "Employment Situation"}]})
        rd = release_dates_parse({"release_dates": [{"release_id": 50, "date": "2026-11-06"}, {"release_id": 50, "date": "2026-10-02"},
                                                    {"date": "kaputt"}]})
        kaputt = 0
        for fn, arg in ((alfred_erst_parse, ("X", {"x": 1})), (series_release_parse, ({"releases": []},)), (release_dates_parse, ([],))):
            try:
                fn(*arg)
            except ValueError:
                kaputt += 1
        ok = (al == [("fred:UNRATE", tag_ts("2026-09-01"), ny830_utc(tag_ts("2026-10-02")), 4.2)] and sr == (50, "Employment Situation")
              and rd == [tag_ts("2026-10-02"), tag_ts("2026-11-06")] and kaputt == 3)
        pruef.append(("Parser ALFRED (Erstveröffentlichung, „.“ fällt weg), series/release, release/dates; falsches Format gemeldet", bool(ok), f"{al} {sr}"))
        con = verbinden(os.path.join(tmp, "t.db"))
        jetzt = tag_ts("2026-10-13") + 3600
        n1 = termine_schreiben(con, 10, [tag_ts("2026-09-11"), tag_ts("2026-10-14"), tag_ts("2026-11-13")], jetzt)
        n2 = termine_schreiben(con, 10, [tag_ts("2026-10-15"), tag_ts("2026-11-13")], jetzt)        # 14.10. verschoben, 11.09. fehlt in der Antwort
        tt = [ts_tag(t) for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=10 ORDER BY tag")]
        con.close()
        ok = n1 == 3 and n2 == 1 and tt == ["2026-09-11", "2026-10-15", "2026-11-13"]
        pruef.append(("Termine: vergangene bleiben, ein verschobener künftiger fällt weg, der neue kommt dazu", bool(ok), f"{n1}/{n2} {tt}"))
        # Abruf ohne Netz mit Schlüssel: Reihen, Fassungen, Erstveröffentlichungen, Termine; ohne Schlüssel ALFRED/Termine nicht versucht
        uhr = [float(tag_ts("2026-10-13") + 6 * 3600)]
        netz = _FalschesNetz()
        m = Makro(os.path.join(tmp, "a.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        e1 = m.runde(archiv=False)
        fa = dict(m.con.execute("SELECT art, COUNT(*) FROM mk_fassung GROUP BY art").fetchall())
        n_t = m.con.execute("SELECT COUNT(*) FROM mk_termin").fetchone()[0]
        rel = {s_: json.loads(meta(m.con, f"release:{s_}") or "{}").get("id") for s_ in USA_TERMIN_REIHEN}
        ok1 = (all(e1["ziele"].get(f"fred:{s_}", 0) > 0 for s_ in FRED_USA) and fa.get("abruf") == 2 * len(FRED_USA)
               and fa.get("erst") == len(FRED_USA) and n_t == 4 * 4 + 4 and rel == {"UNRATE": 50, "ICSA": 180, "CPIAUCSL": 10, "PPIFIS": 46}
               and not any(k in (meta(m.con, f"fehler:{q_}:{z_}") or "") for q_, z_, _ in Makro.ZIELE))
        uhr[0] += 13 * 3600; netz.usa_wert = {"PAYEMS": 2.5}
        m.runde(nur="fred", archiv=False)
        fa2 = m.con.execute("SELECT COUNT(*) FROM mk_fassung WHERE reihe='fred:PAYEMS' AND art='abruf'").fetchone()[0]
        n_aufr = len(netz.aufrufe); m.runde(nur="fred1", archiv=False); m.runde(nur="fredtermin", archiv=False)
        ok2 = fa2 == 3 and len(netz.aufrufe) == n_aufr                       # ALFRED monatlich, Termine täglich: nicht schon wieder
        m.con.close()
        netz2 = _FalschesNetz()
        m2 = Makro(os.path.join(tmp, "b.db"), http_fn=netz2, uhr=lambda: uhr[0], pause_s=0, fred_schluessel="")
        e2 = m2.runde(archiv=False)
        ok3 = (not any("output_type=4" in u or "fred/series/release" in u or "fred/release/dates" in u for u in netz2.aufrufe) and not any(z_.startswith(("fred1:", "fredtermin:")) for z_ in e2["ziele"]))
        m2.con.close()
        pruef.append(("Abruf ohne Netz: Reihen mit Fassungen, Erstveröffentlichungen (ALFRED) und Termine (Nummer aus series/release, künftige "
                      "nur mit dem Schalter der API); "
                      "Korrektur = neue Fassung; ohne Schlüssel kein ALFRED- und kein Terminabruf", bool(ok1 and ok2 and ok3),
                      f"Fassungen {fa}, Termine {n_t}, Releases {rel}, PAYEMS {fa2}"))
        # Rechnung und Nutzlast auf den Testdaten (Lücke Oktober 2025)
        pfad = os.path.join(tmp, "makro.db")
        testdaten(pfad)
        con = verbinden(pfad)
        for s_, rid in (("UNRATE", 50), ("ICSA", 180), ("CPIAUCSL", 10), ("PPIFIS", 46)):
            _meta_setzen(con, {f"release:{s_}": json.dumps({"id": rid, "name": f"R{rid}"})})
        termine_schreiben(con, 10, [tag_ts("2026-10-14"), tag_ts("2026-11-13")], jetzt)
        termine_schreiben(con, 50, [tag_ts("2026-11-06")], jetzt)
        con.close()
        _CACHE.update(pfad=None, D=None)
        D, _f = _daten(pfad)
        U = (D or {}).get("USA") or {}
        okr = set(U) == {"alq", "stellen", "antraege", "preise_jahr", "preise_monat"}
        if okr:
            g = U["preise_jahr"]["tage"]; tg = {ts_tag(int(t) * TAG)[:7]: i for i, t in enumerate(g)}
            v_cpi = U["preise_jahr"]["linien"][0]["v"]; v_mm = U["preise_monat"]["linien"][0]["v"]
            R_ = Reihen(lesen(pfad))
            tc, wc = R_("fred:CPIAUCNS")
            wm = {ts_tag(int(t) * TAG)[:7]: w for t, w in zip(tc, wc)}
            hand = (wm["2026-09"] / wm["2025-09"] - 1) * 100
            ts_sa, ws_sa = R_("fred:CPIAUCSL"); wsa = {ts_tag(int(t) * TAG)[:7]: w for t, w in zip(ts_sa, ws_sa)}
            hand_mm = (wsa["2026-09"] / wsa["2026-08"] - 1) * 100                   # Monatsrate aus der bereinigten Reihe
            okr = (abs(v_cpi[tg["2026-09"]] - hand) < 1e-9 and abs(v_mm[tg["2026-09"]] - hand_mm) < 1e-9 and not np.isfinite(v_cpi[tg["2025-10"]]) and not np.isfinite(v_cpi[tg["2026-10"]] if "2026-10" in tg else np.nan)
                   and not np.isfinite(v_mm[tg["2025-10"]]) and not np.isfinite(v_mm[tg["2025-11"]]) and np.isfinite(v_mm[tg["2025-12"]])
                   and U["alq"]["luecken"] == ["2025-10"] and "2025-10" in U["preise_jahr"]["luecken"])
            st = U["stellen"]; vs = st["linien"][0]["v"]; v3 = st["linien"][1]["v"]
            i9 = int(np.nonzero(np.isfinite(vs))[0][-1])
            okr = okr and abs(v3[i9] - (vs[i9] + vs[i9 - 1] + vs[i9 - 2]) / 3) < 1e-9
            an = U["antraege"]; ta, wa = R_("fred:ICSA")
            okr = okr and abs(an["linien"][0]["v"][-1] - float(np.mean(wa[-4:])) / 1000) < 1e-9 and len(an["korr"]) == len(an["korr_tage"])
        # 23.100: feste Uhr für diese zwei Aufrufe. Die Termine der Probe enden am 13.11.2026; mit der echten Uhr gab es danach keinen
        # „nächsten Termin“ mehr und die Probe fiel durch (bemerkt am 14.11.2026 im vollen Selbsttest). Die Uhr der Probe ist die, mit
        # der ihre Datenbank gefüllt wurde.
        _echte_uhr = time.time
        time.time = lambda: float(uhr[0])
        try:
            NL = nutzlast(pfad, "makro")
            js = payload_json(pfad, "makro", "BTC")
        finally:
            time.time = _echte_uhr
        try:
            jd = json.loads(js)
        except ValueError:
            jd = {}
        u_ = (jd.get("usa") or {})
        okn = (jd.get("ok") and set(u_.get("reihen") or {}) == set(U) and u_.get("naechste", {}).get("Verbraucherpreise") is not None
               and all(len(e_["t"]) == len(e_["linien"][0]["v"]) for e_ in u_["reihen"].values()))
        pruef.append(("Rechnung: Vorjahresrate (nicht bereinigt) und Monatsrate (bereinigt) von Hand, über die Lücke Oktober 2025 keine Rate (auch nicht im Folgemonat bzw. -jahr), "
                      "3-Monats- und 4-Wochen-Mittel von Hand; Nutzlast /makro mit fünf Charts und den nächsten Terminen (JSON ohne NaN)",
                      bool(okr and okn), f"Charts {sorted(U)}, Termine {u_.get('naechste')}"))
        ok = (frische_grenze("fred:UNRATE") == 100 and frische_grenze("fred:ICSA") == 16 and frische_grenze("fred:PPIFID") == 100
              and erwartete_reihen("fred", "ICSA") == ("fred:ICSA",))
        T = usa_text(pfad, D)
        ok = ok and any("Lücken 2025-10" in z_ for z_ in T) and any("Termine in mk_termin: 3" in z_ for z_ in T)
        pruef.append(("Frische: Monatsreihen 100 Tage, Erstanträge 16; Stand-Text nennt Lücken und Termine", bool(ok), " / ".join(T[1:3])[:150]))
        # 23.68 (U169): Korrelation mit Band und Urteil gegen `_regime`; „FRED-Release 10“; deutsche Wochentage
        kz = [z_ for z_ in T if "Korrelation mit BTC" in z_]
        ok_k = bool(kz)
        for k_, e_ in U.items():
            if e_.get("korr_jetzt") is None:
                continue
            reg = _regime(np.asarray(e_["korr"], dtype=float), np.zeros(len(e_["korr"]), dtype=bool), 24 if e_["monatlich"] else 52)
            band_txt = f"{reg['band']:.2f}".replace(".", ",")
            erwart = "kein belegter Zusammenhang" if abs(reg["korr_jetzt"]) < reg["band"] else "außerhalb des Zufallsbands"
            z_ = next((x for x in T if x.strip().startswith(e_["titel"] + ":")), "")
            ok_k = ok_k and (f"Zufallsband ±{band_txt}, {erwart})" in z_ and abs(reg["band"] - e_["band"]) < 1e-12
                             and ("kein belegter" in reg["regime"]) == (erwart == "kein belegter Zusammenhang"))
        t_do = tag_ts("2026-10-15") + 12 * 3600 + 1800
        kunst = korr_zeile({"korr_jetzt": 0.18, "band": 2 / math.sqrt(24), "monatlich": True})
        kunst2 = korr_zeile({"korr_jetzt": -0.55, "band": 2 / math.sqrt(52), "monatlich": False})
        ok_k = (ok_k and kunst == " · Korrelation mit BTC 0,18 (24 Monate, Zufallsband ±0,41, kein belegter Zusammenhang)"
                and kunst2 == " · Korrelation mit BTC -0,55 (52 Wochen, Zufallsband ±0,28, außerhalb des Zufallsbands)"
                and any("Verbraucherpreise: FRED-Release 10 „R10“" in z_ for z_ in T) and not any(" = 10 " in z_ for z_ in T)
                and tag_kurz(t_do).split()[0] == WOCHENTAGE[time.localtime(t_do).tm_wday]
                and tag_kurz(tag_ts("2026-10-15") + 12 * 3600)[:2] in ("Do", "Mi", "Fr")
                and not any(re.search(r"\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b", z_) for z_ in T))
        pruef.append(("Stand-Text USA (U169): Korrelation mit Zufallsband und Urteil wie `_regime` (0,18 bei ±0,41 kein belegter Zusammenhang, "
                      "−0,55 bei ±0,28 außerhalb), „FRED-Release 10“, deutsche Wochentage", bool(ok_k), (kz[0] if kz else "keine Zeile")[-160:]))
        # nächster Termin je Veröffentlichung: nur künftige (8:30 New York schon vorbei zählt nicht), „nächste 14 Tage“ bis jetzt + 14 T
        con = verbinden(os.path.join(tmp, "n.db"))
        for s_, rid in (("UNRATE", 50), ("CPIAUCSL", 10)):
            _meta_setzen(con, {f"release:{s_}": json.dumps({"id": rid, "name": f"R{rid}"})})
        j0 = tag_ts("2026-10-13") + 15 * 3600                                           # 13.10. 15:00 UTC: der 13.10. 8:30 NY ist vorbei
        termine_schreiben(con, 10, [tag_ts("2026-10-13"), tag_ts("2026-10-14"), tag_ts("2026-11-13")], j0)
        termine_schreiben(con, 50, [tag_ts("2026-10-02"), tag_ts("2026-10-26"), tag_ts("2026-10-28")], j0)
        TT_ = usa_termine(con, j0); con.close()
        ok = (TT_["naechste"] == {"Verbraucherpreise": ny830_utc(tag_ts("2026-10-14")), "Arbeitsmarktbericht": ny830_utc(tag_ts("2026-10-26"))}
              and [(e_["name"], ts_tag(e_["ts"])) for e_ in TT_["vierzehn"]] == [("Verbraucherpreise", "2026-10-14"), ("Arbeitsmarktbericht", "2026-10-26")]
              and TT_["n"] == 6)
        pruef.append(("Termine im Kopf: nächster je Veröffentlichung nur künftig (13.10. 8:30 NY um 15:00 UTC vorbei), 14 Tage bis 27.10. "
                      "(26.10. dabei, 28.10. nicht)", bool(ok), f"{ {k_: ts_tag(v_) for k_, v_ in TT_['naechste'].items()} } {len(TT_['vierzehn'])}"))
        # Erstanträge: 4-Wochen-Mittel nur über vier aufeinanderfolgende Wochen (eine fehlende Woche -> drei Werte fehlen)
        s0 = tag_ts("2024-01-06") // TAG                                                # ein Samstag
        kw = [k_ for k_ in range(24) if k_ != 10]
        ti = np.array([s0 + 7 * k_ for k_ in kw], dtype=np.int64); wi = np.array([200000.0 + 1000 * k_ for k_ in kw])
        leer = (np.zeros(0, dtype=np.int64), np.zeros(0))
        so_ = np.arange(s0 + 1, s0 + 1 + 7 * 30, 7, dtype=np.int64)
        UA = usa_rechnen(lambda n_: (ti, wi) if n_ == "fred:ICSA" else leer, np.arange(s0 - 10, s0 + 220, dtype=np.int64),
                         np.linspace(40000, 50000, 230), so_, np.full(len(so_), 0.01))
        a4_ = (UA.get("antraege") or {}).get("linien", [{}])[0].get("v")
        ok = (a4_ is not None and set(UA) == {"antraege"} and not np.isfinite(a4_[:3]).any() and not np.isfinite(a4_[10:13]).any()
              and abs(a4_[9] - np.mean([200 + k_ for k_ in (6, 7, 8, 9)])) < 1e-9 and abs(a4_[13] - np.mean([200 + k_ for k_ in (11, 12, 13, 14)])) < 1e-9)
        pruef.append(("Erstanträge: 4-Wochen-Mittel nur über vier lückenlose Wochen (Woche 10 fehlt -> die drei folgenden ohne Wert), von Hand",
                      bool(ok), f"{None if a4_ is None else [None if not np.isfinite(x_) else round(float(x_), 2) for x_ in a4_[8:15]]}"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


class _TerminNetz:
    """23.127 (U316): falsches Netz für den Abruf nach Bekanntgabe -- FRED (Beobachtungen erst ab einer Uhrzeit sichtbar, Releases,
    Termine), Feed und Seiten der Fed (ebenfalls ab einer Uhrzeit). Zählt Aufrufe mit der Uhrzeit des Aufrufs."""

    def __init__(self, uhr: list):
        self.uhr = uhr; self.aufrufe: list = []; self.fehler: dict = {}
        self.obs: dict = {}; self.rel: dict = {}; self.dates: dict = {}; self.rss: list = []; self.seiten: dict = {}

    def n(self, muster: str, ab: float = -1e18) -> int:
        return sum(1 for t, u in self.aufrufe if muster in u and t >= ab)

    def __call__(self, url, timeout=30, art="json"):
        jetzt = self.uhr[0]
        self.aufrufe.append((jetzt, url))
        for muster, err in self.fehler.items():
            if muster in url:
                return None, err
        if "fred/series/release" in url:
            sid = re.search(r"series_id=(\w+)", url).group(1)
            rid = self.rel.get(sid)
            return ({"releases": [{"id": rid, "name": f"Release {rid}"}]} if rid else {"releases": []}), None
        if "fred/release/dates" in url:
            rid = int(re.search(r"release_id=(\d+)", url).group(1))
            return {"release_dates": [{"release_id": rid, "date": d} for d in self.dates.get(rid, [])]}, None
        if "fred/series/observations" in url:
            sid = re.search(r"series_id=(\w+)", url).group(1)
            return {"observations": [{"date": d, "value": str(w)} for d, w, ab in self.obs.get(sid, []) if ab <= jetzt]}, None
        if url == FED_RSS:
            items = "".join(f"<item><title>{t}</title><link><![CDATA[{l}]]></link><guid isPermaLink=\"true\"><![CDATA[{l}]]></guid>"
                            f"<description>{t}</description><category>Monetary Policy</category><pubDate>{p}</pubDate></item>"
                            for t, l, p, ab in self.rss if ab <= jetzt)
            return ("﻿<?xml version=\"1.0\" encoding=\"utf-8\" ?><rss version=\"2.0\"><channel><title>FRB: Press Release - Monetary Policy</title>"
                    "<link>https://www.federalreserve.gov/feeds/feeds.htm</link><description>Press releases</description><language>en</language>"
                    + items + "</channel></rss>"), None
        if "federalreserve.gov/newsevents/" in url:
            h, ab = self.seiten.get(url, (None, 0))
            if h is None or ab > jetzt:
                return None, "HTTP 404: Not Found"
            return h, None
        return None, "HTTP 404: unbekannt"


def _erklaerung_html(satz: str, datum: str = "December 09, 2026") -> str:
    """Seite wie die der Fed (gekürzt): Kopf mit Datum, Titel, „For release at 2:00 p.m. EST“, Absätze, ein Gegenvotum."""
    return (f"<!DOCTYPE html><html><head><title>Federal Reserve Board - Federal Reserve issues FOMC statement</title>"
            f"<script>var x = 'decided to raise the target range for the federal funds rate to 9 to 9-1/4 percent';</script></head><body>"
            f"<div class=\"article__time\">{datum}</div><h3 class=\"title\">Federal Reserve issues FOMC statement</h3>"
            f"<p class=\"releaseTime\">For release at 2:00 p.m. EST</p><p>Recent indicators suggest that economic activity has been "
            f"expanding at a solid pace.</p><p>{satz}</p><p>Voting against the action was Jane Doe, who preferred to lower the target range "
            f"for the federal funds rate by 1/4 percentage point at this meeting.</p>"
            f"<p><a href=\"/newsevents/pressreleases/monetary20261209a1.htm\">Implementation Note issued {datum}</a></p></body></html>")


def termin_probe(verbose: bool = True) -> tuple:
    """23.127 (U316): Abruf nach Bekanntgabe -- Uhrzeiten mit Sommerzeit, Fenster, Ablauf am Termin mit falschem Netz und springender
    Uhr (erster Abruf nach 5 min, alle 5 min bis zur neuen Zahl, höchstens 4 h, 12-h-Takt bleibt, ohne Schlüssel nichts), Termine aller
    Veröffentlichungen, Fed-Tage aus Liste und Kalshi, Feed- und Erklärungs-Parser, Abruf am Entscheidungstag (Feed, Seite direkt,
    Gegenprobe), Treppe der Zielspanne, sofort neu rechnen, Debug 168."""
    import shutil
    import tempfile
    pruef = []
    ok = lambda name, gut, txt="": pruef.append((name, bool(gut), str(txt)[:240]))
    tmp = tempfile.mkdtemp(prefix="mk_termin_")
    k = "0123456789abcdef0123456789abcdef"
    alt_pm = os.environ.get("HL_PM_DB")
    T = tag_ts
    hm = lambda ts: time.strftime("%H:%M", time.gmtime(ts))
    try:
        os.environ["HL_PM_DB"] = os.path.join(tmp, "pm.db")
        # ---- T1 Uhrzeiten (New York, Sommer- und Winterzeit; Berlin stellt eine Woche früher um)
        u1 = ny_utc(T("2026-12-03"), 8, 30); u2 = ny_utc(T("2026-10-29"), 16, 30); u3 = ny_utc(T("2026-11-02"), 16, 15)
        u4 = ny_utc(T("2026-03-09"), 8, 30); u5 = ny_utc(T("2026-12-09"), 14, 0); u6 = ny_tag(T("2026-12-10") + 2 * 3600)
        ok("T1 Uhrzeit New York -> UTC: 03.12. 8:30 = 13:30 (Winterzeit), 29.10. 16:30 = 20:30 (noch Sommerzeit, Berlin schon Winterzeit), "
           "02.11. 16:15 = 21:15, 09.03. 8:30 = 12:30 (Sommerzeit ab 08.03.), Fed 09.12. 14:00 = 19:00 (20:00 Berlin); 10.12. 02:00 UTC ist in "
           "New York noch der 09.12.",
           u1 == T("2026-12-03") + 13 * 3600 + 1800 and u2 == T("2026-10-29") + 20 * 3600 + 1800 and u3 == T("2026-11-02") + 21 * 3600 + 900
           and u4 == T("2026-03-09") + 12 * 3600 + 1800 and u5 == T("2026-12-09") + 19 * 3600 and u6 == T("2026-12-09")
           and ny830_utc(T("2026-12-03")) == u1,
           f"{hm(u1)} {hm(u2)} {hm(u3)} {hm(u4)} {hm(u5)} {ts_tag(u6)}")
        # ---- Grundlage: makro.db mit Releases, Terminen und alten Werten
        pfad = os.path.join(tmp, "makro.db")
        uhr = [float(T("2026-12-03") + 6 * 3600)]
        netz = _TerminNetz(uhr)
        m = Makro(pfad, http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        rel = {"ICSA": 180, "CPIAUCSL": 10, "UNRATE": 50, "PPIFIS": 46, "WALCL": 20, "WTREGEN": 20, "M2SL": 21, "DTWEXBGS": 17, "DEXUSEU": 17,
               "DEXJPUS": 17, "DFII10": 18, "DFF": 18, "RRPONTSYD": 31, "CPIAUCNS": 10, "CPILFESL": 10, "CPILFENS": 10, "PPIFID": 46, "PAYEMS": 50}
        _meta_setzen(m.con, {f"release:{s_}": json.dumps({"id": r_, "name": f"R{r_}"}) for s_, r_ in rel.items()})
        termine_schreiben(m.con, 180, [T("2026-11-26"), T("2026-12-03"), T("2026-12-10")], int(uhr[0]))
        termine_schreiben(m.con, 20, [T("2026-12-03")], int(uhr[0]))
        termine_schreiben(m.con, 18, [T("2026-12-02"), T("2026-12-03")], int(uhr[0]))
        for s_ in FRED:
            netz.obs[s_] = [("2026-11-01", 1.0, 0)]
        netz.obs["ICSA"] = [("2026-11-21", 210000.0, 0)]
        alt_ab = int(uhr[0]) - 86_400
        schreiben(m.con, [(f"fred:{s_}", T("2026-11-01"), 1.0) for s_ in FRED if s_ != "ICSA"] + [("fred:ICSA", T("2026-11-21"), 210000.0)], alt_ab)
        _meta_setzen(m.con, {**{f"ok:fred:{s_}": int(uhr[0]) for s_ in FRED}, **{f"voll:fred:{s_}": 1 for s_ in FRED}})
        # ---- T2 Fenster
        t_icsa = ny_utc(T("2026-12-03"), 8, 30); t_h41 = ny_utc(T("2026-12-03"), 16, 30); t_h15 = ny_utc(T("2026-12-03"), 16, 15)
        f0 = termin_fenster(m.con, t_icsa + 299, []); f1 = termin_fenster(m.con, t_icsa + 300, []); f2 = termin_fenster(m.con, t_icsa + 4 * 3600 - 1, [])
        f3 = termin_fenster(m.con, t_icsa + 4 * 3600, []); f4 = termin_fenster(m.con, t_h41 + 600, [])
        f5 = termin_fenster(m.con, ny_utc(T("2026-12-10"), 8, 5), [T("2026-12-09")])
        ok("T2 Fenster: ab 5 min nach der Uhrzeit bis unter 4 h danach (8:30 + 4:59 nichts, 8:35 offen, 12:29:59 offen, 12:30 zu); "
           "abends H.4.1 (16:30) und H.15 (16:15) zugleich offen; Zielspanne am Tag nach dem Fed-Entscheid ab 8:05; Reihen ohne Uhrzeit nie",
           f0 == {} and f1 == {"ICSA": t_icsa} and f2 == {"ICSA": t_icsa} and f3 == {}
           and f4 == {"WALCL": t_h41, "WTREGEN": t_h41, "DFII10": t_h15, "DFF": t_h15}
           and f5 == {"DFEDTARU": ny_utc(T("2026-12-10"), 8, 0), "DFEDTARL": ny_utc(T("2026-12-10"), 8, 0)}
           and not any(s_ in f4 for s_ in TERMIN_OHNE) and set(TERMIN_OHNE) & set(TERMIN_UHRZEIT) == set()
           and set(TERMIN_UHRZEIT) | set(TERMIN_OHNE) | set(TERMIN_NACH_FED) == set(FRED),
           f"{f1} {sorted(f4)} {f5}")
        # ---- T3 Ablauf am Termin: Erstanträge 03.12. 8:30 New York, FRED führt die Zahl 13 min später
        netz.obs["ICSA"].append(("2026-11-28", 216000.0, t_icsa + 13 * 60))
        uhr[0] = float(t_icsa - 60)
        termin_neu = 0; laeufe = []
        while uhr[0] < t_icsa + 4 * 3600 + 120:
            e_ = m.runde(nur="fred", archiv=False)
            termin_neu += e_.get("termin_neu", 0)
            if e_["ziele"]:
                laeufe.append((int(uhr[0] - t_icsa), dict(e_["ziele"])))
            uhr[0] += 20
        zeiten = [int(t_ - t_icsa) for t_, u_ in netz.aufrufe if "series_id=ICSA" in u_]
        zeile = m.con.execute("SELECT versuche, erster, letzter, da, wie FROM mk_terminabruf WHERE reihe='ICSA' AND termin=?", (t_icsa,)).fetchone()
        neu_w = m.con.execute("SELECT wert, abgerufen FROM mk_reihe WHERE reihe='fred:ICSA' AND ts=?", (T("2026-11-28"),)).fetchone()
        andere = [u_ for t_, u_ in netz.aufrufe if "fred/series/observations" in u_ and "series_id=ICSA" not in u_]
        ok("T3 Ablauf am Termin: Erstanträge 8:30, FRED nach 13 min -- Abrufe 5, 10, 15 min nach der Uhrzeit (die Runde alle 20 s fragt "
           "nicht öfter), beim dritten die neue Zahl; danach keiner mehr im Fenster; vermerkt mit 3 Abrufen und Zeitpunkt; die Runde meldet "
           "„termin_neu“; der 12-h-Takt läuft vom letzten Abruf weiter; keine andere Reihe abgefragt (ihre Fenster sind zu)",
           zeiten == [300, 600, 900] and zeile is not None and zeile[0] == 3 and zeile[1] == t_icsa + 300 and zeile[2] == t_icsa + 900
           and zeile[3] == t_icsa + 900 and zeile[4] == "termin" and neu_w is not None and neu_w[0] == 216000.0 and termin_neu >= 1
           and int(meta(m.con, "ok:fred:ICSA")) == t_icsa + 900 and not andere,
           f"Abrufe nach {zeiten} s; Zeile {zeile}; termin_neu {termin_neu}; andere {len(andere)}")
        # ---- T4 schon über den 12-h-Takt da; T5 ohne neue Zahl höchstens 4 h; T6 Fehler -> Pause
        netz.obs["WALCL"].append(("2026-12-02", 6.7e6, t_h41 + 2 * 60))
        schreiben(m.con, [("fred:WALCL", T("2026-12-02"), 6.7e6)], t_h41 + 3 * 60)       # der Takt hatte sie um 16:33 schon geholt
        netz.fehler["series_id=DFII10"] = "HTTP 503: kaputt"
        _meta_setzen(m.con, {f"ok:fred:{s_}": int(t_h15 - 600) for s_ in FRED})       # der 12-h-Takt ist im Abschnitt nicht fällig
        n0 = len(netz.aufrufe)
        uhr[0] = float(t_h15 - 60)
        while uhr[0] < t_h41 + 4 * 3600 + 120:
            if uhr[0] >= t_h15 + 1500:
                netz.fehler.clear()
            m.runde(nur="fred", archiv=False)
            uhr[0] += 20
        neu_a = netz.aufrufe[n0:]
        z_walcl = [int(t_ - t_h41) for t_, u_ in neu_a if "series_id=WALCL" in u_]
        z_tga = [int(t_ - t_h41) for t_, u_ in neu_a if "series_id=WTREGEN" in u_]
        z_dfii = [int(t_ - t_h15) for t_, u_ in neu_a if "series_id=DFII10" in u_]
        r_walcl = m.con.execute("SELECT versuche, da, wie FROM mk_terminabruf WHERE reihe='WALCL' AND termin=?", (t_h41,)).fetchone()
        r_tga = m.con.execute("SELECT versuche, da, wie FROM mk_terminabruf WHERE reihe='WTREGEN' AND termin=?", (t_h41,)).fetchone()
        soll_tga = list(range(300, 4 * 3600, 300))
        ok("T4 Zahl schon über den 12-h-Takt da (geschrieben nach der Uhrzeit): kein Abruf nach Termin, vermerkt als „takt“ mit 0 Abrufen",
           z_walcl == [] and r_walcl == (0, t_h41 + 180, "takt"), f"{z_walcl} {r_walcl}")
        ok("T5 Keine neue Zahl: Abrufe alle 5 min von 5 min bis unter 4 h nach der Uhrzeit (47), dann keiner mehr; vermerkt ohne Zeitpunkt",
           z_tga == soll_tga and r_tga == (47, None, None), f"{len(z_tga)} Abrufe, erster {z_tga[:1]}, letzter {z_tga[-1:]}; {r_tga}")
        ok("T6 Fehler im Fenster: die Pause nach dem Fehler gilt (15 min, dann 30 min), danach wieder alle 5 min",
           z_dfii[:3] == [300, 1200, 3000] and all(b_ - a_ == 300 for a_, b_ in zip(z_dfii[2:], z_dfii[3:])) and len(z_dfii) > 10,
           f"{z_dfii[:6]} … ({len(z_dfii)})")
        # ---- T7 ohne Schlüssel: nichts nach Termin (nur der Takt)
        m2 = Makro(os.path.join(tmp, "ohne.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel="")
        _meta_setzen(m2.con, {f"release:{s_}": json.dumps({"id": r_}) for s_, r_ in rel.items()})
        t10 = ny_utc(T("2026-12-10"), 8, 30)
        _meta_setzen(m2.con, {f"ok:fred:{s_}": int(t10) for s_ in FRED})
        termine_schreiben(m2.con, 180, [T("2026-12-10")], int(t_icsa))
        uhr[0] = float(t10 + 300); n1 = len(netz.aufrufe)
        e7 = m2.runde(nur="fred", archiv=False); m2.con.close()
        ok("T7 Ohne FRED-Schlüssel: kein Fenster, kein Abruf nach Termin (der 12-h-Takt allein)",
           len(netz.aufrufe) == n1 and not e7["ziele"] and m2._fenster == {}, f"{len(netz.aufrufe) - n1} Abrufe")
        # ---- T8 Termine aller Veröffentlichungen (fredtermin), Fehler einer weiteren hält die übrigen nicht auf
        m3 = Makro(os.path.join(tmp, "rel.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        netz.rel = dict(rel); netz.rel.pop("RRPONTSYD")
        netz.dates = {r_: ["2026-11-20", "2026-12-17"] for r_ in set(rel.values())}
        uhr[0] = float(T("2026-12-04") + 3600); n2 = len(netz.aufrufe)
        netz.fehler["series_id=M2SL"] = "HTTP 503: kurz weg"                 # eine weitere Reihe mit Fehler beim Abruf (nicht nur ohne Release)
        e8 = m3.runde(nur="fredtermin", archiv=False); netz.fehler.clear()
        a8 = [u_ for _t, u_ in netz.aufrufe[n2:]]
        ids8 = release_ids(m3.con)
        us_ab = all("realtime_start=2019-01-01" in u_ for u_ in a8 if "release/dates" in u_ and re.search(r"release_id=(10|50|180|46)\b", u_))
        kurz_ab = all(f"realtime_start={ts_tag(T('2026-12-04') - 60 * TAG)}" in u_ for u_ in a8
                      if "release/dates" in u_ and re.search(r"release_id=(20|21|17|18)\b", u_))
        tf8 = meta(m3.con, "termin_fehler") or ""
        n_t8 = m3.con.execute("SELECT COUNT(*) FROM mk_termin").fetchone()[0]
        n_us8 = usa_termine(m3.con, uhr[0])["n"]
        uhr[0] += 600; n3 = len(netz.aufrufe); m3.runde(nur="fredtermin", archiv=False); wieder = len(netz.aufrufe) - n3
        uhr[0] += 3600; n4 = len(netz.aufrufe); m3.runde(nur="fredtermin", archiv=False)
        nach_1h = [u_ for _t, u_ in netz.aufrufe[n4:] if "fred/series/release" in u_]
        netz.fehler["series_id=UNRATE"] = "HTTP 500: weg"
        m4 = Makro(os.path.join(tmp, "rel2.db"), http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        m4.runde(nur="fredtermin", archiv=False); netz.fehler.clear()
        f_us = meta(m4.con, "fehler:fredtermin:usa") or ""
        m4.con.close()
        ok("T8 Termine: Release für jede Reihe mit Uhrzeit (gemerkt), Termine der USA wie bisher ab 2019, die übrigen ab 60 Tagen vor heute; "
           "weitere Reihen ohne Release (RRPONTSYD) oder mit Fehler beim Abruf (M2SL) stehen als Fehler da, die übrigen gelten; die Zahl der "
           "Termine im Stand zählt nur die "
           "vier der USA; ohne Release fragt der Takt nach 10 min "
           "nicht schon wieder, nach über 1 h nur die fehlenden Reihen nach; ein Fehler bei den Reihen der USA bleibt ein Fehler des Ziels",
           e8["ziele"].get("fredtermin:usa", -1) > 0 and set(ids8) == set(TERMIN_UHRZEIT) - {"RRPONTSYD", "M2SL"} and us_ab and kurz_ab
           and "series/release RRPONTSYD" in tf8 and "series/release M2SL: HTTP 503" in tf8 and n_t8 == 2 * len(set(rel.values()) - {31, 21})
           and n_us8 == 2 * 4 and wieder == 0
           and sorted({re.search(r"series_id=(\w+)", u_).group(1) for u_ in nach_1h}) == ["M2SL", "RRPONTSYD"]
           and "series/release UNRATE" in f_us and "500" in f_us,
           f"Ziel {e8['ziele']}; {len(ids8)} Releases; Termine {n_t8}; Fehler „{tf8[:60]}“; nach 10 min {wieder}; nach 1 h {len(nach_1h)}; USA „{f_us[:50]}“")
        m3.con.close()
        # ---- T9 Fed-Tage aus Liste und Kalshi
        pmc = sqlite3.connect(os.environ["HL_PM_DB"])
        pmc.execute("CREATE TABLE pm_markt (plattform TEXT, markt TEXT, reihe TEXT, ende INTEGER)")
        zeilen_pm = [("kalshi", "KXFEDDECISION-26DEC-H25", "KXFEDDECISION", ny_utc(T("2026-12-09"), 13, 55)),
                     ("kalshi", "KXFED-27JAN-T4.00", "KXFED", ny_utc(T("2027-01-27"), 13, 55) * 1000),      # Millisekunden werden erkannt
                     ("kalshi", "KXFEDDECISION-27MAR-H0", "KXFEDDECISION", ny_utc(T("2027-03-18"), 13, 55)),   # weicht von der Liste ab
                     ("kalshi", "KXFED-27APR-X", "KXFED", ny_utc(T("2027-04-28"), 10, 0)),                   # 10:00: kein Entscheid
                     ("kalshi", "KXCPI-26DEC", "KXCPI", ny_utc(T("2026-12-10"), 13, 55)),
                     ("polymarket", "fed-dec", "KXFEDDECISION", ny_utc(T("2026-12-16"), 14, 0)),
                     ("kalshi", "KXFED-KAPUTT", "KXFED", 9 * 10 ** 18)]                                        # unmöglich: nur diese Zeile fällt weg
        pmc.executemany("INSERT INTO pm_markt VALUES (?,?,?,?)", zeilen_pm); pmc.commit(); pmc.close()
        F = fed_tage_alle(pfad, frisch=True)
        import hl_volatil as _VLp
        ok("T9 Fed-Tage: Kalshi KXFEDDECISION/KXFED mit Handelsschluss 13–15 Uhr New York (nicht 10:00, nicht andere Reihen oder Plattformen; "
           "Millisekunden erkannt; ein unmöglicher Handelsschluss fällt allein weg und ist gezählt), vereinigt mit der eingebauten Liste; "
           "Abweichung nur im Zeitraum von Kalshi gezählt",
           F["kalshi"] == [T("2026-12-09"), T("2027-01-27"), T("2027-03-18")] and T("2027-03-18") in F["alle"] and T("2027-03-17") in F["alle"]
           and F["nur_kalshi"] == [T("2027-03-18")] and F["nur_liste"] == [T("2027-03-17")] and F["fehler"] is None
           and F["kalshi_fehler"] == "1 Handelsschluss unlesbar"
           and len(F["liste"]) == len(_VLp.FOMC),
           f"Kalshi {[ts_tag(t_) for t_ in F['kalshi']]}; nur Kalshi {[ts_tag(t_) for t_ in F['nur_kalshi']]}; nur Liste {[ts_tag(t_) for t_ in F['nur_liste']]}")
        # ---- T10 Feed
        feed = ("﻿<?xml version=\"1.0\" encoding=\"utf-8\" ?><rss version=\"2.0\"><channel><title>FRB: Press Release - Monetary Policy</title>"
                "<link>https://www.federalreserve.gov/feeds/feeds.htm</link><description>x</description><language>en</language>"
                "<item><title>Minutes of the Board&#39;s discount rate meetings on October 19 and October 28, 2026</title>"
                "<link><![CDATA[https://www.federalreserve.gov/newsevents/pressreleases/monetary20261124a.htm]]></link>"
                "<guid isPermaLink=\"true\"><![CDATA[https://www.federalreserve.gov/newsevents/pressreleases/monetary20261124a.htm]]></guid>"
                "<description>x</description><category>Monetary Policy</category><pubDate>Tue, 24 Nov 2026 19:00:00 GMT</pubDate></item>"
                "<item><title>Federal Reserve issues FOMC statement</title>"
                "<link><![CDATA[https://www.federalreserve.gov/newsevents/pressreleases/monetary20261209a.htm]]></link>"
                "<pubDate>Wed, 09 Dec 2026 19:00:00 GMT</pubDate></item>"
                "<item><title>Implementation Note issued December 9, 2026</title><link>https://www.federalreserve.gov/x.htm</link>"
                "<pubDate>Wed, 09 Dec 2026 19:00:00 GMT</pubDate></item>"
                "<item><title>Federal Reserve issues FOMC statement on longer-run goals and monetary policy strategy</title>"
                "<link>https://www.federalreserve.gov/y.htm</link><pubDate>Tue, 27 Jan 2026 19:00:00 GMT</pubDate></item>"
                "</channel></rss>")
        E10 = fed_rss_parse(feed)
        kaputt = 0
        for t_ in ("<html><body>kein Feed</body></html>", "", None):
            try:
                fed_rss_parse(t_)
            except ValueError:
                kaputt += 1
        ok("T10 Feed der Fed: RSS 2.0 mit BOM, Adressen in CDATA, Entität &#39;, Zeit GMT -> neueste zuerst; als Erklärung zählt nur ein Titel, "
           "der auf „FOMC statement“ endet (nicht die Implementation Note, nicht die Strategie-Erklärung); kein Feed -> Fehler",
           [e_["titel"][:30] for e_ in E10][:3] == ["Federal Reserve issues FOMC st", "Implementation Note issued Dec", "Minutes of the Board's discoun"]
           and E10[0]["link"].endswith("monetary20261209a.htm") and E10[0]["pub"] == ny_utc(T("2026-12-09"), 14, 0)
           and [e_["link"][-21:] for e_ in E10 if FED_ERKLAERUNG_TITEL.search(e_["titel"])] == ["monetary20261209a.htm"] and kaputt == 3,
           f"{len(E10)} Einträge; Erklärungen {[e_['titel'] for e_ in E10 if FED_ERKLAERUNG_TITEL.search(e_['titel'])]}")
        # ---- T11 Erklärung
        P = fed_erklaerung_parse
        a = P(_erklaerung_html("In support of its goals, the Committee decided to maintain the target range for the federal funds rate at "
                               "3-3/4 to 4 percent, in support of the Federal Reserve's dual mandate.", "October 28, 2026"))
        b = P(_erklaerung_html("the Committee decided to raise the target range for the federal funds rate by 1/4&nbsp;percentage point to "
                               "4&#8209;1/4 to 4&#8209;1/2 percent."))
        c = P(_erklaerung_html("the Committee decided to <em>lower</em> the target range for the federal\n funds rate by 1/2 percentage point "
                               "to 4‑3/4 to 5 percent."))
        d_ = P(_erklaerung_html("the Committee decided to lower the target range for the federal funds rate to 0 to 1/4 percent."))
        e_k = P(_erklaerung_html("the Committee decided to keep the target range for the federal funds rate at 0 to 1/4 percent."))
        f_ = P("<p>Undertake open market operations as necessary to maintain the federal funds rate in a target range of 3-3/4 to 4 percent.</p>")
        g = P(_erklaerung_html("the Committee decided to maintain the target range for the federal funds rate at 3 to 4 percent."))
        h_ = P(_erklaerung_html("The Committee will continue to monitor the implications of incoming information."))
        ok("T11 Erklärung: unverändert 3-3/4 bis 4 (Datum der Seite), erhöht um 1/4 auf 4-1/4 bis 4-1/2 (Entität &#8209;, geschütztes Leerzeichen), "
           "gesenkt um 1/2 auf 4-3/4 bis 5 (Tag im Satz, U+2011, Zeilenumbruch), auf 0 bis 1/4 (2020), „keep“; ersatzweise die Implementation "
           "Note; Gegenvotum und Skript zählen nicht; unplausible Spanne (3 bis 4) und kein Satz -> Fehler",
           (a["aktion"], a["schritt"], a["unten"], a["oben"], a["datum"]) == ("unverändert", None, 3.75, 4.0, T("2026-10-28"))
           and (b["aktion"], b["schritt"], b["unten"], b["oben"]) == ("erhöht", 0.25, 4.25, 4.5)
           and (c["aktion"], c["schritt"], c["unten"], c["oben"]) == ("gesenkt", 0.5, 4.75, 5.0)
           and (d_["aktion"], d_["unten"], d_["oben"]) == ("gesenkt", 0.0, 0.25) and (e_k["aktion"], e_k["unten"], e_k["oben"]) == ("unverändert", 0.0, 0.25)
           and (f_["aktion"], f_["unten"], f_["oben"], f_["fehler"]) == (None, 3.75, 4.0, None)
           and g["unten"] is None and "unplausibel" in (g["fehler"] or "") and h_["unten"] is None and "kein Satz" in (h_["fehler"] or "")
           and (fed_zahl("3-3/4"), fed_zahl("4"), fed_zahl("1/4"), fed_zahl("0"), fed_zahl("x")) == (3.75, 4.0, 0.25, 0.0, None),
           f"{a['aktion']} {a['unten']}–{a['oben']} · {b['aktion']} {b['schritt']} {b['unten']}–{b['oben']} · {c['unten']}–{c['oben']} · {g['fehler']}")
        # ---- T12 Am Entscheidungstag: Feed ohne Erklärung, dann mit; Abrufe 30 s nach 14:00, jede Minute; danach nur stündlich
        m.con.close()
        pfad_f = os.path.join(tmp, "fed.db")
        t_fed = ny_utc(T("2026-12-09"), 14, 0)
        link = FED_SEITE.format(tag="20261209")
        netz2 = _TerminNetz(uhr)
        netz2.rss = [("Minutes of the Federal Open Market Committee, October 27-28, 2026", "https://www.federalreserve.gov/m.htm",
                      "Wed, 18 Nov 2026 19:00:00 GMT", 0),
                     ("Federal Reserve issues FOMC statement", link, "Wed, 09 Dec 2026 19:00:00 GMT", t_fed + 100)]
        netz2.seiten[link] = (_erklaerung_html("the Committee decided to raise the target range for the federal funds rate by 1/4 percentage "
                                               "point to 4 to 4-1/4 percent."), t_fed)
        netz2.seiten[FED_SEITE.format(tag="20261028")] = (_erklaerung_html("the Committee decided to maintain the target range for the "
                                                                           "federal funds rate at 3-3/4 to 4 percent.", "October 28, 2026"), 0)
        uhr[0] = float(t_fed - 7200)
        mf = Makro(pfad_f, http_fn=netz2, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        e12a = mf.runde(nur="fed", archiv=False)                                  # erster Lauf: Feed + Gegenprobe 28.10. über die Seite
        g12 = [z_ for z_ in fed_zeilen(mf.con) if z_["tag"] == T("2026-10-28")]
        n_g = netz2.n("monetary20261028a.htm")
        uhr[0] = float(t_fed - 7200 + 1800); mf.runde(nur="fed", archiv=False); n_halb = netz2.n(FED_RSS)
        uhr[0] = float(t_fed - 7200 + 3700); mf.runde(nur="fed", archiv=False); n_std = netz2.n(FED_RSS)
        uhr[0] = float(t_fed - 120)
        tn12 = 0; v12a = int(meta(mf.con, "version", "0") or 0)
        while uhr[0] < t_fed + 400:
            e_ = mf.runde(nur="fed", archiv=False); tn12 += e_.get("termin_neu", 0)
            uhr[0] += 10
        z_rss = [int(t_ - t_fed) for t_, u_ in netz2.aufrufe if u_ == FED_RSS and t_ >= t_fed - 120]
        z12 = [z_ for z_ in fed_zeilen(mf.con) if z_["tag"] == T("2026-12-09")]
        fa12 = mf.con.execute("SELECT versuche, da, wie FROM mk_terminabruf WHERE reihe='fed:erklaerung' AND termin=?", (t_fed,)).fetchone()
        v12b = int(meta(mf.con, "version", "0") or 0)
        uhr[0] = float(t_fed + 3000); mf.runde(nur="fed", archiv=False); n_danach = netz2.n(FED_RSS, t_fed + 400)
        ok("T12a Erster Lauf: Feed gelesen, dazu einmal die Seite des letzten Entscheids (28.10.2026) über ihre Adresse als Gegenprobe -- "
           "unverändert 3,75–4,00 %, gültig ab 29.10.; nach 30 min nichts, nach gut 1 h der Feed wieder",
           e12a["ziele"].get("fed:rss") == 1 and len(g12) == 1 and g12[0]["unten"] == 3.75 and g12[0]["oben"] == 4.0
           and g12[0]["quelle"] == "adresse" and g12[0]["wirksam"] == T("2026-10-29") and n_g == 1 and n_halb == 1 and n_std == 2,
           f"{e12a['ziele']}; {[(ts_tag(z_['tag']), z_['unten'], z_['oben']) for z_ in g12]}; Feed {n_halb}/{n_std}")
        ok("T12b Entscheidungstag 09.12.: kein Abruf vor 14:00:30, dann jede Minute (30, 90 s); die Erklärung steht ab 14:01:40 im Feed -> beim "
           "Abruf 150 s gelesen: erhöht um 0,25 auf 4,00–4,25 %, gültig ab 10.12.; Datenversion hoch, die Runde meldet „termin_neu“; vermerkt mit "
           "3 Abrufen über den Feed; danach im Fenster kein Abruf mehr, nur der stündliche",
           z_rss == [30, 90, 150] and len(z12) == 1 and z12[0]["unten"] == 4.0 and z12[0]["oben"] == 4.25 and z12[0]["aktion"] == "erhöht"
           and z12[0]["schritt"] == 0.25 and z12[0]["wirksam"] == T("2026-12-10") and z12[0]["quelle"] == "rss" and tn12 == 1
           and fa12 == (3, t_fed + 150, "rss") and n_danach == 0 and v12b == v12a + 1,
           f"Feed nach {z_rss} s; {[(z_['aktion'], z_['unten'], z_['oben'], z_['quelle']) for z_ in z12]}; {fa12}; danach {n_danach}")
        # ---- T12c Seite direkt, wenn der Feed sie nach 10 min nicht führt; Fehler des Feeds im Fenster: nächster Versuch nach 1 min
        pfad_g = os.path.join(tmp, "fed2.db")
        netz3 = _TerminNetz(uhr); netz3.rss = []
        netz3.seiten[link] = netz2.seiten[link]
        netz3.seiten[FED_SEITE.format(tag="20261028")] = netz2.seiten[FED_SEITE.format(tag="20261028")]
        uhr[0] = float(t_fed - 3600)
        mg = Makro(pfad_g, http_fn=netz3, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)
        mg.runde(nur="fed", archiv=False)
        netz3.fehler[FED_RSS] = "HTTP 503: kurz weg"
        uhr[0] = float(t_fed + 30)
        while uhr[0] < t_fed + 900:
            if uhr[0] >= t_fed + 200:
                netz3.fehler.clear()
            mg.runde(nur="fed", archiv=False)
            uhr[0] += 10
        z_rss3 = [int(t_ - t_fed) for t_, u_ in netz3.aufrufe if u_ == FED_RSS and t_ >= t_fed]
        z_seite3 = [int(t_ - t_fed) for t_, u_ in netz3.aufrufe if u_ == link]
        z13 = [z_ for z_ in fed_zeilen(mg.con) if z_["tag"] == T("2026-12-09")]
        mg.con.close()
        ok("T12c Feed fällt im Fenster aus: der nächste Versuch nach 1 min (nicht nach der Pause von 15 min); führt der Feed die Erklärung "
           "10 min nach 14:00 nicht, kommt sie beim nächsten Abruf (14:10:30) über die Adresse der Seite (monetary20261209a.htm) -- vermerkt "
           "als „adresse“, danach Ruhe",
           z_rss3[:4] == [30, 90, 150, 210] and z_seite3 == [630] and len(z13) == 1 and z13[0]["quelle"] == "adresse" and z13[0]["oben"] == 4.25
           and z_rss3[-1] == 630 and all(b_ - a_ == 60 for a_, b_ in zip(z_rss3, z_rss3[1:])),
           f"Feed {z_rss3[:6]}…; Seite {z_seite3}; {[(z_['quelle'], z_['oben']) for z_ in z13]}")
        # ---- T13 Treppe der Zielspanne; vorläufig bis FRED den Tag führt; FRED bestätigt am Morgen danach (Fenster 8:05)
        tage_f = [ts_tag(t_) for t_ in range(T("2026-09-10"), T("2026-12-10"), TAG)]
        for s_, vor_, nach_ in (("DFEDTARU", 3.75, 4.0), ("DFEDTARL", 3.5, 3.75)):
            netz2.obs[s_] = [(d_t, vor_ if d_t < "2026-09-17" else nach_, 0) for d_t in tage_f]
            netz2.obs[s_].append(("2026-12-10", nach_ + 0.25, ny_utc(T("2026-12-10"), 8, 1)))
        uhr[0] = float(ny_utc(T("2026-12-10"), 7, 0))
        mf.runde(nur="fred", archiv=False)                                        # FRED bis 09.12. (alle Reihen fällig)
        con_r = lesen(pfad_f)
        S1 = fed_stand(con_r, Reihen(con_r), [T("2026-09-13") // TAG + 7 * i for i in range(14)])
        con_r.close()
        uhr[0] = float(ny_utc(T("2026-12-10"), 8, 0) + 300)
        n_dft = netz2.n("series_id=DFEDTARU")
        e13 = mf.runde(nur="fred", archiv=False)
        n_dft2 = netz2.n("series_id=DFEDTARU")
        con_r = lesen(pfad_f)
        S2 = fed_stand(con_r, Reihen(con_r), [T("2026-09-13") // TAG + 7 * i for i in range(14)])
        txt13 = termin_text(pfad_f, uhr[0])
        con_r.close()
        t17 = T("2026-09-17") // TAG
        st1 = dict(zip(S1["t"], zip(S1["u"], S1["o"])))
        ok("T13 Treppe: je Wechsel der Tag davor (alt) und der Tag selbst (neu), dazwischen das Wochenraster; vorläufig 4,00–4,25 ab 10.12. aus "
           "der Erklärung, solange FRED nur bis 09.12. reicht; am 10.12. ab 8:05 New York holt das Fenster DFEDTARU/DFEDTARL, FRED führt den "
           "Tag -> nicht mehr vorläufig, Quelle FRED; Debug 168 nennt „FRED gleich“",
           st1.get(t17 - 1) == (3.5, 3.75) and st1.get(t17) == (3.75, 4.0) and S1["t"][-1] == T("2026-12-10") // TAG
           and st1.get(T("2026-12-10") // TAG) == (4.0, 4.25) and S1["vorl"] and S1["vorl"]["wirksam"] == T("2026-12-10") // TAG
           and S1["jetzt"]["quelle"].startswith("Erklärung") and all(b_ >= a_ for a_, b_ in zip(S1["t"], S1["t"][1:]))
           and n_dft2 - n_dft == 1 and e13.get("termin_neu", 0) >= 2 and S2["vorl"] is None and S2["jetzt"]["quelle"] == "FRED"
           and (S2["jetzt"]["u"], S2["jetzt"]["o"]) == (4.0, 4.25) and "FRED gleich" in txt13,
           f"Punkte {len(S1['t'])}; vorläufig {S1['vorl'] and (S1['vorl']['u'], S1['vorl']['o'])}; danach {S2['jetzt']}")
        # ---- T14 Anzeige: Nutzlast des Tabs Makro trägt die Treppe und den Entscheid (testdaten mit Leitzins)
        pfad_n = os.path.join(tmp, "nutz", "makro.db"); os.makedirs(os.path.dirname(pfad_n))
        testdaten(pfad_n)
        con_n = verbinden(pfad_n)
        so_ = [r_[0] for r_ in con_n.execute("SELECT DISTINCT ts FROM mk_reihe WHERE reihe='fred:DFF' ORDER BY ts")]
        schreiben(con_n, [("fred:DFEDTARU", t_, 4.0) for t_ in so_] + [("fred:DFEDTARL", t_, 3.75) for t_ in so_])
        con_n.execute("INSERT INTO mk_fed VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (so_[-1], link, "Federal Reserve issues FOMC statement", None, int(time.time()),
                                                                             "rss", "erhöht", 0.25, 4.0, 4.25, so_[-1] + TAG, None))
        _version_hoch(con_n); con_n.close()
        _CACHE.update(pfad=None, D=None, nutz={})
        N = nutzlast(pfad_n, "makro")
        lz = ((N.get("makro") or {}).get("leitzins") or {})
        _FED_CACHE.update(pfad=pfad_n, wert={"kaputt": True}, ts=time.time()); _CACHE.update(nutz={})   # Fed-Tage kaputt: der Tab kommt
        N2 = nutzlast(pfad_n, "makro"); _FED_CACHE.update(pfad=None, wert=None); _CACHE.update(nutz={})
        lz2 = ((N2.get("makro") or {}).get("leitzins") or {})
        ok("T14 Nutzlast Tab Makro: Chart „Leitzins“ mit Treppe der Zielspanne (Tage, unten, oben; letzter Punkt der vorläufige Tag) und dem "
           "Entscheid (vorläufig, jetzt, nächster Termin); sind die Fed-Tage nicht lesbar, kommt der Tab trotzdem (ohne nächsten Termin)",
           lz.get("ziel") and len(lz["ziel"]["t"]) == len(lz["ziel"]["u"]) == len(lz["ziel"]["o"]) and lz["ziel"]["t"][-1] == (so_[-1] + TAG) // TAG
           and lz["ziel"]["o"][-1] == 4.25 and (lz.get("fed") or {}).get("vorl", {}).get("o") == 4.25 and "naechster" in (lz.get("fed") or {})
           and "fehler" not in (lz.get("fed") or {}) and lz2.get("ziel") == lz.get("ziel") and (lz2.get("fed") or {}).get("naechster") is None
           and str((lz2.get("fed") or {}).get("fehler", "")).startswith("KeyError"),
           f"{len((lz.get('ziel') or {}).get('t', []))} Punkte; fed {sorted((lz.get('fed') or {}).keys())}; kaputt {(lz2.get('fed') or {}).get('fehler')}")
        # ---- T15 sofort neu rechnen; Verträge im Quelltext
        r1 = neu_rechnen_noetig({"termin_neu": 1, "neu_ohne_archiv": 1}, 1000.0, 1030.0, "x", "x")
        r2 = neu_rechnen_noetig({"termin_neu": 0, "neu_ohne_archiv": 1}, 1000.0, 1030.0, "x", "x")
        r3 = neu_rechnen_noetig({"termin_neu": 0, "neu_ohne_archiv": 1}, 1000.0, 1000.0 + NEU_RECHNEN_S + 1, "x", "x")
        r4 = neu_rechnen_noetig({"termin_neu": 0, "neu_ohne_archiv": 0}, 1000.0, 1400.0, "a", "b")
        import inspect
        q_s = inspect.getsource(_schleife); q_r = inspect.getsource(Makro.runde)
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "install.py"), encoding="utf-8") as f_i:
                inst_ = f_i.read()
        except OSError:
            inst_ = ""
        ok("T15 Nach einer neuen Zahl aus Termin oder Erklärung rechnet der Takt sofort neu (sonst frühestens nach 10 min); der Takt ruft die "
           "Regel; die Runde fragt Termine nur für FRED-Reihen und den Feed nach seinem eigenen Takt; Ziel „fed:rss“ stündlich; der Installer "
           "prüft diesen Selbsttest",
           r1 and not r2 and r3 and r4 and "neu_rechnen_noetig(erg, letzte_rechnung" in q_s and "self.termin_faellig(ziel)" in q_r
           and "self.fed_faellig(abstand)" in q_r and ("fed", "rss", FED_REGEL_S) in Makro.ZIELE and FED_REGEL_S == 3600
           and '[py, str(ROOT / "hl_makro.py"), "--selbsttest-termine"]),' in inst_,
           f"{r1} {r2} {r3} {r4}")
        # ---- T16 Debug 168
        txt = termin_text(pfad, float(t_h41 + 5 * 3600))
        ok("T16 Debug 168: Regel, Termine je Veröffentlichung mit Uhrzeit, die Abrufe nach Termin (Zahl da nach X min, schon über den Takt, "
           "keine neue Zahl), Reihen ohne festen Zeitpunkt, Fed-Termine mit Abweichung Liste/Kalshi",
           "★ Makro: Abruf nach Bekanntgabe (U316, Debug 168)" in txt and "Zahl da" in txt and "15 min nach der Uhrzeit, 3 Abrufe" in txt
           and "Zahl schon über den 12-h-Takt da" in txt and "KEINE neue Zahl im Fenster (47 Abrufe" in txt and "BAMLH0A0HYM2" in txt
           and "08:30 New York" in txt and "16:30 New York" in txt and "ABWEICHUNG Liste/Kalshi" in txt and "nur bei Kalshi 18.03.2027" in txt and "nur in der Liste 17.03.2027" in txt,
           txt.split("\n")[0][:80])
        # ---- T17 Liste der Fed-Entscheide (hl_volatil) nach der Pressemitteilung vom 12.11.2026
        fomc = set(_VLp.FOMC)
        ok("T17 Liste der Fed-Entscheide 2027 nach dem revidierten Plan der Fed (12.11.2026): kein Entscheid am 27.10.2027 (Sitzung zur "
           "Strategie), der letzte am 17.11.2027 statt am 08.12.2027, dazu 26.01.2028; 2026 unverändert",
           "2027-10-27" not in fomc and "2027-12-08" not in fomc and "2027-11-17" in fomc and "2028-01-26" in fomc
           and {"2026-10-28", "2026-12-09", "2027-01-27", "2027-09-15"} <= fomc and list(_VLp.FOMC) == sorted(_VLp.FOMC),
           f"2027: {[t_ for t_ in _VLp.FOMC if t_.startswith('2027')]}; {_VLp.FOMC[-1]}")
        mf.con.close()
        # ---- T18 Eine Ausnahme der Schicht nach Termin hält die Runde nicht an (hier: die Fed-Tage sind nicht lesbar)
        p18 = os.path.join(tmp, "ausnahme.db")
        m18 = Makro(p18, http_fn=netz, uhr=lambda: uhr[0], pause_s=0, fred_schluessel=k)

        def _kaputt():
            raise RuntimeError("Probe: Fed-Tage kaputt")
        m18._fed_tage = _kaputt
        uhr[0] = float(T("2026-12-11") + 15 * 3600)
        netz.obs["DFF"] = [("2026-12-09", 3.88, 0), ("2026-12-10", 3.88, 0)]
        e18 = m18.runde(nur="fred", archiv=False)
        a18 = termin_ausnahme_lesen(m18.con, uhr[0])
        uhr[0] += 60
        e18b = m18.runde(nur="fed", archiv=False)
        gp18 = meta(m18.con, "fed:gegenprobe")
        m18.con.close()
        txt18 = termin_text(p18, uhr[0]); kurz18 = termin_kurz(p18, uhr[0])
        f18 = sorted(k_ for k_ in e18["ziele"] if k_.startswith("fred:"))
        ok("T18 Eine Ausnahme der Schicht nach Termin (hier: Fed-Tage nicht lesbar) hält die Runde nicht an: Der 12-h-Takt holt alle "
           "FRED-Reihen, der Feed läuft nach seinem Abstand (ohne Gegenprobe, bis die Fed-Tage lesbar sind); die Ausnahme steht in "
           "Debug 168 und im Makro-Stand",
           f18 == sorted(f"fred:{s_}" for s_ in FRED) and e18["ziele"].get("fred:DFF", -1) > 0 and a18 is not None
           and a18[1] == "Fenster: RuntimeError: Probe: Fed-Tage kaputt" and e18b["ziele"].get("fed:rss", -1) >= 0 and not gp18
           and "AUSNAHME in der Schicht nach Termin" in txt18 and "Probe: Fed-Tage kaputt" in txt18 and "AUSNAHME " in kurz18,
           f"FRED {len(f18)} von {len(FRED)}, DFF {e18['ziele'].get('fred:DFF')}; Ausnahme {a18}; Feed {e18b['ziele']}; Gegenprobe {gp18}")
    except Exception as e_:                                                  # eine Ausnahme ist ein Fehlschlag (FEHL-Zeile), kein Abbruch
        import traceback
        tb_ = traceback.extract_tb(e_.__traceback__)
        ok("Ausnahme im Selbsttest", False, f"{type(e_).__name__}: {e_} -- " + " < ".join(f"{os.path.basename(f_.filename)}:{f_.lineno} {f_.name}"
                                                                                    for f_ in tb_[::-1][:3]))
    finally:
        if alt_pm is None:
            os.environ.pop("HL_PM_DB", None)
        else:
            os.environ["HL_PM_DB"] = alt_pm
        _FED_CACHE.update(pfad=None, wert=None)
        _CACHE.update(pfad=None, D=None, nutz={})
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def selbsttest(verbose: bool = True) -> bool:
    global TOKENS_DATEI
    import tempfile
    t0 = time.time()
    alt = os.environ.pop("HL_MAKRO_DB", None)
    # 23.48: Selbsttest unabhängig von einem echten FRED-Schlüssel (Umgebung oder accesstokens.json des Pi)
    env_fred = os.environ.pop("FRED_API_KEY", None); tokens_alt = TOKENS_DATEI
    TOKENS_DATEI = os.path.join(tempfile.gettempdir(), f"mk_selbsttest_ohne_tokens_{os.getpid()}.json")
    if verbose:
        print("Makro-Chart (U121) -- Selbsttest: je Treiber Positivkontrolle und Nulltest, Kausalität, Parser, Zeitplan, Nutzlast")
    ok = True
    try:
        for teil in (mathe_probe, parser_probe, abruf_probe, gesamt_probe, frische_probe, fred_probe, usa_probe, termin_probe):
            try:
                gut, _ = teil(verbose)
            except Exception as e:
                import traceback
                gut = False
                if verbose:
                    print(f"  FEHL {teil.__name__}: {type(e).__name__}: {e}")
                    traceback.print_exc()
            ok = ok and gut
    finally:
        if alt is not None:
            os.environ["HL_MAKRO_DB"] = alt
        if env_fred is not None:
            os.environ["FRED_API_KEY"] = env_fred
        TOKENS_DATEI = tokens_alt
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return ok


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Makro-Chart (U121): Quellen, Stand, Abruf, Selbsttest")
    ap.add_argument("--db", help="Hauptdatenbank (makro.db liegt daneben)")
    ap.add_argument("--stand", action="store_true")
    ap.add_argument("--abrufen", action="store_true", help="fällige Ziele jetzt abrufen (mit --erzwingen alle)")
    ap.add_argument("--erzwingen", action="store_true")
    ap.add_argument("--quelle", help="nur diese Quelle: cm, fred, fng, llama, bc, drb, bnc, farside, bgm, oi_archiv")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--termine", action="store_true", help="23.127 (U316): Abruf nach Bekanntgabe -- Termine, Abrufe nach Termin, Fed-Entscheid (Debug 168)")
    ap.add_argument("--selbsttest-termine", action="store_true", help="23.127 (U316): Selbsttest des Abrufs nach Bekanntgabe (Debug 169, ohne Netz)")
    ap.add_argument("--fred-schluessel", metavar="SCHLÜSSEL",
                    help="kostenlosen FRED-API-Schlüssel (32 Zeichen, " + FRED_SCHLUESSEL_SEITE + ") prüfen und in accesstokens.json eintragen; "
                         "mit --db werden die FRED-Pausen in makro.db zurückgesetzt")
    a = ap.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.selbsttest_termine:
        t0_ = time.time()
        _tok = TOKENS_DATEI; TOKENS_DATEI = os.path.join(__import__("tempfile").gettempdir(), f"mk_termin_ohne_tokens_{os.getpid()}.json")
        _env = os.environ.pop("FRED_API_KEY", None)
        print("Makro: Selbsttest Abruf nach Bekanntgabe (U316, Debug 169) -- ohne Netz, mit springender Uhr")
        try:
            gut_, _p = termin_probe(True)
        finally:
            TOKENS_DATEI = _tok
            if _env is not None:
                os.environ["FRED_API_KEY"] = _env
        print(f"  Ergebnis: {'bestanden' if gut_ else 'NICHT bestanden'} ({sum(1 for x_ in _p if x_[1])}/{len(_p)}, {time.time() - t0_:.0f} s)")
        sys.exit(0 if gut_ else 1)
    if a.fred_schluessel is not None:
        ok_, meldung_ = fred_schluessel_einrichten(a.fred_schluessel, makro_pfad(a.db) if a.db else None)
        print(meldung_)
        sys.exit(0 if ok_ else 1)
    if not a.db:
        ap.print_help(); sys.exit(2)
    pfad_ = makro_pfad(a.db)
    if a.termine:
        print(termin_text(pfad_))
        sys.exit(0)
    if a.abrufen:
        m_ = Makro(pfad_)
        print(f"Abruf in {pfad_} ...", flush=True)
        e_ = m_.runde(nur=a.quelle, erzwingen=a.erzwingen, archiv=a.quelle == "oi_archiv")
        for k_, v_ in e_["ziele"].items():
            print(f"  {k_:<26} {'FEHLER (siehe Stand)' if v_ < 0 else str(v_) + ' neue/geänderte Werte'}")
        if not e_["ziele"]:
            print("  nichts fällig (mit --erzwingen alle Ziele außer BGeometrics-Budget und Archiv)")
        con_ = lesen(pfad_)
        D_ = ableiten(con_); con_.close()
        if D_.get("ok"):
            print(f"  Archiv: {archivieren(m_.con, D_)} neue Zeilen (Tagesstand, Power-Law-Parameter)")
        print()
    print(stand_text(pfad_))
