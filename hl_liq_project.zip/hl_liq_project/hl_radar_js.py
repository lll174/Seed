"""
hl_radar_js.py -- Skript der Karte „Risikoradar“ im Cockpit (U307, 23.122), ausgeliefert unter /radar.js.

Eigene Datei wie hl_cockpit_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf den
Helfern der Seite und des Cockpits auf ($, getJSON, esc, ckZ, ckPx, ckZeit, ckForm, ckCoin, ckOffen, ckWaehle, CK_F, TON, tonCtx,
tonSirene, tonSchalter) -- sie werden erst beim Zeichnen gebraucht. Das Skript steht in der Seite VOR /cockpit.js, damit ckZeichne
die Karte schon beim ersten Mal findet (rdKarte); ckLaden ruft rdLaden.

Das Skript rechnet nichts: Zahlen, Stufen, Achsen, Sätze und Belege kommen fertig von /cockpit/radar (hl_radar.py). Hier nur die
Zeichnung, die Schalter und die Meldungen im Browser:
  Ton      Sirene 4 s beim Alarm, kurzer Doppelton beim Hinweis -- nur wenn „Töne an“ (der Schalter der Seite)
  Ansage   der Browser spricht den Satz des Alarms (speechSynthesis, Deutsch) -- nur wenn der Schalter „Ansage“ an ist; kann der
           Browser nicht sprechen, steht das in der Karte
Gespielt wird jede Meldung einmal (die Nummer der letzten liegt im Browser) und nur, wenn sie höchstens 10 Minuten alt ist; mehrere
Alarme zugleich: eine Sirene, die Ansagen nacheinander. Die Entwarnung bleibt still. Ton und Ansage gibt es nur bei offener Seite --
der Push kommt auch ohne sie.
Regeln des Cockpits: Form und Wort je Stufe (Ring = normal, Kreis = erhöht, Quadrat = hoch, gestrichelter Ring = ohne Stufe), Farbe
nur für Geprüftes -- eine Stufe gibt es nur, wenn der Rückblick der Zahl besteht; Achsen neutral blau; kein Pfeil, kein Empfehlungswort.
Das Netz zeigt acht Achsen von 0 bis 100; eine graue Achse hat keinen Punkt, die Linie über sie hinweg ist gestrichelt. Die Liste
darunter nennt dieselben Werte genau.
"""

RADAR_JS = r"""// 23.122 Risikoradar (U307): Karte im Cockpit. Daten: /cockpit/radar?coin=.. (hl_radar.py, nur lesend), Meldungen: /cockpit/radar/meldungen.
const RD={d:null, coin:null, laeuft:false, geladen:0, achse:null, fehler:null, meldOffen:false, belegOffen:false, sendet:false, hinweis:null,
 ansage:(()=>{ try{ return localStorage.getItem('hl_radar_ansage')==='1'; }catch(e){ return false; } })(),
 gesehen:(()=>{ try{ return parseInt(localStorage.getItem('hl_radar_gesehen')||'0',10)||0; }catch(e){ return 0; } })()};
const RD_COINS=['BTC','ETH','HYPE','ZEC','XMR'];
function rdSprechenKann(){ return typeof window.speechSynthesis!=='undefined'&&typeof window.SpeechSynthesisUtterance!=='undefined'; }
function rdSprich(texte){ const T=(Array.isArray(texte)?texte:[texte]).filter(Boolean); if(!rdSprechenKann()||!T.length) return false;
 try{ window.speechSynthesis.cancel(); T.forEach(t=>{ const u=new SpeechSynthesisUtterance(String(t)); u.lang='de-DE'; u.rate=1; window.speechSynthesis.speak(u); }); return true; }
 catch(e){ return false; } }
function rdTonHinweis(){ const c=(typeof tonCtx==='function')?tonCtx():null; if(!c) return false; const t0=c.currentTime;
 [[660,0],[880,0.22]].forEach(([f,dt])=>{ const o=c.createOscillator(), g=c.createGain(); o.type='sine'; o.frequency.value=f;
  g.gain.setValueAtTime(0.0001,t0+dt); g.gain.exponentialRampToValueAtTime(0.2,t0+dt+0.02); g.gain.exponentialRampToValueAtTime(0.0001,t0+dt+0.2);
  o.connect(g); g.connect(c.destination); o.start(t0+dt); o.stop(t0+dt+0.25); });
 return true; }
function rdTonAn(){ return typeof TON!=='undefined'&&!!TON.on; }

// ---------- Meldungen: jede einmal, höchstens 10 Minuten alt; Entwarnungen bleiben still ----------
function rdMelden(M, altS){ const jetzt=Date.now()/1000, neu=(M||[]).filter(m=>m&&m.id>RD.gesehen).sort((a,b)=>a.id-b.id); if(!neu.length) return null;
 const frisch=neu.filter(m=>jetzt-m.ts<=(altS||600)), alarme=frisch.filter(m=>m.art==='alarm'), hinweise=frisch.filter(m=>m.art==='hinweis');
 const aus={alarme:alarme.length, hinweise:hinweise.length, sirene:false, ton:false, ansagen:0};
 if(alarme.length){
  if(rdTonAn()&&typeof tonSirene==='function'){ tonSirene(4); aus.sirene=true; }
  if(RD.ansage){ const texte=alarme.map(m=>m.ansage).filter(Boolean); aus.ansagen=texte.length;
   if(texte.length) setTimeout(()=>rdSprich(texte), aus.sirene?4200:0); } }
 else if(hinweise.length&&rdTonAn()) aus.ton=rdTonHinweis();
 RD.gesehen=neu[neu.length-1].id; try{ localStorage.setItem('hl_radar_gesehen', String(RD.gesehen)); }catch(e){}
 return aus; }
async function rdMeldLaden(){ if(!(rdTonAn()||RD.ansage)||RD.laeuft) return;
 try{ const d=await getJSON('/cockpit/radar/meldungen'); if(d&&d.ok!==false) rdMelden(d.meldungen, d.meldung_alt_s); }catch(e){} }

async function rdLaden(erzwungen){
 if(!$('ckbody')||RD.laeuft) return;
 if(!erzwungen&&!ckOffen()) return;
 const coin=ckCoin();
 if(!erzwungen&&RD.d&&RD.coin===coin&&Date.now()-RD.geladen<55000) return;
 RD.laeuft=true;
 try{ const d=await getJSON('/cockpit/radar?coin='+encodeURIComponent(coin)); if(RD.coin!==coin) RD.achse=null; RD.d=d; RD.coin=coin; RD.fehler=null; RD.geladen=Date.now(); }
 catch(e){ RD.fehler=String(e&&e.message||e); }
 RD.laeuft=false;
 if(RD.d&&RD.d.ok!==false&&!RD.fehler) rdMelden(RD.d.meldungen, (RD.d.beleg||{}).meldung_alt_s);
 if(typeof ckZeichne==='function') ckZeichne(); }
function rdAchse(k){ RD.achse=(RD.achse===k?null:k); if(typeof ckZeichne==='function') ckZeichne(); }
async function rdSetze(q){ if(RD.sendet) return; RD.sendet=true; RD.hinweis=null;
 try{ const r=await fetch('/cockpit/radar/einstellung?'+Object.keys(q).map(k=>k+'='+encodeURIComponent(q[k])).join('&'),{method:'POST',headers:{'X-HL-Request':'1'}});
  const j=await r.json(); if(j&&j.ok){ if(RD.d) RD.d.einstellung=j.einstellung; } else RD.hinweis='Nicht gespeichert: '+((j&&(j.msg||j.error))||'ohne Angabe'); }
 catch(e){ RD.hinweis='Nicht gespeichert: '+String(e&&e.message||e); }
 RD.sendet=false; RD.meldOffen=true; await rdLaden(true); }
function rdCoinSchalter(c){ const e=(RD.d&&RD.d.einstellung)||{coins:[]}; const s=new Set(e.coins||[]); if(s.has(c)) s.delete(c); else s.add(c);
 rdSetze({coins:RD_COINS.filter(x=>s.has(x)).join(',')||'-'}); }
function rdAnsageSchalter(){ RD.ansage=!RD.ansage; try{ localStorage.setItem('hl_radar_ansage', RD.ansage?'1':'0'); }catch(e){}
 if(RD.ansage) rdSprich('Risikoradar. Die Ansage ist an.'); RD.meldOffen=true; if(typeof ckZeichne==='function') ckZeichne(); }
function rdTonSchalter(){ if(typeof tonSchalter==='function') tonSchalter(); RD.meldOffen=true; if(typeof ckZeichne==='function') ckZeichne(); }
function rdProbe(art){ if(art==='ton'){ if(typeof tonSirene==='function') tonSirene(2); } else rdSprich('Risikoradar. Probe der Ansage.'); }

// ---------- Zeichnung ----------
function rdStufeForm(st, gr){ return ckForm(st==='hoch'?'warnung':st==='erhoeht'?'hinweis':st==='normal'?'aus':'grau','A',gr); }
function rdZahl(e, gross){ if(!e) return '';
 const stand=e.p==null?'':(e.besteht===true?(e.stufe==='ohne'?'ohne Stufe':`Stufe <b>${esc(e.stufe_wort||'')}</b>`):(e.besteht===false?'im Rückblick nicht bestätigt':'noch nicht geprüft'));
 const was=e.x!=null?`−${esc(e.x_text||'')} in ${esc(e.frist||'')}`:esc(e.frist||'');
 const zeile2=[e.grundrate_text?'üblich '+esc(e.grundrate_text):'', stand].filter(Boolean).join(' · ');
 return `<div class="rdzahl${gross?' rdgross':''}${e.besteht!==true||e.p==null?' rdmatt':''}" title="${esc(e.satz||'')}">${rdStufeForm(e.stufe, gross?28:18)}`
  +`<span class="rdp">${esc(e.p!=null?e.p_text:'—')}</span><span class="rdwas"><b>${was}</b>${e.kurs_schwelle?' · bei '+esc(ckPx(e.kurs_schwelle)):''}`
  +(zeile2?`<br>${zeile2}`:'')+(e.kal?`<br><span class="rdkal">nachkalibriert${e.p_roh_text?' · roh '+esc(e.p_roh_text):''}</span>`:'')+`</span></div>`
  +(e.schwellen?`<div class="ckleise">Stufen: ${esc(e.schwellen)}</div>`:'')
  +(e.fehlt?`<div class="ckfehlt">${esc(e.fehlt)}</div>`:'')+(e.niveau?`<div class="ckleise">${esc(e.niveau)}</div>`:''); }
function rdNetz(A){ const n=A.length; if(n<3) return ''; const bw=340, bh=250, cx=170, cy=125, R=82;
 const pkt=(i,w)=>{ const a=-Math.PI/2+i*2*Math.PI/n, r=R*w/100; return [cx+r*Math.cos(a), cy+r*Math.sin(a)]; };
 const pts=l=>l.map(p=>p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');
 const da=A.map((a,i)=>[a,i]).filter(z=>z[0].wert!=null);
 let s=`<svg class="rdsvg" viewBox="0 0 ${bw} ${bh}" role="img" aria-label="Risikoradar: ${n} Achsen von 0 bis 100, höher heißt mehr Druck; ${da.length} mit Wert. Die Liste darunter nennt die Werte.">`;
 [25,50,75,100].forEach(w=>{ s+=`<polygon points="${pts(A.map((_,i)=>pkt(i,w)))}" fill="none" stroke="${CK_F.spur}" stroke-width="1"/>`; });
 A.forEach((a,i)=>{ const p=pkt(i,100); s+=`<line x1="${cx}" y1="${cy}" x2="${p[0].toFixed(1)}" y2="${p[1].toFixed(1)}" stroke="${a.wert==null?CK_F.grau:CK_F.spur}" stroke-width="1"${a.wert==null?' stroke-dasharray="3 3"':''}/>`; });
 if(da.length>=3) s+=`<polygon class="rdflaeche" points="${pts(da.map(z=>pkt(z[1],z[0].wert)))}" fill="${CK_F.info}" fill-opacity="0.18" stroke="none"/>`;
 if(da.length>=2) da.forEach((z,k)=>{ if(da.length===2&&k===1) return; const y=da[(k+1)%da.length], p=pkt(z[1],z[0].wert), q=pkt(y[1],y[0].wert), direkt=((y[1]-z[1]+n)%n)===1;
  s+=`<line class="rdkante${direkt?'':' rdluecke'}" x1="${p[0].toFixed(1)}" y1="${p[1].toFixed(1)}" x2="${q[0].toFixed(1)}" y2="${q[1].toFixed(1)}" stroke="${CK_F.info}" stroke-width="2" stroke-linecap="round"${direkt?'':' stroke-dasharray="4 4"'}/>`; });
 da.forEach(z=>{ const p=pkt(z[1],z[0].wert); s+=`<circle class="rdpunkt" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="4.5" fill="${CK_F.info}" stroke="#161b22" stroke-width="2"/>`; });
 A.forEach((a,i)=>{ const p=pkt(i,118), ank=Math.abs(p[0]-cx)<10?'middle':(p[0]>cx?'start':'end'), dy=Math.abs(p[1]-cy)<10?4:(p[1]>cy?11:0);
  s+=`<text x="${p[0].toFixed(1)}" y="${(p[1]+dy).toFixed(1)}" text-anchor="${ank}" class="rdlab${a.wert==null?' rdlgrau':''}${RD.achse===a.key?' rdlan':''}" onclick="rdAchse('${esc(a.key)}')">`
   +`${esc(a.kurz||a.name)}${a.wert!=null?' '+esc(ckZ(a.wert,0)):' –'}</text>`; });
 return s+`</svg>`; }
function rdListe(A){ return `<div class="rdliste" role="list" aria-label="Achsen als Liste">`+A.map(a=>
  `<button type="button" role="listitem" class="rdrow${RD.achse===a.key?' an':''}${a.wert==null?' rdohne':''}" onclick="rdAchse('${esc(a.key)}')" aria-expanded="${RD.achse===a.key}" title="${esc(a.leit||'')}">`
  +`<span class="rdn">${esc(a.name)}${a.index?'<i title="Achse des Druck-Index"> ●</i>':''}</span><span class="rdbar" aria-hidden="true"><i style="width:${a.wert!=null?Math.max(0,Math.min(100,a.wert)):0}%"></i></span>`
  +`<span class="rdw">${a.wert!=null?esc(ckZ(a.wert,0)):'—'}</span></button>`).join('')+`</div>`; }
function rdDetail(A){ const a=A.find(x=>x.key===RD.achse);
 if(!a) return `<div class="ckleise">Werte von 0 bis 100: höher heißt mehr Druck. <i class="rdim">●</i> Achse des Druck-Index. „—“ und gestrichelt: kein Wert. Antippen zeigt Leitgröße und Stand.</div>`;
 return `<div class="ckdetail"><b>${esc(a.name)}: ${a.wert!=null?esc(ckZ(a.wert,0))+' von 100':'kein Wert'}.</b> ${esc(a.leit||'')}`
  +(a.wert!=null&&a.vergleich?` · ${esc(a.vergleich)}`:'')+(a.stand?` · Stand ${esc(a.stand)}`:'')+(a.grau?`<div class="ckfehlt">${esc(a.grau)}</div>`:'')
  +`<div class="ckbeleg">${a.index?(a.wert!=null?'Zählt im Druck-Index. ':'Achse des Druck-Index; fehlt dort, solange sie grau ist. '):'Zählt nicht im Druck-Index. '}Gemessen, keine Vorhersage.</div></div>`; }
function rdAlle(d){ const L=d.alle||[]; if(!L.length) return '';
 return `<div class="rdalle" role="group" aria-label="Stufe der 7-Tage-Zahl je Coin"><span class="ckleise">Stufe je Coin (7 Tage):</span>`+L.map(e=>
  `<button type="button" class="rdcoin${e.coin===d.coin?' an':''}" onclick="ckWaehle('${esc(e.coin)}')" title="${esc(e.coin)}: ${esc(e.p_text)} · ${esc(e.stufe_wort)}${e.ts?' · Stand '+esc(ckZeit(e.ts)):''}">`
  +rdStufeForm(e.stufe,12)+`<b>${esc(e.coin)}</b><span>${esc(e.p_text)}</span></button>`).join('')+`</div>`; }
function rdMeldungen(d){ const e=d.einstellung||{coins:[],push:true,pz:0.95}, M=d.meldungen||[], kann=rdSprechenKann(), ton=rdTonAn();
 const tog=(an,text,klick,titel)=>`<button type="button" class="tog ${an?'on':'off'}" onclick="${klick}" title="${esc(titel||'')}" aria-pressed="${an?'true':'false'}"${RD.sendet?' disabled':''}>${esc(text)}</button>`;
 let h=`<details class="rdmeld"${RD.meldOffen?' open':''} ontoggle="RD.meldOffen=this.open"><summary>Meldungen: Push ${e.push?'an':'aus'} · Ton ${ton?'an':'aus'} · Ansage ${RD.ansage?'an':'aus'} · ${esc((e.coins||[]).join(', ')||'kein Coin')}</summary>`;
 h+=`<div class="rdschalter">`+tog(e.push,'Push '+(e.push?'an':'aus'),`rdSetze({push:${e.push?0:1}})`,'Push aufs Handy: kommt auch bei geschlossenem Dashboard')
  +tog(ton,'Ton '+(ton?'an':'aus'),'rdTonSchalter()','Sirene im Dashboard -- derselbe Schalter wie „Töne“ der Seite')
  +tog(RD.ansage,'Ansage '+(RD.ansage?'an':'aus'),'rdAnsageSchalter()','Der Browser spricht den Satz des Alarms')+`</div>`;
 h+=`<div class="rdschalter"><span class="ckleise">Probe:</span><button type="button" class="tog off" onclick="rdProbe('ton')">Ton</button>`
  +`<button type="button" class="tog off" onclick="rdProbe('ansage')"${kann?'':' disabled'}>Ansage</button></div>`;
 if(e.push&&!d.push_eingerichtet) h+=`<div class="ckfehlt">Push ist an, aber die Benachrichtigung aufs Handy ist nicht eingerichtet (Betrieb → Debug → Berichtsplan → „Einrichten“).</div>`;
 if(!kann) h+=`<div class="ckfehlt">Dieser Browser kann nicht sprechen -- die Ansage bleibt stumm. Ton und Push gehen weiter.</div>`;
 h+=`<div class="ckleise">Ton und Ansage gibt es nur, solange diese Seite offen ist und einmal angetippt wurde. Der Push braucht die Seite nicht.</div>`;
 h+=`<div class="rdschalter"><span class="ckleise">Coins:</span>`+RD_COINS.map(c=>tog((e.coins||[]).includes(c),c,`rdCoinSchalter('${c}')`,'Meldungen für '+c)).join('')+`</div>`;
 h+=`<div class="rdschalter"><span class="ckleise">„Hoch“ = die riskantesten</span>`+(d.pz_wahl||[]).map(w=>tog(Math.abs(w.pz-e.pz)<1e-9,w.kurz||w.text,`rdSetze({pz:${+w.pz}})`,w.text)).join('')
  +`<span class="ckleise">der Tage</span></div>`;
 if(RD.hinweis) h+=`<div class="ckfehlt">${esc(RD.hinweis)}</div>`;
 h+=`<div class="ckleise">Alarm beim Eintritt in „hoch“ (endet erst unter 0,8 · Schwelle), höchstens einer in 12 Stunden je Coin und Zahl. Takt: `
  +`${d.takt&&d.takt.ts?(d.takt.laeuft?'läuft, zuletzt ':'steht seit ')+esc(ckZeit(d.takt.ts)):'noch kein Schritt'}.</div>`;
 h+=M.length?`<div class="rdmliste">`+M.map(m=>`<div class="rdm"><b>${esc(ckZeit(m.ts))} · ${esc(m.titel||'')}</b> <span class="ckleise">${esc(m.push||'')}</span><div>${esc(m.text||'')}</div></div>`).join('')+`</div>`
  :`<div class="ckleise">Noch keine Meldung.</div>`;
 return h+`</details>`; }
function rdBeleg(r){ const E=r.ereignis||{}, B=r.beleg||{};
 return `<details class="rdmeld"${RD.belegOffen?' open':''} ontoggle="RD.belegOffen=this.open"><summary>Beleg</summary>`
  +[(E.e7||{}).urteil, (E.e2||{}).urteil, B.kal, B.zahl, B.achsen, r.regeln_satz].filter(Boolean).map(t=>`<div class="ckbeleg">${esc(t)}</div>`).join('')+`</details>`; }
function rdKarte(d){ rdCss(); const r=RD.d, kopf=st=>`<div class="ckt">Risikoradar<span class="cktn">${st||''}</span></div>`;
 if(!r||RD.coin!==(d&&d.coin)) return `<div class="ckk" id="rdkarte">${kopf('')}<div class="ckleise">${RD.fehler?'Risikoradar nicht erreichbar: '+esc(RD.fehler):'lädt …'}</div></div>`;
 if(r.ok===false) return `<div class="ckk ckgrau" id="rdkarte">${kopf('')}<div class="ckfehlt">${(r.fehlt||['Risikoradar: keine Daten']).map(esc).join(' ')}</div></div>`;
 const E=r.ereignis||{}, A=r.achsen||[], I=r.index||{}, W=r.warnzeichen||{}, B=r.beleg||{};
 return `<div class="ckk" id="rdkarte">`+kopf('Stand '+esc(ckZeit(r.jetzt)))
  +(RD.fehler?`<div class="ckfehlt">Die letzte Abfrage ist gescheitert (${esc(RD.fehler)}) -- gezeigt wird der Stand von ${esc(ckZeit(r.jetzt))}.</div>`:'')
  +rdZahl(E.e7,true)+rdZahl(E.e2,false)+(r.trend?`<div class="ckfehlt">${esc(r.trend)}</div>`:'')
  +`<div class="rdnetz">`+rdNetz(A)+`</div>`+rdListe(A)+rdDetail(A)
  +`<div class="rdzeile">${esc(I.text||'')}</div><div class="rdzeile">${esc(r.treiber||'')}</div>`
  +`<div class="rdzeile">${W.aktiv?ckForm('hinweis','A',12)+' ':''}${esc(W.text||'')}${W.aktiv?`<div class="ckbeleg">${esc(W.beleg||'')}</div>`:''}</div>`
  +rdAlle(r)+rdMeldungen(r)+rdBeleg(r)
  +`<div class="ckbeleg">${esc(B.grenzen||'')}</div></div>`; }
function rdCss(){ if($('rd_css')) return; const st=document.createElement('style'); st.id='rd_css'; st.textContent=`
#sec-cockpit .rdzahl{display:flex;align-items:center;gap:10px}
#sec-cockpit .rdzahl svg{flex:none}
#sec-cockpit .rdzahl .rdp{font-size:18px;font-weight:700;color:#e6edf3;min-width:58px;font-variant-numeric:tabular-nums;white-space:nowrap}
#sec-cockpit .rdzahl.rdgross .rdp{font-size:32px;line-height:1.05;min-width:92px}
#sec-cockpit .rdzahl.rdmatt .rdp{color:#9da7b3}
#sec-cockpit .rdzahl .rdwas{color:#9da7b3;font-size:12px;line-height:1.4;min-width:0}
#sec-cockpit .rdzahl .rdwas b{color:#e6edf3;font-weight:600}
#sec-cockpit .rdzahl .rdkal{color:#9da7b3}
#sec-cockpit .rdnetz{width:100%;max-width:360px;margin:0 auto}
#sec-cockpit .rdsvg{width:100%;height:auto;display:block}
#sec-cockpit .rdlab{font-size:11px;fill:#e6edf3;cursor:pointer}
#sec-cockpit .rdlab.rdlgrau{fill:#9da7b3}
#sec-cockpit .rdlab.rdlan{font-weight:700;text-decoration:underline}
#sec-cockpit .rdliste{display:grid;gap:2px}
#sec-cockpit .rdrow{display:grid;grid-template-columns:minmax(118px,40%) 1fr 30px;align-items:center;gap:8px;background:none;border:1px solid transparent;border-radius:8px;padding:4px 6px;color:#e6edf3;font:inherit;font-size:12px;text-align:left;cursor:pointer;min-height:32px}
#sec-cockpit .rdrow.an{border-color:#30363d;background:#0d1117}
#sec-cockpit .rdrow.rdohne{color:#9da7b3}
#sec-cockpit .rdrow .rdn i,#sec-cockpit .rdim{font-style:normal;color:#58a6ff;font-size:9px}
#sec-cockpit .rdrow .rdbar{height:8px;background:#30363d;border-radius:4px;overflow:hidden}
#sec-cockpit .rdrow .rdbar i{display:block;height:100%;background:#58a6ff;border-radius:0 4px 4px 0}
#sec-cockpit .rdrow .rdw{text-align:right;font-variant-numeric:tabular-nums}
#sec-cockpit .rdzeile{font-size:12px;color:#e6edf3}
#sec-cockpit .rdalle{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
#sec-cockpit .rdcoin{display:inline-flex;align-items:center;gap:5px;background:#0d1117;border:1px solid #30363d;border-radius:16px;padding:0 10px;color:#e6edf3;font:inherit;font-size:12px;cursor:pointer;min-height:32px}
#sec-cockpit .rdcoin.an{border-color:#58a6ff}
#sec-cockpit .rdcoin span{color:#9da7b3;font-variant-numeric:tabular-nums}
#sec-cockpit .rdmeld{border-top:1px solid #30363d;padding-top:8px}
#sec-cockpit .rdmeld summary{cursor:pointer;font-size:12px;color:#e6edf3;min-height:28px}
#sec-cockpit .rdmeld>div{margin-top:8px}
#sec-cockpit .rdschalter{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
#sec-cockpit .rdschalter .tog{min-height:32px;min-width:44px;padding:4px 10px}
#sec-cockpit .rdmliste{display:grid;gap:8px}
#sec-cockpit .rdm{font-size:12px;color:#c9d1d9;border-left:2px solid #30363d;padding-left:8px}
#sec-cockpit .rdm b{color:#e6edf3;font-weight:600}
`; document.head.appendChild(st); }
function rdStart(){ setInterval(rdMeldLaden, 60000); }
rdStart();
"""
