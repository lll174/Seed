"""
hl_volatil_js.py -- Skript des Abschnitts „VL Volatilität“ im Dashboard (U237, 23.90), ausgeliefert unter /volatil.js.

Eigene Datei wie hl_prognosemarkt_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf
den Helfern der Seite auf ($, getJSON, esc, hideTip) und muss deshalb NACH dem Hauptskript geladen werden.

Chart je Coin: Volatilitätsindex (realisierte Schwankung 30 und 7 Tage in % p. a., DVOL für BTC und ETH) mit dem Kurs auf einer
ZWEITEN Achse in derselben Fläche -- Entscheidung des Nutzers vom 28.10.2026, bewusst abweichend von der Kursleiste aus U132; der
Fuß sagt deshalb, dass Gleichlauf der Linien nichts bedeutet. Rechts von „heute“ die Prognose für vier Wochen (KONZEPT_Volatilitaet.md
mit Nachtrag 13.4): je Woche das erwartete Wochenmittel als Stufe (Fortsetzung von VI7) mit Bändern 50 % und 90 %, der Tagespfad
dünner (nur das Wochenmittel ist geprüft), die Schwelle einer volatilen Woche und je Woche deren Wahrscheinlichkeit neben der
Grundrate. Ab 12 Monaten Zeitraum im Chart nur „heute“ und die Wochenstufen, Einzelheiten in der Tabelle. Schwankung, nicht Richtung:
keine Kauf- oder Verkaufswörter; Farben nur für Reihen und Zustände.
"""

VOLATIL_JS = r"""// 23.90 Volatilität (U237): Index und Prognose der Schwankung -- nicht der Richtung. Daten: /volatil?tab=..&coin=.. (hl_volatil.py,
// eigene volatil.db). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist (höchstens einmal je Minute; Server 60 s).
// Zwei Achsen in einer Fläche auf Wunsch des Nutzers (28.10.2026): links Schwankung in % p. a., rechts Kurs (log).
const VOLA={tab:'chart', coin:'BTC', bereich:'12m', kurs:true, vi7:true, dvol:true, phasen:true, tabelle:false, cache:{}, laeuft:{}, d:null};
try{ const s_=JSON.parse(localStorage.getItem('hl_vl')||'{}');
 ['tab','coin','bereich'].forEach(k=>{ if(typeof s_[k]==='string') VOLA[k]=s_[k]; });
 ['kurs','vi7','dvol','phasen'].forEach(k=>{ if(typeof s_[k]==='boolean') VOLA[k]=s_[k]; }); }catch(e){}
const VL_TABS=[['chart','Chart'],['bilanz','Bilanz'],['daten','Daten']];
const VL_COINS=['BTC','ETH','ZEC','HYPE','XMR'];
const VL_BEREICH=[['2w','2 W',14],['8w','8 W',56],['6m','6 M',183],['12m','12 M',365],['4j','4 J',1461],['5j','5 J',1826]];
if(!VL_TABS.some(t=>t[0]===VOLA.tab)) VOLA.tab='chart';
if(!VL_COINS.includes(VOLA.coin)) VOLA.coin='BTC';
if(!VL_BEREICH.some(b=>b[0]===VOLA.bereich)) VOLA.bereich='12m';
function vlMerken(){ try{ localStorage.setItem('hl_vl', JSON.stringify({tab:VOLA.tab, coin:VOLA.coin, bereich:VOLA.bereich, kurs:VOLA.kurs,
 vi7:VOLA.vi7, dvol:VOLA.dvol, phasen:VOLA.phasen})); }catch(e){} }
// Farben aus der Palette des Makro-Charts (für die dunkle Fläche #01030a geprüft): Index blau, DVOL grün, Kurs grau (1 px, unter den
// Schwankungslinien), Phasen bernstein mit geringer Deckkraft -- kein Rot/Grün für Zustände; Zustände tragen immer auch ein Wort.
const VL_F={vi:'#3987e5', dvol:'#199e70', kurs:'#c9d1d9', phase:'#c98500', prog:'#3987e5', schwelle:'#c98500'};
const VL_GRID='#161b22', VL_REF='#30363d', VL_MUTED='#8b949e', VL_FLAECHE='#01030a', VL_TEXT='#e6edf3';
const VL_TERMIN={cpi:['I','Inflation USA (CPI)'], jobs:['A','Arbeitsmarktbericht USA'], fed:['F','Fed-Entscheid'],
 verfall_m:['V','Optionsverfall Deribit (Monat)'], verfall_q:['Q','Optionsverfall Deribit (Quartal)']};

// ---------- Zahlen und Zeiten (Dezimalkomma; Tage als UTC-Tage seit 1970) ----------
function vlZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}).replace('-','−'); }
function vlPa(x){ return x==null||!isFinite(x)?'—':vlZ(x,x>=100?0:1)+' %'; }
function vlPr(p){ return p==null||!isFinite(p)?'—':vlZ(Math.min(99,Math.max(1,Math.round(p*100))),0)+' %'; }
function vlSigmaTag(pa){ return pa==null||!isFinite(pa)?'—':vlZ(pa/Math.sqrt(365),2)+' %'; }
function vlUsd(v){ if(v==null||!isFinite(v)) return '—'; const a=Math.abs(v); return vlZ(v, a>=1000?0:a>=10?2:4)+' $'; }
function vlDatum(tag){ return new Date(tag*864e5).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'}); }
function vlKurzDatum(tag){ return new Date(tag*864e5).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'}); }
const VL_MON=['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
function vlMonat(tag){ const d=new Date(tag*864e5); return VL_MON[d.getUTCMonth()]+' '+String(d.getUTCFullYear()).slice(2); }
function vlUhr(ts){ if(!ts) return '—'; const d=new Date(ts*1000), z=n=>String(n).padStart(2,'0');      // wie die Texte des Servers: UTC
 return z(d.getUTCDate())+'.'+z(d.getUTCMonth()+1)+'.'+d.getUTCFullYear()+' '+z(d.getUTCHours())+':'+z(d.getUTCMinutes())+' UTC'; }
function vlLeer(t){ return `<div class="vlleer">${t}</div>`; }
function vlWert(r,tag){ if(!r||!r.v) return null; const i=tag-r.t0; return i>=0&&i<r.v.length?r.v[i]:null; }

// ---------- Laden, Reiter, Leiste ----------
function vlOffen(){ const p=$('sec-volatil'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function vlLeiste(){ const el=$('vlbar'); if(!el) return;
 const chart=VOLA.tab==='chart';
 el.innerHTML=`<div id="vltabs" class="vlzeile">${VL_TABS.map(([k,n])=>`<button class="tog ${k===VOLA.tab?'on':'off'}" onclick="vlTab('${k}')">${n}</button>`).join('')}`
  +`<span id="vlstand" class="sub vlstand"></span></div>`
  +(chart?`<div class="vlzeile"><span class="lbl">Coin</span>${VL_COINS.map(c=>`<button class="tog ${c===VOLA.coin?'on':'off'}" onclick="vlCoin('${c}')">${c}</button>`).join('')}</div>`
  +`<div class="vlzeile"><span class="lbl">Zeitraum</span>${VL_BEREICH.map(([k,n])=>`<button class="tog ${k===VOLA.bereich?'on':'off'}" onclick="vlBereich('${k}')">${n}</button>`).join('')}`
  +`<span class="lbl vlabstand">Zeigen</span>${[['kurs','Kurs'],['vi7','7 Tage'],['dvol','DVOL'],['phasen','Phasen']].map(([k,n])=>`<button class="tog ${VOLA[k]?'on':'off'}" onclick="vlUm('${k}')">${n}</button>`).join('')}</div>`:''); }
function vlTab(k){ if(!VL_TABS.some(t=>t[0]===k)) return; VOLA.tab=k; vlMerken(); vlLeiste(); vlLaden(false); }
function vlCoin(c){ if(!VL_COINS.includes(c)) return; VOLA.coin=c; vlMerken(); vlLeiste(); vlLaden(false); }
function vlBereich(k){ if(!VL_BEREICH.some(b=>b[0]===k)) return; VOLA.bereich=k; vlMerken(); vlLeiste(); if(VOLA.d) vlZeigen(VOLA.d); }
function vlUm(k){ VOLA[k]=!VOLA[k]; vlMerken(); vlLeiste(); if(VOLA.d) vlZeigen(VOLA.d); }
function vlSchluessel(){ return VOLA.tab==='chart'?'chart|'+VOLA.coin:VOLA.tab; }
async function vlLaden(zwang){ if(!vlOffen()) return; const el=$('vlbody'); if(!el) return; vlCss();
 if(!$('vltabs')) vlLeiste();
 const k=vlSchluessel(), c=VOLA.cache[k];
 if(c&&!zwang&&Date.now()-c.zeit<55000){ vlZeigen(c.d); return; }
 if(VOLA.laeuft[k]) return; VOLA.laeuft[k]=true; el.style.opacity=c?'0.55':'1';
 try{ const d=await getJSON('/volatil?tab='+VOLA.tab+(VOLA.tab==='chart'?'&coin='+VOLA.coin:'')); VOLA.cache[k]={d, zeit:Date.now()}; if(vlSchluessel()===k) vlZeigen(d); }
 catch(e){ if(!c&&vlSchluessel()===k) el.innerHTML='<div class="sub">Volatilität nicht erreichbar.</div>'; }
 finally{ VOLA.laeuft[k]=false; el.style.opacity='1'; } }
function vlZeigen(d){ const el=$('vlbody'); if(!el) return; VOLA.d=d;
 const st=$('vlstand'); if(st) st.textContent=d&&d.stand?'Stand '+vlUhr(d.stand)+' · Tage in UTC':'';
 if(!d||!d.ok){ el.innerHTML=vlLeer(((d&&d.fehlt)||['keine Daten']).map(x=>esc(x)).join('<br>'))
   +'<div class="sub">Debug „Volatilität: Stand“ zeigt Erstlauf, Daten und Fehler.</div>'; return; }
 const f={chart:vlChart, bilanz:vlBilanz, daten:vlDaten}[d.tab]||vlDaten;
 el.innerHTML=vlKopf(d)+f(d)+vlFuss(d);
 if(d.tab==='chart') vlZeichne(); }
function vlKopf(d){ const z=(d.kopf&&d.kopf.length)?d.kopf:[d.hinweis||'Schwankung, nicht Richtung.'];
 return `<div class="vlhinweis">${z.map((t,i)=>(i===0?'⚠ ':'')+esc(t)).join('<br>')}</div>`; }
function vlFuss(d){ const t=[d.quelle?'Quelle: '+esc(d.quelle):'', d.auswertung?esc(d.auswertung):''].filter(Boolean); return t.length?`<div class="vlquelle">${t.join(' · ')}</div>`:''; }

// ---------- Chart ----------
function vlGross(){ return vlBereichTage()>=365; }
function vlChart(d){ const p=d.prognose||null;
 const leg=[[VL_F.vi,'VI30 (links)',''], VOLA.vi7?[VL_F.vi,'VI7 (links)','3,2']:null, VOLA.dvol&&d.dvol?[VL_F.dvol,'DVOL (links, 30 T voraus)','6,4']:null,
  VOLA.kurs?[VL_F.kurs,'Kurs (rechts, log)','']:null, p?[VL_F.prog,'Wochenmittel 50 % / 90 %','band']:null,
  p&&!vlGross()?[VL_F.prog,'Tageswerte = Wochenprognose × Kalendermuster (nur das Wochenmittel ist geprüft)','1,3']:null,
  p&&!vlGross()?[VL_F.schwelle,'Schwelle volatil (80. Perzentil der letzten 365 Tage)','4,3']:null,
  VOLA.phasen?[VL_F.phase,'volatile Phase (realisiert, Schwelle des jeweiligen Vorjahrs)','zone']:null].filter(Boolean);
 const legende=`<div class="leg vlleg">${leg.map(([c,n,s])=>s==='band'||s==='zone'
   ?`<span><span class="sw" style="background:${c};opacity:${s==='zone'?0.4:0.35}"></span>${esc(n)}</span>`
   :`<span><svg width="18" height="8" style="vertical-align:middle;margin-right:4px"><line x1="0" y1="4" x2="18" y2="4" stroke="${c}" stroke-width="${n.startsWith('VI30')?2.4:1.4}"${s?` stroke-dasharray="${s}"`:''}/></svg>${esc(n)}</span>`).join('')}</div>`;
 const kopf=`<div class="vlkopf"><b>${esc(VOLA.coin)}: Volatilitätsindex und Kurs</b> <span class="sub">${p?'Prognose ab '+vlDatum(p.ursprung)+' (Stand 00:00 UTC, UTC-Tage) · '+esc(p.modell_text||p.modell)+(p.ungeprueft?' · ungeprüft':'')+(p.nicht_im_urteil?' · nicht im Urteil':''):'noch keine Prognose'}</span>`
  +`<button class="vltab" onclick="vlTabelleUm()">${VOLA.tabelle?'Chart':'Tabelle'}</button></div>`;
 return kopf+legende+`<div id="vlplot" class="vlplot"></div><div id="vlplottab"></div>`
  +`<div class="vlquelle">Zwei Achsen: links Schwankung in % p. a., rechts Kurs (log). Gleichlauf der Linien sagt nichts – die Skalen sind frei gewählt.<br>`
  +`Schwankung in beide Richtungen; Flächen und Wahrscheinlichkeiten sagen nichts über die Richtung.<br>`
  +`DVOL schaut 30 Tage voraus und liegt im Mittel über der späteren Schwankung (Varianzprämie); VI30 schaut 30 Tage zurück.</div>`
  +vlWochen(d); }
function vlTabelleUm(){ VOLA.tabelle=!VOLA.tabelle; if(VOLA.d) vlZeigen(VOLA.d); }
function vlBereichTage(){ const b=VL_BEREICH.find(x=>x[0]===VOLA.bereich)||VL_BEREICH[3]; return b[2]; }
function vlPerz(werte,q){ const a=werte.filter(v=>v!=null&&isFinite(v)).sort((x,y)=>x-y); if(!a.length) return null; return a[Math.min(a.length-1,Math.floor(q*(a.length-1)))]; }
function vlZeichne(){ const d=VOLA.d, el=$('vlplot'), tabEl=$('vlplottab'); if(!d||!el||d.tab!=='chart') return;
 const r=d.reihe||{}, p=d.prognose||null, gross=vlGross();
 if(!r.vi30||!r.vi30.length){ el.innerHTML=vlLeer('Noch keine Tageswerte für '+esc(VOLA.coin)+'.'); return; }
 const letzter=r.t0+r.vi30.length-1, heute=p?p.ursprung:letzter+1, zukunft=p&&p.wochen?28:0;
 const x1=heute-1+zukunft, x0=Math.max(r.t0, heute-vlBereichTage());
 const vi30={t0:r.t0, v:r.vi30}, vi7={t0:r.t0, v:r.vi7||[]}, dvol=d.dvol&&r.dvol?{t0:r.t0, v:r.dvol}:null, kurs={t0:r.t0, v:r.kurs||[]};
 if(VOLA.tabelle){ el.innerHTML=''; if(tabEl) tabEl.innerHTML=vlTabelleHtml(d,x0,heute-1); return; }
 if(tabEl) tabEl.innerHTML='';
 const W=Math.max(260,(el.clientWidth||640)-2), eng=W<520, H=eng?270:320, L=eng?34:46, R=eng?54:64, T=30, B=22, pw=W-L-R, ph=H-T-B;   // −2: Rahmen 1 px je Seite
 const X=t=>L+(t-x0)/Math.max(1,x1+1-x0)*pw;
 // linke Achse: aus VI30, DVOL und den Bändern; VI7 bis zu seinem 99. Perzentil (Spitzen darüber abgeschnitten und markiert)
 let hi=0; const nimm=v=>{ if(v!=null&&isFinite(v)&&v>hi) hi=v; };
 const sicht7=[];
 for(let t=x0;t<heute;t++){ nimm(vlWert(vi30,t)); if(VOLA.dvol&&dvol) nimm(vlWert(dvol,t)); if(VOLA.vi7) sicht7.push(vlWert(vi7,t)); }
 if(VOLA.vi7){ const p99=vlPerz(sicht7,0.99); if(p99!=null) nimm(p99); }
 if(p&&p.wochen) p.wochen.forEach(w=>{ nimm(w.mitte); if(!gross){ nimm(w.hi50); nimm(Math.min(w.hi90||0, 1.6*Math.max(hi,w.hi50||0))); } });
 if(p&&p.pfad&&!gross) p.pfad.forEach(nimm);
 if(p&&!gross) nimm(p.schwelle);                    // die Schwelle einer volatilen Woche bleibt bis 6 M immer im Bild
 if(!(hi>0)){ el.innerHTML=vlLeer('Keine Werte im gewählten Zeitraum.'); return; }
 hi*=1.08; const Y=v=>T+(hi-Math.max(0,Math.min(hi,v)))/hi*ph;
 let klo=Infinity, khi=-Infinity; if(VOLA.kurs) for(let t=x0;t<heute;t++){ const v=vlWert(kurs,t); if(v!=null&&v>0){ if(v<klo) klo=v; if(v>khi) khi=v; } }
 const mitKurs=VOLA.kurs&&isFinite(klo); let Y2=null;
 if(mitKurs){ if(khi===klo){ khi*=1.1; klo/=1.1; } const a=Math.log(klo), b=Math.log(khi), pad=(b-a)*0.08; Y2=v=>T+(b+pad-Math.log(v))/((b-a)+2*pad)*ph; }
 let s=`<svg width="${W}" height="${H}" style="display:block;background:${VL_FLAECHE};border:1px solid #21262d;border-radius:6px">`;
 if(zukunft) s+=`<rect x="${X(heute).toFixed(1)}" y="${T}" width="${(X(x1+1)-X(heute)).toFixed(1)}" height="${ph}" fill="#0d1117"/>`;
 if(VOLA.phasen) (d.zonen||[]).forEach(([a,b])=>{ const a2=Math.max(x0,a), b2=Math.min(heute-1,b); if(b2<a2) return;
  s+=`<rect x="${X(a2).toFixed(1)}" y="${T}" width="${Math.max(1,X(b2+1)-X(a2)).toFixed(1)}" height="${ph}" fill="${VL_F.phase}" opacity="0.13"/>`; });
 vlSchritte(0,hi,5).forEach(v=>{ const y=Y(v).toFixed(1); s+=`<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" stroke="${VL_GRID}"/><text x="${L-4}" y="${(+y+3).toFixed(1)}" fill="${VL_MUTED}" font-size="10" text-anchor="end">${vlZ(v,0)}</text>`; });
 if(mitKurs){ let kt=vlLogSchritte(Math.exp(Math.log(klo)-0.02),Math.exp(Math.log(khi)+0.02)); if(kt.length>4){ const k=Math.ceil(kt.length/4); kt=kt.filter((_,i)=>i%k===0); }
  kt.forEach(v=>{ const y=Y2(v); if(y<T||y>T+ph) return; s+=`<text x="${W-R+5}" y="${(y+3).toFixed(1)}" fill="${VL_F.kurs}" font-size="10">${vlUsd(v)}</text><line x1="${W-R}" x2="${W-R+3}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${VL_F.kurs}"/>`; }); }
 // Achsentitel in eigener Zeile ganz oben (links bündig links, rechts bündig rechts -- nichts ragt aus dem Bild)
 s+=`<text x="3" y="11" fill="${VL_MUTED}" font-size="10">Schwankung (% p. a.)</text>`
  +(mitKurs?`<text x="${W-3}" y="11" fill="${VL_F.kurs}" font-size="10" text-anchor="end">Kurs (rechts, log)</text>`:'');
 vlXSchritte(x0,x1,pw).forEach(([t,txt])=>{ const x=X(t); if(x<L+2||x>W-R-34) return; s+=`<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${T}" y2="${T+ph}" stroke="${VL_GRID}"/><text x="${(x+3).toFixed(1)}" y="${H-6}" fill="${VL_MUTED}" font-size="10">${txt}</text>`; });
 if(zukunft){ const xh=X(heute).toFixed(1); s+=`<line x1="${xh}" x2="${xh}" y1="${T}" y2="${T+ph}" stroke="${VL_REF}" stroke-dasharray="3,3"/><text x="${(+xh+3).toFixed(1)}" y="${T+ph-5}" fill="${VL_MUTED}" font-size="10" paint-order="stroke" stroke="${VL_FLAECHE}" stroke-width="3">heute</text>`; }
 // Kurs zuerst (1 px, unter der Schwankung); er endet am letzten Tagesschluss
 if(mitKurs) s+=vlPfad(kurs,x0,heute-1,X,Y2,true,`stroke="${VL_F.kurs}" stroke-width="1" opacity="0.6"`);
 // Prognose: Bänder (nur bis 6 M), Wochenstufen, Tagespfad, Schwelle, Beschriftung
 if(p&&p.wochen){ p.wochen.forEach(w=>{ const xa=X(w.a), xb=X(w.b+1);
   if(!gross){
    if(w.lo90!=null&&w.hi90!=null) s+=`<rect x="${xa.toFixed(1)}" y="${Y(w.hi90).toFixed(1)}" width="${(xb-xa).toFixed(1)}" height="${Math.max(1,Y(w.lo90)-Y(w.hi90)).toFixed(1)}" fill="${VL_F.prog}" opacity="0.10"/>`;
    if(w.lo50!=null&&w.hi50!=null) s+=`<rect x="${xa.toFixed(1)}" y="${Y(w.hi50).toFixed(1)}" width="${(xb-xa).toFixed(1)}" height="${Math.max(1,Y(w.lo50)-Y(w.hi50)).toFixed(1)}" fill="${VL_F.prog}" opacity="0.22"/>`; }
   if(w.mitte!=null) s+=`<line x1="${xa.toFixed(1)}" x2="${xb.toFixed(1)}" y1="${Y(w.mitte).toFixed(1)}" y2="${Y(w.mitte).toFixed(1)}" stroke="${VL_F.prog}" stroke-width="2.4"/>`;
   // Beschriftung je Woche in zwei Zeilen (Wahrscheinlichkeit, darunter die Grundrate) -- nur wenn die Woche breit genug ist
   if(!gross&&w.p!=null&&xb-xa>=44){ const xm=((xa+xb)/2).toFixed(1), st=`text-anchor="middle" paint-order="stroke" stroke="${VL_FLAECHE}" stroke-width="3"`;
    s+=`<text x="${xm}" y="${T+13}" fill="${VL_TEXT}" font-size="10" ${st}>W${w.k} · ${vlPr(w.p)}</text>`;
    if(xb-xa>=66&&w.grund!=null) s+=`<text x="${xm}" y="${T+25}" fill="${VL_MUTED}" font-size="9" ${st}>üblich ${vlPr(w.grund)}</text>`; } });
  if(!gross){
   if(p.schwelle!=null&&p.schwelle<=hi) s+=`<line x1="${X(heute).toFixed(1)}" x2="${X(x1+1).toFixed(1)}" y1="${Y(p.schwelle).toFixed(1)}" y2="${Y(p.schwelle).toFixed(1)}" stroke="${VL_F.schwelle}" stroke-dasharray="4,3" opacity="0.85"/>`;
   if(p.pfad&&p.pfad.length){ const pf={t0:heute, v:p.pfad}; s+=vlPfad(pf,heute,x1,X,Y,false,`stroke="${VL_F.prog}" stroke-width="1" stroke-dasharray="1,3" opacity="0.8"`); } } }
 if(VOLA.dvol&&dvol) s+=vlPfad(dvol,x0,heute-1,X,Y,false,`stroke="${VL_F.dvol}" stroke-width="1.4" stroke-dasharray="6,4"`);
 if(VOLA.vi7){ s+=vlPfad(vi7,x0,heute-1,X,Y,false,`stroke="${VL_F.vi}" stroke-width="1" opacity="0.6" stroke-dasharray="3,2"`);
  for(let t=x0;t<heute;t++){ const v=vlWert(vi7,t); if(v!=null&&v>hi){ const x=X(t)+(X(t+1)-X(t))/2; s+=`<path d="M${(x-3).toFixed(1)},${(T+5).toFixed(1)}L${(x+3).toFixed(1)},${(T+5).toFixed(1)}L${x.toFixed(1)},${(T+1).toFixed(1)}Z" fill="${VL_F.vi}" opacity="0.8"/>`; } } }
 s+=vlPfad(vi30,x0,heute-1,X,Y,false,`stroke="${VL_F.vi}" stroke-width="2.4"`);
 // Termine als Buchstaben in eigener Zeile über der Fläche; zu eng beieinander -> zu einer Marke zusammengefasst (z. B. „FV“)
 if(!gross){ const gr=[];
  (d.termine||[]).filter(m=>m.tag>=x0&&m.tag<=x1&&VL_TERMIN[m.art]).sort((a,b)=>a.tag-b.tag).forEach(m=>{ const x=X(m.tag)+(X(m.tag+1)-X(m.tag))/2, g=gr[gr.length-1];
   if(g&&x-3<g.x+3+6*g.b.length) g.b+=VL_TERMIN[m.art][0]; else gr.push({x, b:VL_TERMIN[m.art][0], zuk:m.tag>=heute}); });
  gr.forEach(g=>{ s+=`<text x="${Math.max(L,Math.min(W-R-6*g.b.length,g.x-3)).toFixed(1)}" y="${T-6}" fill="${g.zuk?VL_TEXT:VL_MUTED}" font-size="9">${g.b}</text>`; }); }
 s+=`<line class="vlkreuz" x1="0" x2="0" y1="${T}" y2="${T+ph}" stroke="#58a6ff" stroke-width="1" opacity="0"/>`
  +`<rect class="vlhit" x="${L}" y="${T}" width="${pw}" height="${ph}" fill="transparent" style="cursor:crosshair;touch-action:pan-y"/></svg>`;
 el.innerHTML=s;
 const hit=el.querySelector('.vlhit'), kreuz=el.querySelector('.vlkreuz');
 const zeige=ev=>{ const rr=el.querySelector('svg').getBoundingClientRect(); const tag=Math.floor(x0+(ev.clientX-rr.left-L)/pw*(x1+1-x0));
  if(tag<x0||tag>x1){ kreuz.setAttribute('opacity','0'); hideTip(); return; }
  const x=(X(tag)+(X(tag+1)-X(tag))/2).toFixed(1); kreuz.setAttribute('x1',x); kreuz.setAttribute('x2',x); kreuz.setAttribute('opacity','0.7');
  const z=[]; const linie=(c,dash)=>`<span style="display:inline-block;width:12px;height:2px;background:${c};vertical-align:middle;margin-right:5px${dash?';opacity:.6':''}"></span>`;
  if(tag<heute){ z.push(['<b>links</b>','']); z.push([linie(VL_F.vi)+'VI30 (30 Tage bis hier)', vlPa(vlWert(vi30,tag))]);
   if(VOLA.vi7) z.push([linie(VL_F.vi,1)+'VI7 (7 Tage bis hier)', vlPa(vlWert(vi7,tag))]);
   if(VOLA.dvol&&dvol){ const v=vlWert(dvol,tag); if(v!=null) z.push([linie(VL_F.dvol)+'DVOL (30 Tage voraus)', vlPa(v)]); }
   if(VOLA.kurs){ const v=vlWert(kurs,tag); if(v!=null){ z.push(['<b>rechts</b>','']); z.push([linie(VL_F.kurs)+'Kurs (Tagesschluss UTC)', vlUsd(v)]); } }
   if((d.zonen||[]).some(([a,b])=>tag>=a&&tag<=b)) z.push(['', 'volatile Phase (7-Tage-Mittel über der Schwelle des Vorjahrs)']); }
  else if(p&&p.wochen){ const w=p.wochen.find(w=>tag>=w.a&&tag<=w.b), i=tag-heute;
   if(w){ z.push(['<b>Woche '+w.k+'</b> ('+vlKurzDatum(w.a)+' – '+vlKurzDatum(w.b)+')','']);
    z.push([linie(VL_F.prog)+'Wochenmittel', vlPa(w.mitte)+' (1 σ am Tag '+vlSigmaTag(w.mitte)+')']);
    z.push(['50 % / 90 %', vlPa(w.lo50)+' – '+vlPa(w.hi50)+' / '+vlPa(w.lo90)+' – '+vlPa(w.hi90)]);
    z.push(['volatile Woche', vlPr(w.p)+' (Grundrate '+vlPr(w.grund)+')']);
    z.push(['Vergleich', '30 T '+vlPa(w.b0)+' · Jahr '+vlPa(w.b365)+' · EWMA '+vlPa(w.ewma)]);
    if(w.besser&&w.besser.length) z.push(['', 'im Rückblick besser: '+esc(w.besser.join(', '))]); }
   if(p.pfad&&i>=0&&i<p.pfad.length) z.push([linie(VL_F.prog,1)+'Tageswert (nur Kalendermuster)', vlPa(p.pfad[i])]); }
  (d.termine||[]).filter(m=>m.tag===tag).forEach(m=>z.push(['Termin', esc((VL_TERMIN[m.art]||['',m.art])[1])]));
  if(!z.length){ hideTip(); return; }
  vlTip(ev, vlDatum(tag)+(tag>=heute?' · Prognose':''), z); };
 hit.addEventListener('pointermove', zeige); hit.addEventListener('pointerdown', zeige);
 hit.addEventListener('pointerleave', ()=>{ kreuz.setAttribute('opacity','0'); hideTip(); }); }
function vlTip(ev, titel, zeilen){ const t=$('tip'); if(!t) return;
 t.innerHTML=`<div class="t">${titel}</div>`+zeilen.map(z=>`<div class="r"><i>${z[0]}</i><b style="color:${VL_TEXT}">${z[1]}</b></div>`).join('');
 t.style.display='block'; const w=t.offsetWidth, h=t.offsetHeight; let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14; if(y<8) y=ev.clientY+18; x=Math.max(6,Math.min(x,innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; } t.style.left=x+'px'; t.style.top=y+'px'; }
function vlPfad(r,a,b,X,Y,log,stil){ if(!r||!r.v) return ''; let dd='', an=false; const breite=X(b+1)-X(a), schritt=Math.max(1,Math.floor((b-a+1)/Math.max(1,breite)));
 for(let t=a;t<=b;t+=schritt){ const v=vlWert(r,t); if(v==null||!isFinite(v)||(log&&v<=0)){ an=false; continue; }
  const x=X(t)+(X(t+1)-X(t))/2, y=Y(v); dd+=(an?'L':'M')+x.toFixed(1)+','+y.toFixed(1); an=true; }
 return dd?`<path d="${dd}" fill="none" ${stil} stroke-linejoin="round" stroke-linecap="round"/>`:''; }
function vlSchritte(lo,hi,n){ const roh=(hi-lo)/(n||5); if(!(roh>0)) return [lo]; const mag=Math.pow(10,Math.floor(Math.log10(roh)));
 const st=[1,2,2.5,5,10].map(f=>f*mag).find(s=>s>=roh)||10*mag; const out=[]; for(let v=Math.ceil(lo/st)*st; v<=hi+st*1e-9; v+=st) out.push(+v.toPrecision(12)); return out; }
function vlLogSchritte(lo,hi){ const out=[]; const e0=Math.floor(Math.log10(lo)), e1=Math.ceil(Math.log10(hi)), dek=Math.log10(hi/lo);
 const fs=dek>2?[1]:dek>0.8?[1,2,5]:dek>0.3?[1,1.5,2,3,5,7]:[1,1.1,1.2,1.3,1.5,1.7,2,2.5,3,4,5,6,7,8,9];
 for(let e=e0;e<=e1;e++) fs.forEach(f=>{ const v=f*Math.pow(10,e); if(v>=lo*0.999&&v<=hi*1.001) out.push(v); });
 if(out.length<2){ out.push(+Math.sqrt(lo*hi).toPrecision(3)); } return out; }
// Zeitachse: die feinste Teilung, deren Beschriftungen in die Breite passen (etwa eine je 58 px)
function vlXSchritte(x0,x1,pw){ const max=Math.max(2,Math.floor((pw||600)/58));
 for(const [art,n] of [['t',1],['t',2],['t',3],['w',1],['w',2],['m',1],['m',2],['m',3],['m',6],['j',1],['j',2]]){ const z=vlXKandidaten(x0,x1,art,n); if(z.length<=max) return z; }
 return vlXKandidaten(x0,x1,'j',5); }
function vlXKandidaten(x0,x1,art,n){ const out=[];
 if(art==='t'||art==='w'){ for(let t=x0;t<=x1;t++){ const wt=new Date(t*864e5).getUTCDay();
   if(art==='t'?t%n===0:(wt===1&&Math.floor((t-4)/7)%n===0)) out.push([t,vlKurzDatum(t)]); } return out; }
 const d0=new Date(x0*864e5); let j=d0.getUTCFullYear(), m=d0.getUTCMonth();
 if(art==='j'){ for(let jj=j+1;;jj++){ const t=Date.UTC(jj,0,1)/864e5; if(t>x1) break; if(jj%n===0) out.push([t,String(jj)]); } return out; }
 m++; if(m>11){ m=0; j++; }
 while(true){ const t=Date.UTC(j,m,1)/864e5; if(t>x1) break; if(m%n===0) out.push([t,m===0?String(j):vlMonat(t)]); m++; if(m>11){ m=0; j++; } }
 return out; }
function vlTabelleHtml(d,x0,x1){ const r=d.reihe||{}; const st=[]; const schritt=x1-x0>400?30:x1-x0>60?7:1;
 for(let t=x1;t>=x0&&st.length<200;t-=schritt) st.push(t);
 return `<div class="vlscroll"><table class="w"><tr><th>Tag</th><th class="n">VI30</th><th class="n">VI7</th>${d.dvol?'<th class="n">DVOL</th>':''}<th class="n">Kurs</th></tr>`
  +st.map(t=>`<tr><td>${vlDatum(t)}</td><td class="n">${vlPa(vlWert({t0:r.t0,v:r.vi30},t))}</td><td class="n">${vlPa(vlWert({t0:r.t0,v:r.vi7},t))}</td>`
   +(d.dvol?`<td class="n">${vlPa(vlWert({t0:r.t0,v:r.dvol},t))}</td>`:'')+`<td class="n">${vlUsd(vlWert({t0:r.t0,v:r.kurs},t))}</td></tr>`).join('')+'</table></div>'; }

// ---------- Tabelle „Nächste 4 Wochen“ (Anzeige nach dem Urteil, Nachtrag 13.4) ----------
function vlWochen(d){ const p=d.prognose; if(!p||!p.wochen||!p.wochen.length) return vlLeer('Noch keine Prognose (Erstlauf oder Daten fehlen; siehe Reiter Daten).');
 const u=p.urteil||{}, v1nicht=!p.ungeprueft&&u.V1&&u.V1!=='belegt', v2nicht=!p.ungeprueft&&u.V2&&u.V2!=='belegt';
 const niveauBesser=w=>(w.besser||[]).find(b=>['30-Tage-Mittel','Jahresmittel','EWMA'].includes(b));
 const phaseBesser=w=>(w.besser||[]).find(b=>['Grundrate','Zwei-Zustands-Modell'].includes(b));
 const basisWert=(w,b)=>b==='Jahresmittel'?w.b365:b==='EWMA'?w.ewma:w.b0;
 const hauptWert=w=>{ const b=niveauBesser(w); return b?basisWert(w,b):w.mitte; };      // Tagesschwankung zum angezeigten Hauptwert
 const mitte=w=>{ const b=niveauBesser(w); if(!b) return `<b>${vlPa(w.mitte)}</b>`;
  return `<b>${vlPa(basisWert(w,b))}</b> <span class="sub">(${esc(b)}; M ${vlPa(w.mitte)})</span>`; };
 const prob=w=>{ const b=phaseBesser(w); if(!b) return `<b>${vlPr(w.p)}</b>`;
  return `<b>${vlPr(b==='Grundrate'?w.grund:w.markov)}</b> <span class="sub">(${esc(b)}; M ${vlPr(w.p)})</span>`; };
 const hinweise=[];
 if(p.ungeprueft) hinweise.push('Ungeprüft: Ob diese Werte etwas taugen, entscheidet die vorab festgelegte Bilanz.');
 if(v1nicht) hinweise.push('Niveau im Rückblick nicht besser als 30-Tage- und Jahresmittel – beide stehen daneben.');
 if(v2nicht) hinweise.push('Wahrscheinlichkeit im Rückblick nicht besser als die Grundrate – sie steht gleich groß daneben.');
 if(p.wochen.some(w=>(w.besser||[]).length)) hinweise.push('Wo eine einfache Regel im Rückblick besser war, steht sie als Hauptwert („im Rückblick besser“).');
 if(p.nicht_im_urteil) hinweise.push('HYPE: gemeinsame Steigungen, eigenes Niveau – nicht im Urteil.');
 const sp=v1nicht;
 return `<div class="vlkopf2"><b>Nächste 4 Wochen</b> <span class="sub">Wochenmittel der Schwankung in % p. a. und als Tagesschwankung (1 σ) · volatile Woche: 7-Tage-Mittel über ${vlPa(p.schwelle)} (80. Perzentil der letzten 365 Tage)</span></div>`
  // Reihenfolge: Niveau (mit den Vergleichen, wenn V1 nicht belegt), dann die volatile Woche neben der Grundrate, dann Band,
  // Tagesschwankung und Termine -- auf dem Telefon stehen so die Hauptwerte vorn (die Tabelle scrollt waagerecht)
  +`<div class="vlscroll"><table class="w"><tr><th>Woche</th><th>Zeitraum</th><th class="n">Wochenmittel</th>`
  +(sp?'<th class="n">30-Tage-Mittel</th><th class="n">Jahresmittel</th>':'')
  +`<th class="n">volatile Woche</th><th class="n">${v2nicht?'<b>Grundrate</b>':'Grundrate'}</th><th class="n">50 % (M)</th><th class="n">Tagesschwankung (<span class="vlnt">1 σ</span>)</th><th class="vlterm">Termine</th></tr>`
  +p.wochen.map(w=>`<tr><td>W${w.k}</td><td>${vlKurzDatum(w.a)} – ${vlKurzDatum(w.b)}</td><td class="n">${mitte(w)}</td>`
   +(sp?`<td class="n"><b>${vlPa(w.b0)}</b></td><td class="n"><b>${vlPa(w.b365)}</b></td>`:'')
   +`<td class="n">${prob(w)}</td><td class="n">${v2nicht?'<b>'+vlPr(w.grund)+'</b>':vlPr(w.grund)}</td>`
   +`<td class="n">${vlPa(w.lo50)} – ${vlPa(w.hi50)}</td><td class="n">${vlSigmaTag(hauptWert(w))}</td>`
   +`<td class="vlterm">${(w.termine||[]).map(m=>esc(vlKurzDatum(m.tag)+' '+((VL_TERMIN[m.art]||['',m.art])[1]))).join(', ')||'—'}</td></tr>`).join('')
  +`</table></div><div class="sub vlhin">${hinweise.map(esc).join(' ')} Die Prognose sagt, wie stark sich der Kurs bewegen dürfte – nicht, wohin.</div>`; }

// ---------- Bilanz und Daten ----------
function vlUrteilFarbe(u){ return u==='belegt'?'<span class="vlok">✓ belegt</span>':u==='nicht belegt'?'nicht belegt':u&&u.startsWith('nicht prüfbar')?'<span class="vlwarn">⚠ '+esc(u)+'</span>':esc(u||'—'); }
function vlBilanz(d){ const u=d.urteil, z=d.zaehlung;
 if(!u){ if(!z) return vlLeer('Noch keine Zählung – sie folgt nach dem Rückblick (Stand im Reiter Daten).')+vlVorUrteil(d);
  return `<div class="vlsatz">Bis zum gemeinsamen Urteil stehen hier nur Anzahlen (Regel 4) – keine Vergleiche von Prognosen mit Ergebnissen. Freigabe: ${z.freigabe?'<span class="vlok">✓ ja</span>':'<span class="vlwarn">⏳ noch nicht</span> – '+esc(z.grund||'')}</div>`
   +`<div class="vlscroll"><table class="w"><tr><th>Prüfung</th><th class="n">Ursprungstage</th><th class="n">mindestens</th><th>dazu</th></tr>`
   +(z.zeilen||[]).map(r=>`<tr><td>${esc(r.name)}</td><td class="n">${vlZ(r.n,0)}</td><td class="n">${vlZ(r.min,0)}</td><td>${esc(r.dazu||'')}</td></tr>`).join('')+'</table></div>'
   +vlVorUrteil(d); }
 return `<div class="vlsatz">Gemeinsames Urteil vom ${vlUhr(u.vom)}: ${esc(u.holm||'gewichteter Holm')}; studentisierter Block-Bootstrap über Ursprungstage; belegt nur mit angepasstem p unter 0,05, richtigem Vorzeichen in beiden Hälften und erreichter Mindestzahl.</div>`
  +`<div class="vlscroll"><table class="w"><tr><th>Prüfung</th><th>Urteil</th><th class="n">Maß</th><th class="n">90-%-Intervall</th><th class="n">p (Holm)</th><th class="n">p</th><th class="n">Hälften</th><th class="n">Tage</th><th class="n">Block</th></tr>`
  +(u.zeilen||[]).map(r=>{ const teil=r.pruefung==='V1a'||r.pruefung==='V1b';
    return `<tr><td class="vltitel">${teil?'&nbsp;&nbsp;↳ ':''}${esc(r.titel||r.pruefung)}</td><td>${teil?'<span class="sub">Teil von V1</span>':vlUrteilFarbe(r.urteil)}</td><td class="n">${r.pruefung==='V1'?'—':vlZ(r.mass,4)}</td>`
   +`<td class="n">${r.lo!=null&&r.hi!=null?vlZ(r.lo,4)+' … '+vlZ(r.hi,4):'—'}</td><td class="n">${vlZ(r.p_holm,4)}</td><td class="n">${vlZ(r.p,4)}</td>`
   +`<td class="n">${r.h1!=null?vlZ(r.h1,4)+' / '+vlZ(r.h2,4):'—'}</td><td class="n">${vlZ(r.n,0)}</td><td class="n">${r.block?vlZ(r.block,0):'—'}</td></tr>`; }).join('')+'</table></div>'
  +vlBeschreibend(d.beschreibend)+vlVorUrteil(d)+vlVorwaerts(d.vorwaerts); }
function vlBeschreibend(b){ if(!b||!b.je_woche) return '';
 const namen=[['B0','30-Tage-Mittel'],['B365','Jahresmittel'],['EWMA','EWMA'],['grund','Grundrate'],['markov','Zwei-Zustands-Modell']];
 return `<div class="vlkopf2"><b>Je Woche (beschreibend)</b> <span class="sub">Differenz Vergleich minus M mit 90-%-Intervall; positiv = M besser. „Vergleich besser“: Intervall ganz unter 0 und beide Hälften unter 0 (wie Ausblick S1).</span></div>`
  +`<div class="vlscroll"><table class="w"><tr><th>Woche</th>${namen.map(([_,n])=>`<th class="n">${n}</th>`).join('')}</tr>`
  +b.je_woche.map(w=>`<tr><td>W${w.woche}</td>${namen.map(([k])=>{ const iv=w[k]||{}; const bes=((b.regel||{})[String(w.woche)]||{})[k];
    return `<td class="n">${vlZ(iv.mass,4)}<br><span class="sub">[${vlZ(iv.lo,4)}; ${vlZ(iv.hi,4)}]</span>${bes?'<br><span class="vlwarn">Vergleich besser</span>':''}</td>`; }).join('')}</tr>`).join('')+'</table></div>'
  +(b.robust?`<div class="vlsatz">Robustheit: ${Object.entries(b.robust).map(([t,w])=>esc(t)+' Mittel '+vlZ(w.mittel,4)+', ohne 1 % '+vlZ(w.ohne_1_prozent,4)+(w.getragen_von_wenigen?' <span class="vlwarn">getragen von wenigen Wochen</span>':'')).join(' · ')}</div>`:'')
  +`<details class="vldetails"><summary>Mehr (Deckung, Zuverlässigkeit, Mincer-Zarnowitz, Tagespfad, DVOL allein, HYPE)</summary><pre class="vlpre">${esc(JSON.stringify({deckung:b.deckung, zuverlaessigkeit:b.zuverlaessigkeit, mincer_zarnowitz:b.mincer_zarnowitz, tagespfad:b.tagespfad, dvol_allein:b.dvol_allein, hype:b.hype, je_coin:b.je_coin},null,1)).slice(0,9000)}</pre></details>`; }
function vlVorUrteil(d){ const l=d.vor_urteil; if(!l||!l.length) return '';
 return `<div class="vlkopf2"><b>Prüfungen vor dem Urteil</b></div><div class="vlscroll"><table class="w"><tr><th></th><th>Prüfung</th><th>Wert</th></tr>`
  +l.map(([n,ok,w])=>`<tr><td>${ok?'<span class="vlok">✓</span>':'<span class="vlwarn">✗</span>'}</td><td>${esc(n)}</td><td>${esc(String(w||''))}</td></tr>`).join('')+'</table></div>'; }
function vlVorwaerts(v){ if(!v) return '';
 if(v.zeilen) return `<div class="vlkopf2"><b>Vorwärts: Bestätigungstest</b></div>`+v.zeilen.map(r=>`<div class="vlsatz">${esc(r.titel)}: ${vlUrteilFarbe(r.urteil)} (p Holm ${vlZ(r.p_holm,4)}, ${vlZ(r.tage,0)} Tage)</div>`).join('');
 return `<div class="vlkopf2"><b>Vorwärts (beschreibend)</b> <span class="sub">${vlZ(v.tage,0)} Live-Ursprungstage mit fertigen Zielen; Test erst ab ${vlZ(v.min,0)}</span></div>`
  +`<div class="vlsatz">${Object.entries(v.werte||{}).map(([n,w])=>esc(n)+': '+vlZ((w||{}).mass,4)+' ['+vlZ((w||{}).lo,4)+'; '+vlZ((w||{}).hi,4)+']').join(' · ')}${(v.warnung||[]).length?' · <span class="vlwarn">vorwärts schlechter als '+esc(v.warnung.join(', '))+'</span>':''}</div>`; }
function vlDaten(d){ const q=d.quellen||[];
 return `<div class="vlscroll"><table class="w"><tr><th>Coin</th><th>Tage ab</th><th>letzter Tag</th><th class="n">gültige Tage</th><th>DVOL (aktien.db)</th><th>Prognosen</th></tr>`
  +q.map(r=>`<tr><td>${esc(r.coin)}</td><td>${r.von!=null?vlDatum(r.von):'—'}</td><td>${r.bis!=null?vlDatum(r.bis):'—'}</td><td class="n">${r.anteil!=null?vlZ(r.anteil*100,1)+' %':'—'}</td>`
   +`<td>${r.dvol?esc(r.dvol):'—'}</td><td>${esc(r.prognosen||'—')}</td></tr>`).join('')+'</table></div>'
  +`<div class="vlsatz">Rückblick: ${esc(d.rueckblick||'—')} · Stichtag ${d.stichtag?vlUhr(d.stichtag):'—'} · Dienst: ${d.dienst?'letzter Schritt '+vlUhr(d.dienst):'noch kein Lauf'}</div>`
  +((d.hinweise||[]).length?`<ul class="vlhinweise">${d.hinweise.map(h=>`<li>${esc(h)}</li>`).join('')}</ul>`:''); }

function vlCss(){ if($('vlcss')) return; const st=document.createElement('style'); st.id='vlcss';
 st.textContent=`#sec-volatil .vlzeile{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:4px 0}
#sec-volatil .vlabstand{margin-left:10px}
#sec-volatil .vlstand{margin-left:auto}
#sec-volatil .vlhinweis{border:1px solid #30363d;border-radius:6px;padding:6px 10px;margin:6px 0;color:#e6edf3;font-size:12px;line-height:1.45}
#sec-volatil .vlkopf{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap;margin:8px 0 2px}
#sec-volatil .vlkopf2{margin:12px 0 4px}
#sec-volatil .vltab{margin-left:auto;font-size:11px;background:none;border:1px solid #30363d;color:#8b949e;border-radius:4px;padding:1px 8px;cursor:pointer}
#sec-volatil .vlleg{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:11px;color:#8b949e;margin:2px 0 4px}
#sec-volatil .vlleg .sw{display:inline-block;width:12px;height:10px;margin-right:4px;vertical-align:middle;border-radius:2px}
#sec-volatil .vlplot{width:100%;min-width:0}
#sec-volatil .vlquelle{font-size:11px;color:#8b949e;margin:4px 0;line-height:1.4}
#sec-volatil .vlscroll{overflow-x:auto;max-width:100%}
#sec-volatil .vlscroll table{min-width:420px}
#sec-volatil .vlleer{padding:14px;color:#8b949e;text-align:center}
#sec-volatil .vlsatz{font-size:12px;color:#c9d1d9;margin:6px 0}
#sec-volatil .vlok{color:#3fb950}
#sec-volatil .vlwarn{color:#d29922}
#sec-volatil .vltitel{max-width:360px;white-space:normal}
#sec-volatil .vlterm{white-space:normal;min-width:190px}
#sec-volatil .vlhin{margin:4px 0 8px}
#sec-volatil .vlpre{white-space:pre-wrap;font-size:11px;color:#8b949e}
#sec-volatil .vlhinweise{font-size:12px;color:#8b949e;margin:6px 0 0;padding-left:18px}
#sec-volatil .vlnt{text-transform:none}`;
 document.head.appendChild(st); }
function vlStart(){ if(!$('sec-volatil')) return; vlCss(); vlLeiste(); vlLaden(false);
 setInterval(()=>{ if(vlOffen()) vlLaden(false); }, 60000);
 document.addEventListener('visibilitychange',()=>{ if(vlOffen()) vlLaden(false); });
 window.addEventListener('resize',()=>{ if(vlOffen()&&VOLA.tab==='chart') vlZeichne(); }); }
vlStart();
"""
