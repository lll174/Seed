# Änderungskonzept v2 — Hyperliquid-Analysesystem

Fable, 13.09.2026. Grundlage: Übergabe vom 13.09., das vollständige Projekt-Transkript
(609 Beiträge), der Auditbericht (Kimi K3) mit seinen offenen Befunden, das Konzept, das
Opus 5 um 13:22 im anderen Chat geschrieben hat, und die offizielle Hyperliquid-Dokumentation
zu Ratengrenzen (heute geprüft).

**Stand der Umsetzung (Sitzung 2, gleicher Tag):** Nach dem Hochladen des Archivs wurden
alle Codebefunde nachgestellt und **P0 vollständig umgesetzt** — Kalibrierung mit n_eff,
λ = 4/n_eff, Mindest-n_eff je Treiber, Gewichte je Horizont und gelerntem β; Bewertung mit
Wilson-Intervall, Basisrate und Brier-Skill; Ensemble als Beta-Posterior; M9, M6, M10;
Magnet-Placebo; Analog-Basisrate; Zeitprofil 180 Tage; Nulltest und Einheiten-Invarianten
im Selbsttest; Dashboard-Kacheln. Details in `UEBERGABE_13-09-2026.md`. Zwei Annahmen
dieses Konzepts erwiesen sich am Code als falsch und sind unten korrigiert (3.4, 3.8).
Die Budget-Zahlen in 2.4 bleiben Annahmen, bis Anhang A auf dem Pi gelaufen ist.

---

## 0. Die Kernaussage in fünf Sätzen

1. Die goldene Regel ist heute nur halb umgesetzt: Das System verteilt Aufmerksamkeit nach
   **Größe** und wählt Leaderboard-Konten nach **30-Tage-PnL**. Beides sind Näherungen.
   Es misst nirgends, **ob ein Konto dem Kurs vorausläuft** — obwohl genau diese Daten seit
   Wochen in `lb_positions`, `lb_fills` und den Wal-Ereignissen liegen.
2. Die Selbstkalibrierung hat einen Konstruktionsfehler, der schwerer wiegt als alle
   Audit-Befunde zusammen: Ihr Stichprobenumfang ist durch überlappende 24-Stunden-Fenster
   **bis zu 96-fach aufgebläht**, und die Regularisierung `lam = 4/n` wird mit diesem
   aufgeblähten n schwächer. Die Gewichte lösen sich damit vom Prior, lange bevor es
   echte Information gibt.
3. Das Budget lässt sich ohne zweite IP und ohne Bezahlanbieter neu verteilen: Die zehn
   besten Konten bekommen **WebSocket-Echtzeit zum Nullpreis** (dokumentiertes Limit:
   zehn Nutzer), die Fill-Abholung endet für Market Maker und Hedger, der Adress-Poller
   folgt dem Positionswert statt der Reihenfolge.
4. Jede Statistikfunktion bekommt drei Dinge, die heute fehlen: ein **Konfidenzintervall**,
   einen **Vergleich gegen die Basisrate** (Placebo) und einen **Nulltest** auf reinem
   Rauschen, der als Selbsttest dauerhaft mitläuft.
5. Die Fehlerklasse „Zeitstempel in ms, Test bestätigt den Fehler" wird an der Wurzel
   geschlossen: Einheiten-Invarianten in der Datenbank prüfen, nicht im Kopf.

---

## 1. Das Opus-Konzept — was bleibt, was ich korrigiere

Ich habe es Punkt für Punkt gegengelesen, wie es die Arbeitsweise dieses Projekts verlangt.

| Punkt bei Opus | Urteil | Begründung |
|---|---|---|
| Überlappung der Bewertungsfenster als Befund Nr. 1 | **richtig, übernommen** | Alle 15 min eine Prognose, 24-h-Bewertung: zwei Nachbarn teilen 23 h 45 min ihres Ergebnisses. |
| Lösung: nur noch nicht überlappende Fenster bewerten | **korrigiert** | Verwirft über 90 % der Daten. Besser: alle Fenster behalten, aber mit **n_eff = n · 15 min / Horizont** rechnen (n/4 bei 1 h, n/16 bei 4 h, n/96 bei 24 h). Schwellen und Regularisierung hängen an n_eff, Intervalle kommen aus dem Block-Bootstrap. |
| Analog-Suche streichen, weil 39 % Trefferquote | **korrigiert — Widerspruch** | Dieselbe Trefferquote wird zwei Absätze vorher als „statistisch leer" erklärt. Man kann nicht mit einer leeren Zahl einen Treiber hinrichten. Degradieren ja, löschen erst nach dem Killkriterium (Abschnitt 3.4). |
| Budget-Tabelle: „Rest alle 30 min" | **korrigiert — Rechenfehler** | Der Rest sind 140.000 Adressen. Alle 30 min à 2 Gewicht wären 9.300 Einheiten je Minute bei 1.200 verfügbaren. Abschnitt 2.4 enthält eine Tabelle, deren Summe aufgeht. |
| Konto-Score 30/30/30/10 | **erweitert** | Die Anteile sind gesetzt, nicht gemessen. Der Score bekommt einen eigenen Out-of-sample-Test (Rangkorrelation mit dem späteren Vorlauf), und eine kostenlose fünfte Größe: **Edge je Umsatz** aus dem Leaderboard. |
| Vorlauf ab 20 Ereignissen, harte Grenze | **erweitert** | Harte Grenzen springen. Bayes-Schrumpfung: α̂ = α · n / (n + 20). Ein Konto mit 5 Ereignissen zählt zu 20 %, eines mit 200 zu 91 %. |
| Gegen-Flow (Verlierer invertiert) | **als Experiment behalten** | Riskant, wie Opus selbst schreibt. Bekommt ein Killkriterium, kein Startgewicht über 0,3. |
| Fills nur für direktionale Konten | **übernommen** | Die 12.000 Fills je Stunde (Opus-Messung) stammen von Market Makern; ihre Fills tragen keine Richtung. |
| Orders nur für die Spitze | **übernommen** | Stops kleiner Konten verändern das Cluster-Bild nicht. |
| Live-Abrufe Bybit/OKX/Crypto.com in den Dienst | **übernommen** | Minutentakt in die Datenbank, Chart liest nur noch. |
| Konfluenz zeigt die Prognose an, urteilt nicht selbst | **übernommen** | Zwei Urteile auf einer Seite sind eines zu viel. |
| M9 mit Rangmaß, M6, M10, M1–M3, Wilson-Intervalle | **übernommen** | Deckt sich mit der Übergabe. |
| Zweite IP, GoldRush, Knoten: nicht jetzt | **übernommen** | Erst umverteilen, dann messen, dann kaufen. |

**Was bei Opus fehlt und hier neu ist:** WebSocket für die Spitze (2.5), Edge je Umsatz
(2.2), Trennung von Signalgebern und Brennstoff (2.3), der Poller nach Positionswert mit
Sichtungsbudget (2.7), Gewichte je Horizont und Treiber-Familien (3.1), Placebo-Basisraten
für Magnet und Reversal (3.5), Brier-Score statt nur Trefferquote (3.2), der Nulltest als
Dauer-Selbsttest (3.10), Einheiten-Invarianten gegen die Zeitstempel-Fehlerklasse (5.2).

---

## 2. Die goldene Regel, operationalisiert

### 2.1 Was „größtes Konto" bedeuten muss

Das Transkript enthält den Beweis, warum die Regel präzisiert werden muss: Die fünf
Spitzenkonten nach 30-Tage-PnL (Kontowerte 5,4 Mrd, 2,3 Mrd, 1,0 Mrd) hatten laut
`clearinghouseState` **null Perp-Positionen** — Vaults, Market Maker, Treasury. Größe allein
ist kein Wissen.

Die Regel lautet deshalb operativ: **Die größten direktionalen Perp-Konten mit belegter
Bilanz tragen das meiste Wissen.** Drei Bedingungen, alle heute schon messbar: direktional
(Verhaltensklasse), Perp-Position vorhanden, Bilanz über mehrere Fenster positiv.

### 2.2 Der Konto-Score S ∈ [0, 1], je Konto und Coin, täglich neu

| Anteil | Komponente | Woher | Bemerkung |
|---|---|---|---|
| 35 % | **Vorlauf** — läuft das Konto dem Kurs voraus? | eigene Daten: Positionsänderungen (alle 10 min bei Leaderboard-Konten, kürzer bei Walen), `lb_fills` | Rendite eines Portfolios, das jedem Schritt folgt, nach 1 h / 4 h / 24 h, **abzüglich der Marktdrift** im selben Fenster. t-Wert, Bayes-geschrumpft mit k = 20. |
| 25 % | **Edge je Umsatz** — PnL geteilt durch gehandeltes Volumen | Leaderboard liefert `pnl` **und** `vlm` je Fenster, kostenlos | Trennt Market Maker (Milliarden Umsatz, Promille Edge) von Händlern (wenig Umsatz, Prozente). Eine Zeile aus dem Rohformat im Transkript: 1,9 Mio PnL auf 38,9 Mrd Monatsumsatz = 0,005 % — ein Market Maker, kein Signalgeber. |
| 20 % | **Konsistenz** — Vorzeichen über Tag / Woche / Monat / Gesamt, ROI-Rang | Leaderboard, alle vier Fenster (heute werden nur Monat und Woche genutzt) | Ein Glückstreffer im Monat fällt durch. |
| 10 % | **Größe** — log₁₀ des Positionswerts, rangnormiert | `addresses.pos_value` | Bewusst klein: Größe ist die **Hypothese** der goldenen Regel, nicht ihr Beweis. Der Score-Test in 2.6 misst, ob sie stimmt. |
| 10 % | **Klasse** — direktional 1,0 · gemischt 0,6 · Hedge / MM 0,0 | vorhanden | Hedger bleiben Brennstoff (2.3), aber keine Signalgeber. |

Jede Komponente wird rangnormiert (0–1), damit keine Skala dominiert. Der Score wird
protokolliert (`account_score`: ts, addr, coin, S, Komponenten, n_ereignisse), damit sein
Verlauf und seine Prüfung möglich sind.

### 2.3 Zwei Listen, zwei Zwecke — nicht vermischen

| Liste | Auswahl | Zweck | Verbraucher |
|---|---|---|---|
| **Signalgeber** | Score-Rang | Prognose-Treiber: wer hat recht | Smart-Flow, Elite-Positionierung, Smart Money |
| **Brennstoff** | Positionswert × Nähe zur Liquidation | Heatmap, Kaskadenmodell: wer wird zwangsverkauft | Cluster, Magnet, Kapitulation |

Ein Hedge mit 566 Mio Short bei 5-fachem Hebel ist als Signalgeber wertlos und als
Brennstoff fast irrelevant (weit von der Liquidation). Ein direktionaler Wal mit 46 Mio bei
20-fach ist beides. Die Kachel „Wale netto short" zählt heute richtig (nur direktionale);
diese Trennung macht das Prinzip für alle Verbraucher verbindlich.

### 2.4 Gewichtseinheiten folgen dem Score — eine Rechnung, die aufgeht

Verfügbar: 1.200 je Minute, hart. Planungsziel 1.000, damit 200 für Aufholvorgänge und
Fehlerwiederholungen bleiben. Die Kontenzahlen je Stufe sind **Annahmen** — sie werden mit
den Abfragen in Anhang A zuerst gemessen.

| Stufe | Wer (Annahme Anzahl) | Positionen (2) | Orders (20) | Fills (20 + 1/20) | Gewicht/min |
|---|---|---|---|---|---|
| **S1 Elite** | Top 10 nach Score | WebSocket (0) + Sicherheitsabfrage alle 5 min | alle 5 min | WebSocket (0) | 4 + 40 = **44** |
| **S2 Spitze** | nächste 40 Signalgeber + alle Wale ≥ 20 Mio (~170) | alle 2 min | Signalgeber alle 5 min, Wale stündlich | 40 direktionale alle 30 min | 170 + 160 + 46 + ~60 = **436** |
| **S3 Mitte** | 1–20 Mio Positionswert, direktional oder gemischt (~600) | alle 15 min | nie | nie | **80** |
| **S4 Klein** | 250 k – 1 Mio (~1.800) | alle 60 min | nie | nie | **60** |
| **S5 Staub** | unter 250 k mit Position (~10.000) | alle 6 h | nie | nie | **56** |
| **Sichtung** | nie abgefragt oder leer mit neuem Trade, nach Handelsgröße sortiert | festes Budget | — | — | **100** |
| Leaderboard | Abruf + Kandidatenprüfung | | | | **30** |
| **Summe** | | | | | **≈ 806** |

Heute: Poller 624, Orders ~180, Fills 60–550, Leaderboard ~30 — an der Grenze und mit
Rückstand. Neu: 806 mit Reserve, **und die Spitze wird um ein Vielfaches dichter beobachtet
als heute** (Echtzeit-Fills statt Stunden Rückstand, Orders alle 5 statt alle 20 Minuten).
Genau das ist „mehr Gewichtseinheiten für die erfolgreichen Konten".

Wale sind in S2 nicht wegen des Scores, sondern als Brennstoff. Ein Wal, der zugleich
Signalgeber ist, steht in S1 oder S2 — beide Rollen, ein Platz.

### 2.5 WebSocket für die Elite — Echtzeit zum Nullpreis

Die frühere Sitzung hat WebSockets verworfen, weil das Limit von zehn Nutzern für 79
Konten nicht reicht. Unter der goldenen Regel ist das Limit kein Hindernis, sondern eine
Vorgabe: **Die zehn Konten mit dem höchsten Score bekommen `userFills` und `userEvents`
als Abonnement.** Kein REST-Gewicht, keine Verzögerung, Liquidationen des Kontos sofort
sichtbar. Heute geprüft in der Hyperliquid-Dokumentation: maximal 10 verschiedene Nutzer
über alle nutzerbezogenen Abonnements, 100 Verbindungen, 1.000 Abonnements je IP. (Ein
SDK-Hersteller berichtet, die tatsächliche Grenze liege bei 14; geplant wird mit 10.)

Umsetzung: ein Abonnement-Manager im Recorder, der die Elite-Liste einmal je Stunde
abgleicht (Abmelden / Anmelden bei Wechsel), mit `userFills` als Primärquelle und einer
REST-Sicherheitsabfrage alle 5 min als Lückenfüller. Fällt die Verbindung, greift REST
automatisch, `lb_gaps` protokolliert wie bisher.

### 2.6 Signale aus dem Score — und der Test, ob die Regel stimmt

**Smart-Flow** (ersetzt die gleichgewichteten Flow-Treiber):

    F = Σ Sᵢ · dᵢ · √Nᵢ  /  Σ Sᵢ · √Nᵢ        dᵢ = ±1 (Kauf/Verkauf), Nᵢ = Notional in USD

Die Wurzel ist bewusst: Ein Konto mit 50 Mio darf nicht das ganze Signal sein; Score,
nicht Größe, entscheidet. Gerechnet je Fenster 1 h / 4 h / 24 h.

**Elite-Positionierung:** Netto-Ausrichtung der zehn S1-Konten, (USD long − USD short) /
brutto. Die reinste Form der goldenen Regel als eigener Treiber.

**Gegen-Flow (Experiment):** Fluss der zwanzig Konten mit dem niedrigsten Vorlauf bei
n ≥ 20, Vorzeichen invertiert. Prior 0,3. Killkriterium wie jeder Treiber.

**Der Score-Test, wöchentlich, out-of-sample:** Rangkorrelation (Spearman) zwischen dem
Score am Sonntag und dem gemessenen Vorlauf der Ereignisse der Folgewoche. Je Komponente
einzeln. Liegt die Korrelation der Komponente „Größe" bei null oder darunter, ist die
goldene Regel für diesen Markt in ihrer Größen-Form widerlegt — und die Score-Anteile
werden einmal im Monat nach den gemessenen Korrelationen nachgezogen. Die Regel wird damit
von einer Behauptung zu einer Hypothese mit Messung.

### 2.7 Der Adress-Poller: Wert statt Reihenfolge

Der Poller ist mit 624 von 1.020 Einheiten der größte Verbraucher, und er ist produktiv —
die Heatmap entsteht aus ihm. Aber seine Verteilung (65 % mit Position nach Überfälligkeit,
25 % nie abgefragt, 10 % leer) behandelt eine 3.000-Dollar-Position wie eine
3-Millionen-Position, nur seltener. Drei Änderungen:

- **Takt nach Positionswert** (Stufen S2–S5 oben). Vermutung: Die obersten 1.000
  Adressen tragen über 90 % der Heatmap-Masse. Anhang A misst das. Stimmt es, kostet die
  Staub-Stufe heute Hunderte Einheiten für unter 10 % des Bildes.
- **Sichtung nach Handelsgröße.** Der Trade-Feed liefert zu jedem Trade die beiden
  Adressen **und die Größe**. Nie abgefragte Adressen werden nach dem größten gesehenen
  Notional sortiert, nicht nach Ankunft. Wer 2 Mio handelt, wird binnen Minuten geprüft;
  wer 200 Dollar handelt, in Tagen.
- **Leaderboard als kostenlose Wal-Liste.** Der Leaderboard-Abruf liefert 45.000 Konten
  mit Kontowert in einem einzigen Abruf. Alle Konten über 5 Mio Kontowert, die der Poller nicht
  kennt, wandern in die Sichtung an die Spitze. Das ersetzt Tage des Durchsuchens.

---

## 3. Statistikfunktionen — Prüfbefunde und Korrekturen

Für jede Funktion: Befund, Wirkung, Korrektur, Test. Befunde mit „belegt" stehen so im
Transkript; „prüfen" heißt, es muss am Code nachgestellt werden.

### 3.1 `calibrate_weights` — die Kalibrierung

**Befund A (belegt): Überlappung.** Eine Prognose je 15-min-Fenster, Label = Vorzeichen
der 24-h-Bewegung. Bei 92 Fenstern je Tag entstehen je Tag rund **eine** unabhängige
24-h-Beobachtung. „500 Fenster, stabil nach fünf Tagen" aus dem Transkript sind in Wahrheit
fünf unabhängige Beobachtungen.

**Befund B (belegt, Codezeile im Transkript): `lam = 4.0 / max(n, 1)`.** Die L2-Strafe zum
Prior sinkt mit n. Bei 2.000 gespeicherten Fenstern ist λ = 0,002 — der Prior ist
praktisch abgeschafft, während die echte Information bei etwa 20 Beobachtungen liegt.
Das erklärt, warum Gewichte binnen Tagen weit vom Prior wandern.

**Befund C (prüfen): 20 Treiber, viele korreliert.** Taker-Flow HL, Spot-Taker-Flow,
Coinbase-Prämie, Spot-Orderbuch, Funding, OI messen teils dasselbe. Eine logistische
Regression mit 20 Parametern auf 20 unabhängigen Beobachtungen ist Überanpassung mit Ansage.

**Befund D (prüfen): ein Gewicht für alle Horizonte.** Taker-Flow ist ein 1-h-Signal,
Positionierung der Besten ein Mehrtages-Signal. Ein gemeinsames Gewicht mittelt beides
kaputt.

**Korrektur:**
- `n_eff` = Zahl getrennter Horizont-Blöcke (umgesetzt als `n_eff_bloecke`; bei lückenlosen
  Fenstern ≈ n · 900 / Horizont_s, bei geklumpten Ereignis-Treibern die Zahl der Episoden);
  λ = 4 / n_eff; Lernstart ab n_eff ≥ 40 **je Horizont**;
  ein Gewicht darf erst ab n_eff ≥ 50 für diesen Treiber vom Prior abweichen.
- **Gewichte je Horizont** (1 h, 4 h, 24 h). Die 1-h-Spur wird die Hauptspur des Lernens
  (168 unabhängige Fälle je Woche); 24 h bleibt Anzeige, bis Monate vergangen sind.
- **Treiber-Familien** als Zwischenebene: Positionierung der Signalgeber · Liquidationsstruktur
  · Aggressor-Flow · Spot / US-Nachfrage · Regime / Analog · Zeit. Erst lernen die sechs
  Familiengewichte, die Treiber innerhalb einer Familie teilen sich das Gewicht nach Prior;
  Einzelgewichte erst ab n_eff ≥ 100.
- Bleibt: L2 zum Prior, Deckel [0, 2 × Prior], Halbwertszeit 14 Tage, eine Prognose je Fenster.

**Test:** Nulltest (3.10) — auf Rauschen darf kein Gewicht um mehr als 0,1 vom Prior
abweichen. Mit dem heutigen λ tut es das; das ist die Reproduktion des Befunds.

### 3.2 `score_forecasts` / `urteil` — die Trefferquote

**M7 ist erledigt** (Toleranzfälle unentschieden). Drei Ergänzungen:
- **Wilson-Intervall** an jeder Quote, auf Basis von n_eff, im Dashboard als „47 % (38–56)".
- **Basisrate daneben.** In einem Trendmarkt trifft „immer long" 60 %. Die Quote wird
  gegen die Drift-Basisrate derselben Fenster gezeigt: „52 % gegen 55 % Basis" ist kein
  Erfolg, „52 % gegen 44 %" ist einer.
- **Brier-Score und Verlässlichkeit.** Die Trefferquote ignoriert die Konfidenz. Wenn das
  System 70 % sagt, muss es in 70 % der Fälle recht haben. Brier-Skill gegen die
  Basisrate; unter null heißt: Die Wahrscheinlichkeiten sind schlechter als Raten.

**Vereinfachung:** Die Out-of-sample-Trennung nach Gewichtsversion (`wver`) ist unnötig.
Jede gespeicherte Prognose entsteht mit Gewichten, die nur aus **früheren** Daten gelernt
wurden — die gespeicherte Bilanz ist per Konstruktion walk-forward. In-sample sind nur die
Trefferquoten je Treiber, die `calibrate_weights` über sein Trainingsfenster ausgibt; die
werden so beschriftet.

### 3.3 Ensemble Modell / Analog

**Befund (belegt):** Mischung nach „Trefferquote − 0,4", ohne Schrumpfung. 48 % gegen
57 % bei je 127 überlappenden Fällen (n_eff ≈ 1,3 Tage) ergaben 32 / 68. Das ist eine
Entscheidung auf Basis von anderthalb Standardabweichungen aus anderthalb Tagen.

**Korrektur:** Beta-Posterior je Modell mit 50 Pseudo-Beobachtungen bei 55 %, Nullpunkt
0,5 statt 0,4 (ein Modell bei 50 % weiß nichts), Mischung aus den Posterior-Mitteln,
Deckel [0,3; 0,7] bis n_eff ≥ 50 je Modell, sonst Prior 60 / 40.

### 3.4 `analog_forecast` — die Analog-Suche

**Befund (prüfen):** Zustandsvektor aus Renditen 1 / 7 / 30 T, Volatilität, RSI, Lage zum
7-Tage-Mittel, Tageszeit, Wochentag. Ohne Standardisierung dominiert die Größe mit der
weitesten Skala die Distanz. Und: 50 Analoge liefern p_up mit ±7 Prozentpunkten Streuung;
ein p_up von 0,57 ist von 0,5 nicht zu unterscheiden. Über drei Jahre mit Aufwärtsdrift
liegt das unbedingte p_up ohnehin über 0,5.

**Korrektur (am Code geprüft):** Die Merkmale sind bereits mit festen Skalen standardisiert
und die Suche läuft bereits stündlich gecacht — beide Annahmen des ersten Entwurfs waren
falsch. Bleibt: p_up mit Intervall und Vergleich gegen das unbedingte p_up derselben
Historie (**umgesetzt**); Prior 0,8 → 0,4 (offen, nach n_eff 50 entscheiden).

**Killkriterium:** Nach n_eff ≥ 50 auf 1 h und 4 h: Wilson-Intervall enthält 50 % **und**
gelerntes Gewicht < 0,3 × Prior → Treiber parken (Gewicht 0, weiter protokolliert, monatlich
neu geprüft). Dasselbe Kriterium gilt für **jeden** Treiber — das ist das automatische
Ausmisten, das der Auftrag verlangt, ohne dass ein Modell nach Bauchgefühl streicht.

### 3.5 `magnet_stats` — die Magnet-Statistik

**M8 ist erledigt** (aus ~1.300 wurden 17 unabhängige Ereignisse). Der eigentliche Mangel
bleibt: **41 % Berührwahrscheinlichkeit binnen 12 h für Cluster innerhalb 1 % ist ohne
Vergleich bedeutungslos.** Wenn BTC in 12 h ohnehin in 60 % der Fälle 1 % zurücklegt,
ist das Cluster kein Magnet, sondern ein Bremsklotz.

**Korrektur:** **Placebo-Basisrate** — für jedes Ereignis dieselbe Messung an einem
Preisniveau in gleichem Abstand auf der **anderen** Seite oder ohne Cluster; ausgewiesen
wird der **Magnet-Lift** p_touch / p_placebo mit Intervall. Lift ≈ 1 → die Magnet-Hypothese
trägt nicht, und das Pfadmodell fällt auf die Zeitprofil-Bänder zurück. Bei n = 17 sagt das
Intervall ehrlich, dass es noch keine Antwort gibt.

### 3.6 Reversal-Quote

**M6:** `dropna` — Ereignisse ohne Ergebnis fallen heraus statt als „keine Umkehr" zu zählen.
Dazu dieselbe Placebo-Basisrate wie beim Magnet: Wie oft dreht der Kurs nach 4 h ohne
Ereignis? Erst der Unterschied ist die Aussage.

### 3.7 `event_signal` / Leaderboard-Flow — M9 fertigstellen

Der Übergabe-Weg ist richtig: Rang in der vollständigen 168-Stunden-Reihe statt Z-Wert
über aktive Stunden. Eine Warnung dazu: **Ein Perzentil-Schwellwert feuert per Konstruktion
mit konstanter Rate** — die obersten 2 % von 168 Stunden sind immer 3,4 Stunden je Woche,
auch in einer toten Woche. Deshalb bleibt die absolute Untergrenze (≥ 1 Mio brutto, ≥ 2
direktionale Wale) zwingend, und die Vorher-Nachher-Zählung über 7 Tage gehört in den
Bericht, wie die Übergabe verlangt. Dasselbe für den Leaderboard-Flow.

### 3.8 `time_vol_profile` — das Zeitprofil

Über die gesamte Kurshistorie gerechnet (am Code bestätigt) mittelt es Regimewechsel aus.
Rollierendes Fenster 180 Tage, Verhältnis zum Tagesmittel wie bisher (**umgesetzt**).

### 3.9 `capitulation_signal`

Nach C1 / C3 korrekt. Ergänzung: n_eff und Intervall, wenn eine Quote daraus angezeigt wird.

### 3.10 Der Nulltest — ein Selbsttest, der keinen Fehler festschreiben kann

`hl_forecast.py --nulltest`: erzeugt einen Random Walk mit realistischer Volatilität,
zufällige Treiberwerte, zufällige Cluster und Ereignisse — und lässt die **gesamte**
Statistikstrecke darüber laufen. Erwartung, aus ersten Prinzipien statt aus dem heutigen
Ergebnis abgeleitet:

- jede Trefferquote 50 % innerhalb des Wilson-Intervalls (M7 hätte hier 55,1 % gezeigt)
- Magnet-Lift 1,0 (M8 hätte n = 1.300 statt 17 gezeigt)
- Signal-Feuerrate gleich der Nennrate (M9 hätte 42 statt 2 % gezeigt)
- kein gelerntes Gewicht mehr als 0,1 vom Prior (Befund 3.1 B)
- Brier-Skill ≈ 0, Ensemble bei 60 / 40

Läuft in `install.py --selftest` mit. Der Binance-Selbsttest hat C1 jahrelang bestätigt,
weil er das Ist-Verhalten als Soll übernahm; ein Nulltest kann das nicht, weil sein Soll
aus der Mathematik kommt.

---

## 4. Unnütz oder produktiv — Urteile mit Messung davor

| Baustein | Urteil | Was zu tun ist |
|---|---|---|
| Adress-Poller über 140.000 Adressen, 624/min | **produktiv, falsch verteilt** | Takt nach Wert (2.7), Pareto zuerst messen (Anhang A). |
| Fills für Market Maker und Hedger | **unnütz** | Streichen. Erwartung: Rückstand verschwindet ohne Drosselung. |
| Orders für ~1.790 Konten von 250 k bis 1 Mio (Opus-Zählung) | **weitgehend unnütz** | Nur S1 / S2. |
| Fünf Live-Abrufe Bybit / OKX / Crypto.com je Chart-Aufruf | **unnütz als Live** | Minutentakt im Binance-Dienst, in die DB. |
| Analog-Suche alle 15 min | **fraglich** | Stündlich, Prior 0,4, Killkriterium. |
| ETF-Flows als Treiber auf 1 h / 4 h | **unnütz auf kurzen Horizonten** | Ein Tageswert ist über 96 Fenster konstant. Nur im 24-h-Gewicht (löst sich mit 3.1 D). |
| 20 Einzeltreiber in einer Regression | **überdimensioniert** | Sechs Familien (3.1). |
| Drei Flow-Treiber für Hedge / MM / gemischt | **unnütz** | Ersetzt durch Smart-Flow. |
| Konfluenz als zweites Urteil | **unnütz** | Zeigt künftig die Treiberbeiträge der Prognose. |
| Sofortprognosen bei Wal-Ereignissen | **produktiv für die Anzeige** | Bleiben; vom Lernen ausgeschlossen (erledigt). |
| Netzwerkstatus, `lb_gaps`, Watchdog, Backup, `db_locked` | **produktiv** | Bleiben. `db_locked` bekommt eine Warnschwelle. |
| Zweite IP, GoldRush, eigener Knoten | **nicht jetzt** | Nach P1 messen, ob überhaupt Bedarf bleibt. |
| Datenbank auf USB-Stick, drei Schreiber | **Risiko** | Optional, Hardware: NVMe am Pi 5. Weniger Sperrkonflikte, keine Codeänderung. |

---

## 5. Fehler und ihre Wurzel

### 5.1 Offene Audit-Befunde, priorisiert

| Befund | Wirkung | Priorität |
|---|---|---|
| M9 halbfertig | Wal-Signal hängt am alten Z-Wert | **P0** |
| M6 NaN-Renditen | Reversal-Quote systematisch zu niedrig | **P0**, zehn Minuten |
| M10 Fusionsansicht | Cluster doppelt, „both" toter Code | **P0**, zwanzig Minuten |
| M1 Positionen über Neustart | Kaskadenfenster nach Neustart verloren | **P1** |
| M2 Markpreis statt Handelspreis | Liquidationsableitung prüft die falsche Reihe | **P1** |
| M3 `hash()` als Ersatz-`tid` | Duplikate nach Neustart | **P1**, `blake2b` |
| M4 `last_poll` trotz Fehlschlag | Konto gilt als frisch, ist es nicht | **P2** |
| M5 `n_with_pos` ohne Wale und Staub | Kennzahl falsch | **P2** |
| M13 `hl_binance` Exit 0 | systemd-Neustartschleife | **P2** |
| M16 blockierendes `urllib` | Ereignisschleife friert | **P2** |
| M12, M15 | Werkzeugfehler, Migration | **P3** |

### 5.2 Warum diese Fehlerklasse entsteht — und wie sie endet

C1 (ms statt s), C2 (Seite neu geraten), M11 (falsche ms-Schwelle), M10 (zwei Rundungen)
haben eine gemeinsame Wurzel: **Eine Konvention lebte im Kopf des Modells, nicht im Code.**
Bei jedem Modellwechsel wurde sie neu geraten.

- **Einheiten-Invarianten im Selbsttest.** Für jede Tabelle mit `ts`: `MAX(ts) < 1e11`;
  für `addresses.last_trade` und `first_seen`: `MIN > 1e11`. Zehn Zeilen SQL, hätten C1 am
  ersten Tag gefunden. Analog: `side IN ('long','short')` für alle Seitenspalten.
- **Ein Preisraster für alle Quellen.** `bucket_px()` an genau einer Stelle, jede Quelle
  ruft sie. M10 kann dann nicht mehr entstehen.
- **Fixture-Tests aus echten Antworten.** Je Endpunkt eine aufgezeichnete Rohantwort
  (Binance `forceOrder`, Coinbase `side`, HL `clearinghouseState`, `userFillsByTime`), und
  der Parser muss daraus die erwartete Zeile erzeugen — mit der erwarteten **Einheit**.
- **Regressionstests für C1–C3**, die auf der alten Fassung nachweislich scheitern.
- **Git auf dem Pi.** Jede Auslieferung ein Commit, `update.py` prüft gegen den Stand.
  „Beim Löschen zu viel erwischt" wird damit ein Diff, keine Erinnerung.
- **Schema-Dokument mit Einheiten** je Spalte, aus dem Code erzeugt, nicht von Hand.

---

## 6. Prioritäten, Reihenfolge, Messung

| P | Maßnahme | Aufwand | Messung vorher / nachher |
|---|---|---|---|
| **0 ✓** | n_eff, λ = 4/n_eff, Mindest-n je Treiber, Gewichte je Horizont, β | erledigt | Nulltest: Gewichte auf Rauschen ≤ 0,01 (vorher bis 0,12) |
| **0 ✓** | M9 fertig (Rang + Untergrenze), M6, M10 | erledigt | `check_m9.py` auf dem Pi laufen lassen; Reversal-Quote weist Fälle ohne Ergebnis aus |
| **0 ✓** | Nulltest und Einheiten-Invarianten in `--selftest` | erledigt | ms-Zeile → Audit Exit 1 (geprüft); Nulltest 0,3 s |
| **0 ✓** | Wilson-Intervalle, Basisrate, Brier im Dashboard | erledigt | jede Quote mit Intervall sichtbar (Browsertest) |
| **1** | Anhang A ausführen: Pareto, Fill-Verbraucher, Poll-Takte | 1 h | die Zahlen, die 2.4 braucht |
| **1 ✓** | Konto-Score mit Vorlauf, Edge je Umsatz, Konsistenz; Tabelle `account_score` | erledigt (`hl_score.py`, `lb_stats`) | Score-Test läuft wöchentlich, erster Wert nach 7 Tagen |
| **1** | Fills nur direktional / gemischt; Orders nur S1 / S2 | ½ Tag | Rückstand 0, Order-Abdeckung S1 / S2 = 100 % |
| **1** | Stufen S1–S5 + Sichtung nach Handelsgröße | 1 Tag | Gewicht/min ≤ 850, Heatmap-Masse unverändert |
| **1** | WebSocket-Abonnements für S1 | 1 Tag | Fill-Latenz S1 < 5 s, REST-Gewicht S1 ≈ 44 |
| **1 ✓** | Smart-Flow, Elite-Positionierung, Gegen-Flow (Experiment) | erledigt; Hedge/MM/gemischt-Flow gestrichen | 4-h-Trefferquote je Treiber mit Intervall ab n_eff 50 |
| **2** | M1–M3 Liquidationsableitung | 1 Tag | abgeleitete gegen Binance-Liquidationen im selben Fenster |
| **2 ✓** | Magnet-Placebo, Reversal-Placebo, Ensemble-Posterior, Analog-Basisrate | erledigt (vorgezogen) | Magnet-Lift mit Intervall im Dashboard |
| **2** | Treiber-Familien | ½ Tag | Familiengewichte stabil bei n_eff 50 |
| **2** | Live-Abrufe in den Binance-Dienst; Leaderboard als Wal-Liste | ½ Tag | Chart-Antwortzeit, Sichtungsdauer neuer Großkonten |
| **3** | Konfluenz auf Prognose-Beiträge; M4, M5, M12, M13, M15, M16; Zeitprofil 180 T; Git | 1 Tag | Betriebssauberkeit |

**Reihenfolge ist Absicht:** P0 macht jede spätere Zahl erst glaubwürdig. Ohne n_eff und
Intervalle würde P1 nach zwei Wochen „bewiesen" — mit derselben Selbsttäuschung wie heute.

---

## 7. Woran nach vier Wochen zu erkennen ist, ob es trägt

- Score-Test: Spearman-Korrelation Score → Vorlauf der Folgewoche **positiv mit Intervall
  über null**, in mindestens drei der vier Wochen. Sonst ist die Regel für diesen Markt
  falsch — auch das wäre ein Ergebnis, und ein wichtiges.
- Komponente Größe: Korrelation ausgewiesen. Sie entscheidet, ob „größte" oder „beste"
  das richtige Wort war.
- Smart-Flow: 1-h-Trefferquote mit Wilson-Intervall über der Drift-Basisrate.
- Kein Treibergewicht auf weniger als 50 unabhängigen Fällen; geparkte Treiber sichtbar.
- Fill-Rückstand dauerhaft 0; S1-Fills in Echtzeit; API-Gewicht unter 850 mit Reserve.
- Magnet-Lift mit Intervall ausgewiesen — egal, wie er ausfällt.
- Selbsttest enthält Nulltest und Einheiten-Invarianten und ist grün.

---

## 8. Was ich für die Umsetzung brauche

1. `hl_liq_project.zip` — der aktuelle Stand vom 13.09.
2. Die Ausgaben aus Anhang A (fünf Abfragen, laufen auf dem Pi in Minuten).
3. Ein `check_forecast.py`-Lauf und ein `check_leaderboard.py`-Lauf von heute.

Der erste Arbeitsschritt ist dann **Messen, nicht Ändern**: Nulltest auf der heutigen
Fassung (er wird rot), Pareto der Heatmap-Masse, Fill-Verbraucher nach Klasse. Erst mit
diesen drei Zahlen werden die Stufen aus 2.4 festgelegt.

---

## 9. Was an diesem Konzept unsicher ist

- **Vorlauf setzt Konsistenz voraus.** Systematische Händler haben sie, Fonds mit
  wechselnden Strategien nicht. Die Schrumpfung mit k = 20 dämpft, garantiert nichts.
- **Score je Coin** vervielfacht die Datenknappheit. Ein BTC-Könner ist bei HYPE vielleicht
  keiner; bei ZEC, XMR, PAXG wird es lange keine belastbaren Scores geben.
- **Der Gegen-Flow** ist die riskanteste Idee — verlieren Konten, weil sie zufällig handeln,
  ist ihr Fluss Rauschen. Prior 0,3, Killkriterium, kein Sonderstatus.
- **Die Stufenzahlen in 2.4 sind Annahmen.** Sie können um den Faktor zwei danebenliegen;
  deshalb steht Anhang A vor der Umsetzung.
- **WebSocket-Stabilität auf dem Pi** über Tage ist nicht erprobt; deshalb bleibt REST als
  Fallback mit `lb_gaps`-Protokoll.
- **Vier Wochen** reichen für 1-h- und 4-h-Aussagen. Für 24 h braucht es Monate — das
  Dashboard soll das mit n_eff sichtbar machen, statt es zu verschweigen.

---

## Anhang A — Messungen vor der Umsetzung (SQLite, auf dem Pi)

**A1 Pareto der Heatmap-Masse** — tragen die obersten 1.000 Adressen über 90 %?

    WITH r AS (
      SELECT pos_value,
             ROW_NUMBER() OVER (ORDER BY pos_value DESC) AS rn,
             SUM(pos_value) OVER () AS gesamt
      FROM addresses WHERE pos_value > 0)
    SELECT rn,
           ROUND(100.0 * SUM(pos_value) OVER (ORDER BY rn ROWS UNBOUNDED PRECEDING) / gesamt, 1) AS anteil
    FROM r WHERE rn IN (100, 500, 1000, 5000, 20000);

**A2 Fill-Verbraucher** — wer erzeugt die Fills, und welche Klasse hat er?

    SELECT addr, ROUND(COUNT(*) / 7.0) AS fills_je_tag,
           ROUND(20 + COUNT(*) / 7.0 / 20) AS gewicht_je_tag_mind
    FROM lb_fills WHERE ts >= strftime('%s','now') - 7 * 86400
    GROUP BY addr ORDER BY 2 DESC LIMIT 25;

Ergebnis mit der Verhaltensklasse abgleichen. Erwartung: Die Spitze sind Market Maker.

**A3 Tatsächliche Poll-Takte je Wertstufe** — wie oft wird welche Stufe heute abgefragt?

    SELECT CASE WHEN pos_value >= 20e6 THEN 'S2 Wal'
                WHEN pos_value >= 1e6  THEN 'S3'
                WHEN pos_value >= 250e3 THEN 'S4'
                WHEN pos_value > 0     THEN 'S5'
                ELSE 'leer' END AS stufe,
           COUNT(*) AS konten,
           ROUND(AVG(strftime('%s','now') - last_poll) / 60) AS alter_min_mittel
    FROM addresses GROUP BY 1;

**A4 n gegen n_eff je Coin** — wie viel unabhängige Information hat die Kalibrierung?

    SELECT coin, COUNT(DISTINCT ts / 900) AS fenster,
           ROUND(COUNT(DISTINCT ts / 900) / 4.0)  AS n_eff_1h,
           ROUND(COUNT(DISTINCT ts / 900) / 16.0) AS n_eff_4h,
           ROUND(COUNT(DISTINCT ts / 900) / 96.0) AS n_eff_24h
    FROM forecast WHERE ts <= strftime('%s','now') - 86400 GROUP BY coin;

(gegen `forecasts.db`)

**A5 Signal-Feuerrate vorher** — Referenz für M9: Stunden mit `abs(z30) >= 2.5` in den
letzten 7 Tagen je Coin, aus den Wal-Ereignissen; nach der Umstellung dieselbe Zählung mit
Rang ≥ 98 % plus Untergrenze.

---

## Anhang B — Gewichtsformeln (Referenz, heute in der Dokumentation geprüft)

- REST: 1.200 Gewicht je Minute und IP, nicht erhöhbar.
- `clearinghouseState`, `l2Book`, `allMids`, `orderStatus`: 2. `userRole`: 60. Übrige
  Info-Abfragen: 20.
- `userFillsByTime`, `userFills`, `historicalOrders`, `recentTrades`, `fundingHistory`
  u. a.: zusätzlich 1 je 20 gelieferte Einträge. `candleSnapshot`: 1 je 60.
- WebSocket: 100 Verbindungen, 1.000 Abonnements, **10 verschiedene Nutzer** über
  nutzerbezogene Abonnements, 2.000 gesendete Nachrichten je Minute.
