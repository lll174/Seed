#!/usr/bin/env python3
"""
hl_magnet.py -- Magnet-Test (U110, KONZEPT_Fusion.md Stufe 2; 04.10.2026, Version 2026-09-23.45). Nur MESSUNG im Schatten:
kein Treiber, keine Wirkung auf Prognose, v1, v2, v3, Fusion oder Labor.

Frage: Berührt der Kurs Liquidationscluster öfter, als ein Zufallsweg mit der richtigen Schwankung erwarten lässt? Dann zögen
Cluster den Kurs an („Magnet“). Die Kaskaden-Gleichung (hl_kaskade) fragt, ob es NACH dem Erreichen weitergeht -- hier geht es
um das Erreichen selbst.

1. NULLMODELL: P(größter Ausschlag einer Seite binnen h ≥ d) mit gemischter Schwankung, genau das Modell „ohne Heatmap“ der
   Kaskaden-Gleichung (hl_kaskade seit 23.44): Σ_k w_k(τ) · erfc(d / (c · e^{0,05k} · σ_h · √2)). c und τ je Coin und
   Horizont OUT-OF-FOLD (5 Folds über die Zeit, Embargo ein Block) -- jeder Block wird mit Parametern bewertet, die ihn nicht
   gesehen haben. Auf dem Pi stimmte dieses Modell am 04.10. in allen Coins (vorhergesagt ≈ eingetreten, ≥ 1 σ und ≥ 2 σ).
2. FÄLLE: je Block (erster Heatmap-Stand im Block, hl_kaskade.bloecke), Seite und Größenklasse das NÄCHSTE Cluster dieser Klasse
   bis 3 σ_h Abstand: berührt, wenn der größte Ausschlag dieser Seite binnen h mindestens seine Tiefe erreicht. Nur das nächste
   je Klasse: Cluster dahinter erreicht der Kurs erst über das erste (und über Kaskaden, die misst hl_kaskade).
   Größenklassen nach Notional / Tagesumsatz: klein < 0,5 %, mittel 0,5–2 %, groß ab 2 %.
3. ÜBERSCHUSS je Klasse: Mittel von (berührt − P_null), beide Seiten gleich gewichtet (ein Trend hebt Berührungen unten und
   senkt sie oben -- gleich gewichtet hebt sich das auf), Standardfehler mit Tagen als Klumpen.
4. KONTROLLEN, je gepaart:
   Spiegel   -- dasselbe Niveau im gleichen Abstand auf der ANDEREN Seite (gleiches P_null): Berührt der Kurs dort genauso
                oft, ist es keine Anziehung, sondern Schwankung, die mit nahen Clustern auf BEIDEN Seiten steigt.
   Placebo   -- die Cluster des Blocks drei Tage vorher (echte Tiefen und Größen, falsche Zeit) mit Ausschlag und Nullmodell
                des Blocks: fängt, was an Tiefen und Größen der Cluster liegt statt an der Karte des Augenblicks.
   Zufallsniveaus -- feste Abstände 0,25 … 3 σ_h auf beiden Seiten: prüft das Nullmodell selbst über alle Abstände.
5. BELEGT je Klasse: mindestens 60 WIRKSAME Fälle, Überschuss > 2 SE, Überschuss minus Spiegel > 2 SE und minus Placebo > 2 SE.
   Wirksam (Kish) beim seitengleichen Mittel: 4 · n_unten · n_oben / (n_unten + n_oben) -- 30 + 30 Fälle zählen 60, 300 + 0
   zählen 0: mit nur einer Seite ist das Mittel nicht trendfest (Selbsttest „Trendfalle“).
GRENZE: Belegt heißt, die Karte des Augenblicks sagt Berührungen vorher. Ob das Cluster den Kurs zieht oder an einem Niveau
liegt, zu dem der Kurs ohnehin läuft, trennt der Test nicht (Selbsttest „Niveau-Welt“) -- für einen Treiber, der vorhersagen
soll, gleich; für die Deutung („Magnet“) nicht.

Ergebnis im Prognosespeicher (learned coin/„magnet“, gilt 3 Tage), Takt alle 6 h im Familien-Takt des Dashboards nach der
Kaskaden-Gleichung. Ein Treiber „Zug“ (Σ Notional · P_Berührung oben minus unten) kommt erst, wenn eine Klasse belegt ist.

Selbsttest: python3 hl_magnet.py --nulltest · Stand: python3 hl_magnet.py --stand --db PFAD · jetzt: --kalibrieren --db PFAD
"""
import math
import os
import sqlite3
import sys
import time

import numpy as np

import hl_forecast as F
import hl_kaskade as K

VERSION = 1
NAME = "Magnet-Test"
KLASSEN = (("klein", 0.0, 0.005), ("mittel", 0.005, 0.02), ("groß", 0.02, math.inf))   # Notional / Tagesumsatz
X_MAX = 3.0                                     # Cluster bis 3 σ_h Abstand (weiter weg: kaum berührbar)
ZUFALL_X = (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0)
HORIZONTE = (1, 4)
MIN_FAELLE = 60                                 # je Klasse und Horizont, sonst kein Urteil
TAGE = 90
MODELL_ALTER = 3 * 86_400


# ------------------------------------------------------------------------------------------------ Rechnung
def nullmodell(bl: list) -> dict:
    """c, τ des Modells ohne Heatmap je Block OUT-OF-FOLD (Index in K.PARAM, −1 ohne Urteil) -- dieselbe Kreuzvalidierung wie
    die Kaskaden-Kalibrierung, nur mit Y = 0 (H(m) = m); dazu das Paar auf allen Blöcken (Anzeige)."""
    sig_h = np.array([b["sig_h"] for b in bl])
    E = np.array([[[1.0 if b["M"][k] >= x * b["sig_h"] else 0.0 for x in K.SCHWELLEN] for k in range(2)] for b in bl])
    H0 = np.broadcast_to(np.array(K.SCHWELLEN)[None, None, None, :] * sig_h[:, None, None, None], (len(bl), 1, 2, len(K.SCHWELLEN)))
    L0 = K._verluste(np.ascontiguousarray(H0), sig_h, E)
    w = K._waehlen(L0, [b["ts"] // 86_400 for b in bl])
    cf = w.get("c_fold")
    idx = np.full(len(bl), -1, dtype=int)
    if cf is not None:
        ok = np.isfinite(cf[0])
        idx[ok] = cf[0, ok].astype(int)
    alle = int(L0[0].sum(axis=1).argmin())
    return {"idx": idx, "c": round(K.C_GITTER[K.PARAM[alle][0]], 4), "tau": K.T_GITTER[K.PARAM[alle][1]]}


def p_null(x: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """P(Ausschlag ≥ x · σ_h) je Fall mit dem Parameter seines Blocks (x normiert, idx Index in K.PARAM)."""
    x = np.asarray(x, dtype=float); idx = np.asarray(idx, dtype=int); out = np.full(x.shape, np.nan)
    for j in np.unique(idx[idx >= 0]):
        sel = idx == j
        out[sel] = K._p_tabelle(x[sel], [K.PARAM[j]])[0]
    return out


def klasse(q: float, v_tag: float) -> int | None:
    a = q / v_tag if v_tag else 0.0
    for i, (_, lo, hi) in enumerate(KLASSEN):
        if lo <= a < hi:
            return i
    return None


def naechste(cl_seite: tuple, v_tag: float, sig_h: float) -> dict:
    """Je Größenklasse das nächste Cluster (Tiefe in σ_h) bis X_MAX auf einer Seite: {Klasse: x}."""
    d, q = cl_seite; out: dict = {}
    for dd, qq in zip(d, q):                                                   # Tiefen aufsteigend (hl_kaskade.cluster_aus)
        x = dd / sig_h
        if x > X_MAX:
            break
        k = klasse(qq, v_tag)
        if k is not None and k not in out:
            out[k] = x
    return out


def faelle(bl: list, karten: list | None = None) -> list:
    """Fälle (Block, Seite, Klasse, x): aus den eigenen Clustern des Blocks oder aus fremden Karten (Placebo; None = keiner)."""
    out = []
    for i, b in enumerate(bl):
        cl = b["cl"] if karten is None else karten[i]
        if cl is None:
            continue
        for s, seite in enumerate(("ab", "auf")):
            for k, x in naechste(cl[seite], b["v_tag"], b["sig_h"]).items():
                out.append((i, s, k, x))
    return out


def _balanciert(v, seite, tage, p=None) -> tuple:
    """Mittel von v mit beiden Seiten gleich gewichtet (ein Trend hebt Berührungen auf der einen Seite und senkt sie auf der
    anderen -- gleich gewichtet hebt sich das auf) und klumpenrobustem Standardfehler (Tage als Klumpen). Boden: der binomiale
    Standardfehler aus den Vorhersagen p, damit wenige Ereignisse keinen Fehler von 0 vortäuschen."""
    v = np.asarray(v, dtype=float); seite = np.asarray(seite); n0 = int((seite == 0).sum()); n1 = int((seite == 1).sum())
    w = np.where(seite == 0, 0.5 / max(n0, 1), 0.5 / max(n1, 1)) if (n0 and n1) else np.full(len(v), 1.0 / len(v))
    m = float((w * v).sum()); g: dict = {}
    for t, x in zip(np.asarray(tage).tolist(), (w * (v - m)).tolist()):
        g[t] = g.get(t, 0.0) + x
    G = len(g); se = math.sqrt(G / (G - 1) * sum(x * x for x in g.values())) if G > 1 else float("nan")
    if p is not None:
        p = np.asarray(p, dtype=float); boden = math.sqrt(float((w * w * p * (1 - p)).sum()))
        se = boden if not np.isfinite(se) else max(se, boden)
    return m, se


def n_wirksam(n_ab: int, n_auf: int) -> float:
    """Wirksame Fallzahl des seitengleich gewichteten Mittels (Kish: 1 / Σ w² mit w = ½ / n je Seite). Fehlt eine Seite, 0:
    dann gibt es keinen Seitenausgleich, und ein Trend sähe aus wie Anziehung."""
    return 4.0 * n_ab * n_auf / (n_ab + n_auf) if n_ab > 0 and n_auf > 0 else 0.0


def bedingungen(r: dict) -> dict:
    """Die vier Bedingungen für „belegt“ je Klasse und Horizont (Werte wie gespeichert)."""
    def ueber_2se(a, se):
        return a is not None and se is not None and se > 0 and a > 2 * se
    return {"Fälle": (r.get("n_wirksam") or 0.0) >= MIN_FAELLE,
            "Überschuss": ueber_2se(r.get("ueber"), r.get("se")),
            "Spiegel": ueber_2se(r.get("spiegel"), r.get("se_spiegel")),
            "Placebo": ueber_2se(r.get("placebo_diff"), r.get("se_placebo"))}


def belegt_regel(r: dict) -> bool:
    return all(bedingungen(r).values())


def auswerten(bl: list) -> dict:
    """Überschuss je Klasse mit Spiegel und Placebo, Zufallsniveaus, Nullmodell -- für einen Coin und Horizont. Alle Mittel mit
    beiden Seiten gleich gewichtet (trendfest), Standardfehler mit Tagen als Klumpen."""
    nm = nullmodell(bl); idx = nm["idx"]
    tage = np.array([b["ts"] // 86_400 for b in bl]); M = np.array([b["M"] for b in bl]); sig_h = np.array([b["sig_h"] for b in bl])
    out = {"n_bloecke": len(bl), "tage": round((bl[-1]["ts"] - bl[0]["ts"]) / 86_400, 1) if bl else 0, "c0": nm["c"], "tau0": nm["tau"],
           "klassen": {}, "zufall": []}
    f = [x for x in faelle(bl) if idx[x[0]] >= 0]
    karten, mp = K._placebo(bl)
    fp = [x for x in faelle(bl, [karten[i] if mp[i] else None for i in range(len(bl))]) if idx[x[0]] >= 0]
    r4 = lambda x: round(float(x), 4) if x is not None and np.isfinite(x) else None
    for k, (name, _, _) in enumerate(KLASSEN):
        fk = [x for x in f if x[2] == k]
        r = {"n": len(fk), "belegt": False}
        if fk:
            bi = np.array([x[0] for x in fk]); si = np.array([x[1] for x in fk]); xs = np.array([x[3] for x in fk]); tg = tage[bi]
            p = p_null(xs, idx[bi])
            y = (M[bi, si] >= xs * sig_h[bi]).astype(float)                      # berührt auf der eigenen Seite
            ym = (M[bi, 1 - si] >= xs * sig_h[bi]).astype(float)                 # gleiches Niveau auf der anderen Seite
            ue, se = _balanciert(y - p, si, tg, p)
            sp, se_sp = _balanciert(y - ym, si, tg, p)
            n0, n1 = int((si == 0).sum()), int((si == 1).sum())
            r.update(n_ab=n0, n_auf=n1, n_wirksam=round(n_wirksam(n0, n1), 1), x_mittel=r4(xs.mean()), p=r4(p.mean()), y=r4(y.mean()),
                     y_spiegel=r4(ym.mean()), ueber=r4(ue), se=r4(se), spiegel=r4(sp), se_spiegel=r4(se_sp))
            fpk = [x for x in fp if x[2] == k]
            if len(fpk) >= 10:
                pbi = np.array([x[0] for x in fpk]); psi = np.array([x[1] for x in fpk]); pxs = np.array([x[3] for x in fpk])
                pp = p_null(pxs, idx[pbi])
                pu, pse = _balanciert((M[pbi, psi] >= pxs * sig_h[pbi]).astype(float) - pp, psi, tage[pbi], pp)
                d_ = ue - pu; se_d = math.sqrt(se ** 2 + pse ** 2)                    # Placebo und echt teilen Blöcke: konservativ
                r.update(placebo_n=len(fpk), placebo_ueber=r4(pu), placebo_diff=r4(d_), se_placebo=r4(se_d))
            r["belegt"] = belegt_regel(r)
        out["klassen"][name] = r
    gueltig = idx >= 0
    if gueltig.any():
        bi = np.nonzero(gueltig)[0]
        for xz in ZUFALL_X:
            p = p_null(np.full(len(bi), xz), idx[bi])
            y = (M[bi] >= xz * sig_h[bi][:, None]).astype(float)                 # beide Seiten
            v = np.concatenate([y[:, 0] - p, y[:, 1] - p]); sei = np.concatenate([np.zeros(len(bi)), np.ones(len(bi))])
            m_, se_ = _balanciert(v, sei, np.concatenate([tage[bi], tage[bi]]), np.concatenate([p, p]))
            out["zufall"].append([xz, r4(p.mean()), r4(y.mean()), r4(se_)])
    return out


def kalibrieren(con, coin: str, now: int | None = None, path: str | None = None, speichern: bool = True, tage: int = TAGE,
                horizonte: tuple = HORIZONTE) -> dict:
    """Magnet-Test je Horizont über die Historie (bis 90 Tage); speichert learned coin/„magnet“."""
    import hl_anker
    now = int(now or time.time()); von = now - tage * 86_400
    M = hl_anker.Markt(con, coin, von, now)
    out = {"version": VERSION, "coin": coin, "ts": now, "h": {}, "min_faelle": MIN_FAELLE}
    for h in horizonte:
        bl = K.bloecke(con, coin, h, von, now, M)
        if len(bl) < K.MIN_BLOECKE:
            out["h"][str(h)] = {"n_bloecke": len(bl), "zu_wenig": True}
            continue
        out["h"][str(h)] = auswerten(bl)
    if speichern:
        F.learned_save(coin, "magnet", out, path=path or F.STORE)
    return out


def modell_laden(coin: str, path: str | None = None) -> dict | None:
    try:
        m = F.learned_load(coin, "magnet", MODELL_ALTER, path=path or F.STORE)
    except Exception:
        return None
    return m if isinstance(m, dict) and m.get("version") == VERSION else None


def takt(con, path: str | None = None, now: int | None = None) -> dict:
    """Alle 6 h aus dem Familien-Takt (nach der Kaskaden-Gleichung): je Coin mit Prognosen der letzten 24 h; Fehler je Coin sichtbar."""
    now = int(now or time.time()); erg = {}
    st = F.store_connect(path or F.STORE)
    try:
        coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ?", (now - 86_400,))]
    finally:
        st.close()
    for c in coins:
        try:
            m = kalibrieren(con, c, now, path=path)
            erg[c] = {h: [n for n, r in (v.get("klassen") or {}).items() if r.get("belegt")] for h, v in m["h"].items()}
        except Exception as e:
            erg[c] = {"fehler": f"{type(e).__name__}: {e}"}
            F.learned_save(c, "magnet", {"version": VERSION, "coin": c, "ts": now, "fehler": erg[c]["fehler"]}, path=path or F.STORE)
    return erg


# ------------------------------------------------------------------------------------------------ Bericht
def _zahl(x, d: int = 1, vz: bool = False) -> str:
    """Zahl mit Dezimalkomma (vz: mit Vorzeichen)."""
    return f"{x:{'+' if vz else ''}.{d}f}".replace(".", ",")


def _pc(x, d: int = 1) -> str:
    return "—" if x is None else f"{x * 100:.{d}f} %".replace(".", ",")


def _pt(x, se=None) -> str:
    """Punkte mit Vorzeichen (Anteile ·100), optional ± SE."""
    if x is None:
        return "—"
    t = f"{x * 100:+.1f}".replace(".", ",")
    return t + (f" ± {f'{se * 100:.1f}'.replace('.', ',')}" if se is not None else "")


def stand_text(con=None, path: str | None = None, now: int | None = None, coins: list | None = None) -> str:
    now = int(now or time.time())
    z = ["Magnet-Test (U110) -- berührt der Kurs Liquidationscluster öfter als der Zufall? Messung, kein Treiber",
         "Nullmodell: P(Ausschlag ≥ d binnen h) mit gemischter Schwankung (c, τ out-of-fold, wie „ohne Heatmap“ der Kaskaden-Gleichung)",
         "Fälle: je Block, Seite und Größenklasse (Notional / Tagesumsatz: klein < 0,5 %, mittel 0,5–2 %, groß ab 2 %) das nächste Cluster "
         f"bis {X_MAX:g} σ_h · Überschuss = berührt − vorhergesagt, beide Seiten gleich gewichtet · Spiegel = gleiches Niveau auf der "
         "anderen Seite · Placebo = Heatmap von 3 Tagen vorher",
         f"Belegt je Klasse: ab {MIN_FAELLE} wirksamen Fällen (4 · unten · oben / (unten + oben)) Überschuss, Überschuss minus Spiegel und "
         "minus Placebo je > 2 SE (Tage als Klumpen)", ""]
    if coins is None:
        st = F.store_connect(path or F.STORE)
        try:
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ? ORDER BY coin", (now - 86_400,))]
        finally:
            st.close()
    belegt = []
    for coin in coins:
        mod = modell_laden(coin, path)
        if not mod:
            z.append(f"{coin} · noch keine Rechnung (alle 6 h im Familien-Takt des Dashboards, erstmals 20 min nach dem Start)"); z.append("")
            continue
        if mod.get("fehler"):
            z.append(f"{coin} · Fehler {mod['fehler']}"); z.append("")
            continue
        z.append(f"{coin} · Rechnung vom {time.strftime('%d.%m. %H:%M', time.localtime(mod['ts']))}")
        for h in ("1", "4"):
            m = (mod.get("h") or {}).get(h) or {}
            if not m:
                continue
            if m.get("zu_wenig"):
                z.append(f"   {h} h: zu wenige Blöcke ({m.get('n_bloecke')} von {K.MIN_BLOECKE})"); continue
            z.append(f"   {h} h: {m['n_bloecke']} Blöcke in {str(m['tage']).replace('.', ',')} Tagen · Nullmodell c {_zahl(m['c0'], 2)}, τ {_zahl(m['tau0'], 1)}")
            for name, r in (m.get("klassen") or {}).items():
                if not r.get("n"):
                    z.append(f"      {name:<6}: keine Cluster bis {X_MAX:g} σ"); continue
                xm = f"{r['x_mittel']:.2f}".replace(".", ",")
                z.append(f"      {name:<6}: {r['n']} Fälle ({r.get('n_ab', 0)} unten, {r.get('n_auf', 0)} oben, wirksam "
                         f"{r.get('n_wirksam') or 0:.0f}), Ø {xm} σ · berührt {_pc(r['y'])}, vorhergesagt {_pc(r['p'])} → "
                         f"Überschuss {_pt(r['ueber'], r.get('se'))} Punkte · Spiegel {_pc(r['y_spiegel'])} (echt minus Spiegel "
                         f"{_pt(r['spiegel'], r.get('se_spiegel'))}) · Placebo-Überschuss {_pt(r.get('placebo_ueber'))} (echt minus Placebo "
                         f"{_pt(r.get('placebo_diff'), r.get('se_placebo'))}, {r.get('placebo_n', 0)} Placebo-Fälle) → {_urteil(r)}")
                if r["belegt"]:
                    belegt.append(f"{coin} {h} h {name}")
            zf = m.get("zufall") or []
            ok = [abs(y - p) <= 2 * se for _, p, y, se in zf if se]
            z.append(f"      Nullmodell an Zufallsniveaus (vorhergesagt → berührt): " + " · ".join(f"{str(x).replace('.', ',')} σ {_pc(p)} → {_pc(y)}"
                                                                                       for x, p, y, _ in zf)
                     + f" · {sum(ok)} von {len(ok)} innerhalb 2 SE")
        z.append("")
    z.append("Belegt: " + (", ".join(belegt) if belegt else "nichts") + ". Bei 6 Coins, 2 Horizonten und 3 Klassen sind 36 Tests im Spiel: "
             "ein einzelner Befund knapp über 2 SE kann Zufall sein, belastbar ist erst, was über Wochen bleibt.")
    z.append("Grenze: Belegt heißt, die Karte des Augenblicks sagt Berührungen vorher. Ob das Cluster den Kurs zieht oder an einem Niveau "
             "liegt, zu dem der Kurs ohnehin läuft, trennt der Test nicht (Selbsttest „Niveau-Welt“).")
    return "\n".join(z)


def _urteil(r: dict) -> str:
    """BELEGT oder „nicht belegt (…)“ mit den Bedingungen, die fehlen."""
    if r.get("belegt"):
        return "BELEGT"
    b = bedingungen(r); fehlt = []
    if not b["Fälle"]:
        fehlt.append("nur eine Seite" if not (r.get("n_ab") and r.get("n_auf"))
                     else f"zu wenige Fälle (wirksam {r.get('n_wirksam') or 0:.0f} von {MIN_FAELLE})")
    fehlt += [f"{k} ≤ 2 SE" for k in ("Überschuss", "Spiegel") if not b[k]]
    if not b["Placebo"]:
        fehlt.append("Placebo ≤ 2 SE" if r.get("se_placebo") is not None else "kein Placebo")
    return "nicht belegt (" + ", ".join(fehlt) + ")"


# ------------------------------------------------------------------------------------------------ Selbsttest
def _zeigen(pruef: list, verbose: bool) -> None:
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<62} {txt}")


def mathe_probe(verbose: bool = True) -> tuple:
    pruef = []
    # nächstes Cluster je Klasse: Tiefen aufsteigend, Klassen nach Notional / Tagesumsatz, nichts jenseits 3 σ
    v = 1e9; sig = 0.01
    cl = ([0.002, 0.004, 0.006, 0.012, 0.035], [1e6, 3e7, 2e6, 6e6, 9e7])          # 0,1 %, 3 %, 0,2 %, 0,6 %, 9 %
    n = naechste(cl, v, sig); n2 = naechste(([0.025, 0.035], [1e6, 9e7]), v, sig)  # groß nur in 3,5 σ: zählt nicht
    ok = n == {0: 0.2, 2: 0.4, 1: 1.2} and n2 == {0: 2.5}
    pruef.append(("Mathe: nächstes Cluster je Größenklasse bis 3 σ", ok, " · ".join(f"{KLASSEN[k][0]} {_zahl(x, 1)}" for k, x in n.items())
                  + " σ (soll klein 0,2 · groß 0,4 · mittel 1,2 σ) · nur klein 2,5 σ und groß 3,5 σ → "
                  + (" · ".join(f"{KLASSEN[k][0]} {_zahl(x, 1)} σ" for k, x in n2.items()) or "nichts") + " (soll nur klein)"))
    # Nullmodell = Einzelrechnung der Kaskaden-Gleichung
    xs = np.array([0.25, 1.0, 2.0, 3.0]); j = K.PARAM.index((10, 2))
    abw = max(abs(float(a) - K.p_ueber(x, K.C_GITTER[10], 1.0, K.T_GITTER[2])) for a, x in zip(p_null(xs, np.full(4, j)), xs))
    pruef.append(("Mathe: Nullmodell = P der Kaskaden-Gleichung (Y = 0)", abw < 1e-6, f"größte Abweichung {abw:.1e}"))
    # Nullmodell out-of-fold: bekommt Fold 1 doppelt so weite Ausschläge, bleibt SEIN Parameter (er stammt aus den anderen
    # Folds); die anderen Folds und das Paar auf allen Blöcken sehen die Änderung
    rng = np.random.default_rng(7); B = 300; f1 = B // K.FOLDS
    bl = [{"ts": K.PROBE_NOW + i * 3600, "sig_h": 0.01, "M": tuple(0.01 * np.abs(rng.standard_normal(2)))} for i in range(B)]
    a = nullmodell(bl); b = nullmodell([dict(x, M=(2 * x["M"][0], 2 * x["M"][1])) if i < f1 else x for i, x in enumerate(bl)])
    eigen = bool(np.array_equal(a["idx"][:f1], b["idx"][:f1])); rest = int((a["idx"][f1 + 1:] != b["idx"][f1 + 1:]).sum())
    pruef.append(("Mathe: Nullmodell out-of-fold (eigene Ausschläge ändern den eigenen Parameter nicht)",
                  eigen and rest > 0 and (a["c"], a["tau"]) != (b["c"], b["tau"]) and bool((a["idx"] >= 0).all()),
                  f"Fold 1 mit doppelten Ausschlägen: sein Parameter {'gleich' if eigen else 'GEÄNDERT'}; geändert in {rest} anderen Blöcken; "
                  f"Paar auf allen Blöcken c {_zahl(a['c'], 2)} und τ {_zahl(a['tau'], 1)} → c {_zahl(b['c'], 2)} und τ {_zahl(b['tau'], 1)}"))
    # Seitenausgleich: Trend +a unten, −a oben, 30 gegen 10 Fälle → Mittel 0 (ungleich gewichtet a/2); Boden des Standardfehlers
    v = np.array([0.1] * 30 + [-0.1] * 10); s_ = np.array([0] * 30 + [1] * 10); tg = np.arange(40) // 4
    m_, _ = _balanciert(v, s_, tg)
    m1, se1 = _balanciert(np.full(40, 0.1), s_, tg, np.full(40, 0.9))
    boden = math.sqrt(0.09 * (30 * (0.5 / 30) ** 2 + 10 * (0.5 / 10) ** 2))
    pruef.append(("Mathe: Seitenausgleich hebt einen Trend auf, Standardfehler nie unter dem binomialen",
                  abs(m_) < 1e-12 and abs(m1 - 0.1) < 1e-12 and abs(se1 - boden) < 1e-12 and n_wirksam(30, 30) == 60.0
                  and n_wirksam(300, 0) == 0.0 and abs(n_wirksam(200, 20) - 8000 / 110) < 1e-9,
                  f"+0,1 unten (30 Fälle) und −0,1 oben (10) → {_zahl(round(m_, 9) + 0.0, 3, True)} (ungleich gewichtet +0,050) · ohne Streuung "
                  f"SE {_zahl(se1, 4)} = Boden {_zahl(boden, 4)} · wirksam: 30 + 30 → {_zahl(n_wirksam(30, 30), 0)}, 300 + 0 → "
                  f"{_zahl(n_wirksam(300, 0), 0)}, 200 + 20 → {_zahl(n_wirksam(200, 20), 1)}"))
    # Belegt nur mit allen vier Bedingungen; genau 2 SE reicht nicht
    r0 = {"n_wirksam": 100.0, "ueber": 0.05, "se": 0.01, "spiegel": 0.05, "se_spiegel": 0.01, "placebo_diff": 0.05, "se_placebo": 0.01}
    varianten = {"Fälle": {"n_wirksam": MIN_FAELLE - 0.1}, "Überschuss": {"ueber": 0.02}, "Spiegel": {"spiegel": 0.02},
                 "Placebo": {"placebo_diff": 0.02}, "ohne Placebo": {"placebo_diff": None, "se_placebo": None},
                 "SE 0": {"se": 0.0}}
    falsch = [k for k, d in varianten.items() if belegt_regel(dict(r0, **d))]
    pruef.append(("Mathe: belegt nur mit allen vier Bedingungen", belegt_regel(r0) and not falsch,
                  f"alle erfüllt → belegt; je eine verletzt ({', '.join(varianten)}) → " + (f"FÄLSCHLICH belegt: {falsch}" if falsch else "nie belegt")))
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def markt_probe(verbose: bool = True) -> tuple:
    """Synthetische Märkte (hl_kaskade._probe_markt, ohne Kaskaden), dieselbe Rechnung wie auf dem Pi: Positivkontrolle
    (Anziehung zu großen Clustern), Nulltest, Fallen -- je eine, die nur eine bestimmte Bedingung aufhält --, die Grenze des
    Tests (Niveau-Welt) und Schwankung mit Gedächtnis."""
    import itertools
    import shutil
    import tempfile
    pruef = []; tmp = tempfile.mkdtemp(prefix="hl_magnet_"); nr = itertools.count()
    try:
        def lauf(seed, nur_unten=False, **kw):
            kw.setdefault("kl_median", 0.01)
            con, now = K._probe_markt(os.path.join(tmp, f"m_{next(nr)}.db"), seed, tage=30, y_wahr=0.0, **kw)
            try:
                if nur_unten:                                                    # nur Long-Cluster unter dem Kurs
                    con.execute("DELETE FROM heatmap WHERE side='short'"); con.commit()
                return kalibrieren(con, "BTC", now, speichern=False, tage=30, horizonte=(1,))["h"]["1"]
            finally:
                con.close()
        gr = lambda m: m["klassen"]["groß"]
        alle = lambda ms: [r for m in ms for r in m["klassen"].values() if r.get("n")]
        nie = lambda ms: not any(r["belegt"] for r in alle(ms))
        pos = [lauf(s, magnet=0.03) for s in (1, 2, 3)]                       # Drift 0,03 Teilschritt-σ zum großen Cluster bis 2 σ_4h
        pruef.append(("Positivkontrolle (Anziehung zu großen Clustern): groß belegt", sum(gr(m)["belegt"] for m in pos) >= 2
                      and not any(m["klassen"]["klein"]["belegt"] for m in pos),
                      " · ".join(f"groß {_pt(gr(m).get('ueber'), gr(m).get('se'))}, Spiegel {_pt(gr(m).get('spiegel'), gr(m).get('se_spiegel'))}, "
                                 f"{'belegt' if gr(m)['belegt'] else 'nicht belegt'}" for m in pos)))
        nul = [lauf(s) for s in (1, 2, 3, 4)]
        pruef.append(("Nulltest (Cluster ohne Wirkung): nie belegt", nie(nul),
                      " · ".join(f"groß {_pt(gr(m).get('ueber'), gr(m).get('se'))}" for m in nul)))
        # Störfaktor: liegt ein großes Cluster nah, steigt die Schwankung auf BEIDEN Seiten -- Überschuss und Placebo schlagen an,
        # nur der Spiegel (gleiches Niveau auf der anderen Seite, ebenso oft berührt) hält zurück
        stoer = [lauf(s, kopplung=1.0, kopplung_anteil=0.02) for s in (1, 2, 3, 4)]
        nur_sp = [r for r in alle(stoer) if (b := bedingungen(r))["Fälle"] and b["Überschuss"] and b["Placebo"]]
        pruef.append(("Störfaktor (großes Cluster nah, Schwankung beider Seiten höher): nie belegt", nie(stoer) and len(nur_sp) >= 2,
                      f"Überschuss und Placebo > 2 SE in {len(nur_sp)} Klasse(n) -- nur der Spiegel hält sie zurück · "
                      + " · ".join(f"groß {_pt(gr(m).get('ueber'), gr(m).get('se'))}, Spiegel {_pt(gr(m).get('spiegel'), gr(m).get('se_spiegel'))}"
                                   for m in stoer)))
        # Trendfalle: Abwärtstrend, nur Long-Cluster unter dem Kurs -- der Trend hebt die Berührungen und senkt den Spiegel;
        # es halten „nur eine Seite“ (wirksame Fälle 0) und das Placebo (dieselbe einseitige Lage drei Tage vorher)
        tr1 = [lauf(s, nur_unten=True, drift=-0.03) for s in (1, 2, 3)]
        scharf = [r for r in alle(tr1) if (b := bedingungen(r))["Überschuss"] and b["Spiegel"]]
        n_seite = sum(1 for r in scharf if not bedingungen(r)["Fälle"]); n_pl = sum(1 for r in scharf if not bedingungen(r)["Placebo"])
        pruef.append(("Trendfalle (Abwärtstrend, nur Long-Cluster darunter): nie belegt", nie(tr1) and len(scharf) >= 4,
                      f"Überschuss und Spiegel > 2 SE in {len(scharf)} von {len(alle(tr1))} Klassen -- gehalten von „nur eine Seite“ in "
                      f"{n_seite}, vom Placebo in {n_pl}"))
        # derselbe Trend mit Clustern auf beiden Seiten: der Seitenausgleich hebt ihn auf
        tr2 = [lauf(s, drift=-0.03) for s in (1, 2, 3)]
        ue1 = float(np.mean([r["ueber"] for r in alle(tr1)])); ue2 = float(np.mean([r["ueber"] for r in alle(tr2)]))
        pruef.append(("Trend mit Clustern auf beiden Seiten: Seitenausgleich hebt ihn auf", nie(tr2) and abs(ue2) <= 0.02,
                      f"Überschuss im Mittel über {len(alle(tr2))} Klassen {_pt(ue2)} Punkte (nur eine Seite: {_pt(ue1)})"))
        # Grenze: der Kurs zieht zu festen Niveaus, und dort liegen große Cluster -- die Karte sagt Berührungen vorher, belegt
        niv = [lauf(s, niveau=0.03, kl_median=0.003) for s in (1, 2, 3)]
        pruef.append(("Grenze -- Niveau-Welt (Kurs läuft zu festen Niveaus, dort große Cluster): belegt", sum(gr(m)["belegt"] for m in niv) >= 2,
                      "der Test misst Vorhersage, nicht Ursache · " + " · ".join(
                          f"groß {_pt(gr(m).get('ueber'), gr(m).get('se'))}, Placebo-Überschuss {_pt(gr(m).get('placebo_ueber'))}, "
                          f"{'belegt' if gr(m)['belegt'] else 'nicht belegt'}" for m in niv)))
        sv = [lauf(s, sv_tau=0.6) for s in (1, 2, 3)]
        zuf = [(abs(y - p) <= 2 * se) for m in sv for _, p, y, se in m["zufall"] if se]
        taus = " · ".join(_zahl(m["tau0"], 1) for m in sv)
        pruef.append(("Schwankung mit Gedächtnis: nie belegt, Nullmodell an Zufallsniveaus stimmt",
                      nie(sv) and sum(zuf) >= 0.85 * len(zuf),
                      f"Zufallsniveaus innerhalb 2 SE: {sum(zuf)} von {len(zuf)} · Nullmodell τ {taus}"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def live_probe(verbose: bool = True) -> tuple:
    """Speichern, Laden (nur eigene Version), Bericht -- mit eigenem Prognosespeicher (nie den echten)."""
    import shutil
    import tempfile
    pruef = []; tmp = tempfile.mkdtemp(prefix="hl_magnet_live_"); store_alt = F.STORE
    F.STORE = os.path.join(tmp, "prognosen.db")
    try:
        isoliert = os.path.dirname(F.STORE) == tmp and F.STORE != store_alt                 # nie den echten Speicher
        con, now = K._probe_markt(os.path.join(tmp, "m.db"), 5, tage=12, y_wahr=0.0, kl_median=0.01)
        st = F.store_connect(F.STORE)
        st.execute("CREATE TABLE IF NOT EXISTS forecast_drivers (ts INTEGER, coin TEXT, name TEXT, score REAL)")
        st.execute("INSERT INTO forecast_drivers VALUES (?,?,?,?)", (now - 60, "BTC", "Kaskaden-Asymmetrie", 0.0)); st.commit(); st.close()
        erg = takt(con, now=now)
        m = modell_laden("BTC")
        F.learned_save("BTC", "magnet", dict(m or {}, version=VERSION + 100), path=F.STORE)
        fremd = modell_laden("BTC") is None
        F.learned_save("BTC", "magnet", m, path=F.STORE)
        txt = stand_text(con, now=now, coins=["BTC"])
        ok = (isoliert and "BTC" in erg and "fehler" not in erg["BTC"] and m and set(m["h"]) == {"1", "4"} and fremd
              and all(t in txt for t in ("Nullmodell an Zufallsniveaus", "groß", "wirksam", "Belegt:", "Grenze:")))
        pruef.append(("Live: Takt speichert, fremde Version gilt nicht, Bericht läuft", bool(ok),
                      f"{'eigener' if isoliert else 'ECHTER'} Prognosespeicher · Takt {erg.get('BTC')} · Horizonte "
                      f"{sorted((m or {}).get('h', {}))} · Bericht {len(txt.splitlines())} Zeilen"))
        con.close()
    finally:
        F.STORE = store_alt
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def nulltest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Magnet-Test (U110) -- Selbsttest (Mathematik, Positivkontrolle Anziehung, Nulltest, Fallen für Spiegel, Placebo und "
              "Seitenausgleich, Grenze, Live)")
    ok = True
    for teil in (mathe_probe, markt_probe, live_probe):
        try:
            gut, _ = teil(verbose)
        except Exception as e:
            import traceback
            gut = False
            if verbose:
                print(f"  FEHL {teil.__name__}: {type(e).__name__}: {e}")
                traceback.print_exc()
        ok = ok and gut
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return ok


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Magnet-Test (U110): berührt der Kurs Cluster öfter als der Zufall?")
    ap.add_argument("--nulltest", action="store_true")
    ap.add_argument("--stand", action="store_true")
    ap.add_argument("--kalibrieren", action="store_true")
    ap.add_argument("--db")
    a = ap.parse_args()
    if a.nulltest:
        sys.exit(0 if nulltest() else 1)
    if a.db:
        con_ = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True, timeout=30)
        if a.kalibrieren:
            print("Magnet-Test je Coin (belegte Klassen):", takt(con_))
        print(stand_text(con_))
        con_.close()
    else:
        ap.print_help()
