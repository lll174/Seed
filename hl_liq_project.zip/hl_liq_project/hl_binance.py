#!/usr/bin/env python3
"""
hl_binance.py — Binance-Futures-Daten als Ergänzung zur Hyperliquid-Aufzeichnung.

Schreibt in dieselbe SQLite-Datei wie hl_recorder.py, aber in eigene Tabellen
mit Präfix bnc_. Die Quellen werden bewusst NICHT vermischt: Hyperliquid liefert
gemessene Positionen, Binance liefert Marktaggregate und Liquidationsereignisse.

Was rückwirkend geht (30 Tage):
  - Open Interest (Menge und Notional)
  - Long/Short-Verhältnis der Top-Konten und aller Konten
  - Taker-Buy/Sell-Verhältnis
  - Kerzen (die gehen sogar deutlich weiter zurück)

Was NICHT rückwirkend geht:
  - Liquidationen. Es gibt keinen öffentlichen Verlaufsendpunkt. Der Stream
    !forceOrder@arr sammelt nur vorwärts.

Und eine Einschränkung des Streams, die Binance selbst dokumentiert: Pro Symbol
wird nur die größte Order je 1000 ms gepusht. Während einer Kaskade untertreibt
der Stream also deutlich. Zeitpunkt und Richtung sind verlässlich, das
Gesamtvolumen nicht.

    python hl_binance.py --backfill            # 30 Tage nachladen
    python hl_binance.py                       # Liquidationen live mitschneiden
    python hl_binance.py --status
    python hl_binance.py --selftest            # Parser ohne Netz prüfen

Kein API-Key nötig — alle genutzten Endpunkte sind öffentlich.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import signal
import sqlite3
import sys
import time
import urllib.request
from collections import defaultdict

FAPI = "https://fapi.binance.com"
# Binance hat die Futures-WebSockets am 06.03.2026 in /public, /market und /private aufgeteilt
# und die alten Basis-URLs am 23.04.2026 abgeschaltet. Der Handshake auf der alten URL gelingt
# weiterhin, aber /market-Streams (dazu gehört !forceOrder@arr) liefern dort NICHTS mehr --
# genau so lief dieser Dienst 13 Tage lang mit null Liquidationen (Stream-Probe 14.09.2026:
# DNS, TCP, TLS, Handshake ok, 0 Nachrichten). Quelle: developers.binance.com, "Important
# WebSocket Change Notice -- Base URL Split & Migration".
WS = "wss://fstream.binance.com/market/ws/!forceOrder@arr"
DB_PATH = "hl_liq.db"
COINS = ["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"]

SCHEMA = """
-- ts in SEKUNDEN (wie bars, ctx_bars, heatmap). Bis 13.09.2026 wurden hier
-- Millisekunden geschrieben; db_connect migriert Altzeilen einmalig.
CREATE TABLE IF NOT EXISTS bnc_liquidations (
    ts       INTEGER,
    coin     TEXT,
    symbol   TEXT,
    side     TEXT,     -- 'long'  = Long wurde liquidiert (Zwangsverkauf)
                       -- 'short' = Short wurde liquidiert (Zwangskauf)
    price    REAL,
    qty      REAL,
    notional REAL,
    PRIMARY KEY (ts, symbol, side, price, qty)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_bl_coin_ts ON bnc_liquidations(coin, ts);

CREATE TABLE IF NOT EXISTS bnc_metrics (
    ts     INTEGER,
    coin   TEXT,
    metric TEXT,
    value  REAL,
    PRIMARY KEY (ts, coin, metric)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_bm_coin ON bnc_metrics(coin, metric, ts);

-- Tageskerzen für gleitende Durchschnitte (50/200 Tage, 50/200 Wochen).
-- Quelle je Coin: Binance-Futures, sonst Binance-Spot, sonst Hyperliquid.
-- PRIMARY KEY (ts, coin) -- ein Tag je Coin, Nachladen ersetzt statt zu doppeln.
CREATE TABLE IF NOT EXISTS daily_bars (
    ts     INTEGER,            -- Tagesbeginn UTC, Sekunden
    coin   TEXT,
    open REAL, high REAL, low REAL, close REAL,
    volume REAL,
    source TEXT,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS bnc_bars (
    ts     INTEGER,
    coin   TEXT,
    open   REAL, high REAL, low REAL, close REAL,
    volume REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;
"""


def db_connect(path: str = DB_PATH, synchronous: str = "NORMAL") -> sqlite3.Connection:
    import hl_dbcoord
    con = sqlite3.connect(path, timeout=30, isolation_level="IMMEDIATE", factory=hl_dbcoord.KoordinierteVerbindung)
    con.koordination(path, "binance")                     # prozessübergreifende Schreibsperre, siehe hl_dbcoord
    con.execute("PRAGMA journal_mode=WAL")
    con.execute(f"PRAGMA synchronous={synchronous}")
    con.execute("PRAGMA busy_timeout=60000")     # bis zu 60 s auf eine Sperre warten
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    con.executescript(SCHEMA)
    # Einmalige Migration: Altzeilen in Millisekunden auf Sekunden umstellen. Die Grenze
    # 1e11 liegt weit über jedem Sekunden-Zeitstempel (Jahr 5138) und weit unter jedem
    # Millisekunden-Zeitstempel der Gegenwart (1,79e12) -- sie trennt also zweifelsfrei.
    try:
        n = con.execute("SELECT COUNT(*) FROM bnc_liquidations WHERE ts > 100000000000").fetchone()[0]
        if n:
            con.execute("UPDATE bnc_liquidations SET ts = ts / 1000 WHERE ts > 100000000000")
            con.commit()
            print(f"  bnc_liquidations: {n:,} Zeilen von Millisekunden auf Sekunden umgestellt", flush=True)
    except sqlite3.Error:
        pass
    return con


def get(path: str, params: dict | None = None, retries: int = 4, base: str = FAPI):
    from urllib.parse import urlencode
    url = f"{base}{path}" + (f"?{urlencode(params)}" if params else "")
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "hl-recorder/1.0"})
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code in (418, 429):           # Rate-Limit / Bann
                time.sleep(5 * (attempt + 1))
                last = e
                continue
            if e.code == 451:                  # geografisch gesperrt
                raise RuntimeError(
                    "Binance verweigert den Zugriff aus dieser Region (HTTP 451)."
                ) from e
            last = e
            break
        except Exception as e:
            last = e
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Binance-Request {path} fehlgeschlagen: {last}")


# ---------------------------------------------------------------------------
# Reine Parser — ohne Netz testbar
# ---------------------------------------------------------------------------

def parse_force_order(msg: dict, sym2coin: dict[str, str]) -> tuple | None:
    """
    forceOrder-Event in eine Datenbankzeile umwandeln.

    Binance nennt die Seite der ZWANGSORDER, nicht die der Position:
    SELL bedeutet, dass ein Long zwangsverkauft wurde.
    """
    o = msg.get("o") or {}
    sym = o.get("s")
    coin = sym2coin.get(sym)
    if not coin:
        return None
    try:
        qty = float(o.get("l") or o.get("q") or 0)      # ausgeführte Menge
        px = float(o.get("ap") or o.get("p") or 0)      # Durchschnittspreis
        # Binance liefert Millisekunden. Alle anderen Reihen des Projekts speichern
        # SEKUNDEN -- diese eine Ausnahme hat drei Auswertungen still zerstört: Zeitfilter
        # (ms > s ist immer wahr), Heatmap-Buckets und das Kapitulationssignal.
        ts = int(o.get("T") or msg.get("E") or 0) // 1000
    except (TypeError, ValueError):
        return None
    if qty <= 0 or px <= 0 or ts <= 0:
        return None
    side = "long" if str(o.get("S")).upper() == "SELL" else "short"
    return (ts, coin, sym, side, px, qty, px * qty)


def parse_oi(rows: list, coin: str) -> list[tuple]:
    out = []
    for r in rows:
        try:
            ts = int(r["timestamp"])
            out.append((ts, coin, "open_interest", float(r["sumOpenInterest"])))
            out.append((ts, coin, "oi_notional", float(r["sumOpenInterestValue"])))
        except (KeyError, TypeError, ValueError):
            continue
    return out


def parse_ratio(rows: list, coin: str, metric: str, field: str) -> list[tuple]:
    out = []
    for r in rows:
        try:
            out.append((int(r["timestamp"]), coin, metric, float(r[field])))
        except (KeyError, TypeError, ValueError):
            continue
    return out


def parse_klines(rows: list, coin: str) -> list[tuple]:
    out = []
    for k in rows:
        try:
            out.append((int(k[0]) // 1000, coin, float(k[1]), float(k[2]),
                        float(k[3]), float(k[4]), float(k[5])))
        except (IndexError, TypeError, ValueError):
            continue
    return out


# ---------------------------------------------------------------------------
# Symbolauflösung
# ---------------------------------------------------------------------------

def resolve_symbols(coins: list[str]) -> dict[str, str]:
    """Coin -> Binance-Perp-Symbol. Nicht gelistete Coins fallen weg."""
    info = get("/fapi/v1/exchangeInfo")
    live = {}
    for s in info.get("symbols", []):
        if (s.get("status") == "TRADING"
                and s.get("contractType") == "PERPETUAL"
                and s.get("quoteAsset") == "USDT"):
            live[s["baseAsset"].upper()] = s["symbol"]

    out = {}
    for c in coins:
        c = c.upper()
        if c in live:
            out[c] = live[c]
            print(f"  {c:<6} -> {live[c]}")
        else:
            print(f"  {c:<6} -> auf Binance-Futures nicht verfügbar, übersprungen")
    return out


# ---------------------------------------------------------------------------
# Tageskerzen für gleitende Durchschnitte
# ---------------------------------------------------------------------------

SPOT = "https://api.binance.com"
HL_INFO = "https://api.hyperliquid.xyz/info"
DAY = 86_400


def fetch_daily(coin: str, start_ts: int, futures_sym: str | None) -> tuple[list[tuple], str]:
    """
    Tageskerzen ab start_ts. Reihenfolge der Quellen:
    Binance-Futures (falls gelistet) -> Binance-Spot -> Hyperliquid candleSnapshot.
    Liefert (Zeilen, Quelle). Zeilen: (ts, coin, o, h, l, c, v, source).
    """
    now_ms = int(time.time() * 1000)

    def binance(base: str, path: str, sym: str, source: str):
        rows, cursor = [], start_ts * 1000
        while cursor < now_ms:
            chunk = get(path, {"symbol": sym, "interval": "1d", "limit": 1000,
                               "startTime": cursor}, base=base)
            if not isinstance(chunk, list) or not chunk:
                break
            for k in chunk:
                rows.append((int(k[0]) // 1000, coin, float(k[1]), float(k[2]),
                             float(k[3]), float(k[4]), float(k[5]), source))
            newest = int(chunk[-1][0])
            if newest <= cursor:
                break
            cursor = newest + DAY * 1000
            time.sleep(0.25)
        return rows

    if futures_sym:
        try:
            rows = binance(FAPI, "/fapi/v1/klines", futures_sym, "binance-futures")
            if rows:
                return rows, "binance-futures"
        except Exception as e:
            print(f"    {coin}: Futures-Kerzen nicht abrufbar ({e}), versuche Spot")
    try:
        rows = binance(SPOT, "/api/v3/klines", f"{coin}USDT", "binance-spot")
        if rows:
            return rows, "binance-spot"
    except Exception:
        pass
    # Hyperliquid: auch für Coins, die Binance nicht (mehr) führt
    try:
        body = json.dumps({"type": "candleSnapshot",
                           "req": {"coin": coin, "interval": "1d",
                                   "startTime": start_ts * 1000, "endTime": now_ms}}).encode()
        req = urllib.request.Request(HL_INFO, data=body,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read().decode())
        rows = [(int(c["t"]) // 1000, coin, float(c["o"]), float(c["h"]), float(c["l"]),
                 float(c["c"]), float(c["v"]), "hyperliquid") for c in data]
        return rows, "hyperliquid"
    except Exception as e:
        print(f"    {coin}: auch Hyperliquid liefert keine Tageskerzen ({e})")
        return [], "keine"


def backfill_daily(con: sqlite3.Connection, coins: list[str], years: float = 5,
                   coin2sym: dict[str, str] | None = None) -> None:
    """
    Tageskerzen nachladen, nur was fehlt: ab dem letzten gespeicherten Tag minus
    zwei Tage (die laufende Kerze wird so ersetzt). INSERT OR REPLACE auf den
    Primärschlüssel (ts, coin) -- doppelte Einträge sind ausgeschlossen.
    """
    if coin2sym is None:
        try:
            coin2sym = resolve_symbols(coins)
        except Exception as e:
            print(f"  Symbolauflösung fehlgeschlagen ({e}), nutze Spot/Hyperliquid")
            coin2sym = {}
    horizon = int(time.time()) - int(years * 365.25 * DAY)
    total = 0
    for coin in coins:
        coin = coin.upper()
        last = con.execute("SELECT MAX(ts) FROM daily_bars WHERE coin=?", (coin,)).fetchone()[0]
        start = max(horizon, (last or 0) - 2 * DAY) if last else horizon
        rows, source = fetch_daily(coin, start, coin2sym.get(coin))
        if not rows:
            continue
        con.executemany("INSERT OR REPLACE INTO daily_bars VALUES (?,?,?,?,?,?,?,?)", rows)
        con.commit()
        n = con.execute("SELECT COUNT(*), MIN(ts) FROM daily_bars WHERE coin=?", (coin,)).fetchone()
        total += len(rows)
        print(f"  {coin:<6} {len(rows):>5} Kerzen geladen ({source}), "
              f"gesamt {n[0]} Tage seit {time.strftime('%Y-%m-%d', time.gmtime(n[1]))}")
    print(f"  {total} Tageskerzen aktualisiert")


# ---------------------------------------------------------------------------
# Backfill
# ---------------------------------------------------------------------------

# (Endpunkt, Metrikname, Feld im Ergebnis)
RATIOS = [
    ("/futures/data/topLongShortPositionRatio", "top_ls_position", "longShortRatio"),
    ("/futures/data/topLongShortAccountRatio", "top_ls_account", "longShortRatio"),
    ("/futures/data/globalLongShortAccountRatio", "global_ls_account", "longShortRatio"),
    ("/futures/data/takerlongshortRatio", "taker_ls", "buySellRatio"),
]


def backfill(con: sqlite3.Connection, coins: list[str], period: str = "15m",
             days: int = 30) -> None:
    print(f"Backfill {days} Tage, Raster {period}\n")
    sym = resolve_symbols(coins)
    if not sym:
        print("Keine nutzbaren Symbole.")
        return

    now = int(time.time() * 1000)
    start = now - days * 86_400_000
    step_ms = {"5m": 300_000, "15m": 900_000, "30m": 1_800_000,
               "1h": 3_600_000, "4h": 14_400_000}[period]
    total = 0

    for coin, s in sym.items():
        print(f"\n{coin} ({s})")

        # Open Interest — je Abruf maximal 500 Punkte
        rows, cursor = [], start
        while cursor < now:
            chunk = get("/futures/data/openInterestHist",
                        {"symbol": s, "period": period, "limit": 500,
                         "startTime": cursor, "endTime": now})
            if not chunk:
                break
            rows += chunk
            newest = max(int(r["timestamp"]) for r in chunk)
            if newest <= cursor:
                break
            cursor = newest + step_ms
            time.sleep(0.3)
        data = parse_oi(rows, coin)
        con.executemany("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)", data)
        print(f"  Open Interest   {len(rows):>5} Punkte")
        total += len(data)

        # Positionierungs-Verhältnisse
        for path, metric, field in RATIOS:
            rows, cursor = [], start
            while cursor < now:
                try:
                    chunk = get(path, {"symbol": s, "period": period, "limit": 500,
                                       "startTime": cursor, "endTime": now})
                except RuntimeError as e:
                    print(f"  {metric:<16} nicht abrufbar ({e})")
                    chunk = []
                    break
                if not chunk:
                    break
                rows += chunk
                newest = max(int(r["timestamp"]) for r in chunk)
                if newest <= cursor:
                    break
                cursor = newest + step_ms
                time.sleep(0.3)
            data = parse_ratio(rows, coin, metric, field)
            con.executemany("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)", data)
            print(f"  {metric:<16}{len(rows):>5} Punkte")
            total += len(data)

        # Kerzen als Preiskontext
        rows, cursor = [], start
        while cursor < now:
            chunk = get("/fapi/v1/klines",
                        {"symbol": s, "interval": period, "limit": 1500,
                         "startTime": cursor, "endTime": now})
            if not chunk:
                break
            rows += chunk
            newest = int(chunk[-1][0])
            if newest <= cursor:
                break
            cursor = newest + step_ms
            time.sleep(0.3)
        bars = parse_klines(rows, coin)
        con.executemany("INSERT OR REPLACE INTO bnc_bars VALUES (?,?,?,?,?,?,?)", bars)
        print(f"  Kerzen          {len(bars):>5} Punkte")

        con.commit()

    print(f"\n{total} Metrikwerte gespeichert.")
    print("Liquidationen lassen sich nicht nachladen — dafür muss der Live-Modus laufen.")


# ---------------------------------------------------------------------------
# Live: Liquidationen + laufender OI
# ---------------------------------------------------------------------------

class Live:
    def __init__(self, con: sqlite3.Connection, sym2coin: dict[str, str],
                 coin2sym: dict[str, str], oi_interval: int = 600):
        self.con = con
        self.oi_interval = oi_interval
        self.extra_coins: list[str] = []      # Coins ohne Binance-Perp, Tageskerzen via Spot/HL
        self.db_path: str = DB_PATH
        self.sym2coin = sym2coin
        self.coin2sym = coin2sym
        self.stop = asyncio.Event()
        self.stats = defaultdict(int)
        self.puffer: list = []                # Liquidationen, die auf die nächste kurze Transaktion warten
        self.jobs: dict = {}          # Aufgabe -> Zustand, wird in meta gemeldet
        self.pending = 0
        self.last_commit = time.time()

    async def run_ws(self) -> None:
        import websockets
        backoff = 1
        while not self.stop.is_set():
            try:
                async with websockets.connect(WS, ping_interval=20) as ws:
                    print(f"Binance-Stream verbunden, filtere auf "
                          f"{', '.join(sorted(self.coin2sym))}.", flush=True)
                    backoff = 1
                    while not self.stop.is_set():
                        msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=600))
                        self.stats["events"] += 1
                        row = parse_force_order(msg, self.sym2coin)
                        if row:
                            self.puffer.append(row)                  # erst sammeln, dann in EINER kurzen Transaktion schreiben
                            self.stats["notional"] += row[6]
                            self.pending += 1
                        # Zeitnah schreiben: Kaskaden sind genau die Momente, in denen ein
                        # Stromausfall am meisten kosten würde. Aber nicht mit offener
                        # Transaktion warten: Der Einzel-INSERT mit spätem Commit hielt die
                        # Schreibsperre bis zu 10 s (gemessen 14.09., max 12 s) -- über das
                        # Warten auf die nächste Nachricht hinweg.
                        if self.pending >= 25 or (self.pending and time.time() - self.last_commit > 10):
                            self.puffer_schreiben()
            except asyncio.TimeoutError:
                print("Stream still (600 s ohne Nachricht), reconnect …", flush=True)
            except Exception as e:
                if not self.stop.is_set():
                    # flush: Unter systemd geht die Ausgabe in eine Datei und ist blockgepuffert --
                    # ohne flush stand die Fehlermeldung des Streams tagelang in keinem Log.
                    print(f"Stream-Fehler: {type(e).__name__}: {e} — reconnect in {backoff}s", flush=True)
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 60)

    def puffer_schreiben(self) -> None:
        """Gesammelte Liquidationen in einer kurzen Transaktion schreiben."""
        if not self.puffer:
            return
        try:
            self.con.executemany("INSERT OR IGNORE INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", self.puffer)
            self.con.commit()
            self.stats["stored"] += len(self.puffer)
            self.puffer = []; self.pending = 0; self.last_commit = time.time()
        except sqlite3.Error as e:
            try:
                self.con.rollback()                          # Audit v3 D3: immer zurückrollen, Sperre nie offen lassen
            except sqlite3.Error:
                pass
            if not isinstance(e, sqlite3.OperationalError) or ("locked" not in str(e) and "busy" not in str(e)):
                print(f"  Liquidationen nicht gespeichert: {type(e).__name__}: {e}", flush=True)
                self.stats["store_errors"] += 1
                self.puffer = self.puffer[-5000:]
                return
            self.puffer = self.puffer[-5000:]              # behalten, nächster Versuch beim nächsten Schwung

    async def run_oi(self) -> None:
        """Open Interest im eingestellten Takt fortschreiben -- erst alle Abrufe, dann eine kurze Transaktion."""
        while not self.stop.is_set():
            rows = []
            for coin, s in self.coin2sym.items():
                try:
                    # Audit M16: urllib blockiert; in der Ereignisschleife hielt der Abruf
                    # (bis zu vier Versuche mit Wartezeit) den WebSocket-Empfang an.
                    r = await asyncio.to_thread(get, "/fapi/v1/openInterest", {"symbol": s})
                    ts = int(r.get("time", time.time() * 1000))
                    rows.append((ts // 1000, coin, "open_interest", float(r["openInterest"])))
                except Exception:
                    pass
            if rows:
                try:
                    self.con.executemany("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)", rows)
                    self.con.commit()
                except sqlite3.Error:                              # Audit v4 L10: jede sqlite3-Fehlerklasse
                    try:
                        self.con.rollback()
                    except sqlite3.Error:
                        pass
            for _ in range(self.oi_interval):
                if self.stop.is_set():
                    return
                await asyncio.sleep(1)

    def note_job(self, name: str, takt: float | None = None, info: str = "") -> None:
        """
        Zustand melden, damit der Netzwerkstatus im Dashboard Binance kennt. Ohne das
        stand dort nur Hyperliquid, obwohl Binance ununterbrochen Daten liefert -- eine
        Quelle, die niemand sieht, kann tagelang ausfallen, ohne dass es auffällt.
        """
        j = self.jobs.setdefault(name, {})
        j["last"] = int(time.time())
        if takt:
            j["next"] = int(time.time() + takt)
            j["takt"] = int(takt)
        if info:
            j["info"] = info[:120]
        j["ok"] = True

    async def run_report(self) -> None:
        while not self.stop.is_set():
            await asyncio.sleep(self.oi_interval)
            if self.stop.is_set():
                return
            self.con.commit()
            try:
                self.note_job("Binance-Kennzahlen", takt=self.oi_interval,
                              info=f"{len(self.coin2sym)} Symbole, {self.stats.get('stored', 0)} Liquidationen")
                self.note_job("Binance-Feed", info=f"{self.stats.get('events', 0)} Ereignisse")
                self.con.executemany("INSERT OR REPLACE INTO meta VALUES (?,?)", [
                    ("bnc_alive", str(int(time.time()))),
                    ("bnc_jobs", json.dumps(self.jobs)[:2000]),
                    ("bnc_stats", json.dumps({k: int(v) for k, v in self.stats.items() if isinstance(v, (int, float))})[:2000]),
                    ("wlock_binance", json.dumps(self.con.kennzahlen()) if hasattr(self.con, "kennzahlen") else "{}")])
                # Sofort committen: Bis 14.09. fehlte dieser Commit -- die Transaktion blieb bis zum
                # nächsten Durchlauf (600 s) offen und hielt die Schreibsperre der Datenbank zehn
                # Minuten lang. Das war die Quelle der "database is locked"-Fehler im Recorder.
                self.con.commit()
            except (sqlite3.Error, AttributeError, TypeError):
                try:
                    self.con.rollback()
                except sqlite3.Error:
                    pass
            try:
                # PASSIVE statt TRUNCATE: Ein TRUNCATE-Checkpoint verlangt den Lauf
                # exklusiv und blockiert jeden anderen Schreiber, bis er ihn bekommt.
                # In diese Datenbank schreiben drei Dienste (Recorder, Binance, Coinbase)
                # und das Dashboard liest -- zwei davon gleichzeitig auf TRUNCATE zu
                # setzen, hat dem Adress-Poller reihenweise "database is locked"
                # eingebracht. Das harte Aufräumen macht ausschließlich der Recorder,
                # dem die Datenbank gehört; hier genügt die sanfte Form.
                self.con.execute("PRAGMA wal_checkpoint(PASSIVE)")
            except sqlite3.Error:
                pass
            print(f"[{time.strftime('%H:%M:%S')}] Events {self.stats['events']:>7} | "
                  f"gespeichert {self.stats['stored']:>6} | "
                  f"Notional {self.stats['notional']/1e6:>8.1f} Mio USD")

    async def run_daily(self) -> None:
        """
        Tageskerzen beim Start und danach alle 6 Stunden nachziehen.

        Läuft in einem Hintergrund-Thread mit EIGENER Datenbankverbindung --
        SQLite erlaubt keine Verbindung über Thread-Grenzen hinweg.
        """
        await asyncio.sleep(20)

        def job():
            con = db_connect(self.db_path)
            try:
                backfill_daily(con, list(self.coin2sym) + self.extra_coins, 5, self.coin2sym)
            finally:
                con.close()

        while not self.stop.is_set():
            try:
                print(f"[{time.strftime('%H:%M:%S')}] Tageskerzen nachladen …")
                await asyncio.to_thread(job)
            except Exception as e:
                print(f"  Tageskerzen: {e}")
            for _ in range(6 * 3600):
                if self.stop.is_set():
                    return
                await asyncio.sleep(1)

    async def run_ext(self) -> None:
        """
        Reihen der Fremdbörsen (hl_ext): Bybit/OKX/Crypto.com-Kennzahlen, Binance-Verhältnisse
        und -Orderbuch, OKX- und Bybit-Liquidationen, ETF-Flüsse. Eigene Verbindung, eigene
        Threads -- die Binance-Schleifen hier bleiben davon unberührt. Ein Fehler im Sammler
        beendet den Dienst nicht (Neustart des Sammlers nach 60 s).
        """
        import hl_ext
        coins = list(self.coin2sym) + [c for c in self.extra_coins if c not in self.coin2sym]
        def sink(d: dict) -> None:
            self.stats.update(d)
        while not self.stop.is_set():
            try:
                await hl_ext.betreiben(self.db_path, coins, dict(self.coin2sym), self.stop, sink)
            except Exception as e:
                print(f"  Fremdbörsen-Sammler abgebrochen: {type(e).__name__}: {e} -- Neustart in 60 s", flush=True)
                for _ in range(60):
                    if self.stop.is_set():
                        return
                    await asyncio.sleep(1)

    async def run(self) -> None:
        tasks = [asyncio.create_task(t) for t in
                 (self.run_ws(), self.run_oi(), self.run_report(), self.run_daily(), self.run_ext())]
        await self.stop.wait()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.puffer_schreiben()                             # beim Beenden nichts liegen lassen
        self.con.commit()
        print("\nSauber beendet.")


# ---------------------------------------------------------------------------

def probe_stream(sekunden: int = 15) -> int:
    """
    Verbindung zum Liquidations-Stream Schritt für Schritt prüfen: DNS, TCP 443, TLS,
    WebSocket-Handshake, Nachrichten. Jeder Schritt meldet Erfolg oder den Fehlertyp --
    damit ist unterscheidbar, ob der Host vom Pi aus nicht erreichbar ist (Router, DNS,
    Anbieter), ob Binance den Handshake ablehnt (Region, HTTP 451/403) oder ob die
    Verbindung steht und nur keine Nachrichten kommen.
    """
    import socket, ssl
    host = "fstream.binance.com"
    print(f"Stream-Probe {WS} ({sekunden} s)")
    try:
        ip = socket.gethostbyname(host); print(f"  DNS        ok: {host} -> {ip}")
    except Exception as e:
        print(f"  DNS        FEHLER: {type(e).__name__}: {e}"); return 1
    try:
        with socket.create_connection((host, 443), timeout=10) as sock:
            print("  TCP 443    ok")
            with ssl.create_default_context().wrap_socket(sock, server_hostname=host) as tls:
                print(f"  TLS        ok: {tls.version()}")
    except Exception as e:
        print(f"  TCP/TLS    FEHLER: {type(e).__name__}: {e}"); return 1
    try:
        import websockets
        print(f"  websockets {websockets.__version__}")
    except Exception as e:
        print(f"  websockets FEHLER: {type(e).__name__}: {e} -- Bibliothek fehlt im venv"); return 1

    async def lauf() -> int:
        n = 0; erste = None; t_ende = time.time() + sekunden
        try:
            async with websockets.connect(WS, ping_interval=20, open_timeout=15) as ws:
                print("  WebSocket  ok: Handshake angenommen, warte auf Nachrichten …")
                while time.time() < t_ende:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=max(1, t_ende - time.time()))
                    except asyncio.TimeoutError:
                        break
                    n += 1
                    if erste is None:
                        erste = msg[:160]
        except Exception as e:
            print(f"  WebSocket  FEHLER: {type(e).__name__}: {e}")
            return 1
        print(f"  Nachrichten in {sekunden} s: {n}" + (f" · erste: {erste}" if erste else ""))
        if n == 0:
            print("  -> Verbindung steht, aber der Stream liefert nichts. Das ist ungewöhnlich (alle Symbole, alle Liquidationen);")
            print("     in ruhigen Minuten möglich -- Probe mit --probe-stream 60 wiederholen.")
        return 0
    return asyncio.run(lauf())


def status(con: sqlite3.Connection) -> None:
    q = lambda s, *a: con.execute(s, a).fetchone()
    print("Binance-Daten:")
    for coin, n, src, first in con.execute(
            "SELECT coin, COUNT(*), source, MIN(ts) FROM daily_bars GROUP BY coin ORDER BY coin"):
        print(f"  Tageskerzen {coin:<6} {n:>5} seit {time.strftime('%Y-%m-%d', time.gmtime(first))} ({src})")
    print(f"  Liquidationen   {q('SELECT COUNT(*) FROM bnc_liquidations')[0]:,}")
    # Zustand des Streams aus den Zählern des laufenden Dienstes (meta.bnc_stats):
    # events = empfangene Nachrichten, stored = gespeicherte Zeilen. Null Events bei lebendem
    # Dienst heißt: Der Stream verbindet nicht (Journal hl-binance: "Stream-Fehler").
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
        st = json.loads(meta.get("bnc_stats") or "{}")
        alive = int(meta.get("bnc_alive") or 0)
        alter = f"vor {int(time.time()) - alive} s" if alive else "nie"
        print(f"  Stream          Events {st.get('events', 0):,} · gespeichert {st.get('stored', 0):,} · Dienst zuletzt gemeldet {alter}"
              + ("" if st.get("events") else "  <- KEINE Nachrichten: Verbindung zu wss://fstream.binance.com prüfen (Journal hl-binance)"
                 if alive and time.time() - alive < 120 else ""))
    except (sqlite3.OperationalError, ValueError):
        pass
    print(f"  Metrikwerte     {q('SELECT COUNT(*) FROM bnc_metrics')[0]:,}")
    # Reihen der Fremdbörsen (hl_ext) -- je Tabelle Zeilen und Alter der jüngsten
    for tab, was in (("ext_metrics", "Kennzahlen Bybit/OKX/Crypto.com"), ("bnc_book", "Binance-Orderbuch"),
                     ("ext_liquidations", "Liquidationen Bybit/OKX"), ("etf_flows", "ETF-Flüsse")):
        try:
            if tab == "etf_flows":
                n, jung = con.execute("SELECT COUNT(*), MAX(day) FROM etf_flows").fetchone()
                print(f"  {was:<31} {n:>8,} Zeilen · jüngster Tag {jung or '—'}")
            else:
                n, mx = con.execute(f"SELECT COUNT(*), MAX(ts) FROM {tab}").fetchone()
                alter = f"vor {(time.time() - mx) / 60:.0f} min" if mx else "—"
                extra = ""
                if tab == "ext_liquidations":
                    extra = " · " + ", ".join(f"{e} {k:,}" for e, k in con.execute("SELECT exchange, COUNT(*) FROM ext_liquidations GROUP BY exchange"))
                if tab == "ext_metrics":
                    extra = " · " + ", ".join(f"{e} {k}" for e, k in con.execute("SELECT exchange, COUNT(DISTINCT coin) FROM ext_metrics GROUP BY exchange")) + " Coins"
                print(f"  {was:<31} {n:>8,} Zeilen · jüngste {alter}{extra}")
        except sqlite3.OperationalError:
            print(f"  {was:<31} (Tabelle fehlt -- Dienst noch nicht mit hl_ext gestartet)")
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
        st = json.loads(meta.get("bnc_stats") or "{}")
        if any(k.startswith("ext_") for k in st):
            print(f"  Sammler         Fehler {st.get('ext_fehler', 0)} · gesperrt (DB) {st.get('ext_db_locked', 0)} · ungelistet {st.get('ext_ungelistet', 0)}"
                  f" · Bybit-Stream {st.get('ext_bybit_ws_events', 0):,} Ereignisse, {st.get('ext_bybit_ws_reconnects', 0)} Reconnects"
                  + (f" · letzter Fehler: {meta.get('ext_letzter_fehler')}" if meta.get("ext_letzter_fehler") else ""))
    except (sqlite3.OperationalError, ValueError):
        pass
    print(f"  Kerzen          {q('SELECT COUNT(*) FROM bnc_bars')[0]:,}")
    r = q("SELECT MIN(ts), MAX(ts) FROM bnc_metrics")
    if r[0]:
        print(f"  Metrik-Zeitraum {(r[1]-r[0])/86400:.1f} Tage")
    for coin, n, ntl in con.execute(
            "SELECT coin, COUNT(*), SUM(notional) FROM bnc_liquidations "
            "GROUP BY coin ORDER BY 3 DESC"):
        print(f"    {coin:<6} {n:>7} Liqs, {(ntl or 0)/1e6:>9.1f} Mio USD")


def selftest() -> bool:
    """Parser gegen Beispielantworten prüfen, ohne Netz."""
    ok = True

    row = parse_force_order({"e": "forceOrder", "E": 1568014460893, "o": {
        "s": "BTCUSDT", "S": "SELL", "q": "0.014", "p": "9910",
        "ap": "9910", "l": "0.014", "T": 1568014460893}}, {"BTCUSDT": "BTC"})
    # ts in SEKUNDEN -- die Umstellung vom 13.09.2026 (vorher wurden hier Millisekunden
    # erwartet, was den Einheitenfehler jahrelang als "korrekt" bestätigt hat)
    exp = (1568014460, "BTC", "BTCUSDT", "long", 9910.0, 0.014, 138.74)
    if row and row[:6] == exp[:6] and abs(row[6] - exp[6]) < 1e-6:
        print("  [ok]  forceOrder: SELL wird als Long-Liquidation erkannt")
    else:
        print(f"  [FEHLER] forceOrder: {row}")
        ok = False

    # T muss ein echter Millisekunden-Stempel sein: 1 ms ergibt nach der Umrechnung 0
    # und würde als ungültig verworfen -- genau das passierte beim ersten Anlauf.
    row = parse_force_order({"o": {"s": "ETHUSDT", "S": "BUY", "l": "2",
                                   "ap": "3000", "T": 1700000000000}}, {"ETHUSDT": "ETH"})
    if row and row[3] == "short" and row[6] == 6000 and row[0] == 1700000000:
        print("  [ok]  forceOrder: BUY wird als Short-Liquidation erkannt")
    else:
        print(f"  [FEHLER] forceOrder BUY: {row}")
        ok = False

    if parse_force_order({"o": {"s": "DOGEUSDT", "S": "BUY", "l": "1",
                                "ap": "1", "T": 1}}, {"BTCUSDT": "BTC"}) is None:
        print("  [ok]  fremde Symbole werden verworfen")
    else:
        print("  [FEHLER] Filter greift nicht")
        ok = False

    oi = parse_oi([{"symbol": "BTCUSDT", "sumOpenInterest": "20403.637",
                    "sumOpenInterestValue": "150570784.078",
                    "timestamp": 1583127900000}], "BTC")
    if len(oi) == 2 and oi[0][3] == 20403.637 and oi[1][2] == "oi_notional":
        print("  [ok]  openInterestHist wird korrekt zerlegt")
    else:
        print(f"  [FEHLER] parse_oi: {oi}")
        ok = False

    rt = parse_ratio([{"longShortRatio": "1.8105", "longAccount": "0.6442",
                       "shortAccount": "0.3558", "timestamp": 1583139600000}],
                     "BTC", "top_ls_position", "longShortRatio")
    if rt and abs(rt[0][3] - 1.8105) < 1e-9:
        print("  [ok]  Long/Short-Ratio wird korrekt zerlegt")
    else:
        print(f"  [FEHLER] parse_ratio: {rt}")
        ok = False

    kl = parse_klines([[1591258320000, "9640.7", "9642.4", "9640.6", "9642.0",
                        "206.429", 1591258379999, "0", 0, "0", "0", "0"]], "BTC")
    if kl and kl[0][0] == 1591258320 and kl[0][5] == 9642.0:
        print("  [ok]  Kerzen werden korrekt zerlegt (ms -> s)")
    else:
        print(f"  [FEHLER] parse_klines: {kl}")
        ok = False

    # Schreibpfad gegen eine temporäre Datenbank
    import tempfile, os
    tmp = os.path.join(tempfile.gettempdir(), f"_bnc_{os.getpid()}.db")
    try:
        con = db_connect(tmp)
        con.executemany("INSERT OR IGNORE INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)",
                        [exp, exp])          # doppelt -> muss ignoriert werden
        con.executemany("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)", oi)
        con.commit()
        n = con.execute("SELECT COUNT(*) FROM bnc_liquidations").fetchone()[0]
        con.close()
        if n == 1:
            print("  [ok]  Datenbankschema und Duplikatschutz")
        else:
            print(f"  [FEHLER] Duplikatschutz: {n} Zeilen")
            ok = False
    finally:
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(tmp + suffix)
            except OSError:
                pass
    return ok


def main() -> None:
    p = argparse.ArgumentParser(description="Binance-Daten für die Liquidationsanalyse")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--probe-stream", nargs="?", const=15, type=int, metavar="SEKUNDEN",
                   help="Liquidations-Stream vom Pi aus prüfen (DNS, TCP, TLS, WebSocket, Nachrichten)")
    p.add_argument("--coins", nargs="+", default=COINS)
    p.add_argument("--backfill", action="store_true", help="30 Tage nachladen")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--period", default="15m",
                   choices=["5m", "15m", "30m", "1h", "4h"])
    p.add_argument("--backfill-daily", action="store_true",
                   help="Tageskerzen für MA 50/200 Tage und 50/200 Wochen nachladen")
    p.add_argument("--years", type=float, default=5, help="Rückblick für --backfill-daily")
    p.add_argument("--oi-interval", type=int, default=600,
                   help="Abstand der Open-Interest-Abrufe in Sekunden")
    p.add_argument("--durable", action="store_true",
                   help="synchronous=FULL: kein Verlust bei Stromausfall")
    p.add_argument("--status", action="store_true")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args()

    if args.selftest:
        print("Parser-Selbsttest (ohne Netz)")
        sys.exit(0 if selftest() else 1)

    if args.probe_stream:
        sys.exit(probe_stream(args.probe_stream))

    con = db_connect(args.db, "FULL" if args.durable else "NORMAL")

    if args.status:
        status(con)
        return

    if args.backfill_daily:
        print("Tageskerzen für gleitende Durchschnitte:")
        backfill_daily(con, args.coins, args.years)
        return

    if args.backfill:
        if args.days > 30:
            print("Hinweis: Open Interest und Ratios gibt es nur 30 Tage "
                  "rückwirkend. Nur die Kerzen reichen weiter zurück.")
        backfill(con, args.coins, args.period, args.days)
        return

    print("Löse Symbole auf …")
    # Audit M13: Schlug die Auflösung fehl (typisch: Dienst startet vor dem Netz), endete der
    # Prozess mit Exit 0 -- systemd sah keinen Fehler und ließ den Dienst stumm liegen bzw.
    # drehte eine Neustartschleife. Jetzt: bis zu ~15 Minuten (Symbolauflösung: 20 Versuche) geduldig wiederholen, dann
    # Exit 1, damit systemd mit RestartSec sauber neu startet.
    coin2sym = {}
    for versuch in range(20):
        try:
            coin2sym = resolve_symbols(args.coins)
        except Exception as e:
            print(f"  Symbolauflösung fehlgeschlagen: {e}")
            coin2sym = {}
        if coin2sym:
            break
        warte = min(60, 5 * (versuch + 1))
        print(f"  keine Symbole aufgelöst (Netz noch nicht da?), neuer Versuch in {warte} s", flush=True)
        time.sleep(warte)
    if not coin2sym:
        print("Symbole nicht auflösbar — Abbruch mit Fehlercode 1.")
        sys.exit(1)
    sym2coin = {v: k for k, v in coin2sym.items()}

    live = Live(con, sym2coin, coin2sym, args.oi_interval)
    live.extra_coins = [c.upper() for c in args.coins if c.upper() not in coin2sym]
    live.db_path = args.db
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, live.stop.set)
        except NotImplementedError:
            pass
    print("\nLiquidationen werden mitgeschnitten. Abbruch mit Strg-C.")
    print("Hinweis: Binance pusht je Symbol nur die größte Order pro Sekunde.")
    print("Während Kaskaden ist das gespeicherte Volumen daher eine Untergrenze.\n")
    try:
        loop.run_until_complete(live.run())
    except KeyboardInterrupt:
        live.stop.set()
    finally:
        con.close()


if __name__ == "__main__":
    main()
