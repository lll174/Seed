#!/usr/bin/env python3
"""
hl_volumen.py — Volumen-Studie (U221): Laufen die Einstiege der Trading-Strategien bei hohem oder niedrigem Volumen besser?

Regeln vorab in KONZEPT_Volumen.md (Entwurf und unabhängige Durchsicht 24.10.2026, Freigabe des Nutzers 03:17 „wie vorgeschlagen“;
Präzisierungen beim Bau mit Datum in Abschnitt 12). Liest nur: hl_liq.db (bars, bars10, cb_bars), forecasts.db und labor_a.db
(TradeLabor), hebel.db, swing.db. Ändert weder Labor, Konfluenz, Prognose, Fusion, v3, Kaskaden-Rechnung noch v1-Lernen und fließt
nirgends ein.

  Teil A (live)      alle geschlossenen Trades des Labors (Welt B): RV (relatives Volumen) und TS (Taker-Saldo in Handelsrichtung)
                     zum Zeitpunkt der Entscheidung, D = oberes − unteres Drittel je Schicht (Kennung × Long/Short × Werktag/Wochenende),
                     Nullmodell Zeitverschiebung der fertigen Reihen um ±24…±336 h; Urteil erst am 08.11.2026.
  Teil B (Historie)  die vier Swing-Strategien seit 2020 (hl_swing.lauf, Daten bis 23.10.2026) mit Tages-RV und Tages-Taker-Anteil aus
                     hebel.db; Nullmodell Verschiebung um ±30…±365 Tage.

  python3 hl_volumen.py --studie --db <hl_liq.db>     Debug-Bericht „★ Volumen: Einstiege der Strategien nach Volumen (U221)“
  python3 hl_volumen.py --selbsttest                  Rechnung von Hand, Kausalität, Nullmodell, Störgrößen, Kontrollen, Ende zu Ende
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone

import numpy as np

VERSION_MODUL = "2026-09-23.81"
MIN = 60
TAG = 86_400
COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")          # die Labor-Coins (hl_labor.COINS)
W_KURZ = 60                                          # Fenster in Minuten bei Horizont bis 12 h
W_LANG = 1440                                        # … bei Horizont ab 24 h
H_GRENZE = 12
VERGLEICH_TAGE = 28
VERGLEICH_ANTEIL = 0.70
LUECKE_MAX = 0.05
FRAGLICH_REL = 0.01
TS_MIN_TRADES = 20
SEITEN_RHO_MIN = 0.1
SCHICHT_MIN = 9
POOL_MIN = 30
STRAT_MIN = 60
STRAT_TAGE = 14
POOL_PRUEF_MIN = 300
POOL_PRUEF_TAGE = 21
B_PRUEF_MIN = 150
N_BOOT = 1000
N_BOOT_BESCHR = 400                                  # beschreibende Teile (nur Band, ohne Nullmodell)
BLOCK_B_TAGE = 60
ALPHA = 0.05
BH_Q = 0.10
BAND_ENG = 0.25                                      # „Band eng um 0“: ganz innerhalb ±0,25 Punkte bzw. R (KONZEPT 12)
TAU_A = np.array([k for k in range(-336, 337) if abs(k) >= 24], dtype=np.int64)       # Stunden, 626 Werte
TAU_B = np.array([k for k in range(-365, 366) if abs(k) >= 30], dtype=np.int64)       # Tage, 672 Werte
STICHTAG = int(datetime(2026, 11, 8, tzinfo=timezone.utc).timestamp())               # Urteil Teil A: Trades vor 08.11. 00:00 UTC
TEIL_B_ENDE = int(datetime(2026, 10, 24, tzinfo=timezone.utc).timestamp())            # Teil B: Daten bis einschließlich 23.10.2026
VORLAUF_S = VERGLEICH_TAGE * TAG + W_LANG * MIN       # Spanne Teil A: ab 28 Tagen + 24 h Aufzeichnung (KONZEPT 3a, 12)
LADE_MAX_TAGE = 120                                  # Minuten höchstens so weit vor dem ersten Labor-Trade lesen (Speicher des Pi)
AKKU_TAGE = 7
STAND_PUFFER_S = 120                                 # Stand heute: Fenster enden 2 min vor dem Lauf (noch nicht geschriebene Minuten)
SEED = 221
BLOCK_ZEILEN = 100_000
KENNZAHLEN = (("rv", "RV relatives Volumen"), ("ts", "TS Taker-Saldo in Handelsrichtung"))
# Pool (KONZEPT_Volumen.md Abschnitt 4), vorab festgelegt
GEKOPPELT = ("familie_orderfluss", "familie_momentum", "kaskade_umkehr", "kaskade_fortsetzung", "kaskade_kipppunkt", "docht_fangen",
             "magnet", "twap_druck")
SPIEGEL_GEGEN = ("wale_gegen", "leaderboard_gegen", "smartmoney_gegen", "pool_gegen", "darwin_gegen", "elite_gegen")
OHNE_GRUPPEN = ("Grid", "Akkumulation")
GRUPPEN = ("Händler", "Prognose", "Familien", "Ereignisse", "Swing", "volumengekoppelt")
SORT_GRUPPE = GRUPPEN + ("Kontrolle",)


def ist_kontrolle(name: str) -> bool:
    return "zufall" in name or name == "halten_long"


# ================================================================================================ Ausgabe-Helfer

def _de(x, nd: int = 2, vz: bool = False) -> str:
    if x is None:
        return "—"
    try:
        x = float(x)
    except (TypeError, ValueError):
        return "—"
    if not math.isfinite(x):
        return "—"
    s = f"{x:+.{nd}f}" if vz else f"{x:.{nd}f}"
    return s.replace(".", ",")


def _pz(p) -> str:
    if p is None or not math.isfinite(p):
        return "—"
    return "< 0,001" if p < 0.001 else _de(p, 3)


def _dt(ts, mit_zeit: bool = True) -> str:
    if ts is None:
        return "—"
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%d.%m.%Y %H:%M UTC" if mit_zeit else "%d.%m.%Y")


def _tm(ts) -> str:
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%d.%m.")


def _tausend(n) -> str:
    return f"{int(n):,}".replace(",", ".")


def _band_txt(b, nd: int = 2) -> str:
    return f"{_de(b[0], nd, True)} … {_de(b[1], nd, True)}"


# ================================================================================================ Zeit, Pfade

def wochentag(ts) -> np.ndarray:
    """0 = Montag … 6 = Sonntag (UTC); 01.01.1970 war ein Donnerstag."""
    return ((np.asarray(ts, dtype=np.int64) // TAG) + 3) % 7


def tagesart(ts) -> np.ndarray:
    """1 = Wochenende (Samstag, Sonntag UTC), 0 = Werktag."""
    return (wochentag(ts) >= 5).astype(np.int64)


def art_fenster(t_ende, W: int) -> np.ndarray:
    """Tagesart eines Fensters [t − W, t) für die Vergleichsfenster: in der Mitte des Fensters bestimmt (KONZEPT 12, 24.10.2026). Ein
    24-h-Fenster, das Samstag 00:05 endet, enthält den Freitag -- es wird mit Werktagen verglichen, nicht mit Wochenenden."""
    return tagesart(np.asarray(t_ende, dtype=np.int64) - (W * MIN) // 2)


def urteil_a_erlaubt(jetzt: int) -> bool:
    """Teil A urteilt erst ab dem 08.11.2026 00:00 UTC (KONZEPT 5); jeder frühere Lauf heißt „vorläufig“."""
    return int(jetzt) >= STICHTAG


def _ro(pfad: str):
    if not pfad or not os.path.exists(pfad):
        return None
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=30)
    con.execute("PRAGMA busy_timeout=30000")
    return con


def pfade(db: str) -> dict:
    d = os.path.dirname(os.path.abspath(db))
    fc = os.environ.get("HL_FORECAST_DB") or os.path.join(d, "forecasts.db")
    return {"haupt": db, "forecasts": fc,
            "labor_a": os.environ.get("HL_LABOR_A_DB") or os.path.join(os.path.dirname(os.path.abspath(fc)), "labor_a.db"),
            "hebel": os.environ.get("HL_HEBEL_DB") or os.path.join(d, "hebel.db"),
            "swing": os.environ.get("HL_SWING_DB") or os.path.join(d, "swing.db")}


# ================================================================================================ Bausteine

def _nanmedian_zeilen(V: np.ndarray) -> tuple:
    """Median je Zeile über die endlichen Werte (wie np.nanmedian(V, axis=1), ohne Warnung) und ihre Zahl."""
    S = np.sort(V, axis=1)                                   # nan ans Ende
    cnt = np.isfinite(V).sum(axis=1)
    med = np.full(V.shape[0], np.nan)
    j = np.nonzero(cnt > 0)[0]
    if len(j):
        c = cnt[j]
        med[j] = 0.5 * (S[j, (c - 1) // 2] + S[j, c // 2])
    return med, cnt


def _vergleich(arr: np.ndarray, ok: np.ndarray, art: np.ndarray, schritt: int) -> tuple:
    """
    Median über die Vergleichsfenster gleicher Tagesart der 28 Tage davor (k · schritt Indizes zurück, k = 1 … 28; nur Vergangenheit)
    und die Zahl der gültigen. arr, ok und art je Fensterende. soll = 20 Werktage bzw. 8 Wochenendtage (in 28 Tagen immer gleich).
    """
    n = len(arr)
    quelle = np.where(np.asarray(ok, dtype=bool) & np.isfinite(arr), arr, np.nan)
    med = np.full(n, np.nan); anz = np.zeros(n, dtype=np.int64)
    for a0 in range(0, n, BLOCK_ZEILEN):
        a1 = min(n, a0 + BLOCK_ZEILEN)
        V = np.full((VERGLEICH_TAGE, a1 - a0), np.nan)
        for k in range(1, VERGLEICH_TAGE + 1):
            sch = k * schritt
            lo = max(a0, sch)                                     # Fensterenden mit Vergleich k: Index ≥ k · schritt
            if lo >= a1:
                continue
            V[k - 1, lo - a0:] = np.where(art[lo - sch:a1 - sch] == art[lo:a1], quelle[lo - sch:a1 - sch], np.nan)
        m, c = _nanmedian_zeilen(V.T)
        med[a0:a1] = m; anz[a0:a1] = c
    soll = np.where(art == 1, 8, 20)
    return med, anz, soll


def _fenster(x, W: int) -> np.ndarray:
    """Summe über [i − W, i) je Fensterende i = 0 … N (nan, solange das Fenster nicht voll ist)."""
    x = np.asarray(x, dtype=float); N = len(x)
    cs = np.concatenate([[0.0], np.cumsum(x)])
    out = np.full(N + 1, np.nan)
    if N + 1 > W:
        out[W:] = cs[W:] - cs[:-W]
    return out


def _rangkorrelation(x: np.ndarray, y: np.ndarray) -> float:
    """Spearman mit mittleren Rängen bei Gleichstand."""
    if len(x) < 30:
        return float("nan")

    def raenge(a):
        o = np.argsort(a, kind="mergesort"); r = np.empty(len(a)); r[o] = np.arange(len(a), dtype=float)
        _u, inv, cnt = np.unique(a, return_inverse=True, return_counts=True)
        return (np.bincount(inv, weights=r) / cnt)[inv]
    rx, ry = raenge(x), raenge(y)
    sx, sy = rx.std(), ry.std()
    return float(((rx - rx.mean()) * (ry - ry.mean())).mean() / (sx * sy)) if sx > 0 and sy > 0 else float("nan")


def _median_fenster(B: np.ndarray, w: int) -> np.ndarray:
    """Gleitender Median über w Werte: Position s = Median von B[s : s + w] (in Blöcken, schont den Speicher)."""
    from numpy.lib.stride_tricks import sliding_window_view
    n = len(B) - w + 1
    if n <= 0:
        return np.zeros(0)
    out = np.empty(n)
    V = sliding_window_view(B, w)
    for a0 in range(0, n, 20_000):
        out[a0:a0 + 20_000] = np.median(V[a0:a0 + 20_000], axis=1)
    return out


# ================================================================================================ Teil A: Minutenreihen

def erste_bar(con) -> int | None:
    """Erste Minute der Aufzeichnung (erste BTC-Bar)."""
    try:
        r = con.execute("SELECT MIN(ts) FROM bars WHERE coin='BTC'").fetchone()
    except sqlite3.Error:
        return None
    return int(r[0]) if r and r[0] is not None else None


def minuten_laden(con, coins, t_von: int, t_bis: int) -> dict:
    """
    Je Coin Minutenreihen über [t_von, t_bis) (Minute i = [t_von + 60·i, t_von + 60·(i+1))): Umsatz in USD (Schluss × Volumen aus
    `bars`), Volumen, Schluss, Rendite der Minute, Taker-Kauf/-Verkauf und Zahl der Trades aus `bars10` (je Minute summiert, in numpy --
    ein GROUP BY in SQLite bräuchte einen temporären Baum von einigen 100 MB im Speicher oder auf der SD-Karte). Dazu „aufgezeichnet“
    (BTC hat eine Bar, KONZEPT 3c) und „fraglich“ (bars-Volumen und Summe aus bars10 weichen um mehr als 1 % ab). Je Tabelle eine Abfrage
    für alle Coins (ein Durchlauf über den Zeitraum; der Schlüssel ist (ts, coin)), in Stücken gelesen.
    """
    t_von = int(t_von) // MIN * MIN
    N = max(0, (int(t_bis) - t_von) // MIN)
    alle = sorted(set(coins) | {"BTC"})
    M = {"t_von": t_von, "N": int(N), "coins": {}}
    nz = np.zeros((len(alle), N)); vol = np.zeros((len(alle), N)); ret = np.full((len(alle), N), np.nan); cl = np.full((len(alle), N), np.nan)
    da = np.zeros((len(alle), N), dtype=bool); vb = np.zeros((len(alle), N)); vs = np.zeros((len(alle), N)); nt = np.zeros((len(alle), N))
    fall = "CASE coin " + " ".join(f"WHEN '{c}' THEN {j}" for j, c in enumerate(alle)) + " END"
    liste = ", ".join(f"'{c}'" for c in alle)

    def stuecke(sql):
        try:
            cur = con.execute(sql, (t_von, t_bis))
        except sqlite3.Error:
            return
        while True:
            rows = cur.fetchmany(100_000)
            if not rows:
                return
            a = np.array(rows, dtype=float)
            j = a[:, 0].astype(np.int64); i = (a[:, 1].astype(np.int64) - t_von) // MIN
            g = (i >= 0) & (i < N) & (j >= 0)
            yield j[g], i[g], a[g]
    for j, i, a in stuecke(f"SELECT {fall}, ts, open, close, volume FROM bars WHERE ts>=? AND ts<? AND coin IN ({liste})"):
        o, c, v = a[:, 2], a[:, 3], a[:, 4]
        with np.errstate(divide="ignore", invalid="ignore"):
            nz[j, i] = np.where(np.isfinite(c * v), c * v, 0.0)
            vol[j, i] = np.where(np.isfinite(v), v, 0.0)
            ret[j, i] = np.where((o > 0) & (c > 0), np.log(c / o), np.nan)
        cl[j, i] = np.where(c > 0, c, np.nan)
        da[j, i] = True
    vb_f, vs_f, nt_f = vb.reshape(-1), vs.reshape(-1), nt.reshape(-1)        # Sichten: dieselben Felder, flach
    for j, i, a in stuecke(f"SELECT {fall}, ts, vol_buy, vol_sell, trades FROM bars10 WHERE ts>=? AND ts<? AND coin IN ({liste})"):
        k = j * N + i
        np.add.at(vb_f, k, np.nan_to_num(a[:, 2])); np.add.at(vs_f, k, np.nan_to_num(a[:, 3])); np.add.at(nt_f, k, np.nan_to_num(a[:, 4]))
    for j, coin in enumerate(alle):
        summe10 = vb[j] + vs[j]
        gross = np.maximum(vol[j], summe10)
        fraglich = (gross > 0) & (np.abs(vol[j] - summe10) > FRAGLICH_REL * gross)
        M["coins"][coin] = {"nz": nz[j], "vol": vol[j], "c": cl[j], "ret": ret[j], "da": da[j], "vb": vb[j], "vs": vs[j], "nt": nt[j],
                            "fraglich": fraglich}
    M["aufgezeichnet"] = M["coins"]["BTC"]["da"].copy()
    return M


def seiten_pruefen(M: dict, coins, a: int = 0, b: int | None = None) -> dict:
    """Pflichtprüfung der Seiten (3c): Rangkorrelation Taker-Saldo der Minute gegen die Rendite derselben Minute je Coin über die
    Spanne (Minuten-Indizes [a, b))."""
    b = M["N"] if b is None else b
    out = {}
    for coin in coins:
        m = M["coins"].get(coin)
        if m is None:
            out[coin] = {"rho": float("nan"), "n": 0, "ok": False}
            continue
        s = m["vb"] + m["vs"]
        gut = (s > 0) & m["da"] & np.isfinite(m["ret"]) & ~m["fraglich"] & M["aufgezeichnet"]
        gut[:max(0, a)] = False
        gut[max(0, b):] = False
        with np.errstate(divide="ignore", invalid="ignore"):
            I = np.where(s > 0, (m["vb"] - m["vs"]) / np.where(s > 0, s, 1.0), np.nan)
        rho = _rangkorrelation(I[gut], m["ret"][gut])
        out[coin] = {"rho": rho, "n": int(gut.sum()), "ok": bool(math.isfinite(rho) and rho > SEITEN_RHO_MIN)}
    return out


def kennzahl_reihen(M: dict, coin: str, W: int) -> dict:
    """
    RV und I_rel je Fensterende i (Fenster = Minuten [i − W, i), t = t_von + 60·i), nur aus der Vergangenheit (KONZEPT 4):
      RV(i) = U(i) ÷ Median U der Vergleichsfenster gleicher Tagesart der 28 Tage davor (≥ 70 % gültig, Median > 0);
      I_rel(i) = I(i) − Median I der Vergleichsfenster (I = (B − S)/(B + S), ≥ 20 Trades im Fenster).
    Gültig ist ein Fenster mit höchstens 5 % nicht aufgezeichneten oder fraglichen Minuten. Tagesart in der Mitte des Fensters.
    """
    N = M["N"]; m = M["coins"][coin]
    t_ende = M["t_von"] + MIN * np.arange(N + 1, dtype=np.int64)
    art = art_fenster(t_ende, W)
    luecke = (~M["aufgezeichnet"]) | m["fraglich"]
    U = _fenster(m["nz"], W); L = _fenster(luecke, W); B = _fenster(m["vb"], W); S = _fenster(m["vs"], W); NT = _fenster(m["nt"], W)
    ok_w = np.isfinite(L) & (L <= LUECKE_MAX * W)
    with np.errstate(divide="ignore", invalid="ignore"):
        I = np.where((B + S) > 0, (B - S) / (B + S), np.nan)
    ok_i = ok_w & np.isfinite(I) & (NT >= TS_MIN_TRADES)
    medU, nU, soll = _vergleich(U, ok_w & np.isfinite(U), art, 1440)
    medI, nI, _ = _vergleich(I, ok_i, art, 1440)
    genug = np.ceil(VERGLEICH_ANTEIL * soll)
    with np.errstate(divide="ignore", invalid="ignore"):
        rv = np.where(ok_w & (nU >= genug) & (medU > 0), U / medU, np.nan)
    irel = np.where(ok_i & (nI >= genug), I - medI, np.nan)
    return {"rv": rv, "irel": irel}


def spitze_reihen(M: dict, coin: str) -> dict:
    """
    Beschreibend (6.6): größter 5-min-Umsatz im Fenster ÷ Median der 5-min-Umsätze der 24 h davor. 5-min-Blöcke auf dem absoluten
    Raster; das Fenster endet an der letzten 5-min-Grenze ≤ t0. Gültig mit höchstens 5 % Lücken im Fenster und in den 24 h davor.
    """
    from numpy.lib.stride_tricks import sliding_window_view as swv
    N = M["N"]; t_von = M["t_von"]; m = M["coins"][coin]
    luecke = ((~M["aufgezeichnet"]) | m["fraglich"]).astype(float)
    off = int((-(t_von // MIN)) % 5)
    nb = (N - off) // 5
    out = {}
    if nb <= 0:
        return out
    B = m["nz"][off:off + 5 * nb].reshape(nb, 5).sum(axis=1)
    Lb = luecke[off:off + 5 * nb].reshape(nb, 5).sum(axis=1)
    kk = (np.arange(N + 1) - off) // 5                     # letzte Blockgrenze ≤ Minute i
    for W in (W_KURZ, W_LANG):
        w5 = W // 5
        r = np.full(nb + 1, np.nan)
        if nb >= w5 + 288:
            mx = swv(B, w5).max(axis=1); lw = swv(Lb, w5).sum(axis=1)
            md = _median_fenster(B, 288); l288 = swv(Lb, 288).sum(axis=1)
            k = np.arange(w5 + 288, nb + 1)
            ok = (lw[k - w5] <= LUECKE_MAX * W) & (l288[k - w5 - 288] <= LUECKE_MAX * 1440) & (md[k - w5 - 288] > 0)
            with np.errstate(divide="ignore", invalid="ignore"):
                r[k] = np.where(ok, mx[k - w5] / md[k - w5 - 288], np.nan)
        val = np.full(N + 1, np.nan)
        g = (kk >= 0) & (kk <= nb)
        val[g] = r[kk[g]]
        out[W] = val
    return out


def binance_rv_reihen(con_swing, M: dict, coins) -> dict:
    """6.4: Binance-RV aus den 30-min-Kerzen der USDT-Perps in swing.db (`sw_klines`, im Swing-Takt laufend ergänzt, nur abgeschlossene
    Kerzen; KONZEPT 12: nicht `klines30`, das nur der Handaufruf von hl_timestats füllt). Fensterende auf 30 min abgerundet, Normalwert
    wie RV (Vergleichsfenster gleicher Tagesart der 28 Tage davor, ≥ 70 %), alle Kerzen des Fensters vorhanden. Je (Coin, W) als Reihe
    auf dem Minutenraster."""
    out = {}
    N = M["N"]; t_von = M["t_von"]
    g0 = -(-t_von // 1800) * 1800
    ng = (t_von + N * MIN - g0) // 1800
    if ng <= 0:
        return out
    t_min = t_von + MIN * np.arange(N + 1, dtype=np.int64)
    e_min = (t_min - g0) // 1800
    for coin in coins:
        try:
            rows = con_swing.execute("SELECT ts, v FROM sw_klines WHERE coin=? AND ts>=? AND ts<?", (coin, g0, g0 + ng * 1800)).fetchall()
        except (sqlite3.Error, AttributeError):
            rows = []
        if not rows:
            continue
        a = np.array(rows, dtype=float)
        i = (a[:, 0].astype(np.int64) - g0) // 1800
        g = (i >= 0) & (i < ng)
        vol = np.zeros(ng); da = np.zeros(ng)
        vol[i[g]] = np.nan_to_num(a[g, 1]); da[i[g]] = 1.0
        t_e = g0 + 1800 * np.arange(ng + 1, dtype=np.int64)
        for W in (W_KURZ, W_LANG):
            w = W // 30
            U = _fenster(vol, w); nb = _fenster(da, w)
            ok = np.isfinite(nb) & (nb >= w)
            med, anz, soll = _vergleich(U, ok, art_fenster(t_e, W), 48)
            with np.errstate(divide="ignore", invalid="ignore"):
                rv30 = np.where(ok & (anz >= np.ceil(VERGLEICH_ANTEIL * soll)) & (med > 0), U / med, np.nan)
            val = np.full(N + 1, np.nan)
            gg = (e_min >= 0) & (e_min <= ng)
            val[gg] = rv30[e_min[gg]]
            out[(coin, W)] = val
    return out


def coinbase_ts_reihen(con, M: dict, coins) -> tuple:
    """6.5: Coinbase-Taker-Saldo (Spot, cb_bars, Seiten über hl_forecast.cb_seite_ab, U41), bereinigt wie TS: I − Median der
    Vergleichsfenster. „Aufgezeichnet“ = BTC hat eine Coinbase-Minute; mindestens 20 Trades im Fenster. Liefert (Reihen, cb_ab)."""
    N = M["N"]; t_von = M["t_von"]; t_bis = t_von + N * MIN; out = {}
    try:
        import hl_forecast
        cb_ab = hl_forecast.cb_seite_ab(con)
    except Exception:                                                          # noqa: BLE001 -- beschreibend, ohne Korrektur weiter
        cb_ab = None
    roh = {}
    for coin in sorted(set(coins) | {"BTC"}):
        try:
            rows = con.execute("SELECT ts, buy_usd, sell_usd, trades FROM cb_bars WHERE coin=? AND ts>=? AND ts<?", (coin, t_von, t_bis)).fetchall()
        except sqlite3.Error:
            rows = []
        if not rows:
            continue
        a = np.array(rows, dtype=float)
        i = (a[:, 0].astype(np.int64) - t_von) // MIN
        g = (i >= 0) & (i < N)
        i, a = i[g], a[g]
        kauf, verk = np.nan_to_num(a[:, 1]), np.nan_to_num(a[:, 2])
        if cb_ab is not None:
            vor = a[:, 0] < cb_ab
            kauf, verk = np.where(vor, verk, kauf), np.where(vor, kauf, verk)
        b = np.zeros(N); s = np.zeros(N); n = np.zeros(N); da = np.zeros(N, dtype=bool)
        b[i] = kauf; s[i] = verk; n[i] = np.nan_to_num(a[:, 3]); da[i] = True          # je (ts, coin) eine Zeile (Schlüssel)
        roh[coin] = (b, s, n, da)
    if "BTC" not in roh:
        return out, cb_ab
    nicht_auf = (~roh["BTC"][3]).astype(float)
    t_ende = t_von + MIN * np.arange(N + 1, dtype=np.int64)
    for coin in coins:
        if coin not in roh:
            continue
        b, s, n, _ = roh[coin]
        for W in (W_KURZ, W_LANG):
            B = _fenster(b, W); S = _fenster(s, W); NT = _fenster(n, W); L = _fenster(nicht_auf, W)
            ok = np.isfinite(L) & (L <= LUECKE_MAX * W) & (NT >= TS_MIN_TRADES) & ((B + S) > 0)
            with np.errstate(divide="ignore", invalid="ignore"):
                I = np.where(ok, (B - S) / (B + S), np.nan)
            med, anz, soll = _vergleich(I, ok, art_fenster(t_ende, W), 1440)
            out[(coin, W)] = np.where(ok & (anz >= np.ceil(VERGLEICH_ANTEIL * soll)), I - med, np.nan)
    return out, cb_ab


# ================================================================================================ Teil A: Trades

def labor_trades(pfad: str, bis_ts: int) -> dict:
    """
    Geschlossene Trades (vor bis_ts) mit Strategie, Gruppe, Horizont, Seite, t0 (KONZEPT 3b: Marktpreis = eroeffnet, Limit = Zeit der
    gefüllten Order; auf die Minute abgerundet) und netto_pct. Was herausfällt, wird je Grund und je Strategie gezählt. Dazu die offenen
    Positionen (für den Stand heute).
    """
    out = {"trades": [], "aus": {}, "aus_je": {}, "strategien": {}, "offen": [], "nach_stichtag": 0, "t0_ereignis": 0}

    def aus(name, grund):
        out["aus"][grund] = out["aus"].get(grund, 0) + 1
        d = out["aus_je"].setdefault(name, {})
        d[grund] = d.get(grund, 0) + 1
    con = _ro(pfad)
    if con is None:
        out["fehlt"] = True
        return out
    try:
        try:
            rows = con.execute("SELECT sid, name, titel, gruppe, regeln, aktiv FROM labor_strategie").fetchall()
        except sqlite3.Error:
            out["fehlt"] = True
            return out
        for sid, name, titel, gruppe, regeln, aktiv in rows:
            try:
                h = float((json.loads(regeln or "{}") or {}).get("h") or 4)
            except (ValueError, TypeError, AttributeError):
                h = 4.0
            out["strategien"][sid] = {"name": name, "titel": titel, "gruppe": gruppe, "h": h, "aktiv": int(aktiv or 0)}
        orders = {}
        try:
            for pos_id, erstellt in con.execute("SELECT pos_id, erstellt FROM labor_order WHERE pos_id IS NOT NULL"):
                orders[int(pos_id)] = max(int(erstellt or 0), orders.get(int(pos_id), 0))
        except sqlite3.Error:
            pass
        # Das Labor löscht erledigte Orders nach 30 Tagen (auch gefüllte); das Ereignis „limit“ beim Legen der Order (90 Tage) trägt dieselbe
        # Zeit. Schlüssel: Strategie (Name, auch alte Kennungen), Coin, Seite, Preis (= preis_ein der Füllung); KONZEPT 12.13
        ereignisse: dict = {}
        try:
            for ts_e, sid_e, coin_e, seite_e, preis_e in con.execute("SELECT ts, sid, coin, seite, preis FROM labor_ereignis WHERE art='limit'"):
                S_e = out["strategien"].get(sid_e)
                if S_e is not None and preis_e is not None and ts_e is not None:
                    ereignisse.setdefault((S_e["name"], coin_e, seite_e, float(preis_e)), []).append(int(ts_e))
        except sqlite3.Error:
            pass
        q = ("SELECT id, sid, coin, seite, eroeffnet, art_ein, geschlossen, grund_aus, netto_pct, preis_ein FROM labor_position "
             "WHERE status='geschlossen'")
        for pid, sid, coin, seite, eroeffnet, art_ein, geschlossen, grund_aus, netto_pct, preis_ein in con.execute(q):
            if geschlossen is None or int(geschlossen) >= bis_ts:
                out["nach_stichtag"] += 1
                continue
            S = out["strategien"].get(sid)
            if S is None:
                aus("?", "unbekannte Kennung")
                continue
            name = S["name"]
            if S["gruppe"] == "Grid":
                aus(name, "Grid (6.8)")
            elif S["gruppe"] == "Akkumulation":
                aus(name, "Akkumulation (6.9)")
            elif str(grund_aus or "").startswith("Regelversion abgelöst"):
                aus(name, "Regelversion abgelöst")
            elif coin not in COINS:
                aus(name, "anderer Coin")
            elif netto_pct is None:
                aus(name, "ohne Ergebnis")
            else:
                if str(art_ein or "").startswith("Limit"):
                    t = orders.get(int(pid))
                    if not t and preis_ein is not None:
                        kand = [x for x in ereignisse.get((name, coin, seite, float(preis_ein)), []) if x <= int(eroeffnet)]
                        if kand:
                            t = max(kand)
                            out["t0_ereignis"] += 1
                    if not t:
                        aus(name, "Limit ohne Order")
                        continue
                else:
                    t = int(eroeffnet)
                out["trades"].append({"id": int(pid), "sid": sid, "name": name, "gruppe": S["gruppe"], "h": S["h"], "coin": coin,
                                      "seite": seite, "t0": int(t) // MIN * MIN, "netto": float(netto_pct), "geschlossen": int(geschlossen)})
        try:
            for pid, sid, coin, seite, eroeffnet, art_ein in con.execute(
                    "SELECT id, sid, coin, seite, eroeffnet, art_ein FROM labor_position WHERE status='offen'"):
                S = out["strategien"].get(sid)
                if S and coin in COINS and S["gruppe"] not in OHNE_GRUPPEN:
                    t = orders.get(int(pid)) if str(art_ein or "").startswith("Limit") else None
                    out["offen"].append({"name": S["name"], "sid": sid, "gruppe": S["gruppe"], "coin": coin, "seite": seite,
                                         "t0": int(t or eroeffnet) // MIN * MIN, "h": S["h"]})
        except sqlite3.Error:
            pass
    finally:
        con.close()
    return out


# ================================================================================================ Kern: D je Schicht, Verdichtung

def d_schichten(v: np.ndarray, erg: np.ndarray, schicht: np.ndarray, t0: np.ndarray, n_schichten: int, mult: np.ndarray | None = None) -> tuple:
    """
    D je Schicht = Ø Ergebnis oberes Drittel − unteres Drittel nach v (k = n // 3 je Ende; Gleichstand nach t0, stabil); nur Schichten
    mit mindestens 9 gültigen Trades. mult = Vielfachheit je Trade (Bootstrap). Liefert (D, n) je Schicht (n = 0, D = nan ohne Wert).
    """
    ok = np.isfinite(v)
    idx = np.nonzero(ok)[0]
    if mult is not None:
        idx = np.repeat(idx, mult[idx])
    D = np.full(n_schichten, np.nan); n = np.zeros(n_schichten)
    if not len(idx):
        return D, n
    s = schicht[idx]
    o = np.lexsort((t0[idx], v[idx], s))
    s_o = s[o]; e_o = erg[idx][o]
    ns = np.bincount(s_o, minlength=n_schichten).astype(np.int64)
    start = np.concatenate([[0], np.cumsum(ns)[:-1]])
    rang = np.arange(len(o)) - start[s_o]
    k = ns // 3
    unten = rang < k[s_o]; oben = rang >= (ns - k)[s_o]
    su = np.bincount(s_o[unten], weights=e_o[unten], minlength=n_schichten)
    so = np.bincount(s_o[oben], weights=e_o[oben], minlength=n_schichten)
    gut = ns >= SCHICHT_MIN
    with np.errstate(divide="ignore", invalid="ignore"):
        D[gut] = (so[gut] - su[gut]) / k[gut]
    n[gut] = ns[gut]
    return D, n


def boot_ordnung(v: np.ndarray, schicht: np.ndarray, t0: np.ndarray) -> np.ndarray:
    """Für den Bootstrap: die gültigen Trades in der Reihenfolge (Schicht, v, t0) -- dieselbe in jeder Ziehung, nur die Vielfachheiten
    ändern sich. Gleichstand stabil nach dem Index wie in d_schichten."""
    idx = np.nonzero(np.isfinite(v))[0]
    return idx[np.lexsort((t0[idx], v[idx], schicht[idx]))]


def d_schichten_mult(o: np.ndarray, erg: np.ndarray, schicht: np.ndarray, n_schichten: int, mult: np.ndarray) -> tuple:
    """
    Wie d_schichten(v, …, mult), ohne neu zu sortieren: Die Kopien eines Trades liegen in der sortierten Folge nebeneinander; die
    Drittel ergeben sich aus den kumulierten Vielfachheiten (k = n // 3 Einheiten je Ende). Gleich bis auf die Rundung der Summen.
    """
    m = mult[o].astype(np.int64)
    s = schicht[o]
    ns = np.bincount(s, weights=m, minlength=n_schichten).astype(np.int64)
    start = np.concatenate([[0], np.cumsum(ns)[:-1]])
    vor = np.cumsum(m) - m - start[s]                        # Einheiten derselben Schicht vor diesem Trade
    k = ns // 3
    unten = np.clip(k[s] - vor, 0, m)
    oben = np.clip(vor + m - (ns - k)[s], 0, m)
    e = erg[o]
    su = np.bincount(s, weights=e * unten, minlength=n_schichten)
    so = np.bincount(s, weights=e * oben, minlength=n_schichten)
    D = np.full(n_schichten, np.nan); n = np.zeros(n_schichten)
    gut = ns >= SCHICHT_MIN
    with np.errstate(divide="ignore", invalid="ignore"):
        D[gut] = (so[gut] - su[gut]) / k[gut]
    n[gut] = ns[gut]
    return D, n


def drittel_details(v: np.ndarray, erg: np.ndarray, schicht: np.ndarray, t0: np.ndarray, n_schichten: int) -> dict:
    """6.2 (nur τ = 0): je Schicht n, Grenzen der Drittel (lo = größter Wert unten, hi = kleinster Wert oben), Ø Ergebnis und Anteil
    Treffer (Ergebnis > 0) im unteren, mittleren und oberen Drittel."""
    out = {k: np.full(n_schichten, np.nan) for k in ("lo", "hi", "mu_u", "mu_m", "mu_o", "tr_u", "tr_m", "tr_o")}
    out["n"] = np.zeros(n_schichten, dtype=np.int64)
    idx = np.nonzero(np.isfinite(v))[0]
    if not len(idx):
        return out
    s = schicht[idx]
    o = np.lexsort((t0[idx], v[idx], s))
    s_o = s[o]; e_o = erg[idx][o]; v_o = v[idx][o]
    ns = np.bincount(s_o, minlength=n_schichten).astype(np.int64)
    start = np.concatenate([[0], np.cumsum(ns)[:-1]])
    rang = np.arange(len(o)) - start[s_o]
    k = ns // 3
    unten = rang < k[s_o]; oben = rang >= (ns - k)[s_o]; mitte = ~unten & ~oben
    gut = ns >= SCHICHT_MIN
    with np.errstate(divide="ignore", invalid="ignore"):
        for z, m in (("u", unten), ("m", mitte), ("o", oben)):
            cnt = np.bincount(s_o[m], minlength=n_schichten)
            out[f"mu_{z}"] = np.where(gut & (cnt > 0), np.bincount(s_o[m], weights=e_o[m], minlength=n_schichten) / cnt, np.nan)
            out[f"tr_{z}"] = np.where(gut & (cnt > 0), np.bincount(s_o[m], weights=(e_o[m] > 0).astype(float), minlength=n_schichten) / cnt, np.nan)
    j = np.nonzero(gut)[0]
    out["lo"][j] = v_o[start[j] + k[j] - 1]
    out["hi"][j] = v_o[start[j] + ns[j] - k[j]]
    out["n"] = np.where(gut, ns, 0)
    return out


def verdichten(D: np.ndarray, n: np.ndarray, zu: np.ndarray, n_ziel: int) -> tuple:
    """Gewichtetes Mittel der Schichten (Gewicht n) je Ziel (zu = Ziel je Schicht, −1 = keins). Liefert (D, n) je Ziel."""
    w = np.where(np.isfinite(D) & (zu >= 0), n, 0.0)
    z = np.where(zu >= 0, zu, 0)
    num = np.bincount(z, weights=w * np.nan_to_num(D), minlength=n_ziel)[:n_ziel]
    den = np.bincount(z, weights=w, minlength=n_ziel)[:n_ziel]
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(den > 0, num / den, np.nan), den


def p_zentriert(d: float, null: np.ndarray) -> tuple:
    """p der Hauptprüfungen (KONZEPT 5): Abstand vom Median der Null, (1 + #) ÷ (1 + N)."""
    null = null[np.isfinite(null)]
    if not len(null) or not math.isfinite(d):
        return float("nan"), float("nan")
    m = float(np.median(null))
    return float((1 + np.sum(np.abs(null - m) >= abs(d - m))) / (1 + len(null))), m


def p_normal(d: float, null: np.ndarray) -> tuple:
    """p je Strategie (KONZEPT 5): z = (D − Median der Null) ÷ Standardabweichung der Null, zweiseitig; dazu die Wölbung der Null."""
    null = null[np.isfinite(null)]
    if len(null) < 20 or not math.isfinite(d):
        return float("nan"), float("nan"), float("nan"), float("nan")
    m = float(np.median(null)); sd = float(null.std(ddof=1))
    if sd <= 0:
        return float("nan"), float("nan"), m, float("nan")
    z = (d - m) / sd
    kurt = float(np.mean(((null - null.mean()) / sd) ** 4))
    return float(math.erfc(abs(z) / math.sqrt(2))), z, m, kurt


def holm(p: list) -> list:
    """Holm-Bonferroni; nan bleibt nan."""
    idx = [i for i, x in enumerate(p) if x is not None and math.isfinite(x)]
    m = len(idx); out = [float("nan")] * len(p)
    lauf = 0.0
    for r, i in enumerate(sorted(idx, key=lambda j: p[j])):
        lauf = max(lauf, min(1.0, (m - r) * p[i]))
        out[i] = lauf
    return out


def bh(p: list) -> list:
    """Benjamini-Hochberg q-Werte; nan bleibt nan."""
    idx = [i for i, x in enumerate(p) if x is not None and math.isfinite(x)]
    m = len(idx); out = [float("nan")] * len(p)
    if not m:
        return out
    order = sorted(idx, key=lambda j: p[j])
    q = [min(1.0, p[j] * m / (r + 1)) for r, j in enumerate(order)]
    for r in range(m - 2, -1, -1):
        q[r] = min(q[r], q[r + 1])
    for r, j in enumerate(order):
        out[j] = q[r]
    return out


def _band(x: np.ndarray) -> tuple:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 20:
        return float("nan"), float("nan")
    return float(np.quantile(x, 0.05)), float(np.quantile(x, 0.95))


# ================================================================================================ Kern: ein Teil auswerten

class Teil:
    """
    Trades eines Teils als Felder: t0 (Zeit der Entscheidung, s), erg (netto_pct bzw. R), strat (Index), schicht (Index der Schicht
    Kennung × Seite × Tagesart), tag (Kalendertag für den Bootstrap), werte(kennzahl, verschiebung) -> Wert je Trade (nan = nicht
    bestimmt). namen, gruppen je Strategie; schicht_strat = Strategie je Schicht; schl = Schlüssel (Kennung, Seite, Tagesart) -> Schicht.
    """

    def __init__(self, t0, erg, strat, schicht, schicht_strat, namen, gruppen, werte, tau, tag=None, block_tage: int = 1, seite=None,
                 coin=None, schl=None):
        self.t0 = np.asarray(t0, dtype=np.int64); self.erg = np.asarray(erg, dtype=float)
        self.strat = np.asarray(strat, dtype=np.int64); self.schicht = np.asarray(schicht, dtype=np.int64)
        self.schicht_strat = np.asarray(schicht_strat, dtype=np.int64)
        self.namen = list(namen); self.gruppen = list(gruppen); self.werte = werte; self.tau = np.asarray(tau, dtype=np.int64)
        self.tag = np.asarray(tag if tag is not None else self.t0 // TAG, dtype=np.int64)
        self.block_tage = block_tage
        self.seite = np.asarray(seite) if seite is not None else np.array(["long"] * len(self.t0))
        self.coin = np.asarray(coin) if coin is not None else np.array([""] * len(self.t0))
        self.schl = schl or {}
        self.n_s = len(self.schicht_strat); self.n_strat = len(self.namen)


def _bootstrap_mult(tag: np.ndarray, tage_g: np.ndarray, block_tage: int, rng) -> np.ndarray:
    """Vielfachheit je Trade aus dem Blockbootstrap über Kalendertage. Block 1: die Tage mit gültigen Trades mit Zurücklegen gezogen;
    sonst zirkuläre Blöcke von block_tage Kalendertagen über die Spanne der gültigen Tage."""
    d0, d1 = int(tage_g[0]), int(tage_g[-1]); L = d1 - d0 + 1
    if block_tage <= 1:
        zug = rng.choice(tage_g, size=len(tage_g), replace=True)
        cnt = np.bincount(zug - d0, minlength=L)
    else:
        nb = int(math.ceil(L / block_tage))
        starts = rng.integers(0, L, nb)
        cover = ((starts[:, None] + np.arange(block_tage)[None, :]) % L).ravel()[:L]
        cnt = np.bincount(cover, minlength=L)
    drin = (tag >= d0) & (tag <= d1)
    out = np.zeros(len(tag), dtype=np.int64)
    out[drin] = cnt[tag[drin] - d0]
    return out


def auswerten(T: Teil, kennzahl: str, pool, n_boot: int = N_BOOT, seed: int = SEED, extra_maske=None, mit_null: bool = True,
              mit_haelften: bool = True) -> dict:
    """
    Echt (τ = 0), Nullmodell (alle τ von T), Bootstrap und Hälften für eine Kennzahl. pool = Funktion(n gültig je Strategie) -> bool je
    Strategie, oder fest (bool je Strategie). Pool und Menge der Trades stehen bei τ = 0 fest (KONZEPT 5); fehlt die verschobene
    Kennzahl, fehlt der Trade nur in dieser Verschiebung (gezählt). extra_maske = bool je Trade (Teilmengen der beschreibenden Teile).
    """
    v0 = T.werte(kennzahl, 0)
    if extra_maske is not None:
        v0 = np.where(extra_maske, v0, np.nan)
    gueltig = np.isfinite(v0)
    n_gueltig = np.bincount(T.strat[gueltig], minlength=T.n_strat)
    pool_s = np.asarray(pool(n_gueltig) if callable(pool) else pool, dtype=bool)
    zu_pool = np.where(pool_s[T.schicht_strat], 0, -1)

    def rechne(v, mult=None):
        Ds, ns = d_schichten(v, T.erg, T.schicht, T.t0, T.n_s, mult)
        Dst, nst = verdichten(Ds, ns, T.schicht_strat, T.n_strat)
        Dp, npl = verdichten(Ds, ns, zu_pool, 1)
        return Dst, nst, float(Dp[0]), float(npl[0])
    Ds0, ns0 = d_schichten(v0, T.erg, T.schicht, T.t0, T.n_s)
    D_st, n_st, D_pool, n_pool = rechne(v0)
    beitrag = gueltig & (ns0[T.schicht] > 0)
    n_in = np.bincount(T.strat[beitrag], minlength=T.n_strat)
    pool_trade = beitrag & pool_s[T.strat]
    null_st = np.full((len(T.tau), T.n_strat), np.nan); null_pool = np.full(len(T.tau), np.nan); null_n = np.zeros(len(T.tau))
    null_nst = np.zeros((len(T.tau), T.n_strat))
    if mit_null and len(T.tau):
        for j, tau in enumerate(T.tau):
            v = T.werte(kennzahl, int(tau))
            v = np.where(gueltig, v, np.nan)
            a, nst, b, c = rechne(v)
            null_st[j] = a; null_nst[j] = nst; null_pool[j] = b; null_n[j] = c
    rng = np.random.default_rng(seed)
    boot_st = np.full((n_boot, T.n_strat), np.nan); boot_pool = np.full(n_boot, np.nan); boot_nst = np.zeros((n_boot, T.n_strat))
    if gueltig.any() and n_boot > 0:
        tage_g = np.unique(T.tag[gueltig])
        o_boot = boot_ordnung(v0, T.schicht, T.t0)
        for b in range(n_boot):
            mult = np.where(gueltig, _bootstrap_mult(T.tag, tage_g, T.block_tage, rng), 0)
            Ds, ns = d_schichten_mult(o_boot, T.erg, T.schicht, T.n_s, mult)
            boot_st[b], boot_nst[b] = verdichten(Ds, ns, T.schicht_strat, T.n_strat)
            boot_pool[b] = float(verdichten(Ds, ns, zu_pool, 1)[0][0])
    h1 = h2 = float("nan")
    hs1 = hs2 = np.full(T.n_strat, np.nan)
    if mit_haelften:
        pg = gueltig & pool_s[T.strat]
        if pg.any():
            med_p = float(np.median(T.t0[pg]))
            h1 = rechne(np.where(T.t0 < med_p, v0, np.nan))[2]; h2 = rechne(np.where(T.t0 >= med_p, v0, np.nan))[2]
        med_s = np.full(T.n_strat, np.inf)
        for s in range(T.n_strat):
            sel = gueltig & (T.strat == s)
            if sel.any():
                med_s[s] = float(np.median(T.t0[sel]))
        erst = T.t0 < med_s[T.strat]
        hs1 = rechne(np.where(erst, v0, np.nan))[0]; hs2 = rechne(np.where(~erst, v0, np.nan))[0]
    spanne_st = np.zeros(T.n_strat)
    for s in range(T.n_strat):
        sel = beitrag & (T.strat == s)
        if sel.sum() > 1:
            spanne_st[s] = (T.t0[sel].max() - T.t0[sel].min()) / TAG
    sp_pool = float((T.t0[pool_trade].max() - T.t0[pool_trade].min()) / TAG) if pool_trade.sum() > 1 else 0.0
    return {"kennzahl": kennzahl, "pool": pool_s, "v0": v0, "gueltig": gueltig, "n_gueltig": n_gueltig, "n_in": n_in, "ns0": ns0,
            "D_st": D_st, "n_st": n_st, "D_pool": D_pool, "n_pool": int(round(n_pool)), "spanne_pool": sp_pool, "spanne_st": spanne_st,
            "null_st": null_st, "null_nst": null_nst, "null_pool": null_pool, "null_n": null_n, "boot_st": boot_st, "boot_nst": boot_nst,
            "boot_pool": boot_pool,
            "h_pool": (h1, h2), "h_st": (hs1, hs2)}


def urteile(R: dict, T: Teil, pruef_pool_min: int, pruef_pool_tage: float, urteil_erlaubt: bool) -> dict:
    """Hauptprüfung (gepoolt) und je Strategie die Rohwerte; Holm/BH rechnen _haupt_urteil und familie_urteilen über die Familie."""
    p, m = p_zentriert(R["D_pool"], R["null_pool"])
    h1, h2 = R["h_pool"]
    vz = np.sign(R["D_pool"] - m) if math.isfinite(m) and math.isfinite(R["D_pool"]) else 0
    haelften = bool(vz != 0 and np.sign(h1 - m) == vz and np.sign(h2 - m) == vz)
    pruefbar = R["n_pool"] >= pruef_pool_min and R["spanne_pool"] >= pruef_pool_tage and math.isfinite(p)
    nn = R["null_n"][R["null_n"] > 0]
    haupt = {"D": R["D_pool"], "n": R["n_pool"], "p": p, "m": m, "band": _band(R["boot_pool"]), "haelften": haelften, "h": (h1, h2),
             "pruefbar": pruefbar, "urteil_erlaubt": urteil_erlaubt, "spanne": R["spanne_pool"],
             "null_n": (float(nn.min()), float(np.median(nn))) if len(nn) else (float("nan"), float("nan"))}
    je = []
    for s in range(T.n_strat):
        pn, z, ms, kurt = p_normal(float(R["D_st"][s]), R["null_st"][:, s])
        a, b = R["h_st"][0][s], R["h_st"][1][s]
        vz_s = np.sign(R["D_st"][s] - ms) if math.isfinite(ms) and math.isfinite(R["D_st"][s]) else 0
        hl = bool(vz_s != 0 and np.sign(a - ms) == vz_s and np.sign(b - ms) == vz_s)
        pr = int(R["n_in"][s]) >= STRAT_MIN and R["spanne_st"][s] >= STRAT_TAGE and math.isfinite(pn)
        je.append({"name": T.namen[s], "gruppe": T.gruppen[s], "D": float(R["D_st"][s]), "n": int(R["n_in"][s]), "p": pn, "z": z,
                   "m": ms, "kurt": kurt, "band": _band(R["boot_st"][:, s]), "haelften": hl, "h": (a, b), "pruefbar": pr,
                   "pool": bool(R["pool"][s]), "idx": s})
    return {"haupt": haupt, "je": je}


def familie_urteilen(tests: list, urteil_erlaubt: bool) -> None:
    """Holm und BH über die prüfbaren Tests einer Familie (Strategie × Kennzahl); trägt p_holm, q und das Urteil ein (KONZEPT 5)."""
    pr = [t for t in tests if t.get("pruefbar")]
    ph = holm([t["p"] for t in pr]); qb = bh([t["p"] for t in pr])
    for t, a, b in zip(pr, ph, qb):
        t["p_holm"] = a; t["q"] = b
        band_ohne_0 = math.isfinite(t["band"][0]) and (t["band"][0] > 0 or t["band"][1] < 0)
        belegt = a < ALPHA and t["haelften"] and band_ohne_0
        hinweis = (not belegt) and b < BH_Q and t["haelften"]
        t["urteil"] = ("belegt" if belegt else "Hinweis" if hinweis else "nicht belegt") if urteil_erlaubt else "vorläufig"
    for t in tests:
        if not t.get("pruefbar"):
            t["p_holm"] = float("nan"); t["q"] = float("nan"); t["urteil"] = "nicht prüfbar"


def _haupt_urteil(haupt: list, erlaubt: bool) -> None:
    """Holm je Teil über die beiden Hauptprüfungen; belegt = p_Holm < 0,05 und beide Hälften mit demselben Vorzeichen (KONZEPT 5). Eine
    nicht prüfbare Hauptprüfung zählt mit p = 1 (Holm bleibt bei zwei Tests; KONZEPT 12.13)."""
    ph = holm([h["p"] if h["pruefbar"] and math.isfinite(h["p"]) else 1.0 for h in haupt])
    for h, a in zip(haupt, ph):
        h["p_holm"] = a
        if not h["pruefbar"]:
            h["urteil"] = "nicht prüfbar"
        elif not erlaubt:
            h["urteil"] = "vorläufig"
        else:
            h["urteil"] = "belegt" if (a < ALPHA and h["haelften"]) else "nicht belegt"


# ================================================================================================ Teil A zusammenbauen

def schichten_bauen(trades: list) -> tuple:
    """Strategie-Index je Name, Schicht (Kennung × Seite × Tagesart von t0 = am Ende des Fensters, Zeitpunkt der Entscheidung)."""
    namen = sorted({t["name"] for t in trades})
    s_idx = {n: i for i, n in enumerate(namen)}
    arten = tagesart(np.array([t["t0"] for t in trades], dtype=np.int64)) if trades else np.zeros(0, dtype=np.int64)
    schl: dict = {}; sstrat = []
    schicht = np.empty(len(trades), dtype=np.int64); strat = np.empty(len(trades), dtype=np.int64)
    for j, t in enumerate(trades):
        k = (t.get("sid", t["name"]), t["seite"], int(arten[j]))
        if k not in schl:
            schl[k] = len(schl); sstrat.append(s_idx[t["name"]])
        schicht[j] = schl[k]; strat[j] = s_idx[t["name"]]
    return namen, strat, schicht, np.array(sstrat, dtype=np.int64), schl


def pool_a(namen: list, gruppen: list):
    """Pool Teil A (KONZEPT 4): ≥ 30 gültige Trades bei τ = 0, ohne Kontrollen, gekoppelte, Spiegel „…_gegen“, Grid, Akkumulation."""
    raus = np.array([ist_kontrolle(n) or n in GEKOPPELT or n in SPIEGEL_GEGEN or g in OHNE_GRUPPEN for n, g in zip(namen, gruppen)],
                    dtype=bool)

    def fn(n_gueltig):
        return (np.asarray(n_gueltig) >= POOL_MIN) & ~raus
    return fn


class ReihenA:
    """Fertige Kennzahl-Reihen je (Coin, Fenster) mit zirkulärer Verschiebung über die Spanne [a, b) (Indizes der Fensterenden)."""

    def __init__(self, M: dict, coins, seiten_ok: dict, t_a: int, t_b: int, extra: dict | None = None):
        self.M = M; self.t_von = M["t_von"]; self.N = M["N"]
        self.a = int(min(self.N, max(0, (t_a - self.t_von) // MIN)))
        self.b = int(min(self.N, max(self.a, (t_b - self.t_von) // MIN)))
        self.R = {(c, W): kennzahl_reihen(M, c, W) for c in coins if c in M["coins"] for W in (W_KURZ, W_LANG)}
        self.seiten_ok = dict(seiten_ok); self.extra = extra or {}

    def reihe(self, kennzahl: str, c: str, w: int):
        if kennzahl == "rv":
            r = self.R.get((c, w))
            return None if r is None else r["rv"]
        if kennzahl == "ts":
            if not self.seiten_ok.get(c):
                return None
            r = self.R.get((c, w))
            return None if r is None else r["irel"]
        return (self.extra.get(kennzahl) or {}).get((c, w))

    @staticmethod
    def gruppen(coin, W) -> dict:
        g: dict = {}
        for j, key in enumerate(zip(np.asarray(coin).tolist(), np.asarray(W).tolist())):
            g.setdefault(key, []).append(j)
        return {k: np.asarray(v, dtype=np.int64) for k, v in g.items()}

    def werte(self, kennzahl: str, coin, W, t0, vz, tau_min: int, gruppen: dict | None = None) -> np.ndarray:
        t0 = np.asarray(t0, dtype=np.int64); vz = np.asarray(vz, dtype=float)
        out = np.full(len(t0), np.nan)
        i = (t0 - self.t_von) // MIN
        if tau_min:
            L = self.b - self.a
            if L <= 0:
                return out
            i = self.a + np.mod(i - tau_min - self.a, L)
        for (c, w), sel in (gruppen if gruppen is not None else self.gruppen(coin, W)).items():
            arr = self.reihe(kennzahl, c, int(w))
            if arr is None:
                continue
            ii = i[sel]
            drin = (ii >= 0) & (ii < len(arr))
            vals = np.full(len(ii), np.nan)
            vals[drin] = arr[ii[drin]]
            if kennzahl in ("ts", "cb_ts"):
                vals = vals * vz[sel]
            out[sel] = vals
        return out


def teil_a_bauen(trades: list, Rr: ReihenA, tau_h=TAU_A) -> Teil:
    namen, strat, schicht, schicht_strat, schl = schichten_bauen(trades)
    gruppe_von = {t["name"]: ("volumengekoppelt" if t["name"] in GEKOPPELT else "Kontrolle" if ist_kontrolle(t["name"]) else t["gruppe"])
                  for t in trades}
    gruppen = [gruppe_von[n] for n in namen]
    t0 = np.array([t["t0"] for t in trades], dtype=np.int64)
    coin = np.array([t["coin"] for t in trades])
    W = np.array([W_KURZ if t["h"] <= H_GRENZE else W_LANG for t in trades], dtype=np.int64)
    vz = np.array([1.0 if t["seite"] == "long" else -1.0 for t in trades])
    erg = np.array([t["netto"] for t in trades], dtype=float)
    gr = ReihenA.gruppen(coin, W)

    def werte(k, tau):
        return Rr.werte(k, coin, W, t0, vz, int(tau) * 60, gr)
    T = Teil(t0, erg, strat, schicht, schicht_strat, namen, gruppen, werte, wirksame_verschiebungen(tau_h, Rr.b - Rr.a),
             seite=np.array([t["seite"] for t in trades]), coin=coin, schl=schl)
    T.tau_festgelegt = len(tau_h)
    return T


def wirksame_verschiebungen(tau_h, L: int) -> np.ndarray:
    """KONZEPT 12.14: Ist die Spanne (L Minuten) kürzer als 28 Tage, landen τ und τ − L zirkulär an derselben Stelle -- die Doppelten fallen
    weg (die erste bleibt), ebenso jede Verschiebung, die zirkulär näher als 24 h an 0 läge."""
    tau_h = np.asarray(tau_h, dtype=np.int64)
    if L <= 0 or not len(tau_h):
        return tau_h
    eff = np.mod(tau_h * 60, L)
    _u, erst = np.unique(eff, return_index=True)
    keep = np.zeros(len(tau_h), dtype=bool); keep[erst] = True
    keep &= np.minimum(eff, L - eff) >= 24 * 60
    return tau_h[keep]


# ================================================================================================ Teil B: Swing-Historie

def tagesreihen_b(pfad_hebel: str, coins, ende_ts: int) -> dict:
    """Tagesumsatz und Taker-Kauf in USD des USDⓈ-M-Perps <COIN>USDT (hebel.db, Markt „um“; tag = Tage seit 1970) bis vor ende_ts."""
    out = {}
    con = _ro(pfad_hebel)
    if con is None:
        return out
    try:
        for coin in coins:
            try:
                rows = con.execute("SELECT tag, v_usd, taker_usd FROM hb_kerzen WHERE markt='um' AND symbol=? AND tag < ? ORDER BY tag",
                                   (f"{coin}USDT", ende_ts // TAG)).fetchall()
            except sqlite3.Error:
                rows = []
            if not rows:
                continue
            a = np.array(rows, dtype=float)
            d0 = int(a[0, 0]); n = int(a[-1, 0]) - d0 + 1
            v = np.full(n, np.nan); tk = np.full(n, np.nan)
            i = a[:, 0].astype(np.int64) - d0
            v[i] = a[:, 1]; tk[i] = a[:, 2]
            out[coin] = {"d0": d0, "n": n, "v": v, "taker": tk}
    finally:
        con.close()
    return out


def kennzahl_tage(H: dict) -> dict:
    """RV_Tag und Q_rel je Tag (KONZEPT 4, Teil B): gegen die Tage gleicher Tagesart der 28 Tage davor (Kalendertage)."""
    v = H["v"]; tk = H["taker"]; n = H["n"]
    art = tagesart((H["d0"] + np.arange(n, dtype=np.int64)) * TAG)
    ok_v = np.isfinite(v) & (v > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        q = np.where(ok_v & np.isfinite(tk), 2.0 * tk / v - 1.0, np.nan)
    medV, nV, soll = _vergleich(np.where(ok_v, v, np.nan), ok_v, art, 1)
    medQ, nQ, _ = _vergleich(q, np.isfinite(q), art, 1)
    genug = np.ceil(VERGLEICH_ANTEIL * soll)
    with np.errstate(divide="ignore", invalid="ignore"):
        rv = np.where(ok_v & (nV >= genug) & (medV > 0), v / medV, np.nan)
    qrel = np.where(np.isfinite(q) & (nQ >= genug), q - medQ, np.nan)
    return {"rv": rv, "qrel": qrel}


def swing_daten(pfad_swing: str, coins, ende_ts: int) -> tuple:
    """Kerzen und Funding aus swing.db bis vor ende_ts, aufbereitet wie in der Swing-Studie (hl_swing.daten_aufbereiten)."""
    import hl_swing as SW
    daten, info = {}, {}
    con = _ro(pfad_swing)
    if con is None:
        return daten, {"swing.db": "fehlt"}
    try:
        for coin in coins:
            try:
                K = SW.kerzen_lesen(con, coin)
            except sqlite3.Error:
                K = None
            if K is None:
                info[coin] = "keine Kerzen"
                continue
            k = K["ts"] < ende_ts
            K = {key: arr[k] for key, arr in K.items()}
            try:
                F = SW.funding_lesen(con, coin)
            except sqlite3.Error:
                F = {"ts": np.zeros(0, dtype=np.int64), "rate": np.zeros(0)}
            f = F["ts"] < ende_ts
            F = {key: arr[f] for key, arr in F.items()}
            D = SW.daten_aufbereiten(K, F) if len(K["ts"]) else None
            if D is None or D["T"]["nd"] < SW.VORLAUF_TAGE + 40:
                info[coin] = "zu kurz"
                continue
            daten[coin] = D
            info[coin] = f"{_dt(int(D['T']['tag_ts'][0]), False)}–{_dt(int(D['T']['tag_ts'][-1]), False)}"
    finally:
        con.close()
    return daten, info


def _lauf_mit_zufall(SW, coin, R, T, F, I, d_von, d_bis, rng) -> list:
    """Wie hl_swing.lauf, aber mit Zufallszahlen für die Kontroll-Strategien (beschreibend, 6.12)."""
    trades = []; d = d_von
    while d <= d_bis:
        if not T["voll"][d]:
            d += 1; continue
        u = (float(rng.random()), float(rng.random()))
        sig = SW.einstieg(R, T, I, d, u)
        if sig is None:
            d += 1; continue
        tr = SW.handel(coin, R, T, F, I, d + 1, sig, False)
        if tr is None:
            d += 1; continue
        trades.append(tr)
        d = tr["frei_ab"] if tr["frei_ab"] > d else d + 1
    return trades


def swing_trades(daten: dict, namen=None, zufall: bool = False, seed: int = SEED) -> dict:
    """Trades der Swing-Strategien aus hl_swing.lauf über den Bewertungsbereich; ohne „offen am Ende“ (gezählt). t0 = Beginn von Tag e−1
    (Entscheidung am Schluss von e−1, Einstieg zur Eröffnung von e)."""
    import hl_swing as SW
    namen = namen or SW.HAUPT
    out = {"trades": [], "offen_am_ende": 0}
    rng = np.random.default_rng(seed)
    for name in namen:
        R = SW.STRATEGIEN[name]
        for coin, D in daten.items():
            T, F, I = D["T"], D["F"], D["I"]
            d_von, d_bis = SW.bewertungsbereich(T, I)
            if d_bis - d_von < 30:
                continue
            tr = _lauf_mit_zufall(SW, coin, R, T, F, I, d_von, d_bis, rng) if zufall else SW.lauf(coin, R, T, F, I, d_von, d_bis, False)["trades"]
            for t in tr:
                if t.get("grund") == "offen am Ende":
                    out["offen_am_ende"] += 1
                    continue
                out["trades"].append({"name": name, "sid": name, "gruppe": "Swing", "coin": coin, "seite": t["seite"],
                                      "t0": int(t["t_in"]) // TAG * TAG - TAG, "t_in": int(t["t_in"]), "netto": float(t["R"])})
    return out


class ReihenB:
    """Fertige Tagesreihen je Coin; zirkuläre Verschiebung je Coin über dessen Spanne (Tage mit bestimmtem Wert), gemeinsames τ."""

    def __init__(self, H: dict):
        self.H = H; self.K = {c: kennzahl_tage(h) for c, h in H.items()}
        self.spanne = {}
        for c, k in self.K.items():
            idx = np.nonzero(np.isfinite(k["rv"]) | np.isfinite(k["qrel"]))[0]
            self.spanne[c] = (int(idx[0]), int(idx[-1]) + 1) if len(idx) else (0, 0)

    def werte(self, kennzahl: str, coin: np.ndarray, t0: np.ndarray, vz: np.ndarray, tau_tage: int) -> np.ndarray:
        out = np.full(len(t0), np.nan)
        for c in set(np.asarray(coin).tolist()):
            if c not in self.K:
                continue
            sel = coin == c; H = self.H[c]; a, b = self.spanne[c]; L = b - a
            d = t0[sel] // TAG - H["d0"]
            if tau_tage:
                if L <= 0:
                    continue
                d = a + np.mod(d - tau_tage - a, L)
            drin = (d >= 0) & (d < H["n"])
            arr = self.K[c]["rv" if kennzahl == "rv" else "qrel"]
            v = np.full(len(d), np.nan); v[drin] = arr[d[drin]]
            out[sel] = v * (vz[sel] if kennzahl == "ts" else 1.0)
        return out


def teil_b_bauen(trades: list, Rb: ReihenB, tau_d=TAU_B) -> Teil:
    namen, strat, schicht, schicht_strat, schl = schichten_bauen(trades)
    t0 = np.array([t["t0"] for t in trades], dtype=np.int64)
    coin = np.array([t["coin"] for t in trades])
    vz = np.array([1.0 if t["seite"] == "long" else -1.0 for t in trades])
    erg = np.array([t["netto"] for t in trades], dtype=float)

    def werte(k, tau):
        return Rb.werte(k, coin, t0, vz, int(tau))
    return Teil(t0, erg, strat, schicht, schicht_strat, namen, ["Swing"] * len(namen), werte, tau_d, block_tage=BLOCK_B_TAGE,
                seite=np.array([t["seite"] for t in trades]), coin=coin, schl=schl)


def teil_b_vollstaendig(H: dict, pfad_swing: str, coins, ende_ts: int) -> tuple:
    """Historie vollständig (KONZEPT 5, Präzisierung 12): je Coin Tagesumsatz (um, <COIN>USDT) bis 23.10. mit höchstens 1 % fehlenden
    Tagen seit dem ersten Tag, und 30-min-Kerzen in swing.db bis 23.10. 23:30 UTC."""
    fehlt = []
    for c in coins:
        h = H.get(c)
        if h is None:
            fehlt.append(f"{c}: kein Tagesumsatz in hebel.db")
            continue
        if h["d0"] + h["n"] < ende_ts // TAG:
            fehlt.append(f"{c}: Tagesumsatz nur bis {_dt((h['d0'] + h['n'] - 1) * TAG, False)}")
        if np.isnan(h["v"]).mean() > 0.01:
            fehlt.append(f"{c}: {int(np.isnan(h['v']).sum())} Tage ohne Umsatz")
    con = _ro(pfad_swing)
    if con is None:
        fehlt.append("swing.db fehlt")
    else:
        try:
            for c in coins:
                r = con.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=? AND ts < ?", (c, ende_ts)).fetchone()
                if not r or r[0] is None or int(r[0]) < ende_ts - 1800:
                    fehlt.append(f"{c}: 30-min-Kerzen nur bis {_dt(r[0]) if r and r[0] else '—'}")
        except sqlite3.Error as e:
            fehlt.append(f"swing.db: {e}")
        finally:
            con.close()
    return (not fehlt), fehlt


def pruefsumme_b(trades: list, H: dict) -> str:
    """Prüfsumme der Eingangsdaten von Teil B (Trades und Tagesreihen bis 23.10.): Das Urteil gilt aus dem ersten Lauf mit vollständiger
    Historie (KONZEPT 5); die Studie schreibt nichts -- eine andere Prüfsumme in einem späteren Bericht zeigt, dass sich Daten geändert haben."""
    import hashlib
    h = hashlib.sha256()
    for t in sorted(trades, key=lambda x: (x["name"], x["coin"], x["t_in"], x["seite"])):
        h.update(f'{t["name"]}|{t["coin"]}|{t["seite"]}|{t["t_in"]}|{t["netto"]:.12g};'.encode())
    for c in sorted(H):
        h.update(c.encode()); h.update(np.int64(H[c]["d0"]).tobytes())
        h.update(np.nan_to_num(np.asarray(H[c]["v"], dtype=float)).tobytes()); h.update(np.nan_to_num(np.asarray(H[c]["taker"], dtype=float)).tobytes())
    return h.hexdigest()[:12]


def pool_b(namen: list):
    """Pool Teil B: die vier Swing-Strategien (ohne Zufalls-Kontrollen)."""
    raus = np.array([ist_kontrolle(n) for n in namen], dtype=bool)

    def fn(n_gueltig):
        return (np.asarray(n_gueltig) > 0) & ~raus
    return fn


# ================================================================================================ Beschreibende Teile

def gruppen_d(T: Teil, R: dict) -> list:
    """6.1: D je Gruppe (ohne Kontrollen und „…_gegen“, wie im Pool), Band und z aus denselben Läufen, je Verschiebung und Ziehung mit deren
    eigenen Gewichten neu verdichtet (wie D_pool)."""
    out = []
    for g in GRUPPEN:
        sel = np.array([(gg == g) and not ist_kontrolle(n) and n not in SPIEGEL_GEGEN for n, gg in zip(T.namen, T.gruppen)], dtype=bool)
        if not sel.any():
            continue

        def ag(D, n):
            w = np.where(sel, n, 0.0)
            ok = np.isfinite(D) & (w > 0)
            return float(np.sum(D[ok] * w[ok]) / np.sum(w[ok])) if ok.any() else float("nan")
        d = ag(R["D_st"], R["n_st"])
        null = np.array([ag(x, n) for x, n in zip(R["null_st"], R["null_nst"])])
        boot = np.array([ag(x, n) for x, n in zip(R["boot_st"], R["boot_nst"])])
        _p, z, _m, _k = p_normal(d, null)
        out.append({"gruppe": g, "D": d, "n": int(np.sum(R["n_in"][sel])), "z": z, "band": _band(boot), "null": null})
    return out


def zufall_vergleich(T: Teil, A: dict) -> dict | None:
    """6.3: Kontrolle „Zufall“ (Markteffekt) aus denselben Läufen und je Strategie D − D(Zufall) mit Band (gleiche Ziehungen)."""
    if "zufall" not in T.namen:
        return None
    iz = T.namen.index("zufall")
    out = {}
    for k, _ in KENNZAHLEN:
        R = A[k]["roh"]
        _p, z, m, _ku = p_normal(float(R["D_st"][iz]), R["null_st"][:, iz])
        je = []
        for s, name in enumerate(T.namen):
            if s == iz or ist_kontrolle(name) or not math.isfinite(R["D_st"][s]):
                continue
            je.append({"name": name, "d": float(R["D_st"][s] - R["D_st"][iz]), "band": _band(R["boot_st"][:, s] - R["boot_st"][:, iz])})
        out[k] = {"D": float(R["D_st"][iz]), "n": int(R["n_in"][iz]), "z": z, "m": m, "band": _band(R["boot_st"][:, iz]), "je": je}
    return out


def strategie_details(T: Teil, R: dict, det: dict) -> list:
    """6.2: je Strategie Zahl der Schichten, Ø netto und Treffer je Drittel (n-gewichtet über die Schichten wie D)."""
    out = []
    for s in range(T.n_strat):
        sch = np.nonzero((T.schicht_strat == s) & (det["n"] >= SCHICHT_MIN))[0]
        w = det["n"][sch].astype(float)
        z = {"name": T.namen[s], "schichten": int(len(sch))}
        for key in ("mu_u", "mu_m", "mu_o", "tr_u", "tr_m", "tr_o"):
            x = det[key][sch]
            ok = np.isfinite(x)
            z[key] = float(np.sum(x[ok] * w[ok]) / np.sum(w[ok])) if ok.any() and np.sum(w[ok]) > 0 else float("nan")
        out.append(z)
    return out


def beschreibend_a(T: Teil, A: dict, n_boot: int) -> dict:
    """6.4–6.6 (D gepoolt, Pool von A1 bzw. A2) und 6.10 (Teilmengen mit festem Pool): nur D mit Band, ohne Nullmodell."""
    out = {}
    pool_rv = A["rv"]["roh"]["pool"]; pool_ts = A["ts"]["roh"]["pool"]
    for k, titel, pool in (("bnc_rv", "Binance-RV (30-min-Volumen der Perps aus swing.db)", pool_rv), ("cb_ts", "Coinbase-Taker-Saldo (Spot)", pool_ts),
                           ("spitze", "Spitze (größter 5-min-Umsatz)", pool_rv)):
        R = auswerten(T, k, pool, n_boot, seed=SEED + 4, mit_null=False, mit_haelften=False)
        out[k] = {"titel": titel, "D": R["D_pool"], "n": R["n_pool"], "band": _band(R["boot_pool"])}
    teil = {}
    art = tagesart(T.t0)
    for k, _ in KENNZAHLEN:
        pool = A[k]["roh"]["pool"]
        zeilen = []
        for titel, maske in ([(f"Coin {c}", T.coin == c) for c in COINS] + [("Werktag", art == 0), ("Wochenende", art == 1),
                                                                             ("Long", T.seite == "long"), ("Short", T.seite == "short")]):
            if not maske.any():
                continue
            R = auswerten(T, k, pool, max(50, n_boot // 2), seed=SEED + 5, extra_maske=maske, mit_null=False, mit_haelften=False)
            zeilen.append({"titel": titel, "D": R["D_pool"], "n": R["n_pool"], "band": _band(R["boot_pool"])})
        teil[k] = zeilen
    out["teilmengen"] = teil
    return out


def welt_a(pfad_a: str, Rr: ReihenA, bis: int, t_a: int, n_boot: int) -> dict | None:
    """6.7: Welt A (labor_a.db, mit dem Tor der Notbremse) -- D_RV und D_TS gepoolt nach denselben Regeln, nur zum Abgleich."""
    L = labor_trades(pfad_a, bis)
    if L.get("fehlt"):
        return {"fehlt": True}
    trades = [t for t in L["trades"] if t["t0"] >= t_a]
    if not trades:
        return {"n_trades": 0}
    T = teil_a_bauen(trades, Rr, tau_h=np.zeros(0, dtype=np.int64))
    fn = pool_a(T.namen, T.gruppen)
    out = {"n_trades": len(trades)}
    for k, _ in KENNZAHLEN:
        R = auswerten(T, k, fn, n_boot, seed=SEED + 6, mit_null=False, mit_haelften=False)
        out[k] = {"D": R["D_pool"], "n": R["n_pool"], "band": _band(R["boot_pool"])}
    return out


def _mini_teil(name, sid, coin, t0, erg, wert_fn) -> Teil:
    """Kleiner Teil für 6.8/6.9: Schicht (Kennung, long, Tagesart), Strategie = Name."""
    tr = [{"name": n, "sid": s, "seite": "long", "t0": int(t)} for n, s, t in zip(name, sid, t0)]
    namen, strat, schicht, schicht_strat, schl = schichten_bauen(tr)
    return Teil(np.asarray(t0, dtype=np.int64), np.asarray(erg, dtype=float), strat, schicht, schicht_strat, namen, ["—"] * len(namen),
                wert_fn, np.zeros(0, dtype=np.int64), coin=np.asarray(coin), schl=schl)


def grid_teil(pfad_fc: str, Rr: ReihenA, bis: int, t_a: int, n_boot: int) -> dict | None:
    """6.8: Tagesergebnis der Grids (hl_labor.grid_tage_tabelle: realisierte Lose + Änderung des Bestands, in % des Coin-Kontos) gegen
    den RV der 24 h vor dem Tag (Fensterende 00:00 UTC), je Drittel; nur volle Tage in der Spanne vor dem Stichtag bzw. dem Lauf."""
    con = _ro(pfad_fc)
    if con is None:
        return None
    rows = []
    try:
        import hl_labor
        for sid, name in con.execute("SELECT sid, name FROM labor_strategie WHERE gruppe='Grid'").fetchall():
            for r in hl_labor.grid_tage_tabelle(con, sid):
                tag = int(r["tag"])
                if r["coin"] in COINS and tag >= t_a and tag + TAG <= bis and r.get("pct") is not None:
                    rows.append((name, sid, r["coin"], tag, float(r["pct"])))
    except (sqlite3.Error, ImportError, KeyError):
        rows = []
    finally:
        con.close()
    if not rows:
        return {"n": 0}
    name, sid, coin, t0, erg = (list(x) for x in zip(*rows))
    coin_a = np.asarray(coin); t0_a = np.asarray(t0, dtype=np.int64); W = np.full(len(t0_a), W_LANG); gr = ReihenA.gruppen(coin_a, W)
    T = _mini_teil(name, sid, coin_a, t0_a, erg, lambda k, tau: Rr.werte("rv", coin_a, W, t0_a, np.ones(len(t0_a)), 0, gr))
    R = auswerten(T, "rv", np.ones(T.n_strat, dtype=bool), n_boot, seed=SEED + 7, mit_null=False, mit_haelften=False)
    det = drittel_details(R["v0"], T.erg, T.schicht, T.t0, T.n_s)
    dd = strategie_details(T, R, det)
    return {"n": int(len(rows)), "je": [{"name": T.namen[s], "D": float(R["D_st"][s]), "n": int(R["n_in"][s]),
                                         "band": _band(R["boot_st"][:, s]), "mu_u": dd[s]["mu_u"], "mu_o": dd[s]["mu_o"]}
                                        for s in range(T.n_strat)]}


def akku_teil(pfad_fc: str, M: dict, Rr: ReihenA, ende: int, t_a: int, n_boot: int) -> dict | None:
    """6.9: Kurs 7 Tage nach jedem Kauf der Akkumulation (labor_akku_kauf) ÷ Kaufpreis − 1 (in %, Schluss der Minute bzw. der letzte
    Schluss der 60 min davor) gegen RV (24 h) bis zur Minute des Kaufs, je Drittel. Nur Käufe in der Spanne, deren 7 Tage vor `ende`
    liegen."""
    con = _ro(pfad_fc)
    if con is None:
        return None
    try:
        rows = con.execute("SELECT k.sid, s.name, k.coin, k.ts, k.preis FROM labor_akku_kauf k JOIN labor_strategie s ON s.sid = k.sid "
                           "ORDER BY k.ts").fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        con.close()
    zeilen, juenger = [], 0
    for sid, name, coin, ts, preis in rows:
        if coin not in M["coins"] or not preis or int(ts) < t_a:
            continue
        t0 = int(ts) // MIN * MIN; t7 = t0 + AKKU_TAGE * TAG
        if t7 >= ende:
            juenger += 1
            continue
        i7 = (t7 - M["t_von"]) // MIN
        cl = M["coins"][coin]["c"]
        px = float("nan")
        for j in range(min(i7, M["N"] - 1), max(-1, i7 - 61), -1):
            if 0 <= j < M["N"] and np.isfinite(cl[j]):
                px = float(cl[j]); break
        if math.isfinite(px):
            zeilen.append((name, sid, coin, t0, (px / float(preis) - 1.0) * 100.0))
    if not zeilen:
        return {"n": 0, "juenger": juenger}
    name, sid, coin, t0, erg = (list(x) for x in zip(*zeilen))
    coin_a = np.asarray(coin); t0_a = np.asarray(t0, dtype=np.int64); W = np.full(len(t0_a), W_LANG); gr = ReihenA.gruppen(coin_a, W)
    T = _mini_teil(name, sid, coin_a, t0_a, erg, lambda k, tau: Rr.werte("rv", coin_a, W, t0_a, np.ones(len(t0_a)), 0, gr))
    R = auswerten(T, "rv", np.ones(T.n_strat, dtype=bool), n_boot, seed=SEED + 8, mit_null=False, mit_haelften=False)
    det = drittel_details(R["v0"], T.erg, T.schicht, T.t0, T.n_s)
    dd = strategie_details(T, R, det)
    return {"n": len(zeilen), "juenger": juenger, "je": [{"name": T.namen[s], "D": float(R["D_st"][s]), "n": int(R["n_in"][s]),
                                                          "band": _band(R["boot_st"][:, s]), "mu_u": dd[s]["mu_u"], "mu_o": dd[s]["mu_o"]}
                                                         for s in range(T.n_strat)]}


def datenlage(M: dict, coins, seiten: dict, t_a: int, t_b: int, erste: int | None) -> dict:
    """6.11: je Coin Bars, Minuten mit Handel und fragliche Minuten in der Spanne, Seitenprüfung; je Tag nicht aufgezeichnete und
    fragliche Minuten (nur Tage mit mindestens einer)."""
    t_von = M["t_von"]; N = M["N"]
    a = int(min(N, max(0, (t_a - t_von) // MIN))); b = int(min(N, max(a, (t_b - t_von) // MIN)))
    out = {"t_von": t_von, "t_a": t_a, "t_b": t_b, "erste": erste, "coins": {}, "tage": []}
    auf = M["aufgezeichnet"]
    out["nicht_aufgezeichnet"] = float(1 - auf[a:b].mean()) if b > a else float("nan")
    tag_idx = (t_von + MIN * np.arange(N, dtype=np.int64)) // TAG
    zaehl = {}
    for c in coins:
        m = M["coins"].get(c)
        if m is None:
            continue
        da = np.nonzero(m["da"])[0]
        mit = (m["da"] | ((m["vb"] + m["vs"]) > 0))[a:b]
        fr = m["fraglich"][a:b]
        out["coins"][c] = {"erste": int(t_von + MIN * da[0]) if len(da) else None, "letzte": int(t_von + MIN * da[-1]) if len(da) else None,
                           "minuten_mit_handel": int(mit.sum()), "fraglich": int(fr.sum()),
                           "anteil_fraglich": float(fr.sum() / max(1, mit.sum())), "seiten": seiten.get(c)}
        if fr.any():
            d, n = np.unique(tag_idx[a:b][fr], return_counts=True)
            for di, ni in zip(d.tolist(), n.tolist()):
                zaehl.setdefault(di, {})[c] = ni
    if b > a:
        d, n = np.unique(tag_idx[a:b][~auf[a:b]], return_counts=True)
        for di, ni in zip(d.tolist(), n.tolist()):
            zaehl.setdefault(di, {})["ohne"] = ni
    out["tage"] = [(d * TAG, zaehl[d]) for d in sorted(zaehl)]
    return out


def stand_heute(Rr: ReihenA, offen: list, A: dict | None, t: int) -> dict:
    """7: RV und TS (aus Sicht eines Longs) der letzten 60 min und 24 h je Coin; je offener Position die Werte beim Einstieg und die
    Drittelgrenzen ihrer Schicht aus diesem Lauf. Nur Lage, keine Empfehlung."""
    out = {"t": t, "coins": {}, "offen": []}
    for c in COINS:
        z = {}
        for W in (W_KURZ, W_LANG):
            for k in ("rv", "ts"):
                z[(k, W)] = float(Rr.werte(k, np.array([c]), np.array([W]), np.array([t]), np.array([1.0]), 0)[0])
        out["coins"][c] = z
    T = A["T"] if A else None
    for o in offen:
        W = W_KURZ if o["h"] <= H_GRENZE else W_LANG
        vz = 1.0 if o["seite"] == "long" else -1.0
        z = dict(o)
        for k in ("rv", "ts"):
            v = float(Rr.werte(k, np.array([o["coin"]]), np.array([W]), np.array([o["t0"]]), np.array([vz]), 0)[0])
            idx = T.schl.get((o["sid"], o["seite"], int(tagesart(np.array([o["t0"]]))[0]))) if T is not None else None
            lo = hi = float("nan"); dr = "Schicht zu klein"
            if idx is not None and A[k]["details"]["n"][idx] >= SCHICHT_MIN:
                lo = float(A[k]["details"]["lo"][idx]); hi = float(A[k]["details"]["hi"][idx])
                dr = "—" if not math.isfinite(v) else ("unten" if v <= lo else "oben" if v >= hi else "mitte")
            z[k] = {"v": v, "lo": lo, "hi": hi, "drittel": dr}
        out["offen"].append(z)
    return out


# ================================================================================================ Studie

def studie_rechnen(db: str, jetzt: int | None = None, log=print, n_boot: int = N_BOOT, n_beschr: int = N_BOOT_BESCHR,
                   mit_b: bool = True) -> dict:
    jetzt = int(jetzt or time.time()); P = pfade(db); t_start = time.time()
    erlaubt = urteil_a_erlaubt(jetzt)
    bis = STICHTAG if erlaubt else jetzt // MIN * MIN
    t_stand = (jetzt - STAND_PUFFER_S) // MIN * MIN
    V = {"jetzt": jetzt, "urteil_a": erlaubt, "bis": bis, "pfade": P, "laufzeit": {}, "A": None, "B": None}
    # ---------------- Teil A
    log("Teil A: Trades des Labors lesen …")
    L = labor_trades(P["forecasts"], bis)
    V["labor"] = {"aus": L["aus"], "aus_je": L["aus_je"], "n": len(L["trades"]), "fehlt": L.get("fehlt", False),
                  "nach_stichtag": L["nach_stichtag"], "vor_spanne": 0, "vor_spanne_je": {}, "t0_ereignis": L.get("t0_ereignis", 0)}
    con = _ro(db)
    if con is None:
        V["A_fehlt"] = "hl_liq.db fehlt"
    elif not L["trades"]:
        con.close()
        V["A_fehlt"] = "keine geschlossenen Trades"
    else:
        try:
            erste = erste_bar(con)
            t_erst = min(t["t0"] for t in L["trades"])
            t_von = max(erste if erste is not None else t_erst - (VERGLEICH_TAGE + 2) * TAG, t_erst - LADE_MAX_TAGE * TAG) // MIN * MIN
            t_lade = max(bis, t_stand)
            log(f"Teil A: Minutenreihen {_dt(t_von)} bis {_dt(t_lade)} lesen …")
            t1 = time.time()
            M = minuten_laden(con, COINS, t_von, t_lade)
            V["laufzeit"]["minuten"] = time.time() - t1
            auf = M["aufgezeichnet"]
            t_auf = t_von + MIN * int(np.argmax(auf)) if auf.any() else t_lade
            t_a = t_auf + VORLAUF_S
            seiten = seiten_pruefen(M, COINS, (t_a - t_von) // MIN, (bis - t_von) // MIN)
            t1 = time.time()
            extra = {"spitze": {}}
            for c in COINS:
                for W, arr in spitze_reihen(M, c).items():
                    extra["spitze"][(c, W)] = arr
            con_sw = _ro(P["swing"])
            try:
                extra["bnc_rv"] = binance_rv_reihen(con_sw, M, COINS)
            finally:
                if con_sw is not None:
                    con_sw.close()
            extra["cb_ts"], V["cb_ab"] = coinbase_ts_reihen(con, M, COINS)
            Rr = ReihenA(M, COINS, {c: s["ok"] for c, s in seiten.items()}, t_a, bis, extra)
            V["laufzeit"]["reihen"] = time.time() - t1
            V["daten_a"] = datenlage(M, COINS, seiten, t_a, bis, erste)
        finally:
            con.close()
        trades = [t for t in L["trades"] if t["t0"] >= t_a]
        for t in L["trades"]:
            if t["t0"] < t_a:
                V["labor"]["vor_spanne_je"][t["name"]] = V["labor"]["vor_spanne_je"].get(t["name"], 0) + 1
        V["labor"]["vor_spanne"] = len(L["trades"]) - len(trades)
        V["t_a"] = t_a
        if not trades:
            V["A_fehlt"] = f"keine Trades in der Spanne (Kennzahlen erst ab {_dt(t_a)})"
            V["stand"] = stand_heute(Rr, L["offen"], None, t_stand)
        else:
            T = teil_a_bauen(trades, Rr)
            fn = pool_a(T.namen, T.gruppen)
            A = {"T": T}
            for k, _txt in KENNZAHLEN:
                log(f"Teil A: {k.upper()} ({len(T.tau)} Verschiebungen, Bootstrap {n_boot}) …")
                t1 = time.time()
                R = auswerten(T, k, fn, n_boot)
                A[k] = {"roh": R, **urteile(R, T, POOL_PRUEF_MIN, POOL_PRUEF_TAGE, erlaubt)}
                A[k]["gruppen"] = gruppen_d(T, R)
                A[k]["details"] = drittel_details(R["v0"], T.erg, T.schicht, T.t0, T.n_s)
                A[k]["strat_details"] = strategie_details(T, R, A[k]["details"])
                V["laufzeit"][f"A_{k}"] = time.time() - t1
            _haupt_urteil([A["rv"]["haupt"], A["ts"]["haupt"]], erlaubt)
            je = [dict(t, kennzahl=k) for k in ("rv", "ts") for t in A[k]["je"] if not ist_kontrolle(t["name"])]
            familie_urteilen(je, erlaubt)
            A["je_familie"] = je
            A["zufall"] = zufall_vergleich(T, A)
            log("Teil A: beschreibende Teile …")
            t1 = time.time()
            A["beschreibend"] = beschreibend_a(T, A, n_beschr)
            A["welt_a"] = welt_a(P["labor_a"], Rr, bis, t_a, n_beschr)
            A["grid"] = grid_teil(P["forecasts"], Rr, bis, t_a, n_beschr)
            A["akku"] = akku_teil(P["forecasts"], M, Rr, min(bis, t_lade, M["t_von"] + M["N"] * MIN), t_a, n_beschr)
            V["laufzeit"]["A_beschr"] = time.time() - t1
            V["stand"] = stand_heute(Rr, L["offen"], A, t_stand)
            V["A"] = A
    # ---------------- Teil B
    if mit_b:
        log("Teil B: Swing-Historie …")
        t1 = time.time()
        H = tagesreihen_b(P["hebel"], COINS, TEIL_B_ENDE)
        voll, fehlt = teil_b_vollstaendig(H, P["swing"], COINS, TEIL_B_ENDE)
        daten, info = swing_daten(P["swing"], COINS, TEIL_B_ENDE)
        S = swing_trades(daten)
        if S["trades"] and H:
            Rb = ReihenB(H)
            T = teil_b_bauen(S["trades"], Rb)
            fn = pool_b(T.namen)
            B = {"voll": voll, "fehlt": fehlt, "info": info, "offen_am_ende": S["offen_am_ende"], "T": T, "n_trades": len(S["trades"]),
                 "pruefsumme": pruefsumme_b(S["trades"], H)}
            for k, _txt in KENNZAHLEN:
                R = auswerten(T, k, fn, n_boot, seed=SEED + 1)
                B[k] = {"roh": R, **urteile(R, T, B_PRUEF_MIN, 0.0, voll)}
                B[k]["details"] = drittel_details(R["v0"], T.erg, T.schicht, T.t0, T.n_s)
                B[k]["strat_details"] = strategie_details(T, R, B[k]["details"])
            _haupt_urteil([B["rv"]["haupt"], B["ts"]["haupt"]], voll)
            je = [dict(t, kennzahl=k) for k in ("rv", "ts") for t in B[k]["je"]]
            familie_urteilen(je, voll)
            B["je_familie"] = je
            # 6.12: je Jahr (fester Pool) und Zufalls-Swing als Markteffekt
            jahre = np.array([datetime.fromtimestamp(int(x), tz=timezone.utc).year for x in T.t0])
            B["jahre"] = {}
            for k, _ in KENNZAHLEN:
                zeilen = []
                for y in sorted(set(jahre.tolist())):
                    R = auswerten(T, k, B[k]["roh"]["pool"], max(50, n_beschr // 2), seed=SEED + 9, extra_maske=jahre == y, mit_null=False,
                                  mit_haelften=False)
                    zeilen.append({"jahr": y, "D": R["D_pool"], "n": R["n_pool"], "band": _band(R["boot_pool"])})
                B["jahre"][k] = zeilen
            Z = swing_trades(daten, namen=("swing_zufall", "swing_ruecksetzer_zufall"), zufall=True)
            if Z["trades"]:
                Tz = teil_b_bauen(Z["trades"], Rb, tau_d=np.zeros(0, dtype=np.int64))
                B["zufall"] = {k: auswerten(Tz, k, np.ones(Tz.n_strat, dtype=bool), n_beschr, seed=SEED + 2, mit_null=False,
                                            mit_haelften=False) for k, _ in KENNZAHLEN}
                B["zufall_n"] = len(Z["trades"])
            V["B"] = B
        else:
            V["B_fehlt"] = {"trades": len(S["trades"]), "hebel": sorted(H), "fehlt": fehlt, "info": info}
        V["laufzeit"]["B"] = time.time() - t1
    V["laufzeit"]["gesamt"] = time.time() - t_start
    return V


# ================================================================================================ Bericht

def _uk(u: str) -> str:
    return {"belegt": "BELEGT", "Hinweis": "Hinweis", "nicht belegt": "nicht belegt", "vorläufig": "vorläufig",
            "nicht prüfbar": "nicht prüfbar"}.get(u, u or "—")


def _haupt_zeile(name: str, h: dict, einheit: str) -> str:
    return (f"   {name:<3} D {_de(h['D'], 3, True)} {einheit} (90 %: {_band_txt(h['band'], 3)}) · Null-Median {_de(h['m'], 3, True)} · "
            f"p {_pz(h['p'])} · p Holm {_pz(h.get('p_holm'))} · Hälften {_de(h['h'][0], 3, True)} / {_de(h['h'][1], 3, True)} "
            f"({'gleich' if h['haelften'] else 'nicht gleich'}) · n {h['n']} über {_de(h.get('spanne'), 0)} Tage -> {_uk(h.get('urteil', ''))}")


def _lesart_band(t: dict) -> str:
    """Nicht belegt: Band eng um 0 (ganz innerhalb ±0,25 -- schließt einen Effekt dieser Größe aus) oder breit (zu wenige Trades)."""
    lo, hi = t["band"]
    if not (math.isfinite(lo) and math.isfinite(hi)) or not (lo <= 0 <= hi):
        return ""
    return "Band eng um 0" if max(abs(lo), abs(hi)) <= BAND_ENG else "Band breit"


def _sortiert(T: Teil) -> list:
    return sorted(enumerate(T.namen), key=lambda x: (SORT_GRUPPE.index(T.gruppen[x[0]]) if T.gruppen[x[0]] in SORT_GRUPPE else 99, x[1]))


def bericht_text(V: dict) -> str:
    z = [f"VOLUMEN-STUDIE (U221) -- Einstiege der Strategien nach Volumen -- {_dt(V['jetzt'])} · Modul {VERSION_MODUL}",
         "Regeln vorab: KONZEPT_Volumen.md (freigegeben 24.10.2026 03:17; Präzisierungen beim Bau in Abschnitt 12). Liest nur; fließt nirgends ein.",
         "D = Ø Ergebnis der Einstiege im oberen Drittel der Kennzahl − im unteren Drittel (je Schicht Kennung × Long/Short × Werktag/Wochenende).",
         ""]
    A = V.get("A")
    z.append("== TEIL A (live): Trades des TradeLabors, Welt B -- Ergebnis netto_pct (Prozentpunkte je Trade)")
    if V["urteil_a"]:
        z.append(f"   URTEIL: Stichtag erreicht -- es zählen die Trades, die vor dem {_dt(STICHTAG)} geschlossen wurden.")
    else:
        z.append(f"   VORLÄUFIG -- kein Urteil vor dem {_dt(STICHTAG, False)} (Trades geschlossen bis {_dt(V['bis'])}). Zwischenstände sind kein Urteil.")
    lb = V.get("labor") or {}
    if lb.get("fehlt"):
        z.append("   forecasts.db fehlt oder hat keine Labor-Tabellen.")
    aus = ", ".join(f"{k} {v}" for k, v in sorted((lb.get("aus") or {}).items())) or "keine"
    z.append(f"   Trades gelesen: {lb.get('n', 0)} · vor der Spanne der Kennzahlen: {lb.get('vor_spanne', 0)} · nach dem Stichtag bzw. dem Lauf "
             f"geschlossen: {lb.get('nach_stichtag', 0)} · heraus: {aus} · Limit-Einstiege mit t0 aus dem Ereignis „limit“ (Order nach 30 Tagen "
             f"gelöscht): {lb.get('t0_ereignis', 0)}")
    D = V.get("daten_a")
    if D:
        z.append(f"   Aufzeichnung ab {_dt(D['erste'])} (erste BTC-Bar); Minuten gelesen ab {_dt(D['t_von'])}; Spanne der Kennzahlen "
                 f"{_dt(D['t_a'])} bis {_dt(D['t_b'])} (28 Tage + 24 h Aufzeichnung davor); nicht aufgezeichnet in der Spanne "
                 f"{_de(D['nicht_aufgezeichnet'] * 100, 2)} % der Minuten")
        for c, d in D["coins"].items():
            s = d.get("seiten") or {}
            z.append(f"   {c:<5} Bars {_dt(d['erste'], False) if d['erste'] else '—'}–{_dt(d['letzte'], False) if d['letzte'] else '—'} · Minuten mit "
                     f"Handel {_tausend(d['minuten_mit_handel'])} · fraglich {_tausend(d['fraglich'])} ({_de(d['anteil_fraglich'] * 100, 2)} %) · "
                     f"Seitenprüfung ρ {_de(s.get('rho'), 2)} (n {_tausend(s.get('n', 0))}; "
                     f"{'ok' if s.get('ok') else ('keine Daten' if not s.get('n') else 'SEITEN FRAGLICH -- TS ohne diesen Coin')})")
    if V.get("A_fehlt"):
        z.append(f"   Nicht rechenbar: {V['A_fehlt']}.")
    if A:
        T = A["T"]
        z.append("")
        pool_n = [n for n, p in zip(T.namen, A["rv"]["roh"]["pool"]) if p]
        z.append(f"   Hauptprüfungen (gepoolt; Pool fest bei τ = 0: {len(pool_n)} Strategien mit ≥ 30 gültigen Trades, ohne Kontrollen, volumengekoppelte "
                 f"Auslöser, „…_gegen“, Grid, Akkumulation; Nullmodell {len(T.tau)} Verschiebungen"
                 + (f" -- von {T.tau_festgelegt} festgelegten fallen {T.tau_festgelegt - len(T.tau)} weg, die bei der kurzen Spanne an derselben Stelle "
                    f"landen" if getattr(T, "tau_festgelegt", len(T.tau)) > len(T.tau) else "") + "; Holm über A1/A2):")
        z.append(_haupt_zeile("A1", A["rv"]["haupt"], "Pkt."))
        z.append(_haupt_zeile("A2", A["ts"]["haupt"], "Pkt."))
        for k in ("rv", "ts"):
            h = A[k]["haupt"]
            z.append(f"       {k.upper()}: Pool-Trades mit Kennzahl in den Verschiebungen min. {_de(h['null_n'][0], 0)}, Median {_de(h['null_n'][1], 0)} "
                     f"von {h['n']} (fehlt die verschobene Kennzahl, fehlt der Trade nur dort)")
        z.append("   Pool: " + (", ".join(pool_n) or "—"))
        z.append("")
        z.append("   Je Strategie -- Prüfung (n = gültige Trades in Schichten ≥ 9; p aus der Normalnäherung der Null; Holm/BH über alle prüfbaren "
                 "Strategie × Kennzahl; Wölbung der Null in Klammern):")
        z.append(f"   {'Strategie':<26}{'Gruppe':<17}{'Kz':<4}{'n':>6}{'D':>9}{'Band 90 %':>21}{'z':>7}{'p':>9}{'p Holm':>9}{'q':>7}  {'Hälften':<8}Urteil")
        sp = {(t["name"], t["kennzahl"]): t for t in A["je_familie"]}
        for s, name in _sortiert(T):
            for k in ("rv", "ts"):
                t = sp.get((name, k))
                if t is None:                                    # Kontrolle: nur beschreibend
                    r = A[k]["je"][s]
                    z.append(f"   {name[:25]:<26}{(T.gruppen[s] or '')[:16]:<17}{k.upper():<4}{r['n']:>6}{_de(r['D'], 3, True):>9}"
                             f"{_band_txt(r['band']):>21}{_de(r['z'], 2, True):>7}{_pz(r['p']):>9}{'':>9}{'':>7}  {'':<8}Kontrolle (6.3)")
                    continue
                zus = f" ({_de(t['kurt'], 1)})" if math.isfinite(t.get("kurt", float("nan"))) else ""
                lesart = _lesart_band(t) if t["urteil"] == "nicht belegt" else ""
                z.append(f"   {name[:25]:<26}{(t['gruppe'] or '')[:16]:<17}{k.upper():<4}{t['n']:>6}{_de(t['D'], 3, True):>9}"
                         f"{_band_txt(t['band']):>21}{_de(t['z'], 2, True):>7}{_pz(t['p']):>9}{_pz(t.get('p_holm')):>9}{_de(t.get('q'), 3):>7}  "
                         f"{'gleich' if t['haelften'] else '—':<8}{_uk(t['urteil'])}{zus}{(' · ' + lesart) if lesart else ''}")
        z.append("")
        z.append("   6.2 Je Strategie -- Drittel (Ø netto unten / mitte / oben in Pkt., Treffer unten / oben in %, Schichten) und 6.3 D − D(Zufall):")
        zf = A.get("zufall") or {}
        zfd = {k: {e["name"]: e for e in (zf.get(k) or {}).get("je", [])} for k in ("rv", "ts")}
        for s, name in _sortiert(T):
            teile = []
            for k in ("rv", "ts"):
                d = A[k]["strat_details"][s]
                e = zfd[k].get(name)
                dz = f" · D−Z {_de(e['d'], 3, True)} ({_band_txt(e['band'])})" if e else ""
                tru = d["tr_u"] * 100 if math.isfinite(d["tr_u"]) else None
                tro = d["tr_o"] * 100 if math.isfinite(d["tr_o"]) else None
                teile.append(f"{k.upper()} {_de(d['mu_u'], 2, True)} / {_de(d['mu_m'], 2, True)} / {_de(d['mu_o'], 2, True)}, Treffer "
                             f"{_de(tru, 0)} / {_de(tro, 0)} %, {d['schichten']} Sch.{dz}")
            z.append(f"   {name[:25]:<26}" + " | ".join(teile))
        z.append("")
        z.append("   Ausfälle je Strategie (ohne Kennzahl = Wert bei τ = 0 nicht bestimmt; zu kleine Schicht = Schicht unter 9 gültigen Trades):")
        rv, ts = A["rv"]["roh"], A["ts"]["roh"]
        for s, name in _sortiert(T):
            n_ges = int(np.sum(T.strat == s))
            teile = [f"Trades {n_ges}", f"ohne Kennzahl RV {n_ges - int(rv['n_gueltig'][s])} / TS {n_ges - int(ts['n_gueltig'][s])}",
                     f"zu kleine Schicht RV {int(rv['n_gueltig'][s] - rv['n_in'][s])} / TS {int(ts['n_gueltig'][s] - ts['n_in'][s])}"]
            vs = lb.get("vor_spanne_je", {}).get(name)
            if vs:
                teile.append(f"vor der Spanne {vs}")
            for g, n in sorted((lb.get("aus_je") or {}).get(name, {}).items()):
                teile.append(f"{g} {n}")
            z.append(f"   {name[:25]:<26}" + " · ".join(teile))
        for name, d in sorted((lb.get("aus_je") or {}).items()):
            if name not in T.namen:
                teile = [f"{g} {n}" for g, n in sorted(d.items())]
                vs = lb.get("vor_spanne_je", {}).get(name)
                if vs:
                    teile.append(f"vor der Spanne {vs}")
                z.append(f"   {name[:25]:<26}" + " · ".join(teile))
        for name, vs in sorted((lb.get("vor_spanne_je") or {}).items()):
            if name not in T.namen and name not in (lb.get("aus_je") or {}):
                z.append(f"   {name[:25]:<26}vor der Spanne {vs}")
        z.append("")
        z.append("== Beschreibend (kein Urteil)")
        for k, txt in KENNZAHLEN:
            z.append(f"   6.1 Gruppen, {txt} (ohne Kontrollen und „…_gegen“): " + " · ".join(
                f"{g['gruppe']} {_de(g['D'], 3, True)} (90 %: {_band_txt(g['band'])}; z {_de(g['z'], 1, True)}; n {g['n']})" for g in A[k]["gruppen"]))
        if zf:
            z.append("   6.3 Kontrolle „Zufall“ (Markteffekt): " + " · ".join(
                f"{k.upper()} D {_de(v['D'], 3, True)} (90 %: {_band_txt(v['band'])}; z {_de(v['z'], 1, True)}; n {v['n']})" for k, v in zf.items()))
        else:
            z.append("   6.3 Kontrolle „Zufall“: keine Trades.")
        Bs = A["beschreibend"]
        for k, nr in (("bnc_rv", "6.4"), ("cb_ts", "6.5"), ("spitze", "6.6")):
            b = Bs.get(k)
            zus = ""
            if k == "cb_ts":
                zus = f"; Seiten korrigiert vor {_dt(V.get('cb_ab'))}" if V.get("cb_ab") else "; ohne Umstellungszeitpunkt (cb_seite_ab) -- unkorrigiert"
            z.append(f"   {nr} {b['titel']}: D gepoolt {_de(b['D'], 3, True)} (90 %: {_band_txt(b['band'])}; n {b['n']}{zus})")
        wa = A.get("welt_a")
        if not wa or wa.get("fehlt"):
            z.append("   6.7 Welt A: labor_a.db fehlt.")
        elif not wa.get("n_trades"):
            z.append("   6.7 Welt A: keine Trades in der Spanne.")
        else:
            z.append(f"   6.7 Welt A (mit Tor der Notbremse, {wa['n_trades']} Trades): " + " · ".join(
                f"{k.upper()} D {_de(wa[k]['D'], 3, True)} (90 %: {_band_txt(wa[k]['band'])}; n {wa[k]['n']})" for k in ("rv", "ts")))
        g = A.get("grid")
        if not g or not g.get("n"):
            z.append("   6.8 Grid: keine vollen Tage mit Ergebnis in der Spanne.")
        else:
            z.append(f"   6.8 Grid (Tagesergebnis in % des Coin-Kontos gegen RV der 24 h davor; {g['n']} Coin-Tage): " + " · ".join(
                f"{e['name']} D {_de(e['D'], 3, True)} (90 %: {_band_txt(e['band'])}; unten {_de(e['mu_u'], 3, True)} / oben {_de(e['mu_o'], 3, True)}; "
                f"n {e['n']})" for e in g["je"]))
        ak = A.get("akku")
        if not ak or not ak.get("n"):
            zus = f" ({ak.get('juenger', 0)} jünger als 7 Tage)" if ak else ""
            z.append(f"   6.9 Akkumulation: keine Käufe mit 7 Tagen danach in der Spanne{zus}.")
        else:
            z.append(f"   6.9 Akkumulation (Kurs 7 Tage nach dem Kauf in % gegen RV 24 h; {ak['n']} Käufe, {ak['juenger']} jünger als 7 Tage): "
                     + " · ".join(f"{e['name']} D {_de(e['D'], 2, True)} (90 %: {_band_txt(e['band'])}; unten {_de(e['mu_u'], 2, True)} / oben "
                                  f"{_de(e['mu_o'], 2, True)}; n {e['n']})" for e in ak["je"]))
        for k, txt in KENNZAHLEN:
            z.append(f"   6.10 {txt}, D gepoolt getrennt: " + " · ".join(
                f"{r['titel']} {_de(r['D'], 3, True)} ({_band_txt(r['band'])}; n {r['n']})" for r in Bs["teilmengen"][k]))
        if D and D["tage"]:
            z.append("   6.11 Je Tag (nur Tage mit nicht aufgezeichneten oder fraglichen Minuten): " + " · ".join(
                f"{_tm(t)} " + " ".join(f"{('ohne Aufz.' if c == 'ohne' else c)} {n}" for c, n in sorted(d.items())) for t, d in D["tage"]))
        elif D:
            z.append("   6.11 Je Tag: keine nicht aufgezeichneten oder fraglichen Minuten in der Spanne.")
    st = V.get("stand")
    if st:
        z.append("")
        z.append(f"== 7. Stand heute (Fenster bis {_dt(st['t'])}; TS aus Sicht eines Longs; nur Lage, keine Empfehlung)")
        for c, w in st["coins"].items():
            z.append(f"   {c:<5} RV 60 min {_de(w[('rv', W_KURZ)], 2)} · 24 h {_de(w[('rv', W_LANG)], 2)} · TS 60 min {_de(w[('ts', W_KURZ)], 3, True)} · "
                     f"24 h {_de(w[('ts', W_LANG)], 3, True)}")
        for o in st["offen"][:40]:
            z.append(f"   offen: {o['name']} {o['coin']} {o['seite']} seit {_dt(o['t0'])} -- " + " · ".join(
                f"{k.upper()} beim Einstieg {_de(o[k]['v'], 3, k == 'ts')} (Drittelgrenzen {_de(o[k]['lo'], 3, k == 'ts')} / {_de(o[k]['hi'], 3, k == 'ts')}: "
                f"{o[k]['drittel']})" for k in ("rv", "ts")))
        if len(st["offen"]) > 40:
            z.append(f"   … und {len(st['offen']) - 40} weitere offene Positionen")
    # ---------------- Teil B
    z.append("")
    z.append("== TEIL B (Historie): vier Swing-Strategien, Binance-Tagesumsatz des USDⓈ-M-Perps (Daten bis 23.10.2026) -- Ergebnis R je Trade")
    B = V.get("B")
    if not B:
        bf = V.get("B_fehlt") or {}
        z.append(f"   nicht rechenbar: Swing-Trades {bf.get('trades', 0)}, Coins mit Tagesumsatz {bf.get('hebel')}; " + "; ".join(bf.get("fehlt") or [])
                 + ("; " + "; ".join(f"{c} {i}" for c, i in (bf.get("info") or {}).items()) if bf.get("info") else ""))
    else:
        z.append("   Daten: " + "; ".join(f"{c} {i}" for c, i in B["info"].items()) + f" · Trades {B['n_trades']}, „offen am Ende“ ausgelassen: "
                 f"{B['offen_am_ende']}")
        z.append(f"   Prüfsumme der Eingangsdaten {B['pruefsumme']} (Trades und Tagesreihen bis 23.10.) -- das Urteil gilt aus dem ersten Lauf mit "
                 f"vollständiger Historie; eine andere Prüfsumme in einem späteren Bericht heißt: die Daten haben sich geändert.")
        if not B["voll"]:
            z.append("   VORLÄUFIG -- Historie nicht vollständig: " + "; ".join(B["fehlt"]))
        else:
            z.append("   Historie vollständig -- Urteil.")
        z.append(_haupt_zeile("B1", B["rv"]["haupt"], "R"))
        z.append(_haupt_zeile("B2", B["ts"]["haupt"], "R"))
        for t in sorted(B["je_familie"], key=lambda x: (x["name"], x["kennzahl"])):
            d = B[t["kennzahl"]]["strat_details"][t["idx"]]
            lesart = _lesart_band(t) if t["urteil"] == "nicht belegt" else ""
            z.append(f"   {t['name']:<22}{t['kennzahl'].upper():<4} n {t['n']:>4} · D {_de(t['D'], 3, True)} R (90 %: {_band_txt(t['band'])}) · z "
                     f"{_de(t['z'], 2, True)} · p {_pz(t['p'])} · p Holm {_pz(t.get('p_holm'))} · q {_de(t.get('q'), 3)} · Hälften "
                     f"{'gleich' if t['haelften'] else '—'} · "
                     f"Ø R unten/mitte/oben {_de(d['mu_u'], 2, True)} / {_de(d['mu_m'], 2, True)} / {_de(d['mu_o'], 2, True)} -> {_uk(t['urteil'])}"
                     f"{(' · ' + lesart) if lesart else ''}")
        for k, txt in KENNZAHLEN:
            z.append(f"   6.12 je Jahr, {txt}: " + " · ".join(f"{r['jahr']} {_de(r['D'], 2, True)} ({_band_txt(r['band'])}; n {r['n']})"
                                                      for r in B["jahre"][k]))
        if B.get("zufall"):
            z.append(f"   6.12 Zufalls-Swing (Markteffekt, {B['zufall_n']} Trades): " + " · ".join(
                f"{k.upper()} D {_de(r['D_pool'], 3, True)} R (90 %: {_band_txt(_band(r['boot_pool']))}; n {r['n_pool']})"
                for k, r in B["zufall"].items()))
    # ---------------- Anhang: Drittelgrenzen
    if A:
        T = A["T"]
        z.append("")
        z.append("== Anhang: Drittelgrenzen je Schicht, Teil A (RV als Faktor, TS als Abweichung vom üblichen Saldo; L/S = Long/Short, "
                 "WT/WE = Werktag/Wochenende; nur Schichten ≥ 9)")
        inv = {i: k for k, i in T.schl.items()}
        je_name: dict = {}
        for i in range(T.n_s):
            sid, seite, art = inv[i]
            teile = []
            for k in ("rv", "ts"):
                d = A[k]["details"]
                if d["n"][i] >= SCHICHT_MIN:
                    teile.append(f"{k.upper()} {_de(d['lo'][i], 3, k == 'ts')}…{_de(d['hi'][i], 3, k == 'ts')} (n {int(d['n'][i])})")
            if teile:
                je_name.setdefault(T.namen[T.schicht_strat[i]], []).append(f"{sid} {'L' if seite == 'long' else 'S'}/{'WE' if art else 'WT'}: "
                                                                            + ", ".join(teile))
        for name in sorted(je_name):
            z.append(f"   {name}: " + " | ".join(je_name[name]))
    z.append("")
    z.append("== Lesart")
    z.append("   Belegt heißt: Einstiege im oberen Drittel der Kennzahl liefen in diesem Zeitraum verlässlich anders als im unteren -- nach")
    z.append("   Nullmodell, Familienfehler und beiden Hälften. „Nicht belegt“ mit breitem Band heißt meist: zu wenige Trades; ein Band eng um 0")
    z.append("   (ganz innerhalb ±0,25) schließt einen Effekt dieser Größe aus. Zeigt auch „Zufall“ den Effekt, ist es ein Markteffekt. Belegt nur in")
    z.append("   Teil B: erst nach Bestätigung im Labor. Filter (Stufe 2) nur nach eigenem, vorab festgelegtem Plan-Punkt (KONZEPT_Volumen.md 8),")
    z.append("   nicht vor dem 25.10. und nicht vor dem Urteil am 08.11.")
    lz = V.get("laufzeit") or {}
    z.append(f"   Laufzeit {_de(lz.get('gesamt'), 1)} s (Minuten lesen {_de(lz.get('minuten'), 1)} s, Reihen {_de(lz.get('reihen'), 1)} s, A RV "
             f"{_de(lz.get('A_rv'), 1)} s, A TS {_de(lz.get('A_ts'), 1)} s, A beschreibend {_de(lz.get('A_beschr'), 1)} s, B {_de(lz.get('B'), 1)} s)")
    z.append("")
    z.append("ENDE -- bitte vollständig einfügen")
    return "\n".join(z)


def studie(db: str) -> str:
    V = studie_rechnen(db, log=lambda s: print(s, flush=True))
    return bericht_text(V)


# ================================================================================================ Selbsttest: erfundene Daten

def _probe_minuten(N_tage: int, coins=("BTC", "ETH"), seed: int = 1, t_von: int | None = None, tagesfaktor: float = 0.3) -> dict:
    """Erfundenes Minutenraster: Umsatz mit Tagesgang, Wochenende (halb so viel) und Zufallsfaktor je Tag (lognormal), Taker-Seiten
    mit Rauschen, Rendite der Minute folgt dem Saldo."""
    rng = np.random.default_rng(seed)
    t_von = t_von if t_von is not None else int(datetime(2026, 8, 3, tzinfo=timezone.utc).timestamp())    # Montag
    N = N_tage * 1440
    t = t_von + MIN * np.arange(N, dtype=np.int64)
    M = {"t_von": t_von, "N": N, "coins": {}}
    for c in coins:
        tagesgang = 1.0 + 0.5 * np.sin(2 * np.pi * ((t % TAG) / TAG))
        we = np.where(tagesart(t) == 1, 0.5, 1.0)
        tf = np.exp(tagesfaktor * rng.standard_normal(N_tage + 2))[(t - t_von) // TAG]
        vol = rng.gamma(2.0, 1.0, N) * tagesgang * we * tf
        anteil = np.clip(0.5 + 0.1 * rng.standard_normal(N), 0, 1)
        vb = vol * anteil; vs = vol - vb
        ret = 0.001 * (vb - vs) / np.maximum(vol, 1e-9) + 0.0005 * rng.standard_normal(N)
        M["coins"][c] = {"nz": vol * 100.0, "vol": vol, "c": 100.0 * np.exp(np.cumsum(ret)), "ret": ret, "da": np.ones(N, dtype=bool),
                         "vb": vb, "vs": vs, "nt": np.full(N, 3.0), "fraglich": np.zeros(N, dtype=bool)}
    M["aufgezeichnet"] = np.ones(N, dtype=bool)
    return M


def _probe_trades(M: dict, Rr: ReihenA, n: int, seed: int, effekt_rv: float = 0.0, effekt_ts: float = 0.0, namen=("a_folgen", "b"),
                  h: float = 4.0, effekt_we: float = 0.0, effekt_long: float = 0.0, effekt_mo: float = 0.0, nacht: bool = False,
                  nur: str | None = None, gruppe: str = "Händler") -> list:
    """Erfundene Trades nach Tag 31: Ergebnis = Rauschen + Effekte (über die echten Kennzahlen bestimmt). nacht = Einstiege nur
    00:00–06:00 UTC (wie die Swing-Strategien nach dem Tagesschluss)."""
    rng = np.random.default_rng(seed)
    if nacht:
        tage = rng.integers(31, M["N"] // 1440 - 1, n)
        t0s = M["t_von"] + tage * TAG + rng.integers(0, 360, n) * MIN
    else:
        t0s = M["t_von"] + (31 * 1440 + rng.integers(0, M["N"] - 31 * 1440 - 1, n)) * MIN
    t0s = np.sort(t0s)
    coin = np.where(np.arange(n) % 3 == 0, "ETH", "BTC")
    seite = np.where(rng.random(n) < 0.5, "long", "short")
    vz = np.where(seite == "long", 1.0, -1.0)
    W = np.full(n, W_KURZ if h <= H_GRENZE else W_LANG)
    rv = Rr.werte("rv", coin, W, t0s, vz, 0); ts = Rr.werte("ts", coin, W, t0s, vz, 0)
    e = 0.8 * rng.standard_normal(n)
    name = np.array([namen[i % len(namen)] for i in range(n)])
    trifft = np.ones(n, dtype=bool) if nur is None else (name == nur)
    e += np.where(trifft & np.isfinite(rv), effekt_rv * np.where(rv > 1.0, 1.0, -1.0), 0.0)
    e += np.where(trifft & np.isfinite(ts), effekt_ts * np.where(ts > 0, 1.0, -1.0), 0.0)
    e += effekt_we * (tagesart(t0s) == 1) + effekt_long * (seite == "long") + effekt_mo * (wochentag(t0s) == 0)
    return [{"id": i, "sid": str(name[i]), "name": str(name[i]), "gruppe": gruppe, "h": h, "coin": str(coin[i]), "seite": str(seite[i]),
             "t0": int(t0s[i]), "netto": float(e[i])} for i in range(n)]


def _urteil_probe(tr: list, Rr: ReihenA, k: str, tau=TAU_A[::8], n_boot: int = 100, seed: int = SEED) -> tuple:
    T = teil_a_bauen(tr, Rr, tau_h=tau)
    R = auswerten(T, k, pool_a(T.namen, T.gruppen), n_boot=n_boot, seed=seed)
    U = urteile(R, T, POOL_PRUEF_MIN, POOL_PRUEF_TAGE, True)
    _haupt_urteil([U["haupt"]], True)
    return U, T, R


def _probe_db_minuten(con, M: dict, cb_ab: int | None = None) -> None:
    """Schreibt ein erfundenes Minutenraster in bars, bars10 (ein 10-s-Stück je Minute), sw_klines (30 min, wie swing.db) und cb_bars (vor
    cb_ab mit vertauschten Seiten wie vor U41)."""
    con.executescript("""
        CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER,
            PRIMARY KEY (ts, coin)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS bars10 (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, vol_buy REAL, vol_sell REAL,
            trades INTEGER, n_liq INTEGER, liq_notional REAL, max_sz REAL, PRIMARY KEY (ts, coin)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS sw_klines (coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;
        CREATE TABLE IF NOT EXISTS cb_bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER,
            buy_usd REAL, sell_usd REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE IF NOT EXISTS cb_meta (k TEXT PRIMARY KEY, v TEXT);""")
    t = M["t_von"] + MIN * np.arange(M["N"], dtype=np.int64)
    for c, m in M["coins"].items():
        cl = m["c"]; op = np.concatenate([[cl[0]], cl[:-1]])
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)",
                        zip(t.tolist(), [c] * len(t), op.tolist(), np.maximum(op, cl).tolist(), np.minimum(op, cl).tolist(), cl.tolist(),
                            m["vol"].tolist(), [3] * len(t)))
        con.executemany("INSERT INTO bars10 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        zip(t.tolist(), [c] * len(t), op.tolist(), op.tolist(), op.tolist(), op.tolist(), m["vb"].tolist(), m["vs"].tolist(),
                            [3] * len(t), [0] * len(t), [0.0] * len(t), [1.0] * len(t)))
        n30 = len(t) // 30
        v30 = m["vol"][:n30 * 30].reshape(n30, 30).sum(axis=1)
        con.executemany("INSERT INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                        zip([c] * n30, t[:n30 * 30:30].tolist(), [1.0] * n30, [1.0] * n30, [1.0] * n30, [1.0] * n30, v30.tolist()))
        kauf = m["vb"] * cl; verk = m["vs"] * cl
        if cb_ab is not None:
            vor = t < cb_ab
            kauf, verk = np.where(vor, verk, kauf), np.where(vor, kauf, verk)
        con.executemany("INSERT INTO cb_bars VALUES (?,?,?,?,?,?,?,?,?,?)",
                        zip(t.tolist(), [c] * len(t), op.tolist(), op.tolist(), op.tolist(), cl.tolist(), m["vol"].tolist(), [30] * len(t),
                            kauf.tolist(), verk.tolist()))
    if cb_ab is not None:
        con.execute("INSERT OR REPLACE INTO cb_meta VALUES ('seite_umstellung', ?)", (json.dumps({"status": "gefunden", "ts": int(cb_ab)}),))
    con.commit()


def _probe_umgebung(tmp: str, seed: int = 7) -> dict:
    """Erfundene Datenbanken für den Lauf von Ende zu Ende: hl_liq.db ab 01.09.2026 (BTC, ETH), forecasts.db und labor_a.db mit dem
    Schema des Labors (Trades, Limit-Orders, Grid, Akkumulation, offene Positionen), hebel.db (Tagesumsatz, fünf Coins) und swing.db
    (30-min-Kerzen und Funding, fünf Coins) bis 23.10.2026."""
    import shutil
    import hl_labor
    rng = np.random.default_rng(seed)
    t_von = int(datetime(2026, 9, 1, tzinfo=timezone.utc).timestamp())
    n_tage = (STICHTAG + TAG - t_von) // TAG
    M = _probe_minuten(n_tage, coins=("BTC", "ETH"), seed=seed, t_von=t_von)
    db = os.path.join(tmp, "hl_liq.db")
    con = sqlite3.connect(db)
    _probe_db_minuten(con, M, cb_ab=t_von + 5 * TAG)
    con.close()
    t_a = t_von + VORLAUF_S
    fc = os.path.join(tmp, "forecasts.db")
    con = sqlite3.connect(fc)
    con.executescript(hl_labor.SCHEMA)
    strat = [("w@1", "wale_folgen", "Händler", 4), ("w@2", "wale_gegen", "Händler", 4), ("t@1", "familie_trend", "Familien", 24),
             ("o@1", "familie_orderfluss", "Familien", 1), ("z@1", "zufall", "Kontrolle", 4), ("e@1", "empfehlung_limit", "Prognose", 12),
             ("g@1", "grid_long", "Grid", 24), ("a@1", "akku", "Akkumulation", 24)]
    con.executemany("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,?)",
                    [(sid, name, name, gr, json.dumps({"h": h, "v": 1}), "", t_von, 1) for sid, name, gr, h in strat])
    pos = []
    t_ende = STICHTAG + 9 * 3600
    for i in range(2100):
        sid, name, gr, h = strat[i % 6]
        t0 = int(t_a - 3 * TAG + rng.integers(0, t_ende - 6 * 3600 - t_a + 3 * TAG))
        coin = ("BTC", "ETH", "XMR")[(i // 6) % 3] if i % 7 else "PAXG"
        zu = t0 + int(h * 3600 * rng.uniform(0.2, 1.0))
        art = "Limit (Maker)" if name == "empfehlung_limit" else "Markt (Taker)"
        grund = "Regelversion abgelöst" if i % 97 == 0 else "Ziel"
        pos.append((sid, coin, "long" if rng.random() < 0.5 else "short", "geschlossen", t0 + 300 if art.startswith("Limit") else t0, art, zu, grund,
                    float(rng.normal(0, 1)), 10.0))
    con.executemany("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, art_ein, geschlossen, grund_aus, netto_pct, netto_usd) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)", pos)
    orders = [(sid, "BTC", er - 300, "gefuellt", pid) for pid, sid, art, er in con.execute("SELECT id, sid, art_ein, eroeffnet FROM labor_position")
              if str(art).startswith("Limit") and pid % 5]
    con.executemany("INSERT INTO labor_order (sid, coin, erstellt, status, pos_id) VALUES (?,?,?,?,?)", orders)
    con.executemany("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, art_ein) VALUES (?,?,?,?,?,?)",
                    [("w@1", "BTC", "long", "offen", t_ende - 3600, "Markt (Taker)"), ("t@1", "ETH", "short", "offen", t_ende - 7200, "Markt (Taker)")])
    for d in range((t_ende - t_a) // TAG):
        tag = (t_a // TAG + d) * TAG
        con.execute("INSERT INTO labor_grid_tag (sid, coin, tag, unreal, lose, px, ts) VALUES (?,?,?,?,?,?,?)",
                    ("g@1", "BTC", tag, float(rng.normal(0, 50)), 3, 100.0, tag + 3600))
        con.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, art_ein, geschlossen, grund_aus, netto_pct, netto_usd) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)", ("g@1", "BTC", "long", "geschlossen", tag + 100, "Limit (Maker)", tag + 7200, "Ziel", 0.1,
                                                     float(rng.normal(10, 5))))
    i_c = M["coins"]["BTC"]["c"]
    for ts in [t_a + d * TAG + 4000 for d in range(0, 30, 2)] + [STICHTAG - 7 * TAG + 3 * 3600]:     # der letzte: 7 Tage enden nach dem Stichtag
        con.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, ausloeser, preis) VALUES (?,?,?,?,?)",
                    ("a@1", "BTC", ts, "A1", float(i_c[(ts - t_von) // MIN])))
    con.commit(); con.close()
    shutil.copyfile(fc, os.path.join(tmp, "labor_a.db"))
    d0 = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp()) // TAG
    nd = TEIL_B_ENDE // TAG - d0
    hb = sqlite3.connect(os.path.join(tmp, "hebel.db"))
    hb.execute("CREATE TABLE hb_kerzen (markt TEXT, symbol TEXT, tag INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, v_usd REAL, taker_usd REAL, "
               "n INTEGER, PRIMARY KEY (markt, symbol, tag)) WITHOUT ROWID")
    sw = sqlite3.connect(os.path.join(tmp, "swing.db"))
    sw.executescript("CREATE TABLE sw_klines (coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;"
                     "CREATE TABLE sw_funding (coin TEXT, ts INTEGER, rate REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;")
    nd_sw = nd + 30                                                       # Kerzen über den Datenschluss hinaus (darf nicht zählen)
    for j, c in enumerate(COINS):
        r = np.random.default_rng(seed + 10 + j)
        nb = nd_sw * 48
        ts = d0 * TAG + 1800 * np.arange(nb, dtype=np.int64)
        trend = np.repeat(0.002 * np.sin(np.arange(nd_sw) / 40.0 + j), 48)
        cl = 100 * np.exp(np.cumsum(trend / 48 + 0.006 * r.standard_normal(nb)))
        op = np.concatenate([[100.0], cl[:-1]])
        sw.executemany("INSERT INTO sw_klines VALUES (?,?,?,?,?,?,?)", zip([c] * nb, ts.tolist(), op.tolist(), (np.maximum(op, cl) * 1.002).tolist(),
                                                                        (np.minimum(op, cl) * 0.998).tolist(), cl.tolist(), [1.0] * nb))
        sw.executemany("INSERT INTO sw_funding VALUES (?,?,?)", zip([c] * (nd_sw * 3), (d0 * TAG + 28800 * np.arange(nd_sw * 3)).tolist(),
                                                                   (0.0001 * r.standard_normal(nd_sw * 3)).tolist()))
        v = 1e8 * np.exp(0.3 * r.standard_normal(nd)) * np.where(tagesart((d0 + np.arange(nd)) * TAG) == 1, 0.6, 1.0)
        tk = v * np.clip(0.5 + 0.03 * r.standard_normal(nd), 0, 1)
        hb.executemany("INSERT INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                       zip(["um"] * nd, [f"{c}USDT"] * nd, (d0 + np.arange(nd)).tolist(), [1.0] * nd, [1.0] * nd, [1.0] * nd, [1.0] * nd,
                           [1.0] * nd, v.tolist(), tk.tolist(), [1000] * nd))
    hb.commit(); hb.close(); sw.commit(); sw.close()
    return {"db": db, "t_von": t_von, "t_a": t_a, "M": M}


# ================================================================================================ Selbsttest

def selbsttest() -> bool:
    import shutil
    import tempfile
    import warnings
    pruef = []

    def ok(name, bed, text=""):
        pruef.append(bool(bed))
        print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    t_start = time.time()
    print("hl_volumen -- Selbsttest (erfundene Daten, ohne Netz)", flush=True)
    # ---- V1 Zeit: Tagesart, Fenstermitte
    sa = int(datetime(2026, 10, 24, tzinfo=timezone.utc).timestamp()); fr = sa - 1
    ok("V1 Tagesart: Samstag 00:00 UTC Wochenende, Freitag 23:59:59 Werktag, Montag Werktag; ein 24-h-Fenster bis Samstag 00:30 zählt "
       "als Werktag (Mitte Freitag 12:30), ein 60-min-Fenster bis Samstag 00:30 als Wochenende",
       tagesart(np.array([sa]))[0] == 1 and tagesart(np.array([fr]))[0] == 0 and tagesart(np.array([sa + 2 * TAG]))[0] == 0
       and art_fenster(np.array([sa + 1800]), W_LANG)[0] == 0 and art_fenster(np.array([sa + 1800]), W_KURZ)[0] == 1,
       f"Wochentag {wochentag(np.array([sa]))[0]}")
    # ---- V2 Rechnung von Hand: RV und TS (60 min)
    M = _probe_minuten(40, coins=("BTC",), seed=3)
    c = M["coins"]["BTC"]
    K = kennzahl_reihen(M, "BTC", W_KURZ)
    i = 35 * 1440 + 600
    t_e = M["t_von"] + i * MIN

    def gleich_art(t_end, k, W):
        return art_fenster(np.array([t_end - k * TAG]), W)[0] == art_fenster(np.array([t_end]), W)[0]

    def saldo(a, b):
        return (c["vb"][a:b].sum() - c["vs"][a:b].sum()) / (c["vb"][a:b].sum() + c["vs"][a:b].sum())
    U = c["nz"][i - 60:i].sum()
    verg = [c["nz"][i - k * 1440 - 60:i - k * 1440].sum() for k in range(1, 29) if gleich_art(t_e, k, W_KURZ)]
    vergI = [saldo(i - k * 1440 - 60, i - k * 1440) for k in range(1, 29) if gleich_art(t_e, k, W_KURZ)]
    rv_hand = U / np.median(verg); ts_hand = saldo(i - 60, i) - np.median(vergI)
    ok("V2 RV und TS von Hand (60 min, Vergleich nur gleiche Tagesart der 28 Tage davor: 20 Werktage bzw. 8 Wochenendtage)",
       abs(K["rv"][i] - rv_hand) < 1e-9 and abs(K["irel"][i] - ts_hand) < 1e-12 and len(verg) in (8, 20),
       f"RV {K['rv'][i]:.4f} (von Hand {rv_hand:.4f}), TS {K['irel'][i]:+.4f} ({ts_hand:+.4f}), Vergleiche {len(verg)}")
    # ---- V3 24 h: Fenstermitte, von Hand; ohne Vorlauf nicht bestimmt
    K24 = kennzahl_reihen(M, "BTC", W_LANG)
    sa_i = next(j for j in range(30 * 1440, 39 * 1440)
                if wochentag(np.array([M["t_von"] + j * MIN]))[0] == 5 and (M["t_von"] + j * MIN) % TAG == 1800)     # Samstag 00:30
    t_s = M["t_von"] + sa_i * MIN
    verg24 = [c["nz"][sa_i - k * 1440 - 1440:sa_i - k * 1440].sum() for k in range(1, 29) if gleich_art(t_s, k, W_LANG)]
    ok("V3 RV mit Fenster 24 h von Hand: Fenster bis Samstag 00:30 (Inhalt Freitag) gegen die 20 Fenster mit Werktag in der Mitte; ohne "
       "28 Tage Vorlauf nicht bestimmt",
       len(verg24) == 20 and abs(K24["rv"][sa_i] - c["nz"][sa_i - 1440:sa_i].sum() / np.median(verg24)) < 1e-9
       and not np.isfinite(K24["rv"][10 * 1440]) and not np.isfinite(K["rv"][10 * 1440]), f"RV {K24['rv'][sa_i]:.4f}, Vergleiche {len(verg24)}")
    # ---- V4 Kausalität
    M2 = {**M, "coins": {"BTC": {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in c.items()}}, "aufgezeichnet": M["aufgezeichnet"].copy()}
    M2["coins"]["BTC"]["nz"][i:] *= 7.0; M2["coins"]["BTC"]["vb"][i:] *= 3.0
    K2 = kennzahl_reihen(M2, "BTC", W_KURZ); K2l = kennzahl_reihen(M2, "BTC", W_LANG)
    ok("V4 Kausalität: Umsatz und Seiten ab der Entscheidung beliebig verändert -> RV und TS beim Einstieg gleich (60 min und 24 h)",
       K2["rv"][i] == K["rv"][i] and K2["irel"][i] == K["irel"][i] and K2l["rv"][i] == K24["rv"][i] and K2l["irel"][i] == K24["irel"][i])
    # ---- V5 Gültigkeit
    M3 = {**M, "aufgezeichnet": M["aufgezeichnet"].copy()}
    M3["aufgezeichnet"][i - 10:i - 6] = False
    K3 = kennzahl_reihen(M3, "BTC", W_KURZ)
    M4 = {**M, "coins": {"BTC": dict(c, fraglich=c["fraglich"].copy())}}
    M4["coins"]["BTC"]["fraglich"][i - 3:i] = True
    K4 = kennzahl_reihen(M4, "BTC", W_KURZ)
    M5 = {**M, "coins": {"BTC": dict(c, nt=np.full(M["N"], 0.3))}}
    K5 = kennzahl_reihen(M5, "BTC", W_KURZ)
    ok("V5 Gültigkeit: 4 von 60 Minuten ohne BTC-Bar -> nicht bestimmt; 3 von 60 fraglich (5 %) -> bestimmt; unter 20 Trades -> TS nicht "
       "bestimmt, RV schon",
       not np.isfinite(K3["rv"][i]) and np.isfinite(K4["rv"][i]) and not np.isfinite(K5["irel"][i]) and np.isfinite(K5["rv"][i]),
       f"{K3['rv'][i]} / {K4['rv'][i]:.3f} / TS {K5['irel'][i]}")
    # ---- V6 fragliche Minute, Seitenprüfung, Spalten richtig herum (Probe-Datenbank)
    tmp = tempfile.mkdtemp(prefix="hl_vol_")
    try:
        dbp = os.path.join(tmp, "hl_liq.db"); con = sqlite3.connect(dbp)
        con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin))")
        con.execute("CREATE TABLE bars10 (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, vol_buy REAL, vol_sell REAL, trades INTEGER, "
                    "n_liq INTEGER, liq_notional REAL, max_sz REAL, PRIMARY KEY (ts, coin))")
        t0b = M["t_von"]; rng = np.random.default_rng(5); px = 100.0; rows_b, rows_10 = [], []
        for m in range(3000):
            ts = t0b + m * 60
            kb = [rng.gamma(2.0) for _ in range(6)]; ks = [rng.gamma(2.0) for _ in range(6)]
            imb = (sum(kb) - sum(ks)) / (sum(kb) + sum(ks))
            neu = px * math.exp(0.002 * imb + 0.0003 * rng.standard_normal())
            vol = sum(kb) + sum(ks)
            if m == 1500:
                vol *= 0.4                                        # Bruchstück: bars kleiner als die Summe aus bars10
            rows_b.append((ts, "BTC", px, max(px, neu), min(px, neu), neu, vol, 12))
            for j in range(6):
                rows_10.append((ts + 10 * j, "BTC", px, px, px, px, kb[j], ks[j], 2, 0, 0.0, 1.0))
            px = neu
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows_b)
        con.executemany("INSERT INTO bars10 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows_10)
        con.commit()
        Mx = minuten_laden(con, ("BTC",), t0b, t0b + 3000 * 60)
        sp = seiten_pruefen(Mx, ("BTC",))
        kauf_1 = sum(r[6] for r in rows_10[6:12])
        con.execute("UPDATE bars10 SET vol_buy = vol_sell, vol_sell = vol_buy"); con.commit()
        My = minuten_laden(con, ("BTC",), t0b, t0b + 3000 * 60)
        sp2 = seiten_pruefen(My, ("BTC",))
        con.close()
        ok("V6 Daten: Kauf der Minute = Σ vol_buy der 10-s-Stücke; fragliche Minute erkannt (bars gegen Σ bars10); Seitenprüfung ρ > 0,1; "
           "vertauschte Seiten -> „Seiten fraglich“",
           abs(Mx["coins"]["BTC"]["vb"][1] - kauf_1) < 1e-9 and Mx["coins"]["BTC"]["fraglich"].sum() == 1 and bool(Mx["coins"]["BTC"]["fraglich"][1500])
           and sp["BTC"]["ok"] and not sp2["BTC"]["ok"], f"ρ {sp['BTC']['rho']:.2f} / vertauscht {sp2['BTC']['rho']:.2f}")
        # ---- V7 Trades: t0 bei Limit = gefüllte Order; Ausschlüsse je Grund und Strategie
        import hl_labor
        fcp = os.path.join(tmp, "forecasts.db"); con = sqlite3.connect(fcp)
        con.executescript(hl_labor.SCHEMA)
        con.executemany("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,?)", [("e@1", "empfehlung_limit", "E", "Prognose", '{"h": 12}', "", 0, 1),
                                                                               ("e@0", "empfehlung_limit", "E", "Prognose", '{"h": 12}', "", 0, 0),
                                                                               ("g@1", "grid_long", "G", "Grid", '{"h": 24}', "", 0, 1),
                                                                               ("a@1", "akku", "A", "Akkumulation", '{"h": 24}', "", 0, 1),
                                                                               ("s@1", "swing_trend", "S", "Swing", '{"h": 24}', "", 0, 1)])
        T_ = 1_790_000_000
        con.executemany("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, art_ein, geschlossen, grund_aus, netto_pct, netto_usd) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?)", [("e@1", "BTC", "long", "geschlossen", T_ + 7200 + 17, "Limit (Maker)", T_ + 9000, "Ziel", 0.5, 50),
                                                         ("e@1", "BTC", "short", "geschlossen", T_ + 100, "Limit (Maker)", T_ + 900, "Stop", -0.3, -30),
                                                         ("g@1", "BTC", "long", "geschlossen", T_, "Markt (Taker)", T_ + 60, "Ziel", 0.1, 10),
                                                         ("a@1", "BTC", "long", "geschlossen", T_, "Markt (Taker)", T_ + 60, "Ziel", 0.1, 10),
                                                         ("s@1", "ETH", "long", "geschlossen", T_, "Markt (Taker)", T_ + 60, "Regelversion abgelöst", 0.1, 10),
                                                         ("s@1", "PAXG", "long", "geschlossen", T_, "Markt (Taker)", T_ + 60, "Ziel", 0.1, 10),
                                                         ("s@1", "ETH", "long", "geschlossen", T_, "Markt (Taker)", T_ + 2 * 10 ** 6, "Ziel", 0.1, 10),
                                                         ("s@1", "ETH", "short", "offen", T_ + 300, "Markt (Taker)", None, None, None, None)])
        con.executemany("INSERT INTO labor_order (sid, coin, erstellt, status, pos_id) VALUES (?,?,?,?,?)", [("e@1", "BTC", T_ + 1234, "gefuellt", 1),
                                                                                                            ("e@1", "BTC", T_ + 999, "storniert", None)])
        # Order nach 30 Tagen gelöscht: t0 aus dem Ereignis „limit“ (alte Kennung derselben Strategie, gleicher Preis, vor der Füllung)
        con.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, art_ein, geschlossen, grund_aus, netto_pct, "
                    "netto_usd) VALUES ('e@1', 'ETH', 'long', 'geschlossen', ?, 2500.5, 'Limit (Maker)', ?, 'Ziel', 0.2, 20)", (T_ + 50_000, T_ + 52_000))
        con.executemany("INSERT INTO labor_ereignis (ts, sid, coin, art, seite, preis, text) VALUES (?,?,?,?,?,?,?)",
                        [(T_ + 49_000, "e@0", "ETH", "limit", "long", 2500.5, "gelegt"), (T_ + 47_000, "e@0", "ETH", "limit", "long", 2500.5, "früher"),
                         (T_ + 49_500, "e@1", "ETH", "limit", "long", 2501.0, "anderer Preis"),
                         (T_ + 50_100, "e@1", "ETH", "limit", "long", 2500.5, "nach der Füllung")])
        con.commit(); con.close()
        L = labor_trades(fcp, T_ + 10 ** 6)
        lim = [t for t in L["trades"] if t["coin"] == "ETH"]
        ok("V7 Trades: Limit-Einstieg zählt ab der gefüllten Order (auf die Minute); ist die Order gelöscht, ab dem Ereignis „limit“ "
           "(Strategie, Coin, Seite, Preis, vor der Füllung, auch alte Kennung); ohne beides heraus; Grid, Akkumulation, Regelversion "
           "abgelöst, fremder Coin heraus und je Strategie gezählt; nach dem Stichtag geschlossen nicht dabei; offene Position für den Stand",
           len(L["trades"]) == 2 and L["trades"][0]["t0"] == (T_ + 1234) // 60 * 60 and L["aus"].get("Limit ohne Order") == 1
           and len(lim) == 1 and lim[0]["t0"] == (T_ + 49_000) // 60 * 60 and L["t0_ereignis"] == 1
           and L["aus"].get("Grid (6.8)") == 1 and L["aus"].get("Akkumulation (6.9)") == 1 and L["aus"].get("Regelversion abgelöst") == 1
           and L["aus"].get("anderer Coin") == 1 and L["nach_stichtag"] == 1 and L["aus_je"]["swing_trend"] == {"Regelversion abgelöst": 1, "anderer Coin": 1}
           and len(L["offen"]) == 1 and L["offen"][0]["sid"] == "s@1", f"{L['aus']}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # ---- V8 Drittel je Schicht von Hand, Gleichstand nach t0, Grenzen und Mittel je Drittel
    v = np.array([1.0, 2.0, 3.0, 1.0, 1.0, 1.0, 5.0, 6.0, 7.0, 2, 2, 2, 2, 2, 2, 2, 2, 2])
    e = np.array([0.0, 0.0, 0.0, 1.0, 2.0, 3.0, 9.0, 9.0, 9.0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    sch = np.array([0] * 9 + [1] * 9); t0 = np.arange(18)
    Ds, ns = d_schichten(v, e, sch, t0, 2)
    det = drittel_details(v, e, sch, t0, 2)
    # Schicht 0 nach (v, t0): v = 1 bei t0 0, 3, 4, 5 -> unten e 0, 1, 2 (Ø 1), Mitte e 3, 0, 0 (Ø 1), oben e 9 (Ø 9) -> D 8; Grenzen 1 / 5
    # Schicht 1: alle gleich -> nach t0: unten e 1, 2, 3 (Ø 2), Mitte 4, 5, 6 (Ø 5), oben 7, 8, 9 (Ø 8) -> D 6
    ok("V8 Drittel je Schicht von Hand (k = n // 3, Gleichstand nach t0), Grenzen und Ø je Drittel; Schicht unter 9 Trades fällt heraus",
       abs(Ds[0] - 8.0) < 1e-12 and abs(Ds[1] - 6.0) < 1e-12 and ns[0] == 9 and det["lo"][0] == 1.0 and det["hi"][0] == 5.0
       and abs(det["mu_u"][0] - 1.0) < 1e-12 and abs(det["mu_m"][0] - 1.0) < 1e-12 and abs(det["tr_o"][0] - 1.0) < 1e-12
       and abs(det["mu_m"][1] - 5.0) < 1e-12 and not np.isfinite(d_schichten(v[:8], e[:8], sch[:8], t0[:8], 1)[0][0]), f"D {Ds}")
    # ---- V9 Holm, BH, p-Formeln
    hp = holm([0.01, 0.04, 0.03, float("nan")]); bq = bh([0.01, 0.04, 0.03])
    null = np.array([0.0, 0.1, -0.1, 0.2, -0.2, 0.05, -0.05, 0.3, -0.3, 0.0]) + 0.5
    p, m = p_zentriert(0.75, null)
    n3 = np.r_[null, null, null]
    pn, zn, mn, _ = p_normal(0.5 + 2 * float(n3.std(ddof=1)), n3)
    leer = Teil([], [], [], [], [], [], [], None, [])
    Rf = {"D_pool": 0.2, "null_pool": 0.5 + 0.1 * np.linspace(-1, 1, 51), "h_pool": (0.3, 0.1), "n_pool": 500, "spanne_pool": 30.0,
          "null_n": np.full(51, 500.0), "boot_pool": np.linspace(0.1, 0.3, 100), "D_st": np.zeros(0), "null_st": np.zeros((51, 0)),
          "h_st": (np.zeros(0), np.zeros(0)), "n_in": np.zeros(0), "spanne_st": np.zeros(0), "boot_st": np.zeros((100, 0)),
          "pool": np.zeros(0, dtype=bool)}
    hf = urteile(Rf, leer, POOL_PRUEF_MIN, POOL_PRUEF_TAGE, True)["haupt"]
    h2 = [{"pruefbar": True, "p": 0.04, "haelften": True}, {"pruefbar": False, "p": float("nan"), "haelften": False}]
    _haupt_urteil(h2, True)
    w600 = wirksame_verschiebungen(TAU_A, 600 * 60); w300 = wirksame_verschiebungen(TAU_A, 300 * 60)
    e300 = np.mod(w300 * 60, 300 * 60)
    ok("V9 Holm und BH von Hand; p der Hauptprüfung mit Abstand vom Null-Median ((1 + #) ÷ (1 + N)), Null hier um 0,5 versetzt; "
       "Normalnäherung je Strategie; 626 bzw. 672 Verschiebungen ohne |τ| < 24 h / 30 T; Hälften gegen den Null-Median (D 0,2 und "
       "Hälften 0,3 / 0,1 liegen alle unter m = 0,5 -> gleich); Holm bleibt bei zwei Tests, wenn A2 nicht prüfbar ist; bei 25 Tagen Spanne "
       "553 verschiedene Verschiebungen, keine wirksam unter 24 h",
       abs(hp[0] - 0.03) < 1e-12 and abs(hp[2] - 0.06) < 1e-12 and abs(hp[1] - 0.06) < 1e-12 and not math.isfinite(hp[3])
       and abs(bq[0] - 0.03) < 1e-12 and abs(bq[1] - 0.04) < 1e-12 and abs(bq[2] - 0.04) < 1e-12 and abs(p - 3 / 11) < 1e-12 and abs(m - 0.5) < 1e-12
       and abs(mn - 0.5) < 1e-12 and abs(zn - 2.0) < 1e-9 and abs(pn - math.erfc(2.0 / math.sqrt(2))) < 1e-9
       and len(TAU_A) == 626 and len(TAU_B) == 672 and np.min(np.abs(TAU_A)) == 24 and np.min(np.abs(TAU_B)) == 30
       and hf["haelften"] and abs(hf["m"] - 0.5) < 1e-12 and abs(h2[0]["p_holm"] - 0.08) < 1e-12 and h2[0]["urteil"] == "nicht belegt"
       and len(wirksame_verschiebungen(TAU_A, 700 * 60)) == 626 and len(w600) == 553 and len(np.unique(np.mod(w600 * 60, 600 * 60))) == 553
       and np.min(np.minimum(e300, 300 * 60 - e300)) >= 24 * 60,
       f"Holm {hp[:3]}, BH {bq}, p {p:.3f}, z {zn:.2f}, Hälften {hf['haelften']}, A2 nicht prüfbar -> A1 p Holm {h2[0]['p_holm']:.2f}, "
       f"Verschiebungen bei 25 Tagen Spanne {len(w600)}")
    # ---- V10 Verschiebung zirkulär über die Spanne, fertige Reihen; Vorzeichen bei Short
    M = _probe_minuten(75, seed=11)
    Rr = ReihenA(M, ("BTC", "ETH"), {"BTC": True, "ETH": True}, M["t_von"] + 29 * TAG, M["t_von"] + 75 * TAG)
    t_e = M["t_von"] + 40 * TAG + 123 * MIN
    w0 = Rr.werte("rv", np.array(["BTC"]), np.array([60]), np.array([t_e]), np.array([1.0]), 0)[0]
    w1 = Rr.werte("rv", np.array(["BTC"]), np.array([60]), np.array([t_e]), np.array([1.0]), 24 * 60)[0]
    w_wrap = Rr.werte("rv", np.array(["BTC"]), np.array([60]), np.array([M["t_von"] + 30 * TAG]), np.array([1.0]), 48 * 60)[0]
    ii_wrap = Rr.a + ((30 * 1440 - 48 * 60 - Rr.a) % (Rr.b - Rr.a))
    ts_l = Rr.werte("ts", np.array(["BTC"]), np.array([60]), np.array([t_e]), np.array([1.0]), 0)[0]
    ts_s = Rr.werte("ts", np.array(["BTC"]), np.array([60]), np.array([t_e]), np.array([-1.0]), 0)[0]
    ie = (t_e - M["t_von"]) // 60
    ok("V10 Nullmodell: Verschiebung um 24 h liest den fertigen RV 24 h früher; am Anfang der Spanne zirkulär vom Ende; TS bei Short = −I_rel",
       w1 == Rr.R[("BTC", 60)]["rv"][ie - 1440] and w0 == Rr.R[("BTC", 60)]["rv"][ie] and w_wrap == Rr.R[("BTC", 60)]["rv"][ii_wrap]
       and ii_wrap > 60 * 1440 and ts_l == Rr.R[("BTC", 60)]["irel"][ie] and ts_s == -ts_l and ts_l != 0, f"{w0:.3f} / {w1:.3f}")
    # ---- V11/V12 Positivkontrollen, V13 Negativkontrolle
    U, T, R = _urteil_probe(_probe_trades(M, Rr, 1500, seed=12, effekt_rv=0.3, namen=("a_folgen", "b", "c")), Rr, "rv")
    je = [dict(t, kennzahl="rv") for t in U["je"]]
    familie_urteilen(je, True)
    ok("V11 Positivkontrolle RV (oberes Drittel 0,3 Pkt. besser): A1 belegt, je Strategie (500 Trades) erkannt",
       U["haupt"]["urteil"] == "belegt" and all(t["urteil"] == "belegt" for t in je),
       f"D {U['haupt']['D']:+.3f}, p {U['haupt']['p']:.4f}, je Strategie {[t['urteil'] for t in je]}")
    U, T, R = _urteil_probe(_probe_trades(M, Rr, 1500, seed=13, effekt_ts=0.3, namen=("a_folgen", "b", "c")), Rr, "ts")
    ok("V12 Positivkontrolle TS (Taker-Druck in Handelsrichtung 0,3 Pkt. besser, Longs und Shorts): A2 belegt", U["haupt"]["urteil"] == "belegt",
       f"D {U['haupt']['D']:+.3f}, p {U['haupt']['p']:.4f}")
    belegt = 0
    for s in range(20):
        tr = _probe_trades(M, Rr, 600, seed=100 + s, namen=("a_folgen", "b"))
        T = teil_a_bauen(tr, Rr, tau_h=TAU_A[::12])
        h = []
        for k in ("rv", "ts"):
            R = auswerten(T, k, pool_a(T.namen, T.gruppen), n_boot=40, seed=s)
            h.append(urteile(R, T, POOL_PRUEF_MIN, POOL_PRUEF_TAGE, True)["haupt"])
        _haupt_urteil(h, True)
        belegt += any(x["urteil"] == "belegt" for x in h)
    ok("V13 Negativkontrolle: Ertrag unabhängig vom Volumen -> in mindestens 18 von 20 Saaten kein „belegt“", belegt <= 2, f"{belegt} von 20")
    # ---- V14 Störgrößen
    Uwe, _, _ = _urteil_probe(_probe_trades(M, Rr, 1500, seed=21, effekt_we=0.5), Rr, "rv")
    Ulo, _, _ = _urteil_probe(_probe_trades(M, Rr, 1500, seed=22, effekt_long=0.5), Rr, "ts")
    Umo, _, _ = _urteil_probe(_probe_trades(M, Rr, 1500, seed=23, effekt_mo=0.5, h=24, nacht=True), Rr, "rv")
    ok("V14 Störgrößen: Wochenend-Effekt -> RV nicht belegt; Long-gegen-Short -> TS nicht belegt; Montags-Effekt bei 24-h-Fenstern mit "
       "Einstieg 00–06 UTC (das Fenster enthält den Sonntag) -> RV nicht belegt",
       Uwe["haupt"]["urteil"] != "belegt" and Ulo["haupt"]["urteil"] != "belegt" and Umo["haupt"]["urteil"] != "belegt",
       f"RV D {Uwe['haupt']['D']:+.3f} p {Uwe['haupt']['p']:.3f} · TS D {Ulo['haupt']['D']:+.3f} p {Ulo['haupt']['p']:.3f} · Montag D "
       f"{Umo['haupt']['D']:+.3f} p {Umo['haupt']['p']:.3f}")
    # ---- V15 Pool: Regeln und fest bei τ = 0
    namen = ["wale_folgen", "wale_gegen", "zufall", "swing_zufall", "halten_long", "familie_orderfluss", "twap_druck", "grid_long", "akku", "prognose_v1"]
    gruppen = ["Händler", "Händler", "Kontrolle", "Swing", "Kontrolle", "volumengekoppelt", "volumengekoppelt", "Grid", "Akkumulation", "Prognose"]
    pm = pool_a(namen, gruppen)(np.full(len(namen), 100))
    Mg = {**M, "aufgezeichnet": M["aufgezeichnet"].copy()}
    Mg["aufgezeichnet"][30 * 1440:30 * 1440 + 720] = False                # Tag 30 (Mittwoch) 00–12 Uhr ohne Aufzeichnung
    Rg = ReihenA(Mg, ("BTC", "ETH"), {"BTC": True, "ETH": True}, M["t_von"] + 29 * TAG, M["t_von"] + 75 * TAG)
    tr = _probe_trades(Mg, Rg, 600, seed=33, namen=("a_folgen", "b"))
    t31 = M["t_von"] + 31 * TAG
    tr += [{"id": 9000 + q, "sid": "c", "name": "c", "gruppe": "Händler", "h": 4.0, "coin": "BTC", "seite": "long",
            "t0": int(t31 + (3600 + 1800 * q if q < 20 else 13 * 3600 + 1800 * (q - 20))), "netto": float(np.sin(q))} for q in range(30)]
    T = teil_a_bauen(tr, Rg, tau_h=np.array([24, -24, 48], dtype=np.int64))
    R = auswerten(T, "rv", pool_a(T.namen, T.gruppen), n_boot=5)
    ic = T.namen.index("c")
    v24 = np.where(R["gueltig"], T.werte("rv", 24), np.nan)
    Ds_, ns_ = d_schichten(v24, T.erg, T.schicht, T.t0, T.n_s)
    fest = verdichten(Ds_, ns_, np.where(R["pool"][T.schicht_strat], 0, -1), 1)[0][0]
    ohne_c = verdichten(Ds_, ns_, np.where(R["pool"][T.schicht_strat] & (T.schicht_strat != ic), 0, -1), 1)[0][0]
    n_c24 = int(np.isfinite(v24[T.strat == ic]).sum())
    T.gruppen = ["Händler"] * T.n_strat
    gd = [g for g in gruppen_d(T, R) if g["gruppe"] == "Händler"][0]
    ok("V15 Pool: ohne Kontrollen, gekoppelte, Spiegel, Grid, Akkumulation, ab 30 gültigen Trades; fest bei τ = 0 -- eine Strategie mit "
       "30 gültigen Trades bleibt in der Verschiebung im Pool, auch wenn dort nur 10 bestimmt sind; Gruppe (6.1) je Verschiebung mit deren "
       "Gewichten (eine Gruppe aus den Pool-Strategien = Pool)",
       list(pm) == [True, False, False, False, False, False, False, False, False, True] and not pool_a(["prognose_v1"], ["Prognose"])(np.array([29]))[0]
       and bool(R["pool"][ic]) and n_c24 == 10 and abs(R["null_pool"][0] - fest) < 1e-12 and abs(fest - ohne_c) > 1e-6
       and abs(gd["D"] - R["D_pool"]) < 1e-12 and np.allclose(gd["null"], R["null_pool"], rtol=0, atol=1e-12),
       f"c bei τ = 24 h: {n_c24} bestimmt; D fest {fest:+.4f}, ohne c {ohne_c:+.4f}")
    # ---- V16 Teil B: Tageskennzahlen von Hand
    d0 = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp()) // TAG
    n = 120; rng = np.random.default_rng(31)
    vv = rng.uniform(1e8, 2e8, n); tk = vv * rng.uniform(0.45, 0.55, n)
    H = {"BTC": {"d0": d0, "n": n, "v": vv, "taker": tk}}
    Kt = kennzahl_tage(H["BTC"])
    d = 80; art = tagesart(np.array([(d0 + d) * TAG]))[0]
    vg = [vv[d - k] for k in range(1, 29) if tagesart(np.array([(d0 + d - k) * TAG]))[0] == art]
    qg = [2 * tk[d - k] / vv[d - k] - 1 for k in range(1, 29) if tagesart(np.array([(d0 + d - k) * TAG]))[0] == art]
    Rb = ReihenB(H)
    t_in = (d0 + d + 1) * TAG
    wb = Rb.werte("rv", np.array(["BTC"]), np.array([t_in - TAG]), np.array([1.0]), 0)[0]
    qb = Rb.werte("ts", np.array(["BTC"]), np.array([t_in - TAG]), np.array([-1.0]), 0)[0]
    ok("V16 Teil B: Tages-RV und Taker-Anteil von Hand (gleiche Tagesart, 28 Tage davor); Einstieg Tag e liest Tag e−1; Short umgekehrt",
       abs(Kt["rv"][d] - vv[d] / np.median(vg)) < 1e-9 and abs(Kt["qrel"][d] - ((2 * tk[d] / vv[d] - 1) - np.median(qg))) < 1e-12
       and abs(wb - Kt["rv"][d]) < 1e-12 and abs(qb + Kt["qrel"][d]) < 1e-12, f"RV {Kt['rv'][d]:.4f}")
    # ---- V17 Teil B über hl_swing.lauf
    try:
        import hl_swing as SW
        rng = np.random.default_rng(41)
        nb = 520 * 48; ts = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp()) + 1800 * np.arange(nb)
        c_ = 100 * np.exp(np.cumsum(0.004 * rng.standard_normal(nb)))
        o_ = np.concatenate([[100.0], c_[:-1]])
        K = {"ts": ts.astype(np.int64), "o": o_, "h": np.maximum(o_, c_) * 1.001, "l": np.minimum(o_, c_) * 0.999, "c": c_, "v": np.ones(nb)}
        F = {"ts": np.zeros(0, dtype=np.int64), "rate": np.zeros(0)}
        ende = int(ts[-1]) - 10 * TAG
        k = K["ts"] < ende
        Dd = {"BTC": SW.daten_aufbereiten({key: arr[k] for key, arr in K.items()}, F)}
        S = swing_trades(Dd, namen=("swing_trend",))
        t_ok = all(t["t0"] == t["t_in"] // TAG * TAG - TAG and t["t_in"] < ende for t in S["trades"])
        orig = SW.lauf

        def spion(*a, **kw):
            r = orig(*a, **kw)
            if r["trades"]:
                r["trades"] = r["trades"] + [dict(r["trades"][-1], grund="offen am Ende", t_in=r["trades"][-1]["t_in"] + TAG)]
            return r
        SW.lauf = spion
        try:
            S2 = swing_trades(Dd, namen=("swing_trend",))
        finally:
            SW.lauf = orig
        ok("V17 Teil B über hl_swing.lauf: Entscheidung am Schluss von e−1, nichts nach dem Datenschluss, „offen am Ende“ gezählt und heraus",
           len(S["trades"]) > 3 and t_ok and S2["offen_am_ende"] == 1 and len(S2["trades"]) == len(S["trades"]),
           f"{len(S['trades'])} Trades, offen am Ende (Spion) {S2['offen_am_ende']}")
    except Exception as ex:                                                 # noqa: BLE001
        ok("V17 Teil B über hl_swing.lauf", False, f"{type(ex).__name__}: {ex}")
    # ---- V18 Urteil erst am Stichtag
    tt = [{"pruefbar": True, "p": 0.001, "band": (0.1, 0.2), "haelften": True}]
    familie_urteilen(tt, urteil_a_erlaubt(STICHTAG - 1))
    hh = [{"pruefbar": True, "p": 0.001, "haelften": True}]
    _haupt_urteil(hh, urteil_a_erlaubt(STICHTAG - 1))
    tt2 = [{"pruefbar": True, "p": 0.001, "band": (0.1, 0.2), "haelften": True}]
    familie_urteilen(tt2, urteil_a_erlaubt(STICHTAG))
    ok("V18 Urteil Teil A erst ab dem 08.11.2026 00:00 UTC; davor „vorläufig“ auch bei kleinem p", tt[0]["urteil"] == "vorläufig"
       and hh[0]["urteil"] == "vorläufig" and tt2[0]["urteil"] == "belegt" and STICHTAG == 1794096000, _dt(STICHTAG))
    # ---- V19 Markteffekt
    tr = _probe_trades(M, Rr, 1800, seed=51, effekt_rv=0.3, namen=("zufall", "a_folgen", "b"))
    T = teil_a_bauen(tr, Rr, tau_h=TAU_A[::8])
    A_ = {k: {"roh": auswerten(T, k, pool_a(T.namen, T.gruppen), n_boot=150)} for k in ("rv", "ts")}
    zf = zufall_vergleich(T, A_)
    ok("V19 Markteffekt: derselbe RV-Effekt in allen Strategien -> „Zufall“ zeigt ihn (z > 3), D − D(Zufall) je Strategie mit Band um 0",
       zf["rv"]["z"] > 3 and all(e["band"][0] < 0 < e["band"][1] for e in zf["rv"]["je"]),
       f"Zufall D {zf['rv']['D']:+.3f} z {zf['rv']['z']:+.1f}; D−Z {[round(e['d'], 3) for e in zf['rv']['je']]}")
    # ---- V20 Bausteine: schneller Median, Spitze und Binance-RV von Hand
    rng = np.random.default_rng(61)
    Vm = rng.standard_normal((500, 28)); Vm[rng.random((500, 28)) < 0.3] = np.nan; Vm[3] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        ref = np.nanmedian(Vm, axis=1)
    med, cnt = _nanmedian_zeilen(Vm)
    sp = spitze_reihen(M, "BTC")
    j = 40 * 1440 + 7
    off = int((-(M["t_von"] // MIN)) % 5); e5 = off + 5 * ((j - off) // 5)
    nzb = M["coins"]["BTC"]["nz"]
    bl = [nzb[e5 - 60 + 5 * q:e5 - 60 + 5 * q + 5].sum() for q in range(12)]
    vorher = [nzb[e5 - 60 - 1440 + 5 * q:e5 - 60 - 1440 + 5 * q + 5].sum() for q in range(288)]
    tmp = tempfile.mkdtemp(prefix="hl_vol_")
    try:
        con = sqlite3.connect(os.path.join(tmp, "k.db"))
        Mk = _probe_minuten(40, coins=("BTC",), seed=62, t_von=M["t_von"])
        _probe_db_minuten(con, Mk, cb_ab=M["t_von"] + 34 * TAG)
        bn = binance_rv_reihen(con, Mk, ("BTC",))
        cbt, cb_ab_ = coinbase_ts_reihen(con, Mk, ("BTC",))
        con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    jm = 35 * 1440 + 47; eg = (Mk["t_von"] + jm * MIN) // 1800 * 1800

    def v30(t_end):
        return Mk["coins"]["BTC"]["vol"][(t_end - 3600 - Mk["t_von"]) // 60:(t_end - Mk["t_von"]) // 60].sum()
    vg30 = [v30(eg - k * TAG) for k in range(1, 29) if art_fenster(np.array([eg - k * TAG]), 60)[0] == art_fenster(np.array([eg]), 60)[0]]
    ck = Mk["coins"]["BTC"]

    def cb_saldo(e):
        b_, s_ = (ck["vb"][e - 60:e] * ck["c"][e - 60:e]).sum(), (ck["vs"][e - 60:e] * ck["c"][e - 60:e]).sum()
        return (b_ - s_) / (b_ + s_)
    t_jm = Mk["t_von"] + jm * MIN
    cb_hand = cb_saldo(jm) - np.median([cb_saldo(jm - k * 1440) for k in range(1, 29)
                                        if art_fenster(np.array([t_jm - k * TAG]), 60)[0] == art_fenster(np.array([t_jm]), 60)[0]])
    rng = np.random.default_rng(63)
    vb_ = np.round(rng.standard_normal(3000), 1); vb_[rng.random(3000) < 0.1] = np.nan          # mit Gleichständen und Lücken
    eb_ = rng.standard_normal(3000); sb_ = rng.integers(0, 40, 3000); tb_ = rng.integers(0, 500, 3000)
    ob_ = boot_ordnung(vb_, sb_, tb_)
    gleich_b = True
    for q in range(30):
        mu_ = rng.integers(0, 4, 3000)
        Da, na = d_schichten(vb_, eb_, sb_, tb_, 40, mu_)
        Db, nb_ = d_schichten_mult(ob_, eb_, sb_, 40, mu_)
        gleich_b &= bool(np.array_equal(na, nb_) and np.allclose(Da, Db, rtol=0, atol=1e-9, equal_nan=True))
    ok("V20 Bausteine: Median ohne nan wie numpy; Spitze (größter 5-min-Umsatz ÷ Median der 288 Blöcke davor), Binance-RV (30-min-Kerzen "
       "wie in swing.db, Fenster auf 30 min abgerundet) und Coinbase-Taker-Saldo (Seiten über cb_seite_ab berichtigt) von Hand; Bootstrap ohne neues Sortieren gleich der "
       "Rechnung mit wiederholten Trades (30 Ziehungen, Gleichstände)",
       np.allclose(med, ref, equal_nan=True) and cnt[3] == 0 and abs(sp[60][j] - max(bl) / np.median(vorher)) < 1e-9
       and abs(bn[("BTC", 60)][jm] - v30(eg) / np.median(vg30)) < 1e-9 and gleich_b and abs(cbt[("BTC", 60)][jm] - cb_hand) < 1e-9
       and cb_ab_ == M["t_von"] + 34 * TAG,
       f"Spitze {sp[60][j]:.3f}, Binance-RV {bn[('BTC', 60)][jm]:.3f}, Coinbase-TS {cbt[('BTC', 60)][jm]:+.4f} (von Hand {cb_hand:+.4f}, "
       f"Seiten vor Tag 34 vertauscht gespeichert), Bootstrap gleich {gleich_b}")
    # ---- V21 Ende zu Ende auf erfundenen Datenbanken
    tmp = tempfile.mkdtemp(prefix="hl_vol_e2e_")
    alt_env = {k: os.environ.get(k) for k in ("HL_FORECAST_DB", "HL_LABOR_A_DB", "HL_HEBEL_DB", "HL_SWING_DB")}
    try:
        for k in alt_env:
            os.environ.pop(k, None)
        t1 = time.time()
        U_ = _probe_umgebung(tmp)
        t_bau = time.time() - t1
        t1 = time.time()
        Vv = studie_rechnen(U_["db"], jetzt=STICHTAG - 3 * TAG, log=lambda s: None, n_boot=100, n_beschr=60)
        txt_v = bericht_text(Vv)
        Vu = studie_rechnen(U_["db"], jetzt=STICHTAG + 9 * 3600 + 900, log=lambda s: None, n_boot=100, n_beschr=60)
        txt_u = bericht_text(Vu)
        t_lauf = time.time() - t1
        Au, Av = Vu.get("A"), Vv.get("A")
        teile = ("== TEIL A", "A1 ", "A2 ", "6.1 ", "6.2 ", "6.3 ", "6.4 ", "6.5 ", "6.6 ", "6.7 Welt A (", "6.8 Grid (", "6.9 Akkumulation (", "6.10 ",
                 "6.11 ", "== 7. Stand heute", "offen: wale_folgen", "== TEIL B", "B1 ", "B2 ", "6.12 je Jahr", "6.12 Zufalls-Swing",
                 "Anhang: Drittelgrenzen", "ENDE -- bitte vollständig einfügen")
        fehlt = [t for t in teile if t not in txt_u]
        t0_min = min(int(x) for x in Au["T"].t0) if Au else 0
        ok("V21 Ende zu Ende (erfundene Datenbanken): vorläufig vor dem Stichtag, Urteil danach (nur Trades vor dem 08.11.), alle Teile "
           "des Berichts, Teil B mit vollständiger Historie geurteilt und ohne Einstiege nach dem 23.10. (Kerzen reichen weiter), Prüfsumme "
           "von Teil B in beiden Läufen gleich, keine Trades vor der Spanne, Seiten von Coinbase korrigiert, 6.9 ohne Kurse nach dem Stichtag",
           Av is not None and Au is not None and "VORLÄUFIG -- kein Urteil" in txt_v and "URTEIL: Stichtag erreicht" in txt_u and not fehlt
           and Av["rv"]["haupt"]["urteil"] in ("vorläufig", "nicht prüfbar") and Au["rv"]["haupt"]["urteil"] in ("belegt", "nicht belegt")
           and Vu["B"] is not None and Vu["B"]["voll"] and Vu["B"]["rv"]["haupt"]["urteil"] != "vorläufig" and t0_min >= Vu["t_a"]
           and Vu["daten_a"]["coins"]["BTC"]["seiten"]["ok"] and Vu.get("cb_ab") == U_["t_von"] + 5 * TAG
           and max(int(x) for x in Au["T"].t0) < STICHTAG and int(Vu["B"]["T"].t0.max()) + TAG < TEIL_B_ENDE
           and Au["akku"]["juenger"] == 1 and Vu["B"]["pruefsumme"] == Vv["B"]["pruefsumme"] and "Prüfsumme der Eingangsdaten" in txt_u,
           f"fehlt {fehlt}; Aufbau {t_bau:.1f} s, zwei Läufe {t_lauf:.1f} s; A1 {Au['rv']['haupt']['urteil'] if Au else '—'}, "
           f"B1 {Vu['B']['rv']['haupt']['urteil'] if Vu.get('B') else '—'}")
    except Exception as ex:                                                 # noqa: BLE001
        import traceback
        traceback.print_exc()
        ok("V21 Ende zu Ende", False, f"{type(ex).__name__}: {ex}")
    finally:
        for k, v in alt_env.items():
            if v is not None:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(pruef)
    print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(pruef)} von {len(pruef)}, {time.time() - t_start:.1f} s)", flush=True)
    return alles


def main() -> None:
    ap = argparse.ArgumentParser(description="Volumen-Studie (U221)")
    ap.add_argument("--db", default=os.environ.get("HL_DB") or "hl_liq.db")
    ap.add_argument("--studie", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    a = ap.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.studie:
        print(studie(a.db), flush=True)
        return
    ap.print_help()


if __name__ == "__main__":
    main()
