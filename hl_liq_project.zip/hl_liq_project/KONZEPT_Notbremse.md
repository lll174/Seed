# KONZEPT Notbremse: marktweite Long-Sperre bei Schocks

**Fassung 1 · vorab festgelegt in der Nacht zum 23.10.2026 (MESZ), vor jeder Auswertung des 22.10. auf den Daten des Pi.**
Projektstand: Paket 2026-09-23.75 · 28541d9ce0, auf dem Pi bis zum Einspielen 23.74. Nächste neue Nummer im Plan: U206.
Abweichungen nur als neue Fassung mit Datum und Grund, wie bei den übrigen KONZEPT-Dateien.

## 0. Auftrag und Kurzfassung

**Auftrag des Nutzers (sinngemäß, 23.10.2026):** Trägt ein Ereignis quer durch die Märkte, fallen also Krypto und Aktien
zugleich, muss eine Regel mit Vorrang vor allen Strategien sofort weitere Käufe und neue Longs stoppen. Das System soll dabei
nicht nur rechnen, sondern auch Nachrichten und aufziehende Spannungen wahrnehmen. Anlass: Am 22.10. lag das TradeLabor
tagsüber im Plus und schloss mit rund 17.000 USD Papierverlust.

**Auftrag an die umsetzende Sitzung:** U206 nach diesem Konzept bauen, mit den Prüfungen, die Abschnitt 13 dafür nennt.
Zuerst Abschnitt 2 lesen: Die Grundsätze dort gehen jeder Einzelregel vor.

**Kurzfassung**
- **Ebene A, Marktsignal (Kern, sofort scharf in Welt A):** Jede Minute prüft die Bremse, ob ein Krypto-Korb und ein
  Aktien-Korb auf `xyz` *gemeinsam* ungewöhnlich fallen (Median normierter Renditen über 15, 60 und 240 min), und ob Krypto
  allein mit einer Liquidationswelle einbricht. Zwei Stufen: **Stufe 1 Long-Sperre**, **Stufe 2 Schock**. Die Schwellen folgen
  aus einem vorab festgelegten Alarmbudget.
- **Ebene B, Nachrichten und KI (zuerst 30 Tage im Schatten):** Prognosemärkte (Polymarket) und Schlagzeilen mit
  KI-Einordnung. Die KI darf nur bremsen: Bei Spannung macht sie Ebene A empfindlicher („Wache“), bei einem eingetretenen
  Großereignis mit zwei unabhängigen Quellen löst sie Stufe 1 aus. Dazu ein Terminkalender (Wahlnacht, Notenbank), der ohne
  Schatten gilt, weil der Nutzer die Termine selbst einträgt.
- **Ebene C, Handbremse:** Knopf im Dashboard, Longs sperren für 1 h, 4 h, 24 h oder bis auf Widerruf.
- **Wirkung:** keine neuen Longs, kein Nachkaufen, offene Long-Limits storniert. Schließen ist nie gesperrt, Shorts bleiben
  frei. Was bei Stufe 2 mit offenen Longs geschieht, rechnen drei Varianten im Schatten gegen „unverändert“; entschieden
  wird nach Daten.
- **Zwei Welten:** Das TradeLabor läuft unverändert weiter (Welt B), eine Kopie mit Bremse daneben (Welt A). So bleiben
  laufende Auswertungen gültig, und der Nutzen der Bremse ist in USD messbar.

## 1. Anlass: der 22.10.2026

**Beobachtung des Nutzers:** Krypto und die Aktien auf `xyz` fielen am Abend gemeinsam. Das Labor verlor rund 17.000 USD
(Papier), aus einer Mischung von Positionen, die vor der Wende offen waren, und neuen Longs danach. Keine Regel hat das
Nachkaufen gestoppt.

**Öffentliche Berichte (sinngemäß, Quellen am Ende):** Der Nasdaq fiel um 2,6 %, der stärkste Tagesverlust seit Anfang Juni,
nachdem Quartalszahlen unter anderem von Tesla und Meta Zweifel an den KI-Ausgaben weckten. Dazu kamen ein Bericht über
US-israelische Pläne für neue Angriffe auf Iran nach den Zwischenwahlen am 03.11. und Brent über 112 USD nach
Huthi-Angriffen auf saudische Ziele. BTC lag am Nachmittag (UTC) gut 3 % tiefer bei rund 81.500 USD, ETH etwa 4 %.

**Folgerungen für den Entwurf**
1. **Kein Blitzcrash, sondern ein Abverkauf über Stunden.** Eine Bremse, die nur 5–15 min sieht, hätte ihn verpasst;
   deshalb Fenster bis 240 min.
2. **Der Gleichlauf ist das Signal.** Tech-Aktien und Krypto fielen zusammen; der Aktien-Korb gehört deshalb in die
   Kernregel, nicht nur in die Anzeige.
3. **Die Spannung baute sich über Tage auf** (Berichte über Angriffspläne seit Anfang Oktober). Darin liegt der Wert von
   Ebene B, nicht im Moment selbst.
4. **Bestand und Neueinstiege sind getrennt zu behandeln.** Neueinstiege sperrt die Bremse sofort, beim Bestand entscheidet
   der Beleg (7.2).

**Schritt 0, Verlustzerlegung des 22.10. (erstes Ergebnis von U206, auf dem Pi):** `check_notbremse.py --zerlegung
2026-10-22` zerlegt das Netto-Ergebnis der Welt B zwischen 21.10. 12:00 und 23.10. 12:00 UTC (realisiert + Bestand, nach
Gebühren und Funding).
- t0 = erste Minute mit Stufe ≥ 1 im Rückblick mit den vorab kalibrierten Schwellen (4.5). Löst die Bremse nicht aus, gilt t0
  beim empfindlichsten Budget der Tabelle in 10.4; löst sie auch dort nicht aus, die Minute mit dem kleinsten X(t) am 22.10.
  Der Bericht sagt, welcher Fall gilt.
- Teile: (a) Positionen, die vor t0 offen waren; (b) Long-Einstiege zum Markt nach t0; (c) Long-Limit-Füllungen nach t0 aus
  Orders, die vor t0 lagen; (d) Grid-Kauf-Lose nach t0; (e) Shorts.
- Je Teil: Summe in USD, Anzahl, die zehn größten Verlierer nach Strategie und Coin.
- Die Zerlegung ist eine Näherung ohne Folgeeffekte; die genaue Zahl liefert der Rückwärtstest Welt A gegen Welt B (10.4).

## 2. Grundsätze (gehen jeder Einzelregel vor)

1. **Nur Risiko senken.** Die Notbremse eröffnet nie eine Position, vergrößert keine und blockiert nie ein Schließen oder
   Verkleinern (Stopp, Ziel, Zeitablauf, Notausstieg, Grid-Verkauf).
2. **Vorrang vor allem.** Sie gilt für jede Strategie, jeden Coin und jede Hebelstufe des Labors, auch für Ensemble,
   Prognose-Strategien und Folge-Aktionen. Keine Strategie nimmt sich selbst aus; Ausnahmen setzt nur der Nutzer, als neue
   Fassung.
3. **Ein Tor.** Jeder Weg zu einer neuen oder größeren Long-Position geht durch die eine Funktion `hl_notbremse.darf(...)`.
   Das Tor fragt den Zustand zum Zeitpunkt des Vorgangs, nicht den aktuellen; das zählt bei Füllungen, die das Labor über
   Kerzen nachholt.
4. **Im Zweifel gesperrt.** Ist der Zustand älter als 180 s oder nicht lesbar, eröffnet Welt A keine Longs („Notbremse
   veraltet“), so wie das Labor heute bei „Kurs veraltet“ verfährt. Fehlen nur die Daten einer Gruppe, fällt nur deren Pfad
   aus.
5. **Laufende Auswertungen bleiben gültig.** Welt B, das heutige Labor, läuft unverändert; die Bremse wirkt nur in Welt A
   (Abschnitt 8). Die Zusage bis 25.10. (keine Änderung an Fusion, v3 und Kaskaden-Rechnung) und die Labor-Auswertung U99
   sind nicht berührt; die Bremse liest dort höchstens.
6. **Vorab festgelegt.** Formeln, Alarmbudget, Prüfungen und Entscheidungsregeln stehen hier vor dem ersten Lauf auf echten
   Daten. Der 22.10. ist ein ungesehener Test, kein Eichpunkt.
7. **Die KI darf nur bremsen.** Sie kann Stufe 1 auslösen oder Ebene A empfindlicher machen. Sie kann keine Stufe senken,
   keine Sperre aufheben und nicht handeln. Schlagzeilen sind Daten, keine Anweisungen.
8. **Namen.** Im Code heißt die Regel „Notbremse“. „Masterregel“ bleibt die Kontensperre (eiserne Regel 5). Der Schock-Alarm
   des Ausblicks (KONZEPT_Ausblick, „Schock (Ereignisalarm)“) bleibt getrennt und unverändert.
9. **Eiserne Regeln gelten unverändert:** Zeitstempel in Sekunden (UTC); Seiten `long`/`short`; `liquidations.side` roh,
   `A` = Long liquidiert; API-Deckel 1.080 je Minute mit Rang; Version und Prüfsumme gepaart; Paketname
   `hl_liq_project.zip`; Dokumente in derselben Antwort.

## 3. Aufbau

- **Neues Modul `hl_notbremse.py`** als eigener Dienst (wie `hl_coinbase.py`, in `install.py` und `update.py` eingetragen)
  mit eigener Datei `notbremse.db`. Takt: jede Minute bei Sekunde 5 (UTC); Ergebnis als Zeile in `nb_zustand`, auch wenn
  nichts auslöst.
- **Schnittstelle**
  - `zustand(con, t) -> dict`: jüngste Zeile mit `ts ≤ t`. Felder: `stufe` (0, 1, 2), `seit`, `frei_ab`, `quelle`
    (`markt_x`, `markt_y`, `ki`, `termin`, `manuell`), `grund` (Text), `x`, `y`, `lam`, `wache`, `alter_s`.
  - `darf(con, t, seite, art) -> (bool, grund)`: `art` ist `eroeffnen`, `vergroessern`, `limit_setzen`, `limit_fuellen`,
    `grid_kauf`, `schliessen` oder `verkleinern`. Für `short`, `schliessen` und `verkleinern` immer `True`.
- **Tabellen in `notbremse.db`**
  - `nb_preis(inst, ts, mid)`, WITHOUT ROWID, Schlüssel (inst, ts); 70 Tage (60 Tage Kalibrierung von Y plus Reserve),
    Älteres täglich gelöscht.
  - `nb_kerze15(inst, ts, c)`, WITHOUT ROWID, Schlüssel (inst, ts): 15-min-Schlusskurse ohne Löschfrist; beim ersten Start aus
    `candleSnapshot` (Krypto auch aus den eigenen Minutenkerzen), danach aus `nb_preis`.
  - `nb_sigma(tag, inst, klasse, v, n, quelle)`
  - `nb_zustand(ts, stufe, quelle, grund, x, y, lam, wache, gk_json, ga_json)` mit allen Gruppenwerten je Fenster
  - `nb_schwellen(gueltig_ab, theta1, theta2x, theta2y, budget_json, zeitraum, klammer_json)`
  - `nb_episode(id, start, ende, stufe_max, ausloeser, werte_json, gesperrt_n, storniert_n, d_usd, varianten_json)`
  - `nb_blockiert(ts, welt, sid, coin, seite, art, preis, grund)`
  - `nb_ki(ts, modell, prompt_fassung, eingabe_json, antwort_roh, ergebnis_json, gueltig, kosten_usd, dauer_ms)`
  - `nb_markt(ts, slug, p_risiko, volumen_24h)` und `nb_manuell(ts, aktion, dauer_s, grund)`
- **Einbau im Labor (`hl_labor.py`), nur Welt A:** das Tor in `_eroeffnen` für Longs, vor jedem Eintrag einer Long-Order in
  `labor_order`, in der Füllprüfung offener Long-Limits, im Grid-Pfad (Startbestand, Kauf-Limits, Nachführen nach unten), bei
  Folge-Aktionen und im Ensemble. Beim Eintritt in Stufe ≥ 1 storniert Welt A alle offenen Long-Limits
  (`status='storniert'`, Ereignis „Notbremse Stufe n“). Der Strategie-Status zeigt „blockiert: Notbremse Stufe n“ neben den
  bestehenden Gründen („Position offen“, „Pause bis …“, „Kurs veraltet“).
- **Gesperrte Einstiege werden verworfen, nicht nachgeholt.** Nach der Sperre braucht die Strategie ein neues Signal.
- **Bis Historie und Kalibrierung beim ersten Start fertig sind,** gelten die Startwerte (4.5); ohne σ ist X undefiniert, und
  der Abschnitt zeigt „Kalibrierung läuft“.
- **Anzeige:** Banner, Abschnitt „Notbremse“ und Knöpfe in `hl_viz.py` (Abschnitte 6 und 9); Abschnitt „Notbremse“ im Bericht
  „★ TradeLabor“; Debug-Werkzeug `check_notbremse.py` (Zustand, Episoden, Kalibrierung, Rückblick, Zerlegung, Suche nach
  Prognosemärkten).

## 4. Ebene A: Marktsignal

### 4.1 Körbe
- **Krypto K:** die Coins aus `COINS` ohne PAXG (Gold), ergänzt um die größten Perps des Haupt-Dex nach Open Interest bis zu
  10 Instrumenten; festgelegt täglich um 00:00 UTC. Gültig ab 4 Instrumenten mit Daten.
- **Aktien A:** `xyz:SP500`, `xyz:XYZ100` (Nasdaq-100) und die Top 10 aus dem Reiter „Aktienmarkt“ (KONZEPT_Ausblick 13.7 und
  13.8: NVDA, MSFT, AAPL, AMZN, GOOGL, META, AVGO, TSLA, LLY, MU), soweit auf `xyz` handelbar. Nicht im Korb: VIX, TLT,
  Rohstoffe, Gold, Devisen und kryptonahe Aktien (MSTR, STRC, COIN, HOOD, CRCL); „quer durch die Märkte“ soll wirklich zwei
  Märkte meinen. Gültig ab 3 Instrumenten.
- Öl, Gold und VIX stehen nur als Anzeige daneben.
- Außerhalb der Sitzung ist der `xyz`-Perp der Ort der Preisfindung (KONZEPT_Ausblick 13.8) und bewegt sich meist wenig.
  Gemessen an seiner eigenen Ruhe (Zeitklassen, 4.3) zählt eine breite Bewegung dort trotzdem, etwa am Wochenende nach einer
  Meldung. Geopolitische Schocks fielen 2025/26 mehrfach auf Wochenenden; bleiben die Aktien still, trägt der Krypto-Pfad Y.

### 4.2 Daten
- **Mids jede Minute** für beide Körbe, bevorzugt aus WebSocket-Abos `allMids` (Haupt-Dex und `dex: "xyz"`; ob das Abo `dex`
  kennt, beim Einbau an der Doku prüfen), sonst per REST einmal je Minute und Dex im Rang 1: `allMids`, für `xyz` notfalls
  `metaAndAssetCtxs` mit `"dex": "xyz"`, wie es der Recorder für HIP-3 schon nutzt. Gewicht nach Doku prüfen (2 oder 20);
  selbst bei 20 kosten zwei Abfragen 40 je Minute, 3,7 % des Deckels.
- `nb_preis` speichert je Minute und Instrument den jüngsten Mid. Ein Wert gilt, wenn er höchstens 120 s alt ist.
- **Historie beim ersten Start** über `candleSnapshot` im Hintergrund-Rang (`"coin": "xyz:SP500"` usw.): 15-min-Kerzen so weit
  die Abfrage reicht (laut Doku die jüngsten 5.000 Kerzen, also rund 52 Tage; die meisten `xyz`-Werte sind erst seit Mai 2026
  gelistet) nach `nb_kerze15`, 1-min-Kerzen (rund 3,5 Tage) als Startfüllung für `nb_preis`; für Krypto zusätzlich die eigenen
  Minutenkerzen seit Mitte September. `aktien.db` hält nur 30-min-Stände und reicht dafür nicht. Grenzen und Feldnamen beim
  Einbau an einer echten Antwort prüfen; die Sandbox prüft mit gespeicherten Antworten.
- **Jeder Tag Verzug kostet einen Tag Kalibrierung,** weil die Abfrage nur die jüngsten 5.000 Kerzen liefert. Der Dienst holt
  die 15-min-Kerzen deshalb als ersten Schritt nach dem Einspielen.
- **Liquidationen:** Tabelle `liquidations` mit `side = 'A'` (Long liquidiert), Betrag in USD, alle Coins der Tabelle außer
  PAXG.

### 4.3 Normierung
- **Zwei Zeitklassen:** *Sitzung* = reguläre NYSE-Handelszeit, 09:30–16:00 New Yorker Zeit nach dem NYSE-Kalender des Projekts
  (verkürzte Tage eingeschlossen); *außerhalb* = alles andere (Nacht, Wochenende, Feiertag). Beide Grenzen liegen auf dem
  15-min-Raster in UTC. Die Klassen gelten für beide Körbe. Ohne sie bestimmten die ruhigen Stunden außerhalb, rund vier
  Fünftel aller Minuten, das σ der Aktien, und jede gewöhnliche Bewegung in der Sitzung sähe wie ein Schock aus.
- **Varianz je Minute:** v(i, k) = (1,4826 · MAD)² / 15, MAD über die nicht überlappenden 15-min-Renditen von Instrument i,
  deren 15 Minuten ganz in Klasse k liegen, aus den 30 Tagen vor dem letzten 00:00 UTC (Quelle `nb_kerze15`). **Der laufende
  Tag geht nie ein.** Mindestens 60 Renditen je (i, k), sonst ist das Instrument in dieser Klasse ungültig.
- **σ eines Fensters:** σ(i, w, t) = √(n_S · v(i, Sitzung) + n_A · v(i, außerhalb)), mit n_S und n_A = Minuten des Fensters
  (t − w, t] in der Sitzung bzw. außerhalb. Ein Fenster, das über Börsenöffnung oder -schluss reicht, wird so mit der richtigen
  Mischung gemessen und nicht mit der Klasse seiner Endminute.
- Untergrenze: v(i, k) ≥ 0,0625 · Median der v(·, k) seiner Gruppe (also σ ≥ 0,25 · Median). Sonst erzeugen einzelne Reihen,
  die fast stillstehen, riesige z-Werte.
- Neuberechnung täglich um 00:05 UTC, gespeichert in `nb_sigma`.

### 4.4 Maße (jede Minute t, UTC)
- Fenster: W_X = {15, 60, 240} min für den Gleichlauf, W_Y = {5, 15, 60} min für Krypto allein.
- r(i, w, t) = ln P_i(t) − ln P_i(t − w), P = Mid; beide Minutenwerte müssen vorliegen.
- z(i, w, t) = r(i, w, t) / σ(i, w, t) (4.3), begrenzt auf [−20; +20].
- G(g, w, t) = Median der gültigen z(i, w, t) der Gruppe g. Der Median verlangt, dass mindestens die Hälfte der Gruppe fällt;
  ein Einzelwert, der allein abstürzt, löst nichts aus.
- **Gleichlauf** X(t) = Minimum über w ∈ W_X von max(G(K, w, t), G(A, w, t)), nur über Fenster, in denen beide Gruppen
  gültig sind. Beide Märkte müssen fallen, maßgeblich ist der schwächer fallende. Kein gültiges Fenster: X undefiniert.
- **Krypto allein** Y(t) = Minimum über w ∈ W_Y von G(K, w, t).
- **Liquidationen** Λ(t) = Perzentil der Long-Liquidationen (4.2) in (t − 15 min, t] unter den nicht überlappenden
  15-min-Summen derselben Zeitklasse aus den 30 Tagen vor dem letzten 00:00 UTC (beide Klassen zusammen 2.880 Werte):
  Λ = (Anzahl kleinerer Werte + 0,5 · Anzahl gleicher Werte) / Anzahl. Maßgeblich ist die Klasse der Minute t.

### 4.5 Stufen, Schwellen, Kalibrierung

| Stufe | Name | löst aus (eine Bedingung reicht) |
|---|---|---|
| 1 | Long-Sperre | X(t) ≤ θ1 (bei Wache θ1/2, 5.4) · Ebene B direkt (5.4, wenn scharf) · Termin (5.3) · Handbremse |
| 2 | Schock | X(t) ≤ θ2X · Y(t) ≤ θ2Y und Λ(t) ≥ 0,99 · Ebene B Schwere 3 und X(t) ≤ θ1 binnen 30 min (wenn scharf) · Handbremse „Schock“ |

Stufe 2 schließt die Wirkung von Stufe 1 ein.

**Alarmbudget (vorab):** Stufe 1 über X: 4 Episoden je 30 Tage. Stufe 2 über X: 1 je 30 Tage. Stufe 2 über Y: 1 je 30 Tage.
- **Episode:** zusammenhängende Minuten mit erfüllter Bedingung; Läufe mit weniger als 240 min Abstand zählen als eine
  Episode.
- **Verfahren:** X(t) und Y(t) (diese mit der Λ-Bedingung) über den Kalibrierungszeitraum rechnen, je Zeitpunkt mit den σ,
  die an jenem Tag gegolten hätten. θ ist der größte Wert auf dem Raster −1,50; −1,55; …; −8,00 (131 Werte), bei dem er selbst
  und alle kleineren Rasterwerte das Budget je 30 Tage einhalten. So bleibt die Wahl eindeutig, auch wenn sich eine lange
  Episode bei strengerer Schwelle in zwei teilt.
- **Klammern:** θ1 ∈ [−3,5; −1,5]; θ2X ∈ [−6,0; −2,5] und θ2X ≤ θ1 − 0,5; θ2Y ∈ [−8,0; −3,0]. Liegt ein Wert an einer
  Klammer, steht das im Bericht.
- **Startwerte** (Selbsttest, erster Start, zu wenig Daten): θ1 = −2,5; θ2X = −4,0; θ2Y = −5,0.
- **Erste Kalibrierung:** alle Daten bis 20.10.2026 23:59 UTC, damit der 22.10. ungesehen bleibt (der Abverkauf begann in der
  Nacht zum 22.10.). X auf dem 15-min-Raster aus `nb_kerze15`; Y auf den eigenen 1-min-Kerzen, also nur mit den eigenen Coins
  (der Bericht nennt ihre Zahl). Für diese erste Kalibrierung darf σ aus mindestens 10 statt 30 Tagen stammen. Liegen weniger
  als 21 Tage mit beiden Gruppen vor, gelten die Startwerte.
- **Live wird jede Minute geprüft.** Das 15-min-Raster unterschätzt die Auslöserate von X etwas; die Vorwärtszählung (11.1)
  zeigt die echte Rate.
- **Neukalibrierung** monatlich am 1. um 00:30 UTC auf den letzten 60 Tagen bis Monatsende (mindestens 21 Tage): X immer auf
  dem 15-min-Raster, Y auf dem 1-min-Raster aus `nb_preis`, für die Zeit davor aus den eigenen 1-min-Kerzen. Das Budget bleibt
  fest, die Schwellen folgen ihm. Änderungen über 0,5 stehen im Bericht.

### 4.6 Ende einer Sperre
- **Stufe 2 → 1:** frühestens 240 min nach der letzten Minute mit erfüllter Stufe-2-Bedingung.
- **Stufe 1 → 0,** wenn alle drei gelten:
  1. mindestens 120 min seit der letzten Minute mit erfüllter Bedingung für Stufe 1 oder 2, aus jeder Quelle;
  2. seit 30 min X(t) > θ1/2 und G(K, 60, t) > θ1/2, mit θ1 ohne Wache (Hysterese; ein undefinierter Wert zählt nicht
     dagegen). Bewusst nicht Y: Dessen 5-min-Fenster schlägt in unruhigen Phasen so oft an, dass eine Sperre kaum enden würde;
  3. seit 30 min Λ(t) < 0,90.
- **Handbremse:** endet zu ihrer Zeit oder per „Sperre aufheben“. Auch eine Marktsperre darf der Nutzer aufheben; danach
  60 min Ruhefenster, in dem nur eine Stufe-2-Bedingung neu auslöst.
- Keine Höchstdauer. Nach 24 h ununterbrochener Sperre trägt das Banner „seit 24 h, bitte prüfen“.

### 4.7 Spiegel (nur Protokoll)
Dieselben Maße mit umgekehrtem Vorzeichen, also ein marktweiter Aufwärtsschock, werden als mögliche „Short-Sperre“
protokolliert und im Bericht gezählt, ohne Wirkung.

## 5. Ebene B: Nachrichten und KI

### 5.1 B1 Prognosemärkte (Polymarket)
- Liste `notbremse_maerkte.json`, je Eintrag `slug`, `risiko` (die Ausgangsseite, die Risiko bedeutet, z. B. `Yes` bei einer
  Frage nach einem US-Angriff auf Iran) und `thema`.
- Kandidaten sucht `check_notbremse.py --maerkte "Iran,Hormuz,tariff,strike,war"` auf dem Pi (aktive Märkte nach
  24-h-Volumen); der Nutzer wählt aus.
- Abruf alle 5 min über die öffentliche Gamma-API von Polymarket (nur lesen, kein Konto); Erreichbarkeit vom Pi und
  Feldnamen beim Einbau an einer echten Antwort prüfen.
- **Signal B1:** Die Wahrscheinlichkeit der Risikoseite steigt binnen 60 min um mindestens 15 Prozentpunkte, bei mindestens
  50.000 USD 24-h-Volumen.

### 5.2 B2 Schlagzeilen mit KI-Einordnung
- **Quellen** (frei, ohne Schlüssel; Erreichbarkeit vom Pi prüfen): Google-News-RSS-Suchen (englisch, USA) mit festen
  Begriffen, die GDELT-DOC-API, RSS von CoinDesk und Cointelegraph für kryptoeigene Ereignisse (Börsenausfall, Hack,
  Stablecoin verliert die Bindung). Keine sozialen Medien (teuer und verrauscht, wie im Labor-Konzept entschieden).
- **Takt:** alle 5 min. Neu ist eine Schlagzeile mit unbekanntem Schlüssel aus URL und normalisiertem Titel; nur die letzten
  6 h, höchstens 40 je Lauf.
- **Vorfilter ohne KI:** Nur Schlagzeilen mit Begriffen aus einer festen Liste gehen an die KI, etwa Iran, Israel, Hormuz,
  strike, attack, missile, war, invasion, tariff, sanction, Fed, emergency, default, hack, exploit, halt, outage, depeg. Der
  Rest wird nur gezählt. Ohne neue Treffer kein Aufruf.
- **Modell:** Anthropic-API, Vorgabe `claude-haiku-5-5`, Temperatur 0, Prompt-Fassung `NB-KI-1` fest im Code. Schlüssel in
  `accesstokens.json` (Eintrag `anthropic`), nie im Log. Keine Werkzeuge, keine Websuche.
- **Ausgabe** nur als JSON nach diesem Schema, sonst ungültig:

```json
{"lage": "ruhig | angespannt | schock",
 "schwere": 0,
 "kategorie": "krieg | zoelle | notenbank | krypto_boerse | regulierung | sonstiges",
 "maerkte": ["krypto", "aktien", "oel", "gold"],
 "belege": [3, 7],
 "begruendung": "höchstens 200 Zeichen"}
```

- **Schwere:** 0 nichts; 1 Meinung, Gerücht oder Wiederholung; 2 glaubwürdige Meldung über eine mögliche, noch nicht
  eingetretene Eskalation mit Marktwirkung (z. B. ein Bericht, das Pentagon habe Angriffsoptionen vorgelegt, oder eine
  Zolldrohung mit Datum); 3 eingetretenes Ereignis mit marktweiter Tragweite (Angriff erfolgt, Meerenge geschlossen,
  Notfall-Zinsentscheid, Ausfall einer großen Börse oder eines großen Stablecoins).
- **Prüfung der Antwort:** Schema streng; `belege` müssen auf gelieferte Schlagzeilen zeigen. Unabhängige Quellen zählt das
  Programm selbst, als verschiedene Domains der Originalquellen unter den Belegen (bei Google News aus dem Feld `source`, nicht
  aus dem Weiterleitungslink). Ungültig heißt: kein Signal, Zähler „KI ungültig“.
- **Sicherheit:** Der Prompt sagt ausdrücklich, dass Schlagzeilen Daten sind und keine Anweisungen; sie gehen als JSON-Liste
  hinein. Keine Links öffnen.
- **Kosten** je Aufruf aus den Token-Zahlen der Antwort und den Preisen im Code (beim Einbau aus der Preisliste übernehmen).
  Tagesdeckel, Vorgabe 2 USD; ist er erreicht, pausiert B2 bis 00:00 UTC mit Hinweis im Banner, Ebene A läuft weiter.
- **Speicherung:** alles in `nb_ki`, damit jede Einordnung nachprüfbar ist.

### 5.3 B3 Terminkalender
- `notbremse_termine.json`, je Eintrag `name`, `start`, `ende` (UTC). Im Zeitraum gilt Stufe 1.
- Vorgabe für hochrangige US-Daten (Zinsentscheid, Verbraucherpreise, Arbeitsmarkt): 15 min vor bis 30 min nach der
  Veröffentlichung. Die Termine trägt der Nutzer ein oder die Umsetzung nach Prüfung auf dem Pi (Fed-Kalender, BLS-Plan).
  Beispiel: US-Wahlnacht 03.11.2026 23:00 bis 04.11.2026 08:00 UTC.
- B3 ist scharf, sobald ein Termin eingetragen ist. Der Nutzer entscheidet ihn selbst, deshalb gibt es keine Schattenphase.

### 5.4 Zusammenspiel mit Ebene A (gilt, sobald Ebene B scharf ist)
- **Wache** für 120 min, verlängert bei jeder neuen Bestätigung: ausgelöst durch B1 oder durch B2 mit Schwere 2. Wirkung: θ1
  wird zu θ1/2, Ebene A sperrt also schon bei halb so starkem Gleichlauf. Stufe 2 bleibt unverändert.
- **Stufe 1 direkt** für 120 min, verlängert bei jeder Bestätigung: B2 mit Schwere 3 und mindestens zwei unabhängigen
  Domains.
- **Stufe 2** löst Ebene B nie allein aus; Schwere 3 zusammen mit X(t) ≤ θ1 binnen 30 min reicht.
- Ebene B wirkt nur in Richtung Sperre. Ohne neues Signal endet die Wache nach 120 min von selbst.

### 5.5 Schattenphase
- 30 Tage lang rechnen und protokollieren B1 und B2, ohne zu wirken; auch die Wache wirkt nicht. Banner und Abschnitt zeigen
  „Ebene B (Schatten): würde jetzt …“.
- **Bericht nach 30 Tagen:** Signale je Art; Vor- oder Nachlauf in Minuten gegenüber Ebene A; Fehlalarme (Signal ohne
  X ≤ θ1/2 binnen 2 h); Einstiege der Welt A, die eine B-Sperre verhindert hätte, mit ihrem tatsächlichen Netto-Ergebnis
  (Näherung ohne Folgeeffekte, so gekennzeichnet); Kosten.
- Scharf schaltet der Nutzer per Schalter; das Datum steht im Plan.

## 6. Ebene C: Handbremse im Dashboard
- Knopf „Notbremse“ in der Kopfzeile jedes Reiters, Menü: „Longs sperren: 1 h · 4 h · 24 h · bis auf Widerruf“, „Schock
  (Stufe 2) 4 h“, „Sperre aufheben“, dazu ein freiwilliger Grund (höchstens 200 Zeichen).
- Nur per POST mit der Schutz-Kopfzeile `X-HL-Request` und Herkunftsprüfung; GET antwortet mit 405, wie seit M-5.
- Wirkt ab dem nächsten Labor-Takt und nur in Welt A; Eintrag in `nb_manuell` und `nb_zustand` mit Quelle `manuell`.

## 7. Wirkung je Stufe

### 7.1 Übersicht

| Vorgang in Welt A | Stufe 0 | Stufe 1 | Stufe 2 |
|---|---|---|---|
| Neue Long-Position zum Markt | normal | verworfen, protokolliert | verworfen |
| Long vergrößern (Nachkauf, Grid-Kauf-Los, Startbestand, Folge-Aktion, Ensemble) | normal | verworfen | verworfen |
| Neue Long-Limit-Order | normal | nicht gesetzt | nicht gesetzt |
| Offene Long-Limit-Orders | bleiben | beim Eintritt storniert | storniert |
| Füllung einer Long-Limit-Order im Sperrzeitraum (Restfall) | normal | verworfen, storniert | verworfen, storniert |
| Bestehende Longs | unverändert | unverändert | Bestandsregel 7.2 |
| Schließen, Stopp, Ziel, Zeitablauf, Notausstieg, Grid-Verkauf | normal | normal | normal |
| Shorts, Grid Short | normal | normal | normal |

### 7.2 Bestandsregel bei Stufe 2 (Varianten im Schatten)
- **V0** unverändert; gilt, bis der Nutzer nach 11.3 anders entscheidet.
- **V1** alle Longs eine Minute nach Auslösung zum Marktpreis schließen (Taker, Kosten aus der Orderbuchtiefe wie im Labor).
- **V2** jede Long-Position halbieren (Taker).
- **V3** den Stopp jeder Long-Position auf max(bisheriger Stopp; L15 · (1 − 0,5 · σ(coin, 15, t))) setzen, L15 = Tief der
  letzten 15 min; ohne bisherigen Stopp gilt der neue Wert. Liegt der Kurs schon darunter, wird zum nächsten Kurs geschlossen.
  Bei Grid Long die Notausstiegslinie auf dieselbe Höhe.
- **Rechnung je Episode** auf allen Longs der Welt A, die bei Auslösung offen waren, aus den Minutenkerzen bis Episodenende
  + 24 h: Unterschied jeder Variante zu V0 in USD, nach Gebühren.
- Warum nicht gleich V1: Ein Schocktief ist oft der schlechteste Verkaufskurs des Tages. Ob Schließen mehr spart als es
  kostet, sollen die Episoden zeigen, nicht die Annahme.

## 8. Welt A und Welt B
- **Welt B** ist das heutige TradeLabor, unverändert. Auf ihr laufen weiter U99, die Stufen der Strategien (Aufstieg) und alle
  bestehenden Berichte.
- **Welt A** ist eine zweite Instanz mit demselben Code, eigener Datei (z. B. `labor_a.db`) und aktivem Tor. Sie startet beim
  Einspielen als exakte Kopie von Welt B (offene Positionen, Orders, Zustände der Strategien) und weicht nur durch Vorgänge der
  Bremse ab.
- Den Marktzustand `E` je Takt rechnet das Labor einmal; beide Welten nutzen ihn. Zusätzliche Last entsteht nur in der
  Buchführung. Der Speicher der Labor-Tabellen verdoppelt sich; für Welt A gilt dieselbe Aufbewahrung wie für Welt B (U102).
- **Anzeige im Reiter TradeLabor:** oben „mit Notbremse X USD · ohne Y USD · Unterschied Z USD (seit TT.MM.)“, je Strategie
  eine Spalte „Unterschied“. Die Hauptzahl bleibt Welt B, bis der Nutzer umstellt (14.6).

## 9. Anzeige und Meldungen
- **Banner auf jedem Reiter** bei Stufe ≥ 1, Stufe 1 gelb, Stufe 2 rot, Zeiten in Ortszeit. Beispiel: „NOTBREMSE Stufe 2 seit
  21:14 · Gleichlauf Krypto −4,6 σ, Aktien −4,2 σ (60 min) · Long-Liquidationen 99,6. Perzentil · neue Longs gesperrt ·
  frühestens frei 01:14 · [Sperre aufheben]“. Bei veraltetem Zustand rot: „Notbremse ohne aktuelle Daten, neue Longs
  gesperrt (Welt A)“.
- **Ton** beim Wechsel auf Stufe 1 und auf Stufe 2, je ein eigener, über die bestehenden Töne der Treiber-Signale.
- **Abschnitt „Notbremse“:** G je Gruppe und Fenster, X, Y und Λ mit ihren Schwellen; Wache; Episodenliste (Start, Ende,
  Stufe, Auslöser, gesperrte Einstiege, stornierte Orders, Unterschied A − B, Varianten); Ebene B im Schatten;
  Polymarket-Liste; Kalibrierung mit Datum und Klammern.
- **Bericht „★ TradeLabor“:** Abschnitt „Notbremse“ mit denselben Zahlen als Text.

## 10. Prüfungen

### 10.1 Selbsttest `hl_notbremse.py --selbsttest` (Sandbox, synthetisch)
Synthetischer Markt: 10 Krypto- und 6 Aktieninstrumente mit gemeinsamem Faktor, t-verteilten Renditen (ν = 3) und
Tagesprofil (Aktien in der Sitzung dreimal so beweglich wie außerhalb). Die Marktproben 1–11 laufen in der Sitzung. Alle
Proben nutzen einen festen Seed und, außer Probe 15, die Startwerte der Schwellen.
1. **Gleichlauf-Schock:** alle Instrumente fallen gleichmäßig um 6 σ(15) über 15 min → in den 6 h davor Stufe 0, nach Beginn
   erst Stufe 1, Stufe 2 spätestens 16 min nach Beginn.
2. **Langsamer Abverkauf:** beide Körbe gleichmäßig −3 σ(240) über 4 h → Stufe 1, nicht Stufe 2.
3. **Einzelwert:** ein Coin −40 %, der Rest ruhig → Stufe 0.
4. **Nur Krypto:** Krypto fällt gleichmäßig um 6 σ(15) über 15 min, Aktien ruhig, Λ niedrig → Stufe 0; dasselbe mit
   Λ = 0,995 → Stufe 2.
5. **Datenlücke:** Aktien seit 150 s ohne Wert → X undefiniert, kein Auslösen, Hinweis „Aktien: keine aktuellen Daten“.
6. **Hysterese:** X pendelt 3 h um θ1 → genau eine Episode.
7. **Mindestdauer:** Stufe 2 hält mindestens 240 min nach ihrer letzten Bedingung; Stufe 1 endet frühestens 120 min nach der
   letzten Bedingung.
8. **Tor:** In Stufe 1 wird ein Markt-Long verworfen und protokolliert; kein neues Long-Limit; offene Long-Limits sind
   storniert; kein Grid-Kauf-Los. Ein Short geht durch; Stopp und Ziel eines bestehenden Longs werden ausgeführt; Verkleinern
   geht durch.
9. **Zeitpunkt des Vorgangs:** Eine Limit-Füllung, die das Labor über Kerzen nachholt und die in den Sperrzeitraum fällt, wird
   verworfen; eine Füllung eine Minute vor der Sperre bleibt.
10. **Zwei Welten:** Bis zur ersten Sperre sind A und B gleich, danach weichen sie nur durch protokollierte Vorgänge der Bremse
    ab. **Welt B ist byte-gleich mit einem Lauf ohne Bremsen-Modul.**
11. **Veraltet:** Zustand älter als 180 s → Welt A eröffnet keine Longs, Welt B unverändert.
12. **KI:** ungültiges JSON → kein Signal; Antwort mit „Stufe 0“ oder „aufheben“ → wirkungslos; Schwere 3 mit einer Domain →
    keine Sperre, mit zwei → Stufe 1 (im Schatten nur protokolliert); Schwere 2 → Wache, θ1 halbiert; Kostendeckel erreicht →
    B2 pausiert, A läuft.
13. **Polymarket:** +20 Prozentpunkte in 40 min bei 80.000 USD Volumen → Wache; bei 10.000 USD → nichts.
14. **Handbremse:** POST mit Kopfzeile → Stufe 1; GET → 405; „Sperre aufheben“ → Stufe 0, danach 60 min nur Stufe 2 möglich.
15. **Kalibrierung:** 20 Läufe ohne Schocks, je 60 Tage Kalibrierung und 60 Tage Prüfung, eigener Seed je Lauf, 15-min-Raster:
    Bei Budget 4 liegen die Stufe-1-Episoden der Prüftage im Mittel über die Läufe zwischen 3 und 6 je 30 Tage.
16. **Zeitstempel:** Alle `ts` in Sekunden; eine Millisekunden-Zeile macht den Datenbank-Audit rot.
17. **Zeitklassen:** Über 60 synthetische Tage liegt der Anteil der Minuten mit G(A, 15) ≤ θ1 in der Sitzung und außerhalb
    höchstens um den Faktor 2 auseinander; ohne Zeitklassen (Mutation) ist er in der Sitzung mehr als fünfmal so hoch. Ein
    240-min-Fenster, das 30 min nach Börsenschluss endet, hat σ = √(210 · v(Sitzung) + 30 · v(außerhalb)) (Rechnung von Hand).

### 10.2 Mutationen (je einzeln, jede muss rot werden)
Tor in `_eroeffnen` entfernt (8) · Tor in der Füllprüfung entfernt (9) · Median durch Mittelwert ersetzt (3) · σ mit dem
laufenden Tag (eigene Probe: ein Schock verändert das σ desselben Tages nicht) · Hysterese aus (6) · Mindestdauer aus (7) ·
Bremse sperrt auch Schließen (8) · Bremse sperrt auch Shorts (8) · Zustand zum aktuellen statt zum Vorgangszeitpunkt (9) ·
KI darf Stufe senken (12) · Antwort ohne Schemaprüfung (12) · veraltete Werte als gültig (5) · Welt B von der Bremse berührt
(10) · veralteter Zustand gibt frei (11) · Millisekunden statt Sekunden (16) · σ ohne Zeitklassen (17) · Fenster nur mit der
Klasse der Endminute gemessen (17) · Freigabe über Y statt G(K, 60) (eigene Probe: ein kurzes 5-min-Zucken nach 3 h Sperre
hält die Freigabe nicht auf).

### 10.3 Tor statisch prüfen
Ein Test liest `hl_labor.py` mit `ast` und prüft: Positionen entstehen nur über `_eroeffnen` (kein anderer Eintrag in
`labor_position`); `_eroeffnen` ruft das Tor auf; jeder Eintrag einer Order in `labor_order` und jeder Grid-Kauf steht hinter
`darf(...)`. Er liest den Labor-Code, nicht seinen eigenen Quelltext, und wird rot, wenn das Tor an einer Stelle fehlt. Lehre
aus dem Audit vom 22.10.: Ein Test, der nur Text sucht, findet die Zeile im Test selbst.

### 10.4 Rückblick auf dem Pi (`check_notbremse.py --rueckblick`)
- Zeitraum: Beginn der eigenen Daten bis heute, im Hintergrund (nachts), Laufzeit im Bericht.
- Mit den Schwellen der ersten Kalibrierung (Daten bis 20.10.): Episoden je Stufe und Auslöser, Anteil gesperrter Zeit,
  Labor-Rückwärtstest Welt A gegen Welt B (nur Strategien, deren Daten gespeichert sind; die Abdeckung steht im Bericht) und
  die Zerlegung des 22.10. (Abschnitt 1).
- **Empfindlichkeitstabelle** für das Budget 2, 4 und 8 Episoden je 30 Tage: θ-Werte, Episoden, Auslösezeit am 22.10. (oder
  „keine“), Unterschied A − B über den ganzen Zeitraum und am 22.10.
- **Historische Positivkontrollen** (beschreibend, nur Krypto, ohne Liquidationen): 1-min-Kerzen der Perps von
  data.binance.vision für die Coins des Korbs, die es dort gibt (Erreichbarkeit vom Pi prüfen), σ aus den 30 Tagen davor.
  Ereignisse: 10.10.2025 (Zollankündigung, Rekordliquidationen), 22.06.2025 (US-Angriffe auf iranische Atomanlagen, Sonntag),
  28.02.2026 (Beginn der US-israelischen Angriffe auf Iran, Samstag). Je Ereignis, vom Vortag 00:00 bis zum Folgetag 23:59 UTC:
  kleinstes Y und die Minute, in der Y erstmals ≤ θ1 und ≤ θ2Y lag.
- Die Wahl des Budgets ist eine Risikoentscheidung des Nutzers, kein statistisches Urteil. Vorgabe bleibt 4; eine Änderung
  wird mit Datum festgehalten und gilt für die Vorwärtsbilanz erst ab dann.

### 10.5 Bestehende Proben
`install.py --selftest` mit neuem Schritt „Notbremse“; `hl_labor.py --selbsttest` grün für Welt B wie bisher und zusätzlich
mit Welt A; Update-Probe (neuer Dienst, neue Dateien, Sicherung); Browserprobe Handy 390 px und Desktop (Banner, Menü, alle
Reiter ohne Fehler, keine Seitenbreite über dem Bildschirm); `hl_recorder.py --audit` grün.

## 11. Bewertung und Entscheidungen (vorab)

### 11.1 Vorwärtsbilanz
- **Hauptgröße:** D = Netto(A) − Netto(B) je UTC-Tag in USD, über alle Strategien, nach Gebühren und Funding, realisiert plus
  Bestand.
- **Je Episode:** D über Episode + 24 h, gesperrte Einstiege nach Strategie, stornierte Orders, V1–V3 gegen V0.
- **Laufend:** Episoden je 30 Tage gegen das Budget, also die echte Auslöserate.

### 11.2 Urteil zur Ebene A (nach 90 Tagen, frühestens nach 6 Episoden der Stufe ≥ 1)
- Mittel von D mit 90-%-Intervall aus dem stationären Blockbootstrap (mittlere Blocklänge 5 Tage, 2.000 Wiederholungen).
- Rand je Welt: schlechtester Tag, Mittel der 5 % schlechtesten Tage, größter Rückgang.
- **Empfehlung nach Regel:**
  - Rand besser (eine der drei Größen in A um mindestens 20 % besser, keine schlechter) und das Intervall von D enthält 0 oder
    liegt darüber → behalten.
  - Rand besser, aber das Intervall von D liegt ganz unter 0 → Entscheidung des Nutzers; der Bericht nennt den Preis der
    Versicherung in USD je Monat.
  - Rand nicht besser → Budget halbieren oder abschalten, Entscheidung des Nutzers.
- Kein Nachjustieren innerhalb der Runde. Was danach kommt, ist eine neue Fassung.

### 11.3 Urteil zur Bestandsregel
Nach mindestens 5 Episoden der Stufe 2 (Rückblick zählt mit, getrennt ausgewiesen): Tabelle je Episode, V1–V3 gegen V0. Eine
Variante wird nur aktiv, wenn der Nutzer sie wählt; das Datum steht im Plan.

### 11.4 Urteil zur Ebene B
Nach 30 Tagen Schatten der Bericht aus 5.5; der Nutzer schaltet scharf oder nicht.

### 11.5 Erwartung vorab
- Der Rand wird in Welt A besser. Das Mittel bleibt nahe null oder wird leicht negativ, weil Sperren verpasste Erholungen
  kosten.
- Den größten Teil dieser Kosten tragen Strategien gegen die Bewegung (Docht fangen, Kaskaden-Umkehr, Grid Long).
- Ebene B bringt bei plötzlichen Meldungen keinen Vorlauf vor Ebene A, weil der Markt schneller ist; wohl aber Wache-Zeiten
  vor Tagen wie dem 22.10.
- **Ob Ebene A allein den 22.10. erfasst hätte, ist offen.** BTC fiel um gut 3 %, gemessen an seiner üblichen Schwankung eher
  mäßig; stark war der Abverkauf vor allem bei den Tech-Aktien. Gut möglich, dass erst die Wache mit halber Schwelle ausgelöst
  hätte. Das zeigt die Empfindlichkeitstabelle (10.4) als Erstes.

## 12. Betrieb und Ausfälle

| Lage | Verhalten |
|---|---|
| Dienst steht oder Zustand älter als 180 s | Welt A eröffnet keine Longs („Notbremse veraltet“), Banner rot; Welt B unverändert |
| Aktien-Daten fehlen | X aus, Y und Λ weiter; Hinweis im Abschnitt |
| Liquidationen fehlen | Y-Pfad aus, X weiter |
| Polymarket, Nachrichten oder KI fehlen | Ebene B aus, Ebene A unverändert; Zähler im Bericht |
| KI-Kostendeckel erreicht | B2 pausiert bis 00:00 UTC |
| Neustart | Zustand und laufende Sperren aus `notbremse.db`; Welt A setzt fort |

- **Last:** je Minute rund 20 Instrumente mal 4 Fenster, vernachlässigbar. `nb_preis` hält rund 2 Mio. Zeilen
  (20 · 1.440 · 70), `nb_kerze15` wächst um rund 0,7 Mio. Zeilen im Jahr.
- **API:** zwei WebSocket-Abos ohne Gewicht, sonst höchstens 40 je Minute (3,7 % des Deckels); die Historie einmalig im
  Hintergrund-Rang.
- **Sicherung:** `notbremse.db`, `labor_a.db` und die JSON-Listen ins bestehende Backup; `update.py` sichert die neuen Dateien.

## 13. Pakete und Reihenfolge

| Nr. | Inhalt | Wann |
|---|---|---|
| **U206** | `hl_notbremse.py` mit Ebene A, Terminen (B3) und Handbremse (C), Tor, Welt A, Banner, Abschnitt, Bericht, `check_notbremse.py` (Zerlegung, Rückblick, Empfindlichkeit, Positivkontrollen) und alle Prüfungen aus Abschnitt 10 außer 12 und 13 | nächstes Paket; berührt nichts, was bis 25.10. zugesagt ist; Ziel: vor der US-Wahlnacht 03./04.11. auf dem Pi |
| **U207** | Ebene B1 und B2 im Schatten mit den Proben 12 und 13, API-Schlüssel, Kostendeckel | nach mindestens 3 Tagen stabilem U206 auf dem Pi |
| **U208** | Urteile 11.2–11.4 und Entscheidungen des Nutzers | B nach 30 Tagen, A nach 90 Tagen |
| **U209** (Vorschlag) | Verlustgrenze des Labors (Tagesrückgang vom Hoch) als zweite, unabhängige Bremse | nach U208, eigenes Konzept |

- H-2 (vor dem 10.11. fällig) wird von U206 nicht verdrängt.
- **Reihenfolge in der Sitzung für U206:** (1) Rechenkern mit Proben 1–7 und 15–17; (2) Tor und Welt A mit Proben 8–11 und
  der statischen Prüfung; (3) Handbremse und Termine mit Probe 14, Banner, Abschnitt, Browserprobe; (4) `check_notbremse.py`;
  (5) Mutationen; (6) Dokumente und Paket.
- **Dokumente in derselben Antwort:** UEBERGABE (neuer Abschnitt oben), UPDATE_PLAN (U206–U209), PROJEKTUEBERGABE (Vorschlag
  eiserne Regel 11: „Notbremse: Jeder Weg zu einer neuen oder größeren Long-Position geht durch `notbremse.darf()`; sie
  blockiert nie ein Schließen.“), README (Dienst, Knöpfe, Dateien). Version hochzählen, Prüfsumme nennen, Paket
  `hl_liq_project.zip`.
- **Nach dem Einspielen zuerst auf dem Pi:** `check_notbremse.py --zerlegung 2026-10-22` und `--rueckblick`; die Ausgaben
  gehen als Sammeldatei an die nächste Sitzung.

## 14. Entscheidungen beim Nutzer (mit Vorgabe)
1. **Alarmbudget Stufe 1:** Vorgabe 4 Episoden je 30 Tage; Wahl nach der Empfindlichkeitstabelle (10.4).
2. **Bestandsregel:** Vorgabe V0 bis zum Urteil (11.3).
3. **Ebene B scharf:** Vorgabe nach 30 Tagen Schatten.
4. **KI-Schlüssel und Kosten:** B2 braucht einen API-Schlüssel aus der Anthropic-Konsole, getrennt vom Claude-Abo und nach
   Verbrauch bezahlt. Vorgabe Tagesdeckel 2 USD. Ohne Schlüssel läuft B2 nicht, alles andere schon.
5. **Ausnahmen:** Vorgabe keine. PAXG (Gold) als möglicher sicherer Hafen erst nach dem Urteil.
6. **Hauptzahl im Reiter TradeLabor:** Vorgabe Welt B, umstellbar auf Welt A.
7. **Termine:** Vorgabe nur die US-Wahlnacht 03./04.11.; weitere trägt der Nutzer ein.

## 15. Was die Notbremse nicht kann
- **Den ersten Fall verhindern.** Sie erkennt einen Schock, wenn er im Kurs steht. Positionen, die vorher offen sind,
  verlieren den ersten Schritt, außer eine Bestandsvariante wird aktiv.
- **Sprünge zwischen zwei Minuten abfangen.** Was in Sekunden fällt, ist vor dem nächsten Takt gefallen.
- **Langsame Bärenmärkte über Wochen erkennen.** Das ist eine Regime-Frage (KONZEPT_Regime), keine Aufgabe der Bremse.
- **Nachrichten schneller lesen als der Markt.** Ihr Wert liegt in der Wache vor solchen Tagen.
- **Kostenlos sein.** Jede Sperre kostet verpasste Erholungen; wie viel, misst Welt A gegen Welt B.

## Quellen

Zum 22.10.2026:
- [Star-Advertiser (Reuters): Nasdaq −2,6 % nach Sorgen um KI-Ausgaben](https://staradvertiser.com/2026/10/22/breaking-news/nasdaq-plunges-2-6-as-ai-spending-fears-spark-tech-selloff)
- [AOL: Ausverkauf aus Iran-Sorgen und KI-Ausgaben](https://www.aol.com/articles/market-sell-off-gains-steam-150946000.html)
- [TipRanks: Krypto fällt mit den Tech-Aktien](https://www.tipranks.com/news/bitcoin-btc-crumbles-as-technology-stocks-selloff)
- [Bitcoin News Digest, 22.10.2026](https://bitcoinnewsdigest.substack.com/p/bitcoin-news-digest-october-22-2026)
- [Crypto & Finance Market Report, 22.10.2026 (Brent über 112 USD)](https://tedpillows.substack.com/p/crypto-and-finance-market-report-fad)
- [TIME: Berichte über Angriffspläne nach den Zwischenwahlen](https://time.com/article/2026/10/22/us-israel-iran-war-strikes-midterms)

Historische Positivkontrollen:
- [Boston Globe/Bloomberg, 28.02.2026, auch zu den rund 19 Mrd. USD Liquidationen im Oktober 2025](https://www.bostonglobe.com/2026/02/28/business/bitcoin-slides-below-64000-after-us-and-israel-strikes-on-iran)
- [AOL, Juni 2025](https://www.aol.com/finance/bitcoin-plummets-below-100-000-160856266.html)
