# Recherche Volatilitätsmodul: Deribit DVOL und Volatilitätsprognose (1–28 Tage)

Stand: 28.10.2026. Notation: `(Q: URL)` = Quelle. **unbestätigt** = nicht verifiziert, nur Drittquelle oder Negativbefund. **Herleitung** = eigene Rechnung/Schlussfolgerung ohne eigene Quelle.
Wichtig: Aus der Recherche-Sandbox waren www.deribit.com, docs.deribit.com, test.deribit.com und history.deribit.com per curl gesperrt (Proxy 403). Alle API-Angaben stammen aus der Dokumentation (Web-Abruf), **nicht** aus Live-Tests. Prüfliste für den Pi am Ende.

---

## Teil A – Deribit DVOL als Datenquelle

### A1 Endpunkt `public/get_volatility_index_data`

- Liefert Volatilitätsindex-Daten „formatted as candles“ (Q: https://docs.deribit.com/api-reference/market-data/public-get_volatility_index_data.md).
- Parameter, alle als Query-Parameter, alle Pflicht (Q: dieselbe URL):
  - `currency` (string), Enum `BTC, ETH, USDC, USDT, EURR` (generisches Währungs-Enum; DVOL gibt es nur für BTC/ETH, s. A2).
  - `start_timestamp`, `end_timestamp` (integer, **Millisekunden** seit Unix-Epoche).
  - `resolution` (string), nur `"1"`, `"60"`, `"3600"`, `"43200"`, `"1D"` („only some specific resolutions are supported“). Der Beschreibungstext nennt fälschlich `vix_resolution`, das Schema heißt `resolution`.
- Antwort: `result.data` = Array von Arrays mit 5 Werten `[timestamp_ms, open, high, low, close]`; `result.continuation` (integer) „to be used as the `end_timestamp` parameter on the next request“, `NULL` wenn keine Fortsetzung (Q: s. o.). Herleitung: Paginierung läuft damit rückwärts in der Zeit.
  - Widerspruch: Der Artikel „Options Data Collection“ beschreibt das Paging als „Window-based; page by advancing the timestamp boundary“ (Q: https://docs.deribit.com/articles/options-data-collection-best-practices.md). Beides am Pi testen.
- Max. Punkte pro Request: **nicht dokumentiert** (Q: Methodenseite oben; Coinbase-Spiegel https://docs.cdp.coinbase.com/api-reference/market-data/public-get_volatility_index_data.md). Trade-Historien sind auf 1000 pro Call begrenzt (Q: options-data-collection-Artikel oben); für DVOL **unbestätigt**.
- Einheit: Das REST-Beispiel zeigt Werte ≈ 0,21 mit Zeitstempeln aus 08/2020, also vor DVOL-Start (Q: Methodenseite oben). Das WebSocket-Beispiel zeigt `"volatility": 129.36` (Q: https://docs.cdp.coinbase.com/api-reference/coinbase-deribit-app-api/websocket/market-data/deribit_volatility_indexindex_name.md). Drittanbieter berichten Vol-Punkte, z. B. Höchststand 156,2 am 23.05.2021 (Q: https://hexatape.com/history/dvol/). Sehr wahrscheinlich also Vol-Punkte in % p. a.; **unbestätigt**.
- Authentifizierung: Methode ist „Public“; „Public methods can be used without authentication“; im Coinbase-Spiegel `security: []` (Q: beide Methodenseiten oben).
- Live statt Polling: WebSocket-Kanal `deribit_volatility_index.{index_name}` mit Feldern `index_name`, `timestamp` (ms), `volatility`; Notification-Enum nur `btc_usd`, `eth_usd` (Q: Coinbase-WebSocket-Seite oben). Deribit: „Use the WebSocket channel for live DVOL, the REST method for backfilling DVOL history“ (Q: options-data-collection-Artikel oben).
- Basis-URLs: Coinbase hat Deribit am 14.08.2025 übernommen (Q: https://www.theblock.co/post/366957/coinbase-completes-2-9-billion-cash-and-stock-acquisition-of-deribit). Seit der Integration am 01.10.2026 laufen Neukunden über `https://drb.coinbase.com/api/v2`, Bestandskunden weiter über `https://www.deribit.com/api/v2` (Q: https://docs.cdp.coinbase.com/coinbase-app/advanced-trade-apis/guides/derivatives/deribit-partners). Ob kontolose Public-Calls auf beiden Hosts dauerhaft offen bleiben: **unbestätigt**.
- Verwandt: `public/get_historical_volatility` liefert eine „realized volatility time series“ (Q: options-data-collection-Artikel oben). Das Schema ist widersprüchlich (Objekt `{timestamp, value}` vs. Beispiel `[timestamp, value]`), Fenster und Einheit sind nicht dokumentiert (Q: https://docs.deribit.com/api-reference/market-data/public-get_historical_volatility.md).

### A2 Währungen und Historienbeginn

- DVOL nur für **BTC und ETH**: Die Indexliste enthält `btcdvol_usdc`/`ethdvol_usdc` (Basiswerte der DVOL-Futures), aber keinen SOL- oder HYPE-DVOL (Q: Coinbase-WebSocket-Seite oben). Hypercall listet „DVOL (Deribit, Bitcoin and Ethereum options)“ (Q: https://docs.hypercall.xyz/docs/reference/vol-indices/). Deribit listet zwar lineare Optionen auf AVAX, HYPE, SOL, XRP, TRX (Q: https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy), aber einen DVOL dafür habe ich nicht gefunden (Negativbefund, **unbestätigt**).
- Start: BTC-DVOL am 31.03.2021 vorgestellt (Q: https://www.coindesk.com/markets/2021/03/31/crypto-options-giant-deribit-launches-bitcoin-volatility-index; https://insights.deribit.com/exchange-updates/deribit-launches-volatility-index/). Deribit „launched the bitcoin and ether DVOL indices in early 2021“ (Q: https://www.coindesk.com/markets/2023/05/08/ether-volatility-measure-hits-record-low). Ein genaues ETH-Startdatum ist **unbestätigt**.
- Erster Datenpunkt: laut Drittanbieter „Daily since Mar 24, 2021 for BTC and ETH“ (Q: https://hexatape.com/history/dvol/), **unbestätigt**. Tardis zeichnet den DVOL-Stream seit 01.04.2021 auf (Q: https://docs.tardis.dev/historical-data-details/deribit.md).
- DVOL-Futures: BTC-DVOL-Futures seit 27.03.2023, linear, in USDC abgerechnet (Q: https://insights.deribit.com/exchange-updates/deribit-to-launch-industrys-first-bitcoin-volatility-trading-contracts/). „ETHDVOL futures will be listed at a later stage“ (Q: https://insights.deribit.com/exchange-updates/dvol-deribit-implied-volatility-index/).

### A3 Rate-Limits (Credit-System) und Abruftakt

- Authentifiziert (pro Subaccount): Standard-Request 500 Credits, Pool 50 000, Nachfüllung 10 000/s → 20 Requests/s dauerhaft, Burst 100. Ist der Pool leer, kommt `too_many_requests` (code 10028) **und die Session wird beendet** (Q: https://docs.deribit.com/articles/rate-limits.md).
- Unauthentifiziert: Limit pro **IP**, nicht aus dem Credit-Pool; **keine Zahl dokumentiert**; bei Überschreitung Ablehnung oder Trennung (Q: dieselbe URL). „Unauthenticated requests are more likely to result in an IP ban“; „Excessive errors can result in IP banning“; Deribit bevorzugt authentifizierte Requests auch für öffentliche Daten (Q: https://docs.deribit.com/articles/api-usage-policy.md).
- Sonderfall `public/get_instruments`: 10 000 Credits, 1 Request/s, Burst 50 (Q: rate-limits.md). Laut Changelog vom 01.07.2025 dagegen per WebSocket 1 Request/10 s, Burst 5 (Q: https://docs.deribit.com/changelogs/jsonrpc.md). Die Angaben widersprechen sich.
- Empfehlungen: WebSocket statt Polling. REST für „infrequent queries (snapshots, historical data, or occasional state syncs)“, Heartbeat alle 30–60 s, max. 500 Kanäle pro Subscribe (Q: https://docs.deribit.com/articles/market-data-collection-best-practices.md; api-usage-policy.md oben). Eine konkrete Polling-Kadenz nennt Deribit **nicht**.

### A4 Methodik und Verhältnis zur realisierten Volatilität

- Whitepaper vom 31.03.2021, aktualisiert 20.03.2023 (Q: https://insights.deribit.com/exchange-updates/dvol-deribit-implied-volatility-index/):
  - Varianz-Swap-Methodik nach dem VIX-Prinzip. Expiry1 = späteste Laufzeit mit ≤ 30 Tagen, Expiry2 = früheste mit > 30 Tagen; beide müssen > 1 h gelistet sein. Zeitgewichtete Interpolation auf 30 Tage (t in Jahren), dann Wurzel.
  - Nur OTM-Optionen (Strike-Cutoff am synthetischen Forward der jeweiligen Laufzeit). Optionen mit Delta < 0,05 werden verworfen.
  - Preise: tiefengewichteter Orderbuch-Mid (DepthVolume 2 BTC/15 ETH, 5 Levels). Fallbacks: VWAP der Trades der letzten Minute, danach vergangener bzw. aktueller Mark-Preis. Spread-Filter: MinSpreadWidth 0,0025, MaxSpreadWidth 0,03, MaxSpreadBidRatio 12 %.
  - DVOL.Raw wird jede Sekunde berechnet und mit einem EMA über 240 Punkte geglättet. Parameteränderungen werden 48 h vorher angekündigt.
  - Interpretation: 30 Tage vorwärts, annualisiert. „DVOL = 90 gives an expected daily move of 4.5%“ (Faustregel ÷ 20); präzise: „divide DVOL by the square root of 365“ (= 4,71 %, Herleitung).
  - Seit 19.08.2025 gibt es lineare, in USDC abgerechnete BTC/ETH-Optionen (Q: https://nasdaq.com/press-release/deribit-introduces-linear-options-btc-and-eth-2025-08-15). Ob sie in DVOL einfließen: **unbestätigt**.
- Varianzrisikoprämie (VRP):
  - BTC, Deribit-Optionen 07/2017–12/2022: „For a one-month horizon… the BVRP averages 14%“ (Varianz-Einheiten), positiv. Im Niedrig-Vol-Regime ist sie höher als im Hoch-Vol-Regime; im Text wird eine durchschnittliche BTC-IV von 82 % genannt (Q: https://arxiv.org/html/2410.15195v2). Eine Zusammenfassung nennt 0,17 vs. 0,12 (Q: https://harbourfrontquant.substack.com/p/return-and-variance-risk-premia-in).
  - Alexander & Imeraj bauen einen Bitcoin-VIX aus über 7 Mio. Optionspreisen (03/2019–03/2020) und diskutieren die VRP; die Zahlen habe ich nicht eingesehen (Q: https://sro.sussex.ac.uk/id/eprint/91094/).
  - Momentaufnahme 20.10.2026: DVOL 38,3 vs. 14-Tage-RV 20,2 aus Tagesschlüssen, also ≈ 18 Punkte (Q: https://cryptoticker.io/en/bitcoin-price-prediction-volatility-premium-20-october-2026/). Methodisch grob, weil rückwärts gegen vorwärts verglichen wird.
  - ETH-VRP: keine Primärzahl gefunden (**unbestätigt**).
  - Herleitung: DVOL ist im Mittel ein nach oben verzerrter Schätzer der künftigen RV. Als Prognose braucht er eine Kalibrierung, und er sollte in Varianz-Einheiten (DVOL²) mit RV verglichen werden.

### A5 Nutzungsbedingungen; Nutzung aus Deutschland

- Deribit FZE Exchange Membership Terms, Version 13.08.2026 (Q: https://support.deribit.com/hc/en-us/articles/25944532191645-Deribit-Exchange-Membership-Terms-Deribit-FZE):
  - Kopf: „BY ACCESSING OR MAKING USE OF DERIBIT'S WEBSITE AND/OR SERVICES YOU EXPRESSLY ACKNOWLEDGE…“. Nach Ziff. 1.3 gilt die Nutzung als Annahme.
  - Ziff. 2.10: „The use of market data and/or derived data is for personal use only.“ Aggregieren, Weiterverkaufen, Veröffentlichen oder Weiterleiten nur mit vorheriger schriftlicher Zustimmung.
  - Ziff. 27.1(i) verbietet „systematic or automated data collection activities“ (Scraping, Data Mining, Extraktion, Harvesting). Eine ausdrückliche Ausnahme für die API gibt es nicht. Das steht in Spannung zu Deribits eigener Anleitung zur Datensammlung per API (market-data-collection-best-practices, A3). Die Auslegung ist **rechtlich nicht geprüft**.
  - Englisches Recht, Gerichtsstand ADGM; nach Ziff. 46.8 bleiben Klagen am eigenen Wohnsitz möglich.
  - Schon die Fassung vom 29.01.2021 (Art. 4.6) enthielt die Klausel „personal use only“ (Q: https://insights.deribit.com/exchange-updates/deribit-updates-terms-of-service-as-of-29-january-2021/).
- Deutschland steht nicht auf der Liste der „Restricted Jurisdictions“ (u. a. USA, Kanada, Japan, UK-Privatkunden) (Q: https://support.deribit.com/hc/en-us/articles/25944487427741-Restricted-Jurisdictions). Eine Quelle, die das bloße Lesen öffentlicher Daten aus Deutschland einschränkt, habe ich nicht gefunden (Negativbefund, **unbestätigt**). Neukunden müssen seit 01.10.2026 über Coinbase onboarden (Q: deribit-partners-Seite, A1); für kontolose Public-Calls spielt das nur eine Rolle, falls die Public-Endpunkte geschlossen werden (**unbestätigt**).

### A6 Alternativen; implizite Vol für ZEC, XMR, HYPE

- **Volmex BVIV/EVIV**: Start 20.09.2022 (Q: https://www.theblock.co/amp/post/171294/alameda-backed-volmex-labs-launches-bitcoin-and-ether-volatility-indexes-exclusive). Konstante 30 Tage, „model-free“, Daten von Deribit und OKX; GraphQL-Endpunkt `api-v2.volmex.finance/graphql` (Q: https://docs-data.volmex.finance/volmex-indices).
  - Methodikpapier vom 08.07.2026: Berechnung jede Sekunde, EWMA-Glättung mit 1–2 min Halbwertszeit. SVIV (SOL) und HYVIV (HYPE) haben 14 Tage Tenor; SOL/HYPE stammen nur aus Deribit-Daten (Q: https://volmex.finance/papers/Volmex-IV-paper.pdf).
  - Zugang über eine REST/WebSocket-Data-API; „Index data is licensed“ (Q: https://volmex.finance/indices/bviv).
  - HYVIV startete am 22.06.2026 (Q: https://volmex.finance/press/introducing-hyviv-index), einen Tag vor Deribits HYPE-Optionen. Die Datenquelle zum Start ist daher **unbestätigt**.
- **CF Benchmarks BVX/BVXS**: 30-Tage-IV aus CME-Bitcoin-Optionen. BVX etwa sekündlich, BVXS als Tageswert aus 15:30–16:00 Uhr London. Lizenz über CF Benchmarks, Start etwa 11.04.2024 (Q: https://www.businesswire.com/news/home/20240411093100/en/CF-Benchmarks-Launches-Volatility-Index-for-Bitcoin).
- **HYPE-Optionen**:
  - Derive: RFQ-basiert, Artikel vom 20.11.2025 (Q: https://insights.derive.xyz/hype-on-derive/).
  - Deribit: `HYPE_USDC`-Optionen ab 23.06.2026 09:00 UTC mit 2 Dailies, 2 Weeklies, 1 Monthly und 1 Quarterly; Schema `HYPE_USDC-DDMMMYY-STRIKE-SIDE` (Q: https://insights.deribit.com/exchange-updates/hype-derivatives-launching-on-deribit/).
  - Bybit: HYPEUSDT-Optionen ab 04.08.2026 (Q: https://www.structuredretailproducts.com/insights/84373/bybit-expands-options-offering-with-hype-contracts).
  - Eine eigene HYPE-IV ließe sich aus `mark_iv` über `public/get_book_summary_by_currency` (`currency=USDC`, `kind=option`) gewinnen. Die Einheit von `mark_iv` ist undokumentiert, ebenso ob HYPE dort erscheint (**unbestätigt**) (Q: https://docs.deribit.com/api-reference/market-data/public-get_book_summary_by_currency.md).
- **ZEC**: Keine gelisteten Vanilla-Optionen und kein IV-Index gefunden (Negativbefund, **unbestätigt**). Es gibt binäre ZEC-Preis-Ereigniskontrakte einer Organisation „KEX“ (vermutlich Kalshi, **unbestätigt**), zertifiziert am 23.06.2026 (Q: https://www.cftc.gov/IndustryOversight/IndustryFilings/TradingOrganizationProducts/61321). Coinbase Derivatives handelt ZEC-„Perp Style Futures“ ab 02.03.2026 (Q: https://www.cftc.gov/sites/default/files/filings/ptc/26/01/ptc01292638424.pdf).
- **XMR**: Weder Optionen noch IV-Index gefunden (Negativbefund, **unbestätigt**).

---

## Teil B – Prognose über 1–28 Tage und „volatile Phasen“

### B1 Evidenz: HAR vs. GARCH vs. implizite Volatilität

- **HAR schlägt GARCH**: Bitstamp 2014–2018, RV aus 10/15/30-min-Gittern. „HAR models based on realized variance perform better than GARCH models based on daily data“, am stärksten bei kurzen Horizonten. EGARCH und APARCH sind die besten GARCH-Modelle; Vergleich per MCS (Q: https://www.sciencedirect.com/science/article/pii/S0275531921001616).
- **Horizontabhängigkeit** (Bitstamp 2012–2018, 5-min-RV, Annualisierung mit √365, Wochenkomponente 7 Tage):
  - HAR-RV adj. R² 31,8 % (1 Tag), 34,6 % (1 Woche), **13,2 % (1 Monat)**.
  - Out-of-sample ist HARQ-F-J am besten (Clark-West).
  - Strukturbrüche (35 Bruchpunkte) helfen kurzfristig, bei 1–2 Monaten ist das Bild gemischt (Q: https://reading-clone.eprints-hosting.org/87932/1/R%26R_Forecasting%20the%20Volatility%20of%20Bitcoin_complete.pdf).
- **1/7/30 Tage**: Bei 1 Tag genügt HAR mit RV-Lags. Bei 30 Tagen verbessert die Modellierung von Sprüngen und Vorzeichen die Prognose signifikant (DM); positive Sprünge senken die künftige RV (Q: https://ar5iv.arxiv.org/html/1912.05228). Andere Studien finden: Große positive Renditen erhöhen die künftige BTC-Vol, auch langfristig (Q: https://ideas.repec.org/a/wly/jforec/v41y2022i3p633-652.html), und der Leverage-Effekt ist wichtiger als Sprünge (MCS, 1 Schritt) (Q: https://ideas.repec.org/a/eee/phsmap/v533y2019ics0378437119303073.html).
- **Implizite Volatilität**:
  - Hoang & Baur (J. Futures Markets 40(10), 2020): IV ist bei 1 Tag schlechter als ARMA/HAR, bei 7, 10 und 15 Tagen besser; die Kombination ist auf allen Horizonten am besten (Q: https://ideas.repec.org/a/wly/jfutmk/v40y2020i10p1584-1602.html).
  - Stündliche Deribit-ATM-IV 01/2020–06/2026: HAR + ATM-IV senkt den RMSE um 1,5–3,8 % (1/6/24 h). VRP-Proxy und 25-Delta-Skew bringen wenig (Q: https://www.sciencedirect.com/science/article/abs/pii/S1544612326013814).
  - 5-Tage-RV, 01/2023–03/2026: HAR erreicht für BTC in-sample nur adj. R² 9,3 %. DVOL ist im gemeinsamen Modell mit einem Kalshi-Signal nicht signifikant (t = 1,58), die Effekte verblassen bei 21 Tagen. OOS-R² gegenüber dem Basismodell mit Marktkontrollen: 0,126 (BTC), 0,068 (ETH) (Q: https://arxiv.org/pdf/2604.01431).
  - Andere Märkte (FX, Aktien, Anleihen): IV enthält beim Monatshorizont inkrementelle Information über die HAR-Komponenten hinaus und ist bei FX/Aktien unverzerrt (Q: https://www.sciencedirect.com/science/article/abs/pii/S0304407610000564). Größenordnung beim S&P 500, 1 Tag OOS: QLIKE 0,0428 (HAR-RV) vs. 0,0409 (HAR-RV-VIX), also −4,4 % (Herleitung aus Tabellenwerten) (Q: https://arxiv.org/html/2604.02743v2).
  - **Lücke**: Keine Studie gefunden, die DVOL bei 14 oder 28 Tagen für BTC/ETH out-of-sample mit QLIKE/MCS gegen HAR testet.
- **Altcoins**: 8 Coins (u. a. SOL, DOGE, LTC) bei 6-h-Horizont. HAR ist nur für BTC gut, ML (LightGBM, CNN-BiLSTM) ist bei Altcoins besser; unter QLIKE fällt HAR mit Sentiment aus dem MCS (Q: https://link.springer.com/article/10.1007/s10690-024-09510-6). Für ZEC, XMR und HYPE habe ich keine Studien gefunden (Negativbefund).
- **MCS-Trennschärfe**: Die MCS werden kleiner mit asymmetrischen Verlustfunktionen und einem sprungrobusten Proxy (Q: https://ideas.repec.org/a/eee/ecolet/v191y2020ics0165176519304239.html).

### B2 Kalender- und Ereigniseffekte

- **Wochenende**:
  - 2013–2019, GARCH mit Dummies: „significantly lower risk over the weekend“, höher zu Wochenbeginn, geringer im September (Q: https://researchrepository.ucd.ie/entities/publication/ea776b97-3521-4fce-8a02-c5a9939b5563).
  - CME Group (Bitstamp, Parkinson, 2020–03/2026): Die Wochenend-Vol liegt „consistently… approximately 75% of weekday levels“. Mittlere Tagesbewegung 3,10 % an Werktagen vs. 2,33 % am Wochenende (Q: https://www.cmegroup.com/articles/2026/aligning-cryptocurrency-derivatives-with-spot-markets-measuring-the-247-trading-opportunity.html).
  - Kraken stündlich, 2016–2025 (Sekundärbericht über eine MDPI-Studie, Original nicht eingesehen): Verhältnis Wochenend- zu Werktags-Vol 0,96 (2016) → 0,60 (2024) bzw. 0,64 (2025). 13:00–21:59 UTC tragen 50,6 % der täglichen RV (2022–2025) gegenüber 38,4 % (2016–2018) (Q: https://cryptoslate.com/crypto-never-closes-but-bitcoin-ethereum-xrp-and-solana-now-move-on-wall-street-time/).
  - Kaiko (Stand 06/2024): Wochenendanteil am BTC-Volumen im Vorjahr 16 % gegenüber bis zu 28 % im Jahr 2019 (Q: https://www.theblock.co/post/302705/bitcoin-sees-all-time-low-weekend-trading-levels-following-etf-approvals-kaiko).
- **Intraday und Uhrzeiten von Makrodaten** (Binance, 10 s, 2020–2022, Q: https://arxiv.org/html/2306.17095v2):
  - Aktivitätsgipfel 12:00–16:00 UTC, Spitzen zu vollen Stunden.
  - Stärkstes Muster um 12:30 UTC (US-Daten): NFP vor CPI/PPI/PCE. Fed-Statements um 18:00 UTC sind ein zweites Muster.
  - Die Muster treten vor allem 2022 auf.
- **Makrodaten**:
  - 2013–2018: BTC-Vol ist „not influenced by most scheduled US macroeconomic news announcements“; Ausnahme sind vorlaufende Indikatoren. Regulierungsnachrichten und Börsen-Hacks erhöhen die RV (Q: https://www.sciencedirect.com/science/article/pii/S0165188920301482).
  - NY Fed SR 1052 (2017–2022, 30-min-Fenster): BTC ist „orthogonal“ zu Makro- und Geldpolitik-News. Nur CPI ist auf 5 %-Niveau signifikant, und das verschwindet für 2017–2021 (Q: https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr1052.pdf?sc_lang=en).
  - FOMC, 41 Statements 01/2021–01/2026, Coinbase stündlich: Mittlere absolute Stundenrendite BTC 0,66 % → 1,25 %, ETH 0,85 % → 1,50 %, Volumen ×2,5–2,8. Gegenüber Kontrollwochen bleiben +0,44 bzw. +0,50 Prozentpunkte (Q: https://www.sciencedirect.com/science/article/abs/pii/S1544612326006021).
  - Volmex (09/2022–09/2024): CPI und Fed-Entscheid erhöhen die 1-h-Range signifikant. Die BVIV fällt danach um ≈ 0,94 (CPI) bzw. 1,32 (Fed) Punkte. Der CPI-Effekt ist bis zum 24-h-Fenster signifikant, der Fed-Effekt verblasst. Die Einheit der Range-Werte ist unklar (Q: https://volmex.finance/papers/Macroeconomic%20Announcements%20Fuel%20Volatility%20An%20In-Depth%20Analysis.pdf).
  - Herleitung: Der Effekt ist zeitvariabel und erst seit etwa 2022 deutlich.
- **Optionsverfall bei Deribit**:
  - Daily jeden Tag, Weekly jeden Freitag, Monthly am letzten Freitag des Monats, Quarterly am letzten Freitag des Quartals, jeweils 08:00 UTC (Q: https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy).
  - Lieferpreis = 30-min-TWAP des Index von 07:30 bis 08:00 UTC, Snapshot alle 4 s (Q: https://support.deribit.com/hc/en-us/articles/29734325712413-Settlement).
  - 2021–2023, 1058 Verfälle: An Tagen mit hohem ATM-Open-Interest und negativem Dealer-Gamma gibt es eine V-förmige Umkehr um 08:00 UTC (≈ −0,17 % vorher, Umkehr bis etwa 10:00 UTC). Perp- und Spotvolumen der Settlement-Börsen steigen. Die Volatilität selbst wurde nicht getestet; die RV-Kontrolle ist insignifikant (Q: https://www.sciencedirect.com/science/article/pii/S1544612326008688).
  - „Max Pain“: Bei 6 großen Verfällen von 12/2025 bis 09/2026 lag das Settlement nur einmal nahe Max Pain (Q: https://forklog.com/en/max-pain-how-options-expirations-affect-bitcoins-price/). Das spricht für Folklore.
- **Monats-/Quartalsende**: Keine belastbare Evidenz für Vol-Effekte gefunden (**unbestätigt**). Eine Studie meldet Varianz-Anomalien inklusive Quartalseffekten, Details liegen hinter einer Paywall (Q: https://ideas.repec.org/a/eee/ecofin/v79y2025ics1062940825000816.html).

### B3 „Volatile Phasen“: was gestützt ist und was Folklore

- **Gestützt: Regime existieren.**
  - „strong evidence of regime changes in the GARCH process“; MSGARCH liefert bessere 1-Tages-VaR (Q: https://ideas.repec.org/a/eee/finlet/v29y2019icp266-271.html).
  - BTC/ETH/XRP/LTC mit über 1000 GARCH-Modellen: Asymmetrie und Regimewechsel liefern bessere VaR/ES (Q: https://ideas.repec.org/a/eee/riibaf/v48y2019icp143-155.html).
  - Sprünge plus zwei Regime verbessern die Prognose, vor allem in Hoch-Vol-Phasen (Q: https://ideas.repec.org/a/eee/finlet/v47y2022ipbs1544612322000162.html).
- **Einschränkungen**:
  - Stochastic-Volatility-Modelle schlagen MSGARCH bei der 1-Schritt-Varianz; die wahrscheinlichkeitsgewichtete Kombination der Regime ist der Schwachpunkt (Q: https://arxiv.org/pdf/2401.03393).
  - Ein 4-Zustands-HMM ist das beste 1-Schritt-Dichtemodell für Renditen. Die Zustände sind aber nicht persistent, und es gibt nur 30 OOS-Punkte (Q: https://ar5iv.labs.arxiv.org/html/2011.03741).
- **Nicht gestützt (Negativbefunde)**:
  - Den *Beginn* eines Hoch-Vol-Regimes Wochen im Voraus vorherzusagen: keine OOS-Studie gefunden. Die Evidenz betrifft fast nur 1 Tag bzw. 1 Schritt.
  - Schwellenüberschreitung P(RV > Perzentil): keine kryptospezifische OOS-Studie gefunden. Ein SA-Log-HAR-Modell beansprucht bessere Erfassung extremer Vol, nennt im Abstract aber keine Zahlen (Q: https://arxiv.org/abs/2507.22409v1).
  - Vol-of-Vol als Prädiktor: kein kryptospezifischer Nachweis gefunden.
  - „Squeeze“ (Kompression → Expansion): keine begutachtete OOS-Evidenz gefunden, nur Praktikerliteratur.
- **Nächste akademische Analogie zum Squeeze**: Lange Niedrig-Vol-Phasen sagen Bankenkrisen voraus, in- und out-of-sample (211 Jahre, 60 Länder). Das gilt für Makro- und Jahreshorizonte, nicht für Wochen (Q: https://www.riskresearch.org/papers/DanielssonValenzuelaZer2015/).
- Herleitung aus der VRP-Studie in A4 (Q: https://arxiv.org/html/2410.15195v2): Eine große Spanne zwischen DVOL und RV in ruhigen Phasen ist normal und für sich kein Ausbruchssignal, weil die VRP im Niedrig-Vol-Regime höher ist.

### B4 Evaluationsmethodik

- **Patton (2011)**, J. Econometrics 160:246–256 (Q: https://scholars.duke.edu/publication/792433; https://ora.ox.ac.uk/objects/uuid:106d4ae1-12a4-4bc3-a2c6-7e22778fcd06/files/m67e5fdfa70caf400b47f48be10cd3375):
  - Rauschen im Proxy verzerrt Rankings.
  - Von 9 gängigen Verlustfunktionen sind nur MSE und QLIKE robust. QLIKE ist die einzige robuste, die nur vom standardisierten Fehler abhängt.
  - Das Ranking nach MZ-R² ist robust, die Log-Variante nicht.
- **Patton & Sheppard (2009)** (Q: https://ora.ox.ac.uk/objects/uuid:474e796d-5656-4e6b-94d3-b10125785fc5/files/mba0ba07178c0b21e3528d52e99430bd0):
  - QLIKE hat in 3 von 4 Simulationsszenarien die höchste Teststärke in DM/West-Tests; MSE-Tests sind unterdimensioniert (≈ 4 % Ablehnung bei nominal 5 %).
  - MZ-GLS hat „much better finite sample power“.
  - Newey-West mit ⌈T^{1/3}⌉ Lags; präzisere Proxies lohnen sich.
- **MCS**: Hansen, Lunde & Nason, Econometrica 79(2):453–497 (Q: https://www.econometricsociety.org/publications/econometrica/2011/03/01/model-confidence-set). Konsistentes Ranking: Hansen & Lunde 2006, J. Econometrics 131:97–121 (Q: https://ideas.repec.org:443/a/eee/econom/v131y2006i1-2p97-121.html).
- **DM mit überlappenden Horizonten**:
  - h-Schritt-Fehler folgen MA(h−1), daher Bandbreite h−1. HLN-Korrektur: DM·√((n+1−2h+h(h−1)/n)/n) (Q: https://temporalcv.readthedocs.io/en/stable/knowledge/mathematical_foundations.html).
  - Referenzen: DM 1995, JBES 13:253–263; HLN 1997, IJF 13(2):281–291 (Q: https://search.r-project.org/CRAN/refmans/forecast/html/dm.test.html).
  - Für verschachtelte Modelle (HAR vs. HAR+DVOL): Clark-West (Q: https://www.nber.org/papers/t0326) und Giacomini-White, Econometrica 74(6):1545–1578, „nested and nonnested“ (Q: https://econometricsociety.org/publications/econometrica/2006/11/01/tests-conditional-predictive-ability).
- **Fallstricke** (Herleitung, soweit nicht belegt):
  - Überlappung: Tägliche 28-Tage-Ziele teilen 27/28 Tage. Seit 03/2021 gibt es nur etwa 73 unabhängige 28-Tage-Blöcke, die Teststärke ist also gering.
  - Look-ahead: DVOL-Kerzen nur nutzen, wenn sie geschlossen sind. Perzentil-Schwellen und Parameter nur aus Vergangenheitsdaten schätzen.
  - Proxy-Rauschen, s. B5.
  - Strukturbrüche: 35 Bruchpunkte bei Shen et al. (Q: reading-clone-URL in B1); Wandel in der ETF-Ära (Q: CME/CryptoSlate in B2).

### B5 RV-Schätzer aus 30-min-OHLC für 24/7-Märkte

- **Close-to-Close-RV** (Summe der quadrierten 30-min-Log-Renditen) ist der Standard: „it is difficult to significantly beat 5-minute RV“ (31 Assets in 5 Klassen, kein Krypto) (Q: https://fds.duke.edu/db/aas/Economics/faculty/ap172/publications/324327).
  - Die asymptotische Varianz skaliert mit 2 für RV gegenüber ≈ 0,4 für die Range (Q: https://arxiv.org/html/2601.20463v1).
  - Herleitung (konstante Vol, ohne Sprünge): Der relative Standardfehler der Varianz ist ≈ √(2/M). Das ergibt ≈ 20 % für 1 Tag (M = 48), 7,7 % für 7 Tage, 5,5 % für 14 Tage und 3,9 % für 28 Tage; in Vol-Einheiten etwa die Hälfte.
- **Range-basiert, je Kerze**: Parkinson (H−L)²/ln 16, Garman-Klass, Rogers-Satchell (Q: https://arxiv.org/pdf/1202.4311).
  - Effizienz gegenüber quadrierten Renditen: Parkinson 4,9, GK 7,4, RS 6,0 (bei Drift 0).
  - RS ist driftunabhängig, Parkinson und GK setzen Drift 0 voraus. Der Log der Range-Schätzer ist ≈ normalverteilt.
  - GK gilt als „the best volatility estimator based on daily (open, high, low and close) data“ (Q: https://www.phys.sinica.edu.tw/~socioecono/econophysics2010/pdfs/MolnarPaper.pdf).
- **Realized Range**:
  - Bei kontinuierlicher Beobachtung bis zu 5× präziser als RV. Diskrete Beobachtung führt zu einem Abwärtsbias, die Korrektur läuft über λ₂,m; bei m = 10 liegt der Skalar bei ≈ 0,7, der Vorteil schrumpft also. Mikrostruktur-Rauschen deckt die Theorie nicht ab (Q: https://arxiv.org/html/2601.20463v1).
  - Martens & van Dijk (J. Econometrics 138:181–207): niedrigerer MSE als RV bei realistischem Non-Trading und Bid-Ask-Bounce; Bias-Korrektur durch Skalierung mit der mittleren Tagesrange (Q: https://repub.eur.nl/pub/11121).
- **Yang-Zhang**: σ² = σ²_O + k·σ²_C + (1−k)·σ²_RS mit k = 0,34/(1,34 + (n+1)/(n−1)) (Q: https://qf-lib.readthedocs.io/en/stable/_modules/qf_lib/common/utils/volatility/drift_independent_volatility.html).
  - Driftunabhängig, für Eröffnungssprünge konstruiert, kleinste Varianz „among all estimators with similar properties“ (Q: https://scholars.cityu.edu.hk/en/publications/drift-independent-volatility-estimation-based-on-high-low-open-an/).
  - Herleitung: Im 24/7-Markt ist Open ≈ vorheriger Close und damit σ²_O ≈ 0. YZ wird dann zur Mischung aus Open-Close- und RS-Varianz, der Kernvorteil entfällt.
- **Annualisierung mit 365 Tagen**:
  - Shen et al. annualisieren mit √365 (Q: reading-clone-URL in B1).
  - Coin Metrics nutzt √(6·24·365) bei 10-min-Sampling und unterstellt „markets trade 24 hours a day, every day of the year“ (Q: https://docs.coinmetrics.io/market-data/market-data-overview/volatility/realized-volatility).
  - Volmex-RV-Index: Faktor 365/n (Q: https://volmex.finance/papers/Volmex-Realized-Volatility-Indices.pdf). DVOL: ÷ √365 (Q: Whitepaper in A4).
- **Lücken**:
  - Coin Metrics veröffentlicht keinen Wert bei unvollständigem Fenster (Q: Coin-Metrics-Doku oben).
  - Herleitung: Bei Close-to-Close-RV enthält die Rendite über eine Lücke deren Varianz; der Schätzer ist hier robust. Bei Range-Schätzern geht die Varianz fehlender Kerzen verloren. Dann mit M/M_obs hochskalieren oder das Fenster verwerfen.

---

## Folgerungen für das Konzept (eigene Bewertung, keine Quellenfakten)

1. **Was bei 4 Wochen realistisch ist**: das *Niveau* der mittleren Vol (ruhig, normal, hoch) mit begrenzter Güte; die einzige gefundene Zahl ist ein Monats-R² von 13,2 % (in-sample, eine Studie, B1). Das *Timing* einzelner Spitzen ist nicht realistisch. Die Ausgabe sollte eine Verteilung oder Wahrscheinlichkeit sein, z. B. P(RV₂₈ > 75. Perzentil), kein Punktwert.
2. **Zielgröße**: Vorwärts-RV über genau D = 1, 7, 14 oder 28 Tage aus 30-min-Close-to-Close-Log-Renditen, σ = √(365/D · Σr²).
   - 7, 14 und 28 Tage bestehen aus ganzen Wochen. Damit ist die Wochentagsmischung konstant, und der Wochenendeffekt muss nur beim 1-Tages-Horizont modelliert werden.
   - Eine Realized Range nach Parkinson oder RS dient als Robustheitsreihe.
3. **Baselines, die ein neues Modell schlagen muss**:
   - (a) Persistenz: RV der letzten D Tage;
   - (b) Log-HAR mit Komponenten über 1, 7 und 30 Tage;
   - (c) DVOL kalibriert per rollierender MZ-Regression von log RV auf log DVOL (VRP-Korrektur);
   - (d) HAR + DVOL;
   - (e) EWMA bzw. GARCH(1,1) als Plausibilitätscheck.

   Bewertet wird primär mit QLIKE, getestet mit DM-HLN (h−1 Lags) und MCS auf 10 %-Niveau. Für BTC/ETH ist (d) der eigentliche Gegner.
4. **Daten je Coin**:
   - BTC/ETH: DVOL stündlich (`resolution=3600`) per REST nachladen, live über einen WebSocket-Kanal.
   - SOL/HYPE: eigene ATM-IV aus Deribit-`mark_iv` oder Volmex SVIV/HYVIV (Lizenz beachten).
   - ZEC/XMR: nur RV-basierte Modelle, eventuell mit BTC-DVOL als Marktfaktor (Hypothese, testen).
5. **Ereigniskalender** (FOMC, CPI, NFP, Deribit-Monats- und Quartalsverfall) als bekannte Zukunftsregressoren für 1–7 Tage und intraday.
   - Überschlag (Herleitung): Eine FOMC-Stunde addiert bei 35–50 % Jahres-Vol nur etwa 1–2 % zur 28-Tage-Varianz, also unter 1 % in Vol-Einheiten.
   - Am Tag selbst sind es dagegen +25–50 % Varianz.
6. **„Volatile Phase“ als Überschreitungswahrscheinlichkeit** definieren, z. B. RV₇ > rollierendes 80. Perzentil (nur Vergangenheitsdaten).
   - Bewertung per Brier-Score und Reliability-Diagramm gegen Klimatologie (20 %) und Persistenz.
   - HMM-/MS-Modelle und Squeeze-Merkmale nur übernehmen, wenn sie diese Baselines out-of-sample schlagen.
7. **Statistische Ehrlichkeit**: Mit etwa 73 unabhängigen 28-Tage-Fenstern sind QLIKE-Unterschiede von wenigen Prozent kaum nachweisbar. 28-Tage-Ergebnisse als vorläufig kennzeichnen. Wegen Strukturbrüchen (ETF-Ära, Wochenendeffekt) rollierende Schätzfenster von 2–3 Jahren verwenden.
8. **Abrufdisziplin und Lizenz**:
   - Ein REST-Call pro Stunde und Währung oder ein WebSocket-Abo liegt weit unter jedem plausiblen Limit.
   - Auf 10028 mit Backoff reagieren, um IP-Sperren zu vermeiden.
   - Deribit-Daten nur privat nutzen (Ziff. 2.10) und nicht ungefragt in geteilte Dashboards stellen. Volmex-Daten sind lizenzpflichtig.

## Am Pi beim ersten API-Kontakt prüfen (Sandbox hatte keinen Zugriff)

1. Erreichbarkeit ohne Konto: `GET https://www.deribit.com/api/v2/public/get_volatility_index_data?currency=BTC&start_timestamp=…&end_timestamp=…&resolution=3600`, alternativ Host `drb.coinbase.com`. HTTP-Status und Fehlerobjekt festhalten.
2. Struktur: Hat `result.data` die Form `[ts, open, high, low, close]`? Ist `result.continuation` vorhanden, und ist es int oder null?
3. Einheit: Liegen die Werte bei ≈ 30–150 (Vol-Punkte) oder bei ≈ 0,3–1,5 (Dezimal)? Mit dem aktuellen DVOL abgleichen.
4. Maximale Kerzen pro Call und Sortierreihenfolge; Semantik von `continuation` (als neues `end_timestamp`) gegenüber Fenster-Vorschub.
5. `resolution` als String oder Integer? Markiert der Zeitstempel Kerzenbeginn oder -ende? Liegen 1D-Kerzen auf 00:00 oder 08:00 UTC?
6. Frühester Datenpunkt für BTC und ETH (ab 2019 abfragen; erwartet ≈ 24.03.2021).
7. Verhalten bei `currency=SOL`, `HYPE` oder `USDC`: Fehler oder leere Antwort?
8. Lücken und Duplikate (monotone Zeitstempel, fehlende Stunden).
9. Rate-Limit-Reaktion: Code 10028, Session-Abbruch, eventuelle HTTP-Header.
10. WebSocket `deribit_volatility_index.btc_usd`: Feldnamen `index_name`, `timestamp`, `volatility` und Update-Frequenz.
11. `public/get_historical_volatility`: Format (Objekt oder Paar), Einheit, Fenster, Historientiefe.
12. `public/get_book_summary_by_currency?currency=USDC&kind=option`: Erscheinen `SOL_USDC`- und `HYPE_USDC`-Optionen? In welcher Einheit kommt `mark_iv`? Ist `underlying_price` gesetzt?
13. `public/get_time` zum Abgleich der Pi-Uhr mit der Serverzeit.
