"""
TradeLabor (23.33, Wunsch des Nutzers 27.09.2026): simulierter Handel (Paper-Trading) mit allen verarbeiteten Daten.

Kein echtes Geld, keine Order an eine Börse. Jede Strategie ist ein eigenes simuliertes Konto je Coin. Ihre Regeln werden
beim ersten Start eingefroren (Kennung name@hash der Regeln); jede spätere Änderung ergibt eine neue Kennung, die alte
bleibt mit ihrer Bilanz stehen. Damit ist jedes Ergebnis ein echter Vorwärtstest -- nichts wird rückwirkend angepasst.

Ausführung (bewusst vorsichtig gerechnet):
  Markt-Order   Mitte des 5-s-Orderbuchs (book_summary) plus halber Spread plus Marktauswirkung aus der Buchtiefe
                (kumulierte USD innerhalb 10/25/50/100 bps); ist das Buch älter als 90 s: letzter Minutenschluss mit
                Ersatz-Spread (BTC/ETH 1 bp, sonst 4 bp) und 2 bps Aufschlag
  Limit-Order   gefüllt nur, wenn eine spätere 1-min-Kerze DURCH den Preis läuft (Tief < Limit bzw. Hoch > Limit) oder der
                beste Gegenkurs den Preis unterschreitet; in der Füll-Kerze zählt danach nur noch der Stop
  Gebühren      Taker 0,045 %, Maker 0,015 % (Basisstufe Hyperliquid); Ziel = Maker, Stop, Zeit und Folge-Ausstieg = Taker
  Funding       stündlich aus ctx_bars (Longs zahlen bei positiver Rate, Shorts erhalten sie)
  Stop/Ziel     auf 1-min-Kerzen; liegen beide in derselben Kerze, gilt der Stop; Kurslücke über den Stop hinweg: Ausführung
                zum Eröffnungskurs der Kerze; die Einstiegs-Minute einer Markt-Order wird nicht geprüft (sie lag davor)
  Takt          alle 15 s; ein Signal wird zum Kurs des Taktes ausgeführt, in dem es erkannt wird

23.34 (Nutzer 29.09.):
  XMR           fünfter Coin. XMR läuft auf Hyperliquid als HIP-3-Markt: zur Protokollgebühr kommt der Anteil des Betreibers
                (0–300 %, je Markt eingestellt); angenommen 100 % = doppelte Sätze (GEB_FAKTOR). Jeder Coin zählt ab seinem eigenen
                Start (labor_zustand „coins“) -- die Tagesrendite teilt durch die Kontotage, nicht durch Laufzeit × Coins.
  Statistik     t, „Glück“, Hälften und Stufen auf BLÖCKEN: Trades einer Strategie, die im selben Block ihres Horizonts h eröffnet
                wurden (meist dasselbe Signal in mehreren Coins zugleich), zählen als EINE Beobachtung (ihr Mittel). Vorher zählte
                jeder Coin-Trade einzeln -- vier gleichzeitige Trades auf korrelierten Coins vervierfachten scheinbar den Beleg.
  Darwin v2     Eröffnungen eines Kontos der Darwin-Liste werden je Coin und Seite über 15 min aufsummiert (auch in kleinen Stücken;
                der Recorder sammelt ihre Fills seit 23.34 ohne Mindestbetrag). Vorher zählte nur, was in einem Takt zusammenkam --
                in Stücke unter 10k zerlegte Eröffnungen blieben unsichtbar. Neue Regeln = neue Kennung; die alte Bilanz bleibt stehen.
"""
import hashlib
import json
import math
import os
import random
import sqlite3
import sys
import time

import hl_adressfluss
import hl_forecast as F

COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")      # 23.34: XMR dazu (Wunsch 29.09.)
COINS_2333 = ("BTC", "ETH", "ZEC", "HYPE")        # Stand 23.33 -- Übernahme des gemeinsamen Starts bei der Umstellung auf Kontotage
NOTIONAL = 10_000.0              # USD je Trade (Vorschlag 27.09., im Dashboard angezeigt)
GEB_TAKER = 0.00045
GEB_MAKER = 0.00015
TAKT_S = 15
BUCH_MAX_ALTER = 90
KURS_FRISCH_S = 150             # älterer Kurs (Recorder steht?): keine neuen Einstiege, keine Live-Prüfung -- die Minutenkerzen holen nach
PAUSE_S = 900                   # nach einem Ausstieg wartet die Strategie im selben Coin 15 min
HEBEL = (1, 3, 5, 10)
LIQ_SCHWELLE = 0.9              # Hebel-Ansicht: liquidiert, wenn der Rückgang im Trade 90 % der Marge (1/Hebel) erreicht
EREIGNIS_TAGE = 90
ERSATZ_SPREAD_BPS = {"BTC": 1.0, "ETH": 1.0}
SIGMA_ERSATZ = {"BTC": 0.008, "ETH": 0.011, "ZEC": 0.025, "HYPE": 0.02, "XMR": 0.02}
GEB_FAKTOR = {"XMR": 2.0}       # 23.34: HIP-3-Markt -- Protokollgebühr plus Betreiberanteil (0–300 %), angenommen 100 %
DARWIN_MIN_USD = 10_000.0
DARWIN_FRISCH_S = 180           # der jüngste Fill einer Eröffnung darf höchstens so alt sein, wenn die Summe die Schwelle erreicht
DARWIN_FENSTER_S = 900          # 23.34: Eröffnungen je Konto, Coin und Seite über 15 min aufsummiert
DARWIN_EPISODE_S = 12 * 3600    # eine erkannte Eröffnung gilt bis zum Schließen, höchstens 12 h (danach darf dasselbe Konto neu auslösen)
DARWIN_AUS_ANTEIL = 0.5         # 23.34: Folge-Ausstieg erst, wenn das Konto mindestens die Hälfte der erkannten Eröffnung wieder schließt
KASKADE_Z = 2.5
KASKADE_FENSTER_S = 3600
FRISCH_S = {"preis": 90, "treiber": 1800, "familie": 1800, "prognose": 1800, "anker": 1800, "docht": 1800, "funding": 900,
            "adressstrom": 300, "kaskade": 120, "staerke": 3600, "darwin": 900, "sigma": 1800}

SCHEMA = """
CREATE TABLE IF NOT EXISTS labor_strategie (sid TEXT PRIMARY KEY, name TEXT, titel TEXT, gruppe TEXT, regeln TEXT, beschreibung TEXT,
    erstellt INTEGER, aktiv INTEGER);
CREATE TABLE IF NOT EXISTS labor_position (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, status TEXT,
    eroeffnet INTEGER, preis_ein REAL, notional REAL, menge REAL, art_ein TEXT, gebuehr_ein REAL, slip_ein REAL,
    sl REAL, tp REAL, ablauf INTEGER, grund TEXT, werte TEXT, folge TEXT, geprueft_bis INTEGER, nur_stop_bis INTEGER,
    funding REAL DEFAULT 0, funding_bis INTEGER, mae_pct REAL DEFAULT 0, mfe_pct REAL DEFAULT 0,
    geschlossen INTEGER, preis_aus REAL, art_aus TEXT, gebuehr_aus REAL, slip_aus REAL, grund_aus TEXT,
    brutto_usd REAL, netto_usd REAL, netto_pct REAL);
CREATE INDEX IF NOT EXISTS ix_lp_offen ON labor_position(status, coin);
CREATE INDEX IF NOT EXISTS ix_lp_zu ON labor_position(geschlossen);
CREATE TABLE IF NOT EXISTS labor_order (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, preis REAL,
    erstellt INTEGER, gueltig_bis INTEGER, status TEXT, grund TEXT, werte TEXT, sl_rel REAL, tp_rel REAL, sl_px REAL, tp_px REAL,
    halten_s INTEGER, geprueft_bis INTEGER, erledigt INTEGER, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_lo_offen ON labor_order(status, coin);
CREATE TABLE IF NOT EXISTS labor_ereignis (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, sid TEXT, coin TEXT, art TEXT,
    seite TEXT, preis REAL, text TEXT, netto_usd REAL, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_le_ts ON labor_ereignis(ts);
CREATE TABLE IF NOT EXISTS labor_zustand (k TEXT PRIMARY KEY, v TEXT);
"""


# ------------------------------------------------------------------------------------------------ Strategien
def _gen(name, titel, gruppe, fn, regeln, eingaben, beschreibung):
    return {"name": name, "titel": titel, "gruppe": gruppe, "fn": fn, "regeln": dict(regeln, v=1), "eingaben": eingaben,
            "beschreibung": beschreibung}


def strategien() -> list:
    """Die eingefrorenen Strategien. Jede Änderung an „regeln“ ergibt eine neue Kennung (neue Bilanz)."""
    S = []
    std = {"sl": 1.5, "tp": 2.0}
    for key, titel, treiber, h in (("wale", "Wale", "Wal-Flow 30 min", 4), ("leaderboard", "Leaderboard", "Leaderboard-Flow 60 min", 4),
                                   ("smartmoney", "Smart Money", "Smart Money (direktional)", 12), ("pool", "Pool", "Pool-Flow 4 h", 4)):
        for inv in (False, True):
            S.append(_gen(f"{key}_{'gegen' if inv else 'folgen'}", (f"Gegen {titel}" if inv else f"{titel} folgen"), "Händler", "schwelle",
                          dict(std, quelle="treiber", schluessel=treiber, schwelle=0.5, h=h, invert=inv), [f"treiber:{treiber}"],
                          f"Treiber „{treiber}“ ≥ +0,5 → {'Short' if inv else 'Long'}, ≤ −0,5 → {'Long' if inv else 'Short'}; "
                          f"Stop 1,5 σ, Ziel 2 σ, spätestens nach {h} h"))
    for inv in (False, True):
        # 23.34 (Darwin v2): fenster_s -- Eröffnungen über 15 min aufsummiert (neue Kennung; v1 zählte nur, was in einem Takt zusammenkam)
        # 23.37: liste=2 -- die Liste entsteht nach den Regeln v2 (Aufnahme streng, Verbleib großzügig, 14 T); neue Kennung, damit die
        # Bilanz nicht zwei verschiedene Listen vermischt
        S.append(_gen(f"darwin_{'gegen' if inv else 'folgen'}", "Gegen die Darwin-Liste" if inv else "Darwin-Liste live folgen", "Händler",
                      "darwin", dict(std, h=12, min_usd=DARWIN_MIN_USD, invert=inv, fenster_s=DARWIN_FENSTER_S, aus_anteil=DARWIN_AUS_ANTEIL, liste=2), ["darwin"],
                      f"Eröffnet ein Konto der Darwin-Liste im Coin netto mindestens {DARWIN_MIN_USD / 1e3:.0f}k binnen {DARWIN_FENSTER_S // 60} min "
                      f"(auch in kleinen Stücken; Schließungen dazwischen ziehen ab; der jüngste Fill höchstens {DARWIN_FRISCH_S // 60} min alt), "
                      f"{'handeln wir dagegen' if inv else 'handeln wir mit'}; je Eröffnung einmal. Ausstieg, wenn das Konto mindestens die Hälfte "
                      "davon wieder schließt, sonst Stop 1,5 σ, Ziel 2 σ, spätestens nach 12 h. Liste nach den Regeln v2 (23.37)"))
    S.append(_gen("prognose_v1", "Prognose v1", "Prognose", "prognose", dict(std, feld="p_up_v1", schwelle=0.08, h=4), ["prognose"],
                  "P(aufwärts 4 h) der Kalibrierung v1 ≥ 58 % → Long, ≤ 42 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("prognose_v2", "Prognose v2", "Prognose", "prognose", dict(std, feld="p_up_v2", schwelle=0.10, h=4), ["prognose"],
                  "P(aufwärts 4 h) des korrigierten v2 (Version ≥ 2) ≥ 60 % → Long, ≤ 40 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("empfehlung_limit", "Kauf-/Verkaufspreise der Prognose", "Prognose", "empfehlung", {"h": 12, "sl": 1.5}, ["prognose"],
                  "Bias ≥ +0,12: Kauf-Limit am empfohlenen Kaufpreis, Ziel am Verkaufspreis; Bias ≤ −0,12 umgekehrt; "
                  "Order 12 h gültig, Stop 1,5 σ(12 h), spätestens 12 h nach der Füllung"))
    for key, fam in (("grosskonten", "Großkonten-Fluss"), ("trend", "Trend lang"), ("momentum", "Momentum kurz"), ("orderfluss", "Orderfluss"),
                     ("funding", "Funding"), ("etf", "ETF"), ("analog", "Analog"), ("pool", "Pool-Konten"), ("profi", "Profi-Flow")):
        h = {"Trend lang": 24, "Momentum kurz": 1, "Orderfluss": 1, "Funding": 24, "ETF": 24, "Analog": 24}.get(fam, 4)
        S.append(_gen(f"familie_{key}", f"Familie {fam}", "Familien", "schwelle",
                      dict(std, quelle="familie", schluessel=fam, schwelle=0.35, h=h, invert=False), [f"familie:{fam}"],
                      f"Familienwert „{fam}“ ≥ +0,35 → Long, ≤ −0,35 → Short; Stop 1,5 σ, Ziel 2 σ, {h} h"))
    S.append(_gen("kaskade_umkehr", "Kaskaden-Umkehr", "Ereignisse", "kaskade", {"modus": "umkehr", "h": 4}, ["kaskade"],
                  f"Nach einer Kaskade (Kurs ≥ {KASKADE_Z:g} σ in 15 min und Liquidationen über dem 95.-Perzentil der Woche): erste "
                  "Gegenkerze binnen 30 min → Einstieg gegen die Bewegung; Stop 0,5 σ(15 min) hinter dem Extrem, Ziel halber Rücklauf, 4 h"))
    S.append(_gen("kaskade_fortsetzung", "Kaskaden-Fortsetzung", "Ereignisse", "kaskade", {"modus": "fortsetzung", "h": 2}, ["kaskade"],
                  "Dieselbe Erkennung, Einstieg sofort IN Richtung der Bewegung; Stop 1 σ(1 h), Ziel 1,5 σ(1 h), 2 h"))
    S.append(_gen("docht_fangen", "Docht fangen", "Ereignisse", "docht", {"h": 6, "abstand": 0.25, "sl": 1.0, "tp": 1.0, "min_anteil": 0.10},
                  ["docht"], "Limit-Order 0,25 σ(1 h) jenseits des nächsten großen Liquidationsclusters (ab 10 % des Stundenvolumens, "
                  "0,5–3 σ entfernt), 4 h gültig; Ziel und Stop je 1 σ(1 h), spätestens 6 h nach der Füllung"))
    S.append(_gen("magnet", "Magnet", "Ereignisse", "magnet", {"h": 12, "a_min": 0.5, "min_anteil": 0.10}, ["anker"],
                  "Heatmap-Anker |A| ≥ 0,5 mit Cluster ab 10 % des Stundenvolumens 0,5–2 σ entfernt → Einstieg Richtung Cluster, "
                  "Ziel knapp davor, Stop 1 σ(4 h), 12 h"))
    S.append(_gen("funding_extrem", "Funding-Extrem", "Ereignisse", "funding", dict(std, z=2.0, h=24), ["funding"],
                  "Funding-Rate ≥ 2 Standardabweichungen über ihrem 14-Tage-Mittel → Short, ebenso weit darunter → Long; "
                  "Stop 1,5 σ, Ziel 2 σ, 24 h"))
    S.append(_gen("ausbruch_ruhe", "Ausbruch nach Ruhe", "Ereignisse", "ausbruch", {"h": 8, "schwelle": 0.5}, ["staerke"],
                  "Stärke ≥ 0,5 (Ruhe vor dem Sturm) macht scharf; läuft der Kurs binnen 4 h 1 σ(1 h) weg, Einstieg in diese Richtung; "
                  "Stop am Ausgangspunkt, Ziel 2,5 σ(1 h), 8 h"))
    S.append(_gen("twap_druck", "TWAP-Druck", "Ereignisse", "twap", dict(std, anteil=0.02, h=4), ["adressstrom"],
                  "Netto-Fluss laufender TWAP-Aufträge der letzten 60 min ≥ 2 % des Stundenvolumens → in dieselbe Richtung; "
                  "Stop 1,5 σ, Ziel 2 σ, 4 h (wartet, bis TWAP-Trades im Adress-Strom erkannt werden)"))
    S.append(_gen("zufall", "Zufall (Kontrolle)", "Kontrolle", "zufall", dict(std, h=4, rate_h=8), [],
                  "Zufälliger Einstieg (im Schnitt alle 8 h, wenn flach), zufällige Richtung; Stop 1,5 σ, Ziel 2 σ, 4 h -- zeigt, "
                  "was Gebühren und Zufall kosten"))
    S.append(_gen("halten_long", "Halten Long (Vergleich)", "Kontrolle", "halten", {"h": 168}, [],
                  "Immer Long, alle 7 Tage neu eröffnet -- zeigt, was der Markt ohne jedes Signal gebracht hat"))
    for s in S:
        s["sid"] = s["name"] + "@" + hashlib.sha1(json.dumps(s["regeln"], sort_keys=True).encode()).hexdigest()[:8]
    return S


# ------------------------------------------------------------------------------------------------ Hilfen
def _j(x):
    return json.dumps(x, separators=(",", ":"), ensure_ascii=False, default=float)


def schema(st) -> None:
    st.executescript(SCHEMA)


def gebuehr(coin: str, satz: float) -> float:
    """Gebührensatz eines Coins: Grundsatz (Taker/Maker) mal GEB_FAKTOR (23.34: HIP-3-Märkte wie XMR mit Betreiberanteil)."""
    return satz * GEB_FAKTOR.get(coin, 1.0)


def _gegen(seite: str) -> str:
    return "short" if seite == "long" else "long"


def _uhr(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(ts)) if ts else "—"


def _auswirkung_bps(notional: float, halb_bps: float, baender: list) -> float:
    """Mittlerer Abstand zur Buchmitte in bps für eine Markt-Order: der erste Dollar am besten Kurs (halber Spread), danach
    steigt der Preis linear durch die kumulierten Tiefenbänder (USD innerhalb 10/25/50/100 bps); jenseits pauschal 150 bps."""
    b_prev, d_prev, summe, rest = max(halb_bps, 0.0), 0.0, 0.0, notional
    for b, d in baender:
        if d is None or d <= d_prev or b <= b_prev:
            continue
        seg = d - d_prev; nimm = min(rest, seg)
        summe += nimm * (b_prev + (b - b_prev) * (nimm / seg) / 2)
        rest -= nimm
        if rest <= 1e-9:
            break
        b_prev, d_prev = b, d
    if rest > 1e-9:
        summe += rest * max(150.0, b_prev)
    return summe / notional if notional > 0 else halb_bps


def taker_preis(b: dict, kauf: bool, notional: float) -> tuple:
    """(Ausführungspreis, Abstand zur Mitte in bps) einer Markt-Order."""
    halb = max(float(b.get("spread_bps") or 0.0), 0.0) / 2
    baender = b.get("kauf" if kauf else "verkauf") or []
    bps = _auswirkung_bps(notional, halb, baender) if baender else halb + 2.0
    return (b["mid"] * (1 + bps / 1e4) if kauf else b["mid"] * (1 - bps / 1e4)), bps


def buch_jetzt(con, coin: str, now: int):
    try:
        r = con.execute("SELECT ts, bid, ask, spread_bps, bid_10, ask_10, bid_25, ask_25, bid_50, ask_50, bid_100, ask_100 "
                        "FROM book_summary WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - BUCH_MAX_ALTER, now, coin)).fetchone()
    except sqlite3.Error:
        r = None
    if r and r[1] and r[2] and r[2] >= r[1]:
        bid, ask = float(r[1]), float(r[2]); mid = (bid + ask) / 2
        sp = float(r[3]) if r[3] is not None else (ask - bid) / mid * 1e4
        return {"ts": int(r[0]), "bid": bid, "ask": ask, "mid": mid, "spread_bps": sp, "quelle": "Orderbuch",
                "kauf": [(10, r[5]), (25, r[7]), (50, r[9]), (100, r[11])], "verkauf": [(10, r[4]), (25, r[6]), (50, r[8]), (100, r[10])],
                "tiefe10": (r[4] or 0) + (r[5] or 0)}
    try:
        k = con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
    except sqlite3.Error:
        k = None
    if k and k[1]:
        mid = float(k[1]); sp = ERSATZ_SPREAD_BPS.get(coin, 4.0)
        return {"ts": int(k[0]) + 60, "bid": mid * (1 - sp / 2e4), "ask": mid * (1 + sp / 2e4), "mid": mid, "spread_bps": sp,
                "quelle": "Minutenkerze (Buch fehlt)", "kauf": [], "verkauf": [], "tiefe10": None}
    return None


def kerzen(con, coin: str, t0: int, t1: int) -> list:
    """Abgeschlossene 1-min-Kerzen mit t0 <= ts < t1: (ts, open, high, low, close)."""
    try:
        return [tuple(r) for r in con.execute("SELECT ts, open, high, low, close FROM bars WHERE ts>=? AND ts<? AND coin=? ORDER BY ts",
                                              (t0, t1, coin)).fetchall() if r[4]]
    except sqlite3.Error:
        return []


def sigma_4h(con, coin: str, now: int) -> tuple:
    """(σ der 4-h-Rendite aus 15-min-Schlusskursen der letzten 7 Tage, belastbar?, σ der letzten 4 h auf derselben Skala).
    Gezielte Abfrage der 673 Rasterpunkte über den Primärschlüssel (ts, coin) statt eines Bereichs über alle Coins."""
    letzte = now // 900 * 900 - 60
    raster = [letzte - 900 * k for k in range(7 * 96, -1, -1)]
    try:
        rows = con.execute(f"SELECT ts, close FROM bars WHERE coin=? AND ts IN ({','.join('?' * len(raster))}) ORDER BY ts",
                           (coin, *raster)).fetchall()
    except sqlite3.Error:
        rows = []
    r = []; prev = None
    for ts, c in rows:
        if prev and c and prev[1] and ts - prev[0] == 900:
            r.append(math.log(c / prev[1]))
        prev = (ts, c)
    if len(r) < 96:
        return SIGMA_ERSATZ.get(coin, 0.02), False, None
    m = sum(r) / len(r); sd = math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1))
    kurz = r[-16:]; mk = sum(kurz) / len(kurz)
    sdk = math.sqrt(sum((x - mk) ** 2 for x in kurz) / max(len(kurz) - 1, 1))
    return max(sd * 4, 1e-4), True, sdk * 4


def volumen_1h(con, coin: str, now: int):
    """Median des Stundenvolumens (USD) der letzten 24 abgeschlossenen Stunden."""
    t1 = now // 3600 * 3600
    try:
        w = sorted(v for _, v in con.execute("SELECT ts/3600, SUM(volume*close) FROM bars WHERE ts>=? AND ts<? AND coin=? GROUP BY 1",
                                             (t1 - 24 * 3600, t1, coin)).fetchall() if v)
    except sqlite3.Error:
        w = []
    return w[len(w) // 2] if len(w) >= 6 else None


_LIQ_SQL = (("hl", "liquidations", "px*sz", True), ("binance", "bnc_liquidations", "notional", False), ("andere", "ext_liquidations", "notional", False))


def _liq_seite(side, hl: bool) -> str:
    return ("long" if str(side).upper().startswith("A") else "short") if hl else ("long" if str(side).lower() == "long" else "short")


def liquidationen(con, coin: str, t0: int, t1: int) -> dict:
    """USD je liquidierter Seite (long = Zwangsverkauf, short = Zwangskauf) aus Hyperliquid, Binance und den übrigen Börsen."""
    out = {"long": 0.0, "short": 0.0, "hl": 0.0, "binance": 0.0, "andere": 0.0}
    for q, tab, expr, hl in _LIQ_SQL:
        try:
            for side, usd in con.execute(f"SELECT side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? AND ts<? GROUP BY side", (coin, t0, t1)):
                usd = float(usd or 0.0); out[_liq_seite(side, hl)] += usd; out[q] += usd
        except sqlite3.Error:
            pass
    return out


def liq_schwellen(con, coin: str, now: int) -> dict:
    """Je liquidierter Seite: max(95.-Perzentil der 15-min-Summen der letzten 7 Tage, 3 × Median, 50k USD)."""
    t0 = now - 7 * 86_400; eimer = {"long": {}, "short": {}}
    for _q, tab, expr, hl in _LIQ_SQL:
        try:
            for b, side, usd in con.execute(f"SELECT ts/900, side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? GROUP BY 1, 2", (coin, t0)):
                s = _liq_seite(side, hl); eimer[s][b] = eimer[s].get(b, 0.0) + float(usd or 0.0)
        except sqlite3.Error:
            pass
    out = {}
    for seite, d in eimer.items():
        w = sorted(list(d.values()) + [0.0] * max(0, 7 * 96 - len(d)))
        out[seite] = max(w[int(0.95 * (len(w) - 1))], 3 * w[len(w) // 2], 50_000.0)
    return out


# ------------------------------------------------------------------------------------------------ Signale
def _markt(seite, grund, werte=None, **kw):
    return dict({"typ": "markt", "seite": seite, "grund": grund, "werte": werte or {}}, **kw)


def _wert(E, quelle, schluessel, now):
    d = E.get("treiber" if quelle == "treiber" else "familien") or {}
    v = d.get(schluessel)
    if not v or now - v[1] > FRISCH_S[quelle]:
        return None
    return v[0]


def sig_schwelle(S, E, coin, now, zs):
    R = S["regeln"]; v = _wert(E, R["quelle"], R["schluessel"], now)
    if v is None:
        return []
    s = R["schwelle"]
    if v >= s:
        seite = "long"
    elif v <= -s:
        seite = "short"
    else:
        return []
    if R.get("invert"):
        seite = _gegen(seite)
    return [_markt(seite, f"{R['schluessel']} {v:+.2f} (Schwelle ±{s:g})" + (" — dagegen" if R.get("invert") else ""),
                   {R["schluessel"]: round(v, 3)})]


def sig_prognose(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]
    if not P or now - P["ts"] > FRISCH_S["prognose"]:
        return []
    if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
        return []
    p = P.get(R["feld"])
    if p is None:
        return []
    d = float(p) - 0.5
    if abs(d) < R["schwelle"]:
        return []
    return [_markt("long" if d > 0 else "short", f"{'v2' if R['feld'] == 'p_up_v2' else 'v1'}: P(aufwärts 4 h) {float(p) * 100:.1f} %",
                   {"p_up": round(float(p), 4), "bias": P.get("bias")})]


def sig_empfehlung(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]; b = E["preis"]
    if not P or now - P["ts"] > FRISCH_S["prognose"] or P.get("bias") is None:
        return [{"typ": "storno", "grund": "keine frische Prognose"}]
    bias = float(P["bias"]); kp, vp = P.get("buy_px"), P.get("sell_px"); s12 = E["sigma4h"] * math.sqrt(3)
    if bias >= 0.12 and kp and kp < b["bid"]:
        tp = vp if (vp and vp > kp * 1.002) else kp * (1 + 2 * s12)
        return [{"typ": "storno", "seite": "short", "grund": "Bias jetzt bullisch"},
                {"typ": "limit", "seite": "long", "preis": float(kp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Kaufpreis {kp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    if bias <= -0.12 and vp and vp > b["ask"]:
        tp = kp if (kp and kp < vp * 0.998) else vp * (1 - 2 * s12)
        return [{"typ": "storno", "seite": "long", "grund": "Bias jetzt bärisch"},
                {"typ": "limit", "seite": "short", "preis": float(vp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Verkaufspreis {vp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    return [{"typ": "storno", "grund": "Bias neutral oder Preis schon überschritten"}]


def sig_darwin(S, E, coin, now, zs):
    R = S["regeln"]; inv = R.get("invert"); akts = []
    for f in (E.get("darwin") or {}).get("neu", []):
        kurz = f"{f['addr'][:6]}…{f['addr'][-4:]}"
        if f["art"] == "auf" and f["usd"] >= R["min_usd"]:
            stuecke = (f" in {f['n']} Fills über {max(1, round((f['ts'] - f.get('seit', f['ts'])) / 60))} min" if (f.get("n") or 1) > 1 else "")
            akts.append(_markt(_gegen(f["seite"]) if inv else f["seite"],
                               f"Darwin #{f.get('rang') or '?'} {kurz} eröffnet {f['seite']} ({f['usd'] / 1e3:.0f}k{stuecke}, Ø {f['px']:.6g})"
                               + (" — wir handeln dagegen" if inv else ""),
                               {"konto": f["addr"], "usd": round(f["usd"]), "rang": f.get("rang"), "fills": f.get("n")},
                               folge={"addr": f["addr"], "seite_konto": f["seite"]}, h=R["h"]))
        elif f["art"] == "zu":
            anteil = (f" ({f['usd'] / 1e3:.0f}k von {f['von_usd'] / 1e3:.0f}k)" if f.get("von_usd") else "")
            akts.append({"typ": "folge_aus", "addr": f["addr"], "seite_konto": f["seite"], "grund": f"Darwin-Konto {kurz} schließt {f['seite']}{anteil}"})
    return akts


def sig_kaskade(S, E, coin, now, zs):
    K = E.get("kaskade") or {}; R = S["regeln"]; b = E["preis"]
    if not K.get("aktiv") or zs.get("kaskade_id") == K.get("id"):
        return []
    ab = K["richtung"] == "ab"
    if R["modus"] == "fortsetzung":
        zs["kaskade_id"] = K["id"]
        s1 = E["sigma1h"]; p = b["mid"]
        return [_markt("short" if ab else "long",
                       f"Kaskade {'abwärts' if ab else 'aufwärts'} {K.get('z_start') or 0:+.1f} σ in 15 min, {(K.get('liq_usd') or 0) / 1e6:.2f} Mio "
                       "liquidiert — mit der Bewegung", {"z": K.get("z_start"), "liq": round(K.get("liq_usd") or 0)},
                       sl_px=p * (1 + s1) if ab else p * (1 - s1), tp_px=p * (1 - 1.5 * s1) if ab else p * (1 + 1.5 * s1),
                       h=R["h"], halten_s=R["h"] * 3600)]
    if now - K["t"] > 1800:
        return []
    k = E.get("kerze")
    if not k or k[0] < K["t"] // 60 * 60:
        return []
    s15 = E["sigma15"]; ext = K["extrem"]
    if ab and k[4] > k[1] and k[4] >= ext * (1 + 0.25 * s15):
        tp = ext + 0.5 * (K["p_start"] - ext); zs["kaskade_id"] = K["id"]
        if tp <= b["ask"]:
            return []
        return [_markt("long", f"Gegenkerze nach der Kaskade (Tief {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"tief": ext, "start": K["p_start"]}, sl_px=ext * (1 - 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    if not ab and k[4] < k[1] and k[4] <= ext * (1 - 0.25 * s15):
        tp = ext - 0.5 * (ext - K["p_start"]); zs["kaskade_id"] = K["id"]
        if tp >= b["bid"]:
            return []
        return [_markt("short", f"Gegenkerze nach dem Squeeze (Hoch {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"hoch": ext, "start": K["p_start"]}, sl_px=ext * (1 + 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    return []


def sig_docht(S, E, coin, now, zs):
    """Limit knapp jenseits des nächsten großen Clusters. Eine liegende Order bleibt, solange ihr Cluster im Snapshot steht --
    auch wenn der Kurs schon näher als 0,5 σ herangelaufen ist (genau dann soll sie ja gefüllt werden)."""
    D = E.get("docht") or {}; R = S["regeln"]; s1 = E["sigma1h"]; akts = []
    bestehend = {seite: preis for seite, preis in zs.get("_orders", [])}
    for seite, key in (("long", "unten"), ("short", "oben")):
        alle = [c for c in (D.get(key + "_alle") or []) if c["anteil"] >= R["min_anteil"]]
        alt = bestehend.get(seite)
        if alt:
            c_alt = alt / (1 - R["abstand"] * s1) if seite == "long" else alt / (1 + R["abstand"] * s1)
            if any(abs(math.log(c["px"] / c_alt)) <= 0.5 * s1 for c in alle):
                continue
        neu = [c for c in alle if 0.5 <= c["sigma"] <= 3.0]
        c = min(neu, key=lambda c_: c_["sigma"]) if neu else None
        if not c:
            if alt:
                akts.append({"typ": "storno", "seite": seite, "grund": "Cluster nicht mehr im Snapshot"})
            continue
        preis = c["px"] * (1 - R["abstand"] * s1) if seite == "long" else c["px"] * (1 + R["abstand"] * s1)
        akts.append({"typ": "limit", "seite": seite, "preis": preis, "gueltig_s": 4 * 3600, "sl_rel": R["sl"] * s1, "tp_rel": R["tp"] * s1,
                     "halten_s": R["h"] * 3600, "toleranz": 0.25 * s1,
                     "grund": f"{'Long' if seite == 'long' else 'Short'}-Liquidationscluster {c['usd'] / 1e6:.2f} Mio bei {c['px']:.6g} "
                              f"({c['anteil'] * 100:.0f} % des Stundenvolumens, {c['sigma']:.1f} σ)",
                     "werte": {"cluster": c["px"], "usd": round(c["usd"]), "anteil": round(c["anteil"], 3)}})
    return akts


def sig_magnet(S, E, coin, now, zs):
    A = E.get("anker") or {}; R = S["regeln"]; a = A.get("A")
    if a is None or abs(a) < R["a_min"] or not A.get("ts") or now - A["ts"] > FRISCH_S["anker"]:
        return []
    dom = A.get("oben") if a > 0 else A.get("unten")
    if not dom or dom["anteil_volumen"] < R["min_anteil"] or not (0.5 <= dom["abstand_sigma"] <= 2.0):
        return []
    s1 = E["sigma1h"]; p = E["preis"]["mid"]
    return [_markt("long" if a > 0 else "short",
                   f"Anker A {a:+.2f}: Cluster {dom['usd'] / 1e6:.2f} Mio bei {dom['px']:.6g} ({dom['abstand_sigma']:.1f} σ, "
                   f"{dom['anteil_volumen'] * 100:.0f} % des Stundenvolumens)", {"A": a, "cluster": dom["px"]},
                   sl_px=p * (1 - E["sigma4h"]) if a > 0 else p * (1 + E["sigma4h"]),
                   tp_px=dom["px"] * (1 - 0.1 * s1) if a > 0 else dom["px"] * (1 + 0.1 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_funding(S, E, coin, now, zs):
    f = E.get("funding"); R = S["regeln"]
    if not f or f.get("z") is None or now - f["ts"] > FRISCH_S["funding"]:
        return []
    if abs(f["z"]) < R["z"]:
        return []
    return [_markt("short" if f["z"] > 0 else "long", f"Funding {f['rate'] * 100:.4f} %/h, z {f['z']:+.1f} gegenüber 14 Tagen",
                   {"rate": f["rate"], "z": round(f["z"], 2)})]


def sig_ausbruch(S, E, coin, now, zs):
    R = S["regeln"]; w = (E.get("staerke") or {}).get("wert"); b = E["preis"]; s1 = E["sigma1h"]
    arm = zs.get("scharf")
    if arm and now - arm["t"] > 4 * 3600:
        zs.pop("scharf", None); arm = None
    if not arm:
        if w is not None and w >= R["schwelle"]:
            zs["scharf"] = {"t": now, "p": b["mid"], "w": round(w, 2)}
        return []
    d = math.log(b["mid"] / arm["p"]) / max(s1, 1e-6)
    if abs(d) < 1.0:
        return []
    zs.pop("scharf", None)
    return [_markt("long" if d > 0 else "short", f"Ausbruch {d:+.1f} σ(1 h) seit {_uhr(arm['t'])} (Stärke {arm['w']:.2f})",
                   {"ausgang": arm["p"], "staerke": arm["w"]}, sl_px=arm["p"],
                   tp_px=arm["p"] * (1 + 2.5 * s1) if d > 0 else arm["p"] * (1 - 2.5 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_twap(S, E, coin, now, zs):
    A = E.get("adressstrom") or {}; R = S["regeln"]; w = A.get("tw_anteil")
    if w is None or not A.get("ts") or now - A["ts"] > FRISCH_S["adressstrom"] or abs(w) < R["anteil"]:
        return []
    return [_markt("long" if w > 0 else "short", f"TWAP-Netto 60 min {A['tw_netto_h'] / 1e6:+.2f} Mio = {w * 100:+.1f} % des Stundenvolumens",
                   {"tw_netto": round(A["tw_netto_h"]), "anteil": round(w, 4)})]


def sig_zufall(S, E, coin, now, zs):
    R = S["regeln"]; dt = max(1, min(now - int(zs.get("_t_letzt", now - TAKT_S)), 3600)); zs["_t_letzt"] = now
    rng = random.Random(f"{S['sid']}|{coin}|{now}")
    if rng.random() < min(1.0, dt / (R["rate_h"] * 3600)):
        return [_markt("long" if rng.random() < 0.5 else "short", "Zufall (Kontrolle)")]
    return []


def sig_halten(S, E, coin, now, zs):
    return [_markt("long", "Vergleich: immer Long", h=168, halten_s=168 * 3600)]


def status_text(S, E, now, zs) -> str:
    """Was die Strategie in diesem Takt sieht -- für die Live-Tafel (Wert gegen Schwelle, fehlende Daten, scharf/ruhig)."""
    R = S["regeln"]; fn = S["fn"]
    if fn == "schwelle":
        v = _wert(E, R["quelle"], R["schluessel"], now)
        return "keine frischen Werte" if v is None else f"{v:+.2f} (Schwelle ±{R['schwelle']:g})"
    if fn in ("prognose", "empfehlung"):
        P = E.get("prognose")
        if not P or now - P["ts"] > FRISCH_S["prognose"]:
            return "keine frische Prognose"
        if fn == "empfehlung":
            return "Bias —" if P.get("bias") is None else f"Bias {float(P['bias']):+.2f} (Schwelle ±0,12)"
        if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
            return "v2 noch nicht scharf (Version < 2)"
        p = P.get(R["feld"])
        return "—" if p is None else f"P(aufwärts) {float(p) * 100:.1f} % (Schwelle {50 - R['schwelle'] * 100:.0f} / {50 + R['schwelle'] * 100:.0f} %)"
    if fn == "darwin":
        D = E.get("darwin") or {}; su = D.get("summen") or {}
        top = max(su.values()) if su else 0.0
        return (f"{len(D.get('konten') or [])} Konten im Blick" + (f" · größte Eröffnung in {R.get('fenster_s', DARWIN_FENSTER_S) // 60} min "
                f"{top / 1e3:.1f}k (Schwelle {R['min_usd'] / 1e3:.0f}k)" if top else "") + (f", {len(D['neu'])} neue Trades" if D.get("neu") else ""))
    if fn == "kaskade":
        K = E.get("kaskade") or {}
        if K.get("aktiv"):
            return f"Kaskade {'abwärts' if K.get('richtung') == 'ab' else 'aufwärts'} seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}"
        return "keine Kursdaten" if K.get("z") is None else f"ruhig: 15 min {K['z']:+.1f} σ (Schwelle ±{KASKADE_Z:g})"
    if fn == "docht":
        D = E.get("docht") or {}
        t = [f"{'unten' if k == 'unten' else 'oben'} {D[k]['px']:.6g} ({D[k]['anteil'] * 100:.0f} %)" for k in ("unten", "oben") if D.get(k)]
        return ("Cluster " + ", ".join(t)) if t else "kein Cluster ≥ 10 % des Stundenvolumens in 0,5–3 σ"
    if fn == "magnet":
        A = E.get("anker") or {}
        return "kein Anker" if A.get("A") is None else f"A {A['A']:+.2f} (Schwelle ±{R['a_min']:g})"
    if fn == "funding":
        f = E.get("funding")
        return "keine Funding-Daten" if not f else (f"z {f['z']:+.1f} (Schwelle ±{R['z']:g})" if f.get("z") is not None else "Statistik im Aufbau")
    if fn == "ausbruch":
        a = zs.get("scharf")
        if a:
            return f"scharf seit {_uhr(a['t'])} bei {a['p']:.6g}"
        w = (E.get("staerke") or {}).get("wert")
        return "keine Stärke-Werte" if w is None else f"Stärke {w:.2f} (Schwelle {R['schwelle']:g})"
    if fn == "twap":
        w = (E.get("adressstrom") or {}).get("tw_anteil")
        return "wartet auf den Adress-Strom" if w is None else f"TWAP-Netto {w * 100:+.2f} % Vol. (Schwelle ±{R['anteil'] * 100:g} %)"
    if fn == "zufall":
        return f"zufällig, im Schnitt alle {R['rate_h']} h"
    if fn == "halten":
        return "immer Long"
    return ""


SIGNALE = {"schwelle": sig_schwelle, "darwin": sig_darwin, "prognose": sig_prognose, "empfehlung": sig_empfehlung, "kaskade": sig_kaskade,
           "docht": sig_docht, "magnet": sig_magnet, "funding": sig_funding, "ausbruch": sig_ausbruch, "twap": sig_twap,
           "zufall": sig_zufall, "halten": sig_halten}


# ------------------------------------------------------------------------------------------------ Engine
POS_SPALTEN = ("id", "sid", "coin", "seite", "eroeffnet", "preis_ein", "notional", "menge", "gebuehr_ein", "sl", "tp", "ablauf",
               "geprueft_bis", "nur_stop_bis", "funding", "funding_bis", "mae_pct", "mfe_pct", "folge")


class Labor:
    def __init__(self, db: str, store: str | None = None, coins=COINS, notional: float = NOTIONAL, adressfluss: str | None = None,
                 nur: tuple | None = None):
        self.db = db; self.store = store or F.STORE; self.coins = tuple(coins); self.notional = float(notional)
        self.af_pfad = adressfluss or os.path.join(os.path.dirname(os.path.abspath(db)), "adressfluss.db")
        self.strategien = [s for s in strategien() if not nur or s["name"] in nur]
        self.nach_sid = {s["sid"]: s for s in self.strategien}
        self.cache: dict = {}; self.letzte: dict = {}; self.fehler: list = []; self.zyklen = 0; self.dauer = 0.0; self.t_letzt = None
        self._registriert = False
        self.z = None; self._z_txt = None          # Zustand im Speicher; in den Speicher geschrieben nur bei Änderung (Schreiblast)
        self.status: dict = {}                     # (sid, coin) -> was die Strategie in diesem Takt sieht (nur Anzeige)
        self.darwin_log: list = []                 # die letzten erkannten Darwin-Trades (nur Anzeige im Datenfluss)
        self.coin_start: dict = {}                 # 23.34: Start je Coin (labor_zustand „coins“), gesetzt beim Registrieren

    # --- Verbindungen, Zustand, Protokoll
    def _con(self):
        return sqlite3.connect(f"file:{self.db}?mode=ro", uri=True, timeout=10)

    def _st(self):
        st = F.store_connect(self.store); schema(st)
        return st

    def _gecacht(self, key, ttl, now, fn):
        e = self.cache.get(key)
        if e and 0 <= now - e[0] < ttl:
            return e[1]
        v = fn(); self.cache[key] = (now, v)
        if len(self.cache) > 400:                  # Schlüssel mit Zeitstempel (Treiber-, Heatmap-Stand) laufen sonst auf
            for k in [k for k, e_ in self.cache.items() if now - e_[0] > 7200]:
                self.cache.pop(k, None)
        return v

    def _fehler(self, text):
        self.fehler = (self.fehler + [f"{time.strftime('%d.%m. %H:%M:%S')} {text}"])[-20:]

    def _zustand(self, st) -> dict:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
        try:
            z = json.loads(r[0]) if r and r[0] else {}
        except ValueError:
            z = {}
        z.setdefault("s", {}); z.setdefault("k", {})
        for k_ in ("darwin_tids", "darwin_ep"):
            if not isinstance(z.get(k_), dict):
                z[k_] = {}
        return z

    def _zustand_speichern(self, st, z, now) -> None:
        """Nur Bleibendes (Pausen, Kaskaden, scharfe Ausbrüche, gesehene Darwin-Schließungen, laufende Darwin-Eröffnungen), nur bei
        Änderung. Schlüssel mit Unterstrich sind flüchtig (z. B. der letzte Zufallstakt)."""
        z["darwin_tids"] = {k: t for k, t in z["darwin_tids"].items() if t >= now - 2 * DARWIN_FENSTER_S}   # länger als das Fenster
        z["darwin_ep"] = {k: e for k, e in z["darwin_ep"].items() if isinstance(e, dict) and int(e.get("t", 0)) >= now - DARWIN_EPISODE_S}
        s_ = {}
        for k, v in z["s"].items():
            w = {kk: vv for kk, vv in v.items() if not kk.startswith("_") and not (kk == "pause_bis" and vv < now)}
            if w:
                s_[k] = w
        txt = _j({"s": s_, "k": z["k"], "darwin_tids": z["darwin_tids"], "darwin_ep": z["darwin_ep"], "aufgeraeumt": z.get("aufgeraeumt", 0)})
        if txt != self._z_txt:
            st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('zustand', ?)", (txt,))
            self._z_txt = txt

    def _registrieren(self, st, now) -> None:
        if self._registriert:
            return
        for s in self.strategien:
            st.execute("INSERT OR IGNORE INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)",
                       (s["sid"], s["name"], s["titel"], s["gruppe"], _j(s["regeln"]), s["beschreibung"], now))
            st.execute("UPDATE labor_strategie SET aktiv=CASE WHEN sid=? THEN 1 ELSE 0 END WHERE name=?", (s["sid"], s["name"]))
        neu_start = not st.execute("SELECT 1 FROM labor_zustand WHERE k='start'").fetchone()
        if neu_start:
            st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(now),))
        self.coin_start = coin_starts(st, self.coins, now, schreiben=True)
        self._registriert = True

    def _ereignis(self, st, t, sid, coin, art, seite, preis, text, netto=None, pos_id=None) -> None:
        st.execute("INSERT INTO labor_ereignis (ts, sid, coin, art, seite, preis, text, netto_usd, pos_id) VALUES (?,?,?,?,?,?,?,?,?)",
                   (int(t), sid, coin, art, seite, preis, text, netto, pos_id))

    # --- Eingangsdaten
    def eingaben(self, con, st, coin: str, now: int, z: dict) -> dict:
        E = {"coin": coin, "now": now, "preis": buch_jetzt(con, coin, now)}
        s = self._gecacht((coin, "sigma"), 900, now, lambda: sigma_4h(con, coin, now))
        E["sigma4h"], E["sigma_ok"], E["sigma_real4h"] = s
        E["sigma1h"] = E["sigma4h"] / 2; E["sigma15"] = E["sigma4h"] / 4
        E["vol1h"] = self._gecacht((coin, "vol"), 900, now, lambda: volumen_1h(con, coin, now))
        k = kerzen(con, coin, now // 60 * 60 - 20 * 60, now // 60 * 60)
        E["kerze"] = k[-1] if k else None; E["kerzen20"] = k
        try:                                   # Prognose und Treiber tragen denselben Zeitstempel; Index (coin, ts) der Prognosetabelle
            t_fc = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3 * 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_fc = None

        def _treib():
            d = {}
            try:
                for n, sc, t in st.execute("SELECT name, score, ts FROM forecast_drivers WHERE ts>=? AND ts<=? AND coin=?", (now - 3 * 3600, now, coin)):
                    if sc is not None and (n not in d or t > d[n][1]):
                        d[n] = (float(sc), int(t))
            except sqlite3.Error:
                pass
            return d
        E["treiber"] = self._gecacht((coin, "treiber", t_fc), 3600, now, _treib)

        def _prog():
            try:
                r = st.execute("SELECT ts, bias, p_up, buy_px, sell_px, json_extract(payload,'$.p_up_v2'), json_extract(payload,'$.kalib2.version'), "
                               "json_extract(payload,'$.p_up_v1') FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                               (coin, now - 3 * 3600, now)).fetchone()
            except sqlite3.Error:
                r = None
            return {"ts": int(r[0]), "bias": r[1], "p_up": r[2], "buy_px": r[3], "sell_px": r[4], "p_up_v2": r[5], "v2_version": r[6],
                    "p_up_v1": r[7] if r[7] is not None else r[2]} if r else None
        E["prognose"] = self._gecacht((coin, "prognose", t_fc), 3600, now, _prog)
        import hl_familien as H
        fam = {}
        for f, d in H.FAMILIEN.items():
            if d.get("live") or d["art"] == "staerke":
                continue
            w = [E["treiber"][n] for n in d["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
            fam[f] = (sum(x[0] for x in w) / len(w), min(x[1] for x in w), len(w)) if w else None
        try:
            r = st.execute("SELECT value, ts FROM familien_log WHERE coin=? AND familie='Profi-Flow' AND slot<=? ORDER BY slot DESC LIMIT 1",
                           (coin, now // 900)).fetchone()
            r = r if r and now - 1800 <= int(r[1]) <= now else None
            fam["Profi-Flow"] = (float(r[0]), int(r[1]), 1) if r and r[0] is not None else None
        except sqlite3.Error:
            fam["Profi-Flow"] = None
        E["familien"] = fam
        mit = [abs(E["treiber"][n][0]) for n in H.FAMILIEN["Stärke"]["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
        ruhe = None
        if E["sigma_real4h"] is not None and E["sigma_ok"]:
            ruhe = min(1.0, max(0.0, 1 - E["sigma_real4h"] / E["sigma4h"])); mit.append(ruhe)
        E["staerke"] = {"wert": (sum(mit) / len(mit)) if mit else None, "ruhe": ruhe, "n": len(mit)}
        E["kaskade"] = self._kaskade(con, st, coin, now, E, z)

        try:
            t_hm = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_hm = None

        def _anker():
            try:
                import hl_anker
                return hl_anker.jetzt(con, coin, now)
            except Exception as e:
                return {"fehler": f"{type(e).__name__}: {e}"}
        E["anker"] = self._gecacht((coin, "anker", t_hm), 1800, now, _anker)     # neu nur mit neuem Heatmap-Stand (alle 10 min)
        E["docht"] = self._docht(con, coin, now, E, t_hm)
        E["funding"] = self._funding(con, coin, now)
        E["darwin"] = self._darwin(con, st, coin, now, z)
        E["adressstrom"] = self._gecacht((coin, "af"), 120, now, lambda: hl_adressfluss.lesen(self.af_pfad, coin, now, E.get("vol1h")))
        return E

    def _kaskade(self, con, st, coin, now, E, z) -> dict:
        b = E["preis"]; k = E["kerzen20"]; zst = dict(z["k"].get(coin) or {})
        info = {"z": None, "liq": None, "schwelle": None}
        if not b or not k:
            return dict(zst, **info, aktiv=bool(zst.get("aktiv")))
        alt = [x for x in k if x[0] <= now // 60 * 60 - 15 * 60]
        p15 = alt[-1][4] if alt else k[0][1]
        zz = math.log(b["mid"] / p15) / max(E["sigma15"], 1e-6) if p15 else 0.0
        liq = liquidationen(con, coin, now - 900, now + 1)
        thr = self._gecacht((coin, "liqthr"), 3600, now, lambda: liq_schwellen(con, coin, now))
        info.update(z=round(zz, 2), liq=liq, schwelle=thr)
        if zst.get("aktiv"):
            nach = [x for x in k if x[0] >= zst["t"] // 60 * 60]
            if zst["richtung"] == "ab":
                zst["extrem"] = min([zst["extrem"], b["mid"]] + [x[3] for x in nach])
            else:
                zst["extrem"] = max([zst["extrem"], b["mid"]] + [x[2] for x in nach])
            if now - zst["t"] > KASKADE_FENSTER_S:
                zst["aktiv"] = False
        else:
            letzte = [x for x in k if x[0] >= now // 60 * 60 - 15 * 60]
            for richtung, bed, seite_liq in (("ab", zz <= -KASKADE_Z, "long"), ("auf", zz >= KASKADE_Z, "short")):
                if bed and liq[seite_liq] >= thr[seite_liq]:
                    ext = min([b["mid"]] + [x[3] for x in letzte]) if richtung == "ab" else max([b["mid"]] + [x[2] for x in letzte])
                    zst = {"aktiv": True, "id": now, "t": now, "richtung": richtung, "p_start": p15, "z_start": round(zz, 2),
                           "liq_usd": liq[seite_liq], "extrem": ext}
                    self._ereignis(st, now, None, coin, "kaskade", "short" if richtung == "ab" else "long", b["mid"],
                                   f"{'Kaskade abwärts' if richtung == 'ab' else 'Squeeze aufwärts'} erkannt: {zz:+.1f} σ in 15 min, "
                                   f"{liq[seite_liq] / 1e6:.2f} Mio {'Long' if richtung == 'ab' else 'Short'}-Liquidationen "
                                   f"(Schwelle {thr[seite_liq] / 1e6:.2f} Mio; Hyperliquid {liq['hl'] / 1e6:.2f}, Binance {liq['binance'] / 1e6:.2f}, "
                                   f"andere {liq['andere'] / 1e6:.2f})")
                    break
        z["k"][coin] = zst
        return dict(zst, **info, aktiv=bool(zst.get("aktiv")))

    def _docht(self, con, coin, now, E, t_hm) -> dict:
        b = E["preis"]; vol = E.get("vol1h"); sig = E["sigma4h"]
        out = {"unten": None, "oben": None, "ts": None}
        if not b or not vol:
            return out
        t = t_hm if t_hm and now - t_hm <= 1800 else None
        try:
            rows = con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?", (coin, t)).fetchall() if t else []
        except sqlite3.Error:
            rows = []
        out["ts"] = t; p0 = b["mid"]; out["unten_alle"] = []; out["oben_alle"] = []
        for px, side, usd in rows:
            if not px or not usd:
                continue
            d = abs(math.log(px / p0)) / sig; g = usd / vol
            if d > 3.0 or g < 0.10:
                continue
            c = {"px": px, "usd": usd, "anteil": g, "sigma": d}
            if side == "long" and px < p0:
                out["unten_alle"].append(c)
                if d >= 0.5 and (not out["unten"] or px > out["unten"]["px"]):
                    out["unten"] = c
            elif side == "short" and px > p0:
                out["oben_alle"].append(c)
                if d >= 0.5 and (not out["oben"] or px < out["oben"]["px"]):
                    out["oben"] = c
        return out

    def _funding(self, con, coin, now):
        try:
            r = con.execute("SELECT ts, funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
        except sqlite3.Error:
            r = None
        if not r or r[1] is None:
            return None

        def _stat():
            stunden = [now // 3600 * 3600 - 3600 * k for k in range(14 * 24)]
            try:
                w = [float(x[0]) for x in con.execute(f"SELECT funding FROM ctx_bars WHERE coin=? AND ts IN ({','.join('?' * len(stunden))})",
                                                      (coin, *stunden)) if x[0] is not None]
            except sqlite3.Error:
                w = []
            if len(w) < 48:
                return None
            m = sum(w) / len(w)
            return (m, math.sqrt(sum((x - m) ** 2 for x in w) / (len(w) - 1)), len(w))
        s = self._gecacht((coin, "fstat"), 3600, now, _stat)
        rate = float(r[1])
        return {"ts": int(r[0]), "rate": rate, "z": ((rate - s[0]) / s[1]) if s and s[1] > 0 else None, "n": s[2] if s else 0}

    def _funding_rate(self, con, coin, t) -> float:
        try:
            r = con.execute("SELECT funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (t - 7200, t, coin)).fetchone()
        except sqlite3.Error:
            r = None
        return float(r[0]) if r and r[0] is not None else 0.0

    def _darwin(self, con, st, coin, now, z) -> dict:
        """
        23.34 (Darwin v2): Eröffnungen je Konto und Seite über DARWIN_FENSTER_S netto aufsummiert -- auch in kleinen Stücken (der
        Recorder sammelt die Fills der Liste ohne Mindestbetrag); eine Schließung derselben Seite zieht ab (nicht unter null). Erreicht
        die Summe DARWIN_MIN_USD und ist der jüngste Fill frisch, beginnt eine „Episode“ (einmal je Eröffnung, höchstens
        DARWIN_EPISODE_S). Der Folge-Ausstieg kommt erst, wenn das Konto seit der Episode mindestens DARWIN_AUS_ANTEIL davon wieder
        geschlossen hat -- seit die kleinen Fills sichtbar sind, würde sonst jedes Nachjustieren um ein paar hundert Dollar reichen.
        v1 merkte sich jeden gesehenen Fill und zählte nur die neuen eines Taktes: in Stücke unter 10k zerlegte Eröffnungen blieben
        unsichtbar.
        """
        def _liste():
            try:
                r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
                d = json.loads(r[0]) if r and r[0] else {}
            except (sqlite3.Error, ValueError):
                d = {}
            reihe = [str(a).lower() for a in (d.get("reihe") or [])]
            return (reihe + [a for a in (str(x).lower() for x in (d.get("liste") or [])) if a not in reihe])[:100]
        konten = self._gecacht(("*", "darwin"), 300, now, _liste)
        out = {"konten": konten, "neu": [], "summen": {}}
        if not konten:
            return out
        dirs = ("Open Long", "Open Short", "Close Long", "Close Short", "Long > Short", "Short > Long",
                "Open Long*", "Open Short*", "Close Long*", "Close Short*")
        try:
            rows = con.execute(f"SELECT ts, lower(addr), dir, px, notional, tid FROM lb_fills WHERE coin=? AND ts>=? AND ts<=? AND lower(addr) IN "
                               f"({','.join('?' * len(konten))}) AND dir IN ({','.join('?' * len(dirs))}) ORDER BY ts, tid",
                               (coin, now - DARWIN_FENSTER_S, now, *konten, *dirs)).fetchall()
        except sqlite3.Error:
            rows = []
        gesehen = z["darwin_tids"]; eps = z["darwin_ep"]; auf: dict = {}; rang = {a: i + 1 for i, a in enumerate(konten)}; neu = []
        for ts, a, d, px, usd, tid in rows:
            d = str(d).rstrip("*"); ts = int(ts); px = float(px or 0.0); usd = float(usd or 0.0)
            flip = d in ("Short > Long", "Long > Short")
            seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
            if flip or d.startswith("Close"):
                s_zu = _gegen(seite) if flip else seite
                e = auf.get((a, s_zu))
                if e:                                            # Schließungen ziehen von der laufenden Summe ab (nicht unter null)
                    e["usd"] = max(0.0, e["usd"] - usd)
                    if e["usd"] <= 0:
                        auf.pop((a, s_zu), None)
                k = f"{a}|{coin}|{s_zu}"
                if f"{a}:{tid}" not in gesehen:
                    gesehen[f"{a}:{tid}"] = ts
                    ep = eps.get(k)
                    if isinstance(ep, dict):
                        ep["zu"] = ep.get("zu", 0.0) + usd
                        if ep["zu"] >= DARWIN_AUS_ANTEIL * max(ep.get("usd", 0.0), 1.0):
                            eps.pop(k, None)                    # Episode endet: genug geschlossen
                            neu.append({"addr": a, "art": "zu", "seite": s_zu, "usd": ep["zu"], "von_usd": ep.get("usd"), "px": px, "ts": ts,
                                        "rang": rang.get(a)})
            if flip or d.startswith("Open"):
                e = auf.setdefault((a, seite), {"usd": 0.0, "pxu": 0.0, "ts": ts, "t0": ts, "n": 0})
                e["usd"] += usd; e["pxu"] += px * usd; e["n"] += 1; e["ts"] = max(e["ts"], ts)
        for (a, seite), e in auf.items():
            k = f"{a}|{coin}|{seite}"
            out["summen"][k] = round(e["usd"], 2)
            if k in eps or e["usd"] < DARWIN_MIN_USD or now - e["ts"] > DARWIN_FRISCH_S:
                continue
            eps[k] = {"t": now, "usd": round(e["usd"], 2), "zu": 0.0}
            neu.append({"addr": a, "art": "auf", "seite": seite, "usd": e["usd"], "px": (e["pxu"] / e["usd"]) if e["usd"] else 0.0,
                        "ts": e["ts"], "seit": e["t0"], "n": e["n"], "rang": rang.get(a)})
        out["neu"] = sorted(neu, key=lambda e: (e["ts"], e["art"] != "zu"))
        if out["neu"]:
            self.darwin_log = (self.darwin_log + [dict(e, coin=coin) for e in out["neu"]])[-40:]
        out["log"] = [e for e in self.darwin_log if e["coin"] == coin and now - e["ts"] <= 6 * 3600][-4:]
        return out

    # --- Zyklus
    def zyklus(self, now: int | None = None) -> dict:
        t_start = time.time(); now = int(now or time.time())
        con = self._con(); st = self._st(); n_neu = n_zu = 0
        try:
            self._registrieren(st, now)
            if self.z is None:
                self.z = self._zustand(st)
            z = self.z
            for coin in self.coins:
                try:
                    E = self.eingaben(con, st, coin, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Eingaben: {type(e).__name__}: {e}"); continue
                self.letzte[coin] = {"E": E, "ts": now}
                if not E.get("preis"):
                    continue
                try:
                    n_zu += self._orders(con, st, coin, E, now, z)
                    n_zu += self._positionen(con, st, coin, E, now, z)
                    n_neu += self._signale(con, st, coin, E, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Handel: {type(e).__name__}: {e}")
            if now - int(z.get("aufgeraeumt", 0)) > 86_400:
                st.execute("DELETE FROM labor_ereignis WHERE ts < ?", (now - EREIGNIS_TAGE * 86_400,))
                st.execute("DELETE FROM labor_order WHERE status<>'offen' AND erledigt < ?", (now - 30 * 86_400,))
                z["aufgeraeumt"] = now
            self._zustand_speichern(st, z, now)
            st.commit()
            n_offen = st.execute("SELECT COUNT(*) FROM labor_position WHERE status='offen'").fetchone()[0]
        except Exception:
            self.z = None; self._z_txt = None           # Takt verworfen (Rollback): Zustand beim nächsten Takt aus dem Speicher
            raise
        finally:
            con.close(); st.close()
        self.zyklen += 1; self.dauer = time.time() - t_start; self.t_letzt = now
        return {"offen": n_offen, "neu": n_neu, "zu": n_zu, "dauer": round(self.dauer, 3)}

    # --- Limit-Orders
    def _orders(self, con, st, coin, E, now, z) -> int:
        rows = st.execute("SELECT id, sid, seite, preis, erstellt, gueltig_bis, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten_s, geprueft_bis "
                          "FROM labor_order WHERE status='offen' AND coin=?", (coin,)).fetchall()
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(r[13]) for r in rows), now // 60 * 60); n = 0
        for oid, sid, seite, preis, erstellt, gueltig, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten, gepr in rows:
            if sid not in self.nach_sid:
                st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
            kauf = seite == "long"; fill = None
            for ts, o, h, l, c in bars:
                if ts < gepr or ts > gueltig:
                    continue
                if (kauf and l < preis) or (not kauf and h > preis):
                    fill = (ts, ts + 30); break
            if fill is None and now <= gueltig and now - b["ts"] <= KURS_FRISCH_S and ((kauf and b["ask"] < preis) or (not kauf and b["bid"] > preis)):
                fill = (now // 60 * 60, now)
            if fill:
                if st.execute("SELECT 1 FROM labor_position WHERE sid=? AND coin=? AND status='offen'", (sid, coin)).fetchone():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
                t_f = fill[1]
                sl = sl_px if sl_px else ((preis * (1 - sl_rel) if kauf else preis * (1 + sl_rel)) if sl_rel else None)
                tp = tp_px if tp_px else ((preis * (1 + tp_rel) if kauf else preis * (1 - tp_rel)) if tp_rel else None)
                pid = self._eroeffnen(st, coin, self.nach_sid[sid], seite, t_f, preis, 0.0, GEB_MAKER, "Limit (Maker)", sl, tp,
                                      t_f + int(halten or 0), grund, werte, None, pruef_ab=fill[0], nur_stop_bis=fill[0] + 60)
                st.execute("UPDATE labor_order SET status='gefuellt', erledigt=?, pos_id=? WHERE id=?", (t_f, pid, oid))
                for (oid2,) in st.execute("SELECT id FROM labor_order WHERE status='offen' AND sid=? AND coin=? AND id<>?", (sid, coin, oid)).fetchall():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid2))
                    self._ereignis(st, now, sid, coin, "storno", None, None, "Gegen-Order storniert: Position eröffnet")
                n += 1
            elif now > gueltig:
                st.execute("UPDATE labor_order SET status='verfallen', erledigt=? WHERE id=?", (now, oid))
                self._ereignis(st, now, sid, coin, "verfallen", seite, preis, f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} bei {preis:.6g} "
                               "verfallen, nicht gefüllt")
            elif now // 60 * 60 != gepr:
                st.execute("UPDATE labor_order SET geprueft_bis=? WHERE id=?", (now // 60 * 60, oid))
        return n

    # --- Positionen
    def _eroeffnen(self, st, coin, S, seite, t, preis, slip_bps, gebuehr_satz, art, sl, tp, ablauf, grund, werte, folge,
                   pruef_ab=None, nur_stop_bis=None) -> int:
        menge = self.notional / preis; kauf = seite == "long"
        if sl is not None and ((kauf and sl >= preis) or (not kauf and sl <= preis)):
            sl = None
        if tp is not None and ((kauf and tp <= preis) or (not kauf and tp >= preis)):
            tp = None
        pruef_ab = pruef_ab if pruef_ab is not None else (int(t) // 60 + 1) * 60
        cur = st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, "
                         "sl, tp, ablauf, grund, werte, folge, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) "
                         "VALUES (?,?,?,'offen',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,0,0)",
                         (S["sid"], coin, seite, int(t), preis, self.notional, menge, art, self.notional * gebuehr(coin, gebuehr_satz), slip_bps,
                          sl, tp, int(ablauf), grund, werte if isinstance(werte, str) else _j(werte or {}), _j(folge) if folge else None,
                          pruef_ab, nur_stop_bis if nur_stop_bis is not None else pruef_ab, int(t)))
        pid = cur.lastrowid
        teile = [f"{'Long' if kauf else 'Short'} {coin} zu {preis:.6g} ({art}" + (f", {slip_bps:.1f} bps zur Mitte" if slip_bps else "") + ")"]
        if sl:
            teile.append(f"Stop {sl:.6g}")
        if tp:
            teile.append(f"Ziel {tp:.6g}")
        teile.append(f"bis {_uhr(ablauf)}")
        self._ereignis(st, t, S["sid"], coin, "eroeffnet", seite, preis, " · ".join(teile) + f" — {grund}", None, pid)
        return pid

    def _schliessen(self, st, p, preis, art, gebuehr_satz, slip_bps, grund, t, z=None) -> float:
        kauf = p["seite"] == "long"
        brutto = (preis - p["preis_ein"]) * p["menge"] * (1 if kauf else -1)
        geb_aus = p["menge"] * preis * gebuehr(p["coin"], gebuehr_satz)
        netto = brutto - p["gebuehr_ein"] - geb_aus - p["funding"]
        st.execute("UPDATE labor_position SET status='geschlossen', geschlossen=?, preis_aus=?, art_aus=?, gebuehr_aus=?, slip_aus=?, grund_aus=?, "
                   "brutto_usd=?, netto_usd=?, netto_pct=?, mae_pct=?, mfe_pct=?, funding=?, funding_bis=? WHERE id=?",
                   (int(t), preis, art, geb_aus, slip_bps, grund, brutto, netto, netto / p["notional"] * 100, p["mae_pct"], p["mfe_pct"],
                    p["funding"], p["funding_bis"], p["id"]))
        dauer = max(int(t) - int(p["eroeffnet"]), 0)
        self._ereignis(st, t, p["sid"], p["coin"], "geschlossen", p["seite"], preis,
                       f"{'Long' if kauf else 'Short'} {p['coin']} geschlossen zu {preis:.6g} ({grund}, {art}) nach {dauer // 3600} h "
                       f"{dauer % 3600 // 60} min · netto {netto:+.2f} USD ({netto / p['notional'] * 100:+.2f} %)"
                       + (f", Funding {-p['funding']:+.2f} USD" if abs(p["funding"]) >= 0.01 else ""), netto, p["id"])
        if z is not None:
            z["s"].setdefault(f"{p['sid']}|{p['coin']}", {})["pause_bis"] = int(t) + PAUSE_S
        return netto

    def _funding_nachziehen(self, con, p, bis) -> None:
        h = (int(p["funding_bis"]) // 3600 + 1) * 3600
        while h <= bis:
            p["funding"] += self._funding_rate(con, p["coin"], h) * p["notional"] * (1 if p["seite"] == "long" else -1)
            p["funding_bis"] = h; h += 3600

    def _offene(self, st, coin) -> list:
        return [dict(zip(POS_SPALTEN, r)) for r in st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE status='offen' AND coin=?", (coin,))]

    def _positionen(self, con, st, coin, E, now, z) -> int:
        rows = self._offene(st, coin)
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(p["geprueft_bis"]) for p in rows), now // 60 * 60); n = 0
        for p in rows:
            kauf = p["seite"] == "long"; p_in = p["preis_ein"]; erledigt = False
            vorher = (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"])
            for ts, o, hi, lo, c in bars:
                if ts < p["geprueft_bis"]:
                    continue
                self._funding_nachziehen(con, p, ts + 60)
                nur_stop = ts < p["nur_stop_bis"]
                p["mae_pct"] = max(p["mae_pct"], ((p_in - lo) / p_in if kauf else (hi - p_in) / p_in) * 100)
                if not nur_stop:
                    p["mfe_pct"] = max(p["mfe_pct"], ((hi - p_in) / p_in if kauf else (p_in - lo) / p_in) * 100)
                sl, tp = p["sl"], p["tp"]
                if sl and ((kauf and lo <= sl) or (not kauf and hi >= sl)):
                    pr, bps = taker_preis(dict(b, mid=(min(o, sl) if kauf else max(o, sl))), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", ts + 60, z); erledigt = True; n += 1; break
                if not nur_stop and tp and ((kauf and hi > tp) or (not kauf and lo < tp)):
                    self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", ts + 60, z); erledigt = True; n += 1; break
                if p["ablauf"] and ts + 60 >= p["ablauf"]:
                    pr, bps = taker_preis(dict(b, mid=c), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", ts + 60, z); erledigt = True; n += 1; break
                p["geprueft_bis"] = ts + 60
            if erledigt:
                continue
            self._funding_nachziehen(con, p, now)
            sl, tp = p["sl"], p["tp"]
            if now - b["ts"] > KURS_FRISCH_S:
                pass                                                    # Kurs veraltet: nur die Minutenkerzen zählen
            elif sl and ((kauf and b["bid"] <= sl) or (not kauf and b["ask"] >= sl)):
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", now, z); n += 1; continue
            elif tp and now >= p["nur_stop_bis"] and ((kauf and b["bid"] > tp) or (not kauf and b["ask"] < tp)):
                self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", now, z); n += 1; continue
            elif p["ablauf"] and now >= p["ablauf"]:
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", now, z); n += 1; continue
            if (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"]) != vorher:     # einmal je Minute, nicht je Takt
                st.execute("UPDATE labor_position SET geprueft_bis=?, funding=?, funding_bis=?, mae_pct=?, mfe_pct=? WHERE id=?",
                           (p["geprueft_bis"], p["funding"], p["funding_bis"], p["mae_pct"], p["mfe_pct"], p["id"]))
        return n

    # --- Signale ausführen
    def _signale(self, con, st, coin, E, now, z) -> int:
        frisch = now - E["preis"]["ts"] <= KURS_FRISCH_S
        offen = {p["sid"]: p for p in self._offene(st, coin)}
        orders: dict = {}
        for oid, sid, seite, preis in st.execute("SELECT id, sid, seite, preis FROM labor_order WHERE status='offen' AND coin=?", (coin,)):
            orders.setdefault(sid, []).append([oid, seite, preis])
        n = 0
        for S in self.strategien:
            sid = S["sid"]; zs = z["s"].setdefault(f"{sid}|{coin}", {})
            zs["_orders"] = [(o[1], o[2]) for o in orders.get(sid, [])]            # flüchtig: liegende Limits für die Signalfunktion
            try:
                akts = SIGNALE[S["fn"]](S, E, coin, now, zs) or []
            except Exception as e:
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}"); continue
            sig = next((a for a in akts if a.get("typ") in ("markt", "limit")), None)
            zs.pop("_orders", None)
            for a in akts:
                typ = a.get("typ")
                if typ == "folge_aus":
                    p = offen.get(sid)
                    f = json.loads(p["folge"]) if p and p.get("folge") else None
                    if f and f.get("addr") == a["addr"] and f.get("seite_konto") == a["seite_konto"]:
                        p["coin"] = coin; self._funding_nachziehen(con, p, now)
                        pr, bps = taker_preis(E["preis"], p["seite"] != "long", p["notional"])
                        self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, a["grund"], now, z); offen.pop(sid, None)
                    continue
                if typ == "storno":
                    bleiben = []
                    for o in orders.get(sid, []):
                        if a.get("seite") in (None, o[1]):
                            st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                            self._ereignis(st, now, sid, coin, "storno", o[1], o[2], f"Limit storniert: {a.get('grund', '')}")
                        else:
                            bleiben.append(o)
                    orders[sid] = bleiben
                    continue
                if sid in offen or now < int(zs.get("pause_bis", 0)) or not frisch:
                    continue
                if typ == "markt":
                    kauf = a["seite"] == "long"; h = a.get("h", S["regeln"].get("h", 4)); sig_h = E["sigma4h"] * math.sqrt(h / 4)
                    pr, bps = taker_preis(E["preis"], kauf, self.notional)
                    sl, tp = a.get("sl_px"), a.get("tp_px")
                    k_sl, k_tp = a.get("sl", S["regeln"].get("sl")), a.get("tp", S["regeln"].get("tp"))
                    if sl is None and k_sl:
                        sl = pr * (1 - k_sl * sig_h) if kauf else pr * (1 + k_sl * sig_h)
                    if tp is None and k_tp:
                        tp = pr * (1 + k_tp * sig_h) if kauf else pr * (1 - k_tp * sig_h)
                    pid = self._eroeffnen(st, coin, S, a["seite"], now, pr, bps, GEB_TAKER, "Markt (Taker)", sl, tp,
                                          now + int(a.get("halten_s", h * 3600)), a.get("grund", ""), a.get("werte"), a.get("folge"))
                    offen[sid] = self._pos(st, pid)
                    for o in orders.pop(sid, []):
                        st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                    n += 1
                elif typ == "limit":
                    kauf = a["seite"] == "long"
                    vorh = [o for o in orders.get(sid, []) if o[1] == a["seite"]]
                    if vorh and abs(vorh[0][2] / a["preis"] - 1) <= a.get("toleranz", 0.001):
                        continue
                    if (kauf and a["preis"] >= E["preis"]["ask"]) or (not kauf and a["preis"] <= E["preis"]["bid"]):
                        continue                                        # läge schon im Markt -- kein Limit
                    for o in vorh:                                      # ersetzt: ein Ereignis „verschoben“ statt zweier
                        st.execute("UPDATE labor_order SET status='ersetzt', erledigt=? WHERE id=?", (now, o[0]))
                    cur = st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, "
                                     "sl_px, tp_px, halten_s, geprueft_bis) VALUES (?,?,?,?,?,?,'offen',?,?,?,?,?,?,?,?)",
                                     (sid, coin, a["seite"], a["preis"], now, now + int(a.get("gueltig_s", 4 * 3600)), a.get("grund", ""),
                                      _j(a.get("werte") or {}), a.get("sl_rel"), a.get("tp_rel"), a.get("sl_px"), a.get("tp_px"),
                                      int(a.get("halten_s", 6 * 3600)), (now // 60 + 1) * 60))
                    orders[sid] = [o for o in orders.get(sid, []) if o[1] != a["seite"]] + [[cur.lastrowid, a["seite"], a["preis"]]]
                    self._ereignis(st, now, sid, coin, "limit", a["seite"], a["preis"],
                                   f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} "
                                   + (f"verschoben von {vorh[0][2]:.6g} auf {a['preis']:.6g}" if vorh else f"bei {a['preis']:.6g} gesetzt")
                                   + f", gültig bis {_uhr(now + int(a.get('gueltig_s', 4 * 3600)))} — {a.get('grund', '')}")
            try:
                txt = status_text(S, E, now, zs)
            except Exception as e:
                txt = f"({type(e).__name__})"
            self.status[(sid, coin)] = {
                "ts": now, "text": txt,
                "signal": {"typ": sig["typ"], "seite": sig.get("seite"), "grund": sig.get("grund", "")} if sig else None,
                "blockiert": "Position offen" if sid in offen else (f"Pause bis {_uhr(zs['pause_bis'])}" if now < int(zs.get("pause_bis", 0))
                                                                     else (None if frisch else "Kurs veraltet")),
                "orders": len(orders.get(sid, []))}
        return n

    def _pos(self, st, pid) -> dict:
        return dict(zip(POS_SPALTEN, st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE id=?", (pid,)).fetchone()))


# ------------------------------------------------------------------------------------------------ Auswertung
def _betacf(a: float, b: float, x: float) -> float:
    """Kettenbruch der unvollständigen Betafunktion (Numerical Recipes 6.4)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300); h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        de = d * c; h *= de
        if abs(de - 1.0) < 1e-12:
            break
    return h


def p_t_einseitig(t: float, df: int) -> float:
    """P(T >= t) der Student-t-Verteilung mit df Freiheitsgraden -- bei wenigen Trades deutlich vorsichtiger als die Normalverteilung."""
    if df <= 0:
        return 1.0
    x = df / (df + t * t)
    a, b = df / 2.0, 0.5
    if x >= 1.0:
        zwei = 1.0                                    # t = 0
    elif x <= 0.0:
        zwei = 0.0
    else:
        lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
        front = math.exp(lbeta + a * math.log(x) + b * math.log(1 - x))
        ib = front * _betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - front * _betacf(b, a, 1 - x) / b
        zwei = min(1.0, max(0.0, ib))                 # P(|T| >= |t|) = I_x(df/2, 1/2)
    return zwei / 2 if t >= 0 else 1 - zwei / 2


def bloecke(tr: list, block_s: int) -> list:
    """
    23.34: Mittel der Netto-Rendite je Block -- Trades, die im selben Block der Länge block_s (Horizont der Strategie) eröffnet
    wurden, sind EINE Beobachtung (meist dasselbe Signal in mehreren korrelierten Coins zugleich). Reihenfolge = Zeit.
    """
    b: dict = {}
    for t in tr:
        b.setdefault(int(t["eroeffnet"]) // max(int(block_s), 60), []).append(t["netto_pct"])
    return [sum(v) / len(v) for _, v in sorted(b.items())]


def coin_starts(st, coins=COINS, now: int | None = None, schreiben: bool = False) -> dict:
    """
    {Coin: Start des simulierten Kontos} (labor_zustand „coins“). 23.34: Jeder Coin zählt ab seinem eigenen Start -- XMR kam später
    dazu. Beim ersten Schreiben nach dem Update übernehmen die Coins von 23.33 den gemeinsamen Start, neue Coins beginnen jetzt.
    """
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='coins'").fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except (sqlite3.Error, ValueError):
        d = {}
    d = {str(k): int(v) for k, v in (d.items() if isinstance(d, dict) else []) if v}
    if not schreiben:
        return d
    now = int(now or time.time()); neu = dict(d)
    if not d:
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        alt = int(r0[0]) if r0 and r0[0] else now
        for c in coins:
            neu[c] = alt if c in COINS_2333 else now
    for c in coins:
        neu.setdefault(c, now)
    if neu != d:
        st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('coins', ?)", (_j(neu),))
    return neu


def konten_tage(erstellt: int, ende: int, starts: dict, coins) -> float:
    """Summe der Tage, die die Konten einer Strategie gelaufen sind: je Coin ab max(Strategie erstellt, Coin-Start) bis ende."""
    return sum(max(0, int(ende) - max(int(erstellt or 0), int(starts.get(c) or erstellt or 0))) for c in coins) / 86_400


def _stat(tr: list, erstellt: int, now: int, kt: float | None = None, notional: float = NOTIONAL, block_s: int | None = None) -> dict:
    """
    Kennzahlen einer Strategie (oder eines Coins). Konto = je Coin ein simuliertes Konto über `notional` USD; die Tagesrendite teilt
    die Summe durch die Kontotage kt (23.34: je Coin ab seinem Start; ohne Angabe Laufzeit × Coins) -- auch Tage ohne Trade zählen.
    23.34: t, Zufalls-/Glückswahrscheinlichkeit, Hälften und Stufen auf BLÖCKEN (block_s = Horizont): gleichzeitige Trades der Strategie
    zählen einmal (n_eff). Ø netto, Treffer, Kelly und die Hebel-Ansicht bleiben je Trade.
    """
    n = len(tr)
    out = {"n": n, "n_eff": 0, "treffer": None, "mittel_pct": None, "t": None, "summe_usd": round(sum(t["netto_usd"] for t in tr), 2),
           "gebuehren_usd": round(sum(t["gebuehren"] for t in tr), 2), "funding_usd": round(sum(t["funding"] for t in tr), 2),
           "pf": None, "max_dd_usd": 0.0, "trades_tag": None, "letzter": max((t["geschlossen"] for t in tr), default=None),
           "haelften": None, "kelly": None, "hebel": [], "stufe": "Kandidat", "slip_bps": None, "p_zufall": None, "tag_pct": None}
    tage = max((now - erstellt) / 86_400, 1 / 24) if erstellt else None
    if kt is None and tage:
        kt = tage * len(COINS)
    kt = max(kt, 1 / 24) if kt else None
    if tage:
        out["tage"] = round(tage, 2); out["trades_tag"] = round(n / tage, 2)
    if kt:
        out["konten_tage"] = round(kt, 2)
        out["tag_pct"] = out["summe_usd"] / kt / notional * 100
    if not n:
        return out
    r = [t["netto_pct"] for t in tr]; m = sum(r) / n
    out["treffer"] = sum(1 for x in r if x > 0) / n; out["mittel_pct"] = m
    sd = math.sqrt(sum((x - m) ** 2 for x in r) / (n - 1)) if n > 1 else None
    if sd and sd > 0 and n >= 3 and m > 0:
        out["kelly"] = min(50.0, (m / 100) / (sd / 100) ** 2)
    bw = bloecke(tr, block_s) if block_s else r
    ne = len(bw); out["n_eff"] = ne
    if ne >= 3:
        mb = sum(bw) / ne; sdb = math.sqrt(sum((x - mb) ** 2 for x in bw) / (ne - 1))
        if sdb > 0:
            out["t"] = mb / (sdb / math.sqrt(ne))
            out["p_zufall"] = p_t_einseitig(out["t"], ne - 1)            # einseitig: so gut oder besser rein zufällig (Student-t, n_eff − 1)
    gew = sum(t["netto_usd"] for t in tr if t["netto_usd"] > 0); verl = -sum(t["netto_usd"] for t in tr if t["netto_usd"] < 0)
    out["pf"] = (gew / verl) if verl > 0 else None
    cum = peak = dd = 0.0
    for t in tr:
        cum += t["netto_usd"]; peak = max(peak, cum); dd = max(dd, peak - cum)
    out["max_dd_usd"] = round(dd, 2)
    sl = [t["slip"] for t in tr if t["slip"] is not None]
    out["slip_bps"] = (sum(sl) / len(sl)) if sl else None
    if ne >= 6:
        h = ne // 2; a = bw[:h]; b = bw[h:]
        out["haelften"] = [sum(a) / len(a), sum(b) / len(b)]
    for L in HEBEL:
        e, pk, mdd, aus = 1.0, 1.0, 0.0, None
        for i, t in enumerate(tr):
            if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE:
                e = 0.0; aus = i + 1; mdd = 1.0; break
            e *= max(0.0, 1 + L * t["netto_pct"] / 100); pk = max(pk, e); mdd = max(mdd, 1 - e / pk if pk > 0 else 1.0)
            if e <= 0:
                aus = i + 1; break
        # gleiche Marge, L-facher Einsatz: Rendite, Gebühren und Funding wachsen mit L; ein liquidierter Trade kostet die ganze Marge
        summe_L = sum(-notional if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE else L * t["netto_usd"] for t in tr)
        out["hebel"].append({"L": L, "faktor": round(e, 4), "max_dd": round(mdd, 4), "ausgeloescht": aus, "summe_usd": round(summe_L, 2),
                             "tag_pct": round(summe_L / kt / notional * 100, 4) if kt else None,
                             "liquidiert": sum(1 for t in tr if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE),
                             "schlechtester_pct": round(-100.0 if any(t["mae_pct"] / 100 * L >= LIQ_SCHWELLE for t in tr) else L * min(r), 3)})
    span = (max(t["geschlossen"] for t in tr) - min(t["eroeffnet"] for t in tr)) / 86_400
    if ne >= 30 and (out["t"] or 0) >= 3 and span >= 14 and out["haelften"] and min(out["haelften"]) > 0:
        out["stufe"] = "bewährt"
    elif ne >= 15 and (out["t"] or 0) >= 2 and out["summe_usd"] > 0:
        out["stufe"] = "Bewährung"
    elif ne >= 30 and (out["t"] or 0) <= -2:
        out["stufe"] = "negativ"
    return out


def kennzahlen(st, now: int) -> list:
    schema(st)
    strat = {r[0]: {"sid": r[0], "name": r[1], "titel": r[2], "gruppe": r[3], "regeln": json.loads(r[4] or "{}"), "beschreibung": r[5],
                    "erstellt": r[6], "aktiv": r[7]}
             for r in st.execute("SELECT sid, name, titel, gruppe, regeln, beschreibung, erstellt, aktiv FROM labor_strategie")}
    tr: dict = {}
    for r in st.execute("SELECT sid, coin, eroeffnet, geschlossen, netto_usd, netto_pct, mae_pct, gebuehr_ein + gebuehr_aus, funding, "
                        "slip_ein, slip_aus FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
        tr.setdefault(r[0], []).append({"coin": r[1], "eroeffnet": r[2], "geschlossen": r[3], "netto_usd": r[4] or 0.0, "netto_pct": r[5] or 0.0,
                                        "mae_pct": r[6] or 0.0, "gebuehren": r[7] or 0.0, "funding": r[8] or 0.0,
                                        "slip": ((r[9] or 0.0) + (r[10] or 0.0)) if r[9] is not None else None})
    offen: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_position WHERE status='offen'"):
        offen.setdefault(sid, []).append(coin)
    orders: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_order WHERE status='offen'"):
        orders.setdefault(sid, []).append(coin)
    starts = coin_starts(st)                         # die Coins, auf denen das Labor läuft, je mit ihrem Start
    if not starts:                                   # vor dem ersten Takt nach dem Update: 23.33-Coins ab dem Laborstart, neue ab jetzt
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        starts = {c: (int(r0[0]) if (r0 and r0[0] and c in COINS_2333) else now) for c in COINS}
    out = []
    for sid, s in strat.items():
        if not s["aktiv"] and sid not in tr:
            continue
        t_ = tr.get(sid, [])
        # Ende der Laufzeit: aktive Strategien jetzt; alte Regelversionen mit ihrem letzten Trade (oder offener Position)
        ende = now if (s["aktiv"] or sid in offen) else max([x["geschlossen"] for x in t_] or [s["erstellt"]])
        block_s = int(float(s["regeln"].get("h", 4)) * 3600)
        coins_s = sorted(set(starts) | {x["coin"] for x in t_})
        k = dict(s, **_stat(t_, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, coins_s), block_s=block_s),
                 offen=offen.get(sid, []), orders=orders.get(sid, []), block_h=block_s / 3600)
        k["je_coin"] = {}
        for c in sorted({x["coin"] for x in t_}):
            sc = _stat([x for x in t_ if x["coin"] == c], s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, [c]), block_s=block_s)
            k["je_coin"][c] = {f: sc[f] for f in ("n", "n_eff", "treffer", "mittel_pct", "t", "summe_usd", "tag_pct", "max_dd_usd")}
            k["je_coin"][c]["hebel"] = {str(h["L"]): {"summe_usd": h["summe_usd"], "tag_pct": h["tag_pct"], "liquidiert": h["liquidiert"]} for h in sc["hebel"]}
        out.append(k)
    n_aktiv = max(1, sum(1 for k in out if k["aktiv"]))
    for k in out:                                  # viele Strategien zugleich: die beste sieht auch zufällig gut aus
        k["p_glueck"] = min(1.0, k["p_zufall"] * n_aktiv) if k.get("p_zufall") is not None else None
    out.sort(key=lambda k: (-(k["summe_usd"] or 0)))
    return out


def uebersicht(store: str, preise: dict, now: int | None = None) -> dict:
    now = int(now or time.time()); st = F.store_connect(store); schema(st)
    try:
        K = kennzahlen(st, now)
        titel = {k["sid"]: k["titel"] for k in K}
        r = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone(); start = int(r[0]) if r else None
        seit = coin_starts(st)
        for c in COINS:
            seit.setdefault(c, start if (start and c in COINS_2333) else now)
        offen = []
        for p in st.execute("SELECT id, sid, coin, seite, eroeffnet, preis_ein, notional, menge, gebuehr_ein, sl, tp, ablauf, grund, funding, "
                            "mae_pct, mfe_pct, art_ein FROM labor_position WHERE status='offen' ORDER BY eroeffnet DESC"):
            mid = (preise.get(p[2]) or {}).get("mid")
            kauf = p[3] == "long"; unreal = None
            if mid:
                geb_aus = p[7] * mid * gebuehr(p[2], GEB_TAKER)
                unreal = (mid - p[5]) * p[7] * (1 if kauf else -1) - p[8] - geb_aus - (p[13] or 0.0)
            offen.append({"id": p[0], "sid": p[1], "titel": titel.get(p[1], p[1]), "coin": p[2], "seite": p[3], "eroeffnet": p[4], "preis_ein": p[5],
                          "notional": p[6], "sl": p[9], "tp": p[10], "ablauf": p[11], "grund": p[12], "funding": p[13], "mae_pct": p[14],
                          "mfe_pct": p[15], "art": p[16], "jetzt": mid, "netto_usd": unreal, "netto_pct": (unreal / p[6] * 100) if unreal is not None else None})
        orders = [{"id": o[0], "sid": o[1], "titel": titel.get(o[1], o[1]), "coin": o[2], "seite": o[3], "preis": o[4], "erstellt": o[5],
                   "gueltig_bis": o[6], "grund": o[7], "jetzt": (preise.get(o[2]) or {}).get("mid")}
                  for o in st.execute("SELECT id, sid, coin, seite, preis, erstellt, gueltig_bis, grund FROM labor_order WHERE status='offen' ORDER BY erstellt DESC")]
        ereig = [{"id": e[0], "ts": e[1], "sid": e[2], "titel": titel.get(e[2], "Labor") if e[2] else "Erkennung", "coin": e[3], "art": e[4],
                  "seite": e[5], "preis": e[6], "text": e[7], "netto_usd": e[8], "pos_id": e[9]}
                 for e in st.execute("SELECT id, ts, sid, coin, art, seite, preis, text, netto_usd, pos_id FROM labor_ereignis "
                                     "ORDER BY ts DESC, id DESC LIMIT 150")]
        tag = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE status='geschlossen' AND geschlossen>=?",
                         (now - 86_400,)).fetchone()
        ges = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0), COALESCE(SUM(gebuehr_ein + gebuehr_aus), 0) FROM labor_position "
                         "WHERE status='geschlossen'").fetchone()
    finally:
        st.close()
    aktiv = [k for k in K if k["aktiv"]]
    mit = [k for k in aktiv if k["n"] >= 5]
    return {"ts": now, "start": start, "notional": NOTIONAL, "coins": list(COINS), "coins_seit": seit, "geb_faktor": GEB_FAKTOR,
            "strategien": K, "offen": offen, "orders": orders,
            "ereignisse": ereig, "gesamt": {"strategien": len(aktiv), "konten": len(aktiv) * len(COINS), "offen": len(offen), "orders": len(orders),
                                            "trades": ges[0], "netto_usd": round(ges[1], 2), "gebuehren_usd": round(ges[2], 2),
                                            "trades_24h": tag[0], "netto_24h": round(tag[1], 2),
                                            "offen_usd": round(sum(o["netto_usd"] or 0 for o in offen), 2),
                                            "beste": max(mit, key=lambda k: k["summe_usd"])["titel"] if mit else None,
                                            "stufen": {s: sum(1 for k in aktiv if k["stufe"] == s) for s in ("Kandidat", "Bewährung", "bewährt", "negativ")}}}


def trades(store: str, sid: str | None = None, coin: str | None = None, n: int = 150) -> list:
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.coin, p.seite, p.eroeffnet, p.geschlossen, p.preis_ein, p.preis_aus, p.art_ein, p.art_aus, "
             "p.gebuehr_ein + p.gebuehr_aus, p.slip_ein, p.slip_aus, p.funding, p.grund, p.grund_aus, p.netto_usd, p.netto_pct, p.mae_pct, p.mfe_pct "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.status='geschlossen'")
        par = []
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        if coin:
            q += " AND p.coin=?"; par.append(coin)
        q += " ORDER BY p.geschlossen DESC LIMIT ?"; par.append(int(n))
        spalten = ("id", "sid", "titel", "coin", "seite", "eroeffnet", "geschlossen", "preis_ein", "preis_aus", "art_ein", "art_aus", "gebuehren",
                   "slip_ein", "slip_aus", "funding", "grund", "grund_aus", "netto_usd", "netto_pct", "mae_pct", "mfe_pct")
        return [dict(zip(spalten, r)) for r in st.execute(q, par)]
    finally:
        st.close()


def chart(db: str, store: str, coin: str, sid: str | None = None, stunden: int = 24, now: int | None = None) -> dict:
    now = int(now or time.time()); t0 = now - stunden * 3600
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
    try:
        kurs = [(int(t), float(c)) for t, c in con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? AND ts % 300 = 240 ORDER BY ts",
                                                           (t0, now, coin)) if c]
    except sqlite3.Error:
        kurs = []
    finally:
        con.close()
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.seite, p.status, p.eroeffnet, p.preis_ein, p.geschlossen, p.preis_aus, p.netto_usd, p.sl, p.tp "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.coin=? AND (p.eroeffnet>=? OR p.status='offen' OR p.geschlossen>=?)")
        par = [coin, t0, t0]
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        marken = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "status": r[4], "ein_t": r[5], "ein_px": r[6], "aus_t": r[7], "aus_px": r[8],
                   "netto_usd": r[9], "sl": r[10], "tp": r[11]} for r in st.execute(q + " ORDER BY p.eroeffnet", par)]
        q2 = "SELECT o.id, o.sid, s.titel, o.seite, o.preis, o.erstellt, o.gueltig_bis FROM labor_order o LEFT JOIN labor_strategie s ON s.sid = o.sid WHERE o.coin=? AND o.status='offen'"
        par2 = [coin] + ([sid] if sid else [])
        limits = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "preis": r[4], "erstellt": r[5], "gueltig_bis": r[6]}
                  for r in st.execute(q2 + (" AND o.sid=?" if sid else ""), par2)]
    finally:
        st.close()
    return {"coin": coin, "von": t0, "bis": now, "kurs": kurs, "marken": marken, "limits": limits}


def equity(store: str, now: int | None = None) -> dict:
    st = F.store_connect(store); schema(st)
    try:
        titel = {r[0]: (r[1], r[2]) for r in st.execute("SELECT sid, titel, gruppe FROM labor_strategie")}
        reihen: dict = {}
        for sid, t, netto in st.execute("SELECT sid, geschlossen, netto_usd FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
            r = reihen.setdefault(sid, {"sid": sid, "titel": titel.get(sid, (sid, ""))[0], "gruppe": titel.get(sid, ("", ""))[1], "punkte": [], "summe": 0.0})
            r["summe"] += netto or 0.0; r["punkte"].append([int(t), round(r["summe"], 2)])
    finally:
        st.close()
    return {"ts": int(now or time.time()), "reihen": sorted(reihen.values(), key=lambda r: -r["summe"])}


def _fmt_usd(x) -> str:
    if x is None:
        return "—"
    a = abs(x)
    return (f"{x / 1e6:+.2f} Mio" if a >= 1e6 else f"{x / 1e3:+.1f}k" if a >= 1e4 else f"{x:+.0f}")


def datenfluss(E: dict, strat: list, now: int) -> list:
    """Alle Eingangsdaten eines Coins als Zeilen für den Abschnitt „Datenfluss“ (Wert, Alter, Status, genutzt von)."""
    if not E:
        return []
    nutzer: dict = {}
    for s in strat:
        for k in s["eingaben"]:
            nutzer.setdefault(k, []).append(s["titel"])
    zeilen = []

    def z(gruppe, name, wert, ts, key=None, frisch=None, hinweis=None):
        alter = (now - ts) if ts else None
        status = "fehlt" if wert in (None, "—") else ("alt" if (frisch and alter is not None and alter > frisch) else "frisch")
        zeilen.append({"gruppe": gruppe, "name": name, "wert": wert if wert is not None else "—", "alter": alter, "status": status,
                       "nutzer": nutzer.get(key, []) if key else [], "hinweis": hinweis})
    b = E.get("preis") or {}
    z("Kurs & Buch", "Kurs (Mitte)", f"{b['mid']:.6g}" if b else None, b.get("ts"), None, FRISCH_S["preis"], b.get("quelle"))
    z("Kurs & Buch", "Spread", f"{b['spread_bps']:.2f} bps" if b else None, b.get("ts"), None, FRISCH_S["preis"])
    z("Kurs & Buch", "Tiefe ±10 bps", _fmt_usd(b.get("tiefe10")).lstrip("+") if b.get("tiefe10") else None, b.get("ts"), None, FRISCH_S["preis"],
      "bestimmt die Marktauswirkung jeder simulierten Markt-Order")
    z("Schwankung", "σ 4 h", f"{E['sigma4h'] * 100:.2f} %" + ("" if E.get("sigma_ok") else " (Ersatzwert)"), now, None, None,
      "aus 15-min-Renditen der letzten 7 Tage; Grundlage aller Stops und Ziele")
    z("Schwankung", "σ 1 h / 15 min", f"{E['sigma1h'] * 100:.2f} % / {E['sigma15'] * 100:.2f} %", now)
    z("Schwankung", "Stundenvolumen (Median 24 h)", _fmt_usd(E.get("vol1h")).lstrip("+") if E.get("vol1h") else None, now)
    P = E.get("prognose")
    if P:
        z("Prognose", "Bias", f"{P['bias']:+.2f}" if P.get("bias") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v1", f"{P['p_up_v1'] * 100:.1f} %" if P.get("p_up_v1") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v2", f"{float(P['p_up_v2']) * 100:.1f} % (Version {P.get('v2_version') or 1})" if P.get("p_up_v2") is not None else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "Kauf- / Verkaufspreis", f"{P['buy_px']:.6g} / {P['sell_px']:.6g}" if P.get("buy_px") and P.get("sell_px") else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
    else:
        z("Prognose", "Prognose", None, None, "prognose")
    for n_, (v, t) in sorted((E.get("treiber") or {}).items()):
        z("Treiber", n_, f"{v:+.2f}", t, f"treiber:{n_}", FRISCH_S["treiber"])
    for f, v in (E.get("familien") or {}).items():
        z("Familien", f, (f"{v[0]:+.2f} ({v[2]} Treiber)" if f != "Profi-Flow" else f"{v[0]:+.2f}") if v else None, v[1] if v else None,
          f"familie:{f}", FRISCH_S["familie"])
    S_ = E.get("staerke") or {}
    z("Familien", "Stärke (große Bewegung?)", f"{S_['wert']:.2f}" + (f", Ruhe {S_['ruhe']:.2f}" if S_.get("ruhe") is not None else "")
      if S_.get("wert") is not None else None, now, "staerke")
    K = E.get("kaskade") or {}
    liq = K.get("liq") or {}
    z("Ereignisse", "Kursbewegung 15 min", f"{K['z']:+.2f} σ" if K.get("z") is not None else None, now, "kaskade", None,
      f"Kaskade ab ±{KASKADE_Z:g} σ zusammen mit Liquidationen über der Schwelle")
    z("Ereignisse", "Liquidationen 15 min (Long / Short)", f"{_fmt_usd(liq.get('long')).lstrip('+')} / {_fmt_usd(liq.get('short')).lstrip('+')}" if liq else None,
      now, "kaskade", None, (f"Schwellen {_fmt_usd((K.get('schwelle') or {}).get('long')).lstrip('+')} / {_fmt_usd((K.get('schwelle') or {}).get('short')).lstrip('+')} · "
                            f"Hyperliquid {_fmt_usd(liq.get('hl')).lstrip('+')}, Binance {_fmt_usd(liq.get('binance')).lstrip('+')}, andere {_fmt_usd(liq.get('andere')).lstrip('+')}")
      if liq else None)
    z("Ereignisse", "Kaskaden-Status", ("AKTIV: " + ("abwärts" if K.get("richtung") == "ab" else "aufwärts") + f" seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}")
      if K.get("aktiv") else "ruhig", now, "kaskade")
    A = E.get("anker") or {}
    if A.get("fehler"):
        z("Heatmap", "Anker", None, None, "anker", None, A["fehler"])
    else:
        dom = (A.get("oben") if (A.get("A") or 0) > 0 else A.get("unten")) if A.get("A") is not None else None
        z("Heatmap", "Anker A", (f"{A['A']:+.2f}" + (f" · Cluster {dom['px']:.6g}, {dom['abstand_sigma']:.1f} σ, {dom['anteil_volumen'] * 100:.0f} % Vol." if dom else ""))
          if A.get("A") is not None else "kein Anker", A.get("ts"), "anker", FRISCH_S["anker"],
          "Beleg: " + ("ja" if (A.get("bilanz") or {}).get("belegt") else "nein"))
    D = E.get("docht") or {}
    for key, name in (("unten", "Docht-Ziel unten (Long-Cluster)"), ("oben", "Docht-Ziel oben (Short-Cluster)")):
        c = D.get(key)
        z("Heatmap", name, f"{c['px']:.6g} · {_fmt_usd(c['usd']).lstrip('+')} · {c['anteil'] * 100:.0f} % Vol. · {c['sigma']:.1f} σ" if c else "keins",
          D.get("ts"), "docht", FRISCH_S["docht"])
    f = E.get("funding")
    z("Funding", "Funding-Rate", (f"{f['rate'] * 100:.4f} %/h" + (f", z {f['z']:+.1f}" if f.get("z") is not None else ", Statistik im Aufbau")) if f else None,
      f["ts"] if f else None, "funding", FRISCH_S["funding"])
    Dw = E.get("darwin") or {}
    z("Händler", "Darwin-Liste (Konten)", f"{len(Dw.get('konten') or [])}" if Dw.get("konten") is not None else None, now, "darwin")
    log = Dw.get("log") or []
    z("Händler", "Darwin: letzte Ein-/Ausstiege (6 h)", ", ".join(f"{_uhr(e['ts'])[7:]} #{e.get('rang')} {'eröffnet' if e['art'] == 'auf' else 'schließt'} {e['seite']} "
                                                                f"{_fmt_usd(e['usd']).lstrip('+')}" for e in reversed(log)) if log else "keine",
      log[-1]["ts"] if log else now, "darwin")
    su = Dw.get("summen") or {}
    z("Händler", f"Darwin: Eröffnungen der letzten {DARWIN_FENSTER_S // 60} min", ", ".join(
        f"{k.split('|')[0][:6]}…{k.split('|')[0][-4:]} {k.split('|')[2]} {_fmt_usd(v).lstrip('+')}" for k, v in sorted(su.items(), key=lambda kv: -kv[1])[:4])
      if su else "keine", now, "darwin", None, f"Summe je Konto und Seite seit dem letzten Schließen, auch in kleinen Stücken; Einstieg ab "
                                               f"{DARWIN_MIN_USD / 1e3:.0f}k (23.34)")
    AF = E.get("adressstrom")
    if AF is None:
        z("Adress-Strom", "Aufzeichnung", None, None, "adressstrom", None, "adressfluss.db noch nicht angelegt (Recorder ab 23.33)")
    else:
        z("Adress-Strom", "Trades / Adressen 60 min", f"{AF['trades_h']:,} / {AF['adressen_h']:,}".replace(",", "."), AF.get("ts"), "adressstrom",
          FRISCH_S["adressstrom"], f"Aufzeichnung seit {_uhr(AF.get('seit'))}")
        z("Adress-Strom", "TWAP-Anteil (Null-Hash)", f"{AF['nullhash_anteil'] * 100:.2f} % der Trades" if AF.get("nullhash_anteil") is not None else None,
          AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        z("Adress-Strom", "TWAP-Netto 60 min", (f"{_fmt_usd(AF['tw_netto_h'])} USD" + (f" = {AF['tw_anteil'] * 100:+.2f} % Vol." if AF.get("tw_anteil") is not None else ""))
          if AF.get("ts") else None, AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        top = AF.get("top") or []
        z("Adress-Strom", "Größte Netto-Nehmer 60 min", ", ".join(f"{t['addr'][:6]}…{t['addr'][-4:]} {_fmt_usd(t['netto'])}" + (" (TWAP)" if abs(t.get("twap") or 0) >= 0.5 * abs(t["netto"] or 1) else "")
                                                              for t in top) if top else None, AF.get("ts"), None, FRISCH_S["adressstrom"],
          "Nehmer-Käufe minus -Verkäufe je Adresse; Grundlage für den informierten Fluss (geplant, sobald einige Tage Daten da sind)")
    return zeilen


def live(L, now: int | None = None) -> dict:
    """Signaltafel für das Dashboard: je Strategie und Coin, was sie im letzten Takt sah; dazu je Coin die Frische der Eingänge."""
    now = int(now or time.time())
    status: dict = {}
    for (sid, coin), v in list(L.status.items()):
        status.setdefault(sid, {})[coin] = v
    frische = {}
    for coin, v in list(L.letzte.items()):
        z = datenfluss(v.get("E"), L.strategien, now)
        frische[coin] = {"frisch": sum(1 for r in z if r["status"] == "frisch"), "alt": sum(1 for r in z if r["status"] == "alt"),
                         "fehlt": sum(1 for r in z if r["status"] == "fehlt"), "ts": v.get("ts"),
                         "preis": ((v.get("E") or {}).get("preis") or {}).get("mid"), "quelle": ((v.get("E") or {}).get("preis") or {}).get("quelle")}
    return {"status": status, "frische": frische, "coins": list(L.coins), "zyklen": L.zyklen, "dauer_s": round(L.dauer, 3), "letzter": L.t_letzt,
            "fehler": list(L.fehler[-8:])}


_DIRS_AUF = ("Open Long", "Open Short", "Short > Long", "Long > Short")
_DIRS_ZU = ("Close Long", "Close Short")


def darwin_episoden(rows: list, fenster: int = DARWIN_FENSTER_S, schwelle: float = DARWIN_MIN_USD, aus_anteil: float = DARWIN_AUS_ANTEIL) -> list:
    """
    Nachrechnung der Live-Regel über eine ganze Fill-Reihe [(ts, addr, coin, dir, px, usd, tid)], zeitlich sortiert: Eröffnungen je
    Konto, Coin und Seite netto über `fenster` (Schließungen ziehen ab, nicht unter null); ab `schwelle` eine Episode, je Eröffnung
    einmal; sie endet, wenn das Konto `aus_anteil` davon wieder geschlossen hat (Feld „aus“), spätestens nach 12 h.
    """
    hist: dict = {}; ep: dict = {}; out = []
    for ts, a, coin, d, px, usd, tid in rows:
        d = str(d or "").rstrip("*"); ts = int(ts); usd = float(usd or 0.0)
        if d not in _DIRS_AUF and d not in _DIRS_ZU:
            continue
        flip = d in ("Short > Long", "Long > Short")
        seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
        teile = ([("zu", _gegen(seite))] if flip else []) + [("zu" if d in _DIRS_ZU else "auf", seite)]
        h = hist.setdefault((a, coin), [])
        h[:] = [x for x in h if x[0] >= ts - fenster] + [(ts, teile, usd)]
        for k in [k for k, e in ep.items() if ts - e["t"] > DARWIN_EPISODE_S]:
            ep.pop(k)
        for art, s_ in teile:
            k = (a, coin, s_)
            if art == "zu" and k in ep:
                ep[k]["zu"] += usd
                if ep[k]["zu"] >= aus_anteil * max(ep[k]["usd"], 1.0):
                    out[ep.pop(k)["i"]]["aus"] = ts
        for art, s_ in teile:
            k = (a, coin, s_)
            if art != "auf" or k in ep:
                continue
            net, n, t0 = 0.0, 0, None
            for ts2, teile2, usd2 in h:
                for art2, s2 in teile2:
                    if s2 != s_:
                        continue
                    if art2 == "auf":
                        net += usd2; n += 1; t0 = t0 if t0 is not None else ts2
                    else:
                        net = max(0.0, net - usd2)
                        if net <= 0:
                            n, t0 = 0, None
            if net >= schwelle:
                ep[k] = {"t": ts, "usd": net, "zu": 0.0, "i": len(out)}
                out.append({"ts": ts, "addr": a, "coin": coin, "seite": s_, "usd": net, "n": n, "seit": t0, "aus": None})
    return out


def darwin_pruefung(db: str, store: str, now: int | None = None, min_usd_fill: float = 2_500.0) -> list:
    """
    23.34: Sieht das Labor die Trades der Darwin-Liste? Liste, Fills der letzten 24 h in den Labor-Coins (Eröffnungen, Schließungen,
    ohne Richtung, davon unter 2.500 USD = erst seit 23.34 gesammelt), Eröffnungen ≥ 10k binnen 15 min (Live-Regel nachgerechnet)
    und die Einstiege von „Darwin-Liste live folgen“.
    """
    now = int(now or time.time())
    try:
        st = F.store_connect(store); schema(st)
        try:
            r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
            d = json.loads(r[0]) if r and r[0] else {}
            pos = st.execute("SELECT COUNT(*), COALESCE(SUM(p.status='offen'), 0) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                             "WHERE s.name='darwin_folgen' AND p.eroeffnet>=?", (now - 86_400,)).fetchone()
        finally:
            st.close()
    except (sqlite3.Error, ValueError) as e:
        return [f"Darwin-Prüfung: Prognosespeicher nicht lesbar ({type(e).__name__}: {e})"]
    konten = list(dict.fromkeys(str(a).lower() for a in list(d.get("reihe") or []) + list(d.get("liste") or [])))
    if not konten:
        return ["Darwin-Prüfung: Liste leer -- noch kein Konto qualifiziert (check_profis.py --alle zeigt die Gründe)"]
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute(f"SELECT ts, lower(addr), coin, dir, px, notional, tid FROM lb_fills WHERE ts>=? AND coin IN ({','.join('?' * len(COINS))}) "
                               f"AND lower(addr) IN ({','.join('?' * len(konten))}) ORDER BY ts, tid", (now - 86_400, *COINS, *konten)).fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [f"Darwin-Prüfung: Datenbank nicht lesbar ({type(e).__name__}: {e})"]
    n_auf = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_AUF)
    n_zu = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_ZU)
    klein = sum(1 for r in rows if (r[5] or 0) < min_usd_fill)
    ep = darwin_episoden(rows); rang = {a: i + 1 for i, a in enumerate(konten)}
    z = [f"Darwin-Prüfung (24 h): Liste {len(konten)} Konten · Fills in den Labor-Coins {len(rows)} (Eröffnungen {n_auf}, Schließungen {n_zu}, "
         f"ohne Richtung {len(rows) - n_auf - n_zu}; unter 2.500 USD {klein}) · Eröffnungen ≥ {DARWIN_MIN_USD / 1e3:.0f}k binnen "
         f"{DARWIN_FENSTER_S // 60} min: {len(ep)} · „Darwin-Liste live folgen“ eingestiegen: {pos[0] or 0} (offen {pos[1] or 0})"]
    if ep:
        z.append("  letzte Eröffnungen: " + " · ".join(f"{_uhr(e['ts'])} #{rang.get(e['addr'], '?')} {e['addr'][:6]}…{e['addr'][-4:]} {e['coin']} {e['seite']} "
                                                       f"{e['usd'] / 1e3:.0f}k ({e['n']} Fills" + (f", zur Hälfte geschlossen {_uhr(e['aus'])[7:]}" if e.get("aus") else "")
                                                       + ")" for e in ep[-5:][::-1]))
    if len(rows) - n_auf - n_zu > 0:
        z.append("  ohne Richtung = Stream-Fills von Konten, deren Position der Recorder noch nicht kannte -- für das Labor unsichtbar")
    return z


def gebuehren_pruefung(db: str, now: int | None = None, tage: int = 3) -> str | None:
    """23.34: Gebührensatz echter Fills (REST/userEvents: Richtung ohne Sternchen, Gebühr > 0) je Coin -- Prüfung der XMR-Annahme."""
    now = int(now or time.time())
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute("SELECT coin, fee / notional FROM lb_fills WHERE ts>=? AND coin IN ('BTC','ETH','XMR') AND fee > 0 AND notional > 0 "
                               "AND dir NOT LIKE '%*' AND dir <> 'stream' LIMIT 300000", (now - tage * 86_400,)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    je: dict = {}
    for c, q in rows:
        if q is not None and 0 < q < 0.01:
            je.setdefault(c, []).append(q)
    med = lambda v: sorted(v)[len(v) // 2]
    if len(je.get("XMR", [])) < 30 or len(je.get("BTC", []) + je.get("ETH", [])) < 30:
        return (f"Gebühren-Prüfung: zu wenige echte Fills mit Gebühr ({len(je.get('XMR', []))} XMR) -- Labor rechnet XMR mit "
                f"×{GEB_FAKTOR.get('XMR', 1.0):.1f}".replace(".", ","))
    std = med(je.get("BTC", []) + je.get("ETH", [])); x = med(je["XMR"])
    return (f"Gebühren-Prüfung ({tage} T, Median Gebühr/Umsatz echter Fills): BTC/ETH {std * 100:.4f} %, XMR {x * 100:.4f} % "
            f"-> XMR ≈ ×{x / std:.1f} der Standard-Perps (Labor rechnet ×{GEB_FAKTOR.get('XMR', 1.0):.1f}; Konten- und Taker/Maker-Mischung "
            f"verzerrt)").replace(".", ",")


def bericht_text(store: str, now: int | None = None, db: str | None = None) -> str:
    """Textbericht (Debug-Eintrag „labor“, Wochenplan): Stand, Kennzahlen je Strategie, beste je Coin, ALLE offenen Positionen,
    letzte Trades; mit db (23.34) auch die Darwin- und die Gebühren-Prüfung."""
    now = int(now or time.time()); d = uebersicht(store, {}, now); g = d["gesamt"]
    pc = lambda x, n=3: "—" if x is None else f"{x:+.{n}f} %"
    tt = lambda x: "—" if x is None else f"{x:+.1f}"
    qq = lambda x: "—" if x is None else f"{x * 100:.0f} %"
    usd = f"{NOTIONAL:,.0f}".replace(",", ".")
    seit = d.get("coins_seit") or {}
    gruppen: dict = {}
    for c in COINS:
        gruppen.setdefault(seit.get(c), []).append(c)
    coins_txt = "; ".join(f"{', '.join(cs)} seit {_uhr(t)}" for t, cs in sorted(gruppen.items(), key=lambda kv: kv[0] or 0))
    z = [f"TradeLabor · simulierter Handel, kein echtes Geld · {usd} USD je Trade · Start {_uhr(d['start'])} · "
         f"{g['strategien']} Strategien × {len(COINS)} Coins ({coins_txt})",
         f"Geschlossene Trades {g['trades']} (24 h: {g['trades_24h']}, netto {g['netto_24h']:+.2f} USD) · gesamt netto {g['netto_usd']:+.2f} USD, "
         f"Gebühren {g['gebuehren_usd']:.2f} · offen {g['offen']} ({g['offen_usd']:+.2f} USD) · Limit-Orders {g['orders']}",
         "Stufen: " + ", ".join(f"{k} {v}" for k, v in g["stufen"].items()),
         "Achtung: Bei vielen Strategien sehen einige zufällig gut aus. „Glück“ = Wahrscheinlichkeit, dass die beste von allen "
         "rein zufällig so gut aussähe. t, Glück und Stufen zählen BLÖCKE (Bl.): gleichzeitig eröffnete Trades einer Strategie "
         "(dasselbe Signal in mehreren Coins) sind eine Beobachtung. „bewährt“ erst mit ≥ 30 Blöcken, t ≥ 3, beide Hälften positiv, ≥ 14 Tage.", ""]
    z.append(f"{'Strategie':<34}{'Stufe':<11}{'n (Bl.)':>10}{'Treffer':>9}{'Ø netto':>10}{'t':>6}{'Glück':>7}{'Summe USD':>11}{'Ø/Tag':>9}"
             f"{'max DD':>8}  5× Hebel")
    for k in d["strategien"]:
        if not k["aktiv"] and not k["n"]:
            continue
        h5 = next((h for h in k["hebel"] if h["L"] == 5), None)
        h5t = "—" if not h5 else (f"{h5['liquidiert']}× liquidiert" if h5["liquidiert"] else f"Ø/Tag {pc(h5['tag_pct'], 2)}")
        nb = f"{k['n']} ({k.get('n_eff', 0)})"
        z.append(f"{k['titel'][:33]:<34}{k['stufe']:<11}{nb:>10}{qq(k['treffer']):>9}{pc(k['mittel_pct']):>10}{tt(k['t']):>6}"
                 f"{qq(k.get('p_glueck')):>7}{k['summe_usd']:>+11.2f}{pc(k.get('tag_pct'), 3):>9}{k['max_dd_usd']:>8.0f}  {h5t}"
                 + ("" if k["aktiv"] else "  (alte Regelversion)"))
    z.append("")
    z.append("Je Coin (Strategien mit mindestens 5 Trades, beste drei nach Summe):")
    for c in COINS:
        r = sorted(((k["titel"], k["je_coin"][c]) for k in d["strategien"] if c in k["je_coin"] and k["je_coin"][c]["n"] >= 5),
                   key=lambda x: -x[1]["summe_usd"])[:3]
        z.append(f"  {c:<5}" + (" · ".join(f"{t} {v['summe_usd']:+.0f} USD (n {v['n']}, t {tt(v['t'])})" for t, v in r) if r else "noch keine"))
    if db:
        z.append("")
        try:
            z += darwin_pruefung(db, store, now)
        except Exception as e:
            z.append(f"Darwin-Prüfung: {type(e).__name__}: {e}")
        try:
            gp = gebuehren_pruefung(db, now)
            if gp:
                z.append(gp)
        except Exception as e:
            z.append(f"Gebühren-Prüfung: {type(e).__name__}: {e}")
    z.append("")
    z.append(f"Offene Positionen ({len(d['offen'])}):")
    for o in d["offen"]:
        z.append(f"  {o['titel'][:30]:<31}{o['coin']:<5}{o['seite']:<6} seit {_uhr(o['eroeffnet'])} zu {o['preis_ein']:.6g}"
                 + (f" · Stop {o['sl']:.6g}" if o["sl"] else "") + (f" · Ziel {o['tp']:.6g}" if o["tp"] else "")
                 + (f" · bis {_uhr(o['ablauf'])}" if o.get("ablauf") else "") + f" · {(o['grund'] or '')[:90]}")
    z.append("")
    z.append("Letzte Ein- und Ausstiege:")
    for e in [e for e in d["ereignisse"] if e["art"] in ("eroeffnet", "geschlossen", "kaskade")][:30]:
        z.append(f"  {_uhr(e['ts'])} {e['titel'][:26]:<27}{(e['coin'] or ''):<5}{e['art']:<12}{e['text'][:150]}")
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
def _probe_datenbank(pfad: str, t_start: int, tage: int, seed: int = 7) -> dict:
    """Synthetischer Markt für den Selbsttest: 1-min-Kerzen, Buch je Minute, Funding, eine Kaskade mit Liquidationen,
    Heatmap-Cluster, ein Darwin-Konto mit Ein- und Ausstieg. Liefert die Kursreihe (ts -> close)."""
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
    """)
    n = tage * 1440; lp = math.log(100.0); kurs = {}
    crash = t_start + 3 * 86_400 + 5 * 3600                     # Tag 4, 05:00: Kaskade
    rows = []; book = []; ctx = []
    for i in range(n):
        t = t_start + i * 60
        schritt = rng.gauss(0, 0.0006)
        if crash <= t < crash + 600:
            schritt -= 0.003                                       # 3 % in 10 min
        elif crash + 900 <= t < crash + 1800:
            schritt += 0.0012                                      # Teil-Rücklauf
        o = math.exp(lp); lp += schritt; c = math.exp(lp)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.0002))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.0002)))
        rows.append((t, "AAA", o, hi, lo, c, 1000.0, 10)); kurs[t] = c
        book.append((t + 59, "AAA", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
        ctx.append((t, "AAA", c, c, c, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    liq = [(t_start + k * 3600, "AAA", "AAAUSDT", "long" if k % 2 else "short", 100.0, 1.0, 10_000.0) for k in range(tage * 24)]
    liq += [(crash + k * 60, "AAA", "AAAUSDT", "long", 100.0, 1.0, 500_000.0) for k in range(10)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", liq)
    hm = []
    for t in range(t_start + 86_400, t_start + n * 60, 600):     # ein großes Long-Cluster 1,2 σ(4 h) unter dem Kurs
        c = kurs[t // 60 * 60]
        hm.append((t, "AAA", c * (1 - 0.011), "long", 1_500_000.0, 5))            # 25 % des Stundenvolumens (6 Mio)
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm)
    t_d = t_start + 2 * 86_400 + 10 * 3600 + 17                 # Darwin-Konto: Long auf, 2 h später zu
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_d, "0xd1", "AAA", "perp", "Open Long", "B", kurs[t_d // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 1, 1),
                     (t_d + 7200, "0xd1", "AAA", "perp", "Close Long", "A", kurs[(t_d + 7200) // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 2, 0)])
    # 23.34 (Darwin v2): zweites Konto eröffnet Short in vier Stücken über drei Minuten (3k, 3k, 0,8k, 3,5k -- keines erreicht 10k,
    # zusammen 10,3k), verkleinert nach 1 h um 300 USD (darf den Folge-Ausstieg NICHT auslösen) und schließt 3 h später in zwei
    # Stücken. v1 hätte die Eröffnung nie gesehen.
    t_s = t_start + 3 * 86_400 + 14 * 3600 + 7
    stuecke = [(t_s, 3_000.0), (t_s + 50, 3_000.0), (t_s + 110, 800.0), (t_s + 170, 3_500.0)]
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t, "0xd2", "AAA", "perp", "Open Short*", "A", kurs[t // 60 * 60], u / kurs[t // 60 * 60], u, 0.0, 0.0, 10 + i, 0)
                     for i, (t, u) in enumerate(stuecke)]
                    + [(t_s + 3 * 3600 + k * 40, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3 * 3600) // 60 * 60], 50.0, 5_150.0,
                        0.0, 0.0, 20 + k, 1) for k in range(2)]
                    + [(t_s + 3600, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3600) // 60 * 60], 3.0, 300.0, 0.0, 0.0, 30, 1)])
    con.commit(); con.close()
    return {"kurs": kurs, "crash": crash, "darwin_t": t_d, "darwin2_t": t_s + 170}


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    # 1. Ausführungsmodell
    b = {"mid": 100.0, "spread_bps": 2.0, "kauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)], "verkauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)]}
    p1, bps1 = taker_preis(b, True, 10_000)
    p2, bps2 = taker_preis(b, True, 3e6)
    p3, _ = taker_preis(b, False, 10_000)
    ok("Markt-Order klein ≈ Briefkurs", abs(bps1 - 1.0) < 0.05 and p1 > 100.0, f"{bps1:.3f} bps über der Mitte")
    ok("Markt-Order groß mit Auswirkung", 6 < bps2 < 12 and p3 < 100.0, f"3 Mio: {bps2:.1f} bps im Mittel über die Tiefe, Verkauf 10k {p3:.4f}")
    ok("Jenseits der Tiefe pauschal", _auswirkung_bps(1e8, 1.0, [(10, 1e6)]) > 140, f"{_auswirkung_bps(1e8, 1.0, [(10, 1e6)]):.0f} bps")
    tmp = tempfile.mkdtemp(prefix="hl_labor_test_")
    try:
        db = os.path.join(tmp, "m.db"); sp = os.path.join(tmp, "f.db")
        T0 = 1_790_006_400 - 6 * 86_400
        info = _probe_datenbank(db, T0, 5)
        kurs = info["kurs"]
        st = F.store_connect(sp)
        rng = random.Random(3); drv = []; fc = []
        for t in range(T0, T0 + 5 * 86_400, 900):
            p0 = kurs.get(t // 60 * 60); p4 = kurs.get((t + 4 * 3600) // 60 * 60)
            if not p0 or not p4:
                continue
            richtig = rng.random() < 0.85
            s = (1 if p4 > p0 else -1) * (1 if richtig else -1) * 0.8
            drv += [(t, "AAA", "Wal-Flow 30 min", s), (t, "AAA", "Leaderboard-Flow 60 min", max(-1, min(1, rng.gauss(0, 0.6))))]
            fc.append((t, "AAA", p0, 0.0, p0, p0, json.dumps({"p_up_v2": 0.5, "kalib2": {"version": 2}}), 0.5, 0.5))
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, buy_px, sell_px, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?)", fc)
        st.execute("INSERT OR REPLACE INTO learned VALUES ('*', 'darwin', ?, ?)", (json.dumps({"reihe": ["0xd1", "0xd2"], "liste": ["0xd1", "0xd2"]}), T0))
        st.commit(); st.close()
        nur = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "darwin_folgen", "darwin_gegen", "docht_fangen", "kaskade_umkehr",
               "kaskade_fortsetzung", "zufall", "halten_long")
        L = None; t = T0 + 86_400; schritt = 120; i = 0; fehler = []
        while t < T0 + 5 * 86_400 - 120:
            if L is None or i % 400 == 0:
                if L is not None:
                    fehler += L.fehler
                L = Labor(db, sp, coins=("AAA",), nur=nur, adressfluss=os.path.join(tmp, "af.db"))     # Neustart-Probe
            L.zyklus(t)
            t += schritt; i += 1
        fehler += L.fehler
        n_vor = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        ende = T0 + 5 * 86_400
        for dt in (240, 300, 360, 420):                                   # Daten enden: Kurs veraltet -> keine neuen Einstiege
            L.zyklus(ende + dt)
        n_nach = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        veraltet = sum(1 for v in L.status.values() if v.get("blockiert") == "Kurs veraltet")
        fehler += L.fehler
        st = F.store_connect(sp)
        K = {k["name"]: k for k in kennzahlen(st, t)}
        pos = st.execute("SELECT COUNT(*), SUM(status='offen') FROM labor_position").fetchone()
        g_ein = st.execute("SELECT gebuehr_ein, notional, art_ein FROM labor_position WHERE art_ein LIKE 'Markt%' LIMIT 1").fetchone()
        dw_alle = [(e, g, s_, json.loads(w or "{}").get("konto"), zu) for e, g, s_, w, zu in st.execute(
            "SELECT p.eroeffnet, p.grund_aus, p.seite, p.werte, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_folgen'")]
        dw = [x for x in dw_alle if x[3] == "0xd1"]; dw2 = [x for x in dw_alle if x[3] == "0xd2"]
        dg = st.execute("SELECT p.seite FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_gegen' ORDER BY p.eroeffnet").fetchall()
        doc = st.execute("SELECT COUNT(*) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='docht_fangen' AND p.art_ein LIKE 'Limit%'").fetchone()[0]
        kas = st.execute("SELECT s.name, p.seite, p.eroeffnet FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name LIKE 'kaskade%'").fetchall()
        kas_e = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='kaskade'").fetchone()[0]
        st.close()
        w, wg, lb, zf = K["wale_folgen"], K["wale_gegen"], K["leaderboard_folgen"], K["zufall"]
        ok("Positivkontrolle: eingebaute Kante verdient", w["n"] >= 10 and (w["mittel_pct"] or 0) > 0 and (w["t"] or 0) >= 2,
           f"Wale folgen: {w['n']} Trades, Ø {w['mittel_pct'] or 0:+.3f} %, t {w['t'] or 0:+.1f}")
        ok("Gegenrichtung verliert", (wg["mittel_pct"] or 0) < 0, f"Gegen die Wale: Ø {wg['mittel_pct'] or 0:+.3f} %")
        ok("Rauschen ohne Scheinbeleg", lb["n"] >= 5 and abs(lb["t"] or 0) < 3, f"Leaderboard (Zufallstreiber): {lb['n']} Trades, t {lb['t'] or 0:+.1f}")
        ok("Zufall kostet", zf["n"] >= 5 and (zf["mittel_pct"] or 0) < 0.1, f"Zufall: {zf['n']} Trades, Ø {zf['mittel_pct'] or 0:+.3f} %")
        ok("Gebühr Taker 0,045 %", g_ein and abs(g_ein[0] - g_ein[1] * GEB_TAKER) < 1e-6, f"{g_ein[0]:.2f} USD auf {g_ein[1]:.0f}" if g_ein else "keine")
        ok("Darwin folgen: Ein- und Folge-Ausstieg", len(dw) == 1 and 0 <= dw[0][0] - info["darwin_t"] <= DARWIN_FRISCH_S and "schließt" in (dw[0][1] or "")
           and dw[0][2] == "long", f"{len(dw)} Trade(s), Einstieg {dw[0][0] - info['darwin_t'] if dw else '—'} s nach dem Konto, Ausstieg „{dw[0][1] if dw else '—'}“")
        ok("Darwin v2: Eröffnung in Stücken erkannt", len(dw2) == 1 and 0 <= dw2[0][0] - info["darwin2_t"] <= DARWIN_FRISCH_S and dw2[0][2] == "short"
           and "schließt" in (dw2[0][1] or "") and (dw2[0][4] or 0) >= info["darwin2_t"] + 3 * 3600 - 200 and len(dw_alle) == 2,
           f"{len(dw2)} Trade(s) aus 4 Stücken (3k+3k+0,8k+3,5k), Einstieg {dw2[0][0] - info['darwin2_t'] if dw2 else '—'} s nach dem letzten Stück; "
           f"Teilverkauf 300 USD nach 1 h ignoriert, Ausstieg {((dw2[0][4] or 0) - info['darwin2_t']) / 3600:.1f} h danach „{dw2[0][1] if dw2 else '—'}“; "
           f"insgesamt {len(dw_alle)} Darwin-Trades")
        ok("Darwin dagegen: Gegenseite", [x[0] for x in dg] == ["short", "long"], f"{[x[0] for x in dg] or '—'}")
        ok("Docht fangen: Limit gefüllt", doc >= 1, f"{doc} Füllungen über Limit-Orders")
        fs = [k for k in kas if k[0] == "kaskade_fortsetzung"]; um = [k for k in kas if k[0] == "kaskade_umkehr"]
        ok("Kaskade erkannt und gehandelt", kas_e >= 1 and fs and fs[0][1] == "short" and um and um[0][1] == "long" and um[0][2] > fs[0][2],
           f"{kas_e} Erkennung(en); Fortsetzung {fs[0][1] if fs else '—'}, Umkehr {um[0][1] if um else '—'}")
        ok("Keine Laufzeitfehler", not fehler, "; ".join(fehler[-3:]) or "keine")
        ok("Live-Tafel: Stand je Strategie", len(L.status) == len(nur) and all(v.get("text") for v in L.status.values()),
           f"{len(L.status)} Einträge, z. B. „{next(iter(L.status.values()))['text'] if L.status else '—'}“")
        ok("Positionen gespeichert", pos[0] >= 20, f"{pos[0]} Positionen, {pos[1] or 0} offen")
        ok("Veralteter Kurs: keine neuen Einstiege", n_nach == n_vor and veraltet >= 1, f"{n_nach - n_vor} neue Positionen, {veraltet} Strategien „Kurs veraltet“")
        # Hebel-Ansicht: Liquidation bei großem Rückgang im Trade
        s = _stat([{"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 0.5, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 0, "geschlossen": 1},
                   {"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 12.0, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 1, "geschlossen": 2}], 0, 86_400)
        h10 = next(h for h in s["hebel"] if h["L"] == 10); h3 = next(h for h in s["hebel"] if h["L"] == 3)
        ok("Hebel-Ansicht: Liquidation", h10["ausgeloescht"] == 2 and h3["ausgeloescht"] is None and abs(h10["summe_usd"] - (100 - NOTIONAL)) < 1e-6
           and abs(h3["summe_usd"] - 60) < 1e-6, f"10×: ausgelöscht nach Trade {h10['ausgeloescht']}, Summe {h10['summe_usd']:+.0f} USD; 3×: ×{h3['faktor']:.4f}, {h3['summe_usd']:+.0f} USD")
        # 23.34: Blockstatistik -- 40 gleichzeitige Trades (dasselbe Signal, ein 4-h-Block) sind EINE Beobachtung
        rng_b = random.Random(5)
        gleich = [{"netto_usd": 30.0, "netto_pct": 0.3 + rng_b.gauss(0, 0.05), "mae_pct": 0.2, "gebuehren": 9, "funding": 0, "slip": 1,
                   "eroeffnet": 1_790_000_000 + 60 * (i % 5), "geschlossen": 1_790_010_000} for i in range(40)]
        verteilt = [dict(x, eroeffnet=1_790_000_000 + i * 5 * 3600, geschlossen=1_790_000_000 + i * 5 * 3600 + 3000) for i, x in enumerate(gleich)]
        sg = _stat(gleich, 1_789_990_000, 1_790_020_000, 1.0, block_s=4 * 3600); sv = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0, block_s=4 * 3600)
        sr = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0)
        ok("Blockstatistik: gleichzeitige Trades zählen einmal", sg["n"] == 40 and sg["n_eff"] == 1 and sg["t"] is None and sg["stufe"] == "Kandidat"
           and sv["n_eff"] == 40 and abs((sv["t"] or 0) - (sr["t"] or 0)) < 1e-9 and (sv["t"] or 0) > 3,
           f"40 Trades in einem Block: n_eff {sg['n_eff']}, t {sg['t']}, Stufe {sg['stufe']} · verteilt: n_eff {sv['n_eff']}, t {sv['t'] or 0:+.1f}")
        kt = konten_tage(0, 10 * 86_400, {"BTC": 0, "XMR": 8 * 86_400}, ["BTC", "XMR"])
        st_k = _stat([{"netto_usd": 120.0, "netto_pct": 1.2, "mae_pct": 0.1, "gebuehren": 9, "funding": 0, "slip": 1, "eroeffnet": 100, "geschlossen": 200}],
                     0, 10 * 86_400, kt)
        ok("Kontotage: später gestarteter Coin zählt ab seinem Start", abs(kt - 12.0) < 1e-9 and abs(st_k["tag_pct"] - 120.0 / 12 / NOTIONAL * 100) < 1e-9,
           f"BTC 10 T + XMR 2 T = {kt:g} Kontotage, Ø/Tag {st_k['tag_pct']:.4f} %")
        mig = F.store_connect(os.path.join(tmp, "mig.db")); schema(mig)
        mig.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(T0),)); mig.commit()
        cs = coin_starts(mig, ("BTC", "ETH", "XMR"), T0 + 5 * 86_400, schreiben=True); cs2 = coin_starts(mig); mig.close()
        ok("Umstellung: alte Coins behalten den Start, XMR beginnt jetzt", cs == cs2 == {"BTC": T0, "ETH": T0, "XMR": T0 + 5 * 86_400},
           f"{ {c: (t - T0) // 86_400 for c, t in cs.items()} } Tage nach dem Laborstart")
        ok("Gebühr XMR (HIP-3) doppelt", abs(gebuehr("XMR", GEB_TAKER) - 0.0009) < 1e-12 and gebuehr("BTC", GEB_TAKER) == GEB_TAKER,
           f"Taker XMR {gebuehr('XMR', GEB_TAKER) * 100:.3f} %, BTC {gebuehr('BTC', GEB_TAKER) * 100:.3f} %")
        ep = darwin_episoden([(1000, "a", "X", "Open Long*", 1, 4000, 1), (1100, "a", "X", "Open Long*", 1, 4000, 2), (1150, "a", "X", "Close Long", 1, 8000, 3),
                              (1200, "a", "X", "Open Long*", 1, 6000, 4), (1250, "a", "X", "Close Long", 1, 300, 5), (1300, "a", "X", "Open Long*", 1, 5000, 6),
                              (2000, "a", "X", "Close Long", 1, 3000, 7), (2100, "a", "X", "Close Long", 1, 3000, 8), (4000, "a", "X", "Open Long*", 1, 12000, 9)])
        ok("Darwin-Nachrechnung: netto, halbe Schließung, neue Eröffnung", [(e["ts"], e["n"], round(e["usd"]), e["aus"]) for e in ep] == [(1300, 2, 10700, 2100), (4000, 1, 12000, None)],
           f"{[(e['ts'], e['n'], round(e['usd']), e['aus']) for e in ep]} (Soll: 1300 aus 2 Stücken 10,7k, Ausstieg 2100; neu 4000)")
        pt = (p_t_einseitig(3.4, 7), p_t_einseitig(2.0, 1000), p_t_einseitig(-1.0, 10), p_t_einseitig(0.0, 5))
        ok("Student-t: Glück bei wenigen Trades", abs(pt[0] - 0.00572) < 3e-4 and abs(pt[1] - 0.02288) < 3e-4 and abs(pt[2] - 0.8296) < 3e-4 and abs(pt[3] - 0.5) < 1e-9,
           f"t 3,4 bei 8 Trades: {pt[0] * 100:.2f} % (Normalverteilung {0.5 * math.erfc(3.4 / math.sqrt(2)) * 100:.3f} %)")
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p[1] for p in pruef)
    if verbose:
        print("TradeLabor -- Selbsttest (synthetischer Markt, fester Zeitpunkt)")
        for name, gut, text in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
        print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


if __name__ == "__main__":
    if "--selbsttest" in sys.argv or "--nulltest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--bericht" in sys.argv:
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv and sys.argv.index("--db") + 1 < len(sys.argv) else None
        print(bericht_text(F.STORE, db=db_))
        sys.exit(0)
    print("Aufruf: hl_labor.py --selbsttest | --bericht [--db PFAD]")
