"""
TradeLabor (23.33, Wunsch des Nutzers 27.09.2026): simulierter Handel (Paper-Trading) mit allen verarbeiteten Daten.

Kein echtes Geld, keine Order an eine Börse. Jede Strategie ist ein eigenes simuliertes Konto je Coin. Ihre Regeln werden
beim ersten Start eingefroren (Kennung name@hash der Regeln); jede spätere Änderung ergibt eine neue Kennung, die alte
bleibt mit ihrer Bilanz stehen. Damit ist jedes Ergebnis ein echter Vorwärtstest -- nichts wird rückwirkend angepasst.

Ausführung (bewusst vorsichtig gerechnet):
  Markt-Order   Mitte des 5-s-Orderbuchs (book_summary) plus halber Spread plus Marktauswirkung aus der Buchtiefe
                (kumulierte USD innerhalb 10/25/50/100 bps); ist das Buch älter als 90 s: letzter Minutenschluss mit
                Ersatz-Spread (BTC/ETH 1 bp, sonst 4 bp) und 2 bps Aufschlag
  Limit-Order   gefüllt nur, wenn eine spätere 1-min-Kerze DURCH den Preis läuft (Tief < Limit bzw. Hoch > Limit) oder der
                beste Gegenkurs den Preis unterschreitet; in der Füll-Kerze zählt danach nur noch der Stop
  Gebühren      Taker 0,045 %, Maker 0,015 % (Basisstufe Hyperliquid); Ziel = Maker, Stop, Zeit und Folge-Ausstieg = Taker
  Funding       stündlich aus ctx_bars (Longs zahlen bei positiver Rate, Shorts erhalten sie)
  Stop/Ziel     auf 1-min-Kerzen; liegen beide in derselben Kerze, gilt der Stop; Kurslücke über den Stop hinweg: Ausführung
                zum Eröffnungskurs der Kerze; die Einstiegs-Minute einer Markt-Order wird nicht geprüft (sie lag davor)
  Takt          alle 15 s; ein Signal wird zum Kurs des Taktes ausgeführt, in dem es erkannt wird

23.34 (Nutzer 29.09.):
  XMR           fünfter Coin. XMR läuft auf Hyperliquid als HIP-3-Markt: zur Protokollgebühr kommt der Anteil des Betreibers
                (0–300 %, je Markt eingestellt); angenommen 100 % = doppelte Sätze (GEB_FAKTOR). Jeder Coin zählt ab seinem eigenen
                Start (labor_zustand „coins“) -- die Tagesrendite teilt durch die Kontotage, nicht durch Laufzeit × Coins.
  Statistik     t, „Glück“, Hälften und Stufen auf BLÖCKEN: Trades einer Strategie, die im selben Block ihres Horizonts h eröffnet
                wurden (meist dasselbe Signal in mehreren Coins zugleich), zählen als EINE Beobachtung (ihr Mittel). Vorher zählte
                jeder Coin-Trade einzeln -- vier gleichzeitige Trades auf korrelierten Coins vervierfachten scheinbar den Beleg.
  Darwin v2     Eröffnungen eines Kontos der Darwin-Liste werden je Coin und Seite über 15 min aufsummiert (auch in kleinen Stücken;
                der Recorder sammelt ihre Fills seit 23.34 ohne Mindestbetrag). Vorher zählte nur, was in einem Takt zusammenkam --
                in Stücke unter 10k zerlegte Eröffnungen blieben unsichtbar. Neue Regeln = neue Kennung; die alte Bilanz bleibt stehen.
"""
import hashlib
import json
import math
import os
import random
import sqlite3
import sys
import time

import hl_adressfluss
import hl_forecast as F

COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")      # 23.34: XMR dazu (Wunsch 29.09.)
COINS_2333 = ("BTC", "ETH", "ZEC", "HYPE")        # Stand 23.33 -- Übernahme des gemeinsamen Starts bei der Umstellung auf Kontotage
NOTIONAL = 10_000.0              # USD je Trade (Vorschlag 27.09., im Dashboard angezeigt)
GEB_TAKER = 0.00045
GEB_MAKER = 0.00015
TAKT_S = 15
BUCH_MAX_ALTER = 90
KURS_FRISCH_S = 150             # älterer Kurs (Recorder steht?): keine neuen Einstiege, keine Live-Prüfung -- die Minutenkerzen holen nach
PAUSE_S = 900                   # nach einem Ausstieg wartet die Strategie im selben Coin 15 min
HEBEL = (1, 3, 5, 10)
LIQ_SCHWELLE = 0.9              # Hebel-Ansicht: liquidiert, wenn der Rückgang im Trade 90 % der Marge (1/Hebel) erreicht
EREIGNIS_TAGE = 90
ERSATZ_SPREAD_BPS = {"BTC": 1.0, "ETH": 1.0}
SIGMA_ERSATZ = {"BTC": 0.008, "ETH": 0.011, "ZEC": 0.025, "HYPE": 0.02, "XMR": 0.02}
GEB_FAKTOR = {"XMR": 2.0}       # 23.34: HIP-3-Markt -- Protokollgebühr plus Betreiberanteil (0–300 %), angenommen 100 %
DARWIN_MIN_USD = 10_000.0
DARWIN_FRISCH_S = 180           # der jüngste Fill einer Eröffnung darf höchstens so alt sein, wenn die Summe die Schwelle erreicht
DARWIN_FENSTER_S = 900          # 23.34: Eröffnungen je Konto, Coin und Seite über 15 min aufsummiert
DARWIN_EPISODE_S = 12 * 3600    # eine erkannte Eröffnung gilt bis zum Schließen, höchstens 12 h (danach darf dasselbe Konto neu auslösen)
DARWIN_AUS_ANTEIL = 0.5         # 23.34: Folge-Ausstieg erst, wenn das Konto mindestens die Hälfte der erkannten Eröffnung wieder schließt
KASKADE_Z = 2.5
KASKADE_FENSTER_S = 3600
FRISCH_S = {"preis": 90, "treiber": 1800, "familie": 1800, "prognose": 1800, "anker": 1800, "docht": 1800, "funding": 900,
            "adressstrom": 300, "kaskade": 120, "staerke": 3600, "darwin": 900, "elite": 900, "sigma": 1800}
# 23.40 (Nutzer 01.10.): Grid-Bots -- Long und das Spiegelbild Short, je Coin ein Konto über GRID_KAPITAL, auf die Stufen verteilt
GRID_NAMEN = ("grid_long", "grid_short")
GRID_KAPITAL = NOTIONAL          # 10.000 USD je Coin-Konto (vergleichbar mit „10.000 USD je Trade“ der übrigen Strategien)
GRID_TAG_S = 300                 # Bestandswert für die Tagesbilanz alle 5 min und nach jeder Änderung festhalten
# 23.42 (KONZEPT_Fusion.md, Stufe 1): Fusion mit Kostenschwelle -- eingestiegen wird nur, wenn der erwartete Vorsprung die Kosten eines
# Hin- und Rückwegs zum Marktpreis um diesen Faktor übersteigt (die Hälfte der Kosten als Puffer gegen den Schätzfehler von p)
FUSION_PUFFER = 1.5

SCHEMA = """
CREATE TABLE IF NOT EXISTS labor_strategie (sid TEXT PRIMARY KEY, name TEXT, titel TEXT, gruppe TEXT, regeln TEXT, beschreibung TEXT,
    erstellt INTEGER, aktiv INTEGER);
CREATE TABLE IF NOT EXISTS labor_position (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, status TEXT,
    eroeffnet INTEGER, preis_ein REAL, notional REAL, menge REAL, art_ein TEXT, gebuehr_ein REAL, slip_ein REAL,
    sl REAL, tp REAL, ablauf INTEGER, grund TEXT, werte TEXT, folge TEXT, geprueft_bis INTEGER, nur_stop_bis INTEGER,
    funding REAL DEFAULT 0, funding_bis INTEGER, mae_pct REAL DEFAULT 0, mfe_pct REAL DEFAULT 0,
    geschlossen INTEGER, preis_aus REAL, art_aus TEXT, gebuehr_aus REAL, slip_aus REAL, grund_aus TEXT,
    brutto_usd REAL, netto_usd REAL, netto_pct REAL);
CREATE INDEX IF NOT EXISTS ix_lp_offen ON labor_position(status, coin);
CREATE INDEX IF NOT EXISTS ix_lp_zu ON labor_position(geschlossen);
CREATE TABLE IF NOT EXISTS labor_order (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, preis REAL,
    erstellt INTEGER, gueltig_bis INTEGER, status TEXT, grund TEXT, werte TEXT, sl_rel REAL, tp_rel REAL, sl_px REAL, tp_px REAL,
    halten_s INTEGER, geprueft_bis INTEGER, erledigt INTEGER, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_lo_offen ON labor_order(status, coin);
CREATE TABLE IF NOT EXISTS labor_ereignis (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, sid TEXT, coin TEXT, art TEXT,
    seite TEXT, preis REAL, text TEXT, netto_usd REAL, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_le_ts ON labor_ereignis(ts);
CREATE TABLE IF NOT EXISTS labor_zustand (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS labor_grid_tag (sid TEXT, coin TEXT, tag INTEGER, unreal REAL, lose INTEGER, px REAL, ts INTEGER,
    PRIMARY KEY (sid, coin, tag));
CREATE INDEX IF NOT EXISTS ix_lp_sid ON labor_position(sid, status);
"""


# ------------------------------------------------------------------------------------------------ Strategien
def _gen(name, titel, gruppe, fn, regeln, eingaben, beschreibung):
    return {"name": name, "titel": titel, "gruppe": gruppe, "fn": fn, "regeln": dict(regeln, v=1), "eingaben": eingaben,
            "beschreibung": beschreibung}


def strategien() -> list:
    """Die eingefrorenen Strategien. Jede Änderung an „regeln“ ergibt eine neue Kennung (neue Bilanz)."""
    S = []
    std = {"sl": 1.5, "tp": 2.0}
    for key, titel, treiber, h in (("wale", "Wale", "Wal-Flow 30 min", 4), ("leaderboard", "Leaderboard", "Leaderboard-Flow 60 min", 4),
                                   ("smartmoney", "Smart Money", "Smart Money (direktional)", 12), ("pool", "Pool", "Pool-Flow 4 h", 4)):
        for inv in (False, True):
            S.append(_gen(f"{key}_{'gegen' if inv else 'folgen'}", (f"Gegen {titel}" if inv else f"{titel} folgen"), "Händler", "schwelle",
                          dict(std, quelle="treiber", schluessel=treiber, schwelle=0.5, h=h, invert=inv), [f"treiber:{treiber}"],
                          f"Treiber „{treiber}“ ≥ +0,5 → {'Short' if inv else 'Long'}, ≤ −0,5 → {'Long' if inv else 'Short'}; "
                          f"Stop 1,5 σ, Ziel 2 σ, spätestens nach {h} h"))
    for inv in (False, True):
        # 23.34 (Darwin v2): fenster_s -- Eröffnungen über 15 min aufsummiert (neue Kennung; v1 zählte nur, was in einem Takt zusammenkam)
        # 23.37: liste=2 -- die Liste entsteht nach den Regeln v2 (Aufnahme streng, Verbleib großzügig, 14 T); neue Kennung, damit die
        # Bilanz nicht zwei verschiedene Listen vermischt. 23.38: liste=3 -- Regeln v3 (die Schonung nur nach strenger Aufnahme; beim
        # Umstieg fliegen Altbestand und Rückkehrer ohne sie), wieder eine neue Kennung
        S.append(_gen(f"darwin_{'gegen' if inv else 'folgen'}", "Gegen die Darwin-Liste" if inv else "Darwin-Liste live folgen", "Händler",
                      "darwin", dict(std, h=12, min_usd=DARWIN_MIN_USD, invert=inv, fenster_s=DARWIN_FENSTER_S, aus_anteil=DARWIN_AUS_ANTEIL, liste=3), ["darwin"],
                      f"Eröffnet ein Konto der Darwin-Liste im Coin netto mindestens {DARWIN_MIN_USD / 1e3:.0f}k binnen {DARWIN_FENSTER_S // 60} min "
                      f"(auch in kleinen Stücken; Schließungen dazwischen ziehen ab; der jüngste Fill höchstens {DARWIN_FRISCH_S // 60} min alt), "
                      f"{'handeln wir dagegen' if inv else 'handeln wir mit'}; je Eröffnung einmal. Ausstieg, wenn das Konto mindestens die Hälfte "
                      "davon wieder schließt, sonst Stop 1,5 σ, Ziel 2 σ, spätestens nach 12 h. Liste nach den Regeln v3 (23.38)"))
    for inv in (False, True):
        # 23.39 (Nutzer 30.09.: „Elite und Aktive Profis als Vorlage vergleichen“): die Elite des Coins als Vorlage -- dieselbe Kopier-Regel
        # wie bei der Darwin-Liste, damit die beiden Vorlagen vergleichbar sind. Unterschied: Fills der Elite liegen erst ab 2.500 USD vor
        # (Stream), die der Darwin-Liste auch darunter
        S.append(_gen(f"elite_{'gegen' if inv else 'folgen'}", "Gegen die Elite" if inv else "Elite live folgen", "Händler",
                      "elite", dict(std, h=12, min_usd=DARWIN_MIN_USD, invert=inv, fenster_s=DARWIN_FENSTER_S, aus_anteil=DARWIN_AUS_ANTEIL), ["elite"],
                      f"Eröffnet ein Konto der Elite dieses Coins (Konto-Score mit belegtem 4-h-Vorlauf, Gewinn- und Aktivitätsschranke, ohne "
                      f"Gesperrte; das Dashboard stellt sie täglich neu auf) im Coin netto mindestens {DARWIN_MIN_USD / 1e3:.0f}k binnen "
                      f"{DARWIN_FENSTER_S // 60} min (Fills ab 2.500 USD; der jüngste höchstens {DARWIN_FRISCH_S // 60} min alt), "
                      f"{'handeln wir dagegen' if inv else 'handeln wir mit'}; je Eröffnung einmal. Ausstieg, wenn das Konto mindestens die Hälfte "
                      "davon wieder schließt, sonst Stop 1,5 σ, Ziel 2 σ, spätestens nach 12 h -- dieselbe Regel wie „Darwin-Liste live folgen“"))
    S.append(_gen("prognose_v1", "Prognose v1", "Prognose", "prognose", dict(std, feld="p_up_v1", schwelle=0.08, h=4), ["prognose"],
                  "P(aufwärts 4 h) der Kalibrierung v1 ≥ 58 % → Long, ≤ 42 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("prognose_v2", "Prognose v2", "Prognose", "prognose", dict(std, feld="p_up_v2", schwelle=0.10, h=4), ["prognose"],
                  "P(aufwärts 4 h) des korrigierten v2 (Version ≥ 2) ≥ 60 % → Long, ≤ 40 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    # 23.42 (KONZEPT_Fusion.md): die Fusionsprognose -- einmal mit der festen Schwelle von v1, einmal mit der Kostenschwelle. So zeigt der
    # Vergleich beider an DERSELBEN Prognose, was der Kostenfilter bringt
    S.append(_gen("prognose_fusion", "Prognose Fusion", "Prognose", "prognose", dict(std, feld="p_fusion", schwelle=0.08, h=4), ["prognose"],
                  "P(aufwärts 4 h) der Fusionsprognose (Mischung aus Basisrate, v1, v2, v3 und Analog-Suche; hl_fusion) ≥ 58 % → Long, ≤ 42 % → "
                  "Short; Stop 1,5 σ, Ziel 2 σ, 4 h -- dieselbe Schwelle wie „Prognose v1“"))
    S.append(_gen("prognose_fusion_kosten", "Fusion mit Kostenschwelle", "Prognose", "fusion", dict(std, feld="p_fusion", h=4, puffer=FUSION_PUFFER),
                  ["prognose"],
                  "Erwarteter Vorsprung |2p − 1| · E|r 4 h| (p = Fusionsprognose, E|r| = mittlere 4-h-Bewegung des Coins in den letzten 30 Tagen) "
                  "mindestens das 1,5-Fache der Kosten eines Hin- und Rückwegs zum Marktpreis (Taker-Gebühr beider Seiten plus Abstand zur "
                  "Buchmitte bei 10.000 USD, aus dem Buch im Takt) → in Richtung der Prognose; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("empfehlung_limit", "Kauf-/Verkaufspreise der Prognose", "Prognose", "empfehlung", {"h": 12, "sl": 1.5}, ["prognose"],
                  "Bias ≥ +0,12: Kauf-Limit am empfohlenen Kaufpreis, Ziel am Verkaufspreis; Bias ≤ −0,12 umgekehrt; "
                  "Order 12 h gültig, Stop 1,5 σ(12 h), spätestens 12 h nach der Füllung"))
    for key, fam in (("grosskonten", "Großkonten-Fluss"), ("trend", "Trend lang"), ("momentum", "Momentum kurz"), ("orderfluss", "Orderfluss"),
                     ("funding", "Funding"), ("etf", "ETF"), ("analog", "Analog"), ("pool", "Pool-Konten"), ("profi", "Profi-Flow")):
        h = {"Trend lang": 24, "Momentum kurz": 1, "Orderfluss": 1, "Funding": 24, "ETF": 24, "Analog": 24}.get(fam, 4)
        S.append(_gen(f"familie_{key}", f"Familie {fam}", "Familien", "schwelle",
                      dict(std, quelle="familie", schluessel=fam, schwelle=0.35, h=h, invert=False), [f"familie:{fam}"],
                      f"Familienwert „{fam}“ ≥ +0,35 → Long, ≤ −0,35 → Short; Stop 1,5 σ, Ziel 2 σ, {h} h"))
    S.append(_gen("kaskade_umkehr", "Kaskaden-Umkehr", "Ereignisse", "kaskade", {"modus": "umkehr", "h": 4}, ["kaskade"],
                  f"Nach einer Kaskade (Kurs ≥ {KASKADE_Z:g} σ in 15 min und Liquidationen über dem 95.-Perzentil der Woche): erste "
                  "Gegenkerze binnen 30 min → Einstieg gegen die Bewegung; Stop 0,5 σ(15 min) hinter dem Extrem, Ziel halber Rücklauf, 4 h"))
    S.append(_gen("kaskade_fortsetzung", "Kaskaden-Fortsetzung", "Ereignisse", "kaskade", {"modus": "fortsetzung", "h": 2}, ["kaskade"],
                  "Dieselbe Erkennung, Einstieg sofort IN Richtung der Bewegung; Stop 1 σ(1 h), Ziel 1,5 σ(1 h), 2 h"))
    S.append(_gen("docht_fangen", "Docht fangen", "Ereignisse", "docht", {"h": 6, "abstand": 0.25, "sl": 1.0, "tp": 1.0, "min_anteil": 0.10},
                  ["docht"], "Limit-Order 0,25 σ(1 h) jenseits des nächsten großen Liquidationsclusters (ab 10 % des Stundenvolumens, "
                  "0,5–3 σ entfernt), 4 h gültig; Ziel und Stop je 1 σ(1 h), spätestens 6 h nach der Füllung"))
    S.append(_gen("magnet", "Magnet", "Ereignisse", "magnet", {"h": 12, "a_min": 0.5, "min_anteil": 0.10}, ["anker"],
                  "Heatmap-Anker |A| ≥ 0,5 mit Cluster ab 10 % des Stundenvolumens 0,5–2 σ entfernt → Einstieg Richtung Cluster, "
                  "Ziel knapp davor, Stop 1 σ(4 h), 12 h"))
    S.append(_gen("funding_extrem", "Funding-Extrem", "Ereignisse", "funding", dict(std, z=2.0, h=24), ["funding"],
                  "Funding-Rate ≥ 2 Standardabweichungen über ihrem 14-Tage-Mittel → Short, ebenso weit darunter → Long; "
                  "Stop 1,5 σ, Ziel 2 σ, 24 h"))
    S.append(_gen("ausbruch_ruhe", "Ausbruch nach Ruhe", "Ereignisse", "ausbruch", {"h": 8, "schwelle": 0.5}, ["staerke"],
                  "Stärke ≥ 0,5 (Ruhe vor dem Sturm) macht scharf; läuft der Kurs binnen 4 h 1 σ(1 h) weg, Einstieg in diese Richtung; "
                  "Stop am Ausgangspunkt, Ziel 2,5 σ(1 h), 8 h"))
    S.append(_gen("twap_druck", "TWAP-Druck", "Ereignisse", "twap", dict(std, anteil=0.02, h=4), ["adressstrom"],
                  "Netto-Fluss laufender TWAP-Aufträge der letzten 60 min ≥ 2 % des Stundenvolumens → in dieselbe Richtung; "
                  "Stop 1,5 σ, Ziel 2 σ, 4 h (wartet, bis TWAP-Trades im Adress-Strom erkannt werden)"))
    # 23.40 (Nutzer 01.10.): Grid-Bot -- Range automatisch erkennen und nachführen, eine starke Bewegung in Gewinnrichtung aussitzen statt
    # zu früh zu verkaufen (Trailing-Stop vom Extrem), Notausstieg bei starker Bewegung dagegen; Long und das Spiegelbild Short.
    # Alle Lose eines Coins teilen sich GRID_KAPITAL; bewertet wird je Tag nach Bestandswert (grid_tage), nicht nur realisiert.
    # Probe (synthetischer Markt): Ein Auslöser nur über 15 min kam in einer schnellen Rallye zu spät -- ein enges Grid hatte seinen Bestand
    # schon auf den Stufen verkauft; deshalb zusätzlich 5 min. Ein Trendmaß ohne Richtung ließ Grid Long dreimal in einen langsamen
    # Abwärtstrend hinein aufbauen (jedes Mal Notausstieg); deshalb streng gegen das Grid (1), großzügig mit ihm (2), und längere Pausen
    # nach wiederholten Notausstiegen.
    grid = {"fenster_h": 24, "p_rand": 0.10, "trend_gegen": 1.0, "trend_mit": 2.0, "zone": 0.20, "stufen_min": 4, "stufen_max": 12,
            "schritt_min": 0.002, "pruef_min": 60, "verschiebung": 1.0, "breite_rel": 0.25, "startbestand": True, "bewegung_z": 3.0,
            "z_fenster_min": [5, 15], "trail": 1.5, "puffer": 1.0, "pause_notaus_h": [4, 12, 24], "pause_trail_h": 2, "kapital": GRID_KAPITAL,
            "h": 24}
    kap = f"{GRID_KAPITAL:,.0f}".replace(",", ".")
    gemeinsam = ("Range aus den 1-min-Kursen der letzten 24 h (10.–90. Perzentil). Start und Nachführen nur ohne Trend gegen das Grid: "
                 "Netto-Bewegung im Fenster höchstens 1-mal ihre eigene Schwankung dagegen und 2-mal in Grid-Richtung; Start nur mit dem Kurs im "
                 f"mittleren Teil der Range. 4–12 Stufen, je mindestens 0,2 % Abstand; {kap} USD je Coin gleichmäßig auf die Stufen verteilt. "
                 "Stündlich nachgeführt, wenn sich die Range um eine Stufe verschiebt oder ihre Breite um ein Viertel ändert. Nach einem "
                 "Notausstieg 4 h Pause, nach dem zweiten binnen 24 h 12 h, nach dem dritten 24 h; die neue Range nur aus Kursen danach. ")
    S.append(_gen("grid_long", "Grid Long", "Grid", "grid", dict(grid, richtung="long"), ["grid", "kaskade"],
                  gemeinsam + "Startbestand: Lose für die Stufen über dem Kurs zum Marktpreis, darunter Kauf-Limits; jedes Los verkauft eine Stufe "
                  "höher (Maker), danach liegt dort wieder ein Kauf-Limit. Starke Bewegung aufwärts (≥ 3 σ in 5 oder 15 min in der oberen Hälfte "
                  "der Range, Short-Squeeze, Kurs eine Stufe über der Range): Verkäufe aussetzen, alle Lose halten, Trailing-Stop 1,5 σ(1 h) unter "
                  "dem höchsten Hoch; danach 2 h Pause. Notausstieg (alle Lose zum Marktpreis): Liquidationskaskade abwärts, ≥ 3 σ Fall in 15 min "
                  "in der unteren Hälfte der Range oder Kurs eine Stufe unter der Range"))
    S.append(_gen("grid_short", "Grid Short", "Grid", "grid", dict(grid, richtung="short"), ["grid", "kaskade"],
                  gemeinsam + "Spiegelbild von „Grid Long“: Startbestand Short-Lose für die Stufen unter dem Kurs, darüber Verkaufs-Limits; jedes Los "
                  "kauft eine Stufe tiefer zurück (Maker), danach liegt dort wieder ein Verkaufs-Limit. Starke Bewegung abwärts (≥ 3 σ in 5 oder "
                  "15 min in der unteren Hälfte der Range, Long-Kaskade, Kurs eine Stufe unter der Range): Rückkäufe aussetzen, alle Lose halten, "
                  "Trailing-Stop 1,5 σ(1 h) über dem tiefsten Tief; danach 2 h Pause. Notausstieg: Short-Squeeze, ≥ 3 σ Anstieg in 15 min in der "
                  "oberen Hälfte der Range oder Kurs eine Stufe über der Range"))
    S.append(_gen("zufall", "Zufall (Kontrolle)", "Kontrolle", "zufall", dict(std, h=4, rate_h=8), [],
                  "Zufälliger Einstieg (im Schnitt alle 8 h, wenn flach), zufällige Richtung; Stop 1,5 σ, Ziel 2 σ, 4 h -- zeigt, "
                  "was Gebühren und Zufall kosten"))
    S.append(_gen("halten_long", "Halten Long (Vergleich)", "Kontrolle", "halten", {"h": 168}, [],
                  "Immer Long, alle 7 Tage neu eröffnet -- zeigt, was der Markt ohne jedes Signal gebracht hat"))
    for s in S:
        s["sid"] = s["name"] + "@" + hashlib.sha1(json.dumps(s["regeln"], sort_keys=True).encode()).hexdigest()[:8]
    return S


# ------------------------------------------------------------------------------------------------ Hilfen
def _j(x):
    return json.dumps(x, separators=(",", ":"), ensure_ascii=False, default=float)


def schema(st) -> None:
    st.executescript(SCHEMA)


def gebuehr(coin: str, satz: float) -> float:
    """Gebührensatz eines Coins: Grundsatz (Taker/Maker) mal GEB_FAKTOR (23.34: HIP-3-Märkte wie XMR mit Betreiberanteil)."""
    return satz * GEB_FAKTOR.get(coin, 1.0)


def _gegen(seite: str) -> str:
    return "short" if seite == "long" else "long"


def _uhr(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(ts)) if ts else "—"


def _auswirkung_bps(notional: float, halb_bps: float, baender: list) -> float:
    """Mittlerer Abstand zur Buchmitte in bps für eine Markt-Order: der erste Dollar am besten Kurs (halber Spread), danach
    steigt der Preis linear durch die kumulierten Tiefenbänder (USD innerhalb 10/25/50/100 bps); jenseits pauschal 150 bps."""
    b_prev, d_prev, summe, rest = max(halb_bps, 0.0), 0.0, 0.0, notional
    for b, d in baender:
        if d is None or d <= d_prev or b <= b_prev:
            continue
        seg = d - d_prev; nimm = min(rest, seg)
        summe += nimm * (b_prev + (b - b_prev) * (nimm / seg) / 2)
        rest -= nimm
        if rest <= 1e-9:
            break
        b_prev, d_prev = b, d
    if rest > 1e-9:
        summe += rest * max(150.0, b_prev)
    return summe / notional if notional > 0 else halb_bps


def taker_preis(b: dict, kauf: bool, notional: float) -> tuple:
    """(Ausführungspreis, Abstand zur Mitte in bps) einer Markt-Order."""
    halb = max(float(b.get("spread_bps") or 0.0), 0.0) / 2
    baender = b.get("kauf" if kauf else "verkauf") or []
    bps = _auswirkung_bps(notional, halb, baender) if baender else halb + 2.0
    return (b["mid"] * (1 + bps / 1e4) if kauf else b["mid"] * (1 - bps / 1e4)), bps


def buch_jetzt(con, coin: str, now: int):
    try:
        r = con.execute("SELECT ts, bid, ask, spread_bps, bid_10, ask_10, bid_25, ask_25, bid_50, ask_50, bid_100, ask_100 "
                        "FROM book_summary WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - BUCH_MAX_ALTER, now, coin)).fetchone()
    except sqlite3.Error:
        r = None
    if r and r[1] and r[2] and r[2] >= r[1]:
        bid, ask = float(r[1]), float(r[2]); mid = (bid + ask) / 2
        sp = float(r[3]) if r[3] is not None else (ask - bid) / mid * 1e4
        return {"ts": int(r[0]), "bid": bid, "ask": ask, "mid": mid, "spread_bps": sp, "quelle": "Orderbuch",
                "kauf": [(10, r[5]), (25, r[7]), (50, r[9]), (100, r[11])], "verkauf": [(10, r[4]), (25, r[6]), (50, r[8]), (100, r[10])],
                "tiefe10": (r[4] or 0) + (r[5] or 0)}
    try:
        k = con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
    except sqlite3.Error:
        k = None
    if k and k[1]:
        mid = float(k[1]); sp = ERSATZ_SPREAD_BPS.get(coin, 4.0)
        return {"ts": int(k[0]) + 60, "bid": mid * (1 - sp / 2e4), "ask": mid * (1 + sp / 2e4), "mid": mid, "spread_bps": sp,
                "quelle": "Minutenkerze (Buch fehlt)", "kauf": [], "verkauf": [], "tiefe10": None}
    return None


def kerzen(con, coin: str, t0: int, t1: int) -> list:
    """Abgeschlossene 1-min-Kerzen mit t0 <= ts < t1: (ts, open, high, low, close)."""
    try:
        return [tuple(r) for r in con.execute("SELECT ts, open, high, low, close FROM bars WHERE ts>=? AND ts<? AND coin=? ORDER BY ts",
                                              (t0, t1, coin)).fetchall() if r[4]]
    except sqlite3.Error:
        return []


def sigma_4h(con, coin: str, now: int) -> tuple:
    """(σ der 4-h-Rendite aus 15-min-Schlusskursen der letzten 7 Tage, belastbar?, σ der letzten 4 h auf derselben Skala).
    Gezielte Abfrage der 673 Rasterpunkte über den Primärschlüssel (ts, coin) statt eines Bereichs über alle Coins."""
    letzte = now // 900 * 900 - 60
    raster = [letzte - 900 * k for k in range(7 * 96, -1, -1)]
    try:
        rows = con.execute(f"SELECT ts, close FROM bars WHERE coin=? AND ts IN ({','.join('?' * len(raster))}) ORDER BY ts",
                           (coin, *raster)).fetchall()
    except sqlite3.Error:
        rows = []
    r = []; prev = None
    for ts, c in rows:
        if prev and c and prev[1] and ts - prev[0] == 900:
            r.append(math.log(c / prev[1]))
        prev = (ts, c)
    if len(r) < 96:
        return SIGMA_ERSATZ.get(coin, 0.02), False, None
    m = sum(r) / len(r); sd = math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1))
    kurz = r[-16:]; mk = sum(kurz) / len(kurz)
    sdk = math.sqrt(sum((x - mk) ** 2 for x in kurz) / max(len(kurz) - 1, 1))
    return max(sd * 4, 1e-4), True, sdk * 4


def volumen_1h(con, coin: str, now: int):
    """Median des Stundenvolumens (USD) der letzten 24 abgeschlossenen Stunden."""
    t1 = now // 3600 * 3600
    try:
        w = sorted(v for _, v in con.execute("SELECT ts/3600, SUM(volume*close) FROM bars WHERE ts>=? AND ts<? AND coin=? GROUP BY 1",
                                             (t1 - 24 * 3600, t1, coin)).fetchall() if v)
    except sqlite3.Error:
        w = []
    return w[len(w) // 2] if len(w) >= 6 else None


# ------------------------------------------------------------------------------------------------ Grid-Hilfen (23.40)
def grid_kurse(con, coin: str, von: int, bis: int) -> list:
    """1-min-Schlusskurse [(ts, close)] mit von <= ts < bis."""
    try:
        return [(int(t), float(c)) for t, c in con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<? AND coin=? ORDER BY ts",
                                                           (int(von), int(bis), coin)) if c]
    except sqlite3.Error:
        return []


def grid_range(kurse: list, p_rand: float = 0.10) -> dict | None:
    """
    Range aus 1-min-Schlusskursen [(ts, close)]: unten/oben = Perzentile p_rand und 1 − p_rand (einzelne Spitzen zählen nicht).
    Trend (mit Vorzeichen) = Netto-Bewegung in Einheiten der eigenen Schwankung: ln(Ende/Anfang) / (σ der 5-min-Renditen · √Anzahl). Für
    einen reinen Zufallsweg standardnormal, unabhängig von der Fensterlänge (|Trend| ≤ 1 in 68 %, ≤ 2 in 95 % der Fälle).
    """
    if len(kurse) < 120:
        return None
    s = sorted(c for _, c in kurse)
    q = lambda p: s[min(len(s) - 1, max(0, int(round(p * (len(s) - 1)))))]
    c5 = [c for t, c in kurse if t % 300 == 240]
    trend = None
    r = [math.log(c5[i] / c5[i - 1]) for i in range(1, len(c5)) if c5[i - 1] > 0 and c5[i] > 0]
    if len(r) >= 11:
        m = sum(r) / len(r); sd = math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1))
        trend = math.log(c5[-1] / c5[0]) / (sd * math.sqrt(len(r))) if sd > 0 else 0.0
    return {"unten": q(p_rand), "oben": q(1 - p_rand), "trend": trend, "n": len(kurse), "von": kurse[0][0], "bis": kurse[-1][0] + 60}


def grid_trend_ok(trend, R: dict) -> bool:
    """Darf das Grid bei diesem Trend (mit Vorzeichen) aufbauen oder nachführen? Gegen das Grid (Long: abwärts) höchstens trend_gegen,
    in Grid-Richtung höchstens trend_mit -- ein Long-Grid in einem Abwärtstrend ist der klassische Verlustfall, im Aufwärtstrend
    verkauft es nur zu früh."""
    if trend is None:
        return False
    t = trend if R["richtung"] == "long" else -trend
    return -R["trend_gegen"] <= t <= R["trend_mit"]


def grid_stufen(unten: float, oben: float, schritt_min: float, n_min: int, n_max: int):
    """Geometrische Stufen [L0 .. Ln] von unten bis oben: so viele Abstände, wie mit mindestens schritt_min passen (höchstens n_max);
    None, wenn weniger als n_min passen. Liefert (Stufen, Schritt)."""
    if not unten or not oben or oben <= unten or unten <= 0:
        return None
    n = min(int(math.log(oben / unten) / math.log(1 + schritt_min) + 1e-9), n_max)
    if n < n_min:
        return None
    q = (oben / unten) ** (1.0 / n)
    return [unten * q ** i for i in range(n)] + [oben], q - 1


def grid_tage(st, sid: str) -> dict:
    """
    Tagesergebnis eines Grids nach Bestandswert (Mark-to-Market) je UTC-Tag: realisiert im Tag plus Änderung des unrealisierten
    Bestandswerts (letzter Stand des Tages gegen den letzten davor). Nur realisiert zeigte ein Grid laufend kleine Gewinne, während sich
    die Verluste im Bestand sammeln. Ein Tag ohne Stand (Labor aus) gibt seine Änderung an den nächsten Tag mit Stand weiter.
    {"tage": [(tag, usd)], "je_coin": {coin: [(tag, usd)]}, "bestand": {coin: letzter Bestandswert}}
    """
    real: dict = {}
    for coin, tag, usd in st.execute("SELECT coin, geschlossen / 86400 * 86400, SUM(netto_usd) FROM labor_position WHERE sid=? AND status='geschlossen' "
                                     "GROUP BY 1, 2", (sid,)):
        real[(coin, int(tag))] = float(usd or 0.0)
    snap: dict = {}
    try:
        for coin, tag, u in st.execute("SELECT coin, tag, unreal FROM labor_grid_tag WHERE sid=?", (sid,)):
            snap[(coin, int(tag))] = float(u or 0.0)
    except sqlite3.Error:
        pass
    coins = sorted({c for c, _ in real} | {c for c, _ in snap})
    letzt = {c: 0.0 for c in coins}; je = {c: [] for c in coins}; ges = []
    for tag in sorted({t for _, t in real} | {t for _, t in snap}):
        s_ = 0.0; da = False
        for c in coins:
            if (c, tag) not in real and (c, tag) not in snap:
                continue
            v = real.get((c, tag), 0.0)
            if (c, tag) in snap:
                v += snap[(c, tag)] - letzt[c]; letzt[c] = snap[(c, tag)]
            je[c].append((tag, v)); s_ += v; da = True
        if da:
            ges.append((tag, s_))
    return {"tage": ges, "je_coin": je, "bestand": letzt}


def grid_zustand(st) -> dict:
    """Gespeicherter Grid-Zustand je „sid|coin“ (Modus, Stufen, Notlinie, Halten, Pause, Zähler) der aktiven Grid-Strategien -- für
    Übersicht, Chart und Bericht (Stand des letzten Takts)."""
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
        g = (json.loads(r[0]) if r and r[0] else {}).get("g") or {}
        aktiv = {x[0] for x in st.execute("SELECT sid FROM labor_strategie WHERE aktiv=1 AND name IN (?, ?)", GRID_NAMEN)}
    except (sqlite3.Error, ValueError, AttributeError):
        return {}
    return {k: v for k, v in g.items() if isinstance(v, dict) and k.split("|")[0] in aktiv}


_LIQ_SQL =(("hl", "liquidations", "px*sz", True), ("binance", "bnc_liquidations", "notional", False), ("andere", "ext_liquidations", "notional", False))


def _liq_seite(side, hl: bool) -> str:
    return ("long" if str(side).upper().startswith("A") else "short") if hl else ("long" if str(side).lower() == "long" else "short")


def liquidationen(con, coin: str, t0: int, t1: int) -> dict:
    """USD je liquidierter Seite (long = Zwangsverkauf, short = Zwangskauf) aus Hyperliquid, Binance und den übrigen Börsen."""
    out = {"long": 0.0, "short": 0.0, "hl": 0.0, "binance": 0.0, "andere": 0.0}
    for q, tab, expr, hl in _LIQ_SQL:
        try:
            for side, usd in con.execute(f"SELECT side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? AND ts<? GROUP BY side", (coin, t0, t1)):
                usd = float(usd or 0.0); out[_liq_seite(side, hl)] += usd; out[q] += usd
        except sqlite3.Error:
            pass
    return out


def liq_schwellen(con, coin: str, now: int) -> dict:
    """Je liquidierter Seite: max(95.-Perzentil der 15-min-Summen der letzten 7 Tage, 3 × Median, 50k USD)."""
    t0 = now - 7 * 86_400; eimer = {"long": {}, "short": {}}
    for _q, tab, expr, hl in _LIQ_SQL:
        try:
            for b, side, usd in con.execute(f"SELECT ts/900, side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? GROUP BY 1, 2", (coin, t0)):
                s = _liq_seite(side, hl); eimer[s][b] = eimer[s].get(b, 0.0) + float(usd or 0.0)
        except sqlite3.Error:
            pass
    out = {}
    for seite, d in eimer.items():
        w = sorted(list(d.values()) + [0.0] * max(0, 7 * 96 - len(d)))
        out[seite] = max(w[int(0.95 * (len(w) - 1))], 3 * w[len(w) // 2], 50_000.0)
    return out


# ------------------------------------------------------------------------------------------------ Signale
def _markt(seite, grund, werte=None, **kw):
    return dict({"typ": "markt", "seite": seite, "grund": grund, "werte": werte or {}}, **kw)


def _wert(E, quelle, schluessel, now):
    d = E.get("treiber" if quelle == "treiber" else "familien") or {}
    v = d.get(schluessel)
    if not v or now - v[1] > FRISCH_S[quelle]:
        return None
    return v[0]


def sig_schwelle(S, E, coin, now, zs):
    R = S["regeln"]; v = _wert(E, R["quelle"], R["schluessel"], now)
    if v is None:
        return []
    s = R["schwelle"]
    if v >= s:
        seite = "long"
    elif v <= -s:
        seite = "short"
    else:
        return []
    if R.get("invert"):
        seite = _gegen(seite)
    return [_markt(seite, f"{R['schluessel']} {v:+.2f} (Schwelle ±{s:g})" + (" — dagegen" if R.get("invert") else ""),
                   {R["schluessel"]: round(v, 3)})]


def sig_prognose(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]
    if not P or now - P["ts"] > FRISCH_S["prognose"]:
        return []
    if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
        return []
    p = P.get(R["feld"])
    if p is None:
        return []
    d = float(p) - 0.5
    if abs(d) < R["schwelle"]:
        return []
    etikett = {"p_up_v2": "v2", "p_fusion": "Fusion"}.get(R["feld"], "v1")
    return [_markt("long" if d > 0 else "short", f"{etikett}: P(aufwärts 4 h) {float(p) * 100:.1f} %",
                   {"p_up": round(float(p), 4), "bias": P.get("bias")})]


def fusion_vorsprung(S, E, coin, now) -> dict:
    """23.42: Vorsprung der Fusionsprognose gegen die Kosten eines Hin- und Rückwegs zum Marktpreis. Vorsprung = |2p − 1| · E|r 4 h|
    (Herleitung in hl_fusion: so viel bringt ein Richtungsurteil mit Trefferquote p im Mittel), Kosten = Taker-Gebühr beider Seiten
    (XMR doppelt) plus der Abstand zur Buchmitte einer Markt-Order von NOTIONAL in beide Richtungen, aus dem aktuellen Buch."""
    P = E.get("prognose"); R = S["regeln"]; b = E.get("preis")
    if not P or now - P["ts"] > FRISCH_S["prognose"]:
        return {"grund": "keine frische Prognose"}
    p, er = P.get(R["feld"]), P.get("er_4")
    if p is None:
        return {"grund": "keine Fusionszahl in der Prognose"}
    if er is None or float(er) <= 0:
        return {"grund": "keine mittlere 4-h-Bewegung (Kostenschwelle)"}
    if not b or not b.get("mid"):
        return {"grund": "kein Orderbuch"}
    p, er = float(p), float(er)
    if p == 0.5:
        return {"grund": "Fusion genau 50 %"}
    seite = "long" if p > 0.5 else "short"; kauf = seite == "long"
    _, bps_ein = taker_preis(b, kauf, NOTIONAL); _, bps_aus = taker_preis(b, not kauf, NOTIONAL)
    kosten = 2 * gebuehr(coin, GEB_TAKER) + (bps_ein + bps_aus) / 1e4
    vorsprung = abs(2 * p - 1) * er
    return {"p": p, "er": er, "seite": seite, "kosten": kosten, "vorsprung": vorsprung, "handeln": vorsprung >= R["puffer"] * kosten}


def sig_fusion(S, E, coin, now, zs):
    v = fusion_vorsprung(S, E, coin, now)
    if not v.get("handeln"):
        return []
    return [_markt(v["seite"], f"Fusion {v['p'] * 100:.1f} %: Vorsprung {v['vorsprung'] * 100:.3f} % ≥ {S['regeln']['puffer']:g} × Kosten "
                               f"{v['kosten'] * 100:.3f} %",
                   {"p_fusion": round(v["p"], 4), "er_4": round(v["er"], 6), "kosten": round(v["kosten"], 6), "vorsprung": round(v["vorsprung"], 6)})]


def sig_empfehlung(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]; b = E["preis"]
    if not P or now - P["ts"] > FRISCH_S["prognose"] or P.get("bias") is None:
        return [{"typ": "storno", "grund": "keine frische Prognose"}]
    bias = float(P["bias"]); kp, vp = P.get("buy_px"), P.get("sell_px"); s12 = E["sigma4h"] * math.sqrt(3)
    if bias >= 0.12 and kp and kp < b["bid"]:
        tp = vp if (vp and vp > kp * 1.002) else kp * (1 + 2 * s12)
        return [{"typ": "storno", "seite": "short", "grund": "Bias jetzt bullisch"},
                {"typ": "limit", "seite": "long", "preis": float(kp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Kaufpreis {kp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    if bias <= -0.12 and vp and vp > b["ask"]:
        tp = kp if (kp and kp < vp * 0.998) else vp * (1 - 2 * s12)
        return [{"typ": "storno", "seite": "long", "grund": "Bias jetzt bärisch"},
                {"typ": "limit", "seite": "short", "preis": float(vp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Verkaufspreis {vp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    return [{"typ": "storno", "grund": "Bias neutral oder Preis schon überschritten"}]


def _sig_kopie(S, E, quelle, etikett):
    """Kopier-Strategien (Darwin-Liste, seit 23.39 auch Elite): Einstieg je erkannter Eröffnung, Folge-Ausstieg beim Schließen."""
    R = S["regeln"]; inv = R.get("invert"); akts = []
    for f in (E.get(quelle) or {}).get("neu", []):
        kurz = f"{f['addr'][:6]}…{f['addr'][-4:]}"
        if f["art"] == "auf" and f["usd"] >= R["min_usd"]:
            stuecke = (f" in {f['n']} Fills über {max(1, round((f['ts'] - f.get('seit', f['ts'])) / 60))} min" if (f.get("n") or 1) > 1 else "")
            akts.append(_markt(_gegen(f["seite"]) if inv else f["seite"],
                               f"{etikett} #{f.get('rang') or '?'} {kurz} eröffnet {f['seite']} ({f['usd'] / 1e3:.0f}k{stuecke}, Ø {f['px']:.6g})"
                               + (" — wir handeln dagegen" if inv else ""),
                               {"konto": f["addr"], "usd": round(f["usd"]), "rang": f.get("rang"), "fills": f.get("n")},
                               folge={"addr": f["addr"], "seite_konto": f["seite"]}, h=R["h"]))
        elif f["art"] == "zu":
            anteil = (f" ({f['usd'] / 1e3:.0f}k von {f['von_usd'] / 1e3:.0f}k)" if f.get("von_usd") else "")
            akts.append({"typ": "folge_aus", "addr": f["addr"], "seite_konto": f["seite"], "grund": f"{etikett}-Konto {kurz} schließt {f['seite']}{anteil}"})
    return akts


def sig_darwin(S, E, coin, now, zs):
    return _sig_kopie(S, E, "darwin", "Darwin")


def sig_elite(S, E, coin, now, zs):
    return _sig_kopie(S, E, "elite", "Elite")


def sig_kaskade(S, E, coin, now, zs):
    K = E.get("kaskade") or {}; R = S["regeln"]; b = E["preis"]
    if not K.get("aktiv") or zs.get("kaskade_id") == K.get("id"):
        return []
    ab = K["richtung"] == "ab"
    if R["modus"] == "fortsetzung":
        zs["kaskade_id"] = K["id"]
        s1 = E["sigma1h"]; p = b["mid"]
        return [_markt("short" if ab else "long",
                       f"Kaskade {'abwärts' if ab else 'aufwärts'} {K.get('z_start') or 0:+.1f} σ in 15 min, {(K.get('liq_usd') or 0) / 1e6:.2f} Mio "
                       "liquidiert — mit der Bewegung", {"z": K.get("z_start"), "liq": round(K.get("liq_usd") or 0)},
                       sl_px=p * (1 + s1) if ab else p * (1 - s1), tp_px=p * (1 - 1.5 * s1) if ab else p * (1 + 1.5 * s1),
                       h=R["h"], halten_s=R["h"] * 3600)]
    if now - K["t"] > 1800:
        return []
    k = E.get("kerze")
    if not k or k[0] < K["t"] // 60 * 60:
        return []
    s15 = E["sigma15"]; ext = K["extrem"]
    if ab and k[4] > k[1] and k[4] >= ext * (1 + 0.25 * s15):
        tp = ext + 0.5 * (K["p_start"] - ext); zs["kaskade_id"] = K["id"]
        if tp <= b["ask"]:
            return []
        return [_markt("long", f"Gegenkerze nach der Kaskade (Tief {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"tief": ext, "start": K["p_start"]}, sl_px=ext * (1 - 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    if not ab and k[4] < k[1] and k[4] <= ext * (1 - 0.25 * s15):
        tp = ext - 0.5 * (ext - K["p_start"]); zs["kaskade_id"] = K["id"]
        if tp >= b["bid"]:
            return []
        return [_markt("short", f"Gegenkerze nach dem Squeeze (Hoch {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"hoch": ext, "start": K["p_start"]}, sl_px=ext * (1 + 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    return []


def sig_docht(S, E, coin, now, zs):
    """Limit knapp jenseits des nächsten großen Clusters. Eine liegende Order bleibt, solange ihr Cluster im Snapshot steht --
    auch wenn der Kurs schon näher als 0,5 σ herangelaufen ist (genau dann soll sie ja gefüllt werden)."""
    D = E.get("docht") or {}; R = S["regeln"]; s1 = E["sigma1h"]; akts = []
    bestehend = {seite: preis for seite, preis in zs.get("_orders", [])}
    for seite, key in (("long", "unten"), ("short", "oben")):
        alle = [c for c in (D.get(key + "_alle") or []) if c["anteil"] >= R["min_anteil"]]
        alt = bestehend.get(seite)
        if alt:
            c_alt = alt / (1 - R["abstand"] * s1) if seite == "long" else alt / (1 + R["abstand"] * s1)
            if any(abs(math.log(c["px"] / c_alt)) <= 0.5 * s1 for c in alle):
                continue
        neu = [c for c in alle if 0.5 <= c["sigma"] <= 3.0]
        c = min(neu, key=lambda c_: c_["sigma"]) if neu else None
        if not c:
            if alt:
                akts.append({"typ": "storno", "seite": seite, "grund": "Cluster nicht mehr im Snapshot"})
            continue
        preis = c["px"] * (1 - R["abstand"] * s1) if seite == "long" else c["px"] * (1 + R["abstand"] * s1)
        akts.append({"typ": "limit", "seite": seite, "preis": preis, "gueltig_s": 4 * 3600, "sl_rel": R["sl"] * s1, "tp_rel": R["tp"] * s1,
                     "halten_s": R["h"] * 3600, "toleranz": 0.25 * s1,
                     "grund": f"{'Long' if seite == 'long' else 'Short'}-Liquidationscluster {c['usd'] / 1e6:.2f} Mio bei {c['px']:.6g} "
                              f"({c['anteil'] * 100:.0f} % des Stundenvolumens, {c['sigma']:.1f} σ)",
                     "werte": {"cluster": c["px"], "usd": round(c["usd"]), "anteil": round(c["anteil"], 3)}})
    return akts


def sig_magnet(S, E, coin, now, zs):
    A = E.get("anker") or {}; R = S["regeln"]; a = A.get("A")
    if a is None or abs(a) < R["a_min"] or not A.get("ts") or now - A["ts"] > FRISCH_S["anker"]:
        return []
    dom = A.get("oben") if a > 0 else A.get("unten")
    if not dom or dom["anteil_volumen"] < R["min_anteil"] or not (0.5 <= dom["abstand_sigma"] <= 2.0):
        return []
    s1 = E["sigma1h"]; p = E["preis"]["mid"]
    return [_markt("long" if a > 0 else "short",
                   f"Anker A {a:+.2f}: Cluster {dom['usd'] / 1e6:.2f} Mio bei {dom['px']:.6g} ({dom['abstand_sigma']:.1f} σ, "
                   f"{dom['anteil_volumen'] * 100:.0f} % des Stundenvolumens)", {"A": a, "cluster": dom["px"]},
                   sl_px=p * (1 - E["sigma4h"]) if a > 0 else p * (1 + E["sigma4h"]),
                   tp_px=dom["px"] * (1 - 0.1 * s1) if a > 0 else dom["px"] * (1 + 0.1 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_funding(S, E, coin, now, zs):
    f = E.get("funding"); R = S["regeln"]
    if not f or f.get("z") is None or now - f["ts"] > FRISCH_S["funding"]:
        return []
    if abs(f["z"]) < R["z"]:
        return []
    return [_markt("short" if f["z"] > 0 else "long", f"Funding {f['rate'] * 100:.4f} %/h, z {f['z']:+.1f} gegenüber 14 Tagen",
                   {"rate": f["rate"], "z": round(f["z"], 2)})]


def sig_ausbruch(S, E, coin, now, zs):
    R = S["regeln"]; w = (E.get("staerke") or {}).get("wert"); b = E["preis"]; s1 = E["sigma1h"]
    arm = zs.get("scharf")
    if arm and now - arm["t"] > 4 * 3600:
        zs.pop("scharf", None); arm = None
    if not arm:
        if w is not None and w >= R["schwelle"]:
            zs["scharf"] = {"t": now, "p": b["mid"], "w": round(w, 2)}
        return []
    d = math.log(b["mid"] / arm["p"]) / max(s1, 1e-6)
    if abs(d) < 1.0:
        return []
    zs.pop("scharf", None)
    return [_markt("long" if d > 0 else "short", f"Ausbruch {d:+.1f} σ(1 h) seit {_uhr(arm['t'])} (Stärke {arm['w']:.2f})",
                   {"ausgang": arm["p"], "staerke": arm["w"]}, sl_px=arm["p"],
                   tp_px=arm["p"] * (1 + 2.5 * s1) if d > 0 else arm["p"] * (1 - 2.5 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_twap(S, E, coin, now, zs):
    A = E.get("adressstrom") or {}; R = S["regeln"]; w = A.get("tw_anteil")
    if w is None or not A.get("ts") or now - A["ts"] > FRISCH_S["adressstrom"] or abs(w) < R["anteil"]:
        return []
    return [_markt("long" if w > 0 else "short", f"TWAP-Netto 60 min {A['tw_netto_h'] / 1e6:+.2f} Mio = {w * 100:+.1f} % des Stundenvolumens",
                   {"tw_netto": round(A["tw_netto_h"]), "anteil": round(w, 4)})]


def sig_zufall(S, E, coin, now, zs):
    R = S["regeln"]; dt = max(1, min(now - int(zs.get("_t_letzt", now - TAKT_S)), 3600)); zs["_t_letzt"] = now
    rng = random.Random(f"{S['sid']}|{coin}|{now}")
    if rng.random() < min(1.0, dt / (R["rate_h"] * 3600)):
        return [_markt("long" if rng.random() < 0.5 else "short", "Zufall (Kontrolle)")]
    return []


def sig_halten(S, E, coin, now, zs):
    return [_markt("long", "Vergleich: immer Long", h=168, halten_s=168 * 3600)]


def status_text(S, E, now, zs) -> str:
    """Was die Strategie in diesem Takt sieht -- für die Live-Tafel (Wert gegen Schwelle, fehlende Daten, scharf/ruhig)."""
    R = S["regeln"]; fn = S["fn"]
    if fn == "schwelle":
        v = _wert(E, R["quelle"], R["schluessel"], now)
        return "keine frischen Werte" if v is None else f"{v:+.2f} (Schwelle ±{R['schwelle']:g})"
    if fn in ("prognose", "empfehlung"):
        P = E.get("prognose")
        if not P or now - P["ts"] > FRISCH_S["prognose"]:
            return "keine frische Prognose"
        if fn == "empfehlung":
            return "Bias —" if P.get("bias") is None else f"Bias {float(P['bias']):+.2f} (Schwelle ±0,12)"
        if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
            return "v2 noch nicht scharf (Version < 2)"
        p = P.get(R["feld"])
        return "—" if p is None else f"P(aufwärts) {float(p) * 100:.1f} % (Schwelle {50 - R['schwelle'] * 100:.0f} / {50 + R['schwelle'] * 100:.0f} %)"
    if fn == "fusion":
        v = fusion_vorsprung(S, E, E.get("coin"), now)
        if "kosten" not in v:
            return v.get("grund", "—")
        return (f"Fusion {v['p'] * 100:.1f} % · Vorsprung {v['vorsprung'] * 100:.3f} % gegen {R['puffer']:g} × Kosten {v['kosten'] * 100:.3f} %"
                + (" → handelt" if v["handeln"] else ""))
    if fn in ("darwin", "elite"):
        D = E.get(fn) or {}; su = D.get("summen") or {}
        top = max(su.values()) if su else 0.0
        return (f"{len(D.get('konten') or [])} Konten im Blick" + (f" · größte Eröffnung in {R.get('fenster_s', DARWIN_FENSTER_S) // 60} min "
                f"{top / 1e3:.1f}k (Schwelle {R['min_usd'] / 1e3:.0f}k)" if top else "") + (f", {len(D['neu'])} neue Trades" if D.get("neu") else ""))
    if fn == "kaskade":
        K = E.get("kaskade") or {}
        if K.get("aktiv"):
            return f"Kaskade {'abwärts' if K.get('richtung') == 'ab' else 'aufwärts'} seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}"
        return "keine Kursdaten" if K.get("z") is None else f"ruhig: 15 min {K['z']:+.1f} σ (Schwelle ±{KASKADE_Z:g})"
    if fn == "docht":
        D = E.get("docht") or {}
        t = [f"{'unten' if k == 'unten' else 'oben'} {D[k]['px']:.6g} ({D[k]['anteil'] * 100:.0f} %)" for k in ("unten", "oben") if D.get(k)]
        return ("Cluster " + ", ".join(t)) if t else "kein Cluster ≥ 10 % des Stundenvolumens in 0,5–3 σ"
    if fn == "magnet":
        A = E.get("anker") or {}
        return "kein Anker" if A.get("A") is None else f"A {A['A']:+.2f} (Schwelle ±{R['a_min']:g})"
    if fn == "funding":
        f = E.get("funding")
        return "keine Funding-Daten" if not f else (f"z {f['z']:+.1f} (Schwelle ±{R['z']:g})" if f.get("z") is not None else "Statistik im Aufbau")
    if fn == "ausbruch":
        a = zs.get("scharf")
        if a:
            return f"scharf seit {_uhr(a['t'])} bei {a['p']:.6g}"
        w = (E.get("staerke") or {}).get("wert")
        return "keine Stärke-Werte" if w is None else f"Stärke {w:.2f} (Schwelle {R['schwelle']:g})"
    if fn == "twap":
        w = (E.get("adressstrom") or {}).get("tw_anteil")
        return "wartet auf den Adress-Strom" if w is None else f"TWAP-Netto {w * 100:+.2f} % Vol. (Schwelle ±{R['anteil'] * 100:g} %)"
    if fn == "zufall":
        return f"zufällig, im Schnitt alle {R['rate_h']} h"
    if fn == "halten":
        return "immer Long"
    return ""


SIGNALE = {"schwelle": sig_schwelle, "darwin": sig_darwin, "elite": sig_elite, "prognose": sig_prognose, "empfehlung": sig_empfehlung, "kaskade": sig_kaskade,
           "docht": sig_docht, "magnet": sig_magnet, "funding": sig_funding, "ausbruch": sig_ausbruch, "twap": sig_twap,
           "zufall": sig_zufall, "halten": sig_halten, "fusion": sig_fusion}


# ------------------------------------------------------------------------------------------------ Engine
POS_SPALTEN = ("id", "sid", "coin", "seite", "eroeffnet", "preis_ein", "notional", "menge", "gebuehr_ein", "sl", "tp", "ablauf",
               "geprueft_bis", "nur_stop_bis", "funding", "funding_bis", "mae_pct", "mfe_pct", "folge")


class Labor:
    def __init__(self, db: str, store: str | None = None, coins=COINS, notional: float = NOTIONAL, adressfluss: str | None = None,
                 nur: tuple | None = None):
        self.db = db; self.store = store or F.STORE; self.coins = tuple(coins); self.notional = float(notional)
        self.af_pfad = adressfluss or os.path.join(os.path.dirname(os.path.abspath(db)), "adressfluss.db")
        self.strategien = [s for s in strategien() if not nur or s["name"] in nur]
        self.nach_sid = {s["sid"]: s for s in self.strategien}
        self.cache: dict = {}; self.letzte: dict = {}; self.fehler: list = []; self.zyklen = 0; self.dauer = 0.0; self.t_letzt = None
        self._registriert = False
        self.z = None; self._z_txt = None          # Zustand im Speicher; in den Speicher geschrieben nur bei Änderung (Schreiblast)
        self.status: dict = {}                     # (sid, coin) -> was die Strategie in diesem Takt sieht (nur Anzeige)
        self.darwin_log: list = []                 # die letzten erkannten Darwin-Trades (nur Anzeige im Datenfluss)
        self.elite_log: list = []                  # 23.39: dasselbe für die Elite
        self.coin_start: dict = {}                 # 23.34: Start je Coin (labor_zustand „coins“), gesetzt beim Registrieren
        self.grid_strategien = [s for s in self.strategien if s["fn"] == "grid"]      # 23.40
        self.grid_sids = {s["sid"] for s in self.grid_strategien}
        self._grid_alt_ok: set = set()             # Coins, in denen Lose abgelöster Grid-Regelversionen schon geschlossen wurden

    # --- Verbindungen, Zustand, Protokoll
    def _con(self):
        return sqlite3.connect(f"file:{self.db}?mode=ro", uri=True, timeout=10)

    def _st(self):
        st = F.store_connect(self.store); schema(st)
        return st

    def _gecacht(self, key, ttl, now, fn):
        e = self.cache.get(key)
        if e and 0 <= now - e[0] < ttl:
            return e[1]
        v = fn(); self.cache[key] = (now, v)
        if len(self.cache) > 400:                  # Schlüssel mit Zeitstempel (Treiber-, Heatmap-Stand) laufen sonst auf
            for k in [k for k, e_ in self.cache.items() if now - e_[0] > 7200]:
                self.cache.pop(k, None)
        return v

    def _fehler(self, text):
        self.fehler = (self.fehler + [f"{time.strftime('%d.%m. %H:%M:%S')} {text}"])[-20:]

    def _zustand(self, st) -> dict:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
        try:
            z = json.loads(r[0]) if r and r[0] else {}
        except ValueError:
            z = {}
        z.setdefault("s", {}); z.setdefault("k", {})
        for k_ in ("darwin_tids", "darwin_ep", "elite_tids", "elite_ep", "g"):          # 23.40: „g“ = Zustand je Grid und Coin
            if not isinstance(z.get(k_), dict):
                z[k_] = {}
        return z

    def _zustand_speichern(self, st, z, now) -> None:
        """Nur Bleibendes (Pausen, Kaskaden, scharfe Ausbrüche, gesehene Darwin-Schließungen, laufende Darwin-Eröffnungen), nur bei
        Änderung. Schlüssel mit Unterstrich sind flüchtig (z. B. der letzte Zufallstakt)."""
        for v_ in ("darwin", "elite"):                                              # 23.39: Elite wie Darwin
            z[f"{v_}_tids"] = {k: t for k, t in z[f"{v_}_tids"].items() if t >= now - 2 * DARWIN_FENSTER_S}   # länger als das Fenster
            z[f"{v_}_ep"] = {k: e for k, e in z[f"{v_}_ep"].items() if isinstance(e, dict) and int(e.get("t", 0)) >= now - DARWIN_EPISODE_S}
        s_ = {}
        for k, v in z["s"].items():
            w = {kk: vv for kk, vv in v.items() if not kk.startswith("_") and not (kk == "pause_bis" and vv < now)}
            if w:
                s_[k] = w
        # 23.40: Grid-Zustand je Strategie und Coin (Stufen, Modus, Halten, Pause, Kerzen-Stand); nur aktuelle Regelversionen
        g_ = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")} for k, v in z["g"].items()
              if isinstance(v, dict) and k.split("|")[0] in self.nach_sid}
        txt = _j({"s": s_, "k": z["k"], "darwin_tids": z["darwin_tids"], "darwin_ep": z["darwin_ep"], "elite_tids": z["elite_tids"],
                  "elite_ep": z["elite_ep"], "aufgeraeumt": z.get("aufgeraeumt", 0), "g": g_})
        if txt != self._z_txt:
            st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('zustand', ?)", (txt,))
            self._z_txt = txt

    def _registrieren(self, st, now) -> None:
        if self._registriert:
            return
        for s in self.strategien:
            st.execute("INSERT OR IGNORE INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)",
                       (s["sid"], s["name"], s["titel"], s["gruppe"], _j(s["regeln"]), s["beschreibung"], now))
            st.execute("UPDATE labor_strategie SET aktiv=CASE WHEN sid=? THEN 1 ELSE 0 END WHERE name=?", (s["sid"], s["name"]))
        neu_start = not st.execute("SELECT 1 FROM labor_zustand WHERE k='start'").fetchone()
        if neu_start:
            st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(now),))
        self.coin_start = coin_starts(st, self.coins, now, schreiben=True)
        self._registriert = True

    def _ereignis(self, st, t, sid, coin, art, seite, preis, text, netto=None, pos_id=None) -> None:
        st.execute("INSERT INTO labor_ereignis (ts, sid, coin, art, seite, preis, text, netto_usd, pos_id) VALUES (?,?,?,?,?,?,?,?,?)",
                   (int(t), sid, coin, art, seite, preis, text, netto, pos_id))

    # --- Eingangsdaten
    def eingaben(self, con, st, coin: str, now: int, z: dict) -> dict:
        E = {"coin": coin, "now": now, "preis": buch_jetzt(con, coin, now)}
        s = self._gecacht((coin, "sigma"), 900, now, lambda: sigma_4h(con, coin, now))
        E["sigma4h"], E["sigma_ok"], E["sigma_real4h"] = s
        E["sigma1h"] = E["sigma4h"] / 2; E["sigma15"] = E["sigma4h"] / 4
        E["vol1h"] = self._gecacht((coin, "vol"), 900, now, lambda: volumen_1h(con, coin, now))
        k = kerzen(con, coin, now // 60 * 60 - 20 * 60, now // 60 * 60)
        E["kerze"] = k[-1] if k else None; E["kerzen20"] = k
        try:                                   # Prognose und Treiber tragen denselben Zeitstempel; Index (coin, ts) der Prognosetabelle
            t_fc = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3 * 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_fc = None

        def _treib():
            d = {}
            try:
                for n, sc, t in st.execute("SELECT name, score, ts FROM forecast_drivers WHERE ts>=? AND ts<=? AND coin=?", (now - 3 * 3600, now, coin)):
                    if sc is not None and (n not in d or t > d[n][1]):
                        d[n] = (float(sc), int(t))
            except sqlite3.Error:
                pass
            return d
        E["treiber"] = self._gecacht((coin, "treiber", t_fc), 3600, now, _treib)

        def _prog():
            try:
                r = st.execute("SELECT ts, bias, p_up, buy_px, sell_px, json_extract(payload,'$.p_up_v2'), json_extract(payload,'$.kalib2.version'), "
                               "json_extract(payload,'$.p_up_v1'), json_extract(payload,'$.fusion.p_4'), json_extract(payload,'$.kosten.er_4') "
                               "FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                               (coin, now - 3 * 3600, now)).fetchone()
            except sqlite3.Error:
                r = None
            return {"ts": int(r[0]), "bias": r[1], "p_up": r[2], "buy_px": r[3], "sell_px": r[4], "p_up_v2": r[5], "v2_version": r[6],
                    "p_up_v1": r[7] if r[7] is not None else r[2], "p_fusion": r[8], "er_4": r[9]} if r else None
        E["prognose"] = self._gecacht((coin, "prognose", t_fc), 3600, now, _prog)
        import hl_familien as H
        fam = {}
        for f, d in H.FAMILIEN.items():
            if d.get("live") or d["art"] == "staerke":
                continue
            w = [E["treiber"][n] for n in d["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
            fam[f] = (sum(x[0] for x in w) / len(w), min(x[1] for x in w), len(w)) if w else None
        try:
            r = st.execute("SELECT value, ts FROM familien_log WHERE coin=? AND familie='Profi-Flow' AND slot<=? ORDER BY slot DESC LIMIT 1",
                           (coin, now // 900)).fetchone()
            r = r if r and now - 1800 <= int(r[1]) <= now else None
            fam["Profi-Flow"] = (float(r[0]), int(r[1]), 1) if r and r[0] is not None else None
        except sqlite3.Error:
            fam["Profi-Flow"] = None
        E["familien"] = fam
        mit = [abs(E["treiber"][n][0]) for n in H.FAMILIEN["Stärke"]["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
        ruhe = None
        if E["sigma_real4h"] is not None and E["sigma_ok"]:
            ruhe = min(1.0, max(0.0, 1 - E["sigma_real4h"] / E["sigma4h"])); mit.append(ruhe)
        E["staerke"] = {"wert": (sum(mit) / len(mit)) if mit else None, "ruhe": ruhe, "n": len(mit)}
        E["kaskade"] = self._kaskade(con, st, coin, now, E, z)

        try:
            t_hm = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_hm = None

        def _anker():
            try:
                import hl_anker
                return hl_anker.jetzt(con, coin, now)
            except Exception as e:
                return {"fehler": f"{type(e).__name__}: {e}"}
        E["anker"] = self._gecacht((coin, "anker", t_hm), 1800, now, _anker)     # neu nur mit neuem Heatmap-Stand (alle 10 min)
        E["docht"] = self._docht(con, coin, now, E, t_hm)
        E["funding"] = self._funding(con, coin, now)
        E["darwin"] = self._darwin(con, st, coin, now, z)
        E["elite"] = self._elite(con, st, coin, now, z)                          # 23.39
        E["adressstrom"] = self._gecacht((coin, "af"), 120, now, lambda: hl_adressfluss.lesen(self.af_pfad, coin, now, E.get("vol1h")))
        if self.grid_strategien:                                                   # 23.40: Range der letzten 24 h (Datenfluss; die Grids
            p_rand = self.grid_strategien[0]["regeln"]["p_rand"]                   # rechnen nach einem Ausstieg mit kürzerem Fenster)
            E["grid"] = self._gecacht((coin, "grid24"), 300, now, lambda: grid_range(grid_kurse(con, coin, now - 86_400, now // 60 * 60), p_rand))
        return E

    def _kaskade(self, con, st, coin, now, E, z) -> dict:
        b = E["preis"]; k = E["kerzen20"]; zst = dict(z["k"].get(coin) or {})
        info = {"z": None, "liq": None, "schwelle": None}
        if not b or not k:
            return dict(zst, **info, aktiv=bool(zst.get("aktiv")))
        alt = [x for x in k if x[0] <= now // 60 * 60 - 15 * 60]
        p15 = alt[-1][4] if alt else k[0][1]
        zz = math.log(b["mid"] / p15) / max(E["sigma15"], 1e-6) if p15 else 0.0
        liq = liquidationen(con, coin, now - 900, now + 1)
        thr = self._gecacht((coin, "liqthr"), 3600, now, lambda: liq_schwellen(con, coin, now))
        info.update(z=round(zz, 2), liq=liq, schwelle=thr)
        if zst.get("aktiv"):
            nach = [x for x in k if x[0] >= zst["t"] // 60 * 60]
            if zst["richtung"] == "ab":
                zst["extrem"] = min([zst["extrem"], b["mid"]] + [x[3] for x in nach])
            else:
                zst["extrem"] = max([zst["extrem"], b["mid"]] + [x[2] for x in nach])
            if now - zst["t"] > KASKADE_FENSTER_S:
                zst["aktiv"] = False
        else:
            letzte = [x for x in k if x[0] >= now // 60 * 60 - 15 * 60]
            for richtung, bed, seite_liq in (("ab", zz <= -KASKADE_Z, "long"), ("auf", zz >= KASKADE_Z, "short")):
                if bed and liq[seite_liq] >= thr[seite_liq]:
                    ext = min([b["mid"]] + [x[3] for x in letzte]) if richtung == "ab" else max([b["mid"]] + [x[2] for x in letzte])
                    zst = {"aktiv": True, "id": now, "t": now, "richtung": richtung, "p_start": p15, "z_start": round(zz, 2),
                           "liq_usd": liq[seite_liq], "extrem": ext}
                    self._ereignis(st, now, None, coin, "kaskade", "short" if richtung == "ab" else "long", b["mid"],
                                   f"{'Kaskade abwärts' if richtung == 'ab' else 'Squeeze aufwärts'} erkannt: {zz:+.1f} σ in 15 min, "
                                   f"{liq[seite_liq] / 1e6:.2f} Mio {'Long' if richtung == 'ab' else 'Short'}-Liquidationen "
                                   f"(Schwelle {thr[seite_liq] / 1e6:.2f} Mio; Hyperliquid {liq['hl'] / 1e6:.2f}, Binance {liq['binance'] / 1e6:.2f}, "
                                   f"andere {liq['andere'] / 1e6:.2f})")
                    break
        z["k"][coin] = zst
        return dict(zst, **info, aktiv=bool(zst.get("aktiv")))

    def _docht(self, con, coin, now, E, t_hm) -> dict:
        b = E["preis"]; vol = E.get("vol1h"); sig = E["sigma4h"]
        out = {"unten": None, "oben": None, "ts": None}
        if not b or not vol:
            return out
        t = t_hm if t_hm and now - t_hm <= 1800 else None
        try:
            rows = con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?", (coin, t)).fetchall() if t else []
        except sqlite3.Error:
            rows = []
        out["ts"] = t; p0 = b["mid"]; out["unten_alle"] = []; out["oben_alle"] = []
        for px, side, usd in rows:
            if not px or not usd:
                continue
            d = abs(math.log(px / p0)) / sig; g = usd / vol
            if d > 3.0 or g < 0.10:
                continue
            c = {"px": px, "usd": usd, "anteil": g, "sigma": d}
            if side == "long" and px < p0:
                out["unten_alle"].append(c)
                if d >= 0.5 and (not out["unten"] or px > out["unten"]["px"]):
                    out["unten"] = c
            elif side == "short" and px > p0:
                out["oben_alle"].append(c)
                if d >= 0.5 and (not out["oben"] or px < out["oben"]["px"]):
                    out["oben"] = c
        return out

    def _funding(self, con, coin, now):
        try:
            r = con.execute("SELECT ts, funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
        except sqlite3.Error:
            r = None
        if not r or r[1] is None:
            return None

        def _stat():
            stunden = [now // 3600 * 3600 - 3600 * k for k in range(14 * 24)]
            try:
                w = [float(x[0]) for x in con.execute(f"SELECT funding FROM ctx_bars WHERE coin=? AND ts IN ({','.join('?' * len(stunden))})",
                                                      (coin, *stunden)) if x[0] is not None]
            except sqlite3.Error:
                w = []
            if len(w) < 48:
                return None
            m = sum(w) / len(w)
            return (m, math.sqrt(sum((x - m) ** 2 for x in w) / (len(w) - 1)), len(w))
        s = self._gecacht((coin, "fstat"), 3600, now, _stat)
        rate = float(r[1])
        return {"ts": int(r[0]), "rate": rate, "z": ((rate - s[0]) / s[1]) if s and s[1] > 0 else None, "n": s[2] if s else 0}

    def _funding_rate(self, con, coin, t) -> float:
        try:
            r = con.execute("SELECT funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (t - 7200, t, coin)).fetchone()
        except sqlite3.Error:
            r = None
        return float(r[0]) if r and r[0] is not None else 0.0

    def _darwin(self, con, st, coin, now, z) -> dict:
        """
        23.34 (Darwin v2): Eröffnungen je Konto und Seite über DARWIN_FENSTER_S netto aufsummiert -- auch in kleinen Stücken (der
        Recorder sammelt die Fills der Liste ohne Mindestbetrag); eine Schließung derselben Seite zieht ab (nicht unter null). Erreicht
        die Summe DARWIN_MIN_USD und ist der jüngste Fill frisch, beginnt eine „Episode“ (einmal je Eröffnung, höchstens
        DARWIN_EPISODE_S). Der Folge-Ausstieg kommt erst, wenn das Konto seit der Episode mindestens DARWIN_AUS_ANTEIL davon wieder
        geschlossen hat -- seit die kleinen Fills sichtbar sind, würde sonst jedes Nachjustieren um ein paar hundert Dollar reichen.
        v1 merkte sich jeden gesehenen Fill und zählte nur die neuen eines Taktes: in Stücke unter 10k zerlegte Eröffnungen blieben
        unsichtbar.
        """
        def _liste():
            try:
                r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
                d = json.loads(r[0]) if r and r[0] else {}
            except (sqlite3.Error, ValueError):
                d = {}
            reihe = [str(a).lower() for a in (d.get("reihe") or [])]
            return (reihe + [a for a in (str(x).lower() for x in (d.get("liste") or [])) if a not in reihe])[:100]
        konten = self._gecacht(("*", "darwin"), 300, now, _liste)
        return self._kopie(con, coin, now, z, konten, "darwin")

    def _elite(self, con, st, coin, now, z) -> dict:
        """
        23.39: Die Elite des Coins als Kopier-Vorlage (Strategien „Elite live folgen“/„Gegen die Elite“) -- dieselbe Regel wie bei der
        Darwin-Liste (_kopie). Liste aus learned(coin, „elite“), vom Dashboard täglich neu aufgestellt (Konto-Score, Beleg, Gewinn- und
        Aktivitätsschranke, ohne Gesperrte); hier zusätzlich ohne Konten, die die Masterregel seither gesperrt hat. Die Fills der Elite
        sammelt der Recorder seit 23.39 im Stream (ab 2.500 USD, 0 Gewicht), auch wenn ein Konto weder Leaderboard-Auswahl, Pool noch Wal ist.
        """
        def _liste():
            try:
                r = st.execute("SELECT value FROM learned WHERE coin=? AND key='elite'", (coin,)).fetchone()
                v = json.loads(r[0]) if r and r[0] else []
            except (sqlite3.Error, ValueError):
                v = []
            konten = list(dict.fromkeys(str(a).lower() for a in (v if isinstance(v, list) else []) if isinstance(a, str)))[:20]
            try:
                gesperrt = {r_[0].lower() for r_ in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
            except sqlite3.Error:
                gesperrt = set()
            return [a for a in konten if a not in gesperrt]
        konten = self._gecacht((coin, "elite_konten"), 300, now, _liste)
        return self._kopie(con, coin, now, z, konten, "elite")

    def _kopie(self, con, coin, now, z, konten, art) -> dict:
        """Gemeinsame Kopier-Logik (bis 23.38 Rumpf von _darwin, unverändert): Eröffnungen je Konto und Seite über DARWIN_FENSTER_S netto,
        Episoden, Folge-Ausstieg; Zustand je Vorlage in z[„<art>_tids“], z[„<art>_ep“], Anzeige in self.<art>_log."""
        out = {"konten": konten, "neu": [], "summen": {}}
        if not konten:
            return out
        dirs = ("Open Long", "Open Short", "Close Long", "Close Short", "Long > Short", "Short > Long",
                "Open Long*", "Open Short*", "Close Long*", "Close Short*")
        try:
            rows = con.execute(f"SELECT ts, lower(addr), dir, px, notional, tid FROM lb_fills WHERE coin=? AND ts>=? AND ts<=? AND lower(addr) IN "
                               f"({','.join('?' * len(konten))}) AND dir IN ({','.join('?' * len(dirs))}) ORDER BY ts, tid",
                               (coin, now - DARWIN_FENSTER_S, now, *konten, *dirs)).fetchall()
        except sqlite3.Error:
            rows = []
        gesehen = z[f"{art}_tids"]; eps = z[f"{art}_ep"]; auf: dict = {}; rang = {a: i + 1 for i, a in enumerate(konten)}; neu = []
        for ts, a, d, px, usd, tid in rows:
            d = str(d).rstrip("*"); ts = int(ts); px = float(px or 0.0); usd = float(usd or 0.0)
            flip = d in ("Short > Long", "Long > Short")
            seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
            if flip or d.startswith("Close"):
                s_zu = _gegen(seite) if flip else seite
                e = auf.get((a, s_zu))
                if e:                                            # Schließungen ziehen von der laufenden Summe ab (nicht unter null)
                    e["usd"] = max(0.0, e["usd"] - usd)
                    if e["usd"] <= 0:
                        auf.pop((a, s_zu), None)
                k = f"{a}|{coin}|{s_zu}"
                if f"{a}:{tid}" not in gesehen:
                    gesehen[f"{a}:{tid}"] = ts
                    ep = eps.get(k)
                    if isinstance(ep, dict):
                        ep["zu"] = ep.get("zu", 0.0) + usd
                        if ep["zu"] >= DARWIN_AUS_ANTEIL * max(ep.get("usd", 0.0), 1.0):
                            eps.pop(k, None)                    # Episode endet: genug geschlossen
                            neu.append({"addr": a, "art": "zu", "seite": s_zu, "usd": ep["zu"], "von_usd": ep.get("usd"), "px": px, "ts": ts,
                                        "rang": rang.get(a)})
            if flip or d.startswith("Open"):
                e = auf.setdefault((a, seite), {"usd": 0.0, "pxu": 0.0, "ts": ts, "t0": ts, "n": 0})
                e["usd"] += usd; e["pxu"] += px * usd; e["n"] += 1; e["ts"] = max(e["ts"], ts)
        for (a, seite), e in auf.items():
            k = f"{a}|{coin}|{seite}"
            out["summen"][k] = round(e["usd"], 2)
            if k in eps or e["usd"] < DARWIN_MIN_USD or now - e["ts"] > DARWIN_FRISCH_S:
                continue
            eps[k] = {"t": now, "usd": round(e["usd"], 2), "zu": 0.0}
            neu.append({"addr": a, "art": "auf", "seite": seite, "usd": e["usd"], "px": (e["pxu"] / e["usd"]) if e["usd"] else 0.0,
                        "ts": e["ts"], "seit": e["t0"], "n": e["n"], "rang": rang.get(a)})
        out["neu"] = sorted(neu, key=lambda e: (e["ts"], e["art"] != "zu"))
        if out["neu"]:
            setattr(self, f"{art}_log", (getattr(self, f"{art}_log") + [dict(e, coin=coin) for e in out["neu"]])[-40:])
        out["log"] = [e for e in getattr(self, f"{art}_log") if e["coin"] == coin and now - e["ts"] <= 6 * 3600][-4:]
        return out

    # --- Zyklus
    def zyklus(self, now: int | None = None) -> dict:
        t_start = time.time(); now = int(now or time.time())
        con = self._con(); st = self._st(); n_neu = n_zu = n_grid = 0
        try:
            self._registrieren(st, now)
            if self.z is None:
                self.z = self._zustand(st)
            z = self.z
            for coin in self.coins:
                try:
                    E = self.eingaben(con, st, coin, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Eingaben: {type(e).__name__}: {e}"); continue
                self.letzte[coin] = {"E": E, "ts": now}
                if not E.get("preis"):
                    continue
                try:
                    n_zu += self._orders(con, st, coin, E, now, z)
                    n_zu += self._positionen(con, st, coin, E, now, z)
                    n_neu += self._signale(con, st, coin, E, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Handel: {type(e).__name__}: {e}")
            # 23.41: Grids zum Schluss des Takts (vorher je Coin mittendrin): ihre Transaktion hält die Schreibsperre ab Beginn
            # (BEGIN IMMEDIATE, siehe _grid) -- am Ende nur für Grids, Zustand und Commit statt für die Eingaben aller übrigen Coins
            for coin in self.coins:
                v = self.letzte.get(coin) or {}
                if v.get("ts") == now and (v.get("E") or {}).get("preis"):
                    n_grid += self._grid(con, st, coin, v["E"], now, z)          # eigene Fehlerbehandlung je Grid (Sicherungspunkt)
            if now - int(z.get("aufgeraeumt", 0)) > 86_400:
                st.execute("DELETE FROM labor_ereignis WHERE ts < ?", (now - EREIGNIS_TAGE * 86_400,))
                st.execute("DELETE FROM labor_order WHERE status<>'offen' AND erledigt < ?", (now - 30 * 86_400,))
                z["aufgeraeumt"] = now
            self._zustand_speichern(st, z, now)
            st.commit()
            n_offen = st.execute("SELECT COUNT(*) FROM labor_position WHERE status='offen'").fetchone()[0]
        except Exception:
            self.z = None; self._z_txt = None           # Takt verworfen (Rollback): Zustand beim nächsten Takt aus dem Speicher
            raise
        finally:
            con.close(); st.close()
        self.zyklen += 1; self.dauer = time.time() - t_start; self.t_letzt = now
        return {"offen": n_offen, "neu": n_neu, "zu": n_zu, "grid": n_grid, "dauer": round(self.dauer, 3)}

    # --- Limit-Orders
    def _orders(self, con, st, coin, E, now, z) -> int:
        rows = st.execute("SELECT id, sid, seite, preis, erstellt, gueltig_bis, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten_s, geprueft_bis "
                          "FROM labor_order WHERE status='offen' AND coin=? AND sid NOT LIKE 'grid\\_%' ESCAPE '\\'", (coin,)).fetchall()   # 23.40: Grid eigene Mechanik
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(r[13]) for r in rows), now // 60 * 60); n = 0
        for oid, sid, seite, preis, erstellt, gueltig, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten, gepr in rows:
            if sid not in self.nach_sid:
                st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
            kauf = seite == "long"; fill = None
            for ts, o, h, l, c in bars:
                if ts < gepr or ts > gueltig:
                    continue
                if (kauf and l < preis) or (not kauf and h > preis):
                    fill = (ts, ts + 30); break
            if fill is None and now <= gueltig and now - b["ts"] <= KURS_FRISCH_S and ((kauf and b["ask"] < preis) or (not kauf and b["bid"] > preis)):
                fill = (now // 60 * 60, now)
            if fill:
                if st.execute("SELECT 1 FROM labor_position WHERE sid=? AND coin=? AND status='offen'", (sid, coin)).fetchone():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
                t_f = fill[1]
                sl = sl_px if sl_px else ((preis * (1 - sl_rel) if kauf else preis * (1 + sl_rel)) if sl_rel else None)
                tp = tp_px if tp_px else ((preis * (1 + tp_rel) if kauf else preis * (1 - tp_rel)) if tp_rel else None)
                pid = self._eroeffnen(st, coin, self.nach_sid[sid], seite, t_f, preis, 0.0, GEB_MAKER, "Limit (Maker)", sl, tp,
                                      t_f + int(halten or 0), grund, werte, None, pruef_ab=fill[0], nur_stop_bis=fill[0] + 60)
                st.execute("UPDATE labor_order SET status='gefuellt', erledigt=?, pos_id=? WHERE id=?", (t_f, pid, oid))
                for (oid2,) in st.execute("SELECT id FROM labor_order WHERE status='offen' AND sid=? AND coin=? AND id<>?", (sid, coin, oid)).fetchall():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid2))
                    self._ereignis(st, now, sid, coin, "storno", None, None, "Gegen-Order storniert: Position eröffnet")
                n += 1
            elif now > gueltig:
                st.execute("UPDATE labor_order SET status='verfallen', erledigt=? WHERE id=?", (now, oid))
                self._ereignis(st, now, sid, coin, "verfallen", seite, preis, f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} bei {preis:.6g} "
                               "verfallen, nicht gefüllt")
            elif now // 60 * 60 != gepr:
                st.execute("UPDATE labor_order SET geprueft_bis=? WHERE id=?", (now // 60 * 60, oid))
        return n

    # --- Positionen
    def _eroeffnen(self, st, coin, S, seite, t, preis, slip_bps, gebuehr_satz, art, sl, tp, ablauf, grund, werte, folge,
                   pruef_ab=None, nur_stop_bis=None, notional=None, ereignis_art="eroeffnet") -> int:
        # 23.40: notional je Position (Grid-Lose sind ein Teil des Coin-Kontos); ohne Angabe wie bisher self.notional
        nt = float(notional) if notional else self.notional
        menge = nt / preis; kauf = seite == "long"
        if sl is not None and ((kauf and sl >= preis) or (not kauf and sl <= preis)):
            sl = None
        if tp is not None and ((kauf and tp <= preis) or (not kauf and tp >= preis)):
            tp = None
        pruef_ab = pruef_ab if pruef_ab is not None else (int(t) // 60 + 1) * 60
        cur = st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, "
                         "sl, tp, ablauf, grund, werte, folge, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) "
                         "VALUES (?,?,?,'offen',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,0,0)",
                         (S["sid"], coin, seite, int(t), preis, nt, menge, art, nt * gebuehr(coin, gebuehr_satz), slip_bps,
                          sl, tp, int(ablauf), grund, werte if isinstance(werte, str) else _j(werte or {}), _j(folge) if folge else None,
                          pruef_ab, nur_stop_bis if nur_stop_bis is not None else pruef_ab, int(t)))
        pid = cur.lastrowid
        teile = [f"{'Long' if kauf else 'Short'} {coin} zu {preis:.6g} ({art}" + (f", {slip_bps:.1f} bps zur Mitte" if slip_bps else "") + ")"]
        if nt != self.notional:
            teile.append(f"{nt:,.0f} USD".replace(",", "."))
        if sl:
            teile.append(f"Stop {sl:.6g}")
        if tp:
            teile.append(f"Ziel {tp:.6g}")
        if ablauf:
            teile.append(f"bis {_uhr(ablauf)}")
        self._ereignis(st, t, S["sid"], coin, ereignis_art, seite, preis, " · ".join(teile) + f" — {grund}", None, pid)
        return pid

    def _schliessen(self, st, p, preis, art, gebuehr_satz, slip_bps, grund, t, z=None, ereignis_art="geschlossen") -> float:
        kauf = p["seite"] == "long"
        brutto = (preis - p["preis_ein"]) * p["menge"] * (1 if kauf else -1)
        geb_aus = p["menge"] * preis * gebuehr(p["coin"], gebuehr_satz)
        netto = brutto - p["gebuehr_ein"] - geb_aus - p["funding"]
        st.execute("UPDATE labor_position SET status='geschlossen', geschlossen=?, preis_aus=?, art_aus=?, gebuehr_aus=?, slip_aus=?, grund_aus=?, "
                   "brutto_usd=?, netto_usd=?, netto_pct=?, mae_pct=?, mfe_pct=?, funding=?, funding_bis=? WHERE id=?",
                   (int(t), preis, art, geb_aus, slip_bps, grund, brutto, netto, netto / p["notional"] * 100, p["mae_pct"], p["mfe_pct"],
                    p["funding"], p["funding_bis"], p["id"]))
        dauer = max(int(t) - int(p["eroeffnet"]), 0)
        self._ereignis(st, t, p["sid"], p["coin"], ereignis_art, p["seite"], preis,
                       f"{'Long' if kauf else 'Short'} {p['coin']} geschlossen zu {preis:.6g} ({grund}, {art}) nach {dauer // 3600} h "
                       f"{dauer % 3600 // 60} min · netto {netto:+.2f} USD ({netto / p['notional'] * 100:+.2f} %)"
                       + (f", Funding {-p['funding']:+.2f} USD" if abs(p["funding"]) >= 0.01 else ""), netto, p["id"])
        if z is not None:
            z["s"].setdefault(f"{p['sid']}|{p['coin']}", {})["pause_bis"] = int(t) + PAUSE_S
        return netto

    def _funding_nachziehen(self, con, p, bis) -> None:
        h = (int(p["funding_bis"]) // 3600 + 1) * 3600
        while h <= bis:
            p["funding"] += self._funding_rate(con, p["coin"], h) * p["notional"] * (1 if p["seite"] == "long" else -1)
            p["funding_bis"] = h; h += 3600

    def _offene(self, st, coin) -> list:
        return [dict(zip(POS_SPALTEN, r)) for r in st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE status='offen' AND coin=?", (coin,))]

    def _positionen(self, con, st, coin, E, now, z) -> int:
        rows = [p for p in self._offene(st, coin) if not str(p["sid"]).startswith("grid_")]     # 23.40: Grid-Lose führt _grid
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(p["geprueft_bis"]) for p in rows), now // 60 * 60); n = 0
        for p in rows:
            kauf = p["seite"] == "long"; p_in = p["preis_ein"]; erledigt = False
            vorher = (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"])
            for ts, o, hi, lo, c in bars:
                if ts < p["geprueft_bis"]:
                    continue
                self._funding_nachziehen(con, p, ts + 60)
                nur_stop = ts < p["nur_stop_bis"]
                p["mae_pct"] = max(p["mae_pct"], ((p_in - lo) / p_in if kauf else (hi - p_in) / p_in) * 100)
                if not nur_stop:
                    p["mfe_pct"] = max(p["mfe_pct"], ((hi - p_in) / p_in if kauf else (p_in - lo) / p_in) * 100)
                sl, tp = p["sl"], p["tp"]
                if sl and ((kauf and lo <= sl) or (not kauf and hi >= sl)):
                    pr, bps = taker_preis(dict(b, mid=(min(o, sl) if kauf else max(o, sl))), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", ts + 60, z); erledigt = True; n += 1; break
                if not nur_stop and tp and ((kauf and hi > tp) or (not kauf and lo < tp)):
                    self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", ts + 60, z); erledigt = True; n += 1; break
                if p["ablauf"] and ts + 60 >= p["ablauf"]:
                    pr, bps = taker_preis(dict(b, mid=c), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", ts + 60, z); erledigt = True; n += 1; break
                p["geprueft_bis"] = ts + 60
            if erledigt:
                continue
            self._funding_nachziehen(con, p, now)
            sl, tp = p["sl"], p["tp"]
            if now - b["ts"] > KURS_FRISCH_S:
                pass                                                    # Kurs veraltet: nur die Minutenkerzen zählen
            elif sl and ((kauf and b["bid"] <= sl) or (not kauf and b["ask"] >= sl)):
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", now, z); n += 1; continue
            elif tp and now >= p["nur_stop_bis"] and ((kauf and b["bid"] > tp) or (not kauf and b["ask"] < tp)):
                self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", now, z); n += 1; continue
            elif p["ablauf"] and now >= p["ablauf"]:
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", now, z); n += 1; continue
            if (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"]) != vorher:     # einmal je Minute, nicht je Takt
                st.execute("UPDATE labor_position SET geprueft_bis=?, funding=?, funding_bis=?, mae_pct=?, mfe_pct=? WHERE id=?",
                           (p["geprueft_bis"], p["funding"], p["funding_bis"], p["mae_pct"], p["mfe_pct"], p["id"]))
        return n

    # --- Signale ausführen
    def _signale(self, con, st, coin, E, now, z) -> int:
        frisch = now - E["preis"]["ts"] <= KURS_FRISCH_S
        offen = {p["sid"]: p for p in self._offene(st, coin)}
        orders: dict = {}
        for oid, sid, seite, preis in st.execute("SELECT id, sid, seite, preis FROM labor_order WHERE status='offen' AND coin=?", (coin,)):
            orders.setdefault(sid, []).append([oid, seite, preis])
        n = 0
        for S in self.strategien:
            if S["fn"] == "grid":                                                  # 23.40: Grid hat eigene Mechanik (_grid)
                continue
            sid = S["sid"]; zs = z["s"].setdefault(f"{sid}|{coin}", {})
            zs["_orders"] = [(o[1], o[2]) for o in orders.get(sid, [])]            # flüchtig: liegende Limits für die Signalfunktion
            try:
                akts = SIGNALE[S["fn"]](S, E, coin, now, zs) or []
            except Exception as e:
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}"); continue
            sig = next((a for a in akts if a.get("typ") in ("markt", "limit")), None)
            zs.pop("_orders", None)
            for a in akts:
                typ = a.get("typ")
                if typ == "folge_aus":
                    p = offen.get(sid)
                    f = json.loads(p["folge"]) if p and p.get("folge") else None
                    if f and f.get("addr") == a["addr"] and f.get("seite_konto") == a["seite_konto"]:
                        p["coin"] = coin; self._funding_nachziehen(con, p, now)
                        pr, bps = taker_preis(E["preis"], p["seite"] != "long", p["notional"])
                        self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, a["grund"], now, z); offen.pop(sid, None)
                    continue
                if typ == "storno":
                    bleiben = []
                    for o in orders.get(sid, []):
                        if a.get("seite") in (None, o[1]):
                            st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                            self._ereignis(st, now, sid, coin, "storno", o[1], o[2], f"Limit storniert: {a.get('grund', '')}")
                        else:
                            bleiben.append(o)
                    orders[sid] = bleiben
                    continue
                if sid in offen or now < int(zs.get("pause_bis", 0)) or not frisch:
                    continue
                if typ == "markt":
                    kauf = a["seite"] == "long"; h = a.get("h", S["regeln"].get("h", 4)); sig_h = E["sigma4h"] * math.sqrt(h / 4)
                    pr, bps = taker_preis(E["preis"], kauf, self.notional)
                    sl, tp = a.get("sl_px"), a.get("tp_px")
                    k_sl, k_tp = a.get("sl", S["regeln"].get("sl")), a.get("tp", S["regeln"].get("tp"))
                    if sl is None and k_sl:
                        sl = pr * (1 - k_sl * sig_h) if kauf else pr * (1 + k_sl * sig_h)
                    if tp is None and k_tp:
                        tp = pr * (1 + k_tp * sig_h) if kauf else pr * (1 - k_tp * sig_h)
                    pid = self._eroeffnen(st, coin, S, a["seite"], now, pr, bps, GEB_TAKER, "Markt (Taker)", sl, tp,
                                          now + int(a.get("halten_s", h * 3600)), a.get("grund", ""), a.get("werte"), a.get("folge"))
                    offen[sid] = self._pos(st, pid)
                    for o in orders.pop(sid, []):
                        st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                    n += 1
                elif typ == "limit":
                    kauf = a["seite"] == "long"
                    vorh = [o for o in orders.get(sid, []) if o[1] == a["seite"]]
                    if vorh and abs(vorh[0][2] / a["preis"] - 1) <= a.get("toleranz", 0.001):
                        continue
                    if (kauf and a["preis"] >= E["preis"]["ask"]) or (not kauf and a["preis"] <= E["preis"]["bid"]):
                        continue                                        # läge schon im Markt -- kein Limit
                    for o in vorh:                                      # ersetzt: ein Ereignis „verschoben“ statt zweier
                        st.execute("UPDATE labor_order SET status='ersetzt', erledigt=? WHERE id=?", (now, o[0]))
                    cur = st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, "
                                     "sl_px, tp_px, halten_s, geprueft_bis) VALUES (?,?,?,?,?,?,'offen',?,?,?,?,?,?,?,?)",
                                     (sid, coin, a["seite"], a["preis"], now, now + int(a.get("gueltig_s", 4 * 3600)), a.get("grund", ""),
                                      _j(a.get("werte") or {}), a.get("sl_rel"), a.get("tp_rel"), a.get("sl_px"), a.get("tp_px"),
                                      int(a.get("halten_s", 6 * 3600)), (now // 60 + 1) * 60))
                    orders[sid] = [o for o in orders.get(sid, []) if o[1] != a["seite"]] + [[cur.lastrowid, a["seite"], a["preis"]]]
                    self._ereignis(st, now, sid, coin, "limit", a["seite"], a["preis"],
                                   f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} "
                                   + (f"verschoben von {vorh[0][2]:.6g} auf {a['preis']:.6g}" if vorh else f"bei {a['preis']:.6g} gesetzt")
                                   + f", gültig bis {_uhr(now + int(a.get('gueltig_s', 4 * 3600)))} — {a.get('grund', '')}")
            try:
                txt = status_text(S, E, now, zs)
            except Exception as e:
                txt = f"({type(e).__name__})"
            self.status[(sid, coin)] = {
                "ts": now, "text": txt,
                "signal": {"typ": sig["typ"], "seite": sig.get("seite"), "grund": sig.get("grund", "")} if sig else None,
                "blockiert": "Position offen" if sid in offen else (f"Pause bis {_uhr(zs['pause_bis'])}" if now < int(zs.get("pause_bis", 0))
                                                                     else (None if frisch else "Kurs veraltet")),
                "orders": len(orders.get(sid, []))}
        return n

    def _pos(self, st, pid) -> dict:
        return dict(zip(POS_SPALTEN, st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE id=?", (pid,)).fetchone()))

    # --- Grid (23.40, Nutzer 01.10.: „Range automatisch erkennen und anpassen; bei einer starken Bewegung aufwärts das Maximum abwarten und
    #     nicht zu früh verkaufen; bei stark fallenden Kursen ein Notausstieg“ -- dazu das Spiegelbild Short).
    #     Ein Grid je Strategie und Coin: Stufen L0 < … < Ln, Abstand i = [Li, Li+1] hält entweder ein Los oder eine Einstiegs-Order.
    #     Long kauft bei Li und verkauft bei Li+1, Short verkauft bei Li+1 und kauft bei Li zurück. Modi: warten → aktiv → halten / pause.
    #     Lose = labor_position (Notional = Kapital / n), Einstiegs-Orders = labor_order (nur offene; gefüllte und gelöschte verschwinden),
    #     Zustand = labor_zustand „g“. Füllungen und Ziele aus 1-min-Kerzen (wie die übrigen Strategien: ein Limit füllt nur, wenn der Kurs
    #     DURCH den Preis läuft; liegen Notlinie oder Trailing-Stop in derselben Kerze, gilt der Stop), Auslöser zusätzlich im 15-s-Takt.
    _LOS_SPALTEN = ("id", "sid", "coin", "seite", "eroeffnet", "preis_ein", "notional", "menge", "gebuehr_ein", "sl", "tp", "nur_stop_bis",
                    "funding", "funding_bis", "mae_pct", "mfe_pct", "werte")

    def _grid(self, con, st, coin, E, now, z) -> int:
        """Beide Grids eines Coins, jedes hinter einem eigenen Sicherungspunkt: Ein Fehler setzt nur dieses Grid in diesem Takt zurück
        (Datenbank und Zustand), statt halbe Änderungen zu speichern."""
        if not self.grid_strategien:
            return 0
        n = 0
        if coin not in self._grid_alt_ok:
            try:
                n += self._grid_alt_aufraeumen(con, st, coin, E, now)
            except Exception as e:
                self._fehler(f"Grid {coin} Aufräumen: {type(e).__name__}: {e}")
        for S in self.grid_strategien:
            key = f"{S['sid']}|{coin}"
            vorher = json.loads(_j(z["g"][key])) if isinstance(z["g"].get(key), dict) else None
            try:
                if not st.in_transaction:
                    # 23.41: IMMEDIATE -- Schreibsperre gleich zu Beginn (wartet wie jeder Schreibzugriff bis 30 s). 23.40 öffnete hier mit
                    # einem einfachen BEGIN eine LESE-Transaktion; schrieb danach ein anderer Thread (Prognose, Familien, Profis), scheiterte
                    # der nächste Schreibzugriff des Labors in diesem Takt SOFORT mit „database is locked“ (veralteter Lesestand, die Wartezeit
                    # greift nicht). Pi 02.10. 06:57: „ZEC Handel: OperationalError: database is locked“. Dieselbe Falle wie im Recorder
                    # am 14.09. (hl_recorder.db_connect, hl_dbcoord: „ein von Hand ausgeführtes BEGIN“).
                    st.execute("BEGIN IMMEDIATE")
                st.execute("SAVEPOINT grid_eins")
            except sqlite3.OperationalError as e:                        # Sperre länger als 30 s belegt: nur die Grids setzen aus
                self._fehler(f"Grid {coin}: Schreibsperre nicht frei ({e}) -- Grids setzen diesen Takt aus")
                return n
            try:
                n += self._grid_eins(con, st, coin, E, now, z, S)
                st.execute("RELEASE grid_eins")
            except Exception as e:
                st.execute("ROLLBACK TO grid_eins"); st.execute("RELEASE grid_eins")
                if vorher is None:
                    z["g"].pop(key, None)
                else:
                    z["g"][key] = vorher
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}")
        return n

    def _grid_eins(self, con, st, coin, E, now, z, S) -> int:
        key = f"{S['sid']}|{coin}"; gs = z["g"].get(key)
        if not isinstance(gs, dict):
            gs = z["g"][key] = {"modus": "warten", "seit": now, "gen": 0, "gepr": now // 60 * 60, "zaehler": {}}
        gs.setdefault("zaehler", {})
        lose = self._grid_lose(st, S["sid"], coin); orders = self._grid_orders(st, S["sid"], coin)
        n, aufgeholt = self._grid_kerzen(con, st, S, gs, coin, E, now, lose, orders)
        b = E.get("preis")
        if aufgeholt and b and now - b["ts"] <= KURS_FRISCH_S:          # Auslöser und Aufbau nur mit frischem Kurs und nachgeholten Kerzen
            n += self._grid_takt(con, st, S, gs, coin, E, now, lose, orders)
            n += self._grid_pruefen(con, st, S, gs, coin, E, now, lose, orders)
        self._grid_speichern(st, lose)
        self._grid_tag(st, S, gs, coin, E, now, lose, n > 0)
        self.status[(S["sid"], coin)] = self._grid_status(S, gs, E, now, lose, orders)
        return n

    # Lose und Orders
    def _grid_lose(self, st, sid, coin, pid=None) -> list:
        q = f"SELECT {', '.join(self._LOS_SPALTEN)} FROM labor_position WHERE status='offen' AND "
        rows = st.execute(q + "id=?", (pid,)) if pid else st.execute(q + "sid=? AND coin=? ORDER BY eroeffnet, id", (sid, coin))
        out = []
        for r in rows:
            p = dict(zip(self._LOS_SPALTEN, r))
            try:
                w = json.loads(p.pop("werte") or "{}")
            except ValueError:
                w = {}
            p["stufe"] = w.get("stufe"); p["gen"] = w.get("gen"); p["ab"] = int(p.pop("nur_stop_bis") or 0)
            p["funding"] = p["funding"] or 0.0; p["mae_pct"] = p["mae_pct"] or 0.0; p["mfe_pct"] = p["mfe_pct"] or 0.0
            p["funding_bis"] = int(p["funding_bis"] or p["eroeffnet"]); p["_dirty"] = False
            out.append(p)
        return out

    def _grid_orders(self, st, sid, coin) -> list:
        out = []
        for oid, seite, preis, werte, ab, tp in st.execute("SELECT id, seite, preis, werte, geprueft_bis, tp_px FROM labor_order "
                                                           "WHERE status='offen' AND sid=? AND coin=? ORDER BY preis", (sid, coin)).fetchall():
            try:
                w = json.loads(werte or "{}")
            except ValueError:
                w = {}
            out.append({"id": oid, "seite": seite, "preis": preis, "stufe": w.get("stufe"), "gen": w.get("gen"), "ab": int(ab or 0), "tp": tp})
        return out

    def _grid_speichern(self, st, lose) -> None:
        w = [(p["funding"], p["funding_bis"], p["mae_pct"], p["mfe_pct"], p["sl"], p["tp"], p["id"]) for p in lose if p.get("_dirty")]
        if w:
            st.executemany("UPDATE labor_position SET funding=?, funding_bis=?, mae_pct=?, mfe_pct=?, sl=?, tp=? WHERE id=?", w)
        for p in lose:
            p["_dirty"] = False

    def _grid_order(self, st, S, coin, gs, i, t) -> dict:
        """Einstiegs-Order für Abstand i der aktuellen Generation; füllbar erst ab der nächsten vollen Minute (keine Kerze, die schon lief)."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]
        preis, tp = (L[i], L[i + 1]) if lang else (L[i + 1], L[i])
        ab = -(-int(t) // 60) * 60
        cur = st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, sl_px, tp_px, "
                         "halten_s, geprueft_bis) VALUES (?,?,?,?,?,?,'offen',?,?,NULL,NULL,?,?,0,?)",
                         (S["sid"], coin, "long" if lang else "short", preis, int(t), int(t) + 365 * 86_400,
                          f"Grid {gs['gen']}: {'Kauf' if lang else 'Verkauf'} Stufe {i + 1}/{gs['n']}, Ziel {tp:.6g}",
                          _j({"stufe": i, "gen": gs["gen"]}), gs["notlinie"], tp, ab))
        return {"id": cur.lastrowid, "seite": "long" if lang else "short", "preis": preis, "stufe": i, "gen": gs["gen"], "ab": ab, "tp": tp}

    def _grid_orders_weg(self, st, orders) -> None:
        if orders:
            st.executemany("DELETE FROM labor_order WHERE id=?", [(o["id"],) for o in orders])
            orders.clear()

    def _grid_los_auf(self, st, S, coin, gs, i, t, preis, slip_bps, satz, art, ab) -> dict:
        """Los für Abstand i (Ziel eine Stufe weiter, Notlinie als Stop). ab = erste Kerze, in der das Ziel zählen darf."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]
        pid = self._eroeffnen(st, coin, S, "long" if lang else "short", t, preis, slip_bps, satz, art, gs["notlinie"], L[i + 1] if lang else L[i], 0,
                              f"Grid {gs['gen']}: Stufe {i + 1}/{gs['n']}", {"stufe": i, "gen": gs["gen"]}, None, pruef_ab=int(ab), nur_stop_bis=int(ab),
                              notional=gs["los_usd"], ereignis_art="grid_los")
        return self._grid_lose(st, S["sid"], coin, pid=pid)[0]

    def _grid_wert(self, coin, lose, mid) -> float | None:
        """Bestandswert (unrealisiert) zum Kurs mid nach Ausstiegsgebühr (Taker) und Funding -- wie die offenen Positionen der Übersicht."""
        if not lose:
            return 0.0
        if not mid:
            return None
        v = 0.0
        for p in lose:
            v += ((mid - p["preis_ein"]) * p["menge"] * (1 if p["seite"] == "long" else -1) - p["gebuehr_ein"]
                  - p["menge"] * mid * gebuehr(coin, GEB_TAKER) - (p["funding"] or 0.0))
        return v

    def _grid_alle_zu(self, con, st, coin, lose, b, t, px, art, grund) -> float:
        """Alle Lose eines Grids zum Marktpreis (Taker) als EIN Auftrag über die Summe -- Marktauswirkung aus der Buchtiefe für die ganze
        Menge. px = Ausführungsmitte aus der Kerze (Stop, bei Kurslücke die Eröffnung); None = Buch des Taktes."""
        if not lose:
            return 0.0
        lang = lose[0]["seite"] == "long"
        pr, bps = taker_preis(dict(b, mid=px) if px else b, not lang, sum(p["notional"] for p in lose))
        netto = 0.0
        for p in lose:
            self._funding_nachziehen(con, p, t)
            netto += self._schliessen(st, p, pr, art, GEB_TAKER, bps, grund, t, None, ereignis_art="grid_los")
        lose.clear()
        return netto

    # Zustandswechsel
    def _grid_ruhe(self, st, S, gs, coin, orders, t, stunden, text, preis=None, netto=None) -> None:
        """Pause: Orders weg, neue Range erst nach `stunden` und nur aus Kursen ab jetzt."""
        self._grid_orders_weg(st, orders)
        bis = int(t) + int(stunden * 3600)
        gs.update(modus="pause", seit=int(t), reset=int(t), pause_bis=bis, halten=None, hinweis=None)
        self._ereignis(st, t, S["sid"], coin, "grid", S["regeln"]["richtung"], preis,
                       f"{text}; Pause bis {_uhr(bis)}, danach neue Range nur aus Kursen ab jetzt", netto)

    def _grid_notaus(self, con, st, S, gs, coin, lose, orders, b, t, px, grund) -> None:
        """Alle Lose zum Marktpreis, Orders weg, Pause: 4 h, nach dem zweiten Notausstieg binnen 24 h 12 h, nach dem dritten 24 h."""
        n_ = len(lose)
        netto = self._grid_alle_zu(con, st, coin, lose, b, t, px, "Notausstieg (Taker)", "Notausstieg: " + grund)
        gs["zaehler"]["notaus"] = gs["zaehler"].get("notaus", 0) + 1
        zeiten = [x for x in (gs.get("notaus_t") or []) if int(t) - int(x) < 86_400] + [int(t)]
        gs["notaus_t"] = zeiten
        stufen = list(S["regeln"]["pause_notaus_h"]); h = stufen[min(len(zeiten), len(stufen)) - 1]
        self._grid_ruhe(st, S, gs, coin, orders, t, h,
                        f"Notausstieg: {grund} — " + (f"{n_} Lose zum Marktpreis geschlossen, netto {netto:+.2f} USD" if n_ else "keine Lose offen")
                        + (f" ({len(zeiten)}. Notausstieg binnen 24 h: {h} h Pause)" if len(zeiten) > 1 else ""),
                        px or b.get("mid"), netto if n_ else None)

    def _grid_halten(self, st, S, gs, coin, lose, orders, t, px, extrem, sig1h, grund) -> None:
        """Starke Bewegung in Gewinnrichtung: Ziele aussetzen, alle Lose halten, Trailing-Stop trail · σ(1 h) vom Extrem (zählt ab der
        nächsten vollen Kerze -- die laufende enthält Kurse von vor dem Auslöser)."""
        R = S["regeln"]; lang = R["richtung"] == "long"
        ext = max(px, extrem) if lang else min(px, extrem)
        stop = ext * (1 - R["trail"] * sig1h) if lang else ext * (1 + R["trail"] * sig1h)
        gs.update(modus="halten", seit=int(t), halten={"start": int(t), "ab": -(-int(t) // 60) * 60, "start_px": px, "extrem": ext, "stop": stop,
                                                        "sig": sig1h, "grund": grund})
        gs["zaehler"]["halten"] = gs["zaehler"].get("halten", 0) + 1
        self._grid_orders_weg(st, orders)
        for p in lose:
            p["tp"] = None; p["sl"] = stop; p["_dirty"] = True
        self._ereignis(st, t, S["sid"], coin, "grid", R["richtung"], px,
                       f"{grund}: {'Verkäufe' if lang else 'Rückkäufe'} ausgesetzt, {len(lose)} Lose werden gehalten; Trailing-Stop {R['trail']:g} σ(1 h) "
                       f"= {R['trail'] * sig1h * 100:.2f} % {'unter dem höchsten Hoch' if lang else 'über dem tiefsten Tief'}, jetzt {stop:.6g}")

    def _grid_halten_ende(self, con, st, S, gs, coin, lose, orders, b, t, px) -> None:
        R = S["regeln"]; lang = R["richtung"] == "long"; H = gs.get("halten") or {}; n_ = len(lose)
        netto = self._grid_alle_zu(con, st, coin, lose, b, t, px, "Trailing-Stop (Taker)",
                                   f"Halten beendet: {R['trail']:g} σ(1 h) vom {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} zurück")
        self._grid_ruhe(st, S, gs, coin, orders, t, R["pause_trail_h"],
                        f"Halten beendet: Kurs {'fiel' if lang else 'stieg'} {R['trail']:g} σ(1 h) vom {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} "
                        f"zurück (Start {H.get('start_px', 0):.6g} um {_uhr(H.get('start'))}) — {n_} Lose zu etwa {px:.6g} geschlossen, "
                        f"netto {netto:+.2f} USD", px, netto)

    # Kerzen, Takt, Range
    def _grid_kerzen(self, con, st, S, gs, coin, E, now, lose, orders) -> tuple:
        """Abgeschlossene Kerzen seit dem letzten Stand nachspielen. Nach langem Ausfall in Etappen von höchstens 3 Tagen je Takt -- bis
        alles nachgeholt ist (zweiter Wert False), gibt es keine Auslöser und keinen Aufbau zum Kurs von jetzt."""
        t0 = int(gs.get("gepr") or now // 60 * 60); t1 = min(now // 60 * 60, t0 + 3 * 86_400)
        if t1 <= t0:
            return 0, True
        schluss = {}; n = 0
        for ts, o, hi, lo, c in kerzen(con, coin, t0 - 15 * 60, t1):
            schluss[ts] = c
            if ts < t0:
                continue
            n += self._grid_kerze(con, st, S, gs, coin, E, lose, orders, ts, o, hi, lo, c, schluss.get(ts - 15 * 60), schluss.get(ts - 5 * 60))
            gs["gepr"] = ts + 60
        return n, t1 >= now // 60 * 60

    def _grid_kerze(self, con, st, S, gs, coin, E, lose, orders, ts, o, hi, lo, c, c15, c5) -> int:
        """Eine abgeschlossene 1-min-Kerze. Reihenfolge (vorsichtig): Einstiege in Verlustrichtung zuerst, dann Notlinie bzw. Trailing-Stop
        für ALLE Lose (auch die eben gefüllten), erst dann Ziele; Auslöser zum Kerzenschluss; zuletzt freie Abstände neu belegen."""
        R = S["regeln"]; lang = R["richtung"] == "long"; b = E["preis"]; m = gs.get("modus"); n = 0
        for p in lose:
            if ts + 60 <= p["eroeffnet"]:
                continue
            self._funding_nachziehen(con, p, ts + 60)
            pin = p["preis_ein"]
            p["mae_pct"] = max(p["mae_pct"], ((pin - lo) / pin if lang else (hi - pin) / pin) * 100)
            if ts >= p["ab"]:
                p["mfe_pct"] = max(p["mfe_pct"], ((hi - pin) / pin if lang else (pin - lo) / pin) * 100)
            p["_dirty"] = True
        if m == "halten":
            H = gs.get("halten") or {}
            if not lose:                                                  # nichts mehr zu halten (z. B. abgelöste Regelversion)
                self._grid_ruhe(st, S, gs, coin, orders, ts + 60, R["pause_trail_h"], "Halten beendet: keine Lose mehr")
                return 1
            if ts >= H["ab"] and ((lang and lo <= H["stop"]) or (not lang and hi >= H["stop"])):
                self._grid_halten_ende(con, st, S, gs, coin, lose, orders, b, ts + 60, min(o, H["stop"]) if lang else max(o, H["stop"]))
                return 1
            if ts + 60 > H["start"]:
                ext = max(H["extrem"], hi) if lang else min(H["extrem"], lo)
                stop = ext * (1 - R["trail"] * H["sig"]) if lang else ext * (1 + R["trail"] * H["sig"])
                stop = max(stop, H["stop"]) if lang else min(stop, H["stop"])
                if ext != H["extrem"] or stop != H["stop"]:
                    H["extrem"] = ext; H["stop"] = stop
                    for p in lose:
                        p["sl"] = stop; p["_dirty"] = True
            return 0
        if m != "aktiv":
            return 0
        # 1. Einstiege: Limits, durch die der Kurs läuft (Long: Tief unter dem Kauf-Limit, Short: Hoch über dem Verkaufs-Limit)
        for od in list(orders):
            if od["ab"] > ts or not ((lang and lo < od["preis"]) or (not lang and hi > od["preis"])):
                continue
            st.execute("DELETE FROM labor_order WHERE id=?", (od["id"],)); orders.remove(od)
            if od.get("gen") != gs.get("gen") or od.get("stufe") is None or not 0 <= od["stufe"] < gs["n"]:
                continue
            lose.append(self._grid_los_auf(st, S, coin, gs, od["stufe"], ts + 30, od["preis"], 0.0, GEB_MAKER,
                                           "Grid-Kauf (Maker)" if lang else "Grid-Verkauf (Maker)", ts + 60))
            gs["zaehler"]["einstiege"] = gs["zaehler"].get("einstiege", 0) + 1
            n += 1
        # 2. Notlinie eine Stufe jenseits der Range: gilt für alle Lose, auch die eben gefüllten
        nl = gs["notlinie"]
        if (lang and lo <= nl) or (not lang and hi >= nl):
            self._grid_notaus(con, st, S, gs, coin, lose, orders, b, ts + 60, min(o, nl) if lang else max(o, nl),
                              f"Kurs {'unter' if lang else 'über'} der Notlinie {nl:.6g} (eine Stufe {'unter' if lang else 'über'} der Range)")
            return n + 1
        # 3. Ziele (Maker), nicht in der Einstiegskerze
        for p in list(lose):
            if p["tp"] is None or ts < p["ab"] or not ((lang and hi > p["tp"]) or (not lang and lo < p["tp"])):
                continue
            self._schliessen(st, p, p["tp"], "Grid-Verkauf (Maker)" if lang else "Grid-Rückkauf (Maker)", GEB_MAKER, 0.0,
                             f"Grid-Ziel {p['tp']:.6g}", ts + 60, None, ereignis_art="grid_los")
            lose.remove(p); n += 1
            gs["zaehler"]["runden"] = gs["zaehler"].get("runden", 0) + 1
        # 4. Starke Bewegung zum Kerzenschluss (z über 15 und 5 min aus den Schlusskursen; σ(5 min) = σ(15 min) / √3)
        z15 = math.log(c / c15) / max(E["sigma15"], 1e-6) if c15 else None
        z5 = math.log(c / c5) / max(E["sigma15"] / math.sqrt(3), 1e-6) if c5 else None
        n += self._grid_ausloeser(con, st, S, gs, coin, E, lose, orders, ts + 60, c, z15, z5, None, hi if lang else lo, False)
        # 5. Freie Abstände der aktuellen Generation wieder belegen (nach einem Verkauf liegt dort wieder ein Kauf-Limit)
        if gs.get("modus") == "aktiv":
            n += self._grid_auffuellen(st, S, gs, coin, lose, orders, ts + 60, c)
        return n

    def _grid_takt(self, con, st, S, gs, coin, E, now, lose, orders) -> int:
        K = E.get("kaskade") or {}
        if K.get("aktiv") and K.get("id") is not None and gs.get("modus") != "aktiv":
            gs["kaskade_id"] = K["id"]                                    # außerhalb von „aktiv“ gesehen: später nicht mehr auslösen
        b = E["preis"]
        alt5 = [x for x in (E.get("kerzen20") or []) if x[0] <= now // 60 * 60 - 5 * 60]     # wie z15 der Kaskade: Schluss vor 5 min
        z5 = math.log(b["mid"] / alt5[-1][4]) / max(E["sigma15"] / math.sqrt(3), 1e-6) if alt5 and alt5[-1][4] else None
        return self._grid_ausloeser(con, st, S, gs, coin, E, lose, orders, now, b["mid"], K.get("z"), z5, K, b["mid"], True)

    def _grid_ausloeser(self, con, st, S, gs, coin, E, lose, orders, t, px, z15, z5, K, extrem, takt) -> int:
        """Starke Bewegung gegen das Grid → Notausstieg (Kaskade, z15 in der ungünstigen Hälfte); in Gewinnrichtung → halten (mit Bestand)
        bzw. ruhen (Range verlassen, kein Bestand) -- dort zählt auch z5, sonst ist der Bestand eines engen Grids schon verkauft.
        K = Kaskaden-Stand (nur im Takt); jede Kaskade zählt einmal."""
        if gs.get("modus") != "aktiv":
            return 0
        R = S["regeln"]; lang = R["richtung"] == "long"; zg = R["bewegung_z"]
        kas = None
        if K and K.get("aktiv") and K.get("id") is not None and K.get("id") != gs.get("kaskade_id"):
            kas = K.get("richtung"); gs["kaskade_id"] = K["id"]
        mitte = math.sqrt(gs["unten"] * gs["oben"])
        grund = None
        if kas == ("ab" if lang else "auf"):
            grund = (f"{'Liquidationskaskade abwärts' if lang else 'Short-Squeeze aufwärts'} ({(K.get('z_start') or 0):+.1f} σ in 15 min, "
                     f"{(K.get('liq_usd') or 0) / 1e6:.2f} Mio {'Long' if lang else 'Short'}-Liquidationen)")
        elif z15 is not None and (z15 <= -zg if lang else z15 >= zg) and (px < mitte if lang else px > mitte):
            grund = f"{z15:+.1f} σ in 15 min in der {'unteren' if lang else 'oberen'} Hälfte der Range"
        if grund:
            self._grid_notaus(con, st, S, gs, coin, lose, orders, E["preis"], t, None if takt else px, grund)
            return 1
        raus = (px > gs["oben"] * (1 + gs["schritt"])) if lang else (px < gs["unten"] * (1 - gs["schritt"]))
        guenstig = px > mitte if lang else px < mitte          # Schub nur in der Gewinnhälfte: unten ist ein schneller Anstieg ein Rücklauf
        if kas == ("auf" if lang else "ab"):
            grund = f"{'Short-Squeeze aufwärts' if lang else 'Liquidationskaskade abwärts'} ({(K.get('z_start') or 0):+.1f} σ in 15 min)"
        elif guenstig and z15 is not None and (z15 >= zg if lang else z15 <= -zg):
            grund = f"Starke Bewegung {'aufwärts' if lang else 'abwärts'}: {z15:+.1f} σ in 15 min"
        elif guenstig and z5 is not None and (z5 >= zg if lang else z5 <= -zg):
            grund = f"Starke Bewegung {'aufwärts' if lang else 'abwärts'}: {z5:+.1f} σ in 5 min"
        elif raus:
            grund = f"Ausbruch {'über' if lang else 'unter'} die Range ({gs['oben'] if lang else gs['unten']:.6g})"
        if not grund:
            return 0
        n_v = 0
        if lose and takt:
            # im Takt (mitten in der Minute): Ziele, die der Kurs bis jetzt schon durchlaufen hat, waren vor dem Auslöser verkauft
            for p in [p for p in lose if p["tp"] is not None and ((lang and p["tp"] <= px) or (not lang and p["tp"] >= px))]:
                self._schliessen(st, p, p["tp"], "Grid-Verkauf (Maker)" if lang else "Grid-Rückkauf (Maker)", GEB_MAKER, 0.0,
                                 f"Grid-Ziel {p['tp']:.6g}", t, None, ereignis_art="grid_los")
                lose.remove(p); n_v += 1
                gs["zaehler"]["runden"] = gs["zaehler"].get("runden", 0) + 1
        if lose:
            self._grid_halten(st, S, gs, coin, lose, orders, t, px, extrem, E["sigma1h"], grund)
            return 1 + n_v
        if raus:
            self._grid_ruhe(st, S, gs, coin, orders, t, R["pause_trail_h"], f"{grund}, ohne Bestand — Grid ruht", px)
            return 1 + n_v
        return n_v

    def _grid_auffuellen(self, st, S, gs, coin, lose, orders, t, px) -> int:
        """Freie Abstände der aktuellen Generation auf der Einstiegsseite (Long: unter dem Kurs) mit Orders belegen, nächste am Kurs zuerst --
        nur soweit das Kapital reicht (Lose aller Generationen + liegende Orders <= GRID_KAPITAL)."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]; los = gs["los_usd"]; g = gs["gen"]
        frei = GRID_KAPITAL - sum(p["notional"] for p in lose) - los * len(orders)
        if frei < los - 1e-6:
            return 0
        belegt = {p["stufe"] for p in lose if p.get("gen") == g} | {o["stufe"] for o in orders}
        kand = sorted((i for i in range(gs["n"]) if i not in belegt and (L[i] < px if lang else L[i + 1] > px)),
                      key=lambda i: -L[i] if lang else L[i + 1])
        neu = 0
        for i in kand:
            if frei < los - 1e-6:
                break
            orders.append(self._grid_order(st, S, coin, gs, i, t)); frei -= los; neu += 1
        return neu

    def _grid_pruefen(self, con, st, S, gs, coin, E, now, lose, orders) -> int:
        """Range prüfen: im Modus „warten“ jede Minute (Aufbau), im Modus „aktiv“ alle pruef_min Minuten (Nachführen)."""
        R = S["regeln"]; m = gs.get("modus")
        if m == "halten":
            return 0
        if m == "pause":
            if now < int(gs.get("pause_bis") or 0):
                return 0
            gs.update(modus="warten", seit=now); m = "warten"
        if now - int(gs.get("geprueft") or 0) < (60 if m == "warten" else int(R["pruef_min"]) * 60):
            return 0
        gs["geprueft"] = now
        von = max(now - int(R["fenster_h"] * 3600), int(gs.get("reset") or 0))
        # Ergebnis (nicht die Kursliste) je Minute zwischenspeichern: beide Grids eines Coins rechnen meist dasselbe Fenster
        rg = self._gecacht((coin, "grid_rg", von // 60, now // 60, R["p_rand"]), 60, now,
                           lambda: grid_range(grid_kurse(con, coin, von, now // 60 * 60), R["p_rand"]))
        K = E.get("kaskade") or {}; px = E["preis"]["mid"]
        if not rg:
            gs["hinweis"] = f"sammelt Kurse seit {_uhr(von)} (mindestens 2 h)"
            return 0
        stufen = grid_stufen(rg["unten"], rg["oben"], R["schritt_min"], R["stufen_min"], R["stufen_max"])
        gs["range_jetzt"] = {"unten": rg["unten"], "oben": rg["oben"], "trend": rg["trend"], "von": von, "ts": now}
        seitwaerts = grid_trend_ok(rg["trend"], R)
        if m == "warten":
            if K.get("aktiv"):
                grund = "Kaskade läuft"
            elif not seitwaerts:
                lang = R["richtung"] == "long"
                grund = ("Trend " + ("—" if rg["trend"] is None else f"{rg['trend']:+.1f}") + f" (aufgebaut wird bei {-R['trend_gegen'] if lang else -R['trend_mit']:+g} "
                         f"bis {R['trend_mit'] if lang else R['trend_gegen']:+g})").replace(".", ",")
            elif not stufen:
                grund = (f"Range zu eng ({(rg['oben'] / rg['unten'] - 1) * 100:.2f} %; mindestens {R['stufen_min']} Stufen à "
                         f"{R['schritt_min'] * 100:.1f} %)").replace(".", ",")
            else:
                L, schritt = stufen; zone = R["zone"] * (L[-1] - L[0])
                grund = None if L[0] + zone <= px <= L[-1] - zone else f"Kurs am Rand der Range {L[0]:.6g}–{L[-1]:.6g}"
            if grund:
                gs["hinweis"] = grund
                return 0
            return self._grid_aufbauen(st, S, gs, coin, E, now, stufen[0], stufen[1], rg, lose, orders, "aufgebaut")
        # aktiv: nachführen, wenn sich die Range deutlich verändert hat -- nur seitwärts, ohne Kaskade, Kurs innerhalb der neuen Range
        if K.get("aktiv") or not seitwaerts or not stufen:
            return 0
        L, schritt = stufen
        if not L[0] < px < L[-1]:
            return 0
        verschoben = abs(math.log(math.sqrt(L[0] * L[-1]) / math.sqrt(gs["unten"] * gs["oben"]))) >= R["verschiebung"] * gs["schritt"]
        breite = abs(math.log(math.log(L[-1] / L[0]) / math.log(gs["oben"] / gs["unten"]))) >= math.log(1 + R["breite_rel"])
        if not (verschoben or breite):
            return 0
        return self._grid_aufbauen(st, S, gs, coin, E, now, L, schritt, rg, lose, orders, "nachgeführt")

    def _grid_aufbauen(self, st, S, gs, coin, E, now, L, schritt, rg, lose, orders, art) -> int:
        """Neue Generation von Stufen. Bestand wie bei einem klassischen Grid: Abstände jenseits des Kurses in Gewinnrichtung (Long: darüber)
        halten ein Los, die übrigen eine Einstiegs-Order. Vorhandene Lose (auch älterer Generationen) behalten ihr Ziel und zählen auf den
        Bestand an: gekauft wird nur, was zum klassischen Bestand fehlt; Orders nur, soweit das Kapital reicht."""
        R = S["regeln"]; lang = R["richtung"] == "long"; b = E["preis"]; px = b["mid"]; n = len(L) - 1
        self._grid_orders_weg(st, orders)
        gen = int(gs.get("gen") or 0) + 1; los = GRID_KAPITAL / n
        nl = L[0] * (1 - R["puffer"] * schritt) if lang else L[-1] * (1 + R["puffer"] * schritt)
        gs.update(modus="aktiv", gen=gen, stufen=L, n=n, schritt=schritt, unten=L[0], oben=L[-1], notlinie=nl, los_usd=los, aufgebaut=now,
                  trend=rg["trend"], hinweis=None, halten=None)
        if art == "aufgebaut":
            gs["seit"] = now
        gs["zaehler"][art] = gs["zaehler"].get(art, 0) + 1
        bestand = sorted((i for i in range(n) if (L[i] > px if lang else L[i + 1] < px)), key=lambda i: L[i] if lang else -L[i + 1])
        einstieg = sorted((i for i in range(n) if not (L[i] > px if lang else L[i + 1] < px)), key=lambda i: -L[i] if lang else L[i + 1])
        gehalten = sum(p["notional"] for p in lose)
        k = min(len(bestand), max(0, int((len(bestand) * los - gehalten) / los + 1e-9))) if R["startbestand"] else 0
        teile = [f"Range {L[0]:.6g}–{L[-1]:.6g} ({(L[-1] / L[0] - 1) * 100:.2f} %, Trend {rg['trend']:.2f}, Kurse ab {_uhr(rg['von'])})",
                 f"{n} Stufen à {schritt * 100:.2f} %, {los:.0f} USD je Los", f"Notlinie {nl:.6g}"]
        if k:
            pr, bps = taker_preis(b, lang, k * los)
            for i in bestand[:k]:
                lose.append(self._grid_los_auf(st, S, coin, gs, i, now, pr, bps, GEB_TAKER, "Startbestand (Taker)", -(-now // 60) * 60))
            teile.append(f"Startbestand {k} Lose zu {pr:.6g}")
        if gehalten:
            teile.append(f"{len(lose) - k} Lose aus früheren Stufen behalten ihr Ziel")
        frei = GRID_KAPITAL - gehalten - k * los
        n_o = min(len(einstieg), max(0, int(frei / los + 1e-9)))
        for i in einstieg[:n_o]:
            orders.append(self._grid_order(st, S, coin, gs, i, now))
        teile.append(f"{n_o} {'Kauf' if lang else 'Verkaufs'}-Limits")
        for p in lose:
            if p["sl"] != nl and p["tp"] is not None:
                p["sl"] = nl; p["_dirty"] = True
        self._ereignis(st, now, S["sid"], coin, "grid", R["richtung"], px, f"Grid {gen} {art}: " + " · ".join(teile))
        return 1 + k + n_o

    def _grid_alt_aufraeumen(self, con, st, coin, E, now) -> int:
        """Lose und Orders abgelöster Grid-Regelversionen (neue Kennung) schließen bzw. löschen -- sonst lägen sie ohne Führung offen."""
        b = E.get("preis")
        if not b or now - b["ts"] > KURS_FRISCH_S:
            return 0
        self._grid_alt_ok.add(coin)
        n = 0
        for (sid,) in st.execute("SELECT sid FROM labor_strategie WHERE aktiv=0 AND name IN (?, ?)", GRID_NAMEN).fetchall():
            if sid in self.grid_sids:
                continue
            st.execute("DELETE FROM labor_order WHERE status='offen' AND sid=? AND coin=?", (sid, coin))
            lose = self._grid_lose(st, sid, coin)
            if lose:
                n += len(lose)
                self._grid_alle_zu(con, st, coin, lose, b, now, None, "Markt (Taker)", "Regelversion abgelöst")
        return n

    # Tagesstand und Anzeige
    def _grid_tag(self, st, S, gs, coin, E, now, lose, geaendert) -> None:
        """Bestandswert für die Tagesbilanz (labor_grid_tag, ein Stand je Tag, der jeweils letzte): nach jeder Änderung und alle 5 min."""
        letzt = int(gs.get("_tag_ts") or 0)
        if not geaendert and now - letzt < GRID_TAG_S and now // 86_400 == letzt // 86_400:
            return
        b = E.get("preis") or {}
        mid = b.get("mid") if b and now - b.get("ts", 0) <= KURS_FRISCH_S else ((E.get("kerze") or [None] * 5)[4])
        wert = self._grid_wert(coin, lose, mid)
        if wert is None:
            return
        st.execute("INSERT OR REPLACE INTO labor_grid_tag VALUES (?,?,?,?,?,?,?)", (S["sid"], coin, now // 86_400 * 86_400, wert, len(lose), mid, now))
        gs["_tag_ts"] = now

    def _grid_status(self, S, gs, E, now, lose, orders) -> dict:
        R = S["regeln"]; lang = R["richtung"] == "long"; m = gs.get("modus"); H = gs.get("halten") or {}
        mid = (E.get("preis") or {}).get("mid")
        if m == "aktiv":
            txt = (f"{len(lose)}/{gs.get('n')} Lose · Range {gs['unten']:.6g}–{gs['oben']:.6g} · Schritt {gs['schritt'] * 100:.2f} % · "
                   f"Notlinie {gs['notlinie']:.6g}")
        elif m == "halten":
            txt = f"hält {len(lose)} Lose · {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} · Trailing-Stop {H.get('stop', 0):.6g}"
        elif m == "pause":
            txt = f"Pause bis {_uhr(gs.get('pause_bis'))}"
        else:
            txt = "wartet: " + (gs.get("hinweis") or "prüft die Range")
        return {"ts": now, "text": txt, "signal": None, "blockiert": None, "orders": len(orders),
                "grid": {"modus": m, "richtung": R["richtung"], "lose": len(lose), "n": gs.get("n"), "gen": gs.get("gen"), "unten": gs.get("unten"),
                         "oben": gs.get("oben"), "notlinie": gs.get("notlinie"), "schritt": gs.get("schritt"),
                         "bestand_usd": self._grid_wert(E.get("coin"), lose, mid), "einsatz_usd": sum(p["notional"] for p in lose),
                         "stop": H.get("stop"), "extrem": H.get("extrem"), "pause_bis": gs.get("pause_bis"), "hinweis": gs.get("hinweis"),
                         "seit": gs.get("seit"), "zaehler": dict(gs.get("zaehler") or {})}}


# ------------------------------------------------------------------------------------------------ Auswertung
def _betacf(a: float, b: float, x: float) -> float:
    """Kettenbruch der unvollständigen Betafunktion (Numerical Recipes 6.4)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300); h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        de = d * c; h *= de
        if abs(de - 1.0) < 1e-12:
            break
    return h


def p_t_einseitig(t: float, df: int) -> float:
    """P(T >= t) der Student-t-Verteilung mit df Freiheitsgraden -- bei wenigen Trades deutlich vorsichtiger als die Normalverteilung."""
    if df <= 0:
        return 1.0
    x = df / (df + t * t)
    a, b = df / 2.0, 0.5
    if x >= 1.0:
        zwei = 1.0                                    # t = 0
    elif x <= 0.0:
        zwei = 0.0
    else:
        lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
        front = math.exp(lbeta + a * math.log(x) + b * math.log(1 - x))
        ib = front * _betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - front * _betacf(b, a, 1 - x) / b
        zwei = min(1.0, max(0.0, ib))                 # P(|T| >= |t|) = I_x(df/2, 1/2)
    return zwei / 2 if t >= 0 else 1 - zwei / 2


def bloecke(tr: list, block_s: int) -> list:
    """
    23.34: Mittel der Netto-Rendite je Block -- Trades, die im selben Block der Länge block_s (Horizont der Strategie) eröffnet
    wurden, sind EINE Beobachtung (meist dasselbe Signal in mehreren korrelierten Coins zugleich). Reihenfolge = Zeit.
    """
    b: dict = {}
    for t in tr:
        b.setdefault(int(t["eroeffnet"]) // max(int(block_s), 60), []).append(t["netto_pct"])
    return [sum(v) / len(v) for _, v in sorted(b.items())]


def coin_starts(st, coins=COINS, now: int | None = None, schreiben: bool = False) -> dict:
    """
    {Coin: Start des simulierten Kontos} (labor_zustand „coins“). 23.34: Jeder Coin zählt ab seinem eigenen Start -- XMR kam später
    dazu. Beim ersten Schreiben nach dem Update übernehmen die Coins von 23.33 den gemeinsamen Start, neue Coins beginnen jetzt.
    """
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='coins'").fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except (sqlite3.Error, ValueError):
        d = {}
    d = {str(k): int(v) for k, v in (d.items() if isinstance(d, dict) else []) if v}
    if not schreiben:
        return d
    now = int(now or time.time()); neu = dict(d)
    if not d:
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        alt = int(r0[0]) if r0 and r0[0] else now
        for c in coins:
            neu[c] = alt if c in COINS_2333 else now
    for c in coins:
        neu.setdefault(c, now)
    if neu != d:
        st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('coins', ?)", (_j(neu),))
    return neu


def konten_tage(erstellt: int, ende: int, starts: dict, coins) -> float:
    """Summe der Tage, die die Konten einer Strategie gelaufen sind: je Coin ab max(Strategie erstellt, Coin-Start) bis ende."""
    return sum(max(0, int(ende) - max(int(erstellt or 0), int(starts.get(c) or erstellt or 0))) for c in coins) / 86_400


def _stat(tr: list, erstellt: int, now: int, kt: float | None = None, notional: float = NOTIONAL, block_s: int | None = None,
          bloecke_werte: list | None = None, summe_extra: float = 0.0) -> dict:
    """
    Kennzahlen einer Strategie (oder eines Coins). Konto = je Coin ein simuliertes Konto über `notional` USD; die Tagesrendite teilt
    die Summe durch die Kontotage kt (23.34: je Coin ab seinem Start; ohne Angabe Laufzeit × Coins) -- auch Tage ohne Trade zählen.
    23.34: t, Zufalls-/Glückswahrscheinlichkeit, Hälften und Stufen auf BLÖCKEN (block_s = Horizont): gleichzeitige Trades der Strategie
    zählen einmal (n_eff). Ø netto, Treffer, Kelly und die Hebel-Ansicht bleiben je Trade.
    23.40 (Grid): bloecke_werte ersetzt die Blöcke (Tagesergebnis nach Bestandswert in % des Kapitals), summe_extra = unrealisierter
    Bestandswert, zählt in Summe, Ø/Tag, Stufe und Hebel-Summe mit. Trades mit eigenem Notional (Grid-Lose): Liquidation kostet ihre
    Marge, der Kontofaktor wächst mit ihrem Anteil am Konto. Für Trades über `notional` (alle übrigen) unverändert.
    """
    n = len(tr)
    out = {"n": n, "n_eff": 0, "treffer": None, "mittel_pct": None, "t": None,
           "summe_usd": round(sum(t["netto_usd"] for t in tr) + summe_extra, 2),
           "realisiert_usd": round(sum(t["netto_usd"] for t in tr), 2), "bestand_usd": round(summe_extra, 2),
           "gebuehren_usd": round(sum(t["gebuehren"] for t in tr), 2), "funding_usd": round(sum(t["funding"] for t in tr), 2),
           "pf": None, "max_dd_usd": 0.0, "trades_tag": None, "letzter": max((t["geschlossen"] for t in tr), default=None),
           "haelften": None, "kelly": None, "hebel": [], "stufe": "Kandidat", "slip_bps": None, "p_zufall": None, "tag_pct": None}
    tage = max((now - erstellt) / 86_400, 1 / 24) if erstellt else None
    if kt is None and tage:
        kt = tage * len(COINS)
    kt = max(kt, 1 / 24) if kt else None
    if tage:
        out["tage"] = round(tage, 2); out["trades_tag"] = round(n / tage, 2)
    if kt:
        out["konten_tage"] = round(kt, 2)
        out["tag_pct"] = out["summe_usd"] / kt / notional * 100
    if not n:
        return out
    r = [t["netto_pct"] for t in tr]; m = sum(r) / n
    out["treffer"] = sum(1 for x in r if x > 0) / n; out["mittel_pct"] = m
    sd = math.sqrt(sum((x - m) ** 2 for x in r) / (n - 1)) if n > 1 else None
    if sd and sd > 0 and n >= 3 and m > 0:
        out["kelly"] = min(50.0, (m / 100) / (sd / 100) ** 2)
    bw = list(bloecke_werte) if bloecke_werte is not None else (bloecke(tr, block_s) if block_s else r)
    ne = len(bw); out["n_eff"] = ne
    if ne >= 3:
        mb = sum(bw) / ne; sdb = math.sqrt(sum((x - mb) ** 2 for x in bw) / (ne - 1))
        if sdb > 0:
            out["t"] = mb / (sdb / math.sqrt(ne))
            out["p_zufall"] = p_t_einseitig(out["t"], ne - 1)            # einseitig: so gut oder besser rein zufällig (Student-t, n_eff − 1)
    gew = sum(t["netto_usd"] for t in tr if t["netto_usd"] > 0); verl = -sum(t["netto_usd"] for t in tr if t["netto_usd"] < 0)
    out["pf"] = (gew / verl) if verl > 0 else None
    cum = peak = dd = 0.0
    for t in tr:
        cum += t["netto_usd"]; peak = max(peak, cum); dd = max(dd, peak - cum)
    out["max_dd_usd"] = round(dd, 2)
    sl = [t["slip"] for t in tr if t["slip"] is not None]
    out["slip_bps"] = (sum(sl) / len(sl)) if sl else None
    if ne >= 6:
        h = ne // 2; a = bw[:h]; b = bw[h:]
        out["haelften"] = [sum(a) / len(a), sum(b) / len(b)]
    for L in HEBEL:
        e, pk, mdd, aus = 1.0, 1.0, 0.0, None
        for i, t in enumerate(tr):
            if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE:
                e = 0.0; aus = i + 1; mdd = 1.0; break
            e *= max(0.0, 1 + L * t["netto_pct"] / 100 * (t.get("notional") or notional) / notional); pk = max(pk, e)
            mdd = max(mdd, 1 - e / pk if pk > 0 else 1.0)
            if e <= 0:
                aus = i + 1; break
        # gleiche Marge, L-facher Einsatz: Rendite, Gebühren und Funding wachsen mit L; ein liquidierter Trade kostet die ganze Marge
        summe_L = sum(-(t.get("notional") or notional) if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE else L * t["netto_usd"] for t in tr) + L * summe_extra
        out["hebel"].append({"L": L, "faktor": round(e, 4), "max_dd": round(mdd, 4), "ausgeloescht": aus, "summe_usd": round(summe_L, 2),
                             "tag_pct": round(summe_L / kt / notional * 100, 4) if kt else None,
                             "liquidiert": sum(1 for t in tr if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE),
                             "schlechtester_pct": round(-100.0 if any(t["mae_pct"] / 100 * L >= LIQ_SCHWELLE for t in tr) else L * min(r), 3)})
    span = (max(t["geschlossen"] for t in tr) - min(t["eroeffnet"] for t in tr)) / 86_400
    if ne >= 30 and (out["t"] or 0) >= 3 and span >= 14 and out["haelften"] and min(out["haelften"]) > 0:
        out["stufe"] = "bewährt"
    elif ne >= 15 and (out["t"] or 0) >= 2 and out["summe_usd"] > 0:
        out["stufe"] = "Bewährung"
    elif ne >= 30 and (out["t"] or 0) <= -2:
        out["stufe"] = "negativ"
    return out


def kennzahlen(st, now: int) -> list:
    schema(st)
    strat = {r[0]: {"sid": r[0], "name": r[1], "titel": r[2], "gruppe": r[3], "regeln": json.loads(r[4] or "{}"), "beschreibung": r[5],
                    "erstellt": r[6], "aktiv": r[7]}
             for r in st.execute("SELECT sid, name, titel, gruppe, regeln, beschreibung, erstellt, aktiv FROM labor_strategie")}
    tr: dict = {}
    for r in st.execute("SELECT sid, coin, eroeffnet, geschlossen, netto_usd, netto_pct, mae_pct, gebuehr_ein + gebuehr_aus, funding, "
                        "slip_ein, slip_aus, notional FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
        tr.setdefault(r[0], []).append({"coin": r[1], "eroeffnet": r[2], "geschlossen": r[3], "netto_usd": r[4] or 0.0, "netto_pct": r[5] or 0.0,
                                        "mae_pct": r[6] or 0.0, "gebuehren": r[7] or 0.0, "funding": r[8] or 0.0,
                                        "slip": ((r[9] or 0.0) + (r[10] or 0.0)) if r[9] is not None else None, "notional": r[11] or NOTIONAL})
    offen: dict = {}; n_offen: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_position WHERE status='offen'"):
        offen.setdefault(sid, set()).add(coin); n_offen[sid] = n_offen.get(sid, 0) + 1
    orders: dict = {}; n_orders: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_order WHERE status='offen'"):
        orders.setdefault(sid, set()).add(coin); n_orders[sid] = n_orders.get(sid, 0) + 1
    starts = coin_starts(st)                         # die Coins, auf denen das Labor läuft, je mit ihrem Start
    if not starts:                                   # vor dem ersten Takt nach dem Update: 23.33-Coins ab dem Laborstart, neue ab jetzt
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        starts = {c: (int(r0[0]) if (r0 and r0[0] and c in COINS_2333) else now) for c in COINS}
    out = []
    for sid, s in strat.items():
        if not s["aktiv"] and sid not in tr:
            continue
        t_ = tr.get(sid, [])
        # Ende der Laufzeit: aktive Strategien jetzt; alte Regelversionen mit ihrem letzten Trade (oder offener Position)
        ende = now if (s["aktiv"] or sid in offen) else max([x["geschlossen"] for x in t_] or [s["erstellt"]])
        block_s = int(float(s["regeln"].get("h", 4)) * 3600)
        coins_s = sorted(set(starts) | {x["coin"] for x in t_})
        gt = grid_tage(st, sid) if s["name"] in GRID_NAMEN else None
        if gt is None:
            k = dict(s, **_stat(t_, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, coins_s), block_s=block_s))
        else:
            # 23.40 Grid: Blöcke = Tage, Wert = Tagesergebnis nach Bestandswert in % des Kapitals aller Coin-Konten; Summe inkl. Bestand
            kap = GRID_KAPITAL * max(1, len(coins_s))
            k = dict(s, **_stat(t_, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, coins_s), block_s=86_400,
                                bloecke_werte=[usd / kap * 100 for _, usd in gt["tage"]], summe_extra=sum(gt["bestand"].values())))
            cum = peak = dd = 0.0
            for _, usd in gt["tage"]:
                cum += usd; peak = max(peak, cum); dd = max(dd, peak - cum)
            k["max_dd_usd"] = round(dd, 2); block_s = 86_400
            k["grid"] = {"tage": [[tag, round(usd, 2)] for tag, usd in gt["tage"][-90:]], "lose": n_offen.get(sid, 0), "orders": n_orders.get(sid, 0)}
        k.update(offen=sorted(offen.get(sid, ())), orders=sorted(orders.get(sid, ())), block_h=block_s / 3600)
        k["je_coin"] = {}
        for c in sorted({x["coin"] for x in t_} | (set(gt["je_coin"]) if gt else set())):
            tc = [x for x in t_ if x["coin"] == c]
            if gt is None:
                sc = _stat(tc, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, [c]), block_s=block_s)
            else:
                sc = _stat(tc, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, [c]), block_s=86_400,
                           bloecke_werte=[usd / GRID_KAPITAL * 100 for _, usd in gt["je_coin"].get(c, [])], summe_extra=gt["bestand"].get(c, 0.0))
            k["je_coin"][c] = {f: sc[f] for f in ("n", "n_eff", "treffer", "mittel_pct", "t", "summe_usd", "tag_pct", "max_dd_usd", "bestand_usd")}
            k["je_coin"][c]["hebel"] = {str(h["L"]): {"summe_usd": h["summe_usd"], "tag_pct": h["tag_pct"], "liquidiert": h["liquidiert"]} for h in sc["hebel"]}
        out.append(k)
    n_aktiv = max(1, sum(1 for k in out if k["aktiv"]))
    for k in out:                                  # viele Strategien zugleich: die beste sieht auch zufällig gut aus
        k["p_glueck"] = min(1.0, k["p_zufall"] * n_aktiv) if k.get("p_zufall") is not None else None
    out.sort(key=lambda k: (-(k["summe_usd"] or 0)))
    return out


def uebersicht(store: str, preise: dict, now: int | None = None) -> dict:
    now = int(now or time.time()); st = F.store_connect(store); schema(st)
    try:
        K = kennzahlen(st, now)
        titel = {k["sid"]: k["titel"] for k in K}
        r = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone(); start = int(r[0]) if r else None
        seit = coin_starts(st)
        for c in COINS:
            seit.setdefault(c, start if (start and c in COINS_2333) else now)
        offen = []
        for p in st.execute("SELECT id, sid, coin, seite, eroeffnet, preis_ein, notional, menge, gebuehr_ein, sl, tp, ablauf, grund, funding, "
                            "mae_pct, mfe_pct, art_ein FROM labor_position WHERE status='offen' ORDER BY eroeffnet DESC"):
            mid = (preise.get(p[2]) or {}).get("mid")
            kauf = p[3] == "long"; unreal = None
            if mid:
                geb_aus = p[7] * mid * gebuehr(p[2], GEB_TAKER)
                unreal = (mid - p[5]) * p[7] * (1 if kauf else -1) - p[8] - geb_aus - (p[13] or 0.0)
            offen.append({"id": p[0], "sid": p[1], "titel": titel.get(p[1], p[1]), "coin": p[2], "seite": p[3], "eroeffnet": p[4], "preis_ein": p[5],
                          "notional": p[6], "sl": p[9], "tp": p[10], "ablauf": p[11], "grund": p[12], "funding": p[13], "mae_pct": p[14],
                          "mfe_pct": p[15], "art": p[16], "jetzt": mid, "netto_usd": unreal, "netto_pct": (unreal / p[6] * 100) if unreal is not None else None,
                          "grid": str(p[1]).startswith("grid_")})
        orders = [{"id": o[0], "sid": o[1], "titel": titel.get(o[1], o[1]), "coin": o[2], "seite": o[3], "preis": o[4], "erstellt": o[5],
                   "gueltig_bis": o[6], "grund": o[7], "jetzt": (preise.get(o[2]) or {}).get("mid"), "grid": str(o[1]).startswith("grid_")}
                  for o in st.execute("SELECT id, sid, coin, seite, preis, erstellt, gueltig_bis, grund FROM labor_order WHERE status='offen' ORDER BY erstellt DESC")]
        grids = grid_zustand(st)
        # 23.40: die einzelnen Grid-Lose (art „grid_los“, Hunderte am Tag) getrennt -- sonst verdrängten sie alle übrigen Ereignisse
        ev_q = ("SELECT id, ts, sid, coin, art, seite, preis, text, netto_usd, pos_id FROM labor_ereignis WHERE art {} 'grid_los' "
                "ORDER BY ts DESC, id DESC LIMIT {}")
        ev_f = lambda e: {"id": e[0], "ts": e[1], "sid": e[2], "titel": titel.get(e[2], "Labor") if e[2] else "Erkennung", "coin": e[3], "art": e[4],
                          "seite": e[5], "preis": e[6], "text": e[7], "netto_usd": e[8], "pos_id": e[9]}
        ereig = [ev_f(e) for e in st.execute(ev_q.format("<>", 150))]
        ereig_grid = [ev_f(e) for e in st.execute(ev_q.format("=", 100))]
        tag = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE status='geschlossen' AND geschlossen>=?",
                         (now - 86_400,)).fetchone()
        ges = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0), COALESCE(SUM(gebuehr_ein + gebuehr_aus), 0) FROM labor_position "
                         "WHERE status='geschlossen'").fetchone()
    finally:
        st.close()
    aktiv = [k for k in K if k["aktiv"]]
    mit = [k for k in aktiv if k["n"] >= 5]
    return {"ts": now, "start": start, "notional": NOTIONAL, "coins": list(COINS), "coins_seit": seit, "geb_faktor": GEB_FAKTOR,
            "strategien": K, "offen": offen, "orders": orders, "grids": grids, "ereignisse_grid": ereig_grid,
            "ereignisse": ereig, "gesamt": {"strategien": len(aktiv), "konten": len(aktiv) * len(COINS),
                                            "offen": sum(1 for o in offen if not o["grid"]), "orders": sum(1 for o in orders if not o["grid"]),
                                            "grid_lose": sum(1 for o in offen if o["grid"]), "grid_orders": sum(1 for o in orders if o["grid"]),
                                            "grid_bestand_usd": round(sum(o["netto_usd"] or 0 for o in offen if o["grid"]), 2),
                                            "trades": ges[0], "netto_usd": round(ges[1], 2), "gebuehren_usd": round(ges[2], 2),
                                            "trades_24h": tag[0], "netto_24h": round(tag[1], 2),
                                            "offen_usd": round(sum(o["netto_usd"] or 0 for o in offen), 2),
                                            "beste": max(mit, key=lambda k: k["summe_usd"])["titel"] if mit else None,
                                            "stufen": {s: sum(1 for k in aktiv if k["stufe"] == s) for s in ("Kandidat", "Bewährung", "bewährt", "negativ")}}}


def trades(store: str, sid: str | None = None, coin: str | None = None, n: int = 150) -> list:
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.coin, p.seite, p.eroeffnet, p.geschlossen, p.preis_ein, p.preis_aus, p.art_ein, p.art_aus, "
             "p.gebuehr_ein + p.gebuehr_aus, p.slip_ein, p.slip_aus, p.funding, p.grund, p.grund_aus, p.netto_usd, p.netto_pct, p.mae_pct, p.mfe_pct, p.notional "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.status='geschlossen'")
        par = []
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        if coin:
            q += " AND p.coin=?"; par.append(coin)
        q += " ORDER BY p.geschlossen DESC LIMIT ?"; par.append(int(n))
        spalten = ("id", "sid", "titel", "coin", "seite", "eroeffnet", "geschlossen", "preis_ein", "preis_aus", "art_ein", "art_aus", "gebuehren",
                   "slip_ein", "slip_aus", "funding", "grund", "grund_aus", "netto_usd", "netto_pct", "mae_pct", "mfe_pct", "notional")
        return [dict(zip(spalten, r)) for r in st.execute(q, par)]
    finally:
        st.close()


def chart(db: str, store: str, coin: str, sid: str | None = None, stunden: int = 24, now: int | None = None) -> dict:
    now = int(now or time.time()); t0 = now - stunden * 3600
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
    try:
        kurs = [(int(t), float(c)) for t, c in con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? AND ts % 300 = 240 ORDER BY ts",
                                                           (t0, now, coin)) if c]
    except sqlite3.Error:
        kurs = []
    finally:
        con.close()
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.seite, p.status, p.eroeffnet, p.preis_ein, p.geschlossen, p.preis_aus, p.netto_usd, p.sl, p.tp "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.coin=? AND (p.eroeffnet>=? OR p.status='offen' OR p.geschlossen>=?)")
        par = [coin, t0, t0]
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        else:                                       # 23.40: die vielen Grid-Lose nur, wenn das Grid oben gewählt ist
            q += " AND p.sid NOT LIKE 'grid\\_%' ESCAPE '\\'"
        marken = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "status": r[4], "ein_t": r[5], "ein_px": r[6], "aus_t": r[7], "aus_px": r[8],
                   "netto_usd": r[9], "sl": r[10], "tp": r[11]} for r in st.execute(q + " ORDER BY p.eroeffnet", par)]
        q2 = "SELECT o.id, o.sid, s.titel, o.seite, o.preis, o.erstellt, o.gueltig_bis FROM labor_order o LEFT JOIN labor_strategie s ON s.sid = o.sid WHERE o.coin=? AND o.status='offen'"
        par2 = [coin] + ([sid] if sid else [])
        limits = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "preis": r[4], "erstellt": r[5], "gueltig_bis": r[6]}
                  for r in st.execute(q2 + (" AND o.sid=?" if sid else " AND o.sid NOT LIKE 'grid\\_%' ESCAPE '\\'"), par2)]
        grid = grid_zustand(st).get(f"{sid}|{coin}") if sid and str(sid).startswith("grid_") else None
    finally:
        st.close()
    return {"coin": coin, "von": t0, "bis": now, "kurs": kurs, "marken": marken, "limits": limits, "grid": grid}


def equity(store: str, now: int | None = None) -> dict:
    now = int(now or time.time())
    st = F.store_connect(store); schema(st)
    try:
        titel = {r[0]: (r[1], r[2]) for r in st.execute("SELECT sid, titel, gruppe FROM labor_strategie")}
        reihen: dict = {}
        for sid, t, netto in st.execute("SELECT sid, geschlossen, netto_usd FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
            if str(sid).startswith("grid_"):
                continue
            r = reihen.setdefault(sid, {"sid": sid, "titel": titel.get(sid, (sid, ""))[0], "gruppe": titel.get(sid, ("", ""))[1], "punkte": [], "summe": 0.0})
            r["summe"] += netto or 0.0; r["punkte"].append([int(t), round(r["summe"], 2)])
        # 23.40 Grid: Tagespunkte nach Bestandswert (realisiert + unrealisiert) -- sonst stiege die Linie mit jedem kleinen Verkauf, während
        # der Bestand verliert
        for (sid,) in st.execute("SELECT sid FROM labor_strategie WHERE name IN (?, ?)", GRID_NAMEN).fetchall():
            gt = grid_tage(st, sid)
            if not gt["tage"]:
                continue
            r = reihen.setdefault(sid, {"sid": sid, "titel": titel.get(sid, (sid, ""))[0], "gruppe": titel.get(sid, ("", ""))[1], "punkte": [],
                                        "summe": 0.0, "grid": True})
            for tag, usd in gt["tage"]:
                r["summe"] += usd; r["punkte"].append([min(int(tag) + 86_400, now), round(r["summe"], 2)])
    finally:
        st.close()
    return {"ts": now, "reihen": sorted(reihen.values(), key=lambda r: -r["summe"])}


def _fmt_usd(x) -> str:
    if x is None:
        return "—"
    a = abs(x)
    return (f"{x / 1e6:+.2f} Mio" if a >= 1e6 else f"{x / 1e3:+.1f}k" if a >= 1e4 else f"{x:+.0f}")


def datenfluss(E: dict, strat: list, now: int) -> list:
    """Alle Eingangsdaten eines Coins als Zeilen für den Abschnitt „Datenfluss“ (Wert, Alter, Status, genutzt von)."""
    if not E:
        return []
    nutzer: dict = {}
    for s in strat:
        for k in s["eingaben"]:
            nutzer.setdefault(k, []).append(s["titel"])
    zeilen = []

    def z(gruppe, name, wert, ts, key=None, frisch=None, hinweis=None):
        alter = (now - ts) if ts else None
        status = "fehlt" if wert in (None, "—") else ("alt" if (frisch and alter is not None and alter > frisch) else "frisch")
        zeilen.append({"gruppe": gruppe, "name": name, "wert": wert if wert is not None else "—", "alter": alter, "status": status,
                       "nutzer": nutzer.get(key, []) if key else [], "hinweis": hinweis})
    b = E.get("preis") or {}
    z("Kurs & Buch", "Kurs (Mitte)", f"{b['mid']:.6g}" if b else None, b.get("ts"), None, FRISCH_S["preis"], b.get("quelle"))
    z("Kurs & Buch", "Spread", f"{b['spread_bps']:.2f} bps" if b else None, b.get("ts"), None, FRISCH_S["preis"])
    z("Kurs & Buch", "Tiefe ±10 bps", _fmt_usd(b.get("tiefe10")).lstrip("+") if b.get("tiefe10") else None, b.get("ts"), None, FRISCH_S["preis"],
      "bestimmt die Marktauswirkung jeder simulierten Markt-Order")
    z("Schwankung", "σ 4 h", f"{E['sigma4h'] * 100:.2f} %" + ("" if E.get("sigma_ok") else " (Ersatzwert)"), now, None, None,
      "aus 15-min-Renditen der letzten 7 Tage; Grundlage aller Stops und Ziele")
    z("Schwankung", "σ 1 h / 15 min", f"{E['sigma1h'] * 100:.2f} % / {E['sigma15'] * 100:.2f} %", now)
    z("Schwankung", "Stundenvolumen (Median 24 h)", _fmt_usd(E.get("vol1h")).lstrip("+") if E.get("vol1h") else None, now)
    P = E.get("prognose")
    if P:
        z("Prognose", "Bias", f"{P['bias']:+.2f}" if P.get("bias") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v1", f"{P['p_up_v1'] * 100:.1f} %" if P.get("p_up_v1") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v2", f"{float(P['p_up_v2']) * 100:.1f} % (Version {P.get('v2_version') or 1})" if P.get("p_up_v2") is not None else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "Kauf- / Verkaufspreis", f"{P['buy_px']:.6g} / {P['sell_px']:.6g}" if P.get("buy_px") and P.get("sell_px") else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
    else:
        z("Prognose", "Prognose", None, None, "prognose")
    for n_, (v, t) in sorted((E.get("treiber") or {}).items()):
        z("Treiber", n_, f"{v:+.2f}", t, f"treiber:{n_}", FRISCH_S["treiber"])
    for f, v in (E.get("familien") or {}).items():
        z("Familien", f, (f"{v[0]:+.2f} ({v[2]} Treiber)" if f != "Profi-Flow" else f"{v[0]:+.2f}") if v else None, v[1] if v else None,
          f"familie:{f}", FRISCH_S["familie"])
    S_ = E.get("staerke") or {}
    z("Familien", "Stärke (große Bewegung?)", f"{S_['wert']:.2f}" + (f", Ruhe {S_['ruhe']:.2f}" if S_.get("ruhe") is not None else "")
      if S_.get("wert") is not None else None, now, "staerke")
    K = E.get("kaskade") or {}
    liq = K.get("liq") or {}
    z("Ereignisse", "Kursbewegung 15 min", f"{K['z']:+.2f} σ" if K.get("z") is not None else None, now, "kaskade", None,
      f"Kaskade ab ±{KASKADE_Z:g} σ zusammen mit Liquidationen über der Schwelle")
    z("Ereignisse", "Liquidationen 15 min (Long / Short)", f"{_fmt_usd(liq.get('long')).lstrip('+')} / {_fmt_usd(liq.get('short')).lstrip('+')}" if liq else None,
      now, "kaskade", None, (f"Schwellen {_fmt_usd((K.get('schwelle') or {}).get('long')).lstrip('+')} / {_fmt_usd((K.get('schwelle') or {}).get('short')).lstrip('+')} · "
                            f"Hyperliquid {_fmt_usd(liq.get('hl')).lstrip('+')}, Binance {_fmt_usd(liq.get('binance')).lstrip('+')}, andere {_fmt_usd(liq.get('andere')).lstrip('+')}")
      if liq else None)
    z("Ereignisse", "Kaskaden-Status", ("AKTIV: " + ("abwärts" if K.get("richtung") == "ab" else "aufwärts") + f" seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}")
      if K.get("aktiv") else "ruhig", now, "kaskade")
    A = E.get("anker") or {}
    if A.get("fehler"):
        z("Heatmap", "Anker", None, None, "anker", None, A["fehler"])
    else:
        dom = (A.get("oben") if (A.get("A") or 0) > 0 else A.get("unten")) if A.get("A") is not None else None
        z("Heatmap", "Anker A", (f"{A['A']:+.2f}" + (f" · Cluster {dom['px']:.6g}, {dom['abstand_sigma']:.1f} σ, {dom['anteil_volumen'] * 100:.0f} % Vol." if dom else ""))
          if A.get("A") is not None else "kein Anker", A.get("ts"), "anker", FRISCH_S["anker"],
          "Beleg: " + ("ja" if (A.get("bilanz") or {}).get("belegt") else "nein"))
    D = E.get("docht") or {}
    for key, name in (("unten", "Docht-Ziel unten (Long-Cluster)"), ("oben", "Docht-Ziel oben (Short-Cluster)")):
        c = D.get(key)
        z("Heatmap", name, f"{c['px']:.6g} · {_fmt_usd(c['usd']).lstrip('+')} · {c['anteil'] * 100:.0f} % Vol. · {c['sigma']:.1f} σ" if c else "keins",
          D.get("ts"), "docht", FRISCH_S["docht"])
    f = E.get("funding")
    z("Funding", "Funding-Rate", (f"{f['rate'] * 100:.4f} %/h" + (f", z {f['z']:+.1f}" if f.get("z") is not None else ", Statistik im Aufbau")) if f else None,
      f["ts"] if f else None, "funding", FRISCH_S["funding"])
    Dw = E.get("darwin") or {}
    z("Händler", "Darwin-Liste (Konten)", f"{len(Dw.get('konten') or [])}" if Dw.get("konten") is not None else None, now, "darwin")
    log = Dw.get("log") or []
    z("Händler", "Darwin: letzte Ein-/Ausstiege (6 h)", ", ".join(f"{_uhr(e['ts'])[7:]} #{e.get('rang')} {'eröffnet' if e['art'] == 'auf' else 'schließt'} {e['seite']} "
                                                                f"{_fmt_usd(e['usd']).lstrip('+')}" for e in reversed(log)) if log else "keine",
      log[-1]["ts"] if log else now, "darwin")
    su = Dw.get("summen") or {}
    z("Händler", f"Darwin: Eröffnungen der letzten {DARWIN_FENSTER_S // 60} min", ", ".join(
        f"{k.split('|')[0][:6]}…{k.split('|')[0][-4:]} {k.split('|')[2]} {_fmt_usd(v).lstrip('+')}" for k, v in sorted(su.items(), key=lambda kv: -kv[1])[:4])
      if su else "keine", now, "darwin", None, f"Summe je Konto und Seite seit dem letzten Schließen, auch in kleinen Stücken; Einstieg ab "
                                               f"{DARWIN_MIN_USD / 1e3:.0f}k (23.34)")
    El = E.get("elite") or {}                                                      # 23.39: die Elite des Coins als zweite Vorlage
    z("Händler", "Elite des Coins (Konten)", f"{len(El.get('konten') or [])}" if El.get("konten") is not None else None, now, "elite", None,
      "vom Dashboard täglich aufgestellt (Konto-Score mit Beleg, Gewinn- und Aktivitätsschranke), ohne Gesperrte")
    log_e = El.get("log") or []
    z("Händler", "Elite: letzte Ein-/Ausstiege (6 h)", ", ".join(f"{_uhr(e['ts'])[7:]} #{e.get('rang')} {'eröffnet' if e['art'] == 'auf' else 'schließt'} {e['seite']} "
                                                                f"{_fmt_usd(e['usd']).lstrip('+')}" for e in reversed(log_e)) if log_e else "keine",
      log_e[-1]["ts"] if log_e else now, "elite")
    su_e = El.get("summen") or {}
    z("Händler", f"Elite: Eröffnungen der letzten {DARWIN_FENSTER_S // 60} min", ", ".join(
        f"{k.split('|')[0][:6]}…{k.split('|')[0][-4:]} {k.split('|')[2]} {_fmt_usd(v).lstrip('+')}" for k, v in sorted(su_e.items(), key=lambda kv: -kv[1])[:4])
      if su_e else "keine", now, "elite", None, f"Summe je Konto und Seite seit dem letzten Schließen (Fills ab 2.500 USD); Einstieg ab "
                                                f"{DARWIN_MIN_USD / 1e3:.0f}k (23.39)")
    AF = E.get("adressstrom")
    if AF is None:
        z("Adress-Strom", "Aufzeichnung", None, None, "adressstrom", None, "adressfluss.db noch nicht angelegt (Recorder ab 23.33)")
    else:
        z("Adress-Strom", "Trades / Adressen 60 min", f"{AF['trades_h']:,} / {AF['adressen_h']:,}".replace(",", "."), AF.get("ts"), "adressstrom",
          FRISCH_S["adressstrom"], f"Aufzeichnung seit {_uhr(AF.get('seit'))}")
        z("Adress-Strom", "TWAP-Anteil (Null-Hash)", f"{AF['nullhash_anteil'] * 100:.2f} % der Trades" if AF.get("nullhash_anteil") is not None else None,
          AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        z("Adress-Strom", "TWAP-Netto 60 min", (f"{_fmt_usd(AF['tw_netto_h'])} USD" + (f" = {AF['tw_anteil'] * 100:+.2f} % Vol." if AF.get("tw_anteil") is not None else ""))
          if AF.get("ts") else None, AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        top = AF.get("top") or []
        z("Adress-Strom", "Größte Netto-Nehmer 60 min", ", ".join(f"{t['addr'][:6]}…{t['addr'][-4:]} {_fmt_usd(t['netto'])}" + (" (TWAP)" if abs(t.get("twap") or 0) >= 0.5 * abs(t["netto"] or 1) else "")
                                                              for t in top) if top else None, AF.get("ts"), None, FRISCH_S["adressstrom"],
          "Nehmer-Käufe minus -Verkäufe je Adresse; Grundlage für den informierten Fluss (geplant, sobald einige Tage Daten da sind)")
    Rg = next((s["regeln"] for s in strat if s.get("fn") == "grid"), None)       # 23.40: Eingänge der Grids
    if Rg and "grid" in E:
        G = E.get("grid")
        stf = grid_stufen(G["unten"], G["oben"], Rg["schritt_min"], Rg["stufen_min"], Rg["stufen_max"]) if G else None
        z("Grid", "Range 24 h (10.–90. Perzentil)", f"{G['unten']:.6g} – {G['oben']:.6g} ({(G['oben'] / G['unten'] - 1) * 100:.2f} %)" if G else None,
          now, "grid", None, "nach einem Ausstieg rechnen die Grids nur mit Kursen ab dann")
        if G and G.get("trend") is not None:
            ok_l = grid_trend_ok(G["trend"], dict(Rg, richtung="long")); ok_s = grid_trend_ok(G["trend"], dict(Rg, richtung="short"))
            tr_txt = (f"{G['trend']:+.2f} — Long {'darf' if ok_l else 'wartet'}, Short {'darf' if ok_s else 'wartet'} "
                      f"(gegen das Grid höchstens {Rg['trend_gegen']:g}, mit ihm {Rg['trend_mit']:g})").replace(".", ",")
        else:
            tr_txt = None
        z("Grid", "Trend (Netto-Bewegung / Schwankung)", tr_txt, now, "grid", None,
          "für einen reinen Zufallsweg standardnormal: |Trend| ≤ 1 in 68 %, ≤ 2 in 95 % der Fälle")
        z("Grid", f"Stufen (Abstand ≥ {Rg['schritt_min'] * 100:.1f} %)", (f"{len(stf[0]) - 1} Stufen à {stf[1] * 100:.2f} %" if stf
                                                                          else ("Range zu eng" if G else None)), now, "grid")
    return zeilen


def live(L, now: int | None = None) -> dict:
    """Signaltafel für das Dashboard: je Strategie und Coin, was sie im letzten Takt sah; dazu je Coin die Frische der Eingänge."""
    now = int(now or time.time())
    status: dict = {}
    for (sid, coin), v in list(L.status.items()):
        status.setdefault(sid, {})[coin] = v
    frische = {}
    for coin, v in list(L.letzte.items()):
        z = datenfluss(v.get("E"), L.strategien, now)
        frische[coin] = {"frisch": sum(1 for r in z if r["status"] == "frisch"), "alt": sum(1 for r in z if r["status"] == "alt"),
                         "fehlt": sum(1 for r in z if r["status"] == "fehlt"), "ts": v.get("ts"),
                         "preis": ((v.get("E") or {}).get("preis") or {}).get("mid"), "quelle": ((v.get("E") or {}).get("preis") or {}).get("quelle")}
    return {"status": status, "frische": frische, "coins": list(L.coins), "zyklen": L.zyklen, "dauer_s": round(L.dauer, 3), "letzter": L.t_letzt,
            "fehler": list(L.fehler[-8:])}


_DIRS_AUF = ("Open Long", "Open Short", "Short > Long", "Long > Short")
_DIRS_ZU = ("Close Long", "Close Short")


def darwin_episoden(rows: list, fenster: int = DARWIN_FENSTER_S, schwelle: float = DARWIN_MIN_USD, aus_anteil: float = DARWIN_AUS_ANTEIL) -> list:
    """
    Nachrechnung der Live-Regel über eine ganze Fill-Reihe [(ts, addr, coin, dir, px, usd, tid)], zeitlich sortiert: Eröffnungen je
    Konto, Coin und Seite netto über `fenster` (Schließungen ziehen ab, nicht unter null); ab `schwelle` eine Episode, je Eröffnung
    einmal; sie endet, wenn das Konto `aus_anteil` davon wieder geschlossen hat (Feld „aus“), spätestens nach 12 h.
    """
    hist: dict = {}; ep: dict = {}; out = []
    for ts, a, coin, d, px, usd, tid in rows:
        d = str(d or "").rstrip("*"); ts = int(ts); usd = float(usd or 0.0)
        if d not in _DIRS_AUF and d not in _DIRS_ZU:
            continue
        flip = d in ("Short > Long", "Long > Short")
        seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
        teile = ([("zu", _gegen(seite))] if flip else []) + [("zu" if d in _DIRS_ZU else "auf", seite)]
        h = hist.setdefault((a, coin), [])
        h[:] = [x for x in h if x[0] >= ts - fenster] + [(ts, teile, usd)]
        for k in [k for k, e in ep.items() if ts - e["t"] > DARWIN_EPISODE_S]:
            ep.pop(k)
        for art, s_ in teile:
            k = (a, coin, s_)
            if art == "zu" and k in ep:
                ep[k]["zu"] += usd
                if ep[k]["zu"] >= aus_anteil * max(ep[k]["usd"], 1.0):
                    out[ep.pop(k)["i"]]["aus"] = ts
        for art, s_ in teile:
            k = (a, coin, s_)
            if art != "auf" or k in ep:
                continue
            net, n, t0 = 0.0, 0, None
            for ts2, teile2, usd2 in h:
                for art2, s2 in teile2:
                    if s2 != s_:
                        continue
                    if art2 == "auf":
                        net += usd2; n += 1; t0 = t0 if t0 is not None else ts2
                    else:
                        net = max(0.0, net - usd2)
                        if net <= 0:
                            n, t0 = 0, None
            if net >= schwelle:
                ep[k] = {"t": ts, "usd": net, "zu": 0.0, "i": len(out)}
                out.append({"ts": ts, "addr": a, "coin": coin, "seite": s_, "usd": net, "n": n, "seit": t0, "aus": None})
    return out


def darwin_pruefung(db: str, store: str, now: int | None = None, min_usd_fill: float = 2_500.0) -> list:
    """
    23.34: Sieht das Labor die Trades der Darwin-Liste? Liste, Fills der letzten 24 h in den Labor-Coins (Eröffnungen, Schließungen,
    ohne Richtung, davon unter 2.500 USD = erst seit 23.34 gesammelt), Eröffnungen ≥ 10k binnen 15 min (Live-Regel nachgerechnet)
    und die Einstiege von „Darwin-Liste live folgen“.
    """
    now = int(now or time.time())
    try:
        st = F.store_connect(store); schema(st)
        try:
            r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
            d = json.loads(r[0]) if r and r[0] else {}
            pos = st.execute("SELECT COUNT(*), COALESCE(SUM(p.status='offen'), 0) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                             "WHERE s.name='darwin_folgen' AND p.eroeffnet>=?", (now - 86_400,)).fetchone()
        finally:
            st.close()
    except (sqlite3.Error, ValueError) as e:
        return [f"Darwin-Prüfung: Prognosespeicher nicht lesbar ({type(e).__name__}: {e})"]
    konten = list(dict.fromkeys(str(a).lower() for a in list(d.get("reihe") or []) + list(d.get("liste") or [])))
    if not konten:
        return ["Darwin-Prüfung: Liste leer -- noch kein Konto qualifiziert (check_profis.py --alle zeigt die Gründe)"]
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute(f"SELECT ts, lower(addr), coin, dir, px, notional, tid FROM lb_fills WHERE ts>=? AND coin IN ({','.join('?' * len(COINS))}) "
                               f"AND lower(addr) IN ({','.join('?' * len(konten))}) ORDER BY ts, tid", (now - 86_400, *COINS, *konten)).fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [f"Darwin-Prüfung: Datenbank nicht lesbar ({type(e).__name__}: {e})"]
    n_auf = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_AUF)
    n_zu = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_ZU)
    klein = sum(1 for r in rows if (r[5] or 0) < min_usd_fill)
    ep = darwin_episoden(rows); rang = {a: i + 1 for i, a in enumerate(konten)}
    z = [f"Darwin-Prüfung (24 h): Liste {len(konten)} Konten · Fills in den Labor-Coins {len(rows)} (Eröffnungen {n_auf}, Schließungen {n_zu}, "
         f"ohne Richtung {len(rows) - n_auf - n_zu}; unter 2.500 USD {klein}) · Eröffnungen ≥ {DARWIN_MIN_USD / 1e3:.0f}k binnen "
         f"{DARWIN_FENSTER_S // 60} min: {len(ep)} · „Darwin-Liste live folgen“ eingestiegen: {pos[0] or 0} (offen {pos[1] or 0})"]
    if ep:
        z.append("  letzte Eröffnungen: " + " · ".join(f"{_uhr(e['ts'])} #{rang.get(e['addr'], '?')} {e['addr'][:6]}…{e['addr'][-4:]} {e['coin']} {e['seite']} "
                                                       f"{e['usd'] / 1e3:.0f}k ({e['n']} Fills" + (f", zur Hälfte geschlossen {_uhr(e['aus'])[7:]}" if e.get("aus") else "")
                                                       + ")" for e in ep[-5:][::-1]))
    if len(rows) - n_auf - n_zu > 0:
        z.append("  ohne Richtung = Stream-Fills von Konten, deren Position der Recorder noch nicht kannte -- für das Labor unsichtbar")
    return z


def elite_pruefung(db: str, store: str, now: int | None = None) -> list:
    """
    23.39: Sieht das Labor die Trades der Elite? Elite je Labor-Coin (learned coin/„elite“, ohne Gesperrte), ihre Fills der letzten 24 h im
    jeweiligen Coin (Eröffnungen, Schließungen, ohne Richtung), Eröffnungen ≥ 10k binnen 15 min (Live-Regel nachgerechnet) und die
    Einstiege von „Elite live folgen“ -- wie die Darwin-Prüfung, damit beide Vorlagen vergleichbar sind.
    """
    now = int(now or time.time())
    try:
        st = F.store_connect(store); schema(st)
        try:
            je: dict = {}
            for c in COINS:
                r = st.execute("SELECT value FROM learned WHERE coin=? AND key='elite'", (c,)).fetchone()
                try:
                    v = json.loads(r[0]) if r and r[0] else []
                except ValueError:
                    v = []
                je[c] = [str(a).lower() for a in (v if isinstance(v, list) else []) if isinstance(a, str)][:20]
            pos = st.execute("SELECT COUNT(*), COALESCE(SUM(p.status='offen'), 0) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                             "WHERE s.name='elite_folgen' AND p.eroeffnet>=?", (now - 86_400,)).fetchone()
        finally:
            st.close()
    except sqlite3.Error as e:
        return [f"Elite-Prüfung: Prognosespeicher nicht lesbar ({type(e).__name__}: {e})"]
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            try:
                gesperrt = {r_[0].lower() for r_ in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
            except sqlite3.Error:
                gesperrt = set()
            je = {c: [a for a in k if a not in gesperrt] for c, k in je.items()}
            rows = []
            for c, konten in je.items():
                if konten:
                    rows += con.execute(f"SELECT ts, lower(addr), coin, dir, px, notional, tid FROM lb_fills WHERE ts>=? AND coin=? "
                                        f"AND lower(addr) IN ({','.join('?' * len(konten))})", (now - 86_400, c, *konten)).fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [f"Elite-Prüfung: Datenbank nicht lesbar ({type(e).__name__}: {e})"]
    alle = {a for k in je.values() for a in k}
    if not alle:
        return ["Elite-Prüfung: keine Elite gespeichert -- das Dashboard stellt sie täglich je Coin auf (Debug „Elite-Positionierung prüfen“)"]
    rows.sort(key=lambda r: (r[0], r[6]))
    n_auf = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_AUF)
    n_zu = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_ZU)
    ep = darwin_episoden(rows)
    rang = {(c, a): i + 1 for c, k in je.items() for i, a in enumerate(k)}
    z = [f"Elite-Prüfung (24 h): Elite je Coin " + " · ".join(f"{c} {len(k)}" for c, k in je.items()) + f" ({len(alle)} Konten) · Fills im "
         f"eigenen Coin {len(rows)} (Eröffnungen {n_auf}, Schließungen {n_zu}, ohne Richtung {len(rows) - n_auf - n_zu}; erst ab 2.500 USD) · "
         f"Eröffnungen ≥ {DARWIN_MIN_USD / 1e3:.0f}k binnen {DARWIN_FENSTER_S // 60} min: {len(ep)} · „Elite live folgen“ eingestiegen: "
         f"{pos[0] or 0} (offen {pos[1] or 0})"]
    if ep:
        z.append("  letzte Eröffnungen: " + " · ".join(f"{_uhr(e['ts'])} #{rang.get((e['coin'], e['addr']), '?')} {e['addr'][:6]}…{e['addr'][-4:]} "
                                                       f"{e['coin']} {e['seite']} {e['usd'] / 1e3:.0f}k ({e['n']} Fills"
                                                       + (f", zur Hälfte geschlossen {_uhr(e['aus'])[7:]}" if e.get("aus") else "") + ")"
                                                       for e in ep[-5:][::-1]))
    return z


def gebuehren_pruefung(db: str, now: int | None = None, tage: int = 3) -> str | None:
    """23.34: Gebührensatz echter Fills (REST/userEvents: Richtung ohne Sternchen, Gebühr > 0) je Coin -- Prüfung der XMR-Annahme."""
    now = int(now or time.time())
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute("SELECT coin, fee / notional FROM lb_fills WHERE ts>=? AND coin IN ('BTC','ETH','XMR') AND fee > 0 AND notional > 0 "
                               "AND dir NOT LIKE '%*' AND dir <> 'stream' LIMIT 300000", (now - tage * 86_400,)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    je: dict = {}
    for c, q in rows:
        if q is not None and 0 < q < 0.01:
            je.setdefault(c, []).append(q)
    med = lambda v: sorted(v)[len(v) // 2]
    if len(je.get("XMR", [])) < 30 or len(je.get("BTC", []) + je.get("ETH", [])) < 30:
        return (f"Gebühren-Prüfung: zu wenige echte Fills mit Gebühr ({len(je.get('XMR', []))} XMR) -- Labor rechnet XMR mit "
                f"×{GEB_FAKTOR.get('XMR', 1.0):.1f}".replace(".", ","))
    std = med(je.get("BTC", []) + je.get("ETH", [])); x = med(je["XMR"])
    return (f"Gebühren-Prüfung ({tage} T, Median Gebühr/Umsatz echter Fills): BTC/ETH {std * 100:.4f} %, XMR {x * 100:.4f} % "
            f"-> XMR ≈ ×{x / std:.1f} der Standard-Perps (Labor rechnet ×{GEB_FAKTOR.get('XMR', 1.0):.1f}; Konten- und Taker/Maker-Mischung "
            f"verzerrt)").replace(".", ",")


def bericht_text(store: str, now: int | None = None, db: str | None = None) -> str:
    """Textbericht (Debug-Eintrag „labor“, Wochenplan): Stand, Kennzahlen je Strategie, beste je Coin, ALLE offenen Positionen,
    letzte Trades; mit db (23.34) auch die Darwin- und die Gebühren-Prüfung."""
    now = int(now or time.time()); d = uebersicht(store, {}, now); g = d["gesamt"]
    pc = lambda x, n=3: "—" if x is None else f"{x:+.{n}f} %"
    tt = lambda x: "—" if x is None else f"{x:+.1f}"
    qq = lambda x: "—" if x is None else f"{x * 100:.0f} %"
    usd = f"{NOTIONAL:,.0f}".replace(",", ".")
    seit = d.get("coins_seit") or {}
    gruppen: dict = {}
    for c in COINS:
        gruppen.setdefault(seit.get(c), []).append(c)
    coins_txt = "; ".join(f"{', '.join(cs)} seit {_uhr(t)}" for t, cs in sorted(gruppen.items(), key=lambda kv: kv[0] or 0))
    z = [f"TradeLabor · simulierter Handel, kein echtes Geld · {usd} USD je Trade · Start {_uhr(d['start'])} · "
         f"{g['strategien']} Strategien × {len(COINS)} Coins ({coins_txt})",
         f"Geschlossene Trades {g['trades']} (24 h: {g['trades_24h']}, netto {g['netto_24h']:+.2f} USD) · gesamt netto {g['netto_usd']:+.2f} USD, "
         f"Gebühren {g['gebuehren_usd']:.2f} · offen {g['offen']} · Limit-Orders {g['orders']} · Grid {g.get('grid_lose', 0)} Lose (Bestand "
         f"{sum(k.get('bestand_usd') or 0.0 for k in d['strategien'] if k.get('name') in GRID_NAMEN and k.get('aktiv')):+.2f} USD, letzter Tagesstand), "
         f"{g.get('grid_orders', 0)} Orders",
         "Stufen: " + ", ".join(f"{k} {v}" for k, v in g["stufen"].items()),
         "Achtung: Bei vielen Strategien sehen einige zufällig gut aus. „Glück“ = Wahrscheinlichkeit, dass die beste von allen "
         "rein zufällig so gut aussähe. t, Glück und Stufen zählen BLÖCKE (Bl.): gleichzeitig eröffnete Trades einer Strategie "
         "(dasselbe Signal in mehreren Coins) sind eine Beobachtung. „bewährt“ erst mit ≥ 30 Blöcken, t ≥ 3, beide Hälften positiv, ≥ 14 Tage.", ""]
    z.append(f"{'Strategie':<34}{'Stufe':<11}{'n (Bl.)':>10}{'Treffer':>9}{'Ø netto':>10}{'t':>6}{'Glück':>7}{'Summe USD':>11}{'Ø/Tag':>9}"
             f"{'max DD':>8}  5× Hebel")
    for k in d["strategien"]:
        if not k["aktiv"] and not k["n"]:
            continue
        h5 = next((h for h in k["hebel"] if h["L"] == 5), None)
        h5t = "—" if not h5 else (f"{h5['liquidiert']}× liquidiert" if h5["liquidiert"] else f"Ø/Tag {pc(h5['tag_pct'], 2)}")
        nb = f"{k['n']} ({k.get('n_eff', 0)})"
        z.append(f"{k['titel'][:33]:<34}{k['stufe']:<11}{nb:>10}{qq(k['treffer']):>9}{pc(k['mittel_pct']):>10}{tt(k['t']):>6}"
                 f"{qq(k.get('p_glueck')):>7}{k['summe_usd']:>+11.2f}{pc(k.get('tag_pct'), 3):>9}{k['max_dd_usd']:>8.0f}  {h5t}"
                 + ("" if k["aktiv"] else "  (alte Regelversion)"))
    z.append("")
    z.append("Je Coin (Strategien mit mindestens 5 Trades, beste drei nach Summe):")
    for c in COINS:
        r = sorted(((k["titel"], k["je_coin"][c]) for k in d["strategien"] if c in k["je_coin"] and k["je_coin"][c]["n"] >= 5),
                   key=lambda x: -x[1]["summe_usd"])[:3]
        z.append(f"  {c:<5}" + (" · ".join(f"{t} {v['summe_usd']:+.0f} USD (n {v['n']}, t {tt(v['t'])})" for t, v in r) if r else "noch keine"))
    z += grid_bericht(d)
    if db:
        z.append("")
        try:
            z += darwin_pruefung(db, store, now)
        except Exception as e:
            z.append(f"Darwin-Prüfung: {type(e).__name__}: {e}")
        try:
            z += elite_pruefung(db, store, now)
        except Exception as e:
            z.append(f"Elite-Prüfung: {type(e).__name__}: {e}")
        try:
            gp = gebuehren_pruefung(db, now)
            if gp:
                z.append(gp)
        except Exception as e:
            z.append(f"Gebühren-Prüfung: {type(e).__name__}: {e}")
    z.append("")
    o_ = [o for o in d["offen"] if not o.get("grid")]
    z.append(f"Offene Positionen ({len(o_)}; Grid-Lose stehen oben je Grid und Coin):")
    for o in o_:
        z.append(f"  {o['titel'][:30]:<31}{o['coin']:<5}{o['seite']:<6} seit {_uhr(o['eroeffnet'])} zu {o['preis_ein']:.6g}"
                 + (f" · Stop {o['sl']:.6g}" if o["sl"] else "") + (f" · Ziel {o['tp']:.6g}" if o["tp"] else "")
                 + (f" · bis {_uhr(o['ablauf'])}" if o.get("ablauf") else "") + f" · {(o['grund'] or '')[:90]}")
    z.append("")
    z.append("Letzte Ein- und Ausstiege (Grid: Aufbau, Nachführen, Halten, Notausstieg -- die einzelnen Lose nicht):")
    for e in [e for e in d["ereignisse"] if e["art"] in ("eroeffnet", "geschlossen", "kaskade", "grid")][:30]:
        z.append(f"  {_uhr(e['ts'])} {e['titel'][:26]:<27}{(e['coin'] or ''):<5}{e['art']:<12}{e['text'][:150]}")
    return "\n".join(z)


def grid_bericht(d: dict) -> list:
    """23.40: Abschnitt „Grid-Bots“ des Textberichts -- je Grid und Coin Modus, Range, Lose, Bestandswert und Zähler; je Grid die Tage."""
    K = [k for k in d.get("strategien") or [] if k.get("name") in GRID_NAMEN and k.get("aktiv")]
    if not K:
        return []
    pc = lambda x, n=3: "—" if x is None else f"{x:+.{n}f} %"
    G = d.get("grids") or {}
    lose: dict = {}
    for o in d.get("offen") or []:
        if o.get("grid"):
            e = lose.setdefault(f"{o['sid']}|{o['coin']}", [0, 0.0, 0.0]); e[0] += 1; e[1] += o["notional"] or 0.0; e[2] += o["netto_usd"] or 0.0
    z = ["", "Grid-Bots (je Coin ein Konto über "
         f"{GRID_KAPITAL:,.0f} USD auf die Stufen verteilt; Tagesergebnis nach Bestandswert = realisiert + Änderung des unrealisierten Bestands):".replace(",", ".")]
    for k in K:
        t_txt = "—" if k.get("t") is None else f"{k['t']:+.1f}"
        z.append(f"  {k['titel']}: Summe {k['summe_usd']:+.2f} USD (realisiert {k.get('realisiert_usd', 0):+.2f}, Bestand {k.get('bestand_usd', 0):+.2f}) · "
                 f"{k['n']} Lose geschlossen · {k.get('n_eff', 0)} Tage · Ø/Tag {pc(k.get('tag_pct'))} · t {t_txt} · "
                 f"max DD {k['max_dd_usd']:.0f} USD (Tage) · Stufe {k['stufe']}")
        for c in COINS:
            g = G.get(f"{k['sid']}|{c}")
            if not g:
                z.append(f"    {c:<5} noch kein Takt")
                continue
            ln = lose.get(f"{k['sid']}|{c}", [0, 0.0, 0.0]); zl = g.get("zaehler") or {}
            ln[2] = ((k.get("je_coin") or {}).get(c) or {}).get("bestand_usd") or 0.0          # letzter Tagesstand (der Bericht hat keine Kurse)
            m = g.get("modus")
            if m == "aktiv":
                lage = (f"aktiv seit {_uhr(g.get('seit'))} · {ln[0]}/{g.get('n')} Lose ({ln[1]:,.0f} USD) · Range {g['unten']:.6g}–{g['oben']:.6g} · "
                        f"Schritt {g['schritt'] * 100:.2f} % · Notlinie {g['notlinie']:.6g}").replace(",", ".")
            elif m == "halten":
                H = g.get("halten") or {}
                lage = f"HÄLT {ln[0]} Lose seit {_uhr(H.get('start'))} · Extrem {H.get('extrem', 0):.6g} · Trailing-Stop {H.get('stop', 0):.6g} · {H.get('grund', '')}"
            elif m == "pause":
                lage = f"Pause bis {_uhr(g.get('pause_bis'))}"
            else:
                lage = "wartet: " + (g.get("hinweis") or "prüft die Range")
            z.append(f"    {c:<5}{lage} · Bestand {ln[2]:+.2f} USD · Runden {zl.get('runden', 0)}, aufgebaut {zl.get('aufgebaut', 0)}, "
                     f"nachgeführt {zl.get('nachgeführt', 0)}, gehalten {zl.get('halten', 0)}, Notausstiege {zl.get('notaus', 0)}")
    return z


# ------------------------------------------------------------------------------------------------ Selbsttest
def _probe_datenbank(pfad: str, t_start: int, tage: int, seed: int = 7) -> dict:
    """Synthetischer Markt für den Selbsttest: 1-min-Kerzen, Buch je Minute, Funding, eine Kaskade mit Liquidationen,
    Heatmap-Cluster, ein Darwin-Konto mit Ein- und Ausstieg. Liefert die Kursreihe (ts -> close)."""
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    n = tage * 1440; lp = math.log(100.0); kurs = {}
    crash = t_start + 3 * 86_400 + 5 * 3600                     # Tag 4, 05:00: Kaskade
    rows = []; book = []; ctx = []
    for i in range(n):
        t = t_start + i * 60
        schritt = rng.gauss(0, 0.0006)
        if crash <= t < crash + 600:
            schritt -= 0.003                                       # 3 % in 10 min
        elif crash + 900 <= t < crash + 1800:
            schritt += 0.0012                                      # Teil-Rücklauf
        o = math.exp(lp); lp += schritt; c = math.exp(lp)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.0002))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.0002)))
        rows.append((t, "AAA", o, hi, lo, c, 1000.0, 10)); kurs[t] = c
        book.append((t + 59, "AAA", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
        ctx.append((t, "AAA", c, c, c, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    liq = [(t_start + k * 3600, "AAA", "AAAUSDT", "long" if k % 2 else "short", 100.0, 1.0, 10_000.0) for k in range(tage * 24)]
    liq += [(crash + k * 60, "AAA", "AAAUSDT", "long", 100.0, 1.0, 500_000.0) for k in range(10)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", liq)
    hm = []
    for t in range(t_start + 86_400, t_start + n * 60, 600):     # ein großes Long-Cluster 1,2 σ(4 h) unter dem Kurs
        c = kurs[t // 60 * 60]
        hm.append((t, "AAA", c * (1 - 0.011), "long", 1_500_000.0, 5))            # 25 % des Stundenvolumens (6 Mio)
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm)
    t_d = t_start + 2 * 86_400 + 10 * 3600 + 17                 # Darwin-Konto: Long auf, 2 h später zu
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_d, "0xd1", "AAA", "perp", "Open Long", "B", kurs[t_d // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 1, 1),
                     (t_d + 7200, "0xd1", "AAA", "perp", "Close Long", "A", kurs[(t_d + 7200) // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 2, 0)])
    # 23.34 (Darwin v2): zweites Konto eröffnet Short in vier Stücken über drei Minuten (3k, 3k, 0,8k, 3,5k -- keines erreicht 10k,
    # zusammen 10,3k), verkleinert nach 1 h um 300 USD (darf den Folge-Ausstieg NICHT auslösen) und schließt 3 h später in zwei
    # Stücken. v1 hätte die Eröffnung nie gesehen.
    t_s = t_start + 3 * 86_400 + 14 * 3600 + 7
    stuecke = [(t_s, 3_000.0), (t_s + 50, 3_000.0), (t_s + 110, 800.0), (t_s + 170, 3_500.0)]
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t, "0xd2", "AAA", "perp", "Open Short*", "A", kurs[t // 60 * 60], u / kurs[t // 60 * 60], u, 0.0, 0.0, 10 + i, 0)
                     for i, (t, u) in enumerate(stuecke)]
                    + [(t_s + 3 * 3600 + k * 40, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3 * 3600) // 60 * 60], 50.0, 5_150.0,
                        0.0, 0.0, 20 + k, 1) for k in range(2)]
                    + [(t_s + 3600, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3600) // 60 * 60], 3.0, 300.0, 0.0, 0.0, 30, 1)])
    # 23.39 (Elite als Vorlage): 0xe1 eröffnet Short in drei Stücken zu 4k über 2 min (12k), verkleinert nach 30 min um 1k (darf den
    # Folge-Ausstieg nicht auslösen) und schließt 90 min nach dem Einstieg 7k -- über den Labor-Neustart (13:20) hinweg. 0xe2 ist
    # Elite, aber von der Masterregel gesperrt: seine 20k-Eröffnung darf niemand kopieren.
    t_e = t_start + 86_400 + 12 * 3600 + 30 * 60 + 11
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_e + 60 * k, "0xe1", "AAA", "perp", "Open Short*", "A", kurs[(t_e + 60 * k) // 60 * 60], 40.0, 4_000.0, 0.0, 0.0, 40 + k, 0)
                     for k in range(3)]
                    + [(t_e + 30 * 60, "0xe1", "AAA", "perp", "Close Short*", "B", kurs[(t_e + 30 * 60) // 60 * 60], 10.0, 1_000.0, 0.0, 0.0, 50, 1),
                       (t_e + 90 * 60, "0xe1", "AAA", "perp", "Close Short*", "B", kurs[(t_e + 90 * 60) // 60 * 60], 70.0, 7_000.0, 0.0, 0.0, 51, 1),
                       (t_e + 5 * 3600, "0xe2", "AAA", "perp", "Open Long*", "B", kurs[(t_e + 5 * 3600) // 60 * 60], 200.0, 20_000.0, 0.0, 0.0, 60, 1)])
    con.execute("INSERT INTO konto_status VALUES ('0xe2', 'gesperrt', 'Test', ?, 'auto', 0, 400)", (t_start,))
    # 0xd9 steht auf der Darwin-Liste UND in der Elite: beide Vorlagen müssen seine Eröffnung unabhängig kopieren (eigener Zustand je Vorlage)
    t_b = t_start + 2 * 86_400 + 18 * 3600 + 13
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_b, "0xd9", "AAA", "perp", "Open Long", "B", kurs[t_b // 60 * 60], 150.0, 15_000.0, 0.0, 0.0, 70, 1),
                     (t_b + 7200, "0xd9", "AAA", "perp", "Close Long", "A", kurs[(t_b + 7200) // 60 * 60], 150.0, 15_000.0, 0.0, 0.0, 71, 0)])
    con.commit(); con.close()
    return {"kurs": kurs, "crash": crash, "darwin_t": t_d, "darwin2_t": t_s + 170, "elite_t": t_e + 120, "elite_zu": t_e + 90 * 60,
            "elite_teil": t_e + 30 * 60}


def _grid_markt(pfad: str, t0: int, tage: int, seed: int = 11) -> dict:
    """
    23.40: Synthetischer Markt für die Grids (Coin GRD): Sinus 1 % Amplitude mit 4 h Periode plus Rauschen (seitwärts, sieben Tage Vorlauf
    für σ), dann eine Rallye (+5 % in 40 min, +2 % in 80 min, −3 % in 60 min), ein Crash (−6 % in 10 min mit Long-Liquidationen über der
    Kaskaden-Schwelle) und ein langsamer Abwärtstrend (−0,4 %/h über 10 h).
    """
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    D = 86_400
    rally = t0 + 8 * D + 2 * 3600; crash = t0 + 9 * D + 14 * 3600; trend = t0 + 10 * D + 6 * 3600
    basis = math.log(100.0); drift = 0.0; lp = basis; rows = []; book = []; ctx = []; kurs = {}
    for i in range(tage * 1440):
        t = t0 + i * 60
        if rally <= t < rally + 40 * 60:
            drift += 0.05 / 40
        elif rally + 40 * 60 <= t < rally + 120 * 60:
            drift += 0.02 / 80
        elif rally + 120 * 60 <= t < rally + 180 * 60:
            drift -= 0.03 / 60
        elif crash <= t < crash + 10 * 60:
            drift -= 0.06 / 10
        elif trend <= t < trend + 10 * 3600:
            drift -= 0.004 / 60
        o = math.exp(lp)
        lp = basis + drift + 0.01 * math.sin(2 * math.pi * (t - t0) / (4 * 3600)) + rng.gauss(0, 0.0003)
        c = math.exp(lp)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.0002))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.0002)))
        rows.append((t, "GRD", o, hi, lo, c, 1000.0, 10)); kurs[t] = c
        book.append((t + 59, "GRD", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
        ctx.append((t, "GRD", c, c, c, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    liq = [(t0 + k * 3600, "GRD", "GRDUSDT", "long" if k % 2 else "short", 100.0, 1.0, 10_000.0) for k in range(tage * 24)]
    liq += [(crash + k * 60, "GRD", "GRDUSDT", "long", 100.0, 1.0, 500_000.0) for k in range(10)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", liq)
    con.commit(); con.close()
    return {"kurs": kurs, "rally": rally, "crash": crash, "trend": trend, "spitze": max(v for t, v in kurs.items() if rally <= t < rally + 4 * 3600)}


def _grid_selbsttest(tmp: str, ok) -> None:
    """23.40: Grids auf dem synthetischen Markt -- Aufbau, Kapital, Seitwärts-Gewinne, Rallye (Long hält, Short Notausstieg), Crash
    (Long Notausstieg und Pause, Short hält), Abwärtstrend (Long baut nicht hinein), Neustart im Halten, grobe Takte, Tagesbilanz,
    abgelöste Regelversion, Fehler hinter dem Sicherungspunkt."""
    db = os.path.join(tmp, "grid_m.db")
    T0 = 1_790_006_400 - 13 * 86_400
    info = _grid_markt(db, T0, 12)
    nur = ("grid_long", "grid_short")

    def lauf(sp, schritt, neustart_im_halten=False):
        L = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
        t = T0 + 7 * 86_400; ende = T0 + 11 * 86_400 + 12 * 3600; fehler = []; kap = 0.0; neu_halten = None; nach_neustart = None
        sid_l = next(s["sid"] for s in L.grid_strategien if s["regeln"]["richtung"] == "long")
        while t < ende:
            L.zyklus(t)
            st_ = F.store_connect(sp)
            for sid in L.grid_sids:
                g = L.z["g"].get(f"{sid}|GRD") or {}
                a = st_.execute("SELECT COALESCE(SUM(notional), 0) FROM labor_position WHERE status='offen' AND sid=?", (sid,)).fetchone()[0]
                o_ = st_.execute("SELECT COUNT(*) FROM labor_order WHERE status='offen' AND sid=?", (sid,)).fetchone()[0]
                kap = max(kap, a + o_ * (g.get("los_usd") or 0.0))
            st_.close()
            gl = L.z["g"].get(f"{sid_l}|GRD") or {}
            if neustart_im_halten and neu_halten is None and gl.get("modus") == "halten" and t - gl["halten"]["start"] >= 1800:
                fehler += L.fehler
                L = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))      # Neustart mitten im Halten
                neu_halten = t; L.zyklus(t + schritt); t += schritt
                nach_neustart = (L.z["g"].get(f"{sid_l}|GRD") or {}).get("modus")
            t += schritt
        fehler += L.fehler
        return L, fehler, kap, neu_halten, nach_neustart, ende

    sp = os.path.join(tmp, "grid_f.db")
    L, fehler, kap, neu_halten, nach_neustart, ende = lauf(sp, 120, neustart_im_halten=True)
    st = F.store_connect(sp)
    sid = {s["regeln"]["richtung"]: s["sid"] for s in L.grid_strategien}
    ev = {r_: [(t_, txt) for t_, txt in st.execute("SELECT ts, text FROM labor_ereignis WHERE art='grid' AND sid=? ORDER BY ts, id", (sid[r_],))]
          for r_ in ("long", "short")}
    auf = {r_: [x for x in ev[r_] if " aufgebaut: " in x[1]] for r_ in ev}
    ok("Grid: Aufbau aus der Range", auf["long"] and auf["short"] and auf["long"][0][0] == T0 + 7 * 86_400
       and all(4 <= int(x[1].split(" Stufen à ")[0].split("·")[-1].strip()) <= 12 for x in auf["long"] + auf["short"]),
       f"Long {len(auf['long'])}×, Short {len(auf['short'])}× aufgebaut; erstes: „{auf['long'][0][1][:110] if auf['long'] else '—'}“")
    ok("Grid: Kapital nie über dem Konto", kap <= GRID_KAPITAL + 1e-6, f"höchstens {kap:,.2f} USD aus Losen und liegenden Orders (Konto {GRID_KAPITAL:,.0f})")
    vor = info["rally"]
    runden = {r_: st.execute("SELECT COUNT(*), SUM(netto_usd > 0), MIN(netto_usd), SUM(netto_usd) FROM labor_position WHERE sid=? AND status='geschlossen' "
                             "AND art_aus LIKE 'Grid-%' AND geschlossen < ?", (sid[r_], vor)).fetchone() for r_ in ("long", "short")}
    ok("Grid: seitwärts verdient jede Runde", all(r_[0] >= 20 and r_[1] == r_[0] for r_ in runden.values()),
       f"vor der Rallye: Long {runden['long'][0]} Runden, Summe {runden['long'][3] or 0:+.2f} USD (kleinste {runden['long'][2] or 0:+.2f}); "
       f"Short {runden['short'][0]} Runden, Summe {runden['short'][3] or 0:+.2f} USD")
    halten_l = [x for x in ev["long"] if vor <= x[0] <= vor + 3600 and "ausgesetzt" in x[1]]
    ende_l = st.execute("SELECT MIN(geschlossen), MIN(preis_aus), SUM(netto_usd), COUNT(*) FROM labor_position WHERE sid=? AND art_aus LIKE 'Trailing%' "
                        "AND geschlossen BETWEEN ? AND ?", (sid["long"], vor, vor + 6 * 3600)).fetchone()
    g_oben = max((float(x[1].split("Range ")[1].split("–")[1].split(" ")[0]) for x in auf["long"] if x[0] < vor), default=None)
    sig1h = None
    if halten_l:
        try:
            sig1h = float(halten_l[0][1].split(" = ")[1].split(" %")[0]) / 100 / 1.5
        except (IndexError, ValueError):
            sig1h = None
    ok("Grid Long: Rallye halten, nahe dem Hoch verkaufen", halten_l and ende_l[3] and ende_l[2] > 0 and g_oben and ende_l[1] > g_oben * 1.03
       and sig1h and ende_l[1] >= info["spitze"] * (1 - 1.5 * sig1h) * 0.998,
       f"gehalten ab {_uhr(halten_l[0][0]) if halten_l else '—'} ({halten_l[0][1][:60] if halten_l else '—'}); {ende_l[3] or 0} Lose zu "
       f"{ende_l[1] or 0:.4g} verkauft (Hoch {info['spitze']:.4g}, oberste Grid-Stufe {g_oben or 0:.4g}), netto {ende_l[2] or 0:+.2f} USD")
    ok("Grid: Neustart mitten im Halten", neu_halten and nach_neustart == "halten" and ende_l[0] and ende_l[0] > neu_halten,
       f"Neustart {_uhr(neu_halten) if neu_halten else '—'} → Modus „{nach_neustart}“, Ausstieg {_uhr(ende_l[0]) if ende_l[0] else '—'}")
    na_s = [x for x in ev["short"] if vor <= x[0] <= vor + 1800 and x[1].startswith("Notausstieg")]
    ok("Grid Short: Rallye = Notausstieg", na_s, f"{_uhr(na_s[0][0]) if na_s else '—'}: {na_s[0][1][:110] if na_s else 'keiner'}")
    cr = info["crash"]
    na_l = [x for x in ev["long"] if cr <= x[0] <= cr + 300 and x[1].startswith("Notausstieg")]
    offen_nach = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=? AND eroeffnet BETWEEN ? AND ?", (sid["long"], cr + 300, cr + 4 * 3600)).fetchone()[0]
    ok("Grid Long: Crash = Notausstieg, dann Pause", na_l and offen_nach == 0,
       f"{_uhr(na_l[0][0]) + ': ' + na_l[0][1][:100] if na_l else 'kein Notausstieg'}; neue Lose in den 4 h danach: {offen_nach}")
    h_s = [x for x in ev["short"] if cr <= x[0] <= cr + 900 and "ausgesetzt" in x[1]]
    e_s = st.execute("SELECT COUNT(*), SUM(netto_usd) FROM labor_position WHERE sid=? AND art_aus LIKE 'Trailing%' AND geschlossen BETWEEN ? AND ?",
                     (sid["short"], cr, cr + 8 * 3600)).fetchone()
    ok("Grid Short: Crash halten, nach dem Tief zurückkaufen", h_s and e_s[0] and (e_s[1] or 0) > 0,
       f"{_uhr(h_s[0][0]) + ' ' + h_s[0][1][:70] if h_s else 'kein Halten'}; {e_s[0] or 0} Lose per Trailing-Stop, netto {e_s[1] or 0:+.2f} USD")
    tr0 = info["trend"]
    na_tr = [x for x in ev["long"] if tr0 <= x[0] <= tr0 + 12 * 3600 and x[1].startswith("Notausstieg")]
    auf_tr = [x for x in ev["long"] if tr0 + 3600 <= x[0] <= tr0 + 10 * 3600 and " aufgebaut: " in x[1]]
    ok("Grid Long: baut nicht in den Abwärtstrend", len(na_tr) <= 1 and not auf_tr,
       f"Notausstiege im Trend: {len(na_tr)}; Aufbauten im Trend: {len(auf_tr)}")
    ok("Grid Long: langsamer Abwärtstrend endet an der Notlinie", len(na_tr) == 1 and "Notlinie" in na_tr[0][1],
       f"{_uhr(na_tr[0][0]) + ': ' + na_tr[0][1][:100] if na_tr else 'kein Notausstieg im Trend'}")
    K = {k["name"]: k for k in kennzahlen(st, ende)}
    gt = grid_tage(st, sid["long"])
    real = st.execute("SELECT COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE sid=? AND status='geschlossen'", (sid["long"],)).fetchone()[0]
    eq = {r_["sid"]: r_ for r_ in equity(sp, ende)["reihen"]}
    kl = K["grid_long"]
    ok("Grid: Tagesbilanz nach Bestandswert", kl["n_eff"] == len(gt["tage"]) >= 3 and abs(kl["summe_usd"] - (real + sum(gt["bestand"].values()))) < 0.02
       and abs(eq[sid["long"]]["summe"] - kl["summe_usd"]) < 0.05 and abs(sum(u for _, u in gt["tage"]) - kl["summe_usd"]) < 0.05,
       f"Long: {kl['n_eff']} Tage, Summe {kl['summe_usd']:+.2f} = realisiert {real:+.2f} + Bestand {sum(gt['bestand'].values()):+.2f}; "
       f"Bilanzlinie endet bei {eq[sid['long']]['summe']:+.2f}; Short {K['grid_short']['summe_usd']:+.2f} USD")
    st.close()
    # Grobe Takte (10 min, Nachholen über die Kerzen): dieselben Ereignisse, keine Fehler, Kapital eingehalten
    sp2 = os.path.join(tmp, "grid_f2.db")
    L2, fehler2, kap2, _, _, _ = lauf(sp2, 600)
    st2 = F.store_connect(sp2)
    ev2 = [txt for (txt,) in st2.execute("SELECT text FROM labor_ereignis WHERE art='grid' AND sid=? ORDER BY ts", (sid["long"],))]
    s1 = F.store_connect(sp).execute("SELECT SUM(netto_usd) FROM labor_position WHERE status='geschlossen'").fetchone()[0] or 0.0
    s2 = st2.execute("SELECT SUM(netto_usd) FROM labor_position WHERE status='geschlossen'").fetchone()[0] or 0.0
    st2.close()
    ok("Grid: grobe Takte holen über die Kerzen nach", not fehler2 and kap2 <= GRID_KAPITAL + 1e-6 and any("ausgesetzt" in x for x in ev2)
       and abs(s1 - s2) <= 0.35 * max(abs(s1), 50.0),
       f"10-min-Takt: realisiert {s2:+.2f} USD gegen {s1:+.2f} im 2-min-Takt; Halten in der Rallye: {'ja' if any('ausgesetzt' in x for x in ev2) else 'nein'}")
    # Mikro-Proben auf festen Kerzen (Regeln, die der Markt oben nicht zuverlässig trifft)
    spm = os.path.join(tmp, "grid_mikro.db"); Lm = Labor(db, spm, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    stm = Lm._st(); cm = Lm._con(); Lm._registrieren(stm, T0); Sl = next(s for s in Lm.grid_strategien if s["regeln"]["richtung"] == "long")
    tm = T0 + 10 * 86_400
    Em = {"coin": "GRD", "preis": {"ts": tm, "mid": 102.5, "bid": 102.49, "ask": 102.51, "spread_bps": 2.0, "kauf": [], "verkauf": []},
          "sigma15": 0.003, "sigma1h": 0.006, "sigma4h": 0.012, "kerzen20": [], "kaskade": {}}

    def gs_neu(**kw):
        return dict({"modus": "aktiv", "gen": 2, "stufen": [100.0, 101.0, 102.0, 103.0, 104.0], "n": 4, "schritt": 0.01, "unten": 100.0, "oben": 104.0,
                     "notlinie": 99.0, "los_usd": 2500.0, "zaehler": {}, "gepr": tm}, **kw)
    # a) Kapital: zwei Lose einer früheren Generation binden 5.000 -- von drei freien Abständen unter dem Kurs bekommen nur zwei eine Order
    g_a = gs_neu(gen=1); alt_l = [Lm._grid_los_auf(stm, Sl, "GRD", g_a, i, tm, 103.5, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm + 60) for i in (2, 3)]
    g_a = gs_neu(); o_a: list = []
    n_a = Lm._grid_auffuellen(stm, Sl, g_a, "GRD", alt_l, o_a, tm, 102.5)
    ok("Grid: Kapitaldeckel mit Losen früherer Stufen", n_a == 2 and sorted(o["preis"] for o in o_a) == [101.0, 102.0],
       f"{n_a} Orders bei {sorted(o['preis'] for o in o_a)} (Lose älterer Generation 2 × 2.500 USD, Konto 10.000)")
    # b) Halten mitten in der Minute: das Tief derselben Kerze lag VOR dem Auslöser und darf den Trailing-Stop nicht auslösen
    g_b = gs_neu(modus="halten", halten={"start": tm + 30, "ab": tm + 60, "start_px": 103.0, "extrem": 103.0, "stop": 103.0 * (1 - 1.5 * 0.006),
                                        "sig": 0.006, "grund": "Test"})
    l_b = [Lm._grid_los_auf(stm, Sl, "GRD", gs_neu(), 1, tm - 600, 101.0, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm - 540)]
    r1 = Lm._grid_kerze(cm, stm, Sl, g_b, "GRD", Em, l_b, [], tm, 102.5, 103.4, 102.0, 103.3, None, None)
    st_b1 = (g_b["modus"], round((g_b.get("halten") or {}).get("extrem", 0.0), 4), len(l_b))
    r2 = Lm._grid_kerze(cm, stm, Sl, g_b, "GRD", Em, l_b, [], tm + 60, 103.3, 103.35, 102.1, 102.2, None, None)
    ok("Grid: Trailing-Stop zählt erst ab der Kerze nach dem Auslöser", r1 == 0 and st_b1 == ("halten", 103.4, 1) and r2 == 1 and g_b["modus"] == "pause"
       and not l_b, f"Startkerze (Tief 102,0 vor dem Auslöser): {st_b1[0]}, Hoch {st_b1[1]}; nächste Kerze unter dem Stop "
       f"{103.4 * (1 - 1.5 * 0.006):.3f}: {g_b['modus']}")
    # c) Notlinie in derselben Kerze wie eine Füllung: erst füllt das Kauf-Limit, dann schließt die Notlinie ALLE Lose (auch das neue)
    g_c = gs_neu(); l_c = [Lm._grid_los_auf(stm, Sl, "GRD", g_c, 1, tm - 600, 101.0, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm - 540)]
    o_c = [Lm._grid_order(stm, Sl, "GRD", g_c, 0, tm - 600)]
    Lm._grid_kerze(cm, stm, Sl, g_c, "GRD", Em, l_c, o_c, tm, 100.8, 100.9, 98.5, 98.7, None, None)
    zu_c = stm.execute("SELECT preis_ein, art_aus, preis_aus FROM labor_position WHERE status='geschlossen' AND art_aus LIKE 'Notausstieg%' "
                       "AND eroeffnet >= ? ORDER BY preis_ein", (tm - 600,)).fetchall()
    ok("Grid: Notlinie nach der Füllung in derselben Kerze", g_c["modus"] == "pause" and not l_c and not o_c and [round(x[0], 2) for x in zu_c] == [100.0, 101.0]
       and all(abs(x[2] - 99.0 * (1 - 1e-4)) < 0.05 for x in zu_c),
       f"geschlossen: {[(round(x[0], 2), round(x[2], 3)) for x in zu_c]} (Einstieg, Ausstieg bei der Notlinie 99 abzüglich Auswirkung); Modus {g_c['modus']}")
    stm.rollback(); stm.close(); cm.close()
    # Abgelöste Regelversion: Lose schließen, Orders löschen
    st = F.store_connect(sp)
    st.execute("INSERT INTO labor_strategie VALUES ('grid_long@alt00000', 'grid_long', 'Grid Long', 'Grid', '{}', '', ?, 0)", (T0,))
    st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, sl, tp, ablauf, "
               "grund, werte, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) VALUES ('grid_long@alt00000', 'GRD', 'long', 'offen', ?, 95.0, "
               "1000.0, 10.526, 'Grid-Kauf (Maker)', 0.15, 0, 90.0, 99.0, 0, 'alt', '{\"stufe\": 0, \"gen\": 1}', ?, ?, 0, ?, 0, 0)", (ende - 3600,) * 4)
    st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, geprueft_bis) "
               "VALUES ('grid_long@alt00000', 'GRD', 'long', 94.0, ?, ?, 'offen', 'alt', '{}', ?)", (ende - 3600, ende + 86_400, ende - 3600))
    st.commit(); st.close()
    L3 = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    L3.zyklus(ende + 30)
    st = F.store_connect(sp)
    alt = st.execute("SELECT status, grund_aus FROM labor_position WHERE sid='grid_long@alt00000'").fetchone()
    alt_o = st.execute("SELECT COUNT(*) FROM labor_order WHERE sid='grid_long@alt00000'").fetchone()[0]
    ok("Grid: abgelöste Regelversion wird geschlossen", alt and alt[0] == "geschlossen" and alt[1] == "Regelversion abgelöst" and alt_o == 0,
       f"Los: {alt[0] if alt else '—'} ({alt[1] if alt else '—'}), Orders übrig: {alt_o}")
    # Fehler in einem Grid: Sicherungspunkt -- Datenbank und Zustand dieses Grids unverändert, das andere läuft weiter
    vor_z = json.loads(_j(L3.z["g"][f"{sid['short']}|GRD"]))
    vor_n = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=?", (sid["short"],)).fetchone()[0]
    st.close()
    echt = L3._grid_pruefen

    def kaputt(con_, st_, S_, *a, **kw):
        if S_["regeln"]["richtung"] == "short":
            st_.execute("INSERT INTO labor_ereignis (ts, sid, coin, art, text) VALUES (0, ?, 'GRD', 'grid', 'darf nicht bleiben')", (S_["sid"],))
            raise RuntimeError("Testfehler")
        return echt(con_, st_, S_, *a, **kw)
    L3._grid_pruefen = kaputt
    L3.zyklus(ende + 150)
    st = F.store_connect(sp)
    rest = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE text='darf nicht bleiben'").fetchone()[0]
    nach_n = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=?", (sid["short"],)).fetchone()[0]
    st.close()
    ok("Grid: Fehler nur in einem Grid, Sicherungspunkt", rest == 0 and nach_n == vor_n and L3.z["g"][f"{sid['short']}|GRD"] == vor_z
       and any("Testfehler" in f_ for f_ in L3.fehler) and int(L3.z["g"][f"{sid['long']}|GRD"]["gepr"]) >= (ende + 150) // 60 * 60,
       f"Fehler gemeldet: {'ja' if any('Testfehler' in f_ for f_ in L3.fehler) else 'nein'}; halbe Änderung zurückgerollt: {'ja' if rest == 0 else 'NEIN'}; "
       f"Long lief weiter bis {_uhr(L3.z['g'][sid['long'] + '|GRD']['gepr'])}")
    # 23.41 (Pi 02.10. 06:57 „ZEC Handel: database is locked“): Schreibt ein anderer Thread (Prognose, Familien, Profis), während das
    # Grid liest, darf der nächste Schreibzugriff des Labors im selben Takt nicht scheitern. 23.40 öffnete mit einem einfachen BEGIN eine
    # Lese-Transaktion -- nach einem fremden Commit war ihr Stand veraltet, und das Schreiben scheiterte sofort (ohne Wartezeit).
    L4 = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    L4.zyklus(ende + 210)                                                    # erster Takt registriert (schreibt ohnehin)
    echt_lose = L4._grid_lose; fremd = {"commit": 0, "wartet": 0}

    def lose_und_fremder_schreiber(st_, sid_, coin_, pid=None):
        r = echt_lose(st_, sid_, coin_, pid)
        if pid is None:
            c = sqlite3.connect(sp, timeout=0.05)
            try:
                c.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('probe_fremd', ?)", (str(time.time()),)); c.commit(); fremd["commit"] += 1
            except sqlite3.OperationalError:
                fremd["wartet"] += 1                                         # Labor hält die Schreibsperre: der andere muss warten
            finally:
                c.close()
        return r
    L4._grid_lose = lose_und_fremder_schreiber
    abbr = []
    for k in range(3):                                                       # jede Minute neu: Kerzen-Stand und Zustand werden geschrieben
        try:
            L4.zyklus(ende + 270 + 60 * k)
        except sqlite3.OperationalError as e:
            abbr.append(str(e))
    gesp = [f_ for f_ in L4.fehler if "locked" in f_] + abbr
    st = F.store_connect(sp)
    gst = json.loads(st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()[0])["g"].get(f"{sid['long']}|GRD") or {}
    st.close()
    ok("Grid: fremder Schreiber im Takt, kein „database is locked“", not gesp and fremd["wartet"] >= 1 and int(gst.get("gepr") or 0) >= (ende + 390) // 60 * 60,
       f"fremde Commits während das Grid las: {fremd['commit']}, mussten warten: {fremd['wartet']}; Fehler: {gesp[:2] or 'keine'}; Zustand gespeichert bis "
       f"{_uhr(gst.get('gepr'))}")
    ok("Grid: keine Laufzeitfehler", not fehler, "; ".join(fehler[-3:]) or "keine")


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    # 1. Ausführungsmodell
    b = {"mid": 100.0, "spread_bps": 2.0, "kauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)], "verkauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)]}
    p1, bps1 = taker_preis(b, True, 10_000)
    p2, bps2 = taker_preis(b, True, 3e6)
    p3, _ = taker_preis(b, False, 10_000)
    ok("Markt-Order klein ≈ Briefkurs", abs(bps1 - 1.0) < 0.05 and p1 > 100.0, f"{bps1:.3f} bps über der Mitte")
    ok("Markt-Order groß mit Auswirkung", 6 < bps2 < 12 and p3 < 100.0, f"3 Mio: {bps2:.1f} bps im Mittel über die Tiefe, Verkauf 10k {p3:.4f}")
    ok("Jenseits der Tiefe pauschal", _auswirkung_bps(1e8, 1.0, [(10, 1e6)]) > 140, f"{_auswirkung_bps(1e8, 1.0, [(10, 1e6)]):.0f} bps")
    tmp = tempfile.mkdtemp(prefix="hl_labor_test_")
    try:
        db = os.path.join(tmp, "m.db"); sp = os.path.join(tmp, "f.db")
        T0 = 1_790_006_400 - 6 * 86_400
        info = _probe_datenbank(db, T0, 5)
        kurs = info["kurs"]
        st = F.store_connect(sp)
        rng = random.Random(3); drv = []; fc = []
        for t in range(T0, T0 + 5 * 86_400, 900):
            p0 = kurs.get(t // 60 * 60); p4 = kurs.get((t + 4 * 3600) // 60 * 60)
            if not p0 or not p4:
                continue
            richtig = rng.random() < 0.85
            s = (1 if p4 > p0 else -1) * (1 if richtig else -1) * 0.8
            drv += [(t, "AAA", "Wal-Flow 30 min", s), (t, "AAA", "Leaderboard-Flow 60 min", max(-1, min(1, rng.gauss(0, 0.6))))]
            fc.append((t, "AAA", p0, 0.0, p0, p0, json.dumps({"p_up_v2": 0.5, "kalib2": {"version": 2}, "fusion": {"p_4": 0.47},
                                                              "kosten": {"er_4": 0.0123}}), 0.5, 0.5))      # 23.42: Fusion und Kostenschwelle im Payload
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, buy_px, sell_px, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?)", fc)
        st.execute("INSERT OR REPLACE INTO learned VALUES ('*', 'darwin', ?, ?)", (json.dumps({"reihe": ["0xd1", "0xd2", "0xd9"], "liste": ["0xd1", "0xd2", "0xd9"]}), T0))
        st.execute("INSERT OR REPLACE INTO learned VALUES ('AAA', 'elite', ?, ?)", (json.dumps(["0xe1", "0xe2", "0xd9"]), T0))   # 23.39
        st.commit(); st.close()
        nur = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "darwin_folgen", "darwin_gegen", "elite_folgen", "elite_gegen", "docht_fangen", "kaskade_umkehr",
               "kaskade_fortsetzung", "zufall", "halten_long")
        L = None; t = T0 + 86_400; schritt = 120; i = 0; fehler = []
        while t < T0 + 5 * 86_400 - 120:
            if L is None or i % 400 == 0:
                if L is not None:
                    fehler += L.fehler
                L = Labor(db, sp, coins=("AAA",), nur=nur, adressfluss=os.path.join(tmp, "af.db"))     # Neustart-Probe
            L.zyklus(t)
            t += schritt; i += 1
        fehler += L.fehler
        n_vor = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        ende = T0 + 5 * 86_400
        for dt in (240, 300, 360, 420):                                   # Daten enden: Kurs veraltet -> keine neuen Einstiege
            L.zyklus(ende + dt)
        n_nach = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        veraltet = sum(1 for v in L.status.values() if v.get("blockiert") == "Kurs veraltet")
        fehler += L.fehler
        st = F.store_connect(sp)
        K = {k["name"]: k for k in kennzahlen(st, t)}
        pos = st.execute("SELECT COUNT(*), SUM(status='offen') FROM labor_position").fetchone()
        g_ein = st.execute("SELECT gebuehr_ein, notional, art_ein FROM labor_position WHERE art_ein LIKE 'Markt%' LIMIT 1").fetchone()
        dw_alle = [(e, g, s_, json.loads(w or "{}").get("konto"), zu) for e, g, s_, w, zu in st.execute(
            "SELECT p.eroeffnet, p.grund_aus, p.seite, p.werte, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_folgen'")]
        dw = [x for x in dw_alle if x[3] == "0xd1"]; dw2 = [x for x in dw_alle if x[3] == "0xd2"]; dw9 = [x for x in dw_alle if x[3] == "0xd9"]
        dg = st.execute("SELECT p.seite FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_gegen' ORDER BY p.eroeffnet").fetchall()
        el = [(e, g, s_, json.loads(w or "{}").get("konto"), zu) for e, g, s_, w, zu in st.execute(
            "SELECT p.eroeffnet, p.grund_aus, p.seite, p.werte, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='elite_folgen'")]
        eg = st.execute("SELECT p.seite FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='elite_gegen' ORDER BY p.eroeffnet").fetchall()
        doc = st.execute("SELECT COUNT(*) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='docht_fangen' AND p.art_ein LIKE 'Limit%'").fetchone()[0]
        kas = st.execute("SELECT s.name, p.seite, p.eroeffnet FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name LIKE 'kaskade%'").fetchall()
        kas_e = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='kaskade'").fetchone()[0]
        st.close()
        w, wg, lb, zf = K["wale_folgen"], K["wale_gegen"], K["leaderboard_folgen"], K["zufall"]
        ok("Positivkontrolle: eingebaute Kante verdient", w["n"] >= 10 and (w["mittel_pct"] or 0) > 0 and (w["t"] or 0) >= 2,
           f"Wale folgen: {w['n']} Trades, Ø {w['mittel_pct'] or 0:+.3f} %, t {w['t'] or 0:+.1f}")
        ok("Gegenrichtung verliert", (wg["mittel_pct"] or 0) < 0, f"Gegen die Wale: Ø {wg['mittel_pct'] or 0:+.3f} %")
        ok("Rauschen ohne Scheinbeleg", lb["n"] >= 5 and abs(lb["t"] or 0) < 3, f"Leaderboard (Zufallstreiber): {lb['n']} Trades, t {lb['t'] or 0:+.1f}")
        ok("Zufall kostet", zf["n"] >= 5 and (zf["mittel_pct"] or 0) < 0.1, f"Zufall: {zf['n']} Trades, Ø {zf['mittel_pct'] or 0:+.3f} %")
        ok("Gebühr Taker 0,045 %", g_ein and abs(g_ein[0] - g_ein[1] * GEB_TAKER) < 1e-6, f"{g_ein[0]:.2f} USD auf {g_ein[1]:.0f}" if g_ein else "keine")
        ok("Darwin folgen: Ein- und Folge-Ausstieg", len(dw) == 1 and 0 <= dw[0][0] - info["darwin_t"] <= DARWIN_FRISCH_S and "schließt" in (dw[0][1] or "")
           and dw[0][2] == "long", f"{len(dw)} Trade(s), Einstieg {dw[0][0] - info['darwin_t'] if dw else '—'} s nach dem Konto, Ausstieg „{dw[0][1] if dw else '—'}“")
        ok("Darwin v2: Eröffnung in Stücken erkannt", len(dw2) == 1 and 0 <= dw2[0][0] - info["darwin2_t"] <= DARWIN_FRISCH_S and dw2[0][2] == "short"
           and "schließt" in (dw2[0][1] or "") and (dw2[0][4] or 0) >= info["darwin2_t"] + 3 * 3600 - 200 and len(dw_alle) == 3,
           f"{len(dw2)} Trade(s) aus 4 Stücken (3k+3k+0,8k+3,5k), Einstieg {dw2[0][0] - info['darwin2_t'] if dw2 else '—'} s nach dem letzten Stück; "
           f"Teilverkauf 300 USD nach 1 h ignoriert, Ausstieg {((dw2[0][4] or 0) - info['darwin2_t']) / 3600:.1f} h danach „{dw2[0][1] if dw2 else '—'}“; "
           f"insgesamt {len(dw_alle)} Darwin-Trades")
        ok("Darwin dagegen: Gegenseite", [x[0] for x in dg] == ["short", "short", "long"], f"{[x[0] for x in dg] or '—'}")
        el9 = [x for x in el if x[3] == "0xd9"]; el = [x for x in el if x[3] != "0xd9"]
        ok("Elite folgen: Ein- und Folge-Ausstieg über einen Neustart", len(el) == 1 and el[0][3] == "0xe1" and el[0][2] == "short"
           and 0 <= el[0][0] - info["elite_t"] <= DARWIN_FRISCH_S and "Elite-Konto" in (el[0][1] or "") and "schließt" in (el[0][1] or "")
           and info["elite_zu"] <= (el[0][4] or 0) <= info["elite_zu"] + 300,
           f"{len(el)} Trade(s) aus 3 Stücken zu 4k, Einstieg {el[0][0] - info['elite_t'] if el else '—'} s nach dem letzten Stück; Teilschließung 1k "
           f"nach 30 min ignoriert, Ausstieg {((el[0][4] or 0) - info['elite_t']) / 60 if el else 0:.0f} min danach „{el[0][1] if el else '—'}“")
        ok("Elite dagegen: Gegenseite; Gesperrte nie kopiert", [x[0] for x in eg] == ["long", "short"] and not any(x[3] == "0xe2" for x in el),
           f"Gegen die Elite: {[x[0] for x in eg] or '—'}; 20k-Eröffnung des gesperrten Elite-Kontos: {'kopiert (FEHLER)' if any(x[3] == '0xe2' for x in el) else 'nicht kopiert'}")
        ok("Vorlagen getrennt, eigener Zustand je Vorlage", {x[3] for x in dw_alle} == {"0xd1", "0xd2", "0xd9"} and {x[3] for x in el} == {"0xe1"}
           and len(dw9) == 1 and len(el9) == 1 and dw9[0][2] == el9[0][2] == "long" and "schließt" in (dw9[0][1] or "") and "schließt" in (el9[0][1] or ""),
           f"Darwin kopiert {sorted({x[3] for x in dw_alle})}, Elite kopiert {sorted({x[3] for x in el + el9})}; Konto in beiden Vorlagen: "
           f"Darwin {len(dw9)}, Elite {len(el9)} Trade(s), beide mit Folge-Ausstieg")
        ok("Docht fangen: Limit gefüllt", doc >= 1, f"{doc} Füllungen über Limit-Orders")
        fs = [k for k in kas if k[0] == "kaskade_fortsetzung"]; um = [k for k in kas if k[0] == "kaskade_umkehr"]
        ok("Kaskade erkannt und gehandelt", kas_e >= 1 and fs and fs[0][1] == "short" and um and um[0][1] == "long" and um[0][2] > fs[0][2],
           f"{kas_e} Erkennung(en); Fortsetzung {fs[0][1] if fs else '—'}, Umkehr {um[0][1] if um else '—'}")
        ok("Keine Laufzeitfehler", not fehler, "; ".join(fehler[-3:]) or "keine")
        ok("Live-Tafel: Stand je Strategie", len(L.status) == len(nur) and all(v.get("text") for v in L.status.values()),
           f"{len(L.status)} Einträge, z. B. „{next(iter(L.status.values()))['text'] if L.status else '—'}“")
        ok("Positionen gespeichert", pos[0] >= 20, f"{pos[0]} Positionen, {pos[1] or 0} offen")
        ok("Veralteter Kurs: keine neuen Einstiege", n_nach == n_vor and veraltet >= 1, f"{n_nach - n_vor} neue Positionen, {veraltet} Strategien „Kurs veraltet“")
        c_e, s_e = L._con(), L._st()                                                  # 23.42: der Weg Payload → Eingaben der Fusions-Strategien
        try:
            P_e = (L.eingaben(c_e, s_e, "AAA", T0 + 2 * 86_400 + 600, L.z or L._zustand(s_e)).get("prognose") or {})
        finally:
            c_e.close(); s_e.close()
        ok("Fusion und E|r| aus dem Payload gelesen", P_e.get("p_fusion") == 0.47 and P_e.get("er_4") == 0.0123 and P_e.get("p_up") == 0.5,
           f"p_fusion {P_e.get('p_fusion')}, er_4 {P_e.get('er_4')} (p_up {P_e.get('p_up')})")
        # Hebel-Ansicht: Liquidation bei großem Rückgang im Trade
        s = _stat([{"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 0.5, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 0, "geschlossen": 1},
                   {"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 12.0, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 1, "geschlossen": 2}], 0, 86_400)
        h10 = next(h for h in s["hebel"] if h["L"] == 10); h3 = next(h for h in s["hebel"] if h["L"] == 3)
        ok("Hebel-Ansicht: Liquidation", h10["ausgeloescht"] == 2 and h3["ausgeloescht"] is None and abs(h10["summe_usd"] - (100 - NOTIONAL)) < 1e-6
           and abs(h3["summe_usd"] - 60) < 1e-6, f"10×: ausgelöscht nach Trade {h10['ausgeloescht']}, Summe {h10['summe_usd']:+.0f} USD; 3×: ×{h3['faktor']:.4f}, {h3['summe_usd']:+.0f} USD")
        # 23.34: Blockstatistik -- 40 gleichzeitige Trades (dasselbe Signal, ein 4-h-Block) sind EINE Beobachtung
        rng_b = random.Random(5)
        gleich = [{"netto_usd": 30.0, "netto_pct": 0.3 + rng_b.gauss(0, 0.05), "mae_pct": 0.2, "gebuehren": 9, "funding": 0, "slip": 1,
                   "eroeffnet": 1_790_000_000 + 60 * (i % 5), "geschlossen": 1_790_010_000} for i in range(40)]
        verteilt = [dict(x, eroeffnet=1_790_000_000 + i * 5 * 3600, geschlossen=1_790_000_000 + i * 5 * 3600 + 3000) for i, x in enumerate(gleich)]
        sg = _stat(gleich, 1_789_990_000, 1_790_020_000, 1.0, block_s=4 * 3600); sv = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0, block_s=4 * 3600)
        sr = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0)
        ok("Blockstatistik: gleichzeitige Trades zählen einmal", sg["n"] == 40 and sg["n_eff"] == 1 and sg["t"] is None and sg["stufe"] == "Kandidat"
           and sv["n_eff"] == 40 and abs((sv["t"] or 0) - (sr["t"] or 0)) < 1e-9 and (sv["t"] or 0) > 3,
           f"40 Trades in einem Block: n_eff {sg['n_eff']}, t {sg['t']}, Stufe {sg['stufe']} · verteilt: n_eff {sv['n_eff']}, t {sv['t'] or 0:+.1f}")
        kt = konten_tage(0, 10 * 86_400, {"BTC": 0, "XMR": 8 * 86_400}, ["BTC", "XMR"])
        st_k = _stat([{"netto_usd": 120.0, "netto_pct": 1.2, "mae_pct": 0.1, "gebuehren": 9, "funding": 0, "slip": 1, "eroeffnet": 100, "geschlossen": 200}],
                     0, 10 * 86_400, kt)
        ok("Kontotage: später gestarteter Coin zählt ab seinem Start", abs(kt - 12.0) < 1e-9 and abs(st_k["tag_pct"] - 120.0 / 12 / NOTIONAL * 100) < 1e-9,
           f"BTC 10 T + XMR 2 T = {kt:g} Kontotage, Ø/Tag {st_k['tag_pct']:.4f} %")
        mig = F.store_connect(os.path.join(tmp, "mig.db")); schema(mig)
        mig.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(T0),)); mig.commit()
        cs = coin_starts(mig, ("BTC", "ETH", "XMR"), T0 + 5 * 86_400, schreiben=True); cs2 = coin_starts(mig); mig.close()
        ok("Umstellung: alte Coins behalten den Start, XMR beginnt jetzt", cs == cs2 == {"BTC": T0, "ETH": T0, "XMR": T0 + 5 * 86_400},
           f"{ {c: (t - T0) // 86_400 for c, t in cs.items()} } Tage nach dem Laborstart")
        ok("Gebühr XMR (HIP-3) doppelt", abs(gebuehr("XMR", GEB_TAKER) - 0.0009) < 1e-12 and gebuehr("BTC", GEB_TAKER) == GEB_TAKER,
           f"Taker XMR {gebuehr('XMR', GEB_TAKER) * 100:.3f} %, BTC {gebuehr('BTC', GEB_TAKER) * 100:.3f} %")
        # 23.42: Fusion mit Kostenschwelle -- Einstieg nur, wenn |2p − 1| · E|r| mindestens 1,5 × Kosten (Taker beider Seiten plus Abstand zur
        # Buchmitte bei 10k) erreicht; die feste Schwelle 0,08 wie v1 für die Vergleichsstrategie
        S_fk = next(s_ for s_ in strategien() if s_["name"] == "prognose_fusion_kosten")
        S_fp = next(s_ for s_ in strategien() if s_["name"] == "prognose_fusion")
        bk = {"ts": 1000, "mid": 100.0, "bid": 99.99, "ask": 100.01, "spread_bps": 2.0, "kauf": [(10, 2e6), (25, 5e6)], "verkauf": [(10, 2e6), (25, 5e6)]}

        def e_f(p_, er=0.01, ts=1000, coin="AAA"):
            return {"coin": coin, "preis": bk, "prognose": {"ts": ts, "p_fusion": p_, "er_4": er, "bias": 0.0}}
        fk = {(c_, p_): [a["seite"] for a in sig_fusion(S_fk, e_f(p_, coin=c_), c_, 1200, {})] for c_, p_ in
              (("AAA", 0.60), ("AAA", 0.57), ("AAA", 0.40), ("AAA", 0.5), ("XMR", 0.60), ("XMR", 0.70))}
        k_aaa = fusion_vorsprung(S_fk, e_f(0.6), "AAA", 1200)["kosten"]
        alt_ = sig_fusion(S_fk, e_f(0.7, ts=1000 - FRISCH_S["prognose"]), "AAA", 1200, {})
        ohne_er = fusion_vorsprung(S_fk, e_f(0.7, er=None), "AAA", 1200)
        ok("Fusion mit Kostenschwelle: handelt nur über 1,5 × Kosten",
           fk == {("AAA", 0.60): ["long"], ("AAA", 0.57): [], ("AAA", 0.40): ["short"], ("AAA", 0.5): [], ("XMR", 0.60): [], ("XMR", 0.70): ["long"]}
           and abs(k_aaa - (2 * GEB_TAKER + 2 * taker_preis(bk, True, NOTIONAL)[1] / 1e4)) < 1e-12 and not alt_ and not ohne_er.get("handeln"),
           f"Kosten {k_aaa * 100:.3f} % (1,5-fach {1.5 * k_aaa * 100:.3f} %), E|r| 1 %: p 60 % → {fk[('AAA', 0.60)]}, 57 % → {fk[('AAA', 0.57)]}, "
           f"40 % → {fk[('AAA', 0.40)]}; XMR (Gebühr doppelt) 60 % → {fk[('XMR', 0.60)]}, 70 % → {fk[('XMR', 0.70)]}; alte Prognose, fehlendes E|r| → nichts")
        fp = [[a["seite"] for a in sig_prognose(S_fp, e_f(p_), "AAA", 1200, {})] for p_ in (0.59, 0.55, 0.41)]
        ok("Prognose Fusion: feste Schwelle wie v1", fp == [["long"], [], ["short"]] and S_fk["regeln"]["puffer"] == FUSION_PUFFER == 1.5
           and status_text(S_fk, e_f(0.6), 1200, {}).startswith("Fusion 60.0 %"), f"59 % → {fp[0]}, 55 % → {fp[1]}, 41 % → {fp[2]} · Tafel: "
           f"{status_text(S_fk, e_f(0.6), 1200, {})}")
        ep = darwin_episoden([(1000, "a", "X", "Open Long*", 1, 4000, 1), (1100, "a", "X", "Open Long*", 1, 4000, 2), (1150, "a", "X", "Close Long", 1, 8000, 3),
                              (1200, "a", "X", "Open Long*", 1, 6000, 4), (1250, "a", "X", "Close Long", 1, 300, 5), (1300, "a", "X", "Open Long*", 1, 5000, 6),
                              (2000, "a", "X", "Close Long", 1, 3000, 7), (2100, "a", "X", "Close Long", 1, 3000, 8), (4000, "a", "X", "Open Long*", 1, 12000, 9)])
        ok("Darwin-Nachrechnung: netto, halbe Schließung, neue Eröffnung", [(e["ts"], e["n"], round(e["usd"]), e["aus"]) for e in ep] == [(1300, 2, 10700, 2100), (4000, 1, 12000, None)],
           f"{[(e['ts'], e['n'], round(e['usd']), e['aus']) for e in ep]} (Soll: 1300 aus 2 Stücken 10,7k, Ausstieg 2100; neu 4000)")
        pt = (p_t_einseitig(3.4, 7), p_t_einseitig(2.0, 1000), p_t_einseitig(-1.0, 10), p_t_einseitig(0.0, 5))
        ok("Student-t: Glück bei wenigen Trades", abs(pt[0] - 0.00572) < 3e-4 and abs(pt[1] - 0.02288) < 3e-4 and abs(pt[2] - 0.8296) < 3e-4 and abs(pt[3] - 0.5) < 1e-9,
           f"t 3,4 bei 8 Trades: {pt[0] * 100:.2f} % (Normalverteilung {0.5 * math.erfc(3.4 / math.sqrt(2)) * 100:.3f} %)")
        # 23.40: Stufen und Trendmaß
        stf = grid_stufen(100.0, 102.0, 0.002, 4, 12); eng = grid_stufen(100.0, 100.5, 0.002, 4, 12); weit = grid_stufen(100.0, 110.0, 0.002, 4, 12)
        rw = random.Random(9); kz = []; lp_ = 0.0
        for i in range(1440):
            lp_ += rw.gauss(0, 0.0005); kz.append((1_790_000_040 + 60 * i, 100 * math.exp(lp_)))
        tr_ = grid_range(kz)["trend"]; tr_auf = grid_range([(t_, c_ * math.exp(0.00004 * i)) for i, (t_, c_) in enumerate(kz)])["trend"]
        ok("Grid: Stufen und Trendmaß", stf and len(stf[0]) == 10 and abs(stf[1] - (1.02 ** (1 / 9) - 1)) < 1e-12 and eng is None and len(weit[0]) == 13
           and abs(tr_) < 2.5 and tr_auf > tr_ + 2 and grid_trend_ok(0.5, {"richtung": "long", "trend_gegen": 1.0, "trend_mit": 2.0})
           and not grid_trend_ok(-1.2, {"richtung": "long", "trend_gegen": 1.0, "trend_mit": 2.0})
           and grid_trend_ok(-1.2, {"richtung": "short", "trend_gegen": 1.0, "trend_mit": 2.0}),
           f"2 % → {len(stf[0]) - 1 if stf else 0} Stufen à {stf[1] * 100 if stf else 0:.3f} %, 0,5 % → zu eng, 10 % → {len(weit[0]) - 1} Stufen; "
           f"Trend Zufallsweg {tr_:+.2f}, mit Drift {tr_auf:+.2f}")
        try:
            _grid_selbsttest(tmp, ok)
        except Exception as e:                                    # ein Absturz der Probe ist ein Befund, kein Abbruch
            import traceback
            ok("Grid: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p[1] for p in pruef)
    if verbose:
        print("TradeLabor -- Selbsttest (synthetischer Markt, fester Zeitpunkt)")
        for name, gut, text in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
        print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


if __name__ == "__main__":
    if "--selbsttest" in sys.argv or "--nulltest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--bericht" in sys.argv:
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv and sys.argv.index("--db") + 1 < len(sys.argv) else None
        print(bericht_text(F.STORE, db=db_))
        sys.exit(0)
    print("Aufruf: hl_labor.py --selbsttest | --bericht [--db PFAD]")
