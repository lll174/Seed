"""
TradeLabor (23.33, Wunsch des Nutzers 27.09.2026): simulierter Handel (Paper-Trading) mit allen verarbeiteten Daten.

Kein echtes Geld, keine Order an eine Börse. Jede Strategie ist ein eigenes simuliertes Konto je Coin. Ihre Regeln werden
beim ersten Start eingefroren (Kennung name@hash der Regeln); jede spätere Änderung ergibt eine neue Kennung, die alte
bleibt mit ihrer Bilanz stehen. Damit ist jedes Ergebnis ein echter Vorwärtstest -- nichts wird rückwirkend angepasst.

Ausführung (bewusst vorsichtig gerechnet):
  Markt-Order   Mitte des 5-s-Orderbuchs (book_summary) plus halber Spread plus Marktauswirkung aus der Buchtiefe
                (kumulierte USD innerhalb 10/25/50/100 bps); ist das Buch älter als 90 s: letzter Minutenschluss mit
                Ersatz-Spread (BTC/ETH 1 bp, sonst 4 bp) und 2 bps Aufschlag
  Limit-Order   gefüllt nur, wenn eine spätere 1-min-Kerze DURCH den Preis läuft (Tief < Limit bzw. Hoch > Limit) oder der
                beste Gegenkurs den Preis unterschreitet; in der Füll-Kerze zählt danach nur noch der Stop
  Gebühren      Taker 0,045 %, Maker 0,015 % (Basisstufe Hyperliquid); Ziel = Maker, Stop, Zeit und Folge-Ausstieg = Taker
  Funding       stündlich aus ctx_bars (Longs zahlen bei positiver Rate, Shorts erhalten sie)
  Stop/Ziel     auf 1-min-Kerzen; liegen beide in derselben Kerze, gilt der Stop; Kurslücke über den Stop hinweg: Ausführung
                zum Eröffnungskurs der Kerze; die Einstiegs-Minute einer Markt-Order wird nicht geprüft (sie lag davor)
  Takt          alle 15 s; ein Signal wird zum Kurs des Taktes ausgeführt, in dem es erkannt wird

23.34 (Nutzer 29.09.):
  XMR           fünfter Coin. XMR läuft auf Hyperliquid als HIP-3-Markt: zur Protokollgebühr kommt der Anteil des Betreibers
                (0–300 %, je Markt eingestellt); angenommen 100 % = doppelte Sätze (GEB_FAKTOR). Jeder Coin zählt ab seinem eigenen
                Start (labor_zustand „coins“) -- die Tagesrendite teilt durch die Kontotage, nicht durch Laufzeit × Coins.
  Statistik     t, „Glück“, Hälften und Stufen auf BLÖCKEN: Trades einer Strategie, die im selben Block ihres Horizonts h eröffnet
                wurden (meist dasselbe Signal in mehreren Coins zugleich), zählen als EINE Beobachtung (ihr Mittel). Vorher zählte
                jeder Coin-Trade einzeln -- vier gleichzeitige Trades auf korrelierten Coins vervierfachten scheinbar den Beleg.
  Darwin v2     Eröffnungen eines Kontos der Darwin-Liste werden je Coin und Seite über 15 min aufsummiert (auch in kleinen Stücken;
                der Recorder sammelt ihre Fills seit 23.34 ohne Mindestbetrag). Vorher zählte nur, was in einem Takt zusammenkam --
                in Stücke unter 10k zerlegte Eröffnungen blieben unsichtbar. Neue Regeln = neue Kennung; die alte Bilanz bleibt stehen.

23.68:
  U160          XMR mit den normalen Sätzen wie BTC und ETH (Entscheidung des Nutzers 13.10.; Messungen ×0,5 und ×0,3). Der Zeitpunkt
                des Wechsels steht im Labor-Zustand („geb_wechsel“); keine neue Kennung, alte Trades behalten ihre Gebühren, ein Trade über
                den Wechsel zahlt beim Einstieg doppelt und beim Ausstieg normal. Die Kostenschwelle der Fusion bleibt bis zum 25.10. doppelt.
  U161          Bericht je Strategie und Coin (XMR vor und nach dem Wechsel getrennt, nach dem Einstieg).
  U163          Grid in USD vergleichbar (nur Anzeige): Tabelle je Coin und Tag aus den Zahlen, mit denen Stufe und t rechnen.
  U164          Swing und Zyklus mit fester Größe 10.000 USD (neues Regelfeld „groesse“: neue Kennungen, die Historie bleibt bitgleich);
                offene Positionen der alten Kennungen werden zum Marktpreis geschlossen („Regelversion abgelöst“).

23.76 (U206, KONZEPT_Notbremse.md):
  Welt A        eine zweite Instanz mit eigenem Speicher (labor_a.db) und dem Tor der Notbremse (hl_notbremse.Tor): jeder Weg zu einer
                neuen oder größeren Long-Position fragt `_tor` -- Markt-Long, Long-Limit setzen und füllen, Grid-Kauf (Startbestand,
                Kauf-Limits, Nachführen), Akkumulation; beim Eintritt in Stufe ≥ 1 werden offene Long-Limits storniert. Schließen,
                Verkleinern und Shorts sind nie gesperrt. Gesperrte Einstiege werden verworfen, nicht nachgeholt. Den Marktzustand E
                rechnet die Welt B; die Welt A bekommt eine Kopie (zyklus(E_von=...)). Welt B (tor None) rechnet unverändert.
"""
import copy
import hashlib
import json
import math
import os
import random
import re
import sqlite3
import sys
import time

import numpy as np

import hl_adressfluss
import hl_forecast as F
import hl_swing as SW
import hl_wende as WE

COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")      # 23.34: XMR dazu (Wunsch 29.09.)
COINS_2333 = ("BTC", "ETH", "ZEC", "HYPE")        # Stand 23.33 -- Übernahme des gemeinsamen Starts bei der Umstellung auf Kontotage
NOTIONAL = 10_000.0              # USD je Trade (Vorschlag 27.09., im Dashboard angezeigt)
GEB_TAKER = 0.00045
GEB_MAKER = 0.00015
TAKT_S = 15
BUCH_MAX_ALTER = 90
KURS_FRISCH_S = 150             # älterer Kurs (Recorder steht?): keine neuen Einstiege, keine Live-Prüfung -- die Minutenkerzen holen nach
PAUSE_S = 900                   # nach einem Ausstieg wartet die Strategie im selben Coin 15 min
HEBEL = (1, 3, 5, 10)
LIQ_SCHWELLE = 0.9              # Hebel-Ansicht: liquidiert, wenn der Rückgang im Trade 90 % der Marge (1/Hebel) erreicht
EREIGNIS_TAGE = 90
ERSATZ_SPREAD_BPS = {"BTC": 1.0, "ETH": 1.0}
SIGMA_ERSATZ = {"BTC": 0.008, "ETH": 0.011, "ZEC": 0.025, "HYPE": 0.02, "XMR": 0.02}
GEB_FAKTOR: dict = {}           # 23.68 (U160): XMR mit den normalen Sätzen wie BTC und ETH -- Messungen 11.10. ×0,5 und 30.09. ×0,3 der
                                # Standard-Perps (zu grob für ×0,5; ×1 ist die vorsichtige Mitte; Entscheidung des Nutzers 13.10.)
GEB_FAKTOR_ALT = {"XMR": 2.0}   # 23.34–23.67: HIP-3-Markt, Protokollgebühr plus Betreiberanteil (0–300 %), angenommen 100 % = doppelt
DARWIN_MIN_USD = 10_000.0
DARWIN_FRISCH_S = 180           # der jüngste Fill einer Eröffnung darf höchstens so alt sein, wenn die Summe die Schwelle erreicht
DARWIN_FENSTER_S = 900          # 23.34: Eröffnungen je Konto, Coin und Seite über 15 min aufsummiert
DARWIN_EPISODE_S = 12 * 3600    # eine erkannte Eröffnung gilt bis zum Schließen, höchstens 12 h (danach darf dasselbe Konto neu auslösen)
DARWIN_AUS_ANTEIL = 0.5         # 23.34: Folge-Ausstieg erst, wenn das Konto mindestens die Hälfte der erkannten Eröffnung wieder schließt
KASKADE_Z = 2.5
KASKADE_FENSTER_S = 3600
FRISCH_S = {"preis": 90, "treiber": 1800, "familie": 1800, "prognose": 1800, "anker": 1800, "docht": 1800, "funding": 900,
            "adressstrom": 300, "kaskade": 120, "staerke": 3600, "darwin": 900, "elite": 900, "sigma": 1800,
            "swing": 26 * 3600}                    # 23.61: Tageskerze von gestern (Schluss 00:00 UTC) gilt bis 02:00 am Folgetag
# 23.40 (Nutzer 01.10.): Grid-Bots -- Long und das Spiegelbild Short, je Coin ein Konto über GRID_KAPITAL, auf die Stufen verteilt
GRID_NAMEN = ("grid_long", "grid_short")
GRID_KAPITAL = NOTIONAL          # 10.000 USD je Coin-Konto (vergleichbar mit „10.000 USD je Trade“ der übrigen Strategien)
GRID_TAG_S = 300                 # Bestandswert für die Tagesbilanz alle 5 min und nach jeder Änderung festhalten
# 23.42 (KONZEPT_Fusion.md, Stufe 1): Fusion mit Kostenschwelle -- eingestiegen wird nur, wenn der erwartete Vorsprung die Kosten eines
# Hin- und Rückwegs zum Marktpreis um diesen Faktor übersteigt (die Hälfte der Kosten als Puffer gegen den Schätzfehler von p)
FUSION_PUFFER = 1.5
# 23.69 (U180): Akkumulation -- nur Kauf, nie Verkauf (KONZEPT_Akkumulation.md)
# 23.70 (U184, Nutzer 19.10. 23:20 und 23:40, vor dem ersten Lauf): 5.000 USD je Kauf; Startkauf (A0) als erster Kauf je Coin, rückwirkend
# ab dem Start des Coins im Labor nachgerechnet (labor_zustand „coins“), damit die Bilanz denselben Zeitraum hat wie die übrigen Strategien
AKKU_USD = 5_000.0
AKKU_GEB = 0.0007                # Hyperliquid Spot, Stufe 0, Taker (Doku, gelesen 19.10.2026); Kassa: kein Hebel, kein Funding
# 23.72 (U186, Nutzer 20.10. 02:43): Korrekturkauf A4 für alle Coins -- ab 7 % unter dem Hoch der letzten 48 h, Nachkauf je weitere 7 % binnen
# 14 Tagen nach dem letzten Korrekturkauf; eigene Spur neben A0–A3 und ohne Sperre (Wahl des Nutzers 20.10.); rückwirkend ab dem Start des
# Coins im Labor, dann live. Die Regel steht in „regeln“, also neue Kennungen (die Bilanz von 23.70/23.71 bleibt als „alte Regeln“).
# 23.74 (U189, Nutzer 20.10. 09:55: „Es soll nur im Falle von äquivalenten Rücksetzern dazu kommen“, „in ZEC sollte eigentlich wesentlich
# weniger investiert werden“; Wahl: nur A4, Faktor fest aus den 365 Tagen vor dem Start, Betrag ÷ Faktor): Faktor gegenüber BTC je Coin
# f = max(1, σ̄_Coin ÷ σ̄_BTC), σ̄ = Wurzel aus dem Mittel der Tages-RV (30 min) der 365 Tage vor dem Start des Coins im Labor, einmal bestimmt
# und gespeichert (labor_akku_faktor); A4-Schwelle 0,93^f, Betrag 5.000 USD ÷ f für jeden Kauf. Neue Regeln → neue Kennungen.
AKKU_REGELN = {"usd": AKKU_USD, "geb": AKKU_GEB, "tiefe": 2.0, "stufe": 1.0, "fenster_tage": 7, "ma_tage": 200, "ma_faktor": 1.2,
               "cluster": True, "cluster_tiefe": 1.0, "cluster_anteil": 0.25, "cluster_naehe": 0.25, "cluster_merken_h": 6,
               "konten": 3.0, "h": 24, "start": True, "korr": 0.07, "korr_h": 48, "korr_tage": 14,
               "faktor_basis": "BTC", "faktor_tage": 365, "faktor_min": 1.0, "faktor_korr": True, "faktor_betrag": True}
AKKU_FAKTOR_MIN_TAGE = 60        # 23.74 (U189): so viele gemeinsame Tage mit gültiger RV braucht der Faktor mindestens
AKKU_FAKTOR_WARTEN_S = 600       # fehlt der Faktor (zu wenige Tage, swing.db fehlt), frühestens nach so vielen Sekunden neu versuchen
AKKU_NAMEN = ("akku", "akku_ohne_cluster")
AKKU_TAG_S = 300                 # Tageszeile alle 5 min und nach jedem Kauf erneuern
AKKU_KONTEN_S = 2 * 3600         # Binance-Konten-Quote höchstens so alt
AKKU_H7_S = 300                  # 7-Tage-Hoch: voller Lauf über die 1-min-Kerzen alle 5 min, dazwischen die jüngsten Kerzen und der Kurs
AKKU_MIN_VERGLEICH = 5
AKKU_ZIEHUNGEN = 2_000
AKKU_SURROGATE = 200
AKKU_HINWEIS = ("Auch ohne jede Vorhersagekraft liegt der Ø Einstand dieser Regel meist etwas unter dem der Zufallszeiten, weil sie nie "
                "nach einem Anstieg kauft (Simulation auf Zufallswegen am 19.10.: Vorteil im Median rund +2 %). Belastbar sind erst der "
                "Rückblick mit Zufallswegen (Debug „Akkumulation: Rückblick“) und der Abstand zur Kontrolle ohne Heatmap. Der Vergleich zählt "
                "nur die Käufe nach den Regeln A1–A3, nicht den Startkauf (sein Zeitpunkt steht fest) und nicht die Korrekturkäufe (eigene Spur "
                "ohne Sperre).")

SCHEMA = """
CREATE TABLE IF NOT EXISTS labor_strategie (sid TEXT PRIMARY KEY, name TEXT, titel TEXT, gruppe TEXT, regeln TEXT, beschreibung TEXT,
    erstellt INTEGER, aktiv INTEGER);
CREATE TABLE IF NOT EXISTS labor_position (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, status TEXT,
    eroeffnet INTEGER, preis_ein REAL, notional REAL, menge REAL, art_ein TEXT, gebuehr_ein REAL, slip_ein REAL,
    sl REAL, tp REAL, ablauf INTEGER, grund TEXT, werte TEXT, folge TEXT, geprueft_bis INTEGER, nur_stop_bis INTEGER,
    funding REAL DEFAULT 0, funding_bis INTEGER, mae_pct REAL DEFAULT 0, mfe_pct REAL DEFAULT 0,
    geschlossen INTEGER, preis_aus REAL, art_aus TEXT, gebuehr_aus REAL, slip_aus REAL, grund_aus TEXT,
    brutto_usd REAL, netto_usd REAL, netto_pct REAL);
CREATE INDEX IF NOT EXISTS ix_lp_offen ON labor_position(status, coin);
CREATE INDEX IF NOT EXISTS ix_lp_zu ON labor_position(geschlossen);
CREATE TABLE IF NOT EXISTS labor_order (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, seite TEXT, preis REAL,
    erstellt INTEGER, gueltig_bis INTEGER, status TEXT, grund TEXT, werte TEXT, sl_rel REAL, tp_rel REAL, sl_px REAL, tp_px REAL,
    halten_s INTEGER, geprueft_bis INTEGER, erledigt INTEGER, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_lo_offen ON labor_order(status, coin);
CREATE TABLE IF NOT EXISTS labor_ereignis (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, sid TEXT, coin TEXT, art TEXT,
    seite TEXT, preis REAL, text TEXT, netto_usd REAL, pos_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_le_ts ON labor_ereignis(ts);
CREATE TABLE IF NOT EXISTS labor_zustand (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS labor_grid_tag (sid TEXT, coin TEXT, tag INTEGER, unreal REAL, lose INTEGER, px REAL, ts INTEGER,
    PRIMARY KEY (sid, coin, tag));
CREATE INDEX IF NOT EXISTS ix_lp_sid ON labor_position(sid, status);
CREATE TABLE IF NOT EXISTS labor_akku_kauf (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT, coin TEXT, ts INTEGER, ausloeser TEXT,
    preis REAL, mitte REAL, usd REAL, menge REAL, gebuehr REAL, slip_bps REAL, grund TEXT, werte TEXT);
CREATE INDEX IF NOT EXISTS ix_lak ON labor_akku_kauf(sid, coin, ts);
CREATE TABLE IF NOT EXISTS labor_akku_tag (sid TEXT, coin TEXT, tag INTEGER, eingesetzt REAL, menge REAL, wert REAL, px REAL, n INTEGER,
    ts INTEGER, PRIMARY KEY (sid, coin, tag));
CREATE TABLE IF NOT EXISTS labor_akku_faktor (sid TEXT, coin TEXT, faktor REAL, roh REAL, sigma REAL, sigma_basis REAL, n INTEGER,
    von INTEGER, bis INTEGER, start INTEGER, ts INTEGER, PRIMARY KEY (sid, coin));
"""


# ------------------------------------------------------------------------------------------------ Strategien
SWING_GEMEINSAM = (" Größe: 10.000 USD je Trade wie alle Strategien (seit 23.68, U164; bis dahin 100 USD Risiko bis zum Stop); das Risiko bis "
                   "zum Stop ist damit 10.000 USD × Stop-Abstand, R = netto ÷ dieses Risiko. Entscheidung am Tagesschluss 00:00 UTC aus den "
                   "Tageskerzen in swing.db (Binance), Einstieg höchstens 6 h danach; Stops laufen jederzeit auf den Hyperliquid-Minutenkerzen.")
SWING_TEXTE = (
    ("swing_trend", "Swing: Trend-Ausbruch",
     "Schluss über dem höchsten Hoch der 20 Tage davor → Long, unter dem tiefsten Tief → Short; Stop 2 σ_Tag, Nachzieh-Stop 3 σ_Tag vom "
     "besten Schluss; Ausstieg bei Schluss unter dem 10-Tage-Tief (Short: über dem Hoch), spätestens nach 30 Tagen."),
    ("swing_ruecksetzer", "Swing: Rücksetzer im Trend",
     "Im Aufwärtstrend (20-Tage-Mittel über 50-Tage-Mittel, Schluss darüber) nach einem Rücksetzer um mindestens 2 σ_Tag unter den "
     "höchsten Schluss der letzten 10 Tage → Long; Abwärtstrend gespiegelt. Stop 2 σ_Tag, Ziel das 10-Tage-Hoch (mindestens 1,5 σ_Tag), "
     "spätestens nach 10 Tagen -- die Idee „höhere Tiefs“ des Nutzers."),
    ("swing_kompression", "Swing: Ausbruch nach Ruhe",
     "Nach Ruhe (Schwankung der letzten 10 Tage im untersten Fünftel der 250 Tage davor) Schluss über dem 10-Tage-Hoch → Long, unter dem "
     "Tief → Short; Stop 1,5 σ_Tag, Nachzieh-Stop 3 σ_Tag, spätestens nach 20 Tagen."),
    ("swing_gegenbewegung", "Swing: Gegenbewegung nach Übertreibung",
     "3-Tage-Rendite mindestens 2,5 σ (√3-skaliert) gegen eine Seite, deren Funding um mindestens 1 Standardabweichung über dem "
     "30-Tage-Mittel drängt → Gegenrichtung; Stop 2 σ_Tag, Ziel halber Rücklauf (mindestens 1 σ_Tag), spätestens nach 5 Tagen."),
    ("swing_zufall", "Swing: Zufall (Kontrolle)",
     "An jedem Tag ohne Position mit 10 % Einstieg, Richtung zufällig; Ausstiege wie „Trend-Ausbruch“ -- zeigt, was Kosten, Funding und "
     "die Ausstiegsregeln allein bringen."),
    ("swing_ruecksetzer_zufall", "Swing: Zufall im Trend (Kontrolle)",
     "An Tagen mit dem Trend von „Rücksetzer im Trend“ (gleiche Richtung) mit 10 % Einstieg, ohne Rücksetzer-Bedingung; Ausstiege wie "
     "dort -- die Differenz zeigt, was der Zeitpunkt des Rücksetzers bringt."),
    # 23.62 (U141, KONZEPT_Zyklen.md 5 und 7; Nutzer 08.10. 23:45: „wenn ein Dump bestätigt ist, kaufen … laufen lassen … vor dem nächsten
    # Rücksetzer raus“): dieselben Regeln wie die lange Studie in hl_zyklus.py (dort auf den Tagesschlüssen seit 2013)
    ("zyklus_dip", "Zyklus: Dip halten (Z1)",
     "Nach einem Dump (höchster Schluss der 20 Tage bis zum Tief mindestens 5 σ_Tag über dem tiefsten Schluss der 10 Tage davor), bestätigt "
     "durch eine Erholung um mindestens 1 σ_Tag bei noch mindestens 1 σ_Tag Abstand zum Hoch → Long; Stop 1 σ_Tag unter dem Tief, "
     "Nachzieh-Stop 3 σ_Tag unter dem besten Schluss ab dem Folgetag, spätestens nach 60 Tagen -- die Idee des Nutzers „Dump bestätigt, "
     "kaufen, laufen lassen, vor dem nächsten Rücksetzer raus“."),
    ("zyklus_dip_heiss", "Zyklus: Dip halten, raus bei Überhitzung (Z2)",
     "Wie „Dip halten“, zusätzlich Ausstieg am Tagesschluss, sobald der RSI(14) der Tagesschlüsse 80 erreicht oder das Funding mindestens "
     "2 Standardabweichungen über seinem 30-Tage-Mittel liegt -- prüft die Überhitzungs-Signale als Ausstieg."),
    ("zyklus_dip_zufall", "Zyklus: Zufall long (Kontrolle)",
     "An jedem Tag ohne Position mit 3 % Einstieg, immer Long; Stop und Ausstiege wie „Dip halten“ (Stop 1 σ_Tag unter dem tiefsten Schluss "
     "der 10 Tage davor) -- die Differenz zeigt, was der Zeitpunkt nach dem Dump bringt."),
)


# 23.83 (U226, KONZEPT_Wende.md 5): die Strategie aus dem Video „Range Deviation plus Ribbon Flip“ (Nutzer 25.10. 09:47 „baue diese
# Strategie nach“; Wahl „Studie und gleich ins Labor“, „Eine Hauptregel“ = Ziel 1R, „Nur BTC 8h“)
WENDE_TEXT = ("Nur BTC, 8-h-Kerzen (UTC 00/08/16) aus swing.db (Binance). Rot: Hoch unter den höchsten 10 % der 765 Kerzen bis zur "
              "Flip-Kerze, blau: Tief unter den tiefsten 10 %. Flip: EMA 8 kreuzt EMA 89 (Schlüsse). Short: seit dem letzten bullischen "
              "Flip mindestens eine rote Kerze, dann bärischer Flip → Short zum Marktpreis höchstens 60 min nach dem Schluss, Stop 0,1 % über "
              "dem höchsten Hoch der roten Kerzen, Ziel 1R (Einstieg minus Stop-Abstand); Long gespiegelt. Spätestens nach 120 Tagen zum "
              "Markt. Größe 10.000 USD wie alle Swing-Strategien, R = netto ÷ (10.000 USD × Stop-Abstand). Ein Signal während einer offenen "
              "Position entfällt. ")
WENDE_LESART = {"rang": "Lesart Rang: „höchste 10 %“ = Hoch ab dem 90-%-Quantil der Hochs im Fenster (Tief bis zum 10-%-Quantil).",
                "spanne": "Lesart Spanne: „höchste 10 %“ = Hoch im obersten Zehntel der Spanne vom tiefsten Tief bis zum höchsten Hoch "
                          "im Fenster (Tief im untersten Zehntel)."}
WENDE_HINWEIS = (" Das Video lässt die Lesart offen; beide laufen, welche die Video-Strategie ist, entscheidet die Studie (Debug „★ Wende“, "
                 "Nachrechnen der sechs Video-Trades).")


def _gen(name, titel, gruppe, fn, regeln, eingaben, beschreibung):
    return {"name": name, "titel": titel, "gruppe": gruppe, "fn": fn, "regeln": dict(regeln, v=1), "eingaben": eingaben,
            "beschreibung": beschreibung}


AKKU_TEXT = ("Nur Kauf, nie Verkauf: je Kauf 5.000 USD ÷ Faktor gegenüber BTC zum Marktpreis als Spot-Kauf (BTC 5.000 USD; Gebühr 0,07 % "
             "einmal beim Kauf; kein Hebel, kein Funding, keine Kosten beim Halten), Kapital ohne Obergrenze, je Coin eine eigene Bilanz. Faktor "
             "(seit 23.74): Schwankung des Coins (σ_Tag, Wurzel aus dem Mittel der Tages-RV) geteilt durch die von BTC in den 365 Tagen vor seinem "
             "Start im TradeLabor, mindestens 1, einmal bestimmt und dann fest. Startkauf (A0): der erste Kauf je Coin "
             "sofort -- rückwirkend ab dem Start des Coins im TradeLabor auf den 1-min-Kerzen nachgerechnet, damit die Bilanz denselben Zeitraum "
             "hat wie die übrigen Strategien. Rücksetzer (A1): Kurs mindestens 2 σ₇ unter dem höchsten Kurs der letzten 7 Tage (σ₇ = σ_Tag · √7) "
             "und in den 7 Tagen davor kein Kauf. Nachkauf (A3): binnen 7 Tagen nach einem Kauf je weiteres σ₇ unter dem letzten Kaufpreis. "
             "Sperre: kein Kauf (auch kein Startkauf), solange der Kurs 20 % oder mehr über der 200-Tage-Linie liegt. Korrektur (A4, seit "
             "23.72, eigene Spur ohne Sperre): liegt der Kurs 7 % (bei BTC; seit 23.74 bei den übrigen Coins 0,93 hoch Faktor, also gleich "
             "viele σ) unter dem höchsten Kurs der letzten 48 Stunden, kauft sie; binnen 14 Tagen nach einem Korrekturkauf kauft sie je "
             "dieselbe Stufe darunter nach. Derselbe Einbruch kauft nur einmal (das 48-Stunden-Hoch zählt erst ab dem letzten "
             "Korrekturkauf); rückwirkend ab dem Start des Coins im TradeLabor nachgerechnet.")
AKKU_TEXT_CLUSTER = (" Heatmap (A2): liegt der Kurs schon ein σ₇ unter dem 7-Tage-Hoch und kommt an ein heißes Long-Liquidationscluster "
                     "heran (mindestens 25 % des Stundenvolumens, 0,5–3 σ(4 h) unter dem Kurs, bis 6 h gemerkt; Kurs höchstens 0,25 σ(1 h) "
                     "darüber), kauft sie dort schon früher -- außer die Binance-Konten-Quote steht bei 3 oder höher (U142 H1: Rücksetzer "
                     "dann 2,8-mal so häufig); dann wartet sie auf den vollen Rücksetzer.")
AKKU_TEXT_KONTROLLE = " Kontrolle ohne Heatmap-Regel: zeigt, was die Cluster-Käufe bringen."


def strategien() -> list:
    """Die eingefrorenen Strategien. Jede Änderung an „regeln“ ergibt eine neue Kennung (neue Bilanz)."""
    S = []
    std = {"sl": 1.5, "tp": 2.0}
    for key, titel, treiber, h in (("wale", "Wale", "Wal-Flow 30 min", 4), ("leaderboard", "Leaderboard", "Leaderboard-Flow 60 min", 4),
                                   ("smartmoney", "Smart Money", "Smart Money (direktional)", 12), ("pool", "Pool", "Pool-Flow 4 h", 4)):
        for inv in (False, True):
            S.append(_gen(f"{key}_{'gegen' if inv else 'folgen'}", (f"Gegen {titel}" if inv else f"{titel} folgen"), "Händler", "schwelle",
                          dict(std, quelle="treiber", schluessel=treiber, schwelle=0.5, h=h, invert=inv), [f"treiber:{treiber}"],
                          f"Treiber „{treiber}“ ≥ +0,5 → {'Short' if inv else 'Long'}, ≤ −0,5 → {'Long' if inv else 'Short'}; "
                          f"Stop 1,5 σ, Ziel 2 σ, spätestens nach {h} h"))
    for inv in (False, True):
        # 23.34 (Darwin v2): fenster_s -- Eröffnungen über 15 min aufsummiert (neue Kennung; v1 zählte nur, was in einem Takt zusammenkam)
        # 23.37: liste=2 -- die Liste entsteht nach den Regeln v2 (Aufnahme streng, Verbleib großzügig, 14 T); neue Kennung, damit die
        # Bilanz nicht zwei verschiedene Listen vermischt. 23.38: liste=3 -- Regeln v3 (die Schonung nur nach strenger Aufnahme; beim
        # Umstieg fliegen Altbestand und Rückkehrer ohne sie), wieder eine neue Kennung
        S.append(_gen(f"darwin_{'gegen' if inv else 'folgen'}", "Gegen die Darwin-Liste" if inv else "Darwin-Liste live folgen", "Händler",
                      "darwin", dict(std, h=12, min_usd=DARWIN_MIN_USD, invert=inv, fenster_s=DARWIN_FENSTER_S, aus_anteil=DARWIN_AUS_ANTEIL, liste=3), ["darwin"],
                      f"Eröffnet ein Konto der Darwin-Liste im Coin netto mindestens {DARWIN_MIN_USD / 1e3:.0f}k binnen {DARWIN_FENSTER_S // 60} min "
                      f"(auch in kleinen Stücken; Schließungen dazwischen ziehen ab; der jüngste Fill höchstens {DARWIN_FRISCH_S // 60} min alt), "
                      f"{'handeln wir dagegen' if inv else 'handeln wir mit'}; je Eröffnung einmal. Ausstieg, wenn das Konto mindestens die Hälfte "
                      "davon wieder schließt, sonst Stop 1,5 σ, Ziel 2 σ, spätestens nach 12 h. Liste nach den Regeln v3 (23.38)"))
    for inv in (False, True):
        # 23.39 (Nutzer 30.09.: „Elite und Aktive Profis als Vorlage vergleichen“): die Elite des Coins als Vorlage -- dieselbe Kopier-Regel
        # wie bei der Darwin-Liste, damit die beiden Vorlagen vergleichbar sind. Unterschied: Fills der Elite liegen erst ab 2.500 USD vor
        # (Stream), die der Darwin-Liste auch darunter
        S.append(_gen(f"elite_{'gegen' if inv else 'folgen'}", "Gegen die Elite" if inv else "Elite live folgen", "Händler",
                      "elite", dict(std, h=12, min_usd=DARWIN_MIN_USD, invert=inv, fenster_s=DARWIN_FENSTER_S, aus_anteil=DARWIN_AUS_ANTEIL), ["elite"],
                      f"Eröffnet ein Konto der Elite dieses Coins (Konto-Score mit belegtem 4-h-Vorlauf, Gewinn- und Aktivitätsschranke, ohne "
                      f"Gesperrte; das Dashboard stellt sie täglich neu auf) im Coin netto mindestens {DARWIN_MIN_USD / 1e3:.0f}k binnen "
                      f"{DARWIN_FENSTER_S // 60} min (Fills ab 2.500 USD; der jüngste höchstens {DARWIN_FRISCH_S // 60} min alt), "
                      f"{'handeln wir dagegen' if inv else 'handeln wir mit'}; je Eröffnung einmal. Ausstieg, wenn das Konto mindestens die Hälfte "
                      "davon wieder schließt, sonst Stop 1,5 σ, Ziel 2 σ, spätestens nach 12 h -- dieselbe Regel wie „Darwin-Liste live folgen“"))
    S.append(_gen("prognose_v1", "Prognose v1", "Prognose", "prognose", dict(std, feld="p_up_v1", schwelle=0.08, h=4), ["prognose"],
                  "P(aufwärts 4 h) der Kalibrierung v1 ≥ 58 % → Long, ≤ 42 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("prognose_v2", "Prognose v2", "Prognose", "prognose", dict(std, feld="p_up_v2", schwelle=0.10, h=4), ["prognose"],
                  "P(aufwärts 4 h) des korrigierten v2 (Version ≥ 2) ≥ 60 % → Long, ≤ 40 % → Short; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    # 23.42 (KONZEPT_Fusion.md): die Fusionsprognose -- einmal mit der festen Schwelle von v1, einmal mit der Kostenschwelle. So zeigt der
    # Vergleich beider an DERSELBEN Prognose, was der Kostenfilter bringt
    S.append(_gen("prognose_fusion", "Prognose Fusion", "Prognose", "prognose", dict(std, feld="p_fusion", schwelle=0.08, h=4), ["prognose"],
                  "P(aufwärts 4 h) der Fusionsprognose (Mischung aus Basisrate, v1, v2, v3 und Analog-Suche; hl_fusion) ≥ 58 % → Long, ≤ 42 % → "
                  "Short; Stop 1,5 σ, Ziel 2 σ, 4 h -- dieselbe Schwelle wie „Prognose v1“"))
    S.append(_gen("prognose_fusion_kosten", "Fusion mit Kostenschwelle", "Prognose", "fusion", dict(std, feld="p_fusion", h=4, puffer=FUSION_PUFFER),
                  ["prognose"],
                  "Erwarteter Vorsprung |2p − 1| · E|r 4 h| (p = Fusionsprognose, E|r| = mittlere 4-h-Bewegung des Coins in den letzten 30 Tagen) "
                  "mindestens das 1,5-Fache der Kosten eines Hin- und Rückwegs zum Marktpreis (Taker-Gebühr beider Seiten plus Abstand zur "
                  "Buchmitte bei 10.000 USD, aus dem Buch im Takt) → in Richtung der Prognose; Stop 1,5 σ, Ziel 2 σ, 4 h"))
    S.append(_gen("empfehlung_limit", "Kauf-/Verkaufspreise der Prognose", "Prognose", "empfehlung", {"h": 12, "sl": 1.5}, ["prognose"],
                  "Bias ≥ +0,12: Kauf-Limit am empfohlenen Kaufpreis, Ziel am Verkaufspreis; Bias ≤ −0,12 umgekehrt; "
                  "Order 12 h gültig, Stop 1,5 σ(12 h), spätestens 12 h nach der Füllung"))
    for key, fam in (("grosskonten", "Großkonten-Fluss"), ("trend", "Trend lang"), ("momentum", "Momentum kurz"), ("orderfluss", "Orderfluss"),
                     ("funding", "Funding"), ("etf", "ETF"), ("analog", "Analog"), ("pool", "Pool-Konten"), ("profi", "Profi-Flow")):
        h = {"Trend lang": 24, "Momentum kurz": 1, "Orderfluss": 1, "Funding": 24, "ETF": 24, "Analog": 24}.get(fam, 4)
        S.append(_gen(f"familie_{key}", f"Familie {fam}", "Familien", "schwelle",
                      dict(std, quelle="familie", schluessel=fam, schwelle=0.35, h=h, invert=False), [f"familie:{fam}"],
                      f"Familienwert „{fam}“ ≥ +0,35 → Long, ≤ −0,35 → Short; Stop 1,5 σ, Ziel 2 σ, {h} h"))
    S.append(_gen("kaskade_umkehr", "Kaskaden-Umkehr", "Ereignisse", "kaskade", {"modus": "umkehr", "h": 4}, ["kaskade"],
                  f"Nach einer Kaskade (Kurs ≥ {KASKADE_Z:g} σ in 15 min und Liquidationen über dem 95.-Perzentil der Woche): erste "
                  "Gegenkerze binnen 30 min → Einstieg gegen die Bewegung; Stop 0,5 σ(15 min) hinter dem Extrem, Ziel halber Rücklauf, 4 h"))
    S.append(_gen("kaskade_fortsetzung", "Kaskaden-Fortsetzung", "Ereignisse", "kaskade", {"modus": "fortsetzung", "h": 2}, ["kaskade"],
                  "Dieselbe Erkennung, Einstieg sofort IN Richtung der Bewegung; Stop 1 σ(1 h), Ziel 1,5 σ(1 h), 2 h"))
    S.append(_gen("docht_fangen", "Docht fangen", "Ereignisse", "docht", {"h": 6, "abstand": 0.25, "sl": 1.0, "tp": 1.0, "min_anteil": 0.10},
                  ["docht"], "Limit-Order 0,25 σ(1 h) jenseits des nächsten großen Liquidationsclusters (ab 10 % des Stundenvolumens, "
                  "0,5–3 σ entfernt), 4 h gültig; Ziel und Stop je 1 σ(1 h), spätestens 6 h nach der Füllung"))
    S.append(_gen("magnet", "Magnet", "Ereignisse", "magnet", {"h": 12, "a_min": 0.5, "min_anteil": 0.10}, ["anker"],
                  "Heatmap-Anker |A| ≥ 0,5 mit Cluster ab 10 % des Stundenvolumens 0,5–2 σ entfernt → Einstieg Richtung Cluster, "
                  "Ziel knapp davor, Stop 1 σ(4 h), 12 h"))
    # 23.43 (KONZEPT_Fusion.md, Stufe 2b): die Kaskaden-Gleichung als Handelsregel -- prüft, ob die berechnete Reichweite trägt
    S.append(_gen("kaskade_kipppunkt", "Kaskaden-Kipppunkt", "Ereignisse", "kipppunkt", {"h": 2, "puffer": FUSION_PUFFER, "sl": 0.5}, ["prognose"],
                  "Kaskaden-Gleichung (hl_kaskade): Fällt der Kurs durch den unteren Kipppunkt (kleinster Rutsch, ab dem die Kaskade nach dem "
                  "Wurzelgesetz mindestens 0,5 σ(4 h) weiter trägt), Short bis zum berechneten Ende; steigt er durch den oberen, Long. Nur wenn der "
                  "Weg zum Ende mindestens das 1,5-Fache der Kosten zum Marktpreis ist; Stop 0,5 σ(1 h) hinter dem Kipppunkt, spätestens nach 2 h; "
                  "je Kipppunkt einmal"))
    S.append(_gen("funding_extrem", "Funding-Extrem", "Ereignisse", "funding", dict(std, z=2.0, h=24), ["funding"],
                  "Funding-Rate ≥ 2 Standardabweichungen über ihrem 14-Tage-Mittel → Short, ebenso weit darunter → Long; "
                  "Stop 1,5 σ, Ziel 2 σ, 24 h"))
    S.append(_gen("ausbruch_ruhe", "Ausbruch nach Ruhe", "Ereignisse", "ausbruch", {"h": 8, "schwelle": 0.5}, ["staerke"],
                  "Stärke ≥ 0,5 (Ruhe vor dem Sturm) macht scharf; läuft der Kurs binnen 4 h 1 σ(1 h) weg, Einstieg in diese Richtung; "
                  "Stop am Ausgangspunkt, Ziel 2,5 σ(1 h), 8 h"))
    S.append(_gen("twap_druck", "TWAP-Druck", "Ereignisse", "twap", dict(std, anteil=0.02, h=4), ["adressstrom"],
                  "Netto-Fluss laufender TWAP-Aufträge der letzten 60 min ≥ 2 % des Stundenvolumens → in dieselbe Richtung; "
                  "Stop 1,5 σ, Ziel 2 σ, 4 h (wartet, bis TWAP-Trades im Adress-Strom erkannt werden)"))
    # 23.40 (Nutzer 01.10.): Grid-Bot -- Range automatisch erkennen und nachführen, eine starke Bewegung in Gewinnrichtung aussitzen statt
    # zu früh zu verkaufen (Trailing-Stop vom Extrem), Notausstieg bei starker Bewegung dagegen; Long und das Spiegelbild Short.
    # Alle Lose eines Coins teilen sich GRID_KAPITAL; bewertet wird je Tag nach Bestandswert (grid_tage), nicht nur realisiert.
    # Probe (synthetischer Markt): Ein Auslöser nur über 15 min kam in einer schnellen Rallye zu spät -- ein enges Grid hatte seinen Bestand
    # schon auf den Stufen verkauft; deshalb zusätzlich 5 min. Ein Trendmaß ohne Richtung ließ Grid Long dreimal in einen langsamen
    # Abwärtstrend hinein aufbauen (jedes Mal Notausstieg); deshalb streng gegen das Grid (1), großzügig mit ihm (2), und längere Pausen
    # nach wiederholten Notausstiegen.
    grid = {"fenster_h": 24, "p_rand": 0.10, "trend_gegen": 1.0, "trend_mit": 2.0, "zone": 0.20, "stufen_min": 4, "stufen_max": 12,
            "schritt_min": 0.002, "pruef_min": 60, "verschiebung": 1.0, "breite_rel": 0.25, "startbestand": True, "bewegung_z": 3.0,
            "z_fenster_min": [5, 15], "trail": 1.5, "puffer": 1.0, "pause_notaus_h": [4, 12, 24], "pause_trail_h": 2, "kapital": GRID_KAPITAL,
            "h": 24}
    kap = f"{GRID_KAPITAL:,.0f}".replace(",", ".")
    gemeinsam = ("Range aus den 1-min-Kursen der letzten 24 h (10.–90. Perzentil). Start und Nachführen nur ohne Trend gegen das Grid: "
                 "Netto-Bewegung im Fenster höchstens 1-mal ihre eigene Schwankung dagegen und 2-mal in Grid-Richtung; Start nur mit dem Kurs im "
                 f"mittleren Teil der Range. 4–12 Stufen, je mindestens 0,2 % Abstand; {kap} USD je Coin gleichmäßig auf die Stufen verteilt. "
                 "Stündlich nachgeführt, wenn sich die Range um eine Stufe verschiebt oder ihre Breite um ein Viertel ändert. Nach einem "
                 "Notausstieg 4 h Pause, nach dem zweiten binnen 24 h 12 h, nach dem dritten 24 h; die neue Range nur aus Kursen danach. ")
    S.append(_gen("grid_long", "Grid Long", "Grid", "grid", dict(grid, richtung="long"), ["grid", "kaskade"],
                  gemeinsam + "Startbestand: Lose für die Stufen über dem Kurs zum Marktpreis, darunter Kauf-Limits; jedes Los verkauft eine Stufe "
                  "höher (Maker), danach liegt dort wieder ein Kauf-Limit. Starke Bewegung aufwärts (≥ 3 σ in 5 oder 15 min in der oberen Hälfte "
                  "der Range, Short-Squeeze, Kurs eine Stufe über der Range): Verkäufe aussetzen, alle Lose halten, Trailing-Stop 1,5 σ(1 h) unter "
                  "dem höchsten Hoch; danach 2 h Pause. Notausstieg (alle Lose zum Marktpreis): Liquidationskaskade abwärts, ≥ 3 σ Fall in 15 min "
                  "in der unteren Hälfte der Range oder Kurs eine Stufe unter der Range"))
    S.append(_gen("grid_short", "Grid Short", "Grid", "grid", dict(grid, richtung="short"), ["grid", "kaskade"],
                  gemeinsam + "Spiegelbild von „Grid Long“: Startbestand Short-Lose für die Stufen unter dem Kurs, darüber Verkaufs-Limits; jedes Los "
                  "kauft eine Stufe tiefer zurück (Maker), danach liegt dort wieder ein Verkaufs-Limit. Starke Bewegung abwärts (≥ 3 σ in 5 oder "
                  "15 min in der unteren Hälfte der Range, Long-Kaskade, Kurs eine Stufe unter der Range): Rückkäufe aussetzen, alle Lose halten, "
                  "Trailing-Stop 1,5 σ(1 h) über dem tiefsten Tief; danach 2 h Pause. Notausstieg: Short-Squeeze, ≥ 3 σ Anstieg in 15 min in der "
                  "oberen Hälfte der Range oder Kurs eine Stufe über der Range"))
    # 23.61 (U140, Nutzer 08.10. 07:20: „Swing-Trades in das System inkludieren … mehrere bestmögliche Strategien ins TradeLabor“):
    # Regeln aus hl_swing.STRATEGIEN (KONZEPT_Swing.md 4), dieselben Funktionen wie die Vorprüfung auf der Historie. Entscheidung einmal
    # je Tag nach dem Tagesschluss 00:00 UTC aus swing.db (Binance-Kerzen), Ausführung hier auf Hyperliquid. h = 24: Blöcke je Tag
    # (gleichzeitige Einstiege in mehreren Coins zählen einmal). 23.68 (U164): „groesse“: „fest“ -- 10.000 USD je Trade wie alle (vorher
    # 100 USD Risiko bis zum Stop); das Feld steht nur hier, nicht in hl_swing.STRATEGIEN: die Historie bleibt bitgleich, neue Kennungen.
    for name, titel, text in SWING_TEXTE:
        S.append(_gen(name, titel, "Swing", "swing", dict(SW.STRATEGIEN[name], h=24, groesse="fest"), ["swing"], text + SWING_GEMEINSAM))
    # 23.83 (U226): Extrem-Wende nach Video -- Regeln aus hl_wende.REGELN (dieselben Funktionen wie die Studie), Lesart je Strategie
    for name, titel, lesart in (("wende_rang", "Swing: Extrem-Wende 8 h (Video), Lesart Rang", "rang"),
                                ("wende_spanne", "Swing: Extrem-Wende 8 h (Video), Lesart Spanne", "spanne")):
        S.append(_gen(name, titel, "Swing", "wende", dict(WE.REGELN, lesart=lesart, h=8, groesse="fest"), ["wende"],
                      WENDE_TEXT + WENDE_LESART[lesart] + WENDE_HINWEIS))
    # 23.69 (U180, Nutzer 19.10. 20:22): Akkumulation -- nur Kauf, nie Verkauf; je Coin eine Bilanz (labor_akku_kauf), eigener Reiter.
    # Die Kontrolle ohne Heatmap misst, was die Cluster-Käufe bringen (KONZEPT_Akkumulation.md)
    S.append(_gen("akku", "Akkumulation", "Akkumulation", "akku", dict(AKKU_REGELN), ["akku", "docht", "swing"],
                  AKKU_TEXT + AKKU_TEXT_CLUSTER))
    S.append(_gen("akku_ohne_cluster", "Akkumulation ohne Heatmap (Kontrolle)", "Akkumulation", "akku", dict(AKKU_REGELN, cluster=False),
                  ["akku", "swing"], AKKU_TEXT + AKKU_TEXT_KONTROLLE))
    S.append(_gen("zufall", "Zufall (Kontrolle)", "Kontrolle", "zufall", dict(std, h=4, rate_h=8), [],
                  "Zufälliger Einstieg (im Schnitt alle 8 h, wenn flach), zufällige Richtung; Stop 1,5 σ, Ziel 2 σ, 4 h -- zeigt, "
                  "was Gebühren und Zufall kosten"))
    S.append(_gen("halten_long", "Halten Long (Vergleich)", "Kontrolle", "halten", {"h": 168}, [],
                  "Immer Long, alle 7 Tage neu eröffnet -- zeigt, was der Markt ohne jedes Signal gebracht hat"))
    for s in S:
        s["sid"] = s["name"] + "@" + hashlib.sha1(json.dumps(s["regeln"], sort_keys=True).encode()).hexdigest()[:8]
    return S


# ------------------------------------------------------------------------------------------------ Hilfen
def _j(x):
    return json.dumps(x, separators=(",", ":"), ensure_ascii=False, default=float)


def schema(st) -> None:
    st.executescript(SCHEMA)


def gebuehr(coin: str, satz: float) -> float:
    """Gebührensatz eines Coins: Grundsatz (Taker/Maker) mal GEB_FAKTOR (23.34–23.67: XMR doppelt; seit 23.68 für alle Coins ×1, U160)."""
    return satz * GEB_FAKTOR.get(coin, 1.0)


def geb_wechsel(st) -> dict | None:
    """23.68 (U160): Wechsel der Gebühren-Annahme je Coin {coin: {"vorher", "jetzt", "ab"}} aus dem Labor-Zustand, sonst None."""
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='geb_wechsel'").fetchone()
        w = json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError):
        return None
    return w if isinstance(w, dict) and w else None


def _faktor_txt(x) -> str:
    return f"×{float(x):.1f}".replace(".", ",")


def geb_wechsel_text(w: dict | None) -> str:
    """„XMR seit 17.10.2026 10:00 ×1,0 (vorher ×2,0)“ -- für Bericht, Gebühren-Prüfung und Dashboard."""
    if not w:
        return ""
    return "; ".join(f"{c} seit {time.strftime('%d.%m.%Y %H:%M', time.localtime(int(v.get('ab', 0))))} {_faktor_txt(v.get('jetzt', 1.0))} "
                     f"(vorher {_faktor_txt(v.get('vorher', 1.0))})" for c, v in sorted(w.items()))


def _gegen(seite: str) -> str:
    return "short" if seite == "long" else "long"


def _uhr(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(ts)) if ts else "—"


def _auswirkung_bps(notional: float, halb_bps: float, baender: list) -> float:
    """Mittlerer Abstand zur Buchmitte in bps für eine Markt-Order: der erste Dollar am besten Kurs (halber Spread), danach
    steigt der Preis linear durch die kumulierten Tiefenbänder (USD innerhalb 10/25/50/100 bps); jenseits pauschal 150 bps."""
    b_prev, d_prev, summe, rest = max(halb_bps, 0.0), 0.0, 0.0, notional
    for b, d in baender:
        if d is None or d <= d_prev or b <= b_prev:
            continue
        seg = d - d_prev; nimm = min(rest, seg)
        summe += nimm * (b_prev + (b - b_prev) * (nimm / seg) / 2)
        rest -= nimm
        if rest <= 1e-9:
            break
        b_prev, d_prev = b, d
    if rest > 1e-9:
        summe += rest * max(150.0, b_prev)
    return summe / notional if notional > 0 else halb_bps


def taker_preis(b: dict, kauf: bool, notional: float) -> tuple:
    """(Ausführungspreis, Abstand zur Mitte in bps) einer Markt-Order."""
    halb = max(float(b.get("spread_bps") or 0.0), 0.0) / 2
    baender = b.get("kauf" if kauf else "verkauf") or []
    bps = _auswirkung_bps(notional, halb, baender) if baender else halb + 2.0
    return (b["mid"] * (1 + bps / 1e4) if kauf else b["mid"] * (1 - bps / 1e4)), bps


def buch_jetzt(con, coin: str, now: int):
    try:
        r = con.execute("SELECT ts, bid, ask, spread_bps, bid_10, ask_10, bid_25, ask_25, bid_50, ask_50, bid_100, ask_100 "
                        "FROM book_summary WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - BUCH_MAX_ALTER, now, coin)).fetchone()
    except sqlite3.Error:
        r = None
    if r and r[1] and r[2] and r[2] >= r[1]:
        bid, ask = float(r[1]), float(r[2]); mid = (bid + ask) / 2
        sp = float(r[3]) if r[3] is not None else (ask - bid) / mid * 1e4
        return {"ts": int(r[0]), "bid": bid, "ask": ask, "mid": mid, "spread_bps": sp, "quelle": "Orderbuch",
                "kauf": [(10, r[5]), (25, r[7]), (50, r[9]), (100, r[11])], "verkauf": [(10, r[4]), (25, r[6]), (50, r[8]), (100, r[10])],
                "tiefe10": (r[4] or 0) + (r[5] or 0)}
    try:
        k = con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
    except sqlite3.Error:
        k = None
    if k and k[1]:
        mid = float(k[1]); sp = ERSATZ_SPREAD_BPS.get(coin, 4.0)
        return {"ts": int(k[0]) + 60, "bid": mid * (1 - sp / 2e4), "ask": mid * (1 + sp / 2e4), "mid": mid, "spread_bps": sp,
                "quelle": "Minutenkerze (Buch fehlt)", "kauf": [], "verkauf": [], "tiefe10": None}
    return None


def kerzen(con, coin: str, t0: int, t1: int) -> list:
    """Abgeschlossene 1-min-Kerzen mit t0 <= ts < t1: (ts, open, high, low, close)."""
    try:
        return [tuple(r) for r in con.execute("SELECT ts, open, high, low, close FROM bars WHERE ts>=? AND ts<? AND coin=? ORDER BY ts",
                                              (t0, t1, coin)).fetchall() if r[4]]
    except sqlite3.Error:
        return []


def sigma_4h(con, coin: str, now: int) -> tuple:
    """(σ der 4-h-Rendite aus 15-min-Schlusskursen der letzten 7 Tage, belastbar?, σ der letzten 4 h auf derselben Skala).
    Gezielte Abfrage der 673 Rasterpunkte über den Primärschlüssel (ts, coin) statt eines Bereichs über alle Coins."""
    letzte = now // 900 * 900 - 60
    raster = [letzte - 900 * k for k in range(7 * 96, -1, -1)]
    try:
        rows = con.execute(f"SELECT ts, close FROM bars WHERE coin=? AND ts IN ({','.join('?' * len(raster))}) ORDER BY ts",
                           (coin, *raster)).fetchall()
    except sqlite3.Error:
        rows = []
    r = []; prev = None
    for ts, c in rows:
        if prev and c and prev[1] and ts - prev[0] == 900:
            r.append(math.log(c / prev[1]))
        prev = (ts, c)
    if len(r) < 96:
        return SIGMA_ERSATZ.get(coin, 0.02), False, None
    m = sum(r) / len(r); sd = math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1))
    kurz = r[-16:]; mk = sum(kurz) / len(kurz)
    sdk = math.sqrt(sum((x - mk) ** 2 for x in kurz) / max(len(kurz) - 1, 1))
    return max(sd * 4, 1e-4), True, sdk * 4


def volumen_1h(con, coin: str, now: int):
    """Median des Stundenvolumens (USD) der letzten 24 abgeschlossenen Stunden."""
    t1 = now // 3600 * 3600
    try:
        w = sorted(v for _, v in con.execute("SELECT ts/3600, SUM(volume*close) FROM bars WHERE ts>=? AND ts<? AND coin=? GROUP BY 1",
                                             (t1 - 24 * 3600, t1, coin)).fetchall() if v)
    except sqlite3.Error:
        w = []
    return w[len(w) // 2] if len(w) >= 6 else None


# ------------------------------------------------------------------------------------------------ Grid-Hilfen (23.40)
def grid_kurse(con, coin: str, von: int, bis: int) -> list:
    """1-min-Schlusskurse [(ts, close)] mit von <= ts < bis."""
    try:
        return [(int(t), float(c)) for t, c in con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<? AND coin=? ORDER BY ts",
                                                           (int(von), int(bis), coin)) if c]
    except sqlite3.Error:
        return []


def grid_range(kurse: list, p_rand: float = 0.10) -> dict | None:
    """
    Range aus 1-min-Schlusskursen [(ts, close)]: unten/oben = Perzentile p_rand und 1 − p_rand (einzelne Spitzen zählen nicht).
    Trend (mit Vorzeichen) = Netto-Bewegung in Einheiten der eigenen Schwankung: ln(Ende/Anfang) / (σ der 5-min-Renditen · √Anzahl). Für
    einen reinen Zufallsweg standardnormal, unabhängig von der Fensterlänge (|Trend| ≤ 1 in 68 %, ≤ 2 in 95 % der Fälle).
    """
    if len(kurse) < 120:
        return None
    s = sorted(c for _, c in kurse)
    q = lambda p: s[min(len(s) - 1, max(0, int(round(p * (len(s) - 1)))))]
    c5 = [c for t, c in kurse if t % 300 == 240]
    trend = None
    r = [math.log(c5[i] / c5[i - 1]) for i in range(1, len(c5)) if c5[i - 1] > 0 and c5[i] > 0]
    if len(r) >= 11:
        m = sum(r) / len(r); sd = math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1))
        trend = math.log(c5[-1] / c5[0]) / (sd * math.sqrt(len(r))) if sd > 0 else 0.0
    return {"unten": q(p_rand), "oben": q(1 - p_rand), "trend": trend, "n": len(kurse), "von": kurse[0][0], "bis": kurse[-1][0] + 60}


def grid_trend_ok(trend, R: dict) -> bool:
    """Darf das Grid bei diesem Trend (mit Vorzeichen) aufbauen oder nachführen? Gegen das Grid (Long: abwärts) höchstens trend_gegen,
    in Grid-Richtung höchstens trend_mit -- ein Long-Grid in einem Abwärtstrend ist der klassische Verlustfall, im Aufwärtstrend
    verkauft es nur zu früh."""
    if trend is None:
        return False
    t = trend if R["richtung"] == "long" else -trend
    return -R["trend_gegen"] <= t <= R["trend_mit"]


def grid_stufen(unten: float, oben: float, schritt_min: float, n_min: int, n_max: int):
    """Geometrische Stufen [L0 .. Ln] von unten bis oben: so viele Abstände, wie mit mindestens schritt_min passen (höchstens n_max);
    None, wenn weniger als n_min passen. Liefert (Stufen, Schritt)."""
    if not unten or not oben or oben <= unten or unten <= 0:
        return None
    n = min(int(math.log(oben / unten) / math.log(1 + schritt_min) + 1e-9), n_max)
    if n < n_min:
        return None
    q = (oben / unten) ** (1.0 / n)
    return [unten * q ** i for i in range(n)] + [oben], q - 1


def grid_tage(st, sid: str) -> dict:
    """
    Tagesergebnis eines Grids nach Bestandswert (Mark-to-Market) je UTC-Tag: realisiert im Tag plus Änderung des unrealisierten
    Bestandswerts (letzter Stand des Tages gegen den letzten davor). Nur realisiert zeigte ein Grid laufend kleine Gewinne, während sich
    die Verluste im Bestand sammeln. Ein Tag ohne Stand (Labor aus) gibt seine Änderung an den nächsten Tag mit Stand weiter.
    {"tage": [(tag, usd)], "je_coin": {coin: [(tag, usd)]}, "bestand": {coin: letzter Bestandswert}}
    """
    real: dict = {}
    for coin, tag, usd in st.execute("SELECT coin, geschlossen / 86400 * 86400, SUM(netto_usd) FROM labor_position WHERE sid=? AND status='geschlossen' "
                                     "GROUP BY 1, 2", (sid,)):
        real[(coin, int(tag))] = float(usd or 0.0)
    snap: dict = {}
    try:
        for coin, tag, u in st.execute("SELECT coin, tag, unreal FROM labor_grid_tag WHERE sid=?", (sid,)):
            snap[(coin, int(tag))] = float(u or 0.0)
    except sqlite3.Error:
        pass
    coins = sorted({c for c, _ in real} | {c for c, _ in snap})
    letzt = {c: 0.0 for c in coins}; je = {c: [] for c in coins}; ges = []
    for tag in sorted({t for _, t in real} | {t for _, t in snap}):
        s_ = 0.0; da = False
        for c in coins:
            if (c, tag) not in real and (c, tag) not in snap:
                continue
            v = real.get((c, tag), 0.0)
            if (c, tag) in snap:
                v += snap[(c, tag)] - letzt[c]; letzt[c] = snap[(c, tag)]
            je[c].append((tag, v)); s_ += v; da = True
        if da:
            ges.append((tag, s_))
    return {"tage": ges, "je_coin": je, "bestand": letzt}


def grid_tage_tabelle(st, sid: str, coin: str | None = None) -> list:
    """
    23.68 (U163): Tabelle „je Coin und Tag“ eines Grids -- geschlossene Lose, realisiert, Änderung des Bestands, Tagesergebnis in USD und in
    Prozent des Coin-Kontos (GRID_KAPITAL). Eigene Abfragen auf labor_position und labor_grid_tag; dieselbe Regel wie grid_tage (ein Tag
    ohne Stand gibt seine Änderung an den nächsten Tag mit Stand weiter), damit die Probe beide gegeneinander halten kann.
    [{"coin", "tag", "lose", "realisiert", "bestand_aend", "ergebnis", "pct"}], je Coin nach Tag sortiert.
    """
    par = [sid] + ([coin] if coin else [])
    wo = " AND coin=?" if coin else ""
    real, lose = {}, {}
    for c, tag, n, usd in st.execute(f"SELECT coin, geschlossen / 86400 * 86400, COUNT(*), SUM(netto_usd) FROM labor_position WHERE sid=? "
                                     f"AND status='geschlossen'{wo} GROUP BY 1, 2", par):
        real[(c, int(tag))] = float(usd or 0.0); lose[(c, int(tag))] = int(n)
    stand = {}
    try:
        for c, tag, u in st.execute(f"SELECT coin, tag, unreal FROM labor_grid_tag WHERE sid=?{wo}", par):
            stand[(c, int(tag))] = float(u or 0.0)
    except sqlite3.Error:
        pass
    out = []
    for c in sorted({k[0] for k in real} | {k[0] for k in stand}):
        letzt = 0.0
        for tag in sorted({t for (cc, t) in real if cc == c} | {t for (cc, t) in stand if cc == c}):
            r_ = real.get((c, tag), 0.0); d_ = 0.0
            if (c, tag) in stand:
                d_ = stand[(c, tag)] - letzt; letzt = stand[(c, tag)]
            out.append({"coin": c, "tag": tag, "lose": lose.get((c, tag), 0), "realisiert": round(r_, 2), "bestand_aend": round(d_, 2),
                        "ergebnis": round(r_ + d_, 2), "pct": round((r_ + d_) / GRID_KAPITAL * 100, 4)})
    return out


# ------------------------------------------------------------------------------------------------ Akkumulation (U180, 23.69)
# Nutzer 19.10. 20:22: „sie dient ausschließlich der Akkumulation. Es gibt keinen Verkauf“ -- je Rücksetzer ein fester Betrag, nachkaufen,
# Heatmap-Cluster, bei vielen Long-Konten warten, nichts mehr kaufen ab 20 % über der 200-Tage-Linie (KONZEPT_Akkumulation.md).
# 23.70 (U184, Nutzer 19.10. 23:20/23:40): 5.000 USD je Kauf, Spot; Startkauf A0 je Coin, rückwirkend ab dem Start des Coins im Labor.
def _g6(x) -> str:
    """Kurs mit 6 gültigen Stellen und Dezimalkomma (Texte der Akkumulation)."""
    return format(x, ".6g").replace(".", ",")


def akku_lage(R: dict, P, H7, sig7, ma, letzter, now: int, cluster=None, sig1h=None, konten=None, frisch: bool = True) -> dict:
    """
    Kaufentscheidung der Akkumulation aus dem Stand jetzt -- dieselbe Funktion für Takt, Status und Proben (KONZEPT 2).
    letzter = (ts, preis) des letzten Kaufs dieser Strategie im Coin oder None; cluster = {"px", "anteil", ...} oder None.
    -> {kauf, ausloeser (A0/A1/A2/A3), grund, schwellen {sperre, a1, a2, a2_wirk, a3}, warten (Konten ≥ Schwelle), nachkauf (binnen 7 Tagen),
        start (Startkauf steht aus), naechster {preis, art} (nur Anzeige: der nächste Kaufpreis ohne Sperre; beim Startkauf die Sperre)}
    23.70 (U184): Startkauf A0 -- ohne einen Kauf dieser Strategie im Coin kauft sie sofort (frischer Kurs, σ und 200-Tage-Linie bekannt,
    Kurs unter der Sperre); erst danach gelten A1/A2/A3. Den Startkauf ab dem Start des Coins im Labor rechnet _akku_nachrechnen nach.
    """
    fe = int(R["fenster_tage"]) * 86_400
    s = {"sperre": R["ma_faktor"] * ma if ma else None,
         "a1": H7 * math.exp(-R["tiefe"] * sig7) if (H7 and sig7) else None,
         "a2": H7 * math.exp(-R["cluster_tiefe"] * sig7) if (R.get("cluster") and H7 and sig7) else None,
         "a3": letzter[1] * math.exp(-R["stufe"] * sig7) if (letzter and sig7) else None}
    # 23.69: wirksamer Preis von A2 = beide Bedingungen zugleich (σ₇-Abstand und Nähe zum Cluster); nur Anzeige, die Regel unten prüft beide
    s["a2_wirk"] = (min(s["a2"], cluster["px"] * math.exp(R["cluster_naehe"] * sig1h))
                    if (s["a2"] and cluster and sig1h) else None)
    out = {"kauf": False, "ausloeser": None, "grund": "", "schwellen": s, "warten": bool(R.get("cluster") and konten is not None and konten >= R["konten"]),
           "nachkauf": bool(letzter and now - int(letzter[0]) < fe), "start": bool(R.get("start") and letzter is None), "naechster": None}
    if out["start"]:
        if s["sperre"]:
            out["naechster"] = {"preis": s["sperre"], "art": "A0"}
    elif out["nachkauf"]:
        if s["a3"]:
            out["naechster"] = {"preis": s["a3"], "art": "A3"}
    else:
        kand = [(s["a1"], "A1")] if s["a1"] else []
        if R.get("cluster") and s["a2_wirk"] and not out["warten"]:
            kand.append((s["a2_wirk"], "A2"))
        if kand:
            p_, a_ = max(kand)
            out["naechster"] = {"preis": p_, "art": a_}
    if not P:
        out["grund"] = "kein Kurs"; return out
    if not frisch:
        out["grund"] = "Kurs veraltet"; return out
    if out["start"]:                                                   # 23.70 (U184): Startkauf vor allen anderen Auslösern
        if not sig7:
            out["grund"] = "Startkauf wartet: σ fehlt"
        elif not ma:
            out["grund"] = f"Startkauf wartet: keine {R['ma_tage']}-Tage-Linie (zu wenige Tagesschlüsse)"
        elif P >= s["sperre"]:
            out["grund"] = (f"Startkauf wartet: zu teuer, Kurs ≥ {_g6(R['ma_faktor'])} × {R['ma_tage']}-Tage-Linie ({_g6(s['sperre'])}); "
                            "gekauft wird, sobald er darunter liegt")
        else:
            out.update(kauf=True, ausloeser="A0", grund="Startkauf: erster Kauf dieser Strategie in diesem Coin")
        return out
    if not sig7 or not H7:
        out["grund"] = "σ oder 7-Tage-Hoch fehlt"; return out
    if not ma:
        out["grund"] = f"keine {R['ma_tage']}-Tage-Linie (zu wenige Tagesschlüsse)"; return out
    if P >= s["sperre"]:
        out["grund"] = f"zu teuer: Kurs ≥ {_g6(R['ma_faktor'])} × {R['ma_tage']}-Tage-Linie ({_g6(s['sperre'])})"; return out
    if out["nachkauf"]:
        if P <= s["a3"]:
            out.update(kauf=True, ausloeser="A3", grund=f"Nachkauf: Kurs ≤ {_g6(s['a3'])}, ein σ₇ unter dem letzten Kauf ({_g6(letzter[1])})")
        else:
            out["grund"] = f"Nachkauf erst ab {_g6(s['a3'])} (ein σ₇ unter dem letzten Kauf), längstens bis {_uhr(int(letzter[0]) + fe)}"
        return out
    if P <= s["a1"]:
        out.update(kauf=True, ausloeser="A1", grund=f"Rücksetzer: Kurs ≤ {_g6(s['a1'])}, 2 σ₇ unter dem 7-Tage-Hoch ({_g6(H7)})")
        return out
    if R.get("cluster"):
        if cluster and not out["warten"] and P <= s["a2"] and sig1h:
            if P <= cluster["px"] * math.exp(R["cluster_naehe"] * sig1h):
                out.update(kauf=True, ausloeser="A2",
                           grund=f"Heatmap: Kurs am heißen Long-Cluster {_g6(cluster['px'])} ({cluster.get('anteil', 0) * 100:.0f} % des "
                                 f"Stundenvolumens), schon ein σ₇ unter dem 7-Tage-Hoch")
                return out
    teile = [f"wartet: Rücksetzer ab {_g6(s['a1'])}"]
    if R.get("cluster"):
        if out["warten"]:
            teile.append(f"Konten {konten:.2f} ≥ {R['konten']:g}: kein Kauf am Cluster, nur beim vollen Rücksetzer".replace(".", ","))
        elif cluster and s["a2_wirk"]:
            teile.append(f"heißes Long-Cluster {_g6(cluster['px'])}: Kauf dort ab {_g6(s['a2_wirk'])}")
        elif cluster:
            teile.append(f"heißes Long-Cluster {_g6(cluster['px'])}: σ(1 h) fehlt")
    out["grund"] = "; ".join(teile)
    return out


def akku_bilanz(kaeufe: list, mid) -> dict:
    """kaeufe [{"usd", "menge", "gebuehr", "preis", ...}] -> Summen, Ø Einstand (eingesetzt ÷ Bestand, Gebühr eingeschlossen), Wert zur
    Mitte, Gewinn; je Los Wert und Gewinn. Die Strategie verkauft nie: Gewinn ohne Verkaufsgebühr."""
    usd = sum(k["usd"] for k in kaeufe); menge = sum(k["menge"] for k in kaeufe); geb = sum(k["gebuehr"] for k in kaeufe)
    wert = menge * mid if (mid and kaeufe) else None
    lose = []
    for k in kaeufe:
        w = k["menge"] * mid if mid else None
        lose.append(dict(k, wert=w, gewinn_usd=(w - k["usd"]) if w is not None else None,
                         gewinn_pct=((w / k["usd"] - 1) * 100) if w is not None else None))
    return {"n": len(kaeufe), "eingesetzt": usd, "menge": menge, "gebuehren": geb, "einstand": (usd / menge) if menge > 0 else None,
            "mid": mid, "wert": wert, "gewinn_usd": (wert - usd) if wert is not None else None,
            "gewinn_pct": ((wert / usd - 1) * 100) if (wert is not None and usd > 0) else None, "lose": lose}


# 23.71 (U185): Grund des Startkaufs. 23.70 schrieb bei jedem nachgerechneten Startkauf „zum Start des Coins im Labor (…)“, auch wenn er erst
# Tage später kam (auf dem Pi ETH am 07.10., HYPE am 19.10.; vorher war nach der Regel kein Kauf erlaubt). Gekauft wird in der ersten Minute seit dem
# Start, in der ein Kauf erlaubt war -- so heißt es jetzt, und gespeicherte Texte von 23.70 schreibt die Anzeige ebenso.
AKKU_A0_ALT = re.compile(r"Startkauf zum Start des Coins im Labor \(([^)]*)\)")
AKKU_A0_TEXT = ("Startkauf in der ersten Minute seit dem Start des Coins im Labor ({ab}), in der ein Kauf erlaubt war (Kurs unter "
                "1,2 × 200-Tage-Linie, σ₇ und 200-Tage-Linie bekannt)")


def akku_grund_text(t) -> str:
    """Text eines Kaufs oder Ereignisses für die Anzeige: der Startkauf-Grund aus 23.70 in der richtigen Fassung (die Daten bleiben)."""
    return AKKU_A0_ALT.sub(lambda m: AKKU_A0_TEXT.format(ab=m.group(1)), t or "")


def akku_start_ursache(ts, o, s7, sperre, t0: int, t_kauf: int) -> str:
    """Warum der nachgerechnete Startkauf nicht in der ersten Minute ab t0 kam, über alle Minuten von t0 bis vor den Kauf (dieselbe Bedingung
    wie A0 in akku_regel_kerzen): '' (kam sofort), Kurs bei oder über der Sperre, fehlende Tageskerzen (σ₇ oder 200-Tage-Linie) oder beides."""
    ts = np.asarray(ts, dtype=np.int64)
    j0 = int(np.searchsorted(ts, int(t0))); jk = int(np.searchsorted(ts, int(t_kauf)))
    if jk <= j0:
        return ""
    s_ = np.asarray(s7[j0:jk], dtype=float); p_ = np.asarray(sperre[j0:jk], dtype=float); o_ = np.asarray(o[j0:jk], dtype=float)
    fehlt = ~(np.isfinite(s_) & np.isfinite(p_))
    u = f"; erst am {_uhr(int(t_kauf))}, bis dahin "
    if fehlt.all():
        return u + "fehlten Tageskerzen (σ₇ oder 200-Tage-Linie)"
    if not fehlt.any():
        return u + "lag der Kurs bei oder über 1,2 × 200-Tage-Linie"
    return u + "fehlten zeitweise Tageskerzen (σ₇ oder 200-Tage-Linie), sonst lag der Kurs bei oder über 1,2 × 200-Tage-Linie"


def akku_vergleich(preise_kauf, preise_erlaubt, ziehungen: int = AKKU_ZIEHUNGEN, seed: int = 180) -> dict | None:
    """Ø Einstand (gleiche USD je Kauf: harmonisches Mittel) gegen dieselbe Zahl Käufe zu Zufallszeiten (gleichverteilt über die erlaubten
    Kurse, feste Saat) und gegen gleichmäßig verteilte Käufe (KONZEPT 4). p = Anteil der Ziehungen mit niedrigerem Ø Einstand."""
    N = len(preise_kauf); M = len(preise_erlaubt)
    if N < AKKU_MIN_VERGLEICH or M < N:
        return None
    pk = np.asarray(preise_kauf, dtype=float); pe = np.asarray(preise_erlaubt, dtype=float)
    e = N / float(np.sum(1.0 / pk))
    rng = np.random.default_rng(seed)
    Z = rng.integers(0, M, size=(int(ziehungen), N))
    ez = N / np.sum(1.0 / pe[Z], axis=1)
    gl = pe[np.round(np.linspace(0, M - 1, N)).astype(np.int64)]
    eg = N / float(np.sum(1.0 / gl))
    med = float(np.median(ez))
    return {"n": N, "einstand": e, "zufall_median": med, "zufall_band": [float(np.quantile(ez, 0.05)), float(np.quantile(ez, 0.95))],
            "vorteil_pct": (med / e - 1) * 100, "p": float((1 + np.sum(ez <= e)) / (1 + int(ziehungen))),
            "gleichmaessig": eg, "vorteil_gleich_pct": (eg / e - 1) * 100, "erlaubt": M}


def _fenster_max(a: np.ndarray, w: int) -> np.ndarray:
    """out[k] = max(a[k : k + w]) für k = 0 … len(a) − w (van Herk/Gil-Werman: Block-Präfix und -Suffix, linear)."""
    n = len(a); m = -(-n // w) * w
    b = np.full(m, -np.inf); b[:n] = a
    B = b.reshape(-1, w)
    pre = np.maximum.accumulate(B, axis=1).ravel()
    suf = np.maximum.accumulate(B[:, ::-1], axis=1)[:, ::-1].ravel()
    k = np.arange(n - w + 1)
    return np.maximum(suf[k], pre[k + w - 1])


def akku_h7_reihe(ts, h, bar: int = 1800, fenster_s: int = 7 * 86_400) -> np.ndarray:
    """Je Kerze das höchste Hoch der Kerzen im Fenster [t − 7 T, t), ohne die Kerze selbst (kausal; fehlende Kerzen zählen nicht);
    NaN ohne Vorgänger. Auf dem Zeitraster der Kerzen, damit Lücken das Fenster nicht verlängern. 23.72: fenster_s (48 h für A4)."""
    ts = np.asarray(ts, dtype=np.int64); h = np.asarray(h, dtype=float)
    if not len(ts):
        return np.zeros(0)
    idx = (ts - ts[0]) // bar; N = int(idx[-1]) + 1; w = int(fenster_s) // bar
    g = np.full(N, -np.inf); np.maximum.at(g, idx, h)
    pad = np.concatenate([np.full(w, -np.inf), g])
    M = _fenster_max(pad, w)[:N][idx]
    return np.where(np.isfinite(M), M, np.nan)


def akku_regel_kerzen(R: dict, ts, o, h, l, c, s7, sperre, bar: int = 1800, ab: int | None = None) -> tuple:
    """
    Rückblick-Regel ohne Heatmap (KONZEPT 5) auf Kerzen: A1 bei Tief ≤ H7·e^(−tiefe·σ₇), A3 je weiteres σ₇ unter dem letzten Kauf binnen
    7 Tagen; Kauf zur Schwelle, bei einer Eröffnung darunter zum Eröffnungskurs; mehrere Stufen in einer Kerze möglich; Sperre am Kaufpreis.
    s7 und sperre (Preis) je Kerze aus dem Vortag. -> (Käufe [(ts, preis, auslöser)], erlaubt: Schluss unter der Sperre, alles gültig)
    23.70 (U184): bar = Kerzenlänge in s (Raster des 7-Tage-Hochs; 60 für die Rückrechnung auf 1-min-Kerzen). Mit ab: Käufe erst ab diesem
    Zeitpunkt (die Kerzen davor zählen nur zum 7-Tage-Hoch), und mit R["start"] zuerst der Startkauf A0 zur Eröffnung der ersten Kerze ab
    „ab“ mit σ₇ und Sperre und Eröffnung unter der Sperre. Ohne ab (Rückblick seit 2020) nie ein Startkauf.
    """
    ts = np.asarray(ts, dtype=np.int64); n = len(ts); fe = int(R["fenster_tage"]) * 86_400
    H7 = akku_h7_reihe(ts, h, bar)
    with np.errstate(invalid="ignore"):
        lev1 = H7 * np.exp(-R["tiefe"] * s7)
        gueltig = np.isfinite(lev1) & np.isfinite(sperre)
        erlaubt = gueltig & (c < sperre)
    kaeufe = []; j = 0; tL = None; pL = None

    def stufen(jj):                                                    # weitere Nachkauf-Stufen in derselben Kerze
        nonlocal pL
        while True:
            lv = pL * math.exp(-R["stufe"] * s7[jj]); p = min(lv, o[jj])
            if l[jj] <= lv and p < sperre[jj]:
                kaeufe.append((int(ts[jj]), float(p), "A3")); pL = float(p)
            else:
                return
    if ab is not None:
        j = int(np.searchsorted(ts, int(ab)))
        if R.get("start"):
            with np.errstate(invalid="ignore"):
                m = np.nonzero(np.isfinite(s7[j:]) & np.isfinite(sperre[j:]) & (o[j:] < sperre[j:]))[0]
            if not len(m):
                return kaeufe, erlaubt
            jj = j + int(m[0]); p = float(o[jj])
            kaeufe.append((int(ts[jj]), p, "A0")); tL, pL = int(ts[jj]), p
            stufen(jj)
            j = jj + 1
    while j < n:
        if tL is not None and ts[j] - tL < fe:
            k = int(np.searchsorted(ts, tL + fe))
            lev = pL * np.exp(-R["stufe"] * s7[j:k]); px = np.minimum(lev, o[j:k])
            with np.errstate(invalid="ignore"):
                m = np.nonzero(gueltig[j:k] & (l[j:k] <= lev) & (px < sperre[j:k]))[0]
            if not len(m):
                j = k; continue
            jj = j + int(m[0]); p = float(px[m[0]])
            kaeufe.append((int(ts[jj]), p, "A3")); tL, pL = int(ts[jj]), p
        else:
            px = np.minimum(lev1[j:], o[j:])
            with np.errstate(invalid="ignore"):
                m = np.nonzero(gueltig[j:] & (l[j:] <= lev1[j:]) & (px < sperre[j:]))[0]
            if not len(m):
                break
            jj = j + int(m[0]); p = float(px[m[0]])
            kaeufe.append((int(ts[jj]), p, "A1")); tL, pL = int(ts[jj]), p
        stufen(jj)
        j = jj + 1
    return kaeufe, erlaubt


def akku_korr_q(R: dict, f: float = 1.0) -> float:
    """23.74 (U189): Faktor der A4-Schwelle -- (1 − 7 %) hoch f (f = Faktor gegenüber BTC, mit „faktor_korr“; sonst wie bis 23.73)."""
    return (1.0 - R["korr"]) ** (float(f) if R.get("faktor_korr") else 1.0)


def akku_betrag(R: dict, f: float = 1.0) -> float:
    """23.74 (U189): Betrag je Kauf -- 5.000 USD ÷ f (mit „faktor_betrag“; sonst 5.000 USD wie bis 23.73)."""
    return R["usd"] / float(f) if R.get("faktor_betrag") else R["usd"]


def akku_pc(R: dict, f: float = 1.0) -> str:
    """23.74 (U189): Abstand der A4-Schwelle in Prozent für Texte, eine Stelle, ohne „,0“ (BTC „7“, f = 3 „19,6“)."""
    s = _de((1.0 - akku_korr_q(R, f)) * 100, 1)
    return s[:-2] if s.endswith(",0") else s


def akku_korrektur_lage(R: dict, P, H48, letzter_k, now: int, frisch: bool = True, f: float = 1.0) -> dict:
    """
    23.72 (U186, Nutzer 20.10. 02:43): Korrekturkauf A4 -- eigene Spur neben A0–A3, ohne Sperre und ohne σ oder 200-Tage-Linie.
    H48 = höchstes Hoch der 1-min-Kerzen der letzten 48 h, nach einem Korrekturkauf erst ab der Minute danach (derselbe Einbruch kauft nur
    einmal); letzter_k = (ts, preis) des letzten Korrekturkaufs dieser Strategie im Coin oder None.
    Bezug = das höhere von H48 und dem letzten Korrekturkauf, solange dieser jünger als 14 Tage ist; Kauf bei P ≤ (1 − 7 %) · Bezug.
    23.74 (U189): mit dem Faktor gegenüber BTC f bei P ≤ 0,93^f · Bezug (BTC f = 1: wie bisher).
    -> {kauf, ausloeser ("A4"), grund, schwelle, bezug, bezug_art ("hoch48"/"nachkauf"), nachkauf, bis, naechster {preis, art}}
    """
    q = akku_korr_q(R, f); fe = int(R["korr_tage"]) * 86_400
    nach = bool(letzter_k and now - int(letzter_k[0]) < fe)
    kand = ([(float(H48), "hoch48")] if H48 else []) + ([(float(letzter_k[1]), "nachkauf")] if nach else [])
    out = {"kauf": False, "ausloeser": None, "grund": "", "schwelle": None, "bezug": None, "bezug_art": None, "nachkauf": nach,
           "bis": int(letzter_k[0]) + fe if nach else None, "naechster": None}
    if kand:
        b_, art = max(kand)
        out.update(schwelle=q * b_, bezug=b_, bezug_art=art, naechster={"preis": q * b_, "art": "A4"})
    pc = akku_pc(R, f)
    wo = (lambda: f"{pc} % unter dem Hoch der letzten {int(R['korr_h'])} h ({_g6(out['bezug'])})" if out["bezug_art"] == "hoch48"
          else f"{pc} % unter dem letzten Korrekturkauf ({_g6(out['bezug'])})")
    if not P:
        out["grund"] = "kein Kurs"; return out
    if not frisch:
        out["grund"] = "Kurs veraltet"; return out
    if not kand:
        out["grund"] = f"Korrektur: Hoch der letzten {int(R['korr_h'])} h fehlt"; return out
    if P <= out["schwelle"]:
        out.update(kauf=True, ausloeser="A4", grund=(f"Korrektur: Kurs ≤ {_g6(out['schwelle'])}, " if out["bezug_art"] == "hoch48" else
                                                     f"Korrektur, Nachkauf: Kurs ≤ {_g6(out['schwelle'])}, ") + wo())
    else:
        out["grund"] = (f"Korrekturkauf ab {_g6(out['schwelle'])}: {wo()}" + (f", längstens bis {_uhr(out['bis'])}" if out["bezug_art"] == "nachkauf"
                                                                               else ""))
    return out


def akku_korrektur_kerzen(R: dict, ts, o, h, l, c, ab: int | None = None, bar: int = 60, f: float = 1.0) -> list:
    """
    23.72 (U186): Korrekturkauf A4 auf Kerzen (Rückrechnung; dieselbe Regel wie akku_korrektur_lage). Je Kerze i: Bezug = das höhere von
    (a) dem höchsten Hoch der Kerzen im Fenster [t_i − 48 h, t_i), ohne die Kerze selbst und nach einem Korrekturkauf erst ab der Kerze
    danach, und (b) dem letzten Korrekturkauf, solange jünger als 14 Tage. Auslösung am Tief ≤ (1 − 7 %) · Bezug; Kauf zur Schwelle, bei
    einer Eröffnung darunter zur Eröffnung; in derselben Kerze weitere Stufen je 7 % (wie mehrere Takte live). Ohne Sperre. Mit ab: Käufe
    erst ab diesem Zeitpunkt; die Kerzen davor zählen nur zum Hoch. 23.74 (U189): Schwelle und Stufen mit 0,93^f (f = Faktor gegenüber BTC).
    -> [(ts, preis, "A4", bezug_art, bezug, schwelle)]
    """
    ts = np.asarray(ts, dtype=np.int64); o = np.asarray(o, dtype=float); h = np.asarray(h, dtype=float); l = np.asarray(l, dtype=float)
    n = len(ts)
    if not n:
        return []
    q = akku_korr_q(R, f); fh = int(R["korr_h"]) * 3600; fe = int(R["korr_tage"]) * 86_400
    M48 = akku_h7_reihe(ts, h, bar, fh)
    M48 = np.where(np.isfinite(M48), M48, -np.inf)
    j = int(np.searchsorted(ts, int(ab))) if ab is not None else 0
    out = []; jL = None; tL = pL = None
    while j < n:
        i_ = np.arange(j, n)
        if jL is None:
            H = M48[j:]
        else:                                                          # nach einem Kauf: Hoch erst ab der Kerze danach (j = jL + 1)
            lauf = np.concatenate([[-np.inf], np.maximum.accumulate(h[jL + 1:n - 1])]) if n - 1 > jL else np.array([-np.inf])
            H = np.where(ts[i_] - fh > ts[jL], M48[j:], lauf[:n - j])
        F = np.where(ts[i_] - tL < fe, pL, -np.inf) if tL is not None else np.full(n - j, -np.inf)
        B = np.maximum(H, F)
        with np.errstate(invalid="ignore"):
            m = np.nonzero(np.isfinite(B) & (l[j:] <= q * B))[0]
        if not len(m):
            break
        i = j + int(m[0]); b_ = float(B[m[0]]); thr = q * b_
        art = "nachkauf" if (tL is not None and ts[i] - tL < fe and pL >= float(H[m[0]])) else "hoch48"
        p = min(thr, float(o[i]))
        out.append((int(ts[i]), p, "A4", art, b_, thr))
        while l[i] <= q * p and q * p > 1e-9 * float(h[i]):            # weitere Stufen in derselben Kerze (Schutz gegen Tief 0)
            out.append((int(ts[i]), q * p, "A4", "nachkauf", p, q * p)); p = q * p
        jL, tL, pL = i, int(ts[i]), p
        j = i + 1
    return out


def akku_faktor_aus_rv(rv_c, rv_b, R: dict) -> dict:
    """
    23.74 (U189): Faktor gegenüber BTC aus zwei Reihen Tages-RV derselben Tage (NaN = Tag ohne gültige RV). Nur Tage, an denen beide eine
    gültige RV haben; σ̄ = Wurzel aus dem Mittel der RV. f = max(faktor_min, σ̄_Coin ÷ σ̄_BTC), auf zwei Stellen gerundet. Unter
    AKKU_FAKTOR_MIN_TAGE gemeinsamen Tagen (oder σ̄ = 0) kein Faktor.
    -> {ok, faktor, roh, sigma, sigma_basis, n, grund}
    """
    a = np.asarray(rv_c, dtype=float); b = np.asarray(rv_b, dtype=float)
    m = np.isfinite(a) & np.isfinite(b) & (a >= 0) & (b >= 0)
    n = int(m.sum())
    out = {"ok": False, "faktor": None, "roh": None, "sigma": None, "sigma_basis": None, "n": n, "grund": ""}
    if n < AKKU_FAKTOR_MIN_TAGE:
        out["grund"] = f"zu wenige Tage mit Kursen von Coin und {R.get('faktor_basis', 'BTC')} ({n} von mindestens {AKKU_FAKTOR_MIN_TAGE})"
        return out
    s_c = math.sqrt(float(np.mean(a[m]))); s_b = math.sqrt(float(np.mean(b[m])))
    out.update(sigma=s_c, sigma_basis=s_b)
    if not (s_c > 0 and s_b > 0):
        out["grund"] = "Schwankung null -- kein Faktor"
        return out
    roh = s_c / s_b
    out.update(ok=True, roh=roh, faktor=round(max(float(R.get("faktor_min", 1.0)), roh), 2))
    return out


def akku_faktor_rechnen(swing_pfad: str | None, coin: str, t_start: int, R: dict) -> dict:
    """
    23.74 (U189): Faktor eines Coins gegenüber BTC aus swing.db (30-min-Kerzen, nur lesend): die vollen UTC-Tage d mit D_s − 365 ≤ d < D_s,
    D_s = Tag des Starts des Coins im Labor -- nichts ab dem Start. BTC selbst: f = 1 (σ̄ wird nur angezeigt).
    -> wie akku_faktor_aus_rv, dazu von, bis (Tage), start
    """
    basis = R.get("faktor_basis", "BTC"); tage = int(R.get("faktor_tage", 365))
    D_s = int(t_start) // 86_400; von, bis = (D_s - tage) * 86_400, D_s * 86_400
    leer = {"ok": False, "faktor": None, "roh": None, "sigma": None, "sigma_basis": None, "n": 0, "von": von, "bis": bis, "start": int(t_start)}

    def rv_je_tag(con, c_):
        rows = con.execute("SELECT ts, o, h, l, c FROM sw_klines WHERE coin=? AND ts>=? AND ts<? ORDER BY ts", (c_, von, bis)).fetchall()
        if not rows:
            return {}
        a_ = np.array(rows, dtype=float)
        T = SW.tagesreihen({"ts": a_[:, 0].astype(np.int64), "o": a_[:, 1], "h": a_[:, 2], "l": a_[:, 3], "c": a_[:, 4]})
        if T is None:
            return {}
        return {int(d_): float(r_) for d_, r_, v_ in zip(T["tag_ts"] // 86_400, T["RV"], T["voll"]) if v_ and np.isfinite(r_) and von <= d_ * 86_400 < bis}
    if not swing_pfad or not os.path.exists(swing_pfad):
        return dict(leer, grund="swing.db fehlt", faktor=1.0 if coin == basis else None, ok=coin == basis, roh=1.0 if coin == basis else None)
    try:
        con = sqlite3.connect(f"file:{swing_pfad}?mode=ro", uri=True, timeout=5)
        try:
            rc = rv_je_tag(con, coin); rb = rc if coin == basis else rv_je_tag(con, basis)
        finally:
            con.close()
    except sqlite3.Error as e:
        return dict(leer, grund=f"swing.db nicht lesbar: {e}")
    tage_ = sorted(set(rc) | set(rb))
    out = akku_faktor_aus_rv([rc.get(d_, math.nan) for d_ in tage_], [rb.get(d_, math.nan) for d_ in tage_], R)
    out.update(von=von, bis=bis, start=int(t_start))
    if coin == basis:                                                  # die Basis selbst: immer 1 (auch ohne Kerzen)
        out.update(ok=True, faktor=1.0, roh=1.0, grund="")
    return out


def akku_timing(kaeufe: list, ts, c, fenster_s: int = 7 * 86_400, bar: int = 1800) -> tuple:
    """Zeitpunkt-Kennzahl Q (KONZEPT 5, geändert 19.10. vor jedem echten Kurs): Mittel über die Käufe von ln(Mittel der Schlüsse der
    7 Tage NACH der Kaufkerze ÷ Kaufpreis) in %. Ohne Vorhersagekraft im Mittel nahe null (die Folgekurse kennen den Kauf nicht), bei
    Rücksetzern, die zurücklaufen, positiv. Käufe ohne volle 7 Tage danach zählen nicht. -> (Q in % oder None unter 5 Käufen, Zahl)"""
    ts = np.asarray(ts, dtype=np.int64); c = np.asarray(c, dtype=float); w = fenster_s // bar
    if not kaeufe or not len(ts):
        return None, 0
    i = np.searchsorted(ts, [k[0] for k in kaeufe], side="right")
    cs = np.concatenate(([0.0], np.cumsum(c)))
    F = [math.log((cs[j + w] - cs[j]) / w) - math.log(k[1]) for j, k in zip(i, kaeufe) if j + w <= len(c)]
    return ((float(np.mean(F)) * 100) if len(F) >= AKKU_MIN_VERGLEICH else None), len(F)


def akku_kerzen_tage(R: dict, K: dict) -> dict | None:
    """30-min-Kerzen (swing.db) -> Tageskerzen und Kennzahlen wie im Labor (hl_swing), dazu je Kerze σ₇ und Sperre des Vortags."""
    D = SW.daten_aufbereiten(K, None)
    if D is None:
        return None
    T, I = D["T"], D["I"]
    sig = I.sig; ma = I.sma(int(R["ma_tage"]))
    ts = np.asarray(T["bar_ts"], dtype=np.int64)                          # die bereinigten Kerzen von hl_swing (sortiert, eindeutig, gültig)
    d = (ts // 86_400 - int(T["d0"])).astype(np.int64) - 1
    ok = (d >= 0) & (d < len(sig))
    dd = np.where(ok, d, 0)
    with np.errstate(invalid="ignore"):
        s7 = np.where(ok, sig[dd], np.nan) * math.sqrt(int(R["fenster_tage"]))
        sp = np.where(ok, ma[dd], np.nan) * R["ma_faktor"]
    return {"ts": ts, "o": np.asarray(T["bar_o"], dtype=float), "h": np.asarray(T["bar_h"], dtype=float),
            "l": np.asarray(T["bar_l"], dtype=float), "c": np.asarray(T["bar_c"], dtype=float), "s7": s7, "sperre": sp}


def akku_surrogat(K: dict, rng) -> dict:
    """Vorzeichen-Surrogat der 30-min-Renditen (Drift und Schwankung bleiben, Abfolge zufällig; wie U141): r* = μ + s·(r − μ);
    Dochte (Hoch/Tief über bzw. unter Eröffnung und Schluss) bleiben je Kerze."""
    o = np.asarray(K["o"], dtype=float); c = np.asarray(K["c"], dtype=float); h = np.asarray(K["h"], dtype=float); l = np.asarray(K["l"], dtype=float)
    lc = np.log(c); r = np.diff(lc, prepend=math.log(o[0])); mu = float(np.mean(r))
    r2 = mu + rng.choice((-1.0, 1.0), size=len(r)) * (r - mu)
    c2 = np.exp(math.log(o[0]) + np.cumsum(r2)); o2 = np.concatenate(([o[0]], c2[:-1]))
    with np.errstate(divide="ignore", invalid="ignore"):
        oben = np.maximum(np.log(h) - np.maximum(np.log(o), lc), 0.0); unten = np.maximum(np.minimum(np.log(o), lc) - np.log(l), 0.0)
    return {"ts": np.asarray(K["ts"], dtype=np.int64), "o": o2, "h": np.maximum(o2, c2) * np.exp(oben), "l": np.minimum(o2, c2) * np.exp(-unten),
            "c": c2, "v": np.asarray(K.get("v", np.ones(len(c))), dtype=float)}


def akku_rueckblick_coin(R: dict, K: dict, surrogate: int = AKKU_SURROGATE, seed: int = 180) -> dict:
    """KONZEPT 5: Regel ohne Heatmap auf den 30-min-Kerzen eines Coins; Vorteil gegen Zufallszeiten und gleichmäßig, je Hälfte, je Jahr;
    dazu die Vorzeichen-Surrogate: Wie groß ist derselbe Vorteil auf Wegen ohne Vorhersagekraft? (p = Anteil mit Vorteil ≥ echt)."""
    A = akku_kerzen_tage(R, K)
    if A is None:
        return {"ok": False, "grund": "keine verwertbaren Kerzen"}
    kaeufe, erl = akku_regel_kerzen(R, A["ts"], A["o"], A["h"], A["l"], A["c"], A["s7"], A["sperre"])
    gueltig = np.nonzero(np.isfinite(A["s7"]) & np.isfinite(A["sperre"]))[0]
    if not len(gueltig):
        return {"ok": False, "grund": f"keine {R['ma_tage']}-Tage-Linie"}
    t_ab, t_bis = int(A["ts"][gueltig[0]]), int(A["ts"][-1])
    usd, geb = R["usd"], R["geb"]
    px = np.array([k[1] for k in kaeufe]) if kaeufe else np.zeros(0)
    menge = float(np.sum((usd - usd * geb) / px)) if len(px) else 0.0
    out = {"ok": True, "ab": t_ab, "bis": t_bis, "n": len(kaeufe), "eingesetzt": usd * len(kaeufe), "menge": menge,
           "einstand": (usd * len(kaeufe) / menge) if menge else None, "letzter_kurs": float(A["c"][-1]),
           "wert": menge * float(A["c"][-1]), "je_art": {a: sum(1 for k in kaeufe if k[2] == a) for a in ("A1", "A3")}}
    out["gewinn_pct"] = (out["wert"] / out["eingesetzt"] - 1) * 100 if out["eingesetzt"] else None
    out["vergleich"] = akku_vergleich(px, A["c"][erl], seed=seed)
    mitte = t_ab + (t_bis - t_ab) // 2; out["mitte"] = mitte
    out["haelften"] = []
    for a, b in ((t_ab, mitte), (mitte, t_bis + 1)):
        kk = [k[1] for k in kaeufe if a <= k[0] < b]; mm = erl & (A["ts"] >= a) & (A["ts"] < b)
        out["haelften"].append(akku_vergleich(kk, A["c"][mm], seed=seed + 1))
    jahre: dict = {}
    for t, p, a in kaeufe:
        jahre.setdefault(time.gmtime(t).tm_year, []).append(p)
    out["jahre"] = {j: {"n": len(v), "einstand": len(v) / float(np.sum(1.0 / np.asarray(v)))} for j, v in sorted(jahre.items())}
    q0, nq = akku_timing(kaeufe, A["ts"], A["c"]); out["timing"] = {"q": q0, "n": nq}
    out["timing_haelften"] = [akku_timing([k for k in kaeufe if a <= k[0] < b], A["ts"], A["c"])[0] for a, b in ((t_ab, mitte), (mitte, t_bis + 1))]
    if q0 is not None and surrogate:
        rng = np.random.default_rng(seed + 7); qs = []; vs = []
        for _ in range(int(surrogate)):
            S = akku_surrogat(K, rng); A2 = akku_kerzen_tage(R, S)
            if A2 is None:
                continue
            k2, e2 = akku_regel_kerzen(R, A2["ts"], A2["o"], A2["h"], A2["l"], A2["c"], A2["s7"], A2["sperre"])
            q2, _ = akku_timing(k2, A2["ts"], A2["c"])
            if q2 is not None:
                qs.append(q2)
            v2 = akku_vergleich([k[1] for k in k2], A2["c"][e2], ziehungen=400, seed=int(rng.integers(1 << 30)))
            if v2 is not None:
                vs.append(v2["vorteil_pct"])
        if len(qs) >= 20:
            qs_ = np.asarray(qs)
            out["surrogat"] = {"n": len(qs), "median": float(np.median(qs_)), "band": [float(np.quantile(qs_, 0.05)), float(np.quantile(qs_, 0.95))],
                               "p": float((1 + np.sum(qs_ >= q0)) / (1 + len(qs)))}
        if len(vs) >= 20:
            out["surrogat_vorteil"] = {"n": len(vs), "median": float(np.median(vs)), "band": [float(np.quantile(vs, 0.05)), float(np.quantile(vs, 0.95))]}
    s_ = out.get("surrogat")
    out["timing_beleg"] = bool(s_ and s_["p"] < 0.05 and all(x is not None and x > s_["median"] for x in out["timing_haelften"]))
    return out


def strategie_coin_tabelle(st, now: int, K: list | None = None, wechsel: dict | None = None) -> list:
    """
    23.68 (U161): je Strategie und Coin Trades (Blöcke), Treffer, Ø netto, Summe USD, Gebühren und Ø Abstand zur Buchmitte Ein+Aus
    (aus kennzahlen, dieselben Zahlen wie die Strategie-Tabelle). XMR zusätzlich vor und nach dem Gebührenwechsel (U160) getrennt, geteilt
    nach dem EINSTIEG: ab dem Wechsel eröffnete Trades zahlen nur normale Gebühren; ein Trade über den Wechsel zählt zu „vor“. Der Bestand
    eines Grids gehört zu „nach“ (er ist ein heutiger Stand). Summe über die Coins = Summe der Strategie.
    """
    K = K if K is not None else kennzahlen(st, now)
    w = (wechsel or {}).get("XMR")
    ab = int(w["ab"]) if w else None
    zeilen = []
    for k in K:
        if not k.get("n") and not k.get("bestand_usd"):
            continue
        for c, v in sorted((k.get("je_coin") or {}).items()):
            basis = {"sid": k["sid"], "titel": k["titel"], "aktiv": k["aktiv"], "coin": c, "teil": ""}
            if c == "XMR" and ab is not None:
                block_s = int(float(k["regeln"].get("h", 4)) * 3600) if k.get("name") not in GRID_NAMEN else 86_400
                tr = [{"coin": c, "eroeffnet": r[0], "geschlossen": r[1], "netto_usd": r[2] or 0.0, "netto_pct": r[3] or 0.0, "mae_pct": r[4] or 0.0,
                       "gebuehren": r[5] or 0.0, "funding": r[6] or 0.0, "slip": ((r[7] or 0.0) + (r[8] or 0.0)) if r[7] is not None else None,
                       "notional": r[9] or NOTIONAL}
                      for r in st.execute("SELECT eroeffnet, geschlossen, netto_usd, netto_pct, mae_pct, gebuehr_ein + gebuehr_aus, funding, "
                                          "slip_ein, slip_aus, notional FROM labor_position WHERE sid=? AND coin=? AND status='geschlossen' "
                                          "ORDER BY geschlossen", (k["sid"], c))]
                for teil, liste, extra in (("vor", [t for t in tr if t["eroeffnet"] < ab], 0.0),
                                           ("nach", [t for t in tr if t["eroeffnet"] >= ab], v.get("bestand_usd") or 0.0)):
                    if not liste and not extra:
                        continue
                    s_ = _stat(liste, k["erstellt"], now, 1.0, block_s=block_s, summe_extra=extra)
                    zeilen.append(dict(basis, teil=teil, **{f: s_[f] for f in ("n", "n_eff", "treffer", "mittel_pct", "summe_usd", "gebuehren_usd", "slip_bps")}))
                continue
            zeilen.append(dict(basis, **{f: v.get(f) for f in ("n", "n_eff", "treffer", "mittel_pct", "summe_usd", "gebuehren_usd", "slip_bps")}))
    return zeilen


def grid_zustand(st) -> dict:
    """Gespeicherter Grid-Zustand je „sid|coin“ (Modus, Stufen, Notlinie, Halten, Pause, Zähler) der aktiven Grid-Strategien -- für
    Übersicht, Chart und Bericht (Stand des letzten Takts)."""
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
        g = (json.loads(r[0]) if r and r[0] else {}).get("g") or {}
        aktiv = {x[0] for x in st.execute("SELECT sid FROM labor_strategie WHERE aktiv=1 AND name IN (?, ?)", GRID_NAMEN)}
    except (sqlite3.Error, ValueError, AttributeError):
        return {}
    return {k: v for k, v in g.items() if isinstance(v, dict) and k.split("|")[0] in aktiv}


_LIQ_SQL =(("hl", "liquidations", "px*sz", True), ("binance", "bnc_liquidations", "notional", False), ("andere", "ext_liquidations", "notional", False))


def _liq_seite(side, hl: bool) -> str:
    return ("long" if str(side).upper().startswith("A") else "short") if hl else ("long" if str(side).lower() == "long" else "short")


def liquidationen(con, coin: str, t0: int, t1: int) -> dict:
    """USD je liquidierter Seite (long = Zwangsverkauf, short = Zwangskauf) aus Hyperliquid, Binance und den übrigen Börsen."""
    out = {"long": 0.0, "short": 0.0, "hl": 0.0, "binance": 0.0, "andere": 0.0}
    for q, tab, expr, hl in _LIQ_SQL:
        try:
            for side, usd in con.execute(f"SELECT side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? AND ts<? GROUP BY side", (coin, t0, t1)):
                usd = float(usd or 0.0); out[_liq_seite(side, hl)] += usd; out[q] += usd
        except sqlite3.Error:
            pass
    return out


def liq_schwellen(con, coin: str, now: int) -> dict:
    """Je liquidierter Seite: max(95.-Perzentil der 15-min-Summen der letzten 7 Tage, 3 × Median, 50k USD)."""
    t0 = now - 7 * 86_400; eimer = {"long": {}, "short": {}}
    for _q, tab, expr, hl in _LIQ_SQL:
        try:
            for b, side, usd in con.execute(f"SELECT ts/900, side, SUM({expr}) FROM {tab} WHERE coin=? AND ts>=? GROUP BY 1, 2", (coin, t0)):
                s = _liq_seite(side, hl); eimer[s][b] = eimer[s].get(b, 0.0) + float(usd or 0.0)
        except sqlite3.Error:
            pass
    out = {}
    for seite, d in eimer.items():
        w = sorted(list(d.values()) + [0.0] * max(0, 7 * 96 - len(d)))
        out[seite] = max(w[int(0.95 * (len(w) - 1))], 3 * w[len(w) // 2], 50_000.0)
    return out


# ------------------------------------------------------------------------------------------------ Signale
def _markt(seite, grund, werte=None, **kw):
    return dict({"typ": "markt", "seite": seite, "grund": grund, "werte": werte or {}}, **kw)


def _wert(E, quelle, schluessel, now):
    d = E.get("treiber" if quelle == "treiber" else "familien") or {}
    v = d.get(schluessel)
    if not v or now - v[1] > FRISCH_S[quelle]:
        return None
    return v[0]


def sig_schwelle(S, E, coin, now, zs):
    R = S["regeln"]; v = _wert(E, R["quelle"], R["schluessel"], now)
    if v is None:
        return []
    s = R["schwelle"]
    if v >= s:
        seite = "long"
    elif v <= -s:
        seite = "short"
    else:
        return []
    if R.get("invert"):
        seite = _gegen(seite)
    return [_markt(seite, f"{R['schluessel']} {v:+.2f} (Schwelle ±{s:g})" + (" — dagegen" if R.get("invert") else ""),
                   {R["schluessel"]: round(v, 3)})]


def sig_prognose(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]
    if not P or now - P["ts"] > FRISCH_S["prognose"]:
        return []
    if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
        return []
    p = P.get(R["feld"])
    if p is None:
        return []
    d = float(p) - 0.5
    if abs(d) < R["schwelle"]:
        return []
    etikett = {"p_up_v2": "v2", "p_fusion": "Fusion"}.get(R["feld"], "v1")
    return [_markt("long" if d > 0 else "short", f"{etikett}: P(aufwärts 4 h) {float(p) * 100:.1f} %",
                   {"p_up": round(float(p), 4), "bias": P.get("bias")})]


def fusion_vorsprung(S, E, coin, now) -> dict:
    """23.42: Vorsprung der Fusionsprognose gegen die Kosten eines Hin- und Rückwegs zum Marktpreis. Vorsprung = |2p − 1| · E|r 4 h|
    (Herleitung in hl_fusion: so viel bringt ein Richtungsurteil mit Trefferquote p im Mittel), Kosten = Taker-Gebühr beider Seiten
    (gebuehr(): 23.34–23.67 XMR doppelt, seit 23.68 normal) plus der Abstand zur Buchmitte einer Markt-Order von NOTIONAL in beide
    Richtungen, aus dem aktuellen Buch."""
    P = E.get("prognose"); R = S["regeln"]; b = E.get("preis")
    if not P or now - P["ts"] > FRISCH_S["prognose"]:
        return {"grund": "keine frische Prognose"}
    p, er = P.get(R["feld"]), P.get("er_4")
    if p is None:
        return {"grund": "keine Fusionszahl in der Prognose"}
    if er is None or float(er) <= 0:
        return {"grund": "keine mittlere 4-h-Bewegung (Kostenschwelle)"}
    if not b or not b.get("mid"):
        return {"grund": "kein Orderbuch"}
    p, er = float(p), float(er)
    if p == 0.5:
        return {"grund": "Fusion genau 50 %"}
    seite = "long" if p > 0.5 else "short"; kauf = seite == "long"
    _, bps_ein = taker_preis(b, kauf, NOTIONAL); _, bps_aus = taker_preis(b, not kauf, NOTIONAL)
    kosten = 2 * gebuehr(coin, GEB_TAKER) + (bps_ein + bps_aus) / 1e4
    vorsprung = abs(2 * p - 1) * er
    return {"p": p, "er": er, "seite": seite, "kosten": kosten, "vorsprung": vorsprung, "handeln": vorsprung >= R["puffer"] * kosten}


def sig_fusion(S, E, coin, now, zs):
    v = fusion_vorsprung(S, E, coin, now)
    if not v.get("handeln"):
        return []
    return [_markt(v["seite"], f"Fusion {v['p'] * 100:.1f} %: Vorsprung {v['vorsprung'] * 100:.3f} % ≥ {S['regeln']['puffer']:g} × Kosten "
                               f"{v['kosten'] * 100:.3f} %",
                   {"p_fusion": round(v["p"], 4), "er_4": round(v["er"], 6), "kosten": round(v["kosten"], 6), "vorsprung": round(v["vorsprung"], 6)})]


def sig_kipppunkt(S, E, coin, now, zs):
    """23.43: Durchbruch durch einen Kipppunkt der Kaskaden-Gleichung. Kipppunkt und Ende stehen als Kurs im Payload der jüngsten
    Prognose (höchstens 30 min alt); durchbrochen heißt: im vorigen Takt diesseits, jetzt jenseits. Einstieg zum Marktpreis in
    Richtung der Kaskade, Ziel ihr Ende, nur wenn der Weg dorthin die Kosten mit Puffer deckt; je Kipppunkt einmal."""
    P = E.get("prognose"); R = S["regeln"]; b = E.get("preis")
    if not P or now - P["ts"] > FRISCH_S["prognose"] or not b or not b.get("mid"):
        zs.pop("_mid", None)
        return []
    mid = float(b["mid"]); vorher = zs.get("_mid"); zs["_mid"] = mid
    if vorher is None:
        return []
    for s, seite, kipp, ziel in (("ab", "short", P.get("kipp_ab"), P.get("ende_ab")), ("auf", "long", P.get("kipp_auf"), P.get("ende_auf"))):
        if not kipp or not ziel:
            continue
        kipp, ziel = float(kipp), float(ziel)
        durch = (vorher > kipp >= mid) if s == "ab" else (vorher < kipp <= mid)
        if not durch or zs.get(f"_genutzt_{s}") == round(kipp, 8):
            continue
        zs[f"_genutzt_{s}"] = round(kipp, 8)                                    # dieser Kipppunkt ist verbraucht, auch ohne Einstieg
        if (s == "ab" and ziel >= mid) or (s == "auf" and ziel <= mid):
            continue                                                            # die Kaskade ist schon am Ende (schneller als der Takt)
        kauf = seite == "long"
        _, bps_ein = taker_preis(b, kauf, NOTIONAL); _, bps_aus = taker_preis(b, not kauf, NOTIONAL)
        kosten = 2 * gebuehr(coin, GEB_TAKER) + (bps_ein + bps_aus) / 1e4
        weg = abs(math.log(ziel / mid))
        if weg < R["puffer"] * kosten:
            continue
        s1 = E["sigma1h"]
        sl = kipp * (1 + R["sl"] * s1) if s == "ab" else kipp * (1 - R["sl"] * s1)
        return [_markt(seite, f"Kurs durch den {'unteren' if s == 'ab' else 'oberen'} Kipppunkt {kipp:.6g}: Kaskade bis {ziel:.6g} berechnet, "
                              f"Weg {weg * 100:.2f} % gegen {R['puffer']:g} × Kosten {kosten * 100:.3f} %",
                       {"kipp": kipp, "ende": ziel, "weg": round(weg, 5), "kosten": round(kosten, 6)},
                       sl_px=sl, tp_px=ziel, h=R["h"], halten_s=R["h"] * 3600)]
    return []


def sig_empfehlung(S, E, coin, now, zs):
    P = E.get("prognose"); R = S["regeln"]; b = E["preis"]
    if not P or now - P["ts"] > FRISCH_S["prognose"] or P.get("bias") is None:
        return [{"typ": "storno", "grund": "keine frische Prognose"}]
    bias = float(P["bias"]); kp, vp = P.get("buy_px"), P.get("sell_px"); s12 = E["sigma4h"] * math.sqrt(3)
    if bias >= 0.12 and kp and kp < b["bid"]:
        tp = vp if (vp and vp > kp * 1.002) else kp * (1 + 2 * s12)
        return [{"typ": "storno", "seite": "short", "grund": "Bias jetzt bullisch"},
                {"typ": "limit", "seite": "long", "preis": float(kp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Kaufpreis {kp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    if bias <= -0.12 and vp and vp > b["ask"]:
        tp = kp if (kp and kp < vp * 0.998) else vp * (1 - 2 * s12)
        return [{"typ": "storno", "seite": "long", "grund": "Bias jetzt bärisch"},
                {"typ": "limit", "seite": "short", "preis": float(vp), "gueltig_s": 12 * 3600, "sl_rel": R["sl"] * s12, "tp_px": float(tp),
                 "halten_s": 12 * 3600, "toleranz": 0.001, "grund": f"Bias {bias:+.2f}: empfohlener Verkaufspreis {vp:.6g}, Ziel {tp:.6g}",
                 "werte": {"bias": bias, "kauf": kp, "verkauf": vp}}]
    return [{"typ": "storno", "grund": "Bias neutral oder Preis schon überschritten"}]


def _sig_kopie(S, E, quelle, etikett):
    """Kopier-Strategien (Darwin-Liste, seit 23.39 auch Elite): Einstieg je erkannter Eröffnung, Folge-Ausstieg beim Schließen."""
    R = S["regeln"]; inv = R.get("invert"); akts = []
    for f in (E.get(quelle) or {}).get("neu", []):
        kurz = f"{f['addr'][:6]}…{f['addr'][-4:]}"
        if f["art"] == "auf" and f["usd"] >= R["min_usd"]:
            stuecke = (f" in {f['n']} Fills über {max(1, round((f['ts'] - f.get('seit', f['ts'])) / 60))} min" if (f.get("n") or 1) > 1 else "")
            akts.append(_markt(_gegen(f["seite"]) if inv else f["seite"],
                               f"{etikett} #{f.get('rang') or '?'} {kurz} eröffnet {f['seite']} ({f['usd'] / 1e3:.0f}k{stuecke}, Ø {f['px']:.6g})"
                               + (" — wir handeln dagegen" if inv else ""),
                               {"konto": f["addr"], "usd": round(f["usd"]), "rang": f.get("rang"), "fills": f.get("n")},
                               folge={"addr": f["addr"], "seite_konto": f["seite"]}, h=R["h"]))
        elif f["art"] == "zu":
            anteil = (f" ({f['usd'] / 1e3:.0f}k von {f['von_usd'] / 1e3:.0f}k)" if f.get("von_usd") else "")
            akts.append({"typ": "folge_aus", "addr": f["addr"], "seite_konto": f["seite"], "grund": f"{etikett}-Konto {kurz} schließt {f['seite']}{anteil}"})
    return akts


def sig_darwin(S, E, coin, now, zs):
    return _sig_kopie(S, E, "darwin", "Darwin")


def sig_elite(S, E, coin, now, zs):
    return _sig_kopie(S, E, "elite", "Elite")


def sig_kaskade(S, E, coin, now, zs):
    K = E.get("kaskade") or {}; R = S["regeln"]; b = E["preis"]
    if not K.get("aktiv") or zs.get("kaskade_id") == K.get("id"):
        return []
    ab = K["richtung"] == "ab"
    if R["modus"] == "fortsetzung":
        zs["kaskade_id"] = K["id"]
        s1 = E["sigma1h"]; p = b["mid"]
        return [_markt("short" if ab else "long",
                       f"Kaskade {'abwärts' if ab else 'aufwärts'} {K.get('z_start') or 0:+.1f} σ in 15 min, {(K.get('liq_usd') or 0) / 1e6:.2f} Mio "
                       "liquidiert — mit der Bewegung", {"z": K.get("z_start"), "liq": round(K.get("liq_usd") or 0)},
                       sl_px=p * (1 + s1) if ab else p * (1 - s1), tp_px=p * (1 - 1.5 * s1) if ab else p * (1 + 1.5 * s1),
                       h=R["h"], halten_s=R["h"] * 3600)]
    if now - K["t"] > 1800:
        return []
    k = E.get("kerze")
    if not k or k[0] < K["t"] // 60 * 60:
        return []
    s15 = E["sigma15"]; ext = K["extrem"]
    if ab and k[4] > k[1] and k[4] >= ext * (1 + 0.25 * s15):
        tp = ext + 0.5 * (K["p_start"] - ext); zs["kaskade_id"] = K["id"]
        if tp <= b["ask"]:
            return []
        return [_markt("long", f"Gegenkerze nach der Kaskade (Tief {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"tief": ext, "start": K["p_start"]}, sl_px=ext * (1 - 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    if not ab and k[4] < k[1] and k[4] <= ext * (1 - 0.25 * s15):
        tp = ext - 0.5 * (ext - K["p_start"]); zs["kaskade_id"] = K["id"]
        if tp >= b["bid"]:
            return []
        return [_markt("short", f"Gegenkerze nach dem Squeeze (Hoch {ext:.6g}, Start {K['p_start']:.6g}) — Ziel halber Rücklauf",
                       {"hoch": ext, "start": K["p_start"]}, sl_px=ext * (1 + 0.5 * s15), tp_px=tp, h=R["h"], halten_s=R["h"] * 3600)]
    return []


def sig_docht(S, E, coin, now, zs):
    """Limit knapp jenseits des nächsten großen Clusters. Eine liegende Order bleibt, solange ihr Cluster im Snapshot steht --
    auch wenn der Kurs schon näher als 0,5 σ herangelaufen ist (genau dann soll sie ja gefüllt werden)."""
    D = E.get("docht") or {}; R = S["regeln"]; s1 = E["sigma1h"]; akts = []
    bestehend = {seite: preis for seite, preis in zs.get("_orders", [])}
    for seite, key in (("long", "unten"), ("short", "oben")):
        alle = [c for c in (D.get(key + "_alle") or []) if c["anteil"] >= R["min_anteil"]]
        alt = bestehend.get(seite)
        if alt:
            c_alt = alt / (1 - R["abstand"] * s1) if seite == "long" else alt / (1 + R["abstand"] * s1)
            if any(abs(math.log(c["px"] / c_alt)) <= 0.5 * s1 for c in alle):
                continue
        neu = [c for c in alle if 0.5 <= c["sigma"] <= 3.0]
        c = min(neu, key=lambda c_: c_["sigma"]) if neu else None
        if not c:
            if alt:
                akts.append({"typ": "storno", "seite": seite, "grund": "Cluster nicht mehr im Snapshot"})
            continue
        preis = c["px"] * (1 - R["abstand"] * s1) if seite == "long" else c["px"] * (1 + R["abstand"] * s1)
        akts.append({"typ": "limit", "seite": seite, "preis": preis, "gueltig_s": 4 * 3600, "sl_rel": R["sl"] * s1, "tp_rel": R["tp"] * s1,
                     "halten_s": R["h"] * 3600, "toleranz": 0.25 * s1,
                     "grund": f"{'Long' if seite == 'long' else 'Short'}-Liquidationscluster {c['usd'] / 1e6:.2f} Mio bei {c['px']:.6g} "
                              f"({c['anteil'] * 100:.0f} % des Stundenvolumens, {c['sigma']:.1f} σ)",
                     "werte": {"cluster": c["px"], "usd": round(c["usd"]), "anteil": round(c["anteil"], 3)}})
    return akts


def sig_magnet(S, E, coin, now, zs):
    A = E.get("anker") or {}; R = S["regeln"]; a = A.get("A")
    if a is None or abs(a) < R["a_min"] or not A.get("ts") or now - A["ts"] > FRISCH_S["anker"]:
        return []
    dom = A.get("oben") if a > 0 else A.get("unten")
    if not dom or dom["anteil_volumen"] < R["min_anteil"] or not (0.5 <= dom["abstand_sigma"] <= 2.0):
        return []
    s1 = E["sigma1h"]; p = E["preis"]["mid"]
    return [_markt("long" if a > 0 else "short",
                   f"Anker A {a:+.2f}: Cluster {dom['usd'] / 1e6:.2f} Mio bei {dom['px']:.6g} ({dom['abstand_sigma']:.1f} σ, "
                   f"{dom['anteil_volumen'] * 100:.0f} % des Stundenvolumens)", {"A": a, "cluster": dom["px"]},
                   sl_px=p * (1 - E["sigma4h"]) if a > 0 else p * (1 + E["sigma4h"]),
                   tp_px=dom["px"] * (1 - 0.1 * s1) if a > 0 else dom["px"] * (1 + 0.1 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_funding(S, E, coin, now, zs):
    f = E.get("funding"); R = S["regeln"]
    if not f or f.get("z") is None or now - f["ts"] > FRISCH_S["funding"]:
        return []
    if abs(f["z"]) < R["z"]:
        return []
    return [_markt("short" if f["z"] > 0 else "long", f"Funding {f['rate'] * 100:.4f} %/h, z {f['z']:+.1f} gegenüber 14 Tagen",
                   {"rate": f["rate"], "z": round(f["z"], 2)})]


def sig_ausbruch(S, E, coin, now, zs):
    R = S["regeln"]; w = (E.get("staerke") or {}).get("wert"); b = E["preis"]; s1 = E["sigma1h"]
    arm = zs.get("scharf")
    if arm and now - arm["t"] > 4 * 3600:
        zs.pop("scharf", None); arm = None
    if not arm:
        if w is not None and w >= R["schwelle"]:
            zs["scharf"] = {"t": now, "p": b["mid"], "w": round(w, 2)}
        return []
    d = math.log(b["mid"] / arm["p"]) / max(s1, 1e-6)
    if abs(d) < 1.0:
        return []
    zs.pop("scharf", None)
    return [_markt("long" if d > 0 else "short", f"Ausbruch {d:+.1f} σ(1 h) seit {_uhr(arm['t'])} (Stärke {arm['w']:.2f})",
                   {"ausgang": arm["p"], "staerke": arm["w"]}, sl_px=arm["p"],
                   tp_px=arm["p"] * (1 + 2.5 * s1) if d > 0 else arm["p"] * (1 - 2.5 * s1), h=R["h"], halten_s=R["h"] * 3600)]


def sig_twap(S, E, coin, now, zs):
    A = E.get("adressstrom") or {}; R = S["regeln"]; w = A.get("tw_anteil")
    if w is None or not A.get("ts") or now - A["ts"] > FRISCH_S["adressstrom"] or abs(w) < R["anteil"]:
        return []
    return [_markt("long" if w > 0 else "short", f"TWAP-Netto 60 min {A['tw_netto_h'] / 1e6:+.2f} Mio = {w * 100:+.1f} % des Stundenvolumens",
                   {"tw_netto": round(A["tw_netto_h"]), "anteil": round(w, 4)})]


def sig_zufall(S, E, coin, now, zs):
    R = S["regeln"]; dt = max(1, min(now - int(zs.get("_t_letzt", now - TAKT_S)), 3600)); zs["_t_letzt"] = now
    rng = random.Random(f"{S['sid']}|{coin}|{now}")
    if rng.random() < min(1.0, dt / (R["rate_h"] * 3600)):
        return [_markt("long" if rng.random() < 0.5 else "short", "Zufall (Kontrolle)")]
    return []


def sig_halten(S, E, coin, now, zs):
    return [_markt("long", "Vergleich: immer Long", h=168, halten_s=168 * 3600)]


def sig_swing(S, E, coin, now, zs):
    """
    23.61 (U140): Swing-Strategien. Entscheidung einmal je Tag nach dem Tagesschluss aus swing.db (hl_swing: dieselben Funktionen wie
    die Vorprüfung auf der Historie). Offene Position: einmal je Entscheidungstag Nachzieh-Stop bzw. Signal-Ausstieg (zur nächsten
    Gelegenheit, ohne Pause -- am selben Schluss darf die Gegenrichtung folgen). Einstieg nur ohne Position, mit frischen Tageskerzen,
    höchstens 6 h nach dem Schluss und einmal je Tag (zs „letzter_einstieg“ setzt _signale). Zufall der Kontrollen je Tag fest
    (Kennung|Coin|Tag).
    """
    W = E.get("swing") or {}
    if not W.get("ok"):
        return []
    R = S["regeln"]; T, I, d, tag_ts = W["T"], W["I"], W["d"], W["tag_ts"]
    akts = []
    pos = zs.get("_pos")
    if pos:
        if zs.get("pflege_tag") != tag_ts:
            zs["pflege_tag"] = tag_ts
            res = SW.nachfuehren(R, T, I, d, {"seite": pos["seite"], "e": SW.tag_index(T, int(pos["eroeffnet"])), "sl": pos.get("sl")})
            if res.get("aus"):
                akts.append({"typ": "aus", "grund": res["grund"]})
            elif res.get("sl") is not None:
                akts.append({"typ": "stop_nachziehen", "sl": res["sl"], "grund": res["grund"]})
        if not any(a["typ"] == "aus" for a in akts):
            return akts
    if not W.get("frisch") or now - (tag_ts + SW.TAG) > SW.EIN_FENSTER_S or int(zs.get("letzter_einstieg", 0)) >= tag_ts + SW.TAG:
        return akts
    rng = random.Random(f"{S['sid']}|{coin}|{tag_ts}")
    sig = SW.einstieg(R, T, I, d, (rng.random(), rng.random()))
    b = E.get("preis") or {}
    if not sig or not b.get("mid"):
        return akts
    P = SW.plan(sig, float(b["mid"]))
    if R.get("groesse") == "fest":                    # 23.68 (U164): feste Größe wie alle; Stop, Ziel und Ausstiege bleiben wie geplant
        P = dict(P, notional=NOTIONAL, risiko=NOTIONAL * abs(1.0 - P["sl"] / float(b["mid"])))
    werte = dict(sig["werte"], risiko_usd=round(P["risiko"], 2), sigma_tag=round(sig["sigma"], 6), tag=SW._datum(tag_ts))
    akts.append(_markt(sig["seite"], sig["grund"], werte, sl_px=P["sl"], tp_px=P["tp"], h=24, halten_s=int(sig["max_tage"]) * SW.TAG,
                       notional=round(P["notional"], 2)))
    return akts


def sig_wende(S, E, coin, now, zs):
    """
    23.83 (U226, KONZEPT_Wende.md 5): Extrem-Wende nach Video, nur BTC. Entscheidung nach jedem 8-h-Schluss aus swing.db (hl_wende:
    dieselben Funktionen wie die Studie; im Eingang nur das Signal je Lesart, keine Reihen); Einstieg zum Marktpreis höchstens 60 min nach
    dem Schluss und einmal je Signal (zs „letzter_einstieg“ setzt _signale); Stop 0,1 % jenseits des Extrems, Ziel 1R und Risiko ab der
    Mitte jetzt (wie sig_swing), höchstens 120 Tage. Kein Einstieg, wenn der Stop näher als 5 bps an der Mitte oder näher als die Hälfte
    des Abstands am Schluss liegt (sonst ließe _eroeffnen einen Stop auf der falschen Seite still fallen, oder 1R wäre winzig) -- dann
    entfällt das Signal ganz (wie in der Historie: Eröffnung jenseits des Stops -> kein Trade). Eine offene Position führt die Engine (Stop,
    Ziel, Zeit); ein Signal, bei dessen Schluss oder danach eine Position offen war, entfällt -- auch wenn sie binnen 60 min schließt
    (KONZEPT 2.9, wie labor_abgleich; zweite Durchsicht M2). Verfallene und ausgelassene Signale zählt zs für die Tafel.
    """
    R = S["regeln"]
    if coin != R.get("coin", WE.COIN):
        return []
    if zs.get("_pos"):
        zs["pos_bis"] = int(now)                                         # zuletzt mit offener Position gesehen (bleibt über Neustarts)
    W = E.get("wende") or {}
    if not W.get("ok"):
        return []
    t_s = int(W["t_schluss"]); la = R.get("lesart", "rang")
    sig = (W.get("signal") or {}).get(la)
    if sig and int(zs.get("pos_bis", 0)) >= t_s and int(zs.get("letzter_einstieg", 0)) < t_s:
        if zs.get("ausgelassen") != t_s:                                 # Position beim Schluss oder danach offen: Signal entfällt
            zs["ausgelassen"] = t_s; zs["n_ausgelassen"] = int(zs.get("n_ausgelassen", 0)) + 1
        zs["gesehen"] = t_s                                              # gesehen, nicht verfallen
        return []
    if zs.get("_pos"):
        return []
    if not W.get("frisch") or int(now) - t_s > int(R.get("ein_fenster_s", WE.EIN_FENSTER_S)):
        if sig and zs.get("gesehen") != t_s and int(zs.get("letzter_einstieg", 0)) < t_s:
            zs["verfallen"] = t_s; zs["n_verfallen"] = int(zs.get("n_verfallen", 0)) + 1     # zu spät gesehen: Signal verfallen
        zs["gesehen"] = t_s
        return []
    zs["gesehen"] = t_s
    if int(zs.get("letzter_einstieg", 0)) >= t_s:
        return []                                                        # je Signal einmal
    if zs.get("jenseits") == t_s:
        return []                                                        # beim ersten Prüfen jenseits oder zu nah am Stop: entfallen
    b = E.get("preis") or {}
    if not sig or not b.get("mid"):
        return []
    mid = float(b["mid"]); stop = float(sig["stop"]); sv = 1 if sig["seite"] == "long" else -1
    r = abs(mid - stop)
    if (sv > 0 and mid <= stop) or (sv < 0 and mid >= stop) or r / mid < max(WE.LABOR_RAND, 0.5 * float(sig["abstand_schluss"])):
        zs["jenseits"] = t_s; zs["n_jenseits"] = int(zs.get("n_jenseits", 0)) + 1    # das Signal entfällt (einmal gezählt)
        return []
    tp = mid + sv * float(R["ziel_r"]) * r
    farbe = "rote" if sv < 0 else "blaue"
    werte = {"flip": WE._zeit(sig["k_ts"]), "extrem": round(sig["extrem"], 6), "stop": round(stop, 6), "abstand_pct": round(r / mid * 100, 3),
             "abstand_schluss_pct": round(float(sig["abstand_schluss"]) * 100, 3), "n_extrem": sig["n_extrem"], "lesart": la,
             "latenz_s": int(now) - t_s, "risiko_usd": round(NOTIONAL * r / mid, 2)}
    grund = (f"Extrem-Wende: {'bärischer' if sv < 0 else 'bullischer'} Flip EMA 8/89 an der 8-h-Kerze {WE._zeit(sig['k_ts'])} UTC nach "
             f"{sig['n_extrem']} {farbe} Kerze(n) (Extrem {sig['extrem']:.6g}); Stop {stop:.6g}, Ziel 1R {tp:.6g}")
    return [_markt(sig["seite"], grund, werte, sl_px=stop, tp_px=tp, h=int(R.get("h", 8)), halten_s=int(R["max_tage"]) * 86_400,
                   notional=NOTIONAL)]


def status_text(S, E, now, zs) -> str:
    """Was die Strategie in diesem Takt sieht -- für die Live-Tafel (Wert gegen Schwelle, fehlende Daten, scharf/ruhig)."""
    R = S["regeln"]; fn = S["fn"]
    if fn == "schwelle":
        v = _wert(E, R["quelle"], R["schluessel"], now)
        return "keine frischen Werte" if v is None else f"{v:+.2f} (Schwelle ±{R['schwelle']:g})"
    if fn in ("prognose", "empfehlung"):
        P = E.get("prognose")
        if not P or now - P["ts"] > FRISCH_S["prognose"]:
            return "keine frische Prognose"
        if fn == "empfehlung":
            return "Bias —" if P.get("bias") is None else f"Bias {float(P['bias']):+.2f} (Schwelle ±0,12)"
        if R["feld"] == "p_up_v2" and float(P.get("v2_version") or 0) < 2:
            return "v2 noch nicht scharf (Version < 2)"
        p = P.get(R["feld"])
        return "—" if p is None else f"P(aufwärts) {float(p) * 100:.1f} % (Schwelle {50 - R['schwelle'] * 100:.0f} / {50 + R['schwelle'] * 100:.0f} %)"
    if fn == "fusion":
        v = fusion_vorsprung(S, E, E.get("coin"), now)
        if "kosten" not in v:
            return v.get("grund", "—")
        return (f"Fusion {v['p'] * 100:.1f} % · Vorsprung {v['vorsprung'] * 100:.3f} % gegen {R['puffer']:g} × Kosten {v['kosten'] * 100:.3f} %"
                + (" → handelt" if v["handeln"] else ""))
    if fn == "kipppunkt":
        P = E.get("prognose")
        if not P or now - P["ts"] > FRISCH_S["prognose"]:
            return "keine frische Prognose"
        t = [f"{wort} {float(P[k]):.6g} → {float(P[e]):.6g}" for wort, k, e in (("unten", "kipp_ab", "ende_ab"), ("oben", "kipp_auf", "ende_auf"))
             if P.get(k) and P.get(e)]
        return ("Kipppunkte: " + " · ".join(t)) if t else "kein Kipppunkt in Reichweite"
    if fn in ("darwin", "elite"):
        D = E.get(fn) or {}; su = D.get("summen") or {}
        top = max(su.values()) if su else 0.0
        return (f"{len(D.get('konten') or [])} Konten im Blick" + (f" · größte Eröffnung in {R.get('fenster_s', DARWIN_FENSTER_S) // 60} min "
                f"{top / 1e3:.1f}k (Schwelle {R['min_usd'] / 1e3:.0f}k)" if top else "") + (f", {len(D['neu'])} neue Trades" if D.get("neu") else ""))
    if fn == "kaskade":
        K = E.get("kaskade") or {}
        if K.get("aktiv"):
            return f"Kaskade {'abwärts' if K.get('richtung') == 'ab' else 'aufwärts'} seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}"
        return "keine Kursdaten" if K.get("z") is None else f"ruhig: 15 min {K['z']:+.1f} σ (Schwelle ±{KASKADE_Z:g})"
    if fn == "docht":
        D = E.get("docht") or {}
        t = [f"{'unten' if k == 'unten' else 'oben'} {D[k]['px']:.6g} ({D[k]['anteil'] * 100:.0f} %)" for k in ("unten", "oben") if D.get(k)]
        return ("Cluster " + ", ".join(t)) if t else "kein Cluster ≥ 10 % des Stundenvolumens in 0,5–3 σ"
    if fn == "magnet":
        A = E.get("anker") or {}
        return "kein Anker" if A.get("A") is None else f"A {A['A']:+.2f} (Schwelle ±{R['a_min']:g})"
    if fn == "funding":
        f = E.get("funding")
        return "keine Funding-Daten" if not f else (f"z {f['z']:+.1f} (Schwelle ±{R['z']:g})" if f.get("z") is not None else "Statistik im Aufbau")
    if fn == "ausbruch":
        a = zs.get("scharf")
        if a:
            return f"scharf seit {_uhr(a['t'])} bei {a['p']:.6g}"
        w = (E.get("staerke") or {}).get("wert")
        return "keine Stärke-Werte" if w is None else f"Stärke {w:.2f} (Schwelle {R['schwelle']:g})"
    if fn == "twap":
        w = (E.get("adressstrom") or {}).get("tw_anteil")
        return "wartet auf den Adress-Strom" if w is None else f"TWAP-Netto {w * 100:+.2f} % Vol. (Schwelle ±{R['anteil'] * 100:g} %)"
    if fn == "zufall":
        return f"zufällig, im Schnitt alle {R['rate_h']} h"
    if fn == "halten":
        return "immer Long"
    if fn == "swing":                                                             # 23.61
        return SW.status_text(S["name"], R, E.get("swing"), now)
    if fn == "wende":                                                             # 23.83 (U226)
        if E.get("coin") != R.get("coin", WE.COIN):
            return f"nur {R.get('coin', WE.COIN)}"
        t = WE.status_text(R, E.get("wende"), now)
        if zs.get("n_verfallen"):
            t += f" · {zs['n_verfallen']} Signal(e) verfallen (Daten erst nach 60 min gesehen), zuletzt {_uhr(zs['verfallen'])}"
        if zs.get("n_ausgelassen"):
            t += f" · {zs['n_ausgelassen']} Signal(e) ausgelassen (Position offen), zuletzt {_uhr(zs['ausgelassen'])}"
        if zs.get("jenseits"):
            t += (f" · {int(zs.get('n_jenseits', 1))} Signal(e) ausgelassen (Kurs zu nah am oder jenseits des Stops), zuletzt "
                  f"{_uhr(zs['jenseits'])}")
        return t
    return ""


SIGNALE = {"schwelle": sig_schwelle, "darwin": sig_darwin, "elite": sig_elite, "prognose": sig_prognose, "empfehlung": sig_empfehlung, "kaskade": sig_kaskade,
           "docht": sig_docht, "magnet": sig_magnet, "funding": sig_funding, "ausbruch": sig_ausbruch, "twap": sig_twap,
           "zufall": sig_zufall, "halten": sig_halten, "fusion": sig_fusion, "kipppunkt": sig_kipppunkt, "swing": sig_swing,
           "wende": sig_wende}


# ------------------------------------------------------------------------------------------------ Engine
POS_SPALTEN = ("id", "sid", "coin", "seite", "eroeffnet", "preis_ein", "notional", "menge", "gebuehr_ein", "sl", "tp", "ablauf",
               "geprueft_bis", "nur_stop_bis", "funding", "funding_bis", "mae_pct", "mfe_pct", "folge")


class Labor:
    def __init__(self, db: str, store: str | None = None, coins=COINS, notional: float = NOTIONAL, adressfluss: str | None = None,
                 nur: tuple | None = None, swing: str | None = None, welt: str = "B", tor=None):
        self.db = db; self.store = store or F.STORE; self.coins = tuple(coins); self.notional = float(notional)
        self.welt = welt; self.tor = tor                # 23.76 (U206): Welt A mit dem Tor der Notbremse; Welt B ohne (tor None)
        self.af_pfad = adressfluss or os.path.join(os.path.dirname(os.path.abspath(db)), "adressfluss.db")
        self.strategien = [s for s in strategien() if not nur or s["name"] in nur]
        self.nach_sid = {s["sid"]: s for s in self.strategien}
        self.cache: dict = {}; self.letzte: dict = {}; self.fehler: list = []; self.zyklen = 0; self.dauer = 0.0; self.t_letzt = None
        self._registriert = False
        self.z = None; self._z_txt = None          # Zustand im Speicher; in den Speicher geschrieben nur bei Änderung (Schreiblast)
        self.status: dict = {}                     # (sid, coin) -> was die Strategie in diesem Takt sieht (nur Anzeige)
        self.darwin_log: list = []                 # die letzten erkannten Darwin-Trades (nur Anzeige im Datenfluss)
        self.elite_log: list = []                  # 23.39: dasselbe für die Elite
        self.coin_start: dict = {}                 # 23.34: Start je Coin (labor_zustand „coins“), gesetzt beim Registrieren
        self.grid_strategien = [s for s in self.strategien if s["fn"] == "grid"]      # 23.40
        self.grid_sids = {s["sid"] for s in self.grid_strategien}
        self._grid_alt_ok: set = set()             # Coins, in denen Lose abgelöster Grid-Regelversionen schon geschlossen wurden
        self.swing_strategien = [s for s in self.strategien if s["fn"] == "swing"]       # 23.61 (U140)
        self.wende_strategien = [s for s in self.strategien if s["fn"] == "wende"]       # 23.83 (U226)
        self.swing_pfad = swing or SW.swing_pfad(db)
        self.akku_strategien = [s for s in self.strategien if s["fn"] == "akku"]          # 23.69 (U180)
        self.akku_status: dict = {}                # (sid, coin) -> Lage der Akkumulation im letzten Takt (nur Anzeige)

    # --- Verbindungen, Zustand, Protokoll
    def _con(self):
        return sqlite3.connect(f"file:{self.db}?mode=ro", uri=True, timeout=10)

    def _st(self):
        st = F.store_connect(self.store); schema(st)
        return st

    def _gecacht(self, key, ttl, now, fn):
        e = self.cache.get(key)
        if e and 0 <= now - e[0] < ttl:
            return e[1]
        v = fn(); self.cache[key] = (now, v)
        if len(self.cache) > 400:                  # Schlüssel mit Zeitstempel (Treiber-, Heatmap-Stand) laufen sonst auf
            for k in [k for k, e_ in self.cache.items() if now - e_[0] > 7200]:
                self.cache.pop(k, None)
        return v

    def _fehler(self, text):
        self.fehler = (self.fehler + [f"{time.strftime('%d.%m. %H:%M:%S')} {text}"])[-20:]

    def _zustand(self, st) -> dict:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
        try:
            z = json.loads(r[0]) if r and r[0] else {}
        except ValueError:
            z = {}
        z.setdefault("s", {}); z.setdefault("k", {})
        for k_ in ("darwin_tids", "darwin_ep", "elite_tids", "elite_ep", "g", "a"):     # 23.40: „g“ Grid; 23.69: „a“ Akkumulation
            if not isinstance(z.get(k_), dict):
                z[k_] = {}
        return z

    def _zustand_speichern(self, st, z, now) -> None:
        """Nur Bleibendes (Pausen, Kaskaden, scharfe Ausbrüche, gesehene Darwin-Schließungen, laufende Darwin-Eröffnungen), nur bei
        Änderung. Schlüssel mit Unterstrich sind flüchtig (z. B. der letzte Zufallstakt)."""
        for v_ in ("darwin", "elite"):                                              # 23.39: Elite wie Darwin
            z[f"{v_}_tids"] = {k: t for k, t in z[f"{v_}_tids"].items() if t >= now - 2 * DARWIN_FENSTER_S}   # länger als das Fenster
            z[f"{v_}_ep"] = {k: e for k, e in z[f"{v_}_ep"].items() if isinstance(e, dict) and int(e.get("t", 0)) >= now - DARWIN_EPISODE_S}
        s_ = {}
        for k, v in z["s"].items():
            w = {kk: vv for kk, vv in v.items() if not kk.startswith("_") and not (kk == "pause_bis" and vv < now)}
            if w:
                s_[k] = w
        # 23.40: Grid-Zustand je Strategie und Coin (Stufen, Modus, Halten, Pause, Kerzen-Stand); nur aktuelle Regelversionen
        g_ = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")} for k, v in z["g"].items()
              if isinstance(v, dict) and k.split("|")[0] in self.nach_sid}
        txt = _j({"s": s_, "k": z["k"], "darwin_tids": z["darwin_tids"], "darwin_ep": z["darwin_ep"], "elite_tids": z["elite_tids"],
                  "elite_ep": z["elite_ep"], "aufgeraeumt": z.get("aufgeraeumt", 0), "g": g_,
                  "a": {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")} for k, v in z["a"].items()       # 23.69 (U180)
                        if isinstance(v, dict) and k.split("|")[0] in self.nach_sid}})
        if txt != self._z_txt:
            st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('zustand', ?)", (txt,))
            self._z_txt = txt

    def _registrieren(self, st, now) -> None:
        if self._registriert:
            return
        for s in self.strategien:
            st.execute("INSERT OR IGNORE INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)",
                       (s["sid"], s["name"], s["titel"], s["gruppe"], _j(s["regeln"]), s["beschreibung"], now))
            st.execute("UPDATE labor_strategie SET aktiv=CASE WHEN sid=? THEN 1 ELSE 0 END WHERE name=?", (s["sid"], s["name"]))
        neu_start = not st.execute("SELECT 1 FROM labor_zustand WHERE k='start'").fetchone()
        if neu_start:
            st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(now),))
        # 23.68 (U160): Zeitpunkt des Gebührenwechsels einmal festhalten (Bericht, Gebühren-Prüfung, Dashboard, Teilung in U161)
        wechsel = {c: {"vorher": f, "jetzt": GEB_FAKTOR.get(c, 1.0), "ab": now} for c, f in GEB_FAKTOR_ALT.items() if GEB_FAKTOR.get(c, 1.0) != f}
        if wechsel and not st.execute("SELECT 1 FROM labor_zustand WHERE k='geb_wechsel'").fetchone():
            st.execute("INSERT INTO labor_zustand VALUES ('geb_wechsel', ?)", (_j(wechsel),))
        # 23.68 (U164): abgelöste Swing-/Zyklus-Kennungen -- ihre offenen Positionen schließt _swing_alt_aufraeumen
        self.swing_alt = {r[0] for r in st.execute("SELECT sid FROM labor_strategie WHERE aktiv=0 AND gruppe='Swing'")} - set(self.nach_sid)
        self.coin_start = coin_starts(st, self.coins, now, schreiben=True)
        self._registriert = True

    def _tor(self, t, seite, art, sid=None, coin=None, preis=None) -> bool:
        """23.76 (U206): das eine Tor der Notbremse (hl_notbremse.Tor.darf) -- nur Welt A hat eines; Welt B ist immer frei. Gesperrte
        Vorgänge protokolliert das Tor (nb_blockiert, je Strategie, Coin, Seite und Art höchstens alle 15 min)."""
        if self.tor is None or seite != "long":
            return True
        ok, grund = self.tor.darf(int(t), seite, art)
        if not ok:
            self.tor.protokoll(int(t), sid, coin, seite, art, preis, grund)
        return ok

    def _ereignis(self, st, t, sid, coin, art, seite, preis, text, netto=None, pos_id=None) -> None:
        st.execute("INSERT INTO labor_ereignis (ts, sid, coin, art, seite, preis, text, netto_usd, pos_id) VALUES (?,?,?,?,?,?,?,?,?)",
                   (int(t), sid, coin, art, seite, preis, text, netto, pos_id))

    # --- Eingangsdaten
    def eingaben(self, con, st, coin: str, now: int, z: dict) -> dict:
        E = {"coin": coin, "now": now, "preis": buch_jetzt(con, coin, now)}
        s = self._gecacht((coin, "sigma"), 900, now, lambda: sigma_4h(con, coin, now))
        E["sigma4h"], E["sigma_ok"], E["sigma_real4h"] = s
        E["sigma1h"] = E["sigma4h"] / 2; E["sigma15"] = E["sigma4h"] / 4
        E["vol1h"] = self._gecacht((coin, "vol"), 900, now, lambda: volumen_1h(con, coin, now))
        k = kerzen(con, coin, now // 60 * 60 - 20 * 60, now // 60 * 60)
        E["kerze"] = k[-1] if k else None; E["kerzen20"] = k
        try:                                   # Prognose und Treiber tragen denselben Zeitstempel; Index (coin, ts) der Prognosetabelle
            t_fc = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3 * 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_fc = None

        def _treib():
            d = {}
            try:
                for n, sc, t in st.execute("SELECT name, score, ts FROM forecast_drivers WHERE ts>=? AND ts<=? AND coin=?", (now - 3 * 3600, now, coin)):
                    if sc is not None and (n not in d or t > d[n][1]):
                        d[n] = (float(sc), int(t))
            except sqlite3.Error:
                pass
            return d
        E["treiber"] = self._gecacht((coin, "treiber", t_fc), 3600, now, _treib)

        def _prog():
            try:
                r = st.execute("SELECT ts, bias, p_up, buy_px, sell_px, json_extract(payload,'$.p_up_v2'), json_extract(payload,'$.kalib2.version'), "
                               "json_extract(payload,'$.p_up_v1'), json_extract(payload,'$.fusion.p_4'), json_extract(payload,'$.kosten.er_4'), "
                               "json_extract(payload,'$.kaskade.kipp_ab'), json_extract(payload,'$.kaskade.ende_ab'), "
                               "json_extract(payload,'$.kaskade.kipp_auf'), json_extract(payload,'$.kaskade.ende_auf') "
                               "FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                               (coin, now - 3 * 3600, now)).fetchone()
            except sqlite3.Error:
                r = None
            return {"ts": int(r[0]), "bias": r[1], "p_up": r[2], "buy_px": r[3], "sell_px": r[4], "p_up_v2": r[5], "v2_version": r[6],
                    "p_up_v1": r[7] if r[7] is not None else r[2], "p_fusion": r[8], "er_4": r[9],
                    "kipp_ab": r[10], "ende_ab": r[11], "kipp_auf": r[12], "ende_auf": r[13]} if r else None
        E["prognose"] = self._gecacht((coin, "prognose", t_fc), 3600, now, _prog)
        import hl_familien as H
        fam = {}
        for f, d in H.FAMILIEN.items():
            if d.get("live") or d["art"] == "staerke":
                continue
            w = [E["treiber"][n] for n in d["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
            fam[f] = (sum(x[0] for x in w) / len(w), min(x[1] for x in w), len(w)) if w else None
        try:
            r = st.execute("SELECT value, ts FROM familien_log WHERE coin=? AND familie='Profi-Flow' AND slot<=? ORDER BY slot DESC LIMIT 1",
                           (coin, now // 900)).fetchone()
            r = r if r and now - 1800 <= int(r[1]) <= now else None
            fam["Profi-Flow"] = (float(r[0]), int(r[1]), 1) if r and r[0] is not None else None
        except sqlite3.Error:
            fam["Profi-Flow"] = None
        E["familien"] = fam
        mit = [abs(E["treiber"][n][0]) for n in H.FAMILIEN["Stärke"]["treiber"] if n in E["treiber"] and now - E["treiber"][n][1] <= 3600]
        ruhe = None
        if E["sigma_real4h"] is not None and E["sigma_ok"]:
            ruhe = min(1.0, max(0.0, 1 - E["sigma_real4h"] / E["sigma4h"])); mit.append(ruhe)
        E["staerke"] = {"wert": (sum(mit) / len(mit)) if mit else None, "ruhe": ruhe, "n": len(mit)}
        E["kaskade"] = self._kaskade(con, st, coin, now, E, z)

        try:
            t_hm = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin=? AND ts>=? AND ts<=?", (coin, now - 3600, now)).fetchone()[0]
        except sqlite3.Error:
            t_hm = None

        def _anker():
            try:
                import hl_anker
                return hl_anker.jetzt(con, coin, now)
            except Exception as e:
                return {"fehler": f"{type(e).__name__}: {e}"}
        E["anker"] = self._gecacht((coin, "anker", t_hm), 1800, now, _anker)     # neu nur mit neuem Heatmap-Stand (alle 10 min)
        E["docht"] = self._docht(con, coin, now, E, t_hm)
        E["funding"] = self._funding(con, coin, now)
        E["darwin"] = self._darwin(con, st, coin, now, z)
        E["elite"] = self._elite(con, st, coin, now, z)                          # 23.39
        E["adressstrom"] = self._gecacht((coin, "af"), 120, now, lambda: hl_adressfluss.lesen(self.af_pfad, coin, now, E.get("vol1h")))
        if self.swing_strategien or self.akku_strategien:                          # 23.61: Tageskerzen aus swing.db (neu nur bei neuer Kerze)
            E["swing"] = self._gecacht((coin, "swing"), 60, now, lambda: SW.labor_daten(self.swing_pfad, coin, now))
        if self.wende_strategien and coin == WE.COIN:                              # 23.83 (U226): 8-h-Kerzen aus swing.db, nur BTC
            E["wende"] = self._gecacht((coin, "wende"), 60, now, lambda: WE.labor_daten(self.swing_pfad, now))
        if self.akku_strategien:                                                   # 23.69 (U180): 7-Tage-Hoch und Binance-Konten-Quote
            E["akku_h7"] = self._akku_h7(con, coin, now, (E.get("preis") or {}).get("mid"))
            E["konten"] = self._akku_konten(con, coin, now)
            if any(s["regeln"].get("korr") for s in self.akku_strategien):           # 23.72 (U186): Hoch der letzten 48 h (Korrektur A4)
                E["akku_h48"] = self._akku_h48(con, coin, now, None, int(self.akku_strategien[0]["regeln"].get("korr_h") or 48))
        if self.grid_strategien:                                                   # 23.40: Range der letzten 24 h (Datenfluss; die Grids
            p_rand = self.grid_strategien[0]["regeln"]["p_rand"]                   # rechnen nach einem Ausstieg mit kürzerem Fenster)
            E["grid"] = self._gecacht((coin, "grid24"), 300, now, lambda: grid_range(grid_kurse(con, coin, now - 86_400, now // 60 * 60), p_rand))
        return E

    def _kaskade(self, con, st, coin, now, E, z) -> dict:
        b = E["preis"]; k = E["kerzen20"]; zst = dict(z["k"].get(coin) or {})
        info = {"z": None, "liq": None, "schwelle": None}
        if not b or not k:
            return dict(zst, **info, aktiv=bool(zst.get("aktiv")))
        alt = [x for x in k if x[0] <= now // 60 * 60 - 15 * 60]
        p15 = alt[-1][4] if alt else k[0][1]
        zz = math.log(b["mid"] / p15) / max(E["sigma15"], 1e-6) if p15 else 0.0
        liq = liquidationen(con, coin, now - 900, now + 1)
        thr = self._gecacht((coin, "liqthr"), 3600, now, lambda: liq_schwellen(con, coin, now))
        info.update(z=round(zz, 2), liq=liq, schwelle=thr)
        if zst.get("aktiv"):
            nach = [x for x in k if x[0] >= zst["t"] // 60 * 60]
            if zst["richtung"] == "ab":
                zst["extrem"] = min([zst["extrem"], b["mid"]] + [x[3] for x in nach])
            else:
                zst["extrem"] = max([zst["extrem"], b["mid"]] + [x[2] for x in nach])
            if now - zst["t"] > KASKADE_FENSTER_S:
                zst["aktiv"] = False
        else:
            letzte = [x for x in k if x[0] >= now // 60 * 60 - 15 * 60]
            for richtung, bed, seite_liq in (("ab", zz <= -KASKADE_Z, "long"), ("auf", zz >= KASKADE_Z, "short")):
                if bed and liq[seite_liq] >= thr[seite_liq]:
                    ext = min([b["mid"]] + [x[3] for x in letzte]) if richtung == "ab" else max([b["mid"]] + [x[2] for x in letzte])
                    zst = {"aktiv": True, "id": now, "t": now, "richtung": richtung, "p_start": p15, "z_start": round(zz, 2),
                           "liq_usd": liq[seite_liq], "extrem": ext}
                    self._ereignis(st, now, None, coin, "kaskade", "short" if richtung == "ab" else "long", b["mid"],
                                   f"{'Kaskade abwärts' if richtung == 'ab' else 'Squeeze aufwärts'} erkannt: {zz:+.1f} σ in 15 min, "
                                   f"{liq[seite_liq] / 1e6:.2f} Mio {'Long' if richtung == 'ab' else 'Short'}-Liquidationen "
                                   f"(Schwelle {thr[seite_liq] / 1e6:.2f} Mio; Hyperliquid {liq['hl'] / 1e6:.2f}, Binance {liq['binance'] / 1e6:.2f}, "
                                   f"andere {liq['andere'] / 1e6:.2f})")
                    break
        z["k"][coin] = zst
        return dict(zst, **info, aktiv=bool(zst.get("aktiv")))

    def _docht(self, con, coin, now, E, t_hm) -> dict:
        b = E["preis"]; vol = E.get("vol1h"); sig = E["sigma4h"]
        out = {"unten": None, "oben": None, "ts": None}
        if not b or not vol:
            return out
        t = t_hm if t_hm and now - t_hm <= 1800 else None
        try:
            rows = con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?", (coin, t)).fetchall() if t else []
        except sqlite3.Error:
            rows = []
        out["ts"] = t; p0 = b["mid"]; out["unten_alle"] = []; out["oben_alle"] = []
        for px, side, usd in rows:
            if not px or not usd:
                continue
            d = abs(math.log(px / p0)) / sig; g = usd / vol
            if d > 3.0 or g < 0.10:
                continue
            c = {"px": px, "usd": usd, "anteil": g, "sigma": d}
            if side == "long" and px < p0:
                out["unten_alle"].append(c)
                if d >= 0.5 and (not out["unten"] or px > out["unten"]["px"]):
                    out["unten"] = c
            elif side == "short" and px > p0:
                out["oben_alle"].append(c)
                if d >= 0.5 and (not out["oben"] or px < out["oben"]["px"]):
                    out["oben"] = c
        return out

    def _funding(self, con, coin, now):
        try:
            r = con.execute("SELECT ts, funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (now - 900, now, coin)).fetchone()
        except sqlite3.Error:
            r = None
        if not r or r[1] is None:
            return None

        def _stat():
            stunden = [now // 3600 * 3600 - 3600 * k for k in range(14 * 24)]
            try:
                w = [float(x[0]) for x in con.execute(f"SELECT funding FROM ctx_bars WHERE coin=? AND ts IN ({','.join('?' * len(stunden))})",
                                                      (coin, *stunden)) if x[0] is not None]
            except sqlite3.Error:
                w = []
            if len(w) < 48:
                return None
            m = sum(w) / len(w)
            return (m, math.sqrt(sum((x - m) ** 2 for x in w) / (len(w) - 1)), len(w))
        s = self._gecacht((coin, "fstat"), 3600, now, _stat)
        rate = float(r[1])
        return {"ts": int(r[0]), "rate": rate, "z": ((rate - s[0]) / s[1]) if s and s[1] > 0 else None, "n": s[2] if s else 0}

    def _funding_rate(self, con, coin, t) -> float:
        try:
            r = con.execute("SELECT funding FROM ctx_bars WHERE ts>=? AND ts<=? AND coin=? ORDER BY ts DESC LIMIT 1", (t - 7200, t, coin)).fetchone()
        except sqlite3.Error:
            r = None
        return float(r[0]) if r and r[0] is not None else 0.0

    def _darwin(self, con, st, coin, now, z) -> dict:
        """
        23.34 (Darwin v2): Eröffnungen je Konto und Seite über DARWIN_FENSTER_S netto aufsummiert -- auch in kleinen Stücken (der
        Recorder sammelt die Fills der Liste ohne Mindestbetrag); eine Schließung derselben Seite zieht ab (nicht unter null). Erreicht
        die Summe DARWIN_MIN_USD und ist der jüngste Fill frisch, beginnt eine „Episode“ (einmal je Eröffnung, höchstens
        DARWIN_EPISODE_S). Der Folge-Ausstieg kommt erst, wenn das Konto seit der Episode mindestens DARWIN_AUS_ANTEIL davon wieder
        geschlossen hat -- seit die kleinen Fills sichtbar sind, würde sonst jedes Nachjustieren um ein paar hundert Dollar reichen.
        v1 merkte sich jeden gesehenen Fill und zählte nur die neuen eines Taktes: in Stücke unter 10k zerlegte Eröffnungen blieben
        unsichtbar.
        """
        def _liste():
            try:
                r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
                d = json.loads(r[0]) if r and r[0] else {}
            except (sqlite3.Error, ValueError):
                d = {}
            reihe = [str(a).lower() for a in (d.get("reihe") or [])]
            return (reihe + [a for a in (str(x).lower() for x in (d.get("liste") or [])) if a not in reihe])[:100]
        konten = self._gecacht(("*", "darwin"), 300, now, _liste)
        return self._kopie(con, coin, now, z, konten, "darwin")

    def _elite(self, con, st, coin, now, z) -> dict:
        """
        23.39: Die Elite des Coins als Kopier-Vorlage (Strategien „Elite live folgen“/„Gegen die Elite“) -- dieselbe Regel wie bei der
        Darwin-Liste (_kopie). Liste aus learned(coin, „elite“), vom Dashboard täglich neu aufgestellt (Konto-Score, Beleg, Gewinn- und
        Aktivitätsschranke, ohne Gesperrte); hier zusätzlich ohne Konten, die die Masterregel seither gesperrt hat. Die Fills der Elite
        sammelt der Recorder seit 23.39 im Stream (ab 2.500 USD, 0 Gewicht), auch wenn ein Konto weder Leaderboard-Auswahl, Pool noch Wal ist.
        """
        def _liste():
            try:
                r = st.execute("SELECT value FROM learned WHERE coin=? AND key='elite'", (coin,)).fetchone()
                v = json.loads(r[0]) if r and r[0] else []
            except (sqlite3.Error, ValueError):
                v = []
            konten = list(dict.fromkeys(str(a).lower() for a in (v if isinstance(v, list) else []) if isinstance(a, str)))[:20]
            try:
                gesperrt = {r_[0].lower() for r_ in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
            except sqlite3.Error:
                gesperrt = set()
            return [a for a in konten if a not in gesperrt]
        konten = self._gecacht((coin, "elite_konten"), 300, now, _liste)
        return self._kopie(con, coin, now, z, konten, "elite")

    def _kopie(self, con, coin, now, z, konten, art) -> dict:
        """Gemeinsame Kopier-Logik (bis 23.38 Rumpf von _darwin, unverändert): Eröffnungen je Konto und Seite über DARWIN_FENSTER_S netto,
        Episoden, Folge-Ausstieg; Zustand je Vorlage in z[„<art>_tids“], z[„<art>_ep“], Anzeige in self.<art>_log."""
        out = {"konten": konten, "neu": [], "summen": {}}
        if not konten:
            return out
        dirs = ("Open Long", "Open Short", "Close Long", "Close Short", "Long > Short", "Short > Long",
                "Open Long*", "Open Short*", "Close Long*", "Close Short*")
        try:
            rows = con.execute(f"SELECT ts, lower(addr), dir, px, notional, tid FROM lb_fills WHERE coin=? AND ts>=? AND ts<=? AND lower(addr) IN "
                               f"({','.join('?' * len(konten))}) AND dir IN ({','.join('?' * len(dirs))}) ORDER BY ts, tid",
                               (coin, now - DARWIN_FENSTER_S, now, *konten, *dirs)).fetchall()
        except sqlite3.Error:
            rows = []
        gesehen = z[f"{art}_tids"]; eps = z[f"{art}_ep"]; auf: dict = {}; rang = {a: i + 1 for i, a in enumerate(konten)}; neu = []
        for ts, a, d, px, usd, tid in rows:
            d = str(d).rstrip("*"); ts = int(ts); px = float(px or 0.0); usd = float(usd or 0.0)
            flip = d in ("Short > Long", "Long > Short")
            seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
            if flip or d.startswith("Close"):
                s_zu = _gegen(seite) if flip else seite
                e = auf.get((a, s_zu))
                if e:                                            # Schließungen ziehen von der laufenden Summe ab (nicht unter null)
                    e["usd"] = max(0.0, e["usd"] - usd)
                    if e["usd"] <= 0:
                        auf.pop((a, s_zu), None)
                k = f"{a}|{coin}|{s_zu}"
                if f"{a}:{tid}" not in gesehen:
                    gesehen[f"{a}:{tid}"] = ts
                    ep = eps.get(k)
                    if isinstance(ep, dict):
                        ep["zu"] = ep.get("zu", 0.0) + usd
                        if ep["zu"] >= DARWIN_AUS_ANTEIL * max(ep.get("usd", 0.0), 1.0):
                            eps.pop(k, None)                    # Episode endet: genug geschlossen
                            neu.append({"addr": a, "art": "zu", "seite": s_zu, "usd": ep["zu"], "von_usd": ep.get("usd"), "px": px, "ts": ts,
                                        "rang": rang.get(a)})
            if flip or d.startswith("Open"):
                e = auf.setdefault((a, seite), {"usd": 0.0, "pxu": 0.0, "ts": ts, "t0": ts, "n": 0})
                e["usd"] += usd; e["pxu"] += px * usd; e["n"] += 1; e["ts"] = max(e["ts"], ts)
        for (a, seite), e in auf.items():
            k = f"{a}|{coin}|{seite}"
            out["summen"][k] = round(e["usd"], 2)
            if k in eps or e["usd"] < DARWIN_MIN_USD or now - e["ts"] > DARWIN_FRISCH_S:
                continue
            eps[k] = {"t": now, "usd": round(e["usd"], 2), "zu": 0.0}
            neu.append({"addr": a, "art": "auf", "seite": seite, "usd": e["usd"], "px": (e["pxu"] / e["usd"]) if e["usd"] else 0.0,
                        "ts": e["ts"], "seit": e["t0"], "n": e["n"], "rang": rang.get(a)})
        out["neu"] = sorted(neu, key=lambda e: (e["ts"], e["art"] != "zu"))
        if out["neu"]:
            setattr(self, f"{art}_log", (getattr(self, f"{art}_log") + [dict(e, coin=coin) for e in out["neu"]])[-40:])
        out["log"] = [e for e in getattr(self, f"{art}_log") if e["coin"] == coin and now - e["ts"] <= 6 * 3600][-4:]
        return out

    # --- Zyklus
    def zyklus(self, now: int | None = None, E_von: dict | None = None) -> dict:
        """Ein Takt. E_von (23.76, Welt A): der Marktzustand je Coin aus der Welt B ({coin: {"E", "ts"}}) -- kopiert, nie neu gerechnet."""
        t_start = time.time(); now = int(now or time.time())
        con = self._con(); st = self._st(); n_neu = n_zu = n_grid = n_akku = 0
        try:
            self._registrieren(st, now)
            if self.z is None:
                self.z = self._zustand(st)
            z = self.z
            if self.tor is not None:
                self.tor.vorbereiten(now - 3 * 86_400, now)
            for coin in self.coins:
                try:
                    if E_von is not None:
                        v_ = E_von.get(coin) or {}
                        if v_.get("ts") != now or not v_.get("E"):
                            continue
                        E = copy.deepcopy(v_["E"])
                    else:
                        E = self.eingaben(con, st, coin, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Eingaben: {type(e).__name__}: {e}"); continue
                self.letzte[coin] = {"E": E, "ts": now}
                if not E.get("preis"):
                    continue
                try:
                    n_zu += self._orders(con, st, coin, E, now, z)
                    if self.tor is not None:                              # 23.76 (U206): erst die Füllungen bis jetzt, dann stornieren
                        self._notbremse_stornieren(st, now, coin, grid=False)
                    n_zu += self._positionen(con, st, coin, E, now, z)
                    n_zu += self._swing_alt_aufraeumen(con, st, coin, E, now, z)        # 23.68 (U164)
                    n_neu += self._signale(con, st, coin, E, now, z)
                except Exception as e:
                    self._fehler(f"{coin} Handel: {type(e).__name__}: {e}")
            # 23.41: Grids zum Schluss des Takts (vorher je Coin mittendrin): ihre Transaktion hält die Schreibsperre ab Beginn
            # (BEGIN IMMEDIATE, siehe _grid) -- am Ende nur für Grids, Zustand und Commit statt für die Eingaben aller übrigen Coins
            for coin in self.coins:
                v = self.letzte.get(coin) or {}
                if v.get("ts") == now and (v.get("E") or {}).get("preis"):
                    n_grid += self._grid(con, st, coin, v["E"], now, z)          # eigene Fehlerbehandlung je Grid (Sicherungspunkt)
                    n_akku += self._akku(con, st, coin, v["E"], now, z)          # 23.69 (U180): ebenso je Akkumulation
            if self.tor is not None:                                              # 23.76 (U206): Kauf-Limits der Grids nach ihren Kerzen
                self._notbremse_stornieren(st, now, None, grid=True)
            if now - int(z.get("aufgeraeumt", 0)) > 86_400:
                st.execute("DELETE FROM labor_ereignis WHERE ts < ?", (now - EREIGNIS_TAGE * 86_400,))
                st.execute("DELETE FROM labor_order WHERE status<>'offen' AND erledigt < ?", (now - 30 * 86_400,))
                z["aufgeraeumt"] = now
            self._zustand_speichern(st, z, now)
            st.commit()
            n_offen = st.execute("SELECT COUNT(*) FROM labor_position WHERE status='offen'").fetchone()[0]
        except Exception:
            self.z = None; self._z_txt = None           # Takt verworfen (Rollback): Zustand beim nächsten Takt aus dem Speicher
            raise
        finally:
            con.close(); st.close()
            if self.tor is not None:
                self.tor.schreiben()
        self.zyklen += 1; self.dauer = time.time() - t_start; self.t_letzt = now
        return {"offen": n_offen, "neu": n_neu, "zu": n_zu, "grid": n_grid, "akku": n_akku, "dauer": round(self.dauer, 3)}

    def _notbremse_stornieren(self, st, now, coin=None, grid=False) -> int:
        """23.76 (U206): Stufe ≥ 1 -- offene Long-Limits storniert, Ereignis „Notbremse Stufe n“. Erst NACH den Füllungen bis jetzt (eine
        Füllung vor dem Beginn der Sperre bleibt): je Coin nach _orders, die Kauf-Limits der Grids nach deren Kerzen."""
        stufe, grund = self.tor.stufe(now)
        if not stufe:
            return 0
        n = 0
        q = ("SELECT id, sid, coin, preis FROM labor_order WHERE status='offen' AND seite='long' AND "
             + ("sid LIKE 'grid\\_%' ESCAPE '\\'" if grid else "sid NOT LIKE 'grid\\_%' ESCAPE '\\' AND coin=?"))
        for oid, sid, coin_, preis in st.execute(q, () if grid else (coin,)).fetchall():
            coin = coin_
            st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid))
            self._ereignis(st, now, sid, coin, "notbremse", "long", preis, f"Notbremse Stufe {stufe}: Long-Limit {coin} bei {preis:.6g} storniert"
                           + (f" — {grund}" if grund else ""))
            self.tor.protokoll(now, sid, coin, "long", "storno", preis, f"Notbremse Stufe {stufe}")
            n += 1
        return n

    # --- Limit-Orders
    def _orders(self, con, st, coin, E, now, z) -> int:
        rows = st.execute("SELECT id, sid, seite, preis, erstellt, gueltig_bis, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten_s, geprueft_bis "
                          "FROM labor_order WHERE status='offen' AND coin=? AND sid NOT LIKE 'grid\\_%' ESCAPE '\\'", (coin,)).fetchall()   # 23.40: Grid eigene Mechanik
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(r[13]) for r in rows), now // 60 * 60); n = 0
        for oid, sid, seite, preis, erstellt, gueltig, grund, werte, sl_rel, tp_rel, sl_px, tp_px, halten, gepr in rows:
            if sid not in self.nach_sid:
                st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
            kauf = seite == "long"; fill = None
            for ts, o, h, l, c in bars:
                if ts < gepr or ts > gueltig:
                    continue
                if (kauf and l < preis) or (not kauf and h > preis):
                    fill = (ts, ts + 30); break
            if fill is None and now <= gueltig and now - b["ts"] <= KURS_FRISCH_S and ((kauf and b["ask"] < preis) or (not kauf and b["bid"] > preis)):
                fill = (now // 60 * 60, now)
            if fill:
                if st.execute("SELECT 1 FROM labor_position WHERE sid=? AND coin=? AND status='offen'", (sid, coin)).fetchone():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
                t_f = fill[1]
                if kauf and not self._tor(t_f, "long", "limit_fuellen", sid, coin, preis):     # 23.76 (U206): Zustand zur Zeit der Füllung
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid))
                    self._ereignis(st, now, sid, coin, "notbremse", seite, preis, f"Notbremse: Füllung des Long-Limits {coin} bei {preis:.6g} "
                                   f"um {_uhr(t_f)} verworfen, Order storniert")
                    continue
                sl = sl_px if sl_px else ((preis * (1 - sl_rel) if kauf else preis * (1 + sl_rel)) if sl_rel else None)
                tp = tp_px if tp_px else ((preis * (1 + tp_rel) if kauf else preis * (1 - tp_rel)) if tp_rel else None)
                pid = self._eroeffnen(st, coin, self.nach_sid[sid], seite, t_f, preis, 0.0, GEB_MAKER, "Limit (Maker)", sl, tp,
                                      t_f + int(halten or 0), grund, werte, None, pruef_ab=fill[0], nur_stop_bis=fill[0] + 60,
                                      tor_art="limit_fuellen")
                if pid is None:
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid)); continue
                st.execute("UPDATE labor_order SET status='gefuellt', erledigt=?, pos_id=? WHERE id=?", (t_f, pid, oid))
                for (oid2,) in st.execute("SELECT id FROM labor_order WHERE status='offen' AND sid=? AND coin=? AND id<>?", (sid, coin, oid)).fetchall():
                    st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, oid2))
                    self._ereignis(st, now, sid, coin, "storno", None, None, "Gegen-Order storniert: Position eröffnet")
                n += 1
            elif now > gueltig:
                st.execute("UPDATE labor_order SET status='verfallen', erledigt=? WHERE id=?", (now, oid))
                self._ereignis(st, now, sid, coin, "verfallen", seite, preis, f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} bei {preis:.6g} "
                               "verfallen, nicht gefüllt")
            elif now // 60 * 60 != gepr:
                st.execute("UPDATE labor_order SET geprueft_bis=? WHERE id=?", (now // 60 * 60, oid))
        return n

    # --- Positionen
    def _eroeffnen(self, st, coin, S, seite, t, preis, slip_bps, gebuehr_satz, art, sl, tp, ablauf, grund, werte, folge,
                   pruef_ab=None, nur_stop_bis=None, notional=None, ereignis_art="eroeffnet", tor_art="eroeffnen") -> int | None:
        # 23.76 (U206): jede neue Position entsteht hier -- Longs nur, wenn das Tor der Notbremse frei ist (Welt A); sonst None
        if seite == "long" and not self._tor(t, "long", tor_art, S["sid"], coin, preis):
            return None
        # 23.40: notional je Position (Grid-Lose sind ein Teil des Coin-Kontos); ohne Angabe wie bisher self.notional
        nt = float(notional) if notional else self.notional
        menge = nt / preis; kauf = seite == "long"
        if sl is not None and ((kauf and sl >= preis) or (not kauf and sl <= preis)):
            sl = None
        if tp is not None and ((kauf and tp <= preis) or (not kauf and tp >= preis)):
            tp = None
        pruef_ab = pruef_ab if pruef_ab is not None else (int(t) // 60 + 1) * 60
        cur = st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, "
                         "sl, tp, ablauf, grund, werte, folge, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) "
                         "VALUES (?,?,?,'offen',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,0,0)",
                         (S["sid"], coin, seite, int(t), preis, nt, menge, art, nt * gebuehr(coin, gebuehr_satz), slip_bps,
                          sl, tp, int(ablauf), grund, werte if isinstance(werte, str) else _j(werte or {}), _j(folge) if folge else None,
                          pruef_ab, nur_stop_bis if nur_stop_bis is not None else pruef_ab, int(t)))
        pid = cur.lastrowid
        teile = [f"{'Long' if kauf else 'Short'} {coin} zu {preis:.6g} ({art}" + (f", {slip_bps:.1f} bps zur Mitte" if slip_bps else "") + ")"]
        if nt != self.notional:
            teile.append(f"{nt:,.0f} USD".replace(",", "."))
        if sl:
            teile.append(f"Stop {sl:.6g}")
        if tp:
            teile.append(f"Ziel {tp:.6g}")
        if ablauf:
            teile.append(f"bis {_uhr(ablauf)}")
        self._ereignis(st, t, S["sid"], coin, ereignis_art, seite, preis, " · ".join(teile) + f" — {grund}", None, pid)
        return pid

    def _schliessen(self, st, p, preis, art, gebuehr_satz, slip_bps, grund, t, z=None, ereignis_art="geschlossen") -> float:
        kauf = p["seite"] == "long"
        brutto = (preis - p["preis_ein"]) * p["menge"] * (1 if kauf else -1)
        geb_aus = p["menge"] * preis * gebuehr(p["coin"], gebuehr_satz)
        netto = brutto - p["gebuehr_ein"] - geb_aus - p["funding"]
        st.execute("UPDATE labor_position SET status='geschlossen', geschlossen=?, preis_aus=?, art_aus=?, gebuehr_aus=?, slip_aus=?, grund_aus=?, "
                   "brutto_usd=?, netto_usd=?, netto_pct=?, mae_pct=?, mfe_pct=?, funding=?, funding_bis=? WHERE id=?",
                   (int(t), preis, art, geb_aus, slip_bps, grund, brutto, netto, netto / p["notional"] * 100, p["mae_pct"], p["mfe_pct"],
                    p["funding"], p["funding_bis"], p["id"]))
        dauer = max(int(t) - int(p["eroeffnet"]), 0)
        self._ereignis(st, t, p["sid"], p["coin"], ereignis_art, p["seite"], preis,
                       f"{'Long' if kauf else 'Short'} {p['coin']} geschlossen zu {preis:.6g} ({grund}, {art}) nach {dauer // 3600} h "
                       f"{dauer % 3600 // 60} min · netto {netto:+.2f} USD ({netto / p['notional'] * 100:+.2f} %)"
                       + (f", Funding {-p['funding']:+.2f} USD" if abs(p["funding"]) >= 0.01 else ""), netto, p["id"])
        if z is not None:
            z["s"].setdefault(f"{p['sid']}|{p['coin']}", {})["pause_bis"] = int(t) + PAUSE_S
        return netto

    def _funding_nachziehen(self, con, p, bis) -> None:
        h = (int(p["funding_bis"]) // 3600 + 1) * 3600
        while h <= bis:
            p["funding"] += self._funding_rate(con, p["coin"], h) * p["notional"] * (1 if p["seite"] == "long" else -1)
            p["funding_bis"] = h; h += 3600

    def _swing_alt_aufraeumen(self, con, st, coin, E, now, z) -> int:
        """
        23.68 (U164): offene Positionen abgelöster Swing- und Zyklus-Kennungen zum Marktpreis schließen („Regelversion abgelöst“), wie
        bei den Grids: Ihre Strategie läuft nicht mehr im Takt, Nachzieh-Stop und Signal-Ausstieg würden nicht mehr gepflegt. Erst nach
        _positionen (Stop und Ziel bis jetzt zählen), nur mit frischem Kurs.
        """
        alt = getattr(self, "swing_alt", None)
        b = E.get("preis")
        if not alt or not b or now - b["ts"] > KURS_FRISCH_S:
            return 0
        n = 0
        for p in self._offene(st, coin):
            if p["sid"] not in alt:
                continue
            self._funding_nachziehen(con, p, now)
            pr, bps = taker_preis(b, p["seite"] != "long", p["notional"])
            self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Regelversion abgelöst", now, z)
            n += 1
        return n

    def _offene(self, st, coin) -> list:
        return [dict(zip(POS_SPALTEN, r)) for r in st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE status='offen' AND coin=?", (coin,))]

    def _positionen(self, con, st, coin, E, now, z) -> int:
        rows = [p for p in self._offene(st, coin) if not str(p["sid"]).startswith("grid_")]     # 23.40: Grid-Lose führt _grid
        if not rows:
            return 0
        b = E["preis"]; bars = kerzen(con, coin, min(int(p["geprueft_bis"]) for p in rows), now // 60 * 60); n = 0
        for p in rows:
            kauf = p["seite"] == "long"; p_in = p["preis_ein"]; erledigt = False
            vorher = (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"])
            for ts, o, hi, lo, c in bars:
                if ts < p["geprueft_bis"]:
                    continue
                self._funding_nachziehen(con, p, ts + 60)
                nur_stop = ts < p["nur_stop_bis"]
                p["mae_pct"] = max(p["mae_pct"], ((p_in - lo) / p_in if kauf else (hi - p_in) / p_in) * 100)
                if not nur_stop:
                    p["mfe_pct"] = max(p["mfe_pct"], ((hi - p_in) / p_in if kauf else (p_in - lo) / p_in) * 100)
                sl, tp = p["sl"], p["tp"]
                if sl and ((kauf and lo <= sl) or (not kauf and hi >= sl)):
                    pr, bps = taker_preis(dict(b, mid=(min(o, sl) if kauf else max(o, sl))), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", ts + 60, z); erledigt = True; n += 1; break
                if not nur_stop and tp and ((kauf and hi > tp) or (not kauf and lo < tp)):
                    self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", ts + 60, z); erledigt = True; n += 1; break
                if p["ablauf"] and ts + 60 >= p["ablauf"]:
                    pr, bps = taker_preis(dict(b, mid=c), not kauf, p["notional"])
                    self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", ts + 60, z); erledigt = True; n += 1; break
                p["geprueft_bis"] = ts + 60
            if erledigt:
                continue
            self._funding_nachziehen(con, p, now)
            sl, tp = p["sl"], p["tp"]
            if now - b["ts"] > KURS_FRISCH_S:
                pass                                                    # Kurs veraltet: nur die Minutenkerzen zählen
            elif sl and ((kauf and b["bid"] <= sl) or (not kauf and b["ask"] >= sl)):
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Stop (Taker)", GEB_TAKER, bps, "Stop", now, z); n += 1; continue
            elif tp and now >= p["nur_stop_bis"] and ((kauf and b["bid"] > tp) or (not kauf and b["ask"] < tp)):
                self._schliessen(st, p, tp, "Ziel (Maker)", GEB_MAKER, 0.0, "Ziel", now, z); n += 1; continue
            elif p["ablauf"] and now >= p["ablauf"]:
                pr, bps = taker_preis(b, not kauf, p["notional"])
                self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, "Zeit abgelaufen", now, z); n += 1; continue
            if (p["geprueft_bis"], p["funding_bis"], p["mae_pct"], p["mfe_pct"]) != vorher:     # einmal je Minute, nicht je Takt
                st.execute("UPDATE labor_position SET geprueft_bis=?, funding=?, funding_bis=?, mae_pct=?, mfe_pct=? WHERE id=?",
                           (p["geprueft_bis"], p["funding"], p["funding_bis"], p["mae_pct"], p["mfe_pct"], p["id"]))
        return n

    # --- Signale ausführen
    def _signale(self, con, st, coin, E, now, z) -> int:
        frisch = now - E["preis"]["ts"] <= KURS_FRISCH_S
        nb_txt = None
        if self.tor is not None:                                                    # 23.76 (U206): Welt A -- Longs gesperrt?
            ok_, g_ = self.tor.darf(now, "long", "eroeffnen")
            nb_txt = None if ok_ else f"{g_} (nur Longs)"
        offen = {p["sid"]: p for p in self._offene(st, coin)}
        orders: dict = {}
        for oid, sid, seite, preis in st.execute("SELECT id, sid, seite, preis FROM labor_order WHERE status='offen' AND coin=?", (coin,)):
            orders.setdefault(sid, []).append([oid, seite, preis])
        n = 0
        for S in self.strategien:
            if S["fn"] in ("grid", "akku"):                                        # 23.40 Grid, 23.69 Akkumulation: eigene Mechanik
                continue
            sid = S["sid"]; zs = z["s"].setdefault(f"{sid}|{coin}", {})
            zs["_orders"] = [(o[1], o[2]) for o in orders.get(sid, [])]            # flüchtig: liegende Limits für die Signalfunktion
            if S["fn"] in ("swing", "wende"):
                zs["_pos"] = offen.get(sid)                                        # 23.61: offene Position (flüchtig); 23.83 auch Wende
            try:
                akts = SIGNALE[S["fn"]](S, E, coin, now, zs) or []
            except Exception as e:
                zs.pop("_pos", None)
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}"); continue
            sig = next((a for a in akts if a.get("typ") in ("markt", "limit")), None)
            zs.pop("_orders", None); zs.pop("_pos", None)
            for a in akts:
                typ = a.get("typ")
                if typ == "folge_aus":
                    p = offen.get(sid)
                    f = json.loads(p["folge"]) if p and p.get("folge") else None
                    if f and f.get("addr") == a["addr"] and f.get("seite_konto") == a["seite_konto"]:
                        p["coin"] = coin; self._funding_nachziehen(con, p, now)
                        pr, bps = taker_preis(E["preis"], p["seite"] != "long", p["notional"])
                        self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, a["grund"], now, z); offen.pop(sid, None)
                    continue
                if typ == "aus":                                       # 23.61 Swing: Signal-Ausstieg zum Marktpreis, ohne Pause
                    p = offen.get(sid)
                    if p:
                        p["coin"] = coin; self._funding_nachziehen(con, p, now)
                        pr, bps = taker_preis(E["preis"], p["seite"] != "long", p["notional"])
                        self._schliessen(st, p, pr, "Markt (Taker)", GEB_TAKER, bps, a.get("grund", "Ausstieg"), now)
                        offen.pop(sid, None)
                    continue
                if typ == "stop_nachziehen":                           # 23.61 Swing: Stop nur in Gewinnrichtung nachziehen
                    p = offen.get(sid)
                    if p and a.get("sl") is not None:
                        neu, alt = float(a["sl"]), p.get("sl")
                        if alt is None or (neu > alt if p["seite"] == "long" else neu < alt):
                            st.execute("UPDATE labor_position SET sl=? WHERE id=?", (neu, p["id"])); p["sl"] = neu
                            self._ereignis(st, now, sid, coin, "stop", p["seite"], neu, f"Stop nachgezogen auf {neu:.6g}"
                                           + (f" (vorher {alt:.6g})" if alt else "") + f" — {a.get('grund', '')}", None, p["id"])
                    continue
                if typ == "storno":
                    bleiben = []
                    for o in orders.get(sid, []):
                        if a.get("seite") in (None, o[1]):
                            st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                            self._ereignis(st, now, sid, coin, "storno", o[1], o[2], f"Limit storniert: {a.get('grund', '')}")
                        else:
                            bleiben.append(o)
                    orders[sid] = bleiben
                    continue
                if sid in offen or now < int(zs.get("pause_bis", 0)) or not frisch:
                    continue
                if typ == "markt":
                    kauf = a["seite"] == "long"; h = a.get("h", S["regeln"].get("h", 4)); sig_h = E["sigma4h"] * math.sqrt(h / 4)
                    nt = float(a.get("notional") or self.notional)            # 23.61: Swing mit eigener Größe (Risiko ÷ Stop-Abstand)
                    pr, bps = taker_preis(E["preis"], kauf, nt)
                    sl, tp = a.get("sl_px"), a.get("tp_px")
                    k_sl, k_tp = a.get("sl", S["regeln"].get("sl")), a.get("tp", S["regeln"].get("tp"))
                    if sl is None and k_sl:
                        sl = pr * (1 - k_sl * sig_h) if kauf else pr * (1 + k_sl * sig_h)
                    if tp is None and k_tp:
                        tp = pr * (1 + k_tp * sig_h) if kauf else pr * (1 - k_tp * sig_h)
                    pid = self._eroeffnen(st, coin, S, a["seite"], now, pr, bps, GEB_TAKER, "Markt (Taker)", sl, tp,
                                          now + int(a.get("halten_s", h * 3600)), a.get("grund", ""), a.get("werte"), a.get("folge"),
                                          notional=nt if a.get("notional") else None)
                    if pid is None:
                        continue
                    offen[sid] = self._pos(st, pid)
                    if S["fn"] in ("swing", "wende"):
                        zs["letzter_einstieg"] = now                         # 23.61: je Entscheidungstag höchstens ein Einstieg (23.83: je Signal)
                    for o in orders.pop(sid, []):
                        st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (now, o[0]))
                    n += 1
                elif typ == "limit":
                    kauf = a["seite"] == "long"
                    vorh = [o for o in orders.get(sid, []) if o[1] == a["seite"]]
                    if vorh and abs(vorh[0][2] / a["preis"] - 1) <= a.get("toleranz", 0.001):
                        continue
                    if (kauf and a["preis"] >= E["preis"]["ask"]) or (not kauf and a["preis"] <= E["preis"]["bid"]):
                        continue                                        # läge schon im Markt -- kein Limit
                    if kauf and not self._tor(now, "long", "limit_setzen", sid, coin, a["preis"]):
                        continue                                        # 23.76 (U206): kein neues Long-Limit
                    for o in vorh:                                      # ersetzt: ein Ereignis „verschoben“ statt zweier
                        st.execute("UPDATE labor_order SET status='ersetzt', erledigt=? WHERE id=?", (now, o[0]))
                    cur = st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, "
                                     "sl_px, tp_px, halten_s, geprueft_bis) VALUES (?,?,?,?,?,?,'offen',?,?,?,?,?,?,?,?)",
                                     (sid, coin, a["seite"], a["preis"], now, now + int(a.get("gueltig_s", 4 * 3600)), a.get("grund", ""),
                                      _j(a.get("werte") or {}), a.get("sl_rel"), a.get("tp_rel"), a.get("sl_px"), a.get("tp_px"),
                                      int(a.get("halten_s", 6 * 3600)), (now // 60 + 1) * 60))
                    orders[sid] = [o for o in orders.get(sid, []) if o[1] != a["seite"]] + [[cur.lastrowid, a["seite"], a["preis"]]]
                    self._ereignis(st, now, sid, coin, "limit", a["seite"], a["preis"],
                                   f"Limit {'Kauf' if kauf else 'Verkauf'} {coin} "
                                   + (f"verschoben von {vorh[0][2]:.6g} auf {a['preis']:.6g}" if vorh else f"bei {a['preis']:.6g} gesetzt")
                                   + f", gültig bis {_uhr(now + int(a.get('gueltig_s', 4 * 3600)))} — {a.get('grund', '')}")
            try:
                txt = status_text(S, E, now, zs)
            except Exception as e:
                txt = f"({type(e).__name__})"
            self.status[(sid, coin)] = {
                "ts": now, "text": txt,
                "signal": {"typ": sig["typ"], "seite": sig.get("seite"), "grund": sig.get("grund", "")} if sig else None,
                "blockiert": "Position offen" if sid in offen else (f"Pause bis {_uhr(zs['pause_bis'])}" if now < int(zs.get("pause_bis", 0))
                                                                     else (nb_txt if frisch else "Kurs veraltet")),
                "orders": len(orders.get(sid, []))}
        return n

    # --- Akkumulation (U180, 23.69): nur Kauf, nie Verkauf; eigene Bilanz (labor_akku_kauf, labor_akku_tag), Zustand „a“
    def _akku_h7(self, con, coin, now, mid):
        """Höchstes Hoch der Hyperliquid-1-min-Kerzen der letzten 7 Tage, mindestens der Kurs jetzt. Der volle Lauf alle 5 min (über alle
        Coins im Zeitfenster), dazwischen nur die jüngsten Kerzen."""
        def voll():
            try:
                r = con.execute("SELECT MAX(high) FROM bars WHERE coin=? AND ts>=? AND ts<?", (coin, now - 7 * 86_400, now // 60 * 60)).fetchone()
            except sqlite3.Error:
                r = None
            return (float(r[0]) if r and r[0] else None, now // 60 * 60)
        h, bis = self._gecacht((coin, "akku_h7"), AKKU_H7_S, now, voll)
        try:
            r = con.execute("SELECT MAX(high) FROM bars WHERE coin=? AND ts>=? AND ts<=?", (coin, bis, now)).fetchone()
            h2 = float(r[0]) if r and r[0] else None
        except sqlite3.Error:
            h2 = None
        werte = [x for x in (h, h2, mid) if x]
        return max(werte) if werte else None

    def _akku_h48(self, con, coin, now, ab=None, stunden: int = 48):
        """23.72 (U186): höchstes Hoch der Hyperliquid-1-min-Kerzen der letzten 48 h bis jetzt (die laufende Minute eingeschlossen), mit ab
        erst ab dort (Minute nach dem letzten Korrekturkauf). Der abgeschlossene Teil je Minute gecacht. -> Hoch oder None"""
        t_a = max(int(now) - int(stunden) * 3600, int(ab or 0)); m = int(now) // 60 * 60

        def voll():
            try:
                r = con.execute("SELECT MAX(high) FROM bars WHERE coin=? AND ts>=? AND ts<?", (coin, t_a, m)).fetchone()
            except sqlite3.Error:
                r = None
            return float(r[0]) if r and r[0] else None
        h = self._gecacht((coin, "akku_h48", t_a // 60, m), 60, now, voll) if t_a < m else None
        try:
            r = con.execute("SELECT MAX(high) FROM bars WHERE coin=? AND ts>=? AND ts<=?", (coin, max(m, t_a), int(now))).fetchone()
            h2 = float(r[0]) if r and r[0] else None
        except sqlite3.Error:
            h2 = None
        werte = [x for x in (h, h2) if x]
        return max(werte) if werte else None

    def _akku_konten(self, con, coin, now):
        """Binance-Konten-Quote (Long ÷ Short aller Konten, `bnc_metrics` „global_ls_account“), höchstens 2 h alt: (ts, Wert) oder None."""
        def les():
            try:
                r = con.execute("SELECT ts, value FROM bnc_metrics WHERE coin=? AND metric='global_ls_account' AND ts>=? AND ts<=? "
                                "AND ts < 100000000000 ORDER BY ts DESC LIMIT 1", (coin, now - AKKU_KONTEN_S, now)).fetchone()
            except sqlite3.Error:
                r = None
            return (int(r[0]), float(r[1])) if r and r[1] is not None else None
        return self._gecacht((coin, "akku_konten"), 60, now, les)

    @staticmethod
    def _akku_cluster(R, E, za, now):
        """Heißes Long-Cluster unter dem Kurs (≥ 25 % des Stundenvolumens, 0,5–3 σ(4 h)) aus dem jüngsten Heatmap-Stand; das höchste wird
        gemerkt, bis 6 h nach der letzten Sichtung -- liquidierte Cluster verschwinden aus dem Stand, wenn der Kurs ankommt."""
        D = E.get("docht") or {}; p = (E.get("preis") or {}).get("mid")
        heiss = [c for c in (D.get("unten_alle") or []) if c["anteil"] >= R["cluster_anteil"] and 0.5 <= c["sigma"] <= 3.0 and p and c["px"] < p]
        if heiss and D.get("ts"):
            c = max(heiss, key=lambda c_: c_["px"])
            za["cluster"] = {"px": c["px"], "usd": c["usd"], "anteil": c["anteil"], "ts": int(D["ts"])}
        cl = za.get("cluster")
        if cl and now - int(cl.get("ts", 0)) > R["cluster_merken_h"] * 3600:
            za.pop("cluster", None); cl = None
        return cl

    def _akku(self, con, st, coin, E, now, z) -> int:
        """Beide Akkumulations-Strategien eines Coins, je hinter einem eigenen Sicherungspunkt (wie _grid: BEGIN IMMEDIATE)."""
        if not self.akku_strategien:
            return 0
        n = 0
        for S in self.akku_strategien:
            key = f"{S['sid']}|{coin}"
            vorher = json.loads(_j(z["a"][key])) if isinstance(z["a"].get(key), dict) else None
            try:
                if not st.in_transaction:
                    st.execute("BEGIN IMMEDIATE")
                st.execute("SAVEPOINT akku_eins")
            except sqlite3.OperationalError as e:
                self._fehler(f"Akkumulation {coin}: Schreibsperre nicht frei ({e}) -- setzt diesen Takt aus")
                return n
            try:
                n += self._akku_eins(con, st, coin, E, now, z, S)
                st.execute("RELEASE akku_eins")
            except Exception as e:
                st.execute("ROLLBACK TO akku_eins"); st.execute("RELEASE akku_eins")
                if vorher is None:
                    z["a"].pop(key, None)
                else:
                    z["a"][key] = vorher
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}")
        return n

    def _akku_faktor(self, st, S, coin, now) -> dict:
        """
        23.74 (U189): Faktor gegenüber BTC dieser Strategie im Coin -- einmal bestimmt (akku_faktor_rechnen: die 365 Tage vor dem Start des
        Coins im Labor) und in labor_akku_faktor gespeichert, danach nur noch gelesen: fest, auch wenn sich swing.db später ändert. Fehlt
        er (zu wenige Tage, swing.db fehlt), frühestens nach AKKU_FAKTOR_WARTEN_S ein neuer Versuch. Regeln ohne Faktor (bis 23.73): f = 1.
        -> {ok, faktor, roh, sigma, sigma_basis, n, von, bis, start, grund, fest}
        """
        R = S["regeln"]
        if not R.get("faktor_basis"):
            return {"ok": True, "faktor": 1.0, "fest": False}
        r = st.execute("SELECT faktor, roh, sigma, sigma_basis, n, von, bis, start, ts FROM labor_akku_faktor WHERE sid=? AND coin=?",
                       (S["sid"], coin)).fetchone()
        if r:
            return {"ok": True, "faktor": float(r[0]), "roh": r[1], "sigma": r[2], "sigma_basis": r[3], "n": r[4], "von": r[5], "bis": r[6],
                    "start": r[7], "ts": r[8], "grund": "", "fest": True}
        t0 = int(self.coin_start.get(coin) or now)
        key = (coin, "akku_faktor", t0, R.get("faktor_basis"), int(R.get("faktor_tage", 365)), float(R.get("faktor_min", 1.0)))
        fk = dict(self._gecacht(key, AKKU_FAKTOR_WARTEN_S, now, lambda: akku_faktor_rechnen(self.swing_pfad, coin, t0, R)))
        if fk.get("ok"):
            st.execute("INSERT OR IGNORE INTO labor_akku_faktor VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                       (S["sid"], coin, fk["faktor"], fk.get("roh"), fk.get("sigma"), fk.get("sigma_basis"), fk.get("n"), fk.get("von"),
                        fk.get("bis"), fk.get("start"), int(now)))
            fk.update(ts=int(now), fest=True)
        return fk

    def _akku_nach_kerzen(self, con, coin, t0: int, now: int):
        """1-min-Kerzen der Hauptdatenbank von 7 Tagen vor t0 bis zur letzten abgeschlossenen Minute (für beide Strategien eines Coins
        einmal gelesen)."""
        def lesen():
            rows = con.execute("SELECT ts, open, high, low, close FROM bars WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
                               (coin, int(t0) - 7 * 86_400, int(now) // 60 * 60)).fetchall()
            rows = [r for r in rows if r[1] and r[2] and r[3] and r[4]]
            if not rows:
                return None
            a = np.array(rows, dtype=float)
            return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4]}
        return self._gecacht((coin, "akku_nach", int(t0), int(now) // 60), 300, now, lesen)

    def _akku_nachrechnen(self, con, st, coin, now, S, W, za, f: float = 1.0):
        """
        23.70 (U184, Nutzer 19.10. 23:40: „Die Käufe sollen beim Start nachberechnet werden auf Grundlage des Datenbankstarts, also
        rückwirkend … direkt vergleichbar mit den anderen laufenden Strategien“): einmal je Strategie und Coin, solange sie dort noch keinen
        Kauf hat -- dieselbe Regel ohne Heatmap (A0, A1, A3, Sperre; frühere Heatmap-Stände rechnet das Labor nicht nach) auf den
        1-min-Kerzen ab dem Start des Coins im Labor (labor_zustand „coins“, wie die Kontotage der übrigen Strategien). σ₇ und
        200-Tage-Linie je Minute vom letzten vollen Tag davor (swing.db, wie live). Kauf zur Schwelle bzw. Eröffnung, ohne Abstand zur
        Buchmitte (die Bücher von damals fehlen); Gebühr wie live. Dazu je UTC-Tag die Tageszeile und je Kauf ein Ereignis zu seiner Zeit.
        23.72 (U186, Nutzer 20.10. 02:43: „als einmalige Regel zunächst rückwirkend … und dann ab sofort“): dazu die Spur des Korrekturkaufs
        A4 (akku_korrektur_kerzen, ohne Sperre, braucht weder σ noch 200-Tage-Linie); beide Spuren getrennt gerechnet, dann nach der Zeit
        gespeichert (bei gleicher Minute A0–A3 zuerst).
        23.74 (U189): mit dem Faktor gegenüber BTC f -- A4-Schwelle 0,93^f, jeder Kauf 5.000 USD ÷ f.
        -> Zahl der nachgerechneten Käufe (0: nichts nachzurechnen, dann folgt alles live)
        """
        R = S["regeln"]; sid = S["sid"]
        t0 = int(self.coin_start.get(coin) or now)
        za["nach"] = {"ab": t0, "bis": int(now), "n": 0}
        if t0 >= int(now) - 60:                                        # kein früherer Start des Coins: Startkauf live
            return 0
        K = self._akku_nach_kerzen(con, coin, t0, now)
        if K is None:
            return 0
        T = W["T"]; tag_ts = np.asarray(T["tag_ts"], dtype=np.int64); I = W["I"]
        voll = np.nonzero(np.asarray(T["voll"], dtype=bool))[0]
        kaeufe = []; s7 = sperre = None
        if len(voll):                                                  # Spur A0–A3 (mit Sperre) braucht die Tageskerzen
            sig = np.asarray(I.sig, dtype=float); ma = np.asarray(I.sma(int(R["ma_tage"])), dtype=float)
            vortag = K["ts"] // 86_400 * 86_400 - 86_400
            i = np.searchsorted(tag_ts[voll], vortag, side="right") - 1        # letzter volle Tag bis zum Vortag (wie labor_daten live)
            da = i >= 0; d = voll[np.maximum(i, 0)]
            with np.errstate(invalid="ignore"):
                s7 = np.where(da, sig[d], np.nan) * math.sqrt(int(R["fenster_tage"]))
                sperre = np.where(da, ma[d], np.nan) * R["ma_faktor"]
            kaeufe, _ = akku_regel_kerzen(R, K["ts"], K["o"], K["h"], K["l"], K["c"], s7, sperre, bar=60, ab=t0)
        korr = akku_korrektur_kerzen(R, K["ts"], K["o"], K["h"], K["l"], K["c"], ab=t0, bar=60, f=f) if R.get("korr") else []
        if not kaeufe and not korr:
            return 0
        H7 = akku_h7_reihe(K["ts"], K["h"], 60)
        usd = akku_betrag(R, f); geb = usd * R["geb"]
        texte = {"A0": AKKU_A0_TEXT + "{u}", "A1": "Rücksetzer: Tief ≤ {s}, 2 σ₇ unter dem 7-Tage-Hoch ({h})",
                 "A3": "Nachkauf: Tief ≤ {s}, ein σ₇ unter dem letzten Kauf ({l})"}
        zeilen = []; pL = None                                         # (ts, Spur, Nr., Auslöser, Preis, Grund, Werte)
        for nr, (t, p, a) in enumerate(kaeufe):
            j = int(np.searchsorted(K["ts"], t))
            h7 = float(H7[j]) if np.isfinite(H7[j]) else None
            schw = {"A0": p, "A1": (h7 * math.exp(-R["tiefe"] * s7[j])) if h7 else p, "A3": (pL * math.exp(-R["stufe"] * s7[j])) if pL else p}[a]
            u_ = akku_start_ursache(K["ts"], K["o"], s7, sperre, t0, t) if a == "A0" else ""
            grund = ("nachgerechnet (1-min-Kerzen): " + texte[a].format(ab=_uhr(t0), s=_g6(schw), h=_g6(h7) if h7 else "—", l=_g6(pL) if pL else "—",
                                                                        u=u_)
                     + ("" if a == "A0" or p >= schw - 1e-12 else f"; Eröffnung schon darunter, Kauf zu {_g6(p)}"))
            werte = {"h7": h7, "sigma7": float(s7[j]), "ma200": float(sperre[j] / R["ma_faktor"]), "konten": None, "cluster": None,
                     "schwellen": {"sperre": float(sperre[j])}, "nachgerechnet": True, "ab": t0, "bis": int(now), "faktor": f}
            zeilen.append((int(t), 0, nr, a, p, grund, werte)); pL = p
        pc = akku_pc(R, f) if R.get("korr") else ""
        for nr, (t, p, a, art, bez, schw) in enumerate(korr):
            grund = ("nachgerechnet (1-min-Kerzen): "
                     + (f"Korrektur: Tief ≤ {_g6(schw)}, {pc} % unter dem Hoch der letzten {int(R['korr_h'])} h ({_g6(bez)})" if art == "hoch48"
                        else f"Korrektur, Nachkauf: Tief ≤ {_g6(schw)}, {pc} % unter dem letzten Korrekturkauf ({_g6(bez)})")
                     + ("" if p >= schw - 1e-12 else f"; Eröffnung schon darunter, Kauf zu {_g6(p)}"))
            werte = {"bezug": bez, "bezug_art": art, "schwelle": schw, "korr": R["korr"], "nachgerechnet": True, "ab": t0, "bis": int(now),
                     "faktor": f}
            zeilen.append((int(t), 1, nr, a, p, grund, werte))
        zeilen.sort(key=lambda x: (x[0], x[1], x[2]))
        if self.tor is not None:                                       # 23.76 (U206): Welt A -- Käufe in Sperrzeiten fallen weg (ohne Folgen
            zeilen = [z_ for z_ in zeilen if self._tor(z_[0], "long", "vergroessern", sid, coin, z_[4])]   # für spätere Stufen: Näherung)
            if not zeilen:
                return 0
        lose = []
        for t, _sp, _nr, a, p, grund, werte in zeilen:
            menge = (usd - geb) / p
            cur = st.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte) "
                             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, coin, int(t), a, p, p, usd, menge, geb, None, grund, _j(werte)))
            self._ereignis(st, t, sid, coin, "akku", "spot", p, f"Kauf {coin} {_de(usd, 0)} USD zu {_g6(p)} (Spot) — {a}: {grund}", None,
                           cur.lastrowid)
            lose.append((int(t), menge))
        # Tageszeilen der nachgerechneten Tage (Stand am Ende jedes UTC-Tags mit Kerzen; heute schreibt der Takt)
        tage = K["ts"] // 86_400; heute = int(now) // 86_400
        for tg in range(int(lose[0][0]) // 86_400, heute):
            m_ = np.nonzero(tage == tg)[0]
            if not len(m_):
                continue
            jl = int(m_[-1]); bis = [x for x in lose if x[0] <= int(K["ts"][jl])]
            if not bis:
                continue
            mg = sum(x[1] for x in bis); px = float(K["c"][jl])
            st.execute("INSERT OR REPLACE INTO labor_akku_tag VALUES (?,?,?,?,?,?,?,?,?)",
                       (sid, coin, tg, usd * len(bis), mg, mg * px, px, len(bis), int(K["ts"][jl])))
        za["nach"]["n"] = len(zeilen); za["nach"]["korr"] = len(korr)
        return len(zeilen)

    def _akku_letzte(self, st, sid, coin, korr: bool) -> tuple:
        """23.72 (U186): (letzter Kauf der Spur A0–A3, letzter Korrekturkauf A4), je (ts, preis) oder None. Ohne Korrektur-Regel zählt
        jeder Kauf zur ersten Spur (wie bis 23.71)."""
        q = "SELECT ts, preis FROM labor_akku_kauf WHERE sid=? AND coin=?{} ORDER BY ts DESC, id DESC LIMIT 1"
        r = st.execute(q.format(" AND ausloeser<>'A4'" if korr else ""), (sid, coin)).fetchone()
        rk = st.execute(q.format(" AND ausloeser='A4'"), (sid, coin)).fetchone() if korr else None
        return ((int(r[0]), float(r[1])) if r else None), ((int(rk[0]), float(rk[1])) if rk else None)

    def _akku_eins(self, con, st, coin, E, now, z, S) -> int:
        R = S["regeln"]; sid = S["sid"]; key = f"{sid}|{coin}"
        za = z["a"].setdefault(key, {})
        b = E["preis"]; mid = b["mid"]; frisch = now - b["ts"] <= KURS_FRISCH_S
        W = E.get("swing") or {}
        sig = W.get("sigma") if W.get("ok") else None
        sig7 = sig * math.sqrt(R["fenster_tage"]) if sig else None
        ma = None
        if W.get("ok"):
            v = W["I"].sma(int(R["ma_tage"]))[W["d"]]
            ma = float(v) if np.isfinite(v) else None
        H7 = E.get("akku_h7")
        kn = E.get("konten"); konten = kn[1] if kn else None
        cl = self._akku_cluster(R, E, za, now) if R.get("cluster") else None
        korr = bool(R.get("korr"))                                    # 23.72 (U186): Korrekturkauf A4 als eigene Spur
        # 23.74 (U189): Faktor gegenüber BTC -- ohne ihn kauft die Strategie in diesem Coin nicht (auch nicht nachgerechnet)
        fk = self._akku_faktor(st, S, coin, now)
        if not fk.get("ok"):
            self.akku_status[(sid, coin)] = {"ts": now, "kurs": mid, "frisch": frisch, "kauf": None, "start": True, "naechster": None,
                                             "schwellen": {}, "grund": f"wartet: Faktor gegenüber {R.get('faktor_basis', 'BTC')} fehlt "
                                                                      f"({fk.get('grund') or 'noch nicht bestimmt'})", "faktor": fk}
            return 0
        f_ = float(fk["faktor"]); usd = akku_betrag(R, f_); geb_k = usd * R["geb"]
        letzter, letzter_k = self._akku_letzte(st, sid, coin, korr)
        # 23.70 (U184): vor dem ersten Kauf einmal rückwirkend ab dem Start des Coins im Labor nachrechnen (braucht die Tageskerzen);
        # 23.72 (U186): beide Spuren
        if R.get("start") and letzter is None and letzter_k is None and "nach" not in za and W.get("ok"):
            if self._akku_nachrechnen(con, st, coin, now, S, W, za, f_):
                letzter, letzter_k = self._akku_letzte(st, sid, coin, korr)
        Lg = akku_lage(R, mid, H7, sig7, ma, letzter, now, cl, E.get("sigma1h"), konten, frisch)
        n = 0; gekauft = []
        if Lg["kauf"] and not self._tor(now, "long", "vergroessern" if (letzter or letzter_k) else "eroeffnen", sid, coin, mid):
            Lg = dict(Lg, kauf=False, grund=f"Notbremse: Kauf gesperrt ({Lg['ausloeser']}: {Lg['grund']})")      # 23.76 (U206)
        if Lg["kauf"]:
            pr, bps = taker_preis(b, True, usd)
            menge = (usd - geb_k) / pr
            werte = {"h7": H7, "sigma7": sig7, "ma200": ma, "konten": konten, "cluster": cl, "schwellen": Lg["schwellen"], "faktor": f_}
            cur = st.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte) "
                             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, coin, now, Lg["ausloeser"], pr, mid, usd, menge, geb_k, bps, Lg["grund"],
                                                                  _j(werte)))
            # 23.70 (U184): Spot-Kauf -- im Ereignis als „spot“ (bis 23.69 „long“), Betrag und Gebühr mit deutschen Trennzeichen
            self._ereignis(st, now, sid, coin, "akku", "spot", pr, f"Kauf {coin} {_de(usd, 0)} USD zu {_g6(pr)} (Spot, Taker "
                           f"{_de(R['geb'] * 100, 3)} %) — {Lg['ausloeser']}: {Lg['grund']}", None, cur.lastrowid)
            n = 1; letzter = (now, pr); gekauft.append(Lg["ausloeser"])
        # 23.72 (U186): Korrekturkauf A4 -- erst nach der Rückrechnung (sonst rechnete sie ihn doppelt), ohne Sperre, eigener letzter Kauf
        Lk = None; H48 = None
        if korr and ("nach" in za or letzter is not None or letzter_k is not None or not R.get("start")):
            ab_k = int(letzter_k[0]) // 60 * 60 + 60 if letzter_k else None          # 48-h-Hoch erst ab der Minute nach dem Kauf
            if ab_k and ab_k > now - int(R["korr_h"]) * 3600:
                H48 = self._akku_h48(con, coin, now, ab_k, int(R["korr_h"]))
            else:
                H48 = E["akku_h48"] if "akku_h48" in E else self._akku_h48(con, coin, now, None, int(R["korr_h"]))
            Lk = akku_korrektur_lage(R, mid, H48, letzter_k, now, frisch, f_)
            if Lk["kauf"] and not self._tor(now, "long", "vergroessern", sid, coin, mid):
                Lk = dict(Lk, kauf=False, grund=f"Notbremse: Korrekturkauf gesperrt ({Lk['grund']})")          # 23.76 (U206)
            if Lk["kauf"]:
                pr, bps = taker_preis(b, True, usd)
                menge = (usd - geb_k) / pr
                werte = {"h48": H48, "bezug": Lk["bezug"], "bezug_art": Lk["bezug_art"], "schwelle": Lk["schwelle"], "korr": R["korr"],
                         "letzter_korr": list(letzter_k) if letzter_k else None, "faktor": f_}
                cur = st.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte) "
                                 "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (sid, coin, now, "A4", pr, mid, usd, menge, geb_k, bps, Lk["grund"],
                                                                      _j(werte)))
                self._ereignis(st, now, sid, coin, "akku", "spot", pr, f"Kauf {coin} {_de(usd, 0)} USD zu {_g6(pr)} (Spot, Taker "
                               f"{_de(R['geb'] * 100, 3)} %) — A4: {Lk['grund']}", None, cur.lastrowid)
                n += 1; letzter_k = (now, pr); gekauft.append("A4")
        if n or now - int(za.get("_tag_ts", 0)) >= AKKU_TAG_S:
            s_ = st.execute("SELECT COUNT(*), COALESCE(SUM(usd), 0), COALESCE(SUM(menge), 0) FROM labor_akku_kauf WHERE sid=? AND coin=?",
                            (sid, coin)).fetchone()
            if s_[0]:
                st.execute("INSERT OR REPLACE INTO labor_akku_tag VALUES (?,?,?,?,?,?,?,?,?)",
                           (sid, coin, now // 86_400, float(s_[1]), float(s_[2]), float(s_[2]) * mid, mid, int(s_[0]), now))
            za["_tag_ts"] = now
        self.akku_status[(sid, coin)] = {"ts": now, "kurs": mid, "h7": H7, "sigma7": sig7, "ma200": ma, "konten": konten,
                                         "konten_ts": kn[0] if kn else None, "cluster": cl, "letzter": list(letzter) if letzter else None,
                                         "grund": Lg["grund"], "schwellen": Lg["schwellen"], "warten": Lg["warten"], "nachkauf": Lg["nachkauf"],
                                         "naechster": Lg["naechster"], "frisch": frisch, "kauf": ", ".join(gekauft) if gekauft else None,
                                         "start": Lg["start"], "nach": dict(za["nach"]) if isinstance(za.get("nach"), dict) else None,
                                         "korrektur": ({"h48": H48, "schwelle": Lk["schwelle"], "bezug": Lk["bezug"], "bezug_art": Lk["bezug_art"],
                                                        "nachkauf": Lk["nachkauf"], "bis": Lk["bis"], "grund": Lk["grund"],
                                                        "letzter": list(letzter_k) if letzter_k else None, "naechster": Lk["naechster"],
                                                        "prozent": (1.0 - akku_korr_q(R, f_)) * 100, "stunden": int(R["korr_h"]),
                                                        "tage": int(R["korr_tage"])}
                                                       if Lk else None),
                                         "faktor": fk, "usd": usd}
        return n

    def _pos(self, st, pid) -> dict:
        return dict(zip(POS_SPALTEN, st.execute(f"SELECT {', '.join(POS_SPALTEN)} FROM labor_position WHERE id=?", (pid,)).fetchone()))

    # --- Grid (23.40, Nutzer 01.10.: „Range automatisch erkennen und anpassen; bei einer starken Bewegung aufwärts das Maximum abwarten und
    #     nicht zu früh verkaufen; bei stark fallenden Kursen ein Notausstieg“ -- dazu das Spiegelbild Short).
    #     Ein Grid je Strategie und Coin: Stufen L0 < … < Ln, Abstand i = [Li, Li+1] hält entweder ein Los oder eine Einstiegs-Order.
    #     Long kauft bei Li und verkauft bei Li+1, Short verkauft bei Li+1 und kauft bei Li zurück. Modi: warten → aktiv → halten / pause.
    #     Lose = labor_position (Notional = Kapital / n), Einstiegs-Orders = labor_order (nur offene; gefüllte und gelöschte verschwinden),
    #     Zustand = labor_zustand „g“. Füllungen und Ziele aus 1-min-Kerzen (wie die übrigen Strategien: ein Limit füllt nur, wenn der Kurs
    #     DURCH den Preis läuft; liegen Notlinie oder Trailing-Stop in derselben Kerze, gilt der Stop), Auslöser zusätzlich im 15-s-Takt.
    _LOS_SPALTEN = ("id", "sid", "coin", "seite", "eroeffnet", "preis_ein", "notional", "menge", "gebuehr_ein", "sl", "tp", "nur_stop_bis",
                    "funding", "funding_bis", "mae_pct", "mfe_pct", "werte")

    def _grid(self, con, st, coin, E, now, z) -> int:
        """Beide Grids eines Coins, jedes hinter einem eigenen Sicherungspunkt: Ein Fehler setzt nur dieses Grid in diesem Takt zurück
        (Datenbank und Zustand), statt halbe Änderungen zu speichern."""
        if not self.grid_strategien:
            return 0
        n = 0
        if coin not in self._grid_alt_ok:
            try:
                n += self._grid_alt_aufraeumen(con, st, coin, E, now)
            except Exception as e:
                self._fehler(f"Grid {coin} Aufräumen: {type(e).__name__}: {e}")
        for S in self.grid_strategien:
            key = f"{S['sid']}|{coin}"
            vorher = json.loads(_j(z["g"][key])) if isinstance(z["g"].get(key), dict) else None
            try:
                if not st.in_transaction:
                    # 23.41: IMMEDIATE -- Schreibsperre gleich zu Beginn (wartet wie jeder Schreibzugriff bis 30 s). 23.40 öffnete hier mit
                    # einem einfachen BEGIN eine LESE-Transaktion; schrieb danach ein anderer Thread (Prognose, Familien, Profis), scheiterte
                    # der nächste Schreibzugriff des Labors in diesem Takt SOFORT mit „database is locked“ (veralteter Lesestand, die Wartezeit
                    # greift nicht). Pi 02.10. 06:57: „ZEC Handel: OperationalError: database is locked“. Dieselbe Falle wie im Recorder
                    # am 14.09. (hl_recorder.db_connect, hl_dbcoord: „ein von Hand ausgeführtes BEGIN“).
                    st.execute("BEGIN IMMEDIATE")
                st.execute("SAVEPOINT grid_eins")
            except sqlite3.OperationalError as e:                        # Sperre länger als 30 s belegt: nur die Grids setzen aus
                self._fehler(f"Grid {coin}: Schreibsperre nicht frei ({e}) -- Grids setzen diesen Takt aus")
                return n
            try:
                n += self._grid_eins(con, st, coin, E, now, z, S)
                st.execute("RELEASE grid_eins")
            except Exception as e:
                st.execute("ROLLBACK TO grid_eins"); st.execute("RELEASE grid_eins")
                if vorher is None:
                    z["g"].pop(key, None)
                else:
                    z["g"][key] = vorher
                self._fehler(f"{S['name']} {coin}: {type(e).__name__}: {e}")
        return n

    def _grid_eins(self, con, st, coin, E, now, z, S) -> int:
        key = f"{S['sid']}|{coin}"; gs = z["g"].get(key)
        if not isinstance(gs, dict):
            gs = z["g"][key] = {"modus": "warten", "seit": now, "gen": 0, "gepr": now // 60 * 60, "zaehler": {}}
        gs.setdefault("zaehler", {})
        lose = self._grid_lose(st, S["sid"], coin); orders = self._grid_orders(st, S["sid"], coin)
        n, aufgeholt = self._grid_kerzen(con, st, S, gs, coin, E, now, lose, orders)
        b = E.get("preis")
        if aufgeholt and b and now - b["ts"] <= KURS_FRISCH_S:          # Auslöser und Aufbau nur mit frischem Kurs und nachgeholten Kerzen
            n += self._grid_takt(con, st, S, gs, coin, E, now, lose, orders)
            n += self._grid_pruefen(con, st, S, gs, coin, E, now, lose, orders)
        self._grid_speichern(st, lose)
        self._grid_tag(st, S, gs, coin, E, now, lose, n > 0)
        self.status[(S["sid"], coin)] = self._grid_status(S, gs, E, now, lose, orders)
        return n

    # Lose und Orders
    def _grid_lose(self, st, sid, coin, pid=None) -> list:
        q = f"SELECT {', '.join(self._LOS_SPALTEN)} FROM labor_position WHERE status='offen' AND "
        rows = st.execute(q + "id=?", (pid,)) if pid else st.execute(q + "sid=? AND coin=? ORDER BY eroeffnet, id", (sid, coin))
        out = []
        for r in rows:
            p = dict(zip(self._LOS_SPALTEN, r))
            try:
                w = json.loads(p.pop("werte") or "{}")
            except ValueError:
                w = {}
            p["stufe"] = w.get("stufe"); p["gen"] = w.get("gen"); p["ab"] = int(p.pop("nur_stop_bis") or 0)
            p["funding"] = p["funding"] or 0.0; p["mae_pct"] = p["mae_pct"] or 0.0; p["mfe_pct"] = p["mfe_pct"] or 0.0
            p["funding_bis"] = int(p["funding_bis"] or p["eroeffnet"]); p["_dirty"] = False
            out.append(p)
        return out

    def _grid_orders(self, st, sid, coin) -> list:
        out = []
        for oid, seite, preis, werte, ab, tp in st.execute("SELECT id, seite, preis, werte, geprueft_bis, tp_px FROM labor_order "
                                                           "WHERE status='offen' AND sid=? AND coin=? ORDER BY preis", (sid, coin)).fetchall():
            try:
                w = json.loads(werte or "{}")
            except ValueError:
                w = {}
            out.append({"id": oid, "seite": seite, "preis": preis, "stufe": w.get("stufe"), "gen": w.get("gen"), "ab": int(ab or 0), "tp": tp})
        return out

    def _grid_speichern(self, st, lose) -> None:
        w = [(p["funding"], p["funding_bis"], p["mae_pct"], p["mfe_pct"], p["sl"], p["tp"], p["id"]) for p in lose if p.get("_dirty")]
        if w:
            st.executemany("UPDATE labor_position SET funding=?, funding_bis=?, mae_pct=?, mfe_pct=?, sl=?, tp=? WHERE id=?", w)
        for p in lose:
            p["_dirty"] = False

    def _grid_order(self, st, S, coin, gs, i, t) -> dict:
        """Einstiegs-Order für Abstand i der aktuellen Generation; füllbar erst ab der nächsten vollen Minute (keine Kerze, die schon lief)."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]
        preis, tp = (L[i], L[i + 1]) if lang else (L[i + 1], L[i])
        ab = -(-int(t) // 60) * 60
        cur = st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, sl_rel, tp_rel, sl_px, tp_px, "
                         "halten_s, geprueft_bis) VALUES (?,?,?,?,?,?,'offen',?,?,NULL,NULL,?,?,0,?)",
                         (S["sid"], coin, "long" if lang else "short", preis, int(t), int(t) + 365 * 86_400,
                          f"Grid {gs['gen']}: {'Kauf' if lang else 'Verkauf'} Stufe {i + 1}/{gs['n']}, Ziel {tp:.6g}",
                          _j({"stufe": i, "gen": gs["gen"]}), gs["notlinie"], tp, ab))
        return {"id": cur.lastrowid, "seite": "long" if lang else "short", "preis": preis, "stufe": i, "gen": gs["gen"], "ab": ab, "tp": tp}

    def _grid_orders_weg(self, st, orders) -> None:
        if orders:
            st.executemany("DELETE FROM labor_order WHERE id=?", [(o["id"],) for o in orders])
            orders.clear()

    def _grid_los_auf(self, st, S, coin, gs, i, t, preis, slip_bps, satz, art, ab) -> dict:
        """Los für Abstand i (Ziel eine Stufe weiter, Notlinie als Stop). ab = erste Kerze, in der das Ziel zählen darf."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]
        pid = self._eroeffnen(st, coin, S, "long" if lang else "short", t, preis, slip_bps, satz, art, gs["notlinie"], L[i + 1] if lang else L[i], 0,
                              f"Grid {gs['gen']}: Stufe {i + 1}/{gs['n']}", {"stufe": i, "gen": gs["gen"]}, None, pruef_ab=int(ab), nur_stop_bis=int(ab),
                              notional=gs["los_usd"], ereignis_art="grid_los", tor_art="grid_kauf")
        if pid is None:                                                   # 23.76 (U206): Notbremse (Welt A)
            return None
        return self._grid_lose(st, S["sid"], coin, pid=pid)[0]

    def _grid_wert(self, coin, lose, mid) -> float | None:
        """Bestandswert (unrealisiert) zum Kurs mid nach Ausstiegsgebühr (Taker) und Funding -- wie die offenen Positionen der Übersicht."""
        if not lose:
            return 0.0
        if not mid:
            return None
        v = 0.0
        for p in lose:
            v += ((mid - p["preis_ein"]) * p["menge"] * (1 if p["seite"] == "long" else -1) - p["gebuehr_ein"]
                  - p["menge"] * mid * gebuehr(coin, GEB_TAKER) - (p["funding"] or 0.0))
        return v

    def _grid_alle_zu(self, con, st, coin, lose, b, t, px, art, grund) -> float:
        """Alle Lose eines Grids zum Marktpreis (Taker) als EIN Auftrag über die Summe -- Marktauswirkung aus der Buchtiefe für die ganze
        Menge. px = Ausführungsmitte aus der Kerze (Stop, bei Kurslücke die Eröffnung); None = Buch des Taktes."""
        if not lose:
            return 0.0
        lang = lose[0]["seite"] == "long"
        pr, bps = taker_preis(dict(b, mid=px) if px else b, not lang, sum(p["notional"] for p in lose))
        netto = 0.0
        for p in lose:
            self._funding_nachziehen(con, p, t)
            netto += self._schliessen(st, p, pr, art, GEB_TAKER, bps, grund, t, None, ereignis_art="grid_los")
        lose.clear()
        return netto

    # Zustandswechsel
    def _grid_ruhe(self, st, S, gs, coin, orders, t, stunden, text, preis=None, netto=None) -> None:
        """Pause: Orders weg, neue Range erst nach `stunden` und nur aus Kursen ab jetzt."""
        self._grid_orders_weg(st, orders)
        bis = int(t) + int(stunden * 3600)
        gs.update(modus="pause", seit=int(t), reset=int(t), pause_bis=bis, halten=None, hinweis=None)
        self._ereignis(st, t, S["sid"], coin, "grid", S["regeln"]["richtung"], preis,
                       f"{text}; Pause bis {_uhr(bis)}, danach neue Range nur aus Kursen ab jetzt", netto)

    def _grid_notaus(self, con, st, S, gs, coin, lose, orders, b, t, px, grund) -> None:
        """Alle Lose zum Marktpreis, Orders weg, Pause: 4 h, nach dem zweiten Notausstieg binnen 24 h 12 h, nach dem dritten 24 h."""
        n_ = len(lose)
        netto = self._grid_alle_zu(con, st, coin, lose, b, t, px, "Notausstieg (Taker)", "Notausstieg: " + grund)
        gs["zaehler"]["notaus"] = gs["zaehler"].get("notaus", 0) + 1
        zeiten = [x for x in (gs.get("notaus_t") or []) if int(t) - int(x) < 86_400] + [int(t)]
        gs["notaus_t"] = zeiten
        stufen = list(S["regeln"]["pause_notaus_h"]); h = stufen[min(len(zeiten), len(stufen)) - 1]
        self._grid_ruhe(st, S, gs, coin, orders, t, h,
                        f"Notausstieg: {grund} — " + (f"{n_} Lose zum Marktpreis geschlossen, netto {netto:+.2f} USD" if n_ else "keine Lose offen")
                        + (f" ({len(zeiten)}. Notausstieg binnen 24 h: {h} h Pause)" if len(zeiten) > 1 else ""),
                        px or b.get("mid"), netto if n_ else None)

    def _grid_halten(self, st, S, gs, coin, lose, orders, t, px, extrem, sig1h, grund) -> None:
        """Starke Bewegung in Gewinnrichtung: Ziele aussetzen, alle Lose halten, Trailing-Stop trail · σ(1 h) vom Extrem (zählt ab der
        nächsten vollen Kerze -- die laufende enthält Kurse von vor dem Auslöser)."""
        R = S["regeln"]; lang = R["richtung"] == "long"
        ext = max(px, extrem) if lang else min(px, extrem)
        stop = ext * (1 - R["trail"] * sig1h) if lang else ext * (1 + R["trail"] * sig1h)
        gs.update(modus="halten", seit=int(t), halten={"start": int(t), "ab": -(-int(t) // 60) * 60, "start_px": px, "extrem": ext, "stop": stop,
                                                        "sig": sig1h, "grund": grund})
        gs["zaehler"]["halten"] = gs["zaehler"].get("halten", 0) + 1
        self._grid_orders_weg(st, orders)
        for p in lose:
            p["tp"] = None; p["sl"] = stop; p["_dirty"] = True
        self._ereignis(st, t, S["sid"], coin, "grid", R["richtung"], px,
                       f"{grund}: {'Verkäufe' if lang else 'Rückkäufe'} ausgesetzt, {len(lose)} Lose werden gehalten; Trailing-Stop {R['trail']:g} σ(1 h) "
                       f"= {R['trail'] * sig1h * 100:.2f} % {'unter dem höchsten Hoch' if lang else 'über dem tiefsten Tief'}, jetzt {stop:.6g}")

    def _grid_halten_ende(self, con, st, S, gs, coin, lose, orders, b, t, px) -> None:
        R = S["regeln"]; lang = R["richtung"] == "long"; H = gs.get("halten") or {}; n_ = len(lose)
        netto = self._grid_alle_zu(con, st, coin, lose, b, t, px, "Trailing-Stop (Taker)",
                                   f"Halten beendet: {R['trail']:g} σ(1 h) vom {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} zurück")
        self._grid_ruhe(st, S, gs, coin, orders, t, R["pause_trail_h"],
                        f"Halten beendet: Kurs {'fiel' if lang else 'stieg'} {R['trail']:g} σ(1 h) vom {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} "
                        f"zurück (Start {H.get('start_px', 0):.6g} um {_uhr(H.get('start'))}) — {n_} Lose zu etwa {px:.6g} geschlossen, "
                        f"netto {netto:+.2f} USD", px, netto)

    # Kerzen, Takt, Range
    def _grid_kerzen(self, con, st, S, gs, coin, E, now, lose, orders) -> tuple:
        """Abgeschlossene Kerzen seit dem letzten Stand nachspielen. Nach langem Ausfall in Etappen von höchstens 3 Tagen je Takt -- bis
        alles nachgeholt ist (zweiter Wert False), gibt es keine Auslöser und keinen Aufbau zum Kurs von jetzt."""
        t0 = int(gs.get("gepr") or now // 60 * 60); t1 = min(now // 60 * 60, t0 + 3 * 86_400)
        if t1 <= t0:
            return 0, True
        schluss = {}; n = 0
        for ts, o, hi, lo, c in kerzen(con, coin, t0 - 15 * 60, t1):
            schluss[ts] = c
            if ts < t0:
                continue
            n += self._grid_kerze(con, st, S, gs, coin, E, lose, orders, ts, o, hi, lo, c, schluss.get(ts - 15 * 60), schluss.get(ts - 5 * 60))
            gs["gepr"] = ts + 60
        return n, t1 >= now // 60 * 60

    def _grid_kerze(self, con, st, S, gs, coin, E, lose, orders, ts, o, hi, lo, c, c15, c5) -> int:
        """Eine abgeschlossene 1-min-Kerze. Reihenfolge (vorsichtig): Einstiege in Verlustrichtung zuerst, dann Notlinie bzw. Trailing-Stop
        für ALLE Lose (auch die eben gefüllten), erst dann Ziele; Auslöser zum Kerzenschluss; zuletzt freie Abstände neu belegen."""
        R = S["regeln"]; lang = R["richtung"] == "long"; b = E["preis"]; m = gs.get("modus"); n = 0
        for p in lose:
            if ts + 60 <= p["eroeffnet"]:
                continue
            self._funding_nachziehen(con, p, ts + 60)
            pin = p["preis_ein"]
            p["mae_pct"] = max(p["mae_pct"], ((pin - lo) / pin if lang else (hi - pin) / pin) * 100)
            if ts >= p["ab"]:
                p["mfe_pct"] = max(p["mfe_pct"], ((hi - pin) / pin if lang else (pin - lo) / pin) * 100)
            p["_dirty"] = True
        if m == "halten":
            H = gs.get("halten") or {}
            if not lose:                                                  # nichts mehr zu halten (z. B. abgelöste Regelversion)
                self._grid_ruhe(st, S, gs, coin, orders, ts + 60, R["pause_trail_h"], "Halten beendet: keine Lose mehr")
                return 1
            if ts >= H["ab"] and ((lang and lo <= H["stop"]) or (not lang and hi >= H["stop"])):
                self._grid_halten_ende(con, st, S, gs, coin, lose, orders, b, ts + 60, min(o, H["stop"]) if lang else max(o, H["stop"]))
                return 1
            if ts + 60 > H["start"]:
                ext = max(H["extrem"], hi) if lang else min(H["extrem"], lo)
                stop = ext * (1 - R["trail"] * H["sig"]) if lang else ext * (1 + R["trail"] * H["sig"])
                stop = max(stop, H["stop"]) if lang else min(stop, H["stop"])
                if ext != H["extrem"] or stop != H["stop"]:
                    H["extrem"] = ext; H["stop"] = stop
                    for p in lose:
                        p["sl"] = stop; p["_dirty"] = True
            return 0
        if m != "aktiv":
            return 0
        # 1. Einstiege: Limits, durch die der Kurs läuft (Long: Tief unter dem Kauf-Limit, Short: Hoch über dem Verkaufs-Limit)
        for od in list(orders):
            if od["ab"] > ts or not ((lang and lo < od["preis"]) or (not lang and hi > od["preis"])):
                continue
            if lang and not self._tor(ts + 30, "long", "grid_kauf", S["sid"], coin, od["preis"]):    # 23.76 (U206): Zeit der Füllung
                st.execute("UPDATE labor_order SET status='storniert', erledigt=? WHERE id=?", (ts + 60, od["id"])); orders.remove(od)
                self._ereignis(st, ts + 60, S["sid"], coin, "notbremse", "long", od["preis"], f"Notbremse: Grid-Kauf {coin} bei {od['preis']:.6g} "
                               f"um {_uhr(ts + 30)} verworfen, Order storniert")
                continue
            st.execute("DELETE FROM labor_order WHERE id=?", (od["id"],)); orders.remove(od)
            if od.get("gen") != gs.get("gen") or od.get("stufe") is None or not 0 <= od["stufe"] < gs["n"]:
                continue
            los_ = self._grid_los_auf(st, S, coin, gs, od["stufe"], ts + 30, od["preis"], 0.0, GEB_MAKER,
                                      "Grid-Kauf (Maker)" if lang else "Grid-Verkauf (Maker)", ts + 60)
            if los_ is None:
                continue
            lose.append(los_)
            gs["zaehler"]["einstiege"] = gs["zaehler"].get("einstiege", 0) + 1
            n += 1
        # 2. Notlinie eine Stufe jenseits der Range: gilt für alle Lose, auch die eben gefüllten
        nl = gs["notlinie"]
        if (lang and lo <= nl) or (not lang and hi >= nl):
            self._grid_notaus(con, st, S, gs, coin, lose, orders, b, ts + 60, min(o, nl) if lang else max(o, nl),
                              f"Kurs {'unter' if lang else 'über'} der Notlinie {nl:.6g} (eine Stufe {'unter' if lang else 'über'} der Range)")
            return n + 1
        # 3. Ziele (Maker), nicht in der Einstiegskerze
        for p in list(lose):
            if p["tp"] is None or ts < p["ab"] or not ((lang and hi > p["tp"]) or (not lang and lo < p["tp"])):
                continue
            self._schliessen(st, p, p["tp"], "Grid-Verkauf (Maker)" if lang else "Grid-Rückkauf (Maker)", GEB_MAKER, 0.0,
                             f"Grid-Ziel {p['tp']:.6g}", ts + 60, None, ereignis_art="grid_los")
            lose.remove(p); n += 1
            gs["zaehler"]["runden"] = gs["zaehler"].get("runden", 0) + 1
        # 4. Starke Bewegung zum Kerzenschluss (z über 15 und 5 min aus den Schlusskursen; σ(5 min) = σ(15 min) / √3)
        z15 = math.log(c / c15) / max(E["sigma15"], 1e-6) if c15 else None
        z5 = math.log(c / c5) / max(E["sigma15"] / math.sqrt(3), 1e-6) if c5 else None
        n += self._grid_ausloeser(con, st, S, gs, coin, E, lose, orders, ts + 60, c, z15, z5, None, hi if lang else lo, False)
        # 5. Freie Abstände der aktuellen Generation wieder belegen (nach einem Verkauf liegt dort wieder ein Kauf-Limit)
        if gs.get("modus") == "aktiv":
            n += self._grid_auffuellen(st, S, gs, coin, lose, orders, ts + 60, c)
        return n

    def _grid_takt(self, con, st, S, gs, coin, E, now, lose, orders) -> int:
        K = E.get("kaskade") or {}
        if K.get("aktiv") and K.get("id") is not None and gs.get("modus") != "aktiv":
            gs["kaskade_id"] = K["id"]                                    # außerhalb von „aktiv“ gesehen: später nicht mehr auslösen
        b = E["preis"]
        alt5 = [x for x in (E.get("kerzen20") or []) if x[0] <= now // 60 * 60 - 5 * 60]     # wie z15 der Kaskade: Schluss vor 5 min
        z5 = math.log(b["mid"] / alt5[-1][4]) / max(E["sigma15"] / math.sqrt(3), 1e-6) if alt5 and alt5[-1][4] else None
        return self._grid_ausloeser(con, st, S, gs, coin, E, lose, orders, now, b["mid"], K.get("z"), z5, K, b["mid"], True)

    def _grid_ausloeser(self, con, st, S, gs, coin, E, lose, orders, t, px, z15, z5, K, extrem, takt) -> int:
        """Starke Bewegung gegen das Grid → Notausstieg (Kaskade, z15 in der ungünstigen Hälfte); in Gewinnrichtung → halten (mit Bestand)
        bzw. ruhen (Range verlassen, kein Bestand) -- dort zählt auch z5, sonst ist der Bestand eines engen Grids schon verkauft.
        K = Kaskaden-Stand (nur im Takt); jede Kaskade zählt einmal."""
        if gs.get("modus") != "aktiv":
            return 0
        R = S["regeln"]; lang = R["richtung"] == "long"; zg = R["bewegung_z"]
        kas = None
        if K and K.get("aktiv") and K.get("id") is not None and K.get("id") != gs.get("kaskade_id"):
            kas = K.get("richtung"); gs["kaskade_id"] = K["id"]
        mitte = math.sqrt(gs["unten"] * gs["oben"])
        grund = None
        if kas == ("ab" if lang else "auf"):
            grund = (f"{'Liquidationskaskade abwärts' if lang else 'Short-Squeeze aufwärts'} ({(K.get('z_start') or 0):+.1f} σ in 15 min, "
                     f"{(K.get('liq_usd') or 0) / 1e6:.2f} Mio {'Long' if lang else 'Short'}-Liquidationen)")
        elif z15 is not None and (z15 <= -zg if lang else z15 >= zg) and (px < mitte if lang else px > mitte):
            grund = f"{z15:+.1f} σ in 15 min in der {'unteren' if lang else 'oberen'} Hälfte der Range"
        if grund:
            self._grid_notaus(con, st, S, gs, coin, lose, orders, E["preis"], t, None if takt else px, grund)
            return 1
        raus = (px > gs["oben"] * (1 + gs["schritt"])) if lang else (px < gs["unten"] * (1 - gs["schritt"]))
        guenstig = px > mitte if lang else px < mitte          # Schub nur in der Gewinnhälfte: unten ist ein schneller Anstieg ein Rücklauf
        if kas == ("auf" if lang else "ab"):
            grund = f"{'Short-Squeeze aufwärts' if lang else 'Liquidationskaskade abwärts'} ({(K.get('z_start') or 0):+.1f} σ in 15 min)"
        elif guenstig and z15 is not None and (z15 >= zg if lang else z15 <= -zg):
            grund = f"Starke Bewegung {'aufwärts' if lang else 'abwärts'}: {z15:+.1f} σ in 15 min"
        elif guenstig and z5 is not None and (z5 >= zg if lang else z5 <= -zg):
            grund = f"Starke Bewegung {'aufwärts' if lang else 'abwärts'}: {z5:+.1f} σ in 5 min"
        elif raus:
            grund = f"Ausbruch {'über' if lang else 'unter'} die Range ({gs['oben'] if lang else gs['unten']:.6g})"
        if not grund:
            return 0
        n_v = 0
        if lose and takt:
            # im Takt (mitten in der Minute): Ziele, die der Kurs bis jetzt schon durchlaufen hat, waren vor dem Auslöser verkauft
            for p in [p for p in lose if p["tp"] is not None and ((lang and p["tp"] <= px) or (not lang and p["tp"] >= px))]:
                self._schliessen(st, p, p["tp"], "Grid-Verkauf (Maker)" if lang else "Grid-Rückkauf (Maker)", GEB_MAKER, 0.0,
                                 f"Grid-Ziel {p['tp']:.6g}", t, None, ereignis_art="grid_los")
                lose.remove(p); n_v += 1
                gs["zaehler"]["runden"] = gs["zaehler"].get("runden", 0) + 1
        if lose:
            self._grid_halten(st, S, gs, coin, lose, orders, t, px, extrem, E["sigma1h"], grund)
            return 1 + n_v
        if raus:
            self._grid_ruhe(st, S, gs, coin, orders, t, R["pause_trail_h"], f"{grund}, ohne Bestand — Grid ruht", px)
            return 1 + n_v
        return n_v

    def _grid_auffuellen(self, st, S, gs, coin, lose, orders, t, px) -> int:
        """Freie Abstände der aktuellen Generation auf der Einstiegsseite (Long: unter dem Kurs) mit Orders belegen, nächste am Kurs zuerst --
        nur soweit das Kapital reicht (Lose aller Generationen + liegende Orders <= GRID_KAPITAL)."""
        lang = S["regeln"]["richtung"] == "long"; L = gs["stufen"]; los = gs["los_usd"]; g = gs["gen"]
        frei = GRID_KAPITAL - sum(p["notional"] for p in lose) - los * len(orders)
        if frei < los - 1e-6:
            return 0
        if lang and not self._tor(t, "long", "limit_setzen", S["sid"], coin, px):          # 23.76 (U206): keine neuen Kauf-Limits
            return 0
        belegt = {p["stufe"] for p in lose if p.get("gen") == g} | {o["stufe"] for o in orders}
        kand = sorted((i for i in range(gs["n"]) if i not in belegt and (L[i] < px if lang else L[i + 1] > px)),
                      key=lambda i: -L[i] if lang else L[i + 1])
        neu = 0
        for i in kand:
            if frei < los - 1e-6:
                break
            orders.append(self._grid_order(st, S, coin, gs, i, t)); frei -= los; neu += 1
        return neu

    def _grid_pruefen(self, con, st, S, gs, coin, E, now, lose, orders) -> int:
        """Range prüfen: im Modus „warten“ jede Minute (Aufbau), im Modus „aktiv“ alle pruef_min Minuten (Nachführen)."""
        R = S["regeln"]; m = gs.get("modus")
        if m == "halten":
            return 0
        if m == "pause":
            if now < int(gs.get("pause_bis") or 0):
                return 0
            gs.update(modus="warten", seit=now); m = "warten"
        if R["richtung"] == "long" and self.tor is not None:
            ok_, g_ = self.tor.darf(now, "long", "grid_kauf")
            if not ok_:                                                   # 23.76 (U206): kein Aufbau und kein Nachführen nach unten
                gs["hinweis"] = f"{g_}: kein Aufbau, kein Nachführen" if m == "warten" else gs.get("hinweis")
                return 0
        if now - int(gs.get("geprueft") or 0) < (60 if m == "warten" else int(R["pruef_min"]) * 60):
            return 0
        gs["geprueft"] = now
        von = max(now - int(R["fenster_h"] * 3600), int(gs.get("reset") or 0))
        # Ergebnis (nicht die Kursliste) je Minute zwischenspeichern: beide Grids eines Coins rechnen meist dasselbe Fenster
        rg = self._gecacht((coin, "grid_rg", von // 60, now // 60, R["p_rand"]), 60, now,
                           lambda: grid_range(grid_kurse(con, coin, von, now // 60 * 60), R["p_rand"]))
        K = E.get("kaskade") or {}; px = E["preis"]["mid"]
        if not rg:
            gs["hinweis"] = f"sammelt Kurse seit {_uhr(von)} (mindestens 2 h)"
            return 0
        stufen = grid_stufen(rg["unten"], rg["oben"], R["schritt_min"], R["stufen_min"], R["stufen_max"])
        gs["range_jetzt"] = {"unten": rg["unten"], "oben": rg["oben"], "trend": rg["trend"], "von": von, "ts": now}
        seitwaerts = grid_trend_ok(rg["trend"], R)
        if m == "warten":
            if K.get("aktiv"):
                grund = "Kaskade läuft"
            elif not seitwaerts:
                lang = R["richtung"] == "long"
                grund = ("Trend " + ("—" if rg["trend"] is None else f"{rg['trend']:+.1f}") + f" (aufgebaut wird bei {-R['trend_gegen'] if lang else -R['trend_mit']:+g} "
                         f"bis {R['trend_mit'] if lang else R['trend_gegen']:+g})").replace(".", ",")
            elif not stufen:
                grund = (f"Range zu eng ({(rg['oben'] / rg['unten'] - 1) * 100:.2f} %; mindestens {R['stufen_min']} Stufen à "
                         f"{R['schritt_min'] * 100:.1f} %)").replace(".", ",")
            else:
                L, schritt = stufen; zone = R["zone"] * (L[-1] - L[0])
                grund = None if L[0] + zone <= px <= L[-1] - zone else f"Kurs am Rand der Range {L[0]:.6g}–{L[-1]:.6g}"
            if grund:
                gs["hinweis"] = grund
                return 0
            return self._grid_aufbauen(st, S, gs, coin, E, now, stufen[0], stufen[1], rg, lose, orders, "aufgebaut")
        # aktiv: nachführen, wenn sich die Range deutlich verändert hat -- nur seitwärts, ohne Kaskade, Kurs innerhalb der neuen Range
        if K.get("aktiv") or not seitwaerts or not stufen:
            return 0
        L, schritt = stufen
        if not L[0] < px < L[-1]:
            return 0
        verschoben = abs(math.log(math.sqrt(L[0] * L[-1]) / math.sqrt(gs["unten"] * gs["oben"]))) >= R["verschiebung"] * gs["schritt"]
        breite = abs(math.log(math.log(L[-1] / L[0]) / math.log(gs["oben"] / gs["unten"]))) >= math.log(1 + R["breite_rel"])
        if not (verschoben or breite):
            return 0
        return self._grid_aufbauen(st, S, gs, coin, E, now, L, schritt, rg, lose, orders, "nachgeführt")

    def _grid_aufbauen(self, st, S, gs, coin, E, now, L, schritt, rg, lose, orders, art) -> int:
        """Neue Generation von Stufen. Bestand wie bei einem klassischen Grid: Abstände jenseits des Kurses in Gewinnrichtung (Long: darüber)
        halten ein Los, die übrigen eine Einstiegs-Order. Vorhandene Lose (auch älterer Generationen) behalten ihr Ziel und zählen auf den
        Bestand an: gekauft wird nur, was zum klassischen Bestand fehlt; Orders nur, soweit das Kapital reicht."""
        R = S["regeln"]; lang = R["richtung"] == "long"; b = E["preis"]; px = b["mid"]; n = len(L) - 1
        self._grid_orders_weg(st, orders)
        gen = int(gs.get("gen") or 0) + 1; los = GRID_KAPITAL / n
        nl = L[0] * (1 - R["puffer"] * schritt) if lang else L[-1] * (1 + R["puffer"] * schritt)
        gs.update(modus="aktiv", gen=gen, stufen=L, n=n, schritt=schritt, unten=L[0], oben=L[-1], notlinie=nl, los_usd=los, aufgebaut=now,
                  trend=rg["trend"], hinweis=None, halten=None)
        if art == "aufgebaut":
            gs["seit"] = now
        gs["zaehler"][art] = gs["zaehler"].get(art, 0) + 1
        bestand = sorted((i for i in range(n) if (L[i] > px if lang else L[i + 1] < px)), key=lambda i: L[i] if lang else -L[i + 1])
        einstieg = sorted((i for i in range(n) if not (L[i] > px if lang else L[i + 1] < px)), key=lambda i: -L[i] if lang else L[i + 1])
        gehalten = sum(p["notional"] for p in lose)
        k = min(len(bestand), max(0, int((len(bestand) * los - gehalten) / los + 1e-9))) if R["startbestand"] else 0
        teile = [f"Range {L[0]:.6g}–{L[-1]:.6g} ({(L[-1] / L[0] - 1) * 100:.2f} %, Trend {rg['trend']:.2f}, Kurse ab {_uhr(rg['von'])})",
                 f"{n} Stufen à {schritt * 100:.2f} %, {los:.0f} USD je Los", f"Notlinie {nl:.6g}"]
        if k and lang and not self._tor(now, "long", "grid_kauf", S["sid"], coin, px):     # 23.76 (U206): kein Startbestand
            k = 0
        if k:
            pr, bps = taker_preis(b, lang, k * los)
            for i in bestand[:k]:
                los_ = self._grid_los_auf(st, S, coin, gs, i, now, pr, bps, GEB_TAKER, "Startbestand (Taker)", -(-now // 60) * 60)
                if los_ is not None:
                    lose.append(los_)
            teile.append(f"Startbestand {k} Lose zu {pr:.6g}")
        if gehalten:
            teile.append(f"{len(lose) - k} Lose aus früheren Stufen behalten ihr Ziel")
        frei = GRID_KAPITAL - gehalten - k * los
        n_o = min(len(einstieg), max(0, int(frei / los + 1e-9)))
        if n_o and lang and not self._tor(now, "long", "limit_setzen", S["sid"], coin, px):  # 23.76 (U206): keine Kauf-Limits
            n_o = 0
        for i in einstieg[:n_o]:
            orders.append(self._grid_order(st, S, coin, gs, i, now))
        teile.append(f"{n_o} {'Kauf' if lang else 'Verkaufs'}-Limits")
        for p in lose:
            if p["sl"] != nl and p["tp"] is not None:
                p["sl"] = nl; p["_dirty"] = True
        self._ereignis(st, now, S["sid"], coin, "grid", R["richtung"], px, f"Grid {gen} {art}: " + " · ".join(teile))
        return 1 + k + n_o

    def _grid_alt_aufraeumen(self, con, st, coin, E, now) -> int:
        """Lose und Orders abgelöster Grid-Regelversionen (neue Kennung) schließen bzw. löschen -- sonst lägen sie ohne Führung offen."""
        b = E.get("preis")
        if not b or now - b["ts"] > KURS_FRISCH_S:
            return 0
        self._grid_alt_ok.add(coin)
        n = 0
        for (sid,) in st.execute("SELECT sid FROM labor_strategie WHERE aktiv=0 AND name IN (?, ?)", GRID_NAMEN).fetchall():
            if sid in self.grid_sids:
                continue
            st.execute("DELETE FROM labor_order WHERE status='offen' AND sid=? AND coin=?", (sid, coin))
            lose = self._grid_lose(st, sid, coin)
            if lose:
                n += len(lose)
                self._grid_alle_zu(con, st, coin, lose, b, now, None, "Markt (Taker)", "Regelversion abgelöst")
        return n

    # Tagesstand und Anzeige
    def _grid_tag(self, st, S, gs, coin, E, now, lose, geaendert) -> None:
        """Bestandswert für die Tagesbilanz (labor_grid_tag, ein Stand je Tag, der jeweils letzte): nach jeder Änderung und alle 5 min."""
        letzt = int(gs.get("_tag_ts") or 0)
        if not geaendert and now - letzt < GRID_TAG_S and now // 86_400 == letzt // 86_400:
            return
        b = E.get("preis") or {}
        mid = b.get("mid") if b and now - b.get("ts", 0) <= KURS_FRISCH_S else ((E.get("kerze") or [None] * 5)[4])
        wert = self._grid_wert(coin, lose, mid)
        if wert is None:
            return
        st.execute("INSERT OR REPLACE INTO labor_grid_tag VALUES (?,?,?,?,?,?,?)", (S["sid"], coin, now // 86_400 * 86_400, wert, len(lose), mid, now))
        gs["_tag_ts"] = now

    def _grid_status(self, S, gs, E, now, lose, orders) -> dict:
        R = S["regeln"]; lang = R["richtung"] == "long"; m = gs.get("modus"); H = gs.get("halten") or {}
        mid = (E.get("preis") or {}).get("mid")
        if m == "aktiv":
            txt = (f"{len(lose)}/{gs.get('n')} Lose · Range {gs['unten']:.6g}–{gs['oben']:.6g} · Schritt {gs['schritt'] * 100:.2f} % · "
                   f"Notlinie {gs['notlinie']:.6g}")
        elif m == "halten":
            txt = f"hält {len(lose)} Lose · {'Hoch' if lang else 'Tief'} {H.get('extrem', 0):.6g} · Trailing-Stop {H.get('stop', 0):.6g}"
        elif m == "pause":
            txt = f"Pause bis {_uhr(gs.get('pause_bis'))}"
        else:
            txt = "wartet: " + (gs.get("hinweis") or "prüft die Range")
        return {"ts": now, "text": txt, "signal": None, "blockiert": None, "orders": len(orders),
                "grid": {"modus": m, "richtung": R["richtung"], "lose": len(lose), "n": gs.get("n"), "gen": gs.get("gen"), "unten": gs.get("unten"),
                         "oben": gs.get("oben"), "notlinie": gs.get("notlinie"), "schritt": gs.get("schritt"),
                         "bestand_usd": self._grid_wert(E.get("coin"), lose, mid), "einsatz_usd": sum(p["notional"] for p in lose),
                         "stop": H.get("stop"), "extrem": H.get("extrem"), "pause_bis": gs.get("pause_bis"), "hinweis": gs.get("hinweis"),
                         "seit": gs.get("seit"), "zaehler": dict(gs.get("zaehler") or {})}}


# ------------------------------------------------------------------------------------------------ Auswertung
def _betacf(a: float, b: float, x: float) -> float:
    """Kettenbruch der unvollständigen Betafunktion (Numerical Recipes 6.4)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300); h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        de = d * c; h *= de
        if abs(de - 1.0) < 1e-12:
            break
    return h


def p_t_einseitig(t: float, df: int) -> float:
    """P(T >= t) der Student-t-Verteilung mit df Freiheitsgraden -- bei wenigen Trades deutlich vorsichtiger als die Normalverteilung."""
    if df <= 0:
        return 1.0
    x = df / (df + t * t)
    a, b = df / 2.0, 0.5
    if x >= 1.0:
        zwei = 1.0                                    # t = 0
    elif x <= 0.0:
        zwei = 0.0
    else:
        lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
        front = math.exp(lbeta + a * math.log(x) + b * math.log(1 - x))
        ib = front * _betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - front * _betacf(b, a, 1 - x) / b
        zwei = min(1.0, max(0.0, ib))                 # P(|T| >= |t|) = I_x(df/2, 1/2)
    return zwei / 2 if t >= 0 else 1 - zwei / 2


def bloecke(tr: list, block_s: int) -> list:
    """
    23.34: Mittel der Netto-Rendite je Block -- Trades, die im selben Block der Länge block_s (Horizont der Strategie) eröffnet
    wurden, sind EINE Beobachtung (meist dasselbe Signal in mehreren korrelierten Coins zugleich). Reihenfolge = Zeit.
    """
    b: dict = {}
    for t in tr:
        b.setdefault(int(t["eroeffnet"]) // max(int(block_s), 60), []).append(t["netto_pct"])
    return [sum(v) / len(v) for _, v in sorted(b.items())]


def coin_starts(st, coins=COINS, now: int | None = None, schreiben: bool = False) -> dict:
    """
    {Coin: Start des simulierten Kontos} (labor_zustand „coins“). 23.34: Jeder Coin zählt ab seinem eigenen Start -- XMR kam später
    dazu. Beim ersten Schreiben nach dem Update übernehmen die Coins von 23.33 den gemeinsamen Start, neue Coins beginnen jetzt.
    """
    try:
        r = st.execute("SELECT v FROM labor_zustand WHERE k='coins'").fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except (sqlite3.Error, ValueError):
        d = {}
    d = {str(k): int(v) for k, v in (d.items() if isinstance(d, dict) else []) if v}
    if not schreiben:
        return d
    now = int(now or time.time()); neu = dict(d)
    if not d:
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        alt = int(r0[0]) if r0 and r0[0] else now
        for c in coins:
            neu[c] = alt if c in COINS_2333 else now
    for c in coins:
        neu.setdefault(c, now)
    if neu != d:
        st.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('coins', ?)", (_j(neu),))
    return neu


def konten_tage(erstellt: int, ende: int, starts: dict, coins) -> float:
    """Summe der Tage, die die Konten einer Strategie gelaufen sind: je Coin ab max(Strategie erstellt, Coin-Start) bis ende."""
    return sum(max(0, int(ende) - max(int(erstellt or 0), int(starts.get(c) or erstellt or 0))) for c in coins) / 86_400


def _stat(tr: list, erstellt: int, now: int, kt: float | None = None, notional: float = NOTIONAL, block_s: int | None = None,
          bloecke_werte: list | None = None, summe_extra: float = 0.0) -> dict:
    """
    Kennzahlen einer Strategie (oder eines Coins). Konto = je Coin ein simuliertes Konto über `notional` USD; die Tagesrendite teilt
    die Summe durch die Kontotage kt (23.34: je Coin ab seinem Start; ohne Angabe Laufzeit × Coins) -- auch Tage ohne Trade zählen.
    23.34: t, Zufalls-/Glückswahrscheinlichkeit, Hälften und Stufen auf BLÖCKEN (block_s = Horizont): gleichzeitige Trades der Strategie
    zählen einmal (n_eff). Ø netto, Treffer, Kelly und die Hebel-Ansicht bleiben je Trade.
    23.40 (Grid): bloecke_werte ersetzt die Blöcke (Tagesergebnis nach Bestandswert in % des Kapitals), summe_extra = unrealisierter
    Bestandswert, zählt in Summe, Ø/Tag, Stufe und Hebel-Summe mit. Trades mit eigenem Notional (Grid-Lose): Liquidation kostet ihre
    Marge, der Kontofaktor wächst mit ihrem Anteil am Konto. Für Trades über `notional` (alle übrigen) unverändert.
    """
    n = len(tr)
    out = {"n": n, "n_eff": 0, "treffer": None, "mittel_pct": None, "t": None,
           "summe_usd": round(sum(t["netto_usd"] for t in tr) + summe_extra, 2),
           "realisiert_usd": round(sum(t["netto_usd"] for t in tr), 2), "bestand_usd": round(summe_extra, 2),
           "gebuehren_usd": round(sum(t["gebuehren"] for t in tr), 2), "funding_usd": round(sum(t["funding"] for t in tr), 2),
           "pf": None, "max_dd_usd": 0.0, "trades_tag": None, "letzter": max((t["geschlossen"] for t in tr), default=None),
           "haelften": None, "kelly": None, "hebel": [], "stufe": "Kandidat", "slip_bps": None, "p_zufall": None, "tag_pct": None}
    tage = max((now - erstellt) / 86_400, 1 / 24) if erstellt else None
    if kt is None and tage:
        kt = tage * len(COINS)
    kt = max(kt, 1 / 24) if kt else None
    if tage:
        out["tage"] = round(tage, 2); out["trades_tag"] = round(n / tage, 2)
    if kt:
        out["konten_tage"] = round(kt, 2)
        out["tag_pct"] = out["summe_usd"] / kt / notional * 100
    if not n:
        return out
    r = [t["netto_pct"] for t in tr]; m = sum(r) / n
    out["treffer"] = sum(1 for x in r if x > 0) / n; out["mittel_pct"] = m
    sd = math.sqrt(sum((x - m) ** 2 for x in r) / (n - 1)) if n > 1 else None
    if sd and sd > 0 and n >= 3 and m > 0:
        out["kelly"] = min(50.0, (m / 100) / (sd / 100) ** 2)
    bw = list(bloecke_werte) if bloecke_werte is not None else (bloecke(tr, block_s) if block_s else r)
    ne = len(bw); out["n_eff"] = ne
    if ne >= 3:
        mb = sum(bw) / ne; sdb = math.sqrt(sum((x - mb) ** 2 for x in bw) / (ne - 1))
        if sdb > 0:
            out["t"] = mb / (sdb / math.sqrt(ne))
            out["p_zufall"] = p_t_einseitig(out["t"], ne - 1)            # einseitig: so gut oder besser rein zufällig (Student-t, n_eff − 1)
    gew = sum(t["netto_usd"] for t in tr if t["netto_usd"] > 0); verl = -sum(t["netto_usd"] for t in tr if t["netto_usd"] < 0)
    out["pf"] = (gew / verl) if verl > 0 else None
    cum = peak = dd = 0.0
    for t in tr:
        cum += t["netto_usd"]; peak = max(peak, cum); dd = max(dd, peak - cum)
    out["max_dd_usd"] = round(dd, 2)
    sl = [t["slip"] for t in tr if t["slip"] is not None]
    out["slip_bps"] = (sum(sl) / len(sl)) if sl else None
    if ne >= 6:
        h = ne // 2; a = bw[:h]; b = bw[h:]
        out["haelften"] = [sum(a) / len(a), sum(b) / len(b)]
    for L in HEBEL:
        e, pk, mdd, aus = 1.0, 1.0, 0.0, None
        for i, t in enumerate(tr):
            if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE:
                e = 0.0; aus = i + 1; mdd = 1.0; break
            e *= max(0.0, 1 + L * t["netto_pct"] / 100 * (t.get("notional") or notional) / notional); pk = max(pk, e)
            mdd = max(mdd, 1 - e / pk if pk > 0 else 1.0)
            if e <= 0:
                aus = i + 1; break
        # gleiche Marge, L-facher Einsatz: Rendite, Gebühren und Funding wachsen mit L; ein liquidierter Trade kostet die ganze Marge
        summe_L = sum(-(t.get("notional") or notional) if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE else L * t["netto_usd"] for t in tr) + L * summe_extra
        out["hebel"].append({"L": L, "faktor": round(e, 4), "max_dd": round(mdd, 4), "ausgeloescht": aus, "summe_usd": round(summe_L, 2),
                             "tag_pct": round(summe_L / kt / notional * 100, 4) if kt else None,
                             "liquidiert": sum(1 for t in tr if t["mae_pct"] / 100 * L >= LIQ_SCHWELLE),
                             "schlechtester_pct": round(-100.0 if any(t["mae_pct"] / 100 * L >= LIQ_SCHWELLE for t in tr) else L * min(r), 3)})
    span = (max(t["geschlossen"] for t in tr) - min(t["eroeffnet"] for t in tr)) / 86_400
    if ne >= 30 and (out["t"] or 0) >= 3 and span >= 14 and out["haelften"] and min(out["haelften"]) > 0:
        out["stufe"] = "bewährt"
    elif ne >= 15 and (out["t"] or 0) >= 2 and out["summe_usd"] > 0:
        out["stufe"] = "Bewährung"
    elif ne >= 30 and (out["t"] or 0) <= -2:
        out["stufe"] = "negativ"
    return out


def kennzahlen(st, now: int) -> list:
    schema(st)
    strat = {r[0]: {"sid": r[0], "name": r[1], "titel": r[2], "gruppe": r[3], "regeln": json.loads(r[4] or "{}"), "beschreibung": r[5],
                    "erstellt": r[6], "aktiv": r[7]}
             for r in st.execute("SELECT sid, name, titel, gruppe, regeln, beschreibung, erstellt, aktiv FROM labor_strategie")}
    tr: dict = {}
    for r in st.execute("SELECT sid, coin, eroeffnet, geschlossen, netto_usd, netto_pct, mae_pct, gebuehr_ein + gebuehr_aus, funding, "
                        "slip_ein, slip_aus, notional FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
        tr.setdefault(r[0], []).append({"coin": r[1], "eroeffnet": r[2], "geschlossen": r[3], "netto_usd": r[4] or 0.0, "netto_pct": r[5] or 0.0,
                                        "mae_pct": r[6] or 0.0, "gebuehren": r[7] or 0.0, "funding": r[8] or 0.0,
                                        "slip": ((r[9] or 0.0) + (r[10] or 0.0)) if r[9] is not None else None, "notional": r[11] or NOTIONAL})
    offen: dict = {}; n_offen: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_position WHERE status='offen'"):
        offen.setdefault(sid, set()).add(coin); n_offen[sid] = n_offen.get(sid, 0) + 1
    orders: dict = {}; n_orders: dict = {}
    for sid, coin in st.execute("SELECT sid, coin FROM labor_order WHERE status='offen'"):
        orders.setdefault(sid, set()).add(coin); n_orders[sid] = n_orders.get(sid, 0) + 1
    starts = coin_starts(st)                         # die Coins, auf denen das Labor läuft, je mit ihrem Start
    if not starts:                                   # vor dem ersten Takt nach dem Update: 23.33-Coins ab dem Laborstart, neue ab jetzt
        r0 = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone()
        starts = {c: (int(r0[0]) if (r0 and r0[0] and c in COINS_2333) else now) for c in COINS}
    out = []
    for sid, s in strat.items():
        if s["name"] in AKKU_NAMEN:                 # 23.69 (U180): keine Trades, eigene Bilanz (akku_daten, Reiter „Akkumulation“)
            continue
        if not s["aktiv"] and sid not in tr:
            continue
        t_ = tr.get(sid, [])
        # Ende der Laufzeit: aktive Strategien jetzt; alte Regelversionen mit ihrem letzten Trade (oder offener Position)
        ende = now if (s["aktiv"] or sid in offen) else max([x["geschlossen"] for x in t_] or [s["erstellt"]])
        block_s = int(float(s["regeln"].get("h", 4)) * 3600)
        coins_s = sorted(set(starts) | {x["coin"] for x in t_})
        gt = grid_tage(st, sid) if s["name"] in GRID_NAMEN else None
        if gt is None:
            k = dict(s, **_stat(t_, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, coins_s), block_s=block_s))
        else:
            # 23.40 Grid: Blöcke = Tage, Wert = Tagesergebnis nach Bestandswert in % des Kapitals aller Coin-Konten; Summe inkl. Bestand
            kap = GRID_KAPITAL * max(1, len(coins_s))
            k = dict(s, **_stat(t_, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, coins_s), block_s=86_400,
                                bloecke_werte=[usd / kap * 100 for _, usd in gt["tage"]], summe_extra=sum(gt["bestand"].values())))
            cum = peak = dd = 0.0
            for _, usd in gt["tage"]:
                cum += usd; peak = max(peak, cum); dd = max(dd, peak - cum)
            k["max_dd_usd"] = round(dd, 2); block_s = 86_400
            k["grid"] = {"tage": [[tag, round(usd, 2)] for tag, usd in gt["tage"][-90:]], "lose": n_offen.get(sid, 0), "orders": n_orders.get(sid, 0)}
        k.update(offen=sorted(offen.get(sid, ())), orders=sorted(orders.get(sid, ())), block_h=block_s / 3600)
        k["je_coin"] = {}
        for c in sorted({x["coin"] for x in t_} | (set(gt["je_coin"]) if gt else set())):
            tc = [x for x in t_ if x["coin"] == c]
            if gt is None:
                sc = _stat(tc, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, [c]), block_s=block_s)
            else:
                sc = _stat(tc, s["erstellt"], ende, konten_tage(s["erstellt"], ende, starts, [c]), block_s=86_400,
                           bloecke_werte=[usd / GRID_KAPITAL * 100 for _, usd in gt["je_coin"].get(c, [])], summe_extra=gt["bestand"].get(c, 0.0))
            k["je_coin"][c] = {f: sc[f] for f in ("n", "n_eff", "treffer", "mittel_pct", "t", "summe_usd", "tag_pct", "max_dd_usd", "bestand_usd",
                                                  "gebuehren_usd", "slip_bps")}                    # 23.68 (U161): Gebühren, Abstand je Coin
            k["je_coin"][c]["hebel"] = {str(h["L"]): {"summe_usd": h["summe_usd"], "tag_pct": h["tag_pct"], "liquidiert": h["liquidiert"]} for h in sc["hebel"]}
        out.append(k)
    n_aktiv = max(1, sum(1 for k in out if k["aktiv"]))
    for k in out:                                  # viele Strategien zugleich: die beste sieht auch zufällig gut aus
        k["p_glueck"] = min(1.0, k["p_zufall"] * n_aktiv) if k.get("p_zufall") is not None else None
    out.sort(key=lambda k: (-(k["summe_usd"] or 0)))
    return out


def uebersicht(store: str, preise: dict, now: int | None = None) -> dict:
    now = int(now or time.time()); st = F.store_connect(store); schema(st)
    try:
        K = kennzahlen(st, now)
        titel = {k["sid"]: k["titel"] for k in K}
        r = st.execute("SELECT v FROM labor_zustand WHERE k='start'").fetchone(); start = int(r[0]) if r else None
        seit = coin_starts(st)
        for c in COINS:
            seit.setdefault(c, start if (start and c in COINS_2333) else now)
        offen = []
        for p in st.execute("SELECT id, sid, coin, seite, eroeffnet, preis_ein, notional, menge, gebuehr_ein, sl, tp, ablauf, grund, funding, "
                            "mae_pct, mfe_pct, art_ein FROM labor_position WHERE status='offen' ORDER BY eroeffnet DESC"):
            mid = (preise.get(p[2]) or {}).get("mid")
            kauf = p[3] == "long"; unreal = None
            if mid:
                geb_aus = p[7] * mid * gebuehr(p[2], GEB_TAKER)
                unreal = (mid - p[5]) * p[7] * (1 if kauf else -1) - p[8] - geb_aus - (p[13] or 0.0)
            offen.append({"id": p[0], "sid": p[1], "titel": titel.get(p[1], p[1]), "coin": p[2], "seite": p[3], "eroeffnet": p[4], "preis_ein": p[5],
                          "notional": p[6], "sl": p[9], "tp": p[10], "ablauf": p[11], "grund": p[12], "funding": p[13], "mae_pct": p[14],
                          "mfe_pct": p[15], "art": p[16], "jetzt": mid, "netto_usd": unreal, "netto_pct": (unreal / p[6] * 100) if unreal is not None else None,
                          "grid": str(p[1]).startswith("grid_")})
        orders = [{"id": o[0], "sid": o[1], "titel": titel.get(o[1], o[1]), "coin": o[2], "seite": o[3], "preis": o[4], "erstellt": o[5],
                   "gueltig_bis": o[6], "grund": o[7], "jetzt": (preise.get(o[2]) or {}).get("mid"), "grid": str(o[1]).startswith("grid_")}
                  for o in st.execute("SELECT id, sid, coin, seite, preis, erstellt, gueltig_bis, grund FROM labor_order WHERE status='offen' ORDER BY erstellt DESC")]
        grids = grid_zustand(st)
        # 23.40: die einzelnen Grid-Lose (art „grid_los“, Hunderte am Tag) getrennt -- sonst verdrängten sie alle übrigen Ereignisse
        ev_q = ("SELECT id, ts, sid, coin, art, seite, preis, text, netto_usd, pos_id FROM labor_ereignis WHERE art {} 'grid_los' "
                "ORDER BY ts DESC, id DESC LIMIT {}")
        ev_f = lambda e: {"id": e[0], "ts": e[1], "sid": e[2], "titel": titel.get(e[2], "Labor") if e[2] else "Erkennung", "coin": e[3], "art": e[4],
                          "seite": e[5], "preis": e[6], "text": e[7], "netto_usd": e[8], "pos_id": e[9]}
        ereig = [ev_f(e) for e in st.execute(ev_q.format("<>", 150))]
        ereig_grid = [ev_f(e) for e in st.execute(ev_q.format("=", 100))]
        tag = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE status='geschlossen' AND geschlossen>=?",
                         (now - 86_400,)).fetchone()
        wechsel = geb_wechsel(st)                                                   # 23.68 (U160)
        ges = st.execute("SELECT COUNT(*), COALESCE(SUM(netto_usd), 0), COALESCE(SUM(gebuehr_ein + gebuehr_aus), 0) FROM labor_position "
                         "WHERE status='geschlossen'").fetchone()
        # 23.69 (U180): Akkumulation -- Titel für die Ereignisse und eine Kurzbilanz je Strategie für die Kopfzeile (Wert zur Mitte jetzt)
        ak_s = st.execute(f"SELECT sid, titel, aktiv FROM labor_strategie WHERE name IN ({','.join('?' * len(AKKU_NAMEN))}) ORDER BY erstellt, name",
                          AKKU_NAMEN).fetchall()
        ak_k = st.execute("SELECT sid, coin, COUNT(*), SUM(usd), SUM(menge), MAX(ts) FROM labor_akku_kauf GROUP BY sid, coin").fetchall()
    finally:
        st.close()
    akku = []
    for sid_, t_, akt_ in ak_s:
        titel.setdefault(sid_, t_)
        zl = [r for r in ak_k if r[0] == sid_]
        if not akt_ and not zl:
            continue
        ohne = [r[1] for r in zl if not (preise.get(r[1]) or {}).get("mid")]
        ein = sum(r[3] for r in zl); wert = None if ohne else sum(r[4] * preise[r[1]]["mid"] for r in zl)
        akku.append({"sid": sid_, "titel": t_, "aktiv": bool(akt_), "n": sum(r[2] for r in zl), "eingesetzt": ein, "wert": wert, "ohne_kurs": ohne,
                     "gewinn_pct": ((wert / ein - 1) * 100) if (ein and wert is not None) else None, "letzter": max((r[5] for r in zl), default=None)})
    alt_ak = {sid_ for sid_, _t, akt_ in ak_s if not akt_}
    for e in ereig:
        if e["art"] == "akku":
            e["titel"] = titel.get(e["sid"], e["titel"]) + (" (alte Regeln)" if e["sid"] in alt_ak else "")   # 23.72 (U186)
            e["text"] = akku_grund_text(e["text"])                         # 23.71 (U185)
    aktiv = [k for k in K if k["aktiv"]]
    mit = [k for k in aktiv if k["n"] >= 5]
    return {"ts": now, "start": start, "notional": NOTIONAL, "coins": list(COINS), "coins_seit": seit, "geb_faktor": GEB_FAKTOR,
            "geb_wechsel": wechsel, "geb_wechsel_text": geb_wechsel_text(wechsel), "grid_kapital": GRID_KAPITAL,
            "strategien": K, "offen": offen, "orders": orders, "grids": grids, "ereignisse_grid": ereig_grid, "akku": akku,
            "ereignisse": ereig, "gesamt": {"strategien": len(aktiv), "konten": len(aktiv) * len(COINS),
                                            "offen": sum(1 for o in offen if not o["grid"]), "orders": sum(1 for o in orders if not o["grid"]),
                                            "grid_lose": sum(1 for o in offen if o["grid"]), "grid_orders": sum(1 for o in orders if o["grid"]),
                                            "grid_bestand_usd": round(sum(o["netto_usd"] or 0 for o in offen if o["grid"]), 2),
                                            "trades": ges[0], "netto_usd": round(ges[1], 2), "gebuehren_usd": round(ges[2], 2),
                                            "trades_24h": tag[0], "netto_24h": round(tag[1], 2),
                                            "offen_usd": round(sum(o["netto_usd"] or 0 for o in offen), 2),
                                            "beste": max(mit, key=lambda k: k["summe_usd"])["titel"] if mit else None,
                                            "stufen": {s: sum(1 for k in aktiv if k["stufe"] == s) for s in ("Kandidat", "Bewährung", "bewährt", "negativ")}}}


def trades(store: str, sid: str | None = None, coin: str | None = None, n: int = 150) -> list:
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.coin, p.seite, p.eroeffnet, p.geschlossen, p.preis_ein, p.preis_aus, p.art_ein, p.art_aus, "
             "p.gebuehr_ein + p.gebuehr_aus, p.slip_ein, p.slip_aus, p.funding, p.grund, p.grund_aus, p.netto_usd, p.netto_pct, p.mae_pct, p.mfe_pct, p.notional "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.status='geschlossen'")
        par = []
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        if coin:
            q += " AND p.coin=?"; par.append(coin)
        q += " ORDER BY p.geschlossen DESC LIMIT ?"; par.append(int(n))
        spalten = ("id", "sid", "titel", "coin", "seite", "eroeffnet", "geschlossen", "preis_ein", "preis_aus", "art_ein", "art_aus", "gebuehren",
                   "slip_ein", "slip_aus", "funding", "grund", "grund_aus", "netto_usd", "netto_pct", "mae_pct", "mfe_pct", "notional")
        return [dict(zip(spalten, r)) for r in st.execute(q, par)]
    finally:
        st.close()


def trades_antwort(store: str, sid: str | None = None, coin: str | None = None, n: int = 150) -> dict:
    """/labor/trades: geschlossene Trades (mit Größe je Trade bzw. Los); 23.68 (U163) bei einer Grid-Strategie dazu die Tabelle „je Coin
    und Tag“ (grid_tage_tabelle) -- dieselben Zahlen, aus denen Stufe und t des Grids rechnen."""
    d = {"trades": trades(store, sid, coin, n), "grid_kapital": GRID_KAPITAL}
    if sid and str(sid).startswith("grid_"):
        st = F.store_connect(store); schema(st)
        try:
            d["grid_tage"] = grid_tage_tabelle(st, sid, coin)
        finally:
            st.close()
    return d


def chart(db: str, store: str, coin: str, sid: str | None = None, stunden: int = 24, now: int | None = None) -> dict:
    now = int(now or time.time()); t0 = now - stunden * 3600
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
    try:
        kurs = [(int(t), float(c)) for t, c in con.execute("SELECT ts, close FROM bars WHERE ts>=? AND ts<=? AND coin=? AND ts % 300 = 240 ORDER BY ts",
                                                           (t0, now, coin)) if c]
    except sqlite3.Error:
        kurs = []
    finally:
        con.close()
    st = F.store_connect(store); schema(st)
    try:
        q = ("SELECT p.id, p.sid, s.titel, p.seite, p.status, p.eroeffnet, p.preis_ein, p.geschlossen, p.preis_aus, p.netto_usd, p.sl, p.tp "
             "FROM labor_position p LEFT JOIN labor_strategie s ON s.sid = p.sid WHERE p.coin=? AND (p.eroeffnet>=? OR p.status='offen' OR p.geschlossen>=?)")
        par = [coin, t0, t0]
        if sid:
            q += " AND p.sid=?"; par.append(sid)
        else:                                       # 23.40: die vielen Grid-Lose nur, wenn das Grid oben gewählt ist
            q += " AND p.sid NOT LIKE 'grid\\_%' ESCAPE '\\'"
        marken = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "status": r[4], "ein_t": r[5], "ein_px": r[6], "aus_t": r[7], "aus_px": r[8],
                   "netto_usd": r[9], "sl": r[10], "tp": r[11]} for r in st.execute(q + " ORDER BY p.eroeffnet", par)]
        q2 = "SELECT o.id, o.sid, s.titel, o.seite, o.preis, o.erstellt, o.gueltig_bis FROM labor_order o LEFT JOIN labor_strategie s ON s.sid = o.sid WHERE o.coin=? AND o.status='offen'"
        par2 = [coin] + ([sid] if sid else [])
        limits = [{"id": r[0], "sid": r[1], "titel": r[2], "seite": r[3], "preis": r[4], "erstellt": r[5], "gueltig_bis": r[6]}
                  for r in st.execute(q2 + (" AND o.sid=?" if sid else " AND o.sid NOT LIKE 'grid\\_%' ESCAPE '\\'"), par2)]
        grid = grid_zustand(st).get(f"{sid}|{coin}") if sid and str(sid).startswith("grid_") else None
    finally:
        st.close()
    return {"coin": coin, "von": t0, "bis": now, "kurs": kurs, "marken": marken, "limits": limits, "grid": grid}


def equity(store: str, now: int | None = None) -> dict:
    now = int(now or time.time())
    st = F.store_connect(store); schema(st)
    try:
        titel = {r[0]: (r[1], r[2]) for r in st.execute("SELECT sid, titel, gruppe FROM labor_strategie")}
        reihen: dict = {}
        for sid, t, netto in st.execute("SELECT sid, geschlossen, netto_usd FROM labor_position WHERE status='geschlossen' ORDER BY geschlossen"):
            if str(sid).startswith("grid_"):
                continue
            r = reihen.setdefault(sid, {"sid": sid, "titel": titel.get(sid, (sid, ""))[0], "gruppe": titel.get(sid, ("", ""))[1], "punkte": [], "summe": 0.0})
            r["summe"] += netto or 0.0; r["punkte"].append([int(t), round(r["summe"], 2)])
        # 23.40 Grid: Tagespunkte nach Bestandswert (realisiert + unrealisiert) -- sonst stiege die Linie mit jedem kleinen Verkauf, während
        # der Bestand verliert
        for (sid,) in st.execute("SELECT sid FROM labor_strategie WHERE name IN (?, ?)", GRID_NAMEN).fetchall():
            gt = grid_tage(st, sid)
            if not gt["tage"]:
                continue
            r = reihen.setdefault(sid, {"sid": sid, "titel": titel.get(sid, (sid, ""))[0], "gruppe": titel.get(sid, ("", ""))[1], "punkte": [],
                                        "summe": 0.0, "grid": True})
            for tag, usd in gt["tage"]:
                r["summe"] += usd; r["punkte"].append([min(int(tag) + 86_400, now), round(r["summe"], 2)])
    finally:
        st.close()
    return {"ts": now, "reihen": sorted(reihen.values(), key=lambda r: -r["summe"])}


def _fmt_usd(x) -> str:
    if x is None:
        return "—"
    a = abs(x)
    return (f"{x / 1e6:+.2f} Mio" if a >= 1e6 else f"{x / 1e3:+.1f}k" if a >= 1e4 else f"{x:+.0f}")


def datenfluss(E: dict, strat: list, now: int) -> list:
    """Alle Eingangsdaten eines Coins als Zeilen für den Abschnitt „Datenfluss“ (Wert, Alter, Status, genutzt von)."""
    if not E:
        return []
    nutzer: dict = {}
    for s in strat:
        for k in s["eingaben"]:
            nutzer.setdefault(k, []).append(s["titel"])
    zeilen = []

    def z(gruppe, name, wert, ts, key=None, frisch=None, hinweis=None):
        alter = (now - ts) if ts else None
        status = "fehlt" if wert in (None, "—") else ("alt" if (frisch and alter is not None and alter > frisch) else "frisch")
        zeilen.append({"gruppe": gruppe, "name": name, "wert": wert if wert is not None else "—", "alter": alter, "status": status,
                       "nutzer": nutzer.get(key, []) if key else [], "hinweis": hinweis})
    b = E.get("preis") or {}
    z("Kurs & Buch", "Kurs (Mitte)", f"{b['mid']:.6g}" if b else None, b.get("ts"), None, FRISCH_S["preis"], b.get("quelle"))
    z("Kurs & Buch", "Spread", f"{b['spread_bps']:.2f} bps" if b else None, b.get("ts"), None, FRISCH_S["preis"])
    z("Kurs & Buch", "Tiefe ±10 bps", _fmt_usd(b.get("tiefe10")).lstrip("+") if b.get("tiefe10") else None, b.get("ts"), None, FRISCH_S["preis"],
      "bestimmt die Marktauswirkung jeder simulierten Markt-Order")
    z("Schwankung", "σ 4 h", f"{E['sigma4h'] * 100:.2f} %" + ("" if E.get("sigma_ok") else " (Ersatzwert)"), now, None, None,
      "aus 15-min-Renditen der letzten 7 Tage; Grundlage aller Stops und Ziele")
    z("Schwankung", "σ 1 h / 15 min", f"{E['sigma1h'] * 100:.2f} % / {E['sigma15'] * 100:.2f} %", now)
    z("Schwankung", "Stundenvolumen (Median 24 h)", _fmt_usd(E.get("vol1h")).lstrip("+") if E.get("vol1h") else None, now)
    P = E.get("prognose")
    if P:
        z("Prognose", "Bias", f"{P['bias']:+.2f}" if P.get("bias") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v1", f"{P['p_up_v1'] * 100:.1f} %" if P.get("p_up_v1") is not None else None, P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "P(aufwärts 4 h) v2", f"{float(P['p_up_v2']) * 100:.1f} % (Version {P.get('v2_version') or 1})" if P.get("p_up_v2") is not None else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
        z("Prognose", "Kauf- / Verkaufspreis", f"{P['buy_px']:.6g} / {P['sell_px']:.6g}" if P.get("buy_px") and P.get("sell_px") else None,
          P["ts"], "prognose", FRISCH_S["prognose"])
    else:
        z("Prognose", "Prognose", None, None, "prognose")
    for n_, (v, t) in sorted((E.get("treiber") or {}).items()):
        z("Treiber", n_, f"{v:+.2f}", t, f"treiber:{n_}", FRISCH_S["treiber"])
    for f, v in (E.get("familien") or {}).items():
        z("Familien", f, (f"{v[0]:+.2f} ({v[2]} Treiber)" if f != "Profi-Flow" else f"{v[0]:+.2f}") if v else None, v[1] if v else None,
          f"familie:{f}", FRISCH_S["familie"])
    S_ = E.get("staerke") or {}
    z("Familien", "Stärke (große Bewegung?)", f"{S_['wert']:.2f}" + (f", Ruhe {S_['ruhe']:.2f}" if S_.get("ruhe") is not None else "")
      if S_.get("wert") is not None else None, now, "staerke")
    K = E.get("kaskade") or {}
    liq = K.get("liq") or {}
    z("Ereignisse", "Kursbewegung 15 min", f"{K['z']:+.2f} σ" if K.get("z") is not None else None, now, "kaskade", None,
      f"Kaskade ab ±{KASKADE_Z:g} σ zusammen mit Liquidationen über der Schwelle")
    z("Ereignisse", "Liquidationen 15 min (Long / Short)", f"{_fmt_usd(liq.get('long')).lstrip('+')} / {_fmt_usd(liq.get('short')).lstrip('+')}" if liq else None,
      now, "kaskade", None, (f"Schwellen {_fmt_usd((K.get('schwelle') or {}).get('long')).lstrip('+')} / {_fmt_usd((K.get('schwelle') or {}).get('short')).lstrip('+')} · "
                            f"Hyperliquid {_fmt_usd(liq.get('hl')).lstrip('+')}, Binance {_fmt_usd(liq.get('binance')).lstrip('+')}, andere {_fmt_usd(liq.get('andere')).lstrip('+')}")
      if liq else None)
    z("Ereignisse", "Kaskaden-Status", ("AKTIV: " + ("abwärts" if K.get("richtung") == "ab" else "aufwärts") + f" seit {_uhr(K.get('t'))}, Extrem {K.get('extrem', 0):.6g}")
      if K.get("aktiv") else "ruhig", now, "kaskade")
    A = E.get("anker") or {}
    if A.get("fehler"):
        z("Heatmap", "Anker", None, None, "anker", None, A["fehler"])
    else:
        dom = (A.get("oben") if (A.get("A") or 0) > 0 else A.get("unten")) if A.get("A") is not None else None
        z("Heatmap", "Anker A", (f"{A['A']:+.2f}" + (f" · Cluster {dom['px']:.6g}, {dom['abstand_sigma']:.1f} σ, {dom['anteil_volumen'] * 100:.0f} % Vol." if dom else ""))
          if A.get("A") is not None else "kein Anker", A.get("ts"), "anker", FRISCH_S["anker"],
          "Beleg: " + ("ja" if (A.get("bilanz") or {}).get("belegt") else "nein"))
    D = E.get("docht") or {}
    for key, name in (("unten", "Docht-Ziel unten (Long-Cluster)"), ("oben", "Docht-Ziel oben (Short-Cluster)")):
        c = D.get(key)
        z("Heatmap", name, f"{c['px']:.6g} · {_fmt_usd(c['usd']).lstrip('+')} · {c['anteil'] * 100:.0f} % Vol. · {c['sigma']:.1f} σ" if c else "keins",
          D.get("ts"), "docht", FRISCH_S["docht"])
    f = E.get("funding")
    z("Funding", "Funding-Rate", (f"{f['rate'] * 100:.4f} %/h" + (f", z {f['z']:+.1f}" if f.get("z") is not None else ", Statistik im Aufbau")) if f else None,
      f["ts"] if f else None, "funding", FRISCH_S["funding"])
    Dw = E.get("darwin") or {}
    z("Händler", "Darwin-Liste (Konten)", f"{len(Dw.get('konten') or [])}" if Dw.get("konten") is not None else None, now, "darwin")
    log = Dw.get("log") or []
    z("Händler", "Darwin: letzte Ein-/Ausstiege (6 h)", ", ".join(f"{_uhr(e['ts'])[7:]} #{e.get('rang')} {'eröffnet' if e['art'] == 'auf' else 'schließt'} {e['seite']} "
                                                                f"{_fmt_usd(e['usd']).lstrip('+')}" for e in reversed(log)) if log else "keine",
      log[-1]["ts"] if log else now, "darwin")
    su = Dw.get("summen") or {}
    z("Händler", f"Darwin: Eröffnungen der letzten {DARWIN_FENSTER_S // 60} min", ", ".join(
        f"{k.split('|')[0][:6]}…{k.split('|')[0][-4:]} {k.split('|')[2]} {_fmt_usd(v).lstrip('+')}" for k, v in sorted(su.items(), key=lambda kv: -kv[1])[:4])
      if su else "keine", now, "darwin", None, f"Summe je Konto und Seite seit dem letzten Schließen, auch in kleinen Stücken; Einstieg ab "
                                               f"{DARWIN_MIN_USD / 1e3:.0f}k (23.34)")
    El = E.get("elite") or {}                                                      # 23.39: die Elite des Coins als zweite Vorlage
    z("Händler", "Elite des Coins (Konten)", f"{len(El.get('konten') or [])}" if El.get("konten") is not None else None, now, "elite", None,
      "vom Dashboard täglich aufgestellt (Konto-Score mit Beleg, Gewinn- und Aktivitätsschranke), ohne Gesperrte")
    log_e = El.get("log") or []
    z("Händler", "Elite: letzte Ein-/Ausstiege (6 h)", ", ".join(f"{_uhr(e['ts'])[7:]} #{e.get('rang')} {'eröffnet' if e['art'] == 'auf' else 'schließt'} {e['seite']} "
                                                                f"{_fmt_usd(e['usd']).lstrip('+')}" for e in reversed(log_e)) if log_e else "keine",
      log_e[-1]["ts"] if log_e else now, "elite")
    su_e = El.get("summen") or {}
    z("Händler", f"Elite: Eröffnungen der letzten {DARWIN_FENSTER_S // 60} min", ", ".join(
        f"{k.split('|')[0][:6]}…{k.split('|')[0][-4:]} {k.split('|')[2]} {_fmt_usd(v).lstrip('+')}" for k, v in sorted(su_e.items(), key=lambda kv: -kv[1])[:4])
      if su_e else "keine", now, "elite", None, f"Summe je Konto und Seite seit dem letzten Schließen (Fills ab 2.500 USD); Einstieg ab "
                                                f"{DARWIN_MIN_USD / 1e3:.0f}k (23.39)")
    AF = E.get("adressstrom")
    if AF is None:
        z("Adress-Strom", "Aufzeichnung", None, None, "adressstrom", None, "adressfluss.db noch nicht angelegt (Recorder ab 23.33)")
    else:
        z("Adress-Strom", "Trades / Adressen 60 min", f"{AF['trades_h']:,} / {AF['adressen_h']:,}".replace(",", "."), AF.get("ts"), "adressstrom",
          FRISCH_S["adressstrom"], f"Aufzeichnung seit {_uhr(AF.get('seit'))}")
        z("Adress-Strom", "TWAP-Anteil (Null-Hash)", f"{AF['nullhash_anteil'] * 100:.2f} % der Trades" if AF.get("nullhash_anteil") is not None else None,
          AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        z("Adress-Strom", "TWAP-Netto 60 min", (f"{_fmt_usd(AF['tw_netto_h'])} USD" + (f" = {AF['tw_anteil'] * 100:+.2f} % Vol." if AF.get("tw_anteil") is not None else ""))
          if AF.get("ts") else None, AF.get("ts"), "adressstrom", FRISCH_S["adressstrom"])
        top = AF.get("top") or []
        z("Adress-Strom", "Größte Netto-Nehmer 60 min", ", ".join(f"{t['addr'][:6]}…{t['addr'][-4:]} {_fmt_usd(t['netto'])}" + (" (TWAP)" if abs(t.get("twap") or 0) >= 0.5 * abs(t["netto"] or 1) else "")
                                                              for t in top) if top else None, AF.get("ts"), None, FRISCH_S["adressstrom"],
          "Nehmer-Käufe minus -Verkäufe je Adresse; Grundlage für den informierten Fluss (geplant, sobald einige Tage Daten da sind)")
    Rg = next((s["regeln"] for s in strat if s.get("fn") == "grid"), None)       # 23.40: Eingänge der Grids
    if Rg and "grid" in E:
        G = E.get("grid")
        stf = grid_stufen(G["unten"], G["oben"], Rg["schritt_min"], Rg["stufen_min"], Rg["stufen_max"]) if G else None
        z("Grid", "Range 24 h (10.–90. Perzentil)", f"{G['unten']:.6g} – {G['oben']:.6g} ({(G['oben'] / G['unten'] - 1) * 100:.2f} %)" if G else None,
          now, "grid", None, "nach einem Ausstieg rechnen die Grids nur mit Kursen ab dann")
        if G and G.get("trend") is not None:
            ok_l = grid_trend_ok(G["trend"], dict(Rg, richtung="long")); ok_s = grid_trend_ok(G["trend"], dict(Rg, richtung="short"))
            tr_txt = (f"{G['trend']:+.2f} — Long {'darf' if ok_l else 'wartet'}, Short {'darf' if ok_s else 'wartet'} "
                      f"(gegen das Grid höchstens {Rg['trend_gegen']:g}, mit ihm {Rg['trend_mit']:g})").replace(".", ",")
        else:
            tr_txt = None
        z("Grid", "Trend (Netto-Bewegung / Schwankung)", tr_txt, now, "grid", None,
          "für einen reinen Zufallsweg standardnormal: |Trend| ≤ 1 in 68 %, ≤ 2 in 95 % der Fälle")
        z("Grid", f"Stufen (Abstand ≥ {Rg['schritt_min'] * 100:.1f} %)", (f"{len(stf[0]) - 1} Stufen à {stf[1] * 100:.2f} %" if stf
                                                                          else ("Range zu eng" if G else None)), now, "grid")
    Wwe = E.get("wende")                                                          # 23.83 (U226): Eingang der Extrem-Wende (nur BTC)
    if Wwe is not None:
        if Wwe.get("ok"):
            z("Swing", "8-h-Kerzen der Extrem-Wende (swing.db, BTC)", f"bis {_uhr(Wwe['t_schluss'])}" + (" · eben geschlossen" if Wwe["frisch"]
              else ""), Wwe["t_schluss"], "swing", 8 * 3600 + 1800,
              "Entscheidung nach jedem 8-h-Schluss (00/08/16 UTC); Einstieg höchstens 60 min danach, sonst verfällt das Signal")
        else:
            z("Swing", "8-h-Kerzen der Extrem-Wende (swing.db)", None, None, "swing", None, Wwe.get("grund"))
    Wsw = E.get("swing")                                                          # 23.61 (U140): Eingang der Swing-Strategien
    if Wsw is not None:
        if Wsw.get("ok"):
            z("Swing", "Tageskerzen (swing.db, Binance-Futures)", f"Tag {SW._datum(Wsw['tag_ts'])}" + (f" · σ_Tag {Wsw['sigma'] * 100:.2f} %"
              if Wsw.get("sigma") else ""), Wsw["tag_ts"] + SW.TAG, "swing", FRISCH_S["swing"],
              "Entscheidung einmal je Tag nach dem Schluss 00:00 UTC; Einstieg höchstens 6 h danach, sonst erst am nächsten Tag")
        else:
            z("Swing", "Tageskerzen (swing.db)", None, None, "swing", None, Wsw.get("grund"))
        tk = SW._TAKT
        letzt = (tk.get("letzter") or {}).get("ts")
        if not tk.get("gestartet"):
            z("Swing", "Swing-Takt (Kerzen und Funding laden)", None, None, None, None,
              "läuft nicht in diesem Prozess (aus mit HL_SWING=0); neue Kerzen dann nur über „Swing: Historie laden“")
        else:                                                                     # lädt etwa alle 30 min (neue Kerze) -- älter als 1 h = alt
            z("Swing", "Swing-Takt (Kerzen und Funding laden)", "lädt gerade" if tk.get("laeuft") else (f"zuletzt {_uhr(letzt)}" if letzt
              else "wartet auf den ersten Bedarf"), letzt or now, None, 3600,
              tk.get("fehler") or "prüft alle 5 min, ob die letzte fertige 30-min-Kerze fehlt, und lädt sie nach")
    if any(s.get("fn") == "akku" for s in strat) and ("akku_h7" in E or "konten" in E):     # 23.69 (U180): Eingänge der Akkumulation
        H7 = E.get("akku_h7"); kn = E.get("konten"); m_ = b.get("mid") if b else None
        z("Akkumulation", "Hoch 7 Tage (Hyperliquid 1 min)", (f"{H7:.6g}" + (f" · Kurs {(m_ / H7 - 1) * 100:+.2f} %".replace(".", ",") if m_ else ""))
          if H7 else None, now if H7 else None, "akku", None, "Bezug des Rücksetzers: Kauf A1 ab 2 σ₇ darunter, A2 ab 1 σ₇ mit heißem Long-Cluster")
        z("Akkumulation", "Binance-Konten Long ÷ Short", f"{kn[1]:.2f}".replace(".", ",") if kn else None, kn[0] if kn else None, "akku",
          AKKU_KONTEN_S, "ab 3 sind sehr viele Konten long (U142 H1): der Heatmap-Kauf A2 wartet; höchstens 2 h alt, sonst ohne Wirkung")
        if "akku_h48" in E:                                                                  # 23.72 (U186)
            H48 = E.get("akku_h48")
            z("Akkumulation", "Hoch 48 h (Hyperliquid 1 min)", (f"{H48:.6g}" + (f" · Kurs {(m_ / H48 - 1) * 100:+.2f} %".replace(".", ",") if m_ else ""))
              if H48 else None, now if H48 else None, "akku", None, "Bezug des Korrekturkaufs A4: Kauf ab 7 % darunter (ohne Sperre); nach "
              "einem Korrekturkauf zählt das Hoch erst ab dort, dazu binnen 14 Tagen je 7 % unter dem letzten Korrekturkauf")
    return zeilen


def live(L, now: int | None = None) -> dict:
    """Signaltafel für das Dashboard: je Strategie und Coin, was sie im letzten Takt sah; dazu je Coin die Frische der Eingänge."""
    now = int(now or time.time())
    status: dict = {}
    for (sid, coin), v in list(L.status.items()):
        status.setdefault(sid, {})[coin] = v
    frische = {}
    for coin, v in list(L.letzte.items()):
        z = datenfluss(v.get("E"), L.strategien, now)
        frische[coin] = {"frisch": sum(1 for r in z if r["status"] == "frisch"), "alt": sum(1 for r in z if r["status"] == "alt"),
                         "fehlt": sum(1 for r in z if r["status"] == "fehlt"), "ts": v.get("ts"),
                         "preis": ((v.get("E") or {}).get("preis") or {}).get("mid"), "quelle": ((v.get("E") or {}).get("preis") or {}).get("quelle")}
    return {"status": status, "frische": frische, "coins": list(L.coins), "zyklen": L.zyklen, "dauer_s": round(L.dauer, 3), "letzter": L.t_letzt,
            "fehler": list(L.fehler[-8:])}


_DIRS_AUF = ("Open Long", "Open Short", "Short > Long", "Long > Short")
_DIRS_ZU = ("Close Long", "Close Short")


def darwin_episoden(rows: list, fenster: int = DARWIN_FENSTER_S, schwelle: float = DARWIN_MIN_USD, aus_anteil: float = DARWIN_AUS_ANTEIL) -> list:
    """
    Nachrechnung der Live-Regel über eine ganze Fill-Reihe [(ts, addr, coin, dir, px, usd, tid)], zeitlich sortiert: Eröffnungen je
    Konto, Coin und Seite netto über `fenster` (Schließungen ziehen ab, nicht unter null); ab `schwelle` eine Episode, je Eröffnung
    einmal; sie endet, wenn das Konto `aus_anteil` davon wieder geschlossen hat (Feld „aus“), spätestens nach 12 h.
    """
    hist: dict = {}; ep: dict = {}; out = []
    for ts, a, coin, d, px, usd, tid in rows:
        d = str(d or "").rstrip("*"); ts = int(ts); usd = float(usd or 0.0)
        if d not in _DIRS_AUF and d not in _DIRS_ZU:
            continue
        flip = d in ("Short > Long", "Long > Short")
        seite = "long" if d in ("Open Long", "Short > Long", "Close Long") else "short"
        teile = ([("zu", _gegen(seite))] if flip else []) + [("zu" if d in _DIRS_ZU else "auf", seite)]
        h = hist.setdefault((a, coin), [])
        h[:] = [x for x in h if x[0] >= ts - fenster] + [(ts, teile, usd)]
        for k in [k for k, e in ep.items() if ts - e["t"] > DARWIN_EPISODE_S]:
            ep.pop(k)
        for art, s_ in teile:
            k = (a, coin, s_)
            if art == "zu" and k in ep:
                ep[k]["zu"] += usd
                if ep[k]["zu"] >= aus_anteil * max(ep[k]["usd"], 1.0):
                    out[ep.pop(k)["i"]]["aus"] = ts
        for art, s_ in teile:
            k = (a, coin, s_)
            if art != "auf" or k in ep:
                continue
            net, n, t0 = 0.0, 0, None
            for ts2, teile2, usd2 in h:
                for art2, s2 in teile2:
                    if s2 != s_:
                        continue
                    if art2 == "auf":
                        net += usd2; n += 1; t0 = t0 if t0 is not None else ts2
                    else:
                        net = max(0.0, net - usd2)
                        if net <= 0:
                            n, t0 = 0, None
            if net >= schwelle:
                ep[k] = {"t": ts, "usd": net, "zu": 0.0, "i": len(out)}
                out.append({"ts": ts, "addr": a, "coin": coin, "seite": s_, "usd": net, "n": n, "seit": t0, "aus": None})
    return out


def darwin_pruefung(db: str, store: str, now: int | None = None, min_usd_fill: float = 2_500.0) -> list:
    """
    23.34: Sieht das Labor die Trades der Darwin-Liste? Liste, Fills der letzten 24 h in den Labor-Coins (Eröffnungen, Schließungen,
    ohne Richtung, davon unter 2.500 USD = erst seit 23.34 gesammelt), Eröffnungen ≥ 10k binnen 15 min (Live-Regel nachgerechnet)
    und die Einstiege von „Darwin-Liste live folgen“.
    """
    now = int(now or time.time())
    try:
        st = F.store_connect(store); schema(st)
        try:
            r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
            d = json.loads(r[0]) if r and r[0] else {}
            pos = st.execute("SELECT COUNT(*), COALESCE(SUM(p.status='offen'), 0) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                             "WHERE s.name='darwin_folgen' AND p.eroeffnet>=?", (now - 86_400,)).fetchone()
        finally:
            st.close()
    except (sqlite3.Error, ValueError) as e:
        return [f"Darwin-Prüfung: Prognosespeicher nicht lesbar ({type(e).__name__}: {e})"]
    konten = list(dict.fromkeys(str(a).lower() for a in list(d.get("reihe") or []) + list(d.get("liste") or [])))
    if not konten:
        return ["Darwin-Prüfung: Liste leer -- noch kein Konto qualifiziert (check_profis.py --alle zeigt die Gründe)"]
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute(f"SELECT ts, lower(addr), coin, dir, px, notional, tid FROM lb_fills WHERE ts>=? AND coin IN ({','.join('?' * len(COINS))}) "
                               f"AND lower(addr) IN ({','.join('?' * len(konten))}) ORDER BY ts, tid", (now - 86_400, *COINS, *konten)).fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [f"Darwin-Prüfung: Datenbank nicht lesbar ({type(e).__name__}: {e})"]
    n_auf = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_AUF)
    n_zu = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_ZU)
    klein = sum(1 for r in rows if (r[5] or 0) < min_usd_fill)
    ep = darwin_episoden(rows); rang = {a: i + 1 for i, a in enumerate(konten)}
    z = [f"Darwin-Prüfung (24 h): Liste {len(konten)} Konten · Fills in den Labor-Coins {len(rows)} (Eröffnungen {n_auf}, Schließungen {n_zu}, "
         f"ohne Richtung {len(rows) - n_auf - n_zu}; unter 2.500 USD {klein}) · Eröffnungen ≥ {DARWIN_MIN_USD / 1e3:.0f}k binnen "
         f"{DARWIN_FENSTER_S // 60} min: {len(ep)} · „Darwin-Liste live folgen“ eingestiegen: {pos[0] or 0} (offen {pos[1] or 0})"]
    if ep:
        z.append("  letzte Eröffnungen: " + " · ".join(f"{_uhr(e['ts'])} #{rang.get(e['addr'], '?')} {e['addr'][:6]}…{e['addr'][-4:]} {e['coin']} {e['seite']} "
                                                       f"{e['usd'] / 1e3:.0f}k ({e['n']} Fills" + (f", zur Hälfte geschlossen {_uhr(e['aus'])[7:]}" if e.get("aus") else "")
                                                       + ")" for e in ep[-5:][::-1]))
    if len(rows) - n_auf - n_zu > 0:
        z.append("  ohne Richtung = Stream-Fills von Konten, deren Position der Recorder noch nicht kannte -- für das Labor unsichtbar")
    return z


def elite_pruefung(db: str, store: str, now: int | None = None) -> list:
    """
    23.39: Sieht das Labor die Trades der Elite? Elite je Labor-Coin (learned coin/„elite“, ohne Gesperrte), ihre Fills der letzten 24 h im
    jeweiligen Coin (Eröffnungen, Schließungen, ohne Richtung), Eröffnungen ≥ 10k binnen 15 min (Live-Regel nachgerechnet) und die
    Einstiege von „Elite live folgen“ -- wie die Darwin-Prüfung, damit beide Vorlagen vergleichbar sind.
    """
    now = int(now or time.time())
    try:
        st = F.store_connect(store); schema(st)
        try:
            je: dict = {}
            for c in COINS:
                r = st.execute("SELECT value FROM learned WHERE coin=? AND key='elite'", (c,)).fetchone()
                try:
                    v = json.loads(r[0]) if r and r[0] else []
                except ValueError:
                    v = []
                je[c] = [str(a).lower() for a in (v if isinstance(v, list) else []) if isinstance(a, str)][:20]
            pos = st.execute("SELECT COUNT(*), COALESCE(SUM(p.status='offen'), 0) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                             "WHERE s.name='elite_folgen' AND p.eroeffnet>=?", (now - 86_400,)).fetchone()
        finally:
            st.close()
    except sqlite3.Error as e:
        return [f"Elite-Prüfung: Prognosespeicher nicht lesbar ({type(e).__name__}: {e})"]
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            try:
                gesperrt = {r_[0].lower() for r_ in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
            except sqlite3.Error:
                gesperrt = set()
            je = {c: [a for a in k if a not in gesperrt] for c, k in je.items()}
            rows = []
            for c, konten in je.items():
                if konten:
                    rows += con.execute(f"SELECT ts, lower(addr), coin, dir, px, notional, tid FROM lb_fills WHERE ts>=? AND coin=? "
                                        f"AND lower(addr) IN ({','.join('?' * len(konten))})", (now - 86_400, c, *konten)).fetchall()
        finally:
            con.close()
    except sqlite3.Error as e:
        return [f"Elite-Prüfung: Datenbank nicht lesbar ({type(e).__name__}: {e})"]
    alle = {a for k in je.values() for a in k}
    if not alle:
        return ["Elite-Prüfung: keine Elite gespeichert -- das Dashboard stellt sie täglich je Coin auf (Debug „Elite-Positionierung prüfen“)"]
    rows.sort(key=lambda r: (r[0], r[6]))
    n_auf = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_AUF)
    n_zu = sum(1 for r in rows if str(r[3] or "").rstrip("*") in _DIRS_ZU)
    ep = darwin_episoden(rows)
    rang = {(c, a): i + 1 for c, k in je.items() for i, a in enumerate(k)}
    z = [f"Elite-Prüfung (24 h): Elite je Coin " + " · ".join(f"{c} {len(k)}" for c, k in je.items()) + f" ({len(alle)} Konten) · Fills im "
         f"eigenen Coin {len(rows)} (Eröffnungen {n_auf}, Schließungen {n_zu}, ohne Richtung {len(rows) - n_auf - n_zu}; erst ab 2.500 USD) · "
         f"Eröffnungen ≥ {DARWIN_MIN_USD / 1e3:.0f}k binnen {DARWIN_FENSTER_S // 60} min: {len(ep)} · „Elite live folgen“ eingestiegen: "
         f"{pos[0] or 0} (offen {pos[1] or 0})"]
    if ep:
        z.append("  letzte Eröffnungen: " + " · ".join(f"{_uhr(e['ts'])} #{rang.get((e['coin'], e['addr']), '?')} {e['addr'][:6]}…{e['addr'][-4:]} "
                                                       f"{e['coin']} {e['seite']} {e['usd'] / 1e3:.0f}k ({e['n']} Fills"
                                                       + (f", zur Hälfte geschlossen {_uhr(e['aus'])[7:]}" if e.get("aus") else "") + ")"
                                                       for e in ep[-5:][::-1]))
    return z


def gebuehren_pruefung(db: str, now: int | None = None, tage: int = 3, wechsel: dict | None = None) -> str | None:
    """23.34: Gebührensatz echter Fills (REST/userEvents: Richtung ohne Sternchen, Gebühr > 0) je Coin -- Prüfung der XMR-Annahme.
    23.68 (U160): nennt den Faktor, den das Labor rechnet, mit dem Zeitpunkt des Wechsels („×1,0 seit …“)."""
    w = (wechsel or {}).get("XMR")
    labor_txt = (f"Labor rechnet {_faktor_txt(GEB_FAKTOR.get('XMR', 1.0))} seit {time.strftime('%d.%m.%Y %H:%M', time.localtime(int(w['ab'])))} "
                 f"(vorher {_faktor_txt(w.get('vorher', 1.0))})") if w else f"Labor rechnet {_faktor_txt(GEB_FAKTOR.get('XMR', 1.0))}"
    now = int(now or time.time())
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        try:
            rows = con.execute("SELECT coin, fee / notional FROM lb_fills WHERE ts>=? AND coin IN ('BTC','ETH','XMR') AND fee > 0 AND notional > 0 "
                               "AND dir NOT LIKE '%*' AND dir <> 'stream' LIMIT 300000", (now - tage * 86_400,)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    je: dict = {}
    for c, q in rows:
        if q is not None and 0 < q < 0.01:
            je.setdefault(c, []).append(q)
    med = lambda v: sorted(v)[len(v) // 2]
    if len(je.get("XMR", [])) < 30 or len(je.get("BTC", []) + je.get("ETH", [])) < 30:
        return f"Gebühren-Prüfung: zu wenige echte Fills mit Gebühr ({len(je.get('XMR', []))} XMR) -- {labor_txt} für XMR"
    std = med(je.get("BTC", []) + je.get("ETH", [])); x = med(je["XMR"])
    return (f"Gebühren-Prüfung ({tage} T, Median Gebühr/Umsatz echter Fills): BTC/ETH {std * 100:.4f} %, XMR {x * 100:.4f} % "
            f"-> XMR ≈ ×{x / std:.1f} der Standard-Perps".replace(".", ",") + f" ({labor_txt}; Konten- und Taker/Maker-Mischung verzerrt)")


# ------------------------------------------------------------------------------------------------ Akkumulation: Ausgabe (U180, 23.69)
_AKKU_VGL_CACHE: dict = {}


def _akku_mitten(db: str | None, coins, now: int, L=None) -> dict:
    """Kurs (Mitte) je Coin: aus dem laufenden Labor, sonst der jüngste 1-min-Schluss der Hauptdatenbank (höchstens 1 h alt)."""
    out = {}
    if L is not None:
        for c, v in list(L.letzte.items()):
            m = ((v.get("E") or {}).get("preis") or {}).get("mid")
            if m:
                out[c] = float(m)
    if db and os.path.exists(db) and any(c not in out for c in coins):
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                for c in coins:
                    if c not in out:
                        r = con.execute("SELECT close FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts DESC LIMIT 1", (c, now - 3600, now)).fetchone()
                        if r and r[0]:
                            out[c] = float(r[0])
            finally:
                con.close()
        except sqlite3.Error:
            pass
    return out


def akku_erlaubt(ts, c, tag_ts, ma, faktor: float) -> np.ndarray:
    """Minuten ohne Sperre (KONZEPT 4): 1-min-Schluss unter faktor × 200-Tage-Linie des Vortags; ohne Linie des Vortags nicht erlaubt."""
    ts = np.asarray(ts, dtype=np.int64); c = np.asarray(c, dtype=float); tag_ts = np.asarray(tag_ts, dtype=np.int64)
    if not len(tag_ts):
        return np.zeros(len(ts), dtype=bool)
    vortag = ts // 86_400 * 86_400 - 86_400
    i = np.minimum(np.searchsorted(tag_ts, vortag), len(tag_ts) - 1)
    m = np.where(tag_ts[i] == vortag, np.asarray(ma, dtype=float)[i], np.nan)
    with np.errstate(invalid="ignore"):
        return np.isfinite(m) & (c < faktor * m)


def akku_vergleich_live(db: str, swing_pfad: str, coin: str, R: dict, ab: int, now: int, preise_kauf: list) -> dict | None:
    """KONZEPT 4 (vorwärts): dieselbe Zahl Käufe zu Zufallsminuten seit dem Start der Strategie, nur Minuten ohne Sperre (1-min-Schluss unter
    1,2 × 200-Tage-Linie des Vortags aus swing.db); Kaufpreise der Strategie zur Mitte (reiner Zeitpunkt, ohne Abstand zur Buchmitte)."""
    key = (coin, bool(R.get("cluster")), len(preise_kauf), int(ab), int(now) // 300)
    if key in _AKKU_VGL_CACHE:
        return _AKKU_VGL_CACHE[key]
    W = SW.labor_daten(swing_pfad, coin, now)
    if not W.get("ok") or not db or not os.path.exists(db):
        return None
    T = W["T"]; ma = W["I"].sma(int(R["ma_tage"])); tag_ts = np.asarray(T["tag_ts"], dtype=np.int64)
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            rows = con.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<? ORDER BY ts", (coin, int(ab), int(now) // 60 * 60)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    rows = [r for r in rows if r[1]]
    if not rows:
        return None
    a = np.array(rows, dtype=float); ts = a[:, 0].astype(np.int64); c = a[:, 1]
    erl = akku_erlaubt(ts, c, tag_ts, ma, R["ma_faktor"])
    v = akku_vergleich(preise_kauf, c[erl])
    if len(_AKKU_VGL_CACHE) > 64:
        _AKKU_VGL_CACHE.clear()
    _AKKU_VGL_CACHE[key] = v
    return v


def akku_schwellen(R: dict, fk: dict | None, W: dict | None) -> dict:
    """
    23.74 (U189, Nutzer 20.10. 09:55: „eine Tabelle …, wo man einfach reingucken kann, wie die Schwellen sind“): je Coin der Faktor gegenüber
    BTC (fest), der Betrag je Kauf, die Schwelle des Korrekturkaufs A4 (fest) und die Abstände von A1/A2/A3 mit σ₇ von heute (aus swing.db,
    wie der Takt) samt Sperre. Prozente als Abstand nach unten.
    """
    f = float(fk["faktor"]) if fk and fk.get("faktor") else None
    out = {"faktor": f, "roh": (fk or {}).get("roh"), "sigma": (fk or {}).get("sigma"), "sigma_basis": (fk or {}).get("sigma_basis"),
           "n": (fk or {}).get("n"), "von": (fk or {}).get("von"), "bis": (fk or {}).get("bis"), "basis": R.get("faktor_basis", "BTC"),
           "tage": int(R.get("faktor_tage", 365)), "usd": akku_betrag(R, f) if f else None,
           "a4_pct": (1.0 - akku_korr_q(R, f)) * 100 if (f and R.get("korr")) else None, "korr_h": R.get("korr_h"), "korr_tage": R.get("korr_tage"),
           "sigma7": None, "a1_pct": None, "a2_pct": None, "a3_pct": None, "ma200": None, "sperre": None, "ma_faktor": R.get("ma_faktor")}
    if W and W.get("ok") and W.get("sigma"):
        s7 = float(W["sigma"]) * math.sqrt(int(R["fenster_tage"]))
        out.update(sigma7=s7, a1_pct=(1 - math.exp(-R["tiefe"] * s7)) * 100, a3_pct=(1 - math.exp(-R["stufe"] * s7)) * 100,
                   a2_pct=(1 - math.exp(-R["cluster_tiefe"] * s7)) * 100 if R.get("cluster") else None)
        try:
            v = W["I"].sma(int(R["ma_tage"]))[W["d"]]
            if np.isfinite(v):
                out.update(ma200=float(v), sperre=float(v) * R["ma_faktor"])
        except (KeyError, IndexError, TypeError):
            pass
    return out


def akku_daten(store: str, db: str | None = None, L=None, now: int | None = None, vergleich: bool = True, swing_pfad: str | None = None) -> dict:
    """/labor/akku: je Akkumulations-Strategie und Coin die Bilanz mit allen Losen, die Tageszeilen (Wachstum), die Lage aus dem letzten
    Takt und den Vergleich (ab 5 Käufen); dazu die Summen je Strategie."""
    now = int(now or time.time()); st = F.store_connect(store); schema(st)
    try:
        strat = [dict(zip(("sid", "name", "titel", "regeln", "beschreibung", "erstellt", "aktiv"), r)) for r in st.execute(
            f"SELECT sid, name, titel, regeln, beschreibung, erstellt, aktiv FROM labor_strategie WHERE name IN ({','.join('?' * len(AKKU_NAMEN))}) "
            "ORDER BY erstellt, name", AKKU_NAMEN)]
        kauf = st.execute("SELECT id, sid, coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte FROM labor_akku_kauf "
                          "ORDER BY ts, id").fetchall()
        tage = st.execute("SELECT sid, coin, tag, eingesetzt, menge, wert, px, n, ts FROM labor_akku_tag ORDER BY tag").fetchall()
        fak = {(r[0], r[1]): dict(zip(("faktor", "roh", "sigma", "sigma_basis", "n", "von", "bis", "start", "ts"), r[2:])) for r in st.execute(
            "SELECT sid, coin, faktor, roh, sigma, sigma_basis, n, von, bis, start, ts FROM labor_akku_faktor")}      # 23.74 (U189)
    finally:
        st.close()
    coins = list(COINS) + sorted({r[2] for r in kauf} - set(COINS))         # Selbsttest: synthetische Coins
    mitten = _akku_mitten(db, coins, now, L)
    sw = swing_pfad or (L.swing_pfad if L is not None else (SW.swing_pfad(db) if db else None))
    W_c: dict = {}

    def _w(c_):                                                        # 23.74 (U189): σ₇ und 200-Tage-Linie je Coin für die Schwellen
        if c_ not in W_c:
            try:
                W_c[c_] = SW.labor_daten(sw, c_, now) if sw else None
            except Exception:
                W_c[c_] = None
        return W_c[c_]
    out = []
    for s in strat:
        R = json.loads(s["regeln"] or "{}"); sid = s["sid"]
        ks = [r for r in kauf if r[1] == sid]
        if not s["aktiv"] and not ks:
            continue
        je_coin = {}
        for c in coins:
            k = []
            for r in ks:
                if r[2] != c:
                    continue
                try:
                    w = json.loads(r[12] or "{}")
                except ValueError:
                    w = {}
                k.append({"id": r[0], "ts": r[3], "ausloeser": r[4], "preis": r[5], "mitte": r[6], "usd": r[7], "menge": r[8], "gebuehr": r[9],
                          "slip_bps": r[10], "grund": akku_grund_text(r[11]), "werte": w})
            B = akku_bilanz(k, mitten.get(c))
            B["tage"] = [[int(t[2]), round(t[3], 2), round(t[5], 2), t[6], int(t[7])] for t in tage if t[0] == sid and t[1] == c][-400:]
            B["lage"] = (L.akku_status.get((sid, c)) if L is not None else None)
            B["faktor"] = fak.get((sid, c))                            # 23.74 (U189): fest, einmal bestimmt
            B["schwelle"] = akku_schwellen(R, B["faktor"], _w(c)) if (s["aktiv"] and R.get("faktor_basis")) else None
            # 23.70 (U184): Zeitraum ab dem Beginn der Rückrechnung (Start des Coins im Labor); Vergleich nur über die Käufe nach den Regeln
            # 23.72 (U186): ohne die Korrekturkäufe A4 (eigene Spur ohne Sperre -- der Vergleich zieht nur aus Minuten ohne Sperre)
            regel = [x for x in k if x["ausloeser"] not in ("A0", "A4")]
            nach = [x for x in k if (x["werte"] or {}).get("nachgerechnet")]
            B["n_regel"] = len(regel); B["n_nach"] = len(nach); B["n_korr"] = sum(1 for x in k if x["ausloeser"] == "A4")
            B["ab"] = min([int(s["erstellt"])] + [int(x["ts"]) for x in k] + [int(x["werte"]["ab"]) for x in nach if x["werte"].get("ab")])
            B["nach_bis"] = max((int(x["werte"].get("bis") or 0) for x in nach), default=None)
            B["vergleich"] = None
            if vergleich and db and sw and B["n_regel"] >= AKKU_MIN_VERGLEICH:
                try:
                    B["vergleich"] = akku_vergleich_live(db, sw, c, R, B["ab"], now, [x["mitte"] or x["preis"] for x in regel])
                except Exception as e:
                    B["vergleich"] = {"fehler": f"{type(e).__name__}: {e}"}
            je_coin[c] = B
        ein = sum(b["eingesetzt"] for b in je_coin.values()); wert = sum((b["wert"] or 0.0) for b in je_coin.values() if b["n"])
        fehlt = [c for c, b in je_coin.items() if b["n"] and b["wert"] is None]
        tage_ges: dict = {}
        letzte = {}
        for t in sorted({t_[2] for t_ in tage if t_[0] == sid}):
            for c in coins:
                z_ = next((t_ for t_ in tage if t_[0] == sid and t_[1] == c and t_[2] == t), None)
                if z_:
                    letzte[c] = z_
            tage_ges[t] = [round(sum(v[3] for v in letzte.values()), 2), round(sum(v[5] for v in letzte.values()), 2)]
        mit_k = [b for b in je_coin.values() if b["n"]]
        out.append({"sid": sid, "name": s["name"], "titel": s["titel"], "aktiv": bool(s["aktiv"]), "erstellt": s["erstellt"], "regeln": R,
                    "ab": min([int(s["erstellt"])] + [b["ab"] for b in mit_k]), "n_nach": sum(b["n_nach"] for b in je_coin.values()),
                    "n_korr": sum(b.get("n_korr", 0) for b in je_coin.values()),
                    "nach_bis": max((b["nach_bis"] for b in mit_k if b["nach_bis"]), default=None),
                    "beschreibung": s["beschreibung"], "je_coin": je_coin,
                    "gesamt": {"n": sum(b["n"] for b in je_coin.values()), "eingesetzt": ein, "wert": wert if not fehlt else None,
                               "gewinn_usd": (wert - ein) if (ein and not fehlt) else None,
                               "gewinn_pct": ((wert / ein - 1) * 100) if (ein and not fehlt) else None, "ohne_kurs": fehlt,
                               "tage": [[t, v[0], v[1]] for t, v in sorted(tage_ges.items())][-400:]}})
    return {"ts": now, "coins": coins, "usd": AKKU_USD, "geb": AKKU_GEB, "strategien": out, "hinweis": AKKU_HINWEIS,
            "laeuft": L is not None}


def _de(x, nd: int = 2) -> str:
    return "—" if x is None else f"{x:,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def akku_bericht(store: str, db: str | None, now: int) -> list:
    """Abschnitt „Akkumulation“ im Labor-Bericht."""
    try:
        d = akku_daten(store, db, None, now)
    except Exception as e:
        return ["", f"AKKUMULATION (U180): {type(e).__name__}: {e}"]
    z = ["", f"AKKUMULATION (U180) -- nur Kauf, nie Verkauf; {_de(AKKU_USD, 0)} USD je Kauf als Spot-Kauf (seit 23.74 geteilt durch den Faktor "
             f"gegenüber BTC), Gebühr {_de(AKKU_GEB * 100, 3)} % "
             "beim Kauf, Kapital ohne Obergrenze; Startkauf A0 je Coin, seit 23.70 rückwirkend ab dem Start des Coins im Labor; seit 23.72 "
             "Korrekturkauf A4 (7 % unter dem 48-Stunden-Hoch, Nachkauf je 7 % binnen 14 Tagen, ohne Sperre, auch rückwirkend; seit 23.74 bei den "
             "übrigen Coins 0,93 hoch Faktor); Gewinn zur Mitte ohne Verkaufsgebühr (KONZEPT_Akkumulation.md)"]
    if not d["strategien"]:
        z.append("  noch nicht registriert (der Labor-Takt legt die Strategien beim ersten Lauf an)")
        return z
    # 23.74 (U189, Nutzer 20.10. 09:55: „eine Tabelle …, wo man einfach reingucken kann, wie die Schwellen sind“): Schwellen je Coin der
    # laufenden Hauptstrategie (die Kontrolle hat dieselben Faktoren)
    sh = next((s for s in d["strategien"] if s["aktiv"] and s["name"] == "akku"), None)
    if sh and any((b.get("schwelle") or {}) for b in sh["je_coin"].values()):
        R_ = sh.get("regeln") or {}
        z.append(f"  Schwellen je Coin -- Faktor gegenüber {R_.get('faktor_basis', 'BTC')} aus den {R_.get('faktor_tage', 365)} Tagen vor dem Start "
                 "des Coins (fest), Betrag je Kauf, Korrekturkauf A4 unter dem 48-h-Hoch und je Nachkauf (fest); Rücksetzer A1 und Nachkauf A3 "
                 "mit σ₇ von heute; Sperre ab 1,2 × 200-Tage-Linie:")
        for c, b in sh["je_coin"].items():
            w = b.get("schwelle")
            if not w:
                continue
            if w.get("faktor") is None:
                z.append(f"    {c:<5}Faktor folgt mit dem ersten Takt (bis dahin kein Kauf)")
                continue
            sg = (f" (σ_Tag {_de((w['sigma'] or 0) * 100, 2)} % gegen {_de((w['sigma_basis'] or 0) * 100, 2)} %, {w.get('n')} Tage)"
                  if w.get("sigma") is not None and w.get("sigma_basis") is not None else "")
            pc_ = lambda x: "—" if x is None else "−" + _de(x, 1) + " %"
            z.append(f"    {c:<5}Faktor {_de(w['faktor'], 2)}{sg} · {_de(w['usd'], 0)} USD je Kauf · A4 ab {pc_(w.get('a4_pct'))} · A1 "
                     f"{pc_(w.get('a1_pct'))} · A3 je {pc_(w.get('a3_pct'))} · Sperre ab "
                     f"{'—' if w.get('sperre') is None else _g6(w['sperre'])}")
    # 23.73 (U187): die laufenden Strategien zuerst und ausführlich; frühere Regelstände (andere Kennung, kaufen nicht mehr) danach in einer
    # Zeile mit „(alte Regeln)“ -- 23.72 nannte sie mit demselben Titel wie die laufenden
    alt_ = [s for s in d["strategien"] if not s["aktiv"]]
    for s in [s for s in d["strategien"] if s["aktiv"]] + alt_:
        g = s["gesamt"]
        z.append(f"  {s['titel']}{'' if s['aktiv'] else ' (alte Regeln)'}: {g['n']} {'Kauf' if g['n'] == 1 else 'Käufe'} seit "
                 f"{_uhr(s.get('ab') or s['erstellt'])}, eingesetzt "
                 f"{_de(g['eingesetzt'], 0)} USD, Wert {_de(g['wert'], 0)} USD"
                 + (f" ({g['gewinn_pct']:+.2f} %)".replace(".", ",") if g.get("gewinn_pct") is not None else "")
                 + (f" -- ohne Kurs: {', '.join(g['ohne_kurs'])}" if g.get("ohne_kurs") else "")
                 + ("" if s["aktiv"] else f" -- frühere Kennung {s['sid']}, kauft nicht mehr (Abschnitt „frühere Regeln“ im Reiter)"))
        if not s["aktiv"]:
            continue
        if s.get("n_nach"):                                            # 23.70 (U184)
            z.append(f"    davon {s['n_nach']} rückwirkend nachgerechnet (1-min-Kerzen ab dem Start des Coins im Labor, ohne Heatmap) bis "
                     f"{_uhr(s.get('nach_bis'))}")
        for c, b in s["je_coin"].items():
            if not b["n"]:
                continue
            art = {}
            for k in b["lose"]:
                art[k["ausloeser"]] = art.get(k["ausloeser"], 0) + 1
            v = b.get("vergleich") or {}
            vg = ""
            if v and "vorteil_pct" in v:
                vg = (f" · Zufallszeiten Ø {_de(v['zufall_median'], 6 if v['zufall_median'] < 10 else 2)} (Vorteil {v['vorteil_pct']:+.2f} %, "
                      f"p {v['p']:.2f}) · gleichmäßig {v['vorteil_gleich_pct']:+.2f} %").replace(".", ",")
            elif b.get("n_regel", b["n"]) < AKKU_MIN_VERGLEICH:
                vg = f" · Vergleich ab {AKKU_MIN_VERGLEICH} Käufen nach den Regeln (ohne Startkauf und Korrekturkäufe)"
            z.append(f"    {c:<5}{b['n']:>3} {'Kauf ' if b['n'] == 1 else 'Käufe'} ({', '.join(f'{a} {n}' for a, n in sorted(art.items()))}) · Ø Einstand {b['einstand']:.6g} · "
                     f"Kurs {'—' if b['mid'] is None else format(b['mid'], '.6g')} · Wert {_de(b['wert'], 0)} USD"
                     + (f" ({b['gewinn_pct']:+.2f} %)".replace(".", ",") if b.get("gewinn_pct") is not None else "") + vg)
        letzte = sorted((k for b in s["je_coin"].values() for k in b["lose"]), key=lambda k: -k["ts"])[:8]
        for k in letzte:
            z.append(f"      {_uhr(k['ts'])} {k['ausloeser']} zu {k['preis']:.6g}: {(k['grund'] or '')[:320]}")   # 23.71: Startkauf-Grund ganz
    z.append("  " + AKKU_HINWEIS)
    return z


def akku_rueckblick_text(db: str, surrogate: int = AKKU_SURROGATE) -> str:
    """Debug „Akkumulation: Rückblick seit 2020“ (KONZEPT 5): Regel ohne Heatmap auf den 30-min-Kerzen aus swing.db je Coin."""
    t0 = time.time(); pfad = SW.swing_pfad(db)
    R = dict(AKKU_REGELN, cluster=False)
    z = [f"Akkumulation (U180): Rückblick auf der Historie -- Regel ohne Heatmap (A1 Rücksetzer 2 σ₇, A3 Nachkauf je σ₇, Sperre ab "
         f"1,2 × 200-Tage-Linie; ohne Startkauf, er ist kein Zeitpunkt der Regel) auf den 30-min-Kerzen aus swing.db; {_de(AKKU_USD, 0)} USD "
         f"je Kauf, Gebühr {_de(AKKU_GEB * 100, 3)} %; "
         f"Vergleich mit {AKKU_ZIEHUNGEN} Zufallsziehungen und {surrogate} Vorzeichen-Surrogaten (KONZEPT_Akkumulation.md 5)", ""]
    if not os.path.exists(pfad):
        return "\n".join(z + ["swing.db fehlt"])
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        for coin in COINS:
            rows = con.execute("SELECT ts, o, h, l, c, v FROM sw_klines WHERE coin=? ORDER BY ts", (coin,)).fetchall()
            if len(rows) < 48 * 230:
                z.append(f"{coin}: zu wenige Kerzen ({len(rows)})"); continue
            a = np.array(rows, dtype=float)
            K = {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}
            r = akku_rueckblick_coin(R, K, surrogate=surrogate)
            if not r.get("ok"):
                z.append(f"{coin}: {r.get('grund')}"); continue
            v = r.get("vergleich") or {}; s_ = r.get("surrogat") or {}
            z.append(f"{coin}: {time.strftime('%d.%m.%Y', time.gmtime(r['ab']))}–{time.strftime('%d.%m.%Y', time.gmtime(r['bis']))} · {r['n']} Käufe "
                     f"(A1 {r['je_art']['A1']}, A3 {r['je_art']['A3']}) · eingesetzt {_de(r['eingesetzt'], 0)} USD · Ø Einstand "
                     f"{(r['einstand'] or 0):.6g} · Wert am Ende {_de(r['wert'], 0)} USD"
                     + (f" ({r['gewinn_pct']:+.1f} %)".replace(".", ",") if r.get("gewinn_pct") is not None else ""))
            if v:
                z.append(f"   gegen Zufallszeiten: Ø {v['zufall_median']:.6g} (90 %: {v['zufall_band'][0]:.6g}–{v['zufall_band'][1]:.6g}) → Vorteil "
                         f"{v['vorteil_pct']:+.2f} %, p {v['p']:.3f}; gegen gleichmäßig {v['vorteil_gleich_pct']:+.2f} %".replace(".", ","))
                hz = [h_ for h_ in r["haelften"]]
                z.append("   Hälften (Teilung " + time.strftime('%d.%m.%Y', time.gmtime(r['mitte'])) + "): "
                         + " · ".join((f"{h_['n']} Käufe, Vorteil {h_['vorteil_pct']:+.2f} %, p {h_['p']:.3f}".replace(".", ",") if h_ else "zu wenige Käufe")
                                      for h_ in hz))
            sv = r.get("surrogat_vorteil")
            if sv:
                z.append(f"   derselbe Vorteil auf Zufallswegen (Vorzeichen-Surrogate, ohne Vorhersagekraft): Median {sv['median']:+.2f} % "
                         f"(90 %: {sv['band'][0]:+.2f} … {sv['band'][1]:+.2f} %)".replace(".", ","))
            tq = r.get("timing") or {}
            if tq.get("q") is not None:
                z.append((f"   Zeitpunkt Q (Mittel der 7 Tage nach dem Kauf gegen den Kaufpreis, {tq['n']} Käufe): {tq['q']:+.2f} %; Hälften "
                          + " · ".join("—" if x is None else f"{x:+.2f} %" for x in r.get("timing_haelften") or [])).replace(".", ","))
            if s_:
                z.append(f"   Zufallswege (Vorzeichen-Surrogate, Drift und Schwankung gleich): Q derselben Regel im Median {s_['median']:+.2f} % "
                         f"(90 %: {s_['band'][0]:+.2f} … {s_['band'][1]:+.2f} %), p {s_['p']:.3f} → Zeitpunkt "
                         f"{'BELEGT' if r['timing_beleg'] else 'nicht belegt'} (Regel: p < 0,05 und beide Hälften über dem Surrogat-Median)".replace(".", ","))
            elif v:
                z.append("   Zufallswege: zu wenige gültige Surrogate oder Käufe")
            if r.get("jahre"):
                z.append("   je Jahr: " + " · ".join(f"{j} {x['n']}× Ø " + format(x['einstand'], '.6g').replace(".", ",") for j, x in r["jahre"].items()))
    finally:
        con.close()
    z += ["", "Lesart: beschreibend (Parameter und Zeitraum bekannt), kein Urteil über den Live-Betrieb. Der Vorteil gegen Zufallszeiten ist auch "
              "ohne Vorhersagekraft meist positiv (die Regel kauft nie nach einem Anstieg) und schwankt stark mit dem Trend; maßgeblich für den "
              "Zeitpunkt ist Q gegen die Zufallswege.", f"Rechenzeit {time.time() - t0:.0f} s"]
    return "\n".join(z)


def bericht_text(store: str, now: int | None = None, db: str | None = None) -> str:
    """Textbericht (Debug-Eintrag „labor“, Wochenplan): Stand, Kennzahlen je Strategie, beste je Coin, ALLE offenen Positionen,
    letzte Trades; mit db (23.34) auch die Darwin- und die Gebühren-Prüfung."""
    now = int(now or time.time()); d = uebersicht(store, {}, now); g = d["gesamt"]
    pc = lambda x, n=3: "—" if x is None else f"{x:+.{n}f} %"
    tt = lambda x: "—" if x is None else f"{x:+.1f}"
    qq = lambda x: "—" if x is None else f"{x * 100:.0f} %"
    usd = f"{NOTIONAL:,.0f}".replace(",", ".")
    seit = d.get("coins_seit") or {}
    gruppen: dict = {}
    for c in COINS:
        gruppen.setdefault(seit.get(c), []).append(c)
    coins_txt = "; ".join(f"{', '.join(cs)} seit {_uhr(t)}" for t, cs in sorted(gruppen.items(), key=lambda kv: kv[0] or 0))
    z = [f"TradeLabor · simulierter Handel, kein echtes Geld · {usd} USD je Trade (Grid: {usd} USD je Coin, auf die Stufen verteilt) · "
         f"Start {_uhr(d['start'])} · {g['strategien']} Strategien × {len(COINS)} Coins ({coins_txt})",
         "Gebühren: Taker 0,045 %, Maker 0,015 %" + (f"; {d['geb_wechsel_text']} (U160, Entscheidung des Nutzers 13.10.)"
                                                    if d.get("geb_wechsel_text") else ""),
         f"Geschlossene Trades {g['trades']} (24 h: {g['trades_24h']}, netto {g['netto_24h']:+.2f} USD) · gesamt netto {g['netto_usd']:+.2f} USD, "
         f"Gebühren {g['gebuehren_usd']:.2f} · offen {g['offen']} · Limit-Orders {g['orders']} · Grid {g.get('grid_lose', 0)} Lose (Bestand "
         f"{sum(k.get('bestand_usd') or 0.0 for k in d['strategien'] if k.get('name') in GRID_NAMEN and k.get('aktiv')):+.2f} USD, letzter Tagesstand), "
         f"{g.get('grid_orders', 0)} Orders",
         "Stufen: " + ", ".join(f"{k} {v}" for k, v in g["stufen"].items()),
         "Achtung: Bei vielen Strategien sehen einige zufällig gut aus. „Glück“ = Wahrscheinlichkeit, dass die beste von allen "
         "rein zufällig so gut aussähe. t, Glück und Stufen zählen BLÖCKE (Bl.): gleichzeitig eröffnete Trades einer Strategie "
         "(dasselbe Signal in mehreren Coins) sind eine Beobachtung. „bewährt“ erst mit ≥ 30 Blöcken, t ≥ 3, beide Hälften positiv, ≥ 14 Tage.", ""]
    z.append(f"{'Strategie':<34}{'Stufe':<11}{'n (Bl.)':>10}{'Treffer':>9}{'Ø netto':>10}{'t':>6}{'Glück':>7}{'Summe USD':>11}{'Ø/Tag':>9}"
             f"{'max DD':>8}  5× Hebel")
    for k in d["strategien"]:
        if not k["aktiv"] and not k["n"]:
            continue
        h5 = next((h for h in k["hebel"] if h["L"] == 5), None)
        h5t = "—" if not h5 else (f"{h5['liquidiert']}× liquidiert" if h5["liquidiert"] else f"Ø/Tag {pc(h5['tag_pct'], 2)}")
        nb = f"{k['n']} ({k.get('n_eff', 0)})"
        z.append(f"{k['titel'][:33]:<34}{k['stufe']:<11}{nb:>10}{qq(k['treffer']):>9}{pc(k['mittel_pct']):>10}{tt(k['t']):>6}"
                 f"{qq(k.get('p_glueck')):>7}{k['summe_usd']:>+11.2f}{pc(k.get('tag_pct'), 3):>9}{k['max_dd_usd']:>8.0f}  {h5t}"
                 + ("" if k["aktiv"] else "  (alte Regelversion)"))
    z.append("")
    z.append("Je Coin (Strategien mit mindestens 5 Trades, beste drei nach Summe):")
    for c in COINS:
        r = sorted(((k["titel"], k["je_coin"][c]) for k in d["strategien"] if c in k["je_coin"] and k["je_coin"][c]["n"] >= 5),
                   key=lambda x: -x[1]["summe_usd"])[:3]
        z.append(f"  {c:<5}" + (" · ".join(f"{t} {v['summe_usd']:+.0f} USD (n {v['n']}, t {tt(v['t'])})" for t, v in r) if r else "noch keine"))
    z += strategie_coin_bericht(store, d, now)                                  # 23.68 (U161)
    z += grid_bericht(d)
    z += grid_tage_bericht(store, d)                                            # 23.68 (U163)
    z += swing_bericht(store)
    z += akku_bericht(store, db, now)                                          # 23.69 (U180)
    if db:
        z.append("")
        try:
            z += darwin_pruefung(db, store, now)
        except Exception as e:
            z.append(f"Darwin-Prüfung: {type(e).__name__}: {e}")
        try:
            z += elite_pruefung(db, store, now)
        except Exception as e:
            z.append(f"Elite-Prüfung: {type(e).__name__}: {e}")
        try:
            gp = gebuehren_pruefung(db, now, wechsel=d.get("geb_wechsel"))
            if gp:
                z.append(gp)
        except Exception as e:
            z.append(f"Gebühren-Prüfung: {type(e).__name__}: {e}")
        try:                                                                   # 23.76 (U206): Abschnitt Notbremse (Welt A gegen dieses Labor)
            import hl_notbremse as NB
            z.append("")
            z += NB.bericht_zeilen(db, store, NB.labor_a_pfad(store), NB.preise_jetzt(db), now)
        except Exception as e:
            z.append(f"Notbremse: {type(e).__name__}: {e}")
    z.append("")
    o_ = [o for o in d["offen"] if not o.get("grid")]
    z.append(f"Offene Positionen ({len(o_)}; Grid-Lose stehen oben je Grid und Coin):")
    for o in o_:
        z.append(f"  {o['titel'][:30]:<31}{o['coin']:<5}{o['seite']:<6} seit {_uhr(o['eroeffnet'])} zu {o['preis_ein']:.6g}"
                 + (f" · Stop {o['sl']:.6g}" if o["sl"] else "") + (f" · Ziel {o['tp']:.6g}" if o["tp"] else "")
                 + (f" · bis {_uhr(o['ablauf'])}" if o.get("ablauf") else "") + f" · {(o['grund'] or '')[:90]}")
    z.append("")
    z.append("Letzte Ein- und Ausstiege (Grid: Aufbau, Nachführen, Halten, Notausstieg -- die einzelnen Lose nicht):")
    for e in [e for e in d["ereignisse"] if e["art"] in ("eroeffnet", "geschlossen", "kaskade", "grid", "akku")][:30]:
        z.append(f"  {_uhr(e['ts'])} {e['titel'][:26]:<27}{(e['coin'] or ''):<5}{e['art']:<12}{e['text'][:150]}")
    return "\n".join(z)


def swing_bilanz(store: str) -> dict:
    """23.61 (U140): je Swing-Strategie die geschlossenen Trades in R (netto ÷ Risiko bis zum Stop, aus den Werten der Position),
    Trefferquote, Haltedauer und offene Positionen."""
    st = F.store_connect(store); schema(st); out = {}
    try:
        titel = {r[0]: r[1] for r in st.execute("SELECT sid, titel FROM labor_strategie WHERE gruppe='Swing'")}
        aktiv = {r[0]: bool(r[1]) for r in st.execute("SELECT sid, aktiv FROM labor_strategie WHERE gruppe='Swing'")}   # 23.68 (U164)
        if not titel:
            return {}
        q = ",".join("?" * len(titel))
        for sid, netto, werte, ein, aus in st.execute(f"SELECT sid, netto_usd, werte, eroeffnet, geschlossen FROM labor_position "
                                                     f"WHERE status='geschlossen' AND sid IN ({q})", tuple(titel)):
            try:
                risk = float(json.loads(werte or "{}").get("risiko_usd") or SW.RISIKO_USD)
            except (ValueError, TypeError):
                risk = SW.RISIKO_USD
            e = out.setdefault(sid, {"titel": titel[sid], "R": [], "tage": [], "offen": 0})
            e["R"].append((netto or 0.0) / risk if risk > 0 else 0.0); e["tage"].append(((aus or ein) - ein) / 86_400)
        for sid, n in st.execute(f"SELECT sid, COUNT(*) FROM labor_position WHERE status='offen' AND sid IN ({q}) GROUP BY sid", tuple(titel)):
            out.setdefault(sid, {"titel": titel[sid], "R": [], "tage": [], "offen": 0})["offen"] = n
        for sid, t in titel.items():
            out.setdefault(sid, {"titel": t, "R": [], "tage": [], "offen": 0})
        for sid, e in out.items():
            e["aktiv"] = aktiv.get(sid, True)
    finally:
        st.close()
    return out


def swing_bericht(store: str) -> list:
    try:
        B = swing_bilanz(store)
    except Exception as e:
        return ["", f"Swing (U140): {type(e).__name__}: {e}"]
    if not B:
        return []
    z = ["", "Swing (U140), Zyklus (U141) und Extrem-Wende (U226) -- R = netto ÷ Risiko bis zum Stop (seit 23.68 Größe 10.000 USD, Risiko = 10.000 USD × "
         "Stop-Abstand; die alten Kennungen planten 100 USD); Vorwärtsbeleg braucht hier Monate bis Jahre (KONZEPT_Swing.md 7, "
         "KONZEPT_Zyklen.md 7):"]
    for sid, e in sorted(B.items(), key=lambda kv: (kv[1]["titel"], not kv[1].get("aktiv", True))):
        if not e.get("aktiv", True) and not e["R"] and not e["offen"]:
            continue                                                       # alte Regelversion ohne Trades: nichts zu berichten
        r = e["R"]; n = len(r)
        z.append(f"  {e['titel'][:40]:<41}" + (f"{n} Trades, Ø {sum(r) / n:+.2f} R, Summe {sum(r):+.1f} R, Treffer {sum(1 for x in r if x > 0) / n * 100:.0f} %, "
                                              f"Ø {sum(e['tage']) / n:.1f} Tage" if n else "noch keine geschlossenen Trades") + f" · offen {e['offen']}"
                 + ("" if e.get("aktiv", True) else f" · alte Regelversion ({sid.split('@')[-1]}"
                                                    + (")" if sid.startswith("wende_") else ", Größe nach Risiko)")))
    return z


def strategie_coin_bericht(store: str, d: dict, now: int) -> list:
    """23.68 (U161): Tabelle je Strategie und Coin im Textbericht; XMR vor und nach dem Gebührenwechsel getrennt."""
    try:
        st = F.store_connect(store); schema(st)
        try:
            Z = strategie_coin_tabelle(st, now, d.get("strategien"), d.get("geb_wechsel"))
        finally:
            st.close()
    except Exception as e:
        return ["", f"Je Strategie und Coin (U161): {type(e).__name__}: {e}"]
    if not Z:
        return []
    pc = lambda x: "—" if x is None else f"{x:+.3f} %"
    qq = lambda x: "—" if x is None else f"{x * 100:.0f} %"
    bp = lambda x: "—" if x is None else f"{x:.1f} bps"
    w = (d.get("geb_wechsel") or {}).get("XMR")
    teilung = (f"; XMR geteilt am Gebührenwechsel {_uhr(int(w['ab']))} nach dem Einstieg, „vor“ mit {_faktor_txt(w.get('vorher', 2.0))}"
               if w else "")
    z = ["", f"Je Strategie und Coin (U161; Summe über die Coins = Summe der Strategie{teilung}):",
         f"  {'Strategie':<34}{'Coin':<10}{'n (Bl.)':>10}{'Treffer':>9}{'Ø netto':>11}{'Summe USD':>12}{'Gebühren':>11}{'Abstand':>10}"]
    vorher = None
    for r in Z:
        name = (r["titel"][:28] + ("" if r["aktiv"] else " (alt)")) if r["sid"] != vorher else ""
        vorher = r["sid"]
        coin = r["coin"] + (f" {r['teil']}" if r["teil"] else "")
        nb = f"{r['n']} ({r.get('n_eff') or 0})"
        z.append(f"  {name:<34}{coin:<10}{nb:>10}{qq(r['treffer']):>9}{pc(r['mittel_pct']):>11}{r['summe_usd']:>+12.2f}"
                 f"{-(r['gebuehren_usd'] or 0):>+11.2f}{bp(r['slip_bps']):>10}")
    return z


def grid_tage_bericht(store: str, d: dict, tage: int = 7) -> list:
    """23.68 (U163): je Grid und Coin die letzten Tage -- Lose, realisiert, Änderung des Bestands, Tagesergebnis in USD und % des Kontos."""
    K = [k for k in d.get("strategien") or [] if k.get("name") in GRID_NAMEN and k.get("aktiv")]
    if not K:
        return []
    kap = f"{GRID_KAPITAL:,.0f}".replace(",", ".")
    z = ["", f"Grid je Coin und Tag (U163, letzte {tage} Tage; Tagesergebnis = Lose des Tages + Änderung des Bestands, in % des "
             f"{kap}-USD-Kontos):"]
    try:
        st = F.store_connect(store); schema(st)
        try:
            for k in K:
                T = grid_tage_tabelle(st, k["sid"])
                z.append(f"  {k['titel']}:")
                for c in sorted({r["coin"] for r in T}):
                    rs = [r for r in T if r["coin"] == c][-tage:]
                    z.append(f"    {c:<5}" + " · ".join(f"{time.strftime('%d.%m.', time.gmtime(r['tag']))} {r['lose']} {'Los' if r['lose'] == 1 else 'Lose'}, "
                                                     f"real. {r['realisiert']:+.2f}, "
                                                     f"Bestand {r['bestand_aend']:+.2f} = {r['ergebnis']:+.2f} USD ({r['pct']:+.2f} %)" for r in rs))
        finally:
            st.close()
    except Exception as e:
        z.append(f"  {type(e).__name__}: {e}")
    return z


def grid_bericht(d: dict) -> list:
    """23.40: Abschnitt „Grid-Bots“ des Textberichts -- je Grid und Coin Modus, Range, Lose, Bestandswert und Zähler; je Grid die Tage."""
    K = [k for k in d.get("strategien") or [] if k.get("name") in GRID_NAMEN and k.get("aktiv")]
    if not K:
        return []
    pc = lambda x, n=3: "—" if x is None else f"{x:+.{n}f} %"
    G = d.get("grids") or {}
    lose: dict = {}
    for o in d.get("offen") or []:
        if o.get("grid"):
            e = lose.setdefault(f"{o['sid']}|{o['coin']}", [0, 0.0, 0.0]); e[0] += 1; e[1] += o["notional"] or 0.0; e[2] += o["netto_usd"] or 0.0
    z = ["", "Grid-Bots (je Coin ein Konto über "
         f"{GRID_KAPITAL:,.0f} USD auf die Stufen verteilt; Tagesergebnis nach Bestandswert = realisiert + Änderung des unrealisierten Bestands):".replace(",", ".")]
    for k in K:
        t_txt = "—" if k.get("t") is None else f"{k['t']:+.1f}"
        z.append(f"  {k['titel']}: Summe {k['summe_usd']:+.2f} USD (realisiert {k.get('realisiert_usd', 0):+.2f}, Bestand {k.get('bestand_usd', 0):+.2f}) · "
                 f"{k['n']} Lose geschlossen · {k.get('n_eff', 0)} Tage · Ø/Tag {pc(k.get('tag_pct'))} · t {t_txt} · "
                 f"max DD {k['max_dd_usd']:.0f} USD (Tage) · Stufe {k['stufe']}")
        for c in COINS:
            g = G.get(f"{k['sid']}|{c}")
            if not g:
                z.append(f"    {c:<5} noch kein Takt")
                continue
            ln = lose.get(f"{k['sid']}|{c}", [0, 0.0, 0.0]); zl = g.get("zaehler") or {}
            ln[2] = ((k.get("je_coin") or {}).get(c) or {}).get("bestand_usd") or 0.0          # letzter Tagesstand (der Bericht hat keine Kurse)
            m = g.get("modus")
            if m == "aktiv":
                lage = (f"aktiv seit {_uhr(g.get('seit'))} · {ln[0]}/{g.get('n')} Lose ({ln[1]:,.0f} USD) · Range {g['unten']:.6g}–{g['oben']:.6g} · "
                        f"Schritt {g['schritt'] * 100:.2f} % · Notlinie {g['notlinie']:.6g}").replace(",", ".")
            elif m == "halten":
                H = g.get("halten") or {}
                lage = f"HÄLT {ln[0]} Lose seit {_uhr(H.get('start'))} · Extrem {H.get('extrem', 0):.6g} · Trailing-Stop {H.get('stop', 0):.6g} · {H.get('grund', '')}"
            elif m == "pause":
                lage = f"Pause bis {_uhr(g.get('pause_bis'))}"
            else:
                lage = "wartet: " + (g.get("hinweis") or "prüft die Range")
            z.append(f"    {c:<5}{lage} · Bestand {ln[2]:+.2f} USD · Runden {zl.get('runden', 0)}, aufgebaut {zl.get('aufgebaut', 0)}, "
                     f"nachgeführt {zl.get('nachgeführt', 0)}, gehalten {zl.get('halten', 0)}, Notausstiege {zl.get('notaus', 0)}")
    return z


# ------------------------------------------------------------------------------------------------ Selbsttest
# 23.61: Kennungen aller Strategien vor dem Swing-Einbau (Stand 23.60). Sie dürfen sich nicht ändern -- eine geänderte Kennung
# begänne eine neue Bilanz (Probe im Selbsttest). 23.62: dazu die sechs Swing-Kennungen aus 23.61 (die Zyklus-Strategien U141 kamen dazu).
SWING_KENNUNGEN_2361 = ("swing_trend@059e6156", "swing_ruecksetzer@8e863897", "swing_kompression@57d6ab42", "swing_gegenbewegung@3373d1f2",
                        "swing_zufall@c2f0c579", "swing_ruecksetzer_zufall@9e2287e8")
# 23.68 (U164): die neun Swing- und Zyklus-Kennungen bis 23.67 (Größe nach Risiko) und ab 23.68 (feste Größe, Regelfeld „groesse“)
SWING_KENNUNGEN_2362 = SWING_KENNUNGEN_2361 + ("zyklus_dip@f3159c50", "zyklus_dip_heiss@ae288bc8", "zyklus_dip_zufall@254d952e")
SWING_KENNUNGEN_2368 = ("swing_trend@5944f1f0", "swing_ruecksetzer@1c0ceb7c", "swing_kompression@7db88421", "swing_gegenbewegung@c31f73b9",
                        "swing_zufall@1bf9036a", "swing_ruecksetzer_zufall@9e6d0c0d", "zyklus_dip@a2794eea", "zyklus_dip_heiss@c64fc8b0",
                        "zyklus_dip_zufall@da594e22")
WENDE_KENNUNGEN_2383 = ("wende_rang@6fdc1dde", "wende_spanne@c1d92651")      # 23.83 (U226): Extrem-Wende nach Video
ALTE_KENNUNGEN = (
    "wale_folgen@6e9a1cf0", "wale_gegen@c960ec22", "leaderboard_folgen@4f2dc72b", "leaderboard_gegen@320ebc8f",
    "smartmoney_folgen@6cc466cb", "smartmoney_gegen@e3d3bf0d", "pool_folgen@44141cca", "pool_gegen@175c5bc6",
    "darwin_folgen@725eb009", "darwin_gegen@de10c0fa", "elite_folgen@8365f347", "elite_gegen@1238a0fb", "prognose_v1@10fd2bfd",
    "prognose_v2@665ee462", "prognose_fusion@40662765", "prognose_fusion_kosten@aefe5404", "empfehlung_limit@2759a930",
    "familie_grosskonten@f93293a5", "familie_trend@fb58cb40", "familie_momentum@872b2339", "familie_orderfluss@ba986905",
    "familie_funding@9cd08a0d", "familie_etf@7a7d2455", "familie_analog@d15abdcf", "familie_pool@9f8b230a",
    "familie_profi@02cbf702", "kaskade_umkehr@0fa8b424", "kaskade_fortsetzung@d5028807", "docht_fangen@94d7fc00",
    "magnet@3d305c09", "kaskade_kipppunkt@738d23ea", "funding_extrem@e30f9d59", "ausbruch_ruhe@0d5af6ad", "twap_druck@a0908d7c",
    "grid_long@ffe40137", "grid_short@d0c4d618", "zufall@b7e89107", "halten_long@3a4c3ace",
)


def _swing_markt(pfad_db: str, pfad_swing: str, tage: int = 330, hl_tage: int = 12, seed: int = 21, muster: str = "ausbruch") -> dict:
    """
    23.61 (U140): Markt für die Swing-Strategien (Coin SWG), minutengenau erzeugt. Tagesschlüsse bis zum Ausbruchstag B genau auf
    100 (dazwischen Brücken-Rauschen: kein 20-Tage-Ausbruch möglich), am Tag B +6 %, dann vier Tage je +2,5 %, am Tag B+5 ab 10:00 UTC
    ein Rutsch um 9 % binnen einer Stunde, danach seitwärts. swing.db: 30-min-Kerzen aus den Minuten (alle Tage) und Funding je 8 h;
    Hauptdatenbank: 1-min-Kerzen, Buch und Funding (ctx_bars) für die letzten hl_tage Tage.
    23.62 (U141): muster="dip" -- bis B auf 100, am Tag B −12 %, an B+1 −15 % (Tief), an B+2 −12 % (Erholung um 3 %), danach seitwärts
    (Z1 „Dip halten“ entscheidet am Schluss von B+2 auf Long).
    """
    rng = random.Random(seed)
    T0 = 1_788_134_400 - tage * 86_400                         # Tagesgrenze UTC; letzter Tag endet vor dem 30.08.2026
    B = tage - 8
    C = [0.0] * tage
    if muster == "dip":
        for k in range(B, tage):
            C[k] = -0.12
        C[B + 1] = -0.15
    else:
        for k, v in ((B, 0.06), (B + 1, 0.085), (B + 2, 0.11), (B + 3, 0.135), (B + 4, 0.16)):
            C[k] = v
        for k in range(B + 5, tage):
            C[k] = 0.07
    lp = math.log(100.0); minuten = []
    for d in range(tage):
        a = C[d - 1] if d else 0.0; b = C[d]
        w = 0.0; brueck = []
        for i in range(1440):
            w += rng.gauss(0, 0.0002); brueck.append(w)
        for i in range(1440):
            rausch = brueck[i] - brueck[-1] * (i + 1) / 1440                  # Brücke: endet genau auf b
            if d == B + 5 and muster != "dip":
                f = 0.0 if i < 600 else (min(1.0, (i - 599) / 60.0))
                x = a + (b - a) * f
            else:
                x = a + (b - a) * (i + 1) / 1440
            minuten.append((T0 + d * 86_400 + i * 60, lp + x + rausch))
    con = sqlite3.connect(pfad_db)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    rows = []; book = []; ctx = []; k30 = []; vorher = math.log(100.0); t_hl = T0 + (tage - hl_tage) * 86_400
    akt = None
    for t, x in minuten:
        o = math.exp(vorher); c = math.exp(x); vorher = x
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.00005))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.00005)))
        if t >= t_hl:
            rows.append((t, "SWG", o, hi, lo, c, 1000.0, 10))
            book.append((t + 59, "SWG", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
            ctx.append((t, "SWG", c, c, c, 0.00001, 1e6, 0.0))
        b30 = t // 1800 * 1800
        if akt is None or akt[0] != b30:
            if akt:
                k30.append(tuple(akt))
            akt = [b30, o, hi, lo, c, 1.0]
        else:
            akt[2] = max(akt[2], hi); akt[3] = min(akt[3], lo); akt[4] = c
    k30.append(tuple(akt))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    con.commit(); con.close()
    sw = SW.verbinden(pfad_swing)
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)", [("SWG", *k) for k in k30])
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)", [("SWG", T0 + k * 8 * 3600, 0.0001) for k in range(tage * 3)])
    sw.close()
    return {"T0": T0, "B": B, "tage": tage, "k30": k30}


def _swing_selbsttest(tmp: str, ok) -> None:
    """23.61 (U140): Swing im Labor auf dem synthetischen Markt -- Einstieg am Tag nach dem Ausbruch, Größe nach Risiko, Stop zieht nur
    nach oben, Ausstieg am Rutsch, Funding über Tage, Neustarts, gleiche Tage wie die Vorprüfung, veraltete Tageskerzen, Bericht in R."""
    db = os.path.join(tmp, "swing_m.db"); sp = os.path.join(tmp, "swing_f.db"); sw = os.path.join(tmp, "swing.db")
    M = _swing_markt(db, sw)
    T0, B, tage = M["T0"], M["B"], M["tage"]
    nur = ("swing_trend", "swing_ruecksetzer", "swing_kompression", "swing_gegenbewegung", "swing_zufall", "swing_ruecksetzer_zufall")
    import hl_anker
    anker_alt = hl_anker.jetzt
    hl_anker.jetzt = lambda con_, coin_, now_: {}             # der Heatmap-Anker gehört nicht zu dieser Probe (spart 30 s)
    try:
        L = None; fehler = []; t = T0 + (B - 2) * 86_400; i = 0
        while t < T0 + tage * 86_400 - 900:
            if L is None or i % 100 == 0:
                if L is not None:
                    fehler += L.fehler
                L = Labor(db, sp, coins=("SWG",), nur=nur, adressfluss=os.path.join(tmp, "af_sw.db"), swing=sw)       # Neustart-Probe
            L.zyklus(t)
            t += 900; i += 1
        fehler += L.fehler
    finally:
        hl_anker.jetzt = anker_alt
    st = F.store_connect(sp)
    tr = st.execute("SELECT p.eroeffnet, p.geschlossen, p.seite, p.notional, p.sl, p.grund_aus, p.funding, p.werte, p.netto_usd, p.preis_ein "
                    "FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='swing_trend' ORDER BY p.eroeffnet").fetchall()
    stops = [r[0] for r in st.execute("SELECT e.preis FROM labor_ereignis e JOIN labor_strategie s ON s.sid=e.sid "
                                       "WHERE s.name='swing_trend' AND e.art='stop' ORDER BY e.ts")]
    st.close()
    K = {"ts": np.array([k[0] for k in M["k30"]], dtype=np.int64), "o": np.array([k[1] for k in M["k30"]]), "h": np.array([k[2] for k in M["k30"]]),
         "l": np.array([k[3] for k in M["k30"]]), "c": np.array([k[4] for k in M["k30"]]), "v": np.ones(len(M["k30"]))}
    D = SW.daten_aufbereiten(K, None)
    R1 = SW.STRATEGIEN["swing_trend"]
    hist = [x for x in SW.lauf("SWG", R1, D["T"], None, D["I"], 30, D["T"]["nd"] - 2)["trades"] if x["e"] >= B - 1]
    sigB = float(D["I"].sig[B]); px0 = 100 * math.exp(0.06)
    soll_nt = NOTIONAL                                                  # 23.68 (U164): feste Größe, Risiko = 10.000 × Stop-Abstand
    soll_risk = NOTIONAL * (1 - math.exp(-2 * sigB))
    e_tag = (tr[0][0] - T0) // 86_400 if tr else None; x_tag = (tr[0][1] - T0) // 86_400 if tr and tr[0][1] else None
    risk = json.loads(tr[0][7] or "{}").get("risiko_usd") if tr else None
    ok("Swing im Labor: Einstieg nach dem Ausbruch, Größe 10.000 USD mit risiko_usd = 10.000 × Stop-Abstand (U164), Ausstieg am Rutsch",
       len(tr) == 1 and tr[0][2] == "long" and e_tag == B + 1 and 0 <= tr[0][0] - (T0 + (B + 1) * 86_400) <= 900
       and abs(tr[0][3] / soll_nt - 1) < 1e-9 and x_tag == B + 5 and "Stop" in (tr[0][5] or "") and abs((risk or 0) - soll_risk) < 1.0,
       f"{len(tr)} Trade(s): {tr[0][2] if tr else '—'} am Tag B+{(e_tag - B) if tr else '—'} um {_uhr(tr[0][0]) if tr else '—'}, Notional "
       f"{tr[0][3] if tr else 0:,.0f} USD (Soll {soll_nt:,.0f}), Ausstieg Tag B+{(x_tag - B) if x_tag else '—'} "
       f"„{tr[0][5] if tr else '—'}“, Risiko {risk} (Soll {soll_risk:.2f} bei σ_Tag {sigB * 100:.2f} %)")
    ok("Swing: Stop zieht nur nach oben, einmal je Tag", len(stops) == 4 and all(b > a for a, b in zip(stops, stops[1:])),
       f"{len(stops)} Nachzieh-Stops: {', '.join(f'{x:.2f}' for x in stops)}")
    ok("Swing: dieselben Tage wie die Vorprüfung auf der Historie (Einstieg, Ausstieg, Zahl der Nachzieh-Stops)",
       len(hist) == 1 and hist[0]["e"] == e_tag and hist[0]["x_tag"] == x_tag and hist[0]["grund"] == "Nachzieh-Stop" and hist[0]["nachgezogen"] == len(stops),
       f"Historie: Einstieg Tag B+{(hist[0]['e'] - B) if hist else '—'}, Ausstieg Tag B+{(hist[0]['x_tag'] - B) if hist else '—'} „{hist[0]['grund'] if hist else '—'}“, "
       f"{hist[0]['nachgezogen'] if hist else '—'} Nachzieh-Stops")
    ok("Swing: Funding über mehrere Tage (Long zahlt), keine Laufzeitfehler, Neustarts", tr and (tr[0][6] or 0) > 0 and not fehler,
       f"Funding {tr[0][6] if tr else 0:.4f} USD über {(x_tag - e_tag) if tr else 0} Tage; Fehler: {'; '.join(fehler[-2:]) or 'keine'}")
    # veraltete Tageskerzen: zwei Tage nach dem Datenende -- kein Einstieg, Tafel sagt „veraltet“
    S1 = next(s_ for s_ in strategien() if s_["name"] == "swing_trend")
    W_alt = SW.labor_daten(sw, "SWG", T0 + (tage + 2) * 86_400)
    E_alt = {"swing": W_alt, "preis": {"mid": 100.0}}
    a_alt = sig_swing(S1, E_alt, "SWG", T0 + (tage + 2) * 86_400 + 60, {})
    # Einstieg nur einmal je Tag und nur binnen 6 h nach dem Schluss
    W_b = SW.labor_daten(sw, "SWG", T0 + (B + 1) * 86_400 + 60)
    E_b = {"swing": W_b, "preis": {"mid": px0}}
    a1 = sig_swing(S1, E_b, "SWG", T0 + (B + 1) * 86_400 + 60, {})
    a2 = sig_swing(S1, E_b, "SWG", T0 + (B + 1) * 86_400 + 60, {"letzter_einstieg": T0 + (B + 1) * 86_400 + 30})
    a3 = sig_swing(S1, E_b, "SWG", T0 + (B + 1) * 86_400 + 7 * 3600, {})
    txt = status_text(S1, E_alt, T0 + (tage + 2) * 86_400 + 60, {})
    ok("Swing: veraltete Tageskerzen ohne Einstieg; einmal je Tag; höchstens 6 h nach dem Schluss",
       not W_alt["frisch"] and not a_alt and "veraltet" in txt and len(a1) == 1 and a1[0]["seite"] == "long" and not a2 and not a3,
       f"Tafel: „{txt}“; Tag nach dem Ausbruch: {[x['seite'] for x in a1]}, nach einem Einstieg {a2}, nach 7 h {a3}")
    B_ = swing_bilanz(sp)
    e_ = next((v for v in B_.values() if v["titel"] == "Swing: Trend-Ausbruch"), None)
    zeilen = swing_bericht(sp)
    ok("Swing: Bilanz in R im Labor-Bericht", e_ and len(e_["R"]) == 1 and abs(e_["R"][0] - tr[0][8] / risk) < 1e-9 and any("Trend-Ausbruch" in z_ for z_ in zeilen),
       (f"R {e_['R'][0]:+.2f}" if e_ and e_["R"] else "R —") + "; " + next((z_.strip() for z_ in zeilen if "Trend-Ausbruch" in z_), "—"))
    # Signal-Ausstieg am Tagesschluss (hier erzwungen am Schluss von B+2): Markt-Ausstieg ohne Pause, im selben Takt neu entschieden --
    # der Trend hält an, also sofort wieder Long (in der Historie: frei_ab = Tag des Ausstiegssignals)
    sp2 = os.path.join(tmp, "swing_f2.db"); nf_alt = SW.nachfuehren
    tag_aus = T0 + (B + 2) * 86_400

    def nf_test(R_, T_, I_, d_, pos_):
        if d_ >= pos_["e"] and int(T_["tag_ts"][d_]) == tag_aus:
            return {"aus": True, "grund": "Test-Ausstieg am Schluss von B+2"}
        return nf_alt(R_, T_, I_, d_, pos_)
    hl_anker.jetzt = lambda con_, coin_, now_: {}
    SW.nachfuehren = nf_test
    try:
        L2 = Labor(db, sp2, coins=("SWG",), nur=("swing_trend",), adressfluss=os.path.join(tmp, "af_sw2.db"), swing=sw)
        t = T0 + (B + 1) * 86_400 - 1800
        while t < T0 + (B + 3) * 86_400 + 3 * 3600:
            L2.zyklus(t); t += 900
        fehler2 = list(L2.fehler)
    finally:
        SW.nachfuehren = nf_alt; hl_anker.jetzt = anker_alt
    st = F.store_connect(sp2)
    tr2 = st.execute("SELECT p.eroeffnet, p.geschlossen, p.seite, p.grund_aus, p.art_aus, p.status FROM labor_position p JOIN labor_strategie s "
                     "ON s.sid=p.sid WHERE s.name='swing_trend' ORDER BY p.eroeffnet").fetchall()
    st.close()
    ok("Swing: Signal-Ausstieg am Tagesschluss zum Marktpreis, ohne Pause, im selben Takt neu entschieden",
       len(tr2) == 2 and "Test-Ausstieg" in (tr2[0][3] or "") and "Markt" in (tr2[0][4] or "") and tr2[0][1] is not None
       and 0 <= tr2[0][1] - (T0 + (B + 3) * 86_400) <= 900 and tr2[1][0] == tr2[0][1] and tr2[1][2] == "long" and tr2[1][5] == "offen" and not fehler2,
       f"{len(tr2)} Positionen: 1. geschlossen {_uhr(tr2[0][1]) if tr2 and tr2[0][1] else '—'} „{tr2[0][3] if tr2 else '—'}“ ({tr2[0][4] if tr2 else '—'}); "
       f"2. eröffnet {_uhr(tr2[1][0]) if len(tr2) > 1 else '—'} {tr2[1][2] if len(tr2) > 1 else ''}; Fehler: {'; '.join(fehler2[-2:]) or 'keine'}")
    _swing_alt_selbsttest(tmp, ok, db, sw, T0, B)                              # 23.68 (U164)


def _swing_alt_selbsttest(tmp: str, ok, db: str, sw: str, T0: int, B: int) -> None:
    """23.68 (U164): eine offene Position der alten Kennung (Größe nach Risiko) wird beim ersten Takt mit den neuen Regeln zum Marktpreis
    geschlossen („Regelversion abgelöst“); die alte Kennung wird inaktiv, die neue aktiv."""
    sp3 = os.path.join(tmp, "swing_alt.db")
    st = F.store_connect(sp3); schema(st)
    alt_sid = "swing_trend@059e6156"
    regeln_alt = dict(dict(SW.STRATEGIEN["swing_trend"], h=24), v=1)
    st.execute("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)", (alt_sid, "swing_trend", "Swing: Trend-Ausbruch", "Swing", _j(regeln_alt),
                                                                     "alte Regelversion (Größe nach Risiko)", T0))
    t_ein = T0 + (B + 1) * 86_400
    st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, sl, tp, "
               "ablauf, grund, werte, folge, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) "
               "VALUES (?,?,?,'offen',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,0,0)",
               (alt_sid, "SWG", "long", t_ein, 106.0, 2700.0, 2700.0 / 106.0, "Markt (Taker)", 2700.0 * GEB_TAKER, 1.0, 60.0, None,
                t_ein + 30 * 86_400, "Test: alte Regelversion", _j({"risiko_usd": 100.0}), None, t_ein + 60, t_ein + 60, t_ein))
    st.commit(); st.close()
    import hl_anker
    anker_alt = hl_anker.jetzt
    hl_anker.jetzt = lambda con_, coin_, now_: {}
    try:
        L3 = Labor(db, sp3, coins=("SWG",), nur=("swing_trend",), adressfluss=os.path.join(tmp, "af_sw3.db"), swing=sw)
        t3 = T0 + (B + 2) * 86_400 + 3600
        L3.zyklus(t3)
        fehler3 = list(L3.fehler)
    finally:
        hl_anker.jetzt = anker_alt
    st = F.store_connect(sp3)
    pos = st.execute("SELECT status, grund_aus, art_aus, geschlossen FROM labor_position WHERE sid=?", (alt_sid,)).fetchone()
    akt = dict(st.execute("SELECT sid, aktiv FROM labor_strategie WHERE name='swing_trend'").fetchall())
    ev = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE sid=? AND art='geschlossen' AND text LIKE '%Regelversion abgelöst%'", (alt_sid,)).fetchone()[0]
    st.close()
    neu_sid = next(s_["sid"] for s_ in strategien() if s_["name"] == "swing_trend")
    ok("Swing (U164): offene Position der alten Kennung beim Wechsel zum Marktpreis geschlossen („Regelversion abgelöst“), alte inaktiv, "
       "neue aktiv", pos and pos[0] == "geschlossen" and pos[1] == "Regelversion abgelöst" and "Markt" in (pos[2] or "") and pos[3] == t3
       and akt.get(alt_sid) == 0 and akt.get(neu_sid) == 1 and neu_sid != alt_sid and ev == 1 and not fehler3,
       f"Position {pos}, Kennungen {akt}, Ereignis {ev}, Fehler {'; '.join(fehler3[-2:]) or 'keine'}")


def _u160_selbsttest(tmp: str, db: str, ok) -> None:
    """23.68 (U160): XMR mit normaler Gebühr -- Sätze wie BTC, Trade über den Wechsel (Einstieg doppelt gespeichert, Ausstieg normal),
    Zeitpunkt des Wechsels im Labor-Zustand (einmal), Kostenschwelle der Fusion für XMR unverändert doppelt, Gebühren-Prüfung nennt ihn."""
    ok("Gebühr XMR wie BTC und ETH (U160): Taker und Maker gleich, keine Ausnahme mehr",
       gebuehr("XMR", GEB_TAKER) == gebuehr("BTC", GEB_TAKER) == GEB_TAKER and gebuehr("XMR", GEB_MAKER) == GEB_MAKER and not GEB_FAKTOR
       and GEB_FAKTOR_ALT == {"XMR": 2.0}, f"Taker XMR {gebuehr('XMR', GEB_TAKER) * 100:.3f} %, BTC {gebuehr('BTC', GEB_TAKER) * 100:.3f} %")
    sp = os.path.join(tmp, "geb.db")
    Lg = Labor(db, sp, coins=("XMR",), nur=("zufall",), adressfluss=os.path.join(tmp, "af_geb.db"))
    st = F.store_connect(sp); schema(st)
    t_w = 1_790_100_000
    Lg._registrieren(st, t_w); w1 = geb_wechsel(st)
    Lg._registriert = False; Lg._registrieren(st, t_w + 3600); w2 = geb_wechsel(st)
    sid = next(iter(Lg.nach_sid))
    menge = 10_000.0 / 300.0
    cur = st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, "
                     "geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) VALUES (?,?,?,'offen',?,?,?,?,?,?,?,?,?,0,?,0,0)",
                     (sid, "XMR", "long", t_w - 600, 300.0, 10_000.0, menge, "Markt (Taker)", 10_000.0 * GEB_TAKER * 2.0, 1.0, t_w, t_w, t_w))
    p = Lg._pos(st, cur.lastrowid)
    netto = Lg._schliessen(st, p, 303.0, "Markt (Taker)", GEB_TAKER, 1.0, "Test", t_w + 600)
    g_aus = st.execute("SELECT gebuehr_aus, gebuehr_ein FROM labor_position WHERE id=?", (cur.lastrowid,)).fetchone()
    st.commit(); st.close()
    soll_aus = menge * 303.0 * GEB_TAKER
    ok("Trade über den Wechsel (U160): Einstieg doppelt (gespeichert), Ausstieg normal; Wechsel einmal festgehalten (×2 → ×1, Zeitpunkt bleibt)",
       abs(g_aus[0] - soll_aus) < 1e-9 and abs(g_aus[1] - 9.0) < 1e-9 and abs(netto - ((303.0 - 300.0) * menge - 9.0 - soll_aus)) < 1e-9
       and w1 == {"XMR": {"vorher": 2.0, "jetzt": 1.0, "ab": t_w}} and w2 == w1,
       f"Gebühr Ein {g_aus[1]:.4f} / Aus {g_aus[0]:.4f} USD (Soll {soll_aus:.4f}), netto {netto:+.4f}; Wechsel {w1}")
    import hl_fusion
    tk_x, mk_x = hl_fusion.gebuehren("XMR"); tk_b, mk_b = hl_fusion.gebuehren("BTC")
    ok("Kostenschwelle der Fusion folgt dem Labor (U160; seit 23.85 nach dem Urteil U108): XMR wie BTC mit den normalen Sätzen",
       abs(tk_x - gebuehr("XMR", GEB_TAKER)) < 1e-15 and abs(mk_x - gebuehr("XMR", GEB_MAKER)) < 1e-15 and abs(tk_x - GEB_TAKER) < 1e-15
       and abs(mk_x - GEB_MAKER) < 1e-15 and tk_b == GEB_TAKER and mk_b == GEB_MAKER,
       f"Fusion XMR Taker {tk_x * 100:.3f} %, BTC {tk_b * 100:.3f} %")
    fdb = os.path.join(tmp, "fills_geb.db")
    c_ = sqlite3.connect(fdb)
    c_.execute("CREATE TABLE lb_fills (addr TEXT, tid INTEGER, ts INTEGER, coin TEXT, fee REAL, notional REAL, dir TEXT)")
    jetzt_ = t_w + 86_400
    c_.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?)", [("0xa", i, jetzt_ - 3600, "XMR", 1.2, 10_000.0, "Open Long") for i in range(40)]
                   + [("0xb", 100 + i, jetzt_ - 3600, "BTC", 2.55, 10_000.0, "Open Long") for i in range(40)])
    c_.commit(); c_.close()
    gp = gebuehren_pruefung(fdb, jetzt_, 3, w1) or ""
    ok("Gebühren-Prüfung (U160) nennt „Labor rechnet ×1,0 seit …“ mit dem Zeitpunkt des Wechsels und dem alten Faktor",
       f"Labor rechnet ×1,0 seit {time.strftime('%d.%m.%Y %H:%M', time.localtime(t_w))} (vorher ×2,0)" in gp and "XMR ≈ ×0,5" in gp, gp)


def _tabellen_selbsttest(tmp: str, ok) -> None:
    """23.68: U161 (je Strategie und Coin, XMR geteilt am Gebührenwechsel) und U163 (Grid je Coin und Tag, Größe je Trade) auf einem
    Speicher mit bekannten Trades und Bestandsständen."""
    sp = os.path.join(tmp, "tabellen.db")
    st = F.store_connect(sp); schema(st)
    t0 = 1_790_000_000 // 86_400 * 86_400
    ab = t0 + 3 * 86_400 + 5_000                                            # Gebührenwechsel
    st.execute("INSERT INTO labor_zustand VALUES ('geb_wechsel', ?)", (_j({"XMR": {"vorher": 2.0, "jetzt": 1.0, "ab": ab}}),))
    st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t0),))
    st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({c: t0 for c in COINS}),))
    sa = "probe_a@00000001"; sg = "grid_long@00000002"
    st.execute("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)", (sa, "probe_a", "Probe A", "Händler", _j({"h": 4, "v": 1}), "Probe", t0))
    st.execute("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,1)", (sg, "grid_long", "Grid Long", "Grid", _j({"h": 24, "v": 1}), "Probe", t0))
    rng = random.Random(161); zeilen = []

    def trade(sid, coin, ein, aus, netto, nt=NOTIONAL, geb=9.0, slip=(1.5, 2.0)):
        zeilen.append((sid, coin, "long", "geschlossen", ein, 100.0, nt, nt / 100.0, "Markt (Taker)", geb / 2, slip[0], None, None, ein + 3600, "Probe",
                       "{}", None, aus, aus, 0.0, aus, 0.5, 0.5, aus, 100.0 * (1 + netto / nt), "Markt (Taker)", geb / 2, slip[1], "Probe",
                       netto + geb, netto, netto / nt * 100))
    for i in range(12):
        c = ("BTC", "ETH", "XMR")[i % 3]
        e = t0 + 6 * 3600 * i + 600
        trade(sa, c, e, e + 1800, round(rng.uniform(-60, 60), 2), geb=round(rng.uniform(5, 18), 2))
    trade(sa, "XMR", ab - 1, ab + 1800, 12.34, geb=18.0)                     # eine Sekunde vor dem Wechsel eröffnet: „vor“
    trade(sa, "XMR", ab, ab + 1800, -7.89, geb=9.0)                          # genau am Wechsel: „nach“
    for d_ in range(5):                                                       # Grid: Lose an fünf Tagen in BTC und XMR
        for c in ("BTC", "XMR"):
            for j in range(1 + (d_ + (c == "XMR")) % 3):
                e = t0 + d_ * 86_400 + 3600 * (j + 1)
                trade(sg, c, e, e + 900, round(rng.uniform(1, 6), 2), nt=1666.67, geb=round(rng.uniform(0.3, 0.9), 2), slip=(0.0, 0.0))
    st.executemany("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, sl, tp, "
                   "ablauf, grund, werte, folge, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct, geschlossen, preis_aus, art_aus, "
                   "gebuehr_aus, slip_aus, grund_aus, brutto_usd, netto_usd, netto_pct) VALUES (" + ",".join("?" * 32) + ")", zeilen)
    # Bestandsstände: BTC an den Tagen 0, 1, 3, 4 (Tag 2 ohne Stand: seine Änderung geht an Tag 3), XMR an den Tagen 1 und 4
    stand = {("BTC", 0): -12.5, ("BTC", 1): -30.0, ("BTC", 3): 8.25, ("BTC", 4): -4.0, ("XMR", 1): 6.0, ("XMR", 4): -22.75}
    st.executemany("INSERT INTO labor_grid_tag VALUES (?,?,?,?,?,?,?)", [(sg, c, t0 + d_ * 86_400, u, 3, 100.0, t0 + d_ * 86_400 + 80_000)
                                                                        for (c, d_), u in stand.items()])
    st.commit()
    now = t0 + 6 * 86_400
    K = kennzahlen(st, now)
    w = geb_wechsel(st)
    Z = strategie_coin_tabelle(st, now, K, w)
    ka = next(k for k in K if k["sid"] == sa); kg = next(k for k in K if k["sid"] == sg)
    za = [z_ for z_ in Z if z_["sid"] == sa]; zg = [z_ for z_ in Z if z_["sid"] == sg]
    xv = next((z_ for z_ in za if z_["coin"] == "XMR" and z_["teil"] == "vor"), {}); xn = next((z_ for z_ in za if z_["coin"] == "XMR" and z_["teil"] == "nach"), {})
    n_vor = sum(1 for z_ in zeilen if z_[0] == sa and z_[1] == "XMR" and z_[4] < ab); n_nach = sum(1 for z_ in zeilen if z_[0] == sa and z_[1] == "XMR" and z_[4] >= ab)
    ok("Je Strategie und Coin (U161): Summe und Gebühren über die Coins = Strategie (auf den Cent), auch beim Grid mit Bestand; XMR genau "
       "am Wechsel geteilt (eine Sekunde davor „vor“, genau am Wechsel „nach“)",
       abs(sum(z_["summe_usd"] for z_ in za) - ka["summe_usd"]) < 0.005 and abs(sum(z_["gebuehren_usd"] for z_ in za) - ka["gebuehren_usd"]) < 0.005
       and abs(sum(z_["summe_usd"] for z_ in zg) - kg["summe_usd"]) < 0.005 and abs(sum(z_["gebuehren_usd"] for z_ in zg) - kg["gebuehren_usd"]) < 0.005
       and {z_["coin"] for z_ in za} == {"BTC", "ETH", "XMR"} and xv.get("n") == n_vor and xn.get("n") == n_nach and n_nach == 1
       and abs(xn.get("summe_usd", 0) - (-7.89)) < 1e-9 and not any(z_["coin"] == "XMR" and not z_["teil"] for z_ in Z),
       f"A: Coins {sum(z_['summe_usd'] for z_ in za):+.2f} / Strategie {ka['summe_usd']:+.2f}; Grid {sum(z_['summe_usd'] for z_ in zg):+.2f} / "
       f"{kg['summe_usd']:+.2f}; XMR vor {xv.get('n')} (Soll {n_vor}), nach {xn.get('n')} (Soll {n_nach})")
    G = grid_tage_tabelle(st, sg); gt = grid_tage(st, sg)
    je = {(c, int(t)): v for c, L_ in gt["je_coin"].items() for t, v in L_}
    hand_lose = {}
    for z_ in zeilen:
        if z_[0] == sg:
            hand_lose[(z_[1], z_[17] // 86_400 * 86_400)] = hand_lose.get((z_[1], z_[17] // 86_400 * 86_400), 0) + 1
    btc3 = next((r for r in G if r["coin"] == "BTC" and r["tag"] == t0 + 3 * 86_400), {})
    ok("Grid je Coin und Tag (U163): Tageszeile = Lose des Tages + Änderung des Bestands, auf den Cent gleich grid_tage (Stufe, t); Tag ohne "
       "Stand gibt seine Änderung weiter; Summe über die Tage = Strategiesumme; Lose je Tag von Hand",
       G and all(abs(r["ergebnis"] - je[(r["coin"], r["tag"])]) < 0.005 and abs(r["ergebnis"] - (r["realisiert"] + r["bestand_aend"])) < 0.005
                 and r["lose"] == hand_lose.get((r["coin"], r["tag"]), 0) and abs(r["pct"] - r["ergebnis"] / GRID_KAPITAL * 100) < 1e-3 for r in G)
       and len(G) == len(je) and abs(sum(r["ergebnis"] for r in G) - kg["summe_usd"]) < 0.005
       and abs(btc3.get("bestand_aend", 0) - (8.25 - (-30.0))) < 1e-9,
       f"{len(G)} Zeilen, Summe {sum(r['ergebnis'] for r in G):+.2f} gegen Strategie {kg['summe_usd']:+.2f}; BTC Tag 3 Bestand {btc3.get('bestand_aend')}")
    st.close()
    A = trades_antwort(sp, sg, None, 500); A2 = trades_antwort(sp, sa, None, 500)
    st = F.store_connect(sp)
    nt = {(r[0], r[1]): r[2] for r in st.execute("SELECT sid, id, notional FROM labor_position")}
    ids = {r[0]: r[1] for r in st.execute("SELECT id, sid FROM labor_position")}
    st.close()
    ok("Trades-Tabelle (U163): Größe je Zeile = gespeicherte Größe (Los 1.666,67 USD, sonst 10.000); Grid-Tabelle nur bei einer Grid-Strategie",
       A["trades"] and all(abs(t_["notional"] - nt[(ids[t_["id"]], t_["id"])]) < 1e-9 for t_ in A["trades"] + A2["trades"])
       and all(abs(t_["notional"] - 1666.67) < 1e-9 for t_ in A["trades"]) and A.get("grid_tage") and "grid_tage" not in A2
       and A["grid_kapital"] == GRID_KAPITAL, f"{len(A['trades'])} Lose, {len(A2['trades'])} Trades, Grid-Tabelle {len(A.get('grid_tage') or [])} Zeilen")


def _wende_markt(pfad_db: str, pfad_swing: str, tage: int = 700, seed: int = 41, stop_sofort: bool = False) -> dict:
    """
    23.83 (U226): Markt für die Extrem-Wende (BTC; ETH als zweiter Coin ohne Wende): swing.db mit den 30-min-Kerzen eines erfundenen
    Wegs (hl_wende._weg) und Funding je 8 h; Hauptdatenbank mit 1-min-Kerzen, Buch und Funding rund um ein Signal der Lesart Rang
    (ein Tag davor bis zwei Tage danach). Die Minutenkerzen folgen den 30-min-Schlüssen. stop_sofort: von 10 bis 15 min nach dem
    Schluss liegt BTC jenseits des Stops, danach wieder auf dem Weg (Probe „kein zweiter Einstieg auf dasselbe Signal“).
    """
    T0 = 1_756_684_800 - tage * 86_400                         # 01.09.2025 minus tage, 8-h-Grenze
    K = WE._weg(seed, tage=tage, start=T0, p0=60_000.0)
    D = WE.daten(K)
    sig_ = [x for x in WE.signale(D, WE.REGELN, "rang") if x["k_ts"] >= T0 + 620 * 86_400 and x.get("j0") is not None and not x.get("kein")]
    if not sig_:
        raise RuntimeError("kein Signal im Testweg")
    s_ = sig_[0]; t_s = s_["t_flip"]
    con = sqlite3.connect(pfad_db)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    rows = []; book = []; ctx = []
    a = int(np.searchsorted(K["ts"], t_s - 86_400)); b = int(np.searchsorted(K["ts"], t_s + 2 * 86_400))
    for j in range(a, b):
        t30 = int(K["ts"][j]); o_, c_ = float(K["o"][j]), float(K["c"][j])
        for i in range(30):
            t = t30 + 60 * i; po = o_ + (c_ - o_) * i / 30.0; pc = o_ + (c_ - o_) * (i + 1) / 30.0
            if stop_sofort and t_s + 600 <= t < t_s + 900:
                po = pc = s_["stop"] * (1.01 if s_["seite"] == "short" else 0.99)
            for coin, f in (("BTC", 1.0), ("ETH", 0.05)):
                rows.append((t, coin, po * f, max(po, pc) * f * 1.00002, min(po, pc) * f * 0.99998, pc * f, 1000.0, 10))
                book.append((t + 59, coin, pc * f * (1 - 1e-4), pc * f * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
                ctx.append((t, coin, pc * f, pc * f, pc * f, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    con.commit(); con.close()
    sw = SW.verbinden(pfad_swing)
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                  [("BTC", int(t), float(o), float(h), float(l), float(c), 1.0) for t, o, h, l, c in zip(K["ts"], K["o"], K["h"], K["l"], K["c"])])
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)", [("BTC", T0 + k * 8 * 3600, 0.0001) for k in range(tage * 3)])
    sw.close()
    return {"T0": T0, "t_schluss": t_s, "sig": {la: WE.signal_an(D, s_["T"], WE.REGELN, la) for la in WE.LESARTEN}, "K": K}


def _wende_selbsttest(tmp: str, ok) -> None:
    """23.83 (U226, KONZEPT_Wende.md 5 und 6): Extrem-Wende im Labor -- Einstieg nach dem 8-h-Schluss mit dem Stop der Historie und Ziel 1R,
    nur BTC, einmal je Signal, nicht nach 60 min, nicht mit offener Position, nicht jenseits des Stops; Bilanz in R."""
    db = os.path.join(tmp, "wende_m.db"); sp = os.path.join(tmp, "wende_f.db"); sw = os.path.join(tmp, "wende_swing.db")
    WE._LABOR_CACHE.clear()
    M = _wende_markt(db, sw); t_s = M["t_schluss"]
    import hl_anker
    anker_alt = hl_anker.jetzt
    hl_anker.jetzt = lambda con_, coin_, now_: {}
    try:
        L = Labor(db, sp, coins=("BTC", "ETH"), nur=("wende_rang", "wende_spanne"), adressfluss=os.path.join(tmp, "af_we.db"), swing=sw)
        t = t_s - 1800
        while t <= t_s + 3 * 3600:
            L.zyklus(t); t += 300
        fehler = list(L.fehler)
    finally:
        hl_anker.jetzt = anker_alt
    st = F.store_connect(sp)
    pos = st.execute("SELECT s.name, p.coin, p.seite, p.eroeffnet, p.sl, p.tp, p.preis_ein, p.werte, p.ablauf FROM labor_position p "
                     "JOIN labor_strategie s ON s.sid=p.sid ORDER BY p.eroeffnet").fetchall()
    ohne_stop = [r[0] for r in pos if r[0].startswith("wende_") and (r[4] is None or r[5] is None)]
    st.close()
    soll = {la: M["sig"][la] for la in WE.LESARTEN if M["sig"][la]}
    probl = []
    for la, sg in soll.items():
        name = f"wende_{la}"
        p_ = [r for r in pos if r[0] == name]
        if len(p_) != 1:
            probl.append(f"{name}: {len(p_)} Positionen"); continue
        _, coin, seite, er, sl, tp, pin, werte, ablauf = p_[0]
        m = (tp + sl) / 2.0; w_ = json.loads(werte or "{}")
        if not (coin == "BTC" and seite == sg["seite"] and t_s <= er <= t_s + 3600 and abs(sl - sg["stop"]) < 1e-6 * sg["stop"]
                and abs(m / pin - 1) < 5e-4 and abs(w_.get("risiko_usd", 0) - NOTIONAL * abs(m - sl) / m) < 0.05
                and ablauf == er + 120 * 86_400):
            probl.append(f"{name}: {coin} {seite} {er - t_s} s nach dem Schluss, Stop {sl} (Soll {sg['stop']}), Mitte {m} gegen {pin}, "
                         f"Risiko {w_.get('risiko_usd')}, Ablauf {ablauf - er if ablauf else None}")
    andere = [r for r in pos if r[0].replace("wende_", "") not in soll or r[1] != "BTC"]
    S_r = next(s_ for s_ in strategien() if s_["name"] == "wende_rang")
    W1 = WE.labor_daten(sw, t_s + 300); W2 = WE.labor_daten(sw, t_s + 3700)
    b = {"mid": float(M["K"]["c"][int(np.searchsorted(M["K"]["ts"], t_s))])}
    E1 = {"coin": "BTC", "wende": W1, "preis": b}; E2 = {"coin": "BTC", "wende": W2, "preis": b}
    a_ok = sig_wende(S_r, E1, "BTC", t_s + 300, {}) if soll.get("rang") else [1]
    a_spaet = sig_wende(S_r, E2, "BTC", t_s + 3700, {})
    a_cache = sig_wende(S_r, E1, "BTC", t_s + 3700, {})                    # zwischengespeichert „frisch“, aber 61 min nach dem Schluss
    a_einmal = sig_wende(S_r, E1, "BTC", t_s + 300, {"letzter_einstieg": t_s + 120})
    a_pos = sig_wende(S_r, E1, "BTC", t_s + 300, {"_pos": {"id": 1}})
    a_eth = sig_wende(S_r, dict(E1, coin="ETH"), "ETH", t_s + 300, {})
    zs_j = {}; sg_r = soll.get("rang")
    jenseits = {"mid": sg_r["stop"] * (1.01 if sg_r["seite"] == "short" else 0.99)} if sg_r else b
    a_jen = sig_wende(S_r, dict(E1, preis=jenseits), "BTC", t_s + 300, zs_j)
    a_jen2 = sig_wende(S_r, E1, "BTC", t_s + 360, zs_j)                   # danach wieder diesseits: das Signal bleibt entfallen
    zs_p = {"_pos": {"id": 1}}
    sig_wende(S_r, E1, "BTC", t_s + 120, zs_p); zs_p.pop("_pos")           # Position beim Schluss offen, schließt binnen Minuten
    a_nachpos = sig_wende(S_r, E1, "BTC", t_s + 1500, zs_p)
    sig_wende(S_r, E2, "BTC", t_s + 3700, zs_p)                            # nach 60 min: nicht als „verfallen“ zählen
    zs_q = {"pos_bis": t_s - 30}                                           # vor dem Schluss geschlossen: Einstieg
    a_vorpos = sig_wende(S_r, E1, "BTC", t_s + 300, zs_q) if soll.get("rang") else [1]
    if sg_r:                                                            # weit jenseits (1,5 × Abstand am Schluss): der Rand allein hielte nicht
        a_ = float(sg_r["abstand_schluss"])
        weit = {"mid": sg_r["stop"] * (1 + 1.5 * a_) if sg_r["seite"] == "short" else sg_r["stop"] * (1 - 1.5 * a_)}
        a_weit = sig_wende(S_r, dict(E1, preis=weit), "BTC", t_s + 300, {})
    else:
        a_weit = []
    zs_n = {}
    if sg_r:                                                            # Stop näher als die Hälfte des Abstands am Schluss: kein Einstieg
        nah = {"mid": sg_r["stop"] * (1 - 0.4 * sg_r["abstand_schluss"]) if sg_r["seite"] == "short" else sg_r["stop"] * (1 + 0.4 * sg_r["abstand_schluss"])}
        a_nah = sig_wende(S_r, dict(E1, preis=nah), "BTC", t_s + 300, zs_n)
    else:
        a_nah = []
    zs_v = {}; zs_v2 = {"letzter_einstieg": t_s + 10}
    a_v = sig_wende(S_r, E2, "BTC", t_s + 3700, zs_v); sig_wende(S_r, E2, "BTC", t_s + 3760, zs_v); sig_wende(S_r, E2, "BTC", t_s + 3700, zs_v2)
    txt = status_text(S_r, E1, t_s + 300, {}); txt_eth = status_text(S_r, dict(E1, coin="ETH"), t_s + 300, {})
    ok("Extrem-Wende im Labor: Einstieg ab dem 8-h-Schluss binnen 60 min mit dem Stop der Historie, Ziel 1R ab dem Kurs, Risiko in "
       "den Werten, 120 Tage; nur BTC; nur die Lesart mit Signal; keine Position ohne Stop oder Ziel",
       soll.get("rang") and not probl and not andere and not fehler and not ohne_stop,
       f"Soll {sorted(soll)}; {probl or ''} andere {[(r[0], r[1]) for r in andere]}; ohne Stop {ohne_stop}; Fehler {fehler[-2:]}")
    ok("Extrem-Wende: einmal je Signal, nicht nach 60 min (auch nicht mit zwischengespeichertem Eingang), nicht mit offener Position, nur "
       "BTC, nicht jenseits des Stops (knapp und weit; das Signal entfällt dann ganz) und nicht näher als die Hälfte des Abstands am Schluss; "
       "Position beim Schluss offen und binnen 60 min geschlossen -> ausgelassen, nicht verfallen; vor dem Schluss geschlossen -> Einstieg; "
       "zu spät gesehenes Signal einmal "
       "als verfallen "
       "gezählt (nicht nach einem Einstieg); Tafel",
       len(a_ok) == 1 and not a_spaet and not a_cache and not a_einmal and not a_pos and not a_eth and not a_jen and zs_j.get("jenseits") == t_s
       and not a_weit and not a_jen2 and zs_j.get("n_jenseits") == 1 and not a_nachpos and zs_p.get("ausgelassen") == t_s
       and zs_p.get("n_ausgelassen") == 1 and not zs_p.get("n_verfallen") and len(a_vorpos) == 1
       and not a_nah and zs_n.get("jenseits") == t_s and not a_v and zs_v.get("n_verfallen") == 1 and not zs_v2.get("n_verfallen")
       and not W2["frisch"] and W1["frisch"] and txt and "SIGNAL" in txt and txt_eth == "nur BTC",
       f"frisch {W1.get('frisch')}/{W2.get('frisch')}, Tafel „{txt}“, ETH „{txt_eth}“")
    # Stop binnen Minuten, danach liegt der Kurs wieder diesseits: kein zweiter Einstieg auf dasselbe Signal (zs „letzter_einstieg“)
    db2 = os.path.join(tmp, "wende_m2.db"); sp2 = os.path.join(tmp, "wende_f2.db"); sw2 = os.path.join(tmp, "wende_swing2.db")
    WE._LABOR_CACHE.clear()
    M2 = _wende_markt(db2, sw2, stop_sofort=True); t2 = M2["t_schluss"]
    hl_anker.jetzt = lambda con_, coin_, now_: {}
    try:
        L2 = Labor(db2, sp2, coins=("BTC",), nur=("wende_rang",), adressfluss=os.path.join(tmp, "af_we2.db"), swing=sw2)
        t = t2 - 600
        while t <= t2 + 3 * 3600:
            L2.zyklus(t); t += 60
        fehler2 = list(L2.fehler)
    finally:
        hl_anker.jetzt = anker_alt
    st = F.store_connect(sp2)
    pos2 = st.execute("SELECT p.status, p.grund_aus, p.eroeffnet, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid "
                      "WHERE s.name='wende_rang' ORDER BY p.eroeffnet").fetchall()
    sid2 = st.execute("SELECT sid FROM labor_strategie WHERE name='wende_rang' AND aktiv=1").fetchone()
    z2 = st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()
    st.close()
    zs2 = (json.loads(z2[0]) if z2 and z2[0] else {}).get("s", {}).get(f"{sid2[0] if sid2 else ''}|BTC", {})
    WE._LABOR_CACHE.clear()
    ok("Extrem-Wende: nach einem Stop binnen Minuten kein zweiter Einstieg auf dasselbe Signal, obwohl der Kurs wieder diesseits liegt; "
       "der Einstieg ist vermerkt (nicht als „ausgelassen“ gezählt)",
       len(pos2) == 1 and pos2[0][0] == "geschlossen" and "Stop" in (pos2[0][1] or "") and t2 + 600 <= (pos2[0][3] or 0) <= t2 + 960
       and not fehler2 and int(zs2.get("letzter_einstieg", 0)) >= t2 and not zs2.get("n_ausgelassen"),
       f"{pos2}; Zustand letzter_einstieg {zs2.get('letzter_einstieg')}, ausgelassen {zs2.get('n_ausgelassen')}; Fehler {fehler2[-2:]}")
    B_ = swing_bilanz(sp)
    ok("Extrem-Wende: in der Bilanz der Swing-Gruppe (R aus risiko_usd), offene Position gezählt",
       any(v["titel"].startswith("Swing: Extrem-Wende") and v["offen"] + len(v["R"]) >= 1 for v in B_.values()),
       "; ".join(f"{v['titel']}: offen {v['offen']}, {len(v['R'])} geschlossen" for v in B_.values() if "Wende" in v["titel"]))


def _dip_selbsttest(tmp: str, ok) -> None:
    """23.62 (U141): „Dip halten“ im Labor -- nach Dump und Erholung am Schluss von B+2 Long kurz nach 00:00 von B+3, Stop ein σ_Tag unter
    dem Tief, Größe nach Risiko, 60 Tage Haltedauer, am nächsten Schluss Nachzieh-Stop wie hl_swing.nachfuehren; Z2 steigt gleich ein."""
    db = os.path.join(tmp, "dip_m.db"); sp = os.path.join(tmp, "dip_f.db"); sw = os.path.join(tmp, "dip_swing.db")
    M = _swing_markt(db, sw, muster="dip")
    T0, B = M["T0"], M["B"]
    import hl_anker
    anker_alt = hl_anker.jetzt
    hl_anker.jetzt = lambda con_, coin_, now_: {}

    def positionen():
        st = F.store_connect(sp)
        try:
            return st.execute("SELECT s.name, p.eroeffnet, p.seite, p.notional, p.sl, p.preis_ein, p.werte, p.status, p.ablauf FROM labor_position p "
                              "JOIN labor_strategie s ON s.sid=p.sid ORDER BY s.name, p.eroeffnet").fetchall()
        finally:
            st.close()
    try:
        L = Labor(db, sp, coins=("SWG",), nur=("zyklus_dip", "zyklus_dip_heiss"), adressfluss=os.path.join(tmp, "af_dip.db"), swing=sw)
        t = T0 + (B + 2) * 86_400
        while t < T0 + (B + 3) * 86_400 + 3600:
            L.zyklus(t); t += 900
        tr = positionen()
        while t < T0 + (B + 4) * 86_400 + 3600:                                # über den Schluss von B+3: Nachzieh-Stop
            L.zyklus(t); t += 900
        tr2 = positionen()
        fehler = list(L.fehler)
    finally:
        hl_anker.jetzt = anker_alt
    R = SW.STRATEGIEN["zyklus_dip"]
    W = SW.labor_daten(sw, "SWG", T0 + (B + 3) * 86_400 + 60)
    T, I, d = W["T"], W["I"], W["d"]
    lg = SW.dip_lage(R, T, I, d)
    z1 = [r for r in tr if r[0] == "zyklus_dip"]; z2 = [r for r in tr if r[0] == "zyklus_dip_heiss"]
    ok_ = False; txt = f"{len(tr)} Positionen"
    if z1 and lg:
        r = z1[0]; sig = W["sigma"]
        k = math.log(T["c"][d] / lg["L"]) / sig + 1.0
        px = r[4] * math.exp(k * sig)                                          # der Kurs, auf den plan() den Stop setzte
        w = json.loads(r[6] or "{}")
        nt_soll = NOTIONAL; risk_soll = NOTIONAL * (1 - r[4] / px)           # 23.68 (U164): feste Größe
        W2 = SW.labor_daten(sw, "SWG", T0 + (B + 4) * 86_400 + 60)
        res = SW.nachfuehren(R, W2["T"], W2["I"], W2["d"], {"seite": "long", "e": SW.tag_index(W2["T"], int(r[1])), "sl": r[4]})
        sl2 = [x[4] for x in tr2 if x[0] == "zyklus_dip"]
        ok_ = (len(z1) == 1 and r[2] == "long" and 0 <= r[1] - (T0 + (B + 3) * 86_400) <= 900 and abs(px / r[5] - 1) < 0.002
               and abs(r[3] / nt_soll - 1) < 1e-9 and abs(w.get("risiko_usd", 0) - risk_soll) < 1.0 and r[7] == "offen"
               and r[8] is not None and abs((r[8] - r[1]) - 60 * 86_400) <= 900 and d == B + 2 and lg["dump"] >= 5 and lg["erholung"] >= 1
               and len(z2) == 1 and z2[0][1] == r[1] and res.get("sl") is not None and len(sl2) == 1 and abs(sl2[0] / res["sl"] - 1) < 1e-9
               and sl2[0] > r[4] and not fehler)
        txt = (f"Z1 long {_uhr(r[1])} (Tag B+{(r[1] - T0) // 86_400 - B}) zu {r[5]:.3f}, Stop {r[4]:.3f} = Kurs · e^(−(ln(Schluss/Tief)/σ + 1)·σ) "
               f"(Tief {lg['L']:.3f}, σ {sig * 100:.2f} %), Notional {r[3]:.0f} USD, {(r[8] - r[1]) / 86_400 if r[8] else 0:.0f} T; nach dem Schluss "
               f"von B+3 Stop {sl2[0] if sl2 else 0:.3f} (hl_swing {res.get('sl') or 0:.3f}); Dump {lg['dump']:.1f} σ, Erholung {lg['erholung']:.1f} σ; "
               f"Z2 {len(z2)} Position(en); Fehler: {'; '.join(fehler[-2:]) or 'keine'}")
    ok("Zyklus im Labor: „Dip halten“ nach Dump und Erholung Long am Folgetag, Stop ein σ unter dem Tief, Größe 10.000 USD mit "
       "risiko_usd = 10.000 × Stop-Abstand (U164), Nachzieh-Stop wie hl_swing; Z2 ebenso", ok_, txt)


def _akku_markt_k(tage: int, seed: int, art: str = "zufall", sig_tag: float = 0.02) -> dict:
    """23.69 (U180): synthetische 30-min-Kerzen für die Rückblick-Proben -- Zufallsweg, oder mit Einbrüchen um 15 % binnen 4 h, die binnen
    eines Tages zurücklaufen (alle 12 Tage; Positivkontrolle: dort kauft die Regel günstiger, als Zufallswege es erlauben)."""
    rng = np.random.default_rng(seed); n = tage * 48; s = sig_tag / math.sqrt(48)
    r = rng.standard_normal(n) * s
    if art == "dip":
        for k0 in range(30 * 48, n - 60, 12 * 48):
            r[k0:k0 + 8] += math.log(0.85) / 8
            r[k0 + 8:k0 + 56] -= math.log(0.85) / 48
    c = np.exp(math.log(100.0) + np.cumsum(r)); o = np.concatenate(([100.0], c[:-1]))
    w = np.abs(rng.standard_normal(n)) * s * 0.3
    ts = np.arange(n, dtype=np.int64) * 1800 + 1_700_000_000 // 86_400 * 86_400
    return {"ts": ts, "o": o, "h": np.maximum(o, c) * np.exp(w), "l": np.minimum(o, c) * np.exp(-w), "c": c, "v": np.ones(n)}


def _akku_selbsttest(tmp: str, ok) -> None:
    """23.69 (U180): Akkumulation -- Regel, Bilanz und Vergleich von Hand, Rückblick-Regel auf Kerzen (Stufen, Lücke, Sperre, Kausalität,
    gleich der Live-Regel), Zufallswege (Null und Positivkontrolle), Ende zu Ende im Labor mit Heatmap-Cluster und Konten-Quote."""
    R = dict(AKKU_REGELN); Rk = dict(AKKU_REGELN, cluster=False); now = 1_800_000_000
    # 1) Regel von Hand -- A1/A2/A3 mit einem Kauf vor 30 Tagen (sonst greift seit 23.70 zuerst der Startkauf A0), A0 eigens
    s7 = 0.05; a1 = 100 * math.exp(-0.10); a3 = a1 * math.exp(-0.05); cl = {"px": 93.9, "anteil": 0.4}; ALT = (now - 30 * 86_400, 100.0)
    f = lambda P, letzter=ALT, cl_=None, konten=None, R_=R, ma=100.0, frisch=True: akku_lage(R_, P, 100.0, s7, ma, letzter, now, cl_, 0.005,
                                                                                           konten, frisch)
    g0 = f(121.0, None)
    faelle = [("Startkauf beim ersten Takt (A0)", f(97.0, None)["ausloeser"] == "A0" and f(97.0, None)["start"]),
              ("Startkauf ohne 7-Tage-Hoch", akku_lage(R, 97.0, None, s7, 100.0, None, now)["ausloeser"] == "A0"),
              ("Startkauf auch in der Kontrolle", f(97.0, None, R_=Rk)["ausloeser"] == "A0"),
              ("Startkauf nicht über der Sperre", g0["kauf"] is False and "Startkauf wartet" in g0["grund"]
               and g0["naechster"] == {"preis": 120.0, "art": "A0"}),
              ("Startkauf nicht mit altem Kurs", f(97.0, None, frisch=False)["kauf"] is False),
              ("Startkauf nicht ohne 200-Tage-Linie", f(97.0, None, ma=None)["kauf"] is False),
              ("Startkauf nicht ohne σ", akku_lage(R, 97.0, 100.0, None, 100.0, None, now)["kauf"] is False),
              ("kein zweiter Startkauf", f(97.0)["kauf"] is False and not f(97.0)["start"]),
              ("nach dem Startkauf binnen 7 Tagen nur Nachkauf", f(a1 - 0.01, (now - 86_400, 97.0))["ausloeser"] == "A3"),
              ("ohne Startregel kein A0", f(97.0, None, R_=dict(R, start=False))["kauf"] is False),
              ("Sperre ab 1,2 × MA200", f(121.0, ma=100.0)["kauf"] is False and "zu teuer" in f(121.0)["grund"]),
              ("A1 knapp darüber", f(a1 + 0.01)["kauf"] is False),
              ("A1 an der Schwelle", f(a1 - 0.01)["ausloeser"] == "A1"),
              ("A3 knapp darüber", f(a3 + 0.01, (now - 86_400, a1))["kauf"] is False),
              ("A3 darunter", f(a3 - 0.01, (now - 86_400, a1))["ausloeser"] == "A3"),
              ("binnen 7 Tagen kein neues A1", f(a1 - 0.01, (now - 6 * 86_400, 95.0))["kauf"] is False),
              ("nach 7 Tagen wieder A1", f(a1 - 0.01, (now - 7 * 86_400 - 1, 95.0))["ausloeser"] == "A1"),
              ("A2 am Cluster", f(94.0, cl_=cl)["ausloeser"] == "A2"),
              ("A2 nicht ohne σ₇ Abstand", f(95.5, cl_={"px": 95.45, "anteil": 0.4})["kauf"] is False),
              ("A2 ausgesetzt bei Konten ≥ 3", f(94.0, cl_=cl, konten=3.1)["kauf"] is False and f(94.0, cl_=cl, konten=3.1)["warten"]),
              ("A2 bei Konten 2,9", f(94.0, cl_=cl, konten=2.9)["ausloeser"] == "A2"),
              ("Kontrolle ohne A2", f(94.0, cl_=cl, R_=Rk)["kauf"] is False and f(a1 - 0.01, R_=Rk)["ausloeser"] == "A1"),
              ("kein Kauf mit altem Kurs", f(a1 - 1, frisch=False)["kauf"] is False),
              ("kein Kauf ohne MA200", f(a1 - 1, ma=None)["kauf"] is False),
              ("A1 auch bei 1,1 × MA200 (Sperre erst ab 1,2)", f(a1 - 0.01, ma=(a1 - 0.01) / 1.1)["ausloeser"] == "A1"),
              # 23.69: Anzeige „nächster Kauf“ (Reiter Akkumulation) -- binnen 7 Tagen A3, sonst der höhere von A1 und A2 (wirksam: beide Bedingungen)
              ("nächster Kauf: Nachkauf → A3", f(95.0, (now - 86_400, a1))["naechster"] == {"preis": a3, "art": "A3"}),
              ("nächster Kauf: Cluster näher → A2", abs(f(97.0, cl_=cl)["naechster"]["preis"] - min(100 * math.exp(-0.05), 93.9 * math.exp(0.25 * 0.005))) < 1e-12
               and f(97.0, cl_=cl)["naechster"]["art"] == "A2"),
              ("nächster Kauf: Konten ≥ 3 → A1", f(97.0, cl_=cl, konten=3.1)["naechster"] == {"preis": a1, "art": "A1"}),
              ("nächster Kauf: Kontrolle → A1", f(97.0, cl_=cl, R_=Rk)["naechster"] == {"preis": a1, "art": "A1"})]
    falsch = [n_ for n_, g_ in faelle if not g_]
    ok("Akkumulation: Regel von Hand (Startkauf A0, A1/A2/A3, Sperre, 7-Tage-Fenster, Konten, Kontrolle, alter Kurs, nächster Kauf)", not falsch,
       f"{len(faelle) - len(falsch)} von {len(faelle)}" + (f"; falsch: {falsch}" if falsch else f"; A1 bei {a1:.4f}, A3 bei {a3:.4f}"))
    # 2) Bilanz von Hand
    kk = [{"usd": 1000.0, "menge": 999.3 / 100.0, "gebuehr": 0.7, "preis": 100.0}, {"usd": 1000.0, "menge": 999.3 / 80.0, "gebuehr": 0.7, "preis": 80.0}]
    B = akku_bilanz(kk, 90.0); m_ = 9.993 + 12.49125
    ok("Akkumulation: Bilanz von Hand (Bestand, Ø Einstand mit Gebühr, Wert, Gewinn je Los und gesamt)",
       abs(B["menge"] - m_) < 1e-9 and abs(B["einstand"] - 2000 / m_) < 1e-9 and abs(B["wert"] - 90 * m_) < 1e-9
       and abs(B["gewinn_usd"] - (90 * m_ - 2000)) < 1e-9 and abs(B["lose"][1]["gewinn_pct"] - (90 * 12.49125 / 1000 - 1) * 100) < 1e-9
       and B["n"] == 2 and abs(B["gebuehren"] - 1.4) < 1e-12,
       f"Bestand {B['menge']:.5f}, Ø {B['einstand']:.4f}, Wert {B['wert']:.2f}, Gewinn {B['gewinn_usd']:+.2f} ({B['gewinn_pct']:+.3f} %)")
    # 3) Vergleich von Hand
    v = akku_vergleich([100, 80, 90, 110, 95], [100.0] * 50, ziehungen=200, seed=1)
    hm = 5 / sum(1 / x for x in (100, 80, 90, 110, 95))
    v2 = akku_vergleich([100.0] * 5, list(np.linspace(80, 120, 41)), ziehungen=2000, seed=2)
    ok("Akkumulation: Vergleich von Hand (harmonisches Mittel, Zufall, gleichmäßig, p)",
       v and abs(v["einstand"] - hm) < 1e-9 and abs(v["zufall_median"] - 100) < 1e-9 and abs(v["vorteil_pct"] - (100 / hm - 1) * 100) < 1e-9
       and abs(v["p"] - 1 / 201) < 1e-12 and abs(v["gleichmaessig"] - 100) < 1e-9 and akku_vergleich([1, 2, 3, 4], [1.0] * 9) is None
       and v2 and 0.3 < v2["p"] < 0.8,
       f"Ø {v['einstand']:.4f} gegen 100 → Vorteil {v['vorteil_pct']:+.3f} %, p {v['p']:.4f}; flacher Kauf gegen Spanne 80–120: p {v2['p']:.2f}")
    # 4) Regel auf Kerzen von Hand
    n0 = 7 * 48
    ts = np.arange(n0 + 6, dtype=np.int64) * 1800 + 1_700_000_000 // 86_400 * 86_400
    o = np.full(len(ts), 100.0); h = o.copy(); l = o.copy(); c = o.copy()
    o[n0], l[n0], c[n0] = 100.0, 89.0, 95.0                           # A1 bei 90,48 (eine Stufe tiefer 86,07 nicht erreicht)
    o[n0 + 1], l[n0 + 1], c[n0 + 1] = 95.0, 85.0, 86.0                 # A3 bei 86,07
    o[n0 + 2], l[n0 + 2], c[n0 + 2] = 80.0, 79.0, 80.0                 # Eröffnung unter der nächsten Stufe 81,87: Kauf zu 80,0; 77,10 nicht erreicht
    o[n0 + 3], l[n0 + 3], c[n0 + 3] = 80.0, 60.0, 61.0                 # mehrere Stufen in einer Kerze: 76,10 · 72,39 · 68,86 · 65,50 · 62,31
    h = np.maximum(h, np.maximum(o, c))
    s7a = np.full(len(ts), 0.05); spa = np.full(len(ts), 120.0)
    kae, erl = akku_regel_kerzen(R, ts, o, h, l, c, s7a, spa)
    soll = [a1, a1 * math.exp(-0.05), 80.0] + [80.0 * math.exp(-0.05 * k) for k in range(1, 6)]
    kae_sp, _ = akku_regel_kerzen(R, ts, o, h, l, c, s7a, np.full(len(ts), 85.0))
    o2, h2, l2, c2 = o.copy(), h.copy(), l.copy(), c.copy(); o2[n0 + 3:], l2[n0 + 3:], c2[n0 + 3:], h2[n0 + 3:] = 200.0, 200.0, 200.0, 200.0
    kae_z, _ = akku_regel_kerzen(R, ts, o2, h2, l2, c2, s7a, spa)
    o5, h5, l5, c5 = (np.full(n0 + 2, 100.0) for _ in range(4))
    h5[n0], l5[n0], c5[n0] = 110.0, 89.9, 95.0                         # Spitze und Tief in derselben Kerze: ihr Hoch zählt nicht zu H7
    kae5, _ = akku_regel_kerzen(R, ts[:n0 + 2], o5, h5, l5, c5, s7a[:n0 + 2], spa[:n0 + 2])
    ok("Akkumulation: 7-Tage-Hoch ohne die Kerze selbst (Spitze 110 und Tief 89,9 in einer Kerze: Kauf A1 zur Schwelle aus dem Hoch 100 davor)",
       len(kae5) == 1 and kae5[0][2] == "A1" and abs(kae5[0][1] - a1) < 1e-9, f"{kae5}")
    D0 = 1_700_000_000 // 86_400 * 86_400
    ts_e = np.array([D0 + 86_400 + 60, D0 + 86_400 + 120, D0 + 2 * 86_400 + 60, D0 + 2 * 86_400 + 120, D0 + 3 * 86_400 + 60])
    erl_e = akku_erlaubt(ts_e, [119.0, 121.0, 131.0, 133.0, 50.0], [D0, D0 + 86_400], [100.0, 110.0], 1.2)
    ok("Akkumulation: Vergleich nur über Minuten ohne Sperre (Schluss unter 1,2 × 200-Tage-Linie des Vortags; ohne Linie des Vortags keine)",
       erl_e.tolist() == [True, False, True, False, False], f"{erl_e.tolist()}")
    ok("Akkumulation: Rückblick-Regel auf Kerzen von Hand (A1, A3, Eröffnung darunter, mehrere Stufen, Sperre, Kausalität)",
       [round(k[1], 6) for k in kae] == [round(x, 6) for x in soll] and [k[2] for k in kae] == ["A1"] + ["A3"] * 7
       and [round(k[1], 6) for k in kae_sp] == [round(80.0 * math.exp(-0.05 * k), 6) for k in range(6)] and all(k[1] < 85 for k in kae_sp)
       and kae_z == kae[:3],
       f"{len(kae)} Käufe: " + ", ".join(f"{k[2]} {k[1]:.2f}" for k in kae) + f"; mit Sperre 85: {len(kae_sp)} Käufe, alle darunter; "
       f"spätere Kerzen geändert → die ersten drei gleich")
    # 4b) 23.70 (U184): Rückrechnung auf 1-min-Kerzen von Hand -- Käufe erst ab dem Start, zuerst A0 zur Eröffnung (Sperre gilt), dann A3
    # binnen 7 Tagen, A1 erst 7 Tage nach dem letzten Kauf; Kerzen vor dem Start zählen nur zum 7-Tage-Hoch
    D0 = 1_700_000_000 // 86_400 * 86_400; nm = 17 * 1440
    tm = D0 + np.arange(nm, dtype=np.int64) * 60
    om = np.full(nm, 100.0); hm_ = om.copy(); lm = om.copy(); cm = om.copy()
    for t_, lo_, hi_, cl_ in ((D0 + 5 * 86_400, 80.0, None, 99.0), (D0 + 7 * 86_400 + 43_200, None, 130.0, None),
                              (D0 + 9 * 86_400, 94.0, None, 95.0), (D0 + 16 * 86_400 + 3600, 89.0, None, 90.0)):
        j_ = (t_ - D0) // 60
        if lo_ is not None:
            lm[j_] = lo_
        if hi_ is not None:
            hm_[j_] = hi_
        if cl_ is not None:
            cm[j_] = cl_
    s7m = np.full(nm, 0.05); spm = np.full(nm, 120.0); spm[:(8 * 86_400 + 3 * 3600) // 60] = 99.0
    km, _ = akku_regel_kerzen(R, tm, om, hm_, lm, cm, s7m, spm, bar=60, ab=D0 + 8 * 86_400)
    km_soll = [(D0 + 8 * 86_400 + 3 * 3600, 100.0, "A0"), (D0 + 9 * 86_400, 100 * math.exp(-0.05), "A3"),
               (D0 + 16 * 86_400 + 3600, 100 * math.exp(-0.10), "A1")]
    km_ohne, _ = akku_regel_kerzen(R, tm, om, hm_, lm, cm, s7m, np.full(nm, 120.0), bar=60)
    ok("Akkumulation: Rückrechnung auf Kerzen von Hand (ab dem Start: A0 zur Eröffnung erst unter der Sperre, A3 binnen 7 Tagen, A1 danach; "
       "ohne Start-Zeitpunkt kein A0)",
       [(k[0], round(k[1], 9), k[2]) for k in km] == [(k[0], round(k[1], 9), k[2]) for k in km_soll]
       and "A0" not in [k[2] for k in km_ohne] and km_ohne and km_ohne[0][0] == D0 + 5 * 86_400,
       f"{[(round((k[0] - D0) / 86_400, 3), round(k[1], 3), k[2]) for k in km]}; ohne Start: {len(km_ohne)} Käufe ab Tag "
       f"{(km_ohne[0][0] - D0) / 86_400 if km_ohne else '—'}")
    # 4c) 23.71 (U185, Nutzer 20.10. 01:40): Grund des Startkaufs von Hand -- Ursache eines späteren Startkaufs (Sperre, fehlende Tageskerzen,
    # beides; Start mitten in einer Minute) und die Anzeige der Texte aus 23.70 (die gespeicherten Daten bleiben)
    t8 = D0 + 8 * 86_400; t3 = t8 + 3 * 3600; t9 = D0 + 9 * 86_400; sp120 = np.full(nm, 120.0)
    k9, _ = akku_regel_kerzen(R, tm, om, hm_, lm, cm, s7m, spm, bar=60, ab=t9 - 30)
    u_sofort = akku_start_ursache(tm, om, s7m, spm, t9 - 30, k9[0][0]) if k9 else None
    u_teuer = akku_start_ursache(tm, om, s7m, spm, t8, km[0][0]) if km else None
    s7f = s7m.copy(); s7f[:(8 * 86_400 + 5 * 3600) // 60] = np.nan
    kf, _ = akku_regel_kerzen(R, tm, om, hm_, lm, cm, s7f, sp120, bar=60, ab=t8)
    u_fehlt = akku_start_ursache(tm, om, s7f, sp120, t8, kf[0][0]) if kf else None
    s7b = s7m.copy(); s7b[:(8 * 86_400 + 3600) // 60] = np.nan
    kb, _ = akku_regel_kerzen(R, tm, om, hm_, lm, cm, s7b, spm, bar=60, ab=t8)
    u_beides = akku_start_ursache(tm, om, s7b, spm, t8, kb[0][0]) if kb else None
    alt_ = "nachgerechnet (1-min-Kerzen): Startkauf zum Start des Coins im Labor (27.09. 04:40)"
    neu_ = akku_grund_text(alt_); ev_ = "Kauf ETH 5.000 USD zu 2.541,6 (Spot) — A0: "
    a1_ = "nachgerechnet (1-min-Kerzen): Rücksetzer: Tief ≤ 90,48, 2 σ₇ unter dem 7-Tage-Hoch (100)"
    ok("Akkumulation: Grund des Startkaufs von Hand (später Startkauf: Sperre, fehlende Tageskerzen, beides; sofort auch bei Start mitten in der "
       "Minute; Texte aus 23.70 in der Anzeige richtig, andere unverändert)",
       k9 and k9[0][0] == t9 and k9[0][2] == "A0" and u_sofort == ""
       and km and km[0][0] == t3 and u_teuer == f"; erst am {_uhr(t3)}, bis dahin lag der Kurs bei oder über 1,2 × 200-Tage-Linie"
       and kf and kf[0][0] == t8 + 5 * 3600 and kf[0][2] == "A0"
       and u_fehlt == f"; erst am {_uhr(t8 + 5 * 3600)}, bis dahin fehlten Tageskerzen (σ₇ oder 200-Tage-Linie)"
       and kb and kb[0][0] == t3 and kb[0][2] == "A0" and u_beides == (f"; erst am {_uhr(t3)}, bis dahin fehlten zeitweise Tageskerzen (σ₇ oder "
                                                                      "200-Tage-Linie), sonst lag der Kurs bei oder über 1,2 × 200-Tage-Linie")
       and neu_ == "nachgerechnet (1-min-Kerzen): " + AKKU_A0_TEXT.format(ab="27.09. 04:40") and "zum Start des Coins" not in neu_
       and akku_grund_text(neu_) == neu_ and akku_grund_text(ev_ + alt_) == ev_ + neu_ and akku_grund_text(a1_) == a1_
       and akku_grund_text(None) == "" and akku_grund_text("Startkauf: erster Kauf dieser Strategie in diesem Coin") == "Startkauf: erster Kauf dieser Strategie in diesem Coin",
       f"sofort „{u_sofort}“; Sperre „{u_teuer}“; Tageskerzen „{u_fehlt}“; beides „{u_beides}“; 23.70 → „{neu_}“")
    # 4d) 23.72 (U186, Nutzer 20.10. 02:43): Korrekturkauf A4 -- Live-Regel von Hand, Kerzen von Hand, Referenz, Rückrechnung = Live
    Rk4 = dict(AKKU_REGELN); qk = 1.0 - Rk4["korr"]
    fk = lambda P, H, lk=None, fr=True: akku_korrektur_lage(Rk4, P, H, lk, now, fr)
    gesperrt = akku_lage(R, 92.0, 100.0, s7, 50.0, ALT, now)                # Kurs über 1,2 × 200-Tage-Linie (60): A0–A3 kaufen nicht
    faelle_k = [("7 % unter dem 48-h-Hoch: Kauf", fk(92.99, 100.0)["ausloeser"] == "A4" and fk(92.99, 100.0)["bezug_art"] == "hoch48"),
                ("knapp darüber kein Kauf, nächster Kauf an der Schwelle", fk(93.01, 100.0)["kauf"] is False
                 and abs(fk(93.01, 100.0)["naechster"]["preis"] - qk * 100.0) < 1e-9 and fk(93.01, 100.0)["naechster"]["art"] == "A4"),
                ("ohne Sperre: kauft, wo A0–A3 gesperrt sind", gesperrt["kauf"] is False and "zu teuer" in gesperrt["grund"]
                 and fk(92.0, 100.0)["kauf"]),
                ("nach einem Korrekturkauf: Bezug das höhere von Hoch seit dem Kauf und letztem Kauf", fk(88.3, 95.0, (now - 86_400, 93.0))["kauf"]
                 and abs(fk(88.3, 95.0, (now - 86_400, 93.0))["schwelle"] - qk * 95.0) < 1e-9 and fk(88.4, 95.0, (now - 86_400, 93.0))["kauf"] is False),
                ("Nachkauf binnen 14 Tagen je 7 % unter dem letzten Korrekturkauf", fk(86.4, 90.0, (now - 13 * 86_400, 93.0))["kauf"]
                 and fk(86.4, 90.0, (now - 13 * 86_400, 93.0))["bezug_art"] == "nachkauf"),
                ("nach 14 Tagen kein Nachkauf mehr", fk(86.4, 90.0, (now - 14 * 86_400 - 1, 93.0))["kauf"] is False
                 and fk(86.4, 90.0, (now - 14 * 86_400 + 1, 93.0))["kauf"]),
                ("ohne Hoch und ohne Korrekturkauf kein Kauf", fk(50.0, None)["kauf"] is False),
                ("ohne Hoch der Nachkauf trotzdem", fk(86.4, None, (now - 86_400, 93.0))["kauf"]),
                ("alter Kurs, kein Kurs: kein Kauf", fk(80.0, 100.0, fr=False)["kauf"] is False and fk(None, 100.0)["kauf"] is False),
                ("Ende des Nachkaufs = letzter Korrekturkauf + 14 Tage", fk(95.0, 100.0, (now - 86_400, 93.0))["bis"] == now - 86_400 + 14 * 86_400
                 and "längstens bis" in fk(95.0, 80.0, (now - 86_400, 93.0))["grund"])]
    falsch = [n_ for n_, g_ in faelle_k if not g_]
    ok("Akkumulation: Korrekturkauf A4 von Hand (7 % unter dem 48-h-Hoch, ohne Sperre, Bezug nach einem Kauf, Nachkauf binnen 14 Tagen, "
       "alter Kurs)", not falsch, f"{len(faelle_k) - len(falsch)} von {len(faelle_k)}" + (f"; falsch: {falsch}" if falsch else ""))

    def _korr_ref(R_, ts_, o_, h_, l_, ab_, q_=None):                  # unabhängige Rechnung: je Minute ein Fenster-Schnitt (langsam, einfach)
        q_ = (1.0 - R_["korr"]) if q_ is None else q_; fh_ = int(R_["korr_h"]) * 3600; fe_ = int(R_["korr_tage"]) * 86_400
        out_ = []; jL_ = tL_ = pL_ = None
        for j_ in range(int(np.searchsorted(ts_, ab_)), len(ts_)):
            while True:
                a_ = int(np.searchsorted(ts_, ts_[j_] - fh_))
                if jL_ is not None:
                    a_ = max(a_, jL_ + 1)
                H_ = float(np.max(h_[a_:j_])) if j_ > a_ else -math.inf
                F_ = pL_ if (tL_ is not None and ts_[j_] - tL_ < fe_) else -math.inf
                B_ = max(H_, F_)
                if not math.isfinite(B_) or l_[j_] > q_ * B_:
                    break
                p_ = q_ * B_ if jL_ == j_ else min(q_ * B_, float(o_[j_]))
                out_.append((int(ts_[j_]), p_)); jL_, tL_, pL_ = j_, int(ts_[j_]), p_
        return out_
    # Kerzen von Hand (1 min): 0–1 T Stand 100 (nur Hoch), 1 T–1 T 12 h Stand 110, dann in 60 h langsam auf 101,5 (nie 7 % in 48 h; mit
    # 7-Tage-Fenster wäre es ein Kauf), 6 T Einbruch auf 94 (Kauf 94,395), einen Tag bei 94 (kein zweiter Kauf), 7 T Anstieg auf 105,
    # 7 T 6 h Einbruch auf 97 (neues 48-h-Hoch nach dem Kauf: Kauf 97,65), 9 Tage bei 97, 16 T 6 h auf 90,5 (Nachkauf 9 Tage nach dem
    # Kauf: 90,8145), 18 T 6 h Eröffnung 84 unter der Schwelle (Kauf 84) und Tief 75 in derselben Kerze (Stufe 78,12), danach langsam
    # abwärts (der Nachkauf 72,65 käme erst nach 16 Tagen: keiner)
    D0k = 1_700_000_000 // 86_400 * 86_400; nk = 45 * 1440; M_ = lambda d_, h_=0: int((d_ * 86_400 + h_ * 3600) // 60)
    stand = np.full(nk, 100.0)
    stand[M_(1):M_(1, 12)] = 110.0
    stand[M_(1, 12):M_(4)] = np.linspace(110.0, 101.5, M_(4) - M_(1, 12))
    stand[M_(4):M_(6)] = 101.5; stand[M_(6):M_(7)] = 94.0; stand[M_(7):M_(7, 6)] = 105.0
    stand[M_(7, 6):M_(16, 6)] = 97.0; stand[M_(16, 6):M_(18, 6)] = 90.5; stand[M_(18, 6):M_(23, 6)] = 76.0
    stand[M_(23, 6):M_(38, 6)] = 76.0 - 0.3 * np.arange(M_(38, 6) - M_(23, 6)) / 1440.0; stand[M_(38, 6):] = 71.5
    ck = stand.copy(); ok_ = np.concatenate([[100.0], ck[:-1]]); hk = np.maximum(ok_, ck); lk_ = np.minimum(ok_, ck)
    hk[M_(18, 6)] = ok_[M_(18, 6)] = 84.0; lk_[M_(18, 6)] = 75.0; ck[M_(18, 6)] = 76.0
    tkk = D0k + np.arange(nk, dtype=np.int64) * 60
    kk = akku_korrektur_kerzen(Rk4, tkk, ok_, hk, lk_, ck, ab=D0k + 86_400, bar=60)
    kk_soll = [(M_(6), qk * 101.5, "hoch48"), (M_(7, 6), qk * 105.0, "hoch48"), (M_(16, 6), qk * qk * 105.0, "nachkauf"),
               (M_(18, 6), 84.0, "nachkauf"), (M_(18, 6), qk * 84.0, "nachkauf")]
    kk_ref = _korr_ref(Rk4, tkk, ok_, hk, lk_, D0k + 86_400)
    ok("Akkumulation: Korrekturkauf auf Kerzen von Hand (48 h, nicht 7 Tage; derselbe Einbruch einmal; neues Hoch nach dem Kauf; Nachkauf "
       "nach 9 Tagen; Eröffnung darunter und zweite Stufe in derselben Kerze; nach 14 Tagen kein Nachkauf; gleich der Referenzrechnung)",
       [(int((k[0] - D0k) // 60), round(k[1], 9), k[3]) for k in kk] == [(m_, round(p_, 9), a_) for m_, p_, a_ in kk_soll]
       and [(k[0], round(k[1], 9)) for k in kk] == [(k[0], round(k[1], 9)) for k in kk_ref] and all(k[2] == "A4" for k in kk),
       "; ".join(f"Tag {(k[0] - D0k) / 86_400:.2f} {k[1]:.4f} ({k[3]})" for k in kk) + f"; Referenz {len(kk_ref)} Käufe")
    # Referenz auf Zufallswegen mit Einbrüchen (1 min, 30 Tage, drei Saaten): dieselben Käufe wie die Rechnung des Labors
    gleich_ref = []; n_ref = []
    for sd in (11, 12, 13):
        rg = np.random.default_rng(sd); nn = 30 * 1440
        rr = rg.standard_normal(nn) * 0.0012
        for k_ in rg.integers(1000, nn - 1000, 12):
            rr[k_:k_ + 300] -= rg.uniform(0.0001, 0.0004)
        cz = np.exp(np.log(100.0) + np.cumsum(rr)); oz = np.concatenate([[100.0], cz[:-1]])
        hz = np.maximum(oz, cz) * (1 + np.abs(rg.standard_normal(nn)) * 0.0004); lz = np.minimum(oz, cz) * (1 - np.abs(rg.standard_normal(nn)) * 0.0004)
        tzz = D0k + np.arange(nn, dtype=np.int64) * 60
        a_ = akku_korrektur_kerzen(Rk4, tzz, oz, hz, lz, cz, ab=D0k + 3 * 86_400, bar=60); b_ = _korr_ref(Rk4, tzz, oz, hz, lz, D0k + 3 * 86_400)
        gleich_ref.append([(k[0], round(k[1], 9)) for k in a_] == [(k[0], round(k[1], 9)) for k in b_]); n_ref.append(len(a_))
    ok("Akkumulation: Korrekturkauf -- Rechnung des Labors = Referenzrechnung auf Zufallswegen mit Einbrüchen", all(gleich_ref) and min(n_ref) >= 5,
       f"Käufe je Weg {n_ref}, gleich {gleich_ref}")
    # Rückrechnung = Live: Kerzen ohne Docht (30 min), je Kerze ein Takt mit der Live-Regel und dem Hoch bis jetzt
    rg = np.random.default_rng(21); nw = 60 * 48
    rw = rg.standard_normal(nw) * 0.008
    for k_ in rg.integers(200, nw - 200, 6):
        rw[k_:k_ + 30] -= 0.004
    pw = 100 * np.exp(np.cumsum(rw)); tw = D0k + np.arange(nw, dtype=np.int64) * 1800; abw = int(tw[0]) + 3 * 86_400
    kw = akku_korrektur_kerzen(Rk4, tw, pw, pw, pw, pw, ab=abw, bar=1800)
    lw = []; lkw = None
    for j in range(nw):
        if tw[j] < abw:
            continue
        a_ = int(np.searchsorted(tw, max(int(tw[j]) - 48 * 3600, (lkw[0] + 1800) if lkw else 0)))
        Lk_ = akku_korrektur_lage(Rk4, float(pw[j]), float(np.max(pw[a_:j + 1])), lkw, int(tw[j]))
        if Lk_["kauf"]:
            lw.append((int(tw[j]), float(pw[j]))); lkw = (int(tw[j]), float(pw[j]))
    ok("Akkumulation: Korrekturkauf -- Rückrechnung auf Kerzen = Live-Regel Takt für Takt (dieselben Käufe auf denselben Kursen)",
       len(kw) >= 3 and [(k[0], round(k[1], 9)) for k in kw] == [(a_, round(b_, 9)) for a_, b_ in lw],
       f"{len(kw)} Käufe auf Kerzen, {len(lw)} live")
    # 4e) 23.74 (U189, Nutzer 20.10. 09:55): Faktor gegenüber BTC -- von Hand, aus swing.db (nur die 365 Tage vor dem Start), Schwellen und
    # Betrag, Positivkontrolle Gleichwertigkeit (Log-Kurs dreifach → dieselben Minuten), Rückrechnung = Live mit f = 3
    rv_b = np.full(200, 0.0004); rv_b[5] = np.nan
    fa = [akku_faktor_aus_rv(rv_b * 9, rv_b, R), akku_faktor_aus_rv(rv_b, rv_b, R), akku_faktor_aus_rv(rv_b / 4, rv_b, R),
          akku_faktor_aus_rv(rv_b[:60] * 9, rv_b[:60], R), akku_faktor_aus_rv(rv_b[:61] * 9, rv_b[:61], R)]
    rv_l = rv_b * 9; rv_l[10:20] = np.nan
    fa.append(akku_faktor_aus_rv(rv_l, rv_b, R))
    ok("Akkumulation: Faktor gegenüber BTC von Hand (RV 9-mal → 3,00; gleich → 1,00; ruhiger → 1,00 als Untergrenze; unter 60 gemeinsamen "
       "Tagen kein Faktor; Tage ohne gültige RV in einer Reihe zählen nicht)",
       fa[0]["ok"] and fa[0]["faktor"] == 3.0 and abs(fa[0]["roh"] - 3.0) < 1e-12 and fa[0]["n"] == 199
       and fa[1]["faktor"] == 1.0 and fa[2]["ok"] and fa[2]["faktor"] == 1.0 and abs(fa[2]["roh"] - 0.5) < 1e-12
       and not fa[3]["ok"] and fa[3]["n"] == 59 and "59 von mindestens 60" in fa[3]["grund"] and fa[4]["ok"] and fa[4]["n"] == 60
       and fa[5]["n"] == 189 and fa[5]["faktor"] == 3.0,
       "; ".join(f"{x['faktor']} (roh {x['roh']}, n {x['n']})" for x in fa))
    R3 = dict(AKKU_REGELN); q3 = 0.93 ** 3
    ts_st = D0k + np.arange(3 * 1440 + 1, dtype=np.int64) * 60                 # 3 Tage bei 100, dann eine Kerze: Eröffnung 100, Tief 50
    o_st = np.full(len(ts_st), 100.0); h_st = o_st.copy(); l_st = o_st.copy(); c_st = o_st.copy(); l_st[-1] = 50.0; c_st[-1] = 60.0
    fk3 = lambda P, H, lk=None: akku_korrektur_lage(R3, P, H, lk, now, True, 3.0)
    ohne_fk = {k_: v_ for k_, v_ in R3.items() if not k_.startswith("faktor_")}
    faelle_f = [("f = 1: 7 % und 5.000 USD", abs(akku_korr_q(R3, 1.0) - 0.93) < 1e-15 and akku_betrag(R3, 1.0) == 5_000.0 and akku_pc(R3, 1.0) == "7"),
                ("f = 3: 0,93³ und 1.666,67 USD", abs(akku_korr_q(R3, 3.0) - q3) < 1e-15 and abs(akku_betrag(R3, 3.0) - 5_000.0 / 3) < 1e-9
                 and akku_pc(R3, 3.0) == "19,6"),
                ("f = 3: Kauf erst bei 0,93³ unter dem 48-h-Hoch", fk3(q3 * 100 - 0.01, 100.0)["kauf"] and fk3(q3 * 100 + 0.01, 100.0)["kauf"] is False
                 and abs(fk3(90.0, 100.0)["naechster"]["preis"] - q3 * 100) < 1e-9 and "19,6 % unter dem Hoch" in fk3(90.0, 100.0)["grund"]),
                ("f = 3: Nachkauf je 0,93³", fk3(q3 * 80.0 - 0.01, 70.0, (now - 86_400, 80.0))["kauf"]
                 and fk3(q3 * 80.0 + 0.01, 70.0, (now - 86_400, 80.0))["kauf"] is False),
                ("ohne die Faktor-Regeln wie bis 23.73", abs(akku_korr_q(ohne_fk, 3.0) - 0.93) < 1e-15 and akku_betrag(ohne_fk, 3.0) == 5_000.0),
                ("Untergrenze aus den Regeln", akku_faktor_aus_rv(rv_b / 4, rv_b, dict(R3, faktor_min=0.5))["faktor"] == 0.5),
                ("f = 3: mehrere Stufen in einer Kerze je 0,93³ (Eröffnung 100, Tief 50: 80,44 · 64,70 · 52,04; Tief 55: nur die ersten zwei)",
                 [round(k[1], 6) for k in akku_korrektur_kerzen(R3, ts_st, o_st, h_st, l_st, c_st, ab=int(ts_st[-1]), bar=60, f=3.0)]
                 == [round(100 * q3, 6), round(100 * q3 ** 2, 6), round(100 * q3 ** 3, 6)]
                 and [round(k[1], 6) for k in akku_korrektur_kerzen(R3, ts_st, o_st, h_st, np.where(l_st < 51, 55.0, l_st), c_st, ab=int(ts_st[-1]),
                                                                     bar=60, f=3.0)] == [round(100 * q3, 6), round(100 * q3 ** 2, 6)])]
    falsch = [n_ for n_, g_ in faelle_f if not g_]
    ok("Akkumulation: Schwellen und Betrag mit dem Faktor von Hand (A4 0,93^f für Korrektur und Nachkauf, 5.000 USD ÷ f; ohne die Regeln wie "
       "bisher)", not falsch, f"{len(faelle_f) - len(falsch)} von {len(faelle_f)}" + (f"; falsch: {falsch}" if falsch else ""))
    # Faktor aus swing.db: BTC und ein Coin mit dreifachem Log-Weg (30 min), 500 Tage; Start am Tag 420
    swf = os.path.join(tmp, "akku_faktor_swing.db"); cf = SW.verbinden(swf)
    rgf = np.random.default_rng(31); nf = 500 * 48; D0f = 1_700_000_000 // 86_400 * 86_400
    lb = np.cumsum(rgf.standard_normal(nf) * 0.003); tf = D0f + np.arange(nf, dtype=np.int64) * 1800

    def _k30(lp):
        c_ = 100 * np.exp(lp); o_ = np.concatenate([[100.0], c_[:-1]])
        return [(int(a_), float(b_), float(max(b_, c2_)), float(min(b_, c2_)), float(c2_), 1.0) for a_, b_, c2_ in zip(tf, o_, c_)]
    SW._schreiben(cf, "INSERT INTO sw_klines VALUES (?,?,?,?,?,?,?)", [("BTC", *k) for k in _k30(lb)] + [("ZF", *k) for k in _k30(3 * lb)])
    cf.close()
    t_sf = D0f + 420 * 86_400 + 5 * 3600
    ff = [akku_faktor_rechnen(swf, "ZF", t_sf, R3), akku_faktor_rechnen(swf, "BTC", t_sf, R3), akku_faktor_rechnen(swf, "ZF", D0f + 30 * 86_400, R3),
          akku_faktor_rechnen(os.path.join(tmp, "fehlt.db"), "ZF", t_sf, R3), akku_faktor_rechnen(os.path.join(tmp, "fehlt.db"), "BTC", t_sf, R3)]
    cf = sqlite3.connect(swf)
    cf.execute("UPDATE sw_klines SET c=c*1.5, h=h*1.5 WHERE coin='ZF' AND ts>=? AND ts % 3600 = 0", (D0f + 420 * 86_400,))  # ab dem Start
    cf.execute("UPDATE sw_klines SET c=c*1.5, h=h*1.5 WHERE coin='ZF' AND ts<? AND ts % 3600 = 0", (D0f + 55 * 86_400,))   # vor dem Fenster
    cf.commit()
    ff.append(akku_faktor_rechnen(swf, "ZF", t_sf, R3))
    cf.execute("UPDATE sw_klines SET c=c*1.5 WHERE coin='ZF' AND ts>=? AND ts<? AND ts % 3600 = 0", (D0f + 400 * 86_400, D0f + 410 * 86_400))
    cf.commit(); cf.close()
    ff.append(akku_faktor_rechnen(swf, "ZF", t_sf, R3))
    ok("Akkumulation: Faktor aus swing.db von Hand (Coin mit dreifachem Log-Weg → 3,00 aus den 365 Tagen vor dem Start; BTC 1; zu kurze "
       "Historie oder swing.db fehlt → kein Faktor, BTC trotzdem 1; Kerzen ab dem Start und vor dem Fenster ändern nichts, im Fenster schon)",
       ff[0]["ok"] and ff[0]["faktor"] == 3.0 and abs(ff[0]["roh"] - 3.0) < 1e-9 and ff[0]["n"] == 365 and ff[0]["bis"] == D0f + 420 * 86_400
       and ff[0]["von"] == D0f + 55 * 86_400 and ff[1]["ok"] and ff[1]["faktor"] == 1.0 and not ff[2]["ok"] and ff[2]["n"] == 30
       and not ff[3]["ok"] and ff[4]["ok"] and ff[4]["faktor"] == 1.0 and ff[5]["faktor"] == 3.0 and ff[5]["n"] == 365
       and abs(ff[5]["roh"] - ff[0]["roh"]) < 1e-12 and ff[6]["ok"] and abs(ff[6]["roh"] - ff[0]["roh"]) > 1e-3,
       "; ".join(f"{x.get('faktor')} (roh {x.get('roh') if x.get('roh') is None else round(x['roh'], 6)}, n {x.get('n')}{', ' + x['grund'] if x.get('grund') else ''})"
                 for x in ff))
    # Positivkontrolle Gleichwertigkeit: 1-min-Weg wie oben (Einbrüche), der Coin mit dreifachem Log-Weg und f = 3 kauft in denselben Minuten
    # (Preis = BTC-Preis hoch 3 / 100²); mit fest 7 % kauft er viel öfter. BTC mit f = 1 = Regel von 23.72 (Referenz).
    gl_t = []; gl_p = []; n_b = []; n_c3 = []; n_c1 = []; btc_alt = []
    for sd in (41, 42, 43):
        rg = np.random.default_rng(sd); nn = 30 * 1440
        rr = rg.standard_normal(nn) * 0.0012
        for k_ in rg.integers(1000, nn - 1000, 12):
            rr[k_:k_ + 300] -= rg.uniform(0.0001, 0.0004)
        lc_ = np.cumsum(rr); lo_ = np.concatenate([[0.0], lc_[:-1]])
        lh_ = np.maximum(lo_, lc_) + np.abs(rg.standard_normal(nn)) * 0.0004; ll_ = np.minimum(lo_, lc_) - np.abs(rg.standard_normal(nn)) * 0.0004
        tzz = D0k + np.arange(nn, dtype=np.int64) * 60; ab_ = D0k + 3 * 86_400
        P_ = lambda x, m=1.0: 100.0 * np.exp(m * x)
        kb_ = akku_korrektur_kerzen(R3, tzz, P_(lo_), P_(lh_), P_(ll_), P_(lc_), ab=ab_, bar=60, f=1.0)
        kc3 = akku_korrektur_kerzen(R3, tzz, P_(lo_, 3), P_(lh_, 3), P_(ll_, 3), P_(lc_, 3), ab=ab_, bar=60, f=3.0)
        kc1 = akku_korrektur_kerzen(R3, tzz, P_(lo_, 3), P_(lh_, 3), P_(ll_, 3), P_(lc_, 3), ab=ab_, bar=60, f=1.0)
        gl_t.append([k[0] for k in kb_] == [k[0] for k in kc3])
        gl_p.append(len(kb_) == len(kc3) and all(abs(c_[1] / (b_[1] ** 3 / 1e4) - 1) < 1e-9 for b_, c_ in zip(kb_, kc3)))
        btc_alt.append([(k[0], round(k[1], 9)) for k in kb_] == [(k[0], round(k[1], 9)) for k in _korr_ref(R3, tzz, P_(lo_), P_(lh_), P_(ll_), ab_)])
        n_b.append(len(kb_)); n_c3.append(len(kc3)); n_c1.append(len(kc1))
    ok("Akkumulation: Positivkontrolle Gleichwertigkeit -- Coin mit dreifachem Log-Weg und Faktor 3 kauft A4 in denselben Minuten wie BTC (fest "
       "7 % kauft er viel öfter); BTC mit Faktor 1 = Regel von 23.72",
       all(gl_t) and all(gl_p) and all(btc_alt) and min(n_b) >= 3 and all(c1 >= 2 * b_ for c1, b_ in zip(n_c1, n_b)),
       f"BTC {n_b}, Coin mit Faktor {n_c3}, Coin mit fest 7 % {n_c1}; Minuten gleich {gl_t}, Preise gleich {gl_p}, BTC wie 23.72 {btc_alt}")
    # Rückrechnung = Live Takt für Takt mit f = 3 (Kerzen ohne Docht wie oben, Weg mit dreifacher Schwankung)
    pw3 = 100 * np.exp(3 * np.log(pw / 100))
    kw3 = akku_korrektur_kerzen(R3, tw, pw3, pw3, pw3, pw3, ab=abw, bar=1800, f=3.0)
    lw3 = []; lkw = None
    for j in range(nw):
        if tw[j] < abw:
            continue
        a_ = int(np.searchsorted(tw, max(int(tw[j]) - 48 * 3600, (lkw[0] + 1800) if lkw else 0)))
        Lk_ = akku_korrektur_lage(R3, float(pw3[j]), float(np.max(pw3[a_:j + 1])), lkw, int(tw[j]), True, 3.0)
        if Lk_["kauf"]:
            lw3.append((int(tw[j]), float(pw3[j]))); lkw = (int(tw[j]), float(pw3[j]))
    ok("Akkumulation: Korrekturkauf mit Faktor 3 -- Rückrechnung auf Kerzen = Live-Regel Takt für Takt, dieselben Takte wie mit Faktor 1 auf dem "
       "einfachen Weg",
       len(kw3) >= 3 and [(k[0], round(k[1], 9)) for k in kw3] == [(a_, round(b_, 9)) for a_, b_ in lw3]
       and [k[0] for k in kw3] == [k[0] for k in kw],
       f"{len(kw3)} Käufe auf Kerzen, {len(lw3)} live; Takte wie mit Faktor 1: {[k[0] for k in kw3] == [k[0] for k in kw]}")
    # 5) Rückblick = Live (Kerzen ohne Docht, je Kerze ein Takt); ohne Startregel wie 23.69, mit Startregel ab einem Start-Zeitpunkt
    rng = np.random.default_rng(5); n1 = 30 * 48
    pz = 100 * np.exp(np.cumsum(rng.standard_normal(n1) * 0.006)); tz = np.arange(n1, dtype=np.int64) * 1800 + 1_700_000_000 // 86_400 * 86_400
    s7z = np.full(n1, 0.04); spz = np.full(n1, 140.0)
    H7z = akku_h7_reihe(tz, pz)

    def _live(R_, ab_):
        kl_, letzter_ = [], None
        for j in range(n1):
            if tz[j] < ab_:
                continue
            Lg_ = akku_lage(R_, float(pz[j]), float(max(H7z[j], pz[j])) if np.isfinite(H7z[j]) else None, 0.04, 140.0 / 1.2, letzter_, int(tz[j]))
            if Lg_["kauf"]:
                kl_.append((int(tz[j]), float(pz[j]), Lg_["ausloeser"])); letzter_ = (int(tz[j]), float(pz[j]))
        return kl_
    kh, _ = akku_regel_kerzen(dict(R, start=False), tz, pz, pz, pz, pz, s7z, spz)
    kl = _live(dict(Rk, start=False), int(tz[0]))
    ab5 = int(tz[0]) + 3 * 86_400 + 1800
    kh_s, _ = akku_regel_kerzen(R, tz, pz, pz, pz, pz, s7z, spz, ab=ab5)
    kl_s = _live(Rk, ab5)
    ok("Akkumulation: Rückblick-Regel = Live-Regel (dieselben Käufe auf denselben Kursen; mit Startregel ab dem Start-Zeitpunkt samt A0)",
       len(kh) >= 3 and [(k[0], round(k[1], 9), k[2]) for k in kh] == [(k[0], round(k[1], 9), k[2]) for k in kl]
       and len(kh_s) >= 3 and kh_s[0][2] == "A0" and kh_s[0][0] == ab5
       and [(k[0], round(k[1], 9), k[2]) for k in kh_s] == [(k[0], round(k[1], 9), k[2]) for k in kl_s],
       f"ohne Startregel {len(kh)} Käufe im Rückblick, {len(kl)} live; mit Startregel {len(kh_s)} / {len(kl_s)}, erster {kh_s[0][2] if kh_s else '—'}")
    # 6) Zufallswege: Null und Positivkontrolle
    nul = [akku_rueckblick_coin(Rk, _akku_markt_k(540, 300 + i), surrogate=60, seed=i) for i in range(6)]
    pos = [akku_rueckblick_coin(Rk, _akku_markt_k(540, 300 + i, "dip", sig_tag=0.015), surrogate=60, seed=i) for i in range(3)]
    pn = [(r.get("surrogat") or {}).get("p") for r in nul]; pp = [(r.get("surrogat") or {}).get("p") for r in pos]
    ok("Akkumulation: Zufallswege -- ohne Vorhersagekraft kein Beleg (Null), bei Einbrüchen mit Rückkehr belegt (Positivkontrolle)",
       sum(1 for p_ in pn if p_ is not None) >= 4 and all(p_ is not None for p_ in pp)
       and sum(1 for p_ in pn if p_ is not None and p_ < 0.05) <= 1 and sum(1 for r in nul if r.get("timing_beleg")) <= 1
       and all(p_ < 0.05 for p_ in pp) and all(r.get("timing_beleg") for r in pos)
       and all(r.get("n") == sum((r.get("je_art") or {}).values()) for r in nul + pos),     # 23.70: der Rückblick kennt keinen Startkauf
       "Null p " + ", ".join("—" if p_ is None else f"{p_:.2f}" for p_ in pn) + " (Vorteil gegen Zufallszeiten "
       + ", ".join(f"{(r.get('vergleich') or {}).get('vorteil_pct', 0):+.1f} %" for r in nul) + ", Q "
       + ", ".join("—" if (r.get('timing') or {}).get('q') is None else f"{r['timing']['q']:+.1f} %" for r in nul) + "); Positiv p "
       + ", ".join("—" if p_ is None else f"{p_:.3f}" for p_ in pp) + " (Q "
       + ", ".join("—" if (r.get('timing') or {}).get('q') is None else f"{r['timing']['q']:+.1f} %" for r in pos) + ")")
    # 7) Ende zu Ende im Labor: synthetischer Dump (hl_swing-Markt „dip“), Heatmap-Cluster, Konten-Quote. 23.70 (U184): Der Coin läuft im
    # Labor seit 11 Tagen vor dem Dump (labor_zustand „coins“) -- beim ersten Takt die Rückrechnung mit dem Startkauf A0 zur Eröffnung der
    # ersten Minute ab dem Start; dazu ein frischer Speicher ohne früheren Start (A0 live) und ein Neustart ohne zweite Rückrechnung.
    import shutil
    import hl_anker
    db = os.path.join(tmp, "akku_m.db"); sw = os.path.join(tmp, "akku_swing.db")
    M = _swing_markt(db, sw, muster="dip", hl_tage=20)
    T0, Bt = M["T0"], M["B"]
    # 23.74 (U189): BTC in swing.db -- hier eine Kopie von SWG (Faktor 1, alle bisherigen Proben unverändert); sw3: BTC mit einem Drittel des
    # Log-Wegs von SWG (Faktor 3); sw0: ohne BTC (kein Faktor)
    sw3 = os.path.join(tmp, "akku_swing_f3.db"); sw0 = os.path.join(tmp, "akku_swing_ohne_btc.db")
    shutil.copy(sw, sw3); shutil.copy(sw, sw0)
    cs_ = sqlite3.connect(sw); cs_.execute("INSERT OR REPLACE INTO sw_klines SELECT 'BTC', ts, o, h, l, c, v FROM sw_klines WHERE coin='SWG'")
    cs_.commit(); cs_.close()
    cs_ = sqlite3.connect(sw3)
    cs_.create_function("dr", 1, lambda x: 100.0 * (x / 100.0) ** (1.0 / 3.0))
    cs_.execute("INSERT OR REPLACE INTO sw_klines SELECT 'BTC', ts, dr(o), dr(h), dr(l), dr(c), v FROM sw_klines WHERE coin='SWG'")
    cs_.commit(); cs_.close()
    t_start = T0 + (Bt - 11) * 86_400 + 3600; t_erst = T0 + Bt * 86_400 + 600
    db_k = os.path.join(tmp, "akku_m_konten.db"); shutil.copy(db, db_k)
    con = sqlite3.connect(db)
    t_c = None
    for ts_, cl_ in con.execute("SELECT ts, close FROM bars WHERE coin='SWG' AND ts>=? ORDER BY ts", (T0 + Bt * 86_400,)):
        if cl_ <= 97.6:
            t_c = int(ts_); break
    hm_rows = [(t_, "SWG", 97.0, "long", 2.4e6, 50) for t_ in range(t_c - 3600, t_c + 1, 600)] if t_c else []
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm_rows); con.commit()
    bar0 = con.execute("SELECT ts, open FROM bars WHERE coin='SWG' AND ts>=? ORDER BY ts LIMIT 1", (t_start,)).fetchone()
    tag_p = (t_start // 86_400) + 4                                    # ein nachgerechneter Tag (Tageszeile von Hand)
    bar_p = con.execute("SELECT ts, close FROM bars WHERE coin='SWG' AND ts>=? AND ts<? ORDER BY ts DESC LIMIT 1",
                        (tag_p * 86_400, (tag_p + 1) * 86_400)).fetchone()
    con.close()
    ck = sqlite3.connect(db_k)
    ck.execute("CREATE TABLE bnc_metrics (ts INTEGER, coin TEXT, metric TEXT, value REAL)")
    ck.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t_, "SWG", "global_ls_account", 3.2) for t_ in range(T0 + (Bt - 1) * 86_400, T0 + (Bt + 4) * 86_400, 900)])
    ck.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm_rows); ck.commit(); ck.close()
    anker_alt = hl_anker.jetzt
    hl_anker.jetzt = lambda con_, coin_, now_: {}
    erg = {}

    def _lesen(sp_):
        st_ = F.store_connect(sp_)
        try:
            return {"rows": st_.execute("SELECT s.name, k.ts, k.ausloeser, k.preis, k.mitte, k.usd, k.menge, k.gebuehr, k.werte, k.slip_bps FROM "
                                        "labor_akku_kauf k JOIN labor_strategie s ON s.sid=k.sid ORDER BY s.name, k.ts, k.id").fetchall(),
                    "grund": {(r[0], int(r[1])): r[2] for r in st_.execute("SELECT s.name, k.ts, k.grund FROM labor_akku_kauf k JOIN "
                                                                           "labor_strategie s ON s.sid=k.sid WHERE k.ausloeser='A0'")},
                    "gruende": st_.execute("SELECT s.name, k.ts, k.ausloeser, k.grund FROM labor_akku_kauf k JOIN labor_strategie s ON "
                                           "s.sid=k.sid ORDER BY s.name, k.ts, k.id").fetchall(),
                    "tage": st_.execute("SELECT s.name, t.tag, t.eingesetzt, t.menge, t.wert, t.px, t.n FROM labor_akku_tag t JOIN labor_strategie s "
                                        "ON s.sid=t.sid ORDER BY s.name, t.tag").fetchall(),
                    "ev": st_.execute("SELECT seite, COUNT(*) FROM labor_ereignis WHERE art='akku' GROUP BY seite").fetchall(),
                    "andere": st_.execute("SELECT COUNT(*) FROM labor_position").fetchone()[0],
                    "zustand": (st_.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone() or [""])[0]}
        finally:
            st_.close()
    try:
        for name, pfad, frueher, tage_ in (("haupt", db, True, 3), ("konten", db_k, True, 3), ("frisch", db, False, 1)):
            sp = os.path.join(tmp, f"akku_f_{name}.db")
            if frueher:                                                # der Coin läuft im Labor seit t_start (wie auf dem Pi seit Ende September)
                st = F.store_connect(sp); schema(st)
                st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
                st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),)); st.commit(); st.close()
            L = Labor(pfad, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, f"af_akku_{name}.db"), swing=sw)
            t_ = t_erst
            while t_ < t_erst - 600 + tage_ * 86_400:
                L.zyklus(t_); t_ += 900
            erg[name] = dict(_lesen(sp), fehler=list(L.fehler), daten=akku_daten(sp, pfad, L, t_, swing_pfad=sw), status=dict(L.akku_status), ende=t_)
            if name == "haupt":                                         # Neustart: keine zweite Rückrechnung, kein zweiter Startkauf
                L2 = Labor(pfad, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_neu.db"), swing=sw)
                L2.zyklus(t_); L2.zyklus(t_ + 900)
                erg["neustart"] = dict(_lesen(sp), fehler=list(L2.fehler))
        # 23.71 (U185): später Startkauf -- in den ersten 5 Stunden ab dem Start des Coins liegt der Kurs über der Sperre (Kerzen × 3); ein Takt
        db_s = os.path.join(tmp, "akku_m_spaet.db"); shutil.copy(db, db_s)
        cs = sqlite3.connect(db_s)
        cs.execute("UPDATE bars SET open=open*3, high=high*3, low=low*3, close=close*3 WHERE coin='SWG' AND ts>=? AND ts<?", (t_start, t_start + 5 * 3600))
        cs.commit()
        t_sp = cs.execute("SELECT MIN(ts) FROM bars WHERE coin='SWG' AND ts>=?", (t_start + 5 * 3600,)).fetchone()[0]
        cs.close()
        sp = os.path.join(tmp, "akku_f_spaet.db"); st = F.store_connect(sp); schema(st)
        st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
        st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),)); st.commit(); st.close()
        L3 = Labor(db_s, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_spaet.db"), swing=sw)
        L3.zyklus(t_erst)
        erg["spaet"] = dict(_lesen(sp), fehler=list(L3.fehler))
        # 23.72 (U186): (a) dieselbe Hauptrechnung ohne die Korrektur-Regel -- die Spur A0–A3 muss gleich bleiben
        alt_r = dict(AKKU_REGELN)
        for k_ in ("korr", "korr_h", "korr_tage"):
            AKKU_REGELN.pop(k_, None)
        try:
            sp = os.path.join(tmp, "akku_f_ohnekorr.db"); st = F.store_connect(sp); schema(st)
            st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
            st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),)); st.commit(); st.close()
            L4 = Labor(db, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_ohnekorr.db"), swing=sw)
            t_ = t_erst
            while t_ < t_erst - 600 + 3 * 86_400:
                L4.zyklus(t_); t_ += 900
            erg["ohne_korr"] = dict(_lesen(sp), fehler=list(L4.fehler), korr=[s_["regeln"].get("korr") for s_ in L4.akku_strategien])
        finally:
            AKKU_REGELN.clear(); AKKU_REGELN.update(alt_r)
        # (b) wie ZEC auf dem Pi: Kurs über der Sperre (Kerzen und Buch × 1,5), nach dem Start ein Einbruch um 8 % in 20 h, dann langsam
        # weiter auf −15 % (Nachkauf), Erholung, am Tag des Dumps live ein neuer Einbruch -- Korrekturkäufe ohne Sperre, A0–A3 gesperrt
        def g_(x):
            d_ = 86_400
            if x < 2 * d_ or x >= 10.5 * d_:
                return 0.0
            if x < 2 * d_ + 20 * 3600:
                return math.log(0.92) * (x - 2 * d_) / (20 * 3600)
            if x < 4 * d_:
                return math.log(0.92)
            if x < 9 * d_:
                return math.log(0.92) + (math.log(0.85) - math.log(0.92)) * (x - 4 * d_) / (5 * d_)
            if x < 10 * d_:
                return math.log(0.85)
            return math.log(0.85) * (1 - (x - 10 * d_) / (0.5 * d_))
        db_x = os.path.join(tmp, "akku_m_korr.db"); shutil.copy(db, db_x)
        cx = sqlite3.connect(db_x)
        fx = lambda ts_: 1.5 * math.exp(g_(int(ts_) - t_start))
        cx.executemany("UPDATE bars SET open=open*?, high=high*?, low=low*?, close=close*? WHERE coin='SWG' AND ts=?",
                       [(fx(r[0]),) * 4 + (r[0],) for r in cx.execute("SELECT ts FROM bars WHERE coin='SWG'").fetchall()])
        cx.executemany("UPDATE book_summary SET bid=bid*?, ask=ask*? WHERE coin='SWG' AND ts=?",
                       [(fx(r[0]), fx(r[0]), r[0]) for r in cx.execute("SELECT ts FROM book_summary WHERE coin='SWG'").fetchall()])
        cx.executemany("UPDATE ctx_bars SET mark_px=mark_px*?, oracle_px=oracle_px*?, mid_px=mid_px*? WHERE coin='SWG' AND ts=?",
                       [(fx(r[0]),) * 3 + (r[0],) for r in cx.execute("SELECT ts FROM ctx_bars WHERE coin='SWG'").fetchall()])
        cx.commit(); cx.close()
        sp = os.path.join(tmp, "akku_f_korr.db"); st = F.store_connect(sp); schema(st)
        st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
        st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),)); st.commit(); st.close()
        L5 = Labor(db_x, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_korr.db"), swing=sw)
        t_ = t_erst
        while t_ < t_erst - 600 + 2 * 86_400:
            L5.zyklus(t_); t_ += 900
        erg["korr"] = dict(_lesen(sp), fehler=list(L5.fehler), daten=akku_daten(sp, db_x, L5, t_, swing_pfad=sw), status=dict(L5.akku_status),
                           ende=t_, sid={s_["name"]: s_["sid"] for s_ in L5.akku_strategien})
        # (c) Tageskerzen erst im zweiten Takt (swing.db fehlt zunächst): vorher kein Korrekturkauf live -- sonst fiele die Rückrechnung aus.
        # 23.74 (U189): der Faktor steht schon im Speicher -- sonst hielte schon das Fehlen des Faktors den Kauf auf, und die Probe prüfte
        # die Bedingung „erst nach der Rückrechnung“ nicht mehr (Mutation u186_live_vor_rueckrechnung blieb grün)
        sp = os.path.join(tmp, "akku_f_spaetw.db"); st = F.store_connect(sp); schema(st)
        st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
        st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),))
        for s_ in strategien():
            if s_["name"] in AKKU_NAMEN:
                st.execute("INSERT INTO labor_akku_faktor VALUES (?,?,?,?,?,?,?,?,?,?,?)", (s_["sid"], "SWG", 1.0, 1.0, 0.01, 0.01, 300,
                           t_start // 86_400 * 86_400 - 365 * 86_400, t_start // 86_400 * 86_400, t_start, t_start))
        st.commit(); st.close()
        L6 = Labor(db_x, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_spaetw.db"), swing=os.path.join(tmp, "fehlt_swing.db"))
        t1w = t_start + 2 * 86_400 + 18 * 3600
        L6.zyklus(t1w)
        vor_w = _lesen(sp)["rows"]
        L6.swing_pfad = sw; L6.cache.pop(("SWG", "swing"), None)
        L6.zyklus(t1w + 900)
        erg["spaet_w"] = dict(_lesen(sp), fehler=list(L6.fehler), vor=vor_w, t1=t1w)
        # 23.74 (U189): Faktor im Labor -- derselbe Kursweg über der Sperre wie (b), aber tiefer: −25 % in 20 h, dann bis −40 %, Erholung,
        # am Tag des Dumps live weitere −15 % in 6 h. Mit BTC = SWG (Faktor 1) und mit BTC = ein Drittel des Wegs (Faktor 3)
        L0y = t_erst - t_start + 7200

        def g3_(x):
            d_ = 86_400
            if x >= L0y:
                return math.log(0.85) * min(1.0, (x - L0y) / (6 * 3600))
            if x < 2 * d_ or x >= 10.5 * d_:
                return 0.0
            if x < 2 * d_ + 20 * 3600:
                return math.log(0.75) * (x - 2 * d_) / (20 * 3600)
            if x < 4 * d_:
                return math.log(0.75)
            if x < 9 * d_:
                return math.log(0.75) + (math.log(0.60) - math.log(0.75)) * (x - 4 * d_) / (5 * d_)
            if x < 10 * d_:
                return math.log(0.60)
            return math.log(0.60) * (1 - (x - 10 * d_) / (0.5 * d_))
        db_y = os.path.join(tmp, "akku_m_faktor.db"); shutil.copy(db, db_y)
        cy = sqlite3.connect(db_y)
        fy = lambda ts_: 1.5 * math.exp(g3_(int(ts_) - t_start))
        cy.executemany("UPDATE bars SET open=open*?, high=high*?, low=low*?, close=close*? WHERE coin='SWG' AND ts=?",
                       [(fy(r[0]),) * 4 + (r[0],) for r in cy.execute("SELECT ts FROM bars WHERE coin='SWG'").fetchall()])
        cy.executemany("UPDATE book_summary SET bid=bid*?, ask=ask*? WHERE coin='SWG' AND ts=?",
                       [(fy(r[0]), fy(r[0]), r[0]) for r in cy.execute("SELECT ts FROM book_summary WHERE coin='SWG'").fetchall()])
        cy.executemany("UPDATE ctx_bars SET mark_px=mark_px*?, oracle_px=oracle_px*?, mid_px=mid_px*? WHERE coin='SWG' AND ts=?",
                       [(fy(r[0]),) * 3 + (r[0],) for r in cy.execute("SELECT ts FROM ctx_bars WHERE coin='SWG'").fetchall()])
        cy.commit(); cy.close()
        for name, swp in (("f1", sw), ("f3", sw3), ("f0", sw0)):
            sp = os.path.join(tmp, f"akku_f_faktor_{name}.db"); st = F.store_connect(sp); schema(st)
            st.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(t_start),))
            st.execute("INSERT INTO labor_zustand VALUES ('coins', ?)", (_j({"SWG": t_start}),)); st.commit(); st.close()
            Ly = Labor(db_y, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, f"af_akku_faktor_{name}.db"), swing=swp)
            t_ = t_erst
            while t_ < t_erst - 600 + (1 if name == "f0" else 2) * 86_400:
                Ly.zyklus(t_); t_ += 900
            stf = F.store_connect(sp)
            fz = stf.execute("SELECT s.name, f.faktor, f.roh, f.sigma, f.sigma_basis, f.n, f.von, f.bis, f.start FROM labor_akku_faktor f JOIN "
                             "labor_strategie s ON s.sid=f.sid ORDER BY s.name").fetchall()
            stf.close()
            be_ = None
            if name == "f3":                                           # Bericht wie auf dem Pi: swing.db neben der Hauptdatenbank
                d_b = os.path.join(tmp, "akku_bericht_f3"); os.makedirs(d_b, exist_ok=True)
                shutil.copy(db_y, os.path.join(d_b, "hl_liq.db")); shutil.copy(sw3, os.path.join(d_b, "swing.db"))
                be_ = akku_bericht(sp, os.path.join(d_b, "hl_liq.db"), t_)
            erg["faktor_" + name] = dict(_lesen(sp), fehler=list(Ly.fehler), daten=akku_daten(sp, db_y, Ly, t_, swing_pfad=swp), ende=t_,
                                         status=dict(Ly.akku_status), sid={s_["name"]: s_["sid"] for s_ in Ly.akku_strategien}, fz=fz,
                                         bericht=be_)
            if name == "f3":                                           # fest: Neustart mit geänderter swing.db (BTC = SWG) -- Faktor bleibt 3
                Lz = Labor(db_y, sp, coins=("SWG",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_akku_faktor_fest.db"), swing=sw)
                Lz.zyklus(t_); Lz.zyklus(t_ + 900)
                stf = F.store_connect(sp)
                fz2 = stf.execute("SELECT s.name, f.faktor FROM labor_akku_faktor f JOIN labor_strategie s ON s.sid=f.sid ORDER BY s.name").fetchall()
                stf.close()
                erg["faktor_fest"] = dict(_lesen(sp), fehler=list(Lz.fehler), fz=fz2, status=dict(Lz.akku_status),
                                          sid={s_["name"]: s_["sid"] for s_ in Lz.akku_strategien})
    finally:
        hl_anker.jetzt = anker_alt
    # 7-Tage-Hoch live von Hand: Fenster [t − 7 T, t], ohne spätere Kerzen, mindestens der Kurs jetzt
    db_h = os.path.join(tmp, "akku_h7.db"); ch = sqlite3.connect(db_h)
    ch.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin))")
    T_h = 1_800_000_000 // 60 * 60
    ch.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", [(T_h - 7 * 86_400 - 60, "HX", 1, 130.0, 1, 1, 1, 1), (T_h - 7 * 86_400 + 60, "HX", 1, 105.0, 1, 1, 1, 1),
                                                                  (T_h - 3 * 86_400, "HX", 1, 100.0, 1, 1, 1, 1), (T_h - 60, "HX", 1, 98.0, 1, 1, 1, 1),
                                                                  (T_h + 600, "HX", 1, 120.0, 1, 1, 1, 1)])
    ch.commit()
    L_h = Labor(db_h, os.path.join(tmp, "akku_h7_f.db"), coins=("HX",), nur=AKKU_NAMEN, adressfluss=os.path.join(tmp, "af_h7.db"), swing=sw)
    h7_a = L_h._akku_h7(ch, "HX", T_h, 95.0); h7_b = Labor._akku_h7(L_h, ch, "HX", T_h + 30, 140.0)
    # 23.72 (U186): 48-Stunden-Hoch live -- Fenster [t − 48 h, t] mit der laufenden Minute; nach einem Korrekturkauf erst ab der Minute danach
    ch.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", [(T_h - 48 * 3600 - 60, "HK", 1, 130.0, 1, 1, 1, 1), (T_h - 48 * 3600 + 60, "HK", 1, 105.0, 1, 1, 1, 1),
                                                                  (T_h - 7200, "HK", 1, 101.0, 1, 1, 1, 1), (T_h - 3600, "HK", 1, 98.0, 1, 1, 1, 1),
                                                                  (T_h, "HK", 1, 97.0, 1, 1, 1, 1), (T_h + 600, "HK", 1, 120.0, 1, 1, 1, 1)])
    ch.commit()
    h48 = [L_h._akku_h48(ch, "HK", T_h + 30, None), L_h._akku_h48(ch, "HK", T_h + 30, T_h - 7200 + 60), L_h._akku_h48(ch, "HK", T_h + 30, T_h - 3600 + 60),
           L_h._akku_h48(ch, "HK", T_h + 30, T_h + 60), L_h._akku_h48(ch, "HK", T_h + 30, None)]
    ch.close()
    ok("Akkumulation: 7-Tage-Hoch live von Hand (Hoch im Fenster [t − 7 T, t]; davor und danach zählt nicht; mindestens der Kurs jetzt)",
       h7_a == 105.0 and h7_b == 140.0, f"{h7_a} / {h7_b}")
    ok("Akkumulation: 48-Stunden-Hoch live von Hand (Fenster [t − 48 h, t] samt laufender Minute; nach einem Korrekturkauf erst ab der Minute "
       "danach; davor und danach zählt nicht; gecacht gleich)", h48 == [105.0, 98.0, 97.0, None, 105.0], f"{h48}")

    def _kaeufe(name, strat, spur="R"):                                 # 23.72: Spur A0–A3 („R“), Korrekturkäufe („K“) oder alle (None)
        return [r for r in erg[name]["rows"] if r[0] == strat and (spur is None or (r[2] == "A4") == (spur == "K"))]
    h_ = erg["haupt"]; k_ = erg["konten"]; f_ = erg["frisch"]
    z_ohne = _kaeufe("haupt", "akku_ohne_cluster"); z_mit = _kaeufe("haupt", "akku"); z_kon = _kaeufe("konten", "akku"); z_fr = _kaeufe("frisch", "akku")
    za_mit = _kaeufe("haupt", "akku", None)
    USD, GEB = AKKU_REGELN["usd"], AKKU_REGELN["usd"] * AKKU_REGELN["geb"]
    betrag_soll = USD == 5_000.0 and abs(GEB - 3.5) < 1e-12                 # 23.70 (U184, Nutzer 19.10. 23:20): 5.000 USD je Kauf

    def _betrag_ok(z):
        return all(abs(r[5] - USD) < 1e-9 and abs(r[6] - (USD - GEB) / r[3]) < 1e-9 and abs(r[7] - GEB) < 1e-9 for r in z)

    def _start_nach(z, gr):                                             # A0 nachgerechnet: erste Minute ab dem Start, zur Eröffnung
        if not z or z[0][2] != "A0" or not bar0:
            return False
        w = json.loads(z[0][8] or "{}")
        nach_ = [r for r in z if json.loads(r[8] or "{}").get("nachgerechnet")]
        if gr.get((z[0][0], int(z[0][1]))) != "nachgerechnet (1-min-Kerzen): " + AKKU_A0_TEXT.format(ab=_uhr(t_start)):
            return False                                                # 23.71 (U185): Grund in der neuen Fassung, ohne Verzug
        return (int(z[0][1]) == int(bar0[0]) and abs(z[0][3] - float(bar0[1])) < 1e-12 and z[0][9] is None and w.get("nachgerechnet") is True
                and w.get("ab") == t_start and all(int(r[1]) >= t_erst for r in z[1:]) and all(int(r[1]) < t_erst for r in nach_))

    def _stufen_ok(z):                                                  # nach dem ersten Kauf nach den Regeln je σ₇ tiefer
        if len(z) < 3:
            return False
        for a_, b_ in zip(z, z[1:]):
            w = json.loads(b_[8] or "{}")
            if not (b_[2] == "A3" and b_[4] <= a_[3] * math.exp(-w["sigma7"]) + 1e-9):
                return False
        return True
    w1 = json.loads(z_ohne[1][8]) if len(z_ohne) > 1 else {}
    s7_soll = h7_soll = None
    if len(z_ohne) > 1:                                                 # σ₇ und 7-Tage-Hoch des ersten Kaufs nach den Regeln unabhängig nachgerechnet
        t_b = int(z_ohne[1][1]); W_b = SW.labor_daten(sw, "SWG", t_b)
        s7_soll = W_b["sigma"] * math.sqrt(7) if W_b.get("ok") and W_b.get("sigma") else None
        cb = sqlite3.connect(db)
        try:
            hb = cb.execute("SELECT MAX(high) FROM bars WHERE coin='SWG' AND ts>=? AND ts<=?", (t_b - 7 * 86_400, t_b)).fetchone()[0]
        finally:
            cb.close()
        h7_soll = max(float(hb), float(z_ohne[1][4])) if hb else None
    ga = (h_["daten"]["strategien"] or [{}])
    bil = {s["name"]: s for s in ga}
    b_mit = (bil.get("akku") or {}).get("je_coin", {}).get("SWG", {})
    tz_p = [r for r in h_["tage"] if r[0] == "akku" and r[1] == tag_p]
    m0 = (USD - GEB) / float(bar0[1]) if bar0 else 0.0
    ok("Akkumulation im Labor: Rückrechnung ab dem Start des Coins (A0 zur Eröffnung der ersten Minute, Tageszeilen, Ereignisse „spot“), "
       "dann live: Dump → A1 (ohne Heatmap) bzw. A2 am Cluster, Nachkäufe je σ₇; Konten ≥ 3 → kein Kauf am Cluster; 5.000 USD, Spot-Gebühr",
       betrag_soll and _start_nach(z_ohne, h_["grund"]) and _start_nach(z_mit, h_["grund"]) and _start_nach(z_kon, k_["grund"])
       and len(z_ohne) > 1 and z_ohne[1][2] == "A1" and z_ohne[1][4] <= w1["schwellen"]["a1"] + 1e-9 and _stufen_ok(z_ohne[1:])
       and s7_soll is not None and abs(w1["sigma7"] - s7_soll) < 1e-12 and h7_soll is not None and abs(w1["h7"] - h7_soll) < 1e-9
       and len(z_mit) > 1 and z_mit[1][2] == "A2" and abs(z_mit[1][4] / 97.0 - 1) < 0.003 and z_mit[1][3] > z_ohne[1][3] and _stufen_ok(z_mit[1:])
       and len(z_kon) > 1 and z_kon[1][2] == "A1" and abs(z_kon[1][3] - z_ohne[1][3]) < 1e-6
       and _betrag_ok(z_ohne + z_mit + z_kon) and h_["ev"] == [("spot", len(h_["rows"]))] and h_["andere"] == 0 and not h_["fehler"] and not k_["fehler"]
       and len(tz_p) == 1 and bar_p and abs(tz_p[0][2] - USD) < 1e-9 and abs(tz_p[0][3] - m0) < 1e-9 and abs(tz_p[0][4] - m0 * float(bar_p[1])) < 1e-6
       and tz_p[0][6] == 1 and len([r for r in h_["tage"] if r[0] == "akku"]) >= 13
       and b_mit.get("n") == len(za_mit) and abs(b_mit["eingesetzt"] - USD * len(za_mit)) < 1e-9 and b_mit.get("n_nach") == 1
       and b_mit.get("n_regel") == len(z_mit) - 1 and b_mit.get("ab") == t_start and bil["akku"].get("ab") == t_start
       and (b_mit.get("vergleich") or {}).get("n") == len(z_mit) - 1 and all(r[4] < 98.1 for r in z_mit[1:]),
       f"Start {(t_start - T0) / 86_400:.3f} (Tag), A0 {z_ohne[0][3] if z_ohne else 0:.4f} zur Eröffnung {float(bar0[1]) if bar0 else 0:.4f}; ohne Heatmap "
       f"{len(z_ohne)} Käufe, live ab {z_ohne[1][3] if len(z_ohne) > 1 else 0:.3f} ({z_ohne[1][2] if len(z_ohne) > 1 else '—'}); mit Heatmap {len(z_mit)}, "
       f"live ab {z_mit[1][3] if len(z_mit) > 1 else 0:.3f} ({z_mit[1][2] if len(z_mit) > 1 else '—'}); Konten 3,2: {z_kon[1][2] if len(z_kon) > 1 else '—'}; "
       f"Tageszeilen {len(h_['tage'])}, Ereignisse {h_['ev']}, Vergleich n {(b_mit.get('vergleich') or {}).get('n')}; Fehler: "
       f"{'; '.join((h_['fehler'] + k_['fehler'])[-2:]) or 'keine'}")
    # 23.72 (U186): Korrekturkäufe -- unabhängig nachgerechnet je Takt (Mitte aus dem Buch, Hoch der letzten 48 h bis jetzt, nach einem
    # Korrekturkauf ab der Minute danach, Bezug mit dem letzten Korrekturkauf binnen 14 Tagen)
    def _korr_live_soll(dbp, k_rows, t_von, t_bis, q=1 - 0.07):
        cq = sqlite3.connect(dbp)
        try:
            vorher = [r for r in k_rows if int(r[1]) < t_von]
            lk = (int(vorher[-1][1]), float(vorher[-1][3])) if vorher else None
            soll = []; tau = t_von
            while tau < t_bis:
                rb = cq.execute("SELECT bid, ask FROM book_summary WHERE coin='SWG' AND ts>=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                                (tau - BUCH_MAX_ALTER, tau)).fetchone()
                mid_ = (rb[0] + rb[1]) / 2 if rb else None
                a_ = max(tau - 48 * 3600, (lk[0] // 60 * 60 + 60) if lk else 0)
                hb = cq.execute("SELECT MAX(high) FROM bars WHERE coin='SWG' AND ts>=? AND ts<=?", (a_, tau)).fetchone()[0]
                kand = [v for v in (hb, lk[1] if (lk and tau - lk[0] < 14 * 86_400) else None) if v]
                if mid_ and kand and mid_ <= q * max(kand):
                    gek = [r for r in k_rows if int(r[1]) == tau]
                    soll.append((tau, round(max(kand), 9)))
                    lk = (tau, float(gek[0][3]) if gek else mid_)
                tau += 900
            return soll
        finally:
            cq.close()
    zk_mit = _kaeufe("haupt", "akku", "K")
    soll_h = _korr_live_soll(db, zk_mit, t_erst, h_["ende"])
    sig_k = lambda z: [(int(r[1]), round(r[3], 9)) for r in z]
    ok("Akkumulation im Labor: Korrekturkäufe live am Dump (7 % unter dem 48-h-Hoch, dann je 7 % tiefer) gleich der unabhängigen Takt-Rechnung; "
       "Kontrolle und Konten-Lauf gleich (keine Heatmap- und Kontenregel für A4); 5.000 USD zum Ask",
       len(soll_h) >= 2 and [(int(r[1]), round(json.loads(r[8])["bezug"], 9)) for r in zk_mit] == soll_h
       and json.loads(zk_mit[0][8])["bezug_art"] == "hoch48" and sig_k(zk_mit) == sig_k(_kaeufe("haupt", "akku_ohne_cluster", "K"))
       and sig_k(zk_mit) == sig_k(_kaeufe("konten", "akku", "K")) and all(r[3] > r[4] and r[9] is not None for r in zk_mit) and _betrag_ok(zk_mit),
       f"{len(zk_mit)} Korrekturkäufe: " + ", ".join(f"{_uhr(int(r[1]))} {r[3]:.3f} (Bezug {json.loads(r[8])['bezug']:.3f})" for r in zk_mit)
       + f"; unabhängig {len(soll_h)}")
    oc = erg["ohne_korr"]
    r_h = [(r[0], int(r[1]), r[2], round(r[3], 9)) for r in h_["rows"] if r[2] != "A4"]
    r_o = [(r[0], int(r[1]), r[2], round(r[3], 9)) for r in oc["rows"]]
    ok("Akkumulation im Labor: Korrekturkauf als eigene Spur -- ohne die Regel dieselben Käufe A0–A3 auf die Minute und den Preis gleich",
       oc["korr"] == [None, None] and len(r_o) >= 10 and r_h == r_o and not any(r[2] == "A4" for r in oc["rows"]) and not oc["fehler"],
       f"mit Regel {len(r_h)} Käufe A0–A3 (+{len(h_['rows']) - len(r_h)} Korrektur), ohne Regel {len(r_o)}; gleich {r_h == r_o}")
    x_ = erg["korr"]
    zx = [r for r in x_["rows"] if r[0] == "akku"]; zx2 = [r for r in x_["rows"] if r[0] == "akku_ohne_cluster"]
    kx_nach = [r for r in zx if json.loads(r[8] or "{}").get("nachgerechnet")]; kx_live = [r for r in zx if not json.loads(r[8] or "{}").get("nachgerechnet")]
    cxr = sqlite3.connect(db_x)
    bx = np.array(cxr.execute("SELECT ts, open, high, low, close FROM bars WHERE coin='SWG' AND ts>=? AND ts<? ORDER BY ts",
                              (t_start - 7 * 86_400, t_erst // 60 * 60)).fetchall(), dtype=float)
    cxr.close()
    ref_x = _korr_ref(AKKU_REGELN, bx[:, 0].astype(np.int64), bx[:, 1], bx[:, 2], bx[:, 3], t_start)
    soll_x = _korr_live_soll(db_x, zx, t_erst, x_["ende"])
    dx = next((s_ for s_ in x_["daten"]["strategien"] if s_["name"] == "akku"), {}); bxs = (dx.get("je_coin") or {}).get("SWG", {})
    stx = x_["status"].get((x_["sid"]["akku"], "SWG")) or {}
    gx = [g for n_g, t_g, a_g, g in x_["gruende"] if n_g == "akku"]
    ok("Akkumulation im Labor: wie ZEC -- Kurs über der Sperre: kein Kauf A0–A3, aber Korrekturkäufe ohne Sperre, rückwirkend (gleich der "
       "Referenzrechnung auf den Kerzen) und live (gleich der unabhängigen Takt-Rechnung); Bilanz, Lage, Ereignisse",
       zx and all(r[2] == "A4" for r in zx) and sig_k(zx) == sig_k(zx2) and len(ref_x) >= 2 and len(kx_nach) == len(ref_x)
       and sig_k(kx_nach) == [(a_, round(b_, 9)) for a_, b_ in ref_x] and len(soll_x) >= 1
       and [(int(r[1]), round(json.loads(r[8])["bezug"], 9)) for r in kx_live] == soll_x and all(r[3] > r[4] for r in kx_live) and _betrag_ok(zx)
       and gx and gx[0].startswith("nachgerechnet (1-min-Kerzen): Korrektur: Tief ≤") and any("Korrektur, Nachkauf: Tief ≤" in g for g in gx[:len(kx_nach)])
       and bxs.get("n_korr") == len(zx) and bxs.get("n_regel") == 0 and bxs.get("vergleich") is None and dx.get("n_korr") == len(zx) + 0
       and (stx.get("korrektur") or {}).get("schwelle") and x_["ev"] == [("spot", len(x_["rows"]))] and not x_["fehler"],
       f"rückwirkend {len(kx_nach)} (Referenz {len(ref_x)}): " + ", ".join(f"{_uhr(int(r[1]))} {r[3]:.3f}" for r in kx_nach) + f"; live {len(kx_live)} "
       f"(unabhängig {len(soll_x)}); A0–A3 {sum(1 for r in zx if r[2] != 'A4')}; Fehler {x_['fehler'][-1:] or 'keine'}")
    w_ = erg["spaet_w"]; zw = [r for r in w_["rows"] if r[0] == "akku"]
    cxr = sqlite3.connect(db_x)
    bw = np.array(cxr.execute("SELECT ts, open, high, low, close FROM bars WHERE coin='SWG' AND ts>=? AND ts<? ORDER BY ts",
                              (t_start - 7 * 86_400, (w_["t1"] + 900) // 60 * 60)).fetchall(), dtype=float)
    cxr.close()
    ref_w = _korr_ref(AKKU_REGELN, bw[:, 0].astype(np.int64), bw[:, 1], bw[:, 2], bw[:, 3], t_start)
    ok("Akkumulation im Labor: Tageskerzen erst im zweiten Takt (Faktor schon gespeichert) -- vorher kein Korrekturkauf, danach die "
       "Rückrechnung mit allen Korrekturkäufen seit dem Start (gleich der Referenzrechnung)",
       w_["vor"] == [] and len(ref_w) >= 1 and sig_k(zw) == [(a_, round(b_, 9)) for a_, b_ in ref_w]
       and all(json.loads(r[8] or "{}").get("nachgerechnet") for r in zw) and not w_["fehler"],
       f"vorher {len(w_['vor'])} Käufe; danach {len(zw)} (Referenz {len(ref_w)}): " + ", ".join(f"{_uhr(int(r[1]))} {r[3]:.3f}" for r in zw)
       + f"; Fehler {w_['fehler'][-1:] or 'keine'}")
    # 23.74 (U189): Faktor im Labor -- Faktor 3 gespeichert und fest, Beträge 5.000 ÷ 3, Schwellen 0,93³ rückwirkend (Referenz) und live
    # (unabhängige Takt-Rechnung), Tabelle in den Daten und im Bericht; mit Faktor 1 dieselbe Regel wie bisher; ohne BTC kein Kauf
    y1 = erg["faktor_f1"]; y3 = erg["faktor_f3"]; y0 = erg["faktor_f0"]; yf = erg["faktor_fest"]
    z1 = [r for r in y1["rows"] if r[0] == "akku"]; z3 = [r for r in y3["rows"] if r[0] == "akku"]; z3k = [r for r in y3["rows"] if r[0] == "akku_ohne_cluster"]
    U3 = 5_000.0 / 3; G3 = U3 * AKKU_REGELN["geb"]
    cyr = sqlite3.connect(db_y)
    by = np.array(cyr.execute("SELECT ts, open, high, low, close FROM bars WHERE coin='SWG' AND ts>=? AND ts<? ORDER BY ts",
                              (t_start - 7 * 86_400, t_erst // 60 * 60)).fetchall(), dtype=float)
    cyr.close()
    ref3 = _korr_ref(AKKU_REGELN, by[:, 0].astype(np.int64), by[:, 1], by[:, 2], by[:, 3], t_start, 0.93 ** 3)
    ref1 = _korr_ref(AKKU_REGELN, by[:, 0].astype(np.int64), by[:, 1], by[:, 2], by[:, 3], t_start)
    nachg = lambda r: bool(json.loads(r[8] or "{}").get("nachgerechnet"))
    k3 = [r for r in z3 if r[2] == "A4"]; k1 = [r for r in z1 if r[2] == "A4"]          # bei −25 % fällt der Kurs unter die Sperre: auch A0–A3
    z3_nach = [r for r in k3 if nachg(r)]; z3_live = [r for r in k3 if not nachg(r)]; z1_nach = [r for r in k1 if nachg(r)]
    soll3 = _korr_live_soll(db_y, k3, t_erst, y3["ende"], 0.93 ** 3)
    d3 = next((s_ for s_ in y3["daten"]["strategien"] if s_["name"] == "akku"), {}); w3 = ((d3.get("je_coin") or {}).get("SWG") or {}).get("schwelle") or {}
    g3 = [g for n_g, t_g, a_g, g in y3["gruende"] if n_g == "akku"]
    zb3 = [z_ for z_ in (y3["bericht"] or []) if z_.startswith("    SWG  Faktor 3,00")]
    ok("Akkumulation im Labor: Faktor 3 (BTC mit einem Drittel des Wegs) -- für beide Strategien gespeichert (365 Tage vor dem Start), alle Käufe "
       "1.666,67 USD, Korrekturkäufe rückwirkend gleich der Referenzrechnung mit 0,93³ und live gleich der unabhängigen Takt-Rechnung, Tabelle in "
       "den Daten und im Bericht; mit Faktor 1 derselbe Weg wie bisher (Referenz mit 7 %, mehr Käufe zu 5.000 USD)",
       [r[0] for r in y3["fz"]] == ["akku", "akku_ohne_cluster"]
       and all(r[1] == 3.0 and abs(r[2] - 3.0) < 1e-9 and abs(r[3] / r[4] - 3.0) < 1e-9 and r[5] >= 60 and r[7] == t_start // 86_400 * 86_400
               and r[6] == r[7] - 365 * 86_400 and r[8] == t_start for r in y3["fz"])
       and z3 and any(r[2] != "A4" for r in z3) and all(abs(r[5] - U3) < 1e-9 and abs(r[7] - G3) < 1e-9 and abs(r[6] - (U3 - G3) / r[3]) < 1e-9 for r in z3)
       and len(ref3) >= 2 and sig_k(z3_nach) == [(a_, round(b_, 9)) for a_, b_ in ref3]
       and len(soll3) >= 1 and [(int(r[1]), round(json.loads(r[8])["bezug"], 9)) for r in z3_live] == soll3
       and sig_k(k3) == sig_k([r for r in z3k if r[2] == "A4"])
       and all(json.loads(r[8] or "{}").get("faktor") == 3.0 for r in z3)
       and any("19,6 % unter dem Hoch der letzten 48 h" in g for g in g3) and not any("7 % unter dem" in g for g in g3)
       and sig_k(z1_nach) == [(a_, round(b_, 9)) for a_, b_ in ref1] and len(k1) > 2 * len(k3) and all(abs(r[5] - 5_000.0) < 1e-9 for r in z1)
       and [r[1] for r in y1["fz"]] == [1.0, 1.0]
       and w3.get("faktor") == 3.0 and abs((w3.get("usd") or 0) - U3) < 1e-9 and abs((w3.get("a4_pct") or 0) - (1 - 0.93 ** 3) * 100) < 1e-9
       and w3.get("a1_pct") and w3.get("a3_pct") and w3.get("sperre") and w3.get("n") == y3["fz"][0][5]
       and len(zb3) == 1 and "1.667 USD je Kauf" in zb3[0] and "A4 ab −19,6 %" in zb3[0]
       and f"A1 −{_de(w3.get('a1_pct') or 0, 1)} %" in zb3[0] and f"A3 je −{_de(w3.get('a3_pct') or 0, 1)} %" in zb3[0]
       and f"Sperre ab {_g6(w3.get('sperre') or 0)}" in zb3[0] and "(σ_Tag 0,75 % gegen 0,25 %, 311 Tage)" in zb3[0]
       and not y3["fehler"] and not y1["fehler"],
       f"Faktor {[(r[0], r[1], r[5]) for r in y3['fz']]}; mit Faktor 3: {len(z3)} Käufe, davon {len(k3)} Korrektur ({len(z3_nach)} rückwirkend, "
       f"Referenz {len(ref3)}; {len(z3_live)} live, unabhängig {len(soll3)}), je {z3[0][5] if z3 else 0:.2f} USD; mit Faktor 1: {len(z1)} Käufe, "
       f"davon {len(k1)} Korrektur ({len(z1_nach)} rückwirkend, Referenz {len(ref1)}); Bericht: {zb3[0].strip() if zb3 else '—'}; Fehler "
       f"{(y3['fehler'] + y1['fehler'])[-1:] or 'keine'}")
    stf_ = (yf["status"].get((yf["sid"]["akku"], "SWG")) or {}).get("faktor") or {}
    st0 = y0["status"].get((y0["sid"]["akku"], "SWG")) or {}
    ok("Akkumulation im Labor: Faktor fest (Neustart mit geänderter swing.db: bleibt 3, neue Käufe weiter 1.666,67 USD); ohne BTC in swing.db kein "
       "Faktor, kein Kauf, kein Fehler, Grund in der Lage",
       yf["fz"] == [("akku", 3.0), ("akku_ohne_cluster", 3.0)] and stf_.get("faktor") == 3.0 and stf_.get("fest")
       and all(abs(r[5] - U3) < 1e-9 for r in yf["rows"]) and len(yf["rows"]) >= len(y3["rows"]) and not yf["fehler"]
       and y0["rows"] == [] and y0["fz"] == [] and not y0["fehler"]
       and (st0.get("grund") or "").startswith("wartet: Faktor gegenüber BTC fehlt (zu wenige Tage mit Kursen von Coin und BTC (0 von mindestens 60))"),
       f"nach dem Neustart {yf['fz']}, {len(yf['rows'])} Käufe; ohne BTC: {len(y0['rows'])} Käufe, „{st0.get('grund')}“")
    n_ = erg["neustart"]
    ok("Akkumulation im Labor: Neustart ohne zweite Rückrechnung und ohne zweiten Startkauf; Rückrechnung im Zustand vermerkt",
       n_["rows"] == h_["rows"] and [r for r in n_["tage"] if r[1] < h_["ende"] // 86_400] == [r for r in h_["tage"] if r[1] < h_["ende"] // 86_400]
       and not n_["fehler"] and '"nach":{"ab":' in h_["zustand"],
       f"{len(n_['rows'])} Käufe nach dem Neustart (vorher {len(h_['rows'])}); Fehler {n_['fehler'][-1:] or 'keine'}")
    # 23.71 (U185): derselbe Speicher mit den Texten aus 23.70 (Kopie) -- Kauf und Ereignis in der Anzeige in der neuen Fassung, die
    # gespeicherten Texte bleiben, die übrigen Gründe unverändert
    sp_a = os.path.join(tmp, "akku_f_haupt.db"); sp_70 = os.path.join(tmp, "akku_f_alt70.db"); shutil.copy(sp_a, sp_70)
    alt70 = "Startkauf zum Start des Coins im Labor (" + _uhr(t_start) + ")"
    neu71 = AKKU_A0_TEXT.format(ab=_uhr(t_start))
    c70 = sqlite3.connect(sp_70)
    c70.execute("UPDATE labor_akku_kauf SET grund=replace(grund, ?, ?) WHERE ausloeser='A0'", (neu71, alt70))
    c70.execute("UPDATE labor_ereignis SET text=replace(text, ?, ?) WHERE art='akku'", (neu71, alt70)); c70.commit()
    g70 = [r[0] for r in c70.execute("SELECT grund FROM labor_akku_kauf WHERE ausloeser='A0'")]
    e70 = [r[0] for r in c70.execute("SELECT text FROM labor_ereignis WHERE art='akku' AND text LIKE '%A0:%'")]
    c70.close()
    d70 = akku_daten(sp_70, db, None, h_["ende"], vergleich=False, swing_pfad=sw)
    d71 = akku_daten(sp_a, db, None, h_["ende"], vergleich=False, swing_pfad=sw)
    lose70 = [k for s in d70["strategien"] for b in s["je_coin"].values() for k in b["lose"]]
    lose71 = [k for s in d71["strategien"] for b in s["je_coin"].values() for k in b["lose"]]
    u70 = uebersicht(sp_70, {}, h_["ende"]); u71 = uebersicht(sp_a, {}, h_["ende"])
    ev70 = [e["text"] for e in u70["ereignisse"] if e["art"] == "akku"]; ev71 = [e["text"] for e in u71["ereignisse"] if e["art"] == "akku"]
    c70 = sqlite3.connect(sp_70)
    g70b = [r[0] for r in c70.execute("SELECT grund FROM labor_akku_kauf WHERE ausloeser='A0'")]
    c70.close()
    # 23.72 (U186): ein früherer Regelstand (inaktiv) -- seine Käufe heißen in den Ereignissen „… (alte Regeln)“, die laufenden nicht
    sp_70i = os.path.join(tmp, "akku_f_alt70_inaktiv.db"); shutil.copy(sp_70, sp_70i)
    c70 = sqlite3.connect(sp_70i); c70.execute("UPDATE labor_strategie SET aktiv=0 WHERE name='akku'"); c70.commit(); c70.close()
    u70i = uebersicht(sp_70i, {}, h_["ende"])
    tit_i = {(e["titel"]) for e in u70i["ereignisse"] if e["art"] == "akku"}
    alt_ok = tit_i == {"Akkumulation (alte Regeln)", "Akkumulation ohne Heatmap (Kontrolle)"}
    # 23.73 (U187): Bericht mit einem früheren Regelstand gleichen Namens -- die laufenden zuerst und ausführlich, der frühere in einer
    # Zeile mit „(alte Regeln)“ und ohne Zeilen je Coin
    sp_b = os.path.join(tmp, "akku_f_bericht_alt.db"); shutil.copy(sp_a, sp_b)
    cb_ = sqlite3.connect(sp_b)
    cb_.execute("INSERT INTO labor_strategie SELECT 'akku@alt00001', name, titel, gruppe, regeln, beschreibung, erstellt - 86400, 0 FROM labor_strategie "
                "WHERE name='akku' AND aktiv=1")
    cb_.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte) "
                "SELECT 'akku@alt00001', coin, ts, ausloeser, preis, mitte, usd, menge, gebuehr, slip_bps, grund, werte FROM labor_akku_kauf "
                "WHERE ausloeser='A0' AND sid=(SELECT sid FROM labor_strategie WHERE name='akku' AND aktiv=1)")
    cb_.commit(); cb_.close()
    be_b = akku_bericht(sp_b, db, h_["ende"])
    kopf_b = [z_ for z_ in be_b if z_.startswith("  Akkumulation")]
    i_alt = next((i for i, z_ in enumerate(be_b) if z_.startswith("  Akkumulation (alte Regeln): 1 Kauf seit")), None)
    bericht_alt_ok = (len(kopf_b) == 3 and kopf_b[0].startswith("  Akkumulation: ") and kopf_b[1].startswith("  Akkumulation ohne Heatmap (Kontrolle): ")
                      and kopf_b[2].startswith("  Akkumulation (alte Regeln): ") and "frühere Kennung akku@alt00001, kauft nicht mehr" in kopf_b[2]
                      and i_alt is not None and i_alt + 1 < len(be_b) and be_b[i_alt + 1] == "  " + AKKU_HINWEIS)
    sp_70a = os.path.join(tmp, "akku_f_alt70_a0.db"); shutil.copy(sp_70, sp_70a)        # nur die Startkäufe: der Bericht zeigt die 8 jüngsten
    c70 = sqlite3.connect(sp_70a); c70.execute("DELETE FROM labor_akku_kauf WHERE ausloeser<>'A0'"); c70.commit(); c70.close()
    be70 = akku_bericht(sp_70a, db, h_["ende"])                         # Bericht: der Startkauf-Grund ganz, nicht mitten im Satz abgeschnitten
    be_ok = sum(1 for z_ in be70 if z_.endswith(neu71)) == 2
    ok("Akkumulation: Anzeige eines Speichers aus 23.70 -- Startkauf-Grund in Kauf und Ereignis in der neuen Fassung, gespeicherte Texte bleiben; "
       "Käufe eines früheren Regelstands mit „(alte Regeln)“, im Bericht nach den laufenden in einer Zeile",
       len(g70) == 2 and all(alt70 in g for g in g70) and len(e70) == 2 and all(alt70 in e for e in e70) and g70b == g70
       and [k["grund"] for k in lose70] == [k["grund"] for k in lose71] and len(lose70) == len(h_["rows"])
       and sum(1 for k in lose70 if neu71 in k["grund"]) == 2 and not any("zum Start des Coins" in k["grund"] for k in lose70)
       and ev70 == ev71 and sum(1 for e in ev70 if neu71 in e) == 2 and not any("zum Start des Coins" in e for e in ev70) and be_ok and alt_ok
       and bericht_alt_ok,
       f"{len(g70)} Startkäufe und {len(e70)} Ereignisse im Stil von 23.70; Anzeige: {sum(1 for k in lose70 if neu71 in k['grund'])} Käufe, "
       f"{sum(1 for e in ev70 if neu71 in e)} Ereignisse neu; gespeichert unverändert: {g70b == g70}; Bericht ganz: {be_ok}; alte Regeln: {sorted(tit_i)}; "
       f"Bericht mit früherem Regelstand: {[z_[:46] for z_ in kopf_b]}")
    s_ = erg["spaet"]; z_sp = [r for r in s_["rows"] if r[0] == "akku"]; z_sp2 = [r for r in s_["rows"] if r[0] == "akku_ohne_cluster"]
    g_sp = [s_["grund"].get((n_, int(z[0][1]))) for n_, z in (("akku", z_sp), ("akku_ohne_cluster", z_sp2)) if z]
    g_soll = ("nachgerechnet (1-min-Kerzen): " + AKKU_A0_TEXT.format(ab=_uhr(t_start)) + f"; erst am {_uhr(t_sp)}, bis dahin lag der Kurs bei oder "
              "über 1,2 × 200-Tage-Linie") if t_sp else None
    ok("Akkumulation im Labor: später Startkauf (Kurs in den ersten 5 Stunden ab dem Start über der Sperre) -- Kauf in der ersten erlaubten Minute "
       "zur Eröffnung, Grund mit Zeit und Ursache",
       t_sp and z_sp and z_sp2 and z_sp[0][2] == "A0" and z_sp2[0][2] == "A0" and int(z_sp[0][1]) == int(t_sp) == int(z_sp2[0][1])
       and g_sp == [g_soll, g_soll] and json.loads(z_sp[0][8] or "{}").get("nachgerechnet") is True and not s_["fehler"],
       f"Startkauf {_uhr(int(z_sp[0][1])) if z_sp else '—'} (soll {_uhr(t_sp)}): „{(g_sp or ['—'])[0]}“; Fehler {s_['fehler'][-1:] or 'keine'}")
    w_fr = json.loads(z_fr[0][8] or "{}") if z_fr else {}
    ok("Akkumulation im Labor: ohne früheren Start des Coins Startkauf live beim ersten Takt (zum Ask), danach Nachkäufe je σ₇",
       z_fr and z_fr[0][2] == "A0" and int(z_fr[0][1]) == t_erst and not w_fr.get("nachgerechnet") and z_fr[0][9] is not None
       and z_fr[0][3] > z_fr[0][4] and _stufen_ok(z_fr) and _betrag_ok(z_fr) and not f_["fehler"],
       f"{len(z_fr)} Käufe: " + ", ".join(f"{r[2]} {r[3]:.3f}" for r in z_fr[:4]) + f"; Fehler {f_['fehler'][-1:] or 'keine'}")


def _probe_datenbank(pfad: str, t_start: int, tage: int, seed: int = 7) -> dict:
    """Synthetischer Markt für den Selbsttest: 1-min-Kerzen, Buch je Minute, Funding, eine Kaskade mit Liquidationen,
    Heatmap-Cluster, ein Darwin-Konto mit Ein- und Ausstieg. Liefert die Kursreihe (ts -> close)."""
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    n = tage * 1440; lp = math.log(100.0); kurs = {}
    crash = t_start + 3 * 86_400 + 5 * 3600                     # Tag 4, 05:00: Kaskade
    rows = []; book = []; ctx = []
    for i in range(n):
        t = t_start + i * 60
        schritt = rng.gauss(0, 0.0006)
        if crash <= t < crash + 600:
            schritt -= 0.003                                       # 3 % in 10 min
        elif crash + 900 <= t < crash + 1800:
            schritt += 0.0012                                      # Teil-Rücklauf
        o = math.exp(lp); lp += schritt; c = math.exp(lp)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.0002))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.0002)))
        rows.append((t, "AAA", o, hi, lo, c, 1000.0, 10)); kurs[t] = c
        book.append((t + 59, "AAA", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
        ctx.append((t, "AAA", c, c, c, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    liq = [(t_start + k * 3600, "AAA", "AAAUSDT", "long" if k % 2 else "short", 100.0, 1.0, 10_000.0) for k in range(tage * 24)]
    liq += [(crash + k * 60, "AAA", "AAAUSDT", "long", 100.0, 1.0, 500_000.0) for k in range(10)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", liq)
    hm = []
    for t in range(t_start + 86_400, t_start + n * 60, 600):     # ein großes Long-Cluster 1,2 σ(4 h) unter dem Kurs
        c = kurs[t // 60 * 60]
        hm.append((t, "AAA", c * (1 - 0.011), "long", 1_500_000.0, 5))            # 25 % des Stundenvolumens (6 Mio)
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm)
    t_d = t_start + 2 * 86_400 + 10 * 3600 + 17                 # Darwin-Konto: Long auf, 2 h später zu
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_d, "0xd1", "AAA", "perp", "Open Long", "B", kurs[t_d // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 1, 1),
                     (t_d + 7200, "0xd1", "AAA", "perp", "Close Long", "A", kurs[(t_d + 7200) // 60 * 60], 500.0, 50_000.0, 0.0, 0.0, 2, 0)])
    # 23.34 (Darwin v2): zweites Konto eröffnet Short in vier Stücken über drei Minuten (3k, 3k, 0,8k, 3,5k -- keines erreicht 10k,
    # zusammen 10,3k), verkleinert nach 1 h um 300 USD (darf den Folge-Ausstieg NICHT auslösen) und schließt 3 h später in zwei
    # Stücken. v1 hätte die Eröffnung nie gesehen.
    t_s = t_start + 3 * 86_400 + 14 * 3600 + 7
    stuecke = [(t_s, 3_000.0), (t_s + 50, 3_000.0), (t_s + 110, 800.0), (t_s + 170, 3_500.0)]
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t, "0xd2", "AAA", "perp", "Open Short*", "A", kurs[t // 60 * 60], u / kurs[t // 60 * 60], u, 0.0, 0.0, 10 + i, 0)
                     for i, (t, u) in enumerate(stuecke)]
                    + [(t_s + 3 * 3600 + k * 40, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3 * 3600) // 60 * 60], 50.0, 5_150.0,
                        0.0, 0.0, 20 + k, 1) for k in range(2)]
                    + [(t_s + 3600, "0xd2", "AAA", "perp", "Close Short*", "B", kurs[(t_s + 3600) // 60 * 60], 3.0, 300.0, 0.0, 0.0, 30, 1)])
    # 23.39 (Elite als Vorlage): 0xe1 eröffnet Short in drei Stücken zu 4k über 2 min (12k), verkleinert nach 30 min um 1k (darf den
    # Folge-Ausstieg nicht auslösen) und schließt 90 min nach dem Einstieg 7k -- über den Labor-Neustart (13:20) hinweg. 0xe2 ist
    # Elite, aber von der Masterregel gesperrt: seine 20k-Eröffnung darf niemand kopieren.
    t_e = t_start + 86_400 + 12 * 3600 + 30 * 60 + 11
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_e + 60 * k, "0xe1", "AAA", "perp", "Open Short*", "A", kurs[(t_e + 60 * k) // 60 * 60], 40.0, 4_000.0, 0.0, 0.0, 40 + k, 0)
                     for k in range(3)]
                    + [(t_e + 30 * 60, "0xe1", "AAA", "perp", "Close Short*", "B", kurs[(t_e + 30 * 60) // 60 * 60], 10.0, 1_000.0, 0.0, 0.0, 50, 1),
                       (t_e + 90 * 60, "0xe1", "AAA", "perp", "Close Short*", "B", kurs[(t_e + 90 * 60) // 60 * 60], 70.0, 7_000.0, 0.0, 0.0, 51, 1),
                       (t_e + 5 * 3600, "0xe2", "AAA", "perp", "Open Long*", "B", kurs[(t_e + 5 * 3600) // 60 * 60], 200.0, 20_000.0, 0.0, 0.0, 60, 1)])
    con.execute("INSERT INTO konto_status VALUES ('0xe2', 'gesperrt', 'Test', ?, 'auto', 0, 400)", (t_start,))
    # 0xd9 steht auf der Darwin-Liste UND in der Elite: beide Vorlagen müssen seine Eröffnung unabhängig kopieren (eigener Zustand je Vorlage)
    t_b = t_start + 2 * 86_400 + 18 * 3600 + 13
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(t_b, "0xd9", "AAA", "perp", "Open Long", "B", kurs[t_b // 60 * 60], 150.0, 15_000.0, 0.0, 0.0, 70, 1),
                     (t_b + 7200, "0xd9", "AAA", "perp", "Close Long", "A", kurs[(t_b + 7200) // 60 * 60], 150.0, 15_000.0, 0.0, 0.0, 71, 0)])
    con.commit(); con.close()
    return {"kurs": kurs, "crash": crash, "darwin_t": t_d, "darwin2_t": t_s + 170, "elite_t": t_e + 120, "elite_zu": t_e + 90 * 60,
            "elite_teil": t_e + 30 * 60}


def _grid_markt(pfad: str, t0: int, tage: int, seed: int = 11) -> dict:
    """
    23.40: Synthetischer Markt für die Grids (Coin GRD): Sinus 1 % Amplitude mit 4 h Periode plus Rauschen (seitwärts, sieben Tage Vorlauf
    für σ), dann eine Rallye (+5 % in 40 min, +2 % in 80 min, −3 % in 60 min), ein Crash (−6 % in 10 min mit Long-Liquidationen über der
    Kaskaden-Schwelle) und ein langsamer Abwärtstrend (−0,4 %/h über 10 h).
    """
    rng = random.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
        CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
            bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL, funding REAL, oi REAL, premium REAL, PRIMARY KEY (ts, coin));
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL,
            fee REAL, tid INTEGER, buy INTEGER, PRIMARY KEY (addr, tid));
        CREATE TABLE konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
    """)
    D = 86_400
    rally = t0 + 8 * D + 2 * 3600; crash = t0 + 9 * D + 14 * 3600; trend = t0 + 10 * D + 6 * 3600
    basis = math.log(100.0); drift = 0.0; lp = basis; rows = []; book = []; ctx = []; kurs = {}
    for i in range(tage * 1440):
        t = t0 + i * 60
        if rally <= t < rally + 40 * 60:
            drift += 0.05 / 40
        elif rally + 40 * 60 <= t < rally + 120 * 60:
            drift += 0.02 / 80
        elif rally + 120 * 60 <= t < rally + 180 * 60:
            drift -= 0.03 / 60
        elif crash <= t < crash + 10 * 60:
            drift -= 0.06 / 10
        elif trend <= t < trend + 10 * 3600:
            drift -= 0.004 / 60
        o = math.exp(lp)
        lp = basis + drift + 0.01 * math.sin(2 * math.pi * (t - t0) / (4 * 3600)) + rng.gauss(0, 0.0003)
        c = math.exp(lp)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.0002))); lo = min(o, c) * (1 - abs(rng.gauss(0, 0.0002)))
        rows.append((t, "GRD", o, hi, lo, c, 1000.0, 10)); kurs[t] = c
        book.append((t + 59, "GRD", c * (1 - 1e-4), c * (1 + 1e-4), 2.0, 2e6, 2e6, 5e6, 5e6, 1e7, 1e7, 2e7, 2e7, 0.0))
        ctx.append((t, "GRD", c, c, c, 0.00001, 1e6, 0.0))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)", ctx)
    liq = [(t0 + k * 3600, "GRD", "GRDUSDT", "long" if k % 2 else "short", 100.0, 1.0, 10_000.0) for k in range(tage * 24)]
    liq += [(crash + k * 60, "GRD", "GRDUSDT", "long", 100.0, 1.0, 500_000.0) for k in range(10)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", liq)
    con.commit(); con.close()
    return {"kurs": kurs, "rally": rally, "crash": crash, "trend": trend, "spitze": max(v for t, v in kurs.items() if rally <= t < rally + 4 * 3600)}


def _grid_selbsttest(tmp: str, ok) -> None:
    """23.40: Grids auf dem synthetischen Markt -- Aufbau, Kapital, Seitwärts-Gewinne, Rallye (Long hält, Short Notausstieg), Crash
    (Long Notausstieg und Pause, Short hält), Abwärtstrend (Long baut nicht hinein), Neustart im Halten, grobe Takte, Tagesbilanz,
    abgelöste Regelversion, Fehler hinter dem Sicherungspunkt."""
    db = os.path.join(tmp, "grid_m.db")
    T0 = 1_790_006_400 - 13 * 86_400
    info = _grid_markt(db, T0, 12)
    nur = ("grid_long", "grid_short")

    def lauf(sp, schritt, neustart_im_halten=False):
        L = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
        t = T0 + 7 * 86_400; ende = T0 + 11 * 86_400 + 12 * 3600; fehler = []; kap = 0.0; neu_halten = None; nach_neustart = None
        sid_l = next(s["sid"] for s in L.grid_strategien if s["regeln"]["richtung"] == "long")
        while t < ende:
            L.zyklus(t)
            st_ = F.store_connect(sp)
            for sid in L.grid_sids:
                g = L.z["g"].get(f"{sid}|GRD") or {}
                a = st_.execute("SELECT COALESCE(SUM(notional), 0) FROM labor_position WHERE status='offen' AND sid=?", (sid,)).fetchone()[0]
                o_ = st_.execute("SELECT COUNT(*) FROM labor_order WHERE status='offen' AND sid=?", (sid,)).fetchone()[0]
                kap = max(kap, a + o_ * (g.get("los_usd") or 0.0))
            st_.close()
            gl = L.z["g"].get(f"{sid_l}|GRD") or {}
            if neustart_im_halten and neu_halten is None and gl.get("modus") == "halten" and t - gl["halten"]["start"] >= 1800:
                fehler += L.fehler
                L = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))      # Neustart mitten im Halten
                neu_halten = t; L.zyklus(t + schritt); t += schritt
                nach_neustart = (L.z["g"].get(f"{sid_l}|GRD") or {}).get("modus")
            t += schritt
        fehler += L.fehler
        return L, fehler, kap, neu_halten, nach_neustart, ende

    sp = os.path.join(tmp, "grid_f.db")
    L, fehler, kap, neu_halten, nach_neustart, ende = lauf(sp, 120, neustart_im_halten=True)
    st = F.store_connect(sp)
    sid = {s["regeln"]["richtung"]: s["sid"] for s in L.grid_strategien}
    ev = {r_: [(t_, txt) for t_, txt in st.execute("SELECT ts, text FROM labor_ereignis WHERE art='grid' AND sid=? ORDER BY ts, id", (sid[r_],))]
          for r_ in ("long", "short")}
    auf = {r_: [x for x in ev[r_] if " aufgebaut: " in x[1]] for r_ in ev}
    ok("Grid: Aufbau aus der Range", auf["long"] and auf["short"] and auf["long"][0][0] == T0 + 7 * 86_400
       and all(4 <= int(x[1].split(" Stufen à ")[0].split("·")[-1].strip()) <= 12 for x in auf["long"] + auf["short"]),
       f"Long {len(auf['long'])}×, Short {len(auf['short'])}× aufgebaut; erstes: „{auf['long'][0][1][:110] if auf['long'] else '—'}“")
    ok("Grid: Kapital nie über dem Konto", kap <= GRID_KAPITAL + 1e-6, f"höchstens {kap:,.2f} USD aus Losen und liegenden Orders (Konto {GRID_KAPITAL:,.0f})")
    vor = info["rally"]
    runden = {r_: st.execute("SELECT COUNT(*), SUM(netto_usd > 0), MIN(netto_usd), SUM(netto_usd) FROM labor_position WHERE sid=? AND status='geschlossen' "
                             "AND art_aus LIKE 'Grid-%' AND geschlossen < ?", (sid[r_], vor)).fetchone() for r_ in ("long", "short")}
    ok("Grid: seitwärts verdient jede Runde", all(r_[0] >= 20 and r_[1] == r_[0] for r_ in runden.values()),
       f"vor der Rallye: Long {runden['long'][0]} Runden, Summe {runden['long'][3] or 0:+.2f} USD (kleinste {runden['long'][2] or 0:+.2f}); "
       f"Short {runden['short'][0]} Runden, Summe {runden['short'][3] or 0:+.2f} USD")
    halten_l = [x for x in ev["long"] if vor <= x[0] <= vor + 3600 and "ausgesetzt" in x[1]]
    ende_l = st.execute("SELECT MIN(geschlossen), MIN(preis_aus), SUM(netto_usd), COUNT(*) FROM labor_position WHERE sid=? AND art_aus LIKE 'Trailing%' "
                        "AND geschlossen BETWEEN ? AND ?", (sid["long"], vor, vor + 6 * 3600)).fetchone()
    g_oben = max((float(x[1].split("Range ")[1].split("–")[1].split(" ")[0]) for x in auf["long"] if x[0] < vor), default=None)
    sig1h = None
    if halten_l:
        try:
            sig1h = float(halten_l[0][1].split(" = ")[1].split(" %")[0]) / 100 / 1.5
        except (IndexError, ValueError):
            sig1h = None
    ok("Grid Long: Rallye halten, nahe dem Hoch verkaufen", halten_l and ende_l[3] and ende_l[2] > 0 and g_oben and ende_l[1] > g_oben * 1.03
       and sig1h and ende_l[1] >= info["spitze"] * (1 - 1.5 * sig1h) * 0.998,
       f"gehalten ab {_uhr(halten_l[0][0]) if halten_l else '—'} ({halten_l[0][1][:60] if halten_l else '—'}); {ende_l[3] or 0} Lose zu "
       f"{ende_l[1] or 0:.4g} verkauft (Hoch {info['spitze']:.4g}, oberste Grid-Stufe {g_oben or 0:.4g}), netto {ende_l[2] or 0:+.2f} USD")
    ok("Grid: Neustart mitten im Halten", neu_halten and nach_neustart == "halten" and ende_l[0] and ende_l[0] > neu_halten,
       f"Neustart {_uhr(neu_halten) if neu_halten else '—'} → Modus „{nach_neustart}“, Ausstieg {_uhr(ende_l[0]) if ende_l[0] else '—'}")
    na_s = [x for x in ev["short"] if vor <= x[0] <= vor + 1800 and x[1].startswith("Notausstieg")]
    ok("Grid Short: Rallye = Notausstieg", na_s, f"{_uhr(na_s[0][0]) if na_s else '—'}: {na_s[0][1][:110] if na_s else 'keiner'}")
    cr = info["crash"]
    na_l = [x for x in ev["long"] if cr <= x[0] <= cr + 300 and x[1].startswith("Notausstieg")]
    offen_nach = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=? AND eroeffnet BETWEEN ? AND ?", (sid["long"], cr + 300, cr + 4 * 3600)).fetchone()[0]
    ok("Grid Long: Crash = Notausstieg, dann Pause", na_l and offen_nach == 0,
       f"{_uhr(na_l[0][0]) + ': ' + na_l[0][1][:100] if na_l else 'kein Notausstieg'}; neue Lose in den 4 h danach: {offen_nach}")
    h_s = [x for x in ev["short"] if cr <= x[0] <= cr + 900 and "ausgesetzt" in x[1]]
    e_s = st.execute("SELECT COUNT(*), SUM(netto_usd) FROM labor_position WHERE sid=? AND art_aus LIKE 'Trailing%' AND geschlossen BETWEEN ? AND ?",
                     (sid["short"], cr, cr + 8 * 3600)).fetchone()
    ok("Grid Short: Crash halten, nach dem Tief zurückkaufen", h_s and e_s[0] and (e_s[1] or 0) > 0,
       f"{_uhr(h_s[0][0]) + ' ' + h_s[0][1][:70] if h_s else 'kein Halten'}; {e_s[0] or 0} Lose per Trailing-Stop, netto {e_s[1] or 0:+.2f} USD")
    tr0 = info["trend"]
    na_tr = [x for x in ev["long"] if tr0 <= x[0] <= tr0 + 12 * 3600 and x[1].startswith("Notausstieg")]
    auf_tr = [x for x in ev["long"] if tr0 + 3600 <= x[0] <= tr0 + 10 * 3600 and " aufgebaut: " in x[1]]
    ok("Grid Long: baut nicht in den Abwärtstrend", len(na_tr) <= 1 and not auf_tr,
       f"Notausstiege im Trend: {len(na_tr)}; Aufbauten im Trend: {len(auf_tr)}")
    ok("Grid Long: langsamer Abwärtstrend endet an der Notlinie", len(na_tr) == 1 and "Notlinie" in na_tr[0][1],
       f"{_uhr(na_tr[0][0]) + ': ' + na_tr[0][1][:100] if na_tr else 'kein Notausstieg im Trend'}")
    K = {k["name"]: k for k in kennzahlen(st, ende)}
    gt = grid_tage(st, sid["long"])
    real = st.execute("SELECT COALESCE(SUM(netto_usd), 0) FROM labor_position WHERE sid=? AND status='geschlossen'", (sid["long"],)).fetchone()[0]
    eq = {r_["sid"]: r_ for r_ in equity(sp, ende)["reihen"]}
    kl = K["grid_long"]
    ok("Grid: Tagesbilanz nach Bestandswert", kl["n_eff"] == len(gt["tage"]) >= 3 and abs(kl["summe_usd"] - (real + sum(gt["bestand"].values()))) < 0.02
       and abs(eq[sid["long"]]["summe"] - kl["summe_usd"]) < 0.05 and abs(sum(u for _, u in gt["tage"]) - kl["summe_usd"]) < 0.05,
       f"Long: {kl['n_eff']} Tage, Summe {kl['summe_usd']:+.2f} = realisiert {real:+.2f} + Bestand {sum(gt['bestand'].values()):+.2f}; "
       f"Bilanzlinie endet bei {eq[sid['long']]['summe']:+.2f}; Short {K['grid_short']['summe_usd']:+.2f} USD")
    st.close()
    # Grobe Takte (10 min, Nachholen über die Kerzen): dieselben Ereignisse, keine Fehler, Kapital eingehalten
    sp2 = os.path.join(tmp, "grid_f2.db")
    L2, fehler2, kap2, _, _, _ = lauf(sp2, 600)
    st2 = F.store_connect(sp2)
    ev2 = [txt for (txt,) in st2.execute("SELECT text FROM labor_ereignis WHERE art='grid' AND sid=? ORDER BY ts", (sid["long"],))]
    s1 = F.store_connect(sp).execute("SELECT SUM(netto_usd) FROM labor_position WHERE status='geschlossen'").fetchone()[0] or 0.0
    s2 = st2.execute("SELECT SUM(netto_usd) FROM labor_position WHERE status='geschlossen'").fetchone()[0] or 0.0
    st2.close()
    ok("Grid: grobe Takte holen über die Kerzen nach", not fehler2 and kap2 <= GRID_KAPITAL + 1e-6 and any("ausgesetzt" in x for x in ev2)
       and abs(s1 - s2) <= 0.35 * max(abs(s1), 50.0),
       f"10-min-Takt: realisiert {s2:+.2f} USD gegen {s1:+.2f} im 2-min-Takt; Halten in der Rallye: {'ja' if any('ausgesetzt' in x for x in ev2) else 'nein'}")
    # Mikro-Proben auf festen Kerzen (Regeln, die der Markt oben nicht zuverlässig trifft)
    spm = os.path.join(tmp, "grid_mikro.db"); Lm = Labor(db, spm, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    stm = Lm._st(); cm = Lm._con(); Lm._registrieren(stm, T0); Sl = next(s for s in Lm.grid_strategien if s["regeln"]["richtung"] == "long")
    tm = T0 + 10 * 86_400
    Em = {"coin": "GRD", "preis": {"ts": tm, "mid": 102.5, "bid": 102.49, "ask": 102.51, "spread_bps": 2.0, "kauf": [], "verkauf": []},
          "sigma15": 0.003, "sigma1h": 0.006, "sigma4h": 0.012, "kerzen20": [], "kaskade": {}}

    def gs_neu(**kw):
        return dict({"modus": "aktiv", "gen": 2, "stufen": [100.0, 101.0, 102.0, 103.0, 104.0], "n": 4, "schritt": 0.01, "unten": 100.0, "oben": 104.0,
                     "notlinie": 99.0, "los_usd": 2500.0, "zaehler": {}, "gepr": tm}, **kw)
    # a) Kapital: zwei Lose einer früheren Generation binden 5.000 -- von drei freien Abständen unter dem Kurs bekommen nur zwei eine Order
    g_a = gs_neu(gen=1); alt_l = [Lm._grid_los_auf(stm, Sl, "GRD", g_a, i, tm, 103.5, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm + 60) for i in (2, 3)]
    g_a = gs_neu(); o_a: list = []
    n_a = Lm._grid_auffuellen(stm, Sl, g_a, "GRD", alt_l, o_a, tm, 102.5)
    ok("Grid: Kapitaldeckel mit Losen früherer Stufen", n_a == 2 and sorted(o["preis"] for o in o_a) == [101.0, 102.0],
       f"{n_a} Orders bei {sorted(o['preis'] for o in o_a)} (Lose älterer Generation 2 × 2.500 USD, Konto 10.000)")
    # b) Halten mitten in der Minute: das Tief derselben Kerze lag VOR dem Auslöser und darf den Trailing-Stop nicht auslösen
    g_b = gs_neu(modus="halten", halten={"start": tm + 30, "ab": tm + 60, "start_px": 103.0, "extrem": 103.0, "stop": 103.0 * (1 - 1.5 * 0.006),
                                        "sig": 0.006, "grund": "Test"})
    l_b = [Lm._grid_los_auf(stm, Sl, "GRD", gs_neu(), 1, tm - 600, 101.0, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm - 540)]
    r1 = Lm._grid_kerze(cm, stm, Sl, g_b, "GRD", Em, l_b, [], tm, 102.5, 103.4, 102.0, 103.3, None, None)
    st_b1 = (g_b["modus"], round((g_b.get("halten") or {}).get("extrem", 0.0), 4), len(l_b))
    r2 = Lm._grid_kerze(cm, stm, Sl, g_b, "GRD", Em, l_b, [], tm + 60, 103.3, 103.35, 102.1, 102.2, None, None)
    ok("Grid: Trailing-Stop zählt erst ab der Kerze nach dem Auslöser", r1 == 0 and st_b1 == ("halten", 103.4, 1) and r2 == 1 and g_b["modus"] == "pause"
       and not l_b, f"Startkerze (Tief 102,0 vor dem Auslöser): {st_b1[0]}, Hoch {st_b1[1]}; nächste Kerze unter dem Stop "
       f"{103.4 * (1 - 1.5 * 0.006):.3f}: {g_b['modus']}")
    # c) Notlinie in derselben Kerze wie eine Füllung: erst füllt das Kauf-Limit, dann schließt die Notlinie ALLE Lose (auch das neue)
    g_c = gs_neu(); l_c = [Lm._grid_los_auf(stm, Sl, "GRD", g_c, 1, tm - 600, 101.0, 0.0, GEB_MAKER, "Grid-Kauf (Maker)", tm - 540)]
    o_c = [Lm._grid_order(stm, Sl, "GRD", g_c, 0, tm - 600)]
    Lm._grid_kerze(cm, stm, Sl, g_c, "GRD", Em, l_c, o_c, tm, 100.8, 100.9, 98.5, 98.7, None, None)
    zu_c = stm.execute("SELECT preis_ein, art_aus, preis_aus FROM labor_position WHERE status='geschlossen' AND art_aus LIKE 'Notausstieg%' "
                       "AND eroeffnet >= ? ORDER BY preis_ein", (tm - 600,)).fetchall()
    ok("Grid: Notlinie nach der Füllung in derselben Kerze", g_c["modus"] == "pause" and not l_c and not o_c and [round(x[0], 2) for x in zu_c] == [100.0, 101.0]
       and all(abs(x[2] - 99.0 * (1 - 1e-4)) < 0.05 for x in zu_c),
       f"geschlossen: {[(round(x[0], 2), round(x[2], 3)) for x in zu_c]} (Einstieg, Ausstieg bei der Notlinie 99 abzüglich Auswirkung); Modus {g_c['modus']}")
    stm.rollback(); stm.close(); cm.close()
    # Abgelöste Regelversion: Lose schließen, Orders löschen
    st = F.store_connect(sp)
    st.execute("INSERT INTO labor_strategie VALUES ('grid_long@alt00000', 'grid_long', 'Grid Long', 'Grid', '{}', '', ?, 0)", (T0,))
    st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, sl, tp, ablauf, "
               "grund, werte, geprueft_bis, nur_stop_bis, funding, funding_bis, mae_pct, mfe_pct) VALUES ('grid_long@alt00000', 'GRD', 'long', 'offen', ?, 95.0, "
               "1000.0, 10.526, 'Grid-Kauf (Maker)', 0.15, 0, 90.0, 99.0, 0, 'alt', '{\"stufe\": 0, \"gen\": 1}', ?, ?, 0, ?, 0, 0)", (ende - 3600,) * 4)
    st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, gueltig_bis, status, grund, werte, geprueft_bis) "
               "VALUES ('grid_long@alt00000', 'GRD', 'long', 94.0, ?, ?, 'offen', 'alt', '{}', ?)", (ende - 3600, ende + 86_400, ende - 3600))
    st.commit(); st.close()
    L3 = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    L3.zyklus(ende + 30)
    st = F.store_connect(sp)
    alt = st.execute("SELECT status, grund_aus FROM labor_position WHERE sid='grid_long@alt00000'").fetchone()
    alt_o = st.execute("SELECT COUNT(*) FROM labor_order WHERE sid='grid_long@alt00000'").fetchone()[0]
    ok("Grid: abgelöste Regelversion wird geschlossen", alt and alt[0] == "geschlossen" and alt[1] == "Regelversion abgelöst" and alt_o == 0,
       f"Los: {alt[0] if alt else '—'} ({alt[1] if alt else '—'}), Orders übrig: {alt_o}")
    # Fehler in einem Grid: Sicherungspunkt -- Datenbank und Zustand dieses Grids unverändert, das andere läuft weiter
    vor_z = json.loads(_j(L3.z["g"][f"{sid['short']}|GRD"]))
    vor_n = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=?", (sid["short"],)).fetchone()[0]
    st.close()
    echt = L3._grid_pruefen

    def kaputt(con_, st_, S_, *a, **kw):
        if S_["regeln"]["richtung"] == "short":
            st_.execute("INSERT INTO labor_ereignis (ts, sid, coin, art, text) VALUES (0, ?, 'GRD', 'grid', 'darf nicht bleiben')", (S_["sid"],))
            raise RuntimeError("Testfehler")
        return echt(con_, st_, S_, *a, **kw)
    L3._grid_pruefen = kaputt
    L3.zyklus(ende + 150)
    st = F.store_connect(sp)
    rest = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE text='darf nicht bleiben'").fetchone()[0]
    nach_n = st.execute("SELECT COUNT(*) FROM labor_position WHERE sid=?", (sid["short"],)).fetchone()[0]
    st.close()
    ok("Grid: Fehler nur in einem Grid, Sicherungspunkt", rest == 0 and nach_n == vor_n and L3.z["g"][f"{sid['short']}|GRD"] == vor_z
       and any("Testfehler" in f_ for f_ in L3.fehler) and int(L3.z["g"][f"{sid['long']}|GRD"]["gepr"]) >= (ende + 150) // 60 * 60,
       f"Fehler gemeldet: {'ja' if any('Testfehler' in f_ for f_ in L3.fehler) else 'nein'}; halbe Änderung zurückgerollt: {'ja' if rest == 0 else 'NEIN'}; "
       f"Long lief weiter bis {_uhr(L3.z['g'][sid['long'] + '|GRD']['gepr'])}")
    # 23.41 (Pi 02.10. 06:57 „ZEC Handel: database is locked“): Schreibt ein anderer Thread (Prognose, Familien, Profis), während das
    # Grid liest, darf der nächste Schreibzugriff des Labors im selben Takt nicht scheitern. 23.40 öffnete mit einem einfachen BEGIN eine
    # Lese-Transaktion -- nach einem fremden Commit war ihr Stand veraltet, und das Schreiben scheiterte sofort (ohne Wartezeit).
    L4 = Labor(db, sp, coins=("GRD",), nur=nur, adressfluss=os.path.join(tmp, "grid_af.db"))
    L4.zyklus(ende + 210)                                                    # erster Takt registriert (schreibt ohnehin)
    echt_lose = L4._grid_lose; fremd = {"commit": 0, "wartet": 0}

    def lose_und_fremder_schreiber(st_, sid_, coin_, pid=None):
        r = echt_lose(st_, sid_, coin_, pid)
        if pid is None:
            c = sqlite3.connect(sp, timeout=0.05)
            try:
                c.execute("INSERT OR REPLACE INTO labor_zustand VALUES ('probe_fremd', ?)", (str(time.time()),)); c.commit(); fremd["commit"] += 1
            except sqlite3.OperationalError:
                fremd["wartet"] += 1                                         # Labor hält die Schreibsperre: der andere muss warten
            finally:
                c.close()
        return r
    L4._grid_lose = lose_und_fremder_schreiber
    abbr = []
    for k in range(3):                                                       # jede Minute neu: Kerzen-Stand und Zustand werden geschrieben
        try:
            L4.zyklus(ende + 270 + 60 * k)
        except sqlite3.OperationalError as e:
            abbr.append(str(e))
    gesp = [f_ for f_ in L4.fehler if "locked" in f_] + abbr
    st = F.store_connect(sp)
    gst = json.loads(st.execute("SELECT v FROM labor_zustand WHERE k='zustand'").fetchone()[0])["g"].get(f"{sid['long']}|GRD") or {}
    st.close()
    ok("Grid: fremder Schreiber im Takt, kein „database is locked“", not gesp and fremd["wartet"] >= 1 and int(gst.get("gepr") or 0) >= (ende + 390) // 60 * 60,
       f"fremde Commits während das Grid las: {fremd['commit']}, mussten warten: {fremd['wartet']}; Fehler: {gesp[:2] or 'keine'}; Zustand gespeichert bis "
       f"{_uhr(gst.get('gepr'))}")
    ok("Grid: keine Laufzeitfehler", not fehler, "; ".join(fehler[-3:]) or "keine")


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    # 1. Ausführungsmodell
    b = {"mid": 100.0, "spread_bps": 2.0, "kauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)], "verkauf": [(10, 2e6), (25, 5e6), (50, 1e7), (100, 2e7)]}
    p1, bps1 = taker_preis(b, True, 10_000)
    p2, bps2 = taker_preis(b, True, 3e6)
    p3, _ = taker_preis(b, False, 10_000)
    ok("Markt-Order klein ≈ Briefkurs", abs(bps1 - 1.0) < 0.05 and p1 > 100.0, f"{bps1:.3f} bps über der Mitte")
    ok("Markt-Order groß mit Auswirkung", 6 < bps2 < 12 and p3 < 100.0, f"3 Mio: {bps2:.1f} bps im Mittel über die Tiefe, Verkauf 10k {p3:.4f}")
    ok("Jenseits der Tiefe pauschal", _auswirkung_bps(1e8, 1.0, [(10, 1e6)]) > 140, f"{_auswirkung_bps(1e8, 1.0, [(10, 1e6)]):.0f} bps")
    tmp = tempfile.mkdtemp(prefix="hl_labor_test_")
    try:
        db = os.path.join(tmp, "m.db"); sp = os.path.join(tmp, "f.db")
        T0 = 1_790_006_400 - 6 * 86_400
        info = _probe_datenbank(db, T0, 5)
        kurs = info["kurs"]
        st = F.store_connect(sp)
        rng = random.Random(3); drv = []; fc = []
        for t in range(T0, T0 + 5 * 86_400, 900):
            p0 = kurs.get(t // 60 * 60); p4 = kurs.get((t + 4 * 3600) // 60 * 60)
            if not p0 or not p4:
                continue
            richtig = rng.random() < 0.85
            s = (1 if p4 > p0 else -1) * (1 if richtig else -1) * 0.8
            drv += [(t, "AAA", "Wal-Flow 30 min", s), (t, "AAA", "Leaderboard-Flow 60 min", max(-1, min(1, rng.gauss(0, 0.6))))]
            fc.append((t, "AAA", p0, 0.0, p0, p0, json.dumps({"p_up_v2": 0.5, "kalib2": {"version": 2}, "fusion": {"p_4": 0.47},
                                                              "kosten": {"er_4": 0.0123}}), 0.5, 0.5))      # 23.42: Fusion und Kostenschwelle im Payload
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, buy_px, sell_px, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?)", fc)
        st.execute("INSERT OR REPLACE INTO learned VALUES ('*', 'darwin', ?, ?)", (json.dumps({"reihe": ["0xd1", "0xd2", "0xd9"], "liste": ["0xd1", "0xd2", "0xd9"]}), T0))
        st.execute("INSERT OR REPLACE INTO learned VALUES ('AAA', 'elite', ?, ?)", (json.dumps(["0xe1", "0xe2", "0xd9"]), T0))   # 23.39
        st.commit(); st.close()
        nur = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "darwin_folgen", "darwin_gegen", "elite_folgen", "elite_gegen", "docht_fangen", "kaskade_umkehr",
               "kaskade_fortsetzung", "zufall", "halten_long")
        L = None; t = T0 + 86_400; schritt = 120; i = 0; fehler = []
        while t < T0 + 5 * 86_400 - 120:
            if L is None or i % 400 == 0:
                if L is not None:
                    fehler += L.fehler
                L = Labor(db, sp, coins=("AAA",), nur=nur, adressfluss=os.path.join(tmp, "af.db"))     # Neustart-Probe
            L.zyklus(t)
            t += schritt; i += 1
        fehler += L.fehler
        n_vor = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        ende = T0 + 5 * 86_400
        for dt in (240, 300, 360, 420):                                   # Daten enden: Kurs veraltet -> keine neuen Einstiege
            L.zyklus(ende + dt)
        n_nach = F.store_connect(sp).execute("SELECT COUNT(*) FROM labor_position").fetchone()[0]
        veraltet = sum(1 for v in L.status.values() if v.get("blockiert") == "Kurs veraltet")
        fehler += L.fehler
        st = F.store_connect(sp)
        K = {k["name"]: k for k in kennzahlen(st, t)}
        pos = st.execute("SELECT COUNT(*), SUM(status='offen') FROM labor_position").fetchone()
        g_ein = st.execute("SELECT gebuehr_ein, notional, art_ein FROM labor_position WHERE art_ein LIKE 'Markt%' LIMIT 1").fetchone()
        dw_alle = [(e, g, s_, json.loads(w or "{}").get("konto"), zu) for e, g, s_, w, zu in st.execute(
            "SELECT p.eroeffnet, p.grund_aus, p.seite, p.werte, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_folgen'")]
        dw = [x for x in dw_alle if x[3] == "0xd1"]; dw2 = [x for x in dw_alle if x[3] == "0xd2"]; dw9 = [x for x in dw_alle if x[3] == "0xd9"]
        dg = st.execute("SELECT p.seite FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='darwin_gegen' ORDER BY p.eroeffnet").fetchall()
        el = [(e, g, s_, json.loads(w or "{}").get("konto"), zu) for e, g, s_, w, zu in st.execute(
            "SELECT p.eroeffnet, p.grund_aus, p.seite, p.werte, p.geschlossen FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='elite_folgen'")]
        eg = st.execute("SELECT p.seite FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='elite_gegen' ORDER BY p.eroeffnet").fetchall()
        doc = st.execute("SELECT COUNT(*) FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name='docht_fangen' AND p.art_ein LIKE 'Limit%'").fetchone()[0]
        kas = st.execute("SELECT s.name, p.seite, p.eroeffnet FROM labor_position p JOIN labor_strategie s ON s.sid=p.sid WHERE s.name LIKE 'kaskade%'").fetchall()
        kas_e = st.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='kaskade'").fetchone()[0]
        st.close()
        w, wg, lb, zf = K["wale_folgen"], K["wale_gegen"], K["leaderboard_folgen"], K["zufall"]
        ok("Positivkontrolle: eingebaute Kante verdient", w["n"] >= 10 and (w["mittel_pct"] or 0) > 0 and (w["t"] or 0) >= 2,
           f"Wale folgen: {w['n']} Trades, Ø {w['mittel_pct'] or 0:+.3f} %, t {w['t'] or 0:+.1f}")
        ok("Gegenrichtung verliert", (wg["mittel_pct"] or 0) < 0, f"Gegen die Wale: Ø {wg['mittel_pct'] or 0:+.3f} %")
        ok("Rauschen ohne Scheinbeleg", lb["n"] >= 5 and abs(lb["t"] or 0) < 3, f"Leaderboard (Zufallstreiber): {lb['n']} Trades, t {lb['t'] or 0:+.1f}")
        ok("Zufall kostet", zf["n"] >= 5 and (zf["mittel_pct"] or 0) < 0.1, f"Zufall: {zf['n']} Trades, Ø {zf['mittel_pct'] or 0:+.3f} %")
        ok("Gebühr Taker 0,045 %", g_ein and abs(g_ein[0] - g_ein[1] * GEB_TAKER) < 1e-6, f"{g_ein[0]:.2f} USD auf {g_ein[1]:.0f}" if g_ein else "keine")
        ok("Darwin folgen: Ein- und Folge-Ausstieg", len(dw) == 1 and 0 <= dw[0][0] - info["darwin_t"] <= DARWIN_FRISCH_S and "schließt" in (dw[0][1] or "")
           and dw[0][2] == "long", f"{len(dw)} Trade(s), Einstieg {dw[0][0] - info['darwin_t'] if dw else '—'} s nach dem Konto, Ausstieg „{dw[0][1] if dw else '—'}“")
        ok("Darwin v2: Eröffnung in Stücken erkannt", len(dw2) == 1 and 0 <= dw2[0][0] - info["darwin2_t"] <= DARWIN_FRISCH_S and dw2[0][2] == "short"
           and "schließt" in (dw2[0][1] or "") and (dw2[0][4] or 0) >= info["darwin2_t"] + 3 * 3600 - 200 and len(dw_alle) == 3,
           f"{len(dw2)} Trade(s) aus 4 Stücken (3k+3k+0,8k+3,5k), Einstieg {dw2[0][0] - info['darwin2_t'] if dw2 else '—'} s nach dem letzten Stück; "
           f"Teilverkauf 300 USD nach 1 h ignoriert, Ausstieg {((dw2[0][4] or 0) - info['darwin2_t']) / 3600:.1f} h danach „{dw2[0][1] if dw2 else '—'}“; "
           f"insgesamt {len(dw_alle)} Darwin-Trades")
        ok("Darwin dagegen: Gegenseite", [x[0] for x in dg] == ["short", "short", "long"], f"{[x[0] for x in dg] or '—'}")
        el9 = [x for x in el if x[3] == "0xd9"]; el = [x for x in el if x[3] != "0xd9"]
        ok("Elite folgen: Ein- und Folge-Ausstieg über einen Neustart", len(el) == 1 and el[0][3] == "0xe1" and el[0][2] == "short"
           and 0 <= el[0][0] - info["elite_t"] <= DARWIN_FRISCH_S and "Elite-Konto" in (el[0][1] or "") and "schließt" in (el[0][1] or "")
           and info["elite_zu"] <= (el[0][4] or 0) <= info["elite_zu"] + 300,
           f"{len(el)} Trade(s) aus 3 Stücken zu 4k, Einstieg {el[0][0] - info['elite_t'] if el else '—'} s nach dem letzten Stück; Teilschließung 1k "
           f"nach 30 min ignoriert, Ausstieg {((el[0][4] or 0) - info['elite_t']) / 60 if el else 0:.0f} min danach „{el[0][1] if el else '—'}“")
        ok("Elite dagegen: Gegenseite; Gesperrte nie kopiert", [x[0] for x in eg] == ["long", "short"] and not any(x[3] == "0xe2" for x in el),
           f"Gegen die Elite: {[x[0] for x in eg] or '—'}; 20k-Eröffnung des gesperrten Elite-Kontos: {'kopiert (FEHLER)' if any(x[3] == '0xe2' for x in el) else 'nicht kopiert'}")
        ok("Vorlagen getrennt, eigener Zustand je Vorlage", {x[3] for x in dw_alle} == {"0xd1", "0xd2", "0xd9"} and {x[3] for x in el} == {"0xe1"}
           and len(dw9) == 1 and len(el9) == 1 and dw9[0][2] == el9[0][2] == "long" and "schließt" in (dw9[0][1] or "") and "schließt" in (el9[0][1] or ""),
           f"Darwin kopiert {sorted({x[3] for x in dw_alle})}, Elite kopiert {sorted({x[3] for x in el + el9})}; Konto in beiden Vorlagen: "
           f"Darwin {len(dw9)}, Elite {len(el9)} Trade(s), beide mit Folge-Ausstieg")
        ok("Docht fangen: Limit gefüllt", doc >= 1, f"{doc} Füllungen über Limit-Orders")
        fs = [k for k in kas if k[0] == "kaskade_fortsetzung"]; um = [k for k in kas if k[0] == "kaskade_umkehr"]
        ok("Kaskade erkannt und gehandelt", kas_e >= 1 and fs and fs[0][1] == "short" and um and um[0][1] == "long" and um[0][2] > fs[0][2],
           f"{kas_e} Erkennung(en); Fortsetzung {fs[0][1] if fs else '—'}, Umkehr {um[0][1] if um else '—'}")
        ok("Keine Laufzeitfehler", not fehler, "; ".join(fehler[-3:]) or "keine")
        ok("Live-Tafel: Stand je Strategie", len(L.status) == len(nur) and all(v.get("text") for v in L.status.values()),
           f"{len(L.status)} Einträge, z. B. „{next(iter(L.status.values()))['text'] if L.status else '—'}“")
        ok("Positionen gespeichert", pos[0] >= 20, f"{pos[0]} Positionen, {pos[1] or 0} offen")
        ok("Veralteter Kurs: keine neuen Einstiege", n_nach == n_vor and veraltet >= 1, f"{n_nach - n_vor} neue Positionen, {veraltet} Strategien „Kurs veraltet“")
        c_e, s_e = L._con(), L._st()                                                  # 23.42: der Weg Payload → Eingaben der Fusions-Strategien
        try:
            P_e = (L.eingaben(c_e, s_e, "AAA", T0 + 2 * 86_400 + 600, L.z or L._zustand(s_e)).get("prognose") or {})
        finally:
            c_e.close(); s_e.close()
        ok("Fusion und E|r| aus dem Payload gelesen", P_e.get("p_fusion") == 0.47 and P_e.get("er_4") == 0.0123 and P_e.get("p_up") == 0.5,
           f"p_fusion {P_e.get('p_fusion')}, er_4 {P_e.get('er_4')} (p_up {P_e.get('p_up')})")
        # Hebel-Ansicht: Liquidation bei großem Rückgang im Trade
        s = _stat([{"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 0.5, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 0, "geschlossen": 1},
                   {"netto_usd": 10, "netto_pct": 0.1, "mae_pct": 12.0, "gebuehren": 0, "funding": 0, "slip": 1, "eroeffnet": 1, "geschlossen": 2}], 0, 86_400)
        h10 = next(h for h in s["hebel"] if h["L"] == 10); h3 = next(h for h in s["hebel"] if h["L"] == 3)
        ok("Hebel-Ansicht: Liquidation", h10["ausgeloescht"] == 2 and h3["ausgeloescht"] is None and abs(h10["summe_usd"] - (100 - NOTIONAL)) < 1e-6
           and abs(h3["summe_usd"] - 60) < 1e-6, f"10×: ausgelöscht nach Trade {h10['ausgeloescht']}, Summe {h10['summe_usd']:+.0f} USD; 3×: ×{h3['faktor']:.4f}, {h3['summe_usd']:+.0f} USD")
        # 23.34: Blockstatistik -- 40 gleichzeitige Trades (dasselbe Signal, ein 4-h-Block) sind EINE Beobachtung
        rng_b = random.Random(5)
        gleich = [{"netto_usd": 30.0, "netto_pct": 0.3 + rng_b.gauss(0, 0.05), "mae_pct": 0.2, "gebuehren": 9, "funding": 0, "slip": 1,
                   "eroeffnet": 1_790_000_000 + 60 * (i % 5), "geschlossen": 1_790_010_000} for i in range(40)]
        verteilt = [dict(x, eroeffnet=1_790_000_000 + i * 5 * 3600, geschlossen=1_790_000_000 + i * 5 * 3600 + 3000) for i, x in enumerate(gleich)]
        sg = _stat(gleich, 1_789_990_000, 1_790_020_000, 1.0, block_s=4 * 3600); sv = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0, block_s=4 * 3600)
        sr = _stat(verteilt, 1_789_990_000, 1_790_800_000, 1.0)
        ok("Blockstatistik: gleichzeitige Trades zählen einmal", sg["n"] == 40 and sg["n_eff"] == 1 and sg["t"] is None and sg["stufe"] == "Kandidat"
           and sv["n_eff"] == 40 and abs((sv["t"] or 0) - (sr["t"] or 0)) < 1e-9 and (sv["t"] or 0) > 3,
           f"40 Trades in einem Block: n_eff {sg['n_eff']}, t {sg['t']}, Stufe {sg['stufe']} · verteilt: n_eff {sv['n_eff']}, t {sv['t'] or 0:+.1f}")
        kt = konten_tage(0, 10 * 86_400, {"BTC": 0, "XMR": 8 * 86_400}, ["BTC", "XMR"])
        st_k = _stat([{"netto_usd": 120.0, "netto_pct": 1.2, "mae_pct": 0.1, "gebuehren": 9, "funding": 0, "slip": 1, "eroeffnet": 100, "geschlossen": 200}],
                     0, 10 * 86_400, kt)
        ok("Kontotage: später gestarteter Coin zählt ab seinem Start", abs(kt - 12.0) < 1e-9 and abs(st_k["tag_pct"] - 120.0 / 12 / NOTIONAL * 100) < 1e-9,
           f"BTC 10 T + XMR 2 T = {kt:g} Kontotage, Ø/Tag {st_k['tag_pct']:.4f} %")
        mig = F.store_connect(os.path.join(tmp, "mig.db")); schema(mig)
        mig.execute("INSERT INTO labor_zustand VALUES ('start', ?)", (str(T0),)); mig.commit()
        cs = coin_starts(mig, ("BTC", "ETH", "XMR"), T0 + 5 * 86_400, schreiben=True); cs2 = coin_starts(mig); mig.close()
        ok("Umstellung: alte Coins behalten den Start, XMR beginnt jetzt", cs == cs2 == {"BTC": T0, "ETH": T0, "XMR": T0 + 5 * 86_400},
           f"{ {c: (t - T0) // 86_400 for c, t in cs.items()} } Tage nach dem Laborstart")
        try:
            _u160_selbsttest(tmp, db, ok)                                       # 23.68: XMR mit normaler Gebühr
        except Exception as e:
            import traceback
            ok("U160: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        try:
            _tabellen_selbsttest(tmp, ok)                                       # 23.68: U161 je Strategie und Coin, U163 Grid je Tag
        except Exception as e:
            import traceback
            ok("U161/U163: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        # 23.42: Fusion mit Kostenschwelle -- Einstieg nur, wenn |2p − 1| · E|r| mindestens 1,5 × Kosten (Taker beider Seiten plus Abstand zur
        # Buchmitte bei 10k) erreicht; die feste Schwelle 0,08 wie v1 für die Vergleichsstrategie
        S_fk = next(s_ for s_ in strategien() if s_["name"] == "prognose_fusion_kosten")
        S_fp = next(s_ for s_ in strategien() if s_["name"] == "prognose_fusion")
        bk = {"ts": 1000, "mid": 100.0, "bid": 99.99, "ask": 100.01, "spread_bps": 2.0, "kauf": [(10, 2e6), (25, 5e6)], "verkauf": [(10, 2e6), (25, 5e6)]}

        def e_f(p_, er=0.01, ts=1000, coin="AAA"):
            return {"coin": coin, "preis": bk, "prognose": {"ts": ts, "p_fusion": p_, "er_4": er, "bias": 0.0}}
        fk = {(c_, p_): [a["seite"] for a in sig_fusion(S_fk, e_f(p_, coin=c_), c_, 1200, {})] for c_, p_ in
              (("AAA", 0.60), ("AAA", 0.57), ("AAA", 0.40), ("AAA", 0.5), ("XMR", 0.60), ("XMR", 0.70))}
        k_aaa = fusion_vorsprung(S_fk, e_f(0.6), "AAA", 1200)["kosten"]
        alt_ = sig_fusion(S_fk, e_f(0.7, ts=1000 - FRISCH_S["prognose"]), "AAA", 1200, {})
        ohne_er = fusion_vorsprung(S_fk, e_f(0.7, er=None), "AAA", 1200)
        ok("Fusion mit Kostenschwelle: handelt nur über 1,5 × Kosten",
           fk == {("AAA", 0.60): ["long"], ("AAA", 0.57): [], ("AAA", 0.40): ["short"], ("AAA", 0.5): [], ("XMR", 0.60): ["long"], ("XMR", 0.70): ["long"]}
           and abs(k_aaa - (2 * GEB_TAKER + 2 * taker_preis(bk, True, NOTIONAL)[1] / 1e4)) < 1e-12 and not alt_ and not ohne_er.get("handeln"),
           f"Kosten {k_aaa * 100:.3f} % (1,5-fach {1.5 * k_aaa * 100:.3f} %), E|r| 1 %: p 60 % → {fk[('AAA', 0.60)]}, 57 % → {fk[('AAA', 0.57)]}, "
           f"40 % → {fk[('AAA', 0.40)]}; XMR (seit 23.68 Gebühr wie BTC, U160; bis 23.67 bei 60 % kein Trade) 60 % → {fk[('XMR', 0.60)]}, "
           f"70 % → {fk[('XMR', 0.70)]}; alte Prognose, fehlendes E|r| → nichts")
        fp = [[a["seite"] for a in sig_prognose(S_fp, e_f(p_), "AAA", 1200, {})] for p_ in (0.59, 0.55, 0.41)]
        ok("Prognose Fusion: feste Schwelle wie v1", fp == [["long"], [], ["short"]] and S_fk["regeln"]["puffer"] == FUSION_PUFFER == 1.5
           and status_text(S_fk, e_f(0.6), 1200, {}).startswith("Fusion 60.0 %"), f"59 % → {fp[0]}, 55 % → {fp[1]}, 41 % → {fp[2]} · Tafel: "
           f"{status_text(S_fk, e_f(0.6), 1200, {})}")
        # 23.43: Kaskaden-Kipppunkt -- Durchbruch, einmal je Kipppunkt, Kostenfilter, Ziel schon erreicht, alte Prognose, oben gespiegelt
        S_kk = next(s_ for s_ in strategien() if s_["name"] == "kaskade_kipppunkt")

        def e_k(mid, ts=1000, ka=99.0, ea=97.0, ko=None, eo=None, coin="AAA"):
            return {"coin": coin, "preis": dict(bk, mid=mid, bid=mid - 0.01, ask=mid + 0.01), "sigma1h": 0.005,
                    "prognose": {"ts": ts, "kipp_ab": ka, "ende_ab": ea, "kipp_auf": ko, "ende_auf": eo, "bias": 0.0}}

        def folge(preise, **kw):
            zk = {}; out = []
            for i, m_ in enumerate(preise):
                out.append(sig_kipppunkt(S_kk, e_k(m_, **kw), kw.get("coin", "AAA"), 1100 + 15 * i, zk))
            return out
        f1 = folge([99.5, 98.9, 99.2, 98.8])
        f2 = folge([99.5, 98.98], ea=98.95)
        f3 = folge([99.5, 96.5])
        f4 = folge([99.5, 98.9], ts=1100 - FRISCH_S["prognose"] - 30)
        f5 = folge([100.0, 100.6], ka=None, ea=None, ko=100.5, eo=103.0)
        a2 = (f1[1] or [{}])[0]
        ok("Kaskaden-Kipppunkt: Durchbruch, einmal je Kipppunkt, Kostenfilter",
           [len(x) for x in f1] == [0, 1, 0, 0] and a2.get("seite") == "short" and a2.get("tp_px") == 97.0
           and abs(a2.get("sl_px", 0) - 99.0 * (1 + 0.5 * 0.005)) < 1e-9 and a2.get("h") == 2 and [len(x) for x in f2] == [0, 0]
           and [len(x) for x in f3] == [0, 0] and [len(x) for x in f4] == [0, 0]
           and [x[0]["seite"] if x else None for x in f5] == [None, "long"] and f5[1][0]["tp_px"] == 103.0
           and status_text(S_kk, e_k(99.5), 1100, {}).startswith("Kipppunkte: unten 99"),
           f"durch 99 → {a2.get('seite')} Ziel {a2.get('tp_px')} Stop {a2.get('sl_px', 0):.4f}, zweiter Durchgang nichts; Weg 0,03 % < 1,5 × Kosten → "
           f"nichts; schon jenseits des Endes → nichts; alte Prognose → nichts; oben durch 100,5 → {f5[1][0]['seite'] if f5[1] else '—'} · Tafel: "
           f"{status_text(S_kk, e_k(99.5), 1100, {})}")
        ep = darwin_episoden([(1000, "a", "X", "Open Long*", 1, 4000, 1), (1100, "a", "X", "Open Long*", 1, 4000, 2), (1150, "a", "X", "Close Long", 1, 8000, 3),
                              (1200, "a", "X", "Open Long*", 1, 6000, 4), (1250, "a", "X", "Close Long", 1, 300, 5), (1300, "a", "X", "Open Long*", 1, 5000, 6),
                              (2000, "a", "X", "Close Long", 1, 3000, 7), (2100, "a", "X", "Close Long", 1, 3000, 8), (4000, "a", "X", "Open Long*", 1, 12000, 9)])
        ok("Darwin-Nachrechnung: netto, halbe Schließung, neue Eröffnung", [(e["ts"], e["n"], round(e["usd"]), e["aus"]) for e in ep] == [(1300, 2, 10700, 2100), (4000, 1, 12000, None)],
           f"{[(e['ts'], e['n'], round(e['usd']), e['aus']) for e in ep]} (Soll: 1300 aus 2 Stücken 10,7k, Ausstieg 2100; neu 4000)")
        pt = (p_t_einseitig(3.4, 7), p_t_einseitig(2.0, 1000), p_t_einseitig(-1.0, 10), p_t_einseitig(0.0, 5))
        ok("Student-t: Glück bei wenigen Trades", abs(pt[0] - 0.00572) < 3e-4 and abs(pt[1] - 0.02288) < 3e-4 and abs(pt[2] - 0.8296) < 3e-4 and abs(pt[3] - 0.5) < 1e-9,
           f"t 3,4 bei 8 Trades: {pt[0] * 100:.2f} % (Normalverteilung {0.5 * math.erfc(3.4 / math.sqrt(2)) * 100:.3f} %)")
        # 23.40: Stufen und Trendmaß
        stf = grid_stufen(100.0, 102.0, 0.002, 4, 12); eng = grid_stufen(100.0, 100.5, 0.002, 4, 12); weit = grid_stufen(100.0, 110.0, 0.002, 4, 12)
        rw = random.Random(9); kz = []; lp_ = 0.0
        for i in range(1440):
            lp_ += rw.gauss(0, 0.0005); kz.append((1_790_000_040 + 60 * i, 100 * math.exp(lp_)))
        tr_ = grid_range(kz)["trend"]; tr_auf = grid_range([(t_, c_ * math.exp(0.00004 * i)) for i, (t_, c_) in enumerate(kz)])["trend"]
        ok("Grid: Stufen und Trendmaß", stf and len(stf[0]) == 10 and abs(stf[1] - (1.02 ** (1 / 9) - 1)) < 1e-12 and eng is None and len(weit[0]) == 13
           and abs(tr_) < 2.5 and tr_auf > tr_ + 2 and grid_trend_ok(0.5, {"richtung": "long", "trend_gegen": 1.0, "trend_mit": 2.0})
           and not grid_trend_ok(-1.2, {"richtung": "long", "trend_gegen": 1.0, "trend_mit": 2.0})
           and grid_trend_ok(-1.2, {"richtung": "short", "trend_gegen": 1.0, "trend_mit": 2.0}),
           f"2 % → {len(stf[0]) - 1 if stf else 0} Stufen à {stf[1] * 100 if stf else 0:.3f} %, 0,5 % → zu eng, 10 % → {len(weit[0]) - 1} Stufen; "
           f"Trend Zufallsweg {tr_:+.2f}, mit Drift {tr_auf:+.2f}")
        alt_jetzt = {s_["sid"] for s_ in strategien() if s_["gruppe"] not in ("Swing", "Akkumulation")}
        sw_jetzt = {s_["sid"] for s_ in strategien() if s_["gruppe"] == "Swing"}
        ok("Kennungen: alle übrigen unverändert; Swing und Zyklus seit 23.68 (U164, feste Größe) neun neue, keine alte mehr aktiv; "
           "23.83 dazu die zwei der Extrem-Wende (U226)",
           alt_jetzt == set(ALTE_KENNUNGEN) and sw_jetzt == set(SWING_KENNUNGEN_2368) | set(WENDE_KENNUNGEN_2383)
           and not (sw_jetzt & set(SWING_KENNUNGEN_2362))
           and len(strategien()) == len(ALTE_KENNUNGEN) + 9 + len(WENDE_KENNUNGEN_2383) + len(AKKU_NAMEN)
           and all(s_["regeln"].get("groesse") == "fest" for s_ in strategien() if s_["gruppe"] == "Swing")
           and all("groesse" not in SW.STRATEGIEN[n_] for n_ in SW.STRATEGIEN),
           f"{len(alt_jetzt & set(ALTE_KENNUNGEN))} von {len(ALTE_KENNUNGEN)} gleich; Swing/Zyklus: {sorted(sw_jetzt)}")
        try:
            _swing_selbsttest(tmp, ok)
        except Exception as e:
            import traceback
            ok("Swing: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        try:
            _dip_selbsttest(tmp, ok)
        except Exception as e:
            import traceback
            ok("Zyklus: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        try:
            _wende_selbsttest(tmp, ok)                                     # 23.83 (U226)
        except Exception as e:
            import traceback
            ok("Extrem-Wende: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        try:
            _grid_selbsttest(tmp, ok)
        except Exception as e:                                    # ein Absturz der Probe ist ein Befund, kein Abbruch
            import traceback
            ok("Grid: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
        try:
            _akku_selbsttest(tmp, ok)                             # 23.69 (U180)
        except Exception as e:
            import traceback
            ok("Akkumulation: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p[1] for p in pruef)
    if verbose:
        print("TradeLabor -- Selbsttest (synthetischer Markt, fester Zeitpunkt)")
        for name, gut, text in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
        print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_wende() -> bool:
    """23.83 (U226): nur die Labor-Proben der Extrem-Wende (wenige Sekunden; der ganze Selbsttest enthält sie auch)."""
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="labor_wende_"); erg = []

    def ok(name, bed, text=""):
        erg.append(bool(bed))
        print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f"  ({text})" if text and not bed else ""), flush=True)
    try:
        _wende_selbsttest(tmp, ok)
    except Exception as e:  # noqa: BLE001
        import traceback
        ok("Extrem-Wende: Probe ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"Ergebnis: {'bestanden' if all(erg) else 'NICHT bestanden'} ({sum(erg)} von {len(erg)})")
    return bool(erg) and all(erg)


if __name__ == "__main__":
    if "--selbsttest-wende" in sys.argv:                                    # 23.83 (U226): nur die Proben der Extrem-Wende
        sys.exit(0 if selbsttest_wende() else 1)
    if "--selbsttest" in sys.argv or "--nulltest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--bericht" in sys.argv:
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv and sys.argv.index("--db") + 1 < len(sys.argv) else None
        print(bericht_text(F.STORE, db=db_))
        sys.exit(0)
    if "--akku-rueckblick" in sys.argv:                                     # 23.69 (U180): Rückblick auf der Historie
        db_ = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv and sys.argv.index("--db") + 1 < len(sys.argv) else None
        if not db_:
            print("--db PFAD fehlt"); sys.exit(2)
        print(akku_rueckblick_text(db_))
        sys.exit(0)
    print("Aufruf: hl_labor.py --selbsttest | --selbsttest-wende | --bericht [--db PFAD] | --akku-rueckblick --db PFAD")
