# KONZEPT Volumen (U221) — Laufen die Einstiege der Trading-Strategien bei hohem oder niedrigem Volumen besser?

Stand 24.10.2026, Version 2026-09-23.81 (Opus 5.5). **Status: vorab festgelegt und vom Nutzer freigegeben (24.10. 03:17 „Freigeben wie
vorgeschlagen“), gebaut in 23.81 (`hl_volumen.py`) — bevor eine einzige echte Zahl dieser Studie gerechnet wurde.** Nach einer
unabhängigen Durchsicht (Abschnitt 13) überarbeitet. Präzisierungen und eine Korrektur beim Bau mit Datum in Abschnitt 12.

**Frage des Nutzers (24.10. 02:13):** „wir brauchen für alle trading strategien eine volumen analyse. Lassen sich volumendaten von den
bestehenden börsen holen?“ Datenlage in UEBERGABE 3οοοο. **Entscheidung des Nutzers (02:37):** „Erst messen, dann filtern“ — erst je
Strategie messen, ob Einstiege bei hohem oder niedrigem Volumen bzw. Taker-Saldo besser laufen (nur Bericht); Filter erst, wenn das belegt
ist, und nicht vor dem 25.10.

**Zusage bis 25.10. bleibt:** Die Studie liest nur. Sie ändert weder Labor (Welt A und B), Konfluenz, Prognose, Fusion, v3, Kaskaden-
Rechnung noch v1-Lernen, und sie fließt nirgends ein. Sie darf vor dem 25.10. laufen.

## 0. Kurzfassung

- **Teil A (live):** alle geschlossenen Trades des TradeLabors in Welt B (`forecasts.db`, das unveränderte Original) seit dem Start
  am 27.09. Je Trade zwei Kennzahlen zum **Zeitpunkt der Entscheidung**, nur aus Daten davor, aus der eigenen Hyperliquid-Aufzeichnung:
  - **RV** relatives Volumen: Umsatz in USD im Fenster vor dem Einstieg ÷ Median desselben Fensters zur gleichen Uhrzeit an den Tagen
    gleicher Art (Werktag oder Wochenende) der 28 Tage davor.
  - **TS** Taker-Saldo in Handelsrichtung: (Taker-Kauf − Taker-Verkauf) ÷ beides im selben Fenster, abzüglich seines üblichen Werts zur
    gleichen Uhrzeit, für Shorts mit umgekehrtem Vorzeichen; positiv heißt: Die Aggressoren drückten stärker als sonst in unsere Richtung.
  - Fenster 60 min für Strategien mit Horizont bis 12 h, 24 h darüber.
- **Prüfgröße:** D = mittlerer Netto-Ertrag (in %) im oberen Drittel der Kennzahl − im unteren Drittel. Die Drittel werden je Schicht
  gebildet (Strategie × Long/Short × Werktag/Wochenende), damit weder Wochentag noch Long gegen Short als „Volumen“ durchgehen.
- **Nullmodell:** Zeitverschiebung der Kennzahl-Reihen gegen die Trades um ±24 bis ±336 Stunden (626 Verschiebungen) — Trades und
  Ergebnisse bleiben, die Reihen bleiben, nur die Zuordnung „Volumen vor diesem Einstieg“ wird gelöst.
- **Teil B (Historie):** die vier Swing-Strategien seit 2020 auf Binance-Daten (wie die Swing-Studie), mit Tages-RV und Tages-Taker-
  Anteil aus `hebel.db`. Urteilt schon jetzt mit gut 1.000 Trades, aber nur für diese Familie.
- **Hauptprüfungen gepoolt** (A1, A2, B1, B2); je Strategie ein eigenes Urteil mit Familienfehler.
- **Urteil Teil A erst am 08.11.2026** (sechs Wochen Labor); jeder Lauf davor heißt „vorläufig“. Teil B urteilt beim ersten Lauf.
- **Folgen:** Nur, was belegt ist, wird in Stufe 2 als neue Labor-Variante mit Volumenfilter geprüft (eigener, vorab festgelegter
  Plan-Punkt, nicht vor dem 25.10.).

## 1. Die Fragen, messbar gemacht

| Frage | Messung | Prüfung |
|---|---|---|
| Laufen Einstiege bei ungewöhnlich hohem Volumen besser oder schlechter? | D_RV | A1 gepoolt, je Strategie; B1 Swing-Historie |
| Hilft es, wenn die Aggressoren vor dem Einstieg stärker als sonst in unsere Richtung drücken (oder schadet es)? | D_TS | A2 gepoolt, je Strategie; B2 Swing-Historie |
| Gilt das für alle Strategien gleich? | D je Strategie, je Gruppe | je Strategie mit Familienfehler; Gruppen beschreibend |
| Ist es ein Effekt der Strategie oder des Marktes? | D der Zufalls-Kontrollen | beschreibend: D(Strategie) − D(Zufall) |

„Besser“ heißt: höherer Netto-Ertrag je Trade nach Gebühren, Abstand zur Buchmitte und Funding, so wie die Bilanz des Labors rechnet
(`netto_pct`).

## 2. Erwartung (ehrlich, vorab)

- Eine Literaturrecherche gab es für diese Studie nicht. Allgemein gilt: Volumen geht mit Schwankung einher. Aggressiver Ordnungsfluss
  bewegt den Kurs kurzfristig, die Wirkung klingt aber binnen Minuten bis Stunden ab. Volumen allein sagt die Richtung kaum.
- Eigene Befunde: Die meisten Signale des Projekts trugen auf echten Daten nicht (Konfluenz 54 % gegen 52 % Zufall am 07.10.; U130 0 von
  45; Magnet und Anker ohne Beleg). Das Labor steht insgesamt im Minus (07.10.: 3.580 Trades, netto −72.792 USD).
- **Erwartet:**
  - **A1 (RV gepoolt):** am ehesten ein kleiner Effekt, weil hohes Volumen die Schwankung und damit Stop-Treffer verändert. Vorzeichen
    offen.
  - **A2 (TS gepoolt):** schwach. Trendfolger könnten profitieren, Gegenbewegungs-Strategien leiden; gepoolt hebt sich das teilweise auf,
    darum die Gruppen beschreibend.
  - **Je Strategie:** in sechs Wochen fast nirgends belegt.
- **Trennschärfe** (80 % Wahrscheinlichkeit, einen Effekt dieser Größe zu finden; grobe Rechnung):
  - je Strategie mit 300 Trades (Streuung des Ertrags um 1,2 %) nach Familienfehler über rund 80 Tests: D um 0,7 Prozentpunkte;
  - gepoolt (mehrere Tausend Trades, wegen gleichzeitiger Einstiege weniger unabhängige): D um 0,14 Punkte;
  - Teil B: gut 1.000 Trades (S1 343, S2 421, S3 206, S4 67; `KONZEPT_Swing.md` 6b), Streuung um 2 R je Trade: D um 0,47 R.
- Kurz: Die gepoolten Prüfungen sind die realistischen. „Nicht belegt“ je Strategie heißt meist „zu wenig Trades“, nicht „kein Effekt“;
  der Bericht sagt es ausdrücklich (Band breit oder eng um 0).

## 3. Daten

### 3a. Quellen

| Reihe | Quelle | Auflösung | Gebraucht für |
|---|---|---|---|
| Umsatz | `hl_liq.db` → `bars` (Volumen in Coin × Schluss = USD) | 1 min | RV (Teil A) |
| Taker-Kauf, Taker-Verkauf, Zahl der Trades | `hl_liq.db` → `bars10` (`vol_buy` = Taker kauft und trifft den Ask, `vol_sell`; Coin-Einheiten), je Minute zusammengefasst | 10 s → 1 min | TS (Teil A), Prüfung der Minuten (3c) |
| Trades des Labors | `forecasts.db` → `labor_position` (geschlossen), `labor_order` (Limit-Einstiege), `labor_strategie` (Name, Gruppe, Regeln, aktiv) | je Trade | Teil A |
| Tagesumsatz und Taker-Kauf in USD des USDⓈ-M-Perps `<COIN>USDT` | `hebel.db` → `hb_kerzen` (Markt „um“, `v_usd`, `taker_usd`) | 1 Tag | Teil B |
| 30-min-Kerzen der Perps, Funding | `swing.db` (wie die Swing-Studie) | 30 min | Teil B (Trades) |
| Binance 30-min-Volumen, Coinbase-Taker-Seiten | `klines30`, `cb_bars` (Seiten über `cb_seite_ab`, U41) | 30 min / 1 min | nur beschreibend (6.4, 6.5) |

- **Coins:** die Labor-Coins BTC, ETH, ZEC, HYPE, XMR (XMR im Labor ab 29.09.). Teil B: dieselben fünf, HYPE ab 30.05.2025.
- **Spanne Teil A:** von der ersten Minute, ab der die Kennzahl bestimmt ist (28 Tage Aufzeichnung davor), bis zum Stichtag (08.11.
  00:00 UTC; bei vorläufigen Läufen: Laufzeit, auf die Minute abgerundet). Trades davor fallen heraus (gezählt).
- **Welt A** (`labor_a.db`, mit dem Tor der Notbremse seit 23.76) nur beschreibend (6.7) — sie ist eine Kopie mit Tor.
- **Nicht gebraucht:** Hyperliquids `candleSnapshot` (kostet API-Gewicht, der Recorder läuft am Deckel; U218).

### 3b. Zeitpunkt der Entscheidung t0 (kausal)

- Einstieg zum Marktpreis: t0 = `labor_position.eroeffnet`.
- Einstieg über eine Limit-Order (`art_ein` beginnt mit „Limit“): t0 = `labor_order.erstellt` der Order mit `pos_id` = diese Position
  (bei einer neu gelegten Order die zuletzt gelegte, gefüllte). Ohne zugehörige Order fällt der Trade heraus (gezählt).
- t0 wird auf die volle Minute abgerundet; alle Fenster enden dort: [t0 − W, t0). Damit zählt nur, was vor der Entscheidung lag.
- Ausgeschlossen: Trades, die mit „Regelversion abgelöst“ zwangsweise geschlossen wurden (künstlicher Ausstieg), und Trades, die am
  Stichtag noch offen sind.

### 3c. Gültigkeit

- **Ausfall des Recorders:** Eine Minute gilt als „nicht aufgezeichnet“, wenn BTC in ihr keine Bar hat (BTC handelt auf Hyperliquid in
  jeder Minute). Minuten ohne Bar eines anderen Coins bei laufendem Recorder zählen als Umsatz 0.
- **Fragliche Minute:** `bars.volume` und die Summe aus `bars10` (Kauf + Verkauf) derselben Minute weichen um mehr als 1 % voneinander
  ab. Beide entstehen aus denselben Trades und müssten gleich sein. Eine Abweichung zeigt, dass ein verspäteter Trade ein schon
  geschriebenes Stück überschrieben hat (`INSERT OR REPLACE` mit einem Bruchstück, siehe 13.6; U222). Der Bericht zählt sie je Coin.
- **Gültiges Fenster:** höchstens 5 % der Minuten nicht aufgezeichnet oder fraglich.
- **RV:** bestimmt, wenn mindestens 70 % der Vergleichsfenster gültig sind und ihr Median > 0 ist.
- **TS:** bestimmt, wenn im Fenster mindestens 20 Trades lagen (Summe `bars10.trades`) und die Vergleichsfenster wie bei RV reichen.
- **Pflichtprüfung der Seiten** (vor jeder Rechnung mit TS): Je Coin muss die Rangkorrelation zwischen dem Taker-Saldo einer Minute und
  der Rendite derselben Minute über die ganze Spanne größer als +0,1 sein (aggressive Käufe heben den Kurs). Sonst gilt TS für diesen
  Coin als „Seiten fraglich“ und fällt aus A2 heraus (im Bericht genannt). Synthetische Proben fangen eine vertauschte Seite wie U41 nicht.
- Ausfallende Trades werden je Strategie und Grund gezählt und im Bericht genannt.

## 4. Größen

- **Fenster W:** 60 min, wenn der Horizont der Strategie (Regel `h`) höchstens 12 h ist; 24 h bei 24 h und mehr (Familien Trend,
  Funding, ETF, Analog; Funding-Extrem; Grid; Swing und Zyklus; Akkumulation; „Halten Long“).
- **Tagesart:** Werktag (Montag–Freitag, UTC) oder Wochenende (Samstag–Sonntag, UTC), bestimmt am Ende des Fensters.
- **Vergleichszeiten** zu t: {t − k · 24 h : k = 1 … 28, Tagesart gleich wie bei t} — an Werktagen rund 20, am Wochenende 8.
- **Umsatz U(t, W):** Σ Schluss × Volumen der Minuten in [t − W, t).
- **RV(t) = U(t, W) ÷ Median { U(v, W) : v Vergleichszeit von t }.**
- **Saldo I(t, W) = (B − S) ÷ (B + S)** über [t − W, t), B und S aus `bars10`.
- **TS(t0) = s · ( I(t0, W) − Median { I(v, W) : v Vergleichszeit von t0 } )**, s = +1 für Long, −1 für Short.
- **Reihen:** RV und I_rel = I − Median werden einmal auf der echten Zeitachse je Minute berechnet (nur Vergangenheit), getrennt für
  W = 60 min und 24 h. Die Nullmodelle verschieben diese fertigen Reihen, nicht das Rohvolumen.
- **Ergebnis je Trade:** `netto_pct` (Netto-Ertrag nach Gebühren, Abstand zur Buchmitte und Funding in % des Notionals).
- **Strategie:** der Name (`labor_strategie.name`); alle Kennungen eines Namens (auch alte, `aktiv` = 0) zählen zur Strategie, als
  eigene Schicht.
- **Schicht:** (Kennung, Long/Short, Tagesart). In jeder Schicht mit mindestens 9 gültigen Trades werden die Drittel nach der Kennzahl
  gebildet (1/3- und 2/3-Quantil; Gleichstand nach der Reihenfolge von t0, stabil); kleinere Schichten fallen heraus (gezählt).
- **D je Schicht** = Ø netto (oberes Drittel) − Ø netto (unteres Drittel).
- **D je Strategie** = Σ n_Schicht · D_Schicht ÷ Σ n_Schicht über ihre Schichten.
- **D_pool** = dasselbe über alle Schichten der Strategien im Pool.
- **Pool** (Teil A) — vorab festgelegt, gilt für jede Verschiebung, jede Hälfte und jede Bootstrap-Ziehung gleich: alle Strategien mit
  mindestens 30 gültigen Trades bei τ = 0, **außer**
  - Kontrollen: alle Namen mit „zufall“ (`zufall`, `swing_zufall`, `swing_ruecksetzer_zufall`, `zyklus_dip_zufall`) und `halten_long`;
  - **volumengekoppelte Auslöser** — ihr Einstieg hängt selbst an Volumen oder Ordnungsfluss, ihr D misst die Stärke des eigenen
    Auslösers: `familie_orderfluss` (Taker-Flow, Orderbuch), `familie_momentum` (Vol-Spike-Reversion), `kaskade_umkehr`,
    `kaskade_fortsetzung`, `kaskade_kipppunkt`, `docht_fangen` und `magnet` (Cluster ab 10 % des Stundenvolumens), `twap_druck` (ab 2 %
    des Stundenvolumens). Sie bekommen ihre Urteile je Strategie und eine eigene Gruppe in 6.1;
  - **Spiegelpaare:** von `wale`, `leaderboard`, `smartmoney`, `pool`, `darwin`, `elite` nur „…_folgen“ — „…_gegen“ handelt dieselben
    Signale umgekehrt (sein D_TS gleicht dem von „folgen“, sein D_RV ist dessen Spiegel) und würde sonst doppelt bzw. gegenläufig zählen;
  - Grid (Bestandslogik, Lose statt Signale) und Akkumulation (nur Käufe) — beschreibend (6.8, 6.9).
- **Teil B (Historie):**
  - **Trades:** `hl_swing.lauf` je Coin und Strategie aus `hl_swing.HAUPT` über den Bewertungsbereich bis einschließlich 23.10.2026
    (fester Datenschluss), mit denselben Daten und Regeln wie die Swing-Studie (`daten_aufbereiten` aus `swing.db`); ohne Trades „offen am
    Ende“.
  - **Entscheidung** am Schluss von Tag e−1 (Einstieg zur Eröffnung von Tag e, wie `hl_swing.handel`); Kennzahlen aus Tag e−1 und davor.
  - **RV_Tag(e−1) = v_usd(e−1) ÷ Median v_usd** der Vergleichstage gleicher Tagesart in den 28 Tagen davor (USDⓈ-M-Perp `<COIN>USDT`,
    `hb_kerzen`, Markt „um“); mindestens 70 % vorhanden.
  - **TS_Tag(e−1) = s · ( q(e−1) − Median q(Vergleichstage) )** mit q = 2 · taker_usd ÷ v_usd − 1.
  - **Ergebnis:** R je Trade (netto ÷ Risiko aus `hl_swing.handel`); Schichten (Strategie, Long/Short, Tagesart von e−1); Hälften am
    Median von `t_in`.

## 5. Hauptprüfungen (vorab festgelegt)

| | Teil | Kennzahl | Trades | Statistik | Null | Richtung |
|---|---|---|---|---|---|---|
| A1 | live | RV | Pool (Abschnitt 4) | D_pool | Verschiebung der fertigen RV- bzw. TS-Reihen um τ = ±24 … ±336 h in ganzen Stunden (626 Werte), zirkulär über die Spanne aus 3a, dasselbe τ für alle Coins; Drittel je Verschiebung neu | zweiseitig |
| A2 | live | TS | Pool | D_pool | wie A1 | zweiseitig |
| B1 | Historie | RV_Tag | vier Swing-Strategien, fünf Coins | D_pool in R | Verschiebung der fertigen Tagesreihen um τ = ±30 … ±365 Tage (672 Werte), dasselbe τ für alle Coins, zirkulär je Coin über dessen Spanne | zweiseitig |
| B2 | Historie | TS_Tag | wie B1 | D_pool in R | wie B1 | zweiseitig |

- **p (Hauptprüfungen)** = (1 + Zahl der Verschiebungen mit |D_null − m| ≥ |D − m|) ÷ (1 + Zahl der Verschiebungen), m = Median der
  D_null. Gemessen wird der Abstand vom Median des Nullmodells, nicht von 0 — so verschiebt ein Versatz der Null-Verteilung das Urteil
  nicht.
- **Holm** je Teil über die beiden Hauptprüfungen (A1, A2) bzw. (B1, B2).
- **Belegt** = p_Holm < 0,05 **und** beide Hälften (Teilung am Median von t0; Drittel in jeder Hälfte neu gebildet) zeigen D − m mit
  demselben Vorzeichen wie im Ganzen.
- **Intervall:** 90-%-Band aus dem Blockbootstrap über Kalendertage von t0 (Teil A: 1 Tag; Teil B: 60 Tage; je 1000 Ziehungen; Drittel
  in jeder Ziehung neu gebildet, Pool und Schichten wie bei τ = 0).
- **Prüfbar:** Teil A gepoolt mit mindestens 300 gültigen Trades über mindestens 21 Tage; Teil B mit mindestens 150 Trades.
- **Je Strategie** (Teil A alle Strategien; Teil B je Swing-Strategie): prüfbar mit mindestens 60 gültigen Trades über mindestens 14
  Tage. Weil 626 Verschiebungen kein p unter 1/627 erlauben und benachbarte Verschiebungen sich stark ähneln, kommt das p je Strategie aus
  der Normalnäherung des Nullmodells: z = (D − m) ÷ Standardabweichung der D_null, p = 2 · (1 − Φ(|z|)). Familienfehler über alle
  prüfbaren Tests (Strategie × Kennzahl) des Teils:
  - **belegt** = p_Holm < 0,05, beide Hälften mit demselben Vorzeichen und das 90-%-Band ohne die 0;
  - **Hinweis** = q < 0,10 nach Benjamini-Hochberg und beide Hälften — kein Urteil, nur ein Kandidat für eine Entscheidung des Nutzers.
  - Der Bericht zeigt daneben die Wölbung der Null-Verteilung (bei schweren Rändern ist die Normalnäherung zu mild).
- **Zeitpunkt des Urteils (Teil A):** Lauf am **08.11.2026 ab 09:15** (geplanter Bericht). Es zählen die Trades, die vor dem 08.11.
  00:00 UTC geschlossen wurden. Jeder frühere Lauf zeigt dieselben Zahlen mit dem Vermerk „vorläufig — kein Urteil“. Kein früheres
  Urteil, auch wenn ein Zwischenstand „belegt“ aussieht (sonst zählt das wiederholte Hinsehen als Auswahl).
- **Teil B** urteilt beim ersten Lauf mit vollständiger Historie bis 23.10.2026 (alle Monatskerzen in `hebel.db` und `swing.db`
  geladen); sonst „vorläufig“.
- **Warum Zeitverschiebung:** Sie behält die Trades mit ihren Ergebnissen und die Kennzahl-Reihen mit ihrer Ballung (ruhige und hektische
  Wochen) und löst nur die Zuordnung. RV und TS sind schon gegen Uhrzeit und Tagesart bereinigt, und die Drittel werden je Tagesart
  gebildet — eine Verschiebung, die einen Werktag auf ein Wochenende legt, verschiebt deshalb keine Wochenend-Effekte ins Ergebnis.
  Mindestens ±24 h, damit das Fenster vor dem Einstieg nicht mit sich selbst überlappt.
- **Dieselben Trades in jeder Verschiebung:** Die Menge der Trades und der Pool stehen bei τ = 0 fest. Ist die verschobene Kennzahl nicht
  bestimmt (Ausfall, fragliche Minuten), fehlt der Trade nur in dieser Verschiebung (gezählt). Weil die Reihen fertig verschoben werden,
  bleibt jede Kennzahl kausal berechnet; nur die Zuordnung wandert zirkulär über die Spanne.

## 6. Beschreibend (kein Urteil)

1. **Je Gruppe** (Händler, Prognose, Familien, Ereignisse, Swing, volumengekoppelt): D_RV und D_TS mit Band und z, ohne Familienfehler.
2. **Je Strategie:** Ø netto und Treffer je Drittel; Grenzen der Drittel je Schicht (RV als Faktor, TS als Abweichung vom üblichen
   Saldo); gültige Trades und Ausfälle je Grund.
3. **Kontrolle „Zufall“** (`zufall`, 4 h): D_RV und D_TS — der Markteffekt. Daneben je Strategie D − D(Zufall) mit Band.
4. **Binance-RV** (30-min-Volumen aus `klines30`, Fenster auf 30 min abgerundet, Normalwert wie RV): D gepoolt — dasselbe am
   Gesamtmarkt.
5. **Coinbase-Taker-Saldo** (Spot, `cb_bars`, Seiten über `cb_seite_ab`, bereinigt wie TS): D gepoolt — US-Spot-Nachfrage in
   Handelsrichtung.
6. **Spitze:** größter 5-min-Umsatz im Fenster ÷ Median der 5-min-Umsätze der 24 h davor; D gepoolt.
7. **Welt A:** D_RV und D_TS gepoolt — zum Abgleich, ob das Tor der Notbremse die Verteilung verschiebt.
8. **Grid:** Tagesergebnis (`labor_grid_tag` und realisierte Lose) gegen den Tages-RV des Coins, je Drittel.
9. **Akkumulation:** Kurs 7 Tage nach jedem Kauf (`labor_akku_kauf`) gegen RV (24 h) zum Kauf, je Drittel.
10. **Je Coin, Werktag gegen Wochenende, Long gegen Short:** D gepoolt getrennt.
11. **Datenlage:** fragliche Minuten je Coin und Tag (das Ausmaß von 13.6), nicht aufgezeichnete Minuten, Rangkorrelation der Seiten-
    prüfung je Coin.
12. **Teil B zusätzlich:** Zufalls-Swing-Strategien (`swing_zufall`, `swing_ruecksetzer_zufall`) als Markteffekt; je Jahr.

## 7. Stand heute (nur Lage)

Je Coin: RV und TS der letzten 60 min und 24 h, dazu die Drittelgrenzen der Strategien, die gerade offen sind. Keine Empfehlung.

## 8. Folgen (vorab)

- **Belegt (gepoolt A1/A2 oder je Strategie):** Vorschlag an den Nutzer für Stufe 2 — neue Labor-Variante „⟨Strategie⟩ nur bei ⟨Kennzahl⟩
  im oberen (bzw. unteren) Drittel“, die Grenzen eingefroren aus diesem Lauf (nicht neu geschätzt), mit neuer Kennung neben der
  unveränderten Strategie. Eigener, vorab festgelegter Plan-Punkt mit eigenem Urteil (mindestens 4 Wochen, Vergleich gegen das Original
  im selben Zeitraum). Nicht vor dem 25.10. und nicht vor dem Urteil dieser Studie.
- **Gepoolt belegt, je Strategie nicht:** Der Effekt gilt im Mittel. Stufe 2 dann für die Strategien mit den meisten Trades zuerst; der
  Nutzer wählt.
- **Belegt nur in Teil B (Historie):** Stufe 2 für die Swing-Strategien erst nach Bestätigung im Labor (Teil A oder die Variante
  selbst) — die Historie war schon die Grundlage der Swing-Regeln (Gefahr der Mehrfachnutzung).
- **Hinweis (BH):** Der Nutzer entscheidet, ob daraus eine Variante wird.
- **Nicht belegt:** kein Filter. Der Bericht nennt, ob es an zu wenigen Trades lag (Band breit) oder ob das Band einen nennenswerten
  Effekt ausschließt (Band eng um 0).
- **Markteffekt** (gilt auch für „Zufall“): Der Nutzer entscheidet, ob ein Volumen-Hinweis in die Anzeige kommt; nicht in die Konfluenz
  ohne eigenen Plan-Punkt.
- Kein Echtgeld.

## 9. Bericht

Debug **„★ Volumen: Einstiege der Strategien nach Volumen (U221)“** (`hl_volumen.py --studie --db <hl_liq.db>`, liest nur):
- **Daten:** Spanne je Coin, nicht aufgezeichnete und fragliche Minuten, Seitenprüfung, Trades je Strategie (gültig, ohne Kennzahl, ohne
  Order bei Limit, „Regelversion abgelöst“, zu kleine Schicht).
- **Hauptprüfungen A1, A2, B1, B2:** D mit Band, m (Median der Null), p, p_Holm, Hälften, Urteil (oder „vorläufig“).
- **Je Strategie:** n, Schichten, Ø netto je Drittel, D, Band, z, p, p_Holm, q, Hälften, Urteil bzw. Hinweis; sortiert nach Gruppe.
- Beschreibende Teile 6.1–6.12, Stand heute (7), Lesart.

Berichtsplan: Teil B beim ersten Lauf nach dem Einspielen; Teil A sonntags „vorläufig“ und das Urteil am 08.11. 09:15. Laufzeit-Budget
15 min (geplante Berichte); Ziel unter 2 min auf dem Pi (Minutenreihen je Coin im Speicher, Fenster über kumulierte Summen, die
Verschiebungen vektorisiert) — gemessen wird es beim Bau.

## 10. Proben (Selbsttest ohne Netz)

- **Rechnung von Hand:** RV und TS für ein erfundenes Minutenraster (Fenster 60 min und 24 h, Vergleichszeiten gleicher Tagesart,
  Gültigkeit mit BTC-Lücke und fraglicher Minute, Vorzeichen bei Short, `vol_buy`/`vol_sell` richtig herum, Mindestzahl Trades); Drittel
  mit Gleichstand je Schicht; D von Hand.
- **Kausalität:** Volumen nach t0 beliebig verändert → keine Kennzahl ändert sich; t0 bei Limit-Einstieg = Zeitpunkt der gefüllten
  Order; t0 auf die Minute abgerundet.
- **Nullmodell:** Verschiebungen ohne |τ| < 24 h, Anzahl 626, zirkulär über die Spanne, verschoben werden die fertigen Reihen; p mit
  Abstand vom Null-Median; Normalnäherung je Strategie; Holm und BH von Hand.
- **Störgrößen:** ein reiner Wochenend-Effekt im Ertrag → kein „belegt“ für RV; ein reiner Long-gegen-Short-Unterschied → kein „belegt“
  für TS.
- **Positivkontrolle:** erfundene Trades, deren Ertrag im oberen RV-Drittel um 0,3 Punkte höher liegt (bzw. bei positivem TS) → A1 bzw.
  A2 belegt, je Strategie erkannt, wo die Zahl der Trades reicht.
- **Negativkontrolle:** Ertrag unabhängig vom Volumen → in mindestens 18 von 20 Saaten kein „belegt“.
- **Markteffekt:** Effekt nur in der Zufalls-Kontrolle → als Markteffekt ausgewiesen, D − D(Zufall) um 0.
- **Pool:** volumengekoppelte, Spiegel („…_gegen“) und Zufalls-Strategien nicht im Pool; Pool bei τ = 0 fest.
- **Teil B:** Swing-Trades aus `hl_swing.lauf` auf erfundenen Kerzen; Tages-RV und Taker-Anteil von Hand; Entscheidung am Schluss von
  Tag e−1; „offen am Ende“ ausgeschlossen; Datenschluss 23.10.
- **Mutationen** (müssen rot werden): Fenster bis einschließlich t0 (Zukunft), TS ohne Vorzeichen der Seite, `vol_buy` und `vol_sell`
  vertauscht (die Seitenprüfung muss anschlagen), Drittel über alle Strategien statt je Schicht, Tagesart ignoriert, τ = 0 in der Null,
  Rohvolumen statt fertiger Reihen verschoben, p gegen 0 statt gegen den Null-Median, ohne Holm, Limit-Trades mit `eroeffnet`,
  BTC-Lücke nicht als Ausfall, fragliche Minuten nicht geprüft, „…_gegen“ im Pool, Urteil vor dem 08.11.

## 11. Entscheidungen beim Nutzer

1. **Zeitpunkt des Urteils Teil A:** 08.11.2026 (Vorschlag; sechs Wochen Labor). Früher heißt weniger Trades, später verzögert Stufe 2.
2. **Teil B (Swing-Historie) mitbauen:** ja (Vorschlag) — urteilt sofort und mit vielen Trades, aber nur für die Swing-Familie.
3. **Stufe 2 nur für „belegt“** (Vorschlag) oder auch für „Hinweis“.
4. **Zwei Kennzahlen (RV, TS) als Hauptprüfungen** (Vorschlag) — jede weitere Kennzahl kostet Trennschärfe durch den Familienfehler; die
   übrigen bleiben beschreibend.

**Entscheidung des Nutzers (24.10.2026 03:17, Zeitstempel der Antwort):** „Freigeben wie vorgeschlagen (Vorschlag)“ — alle vier Punkte wie
vorgeschlagen: Urteil Teil A am 08.11., Teil B mitbauen, Stufe 2 nur für „belegt“, zwei Hauptkennzahlen RV und TS.

## 12. Änderungen am Plan

**24.10.2026 beim Bau (nach der Freigabe um 03:17, Stand 04:57; vor jeder echten Zahl, kein Lauf auf dem Pi):**

1. **Korrektur: Tagesart der Vergleichsfenster in der Mitte des Fensters** (Abschnitt 4 sagte „am Ende des Fensters“). Beim Bau
   gefunden: Ein 24-h-Fenster, das Samstag 00:05 endet, enthält den Freitag. Am Ende bestimmt, zählte es als Wochenende und wurde mit
   Fenstern verglichen, die halb Freitage, halb Samstage enthalten -- Einstiege am frühen Samstag bekämen systematisch hohe RV, am frühen
   Sonntag niedrige, am frühen Montag (Inhalt Sonntag, gegen Werktage verglichen) sehr niedrige. Die Swing-, Zyklus- und Familien-
   Strategien steigen kurz nach dem Tagesschluss ein; ein Wochentag-Effekt im Ertrag wäre als Volumen-Effekt durchgegangen (die
   Schichten trennen nur Werktag und Wochenende, und fast jede Verschiebung wechselt den Wochentag). Jetzt: Vergleichsfenster gleicher
   Tagesart in der Mitte des Fensters (t − W/2); die **Schichten bleiben bei der Tagesart am Ende des Fensters** (Zeitpunkt der
   Entscheidung). Bei 60-min-Fenstern ändert sich nur die erste halbe Stunde nach Mitternacht am Samstag und Montag, in Teil B
   (Kalendertage) nichts. Proben V1, V3 (von Hand) und V14 (Montags-Effekt bei 24-h-Fenstern und Einstiegen 00–06 UTC -> nicht belegt);
   Mutationen M18, M19. Auf erfundenen Daten (reiner Montags-Effekt +0,5 Punkte, Einstiege 00–06 UTC, 24-h-Fenster, 79 Verschiebungen):
   mit der Regel „am Ende“ D −0,206, p 0,025 -> „belegt“ (falsch), mit „in der Mitte“ D +0,050, p 0,650 -> nicht belegt. Bleibt als bekannte
   Grenze: Unterschiede zwischen Werktagen (Montag gegen Freitag) bereinigt RV nicht; das Nullmodell löst diese Zuordnung, außer bei den
   Verschiebungen um ganze Wochen.
2. **Spanne Teil A:** „28 Tage Aufzeichnung davor“ genau: erste BTC-Bar + 28 Tage + 24 h (beide Fenster mit vollem Vergleich).
   Minuten werden höchstens 120 Tage vor dem ersten Labor-Trade gelesen (Speicher des Pi). Begann die Aufzeichnung in `hl_liq.db` erst
   Mitte September (so steht es in UEBERGABE zur Akkumulation, 23.70), beginnt die Spanne Mitte Oktober, und Teil A hat bis zum 08.11.
   rund 3½ statt 6 Wochen Trades; die Trades davor fallen heraus (gezählt). Der erste Lauf nennt Beginn und Spanne; ob der Stichtag
   bleibt, entscheidet dann der Nutzer (Abschnitt 11.1).
3. **Drittel:** k = n // 3 Trades je Ende (oberes und unteres Drittel gleich groß), die Mitte nimmt den Rest; Gleichstand nach t0.
4. **Familien:** Die Kontrollen (`zufall`, `halten_long`, alle Namen mit „zufall“) gehören nicht zur Familie je Strategie, sie sind der
   Vergleich (6.3; im Bericht als „Kontrolle“ beschreibend). Grid und Akkumulation sind nicht in Teil A (6.8, 6.9). Die Gruppen in 6.1 ohne
   Kontrollen und „…_gegen“ (wie der Pool).
5. **Teil B vollständig** heißt: je Coin Tagesumsatz (Markt „um“, `<COIN>USDT`) bis 23.10. mit höchstens 1 % fehlenden Tagen seit dem
   ersten Tag und 30-min-Kerzen in `swing.db` bis 23.10. 23:30 UTC. Kerzen nach dem 23.10. werden nicht gelesen.
6. **Bootstrap:** Teil A zieht die Kalendertage mit gültigen Trades mit Zurücklegen; Teil B zirkuläre Blöcke von 60 Kalendertagen über
   die Spanne der gültigen Tage. Die Drittel werden je Ziehung über die Vielfachheiten neu gebildet -- gleich der Rechnung mit
   wiederholten Trades (Probe V20), nur ohne neues Sortieren.
7. **Beschreibend:** 6.4 und 6.6 mit dem Pool von A1, 6.5 mit dem Pool von A2, 6.10 und 6.12 (je Jahr) mit festem Pool; 6.4–6.12 nur
   mit Band (400 Ziehungen, Teilmengen 200), ohne Nullmodell; 6.1 und 6.3 mit z aus denselben Läufen wie die Hauptprüfungen. 6.6 auf dem
   absoluten 5-min-Raster (das Fenster endet an der letzten 5-min-Grenze vor t0). 6.8: Tagesergebnis in % des Coin-Kontos
   (`hl_labor.grid_tage_tabelle`) gegen den RV der 24 h vor dem Tag. 6.9: Schluss der Minute 7 Tage nach dem Kauf ÷ Kaufpreis − 1 gegen
   RV (24 h) bis zur Minute des Kaufs. Schichten in 6.8/6.9: Kennung × Tagesart.
8. **„Band eng um 0“** (Lesart bei „nicht belegt“, Abschnitt 8): das ganze 90-%-Band innerhalb ±0,25 Punkte (Teil A) bzw. ±0,25 R
   (Teil B); sonst „Band breit“.
9. **Stand heute:** Die Fenster enden 2 min vor dem Lauf (noch nicht geschriebene Minuten).
10. **Berichtsplan:** einzelne Termine 24.10. 21:15 (Teil B mit Urteil, Teil A vorläufig), 25.10. und 01.11. 09:15 (vorläufig),
    08.11. 09:15 (Urteil Teil A) statt „sonntags“, damit nach dem Urteil kein Lauf mehr folgt.
11. **Laufzeit:** Auf dem Pi nicht gemessen (kein Zugang). Hier bei Höchstgröße (6 Coins × 162 Tage Minuten, bars10 mit 6 Stücken je
    Minute, 20.000 Trades, Teil B ab 2020) 48 s und 320 MB Spitzenspeicher (`bars10` je Minute in numpy summiert, ohne temporären
    Baum in SQLite); auf dem Pi geschätzt 2–4 min. Das Ziel „unter 2 min“ ist
    damit nicht sicher; die Grenze der geplanten Berichte (15 min) hält. Der Bericht nennt die echte Laufzeit.
12. **6.4 Binance-RV aus `swing.db`** (`sw_klines`, die 30-min-Kerzen der USDT-Perps, im Swing-Takt alle 5 min ergänzt, nur
    abgeschlossene Kerzen) statt aus `klines30`: `klines30` füllt nur der Handaufruf von `hl_timestats.py` -- die jüngere Zeit fehlt dort
    vermutlich, und die letzte Kerze eines Abrufs bleibt unvollständig gespeichert (der Lader setzt nach ihr fort; am Code gesehen).

**Nach einer zweiten unabhängigen Durchsicht** (Code gegen dieses Konzept, ohne meine Schlussfolgerungen; gestartet nach 04:30, Laufzeit
19,6 min): sieben Punkte, sechs umgesetzt (12.13–12.18); der siebte („Mutationen fehlen im Code“) ist Absicht -- sie laufen außerhalb des
Moduls (Liste in UEBERGABE 3ππππ).

13. **Holm über beide Hauptprüfungen**, auch wenn eine nicht prüfbar ist: Sie zählt mit p = 1. Vorher hätte A1 allein gegen α = 0,05
    gestanden, wenn A2 nicht prüfbar ist (TS ist strenger gültig) -- gegen Abschnitt 5 („über die beiden Hauptprüfungen“).
14. **Verschiebungen bei kurzer Spanne:** Ist die Spanne kürzer als 28 Tage, landen τ und τ − Spanne zirkulär an derselben Stelle (bei
    25 Tagen 73 von 626). Doppelte Lagen fallen weg (die erste bleibt), ebenso jede, die zirkulär näher als 24 h an 0 läge; der Bericht nennt
    die Zahl.
15. **Limit-Einstiege, deren Order gelöscht ist:** Das Labor löscht erledigte Orders 30 Tage nach der Füllung (`hl_labor`, Aufräumen im
    Takt). t0 kommt dann aus dem Ereignis „limit“ beim Legen der Order (90 Tage aufgehoben, dieselbe Zeit): gleiche Strategie (auch alte
    Kennung), Coin, Seite und Preis (= Einstiegspreis der Füllung), das jüngste vor der Füllung. Ohne beides: „Limit ohne Order“ (gezählt).
    Sonst fielen bei einem späteren Stichtag gerade die ältesten Limit-Trades heraus.
16. **6.1 Gruppen:** Null und Bootstrap je Verschiebung und Ziehung mit deren eigenen Gewichten verdichtet (wie D_pool), nicht mit denen
    bei τ = 0.
17. **6.9 Akkumulation** im Urteilslauf nur mit Käufen, deren 7 Tage vor dem Stichtag enden.
18. **Teil B: Prüfsumme der Eingangsdaten** (Trades und Tagesreihen bis 23.10.) im Bericht. Die Studie schreibt nichts; das Urteil von Teil B
    ist das des ersten Berichts mit vollständiger Historie, und eine andere Prüfsumme in einem späteren Bericht zeigt, dass sich Daten
    geändert haben (z. B. Tageskerzen durch die Monatsdatei ersetzt).

## 13. Unabhängige Durchsicht vor der Freigabe (24.10.2026, vor jeder echten Zahl)

Ein zweiter Durchgang, der den Entwurf und den Code ohne meine Schlussfolgerungen las, fand Folgendes. Alles ist in die Abschnitte oben
eingearbeitet:
1. **Kein Urteil je Strategie möglich:** Mit 626 Verschiebungen ist p ≥ 1/627; nach Holm über rund 80 Tests wäre „belegt“ unerreichbar
   gewesen, und meine Angabe „D um 0,6 Punkte erkennbar“ war falsch. → p je Strategie aus der Normalnäherung (Abschnitt 5), Trennschärfe
   neu (Abschnitt 2).
2. **Wochentag als Scheinwirkung:** Der Normalwert aus 14 gemischten Tagen machte Wochenend-RV klein; Wochenend-Trades hätten das
   untere Drittel gefüllt, und fast alle Verschiebungen wechseln den Wochentag. → Vergleich nur mit Tagen gleicher Art, Drittel je
   Tagesart, TS ebenfalls gegen die Uhrzeit bereinigt.
3. **TS sortierte Long gegen Short:** Bei einem Versatz des Saldos landen Shorts und Longs in verschiedenen Dritteln. → Drittel je
   Seite, p mit Abstand vom Median der Null.
4. **Normalwert über die Naht:** Rohvolumen zirkulär zu verschieben hätte Normalwerte über das Ende der Spanne hinweg gebildet. → Die
   fertigen Reihen werden verschoben.
5. **Pool:** volumengekoppelte Auslöser, die Spiegelpaare und die Zufalls-Swing-Strategien hätten das gepoolte D verzerrt. → feste Liste
   in Abschnitt 4.
6. **Minuten-Bars können überschrieben werden (Befund im Recorder, nicht in der Studie):** `flush_bars` und `flush_bars10` schreiben
   Minuten bzw. 10-s-Stücke, sobald ihre Zeit vorbei ist, nehmen sie aus dem Speicher und schreiben mit `INSERT OR REPLACE`. Kommt danach
   noch ein Trade dieser Minute an (Verzögerung, Neuverbindung; laut Hyperliquid-Doku liefert das Abo bei Zeitreihen, Beispiel eigene
   Fills, einen Schnappschuss früherer Daten — ob auch beim Kanal „trades“, sagt sie nicht; der Recorder entdoppelt Trades nicht nach
   `tid`), beginnt ein neues Stück und ersetzt beim nächsten Schreiben die vollständige Zeile. Folge: zu wenig Volumen, falsche Hochs und Tiefs in einzelnen Minuten. → In der Studie als
   „fragliche Minute“ erkannt und gezählt (3c); die Behebung im Recorder ist ein eigener Plan-Punkt (U222, nach dem 25.10.).
7. Fehlende Festlegungen ergänzt: t0 auf die Minute, Median 0, Mindestzahl Trades für TS, Pool fest bei τ = 0, Drittel je Hälfte und
   Ziehung neu, alte Kennungen, „Regelversion abgelöst“, neu gelegte Limit-Orders, Teil B mit gemeinsamem τ, festem Datenschluss und ohne
   „offen am Ende“; R in Teil A gestrichen (der Stop in `labor_position.sl` wird nachgezogen und überschrieben).
