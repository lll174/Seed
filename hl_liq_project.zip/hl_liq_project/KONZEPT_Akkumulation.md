# KONZEPT Akkumulation (U180) — nur kaufen, bei Rücksetzern nachkaufen, nie verkaufen

Stand 20.10.2026 03:54 (Opus 5.5): **gebaut mit 23.69, vor dem ersten Lauf geändert mit 23.70** (U184, Wunsch des Nutzers 19.10.
23:20 und 23:40: 5.000 USD je Kauf, Startkauf, Käufe rückwirkend ab dem Start des Coins im Labor; Abschnitt 7a). 23.69 wurde nicht
eingespielt; auf dem Pi läuft die Akkumulation seit 23.70. **Anzeige berichtigt mit 23.71** (U185, Hinweis des Nutzers 20.10. 01:40;
Abschnitt 7b): Liste aller Käufe, Tagestabelle als „Stand je Tag“, Grund des Startkaufs; Rechnung, Regeln und gespeicherte Käufe
unverändert. **Korrekturkauf A4 mit 23.72** (U186, Wunsch des Nutzers 20.10. 02:43, Abschnitt 7c): ab 7 % unter dem Hoch der letzten
48 Stunden, Nachkauf je weitere 7 % binnen 14 Tagen, eigene Spur ohne Sperre, rückwirkend ab dem Start; neue Kennungen. Die Regeln (Abschnitt 2) und die Prüfung (Abschnitte 4, 5, 7) waren **vorab
festgelegt**, bevor die Regel auf einem einzigen echten Kurs gerechnet wurde (Entscheidung des Nutzers 19.10.: „heute“, zusammen mit
U177–U179); die Änderungen aus 7a kamen ebenfalls vor jedem echten Kurs. **Berichtigt 19.10. 22:55:** Die Uhrzeiten in diesem Dokument waren
geschätzt statt gemessen und lagen bis zu zwei Stunden zu spät (z. B. „Stand 20.10. 00:30“); jetzt nach den Dateizeiten der Protokolle.
Dazu in Abschnitt 7 die Zahlen ohne Protokoll ersetzt und der Vorlauf der Kalibrierung ergänzt.

**Anlass** — Wunsch des Nutzers vom 19.10. 20:22 (zusammengefasst, Kernsätze wörtlich): eine Strategie, die „sich ganz unterscheiden
[soll] von allen anderen. Denn sie dient ausschließlich der Akkumulation. Es gibt keinen Verkauf.“ Sie kauft Dips, „wartet auf
Gelegenheiten, um günstig einzukaufen“, nutzt Indikatoren für gefallene Kurse und die Heatmap: Kommt der Kurs an „eines richtig
heißen Clusters, das nach unten ausgerichtet ist“, kauft sie. Jeder Kauf 1.000 USD, „damit sie genug Möglichkeiten hat,
nachzukaufen“. Der Rücksetzer muss signifikant sein, „deutlich über dem durchschnittlichen Sigma“; was adäquat ist, entscheide ich.
„Wenn der Kurs also spätestens 20 % über den 200 MA liegt, dann hört sie auf zu kaufen.“ „Wenn sehr, sehr viel Trader im Profit
sind, besteht das Risiko auf einen Rücksetzer. Also wartet sie auf einen Rücksetzer.“ Im Labor: Bilanz statt Einzeltrades,
Positionsgröße und Wachstum, jede Position einzeln als ausklappbare Tabelle mit ihrem Gewinn, dazu eine Gesamtübersicht.

**Entscheidungen des Nutzers (19.10., Auswahl):** alle fünf Labor-Coins, je Coin eine eigene Bilanz; ohne Obergrenze für das Kapital;
200-Tage-Linie; Paket heute mit U177–U179.

**Änderungen des Nutzers vor dem ersten Lauf (19.10. 23:20, Kern wörtlich):** „Bitte korrigiere diese Summe auf 5000 Dollar.“ Die
Position soll „spot sein … die kann endlos gehalten werden und verursacht keine Gebühren“ (sie war schon als Spot-Kauf gerechnet, Abschnitt
2). „Beim ersten Start kauft er für 5000“, danach gelten die besprochenen Regeln; den Satz „bei Kursrückgängen über 3 % fast immer kaufen“
hat der Nutzer selbst gestrichen („Wir lassen die Regeln so wie besprochen“). **Antwort auf meine Rückfrage zum Startkauf (23:40):** „Die
Käufe sollen beim Start nachberechnet werden auf Grundlage des Datenbank starts, also rückwirkend. Dadurch soll diese Strategie direkt
vergleichbar sein mit den anderen laufenden strategien.“ Umsetzung in Abschnitt 2 und 7a.

**Zusatzregel des Nutzers (20.10. 02:43, Kern wörtlich):** Bei „scharfen Korrekturen … ab 7 % Korrektur innerhalb von 48 Stunden“
soll sie kaufen; „Sollte eine weitere Korrektur nach dem Kauf eintreten, erneut … in Höhe von mindestens 7 %, sollte auch entsprechend
weiter nachgekauft werden“, „zum Beispiel innerhalb von 2 Wochen“; „für alle Coins“, „für die Spotkäufe“; „Verpacke es so, dass die
Strategie nicht leer ausgeht, sondern sinnvoll einkauft“; „als einmalige Regel zunächst rückwirkend … und dann ab sofort für alle
weiteren Korrekturen“. **Entscheidung auf meine Rückfrage (20.10.):** ohne Sperre („Ohne Sperre (Vorschlag)“) -- auch über 1,2 × der
200-Tage-Linie. Umsetzung in Abschnitt 2 und 7c.

## 1. Vorwissen (warum diese Regeln)

- **U141 (Zyklus-Studie):** „Nach dem bestätigten Dump kaufen und mit Stop halten“ war bei BTC und ETH schlechter als zufällige
  Einstiege mit denselben Ausstiegen; nach einem Dump ging es oft weiter abwärts. Rallyes und Rücksetzer verhielten sich wie ein
  Zufallsweg. Gier ≥ 80 und Funding-Druck kündigten keine Rücksetzer an (eher das Gegenteil), OI-Überhitzung nur als Hinweis.
- **U142 H1 (Hebel-Studie), belegt:** Steht die Binance-Konten-Quote (Long ÷ Short aller Konten) bei 3 oder höher, folgte ein
  Rücksetzer von mindestens 1,5 σ√7 binnen 7 Tagen in 20,3 % der Fälle gegen 7,3 % sonst (RR 2,77; auch nach der Vorwoche
  geschichtet). Das ist die einzige geprüfte Größe für „viele sind long und im Gewinn, ein Rücksetzer droht“.
- **U110 (Magnet-Test):** ob der Kurs Liquidationscluster öfter berührt als ein Zufallsweg, ist offen (Urteil 25.10.). Die
  Heatmap-Regel unten ist deshalb die Idee des Nutzers, nicht ein Beleg; ihre Wirkung misst die Kontrolle ohne Heatmap.
- **Folge:** Diese Strategie verkauft nie. Es zählt nicht, ob nach dem Kauf eine Rallye kommt, sondern ob der **Ø Einstand** besser
  ist als bei derselben Zahl Käufe zu anderen Zeiten. Unter einem reinen Zufallsweg ist kein Vorteil zu erwarten (Abschnitt 5).

## 2. Regeln (fest; jede Änderung ergibt eine neue Kennung)

Zwei Strategien im Labor, Gruppe „Akkumulation“, je Coin (BTC, ETH, ZEC, HYPE, XMR) eine eigene Bilanz:

| Kennung | Name | Auslöser |
|---|---|---|
| `akku` | Akkumulation | A0, A1, A2, A3; seit 23.72 A4 |
| `akku_ohne_cluster` | Akkumulation ohne Heatmap (Kontrolle) | A0, A1, A3; seit 23.72 A4 — misst, was die Heatmap-Regel bringt |

**Größen je Coin, zu jedem Takt (15 s):**
- d = letzter abgeschlossener UTC-Tag in `swing.db` (Binance-Perp, 30-min-Kerzen), wie bei den Swing-Strategien.
- σ = σ_Tag(d): Wurzel aus dem EWMA der Tages-RV (Halbwertszeit 20 Tage, `hl_swing.sigma_tag`); σ₇ = σ · √7.
- MA200 = Mittel der 200 Tagesschlüsse bis d (`hl_swing.Kennzahlen.sma(200)`).
- H7 = höchstes Hoch der Hyperliquid-1-min-Kerzen der letzten 7 Tage, mindestens der Kurs jetzt.
- P = Mitte des Hyperliquid-Buchs (höchstens `KURS_FRISCH_S` alt, sonst kein Kauf).
- Letzter Kauf (Zeit t_L, Preis P_L) dieser Strategie in diesem Coin.

**Sperre (immer, auch für den Startkauf):** kein Kauf, wenn P ≥ 1,20 · MA200. Ohne MA200 oder σ kein Kauf (Grund steht im Status).

**Auslöser:**
- **A0 Startkauf (seit 23.70):** Solange die Strategie im Coin noch keinen Kauf hat, kauft sie sofort (frischer Kurs, σ₇ und MA200
  bekannt, P unter der Sperre; das 7-Tage-Hoch braucht er nicht). Erst danach gelten A1–A3; in den 7 Tagen nach dem Startkauf also nur
  der Nachkauf A3 ein σ₇ unter ihm.
- **A1 Rücksetzer:** kein Kauf in den 7 Tagen davor und P ≤ H7 · e^(−2σ₇).
- **A3 Nachkauf:** letzter Kauf vor weniger als 7 Tagen und P ≤ P_L · e^(−σ₇). Jeder weitere Nachkauf wieder ein σ₇ tiefer.
- **A2 Heatmap (nur `akku`):** kein Kauf in den 7 Tagen davor; P ≤ H7 · e^(−σ₇); ein **heißes Long-Cluster** C liegt unter dem Kurs
  (Long-Liquidationen im jüngsten Heatmap-Stand, höchstens 30 min alt, 0,5–3 σ(4 h) entfernt, mindestens **25 %** des
  Stundenvolumens; von mehreren das höchste) oder wurde in den 6 h davor so gesehen; und P ≤ C · e^(0,25 σ(1 h)) („angekommen oder
  in der Nähe“). Der Kurs muss also schon ein σ₇ gefallen sein; das Cluster bestimmt den Ort.
- **Warten bei vielen Long-Konten (U142 H1):** Ist die Binance-Konten-Quote des Coins (`bnc_metrics`, `global_ls_account`, höchstens
  2 h alt) ≥ 3, ist A2 ausgesetzt; gekauft wird nur beim vollen Rücksetzer (A1) oder als Nachkauf (A3).
- **A4 Korrektur (seit 23.72, beide Strategien, eigene Spur):** H48 = höchstes Hoch der Hyperliquid-1-min-Kerzen der letzten 48 h bis
  jetzt; nach einem Korrekturkauf zählt das Hoch erst ab der Minute danach (derselbe Einbruch kauft nur einmal). Bezug = das höhere von
  H48 und dem letzten Korrekturkauf, solange dieser jünger als 14 Tage ist. Kauf bei P ≤ (1 − 7 %) · Bezug. Also: 7 % unter dem Hoch
  der letzten 48 h ein Korrekturkauf; danach binnen 14 Tagen je weitere 7 % unter dem letzten Korrekturkauf ein Nachkauf, egal wie
  schnell; erholt sich der Kurs und fällt wieder 7 % binnen 48 h, ist das eine neue Korrektur. **Ohne Sperre** (Entscheidung des
  Nutzers), ohne σ, 200-Tage-Linie, Heatmap und Konten-Quote. **Eigene Spur:** A4 zählt nicht als „letzter Kauf“ für A0–A3 (Startkauf,
  7-Tage-Fenster, Nachkauf je σ₇) und umgekehrt -- die bisherigen Regeln kaufen genau wie ohne A4 (Probe: ohne die Regel dieselben Käufe
  A0–A3 auf die Minute). In einem scharfen Einbruch können deshalb A1 und A4 beide kaufen.

**Ausführung:** höchstens ein Kauf je Takt, Coin und Spur (A0–A3 und A4); **5.000 USD** (seit 23.70, vorher 1.000) als **Spot-Kauf** zum Marktpreis (Ask mit
Abstand zur Buchmitte wie `taker_preis`), Gebühr **0,070 %** einmal beim Kauf (Hyperliquid Spot, Stufe 0, laut Doku am 19.10. gelesen;
3,50 USD je Kauf); kein Hebel, kein Funding, keine Kosten beim Halten, **kein Verkauf**. Kapital ohne Obergrenze. Der Kurs kommt aus dem
Perp-Buch von Hyperliquid (Spot-Bücher zeichnet das System nicht auf); simuliert wird ein Spot-Kauf zu diesem Kurs mit Spot-Gebühr.

**Rückrechnung (seit 23.70, einmal je Strategie und Coin beim ersten Takt, solange sie dort noch keinen Kauf hat):**
- **Beginn:** der Start des Coins im TradeLabor (`labor_zustand` „coins“ -- dieselben Kontotage wie die übrigen Strategien: BTC, ETH,
  ZEC und HYPE mit dem Laborstart, XMR seit seiner Aufnahme). Ohne früheren Start (neuer Speicher) gibt es nichts nachzurechnen; dann
  folgt der Startkauf live beim ersten Takt.
- **Regel:** dieselbe wie oben ohne Heatmap (A0, A1, A3, Sperre) auf den 1-min-Kerzen der Hauptdatenbank bis zur letzten
  abgeschlossenen Minute; die 7 Tage vor dem Beginn zählen nur zum 7-Tage-Hoch. σ₇ und MA200 je Minute vom letzten vollen Tag davor
  (`swing.db`, wie live). Auslösung am Tief der Minute; Kauf zur Schwelle, bei einer Eröffnung darunter zum Eröffnungskurs; der Startkauf
  zur Eröffnung der ersten Minute ab dem Beginn mit σ₇, MA200 und Kurs unter der Sperre. Sein Grund sagt das so: „Startkauf in der
  ersten Minute seit dem Start des Coins im Labor (…), in der ein Kauf erlaubt war“; kam er nicht in der ersten Minute, steht dabei,
  wann und warum („erst am …, bis dahin lag der Kurs bei oder über 1,2 × 200-Tage-Linie“, „… fehlten Tageskerzen“ oder beides; seit
  23.71, Abschnitt 7b).
- **Korrekturkauf A4 (seit 23.72):** dieselbe Regel wie live auf denselben 1-min-Kerzen (`akku_korrektur_kerzen`): je Minute das Hoch der
  Kerzen in [t − 48 h, t) ohne die Minute selbst (nach einem Kauf erst ab der Minute danach), Auslösung am Tief, Kauf zur Schwelle, bei
  einer Eröffnung darunter zur Eröffnung, mehrere Stufen in einer Minute möglich; die 7 Tage vor dem Beginn zählen nur zum Hoch. Beide
  Spuren getrennt gerechnet, gespeichert nach der Zeit (bei gleicher Minute A0–A3 zuerst). Live kauft A4 erst nach der Rückrechnung (fehlen
  beim ersten Takt die Tageskerzen, wartet auch A4, sonst fiele die Rückrechnung aus).
- **Was fehlt:** Heatmap-Stände von damals rechnet das Labor nicht nach -- A2 und die Warteregel wirken erst live; bis zum ersten Takt
  sind `akku` und die Kontrolle gleich. Ohne Bücher von damals kein Abstand zur Buchmitte (der Kauf zur Schwelle ist etwas günstiger
  als live zum Ask). Die Gebühr ist dieselbe.
- **Gespeichert:** jeder Kauf mit dem Vermerk „nachgerechnet“ (Werte: Beginn und Zeitpunkt der Rückrechnung), je UTC-Tag die
  Tageszeile (Stand am Ende des Tages), je Kauf ein Ereignis zu seiner Zeit, im Zustand der Strategie „nach“ (Beginn, Zeitpunkt, Zahl).
  Ein Neustart rechnet nicht noch einmal (es gibt dann Käufe; der Vermerk im Zustand verhindert auch eine leere Wiederholung).

**Was die Zahlen heute bedeuten (Beispiel, nicht festgelegt):** Bei BTC mit σ_Tag um 1,7 % ist σ₇ ≈ 4,5 %; A1 kauft rund 8,6 % unter
dem 7-Tage-Hoch, danach alle weiteren rund 4,4 %.

## 3. Bilanz und Anzeige

- **Je Kauf eine Zeile** (`labor_akku_kauf`): Zeit, Strategie, Coin, Auslöser (A0/A1/A2/A3, seit 23.72 A4), Kurs, Menge, Einsatz,
  Gebühr, Abstand zur Mitte, Grund und Werte (H7, σ₇, MA200, Konten, Cluster; bei A4 Bezug, Art des Bezugs, Schwelle, 48-h-Hoch; bei
  nachgerechneten Käufen „nachgerechnet“, Beginn und Zeitpunkt).
- **Je UTC-Tag eine Zeile** (`labor_akku_tag`): eingesetzt, Bestand, Wert zur Mitte, Kurs; erneuert alle 5 min und nach jedem Kauf.
- **Kennzahlen je Coin und gesamt:** Käufe, eingesetzt, Bestand, Ø Einstand (eingesetzt ÷ Bestand, Gebühr eingeschlossen), Wert,
  Gewinn in USD und % (vor einer Verkaufsgebühr; die Strategie verkauft nie), je Los Wert und Gewinn.
- **Reiter „Akkumulation“** im TradeLabor (gebaut, `/labor/akku`, neu geladen jede Minute, solange der Reiter offen ist):
  - Wahl der Strategie (`akku` oder Kontrolle), die Regeln aufklappbar (seit 23.72 mit „Korrektur ab 7 % unter dem 48-h-Hoch, je 7 %
    tiefer nach (14 Tage, ohne Sperre)“). Frühere Regelstände (andere Kennung, mit ihren Käufen) nur über den Knopf „frühere Regeln (n)“;
    war im Browser ein früherer Stand gewählt, zeigt der Reiter die laufende Strategie.
  - **Gesamtübersicht:** Käufe seit dem Beginn des Zeitraums (seit 23.70 der Beginn der Rückrechnung) und „davon n nachgerechnet bis
    …“ (seit 23.72 dazu „k Korrektur“), eingesetzt, Wert (Bestand × Mitte jetzt), Gewinn in USD und % (ohne Verkaufsgebühr).
  - **Alle Käufe** (seit 23.71) direkt darunter, offen: jeder Kauf der Strategie einzeln über alle Coins, neueste zuerst; gezeigt die
    neuesten 10, ein Knopf zeigt alle (bis 300). Je Kauf Nummer, Zeit, Coin, Auslöser mit Namen und „nachgerechnet“, Preis, Wert jetzt,
    Gewinn in USD und %, Grund. Zu und „alle“ bleiben beim Neuzeichnen.
  - **Wachstum:** eingesetzt als Stufe (#3987e5) und Wert als Linie (#d95926) auf einer USD-Achse je UTC-Tag (heute: letzter Takt),
    alle Coins zusammen (vorgetragen: ein Coin ohne Zeile an einem Tag zählt mit seinem letzten Stand) oder je Coin; Legende,
    Beschriftung am Linienende, Fadenkreuz mit eingesetzt, Wert, Gewinn (je Coin auch Kurs und Käufe bis dahin). Darunter aufklappbar
    **„Stand je Tag — keine Kaufliste“** (seit 23.71 so benannt): je UTC-Tag eine Zeile mit „Käufe“ bis zu diesem Tag, „neu“ = die Käufe
    dieses Tages (Zeile grün markiert), eingesetzt (= Käufe × 5.000 USD), Wert zum Tagesende, Gewinn; je Coin dazu der Kurs.
    Farben mit dem Palettenprüfer gegen den Hintergrund #01030a geprüft (alle Prüfungen bestanden, CVD ΔE 26,8).
  - **Je Coin** eine Zahlenzeile (Käufe, eingesetzt, Bestand, Ø Einstand, Kurs, Wert, Gewinn USD und %), darunter über die ganze
    Breite die **Lage**: „Kauf ab X (−y %, Auslöser)“ = der nächste Kaufpreis (binnen 7 Tagen nach einem Kauf A3, sonst der höhere von
    A1 und A2 wirksam, A2 nur ohne Warteregel; nur Anzeige, `naechster` aus `akku_lage`), „gesperrt“ über 1,2 × 200-Tage-Linie,
    „⊕ Kauf … im letzten Takt“, „Startkauf ausstehend“ (noch kein Kauf, Grund dabei); dazu 7-Tage-Hoch, σ₇, 200-Tage-Linie, Konten,
    Cluster und der Grund im Wortlaut der Regel; seit 23.72 eine Zeile „Korrektur (ohne Sperre): Kauf ab X (−y %), 7 % unter dem Hoch
    der letzten 48 h (Z)“ bzw. „… unter dem letzten Korrekturkauf Z, längstens bis …“; daneben
    „Zeitpunkt gegen Zufall“ (Abschnitt 4, ohne Ampelfarbe, weil auch ohne Vorhersagekraft meist positiv).
  - **Lose:** Antippen einer Coin-Zeile klappt alle Käufe auf (neueste zuerst, Nummer, Zeit, Auslöser mit Namen -- Startkauf,
    Rücksetzer, Heatmap-Cluster, Nachkauf, seit 23.72 Korrektur -- und „nachgerechnet“, Preis, Abstand zur Mitte,
    Menge, Wert jetzt, Gewinn USD und %, Grund) mit „x von n im Gewinn, bestes, schwächstes“; aufgeklappt bleibt aufgeklappt.
  - **Handy:** nur Käufe, Wert und Gewinn als Spalten, eingesetzt, Ø Einstand und Kurs in der Zeile darunter; die Lose-Tabelle ohne
    Abstand, Menge, Wert und Grund; keine Seite scrollt seitwärts. Seit 23.71 „Alle Käufe“ ohne Nummer, Preis-Spalte, Wert und Grund
    (der Preis steht unter dem Coin) und „Stand je Tag“ ohne „neu“ und Gewinn USD (die neuen Käufe stehen unter dem Tag); beide passen
    ohne Seitwärtsscrollen auf 390 Pixel Breite.
  - **Kopfzeile des Labors:** Kachel „Akkumulation“ (Käufe und Gewinn der Hauptstrategie, darunter die Kontrolle). **Ereignisse:**
    jeder Kauf mit ⊕ und dem Titel der Strategie (Seite „spot“, grün; bis 23.69 intern „long“; Käufe früherer Regelstände mit
    „(alte Regeln)“ seit 23.72). **Datenfluss:** Gruppe „Akkumulation“ (7-Tage-Hoch, Binance-Konten, seit 23.72 Hoch 48 h).
- Die Strategien zählen nicht in die Trade-Statistik der übrigen (keine geschlossenen Trades) und nicht in „Offen“.

## 4. Vergleich (beschreibend, vorwärts)

Je Strategie und Coin, sobald 5 Käufe **nach den Regeln** da sind (seit 23.70 ohne den Startkauf: sein Zeitpunkt steht fest; seit 23.72
auch ohne die Korrekturkäufe A4: eigene Spur ohne Sperre, der Vergleich zieht nur aus Minuten ohne Sperre; sonst „ab 5 Käufen nach den
Regeln“). Für A4 gibt es noch keinen eigenen Vergleich (er wäre vorab festzulegen, mit Null- und Positivkontrolle):
- **Zufall:** dieselbe Zahl Käufe zu gleichverteilten Minuten des Laufzeitraums (seit 23.70 ab dem Beginn der Rückrechnung, sonst Start der
  Strategie, bis jetzt), nur Minuten ohne
  Sperre (Schluss < 1,2 · MA200 des Vortags), 2.000 Ziehungen mit fester Saat, Kurs = Schluss der 1-min-Kerze, gleiche Gebühr.
  Ausgewiesen: Median und 90-%-Band des Ø Einstands, p = Anteil der Ziehungen mit niedrigerem Ø Einstand.
- **Gleichmäßig:** dieselbe Zahl Käufe in gleichen Abständen über dieselben Minuten.
- **Vorteil** = Ø Einstand (Zufall, Median) ÷ Ø Einstand (Strategie) − 1; positiv heißt günstiger gekauft.
- **Wichtig (Simulation 19.10. 21:35, vor jedem echten Kurs, Abschnitt 7):** Dieser Vorteil ist auch ohne jede Vorhersagekraft meist
  positiv, weil die Regel nie nach einem Anstieg kauft (auf Zufallswegen im Median rund +2 %, p < 0,05 in 10 % statt 5 % der Märkte),
  und er schwankt stark mit dem Trend des Zeitraums. Er bleibt deshalb **beschreibend**; daneben steht dieser Hinweis. Für die Frage,
  ob die Heatmap etwas bringt, zählt der Abstand von `akku` zur Kontrolle `akku_ohne_cluster` im selben Zeitraum.

## 5. Rückblick auf der Historie (Debug-Bericht, beschreibend, vorab festgelegt)

- **Regel:** `akku_ohne_cluster` (A1, A3, Sperre; die Heatmap hat keine Historie vor September 2026; **ohne Startkauf** -- er ist kein
  Zeitpunkt der Regel und änderte nur einen Kauf; **ohne Korrekturkauf A4** -- er war nicht Teil dieser vorab festgelegten Prüfung) auf
  den 30-min-Kerzen aus `swing.db`, ab dem ersten Tag mit MA200 bis zum letzten vollen Tag. Der Betrag (seit 23.70 5.000 USD) skaliert nur eingesetzt, Wert und Gewinn in USD.
- **Auslösung je Kerze:** Schwelle aus H7 (Hochs der 336 Kerzen davor), σ₇ und MA200 des Vortags. Tief ≤ Schwelle → Kauf zur Schwelle,
  bei einer Eröffnung darunter zum Eröffnungskurs; mehrere Nachkauf-Stufen in einer Kerze sind möglich (wie mehrere Takte live).
  Sperre am Kaufpreis.
- **Vergleich** wie Abschnitt 4 auf den erlaubten Kerzen (Schluss), 2.000 Ziehungen; dazu gleichmäßig — **beschreibend**.
- **Zeitpunkt Q (maßgeblich, geändert 19.10. vor jedem echten Kurs, Abschnitt 7):** je Kauf ln(Mittel der 30-min-Schlüsse der 7 Tage
  nach der Kaufkerze ÷ Kaufpreis), gemittelt über die Käufe mit vollen 7 Tagen danach (mindestens 5), in %. Ohne Vorhersagekraft liegt Q
  nahe null; kauft die Regel Rücksetzer, die zurücklaufen, ist Q positiv; laufen sie weiter (U141), negativ.
- **Null:** dieselbe Regel auf 200 Vorzeichen-Surrogaten der 30-min-Renditen (Drift und Schwankung bleiben, Dochte je Kerze bleiben, σ,
  200-Tage-Linie und Sperre neu gerechnet); p = Anteil der Surrogate mit Q mindestens so groß. Dazu beschreibend der Vorteil gegen
  Zufallszeiten auf denselben Surrogaten (zeigt, wie viel Vorteil die Regel ohne Vorhersagekraft hätte).
- **Ausgewiesen je Coin:** Käufe (gesamt und je Jahr), eingesetzt, Ø Einstand, Wert und Gewinn am Ende, Vorteil gegen Zufall mit
  90-%-Band und p, Vorteil gegen gleichmäßig, Vorteil auf den Surrogaten, Q mit Hälften, Q der Surrogate mit Band und p.
- **Lesart vorab:** „Zeitpunkt belegt“ nur bei p < 0,05 **und** Q in beiden Hälften (Teilung am mittleren Datum) über dem Median der
  Surrogate — beschreibend, kein Urteil über den Live-Betrieb, weil Parameter und Zeitraum bekannt sind.
- **Erwartung vorab:** Q nahe null oder leicht negativ (U141: nach Dumps ging es oft weiter abwärts), Zeitpunkt nicht belegt. Der
  Vorteil gegen Zufallszeiten dürfte trotzdem positiv sein, etwa in der Höhe der Surrogate.

## 6. Proben (Selbsttest ohne Netz, je mit Mutation)

- **Regel von Hand:** A1 an der Schwelle (knapp darüber kein Kauf, darunter Kauf), A3 je Stufe genau einmal, nach 7 Tagen wieder A1,
  A2 nur mit heißem Cluster und mindestens σ₇ Abstand zum Hoch, A2 ausgesetzt bei Konten ≥ 3, Sperre bei 1,2 · MA200, kein Kauf bei
  altem Kurs, Kontrolle ohne A2.
- **Bilanz von Hand:** Menge, Gebühr, Ø Einstand, Wert, Gewinn je Los und gesamt, Tageszeilen.
- **Vergleich:** von Hand mit fester Saat.
- **Zufallswege:** Nullkontrolle (6 Zufallswege, 1,5 Jahre: höchstens einer mit p < 0,05) und Positivkontrolle (3 Märkte mit Einbrüchen um
  15 % binnen 4 h, die binnen eines Tages zurücklaufen: alle mit p < 0,05 und „belegt“), je 60 Surrogate.
- **Kausalität:** Kerzen nach t ändern keinen Kauf bis t.
- **Rückblick = Live:** dieselbe Regelfunktion auf denselben Kerzen gibt dieselben Käufe.
- **Ende zu Ende** über das Labor (Takt, Tabellen, Nutzlast) und die Route; Browserprobe des Reiters (Zahlen gegen die Datenbank,
  Ausklappen, Handybreite).
- **Mutationen:** Sperre aus; 1,2 → 1,0; σ statt σ₇; Nachkauf ohne Stufe; H7 mit Zukunft; Warteregel ohne Wirkung; Perp-Gebühr statt
  Spot; Funding gerechnet; Zufall ohne Sperrfilter; Kontrolle mit A2.
- **Stand nach dem Bau (19.10. 22:45):** Teil „Akkumulation“ des Labor-Selbsttests 10 von 10 grün (Regel von Hand 19 Fälle samt
  „nächster Kauf“ und 1,1 × MA200; 7-Tage-Hoch ohne die eigene Kerze; Vergleich nur über Minuten ohne Sperre; 7-Tage-Hoch live von
  Hand; σ₇ und 7-Tage-Hoch des ersten Kaufs im Labor unabhängig nachgerechnet), ganzer Labor-Selbsttest 77 von 77 (115 s).
  Mutationen der Regel: 10 von 10 rot (Sperre aus, 1,2 → 1,0, σ statt σ₇, Nachkauf ohne Stufe, H7 mit Zukunft im Rückblick und live je eigens,
  Warteregel ohne Wirkung, Perp-Gebühr, Zufall ohne Sperrfilter, Kontrolle mit A2). „H7 mit Zukunft live“ war zuerst grün (der Dump
  im Labor-Markt hat danach nur tiefere Hochs) — dafür kam die Probe „7-Tage-Hoch live von Hand“ dazu. „Funding gerechnet“ entfällt:
  Die Strategie hat keinen Funding-Pfad, den man umschalten könnte.
- **Browserprobe des Reiters** (Nutzlast aus den echten Funktionen auf einem Speicher mit Käufen von Hand; Sollwerte unabhängig):
  54 von 54 am Rechner und auf dem Handy, auch ohne Browser-Speicher. Mutationen der Anzeige 13 von 13 rot (Lose alt zuerst, Linien
  vertauscht, Gesamtwert falsch, Aufklappen vergessen, Fadenkreuz daneben, Beschriftung vertauscht, Beschriftung auf der Linie, alle
  Spalten am Handy, Lose ohne Umbruch, nächster Kauf nur A1, Sperre ignoriert, Vorteil mit Ampelfarbe, Ereignisse ohne Käufe).
- **Seit 23.70 (U184), Stand 01:03:** Startkauf von Hand (10 Fälle: sofort, ohne 7-Tage-Hoch, auch in der Kontrolle, nicht über der
  Sperre, nicht mit altem Kurs, nicht ohne MA200 oder σ, kein zweiter, danach binnen 7 Tagen nur Nachkauf, ohne Startregel kein A0);
  Rückrechnung auf Kerzen von Hand (A0 zur Eröffnung erst unter der Sperre, A3 binnen 7 Tagen, A1 danach; ohne Start-Zeitpunkt kein A0);
  Rückblick = Live auch mit Startregel; Ende zu Ende mit einem Coin-Start 11 Tage vor dem Dump (A0 zur Eröffnung der ersten Minute,
  Tageszeile von Hand, nachgerechnete Käufe alle vor dem ersten Takt, Ereignisse „spot“, Vergleich ohne A0, 5.000 USD), Neustart ohne
  zweite Rückrechnung, frischer Speicher mit A0 live zum Ask; der Rückblick seit 2020 ohne A0. Teil „Akkumulation“ 13 von 13, ganzer
  Labor-Selbsttest 80 von 80. Mutationen der Regel 25 von 25 rot (die 10 von 23.69 und 15 neue: Startkauf fehlt, bei jedem Takt, ohne Sperre; Rückrechnung fehlt, doppelt, ab jetzt, mit künftigen Kerzen, ohne Sperre, ohne Tageszeilen, Startkauf zum Schluss statt zur Eröffnung; Rückblick mit Startkauf; Vergleich mit Startkauf; Betrag 1.000; Ereignis „long“ live und nachgerechnet). Browserprobe mit neuen Daten (Startkauf je Coin, nachgerechnete und live
  gekaufte Lose, ZEC ohne Kauf über der Sperre, HYPE der Kontrolle ohne σ) 58 von 58; Mutationen der Anzeige 20 von 20 rot (die 13 von 23.69 und 7 neue: Startkauf ohne Namen, „nachgerechnet“ fehlt, Zeitraum ab der Anlage statt ab dem Beginn der Rückrechnung, ohne „davon nachgerechnet“, Vergleich nach allen Käufen gezählt, „Startkauf ausstehend“ fehlt, Spot-Käufe grau).
- **Seit 23.71 (U185), Stand 02:30:** Grund des Startkaufs von Hand (sofort, auch bei einem Start mitten in der Minute; später wegen der
  Sperre, wegen fehlender Tageskerzen, wegen beidem; Text aus 23.70 → neu, zweimal angewandt gleich, andere Texte unverändert);
  Speicher mit den Texten aus 23.70: Kauf, Ereignis und Bericht in der neuen Fassung, die gespeicherten Texte unverändert; Ende zu Ende
  mit spätem Startkauf (Kurs 5 h über der Sperre: Kauf in der ersten erlaubten Minute zur Eröffnung, Grund mit Zeit und Ursache). Teil
  „Akkumulation“ 16 von 16, ganzer Labor-Selbsttest 83 von 83 (126 s). Mutationen 11 von 11 rot (Umschreiben aus, nur in den Käufen,
  nur in den Ereignissen; Ursache fehlt, vertauscht, nur die letzte Minute, auch bei sofortigem Kauf, Zeit vom Start statt vom Kauf,
  „beides“ als Sperre; Text von 23.70 beim Nachrechnen; Bericht 120 Zeichen); die 25 Mutationen der Regel aus 23.70 erneut 25 von 25
  rot. Browserprobe mit neuen Daten (ETH mit dem gespeicherten Text aus 23.70, HYPE später gekauft; 14 bzw. 6 Käufe) 75 von 75 am
  Rechner, auf dem Handy (390 px) und schmal (360 px): „Alle Käufe“ (neueste 10, Knopf, Reihenfolge, Nummer, Coin, Auslöser,
  Gewinn, Grund), „Stand je Tag“ (Titel, „Käufe“ bis dahin, „neu“, Markierung, eingesetzt = Käufe × 5.000 USD, je Coin und alle).
  Mutationen der Anzeige 41 von 41 rot (die 20 aus 23.70 und 21 neue).
- **Seit 23.72 (U186), Stand 03:54:** Korrekturkauf von Hand (10 Fälle: 7 % unter dem 48-h-Hoch, knapp darüber nicht, ohne Sperre wo A0–A3
  gesperrt sind, Bezug nach einem Kauf, Nachkauf binnen 14 Tagen, danach nicht, ohne Hoch nur der Nachkauf, alter Kurs); auf Kerzen von
  Hand (48 h statt 7 Tage, derselbe Einbruch einmal, neues Hoch nach dem Kauf, Nachkauf nach 9 Tagen, Eröffnung darunter und zweite
  Stufe in derselben Kerze, nach 14 Tagen kein Nachkauf); Rechnung = unabhängige Referenz (je Minute ein Fenster-Schnitt) auf drei
  Zufallswegen mit Einbrüchen; Rückrechnung = Live-Regel Takt für Takt; 48-h-Hoch live von Hand; im Labor: Korrekturkäufe live am Dump
  gleich einer unabhängigen Takt-Rechnung (Mitte aus dem Buch, Hoch per Abfrage), ohne die Regel dieselben Käufe A0–A3 auf die Minute
  und den Preis, ein Coin über der Sperre wie ZEC (kein A0–A3, Korrekturkäufe rückwirkend gleich der Referenz und live), Tageskerzen
  erst im zweiten Takt (vorher kein Kauf, danach die ganze Rückrechnung), frühere Regelstände in den Ereignissen „(alte Regeln)“. Teil
  „Akkumulation“ 25 von 25, ganzer Labor-Selbsttest 92 von 92 (123 s). Mutationen 19 von 19 rot (Korrektur 14 statt 7 %; Fenster 7 Tage statt 48 h; Nachkauf 7 statt 14 Tage auf Kerzen und live; derselbe Einbruch doppelt; ohne Nachkauf; ohne Stufen; ohne Eröffnung; live mit Sperre; Rückrechnung ohne A4; Spur vereint; 48-h-Hoch ohne Ausschluss der Kaufminute bzw. mit Zukunft; Vergleich mit A4; ohne „(alte Regeln)“; Art des Bezugs vertauscht; live ohne A4; Reihenfolge in derselben Minute; A4 live vor der Rückrechnung); die 36 älteren aus 23.70 und 23.71 erneut 36 von 36 rot (vier Zeichenketten an den neuen Code angepasst). Browserprobe 84 von 84; Mutationen der Anzeige 50 von 50 rot (die 41 aus 23.71 und 9 neue: „Korrektur“ ohne Namen, Lage ohne Korrektur-Zeile, Bezug vertauscht, frühere Regeln immer sichtbar, gemerkte alte Wahl bleibt, alle Knöpfe, Kennzahl ohne Korrektur, Regeln-Zeile ohne Korrektur, Hinweis zum Vergleich alt).

## 7. Änderung vor dem ersten echten Kurs (19.10.2026 21:30–22:10, nur synthetische Märkte)

Beim Bau der Proben habe ich die vorab geplante Prüfung „Vorteil gegen Zufallszeiten“ auf Zufallswegen gerechnet. Ergebnis
(Skripte und Protokolle im Scratchpad `b81/`: `akku_sim.py`, `akku_sim2.py` → `sim2.log`, 21:35):
- 60 Zufallswege ohne Drift (3 Jahre, σ_Tag 2,5 %): Vorteil im Median +2,0 %, p < 0,05 in 10 % der Märkte, p > 0,95 in 5 % — die
  Prüfung ist schief, ohne dass die Regel etwas vorhersagt. Mit starker Drift (+0,2 % je Tag) +3,4 %.
- Dieselbe Größe gegen 60 Vorzeichen-Surrogate (2 Jahre): auf Zufallswegen richtig (0 von 30, mit Drift 0 von 25 unter 0,05), aber
  fast ohne Teststärke: Auf Märkten, deren Kurs binnen Tagen zurückläuft, kam keiner von 13 unter 0,05 (einer unter 0,10, Median p
  0,30), weil der Vorteil mit dem Trend des ganzen Zeitraums stark schwankt.
- Die Zeitpunkt-Kennzahl Q (7 Tage nach dem Kauf) gegen dieselben Surrogate: auf Zufallswegen nicht belegt, auf Märkten mit
  Einbrüchen, die zurücklaufen, belegt. **Berichtigung 19.10. 22:55:** Die Zahlen dieser ersten Vorprobe zu Q standen hier ohne
  Protokoll („0 von 10, mit Drift 0 von 3, Einbrüche 5 von 5“). Nachgerechnet mit dem gebauten Code (`q_nachrechnung.py` →
  `q_nachrechnung.log`, 2 Jahre, 60 Surrogate, Saat 700 ff., unabhängig vom Selbsttest): Zufallswege 0 von 10 unter 0,05, mit Drift
  0 von 3, Einbrüche um 15 % mit Rückkehr 5 von 5 (p 0,016–0,017, das Minimum bei 60 Surrogaten ist 0,016). Dazu der Selbsttest
  (`labor_voll2.log`): Null 0 von 5 auswertbaren, Positivkontrolle 3 von 3 (p 0,018–0,024).

**Folge:** Q mit Vorzeichen-Surrogaten ist die maßgebliche Prüfung (Abschnitt 5); der Vorteil gegen Zufallszeiten bleibt beschreibend
(Abschnitt 4), mit Hinweis. Kein echter Kurs war dabei im Spiel.

**Nachgeprüft am 19.10. um 22:10 (Kalibrierung der maßgeblichen Prüfung, nur synthetisch, `nullp.py` → `nullp_t120.log`):**
120 Zufallswege (3 Jahre, t-Verteilung mit 4 Freiheitsgraden, σ_Tag 3,5 %, leichte Drift), je 100 Surrogate: p < 0,05 in 3 von 120 =
2,5 % (Wilson 95 %: 0,9–7,1 %), p < 0,10 in 12,5 % (7,7–19,6 %). **Vollständig gehört dazu der Vorlauf um 22:00** (`nullp_t.log`,
24 Zufallswege mit einem früheren Stand des Probeskripts oder der Regel; welcher genau, lässt sich nicht mehr nachvollziehen): p < 0,05
in 3 von 24 (12,5 %, Wilson 4,3–31,0 %). Beide zusammen: 6 von 144 = 4,2 % (Wilson 1,9–8,8 %) — mit dem Sollwert 5 % vereinbar; die
Prüfung ist nach diesen Zahlen nicht zu großzügig, ein Fehlalarmanteil bis knapp 9 % ist aber nicht ausgeschlossen. Am oberen Rand
liegen etwas mehr Märkte als erwartet (p ≥ 0,99 in 5 von 120 statt rund 2): Q fällt dort niedriger aus als auf allen Surrogaten.
Vermutete Ursache: Die Surrogate streuen die Drift des ganzen Zeitraums, der echte Weg nicht (seine Abweichungen vom Mittel summieren
sich zu null). Für „Zeitpunkt belegt“ zählt nur der untere Rand (Zahlen oben). Rechenzeit des Rückblicks auf Kerzen in voller Länge (5 Coins, BTC/ETH/ZEC/XMR ab 2020, HYPE ab
2024, 200 Surrogate): 67 s in der Sandbox, auf dem Pi geschätzt 2–4 min (Grenze des Berichtsplans 15 min).

## 7a. Änderung vor dem ersten Lauf (19.10.2026 23:20 bis 20.10., Wunsch des Nutzers; Paket 23.70)

- **Betrag:** 5.000 USD je Kauf statt 1.000 („Ich habe leider einen kleinen Fehler gemacht“). Eingesetzt, Wert und Gewinn in USD werden
  fünfmal so groß; Prozente, Ø Einstand und die Regel bleiben. Gebühr 3,50 USD je Kauf.
- **Spot:** war schon so gerechnet (eigene Bilanz, kein Hebel, kein Funding, keine Kosten beim Halten). Im Ereignisprotokoll stand die
  Seite intern als „long“ -- jetzt „spot“. Die einmalige Kaufgebühr (0,07 %) bleibt, weil auch ein echter Spot-Kauf sie kostet.
- **Startkauf A0:** Der erste Kauf je Coin kommt sofort. Meine Rückfrage, ob er auch über der 20-%-Grenze kaufen soll, beantwortete der
  Nutzer mit der Rückrechnung; die Sperre gilt deshalb wie für jeden Kauf (mein Vorschlag in der Rückfrage; „immer sofort“ wäre eine Zeile).
- **Rückrechnung:** „Datenbankstart“ lese ich als Start des Coins im TradeLabor, weil die übrigen Strategien auf genau diesen Kontotagen
  laufen („direkt vergleichbar“). Der Beginn der Aufzeichnung in `hl_liq.db` (Mitte September) wäre ein Zeitraum, den keine andere
  Strategie hat. Umsetzung in Abschnitt 2.
- **Prüfung:** Q und der Rückblick seit 2020 bleiben ohne Startkauf. Der Vergleich gegen Zufallszeiten zählt nur die Käufe nach den
  Regeln, über den Zeitraum ab dem Beginn der Rückrechnung.
- **Neue Kennungen:** Betrag und Startregel stehen in den Regeln, also ergeben sie neue Kennungen. 23.69 lief nie; es gibt keine alte
  Bilanz.
- **Kein echter Kurs:** Auch diese Änderungen sind vor jedem Lauf auf echten Kursen festgelegt und gebaut; die Rückrechnung läuft auf dem
  Pi zum ersten Mal beim ersten Takt mit 23.70.

## 7b. Anzeige berichtigt (20.10.2026, Hinweis des Nutzers 01:40; Paket 23.71, U185)

**Hinweis des Nutzers** (Screenshot nach dem Einspielen von 23.70, Kern wörtlich): „In der Liste sind sehr viele Käufe, allerdings nur
innerhalb von 23 Tagen. Aber oben steht, dass nur jeweils 5000 gekauft worden sind. Die müssten aber bei einer Akkumulation addiert
werden. Das haut vorne und hinten nicht richtig hin.“

**Nachgeprüft (Zahlen des Screenshots):** Die Rechnung stimmt. Auf dem Pi gab es drei Käufe, je einen Startkauf: BTC am 27.09. (Start
des Labors), ETH am 07.10., HYPE am 19.10.; ZEC und XMR noch ohne Kauf („gesperrt“: Kurs über 1,2 × 200-Tage-Linie). Eingesetzt 3 × 5.000 = 15.000 USD, wie
oben angezeigt. Die „Liste“ war die Tabelle je Tag: je UTC-Tag der Stand am Tagesende (eingesetzt = Summe aller Käufe bis dahin), also
23 Zeilen für 23 Tage, nicht 23 Käufe. Sie sah aus wie eine Kaufliste, und eine Liste aller Käufe über alle Coins gab es nicht (nur je
Coin zum Aufklappen). Dazu ein eigener Fehler im Text von 23.70: Der nachgerechnete Startkauf hieß immer „Startkauf zum Start des
Coins im Labor (27.09. …)“, auch bei ETH und HYPE, die erst am 07.10. bzw. 19.10. kauften. Gekauft wird nach der Regel in der ersten
Minute seit dem Start, in der ein Kauf erlaubt ist (Kurs unter der Sperre, σ₇ und 200-Tage-Linie bekannt) -- die Rechnung war richtig,
der Text nicht.

**Geändert (nur Anzeige und Texte; Rechnung, Regeln, Kennungen und gespeicherte Käufe unverändert):**
- Liste „Alle Käufe“ unter der Gesamtübersicht (Abschnitt 3).
- Die Tagestabelle heißt „Stand je Tag — keine Kaufliste“ und zeigt je Tag „Käufe“ bis dahin und „neu“ (die Käufe des Tages, markiert).
- Grund des Startkaufs (Abschnitt 2): neu nachgerechnete Startkäufe mit dem richtigen Text und, wenn sie später kamen, mit Zeit und
  Ursache. Die drei gespeicherten Texte von 23.70 auf dem Pi zeigen Reiter, Ereignisse und Bericht in der neuen Fassung, aber ohne
  Ursache (sie steht nicht im gespeicherten Text, und nachgerechnet wird nicht noch einmal); in der Datenbank bleiben sie, wie sie sind.
- Bericht: der Grund eines Kaufs ganz (bis 320 statt 120 Zeichen), damit der Startkauf-Grund nicht mitten im Satz endet.
- Handy: beide Tabellen passen ohne Seitwärtsscrollen.
- Unverändert: die drei Käufe auf dem Pi mit Zeit, Preis und Tageszeilen; keine neue Kennung (die Regeln sind dieselben), keine zweite
  Rückrechnung.

## 7c. Korrekturkauf A4 (20.10.2026, Wunsch des Nutzers 02:43; Paket 23.72, U186)

- **Regel** (Abschnitt 2): 7 % unter dem Hoch der letzten 48 h ein Korrekturkauf, danach binnen 14 Tagen je weitere 7 % unter dem
  letzten Korrekturkauf ein Nachkauf; für alle Coins, beide Strategien, 5.000 USD Spot wie jeder Kauf.
- **Meine Festlegungen** (die Zahlen nannte der Nutzer „zum Beispiel“; ich nehme sie fest): 7 % als einfacher Abstand (Kurs ≤ 0,93 ×
  Bezug); das 48-h-Hoch aus den Hyperliquid-1-min-Kerzen wie das 7-Tage-Hoch; die 14 Tage laufen ab dem letzten Korrekturkauf (jeder
  Nachkauf verlängert sie); damit derselbe Einbruch nicht in jedem Takt erneut kauft, zählt das Hoch nach einem Korrekturkauf erst ab der
  Minute danach -- ein neuer Einbruch von 7 % binnen 48 h nach einer Erholung ist eine neue Korrektur. Eigene Spur neben A0–A3, damit
  die bisherigen Regeln unverändert bleiben (sie hatten ihre Prüfung vorab); deshalb zählt A4 auch nicht für den Startkauf: ZEC und XMR
  bekommen ihren Startkauf weiter erst unter der Sperre.
- **Ohne Sperre** (Wahl des Nutzers auf meine Rückfrage, Vorschlag): ZEC und XMR hatten seit ihrem Start keinen Startkauf und stehen
  auf „gesperrt“ (Kurs über 1,2 × der 200-Tage-Linie); mit Sperre hätte A4 dort vermutlich nie gekauft.
- **Rückwirkend:** Die Regel steht in den Regeln, also neue Kennungen; beim ersten Takt mit 23.72 rechnet das Labor für die neuen
  Kennungen ab dem Start des Coins im Labor alles nach (A0–A3 wie bisher, dazu A4) und kauft danach live. Die Bilanz der bisherigen
  Kennungen (auf dem Pi die drei Startkäufe von 23.70) bleibt gespeichert und steht unter „frühere Regeln“; ihre Ereignisse heißen „…
  (alte Regeln)“. Die Käufe A0–A3 der neuen Kennungen sind dieselben (Probe), dazu kommen die Korrekturkäufe.
- **Nicht dabei:** ein Vergleich gegen Zufallszeiten für A4 und A4 im Rückblick seit 2020 (beides nicht vorab festgelegt); der Vergleich
  und der Rückblick zählen weiter nur A1–A3 (Abschnitte 4 und 5). Kein Hinweis, dass die Regel einen Vorteil bringt: sie kauft fallende
  Kurse, und nach U141 ging es nach Einbrüchen oft weiter abwärts -- dafür kauft sie nach; was es bringt, zeigt erst die Bilanz.
- **Kapital:** ohne Obergrenze wie bisher; in einem Absturz um 50 % wären es je Coin bis zu 9 Korrekturkäufe (45.000 USD), dazu die
  Käufe A1–A3, wo die Sperre sie zulässt.

## 8. Abgrenzung

- Wirkt nur im Labor (eigene Tabellen in `forecasts.db`). Keine Wirkung auf Konfluenz, Prognose, Treiber, Fusion, v3, Kaskaden,
  v1-Lernen. Liest nur `hl_liq.db` (Kurse, 1-min-Kerzen, Buch, Heatmap, `bnc_metrics`), `swing.db` und den eigenen Labor-Zustand
  (Start je Coin); keine Daten aus Chartbild, Ausblick, Aktien,
  Makro, Datentage oder CryptoQuant (Zusage bis 25.10.).
- Simulation ohne echtes Geld. Ob die Regel taugt, zeigt der Vergleich; eine Empfehlung ist sie nicht.

## 9. Termine

- **20.10. 08:45** (Berichtsplan `u180-akku-rueckblick`): Rückblick seit 2020 (Abschnitt 5) und der Labor-Bericht mit den ersten
  Käufen (Startkauf und Rückrechnung) und der Lage je Coin; zweiter Termin 21.10. 08:45 nur, falls 23.70 später eingespielt wurde.
  Bitte hochladen.
- Danach wöchentlich im Labor-Bericht (Mittwoch 19:00): Abschnitt „AKKUMULATION“ je Strategie und Coin.
