#!/usr/bin/env python3
"""
check_notbremse.py -- Debug-Werkzeug der Notbremse (U206; KONZEPT_Notbremse.md Fassung 1, Abschnitte 1 „Schritt 0“, 3 und 10.4).

  python3 check_notbremse.py [--db hl_liq.db]            Zustand, Schwellen, Episoden, Korb, Historie, Takt (kurz)
  python3 check_notbremse.py --zerlegung 2026-10-22      Verlustzerlegung der Welt B um den Tag (Schritt 0)
  python3 check_notbremse.py --rueckblick                Rückblick (10.4): Stufen mit den Schwellen der ersten Kalibrierung, Episoden,
                                                         Empfindlichkeit (Budget 2 / 4 / 8), Zerlegung des Tages, Labor-Rückwärtstest
                                                         Welt A gegen Welt B, Positivkontrollen (data.binance.vision)
        Zusätze: --tag 2026-10-22 · --takt 300 (s, Rückwärtstest) · --max-stunden 8 · --ohne-labor · --ohne-binance
  python3 check_notbremse.py --selbsttest                Proben auf synthetischen Daten (ohne Netz)

Liest nur: hl_liq.db, notbremse.db und der Prognosespeicher (Welt B) bleiben unverändert. Der Rückwärtstest rechnet in einem eigenen
Ordner neben der Datenbank (danach gelöscht) und sieht je Takt nur Daten bis zu dessen Zeit (Sichten mit ts ≤ Takt, Minutenkerzen nur
abgeschlossene). Die Positivkontrollen legen ihre Kursdaten verdichtet in notbremse_binance/ neben der Datenbank ab.
Ausgabe als Text zum Einfügen in den Chat; jede Zeile sofort, jeder Abschnitt mit seiner Laufzeit. Zeiten in UTC.
"""
from __future__ import annotations

import argparse
import copy
import csv
import io
import json
import math
import os
import re
import sqlite3
import sys
import tempfile
import time
import zipfile
from datetime import date, datetime, timezone

import numpy as np

import hl_notbremse as NB

UTC = timezone.utc
TAG = NB.TAG
HIER = os.path.dirname(os.path.abspath(__file__))
TAG_STANDARD = "2026-10-22"
BUDGETS = (2, 4, 8)                                   # Empfindlichkeitstabelle (KONZEPT 10.4): Stufe-1-Episoden je 30 Tage
# Eingaben, die im Rückblick nicht je Zeitpunkt vorliegen -- Strategien damit rechnet der Rückwärtstest nicht nach (Abdeckung im Bericht)
AUSGESCHLOSSEN = {"darwin": "Darwin-Liste nur als jüngster Stand gespeichert (learned), nicht je Zeitpunkt",
                  "elite": "Elite-Liste nur als jüngster Stand gespeichert (learned), nicht je Zeitpunkt",
                  "adressstrom": "Adressstrom (adressfluss.db) wird ohne Zeitgrenze gelesen und nur 14 Tage aufbewahrt"}
QUELLE_JE_EINGABE = {"prognose": "forecast", "treiber": "forecast_drivers", "familie": "forecast_drivers", "staerke": "forecast_drivers",
                     "kaskade": "bars", "grid": "bars", "akku": "bars", "docht": "heatmap", "anker": "heatmap", "funding": "ctx_bars",
                     "swing": "swing"}
QUELLE_NAME = {"bars": "Minutenkerzen", "forecast": "Prognose", "forecast_drivers": "Treiber", "heatmap": "Heatmap", "ctx_bars": "Funding",
               "swing": "Swing-Tageskerzen"}
EREIGNISSE = ((date(2025, 10, 10), "Zollankündigung, Rekordliquidationen"),
              (date(2025, 6, 22), "US-Angriffe auf iranische Atomanlagen (Sonntag)"),
              (date(2026, 2, 28), "Beginn der US-israelischen Angriffe auf Iran (Samstag)"))
BINANCE_URL = "https://data.binance.vision/data/futures/um/monthly/klines/{s}/1m/{s}-1m-{j:04d}-{m:02d}.zip"
BINANCE_UA = {"User-Agent": "hl-dashboard/1.0 (notbremse)"}


# --------------------------------------------------------------------------------------------- Ausgabe
def w(text: str = "") -> None:
    print(text, flush=True)


class abschnitt:
    """with abschnitt("Titel"): ... -- Überschrift sofort, Laufzeit am Ende; ein Fehler wird gemeldet, die übrigen Abschnitte laufen weiter."""

    def __init__(self, titel: str):
        self.titel = titel

    def __enter__(self):
        self.t0 = time.time()
        w(); w(f"== {self.titel}")
        return self

    def __exit__(self, typ, wert, tb):
        if typ is not None:
            import traceback
            w(f"   FEHLER in diesem Abschnitt: {typ.__name__}: {wert}")
            w("   " + traceback.format_exc()[-900:].replace("\n", "\n   "))
        w(f"   ({time.time() - self.t0:.1f} s)")
        return typ is not None and issubclass(typ, Exception)


def _utc(ts, mit_datum: bool = True) -> str:
    if ts is None:
        return "—"
    d = datetime.fromtimestamp(int(ts), UTC)
    return d.strftime("%d.%m. %H:%M UTC" if mit_datum else "%H:%M")


def _datum(ts) -> str:
    return "—" if ts is None else datetime.fromtimestamp(int(ts), UTC).strftime("%d.%m.%Y")


def _usd(x, nd: int = 0) -> str:
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "—"
    return (f"{x:+,.{nd}f}").replace(",", "§").replace(".", ",").replace("§", ".")


def _z(x, nd: int = 2) -> str:
    return NB._de(x, nd)


def _f(x):
    """NaN → None (für die Zustandsmaschine)."""
    return None if x is None or not np.isfinite(x) else float(x)


# --------------------------------------------------------------------------------------------- Pfade
def _unit_arg(flag: str, unit: str = "hl-recorder") -> str | None:
    try:
        with open(f"/etc/systemd/system/{unit}.service", encoding="utf-8") as f:
            m = re.search(rf"{flag}\s+(\S+)", f.read())
        return m.group(1) if m else None
    except OSError:
        return None


def db_standard() -> str:
    return _unit_arg("--db") or os.path.join(HIER, "hl_liq.db")


def store_standard(db: str) -> str:
    p = os.path.join(os.path.dirname(os.path.abspath(db)), "forecasts.db")
    if os.path.exists(p):
        return p
    import hl_forecast as F
    return F.STORE


def _ro(pfad: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=60)
    con.execute("PRAGMA busy_timeout=60000")
    return con


def gruppen_lesen(con_nb) -> tuple:
    """Körbe wie im Dienst (nb_meta „korb“), nur Instrumente mit 15-min-Schlüssen. -> ({K, A}, korb)"""
    korb = NB.meta_lesen(con_nb, "korb") or {}

    def da(i):
        return con_nb.execute("SELECT 1 FROM nb_kerze15 WHERE inst=? LIMIT 1", (i,)).fetchone() is not None
    K = [i for i in (korb.get("K") or NB.EIGENE) if da(i)]
    A = [i for i in (korb.get("A") or [f"{NB.XYZ}:{k}" for k in NB.AKTIEN]) if da(i)]
    return {"K": K, "A": A}, korb


# --------------------------------------------------------------------------------------------- Rückblick: Reihen und Stufen
def retro_reihen(con_nb, con_main, gruppen: dict, bis: int | None = None) -> dict | None:
    """X (15-min-Raster), Y und Λ (1-min-Raster, eigene Coins) vom ersten Tag mit σ (wie bei der ersten Kalibrierung: σ ab 10 Tagen) bis
    `bis` (Vorgabe jetzt). -> Reihen von hl_notbremse.reihen_aus_daten mit start, ende oder None"""
    r = con_nb.execute("SELECT MIN(ts) FROM nb_kerze15").fetchone()
    if not r or r[0] is None:
        return None
    ende = int(bis or time.time()) // 60 * 60
    start_tag = (int(r[0]) // TAG + 1) * TAG + NB.ERSTE_KALIB_SIGMA_MIN_TAGE * TAG
    ende_tag = (ende // TAG + 1) * TAG
    if start_tag >= ende:
        return None
    R = NB.reihen_aus_daten(con_nb, con_main, gruppen, start_tag, ende_tag, NB.ERSTE_KALIB_SIGMA_MIN_TAGE)
    R.update(start=start_tag, ende=ende)
    return R


def retro_stufen(R: dict, th: dict, bis: int | None = None) -> dict:
    """Die Zustandsmaschine des Dienstes Minute für Minute über die Reihen des Rückblicks: X und G(K, 60) vom 15-min-Raster (der Wert zur
    Zeit T gilt bis T + 15 min), Y und Λ je Minute; ohne Termine, Handbremse und Ebene B. -> {t0, stufe (je Minute), episoden}"""
    X = R["X_reihe"]; Y = R["Y_reihe"]
    t0 = int(R["start"]); t1 = int(bis or R["ende"])
    n = max(0, (t1 - t0) // 60)
    M = NB.Maschine()
    st = np.zeros(n, dtype=np.int8); eps = []
    X15, G15 = X["X"], X.get("GK60")
    Y1 = Y["Y"] if Y else None; L1 = Y["lam"] if Y else None
    for k in range(n):
        t = t0 + 60 * k
        j = k // 15
        m = {"X": _f(X15[j]) if j < len(X15) else None, "GK60": _f(G15[j]) if G15 is not None and j < len(G15) else None,
             "Y": _f(Y1[k]) if Y1 is not None and k < len(Y1) else None, "lam": _f(L1[k]) if L1 is not None and k < len(L1) else None}
        z = M.schritt(t, m, th)
        st[k] = z["stufe"]
        if z["neu"]:
            eps.append({"start": t, "ende": None, "stufe_max": z["stufe"], "quelle": z["quelle"], "x": m["X"], "y": m["Y"], "lam": m["lam"],
                        "t2": t if z["stufe"] >= 2 else None})
        elif z["stufe"] >= 1 and eps:
            e = eps[-1]; e["stufe_max"] = max(e["stufe_max"], z["stufe"])
            if z["stufe"] >= 2 and e["t2"] is None:
                e["t2"] = t
        elif z["ende"] and eps:
            eps[-1]["ende"] = t
    return {"t0": t0, "t1": t0 + 60 * n, "stufe": st, "episoden": eps, "th": th}


def erste_sperre(S: dict, von: int, bis: int) -> int | None:
    """Erste Minute in [von, bis) mit Stufe ≥ 1."""
    a = max(0, (von - S["t0"]) // 60); b = max(0, min(len(S["stufe"]), (bis - S["t0"]) // 60))
    idx = np.nonzero(S["stufe"][a:b] >= 1)[0]
    return int(S["t0"] + 60 * (a + idx[0])) if len(idx) else None


def schwellen_erste(con_nb, con_main, gruppen: dict) -> dict:
    """Schwellen der ersten Kalibrierung (Daten bis 20.10. 23:59 UTC) je Budget 2 / 4 / 8 (Stufe 2 je 1), dazu die gespeicherte Zeile."""
    erg = NB.kalibrierung_aus_daten(con_nb, con_main, gruppen, NB.ERSTE_KALIB_BIS, erste=True)
    je = {}
    for b in BUDGETS:
        je[b] = NB.kalibrieren(erg.get("X_reihe"), erg.get("Y_reihe"), {"s1x": b, "s2x": NB.BUDGET["s2x"], "s2y": NB.BUDGET["s2y"]})
    gesp = None
    for r in con_nb.execute("SELECT gueltig_ab, theta1, theta2x, theta2y, info_json FROM nb_schwellen ORDER BY gueltig_ab"):
        info = json.loads(r[4] or "{}")
        if info.get("erste"):
            gesp = {"gueltig_ab": r[0], "theta1": r[1], "theta2x": r[2], "theta2y": r[3], "info": info}
            break
    return {"je": je, "erg": erg, "gespeichert": gesp}


def _th(k: dict) -> dict:
    return {"theta1": float(k["theta1"]), "theta2x": float(k["theta2x"]), "theta2y": float(k["theta2y"])}


# --------------------------------------------------------------------------------------------- Werte von Positionen (Zerlegung, Welten)
class Kurse:
    """Kurs zur Zeit t = Schluss der letzten Minute vor t (wie hl_notbremse.summe_zu), gemerkt."""

    def __init__(self, con_main):
        self.con = con_main; self.m: dict = {}

    def __call__(self, coin: str, t: int):
        k = (coin, int(t))
        if k not in self.m:
            self.m[k] = NB._kurs_zu(self.con, coin, int(t))
        return self.m[k]


def positionen_lesen(store: str, von: int | None = None, bis: int | None = None) -> list:
    """Positionen, die [von, bis) berühren (eröffnet vor bis, nicht vor von geschlossen), dazu die Akku-Käufe als Positionen ohne Ende."""
    con = _ro(store)
    try:
        q = ("SELECT id, sid, coin, seite, eroeffnet, geschlossen, preis_ein, menge, gebuehr_ein, funding, netto_usd, art_ein "
             "FROM labor_position WHERE 1=1")
        arg = []
        if bis is not None:
            q += " AND eroeffnet < ?"; arg.append(int(bis))
        if von is not None:
            q += " AND (geschlossen IS NULL OR geschlossen > ?)"; arg.append(int(von))
        try:
            out = [{"art": "pos", "id": r[0], "sid": r[1], "coin": r[2], "seite": r[3], "eroeffnet": int(r[4]), "geschlossen": r[5],
                    "preis_ein": float(r[6]), "menge": float(r[7]), "gebuehr_ein": float(r[8] or 0.0), "funding": float(r[9] or 0.0),
                    "netto": r[10], "art_ein": r[11] or ""} for r in con.execute(q, arg)]
        except sqlite3.OperationalError as e:
            if "no such table" not in str(e):
                raise
            return []                                                      # Speicher ohne Labor (noch kein TradeLabor)
        try:
            q = "SELECT id, sid, coin, ts, usd, menge FROM labor_akku_kauf WHERE 1=1"; arg = []
            if bis is not None:
                q += " AND ts < ?"; arg.append(int(bis))
            out += [{"art": "akku", "id": r[0], "sid": r[1], "coin": r[2], "seite": "long", "eroeffnet": int(r[3]), "geschlossen": None,
                     "usd": float(r[4] or 0.0), "menge": float(r[5] or 0.0), "art_ein": "Akkumulation"} for r in con.execute(q, arg)]
        except sqlite3.Error:
            pass
        try:
            orders = {int(r[0]): int(r[1]) for r in con.execute("SELECT pos_id, erstellt FROM labor_order WHERE pos_id IS NOT NULL")}
        except sqlite3.Error:
            orders = {}
    finally:
        con.close()
    for p in out:
        if p["art"] == "pos":
            p["order_erstellt"] = orders.get(int(p["id"]))
    return out


def wert_zu(p: dict, t: int, kurs, jetzt: float | None = None):
    """Beitrag einer Position zum Ergebnis ihrer Welt zur Zeit t (dieselbe Rechnung wie hl_notbremse.summe_zu): 0 vor der Eröffnung,
    netto nach dem Schließen, sonst Bestand zum Kurs nach Ausstiegsgebühr und anteiligem Funding. Akku-Kauf: Menge · Kurs − Einsatz.
    None, wenn der Kurs fehlt."""
    import hl_labor
    t = int(t)
    if t < p["eroeffnet"]:
        return 0.0
    if p["art"] == "akku":
        px = kurs(p["coin"], t)
        return None if not px else p["menge"] * px - p["usd"]
    if p["geschlossen"] is not None and t >= int(p["geschlossen"]):
        return float(p["netto"] or 0.0)
    px = kurs(p["coin"], t)
    if not px:
        return None
    dauer = max(int(p["geschlossen"] or (jetzt or time.time())) - p["eroeffnet"], 1)
    f_ = p["funding"] * min(1.0, max(0.0, (t - p["eroeffnet"]) / dauer))
    vz = 1 if p["seite"] == "long" else -1
    return (px - p["preis_ein"]) * p["menge"] * vz - p["gebuehr_ein"] - p["menge"] * px * hl_labor.gebuehr(p["coin"], hl_labor.GEB_TAKER) - f_


def summe_je_sid(store: str, con_main, t: int, von_eroeffnet: int | None = None) -> dict:
    """{sid: [Anzahl, USD zur Zeit t]} -- alle Positionen und Akku-Käufe (oder nur die ab von_eroeffnet eröffneten)."""
    kurs = Kurse(con_main); out: dict = {}
    for p in positionen_lesen(store, None, t + 1):
        if von_eroeffnet is not None and p["eroeffnet"] < von_eroeffnet:
            continue
        v = wert_zu(p, t, kurs)
        if v is None:
            continue
        e = out.setdefault(p["sid"], [0, 0.0]); e[0] += 1; e[1] += v
    return out


# --------------------------------------------------------------------------------------------- Zerlegung (KONZEPT 1, Schritt 0)
TEILE = {"a": "Longs, vor t0 eröffnet (Bestand bei t0, auch Grid-Lose und Akku-Käufe)",
         "b": "Long-Einstiege nach t0 (Markt, Limit aus Orders nach t0, Akkumulation)",
         "c": "Long-Limit-Füllungen nach t0 aus Orders, die vor t0 lagen",
         "d": "Grid-Kauf-Lose nach t0",
         "e": "Shorts (alle, auch Grid Short)"}


def teil_von(p: dict, t0: int) -> tuple:
    """(Teil, Unterart). Shorts → e; Longs vor t0 → a; danach Grid → d, Limit aus Order vor t0 → c, sonst b (Markt, Limit nach t0,
    Akkumulation, Limit ohne Order-Zeile)."""
    if p["seite"] != "long":
        return "e", ""
    if p["eroeffnet"] < t0:
        return "a", ""
    if str(p["sid"]).startswith("grid_"):
        return "d", ""
    if p["art"] == "akku":
        return "b", "Akkumulation"
    if str(p["art_ein"]).startswith("Limit"):
        oe = p.get("order_erstellt")
        if oe is None:
            return "b", "Limit ohne Order-Zeile"
        return ("c", "") if oe < t0 else ("b", "Limit aus Order nach t0")
    return "b", "Markt"


def zerlegung(store_b: str, con_main, t0: int, w0: int, w1: int) -> dict:
    """Netto der Welt B in [w0, w1) je Teil: Beitrag je Position = Wert(w1) − Wert(w0) (realisiert + Bestand, nach Gebühren und Funding).
    Prüfsumme: Summe der Teile gegen summe_zu(w1) − summe_zu(w0) (eigener Rechenweg)."""
    kurs = Kurse(con_main); jetzt = time.time()
    teile = {k: {"usd": 0.0, "n": 0, "unter": {}, "je": {}} for k in TEILE}
    ohne_kurs = 0
    for p in positionen_lesen(store_b, w0, w1):
        a, b = wert_zu(p, w0, kurs, jetzt), wert_zu(p, w1, kurs, jetzt)
        if a is None or b is None:
            ohne_kurs += 1; continue
        d = b - a
        tl, unter = teil_von(p, t0)
        T = teile[tl]; T["usd"] += d; T["n"] += 1
        if unter:
            u = T["unter"].setdefault(unter, [0.0, 0]); u[0] += d; u[1] += 1
        key = (str(p["sid"]).split("@")[0], p["coin"])
        e = T["je"].setdefault(key, [0.0, 0]); e[0] += d; e[1] += 1
    s0, s1 = NB.summe_zu(store_b, con_main, w0), NB.summe_zu(store_b, con_main, w1)
    gesamt = (s1 - s0) if None not in (s0, s1) else None
    return {"teile": teile, "summe": sum(T["usd"] for T in teile.values()), "gesamt": gesamt, "ohne_kurs": ohne_kurs, "t0": t0, "w0": w0, "w1": w1}


def zerlegung_text(Z: dict, t0_text: str) -> list:
    z = [f"   Fenster {_utc(Z['w0'])} bis {_utc(Z['w1'])} · t0 = {_utc(Z['t0'])} ({t0_text})",
         f"   Netto der Welt B im Fenster (realisiert + Bestand, nach Gebühren und Funding): {_usd(Z['gesamt'])} USD",
         "   Teil  USD          Anzahl  Inhalt"]
    for k, txt in TEILE.items():
        T = Z["teile"][k]
        z.append(f"   ({k})  {_usd(T['usd']):>11}  {T['n']:>6}  {txt}")
        if T["unter"]:
            z.append("          davon " + " · ".join(f"{u} {_usd(v[0])} ({v[1]})" for u, v in sorted(T["unter"].items(), key=lambda kv: kv[1][0])))
    abw = (Z["summe"] - Z["gesamt"]) if Z["gesamt"] is not None else None
    z.append(f"   Summe der Teile {_usd(Z['summe'])} USD; Netto über den zweiten Rechenweg {_usd(Z['gesamt'])} USD (Abweichung {_usd(abw, 2)} USD)"
             + (f"; {Z['ohne_kurs']} Positionen ohne Kurs nicht gezählt" if Z["ohne_kurs"] else ""))
    bcd = sum(Z["teile"][k]["usd"] for k in "bcd")
    z.append(f"   Näherung ohne Folgeeffekte: Hätte eine Sperre ab t0 die Teile (b)–(d) verhindert, wäre das Fenster um {_usd(-bcd)} USD anders "
             "ausgefallen. Die genaue Zahl mit Folgeeffekten liefert der Rückwärtstest (Welt A gegen Welt B).")
    z.append("   Die zehn größten Verlierer je Teil (Strategie · Coin: USD, Anzahl):")
    for k in TEILE:
        je = sorted(Z["teile"][k]["je"].items(), key=lambda kv: kv[1][0])[:10]
        je = [x for x in je if x[1][0] < 0]
        if je:
            z.append(f"   ({k}) " + " · ".join(f"{s} {c}: {_usd(v[0])} ({v[1]})" for (s, c), v in je))
    return z


def t0_bestimmen(stufen: dict, X_reihe: dict | None, tag_ts: int, w0: int, w1: int) -> tuple:
    """t0 nach KONZEPT 1: erste Minute mit Stufe ≥ 1 im Fenster mit den vorab kalibrierten Schwellen (Budget 4); sonst beim empfindlichsten
    Budget (8); sonst die Minute mit dem kleinsten X am Tag. -> (t0, Fall-Text)"""
    t = erste_sperre(stufen[4], w0, w1) if 4 in stufen else None
    if t is not None:
        return t, "Fall 1: erste Minute mit Stufe ≥ 1 im Fenster, Schwellen der ersten Kalibrierung"
    b_max = max(stufen) if stufen else None
    t = erste_sperre(stufen[b_max], w0, w1) if b_max is not None else None
    if t is not None:
        return t, f"Fall 2: die Bremse löst mit den vorab kalibrierten Schwellen nicht aus; erste Minute mit Stufe ≥ 1 beim Budget {b_max}"
    if X_reihe is not None:
        T, X = X_reihe["T"], X_reihe["X"]
        m = (T >= tag_ts) & (T < tag_ts + TAG) & np.isfinite(X)
        if np.any(m):
            k = int(np.nanargmin(np.where(m, X, np.inf)))
            return int(T[k]), f"Fall 3: keine Sperre, auch nicht beim Budget {b_max}; Minute mit dem kleinsten X am Tag (X {_z(float(X[k]))} σ)"
    return tag_ts + 12 * 3600, "Fall 3 ohne Daten: weder Sperre noch X am Tag -- t0 behelfsweise 12:00 UTC"


# --------------------------------------------------------------------------------------------- Labor-Rückwärtstest (KONZEPT 10.4)
def strategien_rueck() -> tuple:
    """(nachgebildete Namen, {Name: Grund}) -- ohne Strategien mit Eingaben, die nicht je Zeitpunkt vorliegen."""
    import hl_labor as LB
    nur, aus = [], {}
    for s in LB.strategien():
        grund = next((AUSGESCHLOSSEN[e] for e in s["eingaben"] if e.split(":")[0] in AUSGESCHLOSSEN), None)
        if grund:
            aus[s["name"]] = grund
        else:
            nur.append(s["name"])
    return tuple(nur), aus


def _labor_klasse():
    import hl_forecast as F  # noqa: F401  (Speicherschema)
    import hl_labor as LB

    class RueckLabor(LB.Labor):
        """Das Labor im Rückblick: liest hl_liq.db und den Prognosespeicher nur bis zur Zeit des Takts (temporäre Sichten mit ts ≤ Takt;
        Minutenkerzen nur abgeschlossene, ts ≤ Takt − 60) und schreibt in einen eigenen Speicher. Sonst derselbe Code wie im Dashboard."""

        def __init__(self, db, store, store_echt, **kw):
            super().__init__(db, store, **kw)
            self.store_echt = store_echt; self._jetzt = 0; self._tab_m = None; self._tab_q = None

        def zyklus(self, now=None, E_von=None):
            self._jetzt = int(now)
            return super().zyklus(now, E_von)

        def _con(self):
            con = sqlite3.connect("file::memory:", uri=True, timeout=30)
            con.execute("ATTACH DATABASE ? AS m", (f"file:{self.db}?mode=ro",))
            con.execute("CREATE TEMP TABLE jetzt (t INTEGER)")
            con.execute("INSERT INTO temp.jetzt VALUES (?)", (self._jetzt,))
            con.commit()
            if self._tab_m is None:
                self._tab_m = [(n, any(c[1] == "ts" for c in con.execute(f'PRAGMA m.table_info("{n}")')))
                               for (n,) in con.execute("SELECT name FROM m.sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite%'")]
            for n, hat_ts in self._tab_m:
                bed = ""
                if hat_ts:
                    bed = " WHERE ts <= (SELECT t FROM temp.jetzt) - 60" if n == "bars" else " WHERE ts <= (SELECT t FROM temp.jetzt)"
                con.execute(f'CREATE TEMP VIEW "{n}" AS SELECT * FROM m."{n}"{bed}')
            return con

        def _st(self):
            st = sqlite3.connect(f"file:{self.store}", uri=True, timeout=30)
            st.execute("PRAGMA journal_mode=WAL"); st.execute("PRAGMA synchronous=OFF"); st.execute("PRAGMA temp_store=MEMORY")
            LB.schema(st)
            st.execute("ATTACH DATABASE ? AS q", (f"file:{self.store_echt}?mode=ro",))
            if self._tab_q is None:
                self._tab_q = {n for (n,) in st.execute("SELECT name FROM q.sqlite_master WHERE type='table'")}
            st.execute("CREATE TEMP TABLE jetzt (t INTEGER)")
            st.execute("INSERT INTO temp.jetzt VALUES (?)", (self._jetzt,))
            for n in ("forecast", "forecast_drivers", "familien_log"):
                if n in self._tab_q:
                    st.execute(f'CREATE TEMP VIEW "{n}" AS SELECT * FROM q."{n}" WHERE ts <= (SELECT t FROM temp.jetzt)')
            st.commit()
            return st

    return RueckLabor


class TorRueck(NB.Tor):
    """Das Tor mit der Stufenreihe des Rückblicks statt notbremse.db; gesperrte Vorgänge bleiben im Speicher (Bericht)."""

    def __init__(self, zeilen: list, welt_start: int):
        super().__init__(None, "A", welt_start=welt_start, zustaende=zeilen)
        self.alle: list = []

    def schreiben(self) -> None:
        self.alle.extend(self.puffer); self.puffer = []


def _daten_ab(db: str, store_echt: str, coins) -> dict:
    """Erster Zeitpunkt je Quelle (der späteste über die Coins) -- für die Abdeckung."""
    out = {}
    con = _ro(db)
    try:
        for tab in ("bars", "heatmap", "ctx_bars"):
            v = []
            for c in coins:
                try:
                    r = con.execute(f'SELECT MIN(ts) FROM "{tab}" WHERE coin=?', (c,)).fetchone()
                    if r and r[0] is not None:
                        v.append(int(r[0]))
                except sqlite3.Error:
                    pass
            out[tab] = max(v) if v else None
    finally:
        con.close()
    try:
        st = _ro(store_echt)
        try:
            for tab in ("forecast", "forecast_drivers"):
                v = []
                for c in coins:
                    try:
                        r = st.execute(f'SELECT MIN(ts) FROM "{tab}" WHERE coin=?', (c,)).fetchone()
                        if r and r[0] is not None:
                            v.append(int(r[0]))
                    except sqlite3.Error:
                        pass
                out[tab] = max(v) if v else None
        finally:
            st.close()
    except sqlite3.Error:
        pass
    return out


def labor_rueckwaerts(db: str, store_echt: str, stufen: dict, t_von: int, t_bis: int, takt: int = 300, max_s: float = 8 * 3600,
                      coins=None, nur=None, fenster: tuple | None = None, ausgabe=w, swing: str | None = None) -> dict:
    """
    Welt B' (das Labor nachgebildet, ohne Bremse) und je Budget eine Welt A' (Kopie von B' vor der ersten Sperre, Tor mit der Stufenreihe
    des Budgets) über [t_von, t_bis) im Takt `takt`. Beide sehen je Takt nur Daten bis zu dessen Zeit; A' rechnet mit dem Marktzustand von
    B' (E_von), wie im Dashboard. -> Ergebnis je Budget: D = A' − B' gesamt, im Fenster, je Episode (+ 24 h), je Strategie, gesperrte
    Vorgänge; dazu B' gegen das echte TradeLabor (Nachbildung) und die Laufzeit.
    """
    import hl_forecast as F
    import hl_labor as LB
    RueckLabor = _labor_klasse()
    t_start = time.time()
    coins = tuple(coins or LB.COINS)
    if nur is None:
        nur, aus = strategien_rueck()
    else:
        aus = {}
    tmp = tempfile.mkdtemp(prefix="nb_rueckwaerts_", dir=os.path.dirname(os.path.abspath(db)))
    af = os.path.join(tmp, "ohne_adressfluss.db")                       # fehlt: Adressstrom aus (twap_druck ist nicht nachgebildet)
    out = {"t_von": t_von, "nur": nur, "aus": aus, "takt": takt, "A": {}, "abgebrochen": None}
    try:
        sp_b = os.path.join(tmp, "welt_b.db"); F.store_connect(sp_b).close()
        B = RueckLabor(db, sp_b, store_echt, coins=coins, nur=nur, adressfluss=af, swing=swing)
        zeilen = {b: [(int(S["t0"] + 60 * k), int(s), "Rückblick") for k, s in enumerate(S["stufe"])] for b, S in stufen.items()}
        erst = {b: erste_sperre(S, t_von, t_bis) for b, S in stufen.items()}
        A: dict = {}; t_a: dict = {}
        ticks = list(range((t_von // takt + 1) * takt, t_bis, takt))
        t_prev = None; n = 0; melde = max(1, len(ticks) // 10)
        for t in ticks:
            for b, f in erst.items():                                    # Welt A' anlegen: Kopie nach dem letzten Takt vor der Sperre
                if b not in A and f is not None and t_prev is not None and f <= t:
                    sp_a = os.path.join(tmp, f"welt_a{b}.db")
                    NB.welt_a_anlegen(sp_b, sp_a, t_prev, {})
                    LA = RueckLabor(db, sp_a, store_echt, coins=coins, nur=nur, adressfluss=af, swing=swing, welt="A",
                                    tor=TorRueck(zeilen[b], t_prev))
                    LA.z = copy.deepcopy(B.z); A[b] = LA; t_a[b] = t_prev
            B.zyklus(t)
            for b, LA in A.items():
                LA.zyklus(t, E_von=B.letzte)
            t_prev = t; n += 1
            if n % melde == 0:
                ausgabe(f"   … {n * 100 // len(ticks)} % (bis {_utc(t)}), {(time.time() - t_start) / 60:.0f} min")
            if time.time() - t_start > max_s:
                out["abgebrochen"] = f"nach {(time.time() - t_start) / 3600:.1f} h (Zeitbudget) bei {_utc(t)}"
                break
        t_end = t_prev
        out.update(t_end=t_end, takte=n, dauer_s=round(time.time() - t_start), fehler_b=B.fehler[-3:])
        if t_end is None:
            return out
        cm = _ro(db)
        try:
            out["B"] = {"ende": NB.summe_zu(sp_b, cm, t_end), "n": _anzahl(sp_b), "pruef": _pruefsumme(sp_b)}
            sb_ = _ro(sp_b)
            try:
                out["kaskaden"] = int(sb_.execute("SELECT COUNT(*) FROM labor_ereignis WHERE art='kaskade'").fetchone()[0])
            finally:
                sb_.close()
            je_b = summe_je_sid(sp_b, cm, t_end)
            for b, LA in A.items():
                sp_a = LA.store; ta = t_a[b]

                def d_fenster(a0, a1):
                    a1 = min(a1, t_end)
                    if a1 <= a0:
                        return None
                    b0, b1 = NB.summe_zu(sp_b, cm, a0), NB.summe_zu(sp_b, cm, a1)
                    x0 = NB.summe_zu(sp_a, cm, a0) if a0 >= ta else b0
                    x1 = NB.summe_zu(sp_a, cm, a1)
                    return None if None in (b0, b1, x0, x1) else (x1 - x0) - (b1 - b0)
                eps = []
                for e in stufen[b]["episoden"]:
                    if e["start"] < ta or e["start"] >= t_end:
                        continue
                    ende = e["ende"] if e["ende"] is not None else t_end
                    eps.append(dict(e, d=d_fenster(e["start"], ende + TAG), bis=min(ende + TAG, t_end)))
                je_a = summe_je_sid(sp_a, cm, t_end)
                je = {s: round(je_a.get(s, [0, 0.0])[1] - je_b.get(s, [0, 0.0])[1], 2) for s in set(je_a) | set(je_b)}
                gesperrt: dict = {}
                for x in LA.tor.alle:
                    gesperrt[x[5]] = gesperrt.get(x[5], 0) + 1
                out["A"][b] = {"t_a": ta, "ende": NB.summe_zu(sp_a, cm, t_end), "d": d_fenster(ta, t_end),
                               "longs_in_sperre": _longs_in_sperre(sp_a, stufen[b], ta), "longs_in_sperre_b": _longs_in_sperre(sp_b, stufen[b], ta),
                               "d_fenster": d_fenster(max(fenster[0], ta), fenster[1]) if fenster and fenster[1] > ta else (0.0 if fenster else None),
                               "episoden": eps, "je_sid": {k: v for k, v in je.items() if abs(v) >= 0.5}, "gesperrt": gesperrt,
                               "zaehler": dict(LA.tor.zaehler), "fehler": LA.fehler[-3:], "n": _anzahl(sp_a)}
            for b in stufen:
                if b not in out["A"]:
                    out["A"][b] = {"t_a": None, "d": 0.0, "d_fenster": 0.0 if fenster else None, "episoden": [], "je_sid": {}, "gesperrt": {},
                                   "zaehler": {}, "fehler": [], "keine_sperre": True}
            # Nachbildung: B' gegen das echte TradeLabor -- je Strategie die ab t_von eröffneten Positionen, bewertet zur Zeit t_end
            echt = summe_je_sid(store_echt, cm, t_end, von_eroeffnet=t_von)
            nach = summe_je_sid(sp_b, cm, t_end, von_eroeffnet=t_von)
            sids = {s["sid"]: s["name"] for s in LB.strategien() if s["name"] in nur}
            out["nachbildung"] = {sids[s]: (echt.get(s, [0, 0.0]), nach.get(s, [0, 0.0])) for s in sids}
        finally:
            cm.close()
        out["daten_ab"] = _daten_ab(db, store_echt, coins)
        return out
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _pruefsumme(store: str) -> str:
    """Prüfsumme über Positionen, Orders und Akku-Käufe einer Welt (Kausalitätsprobe; gleiche Rechnung → gleiche Summe)."""
    import hashlib
    h = hashlib.sha1()
    con = _ro(store)
    try:
        for q in ("SELECT sid, coin, seite, status, eroeffnet, preis_ein, menge, art_ein, sl, tp, ablauf, geschlossen, preis_aus, netto_usd, funding "
                  "FROM labor_position ORDER BY id", "SELECT sid, coin, seite, preis, erstellt, status, erledigt FROM labor_order ORDER BY id",
                  "SELECT sid, coin, ts, usd, menge FROM labor_akku_kauf ORDER BY id"):
            try:
                for r in con.execute(q):
                    h.update(repr(tuple(r)).encode())
            except sqlite3.Error:
                h.update(b"-")
    finally:
        con.close()
    return h.hexdigest()[:12]


def _longs_in_sperre(store: str, S: dict, ab: int) -> int:
    """Longs (Positionen und Akku-Käufe), die ab `ab` in einer Minute mit Stufe ≥ 1 eröffnet wurden."""
    con = _ro(store); n = 0
    try:
        zeiten = [int(r[0]) for r in con.execute("SELECT eroeffnet FROM labor_position WHERE seite='long' AND eroeffnet>=?", (int(ab),))]
        try:
            zeiten += [int(r[0]) for r in con.execute("SELECT ts FROM labor_akku_kauf WHERE ts>=?", (int(ab),))]
        except sqlite3.Error:
            pass
    finally:
        con.close()
    for e in zeiten:
        k = (e - int(S["t0"])) // 60
        if 0 <= k < len(S["stufe"]) and S["stufe"][k] >= 1:
            n += 1
    return n


def _anzahl(store: str) -> int:
    con = _ro(store)
    try:
        return int(con.execute("SELECT COUNT(*) FROM labor_position").fetchone()[0])
    finally:
        con.close()


def rueckwaerts_text(L: dict, schwellen: dict, fenster_text: str) -> list:
    z = [f"   Zeitraum {_utc(L['t_von'])} bis {_utc(L.get('t_end'))}, Takt {L['takt']} s, {L.get('takte', 0)} Takte, Laufzeit "
         f"{(L.get('dauer_s') or 0) / 60:.0f} min" + (f" -- ABGEBROCHEN {L['abgebrochen']}" if L.get("abgebrochen") else "")]
    z.append(f"   Nachgebildet: {len(L['nur'])} Strategien; nicht nachgebildet: "
             + ("; ".join(f"{n} ({g})" for n, g in sorted(L["aus"].items())) or "keine"))
    da = L.get("daten_ab") or {}
    if da:
        z.append("   Daten ab (der späteste Coin): " + " · ".join(f"{QUELLE_NAME.get(k, k)} {_utc(v)}" for k, v in da.items() if v)
                 + " -- vorher handeln die Strategien mit dieser Eingabe nicht (in beiden Welten gleich)")
    if L.get("fehler_b"):
        z.append(f"   Fehler in B': {L['fehler_b']}")
    B = L.get("B") or {}
    z.append(f"   Welt B' (nachgebildet, ohne Bremse): Ergebnis {_usd(B.get('ende'))} USD, {B.get('n', 0)} Positionen")
    for b in sorted(L["A"]):
        a = L["A"][b]; th = schwellen.get(b) or {}
        if a.get("keine_sperre"):
            z.append(f"   Budget {b} (θ1 {_z(th.get('theta1'))}): keine Sperre im Zeitraum -- A' = B'")
            continue
        gs = " · ".join(f"{k} {v}" for k, v in sorted(a["gesperrt"].items()))
        z.append(f"   Budget {b} (θ1 {_z(th.get('theta1'))}, θ2X {_z(th.get('theta2x'))}, θ2Y {_z(th.get('theta2y'))}): Welt A' ab {_utc(a['t_a'])}, "
                 f"D = A' − B' gesamt {_usd(a['d'])} USD, {fenster_text} {_usd(a['d_fenster'])} USD; protokolliert {gs or 'nichts'} "
                 f"(gesperrt {a['zaehler'].get('gesperrt', 0)}, storniert {a['zaehler'].get('storniert', 0)})"
                 + (f"; Fehler {a['fehler']}" if a.get("fehler") else ""))
        for e in a["episoden"][:12]:
            z.append(f"      Episode {_utc(e['start'])}–{_utc(e['ende']) if e['ende'] else 'läuft'} (Stufe {e['stufe_max']}, "
                     f"{NB.QUELLE_NAME.get(e['quelle'], e['quelle'])}): D bis {_utc(e['bis'])} {_usd(e['d'])} USD")
        grosse = sorted(a["je_sid"].items(), key=lambda kv: kv[1])
        auswahl = list(dict.fromkeys(grosse[:5] + grosse[-3:]))
        if auswahl:
            z.append("      je Strategie (A' − B', die größten Beträge): " + " · ".join(f"{k.split('@')[0]} {_usd(v)}" for k, v in auswahl))
    nb_ = L.get("nachbildung") or {}
    if nb_:
        e_n = sum(v[0][0] for v in nb_.values()); e_u = sum(v[0][1] for v in nb_.values())
        n_n = sum(v[1][0] for v in nb_.values()); n_u = sum(v[1][1] for v in nb_.values())
        z.append(f"   Nachbildung (ab {_utc(L['t_von'])} eröffnete Positionen, bewertet am Ende): echtes TradeLabor {e_n} Positionen {_usd(e_u)} USD · "
                 f"B' {n_n} Positionen {_usd(n_u)} USD. Abweichungen sind zu erwarten (Takt {L['takt']} s statt 15 s, Start ohne Bestand, "
                 "Strategien erst ab ihrer Regelversion im echten Labor)")
        abw = sorted(nb_.items(), key=lambda kv: -abs(kv[1][1][1] - kv[1][0][1]))[:6]
        z.append("      größte Abweichungen (echt / B'): " + " · ".join(f"{k} {v[0][0]}/{v[1][0]} Pos. {_usd(v[0][1])}/{_usd(v[1][1])}" for k, v in abw))
    return z


# --------------------------------------------------------------------------------------------- Positivkontrollen (data.binance.vision)
def _netz_bytes(url: str):
    d, err, status = NB.AK.http(url, timeout=90, art="bytes", kopf=BINANCE_UA)
    return d, err, status


def binance_lesen(roh: bytes) -> tuple:
    """1-min-Kerzen aus einer Monatsdatei von data.binance.vision (ZIP mit einer CSV; mit oder ohne Kopfzeile; Zeit in ms oder µs).
    Nur Zahlen werden übernommen. -> (ts in s, Schlusskurse)"""
    with zipfile.ZipFile(io.BytesIO(roh)) as z:
        namen = [n for n in z.namelist() if n.lower().endswith(".csv")]
        if not namen:
            raise ValueError("keine CSV im ZIP")
        text = z.read(namen[0]).decode("utf-8", "replace")
    ts, c = [], []
    for row in csv.reader(io.StringIO(text)):
        if len(row) < 5:
            continue
        try:
            t = int(float(row[0])); px = float(row[4])
        except ValueError:
            continue                                                        # Kopfzeile
        if t > 1e14:
            t //= 1_000_000
        elif t > 1e11:
            t //= 1000
        if px > 0 and math.isfinite(px):
            ts.append(t); c.append(px)
    a = np.array(ts, dtype=np.int64); b = np.array(c, dtype=float)
    o = np.argsort(a)
    return a[o], b[o]


def binance_monat(sym: str, j: int, m: int, ordner: str, http=None) -> tuple:
    """(ts, c, Fehler) eines Monats; verdichtet zwischengespeichert (npz), damit ein zweiter Lauf nichts lädt."""
    p = os.path.join(ordner, f"{sym}-{j:04d}-{m:02d}.npz")
    if os.path.exists(p):
        with np.load(p) as f:
            return f["ts"], f["c"], None
    d, err, status = (http or _netz_bytes)(BINANCE_URL.format(s=sym, j=j, m=m))
    if err or not d:
        return None, None, err or f"leer (HTTP {status})"
    try:
        ts, c = binance_lesen(d)
    except (ValueError, zipfile.BadZipFile) as e:
        return None, None, f"{type(e).__name__}: {e}"
    os.makedirs(ordner, exist_ok=True)
    np.savez_compressed(p, ts=ts, c=c)
    return ts, c, None


def positivkontrolle(tag: date, coins: list, th: dict, ordner: str, http=None) -> dict:
    """Ein Ereignis (KONZEPT 10.4): 1-min-Kurse der Perps der Coins vom Vortag 00:00 bis zum Folgetag 23:59 UTC, σ je Tag aus den 30 Tagen
    davor (Zeitklassen wie live), Y = min über 5/15/60 min von G(K); kleinstes Y und die erste Minute mit Y ≤ θ1 und mit Y ≤ θ2Y.
    Nur Krypto, ohne Liquidationen (beschreibend)."""
    t_a = int(datetime(tag.year, tag.month, tag.day, tzinfo=UTC).timestamp()) - TAG          # Vortag 00:00
    t_e = t_a + 3 * TAG
    t_s = t_a - (NB.SIGMA_TAGE + 1) * TAG
    monate = sorted({(d.year, d.month) for d in (datetime.fromtimestamp(t, UTC) for t in range(t_s, t_e, TAG))})
    daten, fehlt = {}, {}
    for c in coins:
        sym = f"{c.upper()}USDT"
        ts_l, c_l = [], []
        for j, m in monate:
            ts, cc, err = binance_monat(sym, j, m, ordner, http)
            if err:
                fehlt[c] = err[:60]; ts_l = []; break
            ts_l.append(ts); c_l.append(cc)
        if ts_l:
            daten[c] = (np.concatenate(ts_l), np.concatenate(c_l))
    t_k0 = t_a - NB.SIGMA_TAGE * TAG - 900
    nk = (t_e - t_k0) // 900
    P15, P1 = {}, {}
    n1 = (t_e - t_a) // 60
    for c, (ts, cc) in daten.items():
        a15 = np.full(nk, np.nan)
        m15 = (ts % 900 == 840) & (ts >= t_k0) & (ts < t_e)                  # Schluss der letzten Minute eines 15-min-Intervalls
        k = (ts[m15] - 840 - t_k0) // 900
        a15[k] = cc[m15]
        P15[c] = a15
        a1 = np.full(n1, np.nan)
        m1 = (ts >= t_a - 60) & (ts < t_e - 60)
        k1 = (ts[m1] + 60 - t_a) // 60                                        # Kurs zur Zeit T = Schluss der Minute T − 60
        a1[k1] = cc[m1]
        P1[c] = NB._ffill(a1, NB.PREIS_MAX_ALTER // 60)
        anteil = float(np.mean(np.isfinite(P1[c])))
        if anteil < 0.9:                                                      # Kurse decken das Fenster nicht (Lücke, falsche Zeiteinheit)
            fehlt[c] = f"nur {anteil:.0%} der Minuten im Fenster"
            P15.pop(c, None); P1.pop(c, None)
    out = {"tag": tag, "coins": sorted(P1), "fehlt": fehlt}
    if len(P1) < NB.K_MIN:
        out["grund"] = f"nur {len(P1)} Coins mit Daten (mindestens {NB.K_MIN})"
        return out
    gr = {"K": sorted(P1)}
    V = NB.sigma_reihe(t_k0, P15, [t_a, t_a + TAG, t_a + 2 * TAG], NB.SIGMA_TAGE, None, gr)
    R = NB.reihe_masse(t_a, 60, P1, gr, V, NB.FENSTER_Y1)
    Y = R["Y"]; T = R["T"]
    if not np.any(np.isfinite(Y)):
        out["grund"] = "kein gültiges Y (σ fehlt)"
        return out
    k = int(np.nanargmin(Y))
    out.update(y_min=float(Y[k]), t_min=int(T[k]))
    for name, g in (("theta1", th["theta1"]), ("theta2y", th["theta2y"])):
        idx = np.nonzero(np.isfinite(Y) & (Y <= g))[0]
        out[f"t_{name}"] = int(T[idx[0]]) if len(idx) else None
    return out


# --------------------------------------------------------------------------------------------- Kurzbericht (Standard)
def kurz(db: str, store_b: str) -> None:
    nb = NB.nb_pfad(db)
    with abschnitt(f"NOTBREMSE -- Stand {datetime.now(UTC):%d.%m.%Y %H:%M} UTC ({NB.FASSUNG}) · {nb}"):
        store_a = NB.labor_a_pfad(store_b)
        preise = {}
        try:
            cm = _ro(db)
            try:
                import hl_labor as LB
                for c in LB.COINS:
                    px = NB._kurs_zu(cm, c, int(time.time()) + 60)
                    if px:
                        preise[c] = px
            finally:
                cm.close()
        except sqlite3.Error:
            pass
        for zeile in NB.bericht_zeilen(db, store_b, store_a if os.path.exists(store_a) else None, preise):
            w("   " + zeile)
    if not os.path.exists(nb):
        return
    con = _ro(nb)
    try:
        with abschnitt("Korb, Historie, Takt"):
            korb = NB.meta_lesen(con, "korb") or {}
            w(f"   Korb {_utc(korb.get('ts'))}: Krypto K ({len(korb.get('K') or [])}): {', '.join(korb.get('K') or [])}")
            w(f"   Aktien A ({len(korb.get('A') or [])}): {', '.join(korb.get('A') or [])} · Anzeige: {', '.join(korb.get('anzeige') or [])} · "
              f"Dex: {korb.get('dex')}" + (f" · Hinweise: {korb['hinweise']}" if korb.get("hinweise") else ""))
            h = NB.meta_lesen(con, "historie") or {}
            w(f"   Historie: {'fertig ' + _utc(h.get('fertig_ts')) if h.get('fertig') else 'läuft'} -- 15-min-Kerzen {len(h.get('15m') or [])}, "
              f"1-min-Kerzen {len(h.get('1m') or [])} Instrumente; Zeilen je Abruf: "
              + ", ".join(f"{k} {v}" for k, v in sorted((h.get("n") or {}).items())[:40]))
            tk = NB.meta_lesen(con, "takt") or {}
            w(f"   Takt {_utc(tk.get('ts'))}: {tk.get('zaehler')} · Gewicht der letzten 60 s {tk.get('gewicht_60s')} · Fehler {tk.get('fehler') or 'keiner'}")
            for tab in ("nb_preis", "nb_kerze15"):
                r = con.execute(f"SELECT COUNT(*), MIN(ts), MAX(ts) FROM {tab}").fetchone()
                w(f"   {tab}: {r[0]:,} Zeilen, {_utc(r[1])} bis {_utc(r[2])}".replace(",", "."))
            for inst, n, a, b in con.execute("SELECT inst, COUNT(*), MIN(ts), MAX(ts) FROM nb_kerze15 GROUP BY inst ORDER BY inst"):
                w(f"      {inst}: {n} Schlüsse {_datum(a)}–{_utc(b)}")
        with abschnitt("Kalibrierungen (nb_schwellen)"):
            for r in con.execute("SELECT gueltig_ab, theta1, theta2x, theta2y, zeitraum, klammer_json, info_json FROM nb_schwellen ORDER BY gueltig_ab"):
                info = json.loads(r[6] or "{}")
                w(f"   ab {_utc(r[0])}: θ1 {_z(r[1])}, θ2X {_z(r[2])}, θ2Y {_z(r[3])} · {info.get('quelle')} ({'erste' if info.get('erste') else 'monatlich'}), "
                  f"Zeitraum {r[4]}, X {info.get('zeitraum_x')} Tage, Y {info.get('zeitraum_y')} Tage mit {info.get('eigene_coins')} eigenen Coins, "
                  f"Klammer {json.loads(r[5] or '[]') or 'keine'}, Episoden je 30 Tage: S1X {(info.get('s1x') or {}).get('je30')}, "
                  f"S2X {(info.get('s2x') or {}).get('je30')}, S2Y {(info.get('s2y') or {}).get('je30')}; {info.get('dauer_s')} s"
                  + (f"; {info.get('grund')}" if info.get("grund") else ""))
        with abschnitt("Episoden (alle) und gesperrte Vorgänge"):
            for r in con.execute("SELECT id, start, ende, stufe_max, ausloeser, gesperrt_n, storniert_n, d_usd, spiegel FROM nb_episode ORDER BY start"):
                w(f"   #{r[0]} {'Spiegel ' if r[8] else ''}{_utc(r[1])}–{_utc(r[2]) if r[2] else 'läuft'}: Stufe {r[3]}, {r[4]}, gesperrt {r[5]}, "
                  f"storniert {r[6]}" + (f", D {_usd(r[7])} USD" if r[7] is not None else ""))
            for r in con.execute("SELECT welt, art, COUNT(*), MIN(ts), MAX(ts) FROM nb_blockiert GROUP BY welt, art"):
                w(f"   nb_blockiert Welt {r[0]} {r[1]}: {r[2]} ({_utc(r[3])} bis {_utc(r[4])})")
            v = NB.audit_zeiten(nb)
            w("   Zeitstempel (Audit): " + ("in Sekunden" if not v else "; ".join(v)))
    finally:
        con.close()


# --------------------------------------------------------------------------------------------- Rückblick und Zerlegung
def _tag_lesen(s: str) -> tuple:
    d = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=UTC)
    tag = int(d.timestamp())
    return tag, tag - 12 * 3600, tag + TAG + 12 * 3600                    # Tag, Fenster 12:00 des Vortags bis 12:00 des Folgetags


def rueckblick(db: str, store_b: str, tag_s: str, nur_zerlegung: bool = False, mit_labor: bool = True, mit_binance: bool = True,
               takt: int = 300, max_s: float = 8 * 3600) -> None:
    t_ges = time.time()
    nb = NB.nb_pfad(db)
    w(f"{'ZERLEGUNG' if nur_zerlegung else 'RÜCKBLICK'} NOTBREMSE ({NB.FASSUNG}, KONZEPT 10.4 und Schritt 0) -- {datetime.now(UTC):%d.%m.%Y %H:%M} UTC")
    w(f"   Hauptdatenbank {db} · notbremse.db {nb} · Welt B {store_b}")
    if not os.path.exists(nb):
        w("   notbremse.db fehlt -- der Dienst hl-notbremse ist noch nicht gelaufen (er holt zuerst die Historie)."); return
    tag, w0, w1 = _tag_lesen(tag_s)
    con_nb = _ro(nb); cm = _ro(db)
    R = SE = None
    try:
        gruppen, korb = gruppen_lesen(con_nb)
        hist = NB.meta_lesen(con_nb, "historie") or {}
        with abschnitt("1. Daten und Reihen"):
            w(f"   Korb: K {len(gruppen['K'])} ({', '.join(gruppen['K'])}), A {len(gruppen['A'])} ({', '.join(gruppen['A'])}); Historie "
              f"{'fertig' if hist.get('fertig') else 'NOCH NICHT FERTIG -- Ergebnis vorläufig'}")
            R = retro_reihen(con_nb, cm, gruppen)
            if R is None:
                w("   keine 15-min-Schlüsse in nb_kerze15 (oder weniger als 11 Tage) -- nichts zu rechnen")
            else:
                X, Y = R["X_reihe"], R["Y_reihe"]
                w(f"   Zeitraum {_utc(R['start'])} bis {_utc(R['ende'])}: X auf dem 15-min-Raster an {_z(X['tage'], 1)} Tagen gültig, Y auf dem "
                  f"1-min-Raster ({R['eigene']} eigene Coins) an {_z(Y['tage'] if Y else 0, 1)} Tagen; σ wie bei der ersten Kalibrierung (ab 10 Tagen)")
        if R is None:
            return
        X = R["X_reihe"]
        with abschnitt("2. Schwellen der ersten Kalibrierung (Daten bis 20.10. 23:59 UTC; der 22.10. bleibt ungesehen)"):
            SE = schwellen_erste(con_nb, cm, gruppen)
            erg = SE["erg"]
            w(f"   Kalibrierungszeitraum {erg.get('zeitraum')}: X {erg.get('zeitraum_x')} Tage, Y {erg.get('zeitraum_y')} Tage ({erg.get('eigene')} "
              "eigene Coins)")
            for b in BUDGETS:
                k = SE["je"][b]; inf = k.get("info") or {}
                w(f"   Budget {b}: θ1 {_z(k['theta1'])}, θ2X {_z(k['theta2x'])}, θ2Y {_z(k['theta2y'])} ({k['quelle']}"
                  + (f", an der Klammer: {', '.join(k['klammer'])}" if k.get("klammer") else "") + f"); Episoden je 30 Tage in der Kalibrierung: "
                  f"S1X {_z((inf.get('s1x') or {}).get('je30'))}, S2X {_z((inf.get('s2x') or {}).get('je30'))}, S2Y {_z((inf.get('s2y') or {}).get('je30'))}"
                  + (f"; {inf.get('grund')}" if inf.get("grund") else ""))
            g = SE["gespeichert"]
            th4 = _th(SE["je"][4])
            if g:
                gleich = all(abs(float(g[k]) - th4[k]) < 1e-9 for k in th4)
                w(f"   Gespeicherte erste Kalibrierung des Dienstes (ab {_utc(g['gueltig_ab'])}): θ1 {_z(g['theta1'])}, θ2X {_z(g['theta2x'])}, θ2Y "
                  f"{_z(g['theta2y'])} -- {'gleich der Neurechnung' if gleich else 'ABWEICHEND von der Neurechnung (Korb geändert?); der Rückblick nimmt die gespeicherte'}")
                th4 = {k: float(g[k]) for k in th4}
            else:
                w("   Noch keine gespeicherte Kalibrierung des Dienstes -- der Rückblick nimmt die Neurechnung mit Budget 4")
            SE["th4"] = th4
        if SE is None or "th4" not in SE:
            w("   ohne Schwellen kein Rückblick"); return
        schwellen = {b: _th(SE["je"][b]) for b in BUDGETS}
        schwellen[4] = SE["th4"]
        stufen = {b: retro_stufen(R, schwellen[b]) for b in BUDGETS}
        if not nur_zerlegung:
            with abschnitt("3. Stufen im Rückblick mit den Schwellen der ersten Kalibrierung (Budget 4)"):
                S = stufen[4]; eps = S["episoden"]; tage = len(S["stufe"]) / 1440
                n2 = sum(1 for e in eps if e["stufe_max"] >= 2)
                qn: dict = {}
                for e in eps:
                    qn[e["quelle"]] = qn.get(e["quelle"], 0) + 1
                w(f"   {len(eps)} Episoden in {_z(tage, 1)} Tagen ({_z(len(eps) * 30 / max(tage, 1e-9), 1)} je 30 Tage; Budget 4), davon Stufe 2: {n2}; "
                  f"Auslöser: " + (", ".join(f"{NB.QUELLE_NAME.get(k, k)} {v}" for k, v in qn.items()) or "—")
                  + f"; gesperrte Zeit {_z(100 * float(np.mean(S['stufe'] >= 1)) if len(S['stufe']) else 0, 2)} %")
                for e in eps:
                    dauer = ((e["ende"] or S["t1"]) - e["start"]) / 60
                    w(f"      {_utc(e['start'])}–{_utc(e['ende']) if e['ende'] else 'läuft'} ({dauer:.0f} min): Stufe {e['stufe_max']}, "
                      f"{NB.QUELLE_NAME.get(e['quelle'], e['quelle'])}; bei Beginn X {_z(e['x'])} · Y {_z(e['y'])} · Λ {_z((e['lam'] or 0) * 100, 1) if e['lam'] is not None else '—'} %")
                w("   Hinweis: X im Rückblick nur auf dem 15-min-Raster (wie die Kalibrierung); live prüft der Dienst jede Minute.")
            tabelle = _empfindlichkeit(stufen, schwellen, tag, w0, w1, None)
            with abschnitt("4. Empfindlichkeit (Budget der Stufe 1: 2, 4, 8 Episoden je 30 Tage; D folgt nach dem Rückwärtstest)"):
                for zz in tabelle:
                    w(zz)
        with abschnitt(f"5. Zerlegung des {datetime.fromtimestamp(tag, UTC):%d.%m.%Y} (Schritt 0, Welt B)"):
            t0, fall = t0_bestimmen(stufen, X, tag, w0, w1)
            Z = zerlegung(store_b, cm, t0, w0, w1)
            for zz in zerlegung_text(Z, fall):
                w(zz)
        if nur_zerlegung:
            return
        L = None
        if mit_labor:
            with abschnitt(f"6. Labor-Rückwärtstest Welt A' gegen Welt B' (Takt {takt} s, Zeitbudget {max_s / 3600:.1f} h)"):
                L = labor_rueckwaerts(db, store_b, stufen, R["start"], R["ende"], takt, max_s, fenster=(w0, w1))
                for zz in rueckwaerts_text(L, schwellen, f"im Fenster {datetime.fromtimestamp(tag, UTC):%d.%m.}"):
                    w(zz)
            with abschnitt("4. Empfindlichkeit, vollständig (mit D aus dem Rückwärtstest)"):
                for zz in _empfindlichkeit(stufen, schwellen, tag, w0, w1, L):
                    w(zz)
        if mit_binance:
            with abschnitt("7. Historische Positivkontrollen (data.binance.vision, nur Krypto, ohne Liquidationen, beschreibend)"):
                ordner = os.path.join(os.path.dirname(os.path.abspath(db)), "notbremse_binance")
                th = schwellen[4]
                coins = list(korb.get("K") or NB.EIGENE)
                w(f"   Coins des Korbs: {', '.join(coins)}; Schwellen der ersten Kalibrierung θ1 {_z(th['theta1'])}, θ2Y {_z(th['theta2y'])}")
                for tg, text in EREIGNISSE:
                    P = positivkontrolle(tg, coins, th, ordner)
                    kopf = f"   {tg:%d.%m.%Y} ({text}): "
                    if P.get("grund"):
                        w(kopf + P["grund"] + (f"; fehlt: {P['fehlt']}" if P["fehlt"] else "")); continue
                    w(kopf + f"{len(P['coins'])} Coins ({', '.join(P['coins'])}); kleinstes Y {_z(P['y_min'])} σ um {_utc(P['t_min'])}; Y ≤ θ1 "
                      f"erstmals {_utc(P['t_theta1'])}; Y ≤ θ2Y erstmals {_utc(P['t_theta2y'])}" + (f"; fehlt: {P['fehlt']}" if P["fehlt"] else ""))
    finally:
        con_nb.close(); cm.close()
        w(); w(f"ENDE -- Laufzeit {(time.time() - t_ges) / 60:.1f} min · bitte vollständig einfügen")


def _empfindlichkeit(stufen: dict, schwellen: dict, tag: int, w0: int, w1: int, L: dict | None) -> list:
    z = ["   Budget  θ1      θ2X     θ2Y     Episoden (St. 2)  je 30 T  gesperrt  Auslösung am Tag       D gesamt     D im Fenster"]
    for b in BUDGETS:
        S = stufen[b]; th = schwellen[b]; eps = S["episoden"]; tage = len(S["stufe"]) / 1440
        n2 = sum(1 for e in eps if e["stufe_max"] >= 2)
        t_tag = erste_sperre(S, tag, tag + TAG)
        a = (L or {}).get("A", {}).get(b) if L else None
        d = _usd(a["d"]) if a else "—"; df = _usd(a["d_fenster"]) if a else "—"
        z.append(f"   {b:>6}  {_z(th['theta1']):>6}  {_z(th['theta2x']):>6}  {_z(th['theta2y']):>6}  {len(eps):>8} ({n2:>2})      "
                 f"{_z(len(eps) * 30 / max(tage, 1e-9), 1):>6}  {_z(100 * float(np.mean(S['stufe'] >= 1)) if len(S['stufe']) else 0, 2):>6} %  "
                 f"{(_utc(t_tag) if t_tag else 'keine'):>20}  {d:>11}  {df:>11}")
    z.append(f"   „Auslösung am Tag“: erste Minute mit Stufe ≥ 1 am {datetime.fromtimestamp(tag, UTC):%d.%m.} (UTC); „D im Fenster“: "
             f"{_utc(w0)} bis {_utc(w1)}. Die Wahl des Budgets ist eine Risikoentscheidung, kein statistisches Urteil (Vorgabe 4).")
    return z


# ============================================================================================= Selbsttest
def _bars_db(pfad: str, kurse: dict, t0: int, n: int) -> None:
    """Hauptdatenbank mit Minutenkerzen (Schluss je Minute aus kurse[coin](k)) und leerer Tabelle liquidations."""
    con = sqlite3.connect(pfad)
    con.executescript("CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, "
                      "PRIMARY KEY (ts, coin)); CREATE TABLE IF NOT EXISTS liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, "
                      "px REAL, sz REAL, side TEXT, tid INTEGER PRIMARY KEY); CREATE INDEX IF NOT EXISTS ix_liq_coin_ts ON liquidations(coin, ts);")
    rows = []
    for coin, f in kurse.items():
        for k in range(n):
            c = f(k)
            rows.append((t0 + 60 * k, coin, c, c, c, c, 1.0, 1))
    con.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.commit(); con.close()


def _probe_zerlegung(tmp: str, ok) -> None:
    """Teile von Hand: jede Art von Position in ihrem Teil, Summe der Teile = Netto über den zweiten Rechenweg."""
    import hl_forecast as F
    import hl_labor as LB
    T0 = 1_790_000_000 // TAG * TAG
    db = os.path.join(tmp, "z_m.db")
    _bars_db(db, {"AAA": lambda k: 100.0 + 0.01 * k - (5.0 if k >= 1500 else 0.0), "BBB": lambda k: 50.0}, T0, 3 * 1440)
    sp = os.path.join(tmp, "z_b.db"); F.store_connect(sp).close()
    st = sqlite3.connect(sp); LB.schema(st)
    w0, w1, t0 = T0 + 12 * 3600, T0 + 60 * 3600, T0 + 1500 * 60            # t0 = Minute 1500 (Kurssprung −5)

    def pos(sid, coin, seite, ein, zu=None, preis=100.0, art="Markt (Taker)", netto=None):
        nt = 10_000.0; menge = nt / preis
        cur = st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, preis_ein, notional, menge, art_ein, gebuehr_ein, slip_ein, "
                         "funding, geschlossen, netto_usd) VALUES (?,?,?,?,?,?,?,?,?,?,0,0,?,?)",
                         (sid, coin, seite, "geschlossen" if zu else "offen", ein, preis, nt, menge, art, nt * 0.00045, zu, netto))
        return cur.lastrowid
    erwartet = {}
    pos("halten_long@x", "AAA", "long", T0 + 3600, T0 + 7200, netto=-10.0)                        # vor dem Fenster zu: Beitrag 0
    erwartet["a"] = [pos("prognose_v1@x", "AAA", "long", T0 + 6 * 3600, T0 + 20 * 3600, netto=-40.0),   # vor w0 offen, im Fenster zu
                     pos("zufall@x", "AAA", "long", T0 + 14 * 3600)]                                   # im Fenster vor t0, offen bis w1
    erwartet["b"] = [pos("wale_folgen@x", "AAA", "long", t0 + 600, t0 + 4000, netto=25.0)]
    pb2 = pos("docht_fangen@x", "AAA", "long", t0 + 1200, art="Limit (Maker)")
    pc = pos("empfehlung_limit@x", "AAA", "long", t0 + 1800, art="Limit (Maker)")
    erwartet["b"].append(pb2); erwartet["c"] = [pc]
    st.execute("UPDATE labor_position SET preis_ein=?, menge=? WHERE id=?", (130.0, 10_000.0 / 130.0, pc))     # (c) von Hand nachgerechnet
    st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, status, erledigt, pos_id) VALUES ('docht_fangen@x','AAA','long',100,?, 'gefuellt',?,?)",
               (t0 + 300, t0 + 1200, pb2))
    st.execute("INSERT INTO labor_order (sid, coin, seite, preis, erstellt, status, erledigt, pos_id) VALUES ('empfehlung_limit@x','AAA','long',100,?, 'gefuellt',?,?)",
               (t0 - 3600, t0 + 1800, pc))
    erwartet["d"] = [pos("grid_long@x", "AAA", "long", t0 + 2400, art="Grid-Kauf (Maker)")]
    erwartet["e"] = [pos("kaskade_umkehr@x", "AAA", "short", t0 - 7200, t0 + 300, netto=55.0), pos("grid_short@x", "AAA", "short", t0 + 60)]
    pos("funding_extrem@x", "BBB", "long", w1 + 60)                                                     # nach dem Fenster: Beitrag 0
    st.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, usd, menge) VALUES ('akku@x','AAA',?,1000,10)", (t0 - 600,))
    st.execute("INSERT INTO labor_akku_kauf (sid, coin, ts, usd, menge) VALUES ('akku@x','AAA',?,1000,10.5)", (t0 + 900,))
    st.commit(); st.close()
    cm = _ro(db)
    try:
        Z = zerlegung(sp, cm, t0, w0, w1)
    finally:
        cm.close()
    n = {k: Z["teile"][k]["n"] for k in TEILE}
    soll = {"a": 3, "b": 3, "c": 1, "d": 1, "e": 2}                       # (a) mit dem Akku-Kauf vor t0, (b) mit dem Akku-Kauf danach
    unter_b = {k: v[1] for k, v in Z["teile"]["b"]["unter"].items()}
    px1 = 100.0 + 0.01 * ((w1 - T0) // 60 - 1) - 5.0                      # Schluss der letzten Minute vor w1
    menge = 10_000.0 / 130.0
    c_hand = (px1 - 130.0) * menge - 10_000.0 * 0.00045 - menge * px1 * LB.gebuehr("AAA", LB.GEB_TAKER)
    ok("Zerlegung: jede Position in ihrem Teil, Summe der Teile = Netto (zweiter Rechenweg), Teil (c) von Hand",
       n == soll and unter_b == {"Markt": 1, "Limit aus Order nach t0": 1, "Akkumulation": 1} and Z["gesamt"] is not None
       and abs(Z["summe"] - Z["gesamt"]) < 1e-6 and abs(Z["teile"]["c"]["usd"] - c_hand) < 1e-6,
       f"Anzahl je Teil {n} (soll {soll}), (b) {unter_b}; Summe {Z['summe']:.4f} gegen {Z['gesamt']:.4f} USD; (c) {Z['teile']['c']['usd']:.4f} "
       f"gegen {c_hand:.4f} von Hand")


def _probe_t0(ok) -> None:
    """t0: Fall 1 (Budget 4 löst aus), Fall 2 (nur Budget 8), Fall 3 (keine Sperre: kleinstes X am Tag)."""
    t0 = 1_790_000_000 // TAG * TAG; n = 3 * 1440
    tag = t0 + TAG; w0, w1 = tag - 12 * 3600, tag + TAG + 12 * 3600

    def S(k_an):
        s = np.zeros(n, dtype=np.int8)
        if k_an is not None:
            s[k_an:k_an + 30] = 1
        return {"t0": t0, "stufe": s, "episoden": []}
    T = t0 + 900 * np.arange(n // 15); Xr = np.zeros(len(T)); Xr[(tag - t0) // 900 + 70] = -1.9
    a = t0_bestimmen({2: S(None), 4: S(1440 + 600), 8: S(1440 + 500)}, {"T": T, "X": Xr}, tag, w0, w1)
    b = t0_bestimmen({2: S(None), 4: S(None), 8: S(1440 + 500)}, {"T": T, "X": Xr}, tag, w0, w1)
    c = t0_bestimmen({2: S(None), 4: S(None), 8: S(None)}, {"T": T, "X": Xr}, tag, w0, w1)
    ok("Zerlegung: t0 in den drei Fällen", a[0] == t0 + (1440 + 600) * 60 and a[1].startswith("Fall 1") and b[0] == t0 + (1440 + 500) * 60
       and b[1].startswith("Fall 2") and c[0] == tag + 70 * 900 and c[1].startswith("Fall 3"),
       f"{_utc(a[0])} {a[1][:6]} · {_utc(b[0])} {b[1][:6]} · {_utc(c[0])} {c[1][:6]}")


def _probe_retro(tmp: str, ok) -> None:
    """Rückblick-Stufen auf synthetischen Daten: ein Gleichlauf-Schock wird zur richtigen Zeit erkannt, ohne Schock keine Sperre in den
    Tagen davor; dieselben Reihen geben dieselben Schwellen wie die Kalibrierung des Dienstes."""
    t_start = int(datetime(2026, 8, 10, tzinfo=UTC).timestamp())
    tage = 46
    m = NB._synth(41, t_start, tage)
    K = [k for k in m if not k.startswith("xyz:")]; A = [k for k in m if k.startswith("xyz:")]
    eigene = list(NB.EIGENE)                                               # die eigenen Coins heißen im Rückblick wie im Dienst
    namen = dict(zip(K[:len(eigene)], eigene))
    m = {namen.get(k, k): v for k, v in m.items()}
    K = [namen.get(k, k) for k in K]
    tag_s = t_start + 44 * TAG                                             # Schocktag: Mittwoch, 23.09.2026 (Handelstag)
    s_beginn = NB.sitzung(NB._ny_datum(tag_s + 15 * 3600))[0]
    t_s = s_beginn + 90 * 60
    k0 = (t_s - t_start) // 60
    ts15 = np.arange(t_start, tag_s, 900, dtype=np.int64)                 # σ der Sitzung aus den 30 Tagen vor dem Schocktag (Regel des Dienstes)
    sg = NB.sigma_aus_kerzen({i: (ts15, p[(ts15 + 900 - t_start) // 60]) for i, p in m.items()}, tag_s, 30, None, {"K": K, "A": A})
    sig15 = {i: math.sqrt(15 * sg[(i, "S")][0]) for i in m}
    for i, p in m.items():
        for j in range(k0, len(p)):
            p[j] *= math.exp(-6 * sig15[i] * min(1.0, (j - k0) / 15))
    nbp = os.path.join(tmp, "r_nb.db"); dbp = os.path.join(tmp, "r_m.db")
    con = NB.verbinden(nbp)
    with NB.schreiben(con):
        con.executemany("INSERT INTO nb_kerze15 VALUES (?,?,?)", [(i, ts, float(p[(ts + 900 - t_start) // 60])) for i, p in m.items()
                                                                  for ts in range(t_start, t_start + tage * TAG - 900, 900)])
        NB.meta_setzen(con, {"korb": {"K": K, "A": A}})
    con.close()
    _bars_db(dbp, {c: (lambda k, p=m[c]: float(p[k + 1]) if k + 1 < len(p) else float(p[-1])) for c in eigene}, t_start, tage * 1440 - 1)
    NB._hauptdb_liq(dbp, t_start, t_start + tage * TAG)
    cn = _ro(nbp); cm = _ro(dbp)
    try:
        gruppen, _k = gruppen_lesen(cn)
        R = retro_reihen(cn, cm, gruppen, bis=t_s + 6 * 3600)
        S = retro_stufen(R, dict(NB.START))
        erg = NB.kalibrierung_aus_daten(cn, cm, gruppen, t_start + 40 * TAG - 1, erste=True)
        R2 = NB.reihen_aus_daten(cn, cm, gruppen, int(R["start"]), t_start + 40 * TAG, NB.ERSTE_KALIB_SIGMA_MIN_TAGE)
        k2 = NB.kalibrieren(R2["X_reihe"], R2["Y_reihe"])
    finally:
        cn.close(); cm.close()
    t_erst = erste_sperre(S, t_s - 6 * 3600, t_s + 6 * 3600)
    vor = erste_sperre(S, t_s - 6 * 3600, t_s)
    ok("Rückblick: Gleichlauf-Schock erkannt (15-min-Raster), ohne Schock keine Sperre in den 6 h davor",
       t_erst is not None and 0 <= t_erst - t_s <= 31 * 60 and vor is None,
       f"Schock {_utc(t_s)}, Sperre ab {_utc(t_erst)} ({(t_erst - t_s) // 60 if t_erst else '—'} min danach); Episoden im Rückblick {len(S['episoden'])}")
    ok("Rückblick: dieselben Reihen wie die Kalibrierung des Dienstes (gleiche Schwellen)",
       all(abs(erg["kal"][k] - k2[k]) < 1e-12 for k in ("theta1", "theta2x", "theta2y")),
       f"Dienst θ1 {_z(erg['kal']['theta1'])} θ2X {_z(erg['kal']['theta2x'])} θ2Y {_z(erg['kal']['theta2y'])} · Rückblick-Reihen θ1 {_z(k2['theta1'])}")


def _probe_rueckwaerts(tmp: str, ok) -> None:
    """Rückwärtstest des Labors auf dem Probemarkt des Labors: (1) Kausalität -- bis zur Schnittzeit dasselbe Ergebnis, ob die Daten danach
    vorhanden sind oder nicht; nach der Schnittzeit liegen Köder (riesige Liquidationen, die die Kaskaden-Schwelle verschieben würden, und ein
    Heatmap-Cluster), die ein Blick nach vorn sofort sichtbar machte; (2) Welt A' entsteht vor der Sperre und eröffnet darin keine Longs,
    B' bleibt gleich einem Lauf ohne Bremse."""
    import hl_forecast as F
    import hl_labor as LB
    T0 = 1_790_006_400 - 6 * 86_400
    db = os.path.join(tmp, "rw_m.db")
    info = LB._probe_datenbank(db, T0, 5)
    t_von = T0 + 86_400; t_cut = T0 + 4 * 86_400                          # nach der Kaskade (Tag 4, 05:00) und ihren Trades
    con = sqlite3.connect(db)                                              # dazu Hyperliquid-Liquidationen (Λ, Kaskade) über alle Tage
    con.executemany("INSERT INTO liquidations VALUES (?,?,?,?,?,?,?,?,?)", [(T0 + 1800 * k + 7, "AAA", "0x1", "event", 100.0, 100.0, 5.0 + (k % 7),
                                                                          "A" if k % 2 else "B", 10_000 + k) for k in range(5 * 48)])
    # Köder nach der Schnittzeit: alle 15 min 20 Mio Long-Liquidationen (über 5 % der 15-min-Summen: die Schwelle der Kaskade läge darüber,
    # die Kaskade am Tag 4 bliebe unerkannt) und ein großes Heatmap-Cluster dicht am Kurs
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", [(t_cut + 900 * k + 5, "AAA", "AAAUSDT", "long", 100.0, 2e5, 2e7)
                                                                           for k in range(96)])
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", [(t_cut + 600 * k, "AAA", info["kurs"][(t_cut + 600 * k) // 60 * 60] * 1.012, "short",
                                                                  9e6, 50) for k in range(100)])
    con.commit(); con.close()
    sp = os.path.join(tmp, "rw_store.db"); NB._labor_store(LB, F, sp, info, T0)
    nur = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "docht_fangen", "magnet", "kaskade_umkehr", "kaskade_fortsetzung", "zufall",
           "halten_long")
    # (1) Kausalität: Kopie der Daten, alles ab t_cut gelöscht
    db2 = os.path.join(tmp, "rw_m_cut.db"); sp2 = os.path.join(tmp, "rw_store_cut.db")
    for a_, b_ in ((db, db2), (sp, sp2)):
        s_ = sqlite3.connect(a_); d_ = sqlite3.connect(b_); s_.backup(d_); s_.close(); d_.close()
    c2 = sqlite3.connect(db2)
    for (tab,) in c2.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
        if any(r[1] == "ts" for r in c2.execute(f'PRAGMA table_info("{tab}")')):
            c2.execute(f'DELETE FROM "{tab}" WHERE ts >= ?', (t_cut,))
    c2.commit(); c2.close()
    c2 = sqlite3.connect(sp2)
    for tab in ("forecast", "forecast_drivers"):
        c2.execute(f'DELETE FROM "{tab}" WHERE ts >= ?', (t_cut,))
    c2.commit(); c2.close()
    n = (t_cut - t_von + 7200) // 60; t0r = t_von - 3600
    leer = {2: {"t0": t0r, "stufe": np.zeros(n, dtype=np.int8), "episoden": []}}
    L1 = labor_rueckwaerts(db, sp, leer, t_von, t_cut, 300, 3600, coins=("AAA",), nur=nur, ausgabe=lambda s: None)
    L2 = labor_rueckwaerts(db2, sp2, leer, t_von, t_cut, 300, 3600, coins=("AAA",), nur=nur, ausgabe=lambda s: None)
    kask = L1.get("kaskaden")
    gleich = L1.get("B", {}).get("pruef") is not None and L1["B"]["pruef"] == L2["B"]["pruef"]
    ok("Rückwärtstest: Kausalität -- bis zur Schnittzeit gleich, ob spätere Daten (mit Ködern) da sind oder nicht",
       gleich and L1["B"]["n"] > 0 and L1["takte"] == L2["takte"] and kask,
       f"{L1['takte']} Takte bis {_utc(t_cut)}: mit späteren Daten {L1['B']['n']} Positionen (Prüfsumme {L1['B']['pruef']}), ohne "
       f"{L2['B']['n']} Positionen ({L2['B']['pruef']}); Kaskaden erkannt: {kask}")
    # (2) Sperre 6 h um die Kaskade (Budget „4“), dazu eine Welt ohne Sperre („2“)
    s_a, s_e = info["crash"] - 3600, info["crash"] + 5 * 3600
    st4 = np.zeros(n, dtype=np.int8)
    st4[(s_a - t0r) // 60:(s_e - t0r) // 60] = 1
    stufen = {4: {"t0": t0r, "stufe": st4, "episoden": [{"start": s_a, "ende": s_e, "stufe_max": 1, "quelle": "markt_x"}]}, 2: leer[2]}
    L = labor_rueckwaerts(db, sp, stufen, t_von, t_cut, 300, 3600, coins=("AAA",), nur=nur, fenster=(s_a - 12 * 3600, s_e + 12 * 3600),
                          ausgabe=lambda s: None)
    a4 = L["A"][4]
    ok("Rückwärtstest: Welt A' entsteht vor der Sperre und eröffnet darin keine Longs (B' schon); B' gleich dem Lauf ohne Bremse; "
       "ohne Sperre A' = B'",
       a4.get("t_a") is not None and a4["t_a"] < s_a and a4["zaehler"].get("gesperrt", 0) > 0 and L["A"][2].get("keine_sperre")
       and a4["longs_in_sperre"] == 0 and a4["longs_in_sperre_b"] >= 1 and L["B"]["pruef"] == L1["B"]["pruef"]
       and a4["d"] is not None and L["nachbildung"] is not None,
       f"A' ab {_utc(a4.get('t_a'))} (Sperre {_utc(s_a)}–{_utc(s_e)}): Longs in der Sperre A' {a4['longs_in_sperre']}, B' {a4['longs_in_sperre_b']}; "
       f"B' {'gleich' if L['B']['pruef'] == L1['B']['pruef'] else 'ANDERS als'} ohne Bremse ({L['B']['pruef']}); gesperrt {a4['zaehler']}, "
       f"protokolliert {a4['gesperrt']}, D gesamt {_usd(a4['d'], 2)} USD, im Fenster {_usd(a4['d_fenster'], 2)} USD; Budget 2 ohne Sperre: "
       f"{L['A'][2].get('keine_sperre')}")


def _probe_binance(tmp: str, ok) -> None:
    """Positivkontrolle: Monatsdateien mit und ohne Kopfzeile, Zeit in ms und µs; ein geplanter Einbruch am Ereignistag wird gefunden."""
    tag = date(2025, 10, 10)
    t_a = int(datetime(2025, 8, 1, tzinfo=UTC).timestamp()); n = (int(datetime(2025, 11, 1, tzinfo=UTC).timestamp()) - t_a) // 60
    m = NB._synth(5, t_a, n // 1440 + 1, n_k=6, n_a=0)
    coins = ["BTC", "ETH", "SOL", "ZEC", "HYPE", "XRP"]
    t_drop = int(datetime(2025, 10, 10, 21, 0, tzinfo=UTC).timestamp())
    k_d = (t_drop - t_a) // 60
    kurse = {}
    for c, (name, p) in zip(coins, m.items()):
        p = p[:n].copy()
        p[k_d:] *= np.exp(-0.08 * np.minimum(1.0, (np.arange(n - k_d)) / 20))      # −8 % in 20 min
        kurse[c] = p
    dateien = {}
    for i, c in enumerate(coins):
        for (j, mo) in ((2025, 8), (2025, 9), (2025, 10)):
            a = int(datetime(j, mo, 1, tzinfo=UTC).timestamp()); b = int(datetime(j + (mo == 12), mo % 12 + 1, 1, tzinfo=UTC).timestamp())
            zeilen = [] if i % 2 else ["open_time,open,high,low,close,volume,close_time,quote_volume,count,taker_buy_volume,taker_buy_quote_volume,ignore"]
            f = 1_000_000 if (i == 3 and mo == 10) else 1000
            for t in range(a, b, 60):
                px = float(kurse[c][(t - t_a) // 60])
                zeilen.append(f"{t * f},{px},{px},{px},{px},1,{(t + 59) * f + f - 1},1,1,1,1,0")
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as z:
                z.writestr(f"{c}USDT-1m-{j}-{mo:02d}.csv", "\n".join(zeilen))
            dateien[BINANCE_URL.format(s=f"{c}USDT", j=j, m=mo)] = buf.getvalue()
    abrufe = []

    def http(url):
        abrufe.append(url)
        return (dateien[url], None, 200) if url in dateien else (None, "HTTP 404", 404)
    ordner = os.path.join(tmp, "binance")
    th = dict(NB.START)
    P = positivkontrolle(tag, coins + ["XMR"], th, ordner, http)
    n1 = len(abrufe)
    P2 = positivkontrolle(tag, coins + ["XMR"], th, ordner, http)
    ok("Positivkontrolle (data.binance.vision): Kopfzeile, ms und µs, geplanter Einbruch gefunden, zweiter Lauf aus dem Zwischenspeicher",
       P.get("t_theta2y") is not None and 0 <= P["t_theta2y"] - t_drop <= 20 * 60 and abs(P["t_min"] - t_drop) <= 3600
       and P.get("y_min", 0) <= th["theta2y"] and P.get("t_theta1") is not None and "XMR" in P["fehlt"]
       and len(P["coins"]) == 6 and len(abrufe) - n1 == 1 and P2.get("t_theta2y") == P["t_theta2y"] and P2.get("y_min") == P["y_min"],
       f"Einbruch {_utc(t_drop)}: Y ≤ θ1 ab {_utc(P.get('t_theta1'))}, Y ≤ θ2Y ab {_utc(P.get('t_theta2y'))}, kleinstes Y {_z(P.get('y_min'))}; "
       f"Coins {len(P.get('coins') or [])}, fehlt {P.get('fehlt')}; Abrufe {n1}, im zweiten Lauf {len(abrufe) - n1} (nur der fehlende Coin)")


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    tmp = tempfile.mkdtemp(prefix="check_notbremse_test_")
    t_start = time.time()
    if verbose:
        print("check_notbremse -- Selbsttest (Zerlegung, t0, Rückblick, Rückwärtstest, Positivkontrolle; synthetisch, ohne Netz)", flush=True)
    try:
        for fn in (lambda: _probe_zerlegung(tmp, ok), lambda: _probe_t0(ok), lambda: _probe_retro(tmp, ok), lambda: _probe_binance(tmp, ok),
                   lambda: _probe_rueckwaerts(tmp, ok)):
            try:
                fn()
            except Exception as e:
                import traceback
                ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-700:].replace("\n", " | "))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", default=None, help="Hauptdatenbank (Vorgabe: aus der Einheit hl-recorder)")
    p.add_argument("--store", default=None, help="Prognosespeicher mit der Welt B (Vorgabe: forecasts.db neben der Datenbank)")
    p.add_argument("--zerlegung", default=None, metavar="TAG", help="Verlustzerlegung um den Tag, z. B. 2026-10-22")
    p.add_argument("--rueckblick", action="store_true", help="Rückblick 10.4 (dauert; nachts im Hintergrund)")
    p.add_argument("--tag", default=TAG_STANDARD, help="Tag der Zerlegung im Rückblick (Vorgabe 2026-10-22)")
    p.add_argument("--takt", type=int, default=300, help="Takt des Labor-Rückwärtstests in Sekunden (Vorgabe 300)")
    p.add_argument("--max-stunden", type=float, default=8.0, help="Zeitbudget des Rückwärtstests (Vorgabe 8 h)")
    p.add_argument("--ohne-labor", action="store_true", help="Rückblick ohne Labor-Rückwärtstest")
    p.add_argument("--ohne-binance", action="store_true", help="Rückblick ohne Positivkontrollen (kein Netz)")
    p.add_argument("--selbsttest", action="store_true", help="Proben auf synthetischen Daten (ohne Netz)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    db = a.db or db_standard()
    store = a.store or store_standard(db)
    if a.zerlegung:
        rueckblick(db, store, a.zerlegung, nur_zerlegung=True)
    elif a.rueckblick:
        rueckblick(db, store, a.tag, mit_labor=not a.ohne_labor, mit_binance=not a.ohne_binance, takt=max(60, a.takt),
                   max_s=a.max_stunden * 3600)
    else:
        kurz(db, store)


if __name__ == "__main__":
    main()
