#!/usr/bin/env python3
"""
Makro × Kurs (U130, Teil A, Version 2026-09-23.52): Wie stark hängen die Makro-Merkmale mit der BTC-Rendite der FOLGENDEN 1, 7 und
30 Tage zusammen? Vorab festgelegt in KONZEPT_Makro.md Abschnitt 10 (05.10.2026 19:15): Ziel, Merkmale, Maß und Schwellen standen
fest, bevor ein Ergebnis zu sehen war.

  Ziel        r(t → t+h) = ln P(t+h) − ln P(t), BTC-Tagesschluss (Coin Metrics), h = 1, 7, 30. Nie die Rendite desselben Tags.
  Merkmale    15 Werte am Tag t, nur aus Daten bis t (wie die Zonenkarte). FRED-Reihen mit 7 Tagen Versatz: Ihr Wert zum Datum t
              wird erst Tage später veröffentlicht (Fed-Bilanz donnerstags, Dollarindex wöchentlich).
  Maß         Spearman ρ und ρ² (Anteil der erklärten Rangstreuung -- „wie hoch ist die Wechselwirkung“). Beschreibend dazu: mittlere
              Rendite an Tagen im obersten gegen das unterste Drittel des Merkmals.
  Null        Phasen-Randomisierung (Ebisuzaki 1997): 2000 Surrogate des Merkmals mit gleichem Spektrum -- also gleicher
              Autokorrelation -- und zufälligen Fourier-Phasen; die Renditen bleiben, wie sie sind (ihre Überlappung auch).
              p zweiseitig. Gewählt in der Kalibrierung auf Zufallswegen VOR dem ersten Blick auf echte Daten (kalibrierung(),
              4.050 Tests mit unabhängigen, zähen Merkmalen): Phasen 0,8 % Fehlurteile bei p < 0,01 und 5,4 % bei p < 0,05; die
              beiden vorab genannten Verfahren fielen durch -- zirkuläre Verschiebung 1,7 % und 6,5 % (Perzentile bis 2,7 % und
              8,7 %), Blockbootstrap mit Blocklänge h bis 20 % bei p < 0,05.
  Belegt      Benjamini-Hochberg über alle gerechneten Tests (q = 0,10) UND gleiches Vorzeichen mit |ρ| ≥ 0,05 in beiden Hälften
              (bis 31.12.2021, ab 01.01.2022; je mindestens 365 Tage) UND die Nachrechnung gegen das Archiv mk_stand widerspricht
              nicht. Eine Ära (gemeinsamer Trend in Merkmal und Rendite) besteht die Ganzprobe, aber nicht die Hälften.

Reine Rechnung; liest die Ableitung von hl_makro (D) und das Archiv mk_stand. Debug-Bericht: python3 hl_makro_korr.py --db <hl_liq.db>

Teil B (23.85, U130): Makro-Regime × 4-h-Prognosen -- vorab festgelegt in KONZEPT_Makro.md 10.2, 10.7 und 10.7a (nach unabhängiger
Durchsicht), alles vor dem ersten Lauf auf echten Daten. Liest zusätzlich fusion_fall aus forecasts.db (nur lesen).
  python3 hl_makro_korr.py --teil-b --db <hl_liq.db>        Bericht (genau ein Urteil am 15.01.2027, vorher beschreibend)
  python3 hl_makro_korr.py --kalibrieren-b                  Kalibrierung auf künstlichen Welten (einige Minuten)
U229 (23.85): Der Bericht von Teil A schlüsselt die Nachrechnung von SSR nach Ursachen auf (offener Tag oder Korrektur).
"""
from __future__ import annotations

import argparse
import calendar
import math
import os
import sys
import time
import zlib

import numpy as np

HORIZONTE = (1, 7, 30)
MIN_VERSATZ = 365                       # nur für den Vergleich in der Kalibrierung (zirkuläre Verschiebung)
K_PHASEN = 2000                         # Surrogate je Test (kleinstes p 0,0005; BH braucht bei 45 Tests 0,0022)
MIN_TAGE = 2 * 365 + 30                 # kürzere Reihen sind nicht prüfbar und zählen nicht im BH (ETF seit 01/2024: geprüft, aber ohne erste Hälfte nie belegt)
Q_BH = 0.10
MIN_RHO = 0.05
GRENZE_HAELFTE = "2022-01-01"
MIN_TAGE_HAELFTE = 365
FRED_VERSATZ = 7                        # Veröffentlichungsverzug der FRED-Reihen
TAG = 86400
# 23.56 (U135): Kennzahlen, deren Tageswert am offenen Tag entsteht und sich danach noch ändert -- DVOL (Tageskerze läuft, Abruf
# alle 12 h) und der 30-Tage-ETF-Fluss (Kalendersumme bis heute; die Flüsse eines Handelstags erscheinen nach US-Schluss, einzelne
# Emittenten später). Die Zonenkarte wird beim ersten Rechnen des UTC-Tags festgeschrieben (hl_makro.archivieren). Lag der Datentag
# dabei weniger als so viele Tage zurück, war der Wert vorläufig: kein Widerspruch, eigene Zählung. Pi 06.10.: DVOL 35,97 -> 36,10,
# ETF 2.170,3 -> 2.080,5 Mio -- gemeldet als „ABWEICHEND“, obwohl nichts falsch gerechnet war.
VORLAEUFIG_TAGE = {"dvol": 2, "etf": 3}


def _tag(s: str) -> int:
    return calendar.timegm(time.strptime(s, "%Y-%m-%d")) // TAG


# ================================================================================================ Bausteine

def raenge(a: np.ndarray) -> np.ndarray:
    """Ränge 1..n, Gleichstände gemittelt (nur endliche Werte übergeben)."""
    a = np.asarray(a, dtype=float)
    u, inv, cnt = np.unique(a, return_inverse=True, return_counts=True)
    ende = np.cumsum(cnt); anfang = ende - cnt
    return ((anfang + ende + 1) / 2.0)[inv]


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return float("nan")
    rx = raenge(x[ok]); ry = raenge(y[ok])
    zx = rx - rx.mean(); zy = ry - ry.mean()
    nenner = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    return float(np.dot(zx, zy) / nenner) if nenner > 0 else float("nan")


def vorwaerts(P: np.ndarray, h: int) -> np.ndarray:
    """r(t → t+h) = ln P(t+h) − ln P(t); am Ende (t+h nach dem letzten Tag) leer."""
    P = np.asarray(P, dtype=float); n = len(P)
    r = np.full(n, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        r[: n - h] = np.log(P[h:]) - np.log(P[: n - h])
    return r


def verschiebungen(x: np.ndarray, y: np.ndarray, min_versatz: int = MIN_VERSATZ) -> tuple:
    """
    Spearman ρ und die Nullverteilung aus ALLEN zirkulären Verschiebungen k ∈ [min_versatz, n − min_versatz] des Merkmals gegen die
    Renditen (über die Paare mit beiden Werten). ρ_k = Σ_j zx[j−k]·zy[j] / Nenner per FFT -- so viel wie np.roll(rx, k) gegen ry.
    -> (rho, rho_null (Array), n) oder (rho, None, n), wenn die Reihe für ein Jahr Abstand zu kurz ist.
    """
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 3:
        return float("nan"), None, n
    rx = raenge(xs); ry = raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    nenner = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not nenner > 0:
        return float("nan"), None, n
    if n < 2 * min_versatz + 30:
        return float(np.dot(zx, zy) / nenner), None, n
    c = np.fft.irfft(np.conj(np.fft.rfft(zx)) * np.fft.rfft(zy), n) / nenner
    return float(c[0]), c[min_versatz: n - min_versatz + 1], n


def phasen_null(x: np.ndarray, y: np.ndarray, k: int = K_PHASEN, seed: int = 0) -> tuple:
    """
    Spearman ρ und die Nullverteilung aus k Surrogaten des Merkmals mit zufälligen Fourier-Phasen (Ebisuzaki 1997): gleiches
    Spektrum wie die Ränge des Merkmals (gleiche Autokorrelation), kein Bezug zu den Renditen; die Renditen bleiben fest.
    Für die Ränge zx, zy gilt Σ zx·zy = (1/n)·[2·Σ_f Re(X_f·conj(Y_f)) + Nyquist]; mit zufälliger Phase θ_f ist der Beitrag
    |X_f|·|Y_f|·cos θ_f -- deshalb ohne Rücktransformation: ρ_s = (2·Σ_f |X_f||Y_f| cos θ_f ± |X_N||Y_N|) / (n·Norm).
    -> (rho, null (Array) oder None bei zu kurzer Reihe, n)
    """
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 3:
        return float("nan"), None, n
    rx = raenge(xs); ry = raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    norm = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not norm > 0:
        return float("nan"), None, n
    rho = float(np.dot(zx, zy) / norm)
    if n < MIN_TAGE:
        return rho, None, n
    a = np.abs(np.fft.rfft(zx)) * np.abs(np.fft.rfft(zy))
    gerade = n % 2 == 0
    mitte = a[1:-1] if gerade else a[1:]
    rng = np.random.default_rng(seed)
    out = np.empty(k)
    for s0 in range(0, k, 250):
        m = min(250, k - s0)
        v = 2.0 * (np.cos(rng.uniform(0.0, 2 * np.pi, (m, len(mitte)))) @ mitte)
        if gerade:
            v = v + a[-1] * rng.choice((-1.0, 1.0), m)
        out[s0:s0 + m] = v / n / norm
    return rho, out, n


def p_zweiseitig(rho: float, null: np.ndarray) -> float:
    return float((1 + np.sum(np.abs(null) >= abs(rho) - 1e-12)) / (1 + len(null)))


def bh(p: list, q: float = Q_BH) -> list:
    """Benjamini-Hochberg: welche Tests bei der Rate falscher Entdeckungen q als Entdeckung gelten."""
    m = len(p)
    if not m:
        return []
    ordnung = sorted(range(m), key=lambda i: p[i])
    grenze = -1
    for rang, i in enumerate(ordnung, start=1):
        if p[i] <= rang / m * q:
            grenze = rang
    erlaubt = set(ordnung[:grenze]) if grenze > 0 else set()
    return [i in erlaubt for i in range(m)]


def pruefe(x: np.ndarray, y: np.ndarray, tage: np.ndarray, grenze_tag: int, seed: int = 0, k: int = K_PHASEN) -> dict:
    """Ein Test: Merkmal x(t) gegen Rendite y(t → t+h) mit Phasen-Null, dazu beide Hälften und die Drittel."""
    rho, null, n = phasen_null(x, y, k, seed)
    out = {"n": n, "rho": rho, "r2": rho * rho if math.isfinite(rho) else float("nan")}
    if null is None:
        out.update(zu_kurz=True, p=None)
    else:
        sd = float(np.std(null))
        out.update(p=p_zweiseitig(rho, null), n_null=len(null), sd_null=sd, lo90=rho - 1.6449 * sd, hi90=rho + 1.6449 * sd)
    ok = np.isfinite(x) & np.isfinite(y)
    tage = np.asarray(tage)
    for name, m in (("h1", ok & (tage < grenze_tag)), ("h2", ok & (tage >= grenze_tag))):
        out[f"n_{name}"] = int(m.sum())
        out[f"rho_{name}"] = spearman(x[m], y[m]) if m.sum() >= MIN_TAGE_HAELFTE else float("nan")
    if ok.sum() >= 30:
        xs, ys = x[ok], y[ok]
        q1, q2 = np.quantile(xs, [1 / 3, 2 / 3])
        oben, unten = ys[xs >= q2], ys[xs <= q1]
        out["drittel"] = float(np.mean(oben) - np.mean(unten)) if len(oben) and len(unten) else float("nan")
    return out


def urteil(t: dict) -> bool:
    """Belegt = Benjamini-Hochberg UND beide Hälften UND kein Widerspruch der Nachrechnung -- alle drei, wie vorab festgelegt."""
    return bool(t.get("bh")) and bool(t.get("haelften")) and not t.get("nach_widerspruch")


def haelften_ok(t: dict) -> bool:
    r, r1, r2 = t.get("rho"), t.get("rho_h1"), t.get("rho_h2")
    if not all(v is not None and math.isfinite(v) for v in (r, r1, r2)):
        return False
    return (np.sign(r1) == np.sign(r2) == np.sign(r)) and abs(r1) >= MIN_RHO and abs(r2) >= MIN_RHO


# ================================================================================================ Merkmale aus der Ableitung

def _asof(ziel_tage: np.ndarray, t: np.ndarray, w: np.ndarray, max_alter: int) -> np.ndarray:
    """Je Zieltag der letzte Wert am oder vor diesem Tag, höchstens max_alter Tage alt."""
    t = np.asarray(t, dtype=np.int64); w = np.asarray(w, dtype=float)
    m = np.isfinite(w); t, w = t[m], w[m]
    out = np.full(len(ziel_tage), np.nan)
    if not len(t):
        return out
    k = np.searchsorted(t, ziel_tage, "right") - 1
    gut = (k >= 0)
    kk = np.where(gut, k, 0)
    alt = ziel_tage - t[kk]
    gut &= alt <= max_alter
    out[gut] = w[kk[gut]]
    return out


def merkmale(D: dict) -> list:
    """[(Schlüssel, Name, Array auf der Tagesachse von D oder None, Hinweis, Schlüssel in mk_stand oder None)] -- Reihenfolge fest."""
    P = np.asarray(D["P"], dtype=float); tage = np.asarray(D["tage"], dtype=np.int64)
    bg = D.get("BGM") or {}
    with np.errstate(invalid="ignore", divide="ignore"):
        sth = P / np.asarray(bg.get("sth-realized-price", np.full(len(P), np.nan)), dtype=float) - 1
    ab = D.get("OI_ABDECKUNG") or {}
    oi = None if ab.get("lueckenhaft") else D.get("OI_MC")
    oi_hinweis = (f"Binance-Archiv lädt noch ({ab.get('tage')} von {ab.get('soll')} Tagen)" if ab.get("lueckenhaft") else "")
    out = [
        ("mvrv_pz", "MVRV (Perzentil seit Beginn)", D.get("MVRV_PZ"), "", "mvrv_pz"),
        ("pl_pz", "Kurs ÷ Power-Law-Fair-Value (Perzentil)", (D.get("PL") or {}).get("pz"), "", "pl_pz"),
        ("wma_pz", "Abstand zum 200-Wochen-MA (Perzentil)", D.get("WMA_ABST_PZ"), "", "wma_pz"),
        ("sth", "Kurs ÷ Kurzfrist-Kostenbasis − 1", sth, "", "sth"),
        ("mvrvz", "MVRV-Z", D.get("MVRV_Z"), "", "mvrvz"),
        ("puell_pz", "Puell (Perzentil in der Epoche)", D.get("PUELL_PZ"), "", "puell_pz"),
        ("funding30", "Funding 30 Tage", D.get("FUNDING30"), "", "funding"),
        ("oi", "OI ÷ Marktkapitalisierung", oi, oi_hinweis, "oi"),
        ("dvol", "DVOL", D.get("DVOL"), "", "dvol"),
        ("fng30", "Fear & Greed 30 Tage", D.get("FNG30"), "", "fng"),
        ("ssr_pz", "SSR (Perzentil)", D.get("SSR_PZ"), "", "ssr_pz"),
        ("etf30", "ETF-Fluss BTC 30 Tage", D.get("ETF_BTC_30"), "", "etf"),
    ]
    # FRED: Änderung über 4 Wochen, Wert vom Tag t − 7 (Veröffentlichung) gegen t − 35
    R = D.get("R")

    def reihe(name, max_alter):
        try:
            t, w = R(name)
        except Exception:                                                # nicht geladen oder Datei zu
            return np.full(len(tage), np.nan)
        return _asof(tage - FRED_VERSATZ, t, w, max_alter)

    if R is not None:
        walcl, tga, rrp = reihe("fred:WALCL", 10), reihe("fred:WTREGEN", 10), reihe("fred:RRPONTSYD", 7)
        rrp = np.where(np.isfinite(rrp), rrp, np.where(tage - FRED_VERSATZ < _tag("2013-09-23"), 0.0, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            netliq = walcl - tga - rrp * 1000
            nl4 = np.full(len(tage), np.nan); nl4[28:] = np.log(netliq[28:] / netliq[:-28])
            rz = reihe("fred:DFII10", 7); rz4 = np.full(len(tage), np.nan); rz4[28:] = rz[28:] - rz[:-28]
            dx = reihe("fred:DTWEXBGS", 10); dx4 = np.full(len(tage), np.nan); dx4[28:] = np.log(dx[28:] / dx[:-28])
        for key, name, arr in (("netliq4w", "Nettoliquidität, Änderung 4 Wochen", nl4), ("realzins4w", "Realzins 10 J, Änderung 4 Wochen", rz4),
                               ("dollar4w", "Dollar breit, Änderung 4 Wochen", dx4)):
            leer = not np.isfinite(arr).any()
            out.append((key, name + f" ({FRED_VERSATZ} T Versatz)", None if leer else arr, "FRED ohne Daten (Schlüssel?)" if leer else "", None))
    # eine Reihe ohne einen einzigen Wert ist „nicht prüfbar“, kein Test
    return [(k, n, None if a is None or not np.isfinite(np.asarray(a, dtype=float)).any() else a, h or ("keine Daten" if a is None or
             not np.isfinite(np.asarray(a, dtype=float)).any() else ""), sk) for k, n, a, h, sk in out]


# ================================================================================================ Auswertung

def auswertung(D: dict, stand_zeilen: list | None = None, offen_ssr: set | None = None) -> dict:
    """Alle Tests (Merkmal × Horizont), BH, Hälften, Nachrechnung -> Ergebnis zum Bericht. offen_ssr: Archivtage, an denen die
    Stablecoin-Summe des Datentags beim Festschreiben noch offen war (U229, ssr_diagnose)."""
    t0 = time.time()
    tage = np.asarray(D["tage"], dtype=np.int64); P = np.asarray(D["P"], dtype=float)
    grenze = _tag(GRENZE_HAELFTE)
    nach = nachrechnung_stand(D, stand_zeilen or [], offen_ssr)
    tests, fehlt = [], []
    for key, name, arr, hinweis, _sk in merkmale(D):
        if arr is None:
            fehlt.append({"key": key, "name": name, "grund": hinweis or "keine Daten"})
            continue
        x = np.asarray(arr, dtype=float)
        for h in HORIZONTE:
            t = pruefe(x, vorwaerts(P, h), tage, grenze, seed=zlib.crc32(f"{key}|{h}".encode()))
            t.update(key=key, name=name, h=h)
            if t.get("zu_kurz"):
                t["grund"] = f"zu kurz ({t['n']} Tage, nötig {MIN_TAGE}) -- zählt nicht im BH"
            tests.append(t)
    mit_p = [t for t in tests if t.get("p") is not None]
    ent = bh([t["p"] for t in mit_p])
    for t, e in zip(mit_p, ent):
        t["bh"] = bool(e)
    for t in tests:
        w = (nach.get("je_merkmal") or {}).get(t["key"], {})
        t["haelften"] = haelften_ok(t)
        t["nach_widerspruch"] = bool(w.get("abweichend"))
        t["belegt"] = urteil(t)
    return {"tests": tests, "fehlt": fehlt, "nachrechnung": nach, "n_tests": len(mit_p),
            "belegt": sum(1 for t in tests if t["belegt"]), "bh": sum(1 for t in tests if t.get("bh")),
            "p10": sum(1 for t in mit_p if t["p"] < 0.10), "bis": int(tage[np.nonzero(np.isfinite(P))[0][-1]]) if np.isfinite(P).any() else None,
            "dauer_s": round(time.time() - t0, 2)}


def nachrechnung_stand(D: dict, zeilen: list, offen_ssr: set | None = None) -> dict:
    """
    Kriterium 3: Werte, die die Zonenkarte an einem Tag festgeschrieben hat (mk_stand: Schlüssel und *_datentag), gegen die heutige
    Rechnung für denselben Datentag. zeilen = [(tag, schlüssel, wert)]. Kein Archiv -> kein Widerspruch (noch nicht prüfbar).
    23.56 (U135): Werte aus VORLAEUFIG_TAGE, deren Datentag beim Festschreiben noch offen war, zählen als „vorläufig“ und nicht als
    Widerspruch; ein abgeschlossener Datentag mit geändertem Wert bleibt „abweichend“.
    23.85 (U229): SSR-Werte, deren Stablecoin-Summe beim Festschreiben nachweislich noch offen war (offen_ssr, aus ssr_diagnose),
    zählen ebenso als vorläufig; jede andere Abweichung bleibt „abweichend“.
    """
    if not zeilen:
        return {"n": 0, "n_vorlaeufig": 0, "je_merkmal": {}}
    d0 = int(D["d0"]); arr = {k: a for k, _n, a, _h, sk in merkmale(D) if sk and a is not None for k in [sk]}
    datentag = {(t, k[: -len("_datentag")]): int(w) for t, k, w in zeilen if k.endswith("_datentag")}
    je, n, nv = {}, 0, 0
    rueck = {sk: k for k, _n, a, _h, sk in merkmale(D) if sk}
    for t, k, w in zeilen:
        if k.endswith("_datentag") or k not in arr:
            continue
        basis = k[:-3] if k.endswith("_pz") else k
        d = datentag.get((t, basis))
        if d is None or not (0 <= d - d0 < len(arr[k])):
            continue
        neu = float(arr[k][d - d0])
        e = je.setdefault(rueck[k], {"n": 0, "abweichend": 0, "beispiel": None, "vorlaeufig": 0})
        if _tag(t) - d < VORLAEUFIG_TAGE.get(basis, 0) or (basis == "ssr" and t in (offen_ssr or ())):   # 23.56 (U135), 23.85 (U229)
            e["vorlaeufig"] += 1; nv += 1
            continue
        n += 1; e["n"] += 1
        if not (math.isfinite(neu) and abs(neu - float(w)) <= 1e-6 * max(1.0, abs(float(w)))):
            e["abweichend"] += 1
            e["beispiel"] = e["beispiel"] or f"{t}: {float(w):.6g} -> {neu:.6g}"
    return {"n": n, "n_vorlaeufig": nv, "je_merkmal": je}


def bericht_text(A: dict, ssr: dict | None = None) -> str:
    z = lambda v, d=2: "—" if v is None or not (isinstance(v, (int, float)) and math.isfinite(v)) else f"{v:+.{d}f}".replace(".", ",")
    tag = lambda t: time.strftime("%d.%m.%Y", time.gmtime(t * TAG)) if t else "—"
    zeilen = [f"Makro × Kurs (U130, Teil A) -- BTC-Tagesschluss Coin Metrics bis {tag(A['bis'])}, gerechnet in "
              + f"{A['dauer_s']:.1f} s".replace(".", ","),
              "  Vorab festgelegt in KONZEPT_Makro.md Abschnitt 10 (05.10.2026 19:15). Rendite VORWÄRTS r(t → t+h); Merkmal am Tag t, nur Daten",
              "  bis t. Null: 2000 Phasen-Surrogate des Merkmals (gleiche Autokorrelation). Belegt nur: Benjamini-Hochberg q = 0,10 UND gleiches Vorzeichen mit",
              "  |ρ| ≥ 0,05 in beiden Hälften (bis 2021 / ab 2022) UND Nachrechnung ohne Widerspruch.",
              "",
              f"  {'Merkmal':<46} {'h':>3} {'Tage':>5} {'ρ':>7} {'90 %':>15} {'ρ²':>6} {'p':>6} {'bis 2021':>8} {'ab 2022':>8} {'Drittel':>8}  Urteil"]
    for t in A["tests"]:
        if t.get("zu_kurz"):
            zeilen.append(f"  {t['name'][:46]:<46} {t['h']:>3} {t['n']:>5} {z(t['rho']):>7}  -- {t['grund']}")
            continue
        urteil = ("BELEGT" if t["belegt"] else ("BH ja, Hälften nein" if t.get("bh") and not t["haelften"]
                                                 else ("BH ja, Nachrechnung widerspricht" if t.get("bh") else "nein")))
        dr = t.get("drittel")
        zeilen.append(f"  {t['name'][:46]:<46} {t['h']:>3} {t['n']:>5} {z(t['rho'], 3):>7} [{z(t['lo90'])} {z(t['hi90'])}]".ljust(80)
                      + f" {t['r2'] * 100:5.1f}% {t['p']:6.3f} {z(t['rho_h1']):>8} {z(t['rho_h2']):>8} "
                      f"{('—' if dr is None or not math.isfinite(dr) else f'{dr * 100:+.1f} %'):>8}  {urteil}".replace(".", ","))
    m = A["n_tests"]
    zeilen += ["",
               f"  Zusammen: {A['belegt']} von {m} Tests belegt · Benjamini-Hochberg allein: {A['bh']} · unkorrigiert p < 0,10: {A['p10']} "
               f"(Zufall allein ≈ {m * 0.10:.1f})".replace(".", ","),
               "  ρ² = Anteil der erklärten Rangstreuung der Rendite (ρ = 0,1 erklärt 1 %). Drittel = mittlere Rendite im obersten minus im",
               "  untersten Drittel des Merkmals (beschreibend, ohne eigenen Test). 90 % = ρ ± 1,645 × Streuung der Null. Bei h = 7 und 30",
               "  überlappen die Renditen; die Null lässt sie unverändert und erhält die Autokorrelation des Merkmals.",
               "  Hinweis: Coin Metrics und ETF-Flüsse erscheinen 1–2 Tage nach dem Datum -- bei h = 1 ein Vorteil, den man live nicht hätte.",
               "  Ebenso die Kurzfrist-Kostenbasis (BGeometrics frei 7 Tage später; das Merkmal nimmt den Wert desselben Tags): bei h = 1 und 7",
               "  ein Vorteil, den man live nicht hätte -- ohne erste Hälfte ohnehin nie belegt (eigener Fehler aus 23.52, genannt seit 23.85)."]
    if A["fehlt"]:
        zeilen.append("  Nicht prüfbar: " + "; ".join(f"{f['name']} ({f['grund']})" for f in A["fehlt"]))
    ohne = sorted({t["name"] for t in A["tests"] if not t.get("zu_kurz") and t.get("n_h1", 0) < MIN_TAGE_HAELFTE})
    if ohne:
        zeilen.append("  Ohne erste Hälfte (weniger als 365 Tage vor 2022) -- gerechnet, nach der vorab festgelegten Regel aber nie belegt: "
                      + ", ".join(ohne))
    nn = A["nachrechnung"]
    vl = {k: v["vorlaeufig"] for k, v in nn["je_merkmal"].items() if v.get("vorlaeufig")}
    vtxt = ("" if not vl else " · am offenen Tag festgeschrieben (Tageswert noch vorläufig, nicht geprüft): "
            + ", ".join(f"{k} {v}" for k, v in vl.items()))
    if not nn.get("n"):
        zeilen.append("  Nachrechnung gegen mk_stand: " + ("Archiv noch leer" if not vl else "nur vorläufige Werte")
                      + " -- kein Widerspruch prüfbar (Kriterium 3 hält)" + vtxt)
    else:
        ab = {k: v for k, v in nn["je_merkmal"].items() if v["abweichend"]}
        zeilen.append(f"  Nachrechnung gegen mk_stand: {nn['n']} archivierte Werte geprüft, "
                      + ("alle gleich" if not ab else "ABWEICHEND: " + "; ".join(f"{k} {v['abweichend']} von {v['n']} ({v['beispiel']})" for k, v in ab.items()))
                      + vtxt)
    if ssr is not None:                                                  # 23.85 (U229)
        zeilen += ssr_text(ssr)
    return "\n".join(zeilen)


# ================================================================================================ U229: Nachrechnung von SSR (23.85)
# Bericht 25.10.: ssr_pz wich an 10 von 21 archivierten Tagen von der heutigen Rechnung ab (05.10.: 29,16 -> 29,62). Zwei Ursachen sind
# denkbar (UPDATE_PLAN U229): ein offener Tag (die Stablecoin-Summe des Datentags lief bei DefiLlama noch, als die Zonenkarte ihn
# festschrieb -- SSR = Marktkapitalisierung ÷ Stablecoin-Summe, der Datentag ist der jüngste Tag von Coin Metrics, DefiLlama liefert
# auch den laufenden Tag) oder Korrekturen von DefiLlama. mk_reihe hält je Wert den Zeitpunkt seiner letzten Änderung (abgerufen),
# mk_stand den Zeitpunkt des Festschreibens (berechnet) und den damaligen Rohwert (ssr): daraus folgt die Ursache je Tag.
SSR_OFFEN_TAGE = 2


def ssr_diagnose(D: dict, pfad: str) -> dict:
    """
    23.85 (U229, Regel vorab festgelegt in KONZEPT_Makro.md 10.8): je archiviertem Tag Rohwert und Perzentil gegen heute, letzte Änderung
    der Stablecoin-Summe (DefiLlama) und der Marktkapitalisierung (Coin Metrics) des Datentags, ältere Stablecoin-Werte nach dem
    Festschreiben geändert? Klassen:
      gleich                                   Rohwert und Perzentil gleich
      offener Tag                              Rohwert anders; nur die Stablecoin-Summe des Datentags danach geändert, spätestens 2 Tage
                                               nach dem Ende des Datentags; ältere Werte unverändert -> zählt als vorläufig (wie DVOL, ETF)
      offener Tag, ältere Werte geändert       wie eben, aber auch ältere Stablecoin-Werte danach geändert -> abweichend
      spätere Korrektur der Stablecoin-Summe   die Änderung kam später -> abweichend (Korrektur bei DefiLlama)
      Marktkapitalisierung geändert            Coin Metrics hat den Datentag danach geändert -> abweichend
      nur Perzentil                            Rohwert gleich, Perzentil anders (ältere Werte geändert) -> abweichend
      unklar                                   sonst -> abweichend
    -> {"tage": [...], "zaehl": {Klasse: n}, "offen": {Archivtag, ...}, "fehler": str (wenn makro.db nicht lesbar)}
    """
    import sqlite3
    out: dict = {"tage": [], "zaehl": {}, "offen": set()}
    if not pfad or not os.path.exists(pfad):
        return out
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    except sqlite3.Error as e:
        out["fehler"] = str(e)
        return out
    try:
        je: dict = {}
        for tag, kz, w, b in con.execute("SELECT tag, kennzahl, wert, berechnet FROM mk_stand WHERE kennzahl IN ('ssr', 'ssr_pz', 'ssr_datentag')"):
            je.setdefault(tag, {})[kz] = (w, b)
        ssr = np.asarray(D.get("SSR", np.zeros(0)), dtype=float)
        pz = np.asarray(D.get("SSR_PZ", np.zeros(0)), dtype=float)
        d0 = int(D["d0"])

        def gleich(a, b):
            return a is not None and math.isfinite(b) and abs(b - float(a)) <= 1e-6 * max(1.0, abs(float(a)))

        def zuletzt(reihe, d):
            r = con.execute("SELECT abgerufen FROM mk_reihe WHERE reihe=? AND ts=?", (reihe, d * TAG)).fetchone()
            return int(r[0]) if r and r[0] is not None else None

        for tag in sorted(je):
            e = je[tag]
            if "ssr_datentag" not in e or "ssr_pz" not in e:
                continue
            d = int(e["ssr_datentag"][0]); fest = int(e["ssr_datentag"][1] or 0)
            i = d - d0
            if not 0 <= i < len(ssr):
                continue
            roh_a = (e.get("ssr") or (None, None))[0]; pz_a = e["ssr_pz"][0]
            roh_g, pz_g = gleich(roh_a, float(ssr[i])), gleich(pz_a, float(pz[i]))
            st, mc = zuletzt("llama:stable_usd", d), zuletzt("cm:btc:CapMrktCurUSD", d)
            alt = con.execute("SELECT COUNT(*) FROM mk_reihe WHERE reihe='llama:stable_usd' AND ts<? AND abgerufen>?", (d * TAG, fest)).fetchone()[0]
            st_n, mc_n = st is not None and st > fest, mc is not None and mc > fest
            if roh_g and pz_g:
                kl = "gleich"
            elif mc_n:
                kl = "Marktkapitalisierung geändert"
            elif not roh_g and st_n and st <= (d + 1 + SSR_OFFEN_TAGE) * TAG:
                kl = "offener Tag" if alt == 0 else "offener Tag, ältere Werte geändert"
            elif not roh_g and st_n:
                kl = "spätere Korrektur der Stablecoin-Summe"
            elif roh_g:
                kl = "nur Perzentil"
            else:
                kl = "unklar"
            out["tage"].append({"tag": tag, "datentag": d, "fest": fest, "roh_alt": roh_a, "roh_neu": float(ssr[i]), "pz_alt": pz_a,
                                "pz_neu": float(pz[i]), "klasse": kl, "stable_geaendert": st, "aeltere": int(alt)})
            out["zaehl"][kl] = out["zaehl"].get(kl, 0) + 1
            if kl == "offener Tag":
                out["offen"].add(tag)
    except sqlite3.Error as e:
        out["fehler"] = str(e)
    finally:
        con.close()
    return out


def ssr_text(S: dict) -> list:
    """Abschnitt U229 im Bericht von Teil A."""
    if S.get("fehler"):
        return [f"  U229 (SSR in der Nachrechnung): makro.db nicht lesbar ({S['fehler']})"]
    if not S.get("tage"):
        return ["  U229 (SSR in der Nachrechnung): keine archivierten SSR-Werte"]
    z_ = S["zaehl"]
    reihenfolge = ("gleich", "offener Tag", "offener Tag, ältere Werte geändert", "spätere Korrektur der Stablecoin-Summe",
                   "Marktkapitalisierung geändert", "nur Perzentil", "unklar")
    zl = [f"  U229 -- SSR in der Nachrechnung aufgeschlüsselt ({len(S['tage'])} archivierte Tage): "
          + " · ".join(f"{k} {z_[k]}" for k in reihenfolge if z_.get(k))]
    anders = [t for t in S["tage"] if t["klasse"] != "gleich"]
    if not anders:
        zl.append("    Befund: alle archivierten SSR-Werte gleich -- keine Abweichung mehr.")
        return zl
    revision = [t for t in anders if t["klasse"] != "offener Tag"]
    zl.append("    Befund: " + ("offener Tag -- DefiLlama schrieb die Stablecoin-Summe des Datentags noch fort, als die Zonenkarte ihn festschrieb; "
                                "diese Werte zählen seit 23.85 als vorläufig (wie DVOL und ETF), kein Widerspruch."
                                if not revision else
                                f"nicht nur der offene Tag: {len(revision)} von {len(anders)} Abweichungen sind Korrekturen oder unklar "
                                "(zählen weiter als abweichend; dann Fassungen der Reihe speichern wie bei U153)."))
    tf = lambda ts: time.strftime("%d.%m. %H:%M", time.localtime(ts)) if ts else "—"
    kz = lambda v, d: "—" if v is None else f"{float(v):.{d}f}".replace(".", ",")
    for t in anders[:4]:
        dt = time.strftime("%d.%m.", time.gmtime(t["datentag"] * TAG))
        zl.append(f"    {t['tag']} (Datentag {dt}, festgeschrieben {tf(t['fest'])}): SSR {kz(t['roh_alt'], 4)} -> {kz(t['roh_neu'], 4)}, "
                  f"Perzentil {kz(t['pz_alt'], 2)} -> {kz(t['pz_neu'], 2)}; Stablecoin-Summe zuletzt geändert {tf(t['stable_geaendert'])}; "
                  f"{t['aeltere']} ältere Werte danach geändert -- {t['klasse']}")
    if len(anders) > 4:
        zl.append(f"    … und {len(anders) - 4} weitere")
    return zl


# ================================================================================================ Teil B (U130, 23.85)
# Makro-Regime × 4-h-Prognosen. Vorab festgelegt in KONZEPT_Makro.md 10.2 (05.10.2026 19:15), präzisiert in 10.7 (25.10.2026 23:18)
# und nach unabhängiger Durchsicht in 10.7a (25.10.2026 23:35) -- alles vor dem ersten Lauf auf echten Daten.
#   Regime am Tag t   aus Werten vom Tag t − 2 (Kurzfrist-Kostenbasis t − 9), jüngster Wert höchstens 3 Tage älter; 9 Teilungen
#   Daten             fusion_fall, 4 h, aufgelöste Blöcke; ausgewertet ab dem 29. Tag nach dem ersten Block (Anlauf der Basisrate)
#   Maß               g = (p_Basis − y)² − (p_Quelle − y)² je Block; Δ = Mittel im Regime − Mittel außerhalb (Tage als Klumpen)
#   Hauptfamilie      je Regime und Quelle, Krypto-Coins zusammen (BTC, ETH, HYPE, XMR, ZEC): 27 Tests; je Coin nur beschreibend
#   Unsicherheit      Bootstrap über ganze Tage, je Seite getrennt -> 90-%-Intervall
#   Placebo           Kalender um k ganze Wochen zurück (ganz vor dem Zeitraum, ≥ 2 Jahre Vorgeschichte, gleiche Zahl von
#                     Abschnitten ±1), Rang nach der Welch-Lage z; p = (1 + #|z_k| ≥ |z|) ÷ (1 + K)
#   Belegt            Placebo-p < 0,025 UND Benjamini-Hochberg (q = 0,10) über die prüfbaren Tests der Hauptfamilie UND beide
#                     Hälften; genau ein Urteil am 15.01.2027 (Prognosen bis 14.01.2027 23:59 UTC), vorher beschreibend
B_H = 4
B_QUELLEN = ("v1", "v2", "Fusion")
B_POOL = ("BTC", "ETH", "HYPE", "XMR", "ZEC")
B_VERZUG = 2
B_VERZUG_BGM = 9
B_MAX_ALTER = 3
B_ANLAUF_TAGE = 28
B_MIN_TAGE = 20
B_MIN_ABSCHNITTE = 2
B_MIN_TAGE_HAELFTE = 7
B_MIN_VERSCHIEBUNGEN = 40
B_VORGESCHICHTE = 730
B_ABSCHNITTE_TOL = 1
B_PLACEBO_P = 0.025
B_BOOT = 2000
B_URTEIL = "2027-01-15"
B_P_FUER_BH = "placebo"                 # Regel der Kalibrierung (10.7a): siehe KONZEPT_Makro.md 10.7b
_OBEN, _UNTEN = 200.0 / 3.0, 100.0 / 3.0
# (Schlüssel, Name, Feld in D, Vergleich, Schwelle, Verzug in Tagen)
B_REGIME = (
    ("funding_hoch", "Funding 30 T oberes Drittel", "FUNDING30_PZ", ">=", _OBEN, B_VERZUG),
    ("oi_hoch", "OI ÷ Marktkap. oberes Drittel", "OI_MC_PZ", ">=", _OBEN, B_VERZUG),
    ("dvol_hoch", "DVOL oberes Drittel", "DVOL_PZ", ">=", _OBEN, B_VERZUG),
    ("dvol_tief", "DVOL unteres Drittel", "DVOL_PZ", "<=", _UNTEN, B_VERZUG),
    ("fng_gier", "Fear & Greed 30 T ≥ 75", "FNG30", ">=", 75.0, B_VERZUG),
    ("fng_angst", "Fear & Greed 30 T ≤ 25", "FNG30", "<=", 25.0, B_VERZUG),
    ("unter_sth", "Kurs unter Kurzfrist-Kostenbasis", "sth", "<", 0.0, B_VERZUG_BGM),
    ("mvrv_hoch", "MVRV oberes Drittel", "MVRV_PZ", ">=", _OBEN, B_VERZUG),
    ("mvrv_tief", "MVRV unteres Drittel", "MVRV_PZ", "<=", _UNTEN, B_VERZUG),
)


def _vergleich(w: np.ndarray, op: str, s: float) -> np.ndarray:
    if op == ">=":
        return w >= s
    if op == "<=":
        return w <= s
    if op == "<":
        return w < s
    raise ValueError(op)


def regime_kalender(D: dict) -> dict:
    """
    Je Regime ein Array auf der Tagesachse von D: 1 im Regime, 0 außerhalb, NaN ohne Wert. Für den Tag t gilt der jüngste Wert am
    oder vor t − Verzug, höchstens B_MAX_ALTER Tage älter als t − Verzug (10.7, 10.7a). None, wenn die Quelle fehlt (OI: Archiv
    lückenhaft).
    """
    tage = np.asarray(D["tage"], dtype=np.int64)
    P = np.asarray(D["P"], dtype=float)
    bg = D.get("BGM") or {}
    with np.errstate(invalid="ignore", divide="ignore"):
        sth = P / np.asarray(bg.get("sth-realized-price", np.full(len(P), np.nan)), dtype=float) - 1
    luecke = bool((D.get("OI_ABDECKUNG") or {}).get("lueckenhaft"))
    out = {}
    for key, _name, feld, op, schwelle, verzug in B_REGIME:
        x = sth if feld == "sth" else (None if feld == "OI_MC_PZ" and luecke else D.get(feld))
        if x is None or not np.isfinite(np.asarray(x, dtype=float)).any():
            out[key] = None
            continue
        w = _asof(tage - verzug, tage, np.asarray(x, dtype=float), B_MAX_ALTER)
        r = np.full(len(tage), np.nan)
        ok = np.isfinite(w)
        r[ok] = _vergleich(w[ok], op, schwelle).astype(float)
        out[key] = r
    return out


def faelle_laden(pfad: str) -> list:
    """Aufgelöste 4-h-Blöcke mit Richtung aus fusion_fall (nur lesen): [(coin, ts, y, p_basis, {quelle: p})]."""
    import json
    import sqlite3
    if not os.path.exists(pfad):
        return []
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        rows = con.execute("SELECT coin, ts, experten, p_fusion, y FROM fusion_fall WHERE h=? AND y IN (0, 1) ORDER BY ts",
                           (B_H,)).fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        con.close()
    out = []
    for coin, ts, ex, pf, y in rows:
        try:
            e = json.loads(ex) if ex else {}
        except ValueError:
            e = {}
        pb = e.get("Basisrate") if isinstance(e, dict) else None
        if pb is None:
            continue
        q = {"v1": e.get("v1"), "v2": e.get("v2"), "Fusion": pf}
        q = {k: float(v) for k, v in q.items() if v is not None and math.isfinite(float(v))}
        out.append((str(coin), int(ts), int(y), float(pb), q))
    return out


_FELDER = ("S", "C", "H", "B", "R", "Q")       # Vorsprung g, Blöcke, Treffer, Brier der Basis, Richtungsteil 2δ(y − p_B), Sicherheitsteil δ²


def tagesreihen(faelle: list, w0: int, L: int) -> dict:
    """{(coin, quelle): {Feld: Array je Tag w0 .. w0 + L − 1}} -- Summen je Tag (Felder _FELDER)."""
    out: dict = {}
    for coin, ts, y, pb, q in faelle:
        i = ts // TAG - w0
        if not 0 <= i < L:
            continue
        bb = (pb - y) ** 2
        for quelle, p in q.items():
            a = out.get((coin, quelle))
            if a is None:
                a = out[(coin, quelle)] = {f: np.zeros(L) for f in _FELDER}
            d = p - pb
            a["S"][i] += bb - (p - y) ** 2
            a["C"][i] += 1
            a["H"][i] += 0.5 if p == 0.5 else float((p > 0.5) == (y == 1))
            a["B"][i] += bb
            a["R"][i] += 2 * d * (y - pb)
            a["Q"][i] += d * d
    return out


def _gepoolt(reihen: dict, coins, quelle: str, L: int) -> dict | None:
    teile = [reihen[(c, quelle)] for c in coins if (c, quelle) in reihen]
    if not teile:
        return None
    return {f: np.sum([a[f] for a in teile], axis=0) for f in _FELDER}


def _seite(M: np.ndarray, S: np.ndarray, C: np.ndarray) -> tuple:
    """Mittel ΣS/ΣC über die Tage der Maske (Zeilen = Kalender), Varianz (Verhältnisschätzer, Tage als Klumpen, Faktor n/(n − 1)), n."""
    n = M.sum(1)
    a1, a2 = M @ S, M @ C
    a3, a4, a5 = M @ (S * S), M @ (S * C), M @ (C * C)
    with np.errstate(invalid="ignore", divide="ignore"):
        m = a1 / a2
        ss = np.maximum(a3 - 2 * m * a4 + m * m * a5, 0.0)
        v = n / (n - 1) * ss / (a2 * a2)
    return m, v, n


def lage(S: np.ndarray, C: np.ndarray, MI: np.ndarray, MO: np.ndarray) -> dict:
    """Je Kalender (Masken K × n oder n): Δ, Standardfehler, t, Welch-Freiheitsgrade ν und die Lage z = t(1 − 1/(4ν)) ÷ √(1 + t²/(2ν))
    (Abramowitz & Stegun 26.7.8: t mit ν Freiheitsgraden auf die Normalverteilung)."""
    MI = np.atleast_2d(MI).astype(float); MO = np.atleast_2d(MO).astype(float)
    mI, vI, nI = _seite(MI, S, C)
    mO, vO, nO = _seite(MO, S, C)
    d = mI - mO
    with np.errstate(invalid="ignore", divide="ignore"):
        se = np.sqrt(vI + vO)
        t = d / se
        nu = np.maximum(1.0, (vI + vO) ** 2 / (vI * vI / (nI - 1) + vO * vO / (nO - 1)))
        z = t * (1 - 1 / (4 * nu)) / np.sqrt(1 + t * t / (2 * nu))
    return {"d": d, "se": se, "t": t, "nu": nu, "z": z, "m_i": mI, "m_o": mO}


def abschnitte(R: np.ndarray) -> tuple:
    """Zahl der Abschnitte (Folgen gleicher Werte) je Zeile einer 0/1-Matrix K × n: (im Regime, außerhalb)."""
    R = np.atleast_2d(R)
    if R.shape[1] == 0:
        return np.zeros(R.shape[0], dtype=int), np.zeros(R.shape[0], dtype=int)
    neu = np.ones(R.shape, dtype=bool)
    neu[:, 1:] = R[:, 1:] != R[:, :-1]
    return (neu & (R == 1)).sum(1), (neu & (R == 0)).sum(1)


def _normal_p(z: float) -> float:
    return float(math.erfc(abs(z) / math.sqrt(2.0))) if math.isfinite(z) else float("nan")


def b_test(reg: np.ndarray | None, d0: int, w0: int, L: int, mitte: int, k_min: int, a: dict, seed: int, boot: int = B_BOOT,
           placebo: bool = True) -> dict:
    """Ein Test (Regime × Quelle, gepoolt oder ein Coin) auf den Tagen w0 .. w0 + L − 1. a: Tagessummen (_FELDER)."""
    S, C, H, B = a["S"], a["C"], a["H"], a["B"]
    out = {"pruefbar": False}
    tage = np.arange(w0, w0 + L)
    iD = tage - d0
    r = np.full(L, np.nan)
    if reg is not None:
        ok_ax = (iD >= 0) & (iD < len(reg))
        r[ok_ax] = reg[iD[ok_ax]]
    used = (C > 0) & np.isfinite(r)
    I = used & (r == 1); O = used & (r == 0)
    ab_i, ab_o = abschnitte(r[used][None, :])
    out.update(n_i=int(I.sum()), n_o=int(O.sum()), b_i=int(C[I].sum()), b_o=int(C[O].sum()), ab_i=int(ab_i[0]), ab_o=int(ab_o[0]))
    h1 = tage < mitte
    out.update(n_i_h1=int((I & h1).sum()), n_o_h1=int((O & h1).sum()), n_i_h2=int((I & ~h1).sum()), n_o_h2=int((O & ~h1).sum()))
    if reg is None:
        out["grund"] = "keine Daten"
        return out
    if out["n_i"] < B_MIN_TAGE or out["n_o"] < B_MIN_TAGE:
        out["grund"] = f"{out['n_i']} Tage im Regime, {out['n_o']} außerhalb (nötig je {B_MIN_TAGE})"
        return out
    if out["ab_i"] < B_MIN_ABSCHNITTE or out["ab_o"] < B_MIN_ABSCHNITTE:
        out["grund"] = f"Abschnitte im Regime {out['ab_i']}, außerhalb {out['ab_o']} (nötig je {B_MIN_ABSCHNITTE})"
        return out
    g = lage(S, C, I, O)
    d, t, z = float(g["d"][0]), float(g["t"][0]), float(g["z"][0])
    if not (math.isfinite(t) and float(g["se"][0]) > 0):
        out["grund"] = "keine Streuung"
        return out
    bb = float(B[used].sum() / C[used].sum())
    out.update(delta=d, se=float(g["se"][0]), t=t, nu=float(g["nu"][0]), z=z, brier_basis=bb,
               skill_i=100 * float(g["m_i"][0]) / bb, skill_o=100 * float(g["m_o"][0]) / bb, d_skill=100 * d / bb)
    gr = lage(a["R"], C, I, O); gq = lage(a["Q"], C, I, O)
    out.update(d_richtung=100 * float(gr["d"][0]) / bb, d_sicherheit=100 * float(gq["d"][0]) / bb)
    # Bootstrap über ganze Tage, je Seite getrennt
    rng = np.random.default_rng(seed)
    ii, oo = np.nonzero(I)[0], np.nonzero(O)[0]
    zi = ii[rng.integers(0, len(ii), (boot, len(ii)))]; zo = oo[rng.integers(0, len(oo), (boot, len(oo)))]
    ci, co = C[zi].sum(1), C[zo].sum(1)
    db = S[zi].sum(1) / ci - S[zo].sum(1) / co
    hb = H[zi].sum(1) / ci - H[zo].sum(1) / co
    lo, hi = np.quantile(db, [0.05, 0.95])
    sd_b = float(np.std(db))
    out.update(lo90=float(lo), hi90=float(hi), se_boot=sd_b, p_boot=_normal_p(d / sd_b) if sd_b > 0 else float("nan"),
               lo90_skill=100 * float(lo) / bb, hi90_skill=100 * float(hi) / bb)
    hlo, hhi = np.quantile(hb, [0.05, 0.95])
    out.update(treffer_i=float(H[I].sum() / C[I].sum()), treffer_o=float(H[O].sum() / C[O].sum()), d_treffer_lo=float(hlo),
               d_treffer_hi=float(hhi))
    # Hälften (10.7a: je Seite mindestens 7 Tage in jeder Hälfte, gleiches Vorzeichen wie über alles)
    hv = {}
    for name, m in (("h1", h1), ("h2", ~h1)):
        Ih, Oh = I & m, O & m
        hv[name] = (float(lage(S, C, Ih, Oh)["d"][0]) if Ih.sum() >= B_MIN_TAGE_HAELFTE and Oh.sum() >= B_MIN_TAGE_HAELFTE else None)
    out.update(d_h1=hv["h1"], d_h2=hv["h2"])
    out["haelften"] = bool(hv["h1"] is not None and hv["h2"] is not None and d != 0
                          and np.sign(hv["h1"]) == np.sign(hv["h2"]) == np.sign(d))
    if not placebo:
        return out
    # Placebo: Kalender um k ganze Wochen zurück; ganz vor dem Zeitraum, aus Zeiten mit ≥ 2 Jahren Vorgeschichte der Reihe, auf jedem
    # Tag des Tests mit Wert, dieselben Mindestzahlen; gezählt die mit gleicher Zahl von Abschnitten (±1), wenn es ≥ 40 sind
    ui = np.nonzero(used)[0]
    iDu = iD[ui]
    fin = np.nonzero(np.isfinite(reg))[0]
    erst = int(fin[0]) + B_VORGESCHICHTE
    k_max = (int(iDu.min()) - erst) // 7
    if k_max < k_min:
        out.update(K=0, p_placebo=None, grund="Placebo zu kurz (keine Verschiebung mit 2 Jahren Vorgeschichte vor dem Zeitraum)")
        return out
    ks = np.arange(k_min, k_max + 1)
    idx = iDu[None, :] - 7 * ks[:, None]
    R = reg[idx]
    defin = np.isfinite(R).all(1)
    MI = (R == 1); MO = (R == 0)
    ai, ao = abschnitte(np.where(np.isfinite(R), R, -1))
    gueltig = (defin & (MI.sum(1) >= B_MIN_TAGE) & (MO.sum(1) >= B_MIN_TAGE) & (ai >= B_MIN_ABSCHNITTE) & (ao >= B_MIN_ABSCHNITTE))
    gleich = gueltig & (np.abs((ai + ao) - (out["ab_i"] + out["ab_o"])) <= B_ABSCHNITTE_TOL)
    menge = gleich if gleich.sum() >= B_MIN_VERSCHIEBUNGEN else gueltig
    out.update(K_gueltig=int(gueltig.sum()), K_gleich=int(gleich.sum()), menge=("gleiche Abschnitte" if menge is gleich else "alle gültigen"))
    if menge.sum() < B_MIN_VERSCHIEBUNGEN:
        out.update(K=int(menge.sum()), p_placebo=None,
                   grund=f"Placebo zu kurz ({int(menge.sum())} gültige Verschiebungen, nötig {B_MIN_VERSCHIEBUNGEN})")
        return out
    gk = lage(S[ui], C[ui], MI[menge], MO[menge])
    zk = gk["z"][np.isfinite(gk["z"])]
    K = len(zk)
    out["K"] = K
    if K < B_MIN_VERSCHIEBUNGEN:
        out.update(p_placebo=None, grund=f"Placebo zu kurz ({K} gültige Verschiebungen, nötig {B_MIN_VERSCHIEBUNGEN})")
        return out
    out["p_placebo"] = float((1 + np.sum(np.abs(zk) >= abs(z) - 1e-12)) / (1 + K))
    s0 = float(np.sqrt(np.mean(zk * zk)))
    nu_eff = max(1.0, K * 7.0 / L)
    out.update(s0=s0, nu_eff=nu_eff)
    out["p_skaliert"] = float(2 * (1 - _t_cdf(abs(z) / s0, nu_eff))) if s0 > 0 else float("nan")
    out["pruefbar"] = True
    return out


def _t_cdf(x: float, nu: float) -> float:
    import hl_ausblick
    return float(hl_ausblick.t_cdf(np.array([x]), nu)[0])


def _p_bh(t: dict, art: str) -> float:
    return {"placebo": t.get("p_placebo"), "skaliert": t.get("p_skaliert"), "bootstrap": t.get("p_boot")}[art]


def teil_b(D: dict, faelle: list, jetzt: float | None = None, boot: int = B_BOOT, p_fuer_bh: str = B_P_FUER_BH,
           beschreibend: bool = True) -> dict:
    """Hauptfamilie (Regime × Quelle, gepoolt), Benjamini-Hochberg, Urteil (10.7a); je Coin beschreibend -> Ergebnis zum Bericht."""
    t0 = time.time()
    jetzt = time.time() if jetzt is None else float(jetzt)
    schnitt = calendar.timegm(time.strptime(B_URTEIL, "%Y-%m-%d"))
    urteilstag = jetzt >= schnitt
    if urteilstag:                                          # genau ein Urteil: Prognosen bis 14.01.2027 23:59 UTC
        faelle = [x for x in faelle if x[1] < schnitt]
    if not faelle:
        return {"leer": True, "tests": [], "je_coin": [], "urteilstag": urteilstag, "dauer_s": round(time.time() - t0, 2)}
    d0 = int(D["d0"])
    kal = regime_kalender(D)
    erst = min(ts // TAG for _c, ts, *_ in faelle)
    w0 = int(erst) + B_ANLAUF_TAGE
    w1 = int(max(ts // TAG for _c, ts, *_ in faelle))
    out_basis = {"leer": False, "urteilstag": urteilstag, "erst": int(erst), "w0": w0, "w1": w1, "p_fuer_bh": p_fuer_bh,
                 "coins": sorted({c for c, *_ in faelle}), "bloecke": {}, "pool": [c for c in B_POOL]}
    for c in out_basis["coins"]:
        out_basis["bloecke"][c] = sum(1 for x in faelle if x[0] == c and x[1] // TAG >= w0)
    if w1 < w0:
        out_basis.update(anlauf=True, tests=[], je_coin=[], regime=[], n_tests=0, n_pruefbar=0, placebo_unter=0, bh=0, erfuellt=0,
                         belegt=0, dauer_s=round(time.time() - t0, 2))
        return out_basis
    L = w1 - w0 + 1
    mitte = w0 + (L + 1) // 2
    k_min = (w1 - w0) // 7 + 1
    reihen = tagesreihen(faelle, w0, L)
    tests, regime_info, je_coin = [], [], []
    for key, name, *_r in B_REGIME:
        reg = kal.get(key)
        tests_r = []
        for quelle in B_QUELLEN:
            a = _gepoolt(reihen, B_POOL, quelle, L)
            if a is None:
                continue
            t = b_test(reg, d0, w0, L, mitte, k_min, a, seed=zlib.crc32(f"{key}|pool|{quelle}".encode()), boot=boot)
            t.update(key=key, name=name, quelle=quelle)
            tests_r.append(t)
        tests += tests_r
        if beschreibend:
            for coin in out_basis["coins"]:
                for quelle in B_QUELLEN:
                    a = reihen.get((coin, quelle))
                    if a is None:
                        continue
                    t = b_test(reg, d0, w0, L, mitte, k_min, a, seed=zlib.crc32(f"{key}|{coin}|{quelle}".encode()), boot=boot, placebo=False)
                    t.update(key=key, name=name, coin=coin, quelle=quelle)
                    je_coin.append(t)
        tt = np.arange(w0, w1 + 1) - d0
        r = np.full(L, np.nan)
        if reg is not None:
            ok_ax = (tt >= 0) & (tt < len(reg))
            r[ok_ax] = reg[tt[ok_ax]]
        h1 = np.arange(w0, w1 + 1) < mitte
        fin = np.isfinite(r)
        ai, ao = abschnitte(r[fin][None, :]) if fin.any() else (np.zeros(1, int), np.zeros(1, int))
        regime_info.append({"key": key, "name": name, "da": reg is not None, "im": int(np.sum(r == 1)), "aus": int(np.sum(r == 0)),
                            "ohne": int(np.sum(~fin)), "im_h1": int(np.sum((r == 1) & h1)), "aus_h1": int(np.sum((r == 0) & h1)),
                            "im_h2": int(np.sum((r == 1) & ~h1)), "aus_h2": int(np.sum((r == 0) & ~h1)), "ab_i": int(ai[0]), "ab_o": int(ao[0]),
                            "K": max((t.get("K") or 0 for t in tests_r), default=0), "pruefbar": sum(1 for t in tests_r if t["pruefbar"]),
                            "kalender": r})
    pr = [t for t in tests if t["pruefbar"]]
    pw = [_p_bh(t, p_fuer_bh) for t in pr]
    ent = bh(pw) if p_fuer_bh != "bonferroni" else [p <= Q_BH / len(pr) for p in pw]
    for t, e in zip(pr, ent):
        t["bh"] = bool(e)
    for t in tests:
        t["erfuellt"] = bool(t["pruefbar"] and t["p_placebo"] < B_PLACEBO_P and t.get("bh") and t.get("haelften"))
        t["belegt"] = bool(t["erfuellt"] and urteilstag)
    # Zusammenhang der Regime-Kalender im Zeitraum (φ), damit ein Befund in mehreren Regimen als einer erkennbar ist
    paare = []
    ri = [r_ for r_ in regime_info if r_["im"] and r_["aus"]]
    for i in range(len(ri)):
        for j in range(i + 1, len(ri)):
            a_, b_ = ri[i]["kalender"], ri[j]["kalender"]
            m = np.isfinite(a_) & np.isfinite(b_)
            if m.sum() >= 10 and np.std(a_[m]) > 0 and np.std(b_[m]) > 0:
                phi = float(np.corrcoef(a_[m], b_[m])[0, 1])
                if abs(phi) >= 0.5:
                    paare.append((ri[i]["name"], ri[j]["name"], phi))
    for r_ in regime_info:
        r_.pop("kalender", None)
    out_basis.update(tests=tests, je_coin=je_coin, regime=regime_info, L=L, mitte=mitte, k_min=k_min, paare=paare, n_tests=len(tests),
                     n_pruefbar=len(pr), placebo_unter=sum(1 for t in pr if t["p_placebo"] < B_PLACEBO_P),
                     bh=sum(1 for t in pr if t.get("bh")), erfuellt=sum(1 for t in tests if t["erfuellt"]),
                     belegt=sum(1 for t in tests if t["belegt"]), dauer_s=round(time.time() - t0, 2))
    return out_basis


# ------------------------------------------------------------------------------------------------ Kalibrierung Teil B (künstliche Welten)
B_FAMILIEN = ("ar", "weg", "sprung", "buckel", "gleichlauf_03", "gleichlauf_08", "echt")
B_FAMILIEN_ECHT = ("echt", "echt_weg")      # 10.7b: Prüfung auf den echten Kalendern des Pi (Debug-Lauf), Güte zäh bzw. als Zufallsweg


def _guete(rng, n: int, familie: str, staerke: float) -> np.ndarray:
    """Schwankung der Prognosegüte über die Tage (ohne Bezug zum Regime): AR, Zufallsweg, ein Sprung, 1–2 Buckel von 1–3 Wochen."""
    if familie in ("ar", "gleichlauf_03", "gleichlauf_08", "echt"):
        g = _ar1(n, 0.95, rng)
        return staerke * g / max(1e-12, float(np.std(g)))
    if familie in ("weg", "echt_weg"):
        g = np.cumsum(rng.normal(0, 1, n)); g = g - g.mean()
        return staerke * g / max(1e-12, float(np.std(g)))
    if familie == "sprung":
        j = int(rng.integers(n // 5, 4 * n // 5))
        return 2 * staerke * float(rng.choice((-1.0, 1.0))) * (np.arange(n) >= j)
    if familie == "buckel":
        x = np.zeros(n)
        for _ in range(int(rng.integers(1, 3))):
            lb = int(rng.integers(7, 22)); s = int(rng.integers(0, n - lb))
            x[s:s + lb] += 2.5 * staerke * float(rng.choice((-1.0, 1.0)))
        return x
    if familie == "keine":
        return np.zeros(n)
    raise ValueError(familie)


def _welt_b(seed: int, familie: str = "ar", n_hist: int = 2200, n_fenster: int = 127, staerke: float = 0.03, mu: float = 0.01,
            effekt: float = 0.0, effekt_regime: str | None = None, effekt_quellen: tuple = ("v1", "v2"), D_echt: dict | None = None) -> tuple:
    """
    Künstliche Welt (10.7a): Makro-Reihen als zähe AR-Prozesse (Perzentile seit Beginn wie die Zonenkarte; Familien „echt“ und
    „echt_weg“: alle Regime-Reihen aus der echten Ableitung D_echt, Fenster an zufälliger Stelle der Geschichte -- die Prognosen bleiben
    künstlich, es wird kein Ergebnis angesehen), 4-h-Blöcke von 6 Coins in den letzten n_fenster Tagen
    (Gleichlauf über einen Marktfaktor, PAXG ohne), Güte der Quellen über die Tage schwankend nach Familie, ohne Bezug zum Regime.
    effekt > 0: an Tagen im Regime effekt_regime rücken die Quellen effekt_quellen um effekt zur eingetretenen Richtung
    (p + effekt · (2y − 1); rund effekt Brier-Punkte Vorsprung). effekt_regime „auto“: das Regime mit den meisten Tagen auf der
    knapperen Seite im ausgewerteten Teil (nur nach dem Kalender gewählt).
    """
    rng = np.random.default_rng(seed)
    rho = {"gleichlauf_03": 0.3, "gleichlauf_08": 0.8}.get(familie, 0.6)
    if familie in ("echt", "echt_weg"):
        if D_echt is None:
            raise ValueError("Familie „echt“ braucht die echte Ableitung (D_echt)")
        mv = np.asarray(D_echt["MVRV_PZ"], dtype=float)
        erst = int(np.nonzero(np.isfinite(mv))[0][0])
        lo = erst + B_VORGESCHICHTE + 7 * (B_MIN_VERSCHIEBUNGEN + 30) + n_fenster
        e = int(rng.integers(lo, len(mv)))
        n = e + 1; d0 = int(D_echt["d0"])
        sl = lambda x_: None if x_ is None else np.asarray(x_, dtype=float)[:n]
        bg = D_echt.get("BGM") or {}
        D = {"tage": np.asarray(D_echt["tage"][:n], dtype=np.int64), "d0": d0, "P": sl(D_echt["P"]), "MVRV_PZ": mv[:n],
             "FUNDING30_PZ": sl(D_echt.get("FUNDING30_PZ")), "OI_MC_PZ": sl(D_echt.get("OI_MC_PZ")), "DVOL_PZ": sl(D_echt.get("DVOL_PZ")),
             "FNG30": sl(D_echt.get("FNG30")), "OI_ABDECKUNG": D_echt.get("OI_ABDECKUNG") or {},
             "BGM": {"sth-realized-price": sl(bg.get("sth-realized-price", np.full(len(mv), np.nan)))}}
    else:
        n = n_hist; d0 = _tag("2026-11-09") - n_hist                       # Fenster endet immer am 09.11.2026 (vor dem Urteilsschnitt)
        D = {"tage": np.arange(d0, d0 + n, dtype=np.int64), "d0": d0, "P": np.ones(n),
             "MVRV_PZ": _perzentil_expandierend(_ar1(n, 0.997, rng), 365)}
        pz = lambda phi, m: _perzentil_expandierend(_ar1(n, phi, rng), m)
        D.update({"OI_ABDECKUNG": {"lueckenhaft": False}, "FUNDING30_PZ": pz(0.99, 365), "OI_MC_PZ": pz(0.99, 365), "DVOL_PZ": pz(0.98, 180)})
        f = _ar1(n, 0.98, rng); D["FNG30"] = 50 + 25 * f / np.std(f)
        s = _ar1(n, 0.99, rng); D["BGM"] = {"sth-realized-price": 1.0 / (1.0 + 0.1 * s / np.std(s))}
    w_blk = d0 + n - n_fenster
    kal = regime_kalender(D)
    if effekt and effekt_regime == "auto":
        best = -1
        for key, *_x in B_REGIME:
            r = kal[key][w_blk - d0 + B_ANLAUF_TAGE:]
            m = min(int(np.sum(r == 1)), int(np.sum(r == 0)))
            if m > best:
                best, effekt_regime = m, key
    a = {q: mu + _guete(rng, n_fenster, familie, staerke) for q in ("v1", "v2")}
    im = (kal[effekt_regime][w_blk - d0:] == 1) if effekt else np.zeros(n_fenster, dtype=bool)
    v2_da = np.ones(n_fenster, dtype=bool)
    zust = True
    for i in range(n_fenster):
        if rng.random() < (0.05 if zust else 0.12):
            zust = not zust
        v2_da[i] = zust
    faelle = []
    coins = ("BTC", "ETH", "HYPE", "PAXG", "XMR", "ZEC")
    for i in range(n_fenster):
        for j in range(6):
            ts = int((w_blk + i) * TAG + j * 14_400 + 60)
            zm = rng.normal()
            for c in coins:
                if rng.random() < 0.25:
                    continue
                rr = 0.0 if c == "PAXG" else rho
                u = rr * zm + math.sqrt(1 - rr * rr) * rng.normal()
                y = int(u + 3.0 * rng.normal() > 0)
                pb = 0.5 + 0.01 * rng.normal()
                schub = {q_: (effekt * (2 * y - 1) if im[i] and q_ in effekt_quellen else 0.0) for q_ in ("v1", "v2")}
                p1 = min(0.98, max(0.02, 0.5 + a["v1"][i] * u + 0.03 * rng.normal() + schub["v1"]))
                q = {"v1": p1}
                if v2_da[i]:
                    q["v2"] = min(0.98, max(0.02, 0.5 + a["v2"][i] * u + 0.03 * rng.normal() + schub["v2"]))
                q["Fusion"] = 0.4 * p1 + 0.3 * q.get("v2", pb) + 0.3 * pb
                faelle.append((c, ts, y, pb, q))
    return D, faelle, effekt_regime


def _binom_cdf(x: int, n: int, p: float) -> float:
    """P(X ≤ x) der Binomialverteilung, in Logarithmen gerechnet (große n ohne Überlauf)."""
    if x < 0:
        return 0.0
    if p <= 0.0 or x >= n:
        return 1.0
    if p >= 1.0:
        return 0.0
    lp, lq, lg = math.log(p), math.log1p(-p), math.lgamma(n + 1)
    return min(1.0, sum(math.exp(lg - math.lgamma(k + 1) - math.lgamma(n - k + 1) + k * lp + (n - k) * lq) for k in range(x + 1)))


def _cp_oben(x: int, n: int, stufe: float = 0.90) -> float:
    """Obere einseitige Clopper-Pearson-Grenze für x Treffer in n (Bisektion über die Binomialverteilung)."""
    if n <= 0 or x >= n:
        return 1.0
    lo, hi = x / n, 1.0
    for _ in range(60):
        p = (lo + hi) / 2
        if _binom_cdf(x, n, p) > 1 - stufe:
            lo = p
        else:
            hi = p
    return hi


def _cp_unten(x: int, n: int, stufe: float = 0.90) -> float:
    """Untere einseitige Clopper-Pearson-Grenze: kleinstes p mit P(X ≥ x | p) > 1 − stufe."""
    if n <= 0 or x <= 0:
        return 0.0
    lo, hi = 0.0, x / n
    for _ in range(60):
        p = (lo + hi) / 2
        if 1.0 - _binom_cdf(x - 1, n, p) > 1 - stufe:
            hi = p
        else:
            lo = p
    return lo


def kalibrierung_b(welten: int = 400, familien: tuple = B_FAMILIEN, start: int = 90_000, boot: int = 200, D_echt: dict | None = None,
                   verbose: bool = True, **kw) -> dict:
    """Je Familie: Welten ohne Wirkung; zählt Welten mit mindestens einem falschen „alle drei“ für jedes p im Benjamini-Hochberg
    (Placebo, skaliert, Bootstrap) und den Anteil Placebo-p < 0,025 je prüfbarem Test."""
    jetzt = calendar.timegm(time.strptime("2027-01-10", "%Y-%m-%d"))
    erg = {}
    for fam in familien:
        if fam in B_FAMILIEN_ECHT and D_echt is None:
            if verbose:
                print(f"  {fam:<14} übersprungen (ohne echte Ableitung; --db angeben)")
            continue
        z = {"welten": 0, "tests": 0, "pl": 0, "bo": 0, "sk": 0, "fw": {"placebo": 0, "skaliert": 0, "bootstrap": 0}}
        for w in range(welten):
            D, fa, _r = _welt_b(start + w, familie=fam, D_echt=D_echt, **kw)
            E = teil_b(D, fa, jetzt=jetzt, boot=boot, beschreibend=False)
            pr = [t for t in E["tests"] if t["pruefbar"]]
            z["welten"] += 1; z["tests"] += len(pr)
            z["pl"] += sum(1 for t in pr if t["p_placebo"] < B_PLACEBO_P)
            z["bo"] += sum(1 for t in pr if t["p_boot"] < B_PLACEBO_P)
            z["sk"] += sum(1 for t in pr if t["p_skaliert"] < B_PLACEBO_P)
            for art in z["fw"]:
                ent = bh([_p_bh(t, art) for t in pr]) if pr else []
                z["fw"][art] += int(any(e and t["p_placebo"] < B_PLACEBO_P and t["haelften"] for t, e in zip(pr, ent)))
        z["oben"] = {art: _cp_oben(v, z["welten"]) for art, v in z["fw"].items()}
        z["oben_test"] = {art: _cp_oben(z[k_], z["tests"]) for art, k_ in (("placebo", "pl"), ("skaliert", "sk"), ("bootstrap", "bo"))}
        z["unten_test"] = {art: _cp_unten(z[k_], z["tests"]) for art, k_ in (("placebo", "pl"), ("skaliert", "sk"), ("bootstrap", "bo"))}
        z["unten"] = {art: _cp_unten(v, z["welten"]) for art, v in z["fw"].items()}
        erg[fam] = z
        if verbose:
            T = max(1, z["tests"])
            print((f"  {fam:<14} {z['welten']} Welten, {z['tests'] / max(1, z['welten']):.1f} prüfbare Tests je Welt · je Test p < 0.025 "
                   f"(obere 90-%-Grenze): Placebo {z['pl'] / T:.1%} ({z['oben_test']['placebo']:.1%}), skaliert {z['sk'] / T:.1%} "
                   f"({z['oben_test']['skaliert']:.1%}), Bootstrap {z['bo'] / T:.1%} ({z['oben_test']['bootstrap']:.1%}) · Welten mit falschem "
                   "„alle drei“: " + " · ".join(f"{art} {v / z['welten']:.1%} ({z['oben'][art]:.1%})" for art, v in z["fw"].items()))
                  .replace(".", ","), flush=True)
    return erg


def entscheidung_b(erg: dict, staerke: dict | None = None) -> str:
    """Regel 10.7a mit Ergänzung 10.7b: Ein p besteht, wenn es je Test gültig ist -- kein Beleg für zu viele Fehlurteile, d. h. die untere
    90-%-Grenze des Anteils p < 0,025 liegt nicht über 2,5 % (sonst prüft Benjamini-Hochberg nichts, und die Fehlerrate hinge allein am
    Placebo-Tor und an der Zahl prüfbarer Tests) -- UND in jeder Familie die obere 90-%-Grenze der Welten mit falschem „alle drei“
    höchstens 10 % ist; von den bestehenden das mit der größeren Teststärke; besteht keins: Bonferroni über das Placebo-p."""
    besteht = [art for art in ("placebo", "skaliert", "bootstrap")
               if erg and all(z["unten_test"][art] <= B_PLACEBO_P and z["oben"][art] <= 0.10 for z in erg.values())]
    if not besteht:
        return "bonferroni"
    if staerke and len(besteht) > 1:
        return max(besteht, key=lambda a_: staerke["fund"][a_])
    return besteht[0]


def staerke_b(welten: int = 200, effekt: float = 0.01, start: int = 95_000, boot: int = 200, verbose: bool = True, **kw) -> dict:
    """Teststärke: Vorsprung im Regime (Wahl „auto“ nach dem Kalender) für v1 und v2; Anteil der Welten, in denen ein Test dieses
    Regimes „alle drei“ erfüllt, je p im Benjamini-Hochberg; daneben falsche Funde in anderen Regimen."""
    jetzt = calendar.timegm(time.strptime("2027-01-10", "%Y-%m-%d"))
    z = {"welten": 0, "pruefbar": 0, "fund": {"placebo": 0, "skaliert": 0, "bootstrap": 0}, "andere": {"placebo": 0, "skaliert": 0, "bootstrap": 0}}
    for w in range(welten):
        D, fa, rk = _welt_b(start + w, familie="ar", effekt=effekt, effekt_regime="auto", **kw)
        E = teil_b(D, fa, jetzt=jetzt, boot=boot, beschreibend=False)
        pr = [t for t in E["tests"] if t["pruefbar"]]
        z["welten"] += 1
        z["pruefbar"] += int(any(t["key"] == rk for t in pr))
        for art in z["fund"]:
            ent = bh([_p_bh(t, art) for t in pr]) if pr else []
            erf = [t for t, e in zip(pr, ent) if e and t["p_placebo"] < B_PLACEBO_P and t["haelften"]]
            z["fund"][art] += int(any(t["key"] == rk for t in erf))
            z["andere"][art] += sum(1 for t in erf if t["key"] != rk)
    if verbose:
        print((f"  Teststärke Vorsprung {effekt} ({effekt * 400:.0f} Skill-Punkte) für v1 und v2: {z['welten']} Welten, Regime prüfbar in "
               f"{z['pruefbar']} · Fund im Regime: " + " · ".join(f"{a} {v / z['welten']:.0%}" for a, v in z["fund"].items())
               + " · Funde in anderen Regimen: " + " · ".join(f"{a} {v}" for a, v in z["andere"].items())).replace(".", ","), flush=True)
    return z


# ------------------------------------------------------------------------------------------------ Bericht Teil B

def _datum(tag: int | None, fmt: str = "%d.%m.%Y") -> str:
    return time.strftime(fmt, time.gmtime(int(tag) * TAG)) if tag is not None else "—"


def _werkzeug() -> str:
    """Fingerabdruck des Werkzeugs (10.7a: eingefroren mit 23.85) und Stand des Pakets."""
    import hashlib
    try:
        with open(os.path.abspath(__file__), "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest()[:12]
    except OSError:
        h = "?"
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import version
        st = version.stand()
    except Exception:
        st = "?"
    return f"hl_makro_korr.py sha256 {h} · Paket {st}"


def bericht_b_text(E: dict) -> str:
    k = lambda v, d=1: "—" if v is None or not (isinstance(v, (int, float)) and math.isfinite(v)) else f"{v:+.{d}f}".replace(".", ",")
    kopf = "Makro-Regime × 4-h-Prognosen (U130, Teil B)"
    if E.get("leer"):
        return f"{kopf}: keine aufgelösten 4-h-Blöcke in fusion_fall (forecasts.db) -- nichts zu prüfen"
    regel = ["  Vorab festgelegt: KONZEPT_Makro.md 10.2 (05.10.2026 19:15), 10.7 (25.10.2026 23:18), 10.7a (25.10.2026 23:35, nach",
             "  unabhängiger Durchsicht). Hauptfamilie: je Regime und Quelle die Krypto-Coins " + ", ".join(E["pool"]) + " zusammen (27 Tests),",
             "  Tage als Klumpen; je Coin nur beschreibend. Regime am Tag t aus Werten vom Tag t − 2 (Kurzfrist-Kostenbasis t − 9).",
             "  Maß: Brier-Vorsprung gegen die Basisrate als Skill in % (positiv = besser als die Basisrate), im Regime minus außerhalb.",
             f"  Belegt nur: Placebo-p < 0,025 UND Benjamini-Hochberg q = 0,10 (über das {dict(placebo='Placebo-p', skaliert='am Placebo skalierte p', bootstrap='Bootstrap-p', bonferroni='Placebo-p, Bonferroni').get(E['p_fuer_bh'], E['p_fuer_bh'])})",
             "  UND gleiches Vorzeichen in beiden Hälften. Genau ein Urteil: am 15.01.2027, Prognosen bis 14.01.2027 23:59 UTC -- "
             + ("dieser Lauf IST das Urteil (Zeitraum eingefroren)." if E["urteilstag"] else "dieser Lauf ist beschreibend."),
             f"  Werkzeug: {_werkzeug()}"]
    if E.get("anlauf"):
        return "\n".join([f"{kopf} -- noch im Anlauf: erster Block am {_datum(E['erst'])}, ausgewertet wird ab dem {_datum(E['w0'])} "
                          f"(29. Tag; Anlauf der Basisrate, 10.7a). Noch nichts zu prüfen."] + regel)
    L = E["L"]
    z = [f"{kopf} -- ausgewertet {_datum(E['w0'], '%d.%m.')}–{_datum(E['w1'])} ({L} Tage; Anlauf bis {_datum(E['w0'] - 1, '%d.%m.')} "
         f"ausgelassen; Hälften bis {_datum(E['mitte'] - 1, '%d.%m.')} / ab {_datum(E['mitte'], '%d.%m.')}), gerechnet in "
         + f"{E['dauer_s']:.1f} s".replace(".", ",")] + regel
    z.append("  Blöcke mit Richtung im ausgewerteten Zeitraum: " + " · ".join(f"{c} {n}" for c, n in E["bloecke"].items())
             + (" (PAXG nur je Coin)" if "PAXG" in E["bloecke"] else ""))
    z += ["", f"  {'Regime (Tage im Zeitraum)':<34} {'im':>4} {'außer':>5} {'ohne':>4} {'Abschn. im/außer':>17} {'1. Hälfte':>10} "
              f"{'2. Hälfte':>10} {'Verschieb.':>10}  prüfbar"]
    je = {}
    for t in E["tests"]:
        je.setdefault(t["key"], []).append(t)
    for r in E["regime"]:
        tr = je.get(r["key"], [])
        grund = ""
        if not r["da"]:
            grund = " -- keine Daten (Quelle fehlt oder Archiv lückenhaft)"
        elif not r["pruefbar"]:
            gr = [t.get("grund") for t in tr if t.get("grund")]
            grund = f" -- {gr[0]}" if gr else ""
        z.append(f"  {r['name'][:34]:<34} {r['im']:>4} {r['aus']:>5} {r['ohne']:>4} {r['ab_i']:>8} / {r['ab_o']:<6} "
                 f"{r['im_h1']:>4}/{r['aus_h1']:<5} {r['im_h2']:>4}/{r['aus_h2']:<5} {(str(r['K']) if r['K'] else '—'):>10}  "
                 f"{r['pruefbar']} von {len(tr)}{grund}")
    zeilen = [t for t in E["tests"] if t.get("delta") is not None]
    z += ["", "  Hauptfamilie (Krypto-Coins zusammen)" + ("" if zeilen else ": kein Regime mit genug Tagen und Abschnitten auf beiden Seiten")]
    if zeilen:
        z.append(f"  {'Regime · Quelle':<40} {'Tage':>7} {'Skill im':>8} {'außer':>6} {'Unterschied [90 %]':>22} {'Richtung/Sicherh.':>18} "
                 f"{'z (ν)':>11} {'Placebo-p (K)':>14} {'BH-p':>6} {'Hälften':>13} {'Treffer im/außer':>16}  Urteil")
        for t in zeilen:
            pp = "—" if t.get("p_placebo") is None else f"{t['p_placebo']:.3f} ({t['K']})".replace(".", ",")
            pb_ = _p_bh(t, E["p_fuer_bh"] if E["p_fuer_bh"] != "bonferroni" else "placebo")
            pb = "—" if pb_ is None or not math.isfinite(pb_) else f"{pb_:.3f}".replace(".", ",")
            bb = t["brier_basis"]
            ha = (f"{k(t['d_h1'] * 100 / bb if t['d_h1'] is not None else None)}/{k(t['d_h2'] * 100 / bb if t['d_h2'] is not None else None)}"
                  + (" ✓" if t["haelften"] else ""))
            if t["belegt"]:
                u = "BELEGT"
            elif t["erfuellt"]:
                u = "alle drei erfüllt (vor dem Urteil)"
            elif not t["pruefbar"]:
                u = "nicht prüfbar: " + t.get("grund", "")
            else:
                teile = [n for n, ok in (("Placebo", t["p_placebo"] < B_PLACEBO_P), ("BH", t.get("bh")), ("Hälften", t["haelften"])) if ok]
                u = "nein" + (f" ({', '.join(teile)} ja)" if teile else "")
            if t.get("erfuellt") and abs(t["d_sicherheit"]) > abs(t["d_richtung"]):
                u += " -- überwiegend Sicherheitsteil: die Quelle ist im Regime vorsichtiger/kühner, nicht treffsicherer (10.7a)"
            z.append(f"  {(t['name'] + ' · ' + t['quelle'])[:40]:<40} {t['n_i']:>3}/{t['n_o']:<3} {k(t['skill_i']):>8} {k(t['skill_o']):>6} "
                     f"{k(t['d_skill']):>6} [{k(t['lo90_skill'])}; {k(t['hi90_skill'])}]".ljust(84)
                     + f" {k(t['d_richtung'])}/{k(-t['d_sicherheit'])}".rjust(18)
                     + f" {k(t['z'], 2)} ({t['nu']:.0f})".rjust(12) + f" {pp:>14} {pb:>6} {ha:>13} "
                     + f"{t['treffer_i'] * 100:5.1f}/{t['treffer_o'] * 100:4.1f} %".replace(".", ",") + f"  {u}")
    n = E["n_pruefbar"]
    z += ["", f"  Zusammen: {n} prüfbare Tests von {E['n_tests']} · Placebo-p < 0,025: {E['placebo_unter']} (Zufall allein ≈ "
              f"{n * B_PLACEBO_P:.1f}) · Benjamini-Hochberg: {E['bh']} · alle drei: {E['erfuellt']}".replace(".", ",")
          + (f" · BELEGT: {E['belegt']}" if E["urteilstag"] else " (vor dem Urteil kein Befund)")]
    if E.get("paare"):
        z.append("  Zusammenhängende Regime-Kalender im Zeitraum (|φ| ≥ 0,5 -- ein Befund in beiden kann derselbe sein): "
                 + " · ".join(f"{a} ~ {b} {k(p_, 2)}" for a, b, p_ in E["paare"]))
    jc = [t for t in E.get("je_coin", []) if t.get("delta") is not None]
    if jc:
        z += ["", "  Je Coin, nur beschreibend (Unterschied in Skill-Punkten im Regime minus außerhalb [90 %], ohne p und ohne Urteil):"]
        for r in E["regime"]:
            tr = [t for t in jc if t["key"] == r["key"]]
            if not tr:
                continue
            z.append(f"    {r['name']}:")
            for coin in E["coins"]:
                tc = [t for t in tr if t["coin"] == coin]
                if tc:
                    z.append(f"      {coin:<5} " + " · ".join(f"{t['quelle']} {k(t['d_skill'])} [{k(t['lo90_skill'])}; {k(t['hi90_skill'])}]" for t in tc))
    z += ["", "  Skill = 100 × Brier-Vorsprung ÷ Brier der Basisrate über alle Blöcke des Tests. Richtung/Sicherheit = der Unterschied zerlegt in",
          "  den Richtungsteil 2δ(y − p_Basis) und den Sicherheitsteil −δ² (δ = p_Quelle − p_Basis; Summe = Unterschied). 90 % = Bootstrap",
          "  über ganze Tage (je Seite getrennt). z = Welch-Lage (ν Freiheitsgrade der Tage). Placebo-p = Anteil der um ganze Wochen",
          "  verschobenen Kalender (vor dem Zeitraum, ≥ 2 Jahre Vorgeschichte, gleiche Zahl von Abschnitten ±1, sonst alle gültigen) mit",
          "  mindestens so großem |z|; K = deren Zahl. Treffer = Trefferquote der Quelle, nur beschreibend. Nötig je Seite 20 Tage in",
          "  mindestens 2 Abschnitten, in jeder Hälfte 7 Tage je Seite."]
    return "\n".join(z)


# ================================================================================================ Kalibrierung und Selbsttest

def _ar1(n: int, phi: float, rng) -> np.ndarray:
    e = rng.normal(0, 1, n); x = np.empty(n); x[0] = e[0] / math.sqrt(max(1e-9, 1 - phi * phi))
    for i in range(1, n):
        x[i] = phi * x[i - 1] + e[i]
    return x


def _perzentil_expandierend(x: np.ndarray, min_n: int = 365) -> np.ndarray:
    import bisect
    out = np.full(len(x), np.nan); sl: list = []
    for i, v in enumerate(x):
        bisect.insort(sl, v)
        if len(sl) >= min_n:
            lo = bisect.bisect_left(sl, v); hi = bisect.bisect_right(sl, v)
            out[i] = 100.0 * (lo + 0.5 * (hi - lo - 1)) / (len(sl) - 1)
    return out


def _markt(n: int, rng, art: str) -> tuple:
    """Zufallsweg-Rendite (mit Volatilitäts-Clustern) und ein UNABHÄNGIGES, zähes Merkmal."""
    lv = _ar1(n, 0.98, rng) * 0.25                                       # Log-Volatilität mit Gedächtnis
    P = np.exp(np.cumsum(0.035 * np.exp(lv - 0.03) * rng.normal(0, 1, n)))
    if art == "ar":
        x = _ar1(n, 0.995, rng)
    elif art == "pz":
        x = _perzentil_expandierend(np.cumsum(rng.normal(0, 1, n)))
    else:                                                                # 30-Tage-Mittel einer zähen Größe (wie Funding 30 T)
        k = _ar1(n, 0.9, rng); x = np.convolve(k, np.ones(30) / 30, mode="full")[:n]; x[:29] = np.nan
    return P, x


def _block_null(x, y, h, rng, k=200):
    """Blockbootstrap-Null: Merkmal in Blöcken der Länge h neu gezogen, Renditen fest (zum Vergleich in der Kalibrierung)."""
    ok = np.isfinite(x) & np.isfinite(y); xs, ys = x[ok], y[ok]; n = len(xs); b = max(1, h)
    ry = raenge(ys); zy = ry - ry.mean(); out = np.empty(k)
    starts_n = n - b + 1
    for j in range(k):
        st = rng.integers(0, starts_n, int(math.ceil(n / b)))
        idx = (st[:, None] + np.arange(b)[None, :]).ravel()[:n]
        rx = raenge(xs[idx]); zx = rx - rx.mean()
        out[j] = np.dot(zx, zy) / math.sqrt(np.dot(zx, zx) * np.dot(zy, zy))
    return out


def kalibrierung(maerkte: int = 150, n: int = 4000, mit_block: bool = False, k_phasen: int = K_PHASEN, start: int = 1000,
                 verbose: bool = True) -> dict:
    """
    Fehlurteile (p < 0,01 / 0,05 / 0,10) auf Zufallswegen (mit Volatilitäts-Clustern) mit UNABHÄNGIGEN, zähen Merkmalen (AR 0,995,
    Perzentil eines Zufallswegs, 30-Tage-Mittel): Phasen-Randomisierung gegen zirkuläre Verschiebung (und optional Blockbootstrap).
    """
    zaehl: dict = {}

    def zaehle(meth, art, h, p):
        e = zaehl.setdefault((meth, art, h), [0, 0, 0, 0])
        e[0] += 1; e[1] += int(p < 0.01); e[2] += int(p < 0.05); e[3] += int(p < 0.10)

    for s in range(maerkte):
        rng = np.random.default_rng(start + s)
        for art in ("ar", "pz", "mittel30"):
            P, x = _markt(n, rng, art)
            for h in HORIZONTE:
                y = vorwaerts(P, h)
                rho, null, _n = phasen_null(x, y, k_phasen, seed=start + s)
                zaehle("phasen", art, h, p_zweiseitig(rho, null))
                rho_v, null_v, _n = verschiebungen(x, y)
                zaehle("verschiebung", art, h, p_zweiseitig(rho_v, null_v))
                if mit_block:
                    nb = _block_null(x, y, h, rng)
                    zaehle("block", art, h, float((1 + np.sum(np.abs(nb) >= abs(rho))) / (1 + len(nb))))
    if verbose:
        for (meth, art, h), (k, f1, f5, f10) in sorted(zaehl.items()):
            print(f"  {meth:<13} {art:<9} h {h:>2}: p < 0,01 {f1 / k:5.1%}, p < 0,05 {f5 / k:5.1%}, p < 0,10 {f10 / k:5.1%} (n {k})".replace(".", ","))
    return zaehl


def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    rng = np.random.default_rng(5)
    # 1) Ränge, Spearman, FFT-Verschiebung gegen direkte Rechnung
    a = np.array([3.0, 1.0, 2.0, 2.0, 5.0]); rk = raenge(a)
    x = rng.normal(0, 1, 900); y = 0.3 * x + rng.normal(0, 1, 900); x[::50] = np.round(x[::50], 1)
    rho, null, n = verschiebungen(x, y, 100)
    rx, ry = raenge(x), raenge(y)
    direkt = [float(np.corrcoef(np.roll(rx, k), ry)[0, 1]) for k in (100, 250, 800)]
    fft = [null[k - 100] for k in (100, 250, 800)]
    # Phasen-Null: bei unabhängigen Renditen ist die Streuung von ρ theoretisch 1/√n -- unabhängig von der Zähigkeit des Merkmals
    g = np.random.default_rng(11); n_ = 3000
    xa = _ar1(n_, 0.995, g); ya = g.normal(0, 1, n_)
    rho_a, null_a, _n = phasen_null(xa, ya, 4000, seed=1)
    rho_b, null_b, _n = phasen_null(ya, ya, 500, seed=2)
    sd_ok = abs(float(np.std(null_a)) * math.sqrt(n_) - 1) < 0.06
    ok("Ränge (Gleichstände gemittelt), Spearman, Verschiebungen per FFT = direkte Rechnung; Phasen-Null: Streuung 1/√n, ρ = 1 außerhalb",
       list(rk) == [4.0, 1.0, 2.5, 2.5, 5.0] and abs(rho - spearman(x, y)) < 1e-12 and max(abs(d - f) for d, f in zip(direkt, fft)) < 1e-9
       and len(null) == 900 - 200 + 1 and sd_ok and abs(rho_b - 1) < 1e-12 and p_zweiseitig(rho_b, null_b) < 0.003,
       f"Streuung × √n {np.std(null_a) * math.sqrt(n_):.3f} (Soll 1)")
    # 2) Rendite vorwärts, nie derselbe Tag; Benjamini-Hochberg wie von Hand
    P = np.exp(np.arange(10) * 0.1)
    r1, r3 = vorwaerts(P, 1), vorwaerts(P, 3)
    b = bh([0.001, 0.02, 0.03, 0.04, 0.5], 0.10)
    ok("Rendite vorwärts r(t → t+h), am Ende leer; Benjamini-Hochberg (q 0,10) wie von Hand",
       abs(r1[0] - 0.1) < 1e-12 and abs(r3[5] - 0.3) < 1e-12 and np.isnan(r1[-1]) and np.isnan(r3[-3]) and np.isfinite(r3[-4])
       and b == [True, True, True, True, False] and bh([0.06, 0.5], 0.10) == [False, False] and bh([0.04, 0.5], 0.10) == [True, False], f"BH {b}")
    # 3) Nulltest: Zufallswege mit unabhängigen, zähen Merkmalen -> Fehlurteile nahe 5 %
    zl = kalibrierung(maerkte=24, n=3000, k_phasen=1000, start=7000, verbose=False)
    ph = [v for (m, *_), v in zl.items() if m == "phasen"]
    k = sum(v[0] for v in ph); f1 = sum(v[1] for v in ph); f5 = sum(v[2] for v in ph); f10 = sum(v[3] for v in ph)
    ok("Nulltest: Zufallswege, unabhängige zähe Merkmale (AR 0,995, Perzentil, 30-T-Mittel) -> p < 0,05 in höchstens 8 %, p < 0,01 in 2,5 %",
       f5 <= 0.08 * k and f1 <= 0.025 * k and f10 <= 0.14 * k,
       f"Phasen-Null: p < 0,01 in {f1 / k:.1%}, p < 0,05 in {f5 / k:.1%}, p < 0,10 in {f10 / k:.1%} von {k} Tests".replace(".", ","))
    # 4) Positivkontrolle: Merkmal sagt die Rendite des nächsten Tags schwach voraus (ρ ≈ 0,08) -> belegt, Vorzeichen richtig
    treffer = 0
    for s in range(10):
        g = np.random.default_rng(300 + s); n_ = 4000
        zz = _ar1(n_, 0.99, g); zz = zz / zz.std()
        r = 0.035 * (0.12 * np.concatenate([[0.0], zz[:-1]]) + g.normal(0, 1, n_))
        P_ = np.exp(np.cumsum(r)); tage_ = np.arange(_tag("2015-01-01"), _tag("2015-01-01") + n_)
        t = pruefe(zz, vorwaerts(P_, 1), tage_, _tag(GRENZE_HAELFTE), seed=s, k=1000)
        treffer += int(t["p"] < 0.01 and t["rho"] > 0 and haelften_ok(t))
    ok("Positivkontrolle: echter Vorlauf (ρ ≈ 0,12 auf 1 Tag) -> p < 0,01 und beide Hälften in mindestens 9 von 10 Märkten",
       treffer >= 9, f"{treffer} von 10")
    # 5) Ära: Niveau des Merkmals und Drift der Rendite wechseln gemeinsam, sonst kein Zusammenhang -> Hälften verhindern „belegt“
    g = np.random.default_rng(77); n_ = 4000; tage_ = np.arange(_tag("2015-01-01"), _tag("2015-01-01") + n_)
    grenze_i = int(np.searchsorted(tage_, _tag(GRENZE_HAELFTE)))
    xx = _ar1(n_, 0.99, g) * 0.3 + np.where(np.arange(n_) < grenze_i, 1.0, -1.0)
    rr = g.normal(0, 0.03, n_) + np.where(np.arange(n_) < grenze_i, 0.004, -0.002)
    t = pruefe(xx, vorwaerts(np.exp(np.cumsum(rr)), 30), tage_, _tag(GRENZE_HAELFTE), k=1000)
    ok("Ära: gemeinsamer Wechsel von Niveau und Drift -> Ganzprobe auffällig, Hälften nicht -> nicht belegt",
       t["rho"] > 0.1 and not haelften_ok(t), f"ρ {t['rho']:.2f}, Hälften {t['rho_h1']:+.2f} / {t['rho_h2']:+.2f}".replace(".", ","))
    # 5b) Hälften: gleiches Vorzeichen allein reicht nicht, |ρ| ≥ 0,05 in beiden; FRED-Merkmal nimmt den Wert von t − 7
    schwelle = (not haelften_ok({"rho": 0.035, "rho_h1": 0.03, "rho_h2": 0.04}) and haelften_ok({"rho": 0.065, "rho_h1": 0.06, "rho_h2": 0.07})
                and not haelften_ok({"rho": 0.06, "rho_h1": 0.08, "rho_h2": -0.07}))
    tf = np.arange(_tag("2020-01-01"), _tag("2020-01-01") + 200)
    Df = {"tage": tf, "d0": int(tf[0]), "P": np.ones(200), "R": lambda name: (tf, (tf - tf[0]).astype(float) ** 2) if name == "fred:DFII10" else (tf[:0], np.zeros(0))}
    rz = [a for k_, _n, a, _h, _s in merkmale(Df) if k_ == "realzins4w"][0]
    i = 100
    fred_ok = rz is not None and abs(rz[i] - ((i - FRED_VERSATZ) ** 2 - (i - FRED_VERSATZ - 28) ** 2)) < 1e-9
    drei = (urteil({"bh": True, "haelften": True, "nach_widerspruch": False}) and not urteil({"bh": False, "haelften": True})
            and not urteil({"bh": True, "haelften": False}) and not urteil({"bh": True, "haelften": True, "nach_widerspruch": True}))
    ok("Urteil braucht alle drei Bedingungen; Hälften: |ρ| ≥ 0,05 in beiden, gleiches Vorzeichen; FRED = Wert von t − 7 gegen t − 35",
       schwelle and fred_ok and drei, f"Realzins am Tag 100: {rz[i] if rz is not None else '—'}")
    # 6) zu kurz (ETF seit 2024): keine Nullverteilung, kein Urteil, kein Absturz
    t = pruefe(rng.normal(0, 1, 650), rng.normal(0, 1, 650), np.arange(_tag("2024-01-11"), _tag("2024-01-11") + 650), _tag(GRENZE_HAELFTE), k=200)
    ok("Zu kurze Reihe (650 Tage): keine Nullverteilung, kein p, kein Urteil", t.get("zu_kurz") and t.get("p") is None and not haelften_ok(t),
       f"{t['n']} Tage")
    # 7) Ganze Auswertung auf einer kleinen Ableitung (Kurs + zwei Merkmale + leere FRED) und Bericht; Nachrechnung mit Abweichung
    n_ = 3000; g = np.random.default_rng(9); tage_ = np.arange(_tag("2016-01-01"), _tag("2016-01-01") + n_)
    Dm = {"tage": tage_, "d0": int(tage_[0]), "P": np.exp(np.cumsum(g.normal(0, 0.03, n_))), "MVRV_PZ": _perzentil_expandierend(np.cumsum(g.normal(0, 1, n_))),
          "FUNDING30": np.convolve(_ar1(n_, 0.9, g), np.ones(30) / 30, mode="full")[:n_], "OI_ABDECKUNG": {"lueckenhaft": True, "tage": 30, "soll": 2000}}
    stand = [("2024-03-01", "mvrv_pz", float(Dm["MVRV_PZ"][2900])), ("2024-03-01", "mvrv_datentag", float(tage_[2900])),
             ("2024-03-01", "funding", 1.234), ("2024-03-01", "funding_datentag", float(tage_[2900]))]
    A = auswertung(Dm, stand)
    txt = bericht_text(A)
    keys = {t["key"] for t in A["tests"]}
    nn = A["nachrechnung"]["je_merkmal"]
    ok("Auswertung: Tests je Merkmal und Horizont, fehlende Merkmale benannt (OI lädt), Nachrechnung erkennt Abweichung, Bericht",
       keys == {"mvrv_pz", "funding30"} and len(A["tests"]) == 6 and any(f["key"] == "oi" for f in A["fehlt"])
       and nn.get("mvrv_pz", {}).get("abweichend") == 0 and nn.get("funding30", {}).get("abweichend") == 1
       and all(t["nach_widerspruch"] for t in A["tests"] if t["key"] == "funding30") and not any(t["nach_widerspruch"] for t in A["tests"] if t["key"] == "mvrv_pz")
       and all(not t["belegt"] for t in A["tests"] if t["key"] == "funding30") and "Benjamini-Hochberg" in txt and "OI" in txt,
       f"{A['n_tests']} Tests, {len(A['fehlt'])} nicht prüfbar, Nachrechnung {A['nachrechnung']['n']} Werte")
    # 8) 23.56 (U135): am offenen Tag festgeschrieben (DVOL, ETF) ist kein Widerspruch; ein abgeschlossener Tag mit Revision schon;
    #    andere Kennzahlen prüfen auch am selben Tag (Coin Metrics, Funding … sind beim Festschreiben endgültig)
    n_ = 3000; g = np.random.default_rng(12); tage_ = np.arange(_tag("2016-01-01"), _tag("2016-01-01") + n_)
    Dv = {"tage": tage_, "d0": int(tage_[0]), "P": np.exp(np.cumsum(g.normal(0, 0.03, n_))), "DVOL": 50 + 10 * _ar1(n_, 0.98, g),
          "ETF_BTC_30": np.cumsum(g.normal(0, 30, n_)), "MVRV_PZ": _perzentil_expandierend(np.cumsum(g.normal(0, 1, n_))),
          "OI_ABDECKUNG": {"lueckenhaft": True, "tage": 30, "soll": 2000}}
    i_ = n_ - 1; tag_i = lambda i: time.strftime("%Y-%m-%d", time.gmtime(int(tage_[i]) * TAG))
    stand = [(tag_i(i_), "dvol", float(Dv["DVOL"][i_]) + 0.13), (tag_i(i_), "dvol_datentag", float(tage_[i_])),      # offener Tag
             (tag_i(i_), "etf", float(Dv["ETF_BTC_30"][i_]) + 89.8), (tag_i(i_), "etf_datentag", float(tage_[i_])),
             (tag_i(i_ - 1), "etf", float(Dv["ETF_BTC_30"][i_ - 2]) - 5.0), (tag_i(i_ - 1), "etf_datentag", float(tage_[i_ - 2])),
             (tag_i(i_), "mvrv_pz", float(Dv["MVRV_PZ"][i_]) + 1.0), (tag_i(i_), "mvrv_datentag", float(tage_[i_])),      # selber Tag
             (tag_i(i_ - 3), "dvol", float(Dv["DVOL"][i_ - 9]) + 2.0), (tag_i(i_ - 3), "dvol_datentag", float(tage_[i_ - 9])),  # Revision
             (tag_i(i_ - 4), "etf", float(Dv["ETF_BTC_30"][i_ - 12])), (tag_i(i_ - 4), "etf_datentag", float(tage_[i_ - 12]))]
    A = auswertung(Dv, stand)
    je = A["nachrechnung"]["je_merkmal"]; txt = bericht_text(A)
    w_ = {t["key"]: t["nach_widerspruch"] for t in A["tests"]}
    ok("Nachrechnung: am offenen Tag festgeschrieben (DVOL, ETF) -> vorläufig, kein Widerspruch; abgeschlossener Tag mit Revision -> "
       "abweichend; Coin Metrics auch am selben Tag geprüft",
       je.get("dvol", {}).get("vorlaeufig") == 1 and je.get("dvol", {}).get("abweichend") == 1 and je.get("dvol", {}).get("n") == 1
       and je.get("etf30", {}).get("vorlaeufig") == 2 and je.get("etf30", {}).get("abweichend") == 0 and je.get("etf30", {}).get("n") == 1
       and je.get("mvrv_pz", {}).get("abweichend") == 1 and je.get("mvrv_pz", {}).get("vorlaeufig") == 0
       and A["nachrechnung"]["n"] == 3 and A["nachrechnung"]["n_vorlaeufig"] == 3
       and w_.get("dvol") is True and w_.get("etf30") is False and w_.get("mvrv_pz") is True
       and "am offenen Tag festgeschrieben (Tageswert noch vorläufig, nicht geprüft): dvol 1, etf30 2" in txt
       and "ABWEICHEND: " in txt and "etf30 0 von" not in txt,
       f"geprüft {A['nachrechnung']['n']}, vorläufig {A['nachrechnung']['n_vorlaeufig']}, abweichend "
       + ", ".join(f"{k} {v['abweichend']}" for k, v in je.items()))
    if verbose:
        for name, gut, txt_ in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<64} {txt_.replace('.', ',')}")
    return all(p[1] for p in pruef), pruef


def probe_b(verbose: bool = True) -> tuple:
    """23.85: Teil B (10.7, 10.7a, 10.7b) und U229 -- Verzug und Kalender, Statistik von Hand, Anlauf und Hälften, Placebo von Hand,
    Nulltest, Positivkontrolle, Falle, Urteilstag mit eingefrorenem Zeitraum, Bericht, Ende zu Ende über die Dateien, SSR-Diagnose."""
    import json
    import shutil
    import sqlite3
    import tempfile
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    vor = calendar.timegm(time.strptime("2026-12-01", "%Y-%m-%d"))
    nach = calendar.timegm(time.strptime("2027-01-20", "%Y-%m-%d"))
    # B0) die vorab festgelegten Zahlen (10.7, 10.7a, 10.7b) stehen so im Werkzeug
    soll = {"B_H": 4, "B_QUELLEN": ("v1", "v2", "Fusion"), "B_POOL": ("BTC", "ETH", "HYPE", "XMR", "ZEC"), "B_VERZUG": 2, "B_VERZUG_BGM": 9,
            "B_MAX_ALTER": 3, "B_ANLAUF_TAGE": 28, "B_MIN_TAGE": 20, "B_MIN_ABSCHNITTE": 2, "B_MIN_TAGE_HAELFTE": 7, "B_MIN_VERSCHIEBUNGEN": 40,
            "B_VORGESCHICHTE": 730, "B_ABSCHNITTE_TOL": 1, "B_PLACEBO_P": 0.025, "B_BOOT": 2000, "B_URTEIL": "2027-01-15", "B_P_FUER_BH": "placebo",
            "Q_BH": 0.10, "SSR_OFFEN_TAGE": 2}
    ist = {k: globals()[k] for k in soll}
    schwellen = [(k_, r_[3], r_[4], r_[5]) for r_ in B_REGIME for k_ in [r_[0]]]
    ok("Teil B Zahlen wie vorab festgelegt (Verzug 2/9, Höchstalter 3, Anlauf 28, je Seite 20 Tage in 2 Abschnitten, Hälften 7, Placebo 40 "
       "Verschiebungen aus 2 Jahren Vorgeschichte, ±1 Abschnitt, Urteil 15.01.2027, Pool ohne PAXG, Placebo-p im BH, neun Teilungen)",
       ist == soll and schwellen == [("funding_hoch", ">=", 200 / 3, 2), ("oi_hoch", ">=", 200 / 3, 2), ("dvol_hoch", ">=", 200 / 3, 2),
                                    ("dvol_tief", "<=", 100 / 3, 2), ("fng_gier", ">=", 75.0, 2), ("fng_angst", "<=", 25.0, 2),
                                    ("unter_sth", "<", 0.0, 9), ("mvrv_hoch", ">=", 200 / 3, 2), ("mvrv_tief", "<=", 100 / 3, 2)],
       ", ".join(f"{k} {v}" for k, v in ist.items() if v != soll[k]) or "alle wie festgelegt")
    # B1) Kalender: Verzug 2 (Kurzfrist-Kostenbasis 9), Höchstalter 3 ab t − Verzug, Schwellen, OI lückenhaft -> keine Daten
    n_ = 120; d0_ = _tag("2024-01-01"); x = np.arange(n_, dtype=float); x[50:60] = np.nan
    linie = np.full(n_, 100.0); P_ = np.where(np.arange(n_) < 80, 110.0, 90.0)
    Dk = {"tage": np.arange(d0_, d0_ + n_), "d0": d0_, "P": P_, "BGM": {"sth-realized-price": linie}, "FUNDING30_PZ": x,
          "DVOL_PZ": x, "FNG30": x, "MVRV_PZ": x, "OI_MC_PZ": x, "OI_ABDECKUNG": {"lueckenhaft": True}}
    kk = regime_kalender(Dk)
    f, s_, fg = kk["funding_hoch"], kk["unter_sth"], kk["fng_gier"]
    ok("Teil B Kalender: Wert von t − 2 (Kurzfrist-Kostenbasis t − 9), höchstens 3 Tage älter, Schwellen 66,7 / 33,3 / 75 / 25 / unter 0",
       f[68] == 0 and f[69] == 1 and np.isfinite(f[54]) and np.isnan(f[55]) and s_[88] == 0 and s_[89] == 1 and fg[76] == 0 and fg[77] == 1
       and kk["dvol_tief"][35] == 1 and kk["dvol_tief"][36] == 0 and kk["oi_hoch"] is None and np.isnan(f[1]) and f[2] == 0,
       f"Funding Tag 68/69: {f[68]:.0f}/{f[69]:.0f}; Lücke Tag 54/55: {f[54]:.0f}/nan; unter Linie ab Tag {int(np.argmax(s_ == 1))} (Kurs ab 80)")
    # B2) Statistik von Hand: Verhältnisschätzer mit Tagen als Klumpen, Welch-ν, Lage z (A&S 26.7.8), Abschnitte
    g = np.random.default_rng(3); S = g.normal(0, 1, 30); C = g.integers(1, 7, 30).astype(float); I = g.random(30) < 0.4; O = ~I

    def seite(m):
        mm = S[m].sum() / C[m].sum(); nn = m.sum()
        return mm, nn / (nn - 1) * ((S[m] - mm * C[m]) ** 2).sum() / C[m].sum() ** 2, nn
    (mi, vi, ni), (mo, vo, no) = seite(I), seite(O)
    t_ = (mi - mo) / math.sqrt(vi + vo); nu_ = (vi + vo) ** 2 / (vi * vi / (ni - 1) + vo * vo / (no - 1))
    z_ = t_ * (1 - 1 / (4 * nu_)) / math.sqrt(1 + t_ * t_ / (2 * nu_))
    gl = lage(S, C, I, O)
    ai, ao = abschnitte(np.array([[1, 1, 0, 0, 1, 0, 0], [0] * 7, [1, 0, 1, 0, 1, 0, 1]]))
    ok("Teil B Statistik von Hand: Δ, Standardfehler (Tage als Klumpen, n/(n − 1)), Welch-ν, Lage z; Abschnitte je Seite",
       abs(gl["d"][0] - (mi - mo)) < 1e-12 and abs(gl["t"][0] - t_) < 1e-9 and abs(gl["nu"][0] - nu_) < 1e-6 and abs(gl["z"][0] - z_) < 1e-9
       and list(ai) == [2, 0, 4] and list(ao) == [2, 1, 3], f"z {z_:+.3f} bei ν {nu_:.1f}")

    def tagesdaten(im, m_im, rausch=0.0):
        L_ = len(im); Cd = np.full(L_, 4.0); Sd = Cd * np.where(im == 1, m_im, rausch * np.sin(np.arange(L_) * 1.7))
        return {"S": Sd, "C": Cd, "H": np.full(L_, 2.0), "B": np.full(L_, 1.0), "R": Sd, "Q": np.zeros(L_)}
    im60 = ((np.arange(60) // 10) % 2 == 0).astype(float)
    tb = b_test(im60, 0, 0, 60, 30, 9, tagesdaten(im60, 0.02, 0.0002), seed=1, boot=200, placebo=False)
    im80 = np.zeros(80); im80[0:10] = im80[20:30] = 1; im80[40:43] = 1
    th = b_test(im80, 0, 0, 80, 40, 12, tagesdaten(im80, 0.02, 0.004), seed=2, boot=200, placebo=False)
    ok("Teil B Bootstrap je Seite getrennt (im Regime gleiche Tagesmittel, außerhalb fast null -> Intervall eng um Δ = 0,02); Hälften "
       "brauchen je Seite 7 Tage (2. Hälfte 3 Tage im Regime -> nicht erfüllt, obwohl beide Hälften gleich zeigen)",
       abs(tb["lo90"] - 0.02) < 0.002 and abs(tb["hi90"] - 0.02) < 0.002 and th["n_i_h2"] == 3 and th["d_h2"] is None
       and th["d_h1"] is not None and th["d_h1"] > 0 and th.get("delta", 0) > 0 and not th["haelften"],
       f"Intervall [{tb['lo90']:.4f}; {tb['hi90']:.4f}] bei Δ 0,02; Hälften {th['d_h1']} / {th['d_h2']} -> {th['haelften']}")
    im85 = np.ones(85); im85[10:18] = 0; im85[50:57] = 0                 # außerhalb nur 15 Tage (2 Abschnitte), im Regime 70
    tm = b_test(im85, 0, 0, 85, 43, 13, tagesdaten(im85, 0.02, 0.004), seed=3, boot=100, placebo=False)
    tm2 = b_test(1 - im85, 0, 0, 85, 43, 13, tagesdaten(1 - im85, 0.02, 0.004), seed=4, boot=100, placebo=False)
    ok("Teil B Mindestzahlen auf beiden Seiten: 70 Tage im Regime, aber nur 15 außerhalb -> nicht prüfbar (und umgekehrt)",
       not tm["pruefbar"] and "delta" not in tm and "15 außerhalb" in tm.get("grund", "") and not tm2["pruefbar"] and "delta" not in tm2
       and "15 Tage im Regime" in tm2.get("grund", ""), f"{tm.get('grund')} · {tm2.get('grund')}")
    # B3) Welten: Nulltest (ohne Wirkung, Güte schwankt) und Positivkontrolle (Regime wechselt alle 10 Tage, Vorsprung 0,03)
    fw = 0; tests = 0; unter = 0; bh_falsch = 0; welten_null = []
    for w in range(30):
        Dw, fa, _r = _welt_b(400 + w, familie=("ar", "weg", "buckel")[w % 3])
        E = teil_b(Dw, fa, jetzt=nach, boot=100, beschreibend=False)
        pr = [t for t in E["tests"] if t["pruefbar"]]
        tests += len(pr); unter += sum(1 for t in pr if t["p_placebo"] < B_PLACEBO_P); fw += int(E["erfuellt"] > 0)
        bh_falsch += int(bh([t["p_placebo"] for t in pr]) != [bool(t.get("bh")) for t in pr])
        if len(welten_null) < 4 and pr:
            welten_null.append((Dw, fa, E))
    ok("Teil B Nulltest: 30 Welten ohne Wirkung (Güte schwankt zäh, als Zufallsweg, in Buckeln) -> Placebo-p < 0,025 in höchstens 6 % der "
       "Tests, falsches „alle drei“ in höchstens 3 Welten; Benjamini-Hochberg über das Placebo-p von Hand", tests >= 60 and unter <= 0.06 * tests
       and fw <= 3 and bh_falsch == 0, f"{tests} prüfbare Tests, Placebo-p < 0,025: {unter}, Welten mit „alle drei“: {fw}, BH abweichend {bh_falsch}")

    def welle(seed, effekt):
        Dw, fa, _r = _welt_b(seed, familie="ar")
        n = len(Dw["tage"]); x = np.asarray(Dw["DVOL_PZ"], dtype=float).copy()
        x[n - 127:] = np.where((np.arange(127) // 10) % 2 == 0, 20.0, 50.0)         # im Fenster: alle 10 Tage DVOL tief / mittel
        Dw["DVOL_PZ"] = x
        rk = regime_kalender(Dw)["dvol_tief"]
        fa2 = []
        for c, ts, y, pb, q in fa:
            if rk[ts // TAG - Dw["d0"]] == 1:
                q = dict(q); q["v1"] = min(0.98, max(0.02, q["v1"] + effekt * (2 * y - 1)))
                if "v2" in q:
                    q["v2"] = min(0.98, max(0.02, q["v2"] + effekt * (2 * y - 1)))
                q["Fusion"] = 0.4 * q["v1"] + 0.3 * q.get("v2", pb) + 0.3 * pb
            fa2.append((c, ts, y, pb, q))
        return Dw, fa2
    funde = 0; andere = 0; E_pk = None
    for w in range(10):
        Dw, fa = welle(500 + w, 0.03)
        E = teil_b(Dw, fa, jetzt=nach, boot=100, beschreibend=False)
        funde += int(any(t["erfuellt"] for t in E["tests"] if t["key"] == "dvol_tief"))
        andere += sum(1 for t in E["tests"] if t["erfuellt"] and t["key"] not in ("dvol_tief", "dvol_hoch"))
        E_pk = E_pk or (Dw, fa)
    ok("Teil B Positivkontrolle: Vorsprung 0,03 (12 Skill-Punkte) im Regime „DVOL unteres Drittel“, das alle 10 Tage wechselt -> „alle drei“ "
       "in mindestens 8 von 10 Welten, in fremden Regimen höchstens 1", funde >= 8 and andere <= 1, f"Fund in {funde} von 10, fremd {andere}")
    # B4) Falle: Drift und ein einziger Wechsel (Regime erste Hälfte, Güte wechselt gleichzeitig) -> nie prüfbar, nie „alle drei“
    falle = 0; geprueft = 0
    for w in range(6):
        Dw, fa, _r = _welt_b(600 + w, familie="keine")
        n = len(Dw["tage"]); x = np.asarray(Dw["DVOL_PZ"], dtype=float).copy()
        x[n - 127:n - 50] = 20.0; x[n - 50:] = 50.0
        Dw["DVOL_PZ"] = x
        rk = regime_kalender(Dw)["dvol_tief"]
        fa2 = []
        for c, ts, y, pb, q in fa:
            sch = 0.03 if rk[ts // TAG - Dw["d0"]] == 1 else -0.03
            q = dict(q); q["v1"] = min(0.98, max(0.02, q["v1"] + sch * (2 * y - 1))); q["Fusion"] = 0.4 * q["v1"] + 0.3 * q.get("v2", pb) + 0.3 * pb
            fa2.append((c, ts, y, pb, q))
        E = teil_b(Dw, fa2, jetzt=nach, boot=100, beschreibend=False)
        tt = [t for t in E["tests"] if t["key"] == "dvol_tief"]
        geprueft += sum(1 for t in tt if t["pruefbar"]); falle += sum(1 for t in tt if t["erfuellt"])
    ok("Teil B Falle: Regime wechselt im Zeitraum genau einmal, die Güte zugleich -> ein Abschnitt je Seite, nicht prüfbar, nie „alle drei“",
       geprueft == 0 and falle == 0, f"prüfbar {geprueft}, „alle drei“ {falle}")
    # B5) Placebo von Hand für einen Test der Positivkontrolle: ganze Wochen, ganz vor dem Zeitraum, 2 Jahre Vorgeschichte, Mindestzahlen,
    #     gleiche Abschnitte ±1 (sonst alle gültigen), p = (1 + #|z_k| ≥ |z|) ÷ (1 + K)
    def placebo_hand(Dw, fa, E, key, quelle):
        reg = regime_kalender(Dw)[key]; w0, w1, d0 = E["w0"], E["w1"], int(Dw["d0"]); L = w1 - w0 + 1
        a = _gepoolt(tagesreihen(fa, w0, L), B_POOL, quelle, L)
        used = [i for i in range(L) if a["C"][i] > 0 and np.isfinite(reg[w0 + i - d0])]
        lab = np.array([reg[w0 + i - d0] for i in used])
        ab_echt = sum(abschnitte(lab[None, :]))[0]
        erst = int(np.nonzero(np.isfinite(reg))[0][0]) + B_VORGESCHICHTE
        z_echt = float(lage(a["S"][used], a["C"][used], lab == 1, lab == 0)["z"][0])
        zs, gl_ab = [], []
        for k in range((w1 - w0) // 7 + 1, 10_000):
            idx = [w0 + i - d0 - 7 * k for i in used]
            if min(idx) < erst:
                break
            rr = np.array([reg[j] for j in idx])
            if not np.isfinite(rr).all():
                continue
            abk = abschnitte(rr[None, :]); n1, n0 = int((rr == 1).sum()), int((rr == 0).sum())
            if n1 < B_MIN_TAGE or n0 < B_MIN_TAGE or abk[0][0] < B_MIN_ABSCHNITTE or abk[1][0] < B_MIN_ABSCHNITTE:
                continue
            zs.append(float(lage(a["S"][used], a["C"][used], rr == 1, rr == 0)["z"][0]))
            gl_ab.append(abs(int(abk[0][0] + abk[1][0]) - ab_echt) <= B_ABSCHNITTE_TOL)
        gleich = sum(gl_ab) >= B_MIN_VERSCHIEBUNGEN
        menge = [z for z, g_ in zip(zs, gl_ab) if g_] if gleich else zs
        return (1 + sum(1 for z in menge if abs(z) >= abs(z_echt) - 1e-12)) / (1 + len(menge)), len(menge), len(zs), gleich
    Dw, fa = E_pk
    E = teil_b(Dw, fa, jetzt=nach, boot=100, beschreibend=False)
    faelle_hand = [(Dw, fa, E, t) for t in E["tests"] if t["key"] == "dvol_tief" and t["quelle"] == "v1"]
    for seed_l in (704, 708):                                            # lange Vorgeschichte: auch „gleiche Abschnitte“ (K ≥ 40) kommt vor
        Dl, fl_, _r = _welt_b(seed_l, familie="ar", n_hist=5000)
        welten_null.append((Dl, fl_, teil_b(Dl, fl_, jetzt=nach, boot=100, beschreibend=False)))
    for Dn, fn, En in welten_null:
        faelle_hand += [(Dn, fn, En, t) for t in En["tests"] if t["pruefbar"]]
    abw, mit_gleich = [], 0
    for Dh, fh, Eh, t in faelle_hand:
        p_h, K_h, Kg_h, gl_h = placebo_hand(Dh, fh, Eh, t["key"], t["quelle"])
        mit_gleich += int(gl_h)
        if not (t.get("pruefbar") and abs(t["p_placebo"] - p_h) < 1e-12 and t["K"] == K_h and t["K_gueltig"] == Kg_h
                and (t["menge"] == "gleiche Abschnitte") == gl_h):
            abw.append((t["key"], t["quelle"], t.get("p_placebo"), p_h))
    t0_ = faelle_hand[0][3]
    ok("Teil B Placebo von Hand: ganze Wochen vor dem Zeitraum, 2 Jahre Vorgeschichte, Mindestzahlen, gleiche Abschnitte ±1 (sonst alle "
       "gültigen) -> dasselbe p und K, für die Positivkontrolle und alle prüfbaren Tests von sechs Nullwelten (zwei mit langer Vorgeschichte)",
       not abw and len(faelle_hand) >= 5 and mit_gleich >= 1 and t0_.get("pruefbar"),
       f"{len(faelle_hand)} Tests von Hand nachgerechnet, davon {mit_gleich} mit „gleiche Abschnitte“; abweichend {abw[:2] or 'keiner'}; "
       f"Positivkontrolle p {t0_['p_placebo']:.4f}, K {t0_['K']} ({t0_['menge']})".replace(".", ","))
    # B6) Urteilstag: vorher beschreibend, danach Urteil; Blöcke nach dem 14.01.2027 23:59 UTC ändern nichts (eingefroren); Anlauf
    Ev = teil_b(Dw, fa, jetzt=vor, boot=100, beschreibend=False); En = teil_b(Dw, fa, jetzt=nach, boot=100, beschreibend=False)
    schnitt = calendar.timegm(time.strptime(B_URTEIL, "%Y-%m-%d"))
    spaet = [("BTC", schnitt + 3600 * j, 1, 0.5, {"v1": 0.02, "v2": 0.02, "Fusion": 0.02}) for j in range(40)]
    En2 = teil_b(Dw, fa + spaet, jetzt=nach, boot=100, beschreibend=False)
    erst_tag = min(ts // TAG for _c, ts, *_ in fa)
    Ea = teil_b(Dw, [x_ for x_ in fa if x_[1] // TAG < erst_tag + 20], jetzt=vor, boot=100)
    ok("Teil B Urteilstag: vorher „alle drei“ ohne Urteil, ab 15.01.2027 belegt; spätere Blöcke ändern nichts; Anlauf 28 Tage ausgelassen",
       Ev["erfuellt"] > 0 and Ev["belegt"] == 0 and En["belegt"] == En["erfuellt"] > 0 and En2["belegt"] == En["belegt"]
       and [t.get("p_placebo") for t in En2["tests"]] == [t.get("p_placebo") for t in En["tests"]] and Ev["w0"] == erst_tag + B_ANLAUF_TAGE
       and Ea.get("anlauf") and "noch im Anlauf" in bericht_b_text(Ea),
       f"vorher erfüllt {Ev['erfuellt']}, belegt {Ev['belegt']}; danach belegt {En['belegt']}; mit Blöcken nach dem Schnitt {En2['belegt']}")
    # B7) Bericht und Ende zu Ende über die Dateien (makro.db aus hl_makro.testdaten, forecasts.db mit fusion_fall)
    tmp = tempfile.mkdtemp(prefix="hl_makro_korr_b_")
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_makro
        mp = os.path.join(tmp, "makro.db"); hl_makro.testdaten(mp, n_tage=2600, seed=5)
        con = hl_makro.lesen(mp); D = hl_makro.ableiten(con); con.close()
        tag_e = int(D["tage"][-1])
        fp = os.path.join(tmp, "forecasts.db"); st = sqlite3.connect(fp)
        st.execute("CREATE TABLE fusion_fall (coin TEXT, h INTEGER, block INTEGER, ts INTEGER, px REAL, experten TEXT, p_fusion REAL, "
                   "gewichte TEXT, quelle TEXT, r REAL, y INTEGER, aufgeloest INTEGER, PRIMARY KEY (coin, h, block))")
        gg = np.random.default_rng(8); zeilen = []
        for i in range(70):
            for j in range(6):
                ts = (tag_e - 69 + i) * TAG + j * 14_400 + 30
                for c in ("BTC", "ETH", "PAXG"):
                    y = int(gg.random() < 0.5)
                    ex = {"Basisrate": 0.5, "v1": round(0.5 + 0.05 * gg.normal(), 5), "v2": (0.55 if c == "BTC" else None), "v3": None}
                    zeilen.append((c, 4, ts // 14_400, ts, 100.0, json.dumps(ex), 0.51, "{}", "live", 0.01, y, ts + 14_400))
        zeilen.append(("BTC", 24, 1, (tag_e - 5) * TAG, 100.0, json.dumps({"Basisrate": 0.5, "v1": 0.9}), 0.9, "{}", "live", 0.01, 1, 0))
        zeilen.append(("ETH", 4, 10 ** 9, (tag_e - 5) * TAG + 7, 100.0, json.dumps({"Basisrate": 0.5, "v1": 0.9}), 0.9, "{}", "live", 0.0001, -1, 0))
        st.executemany("INSERT INTO fusion_fall VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", zeilen); st.commit(); st.close()
        fl = faelle_laden(fp)
        E = teil_b(D, fl, jetzt=vor, boot=100); txt = bericht_b_text(E)
        import io
        import contextlib
        buf = io.StringIO(); alt_env = os.environ.get("HL_MAKRO_DB")
        os.environ["HL_MAKRO_DB"] = mp
        try:
            with contextlib.redirect_stdout(buf):
                rc = main(["--teil-b", "--db", os.path.join(tmp, "hl_liq.db"), "--forecasts", fp])
        finally:
            if alt_env is None:
                os.environ.pop("HL_MAKRO_DB", None)
            else:
                os.environ["HL_MAKRO_DB"] = alt_env
        ok("Teil B Ende zu Ende: fusion_fall lesen (nur 4 h, nur Richtung, ohne v2 = None), Bericht mit Hauptfamilie, je Coin, Werkzeug",
           len(fl) == 70 * 6 * 3 and all(("v2" in q) == (c_ == "BTC") for c_, *_x, q in fl) and rc == 0 and "Hauptfamilie" in buf.getvalue()
           and "Werkzeug: hl_makro_korr.py sha256" in txt and "dieser Lauf ist beschreibend" in txt and E["w0"] == tag_e - 69 + B_ANLAUF_TAGE
           and "PAXG nur je Coin" in txt and E["n_tests"] == 27
           and next(t_["b_i"] + t_["b_o"] for t_ in E["tests"] if t_["key"] == "fng_gier" and t_["quelle"] == "v1")
           == sum(1 for c_, ts_, *_x in fl if c_ in ("BTC", "ETH") and E["w0"] <= ts_ // TAG <= E["w1"]),
           f"{len(fl)} Blöcke gelesen, {E['n_tests']} Tests, {E['n_pruefbar']} prüfbar, Bericht {len(txt.splitlines())} Zeilen")
        # B8) U229: Klassen der SSR-Diagnose und Nachrechnung (offener Tag = vorläufig, alles andere abweichend)
        con = sqlite3.connect(mp)
        dd = int(D["tage"][-10]); fest = (dd + 1) * TAG + 600
        ssr = D["SSR"]; pz = D["SSR_PZ"]; i_ = dd - int(D["d0"])
        fall = {"2099-01-01": (float(ssr[i_]), float(pz[i_]), None),                                  # gleich
                "2099-01-02": (float(ssr[i_]) * 1.01, float(pz[i_]) + 0.5, (dd + 1) * TAG + 7200),     # offener Tag
                "2099-01-03": (float(ssr[i_]) * 1.01, float(pz[i_]) + 0.5, (dd + 6) * TAG),            # spätere Korrektur
                "2099-01-04": (float(ssr[i_]), float(pz[i_]) + 0.5, None)}                             # nur Perzentil
        for tag_, (roh, p_, _a) in fall.items():
            con.executemany("INSERT OR REPLACE INTO mk_stand VALUES (?,?,?,?)", [(tag_, "ssr", roh, fest), (tag_, "ssr_pz", p_, fest),
                                                                                 (tag_, "ssr_datentag", float(dd), fest)])
        con.commit()

        def diag(st_ab, mc_ab=None, alt=False):
            con.execute("UPDATE mk_reihe SET abgerufen=? WHERE reihe IN ('llama:stable_usd', 'cm:btc:CapMrktCurUSD')", (fest - 999,))
            con.execute("UPDATE mk_reihe SET abgerufen=? WHERE reihe='llama:stable_usd' AND ts=?", (st_ab or fest - 999, dd * TAG))
            con.execute("UPDATE mk_reihe SET abgerufen=? WHERE reihe='cm:btc:CapMrktCurUSD' AND ts=?", (mc_ab or fest - 999, dd * TAG))
            con.execute("UPDATE mk_reihe SET abgerufen=? WHERE reihe='llama:stable_usd' AND ts=?", (fest + 5 if alt else fest - 999, (dd - 30) * TAG))
            con.commit()
            return ssr_diagnose(D, mp)
        k_offen = {t["tag"]: t["klasse"] for t in diag((dd + 1) * TAG + 7200)["tage"]}
        k_spaet = {t["tag"]: t["klasse"] for t in diag((dd + 6) * TAG)["tage"]}
        k_mc = {t["tag"]: t["klasse"] for t in diag((dd + 1) * TAG + 7200, mc_ab=fest + 60)["tage"]}
        S_alt = diag((dd + 1) * TAG + 7200, alt=True)
        S_of = diag((dd + 1) * TAG + 7200)
        con.close()
        stand = [(tg, k_, w_) for tg, (roh, p_, _a) in fall.items() for k_, w_ in (("ssr_pz", p_), ("ssr_datentag", float(dd)))]
        Dr = {"tage": D["tage"], "d0": D["d0"], "P": D["P"], "SSR": D["SSR"], "SSR_PZ": D["SSR_PZ"], "OI_ABDECKUNG": {"lueckenhaft": True}}
        A = auswertung(Dr, stand, S_of["offen"])
        je = A["nachrechnung"]["je_merkmal"].get("ssr_pz", {})
        txt = bericht_text(A, S_of)
        ok("U229 SSR-Diagnose: gleich / offener Tag (bis 2 Tage nach Tagesende, ältere Werte gleich) / spätere Korrektur / Marktkap. / nur "
           "Perzentil; offener Tag zählt als vorläufig, der Rest als abweichend; Bericht nennt Befund und Kurzfrist-Kostenbasis",
           k_offen == {"2099-01-01": "gleich", "2099-01-02": "offener Tag", "2099-01-03": "offener Tag", "2099-01-04": "nur Perzentil"}
           and k_spaet["2099-01-02"] == "spätere Korrektur der Stablecoin-Summe" and k_mc["2099-01-02"] == "Marktkapitalisierung geändert"
           and {t["tag"]: t["klasse"] for t in S_alt["tage"]}["2099-01-02"] == "offener Tag, ältere Werte geändert"
           and S_of["offen"] == {"2099-01-02", "2099-01-03"} and je.get("vorlaeufig") == 2 and je.get("abweichend") == 1 and je.get("n") == 2
           and "U229 -- SSR in der Nachrechnung aufgeschlüsselt (4 archivierte Tage)" in txt and "nicht nur der offene Tag" in txt
           and "Kurzfrist-Kostenbasis (BGeometrics frei 7 Tage später" in txt,
           f"offen {sorted(S_of['offen'])}; Nachrechnung ssr_pz: geprüft {je.get('n')}, abweichend {je.get('abweichend')}, vorläufig {je.get('vorlaeufig')}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if verbose:
        for name, gut, txt_ in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<64} {txt_}")
    return all(p[1] for p in pruef), pruef


def selbsttest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Makro × Kurs (U130) -- Selbsttest: Teil A (Rangkorrelation, Phasen-Null, Nulltest, Positivkontrolle, Ära, Nachrechnung), "
              "Teil B (Kalender, Statistik, Nulltest, Positivkontrolle, Falle, Placebo, Urteilstag, Ende zu Ende) und U229")
    gut, _ = probe(verbose)
    gut_b, _ = probe_b(verbose)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if gut and gut_b else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return gut and gut_b


def stand_zeilen(pfad: str) -> list:
    """Archiv der Zonenkarte (mk_stand) als [(tag, schlüssel, wert)]; fehlt es, leer."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True)
    except sqlite3.Error:
        return []
    try:
        return [(r[0], r[1], r[2]) for r in con.execute("SELECT tag, kennzahl, wert FROM mk_stand")]
    except sqlite3.Error:
        return []
    finally:
        con.close()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Makro × Kurs (U130, Teil A) und Makro-Regime × 4-h-Prognosen (Teil B)")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (makro.db und forecasts.db liegen daneben)")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--kalibrieren", action="store_true", help="Fehlurteile auf Zufallswegen: Phasen gegen Verschiebung (einige Minuten)")
    ap.add_argument("--teil-b", action="store_true", help="Teil B: Makro-Regime × 4-h-Prognosen (KONZEPT_Makro.md 10.2, 10.7, 10.7a)")
    ap.add_argument("--forecasts", help="forecasts.db (Teil B; sonst HL_FORECAST_DB oder neben --db)")
    ap.add_argument("--kalibrieren-b", action="store_true", help="Teil B: Kalibrierung auf künstlichen Welten, Teststärke, Entscheidung "
                    "nach 10.7a/10.7b (rund 5 min; mit --db zusätzlich die echten Kalender)")
    ap.add_argument("--kalibrieren-b-echt", action="store_true", help="Teil B: Prüfung auf den echten Regime-Kalendern (10.7b, Debug-Lauf; "
                    "künstliche Prognosen, kein Ergebnis wird angesehen)")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.kalibrieren:
        kalibrierung()
        return 0
    D, pfad = None, None
    if not (a.kalibrieren_b and not a.db):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_makro
        pfad = hl_makro.makro_pfad(a.db) if a.db else hl_makro.makro_pfad(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db"))
        con = hl_makro.lesen(pfad)
        if con is None:
            print(f"makro.db fehlt: {pfad}")
            return 1
        try:
            D = hl_makro.ableiten(con)
        finally:
            con.close()
        if not D.get("ok"):
            print("Makro-Daten unvollständig:", D.get("grund"))
            return 1
    if a.kalibrieren_b or a.kalibrieren_b_echt:
        t0 = time.time()
        print(f"Makro-Regime × 4-h-Prognosen (U130, Teil B) -- {'Prüfung auf den echten Kalendern (10.7b)' if a.kalibrieren_b_echt else 'Kalibrierung (10.7a, 10.7b)'}, "
              f"künstliche Prognosen ohne Wirkung der Regime, Start {time.strftime('%d.%m.%Y %H:%M:%S')}; Werkzeug: {_werkzeug()}", flush=True)
        if a.kalibrieren_b_echt:
            erg = kalibrierung_b(welten=600, familien=B_FAMILIEN_ECHT, D_echt=D, boot=20)   # die Regel braucht nur das Placebo
            gut = bool(erg) and all(z["unten_test"]["placebo"] <= B_PLACEBO_P and z["unten"]["placebo"] <= 0.10 for z in erg.values())
            print("  " + " · ".join(f"{f_}: je Test {z['pl']} von {z['tests']} (untere 90-%-Grenze {z['unten_test']['placebo']:.1%}), Welten "
                                    f"{z['fw']['placebo']} von {z['welten']} (untere Grenze {z['unten']['placebo']:.1%})" for f_, z in erg.items()).replace(".", ","))
            print(f"  Ergebnis nach 10.7b: {'bestanden -- das Placebo-p bleibt im Benjamini-Hochberg' if gut else 'NICHT bestanden -- für das Urteil gilt Bonferroni über das Placebo-p'} "
                  f"(nicht bestanden nur bei Beleg für zu viele Fehlurteile: untere 90-%-Grenze je Test über 2,5 % oder je Welt über 10 %) · "
                  f"{time.time() - t0:.0f} s")
        else:
            erg = kalibrierung_b(D_echt=D, n_hist=2600)
            st1 = staerke_b(effekt=0.01, n_hist=2600)
            staerke_b(effekt=0.02, n_hist=2600)
            print(f"  Entscheidung nach 10.7a/10.7b: {entscheidung_b(erg, st1)} -- im Werkzeug festgelegt: {B_P_FUER_BH} · {time.time() - t0:.0f} s")
        return 0
    if a.teil_b:
        fp = a.forecasts or os.environ.get("HL_FORECAST_DB") or os.path.join(os.path.dirname(os.path.abspath(a.db or pfad)), "forecasts.db")
        if not os.path.exists(fp):
            print(f"forecasts.db fehlt: {fp}")
            return 1
        print(bericht_b_text(teil_b(D, faelle_laden(fp))))
        return 0
    S = ssr_diagnose(D, pfad)                                            # 23.85 (U229)
    print(bericht_text(auswertung(D, stand_zeilen(pfad), S.get("offen")), S))
    return 0


if __name__ == "__main__":
    sys.exit(main())
