#!/usr/bin/env python3
"""
Makro × Kurs (U130, Teil A, Version 2026-09-23.52): Wie stark hängen die Makro-Merkmale mit der BTC-Rendite der FOLGENDEN 1, 7 und
30 Tage zusammen? Vorab festgelegt in KONZEPT_Makro.md Abschnitt 10 (05.10.2026 19:15): Ziel, Merkmale, Maß und Schwellen standen
fest, bevor ein Ergebnis zu sehen war.

  Ziel        r(t → t+h) = ln P(t+h) − ln P(t), BTC-Tagesschluss (Coin Metrics), h = 1, 7, 30. Nie die Rendite desselben Tags.
  Merkmale    15 Werte am Tag t, nur aus Daten bis t (wie die Zonenkarte). FRED-Reihen mit 7 Tagen Versatz: Ihr Wert zum Datum t
              wird erst Tage später veröffentlicht (Fed-Bilanz donnerstags, Dollarindex wöchentlich).
  Maß         Spearman ρ und ρ² (Anteil der erklärten Rangstreuung -- „wie hoch ist die Wechselwirkung“). Beschreibend dazu: mittlere
              Rendite an Tagen im obersten gegen das unterste Drittel des Merkmals.
  Null        Phasen-Randomisierung (Ebisuzaki 1997): 2000 Surrogate des Merkmals mit gleichem Spektrum -- also gleicher
              Autokorrelation -- und zufälligen Fourier-Phasen; die Renditen bleiben, wie sie sind (ihre Überlappung auch).
              p zweiseitig. Gewählt in der Kalibrierung auf Zufallswegen VOR dem ersten Blick auf echte Daten (kalibrierung(),
              4.050 Tests mit unabhängigen, zähen Merkmalen): Phasen 0,8 % Fehlurteile bei p < 0,01 und 5,4 % bei p < 0,05; die
              beiden vorab genannten Verfahren fielen durch -- zirkuläre Verschiebung 1,7 % und 6,5 % (Perzentile bis 2,7 % und
              8,7 %), Blockbootstrap mit Blocklänge h bis 20 % bei p < 0,05.
  Belegt      Benjamini-Hochberg über alle gerechneten Tests (q = 0,10) UND gleiches Vorzeichen mit |ρ| ≥ 0,05 in beiden Hälften
              (bis 31.12.2021, ab 01.01.2022; je mindestens 365 Tage) UND die Nachrechnung gegen das Archiv mk_stand widerspricht
              nicht. Eine Ära (gemeinsamer Trend in Merkmal und Rendite) besteht die Ganzprobe, aber nicht die Hälften.

Reine Rechnung; liest die Ableitung von hl_makro (D) und das Archiv mk_stand. Debug-Bericht: python3 hl_makro_korr.py --db <hl_liq.db>
"""
from __future__ import annotations

import argparse
import calendar
import math
import os
import sys
import time
import zlib

import numpy as np

HORIZONTE = (1, 7, 30)
MIN_VERSATZ = 365                       # nur für den Vergleich in der Kalibrierung (zirkuläre Verschiebung)
K_PHASEN = 2000                         # Surrogate je Test (kleinstes p 0,0005; BH braucht bei 45 Tests 0,0022)
MIN_TAGE = 2 * 365 + 30                 # kürzere Reihen sind nicht prüfbar und zählen nicht im BH (ETF seit 01/2024: geprüft, aber ohne erste Hälfte nie belegt)
Q_BH = 0.10
MIN_RHO = 0.05
GRENZE_HAELFTE = "2022-01-01"
MIN_TAGE_HAELFTE = 365
FRED_VERSATZ = 7                        # Veröffentlichungsverzug der FRED-Reihen
TAG = 86400


def _tag(s: str) -> int:
    return calendar.timegm(time.strptime(s, "%Y-%m-%d")) // TAG


# ================================================================================================ Bausteine

def raenge(a: np.ndarray) -> np.ndarray:
    """Ränge 1..n, Gleichstände gemittelt (nur endliche Werte übergeben)."""
    a = np.asarray(a, dtype=float)
    u, inv, cnt = np.unique(a, return_inverse=True, return_counts=True)
    ende = np.cumsum(cnt); anfang = ende - cnt
    return ((anfang + ende + 1) / 2.0)[inv]


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return float("nan")
    rx = raenge(x[ok]); ry = raenge(y[ok])
    zx = rx - rx.mean(); zy = ry - ry.mean()
    nenner = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    return float(np.dot(zx, zy) / nenner) if nenner > 0 else float("nan")


def vorwaerts(P: np.ndarray, h: int) -> np.ndarray:
    """r(t → t+h) = ln P(t+h) − ln P(t); am Ende (t+h nach dem letzten Tag) leer."""
    P = np.asarray(P, dtype=float); n = len(P)
    r = np.full(n, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        r[: n - h] = np.log(P[h:]) - np.log(P[: n - h])
    return r


def verschiebungen(x: np.ndarray, y: np.ndarray, min_versatz: int = MIN_VERSATZ) -> tuple:
    """
    Spearman ρ und die Nullverteilung aus ALLEN zirkulären Verschiebungen k ∈ [min_versatz, n − min_versatz] des Merkmals gegen die
    Renditen (über die Paare mit beiden Werten). ρ_k = Σ_j zx[j−k]·zy[j] / Nenner per FFT -- so viel wie np.roll(rx, k) gegen ry.
    -> (rho, rho_null (Array), n) oder (rho, None, n), wenn die Reihe für ein Jahr Abstand zu kurz ist.
    """
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 3:
        return float("nan"), None, n
    rx = raenge(xs); ry = raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    nenner = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not nenner > 0:
        return float("nan"), None, n
    if n < 2 * min_versatz + 30:
        return float(np.dot(zx, zy) / nenner), None, n
    c = np.fft.irfft(np.conj(np.fft.rfft(zx)) * np.fft.rfft(zy), n) / nenner
    return float(c[0]), c[min_versatz: n - min_versatz + 1], n


def phasen_null(x: np.ndarray, y: np.ndarray, k: int = K_PHASEN, seed: int = 0) -> tuple:
    """
    Spearman ρ und die Nullverteilung aus k Surrogaten des Merkmals mit zufälligen Fourier-Phasen (Ebisuzaki 1997): gleiches
    Spektrum wie die Ränge des Merkmals (gleiche Autokorrelation), kein Bezug zu den Renditen; die Renditen bleiben fest.
    Für die Ränge zx, zy gilt Σ zx·zy = (1/n)·[2·Σ_f Re(X_f·conj(Y_f)) + Nyquist]; mit zufälliger Phase θ_f ist der Beitrag
    |X_f|·|Y_f|·cos θ_f -- deshalb ohne Rücktransformation: ρ_s = (2·Σ_f |X_f||Y_f| cos θ_f ± |X_N||Y_N|) / (n·Norm).
    -> (rho, null (Array) oder None bei zu kurzer Reihe, n)
    """
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 3:
        return float("nan"), None, n
    rx = raenge(xs); ry = raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    norm = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not norm > 0:
        return float("nan"), None, n
    rho = float(np.dot(zx, zy) / norm)
    if n < MIN_TAGE:
        return rho, None, n
    a = np.abs(np.fft.rfft(zx)) * np.abs(np.fft.rfft(zy))
    gerade = n % 2 == 0
    mitte = a[1:-1] if gerade else a[1:]
    rng = np.random.default_rng(seed)
    out = np.empty(k)
    for s0 in range(0, k, 250):
        m = min(250, k - s0)
        v = 2.0 * (np.cos(rng.uniform(0.0, 2 * np.pi, (m, len(mitte)))) @ mitte)
        if gerade:
            v = v + a[-1] * rng.choice((-1.0, 1.0), m)
        out[s0:s0 + m] = v / n / norm
    return rho, out, n


def p_zweiseitig(rho: float, null: np.ndarray) -> float:
    return float((1 + np.sum(np.abs(null) >= abs(rho) - 1e-12)) / (1 + len(null)))


def bh(p: list, q: float = Q_BH) -> list:
    """Benjamini-Hochberg: welche Tests bei der Rate falscher Entdeckungen q als Entdeckung gelten."""
    m = len(p)
    if not m:
        return []
    ordnung = sorted(range(m), key=lambda i: p[i])
    grenze = -1
    for rang, i in enumerate(ordnung, start=1):
        if p[i] <= rang / m * q:
            grenze = rang
    erlaubt = set(ordnung[:grenze]) if grenze > 0 else set()
    return [i in erlaubt for i in range(m)]


def pruefe(x: np.ndarray, y: np.ndarray, tage: np.ndarray, grenze_tag: int, seed: int = 0, k: int = K_PHASEN) -> dict:
    """Ein Test: Merkmal x(t) gegen Rendite y(t → t+h) mit Phasen-Null, dazu beide Hälften und die Drittel."""
    rho, null, n = phasen_null(x, y, k, seed)
    out = {"n": n, "rho": rho, "r2": rho * rho if math.isfinite(rho) else float("nan")}
    if null is None:
        out.update(zu_kurz=True, p=None)
    else:
        sd = float(np.std(null))
        out.update(p=p_zweiseitig(rho, null), n_null=len(null), sd_null=sd, lo90=rho - 1.6449 * sd, hi90=rho + 1.6449 * sd)
    ok = np.isfinite(x) & np.isfinite(y)
    tage = np.asarray(tage)
    for name, m in (("h1", ok & (tage < grenze_tag)), ("h2", ok & (tage >= grenze_tag))):
        out[f"n_{name}"] = int(m.sum())
        out[f"rho_{name}"] = spearman(x[m], y[m]) if m.sum() >= MIN_TAGE_HAELFTE else float("nan")
    if ok.sum() >= 30:
        xs, ys = x[ok], y[ok]
        q1, q2 = np.quantile(xs, [1 / 3, 2 / 3])
        oben, unten = ys[xs >= q2], ys[xs <= q1]
        out["drittel"] = float(np.mean(oben) - np.mean(unten)) if len(oben) and len(unten) else float("nan")
    return out


def urteil(t: dict) -> bool:
    """Belegt = Benjamini-Hochberg UND beide Hälften UND kein Widerspruch der Nachrechnung -- alle drei, wie vorab festgelegt."""
    return bool(t.get("bh")) and bool(t.get("haelften")) and not t.get("nach_widerspruch")


def haelften_ok(t: dict) -> bool:
    r, r1, r2 = t.get("rho"), t.get("rho_h1"), t.get("rho_h2")
    if not all(v is not None and math.isfinite(v) for v in (r, r1, r2)):
        return False
    return (np.sign(r1) == np.sign(r2) == np.sign(r)) and abs(r1) >= MIN_RHO and abs(r2) >= MIN_RHO


# ================================================================================================ Merkmale aus der Ableitung

def _asof(ziel_tage: np.ndarray, t: np.ndarray, w: np.ndarray, max_alter: int) -> np.ndarray:
    """Je Zieltag der letzte Wert am oder vor diesem Tag, höchstens max_alter Tage alt."""
    t = np.asarray(t, dtype=np.int64); w = np.asarray(w, dtype=float)
    m = np.isfinite(w); t, w = t[m], w[m]
    out = np.full(len(ziel_tage), np.nan)
    if not len(t):
        return out
    k = np.searchsorted(t, ziel_tage, "right") - 1
    gut = (k >= 0)
    kk = np.where(gut, k, 0)
    alt = ziel_tage - t[kk]
    gut &= alt <= max_alter
    out[gut] = w[kk[gut]]
    return out


def merkmale(D: dict) -> list:
    """[(Schlüssel, Name, Array auf der Tagesachse von D oder None, Hinweis, Schlüssel in mk_stand oder None)] -- Reihenfolge fest."""
    P = np.asarray(D["P"], dtype=float); tage = np.asarray(D["tage"], dtype=np.int64)
    bg = D.get("BGM") or {}
    with np.errstate(invalid="ignore", divide="ignore"):
        sth = P / np.asarray(bg.get("sth-realized-price", np.full(len(P), np.nan)), dtype=float) - 1
    ab = D.get("OI_ABDECKUNG") or {}
    oi = None if ab.get("lueckenhaft") else D.get("OI_MC")
    oi_hinweis = (f"Binance-Archiv lädt noch ({ab.get('tage')} von {ab.get('soll')} Tagen)" if ab.get("lueckenhaft") else "")
    out = [
        ("mvrv_pz", "MVRV (Perzentil seit Beginn)", D.get("MVRV_PZ"), "", "mvrv_pz"),
        ("pl_pz", "Kurs ÷ Power-Law-Fair-Value (Perzentil)", (D.get("PL") or {}).get("pz"), "", "pl_pz"),
        ("wma_pz", "Abstand zum 200-Wochen-MA (Perzentil)", D.get("WMA_ABST_PZ"), "", "wma_pz"),
        ("sth", "Kurs ÷ Kurzfrist-Kostenbasis − 1", sth, "", "sth"),
        ("mvrvz", "MVRV-Z", D.get("MVRV_Z"), "", "mvrvz"),
        ("puell_pz", "Puell (Perzentil in der Epoche)", D.get("PUELL_PZ"), "", "puell_pz"),
        ("funding30", "Funding 30 Tage", D.get("FUNDING30"), "", "funding"),
        ("oi", "OI ÷ Marktkapitalisierung", oi, oi_hinweis, "oi"),
        ("dvol", "DVOL", D.get("DVOL"), "", "dvol"),
        ("fng30", "Fear & Greed 30 Tage", D.get("FNG30"), "", "fng"),
        ("ssr_pz", "SSR (Perzentil)", D.get("SSR_PZ"), "", "ssr_pz"),
        ("etf30", "ETF-Fluss BTC 30 Tage", D.get("ETF_BTC_30"), "", "etf"),
    ]
    # FRED: Änderung über 4 Wochen, Wert vom Tag t − 7 (Veröffentlichung) gegen t − 35
    R = D.get("R")

    def reihe(name, max_alter):
        try:
            t, w = R(name)
        except Exception:                                                # nicht geladen oder Datei zu
            return np.full(len(tage), np.nan)
        return _asof(tage - FRED_VERSATZ, t, w, max_alter)

    if R is not None:
        walcl, tga, rrp = reihe("fred:WALCL", 10), reihe("fred:WTREGEN", 10), reihe("fred:RRPONTSYD", 7)
        rrp = np.where(np.isfinite(rrp), rrp, np.where(tage - FRED_VERSATZ < _tag("2013-09-23"), 0.0, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            netliq = walcl - tga - rrp * 1000
            nl4 = np.full(len(tage), np.nan); nl4[28:] = np.log(netliq[28:] / netliq[:-28])
            rz = reihe("fred:DFII10", 7); rz4 = np.full(len(tage), np.nan); rz4[28:] = rz[28:] - rz[:-28]
            dx = reihe("fred:DTWEXBGS", 10); dx4 = np.full(len(tage), np.nan); dx4[28:] = np.log(dx[28:] / dx[:-28])
        for key, name, arr in (("netliq4w", "Nettoliquidität, Änderung 4 Wochen", nl4), ("realzins4w", "Realzins 10 J, Änderung 4 Wochen", rz4),
                               ("dollar4w", "Dollar breit, Änderung 4 Wochen", dx4)):
            leer = not np.isfinite(arr).any()
            out.append((key, name + f" ({FRED_VERSATZ} T Versatz)", None if leer else arr, "FRED ohne Daten (Schlüssel?)" if leer else "", None))
    # eine Reihe ohne einen einzigen Wert ist „nicht prüfbar“, kein Test
    return [(k, n, None if a is None or not np.isfinite(np.asarray(a, dtype=float)).any() else a, h or ("keine Daten" if a is None or
             not np.isfinite(np.asarray(a, dtype=float)).any() else ""), sk) for k, n, a, h, sk in out]


# ================================================================================================ Auswertung

def auswertung(D: dict, stand_zeilen: list | None = None) -> dict:
    """Alle Tests (Merkmal × Horizont), BH, Hälften, Nachrechnung -> Ergebnis zum Bericht."""
    t0 = time.time()
    tage = np.asarray(D["tage"], dtype=np.int64); P = np.asarray(D["P"], dtype=float)
    grenze = _tag(GRENZE_HAELFTE)
    nach = nachrechnung_stand(D, stand_zeilen or [])
    tests, fehlt = [], []
    for key, name, arr, hinweis, _sk in merkmale(D):
        if arr is None:
            fehlt.append({"key": key, "name": name, "grund": hinweis or "keine Daten"})
            continue
        x = np.asarray(arr, dtype=float)
        for h in HORIZONTE:
            t = pruefe(x, vorwaerts(P, h), tage, grenze, seed=zlib.crc32(f"{key}|{h}".encode()))
            t.update(key=key, name=name, h=h)
            if t.get("zu_kurz"):
                t["grund"] = f"zu kurz ({t['n']} Tage, nötig {MIN_TAGE}) -- zählt nicht im BH"
            tests.append(t)
    mit_p = [t for t in tests if t.get("p") is not None]
    ent = bh([t["p"] for t in mit_p])
    for t, e in zip(mit_p, ent):
        t["bh"] = bool(e)
    for t in tests:
        w = (nach.get("je_merkmal") or {}).get(t["key"], {})
        t["haelften"] = haelften_ok(t)
        t["nach_widerspruch"] = bool(w.get("abweichend"))
        t["belegt"] = urteil(t)
    return {"tests": tests, "fehlt": fehlt, "nachrechnung": nach, "n_tests": len(mit_p),
            "belegt": sum(1 for t in tests if t["belegt"]), "bh": sum(1 for t in tests if t.get("bh")),
            "p10": sum(1 for t in mit_p if t["p"] < 0.10), "bis": int(tage[np.nonzero(np.isfinite(P))[0][-1]]) if np.isfinite(P).any() else None,
            "dauer_s": round(time.time() - t0, 2)}


def nachrechnung_stand(D: dict, zeilen: list) -> dict:
    """
    Kriterium 3: Werte, die die Zonenkarte an einem Tag festgeschrieben hat (mk_stand: Schlüssel und *_datentag), gegen die heutige
    Rechnung für denselben Datentag. zeilen = [(tag, schlüssel, wert)]. Kein Archiv -> kein Widerspruch (noch nicht prüfbar).
    """
    if not zeilen:
        return {"n": 0, "je_merkmal": {}}
    d0 = int(D["d0"]); arr = {k: a for k, _n, a, _h, sk in merkmale(D) if sk and a is not None for k in [sk]}
    datentag = {(t, k[: -len("_datentag")]): int(w) for t, k, w in zeilen if k.endswith("_datentag")}
    je, n = {}, 0
    rueck = {sk: k for k, _n, a, _h, sk in merkmale(D) if sk}
    for t, k, w in zeilen:
        if k.endswith("_datentag") or k not in arr:
            continue
        basis = k[:-3] if k.endswith("_pz") else k
        d = datentag.get((t, basis))
        if d is None or not (0 <= d - d0 < len(arr[k])):
            continue
        neu = float(arr[k][d - d0]); n += 1
        e = je.setdefault(rueck[k], {"n": 0, "abweichend": 0, "beispiel": None})
        e["n"] += 1
        if not (math.isfinite(neu) and abs(neu - float(w)) <= 1e-6 * max(1.0, abs(float(w)))):
            e["abweichend"] += 1
            e["beispiel"] = e["beispiel"] or f"{t}: {float(w):.6g} -> {neu:.6g}"
    return {"n": n, "je_merkmal": je}


def bericht_text(A: dict) -> str:
    z = lambda v, d=2: "—" if v is None or not (isinstance(v, (int, float)) and math.isfinite(v)) else f"{v:+.{d}f}".replace(".", ",")
    tag = lambda t: time.strftime("%d.%m.%Y", time.gmtime(t * TAG)) if t else "—"
    zeilen = [f"Makro × Kurs (U130, Teil A) -- BTC-Tagesschluss Coin Metrics bis {tag(A['bis'])}, gerechnet in "
              + f"{A['dauer_s']:.1f} s".replace(".", ","),
              "  Vorab festgelegt in KONZEPT_Makro.md Abschnitt 10 (05.10.2026 19:15). Rendite VORWÄRTS r(t → t+h); Merkmal am Tag t, nur Daten",
              "  bis t. Null: 2000 Phasen-Surrogate des Merkmals (gleiche Autokorrelation). Belegt nur: Benjamini-Hochberg q = 0,10 UND gleiches Vorzeichen mit",
              "  |ρ| ≥ 0,05 in beiden Hälften (bis 2021 / ab 2022) UND Nachrechnung ohne Widerspruch.",
              "",
              f"  {'Merkmal':<46} {'h':>3} {'Tage':>5} {'ρ':>7} {'90 %':>15} {'ρ²':>6} {'p':>6} {'bis 2021':>8} {'ab 2022':>8} {'Drittel':>8}  Urteil"]
    for t in A["tests"]:
        if t.get("zu_kurz"):
            zeilen.append(f"  {t['name'][:46]:<46} {t['h']:>3} {t['n']:>5} {z(t['rho']):>7}  -- {t['grund']}")
            continue
        urteil = ("BELEGT" if t["belegt"] else ("BH ja, Hälften nein" if t.get("bh") and not t["haelften"]
                                                 else ("BH ja, Nachrechnung widerspricht" if t.get("bh") else "nein")))
        dr = t.get("drittel")
        zeilen.append(f"  {t['name'][:46]:<46} {t['h']:>3} {t['n']:>5} {z(t['rho'], 3):>7} [{z(t['lo90'])} {z(t['hi90'])}]".ljust(80)
                      + f" {t['r2'] * 100:5.1f}% {t['p']:6.3f} {z(t['rho_h1']):>8} {z(t['rho_h2']):>8} "
                      f"{('—' if dr is None or not math.isfinite(dr) else f'{dr * 100:+.1f} %'):>8}  {urteil}".replace(".", ","))
    m = A["n_tests"]
    zeilen += ["",
               f"  Zusammen: {A['belegt']} von {m} Tests belegt · Benjamini-Hochberg allein: {A['bh']} · unkorrigiert p < 0,10: {A['p10']} "
               f"(Zufall allein ≈ {m * 0.10:.1f})".replace(".", ","),
               "  ρ² = Anteil der erklärten Rangstreuung der Rendite (ρ = 0,1 erklärt 1 %). Drittel = mittlere Rendite im obersten minus im",
               "  untersten Drittel des Merkmals (beschreibend, ohne eigenen Test). 90 % = ρ ± 1,645 × Streuung der Null. Bei h = 7 und 30",
               "  überlappen die Renditen; die Null lässt sie unverändert und erhält die Autokorrelation des Merkmals.",
               "  Hinweis: Coin Metrics und ETF-Flüsse erscheinen 1–2 Tage nach dem Datum -- bei h = 1 ein Vorteil, den man live nicht hätte."]
    if A["fehlt"]:
        zeilen.append("  Nicht prüfbar: " + "; ".join(f"{f['name']} ({f['grund']})" for f in A["fehlt"]))
    ohne = sorted({t["name"] for t in A["tests"] if not t.get("zu_kurz") and t.get("n_h1", 0) < MIN_TAGE_HAELFTE})
    if ohne:
        zeilen.append("  Ohne erste Hälfte (weniger als 365 Tage vor 2022) -- gerechnet, nach der vorab festgelegten Regel aber nie belegt: "
                      + ", ".join(ohne))
    nn = A["nachrechnung"]
    if not nn.get("n"):
        zeilen.append("  Nachrechnung gegen mk_stand: Archiv noch leer -- kein Widerspruch prüfbar (Kriterium 3 hält)")
    else:
        ab = {k: v for k, v in nn["je_merkmal"].items() if v["abweichend"]}
        zeilen.append(f"  Nachrechnung gegen mk_stand: {nn['n']} archivierte Werte, "
                      + ("alle gleich" if not ab else "ABWEICHEND: " + "; ".join(f"{k} {v['abweichend']} von {v['n']} ({v['beispiel']})" for k, v in ab.items())))
    return "\n".join(zeilen)


# ================================================================================================ Kalibrierung und Selbsttest

def _ar1(n: int, phi: float, rng) -> np.ndarray:
    e = rng.normal(0, 1, n); x = np.empty(n); x[0] = e[0] / math.sqrt(max(1e-9, 1 - phi * phi))
    for i in range(1, n):
        x[i] = phi * x[i - 1] + e[i]
    return x


def _perzentil_expandierend(x: np.ndarray, min_n: int = 365) -> np.ndarray:
    import bisect
    out = np.full(len(x), np.nan); sl: list = []
    for i, v in enumerate(x):
        bisect.insort(sl, v)
        if len(sl) >= min_n:
            lo = bisect.bisect_left(sl, v); hi = bisect.bisect_right(sl, v)
            out[i] = 100.0 * (lo + 0.5 * (hi - lo - 1)) / (len(sl) - 1)
    return out


def _markt(n: int, rng, art: str) -> tuple:
    """Zufallsweg-Rendite (mit Volatilitäts-Clustern) und ein UNABHÄNGIGES, zähes Merkmal."""
    lv = _ar1(n, 0.98, rng) * 0.25                                       # Log-Volatilität mit Gedächtnis
    P = np.exp(np.cumsum(0.035 * np.exp(lv - 0.03) * rng.normal(0, 1, n)))
    if art == "ar":
        x = _ar1(n, 0.995, rng)
    elif art == "pz":
        x = _perzentil_expandierend(np.cumsum(rng.normal(0, 1, n)))
    else:                                                                # 30-Tage-Mittel einer zähen Größe (wie Funding 30 T)
        k = _ar1(n, 0.9, rng); x = np.convolve(k, np.ones(30) / 30, mode="full")[:n]; x[:29] = np.nan
    return P, x


def _block_null(x, y, h, rng, k=200):
    """Blockbootstrap-Null: Merkmal in Blöcken der Länge h neu gezogen, Renditen fest (zum Vergleich in der Kalibrierung)."""
    ok = np.isfinite(x) & np.isfinite(y); xs, ys = x[ok], y[ok]; n = len(xs); b = max(1, h)
    ry = raenge(ys); zy = ry - ry.mean(); out = np.empty(k)
    starts_n = n - b + 1
    for j in range(k):
        st = rng.integers(0, starts_n, int(math.ceil(n / b)))
        idx = (st[:, None] + np.arange(b)[None, :]).ravel()[:n]
        rx = raenge(xs[idx]); zx = rx - rx.mean()
        out[j] = np.dot(zx, zy) / math.sqrt(np.dot(zx, zx) * np.dot(zy, zy))
    return out


def kalibrierung(maerkte: int = 150, n: int = 4000, mit_block: bool = False, k_phasen: int = K_PHASEN, start: int = 1000,
                 verbose: bool = True) -> dict:
    """
    Fehlurteile (p < 0,01 / 0,05 / 0,10) auf Zufallswegen (mit Volatilitäts-Clustern) mit UNABHÄNGIGEN, zähen Merkmalen (AR 0,995,
    Perzentil eines Zufallswegs, 30-Tage-Mittel): Phasen-Randomisierung gegen zirkuläre Verschiebung (und optional Blockbootstrap).
    """
    zaehl: dict = {}

    def zaehle(meth, art, h, p):
        e = zaehl.setdefault((meth, art, h), [0, 0, 0, 0])
        e[0] += 1; e[1] += int(p < 0.01); e[2] += int(p < 0.05); e[3] += int(p < 0.10)

    for s in range(maerkte):
        rng = np.random.default_rng(start + s)
        for art in ("ar", "pz", "mittel30"):
            P, x = _markt(n, rng, art)
            for h in HORIZONTE:
                y = vorwaerts(P, h)
                rho, null, _n = phasen_null(x, y, k_phasen, seed=start + s)
                zaehle("phasen", art, h, p_zweiseitig(rho, null))
                rho_v, null_v, _n = verschiebungen(x, y)
                zaehle("verschiebung", art, h, p_zweiseitig(rho_v, null_v))
                if mit_block:
                    nb = _block_null(x, y, h, rng)
                    zaehle("block", art, h, float((1 + np.sum(np.abs(nb) >= abs(rho))) / (1 + len(nb))))
    if verbose:
        for (meth, art, h), (k, f1, f5, f10) in sorted(zaehl.items()):
            print(f"  {meth:<13} {art:<9} h {h:>2}: p < 0,01 {f1 / k:5.1%}, p < 0,05 {f5 / k:5.1%}, p < 0,10 {f10 / k:5.1%} (n {k})".replace(".", ","))
    return zaehl


def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    rng = np.random.default_rng(5)
    # 1) Ränge, Spearman, FFT-Verschiebung gegen direkte Rechnung
    a = np.array([3.0, 1.0, 2.0, 2.0, 5.0]); rk = raenge(a)
    x = rng.normal(0, 1, 900); y = 0.3 * x + rng.normal(0, 1, 900); x[::50] = np.round(x[::50], 1)
    rho, null, n = verschiebungen(x, y, 100)
    rx, ry = raenge(x), raenge(y)
    direkt = [float(np.corrcoef(np.roll(rx, k), ry)[0, 1]) for k in (100, 250, 800)]
    fft = [null[k - 100] for k in (100, 250, 800)]
    # Phasen-Null: bei unabhängigen Renditen ist die Streuung von ρ theoretisch 1/√n -- unabhängig von der Zähigkeit des Merkmals
    g = np.random.default_rng(11); n_ = 3000
    xa = _ar1(n_, 0.995, g); ya = g.normal(0, 1, n_)
    rho_a, null_a, _n = phasen_null(xa, ya, 4000, seed=1)
    rho_b, null_b, _n = phasen_null(ya, ya, 500, seed=2)
    sd_ok = abs(float(np.std(null_a)) * math.sqrt(n_) - 1) < 0.06
    ok("Ränge (Gleichstände gemittelt), Spearman, Verschiebungen per FFT = direkte Rechnung; Phasen-Null: Streuung 1/√n, ρ = 1 außerhalb",
       list(rk) == [4.0, 1.0, 2.5, 2.5, 5.0] and abs(rho - spearman(x, y)) < 1e-12 and max(abs(d - f) for d, f in zip(direkt, fft)) < 1e-9
       and len(null) == 900 - 200 + 1 and sd_ok and abs(rho_b - 1) < 1e-12 and p_zweiseitig(rho_b, null_b) < 0.003,
       f"Streuung × √n {np.std(null_a) * math.sqrt(n_):.3f} (Soll 1)")
    # 2) Rendite vorwärts, nie derselbe Tag; Benjamini-Hochberg wie von Hand
    P = np.exp(np.arange(10) * 0.1)
    r1, r3 = vorwaerts(P, 1), vorwaerts(P, 3)
    b = bh([0.001, 0.02, 0.03, 0.04, 0.5], 0.10)
    ok("Rendite vorwärts r(t → t+h), am Ende leer; Benjamini-Hochberg (q 0,10) wie von Hand",
       abs(r1[0] - 0.1) < 1e-12 and abs(r3[5] - 0.3) < 1e-12 and np.isnan(r1[-1]) and np.isnan(r3[-3]) and np.isfinite(r3[-4])
       and b == [True, True, True, True, False] and bh([0.06, 0.5], 0.10) == [False, False] and bh([0.04, 0.5], 0.10) == [True, False], f"BH {b}")
    # 3) Nulltest: Zufallswege mit unabhängigen, zähen Merkmalen -> Fehlurteile nahe 5 %
    zl = kalibrierung(maerkte=24, n=3000, k_phasen=1000, start=7000, verbose=False)
    ph = [v for (m, *_), v in zl.items() if m == "phasen"]
    k = sum(v[0] for v in ph); f1 = sum(v[1] for v in ph); f5 = sum(v[2] for v in ph); f10 = sum(v[3] for v in ph)
    ok("Nulltest: Zufallswege, unabhängige zähe Merkmale (AR 0,995, Perzentil, 30-T-Mittel) -> p < 0,05 in höchstens 8 %, p < 0,01 in 2,5 %",
       f5 <= 0.08 * k and f1 <= 0.025 * k and f10 <= 0.14 * k,
       f"Phasen-Null: p < 0,01 in {f1 / k:.1%}, p < 0,05 in {f5 / k:.1%}, p < 0,10 in {f10 / k:.1%} von {k} Tests".replace(".", ","))
    # 4) Positivkontrolle: Merkmal sagt die Rendite des nächsten Tags schwach voraus (ρ ≈ 0,08) -> belegt, Vorzeichen richtig
    treffer = 0
    for s in range(10):
        g = np.random.default_rng(300 + s); n_ = 4000
        zz = _ar1(n_, 0.99, g); zz = zz / zz.std()
        r = 0.035 * (0.12 * np.concatenate([[0.0], zz[:-1]]) + g.normal(0, 1, n_))
        P_ = np.exp(np.cumsum(r)); tage_ = np.arange(_tag("2015-01-01"), _tag("2015-01-01") + n_)
        t = pruefe(zz, vorwaerts(P_, 1), tage_, _tag(GRENZE_HAELFTE), seed=s, k=1000)
        treffer += int(t["p"] < 0.01 and t["rho"] > 0 and haelften_ok(t))
    ok("Positivkontrolle: echter Vorlauf (ρ ≈ 0,12 auf 1 Tag) -> p < 0,01 und beide Hälften in mindestens 9 von 10 Märkten",
       treffer >= 9, f"{treffer} von 10")
    # 5) Ära: Niveau des Merkmals und Drift der Rendite wechseln gemeinsam, sonst kein Zusammenhang -> Hälften verhindern „belegt“
    g = np.random.default_rng(77); n_ = 4000; tage_ = np.arange(_tag("2015-01-01"), _tag("2015-01-01") + n_)
    grenze_i = int(np.searchsorted(tage_, _tag(GRENZE_HAELFTE)))
    xx = _ar1(n_, 0.99, g) * 0.3 + np.where(np.arange(n_) < grenze_i, 1.0, -1.0)
    rr = g.normal(0, 0.03, n_) + np.where(np.arange(n_) < grenze_i, 0.004, -0.002)
    t = pruefe(xx, vorwaerts(np.exp(np.cumsum(rr)), 30), tage_, _tag(GRENZE_HAELFTE), k=1000)
    ok("Ära: gemeinsamer Wechsel von Niveau und Drift -> Ganzprobe auffällig, Hälften nicht -> nicht belegt",
       t["rho"] > 0.1 and not haelften_ok(t), f"ρ {t['rho']:.2f}, Hälften {t['rho_h1']:+.2f} / {t['rho_h2']:+.2f}".replace(".", ","))
    # 5b) Hälften: gleiches Vorzeichen allein reicht nicht, |ρ| ≥ 0,05 in beiden; FRED-Merkmal nimmt den Wert von t − 7
    schwelle = (not haelften_ok({"rho": 0.035, "rho_h1": 0.03, "rho_h2": 0.04}) and haelften_ok({"rho": 0.065, "rho_h1": 0.06, "rho_h2": 0.07})
                and not haelften_ok({"rho": 0.06, "rho_h1": 0.08, "rho_h2": -0.07}))
    tf = np.arange(_tag("2020-01-01"), _tag("2020-01-01") + 200)
    Df = {"tage": tf, "d0": int(tf[0]), "P": np.ones(200), "R": lambda name: (tf, (tf - tf[0]).astype(float) ** 2) if name == "fred:DFII10" else (tf[:0], np.zeros(0))}
    rz = [a for k_, _n, a, _h, _s in merkmale(Df) if k_ == "realzins4w"][0]
    i = 100
    fred_ok = rz is not None and abs(rz[i] - ((i - FRED_VERSATZ) ** 2 - (i - FRED_VERSATZ - 28) ** 2)) < 1e-9
    drei = (urteil({"bh": True, "haelften": True, "nach_widerspruch": False}) and not urteil({"bh": False, "haelften": True})
            and not urteil({"bh": True, "haelften": False}) and not urteil({"bh": True, "haelften": True, "nach_widerspruch": True}))
    ok("Urteil braucht alle drei Bedingungen; Hälften: |ρ| ≥ 0,05 in beiden, gleiches Vorzeichen; FRED = Wert von t − 7 gegen t − 35",
       schwelle and fred_ok and drei, f"Realzins am Tag 100: {rz[i] if rz is not None else '—'}")
    # 6) zu kurz (ETF seit 2024): keine Nullverteilung, kein Urteil, kein Absturz
    t = pruefe(rng.normal(0, 1, 650), rng.normal(0, 1, 650), np.arange(_tag("2024-01-11"), _tag("2024-01-11") + 650), _tag(GRENZE_HAELFTE), k=200)
    ok("Zu kurze Reihe (650 Tage): keine Nullverteilung, kein p, kein Urteil", t.get("zu_kurz") and t.get("p") is None and not haelften_ok(t),
       f"{t['n']} Tage")
    # 7) Ganze Auswertung auf einer kleinen Ableitung (Kurs + zwei Merkmale + leere FRED) und Bericht; Nachrechnung mit Abweichung
    n_ = 3000; g = np.random.default_rng(9); tage_ = np.arange(_tag("2016-01-01"), _tag("2016-01-01") + n_)
    Dm = {"tage": tage_, "d0": int(tage_[0]), "P": np.exp(np.cumsum(g.normal(0, 0.03, n_))), "MVRV_PZ": _perzentil_expandierend(np.cumsum(g.normal(0, 1, n_))),
          "FUNDING30": np.convolve(_ar1(n_, 0.9, g), np.ones(30) / 30, mode="full")[:n_], "OI_ABDECKUNG": {"lueckenhaft": True, "tage": 30, "soll": 2000}}
    stand = [("2024-03-01", "mvrv_pz", float(Dm["MVRV_PZ"][2900])), ("2024-03-01", "mvrv_datentag", float(tage_[2900])),
             ("2024-03-01", "funding", 1.234), ("2024-03-01", "funding_datentag", float(tage_[2900]))]
    A = auswertung(Dm, stand)
    txt = bericht_text(A)
    keys = {t["key"] for t in A["tests"]}
    nn = A["nachrechnung"]["je_merkmal"]
    ok("Auswertung: Tests je Merkmal und Horizont, fehlende Merkmale benannt (OI lädt), Nachrechnung erkennt Abweichung, Bericht",
       keys == {"mvrv_pz", "funding30"} and len(A["tests"]) == 6 and any(f["key"] == "oi" for f in A["fehlt"])
       and nn.get("mvrv_pz", {}).get("abweichend") == 0 and nn.get("funding30", {}).get("abweichend") == 1
       and all(t["nach_widerspruch"] for t in A["tests"] if t["key"] == "funding30") and not any(t["nach_widerspruch"] for t in A["tests"] if t["key"] == "mvrv_pz")
       and all(not t["belegt"] for t in A["tests"] if t["key"] == "funding30") and "Benjamini-Hochberg" in txt and "OI" in txt,
       f"{A['n_tests']} Tests, {len(A['fehlt'])} nicht prüfbar, Nachrechnung {A['nachrechnung']['n']} Werte")
    if verbose:
        for name, gut, txt_ in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<64} {txt_.replace('.', ',')}")
    return all(p[1] for p in pruef), pruef


def selbsttest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Makro × Kurs (U130) -- Selbsttest: Rangkorrelation, Phasen-Null, Nulltest, Positivkontrolle, Ära, Nachrechnung")
    gut, _ = probe(verbose)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if gut else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return gut


def stand_zeilen(pfad: str) -> list:
    """Archiv der Zonenkarte (mk_stand) als [(tag, schlüssel, wert)]; fehlt es, leer."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True)
    except sqlite3.Error:
        return []
    try:
        return [(r[0], r[1], r[2]) for r in con.execute("SELECT tag, kennzahl, wert FROM mk_stand")]
    except sqlite3.Error:
        return []
    finally:
        con.close()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Makro × Kurs (U130, Teil A)")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (makro.db liegt daneben)")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--kalibrieren", action="store_true", help="Fehlurteile auf Zufallswegen: Phasen gegen Verschiebung (einige Minuten)")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.kalibrieren:
        kalibrierung()
        return 0
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import hl_makro
    pfad = hl_makro.makro_pfad(a.db) if a.db else hl_makro.makro_pfad(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db"))
    con = hl_makro.lesen(pfad)
    if con is None:
        print(f"makro.db fehlt: {pfad}")
        return 1
    try:
        D = hl_makro.ableiten(con)
    finally:
        con.close()
    if not D.get("ok"):
        print("Makro-Daten unvollständig:", D.get("grund"))
        return 1
    print(bericht_text(auswertung(D, stand_zeilen(pfad))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
