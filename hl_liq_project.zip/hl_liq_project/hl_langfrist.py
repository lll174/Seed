#!/usr/bin/env python3
"""
hl_langfrist.py -- Vorprüfung zum 24-Monats-Chart für BTC (U277, seit 23.115; Debug 153).

Regeln: KONZEPT_Langfrist.md, Abschnitte 3 bis 8 -- festgelegt am 20.11.2026, bevor eine Zahl auf echten Daten gerechnet wurde.
Dieses Modul rechnet die Regeln nur aus; es legt keine fest.

Was gerechnet wird
  An jedem Stichtag (alle 30 Tage, das Raster von U126) entstehen aus den Daten bis zu diesem Tag vier Sichten auf den Kurs
  nach 90, 180, 365, 548 und 730 Tagen:
    A „ohne Richtung“  der Kurs bleibt; Breite aus der Schwankung der letzten 1.461 Tage
    B „Trend“          Power Law mit Rückkehr der Abweichung zum Median (die Rechnung von U126 / Debug 52)
    C „Zyklus“         Abweichung vom Trend wie im Mittel der früheren Zyklen ab demselben Tag nach dem Halving
    D „Bewertung“      Kurs gegen Realized Price und gegen 200-Wochen-MA (Paare von U126)
  Daraus die Fächer H (½ A + ½ B, der Hauptfächer), G (wandernde Gewichte), Z (mit Zyklus), W (mit Bewertung).
  Gemessen wird ab 01.01.2014: CRPS, Deckung der Bänder, Fehler der Mitte. Danach die Regeln 7.1 bis 7.4.

Ein Urteil, ein Lauf (Regel 7.5)
  Der erste Lauf mit vollständigen Daten legt sein Urteil in makro.db ab (mk_meta „langfrist:urteil“). Spätere Läufe zeigen den
  Stand von heute und das abgelegte Urteil; sie ändern es nicht. Eine neue Regelversion legt das alte Urteil mit Datum ab.

Aufrufe
  hl_langfrist.py --vorpruefung --db PFAD     Bericht als Text (Debug 153)
  hl_langfrist.py --selbsttest                Proben P1 bis P9 auf erzeugten Reihen (ohne Netz, ohne echte Daten)

Kein Handelssignal: Der Bericht nennt Spannen und Messwerte, keine Empfehlung.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sqlite3
import statistics
import sys
import time
from collections import namedtuple

import numpy as np

import hl_makro as M
import hl_makro_signal as S
from hl_ausblick import gew_quantile

VERSION_MODUL = "2026-09-23.115"
REGELVERSION = 1                                        # KONZEPT_Langfrist.md 7.6: jede Änderung der Regeln ist eine neue Version
DEBUG_NR = 153
SCHLUESSEL = "langfrist:urteil"                         # mk_meta in makro.db
SCHLUESSEL_ARCHIV = "langfrist:archiv"

HORIZONTE = (90, 180, 365, 548, 730)                    # 3, 6, 12, 18, 24 Monate; die ersten drei sind die von U126
ABSTAND = S.PRUEF_ABSTAND                               # 30 Tage zwischen den Stichtagen
TAU = np.round(np.arange(1, 200) * 0.005, 3)            # 199 Quantile: 0,5 % ... 99,5 %
ZN = np.array([statistics.NormalDist().inv_cdf(float(t)) for t in TAU])
I10, I25, I50, I75, I90 = 19, 49, 99, 149, 179
Q5 = (0.1, 0.25, 0.5, 0.75, 0.9)
MIN_FEHLER = S.MIN_FEHLER                               # 20 bekannte Fehler, sonst Modellband
FEHLER_TAGE = S.FEHLER_JAHRE * 365                      # Fehlergedächtnis: vier Jahre
VOL_TAGE = 1461                                         # Schwankung der Sicht A: letzte 1.461 Tage
VOL_MIN = 365                                           # ... aus mindestens 365 Tagesrenditen
AB_TAG = M.tag_ts("2014-01-01") // M.TAG                # gewertet werden Stichtage ab hier; frühere füllen nur das Fehlergedächtnis
ALPHA = 0.05 / 3                                        # Regel 7.1: drei Kandidaten
MIN_FENSTER = 6                                         # Regel 7.1: mindestens sechs Fenster ohne Überlappung
MAX_FENSTER = 20                                        # der Test zählt alle 2^n Vorzeichenmuster aus -- bis 20 Fenster
FAKTOR_74 = 20.0                                        # Regel 7.4: 90-%-Rand über dem 20-Fachen des 10-%-Rands -> Rückfrage
NEBEN = (("8 J", 2922), ("4 J", 1461))                  # Regel 7.7: Sicht B mit anderen Zeiträumen (ohne Folgen)
FAECHER = ("H", "G", "Z", "W")
SICHTEN = ("A", "B", "C", "D")
NAMEN = {"A": "ohne Richtung", "B": "Trend", "C": "Zyklus", "D": "Bewertung",
         "H": "Hauptfächer (½ A + ½ B)", "G": "wandernde Gewichte", "Z": "mit Zyklus (½ A + ¼ B + ¼ C)", "W": "mit Bewertung (½ A + ¼ B + ¼ D)"}
# Wann der erste Lauf zählt (vor dem ersten Lauf festgelegt, KONZEPT_Langfrist.md 15): Schutz vor einem Urteil auf halben Daten
VOLL_MAX_ALTER = 7                                      # letzter Kurstag höchstens 7 Tage alt
VOLL_MAX_LUECKEN = 30                                   # höchstens 30 Tage ohne Kurs zwischen erstem und letztem Tag
VOLL_MIN_365 = 100                                      # mindestens 100 gewertete Stichtage bei 365 Tagen (erwartet: rund 145)

Fall = namedtuple("Fall", "o crps in80 in50 oben unten fehler gleich spanne q")


# ================================================================================================ Maße

def crps_gew(x: np.ndarray, w: np.ndarray, y: float) -> float:
    """CRPS einer gewichteten Stichprobe, genau: E|X−y| − ½·E|X−X'| (kleiner ist besser). Die Gewichte werden auf 1 gebracht."""
    o = np.argsort(x); xs = x[o]; ws = w[o] / w.sum()
    cw = np.cumsum(ws)
    e_xy = float(np.sum(ws * np.abs(xs - y)))
    e_xx = float(2.0 * np.sum(ws * xs * (2.0 * cw - ws - 1.0)))
    return e_xy - 0.5 * e_xx


def werten(x: np.ndarray, w: np.ndarray, ist: float) -> tuple:
    """Ein Fächer (Werte, Gewichte, in ln) gegen den eingetretenen ln-Kurs: CRPS, im 80-%-Band (Ränder 10 und 90 %), im 50-%-Band
    (Ränder 25 und 75 %), über dem 90-%-Rand, unter dem 10-%-Rand, Fehler der Mitte, Spanne 10–90 %, die fünf Quantile."""
    q = gew_quantile(x, w, Q5)
    return (crps_gew(x, w, ist), bool(q[0] <= ist <= q[4]), bool(q[1] <= ist <= q[3]), bool(ist > q[4]), bool(ist < q[0]),
            float(ist - q[2]), float(q[4] - q[0]), tuple(float(v) for v in q))


def flip_p(d) -> float:
    """
    Einseitiger Vorzeichenwechsel-Test (Regel 7.1): Anteil aller 2^n Vorzeichenmuster, deren Mittel mindestens so groß ist wie das
    beobachtete. Unter MIN_FENSTER Werten gibt es keinen Nachweis (1,0); über MAX_FENSTER ist der Test nicht gebaut (NaN).
    """
    d = np.asarray(d, dtype=float); n = len(d)
    if n < MIN_FENSTER:
        return 1.0
    if n > MAX_FENSTER:
        return float("nan")
    obs = float(d.sum())
    tol = 1e-12 * max(1.0, float(np.abs(d).sum()))
    bits = np.arange(n)[None, :]
    treffer = 0
    for a in range(0, 2 ** n, 65536):
        idx = np.arange(a, min(a + 65536, 2 ** n))[:, None]
        m = ((idx >> bits) & 1) * 2 - 1
        treffer += int(np.sum((m * d[None, :]).sum(axis=1) >= obs - tol))
    return treffer / 2 ** n


def ohne_ueberlappung(R: list, h: int) -> list:
    """Fenster ohne Überlappung: jeder ⌈h ÷ 30⌉-te Stichtag ab dem ersten gewerteten. Fehlt ein Stichtag, bleibt das Raster stehen."""
    if not R:
        return []
    abst = math.ceil(h / ABSTAND) * ABSTAND
    return [r for r in R if (r.o - R[0].o) % abst == 0]


# ================================================================================================ Bausteine der Sichten

def _bekannt(mem: list, o: int, h: int) -> list:
    """Regel _fehler_bekannt von U126: Fehler, deren Ziel am Stichtag o schon bekannt war, aus den Stichtagen der vier Jahre davor."""
    return [e for (o2, z2, e) in mem if z2 <= o and o2 >= o - h - FEHLER_TAGE]


def _b3(qs: dict) -> dict:
    """Regel B3: Die Spanne 10–90 % fällt nicht mit dem Horizont -- sonst alle Abstände zur Mitte mit einem Faktor strecken."""
    vor = 0.0
    out = {}
    for h in HORIZONTE:
        q = qs.get(h)
        if q is None:
            continue
        sp = float(q[I90] - q[I10])
        if 0 < sp < vor:
            q = q[I50] + (q - q[I50]) * (vor / sp)
            sp = vor
        vor = max(vor, sp)
        out[h] = q
    return out


def paare_bauen(tage, P, MVRV=None, RP=None, WMA=None, PL=None) -> dict:
    """
    Die drei Paare von U126, die die Langfrist braucht -- gebaut wie in hl_makro_signal.paare_aus (der Selbsttest vergleicht):
      pl   y = ln(Kurs ÷ Fair Value), Fortschreibung mit den Monatsparametern des Power Law        -> Sicht B (und C)
      rp   y = ln(MVRV),              Fortschreibung des Realized Price mit seinem 365-Tage-Trend  -> Sicht D
      wma  y = ln(Kurs ÷ 200-W-MA),   Fortschreibung des 200-Wochen-MA mit seinem 365-Tage-Trend   -> Sicht D
    Fehlen PL oder WMA, werden sie aus dem Kurs gerechnet (hl_makro.powerlaw_monatlich, hl_makro.wma200).
    """
    tage = np.asarray(tage, dtype=np.int64); P = np.asarray(P, dtype=float)
    d0 = int(tage[0])
    PL = PL if PL is not None else M.powerlaw_monatlich(tage, P)
    WMA = np.asarray(WMA if WMA is not None else M.wma200(tage, P), dtype=float)

    def y_aus(ratio):
        ratio = np.asarray(ratio, dtype=float)
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(np.isfinite(ratio) & (ratio > 0), np.log(np.where(ratio > 0, ratio, 1.0)), np.nan)
    fvk = np.asarray(PL["fv_kausal"], dtype=float)
    with np.errstate(invalid="ignore", divide="ignore"):
        out = {"d0": d0, "tage": tage, "P": P,
               "pl": (y_aus(P / fvk), S.Referenz("powerlaw", fvk, d0, PL.get("parameter"))),
               "wma": (y_aus(P / WMA), S.Referenz("trend", WMA, d0))}
        if MVRV is not None and RP is not None:
            out["rp"] = (y_aus(MVRV), S.Referenz("trend", np.asarray(RP, dtype=float), d0))
    return out


# ================================================================================================ Rückrechnung

class Lauf:
    """
    Rückrechnung auf einer Tagesreihe. w = Zeitraum für Median und AR(1) der Sicht B (0 = „alles“; nur die Nebenrechnung 7.7
    nutzt andere). b3 = Regel B3 anwenden (nur die Gegenprobe mit U126 schaltet sie ab).
    """

    def __init__(self, B: dict, w: int = 0, b3: bool = True):
        y, refx = B["pl"]
        y = np.asarray(y, dtype=float)
        fin = np.nonzero(np.isfinite(y))[0]
        if not len(fin):
            raise ValueError("keine Abweichung vom Trend (kein Tag mit Kurs und Fair Value)")
        self.T = int(fin[-1]); self.n = self.T + 1                      # letzter Tag mit Kurs und Fair Value; danach nichts
        self.tage = np.asarray(B["tage"], dtype=np.int64)[: self.n]
        self.d0 = int(self.tage[0])
        P = np.asarray(B["P"], dtype=float)[: self.n]
        self.P = P
        with np.errstate(invalid="ignore", divide="ignore"):
            self.lnP = np.where(np.isfinite(P) & (P > 0), np.log(np.where(P > 0, P, 1.0)), np.nan)
        self.y = y[: self.n]
        self.refx = refx
        self.paare = [(k, np.asarray(B[k][0], dtype=float)[: self.n], B[k][1]) for k in ("rp", "wma") if k in B]
        self.w = int(w); self.b3 = bool(b3)
        self.halv = [h - self.d0 for h in M.halving_tage()]
        self.ab = AB_TAG - self.d0
        self.start = int(fin[0]) + (self.w if self.w else 365)
        self.urs = list(range(self.start, self.T - min(HORIZONTE) + 1, ABSTAND))
        # Fehlergedächtnis je Sicht und Horizont: (Stichtag, Zieltag, Fehler des Rohwerts) und Fehler der Mitte (für G)
        self.roh = {s: {h: [] for h in HORIZONTE} for s in "BCD"}
        self.mit = {s: {h: [] for h in HORIZONTE} for s in "AB"}
        self.erg = {f: {h: [] for h in HORIZONTE} for f in SICHTEN + FAECHER}
        self.gew_g = {h: [] for h in HORIZONTE}
        self.ohne_ziel = {h: 0 for h in HORIZONTE}                      # Ziel liegt in der Reihe, hat aber keinen Kurs
        self.ohne_rechnung = 0                                          # Stichtage, an denen keine Sicht B möglich war
        self.gerechnet = False

    # -------------------------------------------------------------------------------------------- Sichten
    def _lnfv(self, o: int, i: int) -> float:
        """ln Fair Value am Tag i mit den Parametern des Stichtags o."""
        return math.log(self.refx.pl_wert(o, i - o))

    def _fenster(self, y: np.ndarray, o: int, w: int) -> np.ndarray:
        """Die Tage, aus denen Median und AR(1) am Stichtag o gerechnet werden -- nur Vergangenheit (wie U126)."""
        return S._fenster_daten(y, o, w)

    def _ar(self, y: np.ndarray, o: int, w: int = 0):
        win = self._fenster(y, o, w)
        finw = win[np.isfinite(win)]
        if len(finw) < S.MIN_N or not math.isfinite(y[o]):
            return None
        mu = float(np.median(finw))
        f = S.ar1(win - mu)
        if not f:
            return None
        return mu, min(f["phi"], 1.0), f["sigma"]

    def _vol(self, o: int):
        """Sicht A: Standardabweichung der täglichen ln-Renditen der letzten 1.461 Tage, auf ein Jahr hochgerechnet."""
        seg = self.lnP[max(0, o - VOL_TAGE): o + 1]
        r = np.diff(seg)
        r = r[np.isfinite(r)]
        if len(r) < VOL_MIN:
            return None
        return float(np.std(r, ddof=1)) * math.sqrt(365)

    def sichten(self, o: int, b3: bool | None = None) -> dict | None:
        """Verteilungen (199 Quantile in ln) aller Sichten am Stichtag o für alle Horizonte; None, wenn A oder B nicht möglich ist."""
        ar = self._ar(self.y, o, self.w)
        v = self._vol(o)
        if ar is None or v is None or not math.isfinite(self.lnP[o]):
            return None
        mu, phi, sigma = ar
        aus = {"A": {}, "B": {}, "C": {}, "D": {}, "roh": {"A": {}, "B": {}, "C": {}, "D": {}}, "v": v, "phi": phi, "mu": mu,
               "band": {}, "zyklen": 0, "paare": []}
        streu = {}
        for h in HORIZONTE:
            r = self.refx.prognose(o, h)
            if not (math.isfinite(r) and r > 0):
                return None
            aus["A"][h] = self.lnP[o] + ZN * v * math.sqrt(h / 365)
            aus["roh"]["A"][h] = float(self.lnP[o])
            m, sd = S.y_prognose(float(self.y[o]), mu, phi, sigma, h)
            roh = math.log(r) + m
            E = _bekannt(self.roh["B"][h], o, h)
            if len(E) >= MIN_FEHLER:
                q = np.quantile(E, TAU)
                aus["B"][h] = roh + q; streu[h] = q - q[I50]; aus["band"][h] = "empirisch"
            else:
                aus["B"][h] = roh + ZN * sd; streu[h] = ZN * sd; aus["band"][h] = "modell"
            aus["roh"]["B"][h] = roh
        # Sicht C: frühere Zyklen ab demselben Tag nach dem Halving, gegen den Trend
        letzte = [x for x in self.halv if x <= o]
        if len(letzte) >= 2:
            tau = o - letzte[-1]
            for h in HORIZONTE:
                ql = []
                for x in letzte[:-1]:
                    i1, i2 = x + tau, x + tau + h
                    if i1 < 0 or i2 > o or not (math.isfinite(self.lnP[i1]) and math.isfinite(self.lnP[i2])):
                        continue
                    ql.append((self.lnP[i2] - self.lnP[i1]) - (self._lnfv(o, i2) - self._lnfv(o, i1)))
                if not ql:
                    continue
                roh = self.lnP[o] + (self._lnfv(o, o + h) - self._lnfv(o, o)) + float(np.mean(ql))
                E = _bekannt(self.roh["C"][h], o, h)
                aus["C"][h] = roh + (np.quantile(E, TAU) if len(E) >= MIN_FEHLER else streu[h])
                aus["roh"]["C"][h] = float(roh)
                aus["zyklen"] = max(aus["zyklen"], len(ql))
        # Sicht D: Bewertungspaare (Rückkehr zum Median, Referenz mit ihrem 365-Tage-Trend)
        pp = []
        for key, yp, rx in self.paare:
            a = self._ar(yp, o, 0)
            if a is not None:
                pp.append((key, yp, rx, a))
        if pp:
            for h in HORIZONTE:
                rohs = []; dabei = []
                for key, yp, rx, (mu_, phi_, sig_) in pp:
                    r = rx.prognose(o, h)
                    if not (math.isfinite(r) and r > 0):
                        continue
                    m, _sd = S.y_prognose(float(yp[o]), mu_, phi_, sig_, h)
                    rohs.append(math.log(r) + m); dabei.append(key)
                if not rohs:
                    continue
                roh = float(np.mean(rohs))
                E = _bekannt(self.roh["D"][h], o, h)
                aus["D"][h] = roh + (np.quantile(E, TAU) if len(E) >= MIN_FEHLER else streu[h])
                aus["roh"]["D"][h] = roh
                aus["paare"] = dabei
        if self.b3 if b3 is None else b3:
            for s in "BCD":
                aus[s] = _b3(aus[s])
        return aus

    def faecher(self, V: dict, o: int, h: int) -> dict:
        """Fächer als (Werte, Gewichte). G: Gewicht von B aus den bekannten Fehlern der Mitten der letzten vier Jahre."""
        A, B = V["A"][h], V["B"][h]
        w1 = np.full(199, 1 / 199)
        F = {"A": (A, w1), "B": (B, w1), "H": (np.concatenate([A, B]), np.concatenate([w1 * 0.5, w1 * 0.5]))}
        ea = _bekannt(self.mit["A"][h], o, h); eb = _bekannt(self.mit["B"][h], o, h)
        wb = 0.5
        if len(ea) >= MIN_FEHLER and len(eb) >= MIN_FEHLER:
            ma, mb = float(np.mean(np.square(ea))), float(np.mean(np.square(eb)))
            if ma + mb > 0:
                wb = min(0.75, max(0.25, ma / (ma + mb)))
        F["G"] = (np.concatenate([A, B]), np.concatenate([w1 * (1 - wb), w1 * wb]))
        F["wb"] = wb
        for name, s in (("Z", "C"), ("W", "D")):
            X = V[s].get(h)
            if X is None:
                F[name] = None
            else:
                F[s] = (X, w1)
                F[name] = (np.concatenate([A, B, X]), np.concatenate([w1 * 0.5, w1 * 0.25, w1 * 0.25]))
        return F

    def stand(self, o: int):
        """Alle Sichten und Fächer am Stichtag o. EINE Funktion für die Rückrechnung und für heute (KONZEPT 10: gleiche Rechnung)."""
        V = self.sichten(o)
        if V is None:
            return None
        return V, {h: self.faecher(V, o, h) for h in HORIZONTE}

    def fan(self, o: int) -> dict | None:
        """Für Chart und Bericht: je Horizont und Fächer (auch die Sichten allein) die Ränder 10/25/50/75/90 % in ln -- aus stand()."""
        st = self.stand(o)
        if st is None:
            return None
        V, FF = st
        out = {}
        for h in HORIZONTE:
            F = FF[h]
            out[h] = {name: tuple(float(v) for v in gew_quantile(F[name][0], F[name][1], Q5))
                      for name in SICHTEN + FAECHER if F.get(name) is not None}
            for name in ("Z", "W"):                                          # ohne C bzw. D ist Z bzw. W dort gleich H
                out[h].setdefault(name, out[h]["H"])
            out[h]["wb"] = F["wb"]
        return {"o": o, "h": out, "roh": V["roh"], "v": V["v"], "phi": V["phi"], "mu": V["mu"], "band": V["band"],
                "zyklen": V["zyklen"], "paare": V["paare"]}

    def rechnen(self) -> "Lauf":
        for o in self.urs:
            st = self.stand(o)
            if st is None:
                self.ohne_rechnung += 1
                continue
            V, FF = st
            for h in HORIZONTE:
                F = FF[h]
                im_bereich = o + h <= self.T
                bekannt = im_bereich and math.isfinite(self.lnP[o + h])
                if im_bereich and not bekannt and o >= self.ab:
                    self.ohne_ziel[h] += 1
                if not bekannt:
                    continue
                ist = float(self.lnP[o + h]); z = o + h
                if o >= self.ab:
                    for name in SICHTEN + FAECHER:
                        f = F.get(name)
                        gleich_h = f is None
                        if f is None:
                            if name in ("C", "D"):
                                continue
                            f = F["H"]                                       # ohne C bzw. D ist Z bzw. W dort gleich H
                        if name == "G" and F["wb"] == 0.5:
                            gleich_h = True
                        c, i80, i50, ob, un, e, sp, q = werten(f[0], f[1], ist)
                        self.erg[name][h].append(Fall(o, c, i80, i50, ob, un, e, gleich_h, sp, q))
                    self.gew_g[h].append((o, F["wb"]))
                # Fehlergedächtnis (auch vor 2014)
                self.roh["B"][h].append((o, z, ist - V["roh"]["B"][h]))
                for s in "CD":
                    if h in V["roh"][s]:
                        self.roh[s][h].append((o, z, ist - V["roh"][s][h]))
                self.mit["A"][h].append((o, z, ist - float(self.lnP[o])))
                self.mit["B"][h].append((o, z, ist - float(V["B"][h][I50])))
        self.gerechnet = True
        return self

    # -------------------------------------------------------------------------------------------- Auswertung und Regeln
    def tabelle(self) -> dict:
        out = {}
        for name, je in self.erg.items():
            out[name] = {}
            for h, R in je.items():
                if not R:
                    continue
                un = ohne_ueberlappung(R, h)
                out[name][h] = {"n": len(R), "crps": float(np.mean([r.crps for r in R])), "d80": float(np.mean([r.in80 for r in R])),
                                "d50": float(np.mean([r.in50 for r in R])), "oben": float(np.mean([r.oben for r in R])),
                                "unten": float(np.mean([r.unten for r in R])),
                                "rmse10": float(math.sqrt(np.mean([r.fehler ** 2 for r in R])) / math.log(10)),
                                "spanne": float(np.mean([r.spanne for r in R])), "erster": int(R[0].o), "letzter": int(R[-1].o),
                                "n_un": len(un), "t_un": int(sum(1 for r in un if r.in80)), "t50_un": int(sum(1 for r in un if r.in50))}
        return out

    def abloesung(self, name: str, alpha: float = ALPHA) -> dict:
        """
        Regel 7.1 für einen Kandidaten: (1) Vorzeichenwechsel-Test bei 365 Tagen auf den Fenstern ohne Überlappung (d = CRPS von H −
        CRPS des Kandidaten; Fenster, in denen der Kandidat mit H übereinstimmt, zählen nicht), (2) bei 730 Tagen über alle
        gewerteten Stichtage im Mittel nicht schlechter, (3) in den letzten vier Jahren bei 365 Tagen im Mittel nicht schlechter.
        """
        H365 = self.erg["H"][365]; K = self.erg[name][365]
        Hh = {r.o: r.crps for r in H365}
        raster = {r.o for r in ohne_ueberlappung(H365, 365)}
        d = [Hh[r.o] - r.crps for r in K if r.o in raster and not r.gleich]
        p = flip_p(d)
        test = bool(p <= alpha)                                              # NaN (zu viele Fenster) ist kein Nachweis
        k7 = [r.crps for r in self.erg[name][730]]; h7 = [r.crps for r in self.erg["H"][730]]
        b = bool(k7) and bool(h7) and float(np.mean(k7)) <= float(np.mean(h7))
        letzt = K[-1].o if K else 0
        jung = [(Hh[r.o], r.crps) for r in K if r.o >= letzt - FEHLER_TAGE]
        c = bool(jung) and float(np.mean([x[1] for x in jung])) <= float(np.mean([x[0] for x in jung]))
        m_k = float(np.mean([r.crps for r in K])) if K else float("nan")
        return {"n": len(d), "siege": int(sum(1 for x in d if x > 0)), "p": p, "test": test, "b_730": b, "c_jung": c,
                "crps_365": m_k, "crps_730": float(np.mean(k7)) if k7 else float("nan"),
                "h_730": float(np.mean(h7)) if h7 else float("nan"),
                "jung_k": float(np.mean([x[1] for x in jung])) if jung else float("nan"),
                "jung_h": float(np.mean([x[0] for x in jung])) if jung else float("nan"), "n_jung": len(jung),
                "abgeloest": bool(test and b and c)}

    def hauptfaecher(self) -> tuple:
        """Hauptfächer nach 7.1: H, außer ein Kandidat besteht (bei mehreren: kleinstes mittleres CRPS bei 365 Tagen)."""
        best = []
        for k in ("G", "Z", "W"):
            a = self.abloesung(k)
            if a["abgeloest"]:
                best.append((a["crps_365"], k))
        return (min(best)[1] if best else "H"), [k for _c, k in best]

    def alarm(self, name: str = "H") -> dict:
        """Regeln 7.2 und 7.3: Deckung des 80-%-Bands gegen 0,80 ∓ 2·√(0,16 ÷ n), n = Fenster ohne Überlappung."""
        out = {}
        for h in HORIZONTE:
            R = self.erg[name][h]
            if not R:
                continue
            n_un = len(ohne_ueberlappung(R, h))
            d = float(np.mean([r.in80 for r in R]))
            halb = 2 * math.sqrt(0.16 / n_un)
            out[h] = {"deckung": d, "grenze": 0.8 - halb, "alarm": bool(d < 0.8 - halb), "grenze_oben": 0.8 + halb,
                      "zu_breit": bool(d > 0.8 + halb), "n_un": n_un}
        return out


# ================================================================================================ Urteil (Regeln 7.1 bis 7.5)

def _r(x, k: int = 6):
    """Zahl für die Ablage: endlich und auf k geltende Stellen gerundet, sonst None. Ganze Zahlen und Ja/Nein bleiben, was sie sind."""
    if x is None:
        return None
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if isinstance(x, (int, np.integer)):
        return int(x)
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(x):
        return None
    return float(f"{x:.{k}g}")


def tagtext(tag: int) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(tag) * M.TAG))


def auswerten(L: Lauf, haupt_fest: str | None = None) -> dict:
    """
    Aus einer fertigen Rückrechnung: Tabelle, Regeln 7.1 bis 7.4, der Fächer von heute. Reine Rechnung, legt nichts ab.
    haupt_fest: der Hauptfächer eines schon abgelegten Urteils -- er bleibt in Kraft (Regel 7.5); Alarm und der Fächer von heute
    gelten dann für ihn. „haupt_regel“ nennt, was Regel 7.1 auf dem Stand von heute ergäbe.
    """
    T = L.tabelle()
    abl = {k: L.abloesung(k) for k in ("G", "Z", "W")}
    haupt_regel, bestanden = L.hauptfaecher()
    haupt = haupt_fest if haupt_fest in FAECHER else haupt_regel
    al = L.alarm(haupt)
    heute = L.fan(L.T)
    E = {"ok": True, "regel": REGELVERSION, "version": VERSION_MODUL,
         "daten": {"erster": int(L.d0), "letzter": int(L.d0 + L.T), "tage": int(L.n),
                   "luecken": int(np.sum(~np.isfinite(L.lnP))), "pruef": daten_pruefsumme(L)},
         "raster": {"start": int(L.d0 + L.start), "n": len(L.urs), "ohne_rechnung": int(L.ohne_rechnung),
                    "erster_gewertet": int(L.d0 + T["H"][90]["erster"]) if 90 in T.get("H", {}) else None,
                    "ohne_ziel": {str(h): int(L.ohne_ziel[h]) for h in HORIZONTE}},
         "tabelle": {f: {str(h): {k: _r(v) for k, v in e.items()} for h, e in je.items()} for f, je in T.items()},
         "abloesung": {k: {kk: _r(vv) for kk, vv in a.items()} for k, a in abl.items()},
         "haupt": haupt, "haupt_regel": haupt_regel, "bestanden": bestanden,
         "alarm": {str(h): {k: _r(v) for k, v in a.items()} for h, a in al.items()},
         "gew_g": {str(h): _r(float(np.mean([w for _o, w in L.gew_g[h]]))) if L.gew_g[h] else None for h in HORIZONTE}}
    alarme = [h for h, a in al.items() if a["alarm"]]
    breit = [h for h, a in al.items() if a["zu_breit"]]
    E["alarm_bei"] = alarme; E["zu_breit_bei"] = breit
    if heute is not None:
        q = heute["h"][730][haupt]
        verh = math.exp(q[4] - q[0])
        E["heute"] = {"tag": int(L.d0 + L.T), "kurs": _r(float(L.P[L.T]), 8), "verh_730": _r(verh), "frage_74": bool(verh > FAKTOR_74),
                      "wb": {str(h): _r(heute["h"][h]["wb"]) for h in HORIZONTE}, "v": _r(heute["v"]), "phi": _r(heute["phi"], 9),
                      "zyklen": int(heute["zyklen"]), "paare": list(heute["paare"]),
                      "band": {str(h): heute["band"][h] for h in HORIZONTE},
                      "usd": {str(h): {name: [_r(math.exp(v), 8) for v in heute["h"][h][name]] for name in SICHTEN + FAECHER
                                       if name in heute["h"][h]} for h in HORIZONTE},
                      "roh": {s: {str(h): _r(math.exp(v), 8) for h, v in heute["roh"][s].items()} for s in SICHTEN}}
    else:
        E["heute"] = None
    frage = bool(E["heute"] and E["heute"]["frage_74"])
    gruende = []
    if alarme:
        gruende.append("Alarm 7.2 (Band zu schmal) bei " + ", ".join(f"{h} Tagen" for h in alarme))
    if frage:
        gruende.append(f"Regel 7.4: 90-%-Rand über dem {FAKTOR_74:.0f}-Fachen des 10-%-Rands bei 730 Tagen")
    if E["heute"] is None:
        gruende.append("für heute ist kein Fächer rechenbar")
    E["urteil"] = "rueckfrage" if gruende else "bauen"
    E["gruende"] = gruende
    return E


def daten_pruefsumme(L: Lauf) -> str:
    """Kurze Prüfsumme der Kursreihe (auf 6 geltende Stellen), damit ein späterer Lauf sagen kann, ob sich die Historie geändert hat."""
    h = hashlib.sha1()
    for v in L.P:
        h.update((f"{v:.6g}" if math.isfinite(v) else "-").encode()); h.update(b";")
    return h.hexdigest()[:12]


def nebenrechnung(B: dict, L: Lauf) -> dict:
    """Regel 7.7 (ohne Folgen): Sicht B mit den Zeiträumen 8 J und 4 J statt „alles“ -- die Mitte von heute und ihr Fehler im Rückblick."""
    out = {}
    heute = L.fan(L.T)
    T0 = L.tabelle()["B"]
    out["alles"] = {"mitte": {str(h): _r(math.exp(heute["h"][h]["B"][2]), 8) for h in HORIZONTE} if heute else None,
                    "rmse10": {str(h): _r(T0[h]["rmse10"]) for h in T0}, "n": {str(h): T0[h]["n"] for h in T0}}
    for name, w in NEBEN:
        try:
            Lw = Lauf(B, w=w).rechnen()
        except ValueError:
            out[name] = None
            continue
        fw = Lw.fan(Lw.T)
        Tw = Lw.tabelle()["B"]
        out[name] = {"mitte": {str(h): _r(math.exp(fw["h"][h]["B"][2]), 8) for h in HORIZONTE} if fw else None,
                     "rmse10": {str(h): _r(Tw[h]["rmse10"]) for h in Tw}, "n": {str(h): Tw[h]["n"] for h in Tw}}
    return out


def gegenprobe_u126(B: dict, L: Lauf) -> dict:
    """
    Auf den Daten des Laufs: 90, 180 und 365 Tage der Sicht B gegen hl_makro_signal.pruefung und prognose (Paar „Kurs gegen
    Power-Law-Fair-Value“, Zeitraum des Laufs) -- Zahl der Fälle, Ränder der bekannten Fehler, heutiges Band (ohne Regel B3).
    Hat ein Horizont weniger als 20 bekannte Fehler der letzten vier Jahre, werden seine Ränder nicht verglichen (U126 nimmt dann
    alle Fehler, die Langfrist das Modellband); „ohne“ nennt diese Horizonte.
    """
    y, refx = B["pl"]
    y = np.asarray(y, dtype=float)
    pr = S.pruefung(y, np.asarray(B["P"], dtype=float), refx, L.T, L.w)
    pg = S.prognose(y, refx, L.T, L.w, pr)
    Vt = L.sichten(L.T, b3=False)
    out = {"gleich": True, "max": 0.0, "n": {}, "heute": {}, "ohne": []}
    for h in S.HORIZONTE:
        g = pr[str(h)]
        R = L.roh["B"][h]
        jung = _bekannt(R, L.T, h)
        out["n"][str(h)] = (g.get("n"), len(R))
        out["gleich"] = out["gleich"] and g.get("n") == len(R)
        if len(jung) < MIN_FEHLER or g.get("f_lo") is None:
            out["ohne"].append(h)
            continue
        lo, hi = np.quantile(jung, [0.1, 0.9])
        ab = max(abs(g["f_lo"] - float(lo)), abs(g["f_hi"] - float(hi)))
        out["gleich"] = out["gleich"] and ab < 1e-9
        out["max"] = max(out["max"], ab)
    if pg and Vt:
        for hh in pg["h"]:
            h = hh["tage"]
            if hh.get("wert_lo") is None:
                continue
            out["heute"][str(h)] = (hh["wert_lo"], hh["wert_hi"], hh["wert"])
            if h in out["ohne"]:
                continue
            ab = max(abs(math.log(hh["wert_lo"]) - float(Vt["B"][h][I10])), abs(math.log(hh["wert_hi"]) - float(Vt["B"][h][I90])))
            out["gleich"] = out["gleich"] and ab < 1e-9
            out["max"] = max(out["max"], ab)
    else:
        out["gleich"] = False
    return out


def kausal_probe(B: dict, L: Lauf, stellen: tuple = (0.35, 0.6, 0.85)) -> dict:
    """
    Kein Blick in die Zukunft, geprüft auf den Daten des Laufs: An drei Stichtagen muss die Vorhersage aus der vollen Reihe gleich
    der Vorhersage aus der am Stichtag abgeschnittenen Reihe sein (Power Law und 200-Wochen-MA dabei neu gerechnet; MVRV und
    Realized Price abgeschnitten, wie geliefert). Größte Abweichung in ln über alle Sichten und Horizonte.
    """
    maxd = 0.0; ok = True; tage_ = []
    mv = B.get("rp")
    for anteil in stellen:
        o = L.urs[min(len(L.urs) - 1, int(len(L.urs) * anteil))]
        k = o + 1
        Bk = paare_bauen(B["tage"][:k], np.asarray(B["P"], dtype=float)[:k],
                         MVRV=None if mv is None else np.exp(np.asarray(mv[0], dtype=float)[:k]),
                         RP=None if mv is None else np.asarray(mv[1].ref, dtype=float)[:k])
        kurz = type(L)(Bk, w=L.w, b3=L.b3).rechnen()
        Va = L.sichten(o); Vk = kurz.sichten(o)
        tage_.append(int(L.d0 + o))
        if (Va is None) != (Vk is None):
            ok = False
            continue
        if Va is None:
            continue
        for s in SICHTEN:
            for h in HORIZONTE:
                if (h in Va[s]) != (h in Vk[s]):
                    ok = False
                    continue
                if h in Va[s]:
                    d = float(np.max(np.abs(Va[s][h] - Vk[s][h])))
                    maxd = max(maxd, d)
                    ok = ok and d < 1e-9
    return {"ok": bool(ok), "max": maxd, "tage": tage_}


# ================================================================================================ Daten und Ablage

def daten(db: str, jetzt: float | None = None) -> tuple:
    """(Bausteine, Fehlertext): der Datensatz wie in Debug 52 (hl_makro.ableiten) und daraus die drei Paare."""
    pfad = M.makro_pfad(db)
    con = M.lesen(pfad)
    if con is None:
        return None, "makro.db fehlt noch -- der Makro-Takt legt sie wenige Minuten nach dem Start des Dashboards an"
    try:
        D = M.ableiten(con, None if jetzt is None else int(jetzt) // M.TAG)
    except sqlite3.Error as e:
        return None, f"makro.db: {type(e).__name__}: {e}"
    finally:
        con.close()
    if not D or not D.get("ok"):
        return None, (D or {}).get("grund") or "keine Daten"
    if (D.get("PL") or {}).get("fv_kausal") is None:
        return None, "kein Power Law rechenbar (zu wenig Kursdaten)"
    return paare_bauen(D["tage"], D["P"], MVRV=D["MVRV"], RP=D["RP"], WMA=D["WMA"], PL=D["PL"]), None


def vollstaendig(E: dict, jetzt: float) -> list:
    """Gründe, aus denen der Lauf NICHT als erster Lauf zählt (leer = zählt). Vorab festgelegt; es geht nur um halbe Daten."""
    g = []
    d = E["daten"]
    alter = int(jetzt) // M.TAG - d["letzter"]
    if alter > VOLL_MAX_ALTER:
        g.append(f"der letzte Kurstag ist {alter} Tage alt (höchstens {VOLL_MAX_ALTER})")
    if d["luecken"] > VOLL_MAX_LUECKEN:
        g.append(f"{d['luecken']} Tage ohne Kurs (höchstens {VOLL_MAX_LUECKEN})")
    n365 = ((E["tabelle"].get("H") or {}).get("365") or {}).get("n") or 0
    if n365 < VOLL_MIN_365:
        g.append(f"nur {n365} gewertete Stichtage bei 365 Tagen (mindestens {VOLL_MIN_365})")
    if E.get("heute") is None:
        g.append("für heute ist kein Fächer rechenbar")
    return g


def gespeichert(pfad: str) -> dict | None:
    """Das abgelegte Urteil oder None. Liest nur; legt nichts an."""
    con = M.lesen(pfad)
    if con is None:
        return None
    try:
        roh = M.meta(con, SCHLUESSEL)
    finally:
        con.close()
    try:
        E = json.loads(roh) if roh else None
    except (TypeError, ValueError):
        return None
    return E if isinstance(E, dict) and E.get("ok") else None


def speichern(pfad: str, E: dict) -> dict:
    """
    Das Urteil festhalten (Regel 7.5). Steht schon eines derselben Regelversion da, bleibt es stehen und wird zurückgegeben -- so
    entsteht kein zweites Urteil durch wiederholtes Rechnen. Ein Urteil einer älteren Regelversion wird mit Datum abgelegt und
    ersetzt. Eine Transaktion (BEGIN IMMEDIATE); nur vorhandene Datenbanken (eine fehlende wird nicht angelegt).
    """
    if not os.path.exists(pfad):
        raise FileNotFoundError(pfad)
    con = M.verbinden(pfad)
    try:
        con.execute("BEGIN IMMEDIATE")
        try:
            z = con.execute("SELECT v FROM mk_meta WHERE k=?", (SCHLUESSEL,)).fetchone()
            try:
                alt = json.loads(z[0]) if z and z[0] else None
            except (TypeError, ValueError):
                alt = None
            alt = alt if isinstance(alt, dict) and alt.get("ok") else None
            if alt is not None and alt.get("regel") == E.get("regel"):
                con.execute("COMMIT")
                return alt
            if alt is not None:
                za = con.execute("SELECT v FROM mk_meta WHERE k=?", (SCHLUESSEL_ARCHIV,)).fetchone()
                try:
                    ablage = json.loads(za[0]) if za and za[0] else []
                except (TypeError, ValueError):
                    ablage = []
                ablage = ablage if isinstance(ablage, list) else []
                ablage.append({k: alt.get(k) for k in ("regel", "ts", "version", "urteil", "haupt", "bestanden", "alarm_bei", "gruende")})
                con.execute("INSERT INTO mk_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                            (SCHLUESSEL_ARCHIV, json.dumps(ablage[-20:], ensure_ascii=False)))
            con.execute("INSERT INTO mk_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                        (SCHLUESSEL, json.dumps(E, ensure_ascii=False, allow_nan=False)))
            con.execute("COMMIT")
        except BaseException:
            con.execute("ROLLBACK")
            raise
    finally:
        con.close()
    return E


def vorpruefung(db: str, jetzt: float | None = None, ablegen: bool = True, proben: bool = True, neben: bool = True) -> dict:
    """
    Der ganze Lauf: Daten lesen, rückrechnen, Regeln, Nebenrechnung, Gegenproben; beim ersten Lauf mit vollständigen Daten das
    Urteil ablegen. Rückgabe: {"ok", "fehler", "E" (Stand von heute), "fest" (abgelegtes Urteil oder None), "neu", "unvollstaendig",
    "dauer_s", …}. proben=False lässt die Gegenproben weg, neben=False die Nebenrechnung 7.7 (beides nur für schnelle Proben).
    """
    t0 = time.time()
    jetzt = time.time() if jetzt is None else float(jetzt)
    pfad = M.makro_pfad(db)
    B, fehler = daten(db, jetzt)
    if B is None:
        return {"ok": False, "fehler": fehler, "fest": gespeichert(pfad), "dauer_s": time.time() - t0}
    t1 = time.time()
    try:
        L = Lauf(B).rechnen()
    except ValueError as e:
        return {"ok": False, "fehler": str(e), "fest": gespeichert(pfad), "dauer_s": time.time() - t0}
    if not L.erg["H"][365] or not L.erg["H"][730]:
        return {"ok": False, "fehler": "zu wenig Historie: kein gewerteter Stichtag bei 365 oder 730 Tagen",
                "fest": gespeichert(pfad), "dauer_s": time.time() - t0}
    fest = gespeichert(pfad)
    aktuell = fest is not None and fest.get("regel") == REGELVERSION
    E = auswerten(L, fest.get("haupt") if aktuell else None)
    t2 = time.time()
    E["ts"] = int(jetzt)
    E["neben"] = nebenrechnung(B, L) if neben else None
    t3 = time.time()
    out = {"ok": True, "E": E, "lauf": L, "zeiten": {"daten": t1 - t0, "rueckrechnung": t2 - t1, "neben": t3 - t2}}
    if proben:
        out["u126"] = gegenprobe_u126(B, L)
        out["kausal"] = kausal_probe(B, L)
        out["zeiten"]["proben"] = time.time() - t3
    unv = vollstaendig(E, jetzt)
    out["unvollstaendig"] = unv
    neu = False
    if not aktuell and not unv and ablegen:
        ablage = dict(E)
        ablage["dauer_s"] = _r(time.time() - t0, 4)
        try:
            fest2 = speichern(pfad, ablage)
            neu = fest2 is ablage                                            # sonst stand inzwischen schon eines da
            fest = fest2
        except (sqlite3.Error, OSError, TypeError, ValueError) as e:
            out["ablage_fehler"] = f"{type(e).__name__}: {e}"
    out["fest"] = fest; out["neu"] = neu
    out["dauer_s"] = time.time() - t0
    return out


# ================================================================================================ Bericht

def _z(x, d: int = 2) -> str:
    return M._zahl(None if x is None else float(x), d)


def _usd(x) -> str:
    if x is None or not math.isfinite(x):
        return "—"
    return _z(x, 0) if abs(x) >= 1000 else _z(x, 2)


def _pz(x, d: int = 0) -> str:
    return "—" if x is None or not math.isfinite(x) else _z(100 * x, d) + " %"


def _gegen(c, ch) -> str:
    """CRPS gegen den von H: „ (+3,1 %)“ = schlechter, „ (−2,0 %)“ = besser."""
    if c is None or not ch:
        return ""
    d = 100 * (c / ch - 1)
    if abs(d) < 0.05:
        return " (±0,0 %)"
    return f" ({'+' if d > 0 else '−'}{_z(abs(d), 1)} %)"


def _zeile(kopf: str, werte: list, breite: int = 34, spalte: int = 16) -> str:
    return ("  " + kopf.ljust(breite) + "".join(str(v).rjust(spalte) for v in werte)).rstrip()


def _uhr(ts) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(int(ts)))


def _klein(x: float) -> str:
    """Sehr kleine Abweichung lesbar: „0“ oder „1,8e-15“."""
    return "0" if not x else f"{x:.1e}".replace(".", ",")


def _kurz(name: str) -> str:
    return f"{name} {NAMEN[name].split(' (')[0]}"


def _urteil_zeilen(F: dict) -> list:
    """Das Urteil in vier Zeilen (aus einem abgelegten oder eben gerechneten Stand)."""
    z = []
    haupt = F.get("haupt") or "H"
    if haupt == "H":
        z.append("  Hauptfächer        H = ½ „ohne Richtung“ + ½ „Trend“ -- kein Kandidat hat ihn abgelöst (Regel 7.1)")
    else:
        mehr = F.get("bestanden") or []
        z.append(f"  Hauptfächer        {haupt} = {NAMEN[haupt]} -- hat H nach Regel 7.1 abgelöst"
                 + (f" (bestanden haben: {', '.join(mehr)})" if len(mehr) > 1 else ""))
    al = F.get("alarm_bei") or []
    z.append("  Band zu schmal     " + ("nein -- bei keinem Horizont (Regel 7.2)" if not al else
                                        "JA bei " + ", ".join(f"{h} Tagen" for h in al) + " (Regel 7.2)"))
    h_ = F.get("heute") or {}
    if h_.get("verh_730") is not None:
        z.append(f"  Aussagekraft       bei 730 Tagen liegt der 90-%-Rand beim {_z(h_['verh_730'], 1)}-Fachen des 10-%-Rands "
                 f"(Rückfrage ab dem {FAKTOR_74:.0f}-Fachen, Regel 7.4): " + ("RÜCKFRAGE" if h_.get("frage_74") else "keine Rückfrage"))
    if F.get("urteil") == "bauen":
        z.append("  Ergebnis           Nach den vorab festen Regeln kann der Chart gebaut werden.")
    else:
        z.append("  Ergebnis           Vor dem Bau des Charts ist eine Rückfrage nötig: " + "; ".join(F.get("gruende") or ["—"]) + ".")
    return z


def bericht(R: dict, jetzt: float | None = None) -> str:
    """Text für Debug 153."""
    jetzt = time.time() if jetzt is None else float(jetzt)
    z = []
    a = z.append
    a(f"★ Langfrist: Vorprüfung zum 24-Monats-Chart für BTC (U277, Debug {DEBUG_NR}) · Modul {VERSION_MODUL} · "
      f"Regelversion {REGELVERSION} · {_uhr(jetzt)}")
    a("  Regeln: KONZEPT_Langfrist.md, Abschnitte 3 bis 8 -- festgelegt, bevor eine Zahl auf echten Daten gerechnet wurde.")
    a("  Spannen und Messwerte, keine Empfehlung. Die Rückrechnung nutzt die Kurshistorie, aus der auch die Regeln stammen.")
    a("")
    fest = R.get("fest")
    if not R.get("ok"):
        a("KEIN LAUF: " + str(R.get("fehler")))
        a("")
        if fest:
            a(f"URTEIL -- abgelegt am {_uhr(fest.get('ts') or 0)} (Regelversion {fest.get('regel')}, Modul {fest.get('version')})")
            z.extend(_urteil_zeilen(fest))
        else:
            a("Ein Urteil ist noch nicht abgelegt.")
        return "\n".join(z) + "\n"
    E = R["E"]; unv = R.get("unvollstaendig") or []
    # ---- Urteil
    if fest and R.get("neu"):
        a(f"URTEIL -- dieser Lauf ist der erste mit vollständigen Daten: Sein Urteil ist abgelegt ({_uhr(fest['ts'])}) und bleibt (Regel 7.5)")
        z.extend(_urteil_zeilen(fest))
    elif fest and fest.get("regel") == REGELVERSION:
        a(f"URTEIL -- abgelegt vom ersten Lauf am {_uhr(fest.get('ts') or 0)} (Modul {fest.get('version')}); spätere Läufe ändern es nicht (Regel 7.5)")
        z.extend(_urteil_zeilen(fest))
        gleich = (fest.get("haupt") == E.get("haupt_regel") and (fest.get("alarm_bei") or []) == (E.get("alarm_bei") or [])
                  and fest.get("urteil") == E.get("urteil"))
        if gleich:
            a("  Stand von heute    ergäbe dasselbe.")
        else:
            a(f"  Stand von heute    ergäbe etwas anderes: Hauptfächer nach Regel 7.1 {E.get('haupt_regel')}, Alarm bei "
              + (", ".join(f"{h} Tagen" for h in E.get("alarm_bei") or []) or "keinem Horizont")
              + ", Ergebnis „" + ("bauen" if E.get("urteil") == "bauen" else "Rückfrage") + "“ -- das abgelegte Urteil gilt weiter.")
        fd = fest.get("daten") or {}
        if fd.get("letzter") is not None:
            a(f"  Daten damals       bis {tagtext(fd['letzter'])} ({_z(fd.get('tage'), 0)} Tage, Prüfsumme {fd.get('pruef')}); heute bis "
              f"{tagtext(E['daten']['letzter'])} ({_z(E['daten']['tage'], 0)} Tage)")
        a("  Die Abschnitte 1 bis 7 zeigen den Stand dieses Laufs.")
    else:
        a("URTEIL -- NICHT abgelegt: " + ("; ".join(unv) if unv else str(R.get("ablage_fehler") or "Ablage ausgeschaltet")))
        a("  Die Zahlen unten sind vorläufig. Das Urteil fällt der erste Lauf mit vollständigen Daten (Regel 7.5).")
        z.extend(_urteil_zeilen(E))
    if R.get("ablage_fehler"):
        a("  Ablage             FEHLER: " + R["ablage_fehler"])
    a("")
    # ---- 1 Daten und Raster
    d = E["daten"]; r = E["raster"]; T = E["tabelle"]
    hz = [str(h) for h in HORIZONTE]
    a("1 DATEN UND RASTER")
    a(f"  Kurs               cm:btc:PriceUSD (Coin Metrics, Tageswerte) · {tagtext(d['erster'])} bis {tagtext(d['letzter'])} · "
      f"{_z(d['tage'], 0)} Tage · {d['luecken']} ohne Kurs · Prüfsumme {d['pruef']}")
    a(f"  Stichtage          alle {ABSTAND} Tage ab {tagtext(r['start'])} ({r['n']}); gewertet ab "
      f"{tagtext(r['erster_gewertet']) if r.get('erster_gewertet') is not None else '—'} -- frühere füllen nur das Fehlergedächtnis"
      + (f"; {r['ohne_rechnung']} Stichtage ohne Rechnung (kein Kurs oder zu wenig Historie)" if r.get("ohne_rechnung") else ""))
    a(_zeile("Horizont in Tagen", list(HORIZONTE)))
    a(_zeile("gewertete Stichtage", [(T["H"].get(h) or {}).get("n", 0) for h in hz]))
    a(_zeile("Fenster ohne Überlappung", [(T["H"].get(h) or {}).get("n_un", 0) for h in hz]))
    a(_zeile("Ziel ohne Kurs (entfällt)", [r["ohne_ziel"].get(h, 0) for h in hz]))
    a("")
    # ---- 2 Rückblick
    a("2 RÜCKBLICK JE HORIZONT (an jedem Stichtag nur mit Daten, die damals bekannt waren)")
    a("  CRPS in ln -- kleiner ist besser; in Klammern gegen H (+ = schlechter)")
    a(_zeile("Horizont in Tagen", list(HORIZONTE), 34, 18))
    for name in FAECHER + SICHTEN:
        w = []
        for h in hz:
            e = T.get(name, {}).get(h); eh = T["H"].get(h)
            w.append("—" if not e else _z(e["crps"], 3) + ("" if name == "H" or not eh else _gegen(e["crps"], eh["crps"])))
        a(_zeile(_kurz(name), w, 34, 18))
    a("  Deckung des 80-%-Bands (Soll 80 %) · des 50-%-Bands (Soll 50 %)")
    for name in FAECHER + SICHTEN:
        w = []
        for h in hz:
            e = T.get(name, {}).get(h)
            w.append("—" if not e else f"{_pz(e['d80'])} · {_pz(e['d50'])}")
        a(_zeile(_kurz(name), w, 34, 18))
    haupt = E["haupt"]
    th = T[haupt]
    a(f"  Fächer {haupt} im Einzelnen")

    def feld(h, k):
        return (th.get(h) or {}).get(k)
    a(_zeile("über dem 90-%-Rand (Soll 10 %)", [_pz(feld(h, "oben")) for h in hz], 34, 18))
    a(_zeile("unter dem 10-%-Rand (Soll 10 %)", [_pz(feld(h, "unten")) for h in hz], 34, 18))
    a(_zeile("80-%-Band hielt, ohne Überlappung", [f"{feld(h, 't_un') or 0} von {feld(h, 'n_un') or 0}" for h in hz], 34, 18))
    w = []
    for h in hz:
        n_un = feld(h, "n_un") or 0; p = feld(h, "d80")
        w.append("—" if not n_un or p is None else "± " + _z(100 * math.sqrt(max(p * (1 - p), 0.0) / n_un), 0) + " Punkte")
    a(_zeile("Standardfehler der Deckung", w, 34, 18))
    a(_zeile("Fehler der Mitte (RMSE in log10)", [_z(feld(h, "rmse10"), 3) for h in hz], 34, 18))
    a(_zeile("  typisch daneben um den Faktor", [("—" if feld(h, "rmse10") is None else _z(10 ** feld(h, "rmse10"), 2)) for h in hz], 34, 18))
    a(_zeile("mittlere Spanne 10–90 % (Faktor)", [("—" if feld(h, "spanne") is None else _z(math.exp(feld(h, "spanne")), 1)) for h in hz], 34, 18))
    a(_zeile("Gewicht von B in G (Mittel)", [_z(E["gew_g"].get(h), 2) for h in hz], 34, 18))
    a("")
    # ---- 3 Regel 7.1
    a("3 REGEL 7.1 -- LÖST EIN KANDIDAT DEN HAUPTFÄCHER H AB? (alle drei Bedingungen nötig)")
    for k in ("G", "Z", "W"):
        ab = E["abloesung"][k]
        p = ab.get("p")
        a(f"  {k} {NAMEN[k]}")
        if ab["n"] < MIN_FENSTER:
            a(f"     (1) 365 Tage: nur {ab['n']} Fenster mit Unterschied zu H (mindestens {MIN_FENSTER}) -- kein Nachweis")
        elif p is None:
            a(f"     (1) 365 Tage: {ab['n']} Fenster -- für mehr als {MAX_FENSTER} ist der Test nicht gebaut; kein Nachweis")
        else:
            a(f"     (1) 365 Tage: besser in {ab['siege']} von {ab['n']} Fenstern, p = {_z(p, 4) if p >= 0.0001 else '< 0,0001'} "
              f"(verlangt höchstens {_z(ALPHA, 4)}) -- " + ("erfüllt" if ab["test"] else "nicht erfüllt"))
        a(f"     (2) 730 Tage, alle Stichtage: CRPS {_z(ab.get('crps_730'), 3)} gegen {_z(ab.get('h_730'), 3)} von H -- "
          + ("nicht schlechter" if ab["b_730"] else "schlechter"))
        a(f"     (3) letzte vier Jahre, 365 Tage ({ab.get('n_jung') or 0} Stichtage): CRPS {_z(ab.get('jung_k'), 3)} gegen "
          f"{_z(ab.get('jung_h'), 3)} von H -- " + ("nicht schlechter" if ab["c_jung"] else "schlechter"))
        a("     -> " + ("LÖST AB" if ab["abgeloest"] else "löst nicht ab"))
    a("  Nicht bestanden heißt nicht „kein Zusammenhang“: Auf erzeugten Reihen erkannte die Regel einen schrumpfenden Zyklus nur in")
    a("  einer von fünf Welten (KONZEPT_Langfrist.md, Abschnitt 8).")
    a("")
    # ---- 4 Regeln 7.2 und 7.3
    a(f"4 REGELN 7.2 UND 7.3 -- DECKUNG DES 80-%-BANDS VON {haupt} GEGEN DIE GRENZEN")
    al = E["alarm"]

    def alf(h, k):
        return (al.get(h) or {}).get(k)
    a(_zeile("Horizont in Tagen", list(HORIZONTE), 34, 20))
    a(_zeile("Deckung", [_pz(alf(h, "deckung"), 1) for h in hz], 34, 20))
    a(_zeile("Alarm „zu schmal“ unter", [_pz(alf(h, "grenze"), 1) for h in hz], 34, 20))
    a(_zeile("Hinweis „zu breit“ über", [("—" if alf(h, "grenze_oben") is None else _pz(alf(h, "grenze_oben"), 1)
                                         if alf(h, "grenze_oben") <= 1 else "nicht feststellbar") for h in hz], 34, 20))
    a(_zeile("Befund", [("—" if not al.get(h) else "ALARM" if alf(h, "alarm") else "zu breit" if alf(h, "zu_breit") else "im Rahmen")
                        for h in hz], 34, 20))
    if E.get("alarm_bei"):
        a("  Alarm: Der Chart wird nicht ohne Rückfrage gebaut. Zwei Wege: das Band auf die gemessene Breite strecken und so")
        a("  beschriften -- oder den Horizont nicht zeigen.")
    a("")
    # ---- 5 Heute
    h_ = E.get("heute")
    a("5 HEUTE")
    if not h_:
        a("  Für den letzten Kurstag ist kein Fächer rechenbar.")
    else:
        paare = " und ".join({"rp": "Realized Price", "wma": "200-Wochen-MA"}.get(k, k) for k in h_.get("paare") or []) or "keinem Paar"
        a(f"  Stichtag {tagtext(h_['tag'])} (letzter Tageswert von Coin Metrics) · Kurs {_usd(h_['kurs'])} USD · Schwankung für Sicht A {_pz(h_.get('v'))} im Jahr · "
          f"Sicht C aus {h_.get('zyklen')} früheren Zyklen · Sicht D aus {paare}")
        a(f"  Fächer {haupt} in USD (80-%-Band: 10-%- bis 90-%-Rand; 50-%-Band: 25-%- bis 75-%-Rand)")
        a(_zeile("Horizont in Tagen", list(HORIZONTE), 34, 20))
        for i, nm in enumerate(("10-%-Rand", "25-%-Rand", "Mitte", "75-%-Rand", "90-%-Rand")):
            a(_zeile(nm, [_usd(h_["usd"][h][haupt][i]) for h in hz], 34, 20))
        a("  Mitten der Sichten in USD (Vergleichslinien; in Klammern der Rohwert der Regel)")
        for s in SICHTEN:
            w = []
            for h in hz:
                q = h_["usd"][h].get(s)
                roh = (h_["roh"].get(s) or {}).get(h)
                w.append("—" if not q else f"{_usd(q[2])} ({_usd(roh)})")
            a(_zeile(_kurz(s), w, 34, 20))
        a(_zeile("Gewicht von B in G heute", [_z(h_["wb"].get(h), 2) for h in hz], 34, 20))
        a(_zeile("Band von B", [h_["band"].get(h, "—") for h in hz], 34, 20))
    a("")
    # ---- 6 Nebenrechnung
    nb = E.get("neben") or {}
    a("6 NEBENRECHNUNG 7.7 (ohne Folgen) -- Mitte von Sicht B heute, wenn Median und Rückkehr aus einem kürzeren Zeitraum kommen")
    if not nb:
        a("  nicht gerechnet")
    else:
        a(_zeile("Horizont in Tagen", list(HORIZONTE), 34, 20))
    for name in (("alles",) + tuple(n for n, _w in NEBEN)) if nb else ():
        e = nb.get(name)
        if not e or not e.get("mitte"):
            a(_zeile(f"Zeitraum {name}", ["—"] * len(HORIZONTE), 34, 20))
            continue
        a(_zeile(f"Zeitraum {name}, Mitte in USD", [_usd(e["mitte"].get(h)) for h in hz], 34, 20))
        a(_zeile("  Fehler der Mitte (log10) · Fälle", [(f"{_z(e['rmse10'].get(h), 3)} · {e['n'].get(h, 0)}" if h in e["rmse10"] else "—")
                                                      for h in hz], 34, 20))
    a("")
    # ---- 7 Gegenproben
    a("7 GEGENPROBEN AUF DIESEN DATEN")
    u = R.get("u126"); k = R.get("kausal")
    if u is None and k is None:
        a("  nicht gerechnet")
    if u is not None:
        a("  U126 (Debug 52)    Sicht B bei 90, 180 und 365 Tagen gegen die Rechnung von U126 -- Zahl der Fälle "
          + ", ".join(f"{u['n'][str(h)][1]} gegen {u['n'][str(h)][0]}" for h in S.HORIZONTE if str(h) in u["n"])
          + f"; Ränder der Fehler und heutiges Band: größte Abweichung {_klein(u['max'])} in ln -- " + ("GLEICH" if u["gleich"] else "ABWEICHUNG")
          + (f" (ohne Vergleich der Ränder: {', '.join(str(h) for h in u['ohne'])} Tage -- zu wenige bekannte Fehler)" if u.get("ohne") else ""))
        if (u.get("heute") or {}).get("365"):
            lo, hi, wert = u["heute"]["365"]
            a(f"                     Band von U126 für 365 Tage: {_usd(lo)} bis {_usd(hi)} USD, Erwartung {_usd(wert)} -- so steht es auch in "
              "Debug 52 (Paar „Kurs gegen Power-Law-Fair-Value“, Zeitraum „alles“)")
    if k is not None:
        a("  Kein Blick voraus  Vorhersage aus der vollen Reihe gegen die am Stichtag abgeschnittene Reihe, Stichtage "
          + ", ".join(tagtext(t) for t in k["tage"]) + f": größte Abweichung {_klein(k['max'])} in ln -- " + ("GLEICH" if k["ok"] else "ABWEICHUNG"))
    a("")
    # ---- 8 Grenzen
    a("8 WAS DIESER LAUF NICHT ZEIGT")
    a(f"  - Bei 730 Tagen gibt es {(T['H'].get('730') or {}).get('n_un', 0)} Fenster ohne Überlappung. Das reicht, um ein grob falsches Band zu "
      "erkennen -- nicht, um ein richtiges zu belegen.")
    a("  - Die Rückrechnung ist keine unabhängige Prüfung: Power Law und Zyklus-These stammen aus derselben Kurshistorie.")
    a("  - Der Fächer ist eine Spanne von Szenarien, keine geprüfte Prognose und kein Signal.")
    zt = R.get("zeiten") or {}
    a("")
    a(f"Laufzeit {_z(R.get('dauer_s', 0), 1)} s (Daten {_z(zt.get('daten', 0), 1)} · Rückrechnung {_z(zt.get('rueckrechnung', 0), 1)} · "
      f"Nebenrechnung {_z(zt.get('neben', 0), 1)} · Gegenproben {_z(zt.get('proben', 0), 1)})")
    return "\n".join(z) + "\n"


# ================================================================================================ erzeugte Reihen (nur Selbsttest)

D0_WELT = M.tag_ts("2010-07-18") // M.TAG


def welt(seed: int, n: int = 5970, zyklus: float = 0.0, art: str = "trend") -> tuple:
    """
    Erzeugte Tagesreihe ab 18.07.2010 -- KEINE echten Kurse. art „trend“: Power Law plus AR(1)-Abweichung (Halbwertszeit 317 Tage,
    Streuung 0,301 in log10); zyklus = Stärke eines festen Vier-Jahres-Musters in Einheiten dieser Streuung (Hoch rund 525 Tage
    nach dem Halving). art „zufall“: reiner Zufallsweg ohne Trend (4 % je Tag). Dazu ein Realized Price (geglätteter Kurs,
    Halbwertszeit 500 Tage, 180 Tage Anlauf) und der 200-Wochen-MA -- beide ohne eigene Information.
    Rückgabe: (Tage, Kurs, Realized Price, 200-Wochen-MA).
    """
    rng = np.random.default_rng(seed)
    tage = np.arange(D0_WELT, D0_WELT + n, dtype=np.int64)
    sd = 0.301 * math.log(10)
    if art == "zufall":
        lnp = math.log(0.07) + np.cumsum(rng.standard_normal(n) * 0.04)
    else:
        phi = 0.5 ** (1 / 317.0)
        eps = rng.standard_normal(n) * sd * math.sqrt(1 - phi * phi)
        d = np.empty(n); d[0] = rng.standard_normal() * sd
        for i in range(1, n):
            d[i] = phi * d[i - 1] + eps[i]
        lnp = math.log(10) * (-16.324 + 5.633 * np.log10(tage - M.GENESIS_TAG)) + d
        if zyklus:
            halv = np.array(M.halving_tage())
            k = np.searchsorted(halv, tage, "right") - 1
            basis = np.where(k >= 0, halv[np.maximum(k, 0)], halv[0] - 1400)
            tau = (tage - basis) % 1400
            lnp = lnp + zyklus * sd * np.sin(2 * math.pi * (tau - 175) / 1400)
    P = np.exp(lnp)
    a = 1 - 0.5 ** (1 / 500.0)
    rp = np.empty(n); rp[0] = P[0]
    for i in range(1, n):
        rp[i] = rp[i - 1] + a * (P[i] - rp[i - 1])
    rp[:180] = np.nan
    return tage, P, rp, M.wma200(tage, P)


def welt_bausteine(seed: int, **kw) -> dict:
    tage, P, rp, wma = welt(seed, **kw)
    with np.errstate(invalid="ignore", divide="ignore"):
        return paare_bauen(tage, P, MVRV=P / rp, RP=rp, WMA=wma)


# ================================================================================================ Selbsttest (ohne Netz, ohne echte Daten)

def _faelle(os_: list, crps, gleich=False, in80=True) -> list:
    """Gebaute Fälle für die Proben der Regeln: je Stichtag CRPS, Gleichstand mit H, Treffer des 80-%-Bands."""
    def je(x, i):
        return x[i] if isinstance(x, (list, tuple, np.ndarray)) else x
    return [Fall(int(o), float(je(crps, i)), bool(je(in80, i)), True, False, False, 0.0, bool(je(gleich, i)), 1.0, (0.0,) * 5)
            for i, o in enumerate(os_)]


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    import hl_ausblick as AU
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_langfrist -- Selbsttest (Vorprüfung zum 24-Monats-Chart; ohne Netz, nur erzeugte Reihen -- keine echten Kurse)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_langfrist_test_")
    alt_env = os.environ.get("HL_MAKRO_DB")
    G = globals()
    try:
        B = welt_bausteine(7)
        voll = Lauf(B).rechnen()
        T = voll.tabelle()
        # ---- P1 Kausalität
        k1 = kausal_probe(B, voll)

        class _Zukunft(Lauf):                                               # Gegenprobe: Median und AR(1) sehen 30 Tage voraus
            def _fenster(self, y, o, w):
                return y[: o + 31]
        k1a = kausal_probe(B, _Zukunft(B).rechnen())
        alt_bekannt = G["_bekannt"]
        try:                                                                # Gegenprobe: Fehlergedächtnis mit noch unbekannten Zielen
            G["_bekannt"] = lambda mem, o, h: [e for (o2, _z2, e) in mem if o2 >= o - h - FEHLER_TAGE]
            k1b = kausal_probe(B, Lauf(B).rechnen())
        finally:
            G["_bekannt"] = alt_bekannt
        ok("P1 Kein Blick voraus: An drei Stichtagen ist die Vorhersage aller Sichten aus der vollen Reihe gleich der aus der am "
           "Stichtag abgeschnittenen Reihe (Power Law und 200-Wochen-MA neu gerechnet). Gegenproben: Sieht der Median 30 Tage voraus "
           "oder enthält das Fehlergedächtnis noch unbekannte Ziele, fällt es auf",
           k1["ok"] and k1["max"] < 1e-9 and len(k1["tage"]) == 3 and not k1a["ok"] and k1a["max"] > 1e-3 and not k1b["ok"] and k1b["max"] > 1e-3,
           f"Abweichung {k1['max']:.1e}; mit Blick voraus {k1a['max']:.3f}; mit unbekannten Zielen {k1b['max']:.3f}")
        # ---- P2 Gleichheit mit U126
        u = gegenprobe_u126(B, voll)
        Lw = Lauf(B, w=1461).rechnen()
        uw = gegenprobe_u126(B, Lw)
        alt_abst = G["ABSTAND"]
        try:                                                                # Gegenprobe: Raster 31 statt 30 Tage
            G["ABSTAND"] = 31
            u31 = gegenprobe_u126(B, Lauf(B).rechnen())
        finally:
            G["ABSTAND"] = alt_abst
        ok("P2 Gleich mit U126: Bei 90, 180 und 365 Tagen hat Sicht B so viele Fälle wie hl_makro_signal.pruefung, dieselben Ränder der "
           "bekannten Fehler und (ohne Regel B3) dasselbe heutige Band wie prognose -- für den Zeitraum „alles“ und für 4 Jahre. "
           "Gegenprobe: Ein Raster von 31 Tagen fällt auf",
           u["gleich"] and u["max"] < 1e-9 and u["n"] == {"90": (179, 179), "180": (176, 176), "365": (170, 170)} and not u["ohne"]
           and len(u["heute"]) == 3 and uw["gleich"] and uw["max"] < 1e-9 and uw["n"]["365"][0] == uw["n"]["365"][1] != 170
           and not u31["gleich"] and voll.start == Lw.start - 1461 + 365 and len(voll.urs) == 179,
           f"alles: {u['n']}, Abweichung {u['max']:.1e}; 4 J: {uw['n']['365']}; 31 Tage: {u31['n']['365']}")
        # ---- P3 CRPS
        x = 0.3 + 1.7 * ZN; w1 = np.full(199, 1 / 199)
        gl = [abs(crps_gew(x, w1, y_) - float(AU.crps_ens(x, y_))) for y_ in (-2.0, 0.3, 4.0)]
        nv = [abs(crps_gew(x, w1, y_) / float(AU.crps_normal(0.3, 1.7, y_)) - 1) for y_ in (-2.0, 0.3, 4.0)]
        rng = np.random.default_rng(3); xx = rng.standard_normal(500); ww = rng.random(500); ww /= ww.sum()
        doppel = float(np.sum(ww * np.abs(xx - 0.4)) - 0.5 * np.sum(ww[:, None] * ww[None, :] * np.abs(xx[:, None] - xx[None, :])))
        ok("P3 CRPS: gleiche Gewichte wie hl_ausblick.crps_ens; ungleiche Gewichte wie die Doppelsumme E|X−y| − ½·E|X−X'|; 199 Quantile "
           "einer Normalverteilung höchstens 1 % neben der geschlossenen Formel; nicht normierte Gewichte ändern nichts; ein Punkt hat "
           "CRPS = Abstand",
           max(gl) < 1e-12 and abs(crps_gew(xx, ww, 0.4) - doppel) < 1e-12 and max(nv) < 0.01
           and abs(crps_gew(xx, ww * 7.0, 0.4) - doppel) < 1e-12 and abs(crps_gew(np.array([2.0]), np.array([1.0]), 0.5) - 1.5) < 1e-12
           and crps_gew(xx, ww, 0.4) > 0,
           f"gegen crps_ens {max(gl):.1e}; gegen die Formel bis {100 * max(nv):.2f} %")
        # ---- P4 Mischung
        o4 = voll.urs[120]
        V4 = voll.sichten(o4)
        V4c = dict(V4); V4c["C"] = dict(V4["B"])
        qd = []; cd = []
        for h in HORIZONTE:
            F = voll.faecher(V4c, o4, h)
            qd.append(float(np.max(np.abs(gew_quantile(*F["Z"], Q5) - gew_quantile(*F["H"], Q5)))))
            cd.append(abs(crps_gew(*F["Z"], 1.0) - crps_gew(*F["H"], 1.0)))
        F4 = voll.faecher(V4, o4, 365)
        ab1 = (np.concatenate([V4["A"][365], V4["B"][365]]), np.concatenate([w1, w1 * 0.0]))
        eins = float(np.max(np.abs(gew_quantile(ab1[0], ab1[1], Q5) - gew_quantile(V4["A"][365], w1, Q5))))
        eins_c = abs(crps_gew(ab1[0], ab1[1], 1.0) - crps_gew(V4["A"][365], w1, 1.0))
        steigt = all(all(a_ <= b_ for a_, b_ in zip(q_[:-1], q_[1:])) for o_ in (voll.urs[60], o4, voll.urs[170])
                     for h_, je in voll.fan(o_)["h"].items() for n_, q_ in je.items() if n_ != "wb")
        gw = {n_: float(F4[n_][1].sum()) for n_ in ("A", "B", "H", "G", "Z", "W")}
        ok("P4 Mischung: Ist C gleich B, ist Z gleich H (CRPS genau, Quantile auf 0,005 in ln); Gewicht 1 ergibt die Einzelsicht (ebenso); "
           "die Quantile jedes Fächers steigen; die Gewichte jedes Fächers summieren zu 1; in Z und W hat A die Hälfte, B und C bzw. D je "
           "ein Viertel",
           max(cd) < 1e-11 and max(qd) < 0.005 and eins < 0.005 and eins_c < 1e-11 and steigt
           and all(abs(v_ - 1) < 1e-12 for v_ in gw.values()) and abs(float(F4["Z"][1][:199].sum()) - 0.5) < 1e-12
           and abs(float(F4["W"][1][:199].sum()) - 0.5) < 1e-12 and abs(float(F4["Z"][1][199:398].sum()) - 0.25) < 1e-12
           and abs(float(F4["H"][1][:199].sum()) - 0.5) < 1e-12 and abs(float(F4["W"][1][398:].sum()) - 0.25) < 1e-12
           and np.array_equal(F4["Z"][0][398:], V4["C"][365]) and np.array_equal(F4["W"][0][398:], V4["D"][365])
           and np.array_equal(F4["Z"][0][:199], V4["A"][365]) and np.array_equal(F4["H"][0][199:], V4["B"][365]),
           f"Quantile bis {max(qd):.4f} ln, CRPS bis {max(cd):.1e}; Gewicht 1: {eins:.4f} ln")
        # ---- P5 Vorzeichenwechsel-Test und die drei Bedingungen der Ablösung (gebaute Fälle)
        os_ = list(range(0, 3511, 30))                                      # 118 Stichtage; 10 davon liegen auf dem Raster von 390 Tagen
        ras = [i for i, o_ in enumerate(os_) if o_ % 390 == 0]

        def kunst(z365, z730=0.9, h365=1.0, gleich=False, g365=None):
            Lk = Lauf(B)
            Lk.erg["H"][365] = _faelle(os_, h365); Lk.erg["H"][730] = _faelle(os_, 1.0)
            Lk.erg["Z"][365] = _faelle(os_, z365, gleich); Lk.erg["Z"][730] = _faelle(os_, z730)
            for k_ in ("G", "W"):
                Lk.erg[k_][365] = _faelle(os_, 1.0 if g365 is None or k_ == "W" else g365, g365 is None or k_ == "W")
                Lk.erg[k_][730] = _faelle(os_, 1.0 if g365 is None or k_ == "W" else 0.9)
            return Lk
        a_gut = kunst(0.9).abloesung("Z")
        z_klein = [0.9] * len(os_); z_klein[ras[3]] = 1.01                 # ein kleiner Gegenwert
        z_gross = [0.9] * len(os_); z_gross[ras[3]] = 3.0                  # ein großer
        a_klein = kunst(z_klein).abloesung("Z"); a_gross = kunst(z_gross).abloesung("Z")
        gl5 = [i in ras[:5] for i in range(len(os_))]                      # fünf Fenster stimmen mit H überein -> es bleiben fünf
        z_gl = [1.0 if g_ else 0.9 for g_ in gl5]
        a_gleich = kunst(z_gl, gleich=gl5).abloesung("Z")
        gl1 = [i in ras[:1] for i in range(len(os_))]
        a_gl1 = kunst([1.0 if g_ else 0.9 for g_ in gl1], gleich=gl1).abloesung("Z")
        a_730 = kunst(0.9, z730=1.1).abloesung("Z")
        z_jung = [0.9 if (i in ras or o_ < os_[-1] - FEHLER_TAGE) else 1.15 for i, o_ in enumerate(os_)]
        a_jung = kunst(z_jung).abloesung("Z")
        gl4 = [i in ras[:4] for i in range(len(os_))]                      # sechs Fenster bleiben
        z_s6 = [1.0 if g_ else 0.9 for g_ in gl4]
        a_s6 = kunst(z_s6, gleich=gl4).abloesung("Z")                      # sechs Siege: 1 ÷ 64 = 0,0156 -- reicht
        z_s5 = list(z_s6); z_s5[ras[6]] = 1.01
        a_s5 = kunst(z_s5, gleich=gl4).abloesung("Z")                      # ein kleiner Gegenwert: 2 ÷ 64 = 0,031 -- reicht nicht
        L_zwei = kunst(0.9, g365=0.8)
        ok("P5 Vorzeichenwechsel-Test: neun gleiche Vorzeichen ergeben 1 ÷ 512, ein kleiner Gegenwert 2 ÷ 512, ein großer keinen "
           "Nachweis; unter sechs Werten kein Nachweis, über 20 ist der Test nicht gebaut; einseitig (lauter Verluste: p = 1)",
           flip_p([1.0] * 9) == 1 / 512 and flip_p([1.0] * 8 + [-0.1]) == 2 / 512 and flip_p([1.0] * 8 + [-20.0]) > 0.4
           and flip_p([1.0] * 5) == 1.0 and math.isnan(flip_p([1.0] * 21)) and flip_p([-1.0] * 9) == 1.0
           and flip_p([0.3, 0.1, 0.2, 0.25, 0.15, 0.05]) == 1 / 64 and abs(flip_p(list(np.linspace(0.5, 1.5, 20))) - 2 ** -20) < 1e-15,
           f"{flip_p([1.0] * 9):.6f} · {flip_p([1.0] * 8 + [-0.1]):.6f} · {flip_p([1.0] * 8 + [-20.0]):.3f}")
        ok("P5b Regel 7.1 an gebauten Fällen: Es zählen nur die Fenster des Rasters ohne Überlappung (10 von 118 Stichtagen); Fenster, in "
           "denen der Kandidat mit H übereinstimmt, zählen nicht (fünf von zehn gleich: fünf bleiben, kein Nachweis); jede der drei "
           "Bedingungen allein verhindert die Ablösung (Test, 730 Tage, letzte vier Jahre -- dort schlechter, obwohl über alle Stichtage "
           "besser); die Schwelle ist 0,0167 (sechs Siege aus sechs: 0,0156 reicht; mit einem kleinen Gegenwert: 0,031 reicht nicht); "
           "bestehen zwei Kandidaten, gilt der mit dem kleineren CRPS bei 365 Tagen",
           len(ras) == 10 and a_gut["n"] == 10 and a_gut["siege"] == 10 and a_gut["p"] == 2 ** -10 and a_gut["abgeloest"]
           and a_klein["p"] == 2 / 1024 and a_klein["siege"] == 9 and a_klein["abgeloest"]
           and a_gross["p"] > ALPHA and not a_gross["test"] and not a_gross["abgeloest"] and a_gross["b_730"] and a_gross["c_jung"]
           and a_gleich["n"] == 5 and a_gleich["p"] == 1.0 and not a_gleich["abgeloest"] and a_gl1["n"] == 9 and a_gl1["p"] == 2 ** -9
           and a_730["test"] and a_730["c_jung"] and not a_730["b_730"] and not a_730["abgeloest"]
           and a_jung["test"] and a_jung["b_730"] and not a_jung["c_jung"] and not a_jung["abgeloest"] and a_jung["n_jung"] == 49
           and a_jung["crps_365"] < 1.0 < a_jung["jung_k"] and a_jung["jung_h"] == 1.0
           and a_s6["n"] == 6 and a_s6["p"] == 1 / 64 and a_s6["test"] and a_s6["abgeloest"]
           and a_s5["n"] == 6 and a_s5["p"] == 2 / 64 and not a_s5["test"] and not a_s5["abgeloest"] and a_s5["b_730"] and a_s5["c_jung"]
           and kunst(0.9).hauptfaecher() == ("Z", ["Z"]) and kunst(1.0, gleich=True).hauptfaecher() == ("H", [])
           and L_zwei.hauptfaecher() == ("G", ["G", "Z"]) and kunst(0.7, g365=0.8).hauptfaecher() == ("Z", ["G", "Z"]),
           f"gut p {a_gut['p']:.5f}; fünf gleich: n {a_gleich['n']}; letzte vier Jahre schlechter: {a_jung['jung_k']:.3f} gegen {a_jung['jung_h']:.3f}")
        # ---- P6 Regel B3
        q_a = 1.0 + 0.50 * ZN; q_b = 2.0 + 0.30 * ZN; q_c = 3.0 + 0.80 * ZN; q_d = 4.0 + 0.10 * ZN
        gestr = _b3({90: q_a, 180: q_b, 365: q_c, 548: q_d})
        sp = lambda q_: float(q_[I90] - q_[I10])
        o6 = voll.urs[150]
        L6 = Lauf(B); L6.roh = {s_: {h_: list(v_) for h_, v_ in je.items()} for s_, je in voll.roh.items()}; L6.mit = voll.mit
        L6.roh["B"][548] = [(o2, z2, 0.001 * e_) for (o2, z2, e_) in voll.roh["B"][548]]      # gebaut: fast keine Streuung bei 548 Tagen
        mit6 = L6.sichten(o6); ohne6 = L6.sichten(o6, b3=False)
        ok("P6 Regel B3: Die Spanne 10–90 % fällt nicht mit dem Horizont -- eine kleinere wird um die Mitte gestreckt, bis sie gleich ist "
           "(Mitte und Reihenfolge bleiben; eine größere bleibt, wie sie ist). In der Rechnung: gebaute Fehler mit fast keiner Streuung bei "
           "548 Tagen ergeben mit B3 die Spanne von 365 Tagen, ohne B3 eine viel kleinere",
           abs(sp(gestr[180]) - sp(q_a)) < 1e-12 and gestr[180][I50] == q_b[I50] and bool(np.all(np.diff(gestr[180]) > 0))
           and np.array_equal(gestr[90], q_a) and np.array_equal(gestr[365], q_c) and abs(sp(gestr[548]) - sp(q_c)) < 1e-12
           and abs(gestr[548][I50] - 4.0) < 1e-12 and set(gestr) == {90, 180, 365, 548}
           and sp(ohne6["B"][548]) < 0.05 * sp(ohne6["B"][365]) and abs(sp(mit6["B"][548]) - sp(mit6["B"][365])) < 1e-9
           and abs(mit6["B"][548][I50] - ohne6["B"][548][I50]) < 1e-12 and sp(mit6["B"][730]) >= sp(mit6["B"][548]) - 1e-12,
           f"gebaut: {sp(ohne6['B'][548]):.4f} -> {sp(mit6['B'][548]):.4f} (365 Tage: {sp(mit6['B'][365]):.4f})")
        # ---- P7 Deckung
        rng7 = np.random.default_rng(11)
        zieh = rng7.standard_normal(4000)
        W7 = [werten(ZN, w1, float(y_)) for y_ in zieh]
        d80 = float(np.mean([w_[1] for w_ in W7])); d50 = float(np.mean([w_[2] for w_ in W7]))
        ob7 = float(np.mean([w_[3] for w_ in W7])); un7 = float(np.mean([w_[4] for w_ in W7]))
        e1 = werten(ZN, w1, float((ZN[I10] + ZN[I25]) / 2)); e2 = werten(ZN, w1, float(ZN[I90] + 0.5)); e3 = werten(ZN, w1, 0.0)
        ok("P7 Deckung: Ziehungen aus der Verteilung des Fächers liegen zu 80 % im 80-%-Band (Ränder 10 und 90 %) und zu 50 % im "
           "50-%-Band (25 und 75 %), je 10 % darüber und darunter; ein Wert zwischen 10-%- und 25-%-Rand zählt im 80-%-, nicht im "
           "50-%-Band; der Fehler der Mitte ist Wert − Median; die Spanne ist 90-%- minus 10-%-Rand. Bekannt und Teil der Regelversion 1: "
           "Die Ränder der Vereinigung aus 199 Quantilen liegen bei 10,2 und 89,8 % (Mittelpunktregel von gew_quantile) -- das 80-%-Band "
           "deckt bei genau bekannter Verteilung 79,6 %",
           abs(d80 - 0.80) < 0.02 and abs(d50 - 0.50) < 0.025 and abs(ob7 - 0.10) < 0.015 and abs(un7 - 0.10) < 0.015
           and e1[1] and not e1[2] and not e1[3] and not e1[4] and not e2[1] and e2[3] and not e2[4]
           and abs(e2[5] - (ZN[I90] + 0.5)) < 1e-9 and abs(e3[6] - (e3[7][4] - e3[7][0])) < 1e-12 and e3[1] and e3[2] and len(e3[7]) == 5
           and abs(e3[7][0] - statistics.NormalDist().inv_cdf(0.102)) < 2e-3 and abs(e3[7][4] - statistics.NormalDist().inv_cdf(0.898)) < 2e-3
           and abs(e3[7][2]) < 1e-12 and abs(e3[7][1] - statistics.NormalDist().inv_cdf(0.25125)) < 2e-3,
           f"80-%-Band {100 * d80:.1f} %, 50-%-Band {100 * d50:.1f} %, darüber {100 * ob7:.1f} %, darunter {100 * un7:.1f} %")
        # ---- P7b Alarm 7.2 und Hinweis 7.3 an gebauten Fällen
        os7 = list(range(0, 131 * 30 + 1, 30))                             # 132 Stichtage, 6 Fenster ohne Überlappung bei 730 Tagen
        La = Lauf(B); La.erg["H"][730] = _faelle(os7, 1.0, in80=[i < 62 for i in range(132)])
        Lb = Lauf(B); Lb.erg["H"][730] = _faelle(os7, 1.0, in80=[i < 63 for i in range(132)])
        os9 = list(range(0, 153 * 30 + 1, 30))                             # 154 Stichtage, 52 Fenster bei 90 Tagen
        Lc = Lauf(B); Lc.erg["H"][90] = _faelle(os9, 1.0, in80=[i < 141 for i in range(154)])
        Ld = Lauf(B); Ld.erg["H"][90] = _faelle(os9, 1.0, in80=[i < 140 for i in range(154)])
        al_a, al_b, al_c, al_d = La.alarm("H")[730], Lb.alarm("H")[730], Lc.alarm("H")[90], Ld.alarm("H")[90]
        ok("P7b Regeln 7.2 und 7.3: Die Grenze ist 0,80 ∓ 2·√(0,16 ÷ n) mit n = Fenster ohne Überlappung (730 Tage, 6 Fenster: 47,3 %; "
           "90 Tage, 52 Fenster: 68,9 % und 91,1 %); die Deckung zählt über alle gewerteten Stichtage; knapp darunter ist Alarm, knapp "
           "darüber keiner; „zu breit“ entsprechend",
           al_a["n_un"] == 6 and abs(al_a["grenze"] - 0.47340) < 1e-4 and al_a["alarm"] and not al_b["alarm"]
           and abs(al_a["deckung"] - 62 / 132) < 1e-12 and al_c["n_un"] == 52 and abs(al_c["grenze"] - 0.68906) < 1e-4
           and abs(al_c["grenze_oben"] - 0.91094) < 1e-4 and al_c["zu_breit"] and not al_d["zu_breit"] and not al_c["alarm"]
           and al_a["grenze_oben"] > 1 and not al_a["zu_breit"],
           f"730 Tage: {100 * al_a['deckung']:.1f} % gegen {100 * al_a['grenze']:.1f} %; 90 Tage: {100 * al_c['deckung']:.1f} % gegen {100 * al_c['grenze_oben']:.1f} %")
        # ---- P8 Gewichte von G und kleine Welten
        o8 = voll.urs[150]; V8 = voll.sichten(o8)

        def g_gewicht(fa, fb, n_=25):
            Lg = Lauf(B)
            Lg.mit["A"][365] = [(o8 - 365 - 30 * i, o8 - 30 * i, fa) for i in range(n_)]
            Lg.mit["B"][365] = [(o8 - 365 - 30 * i, o8 - 30 * i, fb) for i in range(n_)]
            F_ = Lg.faecher(V8, o8, 365)
            return F_["wb"], float(F_["G"][1][199:].sum()), float(F_["G"][1][:199].sum())
        g1 = g_gewicht(1.0, 0.5); g2 = g_gewicht(0.5, 1.0); g3 = g_gewicht(1.0, 0.1); g4 = g_gewicht(0.1, 1.0)
        g5 = g_gewicht(1.0, 0.5, 19); g6 = g_gewicht(0.7, 0.7)
        ok("P8 Gewichte von G: Gewicht von B = MSE(A) ÷ [MSE(A) + MSE(B)] -- irrt A doppelt so weit wie B, bekommt B 0,75 (0,8, begrenzt), "
           "umgekehrt 0,25; begrenzt auf ¼ bis ¾; unter 20 bekannten Fehlern und bei Gleichstand ½; der Anteil liegt wirklich auf den "
           "Werten von B",
           abs(g1[0] - 0.75) < 1e-12 and abs(g2[0] - 0.25) < 1e-12 and g3[0] == 0.75 and g4[0] == 0.25 and g5[0] == 0.5 and g6[0] == 0.5
           and abs(g1[1] - 0.75) < 1e-12 and abs(g1[2] - 0.25) < 1e-12 and abs(g2[1] - 0.25) < 1e-12
           and abs(g_gewicht(1.0, 0.8)[0] - 1.0 / 1.64) < 1e-12,
           f"B genauer: {g1[0]:.2f}; A genauer: {g2[0]:.2f}; 19 Fehler: {g5[0]:.2f}")
        ruhig = [Lauf(welt_bausteine(s_)).rechnen() for s_ in range(1000, 1005)]
        zyk = [Lauf(welt_bausteine(s_, zyklus=3.0)).rechnen() for s_ in range(2000, 2005)]
        h_ruhig = [L_.hauptfaecher()[0] for L_ in ruhig]; h_zyk = [L_.hauptfaecher()[0] for L_ in zyk]
        al_zyk = [any(a_["alarm"] for a_ in L_.alarm(L_.hauptfaecher()[0]).values()) for L_ in zyk]
        ok("P8b Erzeugte Welten (KONZEPT_Langfrist.md 8, je fünf): Ohne Zusammenhang (Power Law plus Rauschen) löst kein Kandidat den "
           "Hauptfächer ab und es gibt keinen Alarm; ein eingebauter Zyklus von 3 σ wird in allen fünf erkannt (Z löst ab), auf dem neuen "
           "Hauptfächer ohne Alarm",
           h_ruhig == ["H"] * 5 and h_zyk == ["Z"] * 5 and not any(al_zyk)
           and not any(a_["alarm"] for L_ in ruhig for a_ in L_.alarm("H").values())
           and all(L_.abloesung("Z")["n"] == 9 and L_.abloesung("W")["n"] == 12 and L_.abloesung("G")["n"] == 11 for L_ in ruhig),
           f"ohne Zusammenhang: {h_ruhig}; Zyklus 3 σ: {h_zyk}; p für Z dort: {[round(L_.abloesung('Z')['p'], 4) for L_ in zyk]}")
        # ---- P9 Gleiche Rechnung für Chart und Rückrechnung
        maxd9 = 0.0; n9 = 0
        for o_ in (voll.urs[70], voll.urs[110], voll.urs[160]):
            f_ = voll.fan(o_)
            for h_ in HORIZONTE:
                for n_ in SICHTEN + FAECHER:
                    rec = [r_ for r_ in voll.erg[n_][h_] if r_.o == o_]
                    if rec and n_ in f_["h"][h_]:
                        maxd9 = max(maxd9, max(abs(a_ - b_) for a_, b_ in zip(rec[0].q, f_["h"][h_][n_]))); n9 += 1
        o9 = voll.urs[130]
        Bk = paare_bauen(B["tage"][: o9 + 1], B["P"][: o9 + 1], MVRV=np.exp(B["rp"][0][: o9 + 1]), RP=B["rp"][1].ref[: o9 + 1])
        kurz9 = Lauf(Bk).rechnen()
        f_heute = kurz9.fan(kurz9.T)
        d9 = max(abs(a_ - b_) for h_ in HORIZONTE for n_ in FAECHER
                 for r_ in voll.erg[n_][h_] if r_.o == o9 for a_, b_ in zip(r_.q, f_heute["h"][h_][n_]))
        frueh = voll.urs[40]; f_frueh = voll.fan(frueh)
        ok("P9 Gleiche Rechnung: Die Funktion für den Chart liefert an Stichtagen der Rückrechnung genau die dort gewerteten Ränder (alle "
           "Fächer und Sichten); der Fächer von „heute“ einer Reihe, die an einem Stichtag endet, ist der, den die längere Reihe später "
           "für diesen Tag wertet; vor dem zweiten Halving gibt es Sicht C nicht -- Z ist dort gleich H",
           maxd9 < 1e-12 and n9 >= 100 and kurz9.T == o9 and d9 < 1e-9 and "C" not in f_frueh["h"][365]
           and [r_.q for r_ in voll.erg["Z"][365] if r_.o == frueh] == [r_.q for r_ in voll.erg["H"][365] if r_.o == frueh] != []
           and [r_.crps for r_ in voll.erg["Z"][730] if r_.o == frueh] == [r_.crps for r_ in voll.erg["H"][730] if r_.o == frueh] != []
           and not [r_ for r_ in voll.erg["C"][365] if r_.o == frueh]
           and f_frueh["h"][365]["Z"] == f_frueh["h"][365]["H"] and voll.d0 + frueh < M.tag_ts("2016-07-09") // M.TAG
           and all(r_.gleich for r_ in voll.erg["Z"][365] if voll.d0 + r_.o < M.tag_ts("2016-07-09") // M.TAG)
           and not any(r_.gleich for r_ in voll.erg["Z"][365] if voll.d0 + r_.o >= M.tag_ts("2016-07-09") // M.TAG),
           f"{n9} Vergleiche, Abweichung {maxd9:.1e}; „heute“ gegen später gewertet {d9:.1e}")
        # ---- P10 Raster, Zählung, Sichten im Einzelnen
        e_ab = voll.d0 + T["H"][90]["erster"]
        v_hand = float(np.std(np.diff(voll.lnP[o4 - 1461: o4 + 1]), ddof=1)) * math.sqrt(365)
        Bl = dict(B); Pl = np.array(B["P"], dtype=float); Pl[o4 - 100] = np.nan; Bl["P"] = Pl
        Ll = Lauf(Bl)
        v_l = Ll._vol(o4)
        r_hand = np.diff(np.log(B["P"][o4 - 1461: o4 + 1])); r_hand = np.delete(r_hand, [1461 - 100 - 1, 1461 - 100])
        tau4 = o4 - [x_ for x_ in voll.halv if x_ <= o4][-1]
        frueher = [x_ for x_ in voll.halv if x_ <= o4][:-1]
        c_hand = voll.lnP[o4] + (voll._lnfv(o4, o4 + 365) - voll._lnfv(o4, o4)) + float(np.mean(
            [(voll.lnP[x_ + tau4 + 365] - voll.lnP[x_ + tau4]) - (voll._lnfv(o4, x_ + tau4 + 365) - voll._lnfv(o4, x_ + tau4)) for x_ in frueher]))
        o_e = voll.urs[5]; V_e = voll.sichten(o_e)                       # früh: noch keine 20 bekannten Fehler
        n_e = {h_: len(_bekannt(voll.roh["B"][h_], o_e, h_)) for h_ in HORIZONTE}
        m_e, sd_e = S.y_prognose(float(voll.y[o_e]), V_e["mu"], V_e["phi"], S.ar1(voll.y[: o_e + 1] - V_e["mu"])["sigma"], 365)
        halv2 = M.tag_ts("2016-07-09") // M.TAG - voll.d0
        o_c = next(o_ for o_ in voll.urs if o_ >= halv2)                   # erster Stichtag mit Sicht C: noch keine eigenen Fehler
        V_c = voll.sichten(o_c, b3=False)
        n_c = len(_bekannt(voll.roh["C"][365], o_c, 365))
        d_hand = []
        for _key, yp_, rx_ in voll.paare:
            mu_, phi_, sig_ = voll._ar(yp_, o4, 0)
            d_hand.append(math.log(rx_.prognose(o4, 365)) + S.y_prognose(float(yp_[o4]), mu_, phi_, sig_, 365)[0])
        ok("P10 Raster und Sichten: erster Stichtag 365 Tage nach dem ersten Fair Value (01.01.2012), dann alle 30 Tage; gewertet ab "
           "20.01.2014; 154 / 151 / 145 / 138 / 132 gewertete Stichtage und 52 / 26 / 12 / 8 / 6 Fenster ohne Überlappung wie im Konzept; "
           "Sicht A: Mitte = Kurs, Breite = Schwankung der letzten 1.461 Tage mal Wurzel der Zeit (ein fehlender Kurstag kostet zwei "
           "Renditen, sonst nichts); Sicht C von Hand nachgerechnet. Sicht B hat unter 20 bekannten Fehlern das Modellband (normal, aus "
           "dem AR(1)), sonst das Band aus den eigenen Fehlern; Sicht C hat ohne eigene Fehler die Streuung von B um ihren Rohwert; "
           "Sicht D ist das Mittel der ln-Prognosen beider Paare (früh, vor dem 200-Wochen-MA, nur des Realized Price)",
           tagtext(voll.d0 + voll.start) == "01.01.2012" and tagtext(e_ab) == "20.01.2014"
           and [T["H"][h_]["n"] for h_ in HORIZONTE] == [154, 151, 145, 138, 132] and [T["H"][h_]["n_un"] for h_ in HORIZONTE] == [52, 26, 12, 8, 6]
           and abs(V4["v"] - v_hand) < 1e-12 and abs(V4["A"][365][I50] - voll.lnP[o4]) < 1e-12
           and abs((V4["A"][730][I90] - V4["A"][730][I10]) - 2 * 1.2815515655446004 * v_hand * math.sqrt(2.0)) < 1e-9
           and abs(v_l - float(np.std(r_hand, ddof=1)) * math.sqrt(365)) < 1e-12 and len(frueher) == 2 and V4["zyklen"] == 2
           and abs(V4["roh"]["C"][365] - c_hand) < 1e-12 and V4["paare"] == ["rp", "wma"] and sum(voll.ohne_ziel.values()) == 0
           and max(n_e.values()) < MIN_FEHLER and set(V_e["band"].values()) == {"modell"} and set(V4["band"].values()) == {"empirisch"}
           and abs((V_e["B"][365][I90] - V_e["B"][365][I10]) - 2 * 1.2815515655446004 * sd_e) < 1e-9
           and abs(V_e["B"][365][I50] - V_e["roh"]["B"][365]) < 1e-12 and V_e["zyklen"] == 0 and not V_e["C"]
           and n_c == 0 and V_c["zyklen"] == 1 and abs((V_c["C"][365][I90] - V_c["C"][365][I10]) - (V_c["B"][365][I90] - V_c["B"][365][I10])) < 1e-12
           and abs(V_c["C"][365][I50] - V_c["roh"]["C"][365]) < 1e-12 and voll.ohne_rechnung == 0
           and len(d_hand) == 2 and abs(d_hand[0] - d_hand[1]) > 0.01 and abs(V4["roh"]["D"][365] - (d_hand[0] + d_hand[1]) / 2) < 1e-12
           and V_e["paare"] == ["rp"] and 365 in V_e["D"],
           f"gewertet ab {tagtext(e_ab)}; Schwankung {100 * v_hand:.0f} % im Jahr; {len(frueher)} frühere Zyklen")
        # ---- P11 Urteil: Alarm und Aussagekraft führen zur Rückfrage
        E_gut = auswerten(voll)
        L_al = Lauf(B).rechnen()
        L_al.erg["H"][730] = [r_._replace(in80=False) for r_ in L_al.erg["H"][730]]
        E_al = auswerten(L_al)
        alt_f = G["FAKTOR_74"]
        try:
            G["FAKTOR_74"] = 5.0
            E_74 = auswerten(voll)
        finally:
            G["FAKTOR_74"] = alt_f
        q730 = voll.fan(voll.T)["h"][730]["H"]
        tz = "\n".join(_urteil_zeilen(E_al)); tg = "\n".join(_urteil_zeilen(E_gut)); t74 = "\n".join(_urteil_zeilen(E_74))
        ok("P11 Urteil: ohne Alarm und unter dem 20-Fachen heißt es „kann gebaut werden“; ein Alarm (gebaut: das 80-%-Band hält bei 730 "
           "Tagen nie) führt zur Rückfrage und steht mit dem Horizont im Urteil; liegt der 90-%-Rand bei 730 Tagen über dem Vielfachen "
           "der Regel 7.4 (gebaut: Grenze 5), ebenso; das Verhältnis ist 90-%-Rand ÷ 10-%-Rand des Hauptfächers von heute",
           E_gut["urteil"] == "bauen" and E_gut["gruende"] == [] and E_gut["alarm_bei"] == [] and E_gut["haupt"] == E_gut["haupt_regel"] == "H"
           and not E_gut["heute"]["frage_74"] and abs(E_gut["heute"]["verh_730"] - math.exp(q730[4] - q730[0])) < 1e-4 * E_gut["heute"]["verh_730"]
           and 5 < E_gut["heute"]["verh_730"] < 20 and "kann der Chart gebaut werden" in tg and "nein -- bei keinem Horizont" in tg
           and E_al["urteil"] == "rueckfrage" and E_al["alarm_bei"] == [730] and "Alarm 7.2" in E_al["gruende"][0] and "JA bei 730 Tagen" in tz
           and "Rückfrage nötig" in tz and E_al["alarm"]["730"]["deckung"] == 0.0
           and E_74["urteil"] == "rueckfrage" and E_74["heute"]["frage_74"] and "Regel 7.4" in E_74["gruende"][0] and "RÜCKFRAGE" in t74
           and E_74["alarm_bei"] == [] and json.loads(json.dumps(E_gut, allow_nan=False)) == E_gut,
           f"Verhältnis {E_gut['heute']['verh_730']:.1f}; mit Alarm: {E_al['gruende']}")
        # ---- D1 bis D7: Daten wie auf dem Pi (erzeugte makro.db), Ablage des Urteils
        pfad = os.path.join(tmp, "makro.db")
        os.environ["HL_MAKRO_DB"] = pfad
        db = os.path.join(tmp, "hl_liq.db")
        bis = M.tag_ts("2026-11-19") // M.TAG
        jetzt0 = (bis + 1) * M.TAG + 7200
        R0 = vorpruefung(db, jetzt=jetzt0)
        ok("D1 Ohne makro.db: kein Lauf, klare Meldung, nichts wird angelegt",
           not R0["ok"] and "makro.db fehlt" in R0["fehler"] and R0["fest"] is None and not os.path.exists(pfad)
           and "KEIN LAUF: makro.db fehlt" in bericht(R0, jetzt0) and "Ein Urteil ist noch nicht abgelegt." in bericht(R0, jetzt0), R0["fehler"][:60])
        M.testdaten(pfad, n_tage=bis - D0_WELT + 1, seed=11, bis_tag=bis)
        con = M.lesen(pfad); D = M.ableiten(con, bis); con.close()
        Bd, _f = daten(db, jetzt0)
        PA = {(p_["key"], p_["coin"]): p_ for p_ in S.paare_aus(D)}
        gl_d = True
        for key in ("pl", "rp", "wma"):
            p_ = PA[(key, "BTC")]
            gl_d = gl_d and np.array_equal(p_["y"], Bd[key][0], equal_nan=True) and p_["ref"].art == Bd[key][1].art
            for o_ in (3000, 4500, len(p_["y"]) - 1):
                a_, b_ = p_["ref"].prognose(o_, 365), Bd[key][1].prognose(o_, 365)
                gl_d = gl_d and (a_ == b_ or (math.isnan(a_) and math.isnan(b_)))
        ok("D2 Daten wie in Debug 52: Die drei Paare der Langfrist (Power Law, Realized Price, 200-Wochen-MA) sind aus dem Datensatz von "
           "hl_makro.ableiten genau die von hl_makro_signal.paare_aus -- dieselbe Abweichung je Tag, dieselbe Fortschreibung",
           gl_d and Bd["d0"] == D["d0"] == D0_WELT and len(Bd["P"]) == D["n"], f"{D['n']} Tage ab {tagtext(D['d0'])}")

        def zustand():
            c_ = sqlite3.connect(pfad)
            try:
                return (c_.execute("SELECT COUNT(*), SUM(wert) FROM mk_reihe").fetchone(),
                        sorted(c_.execute("SELECT k, v FROM mk_meta WHERE k NOT LIKE 'langfrist:%'").fetchall()),
                        sorted(k_ for (k_,) in c_.execute("SELECT k FROM mk_meta WHERE k LIKE 'langfrist:%'")))
            finally:
                c_.close()
        z_vor = zustand()
        R1 = vorpruefung(db, jetzt=jetzt0)
        z_nach = zustand()
        t1 = bericht(R1, jetzt0)
        fest1 = gespeichert(pfad)
        ok("D3 Erster Lauf mit vollständigen Daten: Das Urteil wird abgelegt (mk_meta „langfrist:urteil“, Regelversion 1) -- sonst ändert "
           "sich an makro.db nichts; die Gegenproben auf diesen Daten bestehen (gleich mit U126, kein Blick voraus); der Bericht nennt "
           "das Urteil, alle acht Abschnitte und keine leeren Werte",
           R1["ok"] and R1["neu"] and not R1["unvollstaendig"] and fest1 is not None and fest1["regel"] == REGELVERSION == 1
           and fest1["ts"] == int(jetzt0) and fest1["version"] == VERSION_MODUL and z_vor[0] == z_nach[0] and z_vor[1] == z_nach[1]
           and z_vor[2] == [] and z_nach[2] == [SCHLUESSEL] and R1["u126"]["gleich"] and R1["kausal"]["ok"]
           and fest1["haupt"] == "H" and fest1["urteil"] == "bauen" and not fest1["heute"]["frage_74"] and fest1["neben"]["4 J"]["mitte"]
           and 5 < fest1["heute"]["verh_730"] < 20 and fest1["alarm_bei"] == [] and "kann der Chart gebaut werden" in t1
           and "dieser Lauf ist der erste mit vollständigen Daten" in t1 and all(f"\n{i} " in t1 for i in range(1, 9))
           and not any(w_ in t1 for w_ in ("nan", "None", "inf ", "Traceback")) and "-- GLEICH" in t1 and "ABWEICHUNG" not in t1
           and "154             151             145             138             132" in t1 and "Laufzeit" in t1
           and len(json.dumps(fest1)) < 40000,
           f"Hauptfächer {fest1 and fest1['haupt']}, Ergebnis {fest1 and fest1['urteil']}; {len(json.dumps(fest1 or {}))} Zeichen abgelegt")
        # später: mehr Daten, anderes Ergebnis möglich -- das Urteil bleibt
        con = M.verbinden(pfad)
        try:
            p_alt = con.execute("SELECT wert FROM mk_reihe WHERE reihe='cm:btc:PriceUSD' ORDER BY ts DESC LIMIT 1").fetchone()[0]
            M.schreiben(con, [("cm:btc:PriceUSD", (bis + i) * M.TAG, p_alt * (1 + 0.01 * i)) for i in range(1, 4)])
        finally:
            con.close()
        jetzt1 = (bis + 4) * M.TAG + 7200
        R2 = vorpruefung(db, jetzt=jetzt1, proben=False, neben=False)
        t2 = bericht(R2, jetzt1)
        ok("D4 Späterer Lauf mit mehr Daten: Das abgelegte Urteil bleibt (Zeit und Inhalt unverändert, Regel 7.5); der Bericht zeigt es mit "
           "seinem Datum und daneben den Stand von heute; der abgelegte Hauptfächer bleibt in Kraft, auch wenn Regel 7.1 heute anders "
           "ausfiele (gebaut: abgelegt „Z“)",
           R2["ok"] and not R2["neu"] and gespeichert(pfad) == fest1 and R2["E"]["daten"]["tage"] == fest1["daten"]["tage"] + 3
           and R2["E"]["daten"]["pruef"] != fest1["daten"]["pruef"] and "abgelegt vom ersten Lauf am" in t2
           and "Stand von heute" in t2 and "Daten damals" in t2 and "Die Abschnitte 1 bis 7 zeigen den Stand dieses Laufs." in t2,
           t2.split("\n")[4][:110])
        fz = dict(fest1); fz["haupt"] = "Z"
        con = M.verbinden(pfad)
        try:
            M._meta_setzen(con, {SCHLUESSEL: json.dumps(fz)})
        finally:
            con.close()
        R3 = vorpruefung(db, jetzt=jetzt1, proben=False, neben=False)
        t3 = bericht(R3, jetzt1)
        ok("D4b Der abgelegte Hauptfächer gilt für Alarm und den Fächer von heute: abgelegt „Z“ -> Abschnitte 4 und 5 rechnen mit Z; was "
           "Regel 7.1 heute ergäbe, steht daneben",
           R3["E"]["haupt"] == "Z" and R3["E"]["haupt_regel"] == R2["E"]["haupt_regel"] and "DECKUNG DES 80-%-BANDS VON Z" in t3
           and "Fächer Z in USD" in t3 and (R3["E"]["haupt_regel"] == "Z" or "ergäbe etwas anderes" in t3)
           and R3["E"]["heute"]["verh_730"] != R2["E"]["heute"]["verh_730"] and R3["E"]["alarm"] != R2["E"]["alarm"]
           and R3["E"]["alarm"]["365"]["deckung"] == R3["E"]["tabelle"]["Z"]["365"]["d80"] != R3["E"]["tabelle"]["H"]["365"]["d80"],
           f"in Kraft {R3['E']['haupt']}, heute nach Regel {R3['E']['haupt_regel']}")
        echt_g = G["gespeichert"]; rufe = {"n": 0}

        def erst_leer(p_):                                                  # als hätte ein zweiter Lauf zugleich begonnen: er sieht noch kein Urteil
            rufe["n"] += 1
            return None if rufe["n"] == 1 else echt_g(p_)
        try:
            G["gespeichert"] = erst_leer
            R3b = vorpruefung(db, jetzt=jetzt1 + 30, proben=False, neben=False)
        finally:
            G["gespeichert"] = echt_g
        ok("D4c Zwei Läufe zugleich: Wer beim Ablegen schon ein Urteil vorfindet, lässt es stehen und meldet seines nicht als neu",
           R3b["ok"] and not R3b["neu"] and R3b["fest"] == fz and gespeichert(pfad) == fz and rufe["n"] == 1
           and "abgelegt vom ersten Lauf am" in bericht(R3b, jetzt1 + 30) and "dieser Lauf ist der erste" not in bericht(R3b, jetzt1 + 30),
           f"neu {R3b['neu']}, in Kraft bleibt {R3b['fest']['haupt']} vom {_uhr(R3b['fest']['ts'])}")
        # neue Regelversion: altes Urteil ins Archiv
        alt_regel = G["REGELVERSION"]
        try:
            G["REGELVERSION"] = 2
            R4 = vorpruefung(db, jetzt=jetzt1 + 60, proben=False, neben=False)
            fest4 = gespeichert(pfad)
            con = M.lesen(pfad); arch = json.loads(M.meta(con, SCHLUESSEL_ARCHIV) or "[]"); con.close()
        finally:
            G["REGELVERSION"] = alt_regel
        ok("D5 Neue Regelversion: Das alte Urteil wandert mit Datum ins Archiv, das neue wird abgelegt; ein zweites Ablegen derselben "
           "Version ändert nichts (speichern gibt das vorhandene zurück)",
           R4["neu"] and fest4["regel"] == 2 and fest4["ts"] == int(jetzt1 + 60) and len(arch) == 1 and arch[0]["regel"] == 1
           and arch[0]["ts"] == fest1["ts"] and arch[0]["haupt"] == "Z"
           and speichern(pfad, dict(fest4, ts=1, haupt="W")) == fest4 and gespeichert(pfad) == fest4, f"Archiv: {len(arch)} Eintrag, Regel {arch and arch[0]['regel']}")
        # unvollständige Daten: kein Urteil
        pfad2 = os.path.join(tmp, "zwei", "makro.db"); os.makedirs(os.path.dirname(pfad2))
        os.environ["HL_MAKRO_DB"] = pfad2
        M.testdaten(pfad2, n_tage=bis - D0_WELT + 1, seed=12, bis_tag=bis)
        R5 = vorpruefung(db, jetzt=(bis + 9) * M.TAG, proben=False, neben=False)        # der letzte Kurstag ist 9 Tage alt
        t5 = bericht(R5, (bis + 9) * M.TAG)
        con = M.verbinden(pfad2)
        try:
            con.execute("BEGIN IMMEDIATE")
            con.execute("DELETE FROM mk_reihe WHERE reihe='cm:btc:PriceUSD' AND ts >= ? AND ts < ?", ((bis - 2000) * M.TAG, (bis - 1969) * M.TAG))
            con.execute("COMMIT")
        finally:
            con.close()
        R6 = vorpruefung(db, jetzt=jetzt0, proben=False, neben=False)                   # 31 Tage ohne Kurs
        t6 = bericht(R6, jetzt0)
        pfad3 = os.path.join(tmp, "drei", "makro.db"); os.makedirs(os.path.dirname(pfad3))
        os.environ["HL_MAKRO_DB"] = pfad3
        M.testdaten(pfad3, n_tage=3600, seed=13, bis_tag=bis)              # kurze Historie: zu wenige gewertete Stichtage
        R7 = vorpruefung(db, jetzt=jetzt0, proben=False, neben=False)
        t7 = bericht(R7, jetzt0)
        ok("D6 Halbe Daten ergeben kein Urteil (vorab festgelegt): letzter Kurstag älter als 7 Tage; mehr als 30 Tage ohne Kurs; weniger "
           "als 100 gewertete Stichtage bei 365 Tagen -- der Bericht sagt „NICHT abgelegt“ mit dem Grund, zeigt die Zahlen als vorläufig, "
           "und in makro.db steht nichts",
           R5["ok"] and not R5["neu"] and R5["fest"] is None and gespeichert(pfad2) is None and len(R5["unvollstaendig"]) == 1
           and "9 Tage alt" in R5["unvollstaendig"][0] and "URTEIL -- NICHT abgelegt: der letzte Kurstag ist 9 Tage alt" in t5
           and "vorläufig" in t5 and R6["ok"] and R6["E"]["daten"]["luecken"] == 31 and any("31 Tage ohne Kurs" in g_ for g_ in R6["unvollstaendig"])
           and gespeichert(pfad2) is None and "31 ohne Kurs" in t6 and sum(R6["E"]["raster"]["ohne_ziel"].values()) > 0
           and R7["ok"] and len(R7["unvollstaendig"]) == 1 and "gewertete Stichtage bei 365 Tagen (mindestens 100)" in R7["unvollstaendig"][0]
           and 0 < R7["E"]["tabelle"]["H"]["365"]["n"] < 100 and "NICHT abgelegt" in t7 and gespeichert(pfad3) is None,
           f"alt: {R5['unvollstaendig']}; Lücke: Ziel ohne Kurs {R6['E']['raster']['ohne_ziel']}; kurz: {R7.get('unvollstaendig') or R7.get('fehler')}")
        # ---- K Zahlen der Regeln gegen das Konzept
        kz = ""
        for kand in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "KONZEPT_Langfrist.md"),):
            if os.path.exists(kand):
                with open(kand, encoding="utf-8") as fh:
                    kz = fh.read()
        zahlen_ok = (HORIZONTE == (90, 180, 365, 548, 730) and ABSTAND == 30 and VOL_TAGE == 1461 and MIN_FEHLER == 20 and FEHLER_TAGE == 1460
                     and abs(ALPHA - 0.05 / 3) < 1e-15 and MIN_FENSTER == 6 and FAKTOR_74 == 20 and len(TAU) == 199 and TAU[0] == 0.005
                     and TAU[-1] == 0.995 and (TAU[I10], TAU[I25], TAU[I50], TAU[I75], TAU[I90]) == (0.1, 0.25, 0.5, 0.75, 0.9)
                     and tagtext(AB_TAG) == "01.01.2014" and REGELVERSION == 1 and DEBUG_NR == 153 and NEBEN == (("8 J", 2922), ("4 J", 1461))
                     and M.HALVINGS == ("2012-11-28", "2016-07-09", "2020-05-11", "2024-04-20") and Q5 == (0.1, 0.25, 0.5, 0.75, 0.9))
        if kz:
            ok("K1 Die Zahlen der Regeln stehen so im Konzept (KONZEPT_Langfrist.md): Horizonte, Raster, Start 2014, Schwankungsfenster, "
               "Fehlerfenster, 199 Quantile, Schwelle des Tests, Grenze der Aussagekraft, Halvings, Regelversion",
               zahlen_ok and "90, 180, 365, 548 und 730 Tage" in kz and "dann alle 30 Tage" in kz and "ab 01.01.2014" in kz
               and "letzten 1.461 Tage" in kz and "mindestens 20" in kz and "199 Quantile dargestellt (0,5 % bis 99,5 %)" in kz
               and "p ≤ 0,05 ÷ 3 = 0,0167" in kz and "mindestens 6 Fenster" in kz and "20-Fachen" in kz and "begrenzt auf ¼ bis ¾" in kz
               and "(28.11.2012, 09.07.2016, 11.05.2020, 20.04.2024)" in kz and "(Start: 1)" in kz and "0,80 − 2 · √(0,16 ÷ n)" in kz
               and "höchstens 7 Tage alt" in kz and "höchstens 30 Tage ohne Kurs" in kz and "mindestens 100 gewertete" in kz,
               "Konzept gelesen")
        else:
            ok("K1 Die Zahlen der Regeln (das Konzept liegt nicht neben dem Modul -- nur die Zahlen des Moduls geprüft)", zahlen_ok,
               "KONZEPT_Langfrist.md fehlt hier")
        # ---- K2 Vertrag mit dem Paket
        hier = os.path.dirname(os.path.abspath(__file__))
        quellen = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as fh:
                    quellen[n_] = fh.read()
            except OSError:
                quellen[n_] = ""
        ok("K2 Vertrag mit dem Paket: hl_langfrist.py in der Prüfsumme (version.py), in Sicherung und Wiederherstellung (update.py), im "
           "Übersetzungs- und im Prüfschritt des Installers; Debug-Lauf „langfrist_pruefung“ im Dashboard mit --vorpruefung und der "
           "Datenbank; im Berichtsplan nach dem Einspielen von 23.115",
           '"hl_langfrist.py"' in quellen["version.py"] and '"hl_langfrist.py"' in quellen["update.py"]
           and quellen["install.py"].count('str(ROOT / "hl_langfrist.py")') == 2 and '[py, str(ROOT / "hl_langfrist.py"), "--selbsttest"]' in quellen["install.py"]
           and '[py, "hl_langfrist.py", "--vorpruefung", "--db", db]' in quellen["hl_viz.py"] and '"langfrist_pruefung": (' in quellen["hl_viz.py"]
           and '"laeufe": ["langfrist_pruefung", "makro_stand",' in quellen["hl_viz.py"],
           ", ".join(n_ for n_, q_ in quellen.items() if "hl_langfrist" in q_) or "in keiner Liste")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-900:].replace("\n", " | "))
    finally:
        if alt_env is None:
            os.environ.pop("HL_MAKRO_DB", None)
        else:
            os.environ["HL_MAKRO_DB"] = alt_env
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--vorpruefung", action="store_true", help="Rückrechnung, Regeln 7.1 bis 7.4, Bericht als Text (Debug 153)")
    p.add_argument("--db", default="hl_liq.db", help="Hauptdatenbank; makro.db liegt daneben")
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz (erzeugte Reihen)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.vorpruefung:
        try:
            sys.stdout.write(bericht(vorpruefung(a.db)))
        except Exception as e:                                               # der Bericht soll sagen, was geschah -- kein stummer Abbruch
            import traceback
            print(f"★ Langfrist: Vorprüfung (Debug {DEBUG_NR}) · Modul {VERSION_MODUL}\nFEHLER im Lauf: {type(e).__name__}: {e}\n"
                  + traceback.format_exc()[-1500:])
            sys.exit(1)
        return
    p.print_help()


if __name__ == "__main__":
    main()
