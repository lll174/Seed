# KONZEPT Swing-Trades (U140) — Positionen über Tage: Regeln vorab, Historie zuerst, dann das Labor

Stand 08.10.2026, Version 2026-09-23.61 (Opus 5.5). **Status: gebaut** (`hl_swing.py`, sechs neue Strategien im TradeLabor,
Debug-Bericht „★ Swing: Vorprüfung auf der Historie (U140)“). Alle Regeln und Urteilsbedingungen unten standen fest, bevor eine
einzige echte Kerze gerechnet wurde. Beim Bau geändert, ebenfalls vor jedem echten Lauf: der Placebo-Vergleich (Abschnitt 6a, weil
Nullmärkte zeigten, dass der Rang unter den Placebo-Läufen nicht kalibriert war). **Erster Lauf auf dem Pi 08.10. 21:30: keine
Strategie belegt; die beiden Ausbruchsregeln S1 und S3 positiv, aber nicht von Glück zu trennen, S4 negativ (Abschnitt 6b).**

**Wunsch des Nutzers (08.10. 07:20):** „Ich will Swing-Trades in das System inkludieren. Baue alles dafür Notwendige ein. Entwickle
das bestmögliche Konzept und integriere eine oder bevorzugt mehrere bestmögliche Strategien in das TradeLabor.“

**Zusage bis 25.10. bleibt:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen bleiben unberührt. Die bestehenden 38 Labor-Strategien
behalten ihre Kennungen (Probe im Labor-Selbsttest); die neuen bekommen eigene.

## 0. Kurzfassung

1. **Swing heißt hier:** Einstieg nach dem Tagesschluss (00:00 UTC), Haltedauer 1–30 Tage, Stop und Größe aus der Tagesschwankung,
   je Strategie und Coin höchstens eine Position.
2. **Ehrliche Ausgangslage:** Phase 0 (U138) fand auf drei Jahren keine Richtungsvorhersage über Tage (Stufen = Zufallsgeometrie,
   kein Wochenmomentum, Analoge nicht besser als der Zufallsweg). Vorhersagbar ist die Größe der Bewegung. Swing-Strategien
   müssen deshalb auf zwei Dinge bauen: auf das, was die Literatur über Märkte hinweg am besten belegt (Trendfolge mit
   Nachzieh-Stop), und auf saubere Risikosteuerung. Ob sie bei uns tragen, entscheidet zuerst die **Historie seit 2020**, dann
   das Labor.
3. **Vier Strategien und zwei Kontrollen** (Abschnitt 4), alle Parameter fest aus der Lehrbuchpraxis, nichts optimiert:
   - S1 Trend-Ausbruch (20-Tage-Kanal, Nachzieh-Stop) — die am besten belegte Swing-Regel überhaupt;
   - S2 Rücksetzer im Trend — die Idee des Nutzers („höhere Tiefs“), mit eigener Placebo-Kontrolle;
   - S3 Ausbruch nach Ruhe (Kompression) — nutzt, dass die Schwankung vorhersagbar ist;
   - S4 Gegenbewegung nach Übertreibung mit Funding-Druck — die Gedrängt-Seite muss raus;
   - Kontrollen: Zufall mit den Ausstiegen von S1, Zufall im Trend mit den Ausstiegen von S2.
4. **Risiko vor Richtung:** jede Position riskiert 100 USD bis zum Stop (1 % eines 10.000-USD-Kontos je Coin), Größe =
   100 USD ÷ Stop-Abstand, höchstens 10.000 USD. Ergebnisse zählen in Vielfachen dieses Risikos (R).
5. **Vorab festgelegtes Urteil** (Abschnitt 6): auf der Historie gewinnt eine Strategie nach allen Kosten und Funding (Tages-
   ergebnis, HAC-Test), schlägt ihr Zeitpunkt-Placebo (Holm über vier), ist in beiden Hälften positiv und hat einen Deflated
   Sharpe ≥ 0,95. Sonst „nicht belegt“ — und dann ist auch das ein Ergebnis.
6. **Ehrliche Erwartung:** Selbst eine gute Swing-Regel (Sharpe 0,7–1,0) ist auf sechs Jahren nur knapp nachweisbar; vorwärts
   braucht ein Urteil bei S1 rund 2–3 Jahre (8 Trades je Coin und Jahr). Das Labor prüft deshalb zuerst Ausführung, Kosten und
   Gleichlauf mit der Historie, und sammelt nebenbei Vorwärtsbeleg.
7. **Ergebnis des ersten Laufs (08.10., Abschnitt 6b):** nichts belegt. S3 Ausbruch nach Ruhe am stärksten (Ø +0,34 R je Trade,
   Sharpe 0,72, in allen Coins und Jahren positiv, p 0,10), S1 Trend-Ausbruch positiv (Ø +0,17 R, Sharpe 0,49), S2 ≈ null nach
   Kosten, S4 negativ (Ø −0,20 R). Genau der vorab beschriebene Fall: plausibel, aber auf sechs Jahren nicht nachweisbar.

## 1. Was Swing hier heißt

- **Takt:** Entscheidungen fallen einmal am Tag nach dem Tagesschluss 00:00 UTC auf Tageskerzen. Ausgeführt wird zum nächsten
  Kurs (Historie: Eröffnung der 00:00-Kerze; Labor: der erste Takt mit frischen Tageskerzen, spätestens 6 h nach dem Schluss).
- **Halten:** bis zum Stop (in der Kerze, jederzeit), zum Ziel (Limit), bis zu einem Ausstiegssignal am Tagesschluss oder bis
  zur Höchstdauer der Strategie.
- **Coins:** die fünf Labor-Coins BTC, ETH, ZEC, HYPE, XMR. PAXG nicht (kein Labor-Coin, Gold folgt eigenen Regeln).

## 2. Was dafür und dagegen spricht

- **Dafür (Literatur, über viele Märkte):** Zeitreihen-Momentum und Trendfolge sind die am breitesten belegte Anomalie
  (Futures aller Klassen, Jahrzehnte), für Bitcoin auf 1–4 Wochen ebenfalls beschrieben. Der Vorteil kommt nicht aus der
  Trefferquote, sondern aus der Schiefe: viele kleine Verluste, wenige große Trends, die der Nachzieh-Stop laufen lässt.
- **Dagegen (unsere Daten):** P0.6 fand Wochenmomentum für BTC/ETH positiv, aber nicht belegt (Sharpe −0,2 bis +1,7, DSR ≤ 0,89);
  P0.3 und P0.4 zeigen, dass Rücksetzer und höhere Tiefs so oft kommen wie im Zufall. Darum S2 mit eigener Placebo-Kontrolle.
- **Folge:** Nichts wird live gehandelt, bevor die Historie es belegt; das Labor ist Schatten. Die vorab festgelegten Regeln
  verhindern, dass wir am Ende die Variante finden, die zufällig passt.

## 3. Grundregeln

1. **Daten:** Binance-Futures USDT-Perpetual, 30-min-Kerzen ab 01.01.2020 (oder Listung), dazu die Funding-Historie derselben
   Börse. Eigene Datei `swing.db` neben der Hauptdatenbank (Tabellen `sw_klines`, `sw_funding`, `sw_meta`), nur Schreiben mit
   BEGIN IMMEDIATE. `regime.db` und `klines30` bleiben unberührt. Signale aus einer Börse für alle Coins; gehandelt wird im Labor
   auf Hyperliquid (Buch, 1-min-Kerzen, stündliches Funding). Unterschiede (Basis, Funding-Takt) stehen im Bericht.
2. **Tageskerzen:** UTC-Tag aus den 48 Kerzen; Schluss = Schluss der 23:30-Kerze, Hoch/Tief über alle Kerzen. Ein Tag gilt nur
   mit ≥ 40 Kerzen, der 00:00- und der 23:30-Kerze; sonst fällt seine Entscheidung aus.
3. **Schwankung σ_Tag:** EWMA der Tages-RV (Summe der quadrierten 30-min-Renditen) mit Halbwertszeit 20 Tagen, **einschließlich**
   des Entscheidungstags (er ist am Schluss bekannt). Alle Abstände in Vielfachen davon.
4. **Kausal:** Jede Entscheidung am Tag d nutzt nur Kerzen bis zum Schluss von Tag d. Probe: Daten nach d ändern → Entscheidungen
   bis d gleich (Selbsttest).
5. **Größe:** Risiko 100 USD bis zum Stop; Notional = 100 USD ÷ Stop-Abstand (als Anteil), höchstens 10.000 USD.
6. **Kosten wie im Labor:** Taker 0,045 %, Maker 0,015 %, XMR doppelt (HIP-3). Historie zusätzlich Abstand zur Mitte je Seite:
   BTC/ETH 1,5 bp, übrige 5 bp. Stop: Kurs der Kerze, durch die der Stop fällt (Lücke: ihre Eröffnung) minus Abstand; Ziel: genau
   am Limit (Maker); Signal- und Zeitausstieg: Eröffnung des Tages (Taker). Liegen Stop und Ziel in derselben Kerze, gilt der Stop;
   in der Einstiegskerze zählt nur der Stop.
7. **Funding:** jede Funding-Zahlung zwischen Ein- und Ausstieg auf das Notional (Long zahlt positive Raten).
8. **Eine Position je Strategie und Coin.** Nach einem Ausstieg kann am selben Tagesschluss neu entschieden werden (auch in die
   Gegenrichtung).

## 4. Strategien (fest, vorab)

Gemeinsam: Risiko 100 USD, Notional höchstens 10.000 USD, Entscheidung am Tagesschluss, beide Richtungen gespiegelt.

**S1 Trend-Ausbruch** (`swing_trend`)
- Einstieg Long: Schluss > höchstes Hoch der 20 Tage davor; Short: Schluss < tiefstes Tief der 20 Tage davor.
- Stop 2 σ_Tag; Nachzieh-Stop: bester Schluss seit dem Einstieg − 3 σ_Tag (zieht nur nach, nie zurück).
- Ausstieg: Schluss unter dem tiefsten Tief der 10 Tage davor (Short: über dem höchsten Hoch); spätestens nach 30 Tagen.

**S2 Rücksetzer im Trend** (`swing_ruecksetzer`) — die Idee des Nutzers
- Trend Long: 20-Tage-Mittel > 50-Tage-Mittel und Schluss > 50-Tage-Mittel; Rücksetzer: Schluss ≥ 2 σ_Tag unter dem höchsten
  Schluss der letzten 10 Tage (log).
- Stop 2 σ_Tag; Ziel (Limit) = höchster Schluss der letzten 10 Tage, mindestens 1,5 σ_Tag über dem Einstieg; spätestens nach
  10 Tagen.

**S3 Ausbruch nach Ruhe** (`swing_kompression`)
- Ruhe am Vortag: Schwankung der letzten 10 Tage (√ Mittel der Tages-RV) im untersten Fünftel ihrer 250 Werte davor.
- Einstieg Long: Schluss > höchstes Hoch der 10 Tage davor; Short: < tiefstes Tief.
- Stop 1,5 σ_Tag; Nachzieh-Stop 3 σ_Tag vom besten Schluss; spätestens nach 20 Tagen.

**S4 Gegenbewegung nach Übertreibung** (`swing_gegenbewegung`)
- Long: 3-Tage-Rendite ≤ −2,5 · σ_Tag · √3 und Funding gedrängt kurz: Tagesmittel der Funding-Raten mindestens 1
  Standardabweichung unter dem Mittel der 30 Tage davor. Short gespiegelt (≥ +2,5 σ√3, Funding ≥ +1 SD).
- Stop 2 σ_Tag; Ziel (Limit) = halber Rücklauf der 3-Tage-Bewegung, mindestens 1 σ_Tag; spätestens nach 5 Tagen.

**Kontrollen (nur Labor, vorwärts; in der Historie ersetzt sie das Zeitpunkt-Placebo, Abschnitt 6):**
- `swing_zufall`: an jedem Tag ohne Position mit 10 % Einstieg, Richtung zufällig; Ausstiege wie S1.
- `swing_ruecksetzer_zufall`: an Tagen mit dem Trend von S2 (gleiche Richtung) mit 10 % Einstieg, ohne Rücksetzer-Bedingung;
  Ausstiege wie S2. Zieht man sie von S2 ab, bleibt der Wert des Rücksetzer-Zeitpunkts.

## 5. Daten und Takt

- **Erstladen:** Historie ab 2020 (rund 120.000 Kerzen je Coin, HYPE ab Mai 2025) und Funding; im Dashboard-Prozess im
  Hintergrund (je Runde höchstens 4 min, dann weiter in der nächsten) und über den Debug-Eintrag „Swing: Historie laden“.
- **Laufend:** alle 5 min prüft der Swing-Takt, ob die letzte fertige 30-min-Kerze fehlt, und ergänzt Kerzen und Funding. Die
  Tageskerze für den Tag d steht damit gegen 00:05 UTC bereit.
- **Labor:** liest `swing.db` nur lesend (die letzten 460 Tage, neu nur bei neuer Kerze). Ohne frische Tageskerzen keine neuen
  Einstiege (Anzeige „Tageskerzen veraltet“); Stops laufen weiter auf den Hyperliquid-Minutenkerzen.

## 6. Vorprüfung auf der Historie (vorab festgelegt)

- **Zeitraum:** je Coin ab dem ersten Tag mit allen Kennzahlen (260 Tage nach Datenbeginn) bis zum letzten fertigen Tag.
- **Rechnung:** jede Strategie mit genau den Labor-Regeln (gemeinsame Funktionen für Einstieg und Nachführen; Probe im
  Selbsttest), Kosten und Funding wie in Abschnitt 3. Tagesergebnis aller Coins zusammen, bewertet zum Tagesschluss.
- **Zeitpunkt-Placebo:** 200 Läufe je Strategie: gleiche Coins, gleiche Einstiegsrate je Coin, gleicher Anteil Long, gleiche
  Ausstiege, aber zufällige Einstiegstage (S2: nur Tage mit seinem Trend). Geprüft wird der **Mehrertrag je Trade**:
  (Ø R der Strategie − Ø der Placebo-Läufe) ÷ √(SE² + SE_Placebo²), einseitig. SE = Standardfehler des mittleren R aus der
  Tagesreihe (HAC, Lag 10, umgerechnet je Trade), SE_Placebo = Streuung der Läufe ÷ √Läufe. Beim Bau geändert (6a): ursprünglich
  „p = Anteil der Läufe mit mindestens so hohem mittleren R“.
- **Belegt**, wenn alles gilt:
  1. mindestens 60 Trades;
  2. Tagesergebnis im Mittel positiv, HAC-t-Test (Lag 10) p < 0,05;
  3. Placebo-p nach Holm über die vier Strategien < 0,05;
  4. beide Hälften des Zeitraums netto positiv;
  5. Deflated Sharpe ≥ 0,95 (vier Versuche).
- **Beschreibend:** Trades je Richtung, Trefferquote, mittlerer Gewinn und Verlust in R, Profitfaktor, Sharpe je Jahr, größter
  Rückgang, Zeit im Markt, Kosten und Funding, je Coin und je Jahr; dazu der Kursverlauf je Coin als Bezug.
- **Teststärke:** Ein Sharpe von 1,0 ergibt auf 6 Jahren t ≈ 2,4; ein Sharpe von 0,5 ist nicht nachweisbar. „Nicht belegt“
  heißt deshalb nicht „wirkungslos“, sondern „nicht von Zufall und Drift zu trennen“.
- **Zusätzlich beschreibend (kein Urteil):** Zerlegung je Trade in Kurs (Mitte zu Mitte), Abstand zur Mitte, Gebühren und Funding;
  derselbe Placebo-Vergleich „nur Kurs“; der alte Rang unter den Läufen.

## 6a. Beim Bau geändert und kalibriert (08.10., vor dem ersten echten Lauf)

**Placebo: Mehrertrag studentisiert statt Rang unter den Läufen.**
- **Befund:** Auf Zufallswegen ohne jeden Effekt (Nullreplikationen, 30 unabhängige Märkte zu 5 Coins und 1.150 Tagen in fünf
  Varianten: Drift ±0,05 %/Tag, ohne Drift, Drift +0,2 %/Tag, starke Schwankungsregime) lag der Rang-p bei S4 in 9 von 30 Märkten
  unter 0,05 (Soll 1,5), bei S2 in 3, bei S1 und S3 in keinem; in 150 weiteren Märkten bei S4 in 25 % (Soll 5 %).
- **Ursache:** Die Strategien wählen Tage mit anderer Schwankung als der Zufall. S4 steigt nach starken Bewegungen ein (Tages-RV
  am Einstieg rund das 2-Fache von σ²_Tag, beim Placebo das 0,9-Fache); seine Trades enden öfter am Stop oder am weiten Ziel. Ihr
  mittleres R streut daher stärker als das der Placebo-Läufe, und ein Rang gegen die schmalere Placebo-Verteilung wird zu oft
  extrem (U-förmige p-Werte). Das Funding war es nicht: „nur Kurs“ ergab dieselben p.
- **Änderung:** Mehrertrag je Trade gegen das Placebo-Mittel, mit dem Standardfehler der Strategie selbst. Den liefert die
  Tagesreihe (HAC), die auch gleichzeitige und überlappende Trades mehrerer Coins richtig zählt. Der Rang bleibt als Anzeige.
- **Kalibrierung danach** (Placebo-p allein, ohne die übrigen Bedingungen):
  - S2, 100 Nullmärkte: p < 0,05 in 5,0 %, p < 0,10 in 11 % (Rang vorher 14 % bzw. 21 %); SE passt (Streuung der t 0,86).
  - S4 auf den Selbsttest-Märkten (150–300 je Variante): 7,7–10 % statt 19–31 %. Der Rest ist ein Artefakt dieser Testmärkte:
    Ihre 30-min-Kerzen haben einen geraden Pfad mit zufälligem Docht, und dort werden stop-lastige Ausstiege bevorzugt (Mehrertrag
    +0,02 bis +0,04 R ohne jeden Effekt, auch in log-Renditen; ohne Dochte sogar +0,05).
  - **Auf Märkten mit echtem Pfad in der Kerze** (1-min-Schritte, wahres Hoch und Tief wie bei echten Kerzen; Drift 0, Funding
    folgt der Bewegung), Placebo-p < 0,05 / < 0,10 / Mittel:
    - S1 (100 Märkte): 1 % / 1 % / 0,59 -- vorsichtig (Rang 1 %);
    - S2 (100): 5 % / 12 % / 0,48 (Rang 11 %);
    - S3 (100): 2 % / 6 % / 0,58 -- vorsichtig (Rang 3 %);
    - S4 (300): 5,0 % / 10,3 % / 0,47, Mehrertrag +0,009 und +0,015 R, beide nicht von null verschieden (Rang 21 %).
  - Das Urteil als Ganzes: 0 von 160 Nulltests „belegt“ (40 Märkte × 4 Strategien); Tagesergebnis p < 0,05 und positiv in
    3,1 % (Soll 2,5 %); Placebo und Tagesergebnis zusammen bei S4 in 1–4 % (je 150–300 Märkte).
- **Positivkontrollen** bleiben belegt (alle vier mit Placebo-p × 4 < 0,0001; vorher stieß der Rang mit 100 Läufen an seine
  Untergrenze 0,04).
- **Rechenzeit** in voller Größe (5 Coins × 2.450 Tage, 200 Placebo-Läufe je Strategie): 57 s in der Sandbox, auf dem Pi geschätzt
  2–3 min; Grenze des Berichtsplans 15 min.

## 6b. Ergebnis des ersten Laufs (08.10.2026 21:30 auf dem Pi, Code 23.61)

**Daten:** Binance-Futures, ohne Lücke. BTC und ETH 01.01.2020–08.10.2026 (2.473 Tage, je 118.695 Kerzen), ZEC ab 05.02.2020,
XMR ab 03.02.2020, HYPE ab 30.05.2025 (497 Tage, bewertet ab 14.02.2026); 2.977–7.419 Funding-Zahlungen je Coin. Die Historie hatte
der Swing-Takt im Dashboard schon vor dem Termin vollständig geladen. Rechenzeit 27 s mit 200 Placebo-Läufen je Strategie.

| Strategie | Trades | Treffer | Ø R je Trade | Summe R | Sharpe/Jahr | p Tag | Mehrertrag gegen Placebo | p Holm | Hälften | DSR | Urteil |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S1 Trend-Ausbruch | 343 | 35 % | +0,17 ± 0,10 | +58,7 | +0,49 | 0,201 | +0,12 ± 0,13 | 0,561 | +/+ | 0,46 | – |
| S2 Rücksetzer im Trend | 421 | 48 % | +0,04 ± 0,05 | +18,2 | +0,27 | 0,482 | +0,05 ± 0,06 | 0,561 | +/+ | 0,26 | – |
| S3 Ausbruch nach Ruhe | 206 | 34 % | +0,34 ± 0,17 | +70,5 | +0,72 | 0,100 | +0,28 ± 0,21 | 0,360 | +/+ | 0,68 | – |
| S4 Gegenbewegung nach Übertreibung | 67 | 34 % | −0,20 ± 0,13 | −13,5 | −0,45 | 0,216 | −0,18 ± 0,16 | 0,870 | −/− | 0,02 | – |

**Belegt: keine.** Keine Strategie erfüllt schon die Bedingung „Tagesergebnis p < 0,05“, keine hat DSR ≥ 0,95. Der alte Rang-Test
hätte nichts geändert (S3: Rang 0,025, nach Holm 0,10).

**Lesart:**
1. **Die beiden Ausbruchsregeln liegen vorn.**
   - S3 ist in allen fünf Coins positiv (BTC +23,2 R, ETH +15,1, ZEC +14,8, XMR +15,5, HYPE +1,9) und in jedem Jahr (2024 nur
     knapp: +0,9 R aus 14 Trades).
   - S1 trägt bei BTC (+35,2 R) und ETH (+24,0), nicht bei ZEC (−5,4) und XMR (−0,3).
   - Beide leben von wenigen großen Trends: Treffer 34–35 %, Gewinner im Mittel +2,1 bzw. +2,8 R, Verlierer −0,9 R.
2. **Die Größe passt zur Literatur und zur Vorab-Warnung** (Abschnitt 6, Teststärke): Ein Sharpe von 0,5–0,7 ergibt auf sechs
   Jahren t ≈ 1,3–1,7. „Nicht belegt“ heißt hier: plausibel, aber nicht von Glück zu trennen.
3. **2026 trägt viel:** bei S3 +37,3 der +70,5 R (36 Trades), bei S1 +23,1 der +58,7 R. Ohne 2026 bleiben S3 im Mittel +0,20 R und
   S1 +0,12 R je Trade.
4. **Der Vorsprung kommt aus dem Kurs:** Kurs (Mitte zu Mitte) +0,23 R je Trade bei S1, +0,40 R bei S3. Gebühren, Abstand zur Mitte
   und Funding kosten zusammen 0,06 bzw. 0,05 R.
5. **S2 verdient kaum mehr als zufällige Einstiege an Trendtagen** (Mehrertrag +0,05 ± 0,06 R). Der Wert liegt im Trend selbst,
   nicht im Rücksetzer als Zeitpunkt; das passt zu P0.3 (höhere Tiefs so oft wie im Zufall).
6. **S4 verliert:** Kurs −0,21 R je Trade, das Funding bringt +0,02 R. Nach starken 3-Tage-Bewegungen mit gedrängtem Funding kam die
   Gegenbewegung nicht.
7. **Die Placebo-Läufe selbst** liegen bei S1 und S3 im Mittel leicht im Plus (+0,05 bzw. +0,06 R): Ausstiege mit Nachzieh-Stop
   fangen auch bei zufälligem Einstieg etwas Trend.

**Folgen:** Alle sechs Strategien laufen im Labor weiter (Vorwärtsbeleg). Echtes Geld: nein. Mehr Teststärke gibt es nur mit mehr
Daten (Abschnitt 10, Punkt 4).

## 7. Vorwärts im Labor

- Sechs Strategien mit eigenen Kennungen in der Gruppe „Swing“; Blöcke je Tag (gleichzeitige Einstiege in mehreren Coins zählen
  einmal). Im Labor-Bericht zusätzlich R je Trade.
- **Was das Labor zuerst zeigt:** ob Ausführung, Kosten und Funding auf Hyperliquid so ausfallen wie in der Historie
  angenommen, und ob die Einstiege dieselben Tage treffen wie die Historie.
- **Ablauf im Takt:** Nach dem Tagesschluss (sobald der Swing-Takt die 23:30-Kerze geladen hat, gegen 00:05 UTC) einmal je Tag
  Nachführen der offenen Position (Nachzieh-Stop nur in Gewinnrichtung, Ereignis „Stop nachgezogen“) bzw. Signal-Ausstieg zum
  Marktpreis ohne Pause; danach, falls flach, die Einstiegsentscheidung (höchstens 6 h nach dem Schluss, höchstens einmal je
  Tag). Stop und Ziel laufen jederzeit auf den Hyperliquid-Minutenkerzen. Der Ausstieg am nachgezogenen Stop heißt im Labor
  „Stop“ (in der Historie „Nachzieh-Stop“); die Ereignisliste zeigt jedes Nachziehen.
- **Stufen danach (Entscheidung des Nutzers, nichts automatisch):** Historie belegt → mindestens 6 Monate Labor ohne Widerspruch
  (mittleres R innerhalb des 90-%-Bands der Historie) → kleines echtes Konto, falls gewünscht.

## 8. Proben

`hl_swing.py --selbsttest` (20 Prüfungen, rund 40 s in der Sandbox, ohne Netz; auch Installationsschritt):
- **Bausteine:** Tageskerzen gegen Brute Force (Lücken, fehlende 00:00/23:30-Kerze, Tag mit 38 Kerzen), σ_Tag einschließlich des
  Tags, Kanäle ohne den Tag selbst, Perzentile nur aus der Vergangenheit, Funding-Tagesmittel und -z.
- **Ausführung von Hand nachgerechnet:** Stop in der Kerze mit Gebühren und Funding über mehrere Tage, Lücke über den Stop, Ziel
  als Maker, XMR doppelte Gebühr, Zeitausstieg zur Eröffnung, Stop schon in der Einstiegskerze, Stop und Ziel in derselben Kerze
  (Stop), Größe nach Risiko mit Deckel, Short gespiegelt, Nachzieh-Stop nur in Gewinnrichtung (auch wenn σ steigt, Long und
  Short), Kanal-Ausstieg mit Gegen-Einstieg am selben Schluss, Kurs-Anteil (Mitte zu Mitte).
- **Regeln an der Schwelle:** S1 strikt über dem Kanal, S2 ab 2 σ nur im Trend (Schluss über dem langen Mittel), S3 Ruhe am Vortag
  (nicht erst am Signaltag), S4 mit √3 und Funding ab 1 SD, Ziele, beide Kontrollen. Die Labor-Kennung hängt nur an den
  Parametern; diese Probe hält den Code an ihnen fest.
- **Kausalität:** Kurse und Funding ab Tag 600 geändert → Kennzahlen (σ, Kanäle, Mittel, Ruhe, 3-Tage-Rendite, Funding-Druck),
  Einstiege und Nachführen bis Tag 599 gleich, ab 600 verschieden (Gegenprobe); Labor-Ausschnitt (460 Tage) = Historie; aus
  `swing.db` gelesen zählt um 23:50 der laufende Tag nicht, um 00:01 schon.
- **Zeitpunkt-Placebo:** nur flache volle Tage im Bewertungsbereich, keine Überlappung, S2 nur an Trendtagen mit Trendseite,
  Long-Anteil wie vorgegeben, dieselben Ausstiegsparameter.
- **Urteil an gebauten Ergebnissen:** Holm über die vier, ≥ 60 Trades, Tagesergebnis signifikant UND positiv, beide Hälften,
  DSR ≥ 0,95, Formel des Mehrertrags (SE je Trade aus der Tagesreihe, einseitig).
- **Laden ohne Netz** (Quellen ersetzt): ab 2020 lückenlos bis zur letzten fertigen Kerze, spätere Listung, unbekanntes Symbol,
  zweiter Lauf nichts Neues, Sperre gegen einen zweiten Ladevorgang, Börse weg.
- **Nulltest:** Zufallswege (Drift, Schwankungsregime, dicke Ränder, Funding folgt der Bewegung) → keine Strategie belegt.
- **Positivkontrollen** mit eingepflanzten Effekten: Momentum über 20 Tage → S1; Rücklauf nach Rücksetzern im Trend → S2;
  Fortsetzung nach Ausbruch aus Ruhe → S3; Gegenbewegung nach Übertreibung mit Funding-Druck → S4.
- **Bericht** mit allen Abschnitten, „zu kurz“ und „keine Historie“.

Im TradeLabor-Selbsttest (`hl_labor.py --selbsttest`, synthetischer Minutenmarkt mit Ausbruch, Rallye und Rutsch): Einstieg am Tag
nach dem Ausbruch binnen 15 min, Größe nach Risiko, vier Nachzieh-Stops nur nach oben, Ausstieg am Rutsch an denselben Tagen wie
die Historie, Funding über Tage, Neustarts, veraltete Tageskerzen ohne Einstieg, einmal je Tag, höchstens 6 h nach dem Schluss,
Signal-Ausstieg zum Marktpreis ohne Pause mit neuem Einstieg im selben Takt, Bilanz in R; die 38 bestehenden Kennungen unverändert.

**Mutationen** (`mut140b.py`, nicht im Paket): siehe UEBERGABE 3κκ. **Nullreplikationen und Kalibrierung:** Abschnitt 6a.

## 9. Grenzen und Risiken

- **Teststärke** (Abschnitt 6): kleine Vorteile bleiben unsichtbar; vorwärts dauert ein Urteil Jahre.
- **Eine Börse für die Signale:** Binance statt Hyperliquid; Basis meist unter 0,1 %. Das Funding auf Hyperliquid (stündlich)
  weicht ab; das Labor rechnet das echte.
- **Strukturbrüche:** 2020–2026 enthält Bullen- und Bärenmärkte, ETF-Start, CME rund um die Uhr. Der Bericht zeigt jedes Jahr.
- **Drift:** Long-Strategien gewinnen in steigenden Jahren schon durch die Drift; das Placebo mit gleichem Long-Anteil zieht sie ab.
- **Andere Lage, andere Streuung:** Strategien steigen in Lagen mit anderer Schwankung ein als der Zufall; ein Rang gegen die
  Placebo-Läufe allein wäre deshalb zu oft „besser als Zufall“ (6a). Bei S1 ist der Vergleich eher vorsichtig.
- **Testmärkte:** Synthetische 30-min-Kerzen ohne echten Pfad in der Kerze bevorzugen stop-lastige Ausstiege; Kalibrierung deshalb
  auf Märkten mit 1-min-Pfad (6a). Echte Kerzen haben wahres Hoch und Tief.
- **Kosten bei XMR:** doppelte Gebühren auf Hyperliquid.
- **Kein echtes Geld.** Das Labor simuliert nur; eine Freigabe für echtes Geld ist eine Entscheidung des Nutzers.

## 10. Entscheidungen beim Nutzer

1. Nach der Vorprüfung: Strategien, die nicht belegt sind, im Labor weiterlaufen lassen (Vorwärtsbeleg) oder abschalten?
   Empfehlung: weiterlaufen lassen bis mindestens 25.01.2027, dann Bilanz.
2. Risiko je Trade (heute 100 USD = 1 % je Coin-Konto) — nur relevant für die Darstellung; R-Werte bleiben gleich.
3. Echtgeld: erst nach belegter Historie und mindestens 6 Monaten Labor ohne Widerspruch; nie automatisch.

**Nach dem ersten Lauf (08.10., Abschnitt 6b), Empfehlungen:**
- Zu 1: alle sechs weiterlaufen lassen. S4 bleibt als Gegenprobe; Papierhandel kostet nichts.
- Zu 3: kein Echtgeld (nichts belegt).
- Neu 4: **Vorhaltetest in der Breite?** S1 und S3 unverändert auf weiteren liquiden Binance-Perpetuals ab Listung. Die Auswahl
  folgt einer festen Regel, die vor dem Lauf steht (etwa alle USDT-Perpetuals, die vor dem 01.01.2021 gelistet waren und heute
  noch handeln); die Überlebensverzerrung dieser Auswahl steht im Bericht. Urteil wie Abschnitt 6, Holm über die zwei, DSR über
  alle sechs geprüften Varianten. Das Labor bleibt bei den fünf Hyperliquid-Coins.
  - Warum: Vorwärts im Labor bräuchte S3 bei gleicher Stärke (rund 34 Trades im Jahr, Streuung 2,4 R je Trade) etwa drei bis vier
    Jahre bis t ≈ 1,5 und sechs bis t ≈ 2. Breite ist der einzige schnelle Weg zu mehr Teststärke.
  - Grob geschätzt (gleiche Stärke je Coin wie hier, Korrelation der Coins 0,2–0,4): S3 käme mit 20 Coins auf t ≈ 1,9–2,2, also an
    die Grenze; S1 auf t ≈ 1,5. Ein sicherer Weg zum Beleg ist das nicht.
  - Aufwand: eine Sitzung; `swing.db` wächst um rund 2 Millionen Zeilen.
