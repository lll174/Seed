#!/usr/bin/env python3
"""
Makro-Chart, Signale (U126, Version 2026-09-23.49): statistische Kauf- und Verkaufssignale für jeden Chart mit Referenzlinie.

Je Paar (Reihe gegen Referenzlinie, z. B. Kurs gegen Realized Price) und Zeitraum (1 J, 2 J, 4 J, 8 J, alles):

  Abweichung      y = ln(Reihe ÷ Referenz); angezeigt in % als e^y − 1 (symmetrisch rechnen, verständlich zeigen).
  Median          Median von y im Zeitraum -- die typische Lage („optimaler Median“ des Nutzers), Mittellinie im Chart.
  Rückblick       höchste und tiefste Abweichung, dazu die idealen Wendepunkte (Zickzack mit der halben Spannweite P10–P90
                  des Zeitraums). ERST IM NACHHINEIN BEKANNT -- zeigt, wo ideal gewesen wäre, nicht wann man es wissen konnte.
  Live-Signal     Perzentil von y unter den letzten W Tagen BIS EINSCHLIESSLICH HEUTE (kausal; „alles“: seit Beginn).
                  Kauf bei Perzentil ≤ 10, Verkauf bei ≥ 90 -- feste Ränder, nicht auf die Historie angepasst.
  Trefferbilanz   Rendite 90/180/365 Tage nach dem ersten Tag jeder Signal-EPISODE (Signaltage mit höchstens 30 Tagen Abstand)
                  gegen Zufallstage: je Episode ein Tag aus ±(Horizont + 365) Tagen um den Einstieg, 1000-mal; „belegt“ bei
                  einseitigem p < 0,025 (am Zufallsweg kalibriert: rund 5 % Fehlurteile -- ein Block-Bootstrap über alle
                  Signaltage irrte dort in 26–41 % der Fälle und wurde vor der Auslieferung ersetzt).
  Prognose        „Rückkehr zum Median“: AR(1) der Abweichung um den Median des Zeitraums (Halbwertszeit, Dickey-Fuller-t),
                  Referenzlinie fortgeschrieben (Trend der letzten 365 Tage, Power Law mit den Monatsparametern). 80-%-Band
                  EMPIRISCH aus den eigenen Prognosefehlern der letzten 4 Jahre (das Modellband war zu schmal).
                  Rückblick-Prüfung: für Ursprünge alle 30 Tage dieselbe Rechnung nur mit Daten bis zum Ursprung, dann
                  Abdeckung des Bands (Soll 80 %) und Fehler gegen „die Abweichung bleibt“.
  Nachrechnung    Live gegen Nachrechnung: der archivierte Tagesstand (mk_signal, so wie er an dem Tag zu sehen war) gegen das
                  Perzentil, das die heutige Rechnung für denselben Tag ergibt -- gleich, solange die Quellen alte Werte nicht
                  ändern; sonst ist die Bilanz (gerechnet auf heutigen Daten) nicht ganz die Bilanz dessen, was live zu sehen war.

Reine Rechnung ohne Datenbank: hl_makro ruft alle_signale(D) einmal je Datentag und schreibt den Tagesstand (mk_signal).
"""
from __future__ import annotations

import bisect
import datetime
import json
import math
import sys
import time
import zlib

import numpy as np

FENSTER = (("1j", 365), ("2j", 730), ("4j", 1461), ("8j", 2922), ("alles", 0))
HORIZONTE = (90, 180, 365)
KAUF_PZ, VERKAUF_PZ = 10.0, 90.0
BAND_Z = 1.2815515655446004            # zweiseitig 80 %
DF_KRIT = -2.86                         # Dickey-Fuller mit Konstante, 5 % (asymptotisch); Mittel hier = Median -> ungefähr
PLACEBO_K = 1000
P_BELEGT = 0.025                        # einseitig; am Zufallsweg kalibriert -> rund 5 % Fehlurteile
FEHLURTEILE = (0.032, 0.05)             # 23.56 (U135): Kalibrierung KONZEPT_Makro 9.4 -- Episoden mit lokalem Placebo 3,2 %
                                        # (5 von 158), Ära-Nulltest 5 % (4 von 80): so viele Tests sind ohne Zusammenhang „belegt“
MIN_EPISODEN = 3
MIN_N = 292                             # 80 % eines Jahres: kürzere Historie gibt kein Perzentil
ZICKZACK_MIN = 0.05                     # kleinste Wende im Rückblick: 5 % (log)
PRUEF_ABSTAND = 30                      # Ursprünge der Rückblick-Prüfung
REF_TREND_TAGE = 365
EPISODE_LUECKE = 30                     # Signaltage mit höchstens 30 Tagen Abstand = eine Episode
MIN_FEHLER = 20                         # empirisches Band erst ab 20 bekannten Prognosefehlern
FEHLER_JAHRE = 4                        # Fehler der letzten 4 Jahre (Schwankung ändert sich über die Zyklen)
ANZEIGE_PUNKTE = 300                    # Schwellenlinien je Zeitraum ausgedünnt
GENESIS_TAG = 14_247

# Paare: Schlüssel, Tab, Name, Referenzname, Coins, Fenster (None = alle), Referenzart
PAARE = (
    ("rp", "bewertung", "Kurs gegen Realized Price", "Realized Price", "zum Realized Price", ("BTC", "ETH", "ZEC"), None, "trend"),
    ("delta", "bewertung", "Kurs gegen Delta Price", "Delta Price", "zum Delta Price", ("BTC",), None, "trend"),
    ("pl", "trend", "Kurs gegen Power-Law-Fair-Value", "Fair Value (kausal)", "zum Power-Law-Fair-Value", ("BTC",), None, "powerlaw"),
    ("wma", "trend", "Kurs gegen 200-Wochen-MA", "200-Wochen-MA", "zum 200-Wochen-MA", ("BTC", "ETH", "ZEC", "XMR"), None, "trend"),
    ("sth", "kohorten", "Kurs gegen Kurzfrist-Kostenbasis", "Kurzfrist-Kostenbasis", "zur Kurzfrist-Kostenbasis", ("BTC",), None, "trend"),
    ("tmm", "kohorten", "Kurs gegen True Market Mean", "True Market Mean", "zum True Market Mean", ("BTC",), None, "trend"),
    ("lth", "kohorten", "Kurs gegen Langfrist-Kostenbasis", "Langfrist-Kostenbasis", "zur Langfrist-Kostenbasis", ("BTC",), None, "trend"),
    # Miner: fester Gerätetyp über lange Zeit ist kein Maßstab (Effizienz steigt) -> nur bis 4 Jahre
    ("miner", "miner", "Kurs gegen Stromkosten (S21 XP, 7,5 US-ct)", "Stromkosten", "zu den Stromkosten", ("BTC",), ("1j", "2j", "4j"), "trend"),
    ("puell", "miner", "Puell Multiple gegen 1", "1 (Jahresmittel)", "zu 1 (Jahresmittel)", ("BTC",), None, "eins"),
)


# ================================================================================================ Grundbausteine

def _rang(sl: list, v: float) -> float:
    """Perzentil 0..100 eines Werts in einer sortierten Liste (Gleichstände gemittelt; der Wert zählt mit)."""
    n = len(sl)
    lo = bisect.bisect_left(sl, v); hi = bisect.bisect_right(sl, v)
    return 100.0 * (lo + 0.5 * (hi - lo - 1)) / (n - 1)


def _quantil(sl: list, q: float) -> float:
    """Quantil einer sortierten Liste, lineare Interpolation (wie numpy „linear“)."""
    pos = q * (len(sl) - 1)
    i = int(math.floor(pos)); f = pos - i
    return sl[i] if i + 1 >= len(sl) else sl[i] + f * (sl[i + 1] - sl[i])


def rollierend(y: np.ndarray, fenster: int, min_n: int = MIN_N) -> tuple:
    """
    KAUSAL: für jeden Tag i Perzentil von y[i] und die Quantile P10/P50/P90 unter y[i−fenster+1 .. i] (fenster 0 = seit Beginn).
    Tage ohne Wert bleiben leer; weniger als min_n Werte im Fenster -> leer.
    """
    y = np.asarray(y, dtype=float); n = len(y)
    pz, q10, q50, q90 = (np.full(n, np.nan) for _ in range(4))
    sl: list = []
    for i in range(n):
        if fenster and i >= fenster:
            alt = y[i - fenster]
            if math.isfinite(alt):
                del sl[bisect.bisect_left(sl, alt)]
        v = y[i]
        if not math.isfinite(v):
            continue
        bisect.insort(sl, v)
        if len(sl) >= max(2, min_n):
            pz[i] = _rang(sl, v)
            q10[i] = _quantil(sl, 0.10); q50[i] = _quantil(sl, 0.50); q90[i] = _quantil(sl, 0.90)
    return pz, q10, q50, q90


def zickzack(y: np.ndarray, theta: float) -> list:
    """
    Wendepunkte im RÜCKBLICK: ein Tief gilt, sobald danach um mindestens theta (log) gestiegen wurde, ein Hoch, sobald danach um
    theta gefallen wurde; abwechselnd. Der letzte, noch nicht bestätigte Extremwert fehlt (offen). -> [(Index, „kauf“|„verkauf“)]
    """
    idx = [i for i in range(len(y)) if math.isfinite(y[i])]
    if len(idx) < 3 or not (theta > 0):
        return []
    pkt = []
    hi_i = lo_i = idx[0]; richtung = 0
    for i in idx[1:]:
        v = y[i]
        if richtung == 0:
            if v > y[hi_i]:
                hi_i = i
            if v < y[lo_i]:
                lo_i = i
            if y[hi_i] - y[lo_i] >= theta:
                # der erste Extremwert am Rand (erster Tag) ist kein bestätigter Wendepunkt -- was davor lag, ist unbekannt
                if hi_i > lo_i:
                    if lo_i != idx[0]:
                        pkt.append((lo_i, "kauf"))
                    richtung = 1
                else:
                    if hi_i != idx[0]:
                        pkt.append((hi_i, "verkauf"))
                    richtung = -1
        elif richtung == 1:
            if v > y[hi_i]:
                hi_i = i
            elif y[hi_i] - v >= theta:
                pkt.append((hi_i, "verkauf")); richtung = -1; lo_i = i
        else:
            if v < y[lo_i]:
                lo_i = i
            elif v - y[lo_i] >= theta:
                pkt.append((lo_i, "kauf")); richtung = 1; hi_i = i
    return pkt


def _mittel7(y: np.ndarray) -> np.ndarray:
    """ZENTRIERTES 7-Tage-Mittel (± 3 Tage, mindestens 4 Werte) -- nur für die Rückblick-Wendepunkte, die ohnehin erst im
    Nachhinein bekannt sind; zentriert, damit der Punkt nicht um drei Tage hinterherläuft. Das Live-Signal nutzt es nie."""
    y = np.asarray(y, dtype=float); ok = np.isfinite(y); n_ = len(y)
    c = np.concatenate([[0.0], np.cumsum(np.where(ok, y, 0.0))]); k = np.concatenate([[0], np.cumsum(ok)])
    i = np.arange(n_); lo = np.maximum(0, i - 3); hi = np.minimum(n_, i + 4)
    n = k[hi] - k[lo]
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where((n >= 4) & ok, (c[hi] - c[lo]) / np.maximum(n, 1), np.nan)


def _laeufe(maske: np.ndarray, luecke: int = 1) -> list:
    """Zusammenhängende Läufe einer Maske (Lücken bis luecke Tage zählen mit) -> [(a, b)] als Indizes."""
    w = np.nonzero(maske)[0]
    if not len(w):
        return []
    out = []; a = b = int(w[0])
    for i in w[1:]:
        i = int(i)
        if i - b <= luecke:
            b = i
        else:
            out.append((a, b)); a = b = i
    out.append((a, b))
    return out


# ================================================================================================ Trefferbilanz

def bilanz(pz: np.ndarray, preis: np.ndarray, h: int, k_placebo: int = PLACEBO_K, seed: int = 0) -> dict | None:
    """
    Trefferbilanz je Seite über EPISODEN: Signaltage (Kauf: Perzentil ≤ 10, Verkauf: ≥ 90) mit höchstens 30 Tagen Abstand sind eine
    Episode; Einstieg = erster Signaltag. Kennzahl: Rendite h Tage nach dem Einstieg (geometrisches Mittel über die Episoden).
    Nullverteilung (Placebo): je Episode ein Zufallstag in ±(h + 365) Tagen um den Einstieg (gleiche Ära, gleiche Zahl), 1000-mal;
    p einseitig in Richtung der Seite. „belegt“ bei p < 0,025 -- am Zufallsweg kalibriert (300 Tests je Horizont: 4–6 % statt 5 %).
    Warum nicht alle Signaltage: Läufe, in denen der Kurs weiter fällt, werden länger und zählen mit mehr Tagen -- im Zufallsweg
    entsteht so ein Scheineffekt; das Intervall eines Block-Bootstraps auf Signaltagen schloss die 0 in 26–41 % statt 10 % aus.
    """
    pz = np.asarray(pz, dtype=float); preis = np.asarray(preis, dtype=float); n = len(preis)
    if n <= h + 10:
        return None
    r = np.full(n, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        r[: n - h] = np.log(preis[h:] / preis[: n - h])
    ok = np.isfinite(r) & np.isfinite(pz)
    if ok.sum() < 2 * h:
        return None
    okw = np.nonzero(ok)[0]
    m_all = float(np.mean(r[ok]))
    out = {"h": h, "tage": int(ok.sum()), "alle": float(math.expm1(m_all)), "treffer_alle": float(np.mean(r[ok] > 0))}
    rng = np.random.default_rng(seed)
    nb = h + 365
    for seite in ("kauf", "verkauf"):
        mk = np.isfinite(pz) & ((pz <= KAUF_PZ) if seite == "kauf" else (pz >= VERKAUF_PZ))
        starts = [a for a, _b in _laeufe(mk, EPISODE_LUECKE) if ok[a]]
        tage_sig = int((mk & ok).sum())
        if len(starts) < MIN_EPISODEN:
            out[seite] = {"n": tage_sig, "episoden": len(starts), "zu_wenig": True}
            continue
        ein = np.array([r[a] for a in starts])
        stat = float(np.mean(ein))
        lo_i = np.searchsorted(okw, np.array(starts) - nb)
        hi_i = np.searchsorted(okw, np.array(starts) + nb, side="right")
        wahl = lo_i[None, :] + (rng.random((k_placebo, len(starts))) * (hi_i - lo_i)[None, :]).astype(int)
        pl = r[okw[np.minimum(wahl, len(okw) - 1)]].mean(axis=1)
        p = float(np.mean(pl >= stat)) if seite == "kauf" else float(np.mean(pl <= stat))
        b_lo, b_hi = (float(math.expm1(v)) for v in np.percentile(pl, [2.5, 97.5]))
        out[seite] = {"n": tage_sig, "episoden": len(starts), "mittel": float(math.expm1(stat)), "vorteil": float(math.exp(stat) - math.exp(m_all)),
                      "zufall_lo": b_lo, "zufall_hi": b_hi, "zufall_mittel": float(math.expm1(float(np.mean(pl)))), "p": p,
                      "belegt": bool(p < P_BELEGT), "treffer": float(np.mean(ein > 0)),
                      "einstiege": [int(a) for a in starts[-12:]]}
    return out


# ================================================================================================ Prognose: Rückkehr zum Median

def ar1(x: np.ndarray) -> dict | None:
    """AR(1) ohne Achsenabschnitt auf x = y − Median: x[t+1] = φ·x[t] + e. Paare nur über aufeinanderfolgende Tage mit Wert."""
    x = np.asarray(x, dtype=float)
    a, b = x[:-1], x[1:]
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 60:
        return None
    sxx = float(np.dot(a, a))
    if sxx <= 0:
        return None
    phi = float(np.dot(a, b) / sxx)
    res = b - phi * a
    sigma = float(math.sqrt(np.dot(res, res) / max(1, len(a) - 1)))
    se = sigma / math.sqrt(sxx)
    return {"phi": phi, "sigma": sigma, "se": se, "t_df": (phi - 1) / se if se > 0 else float("nan"), "n": int(len(a))}


def y_prognose(y0: float, mu: float, phi: float, sigma: float, h: int) -> tuple:
    """Erwartung und Streuung von y nach h Tagen; φ ≥ 1: keine Rückkehr (Zufallsweg)."""
    if phi < 1:
        m = mu + phi ** h * (y0 - mu)
        var = sigma ** 2 * (1 - phi ** (2 * h)) / (1 - phi ** 2)
    else:
        m = y0; var = sigma ** 2 * h
    return m, math.sqrt(max(var, 0.0))


def halbwertszeit(phi: float) -> float:
    return math.log(0.5) / math.log(phi) if 0 < phi < 1 else float("inf")


def _ref_steigung(ref: np.ndarray, o: int, tage: int = REF_TREND_TAGE) -> float:
    """Trend der Referenzlinie: Steigung von ln(ref) je Tag über die letzten `tage` Tage bis o (nur Vergangenheit)."""
    seg = ref[max(0, o - tage + 1): o + 1]
    t = np.arange(len(seg), dtype=float)
    ok = np.isfinite(seg) & (seg > 0)
    if ok.sum() < 60:
        return 0.0
    with np.errstate(invalid="ignore", divide="ignore"):
        return float(np.polyfit(t[ok], np.log(seg[ok]), 1)[0])


class Referenz:
    """Fortschreibung der Referenzlinie ab Ursprung o (nur Daten bis o): Trend, Power Law (Monatsparameter) oder konstant 1."""

    def __init__(self, art: str, ref: np.ndarray | None, d0: int, pl_param: list | None = None):
        self.art, self.ref, self.d0 = art, ref, d0
        self.pl = sorted(pl_param or [], key=lambda p: p["monat"])
        self.pl_monate = [p["monat"] for p in self.pl]

    def wert(self, o: int) -> float:
        if self.art == "eins":
            return 1.0
        if self.art == "powerlaw":
            return self.pl_wert(o, 0)
        v = self.ref[o] if 0 <= o < len(self.ref) else float("nan")
        return float(v)

    def pl_wert(self, o: int, h: int) -> float:
        tag = self.d0 + o
        monat = time.strftime("%Y-%m", time.gmtime(tag * 86400))
        k = bisect.bisect_right(self.pl_monate, monat) - 1
        if k < 0:
            return float("nan")
        p = self.pl[k]
        return 10 ** (p["a"] + p["b"] * math.log10(max(tag + h - GENESIS_TAG, 1)))

    def prognose(self, o: int, h: int) -> float:
        if self.art == "eins":
            return 1.0
        if self.art == "powerlaw":
            return self.pl_wert(o, h)
        r0 = self.wert(o)
        if not (math.isfinite(r0) and r0 > 0):
            return float("nan")
        return r0 * math.exp(_ref_steigung(self.ref, o) * h)


def _fenster_daten(y: np.ndarray, o: int, w: int) -> np.ndarray:
    return y[max(0, o - w + 1): o + 1] if w else y[: o + 1]


def _fehler_bekannt(R: list, bis: int, h: int) -> list:
    """Prognosefehler, deren Ziel am Tag `bis` schon bekannt war, aus den Ursprüngen der letzten 4 Jahre davor. Eine Regel für die
    Rückblick-Prüfung (bis = Ursprung) und das heutige Band (bis = heute): die Schwankung von BTC sinkt seit 2011 -- Fehler aller
    Jahre machten das Band zu breit (auf echten Daten deckte es bis 97 % statt 80 %)."""
    return [e for (o2, z2, e, _s, _n) in R if z2 <= bis and o2 >= bis - h - FEHLER_JAHRE * 365]


def pruefung(y: np.ndarray, wert: np.ndarray, refx: Referenz, T: int, w: int, abstand: int = PRUEF_ABSTAND) -> dict:
    """
    Rückblick-Prüfung: Ursprünge o alle `abstand` Tage, an jedem NUR Daten bis o (Median, AR(1), Referenztrend); Ziel o+h.
    Fehler e = ln(Wert am Ziel) − ln(Prognose) -- inklusive Fortschreibung der Referenzlinie.
      abdeckung_modell  Anteil im AR(1)-Band (80 %; zu schmal, wenn das Modell nicht stimmt)
      abdeckung         Anteil im EMPIRISCHEN Band: 10.–90. Perzentil der Fehler früherer Ursprünge, deren Ziel bei o schon bekannt
                        war (mindestens 20) -- ehrlich außerhalb der Stichprobe, Soll 80 %
      vs_naiv           Median |e| ÷ Median |e| der Annahme „die Abweichung bleibt“ − 1 (negativ = besser)
      f_lo, f_hi        10./90. Perzentil aller bekannten Fehler -> Band der heutigen Prognose
    """
    fin = np.nonzero(np.isfinite(y))[0]
    out = {str(h): {"n": 0} for h in HORIZONTE}
    if not len(fin):
        return out
    start = int(fin[0]) + (w if w else 365)
    rec: dict = {h: [] for h in HORIZONTE}
    for o in range(start, T - min(HORIZONTE) + 1, abstand):
        if not math.isfinite(y[o]):
            continue
        win = _fenster_daten(y, o, w)
        finw = win[np.isfinite(win)]
        if len(finw) < MIN_N:
            continue
        mu = float(np.median(finw))
        f = ar1(win - mu)
        if not f:
            continue
        phi = min(f["phi"], 1.0)
        for h in HORIZONTE:
            if o + h > T or not (math.isfinite(wert[o + h]) and wert[o + h] > 0):
                continue
            r = refx.prognose(o, h)
            if not (math.isfinite(r) and r > 0):
                continue
            m, sd = y_prognose(float(y[o]), mu, phi, f["sigma"], h)
            ist = math.log(wert[o + h]); soll = math.log(r) + m
            rec[h].append((o, o + h, ist - soll, sd, abs(ist - (math.log(r) + float(y[o])))))
    for h in HORIZONTE:
        R = rec[h]
        if not R:
            continue
        mod = [abs(e) <= BAND_Z * sd for (_o, _z, e, sd, _n) in R]
        emp = []
        for i, (o, _z, e, _sd, _n) in enumerate(R):
            frueher = _fehler_bekannt(R[:i], o, h)                        # nur, was am Ursprung schon bekannt war
            if len(frueher) >= MIN_FEHLER:
                lo, hi = np.quantile(frueher, [0.1, 0.9])
                emp.append(lo <= e <= hi)
        jung = _fehler_bekannt(R, T, h)
        fehler = np.array(jung if len(jung) >= MIN_FEHLER else [e for (_o, _z, e, _s, _n) in R])
        mn = float(np.median([nf for (*_x, nf) in R]))
        out[str(h)] = {"n": len(R), "abdeckung_modell": float(np.mean(mod)), "abdeckung": float(np.mean(emp)) if len(emp) >= MIN_FEHLER else None,
                       "n_emp": len(emp), "vs_naiv": float(np.median(np.abs(fehler)) / mn - 1) if mn > 0 else None,
                       "f_lo": float(np.quantile(fehler, 0.1)) if len(fehler) >= MIN_FEHLER else None,
                       "f_hi": float(np.quantile(fehler, 0.9)) if len(fehler) >= MIN_FEHLER else None, "f_n": int(len(fehler))}
    return out


def prognose(y: np.ndarray, refx: Referenz, T: int, w: int, pruef: dict | None = None) -> dict | None:
    """
    Prognose ab dem letzten Tag T mit dem Zeitraum w (0 = seit Beginn): Erwartung = Rückkehr zum Median nach AR(1); Band 80 %
    EMPIRISCH aus den eigenen Prognosefehlern im Rückblick (pruefung), sonst aus dem Modell.
    """
    win = _fenster_daten(y, T, w)
    fin = win[np.isfinite(win)]
    if len(fin) < MIN_N or not math.isfinite(y[T]):
        return None
    mu = float(np.median(fin))
    f = ar1(win - mu)
    if not f:
        return None
    phi = min(f["phi"], 1.0)
    hl = halbwertszeit(phi)
    hl_lo = halbwertszeit(f["phi"] - 1.6449 * f["se"]) if f["phi"] - 1.6449 * f["se"] > 0 else 0.0
    hl_hi = halbwertszeit(f["phi"] + 1.6449 * f["se"])
    aus = {"mu": mu, "phi": f["phi"], "sigma": f["sigma"], "t_df": f["t_df"], "belegt": bool(f["t_df"] < DF_KRIT), "n": f["n"],
           "halbwert": hl, "halbwert_lo": hl_lo, "halbwert_hi": hl_hi, "h": []}
    for h in HORIZONTE:
        m, sd = y_prognose(float(y[T]), mu, phi, f["sigma"], h)
        pr = (pruef or {}).get(str(h)) or {}
        if pr.get("f_lo") is not None and pr.get("f_hi") is not None:
            lo, hi, art = m + pr["f_lo"], m + pr["f_hi"], "empirisch"
        else:
            lo, hi, art = m - BAND_Z * sd, m + BAND_Z * sd, "modell"
        r = refx.prognose(T, h)
        gut = math.isfinite(r) and r > 0
        aus["h"].append({"tage": h, "y": m, "lo": lo, "hi": hi, "band": art, "ref": r if gut else None,
                         "wert": r * math.exp(m) if gut else None, "wert_lo": r * math.exp(lo) if gut else None,
                         "wert_hi": r * math.exp(hi) if gut else None})
    return aus


# ================================================================================================ je Paar und Zeitraum

def _r(a: np.ndarray, d0: int, sig: int = 4) -> dict | None:
    a = np.asarray(a, dtype=float); g = np.nonzero(np.isfinite(a))[0]
    if not len(g):
        return None
    i0, i1 = int(g[0]), int(g[-1]) + 1
    return {"t0": int(d0 + i0), "v": [None if not math.isfinite(v) else float(f"{v:.{sig}g}") for v in a[i0:i1]]}


def _f(x, nk: int = 5):
    if x is None:
        return None
    x = float(x)
    return round(x, nk) if math.isfinite(x) else None


def paar_signal(y: np.ndarray, wert: np.ndarray, preis: np.ndarray, refx: Referenz, d0: int, fenster: tuple, schluessel: str,
                pz_aus: dict | None = None) -> dict | None:
    """Alle Zeiträume eines Paars. y, wert, preis auf derselben Tagesachse ab d0. wert = Reihe im Hauptchart (Kurs bzw. Puell).
    pz_aus: bekommt je Zeitraum die ganze Perzentil-Reihe (für die Nachrechnung; nie in der Nutzlast)."""
    y = np.asarray(y, dtype=float)
    fin = np.nonzero(np.isfinite(y))[0]
    if len(fin) < MIN_N:
        return None
    T = int(fin[-1])
    erste = int(fin[0])
    aus = {"tag": int(d0 + T), "erster": int(d0 + erste), "fenster": {}}
    for name, w in FENSTER:
        if fenster and name not in fenster:
            continue
        if w and (T - erste + 1) < w * 0.9:                              # Historie kürzer als der Zeitraum
            continue
        pz, q10, q50, q90 = rollierend(y, w, MIN_N if w == 0 or w >= 365 else max(30, int(w * 0.8)))
        if pz_aus is not None:
            pz_aus[name] = pz
        a = max(erste, T - w + 1) if w else erste
        wy = y[a: T + 1]
        wfin = wy[np.isfinite(wy)]
        if len(wfin) < MIN_N:
            continue
        med = float(np.median(wfin))
        i_max = a + int(np.nanargmax(wy)); i_min = a + int(np.nanargmin(wy))
        # Rückblick-Wendepunkte auf dem zentrierten 7-Tage-Mittel: tägliches Rauschen (Puell: Gebühren und Kurs je Tag) ergab sonst
        # 26 „ideale“ Punkte in 4 Jahren; ein Punkt liegt auf dem Tag des geglätteten Extrems
        glatt = _mittel7(wy)
        gfin = glatt[np.isfinite(glatt)]
        theta = max(ZICKZACK_MIN, (float(np.quantile(gfin, 0.9)) - float(np.quantile(gfin, 0.1))) / 2)
        punkte = [{"tag": int(d0 + a + i), "y": _f(y[a + i]), "wert": _f(wert[a + i], 6) if math.isfinite(wert[a + i]) else None, "art": art}
                  for i, art in zickzack(glatt, theta) if math.isfinite(y[a + i])]
        # Schwellen (kausal) im Anzeigebereich, ausgedünnt
        k = max(1, int(math.ceil((T + 1 - a) / ANZEIGE_PUNKTE)))
        sel = np.arange(T, a - 1, -k)[::-1]                              # gleichmäßig, endet genau heute: Tag i = t0 + i·k
        kauf_m = np.isfinite(pz) & (pz <= KAUF_PZ); verk_m = np.isfinite(pz) & (pz >= VERKAUF_PZ)
        laeufe = []
        for art, mk in (("kauf", kauf_m), ("verkauf", verk_m)):
            for x0, x1 in _laeufe(mk[a: T + 1], 3):
                laeufe.append({"a": int(d0 + a + x0), "b": int(d0 + a + x1), "art": art})
        laeufe.sort(key=lambda z: z["a"])
        sig = "kauf" if kauf_m[T] else ("verkauf" if verk_m[T] else None)
        seit = None
        if sig:
            mk = kauf_m if sig == "kauf" else verk_m
            j = T
            while j > 0 and mk[j - 1]:
                j -= 1
            seit = int(d0 + j)
        bil = {}
        tests = belegt = 0
        for h in HORIZONTE:
            b = bilanz(pz, preis, h, seed=zlib.crc32(f"{schluessel}|{name}|{h}".encode()))
            if b is None:
                continue
            for s_ in ("kauf", "verkauf"):
                if isinstance(b.get(s_), dict) and not b[s_].get("zu_wenig"):
                    tests += 1; belegt += int(b[s_]["belegt"])
            for s_ in ("kauf", "verkauf"):
                if isinstance(b.get(s_), dict) and "einstiege" in b[s_]:
                    b[s_]["einstiege"] = [int(d0 + i) for i in b[s_]["einstiege"]]
            bil[str(h)] = _rund(b)
        pr_ = pruefung(y, wert, refx, T, w)
        prog = prognose(y, refx, T, w, pr_)
        if prog:
            prog["pruefung"] = pr_
            prog = _rund(prog)
        aus["fenster"][name] = {
            "w": w, "von": int(d0 + a), "median": _f(med), "theta": _f(theta),
            "max": {"tag": int(d0 + i_max), "y": _f(y[i_max])}, "min": {"tag": int(d0 + i_min), "y": _f(y[i_min])},
            "jetzt": {"tag": int(d0 + T), "y": _f(y[T]), "pz": _f(pz[T], 2)},
            "grenzen": {"kauf": _f(q10[T]), "verkauf": _f(q90[T])},
            "signal": sig, "seit": seit, "laeufe": laeufe[-60:], "punkte": punkte[-60:],
            "schwelle": {"t0": int(d0 + sel[0]), "k": k, "kauf": [_f(q10[i], 4) for i in sel], "verkauf": [_f(q90[i], 4) for i in sel]},
            "bilanz": bil, "tests": tests, "belegt": belegt, "prognose": prog,
        }
    return aus if aus["fenster"] else None


def _rund(o):
    if isinstance(o, dict):
        return {k: _rund(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_rund(v) for v in o]
    if isinstance(o, bool) or o is None or isinstance(o, (int, str)):
        return o
    if isinstance(o, (float, np.floating)):
        x = float(o)
        if not math.isfinite(x):
            return None
        return float(f"{x:.6g}")
    return o


# ================================================================================================ alle Paare aus D (hl_makro.ableiten)

def paare_aus(D: dict) -> list:
    """Reihen je Paar aus dem abgeleiteten Datensatz von hl_makro: (Schlüssel, Coin, d0, y, Wert, Preis, Referenz, Fenster, Kopf)."""
    out = []
    if not D or not D.get("ok"):
        return out
    d0 = D["d0"]; P = np.asarray(D["P"], dtype=float)
    kopf = {k: (tab, name, ref_name, ref_zu, fen) for k, tab, name, ref_name, ref_zu, _c, fen, _a in PAARE}

    def neu(key, coin, dd0, ratio, preis, wert, ref, art, pl=None):
        tab, name, ref_name, ref_zu, fen = kopf[key]
        with np.errstate(invalid="ignore", divide="ignore"):
            y = np.where(np.isfinite(ratio) & (ratio > 0), np.log(np.where(ratio > 0, ratio, 1.0)), np.nan)
        out.append({"key": key, "coin": coin, "tab": tab, "name": name, "ref_name": ref_name, "ref_zu": ref_zu, "d0": dd0, "y": y,
                    "wert": np.asarray(wert, dtype=float), "preis": np.asarray(preis, dtype=float),
                    "ref": Referenz(art, None if ref is None else np.asarray(ref, dtype=float), dd0, pl), "fenster": fen})

    with np.errstate(invalid="ignore", divide="ignore"):
        neu("rp", "BTC", d0, np.asarray(D["MVRV"], dtype=float), P, P, D["RP"], "trend")
        dp = np.asarray(D["DELTA"], dtype=float)
        neu("delta", "BTC", d0, np.where(dp > 0, P / dp, np.nan), P, P, np.where(dp > 0, dp, np.nan), "trend")
        pl = D.get("PL") or {}
        if pl.get("fv_kausal") is not None:
            fvk = np.asarray(pl["fv_kausal"], dtype=float)
            neu("pl", "BTC", d0, P / fvk, P, P, fvk, "powerlaw", pl.get("parameter"))
        neu("wma", "BTC", d0, P / np.asarray(D["WMA"], dtype=float), P, P, D["WMA"], "trend")
        for key, ep in (("sth", "sth-realized-price"), ("tmm", "true-market-mean"), ("lth", "lth-realized-price")):
            lin = np.asarray((D.get("BGM") or {}).get(ep, np.full(len(P), np.nan)), dtype=float)
            neu(key, "BTC", d0, P / lin, P, P, lin, "trend")
        kosten = 13.5 * 7.5 / 100 * np.asarray(D["MINER_E"], dtype=float)
        neu("miner", "BTC", d0, P / kosten, P, P, kosten, "trend")
        pu = np.asarray(D["PUELL"], dtype=float)
        neu("puell", "BTC", d0, pu, P, pu, None, "eins")
        for c, e in (D.get("COINS") or {}).items():
            cp = np.asarray(e["P"], dtype=float)
            if "MVRV" in e and c in ("ETH", "ZEC"):
                neu("rp", c, e["d0"], np.asarray(e["MVRV"], dtype=float), cp, cp, e["RP"], "trend")
            neu("wma", c, e["d0"], cp / np.asarray(e["WMA"], dtype=float), cp, cp, e["WMA"], "trend")
    return out


def alle_signale(D: dict) -> dict:
    """Alle Paare und Zeiträume -> {"tag": letzter Datentag, "paare": {"rp:BTC": Block, ...}, "dauer_s": …}."""
    t0 = time.time()
    paare = {}; pzr = {}
    for p in paare_aus(D):
        pz_ = {}
        b = paar_signal(p["y"], p["wert"], p["preis"], p["ref"], p["d0"], p["fenster"], f"{p['key']}:{p['coin']}", pz_)
        if b is None:
            continue
        miner_lang = p["key"] == "miner"
        b.update(key=p["key"], coin=p["coin"], tab=p["tab"], name=p["name"], ref_name=p["ref_name"], ref_zu=p["ref_zu"],
                 q=_r(np.exp(p["y"][-1500:]) if miner_lang else np.exp(p["y"]), p["d0"] + (max(0, len(p["y"]) - 1500) if miner_lang else 0)))
        paare[f"{p['key']}:{p['coin']}"] = b
        pzr[f"{p['key']}:{p['coin']}"] = {"d0": int(p["d0"]), "fenster": {k: v for k, v in pz_.items() if k in b["fenster"]}}
    tag = max([b["tag"] for b in paare.values()] or [0])
    # "_pz": ganze Perzentil-Reihen je Paar und Zeitraum (numpy) -- nur für nachrechnung(); bloecke() und tagesstand() lesen "paare"
    return {"tag": tag, "paare": paare, "dauer_s": round(time.time() - t0, 2), "kauf_pz": KAUF_PZ, "verkauf_pz": VERKAUF_PZ,
            "horizonte": list(HORIZONTE), "band": 0.8, "_pz": pzr}


def bloecke(S: dict | None, tab: str, coin: str) -> list:
    """Signal-Blöcke für einen Tab (Bewertung und Trend je Coin, sonst BTC)."""
    if not S:
        return []
    c = coin if tab in ("bewertung", "trend") else "BTC"
    return [b for k, b in S.get("paare", {}).items() if b.get("tab") == tab and b.get("coin") == c]


def tagesstand(S: dict) -> list:
    """Zeilen für mk_signal: (tag, paar, fenster, signal, pz, abweichung %, median %, Prognose 365 T Wert)."""
    z = []
    for key, b in (S or {}).get("paare", {}).items():
        for name, f in b["fenster"].items():
            p = f.get("prognose") or {}
            h365 = [h for h in p.get("h", []) if h["tage"] == 365]
            z.append((time.strftime("%Y-%m-%d", time.gmtime(b["tag"] * 86400)), key, name, f["signal"] or "", f["jetzt"]["pz"],
                      math.expm1(f["jetzt"]["y"]) if f["jetzt"]["y"] is not None else None,
                      math.expm1(f["median"]) if f["median"] is not None else None,
                      h365[0]["wert"] if h365 else None))
    return z


def _tag_nr(tag: str) -> int:
    """'JJJJ-MM-TT' (UTC, wie in mk_signal) -> Tage seit 1970."""
    return (datetime.date.fromisoformat(str(tag)) - datetime.date(1970, 1, 1)).days


def nachrechnung(S: dict | None, zeilen: list, toleranz: float = 0.01) -> dict | None:
    """
    LIVE GEGEN NACHRECHNUNG. zeilen = [(Tag, Paar, Zeitraum, Signal, Perzentil)] aus mk_signal -- so wie das Dashboard sie an DEM
    Tag zeigte (einmal je Tag geschrieben, nie überschrieben). Je Zeile das Perzentil, das die heutige Rechnung S für denselben
    Tag ergibt. Gleich (± toleranz, das Archiv rundet auf 0,01), solange die Quellen alte Werte nicht ändern und die Kette kausal
    ist; abweichend = Datenrevision der Quelle (oder ein Blick nach vorn). Zeilen des heutigen Stands zählen nicht (trivial gleich).
    """
    if not S:
        return None
    P = S.get("_pz") or {}
    paare = S.get("paare") or {}
    n = gleich = sig_gleich = fehlt = heute = 0
    abw: list = []; tage: set = set(); schlimm: list = []
    for tag, paar, fen, sig, pz in zeilen:
        try:
            t = _tag_nr(tag)
        except (TypeError, ValueError):
            fehlt += 1
            continue
        if paar in paare and t >= paare[paar]["tag"]:
            heute += 1
            continue
        e = P.get(paar)
        arr = ((e or {}).get("fenster") or {}).get(fen)
        i = t - e["d0"] if e else -1
        if arr is None or pz is None or not (0 <= i < len(arr)) or not math.isfinite(float(arr[i])):
            fehlt += 1
            continue
        neu = float(arr[i]); d = abs(neu - float(pz))
        neu_sig = "kauf" if neu <= KAUF_PZ else ("verkauf" if neu >= VERKAUF_PZ else "")
        n += 1; tage.add(t); abw.append(d)
        gleich += int(d <= toleranz); sig_gleich += int(neu_sig == (sig or ""))
        if d > toleranz or neu_sig != (sig or ""):
            schlimm.append((d, str(tag), paar, fen, float(pz), round(neu, 2), sig or "", neu_sig))
    schlimm.sort(key=lambda z: -z[0])
    return {"n": n, "tage": len(tage), "gleich": gleich, "signal_gleich": sig_gleich, "fehlt": fehlt, "heute": heute, "toleranz": toleranz,
            "max": round(max(abw), 4) if abw else None, "median": round(float(np.median(abw)), 4) if abw else None,
            "paare_abweichend": sorted({z[2] for z in schlimm}),
            "beispiele": [{"tag": z[1], "paar": z[2], "fenster": z[3], "archiv": z[4], "neu": z[5], "signal_archiv": z[6], "signal_neu": z[7]}
                          for z in schlimm[:5]]}


# ================================================================================================ Selbsttest

def _ou(n: int, phi: float, sigma: float, seed: int, start: float = 0.0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    e = rng.normal(0, sigma, n); x = np.empty(n); x[0] = start
    for i in range(1, n):
        x[i] = phi * x[i - 1] + e[i]
    return x


def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    rng = np.random.default_rng(7)
    # 1) rollierend = Brute Force, mit Lücken; kausal
    y = rng.normal(0, 1, 900); y[rng.integers(0, 900, 60)] = np.nan; y[100:105] = 0.25
    pz, q10, q50, q90 = rollierend(y, 200, 50)
    fehl = 0
    for i in rng.integers(60, 900, 120):
        seg = y[max(0, i - 199): i + 1]; seg = seg[np.isfinite(seg)]
        if not math.isfinite(y[i]) or len(seg) < 50:
            fehl += int(math.isfinite(pz[i])); continue
        s = sorted(seg.tolist())
        lt = sum(1 for z in s if z < y[i]); eq = sum(1 for z in s if z == y[i])     # unabhängig von _rang: Gleichstände gemittelt
        soll = (100.0 * (lt + 0.5 * (eq - 1)) / (len(s) - 1), np.quantile(seg, 0.1), np.quantile(seg, 0.5), np.quantile(seg, 0.9))
        fehl += int(abs(pz[i] - soll[0]) > 1e-9 or abs(q10[i] - soll[1]) > 1e-12 or abs(q50[i] - soll[2]) > 1e-12 or abs(q90[i] - soll[3]) > 1e-12)
    y2 = y.copy(); y2[700:] = y2[700:] * 50
    pz2, q102, _, q902 = rollierend(y2, 200, 50)
    kausal = np.array_equal(np.nan_to_num(pz[:700], nan=-9), np.nan_to_num(pz2[:700], nan=-9)) and np.array_equal(
        np.nan_to_num(q90[:700], nan=-9), np.nan_to_num(q902[:700], nan=-9))
    pza, *_ = rollierend(y, 0, 50)
    exp_ok = all(abs(pza[i] - _rang(sorted(y[: i + 1][np.isfinite(y[: i + 1])].tolist()), y[i])) < 1e-9 for i in (300, 650, 899) if math.isfinite(y[i]))
    exp_ok = exp_ok and _rang([1.0, 2.0, 2.0, 2.0, 3.0], 2.0) == 50.0 and _rang([1.0, 2.0, 3.0], 3.0) == 100.0 and _rang([1.0, 2.0, 3.0], 1.0) == 0.0
    fin_ = np.isfinite(pz)
    k_ant, v_ant = float(np.mean(pz[fin_] <= KAUF_PZ)), float(np.mean(pz[fin_] >= VERKAUF_PZ))
    ok("Perzentil und P10/P50/P90 gleitend = Nachrechnung (Lücken, Gleichstände), kausal, seit Beginn; Signal = unterstes/oberstes Zehntel",
       fehl == 0 and kausal and exp_ok and 0.07 <= k_ant <= 0.13 and 0.07 <= v_ant <= 0.13,
       f"{fehl} Abweichungen in 120 Stichproben; Zukunft × 50 ändert nichts davor; Rauschen: Kauf {k_ant:.1%}, Verkauf {v_ant:.1%} der Tage")
    # 2) Zickzack: Welle mit bekannten Extremen; konstant -> nichts
    t = np.arange(2000); welle = 0.5 * np.sin(2 * np.pi * t / 400)
    pk = zickzack(welle, 0.3)
    soll_h = [100 + 400 * k for k in range(5)]; soll_t = [300 + 400 * k for k in range(5)]
    hoch = [i for i, a in pk if a == "verkauf"]; tief = [i for i, a in pk if a == "kauf"]
    abw = all(any(abs(i - s) <= 1 for s in soll_h) for i in hoch) and all(any(abs(i - s) <= 1 for s in soll_t) for i in tief)
    wechsel = all(pk[i][1] != pk[i + 1][1] for i in range(len(pk) - 1))
    rand = zickzack(welle[: 1820], 0.3)                                   # Tief bei 1900 fehlt: Hoch 1700 erst ab ~1810 bestätigt
    ok("Rückblick-Zickzack: Hochs und Tiefs einer Welle genau getroffen, abwechselnd, Rand und letzter Extremwert offen; konstant -> keine",
       abw and wechsel and len(pk) == 10 and pk[0] == (100, "verkauf") and pk[-1] == (1900, "kauf") and rand[-1] == (1700, "verkauf")
       and zickzack(np.zeros(500), 0.1) == [] and zickzack(welle, 2.0) == [], f"{len(pk)} Wendepunkte, erster {pk[0] if pk else '—'}")
    # 3) Bilanz über Episoden: Positivkontrolle (Rückkehr zum Median) und Nulltest (Zufallsweg, zwei Horizonte)
    n = 3000
    ref = np.exp(0.0004 * np.arange(n))
    x = _ou(n, 0.985, 0.03, 11)
    preis = ref * np.exp(x)
    pz_, *_ = rollierend(x, 365)
    b = bilanz(pz_, preis, 90, seed=1)
    pos = (b and b["kauf"]["vorteil"] > 0.05 and b["verkauf"]["vorteil"] < -0.05 and b["kauf"]["treffer"] > b["treffer_alle"])
    treffer = gesamt = 0                                                  # Trennschärfe: 12 Rückkehr-Märkte, 5000 Tage, Halbwertszeit 34 T
    for s in range(12):
        n5 = 5000; x5 = _ou(n5, 0.98, 0.03, 11 + s); pz5, *_ = rollierend(x5, 365)
        b5 = bilanz(pz5, np.exp(0.0004 * np.arange(n5)) * np.exp(x5), 90, seed=1)
        for s_ in ("kauf", "verkauf"):
            if isinstance(b5.get(s_), dict) and "belegt" in b5[s_]:
                gesamt += 1; treffer += int(b5[s_]["belegt"])
    ok("Bilanz Positivkontrolle: Rückkehr-Märkte -> Kauf und Verkauf über Episoden belegt (mindestens 20 von 24)", pos and gesamt == 24 and treffer >= 20,
       (f"{treffer} von {gesamt} belegt; Beispiel Kauf {b['kauf']['mittel']:+.1%} in 90 T (Zufall {b['kauf']['zufall_lo']:+.1%} … "
        f"{b['kauf']['zufall_hi']:+.1%}, p {b['kauf']['p']:.3f}, {b['kauf']['episoden']} Episoden)") if b and "mittel" in b.get("kauf", {}) else "keine Bilanz")
    null = {}
    for h in (90, 365):
        falsch = anzahl = 0
        for s in range(40):
            xr = np.cumsum(np.random.default_rng(100 + s).normal(0, 0.03, n))
            pzr, *_ = rollierend(xr, 365)
            br = bilanz(pzr, ref * np.exp(xr), h, seed=s)
            for s_ in ("kauf", "verkauf"):
                if br and isinstance(br.get(s_), dict) and not br[s_].get("zu_wenig"):
                    anzahl += 1; falsch += int(br[s_]["belegt"])
        null[h] = (falsch, anzahl)
    f_sum = sum(f for f, _a in null.values()); a_sum = sum(a for _f, a in null.values())
    ok("Bilanz Nulltest: Zufallsweg, 40 Märkte je Horizont -> „belegt“ höchstens 6 % (Soll ≈ 5 %)",
       all(a >= 60 for _f, a in null.values()) and f_sum <= 0.06 * a_sum,
       " · ".join(f"{h} T: {f} von {a}" for h, (f, a) in null.items()) + f" · zusammen {f_sum / max(a_sum, 1):.1%}")
    # Ära-Nulltest: Abweichung und Rendite nur über die Ära verbunden (Niveau springt, Drift wechselt). Zufallstage aus der ganzen
    # Historie würden Signale der späten Ära mit der frühen Ära vergleichen (Scheineffekt in 20–34 % der Tests); lokal nicht
    era_f = era_a = 0
    for s in range(20):
        n_e = 5000; half = n_e // 2; g_ = np.random.default_rng(500 + s)
        y_e = _ou(n_e, 0.98, 0.03, 500 + s) + np.where(np.arange(n_e) < half, -0.5, 0.5)
        p_e = np.exp(np.cumsum(g_.normal(0, 0.03, n_e) + np.where(np.arange(n_e) < half, 0.003, -0.001)))
        pz_e, *_ = rollierend(y_e, 0)
        for h in (90, 365):
            b_e = bilanz(pz_e, p_e, h, seed=s)
            for s_ in ("kauf", "verkauf"):
                if b_e and isinstance(b_e.get(s_), dict) and not b_e[s_].get("zu_wenig"):
                    era_a += 1; era_f += int(b_e[s_]["belegt"])
    ok("Bilanz Nulltest Ära: Niveau und Drift wechseln gemeinsam, sonst kein Zusammenhang -> „belegt“ höchstens 10 % (Zufall lokal)",
       era_a >= 60 and era_f <= 0.10 * era_a, f"{era_f} von {era_a} belegt")
    # 4) Prognose: φ wiedergefunden, Rückkehr belegt; empirisches Band hält 80 % außerhalb der Stichprobe -- auch im Zufallsweg,
    #    wo das Modellband zu schmal ist
    refx = Referenz("trend", ref, 0)
    fit = ar1(x[-1461:] - np.median(x[-1461:]))
    pf = pruefung(x, preis, refx, n - 1, 1461)
    pr = prognose(x, refx, n - 1, 1461, pf)
    abd = pf["90"].get("abdeckung")
    ok("Prognose Positivkontrolle: φ und Halbwertszeit wiedergefunden, Rückkehr belegt, empirisches 80-%-Band trifft 70–90 %, besser als „bleibt“",
       fit and abs(fit["phi"] - 0.985) < 0.01 and pr and pr["belegt"] and 25 < pr["halbwert"] < 90 and abd is not None and 0.70 <= abd <= 0.90
       and pf["90"]["vs_naiv"] < 0 and pr["h"][0]["band"] == "empirisch",
       f"φ {fit['phi']:.4f}, Halbwertszeit {pr['halbwert']:.0f} T, t {pr['t_df']:.1f}, Abdeckung 90 T {abd:.0%}, gegen „bleibt“ {pf['90']['vs_naiv']:+.0%}" if (fit and pr and abd is not None) else "—")
    belegt_rw = 0; emp, vsn = [], []
    for s in range(12):
        xr = np.cumsum(np.random.default_rng(200 + s).normal(0, 0.03, n))
        rx_ = Referenz("trend", ref, 0)
        pf_ = pruefung(xr, ref * np.exp(xr), rx_, n - 1, 1461)
        p_ = prognose(xr, rx_, n - 1, 1461, pf_)
        belegt_rw += int(bool(p_ and p_["belegt"]))
        if pf_["365"].get("vs_naiv") is not None:
            vsn.append(pf_["365"]["vs_naiv"])
        if pf_["90"].get("abdeckung") is not None:
            emp.append(pf_["90"]["abdeckung"])
    m, sd = y_prognose(0.4, 0.1, 0.99, 0.02, 365)
    m1, sd1 = y_prognose(0.4, 0.1, 1.0, 0.02, 100)
    formel = abs(m - (0.1 + 0.99 ** 365 * 0.3)) < 1e-12 and abs(sd - 0.02 * math.sqrt((1 - 0.99 ** 730) / (1 - 0.99 ** 2))) < 1e-12 and m1 == 0.4 and abs(sd1 - 0.2) < 1e-12
    # Im Zufallsweg trägt „Rückkehr zum Median“ nicht -- die Prüfung muss das zeigen (nicht besser als „bleibt“, Band zu oft verfehlt)
    ok("Prognose Nulltest: Zufallsweg -> Rückkehr selten „belegt“ (≤ 3 von 12); Prüfung zeigt: nicht besser als „bleibt“; Formeln exakt",
       belegt_rw <= 3 and formel and len(vsn) == 12 and float(np.mean(vsn)) > -0.05,
       (f"{belegt_rw} von 12 belegt · 365 T gegen „bleibt“ {np.mean(vsn):+.0%}" + (f" · Band 90 T {np.mean(emp):.0%}" if emp else "")) if vsn else f"{belegt_rw} von 12")
    # Ehrlich außerhalb der Stichprobe: wächst die Schwankung, trifft ein Band aus VERGANGENEN Fehlern seltener als 80 % -- ein Band,
    # das auch spätere Fehler kennt, träfe genau 80 % (Selbstbestätigung)
    abd_v = []
    for s in range(12):
        g_ = np.random.default_rng(40 + s); n_v = 3000
        sig_v = 0.015 * (1 + 3 * np.arange(n_v) / n_v); x_v = np.zeros(n_v)
        for i in range(1, n_v):
            x_v[i] = 0.985 * x_v[i - 1] + g_.normal(0, sig_v[i])
        r_v = np.exp(0.0004 * np.arange(n_v))
        a_v = pruefung(x_v, r_v * np.exp(x_v), Referenz("trend", r_v, 0), n_v - 1, 1461)["90"].get("abdeckung")
        if a_v is not None:
            abd_v.append(a_v)
    ok("Prognose-Band ehrlich: wachsende Schwankung -> Band aus vergangenen Fehlern trifft seltener als 80 % (keine Selbstbestätigung)",
       len(abd_v) == 12 and float(np.mean(abd_v)) < 0.76, f"Abdeckung 90 T im Mittel {np.mean(abd_v):.0%} (Soll darunter)" if abd_v else "—")
    # Band folgt der Schwankung der letzten 4 Jahre: fällt sie nach Tag 2000 auf ein Drittel, ist das Band heute so schmal wie bei
    # durchgehend kleiner Schwankung (gleiche Zufallszahlen; die alte Zeit klingt mit φ^k ab)
    n_s = 5500; e_s = np.random.default_rng(77).normal(0, 1, n_s); r_s = np.exp(0.0004 * np.arange(n_s)); breite = []
    for sig_s in (np.where(np.arange(n_s) < 2000, 0.045, 0.015), np.full(n_s, 0.015)):
        x_s = np.zeros(n_s)
        for i in range(1, n_s):
            x_s[i] = 0.985 * x_s[i - 1] + sig_s[i] * e_s[i]
        p_s = pruefung(x_s, r_s * np.exp(x_s), Referenz("trend", r_s, 0), n_s - 1, 1461)["90"]
        breite.append((p_s["f_hi"] - p_s["f_lo"]) if p_s.get("f_lo") is not None else float("nan"))
    ok("Prognose-Band folgt der Schwankung der letzten 4 Jahre: fällt sie auf ein Drittel, ist das Band heute so schmal wie ohne die alte Zeit",
       0.9 <= breite[0] / breite[1] <= 1.1, f"Breite {breite[0]:.3f} gegen {breite[1]:.3f} (log)")
    # 5) Referenz: exponentieller Trend exakt fortgeschrieben, nur aus der Vergangenheit (Knick bei Tag 400: Tag 300 kennt nur 0,001 je
    #    Tag, Tag 799 nur 0,003); Power Law mit Monatsparametern ohne Blick nach vorn
    tt_ = np.arange(800); r_ = np.exp(np.where(tt_ < 400, 0.001 * tt_, 0.4 + 0.003 * (tt_ - 400))); rx = Referenz("trend", r_, 0)
    tr_ok = (abs(rx.prognose(799, 365) / (r_[799] * math.exp(0.003 * 365)) - 1) < 1e-9 and abs(rx.prognose(300, 90) / (r_[300] * math.exp(0.09)) - 1) < 1e-9)
    par = [{"monat": "2020-01", "a": -17.0, "b": 5.8}, {"monat": "2020-02", "a": -16.9, "b": 5.7}]
    plx = Referenz("powerlaw", None, 18262, par)                       # 18262 = 2020-01-01
    pl_ok = (abs(plx.prognose(10, 365) - 10 ** (-17.0 + 5.8 * math.log10(18262 + 10 + 365 - GENESIS_TAG))) < 1e-9
             and abs(plx.prognose(40, 0) - 10 ** (-16.9 + 5.7 * math.log10(18262 + 40 - GENESIS_TAG))) < 1e-9)
    ok("Referenzlinie fortgeschrieben: Trend der letzten 365 Tage exakt, Power Law mit den Parametern des Ursprungsmonats", tr_ok and pl_ok)
    # 6) ganzer Block: JSON ohne NaN, Signal heute konsistent mit Perzentil
    xb = _ou(2200, 0.99, 0.03, 5); xb[-5:] = xb[-5:] - 1.0                  # Ende tief -> Kauf
    blk = paar_signal(xb, np.exp(xb), np.exp(xb + 0.0003 * np.arange(2200)), Referenz("eins", None, 16000), 16000, None, "test:BTC")
    js = json.dumps(blk, allow_nan=False)
    f4 = blk["fenster"]["4j"] if blk else {}
    konsistent = blk and all(f["signal"] == ("kauf" if f["jetzt"]["pz"] <= KAUF_PZ else "verkauf" if f["jetzt"]["pz"] >= VERKAUF_PZ else None)
                             for f in blk["fenster"].values())
    med4 = float(np.median(xb[-1461:]))
    tt_ = np.arange(2200)
    xw = 0.3 * np.sin(2 * np.pi * tt_ / 400) + np.random.default_rng(3).normal(0, 0.15, 2200)    # Welle + starkes Tagesrauschen (wie Puell)
    bw = paar_signal(xw, np.exp(xw), np.exp(xw), Referenz("eins", None, 16000), 16000, ("alles",), "welle:BTC")
    n_pkt = len(bw["fenster"]["alles"]["punkte"]) if bw else -1
    ok("Block je Paar: alle Zeiträume bis zur Historie, JSON ohne NaN, Signal = Perzentil-Regel, Ende tief -> Kauf; Median = Median des "
       "Zeitraums, Prognose zielt darauf; Rückblick trotz Tagesrauschen ohne Scheinwenden",
       blk and set(blk["fenster"]) == {"1j", "2j", "4j", "alles"} and konsistent and f4.get("signal") == "kauf" and f4.get("seit") is not None
       and abs(f4["median"] - med4) < 1e-5 and abs(f4["prognose"]["mu"] - med4) < 1e-5 and 8 <= n_pkt <= 16,
       f"{len(js) // 1024} kB; Median 4 J {med4:+.4f}; Welle mit Rauschen: {n_pkt} Wendepunkte (Soll ≈ 10)")
    # 7) Live gegen Nachrechnung: Tagesstände früherer Tage (nur Daten bis dahin) wie archiviert gegen die heutige Rechnung --
    #    Nulltest gleiche Daten -> alle gleich; Positivkontrolle Revision alter Werte -> erkannt; heutiger Stand zählt nicht
    xs = _ou(1500, 0.99, 0.03, 9); d0s = 19000

    def stand(x, bis):
        pzs: dict = {}
        b_ = paar_signal(x[:bis], np.exp(x[:bis]), np.exp(x[:bis]), Referenz("eins", None, d0s), d0s, ("1j", "alles"), "t:BTC", pzs)
        b_.update(key="t", coin="BTC", tab="x", name="t", ref_name="1", ref_zu="zu 1", q=None)
        return {"tag": b_["tag"], "paare": {"t:BTC": b_}, "_pz": {"t:BTC": {"d0": d0s, "fenster": pzs}}}

    archiv = [z[:5] for bis in (1300, 1400) for z in tagesstand(stand(xs, bis))]
    heute_ = stand(xs, 1500)
    N0 = nachrechnung(heute_, archiv + [z[:5] for z in tagesstand(heute_)] + [("2026-01-01", "zz:BTC", "1j", "", 50.0)])
    xr = xs.copy(); xr[1000:1200] += 0.3                                  # die Quelle ändert alte Werte
    N1 = nachrechnung(stand(xr, 1500), archiv)
    js_n = json.dumps(N1, allow_nan=False)
    ok("Live gegen Nachrechnung: gleiche Daten -> alle gleich (heute zählt nicht); Revision alter Werte -> erkannt mit Beispiel",
       N0 and N0["n"] == 4 and N0["gleich"] == 4 and N0["signal_gleich"] == 4 and N0["heute"] == 2 and N0["fehlt"] == 1 and N0["tage"] == 2
       and N0["max"] <= 0.005 and N1 and N1["n"] == 4 and N1["gleich"] < 4 and N1["beispiele"] and N1["beispiele"][0]["archiv"] != N1["beispiele"][0]["neu"],
       f"gleich {N0['gleich']} von {N0['n']} · nach Revision {N1['gleich']} von {N1['n']}, größte Abweichung {N1['max']:.1f} Pz, {len(js_n)} B"
       if N0 and N1 and N1["max"] is not None else "—")
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<64} {txt.replace('.', ',')}")
    return all(p[1] for p in pruef), pruef


def selbsttest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Makro-Signale (U126) -- Selbsttest: Positivkontrollen, Nulltests, Kausalität, Rückblick, Prognose")
    gut, _ = probe(verbose)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if gut else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return gut


if __name__ == "__main__":
    if "--selbsttest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    print(__doc__)
