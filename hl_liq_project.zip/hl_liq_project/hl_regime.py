#!/usr/bin/env python3
"""
Regime-Modul (U138), Phase 0: Vorprüfung auf der Historie (Version 2026-09-23.60).

Vorab festgelegt in KONZEPT_Regime.md Abschnitt 9.1 und 9.1a (07.10.2026 spät abends, vor jedem Lauf auf echten Daten). Prüft
auf rund drei Jahren 30-min-Kerzen je Coin, welche Bausteine des Regime-Moduls tragen. 23.60 (nach dem ersten echten Lauf
08.10.): K3 vergleicht Sitzung und Rest je Stunde (driftneutral, 9.1a „Nach dem ersten Lauf korrigiert“); dazu nur Anzeigen.

  P0.1  Zwei-Uhren-Profil der Schwankung (R1)        P0.6  Wochenmomentum long/flat (R6, nur BTC und ETH)
  P0.2  Bewegungsgröße über 1-7 Tage (R2, HAR)       P0.7  Fensterkombination 2/4/8 Wochen + Historie
  P0.3  Beine gegen die Zufallsgeometrie (R4)        P0.8  Regime-Analog gegen die bestehende Analog-Suche (R8a)
  P0.4  Beinende-Prognose gegen D/θ (R4a)            P0.9  Bruchmelder (CUSUM) gegen GARCH-Null (R3)
  P0.5  Kalender K1-K3, Stunden, Wochentage, Persistenz (R5)

Nur Bericht. Liest und schreibt ausschließlich die eigene Datei regime.db neben der Hauptdatenbank (Kerzen-Zwischenspeicher,
Quelle je Coin). Berührt weder hl_liq.db (klines30 bleibt, wie sie ist: die Analog-Suche der Prognose liest sie) noch Prognose,
Fusion, v3, Kaskaden, Labor oder Familien. Schreiben nur mit BEGIN IMMEDIATE.

  python3 hl_regime.py --vorpruefung --db <hl_liq.db>   Debug-Bericht „★ Regime: Vorprüfung auf der Historie (U138)“
  python3 hl_regime.py --laden --db <hl_liq.db>         nur Historie laden bzw. ergänzen
  python3 hl_regime.py --selbsttest                     Nullen, Positivkontrollen, Rechenproben (ohne Netz)
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import sys
import time
import urllib.error
import urllib.request
import zlib
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import numpy as np

COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG")
BAR = 1800                              # 30 min
BARS_TAG = 48
TAG = 86400
HIST_TAGE = 1096                        # rund drei Jahre
MIN_TAGE = 456                          # 365 Tage Training + 3 Bewertungsmonate
TRAIN_TAGE = 365
HWZ_SIGMA = 20.0                        # Halbwertszeit der kausalen Tagesschwankung σ̂_Tag (Tage)
C_GITTER = (1.0, 1.25, 1.5, 1.75, 2.0)  # θ = c · σ̂_Tag
C_HAUPT = 1.5
N_SURR = 100                            # Vorzeichen-Surrogate je Coin (P0.3)
ALPHA = 0.05
FAPI = "https://fapi.binance.com"
BYBIT = "https://api.bybit.com"
TZ_NY = "America/New_York"
TZ_BERLIN = "Europe/Berlin"
KOSTEN_WECHSEL = 0.0006                 # P0.6: 0,06 % je Positionswechsel
VERSION_MODUL = "2026-09-23.60"


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    """Zahl mit deutschem Komma; None/NaN -> „—“."""
    if x is None:
        return "—"
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not math.isfinite(xf):
        return "—"
    s = f"{xf:+.{nd}f}" if vz else f"{xf:.{nd}f}"
    return s.replace(".", ",")


def _pz(p) -> str:
    """p-Wert lesbar."""
    if p is None or not math.isfinite(p):
        return "—"
    if p < 0.0001:
        return "< 0,0001"
    return _de(p, 4 if p < 0.01 else 3)


def _datum(ts: int) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(ts)))


# ================================================================================================ Statistik-Bausteine

_ERF_A = (0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429)


def phi(x):
    """Standardnormal-Verteilungsfunktion, vektorisiert (Abramowitz & Stegun 7.1.26, Fehler < 1,5e-7)."""
    x = np.asarray(x, dtype=float)
    z = np.abs(x) / math.sqrt(2.0)
    t = 1.0 / (1.0 + 0.3275911 * z)
    a1, a2, a3, a4, a5 = _ERF_A
    erf = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * np.exp(-z * z)
    return 0.5 * (1.0 + np.sign(x) * erf)


def npdf(x):
    x = np.asarray(x, dtype=float)
    return np.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def phi_s(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def ppf(p: float) -> float:
    """Quantil der Standardnormalverteilung (Acklam), relativer Fehler < 1,2e-9 nach einem Newton-Schritt."""
    if not 0.0 < p < 1.0:
        return float("nan") if p != 0.0 and p != 1.0 else (-math.inf if p == 0.0 else math.inf)
    a = (-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01,
         2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00,
         2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00)
    pl = 0.02425
    if p < pl:
        q = math.sqrt(-2 * math.log(p))
        x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    elif p > 1 - pl:
        q = math.sqrt(-2 * math.log(1 - p))
        x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    else:
        q = p - 0.5; r = q * q
        x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    e = phi_s(x) - p
    u = e * math.sqrt(2 * math.pi) * math.exp(x * x / 2)
    return x - u / (1 + x * u / 2)


def _betacf(a: float, b: float, x: float) -> float:
    """Kettenbruch der unvollständigen Betafunktion (Numerical Recipes 6.4)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
    h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e300
        de = d * c
        h *= de
        if abs(de - 1.0) < 3e-14:
            break
    return h


def betai(a: float, b: float, x: float) -> float:
    """Regularisierte unvollständige Betafunktion I_x(a, b)."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x)
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbt) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbt) * _betacf(b, a, 1.0 - x) / b


def t_p2(t: float, df: float) -> float:
    """Zweiseitiger p-Wert der t-Verteilung."""
    if not math.isfinite(t) or df <= 0:
        return float("nan")
    return betai(df / 2.0, 0.5, df / (df + t * t))


def holm(p: list) -> list:
    """Holm-adjustierte p-Werte (gleiche Reihenfolge, NaN bleibt NaN)."""
    idx = [i for i, v in enumerate(p) if v is not None and math.isfinite(v)]
    m = len(idx)
    adj = [float("nan")] * len(p)
    lauf = 0.0
    for r, i in enumerate(sorted(idx, key=lambda k: p[k])):
        lauf = max(lauf, min(1.0, (m - r) * p[i]))
        adj[i] = lauf
    return adj


def bh(p: list, q: float = 0.10) -> list:
    """Benjamini-Hochberg: True für verworfene Hypothesen (NaN -> False)."""
    idx = [i for i, v in enumerate(p) if v is not None and math.isfinite(v)]
    m = len(idx)
    if not m:
        return [False] * len(p)
    sortiert = sorted(idx, key=lambda k: p[k])
    k_max = 0
    for r, i in enumerate(sortiert, start=1):
        if p[i] <= q * r / m:
            k_max = r
    weg = set(sortiert[:k_max])
    return [i in weg for i in range(len(p))]


def nw_se(x: np.ndarray, lag: int) -> float:
    """Newey-West-Standardfehler des Mittelwerts (Bartlett-Gewichte)."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 3:
        return float("nan")
    e = x - x.mean()
    s = float(np.dot(e, e)) / n
    for k in range(1, min(lag, n - 1) + 1):
        s += 2.0 * (1.0 - k / (lag + 1.0)) * float(np.dot(e[k:], e[:-k])) / n
    return math.sqrt(max(s, 0.0) / n)


def mittel_test(x: np.ndarray, lag: int) -> dict:
    """Mittelwert mit HAC-Fehler, t und zweiseitigem p (t-Verteilung, n − 1 Freiheitsgrade)."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 8:
        return {"n": n, "mittel": float("nan"), "se": float("nan"), "t": float("nan"), "p": float("nan")}
    se = nw_se(x, lag)
    m = float(x.mean())
    t = m / se if se > 0 else float("nan")
    return {"n": n, "mittel": m, "se": se, "t": t, "p": t_p2(t, n - 1)}


def dm_test(d: np.ndarray) -> dict:
    """
    Diebold-Mariano mit Coroneo-Iacone (2020): Langfristvarianz aus dem gewichteten Periodogramm der ersten m = ⌊T^{1/3}⌋
    Fourier-Frequenzen (Daniell-Kern), DM ~ t mit 2m Freiheitsgraden. d = Verlust(Konkurrent) − Verlust(Kandidat):
    positives Mittel heißt, der Kandidat ist besser.
    """
    d = np.asarray(d, dtype=float)
    d = d[np.isfinite(d)]
    T = len(d)
    if T < 8:
        return {"T": T, "mittel": float("nan"), "dm": float("nan"), "df": 0, "p": float("nan"), "se": float("nan")}
    m = max(1, int(T ** (1.0 / 3.0)))
    e = d - d.mean()
    f = np.fft.rfft(e)
    w = float(np.mean(np.abs(f[1:m + 1]) ** 2)) / T
    se = math.sqrt(w / T) if w > 0 else float("nan")
    dm = float(d.mean()) / se if se and se > 0 else float("nan")
    return {"T": T, "mittel": float(d.mean()), "dm": dm, "df": 2 * m, "p": t_p2(dm, 2 * m), "se": se}


def qlike(F: np.ndarray, y: np.ndarray) -> np.ndarray:
    """QLIKE-Verlust y/F − log(y/F) − 1 (0 bei F = y); robust gegen Rauschen im Varianzmaß (Patton 2011)."""
    F = np.asarray(F, dtype=float); y = np.asarray(y, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        q = y / F
        return q - np.log(q) - 1.0


def crps_ens(x: np.ndarray, w: np.ndarray | None, y: float) -> float:
    """CRPS einer gewichteten Stichprobe: Σ w|x − y| − ½ ΣΣ w_i w_j |x_i − x_j| (sortiert, O(n log n))."""
    x = np.asarray(x, dtype=float)
    if w is None:
        w = np.full(len(x), 1.0 / len(x))
    else:
        w = np.asarray(w, dtype=float); w = w / w.sum()
    o = np.argsort(x); xs = x[o]; ws = w[o]
    W = np.cumsum(ws)
    paar = 2.0 * float(np.sum(ws * xs * (2.0 * W - ws - 1.0)))
    return float(np.sum(w * np.abs(x - y))) - 0.5 * paar


def crps_norm(sigma: np.ndarray, y: np.ndarray) -> np.ndarray:
    """CRPS der Normalverteilung N(0, σ²) (Gneiting & Raftery 2007)."""
    sigma = np.asarray(sigma, dtype=float); y = np.asarray(y, dtype=float)
    z = y / sigma
    return sigma * (z * (2.0 * phi(z) - 1.0) + 2.0 * npdf(z) - 1.0 / math.sqrt(math.pi))


def korrelation(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 5:
        return float("nan")
    a = a[ok] - a[ok].mean(); b = b[ok] - b[ok].mean()
    n = math.sqrt(float(np.dot(a, a)) * float(np.dot(b, b)))
    return float(np.dot(a, b) / n) if n > 0 else float("nan")


# ================================================================================================ Datenhaltung (regime.db)

SCHEMA = """
CREATE TABLE IF NOT EXISTS rg_klines (
    coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL,
    PRIMARY KEY (coin, ts)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS rg_meta (k TEXT PRIMARY KEY, v TEXT);
"""


def regime_pfad(db: str) -> str:
    """regime.db liegt neben der Hauptdatenbank (wie makro.db); HL_REGIME_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_REGIME_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "regime.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung: Autocommit, jede Schreibtransaktion mit BEGIN IMMEDIATE (Projektregel)."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM rg_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def meta_setzen(con, k: str, v: str) -> None:
    con.execute("BEGIN IMMEDIATE")
    try:
        con.execute("INSERT OR REPLACE INTO rg_meta VALUES (?,?)", (k, v))
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def kerzen_schreiben(con, coin: str, zeilen: list) -> None:
    if not zeilen:
        return
    con.execute("BEGIN IMMEDIATE")
    try:
        con.executemany("INSERT OR REPLACE INTO rg_klines VALUES (?,?,?,?,?,?,?)", [(coin, *z) for z in zeilen])
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def kerzen(con, coin: str) -> dict | None:
    """Gespeicherte 30-min-Kerzen eines Coins als Arrays (aufsteigend, eindeutig)."""
    rows = con.execute("SELECT ts, o, h, l, c, v FROM rg_klines WHERE coin=? ORDER BY ts", (coin,)).fetchall()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}


class KeinSymbol(Exception):
    pass


_UNERREICHBAR: set = set()               # Quellen, die in diesem Lauf nicht erreichbar waren (nicht für jeden Coin neu warten)


def _http_json(url: str, timeout: float = 25.0):
    """GET mit JSON-Antwort -> (Daten, Kopfzeilen). 400 mit Binance-Code −1121 bzw. leere Bybit-Liste: KeinSymbol. Verbindungsfehler:
    zwei Versuche, Ratenbremse (418/429): vier mit Wartezeit."""
    letzter = None
    verbindung = 0
    for versuch in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "hl-regime/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode()), dict(r.headers)
        except urllib.error.HTTPError as e:
            text = ""
            try:
                text = e.read().decode(errors="replace")
            except Exception:
                pass
            if e.code == 400 and ("-1121" in text or "Invalid symbol" in text):
                raise KeinSymbol(text[:120]) from e
            if e.code == 451:
                raise RuntimeError("Börse sperrt den Zugriff aus dieser Region (451)") from e
            if e.code in (418, 429):
                time.sleep(10 * (versuch + 1)); letzter = e
                continue
            letzter = e
        except Exception as e:                       # Zeitüberschreitung, Verbindung
            letzter = e
            verbindung += 1
            if verbindung >= 2:
                break
        time.sleep(1.0 * (versuch + 1))
    raise RuntimeError(f"Abruf fehlgeschlagen: {str(letzter)[:100]}")


def _binance_kerzen(coin: str, start_ms: int, ende_ms: int) -> tuple:
    """Bis 1000 Kerzen ab start_ms (aufsteigend) -> (Zeilen [(ts, o, h, l, c, v)], benutztes Gewicht)."""
    url = (f"{FAPI}/fapi/v1/klines?symbol={coin}USDT&interval=30m&limit=1000&startTime={int(start_ms)}&endTime={int(ende_ms)}")
    d, kopf = _http_json(url)
    gewicht = int(kopf.get("X-MBX-USED-WEIGHT-1M") or kopf.get("x-mbx-used-weight-1m") or 0)
    return [(int(k[0]) // 1000, float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])) for k in d], gewicht


def _bybit_kerzen(coin: str, start_ms: int, ende_ms: int) -> tuple:
    """Bis 1000 Kerzen in [start_ms, ende_ms] von Bybit (linear), aufsteigend -> (Zeilen, 0)."""
    ende_ms = min(int(ende_ms), int(start_ms) + 1000 * BAR * 1000 - 1)
    url = (f"{BYBIT}/v5/market/kline?category=linear&symbol={coin}USDT&interval=30&start={int(start_ms)}&end={ende_ms}&limit=1000")
    d, _ = _http_json(url)
    if not isinstance(d, dict) or d.get("retCode") != 0:
        raise KeinSymbol(str(d)[:120])
    liste = ((d.get("result") or {}).get("list")) or []
    zeilen = [(int(k[0]) // 1000, float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])) for k in liste]
    return sorted(zeilen), 0


QUELLEN = {"binance": _binance_kerzen, "bybit": _bybit_kerzen}
QUELLE_NAME = {"binance": "Binance-Futures", "bybit": "Bybit"}


def quelle_waehlen(con, coin: str, start_ts: int, log=print, jetzt: int | None = None) -> str | None:
    """
    Beim ersten Laden: die Quelle mit der längeren Historie. Geprüft wird in Jahresschritten ab dem Start, je ein Fenster von 1000
    Kerzen bei Binance-Futures und Bybit; die erste Quelle mit Kerzen im frühesten Fenster gewinnt (Gleichstand: Binance). Danach
    fest (rg_meta), damit eine Reihe nie aus zwei Börsen gemischt wird. Nicht erreichbar heißt: kein Urteil, nächster Lauf prüft neu.
    """
    q = meta(con, f"quelle:{coin}")
    if q:
        return q if q in QUELLEN else None
    jetzt = int(jetzt or time.time())
    unerreichbar = False
    for k in range(4):
        s = start_ts + k * 365 * TAG
        if s > jetzt:
            break
        treffer = []
        for name in ("binance", "bybit"):
            if name in _UNERREICHBAR:
                unerreichbar = True
                continue
            try:
                z, _ = QUELLEN[name](coin, s * 1000, (s + 999 * BAR) * 1000)
                if z:
                    treffer.append(name)
            except KeinSymbol:
                pass
            except RuntimeError as e:
                unerreichbar = True
                _UNERREICHBAR.add(name)
                log(f"  {coin}: {name} nicht erreichbar ({e})")
            time.sleep(0.3)
        if treffer:
            meta_setzen(con, f"quelle:{coin}", treffer[0])
            return treffer[0]
    if not unerreichbar:
        meta_setzen(con, f"quelle:{coin}", "keine")
    return None


def laden(con, coin: str, budget_s: float = 420.0, log=print, jetzt: int | None = None) -> dict:
    """Ergänzt die 30-min-Kerzen eines Coins bis zur letzten abgeschlossenen Kerze (höchstens HIST_TAGE zurück)."""
    jetzt = int(jetzt or time.time())
    start = (jetzt - HIST_TAGE * TAG) // BAR * BAR
    t0 = time.time()
    quelle = quelle_waehlen(con, coin, start, log, jetzt)
    if quelle is None:
        if meta(con, f"quelle:{coin}") == "keine":
            return {"coin": coin, "quelle": None, "neu": 0, "fertig": True}
        return {"coin": coin, "quelle": None, "neu": 0, "fertig": False, "fehler": "keine Quelle erreichbar"}
    if quelle in _UNERREICHBAR:
        return {"coin": coin, "quelle": quelle, "neu": 0, "fertig": False, "fehler": f"{QUELLE_NAME.get(quelle, quelle)} nicht erreichbar"}
    f = QUELLEN[quelle]
    have = con.execute("SELECT MAX(ts) FROM rg_klines WHERE coin=?", (coin,)).fetchone()[0]
    cursor = max(start, (int(have) + BAR) if have else start)
    letzte_zu = (jetzt // BAR) * BAR - BAR            # Eröffnung der letzten abgeschlossenen Kerze
    neu = 0
    while cursor <= letzte_zu:
        if time.time() - t0 > budget_s:
            return {"coin": coin, "quelle": quelle, "neu": neu, "fertig": False}
        try:
            zeilen, gewicht = f(coin, cursor * 1000, (letzte_zu + BAR) * 1000 - 1)
        except RuntimeError as e:
            _UNERREICHBAR.add(quelle)
            return {"coin": coin, "quelle": quelle, "neu": neu, "fertig": False, "fehler": str(e)[:100]}
        zeilen = [z for z in zeilen if z[0] <= letzte_zu and z[0] >= cursor]
        if not zeilen:
            # Lücke (z. B. vor der Listung bei Bybit-Fenstern): ein Fenster weiter
            cursor += 1000 * BAR
            continue
        kerzen_schreiben(con, coin, zeilen)
        neu += len(zeilen)
        cursor = zeilen[-1][0] + BAR
        time.sleep(0.3 if gewicht < 1200 else 30.0)
    return {"coin": coin, "quelle": quelle, "neu": neu, "fertig": True}


# ================================================================================================ Aufbereitung

def vorbereiten(K: dict) -> dict:
    """
    Kerzen -> Rechengrundlage. Renditen r_t = x_t − x_{t−1} (log Schluss); über Lücken (Abstand ≠ 30 min) bleibt r für den
    Kurspfad erhalten, zählt aber nicht für die Schwankung. Tagesreihen lückenlos vom ersten bis zum letzten Tag (fehlende Tage NaN):
    RV (Summe r², auf 48 Bars hochgerechnet, ab 40 gültigen), Tagesschluss (Bar 23:30), Hoch, Tief und σ̂²_Tag kausal (EWMA mit
    Halbwertszeit HWZ_SIGMA über die Tage VOR dem Tag).
    """
    ts = np.asarray(K["ts"], dtype=np.int64)
    c = np.asarray(K["c"], dtype=float); h = np.asarray(K["h"], dtype=float); l = np.asarray(K["l"], dtype=float)
    ok = np.isfinite(c) & (c > 0) & np.isfinite(h) & (h > 0) & np.isfinite(l) & (l > 0)
    ts, c, h, l = ts[ok], c[ok], h[ok], l[ok]
    o = np.argsort(ts, kind="stable"); ts, c, h, l = ts[o], c[o], h[o], l[o]
    eind = np.concatenate([[True], np.diff(ts) > 0]); ts, c, h, l = ts[eind], c[eind], h[eind], l[eind]
    x = np.log(c); lh = np.log(np.maximum(h, c)); ll = np.log(np.minimum(l, c))
    n = len(x)
    r = np.full(n, np.nan); r[1:] = np.diff(x)
    rv_ok = np.zeros(n, dtype=bool); rv_ok[1:] = np.diff(ts) == BAR
    tag_abs = ts // TAG
    tag0 = int(tag_abs[0]) if n else 0
    tag_i = (tag_abs - tag0).astype(np.int64)
    nt = int(tag_i[-1]) + 1 if n else 0
    r2 = np.where(rv_ok, np.nan_to_num(r) ** 2, 0.0)
    summe = np.bincount(tag_i, weights=r2, minlength=nt)
    anz = np.bincount(tag_i, weights=rv_ok.astype(float), minlength=nt)
    with np.errstate(divide="ignore", invalid="ignore"):
        RV = np.where(anz >= 40, summe * BARS_TAG / np.maximum(anz, 1), np.nan)
    xe = np.full(nt, np.nan)
    letzte = (ts % TAG) == TAG - BAR
    xe[tag_i[letzte]] = x[letzte]
    dh = np.full(nt, -np.inf); dl = np.full(nt, np.inf)
    np.maximum.at(dh, tag_i, lh); np.minimum.at(dl, tag_i, ll)
    dh[~np.isfinite(dh)] = np.nan; dl[~np.isfinite(dl)] = np.nan
    s2 = sigma2_kausal(RV)
    return {"ts": ts, "x": x, "lh": lh, "ll": ll, "r": r, "rv_ok": rv_ok, "tag_i": tag_i, "tag0": tag0, "n_tage": nt,
            "RV": RV, "xe": xe, "dh": dh, "dl": dl, "s2": s2, "s2_bar": s2[tag_i] / BARS_TAG if n else np.zeros(0)}


def sigma2_kausal(RV: np.ndarray, hwz: float = HWZ_SIGMA) -> np.ndarray:
    """σ̂²_Tag am Tag d aus den Tagen < d: EWMA (Halbwertszeit hwz) der gültigen Tages-RV; Anlauf mit dem Mittel der ersten Tage."""
    lam = 0.5 ** (1.0 / hwz)
    out = np.full(len(RV), np.nan)
    e = None; anlauf = []
    for d in range(len(RV)):
        out[d] = e if e is not None else (float(np.mean(anlauf)) if len(anlauf) >= 5 else np.nan)
        v = RV[d]
        if np.isfinite(v) and v > 0:
            if e is None:
                anlauf.append(float(v))
                if len(anlauf) >= 10:
                    e = float(np.mean(anlauf))
            else:
                e = lam * e + (1.0 - lam) * float(v)
    return out


def _offsets(ts: np.ndarray, tzname: str) -> np.ndarray:
    """UTC-Versatz (Sekunden) je Zeitstempel; Zeitumstellungen liegen in NY und Berlin auf vollen UTC-Stunden."""
    z = ZoneInfo(tzname)
    stunden = np.unique(np.asarray(ts, dtype=np.int64) // 3600)
    off = {int(hh): int(datetime.fromtimestamp(int(hh) * 3600, timezone.utc).astimezone(z).utcoffset().total_seconds())
           for hh in stunden}
    return np.array([off[int(t) // 3600] for t in ts], dtype=np.int64)


def _monate(ts: np.ndarray) -> np.ndarray:
    """Monatsindex (Jahr·12 + Monat − 1) je Zeitstempel (UTC)."""
    d = np.asarray(ts, dtype=np.int64).astype("datetime64[s]")
    return d.astype("datetime64[M]").astype(np.int64)


def _monatsanfang(m: int) -> int:
    return int(np.datetime64(int(m), "M").astype("datetime64[s]").astype(np.int64))


def bewertungsmonate(P: dict) -> list:
    """Monate (Index, Anfang, Ende) ab dem ersten vollen Monat nach TRAIN_TAGE; Monate mit ≥ 10 Tagen Daten."""
    ts = P["ts"]
    if not len(ts):
        return []
    m_alle = _monate(ts)
    erster = int(_monate(np.array([ts[0] + TRAIN_TAGE * TAG]))[0]) + 1
    out = []
    for m in range(erster, int(m_alle[-1]) + 1):
        a, e = _monatsanfang(m), _monatsanfang(m + 1)
        n = int(np.sum((ts >= a) & (ts < e)))
        if n >= 10 * BARS_TAG:
            out.append((m, a, e))
    return out


# ================================================================================================ P0.1 Zwei-Uhren-Profil (R1)

FUND_VOR = (TAG - BAR, 8 * 3600 - BAR, 16 * 3600 - BAR)          # Bars, die 23:30 / 07:30 / 15:30 UTC öffnen
FUND_NACH = (0, 8 * 3600, 16 * 3600)


def zeitachsen(ts: np.ndarray) -> dict:
    mitte = np.asarray(ts, dtype=np.int64) + BAR // 2
    off_ny = _offsets(ts, TZ_NY)
    ny = mitte + off_ny
    return {"ts": np.asarray(ts, dtype=np.int64), "utc_tod": (mitte % TAG) / TAG, "utc_wd": ((mitte // TAG) + 3) % 7, "ny_tod": (ny % TAG) / TAG,
            "ny_wd": ((ny // TAG) + 3) % 7, "ny_auf": (np.asarray(ts, dtype=np.int64) + off_ny) % TAG,
            "utc_auf": np.asarray(ts, dtype=np.int64) % TAG, "off_ny": off_ny}


def design(Z: dict, uhr: str) -> np.ndarray:
    """Regressoren der log-Varianz: Fourier der Tageszeit (Werktag k = 1..4, Wochenende k = 1..2), Sa/So-Niveau, Funding vor/nach
    (UTC); uhr = "ny": Tageszeit und Wochentag in New York, dazu 8:30 und 9:30 ET an Werktagen."""
    tod = Z["ny_tod"] if uhr == "ny" else Z["utc_tod"]
    wd = Z["ny_wd"] if uhr == "ny" else Z["utc_wd"]
    werk = (wd < 5).astype(float); we = 1.0 - werk
    sp = [np.ones(len(tod))]
    for k in range(1, 5):
        sp += [np.cos(2 * np.pi * k * tod) * werk, np.sin(2 * np.pi * k * tod) * werk]
    for k in range(1, 3):
        sp += [np.cos(2 * np.pi * k * tod) * we, np.sin(2 * np.pi * k * tod) * we]
    sp += [(wd == 5).astype(float), (wd == 6).astype(float)]
    sp += [np.isin(Z["utc_auf"], FUND_VOR).astype(float), np.isin(Z["utc_auf"], FUND_NACH).astype(float)]
    if uhr == "ny":
        sp += [werk * (Z["ny_auf"] == 8 * 3600 + 1800), werk * (Z["ny_auf"] == 9 * 3600 + 1800)]
    return np.column_stack(sp)


def _profil_form(X: np.ndarray, r: np.ndarray, s2b: np.ndarray, train: np.ndarray) -> np.ndarray:
    """log-Regression der normierten quadrierten Rendite; liefert s²_roh für alle Bars."""
    y = np.log(r[train] ** 2 / s2b[train] + 0.01)
    beta, *_ = np.linalg.lstsq(X[train], y, rcond=None)
    return np.exp(np.clip(X @ beta, -20, 20))


def _profil_heute(Z: dict, r: np.ndarray, sel: np.ndarray) -> np.ndarray:
    """Wie hl_forecast.time_vol_profile: mittleres |r| je (UTC-Wochentag, UTC-Stunde der Bar) aus sel, normiert auf das Mittel
    der Zellen mit ≥ 20 Werten; als Multiplikator der Schwankung -> s² = mult²."""
    # Wochentag und Stunde der Bar-Eröffnung (nicht der Mitte): hl_forecast nimmt gmtime(t1), t1 = Eröffnung der späteren Kerze
    wd_auf = (((Z["ts"] // TAG) + 3) % 7).astype(np.int64)
    zelle = (Z["utc_auf"] // 3600).astype(np.int64) + 24 * wd_auf
    a = np.abs(np.nan_to_num(r))
    summe = np.bincount(zelle[sel], weights=a[sel], minlength=168)
    anz = np.bincount(zelle[sel], minlength=168)
    with np.errstate(divide="ignore", invalid="ignore"):
        mittel = np.where(anz >= 20, summe / np.maximum(anz, 1), np.nan)
    if np.sum(np.isfinite(mittel)) < 24:
        return np.ones(len(r))
    mult = mittel / np.nanmean(mittel)
    mult = np.where(np.isfinite(mult), mult, 1.0)
    return mult[zelle] ** 2


def p01_profil(P: dict) -> dict:
    """P0.1: QLIKE je Bar und Monat für A flach, B UTC, C heutiges Zeitprofil, D zwei Uhren; D gegen jedes andere."""
    ts, r, ok = P["ts"], P["r"], P["rv_ok"]
    s2b = P["s2_bar"]
    gueltig = ok & np.isfinite(r) & np.isfinite(s2b) & (s2b > 0)
    Z = zeitachsen(ts)
    XB, XD = design(Z, "utc"), design(Z, "ny")
    monate = bewertungsmonate(P)
    zeilen = []
    for m, a, e in monate:
        train = gueltig & (ts < a)
        test = gueltig & (ts >= a) & (ts < e)
        if train.sum() < 200 * BARS_TAG or test.sum() < 5 * BARS_TAG:
            continue
        roh = {"A": np.ones(len(r)), "B": _profil_form(XB, r, s2b, train), "D": _profil_form(XD, r, s2b, train),
               "C": _profil_heute(Z, r, train & (ts >= a - 180 * TAG))}
        L = {}
        for k, s2r in roh.items():
            cn = float(np.mean(r[train] ** 2 / (s2b[train] * s2r[train])))
            v = s2b[test] * s2r[test] * cn
            L[k] = float(np.mean(r[test] ** 2 / v + np.log(v)))
        zeilen.append({"monat": m, "anfang": a, **L})
    erg = {"monate": len(zeilen), "vergleiche": {}}
    for gegen in ("A", "B", "C"):
        erg["vergleiche"][gegen] = p01_vergleich(np.array([z[gegen] - z["D"] for z in zeilen]))
    v = erg["vergleiche"]
    erg["belegt"] = bool(len(zeilen) >= 3 and all(v[g]["ok"] for g in ("A", "B", "C")))
    erg["profil_traegt"] = bool(len(zeilen) >= 3 and v["A"]["ok"] and v["C"]["ok"])
    erg["ny_uhr"] = bool(len(zeilen) >= 3 and v["B"]["ok"])
    erg["buckel"] = _buckel(P, Z, gueltig)
    return erg


def p01_vergleich(d: np.ndarray) -> dict:
    """Monatsdifferenzen (Konkurrent − D, positiv = D besser): Gewinn in ≥ 2/3 der Monate und t-Test über die Monate p < 0,05."""
    d = np.asarray(d, dtype=float)
    if len(d) < 3:
        return {"n": len(d), "anteil": float("nan"), "mittel": float("nan"), "p": float("nan"), "ok": False}
    se = float(np.std(d, ddof=1) / math.sqrt(len(d)))
    t = float(d.mean() / se) if se > 0 else float("nan")
    p = t_p2(t, len(d) - 1)
    anteil = float(np.mean(d > 0))
    return {"n": len(d), "anteil": anteil, "mittel": float(d.mean()), "se": se, "t": t, "p": p,
            "ok": bool(anteil >= 2.0 / 3.0 and d.mean() > 0 and p < ALPHA)}


def _buckel(P: dict, Z: dict, gueltig: np.ndarray) -> dict:
    """
    Beschreibend: Folgt der Werktags-Buckel New York oder UTC? Je Jahreszeit in New York (Sommer- bzw. Winterzeit) wird an
    New Yorker Werktagen die Form log(r²/σ̂² + 0,01) über der UTC-Tageszeit geschätzt (Fourier k = 1…4, Funding-Felder mit eigenem
    Zuschlag, damit ihre UTC-festen Spitzen die Form nicht ziehen). Verschiebung = der Versatz der Winterform gegen die Sommerform
    mit der höchsten Korrelation (−3 … +3 h, 5-min-Schritte): +1 h heißt „folgt New York“, 0 heißt „bleibt in UTC“.
    """
    r, s2b = P["r"], P["s2_bar"]
    tau = np.arange(288) / 288.0
    form = {}
    out = {}
    for name, sel_off in (("sommer", -4 * 3600), ("winter", -5 * 3600)):
        sel = gueltig & (Z["ny_wd"] < 5) & (Z["off_ny"] == sel_off)
        if sel.sum() < 30 * BARS_TAG:
            out[name] = None
            continue
        tod = Z["utc_tod"][sel]
        sp = [np.ones(sel.sum())]
        for k in range(1, 5):
            sp += [np.cos(2 * np.pi * k * tod), np.sin(2 * np.pi * k * tod)]
        sp += [np.isin(Z["utc_auf"][sel], FUND_VOR).astype(float), np.isin(Z["utc_auf"][sel], FUND_NACH).astype(float)]
        X = np.column_stack(sp)
        y = np.log(r[sel] ** 2 / s2b[sel] + 0.01)
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        f = np.full(len(tau), beta[0])
        for k in range(1, 5):
            f += beta[2 * k - 1] * np.cos(2 * np.pi * k * tau) + beta[2 * k] * np.sin(2 * np.pi * k * tau)
        form[name] = f
        i = int(np.argmax(f))
        out[name] = {"uhr_utc": f"{(i * 5) // 60:02d}:{(i * 5) % 60:02d}", "hoehe": float(math.exp(f[i] - float(np.mean(f)))),
                     "tage": int(sel.sum() // BARS_TAG)}
    if "sommer" in form and "winter" in form:
        beste, wert = None, -2.0
        for s in range(-36, 37):                        # 5-min-Schritte, ±3 h
            k = korrelation(form["sommer"], np.roll(form["winter"], -s))
            if k > wert:
                beste, wert = s, k
        out["versatz_h"] = beste * 5 / 60.0
        out["versatz_korr"] = wert
    return out


# ================================================================================================ P0.2 Bewegungsgröße, P0.7 Fenster

H_GROESSE = (1, 3, 7)
TOUCH_K = (0.5, 1.0, 1.5, 2.0)


def _ffill(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=float).copy()
    letzte = np.nan
    for i in range(len(a)):
        if np.isfinite(a[i]) and a[i] > 0:
            letzte = a[i]
        else:
            a[i] = letzte
    return a


def _rollmittel(a: np.ndarray, w: int) -> np.ndarray:
    """Mittel über die Tage d−w+1..d (NaN-Tage ausgelassen, mind. w/2 gültige)."""
    a = np.asarray(a, dtype=float)
    ok = np.isfinite(a)
    cs = np.concatenate([[0.0], np.cumsum(np.where(ok, a, 0.0))])
    cn = np.concatenate([[0], np.cumsum(ok)])
    out = np.full(len(a), np.nan)
    for d in range(w - 1, len(a)):
        n = cn[d + 1] - cn[d + 1 - w]
        if n >= max(1, w // 2):
            out[d] = (cs[d + 1] - cs[d + 1 - w]) / n
    return out


def _vorwaerts_summe(a: np.ndarray, h: int) -> np.ndarray:
    """S_d = a_{d+1} + … + a_{d+h}; NaN, wenn einer fehlt."""
    a = np.asarray(a, dtype=float)
    n = len(a)
    out = np.full(n, np.nan)
    ok = np.isfinite(a)
    cs = np.concatenate([[0.0], np.cumsum(np.where(ok, a, 0.0))])
    cn = np.concatenate([[0], np.cumsum(ok)])
    for d in range(n - h):
        if cn[d + h + 1] - cn[d + 1] == h:
            out[d] = cs[d + h + 1] - cs[d + 1]
    return out


def ewma_tag(RV: np.ndarray, lam: float = 0.94) -> np.ndarray:
    """EWMA der Tages-RV einschließlich des Tags d (Prognose am Tagesende)."""
    out = np.full(len(RV), np.nan)
    e = None
    for d, v in enumerate(RV):
        if np.isfinite(v) and v > 0:
            e = float(v) if e is None else lam * e + (1 - lam) * float(v)
        out[d] = e if e is not None else np.nan
    return out


def _monat_tage(P: dict) -> list:
    """Bewertungsmonate in Tagesindizes: (Anfangstag, Endtag exklusiv)."""
    out = []
    for m, a, e in bewertungsmonate(P):
        out.append((int(a // TAG) - P["tag0"], int(e // TAG) - P["tag0"]))
    return out


def har_prognosen(P: dict, h: int) -> tuple:
    """
    HAR-log je Bewertungsmonat neu geschätzt: log(Ziel/h) auf log RV des Tags, der Woche, des Monats (bis zum Prognosetag d).
    Embargo: trainiert wird nur mit Prognosetagen d, deren Ziel (Tage d+1 … d+h) vor dem Monatsanfang endet. Prognosen für die
    Tagesenden vom Vortag des Monats bis zum vorletzten Monatstag; dazu die 10-/90-%-Quantile der standardisierten Rendite aus
    dem Training. -> (F_har, q_lo, q_hi, r_h, ziel) je Tag.
    """
    RV = P["RV"]; nt = P["n_tage"]; xe = P["xe"]
    rv = _ffill(RV)
    with np.errstate(divide="ignore", invalid="ignore"):
        X = np.column_stack([np.ones(nt), np.log(rv), np.log(_rollmittel(rv, 7)), np.log(_rollmittel(rv, 30))])
    ziel = _vorwaerts_summe(RV, h)
    with np.errstate(divide="ignore", invalid="ignore"):
        y = np.log(ziel / h)
    r_h = np.full(nt, np.nan); r_h[: nt - h] = xe[h:] - xe[: nt - h]
    F_har = np.full(nt, np.nan); q_lo = np.full(nt, np.nan); q_hi = np.full(nt, np.nan)
    for a_d, e_d in _monat_tage(P):
        tr = np.arange(29, max(29, a_d - h))
        tr = tr[np.all(np.isfinite(X[tr]), axis=1) & np.isfinite(y[tr])]
        if len(tr) < 200:
            continue
        beta, *_ = np.linalg.lstsq(X[tr], y[tr], rcond=None)
        res = y[tr] - X[tr] @ beta
        s2e = float(np.var(res))
        z_tr = r_h[tr] / np.sqrt(h * np.exp(X[tr] @ beta + s2e / 2))
        z_tr = z_tr[np.isfinite(z_tr)]
        ql, qh = (np.quantile(z_tr, 0.10), np.quantile(z_tr, 0.90)) if len(z_tr) >= 100 else (np.nan, np.nan)
        o = np.arange(max(29, a_d - 1), min(nt, e_d - 1))
        F_har[o] = h * np.exp(X[o] @ beta + s2e / 2)
        q_lo[o] = ql; q_hi[o] = qh
    return F_har, q_lo, q_hi, r_h, ziel


def p02_groesse(P: dict) -> dict:
    """P0.2: HAR-log gegen EWMA und 7-Tage-Schwankung (QLIKE, DM), 80-%-Band, Berührquoten, Spannweite."""
    RV = P["RV"]; nt = P["n_tage"]
    E = ewma_tag(RV)
    S7 = _rollmittel(RV, 7)
    xe, dh, dl = P["xe"], P["dh"], P["dl"]
    erg = {"h": {}}
    for h in H_GROESSE:
        F_har, q_lo, q_hi, r_h, ziel = har_prognosen(P, h)
        hoch = np.full(nt, np.nan); tief = np.full(nt, np.nan)
        for d in range(nt - h):
            seg_h = dh[d + 1: d + h + 1]; seg_l = dl[d + 1: d + h + 1]
            if np.all(np.isfinite(seg_h)) and np.all(np.isfinite(seg_l)):
                hoch[d] = np.max(seg_h); tief[d] = np.min(seg_l)
        ok = np.isfinite(F_har) & np.isfinite(ziel) & (ziel > 0) & np.isfinite(E) & np.isfinite(S7)
        if ok.sum() < 60:
            erg["h"][h] = {"n": int(ok.sum())}
            continue
        L_har = qlike(F_har[ok], ziel[ok]); L_ew = qlike(h * E[ok], ziel[ok]); L_7 = qlike(h * S7[ok], ziel[ok])
        dm_ew = dm_test(L_ew - L_har); dm_7 = dm_test(L_7 - L_har)
        okb = ok & np.isfinite(r_h) & np.isfinite(q_lo)
        sw = np.sqrt(F_har[okb])
        treffer = float(np.mean((r_h[okb] >= q_lo[okb] * sw) & (r_h[okb] <= q_hi[okb] * sw))) if okb.sum() else float("nan")
        n_eff = okb.sum() / h
        se_b = math.sqrt(0.16 / n_eff) if n_eff > 0 else float("nan")
        okt = ok & np.isfinite(hoch) & np.isfinite(tief) & np.isfinite(xe)
        sv = np.sqrt(F_har[okt])
        soll, ist = [], []
        for k in TOUCH_K:
            p_soll = 2.0 * (1.0 - phi_s(k))
            soll += [p_soll, p_soll]
            ist += [float(np.mean(hoch[okt] - xe[okt] >= k * sv)), float(np.mean(xe[okt] - tief[okt] >= k * sv))]
        soll_a, ist_a = np.array(soll), np.array(ist)
        steigung = float(np.cov(ist_a, soll_a)[0, 1] / np.var(soll_a, ddof=1))
        spann = float(np.mean((hoch[okt] - tief[okt]) / (math.sqrt(8 / math.pi) * sv)))
        erg["h"][h] = {"n": int(ok.sum()), "qlike": {"har": float(L_har.mean()), "ewma": float(L_ew.mean()), "s7": float(L_7.mean())},
                       "dm_ewma": dm_ew, "dm_s7": dm_7, "band": treffer, "band_se": se_b, "band_n": int(okb.sum()),
                       "band_ok": bool(abs(treffer - 0.80) <= 2 * se_b), "touch_soll": soll, "touch_ist": ist,
                       "touch_steigung": steigung, "touch_ok": bool(0.8 <= steigung <= 1.2), "spannweite": spann}
    hh = erg["h"]
    vollst = all(isinstance(hh.get(h), dict) and "dm_ewma" in hh[h] for h in H_GROESSE)
    erg["har_besser"] = bool(vollst and all(hh[h]["dm_ewma"]["mittel"] > 0 and hh[h]["dm_ewma"]["p"] < ALPHA for h in (1, 7)))
    erg["band_ok"] = bool(vollst and all(hh[h]["band_ok"] for h in H_GROESSE))
    erg["touch_ok"] = bool(vollst and all(hh[h]["touch_ok"] for h in H_GROESSE))
    erg["belegt"] = bool(erg["har_besser"] and erg["band_ok"] and erg["touch_ok"])
    return erg


FS_ALPHA = 0.05                         # Fixed Share je Tag (Regime im Mittel rund 20 Tage)
EINZEL_FENSTER = ("2W", "4W", "8W", "EWMA", "Historie")


def fixed_share(F: dict, RV: np.ndarray, alpha: float = FS_ALPHA) -> np.ndarray:
    """
    Fixed Share (Herbster & Warmuth 1998) über Varianzprognosen: Gewichte ∝ exp(−Verlust), Verlust je Tag = Gauß-Quasi-Log-Verlust
    ½(log F + RV/F) des Tages; danach Anteil alpha gleichmäßig verteilt. Prognose für den Tag d+1 = gewichtetes Mittel der
    Einzelprognosen am Tagesende d -- mit den Gewichten, die nur Verluste bis einschließlich Tag d kennen.
    """
    namen = [k for k in EINZEL_FENSTER if k in F]
    M = len(namen)
    lw = np.full(M, -math.log(M))
    Fm = np.column_stack([F[k] for k in namen])
    out = np.full(len(RV), np.nan)
    for d in range(len(RV)):
        f = Fm[d]
        if np.all(np.isfinite(f)) and np.all(f > 0):
            w = np.exp(lw - lw.max()); w /= w.sum()
            out[d] = float(np.dot(w, f))
        # Lernen mit dem Verlust von Tag d+1 erst, wenn er bekannt ist: am Tagesende d+1 (nächste Schleife). Hier: Verlust der
        # Prognosen von gestern (Tag d−1) am heutigen RV.
        if d >= 1:
            fg = Fm[d - 1]; v = RV[d]
            if np.all(np.isfinite(fg)) and np.all(fg > 0) and np.isfinite(v) and v > 0:
                lw = lw - 0.5 * (np.log(fg) + v / fg)
                w = np.exp(lw - lw.max()); w /= w.sum()
                lw = np.log((1.0 - alpha) * w + alpha / M)
    return out


def fenster_prognosen(RV: np.ndarray) -> dict:
    """Tagesvarianz am Tagesende d: Mittel der letzten 2/4/8 Wochen, EWMA (λ 0,94) und ganze Historie bis d."""
    F = {"2W": _rollmittel(RV, 14), "4W": _rollmittel(RV, 28), "8W": _rollmittel(RV, 56), "EWMA": ewma_tag(RV)}
    ok_h = np.isfinite(RV) & (RV > 0)
    cs = np.cumsum(np.where(ok_h, RV, 0.0)); cn = np.cumsum(ok_h)
    F["Historie"] = np.where(cn > 0, cs / np.maximum(cn, 1), np.nan)
    return F


def p07_fenster(P: dict) -> dict:
    """
    P0.7: Tagesvarianz aus 2/4/8 Wochen, EWMA und ganzer Historie gegen die Kombination nach R3 (Fixed Share über die fünf); das
    gleichgewichtete Mittel aus 2/4/8 Wochen und Historie (Pesaran & Pick) wird mit berichtet. QLIKE, HAC-Fehler.
    """
    RV = P["RV"]
    F = fenster_prognosen(RV)
    F["Fixed Share"] = fixed_share(F, RV)
    F["Mittel"] = (F["2W"] + F["4W"] + F["8W"] + F["Historie"]) / 4.0
    erg = {"h": {}}
    start = TRAIN_TAGE
    for h in (1, 7):
        ziel = _vorwaerts_summe(RV, h)
        ok = np.isfinite(ziel) & (ziel > 0)
        for v in F.values():
            ok &= np.isfinite(v) & (v > 0)
        ok[:start] = False
        if ok.sum() < 60:
            erg["h"][h] = {"n": int(ok.sum())}
            continue
        L = {k: qlike(h * v[ok], ziel[ok]) for k, v in F.items()}
        mittel = {k: float(v.mean()) for k, v in L.items()}
        bester = min(EINZEL_FENSTER, key=lambda k: mittel[k])
        diff = L["Fixed Share"] - L[bester]
        se = nw_se(diff, max(h, 5))
        erg["h"][h] = {"n": int(ok.sum()), "qlike": mittel, "bester": bester, "abstand": float(diff.mean()), "se": se,
                       "ok": bool(diff.mean() <= se)}
    erg["belegt"] = bool(all(isinstance(erg["h"].get(h), dict) and erg["h"][h].get("ok") for h in (1, 7)))
    return erg


# ================================================================================================ Directional Change (R4)

def dc_lauf(x, theta, zustand: bool = False, start: int = 0) -> dict:
    """
    Kausale Directional-Change-Segmentierung auf log-Kursen. theta[i] ist die Schwelle, die beim Bestätigen eines Extremums an Bar
    i für das NÄCHSTE Bein festgehalten wird (θ je Bein fest). Ein Hoch gilt als bestätigt, sobald der Kurs θ darunter liegt;
    ein Tief entsprechend. Das erste „Extremum“ ist der Startpunkt und wird verworfen.
    -> ie, ve, typ (+1 Hoch, −1 Tief), ib (Bar der Bestätigung), tb (Schwelle, die es bestätigt hat); mit zustand je Bar: modus,
       aktuelles Extremum (Wert, Index), Index und Wert des letzten bestätigten Extremums, gültige Schwelle.
    """
    xs = x.tolist() if hasattr(x, "tolist") else list(x)
    th = theta.tolist() if hasattr(theta, "tolist") else list(theta)
    n = len(xs)
    ie, ve, typ, ib, tb = [], [], [], [], []
    if zustand:
        z_mod = [0] * n; z_e = [math.nan] * n; z_ie = [-1] * n; z_li = [-1] * n; z_lv = [math.nan] * n; z_t = [math.nan] * n
    i0 = start
    while i0 < n and not (th[i0] == th[i0] and th[i0] > 0):        # erste Bar mit gültiger Schwelle
        i0 += 1
    if i0 >= n:
        out = {"ie": np.zeros(0, np.int64), "ve": np.zeros(0), "typ": np.zeros(0, np.int64), "ib": np.zeros(0, np.int64), "tb": np.zeros(0)}
        return out
    modus = 1; e = xs[i0]; iE = i0; t = th[i0]
    li = -1; lv = math.nan
    for i in range(i0 + 1, n):
        v = xs[i]
        if modus == 1:
            if v > e:
                e = v; iE = i
            elif v <= e - t:
                ie.append(iE); ve.append(e); typ.append(1); ib.append(i); tb.append(t)
                li = iE; lv = e
                modus = -1; e = v; iE = i
                tn = th[i]
                if tn == tn and tn > 0:
                    t = tn
        else:
            if v < e:
                e = v; iE = i
            elif v >= e + t:
                ie.append(iE); ve.append(e); typ.append(-1); ib.append(i); tb.append(t)
                li = iE; lv = e
                modus = 1; e = v; iE = i
                tn = th[i]
                if tn == tn and tn > 0:
                    t = tn
        if zustand:
            z_mod[i] = modus; z_e[i] = e; z_ie[i] = iE; z_li[i] = li; z_lv[i] = lv; z_t[i] = t
    out = {"ie": np.array(ie[1:], np.int64), "ve": np.array(ve[1:]), "typ": np.array(typ[1:], np.int64),
           "ib": np.array(ib[1:], np.int64), "tb": np.array(tb[1:])}
    if zustand:
        out.update({"modus": np.array(z_mod, np.int64), "e": np.array(z_e), "e_i": np.array(z_ie, np.int64),
                    "l_i": np.array(z_li, np.int64), "l_v": np.array(z_lv), "t": np.array(z_t)})
    return out


BEIN_GROESSEN = ("ueberschiessen", "dauer", "p_hl", "p_hh_hl", "ruecksetzer", "asymmetrie")
BEIN_SOLL = {"ueberschiessen": 1.0, "dauer": 1.0, "p_hl": 0.5, "p_hh_hl": 2.0 / 3.0, "ruecksetzer": 1.0, "asymmetrie": 0.0}
BEIN_NAME = {"ueberschiessen": "Überschießen (θ)", "dauer": "Dauer (θ²/σ²)", "p_hl": "P(höheres Tief)",
             "p_hh_hl": "P(höheres Hoch | höheres Tief)", "ruecksetzer": "Rücksetzer (Median, Bein ÷ voriges)",
             "asymmetrie": "Asymmetrie Ū − D̄ (θ)"}


def beine(D: dict, x: np.ndarray, s2b: np.ndarray) -> dict:
    """Beine zwischen aufeinanderfolgenden bestätigten Extrema: Größe, Überschießen, Dauer (normiert), Richtung, Ende."""
    ie, ve, typ, ib, tb = D["ie"], D["ve"], D["typ"], D["ib"], D["tb"]
    if len(ie) < 3:
        return {"n": 0}
    L = np.abs(np.diff(ve))
    th_mit = 0.5 * (tb[:-1] + tb[1:])
    weg_bis_best = np.abs(x[ib[:-1]] - ve[:-1])                     # Kursweg vom Extremum k bis zu seiner Bestätigung
    ueber = (L - weg_bis_best) / tb[1:]
    dauer = (ie[1:] - ie[:-1]) * s2b[ie[:-1]] / th_mit ** 2
    auf = typ[:-1] == -1                                            # Bein vom Tief zum Hoch
    return {"n": len(L), "L": L, "l": L / th_mit, "ueber": ueber, "dauer": dauer, "auf": auf, "ende": ie[1:], "ende_best": ib[1:],
            "typ": typ, "ve": ve, "ie": ie}


def bein_statistik(B: dict, maske_ende=None) -> dict:
    """Sechs Größen über die Beine (optional nur Beine, deren Ende in der Maske liegt: Hälften)."""
    if not B.get("n"):
        return {k: float("nan") for k in BEIN_GROESSEN}
    sel = np.ones(B["n"], bool) if maske_ende is None else maske_ende(B["ende"])
    out = {}
    out["ueberschiessen"] = float(np.mean(B["ueber"][sel])) if sel.any() else float("nan")
    out["dauer"] = float(np.mean(B["dauer"][sel])) if sel.any() else float("nan")
    ve, typ, ie = B["ve"], B["typ"], B["ie"]
    in_sel = np.ones(len(ve), bool) if maske_ende is None else maske_ende(ie)
    tiefs = np.where(typ == -1)[0]
    hl = [ve[tiefs[j + 1]] > ve[tiefs[j]] for j in range(len(tiefs) - 1) if in_sel[tiefs[j + 1]]]
    out["p_hl"] = float(np.mean(hl)) if hl else float("nan")
    hh = []
    for k in range(len(ve) - 3):
        if typ[k] == -1 and ve[k + 2] > ve[k] and in_sel[k + 3]:
            hh.append(ve[k + 3] > ve[k + 1])
    out["p_hh_hl"] = float(np.mean(hh)) if hh else float("nan")
    L = B["L"]
    rr = L[1:] / L[:-1]
    sel_r = sel[1:]
    out["ruecksetzer"] = float(np.median(rr[sel_r])) if sel_r.any() else float("nan")
    l, auf = B["l"][sel], B["auf"][sel]
    out["asymmetrie"] = float(np.mean(l[auf]) - np.mean(l[~auf])) if auf.any() and (~auf).any() else float("nan")
    return out


def _asym_reihe(B: dict, wochen_ts_i: np.ndarray, fenster: int, nach: int = 28 * BARS_TAG) -> tuple:
    """Asymmetrie (Ū − D̄ in θ) der Beine, deren Ende im Fenster vor bzw. nach jedem Wochenpunkt liegt (mind. je 2 auf und ab)."""
    if not B.get("n"):
        return np.full(len(wochen_ts_i), np.nan), np.full(len(wochen_ts_i), np.nan)
    ende = B["ende_best"]; l = B["l"]; auf = B["auf"]           # Zuordnung nach der Bestätigung: erst dann ist ein Bein bekannt
    vor = np.full(len(wochen_ts_i), np.nan); spaeter = np.full(len(wochen_ts_i), np.nan)

    def asym(a, b):
        ll = l[a:b]; aa = auf[a:b]
        if aa.sum() >= 2 and (~aa).sum() >= 2:
            return float(ll[aa].mean() - ll[~aa].mean())
        return np.nan
    for k, t in enumerate(wochen_ts_i):
        a = np.searchsorted(ende, t - fenster, side="right"); b = np.searchsorted(ende, t, side="right")
        c = np.searchsorted(ende, t + nach, side="right")
        vor[k] = asym(a, b); spaeter[k] = asym(b, c)
    return vor, spaeter


def theta_bars(P: dict, c: float) -> np.ndarray:
    return c * np.sqrt(P["s2"][P["tag_i"]])


def p03_rechnen(P: dict, n_surr: int = N_SURR, seed: int = 0, c_gitter=C_GITTER) -> dict:
    """
    P0.3 je Coin: Beinstatistik je c für die echten Kurse und n_surr Vorzeichen-Surrogate mit gleicher Drift (r* = μ + s·(r − μ),
    gleiche θ). Dazu Persistenz der Asymmetrie (c = 1,5; Fenster 4 und 8 Wochen; wöchentlich).
    """
    x, r, s2b = P["x"], P["r"], P["s2_bar"]
    n = len(x)
    rr = np.nan_to_num(r)
    mu = float(np.mean(rr[1:])) if n > 1 else 0.0
    halb = n // 2
    masken = {"h1": lambda e: e < halb, "h2": lambda e: e >= halb}
    woche = np.arange(56 * BARS_TAG, n - 28 * BARS_TAG, 7 * BARS_TAG)
    th = {c: theta_bars(P, c) for c in c_gitter}
    out = {"c": {}, "persistenz": {}}
    obs_B = {}
    for c in c_gitter:
        D = dc_lauf(x, th[c])
        B = beine(D, x, s2b)
        obs_B[c] = B
        out["c"][c] = {"obs": bein_statistik(B), "h1": bein_statistik(B, masken["h1"]), "h2": bein_statistik(B, masken["h2"]),
                       "n_beine": B.get("n", 0), "null": [], "null_h1": [], "null_h2": []}
    pers = {W: {"obs": None, "null": [], "obs_h": None} for W in (28, 56)}
    if C_HAUPT in obs_B:
        for W in (28, 56):
            a, b = _asym_reihe(obs_B[C_HAUPT], woche, W * BARS_TAG)
            pers[W]["obs"] = korrelation(a, b)
            m = len(woche) // 2
            pers[W]["obs_h"] = (korrelation(a[:m], b[:m]), korrelation(a[m:], b[m:]))
    rng = np.random.default_rng(seed)
    for _ in range(n_surr):
        vz = rng.choice(np.array([-1.0, 1.0]), size=n)
        rs = mu + vz * (rr - mu); rs[0] = 0.0
        xs = x[0] + np.cumsum(rs)
        for c in c_gitter:
            D = dc_lauf(xs, th[c])
            B = beine(D, xs, s2b)
            z = out["c"][c]
            z["null"].append(bein_statistik(B)); z["null_h1"].append(bein_statistik(B, masken["h1"]))
            z["null_h2"].append(bein_statistik(B, masken["h2"]))
            if c == C_HAUPT:
                for W in (28, 56):
                    a, b = _asym_reihe(B, woche, W * BARS_TAG)
                    pers[W]["null"].append(korrelation(a, b))
    # Zusammenfassen: z gegen die Surrogate je Größe
    for c, z in out["c"].items():
        z["z"] = {}; z["p"] = {}; z["null_m"] = {}; z["null_sd"] = {}; z["abw_h"] = {}
        for g in BEIN_GROESSEN:
            nv = np.array([d[g] for d in z["null"]], dtype=float); nv = nv[np.isfinite(nv)]
            o = z["obs"][g]
            if len(nv) >= 10 and np.std(nv) > 0 and math.isfinite(o):
                m, sd = float(nv.mean()), float(np.std(nv, ddof=1))
                zz = (o - m) / sd
                # p aus der t-Verteilung mit (Surrogate − 1) Freiheitsgraden: die Streuung der Null ist selbst nur geschätzt
                z["z"][g] = zz; z["p"][g] = t_p2(zz, len(nv) - 1); z["null_m"][g] = m; z["null_sd"][g] = sd
            else:
                z["z"][g] = float("nan"); z["p"][g] = float("nan"); z["null_m"][g] = float("nan"); z["null_sd"][g] = float("nan")
            h = []
            for hk in ("h1", "h2"):
                nv_h = np.array([d[g] for d in z["null_" + hk]], dtype=float); nv_h = nv_h[np.isfinite(nv_h)]
                oh = z[hk][g]
                h.append(oh - float(nv_h.mean()) if len(nv_h) and math.isfinite(oh) else float("nan"))
            z["abw_h"][g] = h
        del z["null"], z["null_h1"], z["null_h2"]
    for W, v in pers.items():
        nv = np.array(v["null"], dtype=float); nv = nv[np.isfinite(nv)]
        o = v["obs"]
        if o is not None and math.isfinite(o) and len(nv) >= 10 and np.std(nv) > 0:
            zz = (o - float(nv.mean())) / float(np.std(nv, ddof=1))
            out["persistenz"][W] = {"rho": o, "null_m": float(nv.mean()), "null_sd": float(np.std(nv, ddof=1)), "z": zz,
                                    "p": t_p2(zz, len(nv) - 1), "rho_h": v["obs_h"], "wochen": int(len(woche))}
        else:
            out["persistenz"][W] = {"rho": o, "p": float("nan"), "z": float("nan"), "rho_h": v["obs_h"], "wochen": int(len(woche))}
    # Beschreibend (c = 1,5): Stufen in Prozent und Tagen
    B = obs_B.get(C_HAUPT)
    if B and B.get("n"):
        tage = n / BARS_TAG
        out["stufen"] = {"beine_4w": B["n"] / tage * 28, "groesse_med_pct": float(np.median(np.expm1(B["L"])) * 100),
                         "dauer_med_tage": float(np.median(np.diff(B["ie"])) / BARS_TAG),
                         "auf_med_pct": float(np.median(np.expm1(B["L"][B["auf"]])) * 100) if B["auf"].any() else float("nan"),
                         "ab_med_pct": float(np.median(-np.expm1(-B["L"][~B["auf"]])) * 100) if (~B["auf"]).any() else float("nan"),
                         "theta_med_pct": float(np.median(th[C_HAUPT][np.isfinite(th[C_HAUPT])]) * 100)}
    return out


def p03_urteil(E03: dict) -> dict:
    """Holm je Größe über alle (Coin × c); belegt bei p_Holm < 0,05 und gleichem Vorzeichen der Abweichung in beiden Hälften.
    Persistenz: Holm über (Coin × Fenster); belegt bei p_Holm < 0,05, ρ > 0 und ρ > 0 in beiden Hälften."""
    urteil = {g: [] for g in BEIN_GROESSEN}
    for g in BEIN_GROESSEN:
        schl, ps = [], []
        for coin, e in E03.items():
            for c, z in e["c"].items():
                schl.append((coin, c)); ps.append(z["p"][g])
        adj = holm(ps)
        for (coin, c), pa in zip(schl, adj):
            z = E03[coin]["c"][c]
            h = z["abw_h"][g]
            gleich = all(math.isfinite(v) for v in h) and (np.sign(h[0]) == np.sign(h[1]) != 0)
            bel = bool(math.isfinite(pa) and pa < ALPHA and gleich)
            z.setdefault("p_holm", {})[g] = pa
            z.setdefault("belegt", {})[g] = bel
            if bel:
                urteil[g].append((coin, c))
    schl, ps = [], []
    for coin, e in E03.items():
        for W, v in e["persistenz"].items():
            schl.append((coin, W)); ps.append(v.get("p"))
    adj = holm(ps)
    pers = []
    for (coin, W), pa in zip(schl, adj):
        v = E03[coin]["persistenz"][W]
        rh = v.get("rho_h") or (float("nan"), float("nan"))
        bel = bool(math.isfinite(pa) and pa < ALPHA and v["rho"] > 0 and all(math.isfinite(q) and q > 0 for q in rh))
        v["p_holm"] = pa; v["belegt"] = bel
        if bel:
            pers.append((coin, W))
    return {"groessen": urteil, "persistenz": pers}


# ================================================================================================ P0.4 Beinende-Prognose (R4a)

P04_MERKMALE = ("alter", "groesse", "seit", "vol", "mom", "asym")
P04_NAME = {"alter": "Alter des Beins", "groesse": "Größe bisher", "seit": "Zeit seit dem Extremum", "vol": "Schwankungszustand",
            "mom": "Momentum in Beinrichtung", "asym": "Asymmetrie 8 W in Beinrichtung"}


def p04_punkte(P: dict, coin: str, schritt: int = 8) -> dict:
    """
    Prognosepunkte alle 4 h innerhalb eines Beins (c = 1,5) mit D/θ in [0,1; 0,9]. Ereignis Y = 1: Das laufende Extremum wird
    bestätigt (der Kurs läuft θ zurück, bevor ein neues Extremum entsteht); aufgelöst bei der Bestätigung bzw. beim neuen Extremum.
    Merkmale nur aus Daten bis zum Punkt (Beine zählen erst ab ihrer Bestätigung).
    """
    x, r, s2b, ts = P["x"], P["r"], P["s2_bar"], P["ts"]
    n = len(x)
    th = theta_bars(P, C_HAUPT)
    D = dc_lauf(x, th, zustand=True)
    leer = {"n": 0}
    if len(D["ie"]) < 10:
        return leer
    ie, ib = D["ie"], D["ib"]
    B = beine(D, x, s2b)
    erstes = int(ie[0])
    r2 = np.where(P["rv_ok"], np.nan_to_num(r) ** 2, np.nan)
    r2c = np.concatenate([[0.0], np.cumsum(np.nan_to_num(r2))])
    nc = np.concatenate([[0], np.cumsum(np.isfinite(r2))])
    zeilen = []
    for i in range(max(erstes + 1, 21 * BARS_TAG), n, schritt):
        mo = D["modus"][i]; t = D["t"][i]; e = D["e"][i]; li = D["l_i"][i]
        if mo == 0 or not (t > 0) or not math.isfinite(e) or li < erstes or not (s2b[i] > 0):
            continue
        dist = (e - x[i]) / t if mo == 1 else (x[i] - e) / t
        if not 0.1 <= dist <= 0.9:
            continue
        k = int(np.searchsorted(ib, i, side="right"))           # nächstes bestätigtes Extremum nach i
        if k >= len(ib):
            continue
        if ie[k] == D["e_i"][i]:
            y, aufl = 1, int(ib[k])
        else:
            seg = x[i + 1: ie[k] + 1]
            j = np.argmax(seg > e) if mo == 1 else np.argmax(seg < e)
            y, aufl = 0, int(i + 1 + j)
        richtung = 1.0 if mo == 1 else -1.0
        sd_tag = math.sqrt(s2b[i] * BARS_TAG)
        a = i - 47
        rv24 = (r2c[i + 1] - r2c[a]) * BARS_TAG / max(1, nc[i + 1] - nc[a]) if a > 0 else float("nan")
        vol = 0.5 * math.log(rv24 / (sd_tag ** 2)) if rv24 > 0 else float("nan")
        mom = richtung * (x[i] - x[i - 21 * BARS_TAG]) / (sd_tag * math.sqrt(21))
        # Asymmetrie der Beine, die in den letzten 56 Tagen bestätigt wurden (bis i)
        hi = np.searchsorted(B["ende_best"], i, side="right"); lo = np.searchsorted(B["ende_best"], i - 56 * BARS_TAG, side="right")
        ll, au = B["l"][lo:hi], B["auf"][lo:hi]
        asym = richtung * (float(ll[au].mean() - ll[~au].mean())) if au.sum() >= 2 and (~au).sum() >= 2 else 0.0
        zeilen.append((int(ts[i]), k, dist, y, int(ts[aufl]),
                       (i - li) * s2b[i] / t ** 2, abs(e - D["l_v"][i]) / t, (i - D["e_i"][i]) * s2b[i] / t ** 2,
                       vol, mom, asym))
    if not zeilen:
        return leer
    a = np.array(zeilen, dtype=float)
    ok = np.all(np.isfinite(a), axis=1)
    a = a[ok]
    return {"n": len(a), "coin": coin, "ts": a[:, 0].astype(np.int64), "bein": a[:, 1].astype(np.int64), "p0": a[:, 2],
            "y": a[:, 3].astype(np.int64), "aufl": a[:, 4].astype(np.int64), "F": a[:, 5:], "beine_gesamt": int(len(ie) - 1),
            "ts_beinende": np.array([int(ts[j]) for j in ib], dtype=np.int64)}


def _logit_fit(X: np.ndarray, y: np.ndarray, strafe: np.ndarray, lam: float, iters: int = 40) -> np.ndarray:
    """Logistische Regression per Newton (IRLS) mit Ridge-Strafe lam·strafe_j·w_j²/2."""
    w = np.zeros(X.shape[1])
    for _ in range(iters):
        eta = np.clip(X @ w, -30, 30)
        p = 1.0 / (1.0 + np.exp(-eta))
        g = X.T @ (y - p) - lam * strafe * w
        H = X.T @ (X * (p * (1 - p))[:, None]) + np.diag(lam * strafe + 1e-9)
        schritt = np.linalg.solve(H, g)
        w += schritt
        if np.max(np.abs(schritt)) < 1e-9:
            break
    return w


def _verluste(p: np.ndarray, y: np.ndarray) -> tuple:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p)), (p - y) ** 2


def p04_auswerten(punkte: list, _intern: bool = False) -> dict:
    """
    Gepoolt über Coins, monatlich neu geschätzt (Training nur mit vor dem Monatsanfang aufgelösten Fällen): roh D/θ, kalibrierte
    Baseline (Achsenabschnitt + Steigung auf logit D/θ), Modell (Baseline + sechs Merkmale, Ridge λ = 2 % der Fälle). Verlust je
    Bein summiert (jeder Prognosepunkt zählt gleich, das Bein ist der Klumpen), DM über die Beine in Zeitfolge.
    """
    punkte = [q for q in punkte if q.get("n")]
    if not punkte:
        return {"belegt": False, "n": 0}
    ts = np.concatenate([q["ts"] for q in punkte])
    coin = np.concatenate([np.full(q["n"], i) for i, q in enumerate(punkte)])
    bein = np.concatenate([q["bein"] for q in punkte])
    p0 = np.clip(np.concatenate([q["p0"] for q in punkte]), 0.02, 0.98)
    y = np.concatenate([q["y"] for q in punkte]).astype(float)
    aufl = np.concatenate([q["aufl"] for q in punkte])
    F = np.concatenate([q["F"] for q in punkte])
    lo = np.log(p0 / (1 - p0))
    start = min(int(q["ts"][0]) for q in punkte)
    m0 = int(_monate(np.array([start + TRAIN_TAGE * TAG]))[0]) + 1
    m1 = int(_monate(np.array([int(ts.max())]))[0])
    pr = {"roh": np.full(len(y), np.nan), "basis": np.full(len(y), np.nan), "modell": np.full(len(y), np.nan)}
    gewichte = []
    gew_monat = []
    for m in range(m0, m1 + 1):
        a, e = _monatsanfang(m), _monatsanfang(m + 1)
        tr = aufl < a
        te = (ts >= a) & (ts < e)
        if tr.sum() < 500 or te.sum() == 0:
            continue
        mu = F[tr].mean(axis=0); sd = F[tr].std(axis=0); sd[sd == 0] = 1.0
        Fs = (F - mu) / sd
        Xb = np.column_stack([np.ones(len(y)), lo])
        Xm = np.column_stack([Xb, Fs])
        wb = _logit_fit(Xb[tr], y[tr], np.zeros(2), 0.0)
        lam = 0.02 * tr.sum()
        wm = _logit_fit(Xm[tr], y[tr], np.concatenate([[0.0, 0.0], np.ones(F.shape[1])]), lam)
        pr["roh"][te] = p0[te]
        pr["basis"][te] = 1.0 / (1.0 + np.exp(-np.clip(Xb[te] @ wb, -30, 30)))
        pr["modell"][te] = 1.0 / (1.0 + np.exp(-np.clip(Xm[te] @ wm, -30, 30)))
        gewichte.append(wm[2:])
        if _intern:
            gew_monat.append((a, wm.copy()))
    bew = np.isfinite(pr["modell"])
    if bew.sum() < 100:
        return {"belegt": False, "n": int(bew.sum())}
    L = {k: _verluste(v[bew], y[bew]) for k, v in pr.items()}
    schl = coin[bew] * 10_000_000 + bein[bew]
    u, inv = np.unique(schl, return_inverse=True)
    t_bein = np.zeros(len(u)); np.maximum.at(t_bein, inv, ts[bew].astype(float))
    reihen = np.argsort(t_bein)

    def je_bein(v):
        # Summe je Bein: gleiche Gewichte je Prognosepunkt wie im Training, Einheit für den Fehler ist das Bein (Klumpen)
        return np.bincount(inv, weights=v)[reihen]
    erg = {"n_punkte": int(bew.sum()), "n_beine": int(len(u)), "y_quote": float(y[bew].mean())}
    for name, (a_, b_) in (("basis_gegen_modell", ("basis", "modell")), ("roh_gegen_modell", ("roh", "modell")),
                           ("roh_gegen_basis", ("roh", "basis"))):
        erg[name] = {"log": dm_test(je_bein(L[a_][0] - L[b_][0])), "brier": dm_test(je_bein(L[a_][1] - L[b_][1]))}
    erg["mittel"] = {k: {"log": float(v[0].mean()), "brier": float(v[1].mean())} for k, v in L.items()}
    # Abdeckung: Beine mit Ende im Bewertungszeitraum, die mindestens einen Prognosepunkt haben
    t_a = int(ts[bew].min()); t_e = int(ts[bew].max())
    gesamt = sum(int(np.sum((q["ts_beinende"] >= t_a) & (q["ts_beinende"] <= t_e))) for q in punkte)
    erg["abdeckung"] = len(u) / gesamt if gesamt else float("nan")
    je_coin = {}
    for i, q in enumerate(punkte):
        s = coin[bew] == i
        if s.sum() >= 50:
            ll = L["basis"][0][s] - L["modell"][0][s]
            je_coin[q["coin"]] = {"n": int(s.sum()), "log_gewinn": float(ll.mean())}
    erg["je_coin"] = je_coin
    if gewichte:
        erg["gewichte"] = dict(zip(P04_MERKMALE, np.mean(np.array(gewichte), axis=0).tolist()))
    bm = erg["basis_gegen_modell"]
    erg["belegt"] = bool(bm["log"]["mittel"] > 0 and bm["log"]["p"] < ALPHA and bm["brier"]["mittel"] > 0 and bm["brier"]["p"] < ALPHA
                         and erg["abdeckung"] >= 0.5)
    if _intern:
        erg["_pr"] = {"ts": ts, "coin": coin, "modell": pr["modell"], "basis": pr["basis"], "gewichte": dict(gew_monat)}
    return erg


# ================================================================================================ P0.5 Kalender (R5)

def kurs_zum(P: dict):
    """Funktion T (UTC-Sekunden, auch Arrays) -> log-Kurs zum Zeitpunkt T = Schluss der Bar, die um T endet; fehlt sie: NaN."""
    ts, x = P["ts"], P["x"]
    t0 = int(ts[0])
    span = int((ts[-1] - t0) // BAR) + 1
    gitter = np.full(span, np.nan)
    gitter[((ts - t0) // BAR).astype(np.int64)] = x

    def f(T):
        T = np.asarray(T, dtype=np.int64)
        k = (T - BAR - t0) // BAR
        ok = (k >= 0) & (k < span) & ((T - BAR - t0) % BAR == 0)
        out = np.full(T.shape, np.nan)
        out[ok] = gitter[k[ok]]
        return out
    return f


def _lokal_utc(datum_tage: np.ndarray, stunde: float, tzname: str) -> np.ndarray:
    """UTC-Zeitpunkt der lokalen Uhrzeit (Stunde, auch x,5) an den Kalendertagen (Tage seit 1970) in tzname."""
    z = ZoneInfo(tzname)
    out = np.zeros(len(datum_tage), dtype=np.int64)
    hh, mm = int(stunde), int(round((stunde - int(stunde)) * 60))
    for k, d in enumerate(datum_tage):
        dt = datetime.fromtimestamp(int(d) * TAG, timezone.utc)
        out[k] = int(datetime(dt.year, dt.month, dt.day, hh, mm, tzinfo=z).timestamp())
    return out


def _jahr(ts) -> np.ndarray:
    return np.asarray(ts, dtype=np.int64).astype("datetime64[s]").astype("datetime64[Y]").astype(np.int64) + 1970


def _jahres_vorzeichen(werte: np.ndarray, zeiten: np.ndarray, mindest: int, gesamt: float) -> tuple:
    """(alle Jahre mit ≥ mindest Werten haben das Vorzeichen von gesamt, Liste (Jahr, Mittel, n))."""
    jahre = _jahr(zeiten)
    liste = []
    ok = True
    for j in np.unique(jahre):
        w = werte[(jahre == j) & np.isfinite(werte)]
        if len(w) >= mindest:
            m = float(w.mean()); liste.append((int(j), m, len(w)))
            if np.sign(m) != np.sign(gesamt):
                ok = False
    return ok and len(liste) >= 1, liste


def _robust(w: np.ndarray) -> dict:
    """Beschreibend (23.60): Median, Mittel ohne die 2,5 % kleinsten und größten Werte, Anteil negativer Werte -- trägt ein
    Kalendereffekt die Masse der Tage oder nur wenige Ausreißer?"""
    w = np.sort(np.asarray(w, dtype=float)[np.isfinite(w)])
    n = len(w)
    if n < 40:
        return {}
    k = int(n * 0.025)
    return {"median": float(np.median(w)), "getrimmt": float(w[k:n - k].mean()), "negativ": float(np.mean(w < 0)), "n": n}


def p05_kalender(P: dict) -> dict:
    """K1–K3 (Holm), 24 UTC-Stunden und 7 UTC-Wochentage (BH q = 0,10), Persistenz nach Heston-Korajczyk-Sadka."""
    xz = kurs_zum(P)
    ts = P["ts"]
    tag_a, tag_e = int(ts[0] // TAG) + 1, int(ts[-1] // TAG) - 1
    tage = np.arange(tag_a, tag_e + 1, dtype=np.int64)
    erg = {"K": {}, "stunden": [], "wochentage": []}
    # K1: 02:00–05:00 Berlin (Tage mit Zeitumstellung fallen aus)
    a = _lokal_utc(tage, 2, TZ_BERLIN); b = _lokal_utc(tage, 5, TZ_BERLIN)
    ok = (b - a) == 3 * 3600
    k1 = (xz(b) - xz(a))[ok]; k1_t = a[ok]
    # K2: Sa 22:00 – So 04:00 Berlin
    sa = tage[((tage + 3) % 7) == 5]
    a2 = _lokal_utc(sa, 22, TZ_BERLIN); b2 = _lokal_utc(sa + 1, 4, TZ_BERLIN)
    ok2 = (b2 - a2) == 6 * 3600
    k2 = (xz(b2) - xz(a2))[ok2]; k2_t = a2[ok2]
    # K3: New York Mo–Fr, Sitzung 9:30–16:00 gegen den Rest seit 16:00 des Vorhandelstags, JE STUNDE verglichen (23.60): der Rest
    # dauert 17,5 h, montags mit dem Wochenende 65,5 h, die Sitzung 6,5 h. Roh verglichen (23.59) zog schon die Drift K3 ins Minus:
    # Erwartung (6,5 − 27,1) h × Drift je Stunde ≈ −0,86 × mittlere Tagesrendite (BTC −8 bp, PAXG −6 bp; Bericht 08.10.). Darum
    # wird der Rest auf die Länge der Sitzung skaliert; „K3 roh“ bleibt als Anzeige (wie vorab, driftbehaftet).
    wt = tage[((tage + 3) % 7) < 5]
    auf = _lokal_utc(wt, 9.5, TZ_NY); zu = _lokal_utc(wt, 16, TZ_NY)
    vor = np.concatenate([[0], zu[:-1]])
    lueck = np.concatenate([[False], (wt[1:] - wt[:-1]) <= 3])          # Vorhandelstag = vorige Zeile (Fr -> Mo: 3 Tage)
    sitzung = xz(zu) - xz(auf); nacht = np.where(lueck, xz(auf) - xz(vor), np.nan)
    d_sitz = (zu - auf).astype(float)
    d_rest = np.where(lueck, (auf - vor).astype(float), np.nan)           # Sekunden, Zeitumstellungen eingeschlossen
    k3_roh = (sitzung - nacht)[lueck]
    k3 = (sitzung - d_sitz / d_rest * nacht)[lueck]; k3_t = auf[lueck]
    defs = (("K1", "02–05 Uhr Berlin", k1, k1_t, 5, 120), ("K2", "Samstagnacht Sa 22 – So 04 Uhr Berlin", k2, k2_t, 2, 26),
            ("K3", "US-Kernsitzung minus Rest je Stunde (New York, Rest auf 6,5 h skaliert)", k3, k3_t, 5, 120))
    ps = []
    for key, name, w, zt, lag, mindest in defs:
        sel = np.isfinite(w)
        t = mittel_test(w[sel], lag)
        jahr_ok, jahre = _jahres_vorzeichen(w[sel], zt[sel], mindest, t["mittel"])
        erg["K"][key] = {"name": name, **t, "jahr_ok": jahr_ok, "jahre": jahre, "robust": _robust(w[sel])}
        ps.append(t["p"])
    sel = np.isfinite(k3_roh)
    erg["K3_roh"] = {**mittel_test(k3_roh[sel], 5), "jahre": _jahres_vorzeichen(k3_roh[sel], k3_t[sel], 120, 1.0)[1]}
    # Drift im Zeitraum (log-Rendite je Tag) und ihr Anteil am rohen K3: (Sitzung − Rest) in Tagen × Drift
    xs = P["x"]; okx = np.isfinite(xs)
    if okx.sum() > 1:
        i0 = int(np.argmax(okx)); i1 = int(len(xs) - 1 - np.argmax(okx[::-1]))
        erg["drift_tag"] = float((xs[i1] - xs[i0]) / max((ts[i1] - ts[i0]) / TAG, 1.0))
        erg["K3_roh"]["drift_anteil"] = erg["drift_tag"] * float(np.nanmean((d_sitz - d_rest)[lueck]) / TAG)
    for key, pa in zip(("K1", "K2", "K3"), holm(ps)):
        k = erg["K"][key]
        k["p_holm"] = pa
        k["belegt"] = bool(math.isfinite(pa) and pa < ALPHA and k["jahr_ok"])
    # 24 Stunden und 7 Wochentage (UTC)
    stunden_r = []
    for h in range(24):
        t1 = tage * TAG + h * 3600
        w = xz(t1 + 3600) - xz(t1)
        stunden_r.append(w)
    tests, namen = [], []
    for h, w in enumerate(stunden_r):
        sel = np.isfinite(w)
        tt = mittel_test(w[sel], 5)
        jahr_ok, _ = _jahres_vorzeichen(w[sel], (tage * TAG)[sel], 120, tt["mittel"])
        tests.append({**tt, "jahr_ok": jahr_ok}); namen.append(f"{h:02d}–{(h + 1) % 24:02d} UTC")
    tag_r = xz(tage * TAG + TAG) - xz(tage * TAG)
    wd = (tage + 3) % 7
    for d in range(7):
        sel = (wd == d) & np.isfinite(tag_r)
        tt = mittel_test(tag_r[sel], 2)
        jahr_ok, _ = _jahres_vorzeichen(tag_r[sel], (tage * TAG)[sel], 26, tt["mittel"])
        tests.append({**tt, "jahr_ok": jahr_ok}); namen.append(("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")[d])
    verw = bh([t["p"] for t in tests], 0.10)
    for t, n_, v in zip(tests, namen, verw):
        t["name"] = n_; t["bh"] = bool(v); t["belegt"] = bool(v and t["jahr_ok"])
    erg["stunden"] = tests[:24]; erg["wochentage"] = tests[24:]
    # Persistenz (HKS): wöchentliche Querschnittssteigung der 24 Stundenrenditen auf ihr 8-Wochen-Mittel davor
    M = np.column_stack(stunden_r)                                     # Tage × 24
    montage = np.where(((tage + 3) % 7) == 0)[0]
    steig, steig_t = [], []
    for i in montage:
        if i - 56 < 0 or i + 7 > len(tage):
            continue
        xv = np.nanmean(M[i - 56: i], axis=0); yv = np.nanmean(M[i: i + 7], axis=0)
        ok = np.isfinite(xv) & np.isfinite(yv)
        if ok.sum() >= 20 and np.var(xv[ok]) > 0:
            xx = xv[ok] - xv[ok].mean(); yy = yv[ok] - yv[ok].mean()
            steig.append(float(np.dot(xx, yy) / np.dot(xx, xx))); steig_t.append(int(tage[i]))
    erg["persistenz"] = hks_urteil(np.array(steig))
    # Beschreibend: die letzten 8 Wochen für K1–K3 (Zahl negativer Werte, Mittel)
    jetzt = int(ts[-1])
    acht = {}
    for key, name, w, zt, lag, mindest in defs:
        sel = np.isfinite(w) & (zt > jetzt - 56 * TAG)
        if sel.sum():
            acht[key] = {"n": int(sel.sum()), "negativ": int(np.sum(w[sel] < 0)), "mittel": float(w[sel].mean())}
    erg["acht_wochen"] = acht
    erg["belegt_k"] = [k for k in ("K1", "K2", "K3") if erg["K"][k]["belegt"]]
    erg["belegt_zeit"] = [t["name"] for t in tests if t["belegt"]]
    return erg


def hks_urteil(steig: np.ndarray) -> dict:
    """Persistenz nach Heston-Korajczyk-Sadka: Mittel der wöchentlichen Querschnittssteigungen (HAC, Lag 8) > 0 mit p < 0,05 und
    positiv in beiden Hälften."""
    if len(steig) < 20:
        return {"n": len(steig), "belegt": False, "p": float("nan"), "mittel": float("nan")}
    t = mittel_test(steig, 8)
    m = len(steig) // 2
    halb = (float(steig[:m].mean()), float(steig[m:].mean()))
    return {**t, "halb": halb, "belegt": bool(t["p"] < ALPHA and t["mittel"] > 0 and halb[0] > 0 and halb[1] > 0)}


# ================================================================================================ P0.6 Wochenmomentum (R6)

L_MOM = (14, 21, 28)


def _woche_signal(P: dict, L: int) -> dict:
    """Montags 00 UTC: z_L, Aufwärts-Ereignis der folgenden 7 Tage und Wochenrendite."""
    xz = kurs_zum(P)
    ts = P["ts"]
    erster = (int(ts[0]) // TAG + L + 1)
    erster += (7 - ((erster + 3) % 7)) % 7                              # nächster Montag
    montage = np.arange(erster, int(ts[-1]) // TAG - 7, 7, dtype=np.int64)
    T = montage * TAG
    x0 = xz(T); xL = xz(T - L * TAG); x7 = xz(T + 7 * TAG)
    s2 = P["s2"]; ti = montage - P["tag0"]
    sig = np.where((ti >= 0) & (ti < len(s2)), np.sqrt(s2[np.clip(ti, 0, len(s2) - 1)]), np.nan)
    z = (x0 - xL) / (sig * math.sqrt(L))
    R = x7 - x0
    ok = np.isfinite(z) & np.isfinite(R)
    return {"T": T[ok], "z": z[ok], "R": R[ok], "up": (R[ok] > 0).astype(float)}


def _dsr(sr: float, n_obs: int, schiefe: float, kurt: float, sr_alle: list) -> float:
    """Deflated Sharpe Ratio (Bailey & López de Prado 2014) je Periode; kurt = gewöhnliche Kurtosis (Normal 3)."""
    N = len(sr_alle)
    v = float(np.var(sr_alle, ddof=1)) if N > 1 else 0.0
    g = 0.5772156649
    sr0 = math.sqrt(v) * ((1 - g) * ppf(1 - 1.0 / N) + g * ppf(1 - 1.0 / (N * math.e))) if N > 1 and v > 0 else 0.0
    nenner = 1 - schiefe * sr + (kurt - 1) / 4.0 * sr * sr
    if nenner <= 0 or n_obs < 3:
        return float("nan")
    return phi_s((sr - sr0) * math.sqrt(n_obs - 1) / math.sqrt(nenner))


def _pbo(M: np.ndarray, S: int = 16) -> float:
    """Probability of Backtest Overfitting per CSCV (Bailey, Borwein, López de Prado & Zhu): M = Perioden × Konfigurationen."""
    from itertools import combinations
    T, N = M.shape
    if N < 2 or T < 2 * S:
        return float("nan")
    b = T // S
    M = M[: b * S]
    summe = M.reshape(S, b, N).sum(axis=1); quadr = (M ** 2).reshape(S, b, N).sum(axis=1)
    lam = []
    alle = set(range(S))
    for IS in combinations(range(S), S // 2):
        OS = list(alle - set(IS)); IS = list(IS)
        n = b * len(IS)
        m_i = summe[IS].sum(0) / n; v_i = quadr[IS].sum(0) / n - m_i ** 2
        m_o = summe[OS].sum(0) / n; v_o = quadr[OS].sum(0) / n - m_o ** 2
        sr_i = m_i / np.sqrt(np.maximum(v_i, 1e-18)); sr_o = m_o / np.sqrt(np.maximum(v_o, 1e-18))
        best = int(np.argmax(sr_i))
        rang = float(np.sum(sr_o <= sr_o[best]))                        # 1 … N
        w = rang / (N + 1.0)
        lam.append(math.log(w / (1 - w)))
    return float(np.mean(np.array(lam) <= 0))


def p06_momentum(PP: dict, _intern: bool = False) -> dict:
    """Nur BTC und ETH (soweit lang genug): Brier gegen die Basisrate (DM, Holm über Coins × L), Timing-Regel mit DSR und PBO."""
    erg = {"varianten": {}}
    reihen = {}
    for coin in ("BTC", "ETH"):
        P = PP.get(coin)
        if P is None:
            continue
        for L in L_MOM:
            W = _woche_signal(P, L)
            T, z, up, R = W["T"], W["z"], W["up"], W["R"]
            start = int(P["ts"][0]) + TRAIN_TAGE * TAG
            p_m, p_b, e_r = [], [], []
            vorher = 0.0
            zeiten = []
            for w in range(len(T)):
                if T[w] < start:
                    continue
                tr = T + 7 * TAG <= T[w]
                if tr.sum() < 40:
                    continue
                pb = float(up[tr].mean())
                th = np.tanh(z[tr])
                k = float(np.dot(up[tr] - pb, th) / max(np.dot(th, th), 1e-12))
                res = up[tr] - pb - k * th
                se = math.sqrt(float(np.var(res)) / max(np.dot(th, th), 1e-12))
                tk = k / se if se > 0 else 0.0
                ks = k * max(0.0, 1.0 - 1.0 / (tk * tk)) if tk != 0 else 0.0
                p_m.append(min(0.95, max(0.05, pb + ks * math.tanh(z[w])))); p_b.append(pb)
                ps = 1.0 if z[w] > 0 else 0.0
                e_mittel = float(np.mean((z[tr] > 0).astype(float)))
                e_r.append((ps - e_mittel) * R[w] - KOSTEN_WECHSEL * abs(ps - vorher))
                vorher = ps
                zeiten.append(int(T[w]))
            if len(p_m) < 30:
                continue
            idx = np.searchsorted(T, np.array(zeiten))
            y = up[idx]
            d = (np.array(p_b) - y) ** 2 - (np.array(p_m) - y) ** 2
            erg["varianten"][(coin, L)] = {"n": len(p_m), "dm": dm_test(d), "brier_m": float(np.mean((np.array(p_m) - y) ** 2)),
                                          "brier_b": float(np.mean((np.array(p_b) - y) ** 2))}
            reihen[(coin, L)] = (np.array(zeiten), np.array(e_r))
            if _intern:
                erg["varianten"][(coin, L)]["_p"] = (np.array(zeiten), np.array(p_m))
    if not erg["varianten"]:
        erg["belegt"] = []
        return erg
    schl = list(erg["varianten"])
    adj = holm([erg["varianten"][k]["dm"]["p"] for k in schl])
    sr_alle = []
    for k in schl:
        e = reihen[k][1]
        sr_alle.append(float(e.mean() / e.std(ddof=1)) if e.std(ddof=1) > 0 else 0.0)
    gemein = None
    for k in schl:
        gemein = set(reihen[k][0].tolist()) if gemein is None else gemein & set(reihen[k][0].tolist())
    gemein = np.array(sorted(gemein)) if gemein else np.zeros(0, np.int64)
    if len(gemein) >= 64:
        M = np.column_stack([reihen[k][1][np.isin(reihen[k][0], gemein)] for k in schl])
        pbo = _pbo(M)
    else:
        pbo = float("nan")
    erg["pbo"] = pbo
    bel = []
    for k, pa, sr in zip(schl, adj, sr_alle):
        v = erg["varianten"][k]
        e = reihen[k][1]
        m3 = float(np.mean((e - e.mean()) ** 3) / e.std() ** 3) if e.std() > 0 else 0.0
        m4 = float(np.mean((e - e.mean()) ** 4) / e.std() ** 4) if e.std() > 0 else 3.0
        v["sr_woche"] = sr; v["sr_jahr"] = sr * math.sqrt(52)
        v["dsr"] = _dsr(sr, len(e), m3, m4, sr_alle)
        v["p_holm"] = pa
        # PBO wird berichtet, ist aber keine Bedingung: Bei sechs fast gleichen Varianten liegt es auch für eine wirksame Regel um 0,5
        # (Positivkontrolle 07.10.); die Mehrfachprüfung übernehmen Holm (Brier) und der Deflated Sharpe über die 6 Varianten.
        v["belegt"] = bool(math.isfinite(pa) and pa < ALPHA and v["dm"]["mittel"] > 0 and math.isfinite(v["dsr"]) and v["dsr"] >= 0.95)
        if v["belegt"]:
            bel.append(k)
    erg["belegt"] = bel
    return erg


# ================================================================================================ P0.8 Regime-Analog (R8a)

H_ANALOG = (48, 144, 336)               # 24 h, 72 h, 7 T in Bars


def analog_merkmale_bestand(c: np.ndarray, ts: np.ndarray) -> np.ndarray:
    """Die 9 Merkmale der bestehenden Analog-Suche (hl_forecast._feature_table), vektorisiert; NaN, wo der Vorlauf fehlt."""
    n = len(c)
    lg = np.log(c)
    r = np.concatenate([[0.0], np.diff(lg)])
    cs = np.concatenate([[0.0], np.cumsum(r)]); cs2 = np.concatenate([[0.0], np.cumsum(r * r)])
    cc = np.concatenate([[0.0], np.cumsum(c)])
    d = np.concatenate([[0.0], np.diff(c)])
    gain = np.concatenate([[0.0], np.cumsum(np.where(d > 0, d, 0.0))]); loss = np.concatenate([[0.0], np.cumsum(np.where(d < 0, -d, 0.0))])
    F = np.full((n, 9), np.nan)
    i = np.arange(1440, n)
    if len(i) == 0:
        return F
    r1d, r7d, r30d = lg[i] - lg[i - 48], lg[i] - lg[i - 336], lg[i] - lg[i - 1440]
    m = (cs[i + 1] - cs[i - 144]) / 145; v = (cs2[i + 1] - cs2[i - 144]) / 145 - m * m
    vol3d = np.sqrt(np.maximum(v, 0.0))
    g = gain[i + 1] - gain[i - 13]; l = loss[i + 1] - loss[i - 13]
    with np.errstate(divide="ignore", invalid="ignore"):
        rsi = np.where(l == 0, 100.0, 100 - 100 / (1 + g / np.where(l == 0, 1.0, l)))
    sma7 = (cc[i + 1] - cc[i - 335]) / 336
    hod = (ts[i] % 86400) / 86400 * 2 * math.pi; wd = (ts[i] // 86400 + 3) % 7
    F[i] = np.column_stack([r1d / 0.03, r7d / 0.08, r30d / 0.15, vol3d / 0.004, (rsi - 50) / 25, np.log(c[i] / sma7) / 0.05,
                            np.sin(hod) * 0.5, np.cos(hod) * 0.5, (wd - 3) / 3 * 0.5])
    return F


def analog_merkmale_regime(P: dict) -> np.ndarray:
    """R8a: r_1T/σ, r_7T/(σ√7), r_28T/(σ√28), log(σ_7T/σ_90T), Richtung × D/θ (c = 1,5); σ = σ̂_Tag kausal."""
    x = P["x"]; n = len(x)
    sig = np.sqrt(P["s2"][P["tag_i"]])
    RV = P["RV"]
    s7 = _rollmittel(RV, 7); s90 = _rollmittel(RV, 90)
    ti = P["tag_i"] - 1                                                 # nur abgeschlossene Tage
    ok_t = ti >= 0
    with np.errstate(divide="ignore", invalid="ignore"):
        f4 = np.where(ok_t, 0.5 * np.log(s7[np.maximum(ti, 0)] / s90[np.maximum(ti, 0)]), np.nan)
    F = np.full((n, 5), np.nan)
    i = np.arange(1344, n)
    F[i, 0] = (x[i] - x[i - 48]) / sig[i]
    F[i, 1] = (x[i] - x[i - 336]) / (sig[i] * math.sqrt(7))
    F[i, 2] = (x[i] - x[i - 1344]) / (sig[i] * math.sqrt(28))
    F[i, 3] = f4[i]
    D = dc_lauf(x, theta_bars(P, C_HAUPT), zustand=True)
    if "modus" in D:
        mo = D["modus"]; t = D["t"]; e = D["e"]
        with np.errstate(divide="ignore", invalid="ignore"):
            dist = np.where(mo == 1, (e - x) / t, (x - e) / t)
        F[:, 4] = np.where(mo != 0, mo * dist, np.nan)
    return F


def _waehle(dist: np.ndarray, kand: np.ndarray, k: int, abstand: int, vorab: int = 4000) -> tuple:
    """
    Die k Nächsten mit Mindestabstand in Bars, gierig in der Reihenfolge des Merkmalsabstands -- wie hl_forecast.analog_forecast
    (dort: jeder neue Kandidat gegen alle schon gewählten). Zuerst nur die vorab Nächsten, reicht das nicht: alle.
    -> (gewählte Bar-Indizes, ihre Abstände)
    """
    import bisect
    if len(dist) == 0:
        return np.zeros(0, np.int64), np.zeros(0)
    m = min(vorab, len(dist))
    while True:
        teil = np.argpartition(dist, m - 1)[:m] if m < len(dist) else np.arange(len(dist))
        reihe = teil[np.argsort(dist[teil], kind="stable")]
        sortiert, wahl = [], []
        for j in reihe:
            i = int(kand[j])
            pos = bisect.bisect_left(sortiert, i)
            if (pos < len(sortiert) and sortiert[pos] - i < abstand) or (pos > 0 and i - sortiert[pos - 1] < abstand):
                continue
            sortiert.insert(pos, i); wahl.append(int(j))
            if len(wahl) >= k:
                break
        if len(wahl) >= k or m == len(dist):
            break
        m = len(dist)
    wahl = np.array(wahl, dtype=np.int64)
    return kand[wahl], dist[wahl]


def p08_analog(P: dict, schritt_tage: int = 1, max_punkte: int | None = None) -> dict:
    """
    Täglich 00 UTC ab 365 Tagen Historie: bestehende Analog-Suche (9 Merkmale, k = 50, Abstand 12) gegen das Regime-Analog
    (5 Merkmale in σ-Einheiten, 150 Nächste, Gauß-Kern, Kish ≥ 20, Ausgänge in σ-Einheiten) und den Zufallsweg N(0, σ̂²h).
    CRPS je Horizont, DM (Bestand − Regime).
    """
    x, ts = P["x"], P["ts"]
    c = np.exp(x)
    n = len(x)
    FB = analog_merkmale_bestand(c, ts)
    FR = analog_merkmale_regime(P)
    sig = np.sqrt(P["s2"][P["tag_i"]])
    tage_start = np.where((ts % TAG) == 0)[0]
    punkte = [t for t in tage_start if t >= max(TRAIN_TAGE * BARS_TAG, 2112 + 400) and t + max(H_ANALOG) < n]
    punkte = punkte[::schritt_tage]
    if max_punkte:
        punkte = punkte[-max_punkte:]
    crps = {h: {"bestand": [], "regime": [], "zufall": []} for h in H_ANALOG}
    kish = []
    for t in punkte:
        fb = FB[t]; fr = FR[t]
        if not (np.all(np.isfinite(fb)) and np.all(np.isfinite(fr)) and sig[t] > 0):
            continue
        kand = np.arange(1440, t - 672, 2)
        okb = np.all(np.isfinite(FB[kand]), axis=1)
        kb = kand[okb]
        if len(kb) < 200:
            continue
        db = np.sqrt(np.sum((FB[kb] - fb) ** 2, axis=1))
        ib, _ = _waehle(db, kb, 50, 12)
        okr = np.all(np.isfinite(FR[kand]), axis=1) & np.isfinite(sig[kand]) & (sig[kand] > 0)
        kr = kand[okr]
        if len(ib) < 15 or len(kr) < 300:
            continue
        mad = np.median(np.abs(FR[kr] - np.median(FR[kr], axis=0)), axis=0) * 1.4826
        mad[mad <= 0] = 1.0
        dr = np.sqrt(np.sum(((FR[kr] - fr) / mad) ** 2, axis=1))
        ir, dsel = _waehle(dr, kr, 150, 12)
        if len(ir) < 30:
            continue
        b = float(np.median(dsel)) or 1.0
        for _ in range(6):
            w = np.exp(-0.5 * (dsel / b) ** 2)
            ne = w.sum() ** 2 / np.sum(w * w)
            if ne >= 20:
                break
            b *= 1.5
        kish.append(ne)
        for h in H_ANALOG:
            y = x[t + h] - x[t]
            rb = x[ib + h] - x[ib]
            u = (x[ir + h] - x[ir]) / (sig[ir] * math.sqrt(h / BARS_TAG))
            rr = u * sig[t] * math.sqrt(h / BARS_TAG)
            crps[h]["bestand"].append(crps_ens(rb, None, y))
            crps[h]["regime"].append(crps_ens(rr, w, y))
            crps[h]["zufall"].append(float(crps_norm(np.array([sig[t] * math.sqrt(h / BARS_TAG)]), np.array([y]))[0]))
    erg = {"h": {}, "n_punkte": len(crps[H_ANALOG[0]]["bestand"]), "kish_median": float(np.median(kish)) if kish else float("nan")}
    for h in H_ANALOG:
        v = {k: np.array(w) for k, w in crps[h].items()}
        if len(v["bestand"]) < 30:
            erg["h"][h] = {"n": len(v["bestand"])}
            continue
        dm = dm_test(v["bestand"] - v["regime"])
        dz_b = dm_test(v["zufall"] - v["bestand"]); dz_r = dm_test(v["zufall"] - v["regime"])
        erg["h"][h] = {"n": len(v["bestand"]), "crps": {k: float(w.mean()) for k, w in v.items()}, "dm": dm, "dm_zufall_bestand": dz_b,
                       "dm_zufall_regime": dz_r}
    erg.update(p08_urteil(erg["h"]))
    return erg


def p08_urteil(hh: dict) -> dict:
    """
    Belegt erst, wenn das Regime-Analog die bestehende Suche UND den Zufallsweg mit σ̂ auf je ≥ 2 von 3 Horizonten schlägt (DM
    p < 0,05, positives Mittel). Gegen die bestehende Suche allein gewinnt schon jede Prognose, die in σ̂-Einheiten rechnet
    (Nulltest auf Zufallsdaten, 07.10.).
    """
    def sieg(v, k):
        return k in v and v[k]["mittel"] > 0 and v[k]["p"] < ALPHA
    siege = sum(1 for h in H_ANALOG if sieg(hh.get(h, {}), "dm"))
    siege_z = sum(1 for h in H_ANALOG if sieg(hh.get(h, {}), "dm_zufall_regime"))
    return {"siege": siege, "siege_zufall": siege_z, "belegt": bool(siege >= 2 and siege_z >= 2)}


# ================================================================================================ P0.9 Bruchmelder (R3)

CUSUM_HWZ = 10 * BARS_TAG               # Referenz: EWMA(a²), Halbwertszeit 10 Tage
CUSUM_NEU = 48                          # nach Alarm: Referenz = Varianz der letzten 24 h, 24 h Sperre für neue Alarme
FA_ZIEL = 1.0                           # Fehlalarme je 30 Tage, beide Melder zusammen
KAPPA_AUF = 4.0                         # Melder „auf“: Schwankung verdoppelt (Varianz ×4)
KAPPA_AB = 0.5                          # Melder „ab“: Varianz halbiert
Z2_KAPPE = 9.0                          # z² gekappt (3 σ): dicke Ränder sonst = Fehlalarme, Schwellen hoch, Melder langsam
H_GITTER = np.round(np.concatenate([np.arange(2.0, 20.0, 0.5), np.arange(20.0, 60.0, 2.0), np.arange(60.0, 120.01, 5.0)]), 2)


def profil_d_voll(P: dict) -> np.ndarray:
    """Profil D (zwei Uhren) auf der ganzen Probe, normiert auf Mittel 1 über die gültigen Bars (für P0.9)."""
    r, s2b = P["r"], P["s2_bar"]
    g = P["rv_ok"] & np.isfinite(r) & np.isfinite(s2b) & (s2b > 0)
    if g.sum() < 30 * BARS_TAG:
        return np.ones(len(r))
    s2 = _profil_form(design(zeitachsen(P["ts"]), "ny"), r, s2b, g)
    return s2 / float(np.mean(s2[g]))


def garch_t_fit(a: np.ndarray) -> dict:
    """GARCH(1,1) mit standardisierten t-Innovationen, Varianz-Targeting, Gitter-Quasi-ML über α, α+β und ν."""
    a = np.asarray(a, dtype=float)
    v0 = float(np.mean(a * a))
    gitter = [(al, pe) for pe in (0.90, 0.95, 0.97, 0.98, 0.99, 0.995, 0.999) for al in (0.01, 0.02, 0.04, 0.06, 0.08, 0.10, 0.13, 0.16, 0.20)
              if pe - al > 0.5]
    al = np.array([g[0] for g in gitter]); be = np.array([g[1] - g[0] for g in gitter]); om = (1 - al - be) * v0
    n = len(a)
    a2 = a * a
    h = np.full(len(gitter), v0)
    H = np.empty((n, len(gitter)))
    for t in range(n):
        H[t] = h
        h = om + al * a2[t] + be * h
    best = None
    for nu in (3.5, 4.0, 5.0, 6.0, 8.0, 12.0):
        k = math.lgamma((nu + 1) / 2) - math.lgamma(nu / 2) - 0.5 * math.log(math.pi * (nu - 2))
        ll = np.sum(k - 0.5 * np.log(H) - (nu + 1) / 2 * np.log1p(a2[:, None] / ((nu - 2) * H)), axis=0)
        j = int(np.argmax(ll))
        if best is None or ll[j] > best["ll"]:
            best = {"ll": float(ll[j]), "alpha": float(al[j]), "beta": float(be[j]), "nu": nu, "var": v0}
    return best


def garch_pfade(g: dict, S: int, n: int, rng) -> np.ndarray:
    """S GARCH(1,1)-t-Pfade der Länge n (Zeilen = Pfade)."""
    al, be, nu, v0 = g["alpha"], g["beta"], g["nu"], g["var"]
    om = (1 - al - be) * v0
    eps = rng.standard_t(nu, size=(S, n)) / math.sqrt(nu / (nu - 2))
    out = np.empty((S, n))
    h = np.full(S, v0)
    for t in range(n):
        out[:, t] = np.sqrt(h) * eps[:, t]
        h = om + al * out[:, t] ** 2 + be * h
    return out


def cusum_lauf(A: np.ndarray, h_auf, h_ab, start: int = CUSUM_HWZ, listen: bool = True):
    """
    CUSUM nach Page für Varianz ×4 (auf: Schwankung verdoppelt) und ×½ (ab) auf A (Spuren × Zeit, auch 1-D). Inkremente
    ℓ = −½ ln κ − z²/2 · (1/κ − 1) mit z² = a²/V, V = EWMA(a²) bis t−1. Nach einem Alarm: beide Summen 0, V = Varianz der letzten
    24 h, 24 h keine neuen Alarme. h_auf, h_ab: Skalar oder je Spur (Kalibrieren über ein Gitter). listen=False: nur Zählung.
    -> (Alarme auf, Alarme ab): Listen von Bar-Indizes je Spur bzw. Anzahlen je Spur.
    """
    A = np.atleast_2d(np.asarray(A, dtype=float))
    S, n = A.shape
    h_auf = np.broadcast_to(np.asarray(h_auf, dtype=float), (S,)); h_ab = np.broadcast_to(np.asarray(h_ab, dtype=float), (S,))
    lam = 0.5 ** (1.0 / CUSUM_HWZ)
    A2 = A * A
    V = np.maximum(A2[:, :start].mean(axis=1), 1e-18) if start > 0 else np.full(S, max(float(np.mean(A2)), 1e-18))
    cs = np.concatenate([np.zeros((S, 1)), np.cumsum(A2, axis=1)], axis=1)
    su = np.zeros(S); sd = np.zeros(S); sperre = np.full(S, -1)
    k_auf = (-0.5 * math.log(KAPPA_AUF), -0.5 * (1.0 / KAPPA_AUF - 1.0))
    k_ab = (-0.5 * math.log(KAPPA_AB), -0.5 * (1.0 / KAPPA_AB - 1.0))
    if listen:
        alarme_auf = [[] for _ in range(S)]; alarme_ab = [[] for _ in range(S)]
    else:
        alarme_auf = np.zeros(S, np.int64); alarme_ab = np.zeros(S, np.int64)
    for t in range(start, n):
        z2 = np.minimum(A2[:, t] / V, Z2_KAPPE)                         # gekappt: ein Ausreißer allein löst nichts aus
        frei = sperre < t
        su = np.where(frei, np.maximum(0.0, su + k_auf[0] + k_auf[1] * z2), 0.0)
        sd = np.where(frei, np.maximum(0.0, sd + k_ab[0] + k_ab[1] * z2), 0.0)
        V = lam * V + (1 - lam) * A2[:, t]
        au = su > h_auf; ab = (sd > h_ab) & ~au
        al = au | ab
        if al.any():
            k = np.where(al)[0]
            if listen:
                for s in k:
                    (alarme_auf if au[s] else alarme_ab)[s].append(t)
            else:
                alarme_auf += au; alarme_ab += ab
            neu = (cs[k, t + 1] - cs[k, max(0, t + 1 - CUSUM_NEU)]) / min(CUSUM_NEU, t + 1)
            V[k] = np.maximum(neu, 1e-18); su[k] = 0.0; sd[k] = 0.0; sperre[k] = t + CUSUM_NEU
    return alarme_auf, alarme_ab


def _kalibrieren(g: dict, rng, S: int = 12, tage: int = 240) -> tuple:
    """
    Schwellen beider Melder auf GARCH-Nullpfaden. Erst je Melder allein die Rate über dem Schwellengitter; daraus Paare mit gleicher
    Einzelrate q. Dann laufen beide gemeinsam (ein Alarm setzt die Referenz neu und kann den Gegenmelder auslösen): gewählt wird
    das empfindlichste Paar mit höchstens FA_ZIEL Fehlalarmen je 30 Tage zusammen.
    """
    n = tage * BARS_TAG
    A = garch_pfade(g, S, n, rng)
    H = len(H_GITTER)
    dauer = (n - CUSUM_HWZ) / BARS_TAG / 30.0
    rate_auf = np.zeros(H); rate_ab = np.zeros(H)
    for j0 in range(0, H, 16):                                          # Gitter in Stücken: Speicher auf dem Pi klein halten
        teil = H_GITTER[j0: j0 + 16]
        k = len(teil)
        rep = np.repeat(A, k, axis=0)
        hh = np.tile(teil, S)
        unendlich = np.full(S * k, np.inf)
        auf, _ = cusum_lauf(rep, hh, unendlich, listen=False)
        _, ab = cusum_lauf(rep, unendlich, hh, listen=False)
        rate_auf[j0: j0 + k] = auf.reshape(S, k).sum(axis=0) / (S * dauer)
        rate_ab[j0: j0 + k] = ab.reshape(S, k).sum(axis=0) / (S * dauer)
        del rep

    def schwelle(rate, q):
        ok = rate <= q
        return float(H_GITTER[int(np.argmax(ok))]) if ok.any() else float(H_GITTER[-1])
    qs = (0.5, 0.4, 0.3, 0.25, 0.2, 0.15, 0.1, 0.07, 0.05, 0.03, 0.02, 0.01)
    paare = [(schwelle(rate_auf, q), schwelle(rate_ab, q)) for q in qs]
    Q = len(paare)
    rep = np.repeat(A, Q, axis=0)
    ha = np.tile([p_[0] for p_ in paare], S); hb = np.tile([p_[1] for p_ in paare], S)
    au, ab = cusum_lauf(rep, ha, hb, listen=False)
    rate = (au + ab).reshape(S, Q).sum(axis=0) / (S * dauer)
    ok = rate <= FA_ZIEL
    k = int(np.argmax(ok)) if ok.any() else Q - 1
    return paare[k]


def p09_bruch(P: dict, seed: int = 0) -> dict:
    """Bruchmelder: GARCH-t-Null je Coin, Schwellen für 1 Fehlalarm je 30 Tage, Prüfung auf neuen Nullpfaden, Verzögerung bei
    Verdopplung der Schwankung (Kriterium) und Halbierung der Varianz, Alarme auf den echten Daten."""
    rng = np.random.default_rng(seed)
    r = P["r"]
    s2 = profil_d_voll(P)
    g_ok = P["rv_ok"] & np.isfinite(r)
    a = np.where(g_ok, np.nan_to_num(r) / np.sqrt(s2), 0.0)
    g = garch_t_fit(a[g_ok])
    h_auf, h_ab = _kalibrieren(g, rng)
    S, tage = 16, 240
    A = garch_pfade(g, S, tage * BARS_TAG, rng)
    au, ab = cusum_lauf(A, h_auf, h_ab, listen=False)
    dauer = (tage * BARS_TAG - CUSUM_HWZ) / BARS_TAG / 30.0
    fa = float(au.sum() + ab.sum()) / (S * dauer)
    S2, n2, tau = 40, 100 * BARS_TAG, 60 * BARS_TAG
    verz = {}
    for name, f in (("verdopplung", 2.0), ("halbierung", 1 / math.sqrt(2.0))):
        A = garch_pfade(g, S2, n2, rng)
        A[:, tau:] *= f
        au_, ab_ = cusum_lauf(A, h_auf, h_ab)
        liste = au_ if f > 1 else ab_
        d = []
        for x in liste:
            nach = [t for t in x if t >= tau]
            d.append((nach[0] - tau) / 2.0 if nach else math.inf)
        d = np.array(d)
        # obere Quantile ohne Interpolation (verpasste Brüche = unendlich, kein inf − inf)
        verz[name] = {"median_h": float(np.quantile(d, 0.5, method="higher")), "q75_h": float(np.quantile(d, 0.75, method="higher")),
                      "verpasst": int(np.sum(~np.isfinite(d)))}
    au_e, ab_e = cusum_lauf(a[None, :], h_auf, h_ab)
    dauer_e = (len(a) - CUSUM_HWZ) / BARS_TAG / 30.0
    letzte = sorted([(t, "auf") for t in au_e[0]] + [(t, "ab") for t in ab_e[0]])[-3:]
    erg = {"garch": g, "h_auf": h_auf, "h_ab": h_ab, "fehlalarme_30t": fa, "verzoegerung": verz,
           "gitter_ende": bool(h_auf >= H_GITTER[-1] or h_ab >= H_GITTER[-1]),
           "echt_auf_30t": len(au_e[0]) / dauer_e if dauer_e > 0 else float("nan"),
           "echt_ab_30t": len(ab_e[0]) / dauer_e if dauer_e > 0 else float("nan"),
           "letzte_alarme": [(int(P["ts"][t]), art) for t, art in letzte]}
    erg["belegt"] = bool(fa <= 1.5 and verz["verdopplung"]["median_h"] <= 12.0)
    return erg


# ================================================================================================ Vorprüfung (alle Coins) und Bericht

def vorpruefung_rechnen(KK: dict, log=print, n_surr: int = N_SURR) -> dict:
    """Alle Prüfungen für die Kerzen je Coin (KK: coin -> Kerzen oder None). Gepoolte Urteile (P0.3 Holm, P0.4, P0.6) am Ende."""
    E = {"coins": {}, "p03": {}, "p04_punkte": [], "PP": {}}
    for coin, K in KK.items():
        info = {"coin": coin}
        if K is None or len(K["ts"]) < 10:
            info["status"] = "keine Historie"
            E["coins"][coin] = info
            continue
        P = vorbereiten(K)
        tage = (int(P["ts"][-1]) - int(P["ts"][0])) / TAG
        luecken = int(np.sum(~P["rv_ok"][1:]))
        info.update({"von": int(P["ts"][0]), "bis": int(P["ts"][-1]), "tage": tage, "kerzen": len(P["ts"]), "luecken": luecken})
        if tage < MIN_TAGE:
            info["status"] = "zu kurz"
            E["coins"][coin] = info
            continue
        info["status"] = "ok"
        t0 = time.time()
        log(f"  {coin}: Profil, Größe, Fenster …")
        info["p01"] = p01_profil(P)
        info["p02"] = p02_groesse(P)
        info["p07"] = p07_fenster(P)
        log(f"  {coin}: Beine gegen {n_surr} Surrogate …")
        E["p03"][coin] = p03_rechnen(P, n_surr=n_surr, seed=zlib.crc32(coin.encode()) % 1000)
        E["p04_punkte"].append(p04_punkte(P, coin))
        log(f"  {coin}: Kalender, Analoge, Bruchmelder …")
        info["p05"] = p05_kalender(P)
        info["p08"] = p08_analog(P)
        info["p09"] = p09_bruch(P, seed=zlib.crc32(coin.encode()) % 1000 + 7)
        info["sekunden"] = time.time() - t0
        if coin in ("BTC", "ETH"):
            E["PP"][coin] = P
        E["coins"][coin] = info
    E["p03_urteil"] = p03_urteil(E["p03"]) if E["p03"] else {"groessen": {}, "persistenz": []}
    E["p04"] = p04_auswerten(E["p04_punkte"]) if E["p04_punkte"] else {"belegt": False, "n": 0}
    E["p06"] = p06_momentum(E["PP"]) if E["PP"] else {"varianten": {}, "belegt": []}
    del E["PP"], E["p04_punkte"]
    return E


def _z(b) -> str:
    return "✓" if b is True else ("–" if b is False else "·")


def bericht_text(E: dict, quellen: dict | None = None, laufzeit: float | None = None, lade: dict | None = None) -> str:
    quellen = quellen or {}
    Z = []
    a = Z.append
    a(f"★ Regime: Vorprüfung auf der Historie (U138, Phase 0) · Modul {VERSION_MODUL}")
    a("Vorab festgelegt in KONZEPT_Regime.md 9.1 und 9.1a (07.10.2026), vor diesem Lauf. Nur Bericht: Prognose, Fusion, v3,")
    a("Kaskaden, Labor und Familien sind unberührt. „Belegt“ heißt: die vorab festgelegte Bedingung ist erfüllt, nicht mehr.")
    if laufzeit is not None:
        a(f"Rechenzeit {_de(laufzeit, 0)} s.")
    a("")
    a("DATEN (eigene Datei regime.db, 30-min-Kerzen der USDT-Perpetuals)")
    ok_coins = []
    for coin, info in E["coins"].items():
        q = QUELLE_NAME.get(quellen.get(coin), quellen.get(coin) or "—")
        st = info.get("status")
        zusatz = ""
        if lade and coin in lade and not lade[coin].get("fertig", True):
            zusatz = "  (Laden noch nicht fertig; der nächste Lauf lädt weiter)"
        if st == "keine Historie":
            a(f"  {coin:<5} " + ("keine Historie (weder Binance-Futures noch Bybit)" if quellen.get(coin) == "keine"
                                 else "keine Kerzen in regime.db (noch nicht geladen)"))
            continue
        if st in ("Laden unvollständig", "Laden fehlgeschlagen"):
            fehler = (lade or {}).get(coin, {}).get("fehler")
            a(f"  {coin:<5} {st}" + (f" ({fehler})" if fehler else "") + " -- der nächste Lauf lädt weiter, dann wird geprüft")
            continue
        zeile = (f"  {coin:<5} {q:<16} {_datum(info['von'])}–{_datum(info['bis'])}  {_de(info['tage'], 0)} Tage  "
                 f"{info['kerzen']:,} Kerzen".replace(",", ".") + f"  Lücken {info['luecken']}")
        if st == "zu kurz":
            zeile += f"  -> zu kurz (nötig {MIN_TAGE} Tage), nur Daten"
        else:
            ok_coins.append(coin)
        a(zeile + zusatz)
    a("")
    if not ok_coins:
        a("Kein Coin mit genug Historie -- keine Prüfung.")
        return "\n".join(Z)
    C = E["coins"]
    U3 = E["p03_urteil"]
    a("PRÜFSTAND  (✓ belegt · – nicht belegt · · nicht geprüft)")
    a("                                   " + "".join(f"{c:>6}" for c in ok_coins))
    p4 = E["p04"]; p6 = E["p06"]
    m6 = {c: [L for (cc, L) in p6.get("belegt", []) if cc == c] for c in ok_coins}
    hat6 = {c: any(k[0] == c for k in p6.get("varianten", {})) for c in ok_coins}
    zeilen = [("P0.1 Zwei-Uhren-Profil (R1)", lambda c: C[c]["p01"]["belegt"]),
              ("P0.2 Bewegungsgröße (R2)", lambda c: C[c]["p02"]["belegt"]),
              ("P0.3 Beine: Abweichungen (R4)", lambda c: sum(1 for g in BEIN_GROESSEN for (cc, _) in U3["groessen"].get(g, []) if cc == c)),
              ("P0.3 Persistenz der Asymmetrie", lambda c: any(cc == c for cc, _ in U3["persistenz"])),
              ("P0.4 Beinende (gepoolt)", None),
              ("P0.5 Kalender K1–K3 (R5)", lambda c: ",".join(C[c]["p05"]["belegt_k"]) or False),
              ("P0.5 Stunden/Wochentage", lambda c: len(C[c]["p05"]["belegt_zeit"])),
              ("P0.5 Persistenz (HKS)", lambda c: C[c]["p05"]["persistenz"]["belegt"]),
              ("P0.6 Wochenmomentum (R6)", lambda c: ("L " + "/".join(str(x) for x in m6[c])) if m6[c] else (False if hat6[c] else None)),
              ("P0.7 Fensterkombination", lambda c: C[c]["p07"]["belegt"]),
              ("P0.8 Regime-Analog (R8a)", lambda c: C[c]["p08"]["belegt"]),
              ("P0.9 Bruchmelder (R3)", lambda c: C[c]["p09"]["belegt"])]
    for name, f in zeilen:
        if f is None:
            a(f"  {name:<33}{_z(p4.get('belegt')):>6}   (ein Urteil über alle Coins)")
            continue
        werte = []
        for c in ok_coins:
            v = f(c)
            werte.append(_z(v) if isinstance(v, bool) or v is None else str(v))
        a(f"  {name:<33}" + "".join(f"{w:>6}" for w in werte))
    a("  Zahlen bei P0.3: belegte Abweichungen von 6 Größen × 5 Schwellen; bei Stunden/Wochentagen: belegte von 31. P0.6 nur BTC, ETH.")
    a("")
    # ---------------------------------------------------------------- P0.1
    a("P0.1 ZWEI-UHREN-PROFIL -- Varianz je 30-min-Bar; D (New York + UTC-Funding) gegen A flach, B UTC, C heutiges Zeitprofil.")
    a("  Gewinn = mittlerer QLIKE-Vorsprung von D je Bar (halbe Differenz = Log-Likelihood je Bar), Anteil der Monate mit Gewinn, t-Test.")
    for c in ok_coins:
        e = C[c]["p01"]
        teile = []
        for g, n_ in (("A", "flach"), ("B", "UTC"), ("C", "heute")):
            v = e["vergleiche"][g]
            teile.append(f"gegen {n_} {_de(v['mittel'], 4, True)} ({_de(v['anteil'] * 100 if math.isfinite(v['anteil']) else float('nan'), 0)} % der "
                         f"Monate, p {_pz(v['p'])})")
        a(f"  {c:<5} {e['monate']} Monate: " + "; ".join(teile) + f" -> {_z(e['belegt'])}")
        b = e.get("buckel") or {}
        if b.get("sommer") and b.get("winter"):
            vz = b.get("versatz_h")
            deutung = ("folgt New York" if vz is not None and 0.5 <= vz <= 1.5 else "bleibt in UTC" if vz is not None and abs(vz) < 0.5
                       else "uneindeutig")
            a(f"        Werktags-Buckel: Sommerzeit {b['sommer']['uhr_utc']} UTC, Winterzeit {b['winter']['uhr_utc']} UTC; "
              f"Versatz {_de(vz, 2, True)} h -> {deutung}")
    a("")
    # ---------------------------------------------------------------- P0.2
    a("P0.2 BEWEGUNGSGRÖSSE -- HAR gegen EWMA und gegen die 7-Tage-Schwankung des heutigen Bands (QLIKE, kleiner = besser).")
    a("  Band = Anteil der Renditen im 80-%-Band (Soll 80 % ± 2 SE); Berühren = Steigung beobachtet gegen Soll 2[1 − Φ(k)] (0,8–1,2);")
    a("  Spannweite = realisiert ÷ 1,60·√V (1 = wie der Zufallsweg).")
    for c in ok_coins:
        e = C[c]["p02"]
        a(f"  {c:<5} -> {_z(e['belegt'])}  (HAR besser als EWMA bei 1 und 7 T: {_z(e['har_besser'])}, Band: {_z(e['band_ok'])}, "
          f"Berühren: {_z(e['touch_ok'])})")
        for h in H_GROESSE:
            v = e["h"].get(h, {})
            if "qlike" not in v:
                a(f"        {h} T: zu wenig Tage ({v.get('n', 0)})")
                continue
            q = v["qlike"]
            a(f"        {h} T: QLIKE HAR {_de(q['har'], 3)} · EWMA {_de(q['ewma'], 3)} (p {_pz(v['dm_ewma']['p'])}) · 7 T {_de(q['s7'], 3)} "
              f"(p {_pz(v['dm_s7']['p'])}) · Band {_de(v['band'] * 100, 1)} % ± {_de(2 * v['band_se'] * 100, 1)} · Berühren "
              f"{_de(v['touch_steigung'], 2)} · Spannweite {_de(v['spannweite'], 2)}")
    a("")
    # ---------------------------------------------------------------- P0.3
    a("P0.3 BEINE GEGEN DIE ZUFALLSGEOMETRIE -- je Coin und c (θ = c·σ̂_Tag) gegen 100 Vorzeichen-Surrogate mit gleicher Drift.")
    a("  Belegt: Holm über Coins × c, p < 0,05, gleiches Vorzeichen in beiden Hälften.")
    def _zelle(cc, cv, g):
        z = E["p03"].get(cc, {}).get("c", {}).get(cv, {})
        o, m = z.get("obs", {}).get(g), z.get("null_m", {}).get(g)
        return f"{cc} c {_de(cv, 2)} ({_de(o, 2)} gegen {_de(m, 2)})" if o is not None and m is not None else f"{cc} c {_de(cv, 2)}"
    for g in BEIN_GROESSEN:
        bel = U3["groessen"].get(g, [])
        a(f"  {BEIN_NAME[g]:<38} Soll (Zufallsweg) {_de(BEIN_SOLL[g], 2)}; belegt: "
          + (", ".join(_zelle(cc, cv, g) for cc, cv in bel) if bel else "keine"))
    if any(U3["groessen"].get(g) for g in BEIN_GROESSEN):
        a("  (Klammer: beobachtet gegen das Mittel der Surrogate; seit 23.60)")
    a(f"  Stufen bei c = {_de(C_HAUPT, 1)} (beschreibend):")
    for c in ok_coins:
        e = E["p03"].get(c, {})
        s = e.get("stufen")
        z = e.get("c", {}).get(C_HAUPT)
        if not s or not z:
            continue
        o, m = z["obs"], z["null_m"]
        a(f"    {c:<5} θ ≈ {_de(s['theta_med_pct'], 1)} %, {_de(s['beine_4w'], 1)} Beine je 4 Wochen, Bein median {_de(s['groesse_med_pct'], 1)} % "
          f"in {_de(s['dauer_med_tage'], 1)} T (auf {_de(s['auf_med_pct'], 1)} %, ab {_de(s['ab_med_pct'], 1)} %); P(höheres Tief) "
          f"{_de(o['p_hl'], 2)} (Surrogate {_de(m['p_hl'], 2)}), P(höheres Hoch | höheres Tief) {_de(o['p_hh_hl'], 2)} ({_de(m['p_hh_hl'], 2)}), "
          f"Überschießen {_de(o['ueberschiessen'], 2)} ({_de(m['ueberschiessen'], 2)}), z {_de(z['z']['ueberschiessen'], 1, True)}")
    a("  Persistenz (Asymmetrie der letzten 4 bzw. 8 Wochen gegen die der folgenden 4 Wochen, c = 1,5):")
    for c in ok_coins:
        e = E["p03"].get(c, {}).get("persistenz", {})
        if not e:
            continue
        a(f"    {c:<5} " + "; ".join(f"{W // 7} W: ρ {_de(v.get('rho'), 2, True)} (Surrogate {_de(v.get('null_m'), 2, True)}), p {_pz(v.get('p'))}, "
                                     f"p Holm {_pz(v.get('p_holm'))} -> {_z(v.get('belegt'))}" for W, v in e.items()))
    a("")
    # ---------------------------------------------------------------- P0.4
    a("P0.4 BEINENDE -- „Ist das laufende Extremum schon endgültig?“ (c = 1,5, alle 4 h bei D/θ 0,1–0,9), gepoolt über die Coins.")
    if p4.get("n_punkte"):
        mm = p4["mittel"]
        a(f"  {p4['n_punkte']:,} Prognosepunkte in {p4['n_beine']:,} Beinen".replace(",", ".")
          + f", Abdeckung {_de(p4['abdeckung'] * 100, 0)} % der Beine, Ereignisquote {_de(p4['y_quote'] * 100, 1)} %.")
        a(f"  Log-Verlust: roh D/θ {_de(mm['roh']['log'], 4)} · kalibriert {_de(mm['basis']['log'], 4)} · Modell {_de(mm['modell']['log'], 4)}; "
          f"Brier {_de(mm['roh']['brier'], 4)} · {_de(mm['basis']['brier'], 4)} · {_de(mm['modell']['brier'], 4)}")
        bm = p4["basis_gegen_modell"]; rb = p4["roh_gegen_basis"]
        a(f"  Modell gegen kalibrierte Baseline (DM über Beine): log p {_pz(bm['log']['p'])}, Brier p {_pz(bm['brier']['p'])} -> {_z(p4['belegt'])}")
        a(f"  Kalibrierte Baseline gegen roh D/θ: log p {_pz(rb['log']['p'])} (Vorzeichen {'+' if rb['log']['mittel'] > 0 else '−'}: "
          f"{'Kalibrieren hilft' if rb['log']['mittel'] > 0 else 'roh ist besser'})")
        if p4.get("gewichte"):
            a("  Mittlere Gewichte (standardisiert): " + ", ".join(f"{P04_NAME[k]} {_de(v, 2, True)}" for k, v in p4["gewichte"].items()))
    else:
        a("  zu wenig Prognosepunkte.")
    a("")
    # ---------------------------------------------------------------- P0.5
    a("P0.5 KALENDER -- Mittel mit HAC-Fehler; K1–K3 mit Holm; Stunden und Wochentage mit Benjamini-Hochberg (q 0,10); dazu je Jahr.")
    a("  K3 seit 23.60 je Stunde: Sitzung 9:30–16:00 New York minus Rest seit 16:00 des Vorhandelstags, der Rest auf 6,5 h skaliert.")
    a("  Bis 23.59 roh (Sitzung minus ganzer Rest): schon die Drift zog K3 ins Minus (Rest im Mittel 27,1 h, Sitzung 6,5 h).")
    a("  Vorsicht bei Stunden/Wochentagen: BH mit q 0,10 lässt je Coin in rund jedem zehnten Lauf ohne jeden Effekt einen Zufallstreffer")
    a("  durch. Ein einzelner Treffer ist kein Befund; zählen würde dieselbe Stunde in mehreren Coins oder eine vorab genannte (K1–K3).")
    for c in ok_coins:
        e = C[c]["p05"]
        teile = []
        for k in ("K1", "K2", "K3"):
            v = e["K"][k]
            teile.append(f"{k} {_de(v['mittel'] * 1e4, 1, True)} bp ± {_de(v['se'] * 1e4, 1)} (n {v['n']}, p Holm {_pz(v.get('p_holm'))}, "
                         f"Jahre {'gleich' if v['jahr_ok'] else 'wechselnd'}) {_z(v['belegt'])}")
        a(f"  {c:<5} " + "; ".join(teile))
        kr = e.get("K3_roh")
        if kr:
            a(f"        K3 roh wie bis 23.59 (driftbehaftet, nur Anzeige): {_de(kr['mittel'] * 1e4, 1, True)} bp ± {_de(kr['se'] * 1e4, 1)}"
              + (f"; die Drift allein ergäbe {_de(kr['drift_anteil'] * 1e4, 1, True)} bp (Drift im Zeitraum {_de(e['drift_tag'] * 1e4, 1, True)} bp "
                 f"je Tag; bei K1 ergäbe sie {_de(e['drift_tag'] * 1e4 / 8, 1, True)} bp, bei K2 {_de(e['drift_tag'] * 1e4 / 4, 1, True)} bp)"
                 if "drift_anteil" in kr else ""))
        rob = [(k, e["K"][k]["robust"]) for k in ("K1", "K2", "K3")
               if e["K"][k].get("robust") and math.isfinite(e["K"][k].get("p_holm", float("nan"))) and e["K"][k]["p_holm"] < ALPHA]
        if rob:
            a("        robust (beschreibend): " + "; ".join(
                f"{k} Median {_de(r['median'] * 1e4, 1, True)} bp, ohne je 2,5 % Ränder {_de(r['getrimmt'] * 1e4, 1, True)} bp, "
                f"negativ {_de(r['negativ'] * 100, 0)} %, je Jahr "
                + ", ".join(f"{j} {_de(m * 1e4, 1, True)} ({nn})" for j, m, nn in e["K"][k].get("jahre", []))
                for k, r in rob))
        st = [t for t in e["stunden"] + e["wochentage"] if t.get("bh")]
        a(f"        Stunden/Wochentage: {sum(1 for t in st if t['belegt'])} belegt, {len(st)} nach BH auffällig"
          + (": " + ", ".join(f"{t['name']} {_de(t['mittel'] * 1e4, 1, True)} bp" for t in st[:6]) if st else ""))
        pe = e["persistenz"]
        a(f"        Persistenz (HKS): Steigung {_de(pe.get('mittel'), 3, True)}, p {_pz(pe.get('p'))} -> {_z(pe.get('belegt'))}")
        acht = e.get("acht_wochen", {})
        if acht:
            a("        Letzte 8 Wochen (beschreibend): " + "; ".join(f"{k} {v['negativ']} von {v['n']} negativ, Mittel {_de(v['mittel'] * 1e4, 1, True)} bp"
                                                              for k, v in acht.items()))
    a("")
    # ---------------------------------------------------------------- P0.6
    a("P0.6 WOCHENMOMENTUM -- montags für 7 Tage; Brier gegen die Basisrate (Holm über 6), Timing-Regel long/flat mit Kosten: DSR, PBO.")
    if p6.get("varianten"):
        a(f"  PBO über alle Varianten {_de(p6.get('pbo'), 2)} (belegt nur bei ≤ 0,05)")
        for (coin, L), v in p6["varianten"].items():
            a(f"  {coin:<5} L {L:>2}: Brier {_de(v['brier_m'], 4)} gegen {_de(v['brier_b'], 4)} (p Holm {_pz(v.get('p_holm'))}), "
              f"Sharpe {_de(v.get('sr_jahr'), 2, True)} je Jahr, DSR {_de(v.get('dsr'), 2)}, {v['n']} Wochen -> {_z(v.get('belegt'))}")
    else:
        a("  BTC/ETH ohne genug Historie.")
    a("")
    # ---------------------------------------------------------------- P0.7
    a("P0.7 FENSTER -- Tagesvarianz: 2/4/8 Wochen, EWMA, Historie gegen Fixed Share (R3) und das einfache Mittel (QLIKE).")
    for c in ok_coins:
        e = C[c]["p07"]
        teile = []
        for h in (1, 7):
            v = e["h"].get(h, {})
            if "qlike" not in v:
                continue
            q = v["qlike"]
            teile.append(f"{h} T: bestes {v['bester']} {_de(q[v['bester']], 3)}, Fixed Share {_de(q['Fixed Share'], 3)} "
                         f"(Abstand {_de(v['abstand'], 3, True)} ± {_de(v['se'], 3)}), Mittel {_de(q['Mittel'], 3)}")
        a(f"  {c:<5} " + "; ".join(teile) + f" -> {_z(e['belegt'])}")
    a("")
    # ---------------------------------------------------------------- P0.8
    a("P0.8 REGIME-ANALOG -- CRPS (kleiner = besser) täglich um 00 UTC: bestehende Analog-Suche, Regime-Analog, Zufallsweg mit σ̂.")
    a("  Belegt: Regime-Analog schlägt die bestehende Suche UND den Zufallsweg auf ≥ 2 von 3 Horizonten (DM p < 0,05).")
    for c in ok_coins:
        e = C[c]["p08"]
        teile = []
        for h in H_ANALOG:
            v = e["h"].get(h, {})
            if "crps" not in v:
                continue
            q = v["crps"]
            teile.append(f"{h // 2} h: {_de(q['bestand'] * 100, 2)} / {_de(q['regime'] * 100, 2)} / {_de(q['zufall'] * 100, 2)} "
                         f"(p {_pz(v['dm']['p'])}; gegen Zufall p {_pz(v['dm_zufall_regime']['p'])}; "
                         f"Bestand gegen Zufall p {_pz(v.get('dm_zufall_bestand', {}).get('p'))})")
        a(f"  {c:<5} {e['n_punkte']} Tage, Kish {_de(e['kish_median'], 0)}: " + "; ".join(teile) + f" -> {_z(e['belegt'])}")
    a("  (CRPS in Prozentpunkten der Rendite: bestehend / Regime / Zufall; p: Regime gegen Bestand, Regime gegen Zufall und seit 23.60")
    a("   Bestand gegen Zufall -- der Nachbau der Analog-Suche der Prognose, beschreibend für die Auswertung nach dem 25.10.)")
    a("")
    # ---------------------------------------------------------------- P0.9
    a("P0.9 BRUCHMELDER -- CUSUM auf Profil-bereinigten 30-min-Renditen, Schwellen auf GARCH-t-Nullpfaden für 1 Fehlalarm je 30 Tage.")
    a("  Belegt: auf neuen Nullpfaden ≤ 1,5 Fehlalarme je 30 Tage und Verdopplung der Schwankung im Median nach ≤ 12 h gemeldet.")
    for c in ok_coins:
        e = C[c]["p09"]
        g = e["garch"]; v = e["verzoegerung"]
        a(f"  {c:<5} GARCH α {_de(g['alpha'], 2)}, β {_de(g['beta'], 3)}, ν {_de(g['nu'], 1)}; Schwellen {_de(e['h_auf'], 1)}/{_de(e['h_ab'], 1)}"
          + (" (Gitterende)" if e.get("gitter_ende") else "")
          + f"; Fehlalarme {_de(e['fehlalarme_30t'], 2)} je 30 T; Verdopplung median {_de(v['verdopplung']['median_h'], 1)} h, "
          f"Halbierung {_de(v['halbierung']['median_h'], 1)} h; echte Daten: {_de(e['echt_auf_30t'], 2)} auf / {_de(e['echt_ab_30t'], 2)} ab je 30 T "
          f"-> {_z(e['belegt'])}")
    a("")
    a("Lesart: Belegtes wird Kandidat für Phase 1 (Schatten). Nicht Belegtes kann als Anzeige mitlaufen, markiert als „nicht belegt“.")
    a("In die Fusion kommt nur, was hier belegt ist und vorwärts besteht (KONZEPT_Regime.md 9.1, frühestens nach dem 25.10.).")
    return "\n".join(Z)


# ================================================================================================ Selbsttest (ohne Netz)

_START_TEST = 1696118400                # 01.10.2023 00:00 UTC: Sommer- und Winterzeiten, Jahreswechsel


def _markt(tage: int = 730, seed: int = 1, sigma_tag: float = 0.025, profil: str = "utc", drift_tag: float = 0.0, fett: bool = True,
           phi_u: float = 0.97, sd_u: float = 0.12, start: int = _START_TEST, extra=None) -> dict:
    """
    Synthetischer Markt in 30-min-Kerzen: Tagesschwankung als log-AR(1) (Schwankungsregime), Tagesprofil „utc“ (Buckel 15 UTC),
    „ny“ (Buckel 10:30 New York, wandert mit der Sommerzeit) oder „flach“, Funding-Spitze 0/8/16 UTC, t(5)- oder Normal-
    Innovationen; extra(ts, r, rng, sb) pflanzt Effekte ein (sb = wahre Bar-Schwankung).
    """
    rng = np.random.default_rng(seed)
    n = tage * BARS_TAG
    ts = start + np.arange(n, dtype=np.int64) * BAR
    u = np.zeros(tage)
    for d in range(1, tage):
        u[d] = phi_u * u[d - 1] + rng.normal(0, sd_u)
    sig_d = sigma_tag * np.exp(u - u.mean())
    Z = zeitachsen(ts)
    s2 = np.ones(n)
    if profil in ("utc", "ny"):
        tod = Z["utc_tod"] if profil == "utc" else Z["ny_tod"]
        wd = Z["utc_wd"] if profil == "utc" else Z["ny_wd"]
        mitte = 15.0 / 24 if profil == "utc" else 10.5 / 24
        buckel = np.exp(-0.5 * ((tod - mitte) / (1.5 / 24)) ** 2)
        s2 = (1.0 + 2.0 * buckel * (wd < 5)) * np.where(wd >= 5, 0.6, 1.0)
        s2 = s2 * np.where(np.isin(Z["utc_auf"], FUND_NACH), 1.8, 1.0)
        s2 = s2 / s2.mean()
    eps = rng.standard_t(5, n) / math.sqrt(5 / 3) if fett else rng.normal(0, 1, n)
    sb = sig_d[np.arange(n) // BARS_TAG] / math.sqrt(BARS_TAG) * np.sqrt(s2)
    r = drift_tag / BARS_TAG + sb * eps
    if extra is not None:
        r = extra(ts, r, rng, sb)
    x = 4.0 + np.cumsum(r)
    c = np.exp(x)
    o = np.exp(np.concatenate([[4.0], x[:-1]]))
    h = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 0.3, n)) * sb)
    l = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 0.3, n)) * sb)
    return {"ts": ts, "o": o, "h": h, "l": l, "c": c, "v": np.ones(n)}


def _x_trends(staerke: float = 0.006, dauer_tage: int = 21):
    """Trendregime: Drift ±staerke je Tag, Vorzeichen wechselt zufällig alle dauer_tage."""
    def f(ts, r, rng, sb):
        d = np.arange(len(r)) // (BARS_TAG * dauer_tage)
        vz = rng.choice(np.array([-1.0, 1.0]), size=int(d.max()) + 1)
        return r + vz[d] * staerke / BARS_TAG
    return f


def _x_rueckkopplung(staerke: float, fenster_tage: int, vorzeichen: float):
    """Drift ∝ tanh der Rendite der letzten fenster_tage in Einheiten der wahren Schwankung: vorzeichen −1 Umkehr, +1 Momentum."""
    def f(ts, r, rng, sb):
        out = r.copy(); n = len(r); x = np.zeros(n)
        w = fenster_tage * BARS_TAG
        sd_tag = sb * math.sqrt(BARS_TAG)
        for i in range(1, n):
            if i > w:
                z = (x[i - 1] - x[i - 1 - w]) / (sd_tag[i] * math.sqrt(fenster_tage))
                out[i] = r[i] + vorzeichen * staerke * sd_tag[i] / BARS_TAG * math.tanh(z)
            x[i] = x[i - 1] + out[i]
        return out
    return f


def _x_k1(bp: float):
    """K1-Effekt: bp Basispunkte je Nacht zwischen 02 und 05 Uhr Berliner Zeit, gleich verteilt auf die sechs Bars."""
    def f(ts, r, rng, sb):
        lok = (ts + _offsets(ts, TZ_BERLIN)) % TAG
        return r + np.where((lok >= 2 * 3600) & (lok < 5 * 3600), bp * 1e-4 / 6, 0.0)
    return f


def _x_k3(bp: float):
    """K3-Effekt (23.60): bp Basispunkte je US-Kernsitzung (Mo–Fr 9:30–16:00 New York), gleich verteilt auf ihre 13 Bars."""
    def f(ts, r, rng, sb):
        Z = zeitachsen(ts)
        im = (Z["ny_auf"] >= 9 * 3600 + 1800) & (Z["ny_auf"] < 16 * 3600) & (Z["ny_wd"] < 5)
        return r + np.where(im, bp * 1e-4 / 13, 0.0)
    return f


def _x_vol_stufen(dauer_tage: int = 20, faktor: float = 3.0):
    def f(ts, r, rng, sb):
        d = np.arange(len(r)) // (BARS_TAG * dauer_tage)
        lvl = np.where(rng.random(int(d.max()) + 1) < 0.5, 1.0, faktor)
        return r * lvl[d]
    return f


def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name:<70} {text}", flush=True)

    rng = np.random.default_rng(3)
    # 1) Rechenbausteine
    xs = np.linspace(-6, 6, 241)
    f_phi = max(abs(float(phi(np.array([v]))[0]) - phi_s(v)) for v in xs)
    t_ok = abs(t_p2(2.0, 10) - 0.07339) < 2e-4 and abs(t_p2(1.96, 1e6) - 0.05) < 1e-3 and abs(ppf(0.975) - 1.959964) < 1e-6
    hh = holm([0.01, 0.04, 0.03, float("nan")])
    bb = bh([0.001, 0.02, 0.03, 0.04, 0.5], 0.10)
    xe = rng.normal(0, 1, 60); we = rng.random(60); ye = 0.3
    brute = float(np.sum(we / we.sum() * np.abs(xe - ye)) - 0.5 * np.sum(np.outer(we / we.sum(), we / we.sum()) * np.abs(xe[:, None] - xe[None, :])))
    gg = np.linspace(-12, 12, 200001); sg = 1.7; yy = 0.9
    numer = float(np.sum((phi(gg / sg) - (gg >= yy)) ** 2) * (gg[1] - gg[0]))
    ok("Bausteine: Φ, Quantil, t-Verteilung, Holm, BH, CRPS (Stichprobe, Normal)",
       f_phi < 2e-7 and t_ok and hh[:3] == [0.03, 0.06, 0.06] and math.isnan(hh[3]) and bb == [True, True, True, True, False]
       and abs(crps_ens(xe, we, ye) - brute) < 1e-12 and abs(float(crps_norm(np.array([sg]), np.array([yy]))[0]) - numer) < 1e-4,
       f"Φ-Fehler {f_phi:.1e}, Holm {hh[:3]}")
    # DM (Coroneo-Iacone) auf unabhängigen Verlustdifferenzen: Fehlurteile nahe 5 %
    fehl = sum(1 for k in range(300) if dm_test(np.random.default_rng(1000 + k).normal(0, 1, 150))["p"] < 0.05)
    se_iid = nw_se(np.random.default_rng(7).normal(0, 2, 4000), 5)
    fehl_ar = 0
    for k in range(300):
        g_ = np.random.default_rng(5000 + k); e_ = g_.normal(0, 1, 300); d_ = np.zeros(300)
        for i in range(1, 300):
            d_[i] = 0.5 * d_[i - 1] + e_[i]
        fehl_ar += dm_test(d_)["p"] < 0.05
    ok("DM-Test: Fehlurteile auf Rauschen 2–9 % (T = 150), bei autokorrelierten Differenzen (AR 0,5, T = 300) ≤ 12 %; Newey-West ≈ σ/√n",
       6 <= fehl <= 27 and fehl_ar <= 36 and abs(se_iid - 2 / math.sqrt(4000)) < 0.004,
       f"{fehl / 3:.1f} % bzw. {fehl_ar / 3:.1f} %, SE {se_iid:.4f} (Soll {2 / math.sqrt(4000):.4f})")
    # 2) Datenhaltung und Laden ohne Netz (Quellen ersetzt)
    import tempfile
    tmp = tempfile.mkdtemp(prefix="hl_regime_test_")
    try:
        con = verbinden(os.path.join(tmp, "regime.db"))
        jetzt = _START_TEST + 1200 * TAG + 7 * 3600 + 600
        start_test = (jetzt - HIST_TAGE * TAG) // BAR * BAR
        aufrufe = []

        def f_bin(coin, s_ms, e_ms):
            aufrufe.append(("binance", coin))
            if coin == "XYZ":
                raise KeinSymbol("Invalid symbol")
            beginn = start_test + 500 * TAG                              # Binance erst ab Tag 500
            a_ = max(int(s_ms // 1000), beginn); a_ = (a_ + BAR - 1) // BAR * BAR
            e_ = int(e_ms // 1000)
            tt = np.arange(a_, min(e_, a_ + 999 * BAR) + 1, BAR)
            return [(int(t), 1.0, 1.1, 0.9, 1.0 + (t % 7) * 1e-3, 5.0) for t in tt], 10

        def f_byb(coin, s_ms, e_ms):
            aufrufe.append(("bybit", coin))
            if coin == "XYZ":
                raise KeinSymbol("10001")
            a_ = max(int(s_ms // 1000), start_test + 30 * TAG); a_ = (a_ + BAR - 1) // BAR * BAR
            e_ = min(int(e_ms // 1000), int(s_ms // 1000) + 999 * BAR)
            tt = np.arange(a_, e_ + 1, BAR)
            return [(int(t), 2.0, 2.2, 1.8, 2.0, 7.0) for t in tt], 0
        alt_q = dict(QUELLEN)
        alt_sleep = time.sleep
        QUELLEN["binance"] = f_bin; QUELLEN["bybit"] = f_byb
        time.sleep = lambda s: None
        try:
            l1 = laden(con, "AAA", budget_s=600, log=lambda *a_: None, jetzt=jetzt)
            n1 = con.execute("SELECT COUNT(*), MIN(ts), MAX(ts) FROM rg_klines WHERE coin='AAA'").fetchone()
            l2 = laden(con, "AAA", budget_s=600, log=lambda *a_: None, jetzt=jetzt)
            l3 = laden(con, "XYZ", budget_s=600, log=lambda *a_: None, jetzt=jetzt)
            l4 = laden(con, "BBB", budget_s=0.0, log=lambda *a_: None, jetzt=jetzt)
        finally:
            QUELLEN.update(alt_q); time.sleep = alt_sleep
        letzte_zu = (jetzt // BAR) * BAR - BAR
        soll_n = (letzte_zu - (start_test + 30 * TAG)) // BAR + 1
        Kt = kerzen(con, "AAA")
        ok("Laden ohne Netz: Quelle mit längerer Historie (Bybit), lückenlos bis zur letzten fertigen Kerze, zweiter Lauf nichts "
           "Neues, unbekanntes Symbol, Zeitbudget",
           l1["quelle"] == "bybit" and l1["fertig"] and n1[0] == soll_n and n1[2] == letzte_zu and l2["neu"] == 0
           and meta(con, "quelle:AAA") == "bybit" and l3["quelle"] is None and l3["fertig"] and meta(con, "quelle:XYZ") == "keine"
           and not l4["fertig"] and Kt is not None and len(Kt["ts"]) == soll_n and float(Kt["c"][0]) == 2.0,
           f"{n1[0]} Kerzen (Soll {soll_n}), Quelle {l1['quelle']}")
        con.close()
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    # 2b) Parser gegen die dokumentierten Antwortformate (Binance /fapi/v1/klines, Bybit /v5/market/kline)
    global _http_json
    alt_http = _http_json
    antworten = {
        "binance": ([[1499040000000, "0.01634790", "0.80000000", "0.01575800", "0.01577100", "148976.11427815", 1499044799999,
                      "2434.19055334", 308, "1756.87402397", "28.46694368", "0"]], {"X-MBX-USED-WEIGHT-1M": "57"}),
        "bybit": ({"retCode": 0, "retMsg": "OK", "result": {"symbol": "BTCUSDT", "category": "linear", "list": [
            ["1670608800000", "17071", "17073", "17027", "17055.5", "268611", "15.74462667"],
            ["1670607000000", "17071.5", "17071.5", "17061", "17071", "4177", "0.24469757"]]}}, {}),
        "fehler": ({"retCode": 10001, "retMsg": "params error: symbol invalid", "result": {}}, {})}
    wahl = {"k": "binance"}
    _http_json = lambda url, timeout=25.0: antworten[wahl["k"]]
    try:
        zb, gw = _binance_kerzen("BTC", 1499040000000, 1499050000000)
        wahl["k"] = "bybit"; zy, _ = _bybit_kerzen("BTC", 1670607000000, 1670610000000)
        wahl["k"] = "fehler"
        try:
            _bybit_kerzen("XYZ", 0, 1)
            kein = False
        except KeinSymbol:
            kein = True
    finally:
        _http_json = alt_http
    ok("Parser: Binance- und Bybit-Kerzen nach den dokumentierten Formaten (Zeit in s, aufsteigend), Gewichtsangabe, ungültiges Symbol",
       zb == [(1499040000, 0.0163479, 0.8, 0.015758, 0.015771, 148976.11427815)] and gw == 57 and [z[0] for z in zy] == [1670607000, 1670608800]
       and zy[1][4] == 17055.5 and kein, f"{len(zb)} + {len(zy)} Kerzen")
    # 3) Aufbereitung und Kausalität
    K = _markt(tage=120, seed=5)
    K2 = {k: v.copy() for k, v in K.items()}
    loch = 60 * BARS_TAG + 10
    K2 = {k: np.delete(v, loch) for k, v in K2.items()}                     # eine fehlende Kerze am Tag 60
    P = vorbereiten(K2)
    d60 = 60
    r_soll = np.log(K["c"][60 * BARS_TAG: 61 * BARS_TAG]) - np.log(np.concatenate([[K["c"][60 * BARS_TAG - 1]], K["c"][60 * BARS_TAG: 61 * BARS_TAG - 1]]))
    gueltig = np.ones(BARS_TAG, bool); gueltig[10] = False; gueltig[11] = False      # Rendite über die Lücke zählt nicht
    rv_soll = float(np.sum(r_soll[gueltig] ** 2) * BARS_TAG / gueltig.sum())
    Kz = {k: v.copy() for k, v in K.items()}
    Kz["c"][80 * BARS_TAG:] *= np.exp(rng.normal(0, 0.05, len(Kz["c"]) - 80 * BARS_TAG))
    Pa, Pz = vorbereiten(K), vorbereiten(Kz)
    th = theta_bars(Pa, 1.5)
    Da = dc_lauf(Pa["x"], th, zustand=True); Dz = dc_lauf(Pz["x"], th, zustand=True)
    gr = 80 * BARS_TAG - 1
    Fa, Fz = analog_merkmale_regime(Pa), analog_merkmale_regime(Pz)
    xz = kurs_zum(Pa)
    ok("Aufbereitung: Lücke zählt nicht zur Tagesvarianz; σ̂, DC-Zustand und Regime-Merkmale bis t unabhängig von Daten nach t; Kurs zum Zeitpunkt",
       abs(P["RV"][d60] - rv_soll) < 1e-12 and np.array_equal(Pa["s2"][:81], Pz["s2"][:81], equal_nan=True)
       and np.array_equal(Da["e"][:gr + 1], Dz["e"][:gr + 1], equal_nan=True) and np.array_equal(Da["modus"][:gr + 1], Dz["modus"][:gr + 1])
       and np.array_equal(Fa[:gr + 1], Fz[:gr + 1], equal_nan=True)
       and abs(float(xz(np.array([K["ts"][100] + BAR]))[0]) - math.log(K["c"][100])) < 1e-12 and np.isnan(xz(np.array([K["ts"][100] + 60]))[0]),
       f"RV Tag 60 {P['RV'][d60]:.6f} (Soll {rv_soll:.6f})")
    # 4) Directional Change gegen die geschlossenen Formen (Zufallsweg, θ = 20 σ_Bar)
    g = np.random.default_rng(11)
    xr = np.cumsum(g.normal(0, 1.0, 1_500_000)); thr = np.full(len(xr), 20.0)
    Dr = dc_lauf(xr, thr)
    Br = beine(Dr, xr, np.ones(len(xr)))
    st = bein_statistik(Br)
    ok("Directional Change: Überschießen ≈ 1 (+ Diskretisierung), Dauer ≈ 1, P(höheres Tief) ½, P(höheres Hoch | höheres Tief) ⅔, "
       "Rücksetzer-Median 1",
       1.0 <= st["ueberschiessen"] <= 1.14 and 0.95 <= st["dauer"] <= 1.25 and abs(st["p_hl"] - 0.5) < 0.03 and abs(st["p_hh_hl"] - 2 / 3) < 0.04
       and abs(st["ruecksetzer"] - 1.0) < 0.1 and abs(st["asymmetrie"]) < 0.15,
       ", ".join(f"{k} {v:.3f}" for k, v in st.items()))
    # 4b) θ folgt der Schwankung: Schwankung ×3 in der zweiten Hälfte -> Beine je Tag in beiden Hälften ähnlich
    def dreifach(ts, r, rng_, sb):
        out = r.copy(); out[len(r) // 2:] *= 3.0
        return out
    Pv = vorbereiten(_markt(tage=600, seed=12, sd_u=1e-4, extra=dreifach))
    Dv = dc_lauf(Pv["x"], theta_bars(Pv, C_HAUPT))
    halb_v = len(Pv["x"]) // 2
    n1 = int(np.sum((Dv["ie"] >= 60 * BARS_TAG) & (Dv["ie"] < halb_v))); n2 = int(np.sum(Dv["ie"] >= halb_v + 60 * BARS_TAG))
    quote = (n2 / (halb_v - 60 * BARS_TAG)) / max(n1 / (halb_v - 60 * BARS_TAG), 1e-9)
    ok("θ folgt der Schwankung: Schwankung ×3 in der zweiten Hälfte -> Beine je Tag in beiden Hälften ähnlich (0,7–1,4)",
       0.7 <= quote <= 1.4, f"Verhältnis {quote:.2f} ({n1} / {n2} Beine)")
    # 4c) Merkmale und Auswahl wie die bestehende Analog-Suche (hl_forecast), Nachbau gegen Original
    Ka = _markt(tage=160, seed=13)
    c_a, ts_a = Ka["c"], Ka["ts"]
    gleich_m, gleich_w = False, False
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_forecast as _hf
        F_alt = _hf._feature_table([float(v) for v in c_a], [int(v) for v in ts_a])
        F_neu = analog_merkmale_bestand(c_a, ts_a)
        gleich_m = max(abs(a_ - b_) for i in range(1440, len(c_a)) for a_, b_ in zip(F_alt[i], F_neu[i])) < 1e-9
        t_ = len(c_a) - 1
        kand_ = np.arange(1440, t_ - 672, 2)
        ib_, _ = _waehle(np.sqrt(((F_neu[kand_] - F_neu[t_]) ** 2).sum(1)), kand_, 50, 12)
        cands = sorted((math.sqrt(sum((a_ - b_) ** 2 for a_, b_ in zip(F_alt[i], F_alt[t_]))), i) for i in range(1440, t_ - 672, 2))
        gew = []
        for d_, i in cands:
            if all(abs(i - j) >= 12 for _, j in gew):
                gew.append((d_, i))
            if len(gew) >= 50:
                break
        gleich_w = sorted(ib_.tolist()) == sorted(j for _, j in gew)
    except Exception as e:                                              # pragma: kein hl_forecast
        gleich_m = gleich_w = False
        print(f"    (hl_forecast nicht ladbar: {e})")
    ok("P0.8-Nachbau: 9 Merkmale und Auswahl (k = 50, Abstand 12) gleich der bestehenden Analog-Suche in hl_forecast",
       gleich_m and gleich_w)
    # 5) P0.1 Positivkontrolle und Nulltest der Uhr
    e_ny = p01_profil(vorbereiten(_markt(tage=800, seed=3, profil="ny")))
    e_utc = p01_profil(vorbereiten(_markt(tage=800, seed=3, profil="utc")))
    ok("P0.1: New-York-Buckel -> belegt, Versatz ≈ +1 h; UTC-Buckel -> New-York-Uhr nicht belegt, Versatz ≈ 0",
       e_ny["belegt"] and 0.75 <= (e_ny["buckel"].get("versatz_h") or 0) <= 1.25 and not e_utc["belegt"] and not e_utc["ny_uhr"]
       and e_utc["profil_traegt"] and abs(e_utc["buckel"].get("versatz_h") or 9) < 0.5,
       f"Versatz {e_ny['buckel'].get('versatz_h'):+.2f} / {e_utc['buckel'].get('versatz_h'):+.2f} h")
    v_a = p01_vergleich(np.array([2.0] * 5 + [-0.1] * 7)); v_b = p01_vergleich(np.array([0.5] * 9 + [-0.1] * 3))
    ok("P0.1-Urteil: kleiner p-Wert allein reicht nicht, D muss in ≥ 2/3 der Monate gewinnen",
       v_a["p"] < 0.05 and v_a["mittel"] > 0 and not v_a["ok"] and v_b["ok"],
       f"Anteil {v_a['anteil']:.2f}, p {_pz(v_a['p'])}")
    # 6) P0.2 auf einem Markt mit Schwankungsregimen
    e2 = p02_groesse(vorbereiten(_markt(tage=800, seed=5, profil="ny")))
    ok("P0.2: Schwankungsregime -> HAR schlägt EWMA, Band und Berührquoten kalibriert",
       e2["har_besser"] and e2["band_ok"] and e2["touch_ok"],
       " · ".join(f"{h} T: Band {e2['h'][h]['band']:.3f}, Steigung {e2['h'][h]['touch_steigung']:.2f}" for h in H_GROESSE))
    # 6a) Band aus den Quantilen des Trainings: Tagesrenditen mit Sprüngen nach unten -> unteres Quantil weiter weg als das obere
    def spruenge(ts, r, rng_, sb):
        out = r.copy()
        tage_ = len(r) // BARS_TAG
        for d_ in np.where(rng_.random(tage_) < 0.06)[0]:
            out[d_ * BARS_TAG + 20] -= 3.0 * sb[d_ * BARS_TAG + 20] * math.sqrt(BARS_TAG)
        return out
    _, ql_, qh_, _, _ = har_prognosen(vorbereiten(_markt(tage=700, seed=16, profil="ny", sd_u=0.05, extra=spruenge)), 1)
    s_ = np.isfinite(ql_)
    ok("P0.2-Band aus den Quantilen des Trainings: Sprünge nach unten -> 10-%-Quantil weiter vom Mittel als das 90-%-Quantil",
       s_.sum() > 100 and float(np.median(-ql_[s_] - qh_[s_])) > 0.1, f"q10 {np.median(ql_[s_]):+.2f}, q90 {np.median(qh_[s_]):+.2f}")
    # 6b) Kausalität: Daten ab Tag D geändert -> HAR-Prognosen (h = 7, mit Band) und Fixed Share vor D unverändert
    Kk = _markt(tage=600, seed=14, profil="ny")
    Pk = vorbereiten(Kk)
    mt_ = _monat_tage(Pk)
    D_ = mt_[2][0] + 2                                                  # zwei Tage nach dem Anfang des dritten Bewertungsmonats
    Kk2 = {k: v.copy() for k, v in Kk.items()}
    ab_ = D_ * BARS_TAG
    for k in ("c", "h", "l", "o"):
        Kk2[k][ab_:] = Kk2[k][ab_:] * np.exp(np.linspace(0, 0.4, len(Kk2[k]) - ab_))
    Kk2["c"][ab_:] *= np.exp(np.random.default_rng(1).normal(0, 0.02, len(Kk2["c"]) - ab_))
    Pk2 = vorbereiten(Kk2)
    h1 = har_prognosen(Pk, 7); h2 = har_prognosen(Pk2, 7)
    fs1, fs2 = fixed_share(fenster_prognosen(Pk["RV"]), Pk["RV"]), fixed_share(fenster_prognosen(Pk2["RV"]), Pk2["RV"])
    vor = slice(0, D_ - 1)
    n_fs = int(np.sum(np.isfinite(fs1[:D_])))
    n_har = int(np.sum(np.isfinite(h1[0][vor])))
    ok("Kausalität: Daten ab Tag D geändert -> HAR-Prognosen und Band vor D gleich, Fixed Share vor D gleich, danach verschieden",
       np.array_equal(h1[0][vor], h2[0][vor], equal_nan=True) and np.array_equal(h1[1][vor], h2[1][vor], equal_nan=True)
       and np.array_equal(fs1[:D_], fs2[:D_], equal_nan=True) and not np.array_equal(h1[0], h2[0], equal_nan=True)
       and not np.array_equal(fs1, fs2, equal_nan=True) and n_fs >= 300 and n_har >= 40,
       f"D = Tag {D_}, verglichen: {n_har} HAR-, {n_fs} Fixed-Share-Prognosen")
    # 7) P0.3 Nulltest und Positivkontrolle
    E3 = {"N1": p03_rechnen(vorbereiten(_markt(tage=700, seed=41, profil="ny", drift_tag=0.004)), n_surr=40, seed=1),
          "N2": p03_rechnen(vorbereiten(_markt(tage=700, seed=42, profil="ny")), n_surr=40, seed=2),
          "T": p03_rechnen(vorbereiten(_markt(tage=700, seed=43, profil="ny", extra=_x_rueckkopplung(0.5, 3, 1.0))), n_surr=40, seed=3)}
    U3 = p03_urteil(E3)
    null_bel = sum(1 for g_ in BEIN_GROESSEN for (cc, _) in U3["groessen"][g_] if cc in ("N1", "N2"))
    trend_ue = sum(1 for (cc, _) in U3["groessen"]["ueberschiessen"] if cc == "T")
    ok("P0.3: Zufallswege (einer mit Drift 0,4 %/Tag) -> keine Abweichung belegt; Momentum über 3 Tage -> Überschießen belegt (≥ 3 von 5)",
       null_bel == 0 and trend_ue >= 3 and not any(cc in ("N1", "N2") for cc, _ in U3["persistenz"]),
       f"Null {null_bel}, Momentum: Überschießen {trend_ue} von 5")
    # 7b) P0.3-Urteil: Holm über Coins × c, Hälften mit gleichem Vorzeichen
    def _z3(p_, h_):
        return {"c": {1.5: {"p": {g_: (p_ if g_ == "dauer" else 0.9) for g_ in BEIN_GROESSEN},
                            "abw_h": {g_: (h_ if g_ == "dauer" else [0.1, 0.1]) for g_ in BEIN_GROESSEN}}}, "persistenz": {}}
    U_t = p03_urteil({"A": _z3(0.001, [0.1, 0.2]), "B": _z3(0.001, [0.1, -0.2]), "C": _z3(0.03, [0.1, 0.2]), "D": _z3(0.03, [0.1, 0.2])})
    ok("P0.3-Urteil: Holm über Coins × c (p 0,03 bei vier Tests reicht nicht); Hälften mit Gegenvorzeichen -> nicht belegt",
       U_t["groessen"]["dauer"] == [("A", 1.5)] and all(not v for g_, v in U_t["groessen"].items() if g_ != "dauer"),
       f"belegt {U_t['groessen']['dauer']}")
    # 8) P0.4 Nulltest und Positivkontrolle
    K0 = [_markt(tage=800, seed=20 + s, profil="ny") for s in range(3)]
    pk0 = [p04_punkte(vorbereiten(K0[s]), f"N{s}") for s in range(3)]
    pk1 = [p04_punkte(vorbereiten(_markt(tage=800, seed=20 + s, profil="ny", extra=_x_rueckkopplung(1.2, 21, -1.0))), f"E{s}") for s in range(3)]
    e40, e41 = p04_auswerten(pk0, _intern=True), p04_auswerten(pk1)
    yq = e40["y_quote"]
    l_konst = -(yq * math.log(yq) + (1 - yq) * math.log(1 - yq))
    ok("P0.4: Zufallswege -> Modell nicht besser als die kalibrierte Baseline, diese klar besser als die Ereignisquote allein (D/θ "
       "trägt); Umkehr nach starkem 21-Tage-Trend -> belegt",
       not e40["belegt"] and e41["belegt"] and e41["abdeckung"] >= 0.5 and e40["mittel"]["basis"]["log"] < l_konst - 0.03,
       f"Null p {_pz(e40['basis_gegen_modell']['log']['p'])}, Log-Verlust Baseline {e40['mittel']['basis']['log']:.3f} gegen "
       f"{l_konst:.3f} ohne D/θ, Umkehr p {_pz(e41['basis_gegen_modell']['log']['p'])}")
    # Kausalität P0.4: Kurse ab einem Monatsanfang geändert -> Vorhersagen davor und das Modell dieses Monats gleich
    schnitt = int(_monatsanfang(int(_monate(np.array([int(K0[0]["ts"][0]) + 600 * TAG]))[0])))
    K0b = []
    for s in range(3):
        kk = {k: v.copy() for k, v in K0[s].items()}
        ab_ = int(np.searchsorted(kk["ts"], schnitt))
        fak = np.exp(np.cumsum(np.random.default_rng(70 + s).normal(0, 0.01, len(kk["c"]) - ab_)))
        for k in ("c", "h", "l", "o"):
            kk[k][ab_:] = kk[k][ab_:] * fak
        K0b.append(kk)
    e40b = p04_auswerten([p04_punkte(vorbereiten(K0b[s]), f"N{s}") for s in range(3)], _intern=True)
    pa, pb = e40["_pr"], e40b["_pr"]
    va = {(int(c_), int(t_)): m_ for c_, t_, m_ in zip(pa["coin"], pa["ts"], pa["modell"]) if t_ < schnitt and np.isfinite(m_)}
    vb = {(int(c_), int(t_)): m_ for c_, t_, m_ in zip(pb["coin"], pb["ts"], pb["modell"]) if t_ < schnitt and np.isfinite(m_)}
    wa_, wb_ = pa["gewichte"].get(schnitt), pb["gewichte"].get(schnitt)
    ok("Kausalität P0.4: Kurse ab einem Monatsanfang geändert -> Vorhersagen davor und das Modell des Monats gleich (nur Aufgelöstes)",
       len(va) > 500 and va.keys() == vb.keys() and all(abs(va[k] - vb[k]) < 1e-12 for k in va)
       and wa_ is not None and wb_ is not None and np.allclose(wa_, wb_, atol=1e-12, rtol=0),
       f"{len(va)} Vorhersagen verglichen, {sum(1 for k in va if k in vb and abs(va[k] - vb[k]) >= 1e-12)} verschieden")
    # 9) P0.5 Nulltest und Positivkontrolle
    e50 = p05_kalender(vorbereiten(_markt(tage=900, seed=51, profil="ny")))
    e51 = p05_kalender(vorbereiten(_markt(tage=900, seed=51, profil="ny", extra=_x_k1(-25.0))))
    ok("P0.5: Zufallsweg -> K1–K3 nicht belegt; −25 bp je Nacht zwischen 2 und 5 Uhr Berlin -> K1 belegt, Größe −25 ± 6 bp",
       not e50["belegt_k"] and "K1" in e51["belegt_k"] and abs(e51["K"]["K1"]["mittel"] * 1e4 + 25.0) <= 6.0,
       f"K1 {e51['K']['K1']['mittel'] * 1e4:+.1f} bp, p Holm {_pz(e51['K']['K1']['p_holm'])}")
    # 9b) Vorzeichenwechsel zwischen den Jahren: −40 bp im ersten Jahr, +10 bp danach -> im Mittel auffällig, aber nicht belegt
    def k1_wechsel(ts, r, rng_, sb):
        lok = (ts + _offsets(ts, TZ_BERLIN)) % TAG
        im = (lok >= 2 * 3600) & (lok < 5 * 3600)
        jahr1 = ts < ts[0] + 365 * TAG
        return r + np.where(im, np.where(jahr1, -40.0, 10.0) * 1e-4 / 6, 0.0)
    e52 = p05_kalender(vorbereiten(_markt(tage=900, seed=51, profil="ny", extra=k1_wechsel)))
    k1w = e52["K"]["K1"]
    ok("P0.5: Vorzeichen wechselt zwischen den Jahren (−40 bp, dann +10 bp) -> trotz kleinem p nicht belegt",
       k1w["p_holm"] < 0.05 and not k1w["jahr_ok"] and not k1w["belegt"],
       f"Mittel {k1w['mittel'] * 1e4:+.1f} bp, p Holm {_pz(k1w['p_holm'])}, Jahre " + ", ".join(f"{j} {m * 1e4:+.0f}" for j, m, n in k1w["jahre"]))
    # 9c) 23.60: Drift allein darf K3 nicht belegen (roh, wie bis 23.59, schon: Erwartung −0,86 × 40 bp); −40 bp je Sitzung schon
    # Start 10.11.2023: drei Frühjahrs-, zwei Herbstumstellungen -- eine falsch gezählte Umstellung höbe sich nicht paarweise auf
    st53 = _START_TEST + 40 * TAG
    e53 = p05_kalender(vorbereiten(_markt(tage=900, seed=53, profil="ny", drift_tag=0.004, start=st53)))
    e55 = p05_kalender(vorbereiten(_markt(tage=900, seed=53, profil="ny", start=st53)))      # derselbe Pfad ohne Drift
    e54 = p05_kalender(vorbereiten(_markt(tage=900, seed=53, profil="ny", extra=_x_k3(-40.0))))
    k3d, k3r, k3e = e53["K"]["K3"], e53["K3_roh"], e54["K"]["K3"]
    gleich = abs(k3d["mittel"] - e55["K"]["K3"]["mittel"]) < 1e-9          # je Stunde verglichen hebt sich jede feste Drift genau auf
    ok("P0.5: Drift +40 bp je Tag -> K3 genau wie ohne Drift, nicht belegt (roh bis 23.59: p < 0,05); −40 bp je US-Sitzung -> K3 belegt, −40 ± 12 bp",
       gleich and "K3" not in e53["belegt_k"] and k3r["mittel"] < 0 and k3r["p"] < 0.05 and "K3" in e54["belegt_k"]
       and abs(k3e["mittel"] * 1e4 + 40.0) <= 12.0,
       f"Drift: K3 {k3d['mittel'] * 1e4:+.2f} bp (ohne {e55['K']['K3']['mittel'] * 1e4:+.2f}; roh {k3r['mittel'] * 1e4:+.1f} bp, p {_pz(k3r['p'])}); "
       f"Effekt: K3 {k3e['mittel'] * 1e4:+.1f} bp, p Holm {_pz(k3e['p_holm'])}")
    g_ = np.random.default_rng(17)
    st_a = np.concatenate([g_.normal(0.3, 0.2, 60), g_.normal(-0.05, 0.2, 60)])      # stark, aber nur in der ersten Hälfte
    st_b = g_.normal(0.15, 0.2, 120)
    ha, hb = hks_urteil(st_a), hks_urteil(st_b)
    ok("P0.5-Persistenz: kleiner p-Wert allein reicht nicht, die Steigung muss in beiden Hälften positiv sein",
       ha["p"] < 0.05 and ha["mittel"] > 0 and not ha["belegt"] and hb["belegt"], f"Hälften {ha['halb'][0]:+.2f} / {ha['halb'][1]:+.2f}")
    # 10) P0.6 Nulltest und Positivkontrolle
    e60 = p06_momentum({"BTC": vorbereiten(_markt(tage=1100, seed=61, profil="ny")), "ETH": vorbereiten(_markt(tage=1100, seed=62, profil="ny"))})
    e61 = p06_momentum({"BTC": vorbereiten(_markt(tage=1100, seed=61, profil="ny", extra=_x_rueckkopplung(0.6, 21, 1.0))),
                        "ETH": vorbereiten(_markt(tage=1100, seed=62, profil="ny", extra=_x_rueckkopplung(0.6, 21, 1.0)))})
    ok("P0.6: Zufallswege -> nichts belegt; starkes Zeitreihen-Momentum -> mindestens eine Variante belegt",
       not e60["belegt"] and len(e61["belegt"]) >= 1,
       f"belegt {e61['belegt']}, PBO {e61.get('pbo', float('nan')):.2f}")
    K6 = _markt(tage=900, seed=63, profil="ny", extra=_x_rueckkopplung(0.6, 21, 1.0))
    schnitt6 = (int(K6["ts"][0]) // TAG + 700) * TAG
    schnitt6 += ((7 - ((schnitt6 // TAG + 3) % 7)) % 7) * TAG                  # nächster Montag 00 UTC
    K6b = {k: v.copy() for k, v in K6.items()}
    ab6 = int(np.searchsorted(K6b["ts"], schnitt6))
    c_s = float(K6["c"][ab6 - 1])                                          # Pfad ab dem Schnitt gespiegelt: jede Rendite danach dreht
    K6b["c"][ab6:] = c_s * c_s / K6["c"][ab6:]; K6b["o"][ab6:] = c_s * c_s / K6["o"][ab6:]
    K6b["h"][ab6:] = c_s * c_s / K6["l"][ab6:]; K6b["l"][ab6:] = c_s * c_s / K6["h"][ab6:]
    e6a = p06_momentum({"BTC": vorbereiten(K6)}, _intern=True); e6b = p06_momentum({"BTC": vorbereiten(K6b)}, _intern=True)
    gleich6 = True; n6 = 0
    for k_, v_ in e6a["varianten"].items():
        ta, pa_ = v_["_p"]; tb, pb_ = e6b["varianten"][k_]["_p"]
        sa = ta <= schnitt6                                              # alle bis zum Schnitt ausgegebenen Prognosen
        n6 += int(sa.sum())
        gleich6 &= np.array_equal(ta[sa], tb[: sa.sum()]) and np.allclose(pa_[sa], pb_[: sa.sum()], atol=1e-12, rtol=0)
    ok("Kausalität P0.6: Kurse ab einem Montag geändert -> alle bis dahin ausgegebenen Wochenprognosen gleich",
       gleich6 and n6 > 100, f"{n6} Wochenprognosen verglichen")
    # 11) P0.7 Fensterkombination
    P7 = vorbereiten(_markt(tage=900, seed=9, profil="ny", sd_u=1e-4, extra=_x_vol_stufen()))
    e7 = p07_fenster(P7)
    RV = P7["RV"]
    Fd = {"2W": _rollmittel(RV, 14), "4W": _rollmittel(RV, 28), "8W": _rollmittel(RV, 56), "EWMA": ewma_tag(RV)}
    okh = np.isfinite(RV) & (RV > 0); cs_ = np.cumsum(np.where(okh, RV, 0.0)); cn_ = np.cumsum(okh)
    Fd["Historie"] = np.where(cn_ > 0, cs_ / np.maximum(cn_, 1), np.nan)
    fs = fixed_share(Fd, RV)
    M_ = np.column_stack([Fd[k] for k in EINZEL_FENSTER])
    sel = np.isfinite(fs)
    ok("P0.7: Fixed Share liegt jeden Tag zwischen den Einzelprognosen; Schwankungsstufen ×3 alle 20 Tage -> nicht schlechter als das beste",
       e7["belegt"] and np.all(fs[sel] >= M_[sel].min(axis=1) - 1e-15) and np.all(fs[sel] <= M_[sel].max(axis=1) + 1e-15),
       " · ".join(f"{h} T: Abstand {e7['h'][h]['abstand']:+.4f} ± {e7['h'][h]['se']:.4f}" for h in (1, 7)))
    # 12) P0.8 Nulltest und Positivkontrolle
    e80 = p08_analog(vorbereiten(_markt(tage=800, seed=8, profil="ny", sd_u=0.25)))
    e81 = p08_analog(vorbereiten(_markt(tage=800, seed=8, profil="ny", sd_u=0.25, extra=_x_rueckkopplung(0.6, 7, -1.0))))
    ok("P0.8: Zufallsweg -> nicht belegt; Umkehr in Schwankungseinheiten -> Regime-Analog schlägt den Zufallsweg auf ≥ 2 Horizonten",
       not e80["belegt"] and e80["siege_zufall"] < 2 and e81["siege_zufall"] >= 2,
       f"Null: Siege {e80['siege']}/{e80['siege_zufall']}, Umkehr: {e81['siege']}/{e81['siege_zufall']}")
    sg = {"mittel": 1.0, "p": 0.01}; ns = {"mittel": 1.0, "p": 0.2}
    u_a = p08_urteil({48: {"dm": sg, "dm_zufall_regime": ns}, 144: {"dm": sg, "dm_zufall_regime": ns}, 336: {"dm": ns, "dm_zufall_regime": ns}})
    u_b = p08_urteil({48: {"dm": sg, "dm_zufall_regime": sg}, 144: {"dm": sg, "dm_zufall_regime": sg}, 336: {"dm": ns, "dm_zufall_regime": ns}})
    u_c = p08_urteil({48: {"dm": sg, "dm_zufall_regime": sg}, 144: {"dm": ns, "dm_zufall_regime": sg}, 336: {"dm": ns, "dm_zufall_regime": sg}})
    ok("P0.8-Urteil: besser als die bestehende Suche allein reicht nicht; beides auf ≥ 2 Horizonten nötig",
       not u_a["belegt"] and u_b["belegt"] and not u_c["belegt"])
    # 13) P0.9 Bruchmelder
    e9 = p09_bruch(vorbereiten(_markt(tage=500, seed=4, profil="ny", sd_u=1e-4)), seed=1)
    bruch_tag = 300

    def bruch(ts, r, rng, sb):
        out = r.copy(); out[bruch_tag * BARS_TAG:] *= 2.0
        return out
    Pb = vorbereiten(_markt(tage=500, seed=4, profil="ny", sd_u=1e-4, extra=bruch))
    s2b_ = profil_d_voll(Pb)
    ab_ = np.where(Pb["rv_ok"] & np.isfinite(Pb["r"]), np.nan_to_num(Pb["r"]) / np.sqrt(s2b_), 0.0)
    au_b, _ = cusum_lauf(ab_[None, :], e9["h_auf"], e9["h_ab"])
    nach = [t for t in au_b[0] if t >= bruch_tag * BARS_TAG]
    verz_b = (nach[0] - bruch_tag * BARS_TAG) / 2.0 if nach else math.inf
    ok("P0.9: fast konstante Schwankung -> ≤ 1,5 Fehlalarme je 30 T, Verdopplung im Median ≤ 12 h; eingepflanzter Bruch binnen 24 h gemeldet",
       e9["belegt"] and e9["fehlalarme_30t"] <= 1.5 and verz_b <= 24.0,
       f"Fehlalarme {e9['fehlalarme_30t']:.2f}, Verdopplung {e9['verzoegerung']['verdopplung']['median_h']:.1f} h, Bruch nach {verz_b:.1f} h")
    # 14) Ganzer Bericht auf kleinen Märkten
    KK = {"BTC": _markt(tage=520, seed=1, profil="ny"), "ETH": _markt(tage=520, seed=2, profil="ny"), "HYPE": _markt(tage=300, seed=3), "XMR": None}
    Eg = vorpruefung_rechnen(KK, log=lambda *a_: None, n_surr=12)
    txt = bericht_text(Eg, {"BTC": "binance", "ETH": "binance", "HYPE": "bybit", "XMR": "keine"}, 1.0, {"XMR": {"fertig": True}})
    teile = ("PRÜFSTAND", "P0.1 ZWEI-UHREN-PROFIL", "P0.2 BEWEGUNGSGRÖSSE", "P0.3 BEINE", "P0.4 BEINENDE", "P0.5 KALENDER", "P0.6 WOCHENMOMENTUM",
             "P0.7 FENSTER", "P0.8 REGIME-ANALOG", "P0.9 BRUCHMELDER", "zu kurz", "keine Historie")
    fehlt = [t_ for t_ in teile if t_ not in txt]
    ok("Bericht: alle Abschnitte, „zu kurz“ und „keine Historie“, keine Ausnahme", not fehlt, f"fehlt: {fehlt}" if fehlt else f"{len(txt)} Zeichen")
    return all(p_[1] for p_ in pruef), pruef


def selbsttest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Regime-Modul (U138) Phase 0 -- Selbsttest: Bausteine, Laden ohne Netz, Kausalität, Nulltests und Positivkontrollen P0.1–P0.9",
              flush=True)
    gut, _ = probe(verbose)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if gut else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return gut


# ================================================================================================ Aufruf

def vorpruefung(db: str, coins=COINS, laden_budget: float = 420.0, ohne_laden: bool = False, n_surr: int = N_SURR) -> int:
    try:
        os.nice(10)                                                     # neben den Diensten des Pi: niedrige Priorität
    except (AttributeError, OSError):
        pass
    t_anf = time.time()
    _UNERREICHBAR.clear()
    pfad = regime_pfad(db)
    print(f"Regime-Vorprüfung: Daten in {pfad}", flush=True)
    con = verbinden(pfad)
    lade = {}
    try:
        if not ohne_laden:
            for coin in coins:
                rest = laden_budget - (time.time() - t_anf)
                if rest <= 5:
                    lade[coin] = {"fertig": False}
                    continue
                try:
                    lade[coin] = laden(con, coin, budget_s=rest, log=lambda s: print(s, flush=True))
                    li = lade[coin]
                    print(f"  {coin}: {QUELLE_NAME.get(li.get('quelle'), 'keine Quelle')}, {li.get('neu', 0)} neue Kerzen"
                          + ("" if li.get("fertig") else " (noch nicht fertig)"), flush=True)
                except Exception as e:                                  # Netz, Börse: ohne diesen Coin weiter
                    lade[coin] = {"fertig": False, "fehler": str(e)[:120]}
                    print(f"  {coin}: Laden fehlgeschlagen ({str(e)[:120]})", flush=True)
        KK = {}
        for coin in coins:
            if lade.get(coin, {}).get("fertig", True) is False:
                KK[coin] = None
            else:
                KK[coin] = kerzen(con, coin)
        quellen = {coin: meta(con, f"quelle:{coin}") for coin in coins}
    finally:
        con.close()
    print("Rechnen …", flush=True)
    t1 = time.time()
    E = vorpruefung_rechnen(KK, log=lambda s: print(s, flush=True), n_surr=n_surr)
    for coin, info in E["coins"].items():
        li = lade.get(coin, {})
        if li.get("fertig") is False:
            info["status"] = "Laden fehlgeschlagen" if li.get("fehler") else "Laden unvollständig"
    print()
    print(bericht_text(E, quellen, time.time() - t1, lade))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Regime-Modul (U138), Phase 0: Vorprüfung auf der Historie")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (regime.db liegt daneben)")
    ap.add_argument("--vorpruefung", action="store_true", help="Historie ergänzen und die Prüfungen P0.1–P0.9 rechnen (Bericht)")
    ap.add_argument("--laden", action="store_true", help="nur Historie laden bzw. ergänzen")
    ap.add_argument("--ohne-laden", action="store_true", help="nur mit vorhandenen Kerzen rechnen")
    ap.add_argument("--coins", default=",".join(COINS))
    ap.add_argument("--surrogate", type=int, default=N_SURR)
    ap.add_argument("--selbsttest", action="store_true")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    db = a.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db")
    coins = tuple(c.strip().upper() for c in a.coins.split(",") if c.strip())
    if a.laden:
        con = verbinden(regime_pfad(db))
        try:
            for coin in coins:
                li = laden(con, coin, budget_s=600, log=lambda s: print(s, flush=True))
                print(f"{coin}: {QUELLE_NAME.get(li.get('quelle'), 'keine Quelle')}, {li.get('neu', 0)} neue Kerzen"
                      + ("" if li.get("fertig") else " (noch nicht fertig)"), flush=True)
        finally:
            con.close()
        return 0
    if a.vorpruefung:
        return vorpruefung(db, coins, ohne_laden=a.ohne_laden, n_surr=a.surrogate)
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
