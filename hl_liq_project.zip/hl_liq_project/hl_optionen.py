#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hl_optionen.py -- Optionen mit langer Laufzeit als mögliche Quelle für den 24-Monats-Chart: der Erstlauf (U278, Debug 154).

Was der Lauf tut (KONZEPT_Langfrist.md 9.1): je EIN Abruf bei Deribit (BTC-Optionen, öffentliche Schnittstelle, schon Quelle für DVOL)
und bei Cboe (IBIT-Optionen, verzögerte Kurse; dieselben zwei Hosts wie für VVIX und VIX9D -- der zweite nur, wenn der erste nicht
liefert). Er misst, was die Quelle liefert: Erreichbarkeit, Größe, Dauer, Verfalltage, Strikes, Anteil mit Geld- und Briefkurs, Spanne am
Geld, offene Kontrakte. Gespeichert wird NICHTS -- der Bericht ist die Ausgabe. Bei unerwartetem Format stürzt der Lauf nicht ab; er
meldet die Struktur der Antwort. Das Format der Cboe-Antwort ist nicht dokumentiert (frei abrufbare Daten hinter den Kursseiten); die
Kontrakte werden deshalb an ihren OCC-Kennungen erkannt, nicht an einem festen Aufbau.

Regel danach (9.2, vorab festgelegt; hier nur gezählt):
  brauchbar für Quantile = auf jeder Seite des Terminkurses mindestens 5 Strikes mit Geld- und Briefkurs UND Spanne am Geld <= 15 %;
  sonst zählt nur die implizite Schwankung am Geld; fehlt auch sie, entfällt der Verfalltag.
  IBIT kommt nur in Frage, wenn mindestens ein brauchbarer Verfalltag 18 Monate oder länger läuft.

Zählweise (Nachtrag vom 20.11.2026 in KONZEPT_Langfrist.md 15, festgelegt VOR dem ersten Abruf):
  Z1 Geld- und Briefkurs: beide vorhanden, größer 0, Brief >= Geld.
  Z2 Terminkurs: Deribit = Feld underlying_price (Median je Verfalltag). IBIT = Put-Call-Parität am Strike mit dem kleinsten Abstand
     zwischen Call und Put (Mittelkurse): F = K + Call - Put (amerikanische Optionen, ohne Zins: Näherung); ohne ein solches Paar der
     Kassakurs.
  Z3 Seiten: unter dem Terminkurs zählen die Puts, darüber die Calls (aus dem Geld -- aus ihnen kämen die Quantile). Ein Strike genau
     am Terminkurs zählt für keine Seite.
  Z4 Am Geld: der Strike nächst dem Terminkurs, an dem Call und Put gelistet sind (bei Gleichstand der niedrigere). Spanne am Geld =
     Spanne des Paars Call + Put: (Brief_C + Brief_P - Geld_C - Geld_P) / Mitte des Paars. Fehlt ein Kurs: keine Spanne.
  Z5 Tage bis zum Verfall: Deribit 08:00 UTC, IBIT 16:00 New York. 12 Monate = 365 Tage, 18 Monate = 548 Tage.
  Z6 Die Bedingung für IBIT wird nur in der US-Handelszeit gewertet (Handelstag, 9:45-16:15 New York: die Kurse sind 15 Minuten
     verzögert); sonst „kein Urteil“. Es zählt der erste Lauf in der Handelszeit, spätere ändern das Urteil nicht.

Aufruf:  python3 hl_optionen.py --erstlauf      je ein Abruf, Bericht als Text (Debug 154)
         python3 hl_optionen.py --selbsttest    ohne Netz
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import statistics
import sys
import time
from datetime import date, datetime, timezone

import hl_aktien as AK

VERSION_MODUL = "2026-09-23.113"
DEBUG_NR = 154
PLAN = "U278"
REGEL = "KONZEPT_Langfrist.md 9, Zählweise Z1–Z6 vom 20.11.2026"
TAG = 86_400
DERIBIT_URL = "https://www.deribit.com/api/v2/public/get_book_summary_by_currency?currency=BTC&kind=option"
CBOE_SYMBOL = "IBIT"
CBOE_URLS = ("https://cdn.cboe.com/api/global/delayed_quotes/options/IBIT.json",
             "https://cdn-api.cboe.com/api/global/delayed_quotes/options/IBIT.json")
MIN_STRIKES = 5                 # 9.2: Strikes mit Geld- und Briefkurs je Seite
MAX_SPANNE = 0.15               # 9.2: Spanne am Geld, Anteil am Mittelkurs
TAGE_12M = 365                  # 9.1: Verfalltage „ab 12 Monaten“
TAGE_18M = 548                  # 9.2: „18 Monate oder länger“
VERZUG_S = 900                  # Cboe: Kurse 15 Minuten verzögert (Z6)
ABRUF_ZEIT_S = 40
EPS = 1e-9
MONATE = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6, "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}
WOCHENTAG = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
STUFE_TXT = {"quantile": "Quantile", "iv": "nur IV am Geld", "entfaellt": "entfällt"}
_DRB = re.compile(r"^BTC-(\d{1,2})([A-Z]{3})(\d{2})-(\d+)-([CP])$")
_OCC_WURZEL = re.compile(r"^[A-Z][A-Z0-9]{0,5}$")
_OCC_REST = re.compile(r"^\d{6}[CP]\d{8}$")


# ================================================================================================ kleine Helfer

def zahl(x):
    """Zahl als float oder None: Zahlen und reine Zahl-Texte; None, leer, Wahrheitswerte, NaN und unendlich sind keine Zahl."""
    if x is None or isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        v = float(x)
    elif isinstance(x, str):
        try:
            v = float(x.strip())
        except ValueError:
            return None
    else:
        return None
    return v if math.isfinite(v) else None


def sauber(x, n: int = 80) -> str:
    """Text aus dem Netz für den Bericht: eine Zeile, nur druckbare Zeichen, höchstens n Zeichen."""
    s = "".join(c if c.isprintable() else " " for c in str(x))
    s = " ".join(s.split())
    return s if len(s) <= n else s[:max(1, n - 1)] + "…"


def beispiel(liste: list, wert) -> None:
    """Bis zu drei Beispiele unlesbarer Kennungen -- nur Texte, gesäubert, nicht leer."""
    b = sauber(wert, 40) if isinstance(wert, str) else ""
    if b and len(liste) < 3:
        liste.append(b)


def felder(d, n: int = 40) -> list:
    return [sauber(k, 30) for k in list(d)[:n]] if isinstance(d, dict) else []


def de(x, n: int = 0) -> str:
    """Zahl in deutscher Schreibweise (1.234,5); None -> Strich."""
    if x is None:
        return "—"
    return f"{x:,.{n}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def pz(x, n: int = 1) -> str:
    return "—" if x is None else de(x * 100.0, n) + " %"


def strike_txt(k: float) -> str:
    return de(k, 0) if abs(k - round(k)) < 1e-9 else de(k, 2)


def datum(d: date) -> str:
    return d.strftime("%d.%m.%Y")


def groesse_txt(n: int) -> str:
    if n < 1000:
        return f"{n} Bytes"
    return f"{de(n / 1e6, 1)} MB" if n >= 1_000_000 else f"{de(n / 1e3, 0)} kB"


def beide(k: dict) -> bool:
    """Z1: Geld- und Briefkurs vorhanden, größer 0, Brief >= Geld."""
    b, a = k.get("bid"), k.get("ask")
    return b is not None and a is not None and b > 0 and a > 0 and a >= b


def mitte(k: dict) -> float:
    return (k["bid"] + k["ask"]) / 2.0


def struktur(o, tiefe: int = 4) -> str:
    """Aufbau einer unerwarteten Antwort: Typen, Schlüssel, Längen -- keine Werte."""
    if isinstance(o, dict):
        if tiefe <= 0:
            return f"Objekt mit {len(o)} Schlüsseln"
        teile = [f"{sauber(k, 30)}: {struktur(v, tiefe - 1)}" for k, v in list(o.items())[:12]]
        return "Objekt {" + ", ".join(teile) + (f", … (+{len(o) - 12})" if len(o) > 12 else "") + "}"
    if isinstance(o, list):
        erst = f"; erster Eintrag: {struktur(o[0], tiefe - 1)}" if o and tiefe > 0 else ""
        return f"Liste mit {len(o)} Einträgen{erst}"
    if isinstance(o, bool):
        return "Wahrheitswert"
    if isinstance(o, (int, float)):
        return "Zahl"
    if isinstance(o, str):
        return f"Text ({len(o)} Zeichen)"
    if o is None:
        return "leer (null)"
    return type(o).__name__


# ================================================================================================ Kennungen

def deribit_name(name):
    """„BTC-27MAR27-100000-C“ -> (Verfall als Unix-Zeit 08:00 UTC, Tag, Strike, „C“/„P“); sonst None."""
    if not isinstance(name, str):
        return None
    m = _DRB.match(name)
    if not m or m.group(2) not in MONATE:
        return None
    try:
        d = date(2000 + int(m.group(3)), MONATE[m.group(2)], int(m.group(1)))
    except ValueError:
        return None
    return int(datetime(d.year, d.month, d.day, 8, tzinfo=timezone.utc).timestamp()), d, float(m.group(4)), m.group(5)


def occ_name(sym):
    """OCC-Kennung „IBIT281215C00055000“ (auch mit Leerzeichen nach der Wurzel) -> (Wurzel, Tag, „C“/„P“, Strike); sonst None."""
    if not isinstance(sym, str):
        return None
    s = sym.replace(" ", "")
    if not 16 <= len(s) <= 21:
        return None
    wurzel, rest = s[:-15], s[-15:]
    if not _OCC_WURZEL.match(wurzel) or not _OCC_REST.match(rest):
        return None
    try:
        d = date(2000 + int(rest[:2]), int(rest[2:4]), int(rest[4:6]))
    except ValueError:
        return None
    return wurzel, d, rest[6], int(rest[7:]) / 1000.0


def _occ_im(e: dict):
    """Die OCC-Kennung in einem Eintrag: zuerst im Feld „option“, sonst im ersten Textfeld, das eine ist."""
    g = occ_name(e.get("option"))
    if g is not None:
        return g
    for v in list(e.values())[:40]:
        if isinstance(v, str):
            g = occ_name(v)
            if g is not None:
                return g
    return None


# ================================================================================================ Antworten lesen

def deribit_lesen(obj) -> dict:
    """Antwort von get_book_summary_by_currency -> Kontrakte. Wirft nie; „grund“ sagt, warum nichts gelesen wurde."""
    out = {"ok": False, "grund": None, "kontrakte": [], "gesamt": 0, "unlesbar": 0, "beispiele": [], "felder": []}
    if not isinstance(obj, dict):
        out["grund"] = "Antwort ist kein Objekt"
        return out
    if "result" not in obj:
        err = obj.get("error")
        out["grund"] = (f"Fehler der Börse: {sauber(err.get('message'), 80)} (Code {sauber(err.get('code'), 12)})" if isinstance(err, dict)
                        else "Schlüssel „result“ fehlt")
        return out
    res = obj["result"]
    if not isinstance(res, list):
        out["grund"] = "„result“ ist keine Liste"
        return out
    out["gesamt"] = len(res)
    for e in res:
        if not isinstance(e, dict):
            out["unlesbar"] += 1
            continue
        if not out["felder"]:
            out["felder"] = felder(e)
        nm = deribit_name(e.get("instrument_name"))
        if nm is None:
            out["unlesbar"] += 1
            beispiel(out["beispiele"], e.get("instrument_name"))
            continue
        ts, d, strike, typ = nm
        out["kontrakte"].append({"verfall": ts, "tag": d, "strike": strike, "typ": typ, "bid": zahl(e.get("bid_price")),
                                 "ask": zahl(e.get("ask_price")), "iv": zahl(e.get("mark_iv")), "oi": zahl(e.get("open_interest")),
                                 "termin": zahl(e.get("underlying_price"))})
    out["ok"] = bool(out["kontrakte"])
    if not out["ok"]:
        out["grund"] = "keine lesbare BTC-Option in der Antwort"
    return out


def _optionsliste(obj):
    """(Liste, Pfad) der Kontrakte: erwartet data.options; sonst die längste Liste aus Objekten mit OCC-Kennung (bis Tiefe 3)."""
    if isinstance(obj, dict) and isinstance(obj.get("data"), dict) and isinstance(obj["data"].get("options"), list):
        return obj["data"]["options"], "data.options"
    best = [0, None, None]

    def suche(o, pfad, tiefe):
        if isinstance(o, list):
            if len(o) > best[0] and any(isinstance(e, dict) and _occ_im(e) is not None for e in o[:50]):
                best[0], best[1], best[2] = len(o), o, pfad or "(oberste Ebene)"
        elif isinstance(o, dict) and tiefe < 3:
            for k, v in list(o.items())[:60]:
                suche(v, f"{pfad}.{sauber(k, 30)}" if pfad else sauber(k, 30), tiefe + 1)
    suche(obj, "", 0)
    return best[1], best[2]


def cboe_lesen(obj, symbol: str = CBOE_SYMBOL) -> dict:
    """Antwort der verzögerten Cboe-Kurse -> Kontrakte der Wurzel symbol, Kassakurs, Zeitstempel. Wirft nie."""
    out = {"ok": False, "grund": None, "kontrakte": [], "gesamt": 0, "unlesbar": 0, "beispiele": [], "felder": [], "pfad": None,
           "kurs": None, "kurs_feld": None, "zeitstempel": None, "zeit_feld": None, "wurzeln": {}, "kopf_felder": []}
    liste, pfad = _optionsliste(obj)
    if liste is None:
        out["grund"] = "keine Liste mit Options-Kennungen gefunden"
        return out
    out["pfad"], out["gesamt"] = pfad, len(liste)
    kopf = obj.get("data") if isinstance(obj, dict) and isinstance(obj.get("data"), dict) else (obj if isinstance(obj, dict) else {})
    out["kopf_felder"] = [sauber(k, 30) for k, v in list(kopf.items())[:60] if not isinstance(v, (list, dict))]
    for feld in ("current_price", "close", "last_trade_price", "prev_day_close"):
        v = zahl(kopf.get(feld))
        if v is not None and v > 0:
            out["kurs"], out["kurs_feld"] = v, feld
            break
    for quelle, feld in ((obj, "timestamp"), (kopf, "last_trade_time"), (kopf, "timestamp")):
        w = quelle.get(feld) if isinstance(quelle, dict) else None
        if isinstance(w, (str, int, float)) and not isinstance(w, bool):
            out["zeitstempel"], out["zeit_feld"] = sauber(w, 40), feld
            break
    for e in liste:
        if not isinstance(e, dict):
            out["unlesbar"] += 1
            continue
        if not out["felder"]:
            out["felder"] = felder(e)
        g = _occ_im(e)
        if g is None:
            out["unlesbar"] += 1
            beispiel(out["beispiele"], e.get("option"))
            continue
        wurzel, d, typ, strike = g
        out["wurzeln"][wurzel] = out["wurzeln"].get(wurzel, 0) + 1
        if wurzel != symbol:
            continue
        out["kontrakte"].append({"verfall": AK.ny_ts(d, 16), "tag": d, "strike": strike, "typ": typ, "bid": zahl(e.get("bid")),
                                 "ask": zahl(e.get("ask")), "iv": zahl(e.get("iv")), "oi": zahl(e.get("open_interest")), "termin": None})
    out["ok"] = bool(out["kontrakte"])
    if not out["ok"]:
        out["grund"] = f"keine Option mit der Wurzel {symbol} in der Liste ({pfad})"
    return out


# ================================================================================================ Kennzahlen je Verfalltag

def kennzahlen(K: list, paritaet: bool = False, kasse: float | None = None) -> dict:
    """Kennzahlen EINES Verfalltags aus seinen Kontrakten (Z1–Z4) und die Stufe nach 9.2."""
    calls, puts, doppelt = {}, {}, 0
    for k in K:
        ziel = calls if k["typ"] == "C" else puts
        if k["strike"] in ziel:
            doppelt += 1
            continue
        ziel[k["strike"]] = k
    strikes = sorted(set(calls) | set(puts))
    einzeln = list(calls.values()) + list(puts.values())
    n_beide = sum(1 for k in einzeln if beide(k))
    # Z2 Terminkurs
    tf = [k["termin"] for k in einzeln if k.get("termin") is not None and k["termin"] > 0]
    termin, art, k_par = None, "keiner", None
    if tf:
        termin, art = float(statistics.median(tf)), "feld"
    elif paritaet:
        paare = [(abs(mitte(calls[s]) - mitte(puts[s])), s) for s in strikes if s in calls and s in puts and beide(calls[s]) and beide(puts[s])]
        if paare:
            _, k_par = min(paare)
            termin, art = k_par + mitte(calls[k_par]) - mitte(puts[k_par]), "paritaet"
        elif kasse is not None and kasse > 0:
            termin, art = float(kasse), "kasse"
    # Z3 Seiten
    unter = sum(1 for s in strikes if termin is not None and s < termin and s in puts and beide(puts[s]))
    ueber = sum(1 for s in strikes if termin is not None and s > termin and s in calls and beide(calls[s]))
    # Z4 am Geld
    gemeinsam = [s for s in strikes if s in calls and s in puts]
    k_geld = min(gemeinsam, key=lambda s: (abs(s - termin), s)) if gemeinsam and termin is not None else None
    spanne_c = spanne_p = spanne = iv = None
    geld = None
    if k_geld is not None:
        c, p = calls[k_geld], puts[k_geld]
        geld = {"c": (c.get("bid"), c.get("ask")), "p": (p.get("bid"), p.get("ask"))}
        spanne_c = (c["ask"] - c["bid"]) / mitte(c) if beide(c) else None
        spanne_p = (p["ask"] - p["bid"]) / mitte(p) if beide(p) else None
        if spanne_c is not None and spanne_p is not None:
            spanne = (c["ask"] + p["ask"] - c["bid"] - p["bid"]) / ((c["ask"] + p["ask"] + c["bid"] + p["bid"]) / 2.0)
        ivs = [k["iv"] for k in (c, p) if k.get("iv") is not None and k["iv"] > 0]
        iv = sum(ivs) / len(ivs) if ivs else None
    gruende = []
    if termin is None:
        gruende.append("kein Terminkurs")
    else:
        if unter < MIN_STRIKES:
            gruende.append(f"unter dem Terminkurs nur {unter} {'Strike' if unter == 1 else 'Strikes'} mit beiden Kursen")
        if ueber < MIN_STRIKES:
            gruende.append(f"darüber nur {ueber} {'Strike' if ueber == 1 else 'Strikes'} mit beiden Kursen")
        if k_geld is None:
            gruende.append("kein Strike mit Call und Put")
        elif spanne is None:
            gruende.append("am Geld fehlt ein Geld- oder Briefkurs")
        elif spanne > MAX_SPANNE + EPS:
            gruende.append(f"Spanne am Geld {pz(spanne)} über {pz(MAX_SPANNE, 0)}")
    brauchbar = not gruende
    oi = [k["oi"] for k in einzeln if k.get("oi") is not None]
    return {"strikes": len(strikes), "kontrakte": len(einzeln), "doppelt": doppelt, "beide": n_beide,
            "anteil": n_beide / len(einzeln) if einzeln else None, "termin": termin, "termin_art": art, "k_par": k_par,
            "unter": unter, "ueber": ueber, "k_geld": k_geld, "geld": geld, "spanne_c": spanne_c, "spanne_p": spanne_p, "spanne": spanne,
            "iv": iv, "oi": sum(oi) if oi else None,
            "stufe": "quantile" if brauchbar else ("iv" if iv is not None else "entfaellt"), "gruende": gruende}


def je_verfall(kontrakte: list, jetzt: float, paritaet: bool = False, kasse: float | None = None) -> tuple:
    """(Liste der kommenden Verfalltage mit Kennzahlen, aufsteigend; Zahl der Kontrakte, deren Verfall schon vorbei ist)."""
    gruppen, vorbei = {}, 0
    for k in kontrakte:
        if k["verfall"] <= jetzt:
            vorbei += 1
            continue
        gruppen.setdefault(k["verfall"], []).append(k)
    out = []
    for ts in sorted(gruppen):
        v = kennzahlen(gruppen[ts], paritaet=paritaet, kasse=kasse)
        v.update(verfall=ts, tag=gruppen[ts][0]["tag"], tage=(ts - jetzt) / TAG)
        out.append(v)
    return out, vorbei


def handelszeit(jetzt: float) -> bool:
    """Z6: Der Stand, den die verzögerten Kurse jetzt zeigen, liegt in der regulären US-Handelszeit."""
    return AK.boerse_offen(jetzt - VERZUG_S)


def ibit_urteil(V: list, jetzt: float) -> dict:
    """Bedingung 9.2 für IBIT in diesem Lauf: mindestens ein brauchbarer Verfalltag ab 18 Monaten; außerhalb der Handelszeit kein Urteil."""
    lang = [v for v in V if v["tage"] >= TAGE_18M]
    gut = [v for v in lang if v["stufe"] == "quantile"]
    offen = handelszeit(jetzt)
    return {"ab_12m": sum(1 for v in V if v["tage"] >= TAGE_12M), "ab_18m": len(lang), "brauchbar_18m": len(gut), "handelszeit": offen,
            "urteil": "kein Urteil" if not offen else ("erfüllt" if gut else "nicht erfüllt")}


# ================================================================================================ Abruf

def _http(url: str, timeout: float):
    return AK.http(url, timeout=timeout, art="bytes")


def abruf(url: str, http_fn) -> dict:
    """Ein Abruf: Status, Fehlertext, Größe, Dauer, gelesenes JSON (oder der Grund, warum nicht). Wirft nie."""
    t0 = time.monotonic()
    try:
        roh, err, status = http_fn(url, ABRUF_ZEIT_S)
    except Exception as e:
        roh, err, status = None, f"{type(e).__name__}: {e}", None
    out = {"url": url, "status": status if isinstance(status, int) else None, "fehler": sauber(err, 160) if err else None,
           "bytes": 0, "dauer": time.monotonic() - t0, "obj": None}
    if out["fehler"] or roh is None:
        out["fehler"] = out["fehler"] or "keine Daten"
        return out
    if isinstance(roh, str):
        roh = roh.encode("utf-8", "replace")
    if not isinstance(roh, (bytes, bytearray)):
        out["fehler"] = f"unerwarteter Inhalt ({type(roh).__name__})"
        return out
    out["bytes"] = len(roh)
    text = bytes(roh).decode("utf-8", "replace")
    try:
        out["obj"] = json.loads(text)
    except (ValueError, RecursionError):
        out["fehler"] = "HTML statt JSON (Sperre oder Fehlerseite)" if AK.ist_html(text) else "kein JSON: " + sauber(text[:80], 80)
    return out


def abruf_txt(a: dict) -> str:
    kopf = f"HTTP {a['status']}" if a["status"] is not None else "keine Antwort"
    if a["fehler"]:
        if a["status"] is not None and a["fehler"].startswith(kopf):       # der Fehlertext nennt den Code schon
            return f"{a['fehler']} · {de(a['dauer'], 1)} s"
        return f"{kopf} · {a['fehler']} · {de(a['dauer'], 1)} s"
    return f"{kopf} · {groesse_txt(a['bytes'])} · {de(a['dauer'], 1)} s"


# ================================================================================================ Bericht

F_DERIBIT = {"preis_n": 4, "termin_n": 0, "oi": "BTC", "preis": "BTC", "iv": lambda x: "—" if x is None else de(x, 1) + " %"}
F_IBIT = {"preis_n": 2, "termin_n": 2, "oi": "Kontrakte", "preis": "USD", "iv": lambda x: "—" if x is None else de(x, 3)}


def termin_txt(v: dict, f: dict) -> str:
    if v["termin"] is None:
        return "—"
    wie = {"feld": "Feld underlying_price", "paritaet": f"Parität am Strike {strike_txt(v['k_par']) if v['k_par'] is not None else '—'}",
           "kasse": "Kassakurs -- keine Parität möglich"}.get(v["termin_art"], "—")
    return f"{de(v['termin'], f['termin_n'])} USD ({wie})"


def tabelle(V: list, f: dict) -> list:
    z = [f"  {'Verfall':<10}{'Tage':>6}{'Strikes':>9}{'Kontrakte':>11}{'beide Kurse':>13}{'Terminkurs':>12}{'unter·über':>12}"
         f"{'Spanne am Geld':>16}{'IV am Geld':>12}{'offen':>10}  Stufe"]
    for v in V:
        z.append(f"  {datum(v['tag']):<10}{int(v['tage']):>6}{v['strikes']:>9}{v['kontrakte']:>11}{pz(v['anteil'], 0):>13}"
                 f"{de(v['termin'], f['termin_n']):>12}{(str(v['unter']) + '·' + str(v['ueber'])):>12}{pz(v['spanne']):>16}"
                 f"{f['iv'](v['iv']):>12}{de(v['oi'], 0):>10}  {STUFE_TXT[v['stufe']]}")
    return z


def einzel_zeile(v: dict, f: dict) -> str:
    kurs = lambda q: "—" if q is None else de(q, f["preis_n"])
    teile = [f"{datum(v['tag'])} · {int(v['tage'])} Tage: Terminkurs {termin_txt(v, f)}"]
    if v["k_geld"] is None:
        teile.append("kein Strike mit Call und Put")
    else:
        c, p = v["geld"]["c"], v["geld"]["p"]
        teile.append(f"am Geld Strike {strike_txt(v['k_geld'])}: Call {kurs(c[0])} / {kurs(c[1])} {f['preis']} (Spanne {pz(v['spanne_c'])}), "
                     f"Put {kurs(p[0])} / {kurs(p[1])} {f['preis']} (Spanne {pz(v['spanne_p'])}), Paar {pz(v['spanne'])}")
    teile.append(f"Strikes mit beiden Kursen: unter dem Terminkurs {v['unter']} (Puts), darüber {v['ueber']} (Calls)")
    teile.append(f"offen {de(v['oi'], 0)} {f['oi']}")
    teile.append(f"Stufe: {STUFE_TXT[v['stufe']]}" + (f" ({'; '.join(v['gruende'])})" if v["gruende"] else ""))
    return "  " + " · ".join(teile)


def stufen_zeile(V: list) -> str:
    q = [v for v in V if v["stufe"] == "quantile"]
    laengster = max(q, key=lambda v: v["verfall"]) if q else None
    return (f"Regel 9.2 (brauchbar für Quantile: je Seite mindestens {MIN_STRIKES} Strikes mit beiden Kursen, Spanne am Geld höchstens "
            f"{pz(MAX_SPANNE, 0)}): {len(q)} von {len(V)} Verfalltagen; nur IV am Geld: {sum(1 for v in V if v['stufe'] == 'iv')}; entfällt: "
            f"{sum(1 for v in V if v['stufe'] == 'entfaellt')}."
            + (f" Längster brauchbarer: {datum(laengster['tag'])} ({int(laengster['tage'])} Tage)." if laengster else ""))


def teil_deribit(http_fn, jetzt: float, kurz: list, gut: list) -> list:
    z = ["== 1. Deribit (BTC-Optionen) ==", f"Abruf: {DERIBIT_URL}"]
    a = abruf(DERIBIT_URL, http_fn)
    z.append(f"Antwort: {abruf_txt(a)}")
    if a["obj"] is None:
        kurz.append(f"Deribit: nicht erreichbar oder nicht lesbar ({abruf_txt(a)}).")
        return z
    L = deribit_lesen(a["obj"])
    if not L["ok"]:
        z.append(f"Nicht auswertbar: {L['grund']}. Aufbau der Antwort: {sauber(struktur(a['obj']), 700)}")
        kurz.append(f"Deribit: erreichbar (HTTP {a['status']}), aber nicht auswertbar ({L['grund']}).")
        return z
    V, vorbei = je_verfall(L["kontrakte"], jetzt)
    alle = [k for k in L["kontrakte"] if k["verfall"] > jetzt]
    z.append(f"Kontrakte: {de(len(alle), 0)} (mit Geld- und Briefkurs: {pz(sum(1 for k in alle if beide(k)) / len(alle), 0) if alle else '—'})"
             + (f" · schon verfallen: {vorbei}" if vorbei else "")
             + (f" · doppelte Kontrakte: {sum(v['doppelt'] for v in V)} (der erste zählt)" if any(v["doppelt"] for v in V) else "")
             + (f" · nicht lesbare Einträge: {L['unlesbar']}" + (f" (z. B. {', '.join(L['beispiele'])})" if L["beispiele"] else "")
                if L["unlesbar"] else ""))
    z.append(sauber(f"Felder je Kontrakt: {', '.join(L['felder'])}", 600))
    if not V:
        z.append("Kein kommender Verfalltag in der Antwort.")
        kurz.append(f"Deribit: erreichbar (HTTP {a['status']}), aber ohne kommenden Verfalltag.")
        return z
    z.append(f"Verfalltage: {len(V)} · längster: {datum(V[-1]['tag'])} (in {int(V[-1]['tage'])} Tagen) · Kurse in BTC · Terminkurs = Feld "
             "underlying_price (Median je Verfalltag) · IV = Feld mark_iv in Prozent · offen = offene Kontrakte in BTC")
    z.append("")
    z += tabelle(V, F_DERIBIT)
    z.append("")
    z.append("Die drei längsten Verfalltage im Einzelnen:")
    z += [einzel_zeile(v, F_DERIBIT) for v in V[-3:][::-1]]
    z.append("")
    z.append(stufen_zeile(V))
    q = sum(1 for v in V if v["stufe"] == "quantile")
    kurz.append(f"Deribit: erreichbar (HTTP {a['status']}), {len(V)} Verfalltage bis {datum(V[-1]['tag'])} ({int(V[-1]['tage'])} Tage), "
                f"{q} brauchbar für Quantile.")
    gut.append("Deribit")
    return z


def teil_ibit(http_fn, jetzt: float, kurz: list, gut: list) -> list:
    z = ["== 2. IBIT (Cboe, verzögerte Kurse) =="]
    a, L = None, None
    for i, url in enumerate(CBOE_URLS):
        a = abruf(url, http_fn)
        z.append(f"Abruf{'' if i == 0 else ' (zweiter Host, weil der erste nicht lieferte)'}: {url}")
        z.append(f"Antwort: {abruf_txt(a)}")
        if a["obj"] is not None:
            L = cboe_lesen(a["obj"])
            if L["ok"]:
                break
            z.append(f"Nicht auswertbar: {L['grund']}. Aufbau der Antwort: {sauber(struktur(a['obj']), 700)}")
    if a is None or a["obj"] is None or L is None or not L["ok"]:
        kurz.append(f"IBIT: nicht erreichbar oder nicht auswertbar ({abruf_txt(a) if a else 'kein Abruf'}"
                    + (f"; {L['grund']}" if L is not None and not L["ok"] else "") + ").")
        return z
    ny = AK.ny_jetzt(jetzt)
    offen = handelszeit(jetzt)
    z.append(f"Zeitstempel der Kurse: {L['zeitstempel'] or '—'}" + (f" (Feld {L['zeit_feld']}, Angabe der Quelle)" if L["zeit_feld"] else "")
             + f" · New York jetzt: {WOCHENTAG[ny.weekday()]} {ny.strftime('%d.%m. %H:%M')} · US-Handelszeit: {'ja' if offen else 'nein'} "
               "(gewertet wird an Handelstagen 9:45–16:15 New York, weil die Kurse 15 Minuten verzögert sind; frühe Schlüsse kennt der Lauf nicht)")
    z.append(f"IBIT-Kurs: {de(L['kurs'], 2) + ' USD (Feld ' + L['kurs_feld'] + ')' if L['kurs'] is not None else '— (kein Kursfeld gefunden)'}")
    V, vorbei = je_verfall(L["kontrakte"], jetzt, paritaet=True, kasse=L["kurs"])
    alle = [k for k in L["kontrakte"] if k["verfall"] > jetzt]
    andere = {w: n for w, n in L["wurzeln"].items() if w != CBOE_SYMBOL}
    z.append(f"Kontrakte: {de(len(alle), 0)} (mit Geld- und Briefkurs: {pz(sum(1 for k in alle if beide(k)) / len(alle), 0) if alle else '—'})"
             + f" · Liste unter „{L['pfad']}“ mit {de(L['gesamt'], 0)} Einträgen"
             + (f" · schon verfallen: {vorbei}" if vorbei else "")
             + (f" · doppelte Kontrakte: {sum(v['doppelt'] for v in V)} (der erste zählt)" if any(v["doppelt"] for v in V) else "")
             + (f" · andere Wurzeln (angepasste Kontrakte, nicht gewertet): "
                + ", ".join(f"{sauber(w, 8)} {n}" for w, n in sorted(andere.items())[:6]) if andere else "")
             + (f" · nicht lesbare Einträge: {L['unlesbar']}" + (f" (z. B. {', '.join(L['beispiele'])})" if L["beispiele"] else "")
                if L["unlesbar"] else ""))
    z.append(sauber(f"Felder je Kontrakt: {', '.join(L['felder'])}", 600))
    z.append(sauber(f"Felder zum Basiswert: {', '.join(L['kopf_felder']) or '—'}", 600))
    if not V:
        z.append("Kein kommender Verfalltag in der Antwort.")
        kurz.append(f"IBIT: erreichbar (HTTP {a['status']}), aber ohne kommenden Verfalltag.")
        return z
    z.append(f"Verfalltage: {len(V)} · längster: {datum(V[-1]['tag'])} (in {int(V[-1]['tage'])} Tagen) · Kurse in USD je Anteil · Terminkurs aus "
             "der Put-Call-Parität (Näherung) · IV = Feld iv der Quelle, Einheit ungeprüft (vermutlich Bruchteil: 0,500 = 50 %) · offen = "
             "offene Kontrakte")
    z.append("")
    z += tabelle(V, F_IBIT)
    z.append("")
    lang = [v for v in V if v["tage"] >= TAGE_12M]
    z.append(f"Verfalltage ab 12 Monaten ({TAGE_12M} Tage) im Einzelnen:" if lang else f"Kein Verfalltag ab 12 Monaten ({TAGE_12M} Tage).")
    z += [einzel_zeile(v, F_IBIT) for v in lang[::-1]]
    z.append("")
    z.append(stufen_zeile(V))
    U = ibit_urteil(V, jetzt)
    z.append(f"Bedingung 9.2 für IBIT (mindestens ein brauchbarer Verfalltag ab 18 Monaten = {TAGE_18M} Tagen): Verfalltage ab 18 Monaten "
             f"{U['ab_18m']}, davon brauchbar {U['brauchbar_18m']} -> in diesem Lauf: {U['urteil']}"
             + ("" if U["handelszeit"] else " (außerhalb der US-Handelszeit gemessen)")
             + ". Es zählt der erste Lauf in der Handelszeit; spätere ändern das Urteil nicht (KONZEPT_Langfrist.md 15, Z6).")
    kurz.append(f"IBIT: erreichbar (HTTP {a['status']}), {len(V)} Verfalltage bis {datum(V[-1]['tag'])} ({int(V[-1]['tage'])} Tage); ab 18 "
                f"Monaten {U['ab_18m']}, davon brauchbar {U['brauchbar_18m']} -> Bedingung 9.2 in diesem Lauf: {U['urteil']}.")
    gut.append("IBIT")
    return z


def erstlauf_text(http_fn=None, jetzt: float | None = None) -> str:
    """Der Bericht von Debug 154. Speichert nichts; wirft nie -- ein Fehler in einem Teil steht im Bericht, der andere Teil läuft."""
    http_fn = http_fn or _http
    jetzt = float(time.time() if jetzt is None else jetzt)
    z = [f"Optionen-Erstlauf ({PLAN}, Debug {DEBUG_NR}) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M', time.localtime(jetzt))}",
         "Je ein Abruf bei Deribit und bei Cboe; gespeichert wird nichts außer diesem Bericht. Gemessen wird, was die Quellen liefern; ob "
         f"Optionen in den 24-Monats-Chart kommen, regelt {REGEL}.", ""]
    kurz, gut = [], []
    for name, teil in (("Deribit", teil_deribit), ("IBIT", teil_ibit)):
        try:
            z += teil(http_fn, jetzt, kurz, gut)
        except Exception as e:                                              # darf nicht vorkommen; dann steht es hier statt eines Absturzes
            z.append(f"Auswertung {name} abgebrochen: {type(e).__name__}: {sauber(e, 160)} -- bitte diesen Bericht hochladen.")
            kurz.append(f"{name}: Auswertung abgebrochen ({type(e).__name__}).")
        z.append("")
    z.append("== 3. Kurz ==")
    z += kurz
    if len(gut) == 2:
        z.append("Gespeichert wurde nichts. Nächster Schritt laut Konzept: Nachtrag zum Rechenweg der Quantile (9.2), dann die Markt-Schicht (U280).")
    else:
        fehlt = [n for n in ("Deribit", "IBIT") if n not in gut]
        z.append(f"Gespeichert wurde nichts. Nicht auswertbar in diesem Lauf: {' und '.join(fehlt)} -- bitte den Bericht hochladen; über "
                 "die Quelle wird danach entschieden.")
    return "\n".join(z)


# ================================================================================================ Selbsttest (ohne Netz)

def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_optionen -- Selbsttest (Erstlauf der Optionen; ohne Netz, nachgebaute Antworten von Deribit und Cboe)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_optionen_test_")
    alt_cwd = os.getcwd()
    try:
        utc = timezone.utc
        JETZT = datetime(2026, 11, 20, 20, 0, tzinfo=utc).timestamp()          # Freitag, 15:00 in New York
        nah = lambda a, b, tol=1e-9: a is not None and abs(a - b) <= tol

        # ---- O1 Kennungen von Deribit
        n1 = deribit_name("BTC-27MAR27-100000-C"); n2 = deribit_name("BTC-3JAN27-90000-P")
        ok("O1 Deribit-Kennung: Tag, Monat, Jahr, Strike, Art; Verfall um 08:00 UTC; einstelliger Tag; Unlesbares ist None",
           n1 == (int(datetime(2027, 3, 27, 8, tzinfo=utc).timestamp()), date(2027, 3, 27), 100_000.0, "C")
           and n2 == (int(datetime(2027, 1, 3, 8, tzinfo=utc).timestamp()), date(2027, 1, 3), 90_000.0, "P")
           and all(deribit_name(x) is None for x in ("BTC-PERPETUAL", "ETH-27MAR27-3000-C", "BTC-27XXX27-100000-C", "BTC-31FEB27-100000-C",
                                                     "btc-27mar27-100000-c", "BTC-27MAR27-100000-X", "BTC-27MAR27-100000-C ", "", None, 5, [])),
           f"{n1}")
        # ---- O2 OCC-Kennungen
        o1 = occ_name("IBIT281215C00055000"); o2 = occ_name("IBIT  270115P00052500"); o3 = occ_name("IBIT1261218C00050000")
        ok("O2 OCC-Kennung: Wurzel, Tag, Art, Strike in Tausendsteln; Leerzeichen nach der Wurzel; angepasste Wurzel als eigene; Unlesbares "
           "ist None; Verfall um 16:00 New York (Winter 21:00 UTC, Sommer 20:00 UTC)",
           o1 == ("IBIT", date(2028, 12, 15), "C", 55.0) and o2 == ("IBIT", date(2027, 1, 15), "P", 52.5)
           and o3 == ("IBIT1", date(2026, 12, 18), "C", 50.0)
           and all(occ_name(x) is None for x in ("IBIT", "IBIT281315C00055000", "IBIT281215X00055000", "IBIT281215C0005500", "281215C00055000",
                                                 "ibit281215C00055000", "ZUVIELEBUCHSTABEN281215C00055000", "", None, 7, {}))
           and AK.ny_ts(date(2028, 12, 15), 16) == int(datetime(2028, 12, 15, 21, tzinfo=utc).timestamp())
           and AK.ny_ts(date(2028, 6, 16), 16) == int(datetime(2028, 6, 16, 20, tzinfo=utc).timestamp()), f"{o1} {o2} {o3}")
        # ---- O3 Zahlen und Kurse
        kq = lambda b, a: {"bid": b, "ask": a}
        ok("O3 Zahlen und Kurse (Z1): Zahl-Texte zählen, Leeres, Wahrheitswerte, NaN und unendlich nicht; Geld- und Briefkurs nur, wenn "
           "beide über 0 und Brief nicht unter Geld",
           zahl("1.5") == 1.5 and zahl(" 2 ") == 2.0 and zahl(3) == 3.0 and zahl(0) == 0.0
           and all(zahl(x) is None for x in (None, "", "abc", True, False, float("nan"), float("inf"), "nan", "inf", [1], {"a": 1}, "1,5"))
           and beide(kq(1.0, 1.0)) and beide(kq(0.0001, 0.0002))
           and not any(beide(kq(b, a)) for b, a in ((None, 1.0), (1.0, None), (0.0, 1.0), (1.0, 0.0), (-1.0, 1.0), (1.1, 1.0), (None, None))),
           "")

        # ---- nachgebaute Antworten
        def drb(name, bid, ask, iv, termin, oi=10.0):
            return {"instrument_name": name, "bid_price": bid, "ask_price": ask, "mid_price": None, "mark_price": 0.01, "mark_iv": iv,
                    "underlying_price": termin, "underlying_index": "SYN.BTC", "open_interest": oi, "volume": 0.0, "interest_rate": 0.0,
                    "creation_timestamp": 1, "base_currency": "BTC", "quote_currency": "BTC"}

        def deribit_antwort(aendern=None):
            res = []
            for k in range(70_000, 130_001, 5_000):                         # Verfall A: 27.03.2027, 13 Strikes, Terminkurs 100.000
                cb, ca, pb, pa = 0.0100, 0.0110, 0.0100, 0.0110
                if k == 100_000:
                    cb, ca, pb, pa = 0.1000, 0.1100, 0.0950, 0.1050
                if k == 70_000:
                    pb = None                                               # Put ohne Geldkurs -> unter dem Terminkurs 5 statt 6
                if k == 130_000:
                    ca = None                                               # Call ohne Briefkurs -> darüber 5 statt 6
                res.append(drb(f"BTC-27MAR27-{k}-C", cb, ca, 50.0, 99_990.0))
                res.append(drb(f"BTC-27MAR27-{k}-P", pb, pa, 52.0, 100_010.0))
            for k in (90_000, 100_000, 110_000):                            # Verfall B: 25.12.2026, je Seite ein Strike
                res.append(drb(f"BTC-25DEC26-{k}-C", 0.02, 0.022, 45.0, 100_000.0))
                res.append(drb(f"BTC-25DEC26-{k}-P", 0.02, 0.022, 45.0, 100_000.0))
            res.append(drb("BTC-3JAN27-100000-C", 0.03, 0.033, 47.0, 100_000.0))     # Verfall C: nur ein Call
            res.append(drb("BTC-20NOV26-100000-C", 0.001, 0.002, 40.0, 100_000.0))   # heute 08:00 UTC verfallen
            res.append(drb("BTC-PERPETUAL", 1.0, 2.0, None, None))
            res.append(drb("ETH-27MAR27-3000-C", 1.0, 2.0, 60.0, 3000.0))
            res.append("kein Objekt")
            if aendern:
                aendern(res)
            return {"jsonrpc": "2.0", "result": res, "usIn": 1, "usOut": 2, "usDiff": 1, "testnet": False}

        def cb(sym, bid, ask, iv=0.5, oi=100):
            return {"option": sym, "bid": bid, "bid_size": 10, "ask": ask, "ask_size": 10, "iv": iv, "open_interest": oi, "volume": 0,
                    "delta": 0.5, "gamma": 0.0, "theta": 0.0, "rho": 0.0, "vega": 0.0, "theo": 1.0, "last_trade_price": 1.0}

        def occ(d, typ, strike, wurzel="IBIT"):
            return f"{wurzel}{d.strftime('%y%m%d')}{typ}{int(round(strike * 1000)):08d}"

        L1, L2, KURZ = date(2028, 12, 15), date(2028, 1, 21), date(2026, 12, 18)

        def cboe_antwort(aendern=None, kopf=None):
            opt = []
            for k in range(30, 81, 5):                                      # Verfall L1: 15.12.2028, 11 Strikes
                if k == 55:
                    c, p = (9.00, 9.40), (8.80, 9.20)
                elif k > 55:
                    c, p = (1.00, 1.10), (20.00, 21.00)
                else:
                    c, p = (20.00, 21.00), (1.00, 1.10)
                opt.append(cb(occ(L1, "C", k), c[0], c[1], 0.52)); opt.append(cb(occ(L1, "P", k), p[0], p[1], 0.54))
            for k, c, p in ((40, (12.0, 12.5), (2.0, 2.5)), (50, (5.0, 5.5), (5.0, 5.5)), (60, (2.0, 2.5), (12.0, 12.5))):
                opt.append(cb(occ(L2, "C", k), c[0], c[1], "0.6")); opt.append(cb(occ(L2, "P", k), p[0], p[1], 0.0))   # L2: 21.01.2028
            for k in (45, 50, 55):                                          # kurzer Verfall 18.12.2026
                opt.append(cb(occ(KURZ, "C", k), 2.0, 2.1)); opt.append(cb(occ(KURZ, "P", k), 2.0, 2.1))
            opt.append(cb(occ(KURZ, "C", 50, "IBIT1"), 2.0, 2.1))           # angepasster Kontrakt: gezählt, nicht gewertet
            opt.append({"option": "XYZ", "bid": 1})
            opt.append(None)
            if aendern:
                aendern(opt)
            daten = {"options": opt, "symbol": "IBIT", "current_price": 50.0, "close": 49.5, "bid": 49.99, "ask": 50.01, "iv30": 55.0,
                     "last_trade_time": "2026-11-20T14:59:57"}
            daten.update(kopf or {})
            return {"timestamp": "2026-11-20 14:59:58", "data": daten, "symbol": "IBIT"}

        # ---- O4 Kennzahlen eines Verfalltags von Hand (Deribit, Verfall A)
        Ld = deribit_lesen(deribit_antwort())
        Vd, vorbei_d = je_verfall(Ld["kontrakte"], JETZT)
        A = next((v for v in Vd if v["tag"] == date(2027, 3, 27)), {})
        ok("O4 Kennzahlen von Hand (Deribit, 27.03.2027): Terminkurs = Median von underlying_price (100.000), 13 Strikes, 26 Kontrakte, 24 "
           "mit beiden Kursen; unter dem Terminkurs 5 Puts (der sechste ohne Geldkurs), darüber 5 Calls (der sechste ohne Briefkurs), der "
           "Strike genau am Terminkurs zählt für keine Seite; am Geld 100.000: Call 9,52 %, Put 10,0 %, Paar 0,02 ÷ 0,205 = 9,76 %; IV 51; "
           "offen 260; 126 Tage",
           A.get("termin") == 100_000.0 and A.get("termin_art") == "feld" and A.get("strikes") == 13 and A.get("kontrakte") == 26
           and A.get("beide") == 24 and nah(A.get("anteil"), 24 / 26) and A.get("unter") == 5 and A.get("ueber") == 5
           and A.get("k_geld") == 100_000.0 and nah(A.get("spanne_c"), 0.01 / 0.105) and nah(A.get("spanne_p"), 0.1)
           and nah(A.get("spanne"), 0.02 / 0.205) and nah(A.get("iv"), 51.0) and nah(A.get("oi"), 260.0) and A.get("stufe") == "quantile"
           and A.get("gruende") == [] and int(A.get("tage", 0)) == 126 and nah(A.get("tage"), 126.5) and A.get("doppelt") == 0
           and A.get("geld") == {"c": (0.1, 0.11), "p": (0.095, 0.105)},
           f"unter {A.get('unter')}, über {A.get('ueber')}, Paar {A.get('spanne')}, Tage {A.get('tage')}")
        Bv = next((v for v in Vd if v["tag"] == date(2026, 12, 25)), {}); Cv = next((v for v in Vd if v["tag"] == date(2027, 1, 3)), {})
        ok("O5 Stufen nach 9.2: je Seite nur ein Strike -> nicht brauchbar, aber IV am Geld vorhanden -> „nur IV am Geld“ mit beiden "
           "Gründen; nur ein Call, kein Put -> „entfällt“; Verfalltage aufsteigend, der heute um 08:00 UTC verfallene zählt nicht; "
           "Unlesbares gezählt und mit Beispielen",
           Bv.get("stufe") == "iv" and Bv.get("unter") == 1 and Bv.get("ueber") == 1 and nah(Bv.get("iv"), 45.0)
           and Bv.get("gruende") == ["unter dem Terminkurs nur 1 Strike mit beiden Kursen", "darüber nur 1 Strike mit beiden Kursen"]
           and Cv.get("stufe") == "entfaellt" and Cv.get("k_geld") is None and "kein Strike mit Call und Put" in Cv.get("gruende", [])
           and [v["tag"] for v in Vd] == [date(2026, 12, 25), date(2027, 1, 3), date(2027, 3, 27)] and vorbei_d == 1
           and Ld["ok"] and Ld["gesamt"] == 37 and len(Ld["kontrakte"]) == 34 and Ld["unlesbar"] == 3
           and Ld["beispiele"] == ["BTC-PERPETUAL", "ETH-27MAR27-3000-C"] and Ld["felder"][:3] == ["instrument_name", "bid_price", "ask_price"],
           f"B {Bv.get('stufe')}, C {Cv.get('stufe')}; {len(Ld['kontrakte'])} Kontrakte, {Ld['unlesbar']} unlesbar")

        # ---- O6 Grenzen der Regel
        def kette(n_unter, n_ueber, c_geld, p_geld, iv=50.0):
            K = [{"verfall": 1, "tag": date(2027, 3, 27), "strike": 100.0, "typ": "C", "bid": c_geld[0], "ask": c_geld[1], "iv": iv, "oi": 1.0, "termin": 100.0},
                 {"verfall": 1, "tag": date(2027, 3, 27), "strike": 100.0, "typ": "P", "bid": p_geld[0], "ask": p_geld[1], "iv": iv, "oi": 1.0, "termin": 100.0}]
            for i in range(1, 9):
                K.append({"verfall": 1, "tag": date(2027, 3, 27), "strike": 100.0 - i, "typ": "P", "bid": 1.0 if i <= n_unter else None, "ask": 1.1,
                          "iv": iv, "oi": 1.0, "termin": 100.0})
                K.append({"verfall": 1, "tag": date(2027, 3, 27), "strike": 100.0 + i, "typ": "C", "bid": 1.0 if i <= n_ueber else None, "ask": 1.1,
                          "iv": iv, "oi": 1.0, "termin": 100.0})
            return K
        g15 = kennzahlen(kette(5, 5, (0.925, 1.075), (0.925, 1.075)))        # Paar: 0,30 ÷ 2,00 = 15 % genau
        g15b = kennzahlen(kette(5, 5, (0.925, 1.0751), (0.925, 1.075)))      # knapp darüber
        g4u = kennzahlen(kette(4, 5, (1.0, 1.05), (1.0, 1.05))); g4o = kennzahlen(kette(5, 4, (1.0, 1.05), (1.0, 1.05)))
        g15r = kennzahlen(kette(5, 5, (0.111, 0.129), (0.111, 0.129)))       # rechnerisch 15 %, im Rechner 0,15000000000000008
        g0 = kennzahlen(kette(5, 5, (None, 1.05), (1.0, 1.05))); gk = kennzahlen(kette(4, 5, (1.0, 1.05), (1.0, 1.05), iv=None))
        gz = kennzahlen(kette(4, 5, (1.0, 1.05), (1.0, 1.05), iv=0.0))
        ok("O6 Grenzen der Regel 9.2: genau 5 Strikes je Seite und genau 15 % Spanne am Geld sind brauchbar (trotz Rundung im Rechner); 4 "
           "unter oder 4 über dem Terminkurs nicht; knapp über 15 % nicht; fehlt am Geld ein Kurs, gibt es keine Spanne; ohne IV am Geld "
           "(fehlend oder 0) „entfällt“",
           g15["stufe"] == "quantile" and nah(g15["spanne"], 0.15, 1e-12) and g15["unter"] == 5 and g15["ueber"] == 5
           and g15r["stufe"] == "quantile" and 0.15 < g15r["spanne"] < 0.15 + 1e-12
           and g15b["stufe"] == "iv" and g15b["gruende"] == ["Spanne am Geld 15,0 % über 15 %"]
           and g4u["stufe"] == "iv" and g4u["gruende"] == ["unter dem Terminkurs nur 4 Strikes mit beiden Kursen"]
           and g4o["stufe"] == "iv" and g4o["gruende"] == ["darüber nur 4 Strikes mit beiden Kursen"]
           and g0["spanne"] is None and g0["spanne_c"] is None and nah(g0["spanne_p"], 0.05 / 1.025) and g0["stufe"] == "iv"
           and g0["gruende"] == ["am Geld fehlt ein Geld- oder Briefkurs"] and gk["stufe"] == "entfaellt" and gz["stufe"] == "entfaellt"
           and MIN_STRIKES == 5 and MAX_SPANNE == 0.15 and TAGE_12M == 365 and TAGE_18M == 548, f"15 %: {g15['spanne']!r}; knapp darüber {g15b['spanne']!r}")

        # ---- O7 Terminkurs aus der Parität (IBIT) von Hand, Seiten, am Geld
        Lc = cboe_lesen(cboe_antwort())
        Vc, vorbei_c = je_verfall(Lc["kontrakte"], JETZT, paritaet=True, kasse=Lc["kurs"])
        E1 = next((v for v in Vc if v["tag"] == L1), {}); E2 = next((v for v in Vc if v["tag"] == L2), {})
        ok("O7 IBIT von Hand (15.12.2028): Terminkurs aus der Parität am Strike mit dem kleinsten Abstand von Call und Put (55): 55 + 9,20 − "
           "9,00 = 55,20; unter dem Terminkurs 6 Puts (30 bis 55), darüber 5 Calls (60 bis 80); am Geld 55: Paar 0,80 ÷ 18,20 = 4,40 %; IV "
           "0,53; offen 2.200; 756 Tage; Stufe Quantile. 21.01.2028 (427 Tage): je Seite ein Strike, IV als Text gelesen, IV 0 zählt nicht "
           "-> nur IV am Geld",
           nah(E1.get("termin"), 55.2) and E1.get("termin_art") == "paritaet" and E1.get("k_par") == 55.0 and E1.get("unter") == 6
           and E1.get("ueber") == 5 and E1.get("k_geld") == 55.0 and nah(E1.get("spanne"), 0.8 / 18.2) and nah(E1.get("spanne_c"), 0.4 / 9.2)
           and nah(E1.get("spanne_p"), 0.4 / 9.0) and nah(E1.get("iv"), 0.53) and nah(E1.get("oi"), 2200.0) and E1.get("stufe") == "quantile"
           and int(E1.get("tage", 0)) == 756 and E1.get("strikes") == 11 and E1.get("kontrakte") == 22
           and int(E2.get("tage", 0)) == 427 and E2.get("stufe") == "iv" and nah(E2.get("iv"), 0.6) and nah(E2.get("termin"), 50.0)
           and E2.get("unter") == 1 and E2.get("ueber") == 1,
           f"Terminkurs {E1.get('termin')}, {E1.get('unter')}·{E1.get('ueber')}, Paar {E1.get('spanne')}, Tage {E1.get('tage')}")
        ohne_paar = [dict(k, bid=None) if k["typ"] == "P" else k for k in Lc["kontrakte"] if k["tag"] == L1]
        kp = kennzahlen(ohne_paar, paritaet=True, kasse=50.0); kn = kennzahlen(ohne_paar, paritaet=True, kasse=None)
        kf = kennzahlen(ohne_paar, paritaet=False, kasse=50.0)
        gleich = [dict(k, bid=5.0, ask=5.5) for k in Lc["kontrakte"] if k["tag"] == L1 and k["strike"] in (50.0, 55.0)]
        kg_ = kennzahlen(gleich, paritaet=True)
        mitte_ = [dict(k, bid=5.0, ask=5.5, termin=52.5) for k in Lc["kontrakte"] if k["tag"] == L1 and k["strike"] in (50.0, 55.0)]
        km = kennzahlen(mitte_)
        ok("O8 Terminkurs, Rückfälle (Z2, Z4): ohne ein Paar mit beiden Kursen der Kassakurs (so benannt); ohne Kassakurs keiner -> „kein "
           "Terminkurs“; ohne Parität (Deribit) kein Rückgriff auf den Kassakurs; bei gleichem Abstand von Call und Put der niedrigere "
           "Strike; liegt der Terminkurs genau zwischen zwei Strikes, ist der niedrigere „am Geld“",
           kp["termin"] == 50.0 and kp["termin_art"] == "kasse" and kp["unter"] == 0 and kp["ueber"] == 6 and kp["stufe"] == "iv"
           and kn["termin"] is None and kn["termin_art"] == "keiner" and kn["gruende"] == ["kein Terminkurs"] and kn["k_geld"] is None
           and kn["stufe"] == "entfaellt" and kf["termin"] is None
           and kg_["k_par"] == 50.0 and nah(kg_["termin"], 50.0) and km["k_geld"] == 50.0 and km["unter"] == 1 and km["ueber"] == 1,
           f"Kasse {kp['termin']} ({kp['termin_art']}); ohne {kn['termin_art']}; Gleichstand Strike {kg_['k_par']}; Mitte {km['k_geld']}")

        # ---- O9 Cboe lesen
        ok("O9 Cboe lesen: Liste unter data.options, Kontrakte nur der Wurzel IBIT (die angepasste Wurzel IBIT1 gezählt, nicht gewertet), "
           "Kassakurs aus current_price, Zeitstempel der Quelle, Unlesbares gezählt, Felder genannt; kommende Verfalltage aufsteigend",
           Lc["ok"] and Lc["pfad"] == "data.options" and Lc["gesamt"] == 37 and len(Lc["kontrakte"]) == 34 and Lc["wurzeln"] == {"IBIT": 34, "IBIT1": 1}
           and Lc["unlesbar"] == 2 and Lc["beispiele"] == ["XYZ"] and Lc["kurs"] == 50.0 and Lc["kurs_feld"] == "current_price"
           and Lc["zeitstempel"] == "2026-11-20 14:59:58" and Lc["zeit_feld"] == "timestamp" and Lc["felder"][:3] == ["option", "bid", "bid_size"]
           and "current_price" in Lc["kopf_felder"] and "options" not in Lc["kopf_felder"]
           and [v["tag"] for v in Vc] == [KURZ, L2, L1] and vorbei_c == 0 and int(Vc[0]["tage"]) == 28,
           f"{len(Lc['kontrakte'])} Kontrakte, Wurzeln {Lc['wurzeln']}, Kurs {Lc['kurs']} ({Lc['kurs_feld']})")
        roh = cboe_antwort()
        anders = {"stand": roh["timestamp"], "kette": {"IBIT": {"liste": roh["data"]["options"], "close": "49.5"}}}
        La = cboe_lesen(anders)
        flach = cboe_lesen(roh["data"]["options"])
        ok("O10 Cboe, anderer Aufbau: Die Kontrakte werden an ihren OCC-Kennungen gefunden, auch wenn die Liste woanders liegt (Pfad genannt) "
           "oder die Antwort selbst die Liste ist; fehlt der Kurs, bleibt er leer; ohne erkennbare Liste eine klare Meldung statt eines Absturzes",
           La["ok"] and La["pfad"] == "kette.IBIT.liste" and len(La["kontrakte"]) == 34 and La["kurs"] is None and La["zeitstempel"] is None
           and flach["ok"] and flach["pfad"] == "(oberste Ebene)" and len(flach["kontrakte"]) == 34
           and all(not cboe_lesen(x)["ok"] and cboe_lesen(x)["grund"] for x in (None, 5, "text", [], {}, {"data": {"options": []}}, {"data": 3},
                                                                                {"data": {"options": [{"option": "SPY281215C00055000"}]}}))
           and cboe_lesen({"data": {"options": [{"option": "SPY281215C00055000"}]}})["grund"] == "keine Option mit der Wurzel IBIT in der Liste (data.options)",
           f"Pfad {La['pfad']}; flach {flach['pfad']}")
        # ---- O11 Deribit, unerwartete Antworten
        ok("O11 Deribit, unerwartete Antworten: Fehlermeldung der Börse wird genannt; fehlt „result“ oder ist es keine Liste, steht der Grund "
           "da; eine Liste ohne lesbare BTC-Option ebenso; nichts davon wirft",
           deribit_lesen({"jsonrpc": "2.0", "error": {"message": "Invalid params", "code": -32602}})["grund"] == "Fehler der Börse: Invalid params (Code -32602)"
           and deribit_lesen({"jsonrpc": "2.0"})["grund"] == "Schlüssel „result“ fehlt" and deribit_lesen({"result": {"a": 1}})["grund"] == "„result“ ist keine Liste"
           and deribit_lesen({"result": [{"instrument_name": "BTC-PERPETUAL"}, 5]})["grund"] == "keine lesbare BTC-Option in der Antwort"
           and all(not deribit_lesen(x)["ok"] and deribit_lesen(x)["grund"] for x in (None, 5, "text", [], {}, {"result": None}, {"result": []})), "")
        ok("O12 Aufbau einer unerwarteten Antwort: Typen, Schlüssel und Längen ohne Werte; begrenzt in Tiefe und Breite; Schlüssel aus dem "
           "Netz gekürzt und ohne Steuerzeichen",
           struktur({"a": 1, "b": "xy", "c": [{"d": None, "e": True}], "f": {"g": {"h": {"i": {"j": 1}}}}})
           == "Objekt {a: Zahl, b: Text (2 Zeichen), c: Liste mit 1 Einträgen; erster Eintrag: Objekt {d: leer (null), e: Wahrheitswert}, "
              "f: Objekt {g: Objekt {h: Objekt {i: Objekt mit 1 Schlüsseln}}}}"
           and struktur({str(i): i for i in range(20)}).endswith(", … (+8)}") and struktur([]) == "Liste mit 0 Einträgen"
           and struktur({"x" * 500 + "\n\x00": 1}) == "Objekt {" + "x" * 29 + "…: Zahl}" and sauber("a\n\tb\x00c  d", 80) == "a b c d"
           and sauber("x" * 100, 10) == "x" * 9 + "…" and de(1234567.891, 2) == "1.234.567,89" and de(None) == "—" and pz(0.0976, 1) == "9,8 %"
           and strike_txt(55.0) == "55" and strike_txt(52.5) == "52,50" and strike_txt(100_000.0) == "100.000"
           and groesse_txt(812_000) == "812 kB" and groesse_txt(3_400_000) == "3,4 MB" and groesse_txt(999) == "999 Bytes", struktur({"a": [1, 2]}))

        # ---- O13 Handelszeit und Urteil (Z6)
        t_fr = JETZT                                                         # Fr 20.11.2026 15:00 New York
        t_sa = datetime(2026, 11, 21, 20, 0, tzinfo=utc).timestamp()          # Samstag
        t_941 = datetime(2026, 11, 20, 14, 41, tzinfo=utc).timestamp()        # 9:41 New York: der gezeigte Stand (9:26) liegt vor der Eröffnung
        t_946 = datetime(2026, 11, 20, 14, 46, tzinfo=utc).timestamp()        # 9:46: Stand 9:31
        t_1614 = datetime(2026, 11, 20, 21, 14, tzinfo=utc).timestamp()       # 16:14: Stand 15:59
        t_1616 = datetime(2026, 11, 20, 21, 16, tzinfo=utc).timestamp()       # 16:16: Stand 16:01
        t_dank = datetime(2026, 11, 26, 18, 0, tzinfo=utc).timestamp()        # Thanksgiving, 13:00 New York
        U1 = ibit_urteil(Vc, t_fr); U2 = ibit_urteil(Vc, t_sa)
        V_ohne = [dict(v, stufe="iv") if v["tag"] == L1 else v for v in Vc]
        U3 = ibit_urteil(V_ohne, t_fr); U4 = ibit_urteil([v for v in Vc if v["tag"] != L1], t_fr)
        ok("O13 Handelszeit und Bedingung für IBIT (Z6): gewertet wird nur, wenn der verzögert gezeigte Stand in der Handelszeit liegt (9:45 "
           "bis 16:15 New York an Handelstagen; Samstag und Feiertag nicht); mit einem brauchbaren Verfalltag ab 548 Tagen „erfüllt“, ohne "
           "ihn „nicht erfüllt“, außerhalb der Handelszeit „kein Urteil“; 427 Tage zählen ab 12, nicht ab 18 Monaten",
           handelszeit(t_fr) and not handelszeit(t_sa) and not handelszeit(t_941) and handelszeit(t_946) and handelszeit(t_1614)
           and not handelszeit(t_1616) and not handelszeit(t_dank)
           and U1 == {"ab_12m": 2, "ab_18m": 1, "brauchbar_18m": 1, "handelszeit": True, "urteil": "erfüllt"}
           and U2["urteil"] == "kein Urteil" and U2["brauchbar_18m"] == 1 and U2["handelszeit"] is False
           and U3["urteil"] == "nicht erfüllt" and U3["ab_18m"] == 1 and U3["brauchbar_18m"] == 0
           and U4 == {"ab_12m": 1, "ab_18m": 0, "brauchbar_18m": 0, "handelszeit": True, "urteil": "nicht erfüllt"},
           f"{U1['urteil']} / {U2['urteil']} / {U3['urteil']} / {U4['urteil']}")
        grenze = [dict(Vc[-1], tage=548.0), dict(Vc[-1], tage=547.99), dict(Vc[-1], tage=365.0), dict(Vc[-1], tage=364.99)]
        ok("O14 Grenzen der Laufzeit: genau 548 Tage zählen als 18 Monate, 547,99 nicht; genau 365 Tage als 12 Monate, 364,99 nicht",
           ibit_urteil(grenze[:1], t_fr)["ab_18m"] == 1 and ibit_urteil(grenze[1:2], t_fr)["ab_18m"] == 0
           and ibit_urteil(grenze[2:3], t_fr)["ab_12m"] == 1 and ibit_urteil(grenze[3:], t_fr)["ab_12m"] == 0, "")

        # ---- O15 der ganze Bericht mit nachgebautem Abruf
        rufe = []

        def netz(antworten):
            def fn(url, timeout):
                rufe.append((url, timeout))
                a = antworten.get(url, (None, "HTTP 404: Not Found", 404))
                if isinstance(a, Exception):
                    raise a
                return a
            return fn
        js = lambda o: json.dumps(o).encode()
        gut = {DERIBIT_URL: (js(deribit_antwort()), None, 200), CBOE_URLS[0]: (js(cboe_antwort()), None, 200)}
        os.chdir(tmp)
        del rufe[:]
        T = erstlauf_text(netz(gut), JETZT)
        Z = T.split("\n")
        zeile = lambda anfang: next((l for l in Z if l.startswith(anfang)), "")
        ok("O15 Bericht, beide Quellen liefern: je EIN Abruf (Deribit, erster Cboe-Host; der zweite Host wird nicht gefragt), Zeitgrenze 40 s; "
           "Kopf mit Plan- und Debugnummer; drei Teile; gespeichert wird nichts (Arbeitsordner bleibt leer)",
           [r[0] for r in rufe] == [DERIBIT_URL, CBOE_URLS[0]] and all(r[1] == ABRUF_ZEIT_S == 40 for r in rufe)
           and Z[0].startswith("Optionen-Erstlauf (U278, Debug 154) · Modul 2026-09-23.113 · ")
           and [l for l in Z if l.startswith("== ")] == ["== 1. Deribit (BTC-Optionen) ==", "== 2. IBIT (Cboe, verzögerte Kurse) ==", "== 3. Kurz =="]
           and os.listdir(tmp) == [] and "Auswertung" not in T and "abgebrochen" not in T, f"{len(Z)} Zeilen, {len(T)} Zeichen")
        ok("O16 Bericht Deribit, Zeilen von Hand: Kontrakte ohne den verfallenen, Anteil mit beiden Kursen, Unlesbares mit Beispielen; die "
           "Tabellenzeile des 27.03.2027; die Einzelzeile mit Kursen am Geld und allen drei Spannen; die Zeile der Stufen",
           zeile("Kontrakte: 33 (mit Geld- und Briefkurs: 94 %) · schon verfallen: 1 · nicht lesbare Einträge: 3 (z. B. BTC-PERPETUAL, ETH-27MAR27-3000-C)") != ""
           and zeile("Verfalltage: 3 · längster: 27.03.2027 (in 126 Tagen) · Kurse in BTC") != ""
           and ("  27.03.2027   126       13         26         92 %     100.000         5·5           9,8 %      51,0 %       260  Quantile") in Z
           and ("  27.03.2027 · 126 Tage: Terminkurs 100.000 USD (Feld underlying_price) · am Geld Strike 100.000: Call 0,1000 / 0,1100 BTC "
                "(Spanne 9,5 %), Put 0,0950 / 0,1050 BTC (Spanne 10,0 %), Paar 9,8 % · Strikes mit beiden Kursen: unter dem Terminkurs 5 "
                "(Puts), darüber 5 (Calls) · offen 260 BTC · Stufe: Quantile") in Z
           and ("  03.01.2027 · 43 Tage: Terminkurs 100.000 USD (Feld underlying_price) · kein Strike mit Call und Put · Strikes mit beiden "
                "Kursen: unter dem Terminkurs 0 (Puts), darüber 0 (Calls) · offen 10 BTC · Stufe: entfällt (unter dem Terminkurs nur 0 Strikes "
                "mit beiden Kursen; darüber nur 0 Strikes mit beiden Kursen; kein Strike mit Call und Put)") in Z
           and ("Regel 9.2 (brauchbar für Quantile: je Seite mindestens 5 Strikes mit beiden Kursen, Spanne am Geld höchstens 15 %): 1 von 3 "
                "Verfalltagen; nur IV am Geld: 1; entfällt: 1. Längster brauchbarer: 27.03.2027 (126 Tage).") in Z
           and Z.index("Die drei längsten Verfalltage im Einzelnen:") + 1 == next(i for i, l in enumerate(Z) if l.startswith("  27.03.2027 · 126 Tage")),
           zeile("  27.03.2027   126"))
        ok("O17 Bericht IBIT, Zeilen von Hand: Zeitstempel der Quelle, New York jetzt und Handelszeit; Kurs mit Feldname; Kontrakte mit "
           "Pfad und anderen Wurzeln; Tabellenzeile und Einzelzeile des 15.12.2028; nur Verfalltage ab 12 Monaten einzeln, der längste "
           "zuerst; Bedingung 9.2 „erfüllt“",
           zeile("Zeitstempel der Kurse: 2026-11-20 14:59:58 (Feld timestamp, Angabe der Quelle) · New York jetzt: Fr 20.11. 15:00 · US-Handelszeit: ja ") != ""
           and "IBIT-Kurs: 50,00 USD (Feld current_price)" in Z
           and zeile("Kontrakte: 34 (mit Geld- und Briefkurs: 100 %) · Liste unter „data.options“ mit 37 Einträgen · andere Wurzeln (angepasste "
                     "Kontrakte, nicht gewertet): IBIT1 1 · nicht lesbare Einträge: 2 (z. B. XYZ)") != ""
           and ("  15.12.2028   756       11         22        100 %       55,20         6·5           4,4 %       0,530     2.200  Quantile") in Z
           and ("  15.12.2028 · 756 Tage: Terminkurs 55,20 USD (Parität am Strike 55) · am Geld Strike 55: Call 9,00 / 9,40 USD (Spanne 4,3 %), "
                "Put 8,80 / 9,20 USD (Spanne 4,4 %), Paar 4,4 % · Strikes mit beiden Kursen: unter dem Terminkurs 6 (Puts), darüber 5 (Calls) · "
                "offen 2.200 Kontrakte · Stufe: Quantile") in Z
           and Z.index("Verfalltage ab 12 Monaten (365 Tage) im Einzelnen:") + 1 == next(i for i, l in enumerate(Z) if l.startswith("  15.12.2028 · 756 Tage"))
           and sum(1 for l in Z if " Tage: Terminkurs " in l and l.startswith("  ")) == 3 + 2 and not any(l.startswith("  18.12.2026 · ") for l in Z)
           and ("Bedingung 9.2 für IBIT (mindestens ein brauchbarer Verfalltag ab 18 Monaten = 548 Tagen): Verfalltage ab 18 Monaten 1, davon "
                "brauchbar 1 -> in diesem Lauf: erfüllt. Es zählt der erste Lauf in der Handelszeit; spätere ändern das Urteil nicht "
                "(KONZEPT_Langfrist.md 15, Z6).") in Z,
           zeile("  15.12.2028   756"))
        ok("O18 Bericht, Teil „Kurz“: je Quelle eine Zeile mit Status, Reichweite und Zahl der brauchbaren Verfalltage; am Ende der Satz, "
           "dass nichts gespeichert wurde",
           Z[Z.index("== 3. Kurz ==") + 1:] == [
               "Deribit: erreichbar (HTTP 200), 3 Verfalltage bis 27.03.2027 (126 Tage), 1 brauchbar für Quantile.",
               "IBIT: erreichbar (HTTP 200), 3 Verfalltage bis 15.12.2028 (756 Tage); ab 18 Monaten 1, davon brauchbar 1 -> Bedingung 9.2 in diesem Lauf: erfüllt.",
               "Gespeichert wurde nichts. Nächster Schritt laut Konzept: Nachtrag zum Rechenweg der Quantile (9.2), dann die Markt-Schicht (U280)."],
           " | ".join(Z[Z.index("== 3. Kurz ==") + 1:])[:160])
        T_sa = erstlauf_text(netz(gut), t_sa)
        ok("O19 Bericht außerhalb der Handelszeit (Samstag): „US-Handelszeit: nein“ und „kein Urteil (außerhalb der US-Handelszeit "
           "gemessen)“ -- die Zahlen stehen trotzdem da",
           "New York jetzt: Sa 21.11. 15:00 · US-Handelszeit: nein " in T_sa and "davon brauchbar 1 -> in diesem Lauf: kein Urteil (außerhalb der "
           "US-Handelszeit gemessen). Es zählt der erste Lauf in der Handelszeit" in T_sa
           and "-> Bedingung 9.2 in diesem Lauf: kein Urteil." in T_sa and "  15.12.2028   755 " in T_sa, "")

        # ---- O20 Störungen im Abruf
        del rufe[:]
        T_403 = erstlauf_text(netz({DERIBIT_URL: (None, "HTTP 403: Forbidden", 403), CBOE_URLS[0]: (None, "HTTP 503: Service Unavailable", 503),
                                    CBOE_URLS[1]: (js(cboe_antwort()), None, 200)}), JETZT)
        ok("O20 Störung: Deribit antwortet mit 403 -> der Teil sagt es mit Statuscode, der IBIT-Teil läuft trotzdem; der erste Cboe-Host "
           "fällt aus -> der zweite wird gefragt (und nur dann), beide Antworten stehen im Bericht",
           [r[0] for r in rufe] == [DERIBIT_URL, CBOE_URLS[0], CBOE_URLS[1]]
           and "Antwort: HTTP 403: Forbidden · " in T_403 and "Deribit: nicht erreichbar oder nicht lesbar (HTTP 403: Forbidden · " in T_403
           and "Antwort: HTTP 503: Service Unavailable · " in T_403 and "HTTP 403 · HTTP 403" not in T_403
           and f"Abruf (zweiter Host, weil der erste nicht lieferte): {CBOE_URLS[1]}" in T_403
           and "IBIT: erreichbar (HTTP 200), 3 Verfalltage bis 15.12.2028" in T_403 and "== 1. Deribit" in T_403
           and T_403.endswith("Gespeichert wurde nichts. Nicht auswertbar in diesem Lauf: Deribit -- bitte den Bericht hochladen; über die "
                              "Quelle wird danach entschieden.") and "Nächster Schritt laut Konzept" not in T_403, "")
        del rufe[:]
        T_aus = erstlauf_text(netz({DERIBIT_URL: TimeoutError("timed out"), CBOE_URLS[0]: (b"<!DOCTYPE html><html><body>Access Denied</body></html>", None, 200),
                                    CBOE_URLS[1]: (b'{"data": {"options": [', None, 200)}), JETZT)
        ok("O21 Störung: Der Abruf wirft (Zeitüberschreitung), eine HTML-Seite statt JSON, abgeschnittenes JSON -> jeweils eine klare Zeile, "
           "kein Absturz, der Bericht hat alle drei Teile",
           len(rufe) == 3 and "Antwort: keine Antwort · TimeoutError: timed out · " in T_aus
           and "Antwort: HTTP 200 · HTML statt JSON (Sperre oder Fehlerseite) · " in T_aus and 'Antwort: HTTP 200 · kein JSON: {"data": {"options": [ · ' in T_aus
           and "IBIT: nicht erreichbar oder nicht auswertbar (HTTP 200 · kein JSON: " in T_aus and T_aus.count("\n== ") == 3 and T_aus.startswith("Optionen-Erstlauf")
           and "abgebrochen" not in T_aus and "Nicht auswertbar in diesem Lauf: Deribit und IBIT -- bitte den Bericht hochladen" in T_aus
           and "Nächster Schritt laut Konzept" not in T_aus, "")
        T_form = erstlauf_text(netz({DERIBIT_URL: (js({"jsonrpc": "2.0", "ergebnis": [1, 2]}), None, 200),
                                     CBOE_URLS[0]: (js({"timestamp": "x", "data": {"quotes": [{"symbol": "IBIT"}]}}), None, 200),
                                     CBOE_URLS[1]: (js([1, 2, 3]), None, 200)}), JETZT)
        ok("O22 unerwartetes Format: Der Bericht nennt den Grund und den Aufbau der Antwort (Schlüssel, Typen, Längen) für Deribit und für "
           "beide Cboe-Hosts, statt abzustürzen",
           "Nicht auswertbar: Schlüssel „result“ fehlt. Aufbau der Antwort: Objekt {jsonrpc: Text (3 Zeichen), ergebnis: Liste mit 2 Einträgen; "
           "erster Eintrag: Zahl}" in T_form
           and "Nicht auswertbar: keine Liste mit Options-Kennungen gefunden. Aufbau der Antwort: Objekt {timestamp: Text (1 Zeichen), data: "
               "Objekt {quotes: Liste mit 1 Einträgen; erster Eintrag: Objekt {symbol: Text (4 Zeichen)}}}" in T_form
           and "Aufbau der Antwort: Liste mit 3 Einträgen; erster Eintrag: Zahl" in T_form
           and "Deribit: erreichbar (HTTP 200), aber nicht auswertbar (Schlüssel „result“ fehlt)." in T_form
           and "IBIT: nicht erreichbar oder nicht auswertbar (HTTP 200 · " in T_form and "; keine Liste mit Options-Kennungen gefunden)." in T_form, "")
        # ---- O23 Unsinn in den Werten
        def unsinn_d(res):
            res.append(drb("BTC-27MAR27-100000-C", 9.0, 9.9, 1.0, 1.0))                 # doppelt: der erste Eintrag zählt
            res.append({"instrument_name": "BTC-26JUN27-100000-C", "bid_price": "abc", "ask_price": [], "mark_iv": float("nan"),
                        "underlying_price": {"x": 1}, "open_interest": None})
            res.append({"instrument_name": "BTC-26JUN27-100000-P", "bid_price": True, "ask_price": float("inf"), "mark_iv": "",
                        "underlying_price": -5, "open_interest": "7"})
            res.append({"instrument_name": "A" * 5000 + "\n\x1b[31m"})

        def unsinn_c(opt):
            opt.append(cb(occ(L1, "C", 55), 99.0, 99.9))                                # doppelt
            opt.append({"option": occ(date(2029, 1, 19), "C", 60), "bid": "x", "ask": None, "iv": [], "open_interest": {}})
            opt.append({"option": occ(date(2029, 1, 19), "P", 60), "bid": float("nan"), "ask": -1, "iv": True, "open_interest": "12"})
            opt.append({"x" * 300: 1, "option": "\x00\x07" * 50})
        T_un = erstlauf_text(netz({DERIBIT_URL: (json.dumps(deribit_antwort(unsinn_d)).encode(), None, 200),
                                   CBOE_URLS[0]: (json.dumps(cboe_antwort(unsinn_c, {"current_price": "NaN", "close": "49.5"})).encode(), None, 200)}), JETZT)
        Zu = T_un.split("\n")
        ok("O23 Unsinn in den Werten (Texte, Listen, NaN, unendlich, Wahrheitswerte, negative Kurse, doppelte Kontrakte, überlange Namen mit "
           "Steuerzeichen): kein Absturz; doppelte Kontrakte ändern die Kennzahlen nicht; ein Verfalltag ohne brauchbare Werte „entfällt“; "
           "fehlt current_price, wird der nächste Kurs mit seinem Feldnamen genommen; keine Zeile über 900 Zeichen, keine Steuerzeichen",
           "abgebrochen" not in T_un
           and ("  27.03.2027   126       13         26         92 %     100.000         5·5           9,8 %      51,0 %       260  Quantile") in Zu
           and any(l.startswith("  26.06.2027   217        1          2          0 %           —         0·0") and l.endswith("entfällt") for l in Zu)
           and ("  15.12.2028   756       11         22        100 %       55,20         6·5           4,4 %       0,530     2.200  Quantile") in Zu
           and any(l.startswith("  19.01.2029   791        1          2          0 %") and l.endswith("entfällt") for l in Zu)
           and "IBIT-Kurs: 49,50 USD (Feld close)" in Zu and max(len(l) for l in Zu) <= 900
           and all(c.isprintable() for l in Zu for c in l), f"längste Zeile {max(len(l) for l in Zu)} Zeichen")
        # ---- O24 Zufallsproben: nichts wirft
        import random
        rnd = random.Random(278)

        def zufall(tiefe=0):
            w = rnd.random()
            if tiefe > 3 or w < 0.25:
                return rnd.choice([None, True, 0, -1, 2.5, float("nan"), "", "IBIT281215C00055000", "BTC-27MAR27-100000-C", "x" * 50, "2026-11-20"])
            if w < 0.6:
                return {rnd.choice(["data", "options", "result", "option", "instrument_name", "bid", "ask", "bid_price", "ask_price", "iv",
                                    "timestamp", "current_price", "error", "k" + str(rnd.randrange(5))]): zufall(tiefe + 1)
                        for _ in range(rnd.randrange(0, 5))}
            return [zufall(tiefe + 1) for _ in range(rnd.randrange(0, 5))]
        fehler = []
        for i in range(400):
            o = zufall()
            try:
                deribit_lesen(o); cboe_lesen(o); struktur(o)
                roh_ = json.dumps(o).encode()
                t_ = erstlauf_text(netz({DERIBIT_URL: (roh_, None, 200), CBOE_URLS[0]: (roh_, None, 200), CBOE_URLS[1]: (roh_, None, 200)}), JETZT)
                if "abgebrochen" in t_ or "== 3. Kurz ==" not in t_:
                    fehler.append((i, "abgebrochen"))
            except Exception as e:
                fehler.append((i, f"{type(e).__name__}: {e}"))
        ok("O24 Zufallsproben: 400 zufällig gebaute Antworten (Objekte, Listen, Kennungen und Unsinn gemischt) durch das Lesen und den ganzen "
           "Bericht -- keine Ausnahme, kein „abgebrochen“, immer alle drei Teile", not fehler, f"{fehler[:2] or 'keine Auffälligkeit'}")
        ok("O25 Abruf: Bytes, Text und Fehler werden einheitlich gemeldet; ein unerwarteter Inhalt (Zahl) steht als solcher da; Größe und "
           "Dauer gemessen",
           abruf("u", lambda u, t: (b'{"a": 1}', None, 200))["obj"] == {"a": 1} and abruf("u", lambda u, t: ('{"a": 2}', None, 200))["obj"] == {"a": 2}
           and abruf("u", lambda u, t: (b'{"a": 1}', None, 200))["bytes"] == 8 and abruf("u", lambda u, t: (5, None, 200))["fehler"] == "unerwarteter Inhalt (int)"
           and abruf("u", lambda u, t: (None, None, None))["fehler"] == "keine Daten" and abruf("u", lambda u, t: (None, "x" * 500, 500))["fehler"] == "x" * 159 + "…"
           and abruf("u", lambda u, t: (b"[" * 100_000, None, 200))["obj"] is None and abruf("u", lambda u, t: (b"\xff\xfe", None, 200))["fehler"].startswith("kein JSON: ")
           and abruf_txt({"status": 200, "fehler": None, "bytes": 3_400_000, "dauer": 1.94}) == "HTTP 200 · 3,4 MB · 1,9 s"
           and abruf_txt({"status": None, "fehler": "URLError: x", "bytes": 0, "dauer": 40.04}) == "keine Antwort · URLError: x · 40,0 s"
           and abruf_txt({"status": 404, "fehler": "HTTP 404: Not Found", "bytes": 0, "dauer": 0.2}) == "HTTP 404: Not Found · 0,2 s"
           and abruf_txt({"status": 200, "fehler": "kein JSON: x", "bytes": 5, "dauer": 0.2}) == "HTTP 200 · kein JSON: x · 0,2 s", "")
        os.chdir(alt_cwd)

        # ---- K1 Vertrag mit dem Paket, K2 mit dem Konzept
        hier = os.path.dirname(os.path.abspath(__file__))
        quellen = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py", "KONZEPT_Langfrist.md", "hl_optionen.py"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as f:
                    quellen[n_] = f.read()
            except OSError:
                quellen[n_] = ""
        ok("K1 Vertrag mit dem Paket: hl_optionen.py in der Prüfsumme (version.py), in Sicherung und Wiederherstellung (update.py, mit dem "
           "Konzept), im Übersetzungs- und im Prüfschritt des Installers; Debug-Lauf „optionen_erstlauf“ im Dashboard mit --erstlauf",
           '"hl_optionen.py"' in quellen["version.py"] and '"hl_optionen.py", "KONZEPT_Langfrist.md"' in quellen["update.py"]
           and 'str(ROOT / "hl_optionen.py")' in quellen["install.py"] and '[py, str(ROOT / "hl_optionen.py"), "--selbsttest"]' in quellen["install.py"]
           and '[py, "hl_optionen.py", "--erstlauf"]' in quellen["hl_viz.py"] and '"optionen_erstlauf": (' in quellen["hl_viz.py"],
           ", ".join(n_ for n_, q_ in quellen.items() if "hl_optionen" in q_) or "in keiner Liste")
        kz = " ".join(quellen["KONZEPT_Langfrist.md"].split())
        zahlen_ok = MIN_STRIKES == 5 and MAX_SPANNE == 0.15 and TAGE_18M == 548 and VERZUG_S == 900
        if not kz:
            # Ein NEUES Dokument kommt erst mit dem übernächsten Update auf den Pi: das laufende update.py der Vorversion übernimmt nur
            # neue .py- und .json-Dateien. Im Paket (Bau, Gesamt-Selbsttest) liegt die Datei -- dort gilt der Vergleich unten.
            ok("K2 Vertrag mit dem Konzept: KONZEPT_Langfrist.md liegt hier nicht im Ordner (ein neues Dokument kommt erst mit dem "
               "übernächsten Update auf den Pi) -- geprüft nur die Zahlen der Regel im Modul", zahlen_ok, "Konzept nicht verglichen")
        else:
            ok("K2 Vertrag mit dem Konzept: Die Zahlen der Regel stehen so in KONZEPT_Langfrist.md 9.2 (fünf Strikes je Seite, 15 % Spanne, 18 "
               "Monate), der Nachtrag mit der Zählweise Z1 bis Z6 ist da und nennt 548 Tage und die Handelszeit",
               "mindestens fünf Strikes Geld- und Briefkurs haben" in kz and "höchstens 15 % des Mittelkurses" in kz
               and "mindestens ein brauchbarer Verfalltag 18 Monate oder länger läuft" in kz
               and all(f"**Z{i}**" in kz for i in range(1, 7)) and "18 Monate = 548 Tage" in kz and "9:45 bis 16:15 New York" in kz
               and "vor dem ersten Abruf" in kz and zahlen_ok, "Konzept gelesen")
        rumpf = quellen["hl_optionen.py"].split("\ndef selbsttest(", 1)[0]
        ok("K3 Der Lauf speichert nichts und fragt nur die drei festen Adressen: im Teil vor dem Selbsttest kein Öffnen von Dateien, keine "
           "Datenbank, kein Löschen; die Adressen sind Konstanten (Deribit einmal, Cboe zwei Hosts für IBIT)",
           bool(rumpf) and not any(w in rumpf for w in ("open(", "sqlite3", "os.remove", "os.unlink", ".write(", "shutil", "subprocess"))
           and DERIBIT_URL == "https://www.deribit.com/api/v2/public/get_book_summary_by_currency?currency=BTC&kind=option"
           and CBOE_URLS == ("https://cdn.cboe.com/api/global/delayed_quotes/options/IBIT.json",
                             "https://cdn-api.cboe.com/api/global/delayed_quotes/options/IBIT.json")
           and rumpf.count("http_fn(") == 1 and DEBUG_NR == 154, f"{len(rumpf)} Zeichen vor dem Selbsttest")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-700:].replace("\n", " | "))
    finally:
        os.chdir(alt_cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--erstlauf", action="store_true", help="je ein Abruf bei Deribit und Cboe, Bericht als Text (Debug 154); speichert nichts")
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz (nachgebaute Antworten)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.erstlauf:
        print(erstlauf_text())
        return
    p.print_help()


if __name__ == "__main__":
    main()
