#!/usr/bin/env python3
"""
Vollbericht: alles, was zur Fehlersuche nötig ist, in einem Text.

  python3 check_report.py                  # Standard: Datenbank aus der systemd-Einheit
  python3 check_report.py --db /pfad.db --coin BTC --minutes 10
  python3 check_report.py --selbsttest     # Proben von U168 (ohne Netz, eigene Testdatenbank)

Sammelt in einem Durchgang:
  1. Umgebung     Version der Dateien, Python, Laufzeit, Dienste
  2. Datenbank    Größe, Tabellenstände (jede Tabelle einmal gezählt), Zuwachs je Stunde, Lücken
  3. Recorder     API-Gewicht, Poller-Zustand, Aufgabenfehler, Temperaturschutz, Backup
  4. Leaderboard  Konten, Positionen, Ereignisse, Fills, Trendzeilen
  5. Wale         Anzahl je Gruppe, Flow, letzte Ereignisse
  6. Prognose     Lernstand, Trefferquoten, Ablage, letzte Prognose
  7. System       Temperatur, CPU, Speicher, Schreiblast je Laufwerk
  8. Journal      die letzten Fehlerzeilen der drei Dienste

23.68 (U168): Der Bericht brach am 14.10. nach 15 min ab, weil er jede Tabelle dreimal vollständig zählte (Zeilen,
Ausgangsstand, Kontrolle nach zwei Minuten Wartezeit) und erst am Ende druckte. Jetzt:
  - jede Tabelle genau eine Vollzählung, die größte (heatmap) zuletzt, mit Zeitbudget (8 min); was danach nicht mehr
    gezählt wird, steht als „nicht gezählt (Zeitbudget)“ da;
  - die Kontrolle zählt die Zeilen mit Zeitstempel im Rückblick von --minutes (über den Zeitindex), ohne Wartezeit;
  - jede Zeile wird sofort ausgegeben, jeder Abschnitt mit seiner Laufzeit -- ein Abbruch behält alles Fertige.

Der Text ist bewusst kompakt gehalten: Er soll sich vollständig in einen Chat einfügen
lassen. Keine Adressen im Klartext außer gekürzt, keine Schlüssel.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT: list[str] = []
_LEER = [0]                 # Leerzeilen, die erst vor der nächsten Zeile ausgegeben werden (Laufzeit gehört davor)
ZAEHL_BUDGET_S = 480.0      # U168: Zeitbudget der Vollzählung (8 min)
ZULETZT = ("heatmap",)      # U168: die größte Tabelle zuletzt (14.10.: 118 Mio. Zeilen, fast die ganze Zählzeit)
ZAEHLUNG: dict = {"stand": {}, "offen": [], "tabs": []}   # Ergebnis der einen Zählung, für alle Abschnitte
_HALT = [None]              # nur für den Selbsttest: vor diesem Abschnitt anhalten (künstlicher Abbruch)


def _aus(s: str) -> None:
    OUT.append(s)
    print(s, flush=True)


def w(line: str = "") -> None:
    """Zeile sofort ausgeben (U168): Bricht der Bericht ab, bleibt alles Fertige stehen."""
    if line == "":
        _LEER[0] += 1
        return
    while _LEER[0]:
        _LEER[0] -= 1
        _aus("")
    _aus(line)


def laufzeit(sekunden: float) -> None:
    """Laufzeit eines Abschnitts direkt unter seine letzte Zeile, vor die Leerzeile."""
    offen, _LEER[0] = _LEER[0], 0
    _aus(f"  [Laufzeit {sekunden:.1f} s]")
    _LEER[0] = max(offen, 1)


def _schluss() -> None:
    while _LEER[0]:
        _LEER[0] -= 1
        _aus("")


def _gezaehlt(t: str) -> str:
    """Zeilenzahl einer Tabelle aus der einen Zählung (U168) als Text."""
    n = ZAEHLUNG["stand"].get(t)
    if t in ZAEHLUNG["offen"]:
        return "nicht gezählt (Zeitbudget)"
    if n is None or n < 0:
        return "—"
    return f"{n:,}"


def _zuruecksetzen() -> None:
    OUT.clear()
    _LEER[0] = 0
    ZAEHLUNG.update(stand={}, offen=[], tabs=[])


def run(cmd: list[str], timeout: int = 20) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()
    except Exception as e:
        return f"({type(e).__name__}: {e})"


def unit_arg(flag: str, unit: str = "hl-recorder") -> str | None:
    try:
        m = re.search(rf"{flag}\s+(\S+)", Path(f"/etc/systemd/system/{unit}.service").read_text())
        return m.group(1) if m else None
    except OSError:
        return None


def db_path() -> str:
    return unit_arg("--db") or str(ROOT / "hl_liq.db")


def ago(ts) -> str:
    if not ts:
        return "—"
    d = time.time() - float(ts)
    return f"{d/60:.0f} min" if d < 7200 else f"{d/3600:.1f} h" if d < 172800 else f"{d/86400:.1f} T"


def fmt(n) -> str:
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "—"
    for grenze, einheit in ((1e9, "Mrd"), (1e6, "Mio"), (1e3, "k")):
        if abs(n) >= grenze:
            return f"{n/grenze:,.1f} {einheit}"
    return f"{n:,.0f}"


def short(a: str) -> str:
    return f"{a[:6]}…{a[-4:]}" if isinstance(a, str) and len(a) > 12 else str(a)


# ---------------------------------------------------------------------------

def teil1_umgebung() -> None:
    w("=" * 70)
    w(" 1. UMGEBUNG")
    w("=" * 70)
    w(f"Bericht {time.strftime('%d.%m.%Y %H:%M:%S')} · Python {sys.version.split()[0]} · Ordner {ROOT}")
    files = sorted(p for p in ROOT.glob("*.py"))
    zeilen = []
    for p in files:
        try:
            zeilen.append(f"{p.name} {p.stat().st_size//1024}k {time.strftime('%d.%m. %H:%M', time.localtime(p.stat().st_mtime))}")
        except OSError:
            pass
    w("Dateien: " + " · ".join(zeilen))
    log = ROOT / "updates" / "last_update.log"
    if log.exists():
        txt = log.read_text(errors="replace").strip().splitlines()
        w(f"Letztes Update: {time.strftime('%d.%m. %H:%M', time.localtime(log.stat().st_mtime))} · "
          f"{'erfolgreich' if any('Fertig' in l for l in txt) else 'ABGEBROCHEN?'} · {len(txt)} Zeilen")
        fehler = [l.strip() for l in txt if "FEHLER" in l or "Traceback" in l]
        if fehler:
            w("  Fehler im Update: " + " | ".join(fehler[:3])[:300])
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        st = run(["systemctl", "is-active", s], 5) or "?"
        if "not been booted" in st or "Failed to connect" in st:
            w("Dienste: systemd nicht verfügbar (Testumgebung)")
            break
        since = run(["systemctl", "show", s, "--property=ActiveEnterTimestamp", "--value"], 5)
        mem = run(["systemctl", "show", s, "--property=MemoryCurrent", "--value"], 5)
        restarts = run(["systemctl", "show", s, "--property=NRestarts", "--value"], 5)
        try:
            mem = f"{int(mem)/1e6:.0f} MB"
        except ValueError:
            mem = "—"
        w(f"Dienst {s:<14} {st:<10} seit {since[:25] or '—'} · Speicher {mem} · Neustarts {restarts or '—'}")
    w()


def _abfrage_mit_frist(con, sql: str, frist_s: float):
    """
    Eine Abfrage mit harter Frist: ein Zeitgeber unterbricht sie (sqlite3_interrupt), auch mitten in der Zählung einer
    großen Tabelle -- der Fortschrittsrückruf von SQLite greift dort nicht, weil COUNT(*) ein einziger Befehl ist
    (geprüft 16.10.). Hat der Zeitgeber ausgelöst, gilt der Wert als nicht ermittelt, auch wenn SQLite eine Zahl
    liefert: sie könnte unvollständig sein. None = nicht in der Frist.
    """
    if frist_s <= 0:
        return None
    gefeuert = threading.Event()

    def stopp():
        gefeuert.set()
        con.interrupt()

    zeit = threading.Timer(frist_s, stopp)
    zeit.daemon = True
    zeit.start()
    try:
        wert = con.execute(sql).fetchone()[0]
    except sqlite3.OperationalError as e:
        if gefeuert.is_set() or "interrupt" in str(e).lower():
            return None
        raise
    finally:
        zeit.cancel()
    return None if gefeuert.is_set() else wert


def zaehl_reihenfolge(tabs: list[str]) -> list[str]:
    """Alle Tabellen in Namensfolge, die größte zuletzt: reicht das Budget nicht, fehlt nur sie."""
    return [t for t in tabs if t not in ZULETZT] + [t for t in ZULETZT if t in tabs]


def zaehlen(con, tabs: list[str], budget_s: float, uhr=time.monotonic):
    """
    U168: jede Tabelle genau einmal vollständig zählen, mit Zeitbudget. Liefert je Tabelle (name, zahl): zahl None =
    nicht gezählt (Zeitbudget), -1 = nicht lesbar. Diese Zählung ist zugleich der Stand für alle übrigen Abschnitte.
    """
    t0 = uhr()
    for t in zaehl_reihenfolge(tabs):
        rest = budget_s - (uhr() - t0)
        if rest <= 0:
            yield t, None
            continue
        try:
            yield t, _abfrage_mit_frist(con, f'SELECT COUNT(*) FROM "{t}"', rest)
        except sqlite3.Error:
            yield t, -1


def teil2_datenbank(db: str, budget_s: float = ZAEHL_BUDGET_S, uhr=time.monotonic) -> sqlite3.Connection | None:
    w("=" * 70)
    w(" 2. DATENBANK")
    w("=" * 70)
    if not os.path.exists(db):
        w(f"FEHLT: {db}")
        w()
        return None
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)
    con.row_factory = sqlite3.Row
    wal = db + "-wal"
    w(f"{db} · {os.path.getsize(db)/1e9:.2f} GB · WAL {os.path.getsize(wal)/1e6:.1f} MB"
      if os.path.exists(wal) else f"{db} · {os.path.getsize(db)/1e9:.2f} GB")
    try:
        u = shutil.disk_usage(os.path.dirname(os.path.abspath(db)))
        w(f"Medium: {u.free/1e9:.1f} GB frei von {u.total/1e9:.0f} GB")
    except OSError:
        pass
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    ZAEHLUNG["tabs"] = tabs
    stand, offen = ZAEHLUNG["stand"], ZAEHLUNG["offen"]
    t_z = time.monotonic()
    # jüngster Eintrag je Strom; jede Zeile sofort, sobald ihre Tabelle gezählt ist
    w(f"{'Tabelle':<18} {'Zeilen':>12}  letzter Eintrag")
    for t, n in zaehlen(con, tabs, budget_s, uhr):
        letzte = "—"
        try:
            cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
            if "ts" in cols:
                ts = con.execute(f'SELECT MAX(ts) FROM "{t}"').fetchone()[0]
                if ts:
                    ts = ts / 1000 if ts > 1e11 else ts
                    letzte = f"vor {ago(ts)}"
        except sqlite3.Error:
            pass
        if n is None:
            offen.append(t)
            w(f"{t:<18} {'nicht gezählt (Zeitbudget)':>12}  {letzte}")
            continue
        stand[t] = n
        if n or letzte != "—":
            w(f"{t:<18} {n:>12,}  {letzte}")
    w(f"Zählung: {len(stand)} von {len(tabs)} Tabellen in {time.monotonic() - t_z:.1f} s, jede einmal"
      + (f" · {len(offen)} nicht gezählt (Zeitbudget {budget_s/60:g} min): {', '.join(offen)}" if offen else ""))
    return con


def teil2b_zuwachs(con, minutes: float) -> None:
    """
    Zuwachs je Stunde -- gezählt über die Zeitstempel der letzten Stunde, nicht hochgerechnet
    aus einem Zweiminutenfenster. Schreibt ein Strom in Schüben (Snapshots alle 15 min), traf
    das kurze Fenster entweder einen Schub oder keinen: einmal 0/h, einmal 353.000/h für
    dieselbe Tabelle. Die Zählung über Zeitstempel ist unabhängig vom Messzeitpunkt.

    23.68 (U168): Die Kontrolle zählt die Zeilen mit Zeitstempel im Rückblick von --minutes über den Zeitindex.
    Bisher zählte sie nach einer Wartezeit von --minutes alle Tabellen ein drittes Mal vollständig.
    """
    now = int(time.time())
    w("Zuwachs je Stunde (aus den Zeitstempeln der letzten 1 h / 6 h):")
    zeilen, kontrolle = [], []
    fenster = max(float(minutes), 0.0) * 60
    for t in sorted(ZAEHLUNG["tabs"]):
        try:
            cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
            if "ts" not in cols:
                continue
            probe = con.execute(f'SELECT MAX(ts) FROM "{t}"').fetchone()[0]
            if not probe:
                continue
            teiler = 1000 if probe > 1e11 else 1        # 1e11 trennt Sekunden (max 5138) von Millisekunden sicher
            h1 = con.execute(f'SELECT COUNT(*) FROM "{t}" WHERE ts > ?', ((now - 3600) * teiler,)).fetchone()[0]
            h6 = con.execute(f'SELECT COUNT(*) FROM "{t}" WHERE ts > ?', ((now - 6 * 3600) * teiler,)).fetchone()[0]
            if h6:
                zeilen.append((h1, t, h6 / 6))
            k = con.execute(f'SELECT COUNT(*) FROM "{t}" WHERE ts > ?', ((now - fenster) * teiler,)).fetchone()[0]
            if k:
                kontrolle.append((k, t))
        except sqlite3.Error:
            continue
    zeilen.sort(reverse=True)
    for h1, t, h6 in zeilen[:14]:
        hinweis = ""
        if h1 == 0 and h6 > 0:
            hinweis = "  ← in der letzten Stunde nichts"
        elif h6 > 0 and h1 > 3 * h6:
            hinweis = "  ← Schub"
        w(f"  {t:<18} {h1:>9,}/h   (6-h-Mittel {h6:>9,.0f}/h){hinweis}")
    kontrolle.sort(reverse=True)
    w(f"  Kontrolle (Zeilen mit Zeitstempel in den letzten {fenster:.0f} s): "
      + (", ".join(f"{t} +{d}" for d, t in kontrolle[:8]) if kontrolle else "keine Tabelle mit neuen Zeilen"))
    w()


def teil2c_luecken(con) -> None:
    """
    Aufzeichnungslücken der letzten 24 h. Ein stiller Ausfall zeigt sich nicht an der Zeilenzahl,
    sondern an der größten Lücke zwischen zwei Einträgen -- so blieb ein Leaderboard-Ausfall
    30 Stunden unbemerkt, obwohl die Tabelle weiter Zeilen hatte.
    """
    now = int(time.time())
    erwartet = {"bars": 5, "ctx_bars": 5, "bars10": 20, "book_summary": 5, "heatmap": 30,
                "lb_accounts": 20, "lb_trend": 130, "trigger_orders": 30, "proximity": 10}
    w("Größte Lücke in den letzten 24 h (Minuten):")
    zeilen = []
    for t, grenze in erwartet.items():
        try:
            rows = [r[0] for r in con.execute(f'SELECT DISTINCT ts FROM "{t}" WHERE ts > ? ORDER BY ts', (now - 86_400,))]
        except sqlite3.Error:
            continue
        if len(rows) < 3:
            zeilen.append((9999, t, grenze, len(rows)))
            continue
        luecke = max((b - a) / 60 for a, b in zip(rows[:-1], rows[1:]))
        luecke = max(luecke, (now - rows[-1]) / 60)
        zeilen.append((luecke, t, grenze, len(rows)))
    zeilen.sort(reverse=True)
    for luecke, t, grenze, n in zeilen:
        if luecke >= 9999:
            w(f"  {t:<18} zu wenige Einträge ({n}) für eine Aussage")
        else:
            w(f"  {t:<18} {luecke:>6.0f} min   (erwartet unter {grenze} min){'  ← AUFFÄLLIG' if luecke > grenze else ''}")
    w()


def teil3_recorder(con) -> None:
    w("=" * 70)
    w(" 3. RECORDER")
    w("=" * 70)
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
    except sqlite3.Error:
        w("meta nicht lesbar")
        w()
        return
    alive = int(meta.get("recorder_alive") or 0)
    w(f"Lebenszeichen: {'vor ' + ago(alive) if alive else 'FEHLT (alte Version oder Recorder aus)'}"
      f" · Start {meta.get('started', '—')}")
    used, budget = int(meta.get("api_weight_1m") or 0), int(meta.get("api_weight_budget") or 1200)
    w(f"API-Gewicht: {used}/{budget} ({used/max(budget,1)*100:.0f} %) · Stand vor {ago(meta.get('api_weight_ts'))}"
      f" · 429er: {meta.get('rate_limited', 0)}")
    try:
        split = json.loads(meta.get("weight_split") or "{}")
    except ValueError:
        split = {}
    if split:
        ges = sum(split.values()) or 1
        w("  Gewicht je Verbraucher (letzte Minute): "
          + " · ".join(f"{k} {v} ({v/ges*100:.0f} %)" for k, v in sorted(split.items(), key=lambda x: -x[1])))
    pb, pw = int(meta.get("poller_batch") or 0), int(meta.get("poller_want") or 0)
    w(f"Poller: {pb}/{pw} je Runde {'(voll)' if pw and pb >= pw else '(NICHT VOLL — zu wenige fällige Adressen)' if pw else ''}"
      f" · fällig: {meta.get('poller_due_a','?')} mit Position, {meta.get('poller_due_b','?')} neu, {meta.get('poller_due_c','?')} leer"
      f" · {int(meta.get('addr_total') or 0):,} Adressen")
    lvl = int(meta.get("thermal_level") or 0)
    w(f"Temperaturschutz: {'Stufe ' + str(lvl) if lvl else 'inaktiv'} · {meta.get('thermal_temp','—')} °C"
      f" · Gewicht x{meta.get('thermal_weight_factor','1')} · Takte x{meta.get('thermal_interval_factor','1')}")
    try:
        te = json.loads(meta.get("task_errors") or "{}")
    except ValueError:
        te = {}
    if te:
        w("AUFGABEN-ABSTÜRZE:")
        for k, v in te.items():
            w(f"  {k}: {v.get('count')}x · zuletzt vor {ago(v.get('ts'))} · {str(v.get('error'))[:150]}")
    else:
        w("Aufgaben: keine Abstürze vermerkt")
    bdir = meta.get("backup_dir") or str(ROOT / "dbbackup")
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            b = json.load(f)
        w(f"Backup: {'ok' if b.get('ok') else 'FEHLGESCHLAGEN: ' + str(b.get('error'))[:80]}"
          f" · vor {ago(b.get('ts'))} · {fmt(b.get('size'))} B · Ordner {bdir}")
    except (OSError, ValueError):
        w(f"Backup: keine backup.json in {bdir}")
    w()


def teil4_leaderboard(con, coin: str) -> None:
    now = int(time.time())
    w("=" * 70)
    w(f" 4. LEADERBOARD ({coin})")
    w("=" * 70)
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.Error:
        w("Tabellen fehlen — Recorder-Version zu alt?")
        w()
        return
    if not last:
        w("noch kein Durchgang")
        w()
        return
    n_acc = con.execute("SELECT COUNT(*) FROM lb_accounts WHERE ts=?", (last,)).fetchone()[0]
    n_pos = con.execute("SELECT COUNT(*) FROM lb_positions WHERE ts=?", (last,)).fetchone()[0]
    n_cyc = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_accounts").fetchone()[0]
    w(f"Letzter Durchgang vor {ago(last)} · {n_acc} Konten · {n_pos} Positionen · {n_cyc} Durchgänge gesamt")
    luecke = con.execute("SELECT COUNT(*) FROM lb_trend WHERE coin=? AND top_n=20", (coin,)).fetchone()[0]
    letzte_trend = con.execute("SELECT MAX(ts) FROM lb_trend WHERE coin=?", (coin,)).fetchone()[0]
    w(f"Trendzeilen {coin}: {luecke} · letzte vor {ago(letzte_trend)}")
    for tab, label in (("lb_events", "Ereignisse"), ("lb_fills", "Fills"), ("lb_spot", "Spot-Bestände")):
        try:
            if tab not in ZAEHLUNG["tabs"]:
                raise sqlite3.OperationalError(f"no such table: {tab}")
            n = _gezaehlt(tab)                     # U168: Stand aus der einen Zählung in Abschnitt 2
            letzte = con.execute(f"SELECT MAX(ts) FROM {tab}").fetchone()[0]
            extra = ""
            if tab == "lb_events":
                h1 = con.execute("SELECT COUNT(*) FROM lb_events WHERE coin=? AND ts>=?", (coin, int(time.time()) - 3600)).fetchone()[0]
                extra = f" · letzte Stunde in {coin}: {h1}"
            w(f"{label}: {n} · letzter vor {ago(letzte)}{extra}")
        except sqlite3.Error:
            w(f"{label}: Tabelle fehlt")
    # Fills je Coin: Kommen für DIESEN Coin überhaupt Daten an? Eine leere Tabelle sagt nichts,
    # solange andere Coins gefüllt werden -- erst der Vergleich trennt "ruhig" von "fehlt".
    try:
        gesamt = con.execute("SELECT COUNT(*), MAX(ts) FROM lb_fills WHERE ts > ?", (now - 86_400,)).fetchone()
        w(f"Fills letzte 24 h: {gesamt[0]:,} · jüngster vor {ago(gesamt[1])}")
        top = con.execute("""SELECT coin, COUNT(*) n, MAX(ts) letzte FROM lb_fills WHERE ts > ?
                             GROUP BY coin ORDER BY n DESC LIMIT 8""", (now - 86_400,)).fetchall()
        if top:
            w("  je Coin (24 h): " + " · ".join(f"{r['coin']} {r['n']:,} (vor {ago(r['letzte'])})" for r in top))
        eigen = con.execute("""SELECT COUNT(*) n, MAX(ts) letzte, COUNT(DISTINCT addr) k FROM lb_fills
                               WHERE coin=? AND ts > ?""", (coin, now - 86_400)).fetchone()
        w(f"  {coin} in 24 h: {eigen['n']:,} Fills von {eigen['k']} Konten"
          + (f" · jüngster vor {ago(eigen['letzte'])}" if eigen["letzte"] else " · KEINER"))
        tage = con.execute("""SELECT strftime('%d.%m', ts, 'unixepoch', 'localtime') tag, COUNT(*) n,
                                     ROUND(SUM(notional)/1e6, 1) usd
                              FROM lb_fills WHERE coin=? AND ts > ? GROUP BY tag ORDER BY MIN(ts)""",
                           (coin, now - 5 * 86_400)).fetchall()
        if tage:
            w(f"  {coin} je Tag: " + " · ".join(f"{r['tag']}: {r['n']:,} Fills, {r['usd']} Mio" for r in tage))
            fehlend = [r["tag"] for r in tage if r["n"] == 0]
            if len(tage) < 4:
                w(f"  ← nur {len(tage)} Tage mit {coin}-Fills in 5 Tagen: prüfen, ob Tage fehlen")
    except sqlite3.Error as e:
        w(f"Fills je Coin nicht lesbar: {e}")

    # Übersprungene Zeiträume
    try:
        gaps = con.execute("SELECT addr, von, bis FROM lb_gaps ORDER BY erkannt DESC LIMIT 5").fetchall()
        n_gaps = ZAEHLUNG["stand"].get("lb_gaps")      # U168: aus der einen Zählung; None/-1 = nicht gezählt
        gezaehlt = n_gaps is not None and n_gaps >= 0
        if (n_gaps if gezaehlt else len(gaps)):
            w(f"ÜBERSPRUNGENE ZEITRÄUME: {n_gaps if gezaehlt else f'mindestens {len(gaps)} (nicht gezählt)'} Konten"
              " — ihre Fills fehlen dort dauerhaft:")
            for g in gaps:
                if not g['von'] or g['von'] < 1_000_000_000:        # 23.14 (U39): Altzeilen mit Beginn 0 (vor der Korrektur)
                    w(f"  {short(g['addr'])}: Beginn unbekannt (Altzeile vor 23.14) bis {time.strftime('%d.%m %H:%M', time.localtime(g['bis']))}")
                    continue
                w(f"  {short(g['addr'])}: {time.strftime('%d.%m %H:%M', time.localtime(g['von']))}"
                  f" bis {time.strftime('%d.%m %H:%M', time.localtime(g['bis']))}"
                  f" ({(g['bis']-g['von'])/3600:.1f} h)")
        else:
            w("Übersprungene Zeiträume: keine")
    except sqlite3.Error:
        w("Übersprungene Zeiträume: Tabelle lb_gaps fehlt (Recorder-Version zu alt)")

    try:
        rows = con.execute("SELECT addr, ts FROM lb_cursor").fetchall()
        if rows:
            jetzt = time.time()
            try:
                ausw = {str(r[0]).lower() for r in con.execute("SELECT addr FROM lb_accounts WHERE ts=(SELECT MAX(ts) FROM lb_accounts)")}
            except sqlite3.Error:
                ausw = set()
            try:
                defer = int(dict(con.execute("SELECT k, v FROM meta")).get("lb_fills_deferred") or 0)
            except sqlite3.Error:
                defer = 0
            # 23.14: Auswahl (Takt 15 min) und Pool (Takt 12 h, U5) getrennt -- gemischt meldete der Bericht „Median 7,9 h,
            # AUFHOLEN LÄUFT“, obwohl die Pool-Konten planmäßig nur alle 12 h nachgetragen werden.
            for name, teil, grenze_h in (("Auswahl (Takt 15 min)", [r for r in rows if str(r[0]).lower() in ausw], 1.0),
                                         ("Pool/übrige (Takt 12 h)", [r for r in rows if str(r[0]).lower() not in ausw], 13.0)):
                if not teil:
                    continue
                rueck = sorted(min((jetzt - (r[1] or 0)) / 3600, 9999) for r in teil)
                hinten = sum(1 for x in rueck if x > grenze_h)
                w(f"Fill-Abholstand {name}: {len(teil)} Konten · Median {rueck[len(rueck) // 2]:.1f} h zurück · schlechtestes {rueck[-1]:.1f} h · "
                  f"{hinten} über {grenze_h:.0f} h" + (f" · {sum(1 for x in rueck if x > 100)} ohne gültigen Stand" if any(x > 100 for x in rueck) else "")
                  + ("  ← AUFHOLEN LÄUFT" if hinten else ""))
            if defer:
                w(f"  {defer} Konten wegen Gewichtsbudget zurückgestellt")
        else:
            w("Fill-Abholstand: keine lb_cursor-Einträge (Recorder-Version zu alt oder erster Lauf steht aus)")
    except sqlite3.Error:
        w("Fill-Abholstand: Tabelle lb_cursor fehlt")
    try:
        rows = con.execute("""SELECT event, side, COUNT(*) n, ROUND(SUM(delta_usd)) s FROM lb_events
                              WHERE coin=? AND ts>=? GROUP BY event, side""", (coin, int(time.time()) - 6 * 3600)).fetchall()
        if rows:
            w("Ereignisse 6 h: " + " · ".join(f"{r['event']} {r['side']} {r['n']}x {fmt(r['s'])}" for r in rows))
    except sqlite3.Error:
        pass
    w()


def teil5_wale(con, coin: str) -> None:
    w("=" * 70)
    w(f" 5. WALE ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_viz
        d = hl_viz.load_whales(con, coin, 72)
    except Exception as e:
        w(f"load_whales fehlgeschlagen: {type(e).__name__}: {e}")
        w()
        return
    F = d.get("flow") or {}
    w(f"Konten je Gruppe: {F.get('sizes')} · erfasst {F.get('n_total')} · direktional {F.get('n_directional')}")
    for g, name in (F.get("group_names") or {}).items():
        gf = (F.get("groups") or {}).get(g)
        if not gf:
            continue
        a30, a60 = gf["w30"], gf["w60"]
        w(f"  {name:<14} 30 min netto {fmt(a30['net_usd']):>10} ({a30['n_buy']}/{a30['n_sell']})"
          f" · 60 min {fmt(a60['net_usd']):>10} ({a60['n_buy']}/{a60['n_sell']})"
          f" · Z30 {'—' if gf.get('z30') is None else round(gf['z30'], 1)}"
          f"{' · EREIGNIS' if gf.get('event_signal') else ''}")
    D = d.get("directional") or {}
    if D:
        w(f"Bestand direktional: {D.get('n_long')} long {fmt(D.get('usd_long'))} gegen {D.get('n_short')} short {fmt(D.get('usd_short'))}")
    ev = list(reversed((d.get("events") or [])[-8:]))       # die NEUESTEN acht, neueste zuerst
    if ev:
        w("Letzte Änderungen:")
        for e in ev:
            grp = (F.get("per_coin") or {}).get(str(e.get("addr", "")).lower(), "?")
            w(f"  {time.strftime('%d.%m %H:%M', time.localtime(e['ts']))} {short(e['addr'])} {e['event']} {e['side']}"
              f" {fmt(e.get('delta_usd'))} [{grp}]")
    w()


def teil5b_aktivitaet(con, coin: str) -> None:
    """
    Ist der Markt ruhig oder die Aufzeichnung kaputt? Die Frage lässt sich nur beantworten,
    indem man die letzte Stunde gegen den eigenen Normalwert stellt -- absolute Zahlen sagen
    nichts. Verglichen werden Volumen, Trades, Spanne, Wal-Ereignisse und Liquidationen.
    """
    now = int(time.time())
    w("=" * 70)
    w(f" 5b. MARKTAKTIVITÄT ({coin}) — letzte Stunde gegen den Schnitt")
    w("=" * 70)

    def vergleich(label: str, h1: float, schnitt: float, einheit: str = "") -> None:
        if schnitt <= 0:
            w(f"  {label:<26} {h1:>12,.0f}{einheit}   (kein Vergleichswert)")
            return
        q = h1 / schnitt
        deutung = ("sehr ruhig" if q < 0.4 else "ruhig" if q < 0.75 else
                   "normal" if q < 1.5 else "lebhaft" if q < 3 else "sehr lebhaft")
        w(f"  {label:<26} {h1:>12,.0f}{einheit}   Schnitt {schnitt:>12,.0f}{einheit}   {q*100:>5.0f} %  {deutung}")

    try:
        r = con.execute("""SELECT SUM(volume*close) v, SUM(trades) n, MAX(high) h, MIN(low) l, MAX(close) c
                           FROM bars WHERE coin=? AND ts>?""", (coin, now - 3600)).fetchone()
        r7 = con.execute("""SELECT SUM(volume*close)/168.0 v, SUM(trades)/168.0 n
                            FROM bars WHERE coin=? AND ts>?""", (coin, now - 7 * 86_400)).fetchone()
        vergleich("Volumen 1 h (USD)", r["v"] or 0, r7["v"] or 0)
        vergleich("Trades 1 h", r["n"] or 0, r7["n"] or 0)
        if r["h"] and r["l"] and r["c"]:
            spanne = (r["h"] - r["l"]) / r["c"] * 100
            r7b = con.execute("""SELECT AVG(s) FROM (SELECT (MAX(high)-MIN(low))/MAX(close)*100 s FROM bars
                                 WHERE coin=? AND ts>? GROUP BY ts/3600)""", (coin, now - 7 * 86_400)).fetchone()[0] or 0
            vergleich("Spanne 1 h (%)", spanne, r7b, " %")
    except sqlite3.Error as e:
        w(f"  Kurs/Volumen nicht lesbar: {e}")

    # Wal-Ereignisse: echte Änderungen gegen Snapshots trennen
    try:
        ev1 = {r[0]: r[1] for r in con.execute(
            "SELECT event, COUNT(*) FROM whale_positions WHERE ts>? GROUP BY event", (now - 3600,))}
        ev24 = {r[0]: r[1] for r in con.execute(
            "SELECT event, COUNT(*) FROM whale_positions WHERE ts>? GROUP BY event", (now - 86_400,))}
        echt1 = sum(v for k, v in ev1.items() if k != "snap")
        echt24 = sum(v for k, v in ev24.items() if k != "snap") / 24
        vergleich("Wal-Ereignisse 1 h (alle)", echt1, echt24)
        c1 = con.execute("SELECT COUNT(*) FROM whale_positions WHERE coin=? AND ts>? AND event!='snap'",
                         (coin, now - 3600)).fetchone()[0]
        c24 = con.execute("SELECT COUNT(*) FROM whale_positions WHERE coin=? AND ts>? AND event!='snap'",
                          (coin, now - 86_400)).fetchone()[0] / 24
        vergleich(f"Wal-Ereignisse 1 h ({coin})", c1, c24)
        w(f"  davon Snapshots 1 h: {ev1.get('snap', 0):,} (zählen nicht als Handel, erklären aber den Zeilenzuwachs)")
        arten = " · ".join(f"{k} {v}" for k, v in sorted(ev1.items()) if k != "snap")
        w(f"  Arten letzte Stunde: {arten or 'keine'}")
    except sqlite3.Error as e:
        w(f"  Wal-Ereignisse nicht lesbar: {e}")

    try:
        l1 = con.execute("SELECT COUNT(*) FROM lb_events WHERE ts>?", (now - 3600,)).fetchone()[0]
        l24 = con.execute("SELECT COUNT(*) FROM lb_events WHERE ts>?", (now - 86_400,)).fetchone()[0] / 24
        vergleich("Leaderboard-Ereignisse 1 h", l1, l24)
    except sqlite3.Error:
        pass
    try:
        q1 = con.execute("SELECT COUNT(*) FROM liquidations WHERE ts>?", (now - 3600,)).fetchone()[0]
        q24 = con.execute("SELECT COUNT(*) FROM liquidations WHERE ts>?", (now - 86_400,)).fetchone()[0] / 24
        vergleich("Liquidationen 1 h", q1, q24)
        # 23.12 -- Probe P2 (Audit v10 K1, Plan U1): beobachtete (userEvents) gegen abgeleitete Liquidationen, 24 h
        rows_m = con.execute("SELECT method, COUNT(*), COUNT(DISTINCT user) FROM liquidations WHERE ts > ? GROUP BY method ORDER BY 2 DESC",
                             (now - 86_400,)).fetchall()
        w("  Liquidationen 24 h nach Methode (Probe P2): " + (" · ".join(f"{m_ or '-'} {n_} Zeilen/{u_} Konten" for m_, n_, u_ in rows_m) or "keine"))
        beob = con.execute("SELECT COUNT(DISTINCT user) FROM liquidations WHERE ts > ? AND method != 'inferred'", (now - 86_400,)).fetchone()[0]
        abg = sum(n_ for m_, n_, _ in rows_m if m_ == "inferred")
        w(f"    Soll: beobachtete Konten <= 10 (HL-Limit je IP) -> {beob} {'ok' if beob <= 10 else 'ZU VIELE'} · "
          f"abgeleitete Zeilen > 0 -> {abg} {'ok' if abg > 0 else '(keine: ruhiger Tag oder Ableitung aus?)'}")
    except sqlite3.Error:
        pass
    w("  Lesehilfe: stehen Volumen und Trades bei 'normal' und die Ereignisse bei 'sehr ruhig',")
    w("  handelt niemand -- die Aufzeichnung ist in Ordnung. Stehen BEIDE bei null, ist sie es nicht.")
    w()


def teil5c_coinbase(con, coin: str) -> None:
    """Coinbase-Spot: läuft der Dienst, und was sagen Prämie, Flow und Buch?"""
    now = int(time.time())
    w("=" * 70)
    w(f" 5c. COINBASE-SPOT ({coin})")
    w("=" * 70)
    try:
        meta = dict(con.execute("SELECT k, v FROM cb_meta"))
    except sqlite3.Error:
        w("Dienst nicht eingerichtet (Tabelle cb_meta fehlt) — python3 install.py --enable")
        w()
        return
    alive = int(meta.get("alive") or 0)
    w(f"Lebenszeichen: {'vor ' + ago(alive) if alive else 'FEHLT'} · Paare: {meta.get('products', '—')}")
    w(f"Zähler: {meta.get('stats', '—')}")
    for tab, label, erwartet in (("cb_bars", "Minutenkerzen", 5), ("cb_book", "Buch-Stände", 10)):
        try:
            n, letzte = con.execute(f"SELECT COUNT(*), MAX(ts) FROM {tab} WHERE coin=?", (coin,)).fetchone()
            alt = (now - letzte) / 60 if letzte else None
            w(f"{label}: {n:,} · letzter vor {ago(letzte)}"
              + ("  ← VERALTET" if alt is not None and alt > erwartet else ""))
        except sqlite3.Error:
            w(f"{label}: Tabelle fehlt")
    try:
        sys.path.insert(0, str(ROOT))
        import hl_viz
        perp = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        d = hl_viz.load_coinbase(con, coin, perp[0] if perp else None)
        if not d.get("aktiv"):
            w(f"Auswertung: keine frischen Daten{' (' + str(d.get('alter_min')) + ' min alt)' if d.get('alter_min') is not None else ''}")
        else:
            if d.get("premium_bps") is not None:
                w(f"Prämie: {d['premium_bps']:+.1f} bps"
                  + (f" · Mittel {d['premium_mittel']:+.1f} · Z {d['premium_z']:+.2f} ({d['premium_n']:,} Minuten)"
                     if d.get("premium_z") is not None else " · noch keine Vergleichsreihe"))
            f60 = d.get("flow60") or {}
            w(f"Taker-Flow 60 min: {fmt(f60.get('buy_usd'))} gekauft gegen {fmt(f60.get('sell_usd'))} verkauft"
              f" · netto {fmt(f60.get('net_usd'))}" + (f" · Z {d['flow_z']:+.2f}" if d.get("flow_z") is not None else ""))
            if d.get("vol_rel"):
                w(f"Volumen 1 h: {fmt(d['vol_1h'])} gegen Schnitt {fmt(d['vol_schnitt'])} = {d['vol_rel']:.2f}x")
            b = d.get("book") or {}
            if b:
                w(f"Buch: Spread {b['spread_bps']:.2f} bps · ±25 bps {fmt(b['bid25'])} Gebot gegen {fmt(b['ask25'])} Angebot"
                  f" ({b['imbalance']*100:+.0f} %) · {len(d.get('walls') or [])} Wände")
    except Exception as e:
        w(f"Auswertung fehlgeschlagen: {type(e).__name__}: {e}")
    w()


def teil6_prognose(con, coin: str) -> None:
    w("=" * 70)
    w(f" 6. PROGNOSE UND LERNSTAND ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_forecast
    except Exception as e:
        w(f"hl_forecast nicht ladbar: {e}")
        w()
        return
    store = hl_forecast.STORE
    w(f"Ablage: {store} ({os.path.getsize(store)/1e6:.1f} MB)" if os.path.exists(store) else f"Ablage: {store} (fehlt)")
    try:
        st = hl_forecast.store_connect(store)
        st.row_factory = sqlite3.Row
        n = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        fen = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        letzte = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        row = st.execute("SELECT ts, price, bias, confidence, p_24h, buy_px, sell_px, wver FROM forecast WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        gew = st.execute("SELECT name, prior, weight, n, hit_rate FROM weights WHERE coin=? ORDER BY ABS(weight-prior) DESC", (coin,)).fetchall()
        lern = st.execute("SELECT key, updated FROM learned WHERE coin=?", (coin,)).fetchall()
        st.close()
    except sqlite3.Error as e:
        w(f"forecasts.db nicht lesbar: {e}")
        w()
        return
    w(f"Prognosen: {n:,} · {fen} Fenster à 15 min · letzte vor {ago(letzte)}")
    if row:
        f0 = lambda v: "—" if v is None else f"{v:,.0f}"
        w(f"Letzte: Kurs {f0(row['price'])} · Bias {row['bias'] if row['bias'] is None else format(row['bias'], '+.2f')} · Konfidenz "
          f"{'—' if row['confidence'] is None else format(row['confidence'], '.0%')}"
          f" · 24 h {f0(row['p_24h'])} · Kauf {f0(row['buy_px'])} · Verkauf {f0(row['sell_px'])}")
    sc = hl_forecast.score_forecasts(con, coin, store)
    def quote(v):
        return "—" if v is None else f"{v*100:.0f} %"
    def block(q):
        if not q or not q.get("n"):
            return "—"
        ci = f" ({q['ci'][0]*100:.0f}–{q['ci'][1]*100:.0f})" if q.get("ci") else ""
        bs = f" · Brier-Skill {q['brier_skill']*100:+.1f} %" if q.get("brier_skill") is not None else ""
        return f"{quote(q['hit_rate'])}{ci} · Basis {quote(q.get('base'))} · n_eff {q.get('n_eff')} ({q['n']} Fenster, {q.get('offen', 0)} offen){bs}"
    w(f"Trefferquote 4 h:  {block(sc.get('q4'))}")
    w(f"Trefferquote 24 h: {block(sc.get('q24'))}")
    w("  (Klammer = Wilson-Intervall auf n_eff, der Zahl unabhängiger Fälle; Basis = 'immer aufwärts/abwärts' in denselben Fenstern)")
    w(f"  Modell {quote((sc.get('model') or {}).get('hit_rate'))} (n={(sc.get('model') or {}).get('n')})"
      f" · Analog {quote((sc.get('analog') or {}).get('hit_rate'))} (n={(sc.get('analog') or {}).get('n')})"
      f" · out-of-sample {quote((sc.get('oos') or {}).get('hit_rate'))} (n={(sc.get('oos') or {}).get('n')})"
      f" · mittlerer Fehler 24 h {'—' if sc.get('mae_pct') is None else format(sc['mae_pct'], '.2f') + ' %'}")
    if gew:
        gelernt = [g for g in gew if abs((g["weight"] or 0) - (g["prior"] or 0)) > 0.02]
        w(f"Gewichte: {len(gelernt)} von {len(gew)} gelernt")
        for g in gew[:8]:
            w(f"  {g['name']:<28} {g['weight']:.2f} (Prior {g['prior']:.1f}) · n={g['n']}"
              f" · Treffer {quote(g['hit_rate'])}")
        for h in hl_forecast.LERN_HORIZONTE:
            m = hl_forecast.learned_cal_meta(coin, store, h)
            if m:
                w(f"  Spur {h} h: n_eff {m.get('n_eff')} ({m.get('n')} Fenster) · "
                  f"{'gelernt, β ' + str(m.get('beta')) + ', λ ' + str(m.get('lam')) if m.get('gelernt') else 'noch Prior (Lernen ab n_eff ' + str(m.get('min_n_eff')) + ')'}")
    if lern:
        w("Bausteine: " + " · ".join(f"{k} vor {ago(u)}" for k, u in lern))
    try:
        n_pts, alter = hl_forecast.series_age(con, coin)
        w(f"Kursreihe für Analog-Suche: {n_pts:,} Punkte à 30 min · letzter Punkt vor {ago(time.time() - alter)}"
          + ("  ← VERALTET" if alter > 4 * 3600 else ""))
    except Exception as e:
        w(f"Kursreihe: {type(e).__name__}: {e}")
    w()


def teil7_system(db: str, sekunden: int) -> None:
    w("=" * 70)
    w(" 7. SYSTEM")
    w("=" * 70)
    try:
        t = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        w(f"CPU-Temperatur: {int(t)/1000:.1f} °C")
    except OSError:
        w("CPU-Temperatur: nicht lesbar")
    thr = run(["vcgencmd", "get_throttled"], 5)
    if thr and "0x" in thr:
        v = int(re.search(r"0x([0-9a-fA-F]+)", thr).group(1), 16)
        flags = {0: "Unterspannung JETZT", 1: "Takt begrenzt JETZT", 2: "gedrosselt JETZT", 3: "Temperaturlimit JETZT",
                 16: "Unterspannung seit Start", 17: "Takt begrenzt seit Start", 18: "gedrosselt seit Start", 19: "Temperaturlimit seit Start"}
        aktiv = [n for b, n in flags.items() if v & (1 << b)]
        w(f"Drosselung: {thr.strip()} {'· ' + ', '.join(aktiv) if aktiv else '· keine'}")
    try:
        la = os.getloadavg()
        mem = open("/proc/meminfo").read()
        tot = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1)) * 1024
        avail = int(re.search(r"MemAvailable:\s+(\d+)", mem).group(1)) * 1024
        w(f"Last {la[0]:.2f}/{la[1]:.2f}/{la[2]:.2f} ({os.cpu_count()} Kerne) · RAM {avail/1e9:.2f} von {tot/1e9:.1f} GB frei"
          f" · Laufzeit {float(open('/proc/uptime').read().split()[0])/86400:.1f} Tage")
    except (OSError, AttributeError):
        pass
    w(run(["df", "-h", "/", os.path.dirname(os.path.abspath(db))], 10).replace("\n", "\n  "))
    w()


def teil8_journal() -> None:
    w("=" * 70)
    w(" 8. JOURNAL — Fehlerzeilen")
    w("=" * 70)
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        txt = run(["journalctl", "-u", s, "-n", "400", "--no-pager", "-o", "short-iso"], 25)
        if "No journal files" in txt or not txt:
            w(f"{s}: kein Journal lesbar (Gruppe systemd-journal fehlt?)")
            continue
        zeilen = [l for l in txt.splitlines()
                  if re.search(r"ABGESTÜRZT|Traceback|Error|FEHLER|nicht ladbar|fehlgeschlagen|Warn", l, re.I)]
        w(f"{s}: {len(zeilen)} auffällige von 400 Zeilen")
        for l in zeilen[-6:]:
            w("  " + l[:200])
    w()


def abschnitt(fn, *args):
    """
    Einen Abschnitt ausführen und seine Laufzeit dahinter schreiben. Ein Fehler in einem Teil darf den Bericht nicht
    abbrechen -- er gehört hinein.
    """
    if _HALT[0] == fn.__name__:                   # nur Selbsttest: künstlicher Abbruch an dieser Stelle
        time.sleep(3600)
    t0 = time.monotonic()
    try:
        return fn(*args)
    except Exception as e:
        import traceback
        tb = traceback.extract_tb(e.__traceback__)
        wo = f"{tb[-1].name}:{tb[-1].lineno}" if tb else "?"
        w(f"FEHLER in diesem Abschnitt: {type(e).__name__}: {e} (bei {wo})")
        w()
        return None
    finally:
        laufzeit(time.monotonic() - t0)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=db_path())
    p.add_argument("--coin", default="BTC")
    p.add_argument("--minutes", type=float, default=1.0,
                   help="Rückblick der Kontrolle in Minuten (Zeilen mit Zeitstempel in diesem Fenster; keine Wartezeit)")
    p.add_argument("--zaehlbudget", type=float, default=ZAEHL_BUDGET_S, help="Zeitbudget der Vollzählung in Sekunden")
    p.add_argument("--selbsttest", action="store_true", help="Proben von U168 auf einer eigenen Testdatenbank")
    p.add_argument("--testhalt", default=None, help=argparse.SUPPRESS)
    a = p.parse_args(argv)
    if a.selbsttest:
        sys.exit(selbsttest())
    _zuruecksetzen()
    _HALT[0] = a.testhalt
    t_ges = time.monotonic()

    w("VOLLBERICHT hl_liq — zum Einfügen in den Chat")
    w()
    abschnitt(teil1_umgebung)
    con = abschnitt(teil2_datenbank, a.db, a.zaehlbudget)
    if con is None:
        _schluss()
        return
    abschnitt(teil2b_zuwachs, con, a.minutes)
    abschnitt(teil2c_luecken, con)
    abschnitt(teil3_recorder, con)
    abschnitt(teil4_leaderboard, con, a.coin)
    abschnitt(teil5_wale, con, a.coin)
    abschnitt(teil5b_aktivitaet, con, a.coin)
    abschnitt(teil5c_coinbase, con, a.coin)
    abschnitt(teil6_prognose, con, a.coin)
    abschnitt(teil7_system, a.db, 0)
    abschnitt(teil8_journal)
    con.close()
    w("=" * 70)
    w(f" ENDE — Laufzeit {time.monotonic() - t_ges:.0f} s · bitte vollständig einfügen")
    _schluss()


# ---------------------------------------------------------------------------
# Selbsttest (U168, 23.68): Installationsschritt, eigene Testdatenbank, ohne Netz

def _testdb(db: str, now: int) -> None:
    """Testdatenbank mit dem echten Schema des Recorders und bekannten Zeilen (Zeitstempel mit Abstand zu allen Grenzen)."""
    sys.path.insert(0, str(ROOT))
    import importlib
    con = sqlite3.connect(db)
    for modname, attr in (("hl_recorder", "SCHEMA"), ("hl_recorder", "MAGNET_SCHEMA"), ("hl_binance", "SCHEMA"),
                          ("hl_coinbase", "SCHEMA"), ("hl_ext", "SCHEMA")):
        try:
            s = getattr(importlib.import_module(modname), attr, None)
        except Exception:
            s = None
        if s:
            con.executescript(s)

    def zeile(t: str, **werte) -> None:
        spalten = [(r[1], (r[2] or "").upper()) for r in con.execute(f'PRAGMA table_info("{t}")')]
        if not spalten:
            raise RuntimeError(f"Tabelle {t} fehlt im Schema")
        vals = []
        for name, typ in spalten:
            if name in werte:
                vals.append(werte[name])
            else:
                vals.append("" if "TEXT" in typ else 0)
        con.execute(f'INSERT OR REPLACE INTO "{t}" ({",".join(chr(34) + n + chr(34) for n, _ in spalten)}) '
                    f'VALUES ({",".join("?" * len(spalten))})', vals)

    # heatmap (Sekunden): 3 Zeilen im 2-min-Rückblick, 5 in der letzten Stunde, 7 vor 5 h, 4 vor 30 h
    for i, alter in enumerate([31] * 3 + [1801] * 5 + [5 * 3600 + 7] * 7 + [30 * 3600 + 7] * 4):
        zeile("heatmap", ts=now - alter, coin="BTC", bucket_px=60000.0 + i, side="L" if i % 2 else "S", usd=1000.0)
    # bnc_liquidations hier in MILLISEKUNDEN (nur im Test; echt Sekunden) -- prüft den Weg für Tabellen mit ms-Zeitstempeln:
    # 2 im Rückblick, 3 vor 1.000 s, 4 vor 4 h
    for i, alter in enumerate([33] * 2 + [1003] * 3 + [4 * 3600 + 11] * 4):
        zeile("bnc_liquidations", ts=(now - alter) * 1000, symbol="BTCUSDT", side="SELL", price=60000.0 + i, qty=0.01 * (i + 1),
              coin="BTC")
    # bars: jede Minute der letzten 25 h, Lücke von 45 min vor rund 10 h
    for k in range(25 * 60):
        if 600 <= k < 645:
            continue
        zeile("bars", ts=now - k * 60 - 7, coin="BTC", open=60000.0, high=60010.0, low=59990.0, close=60000.0, volume=1.0,
              trades=3)
    for i in range(10):
        zeile("addresses", addr=f"0x{i:040x}")
    # Leaderboard, damit Abschnitt 4 vollständig läuft (auch seine bisherigen Zählungen)
    for c in (now - 1207, now - 307):
        for i in range(4):
            zeile("lb_accounts", ts=c, addr=f"0x{i:040x}")
            zeile("lb_positions", ts=c, addr=f"0x{i:040x}", coin="BTC")
    for i in range(6):
        zeile("lb_events", ts=now - 600 - i, addr=f"0x{i:040x}", coin="BTC", event="open", side="long")
        zeile("lb_fills", addr=f"0x{i:040x}", tid=1000 + i, ts=now - 900 - i, coin="BTC")
        zeile("lb_spot", ts=now - 1300 - i, addr=f"0x{i:040x}", token="USDC")
    for i in range(2):
        zeile("lb_gaps", addr=f"0x{i:040x}", von=now - 9000, bis=now - 5000, erkannt=now - 4000)
    zeile("lb_trend", ts=now - 1500, coin="BTC", top_n=20)
    zeile("lb_cursor", addr=f"0x{0:040x}", ts=now - 1700)
    for k, v in (("recorder_alive", now - 5), ("started", "Test"), ("api_weight_1m", 100), ("api_weight_budget", 1200)):
        zeile("meta", k=k, v=str(v))
    con.commit()
    con.close()


def _lauf(argv: list[str], ersatz: dict | None = None, spur: list | None = None) -> str:
    """main() im Prozess; Abschnitte ersetzbar, optional mit Spur aller SQL-Anweisungen. Liefert die Ausgabe."""
    import contextlib
    import io
    g = globals()
    ersatz = ersatz or {}
    alt = {k: g[k] for k in ersatz}
    g.update(ersatz)
    orig = sqlite3.connect
    if spur is not None:
        def verbinden(*a, **k):
            c = orig(*a, **k)
            c.set_trace_callback(spur.append)
            return c
        sqlite3.connect = verbinden
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            try:
                main(argv)
            except KeyboardInterrupt:
                pass
    finally:
        sqlite3.connect = orig
        g.update(alt)
    return buf.getvalue()


def _eigene_zahlen(db: str, now: int, minuten: float) -> dict:
    """Nachrechnung ohne den Bericht: Zeilen, Zuwachs je Stunde, Kontrolle im Rückblick, größte Lücke."""
    con = sqlite3.connect(db)
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    zeilen = {t: con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in tabs}
    zuwachs, kontrolle = {}, {}
    for t in tabs:
        if "ts" not in {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}:
            continue
        alle = [r[0] for r in con.execute(f'SELECT ts FROM "{t}"')]
        if not alle:
            continue
        f = 1000 if max(alle) > 1e11 else 1
        h1 = sum(1 for x in alle if x > (now - 3600) * f)
        h6 = sum(1 for x in alle if x > (now - 6 * 3600) * f)
        if h6:
            zuwachs[t] = (h1, round(h6 / 6))
        k = sum(1 for x in alle if x > (now - minuten * 60) * f)
        if k:
            kontrolle[t] = k
    luecken = {}
    for t in ("bars", "ctx_bars", "bars10", "book_summary", "heatmap", "lb_accounts", "lb_trend", "trigger_orders", "proximity"):
        ts = sorted({r[0] for r in con.execute(f'SELECT ts FROM "{t}" WHERE ts > ?', (now - 86_400,))})
        if len(ts) >= 3:
            luecken[t] = round(max(max((b - a) / 60 for a, b in zip(ts[:-1], ts[1:])), (now - ts[-1]) / 60))
    con.close()
    return {"zeilen": zeilen, "zuwachs": zuwachs, "kontrolle": kontrolle, "luecken": luecken}


def selbsttest() -> int:
    import collections
    import tempfile
    tmp = tempfile.mkdtemp(prefix="check_report_selbsttest_")
    os.environ["HL_FORECAST_DB"] = os.path.join(tmp, "forecasts_test.db")   # nie die echte Prognose-Ablage
    db = os.path.join(tmp, "test.db")
    now = int(time.time())
    _testdb(db, now)
    rot: list[str] = []

    def pruefe(name: str, ok: bool, detail: str = "") -> None:
        print(f"  {'ok ' if ok else 'ROT'}  {name}" + ("" if ok else f" -- {detail}"), flush=True)
        if not ok:
            rot.append(name)

    still = {"teil1_umgebung": lambda: (w("=" * 70), w(" 1. UMGEBUNG"), w("=" * 70), w("(Probe)"), w())[0],
             "teil7_system": lambda *a: (w("=" * 70), w(" 7. SYSTEM"), w("=" * 70), w("(Probe)"), w())[0],
             "teil8_journal": lambda: (w("=" * 70), w(" 8. JOURNAL — Fehlerzeilen"), w("=" * 70), w("(Probe)"), w())[0]}
    argv = ["--db", db, "--minutes", "2"]
    print("check_report.py --selbsttest (U168)")

    # P1 Spur: jede Tabelle genau eine Vollzählung, auch wenn Abschnitt 4 mit Daten läuft
    spur: list[str] = []
    now0 = int(time.time())
    txt = _lauf(argv, still, spur)
    now1 = int(time.time())
    muster = re.compile(r'^\s*SELECT\s+COUNT\(\*\)\s+FROM\s+"?(\w+)"?\s*;?\s*$', re.I)
    voll = collections.Counter(m.group(1) for m in (muster.match(s) for s in spur) if m)
    con = sqlite3.connect(db)
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    con.close()
    falsch = {t: voll.get(t, 0) for t in tabs if voll.get(t, 0) != 1}
    pruefe(f"Spur: jede der {len(tabs)} Tabellen genau eine Vollzählung", not falsch, f"abweichend {falsch}")
    pruefe("Bericht vollständig (Ende, alle Abschnitte mit Laufzeit)",
           " ENDE — Laufzeit" in txt and txt.count("[Laufzeit ") == 12, f"{txt.count('[Laufzeit ')} Laufzeiten")

    # P4 Gleiche Zahlen wie die eigene Nachrechnung (Zeilen, Zuwachs je Stunde, Lücken), P7 Kontrolle im Rückblick
    e0, e1 = _eigene_zahlen(db, now0, 2), _eigene_zahlen(db, now1, 2)
    pruefe("Nachrechnung stabil über die Laufzeit (Zeitstempel mit Abstand zu den Grenzen)",
           all(e0[k] == e1[k] for k in ("zeilen", "zuwachs", "kontrolle")) and e0["luecken"] == e1["luecken"])
    gedruckt = {m.group(1): int(m.group(2).replace(",", ""))
                for m in re.finditer(r"^(\w+)\s+([\d,]+)\s\s", txt, re.M)}
    erwartet = {t: n for t, n in e0["zeilen"].items() if n}          # leere Tabellen ohne Zeitstempel druckt er nicht
    fehlt = {t: (gedruckt.get(t), n) for t, n in erwartet.items() if gedruckt.get(t) != n}
    pruefe("Zeilen je Tabelle = eigene Zählung", not fehlt, f"{fehlt}")
    zw = {m.group(1): (int(m.group(2).replace(",", "")), int(m.group(3).replace(",", "")))
          for m in re.finditer(r"^\s+(\w+)\s+([\d,]+)/h\s+\(6-h-Mittel\s+([\d,]+)/h\)", txt, re.M)}
    pruefe("Zuwachs je Stunde (1 h, 6-h-Mittel) = eigene Zählung", zw == e0["zuwachs"], f"{zw} gegen {e0['zuwachs']}")
    lu = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\w+)\s+(\d+) min\s+\(erwartet", txt, re.M)}
    pruefe("Größte Lücke je Strom = eigene Rechnung (bars: 45 fehlende Minuten = 46 min Abstand)",
           lu == e0["luecken"] and lu.get("bars") == 46,
           f"{lu} gegen {e0['luecken']}")
    m = re.search(r"Kontrolle \(Zeilen mit Zeitstempel in den letzten 120 s\): (.*)", txt)
    ko = {a: int(b) for a, b in re.findall(r"(\w+) \+(\d+)", m.group(1))} if m else None
    pruefe("Kontrolle = eigene Zählung im Rückblick, auch eine Tabelle in Millisekunden (Testzeilen: bnc_liquidations 2, heatmap 3, bars 2)",
           ko == e0["kontrolle"] and (ko or {}).get("bnc_liquidations") == 2 and (ko or {}).get("heatmap") == 3,
           f"{ko} gegen {e0['kontrolle']}")
    pruefe("keine Wartezeit mehr (Bericht in unter 60 s)", now1 - now0 < 60, f"{now1 - now0} s")

    # P2 Teilausgabe nach künstlichem Abbruch im Prozess: alles bis Abschnitt 2c steht schon da
    def abbruch(*a):
        raise KeyboardInterrupt
    txt2 = _lauf(argv, dict(still, teil3_recorder=abbruch))
    pruefe("Abbruch im Prozess: fertige Abschnitte stehen in der Ausgabe",
           all(s in txt2 for s in (" 1. UMGEBUNG", " 2. DATENBANK", "Zählung:", "Zuwachs je Stunde", "Größte Lücke"))
           and " 3. RECORDER" not in txt2, txt2[-300:])

    # P5 Zeitbudget mit kleiner Grenze (falsche Uhr: je Tabelle 10 s): heatmap „nicht gezählt“, alle anderen gezählt
    class Uhr:
        t = -10.0
        def __call__(self):
            self.t += 10.0
            return self.t
    import contextlib
    import io
    _zuruecksetzen()
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        c5 = teil2_datenbank(db, budget_s=10.0 * len(tabs) - 5.0, uhr=Uhr())
        _schluss()
    c5.close()
    t5 = buf.getvalue()
    pruefe("Zeitbudget: nur heatmap nicht gezählt, alle anderen gezählt",
           ZAEHLUNG["offen"] == ["heatmap"] and set(ZAEHLUNG["stand"]) == set(tabs) - {"heatmap"}
           and re.search(r"^heatmap\s+nicht gezählt \(Zeitbudget\)", t5, re.M) is not None
           and "1 nicht gezählt (Zeitbudget" in t5,
           f"offen {ZAEHLUNG['offen']}")
    # Frist bricht eine laufende Abfrage ab (endlose rekursive Abfrage), sonst liefert sie den Wert
    c6 = sqlite3.connect(db)
    t0 = time.monotonic()
    r_endlos = _abfrage_mit_frist(c6, "WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM c) SELECT COUNT(*) FROM c", 0.3)
    dt = time.monotonic() - t0
    r_bars = _abfrage_mit_frist(c6, 'SELECT COUNT(*) FROM "bars"', 30)
    r_null = _abfrage_mit_frist(c6, 'SELECT COUNT(*) FROM "bars"', 0)
    nach = c6.execute("SELECT 1").fetchone()[0]
    c6.close()
    pruefe("Frist: laufende Abfrage nach 0,3 s abgebrochen, danach normale Abfragen", r_endlos is None and dt < 5 and nach == 1,
           f"{r_endlos} nach {dt:.1f} s")
    pruefe("Frist: Zählung in der Frist liefert den Wert, Frist 0 zählt nicht", r_bars == e0["zeilen"]["bars"] and r_null is None,
           f"{r_bars} {r_null}")

    # P3 + P8 über den Berichtsplan des Dashboards (Unterprozess, kurze Grenze)
    try:
        import hl_viz
        py = sys.executable
        _, kopf_a, out_a = hl_viz._bericht_ausfuehren("Probe", [py, str(ROOT / "check_report.py"), "--db", db, "--minutes", "2",
                                                               "--testhalt", "teil3_recorder"], "BTC", grenze_s=15, nahe_s=10)
        pruefe("Berichtsplan, Abbruch an der Zeitgrenze: Teilausgabe mit den fertigen Abschnitten, Kopf „Exit Zeit“",
               "Exit Zeit" in kopf_a and all(s in out_a for s in (" 2. DATENBANK", "Zählung:", "Größte Lücke"))
               and "abgebrochen nach" in out_a and " 3. RECORDER" not in out_a, (kopf_a + out_a)[-400:])
        _, kopf_b, _ = hl_viz._bericht_ausfuehren("Probe", [py, "-c", "import time; time.sleep(1.5); print('fertig')"], "BTC",
                                                  grenze_s=6, nahe_s=1)
        _, kopf_c, _ = hl_viz._bericht_ausfuehren("Probe", [py, "-c", "print('fertig')"], "BTC", grenze_s=6, nahe_s=1)
        pruefe("Kopfzusatz „nahe der Zeitgrenze“ ab der Schwelle, darunter nicht",
               "nahe der Zeitgrenze" in kopf_b and "Exit 0" in kopf_b and "nahe der Zeitgrenze" not in kopf_c, kopf_b + kopf_c)
        pruefe("Grenze und Schwelle des Berichtsplans: 900 s und 600 s (zwei Drittel)",
               hl_viz.BERICHT_GRENZE_S == 900 and hl_viz.BERICHT_NAHE_S == 600)
        name = hl_viz.debug_commands("x.db")["report"][0]
        pruefe("Menüname „(rund 5 min)“, Kennung report", name.endswith("(rund 5 min)") and "(2 min)" not in name, name)
    except Exception as e:
        pruefe("Berichtsplan-Proben", False, f"{type(e).__name__}: {e}")

    import shutil as _sh
    _sh.rmtree(tmp, ignore_errors=True)
    print(f"Ergebnis: {'alle Proben grün' if not rot else str(len(rot)) + ' ROT: ' + '; '.join(rot)}")
    return 0 if not rot else 1


if __name__ == "__main__":
    main()
