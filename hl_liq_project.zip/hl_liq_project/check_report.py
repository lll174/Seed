#!/usr/bin/env python3
"""
Vollbericht: alles, was zur Fehlersuche nötig ist, in einem Text.

  python3 check_report.py                  # Standard: Datenbank aus der systemd-Einheit
  python3 check_report.py --db /pfad.db --coin BTC --minutes 10

Sammelt in einem Durchgang:
  1. Umgebung     Version der Dateien, Python, Laufzeit, Dienste
  2. Datenbank    Größe, Tabellenstände, Zuwachs je Minute, letzter Eintrag je Strom
  3. Recorder     API-Gewicht, Poller-Zustand, Aufgabenfehler, Temperaturschutz, Backup
  4. Leaderboard  Konten, Positionen, Ereignisse, Fills, Trendzeilen
  5. Wale         Anzahl je Gruppe, Flow, letzte Ereignisse
  6. Prognose     Lernstand, Trefferquoten, Ablage, letzte Prognose
  7. System       Temperatur, CPU, Speicher, Schreiblast je Laufwerk
  8. Journal      die letzten Fehlerzeilen der drei Dienste

Der Text ist bewusst kompakt gehalten: Er soll sich vollständig in einen Chat einfügen
lassen. Keine Adressen im Klartext außer gekürzt, keine Schlüssel.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT: list[str] = []


def w(line: str = "") -> None:
    OUT.append(line)


def run(cmd: list[str], timeout: int = 20) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()
    except Exception as e:
        return f"({type(e).__name__}: {e})"


def unit_arg(flag: str, unit: str = "hl-recorder") -> str | None:
    try:
        m = re.search(rf"{flag}\s+(\S+)", Path(f"/etc/systemd/system/{unit}.service").read_text())
        return m.group(1) if m else None
    except OSError:
        return None


def db_path() -> str:
    return unit_arg("--db") or str(ROOT / "hl_liq.db")


def ago(ts) -> str:
    if not ts:
        return "—"
    d = time.time() - float(ts)
    return f"{d/60:.0f} min" if d < 7200 else f"{d/3600:.1f} h" if d < 172800 else f"{d/86400:.1f} T"


def fmt(n) -> str:
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "—"
    for grenze, einheit in ((1e9, "Mrd"), (1e6, "Mio"), (1e3, "k")):
        if abs(n) >= grenze:
            return f"{n/grenze:,.1f} {einheit}"
    return f"{n:,.0f}"


def short(a: str) -> str:
    return f"{a[:6]}…{a[-4:]}" if isinstance(a, str) and len(a) > 12 else str(a)


# ---------------------------------------------------------------------------

def teil1_umgebung() -> None:
    w("=" * 70)
    w(" 1. UMGEBUNG")
    w("=" * 70)
    w(f"Bericht {time.strftime('%d.%m.%Y %H:%M:%S')} · Python {sys.version.split()[0]} · Ordner {ROOT}")
    files = sorted(p for p in ROOT.glob("*.py"))
    zeilen = []
    for p in files:
        try:
            zeilen.append(f"{p.name} {p.stat().st_size//1024}k {time.strftime('%d.%m. %H:%M', time.localtime(p.stat().st_mtime))}")
        except OSError:
            pass
    w("Dateien: " + " · ".join(zeilen))
    log = ROOT / "updates" / "last_update.log"
    if log.exists():
        txt = log.read_text(errors="replace").strip().splitlines()
        w(f"Letztes Update: {time.strftime('%d.%m. %H:%M', time.localtime(log.stat().st_mtime))} · "
          f"{'erfolgreich' if any('Fertig' in l for l in txt) else 'ABGEBROCHEN?'} · {len(txt)} Zeilen")
        fehler = [l.strip() for l in txt if "FEHLER" in l or "Traceback" in l]
        if fehler:
            w("  Fehler im Update: " + " | ".join(fehler[:3])[:300])
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        st = run(["systemctl", "is-active", s], 5) or "?"
        if "not been booted" in st or "Failed to connect" in st:
            w("Dienste: systemd nicht verfügbar (Testumgebung)")
            break
        since = run(["systemctl", "show", s, "--property=ActiveEnterTimestamp", "--value"], 5)
        mem = run(["systemctl", "show", s, "--property=MemoryCurrent", "--value"], 5)
        restarts = run(["systemctl", "show", s, "--property=NRestarts", "--value"], 5)
        try:
            mem = f"{int(mem)/1e6:.0f} MB"
        except ValueError:
            mem = "—"
        w(f"Dienst {s:<14} {st:<10} seit {since[:25] or '—'} · Speicher {mem} · Neustarts {restarts or '—'}")
    w()


def teil2_datenbank(db: str, minutes: int) -> sqlite3.Connection | None:
    w("=" * 70)
    w(" 2. DATENBANK")
    w("=" * 70)
    if not os.path.exists(db):
        w(f"FEHLT: {db}")
        w()
        return None
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)
    con.row_factory = sqlite3.Row
    wal = db + "-wal"
    w(f"{db} · {os.path.getsize(db)/1e9:.2f} GB · WAL {os.path.getsize(wal)/1e6:.1f} MB"
      if os.path.exists(wal) else f"{db} · {os.path.getsize(db)/1e9:.2f} GB")
    try:
        u = shutil.disk_usage(os.path.dirname(os.path.abspath(db)))
        w(f"Medium: {u.free/1e9:.1f} GB frei von {u.total/1e9:.0f} GB")
    except OSError:
        pass
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    stand1 = {}
    for t in tabs:
        try:
            stand1[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            stand1[t] = -1
    # jüngster Eintrag je Strom
    w(f"{'Tabelle':<18} {'Zeilen':>12}  letzter Eintrag")
    for t in tabs:
        letzte = "—"
        try:
            cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
            if "ts" in cols:
                ts = con.execute(f'SELECT MAX(ts) FROM "{t}"').fetchone()[0]
                if ts:
                    ts = ts / 1000 if ts > 1e11 else ts
                    letzte = f"vor {ago(ts)}"
        except sqlite3.Error:
            pass
        if stand1[t] or letzte != "—":
            w(f"{t:<18} {stand1[t]:>12,}  {letzte}")
    return con


def teil2b_zuwachs(con, stand_vorher: dict, sekunden: float) -> None:
    """
    Zuwachs je Stunde -- gezählt über die Zeitstempel der letzten Stunde, nicht hochgerechnet
    aus einem Zweiminutenfenster. Schreibt ein Strom in Schüben (Snapshots alle 15 min), traf
    das kurze Fenster entweder einen Schub oder keinen: einmal 0/h, einmal 353.000/h für
    dieselbe Tabelle. Die Zählung über Zeitstempel ist unabhängig vom Messzeitpunkt.
    """
    now = int(time.time())
    w()
    w("Zuwachs je Stunde (aus den Zeitstempeln der letzten 1 h / 6 h):")
    zeilen = []
    for t in sorted(stand_vorher):
        try:
            cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
            if "ts" not in cols:
                continue
            probe = con.execute(f'SELECT MAX(ts) FROM "{t}"').fetchone()[0]
            if not probe:
                continue
            teiler = 1000 if probe > 1e11 else 1        # 1e11 trennt Sekunden (max 5138) von Millisekunden sicher              # manche Ströme in Millisekunden
            h1 = con.execute(f'SELECT COUNT(*) FROM "{t}" WHERE ts > ?', ((now - 3600) * teiler,)).fetchone()[0]
            h6 = con.execute(f'SELECT COUNT(*) FROM "{t}" WHERE ts > ?', ((now - 6 * 3600) * teiler,)).fetchone()[0]
            if h6:
                zeilen.append((h1, t, h6 / 6))
        except sqlite3.Error:
            continue
    zeilen.sort(reverse=True)
    for h1, t, h6 in zeilen[:14]:
        hinweis = ""
        if h1 == 0 and h6 > 0:
            hinweis = "  ← in der letzten Stunde nichts"
        elif h6 > 0 and h1 > 3 * h6:
            hinweis = "  ← Schub"
        w(f"  {t:<18} {h1:>9,}/h   (6-h-Mittel {h6:>9,.0f}/h){hinweis}")
    # Zweitmessung über das Fenster, nur als Kontrolle
    delta = []
    for t, n0 in stand_vorher.items():
        try:
            n1 = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            continue
        if n1 > n0:
            delta.append((n1 - n0, t))
    delta.sort(reverse=True)
    w(f"  Kontrolle im {sekunden:.0f}-s-Fenster: " + (", ".join(f"{t} +{d}" for d, t in delta[:8]) if delta else "keine Tabelle gewachsen"))
    w()


def teil2c_luecken(con) -> None:
    """
    Aufzeichnungslücken der letzten 24 h. Ein stiller Ausfall zeigt sich nicht an der Zeilenzahl,
    sondern an der größten Lücke zwischen zwei Einträgen -- so blieb ein Leaderboard-Ausfall
    30 Stunden unbemerkt, obwohl die Tabelle weiter Zeilen hatte.
    """
    now = int(time.time())
    erwartet = {"bars": 5, "ctx_bars": 5, "bars10": 20, "book_summary": 5, "heatmap": 30,
                "lb_accounts": 20, "lb_trend": 130, "trigger_orders": 30, "proximity": 10}
    w("Größte Lücke in den letzten 24 h (Minuten):")
    zeilen = []
    for t, grenze in erwartet.items():
        try:
            rows = [r[0] for r in con.execute(f'SELECT DISTINCT ts FROM "{t}" WHERE ts > ? ORDER BY ts', (now - 86_400,))]
        except sqlite3.Error:
            continue
        if len(rows) < 3:
            zeilen.append((9999, t, grenze, len(rows)))
            continue
        luecke = max((b - a) / 60 for a, b in zip(rows[:-1], rows[1:]))
        luecke = max(luecke, (now - rows[-1]) / 60)
        zeilen.append((luecke, t, grenze, len(rows)))
    zeilen.sort(reverse=True)
    for luecke, t, grenze, n in zeilen:
        if luecke >= 9999:
            w(f"  {t:<18} zu wenige Einträge ({n}) für eine Aussage")
        else:
            w(f"  {t:<18} {luecke:>6.0f} min   (erwartet unter {grenze} min){'  ← AUFFÄLLIG' if luecke > grenze else ''}")
    w()


def teil3_recorder(con) -> None:
    w("=" * 70)
    w(" 3. RECORDER")
    w("=" * 70)
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
    except sqlite3.Error:
        w("meta nicht lesbar")
        w()
        return
    alive = int(meta.get("recorder_alive") or 0)
    w(f"Lebenszeichen: {'vor ' + ago(alive) if alive else 'FEHLT (alte Version oder Recorder aus)'}"
      f" · Start {meta.get('started', '—')}")
    used, budget = int(meta.get("api_weight_1m") or 0), int(meta.get("api_weight_budget") or 1200)
    w(f"API-Gewicht: {used}/{budget} ({used/max(budget,1)*100:.0f} %) · Stand vor {ago(meta.get('api_weight_ts'))}"
      f" · 429er: {meta.get('rate_limited', 0)}")
    try:
        split = json.loads(meta.get("weight_split") or "{}")
    except ValueError:
        split = {}
    if split:
        ges = sum(split.values()) or 1
        w("  Gewicht je Verbraucher (letzte Minute): "
          + " · ".join(f"{k} {v} ({v/ges*100:.0f} %)" for k, v in sorted(split.items(), key=lambda x: -x[1])))
    pb, pw = int(meta.get("poller_batch") or 0), int(meta.get("poller_want") or 0)
    w(f"Poller: {pb}/{pw} je Runde {'(voll)' if pw and pb >= pw else '(NICHT VOLL — zu wenige fällige Adressen)' if pw else ''}"
      f" · fällig: {meta.get('poller_due_a','?')} mit Position, {meta.get('poller_due_b','?')} neu, {meta.get('poller_due_c','?')} leer"
      f" · {int(meta.get('addr_total') or 0):,} Adressen")
    lvl = int(meta.get("thermal_level") or 0)
    w(f"Temperaturschutz: {'Stufe ' + str(lvl) if lvl else 'inaktiv'} · {meta.get('thermal_temp','—')} °C"
      f" · Gewicht x{meta.get('thermal_weight_factor','1')} · Takte x{meta.get('thermal_interval_factor','1')}")
    try:
        te = json.loads(meta.get("task_errors") or "{}")
    except ValueError:
        te = {}
    if te:
        w("AUFGABEN-ABSTÜRZE:")
        for k, v in te.items():
            w(f"  {k}: {v.get('count')}x · zuletzt vor {ago(v.get('ts'))} · {str(v.get('error'))[:150]}")
    else:
        w("Aufgaben: keine Abstürze vermerkt")
    bdir = meta.get("backup_dir") or str(ROOT / "dbbackup")
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            b = json.load(f)
        w(f"Backup: {'ok' if b.get('ok') else 'FEHLGESCHLAGEN: ' + str(b.get('error'))[:80]}"
          f" · vor {ago(b.get('ts'))} · {fmt(b.get('size'))} B · Ordner {bdir}")
    except (OSError, ValueError):
        w(f"Backup: keine backup.json in {bdir}")
    w()


def teil4_leaderboard(con, coin: str) -> None:
    now = int(time.time())
    w("=" * 70)
    w(f" 4. LEADERBOARD ({coin})")
    w("=" * 70)
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.Error:
        w("Tabellen fehlen — Recorder-Version zu alt?")
        w()
        return
    if not last:
        w("noch kein Durchgang")
        w()
        return
    n_acc = con.execute("SELECT COUNT(*) FROM lb_accounts WHERE ts=?", (last,)).fetchone()[0]
    n_pos = con.execute("SELECT COUNT(*) FROM lb_positions WHERE ts=?", (last,)).fetchone()[0]
    n_cyc = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_accounts").fetchone()[0]
    w(f"Letzter Durchgang vor {ago(last)} · {n_acc} Konten · {n_pos} Positionen · {n_cyc} Durchgänge gesamt")
    luecke = con.execute("SELECT COUNT(*) FROM lb_trend WHERE coin=? AND top_n=20", (coin,)).fetchone()[0]
    letzte_trend = con.execute("SELECT MAX(ts) FROM lb_trend WHERE coin=?", (coin,)).fetchone()[0]
    w(f"Trendzeilen {coin}: {luecke} · letzte vor {ago(letzte_trend)}")
    for tab, label in (("lb_events", "Ereignisse"), ("lb_fills", "Fills"), ("lb_spot", "Spot-Bestände")):
        try:
            n = con.execute(f"SELECT COUNT(*) FROM {tab}").fetchone()[0]
            letzte = con.execute(f"SELECT MAX(ts) FROM {tab}").fetchone()[0]
            extra = ""
            if tab == "lb_events":
                h1 = con.execute("SELECT COUNT(*) FROM lb_events WHERE coin=? AND ts>=?", (coin, int(time.time()) - 3600)).fetchone()[0]
                extra = f" · letzte Stunde in {coin}: {h1}"
            w(f"{label}: {n:,} · letzter vor {ago(letzte)}{extra}")
        except sqlite3.Error:
            w(f"{label}: Tabelle fehlt")
    # Fills je Coin: Kommen für DIESEN Coin überhaupt Daten an? Eine leere Tabelle sagt nichts,
    # solange andere Coins gefüllt werden -- erst der Vergleich trennt "ruhig" von "fehlt".
    try:
        gesamt = con.execute("SELECT COUNT(*), MAX(ts) FROM lb_fills WHERE ts > ?", (now - 86_400,)).fetchone()
        w(f"Fills letzte 24 h: {gesamt[0]:,} · jüngster vor {ago(gesamt[1])}")
        top = con.execute("""SELECT coin, COUNT(*) n, MAX(ts) letzte FROM lb_fills WHERE ts > ?
                             GROUP BY coin ORDER BY n DESC LIMIT 8""", (now - 86_400,)).fetchall()
        if top:
            w("  je Coin (24 h): " + " · ".join(f"{r['coin']} {r['n']:,} (vor {ago(r['letzte'])})" for r in top))
        eigen = con.execute("""SELECT COUNT(*) n, MAX(ts) letzte, COUNT(DISTINCT addr) k FROM lb_fills
                               WHERE coin=? AND ts > ?""", (coin, now - 86_400)).fetchone()
        w(f"  {coin} in 24 h: {eigen['n']:,} Fills von {eigen['k']} Konten"
          + (f" · jüngster vor {ago(eigen['letzte'])}" if eigen["letzte"] else " · KEINER"))
        tage = con.execute("""SELECT strftime('%d.%m', ts, 'unixepoch', 'localtime') tag, COUNT(*) n,
                                     ROUND(SUM(notional)/1e6, 1) usd
                              FROM lb_fills WHERE coin=? AND ts > ? GROUP BY tag ORDER BY MIN(ts)""",
                           (coin, now - 5 * 86_400)).fetchall()
        if tage:
            w(f"  {coin} je Tag: " + " · ".join(f"{r['tag']}: {r['n']:,} Fills, {r['usd']} Mio" for r in tage))
            fehlend = [r["tag"] for r in tage if r["n"] == 0]
            if len(tage) < 4:
                w(f"  ← nur {len(tage)} Tage mit {coin}-Fills in 5 Tagen: prüfen, ob Tage fehlen")
    except sqlite3.Error as e:
        w(f"Fills je Coin nicht lesbar: {e}")

    # Übersprungene Zeiträume
    try:
        gaps = con.execute("SELECT addr, von, bis FROM lb_gaps ORDER BY erkannt DESC LIMIT 5").fetchall()
        n_gaps = con.execute("SELECT COUNT(*) FROM lb_gaps").fetchone()[0]
        if n_gaps:
            w(f"ÜBERSPRUNGENE ZEITRÄUME: {n_gaps} Konten — ihre Fills fehlen dort dauerhaft:")
            for g in gaps:
                w(f"  {short(g['addr'])}: {time.strftime('%d.%m %H:%M', time.localtime(g['von']))}"
                  f" bis {time.strftime('%d.%m %H:%M', time.localtime(g['bis']))}"
                  f" ({(g['bis']-g['von'])/3600:.1f} h)")
        else:
            w("Übersprungene Zeiträume: keine")
    except sqlite3.Error:
        w("Übersprungene Zeiträume: Tabelle lb_gaps fehlt (Recorder-Version zu alt)")

    try:
        rows = con.execute("SELECT ts FROM lb_cursor").fetchall()
        if rows:
            jetzt = time.time()
            rueck = sorted(min((jetzt - (r[0] or 0)) / 3600, 9999) for r in rows)
            hinten = sum(1 for r in rueck if r > 3)
            try:
                defer = int(dict(con.execute("SELECT k, v FROM meta")).get("lb_fills_deferred") or 0)
            except sqlite3.Error:
                defer = 0
            w(f"Fill-Abholstand: {len(rows)} Konten · Median {rueck[len(rueck)//2]:.1f} h zurück · "
              f"schlechtestes {rueck[-1]:.1f} h · {hinten} Konten mehr als 3 h zurück"
              + (f" · {sum(1 for r in rueck if r > 100)} ohne gültigen Stand" if any(r > 100 for r in rueck) else "")
              + (f" · {defer} Konten wegen Gewichtsbudget zurückgestellt" if defer else "")
              + ("  ← AUFHOLEN LÄUFT" if hinten else ""))
        else:
            w("Fill-Abholstand: keine lb_cursor-Einträge (Recorder-Version zu alt oder erster Lauf steht aus)")
    except sqlite3.Error:
        w("Fill-Abholstand: Tabelle lb_cursor fehlt")
    try:
        rows = con.execute("""SELECT event, side, COUNT(*) n, ROUND(SUM(delta_usd)) s FROM lb_events
                              WHERE coin=? AND ts>=? GROUP BY event, side""", (coin, int(time.time()) - 6 * 3600)).fetchall()
        if rows:
            w("Ereignisse 6 h: " + " · ".join(f"{r['event']} {r['side']} {r['n']}x {fmt(r['s'])}" for r in rows))
    except sqlite3.Error:
        pass
    w()


def teil5_wale(con, coin: str) -> None:
    w("=" * 70)
    w(f" 5. WALE ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_viz
        d = hl_viz.load_whales(con, coin, 72)
    except Exception as e:
        w(f"load_whales fehlgeschlagen: {type(e).__name__}: {e}")
        w()
        return
    F = d.get("flow") or {}
    w(f"Konten je Gruppe: {F.get('sizes')} · erfasst {F.get('n_total')} · direktional {F.get('n_directional')}")
    for g, name in (F.get("group_names") or {}).items():
        gf = (F.get("groups") or {}).get(g)
        if not gf:
            continue
        a30, a60 = gf["w30"], gf["w60"]
        w(f"  {name:<14} 30 min netto {fmt(a30['net_usd']):>10} ({a30['n_buy']}/{a30['n_sell']})"
          f" · 60 min {fmt(a60['net_usd']):>10} ({a60['n_buy']}/{a60['n_sell']})"
          f" · Z30 {'—' if gf.get('z30') is None else round(gf['z30'], 1)}"
          f"{' · EREIGNIS' if gf.get('event_signal') else ''}")
    D = d.get("directional") or {}
    if D:
        w(f"Bestand direktional: {D.get('n_long')} long {fmt(D.get('usd_long'))} gegen {D.get('n_short')} short {fmt(D.get('usd_short'))}")
    ev = list(reversed((d.get("events") or [])[-8:]))       # die NEUESTEN acht, neueste zuerst
    if ev:
        w("Letzte Änderungen:")
        for e in ev:
            grp = (F.get("per_coin") or {}).get(str(e.get("addr", "")).lower(), "?")
            w(f"  {time.strftime('%d.%m %H:%M', time.localtime(e['ts']))} {short(e['addr'])} {e['event']} {e['side']}"
              f" {fmt(e.get('delta_usd'))} [{grp}]")
    w()


def teil5b_aktivitaet(con, coin: str) -> None:
    """
    Ist der Markt ruhig oder die Aufzeichnung kaputt? Die Frage lässt sich nur beantworten,
    indem man die letzte Stunde gegen den eigenen Normalwert stellt -- absolute Zahlen sagen
    nichts. Verglichen werden Volumen, Trades, Spanne, Wal-Ereignisse und Liquidationen.
    """
    now = int(time.time())
    w("=" * 70)
    w(f" 5b. MARKTAKTIVITÄT ({coin}) — letzte Stunde gegen den Schnitt")
    w("=" * 70)

    def vergleich(label: str, h1: float, schnitt: float, einheit: str = "") -> None:
        if schnitt <= 0:
            w(f"  {label:<26} {h1:>12,.0f}{einheit}   (kein Vergleichswert)")
            return
        q = h1 / schnitt
        deutung = ("sehr ruhig" if q < 0.4 else "ruhig" if q < 0.75 else
                   "normal" if q < 1.5 else "lebhaft" if q < 3 else "sehr lebhaft")
        w(f"  {label:<26} {h1:>12,.0f}{einheit}   Schnitt {schnitt:>12,.0f}{einheit}   {q*100:>5.0f} %  {deutung}")

    try:
        r = con.execute("""SELECT SUM(volume*close) v, SUM(trades) n, MAX(high) h, MIN(low) l, MAX(close) c
                           FROM bars WHERE coin=? AND ts>?""", (coin, now - 3600)).fetchone()
        r7 = con.execute("""SELECT SUM(volume*close)/168.0 v, SUM(trades)/168.0 n
                            FROM bars WHERE coin=? AND ts>?""", (coin, now - 7 * 86_400)).fetchone()
        vergleich("Volumen 1 h (USD)", r["v"] or 0, r7["v"] or 0)
        vergleich("Trades 1 h", r["n"] or 0, r7["n"] or 0)
        if r["h"] and r["l"] and r["c"]:
            spanne = (r["h"] - r["l"]) / r["c"] * 100
            r7b = con.execute("""SELECT AVG(s) FROM (SELECT (MAX(high)-MIN(low))/MAX(close)*100 s FROM bars
                                 WHERE coin=? AND ts>? GROUP BY ts/3600)""", (coin, now - 7 * 86_400)).fetchone()[0] or 0
            vergleich("Spanne 1 h (%)", spanne, r7b, " %")
    except sqlite3.Error as e:
        w(f"  Kurs/Volumen nicht lesbar: {e}")

    # Wal-Ereignisse: echte Änderungen gegen Snapshots trennen
    try:
        ev1 = {r[0]: r[1] for r in con.execute(
            "SELECT event, COUNT(*) FROM whale_positions WHERE ts>? GROUP BY event", (now - 3600,))}
        ev24 = {r[0]: r[1] for r in con.execute(
            "SELECT event, COUNT(*) FROM whale_positions WHERE ts>? GROUP BY event", (now - 86_400,))}
        echt1 = sum(v for k, v in ev1.items() if k != "snap")
        echt24 = sum(v for k, v in ev24.items() if k != "snap") / 24
        vergleich("Wal-Ereignisse 1 h (alle)", echt1, echt24)
        c1 = con.execute("SELECT COUNT(*) FROM whale_positions WHERE coin=? AND ts>? AND event!='snap'",
                         (coin, now - 3600)).fetchone()[0]
        c24 = con.execute("SELECT COUNT(*) FROM whale_positions WHERE coin=? AND ts>? AND event!='snap'",
                          (coin, now - 86_400)).fetchone()[0] / 24
        vergleich(f"Wal-Ereignisse 1 h ({coin})", c1, c24)
        w(f"  davon Snapshots 1 h: {ev1.get('snap', 0):,} (zählen nicht als Handel, erklären aber den Zeilenzuwachs)")
        arten = " · ".join(f"{k} {v}" for k, v in sorted(ev1.items()) if k != "snap")
        w(f"  Arten letzte Stunde: {arten or 'keine'}")
    except sqlite3.Error as e:
        w(f"  Wal-Ereignisse nicht lesbar: {e}")

    try:
        l1 = con.execute("SELECT COUNT(*) FROM lb_events WHERE ts>?", (now - 3600,)).fetchone()[0]
        l24 = con.execute("SELECT COUNT(*) FROM lb_events WHERE ts>?", (now - 86_400,)).fetchone()[0] / 24
        vergleich("Leaderboard-Ereignisse 1 h", l1, l24)
    except sqlite3.Error:
        pass
    try:
        q1 = con.execute("SELECT COUNT(*) FROM liquidations WHERE ts>?", (now - 3600,)).fetchone()[0]
        q24 = con.execute("SELECT COUNT(*) FROM liquidations WHERE ts>?", (now - 86_400,)).fetchone()[0] / 24
        vergleich("Liquidationen 1 h", q1, q24)
    except sqlite3.Error:
        pass
    w("  Lesehilfe: stehen Volumen und Trades bei 'normal' und die Ereignisse bei 'sehr ruhig',")
    w("  handelt niemand -- die Aufzeichnung ist in Ordnung. Stehen BEIDE bei null, ist sie es nicht.")
    w()


def teil5c_coinbase(con, coin: str) -> None:
    """Coinbase-Spot: läuft der Dienst, und was sagen Prämie, Flow und Buch?"""
    now = int(time.time())
    w("=" * 70)
    w(f" 5c. COINBASE-SPOT ({coin})")
    w("=" * 70)
    try:
        meta = dict(con.execute("SELECT k, v FROM cb_meta"))
    except sqlite3.Error:
        w("Dienst nicht eingerichtet (Tabelle cb_meta fehlt) — python3 install.py --enable")
        w()
        return
    alive = int(meta.get("alive") or 0)
    w(f"Lebenszeichen: {'vor ' + ago(alive) if alive else 'FEHLT'} · Paare: {meta.get('products', '—')}")
    w(f"Zähler: {meta.get('stats', '—')}")
    for tab, label, erwartet in (("cb_bars", "Minutenkerzen", 5), ("cb_book", "Buch-Stände", 10)):
        try:
            n, letzte = con.execute(f"SELECT COUNT(*), MAX(ts) FROM {tab} WHERE coin=?", (coin,)).fetchone()
            alt = (now - letzte) / 60 if letzte else None
            w(f"{label}: {n:,} · letzter vor {ago(letzte)}"
              + ("  ← VERALTET" if alt is not None and alt > erwartet else ""))
        except sqlite3.Error:
            w(f"{label}: Tabelle fehlt")
    try:
        sys.path.insert(0, str(ROOT))
        import hl_viz
        perp = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        d = hl_viz.load_coinbase(con, coin, perp[0] if perp else None)
        if not d.get("aktiv"):
            w(f"Auswertung: keine frischen Daten{' (' + str(d.get('alter_min')) + ' min alt)' if d.get('alter_min') is not None else ''}")
        else:
            if d.get("premium_bps") is not None:
                w(f"Prämie: {d['premium_bps']:+.1f} bps"
                  + (f" · Mittel {d['premium_mittel']:+.1f} · Z {d['premium_z']:+.2f} ({d['premium_n']:,} Minuten)"
                     if d.get("premium_z") is not None else " · noch keine Vergleichsreihe"))
            f60 = d.get("flow60") or {}
            w(f"Taker-Flow 60 min: {fmt(f60.get('buy_usd'))} gekauft gegen {fmt(f60.get('sell_usd'))} verkauft"
              f" · netto {fmt(f60.get('net_usd'))}" + (f" · Z {d['flow_z']:+.2f}" if d.get("flow_z") is not None else ""))
            if d.get("vol_rel"):
                w(f"Volumen 1 h: {fmt(d['vol_1h'])} gegen Schnitt {fmt(d['vol_schnitt'])} = {d['vol_rel']:.2f}x")
            b = d.get("book") or {}
            if b:
                w(f"Buch: Spread {b['spread_bps']:.2f} bps · ±25 bps {fmt(b['bid25'])} Gebot gegen {fmt(b['ask25'])} Angebot"
                  f" ({b['imbalance']*100:+.0f} %) · {len(d.get('walls') or [])} Wände")
    except Exception as e:
        w(f"Auswertung fehlgeschlagen: {type(e).__name__}: {e}")
    w()


def teil6_prognose(con, coin: str) -> None:
    w("=" * 70)
    w(f" 6. PROGNOSE UND LERNSTAND ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_forecast
    except Exception as e:
        w(f"hl_forecast nicht ladbar: {e}")
        w()
        return
    store = hl_forecast.STORE
    w(f"Ablage: {store} ({os.path.getsize(store)/1e6:.1f} MB)" if os.path.exists(store) else f"Ablage: {store} (fehlt)")
    try:
        st = hl_forecast.store_connect(store)
        st.row_factory = sqlite3.Row
        n = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        fen = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        letzte = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        row = st.execute("SELECT ts, price, bias, confidence, p_24h, buy_px, sell_px, wver FROM forecast WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        gew = st.execute("SELECT name, prior, weight, n, hit_rate FROM weights WHERE coin=? ORDER BY ABS(weight-prior) DESC", (coin,)).fetchall()
        lern = st.execute("SELECT key, updated FROM learned WHERE coin=?", (coin,)).fetchall()
        st.close()
    except sqlite3.Error as e:
        w(f"forecasts.db nicht lesbar: {e}")
        w()
        return
    w(f"Prognosen: {n:,} · {fen} Fenster à 15 min · letzte vor {ago(letzte)}")
    if row:
        f0 = lambda v: "—" if v is None else f"{v:,.0f}"
        w(f"Letzte: Kurs {f0(row['price'])} · Bias {row['bias'] if row['bias'] is None else format(row['bias'], '+.2f')} · Konfidenz "
          f"{'—' if row['confidence'] is None else format(row['confidence'], '.0%')}"
          f" · 24 h {f0(row['p_24h'])} · Kauf {f0(row['buy_px'])} · Verkauf {f0(row['sell_px'])}")
    sc = hl_forecast.score_forecasts(con, coin, store)
    def quote(v):
        return "—" if v is None else f"{v*100:.0f} %"
    def block(q):
        if not q or not q.get("n"):
            return "—"
        ci = f" ({q['ci'][0]*100:.0f}–{q['ci'][1]*100:.0f})" if q.get("ci") else ""
        bs = f" · Brier-Skill {q['brier_skill']*100:+.1f} %" if q.get("brier_skill") is not None else ""
        return f"{quote(q['hit_rate'])}{ci} · Basis {quote(q.get('base'))} · n_eff {q.get('n_eff')} ({q['n']} Fenster, {q.get('offen', 0)} offen){bs}"
    w(f"Trefferquote 4 h:  {block(sc.get('q4'))}")
    w(f"Trefferquote 24 h: {block(sc.get('q24'))}")
    w("  (Klammer = Wilson-Intervall auf n_eff, der Zahl unabhängiger Fälle; Basis = 'immer aufwärts/abwärts' in denselben Fenstern)")
    w(f"  Modell {quote((sc.get('model') or {}).get('hit_rate'))} (n={(sc.get('model') or {}).get('n')})"
      f" · Analog {quote((sc.get('analog') or {}).get('hit_rate'))} (n={(sc.get('analog') or {}).get('n')})"
      f" · out-of-sample {quote((sc.get('oos') or {}).get('hit_rate'))} (n={(sc.get('oos') or {}).get('n')})"
      f" · mittlerer Fehler 24 h {'—' if sc.get('mae_pct') is None else format(sc['mae_pct'], '.2f') + ' %'}")
    if gew:
        gelernt = [g for g in gew if abs((g["weight"] or 0) - (g["prior"] or 0)) > 0.02]
        w(f"Gewichte: {len(gelernt)} von {len(gew)} gelernt")
        for g in gew[:8]:
            w(f"  {g['name']:<28} {g['weight']:.2f} (Prior {g['prior']:.1f}) · n={g['n']}"
              f" · Treffer {quote(g['hit_rate'])}")
        for h in hl_forecast.LERN_HORIZONTE:
            m = hl_forecast.learned_cal_meta(coin, store, h)
            if m:
                w(f"  Spur {h} h: n_eff {m.get('n_eff')} ({m.get('n')} Fenster) · "
                  f"{'gelernt, β ' + str(m.get('beta')) + ', λ ' + str(m.get('lam')) if m.get('gelernt') else 'noch Prior (Lernen ab n_eff ' + str(m.get('min_n_eff')) + ')'}")
    if lern:
        w("Bausteine: " + " · ".join(f"{k} vor {ago(u)}" for k, u in lern))
    try:
        n_pts, alter = hl_forecast.series_age(con, coin)
        w(f"Kursreihe für Analog-Suche: {n_pts:,} Punkte à 30 min · letzter Punkt vor {ago(time.time() - alter)}"
          + ("  ← VERALTET" if alter > 4 * 3600 else ""))
    except Exception as e:
        w(f"Kursreihe: {type(e).__name__}: {e}")
    w()


def teil7_system(db: str, sekunden: int) -> None:
    w("=" * 70)
    w(" 7. SYSTEM")
    w("=" * 70)
    try:
        t = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        w(f"CPU-Temperatur: {int(t)/1000:.1f} °C")
    except OSError:
        w("CPU-Temperatur: nicht lesbar")
    thr = run(["vcgencmd", "get_throttled"], 5)
    if thr and "0x" in thr:
        v = int(re.search(r"0x([0-9a-fA-F]+)", thr).group(1), 16)
        flags = {0: "Unterspannung JETZT", 1: "Takt begrenzt JETZT", 2: "gedrosselt JETZT", 3: "Temperaturlimit JETZT",
                 16: "Unterspannung seit Start", 17: "Takt begrenzt seit Start", 18: "gedrosselt seit Start", 19: "Temperaturlimit seit Start"}
        aktiv = [n for b, n in flags.items() if v & (1 << b)]
        w(f"Drosselung: {thr.strip()} {'· ' + ', '.join(aktiv) if aktiv else '· keine'}")
    try:
        la = os.getloadavg()
        mem = open("/proc/meminfo").read()
        tot = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1)) * 1024
        avail = int(re.search(r"MemAvailable:\s+(\d+)", mem).group(1)) * 1024
        w(f"Last {la[0]:.2f}/{la[1]:.2f}/{la[2]:.2f} ({os.cpu_count()} Kerne) · RAM {avail/1e9:.2f} von {tot/1e9:.1f} GB frei"
          f" · Laufzeit {float(open('/proc/uptime').read().split()[0])/86400:.1f} Tage")
    except (OSError, AttributeError):
        pass
    w(run(["df", "-h", "/", os.path.dirname(os.path.abspath(db))], 10).replace("\n", "\n  "))
    w()


def teil8_journal() -> None:
    w("=" * 70)
    w(" 8. JOURNAL — Fehlerzeilen")
    w("=" * 70)
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        txt = run(["journalctl", "-u", s, "-n", "400", "--no-pager", "-o", "short-iso"], 25)
        if "No journal files" in txt or not txt:
            w(f"{s}: kein Journal lesbar (Gruppe systemd-journal fehlt?)")
            continue
        zeilen = [l for l in txt.splitlines()
                  if re.search(r"ABGESTÜRZT|Traceback|Error|FEHLER|nicht ladbar|fehlgeschlagen|Warn", l, re.I)]
        w(f"{s}: {len(zeilen)} auffällige von 400 Zeilen")
        for l in zeilen[-6:]:
            w("  " + l[:200])
    w()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=db_path())
    p.add_argument("--coin", default="BTC")
    p.add_argument("--minutes", type=float, default=1.0, help="Messfenster für den Zuwachs")
    a = p.parse_args()

    w("VOLLBERICHT hl_liq — zum Einfügen in den Chat")
    w()
    def sicher(fn, *args):
        """Ein Fehler in einem Teil darf den Bericht nicht abbrechen -- er gehört hinein."""
        try:
            return fn(*args)
        except Exception as e:
            import traceback
            tb = traceback.extract_tb(e.__traceback__)
            wo = f"{tb[-1].name}:{tb[-1].lineno}" if tb else "?"
            w(f"FEHLER in diesem Abschnitt: {type(e).__name__}: {e} (bei {wo})")
            w()
            return None

    sicher(teil1_umgebung)
    con = sicher(teil2_datenbank, a.db, a.minutes)
    if con is None:
        print("\n".join(OUT))
        return
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    stand = {}
    for t in tabs:
        try:
            stand[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            pass
    t_start = time.time()
    sicher(teil3_recorder, con)
    sicher(teil4_leaderboard, con, a.coin)
    sicher(teil5_wale, con, a.coin)
    sicher(teil5b_aktivitaet, con, a.coin)
    sicher(teil5c_coinbase, con, a.coin)
    sicher(teil6_prognose, con, a.coin)
    sicher(teil7_system, a.db, 0)
    # Zuwachs über ein echtes Zeitfenster: die übrigen Teile brauchen nur Sekunden,
    # in denen der Recorder kaum schreibt -- gemessen wird ab hier für --minutes.
    rest = a.minutes * 60 - (time.time() - t_start)
    if rest > 0:
        print(f"… messe {rest:.0f} s Zuwachs", file=sys.stderr, flush=True)
        time.sleep(rest)
    sicher(teil2b_zuwachs, con, stand, time.time() - t_start)
    sicher(teil2c_luecken, con)
    sicher(teil8_journal)
    con.close()
    w("=" * 70)
    w(" ENDE — bitte vollständig einfügen")
    print("\n".join(OUT))


if __name__ == "__main__":
    main()
