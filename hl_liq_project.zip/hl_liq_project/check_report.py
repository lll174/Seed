#!/usr/bin/env python3
"""
Vollbericht: alles, was zur Fehlersuche nötig ist, in einem Text.

  python3 check_report.py                  # Standard: Datenbank aus der systemd-Einheit
  python3 check_report.py --db /pfad.db --coin BTC --minutes 10

Sammelt in einem Durchgang:
  1. Umgebung     Version der Dateien, Python, Laufzeit, Dienste
  2. Datenbank    Größe, Tabellenstände, Zuwachs je Minute, letzter Eintrag je Strom
  3. Recorder     API-Gewicht, Poller-Zustand, Aufgabenfehler, Temperaturschutz, Backup
  4. Leaderboard  Konten, Positionen, Ereignisse, Fills, Trendzeilen
  5. Wale         Anzahl je Gruppe, Flow, letzte Ereignisse
  6. Prognose     Lernstand, Trefferquoten, Ablage, letzte Prognose
  7. System       Temperatur, CPU, Speicher, Schreiblast je Laufwerk
  8. Journal      die letzten Fehlerzeilen der drei Dienste

Der Text ist bewusst kompakt gehalten: Er soll sich vollständig in einen Chat einfügen
lassen. Keine Adressen im Klartext außer gekürzt, keine Schlüssel.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT: list[str] = []


def w(line: str = "") -> None:
    OUT.append(line)


def run(cmd: list[str], timeout: int = 20) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()
    except Exception as e:
        return f"({type(e).__name__}: {e})"


def unit_arg(flag: str, unit: str = "hl-recorder") -> str | None:
    try:
        m = re.search(rf"{flag}\s+(\S+)", Path(f"/etc/systemd/system/{unit}.service").read_text())
        return m.group(1) if m else None
    except OSError:
        return None


def db_path() -> str:
    return unit_arg("--db") or str(ROOT / "hl_liq.db")


def ago(ts) -> str:
    if not ts:
        return "—"
    d = time.time() - float(ts)
    return f"{d/60:.0f} min" if d < 7200 else f"{d/3600:.1f} h" if d < 172800 else f"{d/86400:.1f} T"


def fmt(n) -> str:
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "—"
    for grenze, einheit in ((1e9, "Mrd"), (1e6, "Mio"), (1e3, "k")):
        if abs(n) >= grenze:
            return f"{n/grenze:,.1f} {einheit}"
    return f"{n:,.0f}"


def short(a: str) -> str:
    return f"{a[:6]}…{a[-4:]}" if isinstance(a, str) and len(a) > 12 else str(a)


# ---------------------------------------------------------------------------

def teil1_umgebung() -> None:
    w("=" * 70)
    w(" 1. UMGEBUNG")
    w("=" * 70)
    w(f"Bericht {time.strftime('%d.%m.%Y %H:%M:%S')} · Python {sys.version.split()[0]} · Ordner {ROOT}")
    files = sorted(p for p in ROOT.glob("*.py"))
    zeilen = []
    for p in files:
        try:
            zeilen.append(f"{p.name} {p.stat().st_size//1024}k {time.strftime('%d.%m. %H:%M', time.localtime(p.stat().st_mtime))}")
        except OSError:
            pass
    w("Dateien: " + " · ".join(zeilen))
    log = ROOT / "updates" / "last_update.log"
    if log.exists():
        txt = log.read_text(errors="replace").strip().splitlines()
        w(f"Letztes Update: {time.strftime('%d.%m. %H:%M', time.localtime(log.stat().st_mtime))} · "
          f"{'erfolgreich' if any('Fertig' in l for l in txt) else 'ABGEBROCHEN?'} · {len(txt)} Zeilen")
        fehler = [l.strip() for l in txt if "FEHLER" in l or "Traceback" in l]
        if fehler:
            w("  Fehler im Update: " + " | ".join(fehler[:3])[:300])
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        st = run(["systemctl", "is-active", s], 5) or "?"
        if "not been booted" in st or "Failed to connect" in st:
            w("Dienste: systemd nicht verfügbar (Testumgebung)")
            break
        since = run(["systemctl", "show", s, "--property=ActiveEnterTimestamp", "--value"], 5)
        mem = run(["systemctl", "show", s, "--property=MemoryCurrent", "--value"], 5)
        restarts = run(["systemctl", "show", s, "--property=NRestarts", "--value"], 5)
        try:
            mem = f"{int(mem)/1e6:.0f} MB"
        except ValueError:
            mem = "—"
        w(f"Dienst {s:<14} {st:<10} seit {since[:25] or '—'} · Speicher {mem} · Neustarts {restarts or '—'}")
    w()


def teil2_datenbank(db: str, minutes: int) -> sqlite3.Connection | None:
    w("=" * 70)
    w(" 2. DATENBANK")
    w("=" * 70)
    if not os.path.exists(db):
        w(f"FEHLT: {db}")
        w()
        return None
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)
    con.row_factory = sqlite3.Row
    wal = db + "-wal"
    w(f"{db} · {os.path.getsize(db)/1e9:.2f} GB · WAL {os.path.getsize(wal)/1e6:.1f} MB"
      if os.path.exists(wal) else f"{db} · {os.path.getsize(db)/1e9:.2f} GB")
    try:
        u = shutil.disk_usage(os.path.dirname(os.path.abspath(db)))
        w(f"Medium: {u.free/1e9:.1f} GB frei von {u.total/1e9:.0f} GB")
    except OSError:
        pass
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    stand1 = {}
    for t in tabs:
        try:
            stand1[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            stand1[t] = -1
    # jüngster Eintrag je Strom
    w(f"{'Tabelle':<18} {'Zeilen':>12}  letzter Eintrag")
    for t in tabs:
        letzte = "—"
        try:
            cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
            if "ts" in cols:
                ts = con.execute(f'SELECT MAX(ts) FROM "{t}"').fetchone()[0]
                if ts:
                    ts = ts / 1000 if ts > 4e12 else ts
                    letzte = f"vor {ago(ts)}"
        except sqlite3.Error:
            pass
        if stand1[t] or letzte != "—":
            w(f"{t:<18} {stand1[t]:>12,}  {letzte}")
    return con


def teil2b_zuwachs(con, stand_vorher: dict, sekunden: float) -> None:
    w()
    w(f"Zuwachs in {sekunden:.0f} s (hochgerechnet auf eine Stunde):")
    zeilen = []
    for t, n0 in stand_vorher.items():
        try:
            n1 = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            continue
        if n1 > n0:
            zeilen.append((int((n1 - n0) * 3600 / max(sekunden, 1)), t, n1 - n0))
    zeilen.sort(reverse=True)
    w("  " + (" · ".join(f"{t} +{pro_h:,}/h" for pro_h, t, _ in zeilen[:12]) if zeilen else "keine Tabelle gewachsen — Recorder aktiv?"))
    w()


def teil3_recorder(con) -> None:
    w("=" * 70)
    w(" 3. RECORDER")
    w("=" * 70)
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
    except sqlite3.Error:
        w("meta nicht lesbar")
        w()
        return
    alive = int(meta.get("recorder_alive") or 0)
    w(f"Lebenszeichen: {'vor ' + ago(alive) if alive else 'FEHLT (alte Version oder Recorder aus)'}"
      f" · Start {meta.get('started', '—')}")
    used, budget = int(meta.get("api_weight_1m") or 0), int(meta.get("api_weight_budget") or 1200)
    w(f"API-Gewicht: {used}/{budget} ({used/max(budget,1)*100:.0f} %) · Stand vor {ago(meta.get('api_weight_ts'))}"
      f" · 429er: {meta.get('rate_limited', 0)}")
    pb, pw = int(meta.get("poller_batch") or 0), int(meta.get("poller_want") or 0)
    w(f"Poller: {pb}/{pw} je Runde {'(voll)' if pw and pb >= pw else '(NICHT VOLL — zu wenige fällige Adressen)' if pw else ''}"
      f" · fällig: {meta.get('poller_due_a','?')} mit Position, {meta.get('poller_due_b','?')} neu, {meta.get('poller_due_c','?')} leer"
      f" · {int(meta.get('addr_total') or 0):,} Adressen")
    lvl = int(meta.get("thermal_level") or 0)
    w(f"Temperaturschutz: {'Stufe ' + str(lvl) if lvl else 'inaktiv'} · {meta.get('thermal_temp','—')} °C"
      f" · Gewicht x{meta.get('thermal_weight_factor','1')} · Takte x{meta.get('thermal_interval_factor','1')}")
    try:
        te = json.loads(meta.get("task_errors") or "{}")
    except ValueError:
        te = {}
    if te:
        w("AUFGABEN-ABSTÜRZE:")
        for k, v in te.items():
            w(f"  {k}: {v.get('count')}x · zuletzt vor {ago(v.get('ts'))} · {str(v.get('error'))[:150]}")
    else:
        w("Aufgaben: keine Abstürze vermerkt")
    bdir = meta.get("backup_dir") or str(ROOT / "dbbackup")
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            b = json.load(f)
        w(f"Backup: {'ok' if b.get('ok') else 'FEHLGESCHLAGEN: ' + str(b.get('error'))[:80]}"
          f" · vor {ago(b.get('ts'))} · {fmt(b.get('size'))} B · Ordner {bdir}")
    except (OSError, ValueError):
        w(f"Backup: keine backup.json in {bdir}")
    w()


def teil4_leaderboard(con, coin: str) -> None:
    w("=" * 70)
    w(f" 4. LEADERBOARD ({coin})")
    w("=" * 70)
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.Error:
        w("Tabellen fehlen — Recorder-Version zu alt?")
        w()
        return
    if not last:
        w("noch kein Durchgang")
        w()
        return
    n_acc = con.execute("SELECT COUNT(*) FROM lb_accounts WHERE ts=?", (last,)).fetchone()[0]
    n_pos = con.execute("SELECT COUNT(*) FROM lb_positions WHERE ts=?", (last,)).fetchone()[0]
    n_cyc = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_accounts").fetchone()[0]
    w(f"Letzter Durchgang vor {ago(last)} · {n_acc} Konten · {n_pos} Positionen · {n_cyc} Durchgänge gesamt")
    luecke = con.execute("SELECT COUNT(*) FROM lb_trend WHERE coin=? AND top_n=20", (coin,)).fetchone()[0]
    letzte_trend = con.execute("SELECT MAX(ts) FROM lb_trend WHERE coin=?", (coin,)).fetchone()[0]
    w(f"Trendzeilen {coin}: {luecke} · letzte vor {ago(letzte_trend)}")
    for tab, label in (("lb_events", "Ereignisse"), ("lb_fills", "Fills"), ("lb_spot", "Spot-Bestände")):
        try:
            n = con.execute(f"SELECT COUNT(*) FROM {tab}").fetchone()[0]
            letzte = con.execute(f"SELECT MAX(ts) FROM {tab}").fetchone()[0]
            extra = ""
            if tab == "lb_events":
                h1 = con.execute("SELECT COUNT(*) FROM lb_events WHERE coin=? AND ts>=?", (coin, int(time.time()) - 3600)).fetchone()[0]
                extra = f" · letzte Stunde in {coin}: {h1}"
            w(f"{label}: {n:,} · letzter vor {ago(letzte)}{extra}")
        except sqlite3.Error:
            w(f"{label}: Tabelle fehlt")
    try:
        rows = con.execute("""SELECT event, side, COUNT(*) n, ROUND(SUM(delta_usd)) s FROM lb_events
                              WHERE coin=? AND ts>=? GROUP BY event, side""", (coin, int(time.time()) - 6 * 3600)).fetchall()
        if rows:
            w("Ereignisse 6 h: " + " · ".join(f"{r['event']} {r['side']} {r['n']}x {fmt(r['s'])}" for r in rows))
    except sqlite3.Error:
        pass
    w()


def teil5_wale(con, coin: str) -> None:
    w("=" * 70)
    w(f" 5. WALE ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_viz
        d = hl_viz.load_whales(con, coin, 72)
    except Exception as e:
        w(f"load_whales fehlgeschlagen: {type(e).__name__}: {e}")
        w()
        return
    F = d.get("flow") or {}
    w(f"Konten je Gruppe: {F.get('sizes')} · erfasst {F.get('n_total')} · direktional {F.get('n_directional')}")
    for g, name in (F.get("group_names") or {}).items():
        gf = (F.get("groups") or {}).get(g)
        if not gf:
            continue
        a30, a60 = gf["w30"], gf["w60"]
        w(f"  {name:<14} 30 min netto {fmt(a30['net_usd']):>10} ({a30['n_buy']}/{a30['n_sell']})"
          f" · 60 min {fmt(a60['net_usd']):>10} ({a60['n_buy']}/{a60['n_sell']})"
          f" · Z30 {'—' if gf.get('z30') is None else round(gf['z30'], 1)}"
          f"{' · EREIGNIS' if gf.get('event_signal') else ''}")
    D = d.get("directional") or {}
    if D:
        w(f"Bestand direktional: {D.get('n_long')} long {fmt(D.get('usd_long'))} gegen {D.get('n_short')} short {fmt(D.get('usd_short'))}")
    ev = list(reversed((d.get("events") or [])[-8:]))       # die NEUESTEN acht, neueste zuerst
    if ev:
        w("Letzte Änderungen:")
        for e in ev:
            grp = (F.get("per_coin") or {}).get(str(e.get("addr", "")).lower(), "?")
            w(f"  {time.strftime('%d.%m %H:%M', time.localtime(e['ts']))} {short(e['addr'])} {e['event']} {e['side']}"
              f" {fmt(e.get('delta_usd'))} [{grp}]")
    w()


def teil6_prognose(con, coin: str) -> None:
    w("=" * 70)
    w(f" 6. PROGNOSE UND LERNSTAND ({coin})")
    w("=" * 70)
    try:
        sys.path.insert(0, str(ROOT))
        import hl_forecast
    except Exception as e:
        w(f"hl_forecast nicht ladbar: {e}")
        w()
        return
    store = hl_forecast.STORE
    w(f"Ablage: {store} ({os.path.getsize(store)/1e6:.1f} MB)" if os.path.exists(store) else f"Ablage: {store} (fehlt)")
    try:
        st = hl_forecast.store_connect(store)
        st.row_factory = sqlite3.Row
        n = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        fen = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        letzte = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        row = st.execute("SELECT ts, price, bias, confidence, p_24h, buy_px, sell_px, wver FROM forecast WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        gew = st.execute("SELECT name, prior, weight, n, hit_rate FROM weights WHERE coin=? ORDER BY ABS(weight-prior) DESC", (coin,)).fetchall()
        lern = st.execute("SELECT key, updated FROM learned WHERE coin=?", (coin,)).fetchall()
        st.close()
    except sqlite3.Error as e:
        w(f"forecasts.db nicht lesbar: {e}")
        w()
        return
    w(f"Prognosen: {n:,} · {fen} Fenster à 15 min · letzte vor {ago(letzte)}")
    if row:
        w(f"Letzte: Kurs {row['price']:,.0f} · Bias {row['bias']:+.2f} · Konfidenz {row['confidence']:.0%}"
          f" · 24 h {row['p_24h']:,.0f} · Kauf {row['buy_px']:,.0f} · Verkauf {row['sell_px']:,.0f}")
    sc = hl_forecast.score_forecasts(con, coin, store)
    def quote(v):
        return "—" if v is None else f"{v*100:.0f} %"
    w(f"Trefferquote 24 h: {quote(sc.get('hit_rate'))} (n={sc.get('n')}) · 4 h: {quote(sc.get('hit_rate_4h'))} (n={sc.get('n_4h')})")
    w(f"  Modell {quote((sc.get('model') or {}).get('hit_rate'))} (n={(sc.get('model') or {}).get('n')})"
      f" · Analog {quote((sc.get('analog') or {}).get('hit_rate'))} (n={(sc.get('analog') or {}).get('n')})"
      f" · out-of-sample {quote((sc.get('oos') or {}).get('hit_rate'))} (n={(sc.get('oos') or {}).get('n')})"
      f" · mittlerer Fehler 24 h {'—' if sc.get('mae_pct') is None else format(sc['mae_pct'], '.2f') + ' %'}")
    if gew:
        gelernt = [g for g in gew if abs((g["weight"] or 0) - (g["prior"] or 0)) > 0.02]
        w(f"Gewichte: {len(gelernt)} von {len(gew)} gelernt")
        for g in gew[:8]:
            w(f"  {g['name']:<28} {g['weight']:.2f} (Prior {g['prior']:.1f}) · n={g['n']}"
              f" · Treffer {quote(g['hit_rate'])}")
    if lern:
        w("Bausteine: " + " · ".join(f"{k} vor {ago(u)}" for k, u in lern))
    try:
        n_pts, alter = hl_forecast.series_age(con, coin)
        w(f"Kursreihe für Analog-Suche: {n_pts:,} Punkte à 30 min · letzter Punkt vor {ago(time.time() - alter)}"
          + ("  ← VERALTET" if alter > 4 * 3600 else ""))
    except Exception as e:
        w(f"Kursreihe: {type(e).__name__}: {e}")
    w()


def teil7_system(db: str, sekunden: int) -> None:
    w("=" * 70)
    w(" 7. SYSTEM")
    w("=" * 70)
    try:
        t = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        w(f"CPU-Temperatur: {int(t)/1000:.1f} °C")
    except OSError:
        w("CPU-Temperatur: nicht lesbar")
    thr = run(["vcgencmd", "get_throttled"], 5)
    if thr and "0x" in thr:
        v = int(re.search(r"0x([0-9a-fA-F]+)", thr).group(1), 16)
        flags = {0: "Unterspannung JETZT", 1: "Takt begrenzt JETZT", 2: "gedrosselt JETZT", 3: "Temperaturlimit JETZT",
                 16: "Unterspannung seit Start", 17: "Takt begrenzt seit Start", 18: "gedrosselt seit Start", 19: "Temperaturlimit seit Start"}
        aktiv = [n for b, n in flags.items() if v & (1 << b)]
        w(f"Drosselung: {thr.strip()} {'· ' + ', '.join(aktiv) if aktiv else '· keine'}")
    try:
        la = os.getloadavg()
        mem = open("/proc/meminfo").read()
        tot = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1)) * 1024
        avail = int(re.search(r"MemAvailable:\s+(\d+)", mem).group(1)) * 1024
        w(f"Last {la[0]:.2f}/{la[1]:.2f}/{la[2]:.2f} ({os.cpu_count()} Kerne) · RAM {avail/1e9:.2f} von {tot/1e9:.1f} GB frei"
          f" · Laufzeit {float(open('/proc/uptime').read().split()[0])/86400:.1f} Tage")
    except (OSError, AttributeError):
        pass
    w(run(["df", "-h", "/", os.path.dirname(os.path.abspath(db))], 10).replace("\n", "\n  "))
    w()


def teil8_journal() -> None:
    w("=" * 70)
    w(" 8. JOURNAL — Fehlerzeilen")
    w("=" * 70)
    for s in ("hl-recorder", "hl-dashboard", "hl-binance"):
        txt = run(["journalctl", "-u", s, "-n", "400", "--no-pager", "-o", "short-iso"], 25)
        if "No journal files" in txt or not txt:
            w(f"{s}: kein Journal lesbar (Gruppe systemd-journal fehlt?)")
            continue
        zeilen = [l for l in txt.splitlines()
                  if re.search(r"ABGESTÜRZT|Traceback|Error|FEHLER|nicht ladbar|fehlgeschlagen|Warn", l, re.I)]
        w(f"{s}: {len(zeilen)} auffällige von 400 Zeilen")
        for l in zeilen[-6:]:
            w("  " + l[:200])
    w()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=db_path())
    p.add_argument("--coin", default="BTC")
    p.add_argument("--minutes", type=float, default=1.0, help="Messfenster für den Zuwachs")
    a = p.parse_args()

    w("VOLLBERICHT hl_liq — zum Einfügen in den Chat")
    w()
    def sicher(fn, *args):
        """Ein Fehler in einem Teil darf den Bericht nicht abbrechen -- er gehört hinein."""
        try:
            return fn(*args)
        except Exception as e:
            import traceback
            tb = traceback.extract_tb(e.__traceback__)
            wo = f"{tb[-1].name}:{tb[-1].lineno}" if tb else "?"
            w(f"FEHLER in diesem Abschnitt: {type(e).__name__}: {e} (bei {wo})")
            w()
            return None

    sicher(teil1_umgebung)
    con = sicher(teil2_datenbank, a.db, a.minutes)
    if con is None:
        print("\n".join(OUT))
        return
    tabs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    stand = {}
    for t in tabs:
        try:
            stand[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            pass
    t_start = time.time()
    sicher(teil3_recorder, con)
    sicher(teil4_leaderboard, con, a.coin)
    sicher(teil5_wale, con, a.coin)
    sicher(teil6_prognose, con, a.coin)
    sicher(teil7_system, a.db, 0)
    # Zuwachs über ein echtes Zeitfenster: die übrigen Teile brauchen nur Sekunden,
    # in denen der Recorder kaum schreibt -- gemessen wird ab hier für --minutes.
    rest = a.minutes * 60 - (time.time() - t_start)
    if rest > 0:
        print(f"… messe {rest:.0f} s Zuwachs", file=sys.stderr, flush=True)
        time.sleep(rest)
    sicher(teil2b_zuwachs, con, stand, time.time() - t_start)
    sicher(teil8_journal)
    con.close()
    w("=" * 70)
    w(" ENDE — bitte vollständig einfügen")
    print("\n".join(OUT))


if __name__ == "__main__":
    main()
