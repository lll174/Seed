#!/usr/bin/env python3
"""
hl_recorder.py — Zeichnet Hyperliquid-Liquidationscluster live auf und labelt sie.

Warum: Historische Positionsdaten gibt es öffentlich nicht. Wer testen will, ob
Liquidationscluster Vorhersagekraft haben, muss selbst vorwärts aufzeichnen.

Wie es funktioniert:
  1. WebSocket 'trades' liefert zu jedem Trade die beteiligten Wallet-Adressen
     -> daraus wächst über die Zeit ein Adressregister.
  2. 'clearinghouseState' pro Adresse liefert offene Positionen inkl. echtem
     liquidationPx -> keine Schätzung wie bei CEX-Heatmaps.
  3. Alle Liquidationspreise werden in Preis-Buckets aggregiert -> Heatmap.
  4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit später
     Forward-Returns berechnet werden können.
  5. Echte Liquidations-Fills (Feld 'liquidation' im Trade) werden separat geloggt.

Modi:
    python hl_recorder.py --coins BTC ETH HYPE          # aufzeichnen
    python hl_recorder.py --simulate                    # Testdaten erzeugen
    python hl_recorder.py --analyze --coin BTC          # Cluster-Events labeln
    python hl_recorder.py --status                      # DB-Überblick

Abhängigkeiten: pip install websockets aiohttp pandas numpy
"""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import os
import random
import signal
import sqlite3
import sys
import time
from collections import defaultdict
from dataclasses import dataclass

API = "https://api.hyperliquid.xyz/info"
WS = "wss://api.hyperliquid.xyz/ws"
DB_PATH = "hl_liq.db"

# clearinghouseState hat Rate-Limit-Gewicht 2; das IP-Budget liegt bei 1200/min.
# Wir bleiben bewusst deutlich darunter, um Platz für andere Requests zu lassen.
DEFAULT_POLLS_PER_MIN = 240


# ---------------------------------------------------------------------------
# Datenbank
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS addresses (
    addr        TEXT PRIMARY KEY,
    first_seen  INTEGER,
    last_trade  INTEGER,
    last_poll   INTEGER DEFAULT 0,
    notional    REAL    DEFAULT 0,   -- letzte bekannte Positionsgröße, steuert Poll-Priorität
    misses      INTEGER DEFAULT 0,   -- Polls ohne offene Position
    dexes       TEXT    DEFAULT ''   -- Perp-Dexe, auf denen die Adresse handelt
);
CREATE INDEX IF NOT EXISTS ix_addr_poll ON addresses(last_poll);

-- Aggregierte Heatmap: das primäre Trainingsdatum
CREATE TABLE IF NOT EXISTS heatmap (
    ts          INTEGER,
    coin        TEXT,
    bucket_px   REAL,
    side        TEXT,     -- 'long' = Long-Liquidationen (unter Kurs), 'short' = darüber
    notional    REAL,
    n_pos       INTEGER,
    PRIMARY KEY (ts, coin, bucket_px, side)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_heat_coin_ts ON heatmap(coin, ts);

-- 1-Minuten-Bars aus dem Trade-Feed, für Forward-Returns
CREATE TABLE IF NOT EXISTS bars (
    ts      INTEGER,
    coin    TEXT,
    open    REAL, high REAL, low REAL, close REAL,
    volume  REAL,
    trades  INTEGER,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Tatsächlich eingetretene Liquidationen
CREATE TABLE IF NOT EXISTS liquidations (
    ts        INTEGER,
    coin      TEXT,
    user      TEXT,
    method    TEXT,
    mark_px   REAL,
    px        REAL,
    sz        REAL,
    side      TEXT,
    tid       INTEGER PRIMARY KEY
);
CREATE INDEX IF NOT EXISTS ix_liq_coin_ts ON liquidations(coin, ts);

-- Ergebnis des Analyse-Laufs
CREATE TABLE IF NOT EXISTS cluster_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              INTEGER,
    coin            TEXT,
    cluster_px      REAL,
    side            TEXT,
    notional        REAL,
    notional_x_vol  REAL,   -- Cluster relativ zum 1h-Volumen: der eigentliche Schwellenwert
    dist_pct        REAL,   -- Abstand bei Erkennung
    px_at_touch     REAL,
    fwd_1h          REAL, fwd_4h REAL, fwd_24h REAL,
    max_up_4h       REAL, max_dn_4h REAL,
    penetrated      INTEGER, -- wurde das Cluster durchlaufen?
    liq_notional_1h REAL     -- tatsächlich liquidiertes Volumen danach
);

CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


def db_connect(path: str = DB_PATH, synchronous: str = "NORMAL") -> sqlite3.Connection:
    con = sqlite3.connect(path, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute(f"PRAGMA synchronous={synchronous}")
    con.executescript(SCHEMA)
    # Migration älterer Datenbanken
    cols = {r[1] for r in con.execute("PRAGMA table_info(addresses)")}
    if "dexes" not in cols:
        con.execute("ALTER TABLE addresses ADD COLUMN dexes TEXT DEFAULT ''")
        con.commit()
    return con


# ---------------------------------------------------------------------------
# Rate-Limiter
# ---------------------------------------------------------------------------

class RateLimiter:
    """Token-Bucket. Kapazität in Requests pro Minute."""

    def __init__(self, per_min: int):
        self.rate = per_min / 60.0
        self.capacity = max(per_min / 6.0, 5.0)
        self.tokens = self.capacity
        self.last = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            while True:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.last) * self.rate)
                self.last = now
                if self.tokens >= 1:
                    self.tokens -= 1
                    return
                await asyncio.sleep((1 - self.tokens) / self.rate)


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------

@dataclass
class Settings:
    coins: list[str]  # Klarnamen, Symbole werden aufgelöst
    bucket_pct: float = 0.0025      # Bucket-Breite = 0.25 % des Kurses
    snapshot_sec: int = 600         # Heatmap alle 10 Minuten schreiben
    flush_sec: int = 10             # Commit-Takt: begrenzt den Verlust bei Stromausfall
    synchronous: str = "NORMAL"     # FULL = jeder Commit sofort auf Platte
    polls_per_min: int = DEFAULT_POLLS_PER_MIN
    max_addresses: int = 20_000
    hot_notional: float = 50_000    # ab hier gilt eine Adresse als "groß"
    hot_refresh: int = 180          # große Positionen alle 3 min
    cold_refresh: int = 1800        # kleine alle 30 min
    drop_after_misses: int = 5      # Adresse ohne Position mehrfach -> selten pollen


class Recorder:
    def __init__(self, con: sqlite3.Connection, cfg: Settings):
        self.con = con
        self.cfg = cfg
        self.limiter = RateLimiter(cfg.polls_per_min)
        self.positions: dict[str, list[dict]] = {}   # addr -> offene Positionen
        self.bars: dict[tuple[int, str], dict] = {}  # (minute, coin) -> OHLCV
        self.mid: dict[str, float] = {}
        self.symbol_of: dict[str, str] = {}          # BTC -> BTC, XMR -> felix:XMR
        self.coin_of: dict[str, str] = {}            # Symbol -> Klarname
        self.dex_of: dict[str, str] = {}             # Symbol -> Dex ("" = Standard)
        self.dexes: list[str] = [""]
        self.addr_dex: dict[str, set[str]] = {}      # Adresse -> gesehene Dexe
        self.stop = asyncio.Event()
        self.stats = defaultdict(int)
        self.session = None

    # -- HTTP ---------------------------------------------------------------

    async def post(self, payload: dict, weighted: bool = True) -> dict | list | None:
        import aiohttp
        if weighted:
            await self.limiter.acquire()
        for attempt in range(3):
            try:
                async with self.session.post(API, json=payload, timeout=aiohttp.ClientTimeout(total=20)) as r:
                    if r.status == 429:
                        self.stats["rate_limited"] += 1
                        await asyncio.sleep(2 + attempt * 3)
                        continue
                    r.raise_for_status()
                    return await r.json()
            except Exception:
                self.stats["http_error"] += 1
                await asyncio.sleep(1 + attempt * 2)
        return None

    # -- WebSocket: Trades, Adressen, Bars, Liquidationen --------------------

    async def resolve_symbols(self) -> None:
        """
        Ordnet jedem gewünschten Coin sein Handelssymbol und seinen Perp-Dex zu.

        Der Standard-Dex nutzt schlichte Namen ("BTC"). HIP-3-Märkte wie XMR
        laufen auf einem eigenen Dex und tragen dessen Namen als Präfix
        ("felix:XMR"). Wichtiger noch: Positionen auf einem HIP-3-Dex erscheinen
        nur, wenn clearinghouseState mit dem passenden dex-Parameter abgefragt
        wird — sonst fehlen sie vollständig.
        """
        wanted = {c.upper() for c in self.cfg.coins}
        found: dict[str, tuple[str, str]] = {}   # coin -> (symbol, dex)

        # Standard-Dex
        meta = await self.post({"type": "meta"}, weighted=False)
        for a in (meta or {}).get("universe", []):
            name = str(a.get("name", "")).upper()
            if name in wanted:
                found[name] = (a["name"], "")

        # HIP-3-Dexe durchsuchen, falls noch etwas fehlt
        if len(found) < len(wanted):
            dexs = await self.post({"type": "perpDexs"}, weighted=False)
            for d in (dexs or []):
                if not isinstance(d, dict) or not d.get("name"):
                    continue          # erster Eintrag ist der Standard-Dex (null)
                dex = d["name"]
                m = await self.post({"type": "meta", "dex": dex}, weighted=False)
                for a in (m or {}).get("universe", []):
                    short = str(a.get("name", "")).split(":")[-1].upper()
                    if short in wanted and short not in found:
                        sym = a["name"] if ":" in str(a["name"]) else f"{dex}:{a['name']}"
                        found[short] = (sym, dex)
                if len(found) == len(wanted):
                    break

        for coin in sorted(wanted):
            if coin in found:
                sym, dex = found[coin]
                self.symbol_of[coin] = sym
                self.coin_of[sym] = coin
                self.dex_of[sym] = dex
                tag = f"HIP-3 auf '{dex}'" if dex else "Standard-Dex"
                print(f"  {coin:<6} -> {sym:<18} ({tag})")
            else:
                print(f"  {coin:<6} -> nicht gefunden, wird übersprungen")

        self.dexes = sorted({d for d in self.dex_of.values()})
        if len(self.dexes) > 1:
            print(f"  Hinweis: {len(self.dexes)} Perp-Dexe. Adressen, die auf "
                  "mehreren handeln, brauchen entsprechend mehr Abfragen.")

    async def run_ws(self) -> None:
        import websockets
        backoff = 1
        while not self.stop.is_set():
            try:
                async with websockets.connect(WS, ping_interval=20, max_size=2**23) as ws:
                    symbols = list(self.symbol_of.values()) or self.cfg.coins
                    for sym in symbols:
                        await ws.send(json.dumps({
                            "method": "subscribe",
                            "subscription": {"type": "trades", "coin": sym},
                        }))
                    print(f"WS verbunden, {len(symbols)} Feeds abonniert.")
                    backoff = 1
                    while not self.stop.is_set():
                        raw = await asyncio.wait_for(ws.recv(), timeout=90)
                        msg = json.loads(raw)
                        if msg.get("channel") == "trades":
                            for t in msg.get("data", []):
                                self.on_trade(t)
            except asyncio.TimeoutError:
                print("WS still, reconnect …")
            except Exception as e:
                if not self.stop.is_set():
                    print(f"WS-Fehler: {e} — reconnect in {backoff}s")
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 60)

    def on_trade(self, t: dict) -> None:
        symbol = t.get("coin")
        # HIP-3-Symbole ("felix:XMR") auf den Klarnamen normalisieren, damit
        # Bars und Heatmap denselben Schlüssel benutzen.
        coin = self.coin_of.get(symbol) or str(symbol).split(":")[-1]
        dex = self.dex_of.get(symbol, "")
        try:
            px, sz = float(t["px"]), float(t["sz"])
            ts = int(t["time"])
        except (KeyError, TypeError, ValueError):
            return

        self.mid[coin] = px
        self.stats["trades"] += 1

        # 1-Minuten-Bar fortschreiben
        minute = ts // 60_000 * 60
        key = (minute, coin)
        b = self.bars.get(key)
        if b is None:
            self.bars[key] = {"o": px, "h": px, "l": px, "c": px, "v": sz, "n": 1}
        else:
            b["h"] = max(b["h"], px); b["l"] = min(b["l"], px)
            b["c"] = px; b["v"] += sz; b["n"] += 1

        # Adressen einsammeln, inklusive des Dex, auf dem sie gehandelt haben
        for addr in (t.get("users") or []):
            if isinstance(addr, str) and addr.startswith("0x"):
                self.seen_address(addr, ts, dex)

        # Echte Liquidation?
        liq = t.get("liquidation")
        if liq:
            self.stats["liquidations"] += 1
            try:
                self.con.execute(
                    "INSERT OR IGNORE INTO liquidations VALUES (?,?,?,?,?,?,?,?,?)",
                    (ts, coin, liq.get("liquidatedUser"), liq.get("method"),
                     float(liq.get("markPx") or 0), px, sz, t.get("side"), int(t.get("tid", 0))),
                )
            except Exception:
                pass

    def seen_address(self, addr: str, ts: int, dex: str = "") -> None:
        known = self.addr_dex.setdefault(addr, set())
        known.add(dex)
        self.con.execute(
            "INSERT INTO addresses(addr, first_seen, last_trade, dexes) VALUES (?,?,?,?) "
            "ON CONFLICT(addr) DO UPDATE SET last_trade=excluded.last_trade, "
            "dexes=excluded.dexes",
            (addr, ts, ts, ",".join(sorted(known))),
        )

    # -- Positions-Polling ---------------------------------------------------

    def due_addresses(self, limit: int) -> list[str]:
        """Große Positionen häufig, kleine selten, tote fast nie."""
        now = int(time.time())
        c = self.cfg
        rows = self.con.execute(
            """
            SELECT addr FROM addresses
            WHERE (? - last_poll) > CASE
                WHEN misses >= ?            THEN ?
                WHEN notional >= ?          THEN ?
                ELSE ?
            END
            ORDER BY notional DESC, last_poll ASC
            LIMIT ?
            """,
            (now, c.drop_after_misses, c.cold_refresh * 4,
             c.hot_notional, c.hot_refresh, c.cold_refresh, limit),
        ).fetchall()
        return [r[0] for r in rows]

    async def poll_address(self, addr: str) -> None:
        now = int(time.time())
        # Nur die Dexe abfragen, auf denen die Adresse tatsächlich gehandelt hat.
        dexes = self.addr_dex.get(addr) or {""}
        out, total, any_response = [], 0.0, False

        for dex in sorted(dexes):
            req = {"type": "clearinghouseState", "user": addr}
            if dex:
                req["dex"] = dex
            data = await self.post(req)
            if data is None:
                continue
            any_response = True

            for ap in data.get("assetPositions", []):
                p = ap.get("position", {})
                liq = p.get("liquidationPx")
                szi = p.get("szi")
                if liq is None or szi is None:
                    continue                     # z. B. unhebelte Position
                try:
                    liq_px, size = float(liq), float(szi)
                except (TypeError, ValueError):
                    continue
                if liq_px <= 0 or size == 0:
                    continue
                notional = abs(size) * liq_px
                raw = str(p.get("coin", ""))
                out.append({
                    "coin": self.coin_of.get(raw) or raw.split(":")[-1],
                    "size": size,
                    "liq_px": liq_px,
                    "notional": notional,
                    "side": "long" if size > 0 else "short",
                })
                total += notional
            self.stats["polls"] += 1

        if not any_response:
            self.con.execute("UPDATE addresses SET last_poll=? WHERE addr=?", (now, addr))
            return

        if out:
            self.positions[addr] = out
            self.con.execute(
                "UPDATE addresses SET last_poll=?, notional=?, misses=0 WHERE addr=?",
                (now, total, addr))
        else:
            self.positions.pop(addr, None)
            self.con.execute(
                "UPDATE addresses SET last_poll=?, notional=0, misses=misses+1 WHERE addr=?",
                (now, addr))

    async def run_poller(self) -> None:
        while not self.stop.is_set():
            batch = self.due_addresses(max(int(self.cfg.polls_per_min / 4), 10))
            if not batch:
                await asyncio.sleep(5)
                continue
            await asyncio.gather(*(self.poll_address(a) for a in batch))
            self.con.commit()

    # -- Snapshots -----------------------------------------------------------

    def bucket_of(self, liq_px: float) -> float:
        """
        Logarithmisches Preisraster: die Bucket-Grenzen sind über die Zeit
        stabil, unabhängig davon, wo der Kurs gerade steht. Ohne das würde
        das Raster mit dem Kurs mitwandern und Snapshots wären nicht
        vergleichbar.
        """
        step = math.log1p(self.cfg.bucket_pct)
        return round(math.exp(round(math.log(liq_px) / step) * step), 8)

    def write_snapshot(self) -> None:
        """Aggregiert alle bekannten Liquidationspreise in Preis-Buckets."""
        now = int(time.time())
        agg: dict[tuple[str, float, str], list[float]] = defaultdict(lambda: [0.0, 0])

        for positions in self.positions.values():
            for p in positions:
                if p["liq_px"] <= 0:
                    continue
                cell = agg[(p["coin"], self.bucket_of(p["liq_px"]), p["side"])]
                cell[0] += p["notional"]
                cell[1] += 1

        if agg:
            self.con.executemany(
                "INSERT OR REPLACE INTO heatmap VALUES (?,?,?,?,?,?)",
                [(now, coin, bx, side, v[0], v[1]) for (coin, bx, side), v in agg.items()],
            )

        self.flush_bars()
        self.con.commit()

    def poll_lag(self) -> dict:
        """
        Wie aktuell sind die gespeicherten Positionen wirklich?

        Der Snapshot ist ein Mosaik aus unterschiedlich alten Abfragen. Wenn der
        Poller dem Fälligkeitsplan hinterherhinkt, dehnen sich die Abstände still
        aus — diese Zahlen machen das sichtbar.
        """
        now = int(time.time())
        ages = [now - r[0] for r in self.con.execute(
            "SELECT last_poll FROM addresses WHERE notional > 0 AND last_poll > 0")]
        c = self.cfg
        backlog = self.con.execute(
            """SELECT COUNT(*) FROM addresses
               WHERE (? - last_poll) > CASE
                   WHEN misses >= ?   THEN ?
                   WHEN notional >= ? THEN ?
                   ELSE ? END""",
            (now, c.drop_after_misses, c.cold_refresh * 4,
             c.hot_notional, c.hot_refresh, c.cold_refresh)).fetchone()[0]
        hot = self.con.execute(
            "SELECT COUNT(*) FROM addresses WHERE notional >= ?",
            (c.hot_notional,)).fetchone()[0]
        cold = self.con.execute(
            "SELECT COUNT(*) FROM addresses WHERE notional > 0 AND notional < ?",
            (c.hot_notional,)).fetchone()[0]

        ages.sort()
        med = ages[len(ages) // 2] if ages else 0
        p90 = ages[int(len(ages) * 0.9)] if ages else 0
        # benötigtes gegen verfügbares Budget, jeweils Abfragen pro Stunde
        need = hot * 3600 / max(c.hot_refresh, 1) + cold * 3600 / max(c.cold_refresh, 1)
        have = c.polls_per_min * 60
        return {"median": med, "p90": p90, "backlog": backlog,
                "hot": hot, "cold": cold, "load": need / have if have else 0}

    def flush_bars(self) -> None:
        """Abgeschlossene Minuten-Bars in die Datenbank schreiben."""
        cur_min = int(time.time()) // 60 * 60
        done = [k for k in self.bars if k[0] < cur_min]
        if done:
            self.con.executemany(
                "INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)",
                [(k[0], k[1], b["o"], b["h"], b["l"], b["c"], b["v"], b["n"])
                 for k in done for b in [self.bars.pop(k)]],
            )

    async def run_flush(self) -> None:
        """
        Häufiger Commit, damit ein Stromausfall wenig kostet.

        Ohne das lägen Bars und Liquidationen bis zu einem Snapshot-Intervall
        nur im Arbeitsspeicher beziehungsweise in einer offenen Transaktion.
        Bei einem geplanten Neustart geht ohnehin nichts verloren, bei einem
        harten Stromausfall aber sehr wohl.
        """
        last_checkpoint = time.time()
        while not self.stop.is_set():
            await asyncio.sleep(self.cfg.flush_sec)
            if self.stop.is_set():
                break
            try:
                self.flush_bars()
                self.con.commit()
                # WAL gelegentlich zusammenfalten, sonst wächst sie unbegrenzt
                if time.time() - last_checkpoint > 900:
                    self.con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    last_checkpoint = time.time()
            except sqlite3.Error as e:
                print(f"Schreibfehler: {e}")

    async def run_snapshots(self) -> None:
        while not self.stop.is_set():
            await asyncio.sleep(self.cfg.snapshot_sec)
            if self.stop.is_set():
                break
            self.write_snapshot()
            n_addr = self.con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0]
            tracked = sum(len(v) for v in self.positions.values())
            lag = self.poll_lag()
            print(f"[{time.strftime('%H:%M:%S')}] Adressen {n_addr:>6} | "
                  f"Positionen {tracked:>6} | Polls {self.stats['polls']:>7} | "
                  f"Trades {self.stats['trades']:>8} | Liqs {self.stats['liquidations']:>5}"
                  + (f" | 429er {self.stats['rate_limited']}" if self.stats['rate_limited'] else ""))
            print(f"           Datenalter: Median {lag['median']//60:>3} min, "
                  f"90%-Quantil {lag['p90']//60:>3} min | "
                  f"überfällig {lag['backlog']:>5} | "
                  f"Auslastung {lag['load']*100:>3.0f}%"
                  f" ({lag['hot']} heiß / {lag['cold']} kalt)")
            if lag["load"] > 0.9 or lag["backlog"] > 500:
                print("           ACHTUNG: Der Poller kommt nicht mehr nach. Die "
                      "tatsächlichen Abstände sind größer als eingestellt.")
                print("           Abhilfe: --polls-per-min erhöhen (Limit beachten), "
                      "--hot-refresh verlängern oder --hot-notional anheben.")

    # -- Start ---------------------------------------------------------------

    async def run(self) -> None:
        import aiohttp
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('started', ?)",
                         (str(int(time.time())),))
        self.con.commit()
        async with aiohttp.ClientSession() as s:
            self.session = s
            print("Löse Handelssymbole auf …")
            await self.resolve_symbols()
            # bekannte Dex-Zuordnungen aus einem früheren Lauf übernehmen
            for addr, dxs in self.con.execute(
                    "SELECT addr, dexes FROM addresses WHERE dexes != ''"):
                self.addr_dex[addr] = set(dxs.split(","))
            print()
            tasks = [asyncio.create_task(t) for t in
                     (self.run_ws(), self.run_poller(), self.run_snapshots(), self.run_flush())]
            await self.stop.wait()
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        self.write_snapshot()
        print("\nSauber beendet. Daten in", DB_PATH)


# ---------------------------------------------------------------------------
# Analyse: Cluster-Berührungen labeln
# ---------------------------------------------------------------------------

def analyze(con: sqlite3.Connection, coin: str, min_x_vol: float = 0.5,
            touch_pct: float = 0.0035, max_gap: int = 120) -> None:
    """
    Sucht Momente, in denen der Kurs ein signifikantes Cluster berührt, und
    misst, was danach passiert ist. min_x_vol = Cluster-Notional relativ zum
    1h-Volumen; darunter wird ein Cluster einfach absorbiert.
    """
    import numpy as np
    import pandas as pd

    bars = pd.read_sql(
        "SELECT * FROM bars WHERE coin=? ORDER BY ts", con, params=(coin,))
    n_heat = con.execute(
        "SELECT COUNT(*) FROM heatmap WHERE coin=?", (coin,)).fetchone()[0]
    if len(bars) < 120 or not n_heat:
        print(f"Zu wenig Daten für {coin}: {len(bars)} Bars, {n_heat} Heatmap-Zeilen.")
        print("Der Recorder sollte einige Wochen laufen, bevor das aussagekräftig wird.")
        return

    bars = bars.set_index("ts")
    px = bars["close"]
    vol_notional = (bars["volume"] * bars["close"]).rolling(60, min_periods=10).sum()

    liq = pd.read_sql(
        "SELECT ts, px, sz FROM liquidations WHERE coin=? ORDER BY ts", con, params=(coin,))
    liq["notional"] = liq["px"] * liq["sz"]

    events = []
    skipped_gap = 0                             # Snapshots ohne passende Kerze
    active: dict[tuple[float, str], int] = {}   # (bucket, side) -> letzte Berührung

    # Die Heatmap wird fensterweise aus der Datenbank gelesen statt komplett
    # geladen. Bei 90 Tagen sind das mehrere Millionen Zeilen — auf einem Pi
    # mit 4 GB wäre das sonst der Engpass.
    span = con.execute("SELECT MIN(ts), MAX(ts) FROM heatmap WHERE coin=?",
                       (coin,)).fetchone()
    window = 3 * 86400
    print(f"Verarbeite {n_heat:,} Heatmap-Zeilen in "
          f"{max(1, (span[1]-span[0])//window + 1)} Fenstern …")

    for w_start in range(span[0], span[1] + 1, window):
        rows = con.execute(
            "SELECT ts, bucket_px, side, notional FROM heatmap "
            "WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
            (coin, w_start, w_start + window)).fetchall()

        by_ts: dict[int, list] = {}
        for r in rows:
            by_ts.setdefault(r[0], []).append(r)
        del rows

        for snap_ts in sorted(by_ts):
            # nächstgelegener Bar-Preis zum Snapshot
            i = px.index.searchsorted(snap_ts)
            if i <= 0 or i >= len(px) - 1:
                continue
            # Eine Bar entsteht nur, wenn gehandelt wurde. In dünnen Märkten
            # kann die nächste Kerze Minuten entfernt liegen -- dann gehört
            # ihr Preis nicht zu diesem Snapshot und das Ereignis wird
            # verworfen statt mit falschem Bezug gezählt.
            if abs(int(px.index[i]) - snap_ts) > max_gap:
                skipped_gap += 1
                continue
            now_px = px.iloc[i]
            v1h = vol_notional.iloc[i]
            if not v1h or math.isnan(v1h) or v1h <= 0:
                continue

            for _, bpx, side, notional in by_ts[snap_ts]:
                x_vol = notional / v1h
                if x_vol < min_x_vol:
                    continue                      # zu klein, wird absorbiert

                dist = (bpx - now_px) / now_px
                # Long-Liquidationen liegen unter dem Kurs, Short-Liqs darüber
                if side == "long" and dist > 0:
                    continue
                if side == "short" and dist < 0:
                    continue
                if abs(dist) > touch_pct:
                    continue                      # noch nicht berührt

                key = (round(bpx, 6), side)
                if snap_ts - active.get(key, 0) < 3600:
                    continue                      # Entprellung: max. 1 Event/h je Cluster
                active[key] = snap_ts

                fwd = {}
                for label, secs in (("1h", 3600), ("4h", 14400), ("24h", 86400)):
                    j = px.index.searchsorted(snap_ts + secs)
                    fwd[label] = (px.iloc[j] / now_px - 1) if j < len(px) else np.nan

                j4 = px.index.searchsorted(snap_ts + 14400)
                seg = bars.iloc[i:j4] if j4 > i else bars.iloc[i:i + 1]
                max_up = seg["high"].max() / now_px - 1
                max_dn = seg["low"].min() / now_px - 1

                pen = int((seg["low"].min() < bpx) if side == "long"
                          else (seg["high"].max() > bpx))
                liq_after = liq[(liq.ts >= snap_ts) & (liq.ts < snap_ts + 3600)]["notional"].sum()

                events.append({
                    "ts": snap_ts, "coin": coin, "cluster_px": bpx, "side": side,
                    "notional": notional, "notional_x_vol": x_vol, "dist_pct": dist,
                    "px_at_touch": now_px,
                    "fwd_1h": fwd["1h"], "fwd_4h": fwd["4h"], "fwd_24h": fwd["24h"],
                    "max_up_4h": max_up, "max_dn_4h": max_dn,
                    "penetrated": pen, "liq_notional_1h": liq_after,
                })

    if skipped_gap:
        print(f"  {skipped_gap:,} Snapshots übersprungen: keine Kursbar innerhalb "
              f"von {max_gap} s. Betrifft vor allem dünne Märkte und Nachtstunden.")

    if not events:
        print("Keine Cluster-Berührungen gefunden. Schwelle --min-x-vol senken "
              "oder länger aufzeichnen.")
        return

    df = pd.DataFrame(events)
    df.to_sql("cluster_events", con, if_exists="append", index=False)
    con.commit()

    print(f"\n{len(df)} Cluster-Berührungen für {coin}")
    print("=" * 60)
    for side in ("long", "short"):
        s = df[df.side == side]
        if s.empty:
            continue
        # "Reversal" = Kurs bewegt sich vom Cluster weg
        rev = (s.fwd_4h > 0) if side == "long" else (s.fwd_4h < 0)
        print(f"\n{side.upper()}-Cluster  (n={len(s)})")
        print(f"  Reversal-Quote 4h    {rev.mean():.1%}")
        print(f"  durchbrochen         {s.penetrated.mean():.1%}")
        print(f"  Ø Bewegung 4h        {s.fwd_4h.mean():+.2%}")
        print(f"  Median 4h            {s.fwd_4h.median():+.2%}")
        print(f"  Ø bei Reversal       {s.fwd_4h[rev].mean():+.2%}")
        print(f"  Ø bei Durchbruch     {s.fwd_4h[~rev].mean():+.2%}")
        won, lost = s.fwd_4h[rev].abs().mean(), s.fwd_4h[~rev].abs().mean()
        if won and lost and lost > 0:
            edge = rev.mean() * won - (1 - rev.mean()) * lost
            print(f"  Payoff-Ratio         {won/lost:.2f}")
            print(f"  Erwartungswert       {edge:+.3%} pro Event  <- das ist die Zahl")

    print("\nHinweis: Ohne Gebühren und Slippage. Bei ~0.07 % Taker plus Spread "
          "muss der Erwartungswert deutlich über 0.2 % liegen, um zu tragen.")


# ---------------------------------------------------------------------------
# Simulation zum Testen der Pipeline
# ---------------------------------------------------------------------------

def simulate(con: sqlite3.Connection, coin: str = "BTC", days: int = 20) -> None:
    """
    Erzeugt Fake-Daten zum Testen des Analysepfads. Cluster liegen auf festen
    absoluten Preisniveaus und verändern sich nur langsam — so wie echte
    Positionen. Der Kurs wandert dann in sie hinein.
    """
    rng = random.Random(42)
    t0 = int(time.time()) - days * 86400
    n = days * 1440
    p0 = 60_000.0

    # Preisreihe
    price = p0
    prices, rows_b = [], []
    for i in range(n):
        ts = t0 + i * 60
        price *= math.exp(rng.gauss(0, 0.0012))
        hi = price * (1 + abs(rng.gauss(0, 0.0006)))
        lo = price * (1 - abs(rng.gauss(0, 0.0006)))
        prices.append(price)
        rows_b.append((ts, coin, price, hi, lo, price,
                       abs(rng.gauss(4, 2)), rng.randint(5, 80)))

    # Persistente Cluster auf festem logarithmischem Preisraster
    step = math.log1p(0.0025)
    levels: dict[int, float] = {}

    def level_notional(k: int) -> float:
        if k not in levels:
            levels[k] = abs(rng.gauss(0, 1)) * 3e6
        levels[k] *= math.exp(rng.gauss(0, 0.02))   # driftet langsam
        return levels[k]

    rows_h = []
    for i in range(0, n, 5):                          # alle 5 Minuten
        ts, px = t0 + i * 60, prices[i]
        base = round(math.log(px) / step)
        for k in range(-40, 41):
            if k == 0:
                continue
            lv = round(math.exp((base + k) * step), 8)
            notional = level_notional(base + k) * math.exp(-abs(k) / 15)
            if notional > 5e4:
                side = "long" if k < 0 else "short"
                rows_h.append((ts, coin, lv, side, notional, rng.randint(1, 40)))

    con.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)", rows_b)
    con.executemany("INSERT OR REPLACE INTO heatmap VALUES (?,?,?,?,?,?)", rows_h)
    con.commit()
    print(f"Simulation: {len(rows_b)} Bars, {len(rows_h)} Heatmap-Zeilen für {coin}.")
    print("Achtung: reines Rauschen ohne echten Zusammenhang — testet nur die Pipeline.")


# ---------------------------------------------------------------------------
# Export: kompaktes Paket zum Weitergeben oder Hochladen
# ---------------------------------------------------------------------------

def export_bundle(con: sqlite3.Connection, out_path: str,
                  coin: str | None = None) -> None:
    """
    Schreibt ein ZIP mit allem, was zur Auswertung nötig ist -- ohne die
    Rohdaten. Die Datenbank wird nach Monaten hunderte Megabyte groß und ist
    nicht mehr handhabbar; die Ereignisse und Kennzahlen daraus passen in
    wenige hundert Kilobyte.

    Enthalten:
      cluster_events.csv   die gelabelten Berührungen, ein Datensatz je Ereignis
      daily_coverage.csv   je Coin und Tag: Bars, Snapshots, Liquidationen
      time_heatmap.csv     die Wochentag-x-Uhrzeit-Statistik, falls vorhanden
      binance_hourly.csv   stündlich aggregierte Binance-Liquidationen
      meta.json            Abdeckung, Zeitraum, Datenqualität
    """
    import csv
    import io
    import zipfile

    def rows_to_csv(cur) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([d[0] for d in cur.description])
        w.writerows(cur.fetchall())
        return buf.getvalue()

    def table_exists(name: str) -> bool:
        return con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (name,)).fetchone() is not None

    where, args = ("WHERE coin=?", (coin,)) if coin else ("", ())
    parts: dict[str, str] = {}

    # --- Ereignisse, mit abgeleiteten Zeitspalten für die Auswertung
    if table_exists("cluster_events"):
        cur = con.execute(f"""
            SELECT *,
                   CAST(strftime('%w', ts, 'unixepoch') AS INTEGER) AS weekday_sun0,
                   CAST(strftime('%H', ts, 'unixepoch') AS INTEGER) AS hour_utc,
                   CAST(strftime('%H', ts, 'unixepoch') AS INTEGER) * 2
                     + CAST(strftime('%M', ts, 'unixepoch') AS INTEGER) / 30
                     AS slot_utc,
                   datetime(ts, 'unixepoch') AS ts_utc
            FROM cluster_events {where} ORDER BY ts""", args)
        parts["cluster_events.csv"] = rows_to_csv(cur)

    # --- Tagesabdeckung: zeigt Lücken und Ausfälle auf einen Blick
    cur = con.execute(f"""
        SELECT date(ts,'unixepoch') AS tag, coin,
               COUNT(*) AS bars, SUM(volume) AS volumen,
               MIN(low) AS tief, MAX(high) AS hoch
        FROM bars {where} GROUP BY tag, coin ORDER BY tag, coin""", args)
    parts["daily_coverage.csv"] = rows_to_csv(cur)

    cur = con.execute(f"""
        SELECT date(ts,'unixepoch') AS tag, coin,
               COUNT(DISTINCT ts) AS snapshots,
               COUNT(*) AS zeilen,
               SUM(notional) / COUNT(DISTINCT ts) AS notional_je_snapshot
        FROM heatmap {where} GROUP BY tag, coin ORDER BY tag, coin""", args)
    parts["daily_heatmap.csv"] = rows_to_csv(cur)

    if table_exists("time_heatmap"):
        parts["time_heatmap.csv"] = rows_to_csv(
            con.execute("SELECT * FROM time_heatmap ORDER BY coin, threshold, "
                        "weekday, slot"))

    if table_exists("bnc_liquidations"):
        parts["binance_hourly.csv"] = rows_to_csv(con.execute("""
            SELECT strftime('%Y-%m-%dT%H', ts/1000, 'unixepoch') AS stunde, coin,
                   COUNT(*) AS anzahl,
                   SUM(CASE WHEN side='long'  THEN notional ELSE 0 END) AS long_liq,
                   SUM(CASE WHEN side='short' THEN notional ELSE 0 END) AS short_liq
            FROM bnc_liquidations GROUP BY stunde, coin ORDER BY stunde, coin"""))

    # --- Metadaten: Zeitraum, Umfang, Datenqualität
    now = int(time.time())
    span = con.execute("SELECT MIN(ts), MAX(ts) FROM bars").fetchone()
    ages = sorted(now - r[0] for r in con.execute(
        "SELECT last_poll FROM addresses WHERE notional>0 AND last_poll>0"))
    per_coin = {}
    for c, n, lo, hi in con.execute(
            "SELECT coin, COUNT(*), MIN(ts), MAX(ts) FROM bars GROUP BY coin"):
        snaps = con.execute(
            "SELECT COUNT(DISTINCT ts) FROM heatmap WHERE coin=?", (c,)).fetchone()[0]
        per_coin[c] = {"bars": n, "snapshots": snaps,
                       "von": datetime_utc(lo), "bis": datetime_utc(hi),
                       "abdeckung_prozent": round(
                           n / max((hi - lo) / 60, 1) * 100, 1)}
    meta = {
        "erstellt": datetime_utc(now),
        "zeitraum": {"von": datetime_utc(span[0]) if span[0] else None,
                     "bis": datetime_utc(span[1]) if span[1] else None,
                     "tage": round((span[1] - span[0]) / 86400, 1) if span[0] else 0},
        "coins": per_coin,
        "adressen": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
        "adressen_mit_position": con.execute(
            "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
        "datenalter_median_min": (ages[len(ages)//2] // 60) if ages else None,
        "datenalter_p90_min": (ages[int(len(ages)*0.9)] // 60) if ages else None,
        "cluster_events": con.execute(
            "SELECT COUNT(*) FROM cluster_events").fetchone()[0]
            if table_exists("cluster_events") else 0,
        "hinweis": "Aggregate und gelabelte Ereignisse, keine Rohdaten. "
                   "Die vollständige Datenbank verbleibt auf dem Aufzeichnungsrechner.",
    }
    parts["meta.json"] = json.dumps(meta, indent=2, ensure_ascii=False)

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, content in parts.items():
            z.writestr(name, content)

    size = os.path.getsize(out_path)
    print(f"\nExport: {out_path} ({size/1024:.0f} kB)")
    for name, content in parts.items():
        lines = content.count("\n")
        print(f"  {name:<22} {lines:>8,} Zeilen")
    if meta["cluster_events"] == 0:
        print("\nAchtung: keine cluster_events enthalten. Erst --analyze laufen "
              "lassen, sonst fehlt der eigentliche Inhalt.")
    if size > 20_000_000:
        print("\nDas Paket ist recht groß. Mit --coin BTC auf einen Coin "
              "einschränken.")


def datetime_utc(ts) -> str | None:
    if not ts:
        return None
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts))


def status(con: sqlite3.Connection) -> None:
    q = lambda s: con.execute(s).fetchone()
    print("Datenbank:", DB_PATH, f"({os.path.getsize(DB_PATH)/1e6:.1f} MB)")
    print(f"  Adressen           {q('SELECT COUNT(*) FROM addresses')[0]:,}")
    print(f"  davon mit Position {q('SELECT COUNT(*) FROM addresses WHERE notional>0')[0]:,}")
    print(f"  Heatmap-Zeilen     {q('SELECT COUNT(*) FROM heatmap')[0]:,}")
    print(f"  Bars               {q('SELECT COUNT(*) FROM bars')[0]:,}")
    print(f"  Liquidationen      {q('SELECT COUNT(*) FROM liquidations')[0]:,}")
    now = int(time.time())
    ages = sorted(now - r[0] for r in con.execute(
        "SELECT last_poll FROM addresses WHERE notional > 0 AND last_poll > 0"))
    if ages:
        print(f"  Datenalter Median  {ages[len(ages)//2]//60} min")
        print(f"  Datenalter 90%     {ages[int(len(ages)*0.9)]//60} min")
        if ages[int(len(ages)*0.9)] > 3600:
            print("  -> über eine Stunde alt: der Poller hängt hinterher")
    r = q("SELECT MIN(ts), MAX(ts) FROM bars")
    if r[0]:
        span = (r[1] - r[0]) / 86400
        print(f"  Zeitraum           {span:.1f} Tage")
        if span < 14:
            print("  -> für belastbare Statistik deutlich zu wenig")


# ---------------------------------------------------------------------------

def main() -> None:
    global DB_PATH
    p = argparse.ArgumentParser(description="Hyperliquid Liquidations-Recorder")
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR"])
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--bucket-pct", type=float, default=0.0025)
    p.add_argument("--snapshot-sec", type=int, default=600,
                   help="Abstand der Heatmap-Snapshots in Sekunden")
    p.add_argument("--flush-sec", type=int, default=10,
                   help="Commit-Takt in Sekunden")
    p.add_argument("--durable", action="store_true",
                   help="synchronous=FULL: kein Verlust bei Stromausfall, "
                        "dafür mehr Schreibzugriffe")
    p.add_argument("--polls-per-min", type=int, default=DEFAULT_POLLS_PER_MIN,
                   help="Abfragebudget; clearinghouseState hat Gewicht 2 bei 1200/min")
    p.add_argument("--hot-refresh", type=int, default=180,
                   help="Abstand für große Positionen in Sekunden")
    p.add_argument("--cold-refresh", type=int, default=1800,
                   help="Abstand für kleine Positionen in Sekunden")
    p.add_argument("--hot-notional", type=float, default=50_000,
                   help="ab welchem Notional eine Adresse als groß gilt")
    p.add_argument("--analyze", action="store_true")
    p.add_argument("--coin", default="BTC", help="Coin für --analyze")
    p.add_argument("--min-x-vol", type=float, default=0.5)
    p.add_argument("--max-gap", type=int, default=120,
                   help="größter erlaubter Abstand Snapshot zu Kursbar in Sekunden")
    p.add_argument("--simulate", action="store_true")
    p.add_argument("--status", action="store_true")
    p.add_argument("--export", metavar="DATEI.zip",
                   help="Ereignisse und Kennzahlen als kompaktes ZIP ausgeben")
    args = p.parse_args()

    DB_PATH = args.db
    con = db_connect(DB_PATH, "FULL" if getattr(args, "durable", False) else "NORMAL")

    if args.status:
        status(con); return
    if args.export:
        export_bundle(con, args.export, args.coin if args.coin != "BTC" or
                      "--coin" in sys.argv else None)
        return
    if args.simulate:
        simulate(con); return
    if args.analyze:
        analyze(con, args.coin, args.min_x_vol, max_gap=args.max_gap); return

    cfg = Settings(coins=args.coins, bucket_pct=args.bucket_pct,
                   snapshot_sec=args.snapshot_sec, polls_per_min=args.polls_per_min,
                   hot_refresh=args.hot_refresh, cold_refresh=args.cold_refresh,
                   hot_notional=args.hot_notional, flush_sec=args.flush_sec,
                   synchronous="FULL" if args.durable else "NORMAL")
    rec = Recorder(con, cfg)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, rec.stop.set)
        except NotImplementedError:
            pass
    print(f"Recorder läuft für {', '.join(cfg.coins)}. Abbruch mit Strg-C.")
    print("Die ersten Minuten sind leer — das Adressregister muss erst wachsen.\n")
    try:
        loop.run_until_complete(rec.run())
    except KeyboardInterrupt:
        rec.stop.set()
    finally:
        con.close()


if __name__ == "__main__":
    main()
