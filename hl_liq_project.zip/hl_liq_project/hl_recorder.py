#!/usr/bin/env python3
"""
hl_recorder.py — Zeichnet Hyperliquid-Liquidationscluster live auf und labelt sie.

Warum: Historische Positionsdaten gibt es öffentlich nicht. Wer testen will, ob
Liquidationscluster Vorhersagekraft haben, muss selbst vorwärts aufzeichnen.

Wie es funktioniert:
  1. WebSocket 'trades' liefert zu jedem Trade die beteiligten Wallet-Adressen
     -> daraus wächst über die Zeit ein Adressregister.
  2. 'clearinghouseState' pro Adresse liefert offene Positionen inkl. echtem
     liquidationPx -> keine Schätzung wie bei CEX-Heatmaps.
  3. Alle Liquidationspreise werden in Preis-Buckets aggregiert -> Heatmap.
  4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit später
     Forward-Returns berechnet werden können.
  5. Liquidationen: Der öffentliche Trade-Feed kennzeichnet sie NICHT. Zwei
     eigene Quellen: userEvents-Abos für Wale und Konten ab 1 Mio (Echtzeit,
     kostet kein REST-Gewicht) und die Ableitung aus dem Polling für alle
     anderen (Position weg, Kurs hat den Liquidationspreis berührt).

Modi:
    python hl_recorder.py --coins BTC ETH HYPE          # aufzeichnen
    python hl_recorder.py --simulate                    # Testdaten erzeugen
    python hl_recorder.py --analyze --coin BTC          # Cluster-Events labeln
    python hl_recorder.py --status                      # DB-Überblick

Abhängigkeiten: pip install websockets aiohttp pandas numpy
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib                 # 23.11: on_user_event nutzt blake2b im tid-Rueckfall (N5); fehlte -> NameError, WS-Neuaufbau
import heapq
import random
import re                      # 23.38: Grund der zurückgenommenen Freigaben (sperre_kleinfill_korrektur)
import json
import math
import os
import signal
import shutil
import sqlite3
import sys
import time
from collections import defaultdict, deque
from dataclasses import dataclass

VERSION_MODUL = "2026-09-23.126"      # 23.125: erstmals mit Zahl (Regel VERSION_MODUL); U311 Aufgabe „Buch-Tiefe“; 23.126: U287 Hänger-Schutz
API = "https://api.hyperliquid.xyz/info"
WS = "wss://api.hyperliquid.xyz/ws"
DB_PATH = "hl_liq.db"

# clearinghouseState hat Rate-Limit-Gewicht 2; das IP-Budget liegt bei 1200/min.
# Wir bleiben bewusst deutlich darunter, um Platz für andere Requests zu lassen.
# "Aktive Profis" (Konzept 22.09., Phase 1): Kandidatenpool aus der vollen Leaderboard-Datei
POOL_MIN_VALUE = 1e6            # Kontowert USD
POOL_MIN_VLM = 5e5              # Tagesumsatz USD
POOL_HYSTERESE_TAGE = 7         # Verbleib nach dem letzten Erfüllen (Etappe 2: 30)
POOL_DECKEL = 600               # falls der Pool größer wird: die profitabelsten (pnl_7d) bleiben
POOL_MAX_TRADES_TAG = 150       # Phase 2: Ausschluss ab so vielen gebündelten Trades je Tag (Nutzer 22.09.)
POOL_ROH_MAX_FILLS_TAG = 500    # Rohfills 14 Tage nur bis zu dieser Zahl je Tag, darüber 1 Tag (Vielhandler)
POOL_ROH_TAGE = 14              # Rohfill-Aufbewahrung für Pool- und Leaderboard-Konten
POOL_POLL_S = 600               # Positionen der Pool-Konten alle 10 min
# Masterregel Sperre (22.09., Entscheidung Nutzer): eine Maschine wird DAUERHAFT gesperrt -- kein Verhaltenssignal
# mehr (Treiber, Flows, Scores, Elite), keine Order-Abfrage, keine Fill-Speicherung. Positionen bis 23.85 noch alle 6 h
# (gedacht als Liquidationsstufe in der Heatmap; bei Überlast als Rang 2 nie erreicht); seit 23.86 (U220, Entscheidung Nutzer
# 26.10.: oft Hedge-Positionen von Market-Makern, Kapazität lieber für die größten Konten) gar nicht mehr abgefragt.
# Basis seit 23.13 (U31, Entscheidung Nutzer 23.09.): mehr als SPERRE_TRADES_TAG GEBÜNDELTE
# Trades (je Coin, Minute und Richtung) in 24 h -- dieselbe Einheit wie die Aktivitätsschranke der Elite. Bis 23.12
# zählte die Regel Fills (> 2.000); Fills sind Ausführungen, keine Entscheidungen: Nach der Umstellung auf ALLE Fills
# (M1, 22.18) sperrte sie binnen zehn Stunden 19 Konten knapp über 2.000 (A6, 23.09.).
SPERRE_TRADES_TAG = 300
DARWIN_KLEIN_MAX_H = 200        # 23.34: Fills UNTER lb_fills_min_usd nur für Konten der Darwin-Liste, höchstens so viele je Konto, Stunde und Quelle
# 23.29 (Entscheidung Nutzer 25.09.): dauerhaft erst beim ZWEITEN Tag über der Grenze binnen 7 Tagen. Am ersten Tag wird
# das Konto VORLÄUFIG ausgeschlossen (wirkt wie gesperrt, aber seine Rohfills bleiben); ohne zweiten Tag nach 7 Tagen frei.
# Ein Mensch mit einem einzigen extremen Tag (Crash) bleibt so erhalten; Maschinen liegen jeden Tag darüber.
SPERRE_VORLAEUFIG_TAGE = 7
# 23.82 (U222): Minuten-Bars und 10-s-Stücke wurden geschrieben, sobald ihre Zeit vorbei war, und aus dem Speicher genommen; ein danach
# eintreffender Trade begann ein neues Stück, das die vollständige Zeile per INSERT OR REPLACE ersetzte (Volumen zu klein, Hoch und Tief
# falsch -- im ersten Bericht der Volumen-Studie 4–8 % der Minuten je Coin, steigend; bei 10 s Takt in zufälliger Lage und üblicher
# Verspätung von 0,4–0,8 s passt das genau). Jetzt:
# - erst BAR_GRACE_S nach dem Ende schreiben; der Schreibtakt (Dienst: 10 s) liegt FLUSH_PHASE_S hinter jeder Taktgrenze (:03, :13, …);
# - geschriebene Stücke im Speicher halten, bis die Börsenzeit (höchster gesehener Trade, nicht die Uhr des Pi) BAR_HALTEN_S über das Ende
#   ihrer Minute hinaus ist; ein später Trade holt das Stück zurück, die Zeile wird mit allen Trades vollständig neu geschrieben;
# - was danach noch kommt, zählt nicht (u222_zu_alt): so spät ist es fast sicher eine Wiederholung, keine Lieferung;
# - Trades je Coin nach (Zeit, tid) entdoppelt, TID_HALTEN_S länger als jedes Halten (Wiederholungen beim Neuverbinden);
# - Neustart: Trades bis zur höchsten Börsenzeit, die der vorige Dienst gesehen hat (meta u222_hw_ms; fehlt sie: Start des Dienstes),
#   zählen nicht -- für beide Tabellen gleich; die letzte Minute des vorigen Dienstes (MAX(ts) in bars) wird beim ersten Schreiben mit
#   ihrer Zeile zusammengeführt statt ersetzt.
BAR_GRACE_S = 2
FLUSH_PHASE_S = 3
BAR_HALTEN_S = 900
TID_HALTEN_S = 1200
TID_MAX_JE_COIN = 300_000
SPERRE_FILLS_TAG = 2000         # alte Grenze -- nur noch Anzeige und Protokoll, keine Sperrwirkung
KLEIN_TAGESPRUEFUNG_S = 86_400  # 23.86 (U220): leere und -- ohne --klein-regelmaessig -- kleine Konten ohne eigenen Handel höchstens einmal am Tag
VORRANG_UEBERFAELLIG = 1e9       # 23.86: Sortierwert der vorgezogenen Adressen (vor jeder echten Überfälligkeit von Rang 1)
VORRANG_ANTEIL = 0.10           # 23.86: höchstens so viel der Runde (280/min: 2 von 23) für vorgezogene Adressen -- bei Ansturm bis etwa 1/6
                                # des Durchsatzes von Rang 1 (zweite Durchsicht), Wale und Elite nie
FEHL_AUSLOESER_MAX = 3          # 23.86: so viele Fehlschläge hintereinander behält eine leere/kleine Adresse ihren Handel als Auslöser
WAL_WIEDERHER_S = 24 * 3600     # 23.36: Wal-Zustand beim Start aus den letzten 24 h VOR DEM LETZTEN EINTRAG (Schnappschuss alle 10 min)
KLEINFILL_SEIT = 1_790_640_000  # 29.09.2026 00:00 UTC: frühester Stand von 23.34 (kleine Darwin-Fills in lb_fills) -- Sperren ab hier neu bewerten (23.37)
DEFAULT_POLLS_PER_MIN = 280      # 17.09.: von 320 -- Poller (2 je Abfrage) und Wal-Orders füllten 94 % des Budgets, Fills bekamen nichts


# ---------------------------------------------------------------------------
# Datenbank
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS addresses (
    addr        TEXT PRIMARY KEY,
    first_seen  INTEGER,
    last_trade  INTEGER,
    last_poll   INTEGER DEFAULT 0,
    notional    REAL    DEFAULT 0,   -- letzte bekannte Positionsgröße, steuert Poll-Priorität
    misses      INTEGER DEFAULT 0,   -- Polls ohne offene Position
    dexes       TEXT    DEFAULT '',  -- Perp-Dexe, auf denen die Adresse handelt
    pos_value   REAL    DEFAULT 0    -- Positionswert zum Markpreis: steuert die Stufe
);
CREATE INDEX IF NOT EXISTS ix_addr_poll ON addresses(last_poll);

-- Aggregierte Heatmap: das primäre Trainingsdatum
CREATE TABLE IF NOT EXISTS heatmap (
    ts          INTEGER,
    coin        TEXT,
    bucket_px   REAL,
    side        TEXT,     -- 'long' = Long-Liquidationen (unter Kurs), 'short' = darüber
    notional    REAL,
    n_pos       INTEGER,
    PRIMARY KEY (ts, coin, bucket_px, side)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_heat_coin_ts ON heatmap(coin, ts);

-- 1-Minuten-Bars aus dem Trade-Feed, für Forward-Returns
CREATE TABLE IF NOT EXISTS bars (
    ts      INTEGER,
    coin    TEXT,
    open    REAL, high REAL, low REAL, close REAL,
    volume  REAL,
    trades  INTEGER,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Tatsächlich eingetretene Liquidationen
CREATE TABLE IF NOT EXISTS liquidations (
    ts        INTEGER,
    coin      TEXT,
    user      TEXT,
    method    TEXT,
    mark_px   REAL,
    px        REAL,
    sz        REAL,
    side      TEXT,
    tid       INTEGER PRIMARY KEY
);
CREATE INDEX IF NOT EXISTS ix_liq_coin_ts ON liquidations(coin, ts);

-- Ergebnis des Analyse-Laufs
CREATE TABLE IF NOT EXISTS cluster_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              INTEGER,
    coin            TEXT,
    cluster_px      REAL,
    side            TEXT,
    notional        REAL,
    notional_x_vol  REAL,   -- Cluster relativ zum 1h-Volumen: der eigentliche Schwellenwert
    dist_pct        REAL,   -- Abstand bei Erkennung
    px_at_touch     REAL,
    fwd_1h          REAL, fwd_4h REAL, fwd_24h REAL,
    max_up_4h       REAL, max_dn_4h REAL,
    penetrated      INTEGER, -- wurde das Cluster durchlaufen?
    liq_notional_1h REAL     -- tatsächlich liquidiertes Volumen danach
);

-- Tick-Aufzeichnung bei Kaskaden und Flash-Bewegungen. Ein Ringpuffer hält
-- die letzten Minuten aller Rohtrades im Speicher; erkennt der Recorder eine
-- schnelle Bewegung oder einen Liquidationsschub, schreibt er das Fenster
-- davor und danach weg. Damit lassen sich solche Ereignisse später Tick für
-- Tick nachspielen, ohne die Datenbank dauerhaft zu fluten.
CREATE TABLE IF NOT EXISTS tick_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    coin        TEXT,
    t_trigger   INTEGER,   -- ms
    t_start     INTEGER,   -- ms, Beginn des gesicherten Fensters
    t_end       INTEGER,   -- ms
    reason      TEXT,      -- move60, flash10, liqburst
    move_pct    REAL,      -- Bewegung, die ausgelöst hat
    px_before   REAL,
    px_trigger  REAL,
    px_extreme  REAL,      -- extremster Preis im Fenster
    n_ticks     INTEGER,
    n_liqs      INTEGER,
    complete    INTEGER    -- 1 = Nachlauf vollständig gesichert
);
CREATE TABLE IF NOT EXISTS ticks (
    event_id INTEGER,
    ts_ms    INTEGER,
    coin     TEXT,
    px       REAL,
    sz       REAL,
    side     TEXT,         -- A = Verkauf trifft Bid, B = Kauf trifft Ask
    liq      INTEGER,      -- 1 = Liquidations-Fill
    tid      INTEGER,
    PRIMARY KEY (event_id, ts_ms, tid)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS mark_ticks (
    event_id  INTEGER,
    ts_ms     INTEGER,
    coin      TEXT,
    mark_px   REAL,
    oracle_px REAL,
    PRIMARY KEY (event_id, ts_ms)
) WITHOUT ROWID;

-- Orderbuch-Kennzahlen alle 5 s: die eigentlichen Vorläufer eines Flash-Crash.
-- Tiefe in USD innerhalb 10/25/50/100 Basispunkten je Seite, Spread, Imbalance.
CREATE TABLE IF NOT EXISTS book_summary (
    ts        INTEGER,
    coin      TEXT,
    bid       REAL,  ask REAL,
    spread_bps REAL,
    bid_10 REAL, ask_10 REAL,     -- Tiefe in USD innerhalb 10 bps
    bid_25 REAL, ask_25 REAL,
    bid_50 REAL, ask_50 REAL,
    bid_100 REAL, ask_100 REAL,
    imb_50  REAL,                 -- (bid_50 - ask_50) / (bid_50 + ask_50)
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Vollständige Buch-Snapshots (Top 10 je Seite) nur in Ereignisfenstern
CREATE TABLE IF NOT EXISTS book_ticks (
    event_id INTEGER,
    ts_ms    INTEGER,
    coin     TEXT,
    levels   TEXT,                -- JSON [[bids],[asks]] als [px, sz]
    PRIMARY KEY (event_id, ts_ms)
) WITHOUT ROWID;

-- 23.125 (U311): Tiefe des Buchs bis ±1 % je Minute aus gerundeten Preisstufen (Aufgabe „Buch-Tiefe“, 35 Tage)
CREATE TABLE IF NOT EXISTS book_tiefe (
    ts       INTEGER,             -- Minute (Sekunden seit 1970, UTC)
    coin     TEXT,
    nsig     INTEGER,             -- gültige Stellen der Rundung (nSigFigs)
    schritt  REAL,                -- Abstand der Stufen in USD
    mitte    REAL,
    bid_1    REAL,                -- Gebote bis 1 % unter der Mitte (USD)
    ask_1    REAL,                -- Forderungen bis 1 % über der Mitte (USD)
    stufen_b INTEGER, stufen_a INTEGER,
    voll     INTEGER,             -- 1 Gebote bis -1 % vollständig, 2 Forderungen bis +1 %, 3 beide
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- 10-Sekunden-Bars mit Seitenaufteilung: Aggressor-Verkäufe gegen -Käufe
CREATE TABLE IF NOT EXISTS bars10 (
    ts      INTEGER,
    coin    TEXT,
    open REAL, high REAL, low REAL, close REAL,
    vol_buy  REAL,                -- Taker kauft (trifft Ask)
    vol_sell REAL,                -- Taker verkauft (trifft Bid)
    trades   INTEGER,
    n_liq    INTEGER,
    liq_notional REAL,
    max_sz   REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Nähe zum nächsten großen Cluster, je Minute aus den Positionen im Speicher
CREATE TABLE IF NOT EXISTS proximity (
    ts        INTEGER,
    coin      TEXT,
    px        REAL,
    up_px     REAL,  up_notional REAL,  up_dist REAL,
    dn_px     REAL,  dn_notional REAL,  dn_dist REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Offene Orders der Wale, vor allem Trigger-Orders (Stop-Loss, Take-Profit).
-- Die stehen NICHT im Orderbuch: Sie werden erst beim Auslösepreis zu
-- Market-Orders -- wie Liquidationen. Ein Stop-Cluster ist deshalb ein
-- Kaskaden-Kandidat. Ein Datensatz je Order und Abfrage (Zeitreihe).
CREATE TABLE IF NOT EXISTS trigger_orders (
    ts          INTEGER,
    addr        TEXT,
    coin        TEXT,
    oid         INTEGER,
    side        TEXT,       -- A = Verkauf, B = Kauf
    order_type  TEXT,       -- Stop Market, Stop Limit, Take Profit Market, Take Profit Limit, Limit
    is_trigger  INTEGER,
    trigger_px  REAL,
    limit_px    REAL,
    size        REAL,
    notional    REAL,       -- Größe * Auslösepreis (bzw. Limitpreis)
    reduce_only INTEGER,
    is_tpsl     INTEGER,    -- an eine Position gebundener Stop/TP
    kind        TEXT,       -- stop_sell / stop_buy / tp_sell / tp_buy / limit_sell / limit_buy
    PRIMARY KEY (ts, oid)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_trig_coin_ts ON trigger_orders(coin, ts);

-- Schlüsselniveaus und Ordermix je Snapshot (10 min), aus den jüngsten Orders
-- aller abgefragten Konten innerhalb +-30 % des Kurses. Dieselbe Rechnung wie im
-- Dashboard, damit sich später prüfen lässt, ob Kaufwände, Stop-Cluster oder
-- Liquidationscluster den Kurs anziehen -- und wie sich der Ordermix vorher verhielt.
CREATE TABLE IF NOT EXISTS order_levels (
    ts              INTEGER,
    coin            TEXT,
    px              REAL,
    n_accounts      INTEGER,
    support_px      REAL, support_usd    REAL,   -- größte Kaufwand unter dem Kurs
    resist_px       REAL, resist_usd     REAL,   -- größte Verkaufswand darüber
    tp_long_px      REAL, tp_long_usd    REAL,   -- höchste Take-Profits der Longs (oben)
    tp_short_px     REAL, tp_short_usd   REAL,   -- höchste Take-Profits der Shorts (unten)
    stop_sell_px    REAL, stop_sell_usd  REAL,   -- größtes Sell-Stop-Cluster unter dem Kurs
    stop_buy_px     REAL, stop_buy_usd   REAL,   -- größtes Buy-Stop-Cluster darüber
    stop_sell_2pct  REAL, stop_buy_2pct  REAL,   -- Stop-Summen innerhalb 2 %
    limit_buy_usd   REAL, limit_sell_usd REAL,   -- Summen je Art innerhalb +-30 %
    stop_sell_usd_t REAL, stop_buy_usd_t REAL,
    tp_sell_usd     REAL, tp_buy_usd     REAL,
    n_orders        INTEGER,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Marktkontext je Minute aus activeAssetCtx: Liquidationen lösen am
-- Markpreis aus, nicht am Handelspreis. Ohne diese Reihe misst die
-- Berührungserkennung den falschen Preis.
CREATE TABLE IF NOT EXISTS ctx_bars (
    ts        INTEGER,
    coin      TEXT,
    mark_px   REAL,
    oracle_px REAL,
    mid_px    REAL,
    funding   REAL,      -- aktuelle stündliche Funding-Rate
    oi        REAL,      -- Open Interest in Coin-Einheiten (eine Seite)
    premium   REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- 23.96 (U246): Impact-Preise der Börse je Minute (activeAssetCtx.impactPxs) -- der mittlere
-- Ausführungspreis einer Markt-Order über die Impact-Größe der Börse (20.000 USDC bei BTC und
-- ETH, 6.000 USDC bei den übrigen) auf der Geld- und der Briefseite, dazu die Buchmitte
-- derselben Nachricht. Eigene Tabelle: ctx_bars hat acht Spalten und viele Leser, die sie mit
-- Platzhaltern füllen. impact_bid/impact_ask NULL = das Feld kam in dieser Minute nicht (oder
-- war nicht lesbar); geraten wird nichts.
CREATE TABLE IF NOT EXISTS impact_bars (
    ts         INTEGER,
    coin       TEXT,
    mid_px     REAL,
    impact_bid REAL,
    impact_ask REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Abdeckung: welchen Anteil des Open Interest sehen wir überhaupt?
CREATE TABLE IF NOT EXISTS coverage (
    ts            INTEGER,
    coin          TEXT,
    tracked_size  REAL,   -- Summe |size| aller verfolgten Positionen (beide Seiten)
    oi            REAL,   -- offizielles OI, eine Seite
    ratio         REAL,   -- tracked_size / (2 * oi)
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

-- Wal-Protokoll: nur Änderungen und ein Zeitreihenpunkt je Snapshot
CREATE TABLE IF NOT EXISTS whale_positions (
    ts         INTEGER,
    addr       TEXT,
    coin       TEXT,
    event      TEXT,      -- open, add, reduce, close, flip, snap
    side       TEXT,
    size       REAL,
    pos_value  REAL,      -- USD zum Markpreis
    entry_px   REAL,
    liq_px     REAL,
    leverage   REAL,
    upnl       REAL,      -- unrealisierter Gewinn/Verlust
    mark_px    REAL,
    delta_usd  REAL,      -- Veränderung des Positionswerts gegenüber dem Vorzustand
    PRIMARY KEY (ts, addr, coin, event)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_whale_coin_ts ON whale_positions(coin, ts);
CREATE INDEX IF NOT EXISTS ix_whale_addr ON whale_positions(addr, ts);

-- Leaderboard: die profitabelsten Konten (30-Tage-PnL) und ihre offenen Positionen,
-- alle 10 min; lb_trend einmal pro Stunde je Coin für Top 20 und Top 50.
-- 23.27: Positionen ALLER Pool-Konten (Top 500 und Kandidaten, alle 10 min abgefragt). Bisher landeten nur Wale ab 10 Mio
-- Gesamtwert in whale_positions, die Positionen der übrigen Pool-Konten wurden nach der Abfrage verworfen. delta_usd ist
-- hier der GERICHTETE Fluss: + Kaufdruck (Long auf/aufgestockt, Short abgebaut/zu), − Verkaufsdruck; „snap“ = Stand ohne Fluss.
CREATE TABLE IF NOT EXISTS pool_positions (
    ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL, liq_px REAL,
    leverage REAL, upnl REAL, mark_px REAL, delta_usd REAL, PRIMARY KEY (ts, addr, coin));
CREATE INDEX IF NOT EXISTS ix_poolpos_coin_ts ON pool_positions(coin, ts);
CREATE TABLE IF NOT EXISTS lb_accounts (
    ts INTEGER, rank INTEGER, addr TEXT, name TEXT, account_value REAL,
    pnl_30d REAL, roi_30d REAL, pnl_7d REAL, n_positions INTEGER,
    PRIMARY KEY (ts, addr)
);
-- Leaderboard-Kennzahlen aller VERFOLGTEN Konten (Kandidaten + Wale), alle vier Fenster mit
-- Umsatz. Der Umsatz ist die billigste Trennlinie zwischen Market Makern (Milliarden Umsatz,
-- Promille Edge) und Händlern -- er wurde bisher beim Parsen verworfen. Eine Zeile je Konto,
-- stündlich ersetzt; die Historie der Kandidaten liegt weiter in lb_accounts.
-- Audit v3 S1: lb_stats ist der jüngste Stand je Konto (stündlich ersetzt); lb_stats_hist hält
-- jede Stunde fest -- PnL/ROI/UMSATZ als Zeitreihe (75 Konten x 24/Tag, vernachlässigbar).
CREATE TABLE IF NOT EXISTS lb_stats_hist (
    addr TEXT, ts INTEGER, account_value REAL,
    pnl_1d REAL, roi_1d REAL, vlm_1d REAL,
    pnl_7d REAL, roi_7d REAL, vlm_7d REAL,
    pnl_30d REAL, roi_30d REAL, vlm_30d REAL,
    pnl_all REAL, roi_all REAL, vlm_all REAL,
    PRIMARY KEY (addr, ts));
-- Audit v3 S2/S3: Aggregate vor dem Löschen -- Positionen je volle Stunde, Fills je Tag und Konto
CREATE TABLE IF NOT EXISTS lb_pos_hourly (
    ts INTEGER, addr TEXT, coin TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL, liq_px REAL, leverage REAL,
    PRIMARY KEY (ts, addr, coin));
-- "Aktive Profis" Phase 1: Kandidatenpool (stündlich aus der Leaderboard-Datei) und Stundenaggregat
-- der Fills mit GEBÜNDELTEN Trades (je Minute und Richtung), unbegrenzt
-- Masterregel Sperre: dauerhaft gesperrte Konten (automatisch ab SPERRE_TRADES_TAG gebündelten Trades/24 h oder manuell;
-- status 'frei' = bei der Neubewertung nach dem Basiswechsel 23.13 freigegeben)
CREATE TABLE IF NOT EXISTS konto_status (
    addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL);
CREATE TABLE IF NOT EXISTS fill_zaehler_h (addr TEXT, stunde INTEGER, n INTEGER, n_trades INTEGER, PRIMARY KEY (addr, stunde));
CREATE TABLE IF NOT EXISTS pool_accounts (
    addr TEXT PRIMARY KEY, seit INTEGER, zuletzt_erfuellt INTEGER, account_value REAL, vlm_1d REAL, vlm_7d REAL,
    pnl_7d REAL, roi_7d REAL, name TEXT, aktualisiert INTEGER, pnl_1d REAL, roi_1d REAL, pnl_30d REAL, roi_30d REAL);
CREATE TABLE IF NOT EXISTS pool_accounts_hist (
    addr TEXT, ts INTEGER, account_value REAL, pnl_1d REAL, roi_1d REAL, pnl_7d REAL, roi_7d REAL, vlm_1d REAL,
    PRIMARY KEY (addr, ts));
CREATE TABLE IF NOT EXISTS pool_fills_hourly (
    addr TEXT, stunde INTEGER, coin TEXT, market TEXT, n_trades INTEGER, n_fills INTEGER, buy_usd REAL, sell_usd REAL,
    closed_pnl REAL, fee REAL, PRIMARY KEY (addr, stunde, coin, market));
CREATE INDEX IF NOT EXISTS ix_pfh_stunde ON pool_fills_hourly(stunde);
CREATE TABLE IF NOT EXISTS lb_fills_daily (
    day TEXT, addr TEXT, coin TEXT, buy_usd REAL, sell_usd REAL, n INTEGER, closed_pnl REAL, fee REAL,
    PRIMARY KEY (day, addr, coin));
CREATE TABLE IF NOT EXISTS book_summary_1m (
    ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL,
    bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));
CREATE TABLE IF NOT EXISTS lb_stats (
    addr TEXT PRIMARY KEY, ts INTEGER, account_value REAL,
    pnl_1d REAL, roi_1d REAL, vlm_1d REAL,
    pnl_7d REAL, roi_7d REAL, vlm_7d REAL,
    pnl_30d REAL, roi_30d REAL, vlm_30d REAL,
    pnl_all REAL, roi_all REAL, vlm_all REAL
);
CREATE TABLE IF NOT EXISTS lb_positions (
    ts INTEGER, rank INTEGER, addr TEXT, coin TEXT, side TEXT, size REAL,
    pos_value REAL, entry_px REAL, liq_px REAL, leverage REAL, upnl REAL, mark_px REAL,
    PRIMARY KEY (ts, addr, coin)
);
CREATE INDEX IF NOT EXISTS ix_lb_pos_ts ON lb_positions(ts);
-- Käufe/Verkäufe (Perp und Spot) und Spot-Bestände der Leaderboard-Konten, stündlich
CREATE TABLE IF NOT EXISTS lb_fills (
    ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT,
    px REAL, sz REAL, notional REAL, closed_pnl REAL, fee REAL, tid INTEGER,
    buy INTEGER,                      -- 1 = Kaufdruck (Open Long, Close Short, Spot-Buy), 0 = Verkaufsdruck
    PRIMARY KEY (addr, tid)
);
CREATE INDEX IF NOT EXISTS ix_lb_fills_ts ON lb_fills(ts);
-- Abholstand je Konto. NICHT aus lb_fills ableitbar: Gespeichert werden nur Fills ab
-- lb_fills_min_usd. Ein Konto, dessen Fills alle darunter liegen, hätte sonst nie einen
-- neueren Eintrag -- die Abholung liefe für immer gegen dieselbe Stelle.
CREATE TABLE IF NOT EXISTS lb_cursor (addr TEXT PRIMARY KEY, ts INTEGER, updated INTEGER);
-- Übersprungene Zeiträume: Wenn ein Konto schneller handelt, als wir Fills abholen können,
-- springt die Abholung nach vorn. Der übersprungene Bereich wird hier festgehalten -- eine
-- Lücke, von der man weiß, ist brauchbar; eine unbekannte Lücke verfälscht jede Auswertung.
CREATE TABLE IF NOT EXISTS lb_gaps (addr TEXT PRIMARY KEY, von INTEGER, bis INTEGER, erkannt INTEGER);
-- Verbrauchtes API-Gewicht je Minute und Verbraucher. Ohne Verlauf sieht man nur den
-- Augenblickswert und kann weder Spitzen noch Verdrängung erkennen.
CREATE TABLE IF NOT EXISTS api_load (ts INTEGER, quelle TEXT, weight INTEGER, PRIMARY KEY (ts, quelle));
CREATE INDEX IF NOT EXISTS ix_api_load_ts ON api_load(ts);
CREATE INDEX IF NOT EXISTS ix_lb_fills_coin ON lb_fills(coin, ts);
CREATE TABLE IF NOT EXISTS lb_spot (
    ts INTEGER, addr TEXT, token TEXT, coin TEXT, total REAL, hold REAL, entry_ntl REAL, value_usd REAL,
    PRIMARY KEY (ts, addr, token)
);
-- Anzeigenamen aus dem Leaderboard (nur Konten mit gesetztem Namen), für die Wallet-Zuordnung
CREATE TABLE IF NOT EXISTS lb_names (addr TEXT PRIMARY KEY, name TEXT, account_value REAL, ts INTEGER);
-- Ereignisse der Leaderboard-Konten, abgeleitet aus dem Vergleich zweier Positionsstände
CREATE TABLE IF NOT EXISTS lb_events (
    ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT, delta_usd REAL, pos_value REAL, mark_px REAL,
    PRIMARY KEY (ts, addr, coin)
);
CREATE INDEX IF NOT EXISTS ix_lb_events_coin_ts ON lb_events(coin, ts);
CREATE INDEX IF NOT EXISTS ix_lb_events_ts ON lb_events(ts);   -- Aufräumen nach Zeit ohne Vollscan
CREATE TABLE IF NOT EXISTS lb_trend (
    ts INTEGER, coin TEXT, top_n INTEGER, n_long INTEGER, n_short INTEGER,
    usd_long REAL, usd_short REAL, net_usd REAL, n_accounts INTEGER, mark_px REAL,
    PRIMARY KEY (ts, coin, top_n)
);

-- Qualitätsstempel je Snapshot: erlaubt später, schwache Snapshots auszuschließen
CREATE TABLE IF NOT EXISTS snapshot_meta (
    ts             INTEGER PRIMARY KEY,
    n_addresses    INTEGER,   -- bekannte Adressen insgesamt
    n_with_pos     INTEGER,   -- davon mit offener Position
    n_positions    INTEGER,   -- in den Snapshot eingegangene Positionen
    n_stale_dropped INTEGER,  -- wegen Überalterung ausgeschlossen
    age_median     INTEGER,   -- Sekunden seit letzter Abfrage, Median
    age_p90        INTEGER,
    backlog        INTEGER,   -- überfällige Adressen
    uptime         INTEGER    -- Sekunden seit Prozessstart: klein = nach Neustart
);

CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


def impact_aus(roh) -> tuple:
    """
    23.96 (U246): (Impact-Geld, Impact-Brief) aus dem Feld impactPxs der Börse oder (None, None). Angenommen wird nur ein Paar
    endlicher, positiver Zahlen -- alles andere (Feld fehlt, null, Text, ein Wert, 0, negativ) gilt als nicht geliefert. Ob das Paar
    zur Buchmitte passt (Geld <= Mitte <= Brief), prüft erst die Auswertung und zählt die Ausnahmen; hier wird nichts zurechtgebogen.
    """
    try:
        if not isinstance(roh, (list, tuple)) or len(roh) != 2:
            return None, None
        b, a = float(roh[0]), float(roh[1])
    except (TypeError, ValueError):
        return None, None
    if not (math.isfinite(b) and math.isfinite(a)) or b <= 0 or a <= 0:
        return None, None
    return b, a


AUSGELASSEN_REST = "übrige"                                # 23.112 (U272): Sammelname für Coins außerhalb der eingestellten


def ausgelassen_zaehlen(alt: dict, positions) -> None:
    """
    23.112 (U272): Größe der Positionen, die write_snapshot wegen Alters auslässt, je Coin: [Anzahl, Größe in Coins, USD]. Größe und USD
    nur von Positionen mit Liquidationspreis über 0 -- dieselbe Bedingung, unter der eine frische Position im Stand steht und zur
    Abdeckung zählt; die Größe als Betrag (Shorts tragen ein Minus). USD = letzter bekannter Positionswert (pos_value). Die Werte sind
    so alt wie die letzte Abfrage: Die Position kann inzwischen kleiner, größer oder geschlossen sein.
    """
    for p in positions:
        e = alt.setdefault(p.get("coin") or "?", [0, 0.0, 0.0])
        e[0] += 1
        if (p.get("liq_px") or 0) > 0:
            e[1] += abs(p.get("size") or 0.0)
            e[2] += abs(p.get("pos_value") or 0.0)


def ausgelassen_json(alt: dict, now: int, max_alter: int, coins) -> str:
    """
    23.112 (U272): Meta-Wert 'ausgelassen' -- {"ts", "max_alter", "coins": {Coin: {"n", "groesse", "usd"}}}. Die eingestellten Coins
    einzeln (auch mit 0), alle übrigen zusammen unter „übrige“ -- dort nur Anzahl und USD, denn Größen verschiedener Coins lassen sich
    nicht addieren.
    """
    out = {}
    for c in sorted(coins):
        n, g, u = alt.get(c, (0, 0.0, 0.0))
        out[c] = {"n": int(n), "groesse": round(float(g), 6), "usd": round(float(u), 2)}
    rest = [v for c, v in alt.items() if c not in out]
    if rest:
        out[AUSGELASSEN_REST] = {"n": int(sum(v[0] for v in rest)), "groesse": None, "usd": round(float(sum(v[2] for v in rest)), 2)}
    return json.dumps({"ts": int(now), "max_alter": int(max_alter), "coins": out}, ensure_ascii=False, sort_keys=True)


def symbole_ablegen(con, symbol_of: dict, dex_of: dict, jetzt: float | None = None) -> bool:
    """
    23.97 (U250): Zuordnung Coin -> Symbol und Dex in meta['symbole'] ablegen, damit andere Dienste denselben Markt abfragen wie der
    Recorder: {"ts": …, "coins": {Coin: {"symbol": …, "dex": …}}} (dex leer = Haupt-Dex). Die Notbremse fragte XMR bis 23.96 an einem
    fest eingetragenen Dex „felix“ ab, den es nicht gibt, und lief seit dem 23.10. ohne XMR. Eine leere Zuordnung (Börse beim Start
    nicht erreichbar) überschreibt die vorige nicht; ein Schreibfehler hält den Start nicht auf. -> True, wenn geschrieben wurde.
    """
    if not symbol_of:
        return False
    daten = {"ts": int(jetzt if jetzt is not None else time.time()),
             "coins": {str(c): {"symbol": str(sym), "dex": str(dex_of.get(sym) or "")} for c, sym in sorted(symbol_of.items())}}
    try:
        con.execute("INSERT OR REPLACE INTO meta VALUES ('symbole', ?)", (json.dumps(daten),))
        con.commit()
        return True
    except sqlite3.Error:
        try:
            con.rollback()
        except sqlite3.Error:
            pass
        return False


def db_connect(path: str = DB_PATH, synchronous: str = "NORMAL") -> sqlite3.Connection:
    # isolation_level="IMMEDIATE": Jede Schreibtransaktion holt sich die Schreibsperre beim
    # Beginn (BEGIN IMMEDIATE). Mit dem Python-Standard (verzögert) las der Recorder erst, schrieb
    # dann -- und wenn dazwischen ein anderer Dienst geschrieben hatte, lieferte SQLite im
    # WAL-Modus SOFORT "database is locked" (Snapshot-Konflikt), ohne busy_timeout abzuwarten.
    # Seit dem Sammler der Fremdbörsen (14.09.) traf das den Poller mehrmals je Stunde.
    # Jetzt wartet der Recorder bei fremder Sperre (busy_timeout), statt zu scheitern.
    # Prozessübergreifende Schreibsperre (hl_dbcoord): vom ersten schreibenden Statement bis
    # zum Commit hält dieser Prozess die Sperre; andere Schreiber warten geordnet, statt gegen
    # SQLites unfairen Busy-Handler anzulaufen. Auch der WAL-Checkpoint läuft darunter.
    import hl_dbcoord
    con = sqlite3.connect(path, timeout=30, isolation_level="IMMEDIATE", factory=hl_dbcoord.KoordinierteVerbindung)
    con.koordination(path, "recorder")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute(f"PRAGMA synchronous={synchronous}")
    # Ausdrücklich und großzügig: Bei drei schreibenden Diensten und einem lesenden
    # Dashboard kommt es zwangsläufig zu kurzen Sperren. Lieber eine Minute warten als
    # eine Aufgabe abstürzen lassen -- ein Absturz kostet Daten, das Warten nur Zeit.
    con.execute("PRAGMA busy_timeout=60000")
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    con.executescript(SCHEMA)
    # Migration älterer Datenbanken
    cols = {r[1] for r in con.execute("PRAGMA table_info(addresses)")}
    if "dexes" not in cols:
        con.execute("ALTER TABLE addresses ADD COLUMN dexes TEXT DEFAULT ''")
    if "pos_value" not in cols:
        con.execute("ALTER TABLE addresses ADD COLUMN pos_value REAL DEFAULT 0")
    if "account_value" not in cols:
        con.execute("ALTER TABLE addresses ADD COLUMN account_value REAL DEFAULT 0")     # Phase 1: Kontowert (marginSummary)
    pcols = {r[1] for r in con.execute("PRAGMA table_info(pool_accounts)")}
    for c_, t_ in (("pnl_1d", "REAL"), ("roi_1d", "REAL"), ("pnl_30d", "REAL"), ("roi_30d", "REAL")):
        if pcols and c_ not in pcols:
            con.execute(f"ALTER TABLE pool_accounts ADD COLUMN {c_} {t_}")
    # Bestehende Positionen ohne Positionswert: Notional als Näherung übernehmen,
    # sonst gelten alle bis zur nächsten Abfrage als Staub -- auch die Wale.
    con.execute("UPDATE addresses SET pos_value = notional "
                "WHERE pos_value = 0 AND notional > 0")
    # lb_fills: Spalte buy nachziehen (ältere Datenbanken) und einmalig füllen
    fcols = {r[1] for r in con.execute("PRAGMA table_info(lb_fills)")}
    if fcols and "buy" not in fcols:
        con.execute("ALTER TABLE lb_fills ADD COLUMN buy INTEGER")
        con.execute("""UPDATE lb_fills SET buy = CASE
            WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1
            WHEN lower(dir) LIKE '%open short%' OR lower(dir) LIKE '%close long%' OR lower(dir) LIKE '%sell%' THEN 0
            WHEN upper(side) LIKE 'B%' THEN 1 ELSE 0 END WHERE buy IS NULL""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_lb_fills_coin_ts_buy ON lb_fills(coin, ts, buy)")   # nach der Migration, für neue wie alte Datenbanken
    hcols = {r[1] for r in con.execute("PRAGMA table_info(heatmap)")}
    if "lev_wavg" not in hcols:
        con.execute("ALTER TABLE heatmap ADD COLUMN lev_wavg REAL")
        con.execute("ALTER TABLE heatmap ADD COLUMN entry_wavg REAL")
    if "cross_share" not in hcols:
        con.execute("ALTER TABLE heatmap ADD COLUMN cross_share REAL")
    # 23.13 (U31): Masterregel auf gebündelte Trades -- Zählerspalte und Sperrbeleg nachziehen (alte Zeilen: NULL = nicht gezählt)
    zcols = {r[1] for r in con.execute("PRAGMA table_info(fill_zaehler_h)")}
    if zcols and "n_trades" not in zcols:
        con.execute("ALTER TABLE fill_zaehler_h ADD COLUMN n_trades INTEGER")
    kcols = {r[1] for r in con.execute("PRAGMA table_info(konto_status)")}
    if kcols and "trades_tag" not in kcols:
        con.execute("ALTER TABLE konto_status ADD COLUMN trades_tag REAL")
    con.commit()
    return con


# ---------------------------------------------------------------------------
# Rate-Limiter
# ---------------------------------------------------------------------------

HL_WEIGHT_BUDGET = 1200          # Hyperliquid: Gewichtseinheiten je Minute und IP
WEIGHT_STATE = 2                 # clearinghouseState, l2Book, allMids ...
WEIGHT_OTHER = 20                # frontendOpenOrders, meta und der Rest
# Rang am Begrenzer (klein = zuerst): Leaderboard-Stände sind das schnellste Positionssignal und
# billig (2 Gewicht) -- sie dürfen nie hinter 20-Gewicht-Orderabfragen warten. Fills sind seit dem
# Trade-Stream ein Nachtrag und laufen im Hintergrund.
PRIO_BY_QUELLE = {"Leaderboard": 0, "Poller": 1, "Orders": 1, "sonstiges": 1, "Tiefe": 1, "Fills": 3}   # Tiefe: 23.125 (U311)
RESERVE_ANTEIL = 0.20            # Anteil des Budgets nur für Rang >= 2 (Fills): 20 % von 1.080 = 216/min (17.09.: 15 % von 1.020 plus die fünf Punkte vom Deckel); ein Lauf von 1.600 Gewicht in ~7,5 min
# Achtung: userFillsByTime, recentTrades, historicalOrders, fundingHistory und weitere kosten
# zusätzlich 1 je 20 gelieferter Einträge; candleSnapshot 1 je 60. Nachgeschlagen 13.09.2026:
# https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/rate-limits-and-user-limits


class RateLimiter:
    """
    Token-Bucket in GEWICHT je Minute, nicht in Requests: Eine Positionsabfrage
    kostet 2, eine Order-Abfrage 20. Dazu ein 60-s-Fenster, das die tatsächlich
    verbrauchten Einheiten zählt -- das ist die Zahl, die das Dashboard zeigt.
    23.38: Das Fenster ist zugleich ein HARTER Deckel. Die Eimer allein erlaubten in 60 s Rate × 60 plus ihren Füllstand
    (180 + 216): nach jedem Start rund 1.470 in der ersten Minute (über Hyperliquids 1.200), im Betrieb bis ~1.120
    (Bericht 30.09.: 1.092/1.080). Jetzt wird nur vergeben, was im gleitenden 60-s-Fenster unter dem wirksamen Deckel
    (Budget × Temperaturfaktor) bleibt; fehlt dem Ersten der Schlange der Platz, überholt ihn niemand (sonst verhungerten
    die 20er-Abfragen hinter den 2ern). Simulation mit der Last vom 30.09.: Fenster-Maximum 1.118 -> 1.080, Durchsatz gleich.
    """

    def __init__(self, weight_per_min: int):
        self.base_rate = weight_per_min / 60.0
        self.rate = self.base_rate
        self.scale = 1.0
        self.capacity = max(weight_per_min / 6.0, 20.0)
        self.tokens = 0.0                     # 23.38: leer starten -- der vorige Prozess hat in derselben Minute vielleicht schon verbraucht
        self.last = time.monotonic()
        self.window: deque = deque()          # (Zeit, Gewicht) der letzten 60 s
        self._fenster_summe = 0               # 23.38: laufende Summe des Fensters (harter Deckel)
        # Warteschlange MIT RANG (17.09.): Bisher eine FIFO-Sperre -- die 2-Gewicht-Abfrage der 75
        # wichtigsten Konten stand hinter jeder 20-Gewicht-Orderabfrage an. Poller (640/min) und
        # Wal-Orders (320/min) füllten 94 % des Budgets; Leaderboard-Stände brauchten 280 s, Fills
        # 660 s. Jetzt: Heap nach (Rang, Reihenfolge); ein Verteiler bedient den ranghöchsten
        # Wartenden, sobald genug Gewicht da ist. Rang 0 Leaderboard, 1 Poller/Orders, 3 Fills.
        self._heap: list = []
        self._seq = 0
        self._verteiler: asyncio.Task | None = None
        self.wait_total: float = 0.0
        self.wait_by: dict = {}               # Rang -> (Wartezeit gesamt, Zahl)
        # Reserve (17.09., zweiter Befund): Ein reiner Rang lässt den Letzten verhungern -- bei 80 %
        # Auslastung durch Poller/Orders wurde der Fill-Lauf nach dem Neustart nie fertig. Deshalb
        # ein eigener Eimer, aus dem NUR Rang >= 2 schöpft (RESERVE_ANTEIL des Budgets); der
        # Haupteimer wird um diesen Anteil kleiner, die Summe bleibt am Budget. Rang 0/1 sehen nur
        # den Haupteimer; Rang >= 2 nimmt, was von beiden zuerst reicht.
        self.reserve_rate = self.base_rate * RESERVE_ANTEIL
        self.rate = self.base_rate * (1 - RESERVE_ANTEIL)
        self.reserve_tokens = 0.0
        self.reserve_cap = self.reserve_rate * 60

    async def acquire(self, weight: int = WEIGHT_STATE, prio: int = 1) -> None:
        weight = max(1, min(int(weight), int(self.capacity)))       # V5-M4: mehr als die Kapazität wäre nie erfüllbar
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self._seq += 1
        heapq.heappush(self._heap, (prio, self._seq, weight, fut))
        if self._verteiler is None or self._verteiler.done():
            self._verteiler = loop.create_task(self._verteile())
        t0 = time.monotonic()
        try:
            await fut
        except asyncio.CancelledError:
            self._heap = [e for e in self._heap if e[3] is not fut]; heapq.heapify(self._heap)
            raise
        w = time.monotonic() - t0
        self.wait_total += w
        alt = self.wait_by.get(prio, (0.0, 0)); self.wait_by[prio] = (alt[0] + w, alt[1] + 1)

    async def _verteile(self) -> None:
        """
        Bedient die Warteschlange: der ranghöchste Wartende zuerst; kann er (Rang 0/1) nicht, weil
        der Haupteimer leer ist, darf ein Wartender mit Rang >= 2 aus der Reserve ziehen -- so
        verhungert der Hintergrund nicht, und der Vordergrund wartet nie auf die Reserve.
        Endet, wenn die Schlange leer ist (wird bei Bedarf neu gestartet).
        """
        while self._heap:
            now = time.monotonic()
            dt = now - self.last
            br = 0.5 if now < self.drossel_bis else 1.0                    # M6: 429-Drossel
            self.tokens = min(self.capacity, self.tokens + dt * self.rate * br)
            self.reserve_tokens = min(self.reserve_cap, self.reserve_tokens + dt * self.reserve_rate * br)
            self.last = now
            bedient = False
            deckel = self.deckel()
            platz = deckel - self._fenster(now)                                # 23.38: harter Deckel im gleitenden 60-s-Fenster
            ueber = self.tokens + self.reserve_tokens - max(platz, 0.0)
            if ueber > 0:                                                      # Eimer nie über den Platz im Fenster füllen: sonst sammeln
                k_ = min(self.tokens, ueber); self.tokens -= k_; ueber -= k_  # sie während einer Sperre an und entladen sich, sobald ein
                self.reserve_tokens = max(0.0, self.reserve_tokens - ueber)   # Klumpen aus dem Fenster fällt (Schwall, dann Stillstand)
            kopf_offen = True; fehlt = 0.0
            # Analyse v6 U2: Vorher wurden nur die acht Vordersten geprüft -- hinter 23 parallelen Poller-
            # Abfragen lag ein wartender Fill-Aufruf nie im Fenster, die Reserve verfiel. Jetzt der ganze
            # Heap (klein, < 100). Und: Der Vordergrund darf die Reserve nutzen, soweit sie über den
            # SOFORTIGEN Bedarf des Hintergrunds hinausgeht (bg_bedarf) -- Garantie bleibt, nichts liegt brach.
            bg_bedarf = sum(e[2] for e in self._heap if e[0] >= 2 and not e[3].done())
            for idx, (prio, seq, weight, fut) in enumerate(sorted(self._heap)):
                if fut.done():
                    continue
                if min(weight, deckel) > platz:                                  # (größer als der ganze Deckel: nur bei leerem Fenster)
                    if kopf_offen:
                        fehlt = min(weight, deckel) - platz
                        break                                                # dem Ersten fehlt der Platz: niemand überholt ihn
                    continue
                kopf_offen = False
                if self.tokens >= weight:
                    self.tokens -= weight
                elif prio >= 2 and self.reserve_tokens >= weight:
                    self.reserve_tokens -= weight
                elif prio < 2 and self.reserve_tokens >= weight + bg_bedarf:
                    self.reserve_tokens -= weight
                else:
                    continue
                self._heap.remove((prio, seq, weight, fut)); heapq.heapify(self._heap)
                self.window.append((now, weight)); self._fenster_summe += weight
                fut.set_result(None)
                bedient = True
                break
            if bedient:
                continue
            self._heap = [e for e in self._heap if not e[3].done()]; heapq.heapify(self._heap)
            if not self._heap:
                break
            if fehlt > 0:                                                    # warten, bis genug aus dem Fenster fällt
                frei_ab, acc = now, 0.0
                for t_, w_ in self.window:
                    acc += w_; frei_ab = t_ + 60
                    if acc >= fehlt:
                        break
                await asyncio.sleep(min(0.05, max(0.005, frei_ab - now)))
                continue
            kopf = self._heap[0]
            rate_eff = self.rate + (self.reserve_rate if (kopf[0] >= 2 or bg_bedarf == 0) else 0.0)
            await asyncio.sleep(min(0.05, max(0.005, (kopf[2] - self.tokens) / max(rate_eff, 1e-6))))   # feine Körnung: Rang 0 wartet nie auf den Schlaf eines 20ers

    def wartend(self) -> int:
        return sum(1 for e in self._heap if not e[3].done())

    drossel_bis: float = 0.0            # M6: nach 429 bis zu diesem Zeitpunkt (monotonic) halbes Tempo

    def set_scale(self, factor: float) -> None:
        """Budget je Minute skalieren (Temperaturschutz): 0,85 = 15 % weniger Gewicht."""
        self.scale = max(0.1, min(1.0, factor))
        self.rate = self.base_rate * self.scale * (1 - RESERVE_ANTEIL)
        self.reserve_rate = self.base_rate * self.scale * RESERVE_ANTEIL

    def _fenster(self, now: float) -> int:
        """Summe der Vergaben im gleitenden 60-s-Fenster (ältere fallen heraus)."""
        cut = now - 60
        while self.window and self.window[0][0] < cut:
            self._fenster_summe -= self.window.popleft()[1]
        return self._fenster_summe

    def deckel(self) -> float:
        """23.38: wirksamer Deckel je 60 s -- Budget × Temperaturfaktor (wie meta 'api_weight_budget')."""
        return (self.rate + self.reserve_rate) * 60

    def used_last_minute(self) -> int:
        return self._fenster(time.monotonic())


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------

@dataclass
class Settings:
    coins: list[str]  # Klarnamen, Symbole werden aufgelöst
    bucket_pct: float = 0.0025      # Bucket-Breite = 0.25 % des Kurses
    snapshot_sec: int = 600         # Heatmap alle 10 Minuten schreiben
    flush_sec: int = 30             # Commit-Takt: begrenzt den Verlust bei Stromausfall (30 s: weniger Schreibverstärkung)
    synchronous: str = "NORMAL"     # FULL = jeder Commit sofort auf Platte
    polls_per_min: int = DEFAULT_POLLS_PER_MIN
    max_addresses: int = 20_000
    # Vier Stufen nach Positionswert zum Markpreis. Das Budget fließt nach
    # oben: Wale werden fast live verfolgt, Staub gar nicht mehr regelmäßig.
    whale_notional: float = 20_000_000   # Polling-Stufe: ab hier 60-s-Takt (Kontowert)
    whale_refresh: int = 60
    lb_top: int = 75                     # Leaderboard: so viele Konten MIT Perp-Positionen werden verfolgt
    lb_candidates: int = 600             # ... aus den besten N nach 30-Tage-PnL ausgewählt
    lb_interval: int = 120               # ... alle 2 min (Gewicht 2 je Konto, ~75 Konten = 75/min); bei freiem Budget 90 s
    lb_min_value: float = 250_000        # ... Kontowert mindestens
    lb_flat_ttl: int = 3600              # flache Konten erst nach dieser Zeit erneut prüfen
    lb_rank_interval: int = 3600         # das (40 MB große) Leaderboard nur stündlich laden; Positionen alle lb_interval
    lb_fills_interval: int = 900         # Käufe/Verkäufe und Spot-Bestände der Top-Konten: alle 15 min (bis 14.09. stündlich)
    lb_fills_days: int = 3               # ... rückwirkend beim ersten Mal; ältere Fills werden gelöscht
    lb_fills_pages: int = 3              # ... höchstens so viele Seiten à 2.000 Fills je Konto und Lauf
    lb_fills_weight: int = 6_000         # ... Gewichtsbudget je stündlichem Lauf (100/min im Schnitt)
    lb_fills_min_usd: float = 2_500      # ... nur Fills ab diesem Notional (Market-Maker-Staub bleibt draußen)
    event_min_usd: float = 25_000        # Wal-Ereignis ab dieser GEHANDELTEN Menge (Größenänderung x Kurs)
    lb_event_min_usd: float = 12_500     # dasselbe für Leaderboard-Konten
    whale_track: float = 10_000_000      # Wal-Tabelle: Konto ab diesem GESAMTWERT gilt als Wal (Hysterese: bis zur Hälfte)
    whale_pos_min: float = 1_000_000     # ... und von ihm werden alle Positionen ab diesem Wert protokolliert
    pool_pos_min: float = 50_000         # 23.27: Pool-Konten -- Positionen ab diesem Wert protokolliert (pool_positions)
    pool_event_min: float = 10_000       # ... und Größenänderungen ab diesem gehandelten Wert als Ereignis
    hot_notional: float = 500_000   # 23.86 (U220, Entscheidung Nutzer 26.10.): „groß“ erst ab 500.000 USD (bis 23.85: 250.000)
    hot_refresh: int = 180
    min_notional: float = 25_000    # darunter: „klein“ -- seit 23.86 nur nach eigenem Handel, sonst höchstens täglich (bis 23.85 alle 2 h)
    cold_refresh: int = 1800
    klein_nach_handel: bool = True  # 23.86 (U220): kleine Konten wie leere Adressen; False = wie bis 23.85 (--klein-regelmaessig)
    vorrang_usd: float = 25_000     # 23.86 (U220, Durchsicht): leere/kleine Konten, die seit ihrer letzten Abfrage so viel gehandelt haben,
                                    # kommen in Gruppe A vor alle fälligen Konten von Rang 1 (0 = aus) -- neue große Positionen warten
                                    # sonst in Gruppe C hinter den zuletzt Handelnden
    drop_after_misses: int = 5      # Adresse ohne Position mehrfach -> selten pollen
    max_pos_age: int = 3600         # ältere Positionsdaten gehen nicht in den Snapshot
    # Tick-Aufzeichnung bei Ereignissen
    tick_buffer_min: int = 30       # so viele Minuten Rohtrades bleiben im Speicher
    tick_pre_sec: int = 300         # Vorlauf, der beim Auslösen gesichert wird
    tick_post_sec: int = 600        # Nachlauf
    tick_move_pct: float = 0.010    # Auslöser: 1 % in 60 s ...
    tick_flash_pct: float = 0.004   # ... oder 0,4 % in 10 s ...
    tick_liq_burst: int = 5         # ... oder 5 Liquidations-Fills in 30 s
    backup_dir: str = "dbbackup"    # tägliches, verifiziertes Backup
    # Stop-/Trigger-Orders der Wale
    stop_min_usd: float = 2.5e5     # Konten ab diesem Positionswert werden nach Orders gefragt
    # Gestaffelte Takte nach Positionswert: (ab USD, Sekunden). Bei ~1.200 Kandidaten
    # und 15 Abfragen/min ist ein einheitlicher Takt unmöglich; so bleiben Wale frisch
    # und die Kleinen laufen im Hintergrund durch (Summe ~770 Abfragen/h von 900).
    stop_tiers: tuple = ((20e6, 600), (5e6, 2700), (1e6, 10800), (5e5, 21600), (2.5e5, 21600))
    stop_interval: int = 600        # Takt der obersten Stufe (Wale), überschreibt stop_tiers[0]
    stop_interval_big: int = 21600  # Takt der untersten Stufe, überschreibt stop_tiers[-1]
    stop_weight_budget: int = 320   # Gewichtseinheiten/min für Order-Abfragen (16 Abfragen); Gesamtdeckel 90 % -- die Fill-Reserve ist eine Garantie, kein Abzug
    max_event_subs: int = 10        # userEvents-Abos: Hyperliquid erlaubt höchstens 10 verschiedene Nutzer je IP (Audit v10 K1; Doku "Rate limits and user limits")
    discover_all: bool = True       # Adressen aus ALLEN Perp-Feeds sammeln
    af_tage: int = 14               # 23.33 Adress-Strom (adressfluss.db): Vorhalt in Tagen, 0 = aus
    af_max_gb: float = 3.0          # ... Deckel für die belegten Seiten; darüber werden die ältesten Stunden gelöscht


def book_summary_verdichten_con(con, tage: int = 14) -> int:
    """
    Audit v3 S6 / v4 M3+L6: book_summary (5-s-Raster, ~100k Zeilen je Tag) älter als `tage` auf
    Minutenmittel verdichten (book_summary_1m, unbegrenzt) und löschen -- je 6-h-Fenster Einfügen
    UND Löschen in EINER Transaktion (ein Absturz dazwischen hinterlässt keine Teilmittel), bei
    Fehler Rollback. Läuft im Betrieb in einem Thread auf eigener Verbindung (siehe run_backup).
    """
    grenze = int(time.time()) - tage * 86_400
    lo = con.execute("SELECT MIN(ts) FROM book_summary WHERE ts < ?", (grenze,)).fetchone()[0]
    n = 0
    while lo is not None and lo < grenze:
        hi = min(grenze, lo + 6 * 3600)
        try:
            con.execute("""INSERT OR REPLACE INTO book_summary_1m
                           SELECT (ts / 60) * 60, coin, AVG(bid), AVG(ask), AVG(spread_bps), AVG(bid_10), AVG(ask_10), AVG(bid_25), AVG(ask_25),
                                  AVG(bid_50), AVG(ask_50), AVG(bid_100), AVG(ask_100), AVG(imb_50)
                           FROM book_summary WHERE ts >= ? AND ts < ? GROUP BY 1, 2""", (lo, hi))
            cur = con.execute("DELETE FROM book_summary WHERE ts >= ? AND ts < ?", (lo, hi))
            con.commit(); n += cur.rowcount
        except sqlite3.Error as e:
            try:
                con.rollback()
            except sqlite3.Error:
                pass
            print(f"  book_summary verdichten: {type(e).__name__}: {e} -- Rest beim nächsten Lauf", flush=True)
            return n
        lo = hi
    if n:
        print(f"  book_summary: {n:,} 5-s-Zeilen älter als {tage} Tage auf Minuten verdichtet", flush=True)
    return n


def book_summary_verdichten_datei(db_path: str, tage: int = 14) -> int:
    """Für asyncio.to_thread: eigene (koordinierte) Verbindung, damit die Ereignisschleife frei bleibt (Audit v4 M3)."""
    con = db_connect(db_path)
    try:
        return book_summary_verdichten_con(con, tage)
    finally:
        con.close()


# ---------------------------------------------------------------------------
# Tiefe des Buchs bis ±1 % (U311, 23.125)
# ---------------------------------------------------------------------------
# Das Abo „l2Book“ (on_book) liefert die Preisstufen ungerundet, je Seite liest der Recorder davon die obersten 10 -- bei BTC liegen
# sie wenige Dollar auseinander, bis −1 % (rund 600 Dollar) reicht das nie. Die Aufgabe „Buch-Tiefe“ fragt darum einmal je Minute und
# Coin das Buch mit gerundeten Preisstufen ab (Abfrage „l2Book“ mit nSigFigs: höchstens 20 Stufen je Seite, Gewicht 2; Dokumentation der
# Börse, nachgeschlagen am 25.11.2026) und hält die Gebote bis 1 % unter und die Forderungen bis 1 % über der Mitte fest. Eine eigene
# Abfrage statt eines zweiten Abos: Die Nachrichten des Buchs nennen die Rundung nicht, zwei Abos desselben Coins wären auf einer
# Verbindung nicht zu unterscheiden; eine Antwort je Minute kostet außerdem einen Bruchteil der Bandbreite eines Abos.
TIEFE_TAKT = 60                 # Sekunden zwischen zwei Abfragen je Coin (sechs Coins: 12 Gewicht je Minute, 1 % des Budgets)
TIEFE_STUFEN = 20               # so viele Stufen je Seite liefert die Börse höchstens
TIEFE_ABSTAND = 0.01            # gezählt wird bis 1 % unter (Gebote) bzw. über (Forderungen) der Mitte
TIEFE_TAGE = 35                 # so lange bleiben die Zeilen (das Radar vergleicht mit 30 Tagen)
TIEFE_MITTE_S = 60              # so alt darf die Mitte aus dem ungerundeten Buch sein; sonst die Mitte der gerundeten Antwort
TIEFE_GROB_S = 3600             # nach einer unvollständigen Antwort eine Stunde lang eine Stelle gröber
DEBUG_NR_TIEFE, DEBUG_NR_TIEFE_TEST = 165, 166      # Debug-Läufe recorder_tiefe (Bericht) und recorder_tiefe_test (hl_viz)


def tiefe_schritt(px: float, n: int) -> float:
    """Abstand der gerundeten Preisstufen bei n gültigen Stellen: 10 hoch (Stellen vor dem Komma − n) -- 59.181 mit 3 Stellen: 100;
    1.658 mit 4: 1; 0,52 mit 3: 0,001."""
    return 10.0 ** (math.floor(math.log10(float(px))) + 1 - int(n))


def tiefe_stellen(px) -> int | None:
    """
    nSigFigs der Abfrage: die feinsten Stufen (5 bis 2 Stellen), von denen 19 noch 1 % des Kurses überdecken -- die erste Stufe ist
    angebrochen, so reichen 20 gelieferte Stufen sicher bis −1 %. BTC bei 59.181: 3 Stellen (Stufen zu 100 USD, 0,17 %); ETH bei
    1.658: 4 Stellen (1 USD, 0,06 %); bis 1.900 bleibt es bei 4, darüber 3. Ohne Kurs: None (dann fragt die Aufgabe mit 3 Stellen --
    damit reichen 19 Stufen bei jedem Kurs über 2 %).
    """
    try:
        px = float(px)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(px) or px <= 0:
        return None
    for n in (5, 4, 3, 2):
        if (TIEFE_STUFEN - 1) * tiefe_schritt(px, n) >= TIEFE_ABSTAND * px * (1 - 1e-9):
            return n
    return 2


def tiefe_rechnen(levels, mitte) -> dict | None:
    """
    Aus der Antwort der Börse (levels = [Gebote, Forderungen], je höchstens 20 Stufen mit px und sz) und der Mitte: die Gebote mit einem
    Preis ab 99 % der Mitte und die Forderungen bis 101 % (USD: Preis der Stufe mal Menge), die Zahl der Stufen und ob eine Seite bis
    ±1 % vollständig ist -- weniger als 20 Stufen geliefert oder die letzte jenseits der Grenze. Eine Stufe genau auf der Grenze zählt.
    -> {"bid", "ask", "n_b", "n_a", "voll"} (voll: 1 = Gebote vollständig, 2 = Forderungen, 3 = beide) oder None (unlesbar, leere Seite).
    """
    try:
        m = float(mitte)
        if not (math.isfinite(m) and m > 0) or not isinstance(levels, (list, tuple)) or len(levels) != 2:
            return None
        bids = [(float(l["px"]), float(l["sz"])) for l in levels[0]]
        asks = [(float(l["px"]), float(l["sz"])) for l in levels[1]]
    except (TypeError, ValueError, KeyError):
        return None
    if not bids or not asks or not all(math.isfinite(p) and math.isfinite(z) and p > 0 and z >= 0 for p, z in bids + asks):
        return None
    lo, hi = m * (1 - TIEFE_ABSTAND), m * (1 + TIEFE_ABSTAND)
    voll_b = len(bids) < TIEFE_STUFEN or min(p for p, _ in bids) < lo
    voll_a = len(asks) < TIEFE_STUFEN or max(p for p, _ in asks) > hi
    return {"bid": float(sum(p * z for p, z in bids if p >= lo)), "ask": float(sum(p * z for p, z in asks if p <= hi)),
            "n_b": len(bids), "n_a": len(asks), "voll": (1 if voll_b else 0) | (2 if voll_a else 0)}


def _tiefe_zahl(x, nach: int = 0) -> str:
    """Deutsches Zahlenformat: 1.234,5"""
    s = f"{float(x):,.{nach}f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def _tiefe_usd(x) -> str:
    """12,3 Mio. USD · 850 Tsd. USD · — """
    try:
        x = float(x)
    except (TypeError, ValueError):
        return "—"
    if not math.isfinite(x):
        return "—"
    return _tiefe_zahl(x / 1e6, 1) + " Mio. USD" if abs(x) >= 1e6 else _tiefe_zahl(x / 1e3, 0) + " Tsd. USD"


def _tiefe_schritt_text(s) -> str:
    """100 USD · 1 USD · 0,1 USD · 0,001 USD"""
    s = float(s)
    nach = max(0, -int(math.floor(math.log10(s) + 1e-9)))
    return _tiefe_zahl(s, nach) + " USD"


def _tiefe_zeit(ts) -> str:
    return time.strftime("%d.%m. %H:%M UTC", time.gmtime(int(ts)))


def tiefe_text(con, jetzt: float | None = None) -> str:
    """Debug 165: was die Aufgabe „Buch-Tiefe“ festhält -- je Coin der jüngste Stand, die letzten 60 Minuten und 24 Stunden, zum Vergleich
    die obersten 10 Stufen des ungerundeten Buchs (book_summary). Liest nur."""
    jetzt = int(time.time() if jetzt is None else jetzt)
    z = []; a = z.append
    a(f"★ Recorder: Tiefe des Buchs bis ±1 % (U311, Debug {DEBUG_NR_TIEFE}) · Modul {VERSION_MODUL} · {_tiefe_zeit(jetzt)}")
    a("Je Minute und Coin eine Abfrage „l2Book“ mit gerundeten Preisstufen (höchstens 20 je Seite, Gewicht 2): gezählt sind die Gebote bis 1 %")
    a("  unter und die Forderungen bis 1 % über der Mitte. Gerundet wird auf die feinsten Stufen, die noch bis ±1 % reichen.")
    try:
        n_all, t_min, t_max = con.execute("SELECT COUNT(*), MIN(ts), MAX(ts) FROM book_tiefe").fetchone()
    except sqlite3.Error as e:
        a("")
        a("Die Tabelle book_tiefe fehlt -- der Recorder legt sie beim Start an (ab 23.125)." if "no such table" in str(e)
          else f"book_tiefe nicht lesbar ({type(e).__name__}: {e}).")
        return "\n".join(z)
    if not n_all:
        a("")
        a("Noch keine Zeile -- die Aufgabe „Buch-Tiefe“ schreibt sie ab dem Start des Recorders mit 23.125 (Dashboard: „Netzwerkstatus“).")
        return "\n".join(z)
    alter = jetzt - int(t_max)
    a(f"Zeilen: {_tiefe_zahl(n_all)} seit {_tiefe_zeit(t_min)} (aufbewahrt {TIEFE_TAGE} Tage) · jüngste {_tiefe_zeit(t_max)} (vor "
      + (f"{alter} s)" if alter < 120 else f"{alter // 60} min)")
      + (" -- die Aufgabe steht offenbar" if alter > 5 * TIEFE_TAKT else ""))
    coins = [r[0] for r in con.execute("SELECT coin FROM book_tiefe WHERE ts >= ? GROUP BY coin ORDER BY coin", (jetzt - 86_400,))]
    for coin in coins:
        r = con.execute("SELECT ts, nsig, schritt, mitte, bid_1, ask_1, stufen_b, stufen_a, voll FROM book_tiefe WHERE coin=? "
                        "ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        a("")
        voll = {3: "vollständig", 1: "Forderungen nicht bis +1 %", 2: "Gebote nicht bis −1 %", 0: "beide Seiten nicht bis ±1 %"}[int(r[8]) & 3]
        a(f"== {coin} · jüngster Stand ({_tiefe_zeit(r[0])}): Gebote bis −1 % {_tiefe_usd(r[4])} · Forderungen bis +1 % {_tiefe_usd(r[5])}")
        a(f"   Stufen zu {_tiefe_schritt_text(r[2])} ({int(r[1])} Stellen; {_tiefe_zahl(100 * float(r[2]) / float(r[3]), 2)} % der Mitte "
          f"{_tiefe_zahl(r[3], 2 if float(r[3]) < 100 else 0)}) · geliefert {int(r[6])} und {int(r[7])} Stufen · {voll}")
        for spanne, name in ((3600, "letzte 60 Minuten"), (86_400, "letzte 24 Stunden")):
            q = con.execute("SELECT COUNT(*), SUM(voll & 1), AVG(CASE WHEN voll & 1 THEN bid_1 END), MIN(CASE WHEN voll & 1 THEN bid_1 END), "
                            "MAX(CASE WHEN voll & 1 THEN bid_1 END) FROM book_tiefe WHERE coin=? AND ts > ?", (coin, jetzt - spanne)).fetchone()
            n_, nv_ = int(q[0] or 0), int(q[1] or 0)
            if not n_:
                a(f"   {name}: keine Abfrage")
                continue
            a(f"   {name}: {_tiefe_zahl(n_)} Abfragen, {_tiefe_zahl(nv_)} mit Geboten bis −1 % ({_tiefe_zahl(100 * nv_ / n_, 1)} %)"
              + (f" · Gebote im Mittel {_tiefe_usd(q[2])} (kleinste {_tiefe_usd(q[3])}, größte {_tiefe_usd(q[4])})" if nv_ else ""))
        try:
            b = con.execute("SELECT AVG(bid_100), COUNT(*) FROM book_summary WHERE coin=? AND ts > ? AND bid_100 > 0",
                            (coin, jetzt - 3600)).fetchone()
            if b and b[1]:
                a(f"   zum Vergleich die obersten 10 Stufen des ungerundeten Buchs (book_summary, bid_100), letzte 60 Minuten: {_tiefe_usd(b[0])}")
        except sqlite3.Error:
            pass
    a("")
    a("Lesart: Die Summe ist auf ganze Stufen genau -- eine Stufe an der Grenze zählt ganz oder gar nicht. Das Risikoradar (Debug 160) nimmt")
    a("  seit 23.125 diese Gebote für die Markttiefe (A6) und als Nenner der Liquidations-Nähe (A5); ihr Verlauf beginnt mit 23.125.")
    return "\n".join(z)


def tiefe_text_datei(pfad: str, jetzt: float | None = None) -> str:
    """Debug 165 von der Befehlszeile: öffnet hl_liq.db nur lesend (mode=ro) -- legt keine Tabelle an, ändert nichts (der gewöhnliche
    Weg über db_connect legt das Schema an und zieht Spalten nach). Fehlt die Datei oder ist sie nicht lesbar, eine Zeile mit dem Grund."""
    import urllib.parse
    kopf = f"★ Recorder: Tiefe des Buchs bis ±1 % (U311, Debug {DEBUG_NR_TIEFE}) · Modul {VERSION_MODUL}"
    if not os.path.isfile(pfad):
        return kopf + f"\nKein Ergebnis: {os.path.basename(pfad)} fehlt ({pfad})."
    try:
        con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(pfad)) + "?mode=ro", uri=True, timeout=30)
    except sqlite3.Error as e:
        return kopf + f"\nKein Ergebnis: {os.path.basename(pfad)} nicht lesbar ({type(e).__name__}: {e})."
    try:
        con.execute("PRAGMA busy_timeout=30000")
        return tiefe_text(con, jetzt)
    except sqlite3.Error as e:
        return kopf + f"\nKein Ergebnis: {os.path.basename(pfad)} nicht lesbar ({type(e).__name__}: {e})."
    finally:
        con.close()


def selbsttest_tiefe() -> bool:
    """
    U311 (23.125): Stellen und Stufen von Hand, Summen bis ±1 % mit den Grenzen, Vollständigkeit, Mitte, eine Runde der Aufgabe mit einer
    nachgebauten Abfrage (zweite Abfrage eine Stelle gröber, eine Stunde lang gröber), Schreiben in book_tiefe, Aufräumen nach 35 Tagen,
    Bericht (Debug 165), Vertrag mit Aufgabenliste, Gewicht und Schema. Temporäre Datenbank, kein Netz.
    """
    import tempfile
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_tiefe_")
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    def stufen(start, schritt, n, menge=1.0, ab=True):
        return [{"px": f"{start - i * schritt if ab else start + i * schritt:.6f}", "sz": f"{menge:.6f}", "n": 1} for i in range(n)]

    try:
        DB_PATH = os.path.join(tmp, "hl_liq.db")
        con = db_connect(DB_PATH)
        # T1 Stellen und Stufen von Hand
        f1 = [(59181, 3, 100.0), (1658, 4, 1.0), (1900, 4, 1.0), (1900.01, 3, 10.0), (59.2, 3, 0.1), (739.26, 3, 1.0), (511, 3, 1.0),
              (4100, 3, 10.0), (0.52, 3, 0.001), (1000, 4, 1.0)]
        t1 = [(px, tiefe_stellen(px), tiefe_schritt(px, tiefe_stellen(px))) for px, _, _ in f1]
        ok("T1 Stellen und Stufen von Hand: BTC 59.181 -> 3 Stellen (Stufen zu 100 USD), ETH 1.658 -> 4 (1 USD), genau 1.900 -> 4 "
           "(19 Stufen zu 1 USD sind genau 1 %), 1.900,01 -> 3 (10 USD), HYPE 59,2 -> 3 (0,1), ZEC 739,26 -> 3 (1), XMR 511 -> 3, PAXG 4.100 "
           "-> 3 (10), 0,52 -> 3 (0,001), 1.000 -> 4 (1); ohne Kurs, 0, negativ, NaN und Text: keine Stellen",
           all(n == e and abs(s - es) < 1e-12 for (px, n, s), (_, e, es) in zip(t1, f1))
           and all(tiefe_stellen(v) is None for v in (None, 0, -5, float("nan"), float("inf"), "x")),
           " · ".join(f"{px}:{n}/{s:g}" for px, n, s in t1))
        # T2 Summen bis ±1 % von Hand
        lv = [stufen(100.0, 0.1, 20, 2.0), stufen(100.1, 0.1, 20, 1.0, ab=False)]
        r2 = tiefe_rechnen(lv, 100.05)
        lo = 100.05 * 0.99; hi = 100.05 * 1.01
        soll_b = sum(float(s["px"]) * 2.0 for s in lv[0] if float(s["px"]) >= lo); soll_a = sum(float(s["px"]) for s in lv[1] if float(s["px"]) <= hi)
        grenze = [{"px": "99.0", "sz": "1"}, {"px": "98.99", "sz": "5"}]
        r2b = tiefe_rechnen([grenze, [{"px": "101", "sz": "1"}, {"px": "101.01", "sz": "3"}]], 100.0)
        ok("T2 Summen von Hand: Gebote ab 99 % der Mitte, Forderungen bis 101 %, je Preis der Stufe mal Menge; eine Stufe genau auf der "
           "Grenze zählt (99,00 und 101,00 bei Mitte 100), ein Cent dahinter nicht; leere Seite, unlesbare Stufe, NaN, negativer Preis, "
           "falsche Form und Mitte 0 geben nichts",
           r2 is not None and abs(r2["bid"] - soll_b) < 1e-6 and abs(r2["ask"] - soll_a) < 1e-6 and r2["n_b"] == 20 and r2["n_a"] == 20
           and r2b is not None and abs(r2b["bid"] - 99.0) < 1e-9 and abs(r2b["ask"] - 101.0) < 1e-9
           and tiefe_rechnen([[], lv[1]], 100) is None and tiefe_rechnen([lv[0], []], 100) is None
           and tiefe_rechnen([[{"px": "x", "sz": "1"}], lv[1]], 100) is None and tiefe_rechnen([[{"px": "nan", "sz": "1"}], lv[1]], 100) is None
           and tiefe_rechnen([[{"px": "-1", "sz": "1"}], lv[1]], 100) is None and tiefe_rechnen([lv[0]], 100) is None
           and tiefe_rechnen(lv, 0) is None and tiefe_rechnen(lv, None) is None and tiefe_rechnen(None, 100) is None,
           f"{r2['bid']:.4f} gegen {soll_b:.4f}; Grenze {r2b['bid']:.2f}/{r2b['ask']:.2f}" if r2 and r2b else "")
        # T3 Vollständigkeit
        v_eng = tiefe_rechnen([stufen(100.0, 0.01, 20), stufen(100.01, 0.01, 20, ab=False)], 100.005)       # 20 Stufen reichen nur 0,2 %
        v_kurz = tiefe_rechnen([stufen(100.0, 0.01, 19), stufen(100.01, 0.01, 7, ab=False)], 100.005)       # weniger als 20: alles da
        v_weit = tiefe_rechnen([stufen(100.0, 0.1, 20), stufen(100.1, 0.01, 20, ab=False)], 100.05)        # Gebote bis 98,1: vollständig
        v_rand = tiefe_rechnen([stufen(100.0, 0.05, 20), stufen(100.05, 0.05, 20, ab=False)], 100.025)     # letzte Stufe 99,05 >= 99,02
        ok("T3 Vollständigkeit je Seite: 20 Stufen, die nicht bis zur Grenze reichen -> unvollständig; weniger als 20 Stufen -> vollständig "
           "(mehr hat das Buch nicht); die letzte Stufe jenseits der Grenze -> vollständig; liegt die letzte noch diesseits, fehlt etwas",
           v_eng["voll"] == 0 and v_kurz["voll"] == 3 and v_weit["voll"] == 1 and v_rand["voll"] == 0,
           f"{v_eng['voll']} {v_kurz['voll']} {v_weit['voll']} {v_rand['voll']}")

        # Recorder mit nachgebauter Abfrage
        R = Recorder(con, Settings(coins=["BTC", "ETH", "XMR"], af_tage=0))
        R.symbol_of = {"BTC": "BTC", "ETH": "ETH", "XMR": "xyz:XMR"}; R.coin_of = {v: k for k, v in R.symbol_of.items()}
        R.dex_of = {"BTC": "", "ETH": "", "xyz:XMR": "xyz"}
        anfragen = []
        antwort = {}

        async def post_fake(payload, weighted=True, weight=WEIGHT_STATE, quelle="sonstiges"):
            anfragen.append((dict(payload), weight, quelle))
            f = antwort.get((payload.get("coin"), payload.get("nSigFigs")))
            return f() if callable(f) else f

        R.post = post_fake
        t0 = (int(time.time()) // 86_400 - 1) * 86_400 + 40          # gestern 00:00:40 UTC (das Aufräumen rechnet mit der Uhr)
        # T4 Mitte
        R.buch_mitte = {"BTC": (59_150.0, t0 - 60), "ETH": (1_658.0, t0 - 61)}
        ok("T4 Mitte: aus dem ungerundeten Buch, wenn sie höchstens 60 s alt ist (genau 60 s gilt); sonst keine -- dann die Mitte der "
           "gerundeten Antwort; on_book setzt sie bei jeder Nachricht, auch innerhalb desselben 30-s-Fensters",
           R.tiefe_mitte("BTC", t0) == 59_150.0 and R.tiefe_mitte("ETH", t0) is None and R.tiefe_mitte("XMR", t0) is None)
        R.on_book({"coin": "XMR", "time": t0 * 1000, "levels": [[{"px": "511.0", "sz": "1"}], [{"px": "511.4", "sz": "1"}]]})
        R.on_book({"coin": "XMR", "time": t0 * 1000 + 5000, "levels": [[{"px": "512.0", "sz": "1"}], [{"px": "512.4", "sz": "1"}]]})
        ok("T4b on_book merkt die Mitte je Nachricht (zweite Nachricht im selben 30-s-Fenster: 512,2)",
           abs((R.buch_mitte.get("XMR") or (0, 0))[0] - 512.2) < 1e-9 and (R.buch_mitte.get("XMR") or (0, 0))[1] == t0 + 5,
           str(R.buch_mitte.get("XMR")))
        R.buch_mitte = {"BTC": (59_150.0, t0 - 10), "ETH": (1_658.0, t0 - 10)}
        # Antworten: BTC mit 3 Stellen vollständig; ETH mit 4 Stellen unvollständig, mit 3 vollständig; XMR ohne Mitte -> 3 Stellen
        antwort[("BTC", 3)] = {"coin": "BTC", "time": t0 * 1000 + 25_000,             # die Antwort kommt in der nächsten Minute an
                               "levels": [stufen(59_100, 100, 20, 1.5), stufen(59_200, 100, 20, 1.0, ab=False)]}
        antwort[("ETH", 4)] = {"coin": "ETH", "time": t0 * 1000, "levels": [stufen(1_657, 0.5, 20, 10), stufen(1_659, 1, 20, 10, ab=False)]}
        antwort[("ETH", 3)] = {"coin": "ETH", "time": t0 * 1000, "levels": [stufen(1_650, 10, 20, 50), stufen(1_660, 10, 20, 50, ab=False)]}
        antwort[("xyz:XMR", 3)] = {"coin": "xyz:XMR", "time": t0 * 1000, "levels": [stufen(512, 1, 12, 3), stufen(513, 1, 9, 2, ab=False)]}
        n_r = asyncio.run(R.tiefe_runde(t0))
        rows = {r_[1]: r_ for r_ in R.tiefe_rows_pending}
        soll_btc = sum(float(s["px"]) * 1.5 for s in antwort[("BTC", 3)]["levels"][0] if float(s["px"]) >= 59_150 * 0.99)
        ok("T5 eine Runde: je Coin eine Abfrage „l2Book“ mit den Stellen zum Kurs (BTC 3, ETH 4, XMR ohne Mitte 3), dem Symbol der Börse "
           "(xyz:XMR), Gewicht 2, Quelle „Tiefe“; ETH unvollständig -> sofort eine zweite Abfrage mit 3 Stellen; je Coin eine Zeile im "
           "Minutenraster der Antwort (BTC: Zeit der Börse 25 s nach der Runde -> die nächste Minute) mit Stellen, Stufe, Mitte (XMR: Mitte der "
           "gerundeten Antwort), Summen, Stufenzahl und Vollständigkeit",
           n_r == {"zeilen": 3, "voll": 3} and [(p["coin"], p.get("nSigFigs"), w, q) for p, w, q in anfragen]
           == [("BTC", 3, 2, "Tiefe"), ("ETH", 4, 2, "Tiefe"), ("ETH", 3, 2, "Tiefe"), ("xyz:XMR", 3, 2, "Tiefe")]
           and all(p.get("type") == "l2Book" for p, _, _ in anfragen)
           and rows["BTC"][0] == (t0 + 25) // 60 * 60 == t0 // 60 * 60 + 60 and rows["BTC"][2] == 3 and rows["BTC"][3] == 100.0 and rows["BTC"][4] == 59_150.0
           and abs(rows["BTC"][5] - soll_btc) < 1e-6 and rows["BTC"][9] == 3 and rows["ETH"][2] == 3 and rows["ETH"][3] == 10.0
           and rows["ETH"][9] == 3 and abs(rows["XMR"][4] - 512.5) < 1e-9 and rows["XMR"][7] == 12 and rows["XMR"][8] == 9,
           f"{[(p['coin'], p.get('nSigFigs')) for p, _, _ in anfragen]}; BTC {rows.get('BTC')}")
        anfragen.clear(); R.tiefe_rows_pending = []
        asyncio.run(R.tiefe_runde(t0 + 60))
        n_eth_1 = [p.get("nSigFigs") for p, _, _ in anfragen if p["coin"] == "ETH"]
        anfragen.clear(); R.tiefe_rows_pending = []
        R.buch_mitte = {"BTC": (59_150.0, t0 + TIEFE_GROB_S - 5), "ETH": (1_658.0, t0 + TIEFE_GROB_S - 5)}
        asyncio.run(R.tiefe_runde(t0 + TIEFE_GROB_S - 1))
        n_eth_2 = [p.get("nSigFigs") for p, _, _ in anfragen if p["coin"] == "ETH"]
        anfragen.clear(); R.tiefe_rows_pending = []
        R.buch_mitte = {"BTC": (59_150.0, t0 + TIEFE_GROB_S), "ETH": (1_658.0, t0 + TIEFE_GROB_S)}
        asyncio.run(R.tiefe_runde(t0 + TIEFE_GROB_S))
        n_eth_3 = [p.get("nSigFigs") for p, _, _ in anfragen if p["coin"] == "ETH"]
        ok("T6 nach der unvollständigen Antwort fragt die Aufgabe für ETH eine Stunde lang gleich mit 3 Stellen (eine Abfrage statt zwei), "
           "genau nach einer Stunde wieder mit 4 (und dann wieder zweimal)", n_eth_1 == [3] and n_eth_2 == [3] and n_eth_3 == [4, 3],
           f"{n_eth_1} {n_eth_2} {n_eth_3}")
        # T7 Fehler: keine Antwort, unlesbare Antwort; die anderen Coins laufen weiter
        anfragen.clear(); R.tiefe_rows_pending = []; R.tiefe_grob = {}
        antwort[("BTC", 3)] = None
        antwort[("ETH", 4)] = {"coin": "ETH", "time": t0 * 1000, "levels": "kaputt"}
        def wirf():
            raise RuntimeError("Probe")
        antwort[("xyz:XMR", 3)] = wirf
        f0 = R.stats["tiefe_fehler"]
        n7 = asyncio.run(R.tiefe_runde(t0 + 120))
        ok("T7 ohne Antwort, mit unlesbarer Antwort oder mit einem Fehler bei einem Coin: keine Zeile für ihn, gezählt als Fehler, die "
           "anderen Coins laufen weiter (hier keiner); die Runde endet ohne Ausnahme", n7["zeilen"] == 0 and not R.tiefe_rows_pending
           and R.stats["tiefe_fehler"] - f0 == 3 and len(anfragen) == 3, f"{R.stats['tiefe_fehler'] - f0} Fehler, {len(anfragen)} Abfragen")
        # T8 Schreiben: flush_round legt die Zeilen in book_tiefe; dieselbe Minute ersetzt; bei gesperrter Datenbank bleiben sie
        R.tiefe_rows_pending = [(t0 // 60 * 60, "BTC", 3, 100.0, 59_150.0, 1.0e6, 9.0e5, 20, 20, 3),
                                (t0 // 60 * 60, "BTC", 3, 100.0, 59_150.0, 2.0e6, 9.0e5, 20, 20, 3),
                                (t0 // 60 * 60 + 60, "ETH", 4, 1.0, 1_658.0, 5.0e5, 4.0e5, 20, 20, 1)]
        R.flush_round()
        z8 = con.execute("SELECT ts, coin, nsig, schritt, mitte, bid_1, ask_1, stufen_b, stufen_a, voll FROM book_tiefe ORDER BY coin").fetchall()
        ok("T8 Schreiben: die Runde des Recorders legt die Zeilen in book_tiefe (alle zehn Spalten); eine zweite Zeile derselben Minute und "
           "desselben Coins ersetzt die erste; danach ist der Puffer leer", len(z8) == 2 and z8[0][1] == "BTC" and z8[0][5] == 2.0e6
           and z8[1][9] == 1 and not R.tiefe_rows_pending, str(z8))
        # T9 Aufräumen nach 35 Tagen (in der Runde, einmal am Tag)
        jetzt9 = time.time()
        con.executemany("INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)",
                        [(int(jetzt9) - 35 * 86_400 - 60, "BTC", 3, 100.0, 1.0, 1.0, 1.0, 20, 20, 3),
                         (int(jetzt9) - 35 * 86_400 + 3600, "BTC", 3, 100.0, 1.0, 1.0, 1.0, 20, 20, 3),
                         (int(jetzt9) - 20 * 86_400, "BTC", 3, 100.0, 1.0, 1.0, 1.0, 20, 20, 3)])
        con.commit()
        R._tiefe_prune_ts = 0.0; R.tiefe_rows_pending = [(int(jetzt9) // 60 * 60, "ETH", 4, 1.0, 1_658.0, 1.0, 1.0, 20, 20, 3)]
        R.flush_round()
        alt9 = con.execute("SELECT COUNT(*) FROM book_tiefe WHERE ts < ?", (int(jetzt9) - 35 * 86_400,)).fetchone()[0]
        jung9 = con.execute("SELECT COUNT(*) FROM book_tiefe WHERE ts >= ?", (int(jetzt9) - 35 * 86_400,)).fetchone()[0]
        R.tiefe_rows_pending = [(int(jetzt9) // 60 * 60 + 60, "ETH", 4, 1.0, 1_658.0, 1.0, 1.0, 20, 20, 3)]
        con.execute("INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (int(jetzt9) - 35 * 86_400 - 120, "XMR", 3, 1.0, 1.0, 1.0, 1.0, 20, 20, 3)); con.commit()
        R.flush_round()
        alt9b = con.execute("SELECT COUNT(*) FROM book_tiefe WHERE coin='XMR'").fetchone()[0]
        ok("T9 Aufräumen: einmal am Tag löscht die Runde Zeilen, die älter als 35 Tage sind; jüngere bleiben; binnen eines Tages wird nicht "
           "noch einmal gelöscht (die Zeilen von vor 20 und knapp 35 Tagen bleiben, dazu die zwei aus T8 und die neue)", alt9 == 0 and jung9 == 5
           and alt9b == 1, f"alt {alt9}, jung {jung9}, zweite Runde {alt9b}")
        # T10 Bericht
        con.execute("DELETE FROM book_tiefe"); con.commit()
        jetzt10 = t0 + 7200
        zeilen = []
        for i in range(120):
            ts_ = (jetzt10 - 7200 + i * 60) // 60 * 60
            zeilen.append((ts_, "BTC", 3, 100.0, 59_150.0, (1.0e7 + i * 1e4) if i % 10 else 9.0e9, 9.0e6, 20, 20, 3 if i % 10 else 2))   # unvollständig: 9 Mrd. zählen nicht
        con.executemany("INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)", zeilen)
        con.execute("CREATE TABLE IF NOT EXISTS book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, "
                    "ask_10 REAL, bid_25 REAL, ask_25 REAL, bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin))")
        con.execute("INSERT OR REPLACE INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (jetzt10 - 30, "BTC", 59_149, 59_151, 0.3, 0, 0, 0, 0, 0, 0, 1.4e6, 1.3e6, 0)); con.commit()
        txt = tiefe_text(con, jetzt10)
        h60 = [w_ for w_ in zeilen if w_[0] > jetzt10 - 3600]
        voll60 = [w_ for w_ in h60 if w_[9] & 1]
        mittel60 = sum(w_[5] for w_ in voll60) / len(voll60)
        ok("T10 Bericht (Debug 165): Kopf mit Modul, Zeilen und Alter der jüngsten, je Coin der jüngste Stand mit Stufen (100 USD, 3 Stellen, "
           "Anteil an der Mitte), die letzten 60 Minuten und 24 Stunden mit Abfragen, vollständigen Abfragen und Mittel der Gebote (nur "
           "vollständige), der Vergleich mit den obersten 10 Stufen; keine Zeile über 150 Zeichen",
           txt.startswith("★ Recorder: Tiefe des Buchs bis ±1 % (U311, Debug 165) · Modul " + VERSION_MODUL + " · ")
           and (DEBUG_NR_TIEFE, DEBUG_NR_TIEFE_TEST) == (165, 166) and "== BTC" in txt and "Stufen zu 100 USD (3 Stellen; 0,17 % der Mitte 59.150)" in txt
           and f"letzte 60 Minuten: {len(h60)} Abfragen, {len(voll60)} mit Geboten bis −1 %" in txt
           and f"Gebote im Mittel {_tiefe_usd(mittel60)}" in txt and "letzte 24 Stunden: 120 Abfragen, 108 mit Geboten bis −1 % (90,0 %)" in txt
           and "obersten 10 Stufen des ungerundeten Buchs (book_summary, bid_100), letzte 60 Minuten: 1,4 Mio. USD" in txt
           and max(len(l_) for l_ in txt.splitlines()) <= 150, f"{len(txt.splitlines())} Zeilen, längste {max(len(l_) for l_ in txt.splitlines())}")
        con.execute("DELETE FROM book_tiefe"); con.commit()
        leer = tiefe_text(con, jetzt10)
        con2 = sqlite3.connect(":memory:")
        fehlt = tiefe_text(con2, jetzt10); con2.close()
        ok("T10b Bericht ohne Zeilen und ohne Tabelle: sagt, dass noch nichts da ist bzw. die Tabelle fehlt (kein Absturz)",
           "Noch keine Zeile" in leer and "Die Tabelle book_tiefe fehlt" in fehlt)
        ok("T10c Zahlen im Bericht: 12,3 Mio. USD · 850 Tsd. USD · Stufen 100 USD, 1 USD, 0,1 USD, 0,001 USD",
           _tiefe_usd(12_345_678) == "12,3 Mio. USD" and _tiefe_usd(850_000) == "850 Tsd. USD" and _tiefe_usd(None) == "—"
           and [_tiefe_schritt_text(s_) for s_ in (100.0, 1.0, 0.1, 0.001)] == ["100 USD", "1 USD", "0,1 USD", "0,001 USD"],
           f"{_tiefe_usd(12_345_678)} {_tiefe_usd(850_000)} {[_tiefe_schritt_text(s_) for s_ in (100.0, 1.0, 0.1, 0.001)]}")
        # T11 Vertrag: Aufgabe in der Liste des Recorders, Quelle mit Rang, Schema
        import inspect
        quelltext = inspect.getsource(Recorder.run)
        spalten = [r_[1] for r_ in con.execute("PRAGMA table_info(book_tiefe)")]
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "install.py"), encoding="utf-8") as f_:
                inst = f_.read()
        except OSError:
            inst = ""
        ok("T11 Vertrag: die Aufgabe „Buch-Tiefe“ steht in der Liste, die der Recorder startet; die Quelle „Tiefe“ hat Rang 1 am Begrenzer; "
           "book_tiefe hat die zehn Spalten mit dem Schlüssel (ts, coin); das Gewicht je Abfrage ist 2; der Installer prüft diesen Selbsttest",
           '("Buch-Tiefe", self.run_tiefe)' in quelltext and PRIO_BY_QUELLE.get("Tiefe") == 1 and WEIGHT_STATE == 2
           and '[py, str(ROOT / "hl_recorder.py"), "--selbsttest-tiefe"]),' in inst
           and spalten == ["ts", "coin", "nsig", "schritt", "mitte", "bid_1", "ask_1", "stufen_b", "stufen_a", "voll"]
           and [r_[1] for r_ in con.execute("PRAGMA table_info(book_tiefe)") if r_[5]] == ["ts", "coin"], str(spalten))
        con.close()
        # T12 Befehlszeile (Debug 165) nur lesend: eine Datei mit book_tiefe, eine ohne, keine
        import hashlib as _hl, subprocess as _sp
        p12 = os.path.join(tmp, "nur_tiefe.db")
        c12 = sqlite3.connect(p12)
        c12.execute("CREATE TABLE book_tiefe (ts INTEGER, coin TEXT, nsig INTEGER, schritt REAL, mitte REAL, bid_1 REAL, ask_1 REAL, "
                    "stufen_b INTEGER, stufen_a INTEGER, voll INTEGER, PRIMARY KEY (ts, coin)) WITHOUT ROWID")
        c12.execute("INSERT INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)", (int(time.time()) // 60 * 60 - 120, "BTC", 3, 100.0, 59_150.0, 1.0e7, 9.0e6, 20, 20, 3))
        c12.commit(); c12.close()
        p12b = os.path.join(tmp, "ohne_tiefe.db")
        c12 = sqlite3.connect(p12b); c12.execute("CREATE TABLE x (a INTEGER)"); c12.commit(); c12.close()
        h12 = [_hl.sha1(open(q_, "rb").read()).hexdigest() for q_ in (p12, p12b)]
        r12 = _sp.run([sys.executable, os.path.abspath(__file__), "--tiefe-text", "--db", p12], capture_output=True, text=True, timeout=120)
        r12b = _sp.run([sys.executable, os.path.abspath(__file__), "--tiefe-text", "--db", p12b], capture_output=True, text=True, timeout=120)
        r12c = _sp.run([sys.executable, os.path.abspath(__file__), "--tiefe-text", "--db", os.path.join(tmp, "fehlt.db")],
                       capture_output=True, text=True, timeout=120)
        h12n = [_hl.sha1(open(q_, "rb").read()).hexdigest() for q_ in (p12, p12b)]
        t12 = sqlite3.connect(p12b).execute("SELECT name FROM sqlite_master").fetchall()
        ok("T12 Befehlszeile (Debug 165) nur lesend: mit book_tiefe der Bericht (Kopf mit Debug-Nummer, eine Zeile, BTC), ohne die Tabelle "
           "„fehlt“ -- angelegt wird sie dabei nicht, beide Dateien bleiben Byte für Byte gleich; ohne Datei „Kein Ergebnis“ und keine neue "
           "Datei; immer Exit 0",
           r12.returncode == 0 and r12.stdout.startswith("★ Recorder: Tiefe des Buchs bis ±1 % (U311, Debug 165) · Modul " + VERSION_MODUL)
           and "== BTC" in r12.stdout and "Zeilen: 1" in r12.stdout.replace(".", "")
           and r12b.returncode == 0 and "Die Tabelle book_tiefe fehlt" in r12b.stdout and t12 == [("x",)] and h12n == h12
           and r12c.returncode == 0 and "Kein Ergebnis: fehlt.db fehlt" in r12c.stdout and not os.path.exists(os.path.join(tmp, "fehlt.db"))
           and r12.stderr == r12b.stderr == r12c.stderr == "",
           f"rc {r12.returncode}/{r12b.returncode}/{r12c.returncode} · {r12.stdout[:160]!r} · {r12b.stdout[-120:]!r} · {t12} · "
           f"{h12n == h12} · {(r12.stderr + r12b.stderr + r12c.stderr)[-300:]!r}")
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        ok("Ablauf", False, f"{type(e).__name__}: {e}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print(f"Recorder -- Tiefe des Buchs bis ±1 % (U311, seit 23.125; Debug {DEBUG_NR_TIEFE_TEST})")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name}  {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden", f"({sum(1 for p_ in pruef if p_[1])} von {len(pruef)})")
    return alles


# ------------------------------------------------------------------------------------- 23.126 (U287): Hänger-Schutz des Recorders
# Messung vorher (Debug 157, 21.11. 07:03 bis 25.11. 18:45, 107 Stunden, 32.675 Runden): Ein gesunder Recorder schwieg höchstens 77 s
# (Alter des Lebenszeichens von außen 78 s), nie über 120 s -- auch während der Sicherung. Vom Start bis zur ersten Runde: 63 bis 80 s.
# Entscheidung des Nutzers vom 25.11.2026: Frist 5 Minuten. Seither:
#  * Nach jeder fertigen Schreibrunde (Commit in run_flush -- dieselbe Runde, die das Lebenszeichen recorder_alive schreibt) meldet der
#    Recorder WATCHDOG=1 an systemd. Die Unit hat WatchdogSec=300 und NotifyAccess=main. Bleibt die Meldung 5 min aus, beendet systemd den
#    Recorder mit SIGABRT und startet ihn nach 20 s neu (Restart=always).
#  * faulthandler schreibt die Stapel aller Fäden nach logs/recorder_haenger.log: nach 4 min ohne Runde einmal (sein C-Wächter braucht
#    das GIL nicht) und beim SIGABRT von systemd noch einmal („Fatal Python error: Aborted“).
#  * Während des Starts (Datenbank, Symbole, Leaderboard) meldet der Faden „anlauf“ alle 30 s, bis die erste Runde fertig ist, längstens
#    10 min -- sonst bräche ein langsamer Start ab und wiederholte sich ohne Ende.
#  * Aktiv nur im Dienst selbst: WATCHDOG_USEC gesetzt und WATCHDOG_PID (falls gesetzt) dieser Prozess. Läufe von Hand, Läufe aus dem
#    Dashboard (sie erben dessen Umgebung) und update.py melden nichts.
#  * Nach einem Abbruch oder Absturz meldet das Dashboard einmal aufs Handy und lässt Debug 20 laufen (hl_viz._rec_neustart).
REC_HAENGER_DATEI = "recorder_haenger.log"
REC_WAECHTER_S = 300                  # Unit: WatchdogSec (5 min; Entscheidung des Nutzers vom 25.11.2026)
REC_ANLAUF_TAKT_S = 30                # Lebenszeichen während des Starts ...
REC_ANLAUF_MAX_S = 600                # ... längstens so lange; danach nur noch nach einer fertigen Runde
REC_ABZUG_S = 240                     # Stapel aller Fäden nach so langer Zeit ohne Runde (höchstens; sonst 80 % der Wächterzeit)
REC_HAENGER_MAX_B = 1_000_000         # beim Start wird die Datei auf die letzten 1 MB gekürzt
REC_LEBT: dict = {"aktiv": False, "wd_s": None, "datei": None, "pfad": None, "start": None, "runden": 0, "gemeldet": 0,
                  "letzte": None, "erste_s": None, "anlauf_n": 0, "anlauf_ende": None, "melden": None}
_REC_START = re.compile(r"(?m)^== (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) Recorder-Start, PID (\d+)")


def rec_wd_sekunden(env: dict | None = None, pid: int | None = None) -> float | None:
    """Wächterzeit von systemd in Sekunden für DIESEN Prozess: WATCHDOG_USEC > 0 und WATCHDOG_PID leer oder gleich der eigenen PID.
    Ein Kind des Dashboards erbt dessen Umgebung (WATCHDOG_PID = Dashboard) -- es meldet nichts. None ohne systemd."""
    env = os.environ if env is None else env
    wd = str(env.get("WATCHDOG_USEC") or "")
    if not wd.isdigit() or int(wd) <= 0 or not env.get("NOTIFY_SOCKET"):
        return None
    wp = str(env.get("WATCHDOG_PID") or "")
    if wp and wp != str(os.getpid() if pid is None else pid):
        return None
    return int(wd) / 1e6


def rec_sd_notify(nachricht: str, ziel: str | None = None) -> bool:
    """sd_notify ohne Zusatzpaket: ein Datagramm an $NOTIFY_SOCKET (beginnt der Name mit @, liegt der Socket im abstrakten Namensraum).
    Gehört der Wächter einem anderen Prozess (WATCHDOG_PID), meldet dieser Prozess nichts."""
    pfad = ziel if ziel is not None else os.environ.get("NOTIFY_SOCKET")
    if not pfad:
        return False
    if ziel is None and os.environ.get("WATCHDOG_PID") not in (None, "", str(os.getpid())):
        return False
    if pfad.startswith("@"):
        pfad = "\0" + pfad[1:]
    import socket
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as s:
            s.connect(pfad)
            s.sendall(nachricht.encode())
        return True
    except OSError:
        return False


def rec_log_ordner(db: str | None = None) -> str:
    """Ordner der Hänger-Datei: HL_LOGDIR aus der Unit (seit 23.126 auch beim Recorder), sonst logs/ neben der Hauptdatenbank, sonst
    updates/ im Projektordner -- wie beim Dashboard (hl_viz.log_ordner), damit Debug 20 und das Dashboard sie finden."""
    for d in (os.environ.get("HL_LOGDIR"), os.path.join(os.path.dirname(os.path.abspath(db)), "logs") if db else None):
        if d and os.path.isdir(d) and os.access(d, os.W_OK):
            return d
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "updates")
    os.makedirs(d, exist_ok=True)
    return d


def rec_abzug_s(wd_s: float) -> float:
    """Wann faulthandler die Stapel schreibt: 4 min ohne Runde, bei kürzerer Wächterzeit (Selbsttest) 80 % davon -- vor dem Abbruch."""
    return float(min(REC_ABZUG_S, 0.8 * float(wd_s)))


def _rec_kuerzen(pfad: str, max_b: int = REC_HAENGER_MAX_B) -> None:
    """Hänger-Datei auf die letzten max_b Bytes kürzen, ab einer Zeilengrenze (über eine Zwischendatei)."""
    try:
        if os.path.getsize(pfad) <= max_b:
            return
        with open(pfad, "rb") as f:
            f.seek(-max_b, 2)
            rest = f.read()
        rest = rest[rest.find(b"\n") + 1:] if b"\n" in rest else rest
        with open(pfad + ".tmp", "wb") as f:
            f.write(rest)
        os.replace(pfad + ".tmp", pfad)
    except OSError:
        pass


def lebenszeichen_start(db: str | None = None, env: dict | None = None, melden=None, logdir: str | None = None,
                        anlauf_takt: float = REC_ANLAUF_TAKT_S, anlauf_max_s: float = REC_ANLAUF_MAX_S) -> dict | None:
    """23.126 (U287): Hänger-Schutz einschalten -- nur im Dienst mit Wächter von systemd (sonst None, nichts geschieht). Öffnet die
    Hänger-Datei (gekürzt auf 1 MB), schreibt „== Zeit Recorder-Start, PID …“, schaltet faulthandler für alle Fäden darauf und startet den
    Faden „anlauf“: WATCHDOG=1 alle 30 s (höchstens ein Viertel der Wächterzeit), bis die erste Runde fertig ist, längstens 10 min."""
    import faulthandler
    import threading
    wd_s = rec_wd_sekunden(env)
    if wd_s is None:
        return None
    pfad = os.path.join(logdir or rec_log_ordner(db), REC_HAENGER_DATEI)
    _rec_kuerzen(pfad)
    try:
        f = open(pfad, "a", encoding="utf-8")
    except OSError as e:
        print(f"Hänger-Schutz: {pfad} nicht schreibbar ({e}) -- Lebenszeichen an systemd trotzdem", flush=True)
        f = None
    takt = float(max(0.05, min(anlauf_takt, wd_s / 4)))
    abzug = rec_abzug_s(wd_s)
    jetzt = time.time()
    REC_LEBT.update(aktiv=True, wd_s=wd_s, datei=f, pfad=pfad, start=jetzt, runden=0, gemeldet=0, letzte=None, erste_s=None,
                    anlauf_n=0, anlauf_ende=None, melden=melden)
    if f is not None:
        f.write(f"== {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(jetzt))} Recorder-Start, PID {os.getpid()} -- Wächter von "
                f"systemd {wd_s:.0f} s (WATCHDOG=1 nach jeder Schreibrunde), Abzug nach {abzug:.0f} s ohne Runde, Anlauf alle {takt:.0f} s bis "
                f"zur ersten Runde, längstens {anlauf_max_s / 60:.0f} min\n")
        f.flush()
        faulthandler.enable(file=f, all_threads=True)
    ende = time.monotonic() + float(anlauf_max_s)

    def lauf():
        while not REC_LEBT["runden"] and time.monotonic() < ende:
            if (REC_LEBT["melden"] or rec_sd_notify)("WATCHDOG=1"):
                REC_LEBT["anlauf_n"] += 1
            time.sleep(takt)
        REC_LEBT["anlauf_ende"] = "runde" if REC_LEBT["runden"] else "frist"
    threading.Thread(target=lauf, daemon=True, name="anlauf").start()
    print(f"Hänger-Schutz: an -- WATCHDOG=1 nach jeder Schreibrunde; systemd beendet den Recorder nach {wd_s:.0f} s ohne Runde und "
          f"startet ihn neu; Stapel nach {abzug:.0f} s in {pfad}; Anlauf alle {takt:.0f} s bis zur ersten Runde, längstens "
          f"{anlauf_max_s / 60:.0f} min", flush=True)
    return REC_LEBT


def lebenszeichen_runde() -> bool:
    """23.126 (U287): nach jeder fertigen Schreibrunde (run_flush, nach dem Commit): WATCHDOG=1 an systemd und den Abzug von faulthandler
    neu stellen (Stapel aller Fäden, wenn die nächste Runde länger als 4 min ausbleibt). Ohne Hänger-Schutz: nichts (False)."""
    if not REC_LEBT.get("aktiv"):
        return False
    import faulthandler
    jetzt = time.time()
    if not REC_LEBT["runden"]:
        REC_LEBT["erste_s"] = jetzt - (REC_LEBT.get("start") or jetzt)
        print(f"Hänger-Schutz: erste Schreibrunde {REC_LEBT['erste_s']:.0f} s nach dem Start (Anlauf: {REC_LEBT['anlauf_n']} Lebenszeichen) "
              f"-- ab jetzt WATCHDOG=1 nur nach einer fertigen Runde", flush=True)
    REC_LEBT["runden"] += 1
    REC_LEBT["letzte"] = jetzt
    ok = bool((REC_LEBT.get("melden") or rec_sd_notify)("WATCHDOG=1"))
    REC_LEBT["gemeldet"] += int(ok)
    f = REC_LEBT.get("datei")
    if f is not None:
        try:
            faulthandler.dump_traceback_later(rec_abzug_s(REC_LEBT["wd_s"]), repeat=False, file=f, exit=False)
        except (ValueError, OSError, RuntimeError):
            pass
    return ok


def rec_neustarts(text: str) -> list:
    """23.126 (U287): Hänger-Datei des Recorders -> je Start, dem ein Abbruch oder Absturz vorausging, {art: abbruch|absturz, fehler,
    start (des beendeten Laufs), neu_start (Zeit des neuen Starts), pid (des beendeten Laufs)}. „Fatal Python error: Aborted“ = beendet,
    weil die Lebenszeichen ausblieben (so beendet systemd); ein anderer „Fatal Python error“ = Absturz. Nur ein Abzug nach 4 min
    („Timeout“) ohne Abbruch zählt nicht -- dann hat etwas anderes den Lauf beendet (Update, Neustart des Pi)."""
    starts = list(_REC_START.finditer(text or ""))

    def zeit(t_: str) -> int | None:
        try:
            return int(time.mktime(time.strptime(t_, "%Y-%m-%d %H:%M:%S")))
        except (ValueError, OverflowError):
            return None
    out = []
    for a, b in zip(starts, starts[1:]):
        fatal = re.findall(r"(?m)^Fatal Python error: (.+)$", text[a.end():b.start()])
        if fatal:
            out.append({"art": "abbruch" if fatal[-1].strip().startswith("Aborted") else "absturz", "fehler": fatal[-1].strip()[:80],
                        "start": zeit(a.group(1)), "neu_start": zeit(b.group(1)), "pid": int(a.group(2))})
    return out


def rec_neustart_meldung(v: dict, wd_s: float = REC_WAECHTER_S) -> tuple:
    """Titel und Text der Meldung aufs Handy nach einem automatischen Neustart des Recorders (das Dashboard schickt sie)."""
    um = time.strftime("%H:%M", time.localtime(v["neu_start"])) if v.get("neu_start") else "?"
    seit = time.strftime("%d.%m. %H:%M", time.localtime(v["start"])) if v.get("start") else "unbekannt"
    bericht = "Der Bericht dazu (Debug 20) liegt in wenigen Minuten bei den neuen Berichten."
    if v.get("art") == "abbruch":
        return ("HyperBit: Recorder neu gestartet",
                f"Der Recorder hat {wd_s / 60:.0f} Minuten lang keine Schreibrunde fertig bekommen und wurde um {um} automatisch neu gestartet "
                f"(voriger Start {seit}). In dieser Zeit fehlen Daten. Nichts zu tun -- den Pi nicht neu starten. " + bericht)
    return ("HyperBit: Recorder neu gestartet",
            f"Der Recorder ist abgestürzt ({v.get('fehler') or 'Ursache im Abzug'}) und wurde um {um} automatisch neu gestartet (voriger "
            f"Start {seit}). " + bericht)


def selbsttest_waechter() -> bool:
    """Debug 167 (23.126, U287): Hänger-Schutz des Recorders -- Lebenszeichen an systemd nur im Dienst und nur nach einer fertigen
    Schreibrunde, Anlauf, Abzug und Abbruch mit nachgebautem systemd (eigener Prozess, Wächterzeit 4 s), die echte Schreibrunde
    run_flush, Erkennen eines Neustarts, Vertrag mit Unit und main(). Ohne Netz, schreibt nur in einen Ordner unter /tmp."""
    import inspect
    import socket
    import subprocess
    import tempfile
    ergebnisse = []

    def pruef(name, bed, info=""):
        ergebnisse.append(bool(bed))
        print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f"  [{info}]" if info and not bed else ""), flush=True)

    print("Selbsttest Hänger-Schutz des Recorders (U287, Debug 167)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_rec_wd_")
    alt_lebt = dict(REC_LEBT)
    try:
        # W1 Wächterzeit: nur mit WATCHDOG_USEC > 0, NOTIFY_SOCKET und passender WATCHDOG_PID
        e0 = {"WATCHDOG_USEC": "300000000", "NOTIFY_SOCKET": "/run/x"}
        pruef("W1 Wächterzeit aus WATCHDOG_USEC (300 s); ohne Socket, mit 0 oder fremder WATCHDOG_PID keine",
              rec_wd_sekunden(e0) == 300.0 and rec_wd_sekunden({"WATCHDOG_USEC": "300000000"}) is None
              and rec_wd_sekunden({**e0, "WATCHDOG_USEC": "0"}) is None and rec_wd_sekunden({}) is None
              and rec_wd_sekunden({**e0, "WATCHDOG_PID": str(os.getpid() + 1)}) is None
              and rec_wd_sekunden({**e0, "WATCHDOG_PID": str(os.getpid())}) == 300.0,
              f"{rec_wd_sekunden(e0)}")
        # W2 sd_notify an einen Pfad und in den abstrakten Namensraum; ohne Socket nichts
        sp = os.path.join(tmp, "n.sock")
        s1 = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM); s1.bind(sp); s1.settimeout(2)
        name_abs = f"hl_rec_wd_{os.getpid()}"
        s2 = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM); s2.bind("\0" + name_abs); s2.settimeout(2)
        ok1 = rec_sd_notify("WATCHDOG=1", sp); m1 = s1.recv(64)
        ok2 = rec_sd_notify("WATCHDOG=1", "@" + name_abs); m2 = s2.recv(64)
        alt_env = {k: os.environ.get(k) for k in ("NOTIFY_SOCKET", "WATCHDOG_PID", "WATCHDOG_USEC", "HL_LOGDIR")}
        try:
            os.environ.pop("NOTIFY_SOCKET", None)
            ohne = rec_sd_notify("WATCHDOG=1")
            os.environ["NOTIFY_SOCKET"] = sp; os.environ["WATCHDOG_PID"] = str(os.getpid() + 1)
            fremd = rec_sd_notify("WATCHDOG=1")
        finally:
            for k, v in alt_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
        pruef("W2 sd_notify: Datagramm an einen Pfad und an @Name; ohne NOTIFY_SOCKET und für fremde WATCHDOG_PID nichts",
              ok1 and m1 == b"WATCHDOG=1" and ok2 and m2 == b"WATCHDOG=1" and not ohne and not fremd, f"{ok1} {m1} {ok2} {m2} {ohne} {fremd}")
        s1.close(); s2.close()
        # W3 Abzug vor dem Abbruch
        pruef("W3 Abzug nach 240 s bei 300 s Wächterzeit, sonst 80 % (4 s -> 3,2 s), höchstens 240 s (600 s Wächterzeit -> 240 s)",
              rec_abzug_s(300) == 240.0 and abs(rec_abzug_s(4) - 3.2) < 1e-9 and rec_abzug_s(600) == 240.0 and REC_WAECHTER_S == 300)
        # W4 ohne systemd: nichts geschieht, keine Datei
        REC_LEBT.update(aktiv=False)
        r4 = lebenszeichen_start(env={}, logdir=tmp)
        pruef("W4 ohne Wächter von systemd: kein Hänger-Schutz, keine Datei, Runde meldet nichts",
              r4 is None and not os.path.exists(os.path.join(tmp, REC_HAENGER_DATEI)) and lebenszeichen_runde() is False)
        # W5 Kürzen auf die letzten 1 MB ab einer Zeilengrenze
        pk = os.path.join(tmp, "k.log")
        with open(pk, "w", encoding="utf-8") as f:
            f.write("".join(f"Zeile {i:07d} {'x' * 60}\n" for i in range(20_000)))
        _rec_kuerzen(pk, 100_000)
        tk = open(pk, encoding="utf-8").read()
        pruef("W5 Hänger-Datei beim Start gekürzt: höchstens die Grenze, beginnt mit ganzer Zeile, Ende bleibt",
              os.path.getsize(pk) <= 100_000 and tk.startswith("Zeile ") and tk.endswith(f"Zeile {19_999:07d} {'x' * 60}\n"),
              f"{os.path.getsize(pk)} {tk[:20]!r}")

        # W6 bis W9: nachgebautes systemd -- eigener Prozess mit Wächterzeit 4 s; systemd schickt SIGABRT, wenn 4 s kein WATCHDOG=1 kam
        root = os.path.dirname(os.path.abspath(__file__))
        kind = ("import sys, os, time, asyncio, threading\nsys.path.insert(0, sys.argv[1])\nimport hl_recorder as R\n"
                "art, logdir = sys.argv[2], sys.argv[3]\n"
                "def schlaeft_daneben():\n    time.sleep(3600)\n"
                "threading.Thread(target=schlaeft_daneben, daemon=True, name='daneben').start()\n"
                "R.lebenszeichen_start(logdir=logdir, anlauf_max_s=float(sys.argv[4]))\n"
                "def haengt_mit_gil():\n    while True:\n        pass\n"
                "async def haengt_im_await():\n    await asyncio.Event().wait()\n"
                "async def schleife():\n    await asyncio.sleep(2.6)\n"
                "    if art == 'anlauf':\n        await asyncio.sleep(3600)\n"
                "    for _ in range(8):\n        R.lebenszeichen_runde()\n        await asyncio.sleep(0.3)\n"
                "    if art == 'gil':\n        haengt_mit_gil()\n    await haengt_im_await()\n"
                "asyncio.run(schleife())\n")

        def systemd_nachgebaut(art: str, anlauf_max: float = 600.0) -> dict:
            d = os.path.join(tmp, art); os.makedirs(d, exist_ok=True)
            sockp = os.path.join(d, "notify.sock")
            s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM); s.bind(sockp); s.settimeout(0.05)
            env = {k: v for k, v in os.environ.items() if k not in ("WATCHDOG_PID", "HL_LOGDIR")}
            env.update(NOTIFY_SOCKET=sockp, WATCHDOG_USEC="4000000", PYTHONDONTWRITEBYTECODE="1")
            t0 = time.monotonic()
            p = subprocess.Popen([sys.executable, "-B", "-c", kind, root, art, d, str(anlauf_max)], env=env,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            letzte, pings, abbruch = None, [], None          # gezählt ab dem ersten WATCHDOG=1 (das Laden des Moduls dauert auf dem Pi)
            try:
                while p.poll() is None and time.monotonic() - t0 < 60:
                    try:
                        if b"WATCHDOG=1" in s.recv(64):
                            letzte = time.monotonic(); pings.append(round(letzte - t0, 2))
                    except socket.timeout:
                        pass
                    if letzte is None and time.monotonic() - t0 > 30:
                        break
                    if abbruch is None and letzte is not None and time.monotonic() - letzte > 4.0:
                        abbruch = round(time.monotonic() - t0, 2)
                        os.kill(p.pid, signal.SIGABRT)
                if p.poll() is None:
                    p.kill()
                aus = p.communicate(timeout=10)[0].decode("utf-8", "replace")
            finally:
                s.close()
            hp = os.path.join(d, REC_HAENGER_DATEI)
            text = open(hp, encoding="utf-8", errors="replace").read() if os.path.exists(hp) else ""
            return {"rc": p.returncode, "pings": pings, "abbruch": abbruch, "text": text, "aus": aus}

        g = systemd_nachgebaut("gil")
        ab = [round(y - x, 2) for x, y in zip(g["pings"], g["pings"][1:])]
        pruef("W6 Anlauf: WATCHDOG=1 je Sekunde (ein Viertel von 4 s), bis die erste Runde fertig ist; dann eins je Runde",
              10 <= len(g["pings"]) <= 13 and all(0.7 <= x <= 1.6 for x in ab[:2]) and all(0.1 <= x <= 0.9 for x in ab[-7:])
              and g["text"].count("Recorder-Start, PID ") == 1 and "Hänger-Schutz: erste Schreibrunde" in g["aus"],
              f"{g['pings']} {g['aus'][-300:]!r}")
        ab_ = g["text"][g["text"].find("Fatal Python error: Aborted"):]
        pruef("W7 Hänger mit festgehaltenem GIL: Abzug nach 3,2 s (Timeout), Abbruch durch SIGABRT, Stapel aller Fäden mit der Stelle "
              "(auch der Faden daneben)",
              g["rc"] == -signal.SIGABRT and g["abbruch"] is not None and "Timeout (0:00:03.200000)!" in g["text"]
              and "Fatal Python error: Aborted" in g["text"] and g["text"].count("haengt_mit_gil") >= 2
              and g["text"].find("Timeout (") < g["text"].find("Fatal Python error: Aborted") and "schlaeft_daneben" in ab_
              and "haengt_mit_gil" in ab_,
              f"rc {g['rc']} abbruch {g['abbruch']} {g['text'][-400:]!r}")
        a = systemd_nachgebaut("await")
        pruef("W8 Hänger im await (GIL frei, Ereignisschleife wartet, keine Runde): kein WATCHDOG=1 mehr, Abbruch 4 s nach der letzten Runde, Abzug",
              a["rc"] == -signal.SIGABRT and a["abbruch"] is not None and a["pings"] and 3.8 <= a["abbruch"] - a["pings"][-1] < 5.5
              and "Fatal Python error: Aborted" in a["text"] and "run_forever" in a["text"] and "Timeout (" in a["text"],
              f"rc {a['rc']} {a['pings'][-3:]} abbruch {a['abbruch']}")
        n = systemd_nachgebaut("anlauf", anlauf_max=1.5)
        pruef("W9 Anlauf mit Frist: ohne erste Runde enden die Lebenszeichen nach der Frist (1,5 s), dann Abbruch -- keine Schleife ohne Ende",
              n["rc"] == -signal.SIGABRT and n["pings"] and max(n["pings"]) - min(n["pings"]) < 2.2 and n["abbruch"] is not None
              and 3.8 <= n["abbruch"] - max(n["pings"]) < 5.5 and "Timeout (" not in n["text"],
              f"rc {n['rc']} {n['pings']} abbruch {n['abbruch']}")
        # W10 Erkennen im Dashboard und in Debug 20 (rec_neustarts) an den echten Dateien
        zwei = g["text"] + time.strftime("== %Y-%m-%d %H:%M:%S") + " Recorder-Start, PID 4711 -- Wächter von systemd 300 s\n"
        rn = rec_neustarts(zwei)
        pruef("W10 Neustart nach Abbruch erkannt (art abbruch), ohne zweiten Start nichts; Absturz und reiner Abzug unterschieden",
              len(rn) == 1 and rn[0]["art"] == "abbruch" and rn[0]["fehler"].startswith("Aborted") and rn[0]["neu_start"]
              and rec_neustarts(g["text"]) == []
              and [x["art"] for x in rec_neustarts("== 2026-11-26 07:00:00 Recorder-Start, PID 1\nFatal Python error: Segmentation fault\n"
                                                    "== 2026-11-26 07:01:00 Recorder-Start, PID 2\nTimeout (0:04:00)!\n"
                                                    "== 2026-11-26 08:00:00 Recorder-Start, PID 3\n")] == ["absturz"],
              f"{rn}")
        t11, x11 = rec_neustart_meldung({"art": "abbruch", "start": 1_795_000_000, "neu_start": 1_795_003_600})
        pruef("W11 Meldung nach dem Neustart: 5 Minuten, Uhrzeit, kein Handlungsbedarf, Debug 20",
              t11 == "HyperBit: Recorder neu gestartet" and "5 Minuten lang keine Schreibrunde" in x11 and "Debug 20" in x11
              and "den Pi nicht neu starten" in x11)
        # W12 die echte Schreibrunde: WATCHDOG=1 erst NACH dem Commit, der das Lebenszeichen recorder_alive schreibt
        dbp = os.path.join(tmp, "w12.db")
        con = db_connect(dbp)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0, flush_sec=1))
        gesehen = []
        echt = globals()["lebenszeichen_runde"]

        def runde_probe():
            c2 = sqlite3.connect(f"file:{dbp}?mode=ro", uri=True)
            v = c2.execute("SELECT v FROM meta WHERE k='recorder_alive'").fetchone(); c2.close()
            gesehen.append(v[0] if v else None)
            R.stop.set()
            return True
        globals()["lebenszeichen_runde"] = runde_probe
        try:
            t12 = time.time()
            asyncio.run(asyncio.wait_for(R.run_flush(), timeout=20))
        finally:
            globals()["lebenszeichen_runde"] = echt
            con.close()
        pruef("W12 run_flush: nach der Schreibrunde genau eine Meldung; recorder_alive ist da schon geschrieben (Commit davor)",
              len(gesehen) == 1 and gesehen[0] is not None and int(gesehen[0]) >= int(t12), f"{gesehen}")
        # W13 Vertrag: Unit, main() und run_flush
        q_main = inspect.getsource(main); q_flush = inspect.getsource(Recorder.run_flush); q_st = inspect.getsource(lebenszeichen_start)
        i_c = q_flush.find("self.con.commit()"); i_l = q_flush.find("lebenszeichen_runde()")
        try:
            inst = open(os.path.join(root, "install.py"), encoding="utf-8").read()
        except OSError:
            inst = ""
        unit = inst[inst.find('RECORDER_UNIT = """'):]; unit = unit[:unit.find('"""\n', 20)]
        pruef("W13 Vertrag: Unit mit WatchdogSec=300, NotifyAccess=main, LimitCORE=0, HL_LOGDIR; main() schaltet vor allem anderen ein; "
              "run_flush meldet direkt nach dem Commit; der Selbsttest steht in der Installationsprüfung (A7)",
              '[py, str(ROOT / "hl_recorder.py"), "--selbsttest-waechter"]),' in inst and f"WatchdogSec={REC_WAECHTER_S}\n" in unit and "NotifyAccess=main\n" in unit and "LimitCORE=0\n" in unit
              and "Environment=HL_LOGDIR={logdir}\n" in unit and "Restart=always\n" in unit
              and 0 < q_main.find("lebenszeichen_start(args.db)") < q_main.find("if args.selbsttest_v10")
              and 0 < q_st.find("_rec_kuerzen(pfad)") < q_st.find('f = open(pfad, "a", encoding="utf-8")')
              and 0 < i_c < i_l and q_flush[i_c:i_l].count("\n") <= 1,
              f"unit {len(unit)} main {q_main.find('lebenszeichen_start(args.db)')} flush {i_c} {i_l}")
        # W14 Ordner der Hänger-Datei: HL_LOGDIR aus der Unit, sonst logs/ neben der Datenbank, sonst updates/ im Projektordner
        alt_ld = os.environ.get("HL_LOGDIR")
        try:
            os.environ["HL_LOGDIR"] = tmp
            o1 = rec_log_ordner(os.path.join(tmp, "x", "hl_liq.db"))
            os.environ.pop("HL_LOGDIR", None)
            os.makedirs(os.path.join(tmp, "y", "logs"), exist_ok=True)
            o2 = rec_log_ordner(os.path.join(tmp, "y", "hl_liq.db"))
            upd_ = os.path.join(root, "updates"); upd_da = os.path.isdir(upd_)
            o3 = rec_log_ordner(os.path.join(tmp, "z", "hl_liq.db"))
            if not upd_da:                                      # nichts im Projektordner zurücklassen
                try:
                    os.rmdir(upd_)
                except OSError:
                    pass
        finally:
            if alt_ld is None:
                os.environ.pop("HL_LOGDIR", None)
            else:
                os.environ["HL_LOGDIR"] = alt_ld
        pruef("W14 Ordner der Hänger-Datei: HL_LOGDIR, sonst logs/ neben der Datenbank, sonst updates/ im Projektordner (wie beim Dashboard)",
              o1 == tmp and o2 == os.path.join(tmp, "y", "logs") and o3 == os.path.join(root, "updates"), f"{o1} {o2} {o3}")
    except Exception as e:  # noqa: BLE001 -- ein Fehler im Test ist ein Fehlschlag, kein Absturz
        import traceback
        traceback.print_exc()
        pruef(f"Selbsttest ohne Ausnahme ({type(e).__name__}: {e})", False)
    finally:
        REC_LEBT.clear(); REC_LEBT.update(alt_lebt)
        shutil.rmtree(tmp, ignore_errors=True)
    n_ok = sum(ergebnisse)
    print(f"\n{n_ok} von {len(ergebnisse)} Proben bestanden", flush=True)
    return n_ok == len(ergebnisse) and len(ergebnisse) == 14

FIRST_SEEN_GRENZE_MS = 100_000_000_000      # 10^11: als Millisekunden der 03.03.1973, als Sekunden das Jahr 5138


def first_seen_reparieren(con: sqlite3.Connection) -> int:
    """
    23.66 (U149): addresses.first_seen ist MILLISEKUNDEN (wie last_trade). pool_laden trug neue Pool-Konten vom Start des
    Pools (21.09.) bis 23.65 mit Sekunden ein; das Audit meldete „Zeit-Einheiten“ (Bericht 11.10. 13:05). Werte unter 10^11
    können nur Sekunden sein, die Umrechnung ist also eindeutig und wiederholbar (ein zweiter Lauf findet nichts mehr).
    Erst lesen (ohne Schreibsperre), nur bei Befund eine kurze Schreibtransaktion (BEGIN IMMEDIATE über isolation_level).
    Rückgabe: Zahl der umgerechneten Zeilen.
    """
    n = con.execute("SELECT COUNT(*) FROM addresses WHERE first_seen > 0 AND first_seen < ?", (FIRST_SEEN_GRENZE_MS,)).fetchone()[0]
    if not n:
        return 0
    n = con.execute("UPDATE addresses SET first_seen = first_seen * 1000 WHERE first_seen > 0 AND first_seen < ?",
                    (FIRST_SEEN_GRENZE_MS,)).rowcount
    con.commit()
    return int(n)


def wal_zustand_laden(con: sqlite3.Connection, gesperrt=frozenset(), fenster_s: int = WAL_WIEDERHER_S) -> tuple[dict, dict]:
    """
    23.36: Letzter Stand jeder verfolgten Wal-Position aus whale_positions -- für den Recorder-Start.

    Gelesen werden nur die letzten fenster_s Sekunden VOR DEM LETZTEN EINTRAG der Tabelle (nicht vor jetzt: auch nach
    tagelangem Stillstand ist der Stand beim Anhalten vollständig). Jede Position im Zustand bekommt alle 10 min einen
    Schnappschuss, ihr letzter Stand liegt also sicher im Fenster. Bis 23.35 suchte eine korrelierte Unterabfrage den
    letzten Stand über die GANZE Tabelle -- mit 2 Mio. Zeilen 44 s (Aufwand wächst quadratisch mit dem Alter der
    Tabelle), und das vor dem Start der Aufzeichnung.

    Gleicher Zeitstempel: close gewinnt. Ein Schnappschuss in derselben Sekunde wie das close erweckte die Position
    sonst nach jedem Neustart wieder (und der nächste Poll schrieb ein zweites close). Gesperrte werden nicht übernommen:
    Für sie gibt es kein close-Ereignis (H3), ihre Positionen kommen mit der nächsten 6-h-Abfrage frisch herein.
    Rückgabe: ({addr: {coin: Position}}, Kennzahlen).
    """
    info = {"zeilen": 0, "geschlossen": 0, "gesperrt": 0, "gleichstand": 0, "fenster_bis": None}
    t_max = con.execute("SELECT MAX(ts) FROM whale_positions").fetchone()[0]
    if t_max is None:
        return {}, info
    info["fenster_bis"] = int(t_max)
    letzt: dict = {}
    for r in con.execute("""SELECT ts, addr, coin, event, side, size, pos_value, entry_px, liq_px, leverage, upnl
                            FROM whale_positions WHERE ts >= ? ORDER BY ts""", (int(t_max) - int(fenster_s),)):
        info["zeilen"] += 1
        k = (r[1], r[2]); v_ = letzt.get(k)
        if v_ is not None and v_[0] == r[0] and (v_[3] == "close" or r[3] == "close"):
            info["gleichstand"] += 1
            if v_[3] == "close":
                continue                                              # close gewinnt, egal in welcher Reihenfolge
        letzt[k] = r
    zustand: dict = {}
    for (addr, coin), r in letzt.items():
        if r[3] == "close":
            info["geschlossen"] += 1; continue
        if str(addr).lower() in gesperrt:
            info["gesperrt"] += 1; continue
        side, size, val, entry, liq, lev, upnl = r[4], float(r[5] or 0.0), r[6], r[7], r[8], r[9], r[10]
        zustand.setdefault(addr, {})[coin] = {
            "coin": coin, "side": side, "size": size if side == "long" else -size,
            "pos_value": val, "entry": entry, "liq_px": liq,
            "lev": lev, "upnl": upnl, "notional": abs(size) * (liq or 0.0),
        }
    return zustand, info


class Recorder:
    def __init__(self, con: sqlite3.Connection, cfg: Settings):
        self.con = con
        self.cfg = cfg
        # Budget: Positionsabfragen (Gewicht 2) plus Wal-Orders (Gewicht 20) plus
        # Der Begrenzer setzt das API-Limit durch (90 % = 1.080/min); die Erzeuger begrenzen sich selbst
        # (polls_per_min, stop_weight_budget, Fill-Budget). Analyse v6 (17.09.): die alte min()-Klammer
        # kappte das Angebot auf 280·2 + 320 + 60 = 940/min -- exakt das gemeldete Plateau.
        self.limiter = RateLimiter(int(HL_WEIGHT_BUDGET * 0.90))
        self.positions: dict[str, list[dict]] = {}   # addr -> offene Positionen
        self.bars: dict[tuple[int, str], dict] = {}  # (minute, coin) -> OHLCV
        self.mid: dict[str, float] = {}
        self.symbol_of: dict[str, str] = {}          # BTC -> BTC, XMR -> felix:XMR
        self.coin_of: dict[str, str] = {}            # Symbol -> Klarname
        self.dex_of: dict[str, str] = {}             # Symbol -> Dex ("" = Standard)
        self.dexes: list[str] = [""]
        self.addr_dex: dict[str, set[str]] = {}      # Adresse -> gesehene Dexe
        self.polled_at: dict[str, int] = {}           # Adresse -> Zeit der letzten Antwort
        self.whale_state: dict[str, dict[str, dict]] = {}  # Adresse -> Coin -> Position
        self.pool_state: dict = {}; self.pool_snap_ts: dict = {}; self.pool_rows_pending: list = []   # 23.27: alle Pool-Konten
        self._pool_prune_ts = 0.0
        self.ticks: dict[str, deque] = {}             # Coin -> Ringpuffer Rohtrades
        self.mark_hist: dict[str, deque] = {}         # Coin -> Ringpuffer Markpreise
        self.sec_px: dict[str, deque] = {}            # Coin -> (Sekunde, Preis) für Auslöser
        self.liq_times: dict[str, deque] = {}         # Coin -> Zeitpunkte von Liquidations-Fills
        self.tick_rec: dict[str, dict] = {}           # Coin -> laufende Aufzeichnung
        self.books: dict[str, deque] = {}             # Coin -> Ringpuffer (ts_ms, levels_json)
        self.book_last_summary: dict[str, int] = {}   # Coin -> letzte Kennzahl-Sekunde
        self.bars10: dict[tuple[int, str], dict] = {} # (10-s-Slot, Coin) -> Aggregat
        self.bars_fertig: dict = {}                   # 23.82 (U222): geschriebene Minuten, vollständig, bis BAR_HALTEN_S nach ihrem Ende
        self.bars10_fertig: dict = {}                 # 23.82 (U222): dasselbe für die 10-s-Stücke (gehalten wie ihre Minute)
        self._tids: dict = {}                         # 23.82 (U222): Coin -> (Menge (ts_ms, tid), Warteschlange) zum Entdoppeln
        self._hw = 0                                  # 23.82 (U222): höchste Börsenzeit (ms) angenommener Trades
        self._hw_alt = None                           # 23.82 (U222): höchste Börsenzeit des vorigen Dienstes (meta u222_hw_ms)
        self._grenze: dict = {}                       # 23.82 (U222): Coin -> letzte Minute des vorigen Dienstes in bars (oder None)
        self.u222 = {"spaet_min": 0, "spaet_10s": 0, "doppelt": 0, "vor_start": 0, "zu_alt": 0, "zusammengefuehrt": 0, "liq_spaet": 0}
        self._uhr = None                              # Selbsttest: feste Uhr statt time.time() für die Bars
        self.next_control: float = time.time() + random.uniform(3600, 6 * 3600)
        self.ctx: dict[str, dict] = {}                # Coin -> letzter Marktkontext
        self._last_coverage: dict[str, float] = {}
        self._last_prox: float = 0.0
        self.stop_polled_at: dict[str, float] = {}   # Wal-Adresse -> letzte Order-Abfrage
        self.orders: dict[str, list] = {}            # Adresse -> jüngste Orders (coin, kind, px, notional)
        self.event_subs: set[str] = set()            # Adressen mit ANGEFORDERTEM userEvents-Abo
        self.event_subs_ok: set[str] = set()         # vom Server BESTÄTIGTE Abos (subscriptionResponse) -- nur für diese entfällt die Ableitung (K1)
        self.event_subs_abgelehnt: int = 0
        self.event_queue: list[tuple[str, str]] = [] # ("subscribe"/"unsubscribe", addr) für den WS-Task
        self.ctx_pending: dict[tuple[int, str], dict] = {}  # (Minute, Coin) -> Kontext
        self.started_at = int(time.time())
        self.stop = asyncio.Event()
        self.stats = defaultdict(int)
        self.session = None
        self.lb_last_hour = -1
        self.lb_flat_until: dict = {}
        self.lb_flat_seen: dict = {}
        self.lb_last_rec: dict = {}         # (addr, coin) -> zuletzt protokollierte Positionsgröße
        self.task_errors: dict = {}         # Aufgabe -> letzter Absturz (Zeit, Meldung, Anzahl)
        self.weight_by: dict = {}           # Herkunft -> [(Zeit, Gewicht)] der letzten Minute
        self.whale_rows_rest: list = []     # whale_positions-Zeilen der laufenden Runde (flush_round schreibt)
        self.liq_rows_pending: list = []    # abgeleitete Liquidationen der laufenden Runde
        self.addr_update_pending: list = [] # Adress-Stände der laufenden Runde
        self.addr_null_pending: list = []   # 23.14 (U37): Adressen ohne Position (last_poll, Wert 0, misses+1) -- schreibt flush_round
        self.ue_fills_pending: list = []    # 23.23 (U58): vollständige Fills aus userEvents (Darwin-Liste), minütlich geschrieben
        self.book_rows_pending: dict = {}   # book_summary je (5-s-Fenster, Coin), jüngster Stand
        self.tiefe_rows_pending: list = []  # 23.125 (U311): book_tiefe-Zeilen der Aufgabe „Buch-Tiefe“ (flush_round schreibt)
        self.buch_mitte: dict = {}          # 23.125 (U311): Coin -> (Mitte des ungerundeten Buchs, Sekunde)
        self.tiefe_grob: dict = {}          # 23.125 (U311): Coin -> (Stellen, bis) nach einer unvollständigen Antwort
        self._tiefe_prune_ts = 0.0
        # Fills aus dem Trade-Stream: Jeder Trade auf Hyperliquid kommt mit beiden Adressen
        # (users = [Käufer, Verkäufer]). Für die beobachteten Konten sind das ihre Fills --
        # in Echtzeit und ohne Gewicht. Gepuffert, minütlich geschrieben; der REST-Abgleich
        # ersetzt die Zeilen später durch die vollständigen (closedPnl, fee, dir).
        self.fill_konten: set = set()       # Konten, deren Fills gesammelt werden (aktuelle Leaderboard-Auswahl + Pool)
        self.pool_addrs: set = set()        # "Aktive Profis": Kandidatenpool (Phase 1)
        self.gesperrt: set = set()          # Masterregel: dauerhaft gesperrte Konten (konto_status)
        self.trade_buendel: dict = {}       # 23.13 (U31): (Konto, Stunde) -> Menge (Coin, Minute*2 + Käufer) = gebündelte Trades
        self.fill_zaehler: dict = {}        # (Konto, Stunde) -> Fills seit der letzten Persistierung (alle Fills, auch Gesperrte)
        self.lb_pos_side: dict = {}         # (Konto, Coin) -> "long"/"short" aus dem letzten Leaderboard-Zyklus
        self.lb_pos_konten: set = set()     # Konten, deren Positionen im letzten Zyklus abgefragt wurden (flat = bekannt ohne Position)
        self._lb_pos_ts: int = 0            # 23.34: Zeitpunkt dieses Leaderboard-Stands
        # 23.34: Konten der Darwin-Liste -- ihre Fills werden OHNE Mindestbetrag gesammelt (vorher nur ab lb_fills_min_usd: eine in
        # Stücke unter 2.500 USD zerlegte Eröffnung blieb unsichtbar). _stream_pos: Richtung aus den eigenen abgeleiteten Fills, solange
        # sie jünger ist als der letzte Positionsstand (sonst hieß ein Verkauf kurz nach einer frischen Long-Eröffnung „Open Short“).
        self._darwin_set: set = set()
        self._darwin_klein: dict = {}       # (Quelle, Konto, Stunde) -> Zahl der gespeicherten kleinen Fills
        self._stream_pos: dict = {}         # (Konto, Coin) -> (Seite, ts)
        self.stream_fills_pending: list = []
        self.stream_fills_minute: int = 0   # Zähler der laufenden Minute (für die Anzeige)
        self.stream_trades_minute: int = 0  # Trades mit Adressfeld in der laufenden Minute
        # 23.33 Adress-Strom: JEDER Trade der verfolgten Coins je Minute und Adresse (Nehmer/Geber, Kauf/Verkauf, TWAP) in
        # eine eigene Datei adressfluss.db neben der Datenbank -- 0 Gewicht, keine Last auf hl_liq.db, nicht im Backup
        self.af = None; self._af_null = None
        if getattr(cfg, "af_tage", 14) > 0:
            try:
                import hl_adressfluss
                self.af = hl_adressfluss.Adressfluss(hl_adressfluss.pfad_neben(DB_PATH), tage=cfg.af_tage, max_gb=cfg.af_max_gb)
                self._af_null = hl_adressfluss.NULL_HASH
            except Exception as e:
                print(f"Adress-Strom aus: {type(e).__name__}: {e}", flush=True)
        try:
            last = self.con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
            if last:
                self.fill_konten = {r[0].lower() for r in self.con.execute("SELECT addr FROM lb_accounts WHERE ts=?", (last,))}
        except sqlite3.Error:
            pass
        self.jobs: dict = {}                # Aufgabe -> letzte/nächste Ausführung, Dauer, Ergebnis
        self._load_flushed: int = 0         # letzte in api_load geschriebene Minute
        self._ruhig_cache: tuple | None = None   # (Zeitpunkt, Menge ruhiger Stunden)
        self.addr_meta: dict = {}           # addr -> [last_poll, pos_value, last_trade_ms, first_seen_ms]
        self.addr_value: dict = {}          # letzter geschriebener Positionswert je Adresse
        self.addr_dirty: dict = {}          # last_poll, noch nicht geschrieben
        self.addr_seen: dict = {}           # last_trade aus dem Feed, noch nicht geschrieben
        self.addr_umsatz: dict = {}         # 23.86: gehandelter Wert (USD) seit der letzten erfolgreichen Abfrage, aus dem Trade-Feed
        self._vorrang: set = set()          # 23.86: in der letzten Auswahl wegen großen Handels vorgezogene Adressen
        self.abst_stunde = 0; self.abst_lauf: dict = {}; self.abst_letzte: dict = {}   # 23.86 (U231): gemessene Abstände je Stufe
        self.erfolg_at: dict = {}           # 23.86: Zeit der letzten ERFOLGREICHEN Abfrage in diesem Lauf (Abstände, Alter im Snapshot)
        self.poll_fehler: dict = {}         # 23.86: Adresse -> (Fehlschläge hintereinander, Pause bis)
        self.addr_new: dict = {}            # Adressen, die die Datenbank noch nicht kennt
        self.addr_known: set = set()        # alle Adressen der Datenbank (beim Start geladen)
        self._last_addr_flush: float = 0.0
        self._last_addr_full: float = time.time()
        # Temperaturschutz: ab 70 °C weniger API-Gewicht und längere Takte, mit Hysterese (3 °C)
        self.thermal = {"temp": None, "level": 0, "weight_factor": 1.0, "interval_factor": 1.0, "since": 0}
        self.interval_factor = 1.0

    # -- HTTP ---------------------------------------------------------------

    async def post(self, payload: dict, weighted: bool = True,
                   weight: int = WEIGHT_STATE, quelle: str = "sonstiges") -> dict | list | None:
        """
        Eine Abfrage an die API. `quelle` hält fest, wer das Gewicht verbraucht -- ohne diese
        Aufteilung sieht man nur, DASS das Budget fast voll ist, aber nicht, wer es füllt,
        und kann folglich nicht entscheiden, wo man kürzt.
        """
        import aiohttp
        if weighted:
            await self.limiter.acquire(weight, prio=PRIO_BY_QUELLE.get(quelle, 1))
            jetzt = time.time()
            eimer = self.weight_by.setdefault(quelle, [])
            eimer.append((jetzt, weight))
            if len(eimer) > 2000:
                self.weight_by[quelle] = [x for x in eimer if jetzt - x[0] < 180]
        for attempt in range(3):
            if attempt and weighted:
                await self.limiter.acquire(weight, prio=PRIO_BY_QUELLE.get(quelle, 1))   # M6: jeder Versuch kostet Gewicht -- buchen
                self.weight_by.setdefault(quelle, []).append((time.time(), weight))
            try:
                async with self.session.post(API, json=payload, timeout=aiohttp.ClientTimeout(total=8 if weight <= WEIGHT_STATE else 20)) as r:   # v6 Empf. 5: ein Ausreißer blockiert sonst die Runde
                    if r.status == 429:
                        self.limiter.drossel_bis = time.monotonic() + 60            # M6: nach 429 eine Minute halbes Tempo
                        self.stats["rate_limited"] += 1
                        await asyncio.sleep(2 + attempt * 3)
                        continue
                    r.raise_for_status()
                    return await r.json()
            except Exception:
                self.stats["http_error"] += 1
                await asyncio.sleep(1 + attempt * 2)
        return None

    # -- WebSocket: Trades, Adressen, Bars, Liquidationen --------------------

    async def resolve_symbols(self) -> None:
        """
        Ordnet jedem gewünschten Coin sein Handelssymbol und seinen Perp-Dex zu.

        Der Standard-Dex nutzt schlichte Namen ("BTC"). HIP-3-Märkte wie XMR
        laufen auf einem eigenen Dex und tragen dessen Namen als Präfix
        ("felix:XMR"). Wichtiger noch: Positionen auf einem HIP-3-Dex erscheinen
        nur, wenn clearinghouseState mit dem passenden dex-Parameter abgefragt
        wird — sonst fehlen sie vollständig.
        """
        wanted = {c.upper() for c in self.cfg.coins}
        found: dict[str, tuple[str, str]] = {}   # coin -> (symbol, dex)

        # Standard-Dex
        meta = await self.post({"type": "meta"}, weighted=False)
        for a in (meta or {}).get("universe", []):
            name = str(a.get("name", "")).upper()
            if name in wanted:
                found[name] = (a["name"], "")

        # HIP-3-Dexe durchsuchen, falls noch etwas fehlt
        if len(found) < len(wanted):
            dexs = await self.post({"type": "perpDexs"}, weighted=False)
            for d in (dexs or []):
                if not isinstance(d, dict) or not d.get("name"):
                    continue          # erster Eintrag ist der Standard-Dex (null)
                dex = d["name"]
                m = await self.post({"type": "meta", "dex": dex}, weighted=False)
                for a in (m or {}).get("universe", []):
                    short = str(a.get("name", "")).split(":")[-1].upper()
                    if short in wanted and short not in found:
                        sym = a["name"] if ":" in str(a["name"]) else f"{dex}:{a['name']}"
                        found[short] = (sym, dex)
                if len(found) == len(wanted):
                    break

        for coin in sorted(wanted):
            if coin in found:
                sym, dex = found[coin]
                self.symbol_of[coin] = sym
                self.coin_of[sym] = coin
                self.dex_of[sym] = dex
                tag = f"HIP-3 auf '{dex}'" if dex else "Standard-Dex"
                print(f"  {coin:<6} -> {sym:<18} ({tag})")
            else:
                print(f"  {coin:<6} -> nicht gefunden, wird übersprungen")
        symbole_ablegen(self.con, self.symbol_of, self.dex_of)          # 23.97 (U250): für die Notbremse (derselbe Markt wie hier)

        # Zur Adress-Entdeckung alle Standard-Perps abonnieren. Wer BTC hält,
        # handelt vielleicht gerade nur SOL -- ohne breite Beobachtung bleibt
        # seine BTC-Position unsichtbar. Bars entstehen weiterhin nur für die
        # verfolgten Coins, sonst wächst die Datenbank zu schnell.
        self.discovery_symbols: list[str] = []
        if self.cfg.discover_all and meta:
            tracked = set(self.symbol_of.values())
            self.discovery_symbols = [
                a["name"] for a in meta.get("universe", [])
                if a.get("name") and a["name"] not in tracked
                and not a.get("isDelisted")]
            print(f"  + {len(self.discovery_symbols)} weitere Feeds nur zur "
                  "Adress-Entdeckung")

        self.dexes = sorted({d for d in self.dex_of.values()})
        if len(self.dexes) > 1:
            print(f"  Hinweis: {len(self.dexes)} Perp-Dexe. Adressen, die auf "
                  "mehreren handeln, brauchen entsprechend mehr Abfragen.")

    async def run_ws(self) -> None:
        import websockets
        backoff = 1
        while not self.stop.is_set():
            try:
                async with websockets.connect(WS, ping_interval=20, max_size=2**23) as ws:
                    symbols = (list(self.symbol_of.values()) or self.cfg.coins) \
                              + self.discovery_symbols
                    for sym in symbols:
                        await ws.send(json.dumps({
                            "method": "subscribe",
                            "subscription": {"type": "trades", "coin": sym},
                        }))
                    # Marktkontext und Orderbuch nur für die verfolgten Coins
                    for sym in self.symbol_of.values():
                        await ws.send(json.dumps({
                            "method": "subscribe",
                            "subscription": {"type": "activeAssetCtx", "coin": sym},
                        }))
                        await ws.send(json.dumps({
                            "method": "subscribe",
                            "subscription": {"type": "l2Book", "coin": sym},
                        }))
                    for a in sorted(self.event_subs):        # nach Reconnect erneut abonnieren
                        self.event_queue.append(("subscribe", a))
                    print(f"WS verbunden, {len(symbols)} Feeds abonniert"
                          + (f", {len(self.event_subs)} Konten-Feeds folgen." if self.event_subs else "."))
                    backoff = 1
                    while not self.stop.is_set():
                        raw = await asyncio.wait_for(ws.recv(), timeout=90)
                        msg = json.loads(raw)
                        ch = msg.get("channel")
                        if ch == "trades":
                            for t in msg.get("data", []):
                                self.on_trade(t)
                        elif ch == "activeAssetCtx":
                            self.on_ctx(msg.get("data") or {})
                        elif ch == "l2Book":
                            self.on_book(msg.get("data") or {})
                        elif ch == "userEvents":
                            d = msg.get("data") or {}
                            self.on_user_event(str(d.get("user") or msg.get("user") or ""), d)
                        elif ch == "subscriptionResponse":                       # K1: nur bestätigte Abos zählen
                            d = msg.get("data") or {}; sub = d.get("subscription") or {}
                            if sub.get("type") == "userEvents" and sub.get("user"):
                                a_ = str(sub["user"]).lower()
                                if d.get("method") == "unsubscribe":
                                    self.event_subs_ok.discard(a_)
                                else:
                                    self.event_subs_ok.add(a_)
                            self.stats["event_subs_ok"] = len(self.event_subs_ok)
                        elif ch == "error":
                            txt = str(msg.get("data") or "")
                            if "user" in txt.lower() or "subscri" in txt.lower():
                                self.event_subs_abgelehnt += 1; self.stats["event_subs_abgelehnt"] = self.event_subs_abgelehnt
                                if self.event_subs_abgelehnt <= 3:
                                    print(f"  WS-Ablehnung: {txt[:160]}", flush=True)
                        # Abo-Änderungen für Liquidations-Feeds, gedrosselt (2000 Nachrichten/min)
                        n_sent = 0
                        while self.event_queue and n_sent < 20:
                            action, a = self.event_queue.pop(0)
                            await ws.send(json.dumps({"method": action,
                                                      "subscription": {"type": "userEvents", "user": a}}))
                            n_sent += 1
            except asyncio.TimeoutError:
                print("WS still, reconnect …")
            except Exception as e:
                if not self.stop.is_set():
                    print(f"WS-Fehler: {e} — reconnect in {backoff}s")
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 60)

    def on_trade(self, t: dict) -> None:
        symbol = t.get("coin")
        # HIP-3-Symbole ("felix:XMR") auf den Klarnamen normalisieren, damit
        # Bars und Heatmap denselben Schlüssel benutzen.
        coin = self.coin_of.get(symbol) or str(symbol).split(":")[-1]
        dex = self.dex_of.get(symbol, "")
        try:
            px, sz = float(t["px"]), float(t["sz"])
            ts = int(t["time"])
        except (KeyError, TypeError, ValueError):
            return

        tracked = coin in self.symbol_of
        if tracked and self._doppelt(coin, t, ts):                  # 23.82 (U222): derselbe Trade (tid) schon gezählt
            return
        self.stats["trades"] += 1
        if not tracked:
            self.stats["discovery_trades"] += 1

        if tracked:
            self.mid[coin] = px
            is_liq = bool(t.get("liquidation"))
            self.buffer_tick(coin, ts, px, sz, t.get("side"), is_liq,
                             int(t.get("tid") or 0))
            # Fills der beobachteten Konten aus dem Stream (0 Gewicht, Echtzeit)
            users = t.get("users") or ()
            if users:
                self.stream_trades_minute += 1                    # Diagnose: kommen Trades mit Adressen an?
                if self.af is not None:                           # 23.33 Adress-Strom (nur Speicher; geschrieben minütlich)
                    self.af.trade(coin, ts, px * sz, users, str(t.get("side")) == "B", t.get("hash") == self._af_null)
            if self.fill_konten and users:
                # M1 (Audit v10): ALLE Fills zählen (kein Mindestbetrag) -- Zähler je Konto und Stunde, stündlich
                # in fill_zaehler_h persistiert; die Masterregel summiert die letzten 24 h (rollierend, neustartfest)
                st_ = int(t.get("time") or 0) // 3_600_000 * 3600
                min2_ = int(t.get("time") or 0) // 60_000 * 2        # 23.13 (U31): gebündelter Trade = Coin, Minute, Richtung
                for i_, u in enumerate(users[:2]):
                    a = str(u).lower()
                    if a in self.fill_konten or a in self.gesperrt:
                        self.fill_zaehler[(a, st_)] = self.fill_zaehler.get((a, st_), 0) + 1
                        self.trade_buendel.setdefault((a, st_), set()).add((coin, min2_ + (1 if i_ == 0 else 0)))   # users[0] = Käufer
            gross = px * sz >= self.cfg.lb_fills_min_usd
            dset = self._darwin_set
            if users and ((self.fill_konten and gross) or dset):
                tid = int(t.get("tid") or 0)
                for i, u in enumerate(users[:2]):
                    a = str(u).lower()
                    if not tid or a in self.gesperrt:
                        continue
                    darwin = a in dset
                    if not (darwin or (gross and a in self.fill_konten)):
                        continue
                    if not gross and not self.darwin_klein_frei("stream", a, ts // 1000):
                        continue                                # 23.34: kleine Fills nur für die Darwin-Liste, gedeckelt
                    # users[0] = Käufer, users[1] = Verkäufer (Doku); side "B"/"A" wie im REST-Fill.
                    # Richtung aus der bekannten Position ableiten (Leaderboard-Stände alle 2 min,
                    # bei Walen und Pool-Konten aus dem Poller): Verkauf bei Long = "Close Long", ohne Position =
                    # "Open Short" usw. Das Sternchen markiert "abgeleitet, noch ohne REST-Nachtrag" --
                    # bei Konten mit tausenden Fills je Stunde kommt der Nachtrag nie hinterher.
                    kauf = i == 0
                    richtung = self.stream_richtung(a, coin, kauf, ts // 1000)
                    self.stream_fills_pending.append((ts // 1000, a, coin, "perp", richtung, "B" if kauf else "A",
                                                      px, sz, px * sz, 0.0, 0.0, tid, 1 if kauf else 0))
                    self.stream_fills_minute += 1
                    if not gross:
                        self.stats["darwin_fills_klein"] = self.stats.get("darwin_fills_klein", 0) + 1
            # 10-Sekunden-Bar mit Aggressorseite und 1-Minuten-Bar (23.82, U222: ein später Trade ergänzt das geschriebene Stück, statt es zu
            # ersetzen; ob der Trade für die Bars zählt, entscheidet _bar_entscheid einmal für beide Tabellen)
            entscheid = self._bar_entscheid(coin, ts)
            if entscheid is not None:
                side_sell = str(t.get("side")) == "A"      # A = Verkauf trifft Bid
                b10, neu = self._stueck(self.bars10, self.bars10_fertig, (ts // 10_000 * 10, coin), entscheid, "spaet_10s")
                if neu:
                    b10.update(o=px, h=px, l=px, c=px, vb=0.0, vs=0.0, n=0, nl=0, ln=0.0, mx=0.0, t0=ts, t1=ts)
                b10["h"] = max(b10["h"], px); b10["l"] = min(b10["l"], px)
                if ts >= b10["t1"]:
                    b10["c"] = px; b10["t1"] = ts
                if ts < b10["t0"]:
                    b10["o"] = px; b10["t0"] = ts
                if side_sell: b10["vs"] += sz
                else:         b10["vb"] += sz
                b10["n"] += 1; b10["mx"] = max(b10["mx"], sz)
                if is_liq:
                    b10["nl"] += 1; b10["ln"] += px * sz
                b, neu = self._stueck(self.bars, self.bars_fertig, (ts // 60_000 * 60, coin), entscheid, "spaet_min")
                if neu:
                    b.update(o=px, h=px, l=px, c=px, v=0.0, n=0, t0=ts, t1=ts)
                b["h"] = max(b["h"], px); b["l"] = min(b["l"], px)
                if ts >= b["t1"]:
                    b["c"] = px; b["t1"] = ts
                if ts < b["t0"]:
                    b["o"] = px; b["t0"] = ts
                b["v"] += sz; b["n"] += 1

        # Adressen einsammeln, inklusive des Dex, auf dem sie gehandelt haben
        for addr in (t.get("users") or []):
            if isinstance(addr, str) and addr.startswith("0x"):
                self.seen_address(addr, ts, dex, px * sz)

        # Echte Liquidation?
        liq = t.get("liquidation")     # im öffentlichen Feed nie gesetzt; bleibt für den Fall, dass es kommt
        if liq:
            self.record_liquidation(ts // 1000, coin, liq.get("liquidatedUser"), liq.get("method") or "market",
                                    float(liq.get("markPx") or 0), px, sz, t.get("side"), int(t.get("tid", 0)))

    def _jetzt(self) -> float:
        return time.time() if self._uhr is None else float(self._uhr)

    def _doppelt(self, coin: str, t: dict, ts_ms: int) -> bool:
        """23.82 (U222): Trade mit derselben (Zeit, tid) je Coin in den letzten TID_HALTEN_S schon gezählt (Wiederholung beim Neuverbinden)?
        Die Hyperliquid-Doku nennt (Zeit, Coin, tid) als eindeutigen Schlüssel."""
        try:
            tid = int(t.get("tid") or 0)
        except (TypeError, ValueError):
            return False
        if not tid:
            return False
        e = self._tids.get(coin)
        if e is None:
            e = self._tids[coin] = (set(), deque())
        sch = (ts_ms, tid)
        if sch in e[0]:
            self.u222["doppelt"] += 1
            return True
        e[0].add(sch); e[1].append(sch)
        return False

    def _tids_aufraeumen(self) -> None:
        """Entdoppeln: vergessen, was mehr als TID_HALTEN_S Börsenzeit zurückliegt; höchstens TID_MAX_JE_COIN je Coin (Sicherheitsventil)."""
        grenze = self._hw - TID_HALTEN_S * 1000
        for menge, schlange in self._tids.values():
            while schlange and (schlange[0][0] < grenze or len(schlange) > TID_MAX_JE_COIN):
                menge.discard(schlange.popleft())

    def _hw_merken(self) -> None:
        """23.82 (U222): höchste Börsenzeit dieses Dienstes (mindestens die des vorigen) in meta -- beim Beenden nach dem letzten Schreiben;
        der nächste Start zählt Wiederholungen bis dahin nicht noch einmal."""
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('u222_hw_ms', ?)", (str(max(self._hw, self._hw_alt or 0)),))

    def _hw_alt_holen(self) -> int:
        """Höchste Börsenzeit des vorigen Dienstes (meta u222_hw_ms, bei jedem Schreiben und beim Beenden gesetzt); fehlt sie (Recorder vor
        23.82), der Start dieses Dienstes."""
        if self._hw_alt is None:
            v = None
            try:
                r = self.con.execute("SELECT v FROM meta WHERE k='u222_hw_ms'").fetchone()
                v = int(r[0]) if r and r[0] else None
            except (sqlite3.Error, ValueError, TypeError):
                v = None
            self._hw_alt = v if v is not None else int(self.started_at) * 1000
        return self._hw_alt

    def _grenze_holen(self, coin: str):
        """Letzte Minute des vorigen Dienstes für diesen Coin (bars, höchstens einen Tag vor dessen letzter Börsenzeit gesucht)."""
        if coin not in self._grenze:
            g = None
            try:
                r = self.con.execute("SELECT MAX(ts) FROM bars WHERE coin=? AND ts>=?", (coin, self._hw_alt_holen() // 1000 - 86_400)).fetchone()
                g = int(r[0]) if r and r[0] is not None else None
            except sqlite3.Error:
                g = None
            self._grenze[coin] = g
        return self._grenze[coin]

    def _bar_entscheid(self, coin: str, ts_ms: int):
        """
        23.82 (U222): Zählt der Trade für die Bars? Einmal je Trade, für Minute und 10-s-Stück gleich. None (gezählt): bis zur höchsten
        Börsenzeit des vorigen Dienstes („vor_start“, schon gezählt oder womöglich doppelt) oder älter als jede gehaltene Minute
        („zu_alt“, fast sicher eine Wiederholung). Sonst True, bzw. "basis" für die letzte Minute des vorigen Dienstes (beim ersten
        Schreiben mit ihrer Zeile zusammenführen).
        """
        if ts_ms <= self._hw_alt_holen():
            self.u222["vor_start"] += 1
            return None
        m = ts_ms // 60_000 * 60
        k = (m, coin)
        if k not in self.bars and k not in self.bars_fertig and m + 60 <= self._hw / 1000 - BAR_HALTEN_S:
            self.u222["zu_alt"] += 1
            return None
        g = self._grenze_holen(coin)
        if g is not None and m < g:                                   # nur bei falscher Uhr des Pi denkbar: geschriebene Minute schützen
            self.u222["vor_start"] += 1
            return None
        self._hw = max(self._hw, min(int(ts_ms), int(self._jetzt() * 1000) + 60_000))
        return "basis" if g is not None and m == g else True

    def _stueck(self, offen: dict, fertig: dict, k: tuple, entscheid, zaehler: str):
        """23.82 (U222): (Aggregat, neu) für das Stück k. Offen: weiterschreiben; geschrieben und gehalten: zurückholen (später Trade, wird
        vollständig neu geschrieben); sonst neu -- „basis“: beim ersten Schreiben mit der Zeile des vorigen Dienstes zusammenführen."""
        b = offen.get(k)
        if b is not None:
            return b, False
        e = fertig.pop(k, None)
        if e is not None:
            self.u222[zaehler] += 1
            offen[k] = e
            return e, False
        b = offen[k] = ({"basis": True} if entscheid == "basis" else {})
        return b, True

    def _mit_alter_zeile(self, b: dict, k: tuple, tabelle: str) -> None:
        """23.82 (U222): erstes Schreiben der letzten Minute des vorigen Dienstes (und ihrer 10-s-Stücke): die vorhandene Zeile und die
        neuen Trades zusammenführen -- deren Trades liegen alle danach (Börsenzeit über u222_hw_ms), also bleibt die Eröffnung der Zeile,
        der Schluss kommt von den neuen."""
        b.pop("basis", None)
        try:
            if tabelle == "bars":
                r = self.con.execute("SELECT open, high, low, close, volume, trades FROM bars WHERE ts=? AND coin=?", k).fetchone()
            else:
                r = self.con.execute("SELECT open, high, low, close, vol_buy, vol_sell, trades, n_liq, liq_notional, max_sz FROM bars10 "
                                     "WHERE ts=? AND coin=?", k).fetchone()
        except sqlite3.Error:
            r = None
        if not r:
            return
        self.u222["zusammengefuehrt"] += 1
        b["o"] = r[0]; b["t0"] = -1
        b["h"] = max(b["h"], r[1]); b["l"] = min(b["l"], r[2])
        if tabelle == "bars":
            b["v"] += r[4] or 0.0; b["n"] += int(r[5] or 0)
        else:
            b["vb"] += r[4] or 0.0; b["vs"] += r[5] or 0.0; b["n"] += int(r[6] or 0); b["nl"] += int(r[7] or 0)
            b["ln"] += r[8] or 0.0; b["mx"] = max(b["mx"], r[9] or 0.0)

    def record_liquidation(self, ts: int, coin: str, user: str, method: str, mark_px: float,
                           px: float, sz: float, side: str, tid: int) -> None:
        """Eine Liquidation festhalten -- beobachtet (userEvents) oder abgeleitet (Polling)."""
        self.stats["liquidations"] += 1
        self.liq_rows_pending.append((ts, coin, user, method, mark_px, px, sz, side, tid))   # flush_round schreibt gesammelt
        # in die Echtzeit-Signale einspeisen: Liquidations-Auslöser, 10-s-Bars
        if method != "inferred" and coin in self.symbol_of:
            lt = self.liq_times.get(coin)
            if lt is not None:
                lt.append(ts * 1000)
            slot = ts // 10 * 10
            b10 = self.bars10.get((slot, coin))
            if b10 is None and (slot, coin) in self.bars10_fertig:      # 23.82 (U222): Stück schon geschrieben -> zurückholen, neu schreiben
                b10 = self.bars10[(slot, coin)] = self.bars10_fertig.pop((slot, coin))
                self.u222["liq_spaet"] += 1
            if b10 is not None:
                b10["nl"] += 1; b10["ln"] += px * sz

    def on_user_event(self, addr: str, d: dict) -> None:
        """
        userEvents eines abonnierten Kontos. Interessant sind Fills mit
        'liquidation'-Objekt: Das ist die einzige Stelle, an der Hyperliquid
        eine Liquidation als solche kennzeichnet.
        """
        for f in d.get("fills") or []:
            liq = f.get("liquidation")
            if not liq:
                continue
            sym = str(f.get("coin", ""))
            coin = self.coin_of.get(sym) or sym.split(":")[-1]
            try:
                ts = int(f.get("time", 0)) // 1000 or int(time.time())
                px = float(f.get("px") or 0); sz = float(f.get("sz") or 0)
            except (TypeError, ValueError):
                continue
            if not px or not sz:
                continue
            self.record_liquidation(ts, coin, liq.get("liquidatedUser") or addr, liq.get("method") or "market",
                                    float(liq.get("markPx") or 0), px, sz, f.get("side") or "",
                                    int(f.get("tid") or 0) or int.from_bytes(hashlib.blake2b(f"{addr}|{coin}|{ts}|{px}".encode(), digest_size=6).digest(), "big"))   # N5: prozessfest
        # 23.23 (U58): Fills ohne Liquidation sind seit der Umstellung auf die Darwin-Liste der eigentliche Zweck des Abos:
        # vollständig (Richtung, closedPnl, Gebühr, tid) binnen Sekunden, in allen Perp-Coins, ab lb_fills_min_usd (23.34: Konten der
        # Darwin-Liste ohne Mindestbetrag, gedeckelt je Stunde -- sonst blieb eine in kleine Stücke zerlegte Eröffnung unsichtbar).
        # Spot-Fills (@-Namen) überlassen wir dem REST-Nachtrag, der die Spot-Namen auflöst.
        neu = []
        for f in d.get("fills") or []:
            if f.get("liquidation"):
                continue
            try:
                raw = str(f.get("coin", "")); px = float(f.get("px") or 0); sz = float(f.get("sz") or 0)
                if not raw or raw.startswith("@") or "/" in raw:
                    continue
                if px * sz < self.cfg.lb_fills_min_usd and (addr.lower() not in self._darwin_set          # 23.34: Darwin-Konten ohne Mindestbetrag
                                                            or not self.darwin_klein_frei("ue", addr.lower(), int(f.get("time", 0)) // 1000)):
                    continue
                coin = self.coin_of.get(raw) or raw.split(":")[-1]
                dd = str(f.get("dir", "")).lower(); side = str(f.get("side", ""))
                buy = 1 if ("open long" in dd or "close short" in dd or "buy" in dd) else 0 if ("open short" in dd or "close long" in dd or "sell" in dd) \
                    else (1 if side.upper().startswith("B") else 0)
                neu.append((int(f.get("time", 0)) // 1000, addr.lower(), coin, "perp", str(f.get("dir", "")), side, px, sz, px * sz,
                            float(f.get("closedPnl") or 0), float(f.get("fee") or 0), int(f.get("tid") or 0), buy))
            except (TypeError, ValueError):
                continue
        if neu:
            self.ue_fills_pending.extend(neu)
            self.stats["ue_fills"] = self.stats.get("ue_fills", 0) + len(neu)

    def infer_liquidations(self, addr: str, before: list, after: list, since: int, now: int) -> None:
        """
        Ableitung für Konten ohne Abo: Eine Position ist zwischen zwei Abfragen
        verschwunden (oder auf unter 10 % geschrumpft), und der Kurs hat in der
        Zwischenzeit ihren Liquidationspreis berührt -> mit hoher Wahrscheinlichkeit
        liquidiert. Zeitpunkt = erste Minutenkerze, die das Niveau berührt hat.
        """
        if addr in self.event_subs_ok or not before or since <= 0:      # K1: nur BESTÄTIGTE Abos brauchen keine Ableitung
            return
        remaining = {(p["coin"], p["side"]): p for p in after}
        for p in before:
            liq = p.get("liq_px") or 0
            if liq <= 0:
                continue
            rest = remaining.get((p["coin"], p["side"]))
            if rest and abs(rest["size"]) > 0.1 * abs(p["size"]):
                continue                          # Position noch da
            if p["side"] == "long":
                row = self.con.execute("SELECT ts, low FROM bars WHERE coin=? AND ts>=? AND ts<=? AND low<=? "
                                       "ORDER BY ts LIMIT 1", (p["coin"], since - 60, now, liq * 1.002)).fetchone()
                side = "A"
            else:
                row = self.con.execute("SELECT ts, high FROM bars WHERE coin=? AND ts>=? AND ts<=? AND high>=? "
                                       "ORDER BY ts LIMIT 1", (p["coin"], since - 60, now, liq * 0.998)).fetchone()
                side = "B"
            if not row:
                continue                          # Niveau nie berührt -> freiwillig geschlossen
            # Deterministische Kennung: hash() ist je Prozess gesalzen -- nach jedem Neustart
            # bekam dieselbe abgeleitete Liquidation eine neue tid und INSERT OR IGNORE griff
            # nicht mehr (Audit M3). blake2b liefert über Neustarts dieselbe Zahl.
            import hashlib
            tid = int.from_bytes(hashlib.blake2b(f"{addr}|{p['coin']}|{p['side']}|{int(row[0])}".encode(), digest_size=6).digest(), "big")
            self.record_liquidation(int(row[0]), p["coin"], addr, "inferred", liq, liq, abs(p["size"]), side, tid)
            self.stats["liq_inferred"] += 1

    def darwin_klein_frei(self, quelle: str, a: str, ts_s: int) -> bool:
        """23.34: Deckel für Fills unter lb_fills_min_usd (nur Darwin-Liste): höchstens DARWIN_KLEIN_MAX_H je Konto, Stunde und Quelle."""
        k = (quelle, a, int(ts_s) // 3600)
        n = self._darwin_klein.get(k, 0)
        if n >= DARWIN_KLEIN_MAX_H:
            self.stats["darwin_fills_gedeckelt"] = self.stats.get("darwin_fills_gedeckelt", 0) + 1
            return False
        self._darwin_klein[k] = n + 1
        if len(self._darwin_klein) > 20_000:                     # alte Stunden vergessen
            h = int(ts_s) // 3600
            self._darwin_klein = {kk: v for kk, v in self._darwin_klein.items() if kk[2] >= h - 1}
        return True

    def stream_richtung(self, a: str, coin: str, kauf: bool, ts_s: int) -> str:
        """
        Richtung eines Stream-Fills ("Open Long*" usw.) aus der bekannten Position: Leaderboard-Stand (alle 2 min), Poller-Stand
        (Wale, Pool-Konten alle 10 min) -- 23.34: wer in den letzten 20 min abgefragt wurde und keine Position hat, ist flach (vorher
        „stream“ = unbekannt, wenn das Konto gar keine Position hielt); und die Richtung der eigenen abgeleiteten Eröffnungen gilt,
        solange sie jünger ist als der letzte Stand. Ohne jede Kenntnis: "stream".
        """
        pos = None
        sp = self._stream_pos.get((a, coin))
        if sp and sp[1] > max(self.polled_at.get(a, 0), self._lb_pos_ts if a in self.lb_pos_konten else 0):
            pos = sp[0]
        if pos is None:
            pos = self.lb_pos_side.get((a, coin))
        if pos is None:
            for p_ in self.positions.get(a, ()):
                if p_.get("coin") == coin and p_.get("side") in ("long", "short"):
                    pos = p_["side"]; break
        if pos is None and (a in self.lb_pos_konten or a in self.positions or ts_s - self.polled_at.get(a, 0) <= 1200):
            pos = "flat"                            # Positionen bekannt, keine in diesem Coin: Eröffnung
        if pos is None:
            return "stream"
        if kauf:
            r = "Close Short*" if pos == "short" else "Open Long*"
        else:
            r = "Close Long*" if pos == "long" else "Open Short*"
        if r.startswith("Open"):
            self._stream_pos[(a, coin)] = ("long" if kauf else "short", ts_s)
            if len(self._stream_pos) > 20_000:
                self._stream_pos = {k: v for k, v in self._stream_pos.items() if v[1] >= ts_s - 3600}
        return r

    def darwin_ziele(self) -> list:
        """23.23: Konten der Darwin-Liste aus dem Prognosespeicher (Dashboard: learned '*'/'darwin'), beste zuerst; alle 5 min."""
        jetzt = time.time()
        if jetzt - getattr(self, "_darwin_ts", 0.0) < 300:
            return getattr(self, "_darwin_liste", [])
        self._darwin_ts = jetzt
        pfad = os.environ.get("HL_FORECAST_DB") or os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "forecasts.db")
        liste = getattr(self, "_darwin_liste", [])
        try:
            c = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=2)
            try:
                r = c.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
            finally:
                c.close()
            st = json.loads(r[0]) if r and r[0] else {}
            liste = [str(a).lower() for a in (st.get("reihe") or st.get("liste") or [])]
            self._darwin_set = {str(a).lower() for a in (list(st.get("liste") or []) + list(st.get("reihe") or []))} - self.gesperrt   # 23.34: alle Mitglieder
        except (sqlite3.Error, ValueError, TypeError, OSError):
            pass
        self._darwin_liste = liste
        self.stats["darwin_konten"] = len(self._darwin_set)
        return liste

    def update_event_subs(self) -> None:
        """
        Wale und Konten ab stop_min_usd bekommen ein userEvents-Abo, höchstens
        max_event_subs. Änderungen wandern in die Warteschlange des WS-Tasks.
        """
        # 23.23 (U58): Die Plätze gehören der Darwin-Liste (bestes Timing zuerst) -- ihre Trades kommen so binnen Sekunden
        # mit Richtung und closedPnl. Die direkte Liquidationsbeobachtung der größten Positionen brachte in 24 h keinen
        # Treffer (U1); Liquidationen aller Konten kommen weiter über die Ableitung. Ohne Liste gilt die alte Auswahl.
        ziele = [a for a in self.darwin_ziele() if a not in self.gesperrt][: self.cfg.max_event_subs]
        if ziele:
            wanted = set(ziele)
            for a in wanted - self.event_subs:
                self.event_queue.append(("subscribe", a))
            for a in self.event_subs - wanted:
                self.event_queue.append(("unsubscribe", a)); self.event_subs_ok.discard(a)
            self.event_subs = wanted
            self.stats["event_subs"] = len(wanted); self.stats["event_subs_quelle"] = "Darwin-Liste"
            return
        self.stats["event_subs_quelle"] = "größte Positionen"
        # K1 (Audit v10): höchstens max_event_subs (10) verschiedene Nutzer -- die größten Positionen zuerst,
        # gesperrte Konten nie (bis 23.85 kamen ihre Liquidationen über die Ableitung der 6-h-Stufe; seit 23.86 gar nicht abgefragt)
        alle = sorted(((sum(q.get("pos_value", 0) for q in ps), a) for a, ps in self.positions.items()
                       if a not in self.gesperrt and sum(q.get("pos_value", 0) for q in ps) >= self.cfg.stop_min_usd), reverse=True)
        wanted = set()
        for _, a in alle:
            if len(wanted) >= self.cfg.max_event_subs:
                break
            wanted.add(a)
        for a in wanted - self.event_subs:
            self.event_queue.append(("subscribe", a))
        for a in self.event_subs - wanted:
            self.event_queue.append(("unsubscribe", a)); self.event_subs_ok.discard(a)
        self.event_subs = wanted
        self.stats["event_subs"] = len(wanted)

    # -- Tick-Aufzeichnung -------------------------------------------------

    def buffer_tick(self, coin: str, ts: int, px: float, sz: float,
                    side: str, liq: bool, tid: int) -> None:
        c = self.cfg
        buf = self.ticks.get(coin)
        if buf is None:
            buf = self.ticks[coin] = deque()
            self.sec_px[coin] = deque(maxlen=130)
            self.liq_times[coin] = deque(maxlen=200)
        buf.append((ts, px, sz, side, liq, tid))
        cutoff = ts - c.tick_buffer_min * 60_000
        while buf and buf[0][0] < cutoff:
            buf.popleft()

        # Sekundenraster für die Bewegungsprüfung
        sec = ts // 1000
        sp = self.sec_px[coin]
        if not sp or sp[-1][0] != sec:
            sp.append((sec, px))
        if liq:
            self.liq_times[coin].append(ts)

        # Auslösebedingungen prüfen -- gilt für Start UND Verlängerung
        reason, move, ref = None, 0.0, px
        p60 = self._px_ago(sp, sec, 60)
        p10 = self._px_ago(sp, sec, 10)
        if p60 and abs(px / p60 - 1) >= c.tick_move_pct:
            reason, move, ref = "move60", px / p60 - 1, p60
        elif p10 and abs(px / p10 - 1) >= c.tick_flash_pct:
            reason, move, ref = "flash10", px / p10 - 1, p10
        else:
            lt = self.liq_times[coin]
            recent = sum(1 for x in lt if ts - x <= 30_000)
            if recent >= c.tick_liq_burst:
                reason, move = "liqburst", (px / p60 - 1) if p60 else 0.0
                ref = p60 or px

        rec = self.tick_rec.get(coin)
        if rec:
            rec["extreme"] = (min(rec["extreme"], px) if rec["move"] < 0
                              else max(rec["extreme"], px))
            # Nachlauf nur verlängern, wenn die Bewegung WEITERGEHT. Bei jedem
            # Trade zu verlängern hieße bei BTC: die Aufzeichnung endet nie.
            if reason:
                rec["end"] = max(rec["end"], ts + c.tick_post_sec * 1000)
            return

        if reason:
            self.tick_rec[coin] = {
                "trigger": ts, "start": ts - c.tick_pre_sec * 1000,
                "end": ts + c.tick_post_sec * 1000, "reason": reason,
                "move": move, "px_before": ref, "px_trigger": px, "extreme": px,
            }
            self.stats["tick_events"] += 1
            print(f"  Tick-Aufzeichnung {coin}: {reason} {move:+.2%} bei {px}")

    @staticmethod
    def _px_ago(sp: deque, sec: int, ago: int) -> float | None:
        """Preis vor 'ago' Sekunden aus dem Sekundenraster, oder None."""
        target = sec - ago
        best = None
        for s_, p_ in sp:
            if s_ <= target:
                best = p_
            else:
                break
        return best

    def finish_tick_recordings(self, force: bool = False) -> None:
        """Abgeschlossene Aufzeichnungen aus dem Puffer in die Datenbank schreiben."""
        now_ms = int(time.time() * 1000)
        for coin, rec in list(self.tick_rec.items()):
            if not force and now_ms < rec["end"]:
                continue
            buf = self.ticks.get(coin, ())
            rows = [(t, px, sz, sd, int(lq), tid) for t, px, sz, sd, lq, tid in buf
                    if rec["start"] <= t <= rec["end"]]
            marks = [(t, m, o) for t, m, o in self.mark_hist.get(coin, ())
                     if rec["start"] <= t <= rec["end"]]
            books = [(t, lv) for t, lv in self.books.get(coin, ())
                     if rec["start"] <= t <= rec["end"]]
            cur = self.con.execute(
                "INSERT INTO tick_events (coin, t_trigger, t_start, t_end, reason, "
                "move_pct, px_before, px_trigger, px_extreme, n_ticks, n_liqs, complete) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (coin, rec["trigger"], rec["start"], rec["end"], rec["reason"],
                 rec["move"], rec["px_before"], rec["px_trigger"], rec["extreme"],
                 len(rows), sum(r[4] for r in rows), int(not force)))
            eid = cur.lastrowid
            self.con.executemany(
                "INSERT OR IGNORE INTO ticks VALUES (?,?,?,?,?,?,?,?)",
                [(eid, t, coin, px, sz, sd, lq, tid) for t, px, sz, sd, lq, tid in rows])
            self.con.executemany(
                "INSERT OR IGNORE INTO mark_ticks VALUES (?,?,?,?,?)",
                [(eid, t, coin, m, o) for t, m, o in marks])
            self.con.executemany(
                "INSERT OR IGNORE INTO book_ticks VALUES (?,?,?,?)",
                [(eid, t, coin, lv) for t, lv in books])
            self.con.commit()                              # sofort: nicht mit offener Transaktion in die Kaskade
            del self.tick_rec[coin]
            print(f"  Tick-Aufzeichnung {coin} gesichert ({rec['reason']}): "
                  f"{len(rows):,} Trades, {len(marks):,} Markpreise, "
                  f"{len(books):,} Buch-Snapshots, Extrem {rec['extreme']}")

    def on_book(self, d: dict) -> None:
        """
        Orderbuch: Kennzahlen alle 30 s dauerhaft, Top-10-Snapshots im Ringpuffer.

        Die Tiefe nahe am Kurs ist der verlässlichste Vorläufer eines
        Flash-Crash -- sie dünnt aus, bevor sich der Preis bewegt.
        """
        symbol = d.get("coin")
        coin = self.coin_of.get(symbol) or str(symbol).split(":")[-1]
        if coin not in self.symbol_of:
            return
        levels = d.get("levels") or []
        if len(levels) != 2 or not levels[0] or not levels[1]:
            return
        try:
            ts = int(d.get("time") or time.time() * 1000)
            bids = [(float(l["px"]), float(l["sz"])) for l in levels[0][:10]]
            asks = [(float(l["px"]), float(l["sz"])) for l in levels[1][:10]]
        except (TypeError, ValueError, KeyError):
            return
        self.stats["book_updates"] += 1
        if bids and asks and bids[0][0] > 0 and asks[0][0] > 0:
            self.buch_mitte[coin] = ((bids[0][0] + asks[0][0]) / 2, ts // 1000)   # 23.125 (U311): Mitte für die Tiefe bis ±1 %

        # Ringpuffer für Ereignisfenster
        buf = self.books.get(coin)
        if buf is None:
            buf = self.books[coin] = deque()
        buf.append((ts, json.dumps([[[p, z] for p, z in bids], [[p, z] for p, z in asks]],
                                   separators=(",", ":"))))
        cutoff = ts - self.cfg.tick_buffer_min * 60_000
        while buf and buf[0][0] < cutoff:
            buf.popleft()

        # Kennzahlen alle 30 Sekunden (vorher 5 s: 4.100 Zeilen/h, das Dashboard liest nur die jüngste)
        sec5 = ts // 30000 * 30
        if self.book_last_summary.get(coin) == sec5:
            return
        self.book_last_summary[coin] = sec5
        bid, ask = bids[0][0], asks[0][0]
        if bid <= 0 or ask <= 0:
            return
        mid = (bid + ask) / 2

        def depth(side, bps):
            lim = mid * bps / 10_000
            return sum(p * z for p, z in side if abs(p - mid) <= lim)

        b10, a10 = depth(bids, 10), depth(asks, 10)
        b25, a25 = depth(bids, 25), depth(asks, 25)
        b50, a50 = depth(bids, 50), depth(asks, 50)
        b100, a100 = depth(bids, 100), depth(asks, 100)
        imb = (b50 - a50) / (b50 + a50) if (b50 + a50) > 0 else 0.0
        # Nur puffern: Ein direkter INSERT im WebSocket-Handler eröffnete eine Transaktion, die
        # bis zum nächsten Commit der Poll-Runde offen blieb -- die Diagnose zeigte 3 s Haltezeit
        # für "INSERT OR REPLACE INTO book_summary". flush_round schreibt den jüngsten Stand je
        # 5-s-Fenster und Coin in derselben kurzen Transaktion wie den Rest der Runde.
        self.book_rows_pending[(sec5, coin)] = (sec5, coin, bid, ask, (ask - bid) / mid * 10_000,
                                                b10, a10, b25, a25, b50, a50, b100, a100, imb)

    def on_ctx(self, d: dict) -> None:
        self.jobs.setdefault("Feeds (WebSocket)", {})["last"] = int(time.time())
        """Markpreis, Oracle, Funding und OI pro Minute festhalten."""
        symbol = d.get("coin")
        coin = self.coin_of.get(symbol) or str(symbol).split(":")[-1]
        c = d.get("ctx") or {}
        try:
            row = {
                "mark": float(c.get("markPx") or 0),
                "oracle": float(c.get("oraclePx") or 0),
                "mid": float(c.get("midPx") or 0),
                "funding": float(c.get("funding") or 0),
                "oi": float(c.get("openInterest") or 0),
                "premium": float(c.get("premium") or 0),
            }
        except (TypeError, ValueError):
            return
        if row["mark"] <= 0:
            return
        row["ibid"], row["iask"] = impact_aus(c.get("impactPxs"))          # 23.96 (U246): Impact-Preise der Börse, sonst None
        self.ctx[coin] = row
        self.stats["ctx_updates"] += 1
        mh = self.mark_hist.get(coin)
        if mh is None:
            mh = self.mark_hist[coin] = deque()
        now_ms = int(time.time() * 1000)
        mh.append((now_ms, row["mark"], row["oracle"]))
        cutoff = now_ms - self.cfg.tick_buffer_min * 60_000
        while mh and mh[0][0] < cutoff:
            mh.popleft()
        minute = int(time.time()) // 60 * 60
        self.ctx_pending[(minute, coin)] = row     # letzter Wert der Minute gewinnt

    def flush_bars10(self, final: bool = False, jetzt: float | None = None) -> None:
        """10-s-Stücke schreiben, sobald sie vor mindestens BAR_GRACE_S geendet haben (U222, wie flush_bars); gehalten wie ihre Minute;
        dazu die tids aufräumen -- auch wenn das Schreiben scheitert (dann bleiben die Stücke offen für die nächste Runde)."""
        jetzt = self._jetzt() if jetzt is None else float(jetzt)
        cur = int(jetzt - BAR_GRACE_S) // 10 * 10
        done = [k for k in self.bars10 if final or k[0] < cur]
        try:
            if done:
                rows = []
                for k in done:
                    b = self.bars10[k]
                    if b.get("basis"):
                        self._mit_alter_zeile(b, k, "bars10")
                    rows.append((k[0], k[1], b["o"], b["h"], b["l"], b["c"], b["vb"], b["vs"], b["n"], b["nl"], b["ln"], b["mx"]))
                self.con.executemany("INSERT OR REPLACE INTO bars10 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
                for k in done:
                    self.bars10_fertig[k] = self.bars10.pop(k)
        finally:
            grenze = self._hw / 1000 - BAR_HALTEN_S
            for k in [k for k in self.bars10_fertig if k[0] // 60 * 60 + 60 <= grenze]:
                del self.bars10_fertig[k]
            self._tids_aufraeumen()

    def write_order_levels(self, now: int) -> None:
        """
        Schlüsselniveaus und Ordermix je Coin aus den jüngsten Orders (<= 20 min
        alt) aller abgefragten Konten -- dieselben Regeln wie keyLevels() im
        Dashboard: Cluster im 0,25-%-Raster innerhalb +-30 %, je Art das größte.
        """
        cutoff = time.time() - 6 * 3600         # Konten der untersten Stufe sind bis zu 6 h alt
        rows_out = []
        for coin in self.symbol_of:
            px = self.ref_px(coin)
            if not px:
                continue
            clusters: dict[tuple[str, float], list] = defaultdict(lambda: [0.0, 0])
            accounts, n_orders = set(), 0
            for addr, orders in self.orders.items():
                if self.stop_polled_at.get(addr, 0) < cutoff:
                    continue
                for c, kind, opx, notional in orders:
                    if c != coin or not opx or abs(opx / px - 1) > 0.30:
                        continue
                    cell = clusters[(kind, self.bucket_of(opx))]
                    cell[0] += notional; cell[1] += 1
                    accounts.add(addr); n_orders += 1
            if not n_orders:
                continue

            def best(kind, sign):
                cands = [(b, v[0]) for (k, b), v in clusters.items()
                         if k == kind and (b > px) == (sign > 0)]
                return max(cands, key=lambda x: x[1]) if cands else (None, None)

            def total(kind, within=0.30):
                return sum(v[0] for (k, b), v in clusters.items() if k == kind and abs(b / px - 1) <= within)

            def side_sum(kind, sign, within):
                return sum(v[0] for (k, b), v in clusters.items()
                           if k == kind and (b > px) == (sign > 0) and abs(b / px - 1) <= within)

            sp, su = best("limit_buy", -1); rp, ru = best("limit_sell", 1)
            tlp, tlu = best("tp_sell", 1); tsp, tsu = best("tp_buy", -1)
            ssp, ssu = best("stop_sell", -1); sbp, sbu = best("stop_buy", 1)
            rows_out.append((now, coin, px, len(accounts),
                             sp, su, rp, ru, tlp, tlu, tsp, tsu, ssp, ssu, sbp, sbu,
                             side_sum("stop_sell", -1, 0.02), side_sum("stop_buy", 1, 0.02),
                             total("limit_buy"), total("limit_sell"), total("stop_sell"), total("stop_buy"),
                             total("tp_sell"), total("tp_buy"), n_orders))
        if rows_out:
            self.con.executemany("INSERT OR REPLACE INTO order_levels VALUES ("
                                 + ",".join("?" * 25) + ")", rows_out)

    def write_proximity(self) -> None:
        """Nächstes großes Cluster über und unter dem Kurs, je Minute."""
        now = int(time.time()) // 60 * 60
        rows = []
        for coin in self.symbol_of:
            px = self.ref_px(coin)
            if not px:
                continue
            # Buckets aus den Positionen im Speicher, nur innerhalb 5 %
            agg: dict[tuple[float, str], float] = defaultdict(float)
            for addr, positions in self.positions.items():
                for p in positions:
                    if p["coin"] != coin or p["liq_px"] <= 0:
                        continue
                    if abs(p["liq_px"] / px - 1) > 0.05:
                        continue
                    agg[(self.bucket_of(p["liq_px"]), p["side"])] += p["notional"]
            ups = [(b, n) for (b, sd), n in agg.items() if sd == "short" and b > px]
            dns = [(b, n) for (b, sd), n in agg.items() if sd == "long" and b < px]
            up = max(ups, key=lambda x: x[1]) if ups else (None, 0.0)
            dn = max(dns, key=lambda x: x[1]) if dns else (None, 0.0)
            rows.append((now, coin, px,
                         up[0], up[1], (up[0] / px - 1) if up[0] else None,
                         dn[0], dn[1], (1 - dn[0] / px) if dn[0] else None))
        if rows:
            self.con.executemany(
                "INSERT OR REPLACE INTO proximity VALUES (?,?,?,?,?,?,?,?,?)", rows)

    def maybe_control_window(self) -> None:
        """
        Kontrollfenster: ein zufälliges Fenster ohne Auslöser, täglich ein- bis
        zweimal. Ohne diese Fälle kennt eine spätere Simulation nur die Treffer,
        nie die Fehlalarme.
        """
        if time.time() < self.next_control:
            return
        now_ms = int(time.time() * 1000)
        c = self.cfg
        for coin in self.symbol_of:
            if coin in self.tick_rec:
                continue
            self.tick_rec[coin] = {
                "trigger": now_ms, "start": now_ms - c.tick_pre_sec * 1000,
                "end": now_ms + c.tick_post_sec * 1000, "reason": "control",
                "move": 0.0, "px_before": self.ref_px(coin),
                "px_trigger": self.ref_px(coin), "extreme": self.ref_px(coin),
            }
        self.next_control = time.time() + random.uniform(10 * 3600, 20 * 3600)
        print("  Kontrollfenster gestartet (zufälliges Fenster ohne Auslöser)")

    def flush_ctx(self, final: bool = False) -> None:
        cur_min = int(time.time()) // 60 * 60
        done = [k for k in self.ctx_pending if final or k[0] < cur_min]
        if done:
            fertig = [(k, self.ctx_pending.pop(k)) for k in done]
            self.con.executemany(
                "INSERT OR REPLACE INTO ctx_bars VALUES (?,?,?,?,?,?,?,?)",
                [(k[0], k[1], r["mark"], r["oracle"], r["mid"], r["funding"],
                  r["oi"], r["premium"])
                 for k, r in fertig])
            try:                                   # 23.96 (U246): Impact-Preise der Börse; ein Fehler hier kostet ctx_bars nichts
                self.con.executemany(
                    "INSERT OR REPLACE INTO impact_bars VALUES (?,?,?,?,?)",
                    [(k[0], k[1], r["mid"], r.get("ibid"), r.get("iask")) for k, r in fertig])
            except sqlite3.Error:
                self.stats["impact_fehler"] += 1

    def seen_address(self, addr: str, ts: int, dex: str = "", usd: float = 0.0) -> None:
        """
        Adresse aus dem Trade-Feed merken -- im Speicher. Vorher schrieb jeder Trade eine
        Zeile in die Datenbank: ~1.000 Aktualisierungen pro Minute auf zufällige Seiten einer
        130.000-Zeilen-Tabelle, jede eine 4-KB-Seite ins Log und beim Checkpoint noch einmal --
        die halbe Gigabyte-Stunde Schreiblast. Jetzt: neue Adressen alle 10 min eingetragen,
        last_trade einmal pro Stunde, jede Seite einmal statt hundertmal.
        """
        known = self.addr_dex.setdefault(addr, set())
        known.add(dex)
        self.addr_seen[addr] = ts
        if usd > 0:                                                   # 23.86: Umsatz seit der letzten Abfrage (Vorrang in due_addresses)
            self.addr_umsatz[addr] = self.addr_umsatz.get(addr, 0.0) + usd
        m = self.addr_meta.get(addr)
        if m is None:
            self.addr_meta[addr] = [0, 0.0, ts, ts]
        else:
            m[2] = ts
        if addr not in self.addr_known:
            self.addr_new[addr] = ts

    def flush_addresses(self, full: bool = False) -> None:
        """Neue Adressen eintragen (alle 10 min); last_trade und last_poll aller gesammelten (stündlich oder full)."""
        if self.addr_new:
            rows = [(a, t, self.addr_seen.get(a, t), ",".join(sorted(self.addr_dex.get(a, set())))) for a, t in self.addr_new.items()]
            self.stueckweise("INSERT INTO addresses(addr, first_seen, last_trade, dexes) VALUES (?,?,?,?) "
                             "ON CONFLICT(addr) DO UPDATE SET last_trade=excluded.last_trade, dexes=excluded.dexes", rows)
            self.addr_known.update(self.addr_new); self.addr_new = {}
            self.stats["addr_inserted"] = self.stats.get("addr_inserted", 0) + len(rows)
        if full or time.time() - self._last_addr_full >= 3600:
            if self.addr_seen:
                self.stueckweise("UPDATE addresses SET last_trade=? WHERE addr=?", [(t, a) for a, t in self.addr_seen.items()])
                self.stats["addr_trade_flushed"] = self.stats.get("addr_trade_flushed", 0) + len(self.addr_seen); self.addr_seen = {}
            self.flush_addr_polls()
            self._last_addr_full = time.time()

    # -- Positions-Polling ---------------------------------------------------

    def lade_elite(self) -> None:
        """
        Elite-Konten aller Coins aus forecasts.db (vom Dashboard täglich gespeichert, Schlüssel
        'elite'). Anlass 15.09.: Ein Elite-Konto ging flat, fiel damit in die niedrigste Abfragestufe
        und eröffnete einen 9-Mio-Short, den der Poller 18 Stunden lang nicht sah. Elite-Konten
        werden deshalb unabhängig vom Positionswert im Wal-Takt (jede Minute) abgefragt.
        """
        if time.time() - getattr(self, "_elite_ts", 0) < 300:
            return
        self._elite_ts = time.time()
        pfad = os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "forecasts.db")   # forecasts.db liegt neben der Hauptdatenbank
        if not os.path.exists(pfad):
            return
        try:
            st = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=2)
            rows = st.execute("SELECT value FROM learned WHERE key='elite'").fetchall(); st.close()
            elite: set = set()
            for (v,) in rows:
                try:
                    elite.update(a.lower() for a in json.loads(v) if isinstance(a, str))
                except (ValueError, TypeError):
                    continue
            if elite != getattr(self, "elite_addrs", set()):
                print(f"  Elite-Konten mit Vorrang im Poller: {len(elite)}", flush=True)
            self.elite_addrs = elite
            self.stats["elite_addrs"] = len(elite)
        except sqlite3.Error:
            pass

    def due_addresses(self, limit: int) -> list[str]:
        """
        Drei Gruppen mit festem Budgetanteil, damit keine die andere verdrängt:

          A  Adressen MIT Position: fällige Wale zuerst, dann der Rest nach
             Überfälligkeit relativ zum Intervall seiner Stufe.             ~65 %
          B  Nie abgefragte Adressen, älteste zuerst. Ohne eigenen Anteil
             würden sie bei unendlicher "Überfälligkeit" alles verdrängen
             -- oder, umgekehrt sortiert, nie drankommen.                    ~25 %
          C  Bekannt leere Adressen und -- seit 23.86 -- kleine Konten (unter
             min_notional): nur, wenn sie seit der letzten Abfrage wieder
             gehandelt haben (last_trade > last_poll), sonst höchstens einmal
             am Tag. Ohne neuen Trade kann sich ihre Position nicht geändert
             haben -- wir sehen ja alle Feeds.                               ~10 %

        23.86 (U220, Entscheidung Nutzer 26.10.): Gesperrte Konten (Masterregel) werden nicht mehr abgefragt, auch nicht, wenn
        sie noch nie abgefragt wurden (bis 23.85 Rang 2 alle 6 h -- bei Überlast nie erreicht). „groß“ erst ab hot_notional =
        500.000 USD. Kleine Konten in Gruppe C, solange klein_nach_handel gilt (zurück mit --klein-regelmaessig). Gruppe C bedient
        die zuletzt Handelnden zuerst; ist sie voll, warten ältere Fälle -- darum kommt eine leere oder kleine Adresse, die seit ihrer
        letzten Abfrage mindestens vorrang_usd (25.000 USD) gehandelt hat (Summe aus dem Trade-Feed), in Gruppe A vor alle fälligen
        Konten von Rang 1 -- der größte Umsatz zuerst, höchstens VORRANG_ANTEIL der Runde (die übrigen bleiben in C), damit ein
        Ansturm (Crash) die großen Konten nicht verdrängt (unabhängige Durchsicht 26.10.: ohne Vorrang blieben neue große Positionen
        unter vielen kleinen Händlern liegen).
        Die Schleife zählt nebenbei die Konten je Stufe (stats „poller_stufen“) -- daraus rechnet die Statuszeile Bedarf gegen
        Budget wie der Bericht „Poller-Kapazität“.

        Die Auswahl läuft VOLLSTÄNDIG im Speicher (addr_meta), nicht per SQL.
        Grund: last_poll wird nur noch stündlich gesammelt geschrieben (Schreiblast).
        Eine SQL-Sortierung nach last_poll hielte frisch abgefragte Adressen für
        maximal überfällig, füllte die Kandidatenliste mit ihnen -- und der Stapel
        bliebe nach dem Filtern leer. Genau das hat das API-Budget einbrechen lassen.
        Nebenbei entfallen drei Abfragen über eine 130.000-Zeilen-Tabelle alle 5 s.
        """
        now = int(time.time())
        c = self.cfg
        f = self.interval_factor
        n_a, n_b = int(limit * 0.65), int(limit * 0.25)
        n_c = limit - n_a - n_b
        w_ref = c.whale_refresh * f; h_ref = c.hot_refresh * f; c_ref = c.cold_refresh * f; x_ref = c.cold_refresh * 4 * f
        klein_c = getattr(c, "klein_nach_handel", True)
        vorrang_ab = getattr(c, "vorrang_usd", 0.0) or 0.0
        umsatz = getattr(self, "addr_umsatz", {})
        fehler = getattr(self, "poll_fehler", None) or None
        vorrang = set()
        A, B, C, V = [], [], [], []
        n_st = {"Wale": 0, "Elite": 0, "Pool": 0, "groß": 0, "mittel": 0, "klein": 0, "gesperrt": 0}
        self.lade_elite(); elite = getattr(self, "elite_addrs", set())
        for addr, mrec in self.addr_meta.items():
            last_poll, pos_value, last_trade, first_seen = mrec
            if addr in self.gesperrt:                                     # 23.86 (U220): Masterregel -- nicht mehr abfragen
                n_st["gesperrt"] += 1
                continue
            if fehler is not None and addr in fehler and fehler[addr][1] > now:
                continue                                                  # 23.86: Pause nach fehlgeschlagener Abfrage
            if not last_poll:
                B.append((first_seen, addr)); continue
            if addr in elite:                                             # Elite: Wal-Takt, auch ohne Position
                n_st["Elite"] += 1
                overdue = (now - last_poll) / max(w_ref, 1)
                if overdue > 1.0:
                    A.append((0, -overdue, addr))
                continue
            if addr in self.pool_addrs and pos_value < c.whale_notional:    # Pool: alle 10 min, auch ohne Position
                n_st["Pool"] += 1
                overdue = (now - last_poll) / max(POOL_POLL_S * f, 1)
                if overdue > 1.0:
                    A.append((1, -overdue, addr))
                continue
            if pos_value >= c.min_notional or (pos_value > 0 and not klein_c):
                n_st["Wale" if pos_value >= c.whale_notional else "groß" if pos_value >= c.hot_notional
                     else "mittel" if pos_value >= c.min_notional else "klein"] += 1
                ref = w_ref if pos_value >= c.whale_notional else h_ref if pos_value >= c.hot_notional else c_ref if pos_value >= c.min_notional else x_ref
                overdue = (now - last_poll) / max(ref, 1)
                if overdue > 1.0:
                    A.append((0 if pos_value >= c.whale_notional else 1, -overdue, addr))
            else:                                                         # leer -- und seit 23.86 klein: nur nach eigenem Handel
                if pos_value > 0:
                    n_st["klein"] += 1
                if last_trade / 1000 > last_poll and vorrang_ab > 0 and umsatz.get(addr, 0.0) >= vorrang_ab:
                    V.append((-umsatz.get(addr, 0.0), addr))              # 23.86: großer Handel -> Vorrang (der größte Umsatz zuerst)
                    C.append((-last_trade, addr))                         # ... und auch in C (Deckel, oder A bei Drosselung voll)
                elif last_trade / 1000 > last_poll or now - last_poll > KLEIN_TAGESPRUEFUNG_S:
                    C.append((-last_trade, addr))
        V.sort()
        for u_, addr in V[:max(1, int(limit * VORRANG_ANTEIL))]:     # gedeckelt: höchstens ein Zehntel der Runde
            A.append((1, -VORRANG_UEBERFAELLIG + u_, addr)); vorrang.add(addr)   # u_ = −Umsatz: der größte zuerst
        A.sort(); B.sort(); C.sort()
        # Vorgezogene bleiben auch in C (zweite Durchsicht: bei Drosselung füllen Wale und Elite die Plätze von A -- dann kommt die
        # Adresse über C dran statt gar nicht); doppelt wird keine gewählt
        out = [x[-1] for x in A[:n_a]] + [x[-1] for x in B[:n_b]]
        have = set(out)
        n_c_ = 0
        for x in C:
            if n_c_ >= n_c:
                break
            if x[-1] not in have:
                out.append(x[-1]); have.add(x[-1]); n_c_ += 1
        # Nicht ausgeschöpfte Anteile auffüllen, damit das Budget nicht brachliegt
        if len(out) < limit:
            for pool in (A, C, B):
                for x in pool:
                    if x[-1] not in have:
                        out.append(x[-1]); have.add(x[-1])
                        if len(out) >= limit:
                            break
                if len(out) >= limit:
                    break
        self.stats["due_pools"] = (len(A), len(B), len(C))
        self.stats["poller_stufen"] = n_st
        self._vorrang = vorrang
        return out[:limit]


    LEADERBOARD_URL = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard"

    def sperre_laden(self) -> None:
        """Gesperrte Konten aus konto_status und der manuellen Liste (labels.json: "sperre": true/false)."""
        try:
            self.gesperrt = {r[0].lower() for r in self.con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}
        except sqlite3.OperationalError:
            self.gesperrt = set()
        man = self.sperre_manuell()
        for a, v in man.items():
            if v:
                self.gesperrt.add(a)
            else:
                self.gesperrt.discard(a)
        self.stats["gesperrt"] = len(self.gesperrt)

    def sperre_manuell(self) -> dict:
        """labels.json: {"addr": {"sperre": true}} sperrt, {"sperre": false} schützt vor der Automatik."""
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels.json"), encoding="utf-8") as f:
                lab = json.load(f)
            return {a.lower(): bool(v.get("sperre")) for a, v in lab.items() if isinstance(v, dict) and "sperre" in v}
        except (OSError, ValueError):
            return {}

    def sperre_pruefen(self) -> int:
        """
        Masterregel (Entscheidung Nutzer 22.09.; Basis seit 23.13, U31): Konten mit mehr als SPERRE_TRADES_TAG
        GEBÜNDELTEN Trades (je Coin, Minute und Richtung) in den letzten 24 h dauerhaft sperren. Zwei Quellen, es gilt
        das Maximum: Stream-Zähler (alle Fills der verfolgten Coins, fill_zaehler_h.n_trades) und gespeicherte Fills
        (lb_fills, alle Coins der Leaderboard-Konten, ab 2.500 USD). Geschützte Konten (labels.json "sperre": false)
        nie automatisch. Einmalig danach: Neubewertung der Sperren der alten Fills-Regel (sperre_neubewertung).
        23.37: Die gespeicherten Fills zählen nur ab lb_fills_min_usd. Seit 23.34 liegen für Konten der Darwin-Liste auch
        kleinere Fills in lb_fills (fürs Labor) -- mitgezählt wurden genau diese Konten strenger gemessen als alle anderen,
        und die besten (Echtzeit-Plätze, jeder Fill kommt an) rutschten über 300 und aus der Liste. Einmalige Neubewertung
        der Sperren seit 29.09. mit der richtigen Zählung: sperre_neubewertung_kleinfills.
        """
        now = int(time.time()); neu = 0
        manuell = self.sperre_manuell()
        schutz = {a for a, v in manuell.items() if not v}
        # Zähler persistieren: Fills additiv (Zähler wird geleert); Trades als Größe der Menge je Stunde mit MAX -- die
        # Mengen der laufenden und der vorigen Stunde bleiben im Speicher, eine Minute an der Grenze zweier Läufe zählt
        # so nicht doppelt; nach einem Neustart zählt die Stunde eher zu wenig als zu viel.
        try:
            st_jetzt = now // 3600 * 3600
            schluessel = set(self.fill_zaehler) | set(self.trade_buendel)
            if schluessel:
                self.con.executemany("INSERT INTO fill_zaehler_h (addr, stunde, n, n_trades) VALUES (?,?,?,?) "
                                     "ON CONFLICT(addr, stunde) DO UPDATE SET n = n + excluded.n, "
                                     "n_trades = MAX(COALESCE(n_trades, 0), excluded.n_trades)",
                                     [(a, st_, self.fill_zaehler.get((a, st_), 0), len(self.trade_buendel.get((a, st_), ())))
                                      for (a, st_) in schluessel])
                self.fill_zaehler = {}
                self.trade_buendel = {k: v for k, v in self.trade_buendel.items() if k[1] >= st_jetzt - 3600}
            self.con.execute("DELETE FROM fill_zaehler_h WHERE stunde < ?", (now - 8 * 86_400,))    # 23.29: 8 Tage (Zwei-Tage-Regel, U15)
            self.con.commit()
        except sqlite3.Error as e:
            print(f"  fill_zaehler_h: {e}", flush=True)
        kandidaten: dict = {}                                            # Konto -> (gebündelte Trades, Fills)
        try:
            for a, t_, n_ in self.con.execute("SELECT addr, SUM(COALESCE(n_trades, 0)), SUM(n) FROM fill_zaehler_h WHERE stunde >= ? "
                                              "GROUP BY addr HAVING SUM(COALESCE(n_trades, 0)) > ?", (now - 86_400, SPERRE_TRADES_TAG)):
                kandidaten[a.lower()] = (int(t_), int(n_ or 0))
        except sqlite3.OperationalError:
            pass
        try:
            for a, t_, n_ in self.con.execute(
                    "SELECT lower(addr), COUNT(DISTINCT coin || ':' || market || ':' || ((ts / 60) * 2 + COALESCE(buy, 0))), COUNT(*) "
                    "FROM lb_fills WHERE ts >= ? AND notional >= ? GROUP BY 1 "            # 23.37: kleine Darwin-Fills zählen nicht
                    "HAVING COUNT(DISTINCT coin || ':' || market || ':' || ((ts / 60) * 2 + COALESCE(buy, 0))) > ?",
                    (now - 86_400, self.cfg.lb_fills_min_usd * 0.999, SPERRE_TRADES_TAG)):
                alt = kandidaten.get(a, (0, 0))
                kandidaten[a] = (max(int(t_), alt[0]), max(int(n_), alt[1]))
        except sqlite3.OperationalError:
            pass
        neue_liste: list = []                                            # nur DAUERHAFT neu Gesperrte (ihre Rohfills werden gelöscht)
        try:
            self.sperre_neubewertung_kleinfills(now, manuell)
            self.sperre_kleinfill_korrektur(now, manuell)                # 23.38: falsche Freigaben (ohne kleine Bündel) zurücknehmen
        except sqlite3.Error as e:
            print(f"  Sperren neu bewerten (Kleinfills): {type(e).__name__}: {e}", flush=True)
            try:
                self.con.rollback()
            except sqlite3.Error:
                pass
        try:
            stand = {a.lower(): (s_, seit_) for a, s_, seit_ in self.con.execute("SELECT addr, status, seit FROM konto_status")}
        except sqlite3.OperationalError:
            stand = {}
        for a, (t_, n_) in kandidaten.items():
            if a in schutz:
                continue
            s_, seit_ = stand.get(a, (None, None))
            if s_ == "gesperrt":
                continue
            if s_ == "vorlaeufig":
                if now - int(seit_ or now) >= 86_400:                   # zweiter Tag über der Grenze binnen 7 Tagen -> dauerhaft
                    self.con.execute("UPDATE konto_status SET status='gesperrt', grund=?, seit=?, quelle='auto', fills_tag=?, trades_tag=? WHERE addr=?",
                                     (f"zweiter Tag über {SPERRE_TRADES_TAG} binnen {SPERRE_VORLAEUFIG_TAGE} Tagen: {t_} gebündelte Trades in 24 h ({n_} Fills)",
                                      now, float(n_), float(t_), a))
                    self.gesperrt.add(a); neu += 1; neue_liste.append(a)
                    print(f"  SPERRE: {a[:6]}…{a[-4:]} dauerhaft gesperrt -- zweiter Tag über {SPERRE_TRADES_TAG} ({t_} gebündelte Trades/24 h)", flush=True)
                continue
            self.con.execute("INSERT OR REPLACE INTO konto_status (addr, status, grund, seit, quelle, fills_tag, trades_tag) VALUES (?,?,?,?,?,?,?)",
                             (a, "vorlaeufig", f"Tag 1: {t_} gebündelte Trades in 24 h (Masterregel > {SPERRE_TRADES_TAG}; {n_} Fills) -- dauerhaft erst bei "
                                               f"einem zweiten Tag binnen {SPERRE_VORLAEUFIG_TAGE} Tagen", now, "auto", float(n_), float(t_)))
            self.gesperrt.add(a)
            print(f"  SPERRE: {a[:6]}…{a[-4:]} vorläufig ausgeschlossen -- {t_} gebündelte Trades/24 h (Tag 1)", flush=True)
        for a, (s_, seit_) in stand.items():                                # vorläufige ohne zweiten Tag: nach 7 Tagen frei
            if s_ == "vorlaeufig" and a not in kandidaten and now - int(seit_ or now) >= SPERRE_VORLAEUFIG_TAGE * 86_400:
                self.con.execute("UPDATE konto_status SET status='frei', seit=?, quelle='vorlaeufig_abgelaufen', grund=? WHERE addr=?",
                                 (now, f"{SPERRE_VORLAEUFIG_TAGE} Tage ohne zweiten Tag über {SPERRE_TRADES_TAG} -- freigegeben", a))
                self.gesperrt.discard(a)
                print(f"  SPERRE: {a[:6]}…{a[-4:]} freigegeben -- kein zweiter Tag über {SPERRE_TRADES_TAG}", flush=True)
        self.con.commit()
        if neue_liste:                                                   # M1: Rohfills genau der NEU Gesperrten löschen
            self.con.commit()
            try:
                marks = ",".join("?" * len(neue_liste))
                self.con.execute(f"DELETE FROM lb_fills WHERE lower(addr) IN ({marks})", neue_liste)
                self.con.commit()
            except sqlite3.Error:
                pass
        try:                                                             # 23.29: Einzeltag-Sperren einmalig in die Zwei-Tage-Regel überführen
            if not self.con.execute("SELECT v FROM meta WHERE k='sperre_zwei_tage'").fetchone():
                n_um = self.con.execute("UPDATE konto_status SET status='vorlaeufig', seit=?, grund='Neubewertung Zwei-Tage-Regel (23.29): ' || COALESCE(grund, '') "
                                        "WHERE status='gesperrt' AND quelle='auto' AND trades_tag IS NOT NULL", (now - 86_400,)).rowcount
                self.con.execute("INSERT OR REPLACE INTO meta VALUES ('sperre_zwei_tage', ?)", (str(now),)); self.con.commit()
                print(f"  SPERRE: Zwei-Tage-Regel -- {n_um} automatische Sperren auf vorläufig gesetzt; wer weiter über {SPERRE_TRADES_TAG} liegt, "
                      f"ist beim nächsten Durchgang wieder dauerhaft gesperrt, die übrigen werden nach 6 Tagen frei", flush=True)
        except sqlite3.Error as e:
            print(f"  Zwei-Tage-Regel: {type(e).__name__}: {e}", flush=True)
        try:
            self.sperre_neubewertung(now, manuell)
        except sqlite3.Error as e:
            print(f"  Sperre neu bewerten: {type(e).__name__}: {e}", flush=True)
            try:
                self.con.rollback()
            except sqlite3.Error:
                pass
        self.stats["gesperrt"] = len(self.gesperrt)
        return neu

    def sperre_neubewertung_kleinfills(self, now: int, manuell: dict) -> dict:
        """
        23.37, einmalig: Automatische Sperren seit KLEINFILL_SEIT (vorläufig und dauerhaft) mit der richtigen Zählung prüfen --
        gespeicherte Fills nur ab lb_fills_min_usd, dazu der Stream-Zähler, jeweils in den 24 h vor der Sperre UND in den
        letzten 24 h. Freigegeben wird nur, wer wegen der kleinen Fills der Darwin-Liste (23.34–23.36) gesperrt wurde: Die
        gespeicherten Fills MIT den kleinen müssen die Sperre nachvollziehen (über SPERRE_TRADES_TAG), ohne sie und im Stream
        liegt alles höchstens bei SPERRE_TRADES_TAG. 23.38: Bis dahin genügte „ohne sie höchstens 300“ -- das gab am 30.09. ein
        Konto frei, bei dem kein einziges kleines Bündel mitgezählt war: Seine Fills vor der Sperre hatte vermutlich die
        Vielhandler-Regel (Rohfills älter als 1 Tag) schon gelöscht, die Nachzählung fiel unter die Grenze. Status "frei", Quelle
        "kleinfill_neubewertung", alter Grund im Protokoll; die Freigegebenen stehen in meta 'sperre_kleinfill_neubewertung' --
        das Dashboard prüft sie sofort mit der Aufnahme-Regel der Darwin-Liste. Manuelle Sperren bleiben.
        """
        if self.con.execute("SELECT 1 FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone():
            return {}
        min_usd = self.cfg.lb_fills_min_usd * 0.999
        min_txt = f"{self.cfg.lb_fills_min_usd:,.0f}".replace(",", ".")
        buendel = "COUNT(DISTINCT coin || ':' || market || ':' || ((ts / 60) * 2 + COALESCE(buy, 0)))"

        def zaehlung(a: str, bis: int) -> tuple:
            """(Stream, gespeichert ab min_usd, gespeichert alle, Bündel mit kleinen Fills) in [bis - 24 h, bis]."""
            t_s = self.con.execute("SELECT COALESCE(SUM(COALESCE(n_trades, 0)), 0) FROM fill_zaehler_h WHERE lower(addr)=? AND stunde >= ? AND stunde <= ?",
                                   (a, bis - 86_400, bis)).fetchone()[0]
            t_l = self.con.execute(f"SELECT {buendel} FROM lb_fills WHERE lower(addr)=? AND ts >= ? AND ts <= ? AND notional >= ?",
                                   (a, bis - 86_400, bis, min_usd)).fetchone()[0]
            t_a = self.con.execute(f"SELECT {buendel} FROM lb_fills WHERE lower(addr)=? AND ts >= ? AND ts <= ?", (a, bis - 86_400, bis)).fetchone()[0]
            k_ = self.con.execute(f"SELECT {buendel} FROM lb_fills WHERE lower(addr)=? AND ts >= ? AND ts <= ? AND notional < ?",
                                  (a, bis - 86_400, bis, min_usd)).fetchone()[0]
            return int(t_s or 0), int(t_l or 0), int(t_a or 0), int(k_ or 0)
        rows = self.con.execute("SELECT addr, status, grund, seit FROM konto_status WHERE status IN ('vorlaeufig','gesperrt') AND quelle='auto' AND seit >= ?",
                                (KLEINFILL_SEIT,)).fetchall()
        frei: list = []; bleibt: list = []
        for addr, status, grund, seit in rows:
            a = str(addr).lower()
            if manuell.get(a):
                continue
            s_d, l_d, a_d, k_d = zaehlung(a, int(seit or now))
            s_j, l_j, _, _ = zaehlung(a, now)
            dann, jetzt = max(s_d, l_d), max(s_j, l_j)
            if a_d > SPERRE_TRADES_TAG and dann <= SPERRE_TRADES_TAG and jetzt <= SPERRE_TRADES_TAG:
                self.con.execute("UPDATE konto_status SET status='frei', seit=?, quelle='kleinfill_neubewertung', trades_tag=?, grund=? WHERE addr=?",
                                 (now, float(dann), f"freigegeben 23.37: {dann} gebündelte Trades in den 24 h vor der Sperre ohne Fills unter "
                                                    f"{min_txt} USD, mit ihnen {a_d} ({k_d} Bündel mit kleinen Fills; Zählfehler 23.34–23.36), "
                                                    f"jetzt {jetzt} -- vorher {status}: {grund}", addr))
                self.gesperrt.discard(a)
                frei.append({"addr": a, "status": status, "seit": int(seit or 0), "dann": dann, "alle": a_d, "klein": k_d, "jetzt": jetzt})
                print(f"  SPERRE aufgehoben (Kleinfill-Zählfehler): {a[:6]}…{a[-4:]} -- {dann} gebündelte Trades vor der Sperre, "
                      f"mit den kleinen Fills {a_d}", flush=True)
            else:
                bleibt.append({"addr": a, "status": status, "dann": dann, "alle": a_d, "klein": k_d, "jetzt": jetzt})
        erg = {"ts": now, "seit": KLEINFILL_SEIT, "geprueft": len(rows), "frei": frei, "bleibt": bleibt, "korrektur_ts": now,
               "zurueckgenommen": []}                                  # 23.38: mit der strengen Bedingung ist nichts zurückzunehmen
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('sperre_kleinfill_neubewertung', ?)", (json.dumps(erg),))
        self.con.commit()
        print(f"  Masterregel (23.37/23.38): {len(rows)} Sperren seit 29.09. mit der richtigen Zählung geprüft -- {len(frei)} freigegeben, "
              f"{len(bleibt)} bleiben", flush=True)
        return erg

    def sperre_kleinfill_korrektur(self, now: int, manuell: dict) -> list:
        """
        23.38, einmalig: Freigaben der Neubewertung 23.37 zurücknehmen, bei denen KEIN kleines Bündel mitgezählt war („klein“ 0) --
        dann kann der Zählfehler die Sperre nicht verursacht haben (Bericht 30.09.: 0xb078…de15, 362 gebündelte Trades am Tag der
        Sperre; die Nachzählung ergab 299, vermutlich weil die Vielhandler-Regel seine Fills vor der Sperre schon gelöscht hatte). Der alte
        Stand kehrt zurück: Status, seit (die 7-Tage-Frist der vorläufigen Sperre läuft ab der ursprünglichen Sperre), Quelle
        "auto", Grund mit Vermerk. Nur Konten, die noch frei aus dieser Neubewertung sind; manuell geschützte bleiben frei.
        Ergebnis im selben meta-Eintrag: „zurueckgenommen“, „korrektur_ts“ (das Dashboard liest „frei“ -- ohne die Zurückgenommenen).
        """
        row = self.con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()
        if not row or not row[0]:
            return []
        try:
            erg = json.loads(row[0])
        except (TypeError, ValueError):
            return []
        if erg.get("korrektur_ts"):
            return []
        bleibt_frei, zurueck = [], []
        for e in erg.get("frei") or []:
            a = str(e.get("addr") or "").lower()
            if int(e.get("klein") or 0) > 0 or manuell.get(a) is False or not a:
                bleibt_frei.append(e); continue
            st_ = self.con.execute("SELECT status, quelle, grund, trades_tag FROM konto_status WHERE lower(addr)=?", (a,)).fetchone()
            vorher = str(e.get("status") or "vorlaeufig")
            if st_ and st_[0] == "frei" and st_[1] == "kleinfill_neubewertung":
                g = str(st_[2] or "")
                marke = f" -- vorher {vorher}: "
                alt = g.split(marke, 1)[1] if marke in g else g
                m = re.search(r"(\d+) gebündelte Trades in 24 h", alt)
                tt = float(m.group(1)) if m else st_[3]
                neu_g = (f"{alt} · Freigabe vom {time.strftime('%d.%m. %H:%M', time.localtime(int(erg.get('ts') or now)))} zurückgenommen (23.38): "
                         f"kein kleines Bündel mitgezählt, die Sperre war kein Zählfehler")
                self.con.execute("UPDATE konto_status SET status=?, seit=?, quelle='auto', trades_tag=?, grund=? WHERE lower(addr)=?",
                                 (vorher, int(e.get("seit") or now), tt, neu_g, a))
                self.gesperrt.add(a)
                zurueck.append(dict(e, zurueck_ts=now, wieder=vorher))
                print(f"  SPERRE wiederhergestellt (Freigabe 23.37 zurückgenommen): {a[:6]}…{a[-4:]} -- {vorher} seit "
                      f"{time.strftime('%d.%m. %H:%M', time.localtime(int(e.get('seit') or now)))}", flush=True)
            else:
                zurueck.append(dict(e, zurueck_ts=now, wieder=(st_[0] if st_ else "—") + " (schon vorher neu gesetzt)"))
        erg["frei"] = bleibt_frei; erg["zurueckgenommen"] = zurueck; erg["korrektur_ts"] = now
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('sperre_kleinfill_neubewertung', ?)", (json.dumps(erg),))
        self.con.commit()
        print(f"  Masterregel (23.38): Freigaben der Neubewertung 23.37 geprüft -- {len(zurueck)} zurückgenommen, {len(bleibt_frei)} bleiben frei", flush=True)
        return zurueck

    def sperre_neubewertung(self, now: int, manuell: dict) -> int:
        """
        Einmalig nach dem Basiswechsel (23.13, U31): automatische Sperren der alten Fills-Regel (trades_tag leer) nach
        der neuen Regel bewerten, sobald 24 volle Stunden Trade-Zählung vorliegen. Gesperrte Konten werden im Stream
        weiter gezählt, die Zahl liegt also vor. Höchstens SPERRE_TRADES_TAG gebündelte Trades -> freigegeben (Status
        "frei", neuer und alter Grund im Protokoll); darüber -> bleibt gesperrt, Beleg nachgetragen. Manuelle Sperren
        (labels.json "sperre": true) bleiben unberührt. Ergebnis in meta 'masterregel_neubewertung'.
        """
        if self.con.execute("SELECT 1 FROM meta WHERE k='masterregel_neubewertung'").fetchone():
            return 0
        t0 = self.con.execute("SELECT MIN(stunde) FROM fill_zaehler_h WHERE n_trades IS NOT NULL").fetchone()[0]
        if not t0 or now < t0 + 3600 + 86_400:                           # erste volle Stunde der Zählung + 24 h
            return 0
        alte = self.con.execute("SELECT addr, grund FROM konto_status WHERE status='gesperrt' AND quelle='auto' AND trades_tag IS NULL").fetchall()
        frei = bleibt = 0
        for a, grund in alte:
            if manuell.get(str(a).lower()):
                continue
            t_, n_ = self.con.execute("SELECT COALESCE(SUM(COALESCE(n_trades, 0)), 0), COALESCE(SUM(n), 0) FROM fill_zaehler_h "
                                      "WHERE addr=? AND stunde >= ?", (a, now - 86_400)).fetchone()
            if t_ <= SPERRE_TRADES_TAG:
                self.con.execute("UPDATE konto_status SET status='frei', seit=?, quelle='neubewertung', trades_tag=?, grund=? WHERE addr=?",
                                 (now, float(t_), f"freigegeben: {t_} gebündelte Trades in 24 h (neue Masterregel <= {SPERRE_TRADES_TAG}; "
                                                  f"{n_} Fills) -- vorher: {grund}", a))
                self.gesperrt.discard(str(a).lower()); frei += 1
                print(f"  SPERRE aufgehoben (Neubewertung): {a[:6]}…{a[-4:]} -- {t_} gebündelte Trades/24 h, {n_} Fills", flush=True)
            else:
                self.con.execute("UPDATE konto_status SET trades_tag=?, grund=? WHERE addr=?",
                                 (float(t_), f"{t_} gebündelte Trades in 24 h (neue Masterregel > {SPERRE_TRADES_TAG}; {n_} Fills) -- vorher: {grund}", a))
                bleibt += 1
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('masterregel_neubewertung', ?)",
                         (json.dumps({"ts": now, "geprueft": len(alte), "frei": frei, "bleibt": bleibt}),))
        self.con.commit()
        print(f"  Masterregel neu bewertet: {len(alte)} alte Sperren geprüft -- {frei} freigegeben, {bleibt} bleiben", flush=True)
        return frei

    def pool_aktualisieren(self, pool_rows: list) -> None:
        """
        Phase 1 "Aktive Profis": Pool-Tabelle aus der stündlichen Leaderboard-Datei fortschreiben.
        Aufnahme bei Kontowert >= POOL_MIN_VALUE und Tagesumsatz >= POOL_MIN_VLM; Verbleib
        POOL_HYSTERESE_TAGE nach dem letzten Erfüllen; Deckel POOL_DECKEL nach Wochengewinn.
        Neue Pool-Konten kommen in die Adressliste des Pollers (Stufe "Pool", alle 10 min).
        """
        now = int(time.time())
        self.con.executemany("""INSERT INTO pool_accounts (addr, seit, zuletzt_erfuellt, account_value, vlm_1d, vlm_7d, pnl_7d, roi_7d, name, aktualisiert,
                                                           pnl_1d, roi_1d, pnl_30d, roi_30d)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                                ON CONFLICT(addr) DO UPDATE SET zuletzt_erfuellt=excluded.zuletzt_erfuellt, account_value=excluded.account_value,
                                    vlm_1d=excluded.vlm_1d, vlm_7d=excluded.vlm_7d, pnl_7d=excluded.pnl_7d, roi_7d=excluded.roi_7d,
                                    name=excluded.name, aktualisiert=excluded.aktualisiert, pnl_1d=excluded.pnl_1d, roi_1d=excluded.roi_1d,
                                    pnl_30d=excluded.pnl_30d, roi_30d=excluded.roi_30d""",
                             [(a, now, now, av, v1, v7, p7, r7, nm, now, p1, r1, p30, r30) for a, av, v1, v7, p7, r7, nm, p1, r1, p30, r30 in pool_rows])
        # stündliche Historie (Hyperliquids Fenster als Zeitreihe -- später 12-h-Vergleiche, Einzahlungen erkennbar)
        stunde = now // 3600 * 3600
        self.con.executemany("INSERT OR IGNORE INTO pool_accounts_hist VALUES (?,?,?,?,?,?,?,?)",
                             [(a, stunde, av, p1, r1, p7, r7, v1) for a, av, v1, v7, p7, r7, nm, p1, r1, p30, r30 in pool_rows])
        self.con.execute("DELETE FROM pool_accounts WHERE zuletzt_erfuellt < ?", (now - POOL_HYSTERESE_TAGE * 86_400,))
        self.con.commit()
        self.pool_laden(now)

    def fill_konten_auffrischen(self, auswahl: set | None = None) -> None:
        """
        Konten, deren Stream-Fills (ab lb_fills_min_usd, 0 Gewicht) gespeichert und für die Masterregel gezählt werden: die
        Leaderboard-Auswahl (mit `auswahl` neu, sonst die bisherige Menge), die Wale im Wal-Takt, der Pool und -- 23.39 -- die Elite
        aller Coins (Vorlage für „Elite live folgen“ im Labor; bis dahin fehlten ihre Fills, wenn ein Elite-Konto weder Auswahl, Pool
        noch Wal war). Gesperrte nie.
        """
        basis = set(self.fill_konten) if auswahl is None else (set(auswahl) | self.wale_verfolgt())
        self.fill_konten = (basis | self.pool_addrs | set(getattr(self, "elite_addrs", set()))) - self.gesperrt

    def wale_verfolgt(self) -> set:
        """Adressen im Wal-Takt (Position >= whale_notional) -- ihre Fills werden gesammelt, damit die Masterregel sie messen kann."""
        try:
            return {a for a, m in self.addr_meta.items() if (m[1] or 0) >= self.cfg.whale_notional}
        except Exception:
            return set()

    def pool_laden(self, now: int | None = None) -> None:
        """Mitglieder = Zeilen innerhalb der Hysterese, höchstens POOL_DECKEL nach Wochengewinn."""
        now = now or int(time.time())
        try:
            rows = self.con.execute("SELECT addr FROM pool_accounts WHERE zuletzt_erfuellt >= ? ORDER BY pnl_7d DESC LIMIT ?",
                                    (now - POOL_HYSTERESE_TAGE * 86_400, POOL_DECKEL)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        neu = {r[0].lower() for r in rows}
        neu_adr = [a for a in neu - self.pool_addrs if a not in self.addr_meta]    # ins Adressverzeichnis, falls unbekannt -> Poller findet es
        if neu_adr:
            # 23.12 (U32): in EINER Anweisung und sofort committen. Vorher blieb die Transaktion -- und damit die
            # Schreibsperre ALLER Dienste (hl_dbcoord) -- bis zum nächsten Commit offen. Beim Start lagen dazwischen
            # Symbolauflösung, Adressliste und der erste Leaderboard-Zyklus: 48,9 s gehalten (Netzwerkstatus 23.09.,
            # Binance 1 Frist überschritten). Beim Start ist addr_meta noch leer: dann sind es alle Pool-Konten
            # (INSERT OR IGNORE, wenige Millisekunden).
            # 23.66 (U149): first_seen in MILLISEKUNDEN wie last_trade -- bis 23.65 stand hier `now` (Sekunden); das Audit
            # meldete „Zeit-Einheiten“ (11.10.: kleinster Wert 1.790.032.189 = 21.09. 23:09 UTC, Start des Pools).
            self.con.executemany("INSERT OR IGNORE INTO addresses (addr, first_seen, last_trade) VALUES (?,?,?)",
                                 [(a, now * 1000, now * 1000) for a in neu_adr])
            self.con.commit()
            for a in neu_adr:
                self.addr_meta[a] = [0, 0.0, now * 1000, now * 1000]
        if neu != self.pool_addrs:
            print(f"  Pool 'Aktive Profis': {len(neu)} Konten ({len(neu - self.pool_addrs)} neu, {len(self.pool_addrs - neu)} ausgeschieden)", flush=True)
        self.pool_addrs = neu
        self.stats["pool_konten"] = len(neu)
        self.fill_konten_auffrischen()                               # Stream-Fills auch für den Pool (0 Gewicht), ohne Gesperrte

    async def fetch_leaderboard(self) -> list[dict]:
        """Top-Konten nach 30-Tage-PnL: (rank, addr, name, account_value, pnl_30d, roi_30d, pnl_7d)."""
        # Stündlich reicht: die Rangliste ändert sich langsam, der Download ist ~40 MB.
        cached = getattr(self, "_lb_cand", None)
        if cached and time.time() - cached[0] < self.cfg.lb_rank_interval:
            return cached[1]
        try:
            import aiohttp
            tmo = aiohttp.ClientTimeout(total=120)
        except ImportError:                       # Testumgebung ohne aiohttp
            tmo = None
        async with self.session.get(self.LEADERBOARD_URL, timeout=tmo) as r:
            raw = await r.read()

        # Verfolgte Konten, deren Kennzahlen gesichert werden: bekannte Wale plus die Kandidaten.
        try:
            verfolgt = {r[0].lower() for r in self.con.execute("SELECT addr FROM addresses WHERE pos_value >= 20e6")}
        except sqlite3.Error:
            verfolgt = set()

        def parse(raw_bytes: bytes):
            # im Thread: mehrere Sekunden JSON-Parsen dürfen die Feeds nicht anhalten
            data = json.loads(raw_bytes); del raw_bytes
            rows = data.get("leaderboardRows") if isinstance(data, dict) else data
            cand, names, stats = [], [], {}
            pool_rows = []                                          # Phase 1: Kandidatenpool "Aktive Profis"
            def num(d, k):
                try:
                    return float((d or {}).get(k) or 0)
                except (TypeError, ValueError):
                    return 0.0
            for row in rows or []:
                wp = {w: v for w, v in (row.get("windowPerformances") or [])}
                try:
                    pnl_m = float((wp.get("month") or {}).get("pnl") or 0); av = float(row.get("accountValue") or 0)
                    roi_m = float((wp.get("month") or {}).get("roi") or 0); pnl_w = float((wp.get("week") or {}).get("pnl") or 0)
                except (TypeError, ValueError):
                    continue
                addr = str(row.get("ethAddress", "")).lower(); name = row.get("displayName")
                if name:
                    names.append((addr, str(name), av))
                ist_kand = av >= self.cfg.lb_min_value and pnl_m > 0
                if ist_kand:
                    cand.append({"addr": addr, "name": name, "account_value": av, "pnl_30d": pnl_m, "roi_30d": roi_m, "pnl_7d": pnl_w})
                d_ = wp.get("day"); w_ = wp.get("week")
                if av >= POOL_MIN_VALUE and num(d_, "vlm") >= POOL_MIN_VLM:
                    m_ = wp.get("month")
                    pool_rows.append((addr, av, num(d_, "vlm"), num(w_, "vlm"), num(w_, "pnl"), num(w_, "roi"), str(name or ""),
                                      num(d_, "pnl"), num(d_, "roi"), num(m_, "pnl"), num(m_, "roi")))
                if ist_kand or addr in verfolgt:
                    d, w, m, a = wp.get("day"), wp.get("week"), wp.get("month"), wp.get("allTime")
                    stats[addr] = (av, num(d, "pnl"), num(d, "roi"), num(d, "vlm"), num(w, "pnl"), num(w, "roi"), num(w, "vlm"),
                                   num(m, "pnl"), num(m, "roi"), num(m, "vlm"), num(a, "pnl"), num(a, "roi"), num(a, "vlm"))
            cand.sort(key=lambda c: -c["pnl_30d"])
            for i, c in enumerate(cand, 1):
                c["lb_rank"] = i
            kand_set = {c["addr"] for c in cand[:self.cfg.lb_candidates]}
            stats = {a: v for a, v in stats.items() if a in kand_set or a in verfolgt}
            return cand[:self.cfg.lb_candidates], names, stats, pool_rows
        cand, names, stats, pool_rows = await asyncio.to_thread(parse, raw)
        try:
            self.pool_aktualisieren(pool_rows)
        except sqlite3.Error as e:
            print(f"  Pool: {e}", flush=True)
        del raw
        now = int(time.time())
        if names:
            self.con.executemany("INSERT OR REPLACE INTO lb_names VALUES (?,?,?,?)", [(a, n, v, now) for a, n, v in names])
            self.con.commit()
        if stats:
            self.con.executemany("INSERT OR IGNORE INTO lb_stats_hist VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                 [(a, now, *v) for a, v in stats.items()])    # Audit v3 S1: Zeitreihe behalten
            self.con.executemany("INSERT OR REPLACE INTO lb_stats VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                 [(a, now, *v) for a, v in stats.items()])
            self.con.commit()
            self.stats["lb_stats_rows"] = len(stats)
        self._lb_cand = (time.time(), cand)
        return cand

    async def leaderboard_cycle(self, force_trend: bool = False) -> bool:
        """
        Ein Durchgang: Leaderboard laden, Positionen der Top-Konten abfragen, lb_accounts und
        lb_positions schreiben; die Trendzeile je Coin (Top 20 / Top 50), wenn eine neue Stunde
        begonnen hat -- oder erzwungen (Start). Liefert True, wenn geschrieben wurde.
        """
        ph = {"t0": time.time(), "warten0": self.limiter.wait_by.get(0, (0.0, 0))[0]}   # Phasen-Uhr (17.09.: 315-s-Zyklen ohne Erklärung)
        try:
            top = await self.fetch_leaderboard()
        except Exception as e:
            print(f"  Leaderboard nicht ladbar: {e}")
            return False
        ph["leaderboard"] = time.time() - ph["t0"]
        now = int(time.time()); acc_rows, pos_rows = [], []
        per_coin: dict = {}; failed = 0; checked = 0; checked_addrs: set = set()
        known_flat = {a for a, t in self.lb_flat_seen.items() if now - t < 86_400}     # in den letzten 24 h als flach gesehen
        # Auswahl: die profitabelsten Konten, die auf dem Perp-Konto tatsächlich Positionen halten.
        # Das Leaderboard zählt Spot, Vault-Anteile und Unterkonten mit -- die Spitze nach PnL
        # besteht aus Vaults und Market Makern ohne Perp-Position. Flache Konten werden für
        # lb_flat_ttl gemerkt, damit die Auswahl nicht jede Runde das volle Gewicht kostet.
        rank = 0
        # Analyse v6, Empfehlung 1: Positionsabfragen parallel in Stücken à 6 (Connector-Grenze) statt
        # sequentiell mit festen 0,2-s-Schläfern -- der Begrenzer taktet bereits. Zyklus 60 s -> ~15 s.
        # Die Rangvergabe bleibt in Leaderboard-Reihenfolge (nach dem gather, deterministisch).
        kandidaten = [c for c in top if self.lb_flat_until.get(c["addr"], 0) <= now and c["addr"].lower() not in self.gesperrt]   # die ganze Liste, lazy in Stücken; Gesperrte nicht (Masterregel)

        async def hole(c):
            data = await self.post({"type": "clearinghouseState", "user": c["addr"]}, quelle="Leaderboard")
            if data is None:                                    # keine Antwort: einmal wiederholen
                await asyncio.sleep(1.0)
                data = await self.post({"type": "clearinghouseState", "user": c["addr"]}, quelle="Leaderboard")
            return c, data

        # Stückweise weiter, bis lb_top Konten MIT Position gefunden sind (wie die alte Schleife, die bis
        # zum Ziel durch die Liste lief -- die Spitze nach PnL besteht oft aus Vaults ohne Perp-Position)
        ergebnisse = []; mit_position = 0
        for i in range(0, len(kandidaten), 6):
            if self.stop.is_set() or mit_position >= self.cfg.lb_top:
                break
            stueck = await asyncio.gather(*(hole(c) for c in kandidaten[i:i + 6]))
            ergebnisse.extend(stueck)
            mit_position += sum(1 for _, d in stueck if isinstance(d, dict) and d.get("assetPositions"))

        for c, data in ergebnisse:
            if rank >= self.cfg.lb_top:
                break
            checked += 1
            if not isinstance(data, dict) or "assetPositions" not in data:
                failed += 1                             # Fehlschlag ist KEINE leere Position
                continue
            positions = []
            for ap in data.get("assetPositions", []):
                p = ap.get("position", {})
                try:
                    size = float(p.get("szi") or 0)
                    if size == 0:
                        continue
                    raw = str(p.get("coin", "")); coin = self.coin_of.get(raw) or raw.split(":")[-1]
                    lev = p.get("leverage") or {}
                    positions.append((coin, "long" if size > 0 else "short", size, abs(float(p.get("positionValue") or 0)),
                                      float(p.get("entryPx") or 0), float(p.get("liquidationPx") or 0), float(lev.get("value") or 0),
                                      float(p.get("unrealizedPnl") or 0)))
                except (TypeError, ValueError, AttributeError):
                    continue
            checked_addrs.add(c["addr"])
            if not positions:
                self.lb_flat_until[c["addr"]] = now + self.cfg.lb_flat_ttl; self.lb_flat_seen[c["addr"]] = now
                continue
            rank += 1; c["rank"] = rank
            try:
                perp_value = float((data.get("marginSummary") or {}).get("accountValue") or 0)
            except (TypeError, ValueError):
                perp_value = 0.0
            acc_rows.append((now, rank, c["addr"], c["name"], perp_value or c["account_value"], c["pnl_30d"], c["roi_30d"], c["pnl_7d"], len(positions)))
            for coin, side, size, val, entry, liq, lev, upnl in positions:
                mark = self.ref_px_or_db(coin)
                pos_rows.append((now, c["rank"], c["addr"], coin, side, size, val, entry, liq, lev, upnl, mark))
                for top_n in (20, 50):
                    if c["rank"] <= top_n:
                        d = per_coin.setdefault((coin, top_n), {"n_long": 0, "n_short": 0, "usd_long": 0.0, "usd_short": 0.0, "accts": set(), "mark": mark})
                        d["accts"].add(c["addr"])
                        if side == "long":
                            d["n_long"] += 1; d["usd_long"] += val
                        else:
                            d["n_short"] += 1; d["usd_short"] += val
        self.stats["lb_failed"] = failed; self.stats["lb_checked"] = checked
        if failed:
            print(f"  Leaderboard: {failed} von {checked} Positionsabfragen ohne Antwort")
        ph["positionen"] = time.time() - ph["t0"] - ph["leaderboard"]; ph["n"] = checked; ph["t_w"] = time.time()
        if not acc_rows or failed > max(1, checked // 2):   # überwiegend gescheitert: Stand nicht überschreiben
            return False
        # Ereignisse: Vergleich mit dem vorherigen Stand je Konto und Coin (open / add / reduce / close / flip)
        prev_ts = self.con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
        ev_rows = []
        if prev_ts:
            prev_pos = {(r[0], r[1]): (r[2], r[3], abs(r[4] or 0.0)) for r in self.con.execute(
                "SELECT addr, coin, side, pos_value, size FROM lb_positions WHERE ts=?", (prev_ts,))}
            # Verglichen wird gegen den zuletzt PROTOKOLLIERTEN Stand, nicht gegen den letzten
            # Schnappschuss: Sonst gingen Serien kleiner Anpassungen verloren -- fünf Zukäufe von
            # je 20.000 im Abstand von 5 Minuten blieben je unter der Schwelle und verschwänden,
            # obwohl sie zusammen 100.000 ergeben. Bei den Walen ist es seit jeher so.
            prev_accts = {r[0] for r in self.con.execute("SELECT addr FROM lb_accounts WHERE ts=?", (prev_ts,))} | known_flat
            seen = set()
            for (ts_, rank_, addr, coin, side, size, val, entry, liq, lev, upnl, mark) in pos_rows:
                seen.add((addr, coin)); was = prev_pos.get((addr, coin))
                if addr not in prev_accts:
                    continue                                    # Konto neu in der Auswahl: kein Ereignis, nur Stand
                # Gemessen wird die GRÖSSE, nicht der USD-Wert: Der Wert ändert sich auch bei
                # reiner Kursbewegung. delta_usd = gehandelte Menge x Kurs, Schwelle absolut --
                # wer eine große Kernposition hält und mit kleinen Anteilen um sie herum handelt,
                # fiel bei einer Prozentschwelle vollständig durch.
                sz = abs(size)
                key = (addr, coin)
                rec_sz = self.lb_last_rec.get(key)
                if rec_sz is None and was is not None:
                    rec_sz = was[2]; self.lb_last_rec[key] = rec_sz      # Anker beim ersten Sehen setzen
                if was is not None and rec_sz is not None and was[0] == side:
                    was = (was[0], was[1], rec_sz)              # gegen den letzten Protokollstand messen
                if was is None:
                    ev_rows.append((now, addr, coin, "open", side, val, val, mark))
                    self.lb_last_rec[key] = sz
                elif was[0] != side:
                    ev_rows.append((now, addr, coin, "flip", side, abs(was[1] or 0) + val, val, mark))   # M12: gehandelt wurde alt + neu (was = (side, pos_value, size))
                    self.lb_last_rec[key] = sz
                elif abs(sz - was[2]) * (mark or 0) >= self.cfg.lb_event_min_usd:
                    ev_rows.append((now, addr, coin, "add" if sz > was[2] else "reduce", side, (sz - was[2]) * (mark or 0), val, mark))
                    self.lb_last_rec[key] = sz
            for (addr, coin), (side, val, _sz) in prev_pos.items():
                if (addr, coin) not in seen and addr in checked_addrs:     # in diesem Durchgang geprüft und Position weg
                    ev_rows.append((now, addr, coin, "close", side, -val, 0.0, self.ref_px_or_db(coin)))
                    self.lb_last_rec.pop((addr, coin), None)
        self.con.executemany("INSERT OR REPLACE INTO lb_accounts VALUES (?,?,?,?,?,?,?,?,?)", acc_rows)
        self.fill_konten_auffrischen({r[2].lower() for r in acc_rows})     # Stream-Fills: Auswahl + Pool + Wale + Elite, ohne Gesperrte
        self.lb_pos_side = {(r[2].lower(), r[3]): r[4] for r in pos_rows if r[4] in ("long", "short")}
        self.lb_pos_konten = {r[2].lower() for r in acc_rows}
        self._lb_pos_ts = now
        self.stueckweise("INSERT OR REPLACE INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", pos_rows)
        if ev_rows:
            self.con.executemany("INSERT OR REPLACE INTO lb_events VALUES (?,?,?,?,?,?,?,?)", ev_rows)
            self.stats["lb_events"] = self.stats.get("lb_events", 0) + len(ev_rows)
        # Audit v3 S2: je volle Stunde die Positionen dauerhaft festhalten (bevor lb_positions nach
        # 7 Tagen aufgeräumt wird) -- Grundlage für Crowding-/Elite-Rückblicke über Wochen.
        stunde = now // 3600 * 3600
        if stunde != getattr(self, "_pos_hourly_ts", None) and pos_rows:
            self._pos_hourly_ts = stunde
            self.stueckweise("INSERT OR REPLACE INTO lb_pos_hourly VALUES (?,?,?,?,?,?,?,?,?)",
                             [(stunde, r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]) for r in pos_rows])
        self.loesche_stueckweise("lb_events", "ts < ?", (now - 30 * 86_400,))
        self.loesche_stueckweise("lb_positions", "ts < ?", (now - 7 * 86_400,))
        hour = now // 3600
        if force_trend or hour != self.lb_last_hour:
            ts_h = hour * 3600
            self.con.executemany("INSERT OR REPLACE INTO lb_trend VALUES (?,?,?,?,?,?,?,?,?,?)",
                [(ts_h, coin, top_n, d["n_long"], d["n_short"], d["usd_long"], d["usd_short"], d["usd_long"] - d["usd_short"], len(d["accts"]), d["mark"])
                 for (coin, top_n), d in per_coin.items()])
            self.lb_last_hour = hour
        self.con.commit()
        ph["schreiben"] = time.time() - ph["t_w"]
        ph["warten"] = self.limiter.wait_by.get(0, (0.0, 0))[0] - ph["warten0"]          # nur Rang 0 = dieser Zyklus
        self.stats["lb_phasen"] = (f"Leaderboard {ph['leaderboard']:.0f} s · {ph['n']} Konten abgefragt {ph['positionen']:.0f} s "
                                   f"(davon Warten am Begrenzer {ph['warten']:.0f} s) · Schreiben {ph['schreiben']:.1f} s")
        self.stats["lb_wait_s"] = round(ph["warten"], 1)
        self.stats["limiter_wait_by"] = {str(k): [round(v[0], 1), v[1]] for k, v in getattr(self.limiter, "wait_by", {}).items()}
        self.stats["limiter_wartend"] = self.limiter.wartend() if hasattr(self.limiter, "wartend") else None
        self.stats["lb_accounts"] = len(acc_rows); self.stats["lb_positions"] = len(pos_rows)
        return True

    SPOT_ALIAS = {"UBTC": "BTC", "UETH": "ETH", "USOL": "SOL", "UPUMP": "PUMP", "UFART": "FARTCOIN", "UXRP": "XRP", "UDOGE": "DOGE"}

    async def spot_pair_map(self) -> dict:
        """Spot-Paarname ("@107" oder "PURR/USDC") -> Basistoken; einmal geladen (Gewicht 20)."""
        if getattr(self, "_spot_map", None):
            return self._spot_map
        data = await self.post({"type": "spotMeta"}, weight=20)
        out = {}
        if isinstance(data, dict):
            tokens = {t.get("index"): t.get("name") for t in data.get("tokens", [])}
            for u in data.get("universe", []):
                base = tokens.get((u.get("tokens") or [None])[0])
                if base:
                    out[u.get("name")] = base
                    out[f"@{u.get('index')}"] = base
        self._spot_map = out
        return out

    def spot_coin(self, token: str) -> str:
        """Spot-Token auf den Dashboard-Coin abbilden (UBTC -> BTC)."""
        return self.SPOT_ALIAS.get(token, token)

    async def leaderboard_activity(self, nur_addrs: list | None = None, budget_fest: int | None = None, jobname: str = "Leaderboard-Fills") -> None:
        """
        Für die zuletzt ausgewählten Top-Konten: Fills der letzten lb_fills_days (Perp und Spot,
        Gewicht 20 je Konto) und Spot-Bestände (Gewicht 2). Fills werden über (addr, tid)
        dedupliziert, Bestände als Stundenstand gespeichert.
        U5 (23.09.): mit nur_addrs/budget_fest läuft derselbe Nachtrag für den Pool "Aktive Profis"
        (closedPnl/fee/dir je Fill), alle 12 h, Rang 3, gleiche Vielhandler- und Sperr-Regeln.
        """
        last = self.con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
        if not last:
            return
        # Reihenfolge nach Rückstand: Konten, die am weitesten zurückliegen, zuerst. Sonst
        # bekommen sie das Gewicht erst am Ende des Laufs -- und bei knappem Budget gar nicht.
        #
        # Der Lauf hat ein eigenes Gewichtsbudget. Grund: Eine volle Fill-Seite kostet 120
        # (20 plus 1 je 20 Einträge). Ein Nachholen über 28 Konten mit je sechs vollen Seiten
        # wären 20.000 Gewicht in wenigen Minuten -- das Budget der ganzen Anlage beträgt
        # 1.200 je Minute. Ohne Deckel bremst der Begrenzer alles andere aus: Poller, Orders,
        # Leaderboard. Mit Deckel bekommen die am weitesten zurückliegenden Konten das Budget,
        # der Rest kommt in der nächsten Stunde dran.
        addrs = [r[0] for r in self.con.execute(
            """SELECT a.addr FROM lb_accounts a LEFT JOIN lb_cursor c ON c.addr = a.addr
               WHERE a.ts=? ORDER BY COALESCE(c.ts, ?) ASC, a.rank ASC""",
            # Neue Leaderboard-Konten haben noch keinen Abholstand. Mit COALESCE(...,0)
            # sortierten sie vor JEDEN Nachzügler und nahmen ihm bei jedem Durchgang das
            # Budget weg -- bei 82 Konten kommen mit jeder Rangliste neue hinzu. Sie
            # starten ohnehin nur drei Tage rückwirkend; als 48 Stunden eingestuft
            # bekommen sie hohe, aber keine absolute Vorfahrt.
            (last, int(time.time()) - 2 * 86_400))]
        if nur_addrs is not None:                                        # U5: Pool-Lauf mit eigener Kontenliste (Rückstand zuerst)
            staende_ = dict(self.con.execute("SELECT addr, ts FROM lb_cursor"))
            addrs = sorted((a for a in nur_addrs), key=lambda a: staende_.get(a, 0))
        addrs = [a for a in addrs if a.lower() not in self.gesperrt]     # Masterregel: kein REST-Nachtrag für Gesperrte
        spot_map = await self.spot_pair_map()
        now = int(time.time()); n_fills = 0; n_spot = 0
        # Budget aus der tatsächlich freien Kapazität ableiten statt aus einer festen Zahl.
        #
        # Der feste Wert von 6.000 je Stunde stammte aus der Zeit vor der Gewichtskorrektur,
        # als eine Fill-Seite nominell 20 kostete. Tatsächlich kostet eine volle Seite 120
        # (20 plus 1 je 20 Einträge), ein Konto im Rückstand mit sechs Seiten also 720 --
        # mit 6.000 kamen pro Stunde nur acht Konten dran, während mehr als acht neu
        # zurückfielen. Der Rückstand musste wachsen.
        #
        # Jetzt gilt: Was vom Minutenbudget frei ist, darf der Lauf verbrauchen, abzüglich
        # einer Sicherheitsmarge. Ist die Anlage ausgelastet, bleibt es beim Mindestwert.
        kapazitaet = (self.limiter.rate + getattr(self.limiter, "reserve_rate", 0.0)) * 60   # Gewicht je Minute nach Temperaturskala
        # Die Reserve (Rang >= 2) steht den Fills immer zu -- darunter fällt das Laufbudget nie
        frei_pro_min = max(getattr(self.limiter, "reserve_rate", 0.0) * 60, kapazitaet - self.limiter.used_last_minute())
        # Obergrenze, damit ein Lauf nicht länger dauert als sein eigener Takt: Was in
        # der freien Reserve über die Laufzeit hinaus passt, nützt nichts -- der nächste
        # Lauf stünde schon an, während der erste noch arbeitet.
        # Analyse v6, Empfehlung 4: mit dem realen kommenden Takt rechnen (dyn_takt), nicht mit cfg
        takt_min = max(1, int(self.stats.get("fills_takt_s") or (self.cfg.lb_fills_interval // 2 if self.stats.get("lb_fills_backlog") else
                                                                  self.cfg.lb_fills_interval)) // 60)
        # In den gemessenen ruhigen Stunden 80 % der freien Kapazität statt 70 %:
        # Dann entstehen kaum neue Fills, und was der Poller in dieser Zeit verpasst,
        # ist am wenigsten wert.
        nacht = self.ist_ruhig()
        anteil = 0.8 if nacht else 0.7
        budget = max(self.cfg.lb_fills_weight,
                     min(30_000, int(frei_pro_min * takt_min * anteil)))
        if budget_fest is not None:
            budget = budget_fest
        staende = dict(self.con.execute("SELECT addr, ts FROM lb_cursor"))
        rueckstaendig = sum(1 for a in addrs if staende.get(a) and now - staende[a] > 3 * 3600)
        print(f"  Fills: Budget {budget:,} Gewicht (frei {frei_pro_min:.0f}/min, {anteil * 100:.0f} % genutzt"
              + (", ruhige Stunde" if nacht else "") + ") · "
              f"{rueckstaendig} von {len(addrs)} Konten über 3 h zurück", flush=True)
        self.stats["lb_fills_backlog"] = rueckstaendig
        budget_used = 0
        t_lauf = time.time(); n_fertig = 0
        self.note_job(jobname, takt=(12 * 3600 if nur_addrs is not None else self.cfg.lb_fills_interval * self.interval_factor), dauer=0.0,
                      info=f"läuft: 0/{len(addrs)} Konten")
        for addr in addrs:
            n_fertig += 1
            if n_fertig % 10 == 0:
                self.note_job(jobname, takt=(12 * 3600 if nur_addrs is not None else self.cfg.lb_fills_interval * self.interval_factor), dauer=time.time() - t_lauf,
                              info=f"läuft: {n_fertig}/{len(addrs)} Konten, {budget_used:,} Gewicht bisher")
            if self.stop.is_set():
                break
            if budget_used >= budget:
                self.stats["lb_fills_deferred"] = self.stats.get("lb_fills_deferred", 0) + 1
                continue                                    # nächste Stunde, Rückstand entscheidet
            cur_row = self.con.execute("SELECT ts FROM lb_cursor WHERE addr=?", (addr,)).fetchone()
            if cur_row and cur_row[0]:
                stand = cur_row[0]
            else:                                       # erster Lauf: vom neuesten gespeicherten Fill
                stand = self.con.execute("SELECT MAX(ts) FROM lb_fills WHERE addr=?", (addr,)).fetchone()[0] or 0
            start = max(stand - 600, now - self.cfg.lb_fills_days * 86_400)     # 10 min Überlappung
            # Seitenweise: eine Antwort fasst höchstens 2.000 Fills. Der Abholstand richtet sich
            # nach dem neuesten GEHOLTEN Fill, nicht nach dem neuesten gespeicherten -- sonst
            # bliebe ein Konto stehen, dessen Fills sämtlich unter der Speicherschwelle liegen.
            # Bei großem Rückstand mehr Seiten, damit das Aufholen nicht ewig dauert:
            # drei Seiten fassen 6.000 Fills je Stunde, ein aktives Konto macht mehr.
            seiten = self.cfg.lb_fills_pages * (2 if stand and now - stand > 6 * 3600 else 1)
            # `voll` bedeutet: Wir haben ALLE erlaubten Seiten verbraucht und sind noch
            # nicht am Ende. Vorher stand es nur dann auf wahr, wenn ausgerechnet die
            # LETZTE Seite exakt 2.000 Einträge hatte -- lieferte sie 1.999, galt das
            # Konto als aufgeholt, obwohl es 72 Stunden zurücklag und der Sprung
            # ausbleiben musste.
            fills = []; page_start = start * 1000; voll = False; antwort = False; geholt = 0; fehler = False
            for _ in range(seiten):
                data = await self.post({"type": "userFillsByTime", "user": addr, "startTime": page_start}, weight=20, quelle="Fills")
                if not isinstance(data, list):
                    fehler = True                           # Netzfehler (auch nach einer vollen Seite): kein Sprung auf "jetzt"
                    break                                   # keine Antwort: Abholstand NICHT verschieben
                antwort = True
                # userFillsByTime kostet laut Hyperliquid-Dokumentation 20 PLUS 1 je 20 gelieferter
                # Einträge. Eine volle Seite mit 2.000 Fills kostet also 120, nicht 20. Da die Zahl
                # erst mit der Antwort feststeht, wird der Aufschlag danach abgebucht -- das bremst
                # die folgenden Abfragen korrekt, statt das Budget still zu überziehen.
                extra = len(data) // 20
                budget_used += 20 + extra
                if extra:
                    await self.limiter.acquire(extra, prio=PRIO_BY_QUELLE["Fills"])
                    self.weight_by.setdefault("Fills", []).append((time.time(), extra))
                if not data:
                    break
                fills.extend(data)
                geholt += 1
                if len(data) < 2000:
                    break                      # am Ende angekommen: kein Rückstand mehr
                voll = geholt >= seiten        # alle Seiten verbraucht und immer noch Daten
                page_start = max(int(f.get("time", 0)) for f in data) + 1
            # Diagnose 17.09.: Welche Konten fressen den Lauf? Seiten je Konto festhalten -- Vielhandler
            # (volle Seiten zu 2.000 Fills, Gewicht 120 je Seite) sind die Ursache 670-s-langer Läufe.
            lauf_seiten = self.stats.setdefault("_fills_seiten", {})
            lauf_seiten[addr] = geholt
            # Abholstand -- was die Live-Probe vom 13.09. gezeigt hat: Der Stand wurde auf den
            # neuesten GEHOLTEN Fill gesetzt. Die Abholung beginnt zehn Minuten davor, bekommt
            # bei einem Konto, das seitdem nicht gehandelt hat, jedes Mal dieselben alten Fills
            # zurück -- die Antwort ist nicht leer, also rückte der Stand nie auf "jetzt". Ein
            # Konto, das aufhört zu handeln, sah für immer wie Rückstand aus (33 "rückständige"
            # Konten, deren Fills sämtlich 53 Stunden alt waren; lb_fills_deferred stand auf 0).
            # Daraufhin wurde der Adress-Poller zugunsten einer Abholung gedrosselt, die nichts
            # aufzuholen hatte.
            #
            # Richtig: Eine TEILSEITE (unter 2.000 Einträge) heißt, die API hat alles bis jetzt
            # geliefert -- der Stand ist "jetzt" (mit zehn Minuten Überlappung für Nachzügler),
            # unabhängig davon, ob Fills darin waren. Nur wenn alle erlaubten Seiten voll waren,
            # reicht der Stand bis zum neuesten geholten Fill. Kam gar keine Antwort, bleibt er
            # stehen, sonst überspränge ein Netzfehler ein Fenster.
            # Audit v3 D1: Bricht die Schleife durch einen Netzfehler NACH einer vollen Seite ab, ist
            # antwort=True und voll=False -- die Teilseitenregel hätte den Stand auf "jetzt" gesetzt und
            # die noch nicht geholten Fills übersprungen. Deshalb gilt sie nur bei sauberem Ende.
            if antwort and not voll and not fehler:
                neuester = now - 600
            elif fills:
                neuester = max(int(f.get("time", 0)) // 1000 for f in fills)
            else:
                neuester = stand
            if voll and neuester < now - 6 * 3600:
                # Das Konto handelt schneller, als wir nachkommen. Lieber eine Lücke als
                # dauerhaft 18 Stunden hinterherhinken: Signale leben von den letzten Stunden.
                # 23.14 (U39): Die Lücke beginnt beim jüngsten GEHOLTEN Fill -- vorher beim alten Stand, bei neuen Konten 0:
                # der VOLLBERICHT zeigte dann Lücken ab 01.01.1970 (497.264 h).
                geholt_bis = neuester
                luecke_h = (now - 2 * 3600 - geholt_bis) / 3600
                neuester = now - 2 * 3600
                self.stats["lb_fills_jump"] = self.stats.get("lb_fills_jump", 0) + 1
                self.con.execute("INSERT OR REPLACE INTO lb_gaps VALUES (?,?,?,?)",
                                 (addr, geholt_bis, neuester, now))
                print(f"  Fills {addr[:10]}…: zu viele Trades, springe über {luecke_h:.1f} h "
                      f"auf die letzten 2 h (Lücke wird in lb_gaps vermerkt)", flush=True)
            if antwort:
                self.con.execute("INSERT OR REPLACE INTO lb_cursor VALUES (?,?,?)", (addr, max(neuester, stand), now))
            rows = []
            for f in fills:
                try:
                    raw = str(f.get("coin", "")); px = float(f.get("px") or 0); sz = float(f.get("sz") or 0)
                    if raw.startswith("@") or "/" in raw:
                        market = "spot"; coin = self.spot_coin(spot_map.get(raw, raw))
                    else:
                        market = "perp"; coin = self.coin_of.get(raw) or raw.split(":")[-1]
                    if px * sz < self.cfg.lb_fills_min_usd and (addr.lower() not in self._darwin_set or market != "perp"      # 23.34: Darwin ohne Mindestbetrag
                                                                or not self.darwin_klein_frei("rest", addr.lower(), int(f.get("time", 0)) // 1000)):
                        continue
                    d = str(f.get("dir", "")).lower(); side = str(f.get("side", ""))
                    buy = 1 if ("open long" in d or "close short" in d or "buy" in d) else 0 if ("open short" in d or "close long" in d or "sell" in d) else (1 if side.upper().startswith("B") else 0)
                    rows.append((int(f.get("time", 0)) // 1000, addr, coin, market, str(f.get("dir", "")), side,
                                 px, sz, px * sz, float(f.get("closedPnl") or 0), float(f.get("fee") or 0), int(f.get("tid") or 0), buy))
                except (TypeError, ValueError):
                    continue
            if rows:
                # Abgleich: Die vorläufigen Stream-Zeilen dieses Kontos im geholten Zeitraum weichen den
                # vollständigen REST-Fills (closedPnl, fee, dir); die tid der beiden Quellen muss dafür
                # nicht übereinstimmen.
                r_min = min(r[0] for r in rows); r_max = max(r[0] for r in rows)
                self.con.execute("DELETE FROM lb_fills WHERE addr=? AND (dir='stream' OR dir LIKE '%*') AND ts>=? AND ts<=?", (addr, r_min, r_max))
                self.con.executemany("INSERT OR IGNORE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows); n_fills += len(rows)
            self.con.commit()                                   # vor dem nächsten Netzaufruf (Spot): Diagnose zeigte 5 s "lb_cursor"
            await asyncio.sleep(0.3)
            st = await self.post({"type": "spotClearinghouseState", "user": addr}, quelle="Fills")
            srows = []
            for b in (st or {}).get("balances", []) if isinstance(st, dict) else []:
                try:
                    tok = str(b.get("coin", "")); total = float(b.get("total") or 0)
                    if total <= 0 or tok == "USDC":
                        continue
                    coin = self.spot_coin(tok); px = self.ref_px_or_db(coin) if coin in self.cfg.coins else 0.0
                    srows.append((now, addr, tok, coin, total, float(b.get("hold") or 0), float(b.get("entryNtl") or 0), total * px))
                except (TypeError, ValueError):
                    continue
            if srows:
                self.con.executemany("INSERT OR REPLACE INTO lb_spot VALUES (?,?,?,?,?,?,?,?)", srows); n_spot += len(srows)
            self.con.commit()                                   # kurze Transaktion je Konto: Sperre nie über den nächsten Netzaufruf
            await asyncio.sleep(0.2)
        self.fill_nacharbeit(now)                                   # 23.75: Verdichten, Sperre, Löschen, Vielhandler -- mit Messung (Audit v10 M-3)
        # Stände ausgeschiedener Konten aufräumen: Wer seit sieben Tagen in keiner Rangliste mehr
        # steht, wird nicht mehr abgeholt -- sein Stand ist Altlast, kein Rückstand.
        self.con.execute("""DELETE FROM lb_cursor WHERE updated < ? AND addr NOT IN
                            (SELECT addr FROM lb_accounts WHERE ts = (SELECT MAX(ts) FROM lb_accounts))""", (now - 7 * 86_400,))
        self.loesche_stueckweise("lb_spot", "ts < ?", (now - 7 * 86_400,))
        self.con.commit()
        self.stats["lb_fills"] = n_fills; self.stats["lb_spot"] = n_spot
        # Rückstand NACH dem Lauf neu zählen: Der Wert vom Anfang beschreibt den Zustand vor dem
        # Abholen. Blieb er stehen, drosselte der Poller bis zum nächsten Lauf (bis zu 30 min)
        # zugunsten einer Abholung, die längst fertig war (13.09., nach der Cursor-Korrektur).
        jetzt = int(time.time())
        staende = dict(self.con.execute("SELECT addr, ts FROM lb_cursor"))
        self.stats["lb_fills_backlog"] = sum(1 for a in addrs if staende.get(a) and jetzt - staende[a] > 3 * 3600)

    def _scan_zeit(self, name: str, t0: float) -> None:
        """23.75 (Audit v10 vom 22.10., M-3): Dauer eines Schritts der Fill-Nacharbeit -- er läuft in der Ereignisschleife. Je Name
        zuletzt, Höchstwert seit dem Start und Zahl der Läufe in ms; der Vollbericht zeigt sie (meta „fill_scans“)."""
        ms = (time.monotonic() - t0) * 1000.0
        d = self.stats.setdefault("fill_scans", {}).setdefault(name, {"letzt": 0.0, "max": 0.0, "n": 0})
        d["letzt"] = round(ms, 1); d["max"] = round(max(d["max"], ms), 1); d["n"] += 1

    def fill_nacharbeit(self, now: int) -> None:
        """Nach dem Abholen der Fills: Stundenaggregat, Masterregel, Verdichten und Löschen, Vielhandler-Regel (bis 23.74 im
        Fill-Lauf selbst). 23.75 (Audit v10 M-3): jeder Schritt mit Messung -- erst messen, dann über einen Umbau entscheiden."""
        # Phase 1 "Aktive Profis": Stundenaggregat mit gebündelten Trades für die letzten 24 abgeschlossenen
        # Stunden (Rohfills sind innerhalb von 24 h für ALLE Konten vollständig), dann die Aufbewahrung:
        # Rohfills POOL_ROH_TAGE, außer Vielhandler (> POOL_ROH_MAX_FILLS_TAG Fills/Tag): nur 1 Tag.
        t0 = time.monotonic()
        try:
            self.pool_stunden_verdichten(now)
        except sqlite3.Error as e:
            print(f"  pool_fills_hourly: {type(e).__name__}: {e}", flush=True)
        self._scan_zeit("verdichten", t0); t0 = time.monotonic()
        try:
            self.sperre_pruefen()                                       # Masterregel: neue Maschinen sperren
        except sqlite3.Error as e:
            print(f"  Sperre prüfen: {type(e).__name__}: {e}", flush=True)
        self._scan_zeit("sperre", t0); t0 = time.monotonic()
        # Audit v3 S3 / v4 M4: Fills vor dem Löschen je Tag und Konto verdichten -- Aggregation und
        # Löschung je 6-h-Fenster in EINER Transaktion (kein Doppelzählen nach Absturz, keine Löschung
        # ohne Aggregat); bei Fehler Rollback und Abbruch, die Zeilen bleiben bis zum nächsten Lauf.
        cut = now - POOL_ROH_TAGE * 86_400
        self.fills_verdichten_und_loeschen(cut)
        self._scan_zeit("loeschen", t0); t0 = time.monotonic()
        try:
            schwer = [r[0] for r in self.con.execute("SELECT addr FROM lb_fills WHERE ts >= ? AND notional >= ? GROUP BY addr HAVING COUNT(*) > ?",
                                                     (now - 86_400, self.cfg.lb_fills_min_usd * 0.999, POOL_ROH_MAX_FILLS_TAG))]   # 23.37: ohne Kleinfills
            if schwer:
                marks = ",".join("?" * len(schwer))
                cur = self.con.execute(f"DELETE FROM lb_fills WHERE ts < ? AND addr IN ({marks})", (now - 86_400, *schwer))
                self.con.commit()
                self.stats["fills_vielhandler"] = len(schwer)
                if cur.rowcount:
                    print(f"  Rohfills: {cur.rowcount:,} Zeilen von {len(schwer)} Vielhandlern (> {POOL_ROH_MAX_FILLS_TAG}/Tag) älter als 1 Tag gelöscht", flush=True)
        except sqlite3.Error as e:
            print(f"  Vielhandler-Regel: {e}", flush=True)
        self._scan_zeit("vielhandler", t0)

    async def run_pool_fills(self) -> None:
        """U5: closedPnl/fee/dir per REST für alle Pool-Konten, alle 12 h, hinter allem anderen (Rang 3)."""
        await asyncio.sleep(600)
        # 23.14 (U40): nach einem Neustart erst 12 h nach dem LETZTEN Lauf. Vorher löste jedes Update 10 min später einen
        # vollen Lauf aus (bis 15.000 Gewicht, ~11 min, Rang 3) und verdrängte den Nachtrag der 75 Auswahl-Konten
        # (23.09.: sechs Updates; danach Nachtrag-Median 33 min, schlechtestes 1 h, statt höchstens 15 min).
        try:
            r_ = self.con.execute("SELECT v FROM meta WHERE k='pool_fills_letzter'").fetchone()
            rest_ = float(r_[0]) + 12 * 3600 * self.interval_factor - time.time() if r_ and r_[0] else 0.0
        except (sqlite3.Error, TypeError, ValueError):
            rest_ = 0.0
        if rest_ > 0:
            self.note_job("Pool-Fills", takt=12 * 3600, info=f"wartet: nächster Lauf in {rest_ / 3600:.1f} h (12 h nach dem Start des letzten, nicht nach dem Neustart)")
            j_ = self.jobs.get("Pool-Fills") or {}
            j_["last"] = int(float(r_[0])); j_["next"] = int(time.time() + rest_)    # 23.17: zuletzt = Start des letzten Laufs
            await asyncio.sleep(rest_)
        while not self.stop.is_set():
            t0 = time.time()
            try:
                # 23.17 (U40b): den Zeitpunkt beim START merken. Ein Pool-Lauf dauert bei vollem Budget rund 2 h (Rang 3,
                # 15.000 Gewicht); am 23.09. brach jedes Update den laufenden Lauf ab, bevor der Eintrag am Ende geschrieben
                # war -- jeder Neustart begann deshalb von vorn. Abgebrochene Läufe setzen im nächsten 12-h-Takt fort
                # (Reihenfolge nach Rückstand, der Abholstand je Konto bleibt erhalten).
                self.con.execute("INSERT OR REPLACE INTO meta VALUES ('pool_fills_letzter', ?)", (str(int(t0)),))
                self.con.commit()
            except sqlite3.Error:
                pass
            try:
                auswahl = {r[0].lower() for r in self.con.execute("SELECT addr FROM lb_accounts WHERE ts=(SELECT MAX(ts) FROM lb_accounts)")}
                addrs = sorted(self.pool_addrs - auswahl - self.gesperrt)
                if addrs:
                    await self.leaderboard_activity(nur_addrs=addrs, budget_fest=min(15_000, 30 * len(addrs)), jobname="Pool-Fills")
                self.note_job("Pool-Fills", takt=12 * 3600, dauer=time.time() - t0,
                              info=f"{len(addrs)} Pool-Konten (ohne Auswahl und Gesperrte) · closedPnl/fee/dir je Fill nachgetragen")
            except Exception as e:
                self.note_job("Pool-Fills", takt=12 * 3600, dauer=time.time() - t0, info=f"{type(e).__name__}: {e}", ok=False)
                print(f"  Pool-Fills: {type(e).__name__}: {e}", flush=True)
            await asyncio.sleep(12 * 3600 * self.interval_factor)

    async def run_leaderboard_activity(self) -> None:
        """Stündlich Fills und Spot-Bestände; der erste Lauf folgt kurz nach dem Start."""
        await asyncio.sleep(90)
        while not self.stop.is_set():
            t0 = time.time()
            try:
                await self.leaderboard_activity()
                seiten_map = self.stats.pop("_fills_seiten", {}) or {}
                wb = getattr(self.limiter, "wait_by", {}).get(3, (0.0, 0)); wb0 = self.stats.get("_fills_wait0", (0.0, 0))
                w_lauf = (wb[0] - wb0[0], wb[1] - wb0[1]); self.stats["_fills_wait0"] = wb
                schwer = sorted(((n_, a_) for a_, n_ in seiten_map.items() if n_ >= 2), reverse=True)[:5]
                self.stats["fills_schwer"] = [(a_, n_) for n_, a_ in schwer]
                self.note_job("Leaderboard-Fills", takt=self.cfg.lb_fills_interval * self.interval_factor,
                              dauer=time.time() - t0,
                              info=f"{self.stats.get('lb_fills', 0)} Fills, {self.stats.get('lb_fills_deferred', 0)} zurückgestellt · "
                                   f"{len(seiten_map)} Konten, {sum(seiten_map.values())} Seiten"
                                   + (f" · Warten am Begrenzer {w_lauf[0]:.0f} s (Rang 3, hinter allem anderen)" if w_lauf[1] else "")
                                   + (" · Vielhandler: " + ", ".join(f"{a_[:6]}…{a_[-4:]} {n_} S." for n_, a_ in schwer) if schwer else ""))
            except Exception as e:
                self.note_job("Leaderboard-Fills", takt=self.cfg.lb_fills_interval * self.interval_factor,
                              dauer=time.time() - t0, info=f"Fehler: {e}", ok=False)
                print(f"  Leaderboard-Aktivität fehlgeschlagen: {e}")
            # Solange Konten zurückliegen, jede halbe Stunde statt jede Stunde: Das
            # verdoppelt den Durchsatz, ohne das Minutenbudget zu erhöhen, weil jeder
            # einzelne Lauf weiterhin nur die freie Reserve verbraucht.
            takt = self.dyn_takt(self.cfg.lb_fills_interval, 240)          # bei freiem Budget bis auf 4 min
            if self.stats.get("lb_fills_backlog", 0) > 0:
                takt = min(takt, max(240, self.cfg.lb_fills_interval // 2))
            # 15.09. gab es hier eine Pause "mindestens so lang wie der letzte Lauf", weil Rücken-an-Rücken-
            # Läufe die Leaderboard-Stände verdrängten. Seit dem Rang-Begrenzer (17.09.) verdrängen Fills
            # nichts mehr (Rang 3, eigene Reserve) -- die Pause ist weg, das Budget wird gleichmäßig genutzt.
            self.stats["fills_takt_s"] = takt
            await asyncio.sleep(takt * self.interval_factor)

    async def run_leaderboard(self) -> None:
        """Zyklisch alle lb_interval Sekunden; der erste Durchgang läuft bereits beim Start (run())."""
        while not self.stop.is_set():
            takt = self.dyn_takt(self.cfg.lb_interval, 90)                # bei freiem Budget bis auf 90 s
            self.stats["lb_takt_s"] = takt
            await asyncio.sleep(takt * self.interval_factor)
            if self.stop.is_set():
                break
            t0 = time.time()
            await self.leaderboard_cycle()
            self.note_job("Leaderboard-Stände", takt=self.cfg.lb_interval * self.interval_factor,
                          dauer=time.time() - t0,
                          info=f"{self.stats.get('lb_accounts', 0)} Konten, {self.stats.get('lb_positions', 0)} Positionen"
                               + (f" · {self.stats['lb_phasen']}" if self.stats.get("lb_phasen") else ""))

    async def poll_address(self, addr: str) -> None:
        now = int(time.time())
        # Nur die Dexe abfragen, auf denen die Adresse tatsächlich gehandelt hat.
        dexes = self.addr_dex.get(addr) or {""}
        out, total, total_value, any_response = [], 0.0, 0.0, False
        account_value = 0.0                                             # Phase 1: Kontowert aus marginSummary (Standard-Dex)

        for dex in sorted(dexes):
            req = {"type": "clearinghouseState", "user": addr}
            if dex:
                req["dex"] = dex
            data = await self.post(req, quelle="Poller")
            if data is None:
                continue
            any_response = True
            if not dex:
                try:
                    account_value = float((data.get("marginSummary") or {}).get("accountValue") or 0)   # Phase 1: Kontowert
                except (TypeError, ValueError):
                    account_value = 0.0

            for ap in data.get("assetPositions", []):
                p = ap.get("position", {})
                liq = p.get("liquidationPx")
                szi = p.get("szi")
                if liq is None or szi is None:
                    continue                     # z. B. unhebelte Position
                try:
                    liq_px, size = float(liq), float(szi)
                except (TypeError, ValueError):
                    continue
                if liq_px <= 0 or size == 0:
                    continue
                notional = abs(size) * liq_px
                raw = str(p.get("coin", ""))
                lev = p.get("leverage") or {}
                try:
                    lev_val = float(lev.get("value") or 0)
                except (TypeError, ValueError, AttributeError):
                    lev_val = 0.0
                is_cross = str(lev.get("type", "cross")).lower() == "cross"
                try:
                    entry = float(p.get("entryPx") or 0)
                except (TypeError, ValueError):
                    entry = 0.0
                try:
                    pos_val = abs(float(p.get("positionValue") or 0))
                    upnl = float(p.get("unrealizedPnl") or 0)
                except (TypeError, ValueError):
                    pos_val, upnl = 0.0, 0.0
                out.append({
                    "coin": self.coin_of.get(raw) or raw.split(":")[-1],
                    "size": size,
                    "liq_px": liq_px,
                    "notional": notional,
                    "side": "long" if size > 0 else "short",
                    "lev": lev_val,
                    "entry": entry,
                    "pos_value": pos_val,
                    "upnl": upnl,
                    "cross": is_cross,
                })
                total += notional
                total_value += pos_val
            self.stats["polls"] += 1

        if not any_response:
            # Audit M4: Ein kompletter Fehlschlag (alle Dex-Abfragen ohne Antwort) machte die
            # Adresse trotzdem "frisch" -- ihr letzter bekannter Stand blieb bis zum nächsten
            # regulären Takt stehen. Jetzt: last_poll so setzen, dass sie nach fünf Minuten
            # (höchstens der halben Stufenfrist) wieder fällig ist, statt nach der vollen.
            c = self.cfg; pv = self.addr_value.get(addr) or 0.0
            ref = (c.whale_refresh if pv >= c.whale_notional else c.hot_refresh if pv >= c.hot_notional
                   else c.cold_refresh if pv >= c.min_notional else c.cold_refresh * 4) * self.interval_factor
            lp_neu = int(now - ref + min(300, ref // 2))
            m_ = self.addr_meta.get(addr)
            c_typ = pv <= 0 or (pv < c.min_notional and getattr(c, "klein_nach_handel", True))
            k_ = self.poll_fehler.get(addr, (0, 0))[0] + 1
            # 23.86 (zweite Durchsicht): Pause nach Fehlschlägen, verdoppelt je Fehlschlag (erste wie bisher: halber Takt, höchstens
            # 5 min), gedeckelt -- Wale und Elite nach höchstens 5 min wieder, Konten nach eigenem Handel nach höchstens 6 h. Ohne Pause
            # käme eine dauernd scheiternde Adresse mit großem Umsatz jede Runde wieder vor (3 Versuche je Abfrage, die Runde wartet).
            pause = min(6 * 3600 if c_typ else max(4 * ref, 300), max(min(300, ref // 2), 5) * 2 ** (k_ - 1))
            self.poll_fehler[addr] = (k_, now + int(pause))
            if c_typ and m_ and m_[2] / 1000 > (m_[0] or 0) and k_ <= FEHL_AUSLOESER_MAX:
                # 23.86 (Durchsicht): leere und kleine Konten kommen nur nach eigenem Handel dran -- der Handel seit der letzten
                # Abfrage bleibt Auslöser (bis 23.85 ging bei leeren ein Handel verloren, der älter als 1 h 55 min war); nach
                # FEHL_AUSLOESER_MAX Fehlschlägen nicht mehr (dann wie bisher, und kein Vorrang)
                lp_neu = min(lp_neu, int(m_[2] / 1000) - 1)
            elif k_ > FEHL_AUSLOESER_MAX:
                self.addr_umsatz.pop(addr, None)
            self.mark_polled(addr, lp_neu)
            self.stats["poll_failed"] = self.stats.get("poll_failed", 0) + 1
            return

        before, since = self.positions.get(addr, []), self.polled_at.get(addr, 0)
        self.addr_umsatz.pop(addr, None)                     # 23.86: der gehandelte Wert bis jetzt steckt in dieser Antwort
        self.poll_fehler.pop(addr, None)
        vorher_ok = self.erfolg_at.get(addr)
        if vorher_ok:                                        # 23.86 (U231): Abstand von Erfolg zu Erfolg, nur in diesem Lauf
            self.abstand_messen(addr, now - vorher_ok)
        self.erfolg_at[addr] = now
        self.polled_at[addr] = now
        self.track_whales(addr, out, now)
        if addr.lower() in self.pool_addrs:
            self.track_pool(addr, out, now)                # 23.27: Positionen aller Pool-Konten, nicht nur der Wale
        self.infer_liquidations(addr, before, out, since, now)
        # Schreibverstärkung: jede Aktualisierung einer Adresse kostet eine 4-KB-Seite im Log und
        # noch einmal beim Checkpoint. Deshalb: Wert nur schreiben, wenn er sich geändert hat
        # (die meisten Abfragen bringen denselben Stand), last_poll gesammelt alle 10 Minuten.
        prev_val = self.addr_value.get(addr)
        self.mark_polled(addr, now, total_value if out else 0.0)     # Speicherstand sofort aktuell
        if out:
            self.positions[addr] = out
            if prev_val is None or prev_val <= 0 or abs(total_value - prev_val) / max(prev_val, 1) >= 0.02:
                self.addr_update_pending.append((now, total, total_value, account_value, addr))   # flush_round schreibt gesammelt
                self.addr_value[addr] = total_value; self.addr_dirty.pop(addr, None)
            else:
                self.addr_dirty[addr] = now
        else:
            self.positions.pop(addr, None)
            if prev_val is None or prev_val > 0:
                # 23.14 (U37): nur puffern, flush_round schreibt am Ende der Runde. Das direkte UPDATE öffnete mitten in der
                # Runde die Transaktion und hielt die Schreibsperre aller Dienste über die restlichen Netzaufrufe
                # (Netzwerkstatus 23.09. 13:25: 76-mal über 1 s, bis 11,8 s -- jedes Mal genau diese Anweisung).
                self.addr_null_pending.append((now, addr))
                self.addr_value[addr] = 0.0; self.addr_dirty.pop(addr, None)
            else:
                self.addr_dirty[addr] = now

    def whale_positions_schreiben(self, rows: list) -> None:
        """
        Nie scheitern, nie blockieren: Bei gesperrter Datenbank (fremder Schreiber -- am 14.09.
        dreimal je Stunde, seit dem Sammler der Fremdbörsen) bleiben die Zeilen im Speicher und
        gehen beim nächsten Aufruf mit. Verlust gibt es erst ab 5.000 zurückgehaltenen Zeilen.
        """
        # Seit 14.09. nur PUFFERN: Die Poll-Runde schreibt am Ende alles in EINER kurzen
        # Transaktion (flush_round). Vorher öffnete der erste Schreibzugriff die Transaktion
        # und hielt die Schreibsperre über alle Netzaufrufe der Runde -- im Mittel 1,8 s,
        # bis 6,4 s, 142-mal je Stunde über eine Sekunde (gemessen mit hl_dbcoord).
        self.whale_rows_rest.extend(rows)
        if len(self.whale_rows_rest) > 20000:
            self.whale_rows_rest = self.whale_rows_rest[-20000:]

    def abstand_messen(self, addr: str, abstand: int) -> None:
        """23.86 (U231): Abstand zwischen zwei erfolgreichen Abfragen einer Adresse in diesem Lauf, je Stufe wie in due_addresses (vor
        dieser Abfrage), gesammelt je volle Stunde; die letzte volle Stunde steht in meta 'poller_abstaende' (Mittel und Zahl je Stufe) --
        nur Stunden, die nach dem Start begannen. Ersetzt die
        Rückrechnung aus dem gespeicherten Alter, die last_poll als nur stündlich geschrieben annahm -- Konten mit ≥ 2 % Wertänderung,
        neu flache und erstmals abgefragte schreibt der Recorder sofort (unabhängige Durchsicht 26.10.)."""
        c = self.cfg
        m = self.addr_meta.get(addr)
        pv = m[1] if m else 0.0
        if addr in self.gesperrt:
            st = "gesperrt"
        elif addr in getattr(self, "elite_addrs", set()):
            st = "Elite"
        elif addr in self.pool_addrs and pv < c.whale_notional:
            st = "Pool"
        elif pv >= c.whale_notional:
            st = "Wale"
        elif pv >= c.hot_notional:
            st = "groß"
        elif pv >= c.min_notional:
            st = "mittel"
        elif pv > 0:
            st = "klein"
        else:
            st = "leer"
        stunde = int(time.time()) // 3600 * 3600
        if stunde != self.abst_stunde:
            if self.abst_stunde and stunde - self.abst_stunde == 3600 and self.abst_stunde >= getattr(self, "started_at", 0):
                self.abst_letzte = {"stunde": self.abst_stunde, "je_stufe": {k: [n, round(sm / n, 1)] for k, (n, sm) in self.abst_lauf.items() if n}}
            elif self.abst_stunde:
                self.abst_letzte = {}                        # Lücke, Stillstand oder erste (angebrochene) Stunde nach dem Start
            self.abst_stunde, self.abst_lauf = stunde, {}
        z = self.abst_lauf.setdefault(st, [0, 0.0])
        z[0] += 1
        z[1] += abstand

    def mark_polled(self, addr: str, now: int, pos_value: float | None = None) -> None:
        """last_poll (und ggf. der Wert) nur im Speicher; die Datenbank bekommt es gesammelt."""
        self.polled_at[addr] = now
        self.addr_dirty[addr] = now
        m = self.addr_meta.get(addr)
        if m is None:
            self.addr_meta[addr] = [now, pos_value or 0.0, 0, now * 1000]
        else:
            m[0] = now
            if pos_value is not None:
                m[1] = pos_value

    def flush_addr_polls(self) -> None:
        """Gesammelte last_poll-Stände schreiben: eine Transaktion statt Tausender Einzelupdates."""
        if not self.addr_dirty:
            return
        rows = [(t, a) for a, t in self.addr_dirty.items()]
        self.addr_dirty = {}
        self.stueckweise("UPDATE addresses SET last_poll=? WHERE addr=?", rows)
        self.stats["addr_flushed"] = self.stats.get("addr_flushed", 0) + len(rows)

    def ref_px(self, coin: str) -> float:
        """Letzter Handelspreis, sonst Markpreis -- direkt nach dem Start
        gibt es für ruhige Coins noch keinen Trade, aber schon einen Kontext."""
        return self.mid.get(coin) or (self.ctx.get(coin) or {}).get("mark", 0.0)

    def ref_px_or_db(self, coin: str) -> float:
        """Wie ref_px; vor dem ersten Feed (Leaderboard beim Start) der letzte gespeicherte Schluss."""
        px = self.ref_px(coin)
        if px:
            return px
        try:
            row = self.con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
            return float(row[0]) if row and row[0] else 0.0
        except sqlite3.OperationalError:
            return 0.0

    def track_pool(self, addr: str, positions: list[dict], now: int) -> None:
        """
        23.27: Positionen ALLER Pool-Konten protokollieren -- abgefragt werden sie ohnehin alle 10 min (kein zusätzliches
        API-Gewicht). Erste Sicht nach dem Start und danach alle 6 h ein „snap“ (Stand, Fluss 0), dazwischen nur
        Änderungen: open, add, reduce, close, flip mit gerichtetem Fluss in delta_usd. Gesperrte Konten nie.
        """
        a = addr.lower()
        if a in self.gesperrt:
            return
        thr = self.cfg.pool_pos_min
        cur = {p["coin"]: p for p in positions if (p.get("pos_value") or 0) >= thr * 0.5}
        neu = a not in self.pool_state
        prev = self.pool_state.get(a) or {}
        snap = neu or now - self.pool_snap_ts.get(a, 0) >= 6 * 3600
        sg = lambda side: 1.0 if side == "long" else -1.0
        rows = []
        for coin, p in cur.items():
            was = prev.get(coin); val = float(p.get("pos_value") or 0); sz = abs(float(p.get("size") or 0)); mark = self.ref_px_or_db(coin) or 0.0
            ev, fl = None, 0.0
            if not neu:
                if was is None:
                    if val >= thr:
                        ev, fl = "open", sg(p["side"]) * val
                elif p["side"] != was["side"]:
                    ev, fl = "flip", sg(p["side"]) * (abs(float(was.get("pos_value") or 0)) + val)
                else:
                    d_sz = sz - abs(float(was.get("size") or 0))
                    if abs(d_sz) * mark >= self.cfg.pool_event_min:
                        ev, fl = ("add" if d_sz > 0 else "reduce"), sg(p["side"]) * d_sz * mark
            if ev is None and snap:
                ev = "snap"
            if ev:
                rows.append((now, a, coin, ev, p["side"], sz, val, p.get("entry", 0), p.get("liq_px", 0), p.get("lev", 0),
                             p.get("upnl", 0), mark, round(fl, 2)))
        if not neu:
            for coin, was in prev.items():
                if coin not in cur:
                    val = abs(float(was.get("pos_value") or 0))
                    rows.append((now, a, coin, "close", was["side"], 0.0, 0.0, was.get("entry", 0), was.get("liq_px", 0), was.get("lev", 0),
                                 0.0, self.ref_px_or_db(coin) or 0.0, round(-sg(was["side"]) * val, 2)))
        self.pool_state[a] = cur
        if snap:
            self.pool_snap_ts[a] = now
        if rows:
            self.pool_rows_pending.extend(rows)
            self.stats["pool_pos_ereignisse"] = self.stats.get("pool_pos_ereignisse", 0) + sum(1 for r in rows if r[3] != "snap")
            self.stats["pool_pos_konten"] = len(self.pool_state)

    def track_whales(self, addr: str, positions: list[dict], now: int) -> None:
        """
        Protokolliert Positionen über der Wal-Schwelle -- aber nur Änderungen.

        Hysterese: Wer einmal Wal war, bleibt in Beobachtung, bis er unter die
        Hälfte der Schwelle fällt. Sonst flackert eine Position, die um die
        20 Mio. pendelt, ständig zwischen "neu" und "geschlossen".
        """
        # Wal = Konto mit Gesamtwert >= whale_track (Hysterese: bleibt Wal bis zur Hälfte).
        # Von einem Wal werden alle Positionen ab whale_pos_min protokolliert -- so sieht
        # man das ganze Buch eines Kontos, nicht nur seine größte Position.
        thr = self.cfg.whale_pos_min
        cur = {p["coin"]: p for p in positions if p.get("pos_value", 0) > 0}
        prev = self.whale_state.get(addr, {})
        total = sum(p["pos_value"] for p in cur.values())
        is_whale = total >= self.cfg.whale_track or (bool(prev) and total >= self.cfg.whale_track * 0.5)
        if not is_whale:
            cur = {}                                  # kein Wal (mehr): alles Verfolgte schließen
        rows = []

        # Gemessen wird die GRÖSSE der Position, nicht ihr USD-Wert: Der Wert ändert sich auch,
        # wenn nur der Kurs läuft -- eine 113-Mio-Position schwankt bei 1 % Kursbewegung um
        # 1,1 Mio, ohne dass jemand handelt (das erzeugte falsche "stockt auf"-Ereignisse,
        # ausgerechnet in bewegten Phasen). Die Größe ändert sich nur durch echte Trades.
        # delta_usd = gehandelte Menge x Kurs. Schwelle absolut statt prozentual: Wer eine große
        # Kernposition hält und mit kleinen Anteilen um sie herum handelt -- Short in den Dip,
        # zurück in den Long -- fiel bei einer Prozentschwelle vollständig durch. Genau dieses
        # Handeln um die Kernposition ist die eigentliche Strategie.
        for coin, p in cur.items():
            was = prev.get(coin)
            val = p["pos_value"]; sz = abs(p.get("size", 0.0)); mark = self.ref_px_or_db(coin) or 0.0
            if was is None:
                if val < thr:
                    continue
                event = "open"
                delta = val
            else:
                if val < thr * 0.5:
                    continue                          # fällt unten raus -> close
                was_sz = abs(was.get("size", 0.0))
                if p["side"] != was["side"]:
                    event = "flip"; delta = abs(was.get("pos_value", 0) or 0) + val   # M12: gehandelt wurde alt + neu
                elif abs(sz - was_sz) * mark < self.cfg.event_min_usd:
                    continue                          # kein nennenswerter Trade
                else:
                    event = "add" if sz > was_sz else "reduce"
                    delta = (sz - was_sz) * mark
            if addr.lower() in self.gesperrt:                             # H3 (Audit v10): Gesperrte liefern kein Ereignis --
                event, delta = "snap", 0.0                                 # ihre 6-h-Aggregate würden sonst wie ein Wal-Flow-Ereignis wirken
            rows.append((now, addr, coin, event, p["side"], abs(p["size"]), val,
                         p.get("entry", 0), p["liq_px"], p.get("lev", 0),
                         p.get("upnl", 0), self.ref_px(coin), delta))
            prev[coin] = p

        for coin, was in list(prev.items()):
            p = cur.get(coin)
            if p is None or p["pos_value"] < thr * 0.5:
                if addr.lower() not in self.gesperrt:                     # H3: kein close-Ereignis für Gesperrte
                    rows.append((now, addr, coin, "close", was["side"], abs(was["size"]),
                                 p["pos_value"] if p else 0, was.get("entry", 0),
                                 was["liq_px"], was.get("lev", 0),
                                 p.get("upnl", 0) if p else 0, self.ref_px(coin),
                                 -was["pos_value"]))
                # 23.36: auch bei Gesperrten aus dem Zustand nehmen. Bis 23.35 stand das del in der Bedingung oben --
                # eine geschlossene Position eines Gesperrten blieb für immer im Zustand, der Schnappschuss schrieb sie
                # alle 10 min weiter, und jeder Neustart holte sie aus dem Protokoll zurück (Scheinposition).
                del prev[coin]

        if prev:
            self.whale_state[addr] = prev
        else:
            self.whale_state.pop(addr, None)
        if rows or self.whale_rows_rest:
            self.whale_positions_schreiben(rows)
            self.stats["whale_events"] += len(rows)

    def restore_whales(self) -> None:
        """
        Wal-Zustand aus dem Protokoll wiederherstellen.

        Ohne das wäre nach jedem Neustart jeder bestehende Wal ein "neuer" --
        lauter falsche open-Ereignisse mit falschem Zeitstempel.
        23.36: nur noch die letzten 24 h vor dem letzten Eintrag (wal_zustand_laden) -- bis 23.35 las der Start
        die ganze Tabelle (2 Mio. Zeilen: 44 s ohne Aufzeichnung, quadratisch wachsend).
        """
        t0 = time.time()
        zustand, info = wal_zustand_laden(self.con, self.gesperrt)
        n = 0
        for addr, coins in zustand.items():
            for coin, pos in coins.items():
                self.whale_state.setdefault(addr, {})[coin] = pos; n += 1
        if n or info["zeilen"]:
            print(f"  {n} Wal-Positionen aus dem Protokoll übernommen ({info['zeilen']:,} Zeilen der letzten "
                  f"{WAL_WIEDERHER_S // 3600} h, {time.time() - t0:.1f} s"
                  + (f", {info['gesperrt']} von Gesperrten ausgelassen" if info["gesperrt"] else "")
                  + (f", {info['gleichstand']} Gleichstände mit close" if info["gleichstand"] else "") + ")", flush=True)

    def snapshot_whales(self, now: int) -> None:
        """Zeitreihenpunkt je Wal, damit sich Exposure gegen Kurs zeichnen lässt."""
        rows = []
        for addr, coins in self.whale_state.items():
            if addr in self.gesperrt or addr.lower() in self.gesperrt:
                continue                                     # 23.86 (Durchsicht): Gesperrte werden nicht mehr abgefragt -- kein eingefrorener Stand
            for coin, p in coins.items():
                rows.append((now, addr, coin, "snap", p["side"], abs(p["size"]),
                             p["pos_value"], p.get("entry", 0), p["liq_px"],
                             p.get("lev", 0), p.get("upnl", 0),
                             self.ref_px(coin), 0.0))
        if rows or self.whale_rows_rest:
            self.whale_positions_schreiben(rows)

    async def supervise(self, name: str, factory) -> None:
        """
        Hält eine Aufgabe am Leben und macht ihren Ausfall sichtbar.

        Vorher galt: Wirft eine Aufgabe eine Ausnahme, endet sie -- still. Niemand erfährt es,
        die übrigen laufen weiter, und in der Datenbank fehlt einfach ein Datenstrom. Genau so
        blieb ein fehlender Methodenname 30 Stunden unbemerkt und riss eine Lücke in die
        Leaderboard-Historie. Jetzt: Fehler wird gemeldet, in task_errors und in meta vermerkt
        (das Dashboard zeigt es), die Aufgabe startet nach kurzer Pause neu -- Wartezeit
        verdoppelt sich bis höchstens 5 Minuten, damit ein dauerhaft kaputter Lauf nicht rast.
        """
        delay = 5
        while not self.stop.is_set():
            try:
                await factory()
                if not self.stop.is_set():                    # unerwartet normal beendet
                    self.note_task_error(name, "unerwartet beendet")
                    print(f"  AUFGABE {name}: unerwartet beendet — Neustart in {delay} s", flush=True)
                else:
                    return
            except asyncio.CancelledError:
                raise
            except Exception as e:
                import traceback
                tb = traceback.extract_tb(e.__traceback__)
                where = f"{os.path.basename(tb[-1].filename)}:{tb[-1].lineno}" if tb else "?"
                self.note_task_error(name, f"{type(e).__name__}: {e} ({where})")
                print(f"  AUFGABE {name} ABGESTÜRZT: {type(e).__name__}: {e} bei {where} — Neustart in {delay} s", flush=True)
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=delay)
                return                                        # Stopp während der Pause
            except asyncio.TimeoutError:
                pass
            delay = min(delay * 2, 300)

    def ruhige_stunden(self) -> set:
        """
        Die drei umsatzschwächsten Stunden des Tages, aus den eigenen Daten gemessen.

        Der Gedanke: Wo wenig gehandelt wird, entstehen wenig neue Fills und wenig
        Positionsänderungen -- der Adress-Poller hat dann am wenigsten zu entdecken, und
        das Aufholen stört am wenigsten. Statt feste Uhrzeiten anzunehmen, wird gemessen,
        welche Stunden bei DIESEN Märkten tatsächlich ruhig sind; das verschiebt sich mit
        Jahreszeit, Zeitumstellung und Marktlage.

        Gerechnet wird in Ortszeit des Geräts, weil der Mensch davor in Ortszeit denkt.
        Das Ergebnis gilt eine Stunde; die Abfrage läuft also einmal je Stunde.
        """
        jetzt = time.time()
        if self._ruhig_cache and jetzt - self._ruhig_cache[0] < 3600:
            return self._ruhig_cache[1]
        ruhig: set = set()
        try:
            rows = self.con.execute(
                """SELECT CAST(strftime('%H', ts, 'unixepoch', 'localtime') AS INTEGER) h,
                          AVG(volume * close) v
                   FROM bars WHERE ts > ? AND volume > 0
                   GROUP BY h HAVING COUNT(*) >= 20 ORDER BY v ASC""",
                (int(jetzt) - 14 * 86_400,)).fetchall()
            if len(rows) >= 20:                       # nur mit einem vollen Tagesbild
                ruhig = {int(r[0]) for r in rows[:3]}
        except sqlite3.Error:
            ruhig = set()
        self._ruhig_cache = (jetzt, ruhig)
        return ruhig

    def ist_ruhig(self) -> bool:
        """Läuft gerade eine der gemessenen ruhigen Stunden?"""
        return int(time.strftime("%H")) in self.ruhige_stunden()


    def note_job(self, name: str, takt: float | None = None, dauer: float | None = None,
                 info: str = "", ok: bool = True, naechste: float | None = None) -> None:
        """
        Zustand einer wiederkehrenden Aufgabe festhalten: wann sie zuletzt lief, wie lange,
        was dabei herauskam und wann sie das nächste Mal dran ist. Daraus entsteht im
        Dashboard ein Netzwerkstatus -- vorher war das über ein Dutzend Stellen verstreut
        oder gar nicht sichtbar.
        """
        j = self.jobs.setdefault(name, {})
        now = time.time()
        j["last"] = int(now)
        if takt:
            j["next"] = int(now + takt)
            j["takt"] = int(takt)
        if naechste is not None:                 # 23.66 (U145): abweichender nächster Termin, z. B. Wiederholung nach 30 min
            j["next"] = int(now + naechste)
        if dauer is not None:
            j["dauer"] = round(dauer, 1)
        if info:
            j["info"] = info[:120]
        j["ok"] = ok

    def note_task_error(self, name: str, msg: str) -> None:
        e = self.task_errors.setdefault(name, {"count": 0})
        e.update(ts=int(time.time()), error=msg[:200]); e["count"] += 1

    async def run_poller(self) -> None:
        while not self.stop.is_set():
            # Drosselung, solange Fills im Rückstand sind.
            #
            # Der Poller ist der mit Abstand größte Verbraucher (rund 620 von 1.200
            # Gewichtseinheiten je Minute). Das IP-Limit lässt sich bei Hyperliquid weder
            # durch Guthaben noch durch Handelsvolumen erhöhen -- mehr Kapazität für die
            # Fills kann also nur aus der Umverteilung kommen.
            #
            # Bewusst vorübergehend statt dauerhaft: Der Poller durchsucht 140.000 Adressen
            # nach neuen Walen. Ihn für immer zu drosseln hieße, diese Suche dauerhaft zu
            # verlangsamen, obwohl der Engpass nur beim Aufholen besteht. Ist der Rückstand
            # abgebaut, läuft er wieder mit voller Rate. Die bereits bekannten Wale sind
            # nicht betroffen, sie haben eine eigene, kurze Abfragestufe.
            rueckstand = self.stats.get("lb_fills_backlog", 0)
            # 10 % bei größerem Rückstand: Die Untergrenze von 10 Adressen je Runde
            # (siehe want unten) fängt das ab, es bleiben also 120 Abfragen je Minute.
            # Da die Stufensortierung Wale auf Priorität 0 setzt, kommen sie weiterhin
            # zuerst dran -- die Liquidations-Ableitung leidet nicht.
            # Nur bei ECHTEM Rückstand drosseln (mindestens fünf Konten über drei Stunden): Ein oder
            # zwei nachhängende Konten sind Alltag und kein Grund, die Heatmap-Abdeckung zu halbieren
            # (14.09.: 60 % Drossel bei "alle Konten aktuell").
            drossel = 0.30 if rueckstand >= 15 else 0.60 if rueckstand >= 5 else 1.0
            if rueckstand >= 5 and self.ist_ruhig():
                drossel = min(drossel, 0.45)    # ruhige Stunde: nie mehr, nur weniger
            rate = self.cfg.polls_per_min * drossel
            want = max(int(rate / 12), 10)
            batch = self.due_addresses(want)
            self.stats["poller_batch"] = len(batch); self.stats["poller_want"] = want
            if self._vorrang:                                     # 23.86: wegen großen Handels vorgezogene Abfragen (seit dem Start)
                self.stats["poller_vorrang"] = self.stats.get("poller_vorrang", 0) + sum(1 for a_ in batch if a_ in self._vorrang)
            self.stats["poller_drossel"] = drossel
            n_pool_ = sum(1 for a_ in batch if a_ in self.pool_addrs)
            self.stats["poller_pool"] = n_pool_                          # Pool-Konten je Runde (sichtbar: nimmt der Pool zu viel vom Poller-Budget?)
            pool_hist_ = self.stats.setdefault("_poller_pool_hist", [])
            pool_hist_.append((time.time(), n_pool_, len(batch))); del pool_hist_[:-720]         # ~1 h bei 5-s-Runden
            fenster_ = [x for x in pool_hist_ if x[0] >= time.time() - 600]
            self.stats["poller_pool_anteil"] = round(100 * sum(x[1] for x in fenster_) / max(1, sum(x[2] for x in fenster_)), 1)
            self.note_job("Adress-Poller", takt=5,
                          info=f"{len(batch)}/{want} Adressen je Runde · davon Pool {n_pool_} ({self.stats['poller_pool_anteil']:.0f} % der letzten 10 min)"
                               + (f" · auf {drossel * 100:.0f} % gedrosselt, {rueckstand} Konten holen Fills nach"
                                  + (" · ruhige Stunde" if self.ist_ruhig() else "")
                                  if drossel < 1 else ""))
            if not batch:
                self.flush_round()                          # Audit v3 L4: book_summary-Puffer nicht liegen lassen
                await asyncio.sleep(5)
                continue
            await asyncio.gather(*(self.poll_address(a) for a in batch))
            self.flush_round()

    def book_summary_verdichten(self, tage: int = 14) -> None:
        """Wie book_summary_verdichten_datei, auf der eigenen Verbindung (Tests)."""
        book_summary_verdichten_con(self.con, tage)

    def dyn_takt(self, basis: int, minimum: int) -> int:
        """
        Takt nach freiem Budget statt fester Uhr (14.09.): Ist von den 1.200 Gewichtseinheiten je
        Minute viel frei, laufen Fills und Leaderboard-Stände entsprechend öfter -- bis zum
        Minimum; ist wenig frei, gilt der Basistakt. So nähern sich die Daten der Echtzeit, ohne
        dass ein Lauf je mehr als die freie Reserve nimmt (das Budget je Lauf rechnet sich
        weiterhin aus frei_pro_min). Erster Schritt zur bedarfsgesteuerten Warteschlange.
        """
        try:
            kapazitaet = self.limiter.rate * 60                  # Gewicht je Minute nach Temperaturskala (wie im Fill-Budget)
            frei = max(0.0, kapazitaet - self.limiter.used_last_minute()) / max(kapazitaet, 1.0)
        except Exception:
            frei = 0.0
        if frei >= 0.45:
            faktor = 0.25
        elif frei >= 0.30:
            faktor = 0.5
        elif frei >= 0.15:
            faktor = 0.75
        else:
            faktor = 1.0
        self.stats["budget_frei_pct"] = int(frei * 100)
        return max(minimum, int(basis * faktor))

    async def run_stream_fills(self) -> None:
        """
        Minütlich die gesammelten Stream-Fills in EINER kurzen Transaktion schreiben.
        Bei gesperrter Datenbank bleibt der Puffer stehen (höchstens 20.000 Zeilen).
        """
        while not self.stop.is_set():
            for _ in range(60):
                if self.stop.is_set():
                    break
                await asyncio.sleep(1)
            rows, self.stream_fills_pending = self.stream_fills_pending, []
            self.stats["stream_fills_min"] = self.stream_fills_minute; self.stream_fills_minute = 0
            self.stats["stream_trades_min"] = self.stream_trades_minute; self.stream_trades_minute = 0
            self.stream_fills_verlauf = (getattr(self, "stream_fills_verlauf", []) + [self.stats["stream_fills_min"]])[-10:]
            self.stats["stream_fills_10min"] = sum(self.stream_fills_verlauf)
            if self.af is not None:                       # 23.33 Adress-Strom: abgeschlossene Minuten in adressfluss.db, im Hilfsthread
                try:
                    af_rows, af_stat = self.af.abholen(int(time.time()))
                    await asyncio.to_thread(self.af.schreiben, af_rows, af_stat)
                except Exception as e:
                    self.af.st["fehler"] = f"{type(e).__name__}: {e}"; self.af.st["fehler_ts"] = int(time.time())
            ue, self.ue_fills_pending = self.ue_fills_pending, []
            if ue:                                         # 23.23: vollständige Fills der Darwin-Liste ersetzen die geschätzten Stream-Zeilen
                try:
                    for a_ in {r_[1] for r_ in ue}:
                        t_ = [r_[0] for r_ in ue if r_[1] == a_]
                        self.con.execute("DELETE FROM lb_fills WHERE addr=? AND (dir='stream' OR dir LIKE '%*') AND ts>=? AND ts<=?",
                                         (a_, min(t_) - 60, max(t_) + 60))
                    self.con.executemany("INSERT OR REPLACE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ue)
                    self.con.commit()
                except sqlite3.OperationalError as e:
                    if "locked" not in str(e) and "busy" not in str(e):
                        raise
                    try:
                        self.con.rollback()
                    except sqlite3.Error:
                        pass
                    self.ue_fills_pending = (ue + self.ue_fills_pending)[-20000:]
            if not rows:
                continue
            try:
                self.con.executemany("INSERT OR IGNORE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
                self.con.commit()
                self.stats["stream_fills"] = self.stats.get("stream_fills", 0) + len(rows)
            except sqlite3.OperationalError as e:
                if "locked" not in str(e) and "busy" not in str(e):
                    raise
                try:
                    self.con.rollback()
                except sqlite3.Error:
                    pass
                self.stream_fills_pending = (rows + self.stream_fills_pending)[-20000:]
        rows = self.stream_fills_pending
        if rows:
            try:
                self.con.executemany("INSERT OR IGNORE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows); self.con.commit()
            except sqlite3.Error:
                pass
        if self.af is not None:                           # beim Beenden auch die angefangene Minute
            try:
                af_rows, af_stat = self.af.abholen(int(time.time()), alles=True)
                self.af.schreiben(af_rows, af_stat)
            except Exception:
                pass

    def pool_stunden_verdichten(self, now: int) -> int:
        """
        pool_fills_hourly für die letzten 24 abgeschlossenen Stunden neu berechnen (INSERT OR REPLACE, aus
        den Rohfills): n_trades = GEBÜNDELTE Trades (je Minute und Richtung), n_fills = Rohzeilen, Umsätze,
        closedPnl und Gebühren -- für Auswahl (fill_konten) und Pool. Ältere Stunden bleiben, wie sie sind.
        """
        ende = now // 3600 * 3600; start = ende - 24 * 3600
        konten = set(self.fill_konten) | self.pool_addrs
        if not konten:
            return 0
        marks = ",".join("?" * len(konten))
        cur = self.con.execute(f"""INSERT OR REPLACE INTO pool_fills_hourly
                                   SELECT addr, (ts/3600)*3600, coin, market, COUNT(DISTINCT (ts/60)*2 + COALESCE(buy,0)), COUNT(*),
                                          SUM(CASE WHEN buy=1 THEN notional ELSE 0 END), SUM(CASE WHEN buy=1 THEN 0 ELSE notional END),
                                          SUM(COALESCE(closed_pnl,0)), SUM(COALESCE(fee,0))
                                   FROM lb_fills WHERE ts >= ? AND ts < ? AND notional >= ? AND addr IN ({marks}) GROUP BY 1, 2, 3, 4""",
                               (start, ende, self.cfg.lb_fills_min_usd * 0.999, *konten))   # 23.34: kleine Darwin-Fills zählen hier nicht (Vergleichbarkeit)
        self.con.commit()
        return cur.rowcount

    def fills_verdichten_und_loeschen(self, grenze: int, schritt: int = 6 * 3600) -> int:
        """Audit v4 M4: je Fenster [lo, hi): Tagesaggregat einfügen UND Fenster löschen, ein Commit."""
        lo = self.con.execute("SELECT MIN(ts) FROM lb_fills WHERE ts < ?", (grenze,)).fetchone()[0]
        gesamt = 0
        while lo is not None and lo < grenze:
            hi = min(grenze, lo + schritt)
            try:
                self.con.execute("""INSERT INTO lb_fills_daily (day, addr, coin, buy_usd, sell_usd, n, closed_pnl, fee)
                                    SELECT strftime('%Y-%m-%d', ts, 'unixepoch'), addr, coin,
                                           SUM(CASE WHEN buy=1 THEN notional ELSE 0 END), SUM(CASE WHEN buy=1 THEN 0 ELSE notional END),
                                           COUNT(*), SUM(closed_pnl), SUM(fee)
                                    FROM lb_fills WHERE ts >= ? AND ts < ? GROUP BY 1, 2, 3
                                    ON CONFLICT(day, addr, coin) DO UPDATE SET
                                        buy_usd = buy_usd + excluded.buy_usd, sell_usd = sell_usd + excluded.sell_usd,
                                        n = n + excluded.n, closed_pnl = closed_pnl + excluded.closed_pnl, fee = fee + excluded.fee""", (lo, hi))
                cur = self.con.execute("DELETE FROM lb_fills WHERE ts >= ? AND ts < ?", (lo, hi))
                self.con.commit()
                gesamt += cur.rowcount
            except sqlite3.Error as e:
                try:
                    self.con.rollback()
                except sqlite3.Error:
                    pass
                print(f"  lb_fills_daily: {type(e).__name__}: {e} -- Fenster bleibt bis zum nächsten Lauf", flush=True)
                return gesamt
            lo = hi
        return gesamt

    def stueckweise(self, sql: str, rows: list, n: int = 2000) -> None:
        """
        executemany in Stücken von n Zeilen mit Commit dazwischen: Die Schreibsperre ist nur
        Millisekunden gehalten, nie Sekunden. Ein einziges executemany über 50.000 Zeilen
        (stündlicher Adress-Flush) hielt sie auf dem USB-Stick mehrere Sekunden.
        """
        for i in range(0, len(rows), n):
            self.con.executemany(sql, rows[i:i + n])
            self.con.commit()

    def loesche_stueckweise(self, tabelle: str, bedingung: str, args: tuple, schritt: int = 6 * 3600) -> int:
        """
        Aufräumen nach Zeit in Stücken von `schritt` Sekunden Datenzeit, Commit je Stück -- unabhängig
        davon, ob die Tabelle eine rowid hat (heatmap ist WITHOUT ROWID). `bedingung` muss die Form
        "ts < ?" haben; args = (grenze,).
        """
        assert bedingung.strip() == "ts < ?", bedingung
        grenze = int(args[0])
        lo = self.con.execute(f"SELECT MIN(ts) FROM {tabelle} WHERE ts < ?", (grenze,)).fetchone()[0]
        gesamt = 0
        while lo is not None and lo < grenze:
            hi = min(grenze, lo + schritt)
            cur = self.con.execute(f"DELETE FROM {tabelle} WHERE ts >= ? AND ts < ?", (lo, hi))
            self.con.commit()
            gesamt += cur.rowcount
            lo = hi
        return gesamt

    def flush_round(self) -> None:
        """
        Alle Schreibzugriffe einer Poll-Runde in EINER kurzen Transaktion: Positionen der
        Wale, abgeleitete Liquidationen, Adress-Stände. Die Schreibsperre wird erst hier
        geholt und nach Millisekunden wieder freigegeben -- nie über einen Netzaufruf hinweg.
        Bei gesperrter Datenbank bleiben die Puffer stehen und gehen mit der nächsten Runde.
        """
        if not (self.whale_rows_rest or self.liq_rows_pending or self.addr_update_pending or self.addr_null_pending or self.book_rows_pending
                or self.pool_rows_pending or self.tiefe_rows_pending):
            self.con.commit()
            return
        w, l, a, z = self.whale_rows_rest, self.liq_rows_pending, self.addr_update_pending, self.addr_null_pending
        if a and z:
            # je Adresse nur der JÜNGSTE Stand -- nach aufgeschobenen Runden können Wert- und Null-Stand derselben Adresse anstehen
            juengst: dict = {}
            for r in a:
                if r[4] not in juengst or r[0] >= juengst[r[4]][1][0]:
                    juengst[r[4]] = ("a", r)
            for r in z:
                if r[1] not in juengst or r[0] >= juengst[r[1]][1][0]:
                    juengst[r[1]] = ("z", r)
            a = [r for k_, r in juengst.values() if k_ == "a"]; z = [r for k_, r in juengst.values() if k_ == "z"]
        b = list(self.book_rows_pending.values()); self.book_rows_pending = {}
        try:
            if b:
                self.con.executemany("INSERT OR REPLACE INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", b)
            if w:
                self.con.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", w)
            if l:
                self.con.executemany("INSERT OR IGNORE INTO liquidations VALUES (?,?,?,?,?,?,?,?,?)", l)
            if a:
                self.con.executemany("UPDATE addresses SET last_poll=?, notional=?, pos_value=?, account_value=?, misses=0 WHERE addr=?", a)
            if z:
                self.con.executemany("UPDATE addresses SET last_poll=?, notional=0, pos_value=0, misses=misses+1 WHERE addr=?", z)
            pr = self.pool_rows_pending
            if pr:                                                     # 23.27: Positionen der Pool-Konten
                self.con.executemany("INSERT OR REPLACE INTO pool_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", pr)
            if time.time() - self._pool_prune_ts >= 86_400:              # 120 Tage Vorhalt, einmal täglich aufräumen
                self._pool_prune_ts = time.time()
                self.con.execute("DELETE FROM pool_positions WHERE ts < ?", (int(time.time()) - 120 * 86_400,))
            tr = self.tiefe_rows_pending
            if tr:                                                     # 23.125 (U311): Tiefe des Buchs bis ±1 %
                self.con.executemany("INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)", tr)
            if time.time() - self._tiefe_prune_ts >= 86_400:             # 35 Tage Vorhalt, einmal täglich aufräumen
                self._tiefe_prune_ts = time.time()
                self.con.execute("DELETE FROM book_tiefe WHERE ts < ?", (int(time.time()) - TIEFE_TAGE * 86_400,))
            self.con.commit()
            self.tiefe_rows_pending = self.tiefe_rows_pending[len(tr):]
            self.whale_rows_rest, self.liq_rows_pending, self.addr_update_pending, self.addr_null_pending = [], [], [], []
            self.pool_rows_pending = self.pool_rows_pending[len(pr):]
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                raise
            try:
                self.con.rollback()
            except sqlite3.Error:
                pass
            self.stats["round_flush_deferred"] = self.stats.get("round_flush_deferred", 0) + 1
            self.liq_rows_pending = l[-5000:]; self.addr_update_pending = a[-5000:]; self.addr_null_pending = z[-5000:]
            self.pool_rows_pending = self.pool_rows_pending[-30000:]
            self.tiefe_rows_pending = self.tiefe_rows_pending[-600:]

    # -- Snapshots -----------------------------------------------------------

    def bucket_of(self, liq_px: float) -> float:
        """
        Logarithmisches Preisraster: die Bucket-Grenzen sind über die Zeit
        stabil, unabhängig davon, wo der Kurs gerade steht. Ohne das würde
        das Raster mit dem Kurs mitwandern und Snapshots wären nicht
        vergleichbar.
        """
        step = math.log1p(self.cfg.bucket_pct)
        return round(math.exp(round(math.log(liq_px) / step) * step), 8)

    def write_snapshot(self) -> None:
        """
        Aggregiert alle bekannten Liquidationspreise in Preis-Buckets.

        Positionen, deren letzte Abfrage zu lange her ist, bleiben draußen:
        Ein Wallet kann längst geschlossen haben, ohne dass wir es wissen.
        Lieber ein etwas dünnerer, dafür ehrlicher Snapshot.
        """
        now = int(time.time())
        # Zelle -> [notional, n, sum(notional*lev), sum(notional*entry), lev_n, cross_notional]
        agg: dict[tuple[str, float, str], list[float]] = defaultdict(
            lambda: [0.0, 0, 0.0, 0.0, 0.0, 0.0])
        n_pos, n_stale = 0, 0
        tracked_size: dict[str, float] = defaultdict(float)
        alt: dict = {}                                       # 23.112 (U272): Größe der wegen Alters Ausgelassenen je Coin (nur gemessen)

        for addr, positions in self.positions.items():
            # 23.86 (zweite Durchsicht): Alter seit der letzten ERFOLGREICHEN Abfrage -- eine fehlgeschlagene setzt polled_at für den
            # nächsten Versuch neu und ließ alte Positionen bis dahin frisch aussehen (seit Audit M4)
            age = now - self.erfolg_at.get(addr, self.polled_at.get(addr, 0))
            if age > self.cfg.max_pos_age:
                n_stale += len(positions)
                ausgelassen_zaehlen(alt, positions)
                continue
            for p in positions:
                if p["liq_px"] <= 0:
                    continue
                cell = agg[(p["coin"], self.bucket_of(p["liq_px"]), p["side"])]
                cell[0] += p["notional"]
                cell[1] += 1
                if p.get("lev"):
                    cell[2] += p["notional"] * p["lev"]
                    cell[4] += p["notional"]
                if p.get("entry"):
                    cell[3] += p["notional"] * p["entry"]
                if p.get("cross", True):
                    cell[5] += p["notional"]
                tracked_size[p["coin"]] += abs(p["size"])
                n_pos += 1

        # Zähler für die Statuszeile (15.09.: stand immer auf 0, weil nie gesetzt -- kein Datenfehler,
        # die Heatmap wurde geschrieben; die Anzeige las einen Wert, den niemand füllte)
        self.stats["snapshot_rows"] = len(agg); self.stats["snapshot_positions"] = n_pos; self.stats["snapshot_stale"] = n_stale
        if agg:
            self.stueckweise(
                "INSERT OR REPLACE INTO heatmap (ts, coin, bucket_px, side, notional, n_pos, "
                "lev_wavg, entry_wavg, cross_share) VALUES (?,?,?,?,?,?,?,?,?)",
                [(now, coin, bx, side, v[0], v[1],
                  (v[2] / v[4]) if v[4] else None,
                  (v[3] / v[0]) if v[0] and v[3] else None,
                  (v[5] / v[0]) if v[0] else None)
                 for (coin, bx, side), v in agg.items()],
            )

        # Abdeckung: verfolgte Positionsgröße gegen offizielles Open Interest.
        # OI zählt eine Seite, unsere Summe beide -- daher der Faktor 2.
        cov_rows = []
        for coin in self.symbol_of:
            oi = (self.ctx.get(coin) or {}).get("oi", 0)
            if oi > 0:
                cov_rows.append((now, coin, tracked_size.get(coin, 0.0), oi,
                                 tracked_size.get(coin, 0.0) / (2 * oi)))
        if cov_rows:
            self.con.executemany(
                "INSERT OR REPLACE INTO coverage VALUES (?,?,?,?,?)", cov_rows)
            self._last_coverage = {c: r for _, c, _, _, r in cov_rows}

        self.snapshot_whales(now)
        self.write_order_levels(now)
        self.update_event_subs()
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('rate_limited', ?)",
                         (str(self.stats["rate_limited"]),))
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('polls_total', ?)",
                         (str(self.stats["polls"]),))
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('polls_ts', ?)", (str(now),))
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('ausgelassen', ?)",          # 23.112 (U272): für Debug 85, nur gemessen
                         (ausgelassen_json(alt, now, self.cfg.max_pos_age, self.symbol_of),))
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_1m', ?)",
                         (str(self.limiter.used_last_minute()),))
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_budget', ?)",
                         (str(int((self.limiter.rate + getattr(self.limiter, "reserve_rate", 0.0)) * 60)),))   # effektiver Deckel (auch thermisch skaliert), v6 Empf. 6
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_limit', ?)", (str(HL_WEIGHT_BUDGET),))
        self.con.executemany("INSERT OR REPLACE INTO meta VALUES (?, ?)", [
            ("thermal_temp", "" if self.thermal["temp"] is None else f"{self.thermal['temp']:.1f}"),
            ("thermal_level", str(self.thermal["level"])), ("thermal_weight_factor", f"{self.thermal['weight_factor']:.2f}"),
            ("thermal_interval_factor", f"{self.thermal['interval_factor']:.2f}"), ("thermal_since", str(self.thermal["since"]))])
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_ts', ?)", (str(now),))
        lag = self.poll_lag()
        self.con.execute(
            "INSERT OR REPLACE INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)",
            (now,
             self.con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
             # Audit M5: "davon mit offener Position" zählte nur hot + cold -- ohne die Wale und
             # ohne den Staub unter min_notional. Jetzt alle Adressen mit Positionswert.
             self.con.execute("SELECT COUNT(*) FROM addresses WHERE pos_value > 0").fetchone()[0], n_pos, n_stale,
             lag["median"], lag["p90"], lag["backlog"], now - self.started_at))

        self.flush_bars()
        self.flush_bars10()
        self.flush_ctx()
        self.con.commit()

    def poll_lag(self) -> dict:
        """
        Wie aktuell sind die gespeicherten Positionen wirklich?

        Der Snapshot ist ein Mosaik aus unterschiedlich alten Abfragen. Wenn der
        Poller dem Fälligkeitsplan hinterherhinkt, dehnen sich die Abstände still
        aus — diese Zahlen machen das sichtbar.

        23.86 (U220): „überfällig“ und „neu“ aus der letzten Auswahl im Speicher (Gruppe A über ihrem Takt; nie abgefragte ohne
        Gesperrte) statt per SQL über das stündlich geschriebene last_poll -- das zählte kleine und gesperrte Konten mit und hielt
        frisch abgefragte bis zu 1 h für überfällig. „Auslastung“ wie im Bericht „Poller-Kapazität“: Bedarf von Rang 0 und 1 (Wale,
        Elite, Pool, groß, mittel; kleine nur mit --klein-regelmaessig; Takte mal Wärme-Faktor) gegen die EINGESTELLTE Rate mal dem
        Anteil der Runde für Konten mit Position (280/min: 19 von 23). Bis 23.85: Wale, groß und mittel gegen das ganze Budget.
        """
        now = int(time.time())
        ages = [now - r[0] for r in self.con.execute(
            "SELECT last_poll FROM addresses WHERE notional > 0 AND last_poll > 0")]
        c = self.cfg
        f = self.interval_factor
        pools = self.stats.get("due_pools") or (0, 0, 0)
        st = self.stats.get("poller_stufen") or {}
        ages.sort()
        med = ages[len(ages) // 2] if ages else 0
        p90 = ages[int(len(ages) * 0.9)] if ages else 0
        # benötigtes gegen verfügbares Budget, jeweils Abfragen pro Stunde
        need = ((st.get("Wale", 0) + st.get("Elite", 0)) * 3600 / max(c.whale_refresh * f, 1)
                + st.get("Pool", 0) * 3600 / max(POOL_POLL_S * f, 1)
                + st.get("groß", 0) * 3600 / max(c.hot_refresh * f, 1)
                + st.get("mittel", 0) * 3600 / max(c.cold_refresh * f, 1)
                + (0.0 if getattr(c, "klein_nach_handel", True) else st.get("klein", 0) * 3600 / max(c.cold_refresh * 4 * f, 1)))
        want = max(int(c.polls_per_min / 12), 10)
        have = c.polls_per_min * 60 * (int(want * 0.65) + int(want * 0.25)) / want
        return {"median": med, "p90": p90, "backlog": pools[0], "never": pools[1],
                "whales": st.get("Wale", 0), "hot": st.get("groß", 0), "cold": st.get("mittel", 0),
                "elite": st.get("Elite", 0), "pool": st.get("Pool", 0), "klein": st.get("klein", 0), "gesperrt": st.get("gesperrt", 0),
                "load": need / have if have else 0}

    def flush_bars(self, final: bool = False, jetzt: float | None = None) -> None:
        """
        Abgeschlossene Minuten-Bars schreiben; beim Beenden auch die angefangene. 23.82 (U222): erst BAR_GRACE_S nach dem Ende der Minute;
        die Bar ersetzt ihre Zeile vollständig und bleibt im Speicher, bis die Börsenzeit BAR_HALTEN_S über ihr Ende hinaus ist (ein später
        Trade ergänzt sie, die Zeile wird neu geschrieben); die letzte Minute des vorigen Dienstes wird beim ersten Schreiben mit ihrer
        Zeile zusammengeführt. Scheitert das Schreiben, bleiben die Bars offen und werden in der nächsten Runde geschrieben.
        """
        jetzt = self._jetzt() if jetzt is None else float(jetzt)
        cur_min = int(jetzt - BAR_GRACE_S) // 60 * 60
        done = [k for k in self.bars if final or k[0] < cur_min]
        try:
            if done:
                rows = []
                for k in done:
                    b = self.bars[k]
                    if b.get("basis"):
                        self._mit_alter_zeile(b, k, "bars")
                    rows.append((k[0], k[1], b["o"], b["h"], b["l"], b["c"], b["v"], b["n"]))
                self.con.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
                for k in done:
                    self.bars_fertig[k] = self.bars.pop(k)
        finally:
            grenze = self._hw / 1000 - BAR_HALTEN_S
            for k in [k for k in self.bars_fertig if k[0] + 60 <= grenze]:
                del self.bars_fertig[k]

    async def run_flush(self) -> None:
        """
        Häufiger Commit, damit ein Stromausfall wenig kostet.

        Ohne das lägen Bars und Liquidationen bis zu einem Snapshot-Intervall
        nur im Arbeitsspeicher beziehungsweise in einer offenen Transaktion.
        Bei einem geplanten Neustart geht ohnehin nichts verloren, bei einem
        harten Stromausfall aber sehr wohl.
        """
        last_checkpoint = time.time()
        while not self.stop.is_set():
            await asyncio.sleep(flush_warte(time.time(), self.cfg.flush_sec))
            if self.stop.is_set():
                break
            try:
                self.flush_bars()
                self.flush_bars10()
                self.flush_ctx()
                self.maybe_control_window()
                self.finish_tick_recordings()
                if time.time() - self._last_prox >= 60:
                    self.write_proximity()
                    self._last_prox = time.time()
                self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_1m', ?)",
                                 (str(self.limiter.used_last_minute()),))
                self.con.execute("INSERT OR REPLACE INTO meta VALUES ('api_weight_ts', ?)",
                                 (str(int(time.time())),))
                pools = self.stats.get("due_pools") or (0, 0, 0)
                self.con.executemany("INSERT OR REPLACE INTO meta VALUES (?, ?)", [
                    ("poller_batch", str(self.stats.get("poller_batch", 0))), ("poller_want", str(self.stats.get("poller_want", 0))),
                    ("poller_pool_anteil", str(self.stats.get("poller_pool_anteil", 0))), ("pool_konten", str(self.stats.get("pool_konten", 0))),
                    ("gesperrt", str(self.stats.get("gesperrt", 0))),
                    ("poller_due_a", str(pools[0])), ("poller_due_b", str(pools[1])), ("poller_due_c", str(pools[2])),
                    ("poller_vorrang", str(self.stats.get("poller_vorrang", 0))),                     # 23.86: vorgezogen seit dem Start
                    ("poller_abstaende", json.dumps(self.abst_letzte, ensure_ascii=False)),          # 23.86 (U231): letzte volle Stunde
                    ("addr_total", str(len(self.addr_meta))),
                    ("task_errors", json.dumps({k: v for k, v in self.task_errors.items()})[:2000]),
                    ("weight_split", json.dumps({k: round(sum(x[1] for x in v if time.time() - x[0] < 60))
                                                 for k, v in self.weight_by.items()})),
                    ("lb_fills_deferred", str(self.stats.get("lb_fills_deferred", 0))),
                    ("db_locked", str(self.stats.get("db_locked", 0))),
                    ("fill_scans", json.dumps(self.stats.get("fill_scans", {}))),            # 23.75 (Audit v10 M-3)
                    ("event_subs_info", json.dumps({"n": self.stats.get("event_subs", 0), "quelle": self.stats.get("event_subs_quelle", ""),
                                                    "bestaetigt": len(self.event_subs_ok), "abgelehnt": self.event_subs_abgelehnt,
                                                    "grenze": self.cfg.max_event_subs})),          # 23.75 (Audit v10 H-1)
                    ("poller_drossel", f"{self.stats.get('poller_drossel', 1.0):.2f}"),
                    ("stream_fills_min", str(self.stats.get("stream_fills_min", 0))),
                    ("stream_fills_10min", str(self.stats.get("stream_fills_10min", 0))),
                    ("stream_fills_total", str(self.stats.get("stream_fills", 0))),
                    ("stream_trades_min", str(self.stats.get("stream_trades_min", 0))),
                    ("stream_fills_konten", str(len(self.fill_konten))),
                    ("darwin_fills", json.dumps({"konten": len(self._darwin_set), "klein": self.stats.get("darwin_fills_klein", 0),
                                                 "gedeckelt": self.stats.get("darwin_fills_gedeckelt", 0)})),   # 23.34
                    ("adressstrom", json.dumps(self.af.kennzahlen()) if self.af is not None else "{}"),
                    ("fills_takt_s", str(self.stats.get("fills_takt_s", 0))), ("lb_takt_s", str(self.stats.get("lb_takt_s", 0))),
                    ("recorder_alive", str(int(time.time()))),
                    ("u222_seit", time.strftime("%d.%m.%Y %H:%M UTC", time.gmtime(self.started_at)))]       # 23.82: Zähler zu U222
                    + [(f"u222_{k_}", str(v_)) for k_, v_ in self.u222.items()] + [("u222_hw_ms", str(max(self._hw, self._hw_alt or 0)))])
                # Laststatistik je Minute festhalten: eine Zeile je Verbraucher und Minute
                minute = int(time.time()) // 60 * 60 - 60          # die abgeschlossene Minute
                if minute > self._load_flushed:
                    rows = []
                    for quelle, eimer in self.weight_by.items():
                        w_sum = sum(x[1] for x in eimer if minute <= x[0] < minute + 60)
                        if w_sum:
                            rows.append((minute, quelle, int(w_sum)))
                    if rows:
                        self.con.executemany("INSERT OR REPLACE INTO api_load VALUES (?,?,?)", rows)
                        if hasattr(self.con, "kennzahlen"):
                            self.con.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", ("wlock_recorder", json.dumps(self.con.kennzahlen())))
                    self.con.execute("DELETE FROM api_load WHERE ts < ?", (minute - 3 * 86_400,))
                    self._load_flushed = minute
                self.con.execute("INSERT OR REPLACE INTO meta VALUES ('jobs', ?)",
                                 (json.dumps(self.jobs)[:4000],))
                if time.time() - self._last_addr_flush >= 600:
                    self.flush_addresses(); self._last_addr_flush = time.time()
                self.con.commit()
                lebenszeichen_runde()                    # 23.126 (U287): erst nach dem Commit (recorder_alive steht) WATCHDOG=1 an systemd
                # WAL gelegentlich zusammenfalten, sonst wächst sie unbegrenzt
                if time.time() - last_checkpoint > 900:
                    self.con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    last_checkpoint = time.time()
            except sqlite3.Error as e:
                print(f"Schreibfehler: {e}")

    async def run_backup(self) -> None:
        """Einmal täglich, im Hintergrund-Thread, damit der Recorder weiterläuft."""
        interval = 24 * 3600
        await asyncio.sleep(300)                   # nicht direkt beim Start
        while not self.stop.is_set():
            # 23.95 (U243): Stand der Einstellungsdatei VOR dem Lesen merken. Bis 23.94 erst nach dem Backup -- eine Änderung
            # während einer laufenden Sicherung (neuer Pfad, „Jetzt sichern“) galt dann erst nach 30 min statt binnen Sekunden.
            mt0 = speicher_mtime()
            ein = speicher_einstellung()                   # 23.23: Backup-Pfad und „Jetzt sichern“ aus dem Dashboard, ohne Neustart
            if ein.get("backup_dir") and os.path.abspath(ein["backup_dir"]) != os.path.abspath(self.cfg.backup_dir):
                self.cfg.backup_dir = os.path.abspath(ein["backup_dir"])
                print(f"[{time.strftime('%H:%M:%S')}] Backup-Pfad aus dem Dashboard: {self.cfg.backup_dir}", flush=True)
            # meta zeigt Dashboard, Wächter, Bericht und Audit den Ordner. 23.95 (U243): bei jedem Durchgang nachziehen -- bis 23.94 nur
            # beim Wechsel; scheiterte das Schreiben einmal, sahen alle bis zum Neustart den alten Ordner
            try:
                r_m = self.con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
                if not r_m or r_m[0] != self.cfg.backup_dir:
                    self.con.execute("INSERT OR REPLACE INTO meta VALUES ('backup_dir', ?)", (self.cfg.backup_dir,)); self.con.commit()
            except sqlite3.Error:
                pass
            st = backup_status(self.cfg.backup_dir)
            last = st.get("ts", 0) if st and st.get("ok") else 0
            if time.time() - last >= interval or float(ein.get("jetzt_ts") or 0) > last:
                print(f"[{time.strftime('%H:%M:%S')}] Backup läuft …")
                t0 = time.time()
                res = await asyncio.to_thread(do_backup, DB_PATH, self.cfg.backup_dir, 0, None, "Recorder-Dienst")
                if res.get("busy"):
                    # 23.66 (U145): eine andere Sicherung derselben Datenbank läuft (z. B. update.py) -- nicht doppelt
                    # kopieren; in 30 min wieder nachsehen, dann ist ihr Ergebnis in backup.json
                    self.note_job("Backup", takt=interval, naechste=1800, info=f"läuft in anderem Prozess: {res.get('halter')}", ok=True)
                    print(f"           Backup übersprungen: {res.get('error')}", flush=True)
                    res = None
                else:
                    # 23.66 (U145): nach einem Fehler folgt der nächste Versuch in 30 min (die Schleife sieht alle 30 min nach),
                    # nicht erst nach dem Tagestakt -- der Zeitplan zeigte „nächste in 23 h“
                    self.note_job("Backup", takt=interval, dauer=time.time() - t0,
                                  info=(f"{res['size']/1e9:.1f} GB" if res.get("ok") else f"Fehler: {res.get('error')}"),
                                  ok=bool(res.get("ok")), naechste=None if res.get("ok") else 1800)
                if res is None:
                    pass
                elif res["ok"]:
                    print(f"           Backup ok: {res['size']/1e6:.0f} MB in "
                          f"{res['seconds']} s -> {self.cfg.backup_dir}/{BACKUP_NAME}")
                else:
                    print(f"           BACKUP FEHLGESCHLAGEN: {res['error']}"
                          + (" — älteres gutes Backup bleibt erhalten"
                             if res.get("last_good") else ""))
                # Audit v3 S6: täglich nach dem Backup das 5-s-Orderbuch älter als 14 Tage auf Minuten
                # verdichten (kurze Transaktionen je 6 h Datenzeit, Sperre dazwischen frei); 23.66: nicht, solange eine
                # fremde Sicherung läuft (deren Lesetransaktion und Plattenlast nicht zusätzlich belasten)
                try:
                    if res is None:
                        raise _BackupAbbruch()
                    t1 = time.time()
                    n_v = await asyncio.to_thread(book_summary_verdichten_datei, DB_PATH, 14)   # Audit v4 M3: im Thread, eigene Verbindung
                    self.note_job("Buch verdichten", takt=interval, dauer=time.time() - t1, info=f"{n_v:,} 5-s-Zeilen -> 1-min")
                except _BackupAbbruch:
                    pass
                except Exception as e:
                    print(f"  book_summary verdichten: {type(e).__name__}: {e}", flush=True)
            for i_ in range(1800):                 # alle 30 min nachsehen -- 23.23: sofort, wenn das Dashboard etwas einträgt
                if self.stop.is_set():
                    return
                if i_ % 10 == 0 and speicher_mtime() != mt0:
                    break
                await asyncio.sleep(1)

    # -- Stop-/Trigger-Orders der Wale ---------------------------------------

    @staticmethod
    def classify_order(o: dict, mark: float) -> tuple[str, float]:
        """Art der Order und maßgeblicher Preis für die Kaskaden-Frage."""
        side = o.get("side")
        trig = o.get("isTrigger") or o.get("triggerPx") not in (None, "0.0", "0", 0)
        typ = str(o.get("orderType") or ("Limit"))
        tpx = float(o.get("triggerPx") or 0) or float(o.get("limitPx") or 0)
        if trig and tpx:
            if typ.startswith("Stop"):
                return ("stop_sell" if side == "A" else "stop_buy"), tpx
            if typ.startswith("Take"):
                return ("tp_sell" if side == "A" else "tp_buy"), tpx
            # unbenannter Trigger: Lage zum Kurs entscheidet
            if side == "A":
                return ("stop_sell" if tpx < mark else "tp_sell"), tpx
            return ("stop_buy" if tpx > mark else "tp_buy"), tpx
        return ("limit_sell" if side == "A" else "limit_buy"), tpx

    async def poll_whale_orders(self, addr: str) -> None:
        """
        frontendOpenOrders für eine Wal-Adresse: Gewicht 20, zehnmal so teuer wie
        eine Positionsabfrage -- deshalb nur Wale, nur alle stop_interval Sekunden.
        Auf HIP-3-Dexen gesondert abfragen, sonst fehlen die Orders dort.
        """
        dexes = [None] + sorted(self.addr_dex.get(addr, set()) - {""})
        rows, now = [], int(time.time())
        for dex in dexes:
            payload = {"type": "frontendOpenOrders", "user": addr}
            if dex:
                payload["dex"] = dex
            data = await self.post(payload, weight=WEIGHT_OTHER, quelle="Orders")
            if not isinstance(data, list):
                continue
            for o in data:
                sym = str(o.get("coin", ""))
                coin = self.coin_of.get(sym) or sym.split(":")[-1]
                if coin not in self.symbol_of:
                    continue
                mark = self.ref_px(coin) or 0.0
                kind, px = self.classify_order(o, mark)
                try:
                    sz = float(o.get("sz") or 0)
                except (TypeError, ValueError):
                    continue
                if not px or sz <= 0:
                    continue
                rows.append((now, addr, coin, int(o.get("oid") or 0), o.get("side"),
                             str(o.get("orderType") or "Limit"),
                             int(bool(o.get("isTrigger"))),
                             float(o.get("triggerPx") or 0), float(o.get("limitPx") or 0),
                             sz, sz * px, int(bool(o.get("reduceOnly"))),
                             int(bool(o.get("isPositionTpsl"))), kind))
        self.stop_polled_at[addr] = time.time()
        self.orders[addr] = [(r[2], r[13], r[7] or r[8], r[10]) for r in rows]   # (coin, kind, px, notional)
        if rows:
            self.con.executemany("INSERT OR REPLACE INTO trigger_orders VALUES "
                                 "(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            self.stats["order_rows"] += len(rows)
        # Auch ein leeres Ergebnis ist eine Information: Marker-Zeile ohne Order.
        # Die oid muss je Adresse eindeutig sein -- mit oid=0 kollidierten Marker
        # verschiedener Konten derselben Sekunde im Primärschlüssel (ts, oid),
        # und die Zählung "Konten abgefragt" verlor Einträge.
        else:
            marker_oid = -(int(addr[-12:], 16) if addr.startswith("0x") else abs(hash(addr)) % 10**12)
            self.con.execute("INSERT OR REPLACE INTO trigger_orders VALUES "
                             "(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (now, addr, "", marker_oid, "", "none", 0, 0, 0, 0, 0, 0, 0, "none"))
        # Sofort committen: Die Transaktion blieb sonst bis zum Ende des Stapels offen -- über die
        # Netzaufrufe der nächsten Konten hinweg (Diagnose 14.09.: 4,9 s "INSERT ... trigger_orders").
        self.con.commit()

    THERMAL_LEVELS = ((70.0, 0.85, 1.15), (75.0, 0.70, 1.45), (80.0, 0.50, 2.0))   # (°C, Gewichtsfaktor, Taktfaktor)

    @staticmethod
    def read_cpu_temp() -> float | None:
        try:
            with open("/sys/class/thermal/thermal_zone0/temp") as f:
                v = f.read().strip()
            return int(v) / 1000 if v.lstrip("-").isdigit() else None
        except OSError:
            return None

    def apply_thermal(self, temp: float | None) -> bool:
        """Drosselstufe aus der Temperatur mit Hysterese bestimmen und anwenden. True bei Wechsel."""
        lvl = self.thermal["level"]
        if temp is not None:
            new = 0
            for i, (thr, _, _) in enumerate(self.THERMAL_LEVELS, 1):
                if temp >= thr:
                    new = i
            # Hysterese: eine Stufe erst verlassen, wenn 3 °C unter ihrer Schwelle
            if new < lvl and temp > self.THERMAL_LEVELS[lvl - 1][0] - 3.0:
                new = lvl
        else:
            new = 0
        self.thermal["temp"] = temp
        if new == lvl:
            return False
        wf, itf = (1.0, 1.0) if new == 0 else self.THERMAL_LEVELS[new - 1][1:]
        self.thermal.update(level=new, weight_factor=wf, interval_factor=itf, since=int(time.time()))
        self.interval_factor = itf
        self.limiter.set_scale(wf)
        if new:
            print(f"  Temperaturschutz Stufe {new}: {temp:.1f} °C -> API-Gewicht ×{wf:.2f}, Takte ×{itf:.2f}")
        else:
            print(f"  Temperaturschutz aufgehoben: {temp:.1f} °C")
        return True

    async def run_thermal(self) -> None:
        """Alle 30 s die CPU-Temperatur prüfen und die Drosselung nachführen."""
        while not self.stop.is_set():
            try:
                t = self.read_cpu_temp()
                self.apply_thermal(t)
                self.note_job("Temperaturschutz", takt=30, info=f"{t:.1f} °C, Stufe {self.thermal['level']}")
            except Exception:
                pass
            await asyncio.sleep(30)

    def order_tier(self, value: float) -> tuple[int, int]:
        """(Rang, Takt in Sekunden) für einen Positionswert; Rang 0 = Wale. Takte skaliert der Temperaturschutz."""
        tiers = list(self.cfg.stop_tiers)
        tiers[0] = (tiers[0][0], self.cfg.stop_interval)
        tiers[-1] = (tiers[-1][0], self.cfg.stop_interval_big)
        f = self.interval_factor
        for rank, (thr, interval) in enumerate(tiers):
            if value >= thr:
                return rank, int(interval * f)
        return len(tiers), int(self.cfg.stop_interval_big * f)

    def order_candidates(self) -> list[str]:
        """
        Wer wird nach Orders gefragt: alle Konten ab stop_min_usd, jedes in dem
        Takt seiner Größenstufe. Fällige Konten zuerst nach Stufe (Wale vor
        Großen), innerhalb der Stufe die relativ am längsten überfälligen zuerst.
        Das Budget (stop_weight_budget je Minute) nimmt je Runde die ersten.
        """
        now = time.time()
        due = []
        for addr, positions in self.positions.items():
            if addr.lower() in self.gesperrt:                          # Masterregel: keine Order-Abfrage
                continue
            value = sum(p.get("pos_value", 0) for p in positions)
            if value < self.cfg.stop_min_usd:
                continue
            rank, interval = self.order_tier(value)
            age = now - self.stop_polled_at.get(addr, 0)
            if age >= interval:
                due.append((rank, -age / interval, addr))
        for addr in self.whale_state:                      # Wale ohne Positionsdaten im Speicher (nach Neustart)
            if addr.lower() in self.gesperrt:              # 23.30: auch hier keine Order-Abfrage für Gesperrte (Gewicht 20 je Abfrage;
                continue                                   # nach einem Neustart fragte diese Schleife gesperrte Wale bis zu 6 h lang ab)
            if addr not in self.positions and now - self.stop_polled_at.get(addr, 0) >= self.cfg.stop_tiers[1][1]:
                due.append((1, -1e9, addr))
        due.sort()
        self.stats["order_candidates"] = len(due)
        return [a for _, _, a in due]

    async def run_stop_orders(self) -> None:
        """Wale und Großkonten reihum nach ihren Orders fragen, im Budget stop_weight_budget."""
        await asyncio.sleep(90)
        while not self.stop.is_set():
            t0 = time.time()
            try:
                due = self.order_candidates()
                # Stufen sichtbar machen (17.09.: "1.954 fällige Konten" sind keine Wale -- fünf Größenstufen
                # ab 250k; die unteren Stufen laufen nur nach, wenn Budget übrig ist)
                stufen = {}
                for a_ in due:
                    v_ = sum(p_.get("pos_value", 0) for p_ in self.positions.get(a_, ()))
                    k_ = "Wale ≥ 20 Mio" if v_ >= 20e6 else "5–20 Mio" if v_ >= 5e6 else "1–5 Mio" if v_ >= 1e6 else "0,25–1 Mio"
                    stufen[k_] = stufen.get(k_, 0) + 1
                gewicht = 0                                  # v6 Empf. 3: nach Gewicht bemessen -- Multi-Dex-Wale kosten (1 + n_dex) · 20
                for addr in due:
                    kosten = WEIGHT_OTHER * (1 + len(self.addr_dex.get(addr, set()) - {""}))
                    if gewicht + kosten > self.cfg.stop_weight_budget and gewicht > 0:
                        break
                    gewicht += kosten
                    await self.poll_whale_orders(addr)
                    if self.stop.is_set():
                        return
                self.note_job("Orders (Konten ≥ 250k)", takt=60, dauer=time.time() - t0,
                              info=f"{gewicht} Gewicht je Runde · fällig: " + ", ".join(f"{k_} {n_}" for k_, n_ in stufen.items()))
            except Exception as e:
                print(f"  Orders: {e}")
            # v6 Empf. 3: Takt 60 s ABZÜGLICH der Arbeitszeit -- vorher 60 s zusätzlich, Runde 65-75 s
            await asyncio.sleep(max(1.0, 60 - (time.time() - t0)))

    async def run_snapshots(self) -> None:
        while not self.stop.is_set():
            await asyncio.sleep(self.cfg.snapshot_sec)
            if self.stop.is_set():
                break
            t0 = time.time()
            self.write_snapshot()
            self.note_job("Snapshots", takt=self.cfg.snapshot_sec, dauer=time.time() - t0,
                          info=f"{self.stats.get('snapshot_rows', 0)} Heatmap-Zeilen aus {self.stats.get('snapshot_positions', 0)} Positionen"
                               + (f", {self.stats.get('snapshot_stale', 0)} zu alt ausgelassen" if self.stats.get('snapshot_stale') else ""))
            n_addr = self.con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0]
            tracked = sum(len(v) for v in self.positions.values())
            lag = self.poll_lag()
            print(f"[{time.strftime('%H:%M:%S')}] Adressen {n_addr:>6} | "
                  f"Positionen {tracked:>6} | Polls {self.stats['polls']:>7} | "
                  f"Trades {self.stats['trades']:>8} | Liqs {self.stats['liquidations']:>5}"
                  + (f" | 429er {self.stats['rate_limited']}" if self.stats['rate_limited'] else "")
                  + (f" | davon Entdeckung {self.stats['discovery_trades']:,}"
                     if self.stats['discovery_trades'] else "")
                  + (f" | LB {self.stats.get('lb_accounts', 0)}/{self.stats.get('lb_positions', 0)}" if self.stats.get('lb_accounts') else "")
                  + (f" | Fills {self.stats.get('lb_fills', 0)}" if self.stats.get('lb_fills') else "")
                  + (f" | Wal-Events {self.stats['whale_events']}"
                     if self.stats['whale_events'] else "")
                  + (f" | Tick-Events {self.stats['tick_events']}"
                     if self.stats['tick_events'] else "")
                  + f" | API {self.limiter.used_last_minute()}/{HL_WEIGHT_BUDGET}"
                  + (f" | Wal-Orders {self.stats['order_rows']}"
                     if self.stats['order_rows'] else "")
                  + (f" | Liq-Feeds {len(self.event_subs)}" if self.event_subs else "")
                  + (f" | Liqs abgeleitet {self.stats['liq_inferred']}" if self.stats['liq_inferred'] else ""))
            if self._last_coverage:
                print("           Abdeckung des Open Interest: "
                      + "  ".join(f"{c} {r*100:.0f}%" for c, r in
                                  sorted(self._last_coverage.items())))
            print(f"           Datenalter: Median {lag['median']//60:>3} min, "
                  f"90%-Quantil {lag['p90']//60:>3} min | "
                  f"überfällig {lag['backlog']:>5} | neu {lag['never']:>6} | "
                  f"Auslastung {lag['load']*100:>3.0f}%"
                  f" ({lag['whales']} Wale / {lag['elite']} Elite / {lag['pool']} Pool / {lag['hot']} groß / {lag['cold']} mittel"
                  + (f" / {lag['klein']} klein" if not getattr(self.cfg, "klein_nach_handel", True) else
                     f"; {lag['klein']} klein nach eigenem Handel")
                  + f"; {lag['gesperrt']} gesperrt, nicht abgefragt; gegen die eingestellte Rate)")
            if lag["load"] > 0.9 or lag["backlog"] > 200:
                print("           ACHTUNG: Der Poller kommt nicht mehr nach. Die "
                      "tatsächlichen Abstände sind größer als eingestellt.")
                print("           Abhilfe: --polls-per-min erhöhen (Limit beachten), "
                      "--hot-refresh verlängern oder --hot-notional anheben.")

    # -- Start ---------------------------------------------------------------

    # -- Tiefe des Buchs bis ±1 % (U311, 23.125) -------------------------------

    def tiefe_mitte(self, coin: str, jetzt: float) -> float | None:
        """Mitte aus dem ungerundeten Buch (on_book), höchstens TIEFE_MITTE_S alt; sonst None -- dann gilt die Mitte der Antwort."""
        bm = self.buch_mitte.get(coin)
        if bm and bm[0] > 0 and jetzt - bm[1] <= TIEFE_MITTE_S:
            return float(bm[0])
        return None

    async def tiefe_abfragen(self, coin: str, sym: str, jetzt: float) -> tuple | None:
        """
        Eine Abfrage „l2Book“ mit gerundeten Stufen für einen Coin -> Zeile für book_tiefe oder None. Reicht eine Seite nicht bis ±1 %,
        gleich eine zweite Abfrage eine Stelle gröber; danach fragt die Aufgabe für diesen Coin eine Stunde lang gleich gröber.
        """
        mitte = self.tiefe_mitte(coin, jetzt)
        grob = self.tiefe_grob.get(coin)
        n = grob[0] if grob and jetzt < grob[1] else (tiefe_stellen(mitte) or 3)
        for versuch in range(2):
            d = await self.post({"type": "l2Book", "coin": sym, "nSigFigs": n}, weight=WEIGHT_STATE, quelle="Tiefe")
            lv = d.get("levels") if isinstance(d, dict) else None
            m = mitte
            if m is None:
                try:
                    m = (float(lv[0][0]["px"]) + float(lv[1][0]["px"])) / 2
                except (TypeError, ValueError, KeyError, IndexError):
                    m = None
            r = tiefe_rechnen(lv, m) if m else None
            if r is None:
                self.stats["tiefe_fehler"] += 1
                return None
            if r["voll"] == 3 or n <= 2 or versuch:
                break
            self.stats["tiefe_unvollstaendig"] += 1
            n -= 1
            self.tiefe_grob[coin] = (n, jetzt + TIEFE_GROB_S)
        ts = int(d.get("time") or jetzt * 1000) // 1000 // TIEFE_TAKT * TIEFE_TAKT
        return (ts, coin, n, tiefe_schritt(m, n), m, r["bid"], r["ask"], r["n_b"], r["n_a"], r["voll"])

    async def tiefe_runde(self, jetzt: float) -> dict:
        """Eine Runde: je verfolgtem Coin eine Zeile in den Puffer (flush_round schreibt). -> {"zeilen", "voll"}"""
        n = v = 0
        for coin, sym in list(self.symbol_of.items()):
            if self.stop.is_set():
                break
            try:
                z = await self.tiefe_abfragen(coin, sym, jetzt)
            except Exception:  # noqa: BLE001 -- ein Coin hält die anderen nicht auf
                self.stats["tiefe_fehler"] += 1
                z = None
            if z is not None:
                self.tiefe_rows_pending.append(z); n += 1; v += int(z[-1] == 3)
        return {"zeilen": n, "voll": v}

    async def run_tiefe(self) -> None:
        """U311 (23.125): einmal je Minute die Tiefe des Buchs bis ±1 % je verfolgtem Coin (gerundete Stufen, Abfrage l2Book)."""
        while not self.stop.is_set():
            t0 = time.time()
            r = await self.tiefe_runde(t0)
            self.note_job("Buch-Tiefe", takt=TIEFE_TAKT, dauer=time.time() - t0,
                          info=f"{r['zeilen']} Coins, {r['voll']} bis ±1 % vollständig", ok=r["zeilen"] > 0)
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=max(1.0, TIEFE_TAKT - (time.time() - t0)))
                return
            except asyncio.TimeoutError:
                pass

    async def run(self) -> None:
        import aiohttp
        self.con.execute("INSERT OR REPLACE INTO meta VALUES ('started', ?)",
                         (str(int(time.time())),))
        self.con.commit()
        # Wenige, langlebige Verbindungen statt bis zu 100 gleichzeitiger:
        # Jede neue TCP+TLS-Verbindung kostet CPU (Hitze) und einen Eintrag
        # in der NAT-Tabelle des Routers. Ohne Begrenzung öffnete jede
        # Abfragerunde bis zu 80 neue -- rund 20.000 pro Stunde. Ein voller
        # Router blockiert dann JEDES Gerät im Haus, minutenlang, auch
        # nachdem der Recorder gestoppt ist.
        connector = aiohttp.TCPConnector(
            limit=6, limit_per_host=6,
            keepalive_timeout=120,        # länger als der Rundentakt, sonst schläft alles ein
            ttl_dns_cache=600,
            enable_cleanup_closed=True)
        async with aiohttp.ClientSession(connector=connector) as s:
            self.session = s
            print("Löse Handelssymbole auf …")
            print("Verbindungen: höchstens 6 gleichzeitig, wiederverwendet")
            # Audit v3 L2 (wie M13 im Binance-Dienst): Ohne Netz beim Start liefen Recorder und
            # Poller mit leerer Symbolliste "blind" weiter (Exit 0, systemd startet nicht neu).
            # Jetzt bis zu 20 Versuche im 30-s-Abstand, dann Exit 1 -> systemd startet neu.
            try:
                self.sperre_laden()                                 # Masterregel: gesperrte Konten (dauerhaft)
            except Exception as e:
                print(f"  Sperre laden: {type(e).__name__}: {e}", flush=True)
            try:
                n_fs = first_seen_reparieren(self.con)              # 23.66 (U149): Altzeilen des Pools von Sekunden auf ms
                if n_fs:
                    print(f"  Adressregister: first_seen von {n_fs:,} Konten von Sekunden auf Millisekunden umgerechnet (U149)", flush=True)
            except sqlite3.Error as e:
                print(f"  first_seen umrechnen: {type(e).__name__}: {e}", flush=True)
            try:
                self.pool_laden()                                   # Phase 1: Pool aus der Tabelle (bis zur ersten Leaderboard-Datei)
            except Exception as e:
                print(f"  Pool laden: {type(e).__name__}: {e}", flush=True)
            try:
                self.darwin_ziele()                                 # 23.34: Darwin-Liste sofort (kleine Fills), nicht erst beim ersten Snapshot
            except Exception as e:
                print(f"  Darwin-Liste laden: {type(e).__name__}: {e}", flush=True)
            for versuch in range(20):
                await self.resolve_symbols()
                if self.symbol_of:
                    break
                print(f"  keine Symbole aufgelöst (Versuch {versuch + 1}/20) -- neuer Versuch in 30 s", flush=True)
                await asyncio.sleep(30)
            else:
                print("Symbolauflösung endgültig fehlgeschlagen -- beende mit Fehlercode, damit systemd neu startet", flush=True)
                sys.exit(1)
            # bekannte Dex-Zuordnungen aus einem früheren Lauf übernehmen
            for addr, dxs in self.con.execute(
                    "SELECT addr, dexes FROM addresses WHERE dexes != ''"):
                self.addr_dex[addr] = set(dxs.split(","))
            self.restore_whales()
            self.addr_meta = {r[0]: [r[1] or 0, r[2] or 0.0, r[3] or 0, r[4] or 0]
                              for r in self.con.execute("SELECT addr, last_poll, pos_value, last_trade, first_seen FROM addresses")}
            self.addr_value = {a_: m_[1] for a_, m_ in self.addr_meta.items() if m_[0]}
            self.polled_at.update({a_: m_[0] for a_, m_ in self.addr_meta.items() if m_[0]})
            self.addr_known = set(self.addr_meta)
            print(f"  {len(self.addr_meta):,} Adressen im Speicher ({sum(1 for m_ in self.addr_meta.values() if m_[1] > 0):,} mit Position)")
            # Adressen, die der Feed schon vor diesem Punkt gemeldet hat, nachtragen
            self.addr_new = {a: t for a, t in self.addr_seen.items() if a not in self.addr_known}
            # Leaderboard ZUERST: Dashboard-Kacheln und Abschnitt 7 sind sofort befüllt, die
            # Trendzeile der laufenden Stunde steht -- danach beginnen Feeds und Polling.
            print("  Leaderboard: Top-Konten und Positionen laden …", flush=True)
            t_lb = time.time()
            try:
                ok_lb = await self.leaderboard_cycle(force_trend=True)
            except Exception as e:                # darf den Start der Aufzeichnung nie verhindern
                print(f"  Leaderboard-Startdurchgang fehlgeschlagen: {e}")
                ok_lb = False
            print(f"  Leaderboard: {'fertig' if ok_lb else 'nicht ladbar, später erneut'} "
                  f"({self.stats.get('lb_accounts', 0)} Konten mit Positionen aus {self.stats.get('lb_checked', 0)} geprüften, {self.stats.get('lb_positions', 0)} Positionen, {time.time() - t_lb:.0f} s)")
            print()
            jobs = (("Feeds", self.run_ws), ("Polling", self.run_poller), ("Snapshots", self.run_snapshots),
                    ("Flush", self.run_flush), ("Backup", self.run_backup), ("Orders", self.run_stop_orders),
                    ("Leaderboard", self.run_leaderboard), ("Leaderboard-Fills", self.run_leaderboard_activity),
                    ("Pool-Fills", self.run_pool_fills),
                    ("Stream-Fills", self.run_stream_fills), ("Temperatur", self.run_thermal),
                    ("Buch-Tiefe", self.run_tiefe))                      # 23.125 (U311)
            tasks = [asyncio.create_task(self.supervise(name, fn)) for name, fn in jobs]
            await self.stop.wait()
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        self.finish_tick_recordings(force=True)
        self.write_snapshot()
        # angefangene Minute nicht verlieren
        self.flush_bars(final=True); self.flush_bars10(final=True); self.flush_ctx(final=True)
        try:
            self._hw_merken()                                    # 23.82 (U222): bis hierher ist alles geschrieben
        except sqlite3.Error:
            pass
        self.flush_addresses(full=True)                          # gesammelte Adress-Stände sichern
        self.con.commit()
        print("\nSauber beendet. Daten in", DB_PATH)


# ---------------------------------------------------------------------------
# Analyse: Cluster-Berührungen labeln
# ---------------------------------------------------------------------------

def analyze(con: sqlite3.Connection, coin: str, min_x_vol: float = 0.5,
            touch_pct: float = 0.0035, max_gap: int = 120) -> None:
    """
    Sucht Momente, in denen der Kurs ein signifikantes Cluster berührt, und
    misst, was danach passiert ist. min_x_vol = Cluster-Notional relativ zum
    1h-Volumen; darunter wird ein Cluster einfach absorbiert.
    """
    import numpy as np
    import pandas as pd

    bars = pd.read_sql(
        "SELECT * FROM bars WHERE coin=? ORDER BY ts", con, params=(coin,))
    n_heat = con.execute(
        "SELECT COUNT(*) FROM heatmap WHERE coin=?", (coin,)).fetchone()[0]
    if len(bars) < 120 or not n_heat:
        print(f"Zu wenig Daten für {coin}: {len(bars)} Bars, {n_heat} Heatmap-Zeilen.")
        print("Der Recorder sollte einige Wochen laufen, bevor das aussagekräftig wird.")
        return

    bars = bars.set_index("ts")
    px = bars["close"]
    vol_notional = (bars["volume"] * bars["close"]).rolling(60, min_periods=10).sum()

    liq = pd.read_sql(
        "SELECT ts, px, sz FROM liquidations WHERE coin=? ORDER BY ts", con, params=(coin,))
    liq["notional"] = liq["px"] * liq["sz"]

    events = []
    skipped_gap = 0                             # Snapshots ohne passende Kerze
    active: dict[tuple[float, str], int] = {}   # (bucket, side) -> letzte Berührung

    # Die Heatmap wird fensterweise aus der Datenbank gelesen statt komplett
    # geladen. Bei 90 Tagen sind das mehrere Millionen Zeilen — auf einem Pi
    # mit 4 GB wäre das sonst der Engpass.
    span = con.execute("SELECT MIN(ts), MAX(ts) FROM heatmap WHERE coin=?",
                       (coin,)).fetchone()
    window = 3 * 86400
    print(f"Verarbeite {n_heat:,} Heatmap-Zeilen in "
          f"{max(1, (span[1]-span[0])//window + 1)} Fenstern …")

    for w_start in range(span[0], span[1] + 1, window):
        rows = con.execute(
            "SELECT ts, bucket_px, side, notional FROM heatmap "
            "WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
            (coin, w_start, w_start + window)).fetchall()

        by_ts: dict[int, list] = {}
        for r in rows:
            by_ts.setdefault(r[0], []).append(r)
        del rows

        for snap_ts in sorted(by_ts):
            # nächstgelegener Bar-Preis zum Snapshot
            i = px.index.searchsorted(snap_ts)
            if i <= 0 or i >= len(px) - 1:
                continue
            # Eine Bar entsteht nur, wenn gehandelt wurde. In dünnen Märkten
            # kann die nächste Kerze Minuten entfernt liegen -- dann gehört
            # ihr Preis nicht zu diesem Snapshot und das Ereignis wird
            # verworfen statt mit falschem Bezug gezählt.
            if abs(int(px.index[i]) - snap_ts) > max_gap:
                skipped_gap += 1
                continue
            now_px = px.iloc[i]
            v1h = vol_notional.iloc[i]
            if not v1h or math.isnan(v1h) or v1h <= 0:
                continue

            for _, bpx, side, notional in by_ts[snap_ts]:
                x_vol = notional / v1h
                if x_vol < min_x_vol:
                    continue                      # zu klein, wird absorbiert

                dist = (bpx - now_px) / now_px
                # Long-Liquidationen liegen unter dem Kurs, Short-Liqs darüber
                if side == "long" and dist > 0:
                    continue
                if side == "short" and dist < 0:
                    continue
                if abs(dist) > touch_pct:
                    continue                      # noch nicht berührt

                key = (round(bpx, 6), side)
                if snap_ts - active.get(key, 0) < 3600:
                    continue                      # Entprellung: max. 1 Event/h je Cluster
                active[key] = snap_ts

                fwd = {}
                for label, secs in (("1h", 3600), ("4h", 14400), ("24h", 86400)):
                    j = px.index.searchsorted(snap_ts + secs)
                    fwd[label] = (px.iloc[j] / now_px - 1) if j < len(px) else np.nan

                j4 = px.index.searchsorted(snap_ts + 14400)
                seg = bars.iloc[i:j4] if j4 > i else bars.iloc[i:i + 1]
                max_up = seg["high"].max() / now_px - 1
                max_dn = seg["low"].min() / now_px - 1

                pen = int((seg["low"].min() < bpx) if side == "long"
                          else (seg["high"].max() > bpx))
                liq_after = liq[(liq.ts >= snap_ts) & (liq.ts < snap_ts + 3600)]["notional"].sum()

                events.append({
                    "ts": snap_ts, "coin": coin, "cluster_px": bpx, "side": side,
                    "notional": notional, "notional_x_vol": x_vol, "dist_pct": dist,
                    "px_at_touch": now_px,
                    "fwd_1h": fwd["1h"], "fwd_4h": fwd["4h"], "fwd_24h": fwd["24h"],
                    "max_up_4h": max_up, "max_dn_4h": max_dn,
                    "penetrated": pen, "liq_notional_1h": liq_after,
                })

    if skipped_gap:
        print(f"  {skipped_gap:,} Snapshots übersprungen: keine Kursbar innerhalb "
              f"von {max_gap} s. Betrifft vor allem dünne Märkte und Nachtstunden.")

    if not events:
        print("Keine Cluster-Berührungen gefunden. Schwelle --min-x-vol senken "
              "oder länger aufzeichnen.")
        return

    df = pd.DataFrame(events)
    # Alte Ereignisse dieses Coins ersetzen, sonst verdoppelt jeder Lauf die Tabelle
    con.execute("DELETE FROM cluster_events WHERE coin=?", (coin,))
    df.to_sql("cluster_events", con, if_exists="append", index=False)
    con.commit()

    print(f"\n{len(df)} Cluster-Berührungen für {coin}")
    print("=" * 60)
    # Placebo-Basisrate: Wie oft ging der Kurs in 4 h ohnehin aufwärts bzw. abwärts?
    # Erst der Abstand der Reversal-Quote zu dieser Zahl ist eine Aussage über das Cluster.
    _pv = px.values; _idx = px.index.values
    _j = px.index.searchsorted(_idx + 14400)
    _ok = _j < len(_pv)
    _fwd = _pv[_j[_ok]] / _pv[_ok] - 1
    basis_up = float((_fwd > 0).mean()) if len(_fwd) else float("nan")
    print(f"  Basisrate 4 h (alle Zeitpunkte): aufwärts {basis_up:.1%}, abwärts {1 - basis_up:.1%}")
    for side in ("long", "short"):
        s = df[df.side == side]
        # M6: Ereignisse der letzten vier Stunden haben noch kein Ergebnis (NaN). Der Vergleich
        # NaN > 0 ist False -- sie zählten als "keine Umkehr" und drückten Quote, Auszahlung und
        # Erwartungswert systematisch nach unten. Ohne Ergebnis keine Wertung.
        n_offen = int(s.fwd_4h.isna().sum())
        s = s.dropna(subset=["fwd_4h"])
        if s.empty:
            continue
        # "Reversal" = Kurs bewegt sich vom Cluster weg
        rev = (s.fwd_4h > 0) if side == "long" else (s.fwd_4h < 0)
        basis = basis_up if side == "long" else 1 - basis_up
        print(f"\n{side.upper()}-Cluster  (n={len(s)}, {n_offen} noch ohne Ergebnis)")
        print(f"  Reversal-Quote 4h    {rev.mean():.1%}   (Basisrate {basis:.1%}, Lift {rev.mean() / basis if basis else float('nan'):.2f})")
        print(f"  durchbrochen         {s.penetrated.mean():.1%}")
        print(f"  Ø Bewegung 4h        {s.fwd_4h.mean():+.2%}")
        print(f"  Median 4h            {s.fwd_4h.median():+.2%}")
        print(f"  Ø bei Reversal       {s.fwd_4h[rev].mean():+.2%}")
        print(f"  Ø bei Durchbruch     {s.fwd_4h[~rev].mean():+.2%}")
        won, lost = s.fwd_4h[rev].abs().mean(), s.fwd_4h[~rev].abs().mean()
        if won and lost and lost > 0:
            edge = rev.mean() * won - (1 - rev.mean()) * lost
            print(f"  Payoff-Ratio         {won/lost:.2f}")
            print(f"  Erwartungswert       {edge:+.3%} pro Event  <- das ist die Zahl")

    print("\nHinweis: Ohne Gebühren und Slippage. Bei ~0.07 % Taker plus Spread "
          "muss der Erwartungswert deutlich über 0.2 % liegen, um zu tragen.")


# ---------------------------------------------------------------------------
# Simulation zum Testen der Pipeline
# ---------------------------------------------------------------------------

def selbsttest_darwin_fills() -> bool:
    """
    23.34: Fills der Darwin-Liste ohne Mindestbetrag -- kleine Fills der Liste werden gesammelt (Stream, userEvents, REST-Pfad
    gleich), andere Konten wie bisher erst ab lb_fills_min_usd; Deckel je Konto und Stunde; Richtung: ein kürzlich abgefragtes
    Konto ohne Position ist flach (Eröffnung), ein Verkauf nach der eigenen frischen Long-Eröffnung schließt; pool_fills_hourly
    zählt weiter nur Fills ab dem Mindestbetrag. Temporäre Datenbank, kein Netz.
    """
    import tempfile
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_test_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        R.symbol_of = {"BTC": "BTC"}; R.coin_of = {"BTC": "BTC"}; R.dex_of = {"BTC": ""}
        D = "0x" + "d2" * 20; X = "0x" + "e5" * 20; Y = "0x" + "f7" * 20
        now = int(time.time()) // 3600 * 3600 + 600
        R._darwin_set = {D}; R.fill_konten = {X}; R.pool_addrs = {D, X}
        R.polled_at[D] = now - 120                                   # vor 2 min abgefragt, keine Position -> flach
        tid = [1000]

        def trade(t_s, kaeufer, verkaeufer, usd, px=100_000.0):
            tid[0] += 1
            R.on_trade({"coin": "BTC", "px": str(px), "sz": str(usd / px), "time": t_s * 1000, "side": "B", "tid": tid[0],
                        "users": [kaeufer, verkaeufer], "hash": "0x" + "ab" * 32})
        trade(now, D, Y, 1_000.0)                                    # Darwin kauft klein -> Open Long* (flach)
        trade(now + 30, Y, D, 1_500.0)                               # Darwin verkauft klein -> Close Long* (eigene Eröffnung)
        trade(now + 40, X, Y, 1_000.0)                               # anderes Konto klein -> nicht gesammelt
        trade(now + 50, X, Y, 5_000.0)                               # anderes Konto groß -> gesammelt
        rows = list(R.stream_fills_pending)
        dd = [(r[1], r[4], round(r[8])) for r in rows]
        ok("Darwin: kleine Fills gesammelt", (D, "Open Long*", 1000) in dd and (D, "Close Long*", 1500) in dd,
           f"{sum(1 for r in dd if r[0] == D)} Fills des Darwin-Kontos: " + ", ".join(f"{r[1]} {r[2]}" for r in dd if r[0] == D))
        ok("Andere Konten: Mindestbetrag bleibt", (X, "stream", 5000) in dd and not any(r[0] == X and r[2] < 2500 for r in dd),
           f"Konto außerhalb der Liste: {[f'{r[1]} {r[2]}' for r in dd if r[0] == X]}")
        # 23.39: Elite-Konten, die weder Auswahl, Pool noch Wal sind, kommen in die Fill-Konten (ab Mindestbetrag), Gesperrte nicht
        EL = "0x" + "e1" * 20; EG = "0x" + "e9" * 20
        R.elite_addrs = {EL, EG}; R.gesperrt = {EG}
        R.fill_konten_auffrischen({X})
        vorher = len(R.stream_fills_pending)
        trade(now + 55, EL, Y, 5_000.0); trade(now + 56, EL, Y, 1_000.0); trade(now + 57, EG, Y, 5_000.0)
        el_ = [(r[1], round(r[8])) for r in list(R.stream_fills_pending)[vorher:]]
        ok("Elite: Fills ab Mindestbetrag, Gesperrte nie", EL in R.fill_konten and EG not in R.fill_konten and el_ == [(EL, 5000)]
           and {X, D} <= R.fill_konten, f"Fill-Konten {len(R.fill_konten)} (Auswahl, Pool, Elite); gespeichert: {el_}")
        R.gesperrt = set()
        for k in range(DARWIN_KLEIN_MAX_H + 50):                     # Deckel je Konto und Stunde
            trade(now + 60 + k, D, Y, 500.0)
        n_d = sum(1 for r in R.stream_fills_pending if r[1] == D)
        ok("Deckel kleine Fills je Stunde", n_d == DARWIN_KLEIN_MAX_H, f"{n_d} von {DARWIN_KLEIN_MAX_H + 52} kleinen Fills gespeichert (Deckel {DARWIN_KLEIN_MAX_H})")
        R.ue_fills_pending = []
        R.on_user_event(D, {"fills": [{"coin": "BTC", "px": "100000", "sz": "0.01", "time": (now + 3000) * 1000, "dir": "Open Short", "side": "A",
                                        "tid": 9001, "closedPnl": "0", "fee": "0.1"}]})
        R.on_user_event(X, {"fills": [{"coin": "BTC", "px": "100000", "sz": "0.01", "time": (now + 3000) * 1000, "dir": "Open Short", "side": "A",
                                        "tid": 9002, "closedPnl": "0", "fee": "0.1"}]})
        ue = [(r[1], r[4]) for r in R.ue_fills_pending]
        ok("userEvents: Darwin ohne Mindestbetrag", ue == [(D, "Open Short")], f"{ue}")
        con.executemany("INSERT OR IGNORE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", R.stream_fills_pending); con.commit()
        R.pool_stunden_verdichten(now + 3600)
        ph = {a: (n_t, n_f) for a, n_t, n_f in con.execute("SELECT addr, n_trades, n_fills FROM pool_fills_hourly WHERE stunde=?", (now // 3600 * 3600,))}
        ok("pool_fills_hourly: nur ab Mindestbetrag", D not in ph and ph.get(X) == (1, 1),
           f"Darwin-Konto {'fehlt (richtig)' if D not in ph else ph[D]}, anderes Konto {ph.get(X)}")
        R.polled_at.pop(D, None); R._stream_pos.clear()
        ok("Ohne Positionskenntnis: unbekannt", R.stream_richtung(D, "BTC", True, now + 4000) == "stream", "Konto nie abgefragt -> „stream“")
        con.close()
    finally:
        DB_PATH = alt_pfad
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- Fills der Darwin-Liste (23.34) und der Elite (23.39)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<40} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def flush_warte(jetzt: float, takt: int) -> float:
    """23.82 (U222): Wartezeit bis zum nächsten Schreiben. Teilt der Takt die Minute (Dienst: 10 s, Voreinstellung von --flush-sec), liegt
    er FLUSH_PHASE_S hinter jeder Taktgrenze (:03, :13, …) -- die eben beendete Minute wird gut 3 s nach ihrem Ende geschrieben."""
    if takt <= 0 or 60 % takt or takt <= FLUSH_PHASE_S:
        return float(max(1, takt))
    w = (FLUSH_PHASE_S - jetzt) % takt
    return w if w > 0.5 else w + takt


def selbsttest_bars_u222() -> bool:
    """
    23.82 (U222, nach unabhängiger Durchsicht überarbeitet): Ein später Trade ergänzt eine schon geschriebene Minuten-Bar bzw. ein
    10-s-Stück, statt die Zeile mit einem Bruchstück zu ersetzen; geschrieben wird erst BAR_GRACE_S nach dem Ende, im Takt FLUSH_PHASE_S
    hinter jeder Taktgrenze; Trades je Coin nach (Zeit, tid) entdoppelt; Wiederholungen nach Ablauf des Haltens zählen nicht (zu_alt);
    Neustart: Trades bis zur Börsenzeit des vorigen Dienstes zählen nicht, seine letzte Minute wird zusammengeführt (beide Tabellen
    gleich, gleich in welcher Reihenfolge die Wiederholung kommt); Uhr des Pi springt zurück; Schreibfehler; Liquidation in einem
    geschriebenen Stück; Sicherheitsventil der tids. Dazu eine Zufallsfolge (20 min, Verspätungen bis 10 min, Doppelte, Liquidationen,
    Neustart mit Wiederholung) gegen die Wahrheit: alle Zeilen gleich, keine fragliche Minute. Temporäre Datenbank, kein Netz.
    """
    import tempfile
    global DB_PATH, TID_MAX_JE_COIN
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_u222_")
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))

    def neuer(con, start):
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        R.symbol_of = {"BTC": "BTC"}; R.coin_of = {"BTC": "BTC"}; R.dex_of = {"BTC": ""}
        R.started_at = int(start)
        return R

    def wahrheit(trades, liqs=()):
        """Je Minute und 10-s-Stück aus den angenommenen Trades (Reihenfolge der Ankunft bei gleicher Zeit wie im Recorder); liqs:
        (ts_s, px, sz) beobachteter Liquidationen je 10-s-Stück."""
        mi, st = {}, {}
        for j, (ts, px, sz, seite, _tid) in enumerate(trades):
            for d, k in ((mi, ts // 60_000 * 60), (st, ts // 10_000 * 10)):
                e = d.get(k)
                if e is None:
                    e = d[k] = {"o": (ts, j, px), "c": (ts, j, px), "h": px, "l": px, "v": 0.0, "n": 0, "vb": 0.0, "vs": 0.0, "mx": 0.0,
                                "nl": 0, "ln": 0.0}
                if (ts, j) < e["o"][:2]:
                    e["o"] = (ts, j, px)
                if (ts, j) >= e["c"][:2]:
                    e["c"] = (ts, j, px)
                e["h"] = max(e["h"], px); e["l"] = min(e["l"], px); e["v"] += sz; e["n"] += 1; e["mx"] = max(e["mx"], sz)
                e["vs" if seite == "A" else "vb"] += sz
        for ts_s, px, sz in liqs:
            e = st.get(ts_s // 10 * 10)
            if e is not None:
                e["nl"] += 1; e["ln"] += px * sz
        return mi, st

    def vergleich(con, mi, st):
        fehler = []
        zb = {r[0]: r for r in con.execute("SELECT ts, open, high, low, close, volume, trades FROM bars WHERE coin='BTC'")}
        z10 = {r[0]: r for r in con.execute("SELECT ts, open, high, low, close, vol_buy, vol_sell, trades, max_sz, n_liq, liq_notional "
                                            "FROM bars10 WHERE coin='BTC'")}
        for k, e in mi.items():
            r = zb.get(k)
            if r is None or abs(r[1] - e["o"][2]) > 1e-9 or abs(r[2] - e["h"]) > 1e-9 or abs(r[3] - e["l"]) > 1e-9 or abs(r[4] - e["c"][2]) > 1e-9 \
                    or abs(r[5] - e["v"]) > 1e-9 * max(1.0, e["v"]) or r[6] != e["n"]:
                fehler.append(("bars", k, r, e))
        for k, e in st.items():
            r = z10.get(k)
            if r is None or abs(r[1] - e["o"][2]) > 1e-9 or abs(r[2] - e["h"]) > 1e-9 or abs(r[3] - e["l"]) > 1e-9 or abs(r[4] - e["c"][2]) > 1e-9 \
                    or abs(r[5] - e["vb"]) > 1e-9 * max(1.0, e["vb"]) or abs(r[6] - e["vs"]) > 1e-9 * max(1.0, e["vs"]) or r[7] != e["n"] \
                    or abs(r[8] - e["mx"]) > 1e-12 or r[9] != e["nl"] or abs(r[10] - e["ln"]) > 1e-6 * max(1.0, e["ln"]):
                fehler.append(("bars10", k, r, e))
        fehler += [("bars zu viel", k) for k in zb if k not in mi] + [("bars10 zu viel", k) for k in z10 if k not in st]
        frag = 0
        for k, r in zb.items():
            s10 = sum(x[5] + x[6] for t_, x in z10.items() if k <= t_ < k + 60)
            frag += abs(r[5] - s10) > 0.01 * max(r[5], s10)
        return fehler, frag

    def leeren(pfad):
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(pfad + ext):
                os.remove(pfad + ext)
    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        T0 = 1_790_006_400                                             # Minute 0 (ganze Minute, UTC)
        R = neuer(con, T0 - 3600)
        gesendet = []                                                  # angenommene Trades (ts_ms, px, sz, Seite, tid)
        nummer = [10_000]

        def trade(ts_ms, px, sz=1.0, seite="B", tid=None, an=None, merken=True):
            if tid is None:
                nummer[0] += 1; tid = nummer[0]
            R._uhr = (an if an is not None else ts_ms / 1000 + 0.2)
            R.on_trade({"coin": "BTC", "px": str(px), "sz": str(sz), "time": int(ts_ms), "side": seite, "tid": tid})
            if merken:
                gesendet.append((int(ts_ms), float(px), float(sz), seite, tid))
            return tid

        def schreiben(t_s):
            R._uhr = t_s
            R.flush_bars(jetzt=t_s); R.flush_bars10(jetzt=t_s); con.commit()
        # (1) Frist und Takt
        for q in range(10):
            trade((T0 + 6 * q) * 1000, 100 + q, 1.0 + q / 10, "A" if q % 3 == 0 else "B")
        schreiben(T0 + 61.5)
        n_vor = con.execute("SELECT COUNT(*) FROM bars WHERE ts=?", (T0,)).fetchone()[0]
        trade((T0 + 59.9) * 1000, 120.0, 2.0, an=T0 + 61.7)
        schreiben(T0 + 63)
        n_nach = con.execute("SELECT COUNT(*) FROM bars WHERE ts=?", (T0,)).fetchone()[0]
        w10 = [round(flush_warte(T0 + x, 10), 3) for x in (0.0, 2.9, 3.0, 3.2, 20.0, 33.4)]
        w30 = [round(flush_warte(T0 + x, 30), 3) for x in (0.0, 3.2, 20.0)]
        ok("Frist: eine Minute wird erst BAR_GRACE_S nach ihrem Ende geschrieben; Schreibtakt des Dienstes (10 s) auf :03, :13, …",
           n_vor == 0 and n_nach == 1 and w10 == [3.0, 10.1, 10.0, 9.8, 3.0, 9.6] and w30 == [3.0, 29.8, 13.0] and flush_warte(T0, 7) == 7.0,
           f"1,5 s danach {n_vor}, 3 s danach {n_nach} Zeile(n); Wartezeiten 10 s {w10}, 30 s {w30}")
        # (2) später Trade nach dem Schreiben: Minute und 10-s-Stück vollständig neu geschrieben
        trade((T0 + 59.95) * 1000, 130.0, 3.0, "A", an=T0 + 70)
        schreiben(T0 + 96)
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        r0 = con.execute("SELECT high, volume, close, trades FROM bars WHERE ts=? AND coin='BTC'", (T0,)).fetchone()
        ok("Später Trade ergänzt die geschriebene Minute und das Stück (statt sie zu ersetzen)", not f_ and frag == 0 and R.u222["spaet_min"] >= 1
           and R.u222["spaet_10s"] >= 1 and r0 == (130.0, mi[T0]["v"], 130.0, 12), f"Minute 0: {r0}; Abweichungen {len(f_)}")
        # (3) derselbe Trade noch einmal (Schnappschuss beim Neuverbinden) -> nicht doppelt
        trade((T0 + 59.95) * 1000, 130.0, 3.0, "A", tid=gesendet[-1][4], an=T0 + 100, merken=False)
        schreiben(T0 + 130)
        f_, frag = vergleich(con, mi, st)
        ok("Doppelter Trade (gleiche Zeit und tid) zählt nicht", not f_ and R.u222["doppelt"] == 1, f"doppelt {R.u222['doppelt']}")
        # (4) Wiederholung nach 930 s (Minute noch gehalten), 1000 s (Minute frei, tid noch bekannt), 3600 s (beides vorbei)
        erst = gesendet[0]
        d0, z0 = R.u222["doppelt"], R.u222["zu_alt"]
        for dt_ in (930, 1000, 3600):
            trade((T0 + dt_) * 1000, 101.0, 0.5)                       # ein neuer Trade schiebt die Börsenzeit vor
            schreiben(T0 + dt_ + 4)
            trade(erst[0], erst[1], erst[2], erst[3], tid=erst[4], an=T0 + dt_ + 5, merken=False)
            schreiben(T0 + dt_ + 14)
        schreiben(T0 + 3600 + 64)
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        ok_wdh = (not f_ and frag == 0 and R.u222["doppelt"] - d0 == 2 and R.u222["zu_alt"] - z0 == 1)
        Tb = T0 + 5400                                                 # (4b) Minute Tb gehalten bis Börsenzeit Tb+960
        for q in range(6):
            trade((Tb + 2 + 9 * q) * 1000, 104.0 + q / 10, 1.0)
        schreiben(Tb + 63)
        trade((Tb + 945) * 1000, 104.5, 0.2)                           # schiebt die Börsenzeit auf Tb+945 (Stück Tb+0 schon 935 s vorbei)
        schreiben(Tb + 950)
        trade((Tb + 4) * 1000, 103.9, 0.3, an=Tb + 951)                # neuer Trade für das erste Stück der noch gehaltenen Minute
        schreiben(Tb + 1010)
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        ok("Wiederholung eines alten Trades nach 930 s, 1000 s und 3600 s: nie doppelt gezählt (tid bekannt, sonst „zu alt“); ein neuer "
           "Trade 947 s spät für das erste 10-s-Stück einer noch gehaltenen Minute ergänzt Minute und Stück", ok_wdh and not f_ and frag == 0,
           f"doppelt +{R.u222['doppelt'] - d0}, zu alt +{R.u222['zu_alt'] - z0}; Abweichungen {[(x[0], x[1]) for x in f_]}")
        # (5) sehr später, unbekannter Trade (Minute nicht mehr gehalten): zählt nicht
        z0 = R.u222["zu_alt"]
        trade((T0 + 30.5) * 1000, 90.0, 4.0, "B", an=T0 + 3700, merken=False)
        schreiben(T0 + 3720)
        f_, frag = vergleich(con, mi, st)
        ok("Sehr später unbekannter Trade (Minute nicht mehr gehalten): zählt nicht, die Zeilen bleiben", not f_ and R.u222["zu_alt"] - z0 == 1,
           f"zu alt +{R.u222['zu_alt'] - z0}")
        # (6) Uhr des Pi springt zurück: Halten und „zu alt“ hängen an der Börsenzeit, nicht an der Uhr
        Tc = T0 + 7200
        for q in range(10):
            trade((Tc + 5 * q) * 1000, 105.0 + q / 10, 1.0)
        schreiben(Tc + 63)
        schreiben(Tc + 63 + 900)                                       # Uhr weit vor, Börsenzeit nicht: die Minute bleibt gehalten
        trade((Tc + 61) * 1000, 105.2, 0.3, an=Tc + 963)               # ein Trade kommt an, während die Uhr vorgeht
        schreiben(Tc + 970)
        trade((Tc + 50.5) * 1000, 105.0, 0.5, an=Tc + 933)             # Uhr springt zurück; später Trade der gehaltenen Minute
        schreiben(Tc + 940)
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        ok("Uhr des Pi springt: eine gehaltene Minute wird ergänzt, nie durch ein Bruchstück ersetzt", not f_ and frag == 0,
           f"Abweichungen {[(x[0], x[1]) for x in f_]}")
        # (7) Schreibfehler: Bars bleiben offen und kommen in der nächsten Runde; tids werden trotzdem aufgeräumt
        Td = T0 + 10_800
        for q in range(6):
            trade((Td + 9 * q) * 1000, 110.0 + q, 1.0)

        class Kaputt:
            def __init__(self, c):
                self.c = c; self.mal = 1

            def executemany(self, *a):
                if self.mal:
                    self.mal -= 1
                    raise sqlite3.OperationalError("database or disk is full (Probe)")
                return self.c.executemany(*a)

            def __getattr__(self, n):
                return getattr(self.c, n)
        R.con = Kaputt(con)
        try:
            R._uhr = Td + 64
            R.flush_bars(jetzt=Td + 64)
            fehler_ok = False
        except sqlite3.OperationalError:
            fehler_ok = True
        R.con = con
        n_tid_vor = sum(len(e[1]) for e in R._tids.values())
        schreiben(Td + 74)
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        ok("Schreibfehler: die Bars bleiben offen und werden in der nächsten Runde geschrieben", fehler_ok and not f_ and frag == 0,
           f"Fehler gemeldet {fehler_ok}; tids danach {n_tid_vor}; Abweichungen {[(x[0], x[1]) for x in f_]}")
        # (8) Liquidation (userEvents) für ein schon geschriebenes 10-s-Stück: Stück zurückgeholt und neu geschrieben
        Te = T0 + 14_400
        trade((Te + 1) * 1000, 100.0, 2.0, "A")
        schreiben(Te + 13)
        R._uhr = Te + 20
        R.record_liquidation(Te + 5, "BTC", "0x" + "ab" * 20, "market", 100.0, 99.5, 0.4, "A", 77)
        schreiben(Te + 33)
        schreiben(Te + 63)
        mi, st = wahrheit(gesendet, liqs=[(Te + 5, 99.5, 0.4)])
        f_, frag = vergleich(con, mi, st)
        ok("Liquidation in einem schon geschriebenen 10-s-Stück wird nachgetragen", not f_ and R.u222["liq_spaet"] == 1,
           f"spät {R.u222['liq_spaet']}; Abweichungen {[(x[0], x[1]) for x in f_]}")
        liqs_bisher = [(Te + 5, 99.5, 0.4)]
        # (9) Sicherheitsventil: höchstens TID_MAX_JE_COIN tids je Coin
        alt_max = TID_MAX_JE_COIN
        TID_MAX_JE_COIN = 50
        try:
            for q in range(200):
                trade((Te + 60 + q * 0.1) * 1000, 100.0, 0.01)
            R._tids_aufraeumen()
            n_tids = len(R._tids["BTC"][1])
        finally:
            TID_MAX_JE_COIN = alt_max
        schreiben(Te + 125)
        mi, st = wahrheit(gesendet, liqs=liqs_bisher)
        f_, frag = vergleich(con, mi, st)
        ok("Sicherheitsventil: die Menge der tids bleibt begrenzt", n_tids == 50 and not f_, f"{n_tids} tids nach 200 Trades (Grenze 50)")
        # (10) Neustart: Wiederholung bis zur Börsenzeit des vorigen Dienstes zählt nicht (neueste zuerst bzw. älteste zuerst), die letzte
        #      Minute wird mit ihrer Zeile zusammengeführt -- in beiden Tabellen gleich
        ergebnisse = []
        for reihenfolge in ("neueste zuerst", "älteste zuerst"):
            con.close(); leeren(DB_PATH); con = db_connect(DB_PATH)
            Tf = T0 + 20_040                                          # ganze Minute
            R = neuer(con, Tf - 600)
            gesendet = []
            for q in range(30):                                       # alter Dienst: Minute Tf voll, Minute Tf+60 bis :27
                trade((Tf + 3 * q) * 1000, 100.0 + q / 10, 1.0 + q / 100, "A" if q % 2 else "B")
            schreiben(Tf + 63)
            R.flush_bars(final=True); R.flush_bars10(final=True)
            R._hw_merken(); con.commit()
            wdh = gesendet[-6:][::-1] if reihenfolge == "neueste zuerst" else gesendet[-6:]
            R = neuer(con, Tf + 120)                                  # neuer Dienst; Uhr beliebig (hier eine Minute zu spät)
            for e in wdh:                                             # erste Nachricht: Wiederholung
                trade(e[0], e[1], e[2], e[3], tid=e[4], an=Tf + 120.5, merken=False)
            for q in range(10):                                       # danach neue Trades, ab :28 in Minute Tf+60 und in Tf+120
                trade((Tf + 88 + 4 * q) * 1000, 102.0 + q / 10, 0.5)
            R.flush_bars(final=True); R.flush_bars10(final=True); con.commit()
            mi, st = wahrheit(gesendet)
            f_, frag = vergleich(con, mi, st)
            ergebnisse.append((reihenfolge, len(f_), frag, R.u222["vor_start"], R.u222["zusammengefuehrt"]))
        ok("Neustart: Wiederholung zählt nicht (neueste oder älteste zuerst), letzte Minute zusammengeführt, beide Tabellen gleich",
           all(e[1] == 0 and e[2] == 0 and e[3] == 6 and e[4] >= 2 for e in ergebnisse), f"{ergebnisse}")
        # (11) Neustart nach einem Recorder ohne u222_hw_ms (23.81): Grenze ist der Start des Dienstes
        con.execute("DELETE FROM meta WHERE k='u222_hw_ms'"); con.commit()
        R = neuer(con, Tf + 130)                                      # Start mitten in Minute Tf+120 (letzte des vorigen Dienstes)
        n0 = con.execute("SELECT volume FROM bars WHERE ts=? AND coin='BTC'", (Tf + 60,)).fetchone()
        trade((Tf + 75) * 1000, 99.0, 9.0, an=Tf + 131, merken=False)                  # vor dem Start (Minute Tf+60) -> zählt nicht
        trade((Tf + 125) * 1000, 99.0, 9.0, an=Tf + 131, merken=False)                 # vor dem Start (Minute Tf+120) -> zählt nicht
        trade((Tf + 140) * 1000, 103.5, 0.7, an=Tf + 140.3)        # danach in Minute Tf+120 -> mit ihrer Zeile zusammengeführt (das 10-s-Stück
        #                                                            :20–:30 hat keine Zeile, es wird einfach geschrieben)
        R.flush_bars(final=True); R.flush_bars10(final=True); con.commit()
        mi, st = wahrheit(gesendet)
        f_, frag = vergleich(con, mi, st)
        n1 = con.execute("SELECT volume FROM bars WHERE ts=? AND coin='BTC'", (Tf + 60,)).fetchone()
        ok("Neustart ohne Zeitmarke des vorigen Dienstes (Recorder 23.81): vor dem Start nicht gezählt, danach zusammengeführt", not f_
           and frag == 0 and n0 == n1 and n0 is not None and R.u222["vor_start"] == 2 and R.u222["zusammengefuehrt"] == 1,
           f"Minute Tf+60 vorher {n0}, nachher {n1}; vor dem Start {R.u222['vor_start']}; Abweichungen {[(x[0], x[1]) for x in f_]}")
        # (12) Zufallsfolge mit Liquidationen und einem Neustart samt Wiederholung, gegen die Wahrheit
        con.close(); leeren(DB_PATH); con = db_connect(DB_PATH)
        R = neuer(con, T0 - 60)
        rng = random.Random(222)
        t_ = float(T0); px = 100.0; folge = []; tid0 = 50_000
        while t_ < T0 + 20 * 60:
            t_ += rng.expovariate(4.0)
            px *= math.exp(rng.gauss(0, 0.0005))
            ts_ms = int(t_ * 1000)
            u = rng.random()
            lat = rng.uniform(2, 40) if u < 0.05 else rng.uniform(100, 600) if u < 0.06 else rng.uniform(0.05, 0.5)
            tid0 += 1
            e = (ts_ms, round(px, 4), round(rng.uniform(0.001, 2.0), 6), "A" if rng.random() < 0.5 else "B", tid0)
            folge.append((ts_ms / 1000 + lat, "t", e))
            if rng.random() < 0.02:
                folge.append((ts_ms / 1000 + lat + rng.uniform(1, 120), "t", e))          # derselbe Trade noch einmal
            if rng.random() < 0.01:
                folge.append((ts_ms / 1000 + rng.uniform(1, 30), "l", (int(t_), e[1], e[2] / 2)))   # Liquidation, verspätet
        folge.sort(key=lambda x: x[0])
        neustart = T0 + 10 * 60 + 17.3
        runden = sorted([T0 + 3 + 10 * q for q in range(0, 160)] + [T0 + rng.uniform(0, 1500) for _ in range(40)])
        angenommen, gesehen, liqs = [], set(), []
        ri = 0; zweiter = False; hw_alt = None; letzte = []
        for an, art, e in folge:
            if not zweiter and an >= neustart:
                R.flush_bars(final=True); R.flush_bars10(final=True)
                hw_alt = max(R._hw, R._hw_alt or 0)
                R._hw_merken(); con.commit()
                R = neuer(con, int(neustart)); zweiter = True; gesehen = set()
                for x in letzte[-25:]:                                # Wiederholung der letzten Trades in zufälliger Reihenfolge
                    rng.shuffle(letzte)
                    R._uhr = neustart + 0.5
                    R.on_trade({"coin": "BTC", "px": str(x[1]), "sz": str(x[2]), "time": x[0], "side": x[3], "tid": x[4]})
            while ri < len(runden) and runden[ri] <= an:
                schreiben(runden[ri]); ri += 1
            R._uhr = an
            if art == "l":
                if (e[0] // 10 * 10, "BTC") in R.bars10 or (e[0] // 10 * 10, "BTC") in R.bars10_fertig:
                    liqs.append(e)
                R.record_liquidation(e[0], "BTC", "0x" + "cd" * 20, "market", e[1], e[1], e[2], "A", 1)
                continue
            R.on_trade({"coin": "BTC", "px": str(e[1]), "sz": str(e[2]), "time": e[0], "side": e[3], "tid": e[4]})
            if (e[0], e[4]) not in gesehen and (hw_alt is None or e[0] > hw_alt):
                gesehen.add((e[0], e[4])); angenommen.append(e)
            letzte.append(e)
        R.flush_bars(final=True); R.flush_bars10(final=True); con.commit()
        mi, st = wahrheit(angenommen, liqs)
        f_, frag = vergleich(con, mi, st)
        ok("Zufallsfolge (20 min, 6 % bis 10 min verspätet, 2 % doppelt, Liquidationen, Neustart mit Wiederholung): jede Zeile gleich der "
           "Wahrheit, keine fragliche Minute", not f_ and frag == 0 and R.u222["vor_start"] > 0 and R.u222["zusammengefuehrt"] > 0,
           f"{len(angenommen)} Trades, {len(liqs)} Liquidationen, {len(mi)} Minuten, {len(st)} Stücke; nach dem Neustart: vor dem Start "
           f"{R.u222['vor_start']}, zusammengeführt {R.u222['zusammengefuehrt']}, spät Minute {R.u222['spaet_min']}, doppelt {R.u222['doppelt']}; "
           f"Abweichungen {len(f_)}, fraglich {frag}")
        con.close()
    except Exception as ex:                                            # noqa: BLE001
        import traceback
        traceback.print_exc()
        ok("Ablauf", False, f"{type(ex).__name__}: {ex}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- späte und doppelte Trades in Minuten-Bars und 10-s-Stücken (U222, 23.82)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name}  {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden", f"({sum(1 for p_ in pruef if p_[1])} von {len(pruef)})")
    return alles


def selbsttest_wal_start() -> bool:
    """
    23.36: Recorder-Start -- der Wal-Zustand aus dem Protokoll (wal_zustand_laden) gleich der Wahrheit eines Generators:
    offen seit zehn Tagen (nur die letzten 24 h im Fenster), geschlossen, Schnappschuss und close in derselben Sekunde,
    close und open in derselben Sekunde (close gewinnt), Flip, add, zwei Coins eines Kontos, alte Scheinposition außerhalb
    des Fensters, Gesperrter; das Fenster hängt am letzten Eintrag (drei Tage Stillstand). Dazu: Eine geschlossene Position
    eines Gesperrten verlässt den Zustand ohne close-Ereignis, der nächste Schnappschuss schreibt sie nicht mehr; ein
    Nicht-Gesperrter bekommt sein close. Laufzeit auf 100.000 Zeilen. Temporäre Datenbank, kein Netz.
    """
    import tempfile
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_start_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        T = (int(time.time()) - 3 * 86_400) // 600 * 600                # letzter Eintrag vor drei Tagen (Stillstand)
        A = lambda i: "0x%040x" % (0xa11ce0 + i)
        rows: list = []

        def zeile(ts, a, c, ev, side, size=2.0, val=5e6):
            rows.append((ts, a, c, ev, side, size, val, 100.0, 50.0, 5.0, 1000.0, 100.0, 0.0 if ev == "snap" else val))

        def snaps(a, c, side, von, bis, size=2.0, val=5e6):
            for t in range(von // 600 * 600, bis + 1, 600):
                if t >= von:
                    zeile(t, a, c, "snap", side, size, val)
        wahr = {}
        zeile(T - 10 * 86_400, A(1), "BTC", "open", "long"); snaps(A(1), "BTC", "long", T - 10 * 86_400, T)                  # offen seit 10 Tagen
        wahr[(A(1), "BTC")] = ("long", 2.0)
        zeile(T - 30 * 3600, A(2), "BTC", "open", "short"); snaps(A(2), "BTC", "short", T - 30 * 3600, T - 7800)              # vor 2 h geschlossen
        zeile(T - 7200, A(2), "BTC", "close", "short", 0.0, 0.0)
        zeile(T - 20 * 3600, A(3), "ETH", "open", "long"); snaps(A(3), "ETH", "long", T - 20 * 3600, T - 3600)               # Schnappschuss und close
        zeile(T - 3600, A(3), "ETH", "close", "long", 0.0, 0.0)                                                                # in derselben Sekunde
        zeile(T - 5 * 3600, A(4), "ETH", "open", "long"); snaps(A(4), "ETH", "long", T - 5 * 3600, T - 2400)                  # close und open in
        zeile(T - 1800, A(4), "ETH", "close", "long", 0.0, 0.0); zeile(T - 1800, A(4), "ETH", "open", "short")                 # derselben Sekunde
        zeile(T - 8 * 3600, A(5), "HYPE", "open", "long"); snaps(A(5), "HYPE", "long", T - 8 * 3600, T - 4 * 3600 - 600)      # Flip im Fenster
        zeile(T - 4 * 3600, A(5), "HYPE", "flip", "short", 3.0, 7e6); snaps(A(5), "HYPE", "short", T - 4 * 3600 + 600, T, 3.0, 7e6)
        wahr[(A(5), "HYPE")] = ("short", -3.0)
        zeile(T - 6 * 3600, A(6), "BTC", "open", "short"); snaps(A(6), "BTC", "short", T - 6 * 3600, T)                       # zwei Coins: BTC offen,
        wahr[(A(6), "BTC")] = ("short", -2.0)
        zeile(T - 6 * 3600, A(6), "ETH", "open", "long"); zeile(T - 3 * 3600, A(6), "ETH", "close", "long", 0.0, 0.0)         # ETH zu
        zeile(T - 40 * 3600, A(7), "BTC", "open", "long"); snaps(A(7), "BTC", "long", T - 40 * 3600, T - 30 * 3600)           # alte Scheinposition
        snaps(A(8), "BTC", "long", T - 3 * 3600, T)                                                                             # Gesperrter
        zeile(T - 2 * 3600, A(9), "BTC", "open", "long"); zeile(T - 3600, A(9), "BTC", "add", "long", 4.0, 1e7)                # add: jüngste Werte
        snaps(A(9), "BTC", "long", T - 3000, T, 4.0, 1e7)
        wahr[(A(9), "BTC")] = ("long", 4.0)
        con.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        con.execute("INSERT OR REPLACE INTO konto_status VALUES (?,?,?,?,?,?,?)", (A(8).upper().replace("0X", "0x"), "gesperrt", "test", T, "auto", None, 400.0))
        con.commit()
        alt = {(r[0], r[1]): r[2] for r in con.execute(
            """SELECT w.addr, w.coin, w.event FROM whale_positions w WHERE w.ts = (SELECT MAX(ts) FROM whale_positions x
               WHERE x.addr = w.addr AND x.coin = w.coin) AND w.event != 'close'""")}
        R.sperre_laden()
        R.restore_whales()
        ist = {(a, c): (p["side"], p["size"]) for a, cs in R.whale_state.items() for c, p in cs.items()}
        ok("Start: Wal-Zustand = Wahrheit", ist == wahr,
           f"{len(ist)} Positionen übernommen (Soll {len(wahr)})"
           + ("" if ist == wahr else f", ABWEICHEND: {sorted(set(ist) ^ set(wahr))}"))
        schein = sorted(k for k in alt if k not in wahr)
        ok("Fallen greifen (Abfrage bis 23.35)", schein == sorted([(A(3), "ETH"), (A(4), "ETH"), (A(7), "BTC"), (A(8), "BTC")]),
           f"die alte Abfrage hätte {len(schein)} Scheinpositionen übernommen: Schnappschuss+close, close+open, alt, gesperrt")
        # Gesperrter: 6-h-Abfrage bringt die Position (als Schnappschuss, H3), dann ist sie weg -> kein close, raus aus dem Zustand
        now = T + 3 * 86_400
        R.whale_rows_rest = []
        pos = {"coin": "BTC", "side": "long", "size": 2.0, "pos_value": 2e7, "entry": 100.0, "liq_px": 50.0, "lev": 5.0, "upnl": 0.0}
        R.track_whales(A(8), [pos], now)
        drin = "BTC" in R.whale_state.get(A(8), {})
        ev1 = [r[3] for r in R.whale_rows_rest if r[1] == A(8)]
        R.track_whales(A(8), [], now + 60)
        ev2 = [r[3] for r in R.whale_rows_rest if r[1] == A(8) and r[0] == now + 60]
        R.snapshot_whales(now + 600)
        snap_g = [r for r in R.whale_rows_rest if r[1] == A(8) and r[0] == now + 600]
        ok("Gesperrter: geschlossen verlässt den Zustand", drin and ev1 == ["snap"] and ev2 == [] and A(8) not in R.whale_state and not snap_g,
           f"Abfrage mit Position: {'im Zustand' if drin else 'FEHLT'}, Ereignis {ev1}; ohne Position: Ereignisse {ev2 or 'keine'}, "
           f"{'aus dem Zustand' if A(8) not in R.whale_state else 'NOCH IM ZUSTAND'}, nächster Schnappschuss {'ohne ihn' if not snap_g else 'SCHREIBT IHN WEITER'}")
        R.track_whales(A(1), [], now + 60)
        ev3 = [r[3] for r in R.whale_rows_rest if r[1] == A(1) and r[0] == now + 60]
        ok("Nicht-Gesperrter: close wie bisher", ev3 == ["close"] and A(1) not in R.whale_state, f"Ereignisse {ev3}")
        # Laufzeit: 100.000 Zeilen im Fenster
        con.execute("DELETE FROM whale_positions")
        viel = [(T - 86_000 + (i // 120) * 60, "0x%040x" % (0xb0b000 + i % 120), ("BTC", "ETH", "HYPE")[i % 3], "snap", "long",
                 1.0, 2e6, 100.0, 50.0, 5.0, 0.0, 100.0, 0.0) for i in range(100_000)]
        con.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", viel); con.commit()
        t_ = time.time(); z_, info_ = wal_zustand_laden(con, set()); dt_ = time.time() - t_
        ok("Laufzeit 100.000 Zeilen", dt_ < 3.0 and info_["zeilen"] == 100_000, f"{dt_:.2f} s, {sum(len(v) for v in z_.values())} Positionen")
        con.close()
    finally:
        DB_PATH = alt_pfad
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- Start: Wal-Zustand aus dem Protokoll (23.36)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<40} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


class _AuditUhr:
    """Selbsttest U150: eine Uhr, die bei jedem time.time() um `schritt` Sekunden weiterläuft (ein 10-min-Audit in Sekunden)."""
    def __init__(self, echt, schritt: float):
        self._echt = echt; self._t = echt.time(); self._schritt = schritt

    def time(self):
        self._t += self._schritt
        return self._t

    def __getattr__(self, name):
        return getattr(self._echt, name)


def selbsttest_adressen_audit() -> bool:
    """
    23.66 (U149, U150): Adressregister und Audit, temporäre Datenbank, kein Netz.
      1  pool_laden trägt neue Pool-Konten mit first_seen in MILLISEKUNDEN ein (wie last_trade), auch im Speicher
      2  first_seen_reparieren rechnet nur Sekundenwerte um (ms, 0 und NULL bleiben); ein zweiter Lauf findet nichts
      3  Audit „Zeit-Einheiten“: vor der Umrechnung FEHLT mit Hinweis U149, danach ok
      4  Audit „Wal-Lebenszyklen“: Sperrgeschichte, Neustart und unerklärter Fall richtig eingeordnet; FEHLT nur mit einem
         unerklärten Fall, „!“ mit Neustart, ok mit reinen Sperrfällen; ein sauberer Lebenszyklus ergibt keinen Fall
      5  Audit-Uhr: läuft das Audit 10 min, wird kein Alter negativ (Uhr je Prüfung statt beim Start)
      6  Laufzeit je Prüfung an der Zeile und die längsten am Ende
    """
    import tempfile, io, contextlib
    global DB_PATH, time
    alt_pfad, echte_zeit = DB_PATH, time
    tmp = tempfile.mkdtemp(prefix="hl_rec_audit_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))

    def audit_text(con_, uhr=None) -> str:
        global time
        buf = io.StringIO()
        try:
            if uhr is not None:
                time = uhr
            with contextlib.redirect_stdout(buf):
                audit(con_)
        finally:
            time = echte_zeit
        return buf.getvalue()

    def zeile_von(text, name):
        return next((z_ for z_ in text.splitlines() if z_[8:8 + len(name)] == name), "")

    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        now = int(time.time())
        # 1 pool_laden
        P = ["0x%040x" % (0x9001 + i) for i in range(2)]
        for a in P:
            con.execute("INSERT INTO pool_accounts (addr, seit, zuletzt_erfuellt, account_value, pnl_7d) VALUES (?,?,?,?,?)",
                        (a, now - 3600, now, 1e6, 5e4))
        con.commit()
        R.addr_meta = {}
        with contextlib.redirect_stdout(io.StringIO()):
            R.pool_laden(now)
        fs = dict(con.execute(f"SELECT addr, first_seen FROM addresses WHERE addr IN ({','.join('?' * len(P))})", P).fetchall())
        im_db = all(abs((fs.get(a) or 0) - now * 1000) < 5_000 for a in P)
        im_sp = all(abs((R.addr_meta.get(a) or [0, 0, 0, 0])[3] - now * 1000) < 5_000 for a in P)
        ok("U149 pool_laden schreibt ms", im_db and im_sp and len(fs) == 2,
           f"Datenbank {sorted(fs.values())} (Soll ≈ {now * 1000}), Speicher {'ms' if im_sp else 'FALSCH'}")
        # 2 Umrechnung
        con.execute("DELETE FROM addresses")
        S, M, N0, NN = ("0x%040x" % 0xa1, "0x%040x" % 0xa2, "0x%040x" % 0xa3, "0x%040x" % 0xa4)
        con.executemany("INSERT INTO addresses (addr, first_seen, last_trade) VALUES (?,?,?)",
                        [(S, 1_790_032_189, 1_790_032_189_000), (M, 1_790_032_189_000, 1_790_032_189_000),
                         (N0, 0, 0), (NN, None, None)])
        con.commit()
        text_vor = audit_text(con)
        n1 = first_seen_reparieren(con)
        n2 = first_seen_reparieren(con)
        nach = dict(con.execute("SELECT addr, first_seen FROM addresses").fetchall())
        ok("U149 Umrechnung nur Sekundenwerte", n1 == 1 and n2 == 0 and nach[S] == 1_790_032_189_000 and nach[M] == 1_790_032_189_000
           and nach[N0] == 0 and nach[NN] is None,
           f"erster Lauf {n1}, zweiter {n2} · Sekundenwert → {nach[S]}, ms-Wert {nach[M]}, 0 → {nach[N0]}, NULL → {nach[NN]}")
        # 3 Audit Zeit-Einheiten
        text_nach = audit_text(con)
        z_vor, z_nach = zeile_von(text_vor, "Zeit-Einheiten"), zeile_von(text_nach, "Zeit-Einheiten")
        ok("U149 Audit Zeit-Einheiten", z_vor.startswith("  FEHLT") and "first_seen" in z_vor and "U149" in z_vor
           and z_nach.startswith("  ok"), f"vorher „{z_vor.strip()[:90]}…“ · nachher „{z_nach.strip()[:60]}“")
        # 4 Wal-Lebenszyklen
        t0 = now - 2 * 86_400
        A = lambda i: "0x%040x" % (0xc0de00 + i)
        def w(ts, a, ev, coin="BTC"):
            return (ts, a, coin, ev, "long", 1.0, 2e7, 100.0, 50.0, 5.0, 0.0, 100.0, 0.0 if ev == "snap" else 2e7)
        rows = [w(t0 + 4000, A(1), "open"), w(t0 + 4600, A(1), "snap"), w(t0 + 7600, A(1), "open"),  # ohne Erklärung
                w(t0, A(2), "open"), w(t0 + 600, A(2), "snap"), w(t0 + 7200, A(2), "open"),          # Sperrgeschichte (frei)
                w(t0, A(3), "open"), w(t0 + 600, A(3), "snap"), w(t0 + 1800, A(3), "open"),          # Neustart t0 + 1200
                w(t0 + 100, A(4), "add"),                                                             # gesperrt, ohne open
                w(t0, A(5), "open"), w(t0 + 600, A(5), "add"), w(t0 + 1200, A(5), "close"),           # sauber
                w(t0 + 2400, A(5), "open"), w(t0 + 3000, A(5), "close")]
        con.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        con.executemany("INSERT OR REPLACE INTO konto_status (addr, status, grund, seit, quelle) VALUES (?,?,?,?,?)",
                        [(A(2), "frei", "test", t0 + 1800, "test"), (A(4), "gesperrt", "test", t0, "test")])
        con.executemany("INSERT OR REPLACE INTO snapshot_meta (ts, uptime) VALUES (?, ?)",
                        [(t0 + 1500, 300), (t0 + 9600, 100)])                               # Starts t0 + 1200 und t0 + 9500 (nach den Fällen)
        con.commit()
        wl = wal_lebenszyklen(con)
        z = {art: {kat: [f_[0] for f_ in v] for kat, v in wl["faelle"][art].items()} for art in wl["faelle"]}
        soll = {"doppelt": {"sperre": [A(2)], "neustart": [A(3)], "sonst": [A(1)]}, "ohne_open": {"sperre": [A(4)], "neustart": [], "sonst": []}}
        ok("U150 Einordnung je Fall", z == soll and wl["n"] == 12,
           f"{wl['n']} Ereignisse · doppelt: Sperre {len(z['doppelt']['sperre'])}, Neustart {len(z['doppelt']['neustart'])}, "
           f"ohne Erklärung {len(z['doppelt']['sonst'])} · ohne open: Sperre {len(z['ohne_open']['sperre'])}"
           + ("" if z == soll else f" · ABWEICHEND {z}"))
        stufen = []
        for weg in (None, A(1), A(3)):
            if weg:
                con.execute("DELETE FROM whale_positions WHERE addr=?", (weg,)); con.commit()
            stufen.append(zeile_von(audit_text(con), "Wal-Lebenszyklen")[:7])
        ok("U150 Stufe: FEHLT · ! · ok", stufen == ["  FEHLT", "  !    ", "  ok   "],
           f"mit unerklärtem Fall {stufen[0].strip()}, nur Neustart und Sperre {stufen[1].strip()}, nur Sperre {stufen[2].strip()}")
        t_ = audit_text(con)
        bsp = [z_ for z_ in t_.splitlines() if z_.startswith(" " * 31 + "Sperrgeschichte:")]
        ok("U150 Fälle mit Zeit gelistet", bsp and "UTC" in bsp[0] and "open" in bsp[0], (bsp[0].strip()[:110] if bsp else "keine Liste"))
        # 5 Audit-Uhr: Zeilen von WÄHREND des Audits (ts = Start + 300 s), die Uhr läuft 120 s je Aufruf
        neu_ts = now + 300
        for tab_ in ("order_levels", "bars10"):
            if has_table(con, tab_):
                con.execute(f"INSERT OR REPLACE INTO {tab_} (ts, coin) VALUES (?, 'BTC')", (neu_ts,))
        con.commit()
        t_uhr = audit_text(con, uhr=_AuditUhr(echte_zeit, 120.0))
        negativ = [z_.strip() for z_ in t_uhr.splitlines() if "vor -" in z_]
        geprueft = [z_ for z_ in t_uhr.splitlines() if ("Order-Niveaus" in z_ or "10-s-Bars" in z_) and " vor " in z_]
        ok("U150 kein negatives Alter bei langem Audit", not negativ and len(geprueft) == 2,
           f"{len(geprueft)} Frische-Zeilen geprüft, negative Alter: {negativ[:2] or 'keine'}")
        # 6 Laufzeit
        lz = [z_ for z_ in t_uhr.splitlines() if z_.startswith("Laufzeit ")]
        mit_zeit = [z_ for z_ in t_uhr.splitlines() if z_.rstrip().endswith(" s]")]
        ok("U150 Laufzeit je Prüfung", lz and "am längsten" in lz[0] and len(mit_zeit) >= 5,
           f"{len(mit_zeit)} Zeilen mit Zeit, Ende: „{lz[0][:90] if lz else '—'}“")
        con.close()
    finally:
        DB_PATH = alt_pfad
        time = echte_zeit
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- Adressregister und Audit (23.66: U149, U150)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<40} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def has_table(con: sqlite3.Connection, name: str) -> bool:
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def _st_backup_worker(tag, src, bdir, t0, verzug, langsame_pruefung, langsame_kopie, warten_s, wenn_aelter_h, q, sperre_aus):
    """Prozess für selbsttest_backup (fork): do_backup mit verlangsamter Prüfung/Kopie, Ereignisse in die Queue."""
    time.sleep(verzug)
    orig = sqlite3.connect

    class _C(sqlite3.Connection):
        def execute(self, sql, *a):
            if sql.startswith("PRAGMA integrity_check"):
                q.put((tag, "pruefung", time.time() - t0))
                if langsame_pruefung:
                    time.sleep(langsame_pruefung)
            return super().execute(sql, *a)

        def backup(self, target, **k):
            if langsame_kopie:
                erst = [True]

                def fortschritt(st, rest, ges):
                    if erst[0]:
                        q.put((tag, "kopie", time.time() - t0)); erst[0] = False
                    time.sleep(langsame_kopie)
                return super().backup(target, pages=20, progress=fortschritt)
            return super().backup(target, **k)

    def verbinde(*a, **k):
        k.setdefault("factory", _C)
        return orig(*a, **k)

    sqlite3.connect = verbinde
    if sperre_aus:                         # Mutation: Sperre wirkungslos (jeder hält sie) -- muss scheitern
        BackupSperre.versuchen = lambda self: True
    q.put((tag, "start", time.time() - t0))
    try:
        res = do_backup(src, bdir, warten_s=warten_s, wenn_aelter_h=wenn_aelter_h, wer=f"Test {tag}", melden=lambda t: None)
    except Exception as e:                 # ein Absturz ist ein Ergebnis wie jedes andere
        res = {"ok": False, "error": f"Ausnahme {type(e).__name__}: {e}"}
    q.put((tag, "ende", time.time() - t0, {k: res.get(k) for k in ("ok", "busy", "frisch", "error", "gewartet_s")}))


def selbsttest_backup(mutation: str | None = None) -> bool:
    """
    23.66 (U145): mehrere Sicherungen derselben Datenbank gleichzeitig -- nachgestellt wie am 11.10. (update.py und
    Recorder nach demselben Kriterium, 0,3 s versetzt). Soll, ohne Netz, in einem temporären Ordner:
      B1  zwei Läufe ohne Warten: genau einer kopiert (ok), der andere meldet „läuft bereits“; Generationen genau
          einmal weitergeschoben; keine Zwischendatei bleibt liegen
      B2  wie update.py: Warten + „nur wenn älter als 24 h“ -> übernimmt das frische Backup, keine zweite Kopie
      B3  Warten ohne Altersgrenze (--force-db-backup): zweite Kopie NACH der ersten, beide ok, zwei Rotationen
      B4  ein Halter wird mitten in der Kopie hart beendet (SIGKILL, wie ein Dienst-Stopp): die Sperre ist sofort frei,
          seine Reste räumt der nächste Lauf weg, der gelingt
      B5  Altlasten: alte Zwischendatei ohne PID samt heißem Journal einer fremden Datenbank -- werden entfernt, Kopie gelingt
      B6  backup.json ist während aller Läufe für einen Leser jederzeit vollständiges JSON
      B7  Nebendatenbanken (forecasts, makro, aktien, ausblick) werden mitgesichert
          23.103 (U257): dazu staking.db; die Kopie jeder Nebendatenbank trägt deren INHALT (bis 23.102 prüfte B7 nur, dass eine Datei
          entstand), nach einem zweiten Lauf ist .1 der vorige Stand; eine beschädigte Nebendatenbank ersetzt die gute Kopie nicht;
          die Muster für Anzeige, Umzug und Aufräumen kennen jeden Namen
    23.95 (U243): Ausgang jeder Probe ist der Stand mit DREI Generationen (F0, F1, F2 wie bis 23.94); Soll sind zwei: die alte .2
    verschwindet beim ersten Lauf (B1–B4: neu, F0; zwei Läufe: neu, neu). Neu:
      B8  die alte .2 fällt VOR der Platzprüfung weg (Platz reicht nur ohne sie), die Kopie gelingt
      B9  Ordner unter /media bzw. /mnt, Laufwerk nicht eingehängt: kein Lauf, nichts angelegt, keine backup.json, keine Ausnahme;
          Gegenprobe auf einem echten Einhängepunkt (/dev/shm): gelingt
      B10 Ordner nicht anlegbar: Fehler im Ergebnis statt Ausnahme (bis 23.94 stürzte die Aufgabe „Backup“ des Recorders ab)
      B11 vier Läufe nacheinander: nie mehr als zwei Stände, .1 ist jeweils die vorige Sicherung; backup_generationen, backup_bedarf
      B12 backup_laeuft: zeigt den Halter der Sperre, danach nichts; legt keine Sperrdatei an
      B13 Schleife des Recorders (run_backup, Zeit gerafft): neuer Pfad aus dem Dashboard binnen Sekunden übernommen und dort
          gesichert; ein zweiter Wechsel WÄHREND einer laufenden Sicherung gilt direkt danach (bis 23.94 erst nach 30 min); scheitert
          das Eintragen in meta einmal, zieht der nächste Durchgang es nach; „Jetzt sichern“ wirkt; ein nicht eingehängtes Ziel bricht
          ab, ohne die Aufgabe zu beenden
      B9 auch: beim Wählen festgehaltener Einhängepunkt fehlt -> kein Lauf (auch außerhalb von /media und /mnt)
    Mutation „sperre_aus“ (jeder hält die Sperre): B1 muss scheitern -- die Sperre trägt.
    """
    import multiprocessing as mp
    import tempfile
    import threading
    ctx = mp.get_context("fork")
    ok_all = True

    def pruef(name, bed, detail=""):
        nonlocal ok_all
        ok_all &= bool(bed)
        print(f"  {'ok ' if bed else 'FEHLER'} {name}{(' — ' + detail) if detail else ''}", flush=True)

    tmp = tempfile.mkdtemp(prefix="hl_backup_test_")
    try:
        src = os.path.join(tmp, "hl_liq.db")
        con = sqlite3.connect(src)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("CREATE TABLE bars(ts INTEGER, coin TEXT, close REAL, pad BLOB)")
        blob = os.urandom(900)
        con.executemany("INSERT INTO bars VALUES (?,?,?,?)", ((i, "BTC", 1.0, blob) for i in range(12_000)))
        con.commit(); con.execute("PRAGMA wal_checkpoint(TRUNCATE)"); con.close()
        n_src = 12_000
        for name in BACKUP_NEBEN:
            c2 = sqlite3.connect(os.path.join(tmp, f"{name}.db")); c2.execute("CREATE TABLE t(x)"); c2.execute("INSERT INTO t VALUES (?)", (name,))
            c2.commit(); c2.close()

        def ordner(name):
            bdir = os.path.join(tmp, name)
            os.makedirs(bdir)
            for g, m in (("", "F0"), (".1", "F1"), (".2", "F2")):
                c3 = sqlite3.connect(os.path.join(bdir, BACKUP_NAME + g)); c3.execute("CREATE TABLE gen(m)"); c3.execute("INSERT INTO gen VALUES (?)", (m,))
                c3.execute("CREATE TABLE bars(x)"); c3.commit(); c3.close()
            _json_atomar(os.path.join(bdir, "backup.json"), {"ts": int(time.time()) - 25 * 3600, "ok": True, "size": 1})
            return bdir

        def kennung(path):
            if not os.path.exists(path):
                return "—"
            try:
                c4 = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
                try:
                    return c4.execute("SELECT m FROM gen").fetchone()[0]
                except sqlite3.Error:
                    n = c4.execute("SELECT COUNT(*) FROM bars").fetchone()[0]
                    return f"neu:{n}" if c4.execute("PRAGMA integrity_check").fetchone()[0] == "ok" else "kaputt"
                finally:
                    c4.close()
            except sqlite3.Error:
                return "unlesbar"

        def lauf(bdir, plan, toeten=None, leser=True):
            q = ctx.Queue()
            t0 = time.time()
            procs = {}
            ev, ende = [], {}
            json_fehler = [0, 0]
            halt = threading.Event()

            def lesen():                      # B6: backup.json jederzeit ganz
                while not halt.is_set():
                    try:
                        with open(os.path.join(bdir, "backup.json"), encoding="utf-8") as f:
                            json.load(f)
                        json_fehler[1] += 1
                    except ValueError:
                        json_fehler[0] += 1
                    except OSError:
                        pass
                    time.sleep(0.002)
            th = threading.Thread(target=lesen, daemon=True)
            if leser:
                th.start()
            for tag, verzug, lp, lk, warten, aelter in plan:
                pr = ctx.Process(target=_st_backup_worker, args=(tag, src, bdir, t0, verzug, lp, lk, warten, aelter, q,
                                                                 mutation == "sperre_aus"))
                pr.start(); procs[tag] = pr
            while any(pr.is_alive() for pr in procs.values()) or not q.empty():
                try:
                    e = q.get(timeout=0.1)
                except Exception:
                    e = None
                if e:
                    ev.append(e)
                    if e[1] == "ende":
                        ende[e[0]] = e[3]
                    if toeten and e[0] == toeten[0] and e[1] == toeten[1] and procs[e[0]].is_alive():
                        os.kill(procs[e[0]].pid, signal.SIGKILL)
                        ev.append((e[0], "getoetet", time.time() - t0))
                if time.time() - t0 > 120:
                    break
            for pr in procs.values():
                pr.join(5)
            halt.set()
            if leser:
                th.join(2)
            return ev, ende, json_fehler

        def reste(bdir):
            return [n for n in os.listdir(bdir) if _BACKUP_REST.match(n)]

        # B1: zwei Läufe ohne Warten, 0,3 s versetzt
        b = ordner("b1")
        ev, ende, jf = lauf(b, [("A", 0, 1.5, 0, 0, None), ("B", 0.3, 0, 0, 0, None)])
        oks = sorted(t for t, r in ende.items() if r.get("ok"))
        busy = sorted(t for t, r in ende.items() if r.get("busy"))
        gens = [kennung(os.path.join(b, BACKUP_NAME + g)) for g in ("", ".1", ".2")]
        pruef("B1 genau eine Kopie, der zweite Lauf meldet „läuft bereits“", oks == ["A"] and busy == ["B"], f"ok={oks} läuft-bereits={busy} {ende}")
        pruef("B1 Generationen einmal weitergeschoben, alte .2 entfernt (neu, F0, —)", gens == [f"neu:{n_src}", "F0", "—"], str(gens))
        pruef("B1 keine Zwischendatei bleibt liegen", not reste(b), str(reste(b)))
        st = backup_status(b) or {}
        pruef("B1 backup.json: ok vom kopierenden Lauf", st.get("ok") is True and st.get("bars") == n_src, str({k: st.get(k) for k in ("ok", "bars", "error")}))
        pruef("B6 backup.json während B1 immer ganz", jf[0] == 0 and jf[1] > 0, f"{jf[0]} halbe von {sum(jf)} Lesungen")
        if mutation == "sperre_aus":
            return ok_all

        # B2: wie update.py -- warten, dann übernehmen
        b = ordner("b2")
        ev, ende, jf = lauf(b, [("A", 0, 1.5, 0, 0, None), ("U", 0.3, 0, 0, 60, 24)])
        u = ende.get("U", {})
        gens = [kennung(os.path.join(b, BACKUP_NAME + g)) for g in ("", ".1", ".2")]
        pruef("B2 update.py wartet und übernimmt das frische Backup", ende.get("A", {}).get("ok") and u.get("ok") and u.get("frisch")
              and (u.get("gewartet_s") or 0) >= 0.5, str(ende))
        pruef("B2 keine zweite Kopie (eine Rotation: neu, F0, —)", gens == [f"neu:{n_src}", "F0", "—"], str(gens))
        pruef("B6 backup.json während B2 immer ganz", jf[0] == 0, f"{jf[0]} halbe von {sum(jf)}")

        # B3: warten ohne Altersgrenze -- zweite Kopie nach der ersten
        b = ordner("b3")
        ev, ende, jf = lauf(b, [("A", 0, 1.5, 0, 0, None), ("F", 0.3, 0, 0, 60, None)])
        gens = [kennung(os.path.join(b, BACKUP_NAME + g)) for g in ("", ".1", ".2")]
        t_a = next((e[2] for e in ev if e[0] == "A" and e[1] == "ende"), None)
        t_f = next((e[2] for e in ev if e[0] == "F" and e[1] == "pruefung"), None)
        pruef("B3 beide ok, die zweite Kopie beginnt erst nach dem Ende der ersten",
              ende.get("A", {}).get("ok") and ende.get("F", {}).get("ok") and t_a is not None and t_f is not None and t_f > t_a,
              f"Ende A {t_a and round(t_a, 2)} s, Prüfung F {t_f and round(t_f, 2)} s")
        pruef("B3 zwei Rotationen (neu, neu, —)", gens == [f"neu:{n_src}", f"neu:{n_src}", "—"], str(gens))
        pruef("B6 backup.json während B3 immer ganz", jf[0] == 0, f"{jf[0]} halbe von {sum(jf)}")

        # B4: Halter mitten in der Kopie hart beendet; danach ein neuer Lauf
        b = ordner("b4")
        ev, ende, jf = lauf(b, [("K", 0, 0, 0.02, 0, None)], toeten=("K", "kopie"))
        rest_k = reste(b)
        ev2, ende2, jf2 = lauf(b, [("N", 0, 0, 0, 0, None)])
        gens = [kennung(os.path.join(b, BACKUP_NAME + g)) for g in ("", ".1", ".2")]
        pruef("B4 Reste des getöteten Laufs lagen da", any(".tmp." in n for n in rest_k), str(rest_k))
        pruef("B4 Sperre sofort frei, neuer Lauf gelingt und räumt die Reste weg",
              ende2.get("N", {}).get("ok") and not ende2.get("N", {}).get("gewartet_s") and not reste(b), f"{ende2} Reste {reste(b)}")
        pruef("B4 Generationen: neu, F0, —", gens == [f"neu:{n_src}", "F0", "—"], str(gens))

        # B5: Altlasten -- alte Zwischendatei ohne PID plus heißes Journal einer fremden Datenbank
        b = ordner("b5")
        alt_tmp = os.path.join(b, BACKUP_NAME + ".tmp")
        c5 = sqlite3.connect(alt_tmp); c5.execute("CREATE TABLE fremd(x)"); c5.commit(); c5.close()
        with open(alt_tmp + "-journal", "wb") as f:
            f.write(b"\xd9\xd5\x05\xf9\x20\xa1\x63\xd7" + os.urandom(4000))
        with open(os.path.join(b, "backup.json.tmp.99999"), "w") as f:
            f.write('{"ts": 1, "ok": tr')
        ev, ende, jf = lauf(b, [("A", 0, 0, 0, 0, None)])
        pruef("B5 Altlasten entfernt, Kopie gelingt", ende.get("A", {}).get("ok") and not reste(b), f"{ende} Reste {reste(b)}")

        # B6 deterministisch: Abbruch mitten im Schreiben -- die alte backup.json bleibt ganz, keine Zwischendatei bleibt
        b6 = ordner("b6")
        orig_dump = json.dump

        def abbruch(obj, f, **k):
            f.write('{"ts": 1, "ok": tr'); f.flush()
            raise OSError("Platte voll (Test)")
        json.dump = abbruch
        try:
            try:
                _json_atomar(os.path.join(b6, "backup.json"), {"ok": True, "ts": 2, "size": 2})
            except OSError:
                pass
        finally:
            json.dump = orig_dump
        st6 = backup_status(b6)
        pruef("B6 Abbruch mitten im Schreiben: alte backup.json bleibt ganz, kein Rest", st6 is not None and st6.get("size") == 1
              and not reste(b6), f"{st6} Reste {reste(b6)}")

        def kurz7(r_):
            return str({k_: r_.get(k_) for k_ in ("ok", "error", "staking_db", "staking_db_error") if r_.get(k_) is not None})

        # B7: Nebendatenbanken
        st = backup_status(b) or {}
        nb = [n for n in BACKUP_NEBEN if st.get(f"{n}_db")]
        pruef("B7 Nebendatenbanken gesichert (forecasts, makro, aktien, ausblick; seit 23.76 notbremse, labor_a; seit 23.88 prognosemarkt; seit 23.90 volatil; seit 23.93 engine; seit 23.103 staking; seit 23.122 radar)", nb == list(BACKUP_NEBEN)
              and all(os.path.exists(os.path.join(b, f"{n}_backup.db")) for n in BACKUP_NEBEN)
              and BACKUP_NEBEN == ("forecasts", "makro", "aktien", "ausblick", "notbremse", "labor_a", "prognosemarkt", "volatil", "engine", "staking", "radar"),
              str(nb))
        pruef("B7 backup_dateien() kennt alle Backup-Dateien", set(backup_dateien(b)) >= {BACKUP_NAME, "backup.json"} | {f"{n}_backup.db" for n in BACKUP_NEBEN},
              str(backup_dateien(b)))

        # 23.103 (U257): Inhalt und voriger Stand der Nebendatenbanken; Muster für jeden Namen
        def inhalt7(p_):
            if not os.path.exists(p_):
                return None
            c_ = sqlite3.connect(f"file:{p_}?mode=ro", uri=True)
            try:
                return [r_[0] for r_ in c_.execute("SELECT x FROM t ORDER BY rowid")]
            except sqlite3.Error as e_:
                return [f"FEHLER {e_}"]
            finally:
                c_.close()
        b7 = os.path.join(tmp, "b7"); os.makedirs(b7)
        r7a = do_backup(src, b7, wer="Test B7.1", melden=lambda t: None)
        erst7 = {n: inhalt7(os.path.join(b7, f"{n}_backup.db")) for n in BACKUP_NEBEN}
        c7 = sqlite3.connect(os.path.join(tmp, "staking.db")); c7.execute("INSERT INTO t VALUES ('zweiter Tag')"); c7.commit(); c7.close()
        r7b = do_backup(src, b7, wer="Test B7.2", melden=lambda t: None)
        pruef("B7 Inhalt (23.103): Die Kopie jeder Nebendatenbank enthält, was in der Quelle steht -- nicht nur eine Datei mit ihrem Namen; "
              "staking.db ist dabei (eigene Tagesreihe aus dem Knoten, nicht neu ladbar)",
              bool(r7a.get("ok")) and erst7 == {n: [n] for n in BACKUP_NEBEN} and (r7a.get("staking_db") or 0) > 0
              and not [k_ for k_ in r7a if k_.endswith("_db_error")], f"{kurz7(r7a)} {erst7.get('staking')}")
        pruef("B7 voriger Stand (23.103): Nach dem zweiten Lauf trägt die Kopie den neuen Inhalt und .1 den vorigen -- für staking.db und "
              "die anderen",
              bool(r7b.get("ok")) and inhalt7(os.path.join(b7, "staking_backup.db")) == ["staking", "zweiter Tag"]
              and inhalt7(os.path.join(b7, "staking_backup.db.1")) == ["staking"]
              and all(inhalt7(os.path.join(b7, f"{n}_backup.db.1")) == [n] for n in BACKUP_NEBEN)
              and not os.path.exists(os.path.join(b7, "staking_backup.db.2")) and not reste(b7),
              f"neu {inhalt7(os.path.join(b7, 'staking_backup.db'))}, .1 {inhalt7(os.path.join(b7, 'staking_backup.db.1'))}")
        p_st7 = os.path.join(tmp, "staking.db")                              # Quelle beschädigen: zweite Seite (Tabelle t) unlesbar
        gut7 = open(p_st7, "rb").read()
        with open(p_st7, "r+b") as f_:
            f_.seek(4096); f_.write(bytes([255]) * 512)
        r7c = do_backup(src, b7, wer="Test B7.3", melden=lambda t: None)
        nach7 = (inhalt7(os.path.join(b7, "staking_backup.db")), inhalt7(os.path.join(b7, "staking_backup.db.1")))
        rest7c = reste(b7)
        with open(p_st7, "wb") as f_:
            f_.write(gut7)                                                   # Quelle wieder heil
        c7 = sqlite3.connect(p_st7)                                          # zweite Art: lesbar, aber in sich widersprüchlich (NULL in NOT NULL)
        c7.execute("CREATE TABLE u(a)"); c7.execute("INSERT INTO u VALUES (NULL)"); c7.commit()
        c7.execute("PRAGMA writable_schema=ON"); c7.execute("UPDATE sqlite_master SET sql='CREATE TABLE u(a NOT NULL)' WHERE name='u'")
        c7.commit(); c7.close()
        r7d = do_backup(src, b7, wer="Test B7.4", melden=lambda t: None)
        nach7d = (inhalt7(os.path.join(b7, "staking_backup.db")), inhalt7(os.path.join(b7, "staking_backup.db.1")))
        with open(p_st7, "wb") as f_:
            f_.write(gut7)                                                   # Quelle wieder heil für die folgenden Proben
        pruef("B7 beschädigte Nebendatenbank (23.103): Ist die Quelle unlesbar oder besteht ihre Kopie die Prüfung nicht, bleiben die "
              "gute Sicherung und ihr voriger Stand liegen; der Fehler steht im Ergebnis, die übrige Sicherung gelingt, keine "
              "Zwischendatei bleibt",
              len(gut7) == 8192 and bool(r7c.get("ok")) and bool(r7c.get("staking_db_error")) and "staking_db" not in r7c
              and nach7 == (["staking", "zweiter Tag"], ["staking"]) and rest7c == []
              and [k_ for k_ in r7c if k_.endswith("_db_error")] == ["staking_db_error"]
              and bool(r7d.get("ok")) and "NULL value in u.a" in str(r7d.get("staking_db_error")) and "staking_db" not in r7d
              and nach7d == (["staking", "zweiter Tag"], ["staking"]) and not reste(b7) and inhalt7(p_st7) == ["staking", "zweiter Tag"],
              f"unlesbar: {kurz7(r7c)}; widersprüchlich: {kurz7(r7d)}; Sicherung {nach7d}")
        for fremd in ("fremd_backup.db", "staking_backup.dbx", "xstaking_backup.db", "staking_backup.db.tmp.x", "stakingxbackup.db"):
            open(os.path.join(b7, fremd), "w").close()
        gel7 = backup_dateien(b7)
        open(os.path.join(b7, "staking_backup.db.tmp.4711-wal"), "w").close()
        pruef("B7 Muster (23.103): Anzeige, Umzug und Aufräumen kennen jede Nebendatenbank mit ihrem vorigen Stand und ihren "
              "Zwischendateien -- gebildet aus der einen Liste; fremde Dateien mit ähnlichem Namen gehören nicht dazu",
              set(gel7) - set(BACKUP_JSON) == {BACKUP_NAME, BACKUP_NAME + ".1", "backup.json"} | {f"{n}_backup.db{g_}" for n in BACKUP_NEBEN for g_ in ("", ".1")}
              and all(_BACKUP_REST.match(f"{n}_backup.db.tmp{z_}") for n in ("hl_liq",) + BACKUP_NEBEN for z_ in ("", ".4711", ".4711-wal", ".4711-shm", ".4711-journal"))
              and not _BACKUP_REST.match("fremd_backup.db.tmp.4711") and not _BACKUP_REST.match("staking_backup.db.tmp.x")
              and reste(b7) == ["staking_backup.db.tmp.4711-wal"] and "staking_backup.db.tmp.4711-wal" in backup_dateien(b7)
              and _BACKUP_NAMEN.split("|") == ["hl_liq"] + list(BACKUP_NEBEN), f"{len(gel7)} Dateien; Reste {reste(b7)}")

        def kurz(r_, schluessel=("ok", "kein_ziel", "error", "entfernt", "ausnahme")):
            return str({k_: r_.get(k_) for k_ in schluessel if r_.get(k_) is not None})

        # 23.95 (U243) B8: die alte .2 fällt VOR der Platzprüfung weg -- Platz reicht nur ohne sie
        b8 = ordner("b8")
        zwei8 = os.path.join(b8, BACKUP_NAME + ".2")
        echt_du = shutil.disk_usage

        def du_test(p_):
            r_ = echt_du(p_)
            return type(r_)(r_.total, r_.used, 0 if os.path.exists(zwei8) else r_.free)
        meld8: list = []
        fw8 = backup_freiwerdend(b8)                       # vor dem Lauf: genau die alte .2
        shutil.disk_usage = du_test
        try:
            r8 = do_backup(src, b8, wer="Test B8", melden=meld8.append)
        except Exception as e:
            r8 = {"ok": False, "ausnahme": f"{type(e).__name__}: {e}"}
        finally:
            shutil.disk_usage = echt_du
        gens = [kennung(os.path.join(b8, BACKUP_NAME + g)) for g in ("", ".1", ".2")]
        pruef("B8 alte .2 VOR der Platzprüfung entfernt (Platz reicht nur ohne sie), Kopie gelingt: neu, F0, —",
              r8.get("ok") and gens == [f"neu:{n_src}", "F0", "—"] and any(".2" in x for x in (r8.get("entfernt") or []))
              and any("ältere Stände entfernt" in m_ for m_ in meld8) and fw8 > 0 and backup_freiwerdend(b8) == 0,
              f"{kurz(r8)} {gens} frei werdend vorher {fw8} B, nachher {backup_freiwerdend(b8)} B")

        # B9: Ordner unter einem Ort für Laufwerke, das Laufwerk aber nicht eingehängt; Gegenprobe auf einem echten Einhängepunkt
        echt_w = BACKUP_MEDIEN_WURZELN
        medien = os.path.join(tmp, "medien")
        try:
            globals()["BACKUP_MEDIEN_WURZELN"] = (medien + "/",)
            try:
                r9 = do_backup(src, os.path.join(medien, "usb", "hl_backup"), wer="Test B9", melden=lambda t: None)
            except Exception as e:
                r9 = {"ok": False, "ausnahme": f"{type(e).__name__}: {e}"}
            pruef("B9 Laufwerk nicht eingehängt: kein Lauf, nichts angelegt (keine backup.json), keine Ausnahme, Grund im Ergebnis",
                  not r9.get("ok") and r9.get("kein_ziel") and "nicht eingehängt" in str(r9.get("error")) and "ausnahme" not in r9
                  and not os.path.exists(medien), f"{kurz(r9)} angelegt: {os.path.exists(medien)}")
            shm = "/dev/shm"
            if os.path.ismount(shm) and os.access(shm, os.W_OK):
                globals()["BACKUP_MEDIEN_WURZELN"] = (shm + "/",)
                b9g = os.path.join(shm, f"hl_selbsttest_{os.getpid()}")
                try:
                    r9g = do_backup(src, os.path.join(b9g, "usb"), wer="Test B9 Gegenprobe", melden=lambda t: None)
                except Exception as e:
                    r9g = {"ok": False, "ausnahme": f"{type(e).__name__}: {e}"}
                finally:
                    shutil.rmtree(b9g, ignore_errors=True)
                pruef("B9 Gegenprobe: Ordner auf einem eingehängten Laufwerk (/dev/shm als Ort für Laufwerke) -- Sicherung gelingt",
                      r9g.get("ok") and not r9g.get("kein_ziel"), kurz(r9g))
            else:
                print("  --     B9 Gegenprobe übersprungen (/dev/shm ist hier kein eigener, beschreibbarer Einhängepunkt)", flush=True)
        finally:
            globals()["BACKUP_MEDIEN_WURZELN"] = echt_w

        # B9: beim Wählen festgehaltener Einhängepunkt (speicherorte.json „mount“) -- fehlt er später, kein Lauf, auch außerhalb von
        # /media und /mnt (etwa ein Laufwerk unter /home); ist er da, gelingt die Sicherung
        b9c = os.path.join(tmp, "b9c", "hl_backup")
        sp9 = os.path.join(tmp, "speicherorte_b9.json")
        echt_sp9 = globals()["speicher_pfad"]
        try:
            globals()["speicher_pfad"] = lambda: sp9
            with open(sp9, "w", encoding="utf-8") as f:
                json.dump({"backup_dir": b9c, "mount": "/dev/shm/hl_nicht_da"}, f)
            r9c = do_backup(src, b9c, wer="Test B9c", melden=lambda t: None)
            angelegt9c = os.path.exists(os.path.join(tmp, "b9c"))
            with open(sp9, "w", encoding="utf-8") as f:
                json.dump({"backup_dir": b9c, "mount": medium_von(b9c)["mount"]}, f)
            r9d = do_backup(src, b9c, wer="Test B9d", melden=lambda t: None)
        except Exception as e:
            r9c = r9d = {"ok": False, "ausnahme": f"{type(e).__name__}: {e}"}; angelegt9c = None
        finally:
            globals()["speicher_pfad"] = echt_sp9
        pruef("B9 Einhängepunkt beim Wählen festgehalten: fehlt er, kein Lauf und nichts angelegt (auch außerhalb /media, /mnt); ist er da, gelingt die Sicherung",
              not r9c.get("ok") and r9c.get("kein_ziel") and "beim Wählen auf /dev/shm/hl_nicht_da" in str(r9c.get("error")) and angelegt9c is False
              and r9d.get("ok"), f"{kurz(r9c)} angelegt {angelegt9c} | {kurz(r9d)}")

        # B10: Ordner nicht anlegbar -- eine Datei steht im Weg
        datei = os.path.join(tmp, "eine_datei")
        with open(datei, "w") as f:
            f.write("x")
        try:
            r10 = do_backup(src, os.path.join(datei, "sub"), wer="Test B10", melden=lambda t: None)
        except Exception as e:
            r10 = {"ok": False, "ausnahme": f"{type(e).__name__}: {e}"}
        pruef("B10 Ordner nicht anlegbar: Fehler im Ergebnis statt Ausnahme (bis 23.94 stürzte die Aufgabe „Backup“ ab)",
              not r10.get("ok") and r10.get("kein_ziel") and "nicht anlegbar" in str(r10.get("error")) and "ausnahme" not in r10, kurz(r10))

        # B11: vier Läufe nacheinander -- nie mehr als zwei Stände, .1 ist jeweils die vorige Sicherung
        b11 = os.path.join(tmp, "b11"); f11 = os.path.join(b11, BACKUP_NAME)

        def marke(m_):
            c_ = sqlite3.connect(src)
            c_.execute("CREATE TABLE IF NOT EXISTS lauf(m)"); c_.execute("DELETE FROM lauf"); c_.execute("INSERT INTO lauf VALUES (?)", (m_,))
            c_.commit(); c_.close()

        def marke_von(p_):
            if not os.path.exists(p_):
                return "—"
            c_ = sqlite3.connect(f"file:{p_}?mode=ro", uri=True)
            try:
                return c_.execute("SELECT m FROM lauf").fetchone()[0]
            except sqlite3.Error:
                return "?"
            finally:
                c_.close()
        verlauf = []
        for k_ in range(1, 5):
            marke(f"L{k_}")
            r11 = do_backup(src, b11, wer=f"Test B11.{k_}", melden=lambda t: None)
            verlauf.append((bool(r11.get("ok")), marke_von(f11), marke_von(f11 + ".1"),
                            len([n for n in os.listdir(b11) if re.fullmatch(re.escape(BACKUP_NAME) + r"(\.\d)?", n)])))   # ohne -wal/-shm der Leser
        pruef("B11 vier Läufe: nie mehr als zwei Stände, .1 ist die vorige Sicherung",
              verlauf == [(True, "L1", "—", 1), (True, "L2", "L1", 2), (True, "L3", "L2", 2), (True, "L4", "L3", 2)], str(verlauf))
        g11 = backup_generationen(b11); bd = backup_bedarf(src)
        n_db = os.path.getsize(src); n_nb = sum(os.path.getsize(os.path.join(tmp, f"{n}.db")) for n in BACKUP_NEBEN)
        pruef("B11 backup_generationen: neu und .1; backup_bedarf: Lauf = DB × 1,1 + Neben, auf Dauer 2 × (DB + Neben) + Lauf",
              [g["name"] for g in g11] == [BACKUP_NAME, BACKUP_NAME + ".1"] and abs(bd["lauf"] - (n_db * 1.1 + n_nb)) < 1
              and abs(bd["dauer"] - (2 * (n_db + n_nb) + n_db * 1.1 + n_nb)) < 1, f"{[g['name'] for g in g11]} {bd}")

        # B12: backup_laeuft -- Halter der Sperre, danach nichts; die Probe gibt die Sperre wieder frei; legt keine Sperrdatei an
        b12 = os.path.join(tmp, "b12"); os.makedirs(b12)
        sp12 = BackupSperre(src, b12, "Test B12")
        gehalten = sp12.versuchen()
        try:
            l1 = backup_laeuft(src, b12)
        finally:
            sp12.freigeben()
        l2 = backup_laeuft(src, b12)
        sp12b = BackupSperre(src, b12, "Test B12b")
        wieder = sp12b.versuchen()
        sp12b.freigeben()
        ohne = os.path.join(tmp, "ohne_sperre.db")
        l3 = backup_laeuft(ohne)
        pruef("B12 backup_laeuft: Halter während der Sperre, danach nichts, Sperre danach frei; keine Sperrdatei angelegt",
              gehalten is True and l1 is not None and l1.get("wer") == "Test B12" and l2 is None and wieder is True and l3 is None
              and not os.path.exists(ohne + ".backup.lock"), f"{l1} | {l2} | {wieder} | {l3}")

        # B13: Schleife des Recorders (run_backup) mit geraffter Zeit (1 s Warten = 10 ms)
        import types
        import io
        import contextlib
        tA, tB, tC = (os.path.join(tmp, n) for n in ("b13_a", "b13_b", "b13_c"))
        tD = os.path.join(tmp, "medien13", "usb", "hl_backup")
        os.makedirs(tA)
        _json_atomar(os.path.join(tA, "backup.json"), {"ts": int(time.time()), "ok": True, "size": 1})   # frisch: am alten Ort kein Lauf
        sp_json = os.path.join(tmp, "speicherorte_b13.json")
        echt13 = {n: globals()[n] for n in ("speicher_pfad", "do_backup", "DB_PATH", "BACKUP_MEDIEN_WURZELN", "book_summary_verdichten_datei")}
        echt_sleep = asyncio.sleep
        beginn13: list = []
        aufrufe13: list = []

        def do_backup_langsam(db_, bdir_, *a, **k):
            t_a = time.time(); beginn13.append((bdir_, t_a)); time.sleep(0.8)
            r_ = echt13["do_backup"](db_, bdir_, *a, **k)
            aufrufe13.append((bdir_, t_a, time.time(), r_))
            return r_

        async def gerafft(d_, *a, **k):
            return await echt_sleep(0.01 if d_ >= 1 else d_)

        def schreib(d_):
            with open(sp_json + ".tmp", "w", encoding="utf-8") as f_:
                json.dump(d_, f_)
            os.replace(sp_json + ".tmp", sp_json)

        class _ConEinmalFehler:
            """In-Memory-Verbindung; das Eintragen von C in meta scheitert genau einmal (wie eine kurz gesperrte Datenbank)."""
            def __init__(self):
                self.con = sqlite3.connect(":memory:"); self.fehler = 0

            def execute(self, sql, *a):
                if sql.startswith("INSERT OR REPLACE INTO meta") and a and a[0] and a[0][0] == tC and not self.fehler:
                    self.fehler += 1
                    raise sqlite3.OperationalError("database is locked (Test)")
                return self.con.execute(sql, *a)

            def commit(self):
                return self.con.commit()
        fake = types.SimpleNamespace(cfg=types.SimpleNamespace(backup_dir=tA), con=_ConEinmalFehler(), jobs=[])
        fake.con.execute("CREATE TABLE meta(k TEXT PRIMARY KEY, v)")
        fake.note_job = lambda name, **k: fake.jobs.append((name, k))
        info13: dict = {}

        async def warte_bis(bed, frist):
            ende_ = time.time() + frist
            while time.time() < ende_ and not bed():
                await echt_sleep(0.02)
            return bed()

        async def szenario():
            fake.stop = asyncio.Event()
            task = asyncio.create_task(Recorder.run_backup(fake))
            await echt_sleep(0.3)
            schreib({"backup_dir": tB})
            info13["B_beginnt"] = await warte_bis(lambda: any(x[0] == tB for x in beginn13), 3)
            schreib({"backup_dir": tC})                                   # zweiter Wechsel WÄHREND der Sicherung in B
            info13["C_gesichert"] = await warte_bis(lambda: any(x[0] == tC for x in aufrufe13), 6)
            info13["meta_C"] = (fake.con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone() or [None])[0]
            ts_c = int((backup_status(tC) or {}).get("ts") or 0)           # Beginn der Sicherung in C (backup.json, ganze Sekunden)
            await warte_bis(lambda: int(time.time()) > ts_c, 3)            # „Jetzt sichern“ zählt nur, wenn später als sie
            schreib({"backup_dir": tC, "jetzt_ts": int(time.time())})        # „Jetzt sichern“
            info13["jetzt"] = await warte_bis(lambda: sum(1 for x in aufrufe13 if x[0] == tC) >= 2, 4)
            info13["meta_J"] = (fake.con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone() or [None])[0]
            globals()["BACKUP_MEDIEN_WURZELN"] = (os.path.join(tmp, "medien13") + "/",)
            schreib({"backup_dir": tD})                                   # Ziel unter einem Ort für Laufwerke, nicht eingehängt
            info13["D"] = await warte_bis(lambda: any(x[0] == tD for x in aufrufe13), 4)
            await echt_sleep(0.3)
            info13["lebt"] = not task.done()
            fake.stop.set()
            try:
                await asyncio.wait_for(task, 10)
            except Exception as e:
                info13["ende"] = f"{type(e).__name__}: {e}"
        log13 = io.StringIO()
        try:
            globals().update(speicher_pfad=lambda: sp_json, do_backup=do_backup_langsam, DB_PATH=src,
                             book_summary_verdichten_datei=lambda *a, **k: 0)
            asyncio.sleep = gerafft
            with contextlib.redirect_stdout(log13):
                asyncio.run(szenario())
        except Exception as e:
            info13["ausnahme"] = f"{type(e).__name__}: {e}"
        finally:
            asyncio.sleep = echt_sleep
            globals().update(echt13)
        ordner13 = [os.path.basename(x[0]) for x in aufrufe13]
        b_ende = next((x[2] for x in aufrufe13 if x[0] == tB), None)
        c_beginn = next((x[1] for x in aufrufe13 if x[0] == tC), None)
        luecke = (c_beginn - b_ende) if b_ende and c_beginn else None
        pruef("B13 neuer Pfad aus dem Dashboard binnen Sekunden übernommen und dort gesichert (am alten, frisch gesicherten Ort nicht)",
              info13.get("B_beginnt") and ordner13[:1] == ["b13_b"] and aufrufe13[0][3].get("ok"), f"Läufe {ordner13} {info13}")
        pruef("B13 Wechsel WÄHREND einer laufenden Sicherung gilt direkt danach (bis 23.94 erst nach 30 min)",
              info13.get("C_gesichert") and luecke is not None and luecke < 1.5, f"Lücke {luecke and round(luecke, 2)} s")
        pruef("B13 meta: scheitert das Eintragen des neuen Orts einmal, zieht der nächste Durchgang es nach (bis 23.94 erst nach einem Neustart)",
              fake.con.fehler == 1 and info13.get("meta_C") != tC and info13.get("meta_J") == tC,
              f"Fehler {fake.con.fehler}, nach C {info13.get('meta_C')}, nach „Jetzt sichern“ {info13.get('meta_J')}")
        pruef("B13 „Jetzt sichern“ startet einen Lauf am gültigen Ort", info13.get("jetzt") and ordner13[:3] == ["b13_b", "b13_c", "b13_c"]
              and all(x[3].get("ok") for x in aufrufe13[:3]), f"Läufe {ordner13}")
        r_d = next((x[3] for x in aufrufe13 if x[0] == tD), {})
        job_d = [k for n, k in fake.jobs if n == "Backup" and "nicht eingehängt" in str(k.get("info"))]
        pruef("B13 Ziel nicht eingehängt: Lauf bricht mit Grund ab, Zeitplan „Fehler … nicht eingehängt“, nächster Versuch in 30 min, "
              "Aufgabe lebt weiter, nichts angelegt",
              info13.get("D") and r_d.get("kein_ziel") and job_d and job_d[-1].get("ok") is False and job_d[-1].get("naechste") == 1800
              and info13.get("lebt") and "ausnahme" not in info13 and "ende" not in info13 and not os.path.exists(os.path.join(tmp, "medien13")),
              f"{kurz(r_d)} Zeitplan {job_d[-1:] if job_d else '—'} {info13}")
        print("     Protokoll der Schleife: " + " | ".join(z.strip() for z in log13.getvalue().splitlines() if "Backup" in z)[:600], flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"Backup-Selbsttest: {'bestanden' if ok_all else 'FEHLER'}", flush=True)
    return ok_all


def selbsttest_gewicht() -> bool:
    """
    23.38: API-Gewicht hart gedeckelt -- RateLimiter in VIRTUELLER Zeit (die Ereignisschleife springt statt zu schlafen) unter
    der Last vom 30.09.: Poller in Runden zu 23 Abfragen (Gewicht 2, Antwort 0,3–1,5 s, danach 0,3 s Schreiben), Wal-Orders
    9 × 20 je Minute, Leaderboard 78 × 2 je Minute (Rang 0), ein Fill-Lauf 40 × 22 (Rang 3). Soll: das gleitende 60-s-Fenster
    nie über dem Deckel (1.080, auch in der ersten Minute nach dem Start), Durchsatz mindestens 93 % davon, Rang 0 wartet
    höchstens 1 s, Orders und Fills werden bedient, keine Stillstände (Schwall/Sperre im Wechsel), die Anzeige
    (used_last_minute) stimmt mit dem Fenster überein; Temperaturschutz 0,7 -> Fenster höchstens 756. Kein Netz.
    """
    import selectors
    vt = [10_000.0]
    echt = time.monotonic

    class _VSel(selectors.DefaultSelector):
        def select(self, timeout=None):
            r = super().select(0)
            if not r and timeout and timeout > 0:
                vt[0] += timeout
            return r
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    time.monotonic = lambda: vt[0]
    try:
        async def lauf():
            L = RateLimiter(int(HL_WEIGHT_BUDGET * 0.90))
            log = []; rng = random.Random(5); t0 = time.monotonic(); ende = t0 + 600; anzeige = []

            async def req(w, prio):
                a = time.monotonic(); await L.acquire(w, prio); log.append((time.monotonic(), w, prio, time.monotonic() - a))

            async def eins():
                await req(2, 1); await asyncio.sleep(rng.uniform(0.3, 1.5))

            async def poller():
                while time.monotonic() < ende:
                    await asyncio.gather(*(eins() for _ in range(23))); await asyncio.sleep(0.3)

            async def takt(n, w, prio, pause, start=0.0):
                await asyncio.sleep(start)
                while time.monotonic() < ende:
                    a = time.monotonic()
                    for _ in range(n):
                        await req(w, prio); await asyncio.sleep(rng.uniform(0.05, 0.2))
                    await asyncio.sleep(max(1.0, pause - (time.monotonic() - a)))

            async def fills():
                await asyncio.sleep(180)
                for _ in range(40):
                    await req(22, 3); await asyncio.sleep(0.3)

            async def warm():                                          # Temperaturschutz ab Minute 8 (Übergang: das Fenster muss erst
                await asyncio.sleep(480); L.set_scale(0.7)              # unter den neuen Deckel fallen -- ein kurzer Stillstand ist gewollt)

            async def ablesen():
                while time.monotonic() < ende:
                    await asyncio.sleep(7.3); anzeige.append((time.monotonic(), L.used_last_minute()))
            await asyncio.gather(poller(), takt(9, 20, 1, 60), takt(78, 2, 0, 60, 2.0), fills(), warm(), ablesen())
            return t0, log, anzeige
        schleife = asyncio.SelectorEventLoop(_VSel())
        try:
            t0, log, anzeige = schleife.run_until_complete(lauf())
        finally:
            schleife.close()
    finally:
        time.monotonic = echt

    def fenster(t_bis):
        return sum(w for t, w, _, _ in log if t_bis - 60 <= t <= t_bis)
    dq = deque(); s_ = 0; mx_kalt = mx_warm = 0
    for t, w, _, _ in log:
        dq.append((t, w)); s_ += w
        while dq and dq[0][0] < t - 60:
            s_ -= dq.popleft()[1]
        if t < t0 + 480:
            mx_kalt = max(mx_kalt, s_)
        elif t >= t0 + 540:
            mx_warm = max(mx_warm, s_)
    erste = sum(w for t, w, _, _ in log if t <= t0 + 60)
    durch = sum(w for t, w, _, _ in log if t0 + 120 <= t < t0 + 480) / 6.0
    ok("Fenster nie über dem Deckel (1.080)", mx_kalt <= 1080, f"Maximum {mx_kalt} · erste Minute nach dem Start {erste} (vorher bis ~1.470)")
    ok("Durchsatz mindestens 93 % des Deckels", durch >= 0.93 * 1080, f"{durch:.0f} je Minute (Minute 2–8)")
    vor = [x for x in log if x[0] < t0 + 480]                          # bis zum Temperaturschutz
    w0 = [x[3] for x in vor if x[2] == 0]; w20 = [x for x in vor if x[1] == 20]; wf = [x for x in vor if x[2] == 3]
    ok("Rang 0 (Leaderboard) wartet höchstens 1 s", w0 and max(w0) <= 1.0, f"max {max(w0) if w0 else 0:.2f} s bei {len(w0)} Abfragen")
    ok("Orders (20) und Fills (22) werden bedient", len(w20) >= 58 and len(wf) == 40,
       f"Orders {len(w20)} von ~72, Fills {len(wf)} von 40, Wartezeit Orders max {max((x[3] for x in w20), default=0):.1f} s")
    sek = {int(x[0] - t0) for x in vor}
    luecke = max((b - a for a, b in zip(sorted(sek), sorted(sek)[1:])), default=0)
    ok("Keine Stillstände", luecke <= 3, f"längste Sekundenlücke ohne Vergabe {luecke} s")
    abw = max((abs(u - fenster(t)) for t, u in anzeige), default=0)
    ok("Anzeige = Fenster", abw <= 22, f"größte Abweichung {abw} (Ablesezeitpunkt zwischen zwei Vergaben)")
    ok("Temperaturschutz 0,7 -> höchstens 756", mx_warm <= 756, f"Fenster-Maximum ab Minute 9: {mx_warm}")
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- API-Gewicht hart gedeckelt (23.38), virtuelle Zeit, Last vom 30.09.")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<42} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_sperre_kleinfills() -> bool:
    """
    23.37: Masterregel zählt gespeicherte Fills nur ab lb_fills_min_usd -- ein Darwin-Konto mit 350 kleinen und 20 großen
    Bündeln in 24 h bleibt frei, eine Maschine mit 350 großen wird vorläufig ausgeschlossen. Einmalige Neubewertung der
    Sperren seit 29.09.: vorläufig wegen Kleinfills -> frei (mit Grund, in meta), vorläufig mit echten 320 großen Bündeln
    oder 350 Stream-Trades -> bleibt, eine Sperre vor dem 29.09. bleibt unberührt, zweiter Lauf ändert nichts.
    23.38: Ein Vielhandler, dessen Fills vor der Sperre schon gelöscht sind (Nachzählung 250, kein kleines Bündel), bleibt
    gesperrt; eine Freigabe im alten Stand ohne kleines Bündel wird einmalig zurückgenommen (Status, seit und Grund wie
    vorher, wieder in der Sperrmenge), eine mit kleinen Bündeln bleibt frei. Temporäre Datenbanken, kein Netz.
    """
    import tempfile
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_sperre_")
    pruef = []
    # 23.47 (U122): feste virtuelle Uhr -- der Test lief mit der echten Zeit, und seit dem 05.10. ist seine Sperre „vor dem
    # 29.09.“ älter als 7 Tage: die Zwei-Tage-Regel gibt sie (richtig) frei, die Erwartung „unberührt“ galt nur bis 04.10.
    # Mit fester Uhr rechnet der Test an jedem Tag gleich (Muster wie U34/U36). sperre_pruefen liest time.time() selbst.
    echte_zeit = time.time; t_start = echte_zeit()
    time.time = lambda: KLEINFILL_SEIT + 3 * 86_400 + 12 * 3600 + (echte_zeit() - t_start)

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        R.sperre_manuell = lambda: {}                                     # labels.json des Projekts spielt hier keine Rolle
        now = int(time.time())
        A = lambda i: "0x%040x" % (0x5e0000 + i)
        D, M, D2, M2, S, ALT, V = A(1), A(2), A(3), A(4), A(5), A(6), A(7)
        tid = [1]

        def fills(c_, a, n, usd, bis, markt="perp", coin="PUMP"):
            rows = []
            for i in range(n):
                tid[0] += 1; t = bis - 60 * (i + 1)
                rows.append((t, a, coin, markt, "Open Short", "A", 1.0, usd, usd, 0.0, 0.0, tid[0], 0))
            c_.executemany("INSERT OR IGNORE INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        fills(con, D, 350, 900.0, now); fills(con, D, 20, 5_000.0, now - 400 * 60)   # Darwin-Konto: viele kleine, wenige große
        fills(con, M, 350, 5_000.0, now)                                             # Maschine: 350 große Bündel
        seit = now - 3600
        fills(con, D2, 320, 800.0, seit); fills(con, D2, 10, 4_000.0, seit - 330 * 60)   # zu Unrecht vorläufig (Kleinfills)
        fills(con, M2, 320, 3_000.0, seit)                                           # zu Recht vorläufig (große)
        fills(con, V, 250, 3_000.0, seit)                                            # Vielhandler: 362 große, die ältesten 112 gelöscht
        con.execute("INSERT INTO fill_zaehler_h (addr, stunde, n, n_trades) VALUES (?,?,?,?)", (S, seit // 3600 * 3600, 900, 350))
        for a, st_ in ((D2, seit), (M2, seit), (S, seit), (ALT, KLEINFILL_SEIT - 86_400), (V, seit)):
            con.execute("INSERT OR REPLACE INTO konto_status VALUES (?,?,?,?,?,?,?)", (a, "vorlaeufig", "Tag 1: test", st_, "auto", 0.0, 330.0))
        con.commit()
        R.gesperrt = {D2, M2, S, ALT, V}
        R.sperre_pruefen()
        st = {a: s_ for a, s_ in con.execute("SELECT addr, status FROM konto_status")}
        ok("Darwin-Konto: Kleinfills zählen nicht", D not in st and D not in R.gesperrt, f"Status {st.get(D, 'frei')} (350 kleine + 20 große Bündel)")
        ok("Maschine: 350 große Bündel -> vorläufig", st.get(M) == "vorlaeufig", f"Status {st.get(M)}")
        erg = json.loads(con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0])
        frei = [e["addr"] for e in erg["frei"]]
        grund = con.execute("SELECT grund, quelle FROM konto_status WHERE addr=?", (D2,)).fetchone()
        ok("Neubewertung: zu Unrecht vorläufig -> frei", st.get(D2) == "frei" and frei == [D2] and D2 not in R.gesperrt and grund[1] == "kleinfill_neubewertung"
           and "Zählfehler" in grund[0], f"Status {st.get(D2)}, freigegeben {len(frei)}: {grund[0][:90]}…")
        ok("Neubewertung: echte Sperren bleiben", st.get(M2) == "vorlaeufig" and st.get(S) == "vorlaeufig" and st.get(ALT) == "vorlaeufig"
           and M2 in R.gesperrt and S in R.gesperrt, f"320 große Bündel {st.get(M2)}, 350 Stream-Trades {st.get(S)}, vor dem 29.09. {st.get(ALT)} (unberührt)")
        ok("23.38: Vielhandler ohne kleine Bündel bleibt", st.get(V) == "vorlaeufig" and V in R.gesperrt and erg.get("korrektur_ts")
           and not erg.get("zurueckgenommen"), f"Nachzählung 250 (Fills vor der Sperre gelöscht), 0 kleine Bündel: {st.get(V)}")
        vorher = con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0]
        con.execute("UPDATE konto_status SET status='vorlaeufig' WHERE addr=?", (D2,)); con.commit()
        R.sperre_pruefen()
        ok("Einmalig", con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0] == vorher
           and con.execute("SELECT status FROM konto_status WHERE addr=?", (D2,)).fetchone()[0] == "vorlaeufig", "zweiter Lauf prüft nicht erneut")
        con.close()
        # 23.38: Stand wie auf dem Pi nach 23.37 -- zwei Freigaben, eine ohne kleines Bündel (falsch), eine mit (richtig)
        DB_PATH = os.path.join(tmp, "k.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0))
        R.sperre_manuell = lambda: {}
        B, G = A(20), A(21)
        t_frei = now - 8 * 3600; seit_b = now - 30 * 3600
        alt_b = "Tag 1: 362 gebündelte Trades in 24 h (Masterregel > 300; 926 Fills) -- dauerhaft erst bei einem zweiten Tag binnen 7 Tagen"
        con.execute("INSERT INTO konto_status VALUES (?,?,?,?,?,?,?)", (B, "frei", f"freigegeben 23.37: 299 gebündelte Trades ... jetzt 290 -- vorher vorlaeufig: {alt_b}",
                                                                          t_frei, "kleinfill_neubewertung", 926.0, 299.0))
        con.execute("INSERT INTO konto_status VALUES (?,?,?,?,?,?,?)", (G, "frei", "freigegeben 23.37: 280 ... -- vorher vorlaeufig: Tag 1: 330 gebündelte Trades in 24 h",
                                                                          t_frei, "kleinfill_neubewertung", 500.0, 280.0))
        con.execute("INSERT INTO meta VALUES ('sperre_kleinfill_neubewertung', ?)", (json.dumps(
            {"ts": t_frei, "seit": KLEINFILL_SEIT, "geprueft": 20, "frei": [{"addr": B, "status": "vorlaeufig", "seit": seit_b, "dann": 299, "klein": 0, "jetzt": 290},
                                                                          {"addr": G, "status": "vorlaeufig", "seit": seit_b, "dann": 280, "klein": 45, "jetzt": 100}],
             "bleibt": []}),))
        con.commit()
        R.gesperrt = set()
        R.sperre_pruefen()
        rb = con.execute("SELECT status, seit, quelle, trades_tag, grund FROM konto_status WHERE addr=?", (B,)).fetchone()
        rg = con.execute("SELECT status, quelle FROM konto_status WHERE addr=?", (G,)).fetchone()
        erg = json.loads(con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0])
        ok("23.38: Freigabe ohne kleines Bündel zurückgenommen", rb[0] == "vorlaeufig" and rb[1] == seit_b and rb[2] == "auto" and rb[3] == 362.0
           and rb[4].startswith("Tag 1: 362") and "zurückgenommen" in rb[4] and B in R.gesperrt,
           f"{rb[0]} seit {'der ursprünglichen Sperre' if rb[1] == seit_b else rb[1]}, {rb[3]:.0f} Trades, Grund „…{rb[4][-60:]}“")
        ok("23.38: Freigabe mit kleinen Bündeln bleibt", rg == ("frei", "kleinfill_neubewertung") and G not in R.gesperrt
           and [e["addr"] for e in erg.get("frei") or []] == [G] and [e["addr"] for e in erg.get("zurueckgenommen") or []] == [B] and erg.get("korrektur_ts"),
           f"{rg[0]}; meta: frei {len(erg.get('frei') or [])}, zurückgenommen {len(erg.get('zurueckgenommen') or [])}")
        vorher = con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0]
        con.execute("UPDATE konto_status SET status='frei', quelle='kleinfill_neubewertung' WHERE addr=?", (B,)); con.commit()
        R.sperre_pruefen()
        ok("23.38: Rücknahme einmalig", con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()[0] == vorher
           and con.execute("SELECT status FROM konto_status WHERE addr=?", (B,)).fetchone()[0] == "frei", "zweiter Lauf nimmt nichts mehr zurück")
        con.close()
    finally:
        time.time = echte_zeit
        DB_PATH = alt_pfad
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Recorder -- Masterregel ohne Kleinfills, Neubewertung der Sperren seit 29.09. (23.37) und Rücknahme falscher Freigaben (23.38)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<48} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_audit_v10() -> bool:
    """
    23.75 (Audit v10 vom 22.10.): (H-1) Ohne --max-event-subs gilt die Einstellung 10 -- bis 23.74 überschrieb der Standard 600
    der Befehlszeile sie; mit leerer Darwin-Liste wählt die Rückfallregel höchstens 10 Konten, die größten zuerst, keine
    gesperrten. (M-3) Die Nacharbeit des Fill-Laufs misst jeden ihrer vier Schritte und rechnet dabei wie bisher. Temporäre
    Datenbank, kein Netz.
    """
    import tempfile, shutil
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_v10_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        a0 = parser_bauen().parse_args(["--db", os.path.join(tmp, "x.db")])
        a7 = parser_bauen().parse_args(["--max-event-subs", "7"])
        ok("H-1 Befehlszeile ohne Angabe -> 10", a0.max_event_subs is None and event_subs_aus(a0.max_event_subs) == 10 == Settings.max_event_subs,
           f"Standard {a0.max_event_subs!r} -> {event_subs_aus(a0.max_event_subs)}, Einstellung {Settings.max_event_subs}")
        ok("H-1 Befehlszeile mit Angabe gilt", event_subs_aus(a7.max_event_subs) == 7, f"--max-event-subs 7 -> {event_subs_aus(a7.max_event_subs)}")
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC"], af_tage=0, max_event_subs=event_subs_aus(a0.max_event_subs)))
        R.darwin_ziele = lambda: []
        R.sperre_manuell = lambda: {}
        A = lambda i: "0x%040x" % (0x7a0000 + i)
        R.positions = {A(i): [{"pos_value": 300_000.0 + i * 10_000}] for i in range(30)}
        R.gesperrt = {A(29)}
        R.update_event_subs()
        soll = {A(i) for i in range(19, 29)}
        n_sub = sum(1 for x in R.event_queue if x[0] == "subscribe")
        ok("H-1 Rückfall: 10 größte, ohne Gesperrte", R.event_subs == soll and n_sub == 10,
           f"{len(R.event_subs)} Abos, {n_sub} subscribe; erwartet die 10 größten ohne das gesperrte")
        now = int(time.time())
        rows = [(now - 3600 - k * 60, A(1), "BTC", "perp", "Open Long", "B", 100.0, 50.0, 5000.0, 0.0, 1.0, 1000 + k, 1) for k in range(20)]
        con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows); con.commit()
        R.fill_konten = {A(1)}
        R.fill_nacharbeit(now)
        fs = R.stats.get("fill_scans", {})
        ok("M-3 Nacharbeit misst vier Schritte", set(fs) == {"verdichten", "sperre", "loeschen", "vielhandler"}
           and all(v["n"] == 1 and 0 <= v["letzt"] <= v["max"] for v in fs.values()), json.dumps(fs))
        R.fill_nacharbeit(now)
        ok("M-3 zweiter Lauf zählt weiter", all(v["n"] == 2 for v in R.stats["fill_scans"].values()),
           " · ".join(f"{k} n {v['n']}" for k, v in R.stats["fill_scans"].items()))
        n_ph = con.execute("SELECT COUNT(*) FROM pool_fills_hourly").fetchone()[0]
        ok("M-3 rechnet wie bisher (Stundenaggregat)", n_ph >= 1, f"{n_ph} Zeilen pool_fills_hourly")
        import inspect
        quelle = inspect.getsource(Recorder.leaderboard_activity)
        quelle_mod = open(os.path.abspath(__file__), encoding="utf-8").read()
        s1_ = '("fill_scans", json.dumps(self.stats.get("fill_scans", {})))'; s2_ = '("event_subs_info", json.dumps({"n": self.stats.get("event_subs", 0)'
        ok("Meta für den Vollbericht (fill_scans, event_subs_info)", quelle_mod.count(s1_) == 2 and quelle_mod.count(s2_) == 2,
           "beide Schlüssel in der Meta-Liste (je einmal dort, einmal in dieser Probe)")
        ok("M-3 Fill-Lauf ruft die Nacharbeit", quelle.count("self.fill_nacharbeit(now)") == 1 and "self.sperre_pruefen()" not in quelle,
           "leaderboard_activity -> fill_nacharbeit(now), Sperre nur noch dort")
        con.close()
    except Exception as e:
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Recorder -- Audit v10 vom 22.10. (23.75): Abo-Grenze ohne Befehlszeile, Messung der Fill-Nacharbeit")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<48} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_impact() -> bool:
    """
    23.96 (U246): Impact-Preise der Börse. (1) impact_aus nimmt nur ein Paar endlicher, positiver Zahlen; (2) on_ctx und flush_ctx
    schreiben je Minute eine Zeile impact_bars (Mitte, Geld, Brief) und ctx_bars wie bisher mit acht Spalten; (3) fehlt das Feld,
    steht die Zeile mit NULL da; (4) HIP-3-Symbol („felix:XMR“) landet unter dem Coin; (5) eine ältere Datenbank ohne die Tabelle
    bekommt sie beim Öffnen; (6) scheitert das Schreiben der neuen Tabelle, bleibt ctx_bars vollständig und der Zähler zeigt es.
    Temporäre Datenbank, kein Netz.
    """
    import tempfile, shutil
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_impact_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        faelle = [(["99.9", "100.1"], (99.9, 100.1)), ([99.9, 100.1], (99.9, 100.1)), (None, (None, None)), ([], (None, None)),
                  (["99.9"], (None, None)), (["x", "100.1"], (None, None)), ([None, "100.1"], (None, None)), (["0", "100.1"], (None, None)),
                  (["-1", "100.1"], (None, None)), (["nan", "100.1"], (None, None)), (["inf", "100.1"], (None, None)),
                  ("99.9,100.1", (None, None)), (["99.9", "100.1", "100.2"], (None, None))]
        falsch = [(r_, impact_aus(r_)) for r_, soll in faelle if impact_aus(r_) != soll]
        ok("impact_aus: nur ein Paar positiver Zahlen", not falsch, f"{len(faelle)} Fälle" + (f", falsch: {falsch}" if falsch else ""))
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC", "XMR"], af_tage=0))
        R.symbol_of = {"BTC": "BTC", "XMR": "felix:XMR"}; R.coin_of = {"BTC": "BTC", "felix:XMR": "XMR"}; R.dex_of = {"BTC": "", "XMR": "felix"}
        ctx = lambda mid, imp=...: dict({"markPx": str(mid), "oraclePx": str(mid * 1.0001), "midPx": str(mid), "funding": "0.0000125",
                                         "openInterest": "1234.5", "premium": "0.0002"}, **({} if imp is ... else {"impactPxs": imp}))
        R.on_ctx({"coin": "BTC", "ctx": ctx(100.0, ["99.5", "100.7"])})
        R.on_ctx({"coin": "BTC", "ctx": ctx(100.0, ["99.9", "100.2"])})          # letzter Wert der Minute gewinnt
        R.on_ctx({"coin": "felix:XMR", "ctx": ctx(350.0)})                       # Feld fehlt
        ok("on_ctx legt Geld/Brief in den Minutenwert", (R.ctx["BTC"].get("ibid"), R.ctx["BTC"].get("iask")) == (99.9, 100.2)
           and (R.ctx["XMR"].get("ibid"), R.ctx["XMR"].get("iask")) == (None, None), f"BTC {R.ctx['BTC'].get('ibid')}/{R.ctx['BTC'].get('iask')}, "
           f"XMR {R.ctx['XMR'].get('ibid')}/{R.ctx['XMR'].get('iask')}")
        R.flush_ctx(final=True); con.commit()
        z = con.execute("SELECT coin, mid_px, impact_bid, impact_ask FROM impact_bars ORDER BY coin").fetchall()
        ok("impact_bars: eine Zeile je Minute und Coin", z == [("BTC", 100.0, 99.9, 100.2), ("XMR", 350.0, None, None)], f"{z}")
        c8 = con.execute("SELECT * FROM ctx_bars ORDER BY coin").fetchall()
        ok("ctx_bars wie bisher (acht Spalten, gleiche Werte)", len(c8) == 2 and all(len(r) == 8 for r in c8)
           and c8[0][1:] == ("BTC", 100.0, 100.0 * 1.0001, 100.0, 0.0000125, 1234.5, 0.0002)
           and [r[1] for r in con.execute("PRAGMA table_info(ctx_bars)")] == ["ts", "coin", "mark_px", "oracle_px", "mid_px", "funding", "oi", "premium"],
           f"{len(c8)} Zeilen, Spalten {len(c8[0]) if c8 else 0}")
        ok("Zwischenspeicher geleert, kein Fehlerzähler", not R.ctx_pending and R.stats.get("impact_fehler", 0) == 0,
           f"offen {len(R.ctx_pending)}, impact_fehler {R.stats.get('impact_fehler', 0)}")
        # (6) Schreiben der neuen Tabelle scheitert -> ctx_bars bleibt vollständig
        con.execute("DROP TABLE impact_bars"); con.commit()
        con.execute("DELETE FROM ctx_bars"); con.commit()
        R.on_ctx({"coin": "BTC", "ctx": ctx(101.0, ["100.9", "101.1"])})
        R.flush_ctx(final=True); con.commit()
        n8 = con.execute("SELECT COUNT(*) FROM ctx_bars").fetchone()[0]
        ok("Fehler der neuen Tabelle kostet ctx_bars nichts", n8 == 1 and R.stats.get("impact_fehler", 0) == 1 and not R.ctx_pending,
           f"ctx_bars {n8} Zeile, impact_fehler {R.stats.get('impact_fehler', 0)}")
        con.close()
        # (5) ältere Datenbank ohne die Tabelle: beim Öffnen angelegt, Daten bleiben
        con = db_connect(DB_PATH)
        da = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='impact_bars'").fetchone()[0]
        ok("ältere Datenbank bekommt die Tabelle beim Öffnen", da == 1 and con.execute("SELECT COUNT(*) FROM ctx_bars").fetchone()[0] == 1,
           f"impact_bars vorhanden: {bool(da)}, ctx_bars unverändert")
        con.close()
    except Exception as e:
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Recorder -- Impact-Preise der Börse je Minute (23.96, U246)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_ausgelassen() -> bool:
    """
    23.112 (U272): Größe der wegen Alters ausgelassenen Positionen. (1) ausgelassen_zaehlen von Hand: Anzahl aller, Größe und USD nur mit
    Liquidationspreis, Betrag bei Shorts, USD aus pos_value; (2) ausgelassen_json: eingestellte Coins einzeln (auch mit 0), übrige
    zusammen ohne Größe; (3) write_snapshot mit echtem Recorder: frische Positionen im Stand und in der Abdeckung, alte nur im Meta-Wert
    -- Alter nach der letzten ERFOLGREICHEN Abfrage, Summe der Anzahlen = n_stale_dropped; der Stand selbst (heatmap, coverage,
    snapshot_meta) wie zuvor; (4) der nächste Stand ersetzt den Wert. Temporäre Datenbank, kein Netz.
    """
    import tempfile
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_ausgelassen_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    P = lambda coin, size, liq, pv: {"coin": coin, "size": size, "liq_px": liq, "notional": abs(size) * liq, "side": "long" if size > 0 else "short",
                                     "lev": 5.0, "entry": liq * 1.2, "pos_value": pv, "upnl": 0.0, "cross": True}
    try:
        a = {}
        ausgelassen_zaehlen(a, [P("BTC", -3.0, 70_000.0, 180_000.0), P("BTC", 1.5, 40_000.0, 90_000.0), P("ETH", 10.0, 1_500.0, 20_000.0),
                                {"coin": "BTC", "size": 4.0, "liq_px": 0.0, "pos_value": 5.0}, P("SOL", 100.0, 20.0, 15_000.0)])
        ok("Zählung von Hand: alle zählen, Größe und USD nur mit Liquidationspreis, Short als Betrag", a == {"BTC": [3, 4.5, 270_000.0],
           "ETH": [1, 10.0, 20_000.0], "SOL": [1, 100.0, 15_000.0]}, f"{a}")
        ausgelassen_zaehlen(a, [P("ETH", -2.0, 2_500.0, 4_000.0)])
        ok("Zählung sammelt über mehrere Konten", a["ETH"] == [2, 12.0, 24_000.0] and a["BTC"] == [3, 4.5, 270_000.0], f"ETH {a['ETH']}")
        j = json.loads(ausgelassen_json(a, 1234, 3600, ["ETH", "BTC", "XMR"]))
        ok("Meta-Wert: eingestellte Coins einzeln (auch mit 0), übrige zusammen ohne Größe", j == {"ts": 1234, "max_alter": 3600, "coins": {
           "BTC": {"n": 3, "groesse": 4.5, "usd": 270_000.0}, "ETH": {"n": 2, "groesse": 12.0, "usd": 24_000.0},
           "XMR": {"n": 0, "groesse": 0.0, "usd": 0.0}, AUSGELASSEN_REST: {"n": 1, "groesse": None, "usd": 15_000.0}}}, f"{j['coins']}")
        j0 = json.loads(ausgelassen_json({}, 5, 3600, ["BTC"]))
        ok("Meta-Wert ohne Ausgelassene: Nullen, kein „übrige“", j0["coins"] == {"BTC": {"n": 0, "groesse": 0.0, "usd": 0.0}}, f"{j0['coins']}")
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        R = Recorder(con, Settings(coins=["BTC", "ETH"], af_tage=0))
        R.symbol_of = {"BTC": "BTC", "ETH": "ETH"}; R.coin_of = {"BTC": "BTC", "ETH": "ETH"}; R.dex_of = {"BTC": "", "ETH": ""}
        R.ctx = {"BTC": {"oi": 100.0}, "ETH": {"oi": 1000.0}}
        now = int(time.time())
        # a frisch; b alt nach der letzten ERFOLGREICHEN Abfrage (ein späterer Fehlversuch hat polled_at erneuert); c alt, nur polled_at
        R.positions = {"a": [P("BTC", 2.0, 50_000.0, 120_000.0)],
                       "b": [P("BTC", -3.0, 70_000.0, 180_000.0), P("ETH", 10.0, 1_500.0, 20_000.0), P("SOL", 100.0, 20.0, 15_000.0)],
                       "c": [P("BTC", 1.5, 40_000.0, 90_000.0)]}
        R.erfolg_at = {"a": now - 100, "b": now - 4000}; R.polled_at = {"a": now - 100, "b": now - 50, "c": now - 9000}
        R.write_snapshot()
        r = con.execute("SELECT v FROM meta WHERE k='ausgelassen'").fetchone()
        j = json.loads(r[0]) if r else {}
        sm = con.execute("SELECT ts, n_positions, n_stale_dropped FROM snapshot_meta ORDER BY ts DESC LIMIT 1").fetchone()
        ok("write_snapshot schreibt den Meta-Wert: alte Positionen je Coin, frische nicht", (j.get("coins") or {}) == {
           "BTC": {"n": 2, "groesse": 4.5, "usd": 270_000.0}, "ETH": {"n": 1, "groesse": 10.0, "usd": 20_000.0},
           AUSGELASSEN_REST: {"n": 1, "groesse": None, "usd": 15_000.0}} and j.get("max_alter") == R.cfg.max_pos_age, f"{j.get('coins')}")
        ok("Zeit des Meta-Werts = Zeit des Standes, Summe der Anzahlen = n_stale_dropped", bool(sm) and j.get("ts") == sm[0] and sm[1] == 1
           and sm[2] == 4 == sum(e["n"] for e in j["coins"].values()), f"snapshot_meta {sm}, Meta-Wert ts {j.get('ts')}")
        cov = dict((c, (tr, ra)) for c, tr, ra in con.execute("SELECT coin, tracked_size, ratio FROM coverage"))
        hm = con.execute("SELECT coin, side, notional, n_pos FROM heatmap").fetchall()
        ok("Stand selbst unverändert: nur die frische Position in Heatmap und Abdeckung", cov == {"BTC": (2.0, 0.01), "ETH": (0.0, 0.0)}
           and hm == [("BTC", "long", 100_000.0, 1)], f"coverage {cov}, heatmap {hm}")
        R.erfolg_at["b"] = int(time.time())                                      # b wird wieder frisch -> nur noch c ist alt
        R.write_snapshot()
        j2 = json.loads(con.execute("SELECT v FROM meta WHERE k='ausgelassen'").fetchone()[0])
        n_meta = con.execute("SELECT COUNT(*) FROM meta WHERE k='ausgelassen'").fetchone()[0]
        ok("Nächster Stand ersetzt den Wert (ein Eintrag, keine Reste)", n_meta == 1 and j2["coins"] == {"BTC": {"n": 1, "groesse": 1.5, "usd": 90_000.0},
           "ETH": {"n": 0, "groesse": 0.0, "usd": 0.0}}, f"{j2['coins']}")
        con.close()
    except Exception as e:
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Recorder -- Größe der wegen Alters ausgelassenen Positionen (23.112, U272)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_symbole() -> bool:
    """
    23.97 (U250): Zuordnung der Symbole für andere Dienste. (1) resolve_symbols mit nachgebauter Börse (XMR nur auf dem HIP-3-Dex
    „hyna“) legt meta['symbole'] ab; (2) die Notbremse liest daraus genau diesen Markt (Vertrag zwischen Schreiber und Leser);
    (3) ist die Börse beim Start nicht erreichbar, bleibt die vorige Zuordnung stehen; (4) ein Schreibfehler wirft nicht.
    Temporäre Datenbank, kein Netz.
    """
    import tempfile, shutil, io, contextlib
    global DB_PATH
    alt_pfad = DB_PATH
    tmp = tempfile.mkdtemp(prefix="hl_rec_symbole_")
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    try:
        DB_PATH = os.path.join(tmp, "t.db")
        con = db_connect(DB_PATH)
        welt = {"da": True}
        abrufe = []

        async def post(body, weighted=True):
            abrufe.append(dict(body))
            if not welt["da"]:
                return None
            typ, dx = body.get("type"), body.get("dex")
            if typ == "meta" and not dx:
                return {"universe": [{"name": "BTC"}, {"name": "ETH"}, {"name": "SOL"}]}
            if typ == "perpDexs":
                return [None, {"name": "xyz"}, {"name": "hyna"}]
            if typ == "meta" and dx == "hyna":
                return {"universe": [{"name": "hyna:XMR"}]}
            if typ == "meta":
                return {"universe": []}
            return None

        def lauf():
            R = Recorder(con, Settings(coins=["BTC", "XMR"], af_tage=0))
            R.post = post
            with contextlib.redirect_stdout(io.StringIO()):
                asyncio.run(R.resolve_symbols())
            return R
        R = lauf()
        z = con.execute("SELECT v FROM meta WHERE k='symbole'").fetchone()
        d = json.loads(z[0]) if z else {}
        ok("Zuordnung nach dem Start abgelegt", R.symbol_of == {"BTC": "BTC", "XMR": "hyna:XMR"}
           and d.get("coins") == {"BTC": {"symbol": "BTC", "dex": ""}, "XMR": {"symbol": "hyna:XMR", "dex": "hyna"}} and isinstance(d.get("ts"), int),
           f"{d.get('coins')}")
        import hl_notbremse as NB
        D = NB.Dienst(DB_PATH, nb=os.path.join(tmp, "nb.db"), http=lambda b_: (None, "kein Netz", None), log=lambda s_: None,
                      termine_datei=os.path.join(tmp, "termine.json"))
        gelesen = D.dex_aus_recorder()
        D.con.close()
        ok("Die Notbremse liest daraus denselben Markt", gelesen == ({"XMR": ("hyna", "hyna:XMR")}, True), f"{gelesen}")
        ts1 = d.get("ts")
        con.execute("UPDATE meta SET v=? WHERE k='symbole'", (json.dumps(dict(d, ts=12345)),)); con.commit()
        welt["da"] = False
        R2 = lauf()
        d2 = json.loads(con.execute("SELECT v FROM meta WHERE k='symbole'").fetchone()[0])
        ok("Börse beim Start nicht erreichbar: vorige Zuordnung bleibt", R2.symbol_of == {} and d2.get("ts") == 12345 and d2.get("coins") == d.get("coins"),
           f"Symbole dieses Starts {R2.symbol_of}, abgelegt weiter {sorted(d2.get('coins') or {})} (ts {d2.get('ts')}, vorher {ts1})")
        leer = sqlite3.connect(":memory:")                                     # ohne Tabelle meta: Schreibfehler
        ok("Schreibfehler wirft nicht", symbole_ablegen(leer, {"BTC": "BTC"}, {"BTC": ""}) is False and symbole_ablegen(con, {}, {}) is False
           and symbole_ablegen(con, {"XMR": "hyna:XMR"}, {"hyna:XMR": "hyna"}, jetzt=777) is True
           and json.loads(con.execute("SELECT v FROM meta WHERE k='symbole'").fetchone()[0]) == {"ts": 777, "coins": {"XMR": {"symbol": "hyna:XMR", "dex": "hyna"}}},
           "ohne Tabelle False, leere Zuordnung False, sonst geschrieben")
        leer.close(); con.close()
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} {traceback.format_exc()[-300:]}")
    finally:
        DB_PATH = alt_pfad
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Recorder -- Zuordnung der Symbole für andere Dienste (23.97, U250)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<52} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def selbsttest_poller_u220() -> bool:
    """
    23.86 (U220, Entscheidung Nutzer 26.10.): Auswahl des Pollers, ohne Netz, Uhr und Datenbank nachgebaut.
      P1  Gesperrte Konten werden nie gewählt -- mit Position und weit überfällig, und nie abgefragte (bis 23.85: Rang 2 alle 6 h,
          nie abgefragte über Gruppe B)
      P2  „groß“ erst ab 500.000 USD: 600.000 nach 3 min fällig, 300.000 erst nach 30 min
      P3  kleine Konten nur nach eigenem Handel (Gruppe C) oder nach einem Tag; ohne Handel auch nach 3 h nicht; mit
          klein_nach_handel=False wieder in Gruppe A nach 2 h
      P4  Elite (Wal-Takt, auch ohne Position) und Pool (10 min) wie bisher; Rang 0 vor Rang 1; Zählung je Stufe
      P5  Statuszeile: Auslastung = Bedarf von Rang 0 und 1 gegen eingestellte Rate × Anteil der Runde -- gleich der Formel des Berichts
          (check_system.poller_modell mit denselben Konten); „überfällig“ = Gruppe A, „neu“ = Gruppe B ohne Gesperrte
      P6  Befehlszeile: --hot-notional 500.000, --klein-regelmaessig aus; mit Schalter an
      P7  Simulation 2 h unter Überlast: gesperrte 0 Abfragen; jedes kleine Konto mit Handel binnen 2 Runden abgefragt, kleine ohne Handel
          gar nicht; nie ein kleines Konto in Gruppe A
      P8  Vorrang (Durchsicht 26.10.): leere und kleine Konten mit mindestens 25.000 USD Handel seit der letzten Abfrage kommen in Gruppe A
          vor alle fälligen Konten von Rang 1; darunter, ohne Handel seit der Abfrage oder mit vorrang_usd = 0 nicht; der Trade-Feed
          summiert den Umsatz (seen_address), eine erfolgreiche Abfrage setzt ihn zurück
      P9  Gruppe C voll (viele kleine Händler, 3 Auslöser je Sekunde): jede leere Adresse, die mit einem Handel eine große Position
          eröffnet, binnen 2 Runden abgefragt -- ohne Vorrang nicht (Gegenprobe)
      P10 Fehlgeschlagene Abfrage: Pause (verdoppelt), der Handel seit der letzten Abfrage bleibt Auslöser (leere und kleine Konten, auch
          nach 2 h) -- nach 3 Fehlschlägen nicht mehr und ohne Vorrang; ein Wal ist nach 30 s wieder dran
      P11 Abstände je Stufe gemessen (volle Stunde in meta), Lücke und angebrochene erste Stunde ergeben keine; Gesperrte ohne Wal-Punkt
      P12 Erfolgreiche Abfrage durch poll_address: Umsatz und Fehlschläge zurück, Abstand von Erfolg zu Erfolg mit der Stufe vor der Abfrage
      P8b Drosselung (10 je Runde): vorgezogene Adresse über C statt gar nicht, keine doppelt
    """
    import types
    global time
    echte_zeit = time
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    T = [1_800_000_000]
    try:
        time = types.SimpleNamespace(time=lambda: T[0], sleep=echte_zeit.sleep, monotonic=echte_zeit.monotonic)

        def rec(klein_nach_handel=True, vorrang_usd=25_000):
            cfg = Settings(coins=["BTC"], klein_nach_handel=klein_nach_handel, vorrang_usd=vorrang_usd)
            R = types.SimpleNamespace(cfg=cfg, interval_factor=1.0, addr_meta={}, gesperrt=set(), pool_addrs=set(), stats={},
                                      elite_addrs=set(), addr_umsatz={}, poll_fehler={}, erfolg_at={})
            R.lade_elite = lambda: None
            return R
        t0 = T[0]
        konten = {   # addr: (last_poll, Positionswert, last_trade in ms, Sonderstufe)
            "w1": (t0 - 120, 30e6, 0, None), "e1": (t0 - 120, 0.0, 0, "Elite"), "g1": (t0 - 30 * 86_400, 1e6, (t0 - 10) * 1000, "gesperrt"),
            "g2": (0, 0.0, (t0 - 10) * 1000, "gesperrt"), "h1": (t0 - 200, 600e3, 0, None), "m1": (t0 - 200, 300e3, 0, None),
            "m2": (t0 - 1900, 300e3, 0, None), "k1": (t0 - 3 * 3600, 5e3, (t0 - 4 * 3600) * 1000, None),
            "k2": (t0 - 3 * 3600, 5e3, (t0 - 60) * 1000, None), "k3": (t0 - 25 * 3600, 5e3, 0, None), "p1": (t0 - 700, 100e3, 0, "Pool"),
            "x1": (t0 - 3600, 0.0, (t0 - 30) * 1000, None), "n1": (0, 0.0, (t0 - 5) * 1000, None)}

        def fuellen(R):
            for a_, (lp, pv, lt, so) in konten.items():
                R.addr_meta[a_] = [lp, pv, lt, (t0 - 86_400) * 1000]
                if so == "Elite":
                    R.elite_addrs.add(a_)
                elif so == "Pool":
                    R.pool_addrs.add(a_)
                elif so == "gesperrt":
                    R.gesperrt.add(a_)
            return R
        R = fuellen(rec())
        alle = set(Recorder.due_addresses(R, 100))
        ok("P1 Gesperrte nie (mit Position, nie abgefragt)", not ({"g1", "g2"} & alle), f"gewählt {sorted(alle)}")
        ok("P2 groß ab 500.000: 600 Tsd nach 3 min, 300 Tsd erst nach 30 min", {"h1", "m2"} <= alle and "m1" not in alle,
           f"h1 {'h1' in alle}, m1 {'m1' in alle}, m2 {'m2' in alle}")
        ok("P3 kleine nur nach eigenem Handel oder nach einem Tag", {"k2", "k3", "x1"} <= alle and "k1" not in alle
           and R.stats["due_pools"] == (5, 1, 3), f"k1 {'k1' in alle}, k2 {'k2' in alle}, k3 {'k3' in alle}; Gruppen {R.stats['due_pools']}")
        st_ = R.stats["poller_stufen"]
        ok("P4 Elite, Pool, Wal gewählt; Zählung je Stufe", {"w1", "e1", "p1", "n1"} <= alle
           and st_ == {"Wale": 1, "Elite": 1, "Pool": 1, "groß": 1, "mittel": 2, "klein": 3, "gesperrt": 2}, json.dumps(st_, ensure_ascii=False))
        klein10 = Recorder.due_addresses(fuellen(rec()), 10)       # 6 A + 2 B + 2 C: Rang 0 vor Rang 1 (nach Überfälligkeit), dann B, dann C
        ok("P4 Reihenfolge: Rang 0 (Elite, Wal) vor Rang 1 (Pool 1,17, groß 1,11, mittel 1,06), dann nie abgefragt, dann C nach Handelszeit",
           klein10[:6] == ["e1", "w1", "p1", "h1", "m2", "n1"] and klein10[6:8] == ["x1", "k2"], f"{klein10}")
        R2 = fuellen(rec(klein_nach_handel=False))
        alle2 = set(Recorder.due_addresses(R2, 100))
        ok("P3 mit klein_nach_handel=False: kleine wieder nach 2 h in Gruppe A", {"k1", "k2", "k3"} <= alle2 and R2.stats["due_pools"][0] == 8,
           f"Gruppen {R2.stats['due_pools']}")
        # P5: Statuszeile gegen die Formel des Berichts
        R.con = sqlite3.connect(":memory:")
        R.con.execute("CREATE TABLE addresses (addr TEXT, notional REAL, last_poll INTEGER)")
        lag = Recorder.poll_lag(R)
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import check_system as cs_
        kont = [(pv, so) for a_, (lp, pv, lt, so) in konten.items() if lp]
        m_ = cs_.poller_modell(kont, dict(cs_.POLLER_STANDARD))
        soll = m_["bedarf"] / (Settings.polls_per_min * 60 * cs_.poller_anteil_a(Settings.polls_per_min))
        ok("P5 Auslastung wie der Bericht (Bedarf 150/h von Hand), überfällig = A, neu = B ohne Gesperrte",
           abs(lag["load"] - soll) < 1e-12 and abs(m_["bedarf"] - 150) < 1e-9 and lag["backlog"] == 5 and lag["never"] == 1
           and (lag["whales"], lag["elite"], lag["pool"], lag["hot"], lag["cold"], lag["klein"], lag["gesperrt"]) == (1, 1, 1, 1, 2, 3, 2),
           f"Auslastung {lag['load'] * 100:.2f} % (Bericht {soll * 100:.2f} %), überfällig {lag['backlog']}, neu {lag['never']}")
        R2.con = R.con
        lag2 = Recorder.poll_lag(R2)
        soll2 = cs_.poller_modell(kont, dict(cs_.POLLER_STANDARD, klein_nach_handel=False))["bedarf"] / (
            Settings.polls_per_min * 60 * cs_.poller_anteil_a(Settings.polls_per_min))
        ok("P5 mit regelmäßigen kleinen Konten ebenso", abs(lag2["load"] - soll2) < 1e-12 and soll2 > soll, f"{lag2['load'] * 100:.2f} %")
        R.con.close()
        a0 = parser_bauen().parse_args([])
        a1 = parser_bauen().parse_args(["--klein-regelmaessig", "--hot-notional", "250000"])
        ok("P6 Befehlszeile: groß ab 500.000, kleine nach Handel; Schalter und alter Wert", a0.hot_notional == 500_000
           and a0.klein_regelmaessig is False and Settings.hot_notional == 500_000 and Settings.klein_nach_handel is True
           and a1.klein_regelmaessig is True and a1.hot_notional == 250_000, f"{a0.hot_notional}, {a0.klein_regelmaessig}; {a1.klein_regelmaessig}")
        # P7: Simulation 2 h unter Überlast (Rate 60/min: 10 je Runde, 6 A + 2 B + 2 C)
        rnd = random.Random(7)
        R = rec()
        R.cfg.polls_per_min = 60
        T[0] = t0
        handel_t = {}
        for i in range(5):
            R.addr_meta[f"W{i}"] = [t0 - rnd.randint(1, 60), 30e6, 0, 0]
        for i in range(400):
            R.addr_meta[f"H{i}"] = [t0 - rnd.randint(1, 3600), 600e3, 0, 0]
        for i in range(200):
            R.addr_meta[f"M{i}"] = [t0 - rnd.randint(1, 7200), 100e3, 0, 0]
        for i in range(400):
            R.addr_meta[f"K{i}"] = [t0 - rnd.randint(60, 20 * 3600), 5e3, 0, 0]
            if i < 40:
                handel_t[f"K{i}"] = t0 + rnd.randint(60, 7000)
        for i in range(10):
            R.addr_meta[f"G{i}"] = [t0 - 30 * 86_400, 1e6, 0, 0]
            R.gesperrt.add(f"G{i}")
        abfragen, erste = {}, {}
        k_in_a = 0
        while T[0] < t0 + 7200:
            for a_, th in handel_t.items():
                if th <= T[0] and R.addr_meta[a_][2] < th * 1000:
                    R.addr_meta[a_][2] = th * 1000
            batch = Recorder.due_addresses(R, max(int(R.cfg.polls_per_min / 12), 10))
            for a_ in batch:
                abfragen[a_] = abfragen.get(a_, 0) + 1
                if a_ in handel_t and handel_t[a_] <= T[0] and a_ not in erste:
                    erste[a_] = T[0] - handel_t[a_]
                R.addr_meta[a_][0] = T[0]
            k_in_a += sum(1 for a_ in batch[:6] if a_.startswith("K"))
            T[0] += 5
        g_ = sum(abfragen.get(f"G{i}", 0) for i in range(10))
        k_ohne = sum(abfragen.get(f"K{i}", 0) for i in range(40, 400))
        verz = sorted(erste.values())
        ok("P7 Simulation 2 h: gesperrt 0, kleine mit Handel binnen 2 Runden, ohne Handel nie, kein kleines Konto in Gruppe A",
           g_ == 0 and len(erste) == 40 and verz[-1] <= 10 and k_ohne == 0 and k_in_a == 0
           and sum(abfragen.get(f"H{i}", 0) for i in range(400)) > 0,
           f"gesperrt {g_}, kleine mit Handel {len(erste)}/40 (längste Wartezeit {verz[-1] if verz else '—'} s), ohne Handel {k_ohne}, "
           f"in A {k_in_a}, groß {sum(abfragen.get(f'H{i}', 0) for i in range(400))} Abfragen")
        # P8: Vorrang nach großem Handel
        T[0] = t0
        R = rec()
        R.addr_meta.update({"v1": [t0 - 3600, 0.0, (t0 - 20) * 1000, 0], "v2": [t0 - 3600, 5e3, (t0 - 20) * 1000, 0],
                            "v3": [t0 - 3600, 0.0, (t0 - 20) * 1000, 0], "v4": [t0 - 60, 0.0, (t0 - 3600) * 1000, 0],
                            "h1": [t0 - 900, 600e3, 0, 0]})
        R.addr_dex, R.addr_seen, R.addr_known, R.addr_new = {}, {}, set(), {}
        for a_, usd in (("v1", 20_000.0), ("v1", 6_000.0), ("v2", 30_000.0), ("v3", 24_000.0), ("v4", 1e6)):
            Recorder.seen_address(R, a_, (t0 - 20) * 1000, "", usd)
        R.addr_meta["v4"][2] = (t0 - 3600) * 1000                    # Handel vor der letzten Abfrage: kein Auslöser
        reihe = Recorder.due_addresses(R, 23)
        R0 = rec(vorrang_usd=0)
        R0.addr_meta = {k: list(v) for k, v in R.addr_meta.items()}; R0.addr_umsatz = dict(R.addr_umsatz)
        Recorder.due_addresses(R0, 23)
        R5 = rec()                                                   # Deckel: 5 Kandidaten, Runde 23 -> 2 vorne, die übrigen in C
        R5.addr_meta = {f"q{i}": [t0 - 3600, 0.0, (t0 - 20 - i) * 1000, 0] for i in range(5)}
        R5.addr_meta["h1"] = [t0 - 900, 600e3, 0, 0]
        R5.addr_umsatz = {f"q{i}": 30_000.0 + 1000 * i for i in range(5)}
        reihe5 = Recorder.due_addresses(R5, 23)
        ok("P8 Vorrang ab 25.000 USD Handel seit der letzten Abfrage (Summe aus dem Feed), vor fälligen Konten von Rang 1, größter Umsatz "
           "zuerst, höchstens ein Zehntel der Runde (übrige in C); sonst Gruppe C",
           reihe[:2] == ["v2", "v1"] and reihe.index("h1") == 2 and "v3" in reihe[3:] and "v4" not in reihe and R._vorrang == {"v1", "v2"}
           and abs(R.addr_umsatz["v1"] - 26_000) < 1e-9 and R.stats["due_pools"] == (3, 0, 3) and R0.stats["due_pools"] == (1, 0, 3)
           and not R0._vorrang and reihe5[:3] == ["q4", "q3", "h1"] and R5._vorrang == {"q3", "q4"} and R5.stats["due_pools"] == (3, 0, 5)
           and set(reihe5[3:]) == {"q0", "q1", "q2"} and len(reihe5) == len(set(reihe5)),
           f"{reihe} · Gruppen {R.stats['due_pools']}, ohne Vorrang {R0.stats['due_pools']} · Deckel {reihe5} {R5.stats['due_pools']}")
        # P9: Gruppe C voll -- große Eröffnungen leerer Adressen trotzdem binnen 2 Runden
        def saettigung(vorrang_usd):
            rnd_ = random.Random(11)
            R_ = rec(vorrang_usd=vorrang_usd)
            T[0] = t0
            for i in range(3000):
                R_.addr_meta[f"G{i}"] = [t0 - rnd_.randint(4000, 40000), 600e3, 0, 0]
            for i in range(20000):
                R_.addr_meta[f"K{i}"] = [t0 - rnd_.randint(600, 20 * 3600), 5e3, 0, 0]
            for i in range(200):
                R_.addr_meta[f"P{i}"] = [t0 - rnd_.randint(600, 20 * 3600), 0.0, 0, 0]
            ev = []
            tt = float(t0)
            while tt < t0 + 2400:
                tt += rnd_.expovariate(3.0)
                ev.append((tt, f"K{rnd_.randrange(20000)}", rnd_.uniform(50, 20_000)))
            p_t = {f"P{i}": t0 + rnd_.uniform(60, 1500) for i in range(200)}
            ev += [(x, a_, 1e6) for a_, x in p_t.items()]
            ev.sort()
            j, verz = 0, {}
            while T[0] < t0 + 2400:
                while j < len(ev) and ev[j][0] <= T[0]:
                    x, a_, usd = ev[j]
                    R_.addr_meta[a_][2] = int(x * 1000)
                    R_.addr_umsatz[a_] = R_.addr_umsatz.get(a_, 0.0) + usd
                    j += 1
                for a_ in Recorder.due_addresses(R_, 23):
                    if a_ in p_t and p_t[a_] <= T[0] and a_ not in verz:
                        verz[a_] = T[0] - p_t[a_]
                    R_.addr_meta[a_][0] = T[0]
                    R_.addr_umsatz.pop(a_, None)
                T[0] += 5
            return verz, len(p_t)
        v_mit, n_p = saettigung(25_000)
        v_ohne, _n = saettigung(0)
        ok("P9 Gruppe C voll (3 Auslöser je Sekunde): große Eröffnungen leerer Adressen binnen 2 Runden; ohne Vorrang nicht",
           len(v_mit) == n_p and max(v_mit.values()) <= 10 and (len(v_ohne) < n_p or max(v_ohne.values()) > 60),
           f"mit Vorrang {len(v_mit)}/{n_p}, längste {max(v_mit.values()) if v_mit else '—'} s; ohne {len(v_ohne)}/{n_p}"
           f"{', längste ' + str(max(v_ohne.values())) + ' s' if v_ohne else ''}")
        # P10: fehlgeschlagene Abfrage lässt den Auslöser stehen
        import asyncio as _aio
        async def post_nichts(req, quelle=None):
            return None

        def fehl_rec(pv_, lt_):
            R_ = rec()
            R_.addr_dex, R_.addr_value, R_.polled_at, R_.addr_dirty = {}, {"x": pv_}, {}, {}
            R_.stats = {"polls": 0}
            R_.mark_polled = lambda a_, n_, pv=None, R_=R_: Recorder.mark_polled(R_, a_, n_, pv)
            R_.post = post_nichts
            R_.addr_meta["x"] = [t0 - 5 * 3600, pv_, lt_, 0]
            return R_
        erg10 = []
        for pv_, alter_h in ((5e3, 1), (5e3, 2), (0.0, 2)):
            T[0] = t0
            R_ = fehl_rec(pv_, (t0 - alter_h * 3600) * 1000)
            vor_ = "x" in Recorder.due_addresses(R_, 23)
            _aio.run(Recorder.poll_address(R_, "x"))
            T[0] += 5
            pause_ = "x" not in Recorder.due_addresses(R_, 23)
            T[0] += 300
            erg10.append((vor_, pause_, "x" in Recorder.due_addresses(R_, 23)))
        T[0] = t0                                                    # dauernd scheiternd, mit großem Umsatz
        R_ = fehl_rec(0.0, (t0 - 2 * 3600) * 1000)
        R_.addr_umsatz["x"] = 2e6
        n_versuche, pausen, umsatz_da = 0, [], []
        while T[0] < t0 + 6 * 3600:
            if "x" in Recorder.due_addresses(R_, 23):
                n_versuche += 1
                _aio.run(Recorder.poll_address(R_, "x"))
                pausen.append(R_.poll_fehler["x"][1] - T[0])
                umsatz_da.append("x" in R_.addr_umsatz)
            T[0] += 5
        Rw = fehl_rec(30e6, 0)                                       # Wal: erster neuer Versuch nach 30 s
        T[0] = t0
        Rw.addr_meta["x"] = [t0 - 120, 30e6, 0, 0]
        _aio.run(Recorder.poll_address(Rw, "x"))
        T[0] += 25
        w_frueh = "x" in Recorder.due_addresses(Rw, 23)
        T[0] += 10
        w_spaet = "x" in Recorder.due_addresses(Rw, 23)
        ok("P10 fehlgeschlagene Abfrage: Pause (halber Takt, höchstens 5 min, dann doppelt), Handel bleibt Auslöser (klein 1 h und 2 h, leer "
           "2 h); dauernd scheiternd mit großem Umsatz: nach 3 Fehlschlägen kein Auslöser und kein Vorrang mehr; Wal nach 30 s wieder",
           erg10 == [(True, True, True)] * 3 and n_versuche == 4 and pausen[:3] == [300, 600, 1200] and "x" not in R_.addr_umsatz
           and umsatz_da == [True, True, True, False]
           and not w_frueh and w_spaet,
           f"{erg10} · scheiternd: {n_versuche} Versuche in 6 h, Pausen {pausen} · Wal {w_frueh}/{w_spaet}")
        # P12: erfolgreiche Abfrage -- Umsatz und Fehlschläge zurück, Abstand von Erfolg zu Erfolg mit der Stufe VOR der Abfrage
        async def post_pos(req, quelle=None):
            return {"marginSummary": {"accountValue": "1000"}, "assetPositions": [{"position": {
                "coin": "BTC", "szi": "0.1", "liquidationPx": "50000", "entryPx": "60000", "positionValue": "6000", "unrealizedPnl": "0",
                "leverage": {"type": "cross", "value": 10}}}]}
        T[0] = 1_800_007_200 + 30
        R_ = fehl_rec(600e3, 0)
        R_.post = post_pos
        R_.addr_meta["x"] = [T[0] - 1000, 600e3, (T[0] - 50) * 1000, 0]
        R_.addr_umsatz["x"] = 50_000.0
        R_.poll_fehler["x"] = (1, 0)
        R_.erfolg_at["x"] = T[0] - 1000
        R_.positions, R_.coin_of, R_.addr_update_pending, R_.addr_null_pending = {}, {}, [], []
        R_.track_whales = lambda *a_: None
        R_.track_pool = lambda *a_: None
        R_.infer_liquidations = lambda *a_: None
        R_.abst_stunde, R_.abst_lauf, R_.abst_letzte, R_.started_at = 0, {}, {}, T[0] - 86_400
        R_.abstand_messen = lambda a_, g_, R_=R_: Recorder.abstand_messen(R_, a_, g_)
        _aio.run(Recorder.poll_address(R_, "x"))
        ok("P12 erfolgreiche Abfrage: Umsatz und Fehlschläge zurückgesetzt, Abstand von Erfolg zu Erfolg (1.000 s) unter der Stufe vor der "
           "Abfrage (groß, obwohl jetzt klein), Erfolgszeit gesetzt",
           "x" not in R_.addr_umsatz and "x" not in R_.poll_fehler and R_.erfolg_at["x"] == T[0] and R_.abst_lauf == {"groß": [1, 1000.0]}
           and R_.addr_meta["x"][1] == 6000.0, f"Abstände {R_.abst_lauf}, Wert jetzt {R_.addr_meta['x'][1]}")
        # P8b: Drosselung (10 je Runde, A voll mit Walen) -- die vorgezogene Adresse kommt über C dran statt gar nicht
        T[0] = t0
        R_ = rec()
        for i in range(8):
            R_.addr_meta[f"W{i}"] = [t0 - 120, 30e6, 0, 0]
        R_.addr_meta.update({"n1": [0, 0.0, (t0 - 5) * 1000, (t0 - 100) * 1000], "n2": [0, 0.0, (t0 - 5) * 1000, (t0 - 90) * 1000],
                             "big": [t0 - 3600, 0.0, (t0 - 5) * 1000, 0], "kalt": [t0 - 3600, 5e3, (t0 - 100) * 1000, 0]})
        R_.addr_umsatz = {"big": 2e6}
        reihe8 = Recorder.due_addresses(R_, 10)
        ok("P8b Drosselung (10 je Runde, A voll mit Walen): die vorgezogene Adresse kommt über C dran, keine doppelt",
           "big" in reihe8 and len(reihe8) == len(set(reihe8)) == 10 and reihe8[6:8] == ["n1", "n2"], f"{reihe8}")
        # P11: Abstände je Stufe und Gesperrte ohne Wal-Zeitreihenpunkt
        R_ = rec()
        R_.addr_meta = {"g": [0, 600e3, 0, 0], "m": [0, 50e3, 0, 0], "w": [0, 30e6, 0, 0], "x": [0, 1e6, 0, 0]}
        R_.gesperrt = {"x"}
        R_.abst_stunde, R_.abst_lauf, R_.abst_letzte, R_.started_at = 0, {}, {}, 1_800_003_600 - 500
        T[0] = 1_800_003_600 + 100
        for a_, g_ in (("g", 1000), ("g", 2000), ("m", 9000), ("w", 60)):
            Recorder.abstand_messen(R_, a_, g_)
        T[0] += 3600
        Recorder.abstand_messen(R_, "g", 500)
        voll = dict(R_.abst_letzte)
        T[0] += 3 * 3600
        Recorder.abstand_messen(R_, "g", 500)
        luecke = dict(R_.abst_letzte)
        Rn = rec()                                                   # Neustart mitten in der Stunde: diese Stunde wird nicht veröffentlicht
        Rn.addr_meta = {"g": [0, 600e3, 0, 0]}
        Rn.abst_stunde, Rn.abst_lauf, Rn.abst_letzte, Rn.started_at = 0, {}, {}, 1_800_003_600 + 50
        T[0] = 1_800_003_600 + 100
        Recorder.abstand_messen(Rn, "g", 700)
        T[0] += 3600
        Recorder.abstand_messen(Rn, "g", 700)
        angebrochen = dict(Rn.abst_letzte)
        R_.whale_state = {"x": {"BTC": {"side": "long", "size": 1.0, "pos_value": 1e6, "liq_px": 1.0}},
                          "w": {"BTC": {"side": "long", "size": 1.0, "pos_value": 3e7, "liq_px": 1.0}}}
        R_.ref_px = lambda c_: 1.0
        zeilen11 = []
        R_.whale_rows_rest = []
        R_.whale_positions_schreiben = lambda rows: zeilen11.extend(rows)
        Recorder.snapshot_whales(R_, t0)
        ok("P11 Abstände je Stufe als volle Stunde (Mittel, Zahl), nach einer Lücke keine; Gesperrte ohne Wal-Zeitreihenpunkt",
           voll == {"stunde": 1_800_003_600 // 3600 * 3600, "je_stufe": {"groß": [2, 1500.0], "mittel": [1, 9000.0], "Wale": [1, 60.0]}}
           and luecke == {} and angebrochen == {} and [z_[1] for z_ in zeilen11] == ["w"],
           f"{voll} · nach Lücke {luecke} · angebrochene erste Stunde {angebrochen} · Zeitreihe {[z_[1] for z_ in zeilen11]}")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} {traceback.format_exc()[-300:]}")
    finally:
        time = echte_zeit
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Recorder -- Auswahl des Pollers (23.86, U220): Gesperrte nie, „groß“ ab 500.000, kleine nach eigenem Handel, Vorrang nach großem "
          "Handel, Statuszeile, gemessene Abstände")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<48} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def simulate(con: sqlite3.Connection, coin: str = "BTC", days: int = 20) -> None:
    """
    Erzeugt Fake-Daten zum Testen des Analysepfads. Cluster liegen auf festen
    absoluten Preisniveaus und verändern sich nur langsam — so wie echte
    Positionen. Der Kurs wandert dann in sie hinein.
    """
    rng = random.Random(42)
    t0 = int(time.time()) - days * 86400
    n = days * 1440
    p0 = 60_000.0

    # Preisreihe
    price = p0
    prices, rows_b = [], []
    for i in range(n):
        ts = t0 + i * 60
        price *= math.exp(rng.gauss(0, 0.0012))
        hi = price * (1 + abs(rng.gauss(0, 0.0006)))
        lo = price * (1 - abs(rng.gauss(0, 0.0006)))
        prices.append(price)
        rows_b.append((ts, coin, price, hi, lo, price,
                       abs(rng.gauss(4, 2)), rng.randint(5, 80)))

    # Persistente Cluster auf festem logarithmischem Preisraster
    step = math.log1p(0.0025)
    levels: dict[int, float] = {}

    def level_notional(k: int) -> float:
        if k not in levels:
            levels[k] = abs(rng.gauss(0, 1)) * 3e6
        levels[k] *= math.exp(rng.gauss(0, 0.02))   # driftet langsam
        return levels[k]

    rows_h = []
    for i in range(0, n, 5):                          # alle 5 Minuten
        ts, px = t0 + i * 60, prices[i]
        base = round(math.log(px) / step)
        for k in range(-40, 41):
            if k == 0:
                continue
            lv = round(math.exp((base + k) * step), 8)
            notional = level_notional(base + k) * math.exp(-abs(k) / 15)
            if notional > 5e4:
                side = "long" if k < 0 else "short"
                rows_h.append((ts, coin, lv, side, notional, rng.randint(1, 40),
                               rng.uniform(3, 25), lv * rng.uniform(0.9, 1.1),
                               rng.uniform(0.5, 1.0)))

    con.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)", rows_b)
    con.executemany("INSERT OR REPLACE INTO heatmap (ts, coin, bucket_px, side, notional, n_pos, "
                    "lev_wavg, entry_wavg, cross_share) VALUES (?,?,?,?,?,?,?,?,?)", rows_h)
    con.commit()
    print(f"Simulation: {len(rows_b)} Bars, {len(rows_h)} Heatmap-Zeilen für {coin}.")
    print("Achtung: reines Rauschen ohne echten Zusammenhang — testet nur die Pipeline.")


# ---------------------------------------------------------------------------
# Magnet-Test: zieht das größere Cluster den Kurs an?
# ---------------------------------------------------------------------------

MAGNET_SCHEMA = """
CREATE TABLE IF NOT EXISTS magnet_events (
    ts            INTEGER,
    coin          TEXT,
    horizon_h     INTEGER,
    px0           REAL,
    up_px         REAL,  up_notional REAL,  up_dist REAL,   -- größtes Short-Cluster oben
    dn_px         REAL,  dn_notional REAL,  dn_dist REAL,   -- größtes Long-Cluster unten
    bigger        TEXT,   -- 'up' oder 'dn': wo liegt mehr Notional
    closer        TEXT,   -- 'up' oder 'dn': was ist näher
    disagree      INTEGER,
    first_hit     TEXT,   -- 'up', 'dn' oder 'none' innerhalb des Horizonts
    t_hit_min     INTEGER,
    ret_h         REAL,   -- Rendite am Horizontende, signiert Richtung 'bigger'
    PRIMARY KEY (ts, coin, horizon_h)
) WITHOUT ROWID;
"""


def magnet_analyze(con: sqlite3.Connection, coin: str, horizons=(4, 24),
                   range_pct: float = 0.06, min_x_vol: float = 0.3,
                   step_min: int = 60, max_gap: int = 120) -> None:
    """
    Kernthese: Liquidationscluster wirken als Magnet, der Kurs läuft auf sie zu.

    Prüfung je Zeitpunkt: größtes Short-Cluster oberhalb, größtes Long-Cluster
    unterhalb (innerhalb range_pct). Welches wird zuerst erreicht?

    Drei Vorhersageregeln im Vergleich:
      Größe     -> das Cluster mit mehr Notional wird zuerst erreicht  (These)
      Nähe      -> das nähere wird zuerst erreicht                     (Geometrie)
      Zufall    -> 50 %

    Entscheidend ist die Teilmenge, in der Größe und Nähe VERSCHIEDENE Ziele
    nennen. Nur dort ist die These von der Geometrie unterscheidbar.
    """
    import numpy as np
    import pandas as pd

    con.executescript(MAGNET_SCHEMA)
    bars = pd.read_sql(
        "SELECT ts, high, low, close, volume FROM bars WHERE coin=? ORDER BY ts",
        con, params=(coin,)).set_index("ts")
    if len(bars) < 2000:
        print(f"Zu wenig Kursdaten für {coin}: {len(bars)} Bars.")
        return
    ts_arr = bars.index.to_numpy()
    hi_arr, lo_arr, cl_arr = bars["high"].to_numpy(), bars["low"].to_numpy(), bars["close"].to_numpy()
    vol_notional = (bars["volume"] * bars["close"]).rolling(60, min_periods=10).sum().to_numpy()

    snaps = [r[0] for r in con.execute(
        "SELECT DISTINCT ts FROM heatmap WHERE coin=? ORDER BY ts", (coin,))]
    if not snaps:
        print("Keine Heatmap-Snapshots.")
        return
    # Ausdünnen: Snapshots im Abstand step_min, sonst überlappen die Horizonte massiv
    sampled, last = [], -1e18
    for t in snaps:
        if t - last >= step_min * 60:
            sampled.append(t); last = t

    rows, skipped = [], 0
    for snap_ts in sampled:
        i = int(np.searchsorted(ts_arr, snap_ts))
        if i >= len(ts_arr) or abs(int(ts_arr[i]) - snap_ts) > max_gap:
            skipped += 1
            continue
        px0 = cl_arr[i]
        v1h = vol_notional[i]
        if not v1h or np.isnan(v1h) or v1h <= 0:
            continue
        cl = con.execute(
            "SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?",
            (coin, snap_ts)).fetchall()
        up = [(b, n) for b, sd, n in cl if sd == "short" and px0 < b <= px0 * (1 + range_pct)
              and n / v1h >= min_x_vol]
        dn = [(b, n) for b, sd, n in cl if sd == "long" and px0 * (1 - range_pct) <= b < px0
              and n / v1h >= min_x_vol]
        if not up or not dn:
            continue
        up_px, up_n = max(up, key=lambda x: x[1])
        dn_px, dn_n = max(dn, key=lambda x: x[1])
        up_d, dn_d = up_px / px0 - 1, 1 - dn_px / px0
        bigger = "up" if up_n > dn_n else "dn"
        closer = "up" if up_d < dn_d else "dn"

        for h in horizons:
            j = int(np.searchsorted(ts_arr, snap_ts + h * 3600))
            if j >= len(ts_arr):
                continue
            seg_hi, seg_lo = hi_arr[i:j], lo_arr[i:j]
            hit_up = np.argmax(seg_hi >= up_px) if (seg_hi >= up_px).any() else None
            hit_dn = np.argmax(seg_lo <= dn_px) if (seg_lo <= dn_px).any() else None
            if hit_up is None and hit_dn is None:
                first, t_hit = "none", None
            elif hit_dn is None or (hit_up is not None and hit_up <= hit_dn):
                first, t_hit = "up", int(hit_up)
            else:
                first, t_hit = "dn", int(hit_dn)
            ret = (cl_arr[j] / px0 - 1) * (1 if bigger == "up" else -1)
            rows.append((snap_ts, coin, h, px0, up_px, up_n, up_d, dn_px, dn_n, dn_d,
                         bigger, closer, int(bigger != closer), first, t_hit, ret))

    if not rows:
        print("Keine auswertbaren Zeitpunkte (beide Seiten brauchen ein Cluster "
              f"über {min_x_vol}x Stundenvolumen innerhalb {range_pct:.0%}).")
        return
    con.execute("DELETE FROM magnet_events WHERE coin=?", (coin,))
    con.executemany("INSERT OR REPLACE INTO magnet_events VALUES "
                    "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    df = pd.DataFrame(rows, columns=[
        "ts", "coin", "h", "px0", "up_px", "up_n", "up_d", "dn_px", "dn_n", "dn_d",
        "bigger", "closer", "disagree", "first", "t_hit", "ret"])

    print(f"\nMagnet-Test {coin}: {len(sampled)} Zeitpunkte im {step_min}-min-Raster"
          + (f", {skipped} ohne passende Kursbar" if skipped else ""))
    print("=" * 70)
    for h in horizons:
        d = df[df.h == h]
        hit = d[d["first"] != "none"]
        if len(hit) < 10:
            print(f"\n  Horizont {h} h: nur {len(hit)} Treffer, zu wenig.")
            continue
        acc_size = (hit["first"] == hit["bigger"]).mean()
        acc_dist = (hit["first"] == hit["closer"]).mean()
        dis = hit[hit.disagree == 1]
        print(f"\n  Horizont {h} h  ·  {len(d)} Zeitpunkte, {len(hit)} mit erreichtem Cluster "
              f"({len(hit)/len(d):.0%})")
        print(f"    Regel Größe   trifft {acc_size:>6.1%}")
        print(f"    Regel Nähe    trifft {acc_dist:>6.1%}")
        print(f"    Zufall               50.0%")
        if len(dis) >= 10:
            far_first = (dis["first"] == dis["bigger"]).to_numpy()
            # Geometrische Erwartung (Gambler's Ruin, driftloser Pfad): das
            # fernere von zwei Niveaus wird mit d_nah / (d_nah + d_fern) zuerst
            # erreicht. DAS ist die Messlatte, nicht 50 %.
            d_big = np.where(dis.bigger == "up", dis.up_d, dis.dn_d).astype(float)
            d_cls = np.where(dis.bigger == "up", dis.dn_d, dis.up_d).astype(float)
            p_geo = d_cls / (d_cls + d_big)
            expected, var = p_geo.sum(), (p_geo * (1 - p_geo)).sum()
            observed = far_first.sum()
            z = (observed - expected) / math.sqrt(var) if var > 0 else 0.0
            pval = math.erfc(abs(z) / math.sqrt(2))
            print(f"\n    Entscheidende Teilmenge: Größe und Nähe uneins (n={len(dis)})")
            print(f"      größeres, ferneres Cluster zuerst erreicht: "
                  f"{far_first.mean():.1%}")
            print(f"      geometrisch erwartet ohne Magnet:          "
                  f"{expected/len(dis):.1%}")
            print(f"      Überschuss {observed-expected:+.1f} Fälle, z = {z:+.2f}, p = {pval:.2}")
            if z > 1.96:
                print("      -> mehr als die Geometrie erklärt. Das wäre Magnetwirkung.")
            elif z < -1.96:
                print("      -> weniger als die Geometrie erklärt. Große Cluster stoßen eher ab.")
            else:
                print("      -> im Rahmen der Geometrie. Kein Beleg für einen Magneten.")
        else:
            print(f"\n    Nur {len(dis)} Fälle, in denen Größe und Nähe uneins sind — "
                  "das ist die Teilmenge, die zählt. Noch zu wenig.")
        print(f"    Ø Rendite Richtung größeres Cluster nach {h} h: {d['ret'].mean():+.2%}")

    # Zieht die Masse auch dann, wenn sie nicht erreicht wird?
    d24 = df[df.h == max(horizons)]
    if len(d24) >= 30:
        d24 = d24.assign(ratio=np.log(np.maximum(d24.up_n, 1) / np.maximum(d24.dn_n, 1)))
        q = pd.qcut(d24.ratio, 4, labels=False, duplicates="drop")
        print(f"\n  Nach Notional-Verhältnis oben/unten (Quartile), Horizont {max(horizons)} h:")
        for k, g in d24.groupby(q):
            toward_up = (g["first"] == "up").mean()
            print(f"    Quartil {int(k)+1}: oben/unten = {np.exp(g.ratio.mean()):5.2f}x  "
                  f"-> zuerst oben erreicht {toward_up:.0%}  (n={len(g)})")
        print("  Steigt der Anteil mit dem Verhältnis, zieht die Masse.")

    print("\n  Vorbehalte: Cluster liegen an alten Hochs und Tiefs, und ein Zufallspfad")
    print("  kehrt zu alten Niveaus zurück. Erst der Vergleich mit der Nähe-Regel")
    print("  in der uneinigen Teilmenge unterscheidet Magnet von Geometrie.")


def _wilson(hits: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return 0.0, 0.0
    p = hits / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (c - r) / d), min(1.0, (c + r) / d)


# ---------------------------------------------------------------------------
# Wal-Auswertung: haben Wal-Aktionen Vorhersagekraft?
# ---------------------------------------------------------------------------

def whale_analyze(con: sqlite3.Connection, coin: str) -> None:
    """
    Prüft, ob nach Wal-Aktionen der Kurs in die "richtige" Richtung läuft.

    Der entscheidende Vergleich ist die Kontrollgruppe: dieselbe Messung an
    zufälligen Zeitpunkten ohne Wal-Aktion. Erst der Unterschied zwischen
    beiden sagt etwas -- nicht die Trefferquote der Wale allein, denn in
    einem steigenden Markt "haben" auch zufällige Longs meist recht.

    Und selbst ein echter Unterschied beweist kein Insiderwissen: Wale
    bewegen den Kurs auch durch ihre eigene Order.
    """
    import random
    import numpy as np
    import pandas as pd

    ev = pd.read_sql(
        "SELECT ts, addr, event, side, pos_value, delta_usd FROM whale_positions "
        "WHERE coin=? AND event IN ('open','add','reduce','close','flip') ORDER BY ts",
        con, params=(coin,))
    bars = pd.read_sql("SELECT ts, close, high, low FROM bars WHERE coin=? ORDER BY ts",
                       con, params=(coin,)).set_index("ts")
    if len(ev) < 20 or len(bars) < 1000:
        print(f"Zu wenig Daten: {len(ev)} Wal-Ereignisse, {len(bars)} Bars.")
        print("Für eine belastbare Aussage braucht es Dutzende Ereignisse je Richtung.")
        return
    px = bars["close"]

    def fwd(ts: int, secs: int) -> float:
        i = px.index.searchsorted(ts); j = px.index.searchsorted(ts + secs)
        if i >= len(px) or j >= len(px) or abs(int(px.index[i]) - ts) > 180:
            return np.nan
        return px.iloc[j] / px.iloc[i] - 1

    # Implizite Richtung: Long öffnen/aufstocken = bullisch, Short öffnen = bärisch,
    # reduzieren/schließen = Gegenrichtung der Position.
    def direction(r) -> int:
        bull = 1 if r.side == "long" else -1
        return bull if r.event in ("open", "add", "flip") else -bull

    ev["dir"] = ev.apply(direction, axis=1)
    for h, secs in (("1h", 3600), ("4h", 14400), ("24h", 86400)):
        ev[f"r{h}"] = ev.ts.apply(lambda t: fwd(int(t), secs))
        ev[f"hit{h}"] = np.sign(ev[f"r{h}"]) == ev["dir"]
        ev[f"signed{h}"] = ev[f"r{h}"] * ev["dir"]

    # Kontrollgruppe: gleich viele zufällige Zeitpunkte, zufällige Richtung
    rng = random.Random(7)
    # Die Kontrollgruppe zieht Zeitpunkte, die noch 24 h Vorlauf haben. Bei weniger als
    # einem Tag Historie ist dieser Bereich leer -- randint warf dann ValueError und riss
    # den ganzen Lauf mit. Die Eingangsprüfung verlangt nur 1000 Bars (rund 17 h).
    lo, hi = int(px.index[0]), int(px.index[-1]) - 86400
    if hi <= lo:
        print(f"Zu kurze Historie: {(int(px.index[-1]) - lo) / 3600:.1f} h Kursdaten, "
              f"für die Kontrollgruppe werden mehr als 24 h gebraucht.")
        return
    ctrl = pd.DataFrame({"ts": [rng.randint(lo, hi) for _ in range(max(len(ev) * 5, 200))]})
    ctrl["dir"] = [rng.choice((1, -1)) for _ in range(len(ctrl))]
    for h, secs in (("1h", 3600), ("4h", 14400), ("24h", 86400)):
        ctrl[f"r{h}"] = ctrl.ts.apply(lambda t: fwd(int(t), secs))
        ctrl[f"hit{h}"] = np.sign(ctrl[f"r{h}"]) == ctrl["dir"]
        ctrl[f"signed{h}"] = ctrl[f"r{h}"] * ctrl["dir"]

    print(f"\nWal-Ereignisse {coin}: {len(ev)} (Kontrolle: {len(ctrl)} Zufallszeitpunkte)")
    print("=" * 66)
    print(f"  {'':<10}{'Treffer':>9}{'Kontrolle':>11}{'Ø signiert':>13}{'Kontrolle':>11}")
    for h in ("1h", "4h", "24h"):
        e = ev[f"hit{h}"].dropna(); c = ctrl[f"hit{h}"].dropna()
        print(f"  {h:<10}{e.mean():>8.1%}{c.mean():>11.1%}"
              f"{ev[f'signed{h}'].mean():>+13.2%}{ctrl[f'signed{h}'].mean():>+11.2%}")

    print("\n  Nach Ereignistyp (4 h):")
    for evt, grp in ev.groupby("event"):
        if len(grp) >= 5:
            print(f"    {evt:<8} n={len(grp):<4} Treffer {grp['hit4h'].mean():.0%}  "
                  f"Ø signiert {grp['signed4h'].mean():+.2%}")

    # Reagiert der Kurs schon in der Minute der Aktion? Dann ist es Impact, nicht Wissen.
    ev["r5m"] = ev.ts.apply(lambda t: fwd(int(t), 300)) * ev["dir"]
    print(f"\n  Bewegung in den ersten 5 Minuten, signiert: {ev['r5m'].mean():+.3%}")
    print("  Groß und positiv = die Wal-Order bewegt den Kurs selbst (Impact).")
    print("  Nahe null, aber 4h/24h positiv = eher Information als Impact.")

    print("\n  Einordnung: Ein Vorsprung gegenüber der Kontrolle ist noch kein")
    print("  Insiderwissen. Ein großer Short kann eine abgesicherte Spot-Position")
    print("  sein, und was jeder sehen kann, ist im Kurs meist schon drin.")


# ---------------------------------------------------------------------------
# Export: kompaktes Paket zum Weitergeben oder Hochladen
# ---------------------------------------------------------------------------

def export_bundle(con: sqlite3.Connection, out_path: str,
                  coin: str | None = None, with_ticks: bool = False) -> None:
    """
    Schreibt ein ZIP mit allem, was zur Auswertung nötig ist -- ohne die
    Rohdaten. Die Datenbank wird nach Monaten hunderte Megabyte groß und ist
    nicht mehr handhabbar; die Ereignisse und Kennzahlen daraus passen in
    wenige hundert Kilobyte.

    Enthalten:
      cluster_events.csv   die gelabelten Berührungen, ein Datensatz je Ereignis
      daily_coverage.csv   je Coin und Tag: Bars, Snapshots, Liquidationen
      time_heatmap.csv     die Wochentag-x-Uhrzeit-Statistik, falls vorhanden
      binance_hourly.csv   stündlich aggregierte Binance-Liquidationen
      meta.json            Abdeckung, Zeitraum, Datenqualität
    """
    import csv
    import io
    import zipfile

    def rows_to_csv(cur) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([d[0] for d in cur.description])
        w.writerows(cur.fetchall())
        return buf.getvalue()

    def table_exists(name: str) -> bool:
        return con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (name,)).fetchone() is not None

    where, args = ("WHERE coin=?", (coin,)) if coin else ("", ())
    parts: dict[str, str] = {}

    # --- Ereignisse, mit abgeleiteten Zeitspalten für die Auswertung
    if table_exists("cluster_events"):
        cur = con.execute(f"""
            SELECT *,
                   CAST(strftime('%w', ts, 'unixepoch') AS INTEGER) AS weekday_sun0,
                   CAST(strftime('%H', ts, 'unixepoch') AS INTEGER) AS hour_utc,
                   CAST(strftime('%H', ts, 'unixepoch') AS INTEGER) * 2
                     + CAST(strftime('%M', ts, 'unixepoch') AS INTEGER) / 30
                     AS slot_utc,
                   datetime(ts, 'unixepoch') AS ts_utc
            FROM cluster_events {where} ORDER BY ts""", args)
        parts["cluster_events.csv"] = rows_to_csv(cur)

    # --- Tagesabdeckung: zeigt Lücken und Ausfälle auf einen Blick
    cur = con.execute(f"""
        SELECT date(ts,'unixepoch') AS tag, coin,
               COUNT(*) AS bars, SUM(volume) AS volumen,
               MIN(low) AS tief, MAX(high) AS hoch
        FROM bars {where} GROUP BY tag, coin ORDER BY tag, coin""", args)
    parts["daily_coverage.csv"] = rows_to_csv(cur)

    cur = con.execute(f"""
        SELECT date(ts,'unixepoch') AS tag, coin,
               COUNT(DISTINCT ts) AS snapshots,
               COUNT(*) AS zeilen,
               SUM(notional) / COUNT(DISTINCT ts) AS notional_je_snapshot
        FROM heatmap {where} GROUP BY tag, coin ORDER BY tag, coin""", args)
    parts["daily_heatmap.csv"] = rows_to_csv(cur)

    if table_exists("tick_events"):
        parts["tick_events.csv"] = rows_to_csv(con.execute(
            f"SELECT id, datetime(t_trigger/1000,'unixepoch') AS trigger_utc, * "
            f"FROM tick_events {where} ORDER BY t_trigger", args))
        if with_ticks:
            parts["ticks.csv"] = rows_to_csv(con.execute(
                f"SELECT * FROM ticks {where} ORDER BY event_id, ts_ms", args))
            parts["mark_ticks.csv"] = rows_to_csv(con.execute(
                f"SELECT * FROM mark_ticks {where} ORDER BY event_id, ts_ms", args))
            if table_exists("book_ticks"):
                parts["book_ticks.csv"] = rows_to_csv(con.execute(
                    f"SELECT * FROM book_ticks {where} ORDER BY event_id, ts_ms", args))
    for t in ("book_summary", "bars10", "proximity"):
        if table_exists(t) and with_ticks:
            parts[f"{t}.csv"] = rows_to_csv(con.execute(
                f"SELECT * FROM {t} {where} ORDER BY ts", args))

    if table_exists("order_levels"):
        parts["order_levels.csv"] = rows_to_csv(con.execute(
            f"SELECT datetime(ts,'unixepoch') AS utc, * FROM order_levels {where} ORDER BY ts", args))

    if table_exists("magnet_events"):
        parts["magnet_events.csv"] = rows_to_csv(con.execute(
            f"SELECT datetime(ts,'unixepoch') AS ts_utc, * FROM magnet_events {where} "
            "ORDER BY ts", args))

    if table_exists("whale_positions"):
        parts["whale_events.csv"] = rows_to_csv(con.execute(
            f"SELECT datetime(ts,'unixepoch') AS ts_utc, * FROM whale_positions "
            f"{where.replace('coin', 'whale_positions.coin') if where else ''} "
            "ORDER BY ts", args))

    if table_exists("coverage"):
        parts["coverage.csv"] = rows_to_csv(con.execute(
            f"SELECT datetime(ts,'unixepoch') AS ts_utc, * FROM coverage {where} ORDER BY ts",
            args))
    if table_exists("ctx_bars"):
        parts["market_context_hourly.csv"] = rows_to_csv(con.execute(f"""
            SELECT strftime('%Y-%m-%dT%H', ts, 'unixepoch') AS stunde, coin,
                   AVG(mark_px) AS mark, AVG(oracle_px) AS oracle,
                   AVG(funding) AS funding, AVG(oi) AS oi, AVG(premium) AS premium
            FROM ctx_bars {where} GROUP BY stunde, coin ORDER BY stunde, coin""", args))

    if table_exists("snapshot_meta"):
        parts["snapshot_quality.csv"] = rows_to_csv(con.execute(
            "SELECT datetime(ts,'unixepoch') AS ts_utc, * FROM snapshot_meta ORDER BY ts"))

    if table_exists("time_heatmap"):
        parts["time_heatmap.csv"] = rows_to_csv(
            con.execute("SELECT * FROM time_heatmap ORDER BY coin, threshold, "
                        "weekday, slot"))

    if table_exists("bnc_liquidations"):
        parts["binance_hourly.csv"] = rows_to_csv(con.execute("""
            SELECT strftime('%Y-%m-%dT%H', ts/1000, 'unixepoch') AS stunde, coin,
                   COUNT(*) AS anzahl,
                   SUM(CASE WHEN side='long'  THEN notional ELSE 0 END) AS long_liq,
                   SUM(CASE WHEN side='short' THEN notional ELSE 0 END) AS short_liq
            FROM bnc_liquidations GROUP BY stunde, coin ORDER BY stunde, coin"""))

    # --- Metadaten: Zeitraum, Umfang, Datenqualität
    now = int(time.time())
    span = con.execute("SELECT MIN(ts), MAX(ts) FROM bars").fetchone()
    ages = sorted(now - r[0] for r in con.execute(
        "SELECT last_poll FROM addresses WHERE notional>0 AND last_poll>0"))
    per_coin = {}
    for c, n, lo, hi in con.execute(
            "SELECT coin, COUNT(*), MIN(ts), MAX(ts) FROM bars GROUP BY coin"):
        snaps = con.execute(
            "SELECT COUNT(DISTINCT ts) FROM heatmap WHERE coin=?", (c,)).fetchone()[0]
        per_coin[c] = {"bars": n, "snapshots": snaps,
                       "von": datetime_utc(lo), "bis": datetime_utc(hi),
                       "abdeckung_prozent": round(
                           n / max((hi - lo) / 60, 1) * 100, 1)}
    meta = {
        "erstellt": datetime_utc(now),
        "zeitraum": {"von": datetime_utc(span[0]) if span[0] else None,
                     "bis": datetime_utc(span[1]) if span[1] else None,
                     "tage": round((span[1] - span[0]) / 86400, 1) if span[0] else 0},
        "coins": per_coin,
        "adressen": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
        "adressen_mit_position": con.execute(
            "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
        "datenalter_median_min": (ages[len(ages)//2] // 60) if ages else None,
        "datenalter_p90_min": (ages[int(len(ages)*0.9)] // 60) if ages else None,
        "cluster_events": con.execute(
            "SELECT COUNT(*) FROM cluster_events").fetchone()[0]
            if table_exists("cluster_events") else 0,
        "hinweis": "Aggregate und gelabelte Ereignisse, keine Rohdaten. "
                   "Die vollständige Datenbank verbleibt auf dem Aufzeichnungsrechner.",
    }
    parts["meta.json"] = json.dumps(meta, indent=2, ensure_ascii=False)

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, content in parts.items():
            z.writestr(name, content)

    size = os.path.getsize(out_path)
    print(f"\nExport: {out_path} ({size/1024:.0f} kB)")
    for name, content in parts.items():
        lines = content.count("\n")
        print(f"  {name:<22} {lines:>8,} Zeilen")
    if meta["cluster_events"] == 0:
        print("\nAchtung: keine cluster_events enthalten. Erst --analyze laufen "
              "lassen, sonst fehlt der eigentliche Inhalt.")
    if size > 20_000_000:
        print("\nDas Paket ist recht groß. Mit --coin BTC auf einen Coin "
              "einschränken.")


# ---------------------------------------------------------------------------
# Backup: täglich, verifiziert, atomar ersetzt
# ---------------------------------------------------------------------------

BACKUP_NAME = "hl_liq_backup.db"
SPEICHER_DATEI = "speicherorte.json"   # 23.23: Einstellungen aus dem Dashboard (Backup-Pfad, „Jetzt sichern“), im Projektordner


def speicher_pfad() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), SPEICHER_DATEI)


def speicher_einstellung() -> dict:
    try:
        with open(speicher_pfad(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def speicher_mtime() -> float:
    try:
        return os.path.getmtime(speicher_pfad())
    except OSError:
        return 0.0


# 23.66 (U145): Nebendatenbanken neben hl_liq.db, gesichert mit derselben Backup-API (eine Generation .1). Neu dabei:
# aktien.db (Archiv der Aktien- und Kreditreihen -- FRED zeigt den Hochzinsaufschlag nur 3 Jahre, Farside und die
# xyz-Kerzen nur ein kurzes Fenster) und ausblick.db (Vorwärtsbuch der 4-Wochen-Prognose). Beides gibt es nur hier.
# 23.76 (U206): notbremse.db (Zustand, Episoden, Kalibrierungen der Notbremse) und labor_a.db (Welt A des TradeLabors); dazu die vom
# Nutzer gepflegte notbremse_termine.json aus dem Projektordner (BACKUP_JSON, eine Kopie im Backup-Ordner)
# 23.88 (U235): prognosemarkt.db (Live-Kurse der Prognosemärkte ab dem Stichtag -- bei Polymarket später nicht in derselben Feinheit
# nachladbar; Rückblick und Urteil). Sie wächst geschätzt um 1–4 GB im Jahr (KONZEPT_Prognosemaerkte.md 12, Entscheidung 4); die
# Platzprüfung des Backups zählt sie mit.
# 23.90 (U237): volatil.db (vorab festgelegte Prognosen der Volatilität ab dem Stichtag und das Urteil; klein, einige 10 MB)
# 23.93 (U241): engine.db (Trading Engine: Start des Kontos, Puls des Labors = Ausfalltage, Protokoll der Entscheidungen, Lösen der
# Bremse -- der Puls lässt sich später nicht nachrechnen; klein, wenige MB im Jahr)
# 23.103 (U257): staking.db (Unstaking bei Ethereum). Seit 23.102 liegt darin die eigene Tagesreihe aus dem Beacon-Knoten -- der Knoten
# zeigt nur den jetzigen Stand, und die Tagesdatei der Quelle endet am 25.10.2026: Die Reihe lässt sich nicht neu laden. Dazu das
# gespeicherte Urteil der Prüfung der Kursfolge (U255) -- ginge es verloren, rechnete Debug 147 ein zweites mit anderen Daten. Klein
# (wenige MB); der Dienst des Dashboards schreibt stündlich hinein, gelesen wird wie bei den anderen in einem Schritt.
# 23.122 (U307): radar.db (Risikoradar). Die Stundenstände sind der eigene Verlauf der Achse „Liquidations-Nähe“ (die Heatmap hält
# keinen Verlauf) und die Grundlage der Vorwärtsbilanz der beiden Zahlen -- nicht nachrechenbar. Klein (wenige MB im Jahr); der Takt des
# Dashboards schreibt alle 5 Minuten hinein.
BACKUP_NEBEN = ("forecasts", "makro", "aktien", "ausblick", "notbremse", "labor_a", "prognosemarkt", "volatil", "engine", "staking", "radar")
BACKUP_JSON = ("notbremse_termine.json",)
# 23.103: Die Namen stehen nur noch in BACKUP_NEBEN -- bis 23.102 zusätzlich von Hand in zwei Mustern (drei Stellen für jede neue Datei).
_BACKUP_NAMEN = "|".join(re.escape(n) for n in ("hl_liq",) + BACKUP_NEBEN)
_BACKUP_REST = re.compile(r"^(" + _BACKUP_NAMEN + r")_backup\.db\.tmp(\.\d+)?(-journal|-wal|-shm)?$"
                          r"|^backup\.json\.tmp\.\d+$|^notbremse_termine\.json\.tmp\.\d+$")
_BACKUP_MUSTER = re.compile(r"^(" + _BACKUP_NAMEN + r")_backup\.db(\.\d)?$|^backup\.json$|^notbremse_termine\.json$")


def backup_dateien(backup_dir: str) -> list[str]:
    """23.66: alle Dateien, die zum Backup gehören (Generationen, Nebendatenbanken, Reste, backup.json) -- für Anzeige und Umzug."""
    try:
        return sorted(n for n in os.listdir(backup_dir) if _BACKUP_MUSTER.match(n) or _BACKUP_REST.match(n))
    except OSError:
        return []


# 23.95 (U243, Wunsch des Nutzers 04.11. 23:48): ZWEI Stände der Hauptdatenbank -- die neue Sicherung und die vorige (.1). Bis 23.94
# waren es drei (M13, Audit v10): auf der SD-Karte drei Kopien zu je 23,6 GB, frei blieben am 04.11. noch 35 GB, die Platzprüfung
# hätte um den 07./08.11. übersprungen. Ältere Stände (.2 aus der Zeit mit drei Generationen) entfernt der nächste Lauf VOR der
# Platzprüfung. Die Nebendatenbanken hatten schon immer zwei Stände (neu und .1).
GENERATIONEN = 2
# 23.95 (U243): Orte für eingehängte Laufwerke. Ein Backup-Ordner darunter muss auf einem eigenen Laufwerk liegen, dessen
# Einhängepunkt selbst darunter liegt (/media/seed/USB, /mnt). Ist das Laufwerk nicht eingehängt (USB abgezogen, nach einem
# Neustart nicht eingehängt), läge der Ordner auf der Systemkarte: Der Lauf bricht dann ab, statt die Kopie unbemerkt auf die
# SD-Karte zu schreiben (dort läge sie später verdeckt unter dem Einhängepunkt) -- oder, ohne Schreibrecht, mit einer Ausnahme
# die Aufgabe „Backup“ des Recorders abstürzen zu lassen (bis 23.94: os.makedirs vor jeder Prüfung).
BACKUP_MEDIEN_WURZELN = ("/media/", "/mnt/")
FAT_FS = ("vfat", "msdos", "fat", "umsdos")       # FAT32: eine Datei höchstens 4 GiB -- die Kopie bräche nach 4 GB ab
FAT_GRENZE = 4 * 1024 ** 3 - 1


def _mount_text(s: str) -> str:
    """/proc/mounts schreibt Leerzeichen, Tab, Zeilenumbruch und Backslash oktal (\\040, \\011, \\012, \\134)."""
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), s)


def einhaengungen() -> list[tuple[str, str, str]]:
    """23.95: (Einhängepunkt, Gerät, Dateisystem) aus /proc/mounts, in der Reihenfolge der Datei (spätere überdecken frühere)."""
    out = []
    try:
        with open("/proc/mounts", encoding="utf-8", errors="replace") as f:
            for zeile in f:
                t = zeile.split()
                if len(t) >= 3:
                    out.append((_mount_text(t[1]), _mount_text(t[0]), t[2]))
    except OSError:
        pass
    return out


def medium_von(pfad: str) -> dict:
    """
    23.95: Auf welchem Dateisystem läge pfad? Nächster existierender Vorfahr (Symlinks aufgelöst), dazu der längste passende
    Einhängepunkt aus /proc/mounts (am selben Punkt gilt der spätere Eintrag). Ohne /proc/mounts: os.path.ismount aufwärts.
    """
    p = os.path.realpath(os.path.abspath(pfad))
    q = p
    while not os.path.exists(q) and os.path.dirname(q) != q:
        q = os.path.dirname(q)
    mp, dev, fs = None, "?", "?"
    for m_, d_, f_ in einhaengungen():
        if (q == m_ or q.startswith(m_.rstrip("/") + "/")) and (mp is None or len(m_) >= len(mp)):
            mp, dev, fs = m_, d_, f_
    if mp is None:
        mp = q
        while not os.path.ismount(mp) and os.path.dirname(mp) != mp:
            mp = os.path.dirname(mp)
    return {"pfad": p, "vorhanden": q, "mount": mp, "geraet": dev, "fs": fs}


def _unter(pfad: str, wurzeln) -> bool:
    return (pfad.rstrip("/") + "/").startswith(tuple(wurzeln))


def speicher_mount_soll(backup_dir: str) -> str | None:
    """
    23.95 (U243): Einhängepunkt, den das Dashboard beim Wählen dieses Ordners festgehalten hat (speicherorte.json, „mount“) -- nur
    wenn backup_dir der dort gewählte Ordner ist, sonst None.
    """
    ein = speicher_einstellung()
    try:
        if ein.get("backup_dir") and os.path.realpath(ein["backup_dir"]) == os.path.realpath(backup_dir):
            return str(ein.get("mount") or "") or None
    except (TypeError, ValueError):
        pass
    return None


def backup_ziel_pruefungen(backup_dir: str, db_bytes: int | None = None, mount_soll: str | None = None) -> list[list]:
    """
    23.95 (U243): Prüfungen des Ziels, BEVOR etwas angelegt wird -- [Name, bestanden, Text]; dieselben für das Dashboard (Auswahl des
    Ordners) und vor jedem Backup (backup_ziel_fehler):
      Laufwerk eingehängt -- unter /media und /mnt muss der Einhängepunkt selbst darunter liegen (sonst meist „/“, die SD-Karte); und
          hat das Dashboard beim Wählen einen eigenen Einhängepunkt festgehalten (mount_soll, sonst aus speicherorte.json), muss es
          genau dieser sein -- so auch für ein Laufwerk, das etwa unter /home eingehängt ist;
      Dateisystem -- kein FAT, wenn die Datenbank größer als 4 GiB ist (die Kopie bräche nach 4 GB ab, jeden Tag aufs Neue).
    """
    m = medium_von(backup_dir)
    soll = mount_soll if mount_soll is not None else speicher_mount_soll(backup_dir)
    soll = soll if soll and soll != "/" else None
    out = []
    unter_medien = _unter(m["pfad"], BACKUP_MEDIEN_WURZELN)
    if unter_medien or soll:
        ok = (not unter_medien or _unter(m["mount"], BACKUP_MEDIEN_WURZELN)) and (soll is None or m["mount"] == soll)
        wo = "der Systemkarte (SD)" if m["mount"] == "/" else m["mount"]
        out.append(["Laufwerk eingehängt", ok, f"ja: {m['mount']} ({m['geraet']})" if ok else
                    f"Laufwerk für {m['pfad']} nicht eingehängt — der Ordner läge auf {wo}"
                    + (f", beim Wählen auf {soll}" if soll else "") + " (Laufwerk einstecken bzw. einhängen)"])
    zu_gross = m["fs"] in FAT_FS and (db_bytes or 0) > FAT_GRENZE
    out.append(["Dateisystem", not zu_gross, m["fs"] if not zu_gross else
                f"{m['mount']} ist FAT ({m['fs']}): höchstens 4 GB je Datei, die Datenbank hat {(db_bytes or 0) / 1e9:.1f} GB "
                f"(Laufwerk mit ext4 oder exFAT formatieren)"])
    return out


def backup_ziel_fehler(backup_dir: str, db_bytes: int | None = None, mount_soll: str | None = None) -> str | None:
    """23.95 (U243): Grund, warum in backup_dir jetzt nicht gesichert werden darf (backup_ziel_pruefungen), sonst None."""
    for _name, ok, text in backup_ziel_pruefungen(backup_dir, db_bytes, mount_soll):
        if not ok:
            return f"{text}; Backup übersprungen, das letzte bleibt erhalten"
    return None


def backup_bedarf(db_path: str) -> dict:
    """
    23.95 (U243): Platz am Backup-Ort. lauf = was ein Lauf zusätzlich zu den liegenden Ständen braucht (wie seit jeher: Datenbank × 1,1
    plus Nebendatenbanken -- die neue Kopie entsteht neben den alten); dauer = GENERATIONEN Stände von allem plus ein Lauf, so viel
    muss der Ort auf Dauer fassen (bei heutiger Größe; die Datenbank wächst).
    """
    ddir = os.path.dirname(os.path.abspath(db_path))

    def gr(p):
        try:
            return os.path.getsize(p)
        except OSError:
            return 0
    db = gr(db_path)
    neben = sum(gr(os.path.join(ddir, f"{n}.db")) for n in BACKUP_NEBEN)
    lauf = db * 1.1 + neben
    return {"db": db, "neben": neben, "lauf": lauf, "dauer": GENERATIONEN * (db + neben) + lauf}


def backup_generationen(backup_dir: str) -> list[dict]:
    """23.95: die liegenden Stände der Hauptdatenbank (neu, .1, ggf. ältere aus der Zeit mit drei) mit Größe und Zeit."""
    out = []
    for g in [""] + [f".{i}" for i in range(1, 10)]:
        try:
            st = os.stat(os.path.join(backup_dir, BACKUP_NAME + g))
        except OSError:
            continue
        out.append({"name": BACKUP_NAME + g, "bytes": st.st_size, "mtime": int(st.st_mtime)})
    return out


def backup_freiwerdend(backup_dir: str) -> int:
    """23.95 (U243): Bytes der Stände über GENERATIONEN hinaus (die .2 aus der Zeit mit drei) -- der nächste Lauf löscht sie vor der
    Platzprüfung; Anzeigen zählen sie darum zum freien Platz."""
    return sum(g["bytes"] for g in backup_generationen(backup_dir)
               if g["name"] != BACKUP_NAME and int(g["name"].rsplit(".", 1)[1]) >= GENERATIONEN)


def backup_laeuft(db_path: str, backup_dir: str | None = None) -> dict | None:
    """
    23.95: Hält gerade ein Prozess die BackupSperre? Probe mit geteilter Sperre ohne Warten, sofort wieder frei -- liest nur
    (die Sperrdatei wird nicht angelegt). Für das Dashboard: „Backup läuft“, „Jetzt sichern“ nicht doppelt.
    """
    import fcntl
    for p in [os.path.abspath(db_path) + ".backup.lock"] + ([os.path.join(backup_dir, ".backup.lock")] if backup_dir else []):
        try:
            fd = os.open(p, os.O_RDONLY)
        except OSError:
            continue
        try:
            try:
                fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
            except BlockingIOError:
                try:
                    d = json.loads(os.pread(fd, 400, 0).decode("utf-8", "replace") or "{}")
                except (OSError, ValueError):
                    d = {}
                d = d if isinstance(d, dict) else {}
                return {"wer": d.get("wer") or "anderer Prozess", "pid": d.get("pid"), "seit": d.get("seit"), "sperre": p}
            except OSError:
                continue
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)
    return None


class BackupSperre:
    """
    23.66 (U145): höchstens EINE Sicherung derselben Datenbank zur selben Zeit.

    Am 11.10. liefen update.py (hl_recorder.py --backup) und der Recorder (run_backup) nach demselben Kriterium los und
    schrieben in dieselbe Zwischendatei hl_liq_backup.db.tmp; das Aufräumen des einen löschte die Dateien des anderen
    (disk I/O error beim Abschluss, fehlende Datei beim Umbenennen, fremdes Journal, halbe backup.json). Die Sperre ist ein
    flock auf <db>.backup.lock (Ausweichort: .backup.lock im Backup-Ordner). Der Kernel gibt sie frei, wenn der Prozess
    endet -- auch bei Absturz oder SIGKILL; eine liegengebliebene Sperre gibt es nicht. In der Datei steht, wer sie hält.
    """

    def __init__(self, db_path: str, backup_dir: str, wer: str = ""):
        self.orte = [os.path.abspath(db_path) + ".backup.lock", os.path.join(backup_dir, ".backup.lock")]
        self.wer = wer or os.path.basename(sys.argv[0] or "python")
        self.fd: int | None = None
        self.pfad: str | None = None
        self.grund_ohne: str | None = None

    def versuchen(self) -> bool | None:
        """True = gehalten, False = besetzt (self.pfad sagt wo), None = auf diesem Dateisystem keine Sperre möglich."""
        import fcntl
        fehler = []
        for p in self.orte:
            try:
                fd = os.open(p, os.O_RDWR | os.O_CREAT, 0o644)
            except OSError as e:
                fehler.append(f"{p}: {e.strerror or e}")
                continue
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                os.close(fd)
                self.pfad = p
                return False
            except OSError as e:
                os.close(fd)
                fehler.append(f"{p}: {e.strerror or e}")
                continue
            self.fd, self.pfad = fd, p
            try:
                info = json.dumps({"pid": os.getpid(), "seit": int(time.time()), "wer": self.wer}).encode()
                os.ftruncate(fd, 0)
                os.pwrite(fd, info, 0)
            except OSError:
                pass
            return True
        self.grund_ohne = "; ".join(fehler) or "kein Ort"
        return None

    def halter(self) -> str:
        """Wer hält die Sperre? (für Meldungen; liest die Angaben des Halters aus der Sperrdatei)"""
        try:
            with open(self.pfad or self.orte[0], encoding="utf-8") as f:
                d = json.load(f)
            alt = max(0, time.time() - float(d.get("seit") or time.time())) / 60
            return f"{d.get('wer') or 'anderer Prozess'}, PID {d.get('pid')}, seit {alt:.0f} min"
        except (OSError, ValueError, TypeError):
            return "anderer Prozess"

    def freigeben(self) -> None:
        if self.fd is not None:
            import fcntl
            try:
                fcntl.flock(self.fd, fcntl.LOCK_UN)
            finally:
                os.close(self.fd)
                self.fd = None


def _json_atomar(pfad: str, daten: dict) -> None:
    """23.66 (U145): backup.json über eine Zwischendatei und os.replace -- ein Leser sieht immer eine ganze Datei."""
    tmp = f"{pfad}.tmp.{os.getpid()}"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp, pfad)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def do_backup(db_path: str, backup_dir: str, warten_s: float = 0, wenn_aelter_h: float | None = None,
              wer: str = "", melden=None) -> dict:
    """
    Konsistente Kopie im laufenden Betrieb über die SQLite-Backup-API.

    Reihenfolge ist entscheidend: erst in eine temporäre Datei kopieren, dann
    die Kopie mit integrity_check prüfen, erst dann das alte Backup atomar
    ersetzen. Ist die Quelle bereits beschädigt, scheitert die Prüfung und
    das letzte gute Backup bleibt unangetastet.

    23.66 (U145): nur unter der BackupSperre. Ist sie besetzt, wartet der Aufruf bis zu warten_s Sekunden (update.py) oder
    kehrt sofort mit busy=True zurück (Recorder) -- backup.json schreibt dann nur der laufende Prozess. wenn_aelter_h: nach
    dem Warten erneut nachsehen; ist das letzte gute Backup jünger, wird es übernommen (frisch=True) statt ein zweites zu
    ziehen. Zwischendateien tragen die PID (eigenes Journal je Prozess); Reste anderer Läufe räumt nur der Sperrhalter weg.

    23.95 (U243): zuerst das Ziel prüfen (backup_ziel_fehler: Laufwerk eingehängt? FAT?), erst dann den Ordner anlegen -- beides
    ohne Ausnahme nach außen (Ergebnis mit kein_ziel=True, ohne backup.json: der Ordner fehlt oder läge auf der Systemkarte).
    Zwei Generationen der Hauptdatenbank (GENERATIONEN); ältere Stände fallen vor der Platzprüfung weg.
    """
    melden = melden or (lambda t: print(t, flush=True))
    pid = os.getpid()
    tmp = os.path.join(backup_dir, f"{BACKUP_NAME}.tmp.{pid}")
    final = os.path.join(backup_dir, BACKUP_NAME)
    info_path = os.path.join(backup_dir, "backup.json")
    t0 = time.time()
    result = {"ts": int(t0), "ok": False, "size": 0, "seconds": 0.0, "error": None}
    try:
        db_bytes = os.path.getsize(db_path)
    except OSError:
        db_bytes = None
    fehler_ziel = backup_ziel_fehler(backup_dir, db_bytes)
    if fehler_ziel is None:
        try:
            os.makedirs(backup_dir, exist_ok=True)
        except OSError as e:
            fehler_ziel = f"Backup-Ordner {backup_dir} nicht anlegbar: {e.strerror or e} — Backup übersprungen, das letzte bleibt erhalten"
    if fehler_ziel:
        result.update(error=fehler_ziel, kein_ziel=True, seconds=round(time.time() - t0, 1))
        return result

    sperre = BackupSperre(db_path, backup_dir, wer)
    naechste_meldung = 0.0
    while True:
        zustand = sperre.versuchen()
        if zustand is not False:
            break
        if time.time() - t0 >= warten_s:
            result.update(busy=True, halter=sperre.halter(),
                          error=f"läuft bereits ({sperre.halter()}) — nicht doppelt gestartet")
            result["seconds"] = round(time.time() - t0, 1)
            return result                                   # backup.json bleibt dem laufenden Prozess
        if time.time() >= naechste_meldung:
            melden(f"  wartet auf die laufende Sicherung ({sperre.halter()}) …")
            naechste_meldung = time.time() + 60
        time.sleep(2)
    if zustand is None:
        result["ohne_sperre"] = sperre.grund_ohne
        melden(f"  Hinweis: keine Sperre möglich ({sperre.grund_ohne}) — Sicherung mit eigenen Zwischendateien")
    gewartet = time.time() - t0
    schreiben = True                                        # backup.json am Ende schreiben (nicht bei übernommenem Backup)

    try:
        if wenn_aelter_h is not None:
            prev = backup_status(backup_dir) or {}
            alter = time.time() - float(prev.get("ts") or 0)
            if prev.get("ok") and alter < wenn_aelter_h * 3600:
                schreiben = False
                return {"ok": True, "frisch": True, "ts": prev.get("ts"), "size": prev.get("size", 0), "alter_h": alter / 3600,
                        "gewartet_s": round(gewartet, 1), "seconds": round(time.time() - t0, 1), "error": None}

        # Reste: der Sperrhalter räumt alle weg (auch die alte Zwischendatei ohne PID und halbe backup.json-Zwischenstände),
        # ohne Sperre nur die eigenen
        try:
            for n in os.listdir(backup_dir):
                if _BACKUP_REST.match(n) and (zustand is True or n.endswith(f".{pid}") or f".{pid}-" in n):
                    try:
                        os.remove(os.path.join(backup_dir, n))
                    except OSError:
                        pass
        except OSError:
            pass

        # 23.95 (U243): Stände über GENERATIONEN hinaus -- die .2 aus der Zeit mit drei Generationen -- VOR der Platzprüfung entfernen;
        # erst damit reicht der Platz auf der SD-Karte wieder (rund eine Datenbankgröße mehr frei)
        weg = []
        for g in range(GENERATIONEN, 10):
            p_alt = f"{final}.{g}"
            if os.path.exists(p_alt):
                try:
                    n_alt = os.path.getsize(p_alt)
                    os.remove(p_alt)
                    weg.append(f"{os.path.basename(p_alt)} ({n_alt / 1e9:.1f} GB)")
                except OSError as e:
                    melden(f"  {os.path.basename(p_alt)} nicht entfernbar: {e.strerror or e}")
        if weg:
            result["entfernt"] = weg
            melden(f"  ältere Stände entfernt (seit 23.95 zwei Generationen): {', '.join(weg)}")

        # Kopiert werden die Hauptdatenbank und die Nebendatenbanken (BACKUP_NEBEN, SQLite-Backup-API);
        # zwei Generationen der Hauptdatenbank (23.95, GENERATIONEN; bis 23.94 drei, M13). sys_history.json und WAL-Dateien bleiben
        # außen vor -- sie liegen zwar im selben Ordner, gehören aber nicht ins Backup und würden das Zielmedium füllen.
        #
        # Platzprüfung vorher: das Backup läuft oft auf die SD-Karte. Ohne Prüfung schreibt es
        # die Karte voll, und ein volles Dateisystem legt Recorder und System lahm. Nötig sind
        # die Größe der Datenbank plus 10 % Reserve (das alte Backup wird erst am Ende ersetzt,
        # es müssen also beide gleichzeitig Platz haben), dazu die Nebendatenbanken (backup_bedarf, „lauf“).
        ddir = os.path.dirname(os.path.abspath(db_path))
        try:
            need = backup_bedarf(db_path)["lauf"]
            free = shutil.disk_usage(backup_dir).free
            if free < need:
                result["error"] = (f"zu wenig Platz in {backup_dir}: {free/1e9:.1f} GB frei, "
                                   f"{need/1e9:.1f} GB nötig — Backup übersprungen, altes bleibt erhalten")
                result["no_space"] = True
                raise _BackupAbbruch()
        except OSError as e:
            print(f"  Platzprüfung nicht möglich: {e}")

        def clean_tmp():
            for suffix in ("", "-wal", "-shm", "-journal"):
                try:
                    os.remove(tmp + suffix)
                except OSError:
                    pass

        try:
            src = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=60)
            dst = sqlite3.connect(tmp)
            # In EINEM Schritt kopieren. Schrittweise mit Pausen klingt schonender,
            # führt aber in eine Endlosschleife: Verändert eine andere Verbindung die
            # Quelle zwischen zwei Schritten -- der Recorder schreibt alle 10 s --,
            # beginnt die Backup-API von vorn. Ein einzelner Schritt läuft in einer
            # Lesetransaktion und wird von Commits nicht unterbrochen (WAL-Modus:
            # Leser blockieren Schreiber nicht). Die Geschwindigkeit begrenzt dann
            # das Zielmedium, typisch 10-30 MB/s auf einer SD-Karte.
            src.backup(dst, pages=-1)
            src.close()
            check = dst.execute("PRAGMA integrity_check").fetchone()[0]
            n_bars = dst.execute("SELECT COUNT(*) FROM bars").fetchone()[0]
            dst.close()
            if check != "ok":
                clean_tmp()
                result["error"] = f"Kopie fehlerhaft: {check[:120]}"
            else:
                # M13 (Audit v10): Generationen statt einer einzigen Sicherung -- logisch falsche Daten überschreiben so nicht
                # am nächsten Tag die einzige Kopie. 23.95 (U243): GENERATIONEN = 2 -- die bisherige wird zu .1 (die vorige .1
                # fällt dabei weg), dann tritt die neue an ihre Stelle. Bis 23.94 drei Stände (.1 wurde zu .2).
                for g in range(GENERATIONEN - 1, 1, -1):          # bei zwei Generationen leer
                    if os.path.exists(f"{final}.{g - 1}"):
                        try:
                            os.replace(f"{final}.{g - 1}", f"{final}.{g}")
                        except OSError:
                            pass
                if os.path.exists(final):
                    try:
                        os.replace(final, final + ".1")
                    except OSError:
                        pass
                os.replace(tmp, final)                # atomar: alt weg, neu da
                for suffix in ("-wal", "-shm", "-journal"):   # Reste der Kopie
                    try:
                        os.remove(tmp + suffix)
                    except OSError:
                        pass
                result.update(ok=True, size=os.path.getsize(final), bars=n_bars)
                # H12 (Audit v10) forecasts.db, 23.47 (U121) makro.db, 23.66 aktien.db und ausblick.db: dieselbe Backup-API,
                # eine Generation (.1); die Zwischendatei trägt die PID wie die der Hauptdatenbank
                for name in BACKUP_NEBEN:
                    try:
                        ndb = os.path.join(ddir, f"{name}.db")
                        if not os.path.exists(ndb):
                            continue
                        ntmp = os.path.join(backup_dir, f"{name}_backup.db.tmp.{pid}")
                        nfinal = os.path.join(backup_dir, f"{name}_backup.db")
                        ns = sqlite3.connect(f"file:{ndb}?mode=ro", uri=True, timeout=60); nd = sqlite3.connect(ntmp)
                        ns.backup(nd, pages=-1); ns.close()
                        nchk = nd.execute("PRAGMA integrity_check").fetchone()[0]; nd.close()
                        if nchk == "ok":
                            if os.path.exists(nfinal):
                                os.replace(nfinal, nfinal + ".1")
                            os.replace(ntmp, nfinal); result[f"{name}_db"] = os.path.getsize(nfinal)
                        else:
                            os.remove(ntmp); result[f"{name}_db_error"] = nchk[:120]
                    except Exception as e:
                        result[f"{name}_db_error"] = str(e)
                        for suffix in ("", "-journal", "-wal", "-shm"):
                            try:
                                os.remove(os.path.join(backup_dir, f"{name}_backup.db.tmp.{pid}") + suffix)
                            except OSError:
                                pass
                for name in BACKUP_JSON:                          # 23.76 (U206): vom Nutzer gepflegte Listen aus dem Projektordner
                    quelle = os.path.join(os.path.dirname(os.path.abspath(__file__)), name)
                    if not os.path.exists(quelle):
                        continue
                    jtmp = os.path.join(backup_dir, f"{name}.tmp.{pid}")
                    try:
                        shutil.copyfile(quelle, jtmp); os.replace(jtmp, os.path.join(backup_dir, name))
                        result[name.replace(".", "_")] = os.path.getsize(os.path.join(backup_dir, name))
                    except OSError as e:
                        result[f"{name.replace('.', '_')}_error"] = str(e)
                        try:
                            os.remove(jtmp)
                        except OSError:
                            pass
        except Exception as e:
            result["error"] = str(e)
            clean_tmp()
    except _BackupAbbruch:
        pass
    finally:
        if schreiben:
            result["seconds"] = round(time.time() - t0, 1)
            if gewartet >= 1:
                result["gewartet_s"] = round(gewartet, 1)
            try:
                prev = backup_status(backup_dir) or {}
                if not result["ok"]:
                    # Das letzte gute Backup bleibt liegen -- den Zeitpunkt mitführen
                    result["last_good"] = prev.get("ts") if prev.get("ok") else prev.get("last_good")
                _json_atomar(info_path, result)
            except OSError:
                pass
        sperre.freigeben()
    return result


class _BackupAbbruch(Exception):
    """intern: Sicherung vor dem Kopieren beendet (zu wenig Platz) -- backup.json wird trotzdem geschrieben."""


def resolve_backup_dir(con: "sqlite3.Connection | None", db_path: str,
                       explicit: str | None = None) -> str:
    """
    Eine Quelle für alle: der Recorder trägt seinen Backup-Ordner in meta ein,
    Dashboard, Wächter und Audit lesen ihn dort. Vorrang: --backup-dir,
    dann meta, dann 'dbbackup' neben der Datenbank.
    """
    if explicit:
        return os.path.abspath(explicit)
    if con is not None:
        try:
            r = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
            if r and r[0]:
                return r[0]
        except sqlite3.Error:
            pass
    return os.path.join(os.path.dirname(os.path.abspath(db_path)), "dbbackup")


def device_of(path: str) -> int:
    """st_dev des nächsten existierenden Vorfahren -- auch für Pfade, die es noch nicht gibt."""
    p = os.path.abspath(path)
    while not os.path.exists(p):
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    return os.stat(p).st_dev


def same_device(a: str, b: str) -> bool:
    try:
        return device_of(a) == device_of(b)
    except OSError:
        return True


def backup_status(backup_dir: str) -> dict | None:
    p = os.path.join(backup_dir, "backup.json")
    try:
        return json.load(open(p))
    except (OSError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Audit: passen die Tabellen zueinander?
# ---------------------------------------------------------------------------

def audit(con: sqlite3.Connection) -> bool:
    """
    Prüft die Datenbank auf innere Widersprüche. Der Wächter fragt, ob die
    Daten frisch sind; hier geht es darum, ob sie *stimmen*: Ausrichtung der
    Zeitstempel, Vollständigkeit der Begleittabellen, Konsistenz zwischen
    Heatmap und Qualitätsstempel, Lebenszyklen der Wale, Duplikate.
    """
    ok_all = True
    now = int(time.time())
    OK, WARN, FAIL = "  ok   ", "  !    ", "  FEHLT"
    # 23.66 (U150): Laufzeit je Prüfung. Das Audit vom 11.10. 13:05 lief auf dem Pi 603 s; welcher Teil so lange braucht,
    # zeigte es nicht. Jede Zeile trägt jetzt die Zeit seit der vorigen (ab 1 s), am Ende stehen die drei längsten.
    t_lauf = [time.time(), time.time()]
    zeiten: list = []

    def has(t):
        return con.execute("SELECT 1 FROM sqlite_master WHERE name=?", (t,)).fetchone()

    def line(level, name, detail):
        nonlocal ok_all
        if level == FAIL:
            ok_all = False
        t_ = time.time(); dt_ = t_ - t_lauf[1]; t_lauf[1] = t_
        zeiten.append((name, dt_))
        print(f"{level} {name:<22} {detail}" + (f"  [{dt_:.0f} s]" if dt_ >= 1.0 else ""), flush=True)

    print("\nAudit der Datenbank")
    print("-" * 70)

    # --- Bars: Minutenausrichtung, Lücken
    for coin, n, mis, lo, hi in con.execute(
            "SELECT coin, COUNT(*), SUM(ts % 60 != 0), MIN(ts), MAX(ts) "
            "FROM bars GROUP BY coin"):
        span_min = (hi - lo) // 60 + 1
        gaps = span_min - n
        level = OK if mis == 0 and gaps / max(span_min, 1) < 0.05 else WARN
        line(level, f"Bars {coin}",
             f"{n:,} Kerzen, {mis} nicht minutengenau, "
             f"{gaps:,} fehlende Minuten ({gaps/max(span_min,1):.1%})")
    if not con.execute("SELECT 1 FROM bars LIMIT 1").fetchone():
        line(FAIL, "Bars", "leer")

    # --- Einheiten-Invarianten: Zeitstempel sind SEKUNDEN, Seiten sind long/short.
    # Diese Konvention lebte bisher im Kopf des jeweiligen Modells; bei jedem Wechsel wurde
    # sie neu geraten (bnc_liquidations stand bis 13.09.2026 in Millisekunden, der Selbsttest
    # bestätigte es). Hier steht sie in der Datenbank selbst. Ausnahmen bewusst in ms:
    # addresses.last_trade und addresses.first_seen.
    MS_SPALTEN = {("addresses", "last_trade"), ("addresses", "first_seen")}
    ZEITNAMEN = {"ts", "updated", "last_poll", "last_trade", "first_seen", "von", "bis", "erkannt",
                 "opened_at", "closed_at", "last_seen", "seen", "since", "until", "erstellt"}
    verletzt = []; geprueft = 0; ms_ok = 0
    for (tab,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall():
        for col in con.execute(f'PRAGMA table_info("{tab}")').fetchall():
            cname, ctype = col[1], (col[2] or "").upper()
            if cname not in ZEITNAMEN or ("INT" not in ctype and "REAL" not in ctype and ctype != ""):
                continue
            geprueft += 1
            lo, hi = con.execute(f'SELECT MIN("{cname}"), MAX("{cname}") FROM "{tab}" WHERE "{cname}" IS NOT NULL').fetchone()
            if hi is None:
                continue
            if (tab, cname) in MS_SPALTEN:
                lo_pos = con.execute(f'SELECT MIN("{cname}") FROM "{tab}" WHERE "{cname}" > 0').fetchone()[0]
                if lo_pos is not None and lo_pos < 1e11:
                    n_s = con.execute(f'SELECT COUNT(*) FROM "{tab}" WHERE "{cname}" > 0 AND "{cname}" < 1e11').fetchone()[0]
                    verletzt.append(f"{tab}.{cname}: {lo_pos:,.0f} sieht nach Sekunden aus (Spalte ist ms; {n_s:,} Zeilen)"
                                    + (" -- der Recorder rechnet sie ab 23.66 beim Start um (U149)"
                                       if (tab, cname) == ("addresses", "first_seen") else ""))
                else:
                    ms_ok += 1
            elif hi > 1e11:
                verletzt.append(f"{tab}.{cname}: {hi:,.0f} sieht nach Millisekunden aus (Spalte ist s)")
    if verletzt:
        line(FAIL, "Zeit-Einheiten", "; ".join(verletzt[:4]) + (" …" if len(verletzt) > 4 else ""))
    else:
        line(OK, "Zeit-Einheiten", f"{geprueft} Zeitspalten in Sekunden, {ms_ok} bewusste ms-Spalten")
    # 23.76 (U206): notbremse.db neben der Datenbank -- alle Zeitspalten in Sekunden (KONZEPT_Notbremse.md, Probe 16)
    try:
        dbp = con.execute("PRAGMA database_list").fetchone()[2]
        if dbp:
            import hl_notbremse
            nbp = hl_notbremse.nb_pfad(dbp)
            if os.path.exists(nbp):
                v_ = hl_notbremse.audit_zeiten(nbp)
                line(FAIL if v_ else OK, "Notbremse Zeit", "; ".join(v_[:3]) if v_ else "alle Zeitspalten von notbremse.db in Sekunden")
    except Exception as e:
        line(WARN, "Notbremse Zeit", f"nicht prüfbar: {type(e).__name__}: {e}")
    # Nur Tabellen, in denen `side` die POSITIONSSEITE meint. liquidations, lb_fills,
    # trigger_orders und ticks tragen absichtlich die Rohseite der Börse (A = Verkauf,
    # B = Kauf) -- dort wäre eine Warnung falsch.
    POSITIONS_TABELLEN = ("heatmap", "whale_positions", "lb_positions", "lb_events", "bnc_liquidations", "cluster_events", "ext_liquidations")
    fremd = []
    for tab in POSITIONS_TABELLEN:
        if not has(tab):
            continue
        if any(c[1] == "side" for c in con.execute(f'PRAGMA table_info("{tab}")').fetchall()):
            r = con.execute(f'SELECT COUNT(*) FROM "{tab}" WHERE side IS NOT NULL AND side NOT IN (\'long\',\'short\')').fetchone()[0]
            if r:
                fremd.append(f"{tab}: {r:,} Zeilen")
    if fremd:
        line(WARN, "Seiten-Werte", "nicht long/short in " + ", ".join(fremd) + " (Altbestand wird beim Lesen verstanden; neue Zeilen müssen normalisiert sein)")
    else:
        line(OK, "Seiten-Werte", "überall long/short")

    # --- Marktkontext gegen Handelspreis
    if has("ctx_bars"):
        r = con.execute("""
            SELECT b.coin, COUNT(*),
                   AVG(ABS(c.mark_px / b.close - 1)),
                   SUM(ABS(c.mark_px / b.close - 1) > 0.005)
            FROM bars b JOIN ctx_bars c ON c.ts = b.ts AND c.coin = b.coin
            WHERE c.mark_px > 0 GROUP BY b.coin""").fetchall()
        if not r:
            line(WARN, "Markpreis", "noch keine ctx_bars — Feed activeAssetCtx aktiv?")
        for coin, n, dev, big in r:
            nb = con.execute("SELECT COUNT(*) FROM bars WHERE coin=?", (coin,)).fetchone()[0]
            level = OK if big / max(n, 1) < 0.02 and n / max(nb, 1) > 0.8 else WARN
            line(level, f"Markpreis {coin}",
                 f"{n:,} von {nb:,} Minuten, Ø Abweichung zum Trade "
                 f"{dev*100:.3f} %, {big} Minuten über 0,5 %")

    # --- Heatmap gegen Qualitätsstempel: Positionszahl muss exakt übereinstimmen
    if has("snapshot_meta"):
        r = con.execute("""
            SELECT COUNT(*),
                   SUM(m.ts IS NULL),
                   SUM(m.ts IS NOT NULL AND h.n != m.n_positions)
            FROM (SELECT ts, SUM(n_pos) AS n FROM heatmap GROUP BY ts) h
            LEFT JOIN snapshot_meta m ON m.ts = h.ts""").fetchone()
        n, no_meta, mismatch = r
        if n:
            level = OK if no_meta == 0 and mismatch == 0 else (WARN if mismatch == 0 else FAIL)
            line(level, "Snapshot-Konsistenz",
                 f"{n:,} Snapshots, {no_meta} ohne Stempel, "
                 f"{mismatch} mit abweichender Positionszahl")
        else:
            line(WARN, "Snapshot-Konsistenz", "noch keine Snapshots")

        # Snapshot-Abstände
        ts = [r[0] for r in con.execute("SELECT ts FROM snapshot_meta ORDER BY ts")]
        if len(ts) > 2:
            d = sorted(b - a for a, b in zip(ts, ts[1:]))
            med = d[len(d) // 2]
            odd = sum(1 for x in d if x > med * 1.5 or x < med * 0.5)
            line(OK if odd / len(d) < 0.05 else WARN, "Snapshot-Takt",
                 f"Median {med//60} min, {odd} von {len(d)} Abstände unregelmäßig")
            restarts = con.execute(
                "SELECT COUNT(*) FROM snapshot_meta WHERE uptime < 900").fetchone()[0]
            line(OK, "Neustarts", f"{restarts} Snapshots innerhalb 15 min nach Start "
                                  "(in der Auswertung ausschließbar)")

    # --- Abdeckung
    if has("coverage"):
        for coin, n, avg, mx in con.execute(
                "SELECT coin, COUNT(*), AVG(ratio), MAX(ratio) FROM coverage GROUP BY coin"):
            level = OK if mx <= 1.2 and avg >= 0.25 else WARN
            line(level, f"Abdeckung {coin}",
                 f"{n:,} Messungen, Ø {avg*100:.0f} %, max {mx*100:.0f} %"
                 + ("  — über 120 % deutet auf falsches OI oder Doppelzählung" if mx > 1.2 else "")
                 + ("  — unter 25 % kaum repräsentativ" if avg < 0.25 else ""))
        if not con.execute("SELECT 1 FROM coverage LIMIT 1").fetchone():
            line(WARN, "Abdeckung", "noch keine Messung — braucht ctx_bars mit OI")

    # --- Adressen
    r = con.execute("""SELECT COUNT(*), SUM(last_poll = 0), SUM(pos_value > 0),
                              SUM(pos_value >= 20000000)
                       FROM addresses""").fetchone()
    if r[0]:
        never = r[1] or 0
        line(OK if never / r[0] < 0.5 else WARN, "Adressen",
             f"{r[0]:,} bekannt, {never:,} nie abgefragt ({never/r[0]:.0%}), "
             f"{r[2] or 0:,} mit Position, {r[3] or 0} Wale")

    # --- Wal-Lebenszyklen: kein open auf open, kein close ohne open -- 23.66 (U150) mit Einordnung je Fall
    if has("whale_positions"):
        wl = wal_lebenszyklen(con)
        n = wl["n"]
        if n:
            z = {art: {kat: len(v) for kat, v in wl["faelle"][art].items()} for art in wl["faelle"]}
            d_, o_ = sum(z["doppelt"].values()), sum(z["ohne_open"].values())
            sonst_, neu_ = z["doppelt"]["sonst"] + z["ohne_open"]["sonst"], z["doppelt"]["neustart"] + z["ohne_open"]["neustart"]
            level = FAIL if sonst_ else (WARN if neu_ else OK)
            line(level, "Wal-Lebenszyklen",
                 f"{n:,} Ereignisse, {d_} doppelte Eröffnungen, {o_} Änderungen ohne Eröffnung"
                 + (f" — Konten mit Sperrgeschichte (H3, gewollt) {z['doppelt']['sperre']} + {z['ohne_open']['sperre']}, "
                    f"Neustart dazwischen {z['doppelt']['neustart']} + {z['ohne_open']['neustart']}, "
                    f"ohne Erklärung {z['doppelt']['sonst']} + {z['ohne_open']['sonst']}" if d_ or o_ else ""))
            for kat, titel in (("sonst", "ohne Erklärung"), ("neustart", "Neustart dazwischen"), ("sperre", "Sperrgeschichte")):
                bsp = (wl["faelle"]["doppelt"][kat] + wl["faelle"]["ohne_open"][kat])[:3]
                if bsp:
                    print(f"{'':31}{titel}: " + " · ".join(wal_fall_text(b) for b in bsp), flush=True)
        else:
            line(OK, "Wal-Lebenszyklen", "noch keine Wal-Ereignisse")

    # --- Liquidationen
    r = con.execute("""SELECT COUNT(*), SUM(side NOT IN ('A','B')),
                              SUM(px <= 0 OR sz <= 0) FROM liquidations""").fetchone()
    if r[0]:
        src = dict(con.execute("SELECT CASE WHEN method='inferred' THEN 'abgeleitet' ELSE 'beobachtet' END, COUNT(*) "
                               "FROM liquidations GROUP BY 1").fetchall())
        line(OK if not r[1] and not r[2] else WARN, "Liquidationen",
             f"{r[0]:,} Ereignisse ({src.get('beobachtet', 0)} beobachtet via userEvents, "
             f"{src.get('abgeleitet', 0)} aus dem Polling abgeleitet), {r[1] or 0} mit unbekannter Seite, "
             f"{r[2] or 0} mit ungültigem Preis/Menge")
    else:
        bars_age = con.execute("SELECT MAX(ts) - MIN(ts) FROM bars").fetchone()[0] or 0
        line(WARN if bars_age > 86400 else OK, "Liquidationen",
             "keine — der öffentliche Trade-Feed kennzeichnet keine; Quellen sind userEvents-Abos "
             "und die Ableitung aus dem Polling (beide ab Recorder-Version vom 8.9.)")

    # --- Cluster-Events: Duplikate, Bezug zu Snapshots
    if has("cluster_events"):
        n = con.execute("SELECT COUNT(*) FROM cluster_events").fetchone()[0]
        if n:
            dup = n - con.execute(
                "SELECT COUNT(*) FROM (SELECT DISTINCT ts, coin, cluster_px, side "
                "FROM cluster_events)").fetchone()[0]
            orphan = con.execute(
                "SELECT COUNT(*) FROM cluster_events e WHERE NOT EXISTS "
                "(SELECT 1 FROM heatmap h WHERE h.ts = e.ts AND h.coin = e.coin)").fetchone()[0]
            line(OK if dup == 0 and orphan == 0 else FAIL, "Cluster-Events",
                 f"{n:,} Ereignisse, {dup} Duplikate, {orphan} ohne Snapshot")

    # --- Backup
    # 23.66 (U150): Alter gegen die Uhr JETZT (alter_s), nicht gegen den Start des Audits. Am 11.10. lief es 10 min, Zeilen
    # von währenddessen erschienen als „jüngste vor -10 min“ (Wal-Orders, Order-Niveaus, Orderbuch, 10-s-Bars).
    def alter_s(ts_) -> int:
        return int(time.time()) - int(ts_)

    bdir = resolve_backup_dir(con, DB_PATH)
    st = backup_status(bdir)
    if st and st.get("ok"):
        age_h = alter_s(st["ts"]) / 3600
        line(OK if age_h < 26 else WARN, "Backup",
             f"vor {age_h:.1f} h, {st['size']/1e6:.0f} MB, "
             f"{st.get('bars', 0):,} Bars in {bdir}/{BACKUP_NAME}")
    elif st:
        lg = st.get("last_good")
        line(WARN, "Backup", f"letzter Versuch fehlgeschlagen: {st.get('error')}"
             + (f" — gutes Backup von vor {alter_s(lg)/3600:.1f} h liegt noch vor" if lg else ""))
    elif backup_ziel_fehler(bdir):                      # 23.95 (U243): Laufwerk des Backup-Ordners nicht eingehängt
        line(WARN, "Backup", backup_ziel_fehler(bdir).split(";")[0])
    else:
        line(WARN, "Backup", "noch keines — läuft 5 min nach Recorder-Start, dann täglich")
    gens_ = backup_generationen(bdir)                   # 23.95 (U243): Stände der Hauptdatenbank (gehalten werden GENERATIONEN)
    if len(gens_) > GENERATIONEN:
        line(OK, "Backup-Stände", f"{len(gens_)} liegen, gehalten werden {GENERATIONEN} -- ältere entfallen beim nächsten Lauf")

    # --- Wal-Orders
    if has("trigger_orders"):
        r = con.execute("""SELECT COUNT(DISTINCT addr), SUM(kind LIKE 'stop_%'), SUM(kind LIKE 'tp_%'),
                                  MAX(ts) FROM trigger_orders WHERE ts > ?""", (int(time.time()) - 1200,)).fetchone()
        if r[0]:
            line(OK, "Wal-Orders", f"{r[0]} Wale in den letzten 20 min, {r[1] or 0} Stops, "
                                   f"{r[2] or 0} Take-Profits, jüngste vor {alter_s(r[3])//60} min")
        else:
            line(WARN, "Wal-Orders", "keine Abfrage in den letzten 20 min — Recorder älter als 2 min?")
    api = dict(con.execute("SELECT k, v FROM meta WHERE k IN ('api_weight_1m','api_weight_budget')"))
    if "api_weight_1m" in api:
        used, budget = int(api["api_weight_1m"]), int(api.get("api_weight_budget", 1200))
        line(OK if used < budget * 0.8 else WARN, "API-Budget",
             f"{used} von {budget} Gewicht/min ({used / budget * 100:.0f} %)")

    if has("order_levels"):
        r = con.execute("SELECT COUNT(*), MAX(ts), COUNT(DISTINCT coin) FROM order_levels").fetchone()
        if r[0]:
            a_ = alter_s(r[1])
            line(OK if a_ < 1800 else WARN, "Order-Niveaus",
                 f"{r[0]:,} Snapshots für {r[2]} Coins, jüngster vor {a_//60} min")
        else:
            line(WARN, "Order-Niveaus", "noch keine — entstehen mit dem ersten Snapshot nach Order-Abfragen")

    # --- Orderbuch-Kennzahlen
    if has("book_summary"):
        r = con.execute("SELECT COUNT(*), MAX(ts), SUM(spread_bps <= 0 OR bid_50 < 0) "
                        "FROM book_summary").fetchone()
        if r[0]:
            age = alter_s(r[1]) // 60
            line(OK if age < 10 and not r[2] else WARN, "Orderbuch",
                 f"{r[0]:,} Kennzahlen, jüngste vor {age} min, {r[2] or 0} ungültig")
        else:
            line(WARN, "Orderbuch", "noch keine Kennzahlen — Feed l2Book aktiv?")
    if has("bars10"):
        r = con.execute("SELECT COUNT(*), MAX(ts) FROM bars10").fetchone()
        if r[0]:
            a_ = alter_s(r[1])
            line(OK if a_ < 300 else WARN, "10-s-Bars",
                 f"{r[0]:,} Bars, jüngste vor {a_//60} min")

    # --- Tick-Aufzeichnungen
    if has("tick_events"):
        r = con.execute("""SELECT COUNT(*), SUM(complete = 0), SUM(n_ticks = 0),
                                  MIN(n_ticks), AVG(n_ticks) FROM tick_events""").fetchone()
        if r[0]:
            level = OK if not r[1] and not r[2] else WARN
            line(level, "Tick-Aufzeichnungen",
                 f"{r[0]} Ereignisse, {r[1] or 0} unvollständig, {r[2] or 0} leer, "
                 f"Ø {r[4]:,.0f} Ticks")
        else:
            line(OK, "Tick-Aufzeichnungen", "noch keine — löst bei 1 %/60 s, "
                                            "0,4 %/10 s oder 5 Liqs/30 s aus")

    # --- Binance
    for t, label in (("bnc_liquidations", "Binance Liqs"), ("bnc_metrics", "Binance Metriken")):
        if has(t):
            r = con.execute(f"SELECT COUNT(*), MAX(ts) FROM {t}").fetchone()
            if r[0]:
                ts_s = r[1] // 1000 if r[1] > 1e11 else r[1]
                age = (int(time.time()) - ts_s) // 60
                line(OK if age < 120 else WARN, label, f"{r[0]:,} Zeilen, jüngste vor {age} min")

    print("-" * 70)
    gesamt_ = time.time() - t_lauf[0]
    lang_ = [z_ for z_ in sorted(zeiten, key=lambda z_: -z_[1])[:3] if z_[1] >= 1.0]
    print(f"Laufzeit {gesamt_:.0f} s" + ("; am längsten: " + ", ".join(f"{n_} {d_:.0f} s" for n_, d_ in lang_) if lang_ else ""))
    print("Ergebnis:", "keine Widersprüche gefunden" if ok_all
          else "FEHLER gefunden — Details oben")
    return ok_all


def wal_lebenszyklen(con: sqlite3.Connection) -> dict:
    """
    23.66 (U150): Lebenszyklen der Wal-Positionen nachspielen (ohne Schnappschüsse) und jede Unstimmigkeit einordnen.
      doppelt     open auf eine offene Position
      ohne_open   add, reduce, flip oder close auf eine Position, die nicht offen ist
    Einordnung je Fall, in dieser Reihenfolge (Audit 11.10. 13:05: 54 + 6 bei 95.497 Ereignissen, Hinweis damals
    „typisch für Neustart ohne Wiederherstellung“, obwohl die Wiederherstellung seit 23.36 läuft):
      sperre      das Konto hat eine Sperrgeschichte (konto_status: gesperrt, vorläufig oder wieder frei; labels.json
                  "sperre": true). Gesperrte schreiben weder open noch close, nur Schnappschüsse (H3, Audit v10): Wer
                  öffnet, gesperrt wird, unbemerkt schließt und nach der Freigabe neu öffnet, hat zwei opens. Gewollt.
      neustart    zwischen der vorigen Zeile der Position (auch Schnappschuss) und dem Fall startete der Recorder
                  (snapshot_meta: Start = ts − uptime bei uptime < 900 s) -- die Wiederherstellung hat ihn nicht aufgefangen
      sonst       keins von beidem: ein Fehler der Ereignislogik
    Rückgabe: {"n": Ereignisse, "faelle": {art: {kat: [Fall, ...]}}}; Fall = (addr, coin, voriges Ereignis, seine Zeit, Ereignis, Zeit).
    """
    import bisect
    faelle = {art: {"sperre": [], "neustart": [], "sonst": []} for art in ("doppelt", "ohne_open")}
    roh: list = []
    state: dict = {}
    n = 0
    for ts, addr, coin, ev in con.execute(
            "SELECT ts, addr, coin, event FROM whale_positions WHERE event != 'snap' ORDER BY ts, addr, coin"):
        n += 1
        k = (addr, coin)
        offen, v_ev, v_ts = state.get(k, (False, None, None))
        if ev == "open":
            if offen:
                roh.append(("doppelt", addr, coin, v_ev, v_ts, ev, ts))
            state[k] = (True, ev, ts)
        elif ev == "close":
            if not offen:
                roh.append(("ohne_open", addr, coin, v_ev, v_ts, ev, ts))
            state[k] = (False, ev, ts)
        else:                                                      # add, reduce, flip
            if not offen:
                roh.append(("ohne_open", addr, coin, v_ev, v_ts, ev, ts))
            state[k] = (True, ev, ts)
    if not roh:
        return {"n": n, "faelle": faelle}
    sperre: set = set()
    try:
        sperre = {str(r[0]).lower() for r in con.execute("SELECT addr FROM konto_status")}
    except sqlite3.OperationalError:
        pass
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels.json"), encoding="utf-8") as f:
            lab = json.load(f)
        sperre |= {a.lower() for a, v in lab.items() if isinstance(v, dict) and v.get("sperre")}
    except (OSError, ValueError, AttributeError):
        pass
    try:
        starts = sorted({int(t_ - (u_ or 0)) for t_, u_ in con.execute("SELECT ts, uptime FROM snapshot_meta WHERE uptime < 900")})
    except sqlite3.OperationalError:
        starts = []
    for art, addr, coin, v_ev, v_ts, ev, ts in roh:
        if str(addr).lower() in sperre:
            kat = "sperre"
        else:
            vorher = con.execute("SELECT MAX(ts) FROM whale_positions WHERE addr=? AND coin=? AND ts < ?",
                                 (addr, coin, ts)).fetchone()[0]
            i_ = bisect.bisect_right(starts, int(vorher)) if vorher is not None else None
            kat = "neustart" if i_ is not None and i_ < len(starts) and starts[i_] <= ts else "sonst"
        faelle[art][kat].append((addr, coin, v_ev, v_ts, ev, ts))
    return {"n": n, "faelle": faelle}


def wal_fall_text(f: tuple) -> str:
    """Ein Fall aus wal_lebenszyklen kurz: 0xabcd…1234 BTC open 21.09. 23:10 → open 28.09. 14:02 UTC."""
    addr, coin, v_ev, v_ts, ev, ts = f
    zt = lambda t_: time.strftime("%d.%m. %H:%M", time.gmtime(int(t_)))
    a_ = str(addr)
    return (f"{a_[:6]}…{a_[-4:]} {coin} " + (f"{v_ev} {zt(v_ts)}" if v_ev else "ohne Vorereignis")
            + f" → {ev} {zt(ts)} UTC")


def datetime_utc(ts) -> str | None:
    if not ts:
        return None
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts))


def status(con: sqlite3.Connection) -> None:
    q = lambda s: con.execute(s).fetchone()
    print("Datenbank:", DB_PATH, f"({os.path.getsize(DB_PATH)/1e6:.1f} MB)")
    print(f"  Adressen           {q('SELECT COUNT(*) FROM addresses')[0]:,}")
    print(f"  davon mit Position {q('SELECT COUNT(*) FROM addresses WHERE notional>0')[0]:,}")
    print(f"  Heatmap-Zeilen     {q('SELECT COUNT(*) FROM heatmap')[0]:,}")
    print(f"  Bars               {q('SELECT COUNT(*) FROM bars')[0]:,}")
    print(f"  Liquidationen      {q('SELECT COUNT(*) FROM liquidations')[0]:,}")
    now = int(time.time())
    ages = sorted(now - r[0] for r in con.execute(
        "SELECT last_poll FROM addresses WHERE notional > 0 AND last_poll > 0"))
    if ages:
        print(f"  Datenalter Median  {ages[len(ages)//2]//60} min")
        print(f"  Datenalter 90%     {ages[int(len(ages)*0.9)]//60} min")
        if ages[int(len(ages)*0.9)] > 3600:
            print("  -> über eine Stunde alt: der Poller hängt hinterher")
    r = q("SELECT MIN(ts), MAX(ts) FROM bars")
    if r[0]:
        span = (r[1] - r[0]) / 86400
        print(f"  Zeitraum           {span:.1f} Tage")
        if span < 14:
            print("  -> für belastbare Statistik deutlich zu wenig")


# ---------------------------------------------------------------------------

def event_subs_aus(wert) -> int:
    """23.75 (Audit v10 vom 22.10., H-1): ohne Angabe auf der Befehlszeile gilt die Einstellung (10). Bis 23.74 stand dort
    der Standard 600 und überschrieb sie -- eigener Fehler aus der Korrektur K1 vom 22.09."""
    return Settings.max_event_subs if wert is None else max(0, int(wert))


def parser_bauen() -> argparse.ArgumentParser:
    """23.75: die Befehlszeile als eigene Funktion -- der Selbsttest prüft ihre Standardwerte (Audit v10 H-1)."""
    p = argparse.ArgumentParser(description="Hyperliquid Liquidations-Recorder")
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"])
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--bucket-pct", type=float, default=0.0025)
    p.add_argument("--snapshot-sec", type=int, default=600,
                   help="Abstand der Heatmap-Snapshots in Sekunden")
    p.add_argument("--flush-sec", type=int, default=10,
                   help="Commit-Takt in Sekunden")
    p.add_argument("--durable", action="store_true",
                   help="synchronous=FULL: kein Verlust bei Stromausfall, "
                        "dafür mehr Schreibzugriffe")
    p.add_argument("--no-discover-all", action="store_true",
                   help="Adressen nur aus den verfolgten Coins sammeln")
    p.add_argument("--max-pos-age", type=int, default=3600,
                   help="ältere Positionsdaten gehen nicht in den Snapshot (Sekunden)")
    p.add_argument("--tick-move", type=float, default=0.010,
                   help="Tick-Auslöser: Bewegung in 60 s, Anteil (0.01 = 1 %%)")
    p.add_argument("--tick-flash", type=float, default=0.004,
                   help="Tick-Auslöser: Bewegung in 10 s")
    p.add_argument("--tick-liqs", type=int, default=5,
                   help="Tick-Auslöser: Liquidations-Fills in 30 s")
    p.add_argument("--tick-pre", type=int, default=300, help="Vorlauf in Sekunden")
    p.add_argument("--stop-interval", type=int, default=600,
                   help="Sekunden zwischen zwei Order-Abfragen je Wal (Gewicht 20)")
    p.add_argument("--max-event-subs", type=int, default=None,
                   help="userEvents-Abos (Standard 10: Hyperliquid erlaubt höchstens 10 verschiedene Nutzer je IP; 23.75, Audit v10 H-1)")
    p.add_argument("--stop-min-usd", type=float, default=2.5e5,
                   help="Konten ab diesem Positionswert nach Orders fragen (Wale immer)")
    p.add_argument("--stop-budget", type=int, default=320,
                   help="Gewicht/min für Wal-Order-Abfragen (0 = aus)")
    p.add_argument("--tick-post", type=int, default=600, help="Nachlauf in Sekunden")
    p.add_argument("--polls-per-min", type=int, default=DEFAULT_POLLS_PER_MIN,
                   help="Abfragebudget; clearinghouseState hat Gewicht 2 bei 1200/min")
    p.add_argument("--hot-refresh", type=int, default=180,
                   help="Abstand für große Positionen in Sekunden")
    p.add_argument("--cold-refresh", type=int, default=1800,
                   help="Abstand für kleine Positionen in Sekunden")
    p.add_argument("--whale-notional", type=float, default=20_000_000,
                   help="Polling-Stufe: ab diesem Kontowert (USD) alle 60 s abgefragt")
    p.add_argument("--lb-top", type=int, default=75, help="Leaderboard: so viele Konten mit Perp-Positionen verfolgen")
    p.add_argument("--lb-candidates", type=int, default=600, help="Leaderboard: aus den besten N nach 30-Tage-PnL auswählen")
    p.add_argument("--event-min-usd", type=float, default=25_000, help="Wal-Ereignis ab dieser gehandelten Menge (USD)")
    p.add_argument("--lb-event-min-usd", type=float, default=12_500, help="Leaderboard-Ereignis ab dieser gehandelten Menge (USD)")
    p.add_argument("--lb-fills-weight", type=int, default=6_000, help="Gewichtsbudget je stündlichem Fill-Lauf")
    p.add_argument("--af-tage", type=int, default=14, help="Adress-Strom (adressfluss.db neben der Datenbank): Vorhalt in Tagen, 0 = aus")
    p.add_argument("--af-max-gb", type=float, default=3.0, help="Adress-Strom: Deckel in GB, darüber werden die ältesten Stunden gelöscht")
    p.add_argument("--lb-interval", type=int, default=120, help="Leaderboard: Abfragetakt in Sekunden (bei freiem Budget bis 90 s)")
    p.add_argument("--whale-track", type=float, default=10_000_000,
                   help="Wal-Tabelle: Konto ab diesem Gesamtwert (USD) wird verfolgt")
    p.add_argument("--whale-pos-min", type=float, default=1_000_000,
                   help="von einem Wal werden Positionen ab diesem Wert (USD) protokolliert")
    p.add_argument("--whale-refresh", type=int, default=60,
                   help="Abstand für Wale in Sekunden")
    p.add_argument("--hot-notional", type=float, default=500_000,
                   help="ab welchem Positionswert eine Adresse als groß gilt (23.86, U220: 500.000; bis 23.85: 250.000)")
    p.add_argument("--min-notional", type=float, default=25_000,
                   help="darunter „klein“: nur nach eigenem Handel, sonst höchstens täglich (mit --klein-regelmaessig alle 2 Stunden)")
    p.add_argument("--vorrang-ab", type=float, default=25_000,
                   help="23.86: leere und kleine Konten, die seit ihrer letzten Abfrage mindestens so viel USD gehandelt haben, vor alle "
                        "fälligen Konten von Rang 1 (0 = aus)")
    p.add_argument("--klein-regelmaessig", action="store_true",
                   help="23.86 (U220): kleine Konten wieder regelmäßig alle 4 × cold-refresh abfragen (wie bis 23.85) statt nur nach eigenem Handel")
    p.add_argument("--analyze", action="store_true")
    p.add_argument("--coin", default="BTC", help="Coin für --analyze")
    p.add_argument("--min-x-vol", type=float, default=0.5)
    p.add_argument("--max-gap", type=int, default=120,
                   help="größter erlaubter Abstand Snapshot zu Kursbar in Sekunden")
    p.add_argument("--simulate", action="store_true")
    p.add_argument("--selbsttest-fills", action="store_true", help="23.34: Fills der Darwin-Liste ohne Mindestbetrag prüfen (temporäre Datenbank)")
    p.add_argument("--selbsttest-bars", action="store_true", help="23.82 (U222): späte und doppelte Trades in Minuten-Bars und 10-s-Stücken")
    p.add_argument("--selbsttest-start", action="store_true", help="23.36: Wal-Zustand beim Start (24-h-Fenster, Gleichstände, Gesperrte) prüfen (temporäre Datenbank)")
    p.add_argument("--selbsttest-sperre", action="store_true", help="23.37: Masterregel ohne Kleinfills der Darwin-Liste, Neubewertung der Sperren seit 29.09. (temporäre Datenbank)")
    p.add_argument("--selbsttest-gewicht", action="store_true", help="23.38: API-Gewicht hart gedeckelt (Begrenzer in virtueller Zeit, Last vom 30.09.)")
    p.add_argument("--status", action="store_true")
    p.add_argument("--audit", action="store_true",
                   help="Datenbank auf innere Widersprüche prüfen")
    p.add_argument("--backup", action="store_true",
                   help="sofort ein verifiziertes Backup erstellen")

    p.add_argument("--backup-dir", default=None,
                   help="Zielordner, Standard: dbbackup neben der Datenbank")
    p.add_argument("--backup-warten", type=float, default=0,
                   help="23.66 (U145): so viele Sekunden auf eine laufende Sicherung derselben Datenbank warten (update.py: 5400)")
    p.add_argument("--backup-wenn-aelter", type=float, default=None,
                   help="23.66 (U145): nur sichern, wenn das letzte gute Backup älter ist als so viele Stunden (sonst übernehmen)")
    p.add_argument("--backup-wer", default="hl_recorder.py --backup",
                   help="23.66: Name in der Sperrdatei (wer sichert gerade)")
    p.add_argument("--selbsttest-backup", action="store_true",
                   help="23.66 (U145): mehrere Sicherungen gleichzeitig -- Sperre, Zwischendateien, backup.json (temporärer Ordner)")
    p.add_argument("--selbsttest-v10", action="store_true",
                   help="23.75 (Audit v10 vom 22.10.): Abo-Grenze 10 auch ohne Befehlszeile, Messung der Fill-Nacharbeit (temporäre Datenbank)")
    p.add_argument("--selbsttest-ausgelassen", action="store_true",
                   help="23.112 (U272): Größe der wegen Alters ausgelassenen Positionen je Coin im Meta-Wert 'ausgelassen' (temporäre Datenbank)")
    p.add_argument("--selbsttest-symbole", action="store_true",
                   help="23.97 (U250): Zuordnung Coin -> Symbol und Dex in meta['symbole'], gelesen von der Notbremse (temporäre Datenbank)")
    p.add_argument("--selbsttest-impact", action="store_true",
                   help="23.96 (U246): Impact-Preise der Börse je Minute in impact_bars, ctx_bars unverändert (temporäre Datenbank)")
    p.add_argument("--selbsttest-poller", action="store_true",
                   help="23.86 (U220): Auswahl des Pollers -- Gesperrte nie, „groß“ ab 500.000, kleine nach eigenem Handel, Statuszeile wie der Bericht")
    p.add_argument("--selbsttest-tiefe", action="store_true",
                   help="23.125 (U311): Tiefe des Buchs bis ±1 % -- Stellen, Summen, Aufgabe, Schreiben, Bericht (temporäre Datenbank)")
    p.add_argument("--tiefe-text", action="store_true", help="23.125 (U311): Bericht Tiefe des Buchs bis ±1 % (Debug 165, liest nur)")
    p.add_argument("--selbsttest-waechter", action="store_true",
                   help="23.126 (U287): Hänger-Schutz -- Lebenszeichen an systemd, Anlauf, Abzug und Abbruch mit nachgebautem systemd (Debug 167)")
    p.add_argument("--selbsttest-audit", action="store_true",
                   help="23.66 (U149, U150): first_seen in ms, Umrechnung, Audit der Wal-Lebenszyklen mit Einordnung, Audit-Uhr (temporäre Datenbank)")
    p.add_argument("--magnet-analyze", action="store_true",
                   help="Kernthese prüfen: zieht das größere Cluster den Kurs an?")
    p.add_argument("--magnet-range", type=float, default=0.06,
                   help="Suchbereich für Cluster ober-/unterhalb, Anteil vom Kurs")
    p.add_argument("--magnet-step", type=int, default=60,
                   help="Abstand der Prüfzeitpunkte in Minuten")
    p.add_argument("--whale-analyze", action="store_true",
                   help="Vorhersagekraft von Wal-Aktionen gegen Kontrollgruppe prüfen")
    p.add_argument("--with-ticks", action="store_true",
                   help="beim Export auch die Tick-Aufzeichnungen mitgeben (groß)")
    p.add_argument("--export", metavar="DATEI.zip",
                   help="Ereignisse und Kennzahlen als kompaktes ZIP ausgeben")
    return p


def main() -> None:
    global DB_PATH
    p = parser_bauen()
    args = p.parse_args()
    lebenszeichen_start(args.db)                 # 23.126 (U287): nur im Dienst mit Wächter von systemd (WATCHDOG_PID = dieser Prozess)
    if args.selbsttest_v10:
        sys.exit(0 if selbsttest_audit_v10() else 1)
    if args.selbsttest_poller:
        sys.exit(0 if selbsttest_poller_u220() else 1)
    if args.selbsttest_impact:
        sys.exit(0 if selbsttest_impact() else 1)
    if args.selbsttest_symbole:
        sys.exit(0 if selbsttest_symbole() else 1)
    if args.selbsttest_ausgelassen:
        sys.exit(0 if selbsttest_ausgelassen() else 1)
    if args.selbsttest_bars:
        sys.exit(0 if selbsttest_bars_u222() else 1)
    if args.selbsttest_fills:
        sys.exit(0 if selbsttest_darwin_fills() else 1)
    if args.selbsttest_start:
        sys.exit(0 if selbsttest_wal_start() else 1)
    if args.selbsttest_sperre:
        sys.exit(0 if selbsttest_sperre_kleinfills() else 1)
    if args.selbsttest_gewicht:
        sys.exit(0 if selbsttest_gewicht() else 1)
    if args.selbsttest_backup:
        sys.exit(0 if selbsttest_backup() else 1)
    if args.selbsttest_audit:
        sys.exit(0 if selbsttest_adressen_audit() else 1)
    if args.selbsttest_tiefe:
        sys.exit(0 if selbsttest_tiefe() else 1)
    if args.selbsttest_waechter:
        sys.exit(0 if selbsttest_waechter() else 1)
    if args.tiefe_text:                         # 23.125 (U311, Debug 165): nur lesend -- nicht über db_connect (legt das Schema an)
        print(tiefe_text_datei(args.db)); return

    DB_PATH = args.db
    con = db_connect(DB_PATH, "FULL" if getattr(args, "durable", False) else "NORMAL")

    if args.status:
        status(con); return
    backup_dir = resolve_backup_dir(con, DB_PATH, args.backup_dir)
    if speicher_einstellung().get("backup_dir"):          # 23.23: die Einstellung im Dashboard hat Vorrang
        backup_dir = os.path.abspath(speicher_einstellung()["backup_dir"])
        try:
            con.execute("INSERT OR REPLACE INTO meta VALUES ('backup_dir', ?)", (backup_dir,)); con.commit()
        except sqlite3.Error:
            pass
    same_disk = same_device(os.path.dirname(os.path.abspath(DB_PATH)), backup_dir)
    if args.backup:
        if args.backup_dir:
            con.execute("INSERT OR REPLACE INTO meta VALUES ('backup_dir', ?)", (backup_dir,))
            con.commit()
        con.close()
        if same_disk:
            print("Hinweis: Backup liegt auf demselben Datenträger wie die Datenbank "
                  "— schützt vor Beschädigung, nicht vor Ausfall des Mediums.")
        res = do_backup(DB_PATH, backup_dir, warten_s=args.backup_warten, wenn_aelter_h=args.backup_wenn_aelter,
                        wer=args.backup_wer)
        if res.get("frisch"):
            print(f"Backup vor {res['alter_h']:.1f} h vorhanden ({backup_dir}) — kein neues nötig"
                  + (f" (nach {res['gewartet_s']/60:.0f} min Warten auf die laufende Sicherung übernommen)"
                     if res.get("gewartet_s", 0) >= 60 else ""))
            sys.exit(0)
        if res.get("busy"):
            print(f"Backup nicht gestartet: {res['error']}")
            sys.exit(3)
        if res["ok"]:
            print(f"Backup ok: {res['size']/1e6:.1f} MB, {res.get('bars', 0):,} Bars, "
                  f"{res['seconds']} s -> {backup_dir}/{BACKUP_NAME}"
                  + (f" (vorher {res['gewartet_s']/60:.0f} min auf eine laufende Sicherung gewartet)"
                     if res.get("gewartet_s", 0) >= 60 else ""))
        else:
            print(f"Backup FEHLGESCHLAGEN: {res['error']}")
        sys.exit(0 if res["ok"] else 1)
    if args.audit:
        sys.exit(0 if audit(con) else 1)
    if args.magnet_analyze:
        magnet_analyze(con, args.coin, range_pct=args.magnet_range,
                       min_x_vol=args.min_x_vol, step_min=args.magnet_step,
                       max_gap=args.max_gap); return
    if args.whale_analyze:
        whale_analyze(con, args.coin); return
    if args.export:
        export_bundle(con, args.export, args.coin if args.coin != "BTC" or
                      "--coin" in sys.argv else None, args.with_ticks)
        return
    if args.simulate:
        simulate(con); return
    if args.analyze:
        analyze(con, args.coin, args.min_x_vol, max_gap=args.max_gap); return

    if args.polls_per_min > 500:
        print(f"--polls-per-min {args.polls_per_min} überschreitet das Hyperliquid-Limit "
              "(1200 Gewicht/min, je Abfrage 2). Gedeckelt auf 500.")
        args.polls_per_min = 500
    cfg = Settings(coins=args.coins, bucket_pct=args.bucket_pct,
                   snapshot_sec=args.snapshot_sec, polls_per_min=args.polls_per_min,
                   hot_refresh=args.hot_refresh, cold_refresh=args.cold_refresh,
                   hot_notional=args.hot_notional, flush_sec=args.flush_sec,
                   klein_nach_handel=not args.klein_regelmaessig, vorrang_usd=args.vorrang_ab,
                   whale_notional=args.whale_notional, whale_refresh=args.whale_refresh,
                   whale_track=args.whale_track, whale_pos_min=args.whale_pos_min,
                   lb_top=args.lb_top, lb_interval=args.lb_interval, lb_candidates=args.lb_candidates,
                   event_min_usd=args.event_min_usd, lb_event_min_usd=args.lb_event_min_usd,
                   lb_fills_weight=args.lb_fills_weight,
                   min_notional=args.min_notional,
                   synchronous="FULL" if args.durable else "NORMAL",
                   discover_all=not args.no_discover_all,
                   max_pos_age=args.max_pos_age,
                   tick_move_pct=args.tick_move, tick_flash_pct=args.tick_flash,
                   tick_liq_burst=args.tick_liqs, tick_pre_sec=args.tick_pre,
                   tick_post_sec=args.tick_post, backup_dir=backup_dir,
                   stop_interval=args.stop_interval, stop_weight_budget=args.stop_budget,
                   stop_min_usd=args.stop_min_usd, max_event_subs=event_subs_aus(args.max_event_subs),
                   af_tage=args.af_tage, af_max_gb=args.af_max_gb)
    con.execute("INSERT OR REPLACE INTO meta VALUES ('backup_dir', ?)", (backup_dir,))
    con.commit()
    if same_disk:
        print(f"Backup-Ordner: {backup_dir} (gleicher Datenträger wie die Datenbank)")
    else:
        print(f"Backup-Ordner: {backup_dir} (anderer Datenträger als die Datenbank)")
    rec = Recorder(con, cfg)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, rec.stop.set)
        except NotImplementedError:
            pass
    print(f"Recorder läuft für {', '.join(cfg.coins)}. Abbruch mit Strg-C.")
    print("Die ersten Minuten sind leer — das Adressregister muss erst wachsen.\n")
    try:
        loop.run_until_complete(rec.run())
    except KeyboardInterrupt:
        rec.stop.set()
    finally:
        con.close()


if __name__ == "__main__":
    main()
