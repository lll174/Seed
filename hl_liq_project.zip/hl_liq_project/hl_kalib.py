#!/usr/bin/env python3
"""
hl_kalib.py -- Kalibrierung v2 (K2-Neubau, 23.09.2026). Läuft zunächst im SCHATTEN neben der alten
Kalibrierung (hl_forecast.calibrate_weights): rechnet und speichert eigene Wahrscheinlichkeiten, ohne die
angezeigte Prognose zu ändern, bis der Schalter gesetzt ist (learned-Schlüssel "kalib2_aktiv").

Modell (je Coin und Horizont h):
    p = σ( b + Σ_j w_j · x_j / s_j )
  x_j   Treiber-Score in [−1, 1], fehlender Treiber = 0 (Beleg mit Bayes-Faktor 1)
  s_j   Skala je Treiber = Streuung der vorhandenen Scores im Trainingsfenster (min 0,05) -- damit wirkt L2 auf
        alle Treiber gleich, unabhängig davon, wie weit ein Score typischerweise ausschlägt
  b     Achsenabschnitt (Drift), nicht regularisiert
  w     Gewichte, L2 gegen einen Startvektor w0 aus den Priors (Prior als Ausgangspunkt, nicht als Attraktor:
        λ wird per geblockter Kreuzvalidierung mit Lücke gewählt; mit wachsender Datenmenge sinkt λ, die Daten
        übernehmen. Ohne Nenner PRIOR_SUMME, ohne β, ohne Klemmung auf 2·Prior -- die Ursachen von K2)
Daten:
  - Prognosen der letzten TRAIN_TAGE (nach Zeit, nicht nach Fensterzahl), EINE je h-Block (die früheste --
    dieselbe Wahl wie score_forecasts, M10)
  - Label: Richtung nach h Stunden; |Bewegung| < TOLERANZ wird nicht trainiert (M7); Kurs nur, wenn eine Bar
    ≤ 120 s vor dem Zeitpunkt liegt (H4)
  - Alters-Gewicht mit HALF_LIFE_DAYS
Auswahl von λ: 5 zusammenhängende Zeitblöcke, Trainingszeilen im Abstand < h um die Testgrenzen werden
ausgelassen (Embargo), Zielgröße gewichteter Log-Loss; 1-SE-Regel (das größte λ innerhalb einer
Standardabweichung des besten). Ausgegeben werden außerdem Brier-Skill und Trefferquote out-of-fold
sowie das Zuverlässigkeitsdiagramm (vorhergesagt vs. eingetreten in Zehnteln).
Abnahme (Positivkontrolle): Kante 0,65 → p bei Score +0,6 in [0,60; 0,70]; Kante 0,50 → |w| klein.
"""
import json
import math
import sqlite3
import sys
import time

import numpy as np

import hl_forecast as F

TRAIN_TAGE = 90
PRIOR_N0 = 200                  # Blöcke, bis der Prior als Strafziel vollständig durch null ersetzt ist (~33 Tage bei 4 h)
LAMBDAS = (0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
FOLDS = 5
W_CLIP = 4.0
MIN_FAELLE = 60


# ----------------------------------------------------------------------------------------------
# Daten
# ----------------------------------------------------------------------------------------------
def lade_faelle(con_main, coin: str, path: str, horizon_h: int, tage: int = TRAIN_TAGE, now: int | None = None) -> dict:
    """X (n×d), y (0/1), sw (Alters-Gewicht), T (Zeiten), names, present (n×d Maske), tol_ausgelassen."""
    now = now or int(time.time())
    names = list(F.PRIORS)
    idx = {n: j for j, n in enumerate(names)}
    st = F.store_connect(path)
    rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                      (coin, now - tage * 86_400, now - horizon_h * 3600)).fetchall()
    st.close()
    block = horizon_h * 3600
    seen = set(); X = []; y = []; sw = []; T = []; P = []; tol = 0; ohne_kurs = 0
    cache: dict = {}

    def real_at(t):
        if t not in cache:
            r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1", (coin, t, t - 120)).fetchone()
            cache[t] = r[0] if r and r[0] else None
        return cache[t]

    for ts, p0, payload in rows:
        b = ts // block
        if b in seen:
            continue
        seen.add(b)                                   # EINE Prognose je Block: die früheste (wie score_forecasts)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        real = real_at(ts + block)
        if not real or not p0:
            ohne_kurs += 1; continue
        r = real / p0 - 1.0
        if abs(r) < F.TOLERANZ:
            tol += 1; continue
        vec = {d["name"]: d["score"] for d in pl.get("drivers", []) if d.get("name") in idx}
        x = [0.0] * len(names); pr = [0] * len(names)
        for n_, v_ in vec.items():
            x[idx[n_]] = float(v_ or 0.0); pr[idx[n_]] = 1
        X.append(x); P.append(pr); y.append(1.0 if r > 0 else 0.0); T.append(ts)
        sw.append(0.5 ** ((now - ts) / (F.HALF_LIFE_DAYS * 86_400)))
    return {"X": np.array(X, dtype=float).reshape(-1, len(names)), "y": np.array(y, dtype=float), "sw": np.array(sw, dtype=float),
            "T": np.array(T, dtype=float), "present": np.array(P, dtype=float).reshape(-1, len(names)), "names": names,
            "tol_ausgelassen": tol, "ohne_kurs": ohne_kurs, "n_bloecke": len(seen)}


def skalen(X: np.ndarray, present: np.ndarray) -> np.ndarray:
    s = np.full(X.shape[1], 1.0)
    for j in range(X.shape[1]):
        v = X[present[:, j] > 0, j]
        s[j] = max(float(np.std(v)), 0.05) if v.size >= 10 else 1.0
    return s


# ----------------------------------------------------------------------------------------------
# Modell
# ----------------------------------------------------------------------------------------------
def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def fit(Xs: np.ndarray, y: np.ndarray, sw: np.ndarray, lam: float, w0: np.ndarray, iters: int = 60) -> tuple:
    """
    L2-Logit gegen w0 (Achsenabschnitt frei), gewichtete Fälle, Newton mit Dämpfung.
    Verlust = Σ sw·logloss / Σ sw + λ·||w − w0||² / d.
    """
    n, d = Xs.shape
    if n == 0:
        return w0.copy(), 0.0
    W = sw / max(sw.sum(), 1e-9)
    w = w0.copy(); b = 0.0
    A = np.hstack([np.ones((n, 1)), Xs])                         # Spalte 0 = Achsenabschnitt
    theta = np.concatenate([[b], w])
    reg = np.zeros(d + 1); reg[1:] = 2.0 * lam / d
    theta0 = np.concatenate([[0.0], w0])
    for _ in range(iters):
        z = A @ theta; p = _sig(z)
        g = A.T @ (W * (p - y)) + reg * (theta - theta0)
        H = (A * (W * p * (1 - p))[:, None]).T @ A + np.diag(reg) + 1e-9 * np.eye(d + 1)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        # Dämpfung: Schrittweite halbieren, bis der Verlust nicht steigt
        def verlust(th):
            pz = _sig(A @ th)
            ll = -np.sum(W * (y * np.log(pz + 1e-12) + (1 - y) * np.log(1 - pz + 1e-12)))
            return ll + lam * float(np.sum((th[1:] - w0) ** 2)) / d
        v0 = verlust(theta); t = 1.0; neu = theta - step
        while verlust(neu) > v0 + 1e-12 and t > 1e-4:
            t *= 0.5; neu = theta - t * step
        if np.max(np.abs(neu - theta)) < 1e-7:
            theta = neu; break
        theta = neu
    theta[1:] = np.clip(theta[1:], -W_CLIP, W_CLIP)
    return theta[1:], float(theta[0])


def _logloss(p, y, sw):
    W = sw / max(sw.sum(), 1e-9)
    return float(-np.sum(W * (y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12))))


def cv_lambda(Xs, y, sw, T, horizon_h: int, w0: np.ndarray) -> dict:
    """Geblockte Kreuzvalidierung mit Embargo; 1-SE-Regel. Liefert λ, Verluste je λ, OOF-Kennzahlen des gewählten λ."""
    n = len(y)
    order = np.argsort(T); grenzen = np.linspace(0, n, FOLDS + 1).astype(int)
    ergebnisse = {}
    embargo = horizon_h * 3600
    for lam in LAMBDAS:
        oof_p = np.full(n, np.nan); verluste = []
        for k in range(FOLDS):
            test = order[grenzen[k]:grenzen[k + 1]]
            if len(test) < 5:
                continue
            t_lo, t_hi = T[test].min(), T[test].max()
            train_mask = np.ones(n, dtype=bool); train_mask[test] = False
            train_mask &= ~((T >= t_lo - embargo) & (T <= t_hi + embargo))     # Embargo um den Testblock
            tr = np.where(train_mask)[0]
            if len(tr) < 20:
                continue
            w, b = fit(Xs[tr], y[tr], sw[tr], lam, w0)
            p = _sig(b + Xs[test] @ w); oof_p[test] = p
            verluste.append(_logloss(p, y[test], sw[test]))
        if verluste:
            ergebnisse[lam] = {"loss": float(np.mean(verluste)), "se": float(np.std(verluste) / math.sqrt(len(verluste))) if len(verluste) > 1 else 0.0, "oof": oof_p}
    if not ergebnisse:
        return {"lam": LAMBDAS[-1], "tabelle": {}, "oof": None}
    best = min(ergebnisse, key=lambda l: ergebnisse[l]["loss"])
    schwelle = ergebnisse[best]["loss"] + ergebnisse[best]["se"]
    gewaehlt = max(l for l in ergebnisse if ergebnisse[l]["loss"] <= schwelle)     # 1-SE: das größte λ innerhalb einer SE
    return {"lam": gewaehlt, "tabelle": {l: {"loss": round(v["loss"], 5), "se": round(v["se"], 5)} for l, v in ergebnisse.items()}, "oof": ergebnisse[gewaehlt]["oof"]}


def zuverlaessigkeit(p: np.ndarray, y: np.ndarray, sw: np.ndarray) -> list:
    """Zehntel des vorhergesagten p: [untere, obere, mittleres p, eingetreten, n]"""
    out = []
    kanten = np.linspace(0.0, 1.0, 11)
    for i in range(10):
        m = (p >= kanten[i]) & (p < kanten[i + 1] if i < 9 else p <= 1.0)
        if m.sum() >= 5:
            out.append([round(float(kanten[i]), 2), round(float(kanten[i + 1]), 2), round(float(np.average(p[m], weights=sw[m])), 3),
                        round(float(np.average(y[m], weights=sw[m])), 3), int(m.sum())])
    return out


# ----------------------------------------------------------------------------------------------
# Kalibrieren und anwenden
# ----------------------------------------------------------------------------------------------
def kalibrieren(con_main, coin: str, horizon_h: int = 4, path: str = F.STORE, now: int | None = None, speichern: bool = True) -> dict | None:
    now = now or int(time.time())
    D = lade_faelle(con_main, coin, path, horizon_h, now=now)
    X, y, sw, T, P, names = D["X"], D["y"], D["sw"], D["T"], D["present"], D["names"]
    n = len(y)
    if n < MIN_FAELLE:
        return {"coin": coin, "h": horizon_h, "n": n, "zu_wenig": True, "ts": now}
    s = skalen(X, P); Xs = X / s
    # Prior als Ausgangspunkt, der mit der Datenmenge verschwindet (nicht als Attraktor -- Audit v9/v10 "Fehler 1"):
    # Zielvektor der L2-Strafe = Prior · max(0, 1 − n_eff/PRIOR_N0). Bei n_eff 0 gilt der Prior voll, ab
    # PRIOR_N0 Blöcken zieht die Strafe gegen null und ein Rausch-Treiber verliert sein Gewicht.
    n_eff_ = F.n_eff_bloecke(T.tolist(), horizon_h)
    anteil = max(0.0, 1.0 - n_eff_ / PRIOR_N0)
    w0 = np.array([F.PRIORS[nm] for nm in names], dtype=float) * s * anteil
    cv = cv_lambda(Xs, y, sw, T, horizon_h, w0)
    w, b = fit(Xs, y, sw, cv["lam"], w0)
    p_in = _sig(b + Xs @ w)
    oof = cv["oof"]
    ok = oof is not None and np.isfinite(oof).sum() >= 20
    m = np.isfinite(oof) if ok else np.zeros(n, dtype=bool)
    pu = float(np.average(y, weights=sw))
    brier_ref = pu * (1 - pu)
    aus = {"coin": coin, "h": horizon_h, "ts": now, "n": n, "n_eff": n_eff_, "prior_anteil": round(anteil, 3), "tol_ausgelassen": D["tol_ausgelassen"],
           "ohne_kurs": D["ohne_kurs"], "lam": cv["lam"], "lam_tabelle": cv["tabelle"], "intercept": round(b, 4),
           "weights": {nm: round(float(w[j] / s[j]), 4) for j, nm in enumerate(names)},        # Gewicht in Score-Einheiten
           "weights_std": {nm: round(float(w[j]), 4) for j, nm in enumerate(names)}, "scales": {nm: round(float(s[j]), 4) for j, nm in enumerate(names)},
           "base_up": round(pu, 4),
           "in_sample": {"logloss": round(_logloss(p_in, y, sw), 4), "brier": round(float(np.average((p_in - y) ** 2, weights=sw)), 4)},
           "oof": None, "zuverlaessigkeit": None}
    if ok:
        po = oof[m]; yo = y[m]; so = sw[m]
        brier = float(np.average((po - yo) ** 2, weights=so))
        ruf = po != 0.5
        treffer = float(np.average(((po > 0.5) == (yo > 0.5))[ruf], weights=so[ruf])) if ruf.sum() else None
        aus["oof"] = {"n": int(m.sum()), "logloss": round(_logloss(po, yo, so), 4), "brier": round(brier, 4),
                      "brier_skill": round(1 - brier / brier_ref, 4) if brier_ref > 1e-9 else None, "hit_rate": round(treffer, 4) if treffer is not None else None}
        aus["zuverlaessigkeit"] = zuverlaessigkeit(po, yo, so)
    if speichern:
        st = F.store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, f"kalib2_{horizon_h}", json.dumps(aus), now))
        st.commit(); st.close()
    return aus


def laden(coin: str, horizon_h: int = 4, path: str = F.STORE) -> dict | None:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key=?", (coin, f"kalib2_{horizon_h}")).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


def aktiv(path: str = F.STORE) -> bool:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='kalib2_aktiv'").fetchone(); st.close()
        return bool(r and r[0] == "1")
    except sqlite3.Error:
        return False


def schalten(an: bool, path: str = F.STORE) -> None:
    st = F.store_connect(path)
    st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", ("*", "kalib2_aktiv", "1" if an else "0", int(time.time())))
    st.commit(); st.close()


def p_up(model: dict, drivers: list) -> float | None:
    """Wahrscheinlichkeit aus einem gespeicherten v2-Modell für die aktuellen Treiber (fehlende = 0)."""
    if not model or model.get("zu_wenig") or not model.get("weights"):
        return None
    z = model.get("intercept", 0.0)
    for d in drivers:
        w = model["weights"].get(d["name"])
        if w is not None and d.get("score") is not None:
            z += w * float(d["score"])
    return float(_sig(np.array(z)))


# ----------------------------------------------------------------------------------------------
# Positivkontrolle (Tor) und Nulltest für v2
# ----------------------------------------------------------------------------------------------
def positivkontrolle(seed: int = 1, tage: int = 30, verbose: bool = True) -> dict:
    """Wie hl_forecast.positivkontrolle, aber durch v2: Kante 0,65 → p bei Score +0,6 in [0,60; 0,70]; Kante 0,50 → |w| klein."""
    import random as _rnd, tempfile as _tf, os as _os
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    rng = _rnd.Random(seed); now = int(time.time()) // 900 * 900; start = now - tage * 86_400; px = 100.0; rows = []
    t = start - 5 * 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0006)); rows.append((t, "BTC", px, px, px, px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    rausch = [n for n in list(F.PRIORS)[:13] if n != "Taker-Flow"][:12]
    out = {}
    for kante in (0.5, 0.65, 0.9):
        tmp = _tf.mkdtemp(); st_path = _os.path.join(tmp, "f.db"); c = F.store_connect(st_path)
        for ts in range(start, now - 4 * 3600, 900):
            p0 = close[ts]; fut = close.get(ts + 4 * 3600)
            if not fut:
                continue
            up = fut > p0; richtig = _rnd.Random(ts // 14_400 + seed).random() < kante
            s_ = (1 if up else -1) if richtig else (-1 if up else 1)
            drivers = [{"name": "Taker-Flow", "score": 0.6 * s_}] + [{"name": n, "score": rng.uniform(-.6, .6)} for n in rausch]
            c.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                      (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": drivers})))
        c.commit(); c.close()
        m = kalibrieren(con, "BTC", 4, path=st_path, now=now, speichern=False)
        pk = p_up(m, [{"name": "Taker-Flow", "score": 0.6}]) if m and not m.get("zu_wenig") else None
        p0_ = p_up(m, [{"name": "Taker-Flow", "score": 0.0}]) if m and not m.get("zu_wenig") else None      # Basis (nur Achsenabschnitt = Basisrate des Fensters)
        out[kante] = {"n": m.get("n") if m else 0, "n_eff": m.get("n_eff") if m else 0, "lam": m.get("lam") if m else None,
                      "w": (m.get("weights") or {}).get("Taker-Flow") if m else None, "p_up": pk, "p_basis": p0_,
                      "oof_hit": ((m.get("oof") or {}).get("hit_rate") if m else None), "brier_skill": ((m.get("oof") or {}).get("brier_skill") if m else None)}
        try:
            for f in _os.listdir(tmp):
                _os.remove(_os.path.join(tmp, f))
            _os.rmdir(tmp)
        except OSError:
            pass
    # Tor: Kante 0,65 -> p bei Score +0,6 in [0,60; 0,70]; Rauschen -> der Treiber bewegt die Wahrscheinlichkeit
    # gegenüber Score 0 um weniger als 5 Punkte (der Achsenabschnitt darf die Basisrate des Fensters tragen)
    tor = (out[0.65]["p_up"] is not None and 0.60 <= out[0.65]["p_up"] <= 0.70
           and out[0.5]["p_up"] is not None and out[0.5]["p_basis"] is not None and abs(out[0.5]["p_up"] - out[0.5]["p_basis"]) < 0.05)
    if verbose:
        print("  Positivkontrolle v2 (Tor: Kante 0,65 → p_up 0,60–0,70; Rauschen → Treiber bewegt p um < 5 Punkte gegen die Basis):")
        for k, v in out.items():
            print(f"    Kante {k:.2f}: n {v['n']} (n_eff {v['n_eff']}) · λ {v['lam']} · Gewicht Taker-Flow {v['w'] if v['w'] is not None else '—'} · "
                  f"p_up bei Score +0,6 = {(v['p_up'] or 0) * 100:.1f} % (Basis {(v['p_basis'] or 0) * 100:.1f} %) · OOF-Quote {((v['oof_hit'] or 0) * 100):.0f} % · Brier-Skill {v['brier_skill']}")
        print("    Tor:", "BESTANDEN" if tor else "NICHT bestanden")
    out["tor"] = tor
    return out


def nulltest(verbose: bool = True) -> bool:
    """Rauschen (Kante 0,50): p_up ≈ 0,5 und Brier-Skill ≤ 0,02; Signal (0,65): Tor."""
    r = positivkontrolle(verbose=verbose)
    ok = r["tor"] and (r[0.5]["brier_skill"] is None or r[0.5]["brier_skill"] <= 0.02)   # Rauschen darf keinen Skill vortäuschen
    if verbose:
        print("  Ergebnis v2:", "bestanden" if ok else "NICHT bestanden")
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--aktivieren" in sys.argv:
        schalten(True); print("Kalibrierung v2 AKTIV -- die Prognose nutzt jetzt p_up_v2"); sys.exit(0)
    if "--deaktivieren" in sys.argv:
        schalten(False); print("Kalibrierung v2 im Schatten -- die Prognose nutzt wieder das alte Modell"); sys.exit(0)
    print(__doc__)
