#!/usr/bin/env python3
"""
hl_kalib.py -- Kalibrierung v2 (K2-Neubau, 23.09.2026). Läuft zunächst im SCHATTEN neben der alten
Kalibrierung (hl_forecast.calibrate_weights): rechnet und speichert eigene Wahrscheinlichkeiten, ohne die
angezeigte Prognose zu ändern, bis der Schalter gesetzt ist (learned-Schlüssel "kalib2_aktiv").

Modell (je Coin und Horizont h):
    p = σ( b + Σ_j w_j · x_j / s_j )
  x_j   Treiber-Score in [−1, 1], fehlender Treiber = 0 (Beleg mit Bayes-Faktor 1)
  s_j   Skala je Treiber = Streuung der vorhandenen Scores im Trainingsfenster (min 0,05) -- damit wirkt L2 auf
        alle Treiber gleich, unabhängig davon, wie weit ein Score typischerweise ausschlägt
  b     Achsenabschnitt (Drift), nicht regularisiert
  w     Gewichte, L2 gegen einen Startvektor w0 aus den Priors (Prior als Ausgangspunkt, nicht als Attraktor:
        λ wird per geblockter Kreuzvalidierung mit Lücke gewählt; mit wachsender Datenmenge sinkt λ, die Daten
        übernehmen. Ohne Nenner PRIOR_SUMME, ohne β, ohne Klemmung auf 2·Prior -- die Ursachen von K2)
Daten:
  - Prognosen der letzten TRAIN_TAGE (nach Zeit, nicht nach Fensterzahl), EINE je h-Block (die früheste --
    dieselbe Wahl wie score_forecasts, M10)
  - Label: Richtung nach h Stunden; |Bewegung| < TOLERANZ wird nicht trainiert (M7); Kurs nur, wenn eine Bar
    ≤ 120 s vor dem Zeitpunkt liegt (H4)
  - Alters-Gewicht mit HALF_LIFE_DAYS
Auswahl von λ: 5 zusammenhängende Zeitblöcke, Trainingszeilen im Abstand < h um die Testgrenzen werden
ausgelassen (Embargo), Zielgröße gewichteter Log-Loss; 1-SE-Regel (das größte λ innerhalb einer
Standardabweichung des besten). Ausgegeben werden außerdem Brier-Skill und Trefferquote out-of-fold
sowie das Zuverlässigkeitsdiagramm (vorhergesagt vs. eingetreten in Zehnteln).
Abnahme (Positivkontrolle): Kante 0,65 → p bei Score +0,6 in [0,60; 0,70]; Kante 0,50 → |w| klein.
"""
import json
import math
import sqlite3
import sys
import time

import numpy as np

import hl_forecast as F

TRAIN_TAGE = 90
PRIOR_N0 = 200                  # Blöcke, bis der Prior als Strafziel vollständig durch null ersetzt ist (~33 Tage bei 4 h)
LAMBDAS = (0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
FOLDS = 5
W_CLIP = 4.0
# 23.13: fester, auf 4 h ausgerichteter Zeitpunkt und feste Szenarien für Positivkontrolle und Nulltest. Vorher hing das
# synthetische Szenario an time.time() (4-h-Raster und Kanten-Zuordnung je Block): Bei unverändertem Code fiel das Tor in
# 5 von 24 Viertelstunden durch (p_up bei Kante 0,65 zwischen 56,8 und 65,7 %, Mittel 61,6 %).
PROBE_NOW = 1_790_006_400
PROBE_SEEDS = (1, 2, 3, 4, 5)
# 23.26 (v2-Korrektur): Das Prior-Ziel ist ein gewichteter DURCHSCHNITT der Treiber wie in v1 (Summe der Zielgewichte =
# BETA0 über die üblicherweise vorhandenen Treiber) statt jedem Treiber sein volles Prior-Gewicht als Logit-Koeffizienten
# zu geben. Vorher summierten sich ~20 gleichgerichtete Treiber: Pi 24.09. p_up v2 88,7 %, Zuverlässigkeit 85 % → 28 %.
BETA0 = 1.0
KALIB_C = tuple(i / 10 for i in range(11))     # Kalibrierfaktor für den Treiberanteil, gewählt auf den OOF-Vorhersagen
MODELL_VERSION = 2                             # ältere gespeicherte Modelle (Summe, ohne Kalibrierschritt) werden nicht mehr benutzt
MIN_FAELLE = 30                 # 23.09.: 60 war zu hoch -- BTC hatte 74 Blöcke minus Toleranzfälle; der abklingende Prior trägt kleine n


# ----------------------------------------------------------------------------------------------
# Daten
# ----------------------------------------------------------------------------------------------
def lade_faelle(con_main, coin: str, path: str, horizon_h: int, tage: int = TRAIN_TAGE, now: int | None = None) -> dict:
    """X (n×d), y (0/1), sw (Alters-Gewicht), T (Zeiten), names, present (n×d Maske), tol_ausgelassen."""
    now = now or int(time.time())
    names = [n for n in F.PRIORS if n not in getattr(F, "SCHATTEN_TREIBER", ())]     # 23.27: Schatten-Treiber nicht in v2
    idx = {n: j for j, n in enumerate(names)}
    st = F.store_connect(path)
    rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                      (coin, now - tage * 86_400, now - horizon_h * 3600)).fetchall()
    st.close()
    block = horizon_h * 3600
    seen = set(); X = []; y = []; sw = []; T = []; P = []; tol = 0; ohne_kurs = 0
    cache: dict = {}

    def real_at(t):
        if t not in cache:
            r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1", (coin, t, t - 120)).fetchone()
            cache[t] = r[0] if r and r[0] else None
        return cache[t]

    cb_ab = F.cb_seite_ab(con_main)                                 # U41: Spot-Taker-Flow davor vertauscht
    for ts, p0, payload in rows:
        b = ts // block
        if b in seen:
            continue
        seen.add(b)                                   # EINE Prognose je Block: die früheste (wie score_forecasts)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        real = real_at(ts + block)
        if not real or not p0:
            ohne_kurs += 1; continue
        r = real / p0 - 1.0
        if abs(r) < F.TOLERANZ:
            tol += 1; continue
        vec = {d["name"]: d["score"] for d in pl.get("drivers", []) if d.get("name") in idx}
        if cb_ab and ts < cb_ab:
            vec.pop(F.CB_TREIBER, None)                                 # U41: fehlt statt falschem Vorzeichen
        x = [0.0] * len(names); pr = [0] * len(names)
        for n_, v_ in vec.items():
            x[idx[n_]] = float(v_ or 0.0); pr[idx[n_]] = 1
        X.append(x); P.append(pr); y.append(1.0 if r > 0 else 0.0); T.append(ts)
        sw.append(0.5 ** ((now - ts) / (F.HALF_LIFE_DAYS * 86_400)))
    return {"X": np.array(X, dtype=float).reshape(-1, len(names)), "y": np.array(y, dtype=float), "sw": np.array(sw, dtype=float),
            "T": np.array(T, dtype=float), "present": np.array(P, dtype=float).reshape(-1, len(names)), "names": names,
            "tol_ausgelassen": tol, "ohne_kurs": ohne_kurs, "n_bloecke": len(seen)}


def skalen(X: np.ndarray, present: np.ndarray) -> np.ndarray:
    s = np.full(X.shape[1], 1.0)
    for j in range(X.shape[1]):
        v = X[present[:, j] > 0, j]
        s[j] = max(float(np.std(v)), 0.05) if v.size >= 10 else 1.0
    return s


# ----------------------------------------------------------------------------------------------
# Modell
# ----------------------------------------------------------------------------------------------
def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def fit(Xs: np.ndarray, y: np.ndarray, sw: np.ndarray, lam: float, w0: np.ndarray, iters: int = 60) -> tuple:
    """
    L2-Logit gegen w0 (Achsenabschnitt frei), gewichtete Fälle, Newton mit Dämpfung.
    Verlust = Σ sw·logloss / Σ sw + λ·||w − w0||² / d.
    """
    n, d = Xs.shape
    if n == 0:
        return w0.copy(), 0.0
    W = sw / max(sw.sum(), 1e-9)
    w = w0.copy(); b = 0.0
    A = np.hstack([np.ones((n, 1)), Xs])                         # Spalte 0 = Achsenabschnitt
    theta = np.concatenate([[b], w])
    reg = np.zeros(d + 1); reg[1:] = 2.0 * lam / d
    theta0 = np.concatenate([[0.0], w0])
    for _ in range(iters):
        z = A @ theta; p = _sig(z)
        g = A.T @ (W * (p - y)) + reg * (theta - theta0)
        H = (A * (W * p * (1 - p))[:, None]).T @ A + np.diag(reg) + 1e-9 * np.eye(d + 1)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        # Dämpfung: Schrittweite halbieren, bis der Verlust nicht steigt
        def verlust(th):
            pz = _sig(A @ th)
            ll = -np.sum(W * (y * np.log(pz + 1e-12) + (1 - y) * np.log(1 - pz + 1e-12)))
            return ll + lam * float(np.sum((th[1:] - w0) ** 2)) / d
        v0 = verlust(theta); t = 1.0; neu = theta - step
        while verlust(neu) > v0 + 1e-12 and t > 1e-4:
            t *= 0.5; neu = theta - t * step
        if np.max(np.abs(neu - theta)) < 1e-7:
            theta = neu; break
        theta = neu
    theta[1:] = np.clip(theta[1:], -W_CLIP, W_CLIP)
    return theta[1:], float(theta[0])


def _logloss(p, y, sw):
    W = sw / max(sw.sum(), 1e-9)
    return float(-np.sum(W * (y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12))))


def cv_lambda(Xs, y, sw, T, horizon_h: int, w0: np.ndarray) -> dict:
    """Geblockte Kreuzvalidierung mit Embargo; 1-SE-Regel. Liefert λ, Verluste je λ, OOF-Kennzahlen des gewählten λ."""
    n = len(y)
    order = np.argsort(T); grenzen = np.linspace(0, n, FOLDS + 1).astype(int)
    ergebnisse = {}
    embargo = horizon_h * 3600
    for lam in LAMBDAS:
        oof_p = np.full(n, np.nan); oof_d = np.full(n, np.nan); oof_c = np.full(n, np.nan); verluste = []
        for k in range(FOLDS):
            test = order[grenzen[k]:grenzen[k + 1]]
            if len(test) < 5:
                continue
            t_lo, t_hi = T[test].min(), T[test].max()
            train_mask = np.ones(n, dtype=bool); train_mask[test] = False
            train_mask &= ~((T >= t_lo - embargo) & (T <= t_hi + embargo))     # Embargo um den Testblock
            tr = np.where(train_mask)[0]
            if len(tr) < 20:
                continue
            w, b = fit(Xs[tr], y[tr], sw[tr], lam, w0)
            p = _sig(b + Xs[test] @ w); oof_p[test] = p
            oof_d[test] = Xs[test] @ w                                   # 23.26: Treiberanteil für den Kalibrierschritt
            oof_c[test] = float(np.average(y[tr], weights=sw[tr]))       # U29: Klimatologie, die das OOF-Modell kennen konnte
            verluste.append(_logloss(p, y[test], sw[test]))
        if verluste:
            ergebnisse[lam] = {"loss": float(np.mean(verluste)), "se": float(np.std(verluste) / math.sqrt(len(verluste))) if len(verluste) > 1 else 0.0, "oof": oof_p,
                               "oof_d": oof_d, "oof_c": oof_c}
    if not ergebnisse:
        return {"lam": LAMBDAS[-1], "tabelle": {}, "oof": None, "oof_d": None, "oof_c": None}
    best = min(ergebnisse, key=lambda l: ergebnisse[l]["loss"])
    schwelle = ergebnisse[best]["loss"] + ergebnisse[best]["se"]
    gewaehlt = max(l for l in ergebnisse if ergebnisse[l]["loss"] <= schwelle)     # 1-SE: das größte λ innerhalb einer SE
    return {"lam": gewaehlt, "tabelle": {l: {"loss": round(v["loss"], 5), "se": round(v["se"], 5)} for l, v in ergebnisse.items()}, "oof": ergebnisse[gewaehlt]["oof"],
            "oof_d": ergebnisse[gewaehlt]["oof_d"], "oof_c": ergebnisse[gewaehlt]["oof_c"]}


def _fit_a(z: np.ndarray, y: np.ndarray, w: np.ndarray) -> float:
    """Achsenabschnitt a für p = sig(a + z) (Newton, gewichtete Fälle)."""
    W = w / max(w.sum(), 1e-9); pb = float(np.clip(np.sum(W * y), 0.02, 0.98)); a = math.log(pb / (1 - pb))
    for _ in range(40):
        p = _sig(a + z); g = float(np.sum(W * (p - y))); h = float(np.sum(W * p * (1 - p))) + 1e-9
        a -= g / h
        if abs(g / h) < 1e-8:
            break
    return float(a)


def kalibrierschritt(cv: dict, y: np.ndarray, sw: np.ndarray) -> dict:
    """
    23.26: p = sig(a + c · Treiberanteil), c aus KALIB_C auf den OOF-Vorhersagen gewählt. Vorsichtige Regel wie bei λ:
    das KLEINSTE c, dessen Verlust nicht mehr als einen Standardfehler (gepaarte Fallverluste) über dem besten liegt.
    Ohne Beleg wird c = 0 -- dann nennt v2 die Basisrate statt einer übersicherten Zahl.
    """
    d = cv.get("oof_d")
    pb = float(np.clip(np.average(y, weights=sw), 0.02, 0.98)) if len(y) else 0.5
    if d is None or np.isfinite(d).sum() < 20:
        return {"c": 0.0, "a": math.log(pb / (1 - pb)), "tabelle": {}, "n": 0 if d is None else int(np.isfinite(d).sum())}
    m = np.isfinite(d); dd, yy, ww = d[m], y[m], sw[m]; W = ww / ww.sum()
    fall = {}; tab = {}
    for c in KALIB_C:
        a = _fit_a(c * dd, yy, ww); p = _sig(a + c * dd)
        fall[c] = (a, -(yy * np.log(p + 1e-12) + (1 - yy) * np.log(1 - p + 1e-12)))
        tab[c] = round(float(np.sum(W * fall[c][1])), 5)
    best = min(tab, key=tab.get)
    for c in KALIB_C:                                                   # aufsteigend: das vorsichtigste zuerst
        diff = fall[c][1] - fall[best][1]
        mw = float(np.sum(W * diff)); se = float(math.sqrt(max(np.sum(W * (diff - mw) ** 2), 0.0) / max(len(diff) - 1, 1)))
        if mw <= se:
            return {"c": c, "a": fall[c][0], "tabelle": tab, "n": int(m.sum()), "bestes_c": best}
    return {"c": best, "a": fall[best][0], "tabelle": tab, "n": int(m.sum()), "bestes_c": best}


def zuverlaessigkeit(p: np.ndarray, y: np.ndarray, sw: np.ndarray) -> list:
    """Zehntel des vorhergesagten p: [untere, obere, mittleres p, eingetreten, n]"""
    out = []
    kanten = np.linspace(0.0, 1.0, 11)
    for i in range(10):
        m = (p >= kanten[i]) & (p < kanten[i + 1] if i < 9 else p <= 1.0)
        if m.sum() >= 5:
            out.append([round(float(kanten[i]), 2), round(float(kanten[i + 1]), 2), round(float(np.average(p[m], weights=sw[m])), 3),
                        round(float(np.average(y[m], weights=sw[m])), 3), int(m.sum())])
    return out


# ----------------------------------------------------------------------------------------------
# Kalibrieren und anwenden
# ----------------------------------------------------------------------------------------------
def kalibrieren(con_main, coin: str, horizon_h: int = 4, path: str = F.STORE, now: int | None = None, speichern: bool = True) -> dict | None:
    now = now or int(time.time())
    D = lade_faelle(con_main, coin, path, horizon_h, now=now)
    X, y, sw, T, P, names = D["X"], D["y"], D["sw"], D["T"], D["present"], D["names"]
    n = len(y)
    if n < MIN_FAELLE:
        aus = {"coin": coin, "h": horizon_h, "n": n, "n_bloecke": D["n_bloecke"], "tol_ausgelassen": D["tol_ausgelassen"], "ohne_kurs": D["ohne_kurs"],
               "min_faelle": MIN_FAELLE, "zu_wenig": True, "ts": now}
        if speichern:                                            # auch den Zustand "zu wenige Fälle" speichern -- die Anzeige muss ihn nennen können
            st = F.store_connect(path)
            st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, f"kalib2_{horizon_h}", json.dumps(aus), now))
            st.commit(); st.close()
        return aus
    s = skalen(X, P); Xs = X / s
    # Prior als Ausgangspunkt, der mit der Datenmenge verschwindet (nicht als Attraktor -- Audit v9/v10 "Fehler 1"):
    # Zielvektor der L2-Strafe = Prior · max(0, 1 − n_eff/PRIOR_N0). Bei n_eff 0 gilt der Prior voll, ab
    # PRIOR_N0 Blöcken zieht die Strafe gegen null und ein Rausch-Treiber verliert sein Gewicht.
    n_eff_ = F.n_eff_bloecke(T.tolist(), horizon_h)
    anteil = max(0.0, 1.0 - n_eff_ / PRIOR_N0)
    pri = np.array([F.PRIORS[nm] for nm in names], dtype=float)
    da = P.mean(axis=0) if len(P) else np.zeros(len(names))
    s_prior = float(pri[da >= 0.5].sum()) or float(pri.sum())                  # 23.26: Summe der Priors der üblichen Treiber
    w0 = (BETA0 * pri / s_prior) * s * anteil                                  # Durchschnitt statt Summe
    cv = cv_lambda(Xs, y, sw, T, horizon_h, w0)
    w, b = fit(Xs, y, sw, cv["lam"], w0)
    kal = kalibrierschritt(cv, y, sw)                                          # 23.26: Kalibrierschritt auf OOF
    p_in = _sig(kal["a"] + kal["c"] * (Xs @ w))
    oof = cv["oof"]
    if oof is not None and cv.get("oof_d") is not None:
        oof_roh = oof
        oof = np.where(np.isfinite(cv["oof_d"]), _sig(kal["a"] + kal["c"] * np.nan_to_num(cv["oof_d"])), np.nan)
    else:
        oof_roh = None
    ok = oof is not None and np.isfinite(oof).sum() >= 20
    m = np.isfinite(oof) if ok else np.zeros(n, dtype=bool)
    pu = float(np.average(y, weights=sw))
    brier_ref = pu * (1 - pu)
    if ok and cv.get("oof_c") is not None:                                     # U29: Referenz = OOF-Klimatologie
        mc = m & np.isfinite(cv["oof_c"])
        if mc.sum() >= 20:
            brier_ref = float(np.average((cv["oof_c"][mc] - y[mc]) ** 2, weights=sw[mc]))
    aus = {"coin": coin, "h": horizon_h, "ts": now, "n": n, "n_eff": n_eff_, "prior_anteil": round(anteil, 3), "tol_ausgelassen": D["tol_ausgelassen"],
           "ohne_kurs": D["ohne_kurs"], "lam": cv["lam"], "lam_tabelle": cv["tabelle"], "intercept": round(b, 4),
           "weights": {nm: round(float(w[j] / s[j]), 4) for j, nm in enumerate(names)},        # Gewicht in Score-Einheiten
           "weights_std": {nm: round(float(w[j]), 4) for j, nm in enumerate(names)}, "scales": {nm: round(float(s[j]), 4) for j, nm in enumerate(names)},
           "base_up": round(pu, 4), "version": MODELL_VERSION, "beta0": BETA0, "s_prior": round(s_prior, 3),
           "kalib": {"c": kal["c"], "a": round(kal["a"], 4), "bestes_c": kal.get("bestes_c"), "n": kal.get("n"), "tabelle": kal.get("tabelle")},
           "in_sample": {"logloss": round(_logloss(p_in, y, sw), 4), "brier": round(float(np.average((p_in - y) ** 2, weights=sw)), 4)},
           "oof": None, "zuverlaessigkeit": None}
    if ok:
        po = oof[m]; yo = y[m]; so = sw[m]
        brier = float(np.average((po - yo) ** 2, weights=so))
        ruf = po != 0.5
        treffer = float(np.average(((po > 0.5) == (yo > 0.5))[ruf], weights=so[ruf])) if ruf.sum() else None
        # U120 (23.47, eigener Fehler seit 23.26): Der Achsenabschnitt a des Kalibrierschritts kennt ALLE OOF-Fälle; gegen die
        # OOF-Klimatologie der Trainingsfolds (U29) gemessen, zeigte schon c = 0 -- die reine Basisrate -- Skill (Pi 05.10.:
        # +0,005 bis +0,053). Vergleich jetzt gegen DENSELBEN Kalibrierschritt mit c = 0 auf denselben Fällen (wie v3 in
        # hl_fusion): c = 0 ergibt Skill genau 0, nur der Treiberanteil kann ihn heben. Die alte Zahl bleibt als
        # „brier_skill_klima“ sichtbar. Nur Anzeige: p_up_v2, Tor und Gleichlauf rechnen unverändert.
        a0 = _fit_a(np.zeros(len(yo)), yo, so)
        brier_0 = float(np.average((_sig(np.full(len(yo), a0)) - yo) ** 2, weights=so))
        aus["oof"] = {"n": int(m.sum()), "logloss": round(_logloss(po, yo, so), 4), "brier": round(brier, 4),
                      "brier_skill": round(1 - brier / brier_0, 4) if brier_0 > 1e-9 else None, "skill_ref": "Kalibrierschritt mit c = 0",
                      "brier_skill_klima": round(1 - brier / brier_ref, 4) if brier_ref > 1e-9 else None,
                      "basisrate": bool(kal["c"] == 0), "hit_rate": round(treffer, 4) if treffer is not None else None}
        aus["zuverlaessigkeit"] = zuverlaessigkeit(po, yo, so)
        if oof_roh is not None:                                                # zum Vergleich: ohne Kalibrierschritt
            pr_ = oof_roh[m]
            aus["oof_roh"] = {"brier": round(float(np.average((pr_ - yo) ** 2, weights=so)), 4),
                              "brier_skill": round(1 - float(np.average((pr_ - yo) ** 2, weights=so)) / brier_ref, 4) if brier_ref > 1e-9 else None,
                              "zuverlaessigkeit": zuverlaessigkeit(pr_, yo, so)}
    if speichern:
        st = F.store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, f"kalib2_{horizon_h}", json.dumps(aus), now))
        st.commit(); st.close()
    return aus


def laden(coin: str, horizon_h: int = 4, path: str = F.STORE) -> dict | None:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key=?", (coin, f"kalib2_{horizon_h}")).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


def aktiv(path: str = F.STORE) -> bool:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='kalib2_aktiv'").fetchone(); st.close()
        return bool(r and r[0] == "1")
    except sqlite3.Error:
        return False


def schalten(an: bool, path: str = F.STORE) -> None:
    st = F.store_connect(path)
    st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", ("*", "kalib2_aktiv", "1" if an else "0", int(time.time())))
    st.commit(); st.close()


def p_up(model: dict, drivers: list) -> float | None:
    """Wahrscheinlichkeit aus einem gespeicherten v2-Modell für die aktuellen Treiber (fehlende = 0)."""
    if not model or model.get("zu_wenig") or not model.get("weights"):
        return None
    k = model.get("kalib")
    if int(model.get("version") or 1) < MODELL_VERSION or not k:
        return None                                                            # 23.26: altes, übersichertes Modell -- bis zur nächsten Kalibrierung (stündlich) keine v2-Zahl
    z = 0.0
    for d in drivers:
        w = model["weights"].get(d["name"])
        if w is not None and d.get("score") is not None:
            z += w * float(d["score"])
    return float(_sig(np.array(k["a"] + k["c"] * z)))


# ----------------------------------------------------------------------------------------------
# Positivkontrolle (Tor) und Nulltest für v2
# ----------------------------------------------------------------------------------------------
def positivkontrolle(seed: int = 1, tage: int = 30, verbose: bool = True, now: int | None = None) -> dict:
    """Wie hl_forecast.positivkontrolle, aber durch v2: Kante 0,65 → p bei Score +0,6 in [0,60; 0,70]; Kante 0,50 → |w| klein."""
    import random as _rnd, tempfile as _tf, os as _os
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    rng = _rnd.Random(seed); now = (now or PROBE_NOW) // 900 * 900; start = now - tage * 86_400; px = 100.0; rows = []
    t = start - 5 * 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0006)); rows.append((t, "BTC", px, px, px, px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    rausch = [n for n in list(F.PRIORS)[:13] if n != "Taker-Flow"][:12]
    out = {}
    for kante in (0.5, 0.65, 0.9):
        tmp = _tf.mkdtemp(); st_path = _os.path.join(tmp, "f.db"); c = F.store_connect(st_path)
        for ts in range(start, now - 4 * 3600, 900):
            p0 = close[ts]; fut = close.get(ts + 4 * 3600)
            if not fut:
                continue
            up = fut > p0; richtig = _rnd.Random(ts // 14_400 + seed).random() < kante
            s_ = (1 if up else -1) if richtig else (-1 if up else 1)
            drivers = [{"name": "Taker-Flow", "score": 0.6 * s_}] + [{"name": n, "score": rng.uniform(-.6, .6)} for n in rausch]
            c.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                      (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": drivers})))
        c.commit(); c.close()
        m = kalibrieren(con, "BTC", 4, path=st_path, now=now, speichern=False)
        pk = p_up(m, [{"name": "Taker-Flow", "score": 0.6}]) if m and not m.get("zu_wenig") else None
        p0_ = p_up(m, [{"name": "Taker-Flow", "score": 0.0}]) if m and not m.get("zu_wenig") else None      # Basis (nur Achsenabschnitt = Basisrate des Fensters)
        lo = (lambda p: math.log(p / (1 - p)) if p and 0 < p < 1 else None)
        dlo = (lo(pk) - lo(p0_)) if (pk is not None and p0_ is not None and lo(pk) is not None and lo(p0_) is not None) else None
        out[kante] = {"n": m.get("n") if m else 0, "n_eff": m.get("n_eff") if m else 0, "lam": m.get("lam") if m else None, "dlogit": dlo,
                      "c": ((m.get("kalib") or {}).get("c") if m else None),
                      "w": (m.get("weights") or {}).get("Taker-Flow") if m else None, "p_up": pk, "p_basis": p0_,
                      "oof_hit": ((m.get("oof") or {}).get("hit_rate") if m else None), "brier_skill": ((m.get("oof") or {}).get("brier_skill") if m else None),
                      "brier_skill_klima": ((m.get("oof") or {}).get("brier_skill_klima") if m else None)}
        try:
            for f in _os.listdir(tmp):
                _os.remove(_os.path.join(tmp, f))
            _os.rmdir(tmp)
        except OSError:
            pass
    # Tor (U35, 23.26): Kante 0,65 -> Log-Odds-Beitrag des Treibers bei Score +0,6 gegen Score 0 zwischen 0,20 und 1,00
    # (wahrer Wert log(0,65/0,35) = 0,62, die Schrumpfung darf ihn verkleinern) -- unabhängig von der Basisrate des
    # Fensters; Rauschen -> der Treiber bewegt p um weniger als 5 Punkte
    tor = (out[0.65]["dlogit"] is not None and 0.20 <= out[0.65]["dlogit"] <= 1.00
           and out[0.5]["p_up"] is not None and out[0.5]["p_basis"] is not None and abs(out[0.5]["p_up"] - out[0.5]["p_basis"]) < 0.05)
    if verbose:
        print("  Positivkontrolle v2 (Tor: Kante 0,65 → Log-Odds-Beitrag 0,20–1,00; Rauschen → Treiber bewegt p um < 5 Punkte gegen die Basis):")
        for k, v in out.items():
            print(f"    Kante {k:.2f}: n {v['n']} (n_eff {v['n_eff']}) · λ {v['lam']} · Gewicht Taker-Flow {v['w'] if v['w'] is not None else '—'} · "
                  f"p_up bei Score +0,6 = {(v['p_up'] or 0) * 100:.1f} % (Basis {(v['p_basis'] or 0) * 100:.1f} %) · OOF-Quote {((v['oof_hit'] or 0) * 100):.0f} % · Brier-Skill {v['brier_skill']}")
        print("    Tor:", "BESTANDEN" if tor else "NICHT bestanden")
    out["tor"] = tor
    return out


def gleichlauf(seed: int = 1, tage: int = 30, now: int | None = None) -> dict:
    """
    23.26 Prüftor „Gleichlauf“: 20 Treiber folgen einem gemeinsamen, langsamen Faktor (wie ein Bullenregime, in dem fast
    alle Treiber gleichzeitig positiv stehen), OHNE Zusammenhang mit der kommenden 4-h-Richtung. v2 darf daraus keine
    Sicherheit ableiten: p bei allen Treibern +0,6 höchstens 7 Punkte neben der Basis. Zum Vergleich der alte Ansatz
    (volles Prior-Gewicht je Treiber als Logit-Koeffizient, Summe).
    """
    import random as _rnd, tempfile as _tf, os as _os
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    rng = _rnd.Random(seed + 100); now = (now or PROBE_NOW) // 900 * 900; start = now - tage * 86_400; px = 100.0; rows = []
    t = start - 5 * 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0006)); rows.append((t, "BTC", px, px, px, px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    namen = [n for n in F.PRIORS if n != F.CB_TREIBER][:20]
    tmp = _tf.mkdtemp(); st_path = _os.path.join(tmp, "f.db"); c = F.store_connect(st_path); f_ = 0.0
    for ts in range(start, now - 4 * 3600, 900):
        f_ = max(-0.8, min(0.8, f_ + rng.gauss(0, 0.05)))                 # gemeinsamer, langsamer Faktor
        drivers = [{"name": n, "score": max(-1.0, min(1.0, f_ + rng.gauss(0, 0.1)))} for n in namen]
        c.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                  (ts, "BTC", close[ts], 0, close[ts], close[ts], json.dumps({"drivers": drivers})))
    c.commit(); c.close()
    m = kalibrieren(con, "BTC", 4, path=st_path, now=now, speichern=False)
    try:
        for f in _os.listdir(tmp):
            _os.remove(_os.path.join(tmp, f))
        _os.rmdir(tmp)
    except OSError:
        pass
    if not m or m.get("zu_wenig"):
        return {"ok": False, "grund": "zu wenige Fälle"}
    alle = [{"name": n, "score": 0.6} for n in namen]
    p_al = p_up(m, alle); p_b = p_up(m, [{"name": n, "score": 0.0} for n in namen])
    anteil = float(m.get("prior_anteil") or 0)
    z_alt = sum(F.PRIORS[n] * anteil * 0.6 for n in namen)                     # alter Ansatz: Prior-Ziel als Summe
    return {"ok": p_al is not None and p_b is not None and abs(p_al - p_b) <= 0.07, "p_alle": p_al, "p_basis": p_b,
            "p_alt": float(_sig(np.array(z_alt))), "c": (m.get("kalib") or {}).get("c"), "brier_skill": (m.get("oof") or {}).get("brier_skill"), "n": m.get("n")}


def nulltest(verbose: bool = True) -> bool:
    """
    Tor über PROBE_SEEDS am festen Zeitpunkt PROBE_NOW (deterministisch): Mittel von p_up bei Kante 0,65 in [0,60; 0,70];
    Rauschen: der Treiber bewegt p im Mittel um < 5 Punkte gegen die Basis, Brier-Skill im Mittel <= 0,02.
    """
    erg = [positivkontrolle(seed=s_, verbose=False) for s_ in PROBE_SEEDS]

    def mittel(werte):
        w = [x for x in werte if x is not None]
        return sum(w) / len(w) if w else None

    def pc(x):
        return f"{x * 100:.1f} %" if x is not None else "—"

    p65 = mittel([r[0.65]["p_up"] for r in erg])
    d50 = mittel([abs(r[0.5]["p_up"] - r[0.5]["p_basis"]) for r in erg if r[0.5]["p_up"] is not None and r[0.5]["p_basis"] is not None])
    bs50 = mittel([r[0.5]["brier_skill"] for r in erg])
    dl65 = mittel([r[0.65]["dlogit"] for r in erg])
    gl = [gleichlauf(seed=s_) for s_ in PROBE_SEEDS]
    gl_ok = all(g_["ok"] for g_ in gl)
    tor = dl65 is not None and 0.20 <= dl65 <= 1.00 and d50 is not None and d50 < 0.05          # U35: Log-Odds-Beitrag statt absolutem Fenster
    # U120 (23.47): mit c = 0 (Basisrate) ist der Brier-Skill GENAU 0 -- vorher +0,001 bis +0,014 auf reinem Rauschen
    c0 = [r[0.5]["brier_skill"] for r in erg if r[0.5]["c"] == 0 and r[0.5]["brier_skill"] is not None]
    pos = [r[0.65]["brier_skill"] for r in erg if r[0.65]["c"] and r[0.65]["brier_skill"] is not None]
    u120 = bool(c0) and all(b == 0 for b in c0) and all(b > 0 for b in pos)
    ok = tor and gl_ok and (bs50 is None or bs50 <= 0.02) and u120          # Rauschen darf keinen Skill vortäuschen, Gleichlauf keine Sicherheit
    if verbose:
        print(f"  Positivkontrolle v2 über {len(PROBE_SEEDS)} feste Szenarien (Tor: Log-Odds-Beitrag bei Kante 0,65 zwischen 0,20 und 1,00; "
              "Rauschen < 5 Punkte gegen die Basis, Brier-Skill <= 0,02; Gleichlauf ohne Signal <= 7 Punkte):")
        for s_, r in zip(PROBE_SEEDS, erg):
            print(f"    Szenario {s_}: Kante 0,65 → p_up {pc(r[0.65]['p_up'])} (Basis {pc(r[0.65]['p_basis'])}) · Rauschen {pc(r[0.5]['p_up'])} "
                  f"gegen Basis {pc(r[0.5]['p_basis'])}, Brier-Skill {r[0.5]['brier_skill']} · Kante 0,90 → {pc(r[0.9]['p_up'])} · n_eff {r[0.65]['n_eff']}")
        print(f"    Mittel: Kante 0,65 → {pc(p65)}, Log-Odds-Beitrag {dl65 if dl65 is not None else float('nan'):+.2f} (wahr +0,62, Tor 0,20–1,00) · "
              f"Rauschen {d50 * 100 if d50 is not None else float('nan'):.1f} Punkte · Brier-Skill Rauschen {bs50 if bs50 is not None else float('nan'):+.3f}")
        for s_, g_ in zip(PROBE_SEEDS, gl):
            print(f"    Gleichlauf {s_}: 20 Treiber gemeinsam +0,6 ohne Signal → v2 {pc(g_.get('p_alle'))} gegen Basis {pc(g_.get('p_basis'))} "
                  f"(Kalibrierfaktor c {g_.get('c')}) · alter Ansatz (Summe) {pc(g_.get('p_alt'))} → {'ok' if g_['ok'] else 'FEHL'}")
        print(f"    U120: Brier-Skill bei c = 0 genau 0 in {len(c0)} Rausch-Szenarien ({'ok' if c0 and all(b == 0 for b in c0) else 'FEHL'}), "
              f"Positivkontrolle mit c > 0 über 0 in {sum(1 for b in pos if b > 0)} von {len(pos)} ({'ok' if all(b > 0 for b in pos) else 'FEHL'})")
        print("    Tor:", "BESTANDEN" if tor else "NICHT bestanden")
        print("  Ergebnis v2:", "bestanden" if ok else "NICHT bestanden")
    return ok


U7B_MIN_N = 100                 # U7b-Regel: Quote und Brier-Skill v2 ≥ v1 bei mindestens so vielen bewerteten 4-h-Fällen je Version


def u7b_regel(d1: dict | None, d2: dict | None) -> bool:
    """23.86 (U230): die Zahl der U7b-Regel aus der direkten Bilanz -- Trefferquote UND Brier-Skill von v2 mindestens so gut wie v1, je
    mindestens U7B_MIN_N gerufene Fälle. Die Zuverlässigkeit (zweiter Teil der Regel) prüft der Bericht nicht."""
    if not d1 or not d2 or (d1.get("n") or 0) < U7B_MIN_N or (d2.get("n") or 0) < U7B_MIN_N:
        return False
    if None in (d1.get("hit_rate"), d2.get("hit_rate"), d1.get("brier_skill"), d2.get("brier_skill")):
        return False
    return d2["hit_rate"] >= d1["hit_rate"] and d2["brier_skill"] >= d1["brier_skill"]


def _bilanz(d: dict | None) -> str:
    if not d or not d.get("n"):
        return "noch keine bewerteten Prognosen" if not d else f"keine gerufenen Fälle (Brier über {d.get('n_brier', 0)})"
    sk = d.get("brier_skill")
    return (f"Quote {d['hit_rate'] * 100:.1f} % (n {d['n']}), Brier {d['brier']:.4f}, Brier-Skill "
            + (f"{sk:+.4f}" if sk is not None else "—") + f" (über {d.get('n_brier', 0)})")


def bilanz_zeilen(db: str | None, path: str | None, coins: list) -> tuple:
    """23.86 (U230): direkte Bilanz der gespeicherten 4-h-Prognosen von v1 und v2 je Coin -- dieselbe Rechnung wie die Dashboard-Kachel
    „Kalibrierung v2“ (hl_forecast.score_forecasts: eine Prognose je 15-min-Fenster, Ruf = Vorzeichen von p − 0,5, Enthaltung unter
    2 Punkten, Brier-Skill gegen die Basisrate der Aufwärtsfälle). Bis 23.85 stand sie nur in der Kachel -- die Zahl der U7b-Regel war in
    keinem Bericht nachlesbar (UEBERGABE 3χχχχ). Liefert (Zeilen, {Coin: (direkt_v1, direkt_v2, Enthaltungen von v2)})."""
    if not db:
        return ["Direkte Bilanz v1/v2 (U230): ohne --db nicht berechnet (der Debug-Lauf übergibt die Datenbank)."], {}
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=30)
        con.execute("SELECT 1 FROM bars LIMIT 1")
    except sqlite3.Error as e:
        return [f"Direkte Bilanz v1/v2 (U230): Datenbank nicht lesbar ({type(e).__name__}: {e})."], {}
    werte: dict = {}
    z = ["Direkte Bilanz der gespeicherten 4-h-Prognosen (U230; dieselbe Rechnung wie die Kachel „Kalibrierung v2“: eine Prognose je "
         "15 min, Ruf = Vorzeichen von p − 0,5, Enthaltung unter 2 Punkten, Brier-Skill gegen die Basisrate):"]
    try:
        for coin in coins:
            sc = F.score_forecasts(con, coin, path or F.STORE)
            d1, d2, en = sc.get("direkt_v1"), sc.get("direkt_v2"), int(sc.get("enthalten_v2") or 0)
            c_ = ((laden(coin, 4, path or F.STORE) or {}).get("kalib") or {}).get("c")
            basis = c_ is not None and float(c_) == 0.0                 # v2 ist hier nur die Basisrate (kein Treiber wirkt)
            werte[coin] = (d1, d2, en, basis)
            z.append(f"   {coin}: v1 {_bilanz(d1)} · v2 {_bilanz(d2)}, {en} Enthaltungen" + (" · v2 hier = Basisrate (c = 0)" if basis else ""))
    finally:
        con.close()
    erfuellt = [c for c, (d1, d2, _e, _b) in werte.items() if u7b_regel(d1, d2)]
    basis_c = [c for c in erfuellt if werte[c][3]]
    z.append(f"   U7b-Regel (Quote und Brier-Skill v2 ≥ v1, je mindestens {U7B_MIN_N} gerufene Fälle; verglichen wie in der Kachel über die "
             "jeweils bewerteten Fälle, v2 nur über seine eigenen; die Zuverlässigkeit prüft dieser Bericht nicht): "
             + (("erfüllt in " + ", ".join(erfuellt) + " -- U7b neu vorlegen") if erfuellt else "in keinem Coin erfüllt")
             + (f"; in {', '.join(basis_c)} ist v2 nur die Basisrate (c = 0) -- dort kein Signal, ein Vorsprung kann aus einer Trendphase "
                "kommen" if basis_c else ""))
    return z, werte


def stand_text(path: str | None = None, db: str | None = None) -> str:
    """23.21: Debug „Kalibrierung v2: Stand je Coin“ -- Zustand, Achsenabschnitt, Zuverlässigkeit und die Beiträge der Treiber
    zur aktuellen v2-Wahrscheinlichkeit (woher kommt z. B. p_up 88,7 %?). 23.86 (U230): am Ende die direkte Bilanz v1/v2 je Coin
    (mit --db; dieselbe Rechnung wie die Kachel) und die Zahl der U7b-Regel."""
    st = F.store_connect(path or F.STORE)
    z = ["Kalibrierung v2 -- Stand je Coin (läuft im Schatten; umgeschaltet wird erst nach Prüfung, U7b)",
         "Seit 23.26: p_up = Sigmoid(a + c × Summe Gewicht x Score); Prior-Ziel als Durchschnitt, c aus den OOF-Vorhersagen (0 = Basisrate).", ""]
    try:
        coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers ORDER BY coin")]
        for coin in coins:
            r = st.execute("SELECT MAX(ts) FROM forecast_drivers WHERE coin=?", (coin,)).fetchone()
            drv = [{"name": n_, "score": s_} for n_, s_ in st.execute("SELECT name, score FROM forecast_drivers WHERE coin=? AND ts=?",
                                                                      (coin, r[0]))] if r and r[0] else []
            for h in (4, 24):
                m = laden(coin, h)
                if not m:
                    z.append(f"{coin} {h} h: kein Modell gespeichert"); continue
                if m.get("zu_wenig"):
                    z.append(f"{coin} {h} h: zu wenige Fälle (n {m.get('n')} von mindestens {m.get('min_faelle')})"); continue
                w = m.get("weights") or {}; k_ = m.get("kalib") or {}
                if int(m.get("version") or 1) < MODELL_VERSION or not k_:
                    z.append(f"{coin} {h} h: altes Modell (Summe, ohne Kalibrierschritt) -- wird bei der nächsten stündlichen Kalibrierung ersetzt"); continue
                b = float(k_.get("a") or 0.0); cfak = float(k_.get("c") or 0.0)
                beitr = sorted(((d["name"], cfak * w[d["name"]] * float(d["score"])) for d in drv if d["name"] in w and d["score"] is not None),
                               key=lambda x: -abs(x[1]))
                summe = sum(x[1] for x in beitr); p = 1 / (1 + math.exp(-(b + summe)))
                z.append(f"{coin} {h} h: n {m.get('n')} · n_eff {m.get('n_eff')} · λ {m.get('lam')} · Prior-Anteil {m.get('prior_anteil')} · "
                         f"OOF {json.dumps(m.get('oof'), ensure_ascii=False)}")
                z.append(f"   Kalibrierfaktor c {cfak:.1f} (bestes c {k_.get('bestes_c')}; 0 = keine belegte Aussage, dann Basisrate) · "
                         f"OOF ohne Kalibrierschritt: {json.dumps((m.get('oof_roh') or {}).get('brier_skill'))}")
                o_ = m.get("oof") or {}
                if "skill_ref" in o_:                                                  # U120 (23.47)
                    z.append(f"   Brier-Skill gegen den Kalibrierschritt mit c = 0: {o_.get('brier_skill')} (vor 23.47 gegen die OOF-Klimatologie: "
                             f"{o_.get('brier_skill_klima')})" + (" · c = 0: die OOF-Quote ist nur der Anteil der häufigeren Richtung (Basisrate)"
                                                                  if o_.get("basisrate") else ""))
                z.append(f"   jetzt: p_up {p * 100:.1f} % = Sigmoid(a {b:+.2f} + c × Beiträge {summe:+.2f}) · "
                         f"{len(beitr)} Treiber mit Beitrag")
                z.append("   größte Beiträge: " + " · ".join(f"{n_} {v_:+.2f}" for n_, v_ in beitr[:8]))
                z.append("   größte Gewichte: " + " · ".join(f"{n_} {v_:+.2f}" for n_, v_ in sorted(w.items(), key=lambda x: -abs(x[1] or 0))[:8]))
                zv = m.get("zuverlaessigkeit")
                if zv:
                    z.append(f"   Zuverlässigkeit: {json.dumps(zv, ensure_ascii=False)}")
            z.append("")
    finally:
        st.close()
    z.extend(bilanz_zeilen(db, path, coins)[0])
    return "\n".join(z)



def selbsttest_bilanz() -> bool:
    """23.86 (U230): direkte Bilanz v1/v2 im Bericht „Kalibrierung v2: Stand“ -- erfundene Prognosen (forecasts.db) und Kurse (bars), kein
    Netz.
      B1  die Zahlen im Bericht sind dieselben wie in hl_forecast.score_forecasts (Quelle der Kachel) -- und stimmen mit einer Rechnung von
          Hand (eine Prognose je 15 min, Ruf ab 2 Punkten Abstand zu 0,5, Brier-Skill gegen die Basisrate der Aufwärtsfälle)
      B2  v2-Prognosen eines alten Modells (kalib2.version < 2) zählen nicht, Enthaltungen von v2 gezählt
      B3  U7b-Regel: nur Quote UND Skill v2 ≥ v1 bei je mindestens 100 Fällen; Bericht nennt „erfüllt in …“ bzw. „in keinem Coin“
      B4  ohne --db ein Hinweis statt Zahlen, der Bericht bricht nicht ab
    """
    import random
    import shutil
    import tempfile
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
    tmp = tempfile.mkdtemp(prefix="hl_kalib_bilanz_")
    try:
        store, db = f"{tmp}/forecasts.db", f"{tmp}/hl_liq.db"
        st = F.store_connect(store)
        con = sqlite3.connect(db)
        con.execute("CREATE TABLE bars (coin TEXT, ts INTEGER, open REAL, high REAL, low REAL, close REAL, volume REAL, PRIMARY KEY (coin, ts))")
        rnd = random.Random(23)
        jetzt = int(time.time())
        hand = {}
        for coin, n_, kante1, kante2 in (("BTC", 260, 0.10, 0.00), ("ETH", 240, 0.02, 0.12)):
            v = {"v1": [0, 0, []], "v2": [0, 0, []], "enth": 0, "up": 0, "n4": 0}
            for k in range(n_):
                ts = (jetzt - 5 * 3600 - k * 900) // 900 * 900
                y = rnd.random() < 0.5
                p1 = min(0.95, max(0.05, 0.5 + (kante1 if y else -kante1) + rnd.gauss(0, 0.08)))
                p2 = min(0.95, max(0.05, 0.5 + (kante2 if y else -kante2) + rnd.gauss(0, 0.08)))
                if k % 25 == 0:
                    p2 = 0.51                                              # Enthaltung von v2
                alt = k % 40 == 7                                          # v2 eines alten Modells: zählt nicht
                payload = {"p_up_v1": p1, "p_up_v2": p2, "kalib2": {"version": 1 if alt else 2}}
                st.execute("INSERT INTO forecast (ts, coin, price, p_4h, payload, p_up) VALUES (?,?,?,?,?,?)",
                           (ts, coin, 100.0, 101.0, json.dumps(payload), p1))
                con.execute("INSERT OR REPLACE INTO bars (coin, ts, close) VALUES (?,?,?)", (coin, ts + 4 * 3600, 101.0 if y else 99.0))
                st.execute("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", (ts, coin, "Funding", 0.1))
                yy = 1.0 if y else 0.0
                v["n4"] += 1; v["up"] += y
                for key, pv in (("v1", p1), ("v2", None if alt else p2)):
                    if pv is None:
                        continue
                    v[key][2].append((pv - yy) ** 2)
                    if abs(pv - 0.5) >= 0.02:
                        v[key][0] += 1; v[key][1] += (pv > 0.5) == y
                    elif key == "v2":
                        v["enth"] += 1
            st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, "kalib2_4", json.dumps(
                {"version": 2, "kalib": {"a": 0.0, "c": 0.0 if coin == "ETH" else 0.7}}), 0))
            bu = v["up"] / v["n4"]
            hand[coin] = {key: {"n": v[key][0], "hit_rate": v[key][1] / v[key][0], "brier": round(sum(v[key][2]) / len(v[key][2]), 4),
                                "brier_skill": round(1 - (sum(v[key][2]) / len(v[key][2])) / (bu * (1 - bu)), 4), "n_brier": len(v[key][2])}
                          for key in ("v1", "v2")}
            hand[coin]["enth"] = v["enth"]
        st.commit(); con.commit(); st.close(); con.close()
        text = stand_text(path=store, db=db)
        con = sqlite3.connect(db)
        kachel = {c: F.score_forecasts(con, c, store) for c in ("BTC", "ETH")}
        con.close()
        gleich = all(kachel[c]["direkt_" + key] == {**hand[c][key]} for c in ("BTC", "ETH") for key in ("v1", "v2"))
        zeilen = [z for z in text.split("\n") if z.startswith("   BTC:") or z.startswith("   ETH:")]
        im_text = all(_bilanz(kachel[c]["direkt_v1"]) in z and _bilanz(kachel[c]["direkt_v2"]) in z and f"{kachel[c]['enthalten_v2']} Enthaltungen" in z
                      for c, z in zip(("BTC", "ETH"), zeilen))
        ok("B1 Bericht = score_forecasts (Kachel) = Rechnung von Hand", gleich and im_text and len(zeilen) == 2,
           " · ".join(f"{c} v1 {kachel[c]['direkt_v1']['hit_rate']:.3f}/{kachel[c]['direkt_v1']['brier_skill']:+.4f} "
                      f"v2 {kachel[c]['direkt_v2']['hit_rate']:.3f}/{kachel[c]['direkt_v2']['brier_skill']:+.4f}" for c in ("BTC", "ETH")))
        ok("B2 alte v2-Prognosen nicht gezählt, Enthaltungen gezählt", all(kachel[c]["enthalten_v2"] == hand[c]["enth"] > 0
                                                                           and kachel[c]["direkt_v2"]["n_brier"] < kachel[c]["direkt_v1"]["n_brier"]
                                                                           for c in ("BTC", "ETH")),
           " · ".join(f"{c}: {kachel[c]['enthalten_v2']} Enthaltungen, Brier über {kachel[c]['direkt_v2']['n_brier']} statt "
                      f"{kachel[c]['direkt_v1']['n_brier']}" for c in ("BTC", "ETH")))
        a = {"n": 150, "hit_rate": 0.55, "brier_skill": 0.02}
        b = {"n": 150, "hit_rate": 0.56, "brier_skill": 0.03}
        regel = (u7b_regel(a, b) and not u7b_regel(b, a) and not u7b_regel(a, dict(b, n=99)) and not u7b_regel(a, dict(b, brier_skill=0.01))
                 and not u7b_regel(a, dict(b, hit_rate=0.54)) and not u7b_regel(a, None) and not u7b_regel(a, dict(b, brier_skill=None)))
        erwartet = [c for c in ("BTC", "ETH") if u7b_regel(kachel[c]["direkt_v1"], kachel[c]["direkt_v2"])]
        ok("B3 U7b-Regel: Quote und Skill v2 ≥ v1 bei je mindestens 100; Bericht nennt die Coins und markiert, wo v2 nur die Basisrate ist",
           regel and erwartet == ["ETH"] and "erfüllt in ETH -- U7b neu vorlegen; in ETH ist v2 nur die Basisrate (c = 0)" in text
           and "ETH: v1" in text and "· v2 hier = Basisrate (c = 0)" in [z for z in text.split("\n") if z.startswith("   ETH:")][0]
           and "Basisrate" not in [z for z in text.split("\n") if z.startswith("   BTC:")][0], f"erfüllt in {erwartet}")
        ohne = stand_text(path=store)
        ok("B4 ohne --db ein Hinweis, keine Zahlen", "ohne --db nicht berechnet" in ohne and "   BTC:" not in ohne, ohne.split("\n")[-1][:90])
        import os
        import subprocess
        r = subprocess.run([sys.executable, os.path.abspath(__file__), "--stand", "--db", db], capture_output=True, text=True, timeout=120,
                           env=dict(os.environ, HL_FORECAST_DB=store, PYTHONDONTWRITEBYTECODE="1"))
        ok("B5 Aufruf wie im Debug-Lauf (--stand --db, Ablage über HL_FORECAST_DB): dieselben Zeilen", r.returncode == 0
           and all(z in r.stdout for z in zeilen) and "erfüllt in ETH" in r.stdout, f"Exit {r.returncode}, {len(r.stdout)} Zeichen")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} {traceback.format_exc()[-400:]}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p_[1] for p_ in pruef)
    print("Kalibrierung v2 -- direkte Bilanz v1/v2 im Bericht (23.86, U230)")
    for name, gut, text_ in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<60} {text_}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles

if __name__ == "__main__":
    if "--stand" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv[:-1] else None
        print(stand_text(db=_db))
        sys.exit(0)
    if "--selbsttest-bilanz" in sys.argv:
        sys.exit(0 if selbsttest_bilanz() else 1)
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--aktivieren" in sys.argv:
        schalten(True); print("Kalibrierung v2 AKTIV -- die Prognose nutzt jetzt p_up_v2"); sys.exit(0)
    if "--deaktivieren" in sys.argv:
        schalten(False); print("Kalibrierung v2 im Schatten -- die Prognose nutzt wieder das alte Modell"); sys.exit(0)
    print(__doc__)
