# Übergabe — Hyperliquid-Analysesystem, Stand 13.09.2026, Sitzung 2 (Fable)

Für die nächste Sitzung. Die erste Übergabe vom 13.09. (Sitzung 1, Opus) ist hier
eingearbeitet; das Änderungskonzept liegt als `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
bei und ist die Landkarte für alles Weitere. Code im Archiv `hl_liq_project.zip`.

---

## 1. Was das System ist

Trading-Analysesystem für Hyperliquid auf einem Raspberry Pi 5. Es sagt **nicht**
Kurse voraus, sondern misst, wo gehebelte Positionen liquidiert würden, wer sie hält
und wie sich das verändert — daraus entsteht eine Prognose mit selbstkalibrierenden
Gewichten.

**Fünf Dienste**, alle in dieselbe SQLite-Datei schreibend:

| Dienst | Aufgabe |
|---|---|
| `hl-recorder` | Kern: Adress-Poller, Wal-Verfolgung, Leaderboard, Fills, Snapshots, Backup |
| `hl-dashboard` | `hl_viz.py`, Port 8765, Oberfläche, Prognose und Lernzyklus |
| `hl-binance` | Liquidationen, Kennzahlen, Tageskerzen |
| `hl-coinbase` | Spot: Prämie, Taker-Flow, Orderbuch |
| `hl-watchdog` | Überwachung, Benachrichtigung |

**Datenbank:** `/media/seed/marketdatabase/hl_liq/hl_liq.db` (~3,9 GB, USB-Stick).
`forecasts.db` und `sys_history.json` liegen daneben.

**Coins:** BTC, ETH, HYPE, ZEC, XMR, PAXG — die Liste steht **einmal** in
`install.py` als `COINS`.

---

## 2. Eiserne Regeln dieses Projekts

**Zeitstempel sind SEKUNDEN.** Ausnahmen: `addresses.last_trade` und `first_seen` in
Millisekunden (bewusst). Erkennungsgrenze ms gegen s ist **1e11**. **Neu:** Der
Datenbank-Audit (`hl_recorder.py --audit`, Teil des Selbsttests) prüft das als Invariante
über alle Tabellen — eine Millisekunden-Zeile ergibt FEHLT und Exit 1.

**Seiten sind normalisiert.** `side` steht als `"long"`/`"short"` in der Datenbank und
wird beim Lesen **nicht** neu abgeleitet. Der Audit meldet Fremdwerte.

**Maker gegen Taker.** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`hl_coinbase.py --selftest` prüft das als erste Zeile.

**Das IP-Limit ist nicht erhöhbar.** 1.200 Gewicht je Minute und IP. `clearinghouseState`
2, übrige Info-Abfragen 20, `userFillsByTime` plus 1 je 20 Einträge. **WebSocket:**
höchstens **10 verschiedene Nutzer** über nutzerbezogene Abonnements (Doku, 13.09.
geprüft) — das ist die Vorgabe für die Elite-Liste im Konzept, kein Hindernis.

**Stichproben sind n_eff, nicht Fenster.** Alle 15 min eine Prognose, Bewertung nach
h Stunden: n_eff = Zahl getrennter h-Stunden-Blöcke (≈ Fenster / 16 bei 4 h; bei
geklumpten Ereignis-Treibern die Zahl der Episoden — `n_eff_bloecke`). Jede Quote im System trägt ein Wilson-Intervall
auf n_eff und steht neben ihrer Basisrate. Eine Zahl ohne Intervall ist keine Aussage.

**Prüfen statt behaupten.** Jeder Befund wird vor der Korrektur nachgestellt. In dieser
Sitzung: alle Konzeptbefunde am Code bestätigt, zwei eigene Fehler durch den Nulltest
gefunden (Lernrate nach Umnormierung, Magnet-Intervall zu eng).

---

## 3. In Sitzung 2 erledigt

### Kalibrierung (`hl_forecast.calibrate_weights`)

- **Befund bestätigt:** `lam = 4.0 / max(n, 1)` mit überlappenden Fenstern. Bei 2.000
  Fenstern λ = 0,002 → Prior praktisch abgeschafft; auf reinem Rauschen wanderten
  Gewichte um bis zu 0,12 (gemessen, drei Seeds).
- **Neu:** λ = 4 / n_eff (n_eff = getrennte Horizont-Blöcke, `n_eff_bloecke`); Lernstart ab
  n_eff 40 je Horizont (4 h: rund eine Woche; 24 h: rund 40 Tage); ein Treiber verlässt
  seinen Prior erst ab eigenen unabhängigen Fällen — **je Horizont gestaffelt**
  (`MIN_N_EFF_TREIBER = {4: 50, 24: 30}`, Re-Audit N1: `forecasts.db` behält 60 Tage, die
  24-h-Spur sieht also nie mehr als ~60 Blöcke). Die 24-h-Spur trainiert mit **einem
  Fenster je Stunde** (`TRAIN_STRIDE`), 60 Tage = 1.440 Fenster, Laufzeit ~1 s auf dem Pi.
- **Zwei Spuren:** 4 h (Hauptspur, alle 15 min, `weights_h` h=4, Spiegel in `weights`)
  und 24 h (stündlich, `weights_h` h=24). `compute_forecast` nutzt die 4-h-Gewichte für
  `bias` und den Pfad bis 24 h, die 24-h-Gewichte (`bias_24`) für die Drift danach.
- **β, gelernter Maßstab:** P(auf) = sigmoid(β · Σ wᵢxᵢ / Σ Priors). Gespeichert als
  `p_up` / `p_up_24` je Prognose (neue Spalten). Vor dem Lernen β = 1 → p_up ist dann
  eine Vorgabe. Meta (n, n_eff, λ, β) in `learned.cal_4` / `cal_24`.
- **Gegenprobe:** Ein Treiber mit echten 65 % (4 h) wird gelernt: 1,20 → 1,27 nach 14
  Tagen, 1,29 nach 28; β steigt auf 1,09. Rauschen bewegt nichts mehr (≤ 0,01).
- Laufzeit `forecast_learn` mit 1.900 Fenstern: 1,1 s hier, Pi etwa 4 s.

### Trefferbilanz (`score_forecasts`)

Eine Prognose je 15-min-Fenster (Sofortprognosen zählen nicht doppelt), Blöcke `q4` und
`q24` mit n, n_eff, Wilson-Intervall, Basisrate („immer aufwärts" in denselben Fenstern),
Brier-Score und Brier-Skill. Alte Felder (`n`, `hit_rate`, `hit_rate_4h`, `model`,
`analog`, `oos`, `mae_pct`) bleiben für `check_report.py`. Die `wver`-Trennung heißt jetzt
„Seit Gewichtsversion" — alle gespeicherten Prognosen sind ohnehin walk-forward.

### Ensemble

Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Pseudo-Priors 0,56/0,54 = alte
Mischung 60/40, Nullpunkt 0,5), gedeckelt 30–70 % bis n_eff 50 je Modell. Vorher:
`hit_rate − 0,4` ohne Schrumpfung — 32/68 aus anderthalb Tagen.

### M9, M6, M10 — erledigt

- **M9** (`hl_viz.py`, Wal-Flow `pack()` und Leaderboard-Flow): `event_signal` = Rang in
  der vollständigen Wochenreihe ≥ 98 % (`hl_forecast.rang_in_reihe`, vom Nulltest geprüft;
  Vergleichsreihe ohne die laufende Stunde)
  **und** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto) **und** Breite
  (4 bzw. 3 Konten), mindestens 48 h Historie. Z-Wert bleibt für die Anzeige,
  `event_signal_z` zeigt die alte Regel zum Vergleich. **`check_m9.py --db …`** zählt die
  Feuerraten alt/neu der letzten 7 Tage auf den echten Daten — **das ist noch zu laufen**
  (hier nur mit synthetischen Ereignissen geprüft: echter Schub feuert in beiden Regeln).
- **M6** (`hl_recorder.py analyze`): `dropna` auf `fwd_4h`, Anzahl „noch ohne Ergebnis"
  wird ausgewiesen; dazu Placebo-Basisrate (4 h aufwärts/abwärts über alle Zeitpunkte)
  und Lift.
- **M10** (`load_stops`): `bucket_px()` statt `round(…, 2)` — Fusion findet jetzt zusammen.

### Weitere Statistik

- **Magnet-Statistik:** Placebo-Niveau (gleicher Abstand, andere Seite, gleicher
  Zeitpunkt), `p_placebo`, `lift`, Intervall auf n_eff = getrennte 12-h-Blöcke.
- **Analog-Suche:** `p_up` mit Intervall und unbedingter Basisrate `p_up_base`; der
  Treiber misst gegen die Basisrate statt gegen 0,5.
- **Zeitprofil:** rollierend 180 Tage.

### Nulltest und Selbsttest

`hl_forecast.py --nulltest` (Teil von `install.py --selftest`): Wilson-Überdeckung,
Quote 4 h/24 h enthält 50 %, Brier-Skill ≈ 0, Gewichte beim Prior, Magnet-Lift 1,
Rang-Signal ~2 %. Läuft in 0,3 s. Selbsttest kompiliert jetzt auch `hl_forecast.py`,
`hl_coinbase.py` und `hl_score.py`; Audit-Schritt heißt „mit Einheiten-Invarianten";
17 Schritte, alle grün.

### Konto-Score — P1, Teil 1 (`hl_score.py`, neu)

Die goldene Regel wird messbar: je Konto und Coin ein Score aus **Vorlauf** (35 %,
Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, ein Schritt je Stunde,
geschrumpft n/(n+20)), **Edge je Umsatz** (25 %, PnL/Umsatz), **Konsistenz** (20 %, vier
Leaderboard-Fenster), **Größe** (10 %) und **Klasse** (10 %); rangnormiert, täglich neu,
Schnappschuss in `forecasts.db` → `account_score` (120 Tage Vorhalt).

- **Recorder:** neue Tabelle `lb_stats` (alle vier Leaderboard-Fenster mit `pnl`, `roi`,
  `vlm` für Kandidaten **und** bekannte Wale, stündlich ersetzt). Der Umsatz wurde bisher
  beim Parsen verworfen — er ist die billigste Trennlinie zwischen Market Makern und
  Händlern.
- **Drei neue Treiber** in `compute_forecast`: `Smart-Flow 4 h` (1,0; Fluss mit Score
  gewichtet, √Notional), `Elite-Positionierung` (1,0; Netto der zehn besten Konten),
  `Gegen-Flow` (0,3; Konten mit belegt negativem Vorlauf, n ≥ 20, invertiert).
  **Gestrichen:** `Wal-Flow Hedge`, `Wal-Flow Market Maker`, `Wal-Flow gemischt`.
- **Score-Test** wöchentlich (`learned.score_test`): Spearman des Scores von vor 7 Tagen
  gegen den Vorlauf der Folgewoche, je Komponente, mit SE ≈ 1/√(n−1). Erster Wert
  frühestens sieben Tage nach dem ersten Schnappschuss. Im Selbsttest mit 16 Konten ist
  ρ ± 0,26 — Aussagekraft braucht die Hunderte Konten des Pi.
- **Elite-Liste** `learn.elite` (Top 10 nach Score, nur direktional/gemischt) — das ist
  die Vorgabe für die WebSocket-Abonnements (Konzept 2.5), noch nicht angeschlossen.
- Kachel „Konto-Score" in der Selbstoptimierung; Selbsttest-Schritt „Konto-Score
  (hl_score)" (drei synthetische Konten mit echtem Vorlauf müssen die Elite stellen).

### Dashboard

Trefferquote-Kachel: „4 h: 57 % (47–66) · Basis 51 % · n_eff 108 · Brier-Skill".
Gelernte Gewichte: n_eff, Fenster, β, λ beider Spuren. Treibertabelle: Intervall und
n_eff je Treiber. Magnet: „93 vs 90 %" (berührt vs Placebo), Lift mit Intervall.
Lernplan: Lernbeginn nach n_eff, fehlende Fenster. Browsertest Handy/Desktop ohne
JS-Fehler; `node --check` beider Skriptblöcke grün.

---

## 3b. Audit der eigenen Änderungen (Sitzung 2, auf Wunsch)

Jede Änderung wurde nachgelesen, Randfälle ausgeführt. **Gefunden und behoben:**

| Befund | Wirkung | Korrektur |
|---|---|---|
| Seiten-Invariante im Audit hätte auf dem Pi **falsch gewarnt** | `liquidations`, `lb_fills`, `trigger_orders`, `ticks` tragen absichtlich die Rohseiten `A`/`B` | Prüfung nur auf Positions-Tabellen (heatmap, whale_positions, lb_positions, lb_events, bnc_liquidations, cluster_events) |
| ms-Invariante: Nullen in `first_seen`/`last_trade` wären als „Sekunden" gemeldet worden | falscher FAIL möglich | `MIN(...) WHERE > 0` |
| `update.py` sicherte `hl_score.py` und `check_m9.py` nicht vor dem nächsten Update | Verlust bei Rücksprung | in `PROJECT_FILES` aufgenommen |
| Rang-Vergleichsreihe enthielt die **laufende Stunde** — also den Wert, der eingeordnet wird | Signal wirkt kleiner als es ist; galt auch für den alten Z-Wert | laufende Stunde aus der Reihe genommen (Wal-Flow, Leaderboard-Flow, `check_m9.py`) |
| Elite-Positionierung zählte ein Konto doppelt, wenn es Leaderboard-Konto **und** Wal ist | Netto verzerrt | Leaderboard-Stand hat Vorrang, Wal-Zeile wird übersprungen |
| n_eff = Fenster · 0,25 / h unterstellt gleichmäßige Fenster | Ereignis-Treiber (geklumpte Fenster) wurden zu optimistisch, seltene Treiber zu pessimistisch gezählt (52 Fenster in 13 Episoden: Formel 3,2, Wahrheit 13) | `n_eff_bloecke`: getrennte Horizont-Blöcke, in Kalibrierung und Trefferbilanz |
| Wilson-Intervall bei n_eff < 1 | sinnlose Klammer (0–100) | Intervall erst ab einem unabhängigen Fall |
| forecasts.db-Verbindung im Score-Abschnitt blieb bei Fehler offen | Handle-Leck | `finally: close()` |
| Unveränderte Gewichte wurden alle 15 min neu geschrieben | unnötige Schreiblast | Auffrischen höchstens stündlich |

**Geprüft und in Ordnung:** Gradienten der Kalibrierung (Logit, L2, Schrittweiten stabil);
Konsistenz von `p_up` zwischen Kalibrierung und Prognose (fehlende Treiber = 0, gleiche
Normierung); alle Zeitspalten der Binance-, Coinbase- und Timestats-Tabellen in Sekunden;
`lb_stats`-Spaltenzahl gegen INSERT; Lesezugriffe von `check_report`/`check_forecast` auf die
neue Bewertungsstruktur; JSON-Serialisierbarkeit aller gespeicherten Felder; JS-Syntax beider
Skriptblöcke; Selbsttest 17/17, Nulltest, Positivkontrollen (echter Treiber wird gelernt,
Rauschen nicht; Elite aus Konten mit echtem Vorlauf).

## 3c. Externer Re-Audit (Kimi K3, gleicher Tag) — abgearbeitet

Der Re-Audit bestätigte die Statistik-Umbauten numerisch (Lernkurven, Nulltest, Invarianten)
und fand einen MEDIUM-Befund plus 14 LOW; alle am Code nachgestellt, dann korrigiert:

| Befund | Korrektur |
|---|---|
| **N1 24-h-Spur lernt nie** (MAX_TRAIN 4000 < 50 Blöcke; dazu 60-Tage-Vorhalt) | Schwelle je Horizont {4: 50, 24: 30}, ein Fenster je Stunde, `gelernt` nur bei aktiven Treibern. Gegenprobe: ab 40 Tagen lernt die Spur (Wale 1,20 → 1,26 bei 60 T) |
| H2-Rest: drei unmaskierte Namen (`innerHTML`) | `esc()` für Name, `market`, `dir` in beiden Fill-Tabellen und der Wal-Tabelle |
| N2 `schreibe()` blockierte mit `time.sleep` die Ereignisschleife | `async`, `asyncio.sleep`; bei Endfehlschlag Wert nicht als geschrieben verbuchen |
| N3 Coinbase-Kachel `toFixed` auf null | Null-Guard |
| N4 Volumenvergleich laufende gegen volle Stunden | gleitende 60 min (`flow60`) gegen den Schnitt voller Stunden |
| N5/M14 `/leaderboard`-`days` ungeklemmt, `_LB_CACHE` ohne Kappe | `_grenze(1..90)`, `_kappen(48)` |
| N6 Coinbase `busy_timeout` 60 s > Heartbeat 20 s | 5 s, sperr-tolerantes `schreibe()` mit Zähler `db_locked` |
| N7 Backoff-Reset sofort nach Connect | Reset erst nach einer stabilen Minute |
| N8 `ws_connect(timeout=20)` als Zahl | `ClientWSTimeout`, Rückfall auf Zahl bei alter aiohttp |
| N9 Minuten-Bucket aus lokaler Uhr | Nachrichtenzeit, wenn plausibel (±10 min) |
| N10/N11/N16 Vorgabe-Coins, Kommentar 2 %, tote Imports | angeglichen |
| N12 `check_m9 --days 0` | geklemmt 1..60 |
| N13 Wal/Leaderboard-Überlappung doppelt gezählt | Konto nur aus `whale_positions`, wenn dort vorhanden (nachgewiesen) |
| N14 Elite je Coin mit Fremdkonten | Elite nur aus Konten mit Schritten im Coin |
| N15 Kommentar zur Lernrate falsch | Schritt bleibt im Gewichtsraum gleich, nicht im Logit-Raum — so steht es jetzt da |
| Zeitprofil: Division durch null bei kurzer Historie (eigener Fund beim Regressionslauf) | kein Profil unter 24 gefüllten (Wochentag, Stunde)-Zellen |

**Aus der offenen Recorder-/Betriebsliste zusätzlich erledigt:** M3 (`blake2b` statt
gesalzenem `hash()` — deterministische tid über Neustarts), M4 (Fehlschlag macht die Adresse
nach fünf Minuten wieder fällig, Zähler `poll_failed`), M5 (alle Adressen mit Position),
M12 (Rückfallschwelle statt `TypeError`), M13 (Symbolauflösung bis zehn Minuten wiederholen,
dann Exit 1), M16 (Open-Interest-Abruf im Thread).

**Bewusst offen — Entscheidungen des Nutzers oder eigene Sitzung:** C4-Rest (Auth-Token
für `POST /update`, `install.py --host 0.0.0.0`, ZIP-Manifest/Signatur, sudoers statt
`sudo.txt`), M1/M2 (Positionen über Neustart, Markpreis-Touch), H5/M15 (Migration), die
~38 LOW-Befunde des Erstberichts.

## 3e. Der „Fill-Rückstand" war ein Phantom (gefunden mit Live-Probe auf dem Pi)

Seit Sitzung 1 galt: „34 von 79 Konten im Rückstand, schlechtestes 63 h", und der
Adress-Poller wurde deshalb **auf 10 % gedrosselt** zugunsten der Fill-Abholung. Die
Live-Probe (`check_fills.py`, Abschnitt 4) zeigte für die schlechtesten Konten: sofortige
Antwort, Teilseiten, und **alle gelieferten Fills lagen bei 53 Stunden** — die Konten hatten
seitdem nicht gehandelt. `lb_fills_deferred = 0`: Das Budget hat nie ein Konto vertagt.

**Ursache:** Der Abholstand wurde auf den neuesten *geholten* Fill gesetzt. Die Abholung
beginnt zehn Minuten davor, bekommt bei einem inaktiven Konto jedes Mal dieselben alten
Fills zurück, die Antwort ist nicht leer — der Stand rückte nie auf „jetzt". Ein Konto, das
aufhört zu handeln, sah für immer wie Rückstand aus.

**Korrektur (`hl_recorder.py`, Fill-Schleife):** Eine Teilseite (unter 2.000 Einträge) heißt,
die API hat alles bis jetzt geliefert → Stand = jetzt − 10 min, unabhängig davon, ob Fills
darin waren. Nur bei ausschließlich vollen Seiten reicht der Stand bis zum neuesten Fill.
Dazu: Kachel „Fill-Abholstand" zählt nur Konten der aktuellen Auswahl (10 veraltete Stände
ausgeschiedener Konten zählten mit); der Recorder räumt solche Stände nach 7 Tagen auf.

**Erwartung nach dem Einspielen:** Der Rückstand fällt binnen einer Stunde auf wenige
Konten (die mit wirklich vielen Fills), die Poller-Drossel hebt sich von selbst auf
(`poller_drossel` 0,10 → 1,0), die Heatmap-Abdeckung steigt. Das ist zugleich die Antwort
auf die Budgetfrage aus dem Konzept: Hedge- und MM-Konten erzeugen nur **9 %** aller Fills
(gemessen), nicht 70 % — „Fills nur für direktionale Konten" spart weniger als angenommen.
Die Konzept-Annahme ist damit widerlegt und in 2.4 zu korrigieren; der Poller bekommt sein
Budget durch die Cursor-Korrektur zurück, nicht durch Streichen von Fills.

**Weitere Messwerte vom Pi (13.09., 21:08–21:34):** Nulltest und Konto-Score-Selbsttest
grün; M9: Rang trifft alle drei Fälle der alten Regel und findet einen vierten (11.09.
16:00, −54 Mio aus 12 Konten), Feuerrate 2,4 %; Leaderboard-Flow dreimal am 13.09., alle
24–35 Mio.

## 3f. Prüfung des Mix-Modus (Fremdbörsen in den Statistiken)

Jede Fremdquelle einzeln verfolgt: Tabelle → Leser → Frischeprüfung → Treiber.

| Quelle | Fließt ein in | Frische | Befund |
|---|---|---|---|
| Binance Taker-Verhältnis (5 min, live) | Treiber „Taker-Flow" (Log-Mittel aller Börsen) | live, 5-min-Cache | korrekt |
| OKX Taker (5 min), Bybit / Crypto.com (Trade-Listen) | „Taker-Flow" | Mindestspanne 60 s | korrekt; Fenster uneinheitlich (5 min vs. 150/500 Trades) — Schwäche, kein Fehler |
| Binance-Liquidationen | Kapitulation | 3 Tage | korrekt (Sekunden, Seiten normalisiert); HL-eigene Liquidationen nicht enthalten (Designentscheidung) |
| Binance- und Crypto.com-Orderbuch | Wände im Pfadmodell (fusionierte Cluster) | 15-s-Cache | korrekt (M10 behoben) |
| HL-Buch (`book_summary`), HL-Funding | „Orderbuch", „Funding" | 10 / 15 min | korrekt, nur HL — Fremdfunding nur Anzeige |
| Coinbase Spot | Prämie, Spot-Taker, Spot-Buch | 30 min | korrekt |
| Binance Tages-/30-min-Kerzen | MA 200 / 50 W, Analog-Suche, Zeitprofil | — | korrekt |
| Binance-Volumen | **Magnet-Schwelle der Prognose** | — | **Fehler, behoben** (unten) |

**Der Fehler:** Die Prognose rechnet immer im Fusionsmodus; dort ist `vol_1h` die Summe
aus HL + Binance + Crypto.com. Die Schwelle „Cluster ≥ ½ Stundenvolumen" war für das
HL-Volumen gedacht — gegen das Fünf- bis Zehnfache war kein HL-Liquidationscluster je groß
genug, und die Prognose lief bei BTC/ETH ohne Magneten und Stop-Auslöser auf dem
Sigma-Pfad. Die Magnet-Statistik dagegen rechnete ihre Schwelle korrekt aus dem HL-Volumen
— Statistik und Prognose vermaßen verschiedene Populationen. **Jetzt:** HL-Cluster und
HL-Stops gegen das HL-Volumen (`vol_split.hl`), fusionierte Bücher gegen das fusionierte
Volumen. Die Kachel „Magnet-Statistik" zeigt Schwelle, HL-Stundenvolumen und größten
Cluster je Seite — damit ist sichtbar, woran ein Magnet scheitert.

**Nebenbefund (eigener Fehler):** `score_forecasts` kehrte bei fehlenden Prognosen früh
zurück, ohne die internen Zähler (darunter ein `set`) zu entfernen → `/forecast` für einen
Coin ohne gespeicherte Prognosen hätte HTTP 500 geliefert. Behoben.

## 3g. Binance-Liquidationen: 13 Tage lang null Zeilen (gefunden 14.09., 00:02)

`bnc_liquidations` war leer — seit dem ersten Start. Der Weg zur Ursache: „36 Datensätze/h"
in der Quellenzeile (= nur die 10-min-OI-Abfragen) → `--status` zeigt **Liquidationen 0**,
Stream **Events 0** → die Unit auf dem Pi schreibt gepuffert ins Journal, die Fehlermeldung
kam nie an → Stream-Probe (`hl_binance.py --probe-stream`): DNS, TCP, TLS, Handshake ok,
**0 Nachrichten**. Dann die Dokumentation: Binance hat die Futures-WebSockets am 06.03.2026
in `/public`, `/market`, `/private` aufgeteilt und die alten Basis-URLs am **23.04.2026**
abgeschaltet — der Handshake auf `wss://fstream.binance.com/ws/…` gelingt weiter, aber
`/market`-Streams (darunter `!forceOrder@arr`) liefern dort nichts mehr.

**Korrektur:** `WS = wss://fstream.binance.com/market/ws/!forceOrder@arr`. Dazu: `--status`
zeigt die Stream-Zähler, `--probe-stream` als Debug-Eintrag, Quellenzeile weist den
Liquidations-Stream getrennt aus („STREAM PRÜFEN" ab 2 h Stille), Stream-Meldungen mit
`flush`, alle Units `PYTHONUNBUFFERED=1` (wirksam nach `install.py --systemd`).

**Folgen:** Der Treiber „Kapitulation" hatte nie Daten; seine Trefferquote in allen
bisherigen Berichten war leer. Er startet jetzt bei n_eff 0 wie ein neuer Treiber. Alles,
was im Erst-Audit über bnc_liquidations gefixt wurde (C1 ms→s, C2 Seiten), war korrekt —
nur ohne Daten. Nach dem Einspielen sollten binnen Minuten Zeilen erscheinen (Binance pusht
je Symbol bis zu eine Liquidation pro Sekunde); wenn nicht: Stream-Probe erneut.

**Lehre für die Arbeitsweise:** „Dienst läuft" ist keine Aussage über Daten. Jede Quelle
braucht einen Zähler ihrer *Nutzdaten* mit Alarm bei Stille — nicht nur einen Lebenszeichen-
Stempel.

## 3d. Debug-Konsole

Die neuen Werkzeuge stehen in der Debug-Liste des Dashboards (`debug_commands` in
`hl_viz.py`): **Fill-Abholstand** (`check_fills.py` — welche Konten hängen, Klasse, Fills je
Tag), **Ereignis-Signal M9** (`check_m9.py`), **Nulltest**, **Konto-Score-Selbsttest**. Jedes
neue Diagnosewerkzeug gehört dort eingetragen — vom Handy aus ist die Konsole der einzige
Weg, es zu starten.

## 4. Was beim ersten Start auf dem Pi zu erwarten ist

- `forecasts.db` bekommt die Tabelle `weights_h` und die Spalten `p_up`, `p_up_24`
  automatisch (`store_connect`). Der Reset-Marker von Sitzung 1 bleibt gesetzt; die
  Gewichte starten beim Prior in beiden Spuren.
- **Der Lernbeginn springt nach hinten**: Statt „läuft" steht für rund eine Woche
  „n_eff 4 h: x von 40". Das ist richtig — die bisherigen 40 Fenster waren zehn Stunden
  Daten. Die 24-h-Spur bleibt etwa 40 Tage beim Prior (dann Schwelle 30 Blöcke je Treiber).
- **Trefferquoten fallen und bekommen Klammern.** Beides ist richtig (M7 plus Intervall).
  Grün wird eine Quote erst, wenn das Intervall ganz über der Basisrate liegt.
- **Das Ereignis-Signal feuert seltener.** `check_m9.py` zeigt, wie viel seltener.
- `p_up` liegt anfangs nahe 50 %, auch bei deutlichem `bias`: Ohne gelerntes β und mit
  wenigen aktiven Treibern ist die kalibrierte Wahrscheinlichkeit bewusst zurückhaltend.
- **Konto-Score:** Beim ersten Lernlauf entsteht der erste Schnappschuss aus den letzten
  28 Tagen Ereignissen. `lb_stats` füllt sich erst mit dem nächsten Leaderboard-Abruf —
  bis dahin fehlen Edge und Konsistenz (zählen neutral 0,5), der Score lebt von Vorlauf,
  Größe und Klasse. Die Treiber Smart-Flow / Elite / Gegen-Flow erscheinen ab dem ersten
  Schnappschuss; Gegen-Flow erst, wenn Konten n ≥ 20 Schritte haben.

---

## 5. Nächste Schritte, in dieser Reihenfolge (Konzept Abschnitt 6)

1. **Auf dem Pi zuerst messen, nicht ändern:** `install.py --selftest` (Nulltest,
   Invarianten), `hl_recorder.py --db … --audit`, `check_m9.py --db …`, und die fünf
   Abfragen aus Anhang A des Konzepts (Pareto der Heatmap-Masse, Fill-Verbraucher je
   Klasse, Poll-Takte je Wertstufe, n gegen n_eff je Coin). Diese Zahlen legen die
   Stufen der Budget-Tabelle fest.
2. ~~P1 — Konto-Score~~ **erledigt** (hl_score.py). Offen daran: Vorlauf zusätzlich aus
   `lb_fills` (heute nur Positionsereignisse) und Score je Coin für ETH/HYPE prüfen, ob
   genug Schritte anfallen.
3. **P1 — Budget nach Score** (Recorder): Fills nur direktional/gemischt, Orders nur
   S1/S2, Stufen S1–S5, Sichtung nach Handelsgröße, **WebSocket-Abonnements für
   `learn.elite`** (`userFills` + `userEvents`, REST alle 5 min als Lückenfüller). Braucht
   einen Kanal Dashboard → Recorder für Klasse und Score (Vorschlag: Tabelle
   `account_class` in der Hauptdatenbank, vom Dashboard täglich geschrieben).
4. ~~P1 — Smart-Flow, Elite-Positionierung, Gegen-Flow~~ **erledigt**; Killkriterium
   (Konzept 3.4: Intervall enthält 50 % und Gewicht < 0,3 × Prior bei n_eff ≥ 50 → parken)
   noch offen — braucht erst n_eff 50.
5. **P2 — M1–M3** (Liquidationsableitung), Treiber-Familien, Live-Abrufe Bybit/OKX/
   Crypto.com in den Binance-Dienst, Leaderboard als Wal-Liste.
6. **P3 — Konfluenz zeigt Prognose-Beiträge; M4, M5, M12, M13, M15, M16; Git auf dem Pi.**

---

## 6. Offene Befunde aus dem Audit (unverändert seit Sitzung 1)

**Datenqualität:** M1 (Positionen über Neustart), M2 (Markpreis statt Handelspreis).
~~M3, M4, M5~~ erledigt (3c). **Betrieb:** M15 (Migration der Nebendateien); ~~M12, M13,
M16~~ erledigt (3c).
**Sicherheit, bewusst offen:** Dashboard lauscht auf allen Adressen — Entscheidung des
Nutzers.

---

## 7. Arbeitsweise, die sich bewährt hat

- **Prüfen statt behaupten.** Auch das eigene Konzept: Zwei Annahmen darin waren falsch
  (Analog-Suche läuft bereits stündlich; ihre Merkmale sind fest standardisiert) und
  sind im Konzept korrigiert.
- **Nulltest vor Vertrauen.** Er hat in dieser Sitzung zwei Fehler in frisch
  geschriebenem Code gezeigt, bevor sie ausgeliefert wurden.
- **Nach jeder Änderung:** `python -m compileall`, `node --check` der ausgelieferten
  Seite, Browsertest Handy und Desktop, alle Endpunkte, `install.py --selftest`.
- **Beim Löschen von Codeblöcken vorsichtig schneiden**; Patches mit `assert count == 1`.
- **Ein Server je Port.** „Port bereits belegt" liefert stillschweigend die alte
  Fassung aus — beim Testen immer auf einen frischen Port.
- **Tests, die Fehler festschreiben, sind gefährlicher als fehlende Tests.** Deshalb
  kommt das Soll des Nulltests aus der Mathematik.
