# Übergabe — Hyperliquid-Analysesystem, Stand 13.09.2026, Sitzung 2 (Fable)

Für die nächste Sitzung. Die erste Übergabe vom 13.09. (Sitzung 1, Opus) ist hier
eingearbeitet; das Änderungskonzept liegt als `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
bei und ist die Landkarte für alles Weitere. Code im Archiv `hl_liq_project.zip`.

---

## 1. Was das System ist

Trading-Analysesystem für Hyperliquid auf einem Raspberry Pi 5. Es sagt **nicht**
Kurse voraus, sondern misst, wo gehebelte Positionen liquidiert würden, wer sie hält
und wie sich das verändert — daraus entsteht eine Prognose mit selbstkalibrierenden
Gewichten.

**Fünf Dienste**, alle in dieselbe SQLite-Datei schreibend:

| Dienst | Aufgabe |
|---|---|
| `hl-recorder` | Kern: Adress-Poller, Wal-Verfolgung, Leaderboard, Fills, Snapshots, Backup |
| `hl-dashboard` | `hl_viz.py`, Port 8765, Oberfläche, Prognose und Lernzyklus |
| `hl-binance` | Liquidationen, Kennzahlen, Tageskerzen |
| `hl-coinbase` | Spot: Prämie, Taker-Flow, Orderbuch |
| `hl-watchdog` | Überwachung, Benachrichtigung |

**Datenbank:** `/media/seed/marketdatabase/hl_liq/hl_liq.db` (~3,9 GB, USB-Stick).
`forecasts.db` und `sys_history.json` liegen daneben.

**Coins:** BTC, ETH, HYPE, ZEC, XMR, PAXG — die Liste steht **einmal** in
`install.py` als `COINS`.

---

## 2. Eiserne Regeln dieses Projekts

**Zeitstempel sind SEKUNDEN.** Ausnahmen: `addresses.last_trade` und `first_seen` in
Millisekunden (bewusst). Erkennungsgrenze ms gegen s ist **1e11**. **Neu:** Der
Datenbank-Audit (`hl_recorder.py --audit`, Teil des Selbsttests) prüft das als Invariante
über alle Tabellen — eine Millisekunden-Zeile ergibt FEHLT und Exit 1.

**Seiten sind normalisiert.** `side` steht als `"long"`/`"short"` in der Datenbank und
wird beim Lesen **nicht** neu abgeleitet. Der Audit meldet Fremdwerte.

**Maker gegen Taker.** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`hl_coinbase.py --selftest` prüft das als erste Zeile.

**Das IP-Limit ist nicht erhöhbar.** 1.200 Gewicht je Minute und IP. `clearinghouseState`
2, übrige Info-Abfragen 20, `userFillsByTime` plus 1 je 20 Einträge. **WebSocket:**
höchstens **10 verschiedene Nutzer** über nutzerbezogene Abonnements (Doku, 13.09.
geprüft) — das ist die Vorgabe für die Elite-Liste im Konzept, kein Hindernis.

**Stichproben sind n_eff, nicht Fenster.** Alle 15 min eine Prognose, Bewertung nach
h Stunden: n_eff = Zahl getrennter h-Stunden-Blöcke (≈ Fenster / 16 bei 4 h; bei
geklumpten Ereignis-Treibern die Zahl der Episoden — `n_eff_bloecke`). Jede Quote im System trägt ein Wilson-Intervall
auf n_eff und steht neben ihrer Basisrate. Eine Zahl ohne Intervall ist keine Aussage.

**Prüfen statt behaupten.** Jeder Befund wird vor der Korrektur nachgestellt. In dieser
Sitzung: alle Konzeptbefunde am Code bestätigt, zwei eigene Fehler durch den Nulltest
gefunden (Lernrate nach Umnormierung, Magnet-Intervall zu eng).

---

## 3. In Sitzung 2 erledigt

### Kalibrierung (`hl_forecast.calibrate_weights`)

- **Befund bestätigt:** `lam = 4.0 / max(n, 1)` mit überlappenden Fenstern. Bei 2.000
  Fenstern λ = 0,002 → Prior praktisch abgeschafft; auf reinem Rauschen wanderten
  Gewichte um bis zu 0,12 (gemessen, drei Seeds).
- **Neu:** λ = 4 / n_eff (n_eff = getrennte Horizont-Blöcke, `n_eff_bloecke`); Lernstart ab
  n_eff 40 je Horizont (4 h: rund eine Woche; 24 h: rund 40 Tage); ein Treiber verlässt
  seinen Prior erst ab eigenen unabhängigen Fällen — **je Horizont gestaffelt**
  (`MIN_N_EFF_TREIBER = {4: 50, 24: 30}`, Re-Audit N1: `forecasts.db` behält 60 Tage, die
  24-h-Spur sieht also nie mehr als ~60 Blöcke). Die 24-h-Spur trainiert mit **einem
  Fenster je Stunde** (`TRAIN_STRIDE`), 60 Tage = 1.440 Fenster, Laufzeit ~1 s auf dem Pi.
- **Zwei Spuren:** 4 h (Hauptspur, alle 15 min, `weights_h` h=4, Spiegel in `weights`)
  und 24 h (stündlich, `weights_h` h=24). `compute_forecast` nutzt die 4-h-Gewichte für
  `bias` und den Pfad bis 24 h, die 24-h-Gewichte (`bias_24`) für die Drift danach.
- **β, gelernter Maßstab:** P(auf) = sigmoid(β · Σ wᵢxᵢ / Σ Priors). Gespeichert als
  `p_up` / `p_up_24` je Prognose (neue Spalten). Vor dem Lernen β = 1 → p_up ist dann
  eine Vorgabe. Meta (n, n_eff, λ, β) in `learned.cal_4` / `cal_24`.
- **Gegenprobe:** Ein Treiber mit echten 65 % (4 h) wird gelernt: 1,20 → 1,27 nach 14
  Tagen, 1,29 nach 28; β steigt auf 1,09. Rauschen bewegt nichts mehr (≤ 0,01).
- Laufzeit `forecast_learn` mit 1.900 Fenstern: 1,1 s hier, Pi etwa 4 s.

### Trefferbilanz (`score_forecasts`)

Eine Prognose je 15-min-Fenster (Sofortprognosen zählen nicht doppelt), Blöcke `q4` und
`q24` mit n, n_eff, Wilson-Intervall, Basisrate („immer aufwärts" in denselben Fenstern),
Brier-Score und Brier-Skill. Alte Felder (`n`, `hit_rate`, `hit_rate_4h`, `model`,
`analog`, `oos`, `mae_pct`) bleiben für `check_report.py`. Die `wver`-Trennung heißt jetzt
„Seit Gewichtsversion" — alle gespeicherten Prognosen sind ohnehin walk-forward.

### Ensemble

Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Pseudo-Priors 0,56/0,54 = alte
Mischung 60/40, Nullpunkt 0,5), gedeckelt 30–70 % bis n_eff 50 je Modell. Vorher:
`hit_rate − 0,4` ohne Schrumpfung — 32/68 aus anderthalb Tagen.

### M9, M6, M10 — erledigt

- **M9** (`hl_viz.py`, Wal-Flow `pack()` und Leaderboard-Flow): `event_signal` = Rang in
  der vollständigen Wochenreihe ≥ 98 % (`hl_forecast.rang_in_reihe`, vom Nulltest geprüft;
  Vergleichsreihe ohne die laufende Stunde)
  **und** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto) **und** Breite
  (4 bzw. 3 Konten), mindestens 48 h Historie. Z-Wert bleibt für die Anzeige,
  `event_signal_z` zeigt die alte Regel zum Vergleich. **`check_m9.py --db …`** zählt die
  Feuerraten alt/neu der letzten 7 Tage auf den echten Daten — **das ist noch zu laufen**
  (hier nur mit synthetischen Ereignissen geprüft: echter Schub feuert in beiden Regeln).
- **M6** (`hl_recorder.py analyze`): `dropna` auf `fwd_4h`, Anzahl „noch ohne Ergebnis"
  wird ausgewiesen; dazu Placebo-Basisrate (4 h aufwärts/abwärts über alle Zeitpunkte)
  und Lift.
- **M10** (`load_stops`): `bucket_px()` statt `round(…, 2)` — Fusion findet jetzt zusammen.

### Weitere Statistik

- **Magnet-Statistik:** Placebo-Niveau (gleicher Abstand, andere Seite, gleicher
  Zeitpunkt), `p_placebo`, `lift`, Intervall auf n_eff = getrennte 12-h-Blöcke.
- **Analog-Suche:** `p_up` mit Intervall und unbedingter Basisrate `p_up_base`; der
  Treiber misst gegen die Basisrate statt gegen 0,5.
- **Zeitprofil:** rollierend 180 Tage.

### Nulltest und Selbsttest

`hl_forecast.py --nulltest` (Teil von `install.py --selftest`): Wilson-Überdeckung,
Quote 4 h/24 h enthält 50 %, Brier-Skill ≈ 0, Gewichte beim Prior, Magnet-Lift 1,
Rang-Signal ~2 %. Läuft in 0,3 s. Selbsttest kompiliert jetzt auch `hl_forecast.py`,
`hl_coinbase.py` und `hl_score.py`; Audit-Schritt heißt „mit Einheiten-Invarianten";
17 Schritte, alle grün.

### Konto-Score — P1, Teil 1 (`hl_score.py`, neu)

Die goldene Regel wird messbar: je Konto und Coin ein Score aus **Vorlauf** (35 %,
Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, ein Schritt je Stunde,
geschrumpft n/(n+20)), **Edge je Umsatz** (25 %, PnL/Umsatz), **Konsistenz** (20 %, vier
Leaderboard-Fenster), **Größe** (10 %) und **Klasse** (10 %); rangnormiert, täglich neu,
Schnappschuss in `forecasts.db` → `account_score` (120 Tage Vorhalt).

- **Recorder:** neue Tabelle `lb_stats` (alle vier Leaderboard-Fenster mit `pnl`, `roi`,
  `vlm` für Kandidaten **und** bekannte Wale, stündlich ersetzt). Der Umsatz wurde bisher
  beim Parsen verworfen — er ist die billigste Trennlinie zwischen Market Makern und
  Händlern.
- **Drei neue Treiber** in `compute_forecast`: `Smart-Flow 4 h` (1,0; Fluss mit Score
  gewichtet, √Notional), `Elite-Positionierung` (1,0; Netto der zehn besten Konten),
  `Gegen-Flow` (0,3; Konten mit belegt negativem Vorlauf, n ≥ 20, invertiert).
  **Gestrichen:** `Wal-Flow Hedge`, `Wal-Flow Market Maker`, `Wal-Flow gemischt`.
- **Score-Test** wöchentlich (`learned.score_test`): Spearman des Scores von vor 7 Tagen
  gegen den Vorlauf der Folgewoche, je Komponente, mit SE ≈ 1/√(n−1). Erster Wert
  frühestens sieben Tage nach dem ersten Schnappschuss. Im Selbsttest mit 16 Konten ist
  ρ ± 0,26 — Aussagekraft braucht die Hunderte Konten des Pi.
- **Elite-Liste** `learn.elite` (Top 10 nach Score, nur direktional/gemischt) — das ist
  die Vorgabe für die WebSocket-Abonnements (Konzept 2.5), noch nicht angeschlossen.
- Kachel „Konto-Score" in der Selbstoptimierung; Selbsttest-Schritt „Konto-Score
  (hl_score)" (drei synthetische Konten mit echtem Vorlauf müssen die Elite stellen).

### Dashboard

Trefferquote-Kachel: „4 h: 57 % (47–66) · Basis 51 % · n_eff 108 · Brier-Skill".
Gelernte Gewichte: n_eff, Fenster, β, λ beider Spuren. Treibertabelle: Intervall und
n_eff je Treiber. Magnet: „93 vs 90 %" (berührt vs Placebo), Lift mit Intervall.
Lernplan: Lernbeginn nach n_eff, fehlende Fenster. Browsertest Handy/Desktop ohne
JS-Fehler; `node --check` beider Skriptblöcke grün.

---

## 3b. Audit der eigenen Änderungen (Sitzung 2, auf Wunsch)

Jede Änderung wurde nachgelesen, Randfälle ausgeführt. **Gefunden und behoben:**

| Befund | Wirkung | Korrektur |
|---|---|---|
| Seiten-Invariante im Audit hätte auf dem Pi **falsch gewarnt** | `liquidations`, `lb_fills`, `trigger_orders`, `ticks` tragen absichtlich die Rohseiten `A`/`B` | Prüfung nur auf Positions-Tabellen (heatmap, whale_positions, lb_positions, lb_events, bnc_liquidations, cluster_events) |
| ms-Invariante: Nullen in `first_seen`/`last_trade` wären als „Sekunden" gemeldet worden | falscher FAIL möglich | `MIN(...) WHERE > 0` |
| `update.py` sicherte `hl_score.py` und `check_m9.py` nicht vor dem nächsten Update | Verlust bei Rücksprung | in `PROJECT_FILES` aufgenommen |
| Rang-Vergleichsreihe enthielt die **laufende Stunde** — also den Wert, der eingeordnet wird | Signal wirkt kleiner als es ist; galt auch für den alten Z-Wert | laufende Stunde aus der Reihe genommen (Wal-Flow, Leaderboard-Flow, `check_m9.py`) |
| Elite-Positionierung zählte ein Konto doppelt, wenn es Leaderboard-Konto **und** Wal ist | Netto verzerrt | Leaderboard-Stand hat Vorrang, Wal-Zeile wird übersprungen |
| n_eff = Fenster · 0,25 / h unterstellt gleichmäßige Fenster | Ereignis-Treiber (geklumpte Fenster) wurden zu optimistisch, seltene Treiber zu pessimistisch gezählt (52 Fenster in 13 Episoden: Formel 3,2, Wahrheit 13) | `n_eff_bloecke`: getrennte Horizont-Blöcke, in Kalibrierung und Trefferbilanz |
| Wilson-Intervall bei n_eff < 1 | sinnlose Klammer (0–100) | Intervall erst ab einem unabhängigen Fall |
| forecasts.db-Verbindung im Score-Abschnitt blieb bei Fehler offen | Handle-Leck | `finally: close()` |
| Unveränderte Gewichte wurden alle 15 min neu geschrieben | unnötige Schreiblast | Auffrischen höchstens stündlich |

**Geprüft und in Ordnung:** Gradienten der Kalibrierung (Logit, L2, Schrittweiten stabil);
Konsistenz von `p_up` zwischen Kalibrierung und Prognose (fehlende Treiber = 0, gleiche
Normierung); alle Zeitspalten der Binance-, Coinbase- und Timestats-Tabellen in Sekunden;
`lb_stats`-Spaltenzahl gegen INSERT; Lesezugriffe von `check_report`/`check_forecast` auf die
neue Bewertungsstruktur; JSON-Serialisierbarkeit aller gespeicherten Felder; JS-Syntax beider
Skriptblöcke; Selbsttest 17/17, Nulltest, Positivkontrollen (echter Treiber wird gelernt,
Rauschen nicht; Elite aus Konten mit echtem Vorlauf).

## 3c. Externer Re-Audit (Kimi K3, gleicher Tag) — abgearbeitet

Der Re-Audit bestätigte die Statistik-Umbauten numerisch (Lernkurven, Nulltest, Invarianten)
und fand einen MEDIUM-Befund plus 14 LOW; alle am Code nachgestellt, dann korrigiert:

| Befund | Korrektur |
|---|---|
| **N1 24-h-Spur lernt nie** (MAX_TRAIN 4000 < 50 Blöcke; dazu 60-Tage-Vorhalt) | Schwelle je Horizont {4: 50, 24: 30}, ein Fenster je Stunde, `gelernt` nur bei aktiven Treibern. Gegenprobe: ab 40 Tagen lernt die Spur (Wale 1,20 → 1,26 bei 60 T) |
| H2-Rest: drei unmaskierte Namen (`innerHTML`) | `esc()` für Name, `market`, `dir` in beiden Fill-Tabellen und der Wal-Tabelle |
| N2 `schreibe()` blockierte mit `time.sleep` die Ereignisschleife | `async`, `asyncio.sleep`; bei Endfehlschlag Wert nicht als geschrieben verbuchen |
| N3 Coinbase-Kachel `toFixed` auf null | Null-Guard |
| N4 Volumenvergleich laufende gegen volle Stunden | gleitende 60 min (`flow60`) gegen den Schnitt voller Stunden |
| N5/M14 `/leaderboard`-`days` ungeklemmt, `_LB_CACHE` ohne Kappe | `_grenze(1..90)`, `_kappen(48)` |
| N6 Coinbase `busy_timeout` 60 s > Heartbeat 20 s | 5 s, sperr-tolerantes `schreibe()` mit Zähler `db_locked` |
| N7 Backoff-Reset sofort nach Connect | Reset erst nach einer stabilen Minute |
| N8 `ws_connect(timeout=20)` als Zahl | `ClientWSTimeout`, Rückfall auf Zahl bei alter aiohttp |
| N9 Minuten-Bucket aus lokaler Uhr | Nachrichtenzeit, wenn plausibel (±10 min) |
| N10/N11/N16 Vorgabe-Coins, Kommentar 2 %, tote Imports | angeglichen |
| N12 `check_m9 --days 0` | geklemmt 1..60 |
| N13 Wal/Leaderboard-Überlappung doppelt gezählt | Konto nur aus `whale_positions`, wenn dort vorhanden (nachgewiesen) |
| N14 Elite je Coin mit Fremdkonten | Elite nur aus Konten mit Schritten im Coin |
| N15 Kommentar zur Lernrate falsch | Schritt bleibt im Gewichtsraum gleich, nicht im Logit-Raum — so steht es jetzt da |
| Zeitprofil: Division durch null bei kurzer Historie (eigener Fund beim Regressionslauf) | kein Profil unter 24 gefüllten (Wochentag, Stunde)-Zellen |

**Aus der offenen Recorder-/Betriebsliste zusätzlich erledigt:** M3 (`blake2b` statt
gesalzenem `hash()` — deterministische tid über Neustarts), M4 (Fehlschlag macht die Adresse
nach fünf Minuten wieder fällig, Zähler `poll_failed`), M5 (alle Adressen mit Position),
M12 (Rückfallschwelle statt `TypeError`), M13 (Symbolauflösung bis zehn Minuten wiederholen,
dann Exit 1), M16 (Open-Interest-Abruf im Thread).

**Bewusst offen — Entscheidungen des Nutzers oder eigene Sitzung:** C4-Rest (Auth-Token
für `POST /update`, `install.py --host 0.0.0.0`, ZIP-Manifest/Signatur, sudoers statt
`sudo.txt`), M1/M2 (Positionen über Neustart, Markpreis-Touch), H5/M15 (Migration), die
~38 LOW-Befunde des Erstberichts.

## 3e. Der „Fill-Rückstand" war ein Phantom (gefunden mit Live-Probe auf dem Pi)

Seit Sitzung 1 galt: „34 von 79 Konten im Rückstand, schlechtestes 63 h", und der
Adress-Poller wurde deshalb **auf 10 % gedrosselt** zugunsten der Fill-Abholung. Die
Live-Probe (`check_fills.py`, Abschnitt 4) zeigte für die schlechtesten Konten: sofortige
Antwort, Teilseiten, und **alle gelieferten Fills lagen bei 53 Stunden** — die Konten hatten
seitdem nicht gehandelt. `lb_fills_deferred = 0`: Das Budget hat nie ein Konto vertagt.

**Ursache:** Der Abholstand wurde auf den neuesten *geholten* Fill gesetzt. Die Abholung
beginnt zehn Minuten davor, bekommt bei einem inaktiven Konto jedes Mal dieselben alten
Fills zurück, die Antwort ist nicht leer — der Stand rückte nie auf „jetzt". Ein Konto, das
aufhört zu handeln, sah für immer wie Rückstand aus.

**Korrektur (`hl_recorder.py`, Fill-Schleife):** Eine Teilseite (unter 2.000 Einträge) heißt,
die API hat alles bis jetzt geliefert → Stand = jetzt − 10 min, unabhängig davon, ob Fills
darin waren. Nur bei ausschließlich vollen Seiten reicht der Stand bis zum neuesten Fill.
Dazu: Kachel „Fill-Abholstand" zählt nur Konten der aktuellen Auswahl (10 veraltete Stände
ausgeschiedener Konten zählten mit); der Recorder räumt solche Stände nach 7 Tagen auf.

**Erwartung nach dem Einspielen:** Der Rückstand fällt binnen einer Stunde auf wenige
Konten (die mit wirklich vielen Fills), die Poller-Drossel hebt sich von selbst auf
(`poller_drossel` 0,10 → 1,0), die Heatmap-Abdeckung steigt. Das ist zugleich die Antwort
auf die Budgetfrage aus dem Konzept: Hedge- und MM-Konten erzeugen nur **9 %** aller Fills
(gemessen), nicht 70 % — „Fills nur für direktionale Konten" spart weniger als angenommen.
Die Konzept-Annahme ist damit widerlegt und in 2.4 zu korrigieren; der Poller bekommt sein
Budget durch die Cursor-Korrektur zurück, nicht durch Streichen von Fills.

**Weitere Messwerte vom Pi (13.09., 21:08–21:34):** Nulltest und Konto-Score-Selbsttest
grün; M9: Rang trifft alle drei Fälle der alten Regel und findet einen vierten (11.09.
16:00, −54 Mio aus 12 Konten), Feuerrate 2,4 %; Leaderboard-Flow dreimal am 13.09., alle
24–35 Mio.

## 3f. Prüfung des Mix-Modus (Fremdbörsen in den Statistiken)

Jede Fremdquelle einzeln verfolgt: Tabelle → Leser → Frischeprüfung → Treiber.

| Quelle | Fließt ein in | Frische | Befund |
|---|---|---|---|
| Binance Taker-Verhältnis (5 min, live) | Treiber „Taker-Flow" (Log-Mittel aller Börsen) | live, 5-min-Cache | korrekt |
| OKX Taker (5 min), Bybit / Crypto.com (Trade-Listen) | „Taker-Flow" | Mindestspanne 60 s | korrekt; Fenster uneinheitlich (5 min vs. 150/500 Trades) — Schwäche, kein Fehler |
| Binance-Liquidationen | Kapitulation | 3 Tage | korrekt (Sekunden, Seiten normalisiert); HL-eigene Liquidationen nicht enthalten (Designentscheidung) |
| Binance- und Crypto.com-Orderbuch | Wände im Pfadmodell (fusionierte Cluster) | 15-s-Cache | korrekt (M10 behoben) |
| HL-Buch (`book_summary`), HL-Funding | „Orderbuch", „Funding" | 10 / 15 min | korrekt, nur HL — Fremdfunding nur Anzeige |
| Coinbase Spot | Prämie, Spot-Taker, Spot-Buch | 30 min | korrekt |
| Binance Tages-/30-min-Kerzen | MA 200 / 50 W, Analog-Suche, Zeitprofil | — | korrekt |
| Binance-Volumen | **Magnet-Schwelle der Prognose** | — | **Fehler, behoben** (unten) |

**Der Fehler:** Die Prognose rechnet immer im Fusionsmodus; dort ist `vol_1h` die Summe
aus HL + Binance + Crypto.com. Die Schwelle „Cluster ≥ ½ Stundenvolumen" war für das
HL-Volumen gedacht — gegen das Fünf- bis Zehnfache war kein HL-Liquidationscluster je groß
genug, und die Prognose lief bei BTC/ETH ohne Magneten und Stop-Auslöser auf dem
Sigma-Pfad. Die Magnet-Statistik dagegen rechnete ihre Schwelle korrekt aus dem HL-Volumen
— Statistik und Prognose vermaßen verschiedene Populationen. **Jetzt:** HL-Cluster und
HL-Stops gegen das HL-Volumen (`vol_split.hl`), fusionierte Bücher gegen das fusionierte
Volumen. Die Kachel „Magnet-Statistik" zeigt Schwelle, HL-Stundenvolumen und größten
Cluster je Seite — damit ist sichtbar, woran ein Magnet scheitert.

**Nebenbefund (eigener Fehler):** `score_forecasts` kehrte bei fehlenden Prognosen früh
zurück, ohne die internen Zähler (darunter ein `set`) zu entfernen → `/forecast` für einen
Coin ohne gespeicherte Prognosen hätte HTTP 500 geliefert. Behoben.

## 3g. Binance-Liquidationen: 13 Tage lang null Zeilen (gefunden 14.09., 00:02)

`bnc_liquidations` war leer — seit dem ersten Start. Der Weg zur Ursache: „36 Datensätze/h"
in der Quellenzeile (= nur die 10-min-OI-Abfragen) → `--status` zeigt **Liquidationen 0**,
Stream **Events 0** → die Unit auf dem Pi schreibt gepuffert ins Journal, die Fehlermeldung
kam nie an → Stream-Probe (`hl_binance.py --probe-stream`): DNS, TCP, TLS, Handshake ok,
**0 Nachrichten**. Dann die Dokumentation: Binance hat die Futures-WebSockets am 06.03.2026
in `/public`, `/market`, `/private` aufgeteilt und die alten Basis-URLs am **23.04.2026**
abgeschaltet — der Handshake auf `wss://fstream.binance.com/ws/…` gelingt weiter, aber
`/market`-Streams (darunter `!forceOrder@arr`) liefern dort nichts mehr.

**Korrektur:** `WS = wss://fstream.binance.com/market/ws/!forceOrder@arr`. Dazu: `--status`
zeigt die Stream-Zähler, `--probe-stream` als Debug-Eintrag, Quellenzeile weist den
Liquidations-Stream getrennt aus („STREAM PRÜFEN" ab 2 h Stille), Stream-Meldungen mit
`flush`, alle Units `PYTHONUNBUFFERED=1` (wirksam nach `install.py --systemd`).

**Folgen:** Der Treiber „Kapitulation" hatte nie Daten; seine Trefferquote in allen
bisherigen Berichten war leer. Er startet jetzt bei n_eff 0 wie ein neuer Treiber. Alles,
was im Erst-Audit über bnc_liquidations gefixt wurde (C1 ms→s, C2 Seiten), war korrekt —
nur ohne Daten. Nach dem Einspielen sollten binnen Minuten Zeilen erscheinen (Binance pusht
je Symbol bis zu eine Liquidation pro Sekunde); wenn nicht: Stream-Probe erneut.

**Lehre für die Arbeitsweise:** „Dienst läuft" ist keine Aussage über Daten. Jede Quelle
braucht einen Zähler ihrer *Nutzdaten* mit Alarm bei Stille — nicht nur einen Lebenszeichen-
Stempel.

## 3h. Rundum-Funktionstest aller Quellen (`check_sources.py`)

Debug-Eintrag „★ Rundum-Funktionstest aller Quellen (langsam, ~3 min)". Ruft jede Börse
mit genau den Anfragen des Codes auf — Hyperliquid (meta, spotMeta, perpDexs, l2Book,
clearinghouseState, spotClearinghouseState, frontendOpenOrders, userFillsByTime am größten
Wal aus der Datenbank, Leaderboard mit Fensterprüfung inkl. `vlm`; WS trades/l2Book/
activeAssetCtx), Binance (ping, exchangeInfo, klines 1m/15m/1d, Spot-Tageskerzen, depth,
premiumIndex, openInterest, alle vier `/futures/data`-Verhältnisse; WS neue **und** alte
URL — die alte muss still sein), Coinbase (products, stats, book, candles; WS ticker), Bybit,
OKX (inkl. rubik und liquidation-orders), Crypto.com, Farside-ETF. Je Aufruf: Latenz, Form,
und ob die FELDER da sind, die der Code liest. Pausen zwischen Aufrufen, HL-Gewicht < 150.
Hinweise = nicht gelistete Coins oder ruhige Streams; FEHL = der Code liest etwas, das nicht
(mehr) kommt → zuerst die Doku der Börse prüfen (Umstellung?). Exit 1 bei FEHL.

**Erster vollständiger Lauf auf dem Pi (14.09., 00:24): 61 ok · 4 Hinweise · 0 FEHL.**
Hinweise = nicht gelistet: XMR (Coinbase), XMR/PAXG (OKX), ZEC/XMR (Crypto.com); Bybit
listet alle sechs. Binance-Stream auf der neuen URL 8 Nachrichten/20 s, alte URL still.
Leaderboard 45.106 Zeilen mit allen vier Fenstern und `vlm`. HL-WebSocket trades/l2Book/
activeAssetCtx liefern. Fills des Testwals: volle Seite (2.000 in 24 h) — ein Vielhandler.

**Empfehlung:** einmal je Woche laufen lassen und nach jeder Meldung einer Börse über
API-Änderungen. Das hätte die Binance-Umstellung am Tag ihrer Wirkung gezeigt.

## 3i. Reihen der Fremdbörsen (`hl_ext.py`, 14.09.) — mit Audit

Vier Bausteine, wie beauftragt: `ext_metrics` (Bybit/OKX/Crypto.com alle 5 min),
`bnc_metrics` um die Binance-Verhältnisse ergänzt, `bnc_book` (Orderbuch mit Wänden alle
5 min), `ext_liquidations` (Bybit-Stream vollständig, OKX alle 2 min), dazu `etf_flows`.
Betrieb als Zusatzaufgaben in `hl-binance` (`Live.run_ext`), eigene Verbindung mit
Schloss, Abrufe in Threads. Details, Formate, Ratenbudget: README „Reihen der Fremdbörsen".

**Vor dem Bau geprüft:** Seitenbedeutung Bybit (`S = Buy` → Long liquidiert, Doku) und
OKX (`posSide`); Listungen je Börse aus dem Rundum-Test (Bybit alle 6, OKX ohne XMR/PAXG,
Crypto.com ohne ZEC/XMR); Formate aller Antworten aus dem Rundum-Test; Ratenlimits der
öffentlichen Endpunkte.

**Audit des Ergebnisses (Randfälle gelesen, Proben gefahren) — gefunden und behoben:**

| Befund | Korrektur |
|---|---|
| Bybit-Sperre bei jedem `retCode != 0` — ein Ratenlimit hätte den Coin einen Tag gesperrt | sperren nur bei 10001 (Symbol unbekannt), sonst zählen |
| `gather` ohne `return_exceptions`: stirbt der Stream, laufen die anderen Schleifen verwaist, der Neustart verdoppelt sie | `return_exceptions=True`, Schleifen enden einzeln |
| `import websockets` außerhalb des try | im try, Stream bleibt bei fehlendem Paket aus, Rest läuft |
| Anfangsverzögerungen (bis 600 s) ohne Stop-Prüfung — der Dienst hätte beim Beenden bis zehn Minuten gehangen (Betriebsprobe) | `warten()` in 1-s-Schritten mit Stop-Prüfung; Stopp jetzt in 0,2 s |
| Stream-Puffer (< 20 Zeilen) beim Stopp verloren (Betriebsprobe) | Flush beim Verlassen |
| Ein einziges ungültiges Bybit-Thema hätte die ganze Abonnement-Anfrage abgelehnt | ein Abonnement je Thema |
| Speicher: 40 Wände × 6 Coins alle 5 min ≈ 3,5 MB/Tag | 25 Wände, Buch-Vorhalt 60 Tage |
| `bnc_stats` auf 500 Zeichen gekappt → mit den neuen Zählern abgeschnittenes JSON | 2.000 Zeichen, nur Zahlen |

**Proben:** Selbsttest `hl_ext.py` (Parser, Seiten, Duplikate, Wände, Farside, Invariante);
Integrationstest mit dokumentierten Antwortformaten gegen SQLite (106 Kennzahlen je Lauf,
Sperren wirken, zweiter Lauf ohne Duplikate, alle `ts` in Sekunden); Betriebsprobe der
asynchronen Schleifen mit gemocktem Stream und Netzfehlern (läuft weiter, stoppt sauber).
Selbsttest der Anlage 18/18. **Live-Probe auf dem Pi steht aus**: nach dem Einspielen
„Binance-Modul --status" (Zeilen je Tabelle) und den Rundum-Test (jetzt mit Bybit-Stream).

**Bewusst nicht geändert:** Die Treiber lesen weiter live. Kapitulation über drei Börsen
und einheitliche Taker-Fenster aus `ext_metrics` sind der nächste Schritt, nachdem die
Reihen ein paar Tage gefüllt sind.

## 3j. Magnet-Schwelle — Parameter offengelegt und messbar gemacht (14.09.)

**Herkunft:** „Cluster ≥ ½ Stundenvolumen, mindestens 5 Mio" stammt aus Sitzung 1 — in
`compute_forecast` und `magnet_stats` gleichermaßen, nie gemessen. Sitzung 2 hat nur die
Bezugsgröße korrigiert (HL- statt fusioniertes Volumen, 3f) und die Zahl sichtbar gemacht;
den Faktor ½ hat sie ungeprüft übernommen. Das war ein Versäumnis: Dieser Faktor
entscheidet, ob Liquidationscluster überhaupt als Ziel gelten — der Kern des Systems.

**Jetzt:** `MAGNET_VOL_ANTEIL = 0.10`, `MAGNET_MIN_USD = 5e6` (benannte Konstanten,
`magnet_schwelle()`), in Prognose und Statistik dieselbe Funktion. Bei 100 Mio/h HL-Volumen
sind das 10 Mio — die 92 Mio oben und 35 Mio unten aus der Kachel vom 14.09. qualifizieren
beide. **Gemessen statt geraten:** `magnet_stats` weist den Lift jetzt zusätzlich je
**Größenklasse** aus (5–10, 10–25, 25–50, >50 % des Stundenvolumens; alle Cluster ab
5 Mio). Die Klasse, ab der der Lift über 1 liegt, ist die richtige Schwelle — dann wird der
Faktor nachgezogen. Kachel zeigt beide Sichten.

**Text korrigiert:** „kein großes Cluster in Reichweite" stand für drei verschiedene
Fälle. Jetzt steht der Grund: Richtung neutral (|Bias| ≤ 0,12 → kein Ziel, Sigma-Band) /
kein Cluster über der Schwelle in Richtung / Ziel wird angelaufen, Berührstatistik der
Klasse fehlt noch (n < 5) / Ziel mit Statistik.

**Offen, Entscheidung des Nutzers:** Bei neutralem Bias läuft der Pfad kein Cluster an,
auch wenn 92 Mio 1,8 % entfernt liegen. Wenn Cluster unabhängig vom Richtungsdruck
anziehen sollen (das ist die Magnet-These), müsste der Pfad bei neutralem Bias das
näherliegende/größere Cluster mit der gemessenen Berührquote als Reichweite anlaufen.
Das ist eine Modelländerung, kein Fix — nicht ohne Rückfrage.

## 3k. Magnet-Varianten: ziehen Cluster bei 0,5–1 % und 1–2 % den Kurs an? (14.09.)

Nach der Literatur (Osler 2005: Kaskaden nach der Berührung; Brunnermeier/Pedersen 2005:
Anziehung vorher durch strategisches Drücken; Cho et al. 2003: Magnet-Effekt als bedingte
Wahrscheinlichkeit nach Abstand; Avellaneda/Lipkin 2003: Drift zum Niveau ∝ Exposure)
misst `hl_forecast.magnet_varianten()` je Variante (0,5–1 %, 1–2 % vom Kurs) und Horizont
(4/8/12/24 h): **Δ Berührung minus Placebo** in Prozentpunkten mit z auf n_eff (Hauptmaß;
der Lift als Quotient ist bei kleinem n nach oben verzerrt — acht Seeds Rauschen ergaben
Ø 1,15), **Anziehung** (Überschussbewegung zum Cluster nach Abzug der Marktdrift, mit t),
**näher** gegen Placebo, und **Cho 15 min** (bedingte Wahrscheinlichkeit einer Bewegung zum
Cluster im Band gegen die unbedingte). Unabhängigkeit: ein Ereignis je Niveau und 24 h,
n_eff = getrennte h-Blöcke. Nur Cluster auf der richtigen Seite (Short-Cluster oben,
Long-Cluster unten), ab 5 Mio.

**Kontrollen:** Rauschen → Δ ≈ 0, Anziehung ≈ 0, Cho = Basis (im Nulltest verankert).
Positivkontrolle (ein stehendes Cluster je Tag, Zug 0,3 %/min des Abstands) → Δ +30 bis
+78 pp mit z 3–9, Anziehung +0,6 bis +1,1 % mit t 3–6, Cho 57–60 % gegen 50 %.

**Werkzeug:** Debug-Eintrag „Magnet-Varianten" (`check_magnet.py`, alle Coins, 14 Tage
Heatmap-Vorhalt). Kachel „Magnet-Statistik" zeigt je Variante 4 h und 24 h kompakt; der
Lernzyklus rechnet täglich. **Lesart:** belegt erst, wenn Δ und Anziehung positiv sind und
z bzw. t über 2 liegen, in mehreren Horizonten, mit Cho über Basis; n_eff unter 20 ist keine
Aussage. Erst mit diesem Beleg wird der Pfad bei neutralem Bias das Cluster anlaufen (3j).

## 3l. Schreibkoordination der Dienste (14.09., nach „database is locked" im Poller)

Vier Prozesse schreiben in eine SQLite-Datei (Recorder, Binance-Dienst mit Sammler,
Coinbase, Watchdog). Nach dem Start des Sammlers meldete der Poller „database is locked"
(hl_recorder.py, whale_positions), dreimal je Stunde; der Sammler zählte 38 verworfene
Schreibversuche. Drei Maßnahmen:

1. **`isolation_level="IMMEDIATE"`** für Recorder, Binance-Dienst und Sammler (Coinbase war
   schon Autocommit): Jede Schreibtransaktion holt die Schreibsperre beim Beginn; bei
   fremder Sperre wird gewartet (`busy_timeout`), statt zu scheitern.
2. **Weniger Transaktionen im Sammler:** Bybit-Stream schreibt höchstens einmal je Minute
   (oder ab 200 Zeilen) statt alle 5 s; Meta-Stempel nur im 5-min-Kennzahlenlauf, in einer
   Transaktion. Von ~800 auf ~130 Transaktionen je Stunde.
3. **Nie scheitern, nie blockieren:** Der Sammler wiederholt bei Sperre (0,4 / 0,8 s) und
   hält Stream-Zeilen zurück (`db_retry` / `db_locked` getrennt, Quellenzeile zeigt beides);
   der Recorder hält `whale_positions`-Zeilen zurück (`whale_positions_schreiben()`, Zähler
   `whale_write_deferred`) und schreibt sie beim nächsten Aufruf mit.

**Erwartung:** „verloren" bleibt bei 0, „wiederholt" zählt gelegentlich, der Poller meldet
keine Sperrfehler mehr. Bleibt der Fehler, hält ein Prozess die Datei länger als 60 s — dann
`PRAGMA wal_checkpoint`-Takte prüfen (Recorder, TRUNCATE) und lange Lesevorgänge des
Dashboards (Magnet-Varianten, Konto-Score) auf eine eigene, kurze Verbindung legen.
**Grundsätzlich** wäre ein einzelner Schreibprozess (Queue) die saubere Lösung; das ist ein
Umbau für eine eigene Sitzung.

## 3m. Schreibkoordination, professionell (`hl_dbcoord.py`, 14.09.)

3l („warten und wiederholen") genügte nicht — der Poller meldete weiter Sperrfehler, die
Drossel stand bei 60 % ohne echten Rückstand. Recherche (SQLite-Dokumentation, Mozilla
application-services, Praxisleitfäden): WAL erlaubt viele Leser, **einen** Schreiber; SQLite
reiht wartende Schreiber **nicht fair** ein (Busy-Handler fragt in wachsenden Abständen,
wer zufällig zuerst fragt, gewinnt); `BEGIN IMMEDIATE` verhindert den Snapshot-Fehler, aber
nicht das Verhungern. Das Muster für mehrere Schreibprozesse ist **Serialisierung auf
Anwendungsebene**: eine Sperre vor dem ersten schreibenden Statement bis zum Commit.

**Umsetzung:** `hl_dbcoord.KoordinierteVerbindung` (sqlite3.Connection-Factory) hält eine
prozessübergreifende Sperre (`fcntl.flock` auf `<db>.wlock`) vom ersten schreibenden
Statement bis Commit/Rollback, im Autocommit je Statement; `PRAGMA wal_checkpoint` läuft
darunter (Race-Bedingung in SQLite < 3.51.3 bei gleichzeitigem Schreiben und Checkpoint).
Wartefrist 20 s, danach entscheidet SQLites `busy_timeout` (gezählt als „Frist"). Angebunden:
Recorder, Binance-Dienst, Sammler, Coinbase. Kennzahlen je Prozess (Transaktionen,
Wartezeit Ø/max, Haltezeit Ø/max, Fristen, Haltezeiten über 1 s) in `meta.wlock_*` und im
Netzwerkstatus („Schreibkoordination: …"). Lesende Verbindungen (Dashboard, `mode=ro`)
bleiben unberührt.

**Nachweise:** 4 Prozesse × 300 Transaktionen bei `busy_timeout` 50 ms — ohne Koordination
6 Sperrfehler, mit 0, gleiche Dauer, längstes Warten 150 ms. Recorder-artiger Schreiber
neben dem Sammler: 0 Fehler, keine Zeile verloren, Haltezeit max 9 ms. Selbsttest 19/19.

**Dazu:** Drossel des Adress-Pollers nur noch bei echtem Rückstand (≥ 5 Konten über 3 h →
60 %, ≥ 15 → 30 %; ein bis vier Konten sind Alltag). **Fills alle 15 Minuten** statt
stündlich (`lb_fills_interval = 900`, bei Rückstand 10 min); Budget je Lauf rechnet sich aus
dem Takt. Kosten: ~75 Konten × 4 Läufe × ~25 Gewicht ≈ 125/min, aus der Reserve gedeckt.

**Woran es sich zeigt:** „Schreibkoordination" im Netzwerkstatus mit Fristen 0; keine
`database is locked` mehr im Fehlerfeld; Poller ohne Drosselhinweis; Fill-Median unter
10 min. Zeigt „hält max" bei einem Prozess Sekunden, hält dieser Prozess eine Transaktion
zu lange offen — dann dort committen, nicht die Sperre lockern.

## 3n. Kurze Transaktionen und dynamischer Takt (14.09., nach den ersten Sperrkennzahlen)

Die Kennzahlen aus 3m zeigten sofort das nächste Problem: Recorder **hält** die Sperre
Ø 1,8 s (max 6,4 s, 142× über 1 s je Stunde), Binance-Dienst Ø 3,2 s (max 12,4 s). Beide
hielten Transaktionen über Netzaufrufe hinweg offen — das Anti-Muster schlechthin:

| Stelle | vorher | jetzt |
|---|---|---|
| Recorder Poll-Runde | erster Schreibzugriff öffnet, Commit erst nach `gather` aller 26 Adressen | Puffer (Wal-Positionen, abgeleitete Liquidationen, Adress-Stände), `flush_round()` schreibt am Ende in **einer** Transaktion; bei Sperre bleiben die Puffer stehen |
| Recorder Fills | Schreiben je Konto, Commit erst nach allen 75 Konten (Sperre über den ganzen Lauf) | Commit je Konto |
| Binance-Stream | Einzel-INSERT, Commit alle 25 Ereignisse/10 s → Sperre bis 10 s beim Warten auf Nachrichten | Zeilen sammeln, alle 25/10 s `executemany` + Commit in Millisekunden; Flush beim Beenden |
| Binance Open Interest | INSERT je Symbol zwischen Netzabrufen, Commit am Ende | erst alle Abrufe, dann eine Transaktion |

**Erwartung:** „hält max" bei allen Prozessen unter 100 ms, „über 1 s gehalten" bleibt bei 0.

**Dynamischer Takt** (`dyn_takt`): Fills und Leaderboard-Stände laufen nach freiem Budget
statt fester Uhr — bei ≥ 45 % freiem Gewicht ein Viertel des Basistakts (Fills alle 4 min,
Leaderboard alle 90 s), bei ≥ 30 % die Hälfte, bei ≥ 15 % drei Viertel, sonst Basistakt.
Jeder Lauf nimmt weiterhin nur die freie Reserve. Kennzahlen `fills_takt_s`, `lb_takt_s`,
`budget_frei_pct` in den Stats.

**Nächster Schritt — bedarfsgesteuerte Warteschlange (Vorschlag des Nutzers, richtig):**
Statt vier Schleifen mit eigener Uhr ein Scheduler im Recorder: jede Abfrage (Adresse,
Konto-Fills, Orders, Leaderboard) ist ein Element mit **Nutzen** = Alter des Stands ×
Wichtigkeit (Konto-Score, Positionswert, Nähe zur Liquidation) und **Kosten** = Gewicht;
ein Token-Eimer mit 1.020 Einheiten je Minute; der Scheduler nimmt fortlaufend das Element
mit dem höchsten Nutzen je Gewichtseinheit. Damit verteilt sich das Budget von selbst dorthin,
wo es am meisten Information bringt, und alles ist so aktuell, wie das Budget erlaubt.
Das ersetzt Drossel, Stufen und Takte — ein Umbau der Recorder-Schleifen, für eine eigene
Sitzung, mit der Elite-Liste (`learn.elite`) als erster Wichtigkeitsquelle und den
WebSockets für die zehn besten Konten als Echtzeit-Ergänzung ohne Gewicht.

## 3o. Fills in Echtzeit aus dem Trade-Stream, Leaderboard alle 2 min (14.09.)

Anforderung des Nutzers: Fill-Median unter 2 Minuten, kontinuierlich abfragen, minütlich
schreiben. Rechnung: 75 Konten per REST alle 2 min = ~825 Gewicht/min — nicht bezahlbar.
Der Weg ohne Gewicht: Der Recorder empfängt bereits **jeden Trade** der sechs Coins per
WebSocket mit `users = [Käufer, Verkäufer]` (Doku, 14.09. geprüft), Preis, Größe, `tid`.
Für die beobachteten Konten sind das ihre Fills, in Echtzeit.

**Umsetzung (`hl_recorder.py`):** `on_trade` puffert Trades, an denen ein Konto der aktuellen
Leaderboard-Auswahl (`fill_konten`, bei jedem Leaderboard-Zyklus aktualisiert) beteiligt ist,
als `lb_fills`-Zeile mit `dir='stream'` (Seite B/A aus der Position im `users`-Paar, `buy`
entsprechend, closedPnl/fee 0). `run_stream_fills` schreibt sie **minütlich in einer kurzen
Transaktion** (Puffer bleibt bei Sperre stehen, Flush beim Beenden). Der REST-Abgleich
(`userFillsByTime`, Takt nach freiem Budget, min. 4 min) **löscht die Stream-Zeilen des
Kontos im geholten Zeitraum** und schreibt die vollständigen Fills — die `tid` beider
Quellen muss dafür nicht übereinstimmen. Konsumenten (Konto-Score, Smart-Flow) sehen
Stream-Zeilen nur bis zum Abgleich. Grenze: Fills in Coins außerhalb der sechs Projekt-Coins
kommen weiterhin nur per REST.

**Leaderboard-Stände:** `lb_interval` 300 → 120 s (bei freiem Budget 90 s); Kosten ~75/min.

**Anzeige:** „Fills live: Trade-Stream für n Konten, m Fills in der letzten Minute" und
getrennt „REST-Abgleich der Fills: Median …, Takt … nach freiem Budget · Leaderboard-Stände
alle … s". Meta-Schlüssel `stream_fills_min`, `stream_fills_konten`, `fills_takt_s`, `lb_takt_s`.

**Orders bleiben die teure Klasse** (20 Gewicht je Konto, `frontendOpenOrders`): alle 75 Konten
alle 2 min wären 750/min. Zwei Wege, beide brauchen den Score-Kanal zum Recorder: die zehn
Elite-Konten per WebSocket `orderUpdates` (0 Gewicht, im 10-Nutzer-Limit) und der Rest im
Stufentakt — oder der bedarfsgesteuerte Scheduler aus 3n, der Orders nach Nutzen je Gewicht
einreiht. Das ist der nächste Umbau.

**Geprüft:** Trade-Handler (Konto als Käufer → B/Kauf, als Verkäufer → A/Verkauf,
Fremdkonten ignoriert), minütlicher Schreiber mit Flush beim Stopp, REST-Abgleich ersetzt
Stream-Zeilen (Nachweis mit Datei-DB), Selbsttest 19/19.

## 3p. Die 600-Sekunden-Transaktion und die letzten langen Halter (14.09., 15:00)

Die Sperrkennzahlen zeigten „binance hält max 600.001 ms" — exakt zehn Minuten. Ursache:
`run_report` im Binance-Dienst schreibt Meta-Zeilen und committete **nicht**; der Commit
stand erst am Anfang der nächsten Runde, nach `sleep(600)`. Zehn Minuten offene
Transaktion, alle zehn Minuten, seit Wochen — vor der Koordination hielt das genauso SQLites
Schreibsperre. Sehr wahrscheinlich die eigentliche Quelle der „database is locked"-Fehler
des Recorders von Anfang an. **Behoben:** Commit direkt nach dem Schreiben.

**Diagnose statt Raten:** `hl_dbcoord` merkt sich je Transaktion das eröffnende Statement
und hält die fünf längsten (ab 0,2 s) vor; der Netzwerkstatus zeigt sie: „längste: 6,3 s
‚INSERT OR REPLACE INTO heatmap …'". Damit ist jeder lange Halter benannt.

**Gestückelt (Recorder):** stündlicher Adress-Flush (bis zu 50.000 UPDATEs), Heatmap-
Schnappschuss, Leaderboard-Positionen → `stueckweise()`: 2.000 Zeilen je Transaktion,
Sperre dazwischen frei (Probe: 12.000 Zeilen in 8 Transaktionen, max 5 ms). Aufräum-
Deletes (lb_events, lb_positions, lb_fills, lb_spot) → `loesche_stueckweise()`: nach
Zeitfenstern von 6 h Datenzeit je Transaktion (funktioniert auch für WITHOUT-ROWID-
Tabellen); neuer Index `lb_events(ts)`.

**Zum Fill-Median:** Die Zeile „REST-Abgleich der Fills: Median 35 min" misst das Alter des
REST-Abholstands, nicht das Alter der Daten. Die Fills selbst kommen seit 3o aus dem
Trade-Stream in Echtzeit („Fills live"). Damit das nicht mehr missverständlich ist, zeigt die
Zeile „Fills live" jetzt zusätzlich Fills der letzten 10 Minuten und Gesamtzahl seit Start,
und der Abgleich heißt ausdrücklich „Nachtrag von closedPnl/fee/dir". Der REST-Takt folgt
weiter dem freien Budget (bei 84 % Auslastung = Basistakt 15 min); er ist kein Maß für die
Aktualität mehr.

**Erwartung nach dem Einspielen:** binance „hält max" unter 100 ms; recorder „über 1 s
gehalten" nahe 0; „Fristen überschritten" 0; keine `database is locked` mehr.

## 3q. Nachlese der Diagnose (14.09., 15:00): book_summary im WebSocket-Handler

Die neue Anzeige der längsten Transaktionen zeigte sofort den nächsten Halter: „2,985 s
‚INSERT OR REPLACE INTO book_summary'". `on_book` (WebSocket-Handler des HL-Buchs) schrieb
direkt in die Datenbank; die Transaktion blieb bis zum nächsten Commit der Poll-Runde offen.
Jetzt puffert `on_book` den jüngsten Stand je 5-s-Fenster und Coin, `flush_round` schreibt
ihn mit. Der seltene Tick-Dump bei Kaskaden committet sofort. Statement-Texte in der Anzeige
enden nicht mehr mitten im Wort („misses=miss"), sondern zeigen Aktion und Tabelle.

**Lesehinweise für die Kennzahlen:** `wlock_binance` wird nur alle 10 min geschrieben — nach
einem Neustart des Binance-Dienstes zeigt die Kachel bis dahin den alten Wert (600.001 ms).
„Fills live … seit Start" zählt seit dem Neustart des Recorders; „Stream liefert n Trades/min
mit Adressen" belegt, dass der Trade-Stream Adressen liefert — ist das > 0 und bleiben die
Fills über Stunden bei 0, ist die Zuordnung der Konten das Problem, nicht der Stream.

## 3r. Auditbericht v3 (Kimi K3, 14.09.) — Umsetzung

Alle sechs MEDIUM-Befunde am Code bestätigt und behoben, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| D1 Fill-Cursor springt nach Netzfehler hinter voller Seite auf „jetzt" | `fehler`-Flag; Teilseitenregel nur bei sauberem Ende | Logik nachvollzogen |
| D2 hl_ext `schreibe()` ohne Rollback → Transaktion + flock offen | Rollback bei **jedem** `sqlite3.Error`; Nicht-Sperrfehler zählen statt werfen | Fehlversuch → `in_transaction` False, Sperre frei |
| D3 hl_binance `puffer_schreiben()` dito | Rollback vor allem anderen, Fehler gezählt | — |
| D4 OKX-Ratenlimit sperrt Coin 24 h | sperren nur bei 51001 | 50011 → nicht gesperrt; 51001 → gesperrt |
| D5 Crypto.com leere Liste sperrt | sperren nur bei 40004/40003 | leere Liste (code 0) → nicht gesperrt |
| D6 Bybit-Puffer bei Abbruch verloren | Puffer außerhalb der Verbindung, Flush im `except`; Themen je Verbindung neu (L8) | Abbruch nach 2 Liquidationen → 2 gespeichert |

LOW umgesetzt: L1 (Sperr-Sentinel je Transaktion), L2 (Recorder: 20 Versuche Symbolauflösung,
dann Exit 1), L3 (tote `schreibe()` entfernt), L4 (leerer Stapel flusht Puffer), L5 (Coinbase
120-s-Empfangs-Timeout), L6 (CDC-Spanne vorzeichenfrei), L7 (Farside „–" übersprungen), L9
(OKX-uid in ms), L10 (Zählung unter dem Schloss), L11 (Sperrdatei nicht öffenbar → Zähler +
Meldung), L12 (`con.close()` im finally), L13/L15 (Doku), L14 (Hinweis), L16 (`--ws-sekunden`).
Offen: L17 (Lint, kosmetisch).

**Datenhaltung (S1–S8) — die eigentliche Erkenntnis des Berichts:**

| # | Umsetzung |
|---|---|
| S1 | `lb_stats_hist` (PK addr, ts): jede Stunde PnL/ROI/Umsatz je Konto, unbegrenzt; `lb_stats` bleibt der jüngste Stand |
| S2 | `lb_pos_hourly`: je volle Stunde die Positionen der Leaderboard-Konten, unbegrenzt |
| S3 | `lb_fills_daily`: vor dem Löschen je Tag/Konto/Coin Kauf-/Verkaufsnotional, n, closedPnl, Gebühren (Probe: Summen korrekt) |
| S4 | `forecast_drivers` (ts, coin, name, score) und `forecast_slim` (ts, coin, price, bias, p_4h…p_168h, p_up, p_up_24) in forecasts.db, **unbegrenzt**; Prognosezeilen mit Payload weiter 60 Tage |
| S5 | `score_forecasts` bewertet **72 h und 168 h** aus `forecast_slim` (ein Fall je Stunde, n_eff = getrennte Blöcke); Kachel zeigt sie als „unkalibriert (Drift ohne gelernte Gewichte)" |
| S6 | `book_summary` älter als 14 Tage → Minutenmittel `book_summary_1m`, täglich nach dem Backup, in 6-h-Fenstern (Probe: 14.400 Zeilen → 1.200, max 25 ms Sperre) |
| S7 | Coinbase `BARS_DAYS` 30 → 180 |
| S8 | Binance `premiumIndex` alle 5 min in `bnc_metrics` (`funding`, `basis_bps`) |

**Noch nicht:** Die Kalibrierung liest weiter die Payloads der 60-Tage-Prognosezeilen; für eine
lernende 168-h-Spur muss `calibrate_weights` auf `forecast_drivers` umgestellt werden — sinnvoll,
sobald dort einige Wochen liegen. Selbsttest 19/19, Nulltest grün.

**Indikatoren (Abschnitt 3 des Berichts):** Entscheidung mit dem Nutzer — siehe Gesprächsnotiz.
Vorschlag der Reihenfolge: N3 OI-Perzentil, N7 Crowding-Extreme, N8 ETF-Momentum, N9 Vol-Regime
(als Kontext, nicht Richtung), N1 Funding-Spread (Daten seit S8), N6 Liquidations-Imbalance
(Bybit vollständig), Varianz-Kompression aus `bars10` (Regime-Flag). Jeder mit Prior 0,3–0,5,
Nulltest-Pflicht, Killkriterium; keiner ersetzt einen bestehenden Treiber.

## 3s. Neue Indikatoren nach Auditbericht v3 — Entscheidungen des Nutzers (14.09.)

Entscheidungen: (1) N3/N7/N8/N9/N1 sofort, (2) N6 und Varianz-Kompression ebenfalls, (3) Priors
von Taker/Funding/Buch unverändert — die Kalibrierung entscheidet, (4) Horizont Stunden bis
vier Wochen.

**Neues Modul `hl_indikatoren.py`** (reine Funktionen auf der Hauptdatenbank, None bei zu
wenig Daten → Treiber erscheint nicht):

| Treiber / Flag | Quelle | Form | Prior |
|---|---|---|---|
| OI-Überhitzung | `bnc_metrics.open_interest` (sonst `ctx_bars.oi`), Perzentil 90 T | ab 90. Perzentil leichter Kontra (−0,6 × Überhitzung); zugleich Regime | 0,3 |
| Crowding-Extrem | `lb_trend` (Top-20, unbegrenzt), Perzentil 365 T | unterstes Dezil → +1, oberstes → −0,5 (asymmetrisch wie die Studie) | 0,5 |
| Crowding-Trend 7 T | dito | Δ 7 T normiert an der Verteilung solcher Änderungen, tanh | 0,4 |
| ETF-Momentum | `etf_flows` (seit 3i) | (3-T-Mittel − 10-T-Mittel) / σ, tanh; nur BTC/ETH | 0,5 |
| Vol-Spike-Reversion | `bars` (Parkinson-σ 24 h gegen 20 T) | ab 1,5× Norm gegen die 24-h-Bewegung; Verhältnis ist zugleich Band-Multiplikator 0,7–1,6 | 0,3 |
| Funding-Spread | `ctx_bars.funding` gegen `ext_metrics.funding_8h` + `bnc_metrics.funding` (seit S8) | Perzentil des Spreads 30 T, Kontra (Carry) | 0,4 |
| Liquidationsdruck (3 Börsen) | `bnc_liquidations` + `ext_liquidations` + `liquidations` | Imbalance × Intensität (2 h gegen 30-T-Perzentil); Intensität zugleich Regime | 0,5 |
| Taker-Varianz-Kompression | `bars10` (Varianz der 10-s-Salden je Stunde, 30-T-Verteilung, Tages-Cache) | **nur Regime** (unterstes Dezil → Band +20 %) | — |

**Regime** = Band-Multiplikator aus Vol-Verhältnis × (1 + 0,25·OI-Überhitzung) × (1 + 0,25·
Liquidationsintensität) × (1 + 0,2·Varianz-Kompression), gedeckelt 0,7–2,2; steht im Payload
(`regime`) und als Zeile über der Treibertabelle. Es verschiebt keine Richtung.

**Nulltest:** neue Zeile „Neue Indikatoren auf Rauschen" — alle sieben Funktionen liefern auf
synthetischem Rauschen ein Ergebnis, Scores in [−1, 1], Band nahe 1. (Ein echter Vorzeichen-
Bias-Test über viele Zeitpunkte ist mit „jetzt"-lesenden Funktionen nicht möglich; die
Kalibrierung mit Killkriterium übernimmt das im Betrieb.) Selbsttest 19/19.

**Was auf dem Pi zuerst erscheint:** Vol-Spike-Reversion und Liquidationsdruck (Daten da),
OI-Überhitzung (13 Tage Binance-OI), Crowding (lb_trend seit Sitzung 1). Funding-Spread braucht
3 Tage `ext_metrics`, ETF-Momentum 12 Tage `etf_flows` (der Farside-Import bringt die Historie
mit, also sofort). Erwartung an die Kalibrierung: nach 2–4 Wochen zeigt die Treibertabelle, wer
trägt — die Priors sind klein genug, dass ein Nichtträger nichts verdirbt.

## 3t. Auditbericht v4 (15.09.) — Umsetzung

Fix-Quote v3 laut Audit 27/27. Neue Befunde: 5 MITTEL, 10 NIEDRIG — alle umgesetzt, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| M1 `_rank` strikt „<": Plateau → Perzentil 0 → Vollsignal (Crowding +1, Funding ±1, Varianz-Band +20 %) | Midrank (Bindungen halb); konstante Reihe → None | konstant → None; Median mit Bindungen 0,46 statt 0,31 |
| M2 Liquidationsintensität gegen verdoppelte Einzelstunden (Varianz falsch) → Trigger 6 % statt 10 % | Referenz aus echten rollierenden 2-h-Summen | Nulltest |
| M3 `book_summary_verdichten` synchron auf der Ereignisschleife | `book_summary_verdichten_datei()` in `asyncio.to_thread` mit eigener koordinierter Verbindung | 1.440 Zeilen im Thread verdichtet |
| M4 `lb_fills_daily` doppelt nach Absturz; Löschung trotz Aggregationsfehler | `fills_verdichten_und_loeschen()`: je 6-h-Fenster Aggregat + Löschung in **einer** Transaktion, Rollback bei Fehler, keine Löschung ohne Aggregat | zweiter Lauf 0 Zeilen, Summe exakt; Zieltabelle fehlt → 0 gelöscht, Zeilen erhalten |
| M5 Restore startete Dienste mit kaputtem Stand | Syntaxfehler → gesicherter Stand (`_rueck`) wird zurückgespielt, dann Start | kaputtes `hl_score.py` im Backup → nach Restore wieder gültig |

LOW: L1 OI-Quellenwahl mit Frische (Binance frisch & lang genug, sonst HL), L2 Funding-Spread je
Quelle ein try, L3 ETF-Frische 4 Tage, L4 gemessene Stunde nicht in der Varianz-Referenz,
L5 Rollback in den neuen Fehlerpfaden, L6 Einfügen + Löschen je Fenster in einer Transaktion,
L7 Regime-Zeile vor der Tabelle, L8 `/restore/info` im 30-s-Antwort-Cache, L9 `n_fremd` zählt
Börsen, L10 `run_oi` fängt `sqlite3.Error`; Kommentar premiumIndex-Endpunkt. S2-Hinweis: `lb_pos_hourly`
ist der Schnappschuss des ersten Zyklus je Stunde, kein Stundenmittel. Offen bleibt L17 (Lint).

Nulltest grün, Selbsttest 19/19. Die vom Audit empfohlene Umstellung der Kalibrierung auf
`forecast_drivers` (inkl. 72/168-h-Training) steht wie geplant an, sobald 8–12 Wochen vorliegen.

## 3u. Elite-Positionierung geprüft (15.09., `check_elite.py`)

Anlass: −0,95 gegen Smart Money +0,77. Werkzeug „Elite-Positionierung prüfen" (Debug, gewählter
Coin, mit Live-Abfrage): Elite-Konten mit Score, Klassen kontoweit/im Coin, n, Vorlauf, Position
aus lb_positions und whale_positions mit Alter, Widersprüche („≠"), Live-Stand („WEICHT AB"),
Dominanz, Treiber alt/neu, Smart Money aus demselben Schnappschuss.

**Befund auf dem Pi:** Daten korrekt (alle zehn live bestätigt, ein Zeitstempel, close → flat).
Der Gegensatz ist echt: Smart Money = Top-50 nach Leaderboard-Gewinn (17 long 387 Mio); „Elite" =
fast nur Wale außerhalb des Leaderboards mit 1–7 Schritten in BTC, Score aus Größe/Klasse, nicht
aus belegtem Vorlauf; einziges belegtes Konto (n=140) hält 51 % des Bruttowerts short.

**Korrekturen:** (1) `hl_score.elite()`: Mitglied nur mit ≥ 10 Schritten im Coin und positivem
Vorlauf (`ELITE_MIN_SCHRITTE`). (2) Treiber zählt nur im Coin direktionale Konten (Leaderboard-
Gruppe; Wale ohne Eintrag nur bei Klasse 1,0). (3) Dominanz-Dämpfer clip((1−anteil)/0,5, 0,5, 1).
Erwartung: Der Treiber fehlt zunächst häufig („zu wenige direktionale Elite-Positionen") — das
ist ehrlich; er erscheint, sobald genug Konten Beleg haben. Die Elite-Liste speist auch die
WebSocket-Kandidaten (Konzept 2.5): dort gilt dieselbe Schwelle.

## 3v. Treiber-Funktionstest (`check_treiber.py`, 15.09.)

Für alle 30 Treiber und die Regime-Flags kontrollierte Szenarien mit bekanntem Ergebnis:
aufwärts (positiv, Betrag nach Formel), abwärts, Sättigung, und wo es Bedingungen gibt, gesperrt
(zu wenig Konten/Umsatz, Spanne < 60 s, Dienst aus, Plateau, veraltet). 72 Prüfungen, alle
synthetisch und in-memory; Teil des Selbsttests (jetzt 20 Schritte) und als Debug-Eintrag
„★ Treiber-Funktionstest" mit anschließender Plausibilität auf der echten Datenbank (welche
Treiber liegen an, mit welchem Score und Gewicht, warum fehlen andere).

Was der erste Lauf nebenbei klargestellt hat (keine Fehler, aber Eigenschaften, die man kennen
muss): Smart-Flow gewichtet ALLE Konten mit Score > 0 — ein schwaches Konto (0,2) zählt mit
kleinem Gewicht mit; das Kapitulationssignal wird im Lernzyklus berechnet und über `learned`
übergeben (compute_forecast rechnet es nicht selbst); Elite-Positionierung braucht drei zählbare
Positionen; ein OI-Plateau von 30 Stunden am Rekord ergibt per Midrank ü ≈ 0,77, nicht 1.

## 3w. Fund des Treiber-Tests auf dem Pi: „Direktionale Wale" war nicht je Coin (15.09.)

Die Plausibilität in `check_treiber.py --db` zeigte für BTC und ETH identische Zahlen (51 long
1.281 Mio gegen 59 short 1.451 Mio, 110 Wale). Ursache: In `load_whales` hat die Abfrage der
aktuellen Positionen keinen Coin-Filter (für die Wal-Tabelle gewollt), und die Richtungs-
Zusammenfassung `directional` wurde daraus über ALLE Coins gebildet — seit Sitzung 1. Ein Wal
mit BTC long und ETH long zählte doppelt, einer mit BTC long und ETH short fiel als „zwei
Seiten" heraus. **Korrektur:** Zusammenfassung nur aus Zeilen des Coins, Klasse je Coin über
`behavior_per_coin` (Gruppen dir und mixed zählen, hedge/mm nicht — dieselbe Konvention wie
`lb_groups(coin)` bei Smart Money). Regressionsprobe im Treiber-Test (BTC ≠ ETH). Der
Treiber „Direktionale Wale" hat damit eine neue Datenbasis; seine bisherige Trefferbilanz gehörte
zu einem anderen Signal. Dazu: `hl_viz.Handler.db` wird im Plausibilitätslauf gesetzt (keine
Thread-Fehler der Hintergrundlader mehr).

## 3x. Elite-Positionierung, zweite Prüfung (15.09., 15:18): −1,00 ist korrekt gerechnet — und ein Momentum-Proxy

Nach der Beleg-Regel (n ≥ 10, Vorlauf > 0) bestand die Elite aus zehn Walen, alle kontoweit
direktional, alle live bestätigt; acht davon short (4–48 Mio), zwei flat; größtes Konto 38 %
(kein Dämpfer). Score −1,00 ist damit richtig: acht belegte Konten, einstimmig short. Smart
Money (Top-50 nach Gewinn) zugleich +0,85.

**Zwei Erkenntnisse:** (1) Der Beleg war schwach — Vorläufe von +0,01 bis +0,24 %/4 h ohne
Signifikanzprüfung; ein Vorzeichen ist kein Beleg. Jetzt zusätzlich `ELITE_MIN_T = 1.0`
(t-Wert des 4-h-Vorlaufs). (2) **Selektionseffekt:** Der Vorlauf misst die Rendite nach den
eigenen Schritten im 28-Tage-Fenster. In einem fallenden Markt sammeln genau die Konten
positiven Vorlauf, die short waren — und die halten weiter short. Die Elite-Positionierung ist
dadurch strukturell mit dem jüngsten Trend korreliert (ein Momentum-Proxy), nicht unabhängig
davon. Kein Rechenfehler, aber die Lesart, die man kennen muss; ob sie Vorhersagewert hat,
zeigt die Kalibrierung. Werkzeug `check_elite` zeigt jetzt den t-Wert je Konto und meldet eine
leere Elite ausdrücklich.

## 3y. Elite-Kanal zum Poller (15.09., nach zwei „WEICHT AB" im Prüflauf)

`check_elite --live` fand zwei Konten, deren Datenbankstand vom Live-Stand abwich: eines hatte
vor Minuten geschlossen (Leaderboard-Schnappschuss 12 min alt, Poller sah nur die Reduktion),
eines hatte nach einem „close" einen 9-Mio-Short eröffnet, den der Poller **18 Stunden** nicht
sah — wer flat geht, fällt in die niedrigste Abfragestufe, auch ein Elite-Konto. Das ist der
Score-Kanal aus Konzept 2.4/2.5, jetzt in der einfachsten Form:

- Dashboard speichert die Elite je Coin in `forecasts.db` (`learned`, Schlüssel `elite`).
- Recorder liest alle Elite-Listen alle 5 min (`lade_elite`, read-only) und fragt diese Konten
  im **Wal-Takt** (jede Minute) ab, unabhängig vom Positionswert (`due_addresses`, Stufe A).
- Probe: flates Elite-Konto wird fällig, normales flates Konto nicht, Wal weiterhin.
- Elite-Regel jetzt mit t ≥ 1,0 (`ELITE_MIN_T`); `check_elite` zeigt t je Konto und warnt bei
  einem Schnappschuss älter als 5 min. Die „Nicht aktiv"-Zeile unter der Treibertabelle nennt
  jeden fehlenden Treiber mit Grund.

Nächste Stufe bleibt der WebSocket für die zehn besten Konten (0 Gewicht, Echtzeit).

## 3d. Debug-Konsole

Die neuen Werkzeuge stehen in der Debug-Liste des Dashboards (`debug_commands` in
`hl_viz.py`): **Fill-Abholstand** (`check_fills.py` — welche Konten hängen, Klasse, Fills je
Tag), **Ereignis-Signal M9** (`check_m9.py`), **Nulltest**, **Konto-Score-Selbsttest**. Jedes
neue Diagnosewerkzeug gehört dort eingetragen — vom Handy aus ist die Konsole der einzige
Weg, es zu starten.

## 4. Was beim ersten Start auf dem Pi zu erwarten ist

- `forecasts.db` bekommt die Tabelle `weights_h` und die Spalten `p_up`, `p_up_24`
  automatisch (`store_connect`). Der Reset-Marker von Sitzung 1 bleibt gesetzt; die
  Gewichte starten beim Prior in beiden Spuren.
- **Der Lernbeginn springt nach hinten**: Statt „läuft" steht für rund eine Woche
  „n_eff 4 h: x von 40". Das ist richtig — die bisherigen 40 Fenster waren zehn Stunden
  Daten. Die 24-h-Spur bleibt etwa 40 Tage beim Prior (dann Schwelle 30 Blöcke je Treiber).
- **Trefferquoten fallen und bekommen Klammern.** Beides ist richtig (M7 plus Intervall).
  Grün wird eine Quote erst, wenn das Intervall ganz über der Basisrate liegt.
- **Das Ereignis-Signal feuert seltener.** `check_m9.py` zeigt, wie viel seltener.
- `p_up` liegt anfangs nahe 50 %, auch bei deutlichem `bias`: Ohne gelerntes β und mit
  wenigen aktiven Treibern ist die kalibrierte Wahrscheinlichkeit bewusst zurückhaltend.
- **Konto-Score:** Beim ersten Lernlauf entsteht der erste Schnappschuss aus den letzten
  28 Tagen Ereignissen. `lb_stats` füllt sich erst mit dem nächsten Leaderboard-Abruf —
  bis dahin fehlen Edge und Konsistenz (zählen neutral 0,5), der Score lebt von Vorlauf,
  Größe und Klasse. Die Treiber Smart-Flow / Elite / Gegen-Flow erscheinen ab dem ersten
  Schnappschuss; Gegen-Flow erst, wenn Konten n ≥ 20 Schritte haben.

---

## 5. Nächste Schritte, in dieser Reihenfolge (Konzept Abschnitt 6)

1. **Auf dem Pi zuerst messen, nicht ändern:** `install.py --selftest` (Nulltest,
   Invarianten), `hl_recorder.py --db … --audit`, `check_m9.py --db …`, und die fünf
   Abfragen aus Anhang A des Konzepts (Pareto der Heatmap-Masse, Fill-Verbraucher je
   Klasse, Poll-Takte je Wertstufe, n gegen n_eff je Coin). Diese Zahlen legen die
   Stufen der Budget-Tabelle fest.
2. ~~P1 — Konto-Score~~ **erledigt** (hl_score.py). Offen daran: Vorlauf zusätzlich aus
   `lb_fills` (heute nur Positionsereignisse) und Score je Coin für ETH/HYPE prüfen, ob
   genug Schritte anfallen.
3. **P1 — Budget nach Score** (Recorder): Fills nur direktional/gemischt, Orders nur
   S1/S2, Stufen S1–S5, Sichtung nach Handelsgröße, **WebSocket-Abonnements für
   `learn.elite`** (`userFills` + `userEvents`, REST alle 5 min als Lückenfüller). Braucht
   einen Kanal Dashboard → Recorder für Klasse und Score (Vorschlag: Tabelle
   `account_class` in der Hauptdatenbank, vom Dashboard täglich geschrieben).
4. ~~P1 — Smart-Flow, Elite-Positionierung, Gegen-Flow~~ **erledigt**; Killkriterium
   (Konzept 3.4: Intervall enthält 50 % und Gewicht < 0,3 × Prior bei n_eff ≥ 50 → parken)
   noch offen — braucht erst n_eff 50.
5. **P2 — M1–M3** (Liquidationsableitung), Treiber-Familien, Live-Abrufe Bybit/OKX/
   Crypto.com in den Binance-Dienst, Leaderboard als Wal-Liste.
6. **P3 — Konfluenz zeigt Prognose-Beiträge; M4, M5, M12, M13, M15, M16; Git auf dem Pi.**

---

## 6. Offene Befunde aus dem Audit (unverändert seit Sitzung 1)

**Datenqualität:** M1 (Positionen über Neustart), M2 (Markpreis statt Handelspreis).
~~M3, M4, M5~~ erledigt (3c). **Betrieb:** M15 (Migration der Nebendateien); ~~M12, M13,
M16~~ erledigt (3c).
**Sicherheit, bewusst offen:** Dashboard lauscht auf allen Adressen — Entscheidung des
Nutzers.

---

## 7. Arbeitsweise, die sich bewährt hat

- **Prüfen statt behaupten.** Auch das eigene Konzept: Zwei Annahmen darin waren falsch
  (Analog-Suche läuft bereits stündlich; ihre Merkmale sind fest standardisiert) und
  sind im Konzept korrigiert.
- **Nulltest vor Vertrauen.** Er hat in dieser Sitzung zwei Fehler in frisch
  geschriebenem Code gezeigt, bevor sie ausgeliefert wurden.
- **Nach jeder Änderung:** `python -m compileall`, `node --check` der ausgelieferten
  Seite, Browsertest Handy und Desktop, alle Endpunkte, `install.py --selftest`.
- **Beim Löschen von Codeblöcken vorsichtig schneiden**; Patches mit `assert count == 1`.
- **Ein Server je Port.** „Port bereits belegt" liefert stillschweigend die alte
  Fassung aus — beim Testen immer auf einen frischen Port.
- **Tests, die Fehler festschreiben, sind gefährlicher als fehlende Tests.** Deshalb
  kommt das Soll des Nulltests aus der Mathematik.
