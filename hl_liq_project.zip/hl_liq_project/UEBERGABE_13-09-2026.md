# Übergabe — Hyperliquid-Analysesystem (Änderungsprotokoll seit 13.09.2026; erstellt mit Claude Fable 5.1 bis 23.09.2026, fortgeführt mit Opus 5.5 — Einstieg: PROJEKTUEBERGABE_OPUS55_23-09-2026.md)

Für die nächste Sitzung. Die erste Übergabe vom 13.09. (Sitzung 1, Opus) ist hier
eingearbeitet; das Änderungskonzept liegt als `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
bei und ist die Landkarte für alles Weitere. Code im Archiv `hl_liq_project.zip`.

---

## 1. Was das System ist

Trading-Analysesystem für Hyperliquid auf einem Raspberry Pi 5. Es sagt **nicht**
Kurse voraus, sondern misst, wo gehebelte Positionen liquidiert würden, wer sie hält
und wie sich das verändert — daraus entsteht eine Prognose mit selbstkalibrierenden
Gewichten.

**Fünf Dienste**, alle in dieselbe SQLite-Datei schreibend:

| Dienst | Aufgabe |
|---|---|
| `hl-recorder` | Kern: Adress-Poller, Wal-Verfolgung, Leaderboard, Fills, Snapshots, Backup |
| `hl-dashboard` | `hl_viz.py`, Port 8765, Oberfläche, Prognose und Lernzyklus |
| `hl-binance` | Liquidationen, Kennzahlen, Tageskerzen |
| `hl-coinbase` | Spot: Prämie, Taker-Flow, Orderbuch |
| `hl-watchdog` | Überwachung, Benachrichtigung |

**Datenbank:** `/media/seed/marketdatabase/hl_liq/hl_liq.db` (~3,9 GB, USB-Stick).
`forecasts.db` und `sys_history.json` liegen daneben.

**Coins:** BTC, ETH, HYPE, ZEC, XMR, PAXG — die Liste steht **einmal** in
`install.py` als `COINS`.

---

## 2. Eiserne Regeln dieses Projekts

**Zeitstempel sind SEKUNDEN.** Ausnahmen: `addresses.last_trade` und `first_seen` in
Millisekunden (bewusst). Erkennungsgrenze ms gegen s ist **1e11**. **Neu:** Der
Datenbank-Audit (`hl_recorder.py --audit`, Teil des Selbsttests) prüft das als Invariante
über alle Tabellen — eine Millisekunden-Zeile ergibt FEHLT und Exit 1.

**Seiten sind normalisiert.** `side` steht als `"long"`/`"short"` in der Datenbank und
wird beim Lesen **nicht** neu abgeleitet. Der Audit meldet Fremdwerte.

**Maker gegen Taker.** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`hl_coinbase.py --selftest` prüft das als erste Zeile.

**Das IP-Limit ist nicht erhöhbar.** 1.200 Gewicht je Minute und IP. `clearinghouseState`
2, übrige Info-Abfragen 20, `userFillsByTime` plus 1 je 20 Einträge. **WebSocket:**
höchstens **10 verschiedene Nutzer** über nutzerbezogene Abonnements (Doku, 13.09.
geprüft) — das ist die Vorgabe für die Elite-Liste im Konzept, kein Hindernis.

**Stichproben sind n_eff, nicht Fenster.** Alle 15 min eine Prognose, Bewertung nach
h Stunden: n_eff = Zahl getrennter h-Stunden-Blöcke (≈ Fenster / 16 bei 4 h; bei
geklumpten Ereignis-Treibern die Zahl der Episoden — `n_eff_bloecke`). Jede Quote im System trägt ein Wilson-Intervall
auf n_eff und steht neben ihrer Basisrate. Eine Zahl ohne Intervall ist keine Aussage.

**Prüfen statt behaupten.** Jeder Befund wird vor der Korrektur nachgestellt. In dieser
Sitzung: alle Konzeptbefunde am Code bestätigt, zwei eigene Fehler durch den Nulltest
gefunden (Lernrate nach Umnormierung, Magnet-Intervall zu eng).

---

## 3. In Sitzung 2 erledigt

### Kalibrierung (`hl_forecast.calibrate_weights`)

- **Befund bestätigt:** `lam = 4.0 / max(n, 1)` mit überlappenden Fenstern. Bei 2.000
  Fenstern λ = 0,002 → Prior praktisch abgeschafft; auf reinem Rauschen wanderten
  Gewichte um bis zu 0,12 (gemessen, drei Seeds).
- **Neu:** λ = 4 / n_eff (n_eff = getrennte Horizont-Blöcke, `n_eff_bloecke`); Lernstart ab
  n_eff 40 je Horizont (4 h: rund eine Woche; 24 h: rund 40 Tage); ein Treiber verlässt
  seinen Prior erst ab eigenen unabhängigen Fällen — **je Horizont gestaffelt**
  (`MIN_N_EFF_TREIBER = {4: 50, 24: 30}`, Re-Audit N1: `forecasts.db` behält 60 Tage, die
  24-h-Spur sieht also nie mehr als ~60 Blöcke). Die 24-h-Spur trainiert mit **einem
  Fenster je Stunde** (`TRAIN_STRIDE`), 60 Tage = 1.440 Fenster, Laufzeit ~1 s auf dem Pi.
- **Zwei Spuren:** 4 h (Hauptspur, alle 15 min, `weights_h` h=4, Spiegel in `weights`)
  und 24 h (stündlich, `weights_h` h=24). `compute_forecast` nutzt die 4-h-Gewichte für
  `bias` und den Pfad bis 24 h, die 24-h-Gewichte (`bias_24`) für die Drift danach.
- **β, gelernter Maßstab:** P(auf) = sigmoid(β · Σ wᵢxᵢ / Σ Priors). Gespeichert als
  `p_up` / `p_up_24` je Prognose (neue Spalten). Vor dem Lernen β = 1 → p_up ist dann
  eine Vorgabe. Meta (n, n_eff, λ, β) in `learned.cal_4` / `cal_24`.
- **Gegenprobe:** Ein Treiber mit echten 65 % (4 h) wird gelernt: 1,20 → 1,27 nach 14
  Tagen, 1,29 nach 28; β steigt auf 1,09. Rauschen bewegt nichts mehr (≤ 0,01).
- Laufzeit `forecast_learn` mit 1.900 Fenstern: 1,1 s hier, Pi etwa 4 s.

### Trefferbilanz (`score_forecasts`)

Eine Prognose je 15-min-Fenster (Sofortprognosen zählen nicht doppelt), Blöcke `q4` und
`q24` mit n, n_eff, Wilson-Intervall, Basisrate („immer aufwärts" in denselben Fenstern),
Brier-Score und Brier-Skill. Alte Felder (`n`, `hit_rate`, `hit_rate_4h`, `model`,
`analog`, `oos`, `mae_pct`) bleiben für `check_report.py`. Die `wver`-Trennung heißt jetzt
„Seit Gewichtsversion" — alle gespeicherten Prognosen sind ohnehin walk-forward.

### Ensemble

Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Pseudo-Priors 0,56/0,54 = alte
Mischung 60/40, Nullpunkt 0,5), gedeckelt 30–70 % bis n_eff 50 je Modell. Vorher:
`hit_rate − 0,4` ohne Schrumpfung — 32/68 aus anderthalb Tagen.

### M9, M6, M10 — erledigt

- **M9** (`hl_viz.py`, Wal-Flow `pack()` und Leaderboard-Flow): `event_signal` = Rang in
  der vollständigen Wochenreihe ≥ 98 % (`hl_forecast.rang_in_reihe`, vom Nulltest geprüft;
  Vergleichsreihe ohne die laufende Stunde)
  **und** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto) **und** Breite
  (4 bzw. 3 Konten), mindestens 48 h Historie. Z-Wert bleibt für die Anzeige,
  `event_signal_z` zeigt die alte Regel zum Vergleich. **`check_m9.py --db …`** zählt die
  Feuerraten alt/neu der letzten 7 Tage auf den echten Daten — **das ist noch zu laufen**
  (hier nur mit synthetischen Ereignissen geprüft: echter Schub feuert in beiden Regeln).
- **M6** (`hl_recorder.py analyze`): `dropna` auf `fwd_4h`, Anzahl „noch ohne Ergebnis"
  wird ausgewiesen; dazu Placebo-Basisrate (4 h aufwärts/abwärts über alle Zeitpunkte)
  und Lift.
- **M10** (`load_stops`): `bucket_px()` statt `round(…, 2)` — Fusion findet jetzt zusammen.

### Weitere Statistik

- **Magnet-Statistik:** Placebo-Niveau (gleicher Abstand, andere Seite, gleicher
  Zeitpunkt), `p_placebo`, `lift`, Intervall auf n_eff = getrennte 12-h-Blöcke.
- **Analog-Suche:** `p_up` mit Intervall und unbedingter Basisrate `p_up_base`; der
  Treiber misst gegen die Basisrate statt gegen 0,5.
- **Zeitprofil:** rollierend 180 Tage.

### Nulltest und Selbsttest

`hl_forecast.py --nulltest` (Teil von `install.py --selftest`): Wilson-Überdeckung,
Quote 4 h/24 h enthält 50 %, Brier-Skill ≈ 0, Gewichte beim Prior, Magnet-Lift 1,
Rang-Signal ~2 %. Läuft in 0,3 s. Selbsttest kompiliert jetzt auch `hl_forecast.py`,
`hl_coinbase.py` und `hl_score.py`; Audit-Schritt heißt „mit Einheiten-Invarianten";
17 Schritte, alle grün.

### Konto-Score — P1, Teil 1 (`hl_score.py`, neu)

Die goldene Regel wird messbar: je Konto und Coin ein Score aus **Vorlauf** (35 %,
Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, ein Schritt je Stunde,
geschrumpft n/(n+20)), **Edge je Umsatz** (25 %, PnL/Umsatz), **Konsistenz** (20 %, vier
Leaderboard-Fenster), **Größe** (10 %) und **Klasse** (10 %); rangnormiert, täglich neu,
Schnappschuss in `forecasts.db` → `account_score` (120 Tage Vorhalt).

- **Recorder:** neue Tabelle `lb_stats` (alle vier Leaderboard-Fenster mit `pnl`, `roi`,
  `vlm` für Kandidaten **und** bekannte Wale, stündlich ersetzt). Der Umsatz wurde bisher
  beim Parsen verworfen — er ist die billigste Trennlinie zwischen Market Makern und
  Händlern.
- **Drei neue Treiber** in `compute_forecast`: `Smart-Flow 4 h` (1,0; Fluss mit Score
  gewichtet, √Notional), `Elite-Positionierung` (1,0; Netto der zehn besten Konten),
  `Gegen-Flow` (0,3; Konten mit belegt negativem Vorlauf, n ≥ 20, invertiert).
  **Gestrichen:** `Wal-Flow Hedge`, `Wal-Flow Market Maker`, `Wal-Flow gemischt`.
- **Score-Test** wöchentlich (`learned.score_test`): Spearman des Scores von vor 7 Tagen
  gegen den Vorlauf der Folgewoche, je Komponente, mit SE ≈ 1/√(n−1). Erster Wert
  frühestens sieben Tage nach dem ersten Schnappschuss. Im Selbsttest mit 16 Konten ist
  ρ ± 0,26 — Aussagekraft braucht die Hunderte Konten des Pi.
- **Elite-Liste** `learn.elite` (Top 10 nach Score, nur direktional/gemischt) — das ist
  die Vorgabe für die WebSocket-Abonnements (Konzept 2.5), noch nicht angeschlossen.
- Kachel „Konto-Score" in der Selbstoptimierung; Selbsttest-Schritt „Konto-Score
  (hl_score)" (drei synthetische Konten mit echtem Vorlauf müssen die Elite stellen).

### Dashboard

Trefferquote-Kachel: „4 h: 57 % (47–66) · Basis 51 % · n_eff 108 · Brier-Skill".
Gelernte Gewichte: n_eff, Fenster, β, λ beider Spuren. Treibertabelle: Intervall und
n_eff je Treiber. Magnet: „93 vs 90 %" (berührt vs Placebo), Lift mit Intervall.
Lernplan: Lernbeginn nach n_eff, fehlende Fenster. Browsertest Handy/Desktop ohne
JS-Fehler; `node --check` beider Skriptblöcke grün.

---

## 3b. Audit der eigenen Änderungen (Sitzung 2, auf Wunsch)

Jede Änderung wurde nachgelesen, Randfälle ausgeführt. **Gefunden und behoben:**

| Befund | Wirkung | Korrektur |
|---|---|---|
| Seiten-Invariante im Audit hätte auf dem Pi **falsch gewarnt** | `liquidations`, `lb_fills`, `trigger_orders`, `ticks` tragen absichtlich die Rohseiten `A`/`B` | Prüfung nur auf Positions-Tabellen (heatmap, whale_positions, lb_positions, lb_events, bnc_liquidations, cluster_events) |
| ms-Invariante: Nullen in `first_seen`/`last_trade` wären als „Sekunden" gemeldet worden | falscher FAIL möglich | `MIN(...) WHERE > 0` |
| `update.py` sicherte `hl_score.py` und `check_m9.py` nicht vor dem nächsten Update | Verlust bei Rücksprung | in `PROJECT_FILES` aufgenommen |
| Rang-Vergleichsreihe enthielt die **laufende Stunde** — also den Wert, der eingeordnet wird | Signal wirkt kleiner als es ist; galt auch für den alten Z-Wert | laufende Stunde aus der Reihe genommen (Wal-Flow, Leaderboard-Flow, `check_m9.py`) |
| Elite-Positionierung zählte ein Konto doppelt, wenn es Leaderboard-Konto **und** Wal ist | Netto verzerrt | Leaderboard-Stand hat Vorrang, Wal-Zeile wird übersprungen |
| n_eff = Fenster · 0,25 / h unterstellt gleichmäßige Fenster | Ereignis-Treiber (geklumpte Fenster) wurden zu optimistisch, seltene Treiber zu pessimistisch gezählt (52 Fenster in 13 Episoden: Formel 3,2, Wahrheit 13) | `n_eff_bloecke`: getrennte Horizont-Blöcke, in Kalibrierung und Trefferbilanz |
| Wilson-Intervall bei n_eff < 1 | sinnlose Klammer (0–100) | Intervall erst ab einem unabhängigen Fall |
| forecasts.db-Verbindung im Score-Abschnitt blieb bei Fehler offen | Handle-Leck | `finally: close()` |
| Unveränderte Gewichte wurden alle 15 min neu geschrieben | unnötige Schreiblast | Auffrischen höchstens stündlich |

**Geprüft und in Ordnung:** Gradienten der Kalibrierung (Logit, L2, Schrittweiten stabil);
Konsistenz von `p_up` zwischen Kalibrierung und Prognose (fehlende Treiber = 0, gleiche
Normierung); alle Zeitspalten der Binance-, Coinbase- und Timestats-Tabellen in Sekunden;
`lb_stats`-Spaltenzahl gegen INSERT; Lesezugriffe von `check_report`/`check_forecast` auf die
neue Bewertungsstruktur; JSON-Serialisierbarkeit aller gespeicherten Felder; JS-Syntax beider
Skriptblöcke; Selbsttest 17/17, Nulltest, Positivkontrollen (echter Treiber wird gelernt,
Rauschen nicht; Elite aus Konten mit echtem Vorlauf).

## 3c. Externer Re-Audit (Kimi K3, gleicher Tag) — abgearbeitet

Der Re-Audit bestätigte die Statistik-Umbauten numerisch (Lernkurven, Nulltest, Invarianten)
und fand einen MEDIUM-Befund plus 14 LOW; alle am Code nachgestellt, dann korrigiert:

| Befund | Korrektur |
|---|---|
| **N1 24-h-Spur lernt nie** (MAX_TRAIN 4000 < 50 Blöcke; dazu 60-Tage-Vorhalt) | Schwelle je Horizont {4: 50, 24: 30}, ein Fenster je Stunde, `gelernt` nur bei aktiven Treibern. Gegenprobe: ab 40 Tagen lernt die Spur (Wale 1,20 → 1,26 bei 60 T) |
| H2-Rest: drei unmaskierte Namen (`innerHTML`) | `esc()` für Name, `market`, `dir` in beiden Fill-Tabellen und der Wal-Tabelle |
| N2 `schreibe()` blockierte mit `time.sleep` die Ereignisschleife | `async`, `asyncio.sleep`; bei Endfehlschlag Wert nicht als geschrieben verbuchen |
| N3 Coinbase-Kachel `toFixed` auf null | Null-Guard |
| N4 Volumenvergleich laufende gegen volle Stunden | gleitende 60 min (`flow60`) gegen den Schnitt voller Stunden |
| N5/M14 `/leaderboard`-`days` ungeklemmt, `_LB_CACHE` ohne Kappe | `_grenze(1..90)`, `_kappen(48)` |
| N6 Coinbase `busy_timeout` 60 s > Heartbeat 20 s | 5 s, sperr-tolerantes `schreibe()` mit Zähler `db_locked` |
| N7 Backoff-Reset sofort nach Connect | Reset erst nach einer stabilen Minute |
| N8 `ws_connect(timeout=20)` als Zahl | `ClientWSTimeout`, Rückfall auf Zahl bei alter aiohttp |
| N9 Minuten-Bucket aus lokaler Uhr | Nachrichtenzeit, wenn plausibel (±10 min) |
| N10/N11/N16 Vorgabe-Coins, Kommentar 2 %, tote Imports | angeglichen |
| N12 `check_m9 --days 0` | geklemmt 1..60 |
| N13 Wal/Leaderboard-Überlappung doppelt gezählt | Konto nur aus `whale_positions`, wenn dort vorhanden (nachgewiesen) |
| N14 Elite je Coin mit Fremdkonten | Elite nur aus Konten mit Schritten im Coin |
| N15 Kommentar zur Lernrate falsch | Schritt bleibt im Gewichtsraum gleich, nicht im Logit-Raum — so steht es jetzt da |
| Zeitprofil: Division durch null bei kurzer Historie (eigener Fund beim Regressionslauf) | kein Profil unter 24 gefüllten (Wochentag, Stunde)-Zellen |

**Aus der offenen Recorder-/Betriebsliste zusätzlich erledigt:** M3 (`blake2b` statt
gesalzenem `hash()` — deterministische tid über Neustarts), M4 (Fehlschlag macht die Adresse
nach fünf Minuten wieder fällig, Zähler `poll_failed`), M5 (alle Adressen mit Position),
M12 (Rückfallschwelle statt `TypeError`), M13 (Symbolauflösung bis zehn Minuten wiederholen,
dann Exit 1), M16 (Open-Interest-Abruf im Thread).

**Bewusst offen — Entscheidungen des Nutzers oder eigene Sitzung:** C4-Rest (Auth-Token
für `POST /update`, `install.py --host 0.0.0.0`, ZIP-Manifest/Signatur, sudoers statt
`sudo.txt`), M1/M2 (Positionen über Neustart, Markpreis-Touch), H5/M15 (Migration), die
~38 LOW-Befunde des Erstberichts.

## 3e. Der „Fill-Rückstand" war ein Phantom (gefunden mit Live-Probe auf dem Pi)

Seit Sitzung 1 galt: „34 von 79 Konten im Rückstand, schlechtestes 63 h", und der
Adress-Poller wurde deshalb **auf 10 % gedrosselt** zugunsten der Fill-Abholung. Die
Live-Probe (`check_fills.py`, Abschnitt 4) zeigte für die schlechtesten Konten: sofortige
Antwort, Teilseiten, und **alle gelieferten Fills lagen bei 53 Stunden** — die Konten hatten
seitdem nicht gehandelt. `lb_fills_deferred = 0`: Das Budget hat nie ein Konto vertagt.

**Ursache:** Der Abholstand wurde auf den neuesten *geholten* Fill gesetzt. Die Abholung
beginnt zehn Minuten davor, bekommt bei einem inaktiven Konto jedes Mal dieselben alten
Fills zurück, die Antwort ist nicht leer — der Stand rückte nie auf „jetzt". Ein Konto, das
aufhört zu handeln, sah für immer wie Rückstand aus.

**Korrektur (`hl_recorder.py`, Fill-Schleife):** Eine Teilseite (unter 2.000 Einträge) heißt,
die API hat alles bis jetzt geliefert → Stand = jetzt − 10 min, unabhängig davon, ob Fills
darin waren. Nur bei ausschließlich vollen Seiten reicht der Stand bis zum neuesten Fill.
Dazu: Kachel „Fill-Abholstand" zählt nur Konten der aktuellen Auswahl (10 veraltete Stände
ausgeschiedener Konten zählten mit); der Recorder räumt solche Stände nach 7 Tagen auf.

**Erwartung nach dem Einspielen:** Der Rückstand fällt binnen einer Stunde auf wenige
Konten (die mit wirklich vielen Fills), die Poller-Drossel hebt sich von selbst auf
(`poller_drossel` 0,10 → 1,0), die Heatmap-Abdeckung steigt. Das ist zugleich die Antwort
auf die Budgetfrage aus dem Konzept: Hedge- und MM-Konten erzeugen nur **9 %** aller Fills
(gemessen), nicht 70 % — „Fills nur für direktionale Konten" spart weniger als angenommen.
Die Konzept-Annahme ist damit widerlegt und in 2.4 zu korrigieren; der Poller bekommt sein
Budget durch die Cursor-Korrektur zurück, nicht durch Streichen von Fills.

**Weitere Messwerte vom Pi (13.09., 21:08–21:34):** Nulltest und Konto-Score-Selbsttest
grün; M9: Rang trifft alle drei Fälle der alten Regel und findet einen vierten (11.09.
16:00, −54 Mio aus 12 Konten), Feuerrate 2,4 %; Leaderboard-Flow dreimal am 13.09., alle
24–35 Mio.

## 3f. Prüfung des Mix-Modus (Fremdbörsen in den Statistiken)

Jede Fremdquelle einzeln verfolgt: Tabelle → Leser → Frischeprüfung → Treiber.

| Quelle | Fließt ein in | Frische | Befund |
|---|---|---|---|
| Binance Taker-Verhältnis (5 min, live) | Treiber „Taker-Flow" (Log-Mittel aller Börsen) | live, 5-min-Cache | korrekt |
| OKX Taker (5 min), Bybit / Crypto.com (Trade-Listen) | „Taker-Flow" | Mindestspanne 60 s | korrekt; Fenster uneinheitlich (5 min vs. 150/500 Trades) — Schwäche, kein Fehler |
| Binance-Liquidationen | Kapitulation | 3 Tage | korrekt (Sekunden, Seiten normalisiert); HL-eigene Liquidationen nicht enthalten (Designentscheidung) |
| Binance- und Crypto.com-Orderbuch | Wände im Pfadmodell (fusionierte Cluster) | 15-s-Cache | korrekt (M10 behoben) |
| HL-Buch (`book_summary`), HL-Funding | „Orderbuch", „Funding" | 10 / 15 min | korrekt, nur HL — Fremdfunding nur Anzeige |
| Coinbase Spot | Prämie, Spot-Taker, Spot-Buch | 30 min | korrekt |
| Binance Tages-/30-min-Kerzen | MA 200 / 50 W, Analog-Suche, Zeitprofil | — | korrekt |
| Binance-Volumen | **Magnet-Schwelle der Prognose** | — | **Fehler, behoben** (unten) |

**Der Fehler:** Die Prognose rechnet immer im Fusionsmodus; dort ist `vol_1h` die Summe
aus HL + Binance + Crypto.com. Die Schwelle „Cluster ≥ ½ Stundenvolumen" war für das
HL-Volumen gedacht — gegen das Fünf- bis Zehnfache war kein HL-Liquidationscluster je groß
genug, und die Prognose lief bei BTC/ETH ohne Magneten und Stop-Auslöser auf dem
Sigma-Pfad. Die Magnet-Statistik dagegen rechnete ihre Schwelle korrekt aus dem HL-Volumen
— Statistik und Prognose vermaßen verschiedene Populationen. **Jetzt:** HL-Cluster und
HL-Stops gegen das HL-Volumen (`vol_split.hl`), fusionierte Bücher gegen das fusionierte
Volumen. Die Kachel „Magnet-Statistik" zeigt Schwelle, HL-Stundenvolumen und größten
Cluster je Seite — damit ist sichtbar, woran ein Magnet scheitert.

**Nebenbefund (eigener Fehler):** `score_forecasts` kehrte bei fehlenden Prognosen früh
zurück, ohne die internen Zähler (darunter ein `set`) zu entfernen → `/forecast` für einen
Coin ohne gespeicherte Prognosen hätte HTTP 500 geliefert. Behoben.

## 3g. Binance-Liquidationen: 13 Tage lang null Zeilen (gefunden 14.09., 00:02)

`bnc_liquidations` war leer — seit dem ersten Start. Der Weg zur Ursache: „36 Datensätze/h"
in der Quellenzeile (= nur die 10-min-OI-Abfragen) → `--status` zeigt **Liquidationen 0**,
Stream **Events 0** → die Unit auf dem Pi schreibt gepuffert ins Journal, die Fehlermeldung
kam nie an → Stream-Probe (`hl_binance.py --probe-stream`): DNS, TCP, TLS, Handshake ok,
**0 Nachrichten**. Dann die Dokumentation: Binance hat die Futures-WebSockets am 06.03.2026
in `/public`, `/market`, `/private` aufgeteilt und die alten Basis-URLs am **23.04.2026**
abgeschaltet — der Handshake auf `wss://fstream.binance.com/ws/…` gelingt weiter, aber
`/market`-Streams (darunter `!forceOrder@arr`) liefern dort nichts mehr.

**Korrektur:** `WS = wss://fstream.binance.com/market/ws/!forceOrder@arr`. Dazu: `--status`
zeigt die Stream-Zähler, `--probe-stream` als Debug-Eintrag, Quellenzeile weist den
Liquidations-Stream getrennt aus („STREAM PRÜFEN" ab 2 h Stille), Stream-Meldungen mit
`flush`, alle Units `PYTHONUNBUFFERED=1` (wirksam nach `install.py --systemd`).

**Folgen:** Der Treiber „Kapitulation" hatte nie Daten; seine Trefferquote in allen
bisherigen Berichten war leer. Er startet jetzt bei n_eff 0 wie ein neuer Treiber. Alles,
was im Erst-Audit über bnc_liquidations gefixt wurde (C1 ms→s, C2 Seiten), war korrekt —
nur ohne Daten. Nach dem Einspielen sollten binnen Minuten Zeilen erscheinen (Binance pusht
je Symbol bis zu eine Liquidation pro Sekunde); wenn nicht: Stream-Probe erneut.

**Lehre für die Arbeitsweise:** „Dienst läuft" ist keine Aussage über Daten. Jede Quelle
braucht einen Zähler ihrer *Nutzdaten* mit Alarm bei Stille — nicht nur einen Lebenszeichen-
Stempel.

## 3h. Rundum-Funktionstest aller Quellen (`check_sources.py`)

Debug-Eintrag „★ Rundum-Funktionstest aller Quellen (langsam, ~3 min)". Ruft jede Börse
mit genau den Anfragen des Codes auf — Hyperliquid (meta, spotMeta, perpDexs, l2Book,
clearinghouseState, spotClearinghouseState, frontendOpenOrders, userFillsByTime am größten
Wal aus der Datenbank, Leaderboard mit Fensterprüfung inkl. `vlm`; WS trades/l2Book/
activeAssetCtx), Binance (ping, exchangeInfo, klines 1m/15m/1d, Spot-Tageskerzen, depth,
premiumIndex, openInterest, alle vier `/futures/data`-Verhältnisse; WS neue **und** alte
URL — die alte muss still sein), Coinbase (products, stats, book, candles; WS ticker), Bybit,
OKX (inkl. rubik und liquidation-orders), Crypto.com, Farside-ETF. Je Aufruf: Latenz, Form,
und ob die FELDER da sind, die der Code liest. Pausen zwischen Aufrufen, HL-Gewicht < 150.
Hinweise = nicht gelistete Coins oder ruhige Streams; FEHL = der Code liest etwas, das nicht
(mehr) kommt → zuerst die Doku der Börse prüfen (Umstellung?). Exit 1 bei FEHL.

**Erster vollständiger Lauf auf dem Pi (14.09., 00:24): 61 ok · 4 Hinweise · 0 FEHL.**
Hinweise = nicht gelistet: XMR (Coinbase), XMR/PAXG (OKX), ZEC/XMR (Crypto.com); Bybit
listet alle sechs. Binance-Stream auf der neuen URL 8 Nachrichten/20 s, alte URL still.
Leaderboard 45.106 Zeilen mit allen vier Fenstern und `vlm`. HL-WebSocket trades/l2Book/
activeAssetCtx liefern. Fills des Testwals: volle Seite (2.000 in 24 h) — ein Vielhandler.

**Empfehlung:** einmal je Woche laufen lassen und nach jeder Meldung einer Börse über
API-Änderungen. Das hätte die Binance-Umstellung am Tag ihrer Wirkung gezeigt.

## 3i. Reihen der Fremdbörsen (`hl_ext.py`, 14.09.) — mit Audit

Vier Bausteine, wie beauftragt: `ext_metrics` (Bybit/OKX/Crypto.com alle 5 min),
`bnc_metrics` um die Binance-Verhältnisse ergänzt, `bnc_book` (Orderbuch mit Wänden alle
5 min), `ext_liquidations` (Bybit-Stream vollständig, OKX alle 2 min), dazu `etf_flows`.
Betrieb als Zusatzaufgaben in `hl-binance` (`Live.run_ext`), eigene Verbindung mit
Schloss, Abrufe in Threads. Details, Formate, Ratenbudget: README „Reihen der Fremdbörsen".

**Vor dem Bau geprüft:** Seitenbedeutung Bybit (`S = Buy` → Long liquidiert, Doku) und
OKX (`posSide`); Listungen je Börse aus dem Rundum-Test (Bybit alle 6, OKX ohne XMR/PAXG,
Crypto.com ohne ZEC/XMR); Formate aller Antworten aus dem Rundum-Test; Ratenlimits der
öffentlichen Endpunkte.

**Audit des Ergebnisses (Randfälle gelesen, Proben gefahren) — gefunden und behoben:**

| Befund | Korrektur |
|---|---|
| Bybit-Sperre bei jedem `retCode != 0` — ein Ratenlimit hätte den Coin einen Tag gesperrt | sperren nur bei 10001 (Symbol unbekannt), sonst zählen |
| `gather` ohne `return_exceptions`: stirbt der Stream, laufen die anderen Schleifen verwaist, der Neustart verdoppelt sie | `return_exceptions=True`, Schleifen enden einzeln |
| `import websockets` außerhalb des try | im try, Stream bleibt bei fehlendem Paket aus, Rest läuft |
| Anfangsverzögerungen (bis 600 s) ohne Stop-Prüfung — der Dienst hätte beim Beenden bis zehn Minuten gehangen (Betriebsprobe) | `warten()` in 1-s-Schritten mit Stop-Prüfung; Stopp jetzt in 0,2 s |
| Stream-Puffer (< 20 Zeilen) beim Stopp verloren (Betriebsprobe) | Flush beim Verlassen |
| Ein einziges ungültiges Bybit-Thema hätte die ganze Abonnement-Anfrage abgelehnt | ein Abonnement je Thema |
| Speicher: 40 Wände × 6 Coins alle 5 min ≈ 3,5 MB/Tag | 25 Wände, Buch-Vorhalt 60 Tage |
| `bnc_stats` auf 500 Zeichen gekappt → mit den neuen Zählern abgeschnittenes JSON | 2.000 Zeichen, nur Zahlen |

**Proben:** Selbsttest `hl_ext.py` (Parser, Seiten, Duplikate, Wände, Farside, Invariante);
Integrationstest mit dokumentierten Antwortformaten gegen SQLite (106 Kennzahlen je Lauf,
Sperren wirken, zweiter Lauf ohne Duplikate, alle `ts` in Sekunden); Betriebsprobe der
asynchronen Schleifen mit gemocktem Stream und Netzfehlern (läuft weiter, stoppt sauber).
Selbsttest der Anlage 18/18. **Live-Probe auf dem Pi steht aus**: nach dem Einspielen
„Binance-Modul --status" (Zeilen je Tabelle) und den Rundum-Test (jetzt mit Bybit-Stream).

**Bewusst nicht geändert:** Die Treiber lesen weiter live. Kapitulation über drei Börsen
und einheitliche Taker-Fenster aus `ext_metrics` sind der nächste Schritt, nachdem die
Reihen ein paar Tage gefüllt sind.

## 3j. Magnet-Schwelle — Parameter offengelegt und messbar gemacht (14.09.)

**Herkunft:** „Cluster ≥ ½ Stundenvolumen, mindestens 5 Mio" stammt aus Sitzung 1 — in
`compute_forecast` und `magnet_stats` gleichermaßen, nie gemessen. Sitzung 2 hat nur die
Bezugsgröße korrigiert (HL- statt fusioniertes Volumen, 3f) und die Zahl sichtbar gemacht;
den Faktor ½ hat sie ungeprüft übernommen. Das war ein Versäumnis: Dieser Faktor
entscheidet, ob Liquidationscluster überhaupt als Ziel gelten — der Kern des Systems.

**Jetzt:** `MAGNET_VOL_ANTEIL = 0.10`, `MAGNET_MIN_USD = 5e6` (benannte Konstanten,
`magnet_schwelle()`), in Prognose und Statistik dieselbe Funktion. Bei 100 Mio/h HL-Volumen
sind das 10 Mio — die 92 Mio oben und 35 Mio unten aus der Kachel vom 14.09. qualifizieren
beide. **Gemessen statt geraten:** `magnet_stats` weist den Lift jetzt zusätzlich je
**Größenklasse** aus (5–10, 10–25, 25–50, >50 % des Stundenvolumens; alle Cluster ab
5 Mio). Die Klasse, ab der der Lift über 1 liegt, ist die richtige Schwelle — dann wird der
Faktor nachgezogen. Kachel zeigt beide Sichten.

**Text korrigiert:** „kein großes Cluster in Reichweite" stand für drei verschiedene
Fälle. Jetzt steht der Grund: Richtung neutral (|Bias| ≤ 0,12 → kein Ziel, Sigma-Band) /
kein Cluster über der Schwelle in Richtung / Ziel wird angelaufen, Berührstatistik der
Klasse fehlt noch (n < 5) / Ziel mit Statistik.

**Offen, Entscheidung des Nutzers:** Bei neutralem Bias läuft der Pfad kein Cluster an,
auch wenn 92 Mio 1,8 % entfernt liegen. Wenn Cluster unabhängig vom Richtungsdruck
anziehen sollen (das ist die Magnet-These), müsste der Pfad bei neutralem Bias das
näherliegende/größere Cluster mit der gemessenen Berührquote als Reichweite anlaufen.
Das ist eine Modelländerung, kein Fix — nicht ohne Rückfrage.

## 3k. Magnet-Varianten: ziehen Cluster bei 0,5–1 % und 1–2 % den Kurs an? (14.09.)

Nach der Literatur (Osler 2005: Kaskaden nach der Berührung; Brunnermeier/Pedersen 2005:
Anziehung vorher durch strategisches Drücken; Cho et al. 2003: Magnet-Effekt als bedingte
Wahrscheinlichkeit nach Abstand; Avellaneda/Lipkin 2003: Drift zum Niveau ∝ Exposure)
misst `hl_forecast.magnet_varianten()` je Variante (0,5–1 %, 1–2 % vom Kurs) und Horizont
(4/8/12/24 h): **Δ Berührung minus Placebo** in Prozentpunkten mit z auf n_eff (Hauptmaß;
der Lift als Quotient ist bei kleinem n nach oben verzerrt — acht Seeds Rauschen ergaben
Ø 1,15), **Anziehung** (Überschussbewegung zum Cluster nach Abzug der Marktdrift, mit t),
**näher** gegen Placebo, und **Cho 15 min** (bedingte Wahrscheinlichkeit einer Bewegung zum
Cluster im Band gegen die unbedingte). Unabhängigkeit: ein Ereignis je Niveau und 24 h,
n_eff = getrennte h-Blöcke. Nur Cluster auf der richtigen Seite (Short-Cluster oben,
Long-Cluster unten), ab 5 Mio.

**Kontrollen:** Rauschen → Δ ≈ 0, Anziehung ≈ 0, Cho = Basis (im Nulltest verankert).
Positivkontrolle (ein stehendes Cluster je Tag, Zug 0,3 %/min des Abstands) → Δ +30 bis
+78 pp mit z 3–9, Anziehung +0,6 bis +1,1 % mit t 3–6, Cho 57–60 % gegen 50 %.

**Werkzeug:** Debug-Eintrag „Magnet-Varianten" (`check_magnet.py`, alle Coins, 14 Tage
Heatmap-Vorhalt). Kachel „Magnet-Statistik" zeigt je Variante 4 h und 24 h kompakt; der
Lernzyklus rechnet täglich. **Lesart:** belegt erst, wenn Δ und Anziehung positiv sind und
z bzw. t über 2 liegen, in mehreren Horizonten, mit Cho über Basis; n_eff unter 20 ist keine
Aussage. Erst mit diesem Beleg wird der Pfad bei neutralem Bias das Cluster anlaufen (3j).

## 3l. Schreibkoordination der Dienste (14.09., nach „database is locked" im Poller)

Vier Prozesse schreiben in eine SQLite-Datei (Recorder, Binance-Dienst mit Sammler,
Coinbase, Watchdog). Nach dem Start des Sammlers meldete der Poller „database is locked"
(hl_recorder.py, whale_positions), dreimal je Stunde; der Sammler zählte 38 verworfene
Schreibversuche. Drei Maßnahmen:

1. **`isolation_level="IMMEDIATE"`** für Recorder, Binance-Dienst und Sammler (Coinbase war
   schon Autocommit): Jede Schreibtransaktion holt die Schreibsperre beim Beginn; bei
   fremder Sperre wird gewartet (`busy_timeout`), statt zu scheitern.
2. **Weniger Transaktionen im Sammler:** Bybit-Stream schreibt höchstens einmal je Minute
   (oder ab 200 Zeilen) statt alle 5 s; Meta-Stempel nur im 5-min-Kennzahlenlauf, in einer
   Transaktion. Von ~800 auf ~130 Transaktionen je Stunde.
3. **Nie scheitern, nie blockieren:** Der Sammler wiederholt bei Sperre (0,4 / 0,8 s) und
   hält Stream-Zeilen zurück (`db_retry` / `db_locked` getrennt, Quellenzeile zeigt beides);
   der Recorder hält `whale_positions`-Zeilen zurück (`whale_positions_schreiben()`, Zähler
   `whale_write_deferred`) und schreibt sie beim nächsten Aufruf mit.

**Erwartung:** „verloren" bleibt bei 0, „wiederholt" zählt gelegentlich, der Poller meldet
keine Sperrfehler mehr. Bleibt der Fehler, hält ein Prozess die Datei länger als 60 s — dann
`PRAGMA wal_checkpoint`-Takte prüfen (Recorder, TRUNCATE) und lange Lesevorgänge des
Dashboards (Magnet-Varianten, Konto-Score) auf eine eigene, kurze Verbindung legen.
**Grundsätzlich** wäre ein einzelner Schreibprozess (Queue) die saubere Lösung; das ist ein
Umbau für eine eigene Sitzung.

## 3m. Schreibkoordination, professionell (`hl_dbcoord.py`, 14.09.)

3l („warten und wiederholen") genügte nicht — der Poller meldete weiter Sperrfehler, die
Drossel stand bei 60 % ohne echten Rückstand. Recherche (SQLite-Dokumentation, Mozilla
application-services, Praxisleitfäden): WAL erlaubt viele Leser, **einen** Schreiber; SQLite
reiht wartende Schreiber **nicht fair** ein (Busy-Handler fragt in wachsenden Abständen,
wer zufällig zuerst fragt, gewinnt); `BEGIN IMMEDIATE` verhindert den Snapshot-Fehler, aber
nicht das Verhungern. Das Muster für mehrere Schreibprozesse ist **Serialisierung auf
Anwendungsebene**: eine Sperre vor dem ersten schreibenden Statement bis zum Commit.

**Umsetzung:** `hl_dbcoord.KoordinierteVerbindung` (sqlite3.Connection-Factory) hält eine
prozessübergreifende Sperre (`fcntl.flock` auf `<db>.wlock`) vom ersten schreibenden
Statement bis Commit/Rollback, im Autocommit je Statement; `PRAGMA wal_checkpoint` läuft
darunter (Race-Bedingung in SQLite < 3.51.3 bei gleichzeitigem Schreiben und Checkpoint).
Wartefrist 20 s, danach entscheidet SQLites `busy_timeout` (gezählt als „Frist"). Angebunden:
Recorder, Binance-Dienst, Sammler, Coinbase. Kennzahlen je Prozess (Transaktionen,
Wartezeit Ø/max, Haltezeit Ø/max, Fristen, Haltezeiten über 1 s) in `meta.wlock_*` und im
Netzwerkstatus („Schreibkoordination: …"). Lesende Verbindungen (Dashboard, `mode=ro`)
bleiben unberührt.

**Nachweise:** 4 Prozesse × 300 Transaktionen bei `busy_timeout` 50 ms — ohne Koordination
6 Sperrfehler, mit 0, gleiche Dauer, längstes Warten 150 ms. Recorder-artiger Schreiber
neben dem Sammler: 0 Fehler, keine Zeile verloren, Haltezeit max 9 ms. Selbsttest 19/19.

**Dazu:** Drossel des Adress-Pollers nur noch bei echtem Rückstand (≥ 5 Konten über 3 h →
60 %, ≥ 15 → 30 %; ein bis vier Konten sind Alltag). **Fills alle 15 Minuten** statt
stündlich (`lb_fills_interval = 900`, bei Rückstand 10 min); Budget je Lauf rechnet sich aus
dem Takt. Kosten: ~75 Konten × 4 Läufe × ~25 Gewicht ≈ 125/min, aus der Reserve gedeckt.

**Woran es sich zeigt:** „Schreibkoordination" im Netzwerkstatus mit Fristen 0; keine
`database is locked` mehr im Fehlerfeld; Poller ohne Drosselhinweis; Fill-Median unter
10 min. Zeigt „hält max" bei einem Prozess Sekunden, hält dieser Prozess eine Transaktion
zu lange offen — dann dort committen, nicht die Sperre lockern.

## 3n. Kurze Transaktionen und dynamischer Takt (14.09., nach den ersten Sperrkennzahlen)

Die Kennzahlen aus 3m zeigten sofort das nächste Problem: Recorder **hält** die Sperre
Ø 1,8 s (max 6,4 s, 142× über 1 s je Stunde), Binance-Dienst Ø 3,2 s (max 12,4 s). Beide
hielten Transaktionen über Netzaufrufe hinweg offen — das Anti-Muster schlechthin:

| Stelle | vorher | jetzt |
|---|---|---|
| Recorder Poll-Runde | erster Schreibzugriff öffnet, Commit erst nach `gather` aller 26 Adressen | Puffer (Wal-Positionen, abgeleitete Liquidationen, Adress-Stände), `flush_round()` schreibt am Ende in **einer** Transaktion; bei Sperre bleiben die Puffer stehen |
| Recorder Fills | Schreiben je Konto, Commit erst nach allen 75 Konten (Sperre über den ganzen Lauf) | Commit je Konto |
| Binance-Stream | Einzel-INSERT, Commit alle 25 Ereignisse/10 s → Sperre bis 10 s beim Warten auf Nachrichten | Zeilen sammeln, alle 25/10 s `executemany` + Commit in Millisekunden; Flush beim Beenden |
| Binance Open Interest | INSERT je Symbol zwischen Netzabrufen, Commit am Ende | erst alle Abrufe, dann eine Transaktion |

**Erwartung:** „hält max" bei allen Prozessen unter 100 ms, „über 1 s gehalten" bleibt bei 0.

**Dynamischer Takt** (`dyn_takt`): Fills und Leaderboard-Stände laufen nach freiem Budget
statt fester Uhr — bei ≥ 45 % freiem Gewicht ein Viertel des Basistakts (Fills alle 4 min,
Leaderboard alle 90 s), bei ≥ 30 % die Hälfte, bei ≥ 15 % drei Viertel, sonst Basistakt.
Jeder Lauf nimmt weiterhin nur die freie Reserve. Kennzahlen `fills_takt_s`, `lb_takt_s`,
`budget_frei_pct` in den Stats.

**Nächster Schritt — bedarfsgesteuerte Warteschlange (Vorschlag des Nutzers, richtig):**
Statt vier Schleifen mit eigener Uhr ein Scheduler im Recorder: jede Abfrage (Adresse,
Konto-Fills, Orders, Leaderboard) ist ein Element mit **Nutzen** = Alter des Stands ×
Wichtigkeit (Konto-Score, Positionswert, Nähe zur Liquidation) und **Kosten** = Gewicht;
ein Token-Eimer mit 1.020 Einheiten je Minute; der Scheduler nimmt fortlaufend das Element
mit dem höchsten Nutzen je Gewichtseinheit. Damit verteilt sich das Budget von selbst dorthin,
wo es am meisten Information bringt, und alles ist so aktuell, wie das Budget erlaubt.
Das ersetzt Drossel, Stufen und Takte — ein Umbau der Recorder-Schleifen, für eine eigene
Sitzung, mit der Elite-Liste (`learn.elite`) als erster Wichtigkeitsquelle und den
WebSockets für die zehn besten Konten als Echtzeit-Ergänzung ohne Gewicht.

## 3o. Fills in Echtzeit aus dem Trade-Stream, Leaderboard alle 2 min (14.09.)

Anforderung des Nutzers: Fill-Median unter 2 Minuten, kontinuierlich abfragen, minütlich
schreiben. Rechnung: 75 Konten per REST alle 2 min = ~825 Gewicht/min — nicht bezahlbar.
Der Weg ohne Gewicht: Der Recorder empfängt bereits **jeden Trade** der sechs Coins per
WebSocket mit `users = [Käufer, Verkäufer]` (Doku, 14.09. geprüft), Preis, Größe, `tid`.
Für die beobachteten Konten sind das ihre Fills, in Echtzeit.

**Umsetzung (`hl_recorder.py`):** `on_trade` puffert Trades, an denen ein Konto der aktuellen
Leaderboard-Auswahl (`fill_konten`, bei jedem Leaderboard-Zyklus aktualisiert) beteiligt ist,
als `lb_fills`-Zeile mit `dir='stream'` (Seite B/A aus der Position im `users`-Paar, `buy`
entsprechend, closedPnl/fee 0). `run_stream_fills` schreibt sie **minütlich in einer kurzen
Transaktion** (Puffer bleibt bei Sperre stehen, Flush beim Beenden). Der REST-Abgleich
(`userFillsByTime`, Takt nach freiem Budget, min. 4 min) **löscht die Stream-Zeilen des
Kontos im geholten Zeitraum** und schreibt die vollständigen Fills — die `tid` beider
Quellen muss dafür nicht übereinstimmen. Konsumenten (Konto-Score, Smart-Flow) sehen
Stream-Zeilen nur bis zum Abgleich. Grenze: Fills in Coins außerhalb der sechs Projekt-Coins
kommen weiterhin nur per REST.

**Leaderboard-Stände:** `lb_interval` 300 → 120 s (bei freiem Budget 90 s); Kosten ~75/min.

**Anzeige:** „Fills live: Trade-Stream für n Konten, m Fills in der letzten Minute" und
getrennt „REST-Abgleich der Fills: Median …, Takt … nach freiem Budget · Leaderboard-Stände
alle … s". Meta-Schlüssel `stream_fills_min`, `stream_fills_konten`, `fills_takt_s`, `lb_takt_s`.

**Orders bleiben die teure Klasse** (20 Gewicht je Konto, `frontendOpenOrders`): alle 75 Konten
alle 2 min wären 750/min. Zwei Wege, beide brauchen den Score-Kanal zum Recorder: die zehn
Elite-Konten per WebSocket `orderUpdates` (0 Gewicht, im 10-Nutzer-Limit) und der Rest im
Stufentakt — oder der bedarfsgesteuerte Scheduler aus 3n, der Orders nach Nutzen je Gewicht
einreiht. Das ist der nächste Umbau.

**Geprüft:** Trade-Handler (Konto als Käufer → B/Kauf, als Verkäufer → A/Verkauf,
Fremdkonten ignoriert), minütlicher Schreiber mit Flush beim Stopp, REST-Abgleich ersetzt
Stream-Zeilen (Nachweis mit Datei-DB), Selbsttest 19/19.

## 3p. Die 600-Sekunden-Transaktion und die letzten langen Halter (14.09., 15:00)

Die Sperrkennzahlen zeigten „binance hält max 600.001 ms" — exakt zehn Minuten. Ursache:
`run_report` im Binance-Dienst schreibt Meta-Zeilen und committete **nicht**; der Commit
stand erst am Anfang der nächsten Runde, nach `sleep(600)`. Zehn Minuten offene
Transaktion, alle zehn Minuten, seit Wochen — vor der Koordination hielt das genauso SQLites
Schreibsperre. Sehr wahrscheinlich die eigentliche Quelle der „database is locked"-Fehler
des Recorders von Anfang an. **Behoben:** Commit direkt nach dem Schreiben.

**Diagnose statt Raten:** `hl_dbcoord` merkt sich je Transaktion das eröffnende Statement
und hält die fünf längsten (ab 0,2 s) vor; der Netzwerkstatus zeigt sie: „längste: 6,3 s
‚INSERT OR REPLACE INTO heatmap …'". Damit ist jeder lange Halter benannt.

**Gestückelt (Recorder):** stündlicher Adress-Flush (bis zu 50.000 UPDATEs), Heatmap-
Schnappschuss, Leaderboard-Positionen → `stueckweise()`: 2.000 Zeilen je Transaktion,
Sperre dazwischen frei (Probe: 12.000 Zeilen in 8 Transaktionen, max 5 ms). Aufräum-
Deletes (lb_events, lb_positions, lb_fills, lb_spot) → `loesche_stueckweise()`: nach
Zeitfenstern von 6 h Datenzeit je Transaktion (funktioniert auch für WITHOUT-ROWID-
Tabellen); neuer Index `lb_events(ts)`.

**Zum Fill-Median:** Die Zeile „REST-Abgleich der Fills: Median 35 min" misst das Alter des
REST-Abholstands, nicht das Alter der Daten. Die Fills selbst kommen seit 3o aus dem
Trade-Stream in Echtzeit („Fills live"). Damit das nicht mehr missverständlich ist, zeigt die
Zeile „Fills live" jetzt zusätzlich Fills der letzten 10 Minuten und Gesamtzahl seit Start,
und der Abgleich heißt ausdrücklich „Nachtrag von closedPnl/fee/dir". Der REST-Takt folgt
weiter dem freien Budget (bei 84 % Auslastung = Basistakt 15 min); er ist kein Maß für die
Aktualität mehr.

**Erwartung nach dem Einspielen:** binance „hält max" unter 100 ms; recorder „über 1 s
gehalten" nahe 0; „Fristen überschritten" 0; keine `database is locked` mehr.

## 3q. Nachlese der Diagnose (14.09., 15:00): book_summary im WebSocket-Handler

Die neue Anzeige der längsten Transaktionen zeigte sofort den nächsten Halter: „2,985 s
‚INSERT OR REPLACE INTO book_summary'". `on_book` (WebSocket-Handler des HL-Buchs) schrieb
direkt in die Datenbank; die Transaktion blieb bis zum nächsten Commit der Poll-Runde offen.
Jetzt puffert `on_book` den jüngsten Stand je 5-s-Fenster und Coin, `flush_round` schreibt
ihn mit. Der seltene Tick-Dump bei Kaskaden committet sofort. Statement-Texte in der Anzeige
enden nicht mehr mitten im Wort („misses=miss"), sondern zeigen Aktion und Tabelle.

**Lesehinweise für die Kennzahlen:** `wlock_binance` wird nur alle 10 min geschrieben — nach
einem Neustart des Binance-Dienstes zeigt die Kachel bis dahin den alten Wert (600.001 ms).
„Fills live … seit Start" zählt seit dem Neustart des Recorders; „Stream liefert n Trades/min
mit Adressen" belegt, dass der Trade-Stream Adressen liefert — ist das > 0 und bleiben die
Fills über Stunden bei 0, ist die Zuordnung der Konten das Problem, nicht der Stream.

## 3r. Auditbericht v3 (Kimi K3, 14.09.) — Umsetzung

Alle sechs MEDIUM-Befunde am Code bestätigt und behoben, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| D1 Fill-Cursor springt nach Netzfehler hinter voller Seite auf „jetzt" | `fehler`-Flag; Teilseitenregel nur bei sauberem Ende | Logik nachvollzogen |
| D2 hl_ext `schreibe()` ohne Rollback → Transaktion + flock offen | Rollback bei **jedem** `sqlite3.Error`; Nicht-Sperrfehler zählen statt werfen | Fehlversuch → `in_transaction` False, Sperre frei |
| D3 hl_binance `puffer_schreiben()` dito | Rollback vor allem anderen, Fehler gezählt | — |
| D4 OKX-Ratenlimit sperrt Coin 24 h | sperren nur bei 51001 | 50011 → nicht gesperrt; 51001 → gesperrt |
| D5 Crypto.com leere Liste sperrt | sperren nur bei 40004/40003 | leere Liste (code 0) → nicht gesperrt |
| D6 Bybit-Puffer bei Abbruch verloren | Puffer außerhalb der Verbindung, Flush im `except`; Themen je Verbindung neu (L8) | Abbruch nach 2 Liquidationen → 2 gespeichert |

LOW umgesetzt: L1 (Sperr-Sentinel je Transaktion), L2 (Recorder: 20 Versuche Symbolauflösung,
dann Exit 1), L3 (tote `schreibe()` entfernt), L4 (leerer Stapel flusht Puffer), L5 (Coinbase
120-s-Empfangs-Timeout), L6 (CDC-Spanne vorzeichenfrei), L7 (Farside „–" übersprungen), L9
(OKX-uid in ms), L10 (Zählung unter dem Schloss), L11 (Sperrdatei nicht öffenbar → Zähler +
Meldung), L12 (`con.close()` im finally), L13/L15 (Doku), L14 (Hinweis), L16 (`--ws-sekunden`).
Offen: L17 (Lint, kosmetisch).

**Datenhaltung (S1–S8) — die eigentliche Erkenntnis des Berichts:**

| # | Umsetzung |
|---|---|
| S1 | `lb_stats_hist` (PK addr, ts): jede Stunde PnL/ROI/Umsatz je Konto, unbegrenzt; `lb_stats` bleibt der jüngste Stand |
| S2 | `lb_pos_hourly`: je volle Stunde die Positionen der Leaderboard-Konten, unbegrenzt |
| S3 | `lb_fills_daily`: vor dem Löschen je Tag/Konto/Coin Kauf-/Verkaufsnotional, n, closedPnl, Gebühren (Probe: Summen korrekt) |
| S4 | `forecast_drivers` (ts, coin, name, score) und `forecast_slim` (ts, coin, price, bias, p_4h…p_168h, p_up, p_up_24) in forecasts.db, **unbegrenzt**; Prognosezeilen mit Payload weiter 60 Tage |
| S5 | `score_forecasts` bewertet **72 h und 168 h** aus `forecast_slim` (ein Fall je Stunde, n_eff = getrennte Blöcke); Kachel zeigt sie als „unkalibriert (Drift ohne gelernte Gewichte)" |
| S6 | `book_summary` älter als 14 Tage → Minutenmittel `book_summary_1m`, täglich nach dem Backup, in 6-h-Fenstern (Probe: 14.400 Zeilen → 1.200, max 25 ms Sperre) |
| S7 | Coinbase `BARS_DAYS` 30 → 180 |
| S8 | Binance `premiumIndex` alle 5 min in `bnc_metrics` (`funding`, `basis_bps`) |

**Noch nicht:** Die Kalibrierung liest weiter die Payloads der 60-Tage-Prognosezeilen; für eine
lernende 168-h-Spur muss `calibrate_weights` auf `forecast_drivers` umgestellt werden — sinnvoll,
sobald dort einige Wochen liegen. Selbsttest 19/19, Nulltest grün.

**Indikatoren (Abschnitt 3 des Berichts):** Entscheidung mit dem Nutzer — siehe Gesprächsnotiz.
Vorschlag der Reihenfolge: N3 OI-Perzentil, N7 Crowding-Extreme, N8 ETF-Momentum, N9 Vol-Regime
(als Kontext, nicht Richtung), N1 Funding-Spread (Daten seit S8), N6 Liquidations-Imbalance
(Bybit vollständig), Varianz-Kompression aus `bars10` (Regime-Flag). Jeder mit Prior 0,3–0,5,
Nulltest-Pflicht, Killkriterium; keiner ersetzt einen bestehenden Treiber.

## 3s. Neue Indikatoren nach Auditbericht v3 — Entscheidungen des Nutzers (14.09.)

Entscheidungen: (1) N3/N7/N8/N9/N1 sofort, (2) N6 und Varianz-Kompression ebenfalls, (3) Priors
von Taker/Funding/Buch unverändert — die Kalibrierung entscheidet, (4) Horizont Stunden bis
vier Wochen.

**Neues Modul `hl_indikatoren.py`** (reine Funktionen auf der Hauptdatenbank, None bei zu
wenig Daten → Treiber erscheint nicht):

| Treiber / Flag | Quelle | Form | Prior |
|---|---|---|---|
| OI-Überhitzung | `bnc_metrics.open_interest` (sonst `ctx_bars.oi`), Perzentil 90 T | ab 90. Perzentil leichter Kontra (−0,6 × Überhitzung); zugleich Regime | 0,3 |
| Crowding-Extrem | `lb_trend` (Top-20, unbegrenzt), Perzentil 365 T | unterstes Dezil → +1, oberstes → −0,5 (asymmetrisch wie die Studie) | 0,5 |
| Crowding-Trend 7 T | dito | Δ 7 T normiert an der Verteilung solcher Änderungen, tanh | 0,4 |
| ETF-Momentum | `etf_flows` (seit 3i) | (3-T-Mittel − 10-T-Mittel) / σ, tanh; nur BTC/ETH | 0,5 |
| Vol-Spike-Reversion | `bars` (Parkinson-σ 24 h gegen 20 T) | ab 1,5× Norm gegen die 24-h-Bewegung; Verhältnis ist zugleich Band-Multiplikator 0,7–1,6 | 0,3 |
| Funding-Spread | `ctx_bars.funding` gegen `ext_metrics.funding_8h` + `bnc_metrics.funding` (seit S8) | Perzentil des Spreads 30 T, Kontra (Carry) | 0,4 |
| Liquidationsdruck (3 Börsen) | `bnc_liquidations` + `ext_liquidations` + `liquidations` | Imbalance × Intensität (2 h gegen 30-T-Perzentil); Intensität zugleich Regime | 0,5 |
| Taker-Varianz-Kompression | `bars10` (Varianz der 10-s-Salden je Stunde, 30-T-Verteilung, Tages-Cache) | **nur Regime** (unterstes Dezil → Band +20 %) | — |

**Regime** = Band-Multiplikator aus Vol-Verhältnis × (1 + 0,25·OI-Überhitzung) × (1 + 0,25·
Liquidationsintensität) × (1 + 0,2·Varianz-Kompression), gedeckelt 0,7–2,2; steht im Payload
(`regime`) und als Zeile über der Treibertabelle. Es verschiebt keine Richtung.

**Nulltest:** neue Zeile „Neue Indikatoren auf Rauschen" — alle sieben Funktionen liefern auf
synthetischem Rauschen ein Ergebnis, Scores in [−1, 1], Band nahe 1. (Ein echter Vorzeichen-
Bias-Test über viele Zeitpunkte ist mit „jetzt"-lesenden Funktionen nicht möglich; die
Kalibrierung mit Killkriterium übernimmt das im Betrieb.) Selbsttest 19/19.

**Was auf dem Pi zuerst erscheint:** Vol-Spike-Reversion und Liquidationsdruck (Daten da),
OI-Überhitzung (13 Tage Binance-OI), Crowding (lb_trend seit Sitzung 1). Funding-Spread braucht
3 Tage `ext_metrics`, ETF-Momentum 12 Tage `etf_flows` (der Farside-Import bringt die Historie
mit, also sofort). Erwartung an die Kalibrierung: nach 2–4 Wochen zeigt die Treibertabelle, wer
trägt — die Priors sind klein genug, dass ein Nichtträger nichts verdirbt.

## 3t. Auditbericht v4 (15.09.) — Umsetzung

Fix-Quote v3 laut Audit 27/27. Neue Befunde: 5 MITTEL, 10 NIEDRIG — alle umgesetzt, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| M1 `_rank` strikt „<": Plateau → Perzentil 0 → Vollsignal (Crowding +1, Funding ±1, Varianz-Band +20 %) | Midrank (Bindungen halb); konstante Reihe → None | konstant → None; Median mit Bindungen 0,46 statt 0,31 |
| M2 Liquidationsintensität gegen verdoppelte Einzelstunden (Varianz falsch) → Trigger 6 % statt 10 % | Referenz aus echten rollierenden 2-h-Summen | Nulltest |
| M3 `book_summary_verdichten` synchron auf der Ereignisschleife | `book_summary_verdichten_datei()` in `asyncio.to_thread` mit eigener koordinierter Verbindung | 1.440 Zeilen im Thread verdichtet |
| M4 `lb_fills_daily` doppelt nach Absturz; Löschung trotz Aggregationsfehler | `fills_verdichten_und_loeschen()`: je 6-h-Fenster Aggregat + Löschung in **einer** Transaktion, Rollback bei Fehler, keine Löschung ohne Aggregat | zweiter Lauf 0 Zeilen, Summe exakt; Zieltabelle fehlt → 0 gelöscht, Zeilen erhalten |
| M5 Restore startete Dienste mit kaputtem Stand | Syntaxfehler → gesicherter Stand (`_rueck`) wird zurückgespielt, dann Start | kaputtes `hl_score.py` im Backup → nach Restore wieder gültig |

LOW: L1 OI-Quellenwahl mit Frische (Binance frisch & lang genug, sonst HL), L2 Funding-Spread je
Quelle ein try, L3 ETF-Frische 4 Tage, L4 gemessene Stunde nicht in der Varianz-Referenz,
L5 Rollback in den neuen Fehlerpfaden, L6 Einfügen + Löschen je Fenster in einer Transaktion,
L7 Regime-Zeile vor der Tabelle, L8 `/restore/info` im 30-s-Antwort-Cache, L9 `n_fremd` zählt
Börsen, L10 `run_oi` fängt `sqlite3.Error`; Kommentar premiumIndex-Endpunkt. S2-Hinweis: `lb_pos_hourly`
ist der Schnappschuss des ersten Zyklus je Stunde, kein Stundenmittel. Offen bleibt L17 (Lint).

Nulltest grün, Selbsttest 19/19. Die vom Audit empfohlene Umstellung der Kalibrierung auf
`forecast_drivers` (inkl. 72/168-h-Training) steht wie geplant an, sobald 8–12 Wochen vorliegen.

## 3u. Elite-Positionierung geprüft (15.09., `check_elite.py`)

Anlass: −0,95 gegen Smart Money +0,77. Werkzeug „Elite-Positionierung prüfen" (Debug, gewählter
Coin, mit Live-Abfrage): Elite-Konten mit Score, Klassen kontoweit/im Coin, n, Vorlauf, Position
aus lb_positions und whale_positions mit Alter, Widersprüche („≠"), Live-Stand („WEICHT AB"),
Dominanz, Treiber alt/neu, Smart Money aus demselben Schnappschuss.

**Befund auf dem Pi:** Daten korrekt (alle zehn live bestätigt, ein Zeitstempel, close → flat).
Der Gegensatz ist echt: Smart Money = Top-50 nach Leaderboard-Gewinn (17 long 387 Mio); „Elite" =
fast nur Wale außerhalb des Leaderboards mit 1–7 Schritten in BTC, Score aus Größe/Klasse, nicht
aus belegtem Vorlauf; einziges belegtes Konto (n=140) hält 51 % des Bruttowerts short.

**Korrekturen:** (1) `hl_score.elite()`: Mitglied nur mit ≥ 10 Schritten im Coin und positivem
Vorlauf (`ELITE_MIN_SCHRITTE`). (2) Treiber zählt nur im Coin direktionale Konten (Leaderboard-
Gruppe; Wale ohne Eintrag nur bei Klasse 1,0). (3) Dominanz-Dämpfer clip((1−anteil)/0,5, 0,5, 1).
Erwartung: Der Treiber fehlt zunächst häufig („zu wenige direktionale Elite-Positionen") — das
ist ehrlich; er erscheint, sobald genug Konten Beleg haben. Die Elite-Liste speist auch die
WebSocket-Kandidaten (Konzept 2.5): dort gilt dieselbe Schwelle.

## 3v. Treiber-Funktionstest (`check_treiber.py`, 15.09.)

Für alle 30 Treiber und die Regime-Flags kontrollierte Szenarien mit bekanntem Ergebnis:
aufwärts (positiv, Betrag nach Formel), abwärts, Sättigung, und wo es Bedingungen gibt, gesperrt
(zu wenig Konten/Umsatz, Spanne < 60 s, Dienst aus, Plateau, veraltet). 72 Prüfungen, alle
synthetisch und in-memory; Teil des Selbsttests (jetzt 20 Schritte) und als Debug-Eintrag
„★ Treiber-Funktionstest" mit anschließender Plausibilität auf der echten Datenbank (welche
Treiber liegen an, mit welchem Score und Gewicht, warum fehlen andere).

Was der erste Lauf nebenbei klargestellt hat (keine Fehler, aber Eigenschaften, die man kennen
muss): Smart-Flow gewichtet ALLE Konten mit Score > 0 — ein schwaches Konto (0,2) zählt mit
kleinem Gewicht mit; das Kapitulationssignal wird im Lernzyklus berechnet und über `learned`
übergeben (compute_forecast rechnet es nicht selbst); Elite-Positionierung braucht drei zählbare
Positionen; ein OI-Plateau von 30 Stunden am Rekord ergibt per Midrank ü ≈ 0,77, nicht 1.

## 3w. Fund des Treiber-Tests auf dem Pi: „Direktionale Wale" war nicht je Coin (15.09.)

Die Plausibilität in `check_treiber.py --db` zeigte für BTC und ETH identische Zahlen (51 long
1.281 Mio gegen 59 short 1.451 Mio, 110 Wale). Ursache: In `load_whales` hat die Abfrage der
aktuellen Positionen keinen Coin-Filter (für die Wal-Tabelle gewollt), und die Richtungs-
Zusammenfassung `directional` wurde daraus über ALLE Coins gebildet — seit Sitzung 1. Ein Wal
mit BTC long und ETH long zählte doppelt, einer mit BTC long und ETH short fiel als „zwei
Seiten" heraus. **Korrektur:** Zusammenfassung nur aus Zeilen des Coins, Klasse je Coin über
`behavior_per_coin` (Gruppen dir und mixed zählen, hedge/mm nicht — dieselbe Konvention wie
`lb_groups(coin)` bei Smart Money). Regressionsprobe im Treiber-Test (BTC ≠ ETH). Der
Treiber „Direktionale Wale" hat damit eine neue Datenbasis; seine bisherige Trefferbilanz gehörte
zu einem anderen Signal. Dazu: `hl_viz.Handler.db` wird im Plausibilitätslauf gesetzt (keine
Thread-Fehler der Hintergrundlader mehr).

## 3x. Elite-Positionierung, zweite Prüfung (15.09., 15:18): −1,00 ist korrekt gerechnet — und ein Momentum-Proxy

Nach der Beleg-Regel (n ≥ 10, Vorlauf > 0) bestand die Elite aus zehn Walen, alle kontoweit
direktional, alle live bestätigt; acht davon short (4–48 Mio), zwei flat; größtes Konto 38 %
(kein Dämpfer). Score −1,00 ist damit richtig: acht belegte Konten, einstimmig short. Smart
Money (Top-50 nach Gewinn) zugleich +0,85.

**Zwei Erkenntnisse:** (1) Der Beleg war schwach — Vorläufe von +0,01 bis +0,24 %/4 h ohne
Signifikanzprüfung; ein Vorzeichen ist kein Beleg. Jetzt zusätzlich `ELITE_MIN_T = 1.0`
(t-Wert des 4-h-Vorlaufs). (2) **Selektionseffekt:** Der Vorlauf misst die Rendite nach den
eigenen Schritten im 28-Tage-Fenster. In einem fallenden Markt sammeln genau die Konten
positiven Vorlauf, die short waren — und die halten weiter short. Die Elite-Positionierung ist
dadurch strukturell mit dem jüngsten Trend korreliert (ein Momentum-Proxy), nicht unabhängig
davon. Kein Rechenfehler, aber die Lesart, die man kennen muss; ob sie Vorhersagewert hat,
zeigt die Kalibrierung. Werkzeug `check_elite` zeigt jetzt den t-Wert je Konto und meldet eine
leere Elite ausdrücklich.

## 3y. Elite-Kanal zum Poller (15.09., nach zwei „WEICHT AB" im Prüflauf)

`check_elite --live` fand zwei Konten, deren Datenbankstand vom Live-Stand abwich: eines hatte
vor Minuten geschlossen (Leaderboard-Schnappschuss 12 min alt, Poller sah nur die Reduktion),
eines hatte nach einem „close" einen 9-Mio-Short eröffnet, den der Poller **18 Stunden** nicht
sah — wer flat geht, fällt in die niedrigste Abfragestufe, auch ein Elite-Konto. Das ist der
Score-Kanal aus Konzept 2.4/2.5, jetzt in der einfachsten Form:

- Dashboard speichert die Elite je Coin in `forecasts.db` (`learned`, Schlüssel `elite`).
- Recorder liest alle Elite-Listen alle 5 min (`lade_elite`, read-only) und fragt diese Konten
  im **Wal-Takt** (jede Minute) ab, unabhängig vom Positionswert (`due_addresses`, Stufe A).
- Probe: flates Elite-Konto wird fällig, normales flates Konto nicht, Wal weiterhin.
- Elite-Regel jetzt mit t ≥ 1,0 (`ELITE_MIN_T`); `check_elite` zeigt t je Konto und warnt bei
  einem Schnappschuss älter als 5 min. Die „Nicht aktiv"-Zeile unter der Treibertabelle nennt
  jeden fehlenden Treiber mit Grund.

Nächste Stufe bleibt der WebSocket für die zehn besten Konten (0 Gewicht, Echtzeit).

## 3z. Statuszeilen richtig gestellt (15.09., Bild des Netzwerkstatus)

- **Snapshots „0 Zeilen je Durchgang":** Anzeigefehler, kein Datenfehler. Der Zähler
  `snapshot_rows` wurde nie gesetzt. Jetzt: „N Heatmap-Zeilen aus M Positionen, K zu alt
  ausgelassen". Der Snapshot ist der 10-min-Heatmap-Schnappschuss (Liquidationspreise aller
  Positionen im 0,25-%-Raster) plus Abdeckung, Wal-Zeitreihenpunkt, Order-Niveaus, Stempel.
- **„Gewichte prüfen vor 50 h":** zeigte das letzte SCHREIBEN der Gewichte; geprüft wird alle
  15 min, geschrieben nur ab n_eff 40. Jetzt Zeitpunkt der Prüfung (`learned` Schlüssel
  `weights_check_<h>`), im Text n_eff und ob gelernt wurde.
- **„Leaderboard-Stände vor 20 min" (Soll 90–120 s):** Ursache die Fill-Läufe von 709 s bei
  4-min-Takt — Rücken an Rücken, dauerhaft Gewicht, der Leaderboard-Zyklus wartete am
  Begrenzer (273 s je Zyklus). Jetzt Pause mindestens so lang wie der letzte Lauf; seit dem
  Trade-Stream sind Fills ohnehin in Echtzeit, der REST-Abgleich darf warten.

## 3aa. Begrenzer mit Rang (17.09.) — Ursache der Verzögerungen

Die neue Phasenzeile zeigte: „75 Konten abgefragt 280 s (davon Warten am Begrenzer …)". Die
Arithmetik: Budget 1.020/min; Poller 320 Abfragen × 2 = 640, Wal-Orders 320 → 960 = 94 % per
Konfiguration; für Leaderboard-Stände (150 je Zyklus) und Fills (1.600 je Lauf) blieben 60/min
→ 280 s bzw. 660 s. Und der Begrenzer war eine FIFO-Sperre: die 2-Gewicht-Abfrage der 75
wichtigsten Konten stand hinter jeder 20-Gewicht-Orderabfrage an.

**Korrektur:** `RateLimiter` als Warteschlange mit Rang (Heap, Verteiler-Task): Rang 0
Leaderboard, 1 Poller/Orders/sonstiges, 3 Fills (`PRIO_BY_QUELLE`). Probe: Fills sättigen das
Budget, Leaderboard-Abfragen warten Ø 0,13 s statt Minuten; Durchsatz exakt am Budget.
Wartezeit je Rang (`limiter_wait_by`) in den Stats; Statuszeilen zeigen die eigene Wartezeit
(Leaderboard: Rang 0; Fills: Rang 3). Budgetanteile: `--polls-per-min` 320 → 280,
`stop_weight_budget` 320 → 240 — damit bleiben ~160/min für Fills (ein Lauf ~10 min) statt null.
Erwartung nach dem Einspielen: Leaderboard-Stände wieder alle 90–120 s mit Zyklen < 30 s.

## 3bb. Reserve für den Hintergrund (17.09., 05:00): Fills verhungerten am Rang

Nach dem Rang-Begrenzer fehlte die Zeile „Leaderboard-Fills" im Zeitplan: Der Lauf war seit dem
Neustart nicht fertig geworden — Rang 3 bekam bei 80 % Auslastung durch Poller/Orders nur Reste.
**Korrektur:** eigener Reserve-Eimer (`RESERVE_ANTEIL` 15 % ≈ 150/min), aus dem nur Rang ≥ 2
schöpft; der Haupteimer schrumpft um denselben Anteil, die Summe bleibt am Budget. Probe unter
Volllast: Rang 3 bekommt 31 % (Reserve + Reste), Rang 0 wartet Ø 0,03 s. Das Fill-Laufbudget
rechnet die Reserve als garantiert frei. Dazu Fortschritt während des Laufs („läuft: 30/75
Konten, 812 Gewicht bisher") alle zehn Konten — die Zeile fehlt nie mehr.

## 3cc. Deckel 90 %, Fill-Reserve 20 % (17.09., Vorschlag des Nutzers)

Der Recorder deckelte sich bei 85 % von 1.200 (1.020/min) — ein Sicherheitsabstand aus der Zeit
vor der exakten Gewichtszählung; 429 stand seit Wochen bei null. Jetzt 90 % (1.080/min), und die
fünf Punkte gehen an die Fill-Reserve: `RESERVE_ANTEIL` 0,15 → 0,20 = 216/min nur für Rang ≥ 2.
Haupteimer 864/min für Leaderboard/Poller/Orders. Ein Fill-Lauf von 1.600 Gewicht dauert damit
~7,5 min. Wächter (`API-Budget`) und Farbe der Ratengrenze warnen erst über 91 %, kritisch über 97 %.

## 3dd. Reserve als Garantie, nicht als Ausschluss (17.09., Bild: Plateau bei 930)

Nach 3bb/3cc lag die Auslastung bei ~930 statt 1.080: Die Fill-Reserve (216/min) war NUR für
Rang ≥ 2 nutzbar und lag brach, sobald kein Fill-Lauf lief — also die meiste Zeit. Jetzt ist
die Reserve arbeitserhaltend: Wartet ein Hintergrund-Aufruf, bekommt er sie zuerst (Garantie);
wartet keiner, dürfen Leaderboard/Poller/Orders sie verbrauchen. Probe ohne Hintergrund:
Budget voll genutzt; mit Hintergrund: Rang 3 ≥ 216/min, Rang 0 wartet Ø 50 ms (Verteiler-Körnung
50 ms statt 250 ms). Dazu: Orders zurück auf 320/min (16 Konten je Minute), die Fill-Pause
„mindestens so lang wie der letzte Lauf" ist weg — Rang und Reserve machen sie überflüssig.
Erwartung: durchgehend ~1.050–1.080/min, Wal-Orders wieder im Minutentakt, Fills alle
4–15 min nach freiem Budget.

## 3ee. Analyse v6 (17.09.) — Budget kam nicht bei 1.080 an: umgesetzt

Externe Analyse mit Simulation, beide Hauptbefunde am Code bestätigt:
- **U1** Init-Klammer `min(1080, 280·2+320+60)` = 940 → Angebot lag 13 % unter dem Deckel (das
  Plateau ~930). **Fix:** `RateLimiter(int(1200·0,90))`; die Erzeuger begrenzen sich selbst.
- **U2** Verteiler prüfte nur die acht vordersten Wartenden; hinter 23 parallelen Poller-Abfragen
  lag ein Fill-Aufruf nie im Fenster, die Reserve verfiel (simuliert: 752/min, Fills 2 in 75 s).
  **Fix:** ganzer Heap; Vordergrund darf die Reserve oberhalb des sofortigen Hintergrund-Bedarfs
  (`bg_bedarf`) nutzen. Probe: Gemisch mit 23 parallelen Wartenden + Fills → Angebot voll genutzt,
  Fills 240/min ≥ 216, Rang 0 Ø 43 ms.
- Empfehlungen: Leaderboard-Positionen parallel in Stücken à 6 (Zyklus ~15 s statt 60 s),
  feste Pacer (0,2/0,3 s) entfernt, Orders-Runde nach **Gewicht** bemessen (Multi-Dex-Wale
  kosten (1+n)·20) und Takt 60 s abzüglich Arbeitszeit, Fill-Budget aus dem realen Takt,
  8-s-Timeout für 2-Gewicht-Abfragen, `weight ≤ capacity` (V5-M4), `api_weight_budget` =
  effektiver Deckel (thermisch skaliert) plus `api_weight_limit` = 1.200.
- Anzeige/Wächter: Chart zeigt rote Linie Limit und gelbe Linie Deckel; Ratengrenze in % des
  Deckels und des Limits; Wächter warnt gegen das Limit (≥ 93 %), nicht gegen den Deckel.
- **„Wal-Orders" heißt jetzt „Orders (Konten ≥ 250k)"** und nennt die Stufen der fälligen Konten
  („fällig: Wale ≥ 20 Mio 9, 5–20 Mio 41, 1–5 Mio 300, 0,25–1 Mio 1.604"): die 1.954 waren nie
  Wale, sondern alle fünf Größenstufen; die kleinen laufen nur nach, wenn Budget übrig ist.
Selbsttest 20/20.

## 3ff. Acht Tabs = 99 % CPU (21.09.) — drei Maßnahmen und Bug-Prüfung

Ursache bestätigt: offene Browser-Tabs; jeder pollte Chart (5 s) und Daten (20 s).
1. **Unsichtbare Tabs pausieren** (`document.visibilityState`): alle Intervalle prüfen die
   Sichtbarkeit; beim Sichtbarwerden lädt der Tab einmal komplett nach. Browser-Probe: verborgen
   12 s → höchstens eine nachlaufende Abfrage, sichtbar sofort wieder.
2. **Chart-Antwortcache 5 s** je Coin/Quelle (vorher 4 s).
3. **CPU je Dienst** in der Systemkachel: PIDs über `systemctl show MainPID` (sonst /proc-
   Kommandozeilen), utime+stime aus `/proc/<pid>/stat`, Differenz je Messung, Prozent eines Kerns;
   rot ab 150 %, gelb ab 80 %; Summe gegen Kerne × 100 %. Erste Werte nach der zweiten Messung (60 s).

Bug-Prüfung danach: Selbsttest 20/20, Treiber-Test 73/73, JS-Syntax, statische Namensprüfung
(alle Module: keine undefinierten Namen). Gefunden und behoben: die parallele Leaderboard-
Schleife (v6) brach nach `lb_top·2` Kandidaten ab statt bis zum Ziel „lb_top Konten mit
Position" zu laufen (nach einem Neustart mit leerem Flat-Cache hätte sie < 75 Konten geliefert)
— jetzt lazy in Stücken bis zum Ziel; tote Variable `per_round` entfernt.

## 3gg. hl_viz auf drei Kernen (21.09., Kachel „CPU je Dienst": viz 313 %) — Ursache und Korrektur

Ein Python-Prozess kann mit Python-Code kaum mehr als einen Kern auslasten (GIL); 313 % heißt:
SQLite in parallelen Threads. Ursache im Code: der **Ereignis-Auslöser** der Prognose (30-s-Thread)
feuerte bei JEDEM Wal-/Leaderboard-Ereignis mit 120 s Mindestabstand — seit die Leaderboard-
Stände alle 2 min kommen, gab es alle 2 min eines: sechs volle Prognosen je 2 min statt je 15.
Multipliziert mit den seit 14.09. schweren Prognosen: Liquidationsdruck holte 30 Tage Rohzeilen
aus drei Tabellen (Bybit-Stream: tausende je Stunde), und die Varianz-Kompression löschte je
Coin den Cache ALLER Coins (`_VAR_CACHE.clear()`) — jede Prognose rechnete 259k bars10-Zeilen neu.

**Korrekturen:** Auslöser nur bei Ereignissen ≥ 1 Mio USD (delta_usd) und Mindestabstand
5 min je Coin; Varianz-Cache je Coin; Liquidationsdruck als SQL-Stundensummen (GROUP BY) statt
Rohzeilen (720 Zeilen statt hunderttausenden). Dazu `/debug/threads` (Stack jedes Threads) und
der Debug-Eintrag „Dashboard-Threads" (drei Proben über 10 s, häufigste Stellen) — damit die
nächste Last in Sekunden benannt ist. Erwartung: viz < 60 % eines Kerns.

## 3hh. Elite leer im Dashboard, zehn Konten im Werkzeug (21.09.) — der fehlende t-Wert

`check_elite` fand zehn Konten mit n ≥ 11, Vorlauf > 0, t 1,0–3,5; das Dashboard meldete
„Elite leer". Ursache: Die Elite-Regel liest `t_4h`, aber der Lernzyklus reichte nur
score/comps/klasse/n/alpha_4h weiter (kompakter Stand), und `load_scores` las den Wert nicht
aus der `payload`-Spalte — `t_4h` war im Dashboard immer None → jedes Konto ausgeschlossen.
Folge zweiter Ordnung: Ohne Elite wurde keine Liste nach forecasts.db geschrieben, der Elite-
Kanal des Pollers blieb leer (ein Konto 22 h veraltet, „WEICHT AB"). **Korrektur:** `t_4h` im
kompakten Stand und in `load_scores` (aus `payload`); Probe: gespeichert, geladen, Elite = das
Konto mit t 2,4, nicht das mit 0,4. Nach dem Einspielen erscheint die Elite mit dem nächsten
Lernzyklus (≤ 15 min), der Poller-Kanal füllt sich mit dem nächsten Tageslauf.

## 3ii. Gewinn-Schranke für die Elite und Logikprüfung des Scores (21.09.)

Befund des Nutzers: BTC steigt seit vier Wochen, die Elite ist 202 Mio short. Ursache: Der
4-h-Vorlauf ist driftbereinigt — Richtung × (Rendite − Drift). Ein Long bekommt für den Anstieg
keinen Punkt (er muss die Drift schlagen); ein Konto, das in Spitzen verkauft, hat positiven
Vorlauf, weil der Kurs nach Spitzen kurz unter der Drift bleibt — und liegt mit seinem Short
trotzdem tief im Minus. Entscheidung: Das 4-h-Timing bleibt (erkennt, wer vor Korrekturen
verkauft und vor Anstiegen kauft), aber **Timing ohne Gewinn ist keine Elite**.

**Gewinn-Schranke** `hl_score.gewinn_filter(con, coin, addrs)`: (1) Leaderboard-Gewinn 30 T
(`lb_stats.pnl_30d`), falls vorhanden, muss > 0 sein; (2) gehaltene Position im Coin
(jüngster Leaderboard-Stand, sonst jüngstes Poller-Ereignis inkl. `snap`) höchstens 3 % unter
Wasser (`upnl / pos_value ≥ −ELITE_MAX_VERLUST`). `elite(..., gewinn=…)` schließt Verlierer aus;
Lernzyklus wendet sie an, `check_elite` zeigt uPnL % und PnL30 je Konto und nennt Ausgeschlossene.
Probe: Short 9 % unter Wasser raus, Leaderboard-Verlierer raus, Long +6 % bleibt.

**Logikprüfung des Scores, weiterer Fund:** Die Folgerendite eines Stundenblocks begann beim
ERSTEN Schritt der Stunde, obwohl die Nettorichtung erst durch spätere Schritte entstand — bis
zu 59 min Kurs vor dem entscheidenden Schritt zählten mit (milde Rückschau). Jetzt beginnt das
Fenster beim LETZTEN Schritt der Stunde (konservativ, rückschaufrei). Geprüft und in Ordnung:
Vorzeichen des Vorlaufs, Ausschluss der `snap`-Ereignisse, neutrale Ränge (0,5) für fehlende
Leaderboard-Kennzahlen, Frische der `upnl` über die 10-min-Snap-Zeilen. Bekannte Grenze:
`pnl_30d` ist kontoweit, nicht je Coin.

## 3jj. Audit der Bewertungslogik und Stufe 1 (21.09.)

Audit ohne Änderung (Ergebnis in `PROPOSAL_Kalibrierung_Stufe2_3.md`, Abschnitt 1.3): zwei
Fehler (F1 Regularisierung zum Prior — das „Killkriterium" existiert nicht; F2 Nenner von P(auf)
konstant), drei Schwächen (korrelierte Treiber addiert, keine Inversion, Bilanz in-sample ohne
Basisrate). Entscheidung des Nutzers: stufenweise.

**Stufe 1 umgesetzt (keine Lernwirkung, gelernte Gewichte unverändert):**
- Nenner je Fall = Σ Priors der aktiven Treiber — in `calibrate_weights` (S_case) und in
  `compute_forecast` (P(auf), P(auf, 24 h)) gleich; bei allen 30 aktiv identisch mit vorher.
- Ereignis-Signal: `score ← score + 0,5·(sign − score)` statt ×1,5 (0,6 → 0,8; monoton, kein
  Clipping-Verlust).
- `AKTIV_SCHWELLE` 0,05 statt 0,1 für die Treiberbilanz.
- Nulltest grün, Treiber-Test 73/73 (Ereignis-Erwartungen angepasst), PDFs aktualisiert.

**Stufe 2 und 3:** Proposal für externes Audit in `PROPOSAL_Kalibrierung_Stufe2_3.md` —
Null-Regularisierung mit Prior als Startwert, Klemmung [−prior, 2·prior], OOS-Wächter,
Schrittbegrenzung; Familien-Ensemble (8 Familien, zwei Lernebenen), Lift-Bilanz gegen die
Basisrate, OOS je Treiber; Validierung (erweiterter Nulltest, Positivtests, walk-forward auf
`forecast_slim`), Rollback je Stufe, fünf offene Fragen.

## 3kk. Auditbericht v9 (21.09.) — Stufe 1 als Hybrid, E/F, Historie, Version (22.09.)

Der Bericht prüfte den Pi-Stand (vor Stufe 1) und das Proposal. Kernbefund: **F2 war kein Fehler** —
der Logit ist eine Evidenzsumme, ein fehlender Treiber ein Beleg mit Bayes-Faktor 1; mein Nenner je
Fall blähte den Logit bei zwei aktiven Treibern um das 11-fache auf (Simulation: schlechterer Brier
in den Randfällen). Zurückgenommen. Die beiden kleinen Stufe-1-Punkte bestätigt der Bericht.

Umgesetzt (Paket 2026-09-22.1):
- **Hybrid Stufe 1:** Nenner konstant; Ereignis-Faktor monoton (`+0,5·(sign−score)`); AKTIV_SCHWELLE 0,05.
- **E Lift-Bilanz** je Treiber: Trefferquote minus Zufalls-Erwartung aus den Randverteilungen der
  eigenen Fälle, z gegen SE der Differenz (kein Wilson). Probe: Trendfolger 78 %/Lift 0; Kante
  69 %/Lift +13 pp z 2,1. **F OOS je Treiber** ab 25 Blöcken (wver der Prognose). Beides in
  `learned cal_stats_<h>`, Anzeige in der Treibertabelle.
- **weights_hist:** jede Gewichtsversion bleibt (Rollback existierte nicht — weights_h wird überschrieben).
- **version.py + Kachel „Version"** (Version · Prüfsumme der Projektdateien) — Abgleich Paket ↔ Pi.
- Proposal Revision 2 (`PROPOSAL_Kalibrierung_Stufe2_3.md`): λ = max(0,5/n_eff, 0,005) in u,
  Warm-Start mit Reset-Marke, Toleranz-Labels im Training (bestätigt: `label = close > p0` ohne
  Toleranz), Inversionsschwelle, OOS-Wächter n ≥ 100 / 2 SE, Familien mit konstanten Nennern und nur
  v_k lernen, Rückschau auf `forecast_drivers` nach 6–8 Wochen, drei neue offene Fragen.

## 3aaa. „Aktive Profis" Phase 2 + 3 (23.09., Version 2026-09-23.1)

`hl_profis.py`: Qualifikation über 7 Tage — nicht gesperrt, 5–150 gebündelte Trades/Tag **in den
verfolgten Coins** (pool_fills_hourly), Gewinn 7 T > 0 (HL pnl_7d, einzahlungsbereinigt), **Exit-Lift**
> 0 mit t ≥ 1 (Ausstiege = reduce/close aus whale_positions/lb_events; Korrektur ≥ 2 % binnen 12 h gegen
die aufgegebene Richtung, minus Placebo aus 200 Zufallszeitpunkten desselben Fensters; n_eff über 12-h-
Blöcke; mind. 5 Ausstiege). Anzeige: Entry-Lift, Bot-Marke (über 7 Tage nie > 4 h ohne Trade, ab 5 Tagen
Daten), Reaktionszeit (Median Minuten von ≥ 1 %/15 min bis zum nächsten Trade), bester Coin (closedPnl,
sonst Umsatz). **Rang vorerst HL roi_1d** (bis U5 closedPnl liefert; Feld `rang_basis`), eingefroren
alle 12 h (00/12 UTC), Kennzahlen stündlich. Nulltest: 40 Rauschkonten Lift −0,8 pp; Positivtest +78 pp,
t 21 — Selbsttest-Schritt 21. `check_profis.py --alle` (Debug „★ Aktive Profis, Phase 2") zeigt Top 20
und alle Ausschlussgründe. Dashboard: Abschnitt 10 = Karten der Qualifizierten mit den letzten 5
gebündelten Trades (Zeit, Coin/Spot, Richtung, Betrag, Kurs, „seither", real. PnL), darunter die Pool-
Vorschau. Endpunkt `/profis` (Hintergrund-Thread, 90 s nach Start, dann stündlich). Probe: Alpha
(aktiv, Exits vor Rückgängen) qualifiziert; Halter (1 Trade/T) und Bot (Lift ≈ 0) nicht; Gesperrte raus.

## 3bbb. U5 Pool-Fills und eigener 12-h-Rang; Variante 2 für den Entry-Lift (23.09., Versionen 23.2/23.3)

23.2: Entry-Lift signifikant negativ (t kleiner/gleich minus 1) disqualifiziert (Nutzer: beide Seiten
wichtig, Variante 2; strenge Variante nach zwei Wochen als U3b). 23.3: Task **Pool-Fills** alle 12 h —
`leaderboard_activity` mit `nur_addrs` (Pool minus Auswahl minus Gesperrte, Rückstand zuerst), festem
Budget min(15.000, 30 je Konto), Rang 3, gleiche Vielhandler-/Cursor-Logik; erster Lauf 10 min nach dem
Start. `hl_profis.roi_12h`: Summe closedPnl der Fills in 12 h plus Delta uPnL (jüngste whale_positions-
Zeile je Coin gegen die Zeile vor 12 h), relativ zum Kontowert; Rang nach eigener 12-h-ROI, sonst HL
roi_1d; Karte zeigt ROI 12 h mit Quelle. Erster echter Lauf 03:16: 692 Pool, 73 aktiv mit Gewinn,
6 qualifiziert (Exit-Lifts +25 bis +66 pp); 568 ohne Trades in unseren Coins, 28 mit signifikant
negativem Exit-Lift (Gewinnmitnehmer in der Rally). Offen notiert: bester Coin bei Leaderboard-Konten aus
REST-Fills aller Coins; Placebo je Coin statt gemittelt (U5-Feinheit).

## 3ccc. K2-Neubau: Kalibrierung v2 im Schatten (23.09., Version 2026-09-23.4)

`hl_kalib.py` (numpy): p = σ(b + Σ w_j x_j/s_j); s_j = Streuung der vorhandenen Scores (min 0,05);
L2 gegen Prior·max(0, 1−n_eff/200) (Prior als abklingender Ausgangspunkt); λ ∈ {0,003 … 10} per
5 zusammenhängenden Zeitblöcken mit Embargo (Horizont), Zielgröße gewichteter Log-Loss, 1-SE-Regel;
Newton mit Dämpfung, |w| ≤ 4; 90 Tage; Label ohne Toleranzfälle (M7); Kurs nur mit frischer Bar (H4);
eine Prognose je Block, die früheste (M10). Ausgabe je Coin/Horizont in learned `kalib2_<h>`: Gewichte
(Score-Einheiten und standardisiert), Achsenabschnitt, λ-Tabelle, OOF-Quote/Brier/Skill,
Zuverlässigkeitsdiagramm. **Tor (Positivkontrolle, Selbsttest 22):** Kante 0,65 → 63,4 % (Basis 58 %),
0,90 → 86 %, Rauschen bewegt p um 0,6 Punkte — bestanden; v1 zum Vergleich: 50,6 % / 50,8 %.
Integration: Lernzyklus kalibriert v2 stündlich je Horizont; compute_forecast liefert `p_up_v1`,
`p_up_v2`, `p_up_24_v2`, `kalib` (v1/v2) und `kalib2` (Modellstand); score_forecasts bewertet
p_up direkt (Ruf = Vorzeichen p−0,5, Enthaltung < 2 Punkte) für v1 und v2 (`direkt_v1`, `direkt_v2`,
`enthalten_v2`) — H6 damit für die Wahrscheinlichkeit umgesetzt; Kachel „Kalibrierung v2 Schatten/AKTIV";
Schalter `learned('*','kalib2_aktiv')` per Debug „AKTIVIEREN"/„zurück in den Schatten". Plan: U6/U7
erledigt, U7b (Umschalten nach 1–2 Wochen, wenn v2 ≥ v1) neu.

## 3ddd. Konstellationen und Vorbedingungen (23.09., Version 2026-09-23.7) · v1/v2 sichtbar (23.5/23.6)

23.5: Kopfzeile „P(aufwaerts 4 h) — v1 gegen v2"; 23.6: Spalte „Gew. v2" in der Treibertabelle
(v2-Gewicht je Treiber, blau = weicht vom Prior ab, rot = invertiert). 23.7: `hl_konstellation.py`
— (1) Konstellationen: fuer die 15 gewichtigsten Treiber alle Paare; bedingte 4-h-Trefferquote, wenn
beide im selben Block mit |Score| >= 0,3 in dieselbe Richtung zeigen, Wilson auf n_eff (4-h-Bloecke),
Basisrate, Lift, z (Zwei-Anteile-Test), Auswahl-Effekt ausgewiesen (n Pruefungen, beobachtete und
erwartete z >= 2); (2) Vorbedingungen: vor Bewegungen >= 3 % binnen 24 h (Ereignisse zusammengefasst)
je Treiber Anteil „zeigte in die spaetere Richtung" gegen die Basis aller Bloecke, Lift, z, mittlerer
Score. Beides Anzeige (unter der Elite-Tabelle), kein Modellbestandteil; stuendlich im Lernzyklus,
learned `konstellation`. Nulltest (Rauschen: kein |z| >= 3 haeufiger als 5 %) = Selbsttest-Schritt 23;
Probe mit zwei konstruierten 70-%-Treibern: Paar-Quote 90 %, z 3,9. Plan U25 (Stufe 2: Interaktionsterme in v2).
Offen aus dem Gespraech: beim Aktivieren von v2 muss auch der Pfad (Bias) auf v2 umgestellt werden (U7b).

## 3eee. Konstellations-Historie und Stabilitätsliste (23.09., Version 2026-09-23.8)

Frage des Nutzers: Vorzeichen (ja — auf- und abwärts getrennte Prüfungen mit eigenen Schwellen und
Basisraten) und Speicherung fürs Lernen. Neu: Tabelle `konstellation_hist` (je Coin und Tag: alle
Paare mit Quote/Basis/Lift/z, Vorbedingungen), `hl_konstellation.stabil()` = Paare mit z ≥ 2 und
positivem Lift an ≥ 14 Tagen — die Kandidatenliste für Interaktionsterme in v2 (U25 Stufe 2);
Anzeige über der Konstellationstabelle („Über Wochen stabil …" bzw. „aufgezeichnet seit n Tagen").
Paketname wieder `hl_liq_project.zip` (Update-System), Regel im Plan festgehalten.

## 3fff. v2 blieb stumm: MIN_FAELLE 60 -> 30, Zustand sichtbar (23.09., Version 2026-09-23.9)

Auf dem Pi zeigte v2 nach Stunden "noch nicht kalibriert": `hl_kalib.kalibrieren` verlangte 60 Faelle
(eine Prognose je 4-h-Block, Toleranzfaelle ausgelassen) und speicherte bei weniger NICHTS -- die Anzeige
konnte den Grund nicht nennen. Jetzt MIN_FAELLE 30 (der abklingende Prior traegt kleine n), der Zustand
"zu wenige Faelle: n von 30 (Bloecke, unter Toleranz)" wird gespeichert und in Kopfzeile und Kachel
gezeigt; Fehler des Lernzyklus (`kalib2_fehler`) ebenfalls. Gemeldet und offen (U26): Leaderboard-Flow
"0 Konten in 60 min" um 11:20 -- Pruefung mit dem Leaderboard-Werkzeug ausstehend.

## 3ggg. Gegen-/Smart-Flow-Gründe, U26 geklärt, Projektübergabe (23.09., Version 2026-09-23.10)

U26 (Leaderboard-Flow „0 Konten in 60 min"): kein Fehler — Leaderboard-Diagnose zeigt in 6 h nur zwei
BTC-Größenänderungen unter den Top-75, davon eine über der Schwelle mit Ereignis; nur 6 der 75 halten BTC.
Gegen-Flow und Smart-Flow haben jetzt echte Inaktiv-Gründe (INAKTIV_GRUND). Vorschlag U27: Flow-Treiber
auf Basis der qualifizierten Profis (Nulltest-Pflicht), Entscheidung nach zwei Wochen Profis-Daten.
**Projektübergabe für Opus 5.5:** `PROJEKTUEBERGABE_OPUS55_23-09-2026.md` (System, Regeln, Arbeitsweise in
der Sandbox, Stand, Schwächen, erste Schritte); Autorenvermerke angepasst.

## 3hhh. Abschnitt A in der Sandbox, NameError im Liquidations-Pfad, Prüfsumme mit Werkzeugen (23.09., Version 2026-09-23.11, Opus 5.5)

Sitzungsbeginn mit Opus 5.5 nach `PROJEKTUEBERGABE_OPUS55_23-09-2026.md`. Abschnitt A, Sandbox-Teil: Paket 23.10 ·
5b25f96685 unverändert, Selbsttest 23/23, Nulltest v1 grün (Positivkontrolle v1 „NICHT LERNFÄHIG", 0,65 → 50,6 %),
v2-Tor bestanden (0,65 → 62,0 %), JS ok. **Fund der Namensprüfung (U28):** `on_user_event` rief im tid-Rückfall
`hashlib.blake2b` auf (Audit-Korrektur N5 vom 22.18), `hashlib` war im Modul aber nur lokal in `infer_liquidations`
importiert → NameError bei einem Liquidations-Fill ohne tid; die Ausnahme verlässt `run_ws` und erzwingt einen
WS-Neuaufbau (Liquidation verloren, alle Feeds kurz weg). Korrektur: Import auf Modulebene. **Prüfsumme:** umfasst
jetzt auch die 18 Werkzeuge (check_*, db_size, make_treiber_pdf*) — vorher erkannte A1 ein veraltetes Werkzeug auf
dem Pi nicht, obwohl `check_treiber` Selbsttest-Schritt ist. **Plan korrigiert:** A4 heißt „Rundum-Funktionstest aller
Quellen" (check_sources, Soll FEHL 0), nicht der 23-Schritte-Selbsttest; neu A7 (Selbsttest vor jeder Lieferung).
**Neu U29:** OOF-Brier-Skill von v2 auf Rauschen negativ verzerrt (−0,034 über 12 Seeds; Referenz = Klimatologie der
ganzen Stichprobe) — vor U7b korrigieren. Pi-Teil von Abschnitt A steht aus.

## 3iii. Abschnitt A auf dem Pi; Schreibsperre beim Start; Coinbase-Seite als Messung; Beleg je Sperre (23.09., Version 2026-09-23.12, Opus 5.5)

Pi auf 23.11 (12:16–12:25): A1 Version gleich, A2 keine Aufgabe mit Fehler, A3 1.082/min (100 % des Deckels,
0 × 429), A4 FEHL 0 in allen Quellen, A5 v1 NICHT LERNFÄHIG / v2 Tor bestanden (0,65 → 63,7 %). Drei Funde aus den
Ausgaben:

**(1) U32:** Der Netzwerkstatus zeigte eine Schreibsperre von 48,9 s mit der ersten Anweisung „INSERT OR IGNORE INTO
addresses (addr, first_seen, last_trade)“ — die einzige Stelle ist `pool_laden`. Sie fügte ohne Commit ein; beim
Start blieb die Transaktion (und die Sperre aller Dienste) über Symbolauflösung und ersten Leaderboard-Zyklus offen.
Jetzt `executemany` + Commit. Probe: vorher Transaktion offen und 0 Adressen für andere sichtbar, nachher geschlossen,
600 sichtbar.

**(2) A4 prüfte Coinbase am falschen Kanal:** Der Dienst liest seit 22.18 `matches`, der Test den `ticker`, und
„side = MAKER-Seite“ war eine feste Ausgabe, keine Messung. Jetzt prüft A4 `matches` und misst die Seite (Tick-Regel:
Aufwärts-Tick ⇒ Maker „sell“; Vergleich ticker/matches je trade_id). Probe P1 (U2) läuft damit bei jedem A4;
synthetisch geprüft (Maker-Fall ok, 92 %; invertierter Fall fehl, 8 %). Dazu `last_match` im Dienst übergangen (U33).

**(3) A6 — 30 Gesperrte,** 19 neu seit 23.09. 02:02, fast alle 2.007–2.492 Fills. Seit M1 (22.18) zählt die Regel
ALLE Fills rollierend statt Fills ab 2.500 USD je UTC-Tag; die Grenze 2.000 ist damit faktisch gesenkt, und Fills sind
Ausführungen, keine Entscheidungen. `check_sperre` zeigt jetzt je Sperre die gebündelten Trades der 24 h davor
(Maschinen- oder Trader-Muster); Entscheidung U31 beim Nutzer. Probe P2 (U1) steht jetzt im VOLLBERICHT.

## 3jjj. Masterregel auf gebündelte Trades (23.09., Version 2026-09-23.13, Opus 5.5, Entscheidung Nutzer)

**Anlass:** A6 zeigte 19 Sperren binnen zehn Stunden knapp über 2.000 Fills. Die Umstellung M1 (22.18) zählt ALLE
Fills rollierend statt Fills ab 2.500 USD je UTC-Tag; die Grenze war damit faktisch gesenkt. Fills sind Ausführungen,
keine Entscheidungen.

**Entscheidung des Nutzers:** Option (a) — mehr als **300 gebündelte Trades (je Coin, Minute und Richtung) in 24 h**,
dieselbe Einheit wie die Aktivitätsschranke der Elite.

**Umsetzung:**
- Stream: je Konto und Stunde eine Menge (Coin, Minute·2 + Käufer); der Käufer ist `users[0]`.
- Persistierung in `fill_zaehler_h.n_trades` mit MAX: Die Mengen der laufenden und der vorigen Stunde bleiben im
  Speicher, keine Doppelzählung an Laufgrenzen.
- Zweite Quelle: `lb_fills` (alle Coins der Leaderboard-Konten, gespeicherte Fills); es gilt das Maximum.
- `konto_status.trades_tag` neu.
- **Einmalige Neubewertung** der alten Fills-Sperren (`sperre_neubewertung`), sobald 24 volle Stunden Zählung
  vorliegen: ≤ 300 → Status `frei` (neuer und alter Grund im Protokoll), > 300 → bleibt mit Beleg. Manuelle Sperren
  bleiben unberührt; Ergebnis in `meta.masterregel_neubewertung`.
- `check_sperre` neu: Zählung, Neubewertung, Freigegebene, Beleg der alten Sperren, „nahe der Grenze“ nach Trades.
- Texte in Dashboard, README und Projektübergabe (Regel 5) angepasst.

**Probe:** Maschine (400 Minuten mit Trades) gesperrt; Trader (2.500 Fills in 50 Minuten) nicht; zweiter Lauf in einer
schon gezählten Minute zählt nicht doppelt (50 Trades, 2.501 Fills); Neubewertung: 40 Trades → frei, 500 → bleibt,
einmalig; Migration einer 23.12-Datenbank ergänzt `n_trades` und `trades_tag`.

**Nebenfund U34:** Der Selbsttest von 23.13 fiel in zwei UNVERÄNDERTEN Modulen durch (Positivkontrolle v2 59,6 %,
Konstellations-Nulltest +7,2 pp). Ursache: Beide bauten ihr synthetisches Szenario an `time.time()`. Gemessen über
24 Viertelstunden fiel jedes Tor 5-mal durch (p_up bei Kante 0,65 zwischen 56,8 und 65,7 %). Jetzt fester Zeitpunkt
(`PROBE_NOW`) und Tor über fünf feste Szenarien: v2 im Mittel 60,7 % (knapp, siehe U35), Konstellation gepoolt
+2,5 pp; identische Ausgabe zu jeder Uhrzeit.

## 3kkk. Nachlauf zu A (13:25): Sperre über die Poll-Runde, Pool-Fills nach Neustart, Lückenbeginn (23.09., Version 2026-09-23.14, Opus 5.5)

Aus Netzwerkstatus und VOLLBERICHT 13:25 (Pi auf 23.13). **U1 erledigt:** 0 beobachtete Konten, 35 abgeleitete Liquidationen
von 33 Konten. **U32 wirkt:** Der längste Halter der Schreibsperre ist 11,8 s statt 48,9 s.

**U37:** Die verbleibenden 76 Halter über 1 s trugen alle die Anweisung „UPDATE addresses SET last_poll=?, notional=0 …“.
`poll_address` schrieb, wenn eine Adresse keine Position mehr hatte, sofort — mitten in der Poll-Runde; die Sperre aller
Dienste blieb bis `flush_round` über die übrigen Netzaufrufe offen. Die anderen Pfade puffern seit 14.09.; dieser war
übersehen. Jetzt gepuffert (`addr_null_pending`), `flush_round` schreibt beide Stände, je Adresse gewinnt der jüngste.
Probe: 23.13 hielt nach `poll_address` eine offene Transaktion, 23.14 nicht.

**U40:** Pool-Fills lief 10 min nach JEDEM Start und verdrängte den Nachtrag der Auswahl (Median 33 min). Jetzt startet der
Lauf 12 h nach dem letzten (in `meta` gespeichert). Der VOLLBERICHT trennt den Abholstand: Auswahl (Takt 15 min) und
Pool (Takt 12 h); gemischt stand dort „Median 7,9 h, AUFHOLEN LÄUFT“.

**U39:** Übersprungene Zeiträume begannen bei neuen Konten bei 0 (Bericht: Lücken ab 01.01.1970); jetzt beim jüngsten
geholten Fill.

**Offen U38:** Der Begrenzer kann nach Ruhephasen bis 1.476 Gewicht in 60 s abgeben (Deckel 1.080 + Eimer 180 +
Reserve 216). Gemessen wurden 1.143, 429 gab es keine.

**U31, Stand:** Um 13:22 sperrte die neue Regel drei Konten (365–398 gebündelte Trades). Die Neubewertung der alten Sperren
folgt am 24.09. gegen 13:00.

## 3lll. Coinbase-Seite gemessen, vertauschter Spot-Taker-Flow korrigiert (23.09., Version 2026-09-23.15, Opus 5.5)

**U2 erledigt.** Rundum-Funktionstest 13:56:
- `matches.side` ist die Maker-Seite (Tick-Regel 38 von 41, 93 %) — die Umkehr im Dienst ist richtig.
- `ticker.side` ist die TAKER-Seite (0 von 99 gemeinsamen Trades gleich). Damit ist Audit-H2 bestätigt: Bis zur
  Umstellung auf `matches` (22.18/22.19, auf dem Pi vor 02:43 am 23.09.) war der Spot-Taker-Flow vertauscht, seit dem
  Start des Coinbase-Dienstes.

**U41 (Entscheidung Nutzer: ja):**
- Der Umstellzeitpunkt steht nirgends. Der Coinbase-Dienst bestimmt ihn beim Start aus `cb_bars`: Mit richtigen Seiten
  haben Kursänderung und Netto-Taker-Flow einer Minute meist dasselbe Vorzeichen, vertauscht meist das entgegengesetzte.
  Der beste Schnitt (Präfixsummen, auf die Minute) landet in `cb_meta` 'seite_umstellung' mit dem Status gefunden,
  keine oder unklar; nur bei „gefunden“ wird korrigiert.
- Davor tauscht `load_coinbase` buy/sell beim Lesen; das betrifft Flow-Fenster und die Z-Referenz über 7 Tage.
- Die gespeicherten Scores des Treibers „Spot-Taker-Flow“ vor dem Schnitt fallen aus v1-Kalibrierung und -Bilanz, dem
  v2-Training und den Konstellationen heraus (`F.cb_seite_ab`, `F.CB_TREIBER`). Nichts wird umgeschrieben; das ist
  umkehrbar durch Löschen des Eintrags in `cb_meta`.
- Debug-Eintrag „Coinbase: Seiten-Umstellung (U41)“ zeigt den Zeitpunkt und den Gleichlauf je Stunde um den Schnitt.

**Probe (synthetisch, 5 Coins, 10 Tage):**
- Schnitt 1 min neben dem wahren, Gleichlauf vorher 0,22, nachher 0,79.
- Nie vertauscht → keine; Flow ohne Kurswirkung → unklar.
- Z-Wert gleich dem wahren (−0,257).
- Fälle des Treibers in v1, v2 und Konstellationen nur noch nach dem Schnitt (122 von 940 Fenstern).

**Für jeden künftigen Leser von `cb_bars.buy_usd/sell_usd`:** Nur zusammen mit `cb_seite_ab` lesen (Hinweis im Schema
von `hl_coinbase.py`).

## 3mmm. Bestätigungen auf dem Pi (23.09., 14:17–14:47, Version 2026-09-23.15, nur Dokumente)

**U41:** Debug „Coinbase: Seiten-Umstellung“ 14:17: Schnitt 22.09. 22:27 (22.18 am Abend eingespielt). Der Gleichlauf von
Kursänderung und Netto-Flow lag vorher bei 0,356 (57.866 Minuten), nachher bei 0,63 (3.869 Minuten). Das ist ein
Spiegelbild, also eine reine Vertauschung. Je Stunde 29–38 % → 57–67 %; die Stunde des Schnitts liegt bei 48 % (27 min
vertauscht, 33 min richtig). Frage des Nutzers dazu geklärt: „Taker-Flow“ (Perp-Verhältnisse Binance/Bybit/OKX/Crypto.com)
ist ein anderer Treiber als „Spot-Taker-Flow“ (Coinbase) und vom Fehler nicht betroffen.

**U37:** Netzwerkstatus 14:47, 34 min nach dem Start: Sperr-Halter im Mittel 11 ms statt 234 ms, 3-mal über 1 s statt
76-mal, längster 4,2 s (wal_checkpoint). Binance wartet im Mittel 0,2 ms statt 108 ms.

**U40:** Der Pool-Lauf von 23.14 brach beim Einspielen von 23.15 ab, deshalb lief er nach dem Start noch einmal (528 s);
jetzt ist er gespeichert. Der Beleg folgt beim nächsten Start: Die Zeile „Pool-Fills“ muss „nächster Lauf in … h“
zeigen.

**Neu U42 (kosmetisch):** Die Live-Zeilen Bybit, OKX und Crypto.com zeigen „erwartet unter 60 s“, werden aber nur beim
Chart-Abruf geholt.

## 3nnn. U8: Bilanz der Kauf- und Verkaufsempfehlungen (23.09., Version 2026-09-23.16, Opus 5.5)

Die Empfehlungen „Optimaler Kaufpreis / Verkaufspreis (4–12 h)“ wurden seit Wochen ausgegeben, aber nie bewertet
(Audit v10 H10). `hl_forecast.empfehlungen_bilanz` bewertet sie aus den gespeicherten Prognosen (60 Tage) und den
1-min-Kerzen.

**Fälle:** Je Coin und UTC-Tag die erste Empfehlung. Die Ergebnisse überlappen dadurch nicht, und n ist die Zahl
unabhängiger Fälle je Coin; die Coins sind untereinander korreliert.

**Ausführung:** Das Limit liegt ab der Prognose 12 h. Es gilt als gefüllt, sobald ein Minutentief (Kauf) bzw. ein
Minutenhoch (Verkauf) den Preis erreicht. Liegt das Limit schon jenseits des Kurses, zählt es als Market-Order zu p0 mit
Taker-Gebühr.

**Bewertung aller Varianten 24 h nach der Prognose** (Schlusskurs höchstens 2 min alt, sonst „ohne Kurs“):
- Kauf, Ausgangslage Geld: Limit (gefüllt: Schluss/Limit − 1 − Maker − Taker, sonst 0) gegen Markt (Schluss/p0 − 1 − 2 ×
  Taker) und nie (0).
- Verkauf, Ausgangslage eine gehaltene Long-Einheit: Limit (gefüllt: Limit/p0 − 1 − Maker, sonst weiter gehalten) gegen
  sofort (−Taker) und halten (Schluss/p0 − 1).
- „nach Füllung 4 h“ misst die adverse Auswahl.
- Gebühren: Maker 0,015 %, Taker 0,045 % (HL-Basisstufe, Konstanten in `hl_forecast`). Funding bleibt außen vor.

**Anzeige:**
- Kachel „Bilanz der Empfehlungen“ neben Kauf-/Verkaufspreis, für alle Coins, stündlich gerechnet (`learned` „*“/„empf“).
  Farbe: grün, wenn Limit − Markt mit 95 % positiv ist, rot, wenn negativ, gelb, wenn offen.
- Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“: Tabelle je Coin, dazu advised ja/nein für alle Coins.

**Prüfung:**
- Nulltest-Zeile „Empfehlungs-Bilanz auf Rauschen (U8)“ mit festem Zeitpunkt und Seed:
  - Rechenweg exakt gegen Handrechnung (7 Werte; Kauf-Limit +1,9602 %, Markt +0,91 %, Verkaufs-Limit +0,485 %, halten
    +1,0 %, sofort −0,045 %, nach Füllung +2,0202 % / −0,495 %).
  - Martingal-Soll auf einem Random Walk über 118 Tage: Markt −2 Taker, Limit-Kauf −(Maker + Taker) × Füllquote,
    halten 0, Limit-Verkauf −Maker × Füllquote, nach Füllung 0, Grenze 4 SE.
- Mutationsprobe: Verkauf ohne Limitpreis, Vorzeichenfehler nach der Füllung und Füllung am Hoch statt Tief fallen
  durch.
- Sandbox-Probe mit Hand-Szenario: 2 BTC-Tage, ETH marktfähig, ZEC ohne Kurs — alle Werte exakt.

**U42:** Die Live-Zeilen Bybit, OKX und Crypto.com zeigen „erwartet: beim Chart-Abruf“.

## 3ooo. Pool-Fills-Zeitpunkt beim Start (U40b) und erste U8-Zahlen (23.09., Version 2026-09-23.17, Opus 5.5)

**U40b.** Um 16:13, nach dem Start von 23.16, lief Pool-Fills trotz U40 erneut („läuft: 10/542 Konten, 384 Gewicht
bisher“). Ursache: Ein Pool-Lauf dauert bei vollem Budget rund 2 h (Rang 3, bis 15.000 Gewicht). Die in 3kkk/3mmm
genannten „528 s / 644 s“ waren Fortschrittsmeldungen laufender Läufe, keine fertigen — die Annahme „~11 min“ war
falsch. Jedes Update am 23.09. brach den Lauf ab, bevor U40 den Zeitpunkt am Ende schrieb; also begann jeder Neustart
von vorn. Jetzt wird der Zeitpunkt beim Start geschrieben. Ein abgebrochener Lauf setzt im nächsten 12-h-Takt fort; die
Reihenfolge richtet sich nach dem Rückstand, und der Abholstand je Konto bleibt erhalten. Die Warteanzeige zeigt als
„zuletzt“ den Start des letzten Laufs und als „nächste“ den echten Termin (vorher: Zeitpunkt der Meldung und +12 h).

**U8, erste Zahlen vom Pi (16:12, 70 Fälle je Seite aus 12 Tagen × 6 Coins):**
- Kauf: Limit +1,27 % gegen Markt +1,31 % (Differenz −0,04 %, 95 % −0,33 … +0,25), gefüllt 86 %.
- Verkauf: Limit ±0,00 % gegen sofort −0,04 % und halten +1,40 %, gefüllt 70 %.
- Der steigende Markt bestimmt alles. Ein Vorteil der Limits ist insgesamt nicht messbar.
- Je Coin liegen XMR, ZEC (Kauf) und PAXG (Verkauf) über dem Markt, bei 12 Vergleichen mit je n = 12 aber vorsichtig
  zu lesen.
- Alle Fälle sind „advised ja“.
- Neu W7: wöchentlich lesen.

## 3ppp. Fingerabdruck Stufe 1: Ereignis-Profile (U43) (23.09., Version 2026-09-23.18, Opus 5.5)

Anlass: der Rutsch am 23.09. gegen 16:15. Die Idee des Nutzers ist ein Fingerabdruck der Zeit vor Rutschen und
Anstiegen. Der Vorschlag hat drei Stufen (Profile → sparsames Modell → Analog-Suche über Treiberverläufe); gebaut ist
Stufe 1.

**Ereignis:** Die Rendite der nächsten 4 h beträgt mindestens 2 σ. σ ist die 4-h-Schwankung aus den 7 Tagen davor,
aus 15-min-Schlusskursen. Aufeinanderfolgende Startpunkte derselben Richtung (Abstand ≤ 4 h) bilden ein Ereignis.

**Beginn:** Im ersten dieser Fenster der letzte 15-min-Punkt, bevor sich der Kurs um 0,5 σ in Ereignisrichtung bewegt
hat. Ohne diese Schärfung läge der Beginn bis zu 2 h vor der Bewegung, und ein 3-h-Vorläufer erschiene in der Probe nur
mit −1 h. Gleichgerichtete Ereignisse mehrerer Coins binnen 2 h zählen als ein Fall.

**Profil:**
- Je Treiber und Vorlauf (−12, −8, −6, −4, −3, −2, −1, 0 h) die Abweichung vom Normalwert desselben Coins in Zeiten
  gleicher Schwankung (Terzile von σ, ohne die Fenster um Ereignisse).
- Gemittelt über die Coins eines Falls, dann über die Fälle; z = Mittel / SE.
- Treiberwerte stammen aus `forecast_drivers` (alle 15 min, nicht gelöscht) und werden dem nächsten Rasterpunkt
  zugeordnet, sodass kein Blick in die Zukunft entsteht. Spot-Taker-Flow vor der Seiten-Umstellung bleibt außen vor
  (U41).

**Schwelle:** 95 % des größten |z| über alle Treiber × Vorläufe aus 200 Läufen mit je Coin zirkulär verschobenen
Ereigniszeiten. Das begrenzt Zufallsfunde über die ganze Tabelle (Familienfehler 5 % je Richtung) und berücksichtigt
die Autokorrelation. Als „Vorlauf“ gilt der zusammenhängende Abschnitt über der Schwelle, der dem Beginn am nächsten
liegt.

**Ausgabe:** Debug „★ Ereignis-Profile (U43)“ mit den letzten 12 Fällen je Richtung und der Kurszeile (Rendite seit
−12 h in σ, „danach“ = Bewegung über 4 h).

**Selbsttest (Nulltest Konstellationen):** 3 Coins, 40 Tage, eingebaute 4-σ-Sprünge und ein Vorläufer (±0,6 in den
3 h davor) neben Rauschtreibern.
- Soll: Vorläufer in beiden Richtungen erkannt, Rauschtreiber zusammen höchstens ein Zufallsfund.
- 15 von 15 Seeds bestanden; der Vorläufer wurde mit −3 … 0 h bzw. −3 … −1 h erkannt.
- Zufallsfunde traten bei 3 von 15 Seeds auf (erwartet etwa 10 %).

**Stand der Daten:** Die Treiberwerte reichen bis etwa 11.09. zurück, die Schwelle ist bei wenigen Fällen hoch. Leere
Markierungen heißen deshalb zunächst: noch nicht belegbar.

**Stufe 2** folgt ab etwa 30 Fällen je Richtung (W8 wöchentlich).

## 3qqq. Verlauf der Treiber unter dem Kurs (U44) (23.09., Version 2026-09-23.19, Opus 5.5)

Frage des Nutzers: Ist ein Trend oder ein Anbahnungs-Wert irgendwo sichtbar? Antwort: Einen Live-Wert gibt es bewusst
erst mit U43 Stufe 2. Sichtbar waren bisher nur Bias und P(up) sowie die Treiber-Pfeile (Änderung gegen die vorige
Prognose, 15 min). Neu ist ein beschreibender Verlauf.

**Anzeige:** Die Tafel `#verlauf` unter dem Prognose-Chart ist ein SVG mit festem Seitenverhältnis, das mit der Breite
skaliert.
- Oben der Kurs zur Prognosezeit, unten Bias (weiß, dick) und die gewählten Treiber auf −1 … +1, mit Hilfslinien bei
  ±0,5 und 0. Umschaltbar zwischen 24 und 72 h.
- Ereignisse erscheinen als rote bzw. grüne Bänder vom Beginn bis +4 h, nach derselben Definition wie die
  Ereignis-Profile. Dafür ist die Erkennung jetzt eine gemeinsame Funktion (`_profil_kurse`, `_profil_sigma`,
  `_profil_ereignisse`, `ereignisse_kurs`); die U43-Probe liefert nach dem Umbau dieselben Zahlen, 15 von 15 Seeds.
- Treiber werden per Antippen an- oder abgewählt; vorgewählt sind die 4 mit dem größten Betrag jetzt. Die Auswahl
  bleibt bis zum Coin-Wechsel.

**Daten:** Endpunkt `/verlauf?coin=&h=` (60 s Zwischenspeicher) liest `forecast_slim` und `forecast_drivers` (alle
15 min, nicht gelöscht). Spot-Taker-Flow bleibt vor der Seiten-Umstellung leer (U41). Geladen wird mit der Prognose,
höchstens alle 5 min neu.

**Probe:**
- Synthetisch: 72 h ergeben 288 Punkte, ein eingebauter Rutsch wird exakt zur eingebauten Zeit markiert.
- Tafel im node-Nachbau: SVG mit 5 Linien, 1 Band und 3 Auswahlfeldern; Antippen und der 24-h-Knopf wirken.

## 3rrr. Berichtsplan: Debug-Einträge laufen von selbst (U45) (23.09., Version 2026-09-23.20, Opus 5.5)

Frage des Nutzers: Wäre es nicht einfacher, die Debug-Skripte per Zeitplan aus dem Skript aufzurufen? Entscheidung:
Berichtsplan, nur lokal speichern. Versand per Gmail oder Drive wurde angeboten (Claude kann beides über die
Konnektoren lesen) und abgelehnt.

**Ablauf:**
- `hl_viz.BERICHTSPLAN` enthält Einzeltermine und eine Wochenprüfung (mittwochs 19:00 ab 30.09.).
- Ein Hintergrund-Thread des Dashboards prüft minütlich, 90 s nach dem Start zum ersten Mal. Er startet nicht mit
  `_selftest.db` und lässt sich mit HL_BERICHTE=0 abschalten.
- Jeder Termin läuft einmal; der Stand steht in `berichte/.stand.json`. Verpasste Termine (Dienst aus, Update) werden
  bis 12 h nachgeholt, danach als „verpasst“ vermerkt.
- Die Dateien heißen `berichte/JJJJ-MM-TT_HH-MM_<lauf>.txt` und tragen dieselbe Kopfzeile wie beim Herunterladen. Sie
  werden 365 Tage aufbewahrt.
- Ein Handlauf wartet, solange ein geplanter Bericht läuft, und umgekehrt.

**Anzeige im Debug-Bereich:** Plan mit Stand (offen, erledigt, verpasst), Links je Datei und die Sammeldatei „letzte
24 h / 7 Tage“ (`/berichte/sammel?tage=`). Die Sammeldatei lädt der Nutzer in den Chat hoch.

**Pflege:** Neue Termine trägt Claude mit dem nächsten Paket in BERICHTSPLAN ein.

**Probe:**
- Der Wochentermin gilt erst ab 30.09. und bleibt nach dem Sommerzeit-Ende (25.10.) bei 19:00.
- Jeder Termin läuft einmal statt doppelt; 12 h 16 min zu spät gilt als verpasst.
- Ein echter Lauf (Coinbase-Selbsttest) wird mit Kopfzeile gespeichert.
- `../version.py` wird abgewiesen; Sammeldatei und Tafel funktionieren im node-Nachbau.

## 3sss. Paket Teil A (24.09., Version 2026-09-23.21, Opus 5.5)

**Masterregel (U31):** Die einmalige Neubewertung lief am 24.09. um 13:02.
- 32 alte Sperren geprüft: 14 freigegeben mit 0 bis 207 gebündelten Trades; das sind Händler, die große Aufträge in
  viele Fills zerlegen. 18 bleiben gesperrt mit 369 bis 8.618 Trades.
- Seit 23.13 hat die neue Regel 27 Konten gesperrt.

**Zwei ernste Funde, beide behoben:**
- **U48:** Der Zufallsvergleich der Profis war über Coins und Richtungen gemittelt. Im Trendmarkt bekamen zufällige
  Short-Schließungen dadurch +41 Prozentpunkte bei t = 3,2. Jetzt wird je Coin und Richtung verglichen: −2 Prozentpunkte
  bei t = −0,1. Der Test dazu steckt im Selbsttest (Richtungslogik 9 von 9, Trendfalle).
- **U49:** In `compute_forecast` stand `drivers + inaktiv` vor `inaktiv = []`. Das warf einen UnboundLocalError, den
  `except: pass` verschluckte. Folgen: keine v2-Gewichte in der Tabelle, und `aktiv()` → `p_up_v2` wäre nie
  wirksam geworden.

**Weiter:**
- U47: Mindestfallzahl in den Ereignis-Profilen und begrenzte Lückenfüllung.
- U46: Knopf „Neue Berichte“.
- U50: Debug „Magnet-Varianten, 60 Tage“ mit Horizont bis 48 h.
- U51: Snapshot-Knöpfe entfernt.
- U52: Status-Spalte in der Profi-Vorschau.
- Debug „Kalibrierung v2: Stand je Coin“; im Testmodell erklärt er 97 % als Sigmoid(0,10 + 21 × 0,16). Genau dieses
  Aufaddieren ist der Grund für die Übersicherung von v2.

**Offen:** Teil B (U53) als 23.22, das Speicher-Paket (U54) am 25.09., das Analyse-Paket (U55) vor dem 30.09.
Zurückgestellt sind U56 und U57.

## 3ttt. Teil B1: Darwin-Liste, Timing-Bilanz, Zeitleiste (24.09., Version 2026-09-23.22, Opus 5.5)

**Darwin-Liste Schritt 1**
- Mitglieder ändern sich einmal täglich, bei der ersten Bewertung nach 00 UTC.
- Aufnahme bei Qualifikation. Abstieg erst nach 2 Tagesbewertungen in Folge ohne Qualifikation; dazwischen gilt das
  Konto als „auf Bewährung“.
- Reihenfolge nach der vorsichtigen Untergrenze des Exit-Lifts, also Lift minus Standardfehler.
- Der Stand liegt im Prognosespeicher (`learned` „*“/„darwin“) und übersteht Neustarts.

**Timing-Bilanz je Konto**
- Einstiege und Ausstiege, jeweils Long und Short, mit Trefferzahl und Zufallsquote (gleicher Coin, gleiche Richtung).
- „Zuerst richtig“: neue Methode `Kurs.zuerst`. Wer zuerst ±2 % erreicht; erreichen beide Richtungen die Schwelle in
  derselben Minute, gilt der Fall als offen.
- Tempo-Vorsprung nach 1, 4 und 12 h.
- Alles nur Anzeige. Die Entscheidung über den Hauptmaßstab fällt am 06.10.
- Die Zufallsquoten werden einmal je Bewertung gerechnet und für alle Konten geteilt (`placebo_berechnen`, Cache).

**Trades und Anzeige**
- Je Konto 30 Trades, davon 10 sichtbar. Dazu das Alter jedes Trades und eine gemeinsame Zeitleiste mit 40 Einträgen.
- Die Liste lädt sich im Minutentakt neu, solange sie sichtbar ist.
- Im Berichtsplan steht das Datum nicht mehr doppelt, und die Links sind echte Knöpfe.

**Offen U58 (Teil B2):** Die Echtzeit-Plätze gehen auf die Darwin-Liste; das kommt mit dem Speicher-Paket.

## 3uuu. Echtzeit-Plätze für die Darwin-Liste, Backup-Pfad im Dashboard (24.09., Version 2026-09-23.23, Opus 5.5)

**U58: Echtzeit-Plätze für die Darwin-Liste**
- Der Recorder bestimmt die höchstens 10 userEvents-Abos jetzt aus der Darwin-Liste, bestes Timing zuerst.
- Die Reihenfolge schreibt das Dashboard stündlich in den Prognosespeicher (`learned` „*“/„darwin“, Feld „reihe“). Der
  Recorder liest sie alle 5 min, gesperrte Konten nie.
- Ihre Perp-Fills landen vollständig in `lb_fills`, mit Richtung, closedPnl, Gebühr und tid, und ersetzen die
  geschätzten Stream-Zeilen im selben Zeitraum.
- Die frühere Beobachtung der größten Positionen auf Liquidationen entfällt; sie hatte in 24 h 0 Treffer. Liquidationen
  kommen weiter über die Ableitung.

**U54: Speicherorte**
- Die Datenbank wird nur angezeigt. Der Backup-Pfad lässt sich im Dashboard wählen, über eine Ordnerauswahl auf dem Pi.
- Geprüft werden: erlaubter Ort, anlegbar, beschreibbar, anderes Gerät als die Datenbank, Platz für 2 Generationen,
  dazu ein Hinweis, ob das Medium in fstab steht.
- Die Einstellung steht in `speicherorte.json` im Projektordner. Der Recorder liest sie beim Start und vor jedem
  Backup-Durchgang, prüft alle 10 s auf Änderungen und schreibt meta 'backup_dir'. Ein Neustart ist nicht nötig.
- „Jetzt sichern“ löst ein sofortiges Backup aus. „Alte Backups löschen“ ist erst nach einem erfolgreichen Backup am
  neuen Ort möglich und entfernt nur die bekannten Backup-Dateien.

**Offen U59:** Der Umzug der Datenbank über die Oberfläche braucht einen nicht-interaktiven, privilegierten
`migrate_db`-Lauf.

## 3vvv. Konfluenz: Zone gegen Kaskade, Prämie ohne Punkte, Bilanz (24.09., Version 2026-09-23.24, Opus 5.5)

**Anlass:** Der Nutzer sah „Ziel ≈ 82.114 (Long-Squeeze)“ und zugleich „KAUFZONE bullisches FVG“ darüber.

**Ursache in `computeSignal`:**
- Die Warnungen vom Typ „wait“ (Stops, Cluster, Magnet, Kaskadenprognose) zählten 0 Punkte. Sie schalteten nur die
  Beschriftung auf ABWARTEN.
- Die Zone hing allein am Vorzeichen der Punkte. Kaufpunkte kamen vom MA-Regime (+2 dauerhaft), vom FVG (+1) und von der
  Coinbase-Prämie. Die Prämie ist nach Rutschen durch den gedrückten HL-Perp hoch, der bekannte Mangel aus U56.

**Jetzt:**
- Droht ein Anlauf nach unten, zeigt der Chart keine Kaufzone. Die Zone rückt ans Kaskadenziel des Modells („erst nach
  Abholung“); fehlt dort ein Preis, bleibt sie weg, mit Hinweis. Nach oben gilt dasselbe spiegelbildlich.
- Die Prämie erscheint in der Konfluenz nur noch als Hinweis. Der Prognose-Treiber gleichen Namens ist davon unberührt
  und bleibt bis U56 unverändert.

**Bilanz der Konfluenz (U61):**
- Der Browser meldet sein Ergebnis an `/konfluenz/log`, gespeichert in `konfluenz_log` im Prognosespeicher.
- `hl_forecast.konfluenz_bilanz` wertet Richtung nach 4 und 12 h sowie Zonen (erreicht, gehalten) gegen den Zufall aus.
- Anzeige unter dem Konfluenz-Kasten, als Debug-Eintrag und in der Wochenprüfung.
- Einschränkung: nur Zeiten mit offener Dashboard-Seite.

## 3www. Treiberfamilien im Parallelbetrieb (24.09., Version 2026-09-23.25, Opus 5.5)

Neues Modul `hl_familien.py` mit dem Dashboard-Abschnitt „Treiberfamilien“. Er zeigt Kennzahlenkarte, Chart der
Familienwerte über 72 h, Familien-Prognose und Treiber-Hygiene. Die bisherige Prognose bleibt unberührt.

**Familien und Horizonte**
- 9 Familien, je Coin ausgewertet, jede auf ihrem Horizont: Großkonten-Fluss 4 h, Trend lang 24 h, Momentum kurz 1 h,
  Orderfluss 1 h, Funding 24 h, ETF 24 h, Analog 24 h, Profi-Flow 4 h, Stärke 4 h (große Bewegung ja/nein).

**Bewertung**
- Je Block der Horizontlänge zählt der erste Fall.
- Zufall ist der Anteil steigender Blöcke im selben Zeitraum. Bei der Stärke ist es der Anteil großer Bewegungen
  (Betrag ≥ 1,5 σ).
- Ausgewiesen werden ungesehene Daten (letztes Drittel), Wochen, Ereignisse (Betrag ≥ 0,5) und die Überschneidung mit
  anderen Familien.

**Darwin für Familien**
- Wöchentlich; gut heißt z ≥ 2 über 14 Tage.
- Nach 2 guten Wochen in Folge steigt eine Familie auf und bekommt Gewicht in Höhe ihres Vorsprungs.
- Ohne aufgestiegene Familie gilt die Basisrate.

**Hygiene je Treiber**
- Befunde: nachlaufend, umgekehrt?, tot, ausgeschlossen. Die Coinbase-Prämie ist bis U56 ausgeschlossen.

**Profi-Flow**
- Das Dashboard zeichnet ihn alle 15 min in `familien_log` auf und schreibt alle 6 h die Wochenstufen fort
  (Thread `_familien_takt`).

**Einbindung**
- Debug-Eintrag „familien“, Teil der Wochenprüfung.
- Selbsttest-Schritt 24 (`hl_familien.py --nulltest`).
- Die neue Datei steht in den Dateilisten von version, update und install.

## 3xxx. v2-Korrektur (25.09., Version 2026-09-23.26, Opus 5.5)

**Ursache der Übersicherung:** `kalibrieren` gab jedem Treiber sein volles Prior-Gewicht als Logit-Koeffizienten zum Ziel
(`w0 = prior · s · anteil`). Stehen ~20 Treiber gleichgerichtet, summiert sich das zu p 85–99 %.

**Neu im Modell**
- Zielgewichte `BETA0 · prior / s_prior · s · anteil`. `s_prior` ist die Summe der Priors der Treiber, die in mindestens
  der Hälfte der Fälle vorhanden sind. Das entspricht einem gewichteten Durchschnitt wie in v1.
- Kalibrierschritt `kalibrierschritt()`: Aus den OOF-Treiberanteilen (`cv_lambda` liefert jetzt `oof_d` und `oof_c`)
  werden c und a gewählt. Es gilt p = sig(a + c · Σ w · score). Gewählt wird das kleinste c innerhalb eines
  Standardfehlers der gepaarten Fallverluste.
- U29: Die Brier-Referenz ist die OOF-Klimatologie.

**Neu in Prüfung und Anzeige**
- U35: Das Tor prüft den Log-Odds-Beitrag.
- Prüftor `gleichlauf()`: gemeinsamer Faktor ohne Signal.
- `p_up()` nutzt nur Modelle der Version 2.
- `score_forecasts` bewertet v2 nur aus Prognosen mit `kalib2.version` ≥ 2.
- In `kalib2_info` stehen zusätzlich `kalib`, `version` und `oof_roh`.
- `stand_text` zeigt c und a.

## 3yyy. Konten-Universum: alle Pool-Konten (25.09., Version 2026-09-23.27, Opus 5.5)

**Befund:** `select_poll_targets` fragt Pool-Konten alle 10 min ab (POOL_POLL_S). `track_whales` protokolliert davon
nur Konten ab `whale_track` = 10 Mio Gesamtwert. Die Positionen aller übrigen Pool-Konten gingen verloren.

**Neu im Recorder**
- `track_pool` im Anschluss an `track_whales`, nur für `pool_addrs` und nie für Gesperrte.
- Tabelle `pool_positions` im Schema von `whale_positions`. Hier ist `delta_usd` der gerichtete Fluss.
- Ereignisse: „snap“ bei erster Sicht und alle 6 h, dazwischen open/add/reduce/close/flip.
- Schwellen: `pool_pos_min` 50k, `pool_event_min` 10k.
- Geschrieben wird im Rundenpuffer (`flush_round`); einmal täglich werden Einträge älter als 120 Tage gelöscht.

**Neu in der Prognose**
- `hl_forecast._pool_treiber` liefert Pool-Positionierung, Pool-Flow 4 h und Pool-Timing-Flow.
- `PRIORS` = 0, `SCHATTEN_TREIBER`; in `compute_forecast` erzwungen weight = 0 mit Merkmal `schatten`.
- `hl_kalib.lade_faelle` lässt die Schatten-Treiber aus.
- `hl_viz._profis_rechnen` speichert `learned` „*“/„timing_positiv“.
- Treiberfamilien: neue Familie „Pool-Konten“.

**Nächstes:** Heatmap-Anker je Coin (23.28).

## 3zzz. Heatmap als Richtungsanker (25.09., Version 2026-09-23.28, Opus 5.5)

**Neues Modul `hl_anker.py`**
- `Markt`: Kurse, σ(4 h) aus 7 Tagen 15-min-Renditen mit laufenden Summen, Stundenvolumen als Median über 24 h.
- `anker_aus`: A = Ungleichgewicht der Cluster, dazu das stärkste Cluster je Seite.
- `bilanz`: je Klasse (ab 10 % / 25 % des Stundenvolumens) und Horizont (4/8/12/24/48 h) Trefferquote trendbereinigt
  und roh, Berührung gegen Spiegel-Niveau, überhitzt und normal getrennt. Das Ergebnis steht in `learned`
  coin/„anker_bilanz“.
- `jetzt`: aktueller Anker samt gespeicherter Bilanz.

**Dashboard**
- `/anker`, 5 min zwischengespeichert, mit Hinweis `gegen_bias` aus dem jüngsten gespeicherten Bias.
- Kasten `ankerbox` oben in der AI-Prognose.
- Die tägliche Bilanz läuft im Thread `_familien_takt`.

**Einbindung:** Debug-Eintrag „anker“ und Teil der Wochenprüfung.

**Selbsttest**
- Drei synthetische Märkte: Magnet, Rauschen und eine Trendfalle, in der die Cluster immer auf der Seite des
  24-h-Trends stehen.
- Die rohe Rechnung fällt in der Trendfalle herein (+36 bis +43 pp), die trendbereinigte nicht.

## 3α. Fünf Punkte (25.09., Version 2026-09-23.29, Opus 5.5)

**Coinbase-Prämie (U67):** `PRIORS` 0 und in `SCHATTEN_TREIBER`. Damit hat sie in v1 kein Gewicht, fehlt in v2 und
trägt das Kennzeichen „Schatten“.

**Magnet-Pfad (U9):** `compute_forecast` nutzt `liq_up`/`liq_dn` nur als Pfadziel, wenn `learned`
coin/„anker_bilanz“.belegt gesetzt ist (höchstens 8 Tage alt). Sonst gilt der σ-Ersatz. `magnet_info.anker_belegt`
zeigt den Stand.

**Selbsttest im Debug (U30)**
- `install.py --selftest-isoliert` kopiert den Projektordner nach /tmp. Dabei bleiben DBs, dbbackup, venv, Caches und
  Berichte außen vor.
- Der Test läuft mit eigenem `HL_FORECAST_DB` und ohne `HL_DB`. Ohne diese Trennung fände die Test-Instanz des
  Dashboards (Port 8799) über die systemd-Einheit den echten Prognosespeicher.

**Market-Maker aus dem Handel (U15)**
- `hl_forecast.mm_aus_handel`: Daten aus `fill_zaehler_h` und `pool_fills_hourly`, 10 min zwischengespeichert.
- Wirkt in `lb_groups` und in `behavior_map`/per_coin (hl_viz).

**Masterregel (U66)**
- Status „vorlaeufig“ gilt überall als ausgeschlossen: Recorder, hl_viz, hl_profis.
- Zweiter Tag (≥ 24 h nach „seit“) über der Grenze: dauerhaft.
- Nach 7 Tagen ohne zweiten Tag: frei.
- Einmalige Überführung der Einzeltag-Sperren (meta „sperre_zwei_tage“).
- `fill_zaehler_h` wird 8 Tage aufbewahrt.

## 3β. TradeLabor und Adress-Strom (27.09., Version 2026-09-23.33, Opus 5.5)

Wunsch des Nutzers 27.09.: ein Abschnitt „TradeLabor“, in dem alle verarbeiteten Daten und die simulierten Ein- und
Ausstiege live zu sehen sind. Ziel dahinter: prüfen, ob irgendeine Datenquelle eine belastbare Kante hat (Ziel des Nutzers
2–4 %/Tag -- im Labor wird das gemessen, nicht versprochen).

**Engine `hl_labor.py`**
- `Labor(db, store)`: Takt `zyklus(now)` alle 15 s im Dashboard-Thread `_labor_takt` (Start 30 s nach dem Dashboard,
  nicht bei `_selftest*`-Datenbanken, aus mit `HL_LABOR=0`). Eine Lese-Verbindung auf die DB (`mode=ro`), eine
  Schreib-Verbindung auf den Prognosespeicher.
- Tabellen im Prognosespeicher: `labor_strategie` (sid = name@sha1(regeln)[:8], eingefroren; eine Regeländerung ergibt eine
  neue sid, die alte wird `aktiv=0` und bleibt mit Bilanz stehen), `labor_position`, `labor_order`, `labor_ereignis`
  (90 Tage), `labor_zustand` (Pausen, Kaskaden-Zustand, scharfe Ausbrüche, gesehene Darwin-tids; nur bei Änderung
  geschrieben, flüchtige Schlüssel mit Unterstrich werden nicht gespeichert).
- 31 Strategien, `strategien()`: Händler 8 (Wal-Flow 30 min, Leaderboard-Flow 60 min, Smart Money direktional, Pool-Flow
  4 h; je folgen/gegen, Schwelle 0,5) + Darwin folgen/gegen (Einstieg ab 10k binnen 180 s, Ausstieg wenn das Konto
  schließt); Prognose v1 (p_up ±8 Punkte), v2 (p_up_v2 ±10, nur Version ≥ 2), Kauf-/Verkaufspreise als Limit (Bias
  ±0,12); 9 Familien (Schwelle 0,35, Horizont der Familie; Profi-Flow aus `familien_log`); Ereignisse: Kaskade (z ≤ −2,5
  bzw. ≥ +2,5 in 15 min UND Liquidationen HL+Binance+andere über max(p95 der 15-min-Summen 7 T, 3 × Median, 50k)) mit
  Umkehr (erste Gegenkerze ≤ 30 min, Ziel halber Rücklauf) und Fortsetzung, Docht fangen (Limit 0,25 σ1h hinter dem
  nächsten Cluster ≥ 10 % Stundenvolumen in 0,5–3 σ; liegende Order bleibt, solange ihr Cluster im Snapshot steht),
  Magnet (Anker |A| ≥ 0,5), Funding-Extrem (z ≥ 2 gegen 14 T stündlich), Ausbruch nach Ruhe (Stärke ≥ 0,5 macht 4 h
  scharf, Ausbruch 1 σ1h), TWAP-Druck (Null-Hash-Netto 60 min ≥ 2 % Stundenvolumen); Kontrolle Zufall (Ø alle 8 h),
  Halten Long (7 T). Standard: Stop 1,5 σ, Ziel 2 σ (σ4h aus 15-min-Renditen 7 T, skaliert mit √(h/4)).
- Ausführung: Markt = Mitte + halber Spread + Auswirkung über die kumulierten Tiefenbänder 10/25/50/100 bps von
  `book_summary` (jenseits 150 bps), Buch älter als 90 s → Minutenschluss mit Ersatz-Spread 1 bp (BTC/ETH) bzw. 4 bp.
  Limit nur bei Durchlauf (Tief < Limit), in der Füll-Kerze nur Stop. Stop vor Ziel, Kurslücke zum Eröffnungskurs,
  Einstiegsminute einer Markt-Order ungeprüft. Gebühren 0,045/0,015 %, Funding stündlich aus `ctx_bars`.
  Pause 15 min je Strategie und Coin nach einem Ausstieg. Ein Gegensignal schließt eine Position NICHT (nur Stop, Ziel,
  Zeit, Darwin-Folge).
- Kennzahlen `_stat`: Ø netto %, t, `p_zufall` einseitig per Student-t (`p_t_einseitig`, unvollständige Betafunktion),
  `p_glueck` = min(1, p × Zahl aktiver Strategien), Treffer, PF, max DD, Hälften, Kelly, Tagesrendite auf die Konten
  (Summe / Laufzeit / (Coins × 10k)); Hebel 1/3/5/10: Summe mit Liquidation (MAE × L ≥ 90 % → −Marge), Ø/Tag, Anzahl
  liquidiert, Kontofaktor sequentiell. Stufen wie im Plan (U71).
- Anzeige-Hilfen: `status_text` (was jede Strategie sieht), `live()`, `datenfluss()` (alle Eingänge mit Alter, Status,
  Nutzern), `uebersicht()`, `chart()`, `equity()`, `trades()`, `bericht_text()`.
- Schreiblast: Positionen/Orders nur bei Änderung (einmal je Minute), Zustand nur bei Änderung; Lesen mit gezielten
  Primärschlüssel-Abfragen (σ-Raster, Funding-Stunden), Anker nur bei neuem Heatmap-Snapshot.
- Selbsttest (`--selbsttest`, Installations-Schritt): synthetischer Markt mit Kaskade, Cluster, Darwin-Konto; Positivkontrolle
  (eingebaute 85-%-Kante → t ≥ 2), Gegenrichtung verliert, Zufallstreiber ohne Scheinbeleg, Zufall kostet, Gebühren,
  Darwin ein/aus, Docht-Füllung, Kaskade beide Richtungen, Neustart alle 400 Takte, Student-t-Werte, Liquidation.

**Adress-Strom `hl_adressfluss.py`**
- Recorder `on_trade` (verfolgte Coins, `users` vorhanden) → `Adressfluss.trade` im Speicher; `run_stream_fills` holt
  jede Minute die abgeschlossenen Minuten (10 s Gnade) und schreibt sie per `asyncio.to_thread` mit Upsert in
  `adressfluss.db` neben der DB. Tabellen `af_1m` (minute, coin, addr BLOB 20 Byte, taker_kauf/-verk, maker_kauf/-verk,
  n, twap; ganze USD) und `af_stat` (minute, coin, trades, nullhash, adressen, usd, twap_kauf/-verk), beide WITHOUT ROWID.
- Stündlich: Vorhalt (`--af-tage`, Standard 14), `af_stat` 90 Tage, Größendeckel (`--af-max-gb` 3, belegte Seiten),
  Kennzahlen, WAL falten. Schreibfehler: Zeilen bleiben bis 200.000 für den nächsten Versuch.
- Meta `adressstrom` (JSON der Kennzahlen) → Netzwerkstatus-Zeile „Adress-Strom“. Debug „Adress-Strom“ (`--bericht`).
- Deutung Null-Hash = TWAP ist unbestätigt; der Bericht zeigt, ob die Null-Hash-Käufe gleichmäßig über Minuten je Adresse
  laufen (typisch für TWAP).

**Dashboard:** Abschnitt `sec-labor` (Navi „TradeLabor“) nach den Treiberfamilien; Endpunkte `/labor`, `/labor/daten`,
`/labor/chart`, `/labor/trades`, `/labor/equity` (Zwischenspeicher 5–30 s); JS-Zustand `LAB` (Reiter, Hebel, Coin im
Browser gemerkt), Abruf alle 15 s nur bei offenem Abschnitt. Debug-Einträge „★ TradeLabor“, „TradeLabor-Selbsttest“,
„Adress-Strom“; Wochenplan um `labor` und `adressstrom` ergänzt, einmalig 28.09. 12:00. Jeder Handlauf im Debug wird
zusätzlich als `berichte/…_manuell.txt` gespeichert (U73). Nebenbei: `#famtab` scrollt im eigenen Rahmen (U74).

**Grenzen, die man kennen muss:** Simulation zur Buchmitte des 5-s-Buchs, keine Warteschlangenposition bei Limits; das
Labor sieht Signale nur ab dem Takt, in dem sie erscheinen (kein Nachholen nach einem Neustart, offene Positionen und
Orders werden aber über die Minutenkerzen der Pause korrekt nachgeprüft); bei gut 30 Strategien sind Zufallstreffer zu
erwarten -- nur „Glück“ unter 5 % und die Stufe „bewährt“ zählen.

## 3γ. Alle Korrekturen nach dem ersten Labor-Tag, XMR (29.09., Version 2026-09-23.34, Opus 5.5)

Anlass: Der erste Labor-Bericht (Pi, 29.09. 01:27) zeigte keinen einzigen Darwin-Trade, obwohl Profis gehandelt hatten;
`check_profis` (28.09. 23:48) meldete „qualifiziert 0“. Wunsch des Nutzers 29.09.: alle Korrekturen gleich, dazu XMR im Labor.

**1. Profi-Bewertung ohne pool_positions (U77).** `hl_profis.lade_ereignisse` las nur `whale_positions` und `lb_events`.
Die seit 23.27 geführte Tabelle `pool_positions` (Positionsänderungen ALLER Pool-Konten, 10-min-Raster, ab 50k/10k) wurde
nie gelesen. Konten unter der Wal-Schwelle und außerhalb des Leaderboard-Trackings hatten 0 bewertbare Ein-/Ausstiege,
obwohl sie handelten; im Bericht z. B. „Greg: 37 Trades/Tag, nur 0 bewertbare Ein-/Ausstiege“. Die Darwin-Liste trocknete aus.
Jetzt drei Quellen (`QUELLEN`). Dieselbe Entscheidung (Konto, Coin, Ein-/Ausstieg, Seite) zählt binnen 15 min einmal
(`DOPPEL_S`), und je Quelle wird gezählt: `bewerten()` liefert `quellen`, `n_mit_ereignissen`, `gruende`. Probe im
Nulltest `_quellen_test`: 5 von 5 Ereignissen; Doppel, snap, fremder Coin und fremdes Konto werden verworfen; ohne
Tabelle geht es weiter. `check_profis.py`: Kopf mit 2–150 und Timing-Regel, Zeile „Ereignisse der Aktiven (7 T)“ je Quelle,
eigene Kategorien (`grund_kategorie`): Aktivität, Gewinn 7 T, zu wenige Ein-/Ausstiege, Timing nicht belegt, Einstiege
widerlegt. Vorher zählte „Glück zu hoch“ als „zu wenige Ausstiege“. Die Nicht-Qualifizierten stehen die knappsten
zuerst; die Tabelle der Qualifizierten zeigt Ein/Aus, richtig, Zufall, Glück. Dashboard-Karte: Quellenzahl im Kopf,
Ausschlussgründe, wenn niemand qualifiziert ist.
Die Mitglieder der Darwin-Liste ändern sich weiter einmal täglich. Die Korrektur wirkt deshalb ab der ersten
Tagesbewertung nach 00 UTC (02:00 Uhr).

**2. Recorder: Fills der Darwin-Liste ohne Mindestbetrag (U79a).** `lb_fills_min_usd` (2.500 USD) galt auch für die Liste;
eine in Stücke zerlegte Eröffnung war unsichtbar. Jetzt gilt für Konten der Liste (`_darwin_set`, alle Mitglieder,
aktualisiert mit `darwin_ziele`) kein Mindestbetrag, im Stream, in userEvents und im REST-Abgleich. Der REST-Abgleich hätte
die kleinen Stream-Zeilen sonst gelöscht und nicht ersetzt. Deckel `DARWIN_KLEIN_MAX_H` = 200 kleine Fills je Konto, Stunde
und Quelle. `pool_fills_hourly` zählt nur Fills ab dem Mindestbetrag, sonst stiege die Aktivität der Listen-Konten
gegenüber dem übrigen Pool (Rückkopplung). Masterregel unverändert: `fill_zaehler_h` zählte schon alle Fills. Richtung
der Stream-Fills (`stream_richtung`): Wer in den letzten 20 min abgefragt wurde und keine Position hat, ist flach. Vorher
galt bei Konten ganz ohne Position „stream“, unbekannt, und das Labor sah es nicht. Nach der eigenen abgeleiteten
Eröffnung gilt deren Seite, solange sie jünger ist als der letzte Positionsstand. Meta `darwin_fills` →
Netzwerkstatus-Zeile „Darwin-Fills“. Probe `hl_recorder.py --selbsttest-fills` (Installations-Schritt).

**3. TradeLabor Darwin v2 (U79b, neue Kennungen).** v1 merkte sich jeden gesehenen Fill und summierte nur die NEUEN eines
Taktes. Eröffnungen, die sich über mehrere Takte verteilten, erreichten 10k nie. Jetzt (`_darwin`): Eröffnungen je Konto,
Coin und Seite netto über 15 min (`DARWIN_FENSTER_S`); Schließungen derselben Seite ziehen ab, nicht unter null. Ab 10k
beginnt eine Episode, wenn der jüngste Fill höchstens 180 s alt ist; je Eröffnung einmal, gespeichert in
`labor_zustand.darwin_ep`, höchstens 12 h. Den Folge-Ausstieg gibt es erst, wenn das Konto seit der Episode mindestens die
Hälfte davon wieder geschlossen hat (`DARWIN_AUS_ANTEIL`). Seit die kleinen Fills sichtbar sind, reichte sonst jedes
Nachjustieren. Regeln `fenster_s`, `aus_anteil` → neue sid, die v1-Bilanz bleibt als „alte Regelversion“. Nachrechnung
`darwin_episoden` (gleiche Regel über eine Fill-Reihe) für den Bericht.

**4. Blockstatistik (U78).** t, `p_zufall` (Student-t mit n_eff − 1), `p_glueck`, Hälften und Stufen laufen auf Blöcken:
Trades einer Strategie, die im selben Block ihres Horizonts h eröffnet wurden (`eroeffnet // (h·3600)`), gehen mit ihrem
Mittel als EINE Beobachtung ein (`bloecke`, Feld `n_eff`). Vorher zählte jeder Coin-Trade, und gleichzeitige Trades auf
korrelierten Coins täuschten Beleg vor (eiserne Regel 4). Ø netto, Treffer, Kelly und die Hebel-Ansicht bleiben je
Trade. Die Schwellen 15/30 gelten jetzt für Blöcke. Probe: 40 gleichzeitige Trades → n_eff 1, kein t, Kandidat.

**5. XMR (U80).** Fünfter Labor-Coin. Er ist HIP-3 und bekommt deshalb `GEB_FAKTOR` = 2: Zur Protokollgebühr kommt der
Betreiberanteil (0–300 %, je Markt), angenommen sind 100 %. `gebuehren_pruefung` vergleicht das mit echten Fills.
Kontotage (`coin_starts`, `labor_zustand` „coins“): Jeder Coin zählt ab seinem Start. Beim ersten Takt nach dem Update
erben BTC/ETH/ZEC/HYPE den Laborstart, XMR beginnt jetzt. `tag_pct` = Summe / Kontotage / 10k. Alte Regelversionen
zählen bis zu ihrem letzten Trade. Probe: Umstellung 23.33 → 23.34 auf einer Demo-Datenbank (erst ein Tag mit 23.33,
dann einer mit 23.34). Alte Kennungen bleiben, XMR-Start = Update, die v2-Darwin-Trades entstehen aus Stücken.

**6. Bericht (U81).** `hl_labor.py --bericht --db PFAD`: n (Blöcke), alle offenen Positionen mit Ablauf, Darwin-Prüfung
(Liste, Fills der Liste in 24 h nach Eröffnung/Schließung/ohne Richtung und unter 2.500 USD, Episoden nach der
Live-Regel, Einstiege der Strategie) und Gebühren-Prüfung. Debug-Eintrag mit `--db`; einmaliger Bericht 30.09. 12:00
(`check_profis`, `labor`); `check_profis` jetzt auch im Wochenplan. Nebenbei: Die Pool-Tabelle (Handy) und die
Treibertabelle (Desktop) scrollen im eigenen Rahmen, vorher lief die Seite seitwärts.

**Nicht in 23.34 (bewusst):** informierter Fluss je Adresse (U75, braucht ≥ 3 Tage Adress-Strom) und die Trennung TWAP
gegen ausgelöste Orders (U82). Beides wertet dieselben Daten aus, ist aber keine Korrektur.

## 3δ. Dauerlast des Dashboards: Anfragestau auf der Wal-Tabelle (30.09., Version 2026-09-23.35, Opus 5.5)

Befund 30.09. 00:24: CPU 100 %, Last 6,8 / 9,2 / 9,1, „CPU je Dienst“ hl_viz 366 %, Recorder 32 %. Laut Verlauf dauerhaft
seit 29.09. gegen 12 Uhr, vermutlich seit dem Neustart beim Einspielen von 23.34 (dieselbe Ursache hätte jeder andere Neustart
ausgelöst). Der Debug-Eintrag „Dashboard-Threads“ zeigte in drei Proben über 10 s dieselben Threads: 21-mal `behavior_map`
(sieben Seitenabrufe von /profis und /pool gleichzeitig), 17-mal `load_whales` (vier /whales-Abrufe und zwei Prognosen).

**Ursache:** Beide Funktionen lasen die GANZE Tabelle `whale_positions`. Sie hat keinen Vorhalt und wächst um rund 60.000
Zeilen je Tag: jede offene Wal-Position bekommt alle 10 min einen Snapshot.
- `behavior_map`: Volldurchgang `ORDER BY ts` in Python.
- `load_whales`: jüngste Zeile je Konto und Coin per korrelierter Unterabfrage über die ganze Historie, dazu zwei verschachtelte
  Unterabfragen für „offen seit“.
- Nachgestellt mit 2 Mio Zeilen (17 Tage, 200 Wale) auf einem schnellen Rechner: behavior_map 3,0 s, load_whales 41 s. Auf dem
  Pi entsprechend ein Mehrfaches.
- Schutz gab es nur als Zwischenspeicher (60 s bzw. 8 s) ohne Einzelflug. War er abgelaufen, rechnete JEDER Aufrufer selbst.
- Jede sichtbare Seite fragt /whales alle 20 s, /profis alle 60–120 s und /pool alle 5 min ab. Waren die Abrufe langsamer als
  ihr Takt, stapelten sie sich. Jeder zusätzliche Abruf machte alle langsamer, und der Stau löste sich nicht mehr.
- Lastprobe mit drei simulierten Seiten auf der 2-Mio-Tabelle: alt 196 % eines Kerns, in 90 s keine einzige /whales-Antwort.
  Neu 11 %, alle Antworten im Median 0,01 s. Mit acht Seiten 15 %. Zwei echte Browser-Seiten: 3 %.

**Änderungen (hl_viz, hl_score, hl_forecast, hl_profis):**
- **Fenster statt Historie:** Der jüngste Stand je Wal-Position kommt aus den letzten 6 h (`WAL_FENSTER_S`, `WAL_STAND_S`). Offene
  Positionen haben alle 10 min einen Snapshot; was 6 h keine Zeile hat, ist geschlossen oder der Recorder steht.
  - Das gilt für `behavior_map`, `load_whales`, den Konto-Score (`hl_score`), die Elite-Stände der Prognose (`hl_forecast`,
    zwei Stellen) und `roi_12h` in `hl_profis`.
  - Probe mit dem Muster aus hl_score: 3,95 s → 0,014 s.
  - Die Wiederherstellung des Wal-Zustands beim Recorder-Start bleibt über die ganze Historie (einmalig, Korrektheit).
- **„Offen seit“** (`_wal_eroeffnet`): Eine Eröffnung im 6-h-Fenster kommt direkt aus dem Durchgang. Ältere kommen aus einem
  Durchgang über die open/close-Ereignisse der letzten 30 Tage, der 10 min im Speicher bleibt. Noch ältere: „—“.
- **Gleicher Zeitstempel:** Dort gewinnt das Schließen den Stand. Die alte Abfrage lieferte zwei Zeilen je Position, wenn zwei
  Ereignisse dieselbe Sekunde trugen (add und snap): Die Wal-Tabelle zeigte sie doppelt, die Richtungssumme zählte sie
  doppelt, in der Probe 39,5 Mio. Außerdem blieben Scheinpositionen stehen („open“ und „close“ in derselben Sekunde).
  Probe: Ergebnis sonst identisch mit der alten Abfrage; behavior_map identisch.
- **Einzelflug:**
  - `behavior_map`: Während einer Berechnung bekommt jeder andere Aufrufer den vorigen Stand. Nur vor der allerersten Berechnung
    wartet er.
  - `load_whales(…, cache_s=20)` für /whales und die Prognose: je Coin und Fenster höchstens eine Berechnung, sonst vorigen
    Stand oder warten.
  - Der Server (`do_GET`, Tabelle `_RESP_TTL`) gilt für alle gespeicherten Abrufe: Läuft dieselbe Anfrage schon, kommt die
    vorige Antwort (bis 10 min alt) oder die laufende. Neu im Zwischenspeicher: /profis 30 s, /pool 60 s, /network_ext 60 s.
    /data und /whales gelten jetzt 15 statt 8 s.
  - /forecast und /restore/info hatten eine Lebensdauer, legten ihre Antwort aber nie ab. Das tun sie jetzt.
- **Seite:** `getJSON` fragt dieselbe Adresse nicht erneut, solange die erste Antwort aussteht.
- **Profis-Karten:** Die Fills je Konto kommen über den Primärschlüssel (`addr=?`). Vorher lief `lower(addr)=?` rückwärts durch den
  ganzen Zeitindex, bei Konten mit alten Fills durch Millionen Zeilen.
- **Diagnose:** `/debug/threads` liefert je Thread die verbrauchte CPU-Zeit (`/proc/self/task`), auch für Threads ohne
  Python-Rahmen. Der Debug-Eintrag „Dashboard-Threads“ druckt dazu „CPU je Thread zwischen Probe 1 und 3“.
- **Selbsttest** `hl_viz.py --selbsttest-last` (Installations-Schritt und Debug-Eintrag): Wal-Stand gegen die Wahrheit eines
  Generators, mit allen Fallen gleicher Zeitstempel. Dazu Einzelflug von behavior_map, load_whales und Server, jeweils eine
  Berechnung bei 6–8 gleichzeitigen Aufrufen.

**Offen:** Die Tabelle `whale_positions` wächst weiter ohne Vorhalt. Mit dem Fenster ist das nur noch Speicherplatz. Später:
Snapshots älter als z. B. 30 Tage auf einen je Stunde verdichten (U84).

## 3ε. Nach 23.35: Dashboard ruhig; Recorder-Start ohne Vollscan, Scheinpositionen Gesperrter (30.09., Version 2026-09-23.36, Opus 5.5)

Befund 30.09. 02:56, Debug „Dashboard-Threads“ auf 23.35:
- 13 statt 25 Threads. Die einzige laufende Anfrage ist die Probe selbst, alle 7 Hintergrund-Threads stehen in `time.sleep`.
- CPU der dauerhaften Threads 0 %. Die drei Threads „ohne Python-Rahmen“ sind der Rechenpool von numpy (OpenBLAS, Kerne − 1).
- Zum Vergleich 00:36: 14 Anfragen hingen in allen drei Proben (7× `behavior_map`, 3× `load_whales`, dazu beide Prognose-Rechner).
Beim Nachprüfen der übrigen Abfragen auf `whale_positions` fielen zwei Stellen im Recorder auf (U85, U86).

**1. Recorder-Start (`restore_whales`, U85).** Die Wiederherstellung des Wal-Zustands suchte den letzten Stand je Konto und
Coin per korrelierter Unterabfrage über die GANZE Tabelle. 23.35 hatte das bewusst gelassen („einmalig, Korrektheit“).
- Plan `SEARCH x USING COVERING INDEX ix_whale_addr (addr=?)`: je Zeile alle Zeilen desselben Kontos. Der Aufwand wächst mit
  der Summe der Quadrate der Zeilen je Konto, also quadratisch mit dem Alter der Tabelle.
- Gemessen auf der 2-Mio-Tabelle (gen_wale.py): 40–44 s auf einem schnellen Rechner, auf dem Pi ein Mehrfaches. Das läuft VOR
  dem Start von Feeds und Poller: Bei jedem Neustart (auch beim Einspielen) zeichnet der Recorder so lange nichts auf.
- Neu `wal_zustand_laden(con, gesperrt, fenster_s)`: nur die letzten 24 h (`WAL_WIEDERHER_S`) VOR DEM LETZTEN EINTRAG, nicht
  vor jetzt. So ist der Stand beim Anhalten auch nach tagelangem Stillstand vollständig. Gleichwertig, weil
  `snapshot_whales` alle 10 min jede Position im Zustand schreibt: ihr letzter Stand liegt sicher im Fenster.
- Gleicher Zeitstempel: close gewinnt. Ein Schnappschuss in derselben Sekunde wie das close erweckte die Position sonst nach
  jedem Neustart wieder, und der nächste Poll schrieb ein zweites close.
- Gesperrte werden nicht übernommen. Für sie gibt es kein close (H3), ihre Positionen kommen mit der nächsten 6-h-Abfrage frisch.
- Vergleich auf 2 Mio Zeilen: alt 984 Positionen in 40,5 s, neu 982 in 0,25 s. Der Unterschied sind genau die zwei
  Gleichstände Schnappschuss+close (Scheinpositionen der alten Abfrage), alle Werte sonst identisch.
- Startzeile jetzt: „N Wal-Positionen aus dem Protokoll übernommen (Zeilen der letzten 24 h, Sekunden, ausgelassene Gesperrte,
  Gleichstände mit close)“.

**2. Scheinpositionen gesperrter Wale (`track_whales`, U86).** H3 (Audit v10) schreibt für Gesperrte kein close-Ereignis, weil
ihre 6-h-Stände sonst wie Wal-Flow wirken. Das `del prev[coin]` stand aber in derselben Bedingung.
- Folge bis 23.35: Die geschlossene Position eines Gesperrten blieb für immer im Zustand, auch wenn das Konto weiter
  abgefragt wurde. Der Schnappschuss schrieb sie alle 10 min weiter, und jeder Neustart holte sie zurück.
- Jetzt verlässt die Position den Zustand ohne Ereignis.
- Dashboard: Die Exposure-Zeitreihe über der Wal-Tabelle (`_load_whales_roh`) zählt Gesperrte nicht mehr (Masterregel; Tabelle
  und Ereignisse waren schon gefiltert). In die Liste kommen nur Gesperrte, die im Coin und Zeitraum Schnappschüsse haben.
  Hatten Gesperrte große Positionen, sieht der Chart nach dem Update sichtbar anders aus.

**3. Diagnose (U87).** Die CPU-Liste je Thread sieht nur Threads, die über die Proben leben. Kurze Anfragen fehlten: „Summe 0 %“
wäre auch bei Last aus vielen kurzen Anfragen möglich gewesen.
- `/debug/threads` liefert zusätzlich `prozess_cpu_s` (/proc/self/stat, zählt auch beendete Threads).
- Der Debug-Eintrag druckt „Prozess gesamt“, „davon dauerhafte“, „Rest, kurze Anfragen“ und neue Threads je Sekunde (je
  Anfrage einer). Das Skript steht lesbar in `_VIZ_THREADS_SKRIPT`.
- Probe: ruhig 2 / 2 / 0 %. Mit zwei Schleifen kurzer /chart-Abrufe 112 % gesamt, 3 % dauerhaft, 109 % kurz, 177 Anfragen/s.
  Die alte Summe hätte 3 % gezeigt.

**Selbsttest** `hl_recorder.py --selbsttest-start` (Installations-Schritt, jetzt 25 Schritte):
- Generator mit 9 Fällen: offen seit 10 Tagen (nur 24 h im Fenster), geschlossen, Schnappschuss+close und close+open in
  derselben Sekunde, Flip, add, zwei Coins eines Kontos, alte Scheinposition außerhalb des Fensters, Gesperrter. Das Fenster
  hängt am letzten Eintrag nach drei Tagen Stillstand.
- Zustand = Wahrheit. Die alte Abfrage hätte 4 Scheinpositionen übernommen.
- Gesperrter: Eine geschlossene Position verlässt den Zustand ohne close, der nächste Schnappschuss schreibt sie nicht mehr.
  Nicht-Gesperrte bekommen ihr close wie bisher.
- Laufzeit auf 100.000 Zeilen 0,2 s.
- `hl_viz.py --selbsttest-last` prüft zusätzlich: Der 90-Mio-Short eines Gesperrten steht weder in Tabelle, Ereignissen noch
  Exposure.
- Gegenprobe mit der alten Logik (Mutation): beide neuen Prüfungen schlagen fehl.

**Stand der übrigen Leser von `whale_positions`:** Kein Dienst liest mehr die ganze Tabelle. „Offen seit“ im Dashboard liest
30 Tage open/close (10 min gecacht). Auf Abruf lesen weiter die volle Historie: `check_elite` (Elite-Stände) und die
Recorder-Prüfung „Wal-Lebenszyklen“ (`--audit`).

## 3ζ. Aktive Profis: Masterregel-Zählfehler und Darwin-Regeln v2 (30.09., Version 2026-09-23.37, Opus 5.5)

Anlass, Nutzer 30.09. 10:23: „Die besten kommen auf Bewährung, und rein kommen nicht besonders gute. SilkBtc ist trotz
deiner Ankündigung rausgeflogen, trotz super Ergebnissen. Wir müssen die Regeln anpassen!“
- Am 29.09. um 20:11 stand SilkBtc als #1 „auf Bewährung“: 7 von 10 Ein-/Ausstiegen richtig, Zufall 32 %, Glück 1,6 %,
  ROI 7 T 36,8 %, PnL 7 T 2,5 Mio.
- Die Ankündigung („das Etikett sollte heute Nacht verschwinden“) beruhte auf der Bewertung von 19:56. Um 02:00 flog das
  Konto hinaus. Belegen ließ sich der Grund von hier nicht; die Debug-Ausgabe zur Sperre zeigte vorläufige Sperren gar nicht.

**1. Zählfehler der Masterregel (U88, eigener Fehler aus 23.34).**
- Seit 23.34 speichert der Recorder für Konten der Darwin-Liste auch Fills unter 2.500 USD (Stream, userEvents, REST;
  höchstens 200 je Konto, Stunde und Quelle), fürs Labor.
- `sperre_pruefen` zählte die gespeicherten Fills ohne Betragsgrenze. Darwin-Konten wurden also strenger gemessen als alle
  anderen: gebündelte Trades in ALLEN Coins, auch Stücke von ein paar hundert USD.
- Am härtesten traf es die Besten. Die ersten 10 der Liste haben Echtzeit-Plätze (userEvents), dort kommt jeder Fill an.
  SilkBtc handelt in kleinen Stücken (im Screenshot 7 PUMP-Trades in 15 min).
- Über 300 Bündel in 24 h heißt vorläufig gesperrt. Ein gesperrtes Mitglied wird nicht bewertet, das zählt als Fehltag.
  Zusammen mit dem Fehltag vom 29.09. folgte der Abstieg. Ein zweiter Tag über 300 binnen 7 Tagen hätte die Sperre dauerhaft
  gemacht und die Rohfills gelöscht.
- Dasselbe galt für die Vielhandler-Regel des Vorhalts (> 500 Fills/Tag: Rohfills nur 1 Tag).
- Behoben: Beide zählen gespeicherte Fills nur ab `lb_fills_min_usd`, wie vor 23.34 und wie `pool_fills_hourly`.
- **Einmalige Neubewertung** `sperre_neubewertung_kleinfills` beim nächsten Fill-Lauf: alle automatischen Sperren seit
  29.09. 00:00 UTC (`KLEINFILL_SEIT`, frühester Stand von 23.34), vorläufig und dauerhaft. Sie werden mit der richtigen
  Zählung geprüft, in den 24 h vor der Sperre und in den letzten 24 h, jeweils Stream-Zähler und gespeicherte Fills ab
  2.500 USD. Liegt beides höchstens bei 300, wird das Konto freigegeben: Status „frei“, Quelle „kleinfill_neubewertung“,
  Grund mit der Zahl der zu Unrecht mitgezählten Bündel. Das Ergebnis steht in meta `sperre_kleinfill_neubewertung`.
- Grenze: Bei dauerhaften Sperren sind die Rohfills gelöscht, dort entscheidet der Stream-Zähler. Wer tatsächlich über 300
  liegt, wird beim nächsten Lauf wieder gesperrt.
- `check_sperre` zeigt jetzt vorläufige Sperren, Namen und die Freigaben der Neubewertung, und zählt wie der Recorder.

**2. Die Regeln selbst (U89): streng hinein, großzügig bleiben.** Simulation (`sim_regeln.py`, nicht im Paket):
- Population: 200 Konten ohne Vorsprung und 10 Könner. Etwa 1,4 Entscheidungen am Tag, Zufallsquote je Entscheidung
  20–50 %, Placebo mit 3 Punkten Rauschen, tägliche PnL mit Drift für die Könner. Sechs Läufe je Variante, 120 Tage.
- Heutige Regeln bei 20 Punkten Vorsprung: Könner nur 30 % der Zeit auf der Liste, im Mittel 3,9 Zufallskonten darauf,
  12,3 Aufnahmen je Woche (8,8 davon Zufall), 3,4 Könner fliegen je Woche raus.
- Neue Regeln: Könner 68 % der Zeit auf der Liste, 2,0 Zufallskonten darauf, 1,5 Aufnahmen je Woche (0,9 Zufall),
  0,5 Könner fliegen raus. Bei 15 und 25 Punkten Vorsprung ist das Bild gleich (19 % → 51 %, 39 % → 78 %).
- Mit Aufnahme bei 2 % statt 1 % stünden die Könner 72 % der Zeit auf der Liste, bei 3,5 Zufallskonten und 1,8
  Zufallsaufnahmen je Woche. Wegen der Klage über schwache Neuzugänge gilt 1 %. Das ist eine einzige Zahl
  (`AUFNAHME_P_GLUECK`).

Die Regeln in `hl_profis`:
- Timing über 14 Tage (`TIMING_TAGE`, vorher 7), die Aktivität weiter über 7 Tage.
- **Aufnahme:** 2–150 Trades/Tag, Gewinn 7 T > 0 UND 30 T > 0, ≥ 6 Entscheidungen, Glück ≤ 1 %, gedämpfter Vorsprung
  ≥ 10 Punkte, Einstiegs-Veto.
- **Verbleib:** 1–150 Trades/Tag, Gewinn 30 T > 0, ≥ 4 Entscheidungen, Glück ≤ 50 % und Vorsprung > 0, Einstiegs-Veto.
- `bewerten(con, mitglieder=…)` rechnet für Mitglieder (und für die Freigegebenen der Neubewertung) das Timing auch dann,
  wenn sie an der Aufnahme vorher scheitern. Je Konto: `aufnahme`, `verbleib`, `gruende`, `gruende_verbleib`.
  „qualifiziert“ bedeutet jetzt Aufnahme erfüllt. Mitglieder ohne Bewertung stehen mit Grund in `fehlend`.
- Die Tagesentscheidung ist jetzt die reine Funktion `darwin_tag(st, r)`. Das Dashboard lädt und speichert nur.
  - Abstieg nach 3 Tagen in Folge ohne Verbleib, mit dem Grund des letzten Fehltags.
  - Umstieg auf v2 einmalig und sofort: Aufnahme nach den neuen Regeln; die Fehltage der alten Regel bleiben stehen.
  - Beim Umstieg kommen außerdem die jüngst Abgestiegenen zurück, wenn sie die Verbleib-Regel erfüllen. Erkannt werden sie an
    gespeicherten Fills unter 2.500 USD seit 29.09.: Die gibt es seit 23.34 nur für Mitglieder der Liste
    (`bewerten(…, ehemalige_suchen=True)`, nur beim Umstieg). Sie flogen nach den alten, zu wackligen Regeln hinaus;
    so kommt SilkBtc auch dann zurück, wenn nicht die Sperre, sondern der alte Glückstest ihn hinausgeworfen hat.
  - Rückkehr zu Unrecht Gesperrter sofort und je Neubewertung einmal, nur mit erfüllter Verbleib-Regel.
  - Protokoll der Zu- und Abgänge mit Grund, 14 Tage.
- Das Dashboard sieht alle 5 min nach, ob die Neubewertung Freigaben geschrieben hat, und rechnet dann sofort (sonst
  stündlich).

**Anzeige:**
- Abschnitt 10 heißt „Aktive Profis — Darwin-Liste mit belegtem Timing“. Der Kopf nennt die Regeln v2.
- Die Karte zeigt „Verbleib erfüllt“ oder „Verbleib jetzt verfehlt: Grund“ und das Etikett „Fehltag x von 3“ statt „auf
  Bewährung“.
- Darunter: Mitglieder ohne Bewertung mit Grund, Zu- und Abgänge der letzten 7 Tage mit Grund.
- Die Pool-Tabelle zeigt für Mitglieder den Verbleib, sonst „aufnahmefähig“ oder den ersten Grund dagegen.
- `check_profis` gibt Mitglieder mit Fehltagen und Verbleib aus, dazu Protokoll, Aufnahmefähige und die Neubewertung.

**Labor:** „Darwin folgen“ und „Darwin gegen“ bekommen `liste=2`, also eine neue Kennung. Die Bilanz vermischt sonst zwei
verschieden zusammengesetzte Listen. Umstellungsprobe auf der Demo-Datenbank: 23.36 bis 12 h vor jetzt, dann 23.37. Die
alten Kennungen sind inaktiv („alte Regelversion“), die neuen handeln, keine Fehler.

**Proben:**
- `hl_recorder.py --selbsttest-sperre` (Installations-Schritt): 350 kleine und 20 große Bündel → frei; 350 große →
  vorläufig; Neubewertung gibt die Kleinfill-Sperre frei; echte Sperren (320 große, 350 Stream-Trades) bleiben, eine
  Sperre vor dem 29.09. bleibt unberührt, ein zweiter Lauf ändert nichts. Mit der alten Zählung schlagen zwei Prüfungen
  fehl.
- `hl_profis.py --nulltest` mit Glückstest für beide Schwellen (Zufallskonten aufgenommen 0,6 %) und Darwin-Test (11
  Schritte: Umstieg, Verbleib ohne Aufnahme, eine Entscheidung je Tag, gesperrtes Mitglied, Abstieg nach 3, Rückkehr nur
  mit Verbleib und einmal, Protokoll 14 Tage).
- Demo-Ende-zu-Ende: Umstieg nimmt einen Könner sofort auf und holt ein jüngst abgestiegenes Mitglied mit Verbleib zurück
  (seine Aufnahme wäre mit 1,5 % gescheitert); die Neubewertung gibt „SilkBtc“ frei (12 echte Bündel, 330
  kleine zu Unrecht mitgezählt); das Dashboard holt ihn zurück. Seine Aufnahme wäre mit 1,03 % knapp gescheitert, der
  Verbleib hält ihn. Browser Handy und Desktop ohne JS-Fehler, keine Seitwärts-Scrolls.
- Lastprobe `bewerten` (960 Pool-Konten, 450.000 pool_positions, 900.000 whale_positions): 23.36 mit 7 Tagen 2,1 s,
  23.37 mit 14 Tagen 3,0 s (schneller Rechner; auf dem Pi etwa das Dreifache, stündlich).

## 3η. Bericht 30.09. 19:55: Darwin-Regeln v3, falsche Freigabe, API-Gewicht hart gedeckelt (30.09., Version 2026-09-23.38, Opus 5.5)

Anlass: Sammeldatei der Berichte vom 30.09. (19:55, inhaltlich gleich mit 19:40), der erste Tag mit 23.37 auf dem Pi.

**Befund Aktive Profis (19:16):**
- 5 Mitglieder. SilkBtc ist zurück, über die strenge Aufnahme beim Umstieg auf v2: 20 von 28 richtig, Zufall 46 %,
  Glück 0,5 %, ROI 7 T 37 %.
- Korrektur einer eigenen Aussage: Nicht der Zählfehler der Masterregel hatte SilkBtc hinausgeworfen, sondern die alten
  Regeln. Die Neubewertung 23.37 gab nur ein einziges Konto frei, 0xb078…de15, und das zu Unrecht (U92).
- 0x64b7…9da9 kam beim Umstieg über die Verbleib-Regel zurück: 3 von 9, Glück 11 %, ROI 7 T −7,6 %. Die Aufnahme hätte es
  nie bestanden.
- Drei Altmitglieder aus v1 verfehlten den Verbleib und hätten erst am 03.10. gehen sollen:
  - 0x0c4a…1b19: kein bewertbarer Ein-/Ausstieg in 14 T, PnL 30 T −1,15 Mio.
  - perpfumbler: ebenfalls keiner, PnL 30 T −0,06 Mio.
  - 0xe867…c78e: 7 von 15, Glück 54 %.
- Bis dahin folgte ihnen das Labor. 0x0c4a eröffnete BTC 8,4 Mio und ETH 0,9 Mio long, beides kopierte „Darwin folgen“, und
  der Profi-Flow in BTC und ETH stand ihretwegen auf +1,00.
- Außer SilkBtc erfüllt niemand die Aufnahme. Die nächsten liegen bei 16,8 / 19,1 / 19,9 / 20,5 % Glück; das sieht nach
  Zufall aus.

**1. Darwin-Regeln v3 (U91): die Schonung nur nach strenger Aufnahme.**
- Die großzügige Verbleib-Regel mit 3 Fehltagen war für Konten gedacht, die die strenge Aufnahme bestanden haben. v2 gab sie
  beim Umstieg auch dem Altbestand und einer Rückkehr über die Verbleib-Regel. Das widerspricht „rein kommen nicht besonders
  gute“.
- `hl_profis.darwin_tag` führt jetzt den Merker `streng` (Adresse → Zeitpunkt). Jeder Weg auf die Liste verlangt die
  strenge Aufnahme: die Tagesentscheidung, der Umstieg, die Rückkehr zu Unrecht Gesperrter.
- Umstieg auf v3, einmalig und sofort:
  - Den Merker bekommt, wer unter v2 über die Aufnahme-Regel kam (Protokoll: Grund beginnt mit „Aufnahme“).
  - Wer ohne Merker auf der Liste steht, bleibt nur, wenn er die Aufnahme jetzt erfüllt. Sonst Abgang mit Grund „Umstieg auf
    die Regeln v3: ohne strenge Aufnahme … -- <erster Grund>“.
  - Danach Aufnahme nach den Regeln. Die Fehltage der Übrigen bleiben stehen.
- Keine Suche nach „ehemaligen“ mehr: `bewerten(…, ehemalige_suchen)` und `DARWIN_KLEINFILLS_SEIT` sind entfernt.
- Sicherheitsnetz in der Tagesentscheidung: Ein Mitglied ohne Merker bleibt nur mit Aufnahme. Nach dem Umstieg kann das nicht
  mehr vorkommen.
- Erwartung auf dem Pi, beim ersten Rechnen des Dashboards nach dem Update: SilkBtc bleibt (Merker vom 30.09. 11:21). Die
  anderen vier gehen, außer eines erfüllt dann die Aufnahme.
- Labor: `liste=3`, neue Kennungen für „Darwin folgen/gegen“; die v2-Kennungen werden „alte Regelversion“.
- `check_profis` zeigt je Mitglied „streng seit …“ oder „OHNE strenge Aufnahme“. Steht der Umstieg noch aus, rechnet es ihn
  auf einer Kopie vor („Vorschau: bleiben … · raus …“).

**2. Falsche Freigabe der Masterregel (U92).**
- 0xb078…de15 war vorläufig gesperrt: 362 gebündelte Trades, 926 Fills. Die Neubewertung 23.37 zählte 299 und gab es frei,
  mit „0 kleine Bündel zu Unrecht mitgezählt“. Der Zählfehler kann die Sperre also nicht verursacht haben.
- Die Lücke zwischen 362 und 299 stammt vermutlich aus der Vielhandler-Regel: Über 500 Fills/Tag bleiben Rohfills nur 1 Tag,
  die Fills vor der Sperre waren also schon gelöscht.
- Bedingung jetzt: Freigabe nur, wenn die gespeicherten Fills MIT den kleinen über 300 liegen (sie erklären die Sperre) und
  ohne sie wie im Stream höchstens 300.
- Einmalige Rücknahme `sperre_kleinfill_korrektur` für Freigaben ohne kleines Bündel, sofern das Konto noch „frei“ aus der
  Neubewertung ist:
  - Status und `seit` wie vorher; die 7-Tage-Frist läuft ab der ursprünglichen Sperre.
  - Quelle „auto“, Trades/Tag aus dem alten Grund, dazu ein Vermerk.
  - meta `sperre_kleinfill_neubewertung` bekommt „zurueckgenommen“ und „korrektur_ts“. „ts“ bleibt, damit das Dashboard
    nicht neu auslöst.
- `check_sperre` und `check_profis` zeigen die Rücknahme.

**3. API-Gewicht hart gedeckelt (U93, eiserne Regel 90 %).**
- Vollbericht 19:00: 1.092/1.080. Der Begrenzer (Eimer 180 + Reserve 216) erlaubt in 60 s Rate × 60 plus den Füllstand.
- Simulation in virtueller Zeit (Ereignisschleife springt), Last vom 30.09.: Poller in 23er-Runden, Orders 9 × 20,
  Leaderboard 78 × 2, Fills 40 × 22. Ergebnis: erste Minute nach jedem Start ~1.470 (über Hyperliquids 1.200), im Betrieb
  bis 1.118.
- Jetzt:
  - Das gleitende 60-s-Fenster ist ein harter Deckel (Budget × Temperaturfaktor, `deckel()`), mit laufender Summe.
  - Die Eimer werden nie voller als der Platz im Fenster. Ohne diese Klemme sammeln sie während einer Sperre an und entladen
    sich, sobald ein Klumpen aus dem Fenster fällt: Schwall und Stillstand im Wechsel, in der Simulation Lücken bis 12 s.
  - Leerer Start: Der vorige Prozess hat in derselben Minute vielleicht schon verbraucht.
  - Fehlt dem Ersten der Schlange der Platz, überholt ihn niemand.
- Ergebnis: Fenster ≤ 1.080, erste Minute 1.072, Durchsatz ~1.055 statt ~1.080/min (−2,5 %). Wartezeiten wie vorher.
- Nebenbefund U95 (offen): Kleine Abfragen überholen wartende 20er, so gebaut seit 17.09. Mit den Antwortzeiten des Pi
  bekommen die Orders ~165/min. Bei schnellerem Netz fielen sie in der Simulation auf 6/min.

**4. Anker-Bericht (U94).** `hl_anker.py --bericht` nimmt die Coins aus den 1-min-Kerzen statt aus der Heatmap. Bisher kamen
172 Blöcke „zu wenige Kursdaten“ (gut 500 Zeilen je Sammeldatei, 259 s).

**Weitere Befunde, ohne Änderung:**
- Labor gesamt −19.338 USD (24 h −8.378, Gebühren 7.434). Zufall-Kontrolle −2.375. Nichts belegt; beste t-Werte 1,2–1,4.
- XMR: Markt-Einstiege 55–115 bps von der Mitte, „Familie Orderfluss“ XMR −3.000 (t −5,4). Entscheidung U96.
- Prognose 4 h: 46 % gegen Basis 55 %. Kalibrierung v2: Tor bestanden, aber c = 0 für 5 von 6 Coins, sie sagt also die
  Basisrate. U7b noch nicht.
- Pool-Fills: Abholstand Median 29 h (Takt 12 h), 330 Konten wegen Budget zurückgestellt. Die Darwin-Bewertung stützt sich auf
  Positionsereignisse und ist davon nicht betroffen.

**Proben:**
- `hl_profis.py --nulltest`, Darwin-Test v3 14/14. Mutationen rot: Umstieg ohne Entfernen, Rückkehr über Verbleib, Merker nicht
  aus dem Protokoll, kein Sicherheitsnetz, Abstieg nach 2.
- `hl_recorder.py --selbsttest-sperre` 9/9, mit den neuen Fällen: Vielhandler mit gelöschten Fills bleibt, Rücknahme ohne
  kleines Bündel, Freigabe mit kleinen bleibt, einmalig. Mit der alten Bedingung 2 rot.
- `hl_recorder.py --selbsttest-gewicht` 7/7, neuer Installations-Schritt, jetzt 27. Mutationen „ohne Klemme“ und „voller
  Start“ rot.
- Demo-Ende-zu-Ende mit einem Stand wie auf dem Pi (v2, zwei Altmitglieder, SilkBtc streng, eine Rückkehr über Verbleib, eine
  falsche Freigabe ohne kleines Bündel):
  - Vorschau in `check_profis` stimmt mit dem Umstieg überein.
  - Das Altmitglied ohne Aufnahme geht mit Grund; der Rückkehrer bleibt, weil er die Aufnahme jetzt erfüllt; SilkBtc behält den
    Merker; eine zweite Bewertung ändert nichts.
  - Der Recorder nimmt die Freigabe zurück (vorläufig seit der ursprünglichen Sperre, 362 Trades).
  - Browser Handy und Desktop ohne JS-Fehler, keine Seitwärts-Scrolls.
- `install.py --selftest-isoliert`: 27 Schritte, PNG, 7 Dashboard-Abrufe, alles grün.

## 3θ. Elite als zweite Kopier-Vorlage im Labor, check_elite wie das Dashboard (30.09., Version 2026-09-23.39, Opus 5.5)

Anlass, Nutzer 30.09. 21:09: das Labor so laufen lassen und nach einer Weile auswerten; Frage, ob es Elite und Aktive Profis
als Vorlage nutzt. Stand bis 23.38:
- Die Darwin-Liste wurde kopiert („Darwin-Liste live folgen“).
- Die Elite nicht; sie steckte nur als einer von neun Treibern in „Familie Großkonten-Fluss“, und dort meldet die
  Familien-Hygiene sie in BTC, HYPE, ZEC und XMR als „tot“.
Nutzer 21:15: „Ja, setz alles gleich um“.

**1. „Elite live folgen“ und „Gegen die Elite“ (U97).**
- Dieselbe Regel wie bei der Darwin-Liste, damit die beiden Vorlagen vergleichbar sind:
  - Einstieg, wenn ein Konto im Coin netto mindestens 10k binnen 15 min eröffnet und der jüngste Fill höchstens 3 min alt ist.
  - Folge-Ausstieg, wenn das Konto mindestens die Hälfte wieder schließt; sonst Stop 1,5 σ, Ziel 2 σ oder nach 12 h.
- Vorlage ist die Elite des jeweiligen Coins: learned(coin, „elite“), vom Dashboard täglich aufgestellt (Konto-Score mit
  belegtem Vorlauf, Gewinn- und Aktivitätsschranke, ohne Gesperrte). Das Labor nimmt zusätzlich Konten heraus, die die
  Masterregel seither gesperrt hat.
- Code:
  - `_darwin` ist jetzt Liste plus gemeinsame Logik `_kopie`; deren Rumpf ist der bisherige, unverändert.
  - Zustand je Vorlage getrennt (`darwin_tids/_ep`, `elite_tids/_ep`), über Neustarts gespeichert.
  - Signale über `_sig_kopie`; die Darwin-Texte sind gleich geblieben.
  - Alle 31 alten Kennungen sind unverändert, die beiden neuen: `elite_folgen@8365f347`, `elite_gegen@1238a0fb`.
- Recorder:
  - `fill_konten_auffrischen` nimmt die Elite aller Coins in die Fill-Konten auf: Stream-Fills ab 2.500 USD, 0 Gewicht.
  - Bis dahin fehlten ihre Fills, wenn ein Elite-Konto weder Leaderboard-Auswahl, Pool noch Wal war.
  - Die Masterregel zählt diese Konten damit ebenfalls.
  - Die Richtung der Stream-Fills kennt der Recorder, weil die Elite jede Minute abgefragt wird (Wal-Takt seit 15.09.).
- Unterschied zur Darwin-Kopie: Die Elite ist nur mit Fills ab 2.500 USD sichtbar; für die Darwin-Liste speichert der Recorder
  auch kleinere.
- Bericht: „Elite-Prüfung (24 h)“ neben der Darwin-Prüfung. Sie zeigt die Elite je Coin, die Fills im eigenen Coin, die
  Eröffnungen ≥ 10k und die Einstiege.
- Dashboard: Datenfluss-Zeilen für die Elite, Hilfetext des Labors.

**2. check_elite rechnet wie das Dashboard (U98).**
- Der Bericht vom 30.09. zeigte 0x645b…87b8 und 0x3ff5…f705 in der Elite, beide von der Masterregel gesperrt. „Dominanz 63 %“
  war 0x3ff5.
- Das Dashboard nimmt Gesperrte heraus, das Werkzeug nicht. Außerdem stufte das Werkzeug unbekannte Konten als direktional
  ein und kannte das Verhalten je Coin nicht.
- Jetzt:
  - Einstufung über `hl_viz.score_klasse`; der Lernzyklus nutzt dieselbe Funktion (aus dem Block herausgezogen, gleiches
    Verhalten).
  - Ohne Gesperrte, mit einer Zeile, wen die Masterregel herausnimmt.
  - Zusätzlich die gespeicherte Elite, die Treiber, Recorder-Vorrang und Labor tatsächlich nutzen, mit Abweichungen zur
    frischen Rechnung und „davon inzwischen gesperrt“.

**3. Entscheidungen.**
- U96 XMR: so laufen lassen (Nutzer).
- U99: Auswertung des Labors ab 11.10.; für Darwin v3 und Elite ab etwa 14.10.

**Proben:**
- `hl_labor.py --selbsttest` mit Elite-Szenario:
  - 3 Stücke zu 4k über den Labor-Neustart hinweg; eine Teilschließung von 1k wird ignoriert; Folge-Ausstieg nach 90 min.
  - „Gegen die Elite“ nimmt die Gegenseite.
  - Die 20k-Eröffnung eines gesperrten Elite-Kontos wird nie kopiert.
  - Ein Konto in beiden Vorlagen: beide kopieren es, beide mit Folge-Ausstieg.
  - Mutationen rot: Zustand nicht gespeichert, Gesperrte nicht gefiltert, gemeinsamer Zustand der Vorlagen.
- `hl_recorder.py --selbsttest-fills`: Elite-Konto außerhalb von Auswahl, Pool und Walen wird Fill-Konto, sein 5k-Fill wird
  gespeichert, der 1k-Fill nicht; ein gesperrtes Elite-Konto nie.
- Umstellungsprobe auf der Demo-Datenbank: alte Darwin-Kennungen als „alte Regelversion“, neue Elite-Kennungen aktiv, keine
  Fehler, Bericht mit Elite-Prüfung.
- check_elite auf synthetischer Datenbank: Das gesperrte Konto mit Beleg fehlt in der Elite und steht in der Masterregel-Zeile.
- `install.py --selftest-isoliert`: 27 Schritte, PNG, 7 Dashboard-Abrufe, alles grün.

## 3ι. Grid-Bots im TradeLabor: Grid Long und Grid Short (01.10., Version 2026-09-23.40, Opus 5.5)

Anlass, Nutzer 01.10. 21:05: „Das Trading-Labor um die Funktion eines Grid-Bots erweitern. Er soll die Range automatisch
erkennen und anpassen, bei einer plötzlichen starken Bewegung aufwärts das Maximum abwarten und erkennen und nicht zu früh
verkaufen, bei stark fallenden Kursen einen Notausstieg auslösen und so laufend Rendite generieren.“ Auf Rückfrage
entschieden: **Long und gespiegeltes Short** (zwei Strategien), **mit Startbestand** (klassisches Grid), **eine Variante**.

**1. Regeln (eingefroren, Gruppe „Grid“, Kennungen `grid_long@…`, `grid_short@…`; alle übrigen Kennungen unverändert).**
- Range aus den 1-min-Kursen der letzten 24 h: 10. und 90. Perzentil. Nach einem Ausstieg nur Kurse ab dann (mindestens 2 h).
- Trendmaß mit Vorzeichen: ln(Ende/Anfang) / (σ der 5-min-Renditen · √Anzahl) — für einen Zufallsweg standardnormal,
  unabhängig von der Fensterlänge. Aufgebaut und nachgeführt wird nur bei höchstens 1 gegen das Grid (Long: abwärts) und
  höchstens 2 in Grid-Richtung (`grid_trend_ok`). Start nur mit dem Kurs im mittleren Teil (60 %) der Range, nicht während
  einer Kaskade.
- Stufen geometrisch, so viele, wie mit ≥ 0,2 % Abstand passen, 4–12 (`grid_stufen`); unter 4: „Range zu eng“, warten.
- Kapital: 10.000 USD je Coin (`GRID_KAPITAL`), gleich auf die Stufen verteilt. Jeder Abstand [Li, Li+1] hält entweder ein Los
  oder eine Einstiegs-Order. Long kauft bei Li und verkauft bei Li+1, Short verkauft bei Li+1 und kauft bei Li zurück (Maker).
  Nach jedem Verkauf liegt dort wieder ein Einstieg.
- Startbestand: Die Abstände jenseits des Kurses in Gewinnrichtung (Long: darüber) bekommen beim Aufbau ein Los zum
  Marktpreis (ein gemeinsamer Taker-Auftrag, Marktauswirkung aus der Buchtiefe), die übrigen eine Order.
- Nachführen stündlich, wenn sich die Mitte um ≥ 1 Stufe verschiebt oder die Breite um ≥ 25 % ändert (Kurs innerhalb der
  neuen Range, Trendmaß erlaubt). Vorhandene Lose behalten ihr Ziel und zählen auf den Bestand an; gekauft wird nur, was zum
  klassischen Bestand fehlt, Orders nur, soweit das Kapital reicht (Lose aller Generationen + Orders ≤ 10.000).
- Halten (der Wunsch „nicht zu früh verkaufen“): Squeeze bzw. Kaskade in Grid-Richtung (Labor-Erkennung), ≥ 3 σ in 5 oder
  15 min in der Gewinnhälfte der Range, oder Kurs eine Stufe jenseits der Range in Gewinnrichtung. Dann keine Ziele mehr, alle
  Lose bleiben, Trailing-Stop 1,5 σ(1 h) vom Extrem (σ beim Start festgehalten, Stop nur nachgezogen), danach 2 h Pause und
  eine neue Range aus Kursen ab dann. Ein Maximum ist nur im Nachhinein erkennbar — der Rückfall um 1,5 σ ist die Erkennung.
  Ohne Bestand beim Ausbruch: Grid ruht 2 h.
- Notausstieg: Kaskade gegen das Grid, ≥ 3 σ in 15 min in der ungünstigen Hälfte, oder Kurs an der Notlinie eine Stufe
  jenseits der Range. Alle Lose zum Marktpreis (ein Auftrag), Orders weg, Pause 4 h; nach dem zweiten Notausstieg binnen 24 h
  12 h, nach dem dritten 24 h.

**2. Was die Probe auf dem synthetischen Markt an den Regeln geändert hat (vor dem Einfrieren).**
- Ein Auslöser nur über 15 min kam in einer schnellen Rallye zu spät: Ein enges Grid (1,9 % Range, 0,21 % Stufen) hatte seinen
  Bestand auf den Stufen schon verkauft, bevor +3 σ über 15 min erreicht waren — genau das „zu früh verkaufen“. Deshalb auch
  5 min. Danach hielt Grid Long 2 Lose durch die Rallye und verkaufte nahe dem Hoch (+124 USD statt ~+5 USD auf den Stufen).
- Ein Trendmaß ohne Richtung (|Trend| ≤ 1,5) ließ Grid Long im langsamen Abwärtstrend dreimal neu aufbauen, jedes Mal mit
  Notausstieg (−85 bis −112 USD). Deshalb streng gegen das Grid, großzügig mit ihm, und längere Pausen nach Wiederholungen.
- Der Schub-Auslöser zählt nur in der Gewinnhälfte der Range (spiegelbildlich zum Notausstieg): Unten ist ein schneller
  Anstieg ein Rücklauf innerhalb der Range, dort soll das Grid normal verkaufen.

**3. Mechanik (`hl_labor.py`).**
- Lose = `labor_position` (Notional = Kapital / n, Ereignisart „grid_los“), Einstiegs-Orders = `labor_order` (nur offene;
  gefüllte und gelöschte verschwinden), Zustand je Strategie und Coin = `labor_zustand` „g“ (Modus warten/aktiv/halten/pause,
  Stufen, Notlinie, Halten, Pause, Kerzen-Stand, Zähler, Notausstiege der letzten 24 h).
- Kerzen-Replay wie bei den übrigen Strategien: Ein Limit füllt nur, wenn eine spätere 1-min-Kerze DURCH den Preis läuft.
  Reihenfolge in einer Kerze bewusst vorsichtig: erst Einstiege in Verlustrichtung, dann Notlinie bzw. Trailing-Stop für
  ALLE Lose (auch die eben gefüllten), erst dann Ziele; Auslöser zum Kerzenschluss; zuletzt freie Abstände neu belegen.
- Auslöser zusätzlich im 15-s-Takt (Kaskade, z15 aus der Kaskaden-Erkennung, z5 aus dem Schluss vor 5 min). Halten mitten in
  der Minute: Ziele, die der Kurs bis dahin schon durchlaufen hat, gelten als verkauft; der Trailing-Stop zählt erst ab der
  nächsten vollen Kerze (die laufende enthält Kurse von vor dem Auslöser).
- Nach langem Ausfall Kerzen in Etappen (höchstens 3 Tage je Takt); bis alles nachgeholt ist, keine Auslöser und kein Aufbau
  zum Kurs von jetzt.
- Jedes Grid läuft hinter einem eigenen Sicherungspunkt (SAVEPOINT): Ein Fehler rollt nur dieses Grid in diesem Takt zurück,
  Datenbank und Zustand, statt halbe Änderungen zu speichern.
- Lose und Orders abgelöster Grid-Regelversionen (neue Kennung) werden beim ersten Takt geschlossen bzw. gelöscht.
- Die übrigen Strategien: `_orders`, `_positionen` und `_signale` überspringen das Grid; `_eroeffnen`/`_schliessen` kennen ein
  Notional je Position und eine Ereignisart (Standard wie bisher); kein Verhalten geändert.

**4. Bewertung nach Bestandswert.**
- Ein Grid zeigt laufend kleine realisierte Gewinne, während sich Verluste im Bestand sammeln. Deshalb hält das Labor den
  Bestandswert fest (`labor_grid_tag`: nach jeder Änderung und alle 5 min, ein Stand je Tag) und rechnet das
  **Tagesergebnis = realisiert im Tag + Änderung des unrealisierten Bestands** (`grid_tage`).
- Für die Grids sind die Blöcke Tage mit diesem Ergebnis (in % des Kapitals aller Coin-Konten): t, Glück, Hälften, Stufen.
  Summe, Ø/Tag und Hebel-Summe zählen den letzten Bestand mit, max DD aus den Tagen, die Bilanzlinie hat Tagespunkte.
- `_stat`: Trades mit eigenem Notional (Lose) — Liquidation kostet ihre Marge, der Kontofaktor wächst mit ihrem Anteil. Für
  10.000-USD-Trades identisch zu vorher (Selbsttest unverändert grün).
- „Ø netto“ je Los ist klein (eine Stufe abzüglich Gebühren); beurteilt wird ein Grid nach dem Tagesergebnis.

**5. Anzeige und Bericht.**
- Live: Zelle je Coin mit Modus (▦ aktiv x/n Lose, ⇡/⇣ hält, ⏸ Pause, wartet mit Grund) und Bestandswert.
- Positionen: Grid-Lose und -Orders je Grid und Coin gebündelt (Lose, Einsatz, Ø Einstieg, Bestand, Range, Schritt,
  Notlinie bzw. Trailing-Stop, Orders von–bis).
- Chart: mit gewähltem Grid Range (blau), Notlinie (rot gestrichelt), Trailing-Stop (gelb); ohne Auswahl keine Grid-Lose.
- Strategien: Summe nach Bestandswert mit Aufteilung realisiert/Bestand und Tagesergebnissen.
- Ereignisse: Aufbau, Nachführen, Halten, Notausstieg (Art „grid“); die einzelnen Lose getrennt (`ereignisse_grid`, unter
  „alles“) — sonst verdrängten Hunderte Lose am Tag alle übrigen Ereignisse aus den letzten 150.
- Trades: Netto je Los mit seinem Notional. Datenfluss: Range 24 h, Trendmaß (Long/Short darf oder wartet), Stufen.
- Bericht „★ TradeLabor“: Abschnitt „Grid-Bots“ je Grid und Coin (Modus, Range, Lose, Bestand, Runden, Aufbauten,
  Nachführungen, Halten, Notausstiege); die Kopfzeile nennt Grid-Lose und Bestand getrennt.

**Proben:**
- `hl_labor.py --selbsttest` (rund 50 s): synthetischer Markt (Sinus 1 % mit 4 h Periode, Rallye +5 % in 40 min bis +7 %,
  Crash −6 % in 10 min mit Long-Liquidationen, langsamer Abwärtstrend −0,4 %/h über 10 h), 2-min-Takt mit Neustart mitten
  im Halten: Aufbau, Kapital nie über 10.000, seitwärts jede Runde im Gewinn (je 58 Runden vor der Rallye), Long hält die
  Rallye und verkauft nahe dem Hoch, Short Notausstieg in der Rallye, Long Notausstieg im Crash und 4 h keine Lose, Short
  hält den Crash und kauft nach dem Tief zurück, Long baut nicht in den Abwärtstrend und verlässt ihn an der Notlinie,
  Tagesbilanz = realisiert + Bestand = Bilanzlinie, 10-min-Takt holt über die Kerzen nach. Mikro-Proben auf festen Kerzen:
  Kapitaldeckel mit Losen früherer Stufen, Trailing-Stop erst ab der Kerze nach dem Auslöser, Notlinie nach der Füllung in
  derselben Kerze. Dazu abgelöste Regelversion, Fehler hinter dem Sicherungspunkt, Stufen und Trendmaß.
- Mutationen (je einzeln, alle rot): ohne z5, Trendmaß ohne Richtung, Kapital ignoriert, kein Sicherungspunkt, Stop schon in
  der Startkerze, Notlinie aus, Pause nach Notausstieg 0 h.
- Browser (Handy 390 px, Desktop): alle sieben Reiter mit laufendem Labor auf einem synthetischen BTC-Markt, keine
  Labor-Fehler, keine Seitenbreite über dem Bildschirm.
- `install.py --selftest`: alle Schritte grün (Labor-Schritt jetzt mit Grid, rund 50 s in der Sandbox, auf dem Pi länger).

**Was man wissen muss:** Mit zwei Strategien mehr (35) wird „Glück“ für alle etwas strenger. Grids erzeugen viele Lose (in
der Probe rund 60 Runden je Tag und Grid bei 1,9 % Range) — die Tabelle `labor_position` wächst entsprechend (U102). XMR
handelt mit doppelten Gebühren (Runde 0,06 % bei ≥ 0,2 % Stufen). Auswertung: U101.

**Praxis-Hinweis (Frage des Nutzers 01.10. 22:26, geprüft):** Hyperliquid kennt je Konto und Coin nur EINE Netto-Position (kein
Hedge-Modus). Grid Long und Grid Short in einem Konto würden sich verrechnen -- in der Probe hielten beide in 244 von 301 Momenten
gleichzeitig Lose. Das Labor rechnet jede Strategie als eigenes Konto; in der Praxis entspricht das je Grid einem Sub-Account
(eigene Adresse, eigene Positionen und Margin; bis 10 ab 100.000 USD Handelsvolumen, gleiche Gebührenstufe wie das Hauptkonto).
Innerhalb eines Grids passt die Rechnung: alle Lose auf einer Seite = eine Position mit Durchschnittspreis, die Stufen-Verkäufe
wären Reduce-only-Limits. Self-trade prevention gilt je Adresse (die ruhende Order wird gelöscht). Gilt für alle Labor-Strategien.
Beide Grids nutzen dieselbe Range, solange beide dasselbe 24-h-Fenster sehen; auseinander laufen sie nach einem Ausstieg (Fenster ab
dem eigenen Ausstieg) und beim Nachführen (Trendprüfung mit Richtung).

## 3κ. „database is locked“ im Labor nach 23.40 (02.10., Version 2026-09-23.41, Opus 5.5)

Befund Pi 02.10. 06:57:46, Labor-Kopf „Meldungen“: „ZEC Handel: OperationalError: database is locked“.

**Ursache (eigener Fehler aus 23.40):** `_grid` öffnete die Transaktion mit einem einfachen `BEGIN` (verzögert), um jedes Grid hinter
einen Sicherungspunkt zu legen. Hatte das Labor in diesem Takt bis dahin noch nichts geschrieben, war das eine LESE-Transaktion: Das
Grid las Lose und Orders, der Lesestand war damit festgelegt. Schrieb danach ein anderer Thread in den Prognosespeicher (Prognose,
Familien, Profis), war dieser Stand veraltet -- der nächste Schreibzugriff des Labors im selben Takt (hier ZEC, Funding/MAE einmal je
Minute) scheiterte SOFORT, ohne die 30 s Wartezeit (Snapshot-Konflikt im WAL-Modus). Genau diese Falle ist im Projekt seit dem 14.09.
bekannt (`hl_recorder.db_connect`: isolation_level „IMMEDIATE“; `hl_dbcoord`: „ein von Hand ausgeführtes BEGIN“).
- Folgen: keine Datenschäden. Der Takt verliert seine Schreibzugriffe (bricht er ab, wird er ganz zurückgerollt, der Zustand neu
  geladen); Grids und Stops holen über die Kerzen nach. Verloren ist höchstens ein 15-s-Signal.
- Nachgestellt: zwei Verbindungen (`BEGIN`; lesen; fremder Commit; schreiben → sofort „database is locked“, mit `BEGIN IMMEDIATE`
  wartet der andere Schreiber); Labor-Probe mit fremdem Commit während der ZEC-Eingaben: 23.40 ein Abbruch in 240 Takten
  (`_zustand_speichern`), Korrektur 0.

**Korrektur:**
- `BEGIN IMMEDIATE`: Schreibsperre gleich zu Beginn, wartet wie jeder Schreibzugriff (30 s). Ist sie länger belegt, setzen nur die
  Grids diesen Takt aus (Meldung), statt den Takt abzubrechen.
- Grids zum Schluss des Takts statt je Coin mittendrin: Die Sperre gilt dann nur für Grids, Zustand und Commit, nicht für die
  Eingaben der übrigen Coins (Labor-Probe: fremde Commits während der ZEC-Eingaben wieder möglich, 180 von 240; Takt 7 ms wie vorher).
  Die Grids handeln getrennt von den übrigen Strategien; Ergebnisse im Selbsttest Zahl für Zahl gleich.
- Selbsttest „Grid: fremder Schreiber im Takt, kein database is locked“: ein zweiter Schreiber commitet, während das Grid liest; mit
  dem alten `BEGIN` rot (genau die Meldung vom Pi), jetzt grün.

## 3λ. Fusionsprognose, Kalibrierung v3, Kostenschwelle — Stufe 1 im Schatten (04.10., Version 2026-09-23.42, Opus 5.5)

Anlass, Nutzer nach 23.41: „Hast du Ideen oder Überlegungen, ob es mathematische oder psychologische Ansätze gibt, … die
Kursprognose mit einem fusionierten Treiber in eine Formel zu packen, die einen noch besseren prädiktiven Wert erzielt?“ Antwort:
Werkzeugkasten (Bewertungsregeln, Kostenschwelle, Teilen über Coins, Expertenmischung mit Garantie, Schwankungsmodelle, konforme
Bänder, Berührwahrscheinlichkeit, Hawkes, Einstandsanker, Stop-Jagd, Herdenmaß, Regime-Tor) in drei Stufen. Danach: „Leg los.
Mach es perfekt und fehlerfrei.“ Konzept und Begründungen: **`KONZEPT_Fusion.md`** (neu im Paket). Plan: U104–U112.

**1. Gebaut (`hl_fusion.py`, neu; alles im Schatten — angezeigte P(aufwärts), Pfad, Bias, Kaufpreise unverändert).**
- **Kostenschwelle (U104):** p* = ½ + K / (2 · E|r_h|) je Coin für 1/4/12/24 h. E|r_h| gemessen: Mittel |ln(P(t+h)/P(t))| über
  30 Tage im 15-min-Raster (≥ 288 Punkte). K Taker = 2 · (Taker-Gebühr + halber Spread, Median der letzten Stunde aus
  `book_summary`), K Maker = 2 · Maker-Gebühr, Sätze aus `hl_labor` (XMR doppelt). Je Coin stündlich, im Payload als `kosten`.
- **Kalibrierung v3 (U105):** p = sig(a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f) auf den sieben Richtungsfamilien (ohne Stärke,
  Pool-Konten, Profi-Flow), gemeinsame Gewichte β, Abweichung je Coin δ mit Strafe r · λ_β (r ∈ {∞, 64, 16, 4, 1}), Achsenabschnitt
  je Coin, Kalibrierfaktor c ∈ {0; 0,1; …; 1}. Daten wie v2 (90 Tage, früheste Prognose je Block, Toleranz-Labels, 14 Tage
  Halbwertszeit, U41). Stündlich in `_familien_takt` (erstmals 5 min nach dem Start), learned „*“/`kalib3_4`, `kalib3_24`, Fehler in
  `kalib3_h_fehler`; jede Prognose trägt `p_up_v3` (gespeichert) und `p_up_24_v3`.
- **Fusion (U106):** Mischung der Experten Basisrate, v1, v2 (ab Modellversion 2), v3, Analog (50 Pseudo-Fälle zur eigenen
  Basisrate); p geklemmt auf [0,02; 0,98]; Bayes-Update nur für wache Experten (schlafende behalten ihr Gewicht), Fixed Share
  α = min(0,05; h/336); Garantie L_Fusion − L_m ≤ ln 5 + (T − 1) · ln(1/(1 − α)). Tabelle `fusion_fall` im Prognosespeicher
  (eine Zeile je Coin, Horizont, Block; die früheste Prognose zählt), Auflösen nach h (y = −1 unter der Toleranz, −2 ohne Kurs
  nach einem Tag), einmaliger Nachtrag aus den gespeicherten Prognosen (60 Tage), prequential. Bilanz mit Abstand zur Basisrate
  ± 1 Standardfehler; im Debug zusätzlich nur live gestellte Blöcke und alle Coins zusammen (Zeitblöcke als Klumpen).
- **Labor (U107):** „Prognose Fusion“ (`prognose_fusion@40662765`, feste Schwelle wie v1) und „Fusion mit Kostenschwelle“
  (`prognose_fusion_kosten@aefe5404`: nur wenn |2p − 1| · E|r 4 h| ≥ 1,5 × (2 · Taker + Abstand zur Buchmitte bei 10.000 USD,
  Ein- und Ausstieg)). `_prog` liest `$.fusion.p_4` und `$.kosten.er_4` aus dem Payload. Die 35 übrigen Kennungen unverändert.
- **Einbau:** `hl_viz._forecast_compute_inner` ruft `hl_fusion.ergaenzen` vor `store_forecast` (ein Fehler hält die Prognose nie
  an, er steht in `fusion.fehler`); Kacheln „P(aufwärts) Fusion — Schatten“ (AI-Prognose) und „Fusion und Kalibrierung v3“
  (Selbstoptimierung); Debug „★ Fusion und v3“ und „Fusion, v3 und Kostenschwelle: Selbsttest“; Berichtsplan wöchentlich (W11),
  einmal 11.10. 19:30 (`u106-fusion-woche1`) und 25.10. 19:30 (`u108-fusion-auswertung`). `hl_forecast`: `p_up_24_v1` im Ergebnis,
  `store_forecast` lässt `fusion_info`, `kalib3`, `kalib3_24` (Anzeige) aus dem Payload. `install.py`: Selbsttest-Schritt
  „Fusion, v3, Kostenschwelle“ (28 Schritte). `update.py`: `hl_fusion.py`, `KONZEPT_Fusion.md` in PROJECT_FILES.

**2. Entscheidungen beim Bau.**
- **Familienwerte statt Treiber** in v3: 7 statt rund 30 Gewichte; Teilen über Coins braucht Größen, die überall dasselbe messen.
- **Kein Familien-Experte:** Die Familien-Prognose wird nicht je Prognose gespeichert (kein Nachtrag), und bis eine Familie
  aufsteigt, ist sie eine Basisrate ohne Halbwertszeit — ein Doppel, das nur ln M kostet (Stufe 3, U112).
- **λ-Wahl:** verglichen wird der OOF-Treiberanteil mit Achsenabschnitten je Coin aus denselben OOF-Fällen (mit denen der
  Trainingsfolds lag jeder OOF-Verlust über ln 2: Drift eines Zeitraums passt nicht auf den nächsten), 1-SE-Regel mit GEPAARTEM
  Standardfehler über Zeitblöcke (mit der Streuung der Fold-Mittel wählte sie fast immer das stärkste λ). Min-CV ohne 1-SE geprüft:
  nicht besser, dafür mutiger im Rauschen.
- **Payload schlank:** Gespeichert werden nur `fusion` (p, Anteile), `kosten`, `p_up_v3`, `p_up_24_v1` (rund 0,6 kB je Prognose);
  Bilanz, Experten und v3-Zusammenfassung zusammen wären rund 4,2 kB je Prognosezeile gewesen.
- **Schreiben mit `BEGIN IMMEDIATE`** (`_schreiben`, Lehre aus 23.41).

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- Kosten-Theorietest mit 19,9 % Abweichung auf 24 h: Stichprobenrauschen (30 Tage = 30 unabhängige Tagesfenster) — jetzt
  400 Tage und Abweichung in Standardfehlern.
- „Rauschen → die Basisrate trägt die Mischung“ war eine falsche Erwartung: Fixed Share hält die Gewichte gemischt. Richtiges
  Kriterium: Verlust innerhalb der Grenze und nicht sicherer als die Basisrate.
- Ende-zu-Ende-Prüfung auf den Gesamtgewichten (57 %): Schlafende Experten halten Gewicht — maßgeblich sind die Anteile der
  Wachen (96 %).
- Probe-Daten mit `hash()` waren je Prozess zufällig (Texte werden je Prozess anders gehasht) — feste Formel.
- v3 war übervorsichtig (siehe λ-Wahl); Teilen-Probe bei 0,60/21 Tagen wackelte — nach 20 Szenarien (v3 ≈ 3 × v2) bei 0,62/30
  Tagen mit Kriterium „v3 > 0,15 und ≥ 2 × v2“; Probe „Kante nur in einem Coin“ mit „r gewählt in ≥ 4 von 5“.
- Training gegen Vorhersage auf 10⁻⁹ verlangt: gespeicherte Koeffizienten sind auf 5 Stellen gerundet → 10⁻⁴ (gemessen 5,4·10⁻⁶).
- 1 px Überlauf am Desktop durch den langen Debug-Titel in `#dbgselect` — Titel gekürzt.
- Bei der Schlussdurchsicht dazu: Abstand zur Basisrate ± Standardfehler in Kachel und Debug, Bilanz über alle Coins mit
  Zeitblöcken als Klumpen (der naive Standardfehler war in der Probe 1,75-mal zu klein), Zeilen „nur live gestellt“, ein
  Rauchtest des Debug-Berichts im Selbsttest, Termin U108 im Berichtsplan.

**4. Proben.**
- `python3 hl_fusion.py --nulltest` (27 Prüfungen, 26 s): Kosten 4 (E|r| = Theorie in SE, Schwelle, XMR, ohne Kurse), Fusion 10
  (Grenze auf 90 Folgen auch gegnerisch und mit Schläfern: 0 Verletzungen; Rauschen +2,61 Nats über 600 Blöcke bei Grenze 8,78;
  guter Experte 85 %; Regimewechsel 234 gegen 290 Nats; Schläfer; prequential; ohne Urteil; Basisrate; Abstand ± SE; alle Coins
  mit Klumpen), Ende zu Ende 5 (Nachtrag 60 Blöcke, v2-Anteil 96 %, zweite Prognose im Block, Toleranz, unabhängige Nachrechnung
  4,9·10⁻⁶, Debug-Bericht), v3 8 (U41; Tor 0,65 → +0,48, wahr +0,62; Rauschen 0,0 Punkte; vorsichtige Wahl 5/5; Training =
  Vorhersage; Gleichlauf ≤ 3,6 Punkte; Teilen +0,26 gegen v2 +0,08; Kante in einem Coin +0,37 gegen +0,08).
- Mutationen: 19 von 19 im Fusions-Selbsttest rot (Schläfer wie 50 %, ohne Fixed Share, Mischung/Nachtrag/Basisrate sehen die
  Zukunft, Toleranz als Richtung, Schwelle ohne Faktor 2, Spread einmal, falscher Horizont, v3 ohne Abweichung/ohne Teilen,
  mutiger Kalibrierschritt, λ ohne 1-SE, Skala vergessen in Training/Vorhersage, U41, Standardfehler ohne √n, Bilanz mit Blöcken
  ohne Urteil, alle Coins ohne Klumpen); 5 von 5 im Labor-Selbsttest (Kosten nur einer Seite, Puffer ignoriert, XMR-Faktor
  vergessen, Vorsprung halbiert, falsches Feld aus dem Payload).
- `hl_labor.py --selbsttest` grün (drei neue Prüfungen), `hl_forecast.py --nulltest`, `check_treiber.py` 77/77,
  `hl_viz.py --selbsttest-last`, `node --check` beider Skriptblöcke, Namensprüfung.
- Demo (5 Coins, 18 Tage Prognosen mit 58-%-Kante im Taker-Flow): `v3_takt` 0,4 s, `ergaenzen` rund 0,05 s je Coin, v3-Fit über
  90 Tage × 6 Coins 0,9 s; Kacheln am Handy (390 px) und Desktop ohne Überlauf und ohne JS-Fehler; Labor zeigt beide Strategien.
- Last: Kostenschwelle über 30 Tage Minutenkerzen auf einer Tabelle in Recorder-Form (PK ts, coin, WITHOUT ROWID; 12 Coins,
  40 Tage) 0,06 s je Coin, Zwischenspeicher 1 h.
- `install.py --selftest` aus dem Paket: 28 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- Erste Prognose je Coin nach dem Update: einmaliger Nachtrag aus 60 Tagen gespeicherter Prognosen (je Coin und Horizont einige
  Sekunden), danach eine live gestellte Zeile je Block. Die Kachel zeigt sofort eine Fusionszahl und eine Bilanz aus dem Nachtrag.
- v3 erstmals 5 min nach dem Start, dann stündlich; „zu wenige Fälle“ ist für junge Coins möglich (je Coin ≥ 15 Fälle). Bis
  dahin schläft v3 in der Mischung.
- Labor: zwei neue Strategien in der Gruppe Prognose. „Fusion mit Kostenschwelle“ handelt selten (4 h als Taker braucht rund 57 %).
- Berichte: W11 mittwochs 19:00, einmal 11.10. 19:30, Auswertung U108 25.10. 19:30.
- Speicher: Payload +0,6 kB je Prognose, `fusion_fall` rund 7 Zeilen je Coin und Tag.

**Was man wissen muss:** Die Daten sind knapp — rund 237 effektive 4-h-Blöcke je Coin (14 Tage Halbwertszeit), Standardfehler der
Trefferquote 3,3 Punkte; eine Kante von 55 % ist je Coin nicht belegbar, auf 24 h vergehen Monate. Ohne echte Kante ist die Fusion
im Log-Verlust etwas schlechter als die Basisrate (Rauschprobe 0,004 Nats je Block); die Bilanz sagt dann „nicht belegt“. Auf 4 h
braucht ein Taker-Handel rund 57 % Trefferquote. Umgeschaltet wird nur nach U108 (Kriterien in `KONZEPT_Fusion.md`, Abschnitt 6).

## 3μ. Kaskaden-Gleichung im Schatten — Stufe 2b (04.10., Version 2026-09-23.43, Opus 5.5)

Anlass, Nutzer nach dem Einspielen von 23.42: „… ob es nicht möglich wäre eine komplexe Funktionsgleichung abzuleiten, welche den
Kurs im voraus annähernd berechnet. Hättest du Ansätze dafür?“ Antwort in Kurzform:
- Eine Gleichung für den Kurs selbst hebt sich auf (Samuelson 1965, Grossman/Stiglitz 1980).
- Ein Trend ist auf kurzen Horizonten nicht belegbar (Merton 1980: der Beleg wächst mit μ · √T / σ; 30 % im Jahr brauchen rund 9 Jahre
  für 2 Standardfehler).
- Komplexe Modelle passen sich dem Rauschen an (Stock-to-Flow).
- Für die **Verteilung** des Kurses lässt sich eine Gleichung bauen und prüfen.
- Das Power Law, ehrlich gerechnet: auf 4 h 50,6 % P(aufwärts), auf ein Jahr 76 %. Santostasis Zyklusprognose traf außerhalb der
  Stichprobe den Boden, die Spitze um den Faktor 1,7 nicht.
- Vorschlag: Strukturgleichung d ln P = [5,8/t − κ (ln P − ln PL) + β · x] dt + σ(t) dW + J dN. Zuerst der Sprung-Teil J dN, aus den
  eigenen Heatmap-Daten.

Danach: „Leg los“. Konzept: **`KONZEPT_Fusion.md`, Abschnitt 4b** (neu). Plan: U113–U117, W12.

**1. Gebaut (`hl_kaskade.py`, neu; alles im Schatten — angezeigte Prognose, v1, v2, v3 und Fusion unverändert).**
- **Mathematik:**
  - Wirkung: I(Q) = Y · σ_Tag · √(Q / V_Tag), mit σ_Tag = σ_4h · √6 und V_Tag = 24 × Median-Stundenvolumen (`hl_anker.Markt`, dieselben
    Größen wie der Heatmap-Anker).
  - Kaskade als kleinster Fixpunkt u = u_exo + I(Q(u)) (`ende`: Präfixsummen und bisect).
  - Geschlossene Form H(m), in reinem Python (`h_werte`) und als numpy-Feld über Y und Schwellen (`h_feld`).
  - P(Ausschlag ≥ m binnen h) = erfc(H / (c · σ_h · √2)) (`p_ueber` mit math.erfc). Im Feld rechnet eine erfc nach Numerical Recipes
    (relativer Fehler 1,0 · 10⁻⁷), weil scipy auf dem Pi fehlt.
  - Cluster zählen nur auf der richtigen Seite (Long unter, Short über dem Kurs), bis zur Tiefe min(25 %, 6 σ_4h).
- **Live (`zustand`):**
  - Quelle ist der jüngste Heatmap-Stand, höchstens 30 min alt.
  - Zwischenspeicher je Datenbankdatei, Coin und Prognosespeicher. Er wird je Heatmap-Stand neu gefüllt, spätestens nach 15 min. Den
    Kurs setzt jeder Aufruf neu ein.
  - Berechnet werden:
    - der Kipppunkt (Raster 0,02 σ_4h bis 3 σ_4h; die Kaskade trägt ≥ 0,5 σ_4h weiter) und sein Ende,
    - das Ende nach 1 σ und nach 3 σ Ausschlag,
    - der Mehrweg ∫ (P_Kaskade − P_Zufall) dm in σ_4h,
    - die Asymmetrie (m_auf − m_ab) / (m_auf + m_ab + 0,1), mit Y = 1 und c = 1 fest.
- **Treiber „Kaskaden-Asymmetrie“:**
  - `hl_forecast.compute_forecast` ruft `hl_kaskade.treiber` nach dem Pool-Treiber auf. Gewicht 0; ein Fehler landet mit Grund in
    `missing`.
  - Steht in `SCHATTEN_TREIBER`, bewusst NICHT in `PRIORS`.
  - Neue Familie „Kaskaden“ in `hl_familien` (4 h, Richtung). Sie ist von v3 ausgenommen (`hl_fusion._v3_familien`, weiterhin 7
    Familien).
  - In der Treibertabelle steht statt der Trefferquote „Bilanz in der Familie Kaskaden“; der Tooltip nennt den Grund.
- **Payload und Anzeige:**
  - `hl_viz._forecast_compute_inner` ruft `hl_kaskade.ergaenzen` nach der Fusion auf, im try; ein Fehler hält die Prognose nie an.
  - Gespeichert wird `kaskade` = {v, ts, A, y_kipp, kipp_ab, ende_ab, mehr_ab, kipp_auf, ende_auf, mehr_auf}. Sobald ein 4-h-Modell
    gespeichert ist, kommen Y4, belegt4, p2_ab, p2_auf und p2_basis dazu. In der Demo sind das 171–204 Zeichen.
  - `kaskade_info` dient nur der Kachel; `store_forecast` lässt es aus.
- **Kalibrierung (`kalibrieren`, `takt`):**
  - Takt: alle 6 h im Familien-Takt des Dashboards, erstmals 15 min nach dem Start. Coins: alle aus `forecast_drivers` der letzten
    24 h. Je Coin und Horizont (1 h, 4 h).
  - Daten: je Block der erste Heatmap-Stand der ersten 15 min. Zwei gezielte Abfragen je Block, siehe Abschnitt 3.
  - Ereignisse je Seite: „Ausschlag ≥ k · σ_h“ für k = 0,5/1/1,5/2/3, aus Minutenhoch und -tief, bewertet mit dem Log-Verlust.
  - Wahl:
    - Gitter Y × c (7 × 21), 5 Folds geblockt mit Embargo 1 Block.
    - 1-SE-Regel zum kleineren Y (gepaarter Standardfehler, Tage als Klumpen).
    - Mindestens 120 Blöcke.
  - Dazu: Placebo, Seitenspiegel, Brier-Skill ≥ 1 σ und ≥ 2 σ (out-of-fold), Zuverlässigkeit, Richtungsprobe (|A| ≥ 0,3, 4 h) und
    die Abdeckung der Heatmap.
  - Gespeichert als learned coin/„kaskade“, gültig 3 Tage. Ein Fehler wird je Coin gespeichert und angezeigt.
- **Dashboard:**
  - Kachel „Kaskaden-Gleichung — Schatten“ in der AI-Prognose, nach der Fusionskachel.
  - Etikett „Schatten“ mit eigenem Tooltip in der Treibertabelle.
  - Farbe der Familie „Kaskaden“.
  - Drei Debug-Einträge: „★ Kaskaden-Gleichung (Schatten)“, „… jetzt kalibrieren“ und „… Selbsttest“.
  - Berichtsplan: Wochenprüfung (W12, mittwochs 19:00), dazu einmalig `u113-kaskade-woche1` am 11.10. 19:45 und
    `u115-kaskade-auswertung` am 25.10. 19:45.
- **Labor (U114):**
  - Neue Strategie „Kaskaden-Kipppunkt“ (`kaskade_kipppunkt@738d23ea`, Gruppe Ereignisse) mit Signal `sig_kipppunkt` und Tafeltext.
  - `_prog` liest Kipppunkte und Enden aus dem Payload.
  - Die 37 übrigen Kennungen sind unverändert.
- **Einbau:**
  - `install.py`: Selbsttest-Schritt „Kaskaden-Gleichung“, damit 29 Schritte.
  - `update.py`: `hl_kaskade.py` in PROJECT_FILES.
  - `check_treiber.py`: `test_kaskade` mit 6 Szenarien.
  - `version.py`: 23.43, `hl_kaskade.py` in PROJEKTDATEIEN.

**2. Entscheidungen beim Bau.**
- **Nicht in PRIORS:** v1 lernt nur über die Namen in PRIORS, v2 nimmt PRIORS ohne SCHATTEN_TREIBER. Außerhalb von PRIORS bleibt der
  Treiber aus beidem heraus, steht aber in `forecast_drivers` und damit in Familie, Ereignis-Profilen und Hygiene.
- **Festes Y = 1 für Treiber und Kipppunkt:**
  - Die Reihe bleibt über die Zeit vergleichbar; sonst spränge sie mit jeder Kalibrierung.
  - Das kalibrierte Y wirkt auf die Wahrscheinlichkeiten. Auf Kipppunkt und Ende im Payload wirkt es erst, wenn es für 4 h belegt ist
    (`y_kipp` zeigt, welches Y galt).
  - Die Regel der Labor-Strategie bleibt dabei gleich; nur ihre Eingabe wird genauer.
- **Vier Bedingungen für „belegt“.** Das Zeit-Placebo allein reichte nicht:
  - Im Störfaktor-Markt (nahe Cluster gehen mit höherer Schwankung einher, ohne Mechanik) ließ es 1 von 4 Läufen durch.
  - Der Seitenspiegel (dieselben Cluster mit vertauschten Seiten) trennt Mechanik von bloßem Mitlaufen der Schwankung.
- **Y ist ein effektiver Wert:** Die Heatmap sieht nur die verfolgten Konten, und σ_Tag enthält die Kaskaden selbst. In der Probe wird
  ein wahres Y = 2 als 1 gefunden, und c sinkt auf 0,7.
- **Vergleichsgröße „ohne Heatmap“:** derselbe Zufallsweg, mit c₀ aus allen Blöcken. Zuerst hieß sie „ohne Kaskaden“, das war
  irreführend.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Seitenspiegel als vierte Bedingung:** Im Störfaktor-Markt (Seed 3) gab es mit dem Zeit-Placebo allein einen Fehlbefund.
- **Speicher der Kalibrierung (Lastprobe im ungünstigen Fall):**
  - Der Entwurf las jeden Block ganz (`ts % Block < 900`, alle Eimer).
  - Geprüft mit 800 Eimern je Stand, wie sie ein Coin mit vielen verfolgten Positionen im 0,25-%-Raster tragen kann.
  - 30 Tage kosteten 5,5 s und 354 MB Prozessspeicher; 90 Tage wären rund 1 GB im Dashboard-Prozess geworden.
  - Die Lastprobe vorher hatte nur 100 Eimer je Stand und das nicht gezeigt.
  - Jetzt laufen je Block zwei Abfragen über Index und Schlüssel: der erste Stand per `MIN(ts)` über `ix_heat_coin_ts`, dann nur die
    Eimer bis zur größten Clustertiefe über den Primärschlüssel.
  - Ergebnis: 30 Tage 0,4 s und 53 MB, 90 Tage 1,5 s und 91 MB.
  - Die Ausgabe ist Block für Block identisch: Lastdatei, Demo (5 Coins), Probe-Markt und eine neue Selbsttest-Prüfung mit 115.240
    zusätzlichen tiefen und falschseitigen Eimern.
- **Live-Probe:** Das Cluster mit 3 % des Tagesumsatzes trug keine 0,5 σ weiter, es gab also zu Recht keinen Kipppunkt. Die Probe
  nimmt jetzt 8 % und prüft den Kipppunkt im Raster.
- **Kachel:**
  - Sie zeigte „Kalibrierung ausstehend“, obwohl 1 h schon kalibriert war. Jetzt nennt sie den Grund je Horizont.
  - Die P-Zeile nimmt das 1-h-Modell, solange 4 h fehlt.
- **Treibertabelle:** Die Trefferzelle zeigte „nie |Score| > 0,05“, das war falsch, der Score lag bei 0,45. Grund: Der Treiber steht
  nicht in PRIORS und bekommt daher keine v1-Bilanz. Jetzt steht dort „Bilanz in der Familie Kaskaden“.
- **Selbsttest:** Unter einer Mutation brach die Textausgabe der Mathe-Probe ab (None). Jetzt meldet sie ein sauberes FEHL.
- **Docstrings:** Die Bedingungen für „belegt“ (mit Seitenspiegel) und die Payload-Größe sind nachgezogen.

**4. Proben.**
- `python3 hl_kaskade.py --nulltest`: 15 Prüfungen, 14 s.
  - Mathe 5:
    - geschlossene Form = Fixpunkt in 120.000 Vergleichen auf 300 Karten mit Y 0–8, 0 Abweichungen,
    - Feld = Schritt,
    - erfc 1,0 · 10⁻⁷,
    - ohne Kaskaden der Zufallsweg,
    - Kipppunkt und Kette exakt.
  - Positivkontrolle 1 h (Y wahr 2): Y 1 in 3 von 3, Abstand +0,36 … +0,42 je Block bei ≥ 10 SE, belegt 3 von 3.
  - Positivkontrolle 4 h: belegt 3 von 4.
  - Nulltest: Y = 0 in 4 von 4.
  - Störfaktor: nie belegt; der Spiegel verhindert einen Fehlbefund.
  - Blöcke: gezielt = alles gelesen.
  - Live 5: Kipppunkt, Spiegel, veralteter Stand, Payload, gespeicherte Kalibrierung mit Debug-Bericht.
- Mutationen: 20 von 20 rot.
  - 15 in `hl_kaskade`: Wurzel, Fluss davor, eigenes Cluster im Feld, Reflexion ohne Faktor 2, Ende ohne Kette, 1-SE zum größeren Y,
    ohne Spiegel, Placebo mit eigener Karte, falsche Seite, Kipppunkt ohne Mindest-Reichweite, Training sieht Testblöcke, veralteter
    Stand, Vorzeichen der Asymmetrie, Eimer-Fenster zu schmal, letzter statt erster Stand.
  - 4 im Labor: mehrfach, ohne Kostenfilter, Richtung vertauscht, nach dem Ende.
  - 1 in der Prognose: Treiber nicht im Schatten.
- Weitere Selbsttests, alle grün:
  - `check_treiber.py`: 83 von 83.
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`.
  - `node --check` beider Skriptblöcke.
  - Berichtsplan: alle Läufe vorhanden, Termine richtig.
- Demo (Cluster ohne Mechanik, 5 Coins, 12–18 Tage Heatmap):
  - 1 h: Y = 0 in 5 von 5, nicht belegt. Ein realistischer Nulltest.
  - 4 h: zu wenige Blöcke (71–110 von 120).
  - Richtungsprobe: |z| ≤ 1,5.
  - Kachel, Etikett, Trefferzelle, Familie und Labor-Strategie im Browser am Handy (390 px) und am Desktop ohne Überlauf und ohne
    JS-Fehler.
- Last: Live-Stand 0,02 s; Kalibrierung siehe Abschnitt 3.
- `install.py --selftest` aus dem Paket: 29 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Erste Prognose nach dem Update:** Der Treiber „Kaskaden-Asymmetrie“ steht in der Tabelle mit Etikett „Schatten“; die Kachel zeigt
  die Kipppunkte. Ohne Heatmap-Stand der letzten 30 min steht dort „—“ mit Grund.
- **Kalibrierung:** 15 min nach dem Start, dann alle 6 h.
  - 1 h hat sofort genug Blöcke (rund drei Wochen Heatmap).
  - 4 h braucht 120 Blöcke, also rund 20 Tage Aufzeichnung; das Placebo drei Tage mehr.
  - Bis Y belegt ist, rechnen Kipppunkt und Treiber mit Y = 1. „Nicht belegt“ ist ein gültiges Ergebnis.
- **Rechenlast:** rund 2–5 s je Coin alle 6 h (Sandbox 1,5 s bei 90 Tagen und 800 Eimern, der Pi ist langsamer).
- **Speicher:** Payload +0,2 kB je Prognose, eine learned-Zeile je Coin.
- **Labor:** „Kaskaden-Kipppunkt“ handelt selten, nur beim Durchbruch durch einen Kipppunkt und mit Weg ≥ 1,5 × Kosten.
- **Berichte:** W12 mittwochs 19:00, einmalig am 11.10. 19:45 (erste Woche) und am 25.10. 19:45 (Auswertung U115).

**Was man wissen muss:** Die Gleichung ist eine Hypothese mit Messung, kein Signal. Wahrscheinlich ist Y bei BTC und ETH klein oder
nicht belegt, bei ZEC, XMR und HYPE eher sichtbar. Ob die Asymmetrie die Richtung vorhersagt, ist offen: Eine Rutschgefahr nach unten
kann im Mittel durch mehr kleine Anstiege ausgeglichen sein. Eingeschaltet wird nur mit Beleg, als Sprung-Teil der Verteilungsprognose
(U116). Kriterien: U115.

## 3ν. Erste echte Kalibrierung der Kaskaden-Gleichung: gemischte Schwankung, Spiegel beim gleichen Y (04.10., Version 2026-09-23.44, Opus 5.5)

Anlass: Der Nutzer hat 23.43 eingespielt und drei Debug-Ausgaben geschickt.
- Rundum-Funktionstest: in jeder Quelle FEHL 0.
- Kaskaden-Selbsttest auf dem Pi: grün in 25 s.
- „jetzt kalibrieren“: 6 Coins in 8,5 s, 26,7 Tage Heatmap, Abdeckung 25–29 % des OI.
Die Zahlen stehen in `KONZEPT_Fusion.md`, Abschnitt 4b.1a. U110 (Berührwahrscheinlichkeit) war für heute geplant. Es kommt danach,
weil es auf dem hier korrigierten Nullmodell aufsetzt.

**1. Befunde (eigene Fehler aus 23.43).**
- **Wahrscheinlichkeiten großer Ausschläge zu niedrig, in allen Coins und beiden Horizonten.** Ausschläge ≥ 2 σ, vorhergesagt gegen
  eingetreten: BTC 1 h 2,9 → 5,8 % (n 1.268), ETH 1,9 → 4,1 %, XMR 1,7 → 5,3 %, ZEC 3,2 → 5,2 %; 4 h BTC 3,3 → 4,8 %,
  HYPE 4,1 → 6,6 %.
  - Ausschläge ≥ 1 σ waren dagegen seltener: 19–28 % statt 31,7 %.
  - Ursache: σ_h kommt aus 7 Tagen und trifft die einzelne Stunde schlecht. Ruhige und heiße Stunden ergeben zusammen eine dünne
    Mitte und dicke Ränder. Das Reflexionsprinzip mit fester Schwankung kennt das nicht.
  - Die synthetischen Märkte von 23.43 hatten keine Schwankung mit Gedächtnis und konnten das nicht zeigen. Ein Testmarkt mit ihr
    (log-σ als AR(1) je Stunde, τ 0,6) erzeugt genau das Muster vom Pi: 3,0 → 4,7 · 3,4 → 6,1 · 4,0 → 7,9 %.
- **Richtungsprobe mit n = 1:** PAXG „1 Block, 100 % ± 10 %, z +5,0“. Der Standardfehler hatte einen Boden von 0,1, und eine
  Mindestzahl fehlte.
- **Selbsttest nicht isoliert:** Die Live-Probe las den echten Prognosespeicher (auf dem Pi 268 statt 183 Zeichen Payload, Bilanz und
  Richtung des echten BTC-Modells). Geschrieben hat sie dort nichts; das Kalibrier-Speichern der Probe nutzte schon einen eigenen Pfad.

**2. Gebaut.**
- **Gemischte Schwankung (Modell v2):**
  - P(Ausschlag ≥ m) = Σ_k w_k(τ) · erfc(H(m) / (c · e^{0,05·k} · σ_h · √2)), log-normal um c mit Streuung τ; τ = 0 ist das
    Reflexionsprinzip.
  - c (log-Raster 0,41–1,57) und τ ∈ {0; 0,3; 0,6; 0,9} werden je Y in den Folds gewählt (112 Paare).
  - erfc wird einmal je Raster-Exponent gerechnet, dann je Paar als gewichtete Summe (Matrix W @ E), in Stücken zu 100 Blöcken.
  - Live (`p_ueber`) rechnet dieselbe Mischung einzeln. Kachel, Payload (`p2_*`) und Bericht nutzen (c, τ), die Basis „ohne
    Heatmap“ (c₀, τ₀).
  - `VERSION = 2`: Gespeicherte v1-Kalibrierungen gelten nicht mehr (`modell_laden`). Nach dem Update steht bis zum ersten Takt
    „Kalibrierung ausstehend“.
- **Unverändert gelassen:** Treiber „Kaskaden-Asymmetrie“ (Mehrweg mit Y = 1, c = 1, τ = 0) und Kipppunkt/Ende (deterministisch,
  Y_REF). Beide werden vorwärts gemessen (Familie „Kaskaden“, Labor „Kaskaden-Kipppunkt“). Der Selbsttest nagelt sie auf den Wert von
  23.43 fest: Treiber −0,8001767487069966, Kipppunkt 0,5045 %, Ende 1,1286 %, Mehrweg 0,40105.
- **Seitenspiegel beim gleichen Y:** Verlust Spiegel minus echt beim gewählten Y, je mit c und τ seines Folds (vorher: der Spiegel mit
  seinem eigenen Y). Bericht: „Seitenspiegel (eigenes Y …, verglichen bei Y …)“.
- **Bericht** (Debug „★ Kaskaden-Gleichung“):
  - out-of-fold „vorhergesagt, eingetreten, Abstand ± SE ✓/✗“ für ≥ 2 σ und ≥ 1 σ (Kriterium 2 von U115, `kal_2`, `kal_1`, Tage als
    Klumpen);
  - Zuverlässigkeit für ≥ 2 σ und ≥ 1 σ, nur Klassen ab 20 Fällen;
  - τ und c₀/τ₀ in den Modell- und Kalibrierzeilen;
  - eine Zeile „Richtung über alle Coins“ mit dem Hinweis auf den Mehrfachtest.
- **Richtungsprobe:** erst ab 20 Blöcken (`RICHTUNG_MIN`), z mit dem Standardfehler der Nullhypothese √(0,25/n), dazu die Treffer für
  das Poolen.
- **Selbsttest:**
  - Mathe-Prüfungen zur Mischung (Tabelle = Einzelrechnung = Integral, Ränder dicker mit τ), zur Richtungsprobe und zur
    Kreuzvalidierung (kein Blick in die Testblöcke, Embargo).
  - Testmarkt mit Schwankung mit Gedächtnis (`_probe_markt(sv_tau, sv_rho)`): ohne Kaskaden Y = 0, τ erkannt, ≥ 2 σ richtig; mit
    Kaskaden belegt.
  - Live-Probe mit eigenem Prognosespeicher (`F.STORE` umgelenkt; `learned_save` mit ausdrücklichem Pfad, weil Python Standardwerte
    beim Definieren bindet), Durchleitung einer gespeicherten 4-h-belegten Kalibrierung (v1 wirkt nicht, v2 schon).
  - `kalibrieren(horizonte=…)`, damit der Selbsttest nur den geprüften Horizont rechnet.
- **Kachel:** Die Erklärung nennt die Mischung. Sonst ist nichts geändert; Feldnamen und Payload-Felder sind gleich.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Spiegel:** Mit der Mischung wurde im Störfaktor-Markt Seed 3 belegt, ein Fehlbefund. Der Spiegel wählte Y = 0, und „Spiegel minus
  echt“ war damit dieselbe Zahl wie „Y = 0 minus gewählt“ (2,2 SE). Jetzt wird beim gleichen Y verglichen: Seed 3 liegt bei 1,4 SE,
  nicht belegt. Die Positivkontrollen sind gleich geblieben (1 h 3 von 3, 4 h 3 von 4).
- **Laufzeit:** Der Selbsttest brauchte mit allen Horizonten 48 s. Jetzt rechnet jeder Probe-Lauf nur seinen Horizont, das sind rund
  40 s.
- **Mathe-Probe:** Unter der Mutation „nur τ = 0“ brach sie mit IndexError ab. Jetzt passt sie sich dem τ-Raster an; die Mutation fängt
  der Testmarkt mit Schwankung mit Gedächtnis.
- **Kreuzvalidierung:** Die Mutation „Training sieht die Testblöcke“ blieb mit dem neuen Modell unentdeckt (24 von 25). In 23.43 fing sie
  nur nebenbei der Störfaktor-Markt; mit zwei freien Parametern je Y wirkt das Leck kaum auf die Ergebnisse. Jetzt gibt es eine eigene
  Prüfung im Mathe-Teil: Testblöcke und Nachbarblock (Embargo) bevorzugen dort einen anderen Parameter, und `_waehlen` darf ihn nicht
  nehmen. Neu dazu die Mutation „ohne Embargo“.

**4. Proben.**
- `python3 hl_kaskade.py --nulltest`: 21 Prüfungen, rund 40 s.
  - Mathe 8.
  - Kalibrierung 7:
    - Positivkontrolle 1 h: belegt 3 von 3 (Abstand +0,32 … +0,37 bei ≥ 10 SE).
    - Positivkontrolle 4 h: belegt 3 von 4.
    - Nulltest: Y = 0 in 4 von 4.
    - Störfaktor: nie belegt; der Spiegel verhindert 3 Fehlbefunde.
    - Schwankung mit Gedächtnis ohne Kaskaden: Y = 0 und τ 0,6 in 3 von 3; ≥ 2 σ 5,8 → 4,7 · 5,6 → 6,1 · 7,3 → 6,7 %, im Mittel
      −0,4 ± 0,75 Punkte.
    - Schwankung mit Gedächtnis mit Kaskaden: belegt 2 von 2.
    - Blöcke gezielt = ganz gelesen.
  - Live 6.
- Gegen einen Köder-Speicher geprüft (HL_FORECAST_DB mit belegter BTC-Kalibrierung, Y 8): Die Probe übersieht ihn (Payload 183 Zeichen),
  und seine Zeile ist danach unverändert.
- Mutationen: 26 von 26 rot. Das sind die 20 aus 23.43, die Reflexion jetzt in der Tabelle, und neu:
  - nur τ = 0;
  - Mischungsgewichte ohne Normierung;
  - Spiegel mit eigenem Y;
  - Live-Probe liest den echten Speicher (mit Köder-Speicher je Lauf);
  - Richtungsprobe ohne Mindestzahl;
  - Kreuzvalidierung ohne Embargo.
- Weitere Selbsttests grün:
  - `check_treiber.py`: 83 von 83 (Treiber unverändert).
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`.
  - `node --check` beider Skriptblöcke und die Namensprüfung.
- Demo (Gauß-Zufallsweg, 5 Coins):
  - τ = 0 in 5 von 5, Y = 0;
  - ≥ 2 σ vorhergesagt ≈ eingetreten in 5 von 5 (✓);
  - Richtung über alle Coins: 101 Blöcke, z +1,3.
- Last im ungünstigen Fall (800 Eimer je Stand, 90 Tage, 10,4 Mio Zeilen, ein Coin): Kalibrierung 5,7 s, höchstens 150 MB
  Prozessspeicher (23.43: 1,5 s, 91 MB; 30 Tage jetzt 2,1 s, 98 MB). Der Mehraufwand kommt von 112 statt 21 Parametern je Y. Die
  Tabelle läuft in Stücken zu 100 Blöcken; mit 250 waren es 204 MB. Live-Stand 0,03 s. Auf dem Pi grob das Zwei- bis Dreifache, alle
  6 h im Familien-Takt.
- `install.py --selftest` aus dem Paket: 29 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Nach dem Update:** „Kalibrierung ausstehend“ bis zum ersten Takt 15 min nach dem Start (v1 gilt nicht mehr). Sofort geht es mit
  Debug „Kaskaden-Gleichung: jetzt kalibrieren“.
- **Danach:**
  - τ je Coin wahrscheinlich 0,3–0,9 (nachgerechnet aus den Quoten: 0,4–0,7);
  - P(Rutsch ≥ 2 σ) rund 5 % statt 3 %;
  - „vorhergesagt gegen eingetreten“ mit ✓.
- **Y:** Ohne den Gewinn aus dickeren Rändern ist ein Y > 0 seltener. BTC 1 h bleibt der Kandidat. Belegt wird nur mit dem Spiegel beim
  gleichen Y.
- **Unverändert:** Treiber, Familie „Kaskaden“, Kipppunkte und die Labor-Strategie, solange kein Y für 4 h belegt ist.
- **Selbsttest auf dem Pi:** etwa 1 bis 1,5 min (vorher 25 s).

**Was man wissen muss:**
- Die synthetischen Proben müssen die bekannten Eigenschaften echter Kurse enthalten (Schwankung mit Gedächtnis, dicke Ränder), nicht nur
  die geprüfte Mechanik. Sonst bestehen Modelle Proben, die der echte Markt sofort widerlegt.
- Eine Schutzbedingung kann still in eine andere zusammenfallen. Der Spiegel mit eigenem Y wurde zur Bedingung 2. Vergleiche gehören
  auf gleiche Komplexität.
- Selbsttests dürfen den echten Speicher weder lesen noch schreiben. Beim Umlenken von `F.STORE` den Pfad ausdrücklich übergeben.

## 3ξ. Magnet-Test (U110): berührt der Kurs Cluster öfter als der Zufall? (04.10., Version 2026-09-23.45, Opus 5.5)

Anlass: Der Nutzer hat 23.44 eingespielt und die zweite Kalibrierung geschickt (20:55, 6 Coins in 19,5 s). Zugesagt war danach U110.
Zugesagt war auch: Bis zum 25.10. ändert sich nichts an Fusion, v3 und Kaskaden-Rechnung. Daran hält sich 23.45; neu ist nur
Messung.

**1. Die zweite Kalibrierung bestätigt 23.44** (Zahlen in `KONZEPT_Fusion.md` 4b.1b).
- „vorhergesagt gegen eingetreten“ (out-of-fold) liegt in allen 11 Coin-Horizonten für ≥ 2 σ und ≥ 1 σ innerhalb 2 SE: 22 von
  22 ✓. Beispiel BTC 1 h ≥ 2 σ: 5,3 → 5,7 % (+0,4 ± 0,9 Punkte); mit 23.43 waren es 2,9 → 5,8 %.
- τ 0,3–0,9 (nachgerechnet erwartet 0,4–0,7), c 0,67–0,90.
- Y = 0 außer ETH 1 h (0,25; 1,1 SE) und HYPE 4 h (0,5; Abstand +0,032 ± 0,013, also 2,5 SE; Placebo Y 0). HYPE 4 h scheitert allein
  am Spiegel: Beim gleichen Y ist er so gut wie die echten Seiten (−0,0024 ± 0,0146). Für diesen Fall ist er gebaut: Cluster nah
  auf beiden Seiten, keine Seitenmechanik.
- Richtung über alle Coins: 219 Blöcke, 46 % ± 3 % (z −1,1); ETH 34 % (z −2,1). Bei 4 Coins mit eigener Probe liegt einer mit 17 %
  Chance zufällig so weit.
- Auffällig, ohne Handlung vor dem 25.10.:
  - XMR: In einer Zuverlässigkeitsklasse kamen ≥ 2 σ seltener als vorhergesagt (5,5 → 1,2 %, n 254; ≥ 1 σ 21,8 → 15,9 %, n 760).
    Die 7-Tage-Schwankung hing in einer Phase zu hoch. Das ist eine Aufgabe für U109 (HAR).
  - PAXG: τ 0,9 am Rand des Rasters, Tagesumsatz unter 1 Mio, Placebo Y 8 bei flacher Verlustkurve. PAXG bleibt ein Sonderfall.
  - Abdeckung der Heatmap 22–24 % (XMR 18 %, PAXG 16 %) statt 25–29 % bei der ersten Kalibrierung. Die Ursache ist offen; am 05.10.
    zeigt sich, ob die Abdeckung nach dem Neustart wieder steigt.

**2. Gebaut: Magnet-Test** (`hl_magnet.py`, `KONZEPT_Fusion.md` Abschnitt 4 „U110“). Er ist nur eine Messung: ohne Wirkung auf
Prognose, Treiber, v1, v2, v3, Fusion und Labor.
- **Frage:** Berührt der Kurs Liquidationscluster öfter, als die am 04.10. bestätigte Rechnung ohne Cluster erwarten lässt?
- **Nullmodell:** das Modell „ohne Heatmap“ der Kaskaden-Gleichung (Y = 0) mit gemischter Schwankung. c und τ werden je Block
  out-of-fold gewählt (`nullmodell`: dieselben 5 Folds mit Embargo wie `K._waehlen`).
- **Fälle:** je Block, Seite und Größenklasse das nächste Cluster bis 3 σ_h (`naechste`). Klassen nach Notional / Tagesumsatz:
  klein < 0,5 %, mittel 0,5–2 %, groß ab 2 %.
- **Überschuss** = berührt − P_null, beide Seiten gleich gewichtet (`_balanciert`). Standardfehler mit Tagen als Klumpen, nie unter
  dem binomialen.
- **Kontrollen:** Spiegel (gleiches Niveau, andere Seite), Placebo (Tiefen und Größen der Karte von 3 Tagen vorher, `K._placebo`),
  Zufallsniveaus 0,25–3 σ_h.
- **Belegt** (`bedingungen`, `belegt_regel`): mindestens 60 wirksame Fälle (`n_wirksam` = 4 · unten · oben / (unten + oben)),
  Überschuss, echt − Spiegel und echt − Placebo je > 2 SE. Der Bericht nennt die fehlende Bedingung, z. B. „nicht belegt (nur eine
  Seite, Placebo ≤ 2 SE)“.
- **Testmarkt** (`hl_kaskade._probe_markt`, nur Selbsttest) mit neuen Parametern: `magnet` (Anziehung zu großen Clustern), `drift`
  (Trend), `kopplung_anteil` (Störfaktor nur durch große Cluster) und `niveau` (feste Niveaus mit großen Clustern). Ohne Wert
  ändert keiner etwas, auch nicht die Folge der Zufallszahlen; der Kaskaden-Selbsttest liefert Zahl für Zahl dasselbe wie 23.44.
- **Einbau:**
  - Familien-Takt des Dashboards alle 6 h, erstmals 20 min nach dem Start, nach der Kaskaden-Gleichung.
  - Ergebnis in learned coin/„magnet“, gilt 3 Tage, Modellversion 1.
  - Debug: „★ Magnet-Test (U110)“, „Magnet-Test: jetzt rechnen“, „Magnet-Test: Selbsttest“.
  - Berichte: Wochenprüfung (W13), einmalig `u110-magnet-woche1` am 11.10. 20:00 und `u110-magnet-auswertung` am 25.10. 20:00.
  - `install.py`: Schritt 30. `update.py` und `version.py` kennen die neue Datei.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Trendfalle (eigener Fehler im Entwurf):** Der Entwurf nannte das seitengleiche Mittel „trendfest“. Das stimmt nur mit Fällen auf
  beiden Seiten. Mit einer Seite fiel es auf gleiche Gewichte zurück.
  - Testmarkt: Abwärtstrend, nur Long-Cluster. Überschuss und Spiegel lagen in allen Klassen über 2 SE (+5 … +11 Punkte); nur das
    Placebo hielt.
  - Jetzt zählen wirksame Fälle; eine Seite allein ergibt 0 und damit kein Urteil.
  - Derselbe Trend mit Clustern auf beiden Seiten: Der Ausgleich hebt ihn auf (−0,9 Punkte im Mittel, einseitig +8,8).
- **Störfaktor:** Die erste Fassung koppelte wie im Kaskaden-Test alle nahen Cluster an die Schwankung. Der Überschuss kam damit nur
  einmal über 2 SE, der Spiegel wurde kaum geprüft. Jetzt koppeln nur große Cluster: Überschuss und Placebo schlagen in 4 Läufen
  an, nur der Spiegel hält.
- **Niveau-Welt:** Sie war als Falle für das Placebo gedacht, ist aber keine. Das Placebo überträgt Tiefen und Größen der alten Karte
  auf den Kurs von jetzt; feste Niveaus kennt es nicht. Ein Placebo mit den alten PREISEN würde echte Cluster mitnehmen, weil
  Positionen oft tagelang offen bleiben. Ergebnis ist eine Grenze des Tests, offen benannt in Bericht, Konzept und Selbsttest:
  Belegt heißt „die Karte sagt Berührungen vorher“, nicht „das Cluster zieht“.
- **Prüfbar gemacht:**
  - die Belegt-Regel als eigene Funktion;
  - „out-of-fold“: Bekommt Fold 1 doppelt so weite Ausschläge, bleibt sein eigener Parameter;
  - „isoliert“: Die Live-Probe prüft, dass sie im eigenen Speicher arbeitet.
  Ohne diese Prüfungen blieben die Mutationen „Nullmodell in der Stichprobe“ und „echter Speicher“ grün.
- **Standardfehler:** Mit 12 Seeds lag die Streuung der Spiegel-Differenz (klein) beim 1,38-Fachen des berechneten Standardfehlers.
  40 Seeds zeigen 0,82–1,08 über alle Klassen und Kontrollen (erwartet 1 ± 0,11). Der Fehler ist richtig geschätzt; die 1,38 war
  Zufall der kleinen Probe.

**4. Proben.**
- `python3 hl_magnet.py --nulltest`: 13 Prüfungen, rund 21 s (Pi geschätzt rund 40 s).
  - Mathe 5: nächstes Cluster je Klasse bis 3 σ; Nullmodell = Kaskaden-P (5 · 10⁻⁹); out-of-fold; Seitenausgleich, binomialer
    Boden und wirksame Fälle; belegt nur mit allen vier Bedingungen.
  - Markt 7:
    - Positivkontrolle: groß belegt 3 von 3, Überschuss +4,7 … +4,9 ± 1,4–1,5 Punkte, echt − Spiegel +9,3 … +10,2; klein nie.
    - Nulltest: nie belegt.
    - Störfaktor: nie belegt; 4 Klassen, die nur der Spiegel hält.
    - Trendfalle: nie belegt; 9 von 9 Klassen scharf, gehalten von „nur eine Seite“ (9) und Placebo (9).
    - Trend auf beiden Seiten: −0,9 Punkte.
    - Grenze (Niveau-Welt): belegt 3 von 3.
    - Schwankung mit Gedächtnis: nie belegt; Zufallsniveaus 23 von 24 innerhalb 2 SE; τ 0,6 erkannt.
  - Live 1: eigener Speicher, Takt, fremde Version gilt nicht, Bericht.
- Mutationen hl_magnet: 16 von 16 rot. Die Kontrolle ohne Mutation ist sauber, der Köder-Speicher unberührt. Rot werden:
  - Nullmodell in der Stichprobe;
  - weitestes statt nächstes Cluster; ohne 3-σ-Grenze;
  - ohne Seitenausgleich; Seitengewichte vertauscht; ohne binomialen Boden; wirksame = alle Fälle;
  - belegt schon bei genau 2 SE; belegt ohne Mindestzahl, ohne Spiegel oder ohne Placebo;
  - Placebo mit der eigenen Karte; Berührung auf der anderen Seite gezählt; Spiegel auf derselben Seite;
  - Versionsprüfung entfernt; Live-Probe im echten Speicher (Köder verändert, Prüfung rot).
- Nullwelt mit 40 weiteren Seeds (Erkundung): nie belegt in 120 Klassen-Läufen; Streuung/SE 0,82–1,08; z > 2 in 0–2 von 40.
  - Der Überschuss liegt im Mittel 0,3–0,5 Punkte unter null. Das Nullmodell überschätzt im Testmarkt kleine Abstände (0,25 σ:
    79,7 → 77,3 %), weil der Testmarkt in Teilschritten rechnet.
  - Das wirkt gegen „belegt“. Das Placebo hat dieselben Tiefen und nimmt solche Fehler mit.
- Kaskaden-Gleichung: Selbsttest unverändert (21 Prüfungen, dieselben Zahlen wie 23.44). Mutationen 26 von 26 rot.
- Last im ungünstigen Fall (800 Eimer je Stand, 90 Tage, 10,4 Mio Zeilen, ein Coin): Magnet-Test 2,0 s, höchstens 77 MB
  Prozessspeicher. Bei 30 Tagen 0,7 s und 52 MB. Zum Vergleich die Kaskaden-Kalibrierung: 5,7 s und 150 MB.
- Weitere Selbsttests grün:
  - `check_treiber.py`: 83 von 83 (Treiber unverändert);
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`;
  - Berichtsplan: 14 Einträge, alle Läufe bekannt;
  - `node --check` beider Skriptblöcke und die Namensprüfung.
- Demo (5 Coins, 12 Tage, älterer Demo-Erzeuger): Rechnung und Bericht laufen, nichts belegt.
- `install.py --selftest` aus dem Paket: 30 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Erste Rechnung** 20 min nach dem Start, sofort mit Debug „Magnet-Test: jetzt rechnen“; danach alle 6 h.
- **Reichweite:** Viele Cluster liegen weiter als 3 σ_h. Bei BTC (σ_4h 0,70 %) zählen für 1 h Cluster bis rund 1,05 %, für 4 h bis
  2,1 %.
  - Für 1 h kommen die Fälle also vor allem aus kleinen und mittleren Clustern nah am Kurs.
  - Bei ZEC lagen am 04.10. große Cluster nur unten (oben höchstens 0,23 % des Tagesumsatzes). Dort ist „nur eine Seite“ ein
    erwartbares Urteil.
- **Erwartung:** Überschuss nahe 0. Ein Beleg ist am ehesten in „groß“ bei 4 h möglich. „Nicht belegt“ ist ein Ergebnis.
- **Zufallsniveaus:** Die Zeile zeigt, ob das Nullmodell bei jedem Abstand trifft. Eine Abweichung bei kleinen Abständen kennt der
  Testmarkt (siehe oben); auf dem Pi zählt die Größe der Abweichung.

**Was man wissen muss:**
- Ein Mittel, das „trendfest“ heißt, ist es nur unter seiner Bedingung. Eigenschaften gehören mit ihrer Bedingung geprüft, nicht nur
  benannt.
- Jede Schutzbedingung braucht einen Testmarkt, in dem nur sie hält. Sonst zeigt der Selbsttest nicht, dass es sie braucht.
- Eine Falle, die keine Kontrolle fängt, ist entweder eine Lücke oder eine Grenze. Hier ist es eine Grenze (Vorhersage, nicht
  Ursache), offen benannt.

## 3ο. z explodierte bei wenigen Fällen (Nutzerfund 04.10., 21:46): exaktes z für Trefferquoten (04.10., Version 2026-09-23.46, Opus 5.5)

Anlass: Vor dem Einspielen von 23.45 sah der Nutzer im Abschnitt Treiberfamilien (BTC) bei „Kaskaden“ z = +12101198177798966,0 bei
n = 3 (Bild vom Dashboard und vom Handy). 23.46 enthält 23.45 (U110) und diese Korrektur.

**1. Ursache (eigener Fehler, seit 23.25).**
- `hl_familien._stat` rechnete z = Mittel / (Stichproben-Streuung / √n) über „Treffer − Erwartung“ je Fall.
- Drei Treffer bei einer Basisrate von 52,5 % ergeben dreimal denselben Wert 0,475. Die Streuung ist dann 0, im Fließkomma aber
  6,8 · 10⁻¹⁷; die Abfrage `sd > 0` ließ das durch.
- Nachgerechnet: z = 1,2101198177798966 · 10¹⁶, genau der Wert vom Bildschirm.
- Wie oft das unter dem Zufall vorkommt: 3 Treffer in 3 Fällen bei 52,5 % Basis in 14,5 % der Fälle, jedes Mal mit z ≈ 10¹⁶. Auch
  ohne Explosion war das z bei wenigen Fällen zu großzügig: 5 von 6 bei 50 % ergab +2,0, an der Grenze zu „gut“; exakt sind es
  +1,53. Profi-Flow (BTC, n 6, z +2,0) stand genau dort.
- Folge: Die Wochenurteile der Familien („gut“ bei z ≥ 2 über 14 Tage) hätten Familien auf wenigen gleichen Treffern befördert, am
  Wochenwechsel Donnerstag 02:00 auf „Bewährung“, nach zwei Wochen auf „aufgestiegen“ mit Gewicht in der Familien-Prognose
  (Parallelbetrieb, nicht in der Hauptprognose). Auf dem Bild sind alle BTC-Familien Kandidat.

**2. Dieselbe Rechnung an zwei weiteren Stellen.**
- `hl_anker._stat` (Heatmap-Anker, 23.28): „belegt“ (trendbereinigt z ≥ 2 in zwei Horizonten) macht Cluster zum Ziel des Pfads der
  HAUPTprognose. Mit wenigen gleichen Treffern hätte das ohne Beleg gegriffen. Ob das auf dem Pi geschah, ist nicht bekannt; die
  Bilanz läuft täglich und rechnet nach dem Update neu.
- Ereignis-Profile (`hl_konstellation`, U43): Ein toter Treiber hat in allen Fällen dieselbe Abweichung. Die Streuung ist exakt 0, z
  wird unendlich (im Selbsttest nachgewiesen); in JSON wäre das „Infinity“ geworden.
- Geprüft und unverändert, weil die Werte stetig sind oder ein Boden den Standardfehler hält:
  - Treiber-Bilanz (Mindest-Streuung im Standardfehler), Konstellationen (gepoolter Standardfehler mit Boden), Aktive Profis
    (Boden);
  - TradeLabor (t über Blockwerte in %; Stufen erst ab 15 bzw. 30 Blöcken), Elite-t (4-h-Blockrenditen), `check_magnet` (Bewegungen
    in %). Gleiche Werte in allen Blöcken kommen dort praktisch nicht vor; das steht als Restpunkt in U119.

**3. Gebaut.**
- `hl_forecast.z_treffer(paare)`: z einer Trefferquote EXAKT. paare = (Treffer 0/1, Erwartung) je Fall.
  - Unter dem Zufall ist die Zahl der Treffer eine Summe von Binomialverteilungen, je Erwartungswert eine (bei Richtungsfamilien
    zwei: Basis und 1 − Basis).
  - z = Normalwert des mittleren p-Werts P(X < k) + ½ · P(X = k), beide Ränder getrennt gerechnet.
  - Der p-Wert ist nach unten auf 10⁻¹² begrenzt; damit ist |z| höchstens rund 7,0.
  - Bei vielen Fällen ist das das Binomial-z mit dem Standardfehler der Nullhypothese (wie die Richtungsprobe seit 23.44).
- Treiberfamilien und Heatmap-Anker rechnen ihr z damit. Der Vorsprung (pp) bleibt gleich, nur z ändert sich. Die Berührung echt
  gegen Spiegel im Anker nimmt den Vorzeichentest auf den ungleichen Paaren.
- Ereignis-Profile: `_profil_zwerte` (vorher innere Funktion) gibt ohne Streuung kein z.
- Dashboard: Erklärung am Kopf der z-Spalte der Treiberfamilien.

**4. Proben.**
- `hl_forecast.py --nulltest`, neue Prüfung „z exakt“:
  - 3 von 3 bei 52,5 % → z +1,46 (vorher 1,2 · 10¹⁶);
  - 230 von 400 bei 50 % → +3,00, gleich dem Binomial-z;
  - zwei Erwartungen (60 % und 40 %) → +1,421; mit einer gemeinsamen wären es +1,394;
  - unter dem Zufall exakt ausgezählt, z ≥ 2 bei n 3–60 und p 0,15 / 0,3 / 0,5: höchstens 3,5 %, im Mittel 2,1 % (Soll 2,3 %).
- `hl_familien.py --nulltest`: die bisherigen Prüfungen grün. Großkonten-Fluss z 24,8 → 7,0 (das Stichproben-z war bei hoher
  Trefferquote zu groß; 7,0 ist die Obergrenze), Stärke 8,2 → 7,0, ETF (Rauschen) +2,1 → +2,0. Neu „Wenige Fälle“: 3 von 3 → z
  +1,46, Kandidat; 5 von 6 bei 50 % → +1,53 (vorher +2,0).
- `hl_anker.py --nulltest`: Magnet belegt, Rauschen und Trendfalle nicht, wie bisher. Neu „Wenige Fälle“: 3 von 3 bei 55 % → +1,38;
  Berührung 3 von 3 nur echt → +1,53; ohne ungleiche Paare kein z.
- `hl_konstellation.py --nulltest`: neu „ohne Streuung kein z“ (vorher z unendlich).
- Mutationen: 7 von 7 rot, Kontrollen sauber. Rot werden: z wieder über die Stichproben-Streuung (Familien, Anker), Spiegel-z über alle
  Paare, exakter statt mittlerer p-Wert, eine gemeinsame Erwartung statt Gruppen, ohne Untergrenze des p-Werts, Ereignis-Profile ohne
  Streuungs-Schutz.
- Demo (BTC, ZEC): Familien-Bericht und Anker-Bilanz laufen; Kaskaden mit 1 bis 2 Fällen ohne z.
- Batterie wie in 3ξ grün, `install.py --selftest` aus dem Paket: 30 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- Treiberfamilien: z höchstens rund ±7. Bei wenigen Fällen ist es kleiner als vorher: Kaskaden (BTC, 3 von 3) +1,46 statt 1,2 · 10¹⁶,
  Profi-Flow unter 2. Familien mit hoher Trefferquote zeigen kleinere z als vorher. Der Vorsprung (pp) bleibt gleich.
- Stufen: Eine Familie, die mit dem alten z schon „Bewährung“ oder „aufgestiegen“ erreicht hat, bleibt dort nach den Regeln, bis die
  Wochenurteile anders ausfallen.
- Heatmap-Anker: Die nächste tägliche Bilanz rechnet neu. „Belegt“ kann für einzelne Coins wegfallen, wenn es auf wenigen Fällen
  stand; dann sind Cluster nicht mehr Ziel des Pfads.

**Was man wissen muss:**
- Eine Stichproben-Streuung ist bei wenigen gleichen Werten 0, und Fließkomma macht daraus 10⁻¹⁷. `> 0` schützt dann nicht. Für
  Trefferquoten gehört der Standardfehler des Zufalls in den Nenner (Lehre 23.44, Punkt 5), hier jetzt exakt.
- Wo ein Fehler steckt, steckt er oft auch in den Kopien derselben Rechnung. Der Fund in den Familien führte zum Anker und zu den
  Ereignis-Profilen.

## 3π. Makro-Chart (U121) mit Miner-Kostenbasis und eigener `makro.db`; U120 v2-Kachel; U122 Zeitbombe im Recorder-Selbsttest (05.10., Version 2026-09-23.47, Opus 5.5)

Anlass: Nutzer 05.10. 04:20, nach der Recherche (`RECHERCHE_Makro_Chart_05-10-2026.md`): „alles obige einbauen, was kostenlos ist,
jeweils mit einem visuellen Chart; dazu ein Chart für die Miner-Kostenbasis (Ausgangsszenario S21 XP für 7,5 ct/kWh); zur
Entlastung der Datenbank eine neue zusätzliche Datenbank `makro.db`“. Im Paket außerdem U120 (war für das nächste Paket geplant) und
U122 (beim Selbsttest dieses Pakets gefunden). Fusion, v3 und Kaskaden-Rechnung unberührt (Zusage bis 25.10.).

**1. Gebaut (Einzelheiten: `KONZEPT_Makro.md`).**
- `hl_makro.py`: Abruf, Rechnung je Treiber, Nutzlast je Tab, Selbsttest (42 Prüfungen). `hl_makro_js.py`: das Skript des Abschnitts
  (`/makro.js`, 47 kB). Im Dashboard der Abschnitt „MK Makro“ (Navigation „Makro“); er lädt nur, solange er offen ist (dann alle
  2 min neu).
- Eigene Datenbank `makro.db` neben `hl_liq.db` (Tabellen `mk_reihe`, `mk_abruf`, `mk_meta`, `mk_stand`, `mk_pl`). Geschrieben nur
  vom Makro-Takt, einem Thread im Dashboard-Prozess (90 s nach dem Start, dann alle 20 s fällige Ziele), jede Transaktion
  `BEGIN IMMEDIATE`. `hl_liq.db` wird nur gelesen: der letzte BTC-Kurs aus `bars` (höchstens 15 min alt) für die Spalte „jetzt“.
- Quellen, alle frei: Coin Metrics Community (BTC ab 18.07.2010; ETH, ZEC, XMR), FRED ohne Schlüssel (12 Reihen), alternative.me,
  DefiLlama, Blockchain.com, Deribit, Binance Futures mit dem OI-Archiv data.binance.vision, Farside, BGeometrics (8 Endpunkte,
  höchstens 7 je Stunde und 14 je Tag bei 8 freien je Stunde und 15 je Tag).
- Neun Tabs; jeder Treiber ist in einem Chart zu sehen, als eigener Chart oder als Linie im Chart seiner Bezugsgröße (Delta Price
  im Realized-Price-Chart, Epochen-Hochs und -Tiefs als Marken im MVRV-Chart). NUPL = 1 − 1/MVRV wäre dieselbe Kurve wie das MVRV
  und steht deshalb im Fadenkreuz des MVRV-Charts.
  - Überblick: Satz aus den Positionen, Zonenkarte (Tagesschluss und „jetzt“, Lage als Perzentil; am Handy als Karten), Chart
    „Kurs und Kostenbasen“.
  - Bewertung: Realized Price, MVRV mit Perzentil über alles und über 4 Jahre, MVRV-Z, NUPL, Delta Price, Epochen-Hochs und -Tiefs,
    Bewertungsdivergenz (Hypothese).
  - Trend: Power Law mit Bändern und kausalem Perzentil, 200-Wochen-MA (Coin wählbar), Halving-Zyklen.
  - Kohorten (BGeometrics): Kurzfrist- und Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV,
    realisierte Verluste.
  - Miner: Kostenbasis (Punkt 2), Puell Multiple, Hash Ribbons, Difficulty Ribbon.
  - Hebel & Stimmung: Funding in % p. a., Open Interest ÷ Marktkap., DVOL, Fear & Greed, Wochen-RSI.
  - Kapitalfluss: Stablecoins, SSR, ETF-Nettoflüsse BTC und ETH.
  - Makro: Nettoliquidität, globaler Liquiditäts-Proxy, M2, Realzins, Dollar, Hochzinsspread, Leitzins, jeweils mit rollierender
    Korrelation zur BTC-Wochenrendite und Zufallsband.
  - Daten: Quellen mit Lizenz, letzte Abrufe, je Reihe Zeitraum, Alter und Grenze; Warnzeile für zu alte und fehlende Reihen.
- Jeder Chart: eine y-Achse (nie zwei), Legende ab zwei Reihen, Fadenkreuz mit allen Werten des Tages, Tabellenansicht, Quelle
  darunter; Farben geprüft (Prüfskript, dunkle Fläche).
- Recorder: das tägliche Backup sichert `makro.db` als `makro_backup.db` (plus eine Generation). Debug: „Makro: Stand und
  Quellen“, „Makro: jetzt abrufen“, „Makro: Selbsttest“. Berichtsplan: `u121-makro-erstlauf` einmal am 06.10. 20:15, „Makro: Stand“
  im Wochenplan (W14). `HL_MAKRO=0` schaltet den Takt ab.

**2. Miner-Kostenbasis (Szenario, keine Messung).**
- Stromkosten je BTC = J/TH × Strompreis × Difficulty × 2³² ÷ 10¹² ÷ 3,6 · 10⁶ ÷ (Emission + Gebühren je Block, 7-Tage-Summen aus
  Coin Metrics). Der Server liefert die Einheit (USD je BTC für 1 J/TH und 1 USD/kWh), der Browser rechnet das Szenario: umschalten
  ohne neuen Abruf.
- Ausgangsszenario: Antminer S21 XP 13,5 J/TH bei 7,5 ct/kWh. **Annahme (vom Nutzer nicht genannt): US-Cent.** Umschaltbar auf
  Euro-Cent mit dem Tageskurs EUR/USD (FRED DEXUSEU). Geräteliste (S21 XP Hydro 12, S21 Pro 15, S21 17,5, S19 XP 21,5, S19j Pro
  29,5 J/TH) oder eigener Wert, Aufschlag für sonstige Kosten in %.
- Chart: Kurs, Szenario, Band Strompreis ± 2,5 ct, ältere Flotte S19 XP gestrichelt; darunter Kurs ÷ Kosten.
- Prüfwert: Difficulty 1,318 · 10¹⁴, 3,16 BTC je Block → 50.383 USD je BTC.

**3. Entscheidungen.**
- Positionen statt Signale, keine festen Schwellen aus 2013–2021, kein Gesamtwert (Gründe im Bericht und in `KONZEPT_Makro.md` 1).
- Jede Rang-, Z- oder Anpassungsreihe ist kausal; die Power-Law-LINIE im Chart ist über alle Tage angepasst (beschreibend, so
  beschriftet), ihr Perzentil kausal (Anpassung je Monat bis zum Vormonat, Parameter in `mk_pl`).
- Die ersten 180 Tage einer MVRV-Reihe sind verworfen (BTC: 146 am 18.07.2010 ist Anlauf der realisierten Kapitalisierung, kein
  Hoch). Mit 75 Tagen blieb im November 2010 noch 8,19; mit 180 Tagen sind die Epochen-Hochs die des Berichts (7,74 …).
- Hash Ribbons: Kreuzungen im Rauschen der Hashrate sind keine Kapitulation → Rauschschwelle 3 σ/√60, σ aus den 365 Tagen vor der
  Episode. Ohne genug Vorlauf bleibt eine Episode ohne Urteil.
- Miner: kein Perzentil von Kurs ÷ Kosten (ein fester Gerätetyp über die ganze Historie ist kein Maßstab; mein erster Entwurf zeigte
  1,3 %).
- Die Zonenkarte wird einmal je Tag in `mk_stand` festgeschrieben: die eigene Bilanz außerhalb der Stichprobe, ohne Revisionen.
- Frische-Alarm (eigenes Abnahmekriterium von U121, beim Schreiben dieser Doku als fehlend bemerkt und nachgebaut):
  - Je Reihe Alter des letzten Werts gegen eine Grenze je Quelle (Coin Metrics 5 Tage, Farside 7, FRED täglich 10, wöchentlich
    veröffentlicht 14, EZB 21, M2 und BoJ 100).
  - Dazu „fehlt“: Reihen, die ein schon erfolgreich abgerufenes Ziel liefern müsste, die es aber nicht gibt.
  - Grund: Verschwindet eine Metrik aus dem freien Katalog, scheitert oft kein Abruf; die Reihe bleibt nur stehen.
- Nicht gebaut: 25-Delta-Skew (keine freie Historie), Treasury-mNAV (keine freie Schnittstelle), alles aus Stufe 3.

**4. U120: v2-Kachel (eigener Fehler seit 23.26).**
- Der Brier-Skill der v2-Kachel wurde gegen die OOF-Klimatologie der Trainingsfolds gemessen; der Achsenabschnitt des
  Kalibrierschritts kennt aber alle OOF-Fälle. So zeigte schon c = 0 (reine Basisrate) Skill.
- Jetzt gegen denselben Kalibrierschritt mit c = 0 auf denselben Fällen (wie v3). Bei c = 0 ist der Skill genau 0, die Quote heißt
  dann „Basisrate“. Die alte Zahl bleibt als `brier_skill_klima` im Debug.
- Nur Anzeige: p_up_v2, Achsenabschnitt, c, Gewichte, λ und Quote bitgleich (Positivkontrolle vorher/nachher verglichen).

**5. U122: Zeitbombe im Selbsttest „Recorder: Masterregel ohne Kleinfills“ (eigener Fehler aus 23.38).**
- Der Test lief mit der echten Uhr und legte eine vorläufige Sperre „vor dem 29.09.“ auf den 28.09. 00:00 UTC. Seit dem 05.10.
  00:00 UTC ist sie älter als 7 Tage; die Regel „vorläufig ohne zweiten Tag: nach 7 Tagen frei“ gibt sie richtig frei, die Erwartung
  „unberührt“ galt nur bis 04.10.
- Betrifft auch das gelieferte 23.46: Ein Selbsttest auf dem Pi ab dem 05.10. zeigt diesen Schritt rot. Das System rechnet richtig,
  nur der Test war datumsabhängig.
- Korrektur: feste virtuelle Uhr (02.10. 12:00 UTC plus verstrichene Zeit), wie U34/U36. Das Muster war bekannt, ich habe es hier
  nicht angewandt.

**6. Proben.**
- `hl_makro.py --selbsttest`: 42 Prüfungen in rund 2 s.
  - Mathematik je Treiber mit Positivkontrolle und Nulltest.
  - Parser je Quelle: Coin Metrics, FRED, alternative.me, DefiLlama und Deribit gegen am 05.10. gelesene Antworten;
    BGeometrics, Farside-Gesamtseiten und das Binance-Archiv gegen nachgebaute Beispiele (auf dem Pi offen).
  - Zeitplan mit falschem Netz und springender Uhr: Budget, Pause, Erstabruf mit ganzer Historie.
  - Kausalität: Zukunftsdaten × 50 angehängt, 19 Reihen bitgleich.
  - Nutzlast je Tab, Archiv, fehlende `makro.db` (Hinweis, nichts angelegt).
  - Frische mit fester Uhr: stehengebliebene Reihe gemeldet, M2 mit 80 Tagen Verzug nicht, Farside-Wochenende nicht; fehlende
    Reihe nach erfolgreichem Abruf gemeldet, vor dem ersten Abruf nicht.
- Mutationen: 27 von 27 rot (davon 4 für die Frische).
- Rückrechnung mit echten Coin-Metrics-Daten (öffentlicher GitHub-Spiegel bis 24.05.2026) gegen den Bericht:
  - MVRV 06.10.2025 2,287, Realized Price 54.576,53 USD, MVRV-Z 2,53, Puell 1,07; MVRV 21.11.2022 0,778.
  - Epochen-Hochs 7,74 · 5,88 · 4,72 · 3,96 · 2,74.
  - Power-Law-Exponent über alle Tage 5,674 (Perrenod 5,674), bis 09/2019 5,822 (Burger 5,845).
  - Hash Ribbons über der Schwelle u. a. 11/2018, 03/2020, 06/2021, 11/2022 und 01–02/2026 mit Kaufsignal 05.03.2026 (Recherche:
    CoinDesk 25.02.2026).
- Sichtprüfung aller Tabs in Desktop- und Handybreite (Playwright): keine Skriptfehler, nichts über den Rand. Fadenkreuz-Tooltip in
  Überblick, Miner und Makro geprüft. Tab „Daten“: Alter und Grenze stehen direkt neben dem Reihennamen, damit sie am Handy
  ohne Seitwärtsschieben sichtbar sind (erste Fassung hatte sie rechts außen).
- Gemessen auf der Testdatenbank: 178.508 Zeilen in 49 Reihen, 7,8 MB. Ganze Rechnung 0,6 s in der Sandbox; Nutzlast je Tab
  9–440 kB roh (Miner am größten), im Dashboard gzip.
- U120: Positivkontrolle v2, Rausch-Szenarien mit c = 0:
  - Brier-Skill vorher +0,001 bis +0,014 (Mittel +0,009), jetzt in allen 5 genau 0.
  - Mit c > 0 über 0 in 5 von 5; Tor und Gleichlauf unverändert.
  - Mutation (Skill wieder gegen die Klimatologie) macht den Nulltest rot.
- U122: vor der Korrektur rot (eigener Lauf 05.10.), danach grün.
- `install.py --selftest-isoliert`: 31 Schritte, PNG und 9 Dashboard-Abrufe grün, darunter `/makro` und `/makro.js`.
- Beide Skriptblöcke der Seite und `/makro.js` mit `node --check` geprüft.

**7. Was auf dem Pi zu erwarten ist.**
- Nach dem Update startet der Makro-Takt mit dem Dashboard und ruft 90 s später ab.
  - Coin Metrics, FRED, alternative.me, DefiLlama, Blockchain.com, Deribit, Binance und Farside binnen Minuten.
  - BGeometrics über rund eine Stunde (8 Endpunkte, 8 min Abstand, 7 je Stunde).
  - Das OI-Archiv nach und nach, eine Tagesdatei je 20 s (rund 2.200 Dateien, rund 12 h). Bis dahin zeigt OI ÷ Marktkap. nur
    die 30 Tage der REST-Schnittstelle.
- Bis zum ersten Coin-Metrics-Abruf zeigt der Abschnitt „zu wenig BTC-Kursdaten (Coin Metrics noch nicht abgerufen)“.
- Die Bewertungsfelder von Coin Metrics sind erst bei T−2 vollständig. MVRV und Realized Price enden deshalb zwei Tage vor heute;
  „jetzt“ nutzt den Live-Kurs.
- v2-Kachel: nach dem nächsten v2-Lauf (beim ersten Lernlauf nach dem Neustart, dann stündlich) bei Coins mit c = 0
  „Quote … (= Basisrate, c 0)“ und „Brier-Skill 0.000 gegen c 0“. Vor diesem Lauf steht die alte Zahl ohne „gegen c 0“.
- Selbsttest: 31 Schritte; der Makro-Schritt braucht in der Sandbox rund 2 s.
- **Bericht `u121-makro-erstlauf` am 06.10. 20:15** (Debug „Makro: Stand und Quellen“ und „Makro: Selbsttest“; Plan U123), bitte
  hochladen.
  Erst damit sind die Formate belegt, die die Sandbox nicht erreichen konnte:
  - Feldnamen von BGeometrics;
  - Farside-Gesamtseiten;
  - data.binance.vision und Binance Futures vom Pi aus.
  Abnahme: jede Quelle mit Zeilen und ohne Dauerfehler; Frische-Zeile ohne „ZU ALT“ und ohne „FEHLT“; Realized Price 03.10.2026
  ≈ 53.680 USD (Bericht); Budget BGeometrics ≤ 14 je Tag.

**Was man wissen muss:**
- Ein Test mit echter Uhr und festen Daten ist eine Zeitbombe: Er prüft am Tag des Schreibens etwas anderes als eine Woche später.
  Jeder Test, der Daten relativ zu einem festen Datum anlegt, braucht eine feste Uhr.
- Beim MVRV entscheidet der Anlauf über die Extremwerte. Wer Hochs je Epoche vergleicht, muss den Anlauf der realisierten
  Kapitalisierung verwerfen, sonst ist das erste „Hoch“ ein Rechenartefakt.
- Freie Fenster verschwinden (BGeometrics 4 Jahre, FRED-HY 3 Jahre, Binance-REST 30 Tage). `makro.db` behält, was einmal abgerufen
  wurde. Deshalb gehört sie ins Backup.
- Freie Quellen können still ausfallen: Ein Feld verschwindet, die Abfrage antwortet weiter mit 200. Deshalb prüft der Stand das
  Alter jeder Reihe, nicht nur den Erfolg des Abrufs.

## 3ρ. Erster Pi-Lauf des Makro-Charts: FRED hängt ohne Schlüssel, BGeometrics frei mit 7 Tagen Verzug (05.10., Version 2026-09-23.48, Opus 5.5)

Anlass: Bild des Tabs „Daten“ vom Pi (05.10. 12:14, Handy), Frage des Nutzers „Fehler?“. Der Pi lief seit etwa 11:35 mit 23.47.

**1. Befund vom Bild.**
- Läuft und ist damit auch im Format belegt:
  - Coin Metrics (4 Coins), alternative.me, DefiLlama, Blockchain.com (Gegenprobe Hashrate Coin Metrics ÷ Blockchain.com 1,000),
    Deribit;
  - Binance: Funding, Open Interest per REST und das Archiv data.binance.vision (53 Tage geholt, 0 fehlend);
  - Farside BTC/ETH (Alter 3 Tage: letzter Handelstag Freitag);
  - BGeometrics mit den Feldnamen `sthRealizedPrice`, `trueMarketMean`, `lthRealizedPrice` (3 von 8 Endpunkten bis 12:14).
- **FRED:** alle 12 Reihen „TimeoutError: The read operation timed out“, nacheinander 09:53–10:02 UTC. Die übrigen Quellen hatten
  ihren Erfolg um 11:46 Ortszeit; sie stehen im Zeitplan hinter FRED. Das passt zu zwei FRED-Runden zu je 12 × 45 s, die den
  Takt jeweils rund 9 Minuten anhielten (etwa 11:37–11:46 und 11:53–12:02 Ortszeit). Deshalb waren bis 12:14 erst 53 Archivtage
  und 3 BGeometrics-Abrufe da.
- **„Zu alt (3)“:** die drei BGeometrics-Reihen mit Alter 7 Tage bei Grenze 6.

**2. Ursachen.**
- **FRED:** `fredgraph.csv` ohne Schlüssel öffnet die Verbindung, die Antwort kommt nie. Das liegt nicht am Pi: Seit Mitte August
  2026 berichten mehrere Projekte dasselbe, von GitHub-Runnern und vom Heim-PC, und stellten auf die offizielle API mit kostenlosem
  Schlüssel um. Belege:
  - https://github.com/00xJS/Chronoticker/pull/2 („has timed out … since mid-August“);
  - https://github.com/Puma1939/morning-briefing-gmail/pull/5 („la connessione si apre ma la risposta non arriva mai“);
  - https://github.com/sechan9999/macropulse-alexa-mcp/pull/18 („also hangs from a home PC“).
  - Eigener Fehler: Ich hatte am 05.10. nur das Format über das Abrufwerkzeug der Sandbox geprüft, nicht die Erreichbarkeit für ein
    Skript. Und 45 s Wartezeit je Reihe ohne Abbruch je Quelle ließen eine hängende Quelle den ganzen Takt anhalten.
- **BGeometrics:** Die freie API liefert die jüngsten 7 Tage nicht. Am 05.10. an `/v1/sth-realized-price/last` gelesen: letzter Wert
  28.09., dazu `"delayed": true` und „Real-time data (last 7 days) requires an active subscription“. Das ist kein Abruffehler,
  meine Frische-Grenze von 6 Tagen war zu knapp. Die Recherche nannte nur „4 Jahre, 15 Abrufe am Tag“; der Verzug fehlte dort.

**3. Gebaut.**
- **FRED über die offizielle API**, sobald ein Schlüssel da ist: Umgebungsvariable `FRED_API_KEY` oder `accesstokens.json` →
  `"fred"` → `"api_key"`. Ohne Schlüssel bleibt `fredgraph.csv` als Versuch, mit 15 s statt 45 s Wartezeit.
- **Schlüssel eintragen:**
  - im Tab „Daten“: Feld und Knopf „prüfen und speichern“ (POST `/makro/fred_schluessel`, Schutz wie Update und Debug);
  - oder im Projektordner: `.venv/bin/python hl_makro.py --db <hl_liq.db> --fred-schluessel <SCHLÜSSEL>`.
  - Beide Wege prüfen das Format (32 Zeichen a–z, 0–9) und machen einen Probeabruf. Einen abgelehnten Schlüssel schreiben sie nicht.
    Die übrigen Einträge der Datei bleiben, die Datei wird atomar ersetzt, die FRED-Pausen werden zurückgesetzt.
  - Der Schlüssel erscheint nie in Fehlertexten, im Abrufprotokoll, in der Antwort oder in einer Adresse.
- **Abbruch je Quelle und Runde:** Antwortet ein Host nicht (Zeitüberschreitung, Verbindungsfehler), werden die übrigen Ziele
  dieser Quelle in der Runde übersprungen und pausieren mit (15 min, verdoppelt bis 6 h). HTTP-Fehler einer Reihe sperren nichts.
  Ein hängender Host kostet jetzt höchstens 15–20 s je Runde statt 9 Minuten.
- **BGeometrics:** Frische-Grenze 9 Tage (7 Tage Verzug plus Tagesabruf); Hinweise im Tab „Kohorten“, in der Zonenkarte („Linie
  frei mit 7 Tagen Verzug“) und im Stand.
- **Tab „Daten“:**
  - Fehler als eigene Zeile unter dem Ziel, über die volle Breite, mit „nächster Versuch“ (am Handy war die Fehlerspalte eine
    schmale Säule);
  - eine FRED-Zeile mit Weg (API oder CSV), Zahl der abgerufenen Reihen und Abhilfe.
- **Miner:** Hinweis bei Euro-Cent, solange EUR/USD (FRED DEXUSEU) fehlt.
- **`accesstokens.json`:** Die Vorlage hat einen Eintrag `"fred"`. Auf dem Pi bleibt die vorhandene Datei (`update.py`
  überschreibt sie nie); Feld oder Befehl ergänzen den Eintrag.

**4. Proben.**
- `hl_makro.py --selbsttest`: 49 Prüfungen. Neu sind 7:
  - FRED-API-Parser (`'.'` fehlt, Fehlerantwort leer);
  - mit Schlüssel alle 12 Reihen über die API;
  - Schlüssel nie im Fehlertext oder Protokoll;
  - eine Zeitüberschreitung je Quelle, der Rest pausiert, andere Quellen laufen weiter;
  - ein HTTP-Fehler sperrt nichts, auch ein 504 mit „timeout“ im Text nicht;
  - Umgebungsvariable vor Datei;
  - Einrichten mit Format, Ablehnung, Erhalt der übrigen Einträge, Pausen zurück, kaputte Datei unberührt.
  Der Selbsttest ist unabhängig von einem echten Schlüssel auf dem Pi (Umgebung und Datei umgelenkt).
- Mutationen: 37 von 37 rot (10 neu: Schlüssel ignoriert, nichts geschwärzt, kein Abbruch je Quelle, Übersprungene ohne Pause,
  HTTP-Antwort als Netzfehler, Umgebung ignoriert, Format nicht geprüft, Abgelehntes geschrieben, Pausen nicht zurück,
  BGeometrics-Grenze 6).
- Dashboard lokal:
  - POST ohne Kopfzeile abgelehnt;
  - falsches Format und leerer Körper ergeben eine Meldung;
  - ein gültiges Format wird eingetragen; die Antwort enthält den Schlüssel nicht, der Eintrag „coinglass“ bleibt;
  - der Tab „Daten“ zeigt sofort „mit Schlüssel“ (Antwort-Cache geleert).
- Sichtprüfung Handy und Desktop: Feld und Knopf, Fehlerzeilen über die volle Breite, Kohorten-Hinweis.
- Ein eigener Fehler im neuen Test (Prüfung auf das Wort „ablehnt“, die Meldung sagt „lehnt … ab“) fiel beim ersten Lauf auf, der
  Code war richtig.
- **Nicht prüfbar in der Sandbox:** ob `api.stlouisfed.org` vom Pi antwortet (die Sandbox erreicht FRED nicht). Die drei
  Projekte oben melden die API als funktionierend.

**5. Was auf dem Pi zu tun und zu erwarten ist.**
- Kostenlosen Schlüssel holen: Konto bei fredaccount.stlouisfed.org, dort „API Keys“ → „Request API Key“. Dann im Makro-Tab
  „Daten“ eintragen.
- Danach ruft der Takt FRED binnen einer Minute ab; die Charts folgen binnen rund 10 Minuten (gerechnet wird höchstens alle
  10 Minuten). Dann gibt es den Tab „Makro“ und im Miner-Tab Euro-Cent.
- Ohne Schlüssel ist die FRED-Zeile gelb. Es gibt einen Versuch je Runde und eine Pause bis 6 h; alles andere läuft ungebremst.
- „Zu alt“ für BGeometrics verschwindet; die Kohortenwerte enden 7 Tage vor heute.
- Der Bericht `u121-makro-erstlauf` am 06.10. 20:15 bleibt (U123).

**Was man wissen muss:**
- Ein Format prüfen heißt nicht, die Erreichbarkeit zu prüfen: Das Abrufwerkzeug der Sandbox ist kein Skript auf dem Pi.
- Eine Quelle darf den Takt nicht anhalten. Zeitüberschreitungen multiplizieren sich mit der Zahl der Ziele (12 × 45 s).
- Freie Stufen haben Bedingungen jenseits von Kontingent und Historie, hier 7 Tage Verzug. Bei jeder freien Quelle im ersten echten
  Abruf das jüngste Datum ansehen.

## 3σ. Makro-Signale (U126): Kauf- und Verkaufszonen je Chart, Rückblick, Bilanz gegen Zufall, Prognose „Rückkehr zum Median“ (05.10., Version 2026-09-23.49, Opus 5.5)

Anlass: Wunsch des Nutzers 05.10. 13:59: statistische Kauf- und Verkaufssignale in den Makro-Charts. Je Chart soll berechnet
werden, wie weit die Reihe über oder unter ihrer Referenzlinie lag (in %), dazu die idealen Kauf- und Verkaufspunkte je Zeitskala
(1 J, 2 J, 4 J, 8 J, alles), der „optimale Median“ und ein extrapolierter Wert; für alle Charts, täglich. Auf Rückfrage gewählt:
alle Charts mit Referenzlinie; Rückblick und Live getrennt; Median der Abweichung; Rückkehr zum Median, 3/6/12 Monate mit 80-%-Band.

**1. Gebaut.**
- **Neues Modul `hl_makro_signal.py`:** reine Rechnung, ohne Datenbank und ohne Netz. Es rechnet 14 Paare (Reihe gegen
  Referenzlinie):
  - Bewertung: Kurs gegen Realized Price (BTC, ETH, ZEC) und gegen Delta Price (BTC).
  - Trend: Kurs gegen den kausalen Power-Law-Fair-Value (BTC) und gegen den 200-Wochen-MA (BTC, ETH, ZEC, XMR).
  - Kohorten: Kurs gegen Kurzfrist-Kostenbasis, True Market Mean und Langfrist-Kostenbasis (BTC; BGeometrics, 7 Tage Verzug).
  - Miner: Kurs gegen die Stromkosten (S21 XP, 7,5 ct), nur 1, 2 und 4 J, weil ein fester Gerätetyp über 8 Jahre kein Maßstab
    ist; dazu Puell gegen 1.
- **Je Paar und Zeitraum** (nur wenn die Historie mindestens 90 % des Zeitraums deckt):
  - **Abweichung:** y = ln(Reihe ÷ Referenz). Angezeigt wird e^y − 1 in %.
  - **Median** der Abweichung im Zeitraum: gepunktete Linie im Hauptchart und im Signal-Chart.
  - **Rückblick:** tiefster und höchster Stand und die idealen Wendepunkte ▲▼. Sie kommen aus einem Zickzack auf dem zentrierten
    7-Tage-Mittel; die Mindestwende ist die halbe Spannweite P10–P90, mindestens 5 %. Beschriftet als „erst im Nachhinein bekannt“.
  - **Live-Signal:** Perzentil der heutigen Abweichung unter den letzten W Tagen, nur mit Daten bis heute. Kauf bei ≤ 10, Verkauf
    bei ≥ 90. Die Schwellen P10/P90 stehen gleitend als Linien im Chart, die Signalzeiten als Flächen.
  - **Bilanz des Live-Signals** (nachgerechnet): Episoden statt Tage, Rendite nach 90/180/365 T gegen Zufallstage, „belegt“ bei
    p < 0,025.
  - **Prognose:** AR(1) um den Median mit Halbwertszeit (90-%-Intervall) und Dickey-Fuller-t (belegt unter −2,86). Die
    Referenzlinie wird fortgeschrieben: Trend der letzten 365 Tage, Power Law mit den Parametern des Monats, Puell konstant 1.
    Ergebnis: Wert in 90/180/365 T mit 80-%-Band aus den eigenen Prognosefehlern der letzten 4 Jahre. Die Rückblick-Prüfung zeigt
    die Abdeckung (Soll 80 %) und den Fehler gegen „die Abweichung bleibt“.
- **Täglich:** `hl_makro.signale(D)` rechnet einmal je Datentag, mit eigenem Schloss; ein Fehler reißt die Charts nicht mit. Der
  Makro-Takt schreibt den Tagesstand nach `mk_signal` (`INSERT OR IGNORE`, `BEGIN IMMEDIATE`). Er wird nie überschrieben: Es bleibt
  der erste Stand je Datentag, so wie er zu sehen war.
- **Live gegen Nachrechnung:** Jede archivierte Zeile wird mit dem Perzentil verglichen, das die heutige Rechnung für denselben Tag
  ergibt (± 0,01). Das steht unter der Signaltabelle und im Stand; bei Abweichung gelb, mit Paaren und Beispielen.
- **Dashboard** (Tabs Bewertung, Trend, Kohorten, Miner):
  - Signaltabelle je Zeitraum, am Handy als Karten.
  - Im Hauptchart die Median-Linie und ▲▼.
  - Je Paar ein Signal-Chart: log. Skala mit %-Teilung, P10/P90 gleitend, Flächen, Prognose mit Band 365 T nach rechts.
  - Text: Lage, Rückblick, Bilanz-Tabelle (aufklappbar) und Prognose-Tabelle.
- **Debug und Berichte:**
  - „★ Makro: Stand und Quellen“ zeigt je Paar und Zeitraum Lage, Live-Signal, Belegtes und die Prognose 365 T mit Band und
    Prüfung, dazu die Nachrechnung.
  - Neu ist „Makro: Selbsttest der Signale (U126)“; der Installer hat damit 32 Schritte.
  - Berichte `u126-makro-signale` (08.10. 20:15) und `u127-makro-nachrechnung` (05.11. 20:15); die Wochenprüfung W14 ist erweitert.

**2. Kalibrierung vor der Auslieferung (eigene Fehler, gefunden durch die Nulltests).**
- **Bilanz:** Der erste Entwurf war ein Block-Bootstrap über alle Signaltage („belegt“, wenn das 90-%-Intervall die 0 ausschließt).
  Auf reinen Zufallswegen erklärte er 26–41 % der Tests für belegt statt 10 %.
  - Ursache: Läufe, in denen der Kurs weiter fällt, werden länger und zählen mit mehr Tagen.
  - Längere Blöcke und ein zirkulär verschobenes Placebo waren ebenso falsch kalibriert.
  - Jetzt: Episoden (Signaltage mit höchstens 30 Tagen Abstand, gemessen ab dem ersten Tag). Je Episode ein Zufallstag aus
    ±(Horizont + 365) Tagen, 1000-mal, einseitig p < 0,025.
  - Ergebnis auf Zufallswegen: 5 von 158 Tests belegt (3,2 %). Im Ära-Nulltest 4 von 80; mit Zufallstagen aus der ganzen Historie
    wären es 16–27 von 80.
- **Prognoseband:**
  - Das AR(1)-Modellband war auf echten Daten zu schmal.
  - Ein Band aus den Fehlern aller Jahre war zu breit (bis 97 % Abdeckung), weil die Schwankung von BTC seit 2011 sinkt.
  - Jetzt: 10.–90. Perzentil der eigenen Fehler der letzten 4 Jahre, nur aus Fehlern, deren Ziel am Ursprung schon bekannt war.
    Rückblick-Prüfung und heutiges Band nutzen dieselbe Regel (`_fehler_bekannt`). Eine Abdeckung wird erst ab 20 Prüfungen genannt.
- **Weitere eigene Fehler, vor der Lieferung behoben:**
  - Das Zickzack zählte den ersten Tag als Wendepunkt (Rand).
  - Puell bekam 26 Wendepunkte in 4 Jahren (Tagesrauschen). Deshalb glättet der Rückblick, und nur er, mit dem zentrierten
    7-Tage-Mittel.
  - „zur Realized Price“: Jedes Paar hat jetzt sein eigenes Bezugswort.
  - Eine Testerwartung für den Referenztrend war falsch angesetzt (das 365-Tage-Fenster lag über dem Knick); der Code war richtig.
  - Der Modulkopf beschrieb nach dem Umbau noch den alten Bootstrap.
  - Der Text „so wie es damals sichtbar war“ war eine Behauptung ohne Beleg. Jetzt heißt es „gewesen wäre“, und die Nachrechnung
    gegen das Archiv prüft es.

**3. Ergebnis auf echten Daten** (Test-Kopie in der Sandbox, Coin Metrics bis 23.05.2026).
- 14 Paare, 63 Paar-Zeiträume, gerechnet in 4,0 s.
- **Bilanz: 3 von 322 Tests belegt. Der Zufall allein ließe etwa 16 erwarten.**
  - Belegt sind Power Law 4 J, Kauf 90 T: +56 % gegen +13 % an Zufallstagen (p 0,014, 7 Episoden).
  - Und XMR 200-W-MA 8 J und „alles“, Verkauf 90 T: −21 % gegen +12 % (4 Episoden, dieselben in beiden Zeiträumen).
  - Damit gibt es keinen Beleg, dass die Zonen die Rendite vorhersagen.
- **Verkaufssignale kamen zu früh:** Nach dem Einstieg lag die Rendite im Median 5,3 Punkte über den Zufallstagen (in 64 % der
  Tests). Das ist Momentum: Das oberste Zehntel wurde oft noch übertroffen. Bei Kaufsignalen: +1,3 Punkte, 52 % (kein Befund).
- **Prognose „Rückkehr zum Median“:** besser als „die Abweichung bleibt“ in 83 % (90 T), 78 % (180 T) und 78 % (365 T) der
  Paar-Zeiträume. Der Median-Fehler war 15/16/19 % kleiner. Das Band traf im Rückblick im Median 81/83/85 % (Soll 80; bei 365 T eher
  zu breit, P90 98 %). Die Rückkehr ist nach Dickey-Fuller in 14 von 63 Fällen belegt.
- **Live gegen Nachrechnung:** Stände vom 06.10.2025, 05.02., 01.04. und 01.05.2026, jeweils mit der Datei nur bis zu diesem Tag,
  gegen die Nachrechnung mit allen Daten: 249 von 249 gleich (größte Abweichung 0,005 Pz = Rundung). Die Kette ist auf echten
  Reihen kausal. Ob die Quellen alte Werte nachträglich ändern, zeigt erst das Archiv auf dem Pi.
- **Live-Signale am 23.05.2026** (Datenstand der Kopie), 12 Stück:
  - BTC Kauf: Power Law 2 J, 200-W-MA 2 J, Langfrist-Kostenbasis 2 J, Stromkosten 4 J.
  - ETH Kauf: 200-W-MA 4 J.
  - ZEC Verkauf: Realized Price 2 J, 4 J, 8 J und alles; 200-W-MA 2 J, 4 J und alles.

**4. Proben.**
- `hl_makro_signal.py --selbsttest`: 12 Prüfungen, rund 3 s, ohne Netz.
  - Perzentil und P10/P50/P90 gegen eine unabhängige Nachrechnung (Lücken, Gleichstände), kausal; auf Rauschen sind je 10 % der Tage
    Kauf und Verkauf.
  - Zickzack an einer Welle, mit Rand und offenem letzten Extremwert.
  - Bilanz: Positivkontrolle (Rückkehr-Märkte, 23 von 24 belegt), Nulltest Zufallsweg (3,2 %), Nulltest Ära (4 von 80).
  - Prognose: Positivkontrolle (φ 0,985 wiedergefunden, Abdeckung 78 %), Nulltest Zufallsweg (nicht besser als „bleibt“).
  - Band ehrlich: Bei wachsender Schwankung trifft es seltener als 80 % (71 %). Das Band folgt den letzten 4 Jahren: Fällt die
    Schwankung auf ein Drittel, ist es so schmal wie ohne die alte Zeit.
  - Referenztrend nur aus der Vergangenheit; Power Law mit den Parametern des Ursprungsmonats.
  - Block: JSON ohne NaN, Median = Median des Zeitraums, die Prognose zielt darauf; Rückblick trotz Tagesrauschen ohne Scheinwenden.
  - Live gegen Nachrechnung: gleich ohne Revision, Revision erkannt.
- `hl_makro.py --selbsttest`: 52 Prüfungen, 3 davon neu.
  - Signale je Tab: alle Paare, Miner bis 4 J, Tagesstand einmal je Tag, Nachrechnung in der Nutzlast.
  - Kausalität der ganzen Kette: Zukunft × 50 ändert kein Perzentil davor (44 Reihen bitgleich).
  - Live gegen Nachrechnung mit echter Ableitung: Stand vom 01.05. gleich der Nachrechnung; eine Revision des BTC-MVRV wird
    erkannt, und zwar nur in `rp:BTC` und `delta:BTC`.
- Mutationen: 36 von 36 rot. Geprüft wurden der Signal-Code und der Signal-Teil von `hl_makro.py`; es zählen beide Selbsttests,
  weil beide im Installer laufen.
  - Darunter: Blick nach vorn im Perzentil, Kaufschwelle 20, Seiten vertauscht, Randpunkt, Rückblick ohne Glättung, Median
    durch Mittel, alle Signaltage statt Episoden, p < 0,05, Zufallstage aus der ganzen Historie.
  - Außerdem: Band kennt spätere Fehler, Band aus allen Jahren, Referenztrend aus der Zukunft, Power-Law-Paar mit Anpassung über
    alle Tage, Archiv überschrieben, Nachrechnung mit Toleranz 50 oder versetztem Tag.
  - Im ersten Lauf blieben zwei grün: „Gleichstände nicht gemittelt“ (der Test rechnete mit derselben Funktion nach) und „Band
    aus allen Jahren“ (kein Test mit Schwankungssprung). Ich habe beide Tests ergänzt; danach waren sie rot.
- Die 37 Mutationen von `hl_makro.py` aus 23.48 erneut, jetzt mit der Signal-Rechnung im Testordner: 37 von 37 rot.
- Sichtprüfung Desktop und Handy (Bewertung, Trend, Kohorten, Miner; Playwright): keine Skriptfehler, keine Seitenbreite über den
  Rand. Die Zeile „Geprüft: 249 archivierte Live-Werte … stimmen mit der Nachrechnung überein“ erscheint.
- `install.py --selftest-isoliert`: 32 Schritte grün (neu „Makro-Signale“, 2,8 s), dazu PNG und 9 Dashboard-Abrufe. Die
  Namensprüfung (symtable) fand nichts; `node --check` für beide Skriptblöcke der Seite und für `/makro.js` ist ok.

**5. Was auf dem Pi zu erwarten ist.**
- Die erste Rechnung kommt beim ersten Aufruf eines Signal-Tabs oder im Takt. In der Sandbox dauert sie 4 s; auf dem Pi 5 schätze
  ich 10–15 s (nicht gemessen; der Stand zeigt „gerechnet in … s“). Danach kommt sie aus dem Zwischenspeicher, neu einmal je Datentag.
- `mk_signal` wächst um rund 63 Zeilen am Tag (etwa 23.000 im Jahr, wenige MB).
- Die Nachrechnung ist ab dem zweiten Archivtag prüfbar; Bericht am 08.10. um 20:15.
- 23.48 und 23.49 einspielen und den FRED-Schlüssel eintragen (U124). Die Signale brauchen FRED nicht.

**Was man wissen muss:**
- Die Dreiecke ▲▼ sind Rückblick, erst im Nachhinein bekannt. Das Live-Signal heißt nur „im untersten bzw. obersten Zehntel des
  Zeitraums“.
- Die Bilanz auf echten Daten zeigt keinen Beleg. Die Zonen beschreiben eine Lage, sie sagen keine Rendite voraus. Verkaufssignale
  kamen historisch zu früh.
- Bei vielen Tests ist etwa jeder zwanzigste zufällig belegt; die Seite nennt die Erwartung neben der Zahl.
- Eine Signifikanzregel erst auf Zufallswegen kalibrieren: Fehlurteile zählen, nicht nur ein Intervall ansehen.
- Prognosebänder außerhalb der Stichprobe prüfen, nur mit Fehlern, die am Ursprung bekannt waren.
- Die Bilanz ist nachgerechnet. Ob sie dem entspricht, was live zu sehen war, zeigt erst das Archiv (U127).
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

## 3τ. OI-Chart baute sich nicht auf: das Binance-Archiv lud ab 2020 vorwärts (05.10., Version 2026-09-23.50, Opus 5.5)

Anlass: Bild des Nutzers 05.10. 16:04 (Handy, Tab „Hebel & Stimmung“, Zeitraum 4 J): Im Chart „Open Interest ÷
Marktkapitalisierung“ steht nur ein senkrechter Strich am rechten Rand. Frage: „Der Graph scheint sich nicht richtig aufzubauen,
prüfe“.

**1. Befund.**
- Die Zeichnung rechnet richtig; es fehlen Daten.
  - Binance liefert per REST (`openInterestHist`) nur die letzten 30 Tage.
  - Die Jahre davor kommen aus dem Archiv data.binance.vision, eine Tagesdatei je Takt (20 s), rund 2.200 Dateien.
- Das Archiv lief ab 01.09.2020 **vorwärts**.
  - Am Pi waren um 12:14 53 Tage da (bis etwa 23.10.2020).
  - Bis 16:04 kommt es nach meiner Rechnung kaum über Mitte 2022 hinaus, weil 23.47 zusätzlich bei FRED hängt (12 × 45 s je
    Runde, U124).
- Der Chart beginnt am ersten Datentag, höchstens beim Anfang des Zeitraums.
  - Weil schon Daten von 2020 da sind, spannt „4 J“ die volle Breite. Sichtbar sind aber nur die 30 REST-Tage.
  - 30 Tage auf rund 20 Pixel ergeben den senkrechten Strich.
- Nachgestellt in der Sandbox: Test-Datenbank mit Open Interest nur 01.09.2020–30.06.2022 und den 30 REST-Tagen, alter Code,
  Handybreite. Es entsteht dasselbe Bild.
- **Eigene Fehler:**
  - Die Reihenfolge des Archivs ließ die sichtbaren Zeiträume (1 J bis 4 J) bis zuletzt leer.
  - Solange das Archiv lud, stand am Chart kein Hinweis.
  - Die Zonenkarte rechnete das OI-Perzentil aus einer lückenhaften Historie.

**2. Gebaut.**
- **Archiv rückwärts:** vom Tag vor den REST-Daten bis 01.09.2020, jüngste Tage zuerst.
  - Vorhandene Tage werden übersprungen, also die REST-Tage und auf dem Pi der Vorwärtslauf bis zum Update.
  - Neuer Zustand `oi_archiv_rueck`; der alte Vorwärts-Cursor bleibt unbeachtet.
  - Bei einem Tag je 20 s ist das letzte Jahr nach rund 2 h da, 4 J nach rund 8 h. Das ist gerechnet, auf dem Pi nicht gemessen.
- **Hinweis unter dem OI-Chart** (gelb), solange das Archiv lädt: Tage da gegen Soll seit 01.09.2020, Abschnitte ohne Lücke,
  fehlende Tage und die Dauer in Stunden.
- **Zonenkarte:** kein OI-Perzentil, solange die Historie lückenhaft ist (Archiv nicht fertig, und mehr als 2 % bzw. 10 Tage
  fehlen). Statt des Perzentils steht „Binance-Archiv lädt noch“ mit Tagen da gegen Soll.
- **Tab „Daten“ und Stand:** „läuft rückwärts (bei …)“, Tage da gegen Soll, offen, Dauer, Abschnitte, 404-Tage.
- Neue Funktion `oi_abdeckung(con)`, die Ableitung gibt sie als `OI_ABDECKUNG` mit. Die Nutzlast des Tabs „Hebel“ trägt sie als
  `oi_archiv`.

**3. Proben.**
- `hl_makro.py --selbsttest`: 53 Prüfungen.
  - Die Archiv-Prüfung ist neu gefasst. Ein Vorwärtslauf bis 24.08. ist schon da, alter Cursor 25.08., 404 am 27.08. Abgerufen
    wird genau 05.09. … 25.08., absteigend. Der Vorwärtslauf wird übersprungen, ein Tag zählt als fehlend, dann ist das Archiv
    fertig: 2 Abschnitte, 0 offen. Zwischendurch nach 3 Schritten: 9 offen.
  - Neu: Hinweis in der Nutzlast, kein Perzentil aus lückenhafter Historie (Testdaten erst ab 12/2022); nach „fertig“ ist es
    wieder da.
- Mutationen 23.50: 9 von 9 rot (vorhandene Tage nicht übersprungen, 404 ohne Weiterschalten, vorwärts statt rückwärts, offen um
  einen Tag daneben, Abschnitte über eine Lücke, Soll ab dem ersten Datentag, lückenhaft auch nach fertig, Perzentil trotz Lücken,
  Nutzlast ohne Archivstand). Erneut mit dem neuen Stand: die 37
  Mutationen von `hl_makro.py` und die 36 der Signale, alle rot.
- Sichtprüfung mit zwei Ständen, Handy und Desktop:
  - „Pi 16:04“: mit dem alten Code der Strich am Rand wie im Bild, mit dem neuen der Hinweis „698 von 2.091 Tagen … etwa 7,7 h“.
  - „2 h rückwärts“: das letzte Jahr ist gefüllt.
  - Zonenkarte und Tab „Daten“ zeigen den Stand. Keine Skriptfehler im Makro-Abschnitt.
- `install.py --selftest-isoliert`: 32 Schritte grün, dazu PNG und 9 Dashboard-Abrufe. Namensprüfung und `node --check` ok.

**4. Auf dem Pi.** 23.50 enthält 23.48 und 23.49.
- Nach dem Update beginnt das Archiv am Tag vor den REST-Daten und füllt rückwärts. Der Hinweis unter dem Chart zeigt den Stand.
- Bis das Archiv fertig ist, steht die OI-Zeile der Zonenkarte ohne Perzentil.
- Der FRED-Schlüssel (U124) beschleunigt nichts am Archiv. Mit 23.48 hält FRED den Takt aber nicht mehr an.

**Was man wissen muss:**
- Lange Nachladeläufe holen das Sichtbare zuerst und zeigen ihren Stand am Chart.
- Ein Perzentil kommt nur aus einer vollständigen Historie. Fehlt der größte Teil, sagt die Zahl nichts.

## 3υ. Überblick: die Reihe hinter jeder Zahl als kleiner Chart (05.10., Version 2026-09-23.51, Opus 5.5)

Anlass: Wunsch des Nutzers 05.10. 16:59: im Makro-Tab „Überblick“ zusätzlich zu den Indikatoren als Zahlen die Chart-Grafiken.

**1. Gebaut.**
- **„Verlauf je Indikator“** unter der Zonenkarte: für jede Zeile ein kleiner Chart (15 Charts; die Tage seit dem Halving haben
  keinen), im Zeitraum der Filterzeile.
  - Je Chart eine Reihe, die der Titel benennt, und eine eigene Skala. Dazu eine Bezugslinie: 1 für Verhältnisse, 0 für Abstände,
    50 für Fear & Greed.
  - Ein Punkt markiert den letzten Tagesschluss. Die Kopfzeile nennt Wert, Datum und Perzentil; unter dem Chart stehen die
    Bedeutung der Bezugslinie und die Quelle.
  - Fadenkreuz-Tooltip und Tabelle wie in den Tabs. Die Farbe folgt dem Indikator wie in seinem Tab.
- **Reihen:**
  - MVRV, Kurs ÷ Fair Value (kausal), Abstand zum 200-Wochen-MA, Kurs gegen Kurzfrist-Kostenbasis und True Market Mean, MVRV-Z,
    Puell.
  - Kurs ÷ Stromkosten, nur 4 Jahre wie bei den Signalen.
  - Hash Ribbons als SMA 30 ÷ SMA 60 − 1, mit den echten Kapitulationen als Flächen.
  - Fear & Greed (30 T), Funding (30 T), OI ÷ Marktkap., DVOL, SSR, ETF-Flüsse (30 T).
- **Nutzlast** `mini` (`hl_makro.mini_reihen`):
  - Die jüngsten 730 Tage täglich, davor jeder 7. Tag. Das sind echte Tageswerte, kein Mittel.
  - Lücken stehen als `null` drin, damit die Linie abbricht statt zu überbrücken (wichtig, solange das OI-Archiv lädt).
  - Der Überblick wächst dadurch von 245 auf 482 kB roh (73 → 122 kB gzip, Test-Datenbank).
- Solange das OI-Archiv lädt, nennt der kleine OI-Chart den Ladestand statt eines Perzentils.
- Beim Wechsel des Zeitraums wird der Überblick neu aufgebaut, damit die Überschrift den Zeitraum nennt.
- Layout: auf breiten Bildschirmen nebeneinander (bei 1280 px drei Spalten) mit gleich hohen Köpfen; auf dem Handy eine Spalte,
  der Kopf darf umbrechen.

**2. Proben.**
- `hl_makro.py --selbsttest`: 54 Prüfungen. Neu ist eine:
  - Je Zeile der Zonenkarte ein kleiner Chart.
  - Jeder Punkt ist gleich dem Wert der Reihe hinter der Zeile an diesem Tag, gegen die Ableitung nachgerechnet; der letzte Punkt
    ist gleich der Zahl der Tabelle (Tag und Wert).
  - Format: 730 Tage täglich, davor Abstand 7; eine Lücke ergibt genau ein `null`; Miner nur 4 Jahre.
- Mutationen 23.51: 8 von 8 rot. Im ersten Lauf blieb „Funding als Tageswert statt 30-Tage-Mittel“ grün: Die Testdaten haben ein
  konstantes Funding, und die Probe verglich nur den letzten Punkt. Deshalb prüft sie jetzt jeden Punkt. Die älteren Proben
  erneut: 37 von 37, 36 von 36 und 9 von 9 rot.
- Sichtprüfung Desktop und Handy:
  - Ausrichtung der Köpfe, Tooltips in drei Charts, Wechsel auf 1 J (die Überschrift folgt).
  - OI-Lücke im Stand „Pi 16:04“: die Linie bricht ab, der Kopf nennt den Ladestand.
  - Keine Seitenbreite über den Rand, keine Skriptfehler im Makro-Abschnitt.
- `install.py --selftest-isoliert`: 32 Schritte grün, dazu PNG und 9 Dashboard-Abrufe. Namensprüfung und `node --check` ok.

**Was man wissen muss:**
- Kleine Vielfache brauchen je Chart eine eigene Skala; vergleichbar ist die Form, nicht die Höhe.
- Eine Probe, die nur den letzten Punkt vergleicht, übersieht vertauschte Reihen, wenn die Testdaten konstant sind.

## 3φ. Plan U130: Makro × Kurs, vorab festgelegt (05.10., nur Dokumente, Version 2026-09-23.51 unverändert, Opus 5.5)

Anlass: Nutzer 05.10. 19:11: „Makrosignale z. B. auf täglicher Basis mit der Kursbewegung korrelieren und prüfen, wie hoch hier die
Wechselwirkung tatsächlich ist … am 25.10. auswerten. Merk es dir. Oder andere Vorschläge?“

**Festgehalten:**
- U130 im Plan, Auswertung am 25.10.
- Die Tests sind in `KONZEPT_Makro.md` Abschnitt 10 vorab festgelegt (05.10. 19:15), bevor ein Ergebnis zu sehen ist: Ziel,
  Merkmale, Maß, Nullverteilung und Schwellen. Was später dazukommt, zählt nur als neue Hypothese.

**Zwei Teile, weil die Daten verschieden alt sind:**
- **Teil A — Makro × BTC-Kurs, Tagesbasis:** 15 Merkmale gegen die Rendite VORWÄRTS über 1, 7 und 30 Tage (45 Tests).
  - Die Makro-Historie reicht bis 2010 zurück; drei Wochen mehr ändern daran wenig (meist unter 1 %, bei den ETF-Flüssen seit
    01/2024 rund 3 %).
  - Teil A ginge also sofort. Mein Vorschlag an den Nutzer: das Werkzeug vorher bauen und gleich laufen lassen; der 25.10. bleibt
    als zweiter Lauf.
- **Teil B — Makro-Regime × 4-h-Prognosen:** braucht die Hyperliquid-Daten seit Mitte September.
  - Am 25.10. ist das nur ein erster Blick: Bei rund 250 Blöcken je Coin sind Unterschiede unter etwa 12 Punkten nicht zu erkennen.
  - Belegbar ab etwa Mitte Januar 2027.

**Regeln aus der eigenen Erfahrung:**
- Nur Rendite vorwärts, nie die desselben Tags.
- Nullverteilung mit erhaltener Autokorrelation, vorher auf Zufallswegen kalibriert. Der erste Bilanz-Test in U126 irrte in 26–41 %
  der Zufallsfälle.
- Belegt nur mit Korrektur für 45 Tests UND gleichem Vorzeichen in beiden Zeithälften.

Kein Code geändert; Paket nur mit den Dokumenten neu, Version und Prüfsumme bleiben (die Prüfsumme deckt nur Code).

## 3χ. Makro × Kurs, Teil A gebaut (U130): Phasen-Null statt Verschiebung (05.10., Version 2026-09-23.52, Opus 5.5)

Anlass: Nutzer 05.10. 19:19 „Ja“ auf die Frage, das Werkzeug für Teil A (Makro gegen BTC-Kurs, ganze Historie) schon vor dem 25.10.
zu bauen. Die Tests standen seit 19:15 fest (`KONZEPT_Makro.md` Abschnitt 10, UEBERGABE 3φ).

**1. Gebaut.**
- **Modul `hl_makro_korr.py`:** 15 Makro-Merkmale am Tag t (nur Daten bis t) gegen die BTC-Rendite r(t → t+h) für h = 1, 7 und 30
  Tage, also 45 Tests.
  - Maß: Spearman ρ und ρ², dazu beschreibend die Rendite im obersten gegen das unterste Drittel.
  - Null: Phasen-Surrogate (Abschnitt 2). Benjamini-Hochberg über alle gerechneten Tests, beide Hälften (bis 2021 / ab 2022),
    Nachrechnung gegen `mk_stand`.
  - Bericht mit Zufallserwartung, nicht prüfbaren Merkmalen und Merkmalen ohne erste Hälfte.
- **Debug:** „★ Makro × Kurs (U130, Teil A)“ und „Makro × Kurs: Selbsttest“.
- **Berichte:** `u130-makro-korr` am 06.10. 20:30 (erster Lauf mit allen Quellen) und `u130-makro-korr-2510` am 25.10. 20:15.
- **Installer:** 33 Schritte (neu „Makro × Kurs“, rund 14 s in der Sandbox).
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

**2. Kalibrierung vor dem ersten Blick auf echte Daten: Der Plan nannte zwei Verfahren, beide fielen durch.**
- Gerechnet wurden 4.050 Tests auf Zufallswegen mit Volatilitäts-Clustern und unabhängigen, zähen Merkmalen (AR 0,995, Perzentil
  eines Zufallswegs, 30-Tage-Mittel).
- **Zirkuläre Verschiebung:** 1,7 % Fehlurteile bei p < 0,01 und 6,5 % bei p < 0,05; bei Perzentilen bis 2,7 % und 8,7 %.
- **Blockbootstrap mit Blocklänge h:** bis 20 % bei p < 0,05.
- **Gewählt: Phasen-Randomisierung** (Ebisuzaki 1997) mit 0,8 % und 5,4 %. Sie erfüllt das Ziel des Plans: Autokorrelation erhalten,
  rund 5 % Fehlurteile.
- Grund für das Versagen der Verschiebung: Bei zähen Merkmalen tragen wenige tiefe Frequenzen die Korrelation. Eine Verschiebung
  dreht alle Phasen nur gemeinsam, die Surrogate ziehen sie unabhängig.
- Eigener Fehler: Im Plan standen nur diese zwei Verfahren zur Wahl, und ich hatte erwartet, dass die Verschiebung besteht. Erst
  die Kalibrierung mit großer Stichprobe zeigte das Gegenteil; ein erster Lauf mit 80 Märkten schwankte zu stark für ein Urteil.

**3. Vorschau in der Sandbox** (nur die 5 Merkmale aus Coin Metrics mit echten Daten bis 23.05.2026; die übrigen Reihen der
Test-Datenbank sind synthetisch).
- 0 von 15 Tests belegt, Benjamini-Hochberg 0, unkorrigiert p < 0,10 einmal (Zufall allein ≈ 1,5).
- ρ liegt zwischen −0,10 und +0,20, ρ² ist höchstens 4,2 % (Puell, 30 Tage, p 0,32).
- MVRV, MVRV-Z, 200-Wochen-MA und Power Law drehen das Vorzeichen zwischen den Hälften.
- Puell bleibt in beiden Hälften positiv, ab 2022 aber unter 0,05.
- Der ganze Bericht über alle 45 Tests der Test-Datenbank: die synthetischen Merkmale 3 von 45 unter p < 0,10 bei 4,5 erwartet. Die
  Maschine sieht dort, wie es sein soll, nichts.

**4. Proben.**
- Selbsttest: 8 Prüfungen, rund 14 s.
  - Ränge und FFT gegen direkte Rechnung; Streuung der Phasen-Null = 1/√n.
  - Nulltest auf Zufallswegen: p < 0,05 höchstens 8 %, p < 0,01 höchstens 2,5 %.
  - Positivkontrolle (ρ ≈ 0,12): 10 von 10 Märkten erkannt.
  - Ära: Die Ganzprobe ist auffällig, die Hälften nicht.
  - Urteil braucht alle drei Bedingungen; FRED-Versatz; zu kurze Reihe; ganze Auswertung mit Nachrechnung.
- Mutationen: 11 von 11 rot.
- `install.py --selftest-isoliert`: 33 Schritte grün (neu „Makro × Kurs“, 15,1 s), dazu PNG und 9 Dashboard-Abrufe. Die
  Namensprüfung ist ohne Befund (nur `__file__`, wie in `version.py`).

**5. Auf dem Pi.**
- Debug „★ Makro × Kurs“ läuft nach dem Update sofort, rund 7 s in der Sandbox; auf dem Pi geschätzt 20–30 s.
- OI fehlt, bis das Archiv fertig ist; FRED fehlt bis zum Schlüssel. Kurzfrist-Kostenbasis, DVOL und ETF-Flüsse werden gerechnet,
  haben aber keine erste Hälfte und sind nach der Regel nie belegt.
- Bericht am 06.10. 20:30, bitte hochladen.

**Was man wissen muss:**
- Ein Verfahren, das „die Autokorrelation erhält“, ist nicht automatisch kalibriert. Nur die Zählung auf Zufallswegen entscheidet,
  und zwar mit großer Stichprobe.
- Eine Abweichung vom vorab festgelegten Plan ist erlaubt, wenn sie vor dem ersten Blick auf echte Daten fällt, das Ziel des Plans
  erfüllt und dokumentiert ist.

## 3ψ. Vorbedingungen: Rückgänge ≥ 3 % wurden zu selten erfasst (Nutzerfund 05.10. 20:42; 05.10., Version 2026-09-23.53, Opus 5.5)

Anlass: Nutzer 05.10. 20:42: „Bei dem Punkt Vorbedingungen ... vor Rückgängen > 3 % noch zu wenig Ereignisse. Es gab bereits mehrere
Rückgänge, aber es steht dort nicht einmal eine Tabelle, als hätte er die Rückgänge nicht registriert. Bitte überprüfen.“

**1. Befund.** Die Tabelle erscheint ab 3 Ereignissen je Richtung. Gezählt wurde seit 23.7 (U25) so:
- Bezugskurs war nur die erste Prognose je 4-h-Block (00, 04, 08 … Uhr UTC). Ein Rückgang zählte, wenn das Tief der folgenden
  24 h mindestens 3 % unter diesem Kurs lag.
- Ereignisblöcke wurden verkettet: Ein Ereignisblock bis 24 h nach dem VORIGEN gehörte zum selben Ereignis.
- **Fehler 1, Bezug am Blockbeginn:** Liegt das Hoch mitten im Block, erscheint der Rückgang kleiner, als er war.
  - Echte BTC-Kerzen (Crypto.com BTCUSD-PERP, 4 h, abgerufen 05.10.): 02.10. Hoch 87.238 → Tief 83.855 = −3,9 %. Vom Beginn der
    Blöcke aus nur −2,59 % (08:00) und −2,94 % (12:00), also nicht gezählt.
  - Zwischen 27.09. 12:00 und 05.10. sah kein einziger Block −3 %; der Chart zeigt in dieser Zeit −3,1 % (27./28.09.) und −3,9 %.
- **Fehler 2, Verkettung:** Getrennte Bewegungen fielen zusammen. Zwei Rückgänge mit voller Erholung 30 h auseinander zählten als
  einer, ebenso eine Treppe mit 24–36 h Pause und ein neuer Rückgang nach einer Bodenbildung.
- **Fehler 3, Anzeige:** Sie zeigte weder die gezählten Ereignisse noch den Zeitraum der Rückschau. „Noch zu wenige Ereignisse“
  stand auch dann, wenn die Zahl gereicht hätte und nur kein Treiber genug Werte hatte.
- Kein Fehler, aber jetzt sichtbar: Die Rückschau reicht nur so weit wie die Ablage (`forecast` hält 60 Tage; auf dem Pi
  Prognosen seit etwa 11.09.). Die letzten 24 h sind noch offen.
- Wirkung auf Zufallswegen (40 Läufe, 24 Tage, Tagesschwankung 2 % wie BTC zuletzt): Der Chart zeigt im Mittel 8,1 Rückgänge ≥ 3 %
  binnen 24 h (10–90 %: 5–11). Die alte Zählung fand im Mittel 4,7 (3–7), in 10 % der Läufe unter 3. Bei 3 % Tagesschwankung
  13,2 gegen 6,4.
- **Eigener Fehler:** seit 23.7 so gebaut und nie gegen den Chart geprüft. Der Nulltest prüfte nur, dass Rauschen keinen Lift
  erzeugt, nicht, ob die Ereignisse vollständig sind. Welche Zahl der Nutzer auf dem Pi sah, ist von hier nicht nachzuprüfen;
  der neue Debug-Eintrag zeigt sie (bisherige Zählung neben der neuen).

**2. Gebaut (U131, `hl_konstellation.py`).**
- **Bezugspunkte:** jede gespeicherte Prognose, die erste je 15-min-Fenster (wie beim Lernen). Kandidat ist ein Punkt, wenn der Kurs
  binnen 24 h mindestens 3 % von seinem Kurs aus lief (Hoch bzw. Tief der 1-min-Bars in (t, t + 24 h], dieselbe Fensterregel wie
  bisher).
- **Ein Ereignis = eine Bewegung** (`ereignisse()`):
  - Ein Kandidat gehört zum laufenden Ereignis, wenn zwei Dinge gelten:
    - Die Bewegung läuft noch (der Kurs war noch nicht bis auf 1,5 % an ihrem Extrem, `NAEHE_V`), oder der Kandidat läuft auf
      dasselbe Ziel zu (schon das bisherige Extrem liegt 3 % unter bzw. über seinem Kurs).
    - Seit dem Eintreten der Bewegung (erster Bar jenseits der Schwelle der Vorbedingung) hat sich der Kurs nicht um 3 %
      zurückbewegt.
  - Sonst beginnt ein neues Ereignis. Die Vorbedingung ist der früheste Punkt.
  - Das Extrem ist das tiefste Tief bzw. höchste Hoch, das die Fenster der Punkte sehen. Das „Ankommen“ mit 1,5 % Abstand macht die
    Regel unabhängig davon, wo in einer flachen Bodenzone das tiefste Tief zufällig liegt.
  - „Dasselbe Ziel“ verhindert eine Doppelzählung: Ein früher Docht kann das Ereignis zu früh „ankommen“ lassen; die Punkte danach
    zählten sonst ein zweites Mal auf dasselbe Tief (auf Zufallswegen 2 von 343 Bewegungen, mit der Regel 0 von 337).
- **Unverändert:** Basis (alle 4-h-Blöcke), Lift, z und die Konstellationen. `faelle` und Konstellationen sind bitgleich zum alten
  Stand (5 von 5 Nullszenarien).
- **Anzeige:**
  - Zeitraum der Rückschau, Zeitpunkt der Berechnung, Bezug.
  - Je Richtung die erfassten Ereignisse: Zeit, Bewegung vom Kurs der Vorbedingung, größte Bewegung eines Punkts, Tief bzw. Hoch.
  - Leer-Meldung nach Ursache: „2 von mindestens 3“ oder „kein Treiber mit Werten in mindestens 3“.
  - Ein gespeicherter Stand von vor 23.53 ist gelb markiert, bis er neu gerechnet ist (stündlich).
  - Auf dem Handy stehen die beiden Spalten untereinander.
- **Debug „★ Vorbedingungen: Ereignisliste (U131)“** (`--vorbedingungen`), je Coin:
  - die erfassten Ereignisse;
  - der Abgleich mit den Kursdaten: dieselbe Erkennung auf Hoch bzw. Tief jedes 15-min-Abschnitts, also das, was der Chart zeigt.
    Jede nicht erfasste Bewegung steht mit Grund da: „vom Prognosekurs aus höchstens −2,9 %“ (15-min-Takt), „keine Prognose
    gespeichert“ (Lücke der Ablage) oder „im benachbarten Ereignis enthalten“;
  - die bisherige Zählung (`_ereignisse_alt`, gibt exakt die alten Zahlen).
- **Berichte:** `u131-vorbedingungen` am 06.10. 20:45 (mit der Probe), dazu wöchentlich in der Wochenprüfung (W8).
- Rechenzeit `berechnen` je Coin 0,36 → 0,70 s in der Sandbox (60 Tage, Prognosen zu 8,9 kB), stündlich; auf dem Pi geschätzt das
  Zwei- bis Dreifache (nicht gemessen). Debug-Eintrag 1,6 s je Coin in der Sandbox.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.). `hl_familien` nutzt aus diesem Modul nur das 15-min-Raster der
  Ereignis-Profile (U43); das ist unverändert.

**3. Proben.**
- `hl_konstellation.py --nulltest` (Installer-Schritt) enthält die Probe `_vorbed_probe`:
  - **15 Szenarien** mit bekannter Zahl von Bewegungen: Hoch mitten im Block (und Spiegelbild), zwei Rückgänge mit Erholung, langer
    Rückgang (−8 % über 20 h), Treppe mit 36 h und mit 24 h Pause, Bodenbildung mit Docht, Lücke vor dem Tief, Lücke in der Ablage,
    Docht vorab, Zwischenerholung 2 %, Docht am Fensterende, ruhig, bekannte Grenze (Abschnitt 4).
  - Je Ereignis wird geprüft: die Zahl, die Vorbedingung in den 24 h vor der Schwelle, das angezeigte Extrem nicht vor dem Ende der
    Bewegung und nicht hinter dem Beginn des nächsten Ereignisses, und der Abgleich mit den Kursdaten (alles erfasst).
  - Die alte Zählung belegt den Fehler: Hoch mitten im Block 0 statt 1, zwei Rückgänge mit Erholung 1 statt 2, Treppe (36 h, 24 h),
    Bodenbildung, Docht und Lücke in der Ablage je 1 statt 2.
  - Extrema je Punkt gegen eine Rechnung von Hand (Python-Schleife über die Bars).
  - **Positivkontrolle des Profils:** Ein Vorläufer, eingepflanzt vor 7 Rückgängen bzw. 7 Anstiegen, steht oben mit Lift +79 pp,
    z 4,4. Die Rauschtreiber bleiben bei |z| ≤ 1,4.
  - Stabil über 12 Seeds.
- **Nulltest:** unverändert bestanden. Unter Rauschen haben die Profile |z| ≥ 2 in 4,2 % der 120 Werte (Mittel −0,03, SD 1,05,
  höchstens 3,0); gepoolt mit den Paaren |z| ≥ 3 in 0,3 % (Soll ≤ 5 %).
- **Mutationen: 14 von 17 rot.** Grün blieben drei, alle ohne Wirkung auf das Ergebnis:
  - Gegenbewegung gegen das Extrem des eigenen Bars statt des vorigen; das macht nur bei einer 1-min-Kerze mit über 3 % Spanne einen
    Unterschied.
  - „Extrem nicht nachgeführt“ und „Ankommen nicht nachgeführt“: Ein Kandidat, der auf das tiefere Extrem zuläuft, hängt über
    „dasselbe Ziel“ ohnehin an.
- **Zufallswege** (40 Läufe, 2 % Tagesschwankung, 24 Tage, beide Richtungen): 660 Bewegungen laut Kursdaten, 630 erfasst (95 %).
  - 29 der 30 nicht erfassten lagen vom Prognosekurs aus knapp unter 3 % (15-min-Takt gegen das Hoch des Abschnitts).
  - Eine wurde mit der benachbarten zusammengefasst (Abschnitt 4).
  - Rückgänge: im Mittel 7,4 Ereignisse gegen 8,1 im Chart (alt 4,7); bei 3 % Tagesschwankung 12,6 gegen 13,2 (alt 6,4).
  - Doppelt gezählt (zwei Ereignisse auf dasselbe Extrem, 20 Läufe): 0 von 337.
- Lauf auf der Demo-Datenbank: Die Anzeige des ersten von zwei Rückgängen zeigte zunächst das Tief des zweiten (ZEC, zweimal
  „Tief 18:57“). Behoben: Die Anzeige endet beim Beginn des nächsten Ereignisses. Szenario „Lücke in der Ablage“ und die
  Mutation „Anzeige wie vorher“ sichern das.
- Sichtprüfung Desktop und Handy (keine Seitenbreite über den Rand), `node --check` beider Skriptblöcke, Namensprüfung ohne Befund.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Bekannte Grenze.** Steigt der Kurs in einen Rückgang hinein und folgt binnen weniger Stunden nach einer Erholung ein tieferer,
dann erreicht die früheste Vorbedingung 3 % erst mit dem zweiten Tief. Beide zählen dann als ein Ereignis (Szenario
GRENZE_ZWEITER_TIEFER; auf Zufallswegen 1 von 660 Bewegungen). Eine Zuordnung nach dem Zeitpunkt, an dem die Schwelle reißt,
würde das lösen. Nach meiner Durchrechnung von Hand zählt sie aber einen Wiederholungstest des Tiefs (W-Boden) doppelt; deshalb
ist sie nicht gebaut.

**5. Auf dem Pi.**
- Nach dem Update rechnet das Dashboard die Vorbedingungen binnen einer Stunde neu (mit der Kalibrierung v2, stündlich je Coin).
  Bis dahin steht „Stand vor 23.53“.
- Debug „★ Vorbedingungen: Ereignisliste“ zeigt sofort, welche Rückgänge und Anstiege erfasst sind und welche nicht, mit Grund.
- Bericht am 06.10. 20:45 bitte hochladen.

**Was man wissen muss:**
- Ein Ereigniszähler wird gegen das geprüft, was der Chart zeigt. Ein Nulltest belegt nur, dass kein Scheinzusammenhang entsteht.
- Bezugspunkte in einem groben Raster verkleinern Bewegungen systematisch, weil der Rasterbeginn fast nie am Hoch liegt.
- „Zusammenfassen“ braucht eine Regel für das Ende einer Bewegung. Verketten nach Zeitabstand legt getrennte Bewegungen zusammen.

## 3ω. Makro: Kursleiste unter jedem Kennzahl-Chart (Nutzerwunsch 05.10. 22:21; 05.10., Version 2026-09-23.54, Opus 5.5)

Anlass: Nutzer 05.10. 22:21: „Kann man die Makro Charts für den korrelierenden Zeitbereich überlagern mit dem BTC Kurs (orange) um
Korrelationen zu erkennen?“

**1. Entscheidung: eigenes Feld statt zweiter y-Achse.**
- Den Kurs in dasselbe Feld zu legen, braucht eine zweite y-Achse. Deren Bereich ist frei wählbar; mit passender Wahl laufen fast
  beliebige zwei steigende Reihen im Bild gleich. Der Gleichlauf wäre dann ein Werk der Skalierung, nicht der Daten.
  `KONZEPT_Makro.md` Abschnitt 5 schließt das seit U121 aus („eine y-Achse je Chart“).
- Gebaut ist die **Kursleiste**: unter jedem Kennzahl-Chart ein eigenes Feld mit dem Kurs in BTC-Orange (#f7931a, Wunsch des
  Nutzers), eigener log. Skala, derselben Zeitachse und gemeinsamem Fadenkreuz. Der Tooltip nennt Kennzahl und Kurs am selben Tag.
  Gleichlauf, Vorlauf und Wendepunkte sind so sichtbar, ohne dass eine Skalenwahl sie erzeugt.
- **Zeitraum:** kommt nur aus den Reihen des Charts; der Kurs verlängert die Achse nie (ETF-Flüsse ab 2024, Hochzinsspread mit
  kürzerer Historie). In Signal-Charts mit Prognoseteil endet die Leiste am letzten Kurstag.
- **Keine Leiste:** Charts, die den Kurs selbst zeigen (dort bleibt er die neutrale hellgraue Linie), „Halving-Zyklen übereinander“
  (Zeitachse in Tagen nach dem Halving) und die Korrelationscharts im Tab Makro (sie zeigen die Beziehung zum Kurs schon selbst).
- **Münze:** In Bewertung und Trend mit ETH zeigen die Charts der Münze deren Kurs („Kurs ETH“), alle übrigen den BTC-Kurs.
- **Schalter „BTC-Kurs“** in der Zeitraum-Leiste: Standard an, im Browser gemerkt. Die Tabellenansicht hat eine Kursspalte.
- **Farbe:** Orange liegt außerhalb des Helligkeitsbands der dunklen Palette und nahe an #d95926 (ΔE 14,6) und #c98500 (ΔE 9,0;
  `validate_palette.js`). Deshalb steht es nur im eigenen Feld, nie in derselben Fläche wie diese Farben, und immer mit der
  Beschriftung „Kurs BTC · log. Skala“.
- **Hinweis im Überblick:** Gleichlauf im Bild ist kein Beleg. Viele Kennzahlen sind aus dem Kurs gerechnet (MVRV, Puell, Abstand
  zum 200-Wochen-MA …) und laufen deshalb mit ihm. Ob eine Kennzahl die künftige Rendite vorhersagt, misst „Makro × Kurs“ (U130).

**2. Gebaut (U132).**
- `hl_makro.py`: Die Tabs Hebel & Stimmung, Kapitalfluss und Makro tragen den Kurs jetzt als `r.P`; die übrigen hatten ihn schon.
  Je dieser drei Tabs +41,9 kB roh, gepackt +17 bis +18 kB (gzip 6; der Server packt mit Stufe 1). Die anderen fünf Tabs sind
  gleich groß wie vorher.
- `hl_makro_js.py`: `mkZeichne` zeichnet die Leiste (`mkKursReihe`, `MK_BTC`; Höhe 28 % der Charthöhe, mindestens 46 px, dazu 8 px
  Abstand), `mkTabelleHtml` mit Kursspalte, Schalter `mkKursUm`, `kurs` in 26 Chart-Definitionen.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

**3. Proben.**
- **Makro-Selbsttest** (Installer-Schritt), neue Prüfung „Kursleiste“: Jede Nutzlast eines Chart-Tabs trägt den Kurs. JEDER Punkt
  und jede Lücke ist gleich der Ableitung am selben Tag, Anfang und Ende eingeschlossen (BTC in 8 Tabs, dazu Bewertung und Trend
  mit ETH: Kurs ETH). 10 Nutzlasten; der Selbsttest hat jetzt 55 Prüfungen, rund 10 s.
  - Mutationen 6 von 7 rot: Hebel ohne Kurs, Kurs einen Tag versetzt, 30 Tage zu früh zu Ende, grob gerundet, ETH-Charts mit
    BTC-Kurs (Trend, Bewertung). Grün blieb „Lücken gefüllt“: Der Testkurs hat keine Lücke, die Mutation wirkt dort nicht.
  - **Eigener Fehler, vor der Lieferung behoben:** Die Prüfung sah zuerst nur den Anfang der Reihe, nicht das Ende. Eine 30 Tage zu
    früh endende Kursreihe wäre durchgegangen; das zeigte erst die Mutationsliste.
- **Browserprobe** (Playwright gegen ein Dashboard mit Testdaten, Desktop 1280 px und Handy 390 px; Werkzeug der Sandbox, nicht im
  Paket):
  - Leisten je Tab: Überblick 15 von 16 Charts, Bewertung 5/6, Trend 4/7, Kohorten 7/8, Miner 7/8, Hebel 5/5, Kapitalfluss 4/4,
    Makro 7/14 (die 7 Korrelationscharts ohne). Kein Chart hat Kurslinie und Leiste zugleich.
  - **Gegen Quellen außerhalb des Browser-Codes**, an 54 Fadenkreuz-Stellen in 6 Tab/Münz-Kombinationen (Überblick, Hebel, Trend,
    Makro, Bewertung ETH, Trend ETH):
    - Der Tooltip-Kurs ist der Rohwert in `makro.db` am Tooltip-Tag (Toleranz eine Einheit der 5. Stelle, so rundet die Nutzlast).
    - Die Höhe des Leistenpfads am Fadenkreuz ist der Rohkurs auf der beschrifteten log. Skala (Fit durch die
      Achsenbeschriftungen, Abweichung höchstens 0,6 px). Das prüft gemeinsame Zeitachse und Skala zugleich.
  - Schalter: aus → keine Leiste, Charts niedriger (Hebel 264 → 200 px), nach Neuladen weiter aus; an → wieder da. Tabelle mit
    Spalte „Kurs BTC“. Keine Seitenbreite über den Rand, keine Skriptfehler.
  - Mutationen im Browser 8 von 8 rot: Pfad 30 Tage versetzt, eigene Zeitachse aus der ganzen Kurshistorie, Achsenbeschriftung ×2,
    Tooltip ohne Kurs, Kursreihe einen Tag versetzt, Name immer „Kurs BTC“, Schalter nicht gemerkt, Schalter ohne Neuzeichnen.
  - Zwei Fehler der Probe selbst, behoben: Der Filter „Chart zeigt den Kurs“ (/^Kurs/) griff auch bei „Kurs ÷ Stromkosten“. Und im
    Prognoseteil der Signal-Charts gibt es keinen Kurs; dort darf der Tooltip keinen zeigen, das ist jetzt die Regel der Probe.
  - Sichtprüfung der Bilder (Hebel Desktop und Handy, Überblick, Makro): Die unterste Beschriftung des Charts und die oberste der
    Leiste stehen getrennt, die Leiste ist beschriftet.
- `node --check` (`hl_makro_js.MAKRO_JS`), Namensprüfung ohne Befund.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Auf dem Pi.** Nach dem Update sofort sichtbar; die Daten liegen schon in `makro.db`, nichts wird neu gerechnet. Der Schalter
„BTC-Kurs“ blendet die Leisten aus.

**Was man wissen muss:**
- Zwei Reihen verschiedener Einheit nie über zwei y-Achsen in ein Feld. Getrennte Felder auf gemeinsamer Zeitachse zeigen
  Gleichlauf, Vorlauf und Wendepunkte, ohne dass eine Skalenwahl die Korrelation erzeugt.
- Bei Kennzahlen aus dem Kurs ist Gleichlauf mechanisch. Ob eine Kennzahl etwas vorhersagt, zeigt nur die Rendite danach (U130).
- Eine Probe der Anzeige vergleicht mit Quellen außerhalb des geprüften Codes: Rohdaten aus der Datenbank, Geometrie aus der
  Beschriftung. Sollwerte aus denselben JS-Funktionen bestätigen nur sich selbst.
- Eine Reihenprüfung prüft Anfang UND Ende; „jeder Punkt gleich“ über die gelieferten Punkte übersieht eine verkürzte Reihe.

## 3αα. Treiber-Hygiene: „tot“ war bei Ereignis- und jungen Treibern falsch (Nutzerfund 05.10. 23:18; 05.10., Version 2026-09-23.55, Opus 5.5)

Anlass: Nutzer 05.10. 23:18 mit zwei Fotos (BTC: Treibertabelle und aufgeklappte Hygiene „12 von 34 auffällig“): „Bei Treiber
Hygiene stehen viele Treiber als ohne Event …, aber das stimmt nicht, sie sind nur gerade in diesem Moment nicht aktiv oder haben
wenige Events.“ (Abschnitte nach 3ω laufen mit doppelten griechischen Buchstaben weiter, wie nach 3z die doppelten lateinischen.)

**1. Befund.**
- Die Hygiene (`hl_familien.hygiene`, seit 23.25, U62) bewertet nicht den Moment, sondern den ganzen Zeitraum der Familien (auf
  dem Pi Prognosen seit etwa 11.09., rund 24 Tage). „tot“ hieß ein Treiber, wenn eine von drei Regeln griff:
  - weniger als 20 % der 15-min-Punkte mit Wert;
  - weniger als 8 Blöcke im Zeitraum;
  - Streuung des Werts unter 0,02.
- Inaktive Treiber werden nicht gespeichert: `forecast_drivers` erhält nur die aktiven, die Tabelle zeigt die übrigen mit „kein
  Ereignis“. Die 20-%-Regel traf deshalb genau die Ereignis-Treiber. Auf dem Foto: Kapitulation 2 %, Vol-Spike-Reversion 6 %,
  Crowding-Extrem 7 %, Liquidationsdruck 9 %, OI-Überhitzung 10 %.
- Dazu Treiber, die erst seit Kurzem rechnen:
  - Crowding-Trend 7 T, 14 %: braucht 21 Tage `lb_trend`, also Werte ungefähr ab 02.10.
  - Kaskaden-Asymmetrie, 7 %: auf dem Pi seit 04.10. abends (23.46).
- Funding hat immer einen Wert (100 %), aber fast immer ±0,00. Der Score sättigt erst bei 0,02 %/h Prämie, das ist die
  Streuungs-Regel.
- Gemessen wurde zudem nur an festen Blockanfängen. Ein Ereignis-Treiber, der zwei Stunden aktiv ist, fiel meist zwischen zwei
  Anfänge.
- Wirkung: nur Anzeige und Debug-Bericht. Familienwerte, Darwin-Stufen, Fusion und v3 lesen die Hygiene nicht.
  - Das Wort wurde aber benutzt: Am 30.09. (3θ) hieß die Elite-Positionierung „tot“ (damals unter 20 % Werte), ein Grund für U97.
  - Die Pi-Berichte vom 30.09. zeigen „tot“ auch bei MA 200 Tage, MA 50 Wochen, Smart-Flow, Wal-Flow, Leaderboard-Flow und den
    Pool-Treibern.
- **Eigener Fehler:** seit 23.25 so gebaut. Der Selbsttest prüfte „nachlaufend“ und „umgekehrt?“ nur mit Treibern, die immer einen
  Wert haben, nie mit einem Ereignis-Treiber.

**2. Gebaut (U133, `hl_familien.py`, Anzeige in `hl_viz.py`).**
- **Fälle** (`_hyg_faelle`): Zeitpunkte MIT Wert im Abstand von mindestens einem Horizont, davor und danach je ein ganzes Fenster.
  - Ein Treiber mit Wert an jedem Punkt bekommt genau die Blockanfänge wie bisher.
  - Ereignis- und junge Treiber werden an ihren aktiven Zeiten gemessen. Die Fenster überlappen nie.
- Ab 8 Fällen wird bewertet wie bisher: nachlaufend, umgekehrt? oder ok.
- **„kein Urteil“ statt „tot“**, immer mit Grund. Es ist kein Befund gegen den Treiber.
  - „Ereignis-Treiber: 3 Fälle (8 nötig), aktiv 2 % der Zeit“
  - „Werte erst seit 1,7 Tagen: 6 Fälle (8 nötig)“
  - „nur zeitweise aktiv (… % der Zeit): … Fälle“
  - „Wert bewegt sich kaum: Streuung 0,003, größter Betrag 0,01“
  - „bei jedem Fall derselbe Wert (+0,80) … die Richtung zeigt die Trefferquote in der Treibertabelle“: Kapitulation liefert
    nur ±0,8, ein Zusammenhang braucht verschiedene Werte.
- **Neu in der Tabelle:**
  - Spalten „Fälle“, „aktiv“ (Anteil der Zeit mit Wert) und „zuletzt“ (letzter Zeitpunkt mit Wert); Marke „· Ereignis“.
  - Unter jedem r sein 95-%-Intervall (Fisher-z). Bei 10 Fällen liegt auch r = 0,61 noch im Zufall (−0,03 … 0,90).
  - Die Befund-Spalte bricht um, damit die Zahlenspalten sichtbar bleiben.
- **Kopfzeile:** „auffällig“ zählt nur nachlaufend und umgekehrt?, daneben „… ohne Urteil“ und „… ausgeschlossen“.
- **Debug-Bericht `familien`:** eine eigene Zeile „Ohne Urteil (kein Befund gegen den Treiber)“.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.); sie lesen aus `hl_familien` nur `FAMILIEN`.

**3. Proben.**
- **Selbsttest `hl_familien.py --nulltest`** (Installer-Schritt): 22 Prüfungen statt 9.
  - Die neuen Testreihen kommen aus einem eigenen Zufallsstrom; die übrigen Reihen sind bitgleich zum bisherigen Selbsttest.
  - Der Fund ist nachgestellt: Die Regel bis 23.54 nennt alle sieben eingebauten Fälle „tot“.
  - Positivkontrolle: Liquidationsdruck in Schüben (12 % aktiv), kennt die kommenden 4 h. Er wird bewertet, Zukunft r +0,91 bei 24
    Fällen.
  - Ein Ereignis-Treiber gegen die vergangene Stunde (Vol-Spike-Reversion) fällt als „nachlaufend“ auf (r −0,77, 90 Fälle).
  - Ereignis-Rauschen bleibt unauffällig. Ein junger Treiber mit 5 Tagen wird bewertet (29 Fälle).
  - „kein Urteil“ mit dem richtigen Grund: 1 Tag („erst seit 1,0 Tagen“), Funding fast ohne Ausschlag („bewegt sich kaum“),
    immer derselbe Wert („derselbe Wert“) und 3 kurze Schübe („Ereignis-Treiber: 3 Fälle“).
  - Die 27 Treiber mit Wert an jedem Punkt sind in Befund, r und n bitgleich zur Regel bis 23.54. Die alte Regel bleibt dafür als
    `_hygiene_bis_23_54` im Modul.
  - Zeitpunkte „zuletzt“ und „erster Wert“, das Intervall exakt, der Bericht trennt „ohne Urteil“.
  - Über 12 Seeds besteht alles Neue. Bei Seed 4 fällt die ältere Prüfung „ETF (reines Rauschen) ohne Beleg“ mit z −3,2; das tat
    sie schon mit 23.54, unberührt von dieser Änderung (der Installer nutzt Seed 5).
- **Mutationen: 14 von 14 rot.** Dazu gehören: 20-%-Regel zurück, feste Blockanfänge, überlappende Fenster, ohne Streuungsprüfung,
  kein „erst seit“, kein Ereignis-Grund, „zuletzt“ verschoben, Bericht zählt „kein Urteil“ als auffällig, Mindestfälle 3, ohne
  Zeitbezug, Ereignis-Marke falsch, „derselbe Wert“ nie, Intervall mit 1/√n, Intervall fehlt.
- **Nullsimulation:** 2.000 Läufe je Art, Kurs mit Schwankungsclustern, Werte unabhängig vom Kurs.
  - Fehlalarme (nachlaufend oder umgekehrt?) je Art 0,00–0,35 %. Dauer-Treiber 0,30 % (95 %: 0,14–0,65 %), also wie bisher.
  - Schübe 0,00–0,30 %, Schübe nur bei hoher Schwankung 0,20 %, junge Treiber 0,10 %.
  - Das 95-%-Intervall enthält die 0 in 94,1–95,9 % der Fälle.
- **Sichtprobe** mit Pi-ähnlichen Testdaten: 24,5 Tage, Ereignis-Treiber 2–10 % aktiv, Crowding-Trend seit 3,5 Tagen, Kaskaden seit
  1,7 Tagen, Funding fast 0.
  - Kopf „2 von 34 auffällig (60-min-Trend, RSI) · 2 ohne Urteil · 1 ausgeschlossen“.
  - Bewertet: OI-Überhitzung (12 Fälle), Crowding-Extrem (10), Liquidationsdruck (19), Vol-Spike-Reversion (46), Crowding-Trend
    (20), Kaskaden (10). Ohne Urteil: Kapitulation (immer +0,8) und Funding.
  - Desktop und Handy ohne Seitenbreite über den Rand; die Tabelle scrollt am Handy in sich. Keine Skriptfehler, `node --check`
    beider Skriptblöcke, Namensprüfung ohne Befund.
- Rechenzeit der Hygiene 24 → 60 ms je Coin (24,5 Tage, Sandbox); der Bericht liegt 10 min im Zwischenspeicher.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Auf dem Pi.** Die Anzeige rechnet beim nächsten Abruf neu (höchstens 10 min Zwischenspeicher). Nach den Prozentzahlen auf dem
Foto werden die meisten bisherigen „tot“ voraussichtlich mit 10 bis 50 Fällen bewertet, mit breiten Intervallen. Das ist geschätzt,
nicht gemessen. Kapitulation (2 %) und Funding werden wohl „kein Urteil“ zeigen.

**Was man wissen muss:**
- Bei Ereignis-Treibern heißt „kein Wert“ „kein Ereignis“, nicht „kaputt“. Eine Prüfung, die Anteile zählt, muss das wissen.
- Ein Treiber wird an seinen aktiven Zeiten gemessen, nicht an einem festen Raster, in das er selten fällt.
- Bei wenigen Fällen gehört das Intervall neben r; ein r von 0,6 aus 10 Fällen ist oft Zufall.
- Ein Befundwort wird gelesen und benutzt (30.09. Elite). Deshalb nur Wörter, die die Messung trägt.

## 3ββ. Bewertung: Warum v1 kaum lernt und welcher Weg sinnvoll ist (06.10., nur Dokumente, Version 2026-09-23.55 unverändert, Opus 5.5)

Anlass: Nutzer 06.10. 00:51 (Kachel „Gelernte Gewichte 3 von 33“): „Warum bisher nur 3 von 33 gelernt? Wie viele Events sind
nötig?“ Dann 01:02: „Evaluiere gründlich, was der sinnvollste Lösungsweg wäre.“

**1. Befund im Code (Stand 23.55).**
- v1 (`hl_forecast.calibrate_weights`, 4 h) lernt nur in einem begrenzten Fenster und nur unter Auflagen:
  - Fenster: die jüngsten 2.000 Prognosen à 15 min, das sind rund 21 Tage (auf dem Pi 136 Blöcke). Halbwertszeit 14 Tage.
  - Ein Treiber verlässt seinen Prior erst ab 50 eigenen aktiven 4-h-Blöcken (|Score| > 0,05).
  - L2-Zug zum Prior mit λ = 4/n_eff; Gewichte nur in [0, 2 × Prior].
  - Logit = β · Σ w·x / 18,6 (Summe der Priors); β ist am Wert 1 verankert.
- Die Kachel zählt Abweichungen über 0,02, die Tabelle schreibt „gelernt“ schon ab 10⁻⁹. Die beiden Anzeigen passen nicht
  zusammen.
- Gespeichert wird stündlich. Eine neue „Version“ gibt es erst bei einer Änderung über 0,10. „Version 25.09.“ ist also kein
  Stillstand.
- **Ereignis-Treiber** erreichen im 21-Tage-Fenster nie 50 Blöcke. Pi-Foto: Kapitulation 9, OI-Überhitzung 18, Liquidationsdruck
  18, Crowding-Extrem 12, Funding 5, Vol-Spike-Reversion 1.
- Pool-Treiber und Coinbase-Prämie haben den Prior 0 und können nicht lernen.
- Nenner Prior-Summe, β und Klemmung auf 2 × Prior hatte schon der K2-Neubau (23.09., `hl_kalib`) als Ursachen benannt. Deshalb
  gibt es v2.

**2. Messung: Simulation mit genau der v1-Rechnung** (Sandbox, Skripte nicht im Paket).
- Der Optimierungsteil ist nach numpy übertragen und gegen die Python-Schleife geprüft: größte Abweichung 6 · 10⁻¹⁷, β gleich.
- Markt: Zufallsweg auf 15 min mit Schwankungsclustern, 60 Tage Lernen, danach 15 Tage ungesehen. 33 Treiber mit den echten Priors
  und Aktivitätsmustern wie auf dem Pi (Dauer-, Teilzeit- und Ereignis-Treiber, Funding fast 0). 30 Läufe je Fall.
- Varianten:
  - A: wie heute;
  - B: ein Fenster je Stunde über 60 Tage;
  - C: wie B, Halbwertszeit 30 Tage;
  - D: wie A, Schwelle 15 Blöcke;
  - E: wie B, Schwelle 15 Blöcke.
- Gewinn = Log-Verlust je 4-h-Block in den ungesehenen Tagen, in Tausendstel nats, negativ = besser.

  | | A | B | C | D | E |
  |---|---|---|---|---|---|
  | kein Signal: Rauschtreiber über 0,02 je Lauf | 0,7 | 4,0 | 2,8 | 0,7 | 4,1 |
  | kein Signal: größte Rauschabweichung | 0,020 | 0,038 | 0,030 | 0,020 | 0,038 |
  | Dauertreiber 60 % (RSI): Gewicht über Prior | +0,029 | +0,084 | +0,083 | +0,029 | +0,084 |
  | Dauertreiber 60 %: Gewinn gegen die Priors | −0,05 ± 0,01 | −0,16 ± 0,03 | −0,14 ± 0,02 | −0,05 ± 0,01 | −0,16 ± 0,03 |
  | Dauertreiber 55 %: Gewicht über Prior | +0,015 | +0,041 | +0,040 | +0,015 | +0,041 |
  | Ereignis-Treiber 60 % (OI-artig, 10 % aktiv): Gewicht über Prior | 0,000 | +0,001 | +0,001 | +0,002 | +0,008 |

- **Ein frei gewichtetes Modell** (1-D-Logit) auf demselben 60-%-Treiber gewinnt −21,2 ± 4,5 gegen 50 %, v1 in der besten
  Variante −1,2 ± 0,5. v1 nutzt also rund 6 % eines starken Vorsprungs. Das liegt an der Struktur, nicht an Schwelle oder Fenster.
- **Mehr Daten, mehr Schein:** Unter reinem Rauschen weichen in B viermal so viele Treiber über 0,02 ab wie in A. „Gelernt“ ist
  kein Beleg.
- **Teststärke** (80 %, α 5 %, zweiseitig): kleinster erkennbarer Vorsprung bei 50 Blöcken 19,8 pp, bei 136 Blöcken 12,0 pp, bei
  360 Blöcken 7,4 pp, bei 1.000 Blöcken 4,4 pp.
  - Für 15 pp braucht ein Treiber rund 87 Ereignisse, für 10 pp 196.
  - Pi-Raten je 30 Tage: Kapitulation ~12, OI und Liquidationsdruck je ~24, Crowding-Extrem ~16. Das sind 4–7 Monate (15 pp) bzw.
    8–16 Monate (10 pp).
- **Ereignis-Treiber als schlafender Experte in der Fusion** (`hl_fusion.Mischung` unverändert benutzt).
  - Aufbau: wach nur im Ereignis; Trefferquote der bisherigen Ereignisse mit 20 Pseudo-Fällen zu 50 % geschrumpft; 120 Tage, 400
    Läufe.
  - Mischung minus Basisrate je Block über alle Blöcke: −0,09 ± 0,04 ohne Signal (kein Schaden), −0,26 ± 0,05 bei 55 %, −0,98 ±
    0,09 bei 60 %, −2,28 ± 0,13 bei 65 %.
  - Garantie der Mischung: höchstens ln 2 über ALLE Runden schlechter als der beste Experte.

**3. Bewertung der Wege.**
- **Schwellen senken (D, E): verworfen.** Kein Gewinn, auch nicht bei eingebautem 60-%-Ereignisvorsprung. Unter Rauschen bewegen sich
  mehr Gewichte scheinbar.
- **Fenster je Stunde und 60 Tage (B, C): verworfen für v1.** Das Signal-Gewicht verdreifacht sich, der Prognosegewinn bleibt
  winzig (−0,16 statt −0,05). Unter Rauschen gibt es viermal so viele scheinbar gelernte Treiber.
- **v1 umbauen (Nenner, Klemmung, β): verworfen.** Das wäre v2. v2 gibt es schon, mit Kreuzvalidierung und Positivkontrolle
  (Kante 0,65 → p in [0,60; 0,70]).
- **Sinnvoll:**
  - jetzt nur die Anzeige ehrlich machen;
  - am 25.10. die geplante Modellwahl (U108, U7b);
  - danach Lernen dort, wo es frei ist und eine Garantie hat: Ereignis-Experten und „v3 mit langem Gedächtnis“ in der Fusion.

**4. Empfohlener Weg (U134, Entscheidung beim Nutzer).**
1. **Jetzt, nur Anzeige, keine Zahl der Prognose ändert sich:**
   - „gelernt“ in Tabelle und Kachel nach derselben Regel (Abweichung über 0,02);
   - je Treiber der Lernstatus: „Prior: n_eff 9 von 50“, „Ereignis-Treiber: im Lernfenster nicht erreichbar“ oder „angepasst, ohne
     Beleg“ bzw. „mit Beleg (Lift-z ≥ 2)“;
   - Hinweis in der Kachel: v1 bildet einzelne Vorsprünge kaum ab, frei lernen v2 und die Fusion.
   - **Entscheidung des Nutzers 06.10. 01:21:** nicht vorab bauen, sondern zusammen mit Schritt 3 („es ist ja nur die Anzeige, lass
     es uns anpassen, wenn die richtigen Änderungen anstehen“).
2. **25.10. wie geplant (U108, U7b):** Fusion bzw. v2 nach den vorab festgelegten Kriterien. v1 bleibt einer von mehreren Experten.
3. **Nach dem 25.10. in der Fusion** (die Zusage bis 25.10. bleibt unberührt):
   - a) Ereignis-Experten wie oben, je Treiber oder je Familie „Stärke“; nur Richtung, wenn der Treiber ein Vorzeichen hat;
   - b) „v3 mit langem Gedächtnis“ (steht schon in `KONZEPT_Fusion.md` 5: 90 Tage ohne Halbwertszeit, n_eff 540 statt 237).
   - Für beides vorab festlegen: Nulltest (Rauschen: Mischung nicht schlechter als die Basisrate um mehr als die Garantie),
     Positivkontrolle (eingebauter 60-%-Vorsprung wird gefunden), Bewertung nach 60 Tagen live.
4. **v1-Lernen bleibt unverändert.** Kein Umbau eines Modells, das am 25.10. zur Wahl steht.
5. **Erwartung:** Auf echten Daten fand bisher kein Verfahren einen 4-h-Richtungsvorsprung (v2 und v3: Kalibrierfaktor c 0, also
   Basisrate; Fusion gegen Basisrate −0,0020 ± 0,0112). Die Schritte nutzen einen Vorsprung, sobald es ihn gibt. Sie erzeugen keinen.

**Was man wissen muss:**
- „Gelernt“ misst Bewegung, nicht Beleg. Mit mehr Daten bewegen sich auch Rauschgewichte mehr.
- Ein Modell, das Signale durch eine feste Summe teilt und Gewichte klemmt, kann einen starken Einzeltreiber nicht ausdrücken.
  Mehr Daten ändern daran nichts.
- Seltene Ereignisse lernt man nicht mit einer Mindestzahl im kurzen Fenster. Man gibt ihnen eine Stimme nur dann, wenn sie wach
  sind (schlafende Experten), und lässt die Mischung über ihren Wert entscheiden.

## 3γγ. Auswertung der Berichte vom 06.10.: erste Pi-Läufe Makro × Kurs und Vorbedingungen (06.10., nur Dokumente, Version 2026-09-23.55 unverändert, Opus 5.5)

Anlass: Nutzer 06.10. 21:11 lädt die Sammeldatei der geplanten Berichte hoch (letzte 24 h, 10 Berichte, Pi auf 23.55 · c442f4d455).
Neu darin: Makro-Stand und Makro-Selbsttest 20:15, Makro × Kurs 20:30 (U130 Teil A, erster Lauf mit allen Quellen), Konstellation
und Vorbedingungen 20:45 (U131, erster geplanter Bericht), Aktive Profis 19:00.

**1. Betrieb.** Alle 10 Berichte Exit 0.
- Makro-Selbsttest 55 von 55 (9,1 s). Konstellations-Nulltest samt Probe U131 bestanden; er ist deterministisch (feste Szenarien,
  fester Zeitpunkt) und bestätigt nur, dass sich nichts verändert hat.
- Makro-Stand: 51 von 51 Reihen frisch, FRED über die API 12 von 12, OI-Archiv 2.227 von 2.227 Tagen, BGeometrics 8 von 14 am
  Tag. Archiv `mk_stand` seit 05.10. (2 Tage).

**2. Makro × Kurs (U130 Teil A), BTC-Tagesschluss bis 05.10.**
- 0 von 45 Tests belegt; Benjamini-Hochberg allein 0; unkorrigiert p < 0,10: 3 (Zufall allein ≈ 4,5). Wie die Vorschau in der
  Sandbox (0 von 15; Puell 30 T ρ² 4,2 %, p 0,32).
- Größte erklärte Streuung: Puell 30 T, ρ +0,20 [90 %: −0,09; +0,49], ρ² 4,1 %, p 0,33. Kleinste p: Nettoliquidität 1 T 0,020,
  Puell 1 T 0,026, Nettoliquidität 7 T 0,047. Benjamini-Hochberg verlangt beim kleinsten p höchstens 0,10/45 = 0,0022.
- Gleichsinnig in beiden Hälften mit |ρ| ≥ 0,05, aber weit weg von BH: u. a. Puell 30 T (+0,24/+0,08), Nettoliquidität 30 T
  (+0,07/+0,10), Power Law 30 T (−0,08/−0,23), OI ÷ Marktkap. 30 T (−0,10/−0,07). Nach Abschnitt 10 nur Hypothesen für eine
  neue, eigene Runde.
- Teststärke: Das 90-%-Band der Phasen-Null ist bei h = 1 rund ±0,03 bis ±0,09 breit, bei h = 30 für zähe Merkmale ±0,16 bis
  ±0,36 (16 Jahre sind wenige unabhängige Zyklen). Bei 30 Tagen wären nur sehr starke Zusammenhänge belegbar; „nicht belegt“
  heißt dort auch „kaum messbar“.
- 25.10.: Die Historie wächst bis dahin um 19 Tage (lange Reihen unter 0,5 %, ETF-Flüsse rund 2 %). Dasselbe Urteil ist zu
  erwarten; Neues bringt Teil B.
- Die Spalte „Drittel“ (z. B. Puell 30 T +13,9 %) ist beschreibend. Überschlag: 30-Tage-Renditen streuen um 25–35 %, rund 60
  unabhängige Monate je Drittel → ±9 bis ±12 Punkte (95 %), ohne die Zähigkeit des Merkmals. Kein Beleg.
- **Nachrechnung gegen `mk_stand`: DVOL 2 von 2 und ETF-Fluss 2 von 2 abweichend, die übrigen 10 Merkmale (20 Werte) gleich.**
  Ursache, kein Rechenfehler:
  - Der Makro-Takt schreibt die Zonenkarte beim ersten Rechnen jedes UTC-Tags fest (`archivieren`, `INSERT OR IGNORE`).
  - DVOL trägt dann eine noch offene Tageskerze (Abruf alle 12 h).
  - Der 30-Tage-ETF-Fluss ist eine Kalendersumme bis heute (`summe_fenster`, fehlende Tage = 0). Die Flüsse eines Handelstags
    erscheinen erst nach US-Schluss (Abruf alle 12 h).
  - Beispiel 05.10.: DVOL 35,97 festgeschrieben, Tagesschluss 36,10; ETF 2.170,3 → 2.080,5 Mio USD (die Differenz −89,8 Mio ist
    vermutlich der Fluss vom Montag 05.10.).
  - Genau die beiden Merkmale, deren Wert am offenen Tag entsteht, weichen ab. Nicht betroffen: Fear & Greed (ein Wert je Tag),
    Funding (nur abgeschlossene Tage), OI (00:00-Stand), die Coin-Metrics-Merkmale (erscheinen 1–2 Tage später, dann endgültig).
  - Folge für das Urteil: keine. DVOL und ETF haben keine erste Hälfte und sind nach der Regel nie belegt. Der Bericht schreibt
    trotzdem „ABWEICHEND“ → U135 (2).

**3. Signale (U126) im Makro-Stand.**
- Belegt 4 von 336 Tests: Power Law 4 J und 8 J Kauf 90 T (+53 % bzw. +51 %, p 0,012/0,018, 8 bzw. 6 Episoden); XMR 200-W-MA
  8 J und alles Verkauf 90 T (−21 %, p 0,012/0,013, 4 Episoden). Nach der Kalibrierung (9.4: 3–5 % Fehlurteile je Test) liefert
  Zufall allein rund 11–17. Als Ganzes trägt die Bilanz keinen Beleg, wie 9.5 auf der Test-Kopie (3 von 322).
- Live „Verkauf“: Kurzfrist-Kostenbasis 1 J (seit 19.08.), Puell 1 J/2 J (seit 04./05.10.), ZEC Realized Price 2/4/8 J/alles und
  200-W-MA 2/4 J/alles, XMR 200-W-MA alle Zeiträume. Belegt davon nur XMR 8 J/alles (4 Episoden).
- Puell: Halbwertszeit der Abweichung 3–6 Tage (1 J/2 J), 0 von 6 Tests belegt. In U130 geht ein hohes Puell-Perzentil eher mit
  HÖHEREN Folgerenditen einher (ρ +0,08/+0,14/+0,20, nicht belegt). Das passt zu 9.5: Nach Verkaufssignalen lag die Rendite im
  Median über den Zufallstagen (Momentum).
- ZEC: Das 365-T-Band traf im Rückblick 0 % (4 J) bzw. 51 % (2 J) statt 80 %. ZEC liegt bei Perzentil 96–98 seiner Historie;
  die Fehler früherer Ursprünge beschreiben das nicht. Die ZEC-Bänder sind nicht verwendbar.
- Live gegen Nachrechnung der Signale: 64 von 64 gleich (Coin Metrics und BGeometrics sind am Datentag schon endgültig, anders
  als DVOL und ETF oben).

**4. Vorbedingungen (U131), erster geplanter Bericht (Rückschau 11.09.–05.10., 149 Blöcke Basis).**

| Coin | Rückgänge (bisher) | Kursdaten erfasst | Anstiege (bisher) | Kursdaten erfasst |
|---|---|---|---|---|
| BTC | 3 (2) | 4 von 5 | 6 (6) | 6 von 6 |
| ETH | 8 (4) | 8 von 9 | 9 (7) | 10 von 12 |
| HYPE | 15 (7) | 16 von 16 | 16 (7) | 17 von 20 |
| PAXG | 1 (1) | 1 von 1 | 0 (0) | 0 von 1 |
| XMR | 18 (5) | 20 von 21 | 17 (6) | 19 von 22 |
| ZEC | 32 (6) | 38 von 43 | 34 (4) | 42 von 49 |
| zusammen | 77 (25) | 87 von 95 (92 %) | 82 (30) | 94 von 110 (85 %) |

- Von 24 nicht erfassten Kursdaten-Bewegungen liegen 10 im benachbarten, schon gezählten Ereignis. Bei 14 sah kein
  Prognosepunkt binnen 24 h 3 %; 11 davon zwischen 2,5 und 3,0 % (Schwellenrand des 15-min-Takts, Abschnitt W8). Keine
  Ablage-Lücke („keine Prognose gespeichert“ kommt nicht vor).
- Gemeinsame Marktbewegungen zählen in mehreren Coins (14.09. 16:16 in BTC, ETH und HYPE; Tief 28.09. 16:53 in BTC, HYPE und
  XMR). Über Coins gepoolt sind die Fälle nicht unabhängig.
- BTC: 3 Rückgänge und 6 Anstiege in 24 Tagen. Das Vorbedingungen-Profil erscheint ab 3 Ereignissen (`vorbedingungen`); bei 3
  Fällen verschiebt ein Fall den Anteil um 33 Punkte, ein Lift sagt dann nichts. Für 15 Punkte braucht es, wie in U134 gerechnet,
  rund 90 Ereignisse.
- **Eigener Fehler (23.53):** Die Begründung „vom Prognosekurs aus höchstens …“ misst nur die Prognosepunkte der 24 h VOR dem
  Extrem der Kursdaten-Bewegung (`_abgleich`: `k1 − 24 h ≤ ts < k1`). Bei langen Bewegungen sagt sie nicht, wie nah die
  Prognosepunkte zu Beginn an der Schwelle lagen. BTC 11.09. 15:59 → Tief 14.09. 02:29 (58 h, −4,4 %) zeigt „höchstens −1,3 %“;
  das ist nur der Weg ab 13.09. 02:29. Richtig: je Prognosepunkt ab Beginn der Bewegung die eigene 24-h-Bewegung (`ext_*` gegen
  `p0`), davon die größte. Zählung, Ereignisliste und Profile sind nicht betroffen, nur die Begründungszeile → U135 (1).
- Anzeige: „… und N frühere“ steht unter den 15 jüngsten Ereignissen (Liste aufsteigend), gehört darüber → U135 (3).

**5. Treiberfamilien (U133) auf dem Pi** (manueller Lauf 17:14): wie erwartet. Ereignis-Treiber „kein Urteil“ mit Fallzahl (ETH
Kapitulation 7 von 8 nötig, HYPE Crowding-Extrem 5, Vol-Spike-Reversion 5), junge Treiber mit Alter (XMR Pool-Flow 4 h seit 10,9
Tagen), das ruhige Funding „bewegt sich kaum“, MA 200 T und MA 50 W „derselbe Wert“. Auffällig sind nur nachlaufende Treiber
(u. a. 60-min-Trend, RSI 14, Liquidationsdruck, Taker-Flow).

**6. Aktive Profis (19:00).** Darwin-Liste 1 Konto (x.com/SilkBtc, streng seit 30.09., 11 von 16 richtig gegen Zufall 32 %, Glück
0,2 %), keine Zu- oder Abgänge seit 30.09. Nächster Kandidat 0x926a…af36 (Glück 1,4 %, Aufnahme ≤ 1 %). Die Labor-Vorlagen
„Darwin-Liste live folgen“ und „Gegen die Darwin-Liste“ hängen damit an einem einzigen Konto. Die Gründe gegen die Aufnahme gehen
auf: 421 + 110 + 32 + 92 + 68 + 1 = 724 = 808 − 84 gesperrt.

**7. Vorgemerkt (U135), keine Code-Änderung:**
1. U131-Abgleich: Begründung über alle Prognosepunkte ab Beginn der Bewegung, je mit ihrer eigenen 24-h-Bewegung; Werte, die auf
   3,0 runden, mit zwei Nachkommastellen.
2. U130-Nachrechnung: DVOL und ETF als „am offenen Tag festgeschrieben“ statt „ABWEICHEND“. Das Urteil bleibt unberührt.
3. Ereignisliste: „… und N frühere“ über die Liste.
4. Makro-Stand: Summenzeile der Signal-Bilanz „belegt N von M Tests (Zufall allein …)“.
- Reine Anzeige. Nach der Linie des Nutzers (06.10. 01:21, U134) kommt sie mit der nächsten Code-Änderung; auf Wunsch sofort.

**Was man wissen muss:**
- „ABWEICHEND“ in der Makro-Nachrechnung heißt bei DVOL und ETF „am offenen Tag festgeschrieben“, nicht „falsch gerechnet“.
- Ein Makro-„LIVE VERKAUF“ ist eine Lage (Perzentil ≥ 90 im Zeitraum), kein belegtes Timing. 4 belegte von 336 Tests sind weniger,
  als der Zufall liefert.
- Eine Begründung muss dieselbe Spanne messen wie die Regel, die sie erklärt. Sonst klingt ein Schwellenrand wie ein großer
  Widerspruch.

## 3δδ. U135 gebaut (Berichtskorrekturen); Darwin-Aufnahme bei Glück 3 % bewertet (06.10., Version 2026-09-23.56, Opus 5.5)

Anlass: Nutzer 06.10. 22:55: „Ja, baue gleich. Vielleicht sollte man das Darwin-Kriterium lockern auf Glück < 3 %?“

**1. U135 gebaut — reine Anzeige.** Zählung, Ereignisse, Profile, die Urteile von U130 und die Signale bleiben unverändert.
- **(1) Begründung im Abgleich** (`hl_konstellation._abgleich`). Sie misst jetzt dieselbe Spanne wie die Regel: alle
  Prognosepunkte vom 15-min-Abschnitt des Beginns bis zum Extrem, je mit ihrer eigenen 24-h-Bewegung.
  - Text: „vom Prognosekurs aus binnen 24 h höchstens …“, dazu der Docht: „das 15-min-Hoch lag … % über dem höchsten
    Prognosekurs“ (bei Anstiegen das Tief unter dem tiefsten).
  - Werte, die auf 3,0 runden, aber darunter liegen, stehen mit zwei Stellen (abgeschnitten, `_pc_rand`).
  - Ein Kandidat in der Spanne heißt „im benachbarten Ereignis enthalten“. Ohne Prognose in der Spanne: „keine Prognose zwischen
    Beginn und Tief gespeichert“. Zwei Kopfzeilen erklären beide Angaben.
  - Vorher/nachher auf der Probe (Bewegung über 58 h wie BTC 11.09., alte Funktion aus dem Paket 23.55 nachgerechnet): 23.55
    „höchstens -0,7 %“, 23.56 „binnen 24 h höchstens -2,7 %; das 15-min-Hoch lag 0,6 % über dem höchsten Prognosekurs“.
  - Für BTC 11.09. zeigt der nächste Bericht damit, wie knapp die Prognosepunkte zu Beginn lagen und wie groß der Docht war.
    Ein Docht von mehreren Prozent bei BTC spräche für einen Ausreißer in den Bars.
- **(2) Nachrechnung von U130** (`hl_makro_korr.nachrechnung_stand`, `VORLAEUFIG_TAGE = {dvol: 2, etf: 3}`).
  - Lag der Datentag beim Festschreiben weniger Tage zurück, gilt der Wert als „am offenen Tag festgeschrieben (Tageswert noch
    vorläufig, nicht geprüft)“. Das ist kein Widerspruch.
  - Ein abgeschlossener Tag mit geändertem Wert bleibt „abweichend“. Alle übrigen Kennzahlen werden auch am selben Tag geprüft.
  - Für das Bündel vom 06.10. stünde da: „20 archivierte Werte geprüft, alle gleich · am offenen Tag festgeschrieben …: dvol 2,
    etf30 2“.
- **(3) Listen.** „(N frühere nicht gezeigt; es folgen die 15 jüngsten)“ steht jetzt über der Ereignisliste. Ebenso bei den nicht
  erfassten Bewegungen (10) und bei den Fällen der Ereignis-Profile U43 (12).
- **(4) Makro-Stand: Summenzeile unter den Signalen** (`signal_summe`, `signal_summe_text`;
  `hl_makro_signal.FEHLURTEILE = (0,032; 0,05)` aus 9.4).
  - Text: „Zusammen: belegt N von M Tests -- der Zufall allein liefert nach der Kalibrierung (3–5 % Fehlurteile je Test) etwa …;
    Live jetzt … Signale (… Kauf, … Verkauf), davon mit belegter Bilanz ihrer Seite: …“.
  - Ein belegter Kauf zählt bei einem Verkaufssignal nicht.
  - Test-Kopie (Coin Metrics bis 23.05.): „belegt 3 von 322“, wie 9.5. Auf dem Pi zu erwarten: 4 von 336, Zufall 11–17, live 15
    Verkauf, davon 2 mit Beleg (XMR 200-W-MA 8 J und alles).
- **Proben.**
  - Konstellations-Nulltest mit neuer Zeile „Abgleich mit den Kursdaten, Begründung (U135)“. Geprüft: lange Bewegung (Soll −2,7 %
    und Docht 0,6 %), Anstieg gespiegelt, Schwellenrand −2,96 %, Nachbarereignis, keine Prognose, offenes Fenster, die ganze
    Kette über Datenbank und `lade` mit Rauschen, Hinweise vor den Listen.
  - Makro × Kurs: Prüfung 9 (offener Tag vorläufig, Revision eines abgeschlossenen Tags abweichend, Coin Metrics am selben Tag
    geprüft).
  - Makro-Selbsttest: Prüfung 56 (Summen gegen eigene Zählung, Zufallserwartung aus `FEHLURTEILE`, Live mit belegter eigener
    Seite an einem Konstrukt).
  - Mutationen 19 von 19 rot: u. a. Spanne nur 24 h vor dem Extrem, Weg bis zum Extrem, ohne Docht, Docht gegen das falsche
    Extrem, ohne 15-min-Abschnitt des Beginns, Rundung am Rand, alle Kennzahlen vorläufig, Abstand verkehrt herum, Live-Beleg
    ohne eigene Seite, Zufall mit nominellen 2,5 %, belegt je Zeitraum statt je Test.

**2. Darwin-Aufnahme bei Glück < 3 % statt ≤ 1 %? (U136, Entscheidung beim Nutzer)**
- **Heute käme ein Konto in Frage:** 0x926a…af36 (4 von 13 richtig, Zufall 8 %, Glück 1,4 %, gedämpfter Vorsprung rund +17
  Punkte). Ob das Einstiegs-Veto greift, zeigt der Bericht nicht, er nennt nur den ersten Grund. Die Liste hätte 2 statt 1
  Mitglied.
- **Zufallserwartung im heutigen Pool** (69 geprüfte Konten aus check_profis 06.10. 19:00; exakt mit n und Zufallsquote je
  Konto, Binomial, `darwin_null.py`):

  | Glück ≤ | rein zufällig erwartet | beobachtet | P(mindestens so viele rein zufällig) |
  |---|---|---|---|
  | 1 % | 0,32 | 1 | 27 % |
  | 2 % | 0,78 | 2 | 18 % |
  | 3 % | 1,16 | 2 | 32 % |
  | 5 % | 1,72 | 5 | 3 % |

  - Zwischen 1 und 3 % erwartet der Zufall 0,84 Konten, beobachtet ist 1. In diesem Band gibt es keinen Hinweis auf Können.
  - Die Vorauswahl nach Gewinn 7 T/30 T nutzt dieselben Trades; das macht Zufallstreffer eher häufiger als hier gerechnet.
- **Simulation der Regeln v3** (`sim_darwin_v3.py`, nach `sim_regeln.py` vom 30.09.; 200 Konten ohne Vorsprung, Entscheidungen
  Median 1,1 je Tag, Zufallsquote 8–58 % wie im Pi-Bericht, 12 Läufe à 120 Tage):

  | Szenario | Glück ≤ | Könner auf der Liste | Zufallskonten auf der Liste | Anteil Zufall | Zufallsaufnahmen je Woche |
  |---|---|---|---|---|---|
  | ohne Könner | 1 % | — | 1,9 ± 0,2 | 100 % | 1,0 |
  | ohne Könner | 3 % | — | 4,9 ± 0,2 | 100 % | 2,5 |
  | 2 Könner (+20 Punkte) | 1 % | 56 ± 8 % | 2,0 ± 0,2 | 64 % | 1,0 |
  | 2 Könner | 3 % | 79 ± 3 % | 5,5 ± 0,3 | 78 % | 2,7 |
  | 10 Könner | 1 % | 62 ± 4 % | 2,1 ± 0,1 | 25 % | 1,0 |
  | 10 Könner | 3 % | 64 ± 4 % | 5,5 ± 0,3 | 46 % | 2,7 |

  - Bei 2 % liegen die Zufallskonten dazwischen (3,5–4,1).
  - Der Pi mit 1 Mitglied passt zum Szenario ohne Könner.
  - Variante „Bewährung“ (direkt bei ≤ 1 %; bei ≤ 3 % erst Kandidat, Aufnahme nach mindestens 4 späteren Entscheidungen mit
    Glück ≤ 20 % binnen 21 Tagen): ohne Könner 3,1 Zufallskonten; mit 2 Könnern 68 ± 5 % Abdeckung bei 3,0 Zufallskonten. Sie
    liegt zwischen 1 % und 3 %.
- **Bewertung.** 3 % verdreifacht etwa die Zufallsmitglieder und die Zufallsaufnahmen. Könner gewinnen nur, wenn sie selten sind
  (2 Könner: 56 → 79 %), bei vielen nicht (62 → 64 %). Die Liste würde größer, aber nicht besser. Der Engpass ist nicht die
  Schwelle, sondern dass der Pool kaum belegbares Timing enthält.
- **Empfehlung:** 1 % lassen.
  - Für mehr Daten die Beinahe-Aufnahmen (Glück 1–5 %) im Schatten vorwärts verfolgen: ihre späteren Ein- und Ausstiege gegen
    den Zufall, ohne Wirkung auf Liste, Profi-Flow und die Labor-Bilanz der Darwin-Liste. Nach 4–6 Wochen entscheiden.
  - Eine geänderte Aufnahme wäre Regeln v4 mit neuer Labor-Kennung (`liste=4`; heute gilt `liste=3` seit 23.38 -- in 23.56 stand
    hier versehentlich `liste=3`, berichtigt in 3εε).
- **Was die Darwin-Liste speist:** die Labor-Vorlagen „Darwin-Liste live folgen“ und „Gegen die Darwin-Liste“ sowie die Familie
  „Profi-Flow“ (Parallelbetrieb). Nicht v1, v2, Fusion oder Kaskaden — die Zusage bis 25.10. wäre nicht berührt.
- Skripte im Arbeitsbereich, nicht im Paket.

**Was man wissen muss:**
- Eine Glücksschwelle über viele Konten ist ein Mehrfachtest. Bei 69 geprüften Konten kommen bei 3 % rund 1,2 Konten rein
  zufällig durch, bei 1 % rund 0,3.
- Eine kleine Liste ist kein Fehler der Regel, solange im Pool kein Timing belegbar ist. Lockern füllt sie mit Glück.

## 3εε. Schatten der Darwin-Liste gebaut (U136; Nutzer 07.10. 13:37: „ja“; 07.10., Version 2026-09-23.57, Opus 5.5)

Anlass: Auf die Frage „Soll ich die Konten, die knapp an der Darwin-Aufnahme scheitern, im Hintergrund weiter beobachten?“ antwortet
der Nutzer „Ja“. Die Aufnahme bleibt bei Glück ≤ 1 %. Vorab festgelegt in `KONZEPT_Aktive_Profis.md` Abschnitt 11, bevor Daten da
sind.

**1. Was gebaut ist** (`hl_profis.py`, Abschnitt U136; Stand im Prognosespeicher `learned` „*“/„darwin_schatten“).
- **Gruppen** (`schatten_gruppe`):
  - „≤ 1 %“ = die Aufnahme;
  - „1–3 %“ und „3–5 %“ = alle Bedingungen der Aufnahme außer der Glücksschwelle;
  - Kontrolle = ebenso geprüft, aber Glück über 5 %;
  - Mitglieder der Liste nur in „≤ 1 %“.
- **Eintragen** (`schatten_tag`, einmal je UTC-Tag): beim ersten Mal mit Glück, Ein-/Ausstiegen und Zufallsquote. Ein Band bleibt;
  aus der Kontrolle führt genau ein Weg in ein Band.
- **Vorwärts** (`schatten_entscheidungen`, täglich): Ein- und Ausstiege nach dem Eintritt mit vorbeigegangenem 12-h-Fenster.
  - Richtig, Zufallsquote und „je Richtung und 4-h-Block einmal“ wie `bewerte_konto` (gemeinsamer Teil `_entscheidung`;
    `bewerte_konto` selbst unverändert).
  - Das Fenster (bis, jetzt − 12 h] rückt vor; nachgeholt wird höchstens 14 Tage.
- **Urteil** (`schatten_urteil`):
  - Δ = Mehr-Treffer im Band 1–3 % minus Mehr-Treffer der Kontrolle, Streuung aus Σ q(1−q), einseitiger z-Test.
  - „Timing belegt“ nur mit Δ ≥ 5 Punkten, p < 0,05, ≥ 60 Entscheidungen aus ≥ 3 Konten (Kontrolle ≥ 60) und Δ > 0 ohne jedes
    einzelne Konto.
  - Termin 18.11.2026, sonst 16.12.2026; davor nur Zwischenstand.
- **Anzeige:** eigener Abschnitt in `check_profis` (Debug „★ Aktive Profis“, Wochenprüfung mittwochs 19:00); Berichte
  `u136-darwin-schatten` am 18.11. 19:15 und `u136-darwin-schatten-2` am 16.12. 19:15.
- **Dashboard** (`hl_viz._schatten`): nach der Darwin-Entscheidung, einmal je Tag; ein Fehler hält die Bewertung nicht an. Liste,
  Labor und Familien lesen den Schatten nicht.

**2. Warum eine Kontrollgruppe.** Konten handeln eher in bewegten Phasen; dann treffen auch Ein- und Ausstiege ohne Können öfter
als die Zufallsquote aus beliebigen Zeitpunkten (offene Audit-Frage, KONZEPT 10).
- Simulation mit +4 Punkten Bias für alle: Der Vergleich nur mit der Zufallsquote sagt in 25–33 % der Läufe „Timing“, der Vergleich
  mit der Kontrolle in 3 %.
- Pool vom 06.10.: 68 geprüfte Konten trafen 28,1 % gegen 24,6 % Zufall (342 von 1.217, Zufall 299,6 ± 14,0). Ob das Können,
  Auswahl nach Gewinn oder der Bias ist, trennt erst der Vergleich vorwärts.

**3. Proben.**
- `hl_profis.py --nulltest`, neuer Teil „Schatten der Darwin-Liste (U136)“ (rund 11 s; ganzer Nulltest rund 12 s statt 0,6 s):
  - Gruppen gegen die Aufnahme (12 Fälle);
  - Eintragen (Band fest, Kontrolle -> Band einmal, einmal je Tag, ohne Gewinn kein Eintrag);
  - vorwärts auf Kursdaten: Treffer und mittlere Zufallsquote gleich `bewerte_konto` mit demselben Placebo; nur nach dem Eintritt;
    zwei Schritte = einer, ein 4-h-Block über die Grenze zählt einmal; der Wechsel Kontrolle -> Band teilt die Entscheidungen;
  - Statistik gegen eine Rechnung von Hand (Δ +11,6 Punkte, p 0,031), ohne ein Konto, Termine, Bericht;
  - Simulation (150 Konten, 42 Tage, echte Funktionen): ohne Können mit Bias belegt 3 % (Soll ≤ 8), nur gegen die Zufallsquote
    33 % (Soll ≥ 15), halber Pool mit +15 Punkten 100 % (Soll ≥ 80).
- Mutationen 19 von 19 rot, u. a. Bandgrenze strikt, Band ohne Vorsprung, Gründe ignoriert, Band nicht fest, auch vor dem
  Eintritt, ohne 4-h-Block, Fenster ohne „bis“, Zufall der Gegenrichtung, ohne Kontrolle, ohne Probe ohne ein Konto, Urteil vor
  dem Termin, ohne Mindestzahl Konten.
- Ende-zu-Ende in der Sandbox (`e2e_schatten.py`, nicht im Paket): Recorder-Schema, 23 Konten mit echten `bewerten`-Urteilen,
  Dashboard-Schritt an zwei Tagen mit verschobener Uhr, `check_profis`.
  - Tag 1: gute Konten in „≤ 1 %“, ein Zufallskonto in „3–5 %“, der Rest Kontrolle.
  - Ein zweiter Lauf am selben Tag ändert nichts.
  - Tag 2: vorwärts gezählt je Gruppe gleich einer Rechnung von Hand.
  - Der Bericht zeigt den Abschnitt mit „Zwischenstand“.
- Teststärke (Prototyp, 6 Wochen): wahrer Vorsprung des Bands +8,7 / +6,0 / +5,3 / +2,9 Punkte -> belegt in 93 / 63 / 53 / 30 %.

**4. Eigener Fehler (23.56, berichtigt):** In 3δδ und in der Zeile U136 stand, eine geänderte Aufnahme bekäme die Labor-Kennung
`liste=3`. Die gilt aber schon seit 23.38 (Regeln v3, `hl_labor.py`). Richtig ist `liste=4`; der Bericht nennt sie so.

**5. Auf dem Pi.**
- Der Schatten trägt bei der ersten (stündlichen) Bewertung nach dem Update ein, danach einmal je UTC-Tag (erste Bewertung nach
  00 UTC). Vorwärts zählt alles nach dem Eintrag, sobald sein 12-h-Fenster vorbei ist und der nächste Tagesschritt läuft; die
  ersten Zahlen stehen nach ein bis zwei Tagen im Bericht (in der Wochenprüfung am 14.10.).
- In der Wochenprüfung (mittwochs 19:00) steht er unter „★ Aktive Profis“.
- Heute wären in den Bändern: 0x926a…af36 (1–3 %) sowie 0x0c4a…1b19, we love u jeff und 0x9836…457e (3–5 %), sofern sie die übrigen
  Bedingungen dann noch erfüllen.

**Was man wissen muss:**
- Ein Vergleich nur mit der Zufallsquote misst auch, WANN gehandelt wird. Erst die Kontrolle aus demselben Pool trennt Können vom
  Zeitpunkt.
- Gruppen werden beim Eintritt festgelegt und gezählt wird nur danach. Wer Konten später nach ihrer Bilanz umsortiert, misst
  seine eigene Auswahl.

## 3ζζ. Wochenbündel 07.10. ausgewertet; Abgleich-Begründung berichtigt (eigener Fehler 23.56, U137) (07.10., Version 2026-09-23.58, Opus 5.5)

Anlass: Der Nutzer lädt auf meine Bitte das Wochenbündel `berichte_2026-10-07_19-44_1d.txt` hoch (Wochenprüfung 19:00 mit 23.57;
dazu die Makro- und Vorbedingungen-Berichte vom 06.10. mit 23.55).

**1. Eigener Fehler in 23.56 (U135 (1)), berichtigt in 23.58 (U137).**
- **Befund:** Vergleich der Vorbedingungen-Berichte 06.10. 20:45 (Code 23.55) und 07.10. 19:13 (Code 23.56), Zeile für Zeile:
  - 10 Bewegungen hießen vorher „im benachbarten Ereignis enthalten“ und jetzt anders. ZEC: Rückgänge 16.09. 22:44, 22.09. 07:44,
    24.09. 16:44, 30.09. 02:44 und Anstiege 11.09. 16:59, 11.09. 17:59, 23.09. 16:14, 23.09. 18:14, 30.09. 15:44 standen als
    „binnen 24 h höchstens −2,1 … −2,9 %“ bzw. „+1,8 … +2,7 %“ mit Docht da.
  - XMR, Anstieg 24.09. 22:29 (Hoch 22:30, eine Minute): „keine Prognose zwischen Beginn und Hoch gespeichert“. Das las sich wie
    eine Lücke der Ablage.
  - Eine Zahl wurde kleiner: XMR 26.09. 22:59 „+2,8 %“ (23.55), jetzt „+2,1 %“.
- **Ursache:** 23.56 ersetzte die Menge „Punkte der 24 h vor dem Extrem, je mit ihrem Weg bis dorthin“ durch die Spanne „vom
  15-min-Abschnitt des Beginns bis zum Extrem, je mit eigener 24-h-Bewegung“, statt beide zu messen. Punkte VOR dem Beginn der
  Kursdaten-Bewegung fielen heraus. Das sind genau die Fälle einer Treppe nach einer Erholung um 3 % (die Kursdaten zählen den
  zweiten Rückgang vom Docht aus neu, die Prognosepunkte vor der Erholung sahen ihn schon) und eines 1-min-Dochts ohne Prognose im
  Abschnitt. Die Probe (d) prüfte nur den Kandidaten in der Spanne; den Fall „Kandidat vor dem Beginn“ gab es in der Probe nicht,
  und den alten Bericht habe ich vor der Lieferung nicht gegen den neuen verglichen.
- **Berichtigt** (`hl_konstellation._abgleich`), beide Mengen nur mit vollständigem 24-h-Fenster (nur solche Punkte gehören zu
  Ereignissen):
  - Spanne (Abschnitt des Beginns bis Extrem) mit eigener 24-h-Bewegung; „vorher“ (die 24 h vor dem Extrem) mit dem Weg bis zu
    DIESEM Extrem.
  - „im benachbarten Ereignis enthalten“, wenn ein Punkt einer der beiden Mengen 3 % erreicht (dieselbe Schwellenform wie
    `_kandidat`). Sein Ereignis überlappt die Bewegung nicht, dessen angezeigtes Extrem liegt also davor.
  - Sonst „binnen 24 h höchstens …“ = das Größte beider Maße; der Docht gegen den extremsten Kurs derselben Punkte.
  - „keine Prognose in den 24 h vor dem Hoch/Tief gespeichert“ nur, wenn beide Mengen leer sind (bei Bewegungen über 24 h:
    „zwischen Beginn und …“).
  - Kopfzeilen des Berichts erklären die drei Begründungen.
  - Zählung, Ereignisse und Profile sind unberührt; es ändert sich nur der Text der Begründung.
- **Proben** (Konstellations-Nulltest, Zeile „Abgleich mit den Kursdaten, Begründung (U135, 23.58)“), neu:
  - (i) 1-min-Docht ohne Prognose im Abschnitt, frühere Punkte sahen ihn → „benachbart“ (23.56: „keine Prognose zwischen Beginn
    und Hoch“);
  - (j) Treppe nach einer Erholung um 3 %, ganze Kette (Ereignisse aus Prognose- und Kursdaten) → nicht erfasst, „benachbart“
    (23.56: „höchstens −2,9 %; Docht 0,5 %“ -- genau das ZEC-Bild);
  - (k) echte Lücke vor einer kurzen Bewegung → „keine Prognose in den 24 h vor dem Hoch gespeichert“;
  - (l) frühere Punkte näher an 3 %, ganze Kette → „+2,8 %; Docht 0,4 %“ (23.56: +2,1 %, 1,1 %; wie XMR 26.09.);
  - (m) Kandidat nur in der Spanne (lange Bewegung) → „benachbart“;
  - (n) Datenende: ohne bewertbare Punkte „unvollständig“, mit bewertbaren Punkten davor, die 3 % sahen, „benachbart“;
  - (a2) lange Bewegung, Abfall schon im Abschnitt des Beginns → dessen Punkt bestimmt Zahl und Docht (−2,8 %, 0,6 %).
  - (a)–(h) aus 23.56 unverändert grün.
- **Mutationen 19 von 19 rot** (`mut137.py`, nicht im Paket): ohne die Punkte davor (Stand 23.56), Punkte davor ohne
  vollständiges Fenster, Zahl nur aus der Spanne, Zahl nur aus den 24 h davor (Stand 23.55), Docht nur über die Spanne, Lücke vor
  dem Nachbarereignis geprüft, keine Unterscheidung kurz/lang, Schwelle 1,5 % statt 3 %, 48 h statt 24 h, ohne Kandidaten der
  Spanne, Rückgang mit der Schwelle des Anstiegs, dazu die acht aus 23.56 mit neuen Ankern.
  - „ohne 15-min-Abschnitt des Beginns“ blieb zuerst grün: Bei Bewegungen unter 24 h decken die Punkte „vorher“ diesen Abschnitt
    mit ab. Erst (a2) mit einer langen Bewegung macht ihn rot.
- **Im nächsten Vorbedingungen-Bericht zu erwarten:** die 10 Zeilen wieder „im benachbarten Ereignis enthalten“; XMR 26.09. etwa
  „+2,8 %“ mit kleinerem Docht. BTC 11.09. bleibt „−2,99 %; Docht 0,8 %“; die übrigen Zeilen bleiben gleich, außer wo ein Punkt
  vor dem Beginn einen extremeren Kurs hatte (dann kleinerer Docht).

**2. Schatten-Tabelle (reine Anzeige, `hl_profis.schatten_text`).** Die Spalten „Konten“ und „mit Entsch.“ lasen sich als eine
(„Konten mit Entsch. 2“, aber 0 Entscheidungen). Jetzt eine Spalte „Konten (mit Entsch.)“, z. B. „48 (0)“. Probe im
Schatten-Teil des Profis-Nulltests (ein Bandkonto ohne Entscheidung → „4 (3)“); Mutationen 3 von 3 rot.

**3. Auswertung des Bündels.**
- **System** (Vollbericht 19:00): 23.57 läuft seit 07.10. 14:43 (Update erfolgreich), Dienste aktiv, 0 Neustarts; Datenbank
  13,64 GB, 215 GB frei; API-Gewicht 94 %, keine 429er; 52–55 °C, keine Drosselung; Backup vor 7,3 h. Pool-Fills: Abholstand
  Median 21,4 h (Takt 12 h; 30.09.: 29 h); die Darwin-Ereignisse kommen aus Positionen und sind davon nicht betroffen.
- **Vorbedingungen** (19:13, Code 23.56): 190 von 215 Kursdaten-Bewegungen erfasst (06.10.: 181 von 205). Von den 25 übrigen
  liegen 10 im Nachbarereignis (siehe 1) und 15 knapp unter 3 % vom Prognosekurs (im Bericht 2,1–2,99 %, mit 23.58 2,2–2,99 %)
  mit Docht bis 1,2 %.
  - BTC 11.09. 15:59 (−4,4 % bis 14.09. 02:29): „binnen 24 h höchstens −2,99 %; das 15-min-Hoch lag 0,8 % über dem höchsten
    Prognosekurs“. Das ist ein Schwellenrand (0,01 Punkte) und ein normaler Docht am Hoch der Rallye vom 11.09., kein Ausreißer
    in den Bars. Die Diagnose aus 3γγ ist damit bestätigt.
- **Ereignis-Profile** (19:13): Rutsche 28 Fälle (Schwelle |z| ≥ 4,45, getestet ab 14 Fällen), Anstiege 34 (4,14, ab 17);
  nichts markiert.
  - Frage des Nutzers: steigt der Pool-Flow 4 h vor Rallys und fällt er vor Rücksetzern? Bisher je 12 Fälle, noch nicht
    getestet. Mittel vor Rutschen +0,03 … +0,13 (0 h +0,21), vor Anstiegen +0,05 … +0,24 (0 h +0,30). Er liegt vor BEIDEN
    Richtungen leicht über normal; ein Fallen vor Rücksetzern ist nicht zu sehen.
  - Testbar wird er, wenn er in der Hälfte der Fälle Werte hat (`n_min`): Rutsche nach etwa 4 weiteren Fällen (um den
    10.–11.10.), Anstiege nach etwa 10 (um den 14.10.).
  - Labor als Spiegel desselben Signals (Schwelle ±0,5, 4 h): „Pool folgen“ 184 Trades (62 Blöcke) Ø −0,104 %, t −0,8; „Gegen
    Pool“ 184 (63) Ø −0,144 %, t −1,5. Richtungsanteil ≈ +0,02 % je Trade vor Kosten, Kosten ≈ 0,12 %.
  - Familie „Pool-Konten“ (4 h): ZEC +15,3 Punkte (z +2,7), HYPE −14,0 (z −2,4), BTC +10,4 (z +1,8), ETH −2,8, XMR −1,1. Kein
    gemeinsames Vorzeichen.
- **Makro-Stand** (19:14): Die Summenzeile steht und stimmt nachgezählt. Belegt 4 von 337 Tests (Zufall allein etwa 11–17);
  live 13 Signale, alle Verkauf, davon 2 mit belegter Bilanz der eigenen Seite (XMR 200-W-MA 8 J und alles; p 0,013 aus 4
  Episoden, beide Zeilen teilen fast alle Daten). Live gegen Nachrechnung 128 von 128 gleich. Neu live: Puell 1 J Verkauf seit
  04.10. (Perzentil 98). Zonenkarte: DVOL 35,9 = Perzentil 3,7 (sehr niedrige implizite Schwankung; Lage, kein Signal). Die
  U130-Nachrechnung mit „vorläufig“ ist nicht im Bündel (Bericht 25.10. oder Debug „★ Makro × Kurs“).
- **Aktive Profis und Schatten** (19:18): 1 Mitglied (x.com/SilkBtc, Glück 0,4 %, Vorsprung +29). Die nächsten Kandidaten:
  0x58b2…11f3 2,1 %, 0x0c0e…8a4d 3,2 %, 0x4c6d…5ee9 3,7 %, 0x541e…071d 4,0 %. Der Schatten hat eingetragen: 2 / 1 / 3 Konten in
  den Bändern, 48 in der Kontrolle, vorwärts noch 0 (erste Zahlen nach dem Tagesschritt am 09.10.). Einzelheiten in
  `KONZEPT_Aktive_Profis.md` 11.9.
- **Fusion** (19:13): über alle Coins 4 h Fusion − Basisrate −0,0037 ± 0,0032 (nur live −0,0025 ± 0,0042), nicht belegt; 24 h
  −0,0279 ± 0,0084 ✓ (131 Blöcke in 26 Zeitblöcken). Gegen v1 bei 24 h +0,0153 ± 0,0100 (v1 allein etwas besser, nicht belegt).
  Bis 25.10. keine Änderung (U108).
- **Kaskaden** (19:14): Y = 0 in 9 von 11 Zellen mit Daten; BTC 1 h Y 0,25 (+0,0143 ± 0,0090) und ETH 1 h Y 1 (+0,0167 ± 0,0116)
  unter 2 SE, Seitenspiegel nirgends belegt. Zuverlässigkeit der ≥ 2-σ-Vorhersagen überall ✓. Richtung der Asymmetrie über alle
  Coins 46 % ± 3 % (z −1,4). Das Placebo wählte XMR 4 h Y 2 und PAXG 1 h Y 0,5: Y-Wahlen entstehen auch mit verschobener Heatmap.
- **Magnet** (U110, 19:14): nichts belegt (36 Tests). Am nächsten HYPE 1 h mittel, Überschuss +11,6 ± 3,9 Punkte (echt −
  Placebo +18,2 ± 8,0), aber nur 35 von 60 wirksamen Fällen und Spiegel unter 2 SE. In der 60-Tage-Variante A berührt ETH
  Cluster seltener als Zufallsniveaus (z −1,9 bis −2,3 über 4–24 h, n_eff 16–28); kleine Stichproben, überlappende Horizonte, im
  Test U110 nicht zu sehen.
- **Anker:** in keinem Coin ein Beleg.
- **Labor** (19:18): seit 27.09. 3.580 Trades, netto −72.792 USD (Gebühren 26.081), 24 h −13.777. Stufen: Kandidat 31, negativ 7,
  sonst nichts. Die Zufall-Kontrolle verliert (−3.821 USD, t −2,5), wie sie soll; „Glück“ der Besten 100 %, nichts schlägt den
  Zufall. „Familie Orderfluss“ −22.735 USD (290 Trades, 17 % Treffer, t −15,3): bekannt aus U96 (XMR-Markteinstiege bis 73 bps
  von der Mitte, Stopp nach einer Minute), Auswertung mit U99.
- **Familien** (19:16): nichts aufgestiegen. ZEC „Funding“ steht noch auf „Bewährung“ aus dem Wochenurteil vom 01.10. (Woche =
  Unix-Woche ab Donnerstag 00 UTC); heute z −1,5, beim Urteil am 08.10. fällt es zurück. |z| ≥ 2 in 5 von 53 Zellen (Zufall
  ≈ 2,4), vier davon in HYPE mit beiden Vorzeichen.
- **Empfehlungen, Konfluenz, Kalibrierung v2:** wie zuvor. Limit gegen Markt über alle Coins beim Kauf +0,06 % (−0,09 … +0,21);
  Konfluenz nach 4 h 54 % gegen Zufall 52 %; v2 sagt in 4 von 6 Coins die Basisrate (c = 0).

**Was man wissen muss:**
- Wer eine Begründung umbaut, prüft die Fälle der alten mit. Erst der Vergleich alter und neuer Bericht Zeile für Zeile zeigt, was
  verloren ging; eine Probe deckt nur die Fälle ab, an die man gedacht hat.
- „Nicht markiert“ heißt bei wenigen Fällen „noch nicht belegbar“. Die Schwelle der Ereignis-Profile liegt wegen des
  Mehrfachtests über alle Treiber und Vorläufe bei |z| ≈ 4–4,5.

## 3ηη. Konzept Regime-Modul: die letzten 4–8 Wochen lesen (U138; Nutzerwunsch 07.10. 21:51; 07.10., nur Dokumente, Version 2026-09-23.58 unverändert, Opus 5.5)

Anlass: Nutzer 07.10. 21:51, sinngemäß: ein weiteres Modul „wie Reverse Market Engineering“. Es soll die jüngsten 4 (oder 8)
Wochen analysieren, also den Zeithorizont, den die Marktteilnehmer gerade nutzen, und daraus ableiten, wie sich der Markt
aktuell verhält und welche nächsten Schritte möglich sind. Beispiele des Nutzers:
- Stufen über 2–3 Tage, danach ein Rücksetzer zu einem höheren Tief, Schritte von typisch x %;
- „zwischen 2 und 5 Uhr nachts geht der Kurs zurück“;
- „samstags nachts fällt der Kurs“.

Begründung: Die tatsächlichen Bewegungen sind größer als unser Vorhersagewert. Auftrag: sorgfältig recherchieren, Literatur
durchgehen, eigene Vorschläge ergänzen, ein durchdachtes Konzept erstellen.

**1. Was entstanden ist (keine Codeänderung).**
- `RECHERCHE_Regime_07-10-2026.md`: Bericht „Kurze Fenster erkennen Volatilität, nicht Richtung“ (sechs Teilrecherchen und eine
  Synthese, rund 160 Quellen, unbestätigte Angaben gekennzeichnet).
- Zufallsweg-Simulation in der Sandbox (`zufall_regime.py`, nicht im Paket; Ergebnisse in `KONZEPT_Regime.md` 2). Echte
  Kursdaten erreicht die Sandbox nicht (Binance, GitHub und PyPI gesperrt); die Prüfung an Daten ist Phase 0 auf dem Pi.
- `KONZEPT_Regime.md` (U138): acht Bausteine R1–R8, zwölf Anzeigen RG1–RG12, Prüfplan P0.1–P0.9 und V1–V4 (vorab, als Entwurf),
  Phasen 0–3, Entscheidungen 1–7 beim Nutzer.

**2. Befunde, die das Konzept tragen.**
- **Größe und Zeitpunkt sind vorhersagbar, die Richtung kaum.**
  - Tages- und Wochenprofil der Schwankung sind robust (Hansen, Kim & Kimbrough 2024). HAR erklärt bei BTC rund ein Drittel der
    Schwankung (R² 0,32–0,37, in der Lernstichprobe).
  - Richtung: Wochenmomentum bei BTC 2011–2018 R² 3–5 % (≈ 55–57 % Vorzeichentreffer), seit 2020 kleiner, verdient fast nur long.
  - Deshalb wirkt unsere Prognose „zu klein“: Bei P(aufwärts) nahe 50 % liegt der Erwartungswert nahe null, die Bewegung selbst
    hat die volle Schwankung. Das Modul gibt Verteilungen aus (Spannweite, Zonen, Zeitfenster, Berührwahrscheinlichkeiten).
- **Stufen sind zum großen Teil Zufallsgeometrie** (Simulation: 2,5 % Tagesschwankung, 5-min-Schritte, 4.000 Tage):
  - θ 4 %: rund 10 Beine je 4 Wochen, Aufwärtsbein Ø 2,07θ (≈ 8 %) in 2,8 Tagen;
  - P(höheres Tief) 0,47–0,50 (Formel 1/2), P(höheres Hoch | höheres Tief) 0,66–0,70 (Formel 2/3; ein Auswahleffekt, weil die
    Bedingung kurze Rücksetzer auswählt);
  - eine Drift von +0,2 %/Tag (≈ +6 % im Monat) hebt die höheren Tiefs nur auf 0,53–0,54;
  - Rücksetzer verteilen sich wie die geschlossene Formel; Fibonacci-Niveaus sind unauffällig;
  - 30-min-Bars verlängern Beine bei θ 4 % um rund 20 %; Nullsimulationen laufen deshalb in derselben Auflösung wie die Daten.
- **Uhrzeit- und Wochentagsmuster der Richtung sind in 4–8 Wochen nicht von Zufall zu trennen.**
  - Nachweisgrenze einer Stunde (zweiseitig, 80 % Teststärke): 24–30 bp in 4 Wochen, 17–21 bp in 8 Wochen, 3,9–4,8 bp in
    3 Jahren. Der größte dokumentierte Effekt liegt bei rund 4–5 bp, und Kalendereffekte wechseln über Stichproben das Vorzeichen.
  - Der Zufall allein liefert in 8 Wochen zu 66 % einen Wochentag mit mindestens 6 von 8 negativen Nächten (fallend oder
    steigend: 91 %) und in 28 Tagen zu 98 % irgendein 3-h-Fenster mit mindestens 18 von 28 gleichgerichteten Tagen.
- **Regime:** Ein Volatilitätswechsel ist binnen Stunden bis etwa anderthalb Tagen erkennbar (CUSUM auf 30-min-Bars: Verdopplung
  ≈ 4,5 h, Halbierung der Varianz ≈ 38 h), ein Driftwechsel erst nach Wochen bis Monaten (1 %/Tag: 34–126 Tage). Fenster werden kombiniert statt gewählt (Pesaran & Pick
  2011).
- **Neuland:** Ob Kontodaten (Pool, Darwin, Wale, Liquidationen) mehrtägige Wendepunkte erklären, hat niemand untersucht. Die
  einzige Hyperliquid-Renditestudie endet bei 30 Sekunden.

**3. Was das Konzept vorschlägt (Einzelheiten `KONZEPT_Regime.md` 3–10).**
- Grundregel: **Die Historie schätzt, das Fenster filtert.** Drei Jahre 30-min-Kerzen (`klines30`, übrige Coins über
  `hl_timestats`) liefern Profile, Parameter und Nullverteilungen. Die 4–8 Wochen liefern nur den Zustand. Die Fensterlänge folgt
  dem letzten Bruch (14–56 Tage).
- R1 Zwei-Uhren-Profil der Schwankung (New York mit Sommerzeit; UTC für Funding und volle Stunde) → RG1.
- R2 Bewegungsgröße 1–7 T: HAR (BTC zusätzlich DVOL), Spannweite ≈ 1,60·√V, Berührwahrscheinlichkeit mit Bar-Korrektur,
  Restbudget des Tags → RG2, RG3.
- R3 Regime-Zustand: CUSUM-Bruchmelder, Jump-Modell, BOCPD „seit wann“; dazu die Regime-Bilanz der vorhandenen Treiber
  (Giacomini-White) → RG4.
- R4 Stufen: Directional Change mit Schwellengitter (1,0–2,0 σ_Tag), Bein-Zustand, Rücksetzer-Zone mit Clustern, nächste Stufe
  neben 1/2 und 2/3, Beinende gegen die Baseline D/θ → RG5–RG7.
- R5 Zeitmuster der Richtung: höchstens drei vorab festgelegte Hypothesen auf der Historie (Vorschlag K1 02–05 Uhr, K2
  Samstagnacht, K3 US-Kernsitzung); live nur „Beobachtung mit Zufallsvergleich“ → RG8.
- R6 Wochenmomentum long/flat, nur BTC und ETH, nur im Trendzustand → RG9.
- R7 Teilnehmer an den Wendepunkten, das eigentliche „Reverse Engineering“: was Pool, Darwin, Wale, Liquidationen und Cluster je
  Bein tun; Hypothesen T1–T3 vorwärts, Urteil frühestens 16.12.2026 → RG10.
- R8 Regime-Analog als paralleler Experte und Pfadfächer (U116 erweitert) → RG11, RG12.
- Phasen:
  - 0: Vorprüfung auf der Historie als Debug-Bericht, berührt nichts (eine Sitzung);
  - 1: Schatten mit eigenem Abschnitt „RG Regime“;
  - 2: R8, Labor L1–L3 mit neuen Kennungen, Vorwärtsprüfung;
  - 3: Experten der Fusion erst nach dem 25.10. und nach den eigenen Urteilen.
- Keine Doppelungen (`KONZEPT_Regime.md` 8): Das HAR von R2 ist das von U109 und wird nur einmal gebaut. Der heutige
  Band-Multiplikator aus `hl_indikatoren.regime` bleibt bis zum 25.10.; die R2-Bänder werden gegen ihn geprüft. Das Zeitprofil
  (neben R1) und die Analog-Suche (neben R8a) laufen unverändert weiter. U116 geht in R2 und R8b auf. U43 und U131 bleiben
  unverändert; R4 verknüpft ihre Ereignisse nur mit den Beinen.
- Die Zusage bis 25.10. bleibt unberührt.

**4. Eigene Fehler im Entwurf (beim Gegenlesen gefunden, vor der Ablage berichtigt).**
- Die Nachweisgrenze der Stufen-Asymmetrie stand zuerst bei 0,8θ bzw. 0,6θ. Mit 80 % Teststärke sind es 1,6θ (4 Wochen) bzw.
  1,1θ (8 Wochen).
- Die Teststärke-Tabelle der Zeitmuster war teils einseitig gerechnet (aus der Recherche übernommen). Jetzt ist sie einheitlich
  zweiseitig; die Zeilen 02–05 Uhr und Samstagnacht sind neu gerechnet.
- Zuschreibungen vorsichtiger formuliert: Andersen & Bollerslev 1996, Osler (Stop-Orders beschleunigen), Ahmed, Grobys & Sapkota
  2020. Ein unbestätigtes Erscheinungsjahr (Han, Kang & Ryu) ist gestrichen.

**5. Entscheidungen beim Nutzer (`KONZEPT_Regime.md` 12).**
1. Phase 0 jetzt bauen? Empfehlung: ja, zuerst.
2. Kalenderhypothesen K1–K3 oder andere, höchstens drei, festgelegt vor dem Bau.
3. Coins: alle sechs oder zuerst BTC und ETH.
4. Anzeige: eigener Abschnitt „RG Regime“ oder Teil der Prognose.
5. Labor L1–L3 mit neuen Kennungen ab Phase 2.
6. Phase 1 im Schatten noch vor dem 25.10. oder alles danach.
7. Teilnehmer-Hypothesen T1–T3 oder eigene Fragen, festgelegt vor Phase 1.

**6. Nebenbei nachgeführt.** Die Stand-Zeile des UPDATE_PLAN nannte noch Pi-Stand 23.47 und „einzuspielen 23.55“. Jetzt: 23.57
seit 07.10. 14:43 laut Vollbericht 19:00, FRED über die API seit 06.10., einzuspielen 23.58; die vergangenen Termine sind
gestrichen.

**Was man wissen muss:**
- Ein Stufenschema, das man im Chart sieht, liefert schon der Zufall: Beine von 2–3 Tagen und höhere Hochs nach höheren Tiefs in
  zwei von drei Fällen. Information steckt nur in der Abweichung davon, und die prüft man auf der Historie, nicht im Fenster.
- Wer in 4–8 Wochen nach „fällt immer“-Fenstern sucht, findet fast sicher eines. Zu jeder solchen Beobachtung gehört die
  Zufallswahrscheinlichkeit nach der Suche.
- Eine Prognose mit P ≈ 50 % ist nicht „zu klein“. Sie sagt, dass die Richtung offen ist. Die Größe der Bewegung ist
  vorhersagbar und gehört ins Band.

## 3θθ. Regime-Modul Phase 0 gebaut: Vorprüfung auf der Historie (U138; Nutzer 07.10. 23:34: „Lass uns mit Phase 0 beginnen“; 08.10., Version 2026-09-23.59, Opus 5.5)

Anlass: Entscheidung 1 aus `KONZEPT_Regime.md` 12. Für die offenen Punkte 2 und 3 gelten die Empfehlungen: Kalenderhypothesen K1–K3
wie vorgeschlagen, alle Coins mit Historie.

**1. Vorab festgelegt, bevor ein echtes Datum gerechnet wurde.** `KONZEPT_Regime.md` 9.1a fasst die Entwurfsbedingungen so genau, wie
der Code sie rechnet: Datenquelle, Mindestlänge 456 Tage, Monats-Rollen mit Embargo, σ̂_Tag kausal, DM nach Coroneo-Iacone und je
Prüfung Rechnung, Null und „belegt“-Bedingung. Was beim Bau geändert wurde, steht dort mit Grund (Abschnitt „Beim Bau geändert“,
sieben Punkte, siehe 3).

**2. Gebaut: `hl_regime.py`** (neu, rund 2.800 Zeilen, nur numpy).
- **Daten:** eigene Datei `regime.db` neben der Hauptdatenbank, Tabelle `rg_klines` (30-min-Kerzen je Coin) und `rg_meta` (Quelle je
  Coin). Schreiben nur mit BEGIN IMMEDIATE.
  - Quelle je Coin: Binance-Futures oder Bybit, je nachdem, welche die längere Historie hat. Geprüft wird in Jahresschritten; die
    Wahl wird beim ersten Laden festgehalten, damit eine Reihe nie aus zwei Börsen gemischt wird.
  - Bis 1.096 Tage zurück, danach nur Neues; Zeitbudget 7 min je Lauf, sonst lädt der nächste weiter.
  - Ohne Netz bricht der Lauf schnell ab (eine nicht erreichbare Börse wird für die übrigen Coins nicht erneut versucht).
  - `klines30` in `hl_liq.db` bleibt unberührt. Die Analog-Suche der Prognose liest sie; neue Coins dort hätten die Prognose vor dem
    25.10. geändert.
- **P0.1:** vier Varianzprofile je 30-min-Bar (flach, UTC-Fourier, heutiges Zeitprofil wie `hl_forecast.time_vol_profile`,
  New-York-Fourier mit UTC-Funding und 8:30/9:30 ET), monatlich neu geschätzt. Dazu beschreibend der Versatz des Werktags-Buckels
  zwischen Sommer- und Winterzeit aus geglätteten Formen: +1 h heißt „folgt New York“.
- **P0.2:** HAR-log gegen EWMA und gegen die 7-Tage-Schwankung des heutigen Bands, für 1, 3 und 7 Tage. Dazu 80-%-Band aus
  Trainingsquantilen, Berührquoten an Hoch und Tief der Bars und Spannweite gegen 1,60·√V.
- **P0.3:** Directional Change mit θ = c·σ̂_Tag je Bein (c = 1,0 … 2,0), sechs Größen gegen 100 Vorzeichen-Surrogate mit gleicher
  Drift, Holm über Coins × c, Hälften. Persistenz der Asymmetrie gegen dieselbe Korrelation in den Surrogaten. Dazu beschreibend
  die Stufen in Prozent und Tagen.
- **P0.4:** Punkte alle 4 h mit D/θ 0,1–0,9. Modell gegen die kalibrierte Baseline, gepoolt über Coins, nur aufgelöste Fälle im
  Training, Verlust je Bein summiert.
- **P0.5:** K1–K3 (Holm, Vorzeichen je Jahr), 24 Stunden und 7 Wochentage (BH), Persistenz nach Heston-Korajczyk-Sadka; dazu
  beschreibend die letzten 8 Wochen.
- **P0.6:** Wochenmomentum BTC/ETH: Brier gegen die Basisrate (Holm über 6), Timing-Regel mit Kosten, Deflated Sharpe, PBO
  (berichtet).
- **P0.7:** Fenster 2/4/8 Wochen, EWMA und Historie gegen Fixed Share wie in R3; das einfache Mittel wird mit berichtet.
- **P0.8:** Die bestehende Analog-Suche ist nachgebaut; Merkmale und Auswahl sind gleich `hl_forecast` (geprüft gegen das
  Original). Sie läuft gegen das Regime-Analog und den Zufallsweg mit σ̂ (CRPS, täglich, 24 h / 72 h / 7 T).
- **P0.9:** CUSUM für Verdopplung der Schwankung und Halbierung der Varianz auf Profil-bereinigten Renditen; Schwellen auf
  GARCH-t-Nullpfaden je Coin; Verzögerung mit eingepflanzten Brüchen; Alarme auf den echten Daten.
- **Bericht:** Prüfstand je Coin, danach je Prüfung die Zahlen mit Vergleichsgröße. Rechenzeit in der Sandbox rund 2 min für sechs
  Coins zu drei Jahren, Spitzenspeicher 182 MB; auf dem Pi geschätzt 4–8 min (niedrige Priorität per `nice`).
- **Einbindung:**
  - Debug-Einträge „★ Regime: Vorprüfung auf der Historie (U138, Phase 0)“, „Regime: Historie laden bzw. ergänzen“ und „Regime:
    Selbsttest“;
  - Berichtsplan `u138-vorpruefung` einmal am 08.10. um 21:00 (erst laden, dann prüfen, je 15 min Grenze);
  - Selbsttest-Schritt in `install.py` (34 Schritte);
  - `version.py` (Prüfsumme), `update.py` (Dateiliste mit `hl_regime.py`, `KONZEPT_Regime.md`, `RECHERCHE_Regime_07-10-2026.md` --
    die beiden Dokumente fehlten dort in 23.58).

**3. Beim Bau geändert (vor jedem echten Lauf), weil Nullen oder Positivkontrollen es zeigten.**
- P0.4: Verlust je Bein summiert statt gemittelt. Das Mittel gewichtete kurze Beine anders als das Training und meldete auf einem
  Zufallsmarkt „belegt“ (p 0,0035).
- P0.6: PBO ist keine Bedingung. Bei sechs fast gleichen Varianten lag es auch für wirksames Momentum bei 0,44 bzw. 0,63.
- P0.7: Kombination = Fixed Share (wie R3). Das einfache Mittel mit Historie lag 23–65 % hinter dem besten Fenster.
- P0.8: Das Regime-Analog muss zusätzlich den Zufallsweg mit σ̂ schlagen. Gegen die bestehende Suche allein gewann schon die
  Rechnung in σ̂-Einheiten (Zufallsmarkt ohne Struktur: p 0,009 bei 24 h).
- P0.9: Verdopplung heißt Schwankung ×2 (Varianz ×4), wie in R3; dazu z² gekappt, 24 h Sperre und gemeinsame Kalibrierung.
  Getrennt kalibriert ergaben sich 2,6 statt 1 Fehlalarm je 30 Tage; ohne Kappe meldete der Melder eine Verdopplung selbst bei
  konstanter Schwankung erst nach 16 h, mit Kappe nach 10 h.
- P0.3: p aus der t-Verteilung mit 99 Freiheitsgraden (die Streuung der Null ist geschätzt).
- P0.1: Der Versatz des Buckels kommt aus Fourier-Formen statt aus Feldmitteln, die bei dicken Rändern an Einzelbars hingen.

**4. Proben.** `hl_regime.py --selbsttest`, 27 Prüfungen, rund 33 s in der Sandbox, ohne Netz:
- Bausteine:
  - Φ, Quantil, t-Verteilung, Holm, BH, CRPS (gegen Brute Force und numerisches Integral);
  - DM-Fehlurteile 3,3 % auf Rauschen und 5,7 % bei AR(0,5)-Differenzen, Newey-West.
- Daten:
  - Laden ohne Netz mit ersetzten Quellen (Quellenwahl, lückenlos bis zur letzten fertigen Kerze, zweiter Lauf nichts Neues,
    unbekanntes Symbol, Zeitbudget);
  - Parser gegen die dokumentierten Binance- und Bybit-Formate.
- Aufbereitung und Kausalität:
  - Lücke zählt nicht zur Tagesvarianz; σ̂, DC-Zustand und Regime-Merkmale sind von späteren Daten unabhängig;
  - HAR mit Band, Fixed Share, P0.4-Vorhersagen samt Modell des Monats und P0.6-Wochenprognosen bleiben vor einem Schnitt gleich,
    wenn die Kurse danach geändert werden.
- Directional Change gegen die geschlossenen Formen (Überschießen 1,02, Dauer 1,12, P(höheres Tief) 0,505, P(höheres Hoch |
  höheres Tief) 0,664); θ folgt der Schwankung (Schwankung ×3: Beine je Tag 1,15-fach).
- P0.8-Nachbau gleich der bestehenden Analog-Suche: 9 Merkmale bis 1e-15, Auswahl identisch.
- Je Prüfung Nulltest und Positivkontrolle:
  - New-York-Buckel belegt, Versatz +1,25 h; UTC-Buckel nicht, Versatz +0,17 h;
  - HAR schlägt EWMA bei Schwankungsregimen;
  - Zufallswege (einer mit Drift 0,4 %/Tag) ohne Abweichung, Momentum über 3 Tage → Überschießen in 5 von 5 Schwellen belegt;
  - P0.4 Null p 0,13, Umkehr nach 21-Tage-Trend p 0,0002, D/θ trägt (0,602 gegen 0,649);
  - K1 mit −25 bp gefunden (−24,3 bp), Vorzeichenwechsel zwischen den Jahren nicht belegt;
  - Momentum belegt (ETH L 14/21), Null nicht;
  - Fixed Share bei Schwankungsstufen ×3 nicht schlechter als das beste Fenster;
  - Regime-Analog schlägt den Zufallsweg bei Umkehr in Schwankungseinheiten, Null nicht;
  - Bruchmelder: 0,86 Fehlalarme je 30 T, Verdopplung nach 10 h, eingepflanzter Bruch nach 14 h gemeldet.
- Urteilslogik von Hand: P0.1 (Monatsanteil), P0.3 (Holm, Hälften), P0.5-Persistenz (Hälften), P0.8 (beide Vergleiche).
- Bericht mit „zu kurz“ und „keine Historie“.
- **Mutationen 29 von 31 rot** (`mut138.py`, nicht im Paket). Zwei bleiben grün, ohne Wirkung auf die Urteile: die 24-h-Sperre nach
  einem Alarm (die gemeinsame Kalibrierung gleicht sie aus) und der Melder für Varianz ×2 statt ×4 (meldet die Verdopplung ebenfalls
  binnen 12 h).
- **Nullreplikationen** (außerhalb des Selbsttests):
  - P0.1: 0 von 8 UTC-Märkten mit „New-York-Uhr“, 0 von 8 flachen Märkten belegt;
  - P0.3 mit 100 Surrogaten: 0 belegt in zwei Durchgängen zu 6 Coins;
  - P0.4: 0 von 16 belegt;
  - P0.5: eine K-Hypothese in 8 Märkten (Holm je Markt);
  - P0.6: 0 in 6 Läufen; P0.8: 0 von 8.
- Ganzer Lauf auf sechs synthetischen Coins zu 1.096 Tagen:
  - belegt sind P0.1 und P0.2 in allen sechs (eingebaut: New-York-Buckel, Schwankungsregime);
  - dazu ein Zufallstreffer bei den Stunden (BTC 02–03 UTC, +4,6 bp). Bei Benjamini-Hochberg mit q = 0,10 über 31 Tests ist das zu
    erwarten (je Coin rund 10 % Wahrscheinlichkeit für mindestens einen); die Jahresbedingung hält nicht alle ab;
  - sonst nichts belegt;
  - P0.7 und P0.9 bleiben nicht belegt: Fixed Share 1–3 SE hinter 2 Wochen, Verdopplung erst nach 19–26 h. Bei echten Kursen mit
    zäher Schwankung ist das auch zu erwarten.

**5. Eigene Fehler im Bau, vor der Lieferung gefunden.**
- Die erste Kausalitätsprobe für Fixed Share verglich nur NaN: Die Historie war als 500-Tage-Mittel gebaut, Fixed Share also vor Tag
  499 leer. Gefunden durch eine Mutation (Blick in die Zukunft blieb grün). Jetzt nutzt die Probe dieselben Fenster wie P0.7 und
  zählt die verglichenen Werte (374).
- Die erste Mutation „Fixed Share lernt mit morgen“ war gar kein Blick voraus: Der Verlust von morgen ist übermorgen bekannt. Ersetzt
  durch „übermorgen“, jetzt rot.
- Die P0.4-Kausalitätsprobe schnitt drei Tage nach Monatsanfang; Training mit unaufgelösten Fällen fiel so nicht auf. Jetzt schneidet
  sie am Monatsanfang und vergleicht zusätzlich das Modell des Monats.
- Erste Positivkontrolle P0.3 (Trendregime ±0,6 %/Tag) war je nach Startwert z 0 bis 4,5, also kein verlässlicher Test. Ersetzt durch
  Momentum über 3 Tage (z 3,2–8,1 über vier Startwerte).

**Was man wissen muss:**
- Eine Probe, die nur fehlende Werte vergleicht, besteht immer. Jede Vergleichsprobe zählt, wie viele echte Werte sie verglichen hat.
- „Besser als die bestehende Suche“ ist kein Beleg für Regime-Ähnlichkeit, solange schon die Skalierung mit σ̂ allein gewinnt. Jede
  neue Prognose muss auch gegen den einfachsten Konkurrenten mit derselben Schwankung antreten.
- Ein Kriterium, das auch eine wirksame Regel ablehnt (PBO bei fast gleichen Varianten), misst die Auswahl unter Varianten, nicht
  die Wirksamkeit.

## 3ιι. Erster echter Lauf der Regime-Vorprüfung ausgewertet; K3 war nicht driftneutral (eigener Fehler 23.59, U139) (08.10., Version 2026-09-23.60, Opus 5.5)

Anlass: Der Nutzer lädt um 02:24 den Bericht des von Hand gestarteten Laufs hoch („★ Regime: Vorprüfung auf der Historie“,
08.10. 02:06, Code 23.59, Exit 0, 480,7 s, davon Rechnen 162 s). Ergebnis im Einzelnen: `KONZEPT_Regime.md` 9.4.

**1. Daten:** BTC, ETH, ZEC und XMR von Binance-Futures, PAXG von Bybit, je 1.096 Tage (08.10.2023–07.10.2026, 52.608 Kerzen,
keine Lücke); HYPE erst ab 30.05.2025 (496 Tage). Quellenwahl, Budget und Lückenprüfung arbeiteten wie vorgesehen.

**2. Ergebnis (wie vorab festgelegt).**
- **Belegt:**
  - P0.5 bei XMR: K1 +12,3 ± 4,9 bp, also das umgekehrte Vorzeichen der Hypothese „fällt“; K3 −82,6 ± 15,9 bp; Stunden 07–08
    (+8,0), 12–13 (−11,1) und 13–14 UTC (−8,6 bp); Persistenz (HKS) Steigung +0,249, p < 0,0001.
  - P0.5 bei PAXG: K3 −13,5 ± 4,0 bp (beides mit dem rohen K3, siehe 3).
  - P0.7 bei ZEC und XMR.
- **Nicht belegt** (alles andere):
  - P0.1: D schlägt das heutige Zeitprofil in 5 von 6 Coins, aber nicht die glatte UTC-Form. Der Buckel wandert mit der
    US-Sommerzeit (+0,75 bis +1,0 h bei BTC, ETH, HYPE und PAXG).
  - P0.2: HAR schlägt EWMA bei 1 Tag in allen sechs, bei 7 Tagen nur XMR. Das Band ist bei ZEC, XMR und PAXG zu schmal (69–77 %).
    Berührquoten liegen beim 0,75- bis 0,93-Fachen der Formel.
  - P0.3: Die Beine sind Zufallsgeometrie (BTC c = 1,5: P(höheres Tief) 0,57 gegen 0,54, P(höheres Hoch | höheres Tief) 0,67
    gegen 0,68). Abweichungen gibt es nur bei der Dauer (ETH c 1,0; PAXG c 1,0 und 1,25), Persistenz nirgends.
  - P0.4: Das Modell (0,6130) ist schlechter als D/θ (0,6102), und D/θ ist kalibriert.
  - P0.6: kein Momentum (PBO 0,56, beste DSR 0,89).
  - P0.8: Der Zufallsweg mit σ̂ ist bei 72 h und 7 Tagen meist am besten.
  - P0.9: Die Fehlalarme liegen im Soll, aber eine Verdopplung wird erst nach 51–366 h gemeldet (Soll ≤ 12 h).
  - K1 und K2 sind bei BTC und ETH um null (BTC +0,6 ± 2,3 und −1,8 ± 4,9 bp). K3 ist in allen sechs Coins negativ; bei BTC und
    ETH wechseln die Jahre das Vorzeichen.

**3. Eigener Fehler in 23.59: K3 war nicht driftneutral (U139), berichtigt in 23.60.**
- **Befund beim Auswerten:** K3 verglich die Sitzung 9:30–16:00 New York (6,5 h) mit dem ganzen Rest seit 16:00 des
  Vorhandelstags, im Mittel 27,1 h (17,5 h, montags mit dem Wochenende 65,5 h). Schon eine feste Drift d je Stunde ergibt so
  (6,5 − 27,1)·d ≈ −0,86 × mittlere Tagesrendite, ohne jeden Sitzungseffekt. Grob gerechnet (Endkurse Crypto.com 08.10.:
  BTC 83.273 $, PAXG 4.116 $, ETH 2.573 $; Anfangskurse Oktober 2023 aus dem Gedächtnis) sind das bei BTC rund −8,5 bp, bei PAXG
  rund −6 bp und bei ETH rund −3,6 bp.
- **Ursache:** Nulltest und Positivkontrolle von P0.5 liefen ohne Drift, eine Positivkontrolle gab es nur für K1. Den Fall
  „Drift ohne Sitzungseffekt“ hat keine Probe gestellt. Fenster ungleicher Länge zu vergleichen, misst die Drift mit.
- **Berichtigt** (`hl_regime.p05_kalender`): K3 = Sitzung − (6,5 h ÷ Länge des Rests) × Rest, die Längen aus den Zeitstempeln
  (Zeitumstellungen eingeschlossen). Jede feste Drift hebt sich genau auf.
  - Das rohe K3 bleibt als Anzeige, mit dem Wert, den die Drift allein ergäbe (aus den eigenen Kerzen).
  - K1 und K2 bleiben absolut („fällt“ heißt Rendite < 0); ihr Driftanteil steht daneben.
  - Die Hypothese „US-Sitzung schwächer als der Rest“ meint je Stunde. Die Korrektur ist eine Fehlerbehebung, keine neue
    Hypothese (`KONZEPT_Regime.md` 9.1a Punkt 8).
- **Was der Lauf 21:00 (Berichtsplan, mit 23.60) zeigen dürfte**, grob geschätzt mit einem Zwei-Raten-Modell (Rate in der Sitzung,
  Rate im Rest, Drift aus Anfangs- und Endkurs; nicht gerechnet):
  - XMR bleibt deutlich, rund −45 bp je Sitzung oder −7 bp je Stunde gegenüber dem Rest;
  - BTC rund −10 bp, ETH rund −20 bp;
  - PAXG rund −5 bp, vermutlich nicht mehr belegt.
- **Proben** (`hl_regime.py --selbsttest`, jetzt 28 Prüfungen, neu „P0.5: Drift +40 bp je Tag …“):
  - Drift +40 bp je Tag (Start 10.11.2023, drei Frühjahrs- und zwei Herbstumstellungen): K3 bis auf 10⁻⁹ gleich wie ohne Drift,
    nicht belegt; roh −42,4 bp, p 0,0008.
  - −40 bp je US-Sitzung: K3 belegt, −40,4 bp.
  - Nullreplikationen mit 40 Märkten je Fall: berichtigt 1, 1 und 2 von 40 belegt bei Drift 0, −40 und +80 bp je Tag; roh 3, 27
    und 40 von 40 mit p < 0,05. Wirksamkeit bei −40 bp: 38 von 40.
  - Mutationen 5 von 6 rot (`mut160.py`, nicht im Paket): K3 wieder roh, Skalierung verkehrt, Rest immer 17,5 h, Sitzung 6 h,
    Zeitumstellung übergangen. Grün bleibt eine Mutation der Testhilfe (Effekt nur bis 15 Uhr: −34 statt −40 bp, innerhalb der
    Toleranz ±12 bp).
  - Die Zeitumstellung fiel erst auf, als der Testmarkt ungleich viele Frühjahrs- und Herbstumstellungen hatte; mit drei zu drei
    hoben sich die Fehler genau auf.

**4. Weitere Änderungen in 23.60 (nur Anzeige):**
- P0.3 druckt bei belegten Abweichungen „beobachtet gegen Mittel der Surrogate“; im Lauf 02:06 fehlte die Richtung der Dauer.
- P0.5 druckt bei K mit p Holm < 0,05 zusätzlich Median, Mittel ohne je 2,5 % Ränder, Anteil negativer Tage und das Mittel je Jahr.
- P0.8 druckt auch „Bestand gegen Zufall p“ (der Nachbau der Analog-Suche der Prognose gegen den Zufallsweg mit σ̂; beschreibend
  für die Auswertung nach dem 25.10.).
- Berichtsplan `u138-vorpruefung` (08.10. 21:00): Text für den zweiten Lauf. Die übrigen Urteile sollten bei einem Tag mehr Daten
  gleich bleiben; wenn nicht, ist das selbst ein Befund.

**5. Lesart und Vorschlag** (`KONZEPT_Regime.md` 9.4 und 12):
- **Richtung über Stunden bis Tage:** nicht vorhersagbar in diesen Daten. Stufen, Rücksetzer und höhere Tiefs sind
  Zufallsgeometrie bei wechselnder Schwankung.
- **Vorhersagbar ist die Größe:** HAR bei 1 Tag, ein glattes Tagesprofil statt des Zellenprofils, die kalibrierte Bein-Geometrie
  (D/θ).
- **Kalender:** Einziger möglicher Befund ist XMR in der US-Sitzung. Er ist für einen liquiden Markt verdächtig groß und braucht eine
  zweite Quelle und ältere Daten.
- **Vorschlag:**
  - Phase 0b, ein Vorhaltetest auf 10/2020–10/2023 nur für das, was getragen hat (Liste a–e vorab festschreiben), dazu XMR von
    Bybit;
  - danach Phase 1 schlank (Größe, Tagesprofil, Bein-Geometrie, Kalender nur bestätigt);
  - Bruchmelder, Regime-Analog, Wochenmomentum und Labor L1–L3 entfallen;
  - nach dem 25.10. vormerken: Zeitprofil glätten, Band mit HAR, Analog-Suche gegen den Zufallsweg bewerten.

**Was man wissen muss:**
- Wer zwei Zeitfenster ungleicher Länge vergleicht, misst die Drift mit. Jeder Fenstervergleich braucht einen Nulltest mit Drift
  (und mit Zeitumstellungen in ungleicher Zahl), nicht nur den driftfreien Zufallsweg.
- Ein Vergleich „Rohwert gegen Nachrechnung“ im eigenen Bericht (Driftanteil neben K3) macht so einen Fehler sichtbar, bevor ein
  Urteil darauf baut.

## 3κκ. Swing-Trades: Konzept, Modul, sechs Strategien im TradeLabor (U140; Nutzer 08.10. 07:20; Version 2026-09-23.61, Opus 5.5)

Anlass: „Ich will Swing-Trades in das System inkludieren. Baue alles dafür Notwendige ein. Entwickle das bestmögliche Konzept und
integriere eine oder bevorzugt mehrere bestmögliche Strategien in das TradeLabor.“ Davor die ehrliche Einschätzung auf seine Frage:
als Signalquelle für Swing taugt das System heute nicht (Phase 0 fand keine Richtungsvorhersage über Tage), als Risikorahmen teilweise.

**1. Konzept vorab (`KONZEPT_Swing.md`), bevor eine echte Kerze gerechnet wurde.**
- **Swing heißt hier:** Entscheidung einmal am Tag nach dem Tagesschluss 00:00 UTC, Haltedauer 1–30 Tage, Stop und Größe aus
  σ_Tag (EWMA der Tages-RV, Halbwertszeit 20 Tage, einschließlich des Entscheidungstags), je Strategie und Coin eine Position.
- **Vier Strategien, Parameter aus der Lehrbuchpraxis, nichts optimiert:** S1 Trend-Ausbruch (20-Tage-Kanal, Nachzieh-Stop 3 σ,
  Ausstieg am 10-Tage-Kanal), S2 Rücksetzer im Trend (die Idee des Nutzers mit den höheren Tiefs; ab 2 σ unter dem 10-Tage-Hoch,
  Ziel zurück zum Hoch), S3 Ausbruch nach Ruhe (Schwankung im untersten Fünftel des Jahres), S4 Gegenbewegung nach Übertreibung
  (3-Tage-Bewegung über 2,5 σ·√3 mit gedrängtem Funding). Dazu zwei Kontrollen: Zufall (Ausstiege wie S1) und Zufall im Trend
  (Ausstiege wie S2).
- **Risiko vor Richtung:** 100 USD bis zum Stop je Position, Notional = 100 USD ÷ Stop-Abstand, höchstens 10.000 USD; Ergebnisse in R.
- **Urteil vorab** (Vorprüfung auf der Historie ab 2020): ≥ 60 Trades, Tagesergebnis p < 0,05 und positiv (HAC), Mehrertrag gegen ein
  Zeitpunkt-Placebo nach Holm über die vier < 0,05, beide Hälften positiv, DSR ≥ 0,95. Echtes Geld nie automatisch.

**2. Gebaut.**
- **`hl_swing.py`** (neu, rund 1.850 Zeilen, nur numpy):
  - eigene Datei `swing.db` neben der Hauptdatenbank (`sw_klines`, `sw_funding`, `sw_meta`; Schreiben nur mit BEGIN IMMEDIATE):
    30-min-Kerzen der Binance-USDT-Perpetuals ab 01.01.2020 und deren Funding; Laden mit Zeitbudget, Gewichtsbremse und einer
    Sperre gegen zwei gleichzeitige Ladevorgänge (Eintrag `laeuft` mit Prozess und Zeit);
  - Swing-Takt im Dashboard-Prozess: alle 5 min prüfen, ob die letzte fertige Kerze fehlt, dann höchstens 4 min laden
    (`HL_SWING=0` schaltet ab);
  - Tageskerzen, σ_Tag, Kennzahlen (Kanäle ohne den Tag, Mittel, Ruhe-Perzentil, Funding-Druck);
  - `einstieg`, `nachfuehren`, `plan`: dieselben Funktionen für die Historie und das Labor;
  - Handelssimulation auf 30-min-Kerzen (Stop in der Kerze und bei Lücke zur Eröffnung, Ziel als Maker, Gebühren, Abstand zur
    Mitte, Funding je Zahlung, Tagesergebnis zum Schluss), Zeitpunkt-Placebo, Urteil, Debug-Bericht mit Zerlegung je Trade.
- **`hl_labor.py`:** sechs neue Strategien in der Gruppe „Swing“ mit eigenen Kennungen (`swing_trend@059e6156`,
  `swing_ruecksetzer@8e863897`, `swing_kompression@57d6ab42`, `swing_gegenbewegung@3373d1f2`, `swing_zufall@c2f0c579`,
  `swing_ruecksetzer_zufall@9e2287e8`); die 38 bestehenden Kennungen unverändert (Probe). Neu:
  - Signalfunktion `sig_swing` (einmal je Tag nachführen bzw. Signal-Ausstieg; Einstieg nur mit frischen Tageskerzen, höchstens 6 h
    nach dem Schluss, einmal je Tag; Zufall der Kontrollen je Kennung, Coin und Tag fest);
  - Aktionen „aus“ (Markt-Ausstieg ohne Pause, im selben Takt darf die Gegenrichtung folgen) und „stop_nachziehen“ (nur in
    Gewinnrichtung, Ereignis „Stop nachgezogen“), Größe je Aktion (`notional`);
  - Datenfluss-Zeilen „Tageskerzen (swing.db)“ und „Swing-Takt“, Live-Tafel je Strategie (Kanal, Trend, Ruhe, z, Funding),
    Abschnitt „Swing (U140)“ im Labor-Bericht mit R je Trade.
- **`hl_viz.py`:** Debug-Einträge „★ Swing: Vorprüfung auf der Historie (U140)“, „Swing: Historie laden bzw. ergänzen“,
  „Swing: Selbsttest“; Berichtsplan `u140-swing-vorpruefung` 08.10. 21:30 und `u140-swing-vorpruefung-2` 09.10. 07:30 (jeweils
  erst laden, dann prüfen); Swing-Takt beim Start; Gruppe „Swing“ in der Labor-Ansicht.
- **`install.py`** (Kompilierliste, Schritt „Swing: Nulltest, Positivkontrollen, Kausalität, Ausführung (hl_swing)“, jetzt
  35 Schritte), `version.py` (Prüfsumme mit `hl_swing.py`), `update.py` (Dateiliste mit `hl_swing.py`, `KONZEPT_Swing.md`).

**3. Beim Bau geändert, vor dem ersten echten Lauf (`KONZEPT_Swing.md` 6a): der Placebo-Vergleich.**
- Der Entwurf zählte, wie viele Placebo-Läufe mindestens das mittlere R der Strategie erreichen (Rang). Auf Zufallswegen ohne
  Effekt lag dieser p bei S4 in 9 von 30 Märkten unter 0,05 (Soll 1,5), in 150 weiteren in 25 %; S2 14 %.
- **Ursache:** Die Strategien wählen Tage mit anderer Schwankung als der Zufall (S4: Tages-RV am Einstieg rund 2 σ²_Tag, Placebo
  0,9 σ²_Tag); ihr Mittel streut stärker als das der Placebo-Läufe, also wird der Rang zu oft extrem (U-förmige p). Funding war es
  nicht („nur Kurs“ gab dieselben p).
- **Jetzt:** Mehrertrag je Trade gegen das Placebo-Mittel, studentisiert mit dem Standardfehler der Strategie aus der Tagesreihe
  (HAC; zählt gleichzeitige und überlappende Trades mehrerer Coins richtig); der Rang bleibt als Anzeige.
- **Kalibrierung** auf Märkten mit echtem Pfad in der Kerze (1-min-Schritte, wahres Hoch/Tief), Placebo-p < 0,05: S1 1 %,
  S2 5 %, S3 2 %, S4 5,0 % (300 Märkte; Rang dort 21 %). Auf den gröberen Selbsttest-Märkten (gerader Pfad, zufälliger Docht)
  blieb bei S4 ein Rest von 8–10 %: ein Artefakt dieser Kerzenbildung, das stop-lastige Ausstiege bevorzugt (+0,02 bis +0,05 R
  ohne Effekt, auch in log-Renditen, ohne Dochte am größten); mit echtem Pfad +0,009 ± 0,009 R.
- **Urteil als Ganzes:** 0 von 160 Nulltests belegt (40 Märkte × 4 Strategien in fünf Varianten); Tagesergebnis allein p < 0,05 und
  positiv in 3,1 % (Soll 2,5 %).

**4. Proben.**
- `hl_swing.py --selbsttest`: 20 Prüfungen, rund 40 s in der Sandbox, ohne Netz (Einzelheiten `KONZEPT_Swing.md` 8): Bausteine gegen
  Brute Force; Ausführung von Hand nachgerechnet (Stop mit Lücke, Stop in der Einstiegskerze, Stop und Ziel in einer Kerze, Ziel
  als Maker, XMR doppelt, Funding über Tage, Zeitausstieg, Größe mit Deckel, Nachzieh-Stop nur in Gewinnrichtung auch bei
  steigendem σ, Kanal-Ausstieg mit Gegen-Einstieg); Regeln an ihren Schwellen; Kausalität (Kennzahlen, Entscheidungen, Gegenprobe,
  Labor-Ausschnitt, Lesen aus `swing.db` um 23:50 und 00:01); Placebo-Aufbau; Urteil an gebauten Ergebnissen; Laden ohne Netz;
  Nulltest; Positivkontrollen S1–S4 (Placebo-p × 4 < 0,0001); Bericht.
- TradeLabor-Selbsttest, neu: Einstieg am Tag nach dem Ausbruch binnen 15 min mit Größe nach Risiko (6.537 USD bei σ_Tag 0,77 %),
  vier Nachzieh-Stops nur nach oben, Ausstieg am Rutsch an denselben Tagen wie die Historie, Funding über Tage, Neustarts,
  veraltete Tageskerzen, einmal je Tag, 6-h-Fenster, Signal-Ausstieg ohne Pause mit neuem Einstieg im selben Takt, Bilanz in R,
  bestehende Kennungen unverändert.
- **Mutationen 33 von 34 rot** (`mut140b.py`, nicht im Paket): 28 in `hl_swing.py` (Kanal mit dem Tag, Einstieg zur Eröffnung des
  Signaltags, σ vom Folgetag, Lücke übergangen, Funding verkehrt, Nachzieh-Stop lockert, Placebo auf den echten Trades, Holm,
  Hälften, Gebühr, Richtung des Mehrertrags, S2-Placebo ohne Trend, Ziel vor Stop, Notional ohne Deckel, Ruhe am Signaltag, z ohne
  √3, Rücksetzer ab 1,5 σ, Zeitausstieg später, Funding-Druck mit dem Tag, voller Tag ohne 23:30-Kerze, Funding um 24:00, Kanal-
  Ausstieg fehlt, Stop in der Einstiegskerze übergangen, unfertige Kerze im Labor-Ausschnitt, SE nur aus dem Placebo, p
  zweiseitig, SE ohne Umrechnung, Kurs-Anteil mit Abstand) und 5 von 6 im Labor (einmal je Tag, 6-h-Fenster, Größe fest,
  Signal-Ausstieg, Nachzieh-Stop). Grün bleibt „veraltete Tageskerzen erlaubt“: gleichwertig, denn ein veralteter Tag liegt immer
  mehr als 6 h zurück, und das 6-h-Fenster greift ohnehin.
- **Rechenzeit** in voller Größe (5 Coins × 2.450 Tage, 200 Placebo-Läufe): 57 s in der Sandbox; Pi geschätzt 2–3 min.
- **Ansicht** (Demo-Datenbank mit `swing.db`, Handybreite 390 px): Gruppe „Swing“ in Live, Positionen, Strategien und Datenfluss,
  Positionen mit Größe nach Risiko (z. B. 2.726 USD bei σ_Tag 1,87 %), Signal-Ausstieg „Schluss über dem 10-Tage-Hoch“ im Takt nach
  Mitternacht; keine Skriptfehler, kein waagrechter Überlauf. Im Datenfluss steht der Swing-Takt auf „fehlt“, wenn er in diesem
  Prozess nicht läuft (vorher fälschlich grün), und auf „alt“, wenn er über 1 h nicht geladen hat.

**5. Eigene Fehler im Bau, vor der Lieferung gefunden.**
- Der Zeitausstieg las die Höchstdauer aus den Regeln statt aus dem Signal (in den heutigen Abläufen gleich; die Handprobe mit
  eigener Höchstdauer fand es).
- Das synthetische Funding der Tests war zehnmal zu groß: Auf Nullmärkten lag dann jedes Placebo-p bei 1,0. Jetzt bis ±0,05 % je
  Zahlung wie echt.
- Vier Pfade hatte keine Probe gesehen, erst Mutationen zeigten es: ein Nachzieh-Stop, der zurückweichen darf (bei festem σ steigt
  der beste Schluss nur, der Stop also auch -- jetzt mit steigendem σ, Long und Short), ein Stop schon in der Einstiegskerze und
  der Signal-Ausstieg im Labor (der Testmarkt endete stets am Nachzieh-Stop -- jetzt ein eigener Labor-Lauf mit erzwungenem
  Signal-Ausstieg). Dazu das Lesen aus `swing.db` kurz vor Mitternacht.
- Der Rang-Test des Placebos (3).
- Der Labor-Selbsttest brauchte mit Swing zuerst 2 min 24 s (Tageskerzen in jedem Takt neu, Heatmap-Anker); jetzt je
  abgeschlossenem Tag einmal gerechnet und der Anker in der Probe ersetzt (gesamt rund 90 s, im Installationslauf 103 s).

**6. Was der Lauf am 08.10. um 21:30 zeigen dürfte** (Einschätzung, nicht gerechnet): S1 am ehesten positiv (Trendjahre 2020/21
und 2022, Literatur), die Schwelle „belegt“ ist aber hoch (Sharpe 1 ergibt auf sechs Jahren t ≈ 2,4); S2 bis S4 eher nicht
belegt. Die Zerlegung je Trade zeigt, ob ein Vorsprung aus dem Kurs oder aus Funding kommt (S4 kassiert nach Abstürzen Funding).

**Was man wissen muss:**
- Ein Rang gegen Placebo-Läufe ist nur gültig, wenn die Trades der Strategie unter der Null so streuen wie die des Placebos.
  Strategien, die nach starken Bewegungen einsteigen, wählen eine andere Schwankung; dann den Mehrertrag mit dem eigenen
  Standardfehler prüfen.
- Synthetische Kerzen ohne echten Pfad in der Kerze verzerren Simulationen mit Stops und Zielen. Wer Ausstiegsregeln kalibriert,
  braucht Testmärkte mit feinerem Pfad.
- Eine Probe mit konstanter Schwankung kann einen Nachzieh-Stop, der zurückweichen darf, nicht sehen. Jede Regel „nur in eine
  Richtung“ braucht einen Testfall, in dem die andere Richtung möglich wäre.

## 3λλ. Berichtsbündel 08.10. 22:44 ausgewertet: erste Swing-Vorprüfung, zweiter Regime-Lauf, Makro-Signale (nur Dokumente, Version 2026-09-23.61 unverändert, Opus 5.5)

Anlass: Der Nutzer lädt um 22:44 die Sammeldatei der letzten 24 h hoch (8 Berichte). Der Pi läuft auf 23.61 · 07a654b6e7 (A1 ✓).

**1. Swing-Vorprüfung, erster echter Lauf (U140, 21:30; `KONZEPT_Swing.md` 6b).**
- **Daten vollständig:** Der Swing-Takt hatte die Historie vor dem Termin geladen (der Ladelauf um 21:30 fand je Coin nur eine
  neue Kerze). BTC und ETH ab 01.01.2020, ZEC und XMR ab Februar 2020, HYPE ab 30.05.2025, keine Lücke. Rechenzeit 27 s; die
  Schätzung von 2–3 min war zu vorsichtig.
- **Nichts belegt.**
  - S3 Ausbruch nach Ruhe: Ø +0,34 ± 0,17 R je Trade, Sharpe 0,72, p Tag 0,10, Mehrertrag gegen das Placebo +0,28 ± 0,21 R (p Holm
    0,36), DSR 0,68. Positiv in allen fünf Coins und in jedem Jahr; 2026 trägt gut die Hälfte (+37,3 von +70,5 R).
  - S1 Trend-Ausbruch: Ø +0,17 ± 0,10 R, Sharpe 0,49, p 0,20, DSR 0,46. Trägt bei BTC (+35,2 R) und ETH (+24,0), nicht bei ZEC
    (−5,4) und XMR (−0,3).
  - S2 Rücksetzer im Trend: Ø +0,04 ± 0,05 R, kaum mehr als zufällige Einstiege an Trendtagen (+0,05 ± 0,06 R).
  - S4 Gegenbewegung nach Übertreibung: Ø −0,20 ± 0,13 R (Kurs −0,21 R, Funding +0,02 R).
- Der Vorsprung von S1 und S3 kommt aus dem Kurs; Gebühren, Abstand und Funding kosten 0,05–0,06 R je Trade.
- Auch der alte Rang-Test hätte nichts belegt (S3: 0,025 × 4 = 0,10).
- **Lesart:** genau der vorab beschriebene Fall. Ein Sharpe von 0,5–0,7 ist auf sechs Jahren nicht von Glück zu trennen (t ≈ 1,3–1,7).
- **Folgen:** Alle sechs Strategien laufen im Labor weiter; kein Echtgeld. Neu vorgeschlagen (Entscheidung 4 in `KONZEPT_Swing.md`
  10): ein Vorhaltetest in der Breite, S1 und S3 unverändert auf weiteren Binance-Perpetuals nach fester Auswahlregel. Grob
  erreichbar wäre für S3 t ≈ 1,9–2,2, also die Grenze; vorwärts im Labor bräuchte S3 drei bis vier Jahre bis t ≈ 1,5.

**2. Regime-Vorprüfung, zweiter Lauf (U138/U139, 21:00; `KONZEPT_Regime.md` 9.5).**
- **K3 je Stunde, die Abschätzung aus 3ιι traf:** XMR −45,0 ± 8,7 bp (belegt; geschätzt rund −45), ETH −22,7 ± 8,3 (Jahre
  wechseln; geschätzt −20), BTC −10,5 ± 6,4 (geschätzt −10), PAXG −5,3 ± 2,6 (nicht mehr belegt; geschätzt −5), HYPE −29,6 ± 18,7,
  ZEC +7,7 ± 14,6. Der PAXG-Befund des ersten Laufs war die Drift.
- Belegt bleiben der XMR-Kalender (K1 +12,3 bp, K3, drei Stunden, Persistenz) und P0.7 bei ZEC und XMR.
- **P0.3 kippt mit einem Tag mehr Daten** in drei Fällen (ETH c 1,0 fällt weg; ZEC c 1,0 und XMR c 1,0/1,5 kommen dazu). Diese
  Urteile liegen an der Holm-Grenze und hängen an der Ziehung der 100 Surrogate: kein stabiler Befund.
- **P0.8 „Bestand gegen Zufall“** (neu seit 23.60): Die Analog-Suche der Prognose ist bei 72 h und 7 Tagen schlechter als der
  Zufallsweg mit σ̂ (ETH p 0,003, ZEC < 0,003, HYPE 72 h 0,021; BTC 0,075 / 0,094). Vorgemerkt für nach dem 25.10.
- Prüfpunkt (e) für Phase 0b entfällt; die Entscheidungen 8 und 9 bleiben beim Nutzer.

**3. Makro (U126, 20:15):**
- Die Signale rechnen in 4,2 s.
- Live gegen Nachrechnung: 192 von 192 Werten gleich, größte Abweichung 0,00 Perzentilpunkte. DVOL und ETF-Fluss gelten seit 23.56
  am offenen Tag als vorläufig und erscheinen nicht mehr als „abweichend“.
- Summenzeile „belegt 4 von 337“ wie zuvor; alle 51 Reihen frisch, FRED 12 von 12; Selbsttest der Signale bestanden.

**4. Vollbericht 01:43 (von Hand, noch 23.58):** nichts Neues.
- API bei 97 % des Deckels, kein 429.
- Pool-Fills im Rückstand (Median 16 h, 258 Konten wegen des Gewichts zurückgestellt; bekannt).
- Prognose 4 h 48 % gegen eine Basis von 55 % (Urteil U108 am 25.10.); 1 von 36 Gewichten gelernt (U134).

**5. Für die nächste Code-Änderung (nur Anzeige):** Der Swing-Bericht schreibt in „Je Coin“ „1 Trades“ (S4, HYPE).

**Was man wissen muss:**
- Eine vorab notierte Abschätzung, die eintrifft (K3 in vier Coins), ist der beste Beleg dafür, dass eine Korrektur das Richtige
  misst.
- Urteile an der Holm-Grenze kippen schon mit einem Tag mehr Daten. Sie zählen erst, wenn sie einen Vorhaltetest bestehen.
- „Plausibel“ und „belegt“ sind verschiedene Dinge: Eine Swing-Regel mit Sharpe 0,5–0,7 ist auf sechs Jahren nicht nachweisbar,
  vorwärts erst nach Jahren.

## 3μμ. Zyklus-Studie und „Dip halten“: Rallyes, Rücksetzer, Warnsignale, sicherste Strategie (U141; Nutzer 08.10. 23:45; Version 2026-09-23.62, Opus 5.5)

Anlass: Der Nutzer fragt (08.10. 23:45), sinngemäß: Der Markt läuft nach dem Pump-and-Dump-Prinzip. Nach einem bestätigten Dump
kaufen, laufen lassen, ohne viele Trades, vor dem nächsten Rücksetzer raus. Wie lange dauert der Zyklus bis zum Rücksetzer, nach
wie vielen Prozent kommt er, welche Signale (Overheat, Crowding) kündigen ihn an, was ist die sicherste Strategie? Fokus BTC, ETH,
HYPE, Gold langfristig, ZEC spekulativ; 500 Trades am Tag bringen nichts. Nebenbei: Steht im TradeLabor überall Minus wegen eines
Fehlers?

**1. Vorab festgelegt** (`KONZEPT_Zyklen.md`, 09.10. gegen 00:30, vor jedem echten Kurs; Kalibrierung nur auf synthetischen Märkten).
- Teil A Zyklen: Directional Change mit 10/20/30 % auf den Tagesschlüssen von Coin Metrics (`makro.db`: BTC ab 2013, ETH/XMR ab
  2016, ZEC ab 2017; HYPE aus `swing.db`, PAXG aus `regime.db` beschreibend), gegen 1000 Vorzeichen-Surrogate mit einem Vorzeichen
  je Kalendertag für alle Coins (Drift, Schwankungsballung und Gleichlauf bleiben).
- Teil B Strategien: HODL, T200, VOL, Z1 „Dip halten“ (Dump ≥ 5 σ vom 20-Tage-Hoch zum 10-Tage-Tief, Erholung ≥ 1 σ bei ≥ 1 σ
  Abstand zum Hoch; Stop 1 σ unter dem Tief, Nachzieh-Stop 3 σ ab dem Folgetag, höchstens 60 Tage), Z2 (+ raus bei RSI ≥ 80 oder
  Funding-Druck ≥ 2), Z3 (+ raus bei der typischen Rallye aus den eigenen Z1-Trades davor), Z0 Zufall. Urteile B1 Timing (Mehrertrag
  je Markttag gegen 200 Surrogate, Holm über 3) und B2 sicherer als HODL (ΔSharpe im Kern-Portfolio BTC+ETH, Blockbootstrap 30 T,
  Holm über 5, beide Hälften).
- Teil C Warnsignale: C1 OI-Überhitzung (wie im Dashboard), C2 Funding-Druck, C3 RSI ≥ 80, C4 Fear & Greed ≥ 80 gegen einen
  Rücksetzer ≥ 1,5 σ·√14 in 14 Tagen; RR gegen die Surrogate (nur Richtung zählt), Holm über 4, beide Hälften.
- Teil D: Z1/Z2 mit der U140-Rechnung auf `swing.db` (Ausführung, Kosten, Funding), beschreibend.
- Kalibrierung vorab: Dump ab 3 σ hielte Z1 drei Viertel der Zeit im Markt (13,5 Einstiege je Jahr); 5 σ ergibt rund 7–8 je Jahr
  und 40 % im Markt.

**2. Vor dem ersten echten Lauf geändert** (`KONZEPT_Zyklen.md` 12):
- Teil A: gepoolter Mittelwert je Schwelle (Holm über 3) statt Median je Coin und Schwelle (Holm über 12).
  - Tages-Schwung verändert die Beingröße eines Zufallswegs grundsätzlich nicht (Bein nach Bestätigung bei θ exponentiell mit
    Mittel θ, gleich welche Schwankung); er macht die Beine nur schneller.
  - Struktur auf der Bein-Skala erkannte der alte Test kaum (Drift-Regime 1 von 12, Rücklauf 0 von 12), der neue sicher (10/10 und
    9/10, nie falsche Richtung).
- Lange Lücken: Reihe beginnt danach. Das erste Extrem beginnt kein Bein. Regel-Eintrag `abstand` ausdrücklich. Nachzieh-Stop wie
  im Labor ab dem Schluss nach dem Einstieg.

**3. Gebaut:**
- `hl_zyklus.py` (neu): Daten nur lesend, Directional Change, Strategien und Surrogate als schnelle Rechnung über viele Pfade
  zugleich, Urteile A/B1/B2/C, Bericht „★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141)“ mit aktuellem Stand je Coin, Selbsttest.
- `hl_swing.py`: Art „dip“ (`dip_lage`, `einstieg`, `ausstieg_parameter`, `nachfuehren`), `rsi_wilder` und `Kennzahlen.rsi`, drei
  `STRATEGIEN`-Einträge, Live-Tafel-Text; die sechs bestehenden Einträge bitgleich; Probe „Dip-Regeln (U141) an der Schwelle“.
- `hl_labor.py`: drei neue Strategien in der Gruppe „Swing“ — `zyklus_dip@f3159c50`, `zyklus_dip_heiss@ae288bc8`,
  `zyklus_dip_zufall@254d952e`; 44 alte Kennungen unverändert (`SWING_KENNUNGEN_2361` neu im Test); Labor-Probe „Dip halten“ auf
  einem gebauten Dump (Einstieg 00:00–00:15 am Tag nach der Erholung, Stop = Kurs·e^{−(ln(Schluss/Tief)/σ+1)σ}, Größe nach Risiko,
  60 Tage, Nachzieh-Stop am nächsten Schluss gleich `hl_swing`, Z2 steigt gleich ein); Bericht „Swing (U140) und Zyklus (U141)“.
- `hl_viz.py`: Debug „★ Zyklen …“ und „Zyklen: Selbsttest“; Berichtsplan `u141-zyklen` 09.10. 12:00 (bis 12 h nachgeholt) und
  `u141-zyklen-2` 10.10. 07:45. `install.py` 36 Schritte, `version.py`, `update.py`.

**4. Proben:**
- `hl_zyklus.py --selbsttest`: 17 Prüfungen, rund 35 s in der Sandbox. Directional Change von Hand und gegen eine
  Schritt-für-Schritt-Referenz (40 Pfade); RSI (Wilder, = hl_makro, lückenfest) und σ (= hl_swing); Z1/Z2 an den Schwellen genau
  (hl_swing = schnelle Rechnung), Fenster, Gleichstand, Stop, Nachzieh-Stop, Zeit 60 T, Überhitzung, keine Wiederkehr am
  Ausstiegsschluss; **Gleichheit mit dem Labor Tag für Tag** (146 Trades auf drei Märkten: Einstiegstag, Ausstiegstag, Grund);
  Urteile von Hand; Bausteine (T200, Kosten, VOL, Sharpe-Test, Ereignis, OI-Perzentil, Surrogate, Z3-Ziel kausal, B1-Statistik);
  Identität (Surrogate mit Vorzeichen +1 = echte Kurse); Kausalität (bis Tag 900 bitgleich, auch Z3); Bericht mit fehlenden
  Reihen; Nulltests und Positivkontrollen.
- Nullreplikationen (Scratchpad): GARCH mit fairen Vorzeichen, 24 Universen × 4 Coins × 3.600 Tage: Teil A 0 von 72 p < 0,05,
  B1 0 von 72, B2 0 belegt; Teil C 80 weitere Universen: roh p < 0,05 je Signal 2,5–7,5 %, irgendein Beleg in 5 von 80
  (Soll ≤ 5 %, Intervall 2–14 %); B2 auf unabhängigen Renditen 0 von 40.
- Robustheit der Positivkontrollen (je 10): A Regime 10/10, Rücklauf 9/10; B1 10/10; C3 10/10; B2 (±0,6 %/T, 250 T) 12/12.
- Laufzeit mit echten Längen (synthetische Kurse): Teile A–C 30 s, Teil D 23 s in der Sandbox; auf dem Pi grob 2–3 min (Grenze
  des Berichtsplans 15 min).
- Mutationen (`mut141.py`, nicht im Paket): 37 von 37 rot (26 in `hl_zyklus`, 9 in den Dip-Regeln von `hl_swing`, 2 im Labor). Im
  ersten Durchgang blieben drei grün und bekamen eigene Proben: Z3-Ziel mit Blick in die Zukunft (jetzt Handprobe „Ziel erst ab dem
  Tag nach dem 10. Trade“), VOL ohne den Schritt 0,10 (jetzt ein Tag mit Änderung 0,048 ohne Umschichten), Hälften der Surrogate
  nach dem Hoch statt nach dem Tief (jetzt Identitätsprobe: Surrogate mit Vorzeichen +1 ergeben genau die echten Kurse, also
  müssen alle Null-Größen den echten gleichen).

**5. Labor „überall Minus“ — kein Rechenfehler.** Stand des Wochenberichts 07.10. 19:18: 3.580 Trades seit 27.09., netto
−72.792 USD, davon Gebühren 26.081. Vor Kosten liegt die Richtung nahe null (Pool-Probe: ≈ +0,02 % je Trade bei ≈ 0,12 % Kosten);
die Zufall-Kontrolle verliert wie vorgesehen (−3.821 USD, t −2,5); kein Signal schlägt den Zufall. „Familie Orderfluss“ (−22.735
USD, 290 Trades) ist der bekannte Ausführungsfall U96 (XMR-Markteinstiege bis 73 bp von der Mitte), Auswertung mit U99 am 11.10.
Die Swing- und Zyklus-Strategien haben noch kaum Trades; „—“ heißt „noch keine Daten“. Der Befund bestätigt die Vermutung des
Nutzers: Viele kurze Trades verlieren an den Kosten.

**6. Was der Bericht beantwortet und was nicht:**
- Wie groß und wie lang Rallyes und Rücksetzer je Coin bei 10/20/30 % waren (Median, Quartile), wie weit es ab der Bestätigung
  noch ging, und ob das mehr oder weniger ist als bei einem Zufallsweg mit derselben Drift und Schwankung.
- Ob „Dip halten“ das Timing verbessert (B1) und ob es — oder ein Trendfilter, eine Schwankungssteuerung — sicherer ist als HODL
  (B2), dazu Rückgänge, CAGR und Trades je Jahr.
- Ob Überhitzung, Funding-Druck, RSI ≥ 80 oder Gier Rücksetzer ankündigen — mehr als die Schwankung allein.
- Nicht: eine Kaufempfehlung. Der Stand-Abschnitt zeigt nur die Lage. HYPE (16 Monate) und Gold (3 Jahre) nur beschreibend.

**Was man wissen muss:**
- Ein Test der Beingröße ist blind für Schwung von Tag zu Tag — die Größe eines Beins legt beim Zufallsweg die Schwelle fest, nicht
  die Schwankung. Wer Zyklen testet, prüft deshalb Struktur auf der Bein-Skala und beschreibt die Dauer daneben.
- Bei Surrogat-Tests mit Holm muss die Zahl der Surrogate zur Zahl der Tests passen: mit 120 Surrogaten ist zweiseitig nach Holm
  über 12 nichts unter 0,05 zu bringen.
- Wer eine Regel zweimal rechnet (lange Studie schnell über viele Pfade, Labor Tag für Tag), prüft beide gegeneinander Tag für Tag.

## 3νν. Bewertung: Fear & Greed, Binance-Top-Trader und Market Maker, Hebel gegen Spot, Chart-Analyse-Trader (Nutzer 09.10. 02:05; nur Dokumente, Version 2026-09-23.62 unverändert, Opus 5.5)

Anlass: Der Nutzer fragt (09.10. 02:05), sinngemäß: (a) den Fear & Greed Index als weiteren Indikator aufnehmen; (b) gibt es
Schnittstellen zu den Daten und Aktionen der Binance-Top-Trader, dazu die Aktivität der Market Maker; (c) „Wenn es Leverage bei 95 %
gegenüber 5 % Spot ist, dann wird fast immer erfahrungsgemäß eine Liquidierung durchgeführt“ — lässt sich das mit Binance-Daten
prüfen; (d) eine vollwertige Chartanalyse wie bei TradingView, gestützt durch alle gesammelten Daten als untere Schicht — ein
virtueller algorithmischer Trader auf dieser Grundlage? Ausführlich mit Quellen im Projekt-Dokument
`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` (nicht im Paket).

**Kernaussage.** Der Zugang ist nicht das Problem: Fast alles wird schon gesammelt. Offen ist der Nachweis. Die bisherigen Tests
sagen: Die Daten des Systems beschreiben Größe und Risiko kommender Bewegungen (HAR-Schwankung, Kaskaden-Größe, Crowding), kaum
ihre Richtung (U130 0 von 45; Magnet nichts in 36 Tests; Anker nichts; Labor 07.10.: nichts schlägt den Zufall; Regime: Beine wie
beim Zufallsweg). Daraus folgt der Vorschlag für den Chart-Trader: **Der Chart gibt die Richtung, die Daten geben Größe, Stop und
„heute nicht“.**

**1. Fear & Greed (a).**
- Schon im System: `fng:wert` (alternative.me) seit 02/2018 in `makro.db`, im Makro-Chart und in der Zonenkarte; 30-Tage-Mittel am
  08.10. 67,3 (Perzentil 81,8 der eigenen Historie).
- Getestet: U130 Teil A (15 Merkmale gegen die BTC-Rendite über 1/7/30 Tage) auf dem Pi am 06.10. 0 von 45 belegt, Endurteil
  25.10.; U141 C4 (Gier ≥ 80 gegen einen Rücksetzer in 14 Tagen) im Lauf 09.10. 12:00.
- Bauart laut Anbieter: je 25 % Volatilität und Momentum/Volumen, dazu Social Media, BTC-Dominanz und Google Trends (Umfragen
  ausgesetzt). Der Index fasst also überwiegend den Kursverlauf zusammen, den das System ohnehin hat.
- Zyklus 2024–2026 (`RECHERCHE_Makro_Chart_05-10-2026.md`): am Hoch im Oktober 2025 nur 71; extreme Angst (5–9) im Februar 2026,
  rund vier Monate vor dem Tief.
- Folge: kein neuer Baustein; Urteil nach der U141-Auswertung.

**2. Binance-Top-Trader und Market Maker (b).**
- Offizielle Endpunkte: vier Verhältnisse (Top-Trader nach Positionswert, Top-Trader nach Konten, alle Konten, Taker Kauf/Verkauf).
  „Top-Trader“ heißt bei Binance: die 20 % Konten mit dem höchsten Margin-Guthaben — die Größten, nicht die Besten. Raster 5 min bis
  1 Tag, per REST nur die letzten 30 Tage. Die Doku nennt inzwischen einen API-Schlüssel; vom Pi liefen alle vier am 04.10. ohne
  (check_sources). Erzwingt Binance ihn, genügt ein kostenloser Lese-Schlüssel ohne Handelsrechte.
- Im System: alle vier in `bnc_metrics` (alle 5 min seit 14.09. über `hl_ext`; 277.773 Zeilen am 08.10.), Kacheln im Dashboard.
  In der Konfluenz (Binance- und Fusions-Modus) gibt „Top-Trader ≥ 1,5“ einen Kaufpunkt, „≤ 0,67“ einen Verkaufspunkt; „Konten ≥ 3“
  erscheint als Hinweis „Kaskadenrisiko nach unten“. Keine dieser Regeln wurde je einzeln geprüft.
- Historie: Die Tagesdateien „metrics“ von data.binance.vision (5-min-Zeilen) enthalten das OI und dieselben vier Verhältnisse
  (`count_toptrader_long_short_ratio`, `sum_toptrader_long_short_ratio`, `count_long_short_ratio`, `sum_taker_long_short_vol_ratio`).
  `hl_makro` lädt sie für BTC seit 01.09.2020 vollständig (2.229 Tage), behält aber nur das OI. Ab wann jede Spalte gefüllt ist,
  zeigt erst ein Lauf.
- Aktionen einzelner Trader: keine offizielle Schnittstelle. Die Web-Rangliste hat undokumentierte Endpunkte (Drittprojekte nutzen
  sie), zeigt nur freiwillig geteilte Positionen (Auswahlverzerrung) und kann jederzeit brechen. Nicht als Datengrundlage.
- Das Bessere liegt auf Hyperliquid: jede Adresse mit Orders, Fills und Positionen; Wale, Leaderboard, Elite, Darwin-Liste mit
  Könnenstest, Kopier- und Gegenstrategien im Labor. Stand 07.10.: nichts schlägt den Zufall (U99 am 11.10., Darwin ab etwa 14.10.,
  Schatten-Urteil 18.11.).
- Market Maker: auf Binance anonym, sichtbar sind nur Orderbuchtiefe und Wände (`bnc_book`, alle 5 min seit 14.09.) und der
  Taker-Fluss; auf Hyperliquid am Verhalten erkennbar (`hl_score`). Auf Hyperliquid verdienen Market Maker am Spread (rund
  +208 Mio. USD, März 2025 bis Juni 2026), Front-End-Trader verlieren (rund −1,11 Mrd.; Jia, Moallemi, Wang & Zeng 2026) — ihr
  Gewinn ist kein Richtungssignal. Prüfbar ist, ob sich die Buchtiefe vor großen Bewegungen ausdünnt (Größe, nicht Richtung).

**3. Hebel gegen Spot (c).**
- Lesart: Anteil des Derivatevolumens am Gesamtvolumen (95 zu 5). Die andere Lesart, OI im Verhältnis zu Spot oder
  Marktkapitalisierung, steht schon im Makro-Chart: OI ÷ Marktkap. 0,49 % am 07.10. (Perzentil 73,1); U141 C1 prüft die
  OI-Überhitzung.
- Messbar: Binance-Spot- und Futures-Kerzen enthalten Volumen und Taker-Kaufvolumen, per REST mit voller Historie (Spot seit 2017,
  Perpetuals seit 09/2019); beide Endpunkte laufen vom Pi. Spotvolumen sammelt das System heute nicht.
- Falle: BTC-Spot verteilt sich auf mehrere Paare (USDT, FDUSD, USDC, früher BUSD und TUSD). Null-Gebühren-Aktionen verschoben das
  Volumen sprunghaft; nach dem Ende im März 2023 brach Binances Spotvolumen ein (Kaiko, Bloomberg). Also alle Paare summieren, die
  Schwelle relativ prüfen (Perzentil der eigenen 90 Tage) und die 95 % des Nutzers zusätzlich so, wie formuliert.
- Forschung (`RECHERCHE_Regime_07-10-2026.md`): Hoher Carry, also teurer Hebel, kündigt künftige Crashs an (Schmeling, Schrimpf &
  Todorov 2023, BIS WP 1087). Für OI, Long/Short-Quoten und Liquidationsvolumen als Prädiktoren über 1–7 Tage fand die Recherche
  keine begutachtete, außerhalb der Stichprobe getestete Studie; sie folgert eine Rolle als Crowding- und Tail-Größe (mehr Risiko
  großer Rückschläge, kein verschobener Median). Die Beobachtung des Nutzers passt dazu, als Risiko und nicht als Richtung.
- „Fast immer“ heißt nichts ohne Basisrate: Liquidationswellen sind in Krypto häufig. Nur der Vergleich „nach dem Signal“ gegen
  „sonst“ zählt (relatives Risiko mit Intervall, Nullmodell). Genau so misst U141 Teil C.
- Ereignis „Liquidierung“: in der Historie ein Kursausschlag ≥ k σ mit gleichzeitigem OI-Abbau (Archiv, 5 min); vorwärts die echten
  Liquidationen (Hyperliquid vollständig, Bybit vollständig seit 14.09., der Binance-Stream untertreibt).
- Vorhaltefristen: `ext_liquidations` (Bybit, OKX) 90 Tage, `bnc_book` 60 Tage. Ab Mitte November gehen die ersten Tage verloren;
  wer sie für U142/U143 braucht, sichert sie vorher. `order_levels`, `bnc_metrics` und `bnc_liquidations` werden nicht gekürzt.

**4. Chart-Analyse-Trader (d).**
- Gibt es in erster Form: U140 S1–S4 sind klassische Chartregeln (Kanal-Ausbruch, Rücksetzer im Trend, Ausbruch nach Ruhe,
  Gegenbewegung nach Übertreibung) mit Stop, Nachzieh-Stop und Größe nach Risiko; dazu U141 Z1–Z3 „Dip halten“. Historie 2020–2026
  mit Kosten und Funding (08.10.): S3 +0,34 ± 0,17 R je Trade (Sharpe 0,72), S1 +0,17 ± 0,10 (0,49), S2 +0,04, S4 −0,20; nichts
  belegt. Alle laufen im Labor.
- Der Engpass ist die Statistik: Standardfehler der Sharpe-Ratio ≈ √((1 + SR²/2)/T); für SR 0,5 mit 2 Standardfehlern braucht ein
  Markt rund 18 Jahre. Ein Filter, der die Hälfte der Trades aussortiert, vergrößert den Standardfehler um √2, und jeder Filter ist
  ein weiterer Test. Breite (mehr Märkte, Entscheidung 4 in `KONZEPT_Swing.md`) hilft mehr als mehr Regeln.
- Literatur (`RECHERCHE_Regime_07-10-2026.md`): Einzelne Regeln überleben bei BTC die Data-Snooping-Korrektur kaum (Hudson &
  Urquhart 2021; Anghel 2021); vorab gebündelte Ensembles schneiden besser ab (Deprez & Frömmel 2024); Muster ändern Verteilungen
  ohne Gewinnnachweis (Lo, Mamaysky & Wang 2000); Unterstützung und Widerstand wirken, wo tatsächlich Orders liegen (Osler 2000,
  2001; Kavajecz 2004).
- Unser Vorteil: echte Orderniveaus. `order_levels` (Hyperliquid, alle 10 min): größte Kauf- und Verkaufswand, Take-Profits,
  Stop-Cluster; dazu die Binance-Wände in `bnc_book`. Die Linien im Live-Chart sind genau diese Niveaus. Geprüft sind bisher nur
  Anziehung (Magnet U110) und Richtung (Anker) der Liquidationscluster. Ob der Kurs an echten Wänden öfter abprallt als an
  Zufallsniveaus und nach dem Durchbruch von Stop-Clustern beschleunigt, ist offen.
- Vorschlag in drei Stufen (U143):
  1. „Chartbild“ je Coin, beschreibend, kein Signal: Trendlage (200-Tage-Linie, aktuelles Bein mit typischer Größe aus U141),
     nächste Niveaus aus Swings, Wänden und Clustern, RSI, Schwankung (HAR); daneben Funding, OI, Top-Trader, Fear & Greed.
  2. Niveau-Test, vorab festgelegt: Abprallen und Durchbruch an echten Niveaus gegen Zufallsniveaus gleichen Abstands.
  3. Chart-Trader als Labor-Familie: höchstens 3–4 vorab festgelegte Regeln; die Daten nur für Größe, Stop und „heute nicht“;
     Zufallskontrolle mit gleichen Ausstiegen; neue Kennungen; Historie, wo die Daten reichen. Echtgeld wie bisher nur nach Beleg
     und mindestens 6 Monaten Labor, nie automatisch.

**5. Plan (nur Dokumente).** U142 (Positionierung und Hebel, Studie) und U143 (Chart-Trader, Stufen 1–3) im UPDATE_PLAN
vorgemerkt. Bau erst nach der U141-Auswertung und mit Zustimmung des Nutzers. U142 ist eine eigene Studie (nur lesend, eigene
Datei), berührt Fusion, v3, Kaskaden und v1 nicht und ginge vor dem 25.10.

**Was man wissen muss:**
- Gesammelte Daten sind noch kein Signal: Zwei Punkte-Regeln mit den Binance-Top-Trader-Verhältnissen zählen seit Wochen in der
  Konfluenz, ohne je einzeln geprüft worden zu sein.
- Bei „fast immer“ zuerst nach der Basisrate fragen: Ein Signal zählt nur, wenn danach öfter etwas passiert als sonst.
- Mehr Filter machen einen Backtest schöner und den Nachweis schwerer.

## 3ξξ. Hebel-Studie gebaut: Binance-Positionierung und Perp-Anteil vor Liquidationswellen (U142; Nutzer 09.10. 02:48; Version 2026-09-23.63, Opus 5.5)

Anlass: Nach der Bewertung 3νν fragt der Nutzer um 02:48: „Warum machst du heute Nacht nichts?“ Antwort (02:50): Der Grund war
schwach. U142 hängt nicht am Ergebnis von U141, und Regeln vor dem U141-Ergebnis festzuschreiben ist sogar sauberer. Der Engpass ist
der Download des Binance-Archivs auf dem Pi, jeder Tag Warten verschiebt das erste Ergebnis um einen Tag. Gelesen als Auftrag,
U142 zu bauen; Fusion, v3, Kaskaden und v1 bleiben unberührt, `hl_zyklus.py` unverändert (der Lauf 09.10. 12:00 ist nicht berührt).

**1. Vorab festgelegt** (`KONZEPT_Hebel.md`, 09.10. gegen 03:00, vor jeder echten Zahl und vor dem U141-Ergebnis):
- Daten in eigener Datei `hebel.db`: Binance-Archiv „metrics“ (OI in Coins und USD, Top-Trader nach Konten und nach Positionen, alle
  Konten, Taker; gespeichert eine Zeile je Stunde) für BTC, ETH, ZEC, XMR, HYPE ab 01.09.2020; Tageskerzen von 21 Symbolen ab 2020
  (Kurs aller fünf; für BTC/ETH die Perps USDT/USDC/BUSD, COIN-M USD_PERP und Spot USDT/FDUSD/USDC/BUSD/TUSD); Sicherung der
  Bybit/OKX-Liquidationen und der Binance-Buchtiefe aus `hl_liq.db` (nur lesend), bevor deren Vorhaltefrist (90 bzw. 60 Tage) sie
  löscht.
- **H1** Konten ≥ 3 → Rücksetzer in 7 Tagen (Vorzeichen-Surrogate, nur Richtung). **H2** Top-Trader-Regel der Konfluenz (≥ 1,5 /
  ≤ 0,67) → Richtung des nächsten Tages (zweiseitig). **H3** Perp-Anteil ≥ 95 % und **H4** Perp-Anteil im obersten Zehntel der
  90 Tage → Liquidationswelle in 7 Tagen (Zeitverschiebung des Signals um 30–365 Tage). Holm über die prüfbaren, beide Hälften,
  Blockbootstrap; Urteil nur bei vollständig geladener Historie.
- Liquidationswelle: stündliches OI **in Coins** fällt um 1,5 × seine Schwankung × √7 (das USD-OI fiele schon durch den Kurs), und
  der Kurs schlägt um 1,5 σ × √7 aus (Hoch oder Tief).
- Zwei Nullmodelle mit Absicht: Vorzeichen-Surrogate behalten die Schwankung — richtig für Richtungsfragen, aber sie würden ein
  reines Risikosignal „wegrechnen“. Für „kommt eine Welle“ löst die Zeitverschiebung nur die Zuordnung Signal → Welle.

**2. Gebaut:**
- `hl_hebel.py` (rund 2.300 Zeilen): Lader (Archiv, Monats- und Tagesdateien, 404-Regeln, Netzpause, Sperre, Budget), Hebel-Takt im
  Dashboard (alle 5 min höchstens 4 min, 0,35 s Pause je Datei; aus mit `HL_HEBEL=0`), Sicherung, Tafel je Coin (Stand zum
  Tagesende aus der 00:00-Zeile, höchstens 2 h alt; kausal), Tests H1–H4 mit beschreibenden Varianten, Abgleich Archiv gegen
  `bnc_metrics` (prüft die Zuordnung der Archivspalten; meldet ms-Zeitstempel), Stand heute, Bericht; Selbsttest 51 Prüfungen, 19 s.
- `hl_viz.py`: Debug „★ Hebel: Positionierung und Hebel gegen Spot (U142)“, „Hebel: Historie laden“ (bis 10 min; geplante Berichte enden nach 15 min), „Hebel:
  Selbsttest“; Berichtsplan `u142-hebel` 10.10. 08:15 und `u142-hebel-2` 11.10. 08:15 (je erst laden, dann Studie); Takt-Start.
- `install.py` Schritt 37 „Hebel: Nulltest, Positivkontrollen H1–H4, Laden ohne Netz, Kausalität (hl_hebel)“; `version.py`
  23.63 mit `hl_hebel.py` in der Prüfsumme; `update.py` mit `hl_hebel.py`, `KONZEPT_Hebel.md` und
  `RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` (jetzt auch im Paket).
- Unverändert: Konfluenz (die drei Regeln mit Binance-Verhältnissen bleiben bis zum Urteil), Labor (keine neue Strategie),
  `hl_zyklus.py`, `hl_swing.py`, Prognose, Fusion, v3, Kaskaden, v1.

**3. Vor dem ersten echten Lauf präzisiert** (`KONZEPT_Hebel.md` 12.1, keine Regel der Urteile verschoben): prüfbar bei H2 ohne
„30 Tage ohne Signal“; RR an den Rändern (∞ bzw. NaN statt Division durch null, gefunden in der Positivkontrolle); Laden (frisch =
jüngste 2 Tage, Monatsdatei des Vormonats bis zum 7., Tagesdateien nur für noch gelistete Symbole); Stundenzeile ohne Mischung.

**4. Kalibrierung** (synthetische Märkte, `KONZEPT_Hebel.md` 12.2):
- Nullreplikationen H1–H4 (30 Universen): volle Bedingung einmal (3 %); Zeitverschiebung allein (120 Universen) 3–7 % je Test.
- Trend-Null (Schwankung und Perp-Anteil fallen gemeinsam über die Jahre): kein Scheinbefund (H3 2, H4 0 von 60).
- Trennschärfe: H4 bei RR ≈ 2 etwa jedes zweite Mal belegt, ab RR ≈ 3,6 immer; H1 bei RR ≈ 1,9 in 5 von 8; H2 bei 0,17 σ in 7 von 8.
  **Ein RR um 1,2–1,5 ist mit sechs Jahren und zwei Coins nicht nachweisbar** — „nicht belegt“ heißt dann „nicht nachweisbar“.
- Mutationen (`mut142.py`): 26 von 26 rot; fünf erst nach neuen Proben (H2 „dagegen“ als Positivkontrolle, sonst fiel ein
  einseitiger Test nicht auf; fehlende Datei von gestern wird später geholt; √h in der Schwelle; Signale genau an der Schwelle; die
  vertauschte Top-Trader-Regel).

**5. Für den Nutzer:** 23.63 einspielen — bitte **nach** dem U141-Lauf um 12:00 (nötig ist es nicht, `hl_zyklus` ist unverändert;
so bleibt das Bündel sauber). Danach lädt der Hebel-Takt das Archiv im Hintergrund (rund 2–3 h). Am 10.10. um 08:15 läuft der
Bericht „★ Hebel …“ — bitte hochladen. Ist die Historie bis dahin nicht vollständig, sagt er „vorläufig“; dann zählt der
11.10. 08:15.

**Was man wissen muss:**
- Für eine Risikofrage („kommt eine Welle“) braucht man ein anderes Nullmodell als für eine Richtungsfrage; Vorzeichen-Surrogate
  behalten die Schwankung und hätten das Signal des Nutzers von vornherein unsichtbar gemacht.
- Liquidationen misst man am OI in Coins; das USD-OI fällt schon, wenn nur der Kurs fällt.
- Eine Positivkontrolle nur in einer Richtung prüft einen zweiseitigen Test nicht: Erst „H2 dagegen“ machte die Mutation „einseitig“
  rot.
- Nicht gelistete Paare muss der Lader an der Monatsdatei davor erkennen, sonst kostet jedes alte Paar Dutzende Abrufe.

## 3οο. Zyklus-Studie, erster Lauf ausgewertet: nichts belegt (U141; Bericht 09.10. 12:00; nur Dokumente, Version 2026-09-23.63 unverändert, Opus 5.5)

Anlass: Der Nutzer lädt um 12:16 die Sammeldatei der letzten 24 h hoch und fragt, ob er 23.63 jetzt einspielen soll oder ob vorher
noch Anpassungen nötig sind. Der Pi lief auf 23.62. Ausgewertet ist der geplante Lauf von 12:00 (61 s); der Handlauf von 01:55
(Daten bis 07.10.) bleibt außen vor, wie vereinbart.

**1. Urteile (vorab, `KONZEPT_Zyklen.md` 8): nichts belegt.**
- Teil A: Rallyes und Rücksetzer bei 10/20/30 % wie ein Zufallsweg mit derselben Drift und Schwankung (p Holm 0,92/0,92/0,96).
- Teil B1: Z1–Z3 ohne Timing (Z1 −8,9 bp je Markttag gegen Zufall −2,3). B2: keine Strategie sicherer als HODL; T200 am nächsten
  (ΔSR +0,20, 90 %: −0,04 … +0,49, p Holm 0,53), Z1–Z3 klar schlechter (ΔSR −1,0 bis −1,4, Band ganz unter null).
- Teil C: kein Warnsignal belegt. OI-Überhitzung RR 1,60 (90 %: 1,05–2,36) gegen Zufall 1,06, p Holm 0,40 — Hinweis, nicht belegt.
  Gier ≥ 80 RR 0,37 und Funding-Druck RR 0,67: nach diesen Signalen kamen weniger Rücksetzer, nicht mehr.

**2. Beschreibend:** Median-Rallye BTC +25 % in 12 T (10 %), +63 % in 47 T (20 %), +80 % in 56 T (30 %); ab der Bestätigung im Median
noch etwa die Schwelle (BTC 10 %: +10 % in 8 T), wie die Zufallsgeometrie vorhersagt. „Dip halten“ lag bei BTC und ETH sogar unter
zufälligen Einstiegen mit denselben Ausstiegen (Sharpe 0,39 gegen 0,75 … 1,45 bzw. 0,20 gegen 0,67 … 1,32); mit Ausführung (Teil D)
Z1 +0,06 R gegen Placebo +0,20 R. T200 im Kern: Sharpe 1,47 gegen 1,27, Rückgang −71 % gegen −88 %, beide Hälften positiv.

**3. Folgen (vorab, `KONZEPT_Zyklen.md` 8 Regel 5 und 13):** HODL im Kern bleibt der Maßstab, Sicherheit über Größe und Streuung,
kein Timing-Werkzeug. Das Labor zeichnet Z1, Z2 und Z0 weiter auf (U99 am 11.10.). Ergebnis als `KONZEPT_Zyklen.md` 14.

**4. Swing-Zweittermin 07:30 (U140):** wie am Vorabend (S1 345 Trades +0,17 R, S3 206 Trades +0,34 R, Placebo p Holm 0,32), nichts
belegt; stabil mit einem Tag mehr.

**5. Antwort an den Nutzer:** 23.63 jetzt einspielen, keine Anpassung nötig. U142 ist vor diesem Ergebnis festgelegt worden und
bleibt unverändert (der Hinweis aus C1 ändert keine Regel). Die Doku-Stände dieses Abschnitts gehen mit dem nächsten Paket.

**Was man wissen muss:**
- Eine plausible Handelsidee kann schlechter sein als Zufall, nicht nur gleich gut: Erst die Kontrolle mit denselben Ausstiegen (Z0)
  zeigt das.
- „Gier“ und Funding-Druck markierten in dieser Historie laufende Trends, keine bevorstehenden Rücksetzer.

## 3ππ. Hebel-Studie, erster Lauf: H1 erfüllt, H2 nicht, H3/H4 ohne Daten wegen meines Ladefehlers — behoben, H1 beschreibend ergänzt (U142; Bericht 10.10. 08:16; Version 2026-09-23.64, Opus 5.5)

Anlass: Der Nutzer lädt um 12:58 die Sammeldatei der letzten 24 h hoch („Hier der neueste 24h audit report“). Der Pi läuft seit
09.10. abends auf 23.63. Darin: U141 zweiter Lauf (07:45), „Hebel: Historie laden“ (08:15, 12 s: „vollständig“) und die
Hebel-Studie (08:16, 9 s).

**1. U141 zweiter Lauf (ein Tag mehr Daten):** wie der erste — nichts belegt (T200 ΔSR +0,20, p Holm 0,52; OI-Überhitzung RR 1,60,
p Holm 0,39; Gier ≥ 80 RR 0,37). Nichts zu tun.

**2. U142 erster Lauf — nach den vorab festgelegten Regeln, vorläufig (`KONZEPT_Hebel.md` 13):**
- **H1 Konten ≥ 3 → Rücksetzer in 7 Tagen: Bedingung erfüllt.** RR 2,77 (90 %: 2,10–3,73), Quote 20,3 % nach dem Signal gegen
  7,4 % sonst, Null-Median 1,57, p 0,003, p Holm 0,006 (über zwei prüfbare), beide Hälften (3,55/1,58 und 2,56/1,54); 526 Signaltage
  in 61 Episoden; jeder Coin über 1 (BTC 4,63, ZEC 3,38, XMR 2,26, HYPE 2,21, ETH 1,97), jedes Jahr höher als ohne Signal; 3 und
  14 Tage ähnlich (RR 2,53 und 2,64). In rund 4 von 5 Fällen folgte **kein** solcher Rücksetzer.
- **H2 Top-Trader-Regel → Richtung des nächsten Tages: nicht belegt** (T −0,018 σ gegen Null +0,024, p 0,148). Die Regel steht fast
  immer auf „Kauf“ (BTC 540/0, ETH 875/0, HYPE 344/0, ZEC 465/3; nur XMR meist „Verkauf“) — der Konfluenz-Punkt ist nahezu konstant.
- **H3/H4 Perp-Anteil: ohne Daten** (Punkt 3).
- Beschreibend (p roh): Das Konten-Perzentil wirkte als Gegenrichtung (oberstes Zehntel +1, unterstes −1: T −0,092 σ über 1 Tag,
  p 0,002; Top-Trader nach Konten −0,100, p 0,002). Abgleich Archiv gegen Live richtig (Median-Abweichung ≤ 0,07 %), die
  Verhältnisse mit Versatz 300 s. Sicherung: 200.126 Liquidationen, 45.429 Buchzeilen; größter Tag 08.10. (Bybit 77,9, OKX 85,6 Mio
  USD).

**3. Mein Fehler: Ladestand „vollständig“ war falsch.** `hb_dateien` merkte Kerzendateien ohne Markt. Sechs Spotpaare heißen wie
ein USDⓈ-M-Perp (BTCUSDT, BTCUSDC, BTCBUSD und dieselben für ETH): Das Perp lud zuerst, das Spotpaar galt als „schon da“ und wurde
nie geholt. Ohne Spot-USDT kein Perp-Anteil → H3/H4 „ohne Daten“; der Ladestand zählte die Einträge des Perps mit → „vollständig“.
Der Selbsttest fand es nicht: Die Ladeprobe zählte nur Perp-Zeilen, die Ende-zu-Ende-Probe schrieb Kerzen am Lader vorbei direkt in
die Datenbank. H1/H2 berührt der Fehler nicht (nur metrics und Perp-Kerzen), formal sind nach Regel 5 aber alle Urteile vorläufig.
Mit H3/H4 steigt Holm auf vier Tests: H1 p Holm ≤ 0,012, die Bedingung hält, solange RR und Hälften halten.

**4. Nachträglich ergänzt, beschreibend (`KONZEPT_Hebel.md` 12.3), mit Lesart vorab:**
- H1 mit dem Konten-Stand 1 h früher (schließt den 5-min-Versatz der Archivzeile aus) und 24 h früher (Haltbarkeit).
- **H1 geschichtet nach der Rendite der 7 Tage davor** (Coin × 5 Klassen, Mantel-Haenszel, Null aus denselben Surrogaten). Grund:
  eine Lücke im vorab festgelegten Nullmodell, die ich beim Entwurf übersehen habe — Vorzeichen-Surrogate zerstören auch Momentum.
  Ein Konten-Stand, der nur die Vorwoche spiegelt, besteht H1: auf synthetischen Märkten roh 30 von 30 „signifikant“, geschichtet 0
  von 30; ein echter Konten-Effekt bleibt (30 von 30). Bleibt der geschichtete RR über der Null, trägt der Konten-Stand Information;
  fällt er auf die Null, ist H1 vermutlich ein Spiegel der Vorwoche — beides als Vorschlag zum Hinweistext, Entscheidung beim Nutzer.

**5. Paket 23.64:** `hl_hebel.py` (Schlüssel „markt:symbol“, einmalige Umstellung in `verbinden()` mit dem Markt des ersten
gleichnamigen Symbols und `k_fertig = 0`, `bedarf()` erkennt sie; der Ladestand prüft die Buchführung gegen die Zeilen
(„Widerspruch“); die Ende-zu-Ende-Probe lädt Kerzen über den Lader; Ergänzungen aus 4; Selbsttest 63 Prüfungen statt 51; Mutationen
37 von 37 rot, `mut142b.py`); `hl_swing.py` nur Text („1 Trade“ statt „1 Trades“). H1–H4 und alle bisherigen beschreibenden Zeilen
rechnen unverändert (identische Ergebnisse 23.63/23.64 auf fünf synthetischen Märkten). Fusion, v3, Kaskaden, v1-Lernen,
Konfluenz, Labor und Prognose unberührt.

**6. Nach dem Einspielen:** Der Takt startet 90 s nach dem Dashboard, stellt `hebel.db` um und lädt die Spotpaare nach (rund 490
Monats- und 40 Tagesdateien, 10–20 min). Endgültiges Urteil mit H3/H4 und der Schichtung: geplanter Lauf `u142-hebel-2` am
11.10. 08:15 (bitte hochladen). Danach entscheidet der Nutzer über den Top-Trader-Punkt der Konfluenz (Vorschlag nach Regel 8:
entfernen) und den Text des Hinweises „Kaskadenrisiko nach unten“.

**Was man wissen muss:**
- Eine Probe, die am Lader vorbei in die Datenbank schreibt, prüft den Lader nicht. „Vollständig“ muss aus den Zeilen kommen, die
  die Studie liest, nicht aus der Buchführung des Laders.
- Vorzeichen-Surrogate prüfen „Richtung bei gleicher Schwankung“, nicht „mehr als Momentum“. Ein Signal, das den Kursverlauf der
  Vorwoche spiegelt, besteht sie — die Schichtung trennt das.

## 3ρρ. Chartbild (U143 Stufe 1): die Lage je Coin in Worten und im Bild — eine Anzeige, kein Signal (Version 2026-09-23.65, Opus 5.5)

Anlass: Der Nutzer fragt am 10.10. um 22:16 „Wo finde ich die Chart Analysen“. Antwort: Es gibt noch keine, U143 war nur geplant;
vorhanden sind Live-Chart, Makro-Charts, Debug-Berichte der Studien. Auf die Frage, ob Stufe 1 als Paket 23.65 gebaut werden soll,
um 22:20 „Ja“. Gebaut über Nacht; **einspielen erst nach dem U142-Lauf am 11.10. 08:15 (ab 08:20)**, damit der Lauf ungestört bleibt.

**1. Was es ist (`KONZEPT_Chartbild.md`):** neuer Abschnitt „CB Chartbild“ direkt nach dem Live-Chart, für den Coin aus dem Kopf der
Seite. Oben eine **Lesart in fünf bis sechs Sätzen** (Trend, Bein, nächste Niveaus, erwartete Spanne, Lage daneben, „Lagebeschreibung,
kein Signal.“), darunter ein **Tageschart** (abgeschlossene Tageskerzen auf log. Skala, 50-/200-Tage-Linie, Bein als Zickzack mit
Bestätigungsschwelle der Gegenrichtung, Swing-Hochs/-Tiefs; rechts der Linie „heute“ die Niveaus als Momentaufnahme mit Nummer und
das 80-%-Band für den Schluss heute und in 7 Tagen; RSI 14 im eigenen Feld), dann **Tabellen** (Niveaus mit Abstand in % und σ, Bein
je Schwelle, Spanne mit Trefferquote der letzten 365 Tage, Lage daneben mit 90-Tage-Verlauf, Prüfstände, Was fehlt). Jede Zeile nennt
ihren **Prüfstand** (U141, U142, U110, P0.2 oder „ungeprüft, Stufe 2“) mit Datum. Keine Punkte, keine Richtung.

**2. Woher die Zahlen kommen — dieselben Rechnungen wie die Studien, nur lesend:** Bein mit `hl_zyklus` (dc_batch, beine,
zyklen_beschreiben, _dc_stand; 10/20/30 %, PAXG 3/5/10 %), Band mit dem HAR von P0.2 (am Vortag eines Bewertungsmonats bitgleich zu
`hl_regime.har_prognosen`), Funding-Druck wie U141 C2, Perzentile aus den Tagesständen wie U142 (live aus `bnc_metrics`), Niveaus der
Großkonten und Liquidationscluster mit denselben Funktionen wie der Live-Chart (`load_stops`, `load_depth`). Quellen `hl_liq.db`,
`swing.db`, `regime.db` (PAXG), `hebel.db`, `makro.db`; jede mit Frischegrenze, sonst „—“ mit Grund. Wirkt auf nichts: kein Treiber,
keine Konfluenz, kein Labor, keine Prognose; Fusion, v3, Kaskaden, v1-Lernen, Konfluenz unberührt (Zusage bis 25.10.).

**3. Beim Bau gegenüber der ersten Fassung geändert (`KONZEPT_Chartbild.md` 9.1, je mit Grund):** runde Zahlen im 1/2/5-Schritt der
zweiten Stelle (die erste Regel sprang an Zehnerpotenzen und gab XMR 16 % Schritt); Swings die zwei nächsten je Seite und höchstens
±30 %; das nächste Stop-Cluster (ohne Mindestgröße) nicht in der Lesart; PAXG ohne Fear & Greed, Funding und Positionierung als
„bewusst nicht gezeigt“; Trefferquote erst ab 90 Prognosetagen; Band-Kontrolle über acht Märkte (ein Markt wäre an der Grenze ein
Münzwurf); Kerzen neutral mit Form statt Grün/Rot (Prüfskript: ΔE 3,0 für Rot-Grün-Fehlsichtige); Zeitraum „1 M“; weit entfernte
MA-Linien bestimmen den y-Bereich nicht mehr.

**4. Geprüft:** Selbsttest `hl_chartbild.py --selbsttest` 42 Prüfungen in rund 5 s (Bausteine von Hand, Tageskerzen mit Lücken,
Niveaus, gleich der Studien, Kausalität, Band-Kontrolle, Lesart ohne Empfehlungswörter, Frische, Live-Teil je Teil für sich, Ende zu
Ende über `hl_viz`); Mutationen 51 von 51 rot (`mut143.py`, vier davon an `hl_viz.chartbild_live`; eine erst nach einer neuen Probe:
das Anheben eines Hochs unter dem Schluss). Die Probe „Live-Teil je Teil für sich“ fand kurz vor der Lieferung, dass ein Fehler der
Heatmap-Abfrage auch den Kurs mitgenommen hätte -- jetzt liest `chartbild_live` Kurs, Heatmap und Orders getrennt. Browserprobe
in der Sandbox: das SVG gegen die Nutzlast, gemessen an der beschrifteten Achse, vier Szenarien Desktop und Handy, 13 von 13
Skript-Mutationen rot. Vier waren zuerst grün: die um einen Tag verschobene Zeitachse und Swings am Folgetag bis zu neuen Prüfungen
(erste Kerze gegen den Bildrand, Swing an Tag und Preis), die falsche Kurslinie bis zur Vorbedingung „Kurs live“ (die Demo war älter
als 15 min, das Bild zeigte den Ersatz), und „Zickzack mit dem Schluss statt dem Extrem“ war gleichwertig (das Bein läuft auf
Schlusskursen) und wurde durch „ohne den letzten Punkt“ ersetzt. `node --check` aller
Skripte, Namensprüfung, Bildschirmfotos 1.280 und 390 px ohne Seitenüberlauf. `install.py --selftest-isoliert`: 38 Schritte (neu
„Chartbild: Bausteine, gleich der Studien, Kausalität, Band-Kontrolle (hl_chartbild)“) und 11 Dashboard-Abrufe (neu `/chartbild`,
`/chartbild.js`).

**5. Nebenbei gefunden:** Die Seite war am Desktop 1.881 px breit statt 1.280 -- die Auswahl der Debug-Läufe wuchs mit der längsten
Beschreibung (gemessen an 23.64; seit welchem Paket, nicht nachgeprüft). Jetzt höchstens 760 px breit.

**6. Nach dem Einspielen (ab 08:20):** Abschnitt „CB Chartbild“ aufklappen (Navigation „Chartbild“) und einmal Debug „★ Chartbild:
Lage aller Coins als Text“ laufen lassen und hochladen -- erster Blick auf echte Daten: Rechenzeit auf dem Pi, welche Quellen fehlen
oder zu alt sind, ob die Niveaus plausibel liegen. Kein geplanter Lauf im Berichtsplan (Entscheidung 3 beim Nutzer).

**7. Entscheidungen beim Nutzer (`KONZEPT_Chartbild.md` 8):** (1) nach dem U142-Urteil, ob der Prüfstand „Konten ≥ 3“ die gemessenen
Quoten nennt; (2) Stufe 2 (Niveau-Test, vorab festgelegt) als nächster Schritt, Vorschlag nach dem 25.10.; (3) Chartbild als Bericht
im Berichtsplan.

**Was man wissen muss:**
- Die Prüfstände stehen fest im Modul (`PRUEFSTAND`, Stand 10.10.2026) und werden mit dem nächsten Paket nachgezogen -- nach dem
  U142-Lauf vom 11.10. mindestens „konten“ und „top_pos“. Die Anzeige liest keine Berichte aus.
- Eine Browserprobe prüft ihre Vorbedingung: Ohne frischen Kurs zeigte das Bild den Ersatz „letzter Tagesschluss“, und eine falsche
  Kurslinie fiel nicht auf. Relative Lagen sehen eine verschobene Zeitachse nicht -- erst der Bezug zum Rand des Bilds.
- Rot/Grün trennt für Rot-Grün-Fehlsichtige nicht; im Chartbild trägt die Form (hohl/gefüllt) die Richtung der Kerze.

## 3σσ. Hebel-Studie endgültig: H1 belegt, H2 nicht, H3 nicht prüfbar, H4 nicht belegt (U142; Lauf 11.10. 08:16; nur Dokumente, Version 2026-09-23.65 unverändert, Opus 5.5)

Anlass: Der Nutzer lädt um 09:54 die Sammeldatei 08:25 hoch (zwei Berichte: „Hebel: Historie laden“ 08:15 und die Hebel-Studie
08:16). Einzelheiten in `KONZEPT_Hebel.md` 13.5.

**1. Welche Version lief:** Der Kopf der Sammeldatei nennt „Version 2026-09-23.64 · a897c8e3c5“ -- das ist die Prüfsumme von 23.64,
gerechnet aus den Dateien auf der Platte im Augenblick des Herunterladens (08:25). Der Nutzer hatte um 03:10 geschrieben, 23.65
laufe schon. Beides passt nicht zusammen; wahrscheinlich ist 23.65 nicht eingespielt (zum Beispiel nahm das Update ein älteres
Archiv aus „Downloads“ -- es nimmt das jüngste `hl_liq_project*.zip`). Für U142 ohne Folge: Der Lauf brauchte 23.64 (Ladefehler
behoben), und mit 23.64 lief er. Bitte die Versionskachel prüfen und 23.65 einspielen.

**2. U142 endgültig (vorab festgelegte Regeln, Historie vollständig):**
- **H1 belegt:** Konten ≥ 3 → Rücksetzer in 7 Tagen in 20,3 % gegen 7,3 % (RR 2,77, 90 %: 2,12–3,71; Null 1,59; p Holm 0,012 über
  drei prüfbare; beide Hälften). In 4 von 5 Fällen folgte **kein** solcher Rücksetzer. Die vorab gelesene Schichtung nach der Vorwoche
  hält (Mantel-Haenszel-RR 2,52 gegen Null 1,56, p 0,012; in allen fünf Klassen über 2): Der Konten-Stand sagt mehr als der Kursverlauf
  der Vorwoche. Stand 1 h bzw. 24 h früher: RR 2,68 bzw. 2,64.
- **H2 nicht belegt:** Top-Trader-Regel der Konfluenz und Richtung des nächsten Tages, p Holm 0,376; die Regel steht fast immer auf
  „Kauf“ (außer XMR).
- **H3 nicht prüfbar:** Der Perp-Anteil am Binance-Volumen lag bei BTC und ETH seit 2020 an keinem Tag bei 95 % (90-%-Quantil eines Jahres höchstens
  91,0 % bzw. 93,8 %, beide 2026). Die 95-%-Regel ist mit dieser Abgrenzung nie eingetreten.
- **H4 nicht belegt, eher das Gegenteil:** Nach einem Perp-Anteil im obersten Zehntel kam eine Liquidationswelle seltener (2,9 % gegen
  5,5 %, RR 0,53; Mantel-Haenszel über die Schwankungsdrittel 0,57).

**3. Folgen (vorab, `KONZEPT_Hebel.md` 8) -- Entscheidung beim Nutzer:** (a) Hinweis „Kaskadenrisiko nach unten“ mit den gemessenen
Quoten versehen (Vorschlag nach 12.3 Punkt 3); (b) Top-Trader-Punkt der Konfluenz entfernen (Vorschlag); (c) keine Warnkachel für den
Perp-Anteil; (d) U144 Breitentest auf weiteren Binance-Perps; (e) ob die 95 % aus einer anderen Kennzahl stammen (dann neuer Test).
Bis zur Entscheidung bleiben Konfluenz und Hinweis unverändert (Zusage). Mit dem nächsten Paket: Prüfstände „konten“ und „top_pos“
im Chartbild auf dieses Urteil.

**Was man wissen muss:**
- Der Kopf der Sammeldatei zeigt, welche Dateien beim Herunterladen auf dem Pi lagen -- vor jeder Auswertung lesen (A1).
- Eine Regel, deren Bedingung nie eintritt, ist weder bestätigt noch widerlegt: H3 sagt nur, dass „95 % Perp-Anteil“ bei Binance
  seit 2020 nicht vorkam.

## 3ττ. Dashboard-Update auf 23.65 hängt: die Datenbank-Sicherungen von update.py und Recorder kollidieren (U145; 11.10. mittags; nur Dokumente, Version 2026-09-23.65 unverändert, Opus 5.5)

Anlass: Nutzer 12:45 (Bildschirmfoto): Der Update-Knopf steht auf „Update läuft …“, der Pi zeigt weiter „2026-09-23.64 ·
a897c8e3c5“. 12:54: Kachel „Letztes Backup fehlgeschlagen“. 13:09: Der Audit läuft nach 161 s noch. 13:11: keine Tastatur und kein
Monitor am Pi -- der Weg muss ohne Terminal gehen.

**1. Befund (Debug-Läufe 12:51–13:02):**
- Update-Log nur „[12:35:33] Archiv geladen (1705 kB), starte update.py …“ (1.705 kB = 23.65; 23.64 hatte 1.647 kB). update.py
  schreibt gepuffert, das Log füllt sich erst beim Ende.
- RAM je Prozess 12:51: alle fünf Dienste seit 22,4 h (10.10. 14:27) unverändert, dazu ein Python-Prozess seit ~0,3 h (PID 906091,
  36 MB) -- die Sicherung `hl_recorder.py --backup`, die update.py in Schritt 2 startet. Das Dashboard war bis 13:09 erreichbar; in
  Schritt 4 stoppt update.py auch `hl-dashboard` → Schritt 4 nicht erreicht, **nichts verändert**.
- Datenbank ~14 GB (13,74 GB am 08.10.), Ziel der Sicherung die SD-Karte (`…/hl_liq_project/dbbackup`, 49 GB frei): Kopie plus
  `integrity_check` geschätzt 15–30 min, wenn sie allein läuft.
- „fehlgeschlagen“ stand schon um 12:54 da, als die Sicherung von update.py noch lief → der Fehlschlag kam von einer Sicherung des
  Recorders. Welche Variante, zeigt der Fehlertext (Netzwerkstatus → Zeitplan → Zeile „Backup“, Spalte „Ergebnis“) -- angefordert.

**2. Ursache (eigener Konstruktionsfehler):** update.py sichert selbst, wenn die letzte gute Sicherung älter als 24 h ist oder
fehlschlug -- genau dann ist auch der Recorder fällig, nach einem Fehlschlag sogar alle 30 min. Beide schreiben ohne Sperre in
dieselbe Zwischendatei `hl_liq_backup.db.tmp`: `clean_tmp()` der zweiten löscht die Datei der ersten (die erste schreibt in eine Datei
ohne Namen weiter), `os.replace` der zuerst fertigen nimmt die halbe Datei der anderen als neueste Sicherung. Ausgänge: Die später
fertige scheitert beim Umbenennen, oder -- wenn update.py danach den Recorder stoppt -- die neueste Sicherung ist unvollständig,
obwohl `backup.json` „ok“ meldet. Nach meiner Durchsicht der Abläufe bleibt immer mindestens eine ältere vollständige Generation
liegen (drei Generationen). Dazu: Die Spalte „nächste in“ des Zeitplans zeigt nach einem Fehlschlag 24 h, der Recorder versucht es
aber nach 30 min; der Update-Knopf lädt beim zweiten Klick das Archiv neu und leert das Log, **bevor** er „Ein Update läuft noch“
meldet, und zeigt nach dem Neuladen der Seite den laufenden Stand nicht; Debug „Logdatei hl-recorder“ zeigt eine veraltete Datei
im Projektordner (`systemctl show -p StandardOutput` liefert nur „append“, die echte liegt unter `…/hl_liq/logs/recorder.log`);
„RAM je Prozess“ kürzt die Kommandozeile vor dem Skriptnamen; README behauptete „Log live“.

**3. Weg ohne Terminal (dem Nutzer gegeben, ~13:20):** nichts drücken, bis das Update endet (Knopf „Update fertig“ bzw. „Update mit
Fehler beendet“, oder Debug „Update-Log“ mit mehr als einer Zeile; geschätzt bis ~14 Uhr). Fall „Fertig.“: einmal System →
Speicherorte → „Jetzt sichern“ (sauberer neuester Stand); zeigt die Kachel „fehlgeschlagen“, sichert der neu gestartete Recorder nach
5 min von selbst. Fall „Abbruch — Update ohne gültiges Backup nicht ausgeführt“: „Jetzt sichern“, warten, bis die Kachel eine Uhrzeit
zeigt, dann einmal Update -- update.py liest dieselbe `backup.json` (Ordner aus der Recorder-Unit) und überspringt bei guter Sicherung
jünger als 24 h seine eigene. Nicht: zweiter Update-Klick, „Letztes Backup wiederherstellen“ (spielt Code aus `updates/vor_*`
zurück, nicht die Datenbank), schwere Debug-Läufe (Debug-Läufe enden nach 600 s). Scheitert auch eine Sicherung in Ruhe, ist es
nicht die Kollision: Fehlertext und Kachel „Datenbank“ entscheiden.

**4. Für 23.66 (U145):** Sperre in `do_backup` (eine Sicherung zur Zeit, Zwischendatei je Prozess); update.py wartet auf eine
laufende Sicherung bzw. überlässt sie dem Recorder, liest dessen echten Ordner (meta, `speicherorte.json`) und schreibt zeilenweise;
Update-Knopf prüft zuerst, ob ein Update läuft, und zeigt nach dem Neuladen den Stand; „nächste in“ nach Fehlschlag 30 min;
Debug-Logdatei aus `systemctl cat`; „RAM je Prozess“ mit Skriptnamen. Die Fixes wirken erst nach dem Einspielen -- für dieses Update
bleibt der Weg aus 3.

**5. Nachtrag 13:42 -- Fehlertext und Nachstellung:** Zeitplan-Zeile des Nutzers: „Backup · Hyperliquid · zuletzt vor 58 min ·
Dauer 502,9 s · nächste in 23,0 h · Fehler: disk I/O error“. Die Recorder-Sicherung lief also etwa 12:35:40–12:44, begann Sekunden
nach der von update.py (12:35:35) und scheiterte nach 8,4 min („nächste in 23,0 h“ ist der bekannte Anzeigefehler, der nächste
Versuch kam nach 30 min). **Nachgestellt in der Sandbox** (Skript `kollision.py` im Notizordner dieser Sitzung, nicht im Paket -- der Aufbau steht hier,
mit 23.66 kommt es als Probe ins Paket: `do_backup` unverändert aus 23.65 in zwei bis drei Prozessen, gleicher Ordner mit drei markierten alten Generationen, Quelle 657 MB
im WAL-Modus, SQLite 3.45.1; der Pi hat 3.40.1, gleiches Verhalten erwartet, nicht geprüft):
- Kontrolle (eine Sicherung allein): ok, Rotation richtig (F0 → .1, F1 → .2).
- **10 von 10 Läufen mit Überlappung** (Versatz 0,05–0,9 s, langsame Prüfung, dritte Sicherung): Die Kopie, die als zweite fertig
  wird, scheitert beim Abschluss mit genau **„disk I/O error“** -- die erste hat beim Abschluss die Journaldatei gleichen Namens
  gelöscht, SQLite meldet das fehlende Journal als I/O-Fehler.
- Die erste scheitert danach ebenfalls: beim Umbenennen („No such file or directory“, 6 Läufe; danach fehlt `hl_liq_backup.db`,
  .1 und .2 bleiben), in der Prüfung („disk I/O error“, 2), mit einem nicht abgefangenen JSON-Fehler (1: `backup.json` wird nicht
  atomar geschrieben und in `do_backup` beim Lesen nur `OSError` abgefangen), oder -- beginnt eine dritte Sicherung während ihrer
  Prüfung, wie die 30-min-Wiederholung des Recorders -- weil sie deren Journal als „heißes Journal“ in die eigene Kopie
  zurückspielt (Kopie leer, „no such table: bars“; erst die Zählung der bars fing es ab, `integrity_check` meldete „ok“) (1).
- Läuft eine Sicherung danach allein, gelingt sie. In keinem Lauf landete eine beschädigte Datei als neueste unter „ok“, ältere
  Generationen blieben bis auf die gewöhnliche Rotation unberührt.

Folgerung: Der Fehlertext erklärt sich vollständig ohne Hardwarefehler. Die Sicherung des Updates scheitert sehr wahrscheinlich
ebenfalls → „Abbruch“, nichts verändert, danach Weg aus 3 (Fall B). Prüfstein bleibt die nächste Sicherung in Ruhe: Scheitert sie
wieder mit „disk I/O error“, ist es die Hardware -- dann einmal ein Terminal (SSH): Kernel-Protokoll, Update mit `--no-db-backup`.
Dauer: Die Prüfung der 14-GB-Kopie auf der SD-Karte ist der lange Teil (ein altes Recorder-Log zeigt eine Sicherung, die nach 40 min
noch lief) -- meine Schätzung „bis etwa 14 Uhr“ war zu knapp. Für 23.66 zusätzlich: `backup.json` atomar schreiben (Zwischendatei
plus `os.replace`) und beim Lesen `ValueError` abfangen; Zwischen- und Journaldateien je Prozess eindeutig. Die Nachstellung wird
die Probe für U145, mit der Fassung ohne Sperre als Positivkontrolle (sie muss scheitern).
**14:03:** Kachel „Letztes Backup 11.10. 13:26“ grün, „Datenbank OK“, Datenbank 15,0 GB -- die Wiederholung des Recorders ab 13:26
lief allein durch: Prüfstein bestanden, kein Hinweis auf Hardware. Version weiter 23.64. Das Update startet nicht von selbst neu:
Nutzer prüft das Update-Log; endet es mit „Abbruch“, einmal Update drücken (Sicherung jünger als 24 h → update.py überspringt
seine eigene). Läuft das alte noch, nicht drücken -- sein Ende würde nach der Nachstellung die Kachel wieder auf „fehlgeschlagen“
setzen (Rotation, dann Umbenennen ins Leere), dann erst die nächste Recorder-Sicherung abwarten.
**14:07 Update-Log:** Archiv 1.706 kB (23.65), 76 Projektdateien; Schritt 2 „[FEHLER] Backup FEHLGESCHLAGEN: [Errno 2] No such file or
directory: '…/dbbackup/hl_liq_backup.db.tmp' -> '…/dbbackup/hl_liq_backup.db'“, „Abbruch — Update ohne gültiges Backup nicht
ausgeführt.“ -- genau der häufigste Ausgang der Nachstellung (E1); nichts verändert. Ob das Ende vor oder nach der Sicherung 13:26
lag, zeigt nur die Kachel: Uhrzeit → einmal Update; „fehlgeschlagen“ → „Jetzt sichern“, Uhrzeit abwarten, dann Update.
**14:10: 23.65 läuft auf dem Pi** („2026-09-23.65 · e7eb48c004“, A1 ✓; Nutzer: „Hat sofort problemlos geklappt“) -- die Kachel
zeigte eine Uhrzeit, update.py übersprang seine Sicherung. Damit erledigt sich auch der Hinweis aus 3σσ Punkt 1. Nächster Schritt:
Debug „★ Chartbild: Lage aller Coins als Text“ (erster Blick auf echte Daten).

**Was man wissen muss:**
- Ein laufendes Dashboard-Update ist bis Schritt 4 gefahrlos abzuwarten: Bis dahin ist nichts verändert und das Dashboard bleibt
  erreichbar. Ist es 1–2 min weg, starten die Dienste neu.
- „Letztes Backup wiederherstellen“ im Bereich Aktualisierung betrifft den Code, nicht die Datenbank.
- Den Fehlertext einer Sicherung gibt es ohne Maus und ohne Audit im Zeitplan (Netzwerkstatus), Zeile „Backup“.

## 3υυ. Chartbild: erster Lauf auf echten Daten -- stimmig, fünf Nacharbeiten (U143; 11.10. 14:58; nur Dokumente, Version 2026-09-23.65 unverändert, Opus 5.5)

Anlass: Der Nutzer lädt um 14:59 Debug „★ Chartbild: Lage aller Coins als Text“ hoch (14:58, 12,5 s). Einzelheiten und Zahlen
in `KONZEPT_Chartbild.md` 9.2.

**1. Stimmig:** Alle sechs Coins mit Kurs aus der 1-min-Kerze, Trend, Bein, Niveaus und Lage daneben, je Coin 200–458 ms. Von Hand
nachgerechnet: Abstand zur 200-Tage-Linie, Bein-Größen und Bestätigungsschwellen (10 %, PAXG 3 %), Abstände in %, σ-Spalte
(= ln-Abstand ÷ Tages-σ, darum −27,8 % = −25,0 σ bei BTC), Band (leicht schief, 7 Tage breiter als √7 × 1 Tag), Trefferquoten wie
P0.2.

**2. Eigene Fehler, für 23.66:**
1. **PAXG ohne Band:** `regime.db` wird nur vom Debug-Lauf „Regime: Historie laden bzw. ergänzen“ gefüllt (zuletzt Berichtsplan 08.10.
   21:00). Beim Bau übersehen, weil die Probe eine frische synthetische Datei hatte. Bis dahin hilft der Debug-Lauf von Hand.
2. **Satz „keiner dieser Werte hat in U141/U142 ein Timing belegt“ falsch** seit dem endgültigen U142-Lauf (H1 belegt). Das betrifft
   den Satz „Daneben“, den Hinweis unter „Lage daneben“ im Dashboard, den Modulkopf und `PRUEFSTAND` „konten“/„top_pos“. README und
   `KONZEPT_Chartbild.md` 0 und 3.6 sind schon berichtigt. ETH stand bei Konten 2,95.
3. **Winzige Cluster als „größtes Cluster“** (XMR 16 USD, PAXG 317 USD) → Mindestgröße.
4. **„bis zum Hoch 86.579“** ist der höchste Tagesschluss, die Swing-Hochs sind Kerzenhochs → „höchster Schluss“.
5. „-0,0 σ“ → „0,0 σ“.

**3. Kein Fehler:** HYPE „Verkaufswand“ und „Buy-Stops“ beide bei 97,93: dasselbe 0,25-%-Raster für alle Order-Arten, ohne
Randkappung, knapp über dem Hoch vom 22.09. (Schluss 97,21).

**Was man wissen muss:**
- Ein Prüfstand im Modul altert mit jeder Auswertung. Wird ein Urteil endgültig, sind alle Sätze mit „kein … belegt“ zu
  durchsuchen, nicht nur `PRUEFSTAND` -- hier an vier Stellen (zwei Module, README, Konzept).
- Jede Quelle des Chartbilds braucht einen Nachlade-Takt. Eine Datei, die nur ein Studienlauf füllt, altert still.

## 3φφ. Ausblick 4 Wochen (U146): vorab festgelegt -- Breite, Form, geprüfte Richtung, Ziellevels mit Wahrscheinlichkeit (11.10. 17:00; nur Dokumente, Version 2026-09-23.65 unverändert, Opus 5.5)

**Anlass:**
- Der Nutzer wünscht um 16:42 ein Extrapolationschart über 4 Wochen: alle signifikanten Daten korreliert und gewichtet,
  Gewichte geprüft, die Ziellevels für 1, 2 und 4 Wochen mit Preis und Wahrscheinlichkeit.
- Vorab dem Nutzer gesagt:
  - Die Spannweite ist gut vorhersagbar, die Richtung kaum.
  - Ein Test auf ungesehenen Daten entscheidet über jedes Gewicht.
  - Hyperliquid-Daten sind für 4-Wochen-Gewichte zu jung.
- Seine Wahl um 16:50: „Konzept heute, alles in 23.66“ — Ausblick, U145 und Chartbild-Nacharbeiten in einem Paket.

**Festgelegt in `KONZEPT_Ausblick.md`, bevor irgendein Teil auf echten Daten gerechnet wurde:**
- **Breite:** HAR-log je Horizont (h = 1/7/14/28) wie P0.2; dazwischen log-linear interpoliert.
- **Form:**
  - Echte 28-Tage-Pfade (Schluss, Tageshoch, Tagestief) aus der eigenen Historie ab 2020; HYPE gepoolt, solange unter 730 Tagen.
  - Je Tag k auf die damalige HAR-Prognose normiert, auf die heutige zurückskaliert, der mittlere Trend abgezogen.
  - Spannen und Erreich-Wahrscheinlichkeiten als Anteile über alle Pfade — genau, ohne Zufallsziehung.
  - Ein zu schmales HAR (ZEC/XMR/PAXG in P0.2) gleicht die Normierung von selbst aus.
- **Richtung:**
  - 31 Kandidaten: P1–P10 Kurs, D1–D10 Binance-Derivate und Positionierung, M1–M12 Makro und On-Chain aus U130.
  - Kausal z-normiert; Ridge ohne Achsenabschnitt, gepoolt über die Krypto-Coins, PAXG eigens.
  - Walk-forward ab 01.01.2022 alle 28 Tage, λ aus geblockter Kreuzvalidierung mit Purging und Embargo.
  - m̂ gekappt bei 0,5 σ.
- **Tor je Horizont** (Clark-West und CRPS gegen Drift 0 je p < 0,05 aus dem Blockbootstrap, beide Hälften): Nur bei offenem Tor
  verschiebt die Richtung den Fächer; sonst „Richtung nicht belegt“.
- **Gewichte prüfen:** je Kandidat Gewicht, Spur, Vorzeichenstabilität, Beitrag ohne ihn, Null aus 100 zirkulären
  Verschiebungen, Holm über 31 und beide Hälften → „trägt / Hinweis / trägt nicht / zu kurz“.
- **Ziellevels:** Niveaus des Chartbilds, die Bestätigungsschwelle des Beins und die 50/200-Tage-Linie, je mit Erreich- und
  Schluss-Wahrscheinlichkeit für 7/14/28 Tage. Ein Niveau, das seit dem Schluss schon berührt wurde, steht als „erreicht“.
- **Prüfung:**
  - Rückblick ab 2022: CRPS, PIT, Deckung, Brier und Zuverlässigkeit.
  - Vergleich B1 (Zufallsweg mit Schwankung der 365 Tage), B0 (ohne Drift), M (mit Drift).
  - Urteile S1–S3 vorab.
  - Vorwärtsbilanz ab dem ersten Tag, auch für Orders und Cluster.
- **Betrieb:**
  - Eigener Prozess; täglich nach 00:30 UTC (vorher `regime.db` für PAXG nachladen, behebt Chartbild 9.2 Punkt 1), sonntags der
    Rückblick (≤ 15 min auf dem Pi).
  - Datei `ausblick.db`; der Ausblick wirkt auf nichts.

**Erwartung vorab:**
- Breite und Erreich-Wahrscheinlichkeiten halten.
- Die Richtung besteht bei 14/28 Tagen sehr wahrscheinlich nicht, bei 7 Tagen kaum. Die Tabelle „Gewichte“ wird überwiegend
  „trägt nicht“ zeigen — ein Befund, kein Fehler.
- Nachweisgrenze grob: R²_OS 2–3 % (7 T), 5 % (14 T), 10 % (28 T).

**Was man wissen muss:**
- Ein Wunsch nach „allen Daten“ wird ehrlich, wenn jede Quelle eingeht und jede ihr Gewicht vor einem Test verteidigen muss —
  nicht, wenn alle mit kleinem Gewicht mitreden.
- Die Szenarien sind die echte Bibliothek, nicht gezogene Pfade: Jede Prozentzahl ist ein Anteil, den man nachzählen kann.

## 3χχ. Aktienmarkt als Risikobarometer: Recherche und Ergänzung des Ausblicks (U146 13, U147, U148; 11.10. abends; nur Dokumente, Version 2026-09-23.65 unverändert, Opus 5.5)

**Anlass:** Der Nutzer diktiert um 17:49; der erste Versuch um 17:37 kam nur als ein Satz an.
1. Eine monatliche Aktualisierung sei viel zu selten — bei einem Black Swan kippe der Markt blitzschnell. Gewünscht: alle 30
   Minuten bei offenem Dashboard, seltener im Hintergrund.
2. ETF-Flüsse und MicroStrategy als Stimmungsmaß.
3. Der Aktienmarkt: S&P 500, die zehn größten Werte, Quartalszahlen. „Fällt der S&P 500, fällt BTC immer, ohne Ausnahme“; BTC
   lebe von Liquidität und Debasement, der Aktienmarkt gebe die Angst vor.
4. Eine gründliche Recherche der Schnittstellen und eine Prüfung des Zusammenhangs.
- Klargestellt: Nur die Gewichte waren alle 28 Tage geplant, die Prognose täglich.

**Recherche** (fünf Teilrecherchen, Bericht `RECHERCHE_Aktienmarkt_11-10-2026.md`, rund 11.600 Wörter, auch im Projekt):
- **„Immer“ stimmt nicht:** Im jüngsten Jahr fiel BTC an 76 von 115 S&P-Verlusttagen (66 %), an 22 von 25 Tagen unter −1 % (88 %)
  und an 3 von 3 Tagen unter −2 %.
  - Unter der Normalverteilung gilt ½ + arcsin(ρ)/π; ρ ≈ 0,4 erklärt die 66 % genau.
  - Ausnahmen gibt es in beide Richtungen: März 2023 (BTC +23 % abnormal, Banken −11 %) und 2025/26 (BTC −43 % bei steigendem
    S&P).
- **Vorlauf:** Kein belegter Vorlauf der Aktien vor BTC; eher sagt BTC außerhalb der US-Handelszeit den VIX voraus (Gu, Lin & Liu
  2026). Keine Aktiengröße sagt die BTC-Rendite über 1–4 Wochen außerhalb der Stichprobe voraus.
- **Volatilität:** Für die BTC-Volatilität tragen S&P-Schwankung und Finanzstress, der VIX am wenigsten. Die implizite
  BTC-Volatilität (DVOL) ist der stärkste Zusatz ab 7 Tagen.
- **S&P 500:** Die Schwankung ist vorhersagbar (HAR plus implizite Volatilität), die Richtung kaum (R²_OS 1–2 %, fast nur in
  Rezessionen). Konzentration, Bewertung, KI-Capex und die IPO-Welle verstärken Schocks, kündigen sie aber nicht an.
- **Daten:**
  - FRED führt den S&P 500 nur noch ab 2016 und den Hochzinsspread seit April 2026 nur noch drei Jahre.
  - Stooq verlangt seit März 2026 einen Schlüssel; NAAIM kostet seit August 2026 Geld.
  - Für untertägigen VIX gibt es keine saubere freie Quelle.
  - Kein Endpunkt war aus der Sandbox live prüfbar.

**Ergänzung `KONZEPT_Ausblick.md` 13, vorab festgelegt vor jedem Lauf auf echten Daten:**
- **Takt und Anker (13.1):** alle 30 Minuten bei offenem Dashboard, stündlich im Hintergrund, sofort bei Schock; rollierende
  24-h-Tage mit vier Ankerstunden für HAR und Bibliothek.
- **Breite (13.2):** HAR-X mit X1–X4, einzeln geprüft (DVOL, S&P-Schwankung, STLFSI4, VIX).
- **Form (13.3):** S&P-Pfade als zweite Koordinate derselben Fenster ab 2020.
- **Bedingte Szenarien (13.4):** Kern λ = 0,35 mit lokal-linearer Korrektur, Episoden-ESS ≥ 15, sonst t-Kopula; dazu ein
  Stressfächer aus dem unruhigsten Jahr seit 2020.
- **Richtung (13.5):** A1–A4 dazu (Nasdaq-Momentum 1/4 Wochen, ln VIX/VIX3M, Änderung Baa − 10 J); US-Reihen erst ab d+1
  14:00 UTC.
- **Null (13.6):** Das Nullverfahren wählt eine Kalibrierung auf zähen Null-Universen.
- **Anzeige (13.7):** Reiter „Aktienmarkt“ beschreibend.
- **Archiv (13.8):** `aktien.db` mit Abrufzeit (U148).
- **Prüfung (13.9):** Urteil S4 über die gemeinsame Form.
- **Studie U147 (13.12):** „Fällt BTC, wenn der S&P 500 fällt?“
- **Kurzstudie (13.13):** ETF-Flüsse und IBIT-Leerverkäufe über 7 Tage.

**Beim Nutzer (13.11) — entschieden 18:55:**
- **Aktienkurse rund um die Uhr über Hyperliquid HIP-3 `xyz` (trade.xyz).** Das war sein Hinweis; die Werte laut trade.xyz:
  - Indizes: SP500 (lizenziert, seit März 2026), XYZ100, VIX;
  - die Top 10, MSTR, STRC, COIN, TLT.
  - Abruf über dieselbe Info-API, die der Recorder für HIP-3 schon nutzt (`metaAndAssetCtxs` mit `dex`, `candleSnapshot` mit
    `xyz:SP500`).
  - Historie erst seit Listung, deshalb nur Barometer und Schockregel; Modell und Rückblick aus FRED.
  - Keine bezahlte Quelle.
- **SEC-User-Agent** `hl_liq_project admin@localhost.com` nach seiner Vorgabe, änderbar. Sperrt die SEC die Platzhalter-Adresse,
  fehlen nur die Strategy-Bestände.
- **SoSoValue: nein.** Er kannte den Dienst nicht und überließ mir die Wahl; Farside mit Abrufzeit und die eigene Rechnung aus den
  IBIT-Angaben reichen.
- Die E-Mail des Nutzers wird nicht verwendet.

**Was man wissen muss:**
- Gleichlauf ist keine Vorhersage. Aus ρ ≈ 0,4 und einer kaum vorhersagbaren Aktienrichtung wird für BTC fast nichts (ρ² · R²).
  Nützlich ist der Aktienmarkt für die Breite und für bedingte Szenarien.
- Die gefährlichere Fehlannahme ist die Umkehrung „BTC fällt nur, wenn Aktien fallen“: 2025/26 hätte ein reines Aktienbarometer
  Entwarnung gezeigt.
- Freie Datenfenster schrumpfen schneller, als die eigene Historie wächst. Was nicht mit Abrufzeit archiviert wird, fehlt später
  genau in den Stressepisoden.

## 3ψψ. Version 2026-09-23.66: Ausblick 4 Wochen, Aktien-Archiv, Backup-Sperre, Chartbild-Nacharbeiten, Pool-Zeitstempel und Audit (11.10. abends bis nachts, Opus 5.5)

**Anlass:**
- 16:50 und 18:55: „alles in 23.66“.
- 20:21: Auswertung der Abendberichte mit zwei eigenen Fehlern im Audit (U149, U150).
- 20:23 „Weiter“: fertigbauen.

**Was 23.66 enthält:**
1. **U145 Backup-Sperre** (UEBERGABE 3ττ). Zwei Sicherungen derselben Datenbank laufen nie mehr gleichzeitig.
   - `BackupSperre`: flock auf `<db>.backup.lock`, Ausweichort im Backup-Ordner. Der Kernel gibt die Sperre frei, wenn der
     Prozess endet, auch nach SIGKILL. In der Sperrdatei steht, wer sie hält.
   - Zwischendateien tragen die PID (eigenes Journal je Prozess). Reste anderer Läufe räumt nur der Sperrhalter weg.
   - `backup.json` wird atomar geschrieben.
   - `update.py`:
     - übernimmt ein Backup jünger als 24 h;
     - wartet sonst bis 90 min auf eine laufende Sicherung des Recorders und übernimmt sie;
     - legt sonst selbst eine an, mit laufender Ausgabe und einer Frist von 4 h;
     - schreibt das Log zeilenweise.
   - Recorder: Ist die Sperre besetzt, versucht er es nicht doppelt. Nach einem Fehler folgt der nächste Versuch nach 30 min,
     und der Zeitplan zeigt das.
   - Dashboard:
     - Der Update-Knopf sieht zuerst nach, ob ein Update läuft, bevor er Archiv oder Log anfasst. Nach einem Neuladen verfolgt
       die Seite das laufende Update weiter.
     - Das Archiv wird geprüft und dann atomar ersetzt.
     - Die Debug-Logdatei kommt aus `systemctl cat`.
     - „RAM je Prozess“ zeigt den Skriptnamen.
     - Die Backup-Anzeige und der Umzug kennen alle Backup-Dateien (`backup_dateien`).
   - `aktien.db` und `ausblick.db` werden mitgesichert, weil es sie nur hier gibt.
   - Selbsttest „Backup: Sperre, Zwischendateien, Warten, backup.json“ (B1–B7) mit eingebauter Positivkontrolle: Ohne Sperre
     muss B1 scheitern.
   - **Das Einspielen von 23.66 selbst läuft noch mit dem alten `update.py`.** Deshalb gilt ein letztes Mal: nur bei Uhrzeit auf
     der Kachel „Letztes Backup“.
2. **Chartbild-Nacharbeiten** (`KONZEPT_Chartbild.md` 9.2, umgesetzt 9.3):
   - Regime-Takt im Dashboard: `regime.db` bekommt die PAXG-Kerzen laufend (alle 5 min nachgesehen). Damit ist das PAXG-Band da.
   - Das größte Liquidationscluster braucht mindestens ein halbes Stundenvolumen (ohne Stundenvolumen keins, mit Grund).
   - Die Lesart nennt die belegte Kontenregel (U142 H1) und ob sie erfüllt ist; der Satz „keiner belegt“ ist weg.
   - Der Bein-Satz spricht von „Schluss“ statt „Hoch“.
   - „0,0 σ“ steht ohne Vorzeichen.
3. **U148 Aktien-Archiv** `hl_aktien.py` mit eigener Datei `aktien.db`:
   - Quellen: FRED (S&P 500, Nasdaq-100, VIX, VIX3M, Baa − 10 J, STLFSI4, NFCI, Hochzinsaufschlag mit Übernahme der Historie aus
     `makro.db`), Hyperliquid HIP-3 `xyz` rund um die Uhr, Deribit ETH-DVOL, CFTC TFF, FINRA Reg SHO, Farside je Fonds, Cboe
     (optional), SEC (Strategy-Bestände aus 8-K, Aktienzahl).
   - Jeder Wert steht mit Abrufzeit da; eine Revision ist eine neue Fassung, die alte bleibt.
   - NYSE-Kalender und New Yorker Zeit; Abruf nach Plan mit Schutzschalter (30 min · 2^(n−1), höchstens 24 h).
   - Reiter „Aktienmarkt“ im Ausblick: beschreibend, nicht geprüft.
4. **U146 Ausblick 4 Wochen** `hl_ausblick.py` (+ `hl_ausblick_js.py`, eigene Datei `ausblick.db`), wie `KONZEPT_Ausblick.md` 1–13.
   Beim Bau entstandene Punkte stehen in **12.1**: 36 Kandidaten, Nullverfahren, sequentielle Null, Nachweisgrenze, eigener
   Fehler in der λ-Kreuzvalidierung, Ereignisform, Rechenzeit, Takt, Kandidatentag, Proben.
5. **U147 Studie** „Fällt BTC, wenn der S&P 500 fällt?“ und **Kurzstudie K1/K2** (ETF-Flüsse, IBIT-Leerverkäufe), vorab
   festgelegt (13.12/13.13). Berichtsplan 12.10. 21:30, zweiter Termin 13.10.
6. **U149 `first_seen` in Millisekunden.**
   - `pool_laden` trug neue Pool-Konten seit dem Start des Pools (21.09.) mit Sekunden ein. Das ist der Fund „Zeit-Einheiten“ im
     Audit vom 11.10. 13:05.
   - Jetzt stehen Millisekunden da.
   - Beim Start des Recorders rechnet eine idempotente Reparatur alle Werte unter 10¹¹ um. Als Millisekunden wäre das der
     03.03.1973, als Sekunden das Jahr 5138.
7. **U150 Audit der Wal-Lebenszyklen.**
   - Jede Unstimmigkeit („doppeltes open“, „ohne open“) wird eingeordnet: Sperrgeschichte (gewollt, H3) vor Neustart
     (`snapshot_meta`, Laufzeit unter 900 s) vor „sonst“ (Fehler der Ereignislogik). „Sonst“ ist FEHLT, ein Neustart ein Hinweis
     (!), eine Sperrgeschichte ok.
   - Die Fälle stehen mit Zeit in der Liste.
   - Jede Prüfung hat ihre Laufzeit, am Ende steht die längste.
   - Das Alter rechnet mit einer frischen Uhr (das Audit dauert 10 min).
   - Selbsttest `--selbsttest-audit` mit Probe-Uhr.

**Eigene Fehler — beim Bau gefunden, vor jedem Lauf auf echten Daten:**
- **λ-Kreuzvalidierung sah in die Zukunft** (Ausblick, 12.1 Punkt 5). Gefunden von der vorab festgelegten Probe „Embargo der
  Richtung“. Kalibrierung und Nachweisgrenze liefen danach neu.
- **Kandidaten verzählt.** Das Konzept nannte 31 bzw. 35; es sind 32 bzw. 36.
- **Positionierung im Ende-zu-Ende-Lauf ungeprüft.** Den Demo-Datenbanken fehlten die Perp-Tageskerzen in `hebel.db`. Dadurch gab
  es keine Tafeln, und die D-Kandidaten waren im Ende-zu-Ende-Lauf leer. Die vorab geplante Probe meldete „keine Tafel“; jetzt
  läuft sie über echte Tafeln, und die Kausalitätsprobe schneidet auch diese Kerzen ab.
- **Lücken in den Proben, gefunden über die Mutationen:**
  - Bein nur mit einem Startextrem geprüft; jetzt auch gespiegelt.
  - Normalquantil nur auf 10⁻⁶ geprüft; jetzt auf 10⁻¹².
  - Lognormal-Ausgleich der Breite ungeprüft; jetzt „Breite unverzerrt“.
  - U147-Normalwert mit zu weiter Toleranz; jetzt genau bzw. gegen 2·10⁶ Ziehungen.
  - `kurs_um` ohne Kerze ab 16:00; jetzt mit.
- **Selbsttest-Schranke der Null-Universen zu streng.** „Trägt höchstens 1 von 120“ ist bei exakter Familienrate in 9 % der Fälle
  verletzt. Jetzt gilt höchstens 2 (P(≥ 3) ≈ 1 %). Vorher lief eine eigens festgelegte Schwanzprüfung auf 30 neuen Märkten, und
  beide Verfahren hielten sie (12.1 Punkt 2).
- **Ereignisform der Kopula schwankte je Saat um bis zu 0,15 σ** (Verwerfen, rund 2.500 Treffer). Jetzt wird genau im Ereignis
  gezogen, mit wahrem ρ und ν auf 0,02 σ.
- **Korrelationen warnten** bei Reihen, die im Fenster konstant sind (`RuntimeWarning`, ρ NaN). Solche Reihen fallen jetzt mit
  Grund weg.

**Prüfungen:**
- **Ausblick (`hl_ausblick.py --selbsttest`):** 49 Prüfungen in 11 Gruppen, alle grün (341 s in der Sandbox).
  - Nullverfahren (12.1 Punkt 2): Kalibrierung auf 100 Universen ergab Verschiebung 5,4 %, Phasen 4,2 %. Gewählt ist die
    Verschiebung; die Schwanzprüfung auf 30 neuen Universen bestätigt sie.
  - Nachweisgrenze (12.1 Punkt 4): bei R² 2,8 % (Wochenmomentum der Literatur) öffnet das Tor in 3 von 10 Märkten, P1 „trägt“ in 9 von 10; ab R² 5,9 % Tor 9 von 10; Rausch-Kandidaten nie.
  - Mutationen 61 von 61 rot. Fünf wurden erst nach neuen Proben rot: Normalquantil, Lognormal-Ausgleich, gespiegeltes Bein,
    Blocklänge im Tor, Bootstrap ohne Block.
- **Aktien (`hl_aktien.py --selbsttest`):** 22 Prüfungen ohne Netz, alle grün (rund 1 s).
  - Mutationen 14 von 14 rot; der U147-Normalwert erst nach einer neuen Probe.
- **Recorder:** `--selbsttest-audit` 8 Prüfungen (U149/U150), Mutationen 17 von 17 rot. `--selbsttest-backup` 18 Prüfungen
  (U145, B1–B7). Chartbild 47 Prüfungen (5 neu), Regime-Selbsttest mit Takt-Probe.
- **Browserprobe Ausblick:** Das SVG wird gegen die Nutzlast gemessen, nicht gegen die JS-Formeln: Zeit an den beschrifteten
  Wochen- und Monatsmarken, Preis an der log. Achse.
  - 4 Szenarien (BTC 6 Monate, ETH 12 Monate mit Schlusslinie, PAXG, HYPE am Handy), 82 Prüfungen.
  - Skript-Mutationen 16 von 16 rot.
  - Seitenbreite Desktop 1.280 und Handy 390 ohne Überlauf.
  - Die Fotos zeigten vier Schönheitsfehler, alle behoben:
    - Niveau-Beschriftung lief in die Preisachse (jetzt gemessen gekürzt, mit Probe);
    - „Okt 26“ lief in „Anker“;
    - „+1 W/+2 W“ überlappten am Handy;
    - Prozent brach um, und „-0,01“ stand mit Bindestrich.
- **Seite:** `node --check` beider Skriptblöcke und der Modul-Skripte (`/ausblick.js`, `/chartbild.js`, `/makro.js`).
  Namensprüfung ohne Befund.
- **`install.py --selftest-isoliert`:** 42 Schritte, PNG und 14 Dashboard-Abrufe grün. Neu sind die Schritte „Backup: Sperre, Zwischendateien, Warten,
  backup.json“, „Recorder: first_seen in ms, Audit …“, „Aktien-Archiv …“ (0,7 s) und „Ausblick 4 Wochen …“ (356 s), dazu die
  Abrufe `/ausblick?coin=BTC`, `/ausblick.js` und `/aktienmarkt`.

**Was nach dem Einspielen passiert und was ich brauche:**
- Takte im Dashboard: Aktien-Archiv (FRED nach 18:15 New York usw.), Ausblick (stündlich, offen alle 30 min), Regime (PAXG).
- Wenige Minuten nach dem Start rechnet der Ausblick am jüngsten 6-h-Anker: Fächer ohne Richtung, Ziellevels. Er sagt dazu,
  dass der Rückblick noch aussteht.
- In der ersten Nacht (01–06 UTC) läuft der erste Rückblick: Breite S1, Tor, Gewichte mit Nullläufen, S3, S4. Er läuft als
  eigener Prozess mit nice 10, auf dem Pi geschätzt 20–40 min. Gleich danach rechnet die Prognose mit dem neuen Stand.
- **12.10. 08:30 `u146-ausblick-erstlauf`** (Stand aller Coins, Aktienmarkt) und **12.10. 21:30 `u147-aktien-studie`** (U147,
  K1/K2) — bitte beide hochladen. Zweite Termine 13.10. (nur nötig, wenn 23.66 später eingespielt wurde).
- Sammeldatei wie gewohnt; A1 auf 23.66 prüfen.

**Offen beim Nutzer:**
- U142: Hinweis mit Quoten, Top-Trader-Punkt der Konfluenz.
- Chartbild-Entscheidungen 1–3.
- `KONZEPT_Ausblick.md` 11: drei Standards, die gelten, solange nichts anderes entschieden ist.

## 3ωω. 23.66 läuft auf dem Pi; Entscheidungen des Nutzers zu U142, Chartbild und Ausblick (11.10. 23:30; nur Dokumente, Version 2026-09-23.66 unverändert, Opus 5.5)

**Stand:** Der Nutzer hat um 23:28 23.66 eingespielt: „Alles ging wunderbar“. A1 prüfe ich mit der nächsten Sammeldatei. Er bat
darum, die offenen Entscheidungen ohne Nummern und Abkürzungen zu erklären und als Auswahl vorzulegen. Das waren neun Fragen in
drei Runden, dazu eine Nachfrage. Je Frage gab es einen markierten Vorschlag.

**Entschieden:** Alle Vorschläge angenommen, außer Punkt 3 des Ausblicks.

| Frage | Entscheidung | Umsetzung |
|---|---|---|
| Hinweis „Kaskadenrisiko nach unten“ (Binance, Konten ≥ 3, 0 Punkte) | mit den gemessenen Quoten (20 % gegen 7 %; in 4 von 5 Fällen kein Rücksetzer) | U151, 23.67 |
| Konfluenz-Punkt „Binance Top-Trader netto long/short“ (±1) | entfernen (H2 nicht belegt, steht fast immer auf Kauf) | U151, 23.67 |
| 95-%-Regel | eine andere Kennzahl; Quelle nicht mehr bekannt | U152: Liste gängiger Kennzahlen, Nutzer wählt, dann eigener Test |
| Breitentest der Kontenregel (U144) | ja, als eigene Studie | Konzept vorab, Bau in einem der nächsten Pakete |
| Chartbild 1 (Quoten nennen) | mit 23.66 schon erledigt (`KONZEPT_Chartbild.md` 9.3) | — |
| Chartbild 2 (Stufe 2, Niveau-Test) | nach dem 25.10. vorschlagen | mit der Magnet-Auswertung |
| Chartbild 3 (Chartbild-Text im Berichtsplan) | wöchentlich, sonntags 08:30 mit dem Ausblick | U151, 23.67 |
| Ausblick 11.1 (Wahrscheinlichkeiten an Momentaufnahmen) | ja, wie gebaut | — |
| Ausblick 11.2 (unbelegte Richtung gestrichelt) | nein, wie gebaut | — |
| Ausblick 11.3 (zweite Runde mit Hyperliquid-Daten ab Herbst 2027) | **nein** | — |

**Was man wissen muss:**
- Die Konfluenz-Änderung wirkt nur in den Ansichten Binance und Fusion. Fusion, v3, Kaskaden-Rechnung und v1-Lernen bleiben
  unberührt (Zusage bis 25.10.). Die Zusage „Konfluenz unverändert bis zur U142-Entscheidung“ ist erfüllt.
- Die Bilanz der Konfluenz mischt ab 23.67 alte und neue Regel. Der Stichtag kommt in den Bericht.
- Der börsenübergreifende Hinweis (Durchschnitt Binance, Bybit, OKX ≥ 2,5) ist nicht geprüft und bekommt keine Quoten.
- 23.67 kommt erst nach den Berichten vom 12.10. (erster Rückblick des Ausblicks, Studie U147). So läuft die erste Nacht mit
  23.66 ungestört.

Lehre: **Offene Entscheidungen in Klartext und als Auswahl vorlegen, mit Vorschlag und den Folgen je Möglichkeit. Nummern und
Abkürzungen sind Arbeitsnamen, keine Sprache für den Nutzer.**

## 3ααα. Makro: Arbeitsmarkt, Verbraucher- und Erzeugerpreise der USA -- nicht im System, bei FRED vorhanden; Nutzer: sammeln und zeigen, Datentage prüfen (U153, U154; 11.10. 23:44; nur Dokumente, Version 2026-09-23.66 unverändert, Opus 5.5)

**Frage des Nutzers (23:44):** Gibt es im Makro-Teil schon Arbeitsmarktdaten der USA (Arbeitslosenzahlen), Erzeugerpreise (PPI)
und Verbraucherpreise (CPI)? Und lassen sie sich über FRED abrufen? („Thread-Seite“ in der Spracheingabe ist FRED.)

**Befund im Code (alle Module, nicht nur Makro):** keine dieser Reihen.
- `hl_makro.py` holt von FRED 12 Reihen: WALCL, WTREGEN, RRPONTSYD, M2SL, DFII10, DTWEXBGS, BAMLH0A0HYM2, DFF, ECBASSETSW,
  JPNASSETS, DEXUSEU, DEXJPUS.
- `hl_aktien.py` (seit 23.66) holt 8: SP500, NASDAQ100, VIXCLS, VXVCLS, BAA10Y, STLFSI4, NFCI, BAMLH0A0HYM2.
- Das alte Hilfsskript `macro_corr.py` kennt T10YIE (Inflationserwartung), gehört aber nicht zum Makro-Teil.
- Nur geplant, nicht gebaut:
  - σ(t) mit Makro-Kalender (CPI, FOMC) in `KONZEPT_Fusion.md` 4b (U116);
  - optionale Termin-Zuschläge im Zwei-Uhren-Profil (`KONZEPT_Regime.md`; gebaut ist nur ein Zuschlag um 8:30 und 9:30 ET an
    *jedem* Werktag, ohne Kalender);
  - „Ereigniskalender (FOMC, Inflation, Megacap-Berichte)“ als Kandidat der Breite in `RECHERCHE_Aktienmarkt_11-10-2026.md`.

**Bei FRED vorhanden (Seiten am 11.10. gelesen):**

| Reihe | FRED | ab | Takt | Stand 11.10. | nächster Termin |
|---|---|---|---|---|---|
| Arbeitslosenquote | UNRATE | 1948 | monatlich (Employment Situation, BLS) | Sept. 2026: 4,2 % | Fr 06.11. |
| Stellenzahl außerhalb der Landwirtschaft | PAYEMS | 1939 | monatlich (Employment Situation) | Sept. 2026: 159.044 Tsd. (+29 Tsd.) | Fr 06.11. |
| Erstanträge auf Arbeitslosenhilfe | ICSA | 1967 | wöchentlich, Woche bis Samstag, donnerstags (ETA) | Woche bis 03.10.: 197.000 | Do 15.10. |
| Verbraucherpreise gesamt | CPIAUCSL | 1947 | monatlich (CPI, BLS) | Aug. 2026: 334,131 | Mi 14.10. |
| Verbraucherpreise ohne Lebensmittel und Energie | CPILFESL | 1957 | monatlich (CPI) | Aug. 2026: 337,765 | Mi 14.10. |
| Erzeugerpreise Endnachfrage | PPIFIS | Nov. 2009 | monatlich (PPI, BLS) | Aug. 2026: 157,411 (+0,4 % zum Juli) | Do 15.10. |

- Alle um 8:30 New York, also 14:30 Berlin (vom 25.10. bis 01.11. 13:30, weil die Uhren zu verschiedenen Tagen umgestellt werden).
- Weitere Reihen bei FRED: JTSJOL (offene Stellen), CES0500000003 (Stundenlöhne), PCEPI und PCEPILFE (PCE-Preise, das Maß der
  Fed), PPIFES (Erzeugerpreise ohne Lebensmittel und Energie). Die nicht bereinigten Fassungen: CPIAUCNS, CPILFENS, PPIFID.
- Termine über dieselbe Schnittstelle: `fred/release/dates`. Künftige Termine kommen nur mit
  `include_release_dates_with_no_data=true`.
- Erstveröffentlichungen über ALFRED: `fred/series/observations` mit Echtzeitraum und `output_type=4` („Initial Release Only“).
- Abruf: Der Pi holt FRED seit 06.10. über die API mit dem Schlüssel des Nutzers.

**Drei Dinge, die ich dem Nutzer gesagt habe:**
1. **Korrekturen:** Viele dieser Zahlen werden nachträglich korrigiert, am stärksten die Stellenzahlen. FRED zeigt den neuesten
   Stand.
   - **Für den Bau:** `makro.db` überschreibt geänderte Werte (`mk_reihe`, Schlüssel (reihe, ts)), die alte Fassung geht
     verloren.
   - Meine Zusage „jeden Abruf mit Abrufzeit speichern, wie beim Aktien-Archiv“ braucht deshalb eine Fassungstabelle wie `ak_wert`
     in `aktien.db`.
2. **Lücke Oktober 2025:** Die US-Regierung stand vom 01.10. bis 12.11.2025 still.
   - Die Haushaltsbefragung wurde nicht erhoben; die Arbeitslosenquote für Oktober 2025 gibt es nie.
   - Bei den Verbraucherpreisen sind die meisten Oktober-Indizes nicht veröffentlicht. BLS veröffentlicht deshalb für Oktober 2026
     bei diesen Indizes keine Vorjahresrate.
   - Die Stellenzahl für Oktober 2025 kam mit dem Novemberbericht (angesetzt auf 16.12.2025).
3. **Richtung:** Der Kurs reagiert auf die Überraschung gegenüber der Erwartung der Volkswirte. Diese Erwartungswerte gibt es bei
   FRED nicht und frei kaum.
   - Ohne sie dienen die Werte als Kulisse und die Termine als bekannte Tage mit möglicher Bewegung.
   - Ob BTC an diesen Tagen stärker schwankt, ist bei uns nicht geprüft.

**Entschieden (Auswahl mit Vorschlag, beide Vorschläge angenommen):**
- **Sammeln und zeigen (U153, mit 23.67):**
  - Reihen mit Fassungen ins Makro-Archiv, die Vergangenheit der Erstveröffentlichungen aus ALFRED.
  - Eigene Charts „Arbeitsmarkt“ und „Preise“ im Tab Makro, je mit dem nächsten Termin.
  - Nur Anzeige (`KONZEPT_Makro.md` 11).
- **Datentage prüfen (U154, nach dem 25.10.):**
  - Eigene kleine Studie, vorab festgelegt; geprüft wird nur die Schwankung, nicht die Richtung.
  - Ob der Ausblick oder die Strukturgleichung (U116) die Termine danach nutzt, wird eigens entschieden. Jede Nutzung muss
    außerhalb der Stichprobe gegen das bestehende HAR gewinnen (`KONZEPT_Makro.md` 11.7).

**Was man wissen muss:**
- Die Zusagen bis 25.10. bleiben unberührt. Die neuen Reihen wirken auf nichts:
  - keine Zonen und Signale, nicht in der Zonenkarte, nicht in „Makro × Kurs“;
  - nicht in Konfluenz, Labor, Prognose, Treiber oder Ausblick.
- 23.67 bringt damit U151 und U153 und kommt weiterhin erst nach den Berichten vom 12.10.

Quellen: FRED-Seiten der sechs Reihen (fred.stlouisfed.org/series/UNRATE, PAYEMS, ICSA, CPIAUCSL, CPILFESL, PPIFIS), BLS „2025
Federal Government Shutdown Impact on the CPI“ (bls.gov/cpi/additional-resources/2025-federal-government-shutdown-impact-cpi-faq.htm),
SJV Sun zum abgesagten Oktober-Arbeitsmarktbericht, FRED-API `fred/release/dates`, Paketdoku `fredr` zu `output_type`.

Lehre: **Bevor ich eine Speicherart zusage, prüfe ich das Schema der Zieldatenbank.** `makro.db` und `aktien.db` behandeln
Korrekturen verschieden. Die Zusage stimmt als Plan, braucht aber eine neue Tabelle.

**Nachtrag 12.10. kurz nach Mitternacht: Studie vorgezogen.**
- **Frage des Nutzers (00:01):** Warum erst nach dem 25.10., warum nicht früher?
- **Antwort:** Einen zwingenden Grund gibt es nicht.
  - Die Studie liest nur Historie: `swing.db` mit 30-min-Kerzen der Binance-Perps ab 01.01.2020, dazu die alten Termine aus FRED
    und ALFRED. Sie schreibt einen Bericht.
  - Sie berührt nichts, was bis 25.10. fest bleibt (Fusion, v3, Kaskaden-Rechnung, v1-Lernen; am 25.10. die vorab festgelegten
    Auswertungen U108, U110, U115).
  - Den 25.10. hatte ich nur vorgeschlagen, um das Paket schlank zu halten und die Tage für die ersten Auswertungen frei zu haben.
  - Vorbild: U130 Teil A, am 05.10. vor dem 25.10. gebaut und gleich gelaufen.
- **Entschieden per Auswahl (Vorschlag angenommen): U154 kommt mit 23.67.**
- **Reihenfolge im Bau:**
  - zuerst die Festlegung in `KONZEPT_Makro.md` 11.7, vor jeder Zahl;
  - dann der Code;
  - die Termine kommen aus demselben Paket (U153).

Lehre: **Wenn ich einen Zeitpunkt vorschlage, nenne ich den Grund gleich mit, und ob er eine Regel ist oder nur Bequemlichkeit.**

## 3βββ. Neuer Name des Dashboards: „HyperBit — Analyzer“ (U155; Nutzerwunsch 12.10. 02:29; nur Dokumente, Version 2026-09-23.66 unverändert, Opus 5.5)

**Wunsch des Nutzers:**
- 02:24: Der Name oben links („Hyperliquid — Liquidationscluster“) sei langweilig; er wollte fünf Vorschläge. Ich schlug vor:
  TEKTONIK, HUGIN & MUNIN (mein Favorit), SONAR, DOMINO, HEBELWERK.
- 02:29: Er nahm keinen davon, sondern seinen eigenen: „HyperBit - Analyzer. Kannst du es beim nächsten Update bitte im Dashboard
  ändern?“

**Umsetzung mit 23.67 (U155).** Nur angezeigte Namen ändern sich:
- `<title>HL Liquidationen</title>` → „HyperBit — Analyzer“ (Browser-Tab);
- `<h1>Hyperliquid — Liquidationscluster</h1>` → „HyperBit — Analyzer“. Der lange Strich bleibt wie bisher im Kopf; der Nutzer
  schrieb einen Bindestrich mit Leerzeichen.
- Export-Zeile (`const meta=…`, „· Hyperliquid-Liquidationscluster“) → „· HyperBit — Analyzer“;
- Web-App-Manifest (`/manifest.json`): `name` „HL Liquidationen“ → „HyperBit — Analyzer“, `short_name` „HL Liq“ → „HyperBit“;
- README-Titel: „HyperBit — Analyzer“. Die bisherige Zeile wird Untertitel: „Hyperliquid-Liquidationscluster aufzeichnen und
  auswerten“.

**Bleibt bewusst:** alle technischen Namen.
- Ordner `hl_liq_project`, Dienste `hl-recorder`/`hl-dashboard`/…, Datenbanken, Dateinamen;
- User-Agent `hl-dashboard/1.0`, Debug-Texte zu den Diensten.

Ein Umbenennen bräche Installation, Update, systemd und die Wiedererkennung bei den Quellen, ohne dass man es sieht.

**Hinweis für den Nutzer:** Ein schon angelegtes Symbol auf dem Handy-Startbildschirm kann den alten Namen behalten, bis er die
Verknüpfung neu anlegt.

**Probe beim Bau:**
- Titel, Kopfzeile, Export-Zeile und Manifest tragen den neuen Namen.
- Die alten sichtbaren Namen kommen auf der Seite nicht mehr vor.
- Die technischen Namen sind unverändert.

## 3γγγ. Berichte vom 12.10. ausgewertet; Version 2026-09-23.67 geliefert: U151, U153, U154, U155 und acht Befunde aus den Berichten (13.10. 01:03–; Opus 5.5)

**Eingang:** Sammeldatei 13.10. 01:03 („hier aktuelle debug daten“), vier Berichte: Aktienmarkt und Ausblick 12.10. 08:30, U147 und
K1/K2 12.10. 21:30. Kopf „Version 2026-09-23.66 · 8a4d5094de“ → **A1 ✓**.

**Ausblick: erster Rückblick (12.10. 01:00 UTC, 308 s; `KONZEPT_Ausblick.md` 12.2):**
- **Breite HAR-X:** kein Zusatz gewinnt (X1 DVOL 14 T +0,0044, p Holm 0,908) → Grundmodell.
- **S1 Breite besteht bei keinem Horizont.** CRPS-Gewinn B0 gegen B1 7 T +1,3 % (p 0,001), 14 T +0,2 %, 28 T −0,8 %. Deckung des
  80-%-Bands bei 28 T: PAXG 56,5 % ± 5,3 (zu eng), die übrigen in der Spanne; bei 7 T zusätzlich BTC 83,7 % ± 1,6 (zu weit).
  - Nach 5.5 bleibt B0 angezeigt, weil B1 nicht signifikant besser ist. Die Deckung steht je Coin am Fächer.
- **S2:** Tor überall zu, alle 36 Kandidaten „trägt nicht“. **S3 besteht** (Brier-Skill +6,1/+3,5/+1,2 %, Steigung 0,95/0,91/0,89).
- **S4 belegt** (Variogramm-Gewinn 0,0617, p 0,002, beide Hälften). Unter Aktienstress ist die bedingte Verteilung aber nicht
  kalibriert: Rosenblatt-PIT p 0,017 (7 T) und 0,001 (28 T).
- **Bedingte Szenarien:** Episoden-ESS 1,3–10,3, also überall die Kopula, wie erwartet.
- **Stressfächer** bei 80 % schmaler als der normale (BTC 75.465–93.621 gegen 73.018–97.550).

**Eigene Fehleinschätzungen (vorab in 10 und 13.10 bzw. 13.12 notiert):**
- S1 „besteht überall, Gewinn 3–10 %“ und X1 „trägt ab 7 Tagen“: beides falsch.
- S4 „vermutlich, aber knapp“: deutlicher belegt; die Schwäche unter Stress hatte ich nicht auf der Liste.
- U147 „unter −1 % etwa 85–90 %, unter −2 % fast 100 %“: gemessen 77 % und 84 %. Ich hatte aus dem jüngsten Jahr (88 % unter −1 %,
  3χχ) auf alle Jahre geschlossen.

**U147 (`KONZEPT_Ausblick.md` 13.12):** „immer“ **nicht bestätigt**.
- BTC seit 2020 an S&P-Verlusttagen: 64 % (61–68 %); unter −1 % 77 % (71–82 %); unter −2 % 84 % (73–91 %).
- Am nächsten an „immer“: 4 Wochen unter −5 %, 9 von 9 (70–100 %).
- In den letzten 260 Handelstagen unter −1 % 25 von 25 (Reiter „Aktienmarkt“). Der Gleichlauf schwankt stark über die Zeit.
- Vorlauf: BTC über Nacht → S&P am selben Tag belegt (t 4,49). Das ist gemeinsame Information der Nacht, kein Beleg, dass BTC führt.

**K1/K2 (13.13):** beide nicht belegt (ρ 0,026 bzw. 0,025, p Holm 1,000), wie erwartet.

**Befunde in den Berichten → behoben in 23.67:**

| # | Befund | Behebung |
|---|---|---|
| F1 | SEC-Zeile brach mitten im XML um („Aktienzahl: HTTP 404: <?xml … <Error><Code>NoSuch“) | Fehlertexte einzeilig; ein XML-Fehlerkörper wird auf seinen Code gekürzt („HTTP 404: NoSuchKey“) |
| F2 | Strategy meldet die Aktienzahl nicht auf dem Deckblatt (dei 404) → keine Aktienzahl, als Fehler gezählt | Kette Deckblatt → Bilanz (`CommonStockSharesOutstanding`) → gewichteter Quartalsdurchschnitt (nur Quartale, 80–100 Tage); 404 heißt „nicht gemeldet“, kein Fehler; die Abgrenzung steht im Text |
| F3 | VIX im Barometer bei 20,00 und +0,0 % — der Markt ist auf `xyz` eingestellt, der Kurs eingefroren | eingestellte Märkte: kein Archiv, keine Kerzen, nicht im Barometer, „eingestellt auf xyz (… letzter Kurs eingefroren): VIX“ in Text und Reiter; nicht in Struktur und Strategy-Rechnung |
| F4 | Zeiten der Quellenliste in UTC ohne Kennzeichnung | Ortszeit |
| F5 | Der Kopf des Aktien-Texts versprach ETF-Flüsse, CME-Positionierung, Leerverkäufe und Strategy; der Text endete nach dem Gleichlauf | Abschnitte „KRYPTO-AKTIEN UND POSITIONIERUNG“ und „STRUKTUR“; Gleichlauf-Tafel mit „letzte 260 T“ beschriftet |
| F6 | „Im Rückblick traf das 80-%-Band 57 %“ (PAXG) ohne Hinweis, dass das außerhalb der Spanne liegt | nach 5.5 „-- zu eng (Soll 80 %)“ bzw. „-- zu weit“, wenn außerhalb 80 % ± 2 SE (Lesart, damit auch im Dashboard) |
| F7 | S4 „belegt“ ohne die schlechte PIT unter Aktienstress | Zusatz „unter Aktienstress im Rückblick nicht kalibriert (PIT p … bei h T)“ in Text und Dashboard; für ältere Rückblicke aus dem gespeicherten vollen Rückblick ergänzt |
| F8 | Stressfächer schmaler als der normale — liest sich wie „in der Krise weniger Risiko“ | Beschriftung „Form der unruhigsten Phase seit 2020 (…) bei heutiger Schwankung“, 80 und 90 %, mit Erklärung im Dashboard (Form jener Zeit, nicht ihre Größe) |

F6–F8 sind reine Anzeige und ändern kein Urteil (12.2). Ob ein zweiter Stressfächer mit der *Größe* der Stressphase kommen soll, ist
eine Frage an den Nutzer (`KONZEPT_Ausblick.md` 13.11 Punkt 7, Standard nein).

**Gebaut mit 23.67:**
- **U151 Konfluenz** (`KONZEPT_Hebel.md` 11):
  - Top-Trader-Punkt entfernt.
  - Konten-Hinweis mit den Quoten aus H1, weiter ohne Punkt.
  - Regelstand mit Stichtag (Tabelle `konfluenz_regel`; Stichtag = erste Meldung eines Browsers mit „23.67“).
  - Bilanz „Seit der Regeländerung“ getrennt, im Dashboard und in `hl_forecast.py --konfluenz`.
  - Berichtsplan: Chartbild-Text sonntags 08:30.
- **U153 Makro USA** (`KONZEPT_Makro.md` 11, Nachtrag 11.8):
  - neun FRED-Reihen mit Fassungen (`mk_fassung`), Erstveröffentlichungen aus ALFRED, Termine aus `fred/release/dates`;
  - fünf Charts im Tab Makro mit Kursleiste, Termin je Chart und „Termine der nächsten 14 Tage“ in Ortszeit;
  - Lücke Oktober 2025 nicht gefüllt (Fadenkreuz in strenger Lesart: dort „—“);
  - nur Anzeige.
- **U154 Datentage** (`hl_datentage.py`): gebaut wie in 11.7 festgelegt.
  - Selbsttest: Positivkontrolle 40 von 40, Nullprobe 1 von 40, 90-%-Intervall deckt in 85 % von 200 Läufen.
  - Nachweisgrenze: Faktor 1,2 in 22 von 40, 1,3 in 33 von 40.
  - Studienlauf auf echten Daten 15.10. 21:45.
- **U155:** Name „HyperBit — Analyzer“ in Browser-Tab, Kopfzeile, Export-Zeile, Manifest (`short_name` „HyperBit“) und README;
  technische Namen unverändert.
- **U152:** Liste der Kennzahlen in `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md` (neu im Paket und im Projekt). Wörtlich bei
  „95 zu 5“ liegt nur der Perp-Anteil auf Hyperliquid (≈ 97 %, dort der Normalfall). An den Börsen kommt nur CryptoQuants BTC-Messung
  über alle Börsen heran: an Einzeltagen 2025 aus genannten Volumen 95–98 %, als Verhältnisreihe höchstens 94,3 %. Die Wahl liegt
  beim Nutzer.
- **Berichtsplan neu:**
  - 15.10. 20:15 `u153-makro-usa` (Makro-Stand mit den neuen Reihen);
  - 15.10. 21:45 `u154-datentage`, zweiter Termin 16.10. 21:45;
  - ab 18.10. sonntags 08:30 Ausblick, Aktienmarkt und Chartbild als Text.

**Proben (A7):**
- `install.py --selftest-isoliert`: 43 Schritte (neu „Datentage … (hl_datentage)“, 12,5 s) und 14 Dashboard-Abrufe grün, im
  Arbeitsstand und im ausgepackten Paket.
- **Selbsttests:**
  - Makro 9 neue Prüfungen (jetzt 65);
  - Datentage 10 Prüfungen (neu);
  - Aktien 5 neue (Block 4b, jetzt 27);
  - Ausblick 4 neue: 3 in der Gruppe „basis“ (Wertung mit S4-Satz und Stressfächer-Zeile, Ergänzung alter Rückblicke, Lesart), 1 im
    Ende-zu-Ende-Lauf (Text);
  - Dashboard „Last-Schutz“ mit 2 neuen (Konfluenz-Regelstand mit zwei Ständen und Fällen ab dem Wechsel; Name und Regeln in der
    Seite).
- **Python-Mutationen 53 von 53 rot** (`b74/mut/mut_67.py`; je 14 für Makro und Datentage, 9 Aktien, 9 Ausblick, 7 Konfluenz).
  - Dreizehn davon prüft erst eine Probe, die ich beim Entwurf der Mutationen ergänzt habe, zum Beispiel: nächster Termin und 14-Tage-Fenster, Erstanträge über
    eine fehlende Woche, Monatsrate aus der bereinigten Reihe, Termine ohne den Schalter für künftige (das falsche Netz lieferte
    künftige Termine auch ohne ihn), Urteil ohne Hälften, ohne Holm, Intervall 50 statt 90 %, Gegenprobe vertauscht, Hälften,
    Lesart ohne Wertung, ältester statt jüngster Regelstand, Fälle ohne Stichtag.
- **Browserprobe Makro USA** gegen eine eigene Rechnung aus `makro.db`: 9 Prüfungen, Skript-Mutationen 9 von 9 rot.
  - Zwei waren zuerst grün („strenge Lesart aus“, „Lücke gefüllt“). Die Probe zielte in die Mitte der Lücke; dort zeigt auch die
    alte Lesart nichts, weil der Vormonat schon über 40 Tage zurückliegt. Jetzt zielt sie auf den 2.–9. Oktober 2025.
  - Dazu ist eine abgebrochene Probe jetzt als rot mit Grund gezählt (vorher brach der ganze Lauf ab).
- **Browserprobe Ausblick** (Geometrie) unverändert bestanden.
- `node --check` für beide Skriptblöcke der Seite und die drei Modul-Skripte; Namensprüfung ohne Befund.
- Erwartungstreue der Datentage-Prüfgröße auf 200 weiteren Nullmärkten: Mittel T +0,0009 ± 0,0058. Der Median 0,964 im Selbsttest
  war Zufall der 40 Märkte.

**Was der Nutzer tun kann:**
- 23.67 einspielen.
- Nach dem Einspielen holt der Makro-Takt mit dem FRED-Schlüssel die neuen Reihen, die Erstveröffentlichungen und die Termine;
  die Charts füllen sich nach dem ersten Abruf.
- Hochladen: 15.10. 20:15 und 21:45 (bzw. 16.10.), dazu wie bisher die Termine bis 25.10.
- Ein schon angelegtes Symbol auf dem Handy-Startbildschirm kann den alten Namen behalten, bis er es neu anlegt.

Lehren:
- **Eine Lückenprobe zielt dorthin, wo der Fehler etwas anderes zeigen würde** — an den Rand der Lücke, nicht in ihre Mitte.
- **Ein falsches Netz verhält sich wie das echte auch dort, wo der Code einen Schalter braucht.** Sonst prüft die Probe den Schalter
  nicht.
- **Erwartungen aus einem Jahr gelten nicht für alle Jahre.**

## 3δδδ. Entscheidungen des Nutzers nach 23.67: die 95 % sind CryptoQuants Messung, kostenlos sammeln (U152 → U158); Stressfächer zusätzlich in der Größe der Stressphase (U156) (13.10. nachts; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Gefragt per Auswahl** (mit Vorschlag und Folgen), nach der Lieferung von 23.67:

1. **Woran erinnert dich die Quelle der 95-%-Regel?** → „Bitcoin: 9 von 10 sind Futures“, also CryptoQuants Messung über alle
   Börsen (Vorschlag war Hyperliquid).
2. **Wie an die Daten kommen?** → „Kostenlos ab jetzt sammeln“ (Vorschlag).
   - Vorher geprüft (cryptoquant.com/apis, 13.10.): Die kostenlose Stufe „Basic“ enthält Marktdaten je Tag mit 30 Tagen Rückschau.
     Laut Seite wird kein Endpunkt zurückgehalten, nur die Auflösung ändert sich.
   - Die Doku nennt Spot- und Perp-Volumen über alle Börsen in BTC (`btc/market-data/price-ohlcv`, `exchange=all_exchange`).
   - Die bezahlte Stufe hätte ein Jahr Geschichte; den Preis zeigt die Seite ohne Skript nicht (laut Vergleichsseite rund 29 USD im
     Monat).
3. **Stressfächer zusätzlich in der Größe der Stressphase?** → „Ja, zusätzlich“ (Vorschlag war nein).

**Festgelegt, bevor eine Zahl zu sehen ist:**
- **U158** (`KONZEPT_Hebel.md` 14):
  - Signal: CryptoQuant-Anteil der Perps am Bitcoin-Volumen über alle Börsen ≥ 95 %, wie formuliert.
  - Ereignis: Liquidationswelle in 7 Tagen wie H3.
  - Null: zirkuläre Zeitverschiebung (30 Tage bis Länge − 30).
  - Prüfbar erst ab 30 Signaltagen, 3 Episoden und 180 Tagen Reihe; die erste prüfbare Auswertung ist das Urteil.
  - Erwartung: selten prüfbar, wenn überhaupt RR nahe 1–1,5.
  - Abgrenzung: Die API kennt Spot und Perps, keine Termin-Futures. Der Anteil liegt dadurch etwas unter dem der Artikel.
- **U156** (`KONZEPT_Ausblick.md` 13.14):
  - Die tatsächlichen Wege der unruhigsten Phase ohne deren Trend, nur mit eigenen Fenstern des Coins (BTC, ETH, ZEC, XMR).
  - Angezeigt als Szenario mit der Beschriftung „kein Modell für heute“ und dem Verhältnis „damals x-mal so breit wie heute“.
  - Wirkt auf nichts.

**Bau mit 23.68:** CryptoQuant-Abruf, Archiv mit Abrufzeit, Eingabefeld für den Schlüssel, Chart „Derivate-Anteil (CryptoQuant)“ mit
95-%-Linie, Studienteil U158 und der zweite Stressfächer. Vorschlag zum Zeitpunkt: nach den Berichten vom 15./16.10. CryptoQuant
liefert bei jedem Abruf die letzten 30 Tage; bis dahin geht also nichts verloren.

**Was der Nutzer jetzt tun kann:** ein kostenloses CryptoQuant-Konto anlegen und den API-Schlüssel bereithalten. Das Eingabefeld kommt
mit 23.68 (wie beim FRED-Schlüssel im Tab Makro → Daten).

**Nebenbei:** Die Nachricht „hier aktuelle debug daten“ (13.10. 01:03) wurde mir während der Arbeit noch zweimal angezeigt. Es ist
dieselbe Sammeldatei, die 3γγγ auswertet, also nichts Neues.

Lehre: **Bevor ich einen kostenlosen Datenweg als Wahl anbiete, prüfe ich, ob die kostenlose Stufe die Reihe wirklich liefert.**
Hier stand es auf der Seite des Anbieters; ohne das wäre die vorgeschlagene Option womöglich leer gewesen.

## 3εεε. Berichte vom 11.10. abends: Kaskaden-Gleichung und Magnet-Test nach gut einer Woche -- nichts belegt, Nullmodelle treffen; die Abdeckung des OI ist gesunken (U115, U110, U159 neu; 13.10. 04:20; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Eingang:**
- Auf die Frage des Nutzers (04:01), ob ein Bericht fehlt, lud er vier Einzelberichte hoch (04:20):
  - Kaskaden-Stand 19:45 und Kaskaden-Selbsttest 19:46 (`u113-kaskade-woche1`);
  - Magnet-Stand 20:00 und Magnet-Selbsttest 20:00 (`u110-magnet-woche1`).
- **Es fehlt noch 19:30 `u106-fusion-woche1`.** Laut der Liste des Nutzers (05:19) sind das drei Dateien:
  `2026-10-11_19-30_fusion_stand.txt`, `2026-10-11_19-30_fusion_test.txt` und `2026-10-11_19-31_labor.txt`. Meine Vermutung
  „bericht_1 bis 4“ stimmte nicht; es gibt nur diese drei.

**Kaskaden-Gleichung** (`KONZEPT_Fusion.md` 4b.1c, Kalibrierung 11.10. 14:27, 33,5 Tage Heatmap):
- **Nichts belegt,** wie erwartet.
  - HYPE 4 h: drei der vier Bedingungen (Y 0,25, 2,7 SE), aber die gespiegelte Karte ist gleich gut, wie am 04.10.
  - XMR 4 h scheitert am Placebo (Y 2 auf der Karte von drei Tagen vorher).
  - BTC 1 h liegt bei 1,4 SE.
- **Zuverlässigkeit:** 22 von 22 Coin-Horizont-Schwellen innerhalb 2 SE (gemischte Schwankung trifft weiter).
- **Richtung:** 47 % ± 3 % (z −1,1); ETH 38 % (z −1,8), bei vier Coins mit 17 % Chance Zufall.
- Selbsttest auf dem Pi grün (21 Prüfungen, 66 s).

**Magnet-Test** (`KONZEPT_Fusion.md` U110, Rechnung 14:43):
- **Nichts belegt.** 18 urteilsfähige Klassen, keine mit Überschuss über 2 SE. Nullmodell an Zufallsniveaus 83 von 88 innerhalb 2 SE.
- **BTC 1 h groß** (Kandidat vom 04.10.) zeigt weiter in Richtung Anziehung: +6,3 ± 3,7 Punkte, gegen den Spiegel +8,2 ± 4,1, gegen
  das Placebo +7,8 ± 4,6; wirksam 56 von 60. Am 25.10. voraussichtlich urteilsfähig.
- **HYPE 1 h mittel** wieder über 2 SE (+10,9 ± 3,6), aber nur 39 wirksame Fälle und das Spiegel-Niveau ebenso oft berührt: höhere
  Schwankung nahe der Cluster, nicht Anziehung.
- Selbsttest auf dem Pi grün (13 Prüfungen, 29 s).

**Befund: Die Heatmap sieht einen kleineren Teil des offenen Interesses.**
- Abdeckung am 11.10.: BTC 16 %, ETH 19 %, HYPE 14 %, ZEC 10 %, XMR 17 %, PAXG 7 %.
- Am 04.10. waren es 22–24 % (XMR 18 %, PAXG 16 %), am ersten Kalibriertag 25–29 %.
- **Eigener Fehler:** Am 04.10. hatte ich geschrieben, am 05.10. zeige sich, ob die Abdeckung nach dem Neustart wieder steigt. Das
  habe ich nicht nachgehalten.
- **Folgen, soweit bekannt:**
  - Kaskaden-Gleichung und Magnet-Test rechnen mit dem, was die Karte zeigt. Bei kleinerer Abdeckung liegen Kipppunkte eher zu weit
    weg (4b.3).
  - Die Kalibrierungen über 33,5 Tage mischen Zeiten mit hoher und niedriger Abdeckung.
- **Klären (U159):** Die Tabelle `coverage` in `hl_liq.db` speichert je Stand die verfolgte Positionsgröße und das OI. Daraus geht
  hervor, ob das OI gewachsen ist, die verfolgten Positionen kleiner wurden (Sperren, Poller, Pool) oder beides, und seit wann.
  - Vorschlag: ein beschreibender Debug-Bericht „Abdeckung der Heatmap im Verlauf“ (je Coin und Tag: Abdeckung, verfolgte Größe, OI;
    dazu die Zahl verfolgter Konten und der Gesperrten), mit 23.68.
  - Keine Änderung am Recorder, bevor die Ursache feststeht.

**Was der Nutzer tun kann:** die drei Berichte von 19:30/19:31 hochladen (Fusion-Stand, Fusion-Selbsttest, TradeLabor). Ein Handlauf
ist nicht nötig. Für U159 gibt es noch keinen Debug-Bericht mit dem Verlauf; der Datenbank-Audit zeigt nur den Mittelwert seit Beginn.

Lehre: **Eine angekündigte Nachprüfung gehört mit Datum in den Plan, sonst geht sie verloren.** Hier stand sie nur im Konzept.

## 3ζζζ. Berichte vom 11.10. 19:30: Fusion nach einer Woche live und TradeLabor nach 14 Tagen -- nichts belegt, alle Vorhersagen beim Münzwurf; XMR-Gebühr: der Nutzer wählt die normale (U108, U99, U160–U162 neu; 13.10. 05:35; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Eingang (05:21):**
- `bericht_9` = Fusion-Stand 19:30:36, `bericht_10` = TradeLabor 19:31:15, `bericht_11` = derselbe Labor-Bericht noch einmal (byte-gleich).
- Es fehlt nur noch der Fusion-Selbsttest (`2026-10-11_19-30_fusion_test.txt`). Optional: Der Selbsttest ist auch ein
  Installationsschritt jedes Updates.

**Fusion und v3 (U108, erster Blick; Zahlen und Herleitung in `KONZEPT_Fusion.md` 6.1):**
- **Kriterium 1:** Fusion 4 h minus Basisrate, nur live gestellt: −0,0032 ± 0,0029 je Block (199 Blöcke, 47 Zeitblöcke). Nicht
  belegt. Je Coin keine Verschlechterung.
- **Kriterium 2:** kein ✗ gegen einen Experten (4 h live); v2 ✓ (−0,0082 ± 0,0034). Gegen v1 +0,0099 ± 0,0066, also 1,5 SE
  schlechter; v1 ist in allen sechs Coins der beste.
- **Kriterium 3:** v3 hat alle Gewichte bei 0 und c = 0, Brier-Skill 0,0. v3 nennt damit je Coin die Basisrate.
- **Kriterium 4:** „Fusion mit Kostenschwelle“ 16 Trades, Ø +0,025 %, gegen „Prognose Fusion“ 49 Trades, Ø −0,291 %. Die Richtung
  stimmt, aber Glück 100 %: Zwischenstand.
- **Kriterium 5 fehlt im Bericht.** Es steht seit 23.42 in der Liste; gebaut habe ich es nicht. **Eigener Fehler.** Nachrüsten als
  U162, vorab festgelegt in `KONZEPT_Fusion.md` 6.2.
- **24 h** (beschreibend bis Dezember, alle Blöcke): gegen Basisrate und v3 ✓, gegen v1 und Analog ✗.
- **Münzwurf als Maßstab (beschreibend):** Wer immer 50 % sagt, hat den Log-Verlust ln 2 = 0,6931.
  - Basisrate (0,699–0,728) und Fusion (0,698–0,716) liegen in allen sechs Coins darüber.
  - v1 liegt in vier Coins knapp darunter (um 0,001–0,004), ohne Beleg.
  - Keine Vorhersage sagt die Richtung der nächsten 4 h messbar besser voraus als ein Münzwurf.
- **Warum die Fusion hinter v1 liegt:** Fixed Share verteilt je Block rund 1,2 % der Gewichte neu auf alle Experten. Die Mischung
  bleibt dadurch breit und zahlt bis zu 0,012 Nats je Block, solange der Beste nicht wechselt. Der Rückstand von 0,0099 liegt in
  dieser Größenordnung; die Garantie hält.
- **Erwartung für den 25.10., vor dem Ergebnis festgehalten:**
  - Bleibt der Abstand zu v1, ist er dann rund 2,5 SE groß (✗): Kriterium 2 verfehlt.
  - Kriterium 1 läge bei rund −1,8 SE: knapp verfehlt.
  - Die Fusion bleibt dann im Schatten, und die Arbeit geht bei der Information weiter (Stufe 2).

**TradeLabor nach 14 Tagen (U99, erster Blick):**
- **Gesamt:** 47 Strategien, 5 Coins seit 27.09. (XMR seit 29.09.).
  - 5.204 geschlossene Trades, netto −104.833 USD, im Mittel −0,20 % je Trade; in den letzten 24 h 346 Trades, −6.137 USD.
  - Die Gebühren (37.387 USD) machen 36 % des Verlusts aus. Der Rest kommt aus dem Abstand zur Buchmitte, aus Funding und aus den
    Kursbewegungen; einzeln weist der Bericht das nicht aus.
- **Stufen:** 40 Kandidat, 0 Bewährung, **0 bewährt**, 7 negativ: Ausbruch nach Ruhe, Prognose v2, Wale folgen, Zufall (Kontrolle),
  TWAP-Druck, Familie Großkonten-Fluss, Familie Orderfluss.
- **Glück 100 % bei allen Strategien mit t:** Auch die besten sehen nicht besser aus als die beste von 47 Strategien ohne jede Kante.
- **Zufall (Kontrolle):** −0,306 % je Trade (t −2,4). So viel verlor eine Strategie ohne jede Kante, durch Kosten und Zufall. Wer
  darüber liegt, hat damit noch keinen Beleg.
- **Folgen gegen die Gegenprobe (beschreibend, nicht belegt; alle |t| < 3, die Paare hängen über denselben Markt zusammen):**

| Paar | folgen, Ø netto | dagegen, Ø netto | Blöcke |
|---|---|---|---|
| Leaderboard | −0,375 % | +0,196 % | 35 / 36 |
| Smart Money | −0,553 % | +0,080 % | 29 / 29 |
| Wale | −0,210 % | −0,046 % | 76 / 76 |
| Pool | −0,160 % | −0,101 % | 87 / 88 |
| Elite | +0,027 % | −0,258 % | 16 / 16 |

  In allen vier Fluss-Paaren schnitt „folgen“ schlechter ab als „dagegen“; nur bei der Elite war es umgekehrt. Für die Elite und
  die Darwin-Liste beginnt die 14-Tage-Frist erst mit 23.39 (U99).
- **Familie Orderfluss:** 428 Trades (264 Blöcke), Treffer 20 %, Ø −0,708 %, t −16,4, −30.308 USD, fast ein Drittel des
  Gesamtverlusts.
  - Wie viel davon XMR ist (U96: Markt-Einstiege 55–115 bps von der Mitte; bis 30.09. −3.000 USD in XMR), zeigt der Bericht nicht.
    Er nennt je Coin nur die besten drei (→ U161).
  - In XMR verloren selbst die besten drei Strategien je rund 400 USD (Profi-Flow −410, Funding-Extrem −417, Momentum kurz −423).
- **Grid:** Long −1.119 USD (t −1,6), Short −2.160 USD (t −4,6), je 11 Tage.
- **Halten Long (Vergleich):** 9 Trades in 2 Blöcken, Ø −4,8 %, −4.339 USD; mit 5× Hebel einmal liquidiert. Die Kurse fielen in
  diesen zwei Wochen im Mittel.
- **Swing und Zyklus:** noch keine geschlossenen Trades; ihr Vorwärtsbeleg braucht Monate.
- **Lesart:** Nach 14 Tagen hat keine Strategie einen Beleg, und die Kosten überwiegen. So sieht es aus, wenn viele kleine Trades
  ohne Kante laufen. Das ist ein Ergebnis, kein Fehler. Nächster Stand mit dem Bericht vom 25.10. 19:30 (`u108-fusion-auswertung`
  enthält das Labor).

**XMR-Gebühr im Labor (U80, U96 → U160):**
- **Messung:** Gebühren-Prüfung über 3 Tage, Median Gebühr ÷ Umsatz echter Fills:
  - BTC/ETH 0,0255 %, XMR 0,0120 %, also XMR ≈ ×0,5 der Standard-Perps; das Labor rechnet ×2.
  - Zweite Messung in dieselbe Richtung (30.09.: ×0,3).
- **Hintergrund:** Hyperliquid hat für HIP-3-Märkte einen „Growth Mode“ mit rund 90 % niedrigeren Gebühren eingeführt (Berichte von
  November 2025). Ob XMR darunter fällt, ist nicht geprüft. Die Messung vermengt Kontostufen und die Mischung aus Taker und Maker.
- **Regel U80 (vorab, 29.09.):** Weicht der echte Satz deutlich ab, wird die Annahme angepasst (Ausführungsmodell, keine neue
  Kennung).
- **Entscheidung des Nutzers (13.10., Auswahl „Normale Gebühr (Vorschlag)“):** XMR im Labor ab 23.68 mit den normalen Sätzen wie
  BTC und ETH. Nicht ×0,5, weil die Messung dafür zu grob ist; ×1 ist die vorsichtige Mitte.
- **Umsetzung (U160, mit 23.68):**
  - `hl_labor.GEB_FAKTOR` ohne XMR; der Zeitpunkt des Wechsels steht im Labor-Zustand, Bericht und Dashboard nennen ihn.
  - Keine neue Kennung. Alte Trades behalten ihre Gebühren; ein offener Trade über den Wechsel zahlt beim Einstieg doppelt, beim
    Ausstieg normal. Die Gebühren-Prüfung bleibt und vergleicht weiter.
  - Die Kostenschwelle der Fusion (`hl_fusion.gebuehren`, liest bisher die Sätze des Labors) bleibt bis zum Urteil U108 am 25.10.
    bei XMR doppelt, denn die Fusion bleibt bis dahin unverändert. Danach folgt sie dem Labor.
  - Die historische Swing-Studie (`hl_swing.GEB_FAKTOR`) behält ihre vorab festgelegte Annahme. Swing-Trades im Labor laufen über
    das Labor und bekommen die normale Gebühr. Vermerkt in `KONZEPT_Swing.md` 3, 7 und 9 (ins Projekt geladen).
  - Den Dashboard-Text der Labor-Erklärung und den README-Abschnitt „Ausführung“ mitziehen.
  - Selbsttest: XMR zahlt wie BTC; Trade über den Wechsel; Fusion-Kosten für XMR unverändert doppelt; Mutation (Faktor zurück
    auf 2) wird rot.
- **Folgen für die Auswertung:**
  - XMR vor und nach dem Wechsel getrennt lesen (U161).
  - In XMR steigen „Fusion mit Kostenschwelle“ und „Kaskaden-Kipppunkt“ öfter ein, denn beide prüfen die Kosten vor dem Einstieg.
    Ihre Vergleichsstrategien zahlen dieselbe Gebühr; für Kriterium 4 (U108) und den Labor-Vergleich in U115 ist der Zeitraum damit
    gemischt.
  - Die Markt-Einstiege weit von der Buchmitte (U96) bleiben ein eigener Kostenposten.

**Neu im Plan:**
- U160: XMR mit normaler Gebühr.
- U161: Labor-Bericht je Strategie und Coin.
- U162: Kriterium 5 der Fusion im Bericht.

**23.68 umfasst damit:** U156, U158, U159, U160, U161, U162. Vorschlag weiterhin: nach den Berichten vom 15./16.10.

**Was der Nutzer tun kann:** nichts Dringendes. Wenn es passt, den Fusion-Selbsttest vom 11.10. 19:30 hochladen (optional).
Nächste Berichte: 14.10. 19:00 Wochenbericht, 15.10. 20:15 Makro USA und 21:45 Datentage.

Lehre: **Jede Abnahme-Zeile braucht beim Bau ihre Berichtszeile.** Ein Kriterium, das der Bericht nicht rechnet, kann am Stichtag
niemand prüfen.

**Nachtrag 13.10. 14:07 (Upload des Nutzers):**
- `bericht_12` = Fusion-Selbsttest 11.10. 19:31: **bestanden**, 27 Prüfungen grün in 38 s.
  - Zeile für Zeile dieselben Zahlen wie derselbe Selbsttest in der Sandbox mit 23.67 (nur die Laufzeit weicht ab: 32 s), und
    dieselben wie beim Bau (`KONZEPT_Fusion.md` 3.3).
  - Der Pi lief damals mit 23.65. Die Fusion rechnet in beiden Versionen gleich, wie zugesagt.
  - Die Prüfung „Kosten: XMR (HIP-3) doppelt“ bleibt auch mit 23.68 grün, weil die Kostenschwelle der Fusion bis zum 25.10. bei
    XMR doppelt bleibt (U160).
- `bericht_13` = noch einmal der Fusion-Stand (byte-gleich mit `bericht_9`).
- Damit ist `u106-fusion-woche1` vollständig; **es fehlt kein Bericht mehr.**

## 3ηηη. Größe der Trades im TradeLabor geprüft (Nutzerfrage 13.10. 20:25 mit Bild der Trades-Tabelle): Grid-Lose 833–2.500 USD, Swing und Zyklus nach Risiko; Entscheidungen: Grid-Anzeige ergänzen (U163), Swing und Zyklus mit fester Größe (U164) (13.10. 20:35; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Frage des Nutzers:** Die Beträge der Grid-Trades wirken klein, „als wären die Trades lediglich 100 Dollar“; die Regel war 10.000 USD
je Trade. Besser wäre dieselbe Größenordnung für alle, damit die Leistung auch in USD erkennbar ist. „Prüfe das bitte alles.“

**Geprüft (Code 23.67 und das Bild):**
- **Feste 10.000 USD je Trade** (`hl_labor.NOTIONAL`): alle Signal-, Kopier-, Familien-, Prognose-, Ereignis- und Kontrollstrategien.
  Im Bild die letzte Zeile: −43,68 USD bei −0,44 %, also rund 9.900 USD, ein normaler Trade (Rundung des Prozentwerts).
- **Grid:** je Coin ein Konto über `GRID_KAPITAL` = 10.000 USD, gleichmäßig auf die n Abstände verteilt (`los = GRID_KAPITAL / n`,
  n = 4–12), also 833–2.500 USD je Los.
  - Das Bild passt genau: +3,30 USD bei +0,40 % (rund 830 USD, 12 Abstände), +5,02 bei +0,20 % (2.500, 4 Abstände), +2,82 und +2,85
    bei +0,17 % (rund 1.670, 6 Abstände).
  - Ein Los verdient einen Schritt (Ziel ist die nächste Stufe, als Maker) minus Gebühren; daher wenige USD je Zeile.
- **Swing und Zyklus** (neun Strategien, `hl_swing.plan`): Größe = 100 USD Risiko ÷ Stop-Abstand, höchstens 10.000 USD. Die sechs
  offenen Swing-Trades im Bericht vom 11.10. waren rund 800–2.700 USD groß (BTC rund 2.700, ETH rund 2.650, HYPE rund 1.300, ZEC rund
  800–900).
- **Strategie-Tabelle:** Summe und Ø/Tag stehen bei allen auf derselben Grundlage, 10.000 USD je Coin und Kontotag
  (`tag_pct` = Summe ÷ Kontotage ÷ 10.000), beim Grid nach Bestandswert. Die Stufen (t, Glück) rechnen in Prozent je Trade, beim Grid
  in Prozent des Kontos je Tag, und hängen damit nicht von der Größe ab.
- **Die Trades-Tabelle** rechnet „netto USD“ richtig mit der Größe je Trade (`t.notional`), zeigt die Größe aber nicht.
- **Irreführend:** die Kachel „10.000 USD je Trade“ in der Labor-Übersicht und der Hilfetext „ein eigenes Konto mit 10.000 USD je
  Trade“. Für Grid (seit 23.40), Swing (seit 23.61) und Zyklus (seit 23.62) stimmt das nicht. **Eigener Fehler:** beim Einbau nicht
  nachgezogen.

**Entscheidungen des Nutzers (Auswahl, 13.10.):**
- Grid: „Anzeige ergänzen (Vorschlag)“ → **U163**.
- Swing und Zyklus: „Feste Größe wie alle (Vorschlag)“ → **U164**.

**U163 (mit 23.68, nur Anzeige; Rechnung und Kennungen unverändert):**
- Trades-Tabelle: neue Spalte „Größe“ (USD je Trade bzw. Los; in der Hebel-Ansicht mal Hebel, der Untertitel sagt es). In der
  Spalte „Strategie“ tragen Grid-Lose den Zusatz „Los“.
- Grid: Wer in der Trades-Tabelle eine Grid-Strategie wählt, sieht über den Losen die Tabelle „je Coin und Tag“. Sie zeigt:
  - die Zahl der geschlossenen Lose;
  - realisiert und Änderung des Bestands;
  - das Tagesergebnis in USD und in Prozent des 10.000-USD-Kontos.
  
  Das sind genau die Zahlen, aus denen Stufe und t rechnen (`grid_tage`), und sie haben die Größenordnung eines normalen Trades. Im
  Debug-Bericht „★ TradeLabor“ stehen je Grid und Coin die letzten 7 Tage.
- Strategie-Tabelle: „Ø/Tag“ zusätzlich in USD je Coin-Konto (Ø/Tag in % mal 100 USD). Damit sind Grid und alle anderen in einer
  USD-Zahl vergleichbar.
- Kachel und Hilfetext berichtigen: „10.000 USD je Trade; Grid: 10.000 USD je Coin, auf die Stufen verteilt“. Nach U164 gibt es keine
  weitere Ausnahme.
- Proben:
  - Tageszeile = Summe der Lose des Tages + Änderung des Bestands, auf den Cent gegen `grid_tage`.
  - Summe über die Tage = Summe der Strategie.
  - Größe in der Zeile = gespeicherte Größe der Position.
  - Mutation (Bestand vergessen) wird rot.

**U164 (mit 23.68, neue Kennungen):**
- Im Labor handeln die neun Swing- und Zyklus-Strategien mit fester Größe 10.000 USD (`NOTIONAL`) statt 100 USD Risiko ÷
  Stop-Abstand. Stop, Ziel, Nachzieh-Stop und Ausstiege bleiben (`hl_swing.plan` liefert sie weiter).
- **Kennungen:** Ein neues Feld in den Labor-Regeln (etwa `"groesse": "fest"`), nicht in `hl_swing.STRATEGIEN`. Damit bleibt die
  Vorprüfung auf der Historie (`hl_swing.py --vorpruefung`, `hl_zyklus.py`) bitgleich. Es entstehen neun neue Kennungen; die alten
  stehen als „alte Regelversion“ im Bericht.
- **Offene Positionen der alten Kennungen** (am 11.10. sechs Swing-Trades, kein Zyklus-Trade) werden beim Wechsel zum Marktpreis
  geschlossen („Regelversion abgelöst“), wie bei den Grids. Sonst lägen sie ohne tägliches Nachführen offen. Bis zum Bericht vom
  11.10. war kein Swing- oder Zyklus-Trade abgeschlossen; es geht kaum etwas verloren.
- **R** = netto ÷ (Größe × Stop-Abstand); gespeichert wird `risiko_usd` = 10.000 × Stop-Abstand. R hängt nicht von der Größe ab.
  Der Vorwärtsvergleich mit der Historie (`KONZEPT_Swing.md` 7: mittleres R im 90-%-Band der Historie) gilt deshalb weiter.
- **Folgen:**
  - Das Risiko bis zum Stop ist je Coin verschieden. Bei den Stops vom 11.10. wären es bei BTC und ETH rund 370 USD, bei HYPE rund
    770 USD, bei ZEC rund 1.100–1.250 USD.
  - Summe und Ø/Tag gewichten unruhige Coins dadurch stärker. Die Stufen (Prozent je Trade auf Blöcken) ändern sich nicht.
- **Für echtes Geld** (nur auf Entscheidung des Nutzers) bleibt die Größe nach Risiko meine Empfehlung (`KONZEPT_Zyklen.md` 13 Punkt
  3). Im Labor geht die Vergleichbarkeit vor. Das weicht bewusst von meinem Vorschlag vom 09.10. ab.
- **Proben:**
  - Ein Swing-Trade im Labor hat die Größe 10.000 (Markt) und `risiko_usd` = 10.000 × Stop-Abstand. Die bisherige Probe („Größe nach
    Risiko, `risiko_usd` 100“) wird umgestellt.
  - Neue Kennungen wie erwartet, alte abgelöst, offene Positionen mit Grund geschlossen.
  - Die Historie bleibt bitgleich (Swing- und Zyklus-Selbsttest unverändert grün).
  - Mutation (Größe wieder nach Risiko) wird rot.
- **Texte:** Strategie-Beschreibung (`SWING_GEMEINSAM`), Bericht „R = netto ÷ Risiko bis zum Stop (Plan 100 USD)“, README,
  `KONZEPT_Swing.md` 3, 7 und 10, `KONZEPT_Zyklen.md` 7 und 13 (die beiden Konzepte sind schon vermerkt und im Projekt).

**23.68 umfasst damit:** U156, U158, U159, U160, U161, U162, U163, U164. Vorschlag weiterhin: nach den Berichten vom 15./16.10.

Lehre: **Wer eine Ausnahme von einer angezeigten Regel einbaut, ändert die Anzeige mit.** Die Kachel „10.000 USD je Trade“ stimmte seit
dem Grid nicht mehr.

## 3θθθ. Sammeldatei 13.10. 22:07: Zweitläufe von Ausblick, Aktienmarkt, U147 und K1/K2 bestätigen den 12.10.; der Pi läuft noch mit 23.66; Befund zu den ETF-Flüssen (U165 neu) (13.10. 22:15; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Eingang:** Sammeldatei mit vier Berichten (Ausblick und Aktienmarkt 08:30, U147 und K1/K2 21:30), Kopf „Version 2026-09-23.66 ·
8a4d5094de“.

**A1: Auf dem Pi läuft noch 23.66.** 23.67 (geliefert 13.10. nachts) ist nicht eingespielt.
- Die Termine 15.10. 20:15 (Makro USA, U153) und 21:45 (Datentage, U154) stehen nur im Berichtsplan von 23.67. Ohne Update laufen
  sie nicht.
- **Bitte 23.67 vor dem 15.10. 20:15 einspielen**, wie gewohnt über den Update-Knopf; seit 23.66 wartet das Update selbst auf ein
  laufendes Backup. Danach A1: Systemkachel „Version“ = 2026-09-23.67 · 6f5ae65d87.

**Zweitläufe (vorgesehen als Ersatztermine; am 12.10. lief alles vollständig):** kein Urteil ändert sich (`KONZEPT_Ausblick.md`
13.15).
- U147 mit einem S&P-Tag mehr: S&P < 0 → BTC fiel 502 von 782 = 64 % (61–67 %); am 12.10. fiel der S&P leicht, BTC nicht. Sonst
  gleich, „immer“ nicht bestätigt.
- K1/K2 (n 632): beide nicht belegt (ρ 0,026 bzw. 0,024).
- Ausblick: Rückblick noch vom 12.10. (wöchentlich sonntags, nächster 18.10.); dasselbe Bild.
- Die Befunde F1, F2, F3 und F5 aus 3γγγ sind noch sichtbar, weil 23.66 läuft (SEC-Zeile mit Zeilenumbruch, HTTP 404 bei der
  Aktienzahl, VIX bei `xyz` fest auf 20,00, fehlende Abschnitte). Behoben in 23.67.
- Das SEC-Archiv holt auf: 8-K offen 154 → 132, BTC-Bestände 17 → 33 Werte.

**Neuer Befund: Der jüngste Farside-Tag kann unvollständig sein (U165).**
- Im Abruf vom 13.10. 03:00 fehlen für den 12.10. IBIT und HODL (beide bis 09.10.), alle übrigen Fonds und „Total“ reichen bis 12.10.
  Die Tagessumme des 12.10. ist damit vermutlich zu klein.
- Das Archiv speichert die spätere Vervollständigung als neue Fassung. **Nachprüfung mit Datum: Aktienmarkt-Bericht 18.10. 08:30**
  (IBIT mit Wert für den 12.10., `farside:btc:Total` mit mindestens einer Revision). Steht auch im Plan, Lehre aus 3εεε.
- K1 ist nicht betroffen. Betroffen sind die letzten Tage in der Anzeige samt Summen über 5 und 20 Tage.
- U165 (mit 23.68, nur Anzeige): unvollständige Tage markieren („fehlt: IBIT, HODL“), aus den Summen lassen, zählen, wie oft der
  jüngste Tag unvollständig ist (Entscheidung über einen zweiten Abruf erst danach). Vorab festgelegt in 13.15.

**23.68 umfasst damit:** U156, U158, U159, U160, U161, U162, U163, U164, U165. Vorschlag weiterhin: nach den Berichten vom 15./16.10.

**Was der Nutzer tun kann:** 23.67 einspielen. Nächste Berichte: 14.10. 19:00 Wochenbericht; 15.10. 20:15 Makro USA und 21:45
Datentage (beide erst mit 23.67).

## 3ιιι. Skriptfehler im Hinweisfenster des Kurs-Charts mit der Quelle „Binance Daten“ (Bild des Nutzers 14.10. 08:14; U166 neu; Korrektur mit 23.68 nach Wahl des Nutzers) (14.10. 08:25; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Meldung (Bild, 08:14:13):** „Skriptfehler: Uncaught TypeError: Cannot read properties of undefined (reading 'toFixed') (Zeile 2961)“;
Quelle im Kopf „Binance Daten“, sichtbar der Reiter „Chartbild“.

**Ursache (geprüft):**
- Zeile 2961 der ausgelieferten Seite (`hl_viz.PAGE`) ist in 23.67 `+near.x_vol.toFixed(2)+'x Vol'` in `tipChart`, dem Hinweisfenster
  des Kurs-Charts. In 23.66 steht dieselbe Zeile auf 2953, die Zeile 2961 ist dort leer. **Die Meldung stammt also von 23.67; das
  Update ist offenbar eingespielt** (A1 noch mit der Systemkachel bestätigen).
- Die externen Skripte scheiden aus (`makro.js` 614, `chartbild.js` 360, `ausblick.js` 393 Zeilen).
- Mit `src == 'bnc'` ersetzt `attach_binance` die Marken des Charts durch **eingetretene** Binance-Liquidationen je Preisstufe:
  `{px, side, notional, n_pos, dist}`, ohne `x_vol`. Die Hyperliquid-Marken (`chart_payload`) tragen `x_vol` = Notional ÷
  Stundenvolumen.
- Fährt oder tippt man im Chart in die Nähe (0,4 %) einer solchen Marke, formatiert `tipChart` das fehlende `x_vol` und bricht ab.
  Die Fehlerleiste hält Skriptfehler fest, bis die Seite neu lädt.
- **Nachgestellt** (node, `tipChart` aus der Seite, Marke wie aus `attach_binance`): genau diese Meldung; mit `x_vol` läuft es.
  Probe im Scratchpad `b76/repro.js`.
- Die beiden anderen Stellen mit `x_vol` (Linienstärke, Auswahl „groß“) vergleichen nur mit 0,5 und brechen nicht ab.
- **Alter Fehler:** derselbe Code in 23.66, kein Rückschritt durch 23.67.
- **Wirkung:** nur das Hinweisfenster. Daten, Rechnungen, Prognose und Labor sind nicht betroffen.

**Entscheidung des Nutzers (Auswahl 14.10., kurz vor 08:25):** „Mit dem nächsten Paket (Vorschlag)“, also kein eigenes Update vor den Berichten vom
15./16.10. Bis dahin: Seite neu laden; mit „Hyperliquid Daten“ tritt der Fehler nicht auf.

**U166 (mit 23.68, nur Anzeige; vorab festgelegt):**
- `tipChart`: Bei eingetretenen Marken (`levels_realized`) zeigt die Zeile „liquidiert … USD · n Liquidationen“, sonst wie bisher
  „… USD · x-faches Volumen“. Fehlt `x_vol` aus einem anderen Grund, entfällt nur dieser Teil; kein Abbruch.
- Gleiche Prüfung für alle Hinweisfenster mit Feldern, die es nur bei einer Quelle gibt.
- Proben:
  - node: `tipChart` mit Binance-Marke ohne `x_vol` → kein Fehler, Zeile „liquidiert“; mit Hyperliquid-Marke → „x-faches Volumen“
    wie bisher.
  - Browserprobe: Chart, Heatmap und Orderbuch mit der Quelle „Binance Daten“ und „Hyperliquid Daten“, die Maus über jede Marke und
    jede Heatmap-Zelle mit Wert: keine Fehlerleiste.
  - Mutation (Prüfung auf `levels_realized` entfernt) → die Browserprobe wird rot.

**23.68 umfasst damit:** U156, U158–U166.

Lehre: **Eine zweite Datenquelle bringt eigene Formen derselben Objekte mit; jede Anzeige, die ein Feld formatiert, muss beide
Formen kennen.** Die Browserproben liefen bisher nur mit Hyperliquid-Daten.

## 3κκκ. Bilanzverlauf im TradeLabor mit allen Strategien, Auswahl per Häkchen, Standard „Top 10 nach Trefferquote“ (Nutzerwunsch 14.10. 08:30 mit Bild; U167 neu; mit 23.68) (14.10. 12:15; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Wunsch des Nutzers (08:30):** Der Chart „Bilanzverlauf“ (TradeLabor → Chart) gefällt, zeigt aber nur einen Teil der Strategien.
Gewünscht: alle Strategien, jede per Häkchen ein- und ausblendbar, in der Standardansicht die zehn erfolgreichsten „nach positiver %
Erfolgsrate“; „hübsch und fehlerfrei“.

**Heute (23.67):** `labEquityChart` zeichnet die acht Strategien mit dem größten Betrag der Summe (Gewinn oder Verlust) und dazu Zufall
und Halten Long. `/labor/equity` liefert schon alle Strategien mit geschlossenen Trades, auch Grids (nach Bestandswert) und alte
Regelversionen. Die Achse richtet sich nach allen gezeichneten Linien; „Familie Orderfluss“ (−34.755 USD am 14.10.) drückt die übrigen
zusammen.

**Entscheidung des Nutzers (Auswahl 14.10.):** Rangfolge nach **Trefferquote** (Anteil der Trades mit Gewinn). Mein Vorschlag war
„Rendite je Tag“, mit dem Hinweis, dass eine hohe Trefferquote mit Verlust einhergehen kann (Grid Long). Mit den Zahlen vom 11.10.
stünden unter den zehn nach Trefferquote acht mit negativer Summe (vorne Grid Long 65 % und Grid Short 58 %). Darum kommt eine Wahl
„Top 10 nach …“ in den Chart; voreingestellt ist die Trefferquote, wie entschieden.

**U167 (mit 23.68, nur Anzeige; vorab festgelegt):**
- **Daten:** alle Reihen aus `/labor/equity` (kein neuer Endpunkt). Trefferquote, Trades, Summe und Ø/Tag kommen aus
  `LAB.d.strategien`. Strategien ohne geschlossenen Trade stehen ausgegraut in der Liste („noch keine Trades“).
- **Standardauswahl („Top 10“):**
  - Kandidaten sind aktive Strategien mit mindestens 20 geschlossenen Trades.
  - Ausgenommen sind die Kontrollen (Zufall, Halten Long, die Zufalls-Kontrollen von Swing und Zyklus) und alte Regelversionen.
  - Rangfolge nach der gewählten Größe, absteigend: Trefferquote (Standard), Ø/Tag oder Summe. Bei Gleichstand entscheidet die Summe,
    dann der Name.
  - Die zehn ersten werden gezeigt. Erfüllen weniger als zehn die Bedingungen, sind es entsprechend weniger, mit Hinweis.
  - Zufall (gestrichelt) und Halten Long (grau) bleiben als Vergleichslinien dabei; beide haben ein eigenes Häkchen.
- **Liste unter dem Chart (zugleich Legende und Tabelle):**
  - Je Strategie Häkchen, Linien-Schlüssel, Name, Trefferquote, Trades und Summe in USD (Vorzeichenfarbe).
  - Sortiert nach der gewählten Größe; die Gruppen „Strategien“, „Vergleich“ und „alte Regelversionen“ (diese zugeklappt).
  - Knöpfe „Top 10“, „Alle“ und „Keine“.
  - Auf dem Handy als scrollbare Liste mit Zeilen ab 32 px Höhe.
- **Farben:** Die Farbe folgt der Strategie, nicht dem Rang.
  - Die acht Farben stammen aus der geprüften Palette; der Prüfer ist auf dem Chart-Hintergrund #01030a in allen Punkten grün.
  - Eine neu gewählte Strategie bekommt den kleinsten freien Platz: die Plätze 1–8 durchgezogen, 9–16 dieselben Farben gestrichelt.
    Ab der 17. Linie wird gedämpft grau gezeichnet; erkennbar ist sie dann über Liste und Hinweisfenster.
  - Abwählen gibt den Platz frei, ohne die anderen umzufärben. Auswahl und Plätze merkt sich der Browser; geht das nicht, gilt „Top 10“.
- **Achsen:** Die y-Achse richtet sich nach den eingeblendeten Linien (Null-Linie immer sichtbar), mit 4–5 runden Werten in USD; die
  x-Achse vom Laborstart bis jetzt. Linien 2 px, Gitter als feine durchgezogene Linien.
- **Hinweisfenster:** Ein senkrechter Strich folgt dem Finger bzw. der Maus. Das Fenster nennt den Zeitpunkt und je eingeblendeter
  Strategie den Stand dort, nach Wert sortiert: Wert vorn und fett, dahinter der Name, davor der Linien-Schlüssel. Fährt man über
  eine Zeile der Liste, tritt deren Linie hervor und die anderen werden blass.
- **Proben:**
  - node: Auswahl (zehn nach Trefferquote, ≥ 20 Trades, ohne Kontrollen und alte Versionen, Gleichstand nach Summe);
    Umschalten der Größe.
  - node: Farbplätze bleiben beim Ab- und Zuwählen; „Alle“, „Keine“ und „Top 10“; Speicher nicht verfügbar → „Top 10“ ohne Fehler.
  - Browserprobe mit 49 synthetischen Strategien auf 390 und 1.280 px Breite:
    - Standard zeigt 10 + 2 Linien;
    - ein Häkchen fügt eine Linie in freier Farbe hinzu, die übrigen behalten ihre;
    - die Achse folgt der Auswahl;
    - das Hinweisfenster listet alle eingeblendeten Werte;
    - keine Fehlerleiste, kein waagrechtes Scrollen;
    - Bildschirmfotos für den Nutzer.
  - Mutationen (je rot):
    - Rang nach Summe statt Trefferquote;
    - Mindestzahl der Trades entfernt;
    - Farbe nach Rang statt nach Strategie;
    - Achse über alle statt über die eingeblendeten Linien.
- **Wirkung:** keine auf Labor, Prognose oder Bilanzen.

**23.68 umfasst damit:** U156, U158–U167.

**Nachtrag 14.10. nachmittags: gebaut im Arbeitsstand** (`hl_viz.py`, `labEquityChart` neu; ausgeliefert bleibt 23.67):
- **Umsetzung wie festgelegt, mit drei Feinheiten aus der Browserprobe:**
  - Die Liste stellt Strategien, die die Mindestzahl erfüllen, nach vorn; so stehen die zehn gezeigten oben.
  - Auf dem Handy zeigt die Liste nur die gewählte Größe und die Summe; die dritte Spalte würde sonst seitlich scrollen.
  - Der Kopf lautet „Top 10 · nach Trefferquote ▾ · Alle · Keine“ (eine Zeile auch auf 390 px).
- **Achse:** runde Schrittweite nahe einem Fünftel der Spanne (−30.000 … 0 bei −36.615 … +4.290); der erste Entwurf lieferte dort
  nur zwei Werte, die node-Probe fing das.
- **Proben:**
  - node 13 von 13: Rangfolge, Mindestzahl, Kontrollen, Gleichstand, Größenwahl, Farbplätze stabil, Plätze 9–16 gestrichelt und
    danach grau, Achse, Treppenwert, Speicher kaputt, gesperrt oder fremd.
  - Browserprobe 40 von 40 auf 1.280 und 390 px mit den 51 Strategien des Berichts vom 11.10. (Kurven erfunden):
    - Standard 10 + 2 Linien, Farben in Rangfolge;
    - Häkchen nimmt den nächsten freien Platz, Abwählen färbt nicht um;
    - die Achse folgt der Auswahl;
    - das Hinweisfenster listet alle Werte richtig sortiert und passend zur Kurve;
    - „Alle“ (ab der 17. Linie grau), „Keine“ mit Hinweis, „Top 10“ mit denselben Farben wie zu Beginn, „nach Ø/Tag“;
    - alte Versionen aufklappbar, Auswahl übersteht das Neuladen;
    - kein seitliches Scrollen, keine Fehlerleiste;
    - gesperrter Speicher ergibt die Standardansicht ohne Fehler.
  - Mutationen 5 von 5 rot: Rang nach Summe, ohne Mindestzahl, Farbe nach Rang, Achse über alle, ohne Vergleichslinien.
  - Dashboard-Selbsttest (`--selbsttest-last`) grün, `node --check` beider Skriptblöcke grün.
  - Proben im Scratchpad `b77/` (`einheit.js`, `browser_eq.py`, `testdaten.py`); für 23.68 wiederholen.
- **Nebenbei:** Der Ton-Schalter las den Browserspeicher ohne `try`. Wäre der Speicher gesperrt, bräche das Hauptskript beim Laden ab.
  Jetzt steht das Lesen und Schreiben in `try`.
- **Palette:** die acht dunklen Stufen der geprüften Palette; der Prüfer ist auf #01030a in allen Punkten grün (schlechtestes Nachbarpaar
  unter Farbsehschwäche ΔE 8,4, normal 19,3).

## 3λλλ. Sammeldatei 14.10. 21:59 (7 Tage, 60 Berichte): Wochenlauf 14.10. 19:00 -- der Vollbericht brach nach 15 min ab (U168 neu); 23.67 läuft; v3 erstmals mit Gewichten; Abdeckung der Heatmap wieder bei 24–27 %; erste geschlossene Swing- und Zyklus-Trades (14.10. 22:30; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Eingang:** Sammeldatei der letzten 7 Tage (60 Berichte, 6.914 Zeilen), Kopf „Version 2026-09-23.67 · 6f5ae65d87“.
- Neu ist nur der Wochenlauf vom 14.10. 19:00 (19 Berichte). Alles vom 08.–13.10. stand schon in den Tagesdateien und ist
  ausgewertet (3λλ bis 3θθθ).
- Die Wiederholungsläufe von Zyklen, Swing, Hebel und Regime unterscheiden sich nur um die neu hinzugekommenen Tage (verglichen).

**A1 ✓:** 23.67 · 6f5ae65d87 läuft auf dem Pi, eingespielt am 13.10. um 22:44 (Konfluenz-Bericht: „seit der Regeländerung 23.67
(ab 13.10.2026 22:44)“; erste FRED-Abrufe von U153 13.10. 20:46 UTC). Die Termine 15.10. 20:15 (Makro USA) und 21:45 (Datentage)
stehen damit im Berichtsplan.

**Befund 1: Der Vollbericht brach nach 15 min ab (U168 neu).**
- 14.10. 19:00: „Exit Zeit · 900,1 s“. Im Bericht stehen nur „… messe 110 s Zuwachs“ und „abgebrochen nach 15 min“. Die übrigen
  18 Berichte liefen danach vollständig.
- **Laufzeiten aus den Berichtsköpfen:**

| Lauf | Datenbank | Laufzeit |
|---|---|---|
| 30.09. 19:00 (geplant) | 11,08 GB | 596 s |
| 07.10. 19:00 (geplant) | 13,64 GB | 779 s |
| 08.10. 01:43 (Handlauf) | 13,74 GB | 741 s |
| 14.10. 19:00 (geplant) | rund 16 GB (geschätzt, +0,37 GB je Tag) | über 900 s, abgebrochen |

  Die Laufzeit wächst mit der Datenbank: zwischen den beiden geplanten Läufen +183 s bei +2,56 GB, rund 70 s je zusätzlichem GB.
  Für den 14.10. (rund 16 GB) folgen daraus rund 950 s, über der Grenze von 900 s.
- **Ursache (geprüft):** `check_report.py` zählt jede Tabelle dreimal vollständig (`SELECT COUNT(*)`):
  - für die Spalte „Zeilen“ in „2. DATENBANK“;
  - gleich danach noch einmal als Ausgangsstand des Messfensters (`stand` in `main`);
  - nach dem Fenster ein drittes Mal für die Zeile „Kontrolle im 120-s-Fenster“.

  Jede Zählung liest die ganze Tabelle oder ihren kleinsten Index, zusammen also dreimal die ganze Datenbank vom USB-Datenträger.
  Nachgewiesen mit einer Spur aller Anweisungen auf dem Schema aus dem Code (Scratchpad `b78/spur.py`): 52 Tabellen, je genau
  drei Vollzählungen. Die Zählungen über Zeitstempel (Zuwachs je Stunde, größte Lücke) laufen dagegen über Indizes (`EXPLAIN QUERY
  PLAN`, `b78/plaene.py`: SEARCH; ohne nutzbaren Zeitindex sind nur acht kleine Tabellen, die größte `lb_stats_hist` mit rund
  380.000 Zeilen).
  - Rechnung (Handlauf 08.10.): 741 s minus Wartezeit (117 s) und übrige Teile (rund 25 s) ≈ 600 s für drei Durchgänge, also
    rund 200 s je Durchgang bei 13,74 GB.
- **Zweiter Mangel:** Der Bericht sammelt alle Zeilen und druckt erst am Ende. Bricht er ab, ist alles verloren, auch die fertigen
  Abschnitte 1–7. Der Berichtsplan hält eine Teilausgabe fest (`e.stdout`); es gab nur keine.
- **Eigener Fehler:** Die Laufzeiten standen in jedem Kopf (596 s, 779 s), der Name sagt „(2 min)“. Ich habe sie nicht verfolgt.
- **Wirkung:** nur dieser Bericht. Daten, Rechnungen und die übrigen Berichte sind nicht betroffen. Der Handlauf über die
  Debug-Liste hat keine Zeitgrenze (08.10.: 741 s) und liefert den Vollbericht weiter, nur langsam (heute geschätzt gut 15 min).
- **U168 (mit 23.68, nur Bericht; vorab festgelegt):**
  - Jede Tabelle wird einmal gezählt. Diese Zählung ist zugleich der Ausgangsstand.
  - Die Kontrolle zählt die Zeilen mit Zeitstempel in den letzten 2 min (über den Zeitindex), statt alle Tabellen ein drittes Mal
    zu zählen; die Wartezeit (rund 2 min) entfällt. `--minutes` bleibt die Länge dieses Rückblicks.
  - Jeder Abschnitt wird sofort ausgegeben, mit seiner Laufzeit. Ein Abbruch behält alles Fertige.
  - Zeitbudget der Zählung 8 min, die Heatmap (größte Tabelle) zuletzt. Was danach nicht mehr gezählt wird, steht als „nicht
    gezählt (Zeitbudget)“ da. So bleibt der Bericht unter der Grenze des Berichtsplans, auch wenn die Datenbank weiter wächst.
  - Berichtsplan: Läufe über zwei Drittel ihrer Grenze (600 s) bekommen im Kopf den Zusatz „nahe der Zeitgrenze“. Das hätte den
    Lauf vom 07.10. gemeldet.
  - Name im Menü: „★ VOLLBERICHT — alles auf einmal, zum Einfügen in den Chat (rund 5 min)“; Kennung `report` und Termin bleiben.
  - **Erwartung (vorab):** rund 4–5 min statt über 15 min (ein Durchgang statt drei, ohne Wartezeit).
  - **Proben:**
    - Spur der Anweisungen: jede Tabelle genau eine Vollzählung.
    - Ausgabe abschnittsweise: Nach einem künstlichen Abbruch enthält die Teilausgabe die fertigen Abschnitte.
    - Gleiche Zahlen wie bisher (Zeilen, Zuwachs je Stunde, Lücken) auf derselben Datenbank.
    - Zeitbudget mit kleiner Grenze: Heatmap „nicht gezählt“, alle anderen gezählt.
    - Kontrolle gegen eine eigene Zählung der Zeilen im Rückblick, auch für Tabellen mit Millisekunden.
    - Kopfzusatz „nahe der Zeitgrenze“ ab 600 s (Probe mit kurzer Grenze).
    - Mutationen rot: zweite Zählung wieder drin, Ausgabe erst am Ende, Heatmap nicht zuletzt, Kontrolle ohne Zeitgrenze.
    - Als Schritt im Selbsttest der Installation (`check_report.py --selbsttest`).
- **Entscheidung des Nutzers (Auswahl 14.10. 22:49):** „Mit dem nächsten Paket (Vorschlag)“. U168 kommt mit 23.68; kein
  Zwischenpaket, die Zeitgrenze bleibt. Bis dahin liefert der Handlauf den Vollbericht.

**Befund 2: Die Abdeckung der Heatmap ist wieder gestiegen (U159).**
- 14.10.: BTC, ETH und HYPE je 27 %, XMR 26 %, PAXG und ZEC je 24 %. Der Wert gehört zur Kaskaden-Kalibrierung von 17:05 (letzter
  Stand von `coverage` zu dem Zeitpunkt), der Bericht druckt ihn in der Zeile des Heatmap-Stands 19:15.
  - 11.10.: 7–19 %; 04.10.: 16–24 %; erster Kalibriertag: 25–29 %.
  - Der Audit vom 11.10. nannte als Mittel aller Messungen seit Beginn 22–34 % je Coin, Höchstwerte 28–43 %.
- Zeitlich passt das zu den Neustarts:
  - 04.10.: kurz nach dem Einspielen von 23.44 (damals schon notiert: „ob die Abdeckung nach dem Neustart wieder steigt“);
  - 11.10.: vier Tage nach dem Neustart vom 07.10. 21:29;
  - 14.10.: 20 Stunden nach dem Neustart mit 23.67.

  **Vermutung, nicht geprüft:** Kurz nach einem Neustart ist die Abdeckung niedrig, bis der Poller alle Konten wieder abgefragt hat,
  und in den Tagen danach sinkt sie wieder.
- **Mechanik im Code:** In Heatmap und `coverage` gehen nur Positionen, deren Konto in der letzten Stunde abgefragt wurde
  (`max_pos_age` 3.600 s); die übrigen zählt `snapshot_meta.n_stale_dropped`. Am 08.10. waren 65.926 Konten mit Position „fällig“,
  und das Fill-Nachholen stellte 258 Konten wegen des Gewichtsbudgets zurück. Ein Poller, der zurückfällt oder weniger Budget bekommt,
  erzeugt genau dieses Muster. Ebenso möglich: mehr Sperren (dauerhaft 75 → 92 in einer Woche), Pool-Wechsel, gewachsenes OI.
- **U159 präzisiert (vorab, bevor die Daten angesehen sind):** Der Bericht zeigt je Coin und Tag die Abdeckung (Mittel, kleinster,
  größter Wert), verfolgte Größe und OI. Dazu je Tag aus `snapshot_meta`: Positionen im Stand, wegen Alters ausgelassene Positionen,
  Alter der Abfragen (Median, 90 %), Rückstand. Die Neustarts (Laufzeit unter 15 min) stehen als Marke. Den Anteil des Pollers am
  API-Gewicht zeigt er, soweit `api_load` reicht (rollierend, rund zwei Tage). Beschreibend: Abdeckung am ersten Tag nach jedem
  Neustart gegen die Tage danach. Keine Änderung am Recorder, bevor die Ursache feststeht.

**Fusion und v3 (U108, Zwischenstand; Urteil am 25.10.):**
- 4 h, nur live gestellt, alle Coins: 287 Blöcke aus 65 Zeitblöcken (11.10.: 199 aus 47).
  - Kriterium 1, Fusion minus Basisrate: −0,0034 ± 0,0024 je Block (1,4 SE; belegt erst jenseits von 2 SE).
  - Kriterium 2: gegen v1 +0,0084 ± 0,0051 (1,6 SE schlechter), gegen v2 −0,0060 ± 0,0027 ✓, gegen v3 −0,0031 ± 0,0019, gegen
    Analog −0,0108 ± 0,0236; kein ✗.
  - Hochgerechnet auf rund 130 Zeitblöcke am 25.10. (Standardfehler mal √(65/130)): Abstand zu v1 bei gleichem Mittel rund 2,3 SE
    (✗), Kriterium 1 rund −2,0 SE. Die Erwartung aus `KONZEPT_Fusion.md` 6.1 gilt weiter (✗ gegen v1); Kriterium 1 kann knapp in
    beide Richtungen fallen. Ohne Kriterium 2 bleibt die Fusion so oder so im Schatten.
- **v3 hat erstmals Gewichte:** 4 h λ_β 1,0 statt 10, c = 1 (bestes 1), OOF-Brier-Skill 0,0108 (n 807, 180 Zeitblöcke); 24 h
  c = 1, OOF 0,0097 (n 155, 30 Zeitblöcke). Am 11.10. waren alle Gewichte 0 und c = 0.
  - Größte gemeinsame Gewichte (4 h): „Trend lang“ negativ (−0,76 bis −1,43 Log-Odds je Familienwert 1), „Funding“ positiv
    (+0,38 bis +0,73). 24 h: „Trend lang“ −0,45 bis −0,86, dann „Momentum kurz“ +0,14 bis +0,27.
  - v3 ist nicht geändert. Das Tor (kleinstes c innerhalb eines Standardfehlers vom besten) hat nach seiner festen Regel geöffnet.
  - Live liegt v3 je Coin bei 0,698–0,709 Nats je Block (n 22–58, der größte Teil noch aus der Zeit mit c = 0), alle über dem
    Münzwurf ln 2 = 0,6931.
  - **Kriterium 3** verlangt OOF-Skill > 0 in den wöchentlichen Läufen und über drei Wochen stabile Vorzeichen. Bis 25.10. gibt es
    nur zwei Wochenläufe mit Gewichten (14. und 21.10.): Kriterium 3 bleibt am 25.10. ein Zwischenstand. Über das Umschalten
    entscheiden 1 und 2.
- 24 h (beschreibend): alle Blöcke gegen die Basisrate −0,0224 ± 0,0072 ✓, gegen v1 +0,0194 ± 0,0083 ✗, gegen Analog
  +0,0285 ± 0,0134 ✗.
- Kriterium 4 (Labor): „Fusion mit Kostenschwelle“ unverändert 16 Trades (Ø +0,025 %), „Prognose Fusion“ 50 Trades (Ø −0,312 %);
  Glück 100 %: Zwischenstand.

**Kaskaden-Gleichung (U115) und Magnet-Test (U110), Zwischenstand:**
- **Kaskaden:** nichts belegt (Kalibrierung 14.10. 17:05, 36,6 Tage Heatmap).
  - BTC 1 h erfüllt drei der vier Bedingungen (Y 0,25; gegen Y = 0 +0,0155 ± 0,0070, 2,2 SE; Placebo ohne Befund), der
    Seitenspiegel nicht (+0,0078 ± 0,0057).
  - Der Kandidat vom 11.10., HYPE 4 h, steht wieder bei Y = 0. Wechselnde Kandidaten knapp über 2 SE sind bei elf Coin-Horizonten
    je Lauf zu erwarten.
  - Vorhergesagt gegen eingetreten (out-of-fold) 22 von 22 innerhalb 2 SE. In der Klassentabelle wie am 04.10. XMR 4 h: in der
    oberen Klasse seltener als vorhergesagt (≥ 2 σ 6,0 → 0,9 %, n 109) -- Aufgabe für U109.
  - Richtung 47 % ± 3 % (z −1,0), ETH 37 % (z −1,9).
- **Magnet:** nichts belegt (Rechnung 14.10. 17:20).
  - BTC 1 h groß: +7,7 ± 4,0 Punkte (Spiegel +10,6 ± 4,7, Placebo +10,4 ± 4,7), wirksam 58 von 60. Am 25.10. voraussichtlich
    urteilsfähig; es fehlt dann noch der Überschuss über 2 SE.
  - HYPE 1 h mittel: +8,8 ± 3,3, aber nur 48 wirksame Fälle und der Spiegel unter 2 SE.
  - Nullmodell an Zufallsniveaus 86 von 88 innerhalb 2 SE.
- Beide rechnen mit der Karte, die die Abdeckung erlaubt (Befund 2); die 36 Tage mischen Zeiten mit 7 % und mit 27 %.

**TradeLabor (U99) und Grid (U101, erster Blick):**
- 6.497 Trades, netto −120.835 USD (seit 11.10. −16.002 USD in drei Tagen), Gebühren 46.120 USD (38 %).
  - 0 bewährt, 8 negativ. Neu negativ: Kaskaden-Fortsetzung, Smart Money folgen, Kauf-/Verkaufspreise der Prognose; nicht mehr
    negativ: Ausbruch nach Ruhe, Wale folgen. Die Stufe „negativ“ ist ein Stand (t ≤ −2 ab 30 Blöcken), kein Urteil.
  - Glück überall 100 %. Zufall (Kontrolle) −0,294 % je Trade (t −2,3).
- **Folgen gegen dagegen** (Ø netto je Trade): Leaderboard −0,120 % / −0,055 %, Smart Money −0,564 % / +0,109 %, Wale −0,109 % /
  −0,139 %, Pool −0,153 % / −0,114 %, Elite +0,023 % / −0,155 %. Bei den Walen liegt „folgen“ jetzt vorn. Das Bild vom 11.10.
  („folgen“ in allen vier Fluss-Paaren hinten) hielt keine drei Tage. Ein Paar-Vergleich mit Fehler steht nicht im Bericht; je
  Strategie liegt nur „Smart Money folgen“ jenseits von |t| 3 (t −3,1, Glück 100 %).
- Familie Orderfluss −35.227 USD (29 % des Gesamtverlusts).
- **Grid nach 14 Tagen (U101, erster Blick):**
  - Long −1.506 USD (Ø/Tag −0,234 % des Coin-Kontos, t −2,0 auf Tagen), Short −2.251 USD (−0,350 %, t −3,5).
  - 930 bzw. 941 Lose, Treffer der Lose 64 % bzw. 59 %.
  - Notausstiege: Long 48 bei 119 Aufbauten, Short 59 bei 114. Viele kleine Gewinne, wenige große Verluste.
  - Der Rest von U101 (je Coin und Tag, gehaltene Lose gegen Stufenverkäufe, Kosten der Notausstiege, XMR getrennt) braucht die
    Tagestabelle (U163) und den Bericht je Coin (U161), beide mit 23.68. „Bewährt“ braucht ≥ 30 Tage.
- **Erste geschlossene Swing- und Zyklus-Trades:** fünf, alle am Stop (−1,00 bis −1,02 R, zusammen −506 USD bei 100 USD Risiko je
  Trade):
  - Ausbruch nach Ruhe (ETH short, −3,8 %), Trend-Ausbruch (ZEC short, −12,4 %), Rücksetzer im Trend (−7,1 %), Zyklus Z1 und Z2
    (derselbe Trade, −12,3 %).
  - Mit U164 (feste Größe) wären die Verluste in USD bei den weiten Stops viel größer (−12,4 % von 10.000 USD); R bleibt gleich.
  - Fünf Trades sagen nichts; der Vorwärtsbeleg braucht Monate.

**Übrige Wochenberichte (beschreibend, nichts Neues belegt):**
- **U8 Empfehlungen** (33 Tage, je Coin 32–33 Fälle; „Markt“ = sofort als Taker zum Prognosekurs, ohne Spread): Limit gegen Markt
  bei Käufen über alle Coins +0,06 % (−0,08 … +0,19).
  - Zwei Intervalle ohne Null: BTC-Kauf +0,05 % (+0,01 … +0,10) und XMR-Kauf +0,42 % (+0,15 … +0,68).
  - BTC ist bei zwölf Vergleichen kein Beleg. XMR hielte Holm stand (z rund 3,1). Ohne Vorhersagekraft und ohne Rückkehr der
    Kurse wäre nur der Gebührenvorteil des Limits zu erwarten (rund +0,02 %). Nach der Füllung stieg XMR im Mittel weiter (+0,27 % in
    4 h): Rücksetzer, die sich erholten.
  - Nachträglich gefunden, 33 Fälle, ein dünner HIP-3-Markt: nur beschreibend. Ein Urteil bräuchte eine vorab festgelegte
    Vorwärtsprüfung mit Zufallskontrolle (Limit im selben Abstand zu zufälligen Zeiten); nicht im Plan, nur auf Wunsch.
  - **Eigener Fehler beim Entwurf dieses Abschnitts:** Ich hatte den XMR-Vorsprung zuerst dem Abstand der Markt-Einstiege zur
    Buchmitte zugeschrieben (U96). Beim Gegenlesen (ein unabhängiger Prüfer fand dazu eine XMR-Order mit nur 3 bps Abstand) zeigte
    der Code: U8 rechnet den Markt-Kauf ohne Spread. Weitere Korrekturen aus dem Gegenlesen: 19 statt 20 Berichte im Wochenlauf,
    Wartezeit des Handlaufs 117 s, Wachstum rund 70 s je zusätzlichem GB, „alle |t| < 3“ galt nicht mehr.
- **Kalibrierung v2:** c = 0 überall außer XMR 4 h (c 1,0, OOF-Skill 0,0275; schon am 07.10. mit c 0,9 an).
- **Makro:**
  - 60 Reihen frisch, FRED 21 von 21 mit Schlüssel.
  - **U153 erstmals auf dem Pi:** Arbeitslosenquote 4,2 % (September), Stellen +29 Tsd. (3-Monats-Mittel 50,7), Verbraucherpreise
    3,40 % zum Vorjahr (August), ohne Lebensmittel und Energie 2,45 %, Erzeugerpreise 5,44 %, Erstanträge 198 Tsd. (4-Wochen-Mittel);
    alle Korrelationen mit BTC im Zufallsband (±0,41 bzw. ±0,28). Lücke Oktober 2025 vermerkt.
  - Der nächste Termin der Verbraucherpreise ist laut Liste der 10.11.; der September-Wert war also am 14.10. um 14:30 fällig, nach
    dem Tagesabruf (10:46). **Nachprüfung 15.10. 20:15:** Verbraucherpreise mit Wert für 2026-09.
  - Nächste Termine: Erzeugerpreise und Erstanträge 15.10. 14:30, Arbeitsmarktbericht 06.11., Verbraucherpreise 10.11.
  - Signale: 11 live (alle Verkauf); 4 von 337 Tests „belegt“ bei 11–17 erwarteten Fehlurteilen; Live gegen Nachrechnung 576 von 576
    gleich.
- **Sperren und Pool:** dauerhaft gesperrt 92 (07.10.: 75), vorläufig 25 (23), freigegeben 37 (32). Pool 838 Konten, davon 101
  gesperrt (07.10.: 799/88). Darwin-Liste 4 Mitglieder (07.10.: 1); Schatten U136 im Zwischenstand (Band 14 von 60 Entscheidungen,
  Urteil 18.11.).
- **Ereignis-Profile (U43):** kein Treiber über der Schwelle (Rutsche 42 Fälle, Anstiege 45). **Vorbedingungen (U131):** Abgleich mit
  den Kursdaten wie bisher, nicht Erfasstes mit Grund.
- **Treiberfamilien:** keine aufgestiegen; 4 von rund 55 Zellen mit |z| ≥ 2, ohne jede Kante wären rund 3 zu erwarten.
  **Heatmap-Anker:** nichts belegt. **Konfluenz:** nach 4 h 54 % richtig gegen 53 % Zufall (83 Fälle); seit der Regeländerung 23.67
  ein Fall. (Nachtrag 23:15: Die Bilanz mischt Einträge aus verschiedenen Datenquellen und damit Regelwerken, 3μμμ, U170.)
- **Elite:** 4 Konten; ein „WEICHT AB“ (0x66f8: Datenbank short 14,8 Mio, live flach), einzeln.

**Kleinigkeit im Makro-Bericht (U169 neu, P3, mit 23.68, nur Bericht):**
- Die Zeilen „USA“ nennen die Korrelation ohne ihr Zufallsband (das Dashboard zeigt es).
- Die FRED-Release-Nummern stehen da wie Anzahlen („Verbraucherpreise = 10 „Consumer Price Index““).
- Die Wochentage der Termine sind englisch („Thu 15.10.“).
- Mit 23.68: „Korrelation mit BTC 0,18 (Zufallsband ±0,41, kein belegter Zusammenhang)“, „FRED-Release 10“, deutsche Wochentage.
  Probe: Textzeile gegen `_regime`; Mutation (Band fehlt) rot.

**23.68 umfasst damit:** U156, U158–U169 (U167 gebaut). Vorschlag weiterhin: nach den Berichten vom 15./16.10.

**Was der Nutzer tun kann:** nichts Dringendes. Wer den Vollbericht vor 23.68 braucht, startet ihn von Hand in der Debug-Liste (ohne
Zeitgrenze, gut 15 min). Nächste Berichte: 15.10. 20:15 Makro USA (September-Verbraucherpreise sollten da sein) und 21:45
Datentage (erster Lauf auf dem Pi); 16.10. 21:45 Datentage; 18.10. 08:30 Ausblick, Aktienmarkt (Farside, U165) und Chartbild;
21.10. 19:00 Wochenbericht; 25.10. Urteile U108, U115, U110.

Lehre: **Eine Zählung, die mit der Datenbank wächst, läuft einmal und mit Zeitgrenze, und ein Bericht gibt aus, was fertig ist.
Laufzeiten aus den Berichtsköpfen gehören in jeden Wochenblick.**

## 3μμμ. Bild des Nutzers 14.10. 22:04: derselbe Skriptfehler (U166), dazu „NaN %“ beim nächsten FVG; der Feldvergleich aller drei Quellen findet drei fehlende Felder im Binance-Modus (U166 erweitert); die Konfluenz-Bilanz mischt die Quellen (U170 neu) (14.10. 23:15; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Meldung (Bild, 22:04:26, „Fehler entdeckt“):**
- Sechsmal „Skriptfehler: Uncaught TypeError: Cannot read properties of undefined (reading 'toFixed') (Zeile 2961)“ über dem
  Kurs-Chart (BTC, 146 Kerzen, 14 Liquidationsmarken).
- Darunter die Zeile „FVG: 3 offen (0 bull / 3 bear), 14 gefüllt · nächstes bear 82.925,7–83.619,9 (NaN %, 21 % gefüllt)“.

**1. Der Skriptfehler ist U166** (3ιιι): dieselbe Zeile 2961 (`near.x_vol.toFixed` in `tipChart`), Quelle „Binance Daten“.
- Sechsmal in derselben Sekunde: Jede Bewegung des Fingers in der Nähe einer eingetretenen Binance-Marke wirft ihn erneut.
- Die Wahl der Quelle merkt sich der Browser (`hl_src`). Deshalb kommt der Fehler wieder, bis die Quelle umgestellt oder das Paket
  da ist.

**2. Neu: „NaN %“ beim nächsten FVG.**
- **Ursache:** `attach_binance` ersetzt im Binance-Modus die FVGs durch `find_fvgs(Binance-Kerzen)`, ohne das Feld `dist`
  (Abstand zum Kurs), das `load_chart` im Hyperliquid-Modus setzt. Die Infozeile rechnet `(nearest.dist*100).toFixed(2)`, also
  „NaN“.
- **Folge:** Die Sortierung nach Abstand vergleicht NaN. „Nächstes“ ist dann das älteste offene FVG, nicht das nächste.
- **Dazu:** Der Binance-Weg nimmt die Mindestgröße fest mit 0,05 % statt der Auswahl „FVG-Mindestgröße“.

**3. Feldvergleich aller drei Quellen.**
- **Aufbau:** synthetische Datenbank mit dem echten Schema; `/chart`-Nutzlast für Hyperliquid, Binance und Data Mix Fusion; ohne Netz,
  das Binance-Buch nachgebildet; Scratchpad `b79/felder.py`.
- **Ergebnis:** Im Binance-Modus fehlen genau drei Felder, sonst nichts:

| Objekt | fehlt im Binance-Modus | Wirkung |
|---|---|---|
| Liquidationsmarken (`levels`) | `x_vol` | Skriptfehler im Hinweisfenster (U166); alle Linien dünn gestrichelt |
| FVGs (`fvgs`) | `dist` | „NaN %“ und falsches „nächstes“ in der Infozeile |
| Orderbuch-Stufen (`stops.clusters`) | `dist` | Orderbuch-Tabelle und Hinweisfenster zeigen „NaN %“. `keyLevels` filtert alle Stufen aus (Abstand NaN), also keine Schlüsselniveaus (Support, Resistance) im Panel, im Chart und in der Konfluenz, ohne Meldung |

  Data Mix Fusion hat alle Felder (die Abstände rechnet `attach_binance` dort nach).
- **Nachgestellt** (node mit `keyLevels` aus der ausgelieferten Seite 23.67, `b79/keylevels.js`): Buchstufen ohne `dist` → Support
  und Resistance `null`, mit `dist` gefunden; zwei offene bear-FVGs ohne `dist` → „nächstes“ ist das erste der Liste (82.925,7, obwohl
  82.100 näher liegt), Abstand „NaN %“ wie im Bild.

**U166 erweitert (mit 23.68, wie entschieden; vorab festgelegt):**
- **Server:** `attach_binance` setzt `dist` für FVGs (wie `load_chart`: bull zum unteren, bear zum oberen Rand, relativ zum
  Binance-Kurs) und für die Orderbuch-Stufen; die FVG-Mindestgröße kommt aus der Anfrage.
- **Seite:** wie geplant „liquidiert … USD · n Liquidationen“ für eingetretene Marken. Jede Stelle, die einen Abstand formatiert,
  zeigt bei fehlendem Wert „—“ statt „NaN“.
- **Proben:**
  - Feldvergleich als Selbsttest: je Objektart dieselben Felder in allen drei Quellen; ausgenommen `x_vol` der eingetretenen Marken
    (dort zählt die Zahl der Liquidationen).
  - Browserprobe mit allen drei Quellen: keine Fehlerleiste, kein „NaN“ im Chartbereich (Infozeile, Tabellen, Hinweisfenster),
    Schlüsselniveaus auch im Binance-Modus.
  - Mutationen rot: `dist` der FVGs weg, `dist` der Buchstufen weg, Mindestgröße fest.

**4. Die Konfluenz-Bilanz mischt die Quellen (U170 neu).**
- Die Konfluenz rechnet der Browser aus der Nutzlast der gewählten Quelle (`computeSignal` mit `LAST_CHART`). Im Binance- und im
  Fusion-Modus gelten andere Regeln:
  - Binance-Modus: keine Hyperliquid-Cluster (die Marken sind eingetretene Liquidationen und zählen nicht), keine Wal-Punkte, und
    es fehlen die Schlüsselniveaus (Punkt 3);
  - Fusion-Modus: die Schlüsselniveaus kommen aus den Orderbüchern aller Börsen statt nur aus den Orders der Großkonten;
  - in beiden dazu die Binance-Regeln (Taker-Flow über die Börsen, Konten-Hinweis, laufende Kaskade).
- `konfluenz_loggen` speichert die Quelle nicht (Schlüssel Coin und 15-min-Slot, die erste Meldung gewinnt). Die Bilanz (zuletzt 83
  Fälle, nach 4 h 54 % gegen 53 % Zufall) mischt also unbekannte Anteile verschiedener Regelwerke. Nachträglich trennen lässt sich
  das nicht.
- Seit wann die Seite des Nutzers auf „Binance Daten“ steht, ist unbekannt (heute um 08:14 und 22:04 ja).
- **Eigener Konstruktionsfehler** (Bilanz seit 24.09.): die Quelle nicht mitgeschrieben.
- **U170 (mit 23.68, vorab festgelegt):**
  - Die Seite meldet die Quelle mit (`src`). Eine neue Tabelle hat Coin, Slot und Quelle im Schlüssel.
  - Die Bilanz zeigt Hyperliquid (die Regel, wie sie gebaut ist) als Hauptzeile, Binance und Fusion getrennt, die bisherigen
    Einträge als „Quelle unbekannt (vor 23.68)“. Der Debug-Bericht ebenso.
  - Proben: zwei Quellen im selben Slot zählen getrennt; alte Zeilen landen in „unbekannt“; Mutation (Quelle nicht gemeldet) rot.
- Die Lesart der Konfluenz-Bilanz in 3λλλ gilt damit nur für die Mischung.

**Was der Nutzer tun kann:** Bis zum Paket oben die Datenquelle auf „Hyperliquid Daten“ stellen, wenn die Binance-Ansicht nicht
gezielt gebraucht wird. Dann verschwinden Fehlerleiste und „NaN %“, und die Konfluenz rechnet nach ihrer gebauten Regel. Die
Fehlerleiste geht mit dem Neuladen der Seite weg.

**23.68 umfasst damit:** U156, U158–U170 (U167 gebaut).

Lehre: **Eine zweite Datenquelle prüft man mit einem Feldvergleich der ganzen Nutzlast, nicht Fund für Fund. Und was der Browser
aufzeichnet, trägt die Quelle mit, aus der es gerechnet wurde.**

## 3ννν. Berichte vom 15.10.: Verbraucherpreise für September da (Nachprüfung U153 ✓); Datentage-Studie erster Lauf: H1 und H2 belegt, die Erwartung „seit 2024 kleiner“ war falsch, die Gegenprobe weicht ab; Wahl des Nutzers: Hinweis jetzt, Rechnung nach dem 25.10. (U171–U173 neu) (15.10. 22:30; nur Dokumente, Version 2026-09-23.67 unverändert, Opus 5.5)

**Eingang:** Sammeldatei 15.10. 22:04 mit zwei Berichten: Makro-Stand 20:15 und Datentage-Studie 21:45. Kopf „Version
2026-09-23.67 · 6f5ae65d87“ (A1 ✓).

**Makro-Stand (U153), Nachprüfung aus 3λλλ ✓:**
- Verbraucherpreise mit Wert für 2026-09: Vorjahresrate 3,74 % (August 3,40 %), ohne Lebensmittel und Energie 2,56 % (2,45 %);
  Monatsrate saisonbereinigt 0,65 % (Kern 0,33 %). Vier neue Fassungen in `mk_fassung` (2.724 → 2.728).
- Erzeugerpreise und Erstanträge vom 15.10. 14:30 fehlen noch: Der Tagesabruf lief um 08:46 UTC, vor der Veröffentlichung. Sie
  kommen mit dem Abruf am 16.10.
- Nächste Termine: Erstanträge 22.10., Arbeitsmarktbericht 06.11., Verbraucherpreise 10.11., Erzeugerpreise 13.11. (jeweils 14:30
  hier; die Wochentage stehen im Bericht noch englisch, U169).
- Sonst wie am 14.10.: 60 Reihen frisch, FRED 21 von 21; Signale 10 live, alle Verkauf („Kurzfrist-Kostenbasis 1 J“ fiel unter
  Perzentil 90); 4 von 337 Tests belegt; Live gegen Nachrechnung 640 von 640 gleich.

**Datentage (U154), erster Lauf auf dem Pi** (`KONZEPT_Makro.md` 11.7 und 11.9):
- **Daten:** BTC und ETH (`swing.db`, 30-min-Kerzen) 01.01.2020–14.10.2026, 1.705 Werktage. Termine: Verbraucherpreise 86,
  Arbeitsmarktbericht 84, Erzeugerpreise 85, Erstanträge 347.
- **H1 Verbraucherpreise: belegt.** Faktor der Varianz im Fenster 8:30–10:30 New York 2,45 (90 %: 1,95–3,08); p 0,0001 (der
  kleinste mögliche Wert bei 10.000 Ziehungen), nach Holm 0,0002; Hälften 2,61 / 2,29.
- **H2 Arbeitsmarktbericht: belegt.** Faktor 1,90 (1,58–2,29); p 0,0001, nach Holm 0,0002; Hälften 1,91 / 1,89.
- **Je Jahr (beschreibend):**
  - Verbraucherpreise: 2020 0,98 · 2021 1,49 · 2022 8,65 · 2023 2,47 · 2024 3,09 · 2025 2,34 · 2026 2,27.
  - Arbeitsmarkt: 2020 1,95 · 2021 1,13 · 2022 2,66 · 2023 1,65 · 2024 1,81 · 2025 2,23 · 2026 2,42.
- **Beschreibend:**
  - ganzer UTC-Tag: Verbraucherpreise 1,19, Arbeitsmarkt 1,02;
  - mittlere absolute Rendite im Fenster gegen die Vergleichstage: 1,72× bzw. 1,29×;
  - BTC und ETH gleich (2,43/2,47 bzw. 1,95/1,85);
  - Erzeugerpreise 1,09 (p roh 0,23) und Erstanträge 1,05 (p roh 0,22): kein Effekt zu sehen.
- **Erwartung vorab gegen Ergebnis:**
  - H1 belegt mit Faktor 1,5–3 ✓ (2,45); 2022 trägt viel ✓ (8,65), aber beide Hälften liegen über 2.
  - H2 belegt mit Faktor 1,3–2 ✓ (1,90).
  - **„Seit 2024 kleiner“ ✗:** Verbraucherpreise 2024–2026 bei 2,3–3,1, Arbeitsmarkt bei 1,8–2,4, eher größer als 2020–2023.
    Der Effekt ist gegenwärtig, nicht nur ein Nachhall von 2022.
  - Über den ganzen Tag kleiner ✓ (1,19 bzw. 1,02): Der Effekt sitzt in den zwei Stunden nach der Veröffentlichung.
- **Die Gegenprobe weicht ab (erwartet: an keinem Termin):**
  - Verbraucherpreise: ALFRED 80 Tage, Kalender 86; nur im Kalender 6, nur in ALFRED 0. Arbeitsmarkt: ALFRED 81, Kalender 84;
    nur im Kalender 3, nur in ALFRED 0.
  - Jede Erstveröffentlichung steht also im Kalender; der Kalender hat zusätzliche Tage.
  - **Vermutung, nicht geprüft** (der Bericht nennt die Tage nicht, → U171): die Termine aus dem Stillstand der US-Regierung im
    Herbst 2025. Der Kalender führt dann die ursprünglichen Tage verschobener Veröffentlichungen und die ausgefallene
    Oktober-Veröffentlichung. Beim Arbeitsmarkt wären das genau drei Tage (3. Oktober, 7. November, 5. Dezember 2025). Bei den
    Verbraucherpreisen kämen drei solche Tage, der 14.10.2026 (ALFRED zuletzt am 13.10. geholt) und zwei ungeklärte zusammen.
  - **Wirkung aufs Urteil:** Solche Tage zählen als Termin ohne Veröffentlichung und verkleinern den Faktor. Hätten fünf
    Verbraucherpreis-Tage bzw. drei Arbeitsmarkt-Tage den Faktor 1, läge er ohne sie rechnerisch bei rund 2,6 statt 2,45 bzw.
    1,95 statt 1,90. Das Urteil hält damit erst recht; die Abweichung von der Erwartung bleibt festgehalten.
- **Zweiter Lauf 16.10. 21:45:** sollte dasselbe zeigen (ein Tag mehr, an dem nur Erzeugerpreise und Erstanträge lagen).

**Entscheidung des Nutzers (Auswahl 15.10., kurz nach 22:06): „Hinweis jetzt, Rechnung später (Vorschlag)“.**
- **U172 Hinweis an Datentagen (mit 23.68, nur Anzeige; vorab festgelegt):**
  - **Wann:** an Tagen mit Verbraucherpreisen oder Arbeitsmarktbericht laut `mk_termin`, von 00:00 Ortszeit bis 10:30 New York
    (zwei Stunden nach der Veröffentlichung). An Tagen nur mit Erzeugerpreisen oder Erstanträgen kein Hinweis (kein Effekt
    gemessen).
  - **Wo:** eine Zeile oben im Dashboard über dem Chart; im Makro-Tab „USA“ bei den Terminen der nächsten 14 Tage dieselben Zahlen.
  - **Text (Muster):** „Heute 14:30: Verbraucherpreise der USA. In den zwei Stunden danach waren die Kursausschläge von BTC und
    ETH seit 2020 im Mittel rund 1,7-mal so groß wie an anderen Werktagen (Datentage-Studie, belegt); über den ganzen Tag kaum
    größer. Keine Richtung.“ Uhrzeit in Ortszeit, auch in der Woche 25.10.–01.11. (13:30).
  - **Zahlen:** aus dem jüngsten Studienlauf. Die Studie legt ihr Ergebnis dazu in `makro.db` ab (`mk_meta`, Schlüssel
    „datentage:stand“: Faktoren, Ausschlag-Verhältnis, Urteil, Datum). Ist eine Hypothese im jüngsten Lauf nicht belegt oder fehlt
    der Stand, nennt der Hinweis nur den Termin. Ein Stand älter als 60 Tage trägt sein Datum.
  - **Keine Wirkung** auf Konfluenz, Prognose, Treiber, Labor und Ausblick (Zusagen bis 25.10.).
  - **Proben:** Hinweis an einem nachgebildeten Verbraucherpreis-Tag ab 00:00 bis 10:30 New York, danach weg; an Erzeugerpreis-
    und Erstanträge-Tagen keiner; Ortszeit in der Woche 25.10.–01.11.; ohne Stand oder ohne Urteil nur der Termin; Konfluenz- und
    Prognose-Nutzlast mit und ohne Hinweis gleich; Browserprobe Desktop und Handy. Mutationen rot: Zeitzone fest, Hinweis auch an
    Erzeugerpreis-Tagen, Ende ohne die zwei Stunden, Zahl ohne Urteil.
- **U173 Termine in der Schwankung der nächsten Stunden (nach dem 25.10.; Festlegung im Detail vor dem Bau):**
  - Ziel: σ für 1 h und 4 h, die Grundlage von Kaskaden-Gleichung, Magnet-Nullmodell, Kostenschwelle der Fusion und Labor-Stops
    (heute 7-Tage-Schwankung; U109 HAR).
  - Kandidat: HAR auf 30-min-Renditen mit Termin-Faktor im Fenster 8:30–10:30 New York an Verbraucherpreis- und Arbeitsmarkttagen,
    der Faktor nur aus der Vergangenheit geschätzt.
  - Prüfung vorwärts (ab 2023): übernommen nur, wenn besser als HAR ohne Termine über alle Fenster und in beiden Hälften
    (Verlustmaß und Test vor dem Bau festgelegt); beschreibend getrennt nach Fenstern mit und ohne Termin.
  - Einbau in ein Modell erst nach dessen Urteil (U108, U115, U110 am 25.10.) und je mit eigener Entscheidung.
- **Nicht in den 4-Wochen-Ausblick:** Zwei Stunden im Monat verschieben Spannen über Wochen kaum (ganzer Tag 1,19 bzw. 1,02).
- **U171 (P3, mit 23.68, nur Bericht):** Die Gegenprobe nennt die abweichenden Tage. Der jüngste Termin, den ALFRED noch nicht hat,
  steht als „noch nicht in ALFRED (Abruf monatlich)“. Beschreibend und nachträglich, ohne Urteil: der Faktor nur mit Tagen, die
  beide Quellen kennen.

**23.68 umfasst damit:** U156, U158–U172 (U167 gebaut). U173 folgt nach dem 25.10.

Lehre: **Weicht eine Gegenprobe ab, muss der Bericht die Tage nennen; eine Zahl allein lässt nur Vermutungen zu.**

**Nachtrag 16.10. 22:40 (Upload 22:31): zweiter Lauf 16.10. 21:46 bestätigt den ersten.**
- Daten bis 15.10. (1.706 Werktage); H1 und H2 Zahl für Zahl gleich (kein neuer Verbraucherpreis- oder Arbeitsmarkttag), Gegenprobe
  unverändert 6 bzw. 3 (ALFRED wird monatlich geholt, der 14.10. fehlt dort weiter).
- Mit dem 15.10. stiegen die beschreibenden Werte für Erzeugerpreise (85 → 86 Termine, 1,09 → 1,12, p roh 0,19) und Erstanträge
  (347 → 348, 1,05 → 1,06, p roh 0,20). Rechnerisch schwankte das Fenster an diesem Tag mehrfach so stark wie an den
  Vergleichstagen (wegen der Rundung nur grob bestimmbar). Ein Tag ändert am Bild nichts.

## 3ξξξ. Version 2026-09-23.68 gebaut und geprüft: U156, U158–U172 -- Vollbericht in einem Durchgang, Binance-Modus ohne Fehler, Konfluenz je Quelle, Hinweis an Datentagen, Labor (XMR-Gebühr, feste Größe, Tabellen), Farside, Abdeckung, Kriterium 5, Stressfächer in der Größe der Phase, CryptoQuant (17.10.; Version 2026-09-23.68 · e195e119f2, Opus 5.5)

**Auftrag:** Wahl des Nutzers „Jetzt bauen (Vorschlag)“ nach den Berichten vom 15./16.10. Gebaut wurde alles, was für 23.68 festgelegt
war. Jeder Punkt hat Proben gegen eine eigene Rechnung, Mutationen und, wo die Seite betroffen ist, eine Browserprobe auf 1.280 und
390 px. Das Protokoll steht im Scratchpad unter `b80/protokoll.md`.

**Was das Paket ändert:**
- **U168 Vollbericht:**
  - Jede Tabelle wird genau einmal gezählt (bisher dreimal), die Heatmap zuletzt, mit einem Zeitbudget von 8 min.
  - Jeder Abschnitt erscheint sofort mit seiner Laufzeit. Die Kontrolle zählt nur die Zeilen der letzten zwei Minuten, ohne
    Wartezeit.
  - Der Berichtsplan meldet „nahe der Zeitgrenze“ ab 600 s; der Menüname sagt „rund 5 min“.
  - Proben: `check_report.py --selbsttest`, 16 Proben, auch Installationsschritt.
- **U166 Binance-Modus:**
  - `attach_binance` setzt den Abstand der FVGs und der Orderbuch-Stufen und nimmt die FVG-Mindestgröße aus der Anfrage.
  - Das Hinweisfenster zeigt eingetretene Marken als „liquidiert … USD · n Liquidationen“; fehlende Abstände erscheinen als „—“.
  - Börsenbücher heißen „Orderbuch der Börse“ statt „0 Konten“.
  - Proben: Feldvergleich aller drei Quellen als Selbsttest (`hl_viz --selbsttest-quellen`, Installationsschritt).
- **U170 Konfluenz je Quelle:**
  - Die Seite meldet die Quelle der Nutzlast, aus der sie rechnete; Tabelle `konfluenz_log_src`.
  - Die Bilanz zeigt Hyperliquid als Hauptzeile und Binance und Fusion getrennt; die Einträge vor 23.68 stehen als „Quelle
    unbekannt“.
- **U172 Hinweis an Datentagen, U171, U169:**
  - Die Datentage-Studie legt ihren Stand ab, wöchentlich sonntags 21:45, erstmals am 18.10.
  - Der Hinweis steht über der KPI-Zeile, von 00:00 Ortszeit bis 10:30 New York.
  - Die Gegenprobe nennt die abweichenden Tage; die Makro-Zeilen „USA“ sind klarer.
- **TradeLabor:**
  - U160: XMR mit normaler Gebühr; der Zeitpunkt steht im Labor-Zustand, im Bericht und in der Kachel. Die Fusion rechnet bis
    zum 25.10. weiter doppelt.
  - U161: Tabelle je Strategie und Coin.
  - U163: Spalte „Größe“, „Los“, Tabelle „Grid je Coin und Tag“, Ø/Tag auch in USD; die Kachel ist berichtigt.
  - U164: Swing und Zyklus mit fester Größe 10.000 USD unter neun neuen Kennungen; die alten sind abgelöst, offene Positionen
    beim ersten Lauf geschlossen („Regelversion abgelöst“).
  - U167: Bilanzverlauf mit allen Strategien.
- **U162 Kriterium 5:** eigener Abschnitt im Fusion-Bericht. Die Fusion rechnet unverändert.
- **U165 Farside:** Unvollständige Tage werden markiert; die Summen über 5 und 20 Tage zählen nur vollständige Tage; dazu eine
  Zählung je Abruf.
- **U159 Abdeckung:** neues Werkzeug `check_abdeckung.py`. Es zeigt je Coin und Tag die Abdeckung, dazu `snapshot_meta`, den
  Poller-Anteil, die Neustarts und den Tag 1 nach jedem Neustart gegen die Zeit danach.
- **U156 Größe der Stressphase:** Szenario aus den tatsächlichen Wegen der eigenen Fenster, ohne Trend; gepunktete Klammern,
  Tabelle, Text, „damals x-mal so breit wie heute“. HYPE bekommt einen Hinweis, PAXG nichts.
- **U158 CryptoQuant:**
  - Abruf einmal am Tag nach 01:00 UTC; Archiv mit Abrufzeit; Schlüsselfeld im Tab „Daten“; Chart mit der 95-%-Linie.
  - Prüfung S5 mit festgehaltenem ersten Urteil (Einzelheiten unten).

**Eigene Fehler, gefunden und mit 23.68 behoben:**
- **Stressklammer abgeschnitten (seit 23.66):**
  - Die gestrichelte Klammer des Stressfächers bei +4 Wochen lag außerhalb des Zeichenbereichs. Gemessen am 23.67-Skript: Handy
    0 px sichtbar, Desktop 6 Monate 1,4 px, 12 Monate 0 px.
  - Die Browserprobe von 23.66 prüfte die Klammern nicht. Jetzt bleiben 16 px frei, und die Probe prüft jede Klammer auf Lage im
    Zeichenbereich.
- **Probe lief nie:** Die Textprobe des Stressfächers im Ausblick-Selbsttest lief nie, weil die Demo keine Fenster im
  Stresszeitraum hatte. Jetzt legt die Probe den Zeitraum in die Bibliothek.
- **Schon festgehaltene eigene Fehler, jetzt behoben:**
  - Konfluenz-Bilanz ohne Quelle (U170, 3μμμ);
  - Kriterium 5 nie gerechnet (U162, seit 23.42);
  - Laufzeiten des Vollberichts nicht verfolgt (U168, 3λλλ);
  - Text der Labor-Kachel falsch seit 23.40/23.61/23.62 (U163).
- **Beim Bau, vor der Lieferung:**
  - Die Mutation „Urteil überschrieben“ (U158) blieb zuerst grün. Eine zweite Sperre in der Transaktion fing sie auf; ein späterer
    nicht prüfbarer Stand hätte das Urteil aber verdrängt. Jetzt geprüft.
  - Die Mutation „Abstand ohne isFinite“ (U166) ist im Browser mit echten Nutzlasten nicht sichtbar. Ein fehlender Abstand ist null
    und wird auch so zum Strich; NaN entstünde nur aus einer Rechnung. Die node-Probe deckt den Fall ab; so festgehalten.

**Abweichungen vom Wortlaut der Festlegungen (benannt, nicht still):**
- **U156:**
  - Hoch und Tief der Tagesblöcke werden nicht mitgeführt: keine Erreich-Wahrscheinlichkeiten, keine Wirkung auf Ziellevels.
  - Die Probe „auf 10 % genau“ rechnet über 60 synthetische Märkte. Ein einzelner Markt streut zu stark (SD 0,3), weil ein Jahr nur
    etwa 13 unabhängige 28-Tage-Wege hat.
  - Gemessen: Verhältnis 1,93 (SE 0,04), eigene Größe 0,98, Median +0,002 bei einem Trend von 0,12.
- **U158:**
  - Die Positivkontrolle verlangt „belegt in den meisten Märkten“. Das hält erst mit einer Reihe von drei Jahren (16 von 20 bei
    RR ≈ 3). Mit 450 Tagen belegt sie nur etwa jeden vierten Markt.
  - Die Nachweisgrenze steht im Bericht. Die Regel bleibt; „nicht belegt“ bei kurzer Reihe ist schwach.
- **U158 Schlüssel:** Nur ein abgelehnter Schlüssel (401/403) wird nicht geschrieben. Bei Netzfehlern, Abrufgrenze, Credits oder
  unerwarteter Antwort wird er mit Warnung gespeichert.
- **U165:** Fehlen bei einem Fonds zwei Tage in Folge, werden beide markiert. Die wörtliche Vortagsregel hätte nur den ersten
  erfasst.
- **U172:** „über den ganzen Tag kaum größer“ steht nur bei einem Tagesfaktor unter 1,3, sonst „ebenfalls größer“.

**CryptoQuant (U158), vor dem ersten echten Abruf:**
- **Doku am 17.10. gelesen (userguide.cryptoquant.com, docs.cryptoquant.com):**
  - Basis `api.cryptoquant.com/v1`; Token als `Authorization: Bearer`, nie in der Adresse.
  - Antwort `status` und `result.data` mit `date` und `volume`; `all_exchange` in BTC.
  - Basic: Tageswerte, 30 Tage, 10 Abrufe je Minute.
- **Widerspruch:** Der ältere Userguide sagt „Token ab Professional“, die neuere Planseite führt `price-ohlcv` für Basic. Erst der
  erste Abruf auf dem Pi zeigt, was gilt.
- Das Datumsformat steht einmal als „YYYY-DD-MM“, vermutlich ein Tippfehler; der Bericht zählt unlesbare Daten eigens.
- **Ablauf beim Nutzer:**
  1. Den kostenlosen Schlüssel im Makro-Abschnitt eintragen: Tab „Daten“, Feld „CryptoQuant-Schlüssel (kostenlos)“, Knopf
     „prüfen und speichern“. **Nicht in den Chat schreiben.**
  2. Der Takt ruft nach 01:00 UTC ab.
  3. Bericht 19.10. 20:15 „u158-cryptoquant“ hochladen. Er zeigt Status, Tage, Felder, das Median-Volumen (die Einheit
     prüfen: BTC heißt Spot rund 10⁵ je Tag) und die ersten Werte von D.

**Prüfungen vor der Lieferung (A7):**
- `install.py --selftest-isoliert` im ausgepackten Paket: **61 von 61 Schritten grün, zusammen rund 14 min (davon Ausblick 374 s)**.
- `node --check` beider Skriptblöcke der Seite und der drei Module grün; `py_compile` aller Dateien.
- Browserproben (Scratchpad `b80`):
  - U156: 166/166;
  - U158: 19/19;
  - U166/U170/U172 gegen einen Testserver mit echtem Schema: 39/39;
  - U163: 19/19;
  - U167 erneut 40/40 (node 13/13).
- node-Proben: U166 6/6; U172 in drei Zeitzonen 15/15.
- Mutationen:
  - Python: U156 8/8, U158 18/18, dazu die schon protokollierten der übrigen Punkte;
  - Browser: U156 8/8, U158 7/7, U166/U170/U172 5/6 (siehe oben), U163 6/6.
- Gesondert gelaufen (zusätzlich zur Installation): Ausblick-Selbsttest mit Gruppen „stress“ und „e2e“, Hebel-Selbsttest.

**Erst auf dem Pi zu sehen (in der Sandbox nicht prüfbar):**
- **U168, Frist der Zählung:**
  - Ein Zeitgeber bricht eine zu lange Zählung mit `con.interrupt()` ab. In der Sandbox (SQLite 3.45.1) wirkt das mitten in
    `COUNT(*)`, nach 8 bzw. 20 ms. Auf dem Pi läuft vermutlich SQLite 3.40.1, dort ist das nicht geprüft.
  - Wirkt der Abbruch dort nicht, verwirft der Bericht die Zahl trotzdem, sobald die Frist abgelaufen ist. Die Zahlen bleiben also
    richtig; das Budget von 8 min kann aber überschritten werden.
  - Der Wochenlauf am 21.10. zeigt die Laufzeit je Abschnitt.
- **U158:** ob der kostenlose Schlüssel `price-ohlcv` bekommt und in welcher Einheit das Volumen kommt (Bericht 19.10.).
- **U159:** die Abdeckung auf echten Daten (Bericht 18.10. 08:45).

**Wirkung und Zusagen bis 25.10.:**
- Fusion, v3, Kaskaden-Rechnung und v1-Lernen sind unverändert. Die Kostenschwelle der Fusion rechnet XMR bis zum Urteil weiter
  doppelt.
- Chartbild, Ausblick, Aktien, Makro-USA, Datentage und CryptoQuant wirken nicht auf Konfluenz, Labor, Prognose, Treiber oder
  Ausblick. Der Datentage-Hinweis ändert nur `#datentag` (Browserprobe mit MutationObserver).
- Geändert hat sich die Ausführung im Labor, beides nach Wahl des Nutzers: XMR-Gebühr (U160) und feste Größe für Swing und Zyklus
  (U164). Beides bringt neue Zeitpunkte bzw. neue Kennungen; alte Ergebnisse bleiben stehen.

**Nach dem Einspielen (A1: Version 2026-09-23.68 · e195e119f2):**
- **18.10.:**
  - 08:30 Ausblick, Aktienmarkt, Chartbild. Darin die Nachprüfung U165: IBIT für den 12.10., Total mit Revision. Neu sind die
    gepunkteten Klammern und die Zeile „Szenario: so weit gingen die Wege …“.
  - 08:45 Abdeckung (U159, erster Lauf).
  - 21:45 Datentage-Studie, erster abgelegter Stand für den Hinweis (U172).
- **19.10.:** 20:15 CryptoQuant (U158), nur wenn der Schlüssel eingetragen ist.
- **21.10.:** 19:00 Wochenlauf. Darin der Vollbericht mit Laufzeit (Soll unter 600 s, nichts „nicht gezählt“), Kriterium 5,
  CryptoQuant und Abdeckung.
- **25.10.:** Urteile U108, U115, U110.
- **Im Labor beim ersten Lauf:** Die neun alten Swing- und Zyklus-Kennungen schließen ihre offenen Positionen; die Kachel nennt den
  Gebührenwechsel für XMR.

Lehre: **Eine Browserprobe muss auch prüfen, dass etwas sichtbar ist, nicht nur, dass es im Bild steht.** Die Stressklammer stand seit
23.66 richtig im SVG und war doch abgeschnitten.

## 3οοο. Frage des Nutzers 17.10. 03:22: Exchange Inflow und Outflow (CryptoQuant) als Treiber mit 12-Stunden-Fenster? Mit dem freien Schlüssel nicht abrufbar; Wahl „Freie Quelle suchen“; Recherche: keine freie Quelle liefert brutto, stündlich und aktuell (U174 neu) (17.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Frage (Wortlaut):** „Kannst du bei cryptoquant die Zahlen abrufen für Exchange Inflow (Total) und Exchange Outflow (Total)? Falls ja,
kannst du die daten als Prognosetreiber hinzufügen mit 12 Stunden Prognose Fenster?“

**Antwort (17.10. nachts):**
- **Mit dem kostenlosen Schlüssel nicht.** CryptoQuant zählt Exchange Flows zu den On-Chain-Daten (cryptoquant.com/apis, 17.10.
  gelesen):
  - „On-chain endpoints require a Professional plan or above.“
  - „Professional serves on-chain data at daily resolution; Premium adds hourly and per-block.“
  - Basic und Advanced bekommen dafür 403.
  - Preise nur aus Drittquellen: Professional rund 99–109 USD, Premium rund 799 USD im Monat.
- **Als Treiber nicht vor dem 25.10. (Zusage).** Danach höchstens als Schattentreiber nach einem vorab festgelegten Test. Die Prognose
  lernt auf 4 und 24 Stunden; 12 Stunden wären eine neue Lernspur.
- Die Sandbox erreicht weder CryptoQuant noch Coin Metrics (Proxy 403).

**Klarstellung zu U158:** Der am 13.10. zitierte Satz „No asset or endpoint is withheld — only the resolution changes by plan“ steht auf
der Seite bei den Marktdaten. U158 nutzt nur `price-ohlcv` (Marktdaten) und ist nicht betroffen. Notiz in `KONZEPT_Hebel.md` (Stand
17.10.).

**Wahl des Nutzers:** „Freie Quelle suchen“. Zur Auswahl standen auch „Vorerst nicht kaufen (Vorschlag)“, „Professional, Tageswerte“
und „Premium, Stundenwerte“.

**Recherche** (`RECHERCHE_Boersenfluesse_17-10-2026.md`, vier Teilrecherchen, Stand 17.10.2026):
- **Keine freie Quelle liefert BTC-Zu- und Abflüsse brutto, über den ganzen Markt, aktuell und stündlich.**
  - Santiment Free: `exchange_inflow`/`exchange_outflow` brutto, aber ohne die letzten 30 Tage und mit rund einem Jahr Historie. Nur
    für eine Vorstudie.
  - Coin Metrics Community: `FlowInExNtv`/`FlowOutExNtv` täglich, falls noch frei. Die Metriken gehören zu „Network Data Pro“, und die
    Gratisstufe wurde im Oktober 2025 gekürzt. Klären kann es nur ein Abruf vom Pi.
  - DefiLlama: stündliche Bestände von 23 Börsen mit veröffentlichten Wallets, frei und ohne Schlüssel. Daraus folgt nur die
    Nettoänderung, ohne Coinbase und Kraken, mit Stufen bei neuen Wallets.
  - BGeometrics hat Endpunkte für Zu-, Ab- und Nettofluss, aber erst ab dem Advanced-Plan.
  - Eigenbau: Freie Adresslisten (Reservenachweise) kennen vor allem Kaltwallets; eine Reihe daraus misst überwiegend interne
    Umbuchungen der Börsen. Mit eigenem Knoten (2-TB-SSD) und Clustering über gemeinsam ausgegebene Eingänge mittlere Güte, 1–3
    Wochen Arbeit; der Abstand zu den Anbieterreihen ist nirgends gemessen.
- **Vergleichbarkeit:** Jeder Anbieter hat eigene Adressmengen. Zitierte Reservestände liegen bis rund 1 Mio. BTC auseinander
  (Sekundärquellen). Coinbase verschob im November 2025 rund 800.000 BTC zwischen eigenen Wallets.
- **Revisionen:** CryptoQuant ohne Point-in-Time („periodic updates to wallet address clustering“, dienstags 00:00 UTC). Nur Glassnode
  Professional verkauft unveränderliche Fassungen. Ein fairer Test braucht unser eigenes Archiv mit Abrufzeit.
- **Belege:** für die Richtung kaum (einzige Stundenstudie: BTC nur bei 4 h, R² um 0,1 %). Für die Schwankung etwas beständiger, aber
  großteils schon in der verzögerten Schwankung enthalten. 12 Stunden prüft keine Studie außerhalb der Stichprobe.
- **Nachweisgrenze** (eigene Rechnung, n ≈ 6,2/R², 730 Zwölf-Stunden-Fenster im Jahr): 0,1 % R² → rund 8,5 Jahre, 1 % → rund
  10 Monate.
- **Günstigster bezahlter Weg** zu Bruttoflüssen in Echtzeit: Santiment Sanbase Max, 249 USD im Monat (offizieller Preis).

**Eigene Prüfungen:** Ein Abruf von `community-api.coinmetrics.io` scheiterte in der Sandbox am Proxy (403). Zwei Abrufe über das
Rechercheprogramm blieben ohne Freigabe. Offen, bis der Pi abruft oder der Nutzer die Adresse in einer Nachricht schickt.

**Folge:** U174 neu. **Wahl des Nutzers** (Auswahl nach dem Bericht): „Erst prüfen, dann Archiv (Vorschlag)“. Zur Auswahl standen
auch „Archiv gleich mit dem nächsten Paket“, „Erst nach dem 25.10. entscheiden“ und „Nicht weiter verfolgen“.
- Prüfen: Coin Metrics (`FlowInExNtv`/`FlowOutExNtv`, Tageswerte) und DefiLlama (`api.llama.fi/protocol/binance-cex`), sobald der
  Nutzer die zwei Adressen schickt. Das Rechercheprogramm ruft nur Adressen ab, die in einer Nachricht des Nutzers standen.
- Danach Archiv mit Abrufzeit ab dem nächsten Paket, ohne Wirkung; der Test wird vorab festgelegt, bevor eine Zahl gesehen ist.
- Bis 25.10. wirkt nichts davon auf Konfluenz, Labor, Prognose, Treiber oder Ausblick.

Lehre: **Gekaufte Historie bringt Aktualität, aber keine Ehrlichkeit.** Anbieter bereinigen ihre Börsenflüsse nachträglich; für einen
fairen Test zählt, ab wann wir selbst mit Abrufzeit archivieren.

## 3πππ. Frage des Nutzers 17.10. 15:44: Welche freien CryptoQuant-Daten wären wirklich nützlich? Frei sind nur Marktdaten (täglich, 30 Tage); neu für uns wären vor allem die ETF-Bestände je Fonds; Wahl: nach dem 19.10. als Archiv mit Gegenprobe zu Farside (U175 neu) (17.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Frage (Wortlaut):** „Welche sonstigen Daten könnte man bei cryptoquant abrufen kostenlos, die wirklich nützlich wären?“

**Befund (docs.cryptoquant.com, 17.10. gelesen):**
- Basic gibt nur Marktdaten heraus: Tageswerte, 30 Tage Rückschau, 10 Abrufe je Minute, Lizenz „Personal“, 10.000 Credits im Monat.
  Die Credits hängen an der Datenmenge („The more data you receive, the more credits are deducted“); ohne Credits kommt 402, Basic
  kann nicht nachkaufen.
- Für Bitcoin sind das 12 Endpunkte: `price-ohlcv`, `funding-rates`, `open-interest`, `liquidations`, `taker-buy-sell-stats`,
  `coinbase-premium-index`, `capitalization`, vier `fund-data`-Endpunkte (Bestände, Prämie, Kurs, Volumen je Fonds) und
  `miner-data/companies`.
- Nicht frei sind alle On-Chain-Daten, auch `market-indicator` (MVRV, SOPR, Estimated Leverage Ratio): „Professional and above only“.

**Bewertung gegen das System:**
- **Neu und nützlich:** die ETF-Bestände je Fonds in BTC (IBIT, FBTC, BITB, ARKB, HODL, GBTC und weitere). Sie sind eine zweite,
  unabhängige Quelle neben Farside (unvollständige Tage, U165). Der Fluss in BTC ist frei vom Kurseffekt.
- **Mittel:** die Coinbase-Prämie (Coinbase BTCUSD gegen Binance BTCUSDT), fast die geplante Abgrenzung von U56, als tägliche
  Gegenprobe zur eigenen Prämie.
- **Gering:** Liquidationen, Open Interest, Funding und Taker über alle Börsen. Das System hat Hyperliquid, Binance, Bybit und OKX
  feiner. Realized Cap und MVRV-Bausteine sind doppelt (Coin Metrics seit 2010).
- Alles nur täglich mit 30 Tagen Rückschau: für die 4-Stunden-Prognose zu grob, für Rückblicke zu kurz.

**Wahl des Nutzers:** „ETF-Bestände nach dem 19.10. (Vorschlag)“. Zur Auswahl standen auch „ETF-Bestände und Coinbase-Prämie“, „Alle
freien Reihen archivieren“ und „Nichts weiter von CryptoQuant“.

**Folge:** U175 neu, festgelegt in `KONZEPT_Ausblick.md` 13.16:
- Bau erst, wenn der Bericht vom 19.10. den freien Zugang und den Credit-Verbrauch zeigt.
- U158 hat Vorrang beim Credit-Budget.
- Archiv in `hebel.db` mit Abrufzeit; Gegenprobe zu Farside je Fonds und Handelstag, beschreibend.
- Keine Wirkung.

Lehre: **„Kostenlos“ heißt bei einem Datenanbieter oft „grob und kurz“.** Der Wert einer freien Reihe liegt dann im eigenen Archiv
und in der Gegenprobe, nicht im Signal.

## 3ρρρ. Wunsch des Nutzers 17.10. 16:04: Pizza-Index als Warnsignal („bei einem Anstieg alle Long-Positionen sofort pausieren“) -- Datenquellen recherchiert, Belege nur anekdotisch; Wahl: nicht weiter verfolgen (U176 geschlossen) (17.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Wunsch (Wortlaut):** „ein weiterer wichtiger Indikator fehlt uns noch der sogenannte Pizza Index! Recherchiere wo man Daten dafür
holen kann. Wenn dieser Index hoch schiesst sollte man eigentlich alle long positionen sofort pausieren!“

**Datenquellen (17.10. recherchiert):**
- **pizzint.watch („Pentagon Pizza Index“):** Auslastung von Pizzerien rund ums Pentagon nach Google Maps, dazu eine Stufe
  „DOUGHCON“ 5 (ruhig) bis 1.
  - Keine dokumentierte Schnittstelle. Eine Menüleisten-App liest `https://www.pizzint.watch/api/dashboard-data`; die Feldnamen
    (`overall_index`, `defcon_level`, `pizzerias[]` mit `current_busyness`, `normal_busyness`, `percentage_above_normal`) hat ihr
    Autor nur vermutet. Ein anderes Werkzeug sagt, die Seite brauche einen Browser.
  - Historie, Bedingungen und Betreiber stehen nirgends. FlowingData (23.01.2026): Das Projekt dreht sich um Krypto und Memecoins.
- **X-Konto @PenPizzaReport:** nur Posts, maschinell nur über die bezahlte X-Schnittstelle; laut AOL bis 24.02.2026 ohne Post in 2026.
- **Google Maps selbst:** keine offizielle Schnittstelle für „Popular Times“; Scraper verstoßen gegen die Bedingungen. Bezahlt:
  BestTime.app, Apify-Scraper.

**Belege:**
- Nur Anekdoten: Panama 1989, Golfkrieg 1991, Irans Angriffe 2024, Israels Angriff auf Iran am 12.06.2025 (Anstieg rund eine Stunde
  vorher). Fehlalarme zählt niemand; das Pentagon bestreitet einen Zusammenhang.
- Manipulierbar: Verteidigungsminister Hegseth (22.02.2026, Fox) habe überlegt, an zufälligen Abenden viel Pizza zu bestellen, „to
  throw everybody off“. Am 24.02.2026 meldete der Index +250 % bei einem Domino's, mehrdeutig.
- BTC an solchen Tagen: 12./13.06.2025 gut −4 % auf 103.556 USD; 28.02.2026 (Samstag) rund −3 %, Tief 63.177 USD. Das sind
  Reaktionen auf die Nachricht; ein nützlicher Index müsste sie Stunden vorher zeigen.

**Antwort an den Nutzer:**
- Ob ein Anstieg BTC-Rückgänge ankündigt, ist nirgends gemessen; Ereignisse sind selten, die Fehlalarmquote ist unbekannt.
- Eine ungeprüfte Pausenregel kostet bei Fehlalarmen Anstiege; prüfbar wäre sie nur mit eigenem Archiv ab jetzt.
- Bis 25.10. keine Änderung am Labor (Zusage); echtes Geld bewegt das System nicht.

**Wahl des Nutzers:** „Nicht weiter verfolgen“. Zur Auswahl standen auch „Erst prüfen, dann Archiv (Vorschlag)“, „Archiv und Anzeige
als Hinweis“ und „Pausenregel nach dem 25.10. testen“. U176 ist damit geschlossen: kein Abruf, keine Regel.

Lehre: **Ein Signal, über das öffentlich geredet wird, kann der Beobachtete selbst verfälschen.** Bevor eine Regel darauf baut,
braucht es ein eigenes Archiv und eine gezählte Fehlalarmquote.

## 3σσσ. Berichte vom 18.10. (Sammeldatei 15:30, vier Berichte): 23.68 läuft (A1 ✓); Farside-Nachprüfung ✓; neue Stresszeile ✓; Abdeckung geklärt (Einbruch nach Neustarts, kein Dauerverlust); zwei eigene Fehler: Strategy-Bestand aus Tabellen-8-K falsch gelesen (U177), den Stressfächern fehlt der März 2020 (U178) (18.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Eingang:** Sammeldatei 18.10.2026 15:30 („Wochenbericht“), Version 2026-09-23.68 · e195e119f2: Aktienmarkt, Ausblick, Chartbild (je
08:30) und Abdeckung (08:45, erster Lauf).

**Nachprüfungen:**
- **A1 ✓:** 23.68 läuft seit 17.10. 02:46 (Neustart in der Abdeckung, Zählung der Farside-Abrufe „seit 17.10.2026, 23.68“).
- **U165 ✓:** IBIT hat 694 Tage wie die übrigen großen Fonds, also auch den 12.10.; `farside:btc:Total` hat 9 Fassungen. Neu: seit 17.10.
  war der jüngste Tag in 1 von 3 Abrufen unvollständig; über einen zweiten Abruf am Tag erst nach 20 Abrufen entscheiden.
- **U156 ✓:** Die Zeile „Szenario: so weit gingen die Wege …“ steht im Text: BTC damals 1,4-mal so breit wie heute (580 eigene Fenster),
  ETH 1,6, XMR 1,1, ZEC 0,8 (je 456); HYPE „keine eigene Geschichte in dieser Phase“; PAXG ohne.

**Ausblick, zweiter Wochen-Rückblick (18.10. 02:00 UTC, 361 s):** alle Urteile wie am 12.10.
- S1 Breite besteht nicht: 7 T Gewinn +1,4 % (p 0,001), aber Deckung BTC 83,8 % ± 1,6 über dem Soll; 14 T +0,3 % (p 0,236); 28 T −0,8 %.
  PAXG 28 T 56,9 % („zu eng“).
- S2: Tor zu überall; R²_OS überall negativ.
- Gewichte: alle „trägt nicht“, außer D8 (Top-Trader nach Konten) bei 28 T mit p 0,04 roh → „Hinweis“, nicht nach Holm. Bei 108 Tests
  (36 Kandidaten × 3 Horizonte) erwartet der Zufall rund 5 solche Werte; nur eine Hypothese für eine neue Runde.
- S3 besteht (Skill +6,1/+3,5/+1,2 %), S4 belegt (Variogramm-Gewinn 0,0627, p 0,005; unter Aktienstress weiter nicht kalibriert).

**Abdeckung der Heatmap (U159, erster Lauf):**
- Tagesmittel 24–33 % je Coin, seit 28.09. langsam fallend (BTC 33 → 28 %, ZEC 35 → 24 %). Im selben Zeitraum stieg das OI (BTC +12 %),
  die verfolgte Größe blieb gleich, das Alter der Abfragen stieg (Median 18.904 s → rund 23.500 s), „ausgelassen“ von rund 125.000 auf
  rund 155.000. Anteil des Pollers am API-Gewicht 61–66 % (erst seit 15.10. gemessen).
- **Die tiefen Werte vom 11.10.** (Anlass von U159: BTC 16 %, ZEC 10 %, PAXG 7 %) liegen bei den Tagestiefs kurz nach Neustarts (11.10.
  BTC 16–28 %, ZEC 10–26 %, PAXG 7–24 %); das Tagesmittel lag bei 21–27 %.
- **Tag 1 nach einem Neustart** unterscheidet sich im Mittel nicht von den Tagen danach (z. B. 13.10. 22:44: 26 % → 26 %; 17.10.: 26 % →
  25 %).
- 35 Neustarts seit 27.09., fast alle beim Einspielen von Paketen (8 am 05.10., dem Tag von 23.47–23.54); seit 13.10. nur zwei (23.67,
  23.68).
- **Lesart (beschreibend):** keine anhaltende Störung; nach jedem Neustart ein Einbruch für einige Stunden, bis der Poller die Konten
  wieder abgefragt hat; dazu ein Markt, der schneller wächst als die verfolgten Konten. U159 ist damit geklärt. Am Recorder ändert sich
  vor dem 25.10. nichts (Kaskaden und Magnet rechnen mit dieser Karte; U110 am 25.10.).

**Eigene Fehler, gefunden in diesen Berichten:**
1. **Strategy „zuletzt +846.001 BTC“ (U177).**
   - Der Bestand 847.666 BTC (05.10.) stimmt; der Wert davor in `sec:mstr_btc` muss 1.665 sein (847.666 − 846.001).
   - Vermutete Ursache: Das vierte Suchmuster in `sec_bestand_parse` nimmt die erste große Zahl nach „Aggregate BTC Holdings“. In einem
     8-K, das nur die Tabelle hat, ist das die Zahl der gekauften BTC oder der Durchschnittspreis.
   - Der Selbsttest prüfte nur die Textform („held an aggregate of approximately …“), nie eine Tabelle.
   - Folge: Die Archivreihe enthält falsche Werte; Bericht und Dashboard zeigen eine falsche Wochenzahl. Gerechnet wird damit nichts.
2. **Den Stressfächern fehlt der März 2020 (U178).**
   - Die Bibliothek beginnt auf dem Pi erst am 01.10.2020: Das HAR braucht 800 Anker (rund 200 Tage) mit abgeschlossenem 28-Tage-Ziel,
     bei Daten ab 01.01.2020.
   - Von der Phase 24.02.2020–23.02.2021 zählen deshalb nur Fenster ab Oktober: BTC und ETH 580 von 1.460 möglichen, ZEC und XMR 456
     (Daten ab Februar 2020). Der Corona-Crash fehlt im Formfächer (seit 23.66) und im Größenfächer (seit 23.68).
   - Die Beschriftung nennt die ganze Phase. Die Ende-zu-Ende-Probe legte die Phase absichtlich in die Bibliothek; so konnte die Lücke
     in der Sandbox nicht auffallen.

**Wahl des Nutzers (Auswahl nach dem Bericht):**
- Stressfächer: „Beschriftung berichtigen (Vorschlag)“: tatsächlicher Zeitraum der Fenster, Zahl von möglichen, Hinweis „März 2020
  nicht enthalten“. Zur Auswahl standen auch „Größenfächer mit allen Fenstern“ (neue Festlegung) und „Phase innerhalb der Bibliothek“.
- Zeitpunkt: „Nächstes Paket nach 19.10. (Vorschlag)“, zusammen mit U175. Zur Auswahl stand auch „Jetzt ein kleines Paket“.

**Als Nächstes:** 18.10. 21:45 Datentage (erster abgelegter Stand für U172), 19.10. 20:15 CryptoQuant (U158), 21.10. 19:00 Wochenlauf
(Vollbericht-Laufzeit U168, Kriterium 5 U162), 25.10. Urteile U108, U115, U110.

Lehre: **Eine Ende-zu-Ende-Probe, die ihre Eingaben passend legt, prüft die Rechnung, nicht den Zuschnitt auf echten Daten.** Der Bericht
muss deshalb nennen, welche Fenster tatsächlich zählen. Und ein Parser braucht für jede Form, in der ein Dokument erscheinen kann, eine
eigene Probe.

## 3τττ. U174 Börsenflüsse: die zwei Adressen des Nutzers abgerufen -- Coin Metrics liefert Zu- und Abfluss täglich frei, DefiLlama nur als Probe; Test vor jeder Zahl festgelegt, Nachweisgrenze simuliert (18.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Ablauf:** Frage des Nutzers „U174 was brauchst du genau von mir ?“ → Antwort: die zwei Adressen im Chat, weil die Sandbox Coin
Metrics sperrt und mein Abrufwerkzeug nur Adressen aus dem Chat abruft. Danach schickte er beide (Coin Metrics mit
`FlowInExNtv,FlowOutExNtv&frequency=1d&page_size=5`, DefiLlama `protocol/binance-cex`).

**Ergebnis des Abrufs:**
- **Coin Metrics Community: frei**, ohne Schlüssel. Am 18.10. um 13:50 UTC reichten die Tageswerte bis zum 17.10. (13. bis 17.10.:
  Zufluss 14.234 bis 27.949 BTC je Tag, Abfluss 12.183 bis 27.450 BTC; 17.10.: 14.233,6 gegen 12.183,2). Ohne `paging_from` kommt die
  jüngste Seite zuerst. Damit ist die offene Frage der Recherche beantwortet. Stundenwerte (`frequency=1h`) sind ungeprüft.
- **DefiLlama: frei, aber nur Bestände** (also der Saldo), je Abfrage eine Börse; Methode „All assets in wallets mentioned in Binance
  PoR api“, Verlauf täglich. Die Antwort ist so groß, dass mein Werkzeug nach rund 60.000 Zeichen abbrach; den Bitcoin-Teil habe ich nicht
  gesehen. → nur eine Probe auf dem Pi, kein Archiv.

**Festlegung vor jeder Zahl (`KONZEPT_Makro.md` 12):**
- Archiv mit dem nächsten Paket: eigenes Coin-Metrics-Ziel alle 6 h, Fassungen mit Abrufzeit in `mk_fassung` (wie U153); ohne Wirkung.
- Merkmal n_d = Nettofluss des Tags d als z-Wert über die 90 Tage davor; Fenster 12 h ab 18:00 UTC am Tag d+1 (ein Fenster je Tag).
- T1 Betrag |n_d| → Schwankung über die HAR-Prognose hinaus (einseitig größer), T2 n_d → Schwankung, T3 n_d → Richtung (erwartet:
  nicht belegt). Spearman, zirkuläre Verschiebung (30 Tage Abstand), Holm über drei, beide Kalenderhälften mit gleichem Vorzeichen.
- Zwei Stufen: Vorstudie auf der bereinigten Historie (rund 2.200 Tage, α 0,05; ohne Beleg endet U174 beim Archiv), Urteil nur auf dem
  eigenen Archiv (365 Tage mit α 0,01, sonst 730 Tage mit α 0,04).
- Positivkontrollen synthetisch und aus den Daten (gleichzeitig: Bruttoaktivität mit der Schwankung desselben Tags), Nullprobe,
  Mutationen (u. a. Wert vor seiner ersten Fassung, Flusstag um einen Tag verschoben).

**Nachweisgrenze, simuliert (18.10., synthetisch, je Punkt 1.000 Läufe, vollständige Regel):** 80 % Teststärke für T1 erst ab
ρ ≈ 0,073 bis 0,085 in der Vorstudie (R² 0,5 bis 0,7 %), ρ ≈ 0,23 bis 0,26 beim ersten Blick (365 Tage) und ρ ≈ 0,13 bis 0,15 beim
zweiten (730 Tage, R² 1,8 bis 2,3 %); der jeweils höhere Wert gilt für Reihen mit Gedächtnis. Ohne Effekt war mindestens ein Test in
0,9 bis 5,2 % der Läufe belegt. Die Studien fanden für die Schwankung R² von 0,3 bis 1,5 % als alleiniger Regressor, mit der
verzögerten Schwankung als Kontrolle deutlich weniger. **Die Vorstudie kann einen Effekt am oberen Rand der Studien finden; das eigene
Archiv bestätigt nur einen größeren.**

**Eigene Korrektur am Entwurf (vor dem Hochladen):** Der erste Entwurf von Abschnitt 12 nannte als Nachweisgrenze bei 365 Tagen
ρ ≈ 0,15 aus der Faustformel n ≈ 7,8 / ρ². Die Formel ließ die Hälftenregel und den Verlust durch Ränge und Betrag weg, und
„einseitig 2,5 %“ war nicht der erste Holm-Schritt (5 % ÷ 3). Die Simulation der vollständigen Regel ergibt bei einem Blick mit α 0,05
rund 0,18 bis 0,20. Außerdem stand dort „Zufluss rund 12.000–28.000 BTC“ (richtig: ab 14.234) und eine ungeprüfte Uhrzeit; beides
nach erneutem Abruf berichtigt.

Lehre: **Eine Nachweisgrenze für eine Regel mit Holm, Hälften und Verschiebungsnull nicht aus der Faustformel nehmen, sondern die
Regel selbst simulieren.**

## 3υυυ. Frage des Nutzers 19.10. 16:52 (Bild): „Ausnahmelage … (Börse geschlossen, Perp-Stand)“, obwohl die US-Börse offen ist -- Auslösung und Bewegung richtig, Text und Wirkungssatz falsch, S&P-Regel ungeprüft; Wahl: Text + Zählung mit 23.69 (U179) (19.10.; nur Dokumente, Version 2026-09-23.68 unverändert, Opus 5.5)

**Frage (Wortlaut):** „Prüfe warum die Meldung erscheint, obwohl die US Börse eigentlich läbgst geöffnet hat. Wird es korrekt
getracked ?“ Dazu ein Bildschirmfoto (Ausblick BTC, Anker 19.10. 14:30 UTC, 16:50 Uhr Ortszeit): „Ausnahmelage seit 19.10. 02:39 UTC:
S&P-500-Perp in 6 h +1,2 % (Börse geschlossen, Perp-Stand) -- die Spanne ist sofort breiter gerechnet (24 h).“

**Befund (Code von 23.68 gelesen, nachgerechnet):**
- `schock_pruefen` (alle 5 min) Regel (c): |ln-Bewegung des Perps `xyz:SP500:30m` über 6 h| > 3 · √(F_S · 6/24), F_S = S&P-Varianz je
  Handelstag aus `sp_breite`; setzt die Ausnahme für alle Coins außer PAXG mit `seit`, `regel`, `grund`; Sperre und Anzeige 24 h
  (`AUSNAHME_S`). Der Zusatz „(Börse geschlossen, Perp-Stand)“ kommt aus `boerse_offen(jetzt)` im Moment der Auslösung und steht fest
  im Text.
- **Auslösung richtig:** 02:39 UTC = Sonntag 22:39 New York. `boerse_offen` nachgerechnet: 02:39 UTC geschlossen, 13:29 geschlossen,
  13:30 offen, 14:50 offen, 20:00 geschlossen.
- **Bewegung echt:** S&P-Futures nach dem Start Sonntag 18:00 New York +0,72 % auf 7.760 (Benzinga, 19.10. 00:46 New York);
  Freitagsschluss 7.659,44 (−1,09 %); Perp am Wochenende 7.630,30 (Bericht 18.10. 08:30). Zusammen rund +1,1 %, gemeldet +1,2 %.
- **Eigene Fehler aus 23.66:**
  1. Börsenstand der Auslösung im Text eingefroren, kein Ende genannt (der Hinweis steht bis 20.10. 02:39 UTC).
  2. „Die Spanne ist sofort breiter gerechnet“ stimmt nur für (a)/(b). Bei (c) geht der Perp in keine Spanne ein: Die Breite ist das
     Grundmodell aus der eigenen Schwankung (Rückblick 18.10.: X1–X4 für alle h verworfen); `G["xyz_sp"]` wird geladen, aber nicht
     benutzt. Der Satz in `KONZEPT_Ausblick.md` 13.1 ist dort jetzt berichtigt.
  3. Regel (c) ohne Probe; der Selbsttest „schock“ prüft nur (a).
- **Offen, ungemessen:** Die Schwelle verteilt die Tagesvarianz gleichmäßig auf 24 h (1,5 Tages-σ für 6 h). Beim S&P liegt der größte
  Teil in der Handelszeit; am Sonntagabend kommen Wochenendlücke und Abdriften des Perps dazu. Erwartung: in der Handelszeit zu
  häufig, nachts fast nie.

**Wahl des Nutzers:** „Text + Zählung (Vorschlag)“. Zur Auswahl standen auch „Nur Text berichtigen“ und „S&P-Regel abschalten“.
→ **U179**, festgelegt in `KONZEPT_Ausblick.md` 13.18, Bau mit 23.69:
- Text mit Beginn und Ende, „bei Auslösung Börse geschlossen“, bei (c) „nur ein Hinweis, die S&P-Bewegung geht nicht ein“; Felder
  statt fertigem Text, alte Einträge umgeschrieben.
- Probe für (c) (Sonntag und Handelszeit, PAXG nie, F von BTC unverändert, Ende = Beginn + 24 h) mit fünf Mutationen.
- Debug-Zählung auf den Perp-Kerzen ab 12.08.: Varianzverhältnis Q und Anteil über der Schwelle je Fensterart, Auslösungen mit Sperre,
  tatsächliche Auslösungen aus `au_prognose`; Probe mit bekanntem Tagesprofil.
- Neue Schwelle erst nach der Zählung, vorab festgelegt, frühestens nach dem 25.10. und nach Entscheidung des Nutzers.

Lehre: **Ein Hinweis, der 24 h stehen bleibt, braucht Zeitbezug und Ende; ein Satz über die Wirkung muss für jede Regel stimmen, die
ihn auslöst.**

## 3φφφ. Paket 23.69: Akkumulation im TradeLabor (U180), Strategy-Bestand aus Tabellen-8-K (U177), Zeitraum der Stressfächer (U178), Ausnahmelage durch den S&P-Perp mit Text, Probe und Zählung (U179) (19.10. abends; Version 2026-09-23.69 · 547c938d6a, Opus 5.5)

**Wunsch des Nutzers (19.10. 20:22, Kern wörtlich):** eine Strategie, die „ausschließlich der Akkumulation“ dient: „Es gibt keinen
Verkauf.“ Sie kauft Dips mit je 1.000 USD, am heißen Long-Cluster der Heatmap und nach einer „signifikanten Kursveränderung ins
Negative“, kauft tiefer nach, hört „spätestens 20 % über den 200 MA“ auf und wartet, wenn „sehr, sehr viel Trader im Profit“ sind;
Bilanz statt Einzeltrades, jede Position einzeln zum Ausklappen mit ihrem Gewinn, dazu eine Gesamtübersicht; „heute umsetzen“.
**Wahl des Nutzers:** alle fünf Labor-Coins, ohne Obergrenze, 200-Tage-Linie, Paket „Akkumulation + U177–U179“ (U174/U175 später).

**U180 Akkumulation (Konzept `KONZEPT_Akkumulation.md`, vorab festgelegt vor jedem echten Kurs):**
- Zwei Strategien (`akku`, Kontrolle `akku_ohne_cluster`), je Coin eine Bilanz in `forecasts.db` (`labor_akku_kauf`,
  `labor_akku_tag`), BEGIN IMMEDIATE und ein Sicherungspunkt je Strategie. Regeln A1/A2/A3, Sperre 1,2 × MA200, Warteregel ab
  Konten-Quote 3 (U142 H1), 1.000 USD, Spot-Gebühr 0,070 %, nie ein Verkauf.
- **Änderung vor jedem echten Kurs (Konzept 7):** Der geplante Vergleich „Ø Einstand gegen Zufallszeiten“ ist auf Zufallswegen schief
  (Median +2 %, p < 0,05 in 10 %) und fast ohne Teststärke gegen Surrogate; maßgeblich ist jetzt Q (Mittel der 7 Tage nach dem Kauf
  gegen den Kaufpreis) gegen 200 Vorzeichen-Surrogate, der Vergleich bleibt beschreibend mit Hinweis. Nachgeprüft: 120 Zufallswege,
  p < 0,05 in 3 von 120 = 2,5 % (Wilson 0,9–7,1 %); mit dem Vorlauf (3 von 24, früherer Stand) zusammen 6 von 144 = 4,2 %
  (Wilson 1,9–8,8 %).
- **Anzeige:** Reiter „Akkumulation“ (Gesamtübersicht, Wachstum mit Stufe „eingesetzt“ und Linie „Wert“ auf einer USD-Achse,
  Fadenkreuz, Tabelle je Tag; je Coin Zahlen, Lage „Kauf ab …“, „Zeitpunkt gegen Zufall“, Lose zum Aufklappen; auf dem Handy nur
  Käufe, Wert, Gewinn als Spalten), Kopfzeilen-Kachel, Käufe unter „Ereignisse“ (⊕, mit Titel), Datenfluss-Gruppe „Akkumulation“.
  Debug „★ Akkumulation: Rückblick seit 2020 (U180)“ (67 s in der Sandbox auf voller Länge), Berichtsplan 20.10. 08:45 (zweiter Termin
  21.10.).
- **Beim Bau gefunden und behoben (vor der Auslieferung):** Beschriftung am Linienende lag auf den Linien (jetzt über bzw. unter allen
  Linienstücken im Bereich der Schrift); auf dem Handy waren die Zeilen hoch und leer (Lage jetzt in einer Zeile über die ganze Breite)
  und die aufgeklappten Lose machten die Tabelle 444 px breiter (Zeilenumbruch fehlte); eine wirkungslose CSS-Begrenzung wieder
  entfernt (ihre Mutation war grün). Die Lage nannte bei einem nahen Cluster einen Preis, der schon unterschritten war — jetzt der
  wirksame A2-Preis (beide Bedingungen) und als „nächster Kauf“ der höhere von A1 und A2. Die Mutation „H7 mit Zukunft (live)“ war
  zunächst grün (der Labor-Markt hat nach dem Dump nur tiefere Hochs); dazu kam die Probe „7-Tage-Hoch live von Hand“.
- **Proben:** Akkumulation 10 von 10 grün, Labor-Selbsttest 77 von 77; Mutationen der Regel 10 von 10 rot (H7 mit Zukunft im
  Rückblick und live je eigens; „Funding gerechnet“ entfällt: kein solcher Codepfad); Browserprobe des Reiters 54 von 54 am Rechner
  und auf dem Handy, Mutationen der Anzeige 13 von 13 rot. Kalibrierung von Q auf Zufallswegen: 6 von 144 unter 0,05 (Vorlauf 3 von
  24, Hauptrechnung 3 von 120; Wilson 1,9–8,8 %); Nachrechnung mit dem gebauten Code: Zufallswege 0 von 13, Einbrüche mit Rückkehr
  5 von 5 (Konzept 7).

**U177 Strategy-Bestand (`KONZEPT_Ausblick.md` 13.17/13.19):** Parser je Tabelle (größte Zahl ohne „$“ in der Spalte „Aggregate BTC
Holdings“), Plausibilität **nur nach unten** gegen den plausiblen Bestand höchstens 9 Tage entfernt (Präzisierung vor dem Bau: eine
Prüfung in beide Richtungen ließe einen durchgerutschten kleinen Wert die richtigen Folgewerte sperren), unplausibel nicht archiviert
und genannt, falsch gespeicherte einmal neu gelesen (höchstens 6 je Lauf), „zuletzt“ nur aus plausiblen. Probe ohne Netz grün,
Mutationen 3 von 3 rot. **Erwartung auf dem Pi:** Der nächste SEC-Lauf liest das 8-K mit 1.665 neu; der Bericht nennt danach den
richtigen Wochenzuwachs.

**U178 Stressfächer (13.17/13.19):** Beschriftung mit dem Zeitraum der Fenster, der Zahl von möglichen und „März 2020 nicht
enthalten“ in Text, Dashboard und Tabelle; Rechnung unverändert. Proben grün, Mutationen rot (Python und Seite).

**U179 Ausnahmelage (13.18/13.19):** Felder statt Text, Text mit Beginn und Ende aus `ausnahme_text`, bei (c) „bei Auslösung Börse
geschlossen“ und „nur ein Hinweis“; alte Einträge und Nutzlasten von 23.68 ebenso geschrieben. Probe für (c) am Sonntag und in der
Handelszeit mit Gegenprobe 0,8 × Schwelle; 5 Mutationen rot. Zählung `--sp-zaehlung` (Debug, Berichtsplan 20.10. 21:15) mit Probe auf
2.000 synthetischen Tagen (Q je Fensterart ±10 %, Einteilung unabhängig nachgeprüft, F_S kausal, 24-h-Sperre); 3 Mutationen rot.
Browserprobe des Banners 13 von 13. Die Schwelle bleibt, bis der Nutzer nach der Zählung entscheidet (frühestens nach dem 25.10.).

**Nicht im Paket:** U174 (Börsenflüsse, Archiv und Vorstudie) und U175 (ETF-Bestände von CryptoQuant; wartet auf den Bericht vom
19.10. 20:15) — Wahl des Nutzers „Akkumulation + U177–U179“. **Neu offen U181:** `akku_daten` sucht die Tageszeilen für die
Gesamtkurve je Tag und Coin in der ganzen Liste; heute Millisekunden, nach einem Jahr geschätzt 2–3 s je Abruf auf dem Pi —
Wörterbuch im nächsten Paket, an den Zahlen ändert sich nichts.

**Beim Packen gefunden und vor der Auslieferung behoben (eigene Fehler):**
- **Dateiliste von `update.py`:** `KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` fehlten in `PROJECT_FILES`;
  Dokumente außerhalb der Liste spielt update.py nicht ein. Ebenso fehlte `check_abdeckung.py` (23.68): als „weitere Datei“
  eingespielt, aber vor dem nächsten Update nicht gesichert und von „Zurückspielen“ nicht erfasst. Alle drei aufgenommen; deshalb
  Prüfsumme 547c938d6a statt 4f52736ff4. Probe in einer Kopie mit zwei echten Läufen von update.py (der Stand 23.68 spielt 23.69 ein,
  danach spielt das neue update.py dasselbe Paket ein): 12 von 12; mit der alten Liste im Paket 3 rot (`b81/upd/probe_update.py`).
  **Folge:** 23.69 wird auf dem Pi noch vom update.py aus 23.68 eingespielt; die beiden Dokumente kommen erst mit dem nächsten Update
  auf den Pi (im Projekt liegen sie schon). Dauerhafte Probe im Selbsttest: U182.
- **Uhrzeiten geschätzt statt gemessen:** In `KONZEPT_Akkumulation.md`, `KONZEPT_Ausblick.md` (13.19), UPDATE_PLAN, PROJEKTUEBERGABE
  und der Überschrift hier standen Zeiten bis zu zwei Stunden zu spät („20.10. 00:30“ und „01:00“, „Simulation 22:00“, „nachgeprüft
  23:40“), als die Uhr noch 22:51 zeigte. Berichtigt nach den Dateizeiten der Protokolle (Simulation 21:35, Kalibrierung 22:10, Bau
  mit Labor-Selbsttest 22:45). Richtig bleiben die Reihenfolge „vorab festgelegt → synthetisch geprüft → gebaut“ und „kein echter
  Kurs“: In der Sandbox lief die Regel nie auf echten Kursen.
- **Zahlen ohne Protokoll (`KONZEPT_Akkumulation.md` 7):** „Einbruch-Märkte p 0,02–0,21“ (Vorteil gegen Surrogate) stand in keinem
  Protokoll → ersetzt durch die protokollierte Zahl (Märkte mit Rückkehr: 0 von 13 unter 0,05, Median p 0,30). „Q: 0 von 10, 0 von
  3, 5 von 5“ → mit dem gebauten Code nachgerechnet und protokolliert (`b81/q_nachrechnung.log`, gleiches Bild, p 0,016–0,017 bei den
  Einbrüchen). Der Vorlauf der Kalibrierung (24 Zufallswege um 22:00, 3 unter 0,05, früherer Stand von Skript oder Regel) fehlte im
  Konzept → ergänzt; zusammen 6 von 144 = 4,2 % (Wilson 1,9–8,8 %).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` auf dem Arbeitsstand (Code gleich dem Paket bis auf die
Dateiliste in `update.py`, die der Selbsttest nicht ausführt): **61 von 61 grün** (46 Schritte, PNG, 14 Dashboard-Abrufe), 1.297 s;
Ausblick 614,7 s (23.68: 374 s; neu die Fensterproben U178 und die Zählprobe U179), TradeLabor 121,7 s. Der Debug-Eintrag
„Selbsttest“ nennt noch „3–5 min“; auf dem Pi ist eher mit einer Stunde zu rechnen (U183). Paket: 120 Einträge, 102 Dateien,
Stempel 2026-09-23.69 · 547c938d6a, `py_compile` aller Skripte im ausgepackten Paket ok.

**Zusage bis 25.10. eingehalten:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen unverändert; die Akkumulation liest nur Kurse, Buch,
Heatmap, `bnc_metrics` und `swing.db`, nichts aus Chartbild, Ausblick, Aktien, Makro, Datentagen oder CryptoQuant; U177–U179 wirken
nur auf Texte und Anzeigen.

Lehre: **Eine Prüfung, die auch ohne jede Vorhersagekraft „gewinnt“, ist keine Prüfung — vor dem ersten echten Kurs auf Zufallswegen
nachrechnen. Und eine Mutation, die grün bleibt, zeigt entweder wirkungslosen Code (weg damit) oder eine fehlende Probe (dazu).**
**Uhrzeiten in Dokumenten nur gemessen (Uhr oder Dateizeit), nie geschätzt; jede Zahl braucht ein Protokoll, jeder Vorlauf gehört
dazu; jede neue Datei gehört in die Liste von update.py.**

## 3χχχ. Paket 23.70: Akkumulation vor dem ersten Lauf geändert -- 5.000 USD, Spot, Startkauf, Rückrechnung ab dem Start des Coins im Labor (U184) (19./20.10.; Version 2026-09-23.70 · a2b59f0fc5, Opus 5.5)

**Wunsch des Nutzers (19.10. 23:20, Kern wörtlich), bevor er 23.69 einspielte:** „Bitte korrigiere diese Summe auf 5000 Dollar.“ Die
Position soll „spot sein … die kann endlos gehalten werden und verursacht keine Gebühren“. „Beim ersten Start kauft er für 5000“, danach
die besprochenen Regeln; „bei Kursrückgängen über 3 % fast immer kaufen“ hat er selbst gestrichen („Wir lassen die Regeln so wie
besprochen“). **Meine Rückfrage** (Startkauf über der 20-%-Grenze: warten oder sofort?) **beantwortete er (23:40) anders:** „Die Käufe
sollen beim Start nachberechnet werden auf Grundlage des Datenbank starts, also rückwirkend. Dadurch soll diese Strategie direkt
vergleichbar sein mit den anderen laufenden strategien.“ **23.69 ist nicht eingespielt; 23.70 enthält alles aus 23.69 (3φφφ).**

**Gebaut (U184, `KONZEPT_Akkumulation.md` 2 und 7a):**
- `AKKU_USD` 5.000 (Gebühr 3,50 USD je Kauf); Regeln mit `start` → neue Kennungen (23.69 lief nie, es gibt keine alte Bilanz).
- **Spot:** war schon so gerechnet (eigene Bilanz, kein Hebel, kein Funding). Das Ereignis trug intern die Seite „long“ -- jetzt „spot“
  (grün in der Liste); Text mit deutschen Trennzeichen (vorher „Taker 0.070 %“). Die einmalige Kaufgebühr bleibt, wie bei einem echten
  Spot-Kauf. Der Kurs kommt weiter aus dem Perp-Buch (Spot-Bücher zeichnet das System nicht auf) -- im Konzept vermerkt.
- **Startkauf A0** (`akku_lage`): ohne Kauf dieser Strategie im Coin sofort, vor allen anderen Auslösern; braucht frischen Kurs, σ₇ und
  MA200, nicht das 7-Tage-Hoch; die Sperre (1,2 × MA200) gilt. Danach A1–A3, in den 7 Tagen nach dem Startkauf nur A3.
- **Rückrechnung** (`Labor._akku_nachrechnen`, einmal je Strategie und Coin vor dem ersten Kauf): Beginn = Start des Coins im Labor
  (`labor_zustand` „coins“, dieselben Kontotage wie die übrigen Strategien); Regel ohne Heatmap (`akku_regel_kerzen` mit neuem `ab`
  und `bar=60`: A0 zur Eröffnung der ersten Minute unter der Sperre, dann A1/A3) auf den 1-min-Kerzen bis zur letzten abgeschlossenen
  Minute, σ₇ und MA200 je Minute vom letzten vollen Tag davor; Käufe mit Vermerk „nachgerechnet“, Tageszeilen je UTC-Tag, Ereignisse zu
  ihrer Zeit, Zustand „nach“. Ohne früheren Start (frischer Speicher) A0 live. Ein Neustart rechnet nicht noch einmal.
- **Vergleich gegen Zufallszeiten** nur über die Käufe nach den Regeln (ohne A0), ab dem Beginn der Rückrechnung; der **Rückblick seit
  2020** bleibt ohne A0 (die Regelfunktion kauft ohne `ab` nie einen Startkauf).
- **Anzeige:** Auslöser „Startkauf“, „nachgerechnet“ je Los, Gesamtübersicht „seit <Beginn> … davon n nachgerechnet bis …“, Lage
  „Startkauf ausstehend“ bzw. „gesperrt“ mit „Startkauf wartet“, „ab 5 Käufen nach den Regeln“, Kopfzeile „wartet auf den Startkauf“,
  Regeln-Zeile mit „Spot“ und „Startkauf“, Hilfetext; Bericht mit „davon n rückwirkend nachgerechnet“. Berichtsplan-Texte „23.70“.

**Meine Entscheidungen (begründet in 7a):** „Datenbankstart“ = Start des Coins im TradeLabor (so sind die Zeiträume wirklich gleich; der
Beginn der Aufzeichnung in `hl_liq.db` Mitte September wäre ein Zeitraum, den keine andere Strategie hat). Die Sperre gilt auch für den
Startkauf (meine Rückfrage blieb in diesem Punkt offen; „immer sofort“ wäre eine Zeile). Die Kontrolle ohne Heatmap bekommt Startkauf und
Rückrechnung ebenso -- bis zum ersten Takt sind beide gleich, danach zählt der Abstand.

**Grenzen der Rückrechnung:** A2 und die Warteregel wirken erst live (Heatmap-Stände von damals rechnet das Labor nicht nach); Kauf zur
Schwelle ohne Abstand zur Buchmitte, also etwas günstiger als live zum Ask; Auslösung am Tief der Minute statt an der Buchmitte je Takt.

**Proben:** Teil „Akkumulation“ 13 von 13 (neu: Startkauf von Hand in 10 Fällen, Rückrechnung auf Kerzen von Hand, Rückblick = Live mit
Startregel, Ende zu Ende mit Coin-Start 11 Tage vor dem Dump samt Tageszeile von Hand, Neustart, frischer Speicher), ganzer
Labor-Selbsttest 80 von 80; Mutationen der Regel 25 von 25 rot (die 10 von 23.69 und 15 neue: Startkauf fehlt, bei jedem Takt, ohne Sperre; Rückrechnung fehlt, doppelt, ab jetzt, mit künftigen Kerzen, ohne Sperre, ohne Tageszeilen, Startkauf zum Schluss statt zur Eröffnung; Rückblick mit Startkauf; Vergleich mit Startkauf; Betrag 1.000; Ereignis „long“ live und nachgerechnet); Browserprobe des Reiters mit neuen Daten 58 von 58, Mutationen der Anzeige
20 von 20 rot (die 13 von 23.69 und 7 neue: Startkauf ohne Namen, „nachgerechnet“ fehlt, Zeitraum ab der Anlage statt ab dem Beginn der Rückrechnung, ohne „davon nachgerechnet“, Vergleich nach allen Käufen gezählt, „Startkauf ausstehend“ fehlt, Spot-Käufe grau).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` auf dem Arbeitsstand von 23.70 (Code gleich dem Paket): **61 von 61 grün** (46 Schritte, PNG, 14
Dashboard-Abrufe), 1.221 s; Ausblick 575,0 s, TradeLabor 112,9 s. Paket: 120 Einträge, 102 Dateien, Stempel 2026-09-23.70 ·
a2b59f0fc5, `py_compile` aller Skripte im ausgepackten Paket ok; Probe der Dateiliste von update.py (23.68 spielt 23.70 ein, dann
23.70 sich selbst) 12 von 12.

**Erwartung auf dem Pi:** Beim ersten Takt nach dem Einspielen rechnet das Labor je Coin ab seinem Start nach (BTC, ETH, ZEC, HYPE seit
dem Laborstart Ende September, XMR seit seiner Aufnahme); dieser eine Takt dauert ein paar Sekunden länger. Danach zeigt der Reiter je
Coin unter der Sperre einen Startkauf und alle Rücksetzer und Nachkäufe seitdem, als „nachgerechnet“ gekennzeichnet. Ein Coin, der seit
seinem Start durchgehend 20 % oder mehr über der 200-Tage-Linie lag, hat noch keinen Kauf („Startkauf wartet“).

**Zusage bis 25.10. eingehalten:** nur das Labor; die Rückrechnung liest 1-min-Kerzen, `swing.db` und den eigenen Labor-Zustand.

Lehre: **Eine Antwort, die eine andere Frage beantwortet als die gestellte, lässt die gestellte offen -- die offene Entscheidung selbst
treffen, begründen und in der Lieferung nennen.**

## 3ψψψ. Paket 23.71: Akkumulation -- Liste aller Käufe, Tagestabelle als „Stand je Tag“, Grund des Startkaufs (U185) (20.10.; Version 2026-09-23.71 · f3113c906a, Opus 5.5)

**Hinweis des Nutzers (20.10. 01:40, Screenshot mit 23.70, Kern wörtlich):** „In der Liste sind sehr viele Käufe, allerdings nur
innerhalb von 23 Tagen. Aber oben steht, dass nur jeweils 5000 gekauft worden sind. Die müssten aber bei einer Akkumulation addiert
werden. Das haut vorne und hinten nicht richtig hin. Überprüfe das bitte alles.“ **Wahl des Nutzers** auf meinen Vorschlag: „Jetzt als
23.71 (Vorschlag)“ -- Tagestabelle als „Stand je Tag (keine Kaufliste)“ mit Spalte „Käufe“ und markierten Kauftagen, eine Liste „Alle
Käufe“ über alle Coins unter der Übersicht, beim Startkauf der richtige Grund; Rechnung und gespeicherte Käufe unverändert.

**Nachgeprüft (Zahlen des Screenshots):** Die Rechnung stimmt. Drei Käufe, je ein Startkauf: BTC 27.09. (Laborstart), ETH 07.10., HYPE
19.10.; ZEC und XMR gesperrt. Eingesetzt 3 × 5.000 = 15.000 USD, Wert 14.785, −1,43 %; die Schwellen der Lage nachgerechnet (z. B. BTC
84.133 · e^(−0,096) = 76.425). Die „Liste“ war die Tabelle je Tag: 23 Zeilen für die UTC-Tage 27.09.–19.10., je Zeile der Stand am
Tagesende (eingesetzt = Summe aller Käufe bis dahin) -- keine Käufe. Eine Liste aller Käufe gab es nicht (nur je Coin zum Aufklappen).
**Eigener Fehler aus 23.70:** Der nachgerechnete Startkauf hieß immer „Startkauf zum Start des Coins im Labor (…)“, auch bei ETH und
HYPE, die erst Tage später kauften (in der ersten Minute seit dem Start, in der ein Kauf erlaubt war). Die Rechnung war richtig, der
Text nicht; die Probe hatte nur den Startkauf in der ersten Minute.

**Gebaut (U185, `KONZEPT_Akkumulation.md` 2, 3 und 7b):**
- `hl_viz.py`: Liste **„Alle Käufe (n)“** (`akAlle`, `akAlleTabelle`) direkt unter der Gesamtübersicht, offen, neueste zuerst, die neuesten
  10 und ein Knopf für alle (bis 300); Nummer, Zeit, Coin, Auslöser mit Namen und „nachgerechnet“, Preis, Wert jetzt, Gewinn, Grund.
  `akTabelleTage` als **„Stand je Tag — keine Kaufliste: …“** mit „Käufe“ (bis zu diesem Tag, aus denselben Losen) und „neu“ (die Käufe des
  Tages, Zeile grün markiert); je Coin nur dessen Käufe. Handy: Preis unter dem Coin, neue Käufe unter dem Tag, ohne #, Preis-Spalte,
  Wert, Grund, „neu“ und Gewinn USD, schmale Ränder -- beide Tabellen ohne Seitwärtsscrollen. Hilfetext.
- `hl_labor.py`: `AKKU_A0_TEXT` („Startkauf in der ersten Minute seit dem Start des Coins im Labor (…), in der ein Kauf erlaubt war (Kurs
  unter 1,2 × 200-Tage-Linie, σ₇ und 200-Tage-Linie bekannt)“) und `akku_start_ursache` für neu nachgerechnete Startkäufe: kam er nicht in
  der ersten Minute, „; erst am …, bis dahin lag der Kurs bei oder über 1,2 × 200-Tage-Linie“, „… fehlten Tageskerzen (σ₇ oder
  200-Tage-Linie)“ oder beides (über alle Minuten bis vor den Kauf, dieselbe Bedingung wie A0 in `akku_regel_kerzen`). `akku_grund_text`
  schreibt den Text aus 23.70 für die Anzeige um (`akku_daten` für Reiter und Bericht, `uebersicht` für die Ereignisse); in der Datenbank
  bleibt er. Bericht: Grund eines Kaufs bis 320 statt 120 Zeichen (der Startkauf-Grund endete sonst mitten im Satz).
- **Unverändert:** Regeln, Kennungen, Rückrechnung, gespeicherte Käufe und Tageszeilen. Die drei Startkäufe auf dem Pi zeigen den neuen
  Text ohne Ursache (die steht nicht im gespeicherten Text, und nachgerechnet wird nicht noch einmal).

**Proben:** Teil „Akkumulation“ 16 von 16 (neu: Grund des Startkaufs von Hand -- sofort auch bei einem Start mitten in der Minute, später
wegen der Sperre, wegen fehlender Tageskerzen, wegen beidem; Text aus 23.70 → neu, zweimal angewandt gleich, andere Texte unverändert;
Speicher mit den Texten aus 23.70: Kauf, Ereignis und Bericht neu, gespeicherte Texte unverändert; Ende zu Ende mit spätem Startkauf:
Kurs 5 h über der Sperre, Kauf in der ersten erlaubten Minute zur Eröffnung, Grund mit Zeit und Ursache), ganzer Labor-Selbsttest 83 von
83 (126 s). Mutationen 11 von 11 rot (Umschreiben aus, nur in den Käufen, nur in den Ereignissen; Ursache fehlt, vertauscht, nur die
letzte Minute, auch bei sofortigem Kauf, Zeit vom Start statt vom Kauf, „beides“ als Sperre; Text von 23.70 beim Nachrechnen; Bericht
120 Zeichen); die 25 Mutationen der Regel aus 23.70 erneut: 25 von 25 rot. Browserprobe mit neuen Daten (ETH mit dem gespeicherten Text aus
23.70, HYPE später gekauft; 14 bzw. 6 Käufe) 75 von 75 am Rechner, auf dem Handy (390 px) und schmal (360 px); Mutationen der Anzeige 41 von 41 rot (die 20 aus 23.70 und 21 neue: „Alle Käufe“ fehlt, alt zuerst, nur ein Coin, zu, Knopf ohne Wirkung, Nummer falsch, ohne „nachgerechnet“, ohne Grund, am Handy alle Spalten; Tagestabelle mit „Käufe“ nur des Tages, ohne „neu“, „neu“ ganz weg, „neu“ ohne Coin, ohne Markierung, alter Titel, „Gewinn USD“ am Handy, ohne Coin-Filter; Handy ohne Preis unter dem Coin, ohne neue Käufe unter dem Tag, ohne schmale Ränder, Zusatzzeilen auch am Rechner).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` im ausgepackten Vorpaket von 23.71: **61 von 61 grün** (46 Schritte, PNG, 14
Dashboard-Abrufe), 1.201 s; Ausblick 576,7 s, TradeLabor 101,4 s. Danach nur eine Kommentarzeile in `hl_labor.py` berichtigt (sie
behauptete für ETH und HYPE die Sperre als Ursache, das ist nicht nachgeprüft); der Syntaxbaum ist gleich, die Prüfsumme deshalb
f3113c906a statt bbf6838259. Paket: 120 Einträge, 102 Dateien, Reihenfolge und Rechte wie 23.70, Stempel 2026-09-23.71 ·
f3113c906a, `py_compile` aller Skripte im ausgepackten Paket ok.

**Erwartung auf dem Pi:** nach dem Einspielen dieselben drei Käufe; darunter „Alle Käufe (3)“; „Stand je Tag“ mit „Käufe“ 1, ab dem
07.10. 2, ab dem 19.10. 3 und den drei Kauftagen markiert; beim Startkauf der neue Text. Keine neue Kennung, keine zweite Rückrechnung.
Mit 23.71 kommen über das `update.py` von 23.70 auch `KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` auf den Pi
(Probe: das `update.py` von 23.70 spielt 23.71 ein, danach 23.71 sich selbst -- beide Dokumente da und gleich dem Paket,
alle .py gleich, Version 23.71, `check_abdeckung.py` vorher gesichert; 16 von 16).

**Nebenbefund (nicht geändert):** Bei 320 px Breite ragen zwei Abschnittsköpfe (Pfeil ▾) 2 bzw. 17 px über den Rand; so schon in
23.70, ab 360 px nicht. Bei 320 px scrollt „Alle Käufe“ zudem 17 px im eigenen Rahmen.

**Zusage bis 25.10. eingehalten:** nur Anzeige und Texte des Labors.

Lehre: **Eine Tabelle mit einer Zeile je Tag sieht aus wie eine Liste von Ereignissen -- ihr Titel muss sagen, was eine Zeile ist, und
die Liste, die man sucht, muss es geben. Ein Text, der einen Zeitpunkt begründet, braucht in der Probe auch den späten Fall.**

## 3ωωω. Paket 23.72: Akkumulation -- Korrekturkauf A4 (7 % in 48 h, Nachkauf je 7 % binnen 14 Tagen, ohne Sperre, rückwirkend) (U186) (20.10.; Version 2026-09-23.72 · 1a8c1b577d, Opus 5.5)

**Wunsch des Nutzers (20.10. 02:43, vor dem Einspielen von 23.71, Kern wörtlich):** Bei „scharfen Korrekturen … ab 7 % Korrektur
innerhalb von 48 Stunden“ kaufen; „Sollte eine weitere Korrektur nach dem Kauf eintreten, erneut … mindestens 7 %, sollte auch
entsprechend weiter nachgekauft werden“, „zum Beispiel innerhalb von 2 Wochen“; „für alle Coins“; „Verpacke es so, dass die Strategie
nicht leer ausgeht, sondern sinnvoll einkauft“; „als einmalige Regel zunächst rückwirkend … und dann ab sofort“; ZEC und vermutlich HYPE
hätten solche Einbrüche gehabt. **Meine Rückfrage** (gilt die Sperre ab 1,2 × 200-Tage-Linie auch hier? ZEC und XMR hatten deshalb
seit dem Start keinen Kauf) **beantwortete er mit „Ohne Sperre (Vorschlag)“.** 23.72 enthält alles aus 23.71 (3ψψψ, nicht eingespielt).

**Gebaut (U186, `KONZEPT_Akkumulation.md` 2, 3, 4, 7c):**
- Regeln: `korr` 0,07, `korr_h` 48, `korr_tage` 14 in `AKKU_REGELN` (beide Strategien) → neue Kennungen.
- `akku_korrektur_lage` (live) und `akku_korrektur_kerzen` (Rückrechnung, dieselbe Regel): Bezug = das höhere von (a) dem Hoch der
  1-min-Kerzen der letzten 48 h -- nach einem Korrekturkauf erst ab der Minute danach, damit derselbe Einbruch einmal kauft -- und (b)
  dem letzten Korrekturkauf, solange jünger als 14 Tage; Kauf bei Kurs ≤ 0,93 × Bezug; auf Kerzen Auslösung am Tief, Kauf zur Schwelle
  bzw. Eröffnung, mehrere Stufen je Kerze. `akku_h7_reihe` mit Fensterlänge (48 h), `Labor._akku_h48` (live, je Minute gecacht).
- **Eigene Spur:** `Labor._akku_letzte` trennt den letzten Kauf A0–A3 vom letzten Korrekturkauf; A0–A3 kaufen genau wie ohne A4. Live
  höchstens ein Kauf je Takt, Coin und Spur. A4 live erst nach der Rückrechnung (fehlen beim ersten Takt die Tageskerzen, wartet A4 mit).
- **Rückrechnung** (`_akku_nachrechnen`): beide Spuren getrennt, gespeichert nach der Zeit (gleiche Minute: A0–A3 zuerst); Tageszeilen
  und Ereignisse wie bisher; Zustand „nach“ mit der Zahl der Korrekturkäufe.
- Vergleich gegen Zufallszeiten und Rückblick seit 2020 weiter nur A1–A3; `akku_daten` mit `n_korr`; Bericht, Datenfluss („Hoch 48 h“),
  Ereignisse früherer Regelstände „(alte Regeln)“.
- `hl_viz.py`: Auslöser „Korrektur“, Regeln-Zeile, Kennzahl „k Korrektur“, Lage-Zeile „Korrektur (ohne Sperre): Kauf ab …“, Hinweis
  zum Vergleich; frühere Regelstände nur über „frühere Regeln (n)“, eine im Browser gemerkte alte Kennung fällt auf die laufende zurück;
  Hilfetext.

**Proben:** Teil „Akkumulation“ 25 von 25 (neu: Korrekturkauf von Hand 10 Fälle, auf Kerzen von Hand -- 48 h statt 7 Tage, derselbe
Einbruch einmal, neues Hoch nach dem Kauf, Nachkauf nach 9 Tagen, Eröffnung darunter und zweite Stufe in einer Kerze, nach 14 Tagen
keiner --, Rechnung = unabhängige Referenz auf drei Zufallswegen mit Einbrüchen, Rückrechnung = Live-Regel Takt für Takt, 48-h-Hoch live
von Hand; im Labor: Korrekturkäufe live am Dump gleich einer unabhängigen Takt-Rechnung, ohne die Regel dieselben Käufe A0–A3, ein Coin
wie ZEC über der Sperre mit Korrekturkäufen rückwirkend und live, Tageskerzen erst im zweiten Takt; frühere Regelstände in den
Ereignissen); ganzer Labor-Selbsttest 92 von 92 (123 s). Mutationen 19 von 19 rot (Korrektur 14 statt 7 %; Fenster 7 Tage statt 48 h; Nachkauf 7 statt 14 Tage auf Kerzen und live; derselbe Einbruch doppelt; ohne Nachkauf; ohne Stufen; ohne Eröffnung; live mit Sperre; Rückrechnung ohne A4; Spur vereint; 48-h-Hoch ohne Ausschluss der Kaufminute bzw. mit Zukunft; Vergleich mit A4; ohne „(alte Regeln)“; Art des Bezugs vertauscht; live ohne A4; Reihenfolge in derselben Minute; A4 live vor der Rückrechnung); die 36 älteren aus 23.70 und 23.71 erneut 36 von 36 rot (vier Zeichenketten an den neuen Code angepasst). Browserprobe mit neuen Daten (ZEC mit Korrekturkäufen ohne Startkauf, HYPE
live, ein früherer Regelstand mit zwei Käufen) 84 von 84; Mutationen der Anzeige 50 von 50 rot (die 41 aus 23.71 und 9 neue: „Korrektur“ ohne Namen, Lage ohne Korrektur-Zeile, Bezug vertauscht, frühere Regeln immer sichtbar, gemerkte alte Wahl bleibt, alle Knöpfe, Kennzahl ohne Korrektur, Regeln-Zeile ohne Korrektur, Hinweis zum Vergleich alt).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` im ausgepackten Vorpaket von 23.72 (Code gleich dem Paket): **61 von 61 grün** (46 Schritte,
PNG, 14 Dashboard-Abrufe), 1.335 s; Ausblick 650,4 s, TradeLabor 119,1 s. Paket: 120 Einträge, 102 Dateien, Reihenfolge und
Rechte wie 23.70, Stempel 2026-09-23.72 · 1a8c1b577d, `py_compile` aller Skripte im ausgepackten Paket ok.

**Erwartung auf dem Pi:** Beim ersten Takt nach dem Einspielen legt das Labor die neuen Kennungen an und rechnet je Coin ab seinem Start
nach: dieselben drei Startkäufe wie bisher (BTC, ETH, HYPE), dazu jeder Korrekturkauf seit dem 27.09. (der Nutzer erwartet welche bei ZEC
und HYPE; wie viele, zeigt erst der Pi). Die bisherige Bilanz steht unter „frühere Regeln (2)“ -- je eine für die Haupt- und die
Kontrollstrategie. Über das `update.py` von 23.70 kommen `KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` mit
(Probe: das `update.py` von 23.70 spielt 23.72 ein, danach 23.72 sich selbst -- beide Dokumente da und gleich dem Paket, alle .py
gleich, Version 23.72, `check_abdeckung.py` vorher gesichert; 16 von 16).

**Zusage bis 25.10. eingehalten:** nur das Labor; A4 liest nur die 1-min-Kerzen.

Lehre: **Eine Zusatzregel bekommt eine eigene Spur -- dann bleiben die geprüften Regeln gleich, und eine Probe kann es zeigen.**

## 3αααα. CryptoQuant-Bericht vom 19.10. geprüft (U158); 23.72 läuft auf dem Pi; neu U187 (20.10. 07:37; nur Dokumente, Version 2026-09-23.72 · 1a8c1b577d unverändert, Opus 5.5)

**Hochgeladen 20.10. 07:33:** Sammeldatei der geplanten Berichte der letzten 24 h, erstellt mit 2026-09-23.72 · 1a8c1b577d -- das
Paket von heute Nacht läuft also auf dem Pi. Darin ein Bericht: „★ Hebel: CryptoQuant-Anteil der Derivate (U158)“ vom 19.10. 20:15
(Modul 23.68, Exit 0, 1,1 s).

**Die offenen Punkte aus 3ξξξ („Erst auf dem Pi zu sehen“, U158) sind beantwortet:**
- Der kostenlose Schlüssel bekommt `price-ohlcv` je Tag: beide Märkte Status 200 „success“, je 30 Tage (19.09.–18.10.), nichts
  verworfen. Der Widerspruch der Doku („Token erst ab Professional“) gilt nicht; das Datum kommt als JJJJ-MM-TT.
- Antwortform: Felder close, date, high, low, open, volume; genutzt wird nur volume.
- Einheit: Die Antwort nennt keine, laut Doku BTC. Die Größenordnung passt (Median je Tag Perps 270.790, Spot 27.784; in USD gelesen
  wären es einige hunderttausend Dollar am Tag -- unmöglich). D hängt nur am Verhältnis; am selben Tag lag D im Median 0,3 Punkte unter
  dem Perp-Anteil von Binance allein (10–90 %: −1,6 … +0,3; Binance-Median 90,2 %) -- eine unabhängige Bestätigung.
- Revisionen 0 seit dem 17.10.

**Stand der Reihe:** 32 Tage (17.09.–18.10.), D zuletzt 91,0 %, Median 89,4 %, Spanne 83,2–91,4 %; **kein Tag ≥ 95 %**. S5 noch nicht
prüfbar (0 Signaltage, 0 Episoden, 24 gültige Tage ohne Signal, L 32 von 180 Tagen) -- kein Urteil, wie vorab festgelegt. Wellenquote an
den gültigen Tagen 4,2 % (1 von 24). Erwartung unverändert (`KONZEPT_Hebel.md` 14, Nachtrag „Erster Bericht vom Pi“).

**Dabei bemerkt, eigener Fehler aus 23.72 (neu U187):** Der Labor-Bericht (`akku_bericht`) nennt frühere Regelstände der Akkumulation
mit demselben Titel wie die laufenden. Im Bericht vom 20.10. 08:45 stehen deshalb je zwei Blöcke „Akkumulation“ und „Akkumulation ohne
Heatmap (Kontrolle)“: die ersten beiden sind die alte Bilanz von 23.70 (je drei Startkäufe), die letzten beiden die neue mit den
Korrekturkäufen (Reihenfolge nach der Anlage). Reiter (Knopf „frühere Regeln“) und Ereignisse („(alte Regeln)“) trennen richtig.
Behebung mit dem nächsten Paket: im Bericht „(alte Regeln)“ und die laufenden zuerst.

Lehre: **Wer eine Kennzeichnung einführt, prüft jede Ausgabe derselben Daten -- Reiter, Ereignisse und Bericht.**

## 3ββββ. Akkumulation: Tagestabelle mit „Kauf an diesem Tag“ (U188), Bericht mit „(alte Regeln)“ (U187) (20.10. 09:36; Version 2026-09-23.73 · 5563865ed5, Opus 5.5)

**Hinweis des Nutzers 08:57** (Bild der Tabelle „Stand je Tag“ für BTC mit 23.72: 24 Tage, in jeder Zeile „Käufe 1“, eingesetzt
5.000): „Bei einem Rücksetzer von 7 % soll er kaufen und bei erneutem Rücksetzer erneut. Aber zwischen den Käufen gibt es keine 7 %
Rücksetzer. Hier scheint glaube ich etwas falsch zu laufen.“

**Nachgeprüft mit den Zahlen des Bildes:** Die Rechnung stimmt. BTC hat seit dem 27.09. einen einzigen Kauf, den Startkauf (5.000 USD
zu rund 84.454 = 0,059162 BTC); Wert ÷ Kurs ergibt an jedem Tag 0,05916 BTC. Eine Korrektur von 7 % binnen 48 h gab es bei BTC seitdem
nicht: größter Rückgang zwischen zwei Tagesschlüssen im Abstand von zwei Tagen 4,5 % (06.10. 85.547 → 08.10. 81.713). Die Spalte „Käufe“
zählte aber die Käufe **bis** zu diesem Tag (in jeder Zeile 1) und las sich wie „an diesem Tag ein Kauf“ -- eigener Gestaltungsfehler
aus 23.71, zum zweiten Mal dieselbe Verwechslung (3ψψψ). Wahl des Nutzers: „Jetzt als 23.73“.

**Gebaut (`KONZEPT_Akkumulation.md` 3, 7d; Rechnung, Regeln, Kennungen und gespeicherte Käufe unverändert):**
- **U188** (`hl_viz.py` `akTabelleTage`): Spalte **„Kauf an diesem Tag“** statt der Zählung -- „—“ ohne Kauf, sonst ⊕ mit Coin und
  Auslöser (Zeile grün); **„eingesetzt gesamt“**; Titel „Stand je Tag — keine Kaufliste: je Zeile der Bestand am Ende des Tages; gekauft
  wurde nur an Tagen mit ⊕ …“. Auf dem Handy in der Spalte nur „—“ oder ⊕, die Namen unter dem Tag. Hilfetext angepasst.
- **U187** (`hl_labor.py` `akku_bericht`, Fehler aus 23.72): zuerst die laufenden Strategien, danach jeder frühere Regelstand in einer
  Zeile mit „(alte Regeln)“, früherer Kennung und „kauft nicht mehr“, ohne Coin-Zeilen; „1 Kauf“ statt „1 Käufe“.

**Proben:** Teil „Akkumulation“ 25 von 25 (die Anzeige eines Speichers aus 23.70 prüft jetzt auch den Bericht mit einer eingefügten
alten Bilanz: Reihenfolge laufend, Kontrolle, alt; „frühere Kennung …, kauft nicht mehr“; danach der Hinweis); ganzer Labor-Selbsttest
92 von 92 (162 s, neben der Browserprobe). Mutationen des Berichts 4 von 4 rot (ohne „(alte Regeln)“, alte zuerst, alte ausführlich,
„1 Käufe“). Browserprobe 84 von 84 am Rechner, auf dem Handy (390 px) und schmal (360 px), mit neuen Prüfungen der Tagestabelle (Kopf
ohne Zählspalte, „—“ an Tagen ohne Kauf, ⊕ und Namen an Kauftagen, eingesetzt gesamt = Käufe bis dahin × 5.000 USD, Markierung, je
Coin und alle, Titel). Mutationen der Anzeige 53 von 53 rot (die 47 aus 23.72, die zum neuen Code passen -- eine davon, „alter Titel“, an den neuen Titel angepasst --, und 6 neue: Zählung zurück, ohne „—“, ohne Namen, Kopf ohne „gesamt“, Handy mit Namen in der Spalte, Handy ohne ⊕; die 3 Mutationen der alten Zählspalte entfallen mit ihr).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` im ausgepackten Vorpaket von 23.73 (Code gleich dem Paket): **61 von 61 grün** (46 Schritte,
PNG, 14 Dashboard-Abrufe), 1.422 s; Ausblick 676,8 s, TradeLabor 136,2 s. Paket: 120 Einträge, 102 Dateien, Reihenfolge und
Rechte wie 23.72, Stempel 2026-09-23.73 · 5563865ed5, `py_compile` aller Skripte im ausgepackten Paket ok. **Probe von update.py:** das
`update.py` von 23.72 spielt 23.73 ein, danach 23.73 sich selbst -- alle .py und die geänderten Dokumente gleich dem Paket (vorher
anders), Version 23.73, `check_abdeckung.py` gesichert, Syntaxprüfung im Protokoll; 24 von 24 (mit einem falschen Archivpfad 6 von 24:
die Probe merkt ein gescheitertes Einspielen).

**Erwartung auf dem Pi:** Dieselben Zahlen wie mit 23.72; in „Stand je Tag“ bei BTC „—“ an allen Tagen außer dem 27.09. (⊕ BTC
Startkauf) und eingesetzt gesamt 5.000, solange kein weiterer Kauf dazukommt. Im Labor-Bericht stehen die beiden laufenden Strategien zuerst, die beiden früheren Regelstände von
23.70 danach je in einer Zeile mit „(alte Regeln)“. Ob ZEC und HYPE Korrekturkäufe bekommen haben, zeigt erst der Bericht vom 20.10.
08:45 oder ein Bild der Liste „Alle Käufe“ (noch nicht hochgeladen).

**Zusage bis 25.10. eingehalten:** nur Anzeige und Bericht des Labors.

Lehre: **Eine Spalte, die bis heute zählt, liest jeder als „heute“ -- in einer Tagestabelle steht, was an dem Tag geschah, die Summe
heißt „gesamt“.**

## 3γγγγ. Akkumulation: Faktor gegenüber BTC für Korrekturkauf und Betrag, Tabelle „Schwellen je Coin“ (U189) (20.10. 11:36; Version 2026-09-23.74 · bc6ebee746, Opus 5.5)

**Wunsch des Nutzers 09:55** (Kern wörtlich): „die Volatilität bei Coins wie … ZEC … oder Hype [ist] viel größer als … bei BTC. Wir haben
aber pauschale Regeln für BTC festgelegt“; „teilweise hatte ZEC Käufe von über 70.000“; „Es soll nur im Falle von äquivalenten
Rücksetzern dazu kommen“; „beim Erstlauf … die Volatilität bestimmt … und dann die Käufe [rückwirkend] ausgeführt“; „eine Tabelle …, wo
man einfach reingucken kann, wie die Schwellen sind“; „in ZEC sollte eigentlich wesentlich weniger investiert werden“.

**Befund:** A1–A3 rechnen schon mit σ₇ des einzelnen Coins; fest in Prozent waren nur der Korrekturkauf A4 (7 %) und die Sperre (1,2 ×
200-Tage-Linie). ZEC lag meist über der Sperre -- seine Käufe waren fast alle Korrekturkäufe. Grobe Schätzung vor dem Bau
(Tagesschlüsse Crypto.com, 01.09.–19.10., 48 Renditen; ZEC und XMR dort nicht vorhanden): HYPE 1,8 × BTC, ETH 1,2 ×.

**Rückfragen → Wahl des Nutzers:** nur A4 anpassen („Nur Korrektur A4 (Vorschlag)“), Faktor fest aus den 365 Tagen vor dem Start („Fest,
365 Tage vor Start (Vorschlag)“), Betrag geteilt durch den Faktor („5.000 USD ÷ Faktor, jetzt mit“).

**Vorab festgelegt** (`KONZEPT_Akkumulation.md` 2 und 7e, 10:18 nach `date`, vor dem Code): f = max(1, σ̄_Coin ÷ σ̄_BTC), auf zwei Stellen;
σ̄ = Wurzel aus dem Mittel der Tages-RV (30-min-Renditen, dieselbe Größe wie σ_Tag) der vollen Tage in den 365 Tagen vor dem Start des
Coins im Labor, nur Tage mit gültiger RV bei Coin und BTC, mindestens 60; fest gespeichert. In der Nachricht an den Nutzer stand „σ der
Tagesrenditen“ -- gemessen wird σ_Tag aus den 30-min-Renditen (wie σ₇ der Regeln A1–A3).

**Gebaut (`KONZEPT_Akkumulation.md` 2, 3, 7e):**
- `hl_labor.py`: Regeln `faktor_basis` „BTC“, `faktor_tage` 365, `faktor_min` 1, `faktor_korr`, `faktor_betrag` (neue Kennungen);
  `akku_korr_q`, `akku_betrag`, `akku_pc`; `akku_faktor_aus_rv`, `akku_faktor_rechnen` (swing.db nur lesend, nichts ab dem Start; BTC immer
  1); Tabelle `labor_akku_faktor`; `Labor._akku_faktor` (einmal bestimmen und speichern, danach nur lesen; ohne Faktor kein Kauf und der
  Grund in der Lage, neuer Versuch nach 10 min); Korrekturkauf live und rückwirkend mit 0,93^f; Betrag 5.000 ÷ f für jeden Kauf (A0–A4,
  live und rückwirkend), Faktor in den Werten jedes Kaufs; `akku_schwellen` und `akku_daten` (je Coin Faktor und Schwellen); Labor-Bericht
  mit „Schwellen je Coin“; Beschreibung der Strategie.
- `hl_viz.py`: Tabelle „Schwellen je Coin“ unter den Regeln (Faktor mit σ darunter, Betrag, Korrektur, A1, A2, A3, Sperre; Handy: Coin,
  Faktor, Betrag, Korrektur), Regeln-Zeile und Kennzahl „5.000 USD ÷ Faktor je Kauf“, Lage-Zeile der Korrektur mit einer Nachkommastelle,
  Hilfetext.
- `install.py` Bezeichnung des Selbsttest-Schritts; `version.py` 23.74. Enthält 23.73 (U187, U188).

**Proben:** Teil „Akkumulation“ 32 von 32 (7 neu: Faktor von Hand -- RV 9-mal → 3,00, gleich → 1,00, ruhiger → 1,00 als Untergrenze, unter 60 gemeinsamen Tagen kein Faktor, Tage ohne gültige RV zählen nicht; Schwellen und Betrag von Hand -- 7 % und 5.000 USD bei Faktor 1, 19,56 % und 1.666,67 USD bei Faktor 3, Nachkauf ebenso, mehrere Stufen in einer Kerze je 0,93³; Faktor aus swing.db -- dreifacher Log-Weg → 3,00 aus genau den 365 Tagen vor dem Start, Kerzen ab dem Start und vor dem Fenster ändern nichts, im Fenster schon, ohne swing.db kein Faktor, BTC trotzdem 1; **Positivkontrolle Gleichwertigkeit** -- ein Coin mit dreifachem Log-Weg kauft mit Faktor 3 in denselben Minuten wie BTC (27, 23 und 23 Käufe auf drei Wegen), mit fest 7 % 141, 131 und 129; BTC mit Faktor 1 = Regel von 23.72; Rückrechnung = Live-Regel Takt für Takt mit Faktor 3; im Labor mit Faktor 3 -- für beide Strategien gespeichert, alle Käufe 1.666,67 USD, Korrekturkäufe rückwirkend gleich der Referenzrechnung mit 0,93³ und live gleich der unabhängigen Takt-Rechnung, 3 Korrekturkäufe statt 11 mit Faktor 1 auf demselben Weg, Tabelle in den Daten und im Bericht; Faktor fest nach einem Neustart mit geänderter swing.db; ohne BTC in swing.db kein Kauf und kein Fehler). Ganzer Labor-Selbsttest 99 von 99 (208 s, neben den Mutationsläufen); mit den beiden später ergänzten Proben im ausgepackten Endpaket erneut 99 von 99 (159 s). Mutationen 20 von 20 rot (Faktor ohne Wirkung; Korrektur ohne Faktor live bzw. rückwirkend; Betrag ohne Faktor live bzw. rückwirkend; Kehrwert; ohne Untergrenze; Fenster mit Zukunft; Faktor jedes Mal neu; Nachkauf ohne Faktor; Stufen in einer Kerze ohne Faktor, nur die Bedingung bzw. ganz -- die erste blieb zuerst grün, dafür kamen die Fälle mit mehreren Stufen in einer Kerze dazu und der erste A7-Lauf wurde abgebrochen; Schwelle linear; ohne Mindestzahl Tage; BTC ohne Daten ohne Faktor; Bericht ohne Schwellen; Daten ohne Schwellen; Fenster 180 Tage; Warten ohne Wirkung; Faktor ungerundet); die 59 älteren aus 23.70–23.73 erneut 59 von 59 rot (eine -- „A4 live vor der Rückrechnung“ -- blieb zuerst grün: die Probe „Tageskerzen erst im zweiten Takt“ hielt seit dem Faktor schon am fehlenden Faktor an; jetzt mit gespeichertem Faktor, danach rot; acht Zeichenketten an den neuen Code angepasst). Browserprobe 92 von 92 am Rechner, auf dem Handy (390 px) und schmal (360 px) mit Faktoren 1 / 1,25 / 3 / 1,8 / 1,4 und einer swing.db mit bekanntem σ_Tag: Tabelle „Schwellen je Coin“ (Lage unter den Regeln, Kopf, je Coin Faktor mit σ, Betrag, Korrektur, A1/A2/A3, Sperre mit „gesperrt (nur A4)“, zugeklappt bleibt zu; Kontrolle ohne A2; ohne Faktor „Faktor folgt“), Regeln-Zeile, Kennzahl, Lage-Zeile der Korrektur (19,6 bzw. 12,2 %), eingesetzt gesamt als Summe der Beträge. Mutationen der Anzeige 65 von 65 rot (die 53 aus 23.73, vier Zeichenketten an die neue CSS-Regel angepasst, und 12 neue: Tabelle fehlt, zu, Spalten vertauscht, Betrag ohne Faktor, Handy zu breit, „Faktor folgt“ fehlt, „gesperrt“ fehlt, σ fehlt, A2 fehlt, Regeln-Zeile ohne Faktor, Kennzahl ohne Faktor, Prozent gerundet).

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` im ausgepackten Vorpaket von 23.74 (Code gleich dem Paket bis auf den Selbsttest in hl_labor.py,
siehe unten): **61 von 61 grün** (46 Schritte,
PNG, 14 Dashboard-Abrufe), 1.642 s; Ausblick 836,1 s, TradeLabor 147,7 s. Paket: 120 Einträge, 102 Dateien, Reihenfolge und
Rechte wie 23.73, Stempel 2026-09-23.74 · bc6ebee746, `py_compile` aller Skripte im ausgepackten Paket ok. **Probe von update.py:** aus
23.72 und aus 23.73 je 24 von 24 (alle .py und die geänderten Dokumente gleich dem Paket, vorher anders; Version 23.74;
`check_abdeckung.py` gesichert; Syntaxprüfung im Protokoll). Ein erster A7-Lauf (Vorpaket 51d52c4f06) wurde nach 7 Minuten
abgebrochen, weil eine Mutation grün blieb (Proben oben). Der zweite lief auf dem Vorpaket 81cbdb7880; danach änderte sich
hl_labor.py nur noch im Selbsttest (Probe „Tageskerzen erst im zweiten Takt“ mit gespeichertem Faktor, weil eine ältere Mutation
grün blieb) -- der Selbsttest des TradeLabors deshalb noch einmal im ausgepackten Endpaket: 99 von 99 (159 s); alle übrigen .py gleich dem
Vorpaket.

**Erwartung auf dem Pi:** Beim ersten Takt mit 23.74 legt das Labor die neuen Kennungen an, bestimmt je Coin den Faktor aus swing.db (365
Tage vor dem 27.09.; XMR vor seinem Start) und rechnet ab dem Start alles neu nach. BTC: Faktor 1, dieselben Käufe wie bisher (Startkauf
27.09., 5.000 USD). Bei ZEC, HYPE und ETH höhere Korrektur-Schwellen und kleinere Beträge, also deutlich weniger eingesetzt als mit 23.72
(ZEC über 70.000 USD); wie groß die Faktoren sind, zeigt erst die Tabelle „Schwellen je Coin“ auf dem Pi. Die Bilanzen von 23.70 und
23.72 stehen unter „frühere Regeln (4)“ -- als Vergleich alt gegen neu.

**Zusage bis 25.10. eingehalten:** nur das Labor; der Faktor liest swing.db wie schon σ₇ und die 200-Tage-Linie.

Lehre: **Eine Schwelle in Prozent stimmt nur für einen Coin -- wer mehrere Coins mit derselben Regel kauft, rechnet sie in σ.**

## 3δδδδ. Berichte vom 20.10. geprüft: Rückblick der Akkumulation seit 2020, Labor-Bericht mit fest 7 %; 23.74 läuft (20.10. 15:33; nur Dokumente, Version 2026-09-23.74 · bc6ebee746 unverändert, Opus 5.5)

**Hochgeladen 20.10. 15:29:** Sammeldatei der geplanten Berichte der letzten 24 h, erstellt mit 2026-09-23.74 · bc6ebee746 -- das Paket
von 11:37 läuft also auf dem Pi. Drei Berichte: CryptoQuant 19.10. 20:15 (schon in 3αααα geprüft), Akkumulation-Rückblick 20.10. 08:46
und Labor-Bericht 20.10. 08:46 (beide noch mit 23.72).

**Rückblick seit 2020** (vorab festgelegt, `KONZEPT_Akkumulation.md` 5; Regel A1/A3 mit Sperre auf den 30-min-Kerzen aus swing.db,
71,6 s): Zeitpunkt-Maß Q gegen 200 Vorzeichen-Surrogate -- BTC +1,51 % (Surrogate +1,14 %, p 0,313), ETH +2,51 % (+2,32 %, p 0,448),
**ZEC +7,71 % (+2,63 %, p 0,020, beide Hälften darüber: belegt)**, XMR +4,41 % (+0,71 %, p 0,055: knapp nicht), HYPE 1 Kauf (zu kurz).
Beschreibend: vier geprüfte Coins, bei 5 % Fehlalarm je Coin wäre einer mit 18,5 % Wahrscheinlichkeit zufällig dabei; nach Bonferroni
bestünde ZEC nicht. Erwartet war Q nahe null oder leicht negativ -- es war bei allen vier positiv, bei BTC und ETH im Band der
Zufallswege. Keine Änderung der Regel. Dazu: A1/A3 rechnen mit σ₇ des Coins und kauften ähnlich oft (BTC 76, ETH 75, ZEC 61, XMR 55
in gut sechs Jahren) -- die Gleichwertigkeit, die U189 seit 23.74 auch dem Korrekturkauf gibt.

**Labor-Bericht 08:46 (23.72):** zwei Blöcke je Strategie mit demselben Titel (U187, seit 23.73 behoben): zuerst die Bilanz von 23.70 (3
Startkäufe, 15.000 USD), dann die von 23.72 mit fest 7 % -- 27 Käufe, 135.000 USD, Wert 127.041 USD (−5,90 %): BTC 1 (Startkauf), ETH 3
(1 + 2 Korrektur), **ZEC 16 Korrekturkäufe (80.000 USD, 59 % des Einsatzes; Wert 73.048 USD, −8,69 %)**, HYPE 6 (Startkauf 18.10. und 5
Korrektur), XMR 1 Korrektur (über der Sperre). Das bestätigt den Befund des Nutzers von 09:55. Diese Bilanz steht mit 23.74 unter
„frühere Regeln“; die neue mit dem Faktor zeigt erst der nächste Labor-Bericht (spätestens Mittwoch 21.10. 19:00) oder ein Bild des
Reiters.

**Zusage bis 25.10. eingehalten:** nur gelesen und dokumentiert.

Lehre: **Der Rückblick mit σ-Regeln war schon gleichwertig über die Coins -- die eine Regel in festen Prozent war es nicht. Ein
Vergleich der Kaufzahlen je Coin zeigt so etwas früher als die Bilanz.**

## 3εεεε. Fehlerleiste „/speicher: keine Verbindung (Failed to fetch)“ geprüft -- harmlos, keine Änderung (20.10. 16:21; nur Dokumente, Version 2026-09-23.74 · bc6ebee746 unverändert, Opus 5.5)

**Bild des Nutzers 16:16** (Handy, Dashboard): rote Leiste „16:15:22 /speicher: keine Verbindung (Failed to fetch)“, sonst keine Zeile.

**Ursache:** `speicherLaden` (Bereich „Speicherorte“) fragt `/speicher` jede Minute ab, auch bei verborgener Seite
(`setInterval(speicherLaden, 60000)` ohne Prüfung der Sichtbarkeit; ebenso `berichteLaden` alle 2 min, `konfBilanzLaden` alle 10 min,
`loadHealth` stündlich). Liegt der Browser im Hintergrund oder verbindet sich das WLAN nach dem Aufwecken neu, scheitert die Anfrage
im Netz („Failed to fetch“, keine HTTP-Antwort). Ein Fehler im Dashboard ergäbe „HTTP 500 …“ (`do_GET` fängt jede Ausnahme), ein
nicht erreichbares Dashboard weitere Zeilen („/data“, „/chart“). Die Leiste räumt sich mit der nächsten erfolgreichen Antwort selbst weg
(`clearFetchErr`; bei sichtbarer Seite `loadChart` alle 5 s).

**Entscheidung des Nutzers:** „Gar nicht“ (Vorschlag war, die vier Abfragen mit dem nächsten Paket nur bei sichtbarer Seite laufen zu
lassen). Nicht wieder vorschlagen, solange keine echten Ausfälle dazukommen.

## 3ζζζζ. Berichte vom 21.10. geprüft: erster Labor-Bericht mit dem Faktor, Zählung der Regel (c), Vollbericht in 354 s, Kriterium 5 (21.10. 22:17; nur Dokumente, Version 2026-09-23.74 · bc6ebee746 unverändert, Opus 5.5)

**Hochgeladen 21.10. 21:34:** Sammeldatei der geplanten Berichte der letzten 24 h (erstellt 21:33 mit 2026-09-23.74 · bc6ebee746), 24
Berichte, alle Exit 0: Akkumulation-Rückblick 08:46, der Wochenlauf ab 19:00 (Vollbericht, Elite, Pool, Sperren, Empfehlungen, Profile,
Magnet 60 Tage, Fusion, Kalibrierung v2, Kaskaden, Magnet-Test, Makro, Vorbedingungen, Anker, Familien, Konfluenz, Abdeckung,
Adress-Strom, Profis, CryptoQuant, Labor 19:15), dazu der Labor-Bericht 08:46 und die Zählung der Regel (c) 21:15 (zweiter Termin; der
erste lief 20.10. 21:15 und liegt außerhalb der 24 h).

**Akkumulation mit dem Faktor (U189), erster Bericht -- die Erwartung vorab ist eingetreten:**
- Faktoren (fest aus den 365 Tagen vor dem Start, σ_Tag von BTC 2,34 %): BTC 1,00 · ETH 1,39 (σ_Tag 3,24 %) · ZEC 3,45 (8,07 %) ·
  HYPE 2,25 (5,28 %) · XMR 2,08 (4,86 %). Daraus je Kauf 5.000 / 3.597 / 1.449 / 2.222 / 2.404 USD und der Korrekturkauf A4 ab −7,0 /
  −9,6 / −22,1 / −15,1 / −14,0 % unter dem 48-h-Hoch.
- Nachgerechnet: Beträge, Schwellen, Ø Einstand, Werte und eingesetzt (14.416,47 USD) stimmen; der ETH-Korrekturkauf vom 08.10. 17:30
  liegt genau auf der Schwelle (2.719,4 · 0,93^1,39 = 2.458,47).
- Neue Bilanz (Hauptstrategie und Kontrolle gleich): 4 Käufe seit 27.09., 14.416 USD eingesetzt, Wert 14.553 USD (+0,95 % um 19:15;
  08:46 −0,95 %). BTC Startkauf; ETH Startkauf 07.10. und Korrekturkauf 08.10.; HYPE Startkauf 18.10.; ZEC und XMR kein Kauf (über der
  Sperre, und kein Rückgang um 22,1 bzw. 14,0 % binnen 48 h). Alle vier Käufe stammen aus der Rückrechnung beim Einspielen (20.10. 15:28).
- **Alt gegen neu:** mit fest 7 % (23.72/23.73) 27 Käufe und 135.000 USD -- ZEC 16, HYPE 6, ETH 3, XMR 1, BTC 1; mit dem Faktor 4 Käufe
  und 14.416 USD. Korrekturkäufe ZEC 16 → 0, HYPE 5 → 0, ETH 2 → 1, XMR 1 → 0, BTC 0 → 0. Vorab erwartet (`KONZEPT_Akkumulation.md`
  7e): BTC unverändert, ZEC deutlich weniger, HYPE weniger, ETH etwas weniger -- so eingetreten. Die alten Bilanzen stehen je in einer
  Zeile „(alte Regeln)“; die mit 27 Käufen steht inzwischen bei 141.616 USD (+4,90 %), überwiegend ZEC.
- Rückblick seit 2020 (08:46, ein Tag mehr als am 20.10., weiter 5.000 USD je Kauf): Q unverändert (kein neuer Kauf); p gegen die
  Surrogate BTC 0,363, ETH 0,443, ZEC 0,030 (belegt, am 20.10. 0,020), XMR 0,065. Das p schwankt, weil ein Tag mehr Kerzen die
  Ziehungen der festen Saat verschiebt; bei 200 Surrogaten ist sein Fehler um 0,03 rund ±0,012.

**Zählung der Regel (c) am S&P-500-Perp (U179)**, vorab festgelegt (`KONZEPT_Ausblick.md` 13.18 Punkt 3), 3.355 Prüfzeitpunkte vom
12.08. bis 21.10.:

| Fensterart | Zeitpunkte | Q (90 %) | über der Schwelle (95 %) | Auslösungen (24-h-Sperre) |
|---|---|---|---|---|
| Sonntagsstart | 120 | 1,35 (0,49–2,13) | 0 = 0 % (0–3,10 %) | 0 |
| Wochenende | 880 | 0,12 (0,08–0,18) | 0 (0–0,43 %) | 0 |
| Handelszeit | 681 | 1,13 (0,79–1,54) | 15 = 2,20 % (1,34–3,60 %) | 2 |
| außerhalb | 1.674 | 0,46 (0,39–0,53) | 2 = 0,12 % (0,03–0,43 %) | 2 |

- Bauart „3 σ“: 0,27 % bei Normalverteilung. Wilson-Intervalle nachgerechnet, gleich.
- **Lesart (beschreibend):** Am Wochenende bewegt sich der Perp mit rund einem Achtel der angenommenen Varianz -- dort kann die Regel
  praktisch nicht auslösen; außerhalb der Handelszeit mit rund der Hälfte. In der Handelszeit stimmt die Varianz ungefähr (Q 1,13),
  aber die Schwelle wird achtmal so oft überschritten wie bei Normalverteilung: dicke Ränder. Die Hypothese aus 13.18 („in der
  Handelszeit zu häufig, nachts fast nie“) passt; dass Q in der Handelszeit kaum über 1 liegt, hatte ich nicht erwartet.
- Auslösungen der Zählung: 03.09. 16:00 UTC (außerhalb, +1,10 % gegen ±1,01 %), 21.09. 18:30 (Handelszeit), 14.10. 16:00 (außerhalb),
  16.10. 18:00 (Handelszeit). Live seit 23.66: 14.10. 16:21, 16.10. 18:31 und 19.10. 02:39 UTC (Sonntagsstart). Den Sonntagsstart vom
  19.10. sieht die Zählung im 30-min-Raster nicht: Die Live-Prüfung alle 5 min fängt kurze Spitzen über der Schwelle, die zum Ende der
  Kerze wieder darunter liegen (vorab als Näherung benannt).
- Für die Entscheidung: Die vorab genannte Form 3·√(Q_Art·F_S·6/24) machte die Regel am Wochenende und nachts empfindlicher (Schwelle
  mal √0,12 = 0,35 bzw. √0,46 = 0,68) und änderte in der Handelszeit fast nichts (mal 1,06) -- die zu häufigen Überschreitungen dort
  kommen aus den dicken Rändern, nicht aus der Varianz. Wie oft sie ausgelöst hätte, zeigt die Zählung bisher nicht.
- **Entschieden 21.10. (Nutzer, Auswahl „Q-Schwelle direkt live“; mein Vorschlag war zuerst eine Probezählung):** Schwelle je
  Fensterart 3·√(Q_Art·F_S·6/24) mit Q fest aus dieser Zählung (1,35 / 0,12 / 1,13 / 0,46), sonst wie bisher (5 min, 24-h-Sperre,
  PAXG ausgenommen, nur Hinweis); Text mit Fensterart und Schwelle; die Zählung zeigt danach beide Schwellen und die Zeit nach dem 21.10.
  getrennt. Proben, Mutationen und Erwartung festgelegt in `KONZEPT_Ausblick.md` 13.20; Bau mit dem nächsten Paket nach dem 25.10.

**Vollbericht (U168) -- Nachprüfung bestanden:** 354,3 s (Soll unter 600 s; Erwartung vorab 4–5 min), alle 53 Tabellen genau einmal
gezählt in 333,8 s, nichts „nicht gezählt“; am 14.10. Abbruch nach 900 s.
- Hochrechnung: Die Datenbank wächst um rund 0,36 GB je Tag (07.10. 13,64 GB, 21.10. 18,69 GB); die Zählung kostet im Mittel rund 18 s
  je GB, nach den alten Läufen rund 24 s je zusätzlichem GB. Das Zählbudget von 480 s reicht damit bis etwa 7. bis 13.11. Danach steht die Heatmap als
  „nicht gezählt (Zeitbudget)“ da (so gebaut, der Rest bleibt vollständig), ab 600 s Laufzeit mit dem Kopfzusatz „nahe der Zeitgrenze“.
- Der Abbruch über `sqlite3_interrupt` ist auf dem Pi (SQLite 3.40.1) damit noch nie gelaufen; das zeigt erst der erste Lauf über dem
  Budget.

**Kriterium 5 der Fusion (U162), erster echter Wert** (live gestellte 4-h-Blöcke, Verhältnis Σ|r| ÷ ΣE|r|, Soll 1):
- Alle Coins 1,03 ± 0,08 (640 Blöcke in 107 Zeitblöcken), innerhalb 2 SE von 1. Je Coin BTC 0,98 ± 0,10, ETH 1,10 ± 0,13, HYPE
  1,00 ± 0,09, XMR 1,07 ± 0,10, ZEC 1,04 ± 0,10, **PAXG 0,81 ± 0,09**.
- PAXG ist ein Grenzfall: Mit den gerundeten Zahlen läge 1 − 2 SE bei 0,82, also über 0,81; ungerundet steht es knapp „innerhalb 2 SE“,
  und so urteilt der Code. **Eigene Schwäche der Anzeige:** Zwei Nachkommastellen reichen im Grenzfall nicht -- neu U190 (P3, nur
  Bericht): den Abstand in Standardfehlern dazuschreiben.
- Anteil |r| > E|r| je Coin 27–40 %, alle 34 % (Normalverteilung 42 %): dicke Ränder, beschreibend.
- Lesart: E|r 4 h| aus 30 Tagen trifft die Größe der 4-h-Bewegung im Mittel; bei PAXG war sie eher zu groß. Das Kriterium entscheidet
  nicht über das Umschalten (Vorarbeit für U109).

**Fusion und v3 (U108), Zwischenstand vor dem Urteil am 25.10.:**
- 4 h, nur live gestellt, alle Coins: 479 Blöcke in 107 Zeitblöcken (14.10.: 287 in 65).
  - Kriterium 1, Fusion minus Basisrate: −0,0015 ± 0,0016 je Block (0,9 SE; 14.10. 1,4 SE).
  - Kriterium 2: gegen v1 +0,0044 ± 0,0036 (1,2 SE schlechter; 14.10. +0,0084 ± 0,0051), gegen v2 −0,0033 ± 0,0021 (14.10. ✓, jetzt
    1,6 SE), gegen v3 −0,0001 ± 0,0016, gegen Analog −0,0178 ± 0,0099; kein ✗.
  - Hochgerechnet auf rund 131 Zeitblöcke am 25.10. (Standardfehler mal √(107/131), gleiche Mittel): Kriterium 1 rund −1,0 SE (nicht
    erfüllt), gegen v1 rund +1,35 SE (kein ✗). Die Erwartung aus `KONZEPT_Fusion.md` 6.1 (✗ gegen v1) tritt damit wohl nicht ein; im
    Schatten bleibt die Fusion trotzdem, weil Kriterium 1 fehlt.
- **v3: das Tor ist wieder zu.** 4 h λ_β 10, c = 0 (bestes c 1,0), OOF-Brier-Skill 0,0 (n 999); 24 h ebenso (n 195). Am 14.10. war es
  offen (c = 1, Skill 0,0108). Kriterium 3 („OOF-Skill > 0 in den Wochenläufen“) ist am 21.10. damit nicht erfüllt. v3 ist nicht
  geändert; das Tor folgt seiner festen Regel (kleinstes c innerhalb eines Standardfehlers vom besten).
- Kriterium 4: unverändert seit 14.10. („Fusion mit Kostenschwelle“ 16 Trades, „Prognose Fusion“ 50). „Prognose Fusion“ steigt erst
  ab 58 % bzw. unter 42 % ein, „Fusion mit Kostenschwelle“ erst bei einem Vorsprung über dem 1,5-Fachen der Kosten; die Fusion stand
  zuletzt (21.10. 18:11, 4 h) bei 49–55 %.
- 24 h (beschreibend): alle Blöcke gegen die Basisrate −0,0209 ± 0,0060 ✓, gegen v1 +0,0182 ± 0,0068 ✗; nur live gegen v1
  +0,0195 ± 0,0072 ✗.
- Kalibrierung v2: c = 0 überall außer PAXG 4 h (c 0,5, OOF-Skill 0,0447); XMR 4 h (14.10. c 1,0) steht jetzt auf c = 0.

**Kaskaden-Gleichung (U115) und Magnet-Test (U110), Zwischenstand:**
- **Kaskaden** (Kalibrierung 21.10. 15:55, 43,5 Tage Heatmap): nichts belegt; vorhergesagt gegen eingetreten 22 von 22 innerhalb 2 SE.
  - BTC 1 h jetzt zwei von vier Bedingungen (Y 0,25; gegen Y = 0 +0,0105 ± 0,0057, 1,8 SE; Spiegel +0,0066 ± 0,0049, nicht).
  - ZEC 1 h drei von vier (Y 0,25; gegen Y = 0 +0,0039 ± 0,0021, 1,9 SE; Placebo Y 0; Spiegel +0,0076 ± 0,0024, 3,2 SE).
  - Richtung über alle Coins 45 % ± 3 % (z −1,8), ETH 38 % (z −2,0).
  - Klassentabelle: bei XMR (1 h und 4 h), HYPE (1 h und 4 h), ZEC 4 h und ETH 1 h dasselbe Muster wie am 14.10. bei XMR -- in der
    unteren Klasse mehr, in der oberen weniger Ereignisse als vorhergesagt (z. B. XMR 4 h ≥ 2 σ: 3,8 → 8,6 %, n 210; 6,6 → 3,5 %, n 312).
    Aufgabe für U109.
- **Magnet** (Rechnung 21.10. 16:11, 43,6 Tage): nichts belegt; Nullmodell an Zufallsniveaus 87 von 88 innerhalb 2 SE.
  - BTC 1 h groß: +5,4 ± 3,3 Punkte (Spiegel +7,5 ± 3,9, Placebo +7,6 ± 3,9) mit 76 wirksamen Fällen -- urteilsfähig, aber unter 2 SE
    (14.10.: +7,7 ± 4,0 bei 58).
  - ETH 1 h groß: +5,5 ± 2,8 (Spiegel 2,4 SE, Placebo 1,4 SE). HYPE 1 h mittel: +8,0 ± 3,5 bei 50 wirksamen Fällen (unter 60).

**TradeLabor (U99) und Grid (U101):**
- 9.652 Trades, netto −154.826 USD (in sieben Tagen −33.991), Gebühren 64.200 USD (41 %). 0 bewährt, 10 negativ (14.10.: 8).
- Zufall (Kontrolle) −0,331 % je Trade (t −3,0). Familie Orderfluss −42.690 USD (28 % des Verlusts, Treffer 25 %).
- Grid nach 21 Tagen: Long −2.681 USD (t −3,1 auf Tagen), Short −3.255 USD (t −4,3).
- Swing und Zyklus mit 10.000 USD (U164): noch kein geschlossener Trade, 5 offen.

**Übrige Berichte (beschreibend, nichts Neues belegt):**
- **Abdeckung der Heatmap (U159):** Tagesmittel 23–29 % bei BTC, ETH, HYPE und ZEC, stabil seit dem 05.10.; XMR am 21.10. 18 %, weil das OI an
  einem Tag von 127 auf 152 Tsd. XMR stieg, bei etwa gleicher verfolgter Größe. Neustarts am 20.10. um 01:31, 07:32 und 15:27, alle
  drei beim Einspielen von Paketen (Journal `hl-update-…`). Das Alter der Abfragen steigt langsam (Median 21.110 s am 01.10., 26.938 s
  am 21.10.); Anteil des Pollers am API-Gewicht 58–61 %.
- **Makro:** 60 Reihen, FRED 21 von 21. **Zu alt: `bc:difficulty` und `bc:hashrate`.** Der Abruf bei Blockchain.com gelingt (21.10.
  09:52), bringt aber keine gültigen Tage nach dem 14.10. (vorher je ein Tag Verzug). Die Ursache liegt vermutlich bei der Quelle; von hier ist sie
  nicht prüfbar (Seite in der Sandbox gesperrt). Wirkung nur auf die Anzeige: Difficulty-Ribbon und Stromkosten rechnen mit der
  Difficulty vom 14.10. weiter, höchstens 20 Tage vorgetragen, also bis 03.11. (die Difficulty ändert sich ohnehin nur etwa alle zwei
  Wochen). Farside am 21.10. 13:39 UTC HTTP 521, Pause bis 17:39 UTC (ETF-Reihe bis 20.10.). Signale: 4 von 337 belegt, 11 live (alle
  Verkauf); Live gegen Nachrechnung 1.024 von 1.024 gleich. US-Preise September: Verbraucherpreise 3,74 % zum Vorjahr, ohne Lebensmittel
  und Energie 2,56 %, Erzeugerpreise 6,34 %; nächster Termin Erstanträge 22.10. 14:30.
- **CryptoQuant (U158):** 34 Tage, D 83,2–91,4 %, kein Tag ≥ 95 % → S5 weiter nicht prüfbar.
- **Konfluenz** seit 23.67/23.68: 24 Fälle, „Konfluenz“ n 8, nach 4 h 50 % richtig (Zufall 50 %).
- **Treiberfamilien:** keine aufgestiegen; in Bewährung PAXG Funding und Stärke, XMR Profi-Flow, ZEC Orderfluss. 1 von 55 Zellen mit
  |z| ≥ 2 (BTC Analog 24 h +2,6, n 36); ohne jede Kante wären rund 2,5 zu erwarten. **Anker:** nichts belegt (XMR mit 10-%-Clustern
  bei 4 und 8 h z −2,3 und −2,8, also gegen die Richtung; beschreibend). **Profile:** nichts über der Schwelle.
- **Empfehlungen (U8):** wie am 14.10.; XMR-Kauf Limit gegen Markt +0,38 % (+0,13 … +0,62), BTC-Kauf +0,06 % (+0,02 … +0,10).
- **Sperren:** dauerhaft 96 (14.10.: 92), vorläufig 35 (25), freigegeben 41 (37). Darwin-Liste 2 Mitglieder (14.10.: 4). Elite frisch
  3 Konten, keine Abweichung zwischen Datenbank und Live-Abfrage.
- **Vollbericht, sonst:** Fill-Rückstand der Pool-Konten wie bisher („Aufholen läuft“, 385 zurückgestellt); 74 Konten mit übersprungenen
  Zeiträumen (30.09.: 53). Im Journal des Dashboards ein `ConnectionResetError` vom 18.10. 18:58 -- ein Browser hat die Verbindung während
  einer Antwort getrennt; harmlos.
- **U177 (Strategy-Bestand):** kein SEC-Lauf in diesen 24 h, die Nachprüfung bleibt offen.

**Zusage bis 25.10. eingehalten:** nur gelesen und dokumentiert.

Lehre: **Ein Varianzverhältnis nahe 1 heißt noch nicht, dass eine 3-σ-Schwelle so selten auslöst wie geplant -- die Zählung der
Überschreitungen gehört immer daneben.**

## 3ηηηη. Auditbericht v3 (Kimi K3, 14.09.) erneut hochgeladen -- alle Korrekturen im Stand 23.74 noch da (22.10. 17:45; nur Dokumente, Version 2026-09-23.74 · bc6ebee746 unverändert, Opus 5.5)

**Hochgeladen 22.10. 17:42** als `auditbericht_v31.docx` mit „Audit des aktuellen Projektstandes“. Der Inhalt ist der Auditbericht v3 vom
14.09. (geprüft: `hl_liq_project(3).zip`, 21.271 Zeilen; heute 73.518 Zeilen in 61 Dateien) -- vermutlich ein zweiter Download von v3.
Umgesetzt am 14.09. (3r, 3s), bestätigt von Audit v4 am 15.09. (3t: „Fix-Quote v3 27/27“).

**Nachprüfung am Code von 23.74 (gleich dem Paket auf dem Pi):** D1 (`fehler`-Flag im Fill-Cursor), D2/D3 (Rollback bei jedem
`sqlite3.Error`), D4/D5 (Sperre nur bei 51001 bzw. 40004/40003), D6 (Bybit-Puffer außerhalb der Verbindung, Flush vor dem Neuverbinden) und
L1–L16 sind unverändert drin; S1–S8 ebenso (Tabellen laut Vollbericht 21.10. gefüllt: `lb_stats_hist` 588.017, `lb_pos_hourly` 366.188,
`lb_fills_daily` 13.621, `book_summary_1m` 295.224 Zeilen; Binance-Funding in `bnc_metrics`; 72/168 h in `score_forecasts`). Die Indikatoren
N1, N3, N6, N7, N8, N9 und die Varianz-Kompression laufen seit 14.09.; N2, N4, N5, N10–N14 waren nicht Teil der damaligen Entscheidung.

**Einziger offener Punkt L17 (Lint):** pyflakes ist jetzt über `/root/.local/bin/flake8 --select=F` verfügbar. Stand: 62 Meldungen, alle
kosmetisch -- 19 ungenutzte Importe, 28 ungenutzte lokale Variablen (z. B. `placebo_r/placebo_a` in `hl_profis.bewerte_konto`, Reste
eines früheren gepoolten Placebos), 13 f-Strings ohne Platzhalter, 1 Neudefinition (`RG` in `hl_ausblick.py`), 1 überflüssiger lokaler
`import hashlib` (`hl_recorder.py:1335`). Keine undefinierten Namen (F821) und keine anderen Fehlerklassen. Bleibt bei W6 (monatlich).

## 3θθθθ. Auditbericht v10 vom 22.10. geprüft; Paket 23.75: Abo-Grenze 10 auch ohne Befehlszeile (H-1), Aktionen nur per POST (M-5), Chart-Zeitraum je Kerzengröße (M-6), ein Sichtbarkeits-Listener (N-5), Messung der Fill-Nacharbeit (M-3) (U191–U205) (22.10. 18:20; Version 2026-09-23.75 · 28541d9ce0, Opus 5.5)

**Hochgeladen 22.10. 17:46** als `auditbericht_v10.md` („Das ist das richtige! Aber Lob bleibt!“), nachdem um 17:42 versehentlich der
alte Auditbericht v3 kam (3ηηηη). Gegenstand: der Stand mit 73.500 Zeilen (= 23.74). Nicht zu verwechseln mit
`REVIEW_Audit_v10_22-09-2026.md` (Audit v10 vom 22.09., K1 usw.) -- im Code und hier heißt der neue deshalb „Audit v10 vom 22.10.“.
Kernaussage des Berichts: kein kritischer Fehler, 2 HOCH, 6 MITTEL, rund 10 NIEDRIG; die neuen Analysemodule mathematisch sauber; offen
v1-Statistik, OOS-Wächter und `forecast_drivers` als Quelle der Kalibrierung; zwei Strategie-Lücken (§6).

**Geprüft am Code von 23.74 (17:47–17:50), Ergebnis an den Nutzer 17:50:**

| Befund | Prüfung | wann |
|---|---|---|
| H-1 `--max-event-subs` Standard 600 | **bestätigt, eigener Fehler aus K1 (22.09.):** Einstellung 10, der Standard der Befehlszeile (600) überschrieb sie; die systemd-Einheit gibt keinen Wert mit; README nannte „bis 600“. Auf dem Pi bisher ohne Wirkung: Die Darwin-Liste hat 2 Mitglieder (Bericht 21.10.), also 2 Abos; die 600 greifen nur bei leerer Liste (Rückfall „größte Positionen“, Konten ab 250k) oder mit mehr als 10 Mitgliedern | 23.75 (U191) |
| H-2 TRAIN_TAGE 90, `forecast` nach 60 Tagen gelöscht | bestätigt; wirkt ab etwa 10.11. (Prognosen seit 11.09.); fällt mit W4 zusammen: `forecast_slim` (Kurs) und `forecast_drivers` (Treiberwerte) werden nicht nach Alter gelöscht | nach dem 25.10., vor dem 10.11. (U196) |
| M-1 v1-Labels ohne Bar-Frische | bestätigt (`SELECT close FROM bars WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1` ohne Untergrenze) | nach dem 25.10., Zusage v1-Lernen (U197) |
| M-2 Vorlauf-Zuordnung in `hl_score` | bestätigt; wirkt nur bei Datenlücken mitten in der Reihe; speist Elite und damit v1 | nach dem 25.10. (U198) |
| M-3 drei 24-h-Abfragen in der Ereignisschleife | im Code bestätigt (Stundenaggregat, Masterregel, Vielhandler-Regel synchron nach jedem Fill-Lauf); Dauer auf dem Pi ungemessen. „`lower(addr)` verhindert den Index“ trifft nicht zu -- **aber meine Aussage „alle drei nutzen den Zeitindex“ war falsch** (siehe Korrektur unten) | 23.75 misst, Umbau danach (U195) |
| M-4 Neubewertung blockiert minutenlang | trifft auf dem Pi nicht mehr zu: einmalig, lief am 30.09., seitdem verhindert der Merker `sperre_kleinfill_neubewertung` den Lauf | nur bei frischer Datenbank, später (U203) |
| M-5 Aktionen per GET ohne CSRF-Schutz | bestätigt: Backup-Ziel setzen, Backup jetzt, alte Backups löschen (löscht die Dateien am alten Ort, nur nach geprüftem Backup am neuen), Konfluenz-Eintrag; `_post_erlaubt` galt nur für POST | 23.75 (U192) |
| M-6 `/chart` bis 3 Jahre | bestätigt; der Vorschlag 90 Tage hätte „1 Tag · 1 Jahr“ und „1 Woche · 5 Jahre“ abgeschnitten → Grenze je Kerzengröße. **Nebenbefund, eigener Fehler:** „1 Woche · 5 Jahre“ zeigte nur 3 Jahre (Kappung 3 · 525.600 min) | 23.75 (U193) |
| N-5 doppelter Listener | bestätigt: beim Sichtbarwerden lief `load()` zweimal (Browserprobe am Stand 23.74: zwei `/data`) | 23.75 (U194) |
| N-1, N-3, N-9, Lift-SE, OOS-Wächter, N-2 | betreffen die Statistik von v1/v2 bzw. die Doku der Priors | nach dem 25.10. (U199, U200, U201) |
| N-4, N-6, N-7 | Stellen gefunden (Verbindungen ohne `finally`; `REST_MAX = 200_000` im Adressfluss; Flush nur im Nachrichtenzweig bzw. `pop` vor dem Schreiben), klein, nur in Fehlerfällen | nach dem 25.10. (U202) |
| N-8 Pool-Treiber mit Prior 0 | keine Änderung: eine Anhebung bleibt eine Entscheidung (wie U7b) | -- |
| N-10 rund 170 `except: pass` | = W6 | W6 |
| §6 Strategie-Lücken | gut begründet; der Bericht rät selbst, die Urteile am 25.10. abzuwarten | als vorab festgelegte Studien nach dem 25.10. (U204, U205) |

**Wahl des Nutzers 17:51:** „23.75 jetzt, Rest nach 25.10. (Vorschlag)“ -- jetzt H-1, M-5, M-6 (mit 5 Jahren), N-5 und eine Messung
für M-3; nichts davon berührt ein Modell.

**Gebaut (23.75):**
- `hl_recorder.py`: `--max-event-subs` ohne Standard (None); `event_subs_aus`: ohne Angabe gilt die Einstellung 10, mit Angabe der Wert;
  die Befehlszeile steht in `parser_bauen` (prüfbar). M-3: die Nacharbeit nach dem Fill-Lauf (Stundenaggregat, Masterregel, Verdichten
  und Löschen, Vielhandler-Regel) als `fill_nacharbeit` -- Reihenfolge und Rechnung unverändert, jeder Schritt mit Dauer (zuletzt,
  höchstens seit dem Start, Zahl der Läufe; meta `fill_scans`); dazu meta `event_subs_info` (Zahl, Quelle, bestätigt, abgelehnt, Grenze).
  `--selbsttest-v10`.
- `check_report.py`: im Vollbericht, Abschnitt Recorder, die Zeilen „userEvents-Abos: n (Quelle) · bestätigt · abgelehnt · Grenze“
  (mit „<- ÜBER 10“, falls die Grenze über 10 steht) und „Fill-Nacharbeit in der Ereignisschleife (zuletzt / höchstens seit dem Start,
  ms)“; ohne Angaben je ein Hinweis (Recorder vor 23.75 bzw. noch kein Fill-Lauf).
- `hl_viz.py`: M-5 -- die vier Aktionen nur noch in `do_POST` (hinter `_post_erlaubt`: Kopfzeile X-HL-Request, Host-Liste, Origin), per
  GET Antwort 405 ohne Wirkung; die Seite sendet sie mit `postJSON` bzw. `fetch` POST mit Kopfzeile; `/speicher` (Lesen) bleibt GET.
  M-6 -- `chart_minuten`: unter 4-h-Kerzen (aus den 1-min-Bars) höchstens 90 Tage, ab 4 h (klines30, daily_bars) bis 5 Jahre. N-5 --
  ein Listener: beim Sichtbarwerden nach 200 ms Daten, Chart, Health, Netz, Prognose, System; im Schnappschuss nichts (vorher lud der
  erste Listener dort Health; `load()` tat dort ohnehin nichts). `--selbsttest-v10`.
- `install.py`: zwei Selbsttest-Schritte (63 statt 61); `version.py` 23.75; README (Abos, Fill-Nacharbeit, Sicherheit, Einspielen).

**Korrektur meiner Prüfung (17:50) beim Dokumentieren:** „Alle drei nutzen den Zeitindex“ stimmt nur für die Masterregel
(`ix_lb_fills_ts`); das Stundenaggregat sucht je Konto über den Primärschlüssel (addr, tid). Die **Vielhandler-Abfrage** (`… WHERE ts >= ?
AND notional >= ? GROUP BY addr …`) liest ohne Planer-Statistik -- das Projekt ruft nie `ANALYZE` -- **die ganze Tabelle** über den
Primärschlüssel und spart dafür das Sortieren für GROUP BY (EXPLAIN QUERY PLAN am Schema von 23.75). Synthetisch in der Sandbox mit 382.452
Zeilen (so viele hatte `lb_fills` am 21.10.) 0,43–0,50 s gegen 0,10 s mit erzwungenem Zeitindex -- beschreibend, eine Maschine, Daten
erfunden. Der Grund im Audit (`lower(addr)`) war falsch, sein Punkt (schwerer Scan) trifft für diese Abfrage zu. Die Messung in 23.75
zeigt die Dauer auf dem Pi; der Umbau (erster Kandidat: diese Abfrage) folgt danach (U195).

**Proben:** Recorder `--selbsttest-v10` 8 von 8 (ohne Angabe 10, mit Angabe 7; Rückfall bei leerer Darwin-Liste: 30 Positionen, die
größte gesperrt → die 10 größten ohne sie, 10-mal subscribe; Nacharbeit misst vier Schritte, der zweite Lauf zählt weiter, das
Stundenaggregat wird gerechnet; beide Meta-Schlüssel; der Fill-Lauf ruft die Nacharbeit). Dashboard `--selbsttest-v10` 9 von 9 (Grenzen je
Kerzengröße; echter Server in diesem Prozess: GET 405 ohne Aufruf, POST ohne Kopfzeile abgelehnt, mit Kopfzeile die vier Aufrufe in
Reihenfolge, `/speicher` per GET; die `/chart`-Route nimmt die Grenze; ein Listener; die Seite mit POST). `check_report.py --selbsttest`
18 von 18 (2 neu). **Browserprobe** (Chromium, echte Seite, alle Anfragen abgefangen) 5 von 5; dieselbe Probe am Stand 23.74: 0 von 5
(Aktionen per GET ohne Kopfzeile; Sichtbarwerden: `load()` zweimal, zwei `/data`). Mutationen der Seite 7 von 7 rot. **Mutationen Python
21 von 21 rot** (Recorder 9, Bericht 2, Dashboard 10). Eine blieb zuerst grün: „Meta ohne Messung“ -- die Probe suchte die Zeile in der
eigenen Quelldatei und fand sie in sich selbst; jetzt zählt sie (einmal in der Meta-Liste, einmal in der Probe), danach rot. Eigener
Fehler in der Probe, bemerkt nach dem Bau des Vorpakets.

**Prüfungen vor der Lieferung (A7):** `install.py --selftest-isoliert` im ausgepackten Vorpaket 23.75 · b36c3b9eba (Code gleich dem Paket
bis auf die berichtigte Probe in `hl_recorder.py`): **63 von 63 grün** (48 Schritte, PNG, 14
Dashboard-Abrufe), rc 0, 725 s (18:05:53–18:17:58 nach `date` und Dateizeit; daneben nur kurze Proben, die letzten Mutationen bis 18:06; 23.74: 1.642 s neben
Mutationsläufen); Ausblick 316,1 s, TradeLabor 79,5 s. Recorder-Selbsttest im ausgepackten Kandidaten des Endpakets (dieselben .py wie das
Paket): 8 von 8. Paket: 120 Einträge, 102 Dateien, Reihenfolge und Rechte wie 23.74, kein `__pycache__`, Stempel 2026-09-23.75 · 28541d9ce0, `py_compile` aller 61 Skripte ok; gegenüber dem A7-Vorpaket nur `hl_recorder.py`, nur in der Probe
„Meta für den Vollbericht“.
**Probe von update.py:** aus 23.74 28 von 28 (zwei Läufe: das update.py von 23.74 und danach das von 23.75; alle .py und die sechs seit 23.74 geänderten Dokumente gleich dem Paket, vorher anders; Version 23.75; `check_abdeckung.py` gesichert; Syntaxprüfung im Protokoll). `UEBERGABE_13-09-2026.md` steht nicht in der Liste von update.py (wie bisher) -- sie kommt nur mit dem Paket,
nicht auf den Pi.

**Erwartung auf dem Pi:** Abos wie bisher 2 (Darwin-Liste); bei leerer Liste höchstens 10 statt bis 600. Im Vollbericht (Abschnitt
Recorder) die Zeile zu den Abos und nach dem ersten Fill-Lauf die Dauer der vier Schritte. Backup-Knöpfe und Konfluenz wie bisher; **eine
offene Seite von 23.74 (z. B. auf dem Handy) einmal neu laden** -- bis dahin schickt sie die Aktionen per GET (Antwort 405, der
Konfluenz-Eintrag fällt still aus). „1 Woche · 5 Jahre“ zeigt 5 Jahre, soweit die Tageskerzen reichen.

**Zusage bis 25.10. eingehalten:** kein Modell, keine Statistik und kein Lernen geändert; Recorder nur Abo-Grenze und Messung.

Lehre: **Eine Prüfung, die eine Zeichenkette in der eigenen Datei sucht, findet sich selbst** -- und: **Ob eine Abfrage den Index nutzt,
sagt EXPLAIN QUERY PLAN, nicht die WHERE-Klausel.**

## 3ιιιι. Notbremse (U206, `KONZEPT_Notbremse.md` Fassung 1): Dienst hl-notbremse mit Ebene A, Terminen und Handbremse; Tor und Welt A im TradeLabor; Banner, Knopf, Abschnitt, Bericht; `check_notbremse.py` (Zerlegung, Rückblick, Rückwärtstest, Positivkontrollen) (23.10. 03:11; Version 2026-09-23.76 · ca72ef99cc, Opus 5.5)

**Auftrag 23.10. 01:05:** „Lies KONZEPT_Notbremse.md und setz U206 um“. Das Konzept liegt im Projekt (`claude/KONZEPT_Notbremse.md`, angelegt
23.10. 01:01, vom Nutzer bzw. einer anderen Sitzung), Fassung 1, vorab festgelegt vor jeder Auswertung des 22.10. Es liegt **unverändert**
im Paket (aus der Projekt-Ablage übernommen, Prüfsumme SHA-256 2e51c0e1…). Umfang U206 laut Abschnitt 13: Ebene A, Termine (B3),
Handbremse (C), Tor, Welt A, Banner, Abschnitt, Bericht, `check_notbremse.py` und alle Prüfungen aus Abschnitt 10 außer 12 und 13 (KI und
Polymarket = Ebene B, U207). **Auslegung der Zusage bis 25.10.** (dem Nutzer zu Beginn gesagt, Einspruch möglich): Welt B, das TradeLabor wie
bisher, bleibt byte-gleich; der Aktien-Korb wirkt nur in der neuen Welt A.

**Gebaut:**
- **`hl_notbremse.py`** (neu, eigener Dienst `hl-notbremse`, eigene Datei `notbremse.db` neben `hl_liq.db`):
  - Ebene A genau nach 4.1–4.6: Körbe täglich 00:00 UTC (K = BTC, ETH, HYPE, ZEC, XMR plus die größten Perps des Haupt-Dex nach OI · Kurs bis
    10, ohne PAXG und Spot-Kennungen „@…“; XMR über `perpDexs`/`meta` auf Dex `felix`; A = `xyz:SP500`, `xyz:XYZ100` und die Top 10; Anzeige PAXG,
    VIX, Öl/Gold soweit gelistet). Mids je Minute per REST `allMids` je Dex (Gewicht 2; drei Dexe = 6 je Minute; Rückfall
    `metaAndAssetCtxs`), ein Mid gilt 120 s. Zeitklassen Sitzung/außerhalb mit dem NYSE-Kalender (Frühschluss 13:00), σ je Instrument und
    Klasse aus den 30 Tagen vor dem letzten 00:00 UTC (nie der laufende Tag), Untergrenze 0,0625 · Median, Fenster-σ aus der Mischung der
    Minuten. z auf ±20, Median je Korb, X, Y, Λ (Long-Liquidationen der eigenen Coins, `side = 'A'`, Perzentil derselben Zeitklasse).
  - Zustandsmaschine (Stufen, Ende mit 120/240 min, Hysterese über X und G(K, 60), 30 min Λ < 0,90; Termine; Handbremse; Ruhefenster
    60 min nach „Sperre aufheben“; Spiegel nur gezählt); je Minute eine Zeile `nb_zustand`, Episoden `nb_episode` (auch Spiegel), Zustand
    der Maschine in `nb_meta` (Neustart setzt fort).
  - Historie beim ersten Start im Hintergrund: 15-min-Kerzen 60 Tage und 1-min-Kerzen 4 Tage über `candleSnapshot`, Budget im Mittel
    40 Gewicht je Minute, nach 429 zwei Minuten Pause; die eigenen Minutenkerzen des Recorders als 15-min-Schlüsse dazu. Danach die erste
    Kalibrierung (Daten bis 20.10. 23:59 UTC, σ ab 10 Tagen, X auf dem 15-min-Raster, Y mit Λ auf den eigenen 1-min-Kerzen, Budget
    4/1/1, Raster −1,50…−8,00, Klammern), monatlich am 1. um 00:30 UTC neu (60 Tage, `nb_preis` dazu). Ein Fehler der Kalibrierung hält
    den Takt nicht an (eine Stunde Pause, Meldung im Takt).
  - Das Tor `darf(con, t, seite, art)` und die Klasse `Tor` für das Labor (Zustand zur Zeit des Vorgangs, älter als 180 s = gesperrt,
    Shorts, Schließen und Verkleinern immer frei; gesperrte Vorgänge nach `nb_blockiert`, derselbe höchstens alle 15 min).
  - Welt A: `welt_a_anlegen` (alle `labor_*`-Tabellen als Kopie in `labor_a.db` neben `forecasts.db`), `welten_vergleich`, Tagesstand
    `nb_tag` (D = ΔA − ΔB je UTC-Tag), `episoden_auswerten` (D über Episode + 24 h, bei Stufe 2 die Varianten V1–V3 gegen V0).
  - Termine aus `notbremse_termine.json` (UTC; neu gelesen bei jeder Änderung; ungültige Einträge genannt). Handbremse `handbremse()`:
    Eintrag in `nb_manuell` und sofort eine Zustandszeile mit Quelle „manuell“ (Sekunden-Zeitstempel zwischen den Minutenzeilen), der
    Dienst übernimmt die Aktion mit seinem nächsten Takt.
  - Anzeige- und Berichtsdaten (`daten`, `banner_daten`, `banner_text`, `bericht_zeilen`), `--status`, `--selbsttest [--nur …]`.
- **`hl_labor.py`** (nur Welt A, `welt="A"` mit `tor`; Welt B ohne Tor wie bisher): das Tor in `_eroeffnen` (jede Position entsteht dort),
  vor jedem Long-Eintrag in `labor_order`, in der Füllprüfung offener Long-Limits (Zustand zur Zeit der Füllung, Ereignis „Notbremse:
  Füllung … verworfen“), im Grid (Kauf-Lose, Kauf-Limits, Startbestand, Aufbau und Nachführen nach unten) und in der Akkumulation (Käufe
  live; die Rückrechnung ab dem Start filtert in Welt A nach dem Tor -- Näherung). Beim Eintritt in Stufe ≥ 1 storniert Welt A offene
  Long-Limits erst nach den Füllungen bis jetzt (je Coin nach `_orders`, die Grid-Kauf-Limits nach den Grid-Kerzen). Status der Strategie
  „blockiert: Notbremse Stufe n“ bzw. „Notbremse veraltet“. Welt A rechnet mit dem Marktzustand der Welt B (`E_von`, kopiert, nie neu).
  Im Bericht „★ TradeLabor“ der Abschnitt „Notbremse“.
- **`hl_viz.py`:** Welt A im Labor-Takt -- entsteht nach einem erfolgreichen Takt der Welt B als Kopie und rechnet ab dem nächsten Takt mit;
  alle 10 min Tagesstand und Auswertung beendeter Episoden; aus mit `HL_NOTBREMSE=0`. Routen `/notbremse` (Abschnitt), `/notbremse/banner`
  (eine Abfrage), `/notbremse/handbremse` nur per POST mit X-HL-Request (GET 405). Seite: Banner im Kopf jeder Seite (Stufe 1 gelb, 2 rot,
  veraltet rot, mit „Sperre aufheben“ und „Einzelheiten“), Knopf „⛔ Notbremse“ mit Menü (1 h, 4 h, 24 h, bis auf Widerruf, Schock 4 h,
  Sperre aufheben, Grund), Abschnitt „NB Notbremse“ (Kacheln, G je Korb und Fenster, Episoden mit D und V1–V3, gesperrte Vorgänge, D je
  Tag, A − B je Strategie, Termine, Handbremse, Körbe, Historie, Kalibrierungen, Welt A, Hinweis auf Ebene B), im TradeLabor die Kachel
  „Notbremse“ (mit / ohne / Unterschied seit dem Start der Welt A) und in „Strategien“ die Spalte „Unterschied“; je ein Ton beim Wechsel auf
  Stufe 1 und auf Stufe 2 (Schalter „Töne“). Debug-Einträge: Zustand, Zerlegung des 22.10., Rückblick kurz (ohne Labor) und vollständig,
  zwei Selbsttests; die Dienstlisten kennen `hl-notbremse`. `--selbsttest-notbremse` (Probe 14, Teil HTTP).
- **`check_notbremse.py`** (neu): Standard = Zustand, Körbe, Historie, Takt, Kalibrierungen, Episoden, gesperrte Vorgänge, Audit der
  Zeitspalten. `--zerlegung TAG` (Schritt 0) und `--rueckblick` (10.4): Reihen wie die erste Kalibrierung (σ ab 10 Tagen), Schwellen der
  ersten Kalibrierung (die gespeicherte, sonst neu gerechnet) und je Budget 2/4/8, Stufen Minute für Minute mit der Zustandsmaschine des
  Dienstes (X vom 15-min-Raster), Episoden je Stufe und Auslöser, gesperrte Zeit, Empfindlichkeitstabelle, Zerlegung, Labor-Rückwärtstest,
  Positivkontrollen. Selbsttest.
- **Zerlegung:** Fenster 12:00 des Vortags bis 12:00 des Folgetags (UTC), Beitrag je Position = Wert(Ende) − Wert(Beginn) (realisiert +
  Bestand nach Ausstiegsgebühr und anteiligem Funding, dieselbe Rechnung wie `summe_zu`); Teile **disjunkt**: (e) alle Shorts, (a) Longs vor t0
  (auch Grid-Lose und Akku-Käufe), danach (d) Grid-Kauf-Lose, (c) Limit-Füllungen aus Orders vor t0 (über `labor_order.pos_id`), (b) der
  Rest mit Unterarten (Markt, Limit aus Order nach t0, Akkumulation, Limit ohne Order-Zeile). Prüfsumme: Summe der Teile gegen
  `summe_zu(Ende) − summe_zu(Beginn)`. t0 nach Abschnitt 1 (Fall 1/2/3, der Bericht nennt den Fall).
- **Labor-Rückwärtstest:** Welt B' (das Labor nachgebildet) und je Budget eine Welt A' (Kopie von B' nach dem letzten Takt vor der ersten
  Sperre, Tor mit der Stufenreihe des Budgets) im Takt 300 s, Zeitbudget 8 h. **Beide sehen je Takt nur Daten bis zu dessen Zeit:** eine
  Unterklasse des Labors liest `hl_liq.db` über temporäre Sichten mit `ts ≤ Takt` (Minutenkerzen nur abgeschlossene, `ts ≤ Takt − 60`)
  und den echten Prognosespeicher (nur lesend angehängt) ebenso. Grund: `liq_schwellen` (Kaskade) und `hl_anker.jetzt` lesen ohne
  Obergrenze -- live richtig, im Rückblick ein Blick nach vorn; die Kausalitätsprobe zeigt es (ohne Sichten wird die Kaskade wegen der
  späteren Liquidationen nicht erkannt). Nicht nachgebildet (Abdeckung im Bericht): Darwin und Elite (Listen nur als jüngster Stand),
  TWAP-Druck (Adressstrom ohne Zeitgrenze, 14 Tage). Ergebnis je Budget: D gesamt, im Fenster des Tages, je Episode + 24 h, je Strategie,
  gesperrte Vorgänge, Longs in Sperrminuten (A' und B'), dazu B' gegen das echte TradeLabor (Nachbildung, beschreibend) und die Laufzeit.
- **Positivkontrollen:** Monatsdateien der 1-min-Kerzen von data.binance.vision (Perps der Korb-Coins, `NAMEUSDT`; Kopfzeile, ms und µs),
  verdichtet zwischengespeichert in `notbremse_binance/`; je Ereignis (10.10.2025, 22.06.2025, 28.02.2026) vom Vortag bis Folgetag kleinstes
  Y und die erste Minute mit Y ≤ θ1 und ≤ θ2Y; ein Coin zählt nur, wenn seine Kurse 90 % der Minuten des Fensters decken.
- **Einbau:** `install.py` (Unit `hl-notbremse` mit Log `notbremse.log`; die Dashboard-Unit hat `Wants=hl-notbremse.service`, damit der
  Dienst auch nach einem Update mit älterer `update.py` startet, die ihn in ihrer Dienstliste nicht kennt; drei Selbsttest-Schritte,
  Syntax), `update.py` (Dienstliste, Projektdateien, `notbremse_termine.json` als Datei des Nutzers), `version.py` 23.76, `run_all.py`
  (startet die Notbremse mit, `--no-notbremse`), `hl_recorder.py` (Backup: `notbremse.db`, `labor_a.db` und `notbremse_termine.json`;
  Audit: Zeitspalten von `notbremse.db` in Sekunden), `check_report.py` (Dienst in Status und Journal), README.

**Abweichungen und Auslegungen (beim Bau, beschreibend):**
- **Proben 3 und 6 verschärft:** Die Mutationen „Median durch Mittelwert“ und „Hysterese aus“ (10.2) wären mit den Proben 3 und 6 im
  Wortlaut grün geblieben (ein einzelner Coin im Krypto-Korb verschiebt den Mittelwert nicht bis zu einer Schwelle; die 120-min-Regel
  verdeckt die Hysterese). Dazu Probe 3b (ein Aktienwert −40 %, der Krypto-Korb fällt breit um 4 σ(15) → Stufe 0) und in Probe 6 ein Fall,
  in dem X drei Stunden zwischen θ1 und θ1/2 bleibt (frei erst 30 min, nachdem X über θ1/2 steigt). Eigene Proben für zwei Mutationen aus
  10.2: „σ mit dem laufenden Tag“ (ein Schock am Tag D ändert das σ des Tages D in beiden Rechenwegen nicht) und „Freigabe über Y“ (ein
  5-min-Zucken von Y kurz vor der Freigabe hält sie nicht auf). Dazu eine Probe mit gespeicherten Antworten im Format der Doku (Korb,
  Dex von XMR, Mids je Dex, Historie mit Budget und 429; KONZEPT 4.2).
- **Mutationen 10.2, die Ebene B betreffen** (KI senkt Stufe, Antwort ohne Schemaprüfung) entfallen mit U207. **Gleichwertige Mutation:**
  „Bremse sperrt auch Shorts“ nur im Labor (`_tor` ohne Seitenprüfung) ändert nichts, weil `Tor.darf` Shorts selbst frei gibt (doppelte
  Sicherung); rot wird sie, sobald `Tor.darf` Shorts sperrt (allein oder mit dem Labor).
- „Am 22.10.“ in der Empfindlichkeitstabelle: die Auslösezeit am UTC-Tag 22.10., der Unterschied A − B im Fenster der Zerlegung (21.10.
  12:00 bis 23.10. 12:00 UTC); der Bericht sagt beides.
- Live prüft der Dienst X jede Minute; Kalibrierung und Rückblick X nur auf dem 15-min-Raster (wie 4.5; der Wert zur Zeit T gilt im
  Rückblick bis T + 15 min).
- Welt A entsteht nach einem Takt der Welt B und rechnet erst ab dem nächsten mit (sonst rechnete sie den Takt der Kopie zweimal); die
  Proben 8, 10 und 11 nach demselben Muster.
- Die Hauptzahl im Reiter TradeLabor bleibt Welt B (14.6); ein Umschalter ist nicht gebaut.
- Die vorgeschlagene eiserne Regel heißt in der PROJEKTUEBERGABE **Regel 12** (11 ist „Dokumente in derselben Antwort“).
- Beim Durchsehen berichtigt: Die 15-min-Schlüsse aus `nb_preis` liefen über die Zeitspalte ohne Index (ganze Tabelle, auf dem Pi rund
  2 Mio. Zeilen) -- jetzt je Instrument über den Schlüssel (inst, ts), höchstens ein Tag nachgeholt.

**Proben (Sandbox, synthetisch, ohne Netz):**
- `hl_notbremse.py --selbsttest` **27 von 27** (119 s, 02:58:00–02:59:59): die Proben 1–11 und 14–17 aus 10.1, dazu 3b, σ ohne den
  laufenden Tag, Freigabe nicht über Y, gespeicherte API-Antworten und Historie, die statische Prüfung des Tors (10.3) und die Termine.
  Zahlen: Probe 1 Stufe 1 nach 6 min (X −3,03), Stufe 2 nach 10 min (X −4,46; Soll höchstens 16 min); Probe 2 höchstens Stufe 1 (kleinstes
  X −3,04); Probe 4 mit niedrigem Λ Stufe 0 (Y −6,63), mit Λ bis 100 % Stufe 2; Probe 10 Welt B byte-gleich mit einem Lauf ohne Bremse
  (Abzug 396.918 Zeichen); Probe 11 Welt A 0 Longs, Welt B 5; Probe 8 im Grid Welt A 0 Kauf-Lose (B 9), 5 Kauf-Limits storniert; Probe 15
  über 20 Läufe im Mittel 4,88 Episoden je 30 Prüftage (Spanne 3–8; Soll im Mittel 3–6), θ1 im Mittel −3,37 (−3,50 bis −2,85); Probe 17
  Anteil G(A, 15) ≤ θ1 in der Sitzung 0,64 %, außerhalb 0,81 % (Faktor 0,80; ohne Zeitklassen 25,4); die Historie braucht 49 Abfragen in
  144 min (Gewicht im Mittel 35,4 je Minute, nach einem 429 zwei Minuten Pause).
- `check_notbremse.py --selbsttest` **7 von 7** (56 s): Zerlegung gegen die Rechnung von Hand (jede Position in ihrem Teil, Summe der
  Teile = Netto auf zweitem Weg), t0 in den drei Fällen, Rückblick erkennt einen Gleichlauf-Schock (15 min danach) und rechnet mit
  denselben Reihen und Schwellen wie die Kalibrierung des Dienstes, Positivkontrolle mit gespeicherten Monatsdateien (Kopfzeile, ms und
  µs, Zwischenspeicher, fehlender Coin), Kausalität des Rückwärtstests (863 Takte: bis zur Schnittzeit gleich, ob spätere Daten mit Ködern
  da sind oder nicht; ohne die Sichten rot), Welt A' entsteht vor der Sperre und eröffnet darin keine Longs (B' 7), ohne Sperre A' = B'.
- `hl_viz.py --selbsttest-notbremse` **4 von 4** (Probe 14 über HTTP: GET 405 ohne Wirkung, POST mit Kopfzeile sofort Stufe 1, Tor sperrt
  Longs und lässt Shorts durch, der Dienst übernimmt, „aufheben“ gibt frei, danach Ruhefenster; Abschnitt als JSON; Seite). Recorder
  `--selbsttest-backup` (B7: `notbremse.db`, `labor_a.db`, `notbremse_termine.json`), `--selbsttest-audit`, `--selbsttest-v10` und
  `check_report.py --selbsttest` bestanden. `hl_labor.py --selbsttest` (Welt B wie bisher) **99 von 99**.
- **Browserprobe** (Playwright, 390 und 1280 px, Testdaten, 02:35:55–02:37:16): **18 von 18** -- Banner Stufe 2 rot mit „Sperre aufheben“,
  Menü mit sechs Aktionen ganz im Bild, „1 h“ per POST mit Kopfzeile und Grund, Abschnitt, Kachel und Spalte im TradeLabor, der Ton genau
  einmal, bei Stufe 0 kein Banner, keine Seitenbreite über dem Bildschirm, keine JS-Fehler (außer den gewollten 503 der Testumgebung).
  Vier Mutationen der Seite (Banner weg, Menü zu breit, Aufruf per GET, Ton nie) alle rot. Beim Bau gefunden und berichtigt: Tabellen und
  Menü machten die Seite am Handy breiter als den Bildschirm; das Banner stand doppelt.
- **Mutationen** (je eine Ersetzung in einer Kopie des Projekts, die zugehörige Probe muss rot werden), 28 Stück: alle aus 10.2 außer den
  beiden der Ebene B -- Tor in `_eroeffnen` entfernt bzw. gelöscht (Probe 8, statische Prüfung), Tor in der Füllprüfung entfernt (9),
  Median durch Mittelwert (3b), σ mit dem laufenden Tag (σ-Probe, beide Rechenwege), Hysterese aus (6), Mindestdauer Stufe 2 bzw. 1 aus
  (7), Bremse sperrt Schließen (8), Bremse sperrt Shorts (drei Formen), Zustand zum aktuellen Zeitpunkt (9), veraltete Werte gültig (5),
  Welt B berührt (10), veralteter Zustand gibt frei (11), Millisekunden (16), σ ohne Zeitklassen (17 und σ-Probe), Fenster mit der Klasse
  der Endminute (17), Freigabe über Y (eigene Probe); dazu eigene: Rückwärtstest ohne Zeitgrenze der Sichten, Zerlegung (c) nach der Zeit
  der Position statt der Order, Zerlegung ohne den Bestand zu Beginn, Handbremse per GET wirksam, Handbremse ohne sofortige Zustandszeile,
  Positivkontrolle liest µs wie ms. Schlusslauf am Endstand (03:00:10–03:09:50): **27 von 28 rot, eine gleichwertig (Doppelsicherung)**.
  Im ersten Lauf (02:27:45–02:33:39) blieb außerdem „µs wie ms“ grün: Der Coin mit der falsch gelesenen Datei fiel still heraus, die
  übrigen fanden den Einbruch trotzdem -- seither zählt ein Coin nur, wenn seine Kurse 90 % der Minuten des Fensters decken, sonst steht
  er unter „fehlt“ (berichtigt 02:34, danach rot).
- **A7** (`install.py --selftest-isoliert` auf dem Vorpaket mit derselben Prüfsumme): **66 von 66 grün** (02:40:44–03:05:08, 1.464 s, zum
  Teil parallel zu anderen Läufen; darin Notbremse 188,8 s, Werkzeug 46,8 s, Dashboard Notbremse 1,1 s, TradeLabor 132,5 s).
- **Probe von update.py** (altes Paket ausgepackt, zwei echte Läufe ohne Netz und ohne systemd, danach `install.py --units-only`): aus
  23.74 **28 von 28**, aus 23.75 **28 von 28** -- das alte `update.py` übernimmt `hl_notbremse.py`, `check_notbremse.py` und
  `notbremse_termine.json` als „weitere Dateien“, `KONZEPT_Notbremse.md` erst das neue; eine vom Nutzer geänderte `notbremse_termine.json`
  bleibt stehen; Units: `hl-notbremse.service` mit `--db`, die Dashboard-Unit mit `Wants=hl-notbremse.service`. Das alte `update.py`
  erzeugt die Units mit dem neuen `install.py`, aktiviert neue Units und startet die Dashboard-Unit -- über `Wants=` startet systemd die
  Notbremse mit (am `update.py` von 23.74 und 23.75 nachgelesen, beide gleich; ohne systemd in der Sandbox nicht ausgeführt).

**Nach dem Einspielen auf dem Pi:** Banner und Abschnitt ansehen (bis die Historie da ist, „Kalibrierung läuft“; die erste Kalibrierung
folgt nach rund zweieinhalb Stunden Historie); Debug „★ Notbremse: Zerlegung des 22.10.“; abends `check_notbremse.py --rueckblick` per
SSH im Hintergrund (README); beide Ausgaben als Sammeldatei an die nächste Sitzung (U210). Offene Seiten anderer Geräte einmal neu laden.
Zeigt der Abschnitt „notbremse.db fehlt“ oder das Banner rot „ohne aktuelle Daten“, läuft der Dienst nicht: `sudo systemctl status
hl-notbremse` (der Start über `Wants=` ist am Code nachgelesen, in der Sandbox ohne systemd nicht ausgeführt); Welt A eröffnet dann
keine Longs, Welt B läuft unverändert.

**Grenzen:** Ebene B fehlt (U207). Die Laufzeit des Rückwärtstests auf dem Pi ist unbekannt (Zeitbudget 8 h, Fortschritt alle 10 %); seine
Abdeckung hängt an den gespeicherten Daten (Prognosen hält der Speicher 60 Tage; der Bericht nennt je Quelle den ersten Zeitpunkt). Ob
data.binance.vision vom Pi erreichbar ist, ist ungeprüft. Die xyz-Werte sind erst seit Mai 2026 gelistet; `candleSnapshot` reicht rund 52
Tage zurück -- jeder Tag Verzug kostet einen Tag Kalibrierung. Welt A verdoppelt den Speicher der Labor-Tabellen.

Lehre: **Was live richtig liest, kann im Rückblick nach vorn sehen** -- Abfragen ohne Obergrenze der Zeit (`hl_anker.jetzt`,
`liq_schwellen`) sind im Dienst korrekt und im Rückwärtstest ein Blick in die Zukunft; erst eine Probe mit Ködern zeigt es. Und: **Eine
Probe im Wortlaut des Konzepts trennt nicht immer** (Median, Hysterese) -- ob sie trennt, sagt erst die Mutation.

## 3κκκκ. Weboberfläche nicht erreichbar (23.10.); Zerlegung des 22.10. (Schritt 0); Paket 23.77: Rückblick im Hintergrund aus der Debug-Konsole, Speicherwächter, Rate bei der wirksamen Schwelle, Systemdiagnose ohne SSH (U210–U214) (23.10. 15:56; Version 2026-09-23.77 · b446905d86, Opus 5.5)

**Meldung 23.10. 14:13:** „Zum ersten Mal ist die Weboberfläche nicht erreichbar. Ping funktioniert, aber der Port 8765 ist nicht
erreichbar. Habe keinen Monitor dran. Was tun“. Antwort 14:19 (Zeitstempel des Sitzungsverlaufs): erst per SSH nachsehen (Block, der nur
liest), dann nur `hl-dashboard` neu starten; ohne SSH der Ein-/Aus-Taster des Pi 5 (mit Desktop zweimal kurz = sauber herunterfahren;
Quelle: raspberrypi/documentation, PR 3397). **Antwort des Nutzers 14:35:** „Neustart hat funktioniert“; SSH geht nicht („connection
refused“ -- auf dem Pi aus); die Zerlegung als Datei; „mach am besten debug befehl zum ausführen“ für den Rückblick statt SSH.

**Ursache des Ausfalls: offen.** Am Code von 23.76 nachgesehen (14:14–14:19): Vor dem Öffnen des Ports läuft nichts Neues (`hl_notbremse`
wird im Dashboard nur innerhalb von Funktionen geladen, `serve()` unverändert); die Dashboard-Unit hängt nur schwach an der Notbremse
(`Wants=`, keine Reihenfolge). Welt A entsteht im Labor-Thread; ihre Kopie (`welt_a_anlegen`) hält mit `BEGIN IMMEDIATE` auch die
angehängte `forecasts.db` bis zum Ende der Kopie -- Schreiber dort warten, der Port nicht. Möglich, aber nicht belegt: Speichernot (Welt A
rechnet im Dashboard-Prozess mit), ein Hänger, Platte/USB, Strom. Der Neustart über den Taster löscht die Spur im Journal, wenn journald
nicht dauerhaft speichert. Dafür jetzt der Debug-Eintrag „★ System: letzter Neustart und Ausfälle“ (U212).

**Zerlegung des 22.10.** (Debug-Lauf auf dem Pi 23.10. 14:33 Ortszeit, 8,5 s; beschreibend, ein Tag):
- Daten: Korb K 10 (BTC, ETH, HYPE, ZEC, XMR, SOL, NEAR, XRP, PUMP, LIT), A 12; Historie fertig; Zeitraum 11.09.–23.10.: X an 41,5 Tagen
  gültig, Y (5 eigene Coins) an 42,5 Tagen.
- Erste Kalibrierung (Daten bis 20.10. 23:59 UTC; X 39, Y 40 Tage), gleich der gespeicherten des Dienstes (ab 23.10. 09:42 UTC): Budget 4:
  θ1 −3,50 (an der Klammer), θ2X −4,95, θ2Y −8,00 (an der Klammer: **kein Wert bis −8,00 hält das Budget 1 je 30 Tage** -- der Pfad
  „Krypto allein“ mit Λ ≥ 0,99 löste in der Kalibrierung öfter aus). Budget 2 wegen der Klammer gleich Budget 4; Budget 8: θ1 −2,85.
- **t0 = 22.10. 02:30 UTC, Fall 2: Mit den vorab kalibrierten Schwellen (Budget 4) löst die Bremse am 22.10. nicht aus;** die erste Minute
  mit Stufe ≥ 1 gibt es erst bei Budget 8 (so in `KONZEPT_Notbremse.md` 11.5 als offen erwartet).
- Netto der Welt B im Fenster 21.10. 12:00 bis 23.10. 12:00 UTC: **−34.760 USD** (über alle Strategien einschließlich der Kontrollen); (a)
  Longs vor t0 −19.837 USD (271), (b) Long-Einstiege nach t0 −12.722 USD (182; Markt −11.727/177, Limit aus Order nach t0 −995/5), (c) 0,
  (d) Grid-Kauf-Lose +90 USD (153), (e) Shorts −2.291 USD (451). Summe der Teile gleich dem zweiten Rechenweg (Abweichung 0,00).
- Näherung ohne Folgeeffekte: Hätte eine Sperre ab t0 alle Long-Einstiege bis zum Fensterende verhindert, +12.632 USD; eine echte Sperre
  endet früher -- die Zahl mit Folgeeffekten liefert der Rückwärtstest.
- Größte Verlierer in (a): die Akkumulation (akku und akku_ohne_cluster je ZEC −3.686, HYPE −1.581, ETH −729) -- vor t0 gekauft, die
  Bremse berührt den Bestand nicht (V0); in (b): familie_orderfluss XMR −1.148, familie_pool XMR −940, familie_pool ZEC −900.
- **Eigener Fehler der Anzeige:** „Episoden je 30 Tage in der Kalibrierung“ stand beim Rohwert vor der Klammer: Budget 2 „1,54“, wirksam
  waren bei θ1 = −3,50 aber 3,85 wie bei Budget 4; bei θ2Y stand nur „—“ ohne die Rate bei −8,00. Berichtigt in 23.77 (U213).

**Gebaut (23.77):**
- **`check_notbremse.py`:** `--rueckblick-start` startet den Rückblick (10.4) als eigene systemd-Einheit `hl-rueckblick-JJJJMMTT-hhmmss`
  über `sudo -S systemd-run` (Passwort aus `sudo.txt` nur über stdin, wie beim Update): `Nice=15`, `IOSchedulingClass=idle`,
  `CPUWeight=20`, `OOMScoreAdjust=900` (bei Speichernot beendet der Kernel zuerst ihn), `RuntimeMaxSec` = Zeitbudget + 2 h, Ausgabe nach
  `updates/rueckblick_notbremse.laeuft.txt`, am Ende als `berichte/JJJJ-MM-TT_hh-mm_notbremse_rueckblick.txt` (dann unter „Neue Berichte“
  und in der Sammeldatei). Kein zweiter Start, solange einer läuft. `--rueckblick-stand`: läuft (Speicher, Rechenzeit, letzte Zeilen),
  fertig (ganzer Bericht) oder ohne Ende (Protokoll mit Hinweis als `…_abgebrochen.txt`); `--rueckblick-stopp`: `systemctl stop`. Ohne
  `systemd-run` oder `sudo.txt`: eigener Prozess mit `nice -n 15` und OOM-Wert 900 -- er endet dann mit einem Neustart des Dashboards
  (gleiche Steuergruppe), das steht in der Ausgabe. **Speicherwächter** im Rückwärtstest: Abbruch mit Teilergebnis, wenn weniger als 400
  MB bzw. 10 % frei sind (MemAvailable je Takt); der Fortschritt nennt den freien Speicher. **Rate bei der wirksamen Schwelle** im Zustand
  und im Rückblick, mit Hinweis auf die Klammer bzw. „kein Wert bis −8,00 hält das Budget“.
- **`hl_notbremse.py`:** `kalibrieren` speichert dazu `theta_wirksam` und `je30_wirksam` je Pfad (nur Bericht; Schwellen und Regeln
  unverändert).
- **`check_system.py` (neu):** Systemdiagnose ohne SSH, liest nur -- Laufzeit und Dienste (Zustand, Neustarts, Speicher), Starts im
  Journal (dauerhaft oder nicht), **vor dem letzten Neustart**: Meldungen von systemd zum Dashboard (Absturz, Neustart), seine letzten 40
  Zeilen, Kernel-Zeilen je Art (Speicher, Platte/USB, Strom, Hänger, Temperatur), die letzten 25 Zeilen des vorigen Starts (sauber
  heruntergefahren oder abrupt); Wächter-Log (Meldungen ≠ ok der letzten 24 h, die letzten Prüfungen vor dem Neustart und die Zeit ohne
  Prüfung); Lücken im CPU-Verlauf des Dashboards (`sys_history.json`); Berichte und Debug-Läufe der letzten 24 h; Speicher, Last, Platten,
  `vcgencmd get_throttled` (entschlüsselt), Temperatur, Prozesse nach Speicher; Update- und Notbremse-Log; am Ende ein Befund. Liest das
  Journal ohne Rechte (Gruppe adm fehlt) einmal mit sudo.
- **`hl_viz.py`:** Debug-Einträge „★ Notbremse: Rückblick vollständig im Hintergrund STARTEN“, „★ … Stand und Ergebnis“, „… abbrechen“ und
  „★ System: letzter Neustart und Ausfälle“; der Eintrag „Notbremse: Rückblick vollständig“ (lief Stunden als Unterprozess der
  Debug-Konsole, blockierte sie, höchstens 200 kB, endete mit dem Dashboard) entfällt. Hinweistext im Abschnitt „NB Notbremse“. Der
  Systemverlauf (`sys_history.json`, je Minute) hält dazu den frei nutzbaren Arbeitsspeicher und den Speicher des Dashboards (RSS) in MB
  -- die Seite liest weiter nur Zeit, Temperatur und CPU; `check_system.py` zeigt das Minimum, das Maximum und die Werte vor einer Lücke.
  Damit ist beim nächsten Ausfall sichtbar, ob der Speicher knapp wurde.
- `install.py` (Syntax, Selbsttest-Schritt „Systemdiagnose“), `update.py` (Projektdatei `check_system.py`), `version.py` 23.77
  (`check_system.py` in der Prüfsumme), README (Notbremse: Rückblick aus der Debug-Konsole; neuer Abschnitt „Weboberfläche nicht
  erreichbar“).

**Proben (Sandbox):**
- `check_notbremse.py --selbsttest` **13 von 13**: dazu neu der Start als systemd-Einheit (Befehl mit allen Eigenschaften, Passwort nur
  über stdin, nicht in den Argumenten), kein zweiter Start, solange einer läuft, Stand (läuft mit Speicher und Fortschritt / fertig mit
  Bericht unter berichte/ / ohne Ende als `…_abgebrochen.txt`), Rückfall ohne `sudo.txt` (eigener Prozess mit nice 15 und Hinweis),
  Abbrechen über `systemctl stop`; der Speicherwächter bricht den Rückwärtstest beim 100. Takt ab, wenn nur noch 300 MB von 4 GB frei
  sind, und liefert das Teilergebnis; die Rate bei der wirksamen Schwelle (Klammer, kein Wert hält das Budget, Kalibrierung von 23.76).
- `hl_notbremse.py --selbsttest` **28 von 28**: dazu „Rate bei der wirksamen Schwelle“ (30 Tage, 10 Dellen auf −3,60 und 3 auf −4,20: roh
  −3,65 mit 3 je 30 Tage, wirksam −3,50 mit 13; Y mit 5 Tiefs auf −9 bei Λ = 1: kein Wert hält das Budget, wirksam −8,00 mit 5).
- `check_system.py --selbsttest` **8 von 8** (Wächter-Log, Lücken im Verlauf mit Speicher, `get_throttled`, Liste der Starts mit und ohne
  Kopfzeile, Kernel-Zeilen je Art, sauber gegen abrupt, Journal ohne Rechte einmal mit sudo, Bericht Ende zu Ende auf erfundener
  Umgebung). Ohne systemd in der Sandbox läuft der Bericht durch und sagt „Journal: nicht lesbar“.
- `hl_viz.py --selbsttest-notbremse` **7 von 7** (dazu die Debug-Einträge und der Systemverlauf mit Speicher, alte Einträge mit drei
  Feldern bleiben lesbar).
- **Mutationen** (je eine Ersetzung in einer Kopie, die Probe muss rot werden): Passwort in den Argumenten, kein Schutz gegen einen
  zweiten Start, ohne OOM-Wert, Speicherwächter aus, Speicherwächter nur mit der MB-Grenze, wirksame Rate = Rohwert (Dienst), Bericht mit
  dem Rohwert, Protokoll am Ende nicht nach berichte/, Lauf ohne Ende nicht abgelegt, Journal ohne sudo-Rückfall, Lücke bis jetzt nicht
  gezählt, Strom-Bits falsch gelesen, sauber und abrupt vertauscht, Rückblick wieder direkt in der Debug-Konsole, Systemverlauf ohne
  Speicher, neue Verlaufseinträge beim Neustart verworfen: **16 von 16 rot**.
- **A7** (`install.py --selftest-isoliert` auf dem Vorpaket mit derselben Prüfsumme): **67 von 67 grün (1.587 s; ein erster Lauf parallel
  zu den Proben wurde nach 30 min vom Zeitlimit der Sitzung beendet, bis dahin 39 Schritte grün)**.
- **Probe von update.py** (altes Paket ausgepackt, zwei echte Läufe ohne Netz und ohne systemd, danach `install.py --units-only`): aus
  23.76 **27 von 27**, aus 23.75 **27 von 27** -- das alte `update.py` übernimmt `check_system.py` als „weitere Datei“, das neue führt sie
  in seiner Liste; eine vom Nutzer geänderte `notbremse_termine.json` bleibt stehen; Units wie in 23.76.

**Nach dem Einspielen auf dem Pi:** (1) Debug „★ System: letzter Neustart und Ausfälle“ -- die Ausgabe an die nächste Sitzung (U212). (2)
Abends „★ Notbremse: Rückblick vollständig im Hintergrund STARTEN“, zwischendurch „… Stand und Ergebnis“; der fertige Bericht liegt unter
„Neue Berichte“ (U210). Offene Seiten anderer Geräte einmal neu laden.

**Grenzen:** Den Start über `systemd-run` mit diesen Eigenschaften prüft die Sandbox nur am Befehl (kein systemd); lehnt der Pi ihn ab,
startet der Rückblick als Prozess des Dashboards und der Grund steht in der Ausgabe. Die Laufzeit auf dem Pi bleibt unbekannt. Das
Systemprotokoll vor dem Neustart gibt es nur bei dauerhaftem journald; ob es so ist, zeigt der Bericht („Journal dauerhaft: ja/nein“). SSH
bleibt aus (Entscheidung des Nutzers, U214). Kleinigkeit, bewusst nicht mehr geändert (A7 lief schon): Ohne gestarteten Lauf zählt „Stand
und Ergebnis“ unter „Frühere Ergebnisse“ auch die Debug-Dateien `…_notbremse_rueckblick_stand_manuell.txt` mit -- harmlos, nächstes Paket.

Lehre: **Was Stunden läuft, gehört nicht in die Debug-Konsole, sondern in eine eigene Einheit** -- und: **Eine Rate gehört zur wirksamen
Schwelle, nicht zum Rohwert vor der Klammer.**

## 3λλλλ. Ausfall vom 23.10. ausgewertet (das Dashboard hing knapp 5 h); Paket 23.78: Selbstheilung bei Hängern, Stapelabzüge, Lücken und Lebenszeichen im Systembericht, Systemprotokoll dauerhaft als Klick, Units bei der Wiederherstellung (U215–U218) (23.10. 18:46; Version 2026-09-23.78 · de01471ead, Opus 5.5)

**Systembericht des Nutzers** (Debug „★ System: letzter Neustart und Ausfälle“ auf 23.77, Pi-Zeit 23.10. 17:35:35, 1,1 s; hochgeladen
17:36 mit „Hier“). Befund, beschreibend:
- Der **Pi selbst lief durch**: Der Wächter prüfte in 24 h 289-mal (Takt 5 min, also praktisch ohne Lücke, auch während des Ausfalls); die
  drei Prüfungen vor dem Neustart (14:14:16, 14:19:18, 14:24:20) liegen je 5 min 2 s auseinander, also ohne Verzögerung, und melden nur
  die bekannten Punkte Abdeckung und Poller -- Kursdaten, Snapshots, Platte und Dienste waren dort in Ordnung.
- **Nur das Dashboard war betroffen:** Sein letzter gesicherter Messwert im Systemverlauf ist von 09:31:19, der nächste von 14:27:51 (Start
  des Pi 14:27:43 nach dem Taster). Gesichert wird alle 5 min, das Ende liegt also zwischen 09:31:19 und etwa 09:36. Davor nichts
  Auffälliges (09:22–09:31: CPU 24–46 %, 49–56 °C); den Speicher schrieb der Verlauf damals noch nicht mit (erst seit 23.77).
- 23.76 wurde um 09:17 eingespielt (Sicherung `vor_20261023_091704`), das Dashboard misst ab 09:17:17: Der Ausfall begann **14–19 min nach
  dem ersten Start von 23.76**.
- In allen rund 59 Prüfungen der Lücke führte systemd das Dashboard als „aktiv“. Ein Absturz mit ständigem Neustart ist damit sehr
  unwahrscheinlich: Ein Neustart wartet 20 s (`RestartSec`), und jeder Prozess hätte höchstens etwa 4 min gelebt (sonst stünden Messwerte
  im Verlauf) -- dann hätte der Wächter mit über 99 % Wahrscheinlichkeit mindestens einmal „activating“ gesehen (grobe Rechnung,
  gleichverteilte Lage der Prüfungen: (240/260)^59 ≈ 0,9 %). Am besten passt: **Der Prozess lebte, hing aber** -- vermutlich bis zum
  Neustart.
- **Ursache offen:** Das Journal ist nicht dauerhaft (`/var/log/journal` fehlt), die Meldungen von Dashboard und Kernel vor dem Neustart sind
  weg. Vermutung, nicht belegt: ein Ablauf, der nur beim allerersten Lauf von 23.76 geschah (einmalige Kopie des TradeLabors in die Welt
  A, erste Runde Tagesstand/Episoden, gleichzeitig das erste Laden der Notbremse-Historie im eigenen Dienst). Nach dem Neustart lief
  dieselbe Version 3 h ohne Hänger, da waren diese Abläufe erledigt -- ein Indiz, kein Beweis.
- Nebenbefund: Der Wächter steht seit Stunden auf KRITISCH, nur wegen Abdeckung (PAXG, XMR, ZEC unter 25 %) und Poller (90 % der
  Positionen bis zu ~1.127 min alt, kritisch ab 120 min) -- mit dem Ausfall hat das nichts zu tun, aber ein echter Ausfall fällt im
  dauernd roten Wächter nicht auf (U218).
- Jetzt: 6,1 von 7,9 GB frei, Auslagerung 0,11 von 2 GB, Dashboard 1.016 MB (5 min nach dem Start von 23.77), `throttled=0x0`, SD 58 %,
  USB-Platte 11 %; Notbremse kalibriert θ1 −3,50, θ2X −4,95, θ2Y −8,00.

Zwischenmeldung an den Nutzer zwischen 17:43:33 und 17:54:13 (gemessen mit `date` davor und danach): Befund wie oben, Bau von 23.78
angekündigt (Selbstheilung, Abzüge, Lebenszeichen, Wächter prüft den Port, Systemprotokoll dauerhaft nur als Klick, SSH bleibt aus);
Bitte: „★ Notbremse: Zustand“ (Zeile „Welt A seit …“: 09:18 = Kopie vor dem Hänger fertig, ~14:28 = nie fertig) und ob der Browser um
14:13 sofort „Verbindung abgelehnt“ zeigte oder lange lud.

**Gebaut (23.78):**
- **`hl_viz.py` -- Selbstheilung (U215):** Faden „lebenszeichen“ fragt jede Minute die eigene Seite `/lebt` ab (neu; ohne Datenbank, ohne
  Cache; Antwort „ok PID Laufzeit“). **Nur bei Antwort** meldet er systemd `WATCHDOG=1` (sd_notify ohne Zusatzpaket über `$NOTIFY_SOCKET`,
  auch abstrakt; nichts ohne systemd oder für einen fremden `WATCHDOG_PID` -- Kinder des Dashboards erben die Umgebung). `faulthandler`
  schreibt nach `logs/dashboard_haenger.log`: bei SIGSEGV/SIGFPE/SIGABRT/SIGBUS/SIGILL die Stapel **aller** Fäden, außerdem 5 min nach der
  letzten eigenen Antwort (`dump_traceback_later`, nach jeder Antwort neu gestellt; sein C-Wächter braucht das GIL nicht). Antwortet nur
  der Webserver nicht, das GIL ist frei: beim 2. und 10. Fehlversuch ein Abzug **mit Fadennamen** (Kennung „Thread 0x…“ wie bei
  faulthandler). Stockt ein Teil im Hintergrund ohne Hänger des Webservers (Systemverlauf über 10 min, TradeLabor über 15 min, Prognose
  über 60 min): je Stillstand ein Abzug „Teil-Hänger“, **kein** Neustart. Unter systemd (`HL_LOGDIR` gesetzt): Ausgabe mit Zeitstempel je
  Zeile (`dashboard.log` statt Journal; Schreibfehler werden geschluckt), `dashboard.log` beim Start auf 5 MB gekürzt, wenn über 20 MB
  (an Ort und Stelle -- systemd hält die Datei mit O_APPEND offen), die Hänger-Datei auf 1 MB, wenn über 2 MB. Setzt systemd einen
  kürzeren Wächter (`WATCHDOG_USEC`), fragt der Faden öfter (ein Viertel). Aus mit `HL_LEBENSZEICHEN=0`. Debug-Einträge „System:
  Systemprotokoll dauerhaft speichern -- EINSCHALTEN / AUSSCHALTEN“; Text von „★ System: letzter Neustart und Ausfälle“ ergänzt.
- **`install.py`:** Unit des Dashboards mit `WatchdogSec=900`, `NotifyAccess=main`, `LimitCORE=0` (kein Speicherabbild von 1 GB auf die
  SD-Karte), `Environment=HL_LOGDIR={logdir}`, `StandardOutput`/`StandardError=append:{logdir}/dashboard.log`; Rest unverändert
  (`Restart=always`, `RestartSec=20`, `Wants=hl-notbremse.service`). Der isolierte Selbsttest (Debug „Selbsttest“) entfernt `HL_LOGDIR`,
  `NOTIFY_SOCKET`, `WATCHDOG_PID`, `WATCHDOG_USEC` aus der geerbten Umgebung. Zwei neue Selbsttest-Schritte (Selbstheilung, Wächter).
- **`hl_watchdog.py`:** Prüfung „Dashboard“: führt systemd es als aktiv, muss `http://127.0.0.1:8765/lebt` antworten (jede HTTP-Antwort
  zählt, auch 404 eines älteren Stands); keine Antwort zweimal im Abstand von 5 s -> KRITISCH mit „hängt?“ (`--dashboard-url`,
  `--selbsttest` neu).
- **`check_system.py` (U216, U217):** neuer Abschnitt Hänger-Schutz (WatchdogUSec, Neustarts, letztes Ergebnis -- „watchdog“ heißt:
  Neustart durch den Wächter), die Abzüge der letzten 7 Tage (je Faden die neueste Stelle im Projekt, „← darin“ die neueste überhaupt) und
  die Zeilen „Lebenszeichen“ sowie das Ende von `dashboard.log`. **Lücken des Dashboards** über 7 Tage aus den Prognosen (alle 15 min je
  Coin; Lücken über 45 min) und über 24 h aus dem Systemverlauf (über 15 min); **um die längste** (oder `--fenster VON BIS`): alle
  Wächter-Prüfungen mit ihren Abständen (über 7 min = der Pi selbst war überlastet; Takt 300 s + Prüfdauer bis ~35 s, wenn das Dashboard
  hängt), dauernd rote Prüfungen nur mit Namen, Backup-Zeilen; Recorder-Log um den Beginn (Datum rückwärts vom Ende ergänzt, das Log hat
  nur Uhrzeiten) und seine Backup-Zeilen; **Lebenszeichen in den Datenbanken** je Teil (Prognose, TradeLabor Welt B, Welt A, Ausblick,
  Makro, Aktien, Seite im Browser) gegen Recorder und Notbremse-Dienst als eigene Dienste: letzter Eintrag davor, Zahl im **Kern der
  Lücke** (je Rand so breit wie die Genauigkeit der Quelle: Prognosen 15 min, Verlauf 5 min) gegen die erwartete Zahl aus den 6 h davor,
  erster danach; Urteil „das GANZE Dashboard stand“ / „nur TEILE standen“ und das letzte Lebenszeichen vor der Lücke. Im Wächter-Teil
  dazu „Dashboard lief, antwortete aber nicht auf seinem Port in N Prüfungen“. `--journal-dauerhaft an|aus` (U217): Einstellung
  `/etc/systemd/journald.conf.d/90-hl-dauerhaft.conf` (`Storage=persistent`, `SystemMaxUse=200M`, `SystemKeepFree=2G`; 90-…, damit sie
  nach einer Voreinstellung gilt), `/var/log/journal`, `systemd-tmpfiles`, journald neu, `journalctl --flush`; aus: Einstellung und Ordner
  weg, journald neu. Jeder Schritt mit sudo, Passwort nur über stdin, **kein Befehl liest stdin** (auch wenn sudo kein Passwort verlangt,
  landet es nirgends); Fehler hält an; am Ende die wirksame Einstellung aus `systemd-analyze cat-config`.
- **`update.py`:** Units erneuern als Funktion `units_erneuern`; **die Wiederherstellung („Letztes Backup wiederherstellen“) erzeugt die
  Units jetzt mit dem `install.py` des zurückgespielten Stands neu** (Schritt 5b, ohne neue Dienste zu aktivieren). Sonst bliebe nach einem
  Zurück auf 23.77 die neue Unit mit `WatchdogSec` stehen, das alte Dashboard sendet keine Lebenszeichen, und systemd startete es alle
  15 min neu -- eine neue Fehlerquelle, beim Bau gefunden und geschlossen.
- `version.py` 23.78; README (Abschnitt „Weboberfläche nicht erreichbar“: Selbstheilung, Bericht, Systemprotokoll, Wiederherstellung;
  Wächter; Tabelle `check_system.py`).

**Beim Bau berichtigt (eigene Fehler, vor dem Vorpaket):** (1) Die Lebenszeichen zählten zuerst alles zwischen Lückenbeginn (letzte
Prognose) und Lückenende -- ein Teil, der bis zum echten Stillstand noch ein paar Minuten schrieb, galt als „lief weiter“; jetzt der Kern der
Lücke mit Rand. (2) Die Überlast-Schwelle der Wächter-Abstände lag zuerst bei 5:30 und hätte die +35 s der neuen Port-Prüfung bei hängendem
Dashboard als Überlast gezählt; jetzt 7 min, mit Nullprobe. (3) Die Wiederherstellung ließ die neue Unit stehen (siehe `update.py` oben).
(4) Zwei Proben zählten falsch (Codezeile im Stapel; „Current thread“ bei faulthandler) -- an den Proben berichtigt, nicht am Code.

**Proben (Sandbox):**
- `hl_viz.py --selbsttest-lebt` **12 von 12 (17 s)**: sd_notify (Pfad und `@`-Socket empfangen `WATCHDOG=1`; nichts ohne systemd oder für einen
  fremden `WATCHDOG_PID`); `/lebt` antwortet mit einer Datenbank, die es nicht gibt; **Nulltest** gesunder Webserver: 5 Runden, 5-mal
  `WATCHDOG=1`, kein Abzug; Webserver hängt (gebunden, nimmt nichts an): 3 Runden, **kein** `WATCHDOG=1`, Abzug mit Fadennamen beim 2.
  Versuch; Teil-Hänger (TradeLabor 2.000 s still): 3 Runden ein Abzug, nach Fortschritt und neuem Stillstand ein weiterer, Prognose unter
  ihrer Grenze keiner; Log an Ort und Stelle gekürzt (gleiche Datei, ab ganzer Zeile); Zeitstempel je Zeile, Schreibfehler geschluckt;
  Unit-Text und kürzerer Wächter. **Ende zu Ende mit nachgebautem systemd** (Kindprozess mit echtem Handler und echtem Lebenszeichen-Faden,
  Takt 0,2 s, Abzug nach 1,5 s; das Elternteil empfängt die Datagramme und sendet SIGABRT nach 3 s ohne Meldung): gesund -> laufend
  Meldungen, kein Abbruch, kein Abzug; **Positivkontrolle: ein Faden hält das GIL fest** (`ctypes.PyDLL(None).sleep(60)`) -> Meldungen
  hören auf, faulthandler „Timeout (0:00:01.500000)!“ und „Fatal Python error: Aborted“ mit allen drei Fäden und der hängenden Stelle,
  Kind endet mit SIGABRT; Webserver hängt bei freiem GIL -> Abzug mit Namen, Timeout-Abzug, SIGABRT.
- Ende zu Ende mit dem **echten Dashboard** (`hl_viz.py --serve` auf leerer Datenbank, `HL_LOGDIR`, Socket, `WATCHDOG_USEC=8000000`; 23.10.
  18:06): erste Meldung nach 3,7 s, `/lebt` „ok 1098 7“, Ausgabe mit Zeitstempeln in `dashboard.log`; SIGABRT -> „Fatal Python error:
  Aborted“ mit allen Fäden in `dashboard_haenger.log`, Exit −6.
- `check_system.py --selbsttest` **14 von 14**: dazu Hänger-Datei lesen (Start, Abzug mit Namen, faulthandler-Abzug und Abbruch, Stelle je
  Faden); Recorder-Log über Mitternacht; Lebenszeichen je Tabelle (stand / lief weiter / zu selten / Tabelle fehlt); **Fenster Ende zu
  Ende** auf erfundenen Datenbanken und Logs (Lücke aus den Prognosen, Wächter mit einer um 15 min verzögerten Prüfung und zwei Prüfungen
  mit hängendem Dashboard und +35 s, die **nicht** als Überlast zählen; Backup; Welt A fehlt) -> „das GANZE Dashboard stand“, letztes
  Lebenszeichen 09:31; Gegenprobe: TradeLabor schreibt weiter -> „nur TEILE standen“; Systemprotokoll ein/aus (Reihenfolge, nur sudo,
  Passwort nie in den Argumenten, Zwischendatei weg, Fehler hält an, ohne `sudo.txt` nichts, eine später gelesene Einstellung -> „nicht
  erledigt“).
- `hl_watchdog.py --selbsttest` **4 von 4**: antwortet (200) -> ok; älterer Stand ohne `/lebt` (404) -> ok; hängt (gebunden, keine Antwort)
  -> KRITISCH nach zwei Versuchen; Port zu -> KRITISCH.
- **Wiederherstellung** (`b97/restore_probe78.py`: nach 23.78 das Backup 23.77 zurück, in-Prozess mit nachgebautem systemd) **6 von 6**:
  Version danach 23.77, Units mit dem alten `install.py` neu (Dashboard ohne `WatchdogSec`), Reihenfolge Stopp -> Units kopiert ->
  daemon-reload -> Start, keine neuen Dienste aktiviert.
- Übrige Dashboard-Proben grün: `--selbsttest-notbremse`, `--selbsttest-v10`, `--selbsttest-last`, `--selbsttest-quellen`.
- **Mutationen** (je eine Ersetzung in einer Kopie, die Probe muss rot werden): `WATCHDOG=1` auch ohne Antwort, `@`-Socket nicht umgesetzt,
  fremder `WATCHDOG_PID` meldet, Abzug nicht neu gestellt, faulthandler nur für den eigenen Faden, `/lebt` fehlt, Log in neuer Datei
  gekürzt, Teil-Hänger in jeder Runde, Unit ohne `WatchdogSec` / ohne `LimitCORE` / Ausgabe weiter ins Journal, Wächter: hängendes
  Dashboard ok bzw. 404 als Ausfall, Lebenszeichen ohne Rand, Recorder-Log ohne Mitternacht, Abzüge mit Namen nicht umgedreht, Journal:
  Zwischendatei bleibt bzw. Fehler hält nicht an, Wiederherstellung ohne neue Units, Überlast nicht erkannt, ohne Vergleich mit den
  eigenen Diensten, Wächter-Zeile „Dashboard antwortet nicht“ übersehen: **22 von 22 rot (Schlusslauf 18:21:07–18:23:30 am eingefrorenen Stand)**.
- **A7** (`install.py --selftest-isoliert` auf dem Vorpaket mit derselben Prüfsumme): **69 von 69 grün (rc 0, 18:20:20–18:45:54, 1.534 s; Selbstheilung 17,4 s, Wächter 1,8 s, Systemdiagnose 0,2 s)**.
- **Probe von update.py** (altes Paket ausgepackt, zwei echte Läufe ohne Netz und ohne systemd, danach `install.py --units-only` mit
  `--log-dir`): aus 23.77 **23 von 23**, aus 23.76 **23 von 23** -- alle `.py` gleich dem Paket, Version 23.78, eigene `notbremse_termine.json`
  bleibt, Unit des Dashboards mit `WatchdogSec=900`, `NotifyAccess=main`, `LimitCORE=0`, `HL_LOGDIR` und `dashboard.log` im Logordner;
  Notbremse- und Wächter-Unit wie in 23.77.

**Nach dem Einspielen auf dem Pi:** (1) Debug „★ System: letzter Neustart und Ausfälle“: Der Abschnitt „Um die Lücke …“ wertet den Ausfall
vom 23.10. nachträglich aus (Lücke aus den Prognosen) -- stand das ganze Dashboard oder nur ein Teil, wann war das letzte Lebenszeichen,
war der Pi selbst überlastet, lief das Backup? Ausgabe an die nächste Sitzung (U216). Im Abschnitt „Hänger-Schutz“ muss „an, 15min“
stehen. (2) Wenn gewollt: „System: Systemprotokoll dauerhaft speichern -- EINSCHALTEN“ (U217). (3) Abends wie geplant „★ Notbremse:
Rückblick vollständig im Hintergrund STARTEN“ (U210). Offene Seiten anderer Geräte einmal neu laden.

**Grenzen:** systemd selbst gibt es in der Sandbox nicht -- geprüft sind das Protokoll (Datagramm an den Socket, Umgang mit `@` und
`WATCHDOG_PID`), die Unit als Text und das Zusammenspiel mit einem nachgebauten systemd (Kindprozess, SIGABRT nach 3 s ohne Meldung).
Dass systemd bei `WatchdogSec` mit SIGABRT beendet und mit `Restart=always` neu startet, ist dokumentiertes Verhalten, auf dem Pi noch
nicht beobachtet. Hängt ein Faden in einem Systemaufruf, der sich nicht unterbrechen lässt (Zustand D, etwa Platte), wirken Abzug und
SIGABRT erst, wenn der Aufruf zurückkehrt. Hängen nur einzelne Seiten (Datenabfragen), während `/lebt` antwortet, startet nichts neu --
dann gibt es nur die Teil-Hänger-Abzüge (drei Teile). Die Lebenszeichen sind so genau wie ihre Quellen (Rand 15 min); „Seite im Browser“
zählt nur bei offener Seite. Der Wächter bleibt wegen Abdeckung und Poller dauernd rot (U218, nicht in diesem Paket). SSH bleibt aus
(U214, Entscheidung des Nutzers).

Lehre: **Ein laufender Prozess ist kein antwortender Dienst** -- überwacht wird, was der Nutzer braucht (eine Antwort), nicht was systemd
sieht (ein Prozess). Und: **Jede Änderung an einer Unit muss auch rückwärts passen** (Wiederherstellung).

## 3μμμμ. Systembericht nach 23.78 (23.10. 18:58): das ganze Dashboard stand ab etwa 09:36; eigener Fehler im Urteil „nur Teile standen“ (das TradeLabor schreibt Marktzeit); Paket 23.79: TradeLabor-Lebenszeichen nur mit Takt-Arten, Nachholen erkennen, Lücken im System-Verlauf (U216, U219) (23.10. 19:36; Version 2026-09-23.79 · b5e713371a, Opus 5.5)

**Nachricht 18:59** (Zeitstempel des Sitzungsverlaufs): Screenshot des Verlaufs „System“ (Lücke mit schräger Linie bis 100 %) und der
Bericht „★ System: letzter Neustart und Ausfälle“ von 18:58:28 (Pi-Zeit, 2,2 s) -- „die cpu/temp Protokollierung setzte auch aus“.

**23.78 läuft** (eingespielt 18:55, Sicherung `vor_20261023_185528`): Selbstheilung „an, 15min“, Start 18:55:39 in
`logs/dashboard_haenger.log`, `logs/dashboard.log` mit Zeitstempeln; keine Meldung „Lebenszeichen“ seit dem Start.

**Fenster um die Lücke des 23.10.** (Quelle Systemverlauf 09:31:19–14:27:51; die Lücke der Prognosen 09:36:09–14:30:08), beschreibend:
- Wächter: 63 Prüfungen, Abstand 3:32 (der Neustart) bis 5:03, keine verzögert -- **der Pi selbst war nicht überlastet**. Erste Prüfung nach
  dem Neustart 14:27:52 kurz ohne Internet und ohne NTP (normal beim Start). Letztes Backup 22.10. 16:52–17:18 (19.023 MB, 2.168 s) -- **kein
  Backup in der Lücke**.
- Eigene Dienste liefen: Recorder 1.683 Kurszeilen im Kern (erwartet 1.694), Notbremse-Dienst 286.
- Dashboard-Teile mit Schreibzeit: Prognose letzte **09:36:09**, im Kern 0 (erwartet 122); Ausblick letzte 09:06:48, 0 (57); Makro letzte
  09:30:31, 0 (7); Aktien letzte 09:26:34, 0 (19); Systemverlauf letzte Sicherung 09:31:19, die nächste (gegen 09:36:25) fehlt.
- Das Urteil des Berichts lautete „nur TEILE standen … TradeLabor Welt B und Welt A liefen weiter“ (je 76 Einträge im Kern, erwartet 295).
  **Eigener Fehler:** Ich hatte `labor_ereignis.ts` als Schreibzeit genommen, ohne es am Code zu prüfen. Bei Füllungen, Ausstiegen und Grid
  ist es die Zeit der **Kerze** (`ts + 60`, Füllzeit), und nach einem Neustart spielt das Labor die verpassten Kerzen nach
  (`hl_labor._grid_kerzen`: „Abgeschlossene Kerzen seit dem letzten Stand nachspielen“; Positionen über Kerzen geprüft). Solche Einträge
  liegen zeitlich in der Lücke, wurden aber danach geschrieben. Dazu passt: Welt A und B haben genau gleich viele, und es sind weit weniger
  als erwartet (nachgeholt werden nur Kerzen-Ereignisse, keine Takt-Ereignisse). Belegt ist es erst, wenn der Bericht von 23.79 auf dem Pi
  die Takt-Arten und die Schreibreihenfolge zeigt.
- **Folgerung (beschreibend, Indiz):** Alles, was mit seiner Schreibzeit schreibt, stand -- **das ganze Dashboard stand vermutlich ab etwa
  09:36**, rund 19 min nach dem ersten Start von 23.76. Letztes Lebenszeichen 09:36:09 (Prognose); blieb alles gleichzeitig stehen, dann
  zwischen 09:36:09 und etwa 09:36:25 (fällige Sicherung des Systemverlaufs). Die Ursache bleibt offen; ein Stapel vom 23.10. fehlt.
- Nebenbefund (U218): Der Recorder meldet selbst „Der Poller kommt nicht mehr nach … Auslastung 396 %“, rund 71.000 Adressen überfällig
  (Statuszeilen 09:48–10:08); Abhilfe laut Recorder: `--polls-per-min`, `--hot-refresh`, `--hot-notional`.

Antwort an den Nutzer unmittelbar danach, vor dem Bau (Zeit nicht gemessen): dieselbe Lücke; die schräge Linie ist ein Zeichenfehler; was
der Bericht zeigt; eigener Fehler im Urteil; 23.79 angekündigt.

**Gebaut (23.79):**
- **`check_system.py` (U219):** Beim TradeLabor (Welt B in `forecasts.db`, Welt A in `labor_a.db`) zählen als Lebenszeichen nur die Arten,
  die es immer mit der Zeit des Takts schreibt (`now`): `limit`, `storno`, `stop` (nachgezogen), `verfallen`, `kaskade` -- am Code geprüft
  (alle Aufrufe von `_ereignis`). Für die übrigen Einträge mit Zeit in der Lücke (Marktzeit) prüft `nachgeholt_pruefen` die
  Schreibreihenfolge (AUTOINCREMENT-id): Rücksprünge über 15 min (je Strategie nachgespielt) und Einträge hinter dem ersten Eintrag nach der
  Lücke -> „nachgeholt (erst nach der Lücke geschrieben)“, sonst „in Schreibreihenfolge gleichmäßig“. Eine Zeile erklärt die Regel.
- **`hl_viz.py`:** Verlauf „System“: Lücken über 3 min grau mit „keine Messung“ und Uhrzeiten (nur, was in die Fläche passt), die Linien
  werden über eine Lücke **nicht** verbunden; die Zeile darunter nennt die Lücken (Zahl, längste mit Datum).
- README (Lebenszeichen des TradeLabors, Verlauf mit Lücken), `version.py` 23.79.

**Proben (Sandbox):**
- `check_system.py --selbsttest` **14 von 14**: das Fenster Ende zu Ende jetzt mit realistischen TradeLabor-Einträgen (vorher live Takt-Arten
  und Kerzen-Ereignisse; nach dem Neustart ein Takt-Eintrag, dann je Strategie die Kerzen der Lücke nachgeholt) -> „das GANZE Dashboard
  stand“, „nachgeholt (erst nach der Lücke geschrieben)“ mit 60 Einträgen, 1 Rücksprung, 60 dahinter; Gegenprobe Labor tickt live durch
  die Lücke -> „nur TEILE standen“, „kein Zeichen für Nachholen“.
- **Browserprobe** Verlauf „System“ (`b97/browser_sys.py`, echte Seite, Handy 390 px und Desktop 1280 px) **12 von 12**: 5-h-Lücke erkannt, in
  der Mitte der Lücke keine blauen oder gelben Linienpixel (Grenzlinien 70/80 °C ausgenommen), Zeile darunter nennt die Lücke; Nulltest
  ohne Lücke: keine Fläche, Linien durchgehend; keine JS-Fehler, keine Seitenbreite über dem Bildschirm. Mutation „überbrückt“ (Linien wie
  bis 23.78): **rot** (Linienpixel in der Lücke).
- `hl_viz.py --selbsttest-lebt` 12 von 12, `--selbsttest-notbremse` grün; Wiederherstellung 6 von 6.
- **Mutationen** (23.78 und neu: alle TradeLabor-Arten als Lebenszeichen, Nachholen nicht erkannt): **24 von 24 rot (19:12:15–19:14:38 am eingefrorenen Stand)**.
- **A7** (`install.py --selftest-isoliert` auf dem Vorpaket mit derselben Prüfsumme): **69 von 69 grün (rc 0, 19:11:47–19:36:28, 1.481 s)**.
- **Probe von update.py** (zwei echte Läufe, danach Units): aus 23.78 **23 von 23**, aus 23.77 **23 von 23**.

**Nach dem Einspielen:** „★ System: letzter Neustart und Ausfälle“ noch einmal (bis etwa 24.10. 09:31 liegt die Lücke noch im
Systemverlauf, danach findet der Bericht sie über die Prognosen): Die Zeilen „TradeLabor … (zur Takt-Zeit geschrieben)“ und „… mit Marktzeit
in der Lücke“ entscheiden, ob das Labor in der Lücke tickte. Ausgabe an die nächste Sitzung (U216). Abends wie geplant der Rückblick der
Notbremse (U210).

**Grenzen:** Sind die Takt-Arten selten, heißt das Urteil „zu selten für ein Urteil“. Nachholen erkennt die Schreibreihenfolge nur, wenn
mindestens zwei Strategien Einträge in der Lücke haben oder ein Takt-Eintrag nach der Lücke vor ihnen geschrieben wurde. Das Ganze bleibt
ein Indiz über Lebenszeichen; die Ursache zeigt erst ein Stapelabzug beim nächsten Hänger (23.78).

Lehre: **Eine Zeitspalte ist erst dann ein Lebenszeichen, wenn sie die Zeit des Schreibens trägt -- am Code prüfen, nicht annehmen.**

## 3νννν. Bericht nach 23.79 (23.10. 20:30): Das ganze Dashboard stand ab etwa 09:36 -- bestätigt mit den Takt-Einträgen des TradeLabors; Ursache weiter offen (U216, U219) (23.10. 20:33; Version 2026-09-23.79 · b5e713371a, kein neues Paket, Opus 5.5)

**Bericht des Nutzers** (Debug „★ System: letzter Neustart und Ausfälle“ auf 23.79, eingespielt 20:29, Sicherung `vor_20261023_202933`;
Lauf 20:30:49, 1,1 s; hochgeladen 20:31 ohne Text), beschreibend:
- Lebenszeichen im Kern der Lücke (09:36:19–14:22:51; Quelle Systemverlauf 09:31:19–14:27:51): Prognose 0 (erwartet 122), **TradeLabor
  Welt B zur Takt-Zeit 0 (45), Welt A 0 (45)**, Ausblick 0 (57), Makro 0 (7), Aktien 0 (19); Recorder 1.683 (1.694) und Notbremse-Dienst 286
  liefen. Urteil des Berichts: „das GANZE Dashboard stand“; letztes Lebenszeichen 09:36:09 (Prognose), erstes danach 14:28:22 (TradeLabor).
  Der letzte Takt-Eintrag des TradeLabors vor der Lücke ist von 09:28:18 -- bei etwa 9 je Stunde ist eine Pause von 8 min bis 09:36 nicht
  auffällig.
- TradeLabor mit Marktzeit in der Lücke: Welt B und Welt A je 82 Einträge, in Schreibreihenfolge 12 Rücksprünge über 15 min, 72 hinter dem
  ersten Eintrag nach der Lücke -> **nachgeholt**. Damit ist der eigene Fehler aus 23.78 (U219) auf dem Pi bestätigt und behoben.
- Der Pi selbst: 63 Wächter-Prüfungen in der Lücke ohne Verzögerung; kein Backup in der Lücke (letztes 22.10. 16:52–17:18).
- Seit 23.78 (18:55) **kein Hänger**: Hänger-Datei nur mit den Starts 18:55:39 und 20:29:47, keine Meldung „Lebenszeichen“. Die Lücke
  20:24:52–20:30:49 im Verlauf ist das Update auf 23.79.
- **Gesamtbild 23.10. (beschreibend, Indiz):** Der Dashboard-Prozess blieb um etwa 09:36 als Ganzes stehen -- alle Teile, die messbar
  schreiben, zur selben Zeit -- rund 19 min nach dem ersten Start von 23.76, und galt für systemd bis zum Neustart 14:27 als „aktiv“. Pi,
  Platte, Netz, Recorder und Notbremse-Dienst waren in Ordnung. Ein Stillstand ALLER Fäden zugleich passt eher zu etwas, das den ganzen
  Python-Prozess anhält (etwa ein C-Aufruf, der die Interpretersperre GIL hält), als zu einem einzelnen blockierten Faden -- eine Folgerung,
  kein Beleg. Die Ursache bleibt offen; beim nächsten Hänger startet systemd das Dashboard nach 15 min neu, und `logs/dashboard_haenger.log`
  zeigt, wo jeder Faden stand (U215).
- Kleinigkeiten: In `dashboard.log` steht die Makro-Zeile mit doppelter Zeit („2026-10-23 19:39:59 [19:39:59] Makro: …“), weil der
  Makro-Takt selbst stempelt -- harmlos. Die Abdeckung fällt nach jedem Neustart des Recorders etwa 15 min später für 15–30 min (17:45 nach
  dem Update 17:30, 19:10 nach dem Update 18:55) und erholt sich -- gehört zu U218.

**Nichts gebaut** (kein neues Paket; Dokumente im Arbeitsstand, sie kommen mit dem nächsten Paket). U216 erledigt.

## 3ξξξξ. Wächter dauernd rot (U218): Poller und Abdeckung gegen den eigenen Normalwert; Debug „★ Recorder: Poller-Kapazität“ mit einem Modell der Auswahl des Recorders; Änderung am Poller erst nach dem 25.10. (U220) (23.10. 21:45; Version 2026-09-23.80 · 6c64536b8f, Opus 5.5)

**Nachricht 20:35** (Zeitstempel des Sitzungsverlaufs): „Ja, dann nimm dir den Wächter vor“ -- auf das Angebot in der Antwort von 20:33
(U218).

**Befund vor dem Bau** (Code von 23.79, Meldungen des Wächters im Bericht des Nutzers von 20:30, beschreibend):
- Der Wächter stand am 23.10. ganztägig auf KRITISCH (33 Meldungen 14:14–20:29, alle KRITISCH). Die Zeile „Poller“ nahm das 90-%-Quantil
  des Alters der letzten Abfrage über **alle** Adressen mit Position -- auch die kleinen, die planmäßig nur alle 2 h drankommen -- und war
  über 120 min KRITISCH; gemessen 1.062 bis 1.161 min. Die Zeile „Abdeckung“ warnte, sobald ein Coin unter 25 % lag (PAXG 6–22 %, XMR
  6–16 %, ZEC 10–21 %; die tiefsten Werte kurz nach Neustarts des Recorders).
  Beides ist ein Dauerzustand, kein Ausfall: Der Recorder meldet selbst „Der Poller kommt nicht mehr nach … Auslastung 396 %“ (74 Wale /
  2.430 groß / 6.787 mittel), und `addresses.last_poll` schreibt er nur stündlich gesammelt. Ein Wächter, der immer rot ist, meldet keinen
  echten Ausfall mehr.
- Am Code der Auswahl geprüft (`hl_recorder.due_addresses`, `run_poller`): Reihenfolge gesperrt (alle 6 h, nur ab 25.000 USD, Rang 2) ->
  Elite (Wal-Takt, auch ohne Position, Rang 0) -> Pool „Aktive Profis“ (alle 10 min, auch ohne Position, Rang 1) -> nach Positionswert
  (Wale Rang 0; groß, mittel, klein Rang 1). Je Runde max(int(Rate/12), 10) Adressen: int(65 %) für Konten mit Position, int(25 %) für nie
  abgefragte (fast immer leer, der Rest fällt an die Konten mit Position), der Rest an leere Adressen mit neuem Handel -- bei 280/min 19 von
  23 = 82,6 %. Rang 1 wird nach Überfälligkeit relativ zum eigenen Takt sortiert. Die „Auslastung“ der Statuszeile rechnet Wale, groß und
  mittel gegen das ganze Budget, ohne kleine Konten, Elite und Pool.
- **Nebenbefund (aus dem Code und im Modell; die Messung steht aus):** Gesperrte Konten kommen als Rang 2 erst nach allen anderen dran --
  bei Überlast also nie. Auch ohne Überlast wären sie höchstens 1/6 der Zeit im Snapshot (Abstand 6 h, der Snapshot nimmt nur Abfragen bis
  1 h). Die Absicht „gesperrte Konten bleiben als Liquidationsstufe in der Heatmap“ wird so nicht erreicht. Gehört zu U220; der Bericht
  „Poller-Kapazität“ zeigt das gemessene Alter der gesperrten Konten.

**Festlegung bei diesem Bau:** Am Poller selbst (Takte, Stufen, Budget) ändert sich bis zum 25.10. nichts -- die Auswertungen U108, U110 und
U115 hängen an den Heatmap-Daten, eine Änderung mitten im Fenster würde sie brechen. Danach U220.

**Gebaut (23.80):**
- **`hl_watchdog.py` (U218):** Zeile „Poller“ KRITISCH, wenn er steht (letzte Runde laut `meta` 'jobs' über 5 min her, sonst alle 5 s; ein
  bei 4.000 Zeichen abgeschnittenes JSON wird per Muster gelesen) oder der Snapshot leer ist; WARNUNG, wenn der Anteil zu alter Positionen
  im letzten Snapshot (`snapshot_meta`) mehr als 20 Prozentpunkte über seinem Normalwert liegt (Median der letzten 7 Tage ohne die 45 min
  nach einem Neustart des Recorders, mindestens 36 Snapshots = 6 h) oder mindestens 97 % beträgt. Zeile „Abdeckung“ WARNUNG, wenn ein
  Coin unter die Hälfte seines Normalwerts fällt (ohne Normalwert: unter 2 %). In den 45 min nach einem Neustart des Recorders kein Alarm,
  nur „Anlauf“ -- außer bei 3 und mehr Starts in 2 h (WARNUNG „Neustart-Schleife?“, Starts aus `snapshot_meta` als ts − uptime), damit der
  Anlauf eine Schleife nicht verdeckt. Das bekannt zu knappe Budget steht als Text in der Zeile („Abfragebudget zu knapp, bekannt (U218)“).
- **`check_system.py --poller`**, Debug **„★ Recorder: Poller-Kapazität“** (liest nur): Einstellungen aus der Unit (auch `--max-pos-age`),
  gemessene Rate des Pollers (`api_load`, Median der letzten 3 h, Gewicht/2), Abfragen je Konto (Dexe), Wärme-Faktor; je Stufe (Wale,
  Elite, groß, Pool, mittel, klein, gesperrt) Konten, Positionswert, Bedarf, Abstand und frischer Anteil im Modell und das gemessene Alter
  aus der Datenbank; Gegenprobe Pool (Anteil an den Abfragen im Modell gegen die Messung des Recorders je Runde), die Formel der Statuszeile
  zum Vergleich, Snapshot und Abdeckung gegen den 7-Tage-Median, sechs Varianten im Modell, Befund. Im Berichtsplan am 24.10. 08:50 und
  26.10. 08:50.
- `hl_viz.py`: Debug-Eintrag und die beiden Termine im Berichtsplan. In der Tabelle des Berichtsplans brechen lange Wörter jetzt um -- die
  Seite war am Handy 10 px breiter als der Bildschirm, schon vor 23.80 (gefunden mit der Browserprobe dieses Baus).
- `install.py` (Schrittnamen), README (Alarm, Datenqualität, Werkzeugliste), `version.py` 23.80.

**Eigene Fehler beim Bau** (vor der Auslieferung gefunden): Die Schonzeit „Anlauf“ hätte eine Neustart-Schleife des Recorders verdeckt
(jede Prüfung fiele in einen Anlauf) -- jetzt WARNUNG ab 3 Starts in 2 h. Die erste Fassung des Modells übersah Elite, Pool und gesperrte Konten und nahm
für die Konten mit Position pauschal 90 % jeder Runde statt der ganzzahligen Aufteilung (82,6 %) -- beim Abgleich mit `due_addresses` und
`run_poller` gefunden und berichtigt; seitdem binden die Simulation gegen die echte Auswahl und Probe C17 das Modell an den Recorder. Dazu drei
Fehler in meinen Proben (abgeschnittenes JSON an der falschen Stelle, Median der Proberate falsch nachgerechnet, 61 statt 62 % erwartet) --
an den Proben berichtigt, nicht am Code.

**Proben (Sandbox):**
- `hl_watchdog.py --selbsttest` **14/14**: Nulltest Dauerzustand wie am 23.10. (80 % zu alt, Abdeckung 14–26 %) -> ok mit „üblich“;
  Positivkontrollen Poller steht (KRITISCH), Snapshot leer (KRITISCH), 60 % -> 86 % zu alt (WARNUNG), 98 % (WARNUNG), 92 % bei üblich 80 %
  (ok), XMR 4 % statt üblich 14 % (WARNUNG); Anlauf nach Neustart (ok); Neustart-Schleife alle 30 min (WARNUNG trotz Anlauf); ohne Verlauf;
  Normalwert ohne Anlaufzeiten (Neustart alle 2 h); abgeschnittenes meta 'jobs'. Ein ganzer Lauf `--once` auf einer Probe-Datenbank ohne Fehler.
- `check_system.py --selbsttest` **18/18**: C14 Modell von Hand nachgerechnet (Ränge, Faktor, Abstände, frischer Wert, gemessene Rate,
  Dexe, Wärme), C15 Stufengrenzen mit Sonderstufen, Anteil je Runde, Text des Pollers auch aus abgeschnittenem JSON, C16 Bericht Ende zu
  Ende auf erfundener Datenbank (Elite aus forecasts.db, Pool nur in der Hysterese, gesperrt aus konto_status und labels.json, nie
  abgefragte getrennt, Rate, Gegenprobe Pool, Formel der Statuszeile), **C17 Werte und Reihenfolge gegen den Quelltext des Recorders**
  (ändert jemand dort Takte, Stufen oder die Reihenfolge, wird die Probe rot).
- **Positivkontrolle des Modells gegen die echte Auswahl** (`b99/sim_poller80.py`, Kriterien vorab im Kopf des Skripts festgelegt):
  `hl_recorder.Recorder.due_addresses` über 15 h simulierte Zeit (Runde 5 s, 120 Abfragen/min, Auswertung ab 6 h; 20:59:00–20:59:52).
  **Überlast** (Modell F = 2,75): mittlere Abstände groß, Pool, mittel, klein gegen das Modell 0,989; 0,985; 0,983; 0,982 (erlaubt
  0,90–1,10); Wale und Elite 65 s (erlaubt bis 70 s); gesperrte nach dem Anlauf 0 Abfragen; Abfragen der Konten mit Position 5.760/h gegen
  5.760/h im Modell; frischer Positionswert gemessen 93,0 % gegen 92,8 %; Mutation „Sonderstufen übersehen“ -> drei Stufen außerhalb,
  erkannt. **Ohne Überlast** (Modell F = 1): Wale, Elite, groß und Pool in der Grenze „Takt + 2 Runden“, **mittel, klein und gesperrt
  nicht** (1.817 s statt höchstens 1.810, 7.241 statt 7.210, 21.778 statt 21.610) -- nach dem Vorab-Kriterium nicht bestanden. Beschreibend
  liegen sie 0,9 %, 0,6 % und 0,8 % über dem Takt (Warten in der Schlange bei 72 % Last); die Grenze war für lange Takte zu eng gewählt. Für
  die Aussagen des Modells (Faktor, frischer Anteil) ist das unerheblich.
- `hl_viz.py --selbsttest-lebt` **12 von 12** (Debug-Eintrag, beide Termine, jeder Lauf des Berichtsplans hat einen Debug-Eintrag),
  `--selbsttest-notbremse` grün.
- **Browserprobe** (`b99/browser_debug80.py`, echte Seite mit den echten Antworten von `debug_commands` und `berichte_uebersicht`, Handy
  390 px und Desktop 1280 px): Debug-Liste mit „★ Recorder: Poller-Kapazität“, Berichtsplan mit beiden Terminen, keine JS-Fehler, Seite
  nicht breiter als der Bildschirm (vorher 400 px auf 390 px, auch ohne die neuen Einträge); Nulltest ohne die Einträge -> rot.
- **Mutationen** (`b99/mutationen80.py`): **54 von 54 rot (21:17:25–21:19:46)**: die 24 aus 23.78/23.79 und 30 neue -- Wächter M25–M34 mit M33b, M52, M53
  (Neustart-Schleife verdeckt, Starts eines Laufs mehrfach gezählt), Modell M35–M43, M48, M49, Recorder geändert ohne Modell M44–M46,
  Debug-Eintrag M47, Berichtsplan M50–M51.
- **A7** (`install.py --selftest-isoliert` auf dem Vorpaket mit derselben Prüfsumme): **69 von 69 grün (rc 0, 21:19:49–21:44:38)**.
- **Probe von update.py** (zwei echte Läufe, danach Units): aus 23.79 **23 von 23**, aus 23.78 **23 von 23**. Wiederherstellung (Probe aus 23.78,
  Rückkehr auf 23.77) **6 von 6**; mit 23.78 als Ziel 5/6 -- erwartet, die Probe verlangt fest eine Unit ohne `WatchdogSec`, und 23.78 hat sie
  schon.

**Nach dem Einspielen:** Im Wächter sollten „Poller“ und „Abdeckung“ ok sein, mit „üblich …“ und dem Hinweis U218; KRITISCH heißt jetzt:
Poller steht oder Snapshot leer. Den Bericht „★ Recorder: Poller-Kapazität“ legt der Berichtsplan am 24.10. 08:50 und am 26.10. 08:50 an
(oder von Hand starten) -- bitte hochladen. Ob das Modell auf dem Pi stimmt, zeigen die Gegenprobe Pool und das gemessene Alter je Stufe;
danach entscheidet er, was an U220 zuerst kommt.

**Grenzen:** Das Modell nimmt an, dass die Gruppe der nie abgefragten Adressen fast leer ist (am 23.10. 0–31 neue je Statuszeile) und die
Gruppe der leeren Adressen ihren Anteil immer füllt. „frisch (Wert)“ misst den Anteil des **bekannten** Positionswerts, dessen Abfrage
höchstens 1 h alt ist -- nicht die Abdeckung des Open Interest; Konten, die der Recorder nicht kennt, fehlen in beiden Rechnungen. Der
Normalwert im Wächter wandert mit: Eine langsame Verschlechterung über Wochen meldet er nicht (nur die feste Grenze 97 %) -- dafür ist der
Bericht da.

## 3οοοο. Volumen-Analyse für alle Trading-Strategien (U221): Datenlage am Code geprüft; Entscheidung des Nutzers „Erst messen, dann filtern“ (24.10. 02:40; Version 2026-09-23.80 · 6c64536b8f, kein neues Paket, Opus 5.5)

**Nachricht 02:13** (Zeitstempel der Sitzung): „wir brauchen für alle trading strategien eine volumen analyse. Lassen sich volumendaten von
den bestehenden börsen holen?“

**Datenlage (am Code geprüft, beschreibend; Mengen auf dem Pi nicht gezählt):**
- **Hyperliquid, eigene Aufzeichnung über den WebSocket (kein API-Gewicht):** `bars` je Minute (Volumen in Coin-Einheiten, Zahl der Trades)
  und `bars10` je 10 s mit **Taker-Kauf und Taker-Verkauf** (Coin-Einheiten), Zahl der Trades, Liquidationen und größtem Trade -- beide
  ohne Löschfrist, seit dem Start der Aufzeichnung; dazu der Adress-Strom (`adressfluss.db`, Volumen je Konto, 14 Tage). Für die sechs Coins
  BTC, ETH, HYPE, ZEC, XMR, PAXG.
- **Binance:** 30-min-Kerzen der USDT-Perps mit Volumen ohne Seitenaufteilung (`swing.db` ab 01.01.2020, `klines30`); Tageskerzen der
  Spot-, USDⓈ-M- und COIN-M-Märkte mit Volumen in USD, **Taker-Kauf in USD** und Zahl der Trades sowie das Taker-Verhältnis je Stunde
  (`hebel.db` ab 2020; BTC, ETH, ZEC, XMR, HYPE); `daily_bars` mit Volumen; das Taker-Verhältnis aus `--backfill` nur 30 Tage. PAXG nicht
  als Binance-Perp (Kerzen von Bybit im Regime-Modul), HYPE ab 30.05.2025.
- **Coinbase-Spot, eigene Aufzeichnung:** `cb_bars` je Minute mit Volumen, Trades, Taker-Kauf und -Verkauf in USD -- Seiten erst ab 22.09.
  22:27 verlässlich (davor vertauscht, beim Lesen über `cb_seite_ab` korrigiert, U41); XMR nicht gelistet.
- **Nicht gespeichert, aber verfügbar:** das Taker-Kaufvolumen jeder Binance-Kerze (Felder 9/10 der Kerzen-Schnittstelle, Archiv
  data.binance.vision ab 2020, 1 min bis 1 Tag) -- die Lader werfen es weg, außer bei den Tageskerzen in `hebel.db`.
- **Nicht empfohlen:** Volumen-Historie über Hyperliquids `candleSnapshot` (nur die letzten 5.000 Kerzen je Auflösung, ohne Seiten, kostet
  API-Gewicht -- der Recorder läuft am Deckel, U218).
- Vorsicht beim Vergleich: Einheiten (Coin gegen USD), Perp gegen Spot, starke Abhängigkeit von Tageszeit und Wochentag (relatives Volumen
  statt rohem), Zusage bis zum 25.10. (nichts fließt in Labor, Konfluenz oder Prognose).

Antwort an den Nutzer mit dieser Datenlage, danach eine Auswahl. **Entscheidung des Nutzers 02:37** (Zeitstempel der Antwort): **„Erst messen,
dann filtern“** -- Stufe 1 vorab festgelegt je Strategie auswerten, ob Einstiege bei hohem oder niedrigem Volumen bzw. Taker-Saldo besser
laufen, nur Bericht; Stufe 2 Filter erst, wenn belegt, und nicht vor dem 25.10. Die beiden anderen Wege („gleich Volumenfilter einbauen“,
„erst Daten vervollständigen“) nicht gewählt.

**Nächster Schritt:** `KONZEPT_Volumen.md` vorab festschreiben (Kennzahlen, Strategien, Nullmodell, Positivkontrollen, Urteilsregeln), dann
das Werkzeug bauen (liest nur; darf vor dem 25.10. laufen, fließt nirgends ein). Kein Code geändert.

**Nachtrag 03:11: Entwurf `KONZEPT_Volumen.md` zum Gegenlesen** (noch nicht freigegeben, nichts gebaut). Teil A live: alle geschlossenen
Trades des Labors (Welt B) mit RV (Umsatz im Fenster gegen denselben Zeitraum an Tagen gleicher Art der 28 Tage davor) und TS (Taker-Saldo
in Handelsrichtung gegen den üblichen Saldo), Drittel je Schicht (Kennung × Long/Short × Werktag/Wochenende), Nullmodell Zeitverschiebung
der fertigen Reihen um ±24…±336 h, Hauptprüfungen gepoolt (A1 RV, A2 TS) über einen festen Pool (ohne Zufalls-Kontrollen,
volumengekoppelte Auslöser und die „…_gegen“-Spiegel), je Strategie mit Normalnäherung und Holm, Urteil erst am 08.11.; Teil B Historie:
die vier Swing-Strategien seit 2020 mit Tages-RV und -Taker-Anteil aus `hebel.db` (B1, B2). Vor der Vorlage hat eine unabhängige Durchsicht
(Entwurf und Code, ohne meine Schlussfolgerungen) sieben Punkte gefunden, alle eingearbeitet (`KONZEPT_Volumen.md` 13) -- darunter eigene
Fehler im ersten Entwurf: ein Urteil je Strategie wäre mit 626 Verschiebungen nach Holm unerreichbar gewesen (meine Trennschärfe-Angabe
war falsch), der Wochentag hätte als Volumen-Effekt durchgehen können, TS hätte Long gegen Short sortiert.
**Befund im Recorder (U222, am Code geprüft):** `flush_bars`/`flush_bars10` schreiben eine Minute bzw. ein 10-s-Stück, sobald seine Zeit
vorbei ist, entfernen es aus dem Speicher und schreiben mit `INSERT OR REPLACE`; ein danach eintreffender Trade derselben Minute beginnt
ein neues Stück, das die vollständige Zeile ersetzt. Trades werden nicht nach `tid` entdoppelt (ein Schnappschuss beim Neuverbinden würde
offene Minuten doppelt zählen). Ausmaß unbekannt -- die Studie zählt „fragliche Minuten“ (`bars.volume` gegen Σ `bars10`); Behebung nach
dem 25.10.

## 3ππππ. Volumen-Studie gebaut (U221): `hl_volumen.py` -- Teil A Labor-Trades (Urteil 08.11.), Teil B Swing-Historie; beim Bau eine Korrektur am Konzept (Tagesart in der Mitte des Fensters) (24.10. 05:21; Version 2026-09-23.81 · 52636840b9, Opus 5.5)

**Freigabe 03:17** (Zeitstempel der Antwort): „Freigeben wie vorgeschlagen (Vorschlag)“ -- Urteil Teil A am 08.11., Teil B mitbauen, Stufe 2
nur für „belegt“, zwei Hauptkennzahlen RV und TS (`KONZEPT_Volumen.md` 11). Gebaut danach bis 05:21 (Dateizeiten), vor jeder echten Zahl;
auf dem Pi lief noch nichts.

**Gebaut** (`hl_volumen.py`, liest nur, schreibt nichts, fließt nirgends ein):
- **Teil A (live):** geschlossene Trades aus `forecasts.db` (Limit-Einstiege ab der gefüllten Order; heraus und je Strategie gezählt:
  „Regelversion abgelöst“, Grid, Akkumulation, fremde Coins, Limit ohne Order, vor der Spanne). Minuten aus `bars` und `bars10` (je
  Tabelle eine Abfrage für alle Coins, `bars10` in numpy je Minute summiert -- ein GROUP BY in SQLite hätte einen temporären Baum von
  rund 500 MB gebraucht, im Speicher oder auf der SD-Karte). Gültigkeit: BTC-Bar = aufgezeichnet; fragliche Minute bei
  mehr als 1 % Abweichung `bars` gegen Σ `bars10` (U222); höchstens 5 % Lücken je Fenster; TS ab 20 Trades; 70 % der Vergleiche.
  Seitenprüfung je Coin (Spearman > 0,1). RV und I_rel je Minute für 60 min und 24 h; Drittel je Schicht; Nullmodell 626 Verschiebungen der
  fertigen Reihen, zirkulär über die Spanne; Blockbootstrap über Kalendertage (1000); Hälften; Holm über A1/A2; je Strategie
  Normalnäherung der Null mit Holm und BH; Urteil erst ab 08.11. 00:00 UTC, davor „vorläufig“.
- **Teil B (Historie):** `hl_swing.lauf` je Coin und Strategie aus `HAUPT` auf `swing.db` bis 23.10. (Kerzen danach nicht gelesen), ohne
  „offen am Ende“; Tages-RV und Taker-Anteil aus `hebel.db`; 672 Verschiebungen in Tagen, Blöcke von 60 Tagen.
- **Beschreibend** 6.1–6.12, **Stand heute** (7), Anhang mit den Drittelgrenzen je Schicht, Lesart; der Bericht nennt seine Laufzeit.
- **Einbindung:** Debug „★ Volumen: Einstiege der Strategien nach Volumen (U221)“ und „Volumen-Studie: Selbsttest“; Berichtsplan 24.10.
  21:15 (Teil B mit Urteil, Teil A vorläufig), 25.10. und 01.11. 09:15 (vorläufig), **08.11. 09:15 Urteil Teil A**; `install.py`
  (Syntaxprüfung, Selbsttest-Schritt), `version.py` (Projektdatei), `update.py` (Projektdateien samt Konzept), README.

**Korrektur beim Bau -- eigener Fehler im freigegebenen Konzept** (`KONZEPT_Volumen.md` 12.1, vor jeder echten Zahl): Die Tagesart der
Vergleichsfenster stand „am Ende des Fensters“. Ein 24-h-Fenster, das Samstag früh endet, enthält aber den Freitag, eines am Montag früh den
Sonntag. Einstiege kurz nach Mitternacht (Swing, Zyklus, Familien mit 24 h) hätten je nach Wochentag systematisch hohe oder niedrige RV
bekommen, und ein Wochentag-Effekt im Ertrag wäre als Volumen-Effekt durchgegangen. Probe auf erfundenen Daten (reiner Montags-Effekt
+0,5 Punkte, Einstiege 00–06 UTC, 24-h-Fenster, 79 Verschiebungen): mit „Ende“ D −0,206, p 0,025 -> „belegt“ (falsch); mit „Mitte“ D +0,050,
p 0,650 -> nicht belegt. Jetzt wird nach der Tagesart in der Mitte des Fensters verglichen; die Schichten bleiben bei der Tagesart des
Einstiegs. Bleibt als Grenze: Unterschiede zwischen den Werktagen (Montag gegen Freitag) bereinigt RV nicht.

**Präzisierungen beim Bau** (`KONZEPT_Volumen.md` 12.2–12.12): Spanne ab erster BTC-Bar + 28 Tage + 24 h, Minuten höchstens 120 Tage vor dem
ersten Labor-Trade gelesen; Drittel mit k = n // 3; Kontrollen nicht in der Familie je Strategie; „Teil B vollständig“ genau; Regeln des
Bootstraps; Pools der beschreibenden Teile; „Band eng um 0“ = ganz innerhalb ±0,25; Stand heute 2 min vor dem Lauf; einzelne Termine im
Berichtsplan; Laufzeit; 6.4 aus `swing.db` statt `klines30`.

**Zweite unabhängige Durchsicht (Code gegen das Konzept, ohne meine Schlussfolgerungen; gestartet nach 04:30, Laufzeit 19,6 min):**
nichts, was bei vollständigen Daten ein Urteil ändert; sieben Punkte, sechs umgesetzt (KONZEPT 12.13–12.18): (1) eigener Fehler -- Holm über
A1/A2 schrumpfte auf einen Test, wenn A2 nicht prüfbar ist (jetzt zählt die nicht prüfbare mit p = 1); (2) das Labor löscht erledigte
Orders 30 Tage nach der Füllung -- t0 der Limit-Einstiege kommt dann aus dem Ereignis „limit“ (90 Tage, dieselbe Zeit); (3) bei einer
Spanne unter 28 Tagen doppelte Lagen der Verschiebung (bei 25 Tagen 73 von 626) -- entfernt, der Bericht nennt die Zahl; (4) Gruppen 6.1
mit den Gewichten je Verschiebung; (5) Prüfsumme der Eingangsdaten von Teil B im Bericht (die Studie schreibt nichts; maßgeblich ist der
erste vollständige Bericht); (6) 6.9 im Urteilslauf nur bis zum Stichtag. Der siebte Punkt („Mutationen fehlen im Code“) ist Absicht:
Die Mutationen laufen außerhalb des Moduls (Liste unten). Dazu je Punkt eine Probe und eine Mutation (M32–M37).

**Hinweis zur Datenlage (vor dem ersten Lauf, nicht gemessen):** Laut UEBERGABE zur Akkumulation (23.70) begann die Aufzeichnung in
`hl_liq.db` Mitte September. Dann beginnt die Spanne der Kennzahlen erst Mitte Oktober, und Teil A hat bis zum 08.11. rund 3½ statt 6 Wochen
Trades; die Trades davor fallen heraus (gezählt). Der erste Bericht nennt die erste BTC-Bar und die Spanne. Ob der Stichtag bleibt,
entscheidet dann der Nutzer (KONZEPT 11.1).

**Nebenbefund (am Code gesehen, auf dem Pi nicht geprüft) -> U223:** `klines30` füllt nur der Handaufruf von `hl_timestats.py` (einmalig
geladen, siehe `hl_forecast._series_30m`), und die letzte Kerze eines Abrufs bleibt unvollständig gespeichert (der Lader setzt nach ihr
fort). Die Prognose stückelt an; der 4-h-Chart des Dashboards (`load_long_candles`) nimmt `klines30` und ersetzt nur die letzten 8 Tage
durch eigene Bars -- dazwischen kann eine Lücke liegen.

**Proben:**
- Selbsttest 21 von 21 (rund 21 s): Rechnung von Hand (RV und TS 60 min und 24 h, Vergleiche nach der Fenstermitte), Kausalität, Gültigkeit (BTC-Lücke,
  fragliche Minute, Mindestzahl Trades), Seitenprüfung mit vertauschten Seiten, t0 bei Limit und Ausschlüsse, Drittel mit Gleichstand,
  Holm/BH/p mit versetzter Null und Hälften gegen den Null-Median, Verschiebung der fertigen Reihen, Positivkontrollen RV und TS (A1/A2 und je
  Strategie belegt), Negativkontrolle (0 von 20 Saaten belegt), Störgrößen Wochenende, Long/Short und Montag, Pool fest bei τ = 0, Teil B
  von Hand und über `hl_swing.lauf` (mit Spion für „offen am Ende“), Urteil erst am Stichtag, Markteffekt, Bausteine (Median, Spitze,
  Binance-RV, Coinbase mit berichtigten Seiten, Bootstrap ohne neues Sortieren gleich der Rechnung mit wiederholten Trades), Ende zu Ende
  auf erfundenen Datenbanken (vorläufig vor, Urteil nach dem Stichtag, alle Teile des Berichts, Teil B ohne Einstiege nach dem 23.10.).
- Mutationen 37 von 37 rot (05:12:52–05:19:52): M01 Fenster bis einschließlich t0, M02 TS ohne Vorzeichen der Seite, M03 `vol_buy`/`vol_sell` vertauscht, M04 Drittel
  über alle Strategien, M05 Drittel im Bootstrap ohne Schicht, M06 Tagesart beim Vergleich ignoriert, M07 τ = 0 in der Null, M08 Rohvolumen
  statt fertiger Reihe verschoben, M09 Verschiebung über alle Minuten statt über die Spanne, M10 p gegen 0, M11 ohne Holm, M12 Limit mit
  `eroeffnet`, M13 BTC-Lücke kein Ausfall, M14 fragliche Minuten nicht geprüft, M15 „…_gegen“ im Pool, M16 Kontrollen im Pool, M17 Urteil
  vor dem 08.11., M18 Tagesart am Fensterende, M19 dasselbe nur in den Kennzahl-Reihen, M20 Pool je Verschiebung neu, M21 Gleichstand
  umgekehrt, M22 Hälften gegen 0, M23 Teil B mit Tag e statt e−1, M24 „offen am Ende“ nicht heraus, M25 Datenschluss ignoriert, M26
  Coinbase-Seiten nicht berichtigt, M27 Grid in Teil A, M28 Bootstrap ohne Ziehung, M29 ohne 70-%-Regel, M30 TS ohne Mindestzahl Trades,
  M31 Schichten unter 9 zählen, M32 Holm über einen Test, M33 kein Rückgriff auf das Ereignis „limit“, M34 doppelte Verschiebungen
  bleiben, M35 Gruppen mit festen Gewichten, M36 6.9 über den Stichtag, M37 wirksame Verschiebung unter 24 h.
- Laufzeit bei Höchstgröße (erfundene Daten: 6 Coins × 162 Tage Minuten, `bars10` mit 6 Stücken je Minute, 49 Strategien mit 20.000 Trades,
  Teil B ab 2020): 48 s und 320 MB Spitzenspeicher. Auf dem Pi nicht gemessen, geschätzt 2–4 min; Grenze der geplanten Berichte 15 min.
- `hl_viz --selbsttest-lebt` 12 von 12 (jeder Lauf des Berichtsplans hat einen Debug-Eintrag); A7 70 von 70 grün (rc 0, 04:23:44–04:52:10, auf dem Vorpaket; danach nur `hl_volumen.py` geändert, sein Selbsttest im fertigen Paket 21 von 21); update.py aus 23.80 25 von 25, aus 23.79 25 von 25
  (das alte update.py übernimmt `hl_volumen.py` als weitere Datei; `KONZEPT_Volumen.md` kommt erst mit dem nächsten Paket auf den Pi, wie
  bei `KONZEPT_Akkumulation.md` mit 23.69 -- das neue update.py führt beide); Wiederherstellung 6 von 6 (mit 23.77).

**Als Nächstes:** 23.81 einspielen; Bericht 24.10. 21:15 hochladen (Teil B mit Urteil, Teil A vorläufig mit Datenlage und Spanne);
08.11. 09:15 das Urteil Teil A. Stufe 2 nur nach eigenem, vorab festgelegtem Plan-Punkt, nicht vor dem 25.10. und nicht vor dem Urteil.
Nächste neue Nummer U224.

## 3ρρρρ. Erster Bericht der Volumen-Studie und Poller-Kapazität ausgewertet; Teil A rechnet fragliche Minuten nicht mehr als Lücke (Entscheidung des Nutzers vor dem Urteil); Recorder-Fix U222: späte Trades ergänzen statt ersetzen, Wiederholungen nie doppelt (25.10. 02:48; Version 2026-09-23.82 · 7bb469f6d6, Opus 5.5)

**Berichte vom 24.10.** (Sammeldatei 25.10. 00:21, auf dem Pi Version 23.81 · 52636840b9):
- **Volumen-Studie 21:15:** Exit 0, 24,6 s. Aufzeichnung ab 31.08.2026 22:29 UTC (erste BTC-Bar), Spanne der Kennzahlen 29.09. 22:29 bis
  24.10. 19:15 UTC. Meine Sorge aus 3ππππ („Aufzeichnung erst ab Mitte September“) war unbegründet: Bis zum 08.11. hat Teil A 40 Tage.
- **Teil B (Urteil, Prüfsumme 46f6598f0b7c, 1.031 Trades 2020–23.10.):** B1 (RV) und B2 (TS) nicht belegt. `swing_ruecksetzer` mit TS
  **belegt**: D −0,346 R (90 %: −0,55 … −0,08), z −2,75, p Holm 0,035, q 0,035, Hälften gleich; Ø R unteres Drittel +0,24, oberes −0,11
  -- Einstiege nach Tagen mit ungewöhnlich viel aggressivem Verkauf liefen besser. Zufalls-Swing TS D +0,010 (−0,21 … +0,19): kein
  Markteffekt. Nach KONZEPT 8 („belegt nur in Teil B“) erst nach Bestätigung im Labor -- dort hat die Strategie bisher einen Trade;
  Stufe 2 nicht vor dem Urteil Teil A und nur mit eigenem Plan-Punkt.
- **Teil A (vorläufig) -- Datenproblem, das ich nicht vorhergesehen habe:** 5.082 von 6.851 Trades der Spanne ohne Kennzahl (74 %; im
  Pool 1.754 von 2.397). Ursache: fragliche Minuten (U222) als Lücke (KONZEPT 3c) -- je Coin 4,2–8,4 % der Minuten der Spanne, steigend
  (BTC 50–132 je Tag bis 14.10., 151–249 vom 20. bis 23.10.; XMR 15–50 -> 81–213; alle Coins gleichzeitig). Folgen: in 6.10 BTC und HYPE
  n 0, XMR 188, ETH 92; in den Verschiebungen nur ein Drittel der Trades mit Kennzahl (Median 209 von 631, Menge fest bei τ = 0) -- die
  Null etwa 1,7-mal zu breit, die Prüfung zu vorsichtig; Stand heute leer, 6.9 n 0, Grid 24 von 230 Coin-Tagen. **Eigener Fehler:** Regel
  3c festgelegt, ohne die Häufigkeit fraglicher Minuten zu kennen. Die Zwischenstände von Teil A sind deshalb nicht aussagekräftig.
- **Eigener Fehler 2:** Bei n 0 zeigte der Bericht ein Band (z. B. `elite_folgen` RV −3,71 … +2,87): Bootstrap-Ziehungen heben kleine
  Schichten durch Mehrfachziehung über 9 Trades. Kein Urteil betroffen (alle „nicht prüfbar“).
- **Kein Fehler:** 6.7 Welt A gleich Welt B -- Welt A wurde mit 23.76 als Kopie der Welt B samt Historie angelegt (hl_viz, „Welt A
  angelegt … als Kopie der Welt B“); der Abgleich sagt erst später etwas.
- **Beschreibend mit vollständigen Fremddaten** (alle 2.397 Pool-Trades): Binance-RV D −0,046 (90 %: −0,24 … +0,14), Coinbase-TS D +0,081
  (−0,09 … +0,22) -- beide Bänder ganz innerhalb ±0,25 Punkte.
- **Poller-Kapazität 08:50 (Modell und Messung, liest nur):** Bedarf 97.095 gegen rund 12.391 Konten-Abfragen je Stunde (Faktor 7,8;
  gemessen 250 Abfragen je Minute); alles außer Walen und Elite rund zehnmal seltener als eingestellt. 69.111 kleine Konten: 2 % des
  Positionswerts, 36 % des Bedarfs. 107 gesperrte Konten (Maschinen nach der Masterregel, Positionen nur alle 6 h, Rang 2): 36 % des
  Positionswerts (3,5 Mrd USD), bei dieser Last nie abgefragt, also nie im Snapshot. OI-Abdeckung 13–27 %; im letzten Snapshot 80 % der
  Positionen zu alt. Die Varianten im Modell bringen wenig (frisch 55 % -> höchstens 60 %). Grundlage für U220 (zweiter Termin 26.10.
  08:50); eingestellt ist nichts.

**Entscheidung des Nutzers 00:57** (Zeitstempel der Antwort): „Regel ändern, Urteil 08.11. (Vorschlag)“ und „U222 + Studie (Vorschlag)“;
einspielen frühestens am 26.10. (nach den Urteilen U108/U115/U110 vom 25.10.). Festgehalten in `KONZEPT_Volumen.md` 12.19–12.24, bevor
irgendein Ergebnis der neuen Regel gerechnet wurde (es gibt keins: die Studie läuft nur auf dem Pi).

**Gebaut -- Volumen-Studie** (`hl_volumen.py`, liest weiter nur):
- **Neue Regel (12.20):** Umsatz je Minute = max(Schluss × Volumen aus `bars`, Σ der 10-s-Stücke von Schluss × (Kauf + Verkauf)); Lücke nur
  noch „nicht aufgezeichnet“ (BTC ohne Bar); TS weiter aus `bars10`; Seitenprüfung weiter nur auf Minuten ohne Abweichung. Unverändert:
  Fenster, Vergleichszeiten, 70-%-Regel, Schichten, Pool, Nullmodell, Hälften, Holm/BH, Stichtag. Gilt für RV, TS, Spitze, Grid,
  Akkumulation und Stand heute. `bars10` je Minute mit Sortieren und `reduceat` zusammengefasst (Summen, Umsatz, Hoch, Tief), auch über
  die Lesestücke hinweg.
- **Alte Regel beschreibend (12.21)** unter den Hauptprüfungen: A1/A2 nach 3c mit D, Band, n, „mit Kennzahl … von …“ und beiden Pools,
  ohne Nullmodell.
- **Art der fraglichen Minuten (12.22)** je Coin und Tag als „fraglich (Minuten-Bar zu klein / 10-s-Stück zu klein) · Hoch/Tief enger“ --
  „Minuten-Bar zu klein“ trifft Hoch, Tief und Volumen, „10-s-Stück zu klein“ nur den Saldo eines Stücks; „Hoch/Tief enger“ wird über
  alle Minuten gezählt (Stops im Labor, U110). `hl_volumen.py --datenlage --db …` (ohne Trades, kein Zwischenstand von Teil A; die 28
  vollen Tage davor und der heutige bis 2 min vor dem Lauf; Debug „★ Recorder: fragliche Minuten in bars/bars10 …“; Berichtsplan 27.10.
  und 29.10. 09:20) zeigt dazu die Zähler des Recorders aus `meta`.
- **Band nur mit Punktschätzung (12.23).**
- Laufzeit 38,4 s und 338 MB Spitzenspeicher bei Höchstgröße (erfundene Daten wie 3ππππ; Sandbox allein, 02:45:34–02:46:13); 23.81 dort 48 s und 320 MB; auf dem Pi lief 23.81 am 24.10. auf den echten Daten 24,6 s.

**Gebaut -- Recorder U222** (`hl_recorder.py`; nach der unabhängigen Durchsicht überarbeitet, unten):
- **Schreiben:** Minuten-Bars und 10-s-Stücke erst `BAR_GRACE_S` = 2 s nach dem Ende; der Schreibtakt des Dienstes (10 s, Voreinstellung
  von `--flush-sec`; die Unit setzt keinen Wert -- **mein Fehler:** ich hatte die 30 s aus `Settings` angenommen) liegt 3 s hinter jeder
  Taktgrenze (:03, :13, … `flush_warte`). Die beendete Minute steht gut 3 s nach ihrem Ende fest, vorher 0–10 s je nach Lage des Takts.
  Scheitert das Schreiben, bleiben die Bars offen und kommen in der nächsten Runde (vorher waren sie verloren).
- **Halten:** Geschriebene Stücke bleiben im Speicher, bis die **Börsenzeit** (höchster angenommener Trade, nicht die Uhr des Pi; nach oben
  auf die Uhr + 60 s begrenzt) 15 min über das Ende ihrer Minute hinaus ist -- 10-s-Stücke so lange wie ihre Minute. Ein später Trade holt
  sein Stück zurück, die Zeile wird mit allen Trades vollständig neu geschrieben; Eröffnung und Schluss nach der Zeit der Trades. Was
  danach noch kommt, zählt nicht (`zu_alt`): so spät ist es fast sicher eine Wiederholung.
- **Entdoppeln:** je Coin nach (Zeit, tid), 20 min Börsenzeit (länger als jedes Halten), höchstens 300.000 je Coin.
- **Neustart:** Der Dienst schreibt seine höchste Börsenzeit bei jedem Schreiben und beim Beenden nach `meta` (`u222_hw_ms`). Der nächste
  Start zählt Trades bis dahin nicht (Wiederholung, für beide Tabellen gleich, gleich in welcher Reihenfolge); fehlt die Marke (Recorder
  23.81), gilt der Start des Dienstes. Die letzte Minute des vorigen Dienstes (`MAX(ts)` in `bars`) und ihre 10-s-Stücke werden beim
  ersten Schreiben mit ihrer Zeile zusammengeführt statt ersetzt.
- **Liquidationen** (userEvents) für ein schon geschriebenes 10-s-Stück werden nachgetragen (vorher verloren).
- **Zähler** in `meta`: `u222_seit` (UTC), `u222_spaet_min`, `u222_spaet_10s`, `u222_doppelt`, `u222_vor_start`, `u222_zu_alt`,
  `u222_zusammengefuehrt`, `u222_liq_spaet`, dazu `u222_hw_ms`. `u222_doppelt` > 0 nach einem Neuverbinden zeigt, dass Hyperliquid beim
  Abonnieren Trades wiederholt (weder in der Doku noch hier prüfbar -- die Sandbox erreicht die Börse nicht).
- **Bekannte Grenzen:** Stürzt der Recorder ab, fehlen die Trades der offenen Minute vor dem letzten Schreiben (bis 10 s plus die offene
  Minute); diese Minute zeigt dann „Minuten-Bar zu klein“ (ehrlich markiert). Beim ersten Start von 23.82 nach 23.81 (noch ohne Marke)
  gilt die Uhr des Pi als Grenze; geht sie dann falsch (Boot ohne Zeitabgleich) und wiederholt die Börse Trades, kann die letzte Minute
  des alten Dienstes einzelne Trades doppelt enthalten (Szenario S3 der Durchsicht, gegen den Umbau nachgerechnet). Die Historie bleibt, wie sie ist (keine Reparatur alter
  Zeilen) -- die Studie gleicht sie mit der neuen Regel aus.
- Für alle Leser von `bars`/`bars10` (Labor, Prognose, Charts, Liquidations-Ableitung, Studien): ab dem Einspielen vollständige Minuten,
  die beendete Minute gut 3 s nach ihrem Ende. Ein Leser, der eine Minute einmal liest (das Labor mit seinem Zeiger), sieht spätere
  Ergänzungen nicht -- das Risiko ist kleiner als vorher, als Bruchstücke eine Zeile auch verengen konnten.

**Unabhängige Durchsicht** (zweiter Agent, Code gegen U222 und KONZEPT 12, ohne meine Schlussfolgerungen; 01:22:57–01:59:00, Bericht
01:58:27, `b101/review/bericht.md`; ein schwerer Befund, zehn kleinere, zwölf Hinweise): Beide Änderungen laufen im Normalbetrieb richtig; das Zurücksetzen des Fixes lässt alle Recorder-Proben
scheitern; die Studie tut genau, was 12.19–12.24 sagen. Plausibilität des Befunds: alter Takt 10 s in zufälliger Lage und übliche
Verspätung 0,4–0,8 s ergeben 4–8 % überschriebene Minuten -- wie gemessen. Befunde und was daraus wurde:
- Recorder 1.1 (major, nur falls der Kanal wiederholt): Wiederholungen, die älter als das tid-Fenster sind, wären doppelt gezählt worden
  (tid nach 900 s vergessen, Bar bis 960 s gehalten; danach Zuschlag) -> tid-Fenster 20 min, alles nach dem Halten zählt nicht (`zu_alt`),
  Probe mit Wiederholung nach 930, 1000 und 3600 s.
- 1.2 Grenze „vor dem Start“ aus der Uhr des Pi (Boot ohne Zeitabgleich) -> Börsenzeit des vorigen Dienstes aus `meta`, letzte Minute aus
  `MAX(ts)`. 1.3 Reihenfolge der Wiederholung und 1.4 getrennte Entscheidung je Tabelle (fragliche Minute bei jedem Neustart) -> eine
  Entscheidung je Trade für beide Tabellen; Probe mit neueste/älteste zuerst. 1.5 Schluss bei zweitem Zuschlag und 1.6 Uhr springt
  zurück -> Zuschlag ganz abgeschafft (Zusammenführen einmal beim ersten Schreiben, danach vollständiges Neuschreiben), Halten an der
  Börsenzeit; Probe mit Uhrsprung. 1.7 tids wachsen bei Schreibfehlern -> Aufräumen in `finally`, Bars bleiben offen, Sicherheitsventil;
  Proben. 1.8 Lücken der Proben -> Proben erweitert (Liquidationen, Neustart in beiden Tabellen, Zufallsfolge mit Neustart).
  1.10 Takt 10 s statt 30 s -> Texte berichtigt. 1.11 Zähler -> getrennt, `u222_seit` in UTC. 1.12 Liquidationen -> nachgetragen.
  1.13 Schlüssel (Zeit, tid) wie in der Doku -> übernommen. 1.9 (Rechenzeit, Speicher) und 1.14 (Leser, Nebenwirkungen): kein Befund.
  Die Szenarien S1–S7 der Durchsicht auf dem Endstand nachgerechnet: S1, S2, S4–S7 richtig, S3 ist die oben beschriebene Grenze.
- Studie 2.1 (`--datenlage` zählte den Rest des heutigen Tages als „nicht aufgezeichnet“ -- die Messung vom 27./29.10. wäre verzerrt
  gewesen) -> endet 2 min vor dem Lauf, der Tag ist als „bis HH:MM“ markiert; Probe am Datenende. 2.2 Kopf der Tabelle („davon … Hoch/Tief
  enger“ stimmte nicht) und fehlendes „10-s-Stück zu klein“ je Tag -> berichtigt. 2.3 Lücken der Proben (Lesestücke, alte Regel, Spitze,
  Tief allein) -> V22 und V24. 2.4 Erklärtext -> Ursachen vor und nach 23.82. 2.6 leeres Lesestück -> abgefangen. 2.7 beide Pools der
  alten Regel -> gezeigt. 2.5, 2.8, 2.9: Hinweise, keine Änderung nötig.

**Nebenbefunde (am Code gesehen, auf dem Pi nicht gemessen):**
- **U225 -- Labor, Limit-Orders:** `_orders` setzt `geprueft_bis` auf den Beginn der laufenden Minute, auch wenn die Bar der eben beendeten
  Minute noch nicht geschrieben ist -- diese Minute prüft das Labor für Limit-Orders dann nie gegen die Kerze (Positionen gehen Bar für Bar
  und sind nicht betroffen). Nach dem Code geschätzt (Labor-Takt 15 s): bisher fehlte die Kerze in rund einem Drittel der Minuten
  (Schreiben 0–10 s nach dem Ende), ab 23.82 in rund einem Fünftel (gut 3 s) -- **etwas mehr Füllungen aus Kerzen bei Limit-Strategien**,
  in Welt A und B gleich. Für die Volumen-Studie ist keine Richtung zu erwarten (alle Drittel gleich betroffen). Die eigentliche Behebung
  (geprüft bis zur letzten vorhandenen Bar) ändert das Labor und gehört nach dem 08.11.
- **U224 -- Coinbase:** `hl_coinbase.py` schreibt `cb_bars` genauso (Minute vorbei -> aus dem Speicher, `INSERT OR REPLACE`); dieselbe
  Schwäche wie U222 ist dort wahrscheinlich, ohne zweite Tabelle aber nicht direkt messbar (Abgleich gegen die REST-Kerzen von Coinbase
  möglich). Nicht in 23.82.

**Proben:**
- `hl_volumen --selbsttest` 24 von 24: wie 3ππππ, dazu V5 neu (fragliche Minuten keine Lücke; nach der alten Regel 3 von 60 bestimmt, 4 von 60
  nicht), V6 erweitert (Art der fraglichen Minute, Umsatz nach der größeren Tabelle, Hoch enger, Zählung je Tag mit beiden Arten), V22
  (6 % Bruchstücke in `bars`: neue Regel 100 % bestimmt und gleich der Rechnung ohne Markierung, alte 5 % und von Hand nachgerechnet;
  Spitze mit fraglicher Minute; Positivkontrolle bleibt belegt), V23 (Band nur mit Punktschätzung, obwohl 133 von 300 Ziehungen ein D
  haben), V24 (120.000 Zeilen `bars10` über die Lesestücke gegen `np.add.at`, Tief allein enger), V21 (Ende zu Ende mit 6 % überschriebenen
  BTC-Minuten, alte Regel, Datenlage nach Art, `--datenlage` ohne Teil A und ohne Scheinlücke am Datenende).
- `hl_recorder --selbsttest-bars` 12 von 12: Frist und Takt (:03, :13, …), später Trade ergänzt Minute und Stück, doppelter Trade, Wiederholung
  nach 930/1000/3600 s und ein neuer Trade 947 s spät für eine gehaltene Minute, sehr später unbekannter Trade, Uhr springt vor und zurück,
  Schreibfehler, Liquidation in einem geschriebenen Stück, Sicherheitsventil, Neustart (neueste/älteste zuerst, ohne Marke wie nach 23.81),
  Zufallsfolge (20 min, 4.802 Trades, 6 % bis 10 min verspätet, 2 % doppelt, 53 Liquidationen, Neustart mit Wiederholung): jede Zeile
  gleich der Wahrheit, keine fragliche Minute. Übrige Recorder-Selbsttests (fills, start, sperre, gewicht, backup, v10, audit) grün.
- Mutationen 66 von 66 rot (02:20:30–02:28:11, 4 gleichzeitig; M44–M46, M52 und R07 nicht vergeben): M01–M37 wie 3ππππ (Muster von M03, M13, M14 an den neuen Code angepasst), neu M38 Band ohne Punktschätzung, M39 Umsatz
  nur aus `bars`, M40 fragliche Minute als Lücke, M41 Art vertauscht, M42 Hoch/Tief nicht verglichen, M43 alte Regel wie die neue, M47 je
  Tag aus allen fraglichen, M48 zweites Lesestück ersetzt das erste, M49 alte Regel mit dem größeren Umsatz, M50 Spitze mit der alten
  Lückenregel, M51 nur das Hoch verglichen, M53 `--datenlage` bis zum Tagesende; Recorder R01 später Trade nicht zurückgeholt, R02 nicht
  entdoppelt, R03 letzte Minute ersetzt statt zusammengeführt, R04 ohne Frist, R05 Wiederholung bis zur Marke gezählt, R06 Schluss ohne
  Zeitvergleich, R08 nicht gehalten, R09 Takt nicht an der Minute, R10 tids sofort vergessen, R11 tids kürzer als das Halten, R12
  10-s-Stück nicht zurückgeholt, R13 10-s-Stück nach eigenem Ende freigegeben, R14 Schreibfehler verliert die Bars, R15 Liquidation
  verloren, R16 Börsenzeit aus der Uhr des Pi, R17 ohne Sicherheitsventil, R18 Zusammenführen ohne die 10-s-Felder.
- A7 71 von 71 [ok], rc 0 (02:28:57–02:43:12, auf dem Vorpaket mit denselben .py-Dateien; Volumen-Schritt 17,1 s, Recorder-Schritt U222 0,3 s); update.py aus 23.81 26 von 26, aus 23.80 26 von 26; Wiederherstellung 6 von 6 (mit 23.77); `hl_viz --selbsttest-lebt` 12 von 12.

**Als Nächstes:** 23.82 frühestens am 26.10. einspielen; Datenlage 27.10. und 29.10. 09:20 hochladen (U222 nachher: neue fragliche Minuten
nur noch in der Minute eines Absturzes; die Zähler zeigen späte Trades, Doppelte und Wiederholungen); Poller-Kapazität 26.10. 08:50 (U220);
Volumen 01.11. vorläufig, **08.11. 09:15 Urteil Teil A** nach der neuen Regel. Nächste neue Nummer U226.

## 3σσσσ. Extrem-Wende (U226): Strategie aus einem Video nachgebaut -- Studie mit vorab festgelegtem, kalibriertem Urteil und zwei Strategien im TradeLabor (25.10. 13:24; Version 2026-09-23.83 · e512a7ab09, Opus 5.5)

**Wunsch des Nutzers** (09:47): „Hol dir das video von https://m.youtube.com/watch?v=grMDEn7QbJA. Und baue diese Strategie nach.“
YouTube war von hier aus nicht erreichbar (Abruf abgewiesen; ein Werkzeug zum Herunterladen ließ sich nicht installieren). Auf meine
Bitte hat der Nutzer um 10:26 das Transkript angehängt. Seine Wahl um 10:32 (Auswahl): „Studie und gleich ins Labor“, „Eine Hauptregel,
Rest beschreibend (Vorschlag)“, „Nur BTC 8h“.

**Die Strategie laut Video** („Range Deviation plus Ribbon Flip“): BTC auf 8-h-Kerzen. Im sichtbaren Chart von rund 765 Kerzen ist eine
Kerze rot, wenn ihr Hoch zu den höchsten 10 % gehört, blau, wenn ihr Tief zu den tiefsten 10 % gehört. Short, wenn seit dem letzten
bullischen Flip mindestens eine rote Kerze kam und dann die EMA 8 unter die EMA 89 fällt; Einstieg zum Schluss der Flip-Kerze; Stop 0,1 %
über dem höchsten Hoch der roten Kerzen; Long gespiegelt. Den Ausstieg lässt der Autor offen. Seine Zahlen (ohne Gebühren): 35 Signale
seit November 2021 (16 Long, 19 Short), von 34 erreichten 20 mindestens 1R; „perfekt“ über 700 %, laufen lassen rund 350 % -- fast alles
aus dem Long vom Januar 2023; gegen zufällige Einstiege bis 1R rund 5 Prozentpunkte besser, danach kein Vorteil.

**Vorab festgelegt** (`KONZEPT_Wende.md`, 10:41, vor jedem Code): Kerzen und Regeln, wo das Video offen ist (2.1–2.10); zwei Lesarten von
„höchste 10 %“ (A Rang = 90-%-Quantil, B Spanne = oberes Zehntel zwischen Tief und Hoch), gewählt allein durch das Nachrechnen der sechs
im Video genannten Trades und der Zahl 35 -- ohne Gewinnzahlen; Hauptregel Ziel 1R/Stop/120 Tage; H1 (Treffer gegen dieselben Trades zu
anderen Zeiten), H2 (Ø R nach Kosten), beide Hälften, Mindestzahl; beschreibend Video-Vergleich, Ausstiege, Stufen, Kontrolle „Flip ohne
Extrem“, Empfindlichkeit; Labor; Proben.

**Eigener Befund beim Bau (10:53):** Der vorab festgelegte H1 (Poisson-binomial über unabhängige Zufallseinstiege) meldete auf 80
driftlosen erfundenen Wegen in 10 % einen Vorteil -- Signale folgen dicht aufeinander (16 von 41 je Weg im Median während eines offenen
Trades). Umbau: alle Trades gemeinsam im Kreis verschoben (Überlappung bleibt) und Cluster-robuster t-Test; danach auf 200 Wegen 6,0 %
(10:58).

**Unabhängige Durchsicht** (zweiter Agent, nur Konzept, Code und Transkript, keine echten Kurse; 10:41:39–11:29:49, Bericht 11:29:31
`b102/review/bericht.md`, eigene Nullmärkte in `review/sim/`): 23 Befunde, davon 4 schwere -- alle umgesetzt (KONZEPT 8):
- **B1:** H1 wie vorab festgelegt nicht kalibriert: 11,6 % falsche Treffer bei α 0,05 auf realistischeren Nullmärkten (1-min-Wege,
  Schwankung log-AR(1); 704 Märkte). Zwei Ursachen: Überlappung, und Signale starten in anderen Schwankungslagen als beliebige Zeitpunkte
  (mit Zeitgrenze zählt das). Die gemeinsame Verschiebung allein kam auf 8,9–9,0 %, mit Stop-Abstand nach der Schwankung der 10 Tage vor dem
  Einstieg skaliert auf 5,7 % -> Skalierung und Kalibrierung (unten).
- **B3:** Das Urteil fällt auf der Stichprobe, auf der der Autor das Setup gezeigt (und vermutlich das Fenster eingestellt) hat ->
  Wortlaut „auf der Stichprobe des Videos bestätigt / nicht bestätigt / nicht prüfbar“; unabhängig sind die Signale vor November 2021
  (beschreibend, erwartete Richtung) und das Labor (dieselbe Prüfung ab 30 Labor-Trades in Welt B, ohne Zwischenblicke).
- **E1:** Der geplante Nulltest (Band 1–10 %) hätte B1 nicht erkannt -> Kalibrierung vorab festgelegt (≥ 1.000 Märkte, Varianten,
  Schranke 6,5 % = 5 % + 2 Standardfehler, sonst Quantil).
- **F1:** Dokument und Code wichen beim Bau ab -> KONZEPT 8 „Beim Bau geändert und kalibriert“, vor jedem echten Lauf.
- Kleinere: Einstieg von Trade 6 82.205 (aus den R-Stufen des Videos) und Toleranz 0,5 % für Trades 1 und 6 (A1); Grenzfälle b < i ≤ T,
  Stop „Block“ und Färbung je Kerze als Varianten (A2/A3); „kein Short zwischen Trade 1 und 6“ und „mit 1.050 Kerzen kein Signal“ als
  Prüfungen ohne Gewinnzahlen in der Wahl der Lesart (A4); **feste Grenze** -- im Urteil nur Signale, deren Flip-Kerze 120 Tage vor dem
  Datenende schloss -- und **Stichtag 27.10.2026 00:00 UTC** (B2/B6: vorher wären junge Trades nur mit schnellem Ausgang ins Urteil
  gekommen, und im Code fielen die Positionen später Trades in der Verschiebung zusammen); Trennschärfe ehrlich (B4); Cluster-t und
  mindestens 20 Gruppen (B5); „perfekt“ nur als Obergrenze im Nachhinein, gleiche Zeitgrenze für echte und verschobene Trades (C1);
  Befunde zur Prüfung im Bericht (C2); Labor (D1–D6, unten); Positivkontrolle mit gemessenem Effekt, Grenzfälle, Mutationen (E2).

**Kalibrierung** (`hl_wende.py --kalibrieren`, ganze Urteilsrechnung auf Nullmärkten wie in der Durchsicht; Sandbox, 2 Kerne,
11:38:13–11:47:11; Lesart A, wo nicht anders genannt): Anteil p < 0,05 bei H1 ohne Drift 6,4 % (1.000 Märkte, ± 1,4), Drift +0,05 %/Tag
6,8 %, −0,05 %/Tag 8,2 %, starke Regime 8,2 %, Lesart B 8,8 % (je 400, ± 2,2), ohne Skalierung 10,0 % -> **Schranke verfehlt, α_H1 =
0,038** (5-%-Quantil der Null-p ohne Drift 0,0387, abgerundet). Mit 0,038 auf denselben Märkten 4,9 / 5,5 / 7,2 / 5,5 / 5,5 %, gepoolt
5,5 %. **Gegenprobe mit frischen Märkten** (11:48:04–11:57:48, ab Seed 950.000, Schwelle nicht auf ihnen bestimmt: p < 0,038 ohne Drift 4,5 % (1.000 Märkte; p < 0,05: 5,7 %), Drift −0,05 %/Tag 3,2 %, starke Regime 4,5 %, Lesart B 4,8 % (je 400), zusammen 4,3 % (2.200)). „Bestätigt“ (H1, H2, Hälften, Mindestzahlen zugleich) auf Nullmärkten zwischen 0,8 und 3,8 % (Lauf 1 mit 0,05: 1,0–3,8 %; Gegenprobe mit 0,038: 0,8–2,0 %).
**Trennschärfe** (Endstand mit α_H1 0,038, gemessen 13:07:23–13:07:43): Auf 60 Nullmärkten wie in der Kalibrierung (26–59 Trades, Median 39; Gruppen 17–35) braucht H1 im Median 67 % Treffer (Spanne 54–81 %) bei p0 um 49 %. Mit einem Vorteil wie im Video (+5 Prozentpunkte über p0) liegt die Wahrscheinlichkeit für p < α_H1 im Median bei 9 % (Quartile 8–10 %), bei +9 Prozentpunkten bei 19 % (16–21 %; Normalnäherung mit der Streuung der verschobenen Trefferzahlen, wie im Bericht). „Nicht bestätigt“ ist also auch bei einem Vorteil wie im Video das wahrscheinliche
Ergebnis und heißt dann: nicht von Glück zu trennen, nicht: widerlegt.

**Zweite unabhängige Durchsicht des Endstands** (zweiter Agent, Code gegen das Konzept und die 23 Befunde der ersten, nur erfundene
Daten; 12:17:29–12:35, Bericht 12:34:48 `b102/review2/bericht.md`): kein schwerer Befund, 4 kleinere, 8 Hinweise. Keine Vorschau auf
künftige Daten; Long und Short auf einem gespiegelten Weg genau spiegelbildlich (37 Signale, 18.000 Ausgänge); die Verschiebung um τ = 0
gibt die echten Trades wieder (215 auf drei Wegen); 20 der 23 ersten Befunde erledigt, D5 und E2 teilweise (Goldprobe nur für die
Signale; Mutationen außerhalb des Moduls). Umgesetzt (KONZEPT 8.4):
- **M1:** Eine Flip-Kerze, die genau 120 Tage vor dem Datenende schloss, hatte keine Kerze zur Zeitgrenze -- ein Fehlschlag wäre still
  aus dem Urteil gefallen, ein Treffer drin geblieben. -> Grenze strikt; der Bericht meldet einen Trade ohne Ausgang im Urteil laut.
- **M2:** Schloss eine offene Position binnen 60 min nach dem Schluss der Flip-Kerze, stieg das Labor noch ein -- gegen 2.9 und gegen den
  Labor-Abgleich der Studie; die Tafel zählte es später als „verfallen“. -> Signal entfällt, gezählt als „ausgelassen (Position offen)“.
- **M3:** Die 1.050-Probe galt auch für eine Lesart, die Trade 6 gar nicht findet. -> nur bestanden, wenn Trade 6 mit 765 Kerzen gefunden
  ist. **M4:** „nicht nachgebaut“ jetzt auch im Kopf und in der Zeile des Urteils.
- **Hinweise:** Pool der Verschiebung nur mit erlaubten Einstiegen (volle Kerze, höchstens 60 min); ohne σ unskaliert und gezählt;
  jüngstes Signal auch ohne Trade (Video-Vergleich, Stand jetzt); Text zum Labor-Abgleich ehrlich (die Studie liest das Labor nicht);
  Grenzen des Labors und die Pause nach dem Ausstieg im Konzept. Dazu von mir: Ein Signal, das das Labor beim ersten Prüfen jenseits
  oder zu nah am Stop sieht, entfällt ganz (vorher konnte es bei späterem Kurs noch eingehen) -- wie in der Historie.
- **Nachprüfung der Schwelle mit dem Endstand:** 1.000 Nullmärkte ohne Drift, dieselben wie in der Gegenprobe (12:49:04–12:55:30): p < 0,038 bei 4,3 % (vorher 4,5 %), p < 0,05 bei 5,8 %, „bestätigt“ 1,8 %; die p-Werte verschieben sich im Median um 0,001 (die Spanne der Verschiebungen ist eine 8-h-Kerze kürzer), 2 Märkte wechseln die Seite der Schwelle -- die Schwelle 0,038 bleibt.

**Gebaut:**
- `hl_wende.py` (neu, 1.904 Zeilen): 8-h-Kerzen UTC 00/08/16 aus `sw_klines` (voll = mindestens 14 von 16 samt erster und letzter),
  EMA 8/89 und Flips als Zustandsautomat (Gleichstand ändert nichts, Flips wechseln sich ab), Schwellen beider Lesarten im Fenster W_T,
  Signal mit Stop, Einstieg zur Eröffnung der ersten 30-min-Kerze nach dem Schluss (nicht mehr als 60 min danach, nicht jenseits des
  Stops), Ausgänge Ziel 1R/2R/3R, bis zum Stop, Gegen-Flip (Ziel nur durchlaufen, nicht in der Einstiegskerze, Gleichstand -> Stop,
  Lücke -> Eröffnung, 120 Tage), schnelle erste Passage über Block-Tabellen, R vor und nach Kosten (Taker 0,045 %, Maker 0,015 %,
  1,5 bps, Funding aus `swing.db`), gemeinsame Verschiebung mit Skalierung, H1/H2/Hälften/Urteil, Nachrechnen und Wahl der Lesart,
  Studie mit Stichtag und Grenze, Bericht in 12 Teilen, Stand jetzt, Labor-Daten, Nullmärkte und Kalibrierung (`--kalibrieren N
  --variante V --teil k/m --seed S`), `--stand`, Selbsttest.
- `hl_labor.py`: Strategien `wende_rang@6fdc1dde` und `wende_spanne@c1d92651` (Gruppe Swing, nur BTC, fest 10.000 USD, `h` 8, Regeln
  samt `wende_v` 1 in der Kennung), `sig_wende` (Einstieg zum Marktpreis höchstens 60 min nach dem Schluss -- je Takt geprüft, nicht nur
  aus dem zwischengespeicherten Eingang --, einmal je Signal über `letzter_einstieg`, auch nach einem schnellen Stop; war beim Schluss
  der Flip-Kerze oder danach eine Position offen, entfällt das Signal (`pos_bis`); Stop und Ziel 1R ab
  der Mitte, `risiko_usd` in den Werten; **kein Einstieg jenseits oder näher als max(5 bps, halber Abstand am Schluss) am Stop** -- sonst
  ließe `_eroeffnen` einen Stop auf der falschen Seite still fallen (Durchsicht D1) -- das Signal entfällt dann ganz; verfallene und
  ausgelassene Signale getrennt gezählt), Eingang `E["wende"]`
  nur Signal und Lage je Lesart (je 60 s aus `swing.db`; Welt A kopiert den Eingang je Takt), Tafel, Bericht mit der Swing-Gruppe,
  Kennungsprobe streng (`WENDE_KENNUNGEN_2383`), Proben `--selbsttest-wende` (4), auch im ganzen Labor-Selbsttest.
- `hl_viz.py`: Debug „★ Wende: Extrem-Wende nach Video (BTC 8 h, U226)“ (`--studie`) und „Wende: Selbsttest“; Berichtsplan
  `u226-wende` 27.10. 09:40 (urteilt mit Datenende Stichtag). `install.py` (Kompilieren, Selbsttest-Schritt), `update.py`
  (`hl_wende.py`, `KONZEPT_Wende.md`), `version.py` (23.83, `hl_wende.py` in der Prüfsumme), README.

**Proben:** `hl_wende --selbsttest` 22 von 22 (29,7 s, 12:43:10–12:43:40, Endstand); `hl_labor --selbsttest-wende` 4 von 4; ganzer Labor-Selbsttest 103 Proben bestanden, rc 0 (12:44:22–12:48:51, Endstand, neben den Mutationen); Goldprobe der Signale
beider Lesarten (ändert ein Umbau die Signale, schlägt sie an: dann `wende_v` erhöhen, neue Kennung); Mutationen 78 von 78 rot (W01–W62, L01–L18 ohne L09 und L10). Erster Lauf 11:54:55–12:11:29 (67 Mutationen, 2 gleichzeitig): 64 rot; grün blieben W29 (Einstiegs-Toleranz 2 % statt 1,5 %), W45 (Zeitgrenze als Treffer) und L05 (Stop auf der falschen Seite angenommen) -- die Proben prüften die Toleranz nur von innen, hatten keinen verschobenen Trade mit Zeitgrenze und nur einen Kurs knapp jenseits des Stops, den schon der Rand abfing; Proben ergänzt, danach rot (12:12:53–12:13:22). Nach der zweiten Durchsicht 79 Mutationen (neu W54–W62, L16–L19) 12:44:20–13:06:08: 77 rot; L06 (Einstieg nicht vermerkt) blieb grün, weil die neue Regel „Position beim Schluss offen“ den zweiten Einstieg auch so verhindert -- die Probe prüft jetzt den gespeicherten Zustand (Einstieg vermerkt, nicht als ausgelassen gezählt), rot 13:07:08–13:07:09; L19 entfällt als gleichwertig (die Prüfung „Position offen“ kommt vor der Zählung „verfallen“). L09 entfällt aus demselben Grund (die Regel „Position offen“ und die Engine sperren schon); L10 ist im Labor gleichwertig, weil `sig_wende` das 60-min-Fenster je Takt selbst prüft (dieselbe Änderung in `hl_wende` ist als W31 rot); Laufzeit 2,3 s und 158 MB Spitzenspeicher auf einem erfundenen Weg voller Größe (6,8 Jahre 30-min-Kerzen, 23 Trades im Urteil, 4.383 Verschiebungen; Sandbox allein, Endstand, 13:07:20–13:07:23), auf Nullmärkten mit 34 und 36 Trades 2,9 und 2,8 s (vor der zweiten Durchsicht); auf dem Pi nicht gemessen (der Bericht nennt die Laufzeit);
`hl_viz --selbsttest-lebt` 12 von 12 (12:14:38–12:14:55); A7 72 von 72 [ok], rc 0 (13:08:16–13:23:59, auf dem Vorpaket des Endstands mit denselben .py-Dateien; Extrem-Wende-Schritt 28,7 s, Labor 97,8 s; erster Lauf auf dem Paket vor der zweiten Durchsicht 12:15:12–12:30:57 ebenfalls 72 von 72); update.py aus 23.82 28 von 28 (13:08:20–13:08:25, Vorpaket des Endstands), aus 23.81 28 von 28 (13:08:25–13:08:31, Vorpaket des Endstands); Wiederherstellung 6 von 6 (mit 23.77, 13:08:32).

**Einspielen und was dann kommt:** 23.83 enthält 23.82 (Recorder-Fix U222) und wird wie geplant **frühestens am 26.10.** eingespielt --
statt 23.82. Das Labor handelt ab dann nur neue Signale (das Short-Signal des Videos vom 16.10. ist vorbei); bei rund sieben Signalen im
Jahr kann der erste Labor-Trade Wochen oder Monate dauern. Der Bericht vom **27.10. 09:40** zeigt das Nachrechnen (welche Lesart die
Video-Strategie ist), das Urteil und alles Beschreibende; danach entscheidet der Nutzer, ob die andere Lesart im Labor weiterläuft. Mit
rund 35 Signalen im Video und der Grenze von 120 Tagen liegt die Zahl der Trades im Urteil nahe an der Mindestzahl (30 Trades in 20
Gruppen) -- „nicht prüfbar“ ist möglich (auf den 60 Nullmärkten der Trennschärfe 13-mal, „bestätigt“ dort 1-mal).

**Grenzen:** Die Datenquelle des Autors ist unbekannt (wir nehmen die Binance-USDT-Perps aus `swing.db`; kleine Kursunterschiede
erklären Abweichungen im Nachrechnen, dafür die Toleranzen). Stop und Ziel in derselben 30-min-Kerze zählen als Stop (vorsichtig). Das
Labor rechnet ab der Hyperliquid-Mitte, die Studie ab Binance. Die Kalibrierung gilt für Nullmärkte mit fester oder fehlender Drift und
log-AR(1)-Schwankung; echte Märkte haben Phasen mit starker Drift (einzelne Varianten mit 400 Märkten schwankten zwischen den Läufen um
bis zu 4 Prozentpunkte, gepoolt 5,5 %).

## 3ττττ. Debug-Nummern (U227): jeder Debug-Lauf hat eine feste Nummer -- Feld „Nr.“ wählt aus, „Ausführen“ startet, Schalter fragen nach (25.10. 15:23; Version 2026-09-23.84 · 736a851017, Opus 5.5)

**Anlass** (Nutzer 13:54): „Ich kann Sternchen Wende vom 27.10.49 nicht finden. Es gibt zwei Wende-Debug-Skripte. … Inzwischen sind es
wahnsinnig viele Debug-Skripte und man kann sie als Mensch kaum noch überblicken. … jedem einzelnen Skript eine Nummer gibt … Vielleicht
kann man auch in das Debug-Menü eine Funktion einführen, wie zum Beispiel, man gibt eine Zahl … und sagt ausführen. … ohne sämtliche
Dateien umzubenennen … So, dass es keine neuen Probleme gibt und gleichzeitig für mich als Menschen transparenter wird“.
„★ Wende vom 27.10. 09:40“ ist ein Termin im Berichtsplan, kein Eintrag im Menü: Er startet zu seiner Zeit den Debug-Lauf „★ Wende:
Extrem-Wende nach Video“ (jetzt Nr. 26) von selbst; der Bericht erscheint danach unter „Neue Berichte“. Die zwei Wende-Einträge im Menü
sind die Studie (26) und ihr Selbsttest (27). Sie gibt es erst seit 23.83 -- auf dem Pi läuft also vermutlich schon 23.83 (vom Nutzer
nicht bestätigt; der Plan sah frühestens den 26.10. vor).

**Wahl des Nutzers** (Auswahl; die Sicherungen der vier Dateien vor dem Bau entstanden danach, 14:03:32): „Heutige Reihenfolge, fest
(Vorschlag)“, „Auswählen, dann Ausführen (Vorschlag)“, „Jetzt als 23.84 bauen (Vorschlag)“.

**Gebaut** (`hl_viz.py`; keine Datei umbenannt, kein interner Name geändert):
- **Nummer = Stelle in `_DEBUG_REIHE`** (126 Namen): 1–124 die Reihenfolge des Menüs am 25.10.2026, 125 „Debug-Liste“, 126 ihr
  Selbsttest. Nur hinten anhängen; weggefallene Läufe behalten ihre Nummer („gibt es nicht mehr“). Schutz: `_DEBUG_REIHE_PRUEFPUNKTE`
  (Anzahl und sha1 der vergebenen Reihe; nach neuen Läufen kommt ein Prüfpunkt hinten dazu, alte bleiben) und 19 feste Stichproben im
  Selbsttest. Die Reihenfolge im Menü bleibt die von `debug_commands`.
- **Server:** `/debug/list` liefert „Nummer · Name“ (so zeigt auch eine ältere offene Seite die Nummern); neu `/debug/nummern` (Lauf ->
  Nummer, auch weggefallene, und die Schalter). **Schalter nimmt `/debug/run` nur mit `&ja=1` an** (Bestätigung der Seite) -- auch eine
  ältere offene Seite schaltet nichts mehr ohne Nachfrage um, sie bekommt „bitte die Seite neu laden“. Kopf der Konsole, der
  Handlauf-Datei und jedes geplanten Berichts „Nr. 26 · …“ (`debug_titel`); die Handlauf-Datei entsteht vor „fertig“; „Es läuft gerade
  ein geplanter Bericht (Nr. … · …)“ mit Nummer. Der Berichtsplan liefert je Termin die Nummern (`nrn`); die Seite zeigt „(Lauf Nr. 26)“
  bzw. „(Läufe Nr. …)“ sortiert und umbrechend.
- **Seite:** Feld „Nr.“ vor dem Menü (Handy: Ziffernblock, volle Breite), anfangs leer. Tippen wählt den Lauf im Menü und zeigt seinen
  Namen; beim Antippen ist der Inhalt markiert (Tippen ersetzt, aus „26“ wird nie „126“); Enter wählt nur aus. Eine unbekannte Nummer
  sperrt „Ausführen“ („Nr. 999 gibt es nicht“). Nach dem Start und bei einer Wahl im Menü von Hand ist das Feld wieder leer. Bis die
  Nummern geladen sind, ist „Ausführen“ gesperrt (vorher Getipptes gilt danach); scheitert das Laden, steht es in der Zeile. Nach einem
  Lauf bleibt „Ausführen“ gesperrt, solange im Feld eine nicht wählbare Nummer steht -- mit Grund in der Zeile. Die sechs Läufe, die
  etwas umschalten (`DEBUG_SCHALTER`: 17/19 Notbremse-Rückblick starten/stoppen, 28/29 Systemprotokoll an/aus, 93/94 Kalibrierung v2
  an/aus), öffnen eine Nachfrage auf der Seite („Ja, ausführen“ / „Abbrechen“; kein Browser-Dialog, den die Android-App nicht zeigt);
  Menü- oder Nummernwechsel schließt sie. „Als Datei“ heißt `nr26_wende_studie_…txt` -- nach dem Lauf, aus dem der Text stammt.
- **Lauf 125 „Debug-Liste“** (`hl_viz.py --debug-liste --db …`): alle Läufe nach Nummer, „[Schalter]“, „[Plan: …]“ = nächster Termin im
  Berichtsplan, weggefallene Nummern. **Lauf 126** = `hl_viz.py --selbsttest-debugnr`, auch Schritt der Installation (A7).
- Unverändert: Dateinamen unter `berichte/` (ihr Kopf trägt die Nummer), Ablauf und Sperren der Läufe, alle Datenbanken.

**Eigene Fehler beim Bau** (von den Proben gefunden, behoben, Proben ergänzt):
- Die Liste kürzte Namen zuerst am „--“; die Einträge 28 und 29 lauteten dadurch gleich -> ganzer Name bis 120 Zeichen.
- Die Wochenprüfung nennt 21 Läufe; ihre Nummern standen in einer nicht umbrechenden Zeile -- die Seite war auf dem Handy 695 statt 390 px
  breit (Browserprobe 14:09:28–14:09:36; 23.83 dort 390 px) -> umbrechend, feste Leerzeichen nur in „Lauf Nr. 26“.
- „Als Datei“ benannte die Datei nach dem Eintrag, der gerade im Menü steht, nicht nach dem Lauf, aus dem der Text stammt -> nach dem Lauf.
- Im ersten Entwurf gab das Ende eines Laufs „Ausführen“ frei, auch wenn während des Laufs eine unbekannte Nummer getippt war -> Freigabe
  nur, wenn das Feld leer ist oder den gewählten Lauf nennt.

**Unabhängige Durchsicht** (zweiter Agent, nur Diffs und Code, eigene Kopie, `/debug/run` abgefangen; 14:25:27–14:46:44, Bericht
`b103/review/bericht84.md`): 0 schwer, 4 mittel, 4 klein, 6 Hinweise -- serverseitig keine Regression, Escapes und Handy-Breite in
Ordnung. Umgesetzt bis zum Vorpaket (15:06:13):
- **M1:** Das Feld war mit der Nummer der Menüwahl vorbelegt („1“ nach dem Laden), Tippen hing an: aus „26“ wurde „126“ (im Browser
  nachgewiesen), aus „1“ „11“ (isolierter Selbsttest) -- der wahrscheinlichste Fehler im Alltag. -> Feld anfangs leer, leert sich nach dem
  Start und bei Menüwahl, Inhalt beim Antippen markiert.
- **M2:** Scheiterte `/debug/nummern`, fragten Schalter nicht nach (fail-open); der Server prüfte nichts. -> Server nimmt Schalter nur mit
  Bestätigung an; die Seite meldet „Nummern nicht geladen“.
- **M3:** Die Android-App (`MainActivity.kt` ohne `WebChromeClient`) zeigt keine JavaScript-Dialoge; `confirm()` gibt dort ohne Dialog
  „nein“ -- die Schalter wären in der App nicht mehr ausführbar gewesen. -> Nachfrage auf der Seite. Die älteren `confirm()`-Dialoge
  (Update, Wiederherstellen, Handbremse, Backup löschen) haben dasselbe Problem schon länger -> U228.
- **M4:** Der Selbsttest prüfte die Seite nur über Teilstrings (auch ein Escape-Fehler, der alles JavaScript lahmlegt, blieb grün). ->
  gezielte Marken und, wo `node` da ist, Syntaxprüfung aller Skripte der Seite; die Browserprobe deckt M1, M2, K1, K2 ab.
- **K1:** Enter setzte den Fokus auf „Ausführen“ („2“, Enter, „6“, Enter startete Lauf 2; gehaltenes Enter startete). -> Enter wählt nur
  aus, ohne Fokuswechsel, ohne Tastenwiederholung. **K2:** Vor dem Laden der Nummern Getipptes wurde ignoriert; „Ausführen“ startete dann
  Lauf 1. -> gesperrt bis zum Laden, Getipptes gilt danach. **K3:** Die Handlauf-Datei entstand erst nach „fertig“ (Rennen im Selbsttest
  auf langsamer SD-Karte). -> Datei vor „fertig“, der Test wartet zusätzlich bis 5 s. **K4:** Der Selbsttest hing an echten Terminen des
  Berichtsplans. -> fester Probeplan im Test.
- **Hinweise:** Prüfpunkte statt einer einzigen Prüfsumme und 19 feste Stichproben (H1); die Reihenfolge-Prüfung war eine Tautologie,
  die Zahl 6 fest -- jetzt die sechs bekannten Schalter plus die Regel „großes Schaltwort -> Schalter“ (H2); Wartezeiten brechen bei
  abgelehntem Start ab, kein `df` mehr im Test (H3); Grund für einen gesperrten Knopf in der Zeile (H4); Nummern sortiert, „läuft
  gerade“ mit Nummer, Schriftgröße (H6). Bleibt: lange Läufe fragen nicht nach (H5, Entscheidung -- mit M1 entfällt das Anhängen); der
  Bericht, den der Notbremse-Rückblick im Hintergrund selbst schreibt, hat keine Nummer im Kopf.

**Proben** (Sandbox, Endstand):
- `hl_viz --selbsttest-debugnr` 11 von 11 (15:05:21–15:05:22): jede Nummer genau einmal; Prüfpunkte und Stichproben; Menü „Nummer ·
  Name“; Schalter (die sechs bekannten, Schaltwort-Regel); `/debug/list`, `/debug/nummern`; **Schalter nur mit Bestätigung** (Probe:
  Lauf 125 als Schalter -- ohne `&ja=1` abgelehnt und nichts gestartet, mit gestartet; ein echter Schalter wird im Test nie geschickt);
  Kopf mit Nummer (Konsole, Handlauf-Datei, geplanter Bericht); Lauf 125 als eigener Prozess und beide Optionen laut `--help`;
  Berichtsplan (echter Plan: jeder Lauf mit Nummer; Probeplan: Termin nennt 26); Debug-Liste (Schalter, Termin, von zweien der
  frühere); Seite (Marken, `node --check` beider Skripte).
- Browserprobe `b103/browser_debug84.py` 26 von 26 (Paketstand, ab 15:07:34) (Handy 390 px und Desktop 1280 px, echte Seite mit den echten Antworten, `/debug/run`
  nachgebaut mit derselben Sperre wie der Server; dazu „Nummern kommen spät“ und „Nummern fehlen“).
- Mutationen: Python D01–D38 38 von 38 rot (15:04:41–15:05:05; u. a. Reihe eingefügt/gelöscht/vertauscht/doppelt, Einfügen samt neuer
  Prüfsumme, Prüfpunkt fehlt, neuer Lauf ohne Nummer, Nummern ab 0, Köpfe, Berichtsplan, Liste, Schalter fehlt oder falsch, neuer
  Lauf mit Schaltwort ohne Eintrag, Server ohne Sperre, Route ohne oder mit immer gesetzter Bestätigung, Seite ohne Feld, Bestätigung
  oder Markieren, Syntaxfehler in der Seite). Seite 17 von 17 rot (15:07:34–15:15:06, auf dem Paketstand: Nummer wählt nicht, unbekannte Nummer frei, ohne Nachfrage, ohne Bestätigung, Feld nach Menüwahl nicht leer, Nachfrage bleibt offen, Plan ohne oder unsortierte Nummern, nicht umbrechend, Enter startet oder springt auf den Knopf, Dateiname nach dem Menü, Knopf nach dem Lauf frei, kein Markieren, früh frei, früh Getipptes ignoriert, Feld nach dem Start nicht leer). Nicht gestellt: „Menü nach Nummer sortiert“, „Liste nach Menü sortiert“
  (heute gleichwertig) und „Datei nach fertig“ (der Test wartet bewusst).
- Übrige Selbsttests von `hl_viz` (`--selbsttest-last`, `-quellen`, `-v10`, `-notbremse`, `-lebt` 12 von 12) bestanden (15:05:21–15:05:45);
  die Browserprobe von 23.80 besteht auf 23.84; flake8 nur die bekannte Warnung.
- Paket: pruef84 8 von 8; update.py aus 23.83 27 von 27, aus 23.82 28 von 28, aus 23.81 28 von 28 (15:06:49–15:07:07, je mit der
  eingespielten Debug-Liste); Wiederherstellung 6 von 6 (15:06:41–15:06:43); A7 73 von 73 [ok], rc 0 (15:06:18–15:22:49, Vorpaket mit denselben .py-Dateien; Debug-Nummern 1,1 s; erster Lauf vor der Durchsicht 14:27:50–14:44:08 ebenfalls 73 von 73).
- Eigene Fehler in den Proben (nicht im Paket): erste Extraktion der Skripte für `node --check` falsch; pruef84 mit relativem Ordner
  aufgerufen (version.py nicht gefunden); die update-Probe suchte nach dem Umbau noch den alten Namen `_DEBUG_REIHE_FEST`.

**Einspielen:** 23.84 enthält 23.83 (und damit 23.82 mit U222). Läuft auf dem Pi schon 23.83: erst, wenn im Berichtsplan die vier
Termine von heute Abend (U108 19:30, U115 19:45, U110 20:00, U130 20:15) als „erledigt“ stehen, oder morgen -- ein Neustart des Dashboards
mitten in einem Termin bricht den laufenden Bericht ab (`berichte_pruefen` vermerkt einen Termin erst nach allen Läufen; er liefe danach
von vorn). Läuft dort noch 23.81: wie vereinbart frühestens am 26.10.

**Regeln für später:** `_DEBUG_REIHE` nur hinten verlängern -- nie löschen, umstellen oder dazwischen einfügen. Schlüssel in
`debug_commands` nicht umbenennen (der Lauf bekäme eine neue Nummer). Ein neuer Lauf: Eintrag in `debug_commands`, Name hinten an die
Reihe (nächste freie Nummer 127), danach einen Prüfpunkt hinten an `_DEBUG_REIHE_PRUEFPUNKTE` (alte nie ändern). Ein Lauf, der etwas
umschaltet, schreibt das Schaltwort groß und steht in `DEBUG_SCHALTER`. Claude nennt Läufe gegenüber dem Nutzer mit Nummer und Namen
(„Debug Nr. 26 · ★ Wende …“).

## 3υυυυ. Abendurteile vom 25.10.: Fusion bleibt im Schatten (U108), Kaskaden-Y nicht belegt (U115), Magnet-Test nichts belegt (U110), Makro × Kurs Teil A 0 von 45 (U130) -- Teil B fehlt (25.10. 22:17; Version 2026-09-23.84 · 736a851017, nur Dokumente, Opus 5.5)

**Grundlage:** Sammeldatei des Nutzers 22:06 (`berichte_2026-10-25_22-06_1d.txt`, 12 Berichte, alle Exit 0). Kopf: **Version
2026-09-23.83 · e512a7ab09** -- auf dem Pi läuft also 23.83 (bisher nur vermutet, 3ττττ). Berichte: Aktien, Ausblick, Chartbild
08:30; Volumen 09:15; Fusion, Kalibrierung v2, TradeLabor 19:30 (U108); Kaskaden 19:45 (U115); Magnet 20:00 (U110); Makro × Kurs
und Makro-Stand 20:15 (U130); Datentage 21:45. Geurteilt nach den vorab festgelegten Regeln (`KONZEPT_Fusion.md` 6, 4b.1/4b.4,
Abschnitt „U110“; `KONZEPT_Makro.md` 10). Nachgerechnet: alle z-Werte aus Mittel und Standardfehler, die Zählungen des
Magnet-Tests per Skript aus dem Bericht (36 Klassen, 21 urteilsfähig, Nullmodell 92 von 96), die p-Werte unter 0,10 in Makro × Kurs.

**U108 Fusion und v3** (4 h, nur live gestellte Blöcke: 587 aus 6 Coins in 130 Zeitblöcken; Standardfehler mit Zeitblöcken als
Klumpen):

| Kriterium | 25.10. | Urteil |
|---|---|---|
| 1. gegen die Basisrate | −0,0022 ± 0,0016 je Block (−1,4 SE; belegt erst unter −2 SE). Je Coin: BTC −1,3, ETH −1,2, HYPE −0,15, PAXG +0,4, XMR −0,8, ZEC −0,5 SE -- keine Verschlechterung | **nicht erfüllt** |
| 2. gegen jeden Experten | v1 +0,0059 ± 0,0032 (+1,8 SE) · v2 −0,0036 ± 0,0020 · v3 −0,0016 ± 0,0015 · Analog −0,0073 ± 0,0079 (n 220) -- kein ✗ | erfüllt |
| 3. v3 | 4 h: c 0,5 (bestes 1,0), OOF-Brier-Skill 0,0006 (n 1.107, 245 Zeitblöcke) > 0. Am 21.10. war das Tor zu (c 0, alle Gewichte 0): stabil über drei Wochenläufe sind die Gewichte damit nicht. Wo ungleich null, Vorzeichen wie am 14.10. (Trend lang −0,05 … −0,09, Funding +0,02/+0,03). 24 h: c 0 | nicht erfüllt |
| 4. Labor | „Fusion mit Kostenschwelle“ 16 Trades (16 Blöcke), Ø +0,025 %, t +0,1 (seit 11.10. kein weiterer geschlossener Trade; seit 17:27 ein ZEC-Short offen); „Prognose Fusion“ 50 (22), Ø −0,312 %, t −2,2 (seit 14.10. unverändert); Glück je 100 % | nicht erfüllt (Glück) -- Richtung wie erhofft |
| 5. Kostenschwelle (U162) | alle Coins 1,02 ± 0,07 (778 Blöcke, 130 Zeitblöcke); je Coin 0,84 (PAXG, −1,8 SE) … 1,14 (XMR, +1,6 SE) | E\|r\| trifft im Mittel |

- **Entscheidung (vorab festgelegt, 6): Kriterium 1 verfehlt → die Fusion bleibt im Schatten.** Die Arbeit geht bei der Information
  weiter (Stufe 2, U109–U111), nicht bei der Mischung.
- **Erwartung gegen Ergebnis:** Erwartet war (13.10., 6.1) „Schatten, weil v1 ✗ (rund 2,5 SE) und Kriterium 1 rund −1,8 SE“. Eingetreten
  ist Schatten, aber über Kriterium 1 (−1,4 SE); gegen v1 1,8 SE, also kein ✗. Hochrechnung vom 21.10.: −1,0 bzw. +1,35 SE.
- **Münzwurf (beschreibend; nach dem Urteil vorgesehen, 6.1):** Log-Verlust je Block auf allen bewerteten 4-h-Blöcken gegen
  ln 2 = 0,6931: Fusion +0,0056 … +0,0142, Basisrate +0,0084 … +0,0225, v1 −0,0021 … +0,0025 (BTC −0,0008, ETH −0,0021, HYPE +0,0011,
  PAXG −0,0014, XMR −0,0002, ZEC +0,0025). Der beste Experte liegt beim Münzwurf, Fusion und Basisrate darüber -- ohne Standardfehler,
  nur beschreibend. Trefferquote der Fusion (Urteile ab 2 Punkten): ZEC 38,7 % (93 Urteile, z −2,2), PAXG 39,5 % (38, z −1,3), die
  übrigen 47,6–51,6 %.
- **24 h** (beschreibend; geurteilt wird erst ab rund 60 live gestellten Blöcken je Coin, jetzt 16–22): nur live gegen die Basisrate
  −0,0136 ± 0,0065 ✓ (2,1 SE), gegen v1 +0,0193 ± 0,0066 ✗ (2,9 SE).
- **Kalibrierung v2** (Schatten, beschreibend): 4 h c > 0 nur in BTC (0,3), XMR (0,7), ZEC (1,0), Brier-Skill gegen c = 0 0,010 /
  0,017 / 0,018; ETH, HYPE, PAXG und alle 24 h c = 0.
- **Nach dem Urteil fällig (nächstes Paket, U108):** der Münzwurf als Vergleichszeile im Bericht (nur beschreibend, kein Experte); die
  Kostenschwelle der Fusion rechnet XMR wie das Labor seit 23.68 (6.1: „danach folgt sie dem Labor“); dazu U190.

**U115 Kaskaden-Gleichung** (Kalibrierung 25.10. 14:05, 47,5 Tage Heatmap; 1 h rund 1.130 Blöcke je Coin, 4 h 285, PAXG 563/122):
- **(1) Y in keinem der 12 Coin-Horizonte belegt.** Am nächsten, je drei von vier Bedingungen:
  - BTC 1 h: Y 0,25; gegen Y = 0 +0,0173 ± 0,0054 (3,2 SE); Placebo Y 0; Spiegel beim gleichen Y +0,0077 ± 0,0046 (1,7 SE) -- nicht belegt.
  - ETH 1 h: Y 0,25; +0,0072 ± 0,0024 (3,0 SE); Placebo Y 0; Spiegel +0,0062 ± 0,0046 (1,35 SE) -- nicht belegt.
  - ZEC 1 h: Y 0,25; +0,0032 ± 0,0020 (1,6 SE); Placebo Y 0; Spiegel +0,0067 ± 0,0023 (2,9 SE) -- nicht belegt.
  - ETH 4 h zwei von vier (1,9 SE; Spiegel 0,75 SE); alle übrigen Y 0.
  - Lesart (beschreibend, nachträglich): In BTC und ETH sagt die Karte die GRÖSSE der 1-h-Ausschläge besser voraus als der Zufallsweg
    (3 SE), ohne dass die SEITE belegt ist. Das ist das Bild des Störfaktors (Cluster nahe am Kurs, mehr Schwankung auf beiden Seiten),
    den der Spiegel abfängt. Für eine neue Runde (U109, Schwankung) eine Hypothese, kein Befund.
- **(2) vorhergesagt ≈ eingetreten:** 24 von 24 ✓ (12 Coin-Horizonte × ≥ 2 σ und ≥ 1 σ, out-of-fold, innerhalb 2 SE; PAXG 4 h jetzt mit
  122 Blöcken dabei).
- **(3) Richtung:** über alle Coins 374 Blöcke, 47 % ± 3 % (z −1,0); BTC 50, ETH 44, HYPE 41, ZEC 53 % -- kein Beleg. Familie
  „Kaskaden“: im Wochenlauf 21.10. ohne |z| ≥ 2 (3ζζζζ); der Bericht vom 25.10. enthielt die Familien nicht.
- **(4) Labor:** „Kaskaden-Kipppunkt“ 19 Trades (14 Blöcke), Ø −0,051 %, t −0,3; „Kaskaden-Fortsetzung“ 329 (141), Ø −0,087 %,
  t −3,2 (Stufe negativ); Glück je 100 % -- nicht belegt.
- **Urteil: nicht belegt** → kein Sprung-Teil für U116; der Treiber „Kaskaden-Asymmetrie“ bleibt im Schatten (Gewicht 0). Erwartung 4b.3
  („bei dünnen Coins eher sichtbar“) nicht eingetreten: am nächsten lagen BTC und ETH.

**U110 Magnet-Test** (Rechnung 25.10. 14:21, 47,5 Tage):
- **Belegt: nichts.** 21 der 36 Klassen sind urteilsfähig (mindestens 60 wirksame Fälle), keine hat einen Überschuss über 2 SE. Über
  2 SE nur HYPE 1 h mittel (+7,8 ± 3,4 Punkte, 50 wirksame Fälle, Spiegel 1,2 SE) -- wie in allen Läufen das Bild des Störfaktors.
- BTC 1 h groß (Kandidat seit 04.10.): Überschuss +4,3 ± 2,9 (1,5 SE), echt minus Spiegel +7,0 ± 3,5 (2,0 SE, nicht darüber), minus
  Placebo +7,5 ± 3,5 (2,1 SE), wirksam 94. Verlauf (überlappende Rechnungen): +4,2 / +6,3 / +7,7 / +5,4 / +4,3 Punkte am 04./11./14./21./
  25.10. -- nie über 2 SE.
- ETH 1 h groß: +5,3 ± 2,9 (1,8 SE), Spiegel 2,6 SE, Placebo 2,3 SE, wirksam 94 -- drei von vier, der Überschuss fehlt.
- Nullmodell an den Zufallsniveaus 92 von 96 Abständen innerhalb 2 SE.
- **Urteil: nicht belegt** → kein Treiber „Zug“. Erwartung vom 04.10.: BTC 1 h groß urteilsfähig ✓ (94 wirksam); HYPE 1 h mittel und
  ZEC groß blieben unter 60 wirksamen Fällen.

**U130 Makro × Kurs** (`KONZEPT_Makro.md` 10; BTC-Tagesschluss bis 24.10.; FRED mit Schlüssel, OI-Archiv vollständig, alle 15 Merkmale):
- **Teil A, Urteil: 0 von 45 belegt.** Benjamini-Hochberg allein 0; unkorrigiert p < 0,10: 3 (Zufall ≈ 4,5) -- Puell 1 T 0,019,
  Nettoliquidität 1 T 0,024 und 7 T 0,059 (Benjamini-Hochberg bräuchte beim kleinsten p höchstens 0,0022). Größtes ρ²: Puell 30 T 4,0 %
  (ρ +0,20, p 0,31). Wie am 06.10. (0 von 45, 10.5: „dasselbe Urteil ist zu erwarten“). DVOL, ETF-Fluss und Kurzfrist-Kostenbasis ohne
  erste Hälfte (nie belegbar).
- **Nachrechnung gegen `mk_stand`:** neu abweichend `ssr_pz` 10 von 21 Werten (Beispiel 05.10.: 29,16 → 29,62); DVOL und ETF je 21 „am
  offenen Tag festgeschrieben“ (seit 23.56). Ohne Folge fürs Urteil (SSR p 0,80 / 0,96 / 1,00). Ursache offen: Stablecoin-Bestand des
  laufenden Tags bei DefiLlama noch vorläufig, oder rückwirkende Korrekturen der Quelle → U229.
- **Teil B (Makro-Regime × 4-h-Prognosen) fehlt.** Das Werkzeug sollte bis 25.10. stehen, damit nach U108 ein erster Blick möglich ist;
  gebaut habe ich es nicht. **Eigenes Versäumnis.** Vorab festgelegt ist Teil B (10.2); belegbar wäre er frühestens Mitte Januar 2027.
  Nachholen mit dem nächsten Paket (liest nur).

**Übrige Berichte (beschreibend):**
- **Makro-Stand 20:15:** alle 60 Reihen innerhalb ihrer Frische-Grenze, FRED 21 von 21, OI-Archiv fertig (2.246 Tage). Signale (U126):
  belegt 4 von 337 Tests (Zufall allein 11–17). Live gegen Nachrechnung: 1.280 Werte, Signal gleich 1.280, Perzentil gleich 1.265;
  größte Abweichung miner:BTC 1j am 18.–20.10. (75–81 → 54–56 Perzentilpunkte). Vermutlich die Hashrate von Blockchain.com: Die
  gespeicherte Reihe endete am 21.10. noch am 14.10. und wurde fortgeschrieben (3ζζζζ), jetzt reicht sie bis 24.10.
- **Volumen 09:15:** Teil A vorläufig (Urteil 08.11.).
- **Datentage 21:45:** H1 Verbraucherpreise Faktor 2,44, H2 Arbeitsmarkt 1,89, beide belegt wie bisher.
- **Aktien, Ausblick, Chartbild 08:30:** Quellen ok; Farside 23.10. unvollständig (HODL fehlt).
- **TradeLabor 19:30:** 11.534 geschlossene Trades, netto −187.962,57 USD (Gebühren 74.582,80); keine Strategie bewährt, alle Glück 100 %.

**Was jetzt gilt:** Die Zusage bis 25.10. ist eingehalten und endet -- Fusion, v3, Kaskaden und v1-Lernen liefen bis zu den Urteilen
unverändert. Die Punkte „nach dem 25.10.“ (U220, U196–U205, U207) sind jetzt dran. 23.84 kann eingespielt werden: Die vier
Abendtermine sind gelaufen.

## 3φφφφ. Nacharbeiten nach den Urteilen: Teil B von U130 gebaut (Makro-Regime × 4-h-Prognosen), SSR-Nachrechnung aufgeschlüsselt (U229), Münzwurf-Zeile und XMR-Kosten der Fusion (U108), Abstand in SE bei Kriterium 5 (U190) (26.10. 00:28; Version 2026-09-23.85 · 30a5e44391, Opus 5.5)

**Anlass:** Wahl des Nutzers nach den Abendurteilen (3υυυυ): „Nacharbeiten als 23.85 (Vorschlag)“ -- Teil B von U130 nachholen, Münzwurf-Zeile
und XMR-Kosten der Fusion, U190, U229 klären; nur Berichte, keine Wirkung auf Prognose oder Labor.

**Teil B von U130 (`hl_makro_korr.py --teil-b`, Debug Nr. 127; Konzept `KONZEPT_Makro.md` 10.7, 10.7a, 10.7b):**
- **Vorab präzisiert** (10.7, 25.10. 23:18, gleich ins Projekt geladen), bevor das Werkzeug stand und bevor ein echter Lauf zu sehen war:
  - neun Teilungen der sechs Regime aus 10.2;
  - Regime am Tag t aus Werten von t − 2 (Kurzfrist-Kostenbasis t − 9, BGeometrics 7 Tage später), höchstens 3 Tage alt;
  - ein Maß: Brier-Vorsprung gegen die Basisrate, im Regime minus außerhalb; die Trefferquote nur beschreibend;
  - Bootstrap über ganze Tage; Placebo mit dem Kalender, um ganze Wochen zurückverschoben.
- **Unabhängige Durchsicht** (eigener Agent, nur Lesen; Ergebnis vor 23:35). Hauptbefund: Mit 162 Tests je Coin ist der Test für
  plausible Wirkungen praktisch blind (t ≲ 24·ε, ε = wahre Abweichung von der Basisrate). Dazu:
  - der Anlauf der Basisrate in `fusion_fall` (erste Wochen um mehrere Skill-Punkte verzerrt);
  - offene Wahlen (Urteilstermin, Mittentag, Höchstalter);
  - eine zu milde Kalibrierung;
  - Vergleichbarkeit der Placebo-Kalender, 10 Tage je Seite zu wenig, schwache Hälften-Regel;
  - eine Zerlegung des Maßes; der knappe Verzug.
  Meine erste Kalibrierung (23:23–23:26) bestätigte die Blindheit je Coin und zeigte das Bootstrap-p unter zäher Drift als ungültig.
- **Nachgeschärft** (10.7a, 23:35, ins Projekt geladen):
  - **Hauptfamilie gepoolt** (Abweichung von 10.2, vor dem ersten Lauf, nur mit Rechnung begründet): je Regime und Quelle die
    Krypto-Coins BTC, ETH, HYPE, XMR, ZEC zusammen, 27 Tests; je Coin (mit PAXG) nur beschreibend.
  - Anlauf: die ersten 28 Tage ausgelassen.
  - **Genau ein Urteil am 15.01.2027** (Prognosen bis 14.01. 23:59 UTC; spätere Läufe rechnen denselben Zeitraum); vorher beschreibend.
  - Mindestzahlen: je Seite 20 Tage in mindestens 2 Abschnitten, in jeder Hälfte 7 Tage je Seite.
  - Placebo: nur aus Zeiten mit 2 Jahren Vorgeschichte, nur Kalender mit gleich vielen Abschnitten (±1, sonst alle gültigen), Rang nach
    der Welch-Lage z.
  - Regel der Kalibrierung für das p im Benjamini-Hochberg; Zerlegung in Richtungs- und Sicherheitsteil.
- **Kalibrierung** (10.7b, 23:55:35–23:58:55; sieben Familien zu je 400 Welten, eine davon mit echten MVRV-Daten):
  - Placebo-p < 0,025 je Test in 1,9–2,5 %;
  - Welten mit falschem „alle drei“ 0,5–3,2 %;
  - Bootstrap-p je Test 26–40 % -- ungültig.
  **Eigener Fehler in 10.7a:** Nach ihrem Wortlaut hätte die Regel das Bootstrap-p gewählt; es bestand nur über das Placebo-Tor. Vor dem
  ersten echten Lauf ergänzt: Ein p muss je Test gültig sein (kein Beleg für zu viele Fehlurteile).
  **Entscheidung: das Placebo-p.** Teststärke: 8 Skill-Punkte in 46 % der Welten gefunden, 4 Punkte in 28 % (das Regime war in 153 von
  200 Welten prüfbar).
- **Prüfung auf den echten Kalendern des Pi** (Debug Nr. 128, `--kalibrieren-b-echt`, Berichtsplan 01.11. 10:00): künstliche Prognosen
  über die echten Regime-Kalender. Nicht bestanden nur bei Beleg für zu viele Fehlurteile; dann gilt für das Urteil Bonferroni (mit einem
  Paket vor dem 15.01.). In der Sandbox (Test-makro.db) bestanden, 51 s.
- **Bericht:** Kopf mit Regeln, Zeitraum, Anlauf, Hälften und Fingerabdruck des Werkzeugs; Übersicht der neun Regime (Tage, Abschnitte,
  Hälften, Verschiebungen, Grund, wenn nicht prüfbar); Tabelle der Hauptfamilie (Skill im Regime und außerhalb, Unterschied mit
  90-%-Intervall, Richtung/Sicherheit, z, Placebo-p mit K, Hälften, Treffer, Urteil); Zusammenhang der Kalender (|φ| ≥ 0,5); je Coin
  beschreibend.
- **Sichtprobe auf Testdaten** (künstliche Prognosen, Regime aus der Test-makro.db):
  - 127 Tage Blöcke: 99 ausgewertet, 6 prüfbare Tests; z = +4,65 bei Placebo-p 0,19 -- die Drift der künstlichen Güte, vom Placebo richtig
    eingeordnet;
  - 46 Tage (wie jetzt): 18 ausgewertet, nichts prüfbar;
  - 20 Tage: „noch im Anlauf“.
- **Erwartung für den 27.10.:** Der erste 4-h-Block in `fusion_fall` liegt um den 10.09., ausgewertet wird also ab etwa 08.10. Am 27.10.
  sind das rund 20 Tage -- noch nichts prüfbar (je Seite 20 Tage nötig). Prüfbar wird ein Regime erst, wenn es im Zeitraum wechselt.

**U229 (SSR-Nachrechnung; `KONZEPT_Makro.md` 10.8):**
- Der Bericht von Teil A schlüsselt jede archivierte SSR-Zahl nach Ursache auf: offener Tag, ältere Werte geändert, spätere Korrektur,
  Marktkapitalisierung, nur Perzentil.
- Nur der nachweislich offene Tag zählt als vorläufig (wie DVOL und ETF seit 23.56); jede andere Abweichung bleibt „abweichend“.
- Erster Befund mit dem Lauf am 27.10. 10:00 (Debug Nr. 56, im Berichtsplan zusammen mit Teil B).
- Dazu nennt der Bericht von Teil A jetzt den Verzug der Kurzfrist-Kostenbasis (BGeometrics 7 Tage). **Eigener Fehler aus 23.52:** Das
  Merkmal nimmt den Wert desselben Tags. Ohne Folge fürs Urteil, denn ohne erste Hälfte war es nie belegbar.

**Nacharbeit U108 (`hl_fusion.py`, wie in `KONZEPT_Fusion.md` 6.1 vorab festgelegt; 6.4):**
- Münzwurf-Vergleich je Coin und über alle Coins: Log-Verlust minus ln 2; nur beschreibend, kein Experte, ohne ✓/✗.
- Die Kostenschwelle rechnet die Gebühren wie das Labor (`hl_labor.gebuehr`), XMR also normal statt doppelt. Wirkt nur auf Anzeige,
  Payload und Bericht; das Labor rechnet seine Kosten selbst.
- Im Labor nur der Selbsttest-Schritt angepasst und ein veralteter Kommentar berichtigt.

**U190:** Kriterium 5 zeigt den Abstand zu 1 in Standardfehlern, aus den ungerundeten Werten, z. B. „0,81 ± 0,09 (−1,99 SE von 1; …)“.

**Debug und Berichtsplan:**
- Nr. 127 „★ Makro-Regime × 4-h-Prognosen (U130, Teil B)“, Nr. 128 „Makro-Regime: Prüfung auf den echten Kalendern“; Prüfpunkt
  (128, 407481a7…).
- Berichtsplan:
  - 27.10. 10:00: Teil B und Teil A mit U229 (Nr. 127, 56);
  - 01.11. 10:00: Prüfung auf echten Kalendern (Nr. 128);
  - 25.11. und 23.12. 20:15: Zwischenblicke (Nr. 127, beschreibend);
  - **15.01.2027 20:15: Urteil** (Nr. 127).

**Proben:**
- Selbsttest `hl_makro_korr.py`: 21 Prüfungen in rund 15 s -- Teil A 9, Teil B und U229 12:
  - Zahlen wie vorab festgelegt;
  - Kalender mit Verzug und Höchstalter;
  - Statistik von Hand; Bootstrap je Seite; Mindestzahlen auf beiden Seiten; Hälften;
  - Nulltest (30 Welten); Positivkontrolle (10 von 10); Falle „ein Wechsel“;
  - Placebo von Hand für 29 Tests (10 mit „gleiche Abschnitte“); Urteilstag mit eingefrorenem Zeitraum;
  - Ende zu Ende über die Dateien; SSR-Diagnose.
- Weitere Selbsttests: `hl_fusion.py --nulltest` bestanden (Münzwurf von Hand, XMR folgt dem Labor-Faktor, U190-Grenzfälle −1,99/−2,01 SE);
  `hl_labor.py --selbsttest` 103 ok; `hl_viz.py --selbsttest-debugnr` 11 von 11 (128 Läufe).
- **Mutationen 41 von 41 rot:**
  - K01–K26: Kalender, Statistik, Zeitraum, Placebo, Urteil, Familie;
  - U01–U05: SSR-Diagnose und Hinweis;
  - F01–F06: Münzwurf, Kosten, Abstand;
  - L01: Labor;
  - V01–V03: Nummern, Prüfpunkt, Plan.
  Lauf 23:59:58–00:09:27; K26 war zuerst grün und ist nach der Ergänzung der Probe rot.
- Paket: A7 73 von 73 [ok] (00:13:04–00:28:13; Makro × Kurs 14,3 s, Fusion 24,2 s, Labor 82,3 s); update.py aus 23.84 und aus 23.83 je 27 von 27; Wiederherstellung 6 von 6.

**Eigene Fehler beim Bau** (von Proben gefunden, behoben):
- die Regel-Lücke in 10.7a (oben);
- die Clopper-Pearson-Grenze lief bei großen n über (Ganzzahl zu groß für Gleitkomma; erster Lauf 23:47) -- jetzt in Logarithmen;
- gemischte Dezimalzeichen in der Ausgabe der Kalibrierung;
- die Mutation „Mindesttage nur im Regime geprüft“ blieb grün -- Probe für beide Seiten ergänzt;
- die Placebo-Probe von Hand traf zuerst nur den Fall „alle gültigen“ -- Welten mit langer Vorgeschichte ergänzt;
- künstliche Welten mit langer Geschichte lagen hinter dem Urteilsschnitt -- das Fenster endet jetzt fest am 09.11.2026.

**Unverändert:** Prognose, Fusion (Rechnung und Gewichte), v1, v2, v3, Kaskaden, Labor-Verhalten, alle Datenbanken (Teil B und U229 lesen
nur).

**Bestätigt vom Nutzer (26.10.2026 01:23, nach der Lieferung):** „Gepoolt lassen (Vorschlag)“ -- die Hauptfamilie von Teil B bleibt gepoolt, vor
dem ersten echten Lauf; „23.85 einspielen, Berichte abwarten (Vorschlag)“. Diese Zeilen (hier, UPDATE_PLAN, KONZEPT_Makro) kommen mit
dem nächsten Paket; KONZEPT_Makro ist im Projekt schon aktuell.

## 3χχχχ. U7b nachgeholt: kein Umschalten auf Kalibrierung v2 -- am 25.10. nicht geurteilt (eigenes Versäumnis) (26.10. 01:37; Version 2026-09-23.85 · 30a5e44391, nur Dokumente, Opus 5.5)

**Anlass:** Frage des Nutzers (26.10. 01:33): „Was ist jetzt aus der Gewichts versions Umstellung eigentlich geworden?“ Gemeint ist U7b:
die angezeigte P(aufwärts) von v1 auf die Kalibrierung v2 umstellen (Debug Nr. 93 „Kalibrierung v2 AKTIVIEREN“). Laut Plan war die
Entscheidung am 25.10. zusammen mit U108 fällig. In der Abendauswertung (3υυυυ) habe ich U108 geurteilt, U7b aber nicht -- **eigenes
Versäumnis**.

**Regel** (UPDATE_PLAN U7b, 05.10.):
- Besteht die Fusion (U108), wird auf die Fusion umgeschaltet, samt Pfad und Bias (U112).
- Sonst auf v2, wenn die direkte Bilanz v2 ≥ v1 zeigt (Trefferquote und Brier-Skill, mindestens 100 4-h-Fälle) und die Zuverlässigkeit
  stimmt -- ebenfalls mit Pfad; die Labor-Strategie „Prognose“ wird vorher auf das v1-Feld festgelegt.

**Nachgeholt mit den Berichten vom 25.10.:**
- **Fusion:** im Schatten (U108) -- dieser Weg entfällt.
- **v2 gegen v1 auf denselben 587 live gestellten 4-h-Blöcken:** v2 rund 0,0095 Nats je Block schlechter als v1. Abgeleitet aus U108:
  Fusion − v1 +0,0059 ± 0,0032, Fusion − v2 −0,0036 ± 0,0020.
- **Je Coin:** Log-Verlust auf allen bewerteten 4-h-Blöcken, v2 nur auf seinen Blöcken -- v2 in allen sechs Coins schlechter.

  | Coin | v1 | v2 |
  |---|---|---|
  | BTC | 0,6923 | 0,6982 |
  | ETH | 0,6910 | 0,6980 |
  | HYPE | 0,6942 | 0,6978 |
  | PAXG | 0,6917 | 0,7078 |
  | XMR | 0,6929 | 0,6997 |
  | ZEC | 0,6956 | 0,7036 |
- **Was v2 überhaupt nutzt:** In ETH, HYPE und PAXG ist v2 gleich der Basisrate (c = 0). Treiber wirken nur in BTC (c 0,3), XMR (0,7)
  und ZEC (1,0).
- **Die Zahl der Regel selbst** (direkte Bilanz: Quote und Brier-Skill) steht nur in der Dashboard-Kachel „Kalibrierung v2“, in keinem
  Bericht. Bei Abweichungen von wenigen Punkten um 50 % ordnen Log-Verlust und Brier dieselben Prognosen gleich. Dass die Kachel
  v2 ≥ v1 zeigt, ist nach diesen Zahlen nicht zu erwarten.

**Ergebnis nach der Regel: kein Umschalten.**
- v1 bleibt die angezeigte Prognose; v2 läuft im Schatten und als Experte der Fusion. Debug Nr. 93 nicht ausführen.
- Auch v1 liegt beim Münzwurf (Log-Verlust je Coin 0,691–0,696 gegen ln 2 = 0,693). Umzustellen gäbe es derzeit nichts Besseres.

**Neu U230:** Die direkte Bilanz v1/v2 (Quote, Brier-Skill, n, Enthaltungen) kommt auch in den Bericht „Kalibrierung v2: Stand“ (Debug
Nr. 89, Wochenprüfung), damit die Zahl der Regel nachlesbar ist; nächstes Paket. Zeigt sie wider Erwarten v2 ≥ v1, wird U7b neu vorgelegt.

## 3ψψψψ. Poller-Kapazität vom 26.10. ausgewertet (U220): Überlast unverändert; die gesperrten Konten -- 36 % des Positionswerts, seit Wochen nie abgefragt -- sind im Modell der größte Hebel und zugleich ein Bruch für die Heatmap; Gegenprobe Pool vergleicht Ungleiches (eigener Fehler aus 23.80) (26.10. 11:00; Version 2026-09-23.85 · 30a5e44391, nur Dokumente, Opus 5.5)

**Anlass:** Bericht „Nr. 21 · ★ Recorder: Poller-Kapazität“ vom 26.10. 08:50:55 (geplant, Exit 0, 0,8 s), hochgeladen 10:42 (Zeit der
Datei), ohne Text. Nach U220 der zweite Termin: Mit den Berichten vom 24.10. und 26.10. wird entschieden, was sich am Poller ändert.

**Vergleich mit dem 24.10. 08:50** (Sammeldatei vom 25.10. 00:21):

| | 24.10. 08:50 | 26.10. 08:50 |
|---|---|---|
| Rate des Pollers (Median der letzten 3 h) | 250/min | 223/min |
| Budget für Konten mit Position | 12.391/h | 11.053/h |
| Bedarf | 97.095/h | 96.385/h |
| Faktor gesamt (Rang 1) | 7,8 (10,1) | 8,7 (11,6) |
| frisch (Wert) im Modell | 55 % | 54 % |
| OI-Abdeckung BTC · ETH · HYPE · PAXG · XMR · ZEC | 27 · 26 · 26 · 21 · 13 · 22 % | 25 · 27 · 26 · 18 · 15 · 21 % |
| Snapshot: Positionen bekannt, davon zu alt | 127.892, 80 % | 91.465, 77 % |
| Laufzeit des Recorders | 10,6 h | 7,3 h |
| Gesperrte: Alter der letzten Abfrage (Median · 90 %) | 570,4 · 746,1 h | 619,4 · 795,1 h |

**Befund (beschreibend):**
- **Überlast unverändert:** Der Bedarf ist rund achtmal so groß wie das Budget; groß, Pool, mittel und klein kommen gut elfmal seltener
  dran als eingestellt. Die Stufen haben sich kaum verschoben (Wale 44 → 42, groß 2.152 → 2.083, mittel 6.747 → 6.926, klein 69.111 →
  69.927).
- **Rate 223 statt 250 je Minute** (80 % der eingestellten 280). Der Poller teilt sich die 1.080 Gewichtseinheiten je Minute mit den
  Order-Abfragen (fest 320), den Leaderboard-Ständen und den Fills (Reserve 216). Woran es diesmal lag, zeigt der Bericht nicht.
- **Modell gegen Messung:**
  - Die gedruckten Zeilen rechnen sich aus den Stufensummen nach (`b106/modell106.py` im Arbeitsordner der Sitzung).
  - Aus dem gemessenen Alter zurückgerechnet liegen die wahren Abstände bei 0,81–0,92 des Modells, an beiden Tagen in allen vier
    Stufen von Rang 1 ähnlich (groß rund 27 und 30 min statt 30 und 35, mittel 4,1 und 5,1 h statt 5,1 und 5,8). Annahmen: Der Versatz
    des stündlichen Schreibens von `last_poll` ist das Alter der Wale (33 bzw. 18 min), die Phasen sind gleichverteilt.
  - Das Modell ist also rund ein Achtel zu vorsichtig; dass Rang 1 gemeinsam gedehnt wird, bestätigt sich.
  - **Berichtigung 14:12 (eigener Fehler, gefunden von der unabhängigen Durchsicht beim Bau von 23.86):** Die Rückrechnung nimmt
    an, dass `last_poll` nur stündlich geschrieben wird. Konten mit ≥ 2 % Wertänderung, neu flache und erstmals abgefragte schreibt
    der Recorder aber sofort -- bei ihnen fehlt der Versatz, die Abstände kommen zu kurz heraus (um bis zu rund 28 min). Für
    „groß“ (30–35 min) kann das den ganzen Unterschied erklären, für „mittel“ und „klein“ (Stunden) nur wenige Prozent. Richtig
    ist also: Das Modell passt grob, bei langen Abständen ist es vielleicht etwas zu vorsichtig. Seit 23.86 misst der Recorder
    die Abstände selbst (3ωωωω).
- **Gesperrte Konten nie abgefragt:**
  - Das Alter ihrer letzten Abfrage wuchs zwischen den Berichten um genau 49,0 h -- die vergangene Zeit (48 h plus die Stunde der
    Zeitumstellung am 25.10.): keine einzige Abfrage.
  - Zuletzt abgefragt zur Hälfte vor dem 30.09., zu einem Zehntel vor dem 23.09. (Masterregel seit 22.09.).
  - Seitdem fehlen 107 Konten mit 3,5 Mrd USD -- 36 % des bekannten Positionswerts -- in der Heatmap. Die Absicht „gesperrte Konten
    bleiben als Liquidationsstufe in der Heatmap“ (Masterregel; 3ξξξξ) wurde nie erreicht.
  - Wer sie sind, zeigt erst ihre Abfrage: Die Masterregel sperrt jedes Konto mit über 300 Bündeln am Tag -- Market-Maker und Bots,
    aber auch Konten, die große Aufträge in vielen kleinen Teilen ausführen.
- **Gegenprobe Pool vergleicht Ungleiches -- eigener Fehler aus 23.80:**
  - Der Recorder zählt jede Adresse aus dem Pool, auch Pool-Konten, die als Wal oder Elite jede Minute drankommen. Das Modell zählt
    nur die Stufe „Pool“.
  - Schon 18 solche Konten im Minutentakt ergäben die gemessenen 10 % (24.10.: 11 %). Die Stufe selbst stimmt: aus dem Alter
    zurückgerechnet 1,8 h, im Modell 1,9 h.
  - Berichtigen: Das Modell zählt wie der Recorder (U231).
- **Der Anteil zu alter Positionen hängt an der Laufzeit:**
  - Der Recorder lädt beim Start keine Positionen. Der Snapshot kennt nur Konten, die seit dem Neustart abgefragt wurden: 127.892
    Positionen nach 10,6 h, 91.465 nach 7,3 h.
  - 77 % gegen 80 % ist deshalb kein Fortschritt; auch der 7-Tage-Median mischt Laufzeiten.
  - Für ein Vorher/Nachher taugen die OI-Abdeckung (ab 2 h Laufzeit) und die Abstände je Stufe, der Anteil zu alter Positionen nur bei
    gleicher Laufzeit (U231).
- **Neustart:** Der Recorder lief seit 7,3 h, also seit etwa 01:30. Das passt zum Einspielen von 23.85 kurz nach 01:25 (update.py
  startet ihn neu); die Version nennt dieser Bericht nicht, die Sammeldatei vom 27.10. zeigt sie.

**Varianten im Modell** (eigene Nachrechnung mit den gedruckten Stufensummen vom 26.10.; beschreibend):

| Variante | Bedarf/h | Faktor Rang 1 | groß alle | mittel alle | gesperrt alle | frisch (Wert) |
|---|---|---|---|---|---|---|
| so wie jetzt | 96.385 | 11,6 | 35 min | 5,8 h | nie | 54 % |
| kleine nur nach eigenem Handel und groß alle 5 min (beste des Berichts) | 44.758 | 5,2 | 26 min | 2,6 h | nie | 59 % |
| gesperrte in Rang 1 alle 30 min | 96.582 | 11,6 | 35 min | 5,8 h | 5,8 h | 60 % |
| gesperrte in Rang 0 alle 30 min | 96.582 | 11,9 | 36 min | 6,0 h | 30 min | 90 % |
| gesperrte in Rang 0 alle 30 min, kleine nach Handel, groß alle 5 min | 44.954 | 5,3 | 27 min | 2,7 h | 30 min | 95 % |

- Gesperrte in Rang 0 alle 30 min kosten 214 Abfragen je Stunde (1,9 % des Budgets). Die anderen Stufen verlieren 0,25 % ihres
  frischen Werts; der frische Positionswert wächst um zwei Drittel (+3,5 Mrd auf heute 5,3 Mrd USD; alle Coins zusammen, je Coin
  unbekannt). In Rang 1 würden sie mitgedehnt (5,8 h) und brächten wenig.
- Grenzen:
  - Modell; „frisch“ ist der Anteil am bekannten Positionswert, nicht am Open Interest.
  - Wohin die kleinen Konten bei „nur nach eigenem Handel“ gehen, bildet das Modell nicht ab: in die Gruppe der leeren Adressen, 4 von
    23 Plätzen je Runde.

**Folgen einer Änderung:**
- Die Heatmap lesen `hl_forecast.py` (Liquidationsstufen als Eingang der Prognose), `hl_labor.py`, `hl_kaskade.py`, `hl_anker.py`,
  `hl_magnet.py`, `check_treiber.py` und das Dashboard.
- Ändert sich ihre Zusammensetzung, ist das ab dem Einspielen ein Bruch für Prognose, Labor und Kaskaden -- auch im Fenster von Teil B
  (U130, Prognosen 08.10. bis 14.01.).
- Im Modell verändern die gesperrten Konten den frischen Wert um zwei Drittel, die Takte des Berichts um knapp ein Zehntel.

**Zur Entscheidung gestellt** (mit dieser Auswertung):
1. **Schatten und messen (Vorschlag):**
   - Gesperrte Konten in Rang 0 alle 30 min abfragen, ihre Liquidationsstufen in eine eigene Tabelle; Heatmap und ihre Leser bleiben
     unverändert.
   - Der Bericht zeigt je Coin, was sie hinzufügen würden (Wert, Nähe zum Kurs, Hebel), und je Stufe, wie viele Konten in 1 h und 24 h
     gehandelt haben. Der Recorder zählt, wie oft sich eine Position ohne eigenen Handel ändert.
   - Mit dem Bericht am 03.11. 08:50 über Aufnahme und Takte zusammen entscheiden -- ein Bruch statt zwei.
2. **Alles jetzt:** Gesperrte in Rang 0 alle 30 min direkt in die Heatmap (die Absicht der Masterregel), kleine nur nach eigenem Handel,
   groß alle 5 min. Im Modell frisch 54 → 95 %; Bruch ab dem Einspielen.
3. **Nur Takte jetzt:** kleine nur nach eigenem Handel, groß alle 5 min; im Modell 54 → 59 %. Gesperrte bleiben draußen.
4. **Nichts ändern:** nur U231 (Bericht berichtigen); die Absicht der Masterregel wird gestrichen.

**Entscheidung des Nutzers** (Antworten auf zwei Fragen, festgehalten 26.10. 12:04):
- Auf die erste Frage (eigener Text): „Wenn die gesperrten ohnehin marketmaker sind, ist die aussage begrenzt. Oftmals sind es hedge
  positionen. Daher würde ich die hochfrequenzkonten gesperrt lassen und nicht weiter abfragen und die verfügbaren Kapazitäten lieber
  aif die größten Konten verwenden“.
- Auf die Nachfrage, wie die Kapazität zu den größten Konten soll (drei Varianten mit Werten im Modell; „frisch“ ohne Gesperrte, heute
  84 %): **„Kleine nach Handel + groß ab 500 Tsd“**.

**Damit festgelegt (U220; Paket 23.86 zusammen mit U231 und U230):**
- **Gesperrte Konten werden nicht mehr abgefragt**, auch nicht mehr alle 6 h als Rang 2. Die Absicht „Liquidationsstufe in der Heatmap“
  der Masterregel entfällt. Am heutigen Zustand ändert das nichts: Sie wurden seit Wochen ohnehin nicht abgefragt.
- **Kleine Konten** (Positionswert unter 25.000 USD) nur noch nach eigenem Handel, sonst höchstens einmal am Tag -- wie leere Adressen.
- **„groß“ erst ab 500.000 USD** (bisher 250.000): Konten ab 500 Tsd weiter alle 3 min eingestellt; die 915 Konten zwischen 250 und
  500 Tsd laufen wie „mittel“ (alle 30 min eingestellt).
- Rückweg über die Parameter der Unit (`--hot-notional 250000`, `--klein-regelmaessig`).

**Erwartung im Modell** (Stufensummen vom 26.10., Gesperrte nicht im Nenner; vorab, vor dem Bau):
- Faktor für Rang 1 11,6 → 5,2: groß (ab 500 Tsd) 35 → 16 min, Pool 1,9 h → 52 min, mittel 5,8 → 2,6 h (die 915 Konten von 250 bis
  500 Tsd: 35 min → 2,6 h).
- Frisch 84 → rund 89 % des bekannten Positionswerts ohne Gesperrte. Gewonnen wird vor allem Aktualität bei den größten Konten und im Pool;
  die Abdeckung des Open Interest steigt nur wenig.

**Messung vor und nach der Änderung** (vorab festgelegt, beschreibend, kein Urteil):
- Vorher: die Berichte vom 24.10. und 26.10. (aus dem Alter zurückgerechnet groß 27 und 30 min, Pool 87 und 106 min, mittel 4,1 und
  5,1 h; OI-Abdeckung 7-Tage-Median am 26.10. BTC 26, ETH 27, HYPE 26, PAXG 21, XMR 17, ZEC 22 %).
- Nachher: Bericht „Poller-Kapazität“ am 28.10. und 30.10. 08:50, jeweils frühestens 24 h nach dem Einspielen (sonst der nächste Lauf von
  Hand).
- Verglichen werden:
  - die Abstände je Stufe, aus dem Alter zurückgerechnet, gegen das Modell desselben Berichts (vorher 0,81–0,92);
  - die OI-Abdeckung je Coin: Median der Snapshots ab 2 h Laufzeit nach dem Einspielen gegen den 7-Tage-Median davor;
  - gesperrte Konten: keine Abfrage (ihr Alter wächst mit der Uhr);
  - kleine Konten: nur nach eigenem Handel (Wartende und Abfragen der Gruppe der leeren Adressen).
- Der Anteil zu alter Positionen ist kein Kriterium: Er hängt an der Laufzeit (U231) und jetzt auch an der neuen Regel für kleine Konten.
- **Ergänzt 14:12, vor dem Einspielen:** gemessene Abstände je Stufe als Hauptmaß, die Rückrechnung nur beschreibend; Vorrang je
  Stunde und Gruppe C beschreibend (3ωωωω).

**Unverändert bis zum Einspielen von 23.86:** Recorder, Heatmap, alle Datenbanken.

## 3ωωωω. Paket 23.86: Poller wie entschieden (U220) -- gesperrte Konten nicht mehr abgefragt, „groß“ ab 500.000 USD, kleine Konten nur nach eigenem Handel, dazu nach zwei unabhängigen Durchsichten Vorrang für großen Handel und Pause nach Fehlschlägen; Abstände je Stufe gemessen; Statuszeile wie das Modell; Poller-Bericht berichtigt (U231); direkte Bilanz v1/v2 im Bericht (U230) (26.10. 14:12, Nachtrag 14:48; Version 2026-09-23.86 · c1d9c975ae, Opus 5.5)

**Anlass:** Entscheidung des Nutzers vom 26.10. 12:04 (3ψψψψ): Gesperrte bleiben gesperrt und werden nicht mehr abgefragt; die Kapazität
geht an die größten Konten -- „Kleine nach Handel + groß ab 500 Tsd“. Dazu U231 und U230, wie mit der Frage angekündigt.

**Recorder (`hl_recorder.py`, U220) -- Auswahl `due_addresses`:**
- Gesperrte Konten (Masterregel) werden **nie** gewählt, auch nie abgefragte. Bis 23.85 Rang 2 alle 6 h (bei Überlast nie erreicht), nie
  abgefragte über Gruppe B. `SPERRE_POLL_S` entfällt.
- **„groß“ ab 500.000 USD** (`Settings.hot_notional`, `--hot-notional`; bis 23.85 250.000): Konten von 250.000 bis 500.000 laufen wie
  „mittel“.
- **Kleine Konten** (unter 25.000 USD) in Gruppe C wie leere Adressen: nach eigenem Handel (`last_trade > last_poll`), sonst höchstens
  einmal am Tag (`KLEIN_TAGESPRUEFUNG_S`). Zurück mit `--klein-regelmaessig`.
- **Vorrang für großen Handel** (nach der ersten Durchsicht):
  - Eine leere oder kleine Adresse, die seit ihrer letzten Abfrage mindestens 25.000 USD gehandelt hat (Summe aus dem öffentlichen
    Trade-Feed, `addr_umsatz`), kommt in Gruppe A vor alle fälligen Konten von Rang 1. Der größte Umsatz geht zuerst.
  - Höchstens ein Zehntel der Runde (280/min: 2 von 23). Bei einem Ansturm ist das bis etwa ein Sechstel des Durchsatzes von Rang 1; Wale
    und Elite nie.
  - Vorgezogene Adressen bleiben zugleich in C, ohne doppelt gewählt zu werden: Bei Drosselung füllen Wale und Elite die Plätze von A,
    dann kommen sie über C dran (nach der zweiten Durchsicht).
  - Eine erfolgreiche Abfrage setzt den Umsatz zurück. `--vorrang-ab` (USD, 0 = aus).
- **Pause nach Fehlschlägen** (nach der zweiten Durchsicht):
  - Die erste Pause ist wie bisher der halbe Takt, höchstens 5 min; danach verdoppelt sie sich. Gedeckelt bei Walen und Elite auf 5 min,
    sonst auf 4 Takte, bei Konten nach eigenem Handel auf 6 h.
  - Leere und kleine Konten behalten ihren Handel bis zu 3 Fehlschläge lang als Auslöser, danach nicht mehr und ohne Vorrang. Bis 23.85
    ging der Auslöser nach 1 h 55 min verloren; ohne Deckel käme eine dauernd scheiternde Adresse mit großem Umsatz jede Runde wieder vor
    (3 Versuche je Abfrage, die Runde wartet).
- Die Schleife zählt die Konten je Stufe (stats `poller_stufen`).

**Recorder -- Messen und Anzeigen:**
- **Erfolgszeit** (`erfolg_at`): Zeit der letzten erfolgreichen Abfrage in diesem Lauf.
  - Daraus kommen die gemessenen Abstände und das **Alter im Snapshot**. Eine fehlgeschlagene Abfrage setzt `polled_at` für den nächsten
    Versuch neu und ließ alte Positionen bis dahin frisch aussehen -- seit Audit M4, gefunden von der zweiten Durchsicht.
  - Wirkt nur nach Fehlschlägen.
- **Abstände je Stufe gemessen** (`abstand_messen`, U231):
  - Abstand von Erfolg zu Erfolg je Stufe (vor der Abfrage), je volle Stunde. Nur Stunden, die nach dem Start begannen; nach einer Lücke
    nichts.
  - Die letzte volle Stunde steht in meta `poller_abstaende`.
- **Gesperrte ohne Wal-Zeitreihenpunkt** (`snapshot_whales`).
- **Statuszeile** (`poll_lag`):
  - „Auslastung“ wie das Modell: Bedarf von Rang 0 und 1 gegen die eingestellte Rate mal dem Anteil der Runde für Konten mit Position.
  - „überfällig“ = Gruppe A über ihrem Takt, „neu“ = Gruppe B ohne Gesperrte, aus der letzten Auswahl im Speicher.
  - Die Reihe `snapshot_meta.backlog` (auch der „Rückstand“ in `check_abdeckung`) springt beim Einspielen: neue Bedeutung, keine
    Verbesserung. Median und 90 % des „Datenalters“ enthalten weiter gesperrte und kleine Konten. Sie steigen nach dem Einspielen, ohne
    dass etwas schlechter wird.
- meta neu: `poller_vorrang` (vorgezogene Abfragen seit dem Start), `poller_abstaende`.
- **Rückweg über die Unit:** `--hot-notional 250000`, `--klein-regelmaessig`, `--vorrang-ab 0`. Gesperrte nur mit dem alten Paket.

**Bericht „★ Recorder: Poller-Kapazität“ (`check_system.py --poller`, Debug Nr. 21; U220, U231):**
- **Modell wie die neue Auswahl:**
  - Gesperrte ohne Bedarf und nicht im Nenner von „frisch“;
  - kleine ohne regelmäßigen Bedarf (zählen als nicht frisch);
  - „groß“ ab 500.000;
  - Schalter ohne Wert aus der Unit.

  Den Vorrang bildet das Modell nicht ab; der Bericht nennt seine Zahl je Stunde.
- **Gemessene Abstände je Stufe** (Recorder, letzte volle Stunde) gegen das Modell. Ein Verhältnis gibt es erst, wenn die Laufzeit zu
  Beginn der Stunde das Doppelte des größeren von Modell und Messung ist. Leere und kleine Konten nur beschreibend.
- **Gegenprobe Pool wie der Recorder** (eigener Fehler aus 23.80): jedes Pool-Mitglied, auch als Wal oder Elite abgefragt.
- **Rückrechnung aus dem gespeicherten Alter** nur noch beschreibend, mit Hinweis auf die Verzerrung.
- **Anteil zu alter Positionen** nur gegen frühere Läufe mit ähnlicher Laufzeit (± 25 %, mindestens ± 1 h; ohne den laufenden Lauf).
- **Neue Zeilen:**
  - die drei Gruppen der letzten Auswahl, Plätze der Gruppe C aus der eingestellten Rate;
  - wartende leere und kleine Konten;
  - Handel je Stufe in 1 h und 24 h;
  - Vorrang je Stunde;
  - die Formel der Statuszeile.
- **Varianten** gegen den neuen Stand. Berichtsplan 28.10. und 30.10. 08:50.

**U230 (`hl_kalib.py --stand --db`, Debug Nr. 89, auch in der Wochenprüfung):**
- Die direkte Bilanz der gespeicherten 4-h-Prognosen von v1 und v2 je Coin: Quote, Brier, Brier-Skill, n, Enthaltungen. Es ist dieselbe
  Rechnung wie in der Kachel (`score_forecasts`; die Kachel zeigt einen Zwischenstand, der Minuten alt sein kann).
- Dazu die Zahl der U7b-Regel: Quote und Brier-Skill v2 ≥ v1 bei je mindestens 100 Fällen. Verglichen wird wie in der Kachel, v2 nur
  über seine eigenen Fälle.
- Coins, in denen v2 jetzt nur die Basisrate ist (c = 0), sind markiert. Der Bericht nimmt das c des heutigen Modells, nicht das jeder
  einzelnen Prognose; die Zuverlässigkeit prüft er nicht.

**Unabhängige Durchsichten** (eigene Agenten, nur Lesen; erste 12:29–12:48, zweite 13:03–13:30):
- **Erste Durchsicht:**
  - **1 (mittel bis hoch) -- in meinem Entwurf:** Die kleinen Konten verdrängten in Gruppe C neue große Positionen leerer Adressen. In
    der Simulation der Durchsicht (200 leere Adressen eröffnen mit einem Handel groß):
    - 23.85: alle binnen 60 s abgefragt;
    - Entwurf, 1 Auslöser kleiner Konten je Sekunde: 58,5 % überhaupt;
    - Entwurf, 3 Auslöser je Sekunde: 20 %.

    → Vorrang. Probe P9: alle 200 binnen 2 Runden; ohne Vorrang 43 von 200.
  - **2 (mittel) -- in meiner Auswertung von 11:00:** Die Rückrechnung der Abstände nahm `last_poll` als nur stündlich geschrieben an.
    Konten mit ≥ 2 % Wertänderung, neu flache und erstmals abgefragte schreibt der Recorder sofort. → gemessene Abstände; Berichtigung in
    3ψψψψ.
  - **3:** Der Vergleich des Anteils zu alter Positionen enthielt den laufenden Lauf.
  - **4:** Eine fehlgeschlagene Abfrage verlor den Auslöser.
  - **5:** Eingefrorene Wal-Zeitreihenpunkte zur Laufzeit gesperrter Konten.
  - **6:** Texte: `check_report` „leer“ → „leer oder klein“; „alle 6 h“ in `check_sperre`, Dashboard-Hinweis und Kommentar; „4 von 23“ jetzt
    aus der Rate gerechnet.
  - **7:** Das U7b-Zeichen konnte bei reiner Basisrate anschlagen.

  Alles berichtigt. Bestätigt: Gesperrte werden nirgends mehr abgefragt, `hot_notional` wirkt nur im Poller, `poll_lag` rechnet wie das
  Modell.
- **Zweite Durchsicht (der Berichtigungen):**
  - **1 (mittel):** Bei Drosselung gingen vorgezogene Adressen ganz verloren, weil ich sie vorher aus C nahm. → bleiben in C (Probe P8b).
  - **2 (mittel):** Dauernd scheiternde Adressen kamen ohne Pause jede Runde wieder vor. → Pause und Ende des Auslösers (P10).
  - **3 (mittel bis niedrig):** Die erste angebrochene Stunde nach dem Start wurde als voll gemeldet. `polled_at` ist beim Start aus der
    Datenbank vorgeladen; Abstände über einen Neustart enthielten die Ausfallzeit. Die Reife-Regel des Berichts ließ Wale nach 2 min zu.
    → Erfolgszeit nur dieses Laufs, nur Stunden nach dem Start, Reife zu Beginn der Stunde mit dem größeren von Modell und Messung (P11,
    C21).
  - **4 (niedrig bis mittel):** Ausfälle waren in den Abständen unsichtbar (fehlgeschlagene Abfragen setzten `polled_at`); dieselbe
    Ursache im Alter des Snapshots. → Erfolgszeit (P12).
  - **5 (niedrig):** Mein Kommentar „groß bleibt geschützt“ übertrieb; der Deckel bindet bis etwa 1/6 des Durchsatzes von Rang 1.
    → berichtigt.
  - **6 (niedrig):** Zwei eingeschleuste Fehler blieben in den Proben grün: Umsatz auch bei Fehlschlag zurückgesetzt, Stufe nach der
    Abfrage. → Proben durch `poll_address` (P10, P12), Mutationen R31, R32.
  - **7 (klein, bleibt, beschrieben):**
    - Nie abgefragte Adressen (Gruppe B, die ältesten zuerst) bekommen keinen Vorrang.
    - Handel in Entdeckungs-Coins wird beim Neuverbinden nicht entdoppelt.
    - Bei teilweisem Erfolg (ein Dex scheitert) wird der Umsatz zurückgesetzt.
  - Bestätigt: kein doppelter Eintrag je Runde, Rang 0 nie verdrängt, Speicher von `addr_umsatz` begrenzt (etwa 130.000 Adressen), Groß-
    und Kleinschreibung kein Problem.
- Die Berichtigungen der zweiten Durchsicht sind nicht noch einmal unabhängig durchgesehen, sondern mit Proben und Mutationen belegt.

**Proben:** - `hl_recorder.py --selbsttest-poller` (neu, Schritt in A7) **16 von 16** in rund 17 s:
  - P1 Gesperrte nie; P2 „groß“ ab 500.000; P3 kleine nach Handel oder Tagesprüfung, mit `klein_nach_handel=False` wieder in A;
  - P4 Elite, Pool, Wal, Reihenfolge, Zählung je Stufe;
  - P5 Statuszeile gleich der Formel des Berichts (Bedarf 150/h von Hand), auch mit regelmäßigen kleinen Konten; P6 Befehlszeile;
  - P7 Simulation 2 h unter Überlast;
  - P8 Vorrang mit Reihenfolge nach Umsatz und Deckel; P8b Drosselung (10 je Runde);
  - P9 Gruppe C voll (3 Auslöser je Sekunde): 200 von 200 großen Eröffnungen binnen 2 Runden, ohne Vorrang 43 von 200;
  - P10 Pause nach Fehlschlägen (300, 600, 1.200, 2.400 s; nach 3 Fehlschlägen kein Auslöser und kein Vorrang mehr; Wal nach 30 s);
  - P11 volle Stunde, Lücke und angebrochene erste Stunde; Gesperrte ohne Wal-Punkt;
  - P12 erfolgreiche Abfrage durch `poll_address`.
- `check_system.py --selbsttest` **22 von 22**:
  - C14–C17 neu gefasst (Modell von Hand, Stufengrenzen und Schalter, Bericht Ende zu Ende, Quelltext des Recorders);
  - C18 Rückrechnung, C19 Gegenprobe Pool, C20 ähnliche Laufzeit ohne den eigenen Lauf, C21 Reife der gemessenen Abstände.
- `hl_kalib.py --selbsttest-bilanz` (neu, Schritt in A7) **5 von 5**: B1 Bericht = `score_forecasts` = Rechnung von Hand; B2 alte
  v2-Prognosen und Enthaltungen; B3 U7b-Regel mit Basisrate-Markierung; B4 ohne `--db`; B5 Aufruf wie im Debug-Lauf.
- Weitere Selbsttests grün: Recorder (fills, start, sperre, gewicht, bars, audit, v10, backup), `hl_watchdog`, `hl_viz`
  (`--selbsttest-debugnr`, `--selbsttest-lebt` 12 von 12, `--selbsttest-notbremse`), `hl_kalib --nulltest`.
- **Simulation gegen die echte Auswahl** (`b106/sim_poller86.py`, Kriterien vorab im Kopf, 12:23:30–12:24:06, nach den Berichtigungen
  wiederholt):
  - Überlast:
    - groß, Pool, mittel gegen das Modell 0,988 / 0,982 / 0,980;
    - Wale und Elite 65 s;
    - Gesperrte 0 Abfragen;
    - kleine nur nach Handel;
    - Gruppe A 1,000 des Modell-Budgets;
    - frisch 97,5 gegen 97,2 %;
    - Mutation „Modell von 23.85“ erkannt.
  - Ohne Überlast: alle Stufen im Takt; kleine mit Handel binnen 4 s.
  - Die Toleranz für lange Takte (Takt × 1,01 + 2 Runden) habe ich vor dem ersten Lauf festgelegt, wegen 23.80.
- **Mutationen 62 von 62 rot** (13:43:25–13:48:42):
  - R01–R34: Auswahl, Vorrang, Pause, Abstände, Statuszeile;
  - C01–C20: Modell und Bericht;
  - K01–K06: Bilanz;
  - V01–V02: Berichtsplan und Debug.

  Im ersten vollen Lauf (13:38–13:42) blieb R20 grün: Die Quelltext-Probe fand die Zeichenkette ein zweites Mal. Ich habe die Mutation
  auf die Verhaltensprobe P12 umgestellt; danach war sie rot.
- **Paket:**
  - A7 75 von 75 [ok], rc 0 (13:48:54–14:12:27, auf dem Vorpaket der Fassung von 14:12 mit der Prüfsumme 61a5df2d04; die gelieferte
    Fassung prüft der Nachtrag unten);
  - `update.py` aus 23.85 und aus 23.84 je 29 von 29 (13:50);
  - Wiederherstellung 6 von 6.

**Eigene Fehler beim Bau:** - **In meinem Vorschlag an den Nutzer** (Varianten „kleine nach Handel …“): Ich hatte nur notiert, dass das Modell Gruppe C nicht abbildet,
  und die Folge nicht gesehen. Ohne den Vorrang hätten die kleinen Konten neue große Positionen verdrängt (erste Durchsicht).
- **In meiner Auswertung von 11:00:** die verzerrte Rückrechnung der Abstände (erste Durchsicht; Berichtigung in 3ψψψψ).
- **In meiner ersten Berichtigung** (zweite Durchsicht):
  - Vorgezogene Adressen gingen bei Drosselung verloren.
  - Eine dauernd scheiternde Adresse wäre ohne Pause jede Runde vorgekommen.
  - Die Abstände nutzten das beim Start vorgeladene und bei Fehlschlägen neu gesetzte `polled_at`.
  - Die erste angebrochene Stunde galt als voll.
  - Die Reife-Regel des Berichts war zu mild.
- **In den Proben:**
  - C16 rechnete den Pool-Anteil von Hand zuerst ohne den Faktor der Dexe.
  - Eine Textprüfung teilte an der Kopfzeile statt an der Bedarfszeile.
  - Die Reihenfolge vorgezogener Adressen hing anfangs am Namen statt am Umsatz (von P8 gefunden).
  - Eine Einrückung in der Probe von `hl_kalib` war falsch (sofort gefunden).
- **Arbeitsweise:** Ein `python3 -c "import version"` im Projektordner legte `__pycache__` an (gleich entfernt). Die erste Durchsicht legte
  bei einem Lauf mit `-I` ebenfalls eines an und entfernte es selbst.

**Messung vorher/nachher -- ergänzt vor dem Einspielen** (zu 3ψψψψ; nach den Durchsichten, bevor es eine Messung mit 23.86 gibt):
- **Hauptmaß für das Modell nachher:** die vom Recorder gemessenen Abstände je Stufe (letzte volle Stunde) gegen das Modell desselben
  Berichts. Nur Stufen, bei denen die Laufzeit zu Beginn der Stunde das Doppelte des Abstands erreicht. Erwartet etwa 0,8–1,1: Ist
  Gruppe C nicht voll, bekommt A mehr als im Modell; der Vorrang nimmt A etwas weg.
- **Vorher/nachher der Abstände** nur beschreibend über die Rückrechnung. Ihre Verzerrung hängt an der Länge der Abstände.
- **OI-Abdeckung je Coin** wie vorab festgelegt.
- **Neu beschreibend:** Vorrang je Stunde, Größe der Gruppe C, wartende leere und kleine Konten. Zeigen sie, dass Gruppe C dauernd voll
  ist und kleine Konten lange warten, oder dass der Vorrang einen großen Teil von A nimmt, wird der Nutzer gefragt.

**Grenzen:**
- Kleine Konten mit kleinem Handel warten bei voller Gruppe C, bis ihr Handel der jüngste ist oder es ruhiger wird. Ihr Anteil am
  Positionswert ist 2 %.
- Der Vorrang zählt Umsatz, nicht Positionsänderung. Viel Hin- und Herhandel ohne große Position kostet ebenfalls Abfragen, höchstens ein
  Zehntel der Runde.
- Gesperrte Konten sind seit Wochen nicht in der Heatmap; daran ändert sich nichts.
- Die Heatmap ändert sich durch 23.86 über die Takte (im Modell frisch ohne Gesperrte 84 → rund 89 %), den Vorrang und das Alter seit dem
  letzten Erfolg. Das Datum des Einspielens ist ein kleiner Bruch für alle Leser der Heatmap (Prognose, Labor, Kaskaden, Teil B).

**Nachtrag 14:48, vor der Lieferung -- Texte nachgezogen (eigenes Versäumnis, nur Text):** Bei der Schlussdurchsicht nach dem Bau
fand ich Texte, die noch den Stand vor den beiden Durchsichten beschrieben. Die Fassung von 14:12 (Prüfsumme 61a5df2d04) wurde nie
geliefert.
- **Berichtsplan 28.10.:** Als Zweck stand „Abstände je Stufe aus dem Alter gegen das Modell“. Vorab festgelegt sind seit der Ergänzung zu
  3ψψψψ die vom Recorder gemessenen Abstände; die Rückrechnung ist nur beschreibend. Zweck und Kommentar jetzt wie vorab festgelegt.
- **Name von Debug Nr. 21:** nannte nur „Abstände aus dem Alter“; jetzt „vom Recorder gemessene Abstände je Stufe gegen das Modell,
  Vorrang nach großem Handel“.
- **README:** Es fehlten der Vorrang nach großem Handel (mit `--vorrang-ab`), die Pause nach Fehlschlägen, die kleinen Konten in der
  dritten Gruppe, das Alter seit dem letzten Erfolg und die gemessenen Abstände als Hauptmaß des Berichts. Jetzt im Abschnitt
  „Datenqualität“ und beim Bericht „Poller-Kapazität“.
- **Bericht:** Die Zeile „Vorrang nach großem Handel“ nennt jetzt den Schalter (`--vorrang-ab`; 25 Tsd USD ist der Standard). Eine
  andere Schwelle aus der Unit liest der Bericht nicht; die Zahl der vorgezogenen Abfragen misst der Recorder.
- Docstrings in `check_system.py`, Kommentar und Name des Selbsttest-Schritts in `install.py` entsprechend.
- Projekt-Ablage `DEBUG_NUMMERN.md` (Stand 23.84) nachgeführt: neu 127 und 128 (seit 23.85), Namen 21, 56, 57 und 89.

**Proben danach:**
- flake8 nur mit der bekannten Meldung (`hl_viz` F401); `hl_viz.py --selbsttest-debugnr` bestanden, `check_system.py --selbsttest`
  22 von 22 (14:23).
- Die Anker der 62 Mutationen treffen weiter je genau einmal -- keine setzt an einem geänderten Text an. Die Mutationen selbst liefen auf
  der Fassung von 14:12.
- Vorpaket `b106/vor86c.zip` (Prüfsumme c1d9c975ae): pruef 8 von 8; `update.py` aus 23.85 und aus 23.84 je 29 von 29
  (14:24:02–14:24:16); Wiederherstellung 6 von 6 (14:24:16–14:24:18); A7 75 von 75 [ok], rc 0 (14:23:57–14:48:07, Schrittliste gleich
  der von 13:48 bis auf den umbenannten Schritt der Systemdiagnose).

## 3ααααα. Paket 23.87: Volumenbalken im Live-Chart (U232, Wunsch des Nutzers 26.10. 15:14) (26.10. 15:57; Version 2026-09-23.87 · 4ce6da0c6e, Opus 5.5)

**Anlass:**
- **Frage 15:08:** „ist volumen inzwischen irgendwo einsehbar?“
  - Antwort: die Studie U221 als Bericht (Debug Nr. 22, Bericht vom 24.10. 21:15; Teil B geurteilt, Teil A am 08.11.).
  - Live-Volumen gab es nur als Kachel „Volumen 1 h“, als Stundenvolumen in der Infozeile und im Tooltip der Kerze.
- **Wunsch 15:14:** „Ich will direkt im Chart Volumenkerzen sehen“.
- **Zwischenmeldung an den Nutzer:** 23.87 enthält 23.86. Jedes Einspielen startet auch den Recorder neu, deshalb 23.87 statt 23.86
  einspielen, sonst spätestens am 27.10. früh (Poller-Messung 28.10. 08:50).

**Kriterien vorab** (`b107/kriterien87.md`, 15:20:17, vor dem ersten Code): V1 Lage und Höhe, V2 keine Kerze und keine Linie im Band, V3
Farbe, V4 gemischte Quellen, V5 Schalter, V6 Tooltip, V7 ohne Volumen, V8 keine Fehler und Handybreite, V9 Server. Mutationen: jede
Eigenschaft einzeln gebrochen → rot.

**Gebaut (`hl_viz.py`):**
- **Server -- Börse je Kerze `q`** (`_quelle`):
  - „hl“: eigene Hyperliquid-Bars (Raster unter 4 h, auch in „Fusion“).
  - „bnc“: Binance (Quelle Binance live und gespeichert; 4 h `klines30` bzw. Binance 4h; 1 Tag und 1 Woche `daily_bars`).
  - Im 4-h-Chart Binance bis zur ersten eigenen Kerze, danach die eigenen Bars (letzte 8 Tage).
- **Seite -- Balken im unteren Fünftel** (`VOL_ANTEIL` 0,2):
  - Die Preisskala reicht dafür nach unten weiter (lo = hi − (hi − lo) / 0,8); Kerzen bleiben darüber.
  - Linien und Marken (Liquidationsmarken, FVG, Kaskade, MAs, Schlüsselniveaus, Konfluenz-Zone, eingetretene Liquidationen) enden an der
    Oberkante des Bands statt am unteren Rand (11 Stellen). Sichtbar sind dieselben Linien wie bisher.
  - Farbe wie die Kerze (halbdurchsichtig), Höhe relativ zum größten Wert der Strecke.
  - Jede zusammenhängende Strecke gleicher Börse hat ihre eigene Skala: Binance handelt ein Vielfaches, ein gemeinsamer Maßstab ließe die
    eigenen Kerzen im 4-h-Chart verschwinden. Gestrichelte Trennlinie, Name und Höchstwert über dem Band.
  - `volBalken` rechnet ohne Zeichnen, damit der Selbsttest sie mit node prüfen kann.
- **Infozeile** „Volumen je Kerze: Hyperliquid“ bzw. „Binance ab …, Hyperliquid ab … (je eigene Skala)“.
- **Tooltip:**
  - Im Band: Volumen in Coin, ≈ USD und die Börse; nur die senkrechte Linie, kein Preis.
  - Über dem Band: das Volumen jetzt mit Coin und ≈ USD. Bisher ohne Einheit und unter 1.000 ganzzahlig, kleine Werte zeigten „0“.
- **Schalter** „Volumen an/aus“ neben „FVG“: Vorgabe an, im Browser gemerkt (`localStorage` `hl_vol`), Umschalten zeichnet ohne neue
  Anfrage.
- Legende und Erklärung (ⓘ) ergänzt.
- **Selbsttest** `hl_viz.py --selbsttest-volumen` (neu, Schritt in A7), Testdatenbank mit dem echten Schema, ohne Netz:
  - q je Weg, mit dem Volumen je Kerze von Hand (5 min, 4 h mit Wechsel an der ersten eigenen Kerze, 1 Tag, 1 Woche, Binance gespeichert und
    live über eine Attrappe der Kerzen-Schnittstelle, Fusion);
  - `volBalken` mit node gegen Werte von Hand (zwei Strecken, ohne q = hl, v = 0 ohne Balken, Mindesthöhe 1 px);
  - Merkmale der Seite (Schalter, Merken, Band, Tooltip, kein `H-B` mehr zwischen den Linien) und die Syntax.
- **README** (Live-Chart): Volumen je Kerze, Quellen, Skala je Strecke, Schalter, Hinweis U222.

**Proben:**
- **Browser-Probe** (`b107/browser_vol.py`, Playwright, echte Seite, Nutzlasten aus dem echten Code ohne Netz -- `b107/payloads87.py`) **78
  von 78**:
  - je Quelle und Raster (hl 1 min bis 1 Woche, Binance 5 min, Fusion 5 min und 4 h) Lage und Höhe jedes Balkens gegen eine unabhängige
    Rechnung in Python, der größte Balken je Strecke an der Oberkante, keine Kerze im Band, Farbe per Pixel, keine Fehler;
  - 4 h zwei Strecken mit Trennlinie und Infozeile;
  - Schalter ohne neue Anfrage, Skala aus/an, gemerkt nach Neuladen;
  - Tooltip im Band und darüber; ohne Volumen kein Band;
  - eine Marke unter den Kerzen im Tageschart (Preis in der Mitte des Bands, mehr als 3,5 % vom Kurs) zeichnet weder Linie noch Etikett;
  - Handybreite 390 px.
- **Mutationen der Seite 12 von 12 rot** (Verlängerung der Skala, gemeinsame Skala, Farbe, Schalter wirkungslos, Linien im Band, Versatz,
  feste Höhe, Tooltip, Band ohne Volumen, nicht gemerkt, ohne Neuzeichnen, Strecken ignoriert).
- **Mutationen gegen den Selbsttest 11 von 11 rot** (Server S1–S6, Seite J1–J5).
- Selbsttest 11 von 11; `--selbsttest-quellen` (Feldvergleich U166, jetzt mit q in allen drei Quellen) bestanden; flake8 nur die bekannte
  Meldung.
- **Vorpaket** `b107/vor87.zip` (Prüfsumme 4ce6da0c6e):
  - pruef 8 von 8;
  - `update.py` aus 23.86 und aus 23.85 je 30 von 30 (15:36:04–15:36:20; neue Probe `b107/upd_probe87.py` mit dem Selbsttest Volumen in
    der eingespielten Kopie);
  - Wiederherstellung 6 von 6 (15:36:25–15:36:27);
  - A7 76 von 76 [ok], rc 0 (15:35:22–15:56:58; Schrittliste gleich der von 23.86 plus der neue Schritt).

**Eigene Fehler beim Bau:**
- **Browser-Probe:**
  - Die erste Fassung der Prüfung „Linien enden am Band“ setzte die Marke nicht ins Band. Im Wochenchart liegen positive Preise nur am
    oberen Rand des Bands; die Vorbedingung schlug an. Umgestellt auf den Tageschart.
  - Die Probe stürzte bei einer Mutation ab, statt rot zu melden (Zustand nach einer roten Prüfung). Jetzt wird das Volumen vor dem
    Tooltip-Teil sicher eingeschaltet.
- **Selbsttest:** Die Mutation „Binance live ohne q“ blieb zuerst grün, weil der Weg ohne Netz nie durchlaufen wurde. Mit einer Attrappe der
  Kerzen-Schnittstelle ist sie rot.
- **Arbeitsweise:** `python3 -I` schaltet `PYTHONDONTWRITEBYTECODE` ab, dadurch entstand ein `__pycache__` im Arbeitsstand (gleich
  entfernt). Seitdem `-I -B`.

**Grenzen:**
- Angebrochene Kerzen zeigen weniger Volumen: die laufende ganz rechts, oft die erste links (der Zeitraum beginnt nicht an einer
  Kerzengrenze) und im 4-h-Chart die erste eigene Kerze nach der Trennlinie (die eigenen Bars beginnen 8 Tage zurück). Beim Kurs war das
  schon bisher so; beim Volumen sieht man es (Bild beim Bau).
- Das Volumen von Hyperliquid war vor U222 (23.82) in einzelnen Minuten zu klein.
- In „Fusion“ steht nur das Hyperliquid-Volumen (die Kerzen sind die eigenen); Binance und Crypto.com sind nicht addiert.
- Kein gleitender Mittelwert und keine Markierung ungewöhnlichen Volumens (RV der Studie U221) -- auf Wunsch ein eigener Plan-Punkt.
- Keine unabhängige Durchsicht durch einen zweiten Agenten: nur Anzeige, kein Rechenweg für Urteile, Prognose oder Labor.

**Einspielen:** wie gewohnt; enthält 23.86 und 23.85. Der Recorder ist gegenüber 23.86 unverändert, startet beim Einspielen aber neu. Für
den Bericht „Poller-Kapazität“ am 28.10. 08:50 also spätestens am 27.10. um 08:50 einspielen.

## 3βββββ. Paket 23.88: Prognosemärkte -- Kalshi, Polymarket und Hyperliquid HIP-4 nur lesend, Rückblick auf abgelaufene Märkte, vorab festgelegte Auswertung H1–H3 mit einem gemeinsamen Urteil, vor dem Urteil nur Zählungen (U235) (27.10. 20:23; Version 2026-09-23.88 · 95b9909a33, Opus 5.5)

**Anlass:**
- **17:06:** „Die Idee mit Kalshi und evtl Polymarket finde ich sehr interessant. Könnte man beide Quellen integrieren. Dort gibt es
  kurzfristige und langfristige Prognosen. Recherchiere was in Frage kommt und berichte“ -- Recherche als
  `RECHERCHE_Prognosemaerkte_27-10-2026.md` (auch im Projekt).
- **17:49:** „dann baue bitte einen neuen Abschnitt in das Projekt "Prediction Markets", ziehe alle verfügbaren Daten über die
  verfügbaren Prognosen und erstelle eine datenbank dafür, wo die Prognosen ausgewertet werden ähnlich wie bei den anderen Treibern um
  Ihre Vorhersagequalität zu prüfen. Falls sich alte Daten beziehen können und gegen die Kursentwicklung testen lassen können um Zeit zu
  sparen, also eine retrospektive Analyse, dann integriere diese auch. Falls du noch weitere Ideen für gute weitere Funktionen hast um die
  Richtung zu bestimmen, dann bringe diese Vorschläge vor.“ (Tippfehler berichtigt)
- Ablauf: Konzept vorab (17:56), unabhängige Durchsicht durch einen eigenen Agenten (27 Befunde: 4 kritisch, 15 wichtig, 8 klein),
  Nachtrag 13.1 mit den festen Regeln R1–R15 (18:40), Modul mit Selbsttest und Mutationen (18:58). Das Zip von 23.87 hat der Nutzer
  um 19:12 hochgeladen; geprüft als 23.87 · 4ce6da0c6e, ohne Code daraus auszuführen. Einbau ab 19:16.
- Zusage an den Nutzer: eingespielt wird erst **nach dem Poller-Bericht am 30.10. um 08:50** (jedes Einspielen startet den Recorder
  neu und störte die vorab festgelegte Messung).

**Kriterien vorab** (`b108/kriterien88.md`, 19:16:02, vor dem ersten Code der Einbindung): P1 Dienst, P2 Wirkung (kein Projektmodul,
nur `prognosemarkt.db`), P3 Server (JSON ohne NaN, 60 s Cache, Fehler mit Grund), P4 Abschnitt (sieben Reiter, nur offen und sichtbar,
R4 vor dem Urteil, „Echo des Spots, kein Signal“, keine Kauf- oder Verkaufswörter, Quelle und Zeitpunkt je Zahl, 390 px, keine
Skriptfehler), P5 Debug ab 129 und Berichtsplan, P6 Einbau, P7 Selbsttests, P8 Browser-Probe mit Mutationen, P9 Dokumente, P10
Vorpaket.

**Gebaut:**
- **`hl_prognosemarkt.py`** (neu, rund 4.600 Zeilen, nur Standardbibliothek):
  - Zeit und Kennungen (ET über `zoneinfo`, Polymarket-Slugs berechnet, Kalshi-Ticker), tolerante Parser je Quelle, Leiter →
    Verteilung (isotone Regression, Median, 16/84-%-Punkte), Spotmodell (driftfrei), Spotreihe mit kausaler Schwankung, log-HAR mit
    monatlicher Neuschätzung für H2, Statistik (studentisierter Block-Bootstrap über 7-Tage-Blöcke, Hälften am Median-Datum,
    gewichteter Holm, Spearman mit Permutation, Kalibrierung).
  - Speicher `prognosemarkt.db` (BEGIN IMMEDIATE; gleiche Live-Werte verlängern nur die vorige Zeile; Ergebnisse als Fassungen;
    Abrufprotokoll 90 Tage).
  - Abruf mit Takt je Quelle und Pausen (429 → 60 s bis 15 min, drei Fehler → 15 min bis 6 h); Hyperliquid mit **eigenem Deckel von
    20 Gewicht je Minute** (Nachtrag 13.2).
  - Live-Takt (Kalshi 15 min und Makro jede Minute, Tagesleitern 5 min, Polymarket Auf/Ab jede Minute und Leitern 5 min, HIP-4,
    Abschlüsse, Spot jede Minute, Wartung), Rückblick in Teilen mit Cursor (wartet auf den Stichtag), Erstlauf (Formatprüfung R15, setzt
    den Stichtag R2).
  - Auswertung nach Nachtrag 13.1: Zählung bis zur Freigabe (R3), Prüfungen vor dem Urteil (R12), ein gemeinsames Urteil (R5), danach
    Beschreibendes (R13); Schutz gegen ein zweites Urteil.
  - Berichte („Stand“ mit Erstlauf und Dienst, „Auswertung“), Nutzlast je Reiter ohne Ergebnisgrößen vor dem Urteil (R4), mit
    Spot-Echo zur Anzeige.
  - Dienst-Faden „prognosemarkt“ im Dashboard (Start nach 60 s; nicht für Selbsttest-Datenbanken; aus mit `HL_PM=0`); eine Ausnahme in
    einem Teil oder einer Runde hält ihn nicht an.
  - Befehlszeile: `--selbsttest`, `--mutationen`, `--erstlauf`, `--stand`, `--auswertung`, `--rueckblick N`, `--takt S`,
    `--nutzlast TAB`.
- **`hl_prognosemarkt_js.py`** (neu): Skript des Abschnitts unter `/prognosemarkt.js`; Reiter Überblick, Krypto, Makro, Ereignisse,
  Bilanz, Rückblick, Daten; fragt nur bei offenem, sichtbarem Abschnitt (höchstens einmal je Minute und Reiter); wichtigste Spalten
  vorn (Handy); fremde Texte immer über `esc`.
- **`hl_viz.py`:** Navigation „Prognosemärkte“, Abschnitt „PM Prognosemärkte“ nach dem Makro-Abschnitt, `/prognosemarkt` (Antwort-Cache
  60 s) und `/prognosemarkt.js`, Laden beim Aufklappen, `prognosemarkt_start` nach `makro_start`, Debug-Läufe **129–133** mit Prüfpunkt
  (133, `a3985f59e5f0af9df909e96f385ccfae46420d53`), Berichtsplan (30.10. 12:00, 31.10. 08:45, 01.11. 20:45, 03.11. 20:45; Stand und
  Auswertung in der Wochenprüfung), neuer Selbsttest `--selbsttest-prognosemarkt`.
- **`hl_recorder.py`:** `prognosemarkt` in den Nebendatenbanken der täglichen Sicherung (`BACKUP_NEBEN` und beide Muster).
- **`install.py`:** Syntaxliste, zwei Schritte (Modul-Selbsttest, Dashboard-Selbsttest), zwei Endpunktprüfungen.
  **`update.py`:** vier neue Projektdateien. **`version.py`:** 23.88, zwei neue Dateien in der Prüfsumme.
- **Dokumente:** README (neuer Abschnitt), `KONZEPT_Prognosemaerkte.md` (Nachtrag 13.2), `RECHERCHE_Prognosemaerkte_27-10-2026.md`
  (Berichtigung zum Hyperliquid-Gewicht), `KONZEPT_Ausblick.md` (Borri-Zitat: Querschnitt der Coins, nicht BTC über die Zeit; Fund
  aus der Bewertung vom 27.10.), UPDATE_PLAN, PROJEKTUEBERGABE. `KONZEPT_Notbremse.md` unverändert.

**Proben:**
- **Selbsttest des Moduls** (`hl_prognosemarkt.py --selbsttest`, ohne Netz) **89 von 89** (rund 25 s): Zeitachsen mit Sommerzeit,
  Parser je Quelle, Leiter, Spotmodell und Kausalität, Statistik von Hand, Nullprobe und Positivkontrolle des Bootstraps (200 Welten),
  Holm, Hälften, Urteil, Abruf-Pausen, Rückblick mit Cursor, Ende zu Ende gegen ein Ersatz-Netz, R4 in der Nutzlast. Neu beim Einbau:
  Ausnahme in einem Teil des Rückblicks (gezählt, nach 20 abgebrochen, Grund in `pm_meta`), Bericht „Stand“ mit Erstlauf und Dienst,
  Spot-Echo (vor der Mittelungsminute genau 50 %, Schwelle und Berührung gleich der Rechnung von Hand).
- **Mutationen des Moduls 30 von 30 rot** (8.2 und Nachtrag 13.1; 6 min).
- **Dashboard** `hl_viz.py --selbsttest-prognosemarkt` **12 von 12** (echte Anfragen an einen Server in diesem Prozess, temporäre
  Dateien): alle sieben Reiter ohne NaN, Überblick mit Ja-Kurs aus Geld und Brief, R4 vor dem Urteil und das Tor danach, fehlende und
  kaputte Datei mit Grund, Skript (node, keine Kauf- oder Verkaufswörter, Titel maskiert, nur bei offenem Abschnitt), Seite, Dienst aus
  im Selbsttest und mit `HL_PM=0`, kein Projektmodul importiert (P2), Debug-Läufe und Termine. **Mutationen dagegen 14 von 14 rot**
  (R4-Tor offen, Makro-Termine immer, Cache fehlt, Laden beim Aufklappen fehlt, Kaufwort, Titel unmaskiert, Abfrage ohne Prüfung,
  Fehler ohne Antwort, Syntaxfehler, Skript fehlt, `HL_PM=0` wirkungslos, Projektmodul importiert, Lauf fehlt in der Wochenprüfung,
  NaN in der Nutzlast).
- `hl_viz.py --selbsttest-debugnr` bestanden (133 Läufe, drei Prüfpunkte); `hl_recorder.py --selbsttest-backup` bestanden (B7 mit
  `prognosemarkt`).
- **Browser-Probe** (`b108/probe/probe.py`, Playwright, echte Seite; Nutzlasten aus dem echten Code gegen das Ersatz-Netz, ohne Netz;
  Stand A vor dem Urteil, Stand B nach dem Urteil): je Stand am Rechner (1.280 px) und am Handy (390 px) alle sieben Reiter, **ohne
  Befund**. Geprüft: kein „undefined“, „NaN“, „null“ oder „[object Object]“; Hinweis und Fuß in jedem Reiter; nichts ragt über den
  Abschnitt; Ja-Kurs und Spotmodell je Zeile gleich der Nutzlast; vor dem Urteil Zählung statt Urteil (R4), danach Urteil mit Zahlen;
  fremde Texte maskiert (Bilanz und Ereignisse); Ereignis mit Sprungmarke und Δ 1 h/24 h; Makro-Erwartung gegen die Nutzlast und
  vergangene Termine nach dem Urteil; sechs markierte Teile im Rückblick; Pause und Hyperliquid-Gewicht im Reiter Daten; keine Anfrage
  bei zugeklapptem Abschnitt; keine Skriptfehler. Bilder je Reiter angesehen (Spalten fürs Handy umgestellt: wichtige zuerst).
  **Mutationen der Seite 12 von 12 rot** (Skriptfehler, Scroll-Hülle ohne `overflow`, Urteilsspalte vor dem Urteil, fremder Text
  unmaskiert, Reiterwechsel lädt nicht, Abfrage auch zugeklappt, Hinweis fehlt, Kurs ohne × 100, Spalten vertauscht, Ereignistitel
  unmaskiert, Makrowert ohne Einheit, breite Tabelle ohne Hülle).
- **Vorpaket** (`b108/vor88/hl_liq_project.zip`, 115 Dateien in 133 Einträgen, Prüfsumme 95b9909a33):
  - `upd_probe88.py` **15 von 15** (20:23:42–20:24:53): Update einer 23.87-Installation mit dem `update.py` von 23.87 (rc 0, alle Skripte syntaktisch in
    Ordnung). Alle Dateien, die es kennt, und die zwei neuen `.py` als „weitere Dateien“ sind gleich dem Paket; die Dateien des Nutzers
    bleiben unverändert; die zwei neuen `.md` kommen erst mit dem nächsten Paket (erwartet). Version und Prüfsumme gleich dem Paket,
    Sicherung in `updates/vor_*`, kein `__pycache__`. In der eingespielten Kopie bestehen die Selbsttests Modul, Dashboard,
    Debug-Nummern und Backup. Die Wiederherstellung gibt wieder 23.87 · 4ce6da0c6e; ein zweites Einspielen (mit dem `update.py` von
    23.88) bringt nur die zwei `.md`.
  - **A7** (`install.py --selftest-isoliert`) **80 von 80 [ok]**, rc 0 (20:23:39–20:38:52, auf dem gelieferten Stand). Die Schrittliste ist die von 23.87 plus zwei Schritte und zwei
    Endpunktprüfungen. In der Bau-Umgebung fehlen `websockets` und `aiohttp` (kein Paketindex erreichbar); kein Schritt braucht sie.

**Eigene Fehler:**
- **Hyperliquid-Gewicht:** Recherche und Konzept 9 sagten, die HIP-4-Abfragen liefen über die Rangfolge des Recorders. Die lebt nur
  im Recorder-Prozess; die Prognosemärkte laufen im Dashboard. Berichtigt mit eigenem Deckel (Nachtrag 13.2, Recherche).
- **Dienst hätte still sterben können:** Eine Ausnahme in einem Teil des Rückblicks (etwa ein unerwartetes Feld) wäre aus der Schleife
  gefallen und hätte den Faden beendet -- ohne Spur und für alle Quellen. Beim Einbau beim Lesen gefunden; jetzt zählt sie als Fehler des
  Teils (nach 20 in Folge abgebrochen mit Vermerk), und die Runde fängt alles Übrige ab. Neue Proben im Selbsttest.
- **Browser-Probe:** Die erste Fassung meldete Falsches -- die Kopfzeilen stehen per CSS in Großbuchstaben, „★“ steht auch im
  Erklärungstext, „belegt“ steht im Hinweis. Umgestellt auf Text ohne Gestaltung und die Tabellenzellen; die Seite blieb gleich.
- **Seite:** Teile ohne Liste zeigten „100,0 % (0 von 0)“ Abdeckung; jetzt „—“.
- **Mutation ohne Wirkung:** „Zahl ohne Format“ (fehlende NaN-Prüfung) blieb grün, weil der Server nie NaN sendet -- gleichwertig, nicht
  aufgedeckt. Ersetzt durch Werte gegen die Nutzlast je Zeile und zwei echte Mutationen (Kurs ohne × 100, Spalten vertauscht).
- **Probe-Daten:** Die virtuelle Uhr des Ersatz-Netzes lief der echten voraus; die Live-Kurse lagen „in der Zukunft“ und fielen in der
  Anzeige weg. Behoben in den Probe-Daten, nicht in der Seite.
- **Lücke der Browser-Probe:** In den ersten Probe-Daten waren die Reiter Ereignisse und Makro leer; ihre Tabellen liefen also nie im
  Browser. Beim Ansehen der Bilder bemerkt; ergänzt (Ereignis mit Sprung und Sonderzeichen, Makro-Leiter, vergangener Termin) mit zwei
  weiteren Mutationen.
- **Bericht „Stand“:** Die Kopfzeile nannte „Median ms“, gerechnet wird der Mittelwert; Teile ohne Schritt hießen „läuft“. Berichtigt
  („mittlere Dauer“, „wartet“).
- **Arbeitsweise:** Der Probe-Server legte eine `forecasts.db` im Projektordner an (Standardablage von `hl_forecast` ohne Unit); vor dem
  Packen entfernt, die Probe setzt jetzt `HL_FORECAST_DB`.

**Grenzen:**
- **Kein Endpunkt war erreichbar** (Bau-Umgebung). Alle Formate stammen aus Dokumentation und Spiegeln; der Erstlauf auf dem Pi prüft sie.
  Weicht etwas ab, steht es vor jeder Auswertung als Nachtrag im Konzept. Gut möglich, dass Parser nach dem Erstlauf nachgezogen werden
  müssen.
- **Nicht gebaut** (Konzept 13.2): Vorwärtsrunde R11, Ausblick-Zusatz und „Markt gegen eigene Prognosen“, HIP-4 gegen `markPx`, einige
  beschreibende Größen, drei angekündigte Mutationen, ein Lebenszeichen in `check_system`.
- **Spot-Echo** nur Anzeige; die Referenzkurse der Märkte (CF-Index, Chainlink, Binance, Mark-Preis) weichen vom Coinbase-Spot ab.
- **Speicher:** `prognosemarkt.db` geschätzt 1–4 GB im Jahr; die tägliche Sicherung kopiert sie mit (eine Generation).
- **Last:** Die tägliche Zählung lädt den BTC-Spot von 400 Tagen und schätzt das HAR (auf dem Pi einige Sekunden bis Minuten im
  Dashboard-Prozess); das Urteil selbst rechnet einige Minuten, einmal.
- Das alte `update.py` (23.87) kennt die zwei neuen `.md` nicht; sie kommen mit dem nächsten Paket auf den Pi. Die `.py` übernimmt es als
  „weitere Dateien“.
- flake8 `--select=F`: keine neuen Befunde; die fünf aus 23.87 (hl_recorder 3, hl_viz 1, update 1) bleiben.
- Keine zweite unabhängige Durchsicht des Einbaus: das Konzept wurde unabhängig durchgesehen; der Einbau ist Anzeige, Abruf und Ablage,
  die Rechenwege der Urteile sind die des geprüften Moduls.

**Einspielen:** **nach dem Poller-Bericht am 30.10. um 08:50** wie gewohnt (Knopf „Update“ oder `update.py`); enthält 23.87. Der Faden
startet 60 s nach dem Dashboard, der Erstlauf dauert einige Minuten. Berichte 30.10. 12:00 und 31.10. 08:45 (Erstlauf, Stand, Zählung),
01.11. 20:45 und 03.11. 20:45 (Urteil oder Zählung) -- bitte hochladen. Ausschalten ohne neues Paket: `HL_PM=0` in der Unit des
Dashboards.

## 0. UPDATE-PLAN (ab 22.09.)

Alles Offene steht in **`UPDATE_PLAN.md`** — lebendes Dokument, wird zu Beginn jeder Sitzung gelesen
(Abschnitt A: Prüfungen) und am Ende aktualisiert (Status, neue Punkte, Version). Was dort nicht
steht, existiert nicht. Nächster Punkt (Stand 23.18): am 24.09. ab 13:15 die Neubewertung der alten Sperren (Debug „Masterregel Sperre“),
beim nächsten Start die Zeile „Pool-Fills“ (U40b), Debug „★ Ereignis-Profile (U43)“ ansehen; U29/U35 vor U7b.

## 3zz. Auditbericht v10 (Opus 5.5): Review und P0-Korrekturen (22.09., Version 2026-09-22.18)

Vollständiges Review in `REVIEW_Audit_v10_22-09-2026.md` (Status je Befund, Belege, Entscheidungen).
Kern: **K1** (HL-Limit 10 Nutzer je IP für userEvents-Abos; wir forderten 600 an und schalteten die
Ableitung für angeforderte Abos ab — Doku online bestätigt) und **K2** (Kalibrierung strukturell
lernunfähig: 93-%-Treiber → p_up 50,8 %, n_eff durch MAX_TRAIN bei ~125 gedeckelt — selbst nach-
gestellt) sind zutreffend; **H8** (t-Wert überlappender Fenster: 27 % Fehlalarme statt 16 % — selbst
nachgestellt) ebenfalls. Die „2.500" in M1 sind USD je Fill (Zähler saß im Mindestbetrag), kein
Fehler des Audits. Umgesetzt: K1, H1, H2 (matches-Kanal), H3, H4, H5, H8 (Block-t), H9, H12, M1, M2,
M6, M9, M11 (store_forecast), M12, M13, N1, N2, N5, N7, N8, S1, S4; Positivkontrolle informativ im
Nulltest. Harness 77/77 (Funding/Gegen-Flow-Erwartungen angepasst), Nulltest grün, Selbsttest 20/20.
Offen: K2-Neubau (P1), H6/H7/H10/H11/H13, M3–M5/M7/M8/M10, S2/S3.

## 3yy. Masterregel Sperre: > 2.000 Fills/Tag = dauerhaft gesperrt (22.09., Version 2026-09-22.17)

Entscheidung Nutzer: eine systemweite Blacklist statt Einzelausschlüsse; dauerhaft, weil Maschinen ihr
System nicht ändern. **Recorder:** `konto_status` (addr, status, grund, seit, quelle, fills_tag);
`sperre_pruefen()` im Fill-Lauf (Zähler `fill_zaehler` je UTC-Tag aus dem Stream für alle
beobachteten Konten inkl. Gesperrter, plus COUNT aus lb_fills 24 h) → über `SPERRE_FILLS_TAG` = 2000
dauerhaft; Rohfills des Kontos gelöscht. Manuell: labels.json `"sperre": true/false` (false schützt).
Wirkung: Stream speichert keine Fills Gesperrter (zählt nur), Poller nur Liquidationsstufe
(`SPERRE_POLL_S` 6 h, Heatmap bleibt), `order_candidates` überspringt, REST-Fill-Lauf überspringt,
Leaderboard-Zyklus überspringt (Rang 0/1), `fill_konten` = Auswahl ∪ Pool ∪ Wale (neu: Wale, damit
Fills/Tag messbar) − Gesperrte. **Dashboard:** `gesperrte_konten(con)` (60 s Cache, Tabelle +
manuell) filtert `load_whales` (current + events → Direktionale Wale, Wal-Flow), den Lernzyklus
(Scores → Elite, Smart-Flow, Gegen-Flow); Label-Marke „GESPERRT — Masterregel"; Netzwerkstatus
„Gesperrt (Masterregel): N Konten"; Pool-Vorschau mit Marke; Werkzeug `check_sperre.py`
(Debug „Masterregel Sperre": Liste mit Grund, aktivste Konten der 24 h). Probe: 2.100 Fills → gesperrt,
Poller 5 min nicht fällig / 7 h fällig, Orders-Kandidaten ohne das Konto, fill_konten ohne das Konto,
load_whales ohne das Konto, Neustart lädt die Sperre. Die Aktivitätsschranke der Elite (300 Trades)
bleibt als zweite, feinere Stufe darunter.

## 3xx. Aktivitätsschranke der Elite: > 300 Trades/Tag = keine Elite (22.09., Version 2026-09-22.16)

Beobachtung des Nutzers: Elite-Konten, die alle paar Sekunden Positionen öffnen. Prüfung der
Ausschlüsse: Hedge (Klasse 0) greift; Market-Maker-Regel verlangt ≥ 5 **ruhende** Kauf- und
Verkaufs-Limits — Taker-HFT ohne ruhende Limits rutscht durch; und weil der Poller es jede Minute
sieht, liefert es hunderte Schritte, die jeden winzigen Vorlauf „signifikant" machen (t ≥ 1 hilft
nicht). **Neu:** `hl_score.aktivitaets_filter` — Trades/Tag = Maximum aus gebündelten Fills
(`pool_fills_hourly`) und Positionsänderungs-Minuten (`whale_positions`/`lb_events`), 3-Tage-Mittel;
über `ELITE_MAX_TRADES_TAG` = 300 → ok=False. `elite_filter` vereint Gewinn- und Aktivitätsschranke;
Lernzyklus und `check_elite` nutzen sie (Spalte Tr/T), die Elite-Tabelle unter den Treibern zeigt
Trades/T (rot > 300). Der Treiber summiert nur Elite-Konten → ausgeschlossene fließen nicht ein.
Probe: 480 Ereignis-Minuten/Tag raus, 480 Fill-Trades/Tag raus, 12/Tag bleibt. PDFs angepasst.
Option für später: die Klasse „Market-Maker" auch aus der Aktivität ableiten (wirkt dann überall).

## 3ww. Pfeile bleiben bis zur nächsten Prognose; Elite-Kontentabelle unter den Treibern (22.09., Version 2026-09-22.15)

**Pfeile verschwanden nach 60 s:** `sigBewerten` verglich gegen den letzten Verlaufseintrag — beim
Nachladen derselben Prognose war das der eigene Eintrag (Δ = 0). Jetzt Vergleich gegen die VORIGE
Prognose (letzter Eintrag mit t ≠ fc.ts); Umschwung-Fenster ebenso ohne den eigenen Eintrag.
Probe: Pfeil nach neuer Prognose 1, nach zwei Nachladungen weiter 1.
**Elite-Konten sichtbar:** `compute_forecast` liefert `elite_konten` (Adresse, Name/Rang aus
lb_accounts, Score/n/α/t aus den Scores, Kontowert aus lb_accounts bzw. addresses, Position im Coin
aus lb_positions bzw. jüngster whale_positions-Zeile, uPnL %, PnL 30 T); Tabelle unter der
Treibertabelle mit HypurrScan-Links, sortiert nach Score. Jede Teilabfrage einzeln abgesichert.

## 3vv. HypurrScan-Links in Wale, Leaderboard und Trade-Tabellen (22.09., Version 2026-09-22.14)

Helfer `hsLink(addr, inner)`; verlinkt: Wal-Tabelle (Gruppenkopf und Positionszeilen), „Letzte
Änderungen" der Wale (Wal-Flow), Leaderboard-Kontozeilen, „Letzte Änderungen der Top-Konten",
Käufe/Verkäufe 3 T und 48 h. Vorschau (10) hatte den Link schon. Infozeile der Vorschau nennt die
Abdeckung der Trades/T („aus k von 24 Stunden", 22.13). Browser-Probe: Wale 8, Leaderboard 4 Links.

## 3uu. Abschnitt 10 vor den Netzwerkstatus, bis 500 Konten (22.09., Version 2026-09-22.12)

Nutzerwunsch: Abschnitt 10 „Aktive Profis" stand unter dem Netzwerkchart bei den Betriebsteilen;
jetzt zwischen „48 h" (9) und „Netzwerkstatus". Anzahl wählbar 20/100/500 (Vorgabe 500; Endpunkt
`/pool?n=` bis 600), die sortierte Spalte ist in der Kopfzeile unterstrichen. Probe: 560 Pool-Konten
→ 500 Zeilen, Reihenfolge lbact48 → pool → network.

## 3tt. Pool-Anteil am Poller-Budget sichtbar (22.09., Version 2026-09-22.11)

Frage des Nutzers: Werden die Pool-Abrufe im Netzwerkmonitor erfasst? Antwort: die Leaderboard-
Datei (anderer Host, kein API-Gewicht) erscheint nur als Dauer in „Leaderboard-Stände"; die Stream-
Fills (0 Gewicht) in „Fills live"; die Positionsabfragen der Pool-Konten laufen über den Poller und
konkurrieren dort um das feste Budget (280/min) — ~111 Gewicht/min bei 554 Konten alle 10 min.
Jetzt sichtbar: Zeile „Adress-Poller … davon Pool N (x % der letzten 10 min)" und im Netzwerkstatus
„Pool-Anteil x %" (`poller_pool_anteil`, `pool_konten` in meta). Stellschraube: `POOL_POLL_S`.
Nur der Kontoname als Link in der Vorschau (22.10).

## 3ss. Vorschau: „{links,behavior}" behoben, HypurrScan-Links (22.09., Version 2026-09-22.9)

`labels_for()` liefert je Adresse ein Objekt (links, behavior, name …); die Vorschau hatte das
ganze Objekt als Namen gezeigt. Jetzt: Name aus dem Label, sonst Kurzadresse; Verhaltensklasse als
Zusatz. Der Kontoname ist ein Link auf `hypurrscan.io/address/<addr>` (neuer Tab). „ROI 1 T" bleibt
„—", bis die erste stündliche Leaderboard-Datei nach dem Einspielen von 22.8 die neuen Spalten füllt.

## 3rr. Vorschau-Abschnitt 10 „Aktive Profis" und ein reparierter Route-Verlust (22.09., Version 2026-09-22.8)

Frage des Nutzers: Woher kommen die PnL-Daten in der Stichprobe — sie kommen aus Hyperliquids
Leaderboard-Datei (Kontowert, Tag/Woche/Monat/gesamt: PnL, ROI, Umsatz; einzahlungsbereinigt).
Sofort nutzbar als Vorschau: neuer Abschnitt **10 „Aktive Profis — Vorschau"**: die 20 Pool-Konten
mit der besten ROI (umschaltbar 1 T / 7 T / 30 T / PnL 7 T), mit Kontowert, PnL 7 T, Umsatz 1 T,
Umschlag und — sobald das Stundenaggregat läuft — gebündelte Trades/Tag (gelb außerhalb 5–150).
Ausdrücklich „ohne Aktivitätsprüfung" (Phase 2). Recorder speichert jetzt auch pnl_1d/roi_1d/
pnl_30d/roi_30d im Pool und eine **stündliche Historie** `pool_accounts_hist` (Kontowert, Tages-
und Wochenwerte) — Grundlage für 12-h-Vergleiche und Einzahlungs-Erkennung. Endpunkt `/pool`, alle
5 min, Nav-Chip, im Snapshot enthalten.

**Nebenfund, behoben:** Beim Einbau von `/debug/threads` (21.09.) war die Zeile `elif u.path ==
"/restore/info":` verloren gegangen — die Route lieferte 404 (die Info-Zeile unter dem Restore-
Knopf blieb leer), und `/debug/threads` hätte zwei Antworten gesendet. Wiederhergestellt.

## 3qq. „Aktive Profis" Phase 1 (22.09., Version 2026-09-22.7) — Grenze 150 Trades/Tag

Ergebnis Phase 0: Pool 545 von 46.651 Konten, Überlappung mit Top-75 35; Umschlag misst Größe,
nicht Aktivität (Hochrechnung wertlos) → Grenze auf **150** gebündelte Trades/Tag gesetzt
(`POOL_MAX_TRADES_TAG`, greift in Phase 2). **Phase 1 im Recorder:** Konstanten `POOL_*`;
Tabellen `pool_accounts`, `pool_fills_hourly`; Spalte `addresses.account_value`;
`pool_aktualisieren()` je Leaderboard-Datei (Aufnahme ≥ 1 Mio & ≥ 500k, Hysterese 7 T, Deckel 600
nach pnl_7d, neue Adressen ins Verzeichnis), `pool_laden()` beim Start; `fill_konten` = Auswahl ∪
Pool; Poller-Stufe Pool (10 min); Kontowert im Poller (Standard-Dex `marginSummary`);
`pool_stunden_verdichten()` (24 abgeschlossene Stunden, gebündelt = COUNT DISTINCT Minute+Richtung)
vor der Fill-Aufräumung; Rohfills 14 T (`POOL_ROH_TAGE`), Vielhandler > 500 Fills/Tag nur 1 T.
`check_pool.py` Block 2b zeigt ab dem Einspielen die echten Trades/Tag (Median, ≤/> 150, < 5,
verbleibend). Erwartung: Stream-Fills für ~620 Konten, Speicher ≤ 1 M Rohzeilen. Phase 2 (Bewertung:
Exit-/Entry-Lift, ROI 12 h, Bot-Marke) und Phase 3 (Dashboard) folgen nach 24 h Daten.

## 3pp. „Aktive Profis" — Konzept und Phase 0 (22.09., Version 2026-09-22.6)

Neues Vorhaben (Konzept in `KONZEPT_Aktive_Profis.md`, alle Entscheidungen des Nutzers eingearbeitet:
Korrektur 2 %/12 h, Bündelung je Minute, Qualifikation 7 T, Pool ≥ 1 Mio Kontowert und ≥ 500k
Tagesumsatz, Perp+Spot, Entry-Lift zusätzlich, Bot = längster Trade-Abstand ≤ 4 h, Rang nach ROI 12 h,
Hysterese 7 → 30 T). **Phase 0 umgesetzt:** `check_pool.py` liest die volle Leaderboard-Datei (alle
Konten) und zählt Pool, ROI-Verteilung, Umschlag, Überlappung mit der Top-75-Auswahl, Kosten; Debug-
Eintrag „★ Aktive Profis, Phase 0". Ändert nichts am System. Nächste Schritte nach der Zählung:
Phase 1 (Pool-Tabelle, Stream-Fills für den Pool, Kontowert der Wale, Rohfills 14 T), Phase 2
(`hl_profis.py`: Bündelung, Exit-/Entry-Lift mit Placebo, Bot-Marke, ROI 12 h), Phase 3 (Dashboard).

## 3oo. Treiber-Signale: Pfeile, Blitze, Töne (22.09., Version 2026-09-22.5)

Nutzerwunsch, drei Punkte: (1) Ton, wenn ein seltener (Ereignis-)Treiber anspringt — negativ
Sirene 5 s, positiv „Kasse" 3 s; (2) Pfeile neben dem Namen bei jeder Änderung (▲ grün / ▼ rot),
Doppelpfeil ab 0,5 Score-Änderung (die „50 %" als halbe Skala interpretiert, absolut — relative
Prozente wären bei kleinen Scores Rauschen); (3) Umschwung: ≥ 2 der 5 gewichtigsten Treiber
binnen 10 min um ≥ 0,5 gefallen → Sirene + roter ⚡ (symmetrisch: gestiegen → Kasse + grüner ⚡).
Umsetzung im Dashboard-JS (`sigBewerten`): Verlauf je Coin/Treiber 60 min in localStorage,
Fortschreibung nur bei neuer Prognose (fc.ts); Töne per Web-Audio (Sirene: Sägezahn 600↔1200 Hz
im 0,5-s-Takt; Kasse: gefiltertes Rauschen + Glocken 1568/2093 Hz, zweimal); Schalter „🔔 Töne"
(localStorage `hl_ton`) mit Probe; Sirene hat Vorrang vor Kasse, wenn beides zutrifft.
Browser-Probe: ▲ / ▼▼ / ▲▲ korrekt, zwei rote Blitze, Sirene ausgelöst, keine JS-Fehler.

## 3nn. Breiten-Regel der Flow-Treiber (22.09., Version 2026-09-22.4, Fund des Nutzers)

Leaderboard-Flow zeigte „inaktiv" bei +13,0 Mio in 60 min — von EINEM Konto. Die Bedingung
„≥ 2 Konten" (gegen kleine Einzelkonten gedacht) warf ein direktionales Top-Konto mit 13 Mio
heraus, und der Grund-Text nannte keine Zahlen. Jetzt: aktiv bei ≥ 2 Konten **oder** einem
Einzelkonto ab 1 Mio (Leaderboard) bzw. 5 Mio (Wale); ein Einzelkonto wird mit 0,7 gedämpft
(Größe ja, Breite nein) und im Text benannt. Die Inaktiv-Gründe beider Flow-Treiber nennen die
tatsächlichen Zahlen („ruhig: 0,40 Mio von 1 Konto in 60 min — nötig …"). Treiber-Test 77/77.

## 3mm. Alle 30 Treiber in EINER Tabelle, EREIGNIS-Marke (22.09., Version 2026-09-22.3)

Nutzer-Entscheidung: keine getrennte „Nicht aktiv"-Liste — alle 30 stehen in der Treibertabelle.
Inaktive Zeilen sind gedimmt, Richtung „—", Gewicht/Prior/Bilanz wie sonst, im Text der Grund
mit Zahl. Ereignis-Treiber (Kapitulation, OI-Überhitzung, Crowding-Extrem, Vol-Spike-Reversion,
Liquidationsdruck, Wal-Flow, Leaderboard-Flow) tragen die Marke **EREIGNIS**, wenn das Ereignis
anschlägt, sonst „kein Ereignis" mit dem Stand der Bedingung. Payload: `inaktiv` (Zeilen) neben
`drivers`; `missing` bleibt für Werkzeuge. Behoben: das Auffangnetz lief vor den Blöcken Analog/
Smart-Flow/Gegen-Flow/Elite (doppelter Elite-Eintrag, generische Texte) — jetzt am Ende; jeder
Treiber hat einen spezifischen Grund (`INAKTIV_GRUND`). **Am Leaderboard-Flow wurde nichts
geändert** außer der Ereignis-Form (Audit v9); seine Bedingung (≥ 75k, ≥ 2 Konten in 60 min/3 h)
ist seit Sitzung 1 dieselbe — in ruhigen Stunden ist er inaktiv, nicht abgeschaltet.

## 3ll. Jeder Treiber erklärt (22.09., Version 2026-09-22.2)

Beobachtung: 25 in der Tabelle plus 1 ausgesetzt = 26 von 30. Die vier fehlenden waren
**bedingte** Treiber ohne Meldung (Kapitulation nur bei Schub, OI-Überhitzung ab 90. Perzentil,
Crowding-Extrem nur in den äußeren Dezilen, Vol-Spike-Reversion ab 1,5× Norm) — sie verschwanden
still. Jetzt: jeder bedingte Treiber meldet seinen Grund mit Zahl („OI im 61. Perzentil, aktiv erst
ab dem 90."), alle Meldungen beginnen mit dem exakten Treibernamen (Mehrfachmeldungen mit „/"),
und ein Auffangnetz stellt sicher, dass jeder der 30 Treiber entweder in der Tabelle steht oder in
„Nicht aktiv" genannt ist. Die Zeile zählt „Nicht aktiv (n von 30; k in der Tabelle)".

## 3d. Debug-Konsole

Die neuen Werkzeuge stehen in der Debug-Liste des Dashboards (`debug_commands` in
`hl_viz.py`): **Fill-Abholstand** (`check_fills.py` — welche Konten hängen, Klasse, Fills je
Tag), **Ereignis-Signal M9** (`check_m9.py`), **Nulltest**, **Konto-Score-Selbsttest**. Jedes
neue Diagnosewerkzeug gehört dort eingetragen — vom Handy aus ist die Konsole der einzige
Weg, es zu starten.

## 4. Was beim ersten Start auf dem Pi zu erwarten ist

- `forecasts.db` bekommt die Tabelle `weights_h` und die Spalten `p_up`, `p_up_24`
  automatisch (`store_connect`). Der Reset-Marker von Sitzung 1 bleibt gesetzt; die
  Gewichte starten beim Prior in beiden Spuren.
- **Der Lernbeginn springt nach hinten**: Statt „läuft" steht für rund eine Woche
  „n_eff 4 h: x von 40". Das ist richtig — die bisherigen 40 Fenster waren zehn Stunden
  Daten. Die 24-h-Spur bleibt etwa 40 Tage beim Prior (dann Schwelle 30 Blöcke je Treiber).
- **Trefferquoten fallen und bekommen Klammern.** Beides ist richtig (M7 plus Intervall).
  Grün wird eine Quote erst, wenn das Intervall ganz über der Basisrate liegt.
- **Das Ereignis-Signal feuert seltener.** `check_m9.py` zeigt, wie viel seltener.
- `p_up` liegt anfangs nahe 50 %, auch bei deutlichem `bias`: Ohne gelerntes β und mit
  wenigen aktiven Treibern ist die kalibrierte Wahrscheinlichkeit bewusst zurückhaltend.
- **Konto-Score:** Beim ersten Lernlauf entsteht der erste Schnappschuss aus den letzten
  28 Tagen Ereignissen. `lb_stats` füllt sich erst mit dem nächsten Leaderboard-Abruf —
  bis dahin fehlen Edge und Konsistenz (zählen neutral 0,5), der Score lebt von Vorlauf,
  Größe und Klasse. Die Treiber Smart-Flow / Elite / Gegen-Flow erscheinen ab dem ersten
  Schnappschuss; Gegen-Flow erst, wenn Konten n ≥ 20 Schritte haben.

---

## 5. Nächste Schritte, in dieser Reihenfolge (Konzept Abschnitt 6)

1. **Auf dem Pi zuerst messen, nicht ändern:** `install.py --selftest` (Nulltest,
   Invarianten), `hl_recorder.py --db … --audit`, `check_m9.py --db …`, und die fünf
   Abfragen aus Anhang A des Konzepts (Pareto der Heatmap-Masse, Fill-Verbraucher je
   Klasse, Poll-Takte je Wertstufe, n gegen n_eff je Coin). Diese Zahlen legen die
   Stufen der Budget-Tabelle fest.
2. ~~P1 — Konto-Score~~ **erledigt** (hl_score.py). Offen daran: Vorlauf zusätzlich aus
   `lb_fills` (heute nur Positionsereignisse) und Score je Coin für ETH/HYPE prüfen, ob
   genug Schritte anfallen.
3. **P1 — Budget nach Score** (Recorder): Fills nur direktional/gemischt, Orders nur
   S1/S2, Stufen S1–S5, Sichtung nach Handelsgröße, **WebSocket-Abonnements für
   `learn.elite`** (`userFills` + `userEvents`, REST alle 5 min als Lückenfüller). Braucht
   einen Kanal Dashboard → Recorder für Klasse und Score (Vorschlag: Tabelle
   `account_class` in der Hauptdatenbank, vom Dashboard täglich geschrieben).
4. ~~P1 — Smart-Flow, Elite-Positionierung, Gegen-Flow~~ **erledigt**; Killkriterium
   (Konzept 3.4: Intervall enthält 50 % und Gewicht < 0,3 × Prior bei n_eff ≥ 50 → parken)
   noch offen — braucht erst n_eff 50.
5. **P2 — M1–M3** (Liquidationsableitung), Treiber-Familien, Live-Abrufe Bybit/OKX/
   Crypto.com in den Binance-Dienst, Leaderboard als Wal-Liste.
6. **P3 — Konfluenz zeigt Prognose-Beiträge; M4, M5, M12, M13, M15, M16; Git auf dem Pi.**

---

## 6. Offene Befunde aus dem Audit (unverändert seit Sitzung 1)

**Datenqualität:** M1 (Positionen über Neustart), M2 (Markpreis statt Handelspreis).
~~M3, M4, M5~~ erledigt (3c). **Betrieb:** M15 (Migration der Nebendateien); ~~M12, M13,
M16~~ erledigt (3c).
**Sicherheit, bewusst offen:** Dashboard lauscht auf allen Adressen — Entscheidung des
Nutzers.

---

## 7. Arbeitsweise, die sich bewährt hat

- **Prüfen statt behaupten.** Auch das eigene Konzept: Zwei Annahmen darin waren falsch
  (Analog-Suche läuft bereits stündlich; ihre Merkmale sind fest standardisiert) und
  sind im Konzept korrigiert.
- **Nulltest vor Vertrauen.** Er hat in dieser Sitzung zwei Fehler in frisch
  geschriebenem Code gezeigt, bevor sie ausgeliefert wurden.
- **Nach jeder Änderung:** `python -m compileall`, `node --check` der ausgelieferten
  Seite, Browsertest Handy und Desktop, alle Endpunkte, `install.py --selftest`.
- **Beim Löschen von Codeblöcken vorsichtig schneiden**; Patches mit `assert count == 1`.
- **Ein Server je Port.** „Port bereits belegt" liefert stillschweigend die alte
  Fassung aus — beim Testen immer auf einen frischen Port.
- **Tests, die Fehler festschreiben, sind gefährlicher als fehlende Tests.** Deshalb
  kommt das Soll des Nulltests aus der Mathematik.
