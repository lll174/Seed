# Übergabe — Hyperliquid-Analysesystem (Änderungsprotokoll seit 13.09.2026; erstellt mit Claude Fable 5.1 bis 23.09.2026, fortgeführt mit Opus 5.5 — Einstieg: PROJEKTUEBERGABE_OPUS55_23-09-2026.md)

Für die nächste Sitzung. Die erste Übergabe vom 13.09. (Sitzung 1, Opus) ist hier
eingearbeitet; das Änderungskonzept liegt als `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
bei und ist die Landkarte für alles Weitere. Code im Archiv `hl_liq_project.zip`.

---

## 1. Was das System ist

Trading-Analysesystem für Hyperliquid auf einem Raspberry Pi 5. Es sagt **nicht**
Kurse voraus, sondern misst, wo gehebelte Positionen liquidiert würden, wer sie hält
und wie sich das verändert — daraus entsteht eine Prognose mit selbstkalibrierenden
Gewichten.

**Fünf Dienste**, alle in dieselbe SQLite-Datei schreibend:

| Dienst | Aufgabe |
|---|---|
| `hl-recorder` | Kern: Adress-Poller, Wal-Verfolgung, Leaderboard, Fills, Snapshots, Backup |
| `hl-dashboard` | `hl_viz.py`, Port 8765, Oberfläche, Prognose und Lernzyklus |
| `hl-binance` | Liquidationen, Kennzahlen, Tageskerzen |
| `hl-coinbase` | Spot: Prämie, Taker-Flow, Orderbuch |
| `hl-watchdog` | Überwachung, Benachrichtigung |

**Datenbank:** `/media/seed/marketdatabase/hl_liq/hl_liq.db` (~3,9 GB, USB-Stick).
`forecasts.db` und `sys_history.json` liegen daneben.

**Coins:** BTC, ETH, HYPE, ZEC, XMR, PAXG — die Liste steht **einmal** in
`install.py` als `COINS`.

---

## 2. Eiserne Regeln dieses Projekts

**Zeitstempel sind SEKUNDEN.** Ausnahmen: `addresses.last_trade` und `first_seen` in
Millisekunden (bewusst). Erkennungsgrenze ms gegen s ist **1e11**. **Neu:** Der
Datenbank-Audit (`hl_recorder.py --audit`, Teil des Selbsttests) prüft das als Invariante
über alle Tabellen — eine Millisekunden-Zeile ergibt FEHLT und Exit 1.

**Seiten sind normalisiert.** `side` steht als `"long"`/`"short"` in der Datenbank und
wird beim Lesen **nicht** neu abgeleitet. Der Audit meldet Fremdwerte.

**Maker gegen Taker.** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`hl_coinbase.py --selftest` prüft das als erste Zeile.

**Das IP-Limit ist nicht erhöhbar.** 1.200 Gewicht je Minute und IP. `clearinghouseState`
2, übrige Info-Abfragen 20, `userFillsByTime` plus 1 je 20 Einträge. **WebSocket:**
höchstens **10 verschiedene Nutzer** über nutzerbezogene Abonnements (Doku, 13.09.
geprüft) — das ist die Vorgabe für die Elite-Liste im Konzept, kein Hindernis.

**Stichproben sind n_eff, nicht Fenster.** Alle 15 min eine Prognose, Bewertung nach
h Stunden: n_eff = Zahl getrennter h-Stunden-Blöcke (≈ Fenster / 16 bei 4 h; bei
geklumpten Ereignis-Treibern die Zahl der Episoden — `n_eff_bloecke`). Jede Quote im System trägt ein Wilson-Intervall
auf n_eff und steht neben ihrer Basisrate. Eine Zahl ohne Intervall ist keine Aussage.

**Prüfen statt behaupten.** Jeder Befund wird vor der Korrektur nachgestellt. In dieser
Sitzung: alle Konzeptbefunde am Code bestätigt, zwei eigene Fehler durch den Nulltest
gefunden (Lernrate nach Umnormierung, Magnet-Intervall zu eng).

---

## 3. In Sitzung 2 erledigt

### Kalibrierung (`hl_forecast.calibrate_weights`)

- **Befund bestätigt:** `lam = 4.0 / max(n, 1)` mit überlappenden Fenstern. Bei 2.000
  Fenstern λ = 0,002 → Prior praktisch abgeschafft; auf reinem Rauschen wanderten
  Gewichte um bis zu 0,12 (gemessen, drei Seeds).
- **Neu:** λ = 4 / n_eff (n_eff = getrennte Horizont-Blöcke, `n_eff_bloecke`); Lernstart ab
  n_eff 40 je Horizont (4 h: rund eine Woche; 24 h: rund 40 Tage); ein Treiber verlässt
  seinen Prior erst ab eigenen unabhängigen Fällen — **je Horizont gestaffelt**
  (`MIN_N_EFF_TREIBER = {4: 50, 24: 30}`, Re-Audit N1: `forecasts.db` behält 60 Tage, die
  24-h-Spur sieht also nie mehr als ~60 Blöcke). Die 24-h-Spur trainiert mit **einem
  Fenster je Stunde** (`TRAIN_STRIDE`), 60 Tage = 1.440 Fenster, Laufzeit ~1 s auf dem Pi.
- **Zwei Spuren:** 4 h (Hauptspur, alle 15 min, `weights_h` h=4, Spiegel in `weights`)
  und 24 h (stündlich, `weights_h` h=24). `compute_forecast` nutzt die 4-h-Gewichte für
  `bias` und den Pfad bis 24 h, die 24-h-Gewichte (`bias_24`) für die Drift danach.
- **β, gelernter Maßstab:** P(auf) = sigmoid(β · Σ wᵢxᵢ / Σ Priors). Gespeichert als
  `p_up` / `p_up_24` je Prognose (neue Spalten). Vor dem Lernen β = 1 → p_up ist dann
  eine Vorgabe. Meta (n, n_eff, λ, β) in `learned.cal_4` / `cal_24`.
- **Gegenprobe:** Ein Treiber mit echten 65 % (4 h) wird gelernt: 1,20 → 1,27 nach 14
  Tagen, 1,29 nach 28; β steigt auf 1,09. Rauschen bewegt nichts mehr (≤ 0,01).
- Laufzeit `forecast_learn` mit 1.900 Fenstern: 1,1 s hier, Pi etwa 4 s.

### Trefferbilanz (`score_forecasts`)

Eine Prognose je 15-min-Fenster (Sofortprognosen zählen nicht doppelt), Blöcke `q4` und
`q24` mit n, n_eff, Wilson-Intervall, Basisrate („immer aufwärts" in denselben Fenstern),
Brier-Score und Brier-Skill. Alte Felder (`n`, `hit_rate`, `hit_rate_4h`, `model`,
`analog`, `oos`, `mae_pct`) bleiben für `check_report.py`. Die `wver`-Trennung heißt jetzt
„Seit Gewichtsversion" — alle gespeicherten Prognosen sind ohnehin walk-forward.

### Ensemble

Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Pseudo-Priors 0,56/0,54 = alte
Mischung 60/40, Nullpunkt 0,5), gedeckelt 30–70 % bis n_eff 50 je Modell. Vorher:
`hit_rate − 0,4` ohne Schrumpfung — 32/68 aus anderthalb Tagen.

### M9, M6, M10 — erledigt

- **M9** (`hl_viz.py`, Wal-Flow `pack()` und Leaderboard-Flow): `event_signal` = Rang in
  der vollständigen Wochenreihe ≥ 98 % (`hl_forecast.rang_in_reihe`, vom Nulltest geprüft;
  Vergleichsreihe ohne die laufende Stunde)
  **und** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto) **und** Breite
  (4 bzw. 3 Konten), mindestens 48 h Historie. Z-Wert bleibt für die Anzeige,
  `event_signal_z` zeigt die alte Regel zum Vergleich. **`check_m9.py --db …`** zählt die
  Feuerraten alt/neu der letzten 7 Tage auf den echten Daten — **das ist noch zu laufen**
  (hier nur mit synthetischen Ereignissen geprüft: echter Schub feuert in beiden Regeln).
- **M6** (`hl_recorder.py analyze`): `dropna` auf `fwd_4h`, Anzahl „noch ohne Ergebnis"
  wird ausgewiesen; dazu Placebo-Basisrate (4 h aufwärts/abwärts über alle Zeitpunkte)
  und Lift.
- **M10** (`load_stops`): `bucket_px()` statt `round(…, 2)` — Fusion findet jetzt zusammen.

### Weitere Statistik

- **Magnet-Statistik:** Placebo-Niveau (gleicher Abstand, andere Seite, gleicher
  Zeitpunkt), `p_placebo`, `lift`, Intervall auf n_eff = getrennte 12-h-Blöcke.
- **Analog-Suche:** `p_up` mit Intervall und unbedingter Basisrate `p_up_base`; der
  Treiber misst gegen die Basisrate statt gegen 0,5.
- **Zeitprofil:** rollierend 180 Tage.

### Nulltest und Selbsttest

`hl_forecast.py --nulltest` (Teil von `install.py --selftest`): Wilson-Überdeckung,
Quote 4 h/24 h enthält 50 %, Brier-Skill ≈ 0, Gewichte beim Prior, Magnet-Lift 1,
Rang-Signal ~2 %. Läuft in 0,3 s. Selbsttest kompiliert jetzt auch `hl_forecast.py`,
`hl_coinbase.py` und `hl_score.py`; Audit-Schritt heißt „mit Einheiten-Invarianten";
17 Schritte, alle grün.

### Konto-Score — P1, Teil 1 (`hl_score.py`, neu)

Die goldene Regel wird messbar: je Konto und Coin ein Score aus **Vorlauf** (35 %,
Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, ein Schritt je Stunde,
geschrumpft n/(n+20)), **Edge je Umsatz** (25 %, PnL/Umsatz), **Konsistenz** (20 %, vier
Leaderboard-Fenster), **Größe** (10 %) und **Klasse** (10 %); rangnormiert, täglich neu,
Schnappschuss in `forecasts.db` → `account_score` (120 Tage Vorhalt).

- **Recorder:** neue Tabelle `lb_stats` (alle vier Leaderboard-Fenster mit `pnl`, `roi`,
  `vlm` für Kandidaten **und** bekannte Wale, stündlich ersetzt). Der Umsatz wurde bisher
  beim Parsen verworfen — er ist die billigste Trennlinie zwischen Market Makern und
  Händlern.
- **Drei neue Treiber** in `compute_forecast`: `Smart-Flow 4 h` (1,0; Fluss mit Score
  gewichtet, √Notional), `Elite-Positionierung` (1,0; Netto der zehn besten Konten),
  `Gegen-Flow` (0,3; Konten mit belegt negativem Vorlauf, n ≥ 20, invertiert).
  **Gestrichen:** `Wal-Flow Hedge`, `Wal-Flow Market Maker`, `Wal-Flow gemischt`.
- **Score-Test** wöchentlich (`learned.score_test`): Spearman des Scores von vor 7 Tagen
  gegen den Vorlauf der Folgewoche, je Komponente, mit SE ≈ 1/√(n−1). Erster Wert
  frühestens sieben Tage nach dem ersten Schnappschuss. Im Selbsttest mit 16 Konten ist
  ρ ± 0,26 — Aussagekraft braucht die Hunderte Konten des Pi.
- **Elite-Liste** `learn.elite` (Top 10 nach Score, nur direktional/gemischt) — das ist
  die Vorgabe für die WebSocket-Abonnements (Konzept 2.5), noch nicht angeschlossen.
- Kachel „Konto-Score" in der Selbstoptimierung; Selbsttest-Schritt „Konto-Score
  (hl_score)" (drei synthetische Konten mit echtem Vorlauf müssen die Elite stellen).

### Dashboard

Trefferquote-Kachel: „4 h: 57 % (47–66) · Basis 51 % · n_eff 108 · Brier-Skill".
Gelernte Gewichte: n_eff, Fenster, β, λ beider Spuren. Treibertabelle: Intervall und
n_eff je Treiber. Magnet: „93 vs 90 %" (berührt vs Placebo), Lift mit Intervall.
Lernplan: Lernbeginn nach n_eff, fehlende Fenster. Browsertest Handy/Desktop ohne
JS-Fehler; `node --check` beider Skriptblöcke grün.

---

## 3b. Audit der eigenen Änderungen (Sitzung 2, auf Wunsch)

Jede Änderung wurde nachgelesen, Randfälle ausgeführt. **Gefunden und behoben:**

| Befund | Wirkung | Korrektur |
|---|---|---|
| Seiten-Invariante im Audit hätte auf dem Pi **falsch gewarnt** | `liquidations`, `lb_fills`, `trigger_orders`, `ticks` tragen absichtlich die Rohseiten `A`/`B` | Prüfung nur auf Positions-Tabellen (heatmap, whale_positions, lb_positions, lb_events, bnc_liquidations, cluster_events) |
| ms-Invariante: Nullen in `first_seen`/`last_trade` wären als „Sekunden" gemeldet worden | falscher FAIL möglich | `MIN(...) WHERE > 0` |
| `update.py` sicherte `hl_score.py` und `check_m9.py` nicht vor dem nächsten Update | Verlust bei Rücksprung | in `PROJECT_FILES` aufgenommen |
| Rang-Vergleichsreihe enthielt die **laufende Stunde** — also den Wert, der eingeordnet wird | Signal wirkt kleiner als es ist; galt auch für den alten Z-Wert | laufende Stunde aus der Reihe genommen (Wal-Flow, Leaderboard-Flow, `check_m9.py`) |
| Elite-Positionierung zählte ein Konto doppelt, wenn es Leaderboard-Konto **und** Wal ist | Netto verzerrt | Leaderboard-Stand hat Vorrang, Wal-Zeile wird übersprungen |
| n_eff = Fenster · 0,25 / h unterstellt gleichmäßige Fenster | Ereignis-Treiber (geklumpte Fenster) wurden zu optimistisch, seltene Treiber zu pessimistisch gezählt (52 Fenster in 13 Episoden: Formel 3,2, Wahrheit 13) | `n_eff_bloecke`: getrennte Horizont-Blöcke, in Kalibrierung und Trefferbilanz |
| Wilson-Intervall bei n_eff < 1 | sinnlose Klammer (0–100) | Intervall erst ab einem unabhängigen Fall |
| forecasts.db-Verbindung im Score-Abschnitt blieb bei Fehler offen | Handle-Leck | `finally: close()` |
| Unveränderte Gewichte wurden alle 15 min neu geschrieben | unnötige Schreiblast | Auffrischen höchstens stündlich |

**Geprüft und in Ordnung:** Gradienten der Kalibrierung (Logit, L2, Schrittweiten stabil);
Konsistenz von `p_up` zwischen Kalibrierung und Prognose (fehlende Treiber = 0, gleiche
Normierung); alle Zeitspalten der Binance-, Coinbase- und Timestats-Tabellen in Sekunden;
`lb_stats`-Spaltenzahl gegen INSERT; Lesezugriffe von `check_report`/`check_forecast` auf die
neue Bewertungsstruktur; JSON-Serialisierbarkeit aller gespeicherten Felder; JS-Syntax beider
Skriptblöcke; Selbsttest 17/17, Nulltest, Positivkontrollen (echter Treiber wird gelernt,
Rauschen nicht; Elite aus Konten mit echtem Vorlauf).

## 3c. Externer Re-Audit (Kimi K3, gleicher Tag) — abgearbeitet

Der Re-Audit bestätigte die Statistik-Umbauten numerisch (Lernkurven, Nulltest, Invarianten)
und fand einen MEDIUM-Befund plus 14 LOW; alle am Code nachgestellt, dann korrigiert:

| Befund | Korrektur |
|---|---|
| **N1 24-h-Spur lernt nie** (MAX_TRAIN 4000 < 50 Blöcke; dazu 60-Tage-Vorhalt) | Schwelle je Horizont {4: 50, 24: 30}, ein Fenster je Stunde, `gelernt` nur bei aktiven Treibern. Gegenprobe: ab 40 Tagen lernt die Spur (Wale 1,20 → 1,26 bei 60 T) |
| H2-Rest: drei unmaskierte Namen (`innerHTML`) | `esc()` für Name, `market`, `dir` in beiden Fill-Tabellen und der Wal-Tabelle |
| N2 `schreibe()` blockierte mit `time.sleep` die Ereignisschleife | `async`, `asyncio.sleep`; bei Endfehlschlag Wert nicht als geschrieben verbuchen |
| N3 Coinbase-Kachel `toFixed` auf null | Null-Guard |
| N4 Volumenvergleich laufende gegen volle Stunden | gleitende 60 min (`flow60`) gegen den Schnitt voller Stunden |
| N5/M14 `/leaderboard`-`days` ungeklemmt, `_LB_CACHE` ohne Kappe | `_grenze(1..90)`, `_kappen(48)` |
| N6 Coinbase `busy_timeout` 60 s > Heartbeat 20 s | 5 s, sperr-tolerantes `schreibe()` mit Zähler `db_locked` |
| N7 Backoff-Reset sofort nach Connect | Reset erst nach einer stabilen Minute |
| N8 `ws_connect(timeout=20)` als Zahl | `ClientWSTimeout`, Rückfall auf Zahl bei alter aiohttp |
| N9 Minuten-Bucket aus lokaler Uhr | Nachrichtenzeit, wenn plausibel (±10 min) |
| N10/N11/N16 Vorgabe-Coins, Kommentar 2 %, tote Imports | angeglichen |
| N12 `check_m9 --days 0` | geklemmt 1..60 |
| N13 Wal/Leaderboard-Überlappung doppelt gezählt | Konto nur aus `whale_positions`, wenn dort vorhanden (nachgewiesen) |
| N14 Elite je Coin mit Fremdkonten | Elite nur aus Konten mit Schritten im Coin |
| N15 Kommentar zur Lernrate falsch | Schritt bleibt im Gewichtsraum gleich, nicht im Logit-Raum — so steht es jetzt da |
| Zeitprofil: Division durch null bei kurzer Historie (eigener Fund beim Regressionslauf) | kein Profil unter 24 gefüllten (Wochentag, Stunde)-Zellen |

**Aus der offenen Recorder-/Betriebsliste zusätzlich erledigt:** M3 (`blake2b` statt
gesalzenem `hash()` — deterministische tid über Neustarts), M4 (Fehlschlag macht die Adresse
nach fünf Minuten wieder fällig, Zähler `poll_failed`), M5 (alle Adressen mit Position),
M12 (Rückfallschwelle statt `TypeError`), M13 (Symbolauflösung bis zehn Minuten wiederholen,
dann Exit 1), M16 (Open-Interest-Abruf im Thread).

**Bewusst offen — Entscheidungen des Nutzers oder eigene Sitzung:** C4-Rest (Auth-Token
für `POST /update`, `install.py --host 0.0.0.0`, ZIP-Manifest/Signatur, sudoers statt
`sudo.txt`), M1/M2 (Positionen über Neustart, Markpreis-Touch), H5/M15 (Migration), die
~38 LOW-Befunde des Erstberichts.

## 3e. Der „Fill-Rückstand" war ein Phantom (gefunden mit Live-Probe auf dem Pi)

Seit Sitzung 1 galt: „34 von 79 Konten im Rückstand, schlechtestes 63 h", und der
Adress-Poller wurde deshalb **auf 10 % gedrosselt** zugunsten der Fill-Abholung. Die
Live-Probe (`check_fills.py`, Abschnitt 4) zeigte für die schlechtesten Konten: sofortige
Antwort, Teilseiten, und **alle gelieferten Fills lagen bei 53 Stunden** — die Konten hatten
seitdem nicht gehandelt. `lb_fills_deferred = 0`: Das Budget hat nie ein Konto vertagt.

**Ursache:** Der Abholstand wurde auf den neuesten *geholten* Fill gesetzt. Die Abholung
beginnt zehn Minuten davor, bekommt bei einem inaktiven Konto jedes Mal dieselben alten
Fills zurück, die Antwort ist nicht leer — der Stand rückte nie auf „jetzt". Ein Konto, das
aufhört zu handeln, sah für immer wie Rückstand aus.

**Korrektur (`hl_recorder.py`, Fill-Schleife):** Eine Teilseite (unter 2.000 Einträge) heißt,
die API hat alles bis jetzt geliefert → Stand = jetzt − 10 min, unabhängig davon, ob Fills
darin waren. Nur bei ausschließlich vollen Seiten reicht der Stand bis zum neuesten Fill.
Dazu: Kachel „Fill-Abholstand" zählt nur Konten der aktuellen Auswahl (10 veraltete Stände
ausgeschiedener Konten zählten mit); der Recorder räumt solche Stände nach 7 Tagen auf.

**Erwartung nach dem Einspielen:** Der Rückstand fällt binnen einer Stunde auf wenige
Konten (die mit wirklich vielen Fills), die Poller-Drossel hebt sich von selbst auf
(`poller_drossel` 0,10 → 1,0), die Heatmap-Abdeckung steigt. Das ist zugleich die Antwort
auf die Budgetfrage aus dem Konzept: Hedge- und MM-Konten erzeugen nur **9 %** aller Fills
(gemessen), nicht 70 % — „Fills nur für direktionale Konten" spart weniger als angenommen.
Die Konzept-Annahme ist damit widerlegt und in 2.4 zu korrigieren; der Poller bekommt sein
Budget durch die Cursor-Korrektur zurück, nicht durch Streichen von Fills.

**Weitere Messwerte vom Pi (13.09., 21:08–21:34):** Nulltest und Konto-Score-Selbsttest
grün; M9: Rang trifft alle drei Fälle der alten Regel und findet einen vierten (11.09.
16:00, −54 Mio aus 12 Konten), Feuerrate 2,4 %; Leaderboard-Flow dreimal am 13.09., alle
24–35 Mio.

## 3f. Prüfung des Mix-Modus (Fremdbörsen in den Statistiken)

Jede Fremdquelle einzeln verfolgt: Tabelle → Leser → Frischeprüfung → Treiber.

| Quelle | Fließt ein in | Frische | Befund |
|---|---|---|---|
| Binance Taker-Verhältnis (5 min, live) | Treiber „Taker-Flow" (Log-Mittel aller Börsen) | live, 5-min-Cache | korrekt |
| OKX Taker (5 min), Bybit / Crypto.com (Trade-Listen) | „Taker-Flow" | Mindestspanne 60 s | korrekt; Fenster uneinheitlich (5 min vs. 150/500 Trades) — Schwäche, kein Fehler |
| Binance-Liquidationen | Kapitulation | 3 Tage | korrekt (Sekunden, Seiten normalisiert); HL-eigene Liquidationen nicht enthalten (Designentscheidung) |
| Binance- und Crypto.com-Orderbuch | Wände im Pfadmodell (fusionierte Cluster) | 15-s-Cache | korrekt (M10 behoben) |
| HL-Buch (`book_summary`), HL-Funding | „Orderbuch", „Funding" | 10 / 15 min | korrekt, nur HL — Fremdfunding nur Anzeige |
| Coinbase Spot | Prämie, Spot-Taker, Spot-Buch | 30 min | korrekt |
| Binance Tages-/30-min-Kerzen | MA 200 / 50 W, Analog-Suche, Zeitprofil | — | korrekt |
| Binance-Volumen | **Magnet-Schwelle der Prognose** | — | **Fehler, behoben** (unten) |

**Der Fehler:** Die Prognose rechnet immer im Fusionsmodus; dort ist `vol_1h` die Summe
aus HL + Binance + Crypto.com. Die Schwelle „Cluster ≥ ½ Stundenvolumen" war für das
HL-Volumen gedacht — gegen das Fünf- bis Zehnfache war kein HL-Liquidationscluster je groß
genug, und die Prognose lief bei BTC/ETH ohne Magneten und Stop-Auslöser auf dem
Sigma-Pfad. Die Magnet-Statistik dagegen rechnete ihre Schwelle korrekt aus dem HL-Volumen
— Statistik und Prognose vermaßen verschiedene Populationen. **Jetzt:** HL-Cluster und
HL-Stops gegen das HL-Volumen (`vol_split.hl`), fusionierte Bücher gegen das fusionierte
Volumen. Die Kachel „Magnet-Statistik" zeigt Schwelle, HL-Stundenvolumen und größten
Cluster je Seite — damit ist sichtbar, woran ein Magnet scheitert.

**Nebenbefund (eigener Fehler):** `score_forecasts` kehrte bei fehlenden Prognosen früh
zurück, ohne die internen Zähler (darunter ein `set`) zu entfernen → `/forecast` für einen
Coin ohne gespeicherte Prognosen hätte HTTP 500 geliefert. Behoben.

## 3g. Binance-Liquidationen: 13 Tage lang null Zeilen (gefunden 14.09., 00:02)

`bnc_liquidations` war leer — seit dem ersten Start. Der Weg zur Ursache: „36 Datensätze/h"
in der Quellenzeile (= nur die 10-min-OI-Abfragen) → `--status` zeigt **Liquidationen 0**,
Stream **Events 0** → die Unit auf dem Pi schreibt gepuffert ins Journal, die Fehlermeldung
kam nie an → Stream-Probe (`hl_binance.py --probe-stream`): DNS, TCP, TLS, Handshake ok,
**0 Nachrichten**. Dann die Dokumentation: Binance hat die Futures-WebSockets am 06.03.2026
in `/public`, `/market`, `/private` aufgeteilt und die alten Basis-URLs am **23.04.2026**
abgeschaltet — der Handshake auf `wss://fstream.binance.com/ws/…` gelingt weiter, aber
`/market`-Streams (darunter `!forceOrder@arr`) liefern dort nichts mehr.

**Korrektur:** `WS = wss://fstream.binance.com/market/ws/!forceOrder@arr`. Dazu: `--status`
zeigt die Stream-Zähler, `--probe-stream` als Debug-Eintrag, Quellenzeile weist den
Liquidations-Stream getrennt aus („STREAM PRÜFEN" ab 2 h Stille), Stream-Meldungen mit
`flush`, alle Units `PYTHONUNBUFFERED=1` (wirksam nach `install.py --systemd`).

**Folgen:** Der Treiber „Kapitulation" hatte nie Daten; seine Trefferquote in allen
bisherigen Berichten war leer. Er startet jetzt bei n_eff 0 wie ein neuer Treiber. Alles,
was im Erst-Audit über bnc_liquidations gefixt wurde (C1 ms→s, C2 Seiten), war korrekt —
nur ohne Daten. Nach dem Einspielen sollten binnen Minuten Zeilen erscheinen (Binance pusht
je Symbol bis zu eine Liquidation pro Sekunde); wenn nicht: Stream-Probe erneut.

**Lehre für die Arbeitsweise:** „Dienst läuft" ist keine Aussage über Daten. Jede Quelle
braucht einen Zähler ihrer *Nutzdaten* mit Alarm bei Stille — nicht nur einen Lebenszeichen-
Stempel.

## 3h. Rundum-Funktionstest aller Quellen (`check_sources.py`)

Debug-Eintrag „★ Rundum-Funktionstest aller Quellen (langsam, ~3 min)". Ruft jede Börse
mit genau den Anfragen des Codes auf — Hyperliquid (meta, spotMeta, perpDexs, l2Book,
clearinghouseState, spotClearinghouseState, frontendOpenOrders, userFillsByTime am größten
Wal aus der Datenbank, Leaderboard mit Fensterprüfung inkl. `vlm`; WS trades/l2Book/
activeAssetCtx), Binance (ping, exchangeInfo, klines 1m/15m/1d, Spot-Tageskerzen, depth,
premiumIndex, openInterest, alle vier `/futures/data`-Verhältnisse; WS neue **und** alte
URL — die alte muss still sein), Coinbase (products, stats, book, candles; WS ticker), Bybit,
OKX (inkl. rubik und liquidation-orders), Crypto.com, Farside-ETF. Je Aufruf: Latenz, Form,
und ob die FELDER da sind, die der Code liest. Pausen zwischen Aufrufen, HL-Gewicht < 150.
Hinweise = nicht gelistete Coins oder ruhige Streams; FEHL = der Code liest etwas, das nicht
(mehr) kommt → zuerst die Doku der Börse prüfen (Umstellung?). Exit 1 bei FEHL.

**Erster vollständiger Lauf auf dem Pi (14.09., 00:24): 61 ok · 4 Hinweise · 0 FEHL.**
Hinweise = nicht gelistet: XMR (Coinbase), XMR/PAXG (OKX), ZEC/XMR (Crypto.com); Bybit
listet alle sechs. Binance-Stream auf der neuen URL 8 Nachrichten/20 s, alte URL still.
Leaderboard 45.106 Zeilen mit allen vier Fenstern und `vlm`. HL-WebSocket trades/l2Book/
activeAssetCtx liefern. Fills des Testwals: volle Seite (2.000 in 24 h) — ein Vielhandler.

**Empfehlung:** einmal je Woche laufen lassen und nach jeder Meldung einer Börse über
API-Änderungen. Das hätte die Binance-Umstellung am Tag ihrer Wirkung gezeigt.

## 3i. Reihen der Fremdbörsen (`hl_ext.py`, 14.09.) — mit Audit

Vier Bausteine, wie beauftragt: `ext_metrics` (Bybit/OKX/Crypto.com alle 5 min),
`bnc_metrics` um die Binance-Verhältnisse ergänzt, `bnc_book` (Orderbuch mit Wänden alle
5 min), `ext_liquidations` (Bybit-Stream vollständig, OKX alle 2 min), dazu `etf_flows`.
Betrieb als Zusatzaufgaben in `hl-binance` (`Live.run_ext`), eigene Verbindung mit
Schloss, Abrufe in Threads. Details, Formate, Ratenbudget: README „Reihen der Fremdbörsen".

**Vor dem Bau geprüft:** Seitenbedeutung Bybit (`S = Buy` → Long liquidiert, Doku) und
OKX (`posSide`); Listungen je Börse aus dem Rundum-Test (Bybit alle 6, OKX ohne XMR/PAXG,
Crypto.com ohne ZEC/XMR); Formate aller Antworten aus dem Rundum-Test; Ratenlimits der
öffentlichen Endpunkte.

**Audit des Ergebnisses (Randfälle gelesen, Proben gefahren) — gefunden und behoben:**

| Befund | Korrektur |
|---|---|
| Bybit-Sperre bei jedem `retCode != 0` — ein Ratenlimit hätte den Coin einen Tag gesperrt | sperren nur bei 10001 (Symbol unbekannt), sonst zählen |
| `gather` ohne `return_exceptions`: stirbt der Stream, laufen die anderen Schleifen verwaist, der Neustart verdoppelt sie | `return_exceptions=True`, Schleifen enden einzeln |
| `import websockets` außerhalb des try | im try, Stream bleibt bei fehlendem Paket aus, Rest läuft |
| Anfangsverzögerungen (bis 600 s) ohne Stop-Prüfung — der Dienst hätte beim Beenden bis zehn Minuten gehangen (Betriebsprobe) | `warten()` in 1-s-Schritten mit Stop-Prüfung; Stopp jetzt in 0,2 s |
| Stream-Puffer (< 20 Zeilen) beim Stopp verloren (Betriebsprobe) | Flush beim Verlassen |
| Ein einziges ungültiges Bybit-Thema hätte die ganze Abonnement-Anfrage abgelehnt | ein Abonnement je Thema |
| Speicher: 40 Wände × 6 Coins alle 5 min ≈ 3,5 MB/Tag | 25 Wände, Buch-Vorhalt 60 Tage |
| `bnc_stats` auf 500 Zeichen gekappt → mit den neuen Zählern abgeschnittenes JSON | 2.000 Zeichen, nur Zahlen |

**Proben:** Selbsttest `hl_ext.py` (Parser, Seiten, Duplikate, Wände, Farside, Invariante);
Integrationstest mit dokumentierten Antwortformaten gegen SQLite (106 Kennzahlen je Lauf,
Sperren wirken, zweiter Lauf ohne Duplikate, alle `ts` in Sekunden); Betriebsprobe der
asynchronen Schleifen mit gemocktem Stream und Netzfehlern (läuft weiter, stoppt sauber).
Selbsttest der Anlage 18/18. **Live-Probe auf dem Pi steht aus**: nach dem Einspielen
„Binance-Modul --status" (Zeilen je Tabelle) und den Rundum-Test (jetzt mit Bybit-Stream).

**Bewusst nicht geändert:** Die Treiber lesen weiter live. Kapitulation über drei Börsen
und einheitliche Taker-Fenster aus `ext_metrics` sind der nächste Schritt, nachdem die
Reihen ein paar Tage gefüllt sind.

## 3j. Magnet-Schwelle — Parameter offengelegt und messbar gemacht (14.09.)

**Herkunft:** „Cluster ≥ ½ Stundenvolumen, mindestens 5 Mio" stammt aus Sitzung 1 — in
`compute_forecast` und `magnet_stats` gleichermaßen, nie gemessen. Sitzung 2 hat nur die
Bezugsgröße korrigiert (HL- statt fusioniertes Volumen, 3f) und die Zahl sichtbar gemacht;
den Faktor ½ hat sie ungeprüft übernommen. Das war ein Versäumnis: Dieser Faktor
entscheidet, ob Liquidationscluster überhaupt als Ziel gelten — der Kern des Systems.

**Jetzt:** `MAGNET_VOL_ANTEIL = 0.10`, `MAGNET_MIN_USD = 5e6` (benannte Konstanten,
`magnet_schwelle()`), in Prognose und Statistik dieselbe Funktion. Bei 100 Mio/h HL-Volumen
sind das 10 Mio — die 92 Mio oben und 35 Mio unten aus der Kachel vom 14.09. qualifizieren
beide. **Gemessen statt geraten:** `magnet_stats` weist den Lift jetzt zusätzlich je
**Größenklasse** aus (5–10, 10–25, 25–50, >50 % des Stundenvolumens; alle Cluster ab
5 Mio). Die Klasse, ab der der Lift über 1 liegt, ist die richtige Schwelle — dann wird der
Faktor nachgezogen. Kachel zeigt beide Sichten.

**Text korrigiert:** „kein großes Cluster in Reichweite" stand für drei verschiedene
Fälle. Jetzt steht der Grund: Richtung neutral (|Bias| ≤ 0,12 → kein Ziel, Sigma-Band) /
kein Cluster über der Schwelle in Richtung / Ziel wird angelaufen, Berührstatistik der
Klasse fehlt noch (n < 5) / Ziel mit Statistik.

**Offen, Entscheidung des Nutzers:** Bei neutralem Bias läuft der Pfad kein Cluster an,
auch wenn 92 Mio 1,8 % entfernt liegen. Wenn Cluster unabhängig vom Richtungsdruck
anziehen sollen (das ist die Magnet-These), müsste der Pfad bei neutralem Bias das
näherliegende/größere Cluster mit der gemessenen Berührquote als Reichweite anlaufen.
Das ist eine Modelländerung, kein Fix — nicht ohne Rückfrage.

## 3k. Magnet-Varianten: ziehen Cluster bei 0,5–1 % und 1–2 % den Kurs an? (14.09.)

Nach der Literatur (Osler 2005: Kaskaden nach der Berührung; Brunnermeier/Pedersen 2005:
Anziehung vorher durch strategisches Drücken; Cho et al. 2003: Magnet-Effekt als bedingte
Wahrscheinlichkeit nach Abstand; Avellaneda/Lipkin 2003: Drift zum Niveau ∝ Exposure)
misst `hl_forecast.magnet_varianten()` je Variante (0,5–1 %, 1–2 % vom Kurs) und Horizont
(4/8/12/24 h): **Δ Berührung minus Placebo** in Prozentpunkten mit z auf n_eff (Hauptmaß;
der Lift als Quotient ist bei kleinem n nach oben verzerrt — acht Seeds Rauschen ergaben
Ø 1,15), **Anziehung** (Überschussbewegung zum Cluster nach Abzug der Marktdrift, mit t),
**näher** gegen Placebo, und **Cho 15 min** (bedingte Wahrscheinlichkeit einer Bewegung zum
Cluster im Band gegen die unbedingte). Unabhängigkeit: ein Ereignis je Niveau und 24 h,
n_eff = getrennte h-Blöcke. Nur Cluster auf der richtigen Seite (Short-Cluster oben,
Long-Cluster unten), ab 5 Mio.

**Kontrollen:** Rauschen → Δ ≈ 0, Anziehung ≈ 0, Cho = Basis (im Nulltest verankert).
Positivkontrolle (ein stehendes Cluster je Tag, Zug 0,3 %/min des Abstands) → Δ +30 bis
+78 pp mit z 3–9, Anziehung +0,6 bis +1,1 % mit t 3–6, Cho 57–60 % gegen 50 %.

**Werkzeug:** Debug-Eintrag „Magnet-Varianten" (`check_magnet.py`, alle Coins, 14 Tage
Heatmap-Vorhalt). Kachel „Magnet-Statistik" zeigt je Variante 4 h und 24 h kompakt; der
Lernzyklus rechnet täglich. **Lesart:** belegt erst, wenn Δ und Anziehung positiv sind und
z bzw. t über 2 liegen, in mehreren Horizonten, mit Cho über Basis; n_eff unter 20 ist keine
Aussage. Erst mit diesem Beleg wird der Pfad bei neutralem Bias das Cluster anlaufen (3j).

## 3l. Schreibkoordination der Dienste (14.09., nach „database is locked" im Poller)

Vier Prozesse schreiben in eine SQLite-Datei (Recorder, Binance-Dienst mit Sammler,
Coinbase, Watchdog). Nach dem Start des Sammlers meldete der Poller „database is locked"
(hl_recorder.py, whale_positions), dreimal je Stunde; der Sammler zählte 38 verworfene
Schreibversuche. Drei Maßnahmen:

1. **`isolation_level="IMMEDIATE"`** für Recorder, Binance-Dienst und Sammler (Coinbase war
   schon Autocommit): Jede Schreibtransaktion holt die Schreibsperre beim Beginn; bei
   fremder Sperre wird gewartet (`busy_timeout`), statt zu scheitern.
2. **Weniger Transaktionen im Sammler:** Bybit-Stream schreibt höchstens einmal je Minute
   (oder ab 200 Zeilen) statt alle 5 s; Meta-Stempel nur im 5-min-Kennzahlenlauf, in einer
   Transaktion. Von ~800 auf ~130 Transaktionen je Stunde.
3. **Nie scheitern, nie blockieren:** Der Sammler wiederholt bei Sperre (0,4 / 0,8 s) und
   hält Stream-Zeilen zurück (`db_retry` / `db_locked` getrennt, Quellenzeile zeigt beides);
   der Recorder hält `whale_positions`-Zeilen zurück (`whale_positions_schreiben()`, Zähler
   `whale_write_deferred`) und schreibt sie beim nächsten Aufruf mit.

**Erwartung:** „verloren" bleibt bei 0, „wiederholt" zählt gelegentlich, der Poller meldet
keine Sperrfehler mehr. Bleibt der Fehler, hält ein Prozess die Datei länger als 60 s — dann
`PRAGMA wal_checkpoint`-Takte prüfen (Recorder, TRUNCATE) und lange Lesevorgänge des
Dashboards (Magnet-Varianten, Konto-Score) auf eine eigene, kurze Verbindung legen.
**Grundsätzlich** wäre ein einzelner Schreibprozess (Queue) die saubere Lösung; das ist ein
Umbau für eine eigene Sitzung.

## 3m. Schreibkoordination, professionell (`hl_dbcoord.py`, 14.09.)

3l („warten und wiederholen") genügte nicht — der Poller meldete weiter Sperrfehler, die
Drossel stand bei 60 % ohne echten Rückstand. Recherche (SQLite-Dokumentation, Mozilla
application-services, Praxisleitfäden): WAL erlaubt viele Leser, **einen** Schreiber; SQLite
reiht wartende Schreiber **nicht fair** ein (Busy-Handler fragt in wachsenden Abständen,
wer zufällig zuerst fragt, gewinnt); `BEGIN IMMEDIATE` verhindert den Snapshot-Fehler, aber
nicht das Verhungern. Das Muster für mehrere Schreibprozesse ist **Serialisierung auf
Anwendungsebene**: eine Sperre vor dem ersten schreibenden Statement bis zum Commit.

**Umsetzung:** `hl_dbcoord.KoordinierteVerbindung` (sqlite3.Connection-Factory) hält eine
prozessübergreifende Sperre (`fcntl.flock` auf `<db>.wlock`) vom ersten schreibenden
Statement bis Commit/Rollback, im Autocommit je Statement; `PRAGMA wal_checkpoint` läuft
darunter (Race-Bedingung in SQLite < 3.51.3 bei gleichzeitigem Schreiben und Checkpoint).
Wartefrist 20 s, danach entscheidet SQLites `busy_timeout` (gezählt als „Frist"). Angebunden:
Recorder, Binance-Dienst, Sammler, Coinbase. Kennzahlen je Prozess (Transaktionen,
Wartezeit Ø/max, Haltezeit Ø/max, Fristen, Haltezeiten über 1 s) in `meta.wlock_*` und im
Netzwerkstatus („Schreibkoordination: …"). Lesende Verbindungen (Dashboard, `mode=ro`)
bleiben unberührt.

**Nachweise:** 4 Prozesse × 300 Transaktionen bei `busy_timeout` 50 ms — ohne Koordination
6 Sperrfehler, mit 0, gleiche Dauer, längstes Warten 150 ms. Recorder-artiger Schreiber
neben dem Sammler: 0 Fehler, keine Zeile verloren, Haltezeit max 9 ms. Selbsttest 19/19.

**Dazu:** Drossel des Adress-Pollers nur noch bei echtem Rückstand (≥ 5 Konten über 3 h →
60 %, ≥ 15 → 30 %; ein bis vier Konten sind Alltag). **Fills alle 15 Minuten** statt
stündlich (`lb_fills_interval = 900`, bei Rückstand 10 min); Budget je Lauf rechnet sich aus
dem Takt. Kosten: ~75 Konten × 4 Läufe × ~25 Gewicht ≈ 125/min, aus der Reserve gedeckt.

**Woran es sich zeigt:** „Schreibkoordination" im Netzwerkstatus mit Fristen 0; keine
`database is locked` mehr im Fehlerfeld; Poller ohne Drosselhinweis; Fill-Median unter
10 min. Zeigt „hält max" bei einem Prozess Sekunden, hält dieser Prozess eine Transaktion
zu lange offen — dann dort committen, nicht die Sperre lockern.

## 3n. Kurze Transaktionen und dynamischer Takt (14.09., nach den ersten Sperrkennzahlen)

Die Kennzahlen aus 3m zeigten sofort das nächste Problem: Recorder **hält** die Sperre
Ø 1,8 s (max 6,4 s, 142× über 1 s je Stunde), Binance-Dienst Ø 3,2 s (max 12,4 s). Beide
hielten Transaktionen über Netzaufrufe hinweg offen — das Anti-Muster schlechthin:

| Stelle | vorher | jetzt |
|---|---|---|
| Recorder Poll-Runde | erster Schreibzugriff öffnet, Commit erst nach `gather` aller 26 Adressen | Puffer (Wal-Positionen, abgeleitete Liquidationen, Adress-Stände), `flush_round()` schreibt am Ende in **einer** Transaktion; bei Sperre bleiben die Puffer stehen |
| Recorder Fills | Schreiben je Konto, Commit erst nach allen 75 Konten (Sperre über den ganzen Lauf) | Commit je Konto |
| Binance-Stream | Einzel-INSERT, Commit alle 25 Ereignisse/10 s → Sperre bis 10 s beim Warten auf Nachrichten | Zeilen sammeln, alle 25/10 s `executemany` + Commit in Millisekunden; Flush beim Beenden |
| Binance Open Interest | INSERT je Symbol zwischen Netzabrufen, Commit am Ende | erst alle Abrufe, dann eine Transaktion |

**Erwartung:** „hält max" bei allen Prozessen unter 100 ms, „über 1 s gehalten" bleibt bei 0.

**Dynamischer Takt** (`dyn_takt`): Fills und Leaderboard-Stände laufen nach freiem Budget
statt fester Uhr — bei ≥ 45 % freiem Gewicht ein Viertel des Basistakts (Fills alle 4 min,
Leaderboard alle 90 s), bei ≥ 30 % die Hälfte, bei ≥ 15 % drei Viertel, sonst Basistakt.
Jeder Lauf nimmt weiterhin nur die freie Reserve. Kennzahlen `fills_takt_s`, `lb_takt_s`,
`budget_frei_pct` in den Stats.

**Nächster Schritt — bedarfsgesteuerte Warteschlange (Vorschlag des Nutzers, richtig):**
Statt vier Schleifen mit eigener Uhr ein Scheduler im Recorder: jede Abfrage (Adresse,
Konto-Fills, Orders, Leaderboard) ist ein Element mit **Nutzen** = Alter des Stands ×
Wichtigkeit (Konto-Score, Positionswert, Nähe zur Liquidation) und **Kosten** = Gewicht;
ein Token-Eimer mit 1.020 Einheiten je Minute; der Scheduler nimmt fortlaufend das Element
mit dem höchsten Nutzen je Gewichtseinheit. Damit verteilt sich das Budget von selbst dorthin,
wo es am meisten Information bringt, und alles ist so aktuell, wie das Budget erlaubt.
Das ersetzt Drossel, Stufen und Takte — ein Umbau der Recorder-Schleifen, für eine eigene
Sitzung, mit der Elite-Liste (`learn.elite`) als erster Wichtigkeitsquelle und den
WebSockets für die zehn besten Konten als Echtzeit-Ergänzung ohne Gewicht.

## 3o. Fills in Echtzeit aus dem Trade-Stream, Leaderboard alle 2 min (14.09.)

Anforderung des Nutzers: Fill-Median unter 2 Minuten, kontinuierlich abfragen, minütlich
schreiben. Rechnung: 75 Konten per REST alle 2 min = ~825 Gewicht/min — nicht bezahlbar.
Der Weg ohne Gewicht: Der Recorder empfängt bereits **jeden Trade** der sechs Coins per
WebSocket mit `users = [Käufer, Verkäufer]` (Doku, 14.09. geprüft), Preis, Größe, `tid`.
Für die beobachteten Konten sind das ihre Fills, in Echtzeit.

**Umsetzung (`hl_recorder.py`):** `on_trade` puffert Trades, an denen ein Konto der aktuellen
Leaderboard-Auswahl (`fill_konten`, bei jedem Leaderboard-Zyklus aktualisiert) beteiligt ist,
als `lb_fills`-Zeile mit `dir='stream'` (Seite B/A aus der Position im `users`-Paar, `buy`
entsprechend, closedPnl/fee 0). `run_stream_fills` schreibt sie **minütlich in einer kurzen
Transaktion** (Puffer bleibt bei Sperre stehen, Flush beim Beenden). Der REST-Abgleich
(`userFillsByTime`, Takt nach freiem Budget, min. 4 min) **löscht die Stream-Zeilen des
Kontos im geholten Zeitraum** und schreibt die vollständigen Fills — die `tid` beider
Quellen muss dafür nicht übereinstimmen. Konsumenten (Konto-Score, Smart-Flow) sehen
Stream-Zeilen nur bis zum Abgleich. Grenze: Fills in Coins außerhalb der sechs Projekt-Coins
kommen weiterhin nur per REST.

**Leaderboard-Stände:** `lb_interval` 300 → 120 s (bei freiem Budget 90 s); Kosten ~75/min.

**Anzeige:** „Fills live: Trade-Stream für n Konten, m Fills in der letzten Minute" und
getrennt „REST-Abgleich der Fills: Median …, Takt … nach freiem Budget · Leaderboard-Stände
alle … s". Meta-Schlüssel `stream_fills_min`, `stream_fills_konten`, `fills_takt_s`, `lb_takt_s`.

**Orders bleiben die teure Klasse** (20 Gewicht je Konto, `frontendOpenOrders`): alle 75 Konten
alle 2 min wären 750/min. Zwei Wege, beide brauchen den Score-Kanal zum Recorder: die zehn
Elite-Konten per WebSocket `orderUpdates` (0 Gewicht, im 10-Nutzer-Limit) und der Rest im
Stufentakt — oder der bedarfsgesteuerte Scheduler aus 3n, der Orders nach Nutzen je Gewicht
einreiht. Das ist der nächste Umbau.

**Geprüft:** Trade-Handler (Konto als Käufer → B/Kauf, als Verkäufer → A/Verkauf,
Fremdkonten ignoriert), minütlicher Schreiber mit Flush beim Stopp, REST-Abgleich ersetzt
Stream-Zeilen (Nachweis mit Datei-DB), Selbsttest 19/19.

## 3p. Die 600-Sekunden-Transaktion und die letzten langen Halter (14.09., 15:00)

Die Sperrkennzahlen zeigten „binance hält max 600.001 ms" — exakt zehn Minuten. Ursache:
`run_report` im Binance-Dienst schreibt Meta-Zeilen und committete **nicht**; der Commit
stand erst am Anfang der nächsten Runde, nach `sleep(600)`. Zehn Minuten offene
Transaktion, alle zehn Minuten, seit Wochen — vor der Koordination hielt das genauso SQLites
Schreibsperre. Sehr wahrscheinlich die eigentliche Quelle der „database is locked"-Fehler
des Recorders von Anfang an. **Behoben:** Commit direkt nach dem Schreiben.

**Diagnose statt Raten:** `hl_dbcoord` merkt sich je Transaktion das eröffnende Statement
und hält die fünf längsten (ab 0,2 s) vor; der Netzwerkstatus zeigt sie: „längste: 6,3 s
‚INSERT OR REPLACE INTO heatmap …'". Damit ist jeder lange Halter benannt.

**Gestückelt (Recorder):** stündlicher Adress-Flush (bis zu 50.000 UPDATEs), Heatmap-
Schnappschuss, Leaderboard-Positionen → `stueckweise()`: 2.000 Zeilen je Transaktion,
Sperre dazwischen frei (Probe: 12.000 Zeilen in 8 Transaktionen, max 5 ms). Aufräum-
Deletes (lb_events, lb_positions, lb_fills, lb_spot) → `loesche_stueckweise()`: nach
Zeitfenstern von 6 h Datenzeit je Transaktion (funktioniert auch für WITHOUT-ROWID-
Tabellen); neuer Index `lb_events(ts)`.

**Zum Fill-Median:** Die Zeile „REST-Abgleich der Fills: Median 35 min" misst das Alter des
REST-Abholstands, nicht das Alter der Daten. Die Fills selbst kommen seit 3o aus dem
Trade-Stream in Echtzeit („Fills live"). Damit das nicht mehr missverständlich ist, zeigt die
Zeile „Fills live" jetzt zusätzlich Fills der letzten 10 Minuten und Gesamtzahl seit Start,
und der Abgleich heißt ausdrücklich „Nachtrag von closedPnl/fee/dir". Der REST-Takt folgt
weiter dem freien Budget (bei 84 % Auslastung = Basistakt 15 min); er ist kein Maß für die
Aktualität mehr.

**Erwartung nach dem Einspielen:** binance „hält max" unter 100 ms; recorder „über 1 s
gehalten" nahe 0; „Fristen überschritten" 0; keine `database is locked` mehr.

## 3q. Nachlese der Diagnose (14.09., 15:00): book_summary im WebSocket-Handler

Die neue Anzeige der längsten Transaktionen zeigte sofort den nächsten Halter: „2,985 s
‚INSERT OR REPLACE INTO book_summary'". `on_book` (WebSocket-Handler des HL-Buchs) schrieb
direkt in die Datenbank; die Transaktion blieb bis zum nächsten Commit der Poll-Runde offen.
Jetzt puffert `on_book` den jüngsten Stand je 5-s-Fenster und Coin, `flush_round` schreibt
ihn mit. Der seltene Tick-Dump bei Kaskaden committet sofort. Statement-Texte in der Anzeige
enden nicht mehr mitten im Wort („misses=miss"), sondern zeigen Aktion und Tabelle.

**Lesehinweise für die Kennzahlen:** `wlock_binance` wird nur alle 10 min geschrieben — nach
einem Neustart des Binance-Dienstes zeigt die Kachel bis dahin den alten Wert (600.001 ms).
„Fills live … seit Start" zählt seit dem Neustart des Recorders; „Stream liefert n Trades/min
mit Adressen" belegt, dass der Trade-Stream Adressen liefert — ist das > 0 und bleiben die
Fills über Stunden bei 0, ist die Zuordnung der Konten das Problem, nicht der Stream.

## 3r. Auditbericht v3 (Kimi K3, 14.09.) — Umsetzung

Alle sechs MEDIUM-Befunde am Code bestätigt und behoben, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| D1 Fill-Cursor springt nach Netzfehler hinter voller Seite auf „jetzt" | `fehler`-Flag; Teilseitenregel nur bei sauberem Ende | Logik nachvollzogen |
| D2 hl_ext `schreibe()` ohne Rollback → Transaktion + flock offen | Rollback bei **jedem** `sqlite3.Error`; Nicht-Sperrfehler zählen statt werfen | Fehlversuch → `in_transaction` False, Sperre frei |
| D3 hl_binance `puffer_schreiben()` dito | Rollback vor allem anderen, Fehler gezählt | — |
| D4 OKX-Ratenlimit sperrt Coin 24 h | sperren nur bei 51001 | 50011 → nicht gesperrt; 51001 → gesperrt |
| D5 Crypto.com leere Liste sperrt | sperren nur bei 40004/40003 | leere Liste (code 0) → nicht gesperrt |
| D6 Bybit-Puffer bei Abbruch verloren | Puffer außerhalb der Verbindung, Flush im `except`; Themen je Verbindung neu (L8) | Abbruch nach 2 Liquidationen → 2 gespeichert |

LOW umgesetzt: L1 (Sperr-Sentinel je Transaktion), L2 (Recorder: 20 Versuche Symbolauflösung,
dann Exit 1), L3 (tote `schreibe()` entfernt), L4 (leerer Stapel flusht Puffer), L5 (Coinbase
120-s-Empfangs-Timeout), L6 (CDC-Spanne vorzeichenfrei), L7 (Farside „–" übersprungen), L9
(OKX-uid in ms), L10 (Zählung unter dem Schloss), L11 (Sperrdatei nicht öffenbar → Zähler +
Meldung), L12 (`con.close()` im finally), L13/L15 (Doku), L14 (Hinweis), L16 (`--ws-sekunden`).
Offen: L17 (Lint, kosmetisch).

**Datenhaltung (S1–S8) — die eigentliche Erkenntnis des Berichts:**

| # | Umsetzung |
|---|---|
| S1 | `lb_stats_hist` (PK addr, ts): jede Stunde PnL/ROI/Umsatz je Konto, unbegrenzt; `lb_stats` bleibt der jüngste Stand |
| S2 | `lb_pos_hourly`: je volle Stunde die Positionen der Leaderboard-Konten, unbegrenzt |
| S3 | `lb_fills_daily`: vor dem Löschen je Tag/Konto/Coin Kauf-/Verkaufsnotional, n, closedPnl, Gebühren (Probe: Summen korrekt) |
| S4 | `forecast_drivers` (ts, coin, name, score) und `forecast_slim` (ts, coin, price, bias, p_4h…p_168h, p_up, p_up_24) in forecasts.db, **unbegrenzt**; Prognosezeilen mit Payload weiter 60 Tage |
| S5 | `score_forecasts` bewertet **72 h und 168 h** aus `forecast_slim` (ein Fall je Stunde, n_eff = getrennte Blöcke); Kachel zeigt sie als „unkalibriert (Drift ohne gelernte Gewichte)" |
| S6 | `book_summary` älter als 14 Tage → Minutenmittel `book_summary_1m`, täglich nach dem Backup, in 6-h-Fenstern (Probe: 14.400 Zeilen → 1.200, max 25 ms Sperre) |
| S7 | Coinbase `BARS_DAYS` 30 → 180 |
| S8 | Binance `premiumIndex` alle 5 min in `bnc_metrics` (`funding`, `basis_bps`) |

**Noch nicht:** Die Kalibrierung liest weiter die Payloads der 60-Tage-Prognosezeilen; für eine
lernende 168-h-Spur muss `calibrate_weights` auf `forecast_drivers` umgestellt werden — sinnvoll,
sobald dort einige Wochen liegen. Selbsttest 19/19, Nulltest grün.

**Indikatoren (Abschnitt 3 des Berichts):** Entscheidung mit dem Nutzer — siehe Gesprächsnotiz.
Vorschlag der Reihenfolge: N3 OI-Perzentil, N7 Crowding-Extreme, N8 ETF-Momentum, N9 Vol-Regime
(als Kontext, nicht Richtung), N1 Funding-Spread (Daten seit S8), N6 Liquidations-Imbalance
(Bybit vollständig), Varianz-Kompression aus `bars10` (Regime-Flag). Jeder mit Prior 0,3–0,5,
Nulltest-Pflicht, Killkriterium; keiner ersetzt einen bestehenden Treiber.

## 3s. Neue Indikatoren nach Auditbericht v3 — Entscheidungen des Nutzers (14.09.)

Entscheidungen: (1) N3/N7/N8/N9/N1 sofort, (2) N6 und Varianz-Kompression ebenfalls, (3) Priors
von Taker/Funding/Buch unverändert — die Kalibrierung entscheidet, (4) Horizont Stunden bis
vier Wochen.

**Neues Modul `hl_indikatoren.py`** (reine Funktionen auf der Hauptdatenbank, None bei zu
wenig Daten → Treiber erscheint nicht):

| Treiber / Flag | Quelle | Form | Prior |
|---|---|---|---|
| OI-Überhitzung | `bnc_metrics.open_interest` (sonst `ctx_bars.oi`), Perzentil 90 T | ab 90. Perzentil leichter Kontra (−0,6 × Überhitzung); zugleich Regime | 0,3 |
| Crowding-Extrem | `lb_trend` (Top-20, unbegrenzt), Perzentil 365 T | unterstes Dezil → +1, oberstes → −0,5 (asymmetrisch wie die Studie) | 0,5 |
| Crowding-Trend 7 T | dito | Δ 7 T normiert an der Verteilung solcher Änderungen, tanh | 0,4 |
| ETF-Momentum | `etf_flows` (seit 3i) | (3-T-Mittel − 10-T-Mittel) / σ, tanh; nur BTC/ETH | 0,5 |
| Vol-Spike-Reversion | `bars` (Parkinson-σ 24 h gegen 20 T) | ab 1,5× Norm gegen die 24-h-Bewegung; Verhältnis ist zugleich Band-Multiplikator 0,7–1,6 | 0,3 |
| Funding-Spread | `ctx_bars.funding` gegen `ext_metrics.funding_8h` + `bnc_metrics.funding` (seit S8) | Perzentil des Spreads 30 T, Kontra (Carry) | 0,4 |
| Liquidationsdruck (3 Börsen) | `bnc_liquidations` + `ext_liquidations` + `liquidations` | Imbalance × Intensität (2 h gegen 30-T-Perzentil); Intensität zugleich Regime | 0,5 |
| Taker-Varianz-Kompression | `bars10` (Varianz der 10-s-Salden je Stunde, 30-T-Verteilung, Tages-Cache) | **nur Regime** (unterstes Dezil → Band +20 %) | — |

**Regime** = Band-Multiplikator aus Vol-Verhältnis × (1 + 0,25·OI-Überhitzung) × (1 + 0,25·
Liquidationsintensität) × (1 + 0,2·Varianz-Kompression), gedeckelt 0,7–2,2; steht im Payload
(`regime`) und als Zeile über der Treibertabelle. Es verschiebt keine Richtung.

**Nulltest:** neue Zeile „Neue Indikatoren auf Rauschen" — alle sieben Funktionen liefern auf
synthetischem Rauschen ein Ergebnis, Scores in [−1, 1], Band nahe 1. (Ein echter Vorzeichen-
Bias-Test über viele Zeitpunkte ist mit „jetzt"-lesenden Funktionen nicht möglich; die
Kalibrierung mit Killkriterium übernimmt das im Betrieb.) Selbsttest 19/19.

**Was auf dem Pi zuerst erscheint:** Vol-Spike-Reversion und Liquidationsdruck (Daten da),
OI-Überhitzung (13 Tage Binance-OI), Crowding (lb_trend seit Sitzung 1). Funding-Spread braucht
3 Tage `ext_metrics`, ETF-Momentum 12 Tage `etf_flows` (der Farside-Import bringt die Historie
mit, also sofort). Erwartung an die Kalibrierung: nach 2–4 Wochen zeigt die Treibertabelle, wer
trägt — die Priors sind klein genug, dass ein Nichtträger nichts verdirbt.

## 3t. Auditbericht v4 (15.09.) — Umsetzung

Fix-Quote v3 laut Audit 27/27. Neue Befunde: 5 MITTEL, 10 NIEDRIG — alle umgesetzt, mit Proben:

| Befund | Korrektur | Probe |
|---|---|---|
| M1 `_rank` strikt „<": Plateau → Perzentil 0 → Vollsignal (Crowding +1, Funding ±1, Varianz-Band +20 %) | Midrank (Bindungen halb); konstante Reihe → None | konstant → None; Median mit Bindungen 0,46 statt 0,31 |
| M2 Liquidationsintensität gegen verdoppelte Einzelstunden (Varianz falsch) → Trigger 6 % statt 10 % | Referenz aus echten rollierenden 2-h-Summen | Nulltest |
| M3 `book_summary_verdichten` synchron auf der Ereignisschleife | `book_summary_verdichten_datei()` in `asyncio.to_thread` mit eigener koordinierter Verbindung | 1.440 Zeilen im Thread verdichtet |
| M4 `lb_fills_daily` doppelt nach Absturz; Löschung trotz Aggregationsfehler | `fills_verdichten_und_loeschen()`: je 6-h-Fenster Aggregat + Löschung in **einer** Transaktion, Rollback bei Fehler, keine Löschung ohne Aggregat | zweiter Lauf 0 Zeilen, Summe exakt; Zieltabelle fehlt → 0 gelöscht, Zeilen erhalten |
| M5 Restore startete Dienste mit kaputtem Stand | Syntaxfehler → gesicherter Stand (`_rueck`) wird zurückgespielt, dann Start | kaputtes `hl_score.py` im Backup → nach Restore wieder gültig |

LOW: L1 OI-Quellenwahl mit Frische (Binance frisch & lang genug, sonst HL), L2 Funding-Spread je
Quelle ein try, L3 ETF-Frische 4 Tage, L4 gemessene Stunde nicht in der Varianz-Referenz,
L5 Rollback in den neuen Fehlerpfaden, L6 Einfügen + Löschen je Fenster in einer Transaktion,
L7 Regime-Zeile vor der Tabelle, L8 `/restore/info` im 30-s-Antwort-Cache, L9 `n_fremd` zählt
Börsen, L10 `run_oi` fängt `sqlite3.Error`; Kommentar premiumIndex-Endpunkt. S2-Hinweis: `lb_pos_hourly`
ist der Schnappschuss des ersten Zyklus je Stunde, kein Stundenmittel. Offen bleibt L17 (Lint).

Nulltest grün, Selbsttest 19/19. Die vom Audit empfohlene Umstellung der Kalibrierung auf
`forecast_drivers` (inkl. 72/168-h-Training) steht wie geplant an, sobald 8–12 Wochen vorliegen.

## 3u. Elite-Positionierung geprüft (15.09., `check_elite.py`)

Anlass: −0,95 gegen Smart Money +0,77. Werkzeug „Elite-Positionierung prüfen" (Debug, gewählter
Coin, mit Live-Abfrage): Elite-Konten mit Score, Klassen kontoweit/im Coin, n, Vorlauf, Position
aus lb_positions und whale_positions mit Alter, Widersprüche („≠"), Live-Stand („WEICHT AB"),
Dominanz, Treiber alt/neu, Smart Money aus demselben Schnappschuss.

**Befund auf dem Pi:** Daten korrekt (alle zehn live bestätigt, ein Zeitstempel, close → flat).
Der Gegensatz ist echt: Smart Money = Top-50 nach Leaderboard-Gewinn (17 long 387 Mio); „Elite" =
fast nur Wale außerhalb des Leaderboards mit 1–7 Schritten in BTC, Score aus Größe/Klasse, nicht
aus belegtem Vorlauf; einziges belegtes Konto (n=140) hält 51 % des Bruttowerts short.

**Korrekturen:** (1) `hl_score.elite()`: Mitglied nur mit ≥ 10 Schritten im Coin und positivem
Vorlauf (`ELITE_MIN_SCHRITTE`). (2) Treiber zählt nur im Coin direktionale Konten (Leaderboard-
Gruppe; Wale ohne Eintrag nur bei Klasse 1,0). (3) Dominanz-Dämpfer clip((1−anteil)/0,5, 0,5, 1).
Erwartung: Der Treiber fehlt zunächst häufig („zu wenige direktionale Elite-Positionen") — das
ist ehrlich; er erscheint, sobald genug Konten Beleg haben. Die Elite-Liste speist auch die
WebSocket-Kandidaten (Konzept 2.5): dort gilt dieselbe Schwelle.

## 3v. Treiber-Funktionstest (`check_treiber.py`, 15.09.)

Für alle 30 Treiber und die Regime-Flags kontrollierte Szenarien mit bekanntem Ergebnis:
aufwärts (positiv, Betrag nach Formel), abwärts, Sättigung, und wo es Bedingungen gibt, gesperrt
(zu wenig Konten/Umsatz, Spanne < 60 s, Dienst aus, Plateau, veraltet). 72 Prüfungen, alle
synthetisch und in-memory; Teil des Selbsttests (jetzt 20 Schritte) und als Debug-Eintrag
„★ Treiber-Funktionstest" mit anschließender Plausibilität auf der echten Datenbank (welche
Treiber liegen an, mit welchem Score und Gewicht, warum fehlen andere).

Was der erste Lauf nebenbei klargestellt hat (keine Fehler, aber Eigenschaften, die man kennen
muss): Smart-Flow gewichtet ALLE Konten mit Score > 0 — ein schwaches Konto (0,2) zählt mit
kleinem Gewicht mit; das Kapitulationssignal wird im Lernzyklus berechnet und über `learned`
übergeben (compute_forecast rechnet es nicht selbst); Elite-Positionierung braucht drei zählbare
Positionen; ein OI-Plateau von 30 Stunden am Rekord ergibt per Midrank ü ≈ 0,77, nicht 1.

## 3w. Fund des Treiber-Tests auf dem Pi: „Direktionale Wale" war nicht je Coin (15.09.)

Die Plausibilität in `check_treiber.py --db` zeigte für BTC und ETH identische Zahlen (51 long
1.281 Mio gegen 59 short 1.451 Mio, 110 Wale). Ursache: In `load_whales` hat die Abfrage der
aktuellen Positionen keinen Coin-Filter (für die Wal-Tabelle gewollt), und die Richtungs-
Zusammenfassung `directional` wurde daraus über ALLE Coins gebildet — seit Sitzung 1. Ein Wal
mit BTC long und ETH long zählte doppelt, einer mit BTC long und ETH short fiel als „zwei
Seiten" heraus. **Korrektur:** Zusammenfassung nur aus Zeilen des Coins, Klasse je Coin über
`behavior_per_coin` (Gruppen dir und mixed zählen, hedge/mm nicht — dieselbe Konvention wie
`lb_groups(coin)` bei Smart Money). Regressionsprobe im Treiber-Test (BTC ≠ ETH). Der
Treiber „Direktionale Wale" hat damit eine neue Datenbasis; seine bisherige Trefferbilanz gehörte
zu einem anderen Signal. Dazu: `hl_viz.Handler.db` wird im Plausibilitätslauf gesetzt (keine
Thread-Fehler der Hintergrundlader mehr).

## 3x. Elite-Positionierung, zweite Prüfung (15.09., 15:18): −1,00 ist korrekt gerechnet — und ein Momentum-Proxy

Nach der Beleg-Regel (n ≥ 10, Vorlauf > 0) bestand die Elite aus zehn Walen, alle kontoweit
direktional, alle live bestätigt; acht davon short (4–48 Mio), zwei flat; größtes Konto 38 %
(kein Dämpfer). Score −1,00 ist damit richtig: acht belegte Konten, einstimmig short. Smart
Money (Top-50 nach Gewinn) zugleich +0,85.

**Zwei Erkenntnisse:** (1) Der Beleg war schwach — Vorläufe von +0,01 bis +0,24 %/4 h ohne
Signifikanzprüfung; ein Vorzeichen ist kein Beleg. Jetzt zusätzlich `ELITE_MIN_T = 1.0`
(t-Wert des 4-h-Vorlaufs). (2) **Selektionseffekt:** Der Vorlauf misst die Rendite nach den
eigenen Schritten im 28-Tage-Fenster. In einem fallenden Markt sammeln genau die Konten
positiven Vorlauf, die short waren — und die halten weiter short. Die Elite-Positionierung ist
dadurch strukturell mit dem jüngsten Trend korreliert (ein Momentum-Proxy), nicht unabhängig
davon. Kein Rechenfehler, aber die Lesart, die man kennen muss; ob sie Vorhersagewert hat,
zeigt die Kalibrierung. Werkzeug `check_elite` zeigt jetzt den t-Wert je Konto und meldet eine
leere Elite ausdrücklich.

## 3y. Elite-Kanal zum Poller (15.09., nach zwei „WEICHT AB" im Prüflauf)

`check_elite --live` fand zwei Konten, deren Datenbankstand vom Live-Stand abwich: eines hatte
vor Minuten geschlossen (Leaderboard-Schnappschuss 12 min alt, Poller sah nur die Reduktion),
eines hatte nach einem „close" einen 9-Mio-Short eröffnet, den der Poller **18 Stunden** nicht
sah — wer flat geht, fällt in die niedrigste Abfragestufe, auch ein Elite-Konto. Das ist der
Score-Kanal aus Konzept 2.4/2.5, jetzt in der einfachsten Form:

- Dashboard speichert die Elite je Coin in `forecasts.db` (`learned`, Schlüssel `elite`).
- Recorder liest alle Elite-Listen alle 5 min (`lade_elite`, read-only) und fragt diese Konten
  im **Wal-Takt** (jede Minute) ab, unabhängig vom Positionswert (`due_addresses`, Stufe A).
- Probe: flates Elite-Konto wird fällig, normales flates Konto nicht, Wal weiterhin.
- Elite-Regel jetzt mit t ≥ 1,0 (`ELITE_MIN_T`); `check_elite` zeigt t je Konto und warnt bei
  einem Schnappschuss älter als 5 min. Die „Nicht aktiv"-Zeile unter der Treibertabelle nennt
  jeden fehlenden Treiber mit Grund.

Nächste Stufe bleibt der WebSocket für die zehn besten Konten (0 Gewicht, Echtzeit).

## 3z. Statuszeilen richtig gestellt (15.09., Bild des Netzwerkstatus)

- **Snapshots „0 Zeilen je Durchgang":** Anzeigefehler, kein Datenfehler. Der Zähler
  `snapshot_rows` wurde nie gesetzt. Jetzt: „N Heatmap-Zeilen aus M Positionen, K zu alt
  ausgelassen". Der Snapshot ist der 10-min-Heatmap-Schnappschuss (Liquidationspreise aller
  Positionen im 0,25-%-Raster) plus Abdeckung, Wal-Zeitreihenpunkt, Order-Niveaus, Stempel.
- **„Gewichte prüfen vor 50 h":** zeigte das letzte SCHREIBEN der Gewichte; geprüft wird alle
  15 min, geschrieben nur ab n_eff 40. Jetzt Zeitpunkt der Prüfung (`learned` Schlüssel
  `weights_check_<h>`), im Text n_eff und ob gelernt wurde.
- **„Leaderboard-Stände vor 20 min" (Soll 90–120 s):** Ursache die Fill-Läufe von 709 s bei
  4-min-Takt — Rücken an Rücken, dauerhaft Gewicht, der Leaderboard-Zyklus wartete am
  Begrenzer (273 s je Zyklus). Jetzt Pause mindestens so lang wie der letzte Lauf; seit dem
  Trade-Stream sind Fills ohnehin in Echtzeit, der REST-Abgleich darf warten.

## 3aa. Begrenzer mit Rang (17.09.) — Ursache der Verzögerungen

Die neue Phasenzeile zeigte: „75 Konten abgefragt 280 s (davon Warten am Begrenzer …)". Die
Arithmetik: Budget 1.020/min; Poller 320 Abfragen × 2 = 640, Wal-Orders 320 → 960 = 94 % per
Konfiguration; für Leaderboard-Stände (150 je Zyklus) und Fills (1.600 je Lauf) blieben 60/min
→ 280 s bzw. 660 s. Und der Begrenzer war eine FIFO-Sperre: die 2-Gewicht-Abfrage der 75
wichtigsten Konten stand hinter jeder 20-Gewicht-Orderabfrage an.

**Korrektur:** `RateLimiter` als Warteschlange mit Rang (Heap, Verteiler-Task): Rang 0
Leaderboard, 1 Poller/Orders/sonstiges, 3 Fills (`PRIO_BY_QUELLE`). Probe: Fills sättigen das
Budget, Leaderboard-Abfragen warten Ø 0,13 s statt Minuten; Durchsatz exakt am Budget.
Wartezeit je Rang (`limiter_wait_by`) in den Stats; Statuszeilen zeigen die eigene Wartezeit
(Leaderboard: Rang 0; Fills: Rang 3). Budgetanteile: `--polls-per-min` 320 → 280,
`stop_weight_budget` 320 → 240 — damit bleiben ~160/min für Fills (ein Lauf ~10 min) statt null.
Erwartung nach dem Einspielen: Leaderboard-Stände wieder alle 90–120 s mit Zyklen < 30 s.

## 3bb. Reserve für den Hintergrund (17.09., 05:00): Fills verhungerten am Rang

Nach dem Rang-Begrenzer fehlte die Zeile „Leaderboard-Fills" im Zeitplan: Der Lauf war seit dem
Neustart nicht fertig geworden — Rang 3 bekam bei 80 % Auslastung durch Poller/Orders nur Reste.
**Korrektur:** eigener Reserve-Eimer (`RESERVE_ANTEIL` 15 % ≈ 150/min), aus dem nur Rang ≥ 2
schöpft; der Haupteimer schrumpft um denselben Anteil, die Summe bleibt am Budget. Probe unter
Volllast: Rang 3 bekommt 31 % (Reserve + Reste), Rang 0 wartet Ø 0,03 s. Das Fill-Laufbudget
rechnet die Reserve als garantiert frei. Dazu Fortschritt während des Laufs („läuft: 30/75
Konten, 812 Gewicht bisher") alle zehn Konten — die Zeile fehlt nie mehr.

## 3cc. Deckel 90 %, Fill-Reserve 20 % (17.09., Vorschlag des Nutzers)

Der Recorder deckelte sich bei 85 % von 1.200 (1.020/min) — ein Sicherheitsabstand aus der Zeit
vor der exakten Gewichtszählung; 429 stand seit Wochen bei null. Jetzt 90 % (1.080/min), und die
fünf Punkte gehen an die Fill-Reserve: `RESERVE_ANTEIL` 0,15 → 0,20 = 216/min nur für Rang ≥ 2.
Haupteimer 864/min für Leaderboard/Poller/Orders. Ein Fill-Lauf von 1.600 Gewicht dauert damit
~7,5 min. Wächter (`API-Budget`) und Farbe der Ratengrenze warnen erst über 91 %, kritisch über 97 %.

## 3dd. Reserve als Garantie, nicht als Ausschluss (17.09., Bild: Plateau bei 930)

Nach 3bb/3cc lag die Auslastung bei ~930 statt 1.080: Die Fill-Reserve (216/min) war NUR für
Rang ≥ 2 nutzbar und lag brach, sobald kein Fill-Lauf lief — also die meiste Zeit. Jetzt ist
die Reserve arbeitserhaltend: Wartet ein Hintergrund-Aufruf, bekommt er sie zuerst (Garantie);
wartet keiner, dürfen Leaderboard/Poller/Orders sie verbrauchen. Probe ohne Hintergrund:
Budget voll genutzt; mit Hintergrund: Rang 3 ≥ 216/min, Rang 0 wartet Ø 50 ms (Verteiler-Körnung
50 ms statt 250 ms). Dazu: Orders zurück auf 320/min (16 Konten je Minute), die Fill-Pause
„mindestens so lang wie der letzte Lauf" ist weg — Rang und Reserve machen sie überflüssig.
Erwartung: durchgehend ~1.050–1.080/min, Wal-Orders wieder im Minutentakt, Fills alle
4–15 min nach freiem Budget.

## 3ee. Analyse v6 (17.09.) — Budget kam nicht bei 1.080 an: umgesetzt

Externe Analyse mit Simulation, beide Hauptbefunde am Code bestätigt:
- **U1** Init-Klammer `min(1080, 280·2+320+60)` = 940 → Angebot lag 13 % unter dem Deckel (das
  Plateau ~930). **Fix:** `RateLimiter(int(1200·0,90))`; die Erzeuger begrenzen sich selbst.
- **U2** Verteiler prüfte nur die acht vordersten Wartenden; hinter 23 parallelen Poller-Abfragen
  lag ein Fill-Aufruf nie im Fenster, die Reserve verfiel (simuliert: 752/min, Fills 2 in 75 s).
  **Fix:** ganzer Heap; Vordergrund darf die Reserve oberhalb des sofortigen Hintergrund-Bedarfs
  (`bg_bedarf`) nutzen. Probe: Gemisch mit 23 parallelen Wartenden + Fills → Angebot voll genutzt,
  Fills 240/min ≥ 216, Rang 0 Ø 43 ms.
- Empfehlungen: Leaderboard-Positionen parallel in Stücken à 6 (Zyklus ~15 s statt 60 s),
  feste Pacer (0,2/0,3 s) entfernt, Orders-Runde nach **Gewicht** bemessen (Multi-Dex-Wale
  kosten (1+n)·20) und Takt 60 s abzüglich Arbeitszeit, Fill-Budget aus dem realen Takt,
  8-s-Timeout für 2-Gewicht-Abfragen, `weight ≤ capacity` (V5-M4), `api_weight_budget` =
  effektiver Deckel (thermisch skaliert) plus `api_weight_limit` = 1.200.
- Anzeige/Wächter: Chart zeigt rote Linie Limit und gelbe Linie Deckel; Ratengrenze in % des
  Deckels und des Limits; Wächter warnt gegen das Limit (≥ 93 %), nicht gegen den Deckel.
- **„Wal-Orders" heißt jetzt „Orders (Konten ≥ 250k)"** und nennt die Stufen der fälligen Konten
  („fällig: Wale ≥ 20 Mio 9, 5–20 Mio 41, 1–5 Mio 300, 0,25–1 Mio 1.604"): die 1.954 waren nie
  Wale, sondern alle fünf Größenstufen; die kleinen laufen nur nach, wenn Budget übrig ist.
Selbsttest 20/20.

## 3ff. Acht Tabs = 99 % CPU (21.09.) — drei Maßnahmen und Bug-Prüfung

Ursache bestätigt: offene Browser-Tabs; jeder pollte Chart (5 s) und Daten (20 s).
1. **Unsichtbare Tabs pausieren** (`document.visibilityState`): alle Intervalle prüfen die
   Sichtbarkeit; beim Sichtbarwerden lädt der Tab einmal komplett nach. Browser-Probe: verborgen
   12 s → höchstens eine nachlaufende Abfrage, sichtbar sofort wieder.
2. **Chart-Antwortcache 5 s** je Coin/Quelle (vorher 4 s).
3. **CPU je Dienst** in der Systemkachel: PIDs über `systemctl show MainPID` (sonst /proc-
   Kommandozeilen), utime+stime aus `/proc/<pid>/stat`, Differenz je Messung, Prozent eines Kerns;
   rot ab 150 %, gelb ab 80 %; Summe gegen Kerne × 100 %. Erste Werte nach der zweiten Messung (60 s).

Bug-Prüfung danach: Selbsttest 20/20, Treiber-Test 73/73, JS-Syntax, statische Namensprüfung
(alle Module: keine undefinierten Namen). Gefunden und behoben: die parallele Leaderboard-
Schleife (v6) brach nach `lb_top·2` Kandidaten ab statt bis zum Ziel „lb_top Konten mit
Position" zu laufen (nach einem Neustart mit leerem Flat-Cache hätte sie < 75 Konten geliefert)
— jetzt lazy in Stücken bis zum Ziel; tote Variable `per_round` entfernt.

## 3gg. hl_viz auf drei Kernen (21.09., Kachel „CPU je Dienst": viz 313 %) — Ursache und Korrektur

Ein Python-Prozess kann mit Python-Code kaum mehr als einen Kern auslasten (GIL); 313 % heißt:
SQLite in parallelen Threads. Ursache im Code: der **Ereignis-Auslöser** der Prognose (30-s-Thread)
feuerte bei JEDEM Wal-/Leaderboard-Ereignis mit 120 s Mindestabstand — seit die Leaderboard-
Stände alle 2 min kommen, gab es alle 2 min eines: sechs volle Prognosen je 2 min statt je 15.
Multipliziert mit den seit 14.09. schweren Prognosen: Liquidationsdruck holte 30 Tage Rohzeilen
aus drei Tabellen (Bybit-Stream: tausende je Stunde), und die Varianz-Kompression löschte je
Coin den Cache ALLER Coins (`_VAR_CACHE.clear()`) — jede Prognose rechnete 259k bars10-Zeilen neu.

**Korrekturen:** Auslöser nur bei Ereignissen ≥ 1 Mio USD (delta_usd) und Mindestabstand
5 min je Coin; Varianz-Cache je Coin; Liquidationsdruck als SQL-Stundensummen (GROUP BY) statt
Rohzeilen (720 Zeilen statt hunderttausenden). Dazu `/debug/threads` (Stack jedes Threads) und
der Debug-Eintrag „Dashboard-Threads" (drei Proben über 10 s, häufigste Stellen) — damit die
nächste Last in Sekunden benannt ist. Erwartung: viz < 60 % eines Kerns.

## 3hh. Elite leer im Dashboard, zehn Konten im Werkzeug (21.09.) — der fehlende t-Wert

`check_elite` fand zehn Konten mit n ≥ 11, Vorlauf > 0, t 1,0–3,5; das Dashboard meldete
„Elite leer". Ursache: Die Elite-Regel liest `t_4h`, aber der Lernzyklus reichte nur
score/comps/klasse/n/alpha_4h weiter (kompakter Stand), und `load_scores` las den Wert nicht
aus der `payload`-Spalte — `t_4h` war im Dashboard immer None → jedes Konto ausgeschlossen.
Folge zweiter Ordnung: Ohne Elite wurde keine Liste nach forecasts.db geschrieben, der Elite-
Kanal des Pollers blieb leer (ein Konto 22 h veraltet, „WEICHT AB"). **Korrektur:** `t_4h` im
kompakten Stand und in `load_scores` (aus `payload`); Probe: gespeichert, geladen, Elite = das
Konto mit t 2,4, nicht das mit 0,4. Nach dem Einspielen erscheint die Elite mit dem nächsten
Lernzyklus (≤ 15 min), der Poller-Kanal füllt sich mit dem nächsten Tageslauf.

## 3ii. Gewinn-Schranke für die Elite und Logikprüfung des Scores (21.09.)

Befund des Nutzers: BTC steigt seit vier Wochen, die Elite ist 202 Mio short. Ursache: Der
4-h-Vorlauf ist driftbereinigt — Richtung × (Rendite − Drift). Ein Long bekommt für den Anstieg
keinen Punkt (er muss die Drift schlagen); ein Konto, das in Spitzen verkauft, hat positiven
Vorlauf, weil der Kurs nach Spitzen kurz unter der Drift bleibt — und liegt mit seinem Short
trotzdem tief im Minus. Entscheidung: Das 4-h-Timing bleibt (erkennt, wer vor Korrekturen
verkauft und vor Anstiegen kauft), aber **Timing ohne Gewinn ist keine Elite**.

**Gewinn-Schranke** `hl_score.gewinn_filter(con, coin, addrs)`: (1) Leaderboard-Gewinn 30 T
(`lb_stats.pnl_30d`), falls vorhanden, muss > 0 sein; (2) gehaltene Position im Coin
(jüngster Leaderboard-Stand, sonst jüngstes Poller-Ereignis inkl. `snap`) höchstens 3 % unter
Wasser (`upnl / pos_value ≥ −ELITE_MAX_VERLUST`). `elite(..., gewinn=…)` schließt Verlierer aus;
Lernzyklus wendet sie an, `check_elite` zeigt uPnL % und PnL30 je Konto und nennt Ausgeschlossene.
Probe: Short 9 % unter Wasser raus, Leaderboard-Verlierer raus, Long +6 % bleibt.

**Logikprüfung des Scores, weiterer Fund:** Die Folgerendite eines Stundenblocks begann beim
ERSTEN Schritt der Stunde, obwohl die Nettorichtung erst durch spätere Schritte entstand — bis
zu 59 min Kurs vor dem entscheidenden Schritt zählten mit (milde Rückschau). Jetzt beginnt das
Fenster beim LETZTEN Schritt der Stunde (konservativ, rückschaufrei). Geprüft und in Ordnung:
Vorzeichen des Vorlaufs, Ausschluss der `snap`-Ereignisse, neutrale Ränge (0,5) für fehlende
Leaderboard-Kennzahlen, Frische der `upnl` über die 10-min-Snap-Zeilen. Bekannte Grenze:
`pnl_30d` ist kontoweit, nicht je Coin.

## 3jj. Audit der Bewertungslogik und Stufe 1 (21.09.)

Audit ohne Änderung (Ergebnis in `PROPOSAL_Kalibrierung_Stufe2_3.md`, Abschnitt 1.3): zwei
Fehler (F1 Regularisierung zum Prior — das „Killkriterium" existiert nicht; F2 Nenner von P(auf)
konstant), drei Schwächen (korrelierte Treiber addiert, keine Inversion, Bilanz in-sample ohne
Basisrate). Entscheidung des Nutzers: stufenweise.

**Stufe 1 umgesetzt (keine Lernwirkung, gelernte Gewichte unverändert):**
- Nenner je Fall = Σ Priors der aktiven Treiber — in `calibrate_weights` (S_case) und in
  `compute_forecast` (P(auf), P(auf, 24 h)) gleich; bei allen 30 aktiv identisch mit vorher.
- Ereignis-Signal: `score ← score + 0,5·(sign − score)` statt ×1,5 (0,6 → 0,8; monoton, kein
  Clipping-Verlust).
- `AKTIV_SCHWELLE` 0,05 statt 0,1 für die Treiberbilanz.
- Nulltest grün, Treiber-Test 73/73 (Ereignis-Erwartungen angepasst), PDFs aktualisiert.

**Stufe 2 und 3:** Proposal für externes Audit in `PROPOSAL_Kalibrierung_Stufe2_3.md` —
Null-Regularisierung mit Prior als Startwert, Klemmung [−prior, 2·prior], OOS-Wächter,
Schrittbegrenzung; Familien-Ensemble (8 Familien, zwei Lernebenen), Lift-Bilanz gegen die
Basisrate, OOS je Treiber; Validierung (erweiterter Nulltest, Positivtests, walk-forward auf
`forecast_slim`), Rollback je Stufe, fünf offene Fragen.

## 3kk. Auditbericht v9 (21.09.) — Stufe 1 als Hybrid, E/F, Historie, Version (22.09.)

Der Bericht prüfte den Pi-Stand (vor Stufe 1) und das Proposal. Kernbefund: **F2 war kein Fehler** —
der Logit ist eine Evidenzsumme, ein fehlender Treiber ein Beleg mit Bayes-Faktor 1; mein Nenner je
Fall blähte den Logit bei zwei aktiven Treibern um das 11-fache auf (Simulation: schlechterer Brier
in den Randfällen). Zurückgenommen. Die beiden kleinen Stufe-1-Punkte bestätigt der Bericht.

Umgesetzt (Paket 2026-09-22.1):
- **Hybrid Stufe 1:** Nenner konstant; Ereignis-Faktor monoton (`+0,5·(sign−score)`); AKTIV_SCHWELLE 0,05.
- **E Lift-Bilanz** je Treiber: Trefferquote minus Zufalls-Erwartung aus den Randverteilungen der
  eigenen Fälle, z gegen SE der Differenz (kein Wilson). Probe: Trendfolger 78 %/Lift 0; Kante
  69 %/Lift +13 pp z 2,1. **F OOS je Treiber** ab 25 Blöcken (wver der Prognose). Beides in
  `learned cal_stats_<h>`, Anzeige in der Treibertabelle.
- **weights_hist:** jede Gewichtsversion bleibt (Rollback existierte nicht — weights_h wird überschrieben).
- **version.py + Kachel „Version"** (Version · Prüfsumme der Projektdateien) — Abgleich Paket ↔ Pi.
- Proposal Revision 2 (`PROPOSAL_Kalibrierung_Stufe2_3.md`): λ = max(0,5/n_eff, 0,005) in u,
  Warm-Start mit Reset-Marke, Toleranz-Labels im Training (bestätigt: `label = close > p0` ohne
  Toleranz), Inversionsschwelle, OOS-Wächter n ≥ 100 / 2 SE, Familien mit konstanten Nennern und nur
  v_k lernen, Rückschau auf `forecast_drivers` nach 6–8 Wochen, drei neue offene Fragen.

## 3aaa. „Aktive Profis" Phase 2 + 3 (23.09., Version 2026-09-23.1)

`hl_profis.py`: Qualifikation über 7 Tage — nicht gesperrt, 5–150 gebündelte Trades/Tag **in den
verfolgten Coins** (pool_fills_hourly), Gewinn 7 T > 0 (HL pnl_7d, einzahlungsbereinigt), **Exit-Lift**
> 0 mit t ≥ 1 (Ausstiege = reduce/close aus whale_positions/lb_events; Korrektur ≥ 2 % binnen 12 h gegen
die aufgegebene Richtung, minus Placebo aus 200 Zufallszeitpunkten desselben Fensters; n_eff über 12-h-
Blöcke; mind. 5 Ausstiege). Anzeige: Entry-Lift, Bot-Marke (über 7 Tage nie > 4 h ohne Trade, ab 5 Tagen
Daten), Reaktionszeit (Median Minuten von ≥ 1 %/15 min bis zum nächsten Trade), bester Coin (closedPnl,
sonst Umsatz). **Rang vorerst HL roi_1d** (bis U5 closedPnl liefert; Feld `rang_basis`), eingefroren
alle 12 h (00/12 UTC), Kennzahlen stündlich. Nulltest: 40 Rauschkonten Lift −0,8 pp; Positivtest +78 pp,
t 21 — Selbsttest-Schritt 21. `check_profis.py --alle` (Debug „★ Aktive Profis, Phase 2") zeigt Top 20
und alle Ausschlussgründe. Dashboard: Abschnitt 10 = Karten der Qualifizierten mit den letzten 5
gebündelten Trades (Zeit, Coin/Spot, Richtung, Betrag, Kurs, „seither", real. PnL), darunter die Pool-
Vorschau. Endpunkt `/profis` (Hintergrund-Thread, 90 s nach Start, dann stündlich). Probe: Alpha
(aktiv, Exits vor Rückgängen) qualifiziert; Halter (1 Trade/T) und Bot (Lift ≈ 0) nicht; Gesperrte raus.

## 3bbb. U5 Pool-Fills und eigener 12-h-Rang; Variante 2 für den Entry-Lift (23.09., Versionen 23.2/23.3)

23.2: Entry-Lift signifikant negativ (t kleiner/gleich minus 1) disqualifiziert (Nutzer: beide Seiten
wichtig, Variante 2; strenge Variante nach zwei Wochen als U3b). 23.3: Task **Pool-Fills** alle 12 h —
`leaderboard_activity` mit `nur_addrs` (Pool minus Auswahl minus Gesperrte, Rückstand zuerst), festem
Budget min(15.000, 30 je Konto), Rang 3, gleiche Vielhandler-/Cursor-Logik; erster Lauf 10 min nach dem
Start. `hl_profis.roi_12h`: Summe closedPnl der Fills in 12 h plus Delta uPnL (jüngste whale_positions-
Zeile je Coin gegen die Zeile vor 12 h), relativ zum Kontowert; Rang nach eigener 12-h-ROI, sonst HL
roi_1d; Karte zeigt ROI 12 h mit Quelle. Erster echter Lauf 03:16: 692 Pool, 73 aktiv mit Gewinn,
6 qualifiziert (Exit-Lifts +25 bis +66 pp); 568 ohne Trades in unseren Coins, 28 mit signifikant
negativem Exit-Lift (Gewinnmitnehmer in der Rally). Offen notiert: bester Coin bei Leaderboard-Konten aus
REST-Fills aller Coins; Placebo je Coin statt gemittelt (U5-Feinheit).

## 3ccc. K2-Neubau: Kalibrierung v2 im Schatten (23.09., Version 2026-09-23.4)

`hl_kalib.py` (numpy): p = σ(b + Σ w_j x_j/s_j); s_j = Streuung der vorhandenen Scores (min 0,05);
L2 gegen Prior·max(0, 1−n_eff/200) (Prior als abklingender Ausgangspunkt); λ ∈ {0,003 … 10} per
5 zusammenhängenden Zeitblöcken mit Embargo (Horizont), Zielgröße gewichteter Log-Loss, 1-SE-Regel;
Newton mit Dämpfung, |w| ≤ 4; 90 Tage; Label ohne Toleranzfälle (M7); Kurs nur mit frischer Bar (H4);
eine Prognose je Block, die früheste (M10). Ausgabe je Coin/Horizont in learned `kalib2_<h>`: Gewichte
(Score-Einheiten und standardisiert), Achsenabschnitt, λ-Tabelle, OOF-Quote/Brier/Skill,
Zuverlässigkeitsdiagramm. **Tor (Positivkontrolle, Selbsttest 22):** Kante 0,65 → 63,4 % (Basis 58 %),
0,90 → 86 %, Rauschen bewegt p um 0,6 Punkte — bestanden; v1 zum Vergleich: 50,6 % / 50,8 %.
Integration: Lernzyklus kalibriert v2 stündlich je Horizont; compute_forecast liefert `p_up_v1`,
`p_up_v2`, `p_up_24_v2`, `kalib` (v1/v2) und `kalib2` (Modellstand); score_forecasts bewertet
p_up direkt (Ruf = Vorzeichen p−0,5, Enthaltung < 2 Punkte) für v1 und v2 (`direkt_v1`, `direkt_v2`,
`enthalten_v2`) — H6 damit für die Wahrscheinlichkeit umgesetzt; Kachel „Kalibrierung v2 Schatten/AKTIV";
Schalter `learned('*','kalib2_aktiv')` per Debug „AKTIVIEREN"/„zurück in den Schatten". Plan: U6/U7
erledigt, U7b (Umschalten nach 1–2 Wochen, wenn v2 ≥ v1) neu.

## 3ddd. Konstellationen und Vorbedingungen (23.09., Version 2026-09-23.7) · v1/v2 sichtbar (23.5/23.6)

23.5: Kopfzeile „P(aufwaerts 4 h) — v1 gegen v2"; 23.6: Spalte „Gew. v2" in der Treibertabelle
(v2-Gewicht je Treiber, blau = weicht vom Prior ab, rot = invertiert). 23.7: `hl_konstellation.py`
— (1) Konstellationen: fuer die 15 gewichtigsten Treiber alle Paare; bedingte 4-h-Trefferquote, wenn
beide im selben Block mit |Score| >= 0,3 in dieselbe Richtung zeigen, Wilson auf n_eff (4-h-Bloecke),
Basisrate, Lift, z (Zwei-Anteile-Test), Auswahl-Effekt ausgewiesen (n Pruefungen, beobachtete und
erwartete z >= 2); (2) Vorbedingungen: vor Bewegungen >= 3 % binnen 24 h (Ereignisse zusammengefasst)
je Treiber Anteil „zeigte in die spaetere Richtung" gegen die Basis aller Bloecke, Lift, z, mittlerer
Score. Beides Anzeige (unter der Elite-Tabelle), kein Modellbestandteil; stuendlich im Lernzyklus,
learned `konstellation`. Nulltest (Rauschen: kein |z| >= 3 haeufiger als 5 %) = Selbsttest-Schritt 23;
Probe mit zwei konstruierten 70-%-Treibern: Paar-Quote 90 %, z 3,9. Plan U25 (Stufe 2: Interaktionsterme in v2).
Offen aus dem Gespraech: beim Aktivieren von v2 muss auch der Pfad (Bias) auf v2 umgestellt werden (U7b).

## 3eee. Konstellations-Historie und Stabilitätsliste (23.09., Version 2026-09-23.8)

Frage des Nutzers: Vorzeichen (ja — auf- und abwärts getrennte Prüfungen mit eigenen Schwellen und
Basisraten) und Speicherung fürs Lernen. Neu: Tabelle `konstellation_hist` (je Coin und Tag: alle
Paare mit Quote/Basis/Lift/z, Vorbedingungen), `hl_konstellation.stabil()` = Paare mit z ≥ 2 und
positivem Lift an ≥ 14 Tagen — die Kandidatenliste für Interaktionsterme in v2 (U25 Stufe 2);
Anzeige über der Konstellationstabelle („Über Wochen stabil …" bzw. „aufgezeichnet seit n Tagen").
Paketname wieder `hl_liq_project.zip` (Update-System), Regel im Plan festgehalten.

## 3fff. v2 blieb stumm: MIN_FAELLE 60 -> 30, Zustand sichtbar (23.09., Version 2026-09-23.9)

Auf dem Pi zeigte v2 nach Stunden "noch nicht kalibriert": `hl_kalib.kalibrieren` verlangte 60 Faelle
(eine Prognose je 4-h-Block, Toleranzfaelle ausgelassen) und speicherte bei weniger NICHTS -- die Anzeige
konnte den Grund nicht nennen. Jetzt MIN_FAELLE 30 (der abklingende Prior traegt kleine n), der Zustand
"zu wenige Faelle: n von 30 (Bloecke, unter Toleranz)" wird gespeichert und in Kopfzeile und Kachel
gezeigt; Fehler des Lernzyklus (`kalib2_fehler`) ebenfalls. Gemeldet und offen (U26): Leaderboard-Flow
"0 Konten in 60 min" um 11:20 -- Pruefung mit dem Leaderboard-Werkzeug ausstehend.

## 3ggg. Gegen-/Smart-Flow-Gründe, U26 geklärt, Projektübergabe (23.09., Version 2026-09-23.10)

U26 (Leaderboard-Flow „0 Konten in 60 min"): kein Fehler — Leaderboard-Diagnose zeigt in 6 h nur zwei
BTC-Größenänderungen unter den Top-75, davon eine über der Schwelle mit Ereignis; nur 6 der 75 halten BTC.
Gegen-Flow und Smart-Flow haben jetzt echte Inaktiv-Gründe (INAKTIV_GRUND). Vorschlag U27: Flow-Treiber
auf Basis der qualifizierten Profis (Nulltest-Pflicht), Entscheidung nach zwei Wochen Profis-Daten.
**Projektübergabe für Opus 5.5:** `PROJEKTUEBERGABE_OPUS55_23-09-2026.md` (System, Regeln, Arbeitsweise in
der Sandbox, Stand, Schwächen, erste Schritte); Autorenvermerke angepasst.

## 3hhh. Abschnitt A in der Sandbox, NameError im Liquidations-Pfad, Prüfsumme mit Werkzeugen (23.09., Version 2026-09-23.11, Opus 5.5)

Sitzungsbeginn mit Opus 5.5 nach `PROJEKTUEBERGABE_OPUS55_23-09-2026.md`. Abschnitt A, Sandbox-Teil: Paket 23.10 ·
5b25f96685 unverändert, Selbsttest 23/23, Nulltest v1 grün (Positivkontrolle v1 „NICHT LERNFÄHIG", 0,65 → 50,6 %),
v2-Tor bestanden (0,65 → 62,0 %), JS ok. **Fund der Namensprüfung (U28):** `on_user_event` rief im tid-Rückfall
`hashlib.blake2b` auf (Audit-Korrektur N5 vom 22.18), `hashlib` war im Modul aber nur lokal in `infer_liquidations`
importiert → NameError bei einem Liquidations-Fill ohne tid; die Ausnahme verlässt `run_ws` und erzwingt einen
WS-Neuaufbau (Liquidation verloren, alle Feeds kurz weg). Korrektur: Import auf Modulebene. **Prüfsumme:** umfasst
jetzt auch die 18 Werkzeuge (check_*, db_size, make_treiber_pdf*) — vorher erkannte A1 ein veraltetes Werkzeug auf
dem Pi nicht, obwohl `check_treiber` Selbsttest-Schritt ist. **Plan korrigiert:** A4 heißt „Rundum-Funktionstest aller
Quellen" (check_sources, Soll FEHL 0), nicht der 23-Schritte-Selbsttest; neu A7 (Selbsttest vor jeder Lieferung).
**Neu U29:** OOF-Brier-Skill von v2 auf Rauschen negativ verzerrt (−0,034 über 12 Seeds; Referenz = Klimatologie der
ganzen Stichprobe) — vor U7b korrigieren. Pi-Teil von Abschnitt A steht aus.

## 3iii. Abschnitt A auf dem Pi; Schreibsperre beim Start; Coinbase-Seite als Messung; Beleg je Sperre (23.09., Version 2026-09-23.12, Opus 5.5)

Pi auf 23.11 (12:16–12:25): A1 Version gleich, A2 keine Aufgabe mit Fehler, A3 1.082/min (100 % des Deckels,
0 × 429), A4 FEHL 0 in allen Quellen, A5 v1 NICHT LERNFÄHIG / v2 Tor bestanden (0,65 → 63,7 %). Drei Funde aus den
Ausgaben:

**(1) U32:** Der Netzwerkstatus zeigte eine Schreibsperre von 48,9 s mit der ersten Anweisung „INSERT OR IGNORE INTO
addresses (addr, first_seen, last_trade)“ — die einzige Stelle ist `pool_laden`. Sie fügte ohne Commit ein; beim
Start blieb die Transaktion (und die Sperre aller Dienste) über Symbolauflösung und ersten Leaderboard-Zyklus offen.
Jetzt `executemany` + Commit. Probe: vorher Transaktion offen und 0 Adressen für andere sichtbar, nachher geschlossen,
600 sichtbar.

**(2) A4 prüfte Coinbase am falschen Kanal:** Der Dienst liest seit 22.18 `matches`, der Test den `ticker`, und
„side = MAKER-Seite“ war eine feste Ausgabe, keine Messung. Jetzt prüft A4 `matches` und misst die Seite (Tick-Regel:
Aufwärts-Tick ⇒ Maker „sell“; Vergleich ticker/matches je trade_id). Probe P1 (U2) läuft damit bei jedem A4;
synthetisch geprüft (Maker-Fall ok, 92 %; invertierter Fall fehl, 8 %). Dazu `last_match` im Dienst übergangen (U33).

**(3) A6 — 30 Gesperrte,** 19 neu seit 23.09. 02:02, fast alle 2.007–2.492 Fills. Seit M1 (22.18) zählt die Regel
ALLE Fills rollierend statt Fills ab 2.500 USD je UTC-Tag; die Grenze 2.000 ist damit faktisch gesenkt, und Fills sind
Ausführungen, keine Entscheidungen. `check_sperre` zeigt jetzt je Sperre die gebündelten Trades der 24 h davor
(Maschinen- oder Trader-Muster); Entscheidung U31 beim Nutzer. Probe P2 (U1) steht jetzt im VOLLBERICHT.

## 3jjj. Masterregel auf gebündelte Trades (23.09., Version 2026-09-23.13, Opus 5.5, Entscheidung Nutzer)

**Anlass:** A6 zeigte 19 Sperren binnen zehn Stunden knapp über 2.000 Fills. Die Umstellung M1 (22.18) zählt ALLE
Fills rollierend statt Fills ab 2.500 USD je UTC-Tag; die Grenze war damit faktisch gesenkt. Fills sind Ausführungen,
keine Entscheidungen.

**Entscheidung des Nutzers:** Option (a) — mehr als **300 gebündelte Trades (je Coin, Minute und Richtung) in 24 h**,
dieselbe Einheit wie die Aktivitätsschranke der Elite.

**Umsetzung:**
- Stream: je Konto und Stunde eine Menge (Coin, Minute·2 + Käufer); der Käufer ist `users[0]`.
- Persistierung in `fill_zaehler_h.n_trades` mit MAX: Die Mengen der laufenden und der vorigen Stunde bleiben im
  Speicher, keine Doppelzählung an Laufgrenzen.
- Zweite Quelle: `lb_fills` (alle Coins der Leaderboard-Konten, gespeicherte Fills); es gilt das Maximum.
- `konto_status.trades_tag` neu.
- **Einmalige Neubewertung** der alten Fills-Sperren (`sperre_neubewertung`), sobald 24 volle Stunden Zählung
  vorliegen: ≤ 300 → Status `frei` (neuer und alter Grund im Protokoll), > 300 → bleibt mit Beleg. Manuelle Sperren
  bleiben unberührt; Ergebnis in `meta.masterregel_neubewertung`.
- `check_sperre` neu: Zählung, Neubewertung, Freigegebene, Beleg der alten Sperren, „nahe der Grenze“ nach Trades.
- Texte in Dashboard, README und Projektübergabe (Regel 5) angepasst.

**Probe:** Maschine (400 Minuten mit Trades) gesperrt; Trader (2.500 Fills in 50 Minuten) nicht; zweiter Lauf in einer
schon gezählten Minute zählt nicht doppelt (50 Trades, 2.501 Fills); Neubewertung: 40 Trades → frei, 500 → bleibt,
einmalig; Migration einer 23.12-Datenbank ergänzt `n_trades` und `trades_tag`.

**Nebenfund U34:** Der Selbsttest von 23.13 fiel in zwei UNVERÄNDERTEN Modulen durch (Positivkontrolle v2 59,6 %,
Konstellations-Nulltest +7,2 pp). Ursache: Beide bauten ihr synthetisches Szenario an `time.time()`. Gemessen über
24 Viertelstunden fiel jedes Tor 5-mal durch (p_up bei Kante 0,65 zwischen 56,8 und 65,7 %). Jetzt fester Zeitpunkt
(`PROBE_NOW`) und Tor über fünf feste Szenarien: v2 im Mittel 60,7 % (knapp, siehe U35), Konstellation gepoolt
+2,5 pp; identische Ausgabe zu jeder Uhrzeit.

## 3kkk. Nachlauf zu A (13:25): Sperre über die Poll-Runde, Pool-Fills nach Neustart, Lückenbeginn (23.09., Version 2026-09-23.14, Opus 5.5)

Aus Netzwerkstatus und VOLLBERICHT 13:25 (Pi auf 23.13). **U1 erledigt:** 0 beobachtete Konten, 35 abgeleitete Liquidationen
von 33 Konten. **U32 wirkt:** Der längste Halter der Schreibsperre ist 11,8 s statt 48,9 s.

**U37:** Die verbleibenden 76 Halter über 1 s trugen alle die Anweisung „UPDATE addresses SET last_poll=?, notional=0 …“.
`poll_address` schrieb, wenn eine Adresse keine Position mehr hatte, sofort — mitten in der Poll-Runde; die Sperre aller
Dienste blieb bis `flush_round` über die übrigen Netzaufrufe offen. Die anderen Pfade puffern seit 14.09.; dieser war
übersehen. Jetzt gepuffert (`addr_null_pending`), `flush_round` schreibt beide Stände, je Adresse gewinnt der jüngste.
Probe: 23.13 hielt nach `poll_address` eine offene Transaktion, 23.14 nicht.

**U40:** Pool-Fills lief 10 min nach JEDEM Start und verdrängte den Nachtrag der Auswahl (Median 33 min). Jetzt startet der
Lauf 12 h nach dem letzten (in `meta` gespeichert). Der VOLLBERICHT trennt den Abholstand: Auswahl (Takt 15 min) und
Pool (Takt 12 h); gemischt stand dort „Median 7,9 h, AUFHOLEN LÄUFT“.

**U39:** Übersprungene Zeiträume begannen bei neuen Konten bei 0 (Bericht: Lücken ab 01.01.1970); jetzt beim jüngsten
geholten Fill.

**Offen U38:** Der Begrenzer kann nach Ruhephasen bis 1.476 Gewicht in 60 s abgeben (Deckel 1.080 + Eimer 180 +
Reserve 216). Gemessen wurden 1.143, 429 gab es keine.

**U31, Stand:** Um 13:22 sperrte die neue Regel drei Konten (365–398 gebündelte Trades). Die Neubewertung der alten Sperren
folgt am 24.09. gegen 13:00.

## 3lll. Coinbase-Seite gemessen, vertauschter Spot-Taker-Flow korrigiert (23.09., Version 2026-09-23.15, Opus 5.5)

**U2 erledigt.** Rundum-Funktionstest 13:56:
- `matches.side` ist die Maker-Seite (Tick-Regel 38 von 41, 93 %) — die Umkehr im Dienst ist richtig.
- `ticker.side` ist die TAKER-Seite (0 von 99 gemeinsamen Trades gleich). Damit ist Audit-H2 bestätigt: Bis zur
  Umstellung auf `matches` (22.18/22.19, auf dem Pi vor 02:43 am 23.09.) war der Spot-Taker-Flow vertauscht, seit dem
  Start des Coinbase-Dienstes.

**U41 (Entscheidung Nutzer: ja):**
- Der Umstellzeitpunkt steht nirgends. Der Coinbase-Dienst bestimmt ihn beim Start aus `cb_bars`: Mit richtigen Seiten
  haben Kursänderung und Netto-Taker-Flow einer Minute meist dasselbe Vorzeichen, vertauscht meist das entgegengesetzte.
  Der beste Schnitt (Präfixsummen, auf die Minute) landet in `cb_meta` 'seite_umstellung' mit dem Status gefunden,
  keine oder unklar; nur bei „gefunden“ wird korrigiert.
- Davor tauscht `load_coinbase` buy/sell beim Lesen; das betrifft Flow-Fenster und die Z-Referenz über 7 Tage.
- Die gespeicherten Scores des Treibers „Spot-Taker-Flow“ vor dem Schnitt fallen aus v1-Kalibrierung und -Bilanz, dem
  v2-Training und den Konstellationen heraus (`F.cb_seite_ab`, `F.CB_TREIBER`). Nichts wird umgeschrieben; das ist
  umkehrbar durch Löschen des Eintrags in `cb_meta`.
- Debug-Eintrag „Coinbase: Seiten-Umstellung (U41)“ zeigt den Zeitpunkt und den Gleichlauf je Stunde um den Schnitt.

**Probe (synthetisch, 5 Coins, 10 Tage):**
- Schnitt 1 min neben dem wahren, Gleichlauf vorher 0,22, nachher 0,79.
- Nie vertauscht → keine; Flow ohne Kurswirkung → unklar.
- Z-Wert gleich dem wahren (−0,257).
- Fälle des Treibers in v1, v2 und Konstellationen nur noch nach dem Schnitt (122 von 940 Fenstern).

**Für jeden künftigen Leser von `cb_bars.buy_usd/sell_usd`:** Nur zusammen mit `cb_seite_ab` lesen (Hinweis im Schema
von `hl_coinbase.py`).

## 3mmm. Bestätigungen auf dem Pi (23.09., 14:17–14:47, Version 2026-09-23.15, nur Dokumente)

**U41:** Debug „Coinbase: Seiten-Umstellung“ 14:17: Schnitt 22.09. 22:27 (22.18 am Abend eingespielt). Der Gleichlauf von
Kursänderung und Netto-Flow lag vorher bei 0,356 (57.866 Minuten), nachher bei 0,63 (3.869 Minuten). Das ist ein
Spiegelbild, also eine reine Vertauschung. Je Stunde 29–38 % → 57–67 %; die Stunde des Schnitts liegt bei 48 % (27 min
vertauscht, 33 min richtig). Frage des Nutzers dazu geklärt: „Taker-Flow“ (Perp-Verhältnisse Binance/Bybit/OKX/Crypto.com)
ist ein anderer Treiber als „Spot-Taker-Flow“ (Coinbase) und vom Fehler nicht betroffen.

**U37:** Netzwerkstatus 14:47, 34 min nach dem Start: Sperr-Halter im Mittel 11 ms statt 234 ms, 3-mal über 1 s statt
76-mal, längster 4,2 s (wal_checkpoint). Binance wartet im Mittel 0,2 ms statt 108 ms.

**U40:** Der Pool-Lauf von 23.14 brach beim Einspielen von 23.15 ab, deshalb lief er nach dem Start noch einmal (528 s);
jetzt ist er gespeichert. Der Beleg folgt beim nächsten Start: Die Zeile „Pool-Fills“ muss „nächster Lauf in … h“
zeigen.

**Neu U42 (kosmetisch):** Die Live-Zeilen Bybit, OKX und Crypto.com zeigen „erwartet unter 60 s“, werden aber nur beim
Chart-Abruf geholt.

## 3nnn. U8: Bilanz der Kauf- und Verkaufsempfehlungen (23.09., Version 2026-09-23.16, Opus 5.5)

Die Empfehlungen „Optimaler Kaufpreis / Verkaufspreis (4–12 h)“ wurden seit Wochen ausgegeben, aber nie bewertet
(Audit v10 H10). `hl_forecast.empfehlungen_bilanz` bewertet sie aus den gespeicherten Prognosen (60 Tage) und den
1-min-Kerzen.

**Fälle:** Je Coin und UTC-Tag die erste Empfehlung. Die Ergebnisse überlappen dadurch nicht, und n ist die Zahl
unabhängiger Fälle je Coin; die Coins sind untereinander korreliert.

**Ausführung:** Das Limit liegt ab der Prognose 12 h. Es gilt als gefüllt, sobald ein Minutentief (Kauf) bzw. ein
Minutenhoch (Verkauf) den Preis erreicht. Liegt das Limit schon jenseits des Kurses, zählt es als Market-Order zu p0 mit
Taker-Gebühr.

**Bewertung aller Varianten 24 h nach der Prognose** (Schlusskurs höchstens 2 min alt, sonst „ohne Kurs“):
- Kauf, Ausgangslage Geld: Limit (gefüllt: Schluss/Limit − 1 − Maker − Taker, sonst 0) gegen Markt (Schluss/p0 − 1 − 2 ×
  Taker) und nie (0).
- Verkauf, Ausgangslage eine gehaltene Long-Einheit: Limit (gefüllt: Limit/p0 − 1 − Maker, sonst weiter gehalten) gegen
  sofort (−Taker) und halten (Schluss/p0 − 1).
- „nach Füllung 4 h“ misst die adverse Auswahl.
- Gebühren: Maker 0,015 %, Taker 0,045 % (HL-Basisstufe, Konstanten in `hl_forecast`). Funding bleibt außen vor.

**Anzeige:**
- Kachel „Bilanz der Empfehlungen“ neben Kauf-/Verkaufspreis, für alle Coins, stündlich gerechnet (`learned` „*“/„empf“).
  Farbe: grün, wenn Limit − Markt mit 95 % positiv ist, rot, wenn negativ, gelb, wenn offen.
- Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“: Tabelle je Coin, dazu advised ja/nein für alle Coins.

**Prüfung:**
- Nulltest-Zeile „Empfehlungs-Bilanz auf Rauschen (U8)“ mit festem Zeitpunkt und Seed:
  - Rechenweg exakt gegen Handrechnung (7 Werte; Kauf-Limit +1,9602 %, Markt +0,91 %, Verkaufs-Limit +0,485 %, halten
    +1,0 %, sofort −0,045 %, nach Füllung +2,0202 % / −0,495 %).
  - Martingal-Soll auf einem Random Walk über 118 Tage: Markt −2 Taker, Limit-Kauf −(Maker + Taker) × Füllquote,
    halten 0, Limit-Verkauf −Maker × Füllquote, nach Füllung 0, Grenze 4 SE.
- Mutationsprobe: Verkauf ohne Limitpreis, Vorzeichenfehler nach der Füllung und Füllung am Hoch statt Tief fallen
  durch.
- Sandbox-Probe mit Hand-Szenario: 2 BTC-Tage, ETH marktfähig, ZEC ohne Kurs — alle Werte exakt.

**U42:** Die Live-Zeilen Bybit, OKX und Crypto.com zeigen „erwartet: beim Chart-Abruf“.

## 3ooo. Pool-Fills-Zeitpunkt beim Start (U40b) und erste U8-Zahlen (23.09., Version 2026-09-23.17, Opus 5.5)

**U40b.** Um 16:13, nach dem Start von 23.16, lief Pool-Fills trotz U40 erneut („läuft: 10/542 Konten, 384 Gewicht
bisher“). Ursache: Ein Pool-Lauf dauert bei vollem Budget rund 2 h (Rang 3, bis 15.000 Gewicht). Die in 3kkk/3mmm
genannten „528 s / 644 s“ waren Fortschrittsmeldungen laufender Läufe, keine fertigen — die Annahme „~11 min“ war
falsch. Jedes Update am 23.09. brach den Lauf ab, bevor U40 den Zeitpunkt am Ende schrieb; also begann jeder Neustart
von vorn. Jetzt wird der Zeitpunkt beim Start geschrieben. Ein abgebrochener Lauf setzt im nächsten 12-h-Takt fort; die
Reihenfolge richtet sich nach dem Rückstand, und der Abholstand je Konto bleibt erhalten. Die Warteanzeige zeigt als
„zuletzt“ den Start des letzten Laufs und als „nächste“ den echten Termin (vorher: Zeitpunkt der Meldung und +12 h).

**U8, erste Zahlen vom Pi (16:12, 70 Fälle je Seite aus 12 Tagen × 6 Coins):**
- Kauf: Limit +1,27 % gegen Markt +1,31 % (Differenz −0,04 %, 95 % −0,33 … +0,25), gefüllt 86 %.
- Verkauf: Limit ±0,00 % gegen sofort −0,04 % und halten +1,40 %, gefüllt 70 %.
- Der steigende Markt bestimmt alles. Ein Vorteil der Limits ist insgesamt nicht messbar.
- Je Coin liegen XMR, ZEC (Kauf) und PAXG (Verkauf) über dem Markt, bei 12 Vergleichen mit je n = 12 aber vorsichtig
  zu lesen.
- Alle Fälle sind „advised ja“.
- Neu W7: wöchentlich lesen.

## 3ppp. Fingerabdruck Stufe 1: Ereignis-Profile (U43) (23.09., Version 2026-09-23.18, Opus 5.5)

Anlass: der Rutsch am 23.09. gegen 16:15. Die Idee des Nutzers ist ein Fingerabdruck der Zeit vor Rutschen und
Anstiegen. Der Vorschlag hat drei Stufen (Profile → sparsames Modell → Analog-Suche über Treiberverläufe); gebaut ist
Stufe 1.

**Ereignis:** Die Rendite der nächsten 4 h beträgt mindestens 2 σ. σ ist die 4-h-Schwankung aus den 7 Tagen davor,
aus 15-min-Schlusskursen. Aufeinanderfolgende Startpunkte derselben Richtung (Abstand ≤ 4 h) bilden ein Ereignis.

**Beginn:** Im ersten dieser Fenster der letzte 15-min-Punkt, bevor sich der Kurs um 0,5 σ in Ereignisrichtung bewegt
hat. Ohne diese Schärfung läge der Beginn bis zu 2 h vor der Bewegung, und ein 3-h-Vorläufer erschiene in der Probe nur
mit −1 h. Gleichgerichtete Ereignisse mehrerer Coins binnen 2 h zählen als ein Fall.

**Profil:**
- Je Treiber und Vorlauf (−12, −8, −6, −4, −3, −2, −1, 0 h) die Abweichung vom Normalwert desselben Coins in Zeiten
  gleicher Schwankung (Terzile von σ, ohne die Fenster um Ereignisse).
- Gemittelt über die Coins eines Falls, dann über die Fälle; z = Mittel / SE.
- Treiberwerte stammen aus `forecast_drivers` (alle 15 min, nicht gelöscht) und werden dem nächsten Rasterpunkt
  zugeordnet, sodass kein Blick in die Zukunft entsteht. Spot-Taker-Flow vor der Seiten-Umstellung bleibt außen vor
  (U41).

**Schwelle:** 95 % des größten |z| über alle Treiber × Vorläufe aus 200 Läufen mit je Coin zirkulär verschobenen
Ereigniszeiten. Das begrenzt Zufallsfunde über die ganze Tabelle (Familienfehler 5 % je Richtung) und berücksichtigt
die Autokorrelation. Als „Vorlauf“ gilt der zusammenhängende Abschnitt über der Schwelle, der dem Beginn am nächsten
liegt.

**Ausgabe:** Debug „★ Ereignis-Profile (U43)“ mit den letzten 12 Fällen je Richtung und der Kurszeile (Rendite seit
−12 h in σ, „danach“ = Bewegung über 4 h).

**Selbsttest (Nulltest Konstellationen):** 3 Coins, 40 Tage, eingebaute 4-σ-Sprünge und ein Vorläufer (±0,6 in den
3 h davor) neben Rauschtreibern.
- Soll: Vorläufer in beiden Richtungen erkannt, Rauschtreiber zusammen höchstens ein Zufallsfund.
- 15 von 15 Seeds bestanden; der Vorläufer wurde mit −3 … 0 h bzw. −3 … −1 h erkannt.
- Zufallsfunde traten bei 3 von 15 Seeds auf (erwartet etwa 10 %).

**Stand der Daten:** Die Treiberwerte reichen bis etwa 11.09. zurück, die Schwelle ist bei wenigen Fällen hoch. Leere
Markierungen heißen deshalb zunächst: noch nicht belegbar.

**Stufe 2** folgt ab etwa 30 Fällen je Richtung (W8 wöchentlich).

## 3qqq. Verlauf der Treiber unter dem Kurs (U44) (23.09., Version 2026-09-23.19, Opus 5.5)

Frage des Nutzers: Ist ein Trend oder ein Anbahnungs-Wert irgendwo sichtbar? Antwort: Einen Live-Wert gibt es bewusst
erst mit U43 Stufe 2. Sichtbar waren bisher nur Bias und P(up) sowie die Treiber-Pfeile (Änderung gegen die vorige
Prognose, 15 min). Neu ist ein beschreibender Verlauf.

**Anzeige:** Die Tafel `#verlauf` unter dem Prognose-Chart ist ein SVG mit festem Seitenverhältnis, das mit der Breite
skaliert.
- Oben der Kurs zur Prognosezeit, unten Bias (weiß, dick) und die gewählten Treiber auf −1 … +1, mit Hilfslinien bei
  ±0,5 und 0. Umschaltbar zwischen 24 und 72 h.
- Ereignisse erscheinen als rote bzw. grüne Bänder vom Beginn bis +4 h, nach derselben Definition wie die
  Ereignis-Profile. Dafür ist die Erkennung jetzt eine gemeinsame Funktion (`_profil_kurse`, `_profil_sigma`,
  `_profil_ereignisse`, `ereignisse_kurs`); die U43-Probe liefert nach dem Umbau dieselben Zahlen, 15 von 15 Seeds.
- Treiber werden per Antippen an- oder abgewählt; vorgewählt sind die 4 mit dem größten Betrag jetzt. Die Auswahl
  bleibt bis zum Coin-Wechsel.

**Daten:** Endpunkt `/verlauf?coin=&h=` (60 s Zwischenspeicher) liest `forecast_slim` und `forecast_drivers` (alle
15 min, nicht gelöscht). Spot-Taker-Flow bleibt vor der Seiten-Umstellung leer (U41). Geladen wird mit der Prognose,
höchstens alle 5 min neu.

**Probe:**
- Synthetisch: 72 h ergeben 288 Punkte, ein eingebauter Rutsch wird exakt zur eingebauten Zeit markiert.
- Tafel im node-Nachbau: SVG mit 5 Linien, 1 Band und 3 Auswahlfeldern; Antippen und der 24-h-Knopf wirken.

## 3rrr. Berichtsplan: Debug-Einträge laufen von selbst (U45) (23.09., Version 2026-09-23.20, Opus 5.5)

Frage des Nutzers: Wäre es nicht einfacher, die Debug-Skripte per Zeitplan aus dem Skript aufzurufen? Entscheidung:
Berichtsplan, nur lokal speichern. Versand per Gmail oder Drive wurde angeboten (Claude kann beides über die
Konnektoren lesen) und abgelehnt.

**Ablauf:**
- `hl_viz.BERICHTSPLAN` enthält Einzeltermine und eine Wochenprüfung (mittwochs 19:00 ab 30.09.).
- Ein Hintergrund-Thread des Dashboards prüft minütlich, 90 s nach dem Start zum ersten Mal. Er startet nicht mit
  `_selftest.db` und lässt sich mit HL_BERICHTE=0 abschalten.
- Jeder Termin läuft einmal; der Stand steht in `berichte/.stand.json`. Verpasste Termine (Dienst aus, Update) werden
  bis 12 h nachgeholt, danach als „verpasst“ vermerkt.
- Die Dateien heißen `berichte/JJJJ-MM-TT_HH-MM_<lauf>.txt` und tragen dieselbe Kopfzeile wie beim Herunterladen. Sie
  werden 365 Tage aufbewahrt.
- Ein Handlauf wartet, solange ein geplanter Bericht läuft, und umgekehrt.

**Anzeige im Debug-Bereich:** Plan mit Stand (offen, erledigt, verpasst), Links je Datei und die Sammeldatei „letzte
24 h / 7 Tage“ (`/berichte/sammel?tage=`). Die Sammeldatei lädt der Nutzer in den Chat hoch.

**Pflege:** Neue Termine trägt Claude mit dem nächsten Paket in BERICHTSPLAN ein.

**Probe:**
- Der Wochentermin gilt erst ab 30.09. und bleibt nach dem Sommerzeit-Ende (25.10.) bei 19:00.
- Jeder Termin läuft einmal statt doppelt; 12 h 16 min zu spät gilt als verpasst.
- Ein echter Lauf (Coinbase-Selbsttest) wird mit Kopfzeile gespeichert.
- `../version.py` wird abgewiesen; Sammeldatei und Tafel funktionieren im node-Nachbau.

## 3sss. Paket Teil A (24.09., Version 2026-09-23.21, Opus 5.5)

**Masterregel (U31):** Die einmalige Neubewertung lief am 24.09. um 13:02.
- 32 alte Sperren geprüft: 14 freigegeben mit 0 bis 207 gebündelten Trades; das sind Händler, die große Aufträge in
  viele Fills zerlegen. 18 bleiben gesperrt mit 369 bis 8.618 Trades.
- Seit 23.13 hat die neue Regel 27 Konten gesperrt.

**Zwei ernste Funde, beide behoben:**
- **U48:** Der Zufallsvergleich der Profis war über Coins und Richtungen gemittelt. Im Trendmarkt bekamen zufällige
  Short-Schließungen dadurch +41 Prozentpunkte bei t = 3,2. Jetzt wird je Coin und Richtung verglichen: −2 Prozentpunkte
  bei t = −0,1. Der Test dazu steckt im Selbsttest (Richtungslogik 9 von 9, Trendfalle).
- **U49:** In `compute_forecast` stand `drivers + inaktiv` vor `inaktiv = []`. Das warf einen UnboundLocalError, den
  `except: pass` verschluckte. Folgen: keine v2-Gewichte in der Tabelle, und `aktiv()` → `p_up_v2` wäre nie
  wirksam geworden.

**Weiter:**
- U47: Mindestfallzahl in den Ereignis-Profilen und begrenzte Lückenfüllung.
- U46: Knopf „Neue Berichte“.
- U50: Debug „Magnet-Varianten, 60 Tage“ mit Horizont bis 48 h.
- U51: Snapshot-Knöpfe entfernt.
- U52: Status-Spalte in der Profi-Vorschau.
- Debug „Kalibrierung v2: Stand je Coin“; im Testmodell erklärt er 97 % als Sigmoid(0,10 + 21 × 0,16). Genau dieses
  Aufaddieren ist der Grund für die Übersicherung von v2.

**Offen:** Teil B (U53) als 23.22, das Speicher-Paket (U54) am 25.09., das Analyse-Paket (U55) vor dem 30.09.
Zurückgestellt sind U56 und U57.

## 3ttt. Teil B1: Darwin-Liste, Timing-Bilanz, Zeitleiste (24.09., Version 2026-09-23.22, Opus 5.5)

**Darwin-Liste Schritt 1**
- Mitglieder ändern sich einmal täglich, bei der ersten Bewertung nach 00 UTC.
- Aufnahme bei Qualifikation. Abstieg erst nach 2 Tagesbewertungen in Folge ohne Qualifikation; dazwischen gilt das
  Konto als „auf Bewährung“.
- Reihenfolge nach der vorsichtigen Untergrenze des Exit-Lifts, also Lift minus Standardfehler.
- Der Stand liegt im Prognosespeicher (`learned` „*“/„darwin“) und übersteht Neustarts.

**Timing-Bilanz je Konto**
- Einstiege und Ausstiege, jeweils Long und Short, mit Trefferzahl und Zufallsquote (gleicher Coin, gleiche Richtung).
- „Zuerst richtig“: neue Methode `Kurs.zuerst`. Wer zuerst ±2 % erreicht; erreichen beide Richtungen die Schwelle in
  derselben Minute, gilt der Fall als offen.
- Tempo-Vorsprung nach 1, 4 und 12 h.
- Alles nur Anzeige. Die Entscheidung über den Hauptmaßstab fällt am 06.10.
- Die Zufallsquoten werden einmal je Bewertung gerechnet und für alle Konten geteilt (`placebo_berechnen`, Cache).

**Trades und Anzeige**
- Je Konto 30 Trades, davon 10 sichtbar. Dazu das Alter jedes Trades und eine gemeinsame Zeitleiste mit 40 Einträgen.
- Die Liste lädt sich im Minutentakt neu, solange sie sichtbar ist.
- Im Berichtsplan steht das Datum nicht mehr doppelt, und die Links sind echte Knöpfe.

**Offen U58 (Teil B2):** Die Echtzeit-Plätze gehen auf die Darwin-Liste; das kommt mit dem Speicher-Paket.

## 3uuu. Echtzeit-Plätze für die Darwin-Liste, Backup-Pfad im Dashboard (24.09., Version 2026-09-23.23, Opus 5.5)

**U58: Echtzeit-Plätze für die Darwin-Liste**
- Der Recorder bestimmt die höchstens 10 userEvents-Abos jetzt aus der Darwin-Liste, bestes Timing zuerst.
- Die Reihenfolge schreibt das Dashboard stündlich in den Prognosespeicher (`learned` „*“/„darwin“, Feld „reihe“). Der
  Recorder liest sie alle 5 min, gesperrte Konten nie.
- Ihre Perp-Fills landen vollständig in `lb_fills`, mit Richtung, closedPnl, Gebühr und tid, und ersetzen die
  geschätzten Stream-Zeilen im selben Zeitraum.
- Die frühere Beobachtung der größten Positionen auf Liquidationen entfällt; sie hatte in 24 h 0 Treffer. Liquidationen
  kommen weiter über die Ableitung.

**U54: Speicherorte**
- Die Datenbank wird nur angezeigt. Der Backup-Pfad lässt sich im Dashboard wählen, über eine Ordnerauswahl auf dem Pi.
- Geprüft werden: erlaubter Ort, anlegbar, beschreibbar, anderes Gerät als die Datenbank, Platz für 2 Generationen,
  dazu ein Hinweis, ob das Medium in fstab steht.
- Die Einstellung steht in `speicherorte.json` im Projektordner. Der Recorder liest sie beim Start und vor jedem
  Backup-Durchgang, prüft alle 10 s auf Änderungen und schreibt meta 'backup_dir'. Ein Neustart ist nicht nötig.
- „Jetzt sichern“ löst ein sofortiges Backup aus. „Alte Backups löschen“ ist erst nach einem erfolgreichen Backup am
  neuen Ort möglich und entfernt nur die bekannten Backup-Dateien.

**Offen U59:** Der Umzug der Datenbank über die Oberfläche braucht einen nicht-interaktiven, privilegierten
`migrate_db`-Lauf.

## 3vvv. Konfluenz: Zone gegen Kaskade, Prämie ohne Punkte, Bilanz (24.09., Version 2026-09-23.24, Opus 5.5)

**Anlass:** Der Nutzer sah „Ziel ≈ 82.114 (Long-Squeeze)“ und zugleich „KAUFZONE bullisches FVG“ darüber.

**Ursache in `computeSignal`:**
- Die Warnungen vom Typ „wait“ (Stops, Cluster, Magnet, Kaskadenprognose) zählten 0 Punkte. Sie schalteten nur die
  Beschriftung auf ABWARTEN.
- Die Zone hing allein am Vorzeichen der Punkte. Kaufpunkte kamen vom MA-Regime (+2 dauerhaft), vom FVG (+1) und von der
  Coinbase-Prämie. Die Prämie ist nach Rutschen durch den gedrückten HL-Perp hoch, der bekannte Mangel aus U56.

**Jetzt:**
- Droht ein Anlauf nach unten, zeigt der Chart keine Kaufzone. Die Zone rückt ans Kaskadenziel des Modells („erst nach
  Abholung“); fehlt dort ein Preis, bleibt sie weg, mit Hinweis. Nach oben gilt dasselbe spiegelbildlich.
- Die Prämie erscheint in der Konfluenz nur noch als Hinweis. Der Prognose-Treiber gleichen Namens ist davon unberührt
  und bleibt bis U56 unverändert.

**Bilanz der Konfluenz (U61):**
- Der Browser meldet sein Ergebnis an `/konfluenz/log`, gespeichert in `konfluenz_log` im Prognosespeicher.
- `hl_forecast.konfluenz_bilanz` wertet Richtung nach 4 und 12 h sowie Zonen (erreicht, gehalten) gegen den Zufall aus.
- Anzeige unter dem Konfluenz-Kasten, als Debug-Eintrag und in der Wochenprüfung.
- Einschränkung: nur Zeiten mit offener Dashboard-Seite.

## 3www. Treiberfamilien im Parallelbetrieb (24.09., Version 2026-09-23.25, Opus 5.5)

Neues Modul `hl_familien.py` mit dem Dashboard-Abschnitt „Treiberfamilien“. Er zeigt Kennzahlenkarte, Chart der
Familienwerte über 72 h, Familien-Prognose und Treiber-Hygiene. Die bisherige Prognose bleibt unberührt.

**Familien und Horizonte**
- 9 Familien, je Coin ausgewertet, jede auf ihrem Horizont: Großkonten-Fluss 4 h, Trend lang 24 h, Momentum kurz 1 h,
  Orderfluss 1 h, Funding 24 h, ETF 24 h, Analog 24 h, Profi-Flow 4 h, Stärke 4 h (große Bewegung ja/nein).

**Bewertung**
- Je Block der Horizontlänge zählt der erste Fall.
- Zufall ist der Anteil steigender Blöcke im selben Zeitraum. Bei der Stärke ist es der Anteil großer Bewegungen
  (Betrag ≥ 1,5 σ).
- Ausgewiesen werden ungesehene Daten (letztes Drittel), Wochen, Ereignisse (Betrag ≥ 0,5) und die Überschneidung mit
  anderen Familien.

**Darwin für Familien**
- Wöchentlich; gut heißt z ≥ 2 über 14 Tage.
- Nach 2 guten Wochen in Folge steigt eine Familie auf und bekommt Gewicht in Höhe ihres Vorsprungs.
- Ohne aufgestiegene Familie gilt die Basisrate.

**Hygiene je Treiber**
- Befunde: nachlaufend, umgekehrt?, tot, ausgeschlossen. Die Coinbase-Prämie ist bis U56 ausgeschlossen.

**Profi-Flow**
- Das Dashboard zeichnet ihn alle 15 min in `familien_log` auf und schreibt alle 6 h die Wochenstufen fort
  (Thread `_familien_takt`).

**Einbindung**
- Debug-Eintrag „familien“, Teil der Wochenprüfung.
- Selbsttest-Schritt 24 (`hl_familien.py --nulltest`).
- Die neue Datei steht in den Dateilisten von version, update und install.

## 3xxx. v2-Korrektur (25.09., Version 2026-09-23.26, Opus 5.5)

**Ursache der Übersicherung:** `kalibrieren` gab jedem Treiber sein volles Prior-Gewicht als Logit-Koeffizienten zum Ziel
(`w0 = prior · s · anteil`). Stehen ~20 Treiber gleichgerichtet, summiert sich das zu p 85–99 %.

**Neu im Modell**
- Zielgewichte `BETA0 · prior / s_prior · s · anteil`. `s_prior` ist die Summe der Priors der Treiber, die in mindestens
  der Hälfte der Fälle vorhanden sind. Das entspricht einem gewichteten Durchschnitt wie in v1.
- Kalibrierschritt `kalibrierschritt()`: Aus den OOF-Treiberanteilen (`cv_lambda` liefert jetzt `oof_d` und `oof_c`)
  werden c und a gewählt. Es gilt p = sig(a + c · Σ w · score). Gewählt wird das kleinste c innerhalb eines
  Standardfehlers der gepaarten Fallverluste.
- U29: Die Brier-Referenz ist die OOF-Klimatologie.

**Neu in Prüfung und Anzeige**
- U35: Das Tor prüft den Log-Odds-Beitrag.
- Prüftor `gleichlauf()`: gemeinsamer Faktor ohne Signal.
- `p_up()` nutzt nur Modelle der Version 2.
- `score_forecasts` bewertet v2 nur aus Prognosen mit `kalib2.version` ≥ 2.
- In `kalib2_info` stehen zusätzlich `kalib`, `version` und `oof_roh`.
- `stand_text` zeigt c und a.

## 3yyy. Konten-Universum: alle Pool-Konten (25.09., Version 2026-09-23.27, Opus 5.5)

**Befund:** `select_poll_targets` fragt Pool-Konten alle 10 min ab (POOL_POLL_S). `track_whales` protokolliert davon
nur Konten ab `whale_track` = 10 Mio Gesamtwert. Die Positionen aller übrigen Pool-Konten gingen verloren.

**Neu im Recorder**
- `track_pool` im Anschluss an `track_whales`, nur für `pool_addrs` und nie für Gesperrte.
- Tabelle `pool_positions` im Schema von `whale_positions`. Hier ist `delta_usd` der gerichtete Fluss.
- Ereignisse: „snap“ bei erster Sicht und alle 6 h, dazwischen open/add/reduce/close/flip.
- Schwellen: `pool_pos_min` 50k, `pool_event_min` 10k.
- Geschrieben wird im Rundenpuffer (`flush_round`); einmal täglich werden Einträge älter als 120 Tage gelöscht.

**Neu in der Prognose**
- `hl_forecast._pool_treiber` liefert Pool-Positionierung, Pool-Flow 4 h und Pool-Timing-Flow.
- `PRIORS` = 0, `SCHATTEN_TREIBER`; in `compute_forecast` erzwungen weight = 0 mit Merkmal `schatten`.
- `hl_kalib.lade_faelle` lässt die Schatten-Treiber aus.
- `hl_viz._profis_rechnen` speichert `learned` „*“/„timing_positiv“.
- Treiberfamilien: neue Familie „Pool-Konten“.

**Nächstes:** Heatmap-Anker je Coin (23.28).

## 3zzz. Heatmap als Richtungsanker (25.09., Version 2026-09-23.28, Opus 5.5)

**Neues Modul `hl_anker.py`**
- `Markt`: Kurse, σ(4 h) aus 7 Tagen 15-min-Renditen mit laufenden Summen, Stundenvolumen als Median über 24 h.
- `anker_aus`: A = Ungleichgewicht der Cluster, dazu das stärkste Cluster je Seite.
- `bilanz`: je Klasse (ab 10 % / 25 % des Stundenvolumens) und Horizont (4/8/12/24/48 h) Trefferquote trendbereinigt
  und roh, Berührung gegen Spiegel-Niveau, überhitzt und normal getrennt. Das Ergebnis steht in `learned`
  coin/„anker_bilanz“.
- `jetzt`: aktueller Anker samt gespeicherter Bilanz.

**Dashboard**
- `/anker`, 5 min zwischengespeichert, mit Hinweis `gegen_bias` aus dem jüngsten gespeicherten Bias.
- Kasten `ankerbox` oben in der AI-Prognose.
- Die tägliche Bilanz läuft im Thread `_familien_takt`.

**Einbindung:** Debug-Eintrag „anker“ und Teil der Wochenprüfung.

**Selbsttest**
- Drei synthetische Märkte: Magnet, Rauschen und eine Trendfalle, in der die Cluster immer auf der Seite des
  24-h-Trends stehen.
- Die rohe Rechnung fällt in der Trendfalle herein (+36 bis +43 pp), die trendbereinigte nicht.

## 3α. Fünf Punkte (25.09., Version 2026-09-23.29, Opus 5.5)

**Coinbase-Prämie (U67):** `PRIORS` 0 und in `SCHATTEN_TREIBER`. Damit hat sie in v1 kein Gewicht, fehlt in v2 und
trägt das Kennzeichen „Schatten“.

**Magnet-Pfad (U9):** `compute_forecast` nutzt `liq_up`/`liq_dn` nur als Pfadziel, wenn `learned`
coin/„anker_bilanz“.belegt gesetzt ist (höchstens 8 Tage alt). Sonst gilt der σ-Ersatz. `magnet_info.anker_belegt`
zeigt den Stand.

**Selbsttest im Debug (U30)**
- `install.py --selftest-isoliert` kopiert den Projektordner nach /tmp. Dabei bleiben DBs, dbbackup, venv, Caches und
  Berichte außen vor.
- Der Test läuft mit eigenem `HL_FORECAST_DB` und ohne `HL_DB`. Ohne diese Trennung fände die Test-Instanz des
  Dashboards (Port 8799) über die systemd-Einheit den echten Prognosespeicher.

**Market-Maker aus dem Handel (U15)**
- `hl_forecast.mm_aus_handel`: Daten aus `fill_zaehler_h` und `pool_fills_hourly`, 10 min zwischengespeichert.
- Wirkt in `lb_groups` und in `behavior_map`/per_coin (hl_viz).

**Masterregel (U66)**
- Status „vorlaeufig“ gilt überall als ausgeschlossen: Recorder, hl_viz, hl_profis.
- Zweiter Tag (≥ 24 h nach „seit“) über der Grenze: dauerhaft.
- Nach 7 Tagen ohne zweiten Tag: frei.
- Einmalige Überführung der Einzeltag-Sperren (meta „sperre_zwei_tage“).
- `fill_zaehler_h` wird 8 Tage aufbewahrt.

## 3β. TradeLabor und Adress-Strom (27.09., Version 2026-09-23.33, Opus 5.5)

Wunsch des Nutzers 27.09.: ein Abschnitt „TradeLabor“, in dem alle verarbeiteten Daten und die simulierten Ein- und
Ausstiege live zu sehen sind. Ziel dahinter: prüfen, ob irgendeine Datenquelle eine belastbare Kante hat (Ziel des Nutzers
2–4 %/Tag -- im Labor wird das gemessen, nicht versprochen).

**Engine `hl_labor.py`**
- `Labor(db, store)`: Takt `zyklus(now)` alle 15 s im Dashboard-Thread `_labor_takt` (Start 30 s nach dem Dashboard,
  nicht bei `_selftest*`-Datenbanken, aus mit `HL_LABOR=0`). Eine Lese-Verbindung auf die DB (`mode=ro`), eine
  Schreib-Verbindung auf den Prognosespeicher.
- Tabellen im Prognosespeicher: `labor_strategie` (sid = name@sha1(regeln)[:8], eingefroren; eine Regeländerung ergibt eine
  neue sid, die alte wird `aktiv=0` und bleibt mit Bilanz stehen), `labor_position`, `labor_order`, `labor_ereignis`
  (90 Tage), `labor_zustand` (Pausen, Kaskaden-Zustand, scharfe Ausbrüche, gesehene Darwin-tids; nur bei Änderung
  geschrieben, flüchtige Schlüssel mit Unterstrich werden nicht gespeichert).
- 31 Strategien, `strategien()`: Händler 8 (Wal-Flow 30 min, Leaderboard-Flow 60 min, Smart Money direktional, Pool-Flow
  4 h; je folgen/gegen, Schwelle 0,5) + Darwin folgen/gegen (Einstieg ab 10k binnen 180 s, Ausstieg wenn das Konto
  schließt); Prognose v1 (p_up ±8 Punkte), v2 (p_up_v2 ±10, nur Version ≥ 2), Kauf-/Verkaufspreise als Limit (Bias
  ±0,12); 9 Familien (Schwelle 0,35, Horizont der Familie; Profi-Flow aus `familien_log`); Ereignisse: Kaskade (z ≤ −2,5
  bzw. ≥ +2,5 in 15 min UND Liquidationen HL+Binance+andere über max(p95 der 15-min-Summen 7 T, 3 × Median, 50k)) mit
  Umkehr (erste Gegenkerze ≤ 30 min, Ziel halber Rücklauf) und Fortsetzung, Docht fangen (Limit 0,25 σ1h hinter dem
  nächsten Cluster ≥ 10 % Stundenvolumen in 0,5–3 σ; liegende Order bleibt, solange ihr Cluster im Snapshot steht),
  Magnet (Anker |A| ≥ 0,5), Funding-Extrem (z ≥ 2 gegen 14 T stündlich), Ausbruch nach Ruhe (Stärke ≥ 0,5 macht 4 h
  scharf, Ausbruch 1 σ1h), TWAP-Druck (Null-Hash-Netto 60 min ≥ 2 % Stundenvolumen); Kontrolle Zufall (Ø alle 8 h),
  Halten Long (7 T). Standard: Stop 1,5 σ, Ziel 2 σ (σ4h aus 15-min-Renditen 7 T, skaliert mit √(h/4)).
- Ausführung: Markt = Mitte + halber Spread + Auswirkung über die kumulierten Tiefenbänder 10/25/50/100 bps von
  `book_summary` (jenseits 150 bps), Buch älter als 90 s → Minutenschluss mit Ersatz-Spread 1 bp (BTC/ETH) bzw. 4 bp.
  Limit nur bei Durchlauf (Tief < Limit), in der Füll-Kerze nur Stop. Stop vor Ziel, Kurslücke zum Eröffnungskurs,
  Einstiegsminute einer Markt-Order ungeprüft. Gebühren 0,045/0,015 %, Funding stündlich aus `ctx_bars`.
  Pause 15 min je Strategie und Coin nach einem Ausstieg. Ein Gegensignal schließt eine Position NICHT (nur Stop, Ziel,
  Zeit, Darwin-Folge).
- Kennzahlen `_stat`: Ø netto %, t, `p_zufall` einseitig per Student-t (`p_t_einseitig`, unvollständige Betafunktion),
  `p_glueck` = min(1, p × Zahl aktiver Strategien), Treffer, PF, max DD, Hälften, Kelly, Tagesrendite auf die Konten
  (Summe / Laufzeit / (Coins × 10k)); Hebel 1/3/5/10: Summe mit Liquidation (MAE × L ≥ 90 % → −Marge), Ø/Tag, Anzahl
  liquidiert, Kontofaktor sequentiell. Stufen wie im Plan (U71).
- Anzeige-Hilfen: `status_text` (was jede Strategie sieht), `live()`, `datenfluss()` (alle Eingänge mit Alter, Status,
  Nutzern), `uebersicht()`, `chart()`, `equity()`, `trades()`, `bericht_text()`.
- Schreiblast: Positionen/Orders nur bei Änderung (einmal je Minute), Zustand nur bei Änderung; Lesen mit gezielten
  Primärschlüssel-Abfragen (σ-Raster, Funding-Stunden), Anker nur bei neuem Heatmap-Snapshot.
- Selbsttest (`--selbsttest`, Installations-Schritt): synthetischer Markt mit Kaskade, Cluster, Darwin-Konto; Positivkontrolle
  (eingebaute 85-%-Kante → t ≥ 2), Gegenrichtung verliert, Zufallstreiber ohne Scheinbeleg, Zufall kostet, Gebühren,
  Darwin ein/aus, Docht-Füllung, Kaskade beide Richtungen, Neustart alle 400 Takte, Student-t-Werte, Liquidation.

**Adress-Strom `hl_adressfluss.py`**
- Recorder `on_trade` (verfolgte Coins, `users` vorhanden) → `Adressfluss.trade` im Speicher; `run_stream_fills` holt
  jede Minute die abgeschlossenen Minuten (10 s Gnade) und schreibt sie per `asyncio.to_thread` mit Upsert in
  `adressfluss.db` neben der DB. Tabellen `af_1m` (minute, coin, addr BLOB 20 Byte, taker_kauf/-verk, maker_kauf/-verk,
  n, twap; ganze USD) und `af_stat` (minute, coin, trades, nullhash, adressen, usd, twap_kauf/-verk), beide WITHOUT ROWID.
- Stündlich: Vorhalt (`--af-tage`, Standard 14), `af_stat` 90 Tage, Größendeckel (`--af-max-gb` 3, belegte Seiten),
  Kennzahlen, WAL falten. Schreibfehler: Zeilen bleiben bis 200.000 für den nächsten Versuch.
- Meta `adressstrom` (JSON der Kennzahlen) → Netzwerkstatus-Zeile „Adress-Strom“. Debug „Adress-Strom“ (`--bericht`).
- Deutung Null-Hash = TWAP ist unbestätigt; der Bericht zeigt, ob die Null-Hash-Käufe gleichmäßig über Minuten je Adresse
  laufen (typisch für TWAP).

**Dashboard:** Abschnitt `sec-labor` (Navi „TradeLabor“) nach den Treiberfamilien; Endpunkte `/labor`, `/labor/daten`,
`/labor/chart`, `/labor/trades`, `/labor/equity` (Zwischenspeicher 5–30 s); JS-Zustand `LAB` (Reiter, Hebel, Coin im
Browser gemerkt), Abruf alle 15 s nur bei offenem Abschnitt. Debug-Einträge „★ TradeLabor“, „TradeLabor-Selbsttest“,
„Adress-Strom“; Wochenplan um `labor` und `adressstrom` ergänzt, einmalig 28.09. 12:00. Jeder Handlauf im Debug wird
zusätzlich als `berichte/…_manuell.txt` gespeichert (U73). Nebenbei: `#famtab` scrollt im eigenen Rahmen (U74).

**Grenzen, die man kennen muss:** Simulation zur Buchmitte des 5-s-Buchs, keine Warteschlangenposition bei Limits; das
Labor sieht Signale nur ab dem Takt, in dem sie erscheinen (kein Nachholen nach einem Neustart, offene Positionen und
Orders werden aber über die Minutenkerzen der Pause korrekt nachgeprüft); bei gut 30 Strategien sind Zufallstreffer zu
erwarten -- nur „Glück“ unter 5 % und die Stufe „bewährt“ zählen.

## 3γ. Alle Korrekturen nach dem ersten Labor-Tag, XMR (29.09., Version 2026-09-23.34, Opus 5.5)

Anlass: Der erste Labor-Bericht (Pi, 29.09. 01:27) zeigte keinen einzigen Darwin-Trade, obwohl Profis gehandelt hatten;
`check_profis` (28.09. 23:48) meldete „qualifiziert 0“. Wunsch des Nutzers 29.09.: alle Korrekturen gleich, dazu XMR im Labor.

**1. Profi-Bewertung ohne pool_positions (U77).** `hl_profis.lade_ereignisse` las nur `whale_positions` und `lb_events`.
Die seit 23.27 geführte Tabelle `pool_positions` (Positionsänderungen ALLER Pool-Konten, 10-min-Raster, ab 50k/10k) wurde
nie gelesen. Konten unter der Wal-Schwelle und außerhalb des Leaderboard-Trackings hatten 0 bewertbare Ein-/Ausstiege,
obwohl sie handelten; im Bericht z. B. „Greg: 37 Trades/Tag, nur 0 bewertbare Ein-/Ausstiege“. Die Darwin-Liste trocknete aus.
Jetzt drei Quellen (`QUELLEN`). Dieselbe Entscheidung (Konto, Coin, Ein-/Ausstieg, Seite) zählt binnen 15 min einmal
(`DOPPEL_S`), und je Quelle wird gezählt: `bewerten()` liefert `quellen`, `n_mit_ereignissen`, `gruende`. Probe im
Nulltest `_quellen_test`: 5 von 5 Ereignissen; Doppel, snap, fremder Coin und fremdes Konto werden verworfen; ohne
Tabelle geht es weiter. `check_profis.py`: Kopf mit 2–150 und Timing-Regel, Zeile „Ereignisse der Aktiven (7 T)“ je Quelle,
eigene Kategorien (`grund_kategorie`): Aktivität, Gewinn 7 T, zu wenige Ein-/Ausstiege, Timing nicht belegt, Einstiege
widerlegt. Vorher zählte „Glück zu hoch“ als „zu wenige Ausstiege“. Die Nicht-Qualifizierten stehen die knappsten
zuerst; die Tabelle der Qualifizierten zeigt Ein/Aus, richtig, Zufall, Glück. Dashboard-Karte: Quellenzahl im Kopf,
Ausschlussgründe, wenn niemand qualifiziert ist.
Die Mitglieder der Darwin-Liste ändern sich weiter einmal täglich. Die Korrektur wirkt deshalb ab der ersten
Tagesbewertung nach 00 UTC (02:00 Uhr).

**2. Recorder: Fills der Darwin-Liste ohne Mindestbetrag (U79a).** `lb_fills_min_usd` (2.500 USD) galt auch für die Liste;
eine in Stücke zerlegte Eröffnung war unsichtbar. Jetzt gilt für Konten der Liste (`_darwin_set`, alle Mitglieder,
aktualisiert mit `darwin_ziele`) kein Mindestbetrag, im Stream, in userEvents und im REST-Abgleich. Der REST-Abgleich hätte
die kleinen Stream-Zeilen sonst gelöscht und nicht ersetzt. Deckel `DARWIN_KLEIN_MAX_H` = 200 kleine Fills je Konto, Stunde
und Quelle. `pool_fills_hourly` zählt nur Fills ab dem Mindestbetrag, sonst stiege die Aktivität der Listen-Konten
gegenüber dem übrigen Pool (Rückkopplung). Masterregel unverändert: `fill_zaehler_h` zählte schon alle Fills. Richtung
der Stream-Fills (`stream_richtung`): Wer in den letzten 20 min abgefragt wurde und keine Position hat, ist flach. Vorher
galt bei Konten ganz ohne Position „stream“, unbekannt, und das Labor sah es nicht. Nach der eigenen abgeleiteten
Eröffnung gilt deren Seite, solange sie jünger ist als der letzte Positionsstand. Meta `darwin_fills` →
Netzwerkstatus-Zeile „Darwin-Fills“. Probe `hl_recorder.py --selbsttest-fills` (Installations-Schritt).

**3. TradeLabor Darwin v2 (U79b, neue Kennungen).** v1 merkte sich jeden gesehenen Fill und summierte nur die NEUEN eines
Taktes. Eröffnungen, die sich über mehrere Takte verteilten, erreichten 10k nie. Jetzt (`_darwin`): Eröffnungen je Konto,
Coin und Seite netto über 15 min (`DARWIN_FENSTER_S`); Schließungen derselben Seite ziehen ab, nicht unter null. Ab 10k
beginnt eine Episode, wenn der jüngste Fill höchstens 180 s alt ist; je Eröffnung einmal, gespeichert in
`labor_zustand.darwin_ep`, höchstens 12 h. Den Folge-Ausstieg gibt es erst, wenn das Konto seit der Episode mindestens die
Hälfte davon wieder geschlossen hat (`DARWIN_AUS_ANTEIL`). Seit die kleinen Fills sichtbar sind, reichte sonst jedes
Nachjustieren. Regeln `fenster_s`, `aus_anteil` → neue sid, die v1-Bilanz bleibt als „alte Regelversion“. Nachrechnung
`darwin_episoden` (gleiche Regel über eine Fill-Reihe) für den Bericht.

**4. Blockstatistik (U78).** t, `p_zufall` (Student-t mit n_eff − 1), `p_glueck`, Hälften und Stufen laufen auf Blöcken:
Trades einer Strategie, die im selben Block ihres Horizonts h eröffnet wurden (`eroeffnet // (h·3600)`), gehen mit ihrem
Mittel als EINE Beobachtung ein (`bloecke`, Feld `n_eff`). Vorher zählte jeder Coin-Trade, und gleichzeitige Trades auf
korrelierten Coins täuschten Beleg vor (eiserne Regel 4). Ø netto, Treffer, Kelly und die Hebel-Ansicht bleiben je
Trade. Die Schwellen 15/30 gelten jetzt für Blöcke. Probe: 40 gleichzeitige Trades → n_eff 1, kein t, Kandidat.

**5. XMR (U80).** Fünfter Labor-Coin. Er ist HIP-3 und bekommt deshalb `GEB_FAKTOR` = 2: Zur Protokollgebühr kommt der
Betreiberanteil (0–300 %, je Markt), angenommen sind 100 %. `gebuehren_pruefung` vergleicht das mit echten Fills.
Kontotage (`coin_starts`, `labor_zustand` „coins“): Jeder Coin zählt ab seinem Start. Beim ersten Takt nach dem Update
erben BTC/ETH/ZEC/HYPE den Laborstart, XMR beginnt jetzt. `tag_pct` = Summe / Kontotage / 10k. Alte Regelversionen
zählen bis zu ihrem letzten Trade. Probe: Umstellung 23.33 → 23.34 auf einer Demo-Datenbank (erst ein Tag mit 23.33,
dann einer mit 23.34). Alte Kennungen bleiben, XMR-Start = Update, die v2-Darwin-Trades entstehen aus Stücken.

**6. Bericht (U81).** `hl_labor.py --bericht --db PFAD`: n (Blöcke), alle offenen Positionen mit Ablauf, Darwin-Prüfung
(Liste, Fills der Liste in 24 h nach Eröffnung/Schließung/ohne Richtung und unter 2.500 USD, Episoden nach der
Live-Regel, Einstiege der Strategie) und Gebühren-Prüfung. Debug-Eintrag mit `--db`; einmaliger Bericht 30.09. 12:00
(`check_profis`, `labor`); `check_profis` jetzt auch im Wochenplan. Nebenbei: Die Pool-Tabelle (Handy) und die
Treibertabelle (Desktop) scrollen im eigenen Rahmen, vorher lief die Seite seitwärts.

**Nicht in 23.34 (bewusst):** informierter Fluss je Adresse (U75, braucht ≥ 3 Tage Adress-Strom) und die Trennung TWAP
gegen ausgelöste Orders (U82). Beides wertet dieselben Daten aus, ist aber keine Korrektur.

## 3δ. Dauerlast des Dashboards: Anfragestau auf der Wal-Tabelle (30.09., Version 2026-09-23.35, Opus 5.5)

Befund 30.09. 00:24: CPU 100 %, Last 6,8 / 9,2 / 9,1, „CPU je Dienst“ hl_viz 366 %, Recorder 32 %. Laut Verlauf dauerhaft
seit 29.09. gegen 12 Uhr, vermutlich seit dem Neustart beim Einspielen von 23.34 (dieselbe Ursache hätte jeder andere Neustart
ausgelöst). Der Debug-Eintrag „Dashboard-Threads“ zeigte in drei Proben über 10 s dieselben Threads: 21-mal `behavior_map`
(sieben Seitenabrufe von /profis und /pool gleichzeitig), 17-mal `load_whales` (vier /whales-Abrufe und zwei Prognosen).

**Ursache:** Beide Funktionen lasen die GANZE Tabelle `whale_positions`. Sie hat keinen Vorhalt und wächst um rund 60.000
Zeilen je Tag: jede offene Wal-Position bekommt alle 10 min einen Snapshot.
- `behavior_map`: Volldurchgang `ORDER BY ts` in Python.
- `load_whales`: jüngste Zeile je Konto und Coin per korrelierter Unterabfrage über die ganze Historie, dazu zwei verschachtelte
  Unterabfragen für „offen seit“.
- Nachgestellt mit 2 Mio Zeilen (17 Tage, 200 Wale) auf einem schnellen Rechner: behavior_map 3,0 s, load_whales 41 s. Auf dem
  Pi entsprechend ein Mehrfaches.
- Schutz gab es nur als Zwischenspeicher (60 s bzw. 8 s) ohne Einzelflug. War er abgelaufen, rechnete JEDER Aufrufer selbst.
- Jede sichtbare Seite fragt /whales alle 20 s, /profis alle 60–120 s und /pool alle 5 min ab. Waren die Abrufe langsamer als
  ihr Takt, stapelten sie sich. Jeder zusätzliche Abruf machte alle langsamer, und der Stau löste sich nicht mehr.
- Lastprobe mit drei simulierten Seiten auf der 2-Mio-Tabelle: alt 196 % eines Kerns, in 90 s keine einzige /whales-Antwort.
  Neu 11 %, alle Antworten im Median 0,01 s. Mit acht Seiten 15 %. Zwei echte Browser-Seiten: 3 %.

**Änderungen (hl_viz, hl_score, hl_forecast, hl_profis):**
- **Fenster statt Historie:** Der jüngste Stand je Wal-Position kommt aus den letzten 6 h (`WAL_FENSTER_S`, `WAL_STAND_S`). Offene
  Positionen haben alle 10 min einen Snapshot; was 6 h keine Zeile hat, ist geschlossen oder der Recorder steht.
  - Das gilt für `behavior_map`, `load_whales`, den Konto-Score (`hl_score`), die Elite-Stände der Prognose (`hl_forecast`,
    zwei Stellen) und `roi_12h` in `hl_profis`.
  - Probe mit dem Muster aus hl_score: 3,95 s → 0,014 s.
  - Die Wiederherstellung des Wal-Zustands beim Recorder-Start bleibt über die ganze Historie (einmalig, Korrektheit).
- **„Offen seit“** (`_wal_eroeffnet`): Eine Eröffnung im 6-h-Fenster kommt direkt aus dem Durchgang. Ältere kommen aus einem
  Durchgang über die open/close-Ereignisse der letzten 30 Tage, der 10 min im Speicher bleibt. Noch ältere: „—“.
- **Gleicher Zeitstempel:** Dort gewinnt das Schließen den Stand. Die alte Abfrage lieferte zwei Zeilen je Position, wenn zwei
  Ereignisse dieselbe Sekunde trugen (add und snap): Die Wal-Tabelle zeigte sie doppelt, die Richtungssumme zählte sie
  doppelt, in der Probe 39,5 Mio. Außerdem blieben Scheinpositionen stehen („open“ und „close“ in derselben Sekunde).
  Probe: Ergebnis sonst identisch mit der alten Abfrage; behavior_map identisch.
- **Einzelflug:**
  - `behavior_map`: Während einer Berechnung bekommt jeder andere Aufrufer den vorigen Stand. Nur vor der allerersten Berechnung
    wartet er.
  - `load_whales(…, cache_s=20)` für /whales und die Prognose: je Coin und Fenster höchstens eine Berechnung, sonst vorigen
    Stand oder warten.
  - Der Server (`do_GET`, Tabelle `_RESP_TTL`) gilt für alle gespeicherten Abrufe: Läuft dieselbe Anfrage schon, kommt die
    vorige Antwort (bis 10 min alt) oder die laufende. Neu im Zwischenspeicher: /profis 30 s, /pool 60 s, /network_ext 60 s.
    /data und /whales gelten jetzt 15 statt 8 s.
  - /forecast und /restore/info hatten eine Lebensdauer, legten ihre Antwort aber nie ab. Das tun sie jetzt.
- **Seite:** `getJSON` fragt dieselbe Adresse nicht erneut, solange die erste Antwort aussteht.
- **Profis-Karten:** Die Fills je Konto kommen über den Primärschlüssel (`addr=?`). Vorher lief `lower(addr)=?` rückwärts durch den
  ganzen Zeitindex, bei Konten mit alten Fills durch Millionen Zeilen.
- **Diagnose:** `/debug/threads` liefert je Thread die verbrauchte CPU-Zeit (`/proc/self/task`), auch für Threads ohne
  Python-Rahmen. Der Debug-Eintrag „Dashboard-Threads“ druckt dazu „CPU je Thread zwischen Probe 1 und 3“.
- **Selbsttest** `hl_viz.py --selbsttest-last` (Installations-Schritt und Debug-Eintrag): Wal-Stand gegen die Wahrheit eines
  Generators, mit allen Fallen gleicher Zeitstempel. Dazu Einzelflug von behavior_map, load_whales und Server, jeweils eine
  Berechnung bei 6–8 gleichzeitigen Aufrufen.

**Offen:** Die Tabelle `whale_positions` wächst weiter ohne Vorhalt. Mit dem Fenster ist das nur noch Speicherplatz. Später:
Snapshots älter als z. B. 30 Tage auf einen je Stunde verdichten (U84).

## 3ε. Nach 23.35: Dashboard ruhig; Recorder-Start ohne Vollscan, Scheinpositionen Gesperrter (30.09., Version 2026-09-23.36, Opus 5.5)

Befund 30.09. 02:56, Debug „Dashboard-Threads“ auf 23.35:
- 13 statt 25 Threads. Die einzige laufende Anfrage ist die Probe selbst, alle 7 Hintergrund-Threads stehen in `time.sleep`.
- CPU der dauerhaften Threads 0 %. Die drei Threads „ohne Python-Rahmen“ sind der Rechenpool von numpy (OpenBLAS, Kerne − 1).
- Zum Vergleich 00:36: 14 Anfragen hingen in allen drei Proben (7× `behavior_map`, 3× `load_whales`, dazu beide Prognose-Rechner).
Beim Nachprüfen der übrigen Abfragen auf `whale_positions` fielen zwei Stellen im Recorder auf (U85, U86).

**1. Recorder-Start (`restore_whales`, U85).** Die Wiederherstellung des Wal-Zustands suchte den letzten Stand je Konto und
Coin per korrelierter Unterabfrage über die GANZE Tabelle. 23.35 hatte das bewusst gelassen („einmalig, Korrektheit“).
- Plan `SEARCH x USING COVERING INDEX ix_whale_addr (addr=?)`: je Zeile alle Zeilen desselben Kontos. Der Aufwand wächst mit
  der Summe der Quadrate der Zeilen je Konto, also quadratisch mit dem Alter der Tabelle.
- Gemessen auf der 2-Mio-Tabelle (gen_wale.py): 40–44 s auf einem schnellen Rechner, auf dem Pi ein Mehrfaches. Das läuft VOR
  dem Start von Feeds und Poller: Bei jedem Neustart (auch beim Einspielen) zeichnet der Recorder so lange nichts auf.
- Neu `wal_zustand_laden(con, gesperrt, fenster_s)`: nur die letzten 24 h (`WAL_WIEDERHER_S`) VOR DEM LETZTEN EINTRAG, nicht
  vor jetzt. So ist der Stand beim Anhalten auch nach tagelangem Stillstand vollständig. Gleichwertig, weil
  `snapshot_whales` alle 10 min jede Position im Zustand schreibt: ihr letzter Stand liegt sicher im Fenster.
- Gleicher Zeitstempel: close gewinnt. Ein Schnappschuss in derselben Sekunde wie das close erweckte die Position sonst nach
  jedem Neustart wieder, und der nächste Poll schrieb ein zweites close.
- Gesperrte werden nicht übernommen. Für sie gibt es kein close (H3), ihre Positionen kommen mit der nächsten 6-h-Abfrage frisch.
- Vergleich auf 2 Mio Zeilen: alt 984 Positionen in 40,5 s, neu 982 in 0,25 s. Der Unterschied sind genau die zwei
  Gleichstände Schnappschuss+close (Scheinpositionen der alten Abfrage), alle Werte sonst identisch.
- Startzeile jetzt: „N Wal-Positionen aus dem Protokoll übernommen (Zeilen der letzten 24 h, Sekunden, ausgelassene Gesperrte,
  Gleichstände mit close)“.

**2. Scheinpositionen gesperrter Wale (`track_whales`, U86).** H3 (Audit v10) schreibt für Gesperrte kein close-Ereignis, weil
ihre 6-h-Stände sonst wie Wal-Flow wirken. Das `del prev[coin]` stand aber in derselben Bedingung.
- Folge bis 23.35: Die geschlossene Position eines Gesperrten blieb für immer im Zustand, auch wenn das Konto weiter
  abgefragt wurde. Der Schnappschuss schrieb sie alle 10 min weiter, und jeder Neustart holte sie zurück.
- Jetzt verlässt die Position den Zustand ohne Ereignis.
- Dashboard: Die Exposure-Zeitreihe über der Wal-Tabelle (`_load_whales_roh`) zählt Gesperrte nicht mehr (Masterregel; Tabelle
  und Ereignisse waren schon gefiltert). In die Liste kommen nur Gesperrte, die im Coin und Zeitraum Schnappschüsse haben.
  Hatten Gesperrte große Positionen, sieht der Chart nach dem Update sichtbar anders aus.

**3. Diagnose (U87).** Die CPU-Liste je Thread sieht nur Threads, die über die Proben leben. Kurze Anfragen fehlten: „Summe 0 %“
wäre auch bei Last aus vielen kurzen Anfragen möglich gewesen.
- `/debug/threads` liefert zusätzlich `prozess_cpu_s` (/proc/self/stat, zählt auch beendete Threads).
- Der Debug-Eintrag druckt „Prozess gesamt“, „davon dauerhafte“, „Rest, kurze Anfragen“ und neue Threads je Sekunde (je
  Anfrage einer). Das Skript steht lesbar in `_VIZ_THREADS_SKRIPT`.
- Probe: ruhig 2 / 2 / 0 %. Mit zwei Schleifen kurzer /chart-Abrufe 112 % gesamt, 3 % dauerhaft, 109 % kurz, 177 Anfragen/s.
  Die alte Summe hätte 3 % gezeigt.

**Selbsttest** `hl_recorder.py --selbsttest-start` (Installations-Schritt, jetzt 25 Schritte):
- Generator mit 9 Fällen: offen seit 10 Tagen (nur 24 h im Fenster), geschlossen, Schnappschuss+close und close+open in
  derselben Sekunde, Flip, add, zwei Coins eines Kontos, alte Scheinposition außerhalb des Fensters, Gesperrter. Das Fenster
  hängt am letzten Eintrag nach drei Tagen Stillstand.
- Zustand = Wahrheit. Die alte Abfrage hätte 4 Scheinpositionen übernommen.
- Gesperrter: Eine geschlossene Position verlässt den Zustand ohne close, der nächste Schnappschuss schreibt sie nicht mehr.
  Nicht-Gesperrte bekommen ihr close wie bisher.
- Laufzeit auf 100.000 Zeilen 0,2 s.
- `hl_viz.py --selbsttest-last` prüft zusätzlich: Der 90-Mio-Short eines Gesperrten steht weder in Tabelle, Ereignissen noch
  Exposure.
- Gegenprobe mit der alten Logik (Mutation): beide neuen Prüfungen schlagen fehl.

**Stand der übrigen Leser von `whale_positions`:** Kein Dienst liest mehr die ganze Tabelle. „Offen seit“ im Dashboard liest
30 Tage open/close (10 min gecacht). Auf Abruf lesen weiter die volle Historie: `check_elite` (Elite-Stände) und die
Recorder-Prüfung „Wal-Lebenszyklen“ (`--audit`).

## 3ζ. Aktive Profis: Masterregel-Zählfehler und Darwin-Regeln v2 (30.09., Version 2026-09-23.37, Opus 5.5)

Anlass, Nutzer 30.09. 10:23: „Die besten kommen auf Bewährung, und rein kommen nicht besonders gute. SilkBtc ist trotz
deiner Ankündigung rausgeflogen, trotz super Ergebnissen. Wir müssen die Regeln anpassen!“
- Am 29.09. um 20:11 stand SilkBtc als #1 „auf Bewährung“: 7 von 10 Ein-/Ausstiegen richtig, Zufall 32 %, Glück 1,6 %,
  ROI 7 T 36,8 %, PnL 7 T 2,5 Mio.
- Die Ankündigung („das Etikett sollte heute Nacht verschwinden“) beruhte auf der Bewertung von 19:56. Um 02:00 flog das
  Konto hinaus. Belegen ließ sich der Grund von hier nicht; die Debug-Ausgabe zur Sperre zeigte vorläufige Sperren gar nicht.

**1. Zählfehler der Masterregel (U88, eigener Fehler aus 23.34).**
- Seit 23.34 speichert der Recorder für Konten der Darwin-Liste auch Fills unter 2.500 USD (Stream, userEvents, REST;
  höchstens 200 je Konto, Stunde und Quelle), fürs Labor.
- `sperre_pruefen` zählte die gespeicherten Fills ohne Betragsgrenze. Darwin-Konten wurden also strenger gemessen als alle
  anderen: gebündelte Trades in ALLEN Coins, auch Stücke von ein paar hundert USD.
- Am härtesten traf es die Besten. Die ersten 10 der Liste haben Echtzeit-Plätze (userEvents), dort kommt jeder Fill an.
  SilkBtc handelt in kleinen Stücken (im Screenshot 7 PUMP-Trades in 15 min).
- Über 300 Bündel in 24 h heißt vorläufig gesperrt. Ein gesperrtes Mitglied wird nicht bewertet, das zählt als Fehltag.
  Zusammen mit dem Fehltag vom 29.09. folgte der Abstieg. Ein zweiter Tag über 300 binnen 7 Tagen hätte die Sperre dauerhaft
  gemacht und die Rohfills gelöscht.
- Dasselbe galt für die Vielhandler-Regel des Vorhalts (> 500 Fills/Tag: Rohfills nur 1 Tag).
- Behoben: Beide zählen gespeicherte Fills nur ab `lb_fills_min_usd`, wie vor 23.34 und wie `pool_fills_hourly`.
- **Einmalige Neubewertung** `sperre_neubewertung_kleinfills` beim nächsten Fill-Lauf: alle automatischen Sperren seit
  29.09. 00:00 UTC (`KLEINFILL_SEIT`, frühester Stand von 23.34), vorläufig und dauerhaft. Sie werden mit der richtigen
  Zählung geprüft, in den 24 h vor der Sperre und in den letzten 24 h, jeweils Stream-Zähler und gespeicherte Fills ab
  2.500 USD. Liegt beides höchstens bei 300, wird das Konto freigegeben: Status „frei“, Quelle „kleinfill_neubewertung“,
  Grund mit der Zahl der zu Unrecht mitgezählten Bündel. Das Ergebnis steht in meta `sperre_kleinfill_neubewertung`.
- Grenze: Bei dauerhaften Sperren sind die Rohfills gelöscht, dort entscheidet der Stream-Zähler. Wer tatsächlich über 300
  liegt, wird beim nächsten Lauf wieder gesperrt.
- `check_sperre` zeigt jetzt vorläufige Sperren, Namen und die Freigaben der Neubewertung, und zählt wie der Recorder.

**2. Die Regeln selbst (U89): streng hinein, großzügig bleiben.** Simulation (`sim_regeln.py`, nicht im Paket):
- Population: 200 Konten ohne Vorsprung und 10 Könner. Etwa 1,4 Entscheidungen am Tag, Zufallsquote je Entscheidung
  20–50 %, Placebo mit 3 Punkten Rauschen, tägliche PnL mit Drift für die Könner. Sechs Läufe je Variante, 120 Tage.
- Heutige Regeln bei 20 Punkten Vorsprung: Könner nur 30 % der Zeit auf der Liste, im Mittel 3,9 Zufallskonten darauf,
  12,3 Aufnahmen je Woche (8,8 davon Zufall), 3,4 Könner fliegen je Woche raus.
- Neue Regeln: Könner 68 % der Zeit auf der Liste, 2,0 Zufallskonten darauf, 1,5 Aufnahmen je Woche (0,9 Zufall),
  0,5 Könner fliegen raus. Bei 15 und 25 Punkten Vorsprung ist das Bild gleich (19 % → 51 %, 39 % → 78 %).
- Mit Aufnahme bei 2 % statt 1 % stünden die Könner 72 % der Zeit auf der Liste, bei 3,5 Zufallskonten und 1,8
  Zufallsaufnahmen je Woche. Wegen der Klage über schwache Neuzugänge gilt 1 %. Das ist eine einzige Zahl
  (`AUFNAHME_P_GLUECK`).

Die Regeln in `hl_profis`:
- Timing über 14 Tage (`TIMING_TAGE`, vorher 7), die Aktivität weiter über 7 Tage.
- **Aufnahme:** 2–150 Trades/Tag, Gewinn 7 T > 0 UND 30 T > 0, ≥ 6 Entscheidungen, Glück ≤ 1 %, gedämpfter Vorsprung
  ≥ 10 Punkte, Einstiegs-Veto.
- **Verbleib:** 1–150 Trades/Tag, Gewinn 30 T > 0, ≥ 4 Entscheidungen, Glück ≤ 50 % und Vorsprung > 0, Einstiegs-Veto.
- `bewerten(con, mitglieder=…)` rechnet für Mitglieder (und für die Freigegebenen der Neubewertung) das Timing auch dann,
  wenn sie an der Aufnahme vorher scheitern. Je Konto: `aufnahme`, `verbleib`, `gruende`, `gruende_verbleib`.
  „qualifiziert“ bedeutet jetzt Aufnahme erfüllt. Mitglieder ohne Bewertung stehen mit Grund in `fehlend`.
- Die Tagesentscheidung ist jetzt die reine Funktion `darwin_tag(st, r)`. Das Dashboard lädt und speichert nur.
  - Abstieg nach 3 Tagen in Folge ohne Verbleib, mit dem Grund des letzten Fehltags.
  - Umstieg auf v2 einmalig und sofort: Aufnahme nach den neuen Regeln; die Fehltage der alten Regel bleiben stehen.
  - Beim Umstieg kommen außerdem die jüngst Abgestiegenen zurück, wenn sie die Verbleib-Regel erfüllen. Erkannt werden sie an
    gespeicherten Fills unter 2.500 USD seit 29.09.: Die gibt es seit 23.34 nur für Mitglieder der Liste
    (`bewerten(…, ehemalige_suchen=True)`, nur beim Umstieg). Sie flogen nach den alten, zu wackligen Regeln hinaus;
    so kommt SilkBtc auch dann zurück, wenn nicht die Sperre, sondern der alte Glückstest ihn hinausgeworfen hat.
  - Rückkehr zu Unrecht Gesperrter sofort und je Neubewertung einmal, nur mit erfüllter Verbleib-Regel.
  - Protokoll der Zu- und Abgänge mit Grund, 14 Tage.
- Das Dashboard sieht alle 5 min nach, ob die Neubewertung Freigaben geschrieben hat, und rechnet dann sofort (sonst
  stündlich).

**Anzeige:**
- Abschnitt 10 heißt „Aktive Profis — Darwin-Liste mit belegtem Timing“. Der Kopf nennt die Regeln v2.
- Die Karte zeigt „Verbleib erfüllt“ oder „Verbleib jetzt verfehlt: Grund“ und das Etikett „Fehltag x von 3“ statt „auf
  Bewährung“.
- Darunter: Mitglieder ohne Bewertung mit Grund, Zu- und Abgänge der letzten 7 Tage mit Grund.
- Die Pool-Tabelle zeigt für Mitglieder den Verbleib, sonst „aufnahmefähig“ oder den ersten Grund dagegen.
- `check_profis` gibt Mitglieder mit Fehltagen und Verbleib aus, dazu Protokoll, Aufnahmefähige und die Neubewertung.

**Labor:** „Darwin folgen“ und „Darwin gegen“ bekommen `liste=2`, also eine neue Kennung. Die Bilanz vermischt sonst zwei
verschieden zusammengesetzte Listen. Umstellungsprobe auf der Demo-Datenbank: 23.36 bis 12 h vor jetzt, dann 23.37. Die
alten Kennungen sind inaktiv („alte Regelversion“), die neuen handeln, keine Fehler.

**Proben:**
- `hl_recorder.py --selbsttest-sperre` (Installations-Schritt): 350 kleine und 20 große Bündel → frei; 350 große →
  vorläufig; Neubewertung gibt die Kleinfill-Sperre frei; echte Sperren (320 große, 350 Stream-Trades) bleiben, eine
  Sperre vor dem 29.09. bleibt unberührt, ein zweiter Lauf ändert nichts. Mit der alten Zählung schlagen zwei Prüfungen
  fehl.
- `hl_profis.py --nulltest` mit Glückstest für beide Schwellen (Zufallskonten aufgenommen 0,6 %) und Darwin-Test (11
  Schritte: Umstieg, Verbleib ohne Aufnahme, eine Entscheidung je Tag, gesperrtes Mitglied, Abstieg nach 3, Rückkehr nur
  mit Verbleib und einmal, Protokoll 14 Tage).
- Demo-Ende-zu-Ende: Umstieg nimmt einen Könner sofort auf und holt ein jüngst abgestiegenes Mitglied mit Verbleib zurück
  (seine Aufnahme wäre mit 1,5 % gescheitert); die Neubewertung gibt „SilkBtc“ frei (12 echte Bündel, 330
  kleine zu Unrecht mitgezählt); das Dashboard holt ihn zurück. Seine Aufnahme wäre mit 1,03 % knapp gescheitert, der
  Verbleib hält ihn. Browser Handy und Desktop ohne JS-Fehler, keine Seitwärts-Scrolls.
- Lastprobe `bewerten` (960 Pool-Konten, 450.000 pool_positions, 900.000 whale_positions): 23.36 mit 7 Tagen 2,1 s,
  23.37 mit 14 Tagen 3,0 s (schneller Rechner; auf dem Pi etwa das Dreifache, stündlich).

## 3η. Bericht 30.09. 19:55: Darwin-Regeln v3, falsche Freigabe, API-Gewicht hart gedeckelt (30.09., Version 2026-09-23.38, Opus 5.5)

Anlass: Sammeldatei der Berichte vom 30.09. (19:55, inhaltlich gleich mit 19:40), der erste Tag mit 23.37 auf dem Pi.

**Befund Aktive Profis (19:16):**
- 5 Mitglieder. SilkBtc ist zurück, über die strenge Aufnahme beim Umstieg auf v2: 20 von 28 richtig, Zufall 46 %,
  Glück 0,5 %, ROI 7 T 37 %.
- Korrektur einer eigenen Aussage: Nicht der Zählfehler der Masterregel hatte SilkBtc hinausgeworfen, sondern die alten
  Regeln. Die Neubewertung 23.37 gab nur ein einziges Konto frei, 0xb078…de15, und das zu Unrecht (U92).
- 0x64b7…9da9 kam beim Umstieg über die Verbleib-Regel zurück: 3 von 9, Glück 11 %, ROI 7 T −7,6 %. Die Aufnahme hätte es
  nie bestanden.
- Drei Altmitglieder aus v1 verfehlten den Verbleib und hätten erst am 03.10. gehen sollen:
  - 0x0c4a…1b19: kein bewertbarer Ein-/Ausstieg in 14 T, PnL 30 T −1,15 Mio.
  - perpfumbler: ebenfalls keiner, PnL 30 T −0,06 Mio.
  - 0xe867…c78e: 7 von 15, Glück 54 %.
- Bis dahin folgte ihnen das Labor. 0x0c4a eröffnete BTC 8,4 Mio und ETH 0,9 Mio long, beides kopierte „Darwin folgen“, und
  der Profi-Flow in BTC und ETH stand ihretwegen auf +1,00.
- Außer SilkBtc erfüllt niemand die Aufnahme. Die nächsten liegen bei 16,8 / 19,1 / 19,9 / 20,5 % Glück; das sieht nach
  Zufall aus.

**1. Darwin-Regeln v3 (U91): die Schonung nur nach strenger Aufnahme.**
- Die großzügige Verbleib-Regel mit 3 Fehltagen war für Konten gedacht, die die strenge Aufnahme bestanden haben. v2 gab sie
  beim Umstieg auch dem Altbestand und einer Rückkehr über die Verbleib-Regel. Das widerspricht „rein kommen nicht besonders
  gute“.
- `hl_profis.darwin_tag` führt jetzt den Merker `streng` (Adresse → Zeitpunkt). Jeder Weg auf die Liste verlangt die
  strenge Aufnahme: die Tagesentscheidung, der Umstieg, die Rückkehr zu Unrecht Gesperrter.
- Umstieg auf v3, einmalig und sofort:
  - Den Merker bekommt, wer unter v2 über die Aufnahme-Regel kam (Protokoll: Grund beginnt mit „Aufnahme“).
  - Wer ohne Merker auf der Liste steht, bleibt nur, wenn er die Aufnahme jetzt erfüllt. Sonst Abgang mit Grund „Umstieg auf
    die Regeln v3: ohne strenge Aufnahme … -- <erster Grund>“.
  - Danach Aufnahme nach den Regeln. Die Fehltage der Übrigen bleiben stehen.
- Keine Suche nach „ehemaligen“ mehr: `bewerten(…, ehemalige_suchen)` und `DARWIN_KLEINFILLS_SEIT` sind entfernt.
- Sicherheitsnetz in der Tagesentscheidung: Ein Mitglied ohne Merker bleibt nur mit Aufnahme. Nach dem Umstieg kann das nicht
  mehr vorkommen.
- Erwartung auf dem Pi, beim ersten Rechnen des Dashboards nach dem Update: SilkBtc bleibt (Merker vom 30.09. 11:21). Die
  anderen vier gehen, außer eines erfüllt dann die Aufnahme.
- Labor: `liste=3`, neue Kennungen für „Darwin folgen/gegen“; die v2-Kennungen werden „alte Regelversion“.
- `check_profis` zeigt je Mitglied „streng seit …“ oder „OHNE strenge Aufnahme“. Steht der Umstieg noch aus, rechnet es ihn
  auf einer Kopie vor („Vorschau: bleiben … · raus …“).

**2. Falsche Freigabe der Masterregel (U92).**
- 0xb078…de15 war vorläufig gesperrt: 362 gebündelte Trades, 926 Fills. Die Neubewertung 23.37 zählte 299 und gab es frei,
  mit „0 kleine Bündel zu Unrecht mitgezählt“. Der Zählfehler kann die Sperre also nicht verursacht haben.
- Die Lücke zwischen 362 und 299 stammt vermutlich aus der Vielhandler-Regel: Über 500 Fills/Tag bleiben Rohfills nur 1 Tag,
  die Fills vor der Sperre waren also schon gelöscht.
- Bedingung jetzt: Freigabe nur, wenn die gespeicherten Fills MIT den kleinen über 300 liegen (sie erklären die Sperre) und
  ohne sie wie im Stream höchstens 300.
- Einmalige Rücknahme `sperre_kleinfill_korrektur` für Freigaben ohne kleines Bündel, sofern das Konto noch „frei“ aus der
  Neubewertung ist:
  - Status und `seit` wie vorher; die 7-Tage-Frist läuft ab der ursprünglichen Sperre.
  - Quelle „auto“, Trades/Tag aus dem alten Grund, dazu ein Vermerk.
  - meta `sperre_kleinfill_neubewertung` bekommt „zurueckgenommen“ und „korrektur_ts“. „ts“ bleibt, damit das Dashboard
    nicht neu auslöst.
- `check_sperre` und `check_profis` zeigen die Rücknahme.

**3. API-Gewicht hart gedeckelt (U93, eiserne Regel 90 %).**
- Vollbericht 19:00: 1.092/1.080. Der Begrenzer (Eimer 180 + Reserve 216) erlaubt in 60 s Rate × 60 plus den Füllstand.
- Simulation in virtueller Zeit (Ereignisschleife springt), Last vom 30.09.: Poller in 23er-Runden, Orders 9 × 20,
  Leaderboard 78 × 2, Fills 40 × 22. Ergebnis: erste Minute nach jedem Start ~1.470 (über Hyperliquids 1.200), im Betrieb
  bis 1.118.
- Jetzt:
  - Das gleitende 60-s-Fenster ist ein harter Deckel (Budget × Temperaturfaktor, `deckel()`), mit laufender Summe.
  - Die Eimer werden nie voller als der Platz im Fenster. Ohne diese Klemme sammeln sie während einer Sperre an und entladen
    sich, sobald ein Klumpen aus dem Fenster fällt: Schwall und Stillstand im Wechsel, in der Simulation Lücken bis 12 s.
  - Leerer Start: Der vorige Prozess hat in derselben Minute vielleicht schon verbraucht.
  - Fehlt dem Ersten der Schlange der Platz, überholt ihn niemand.
- Ergebnis: Fenster ≤ 1.080, erste Minute 1.072, Durchsatz ~1.055 statt ~1.080/min (−2,5 %). Wartezeiten wie vorher.
- Nebenbefund U95 (offen): Kleine Abfragen überholen wartende 20er, so gebaut seit 17.09. Mit den Antwortzeiten des Pi
  bekommen die Orders ~165/min. Bei schnellerem Netz fielen sie in der Simulation auf 6/min.

**4. Anker-Bericht (U94).** `hl_anker.py --bericht` nimmt die Coins aus den 1-min-Kerzen statt aus der Heatmap. Bisher kamen
172 Blöcke „zu wenige Kursdaten“ (gut 500 Zeilen je Sammeldatei, 259 s).

**Weitere Befunde, ohne Änderung:**
- Labor gesamt −19.338 USD (24 h −8.378, Gebühren 7.434). Zufall-Kontrolle −2.375. Nichts belegt; beste t-Werte 1,2–1,4.
- XMR: Markt-Einstiege 55–115 bps von der Mitte, „Familie Orderfluss“ XMR −3.000 (t −5,4). Entscheidung U96.
- Prognose 4 h: 46 % gegen Basis 55 %. Kalibrierung v2: Tor bestanden, aber c = 0 für 5 von 6 Coins, sie sagt also die
  Basisrate. U7b noch nicht.
- Pool-Fills: Abholstand Median 29 h (Takt 12 h), 330 Konten wegen Budget zurückgestellt. Die Darwin-Bewertung stützt sich auf
  Positionsereignisse und ist davon nicht betroffen.

**Proben:**
- `hl_profis.py --nulltest`, Darwin-Test v3 14/14. Mutationen rot: Umstieg ohne Entfernen, Rückkehr über Verbleib, Merker nicht
  aus dem Protokoll, kein Sicherheitsnetz, Abstieg nach 2.
- `hl_recorder.py --selbsttest-sperre` 9/9, mit den neuen Fällen: Vielhandler mit gelöschten Fills bleibt, Rücknahme ohne
  kleines Bündel, Freigabe mit kleinen bleibt, einmalig. Mit der alten Bedingung 2 rot.
- `hl_recorder.py --selbsttest-gewicht` 7/7, neuer Installations-Schritt, jetzt 27. Mutationen „ohne Klemme“ und „voller
  Start“ rot.
- Demo-Ende-zu-Ende mit einem Stand wie auf dem Pi (v2, zwei Altmitglieder, SilkBtc streng, eine Rückkehr über Verbleib, eine
  falsche Freigabe ohne kleines Bündel):
  - Vorschau in `check_profis` stimmt mit dem Umstieg überein.
  - Das Altmitglied ohne Aufnahme geht mit Grund; der Rückkehrer bleibt, weil er die Aufnahme jetzt erfüllt; SilkBtc behält den
    Merker; eine zweite Bewertung ändert nichts.
  - Der Recorder nimmt die Freigabe zurück (vorläufig seit der ursprünglichen Sperre, 362 Trades).
  - Browser Handy und Desktop ohne JS-Fehler, keine Seitwärts-Scrolls.
- `install.py --selftest-isoliert`: 27 Schritte, PNG, 7 Dashboard-Abrufe, alles grün.

## 3θ. Elite als zweite Kopier-Vorlage im Labor, check_elite wie das Dashboard (30.09., Version 2026-09-23.39, Opus 5.5)

Anlass, Nutzer 30.09. 21:09: das Labor so laufen lassen und nach einer Weile auswerten; Frage, ob es Elite und Aktive Profis
als Vorlage nutzt. Stand bis 23.38:
- Die Darwin-Liste wurde kopiert („Darwin-Liste live folgen“).
- Die Elite nicht; sie steckte nur als einer von neun Treibern in „Familie Großkonten-Fluss“, und dort meldet die
  Familien-Hygiene sie in BTC, HYPE, ZEC und XMR als „tot“.
Nutzer 21:15: „Ja, setz alles gleich um“.

**1. „Elite live folgen“ und „Gegen die Elite“ (U97).**
- Dieselbe Regel wie bei der Darwin-Liste, damit die beiden Vorlagen vergleichbar sind:
  - Einstieg, wenn ein Konto im Coin netto mindestens 10k binnen 15 min eröffnet und der jüngste Fill höchstens 3 min alt ist.
  - Folge-Ausstieg, wenn das Konto mindestens die Hälfte wieder schließt; sonst Stop 1,5 σ, Ziel 2 σ oder nach 12 h.
- Vorlage ist die Elite des jeweiligen Coins: learned(coin, „elite“), vom Dashboard täglich aufgestellt (Konto-Score mit
  belegtem Vorlauf, Gewinn- und Aktivitätsschranke, ohne Gesperrte). Das Labor nimmt zusätzlich Konten heraus, die die
  Masterregel seither gesperrt hat.
- Code:
  - `_darwin` ist jetzt Liste plus gemeinsame Logik `_kopie`; deren Rumpf ist der bisherige, unverändert.
  - Zustand je Vorlage getrennt (`darwin_tids/_ep`, `elite_tids/_ep`), über Neustarts gespeichert.
  - Signale über `_sig_kopie`; die Darwin-Texte sind gleich geblieben.
  - Alle 31 alten Kennungen sind unverändert, die beiden neuen: `elite_folgen@8365f347`, `elite_gegen@1238a0fb`.
- Recorder:
  - `fill_konten_auffrischen` nimmt die Elite aller Coins in die Fill-Konten auf: Stream-Fills ab 2.500 USD, 0 Gewicht.
  - Bis dahin fehlten ihre Fills, wenn ein Elite-Konto weder Leaderboard-Auswahl, Pool noch Wal war.
  - Die Masterregel zählt diese Konten damit ebenfalls.
  - Die Richtung der Stream-Fills kennt der Recorder, weil die Elite jede Minute abgefragt wird (Wal-Takt seit 15.09.).
- Unterschied zur Darwin-Kopie: Die Elite ist nur mit Fills ab 2.500 USD sichtbar; für die Darwin-Liste speichert der Recorder
  auch kleinere.
- Bericht: „Elite-Prüfung (24 h)“ neben der Darwin-Prüfung. Sie zeigt die Elite je Coin, die Fills im eigenen Coin, die
  Eröffnungen ≥ 10k und die Einstiege.
- Dashboard: Datenfluss-Zeilen für die Elite, Hilfetext des Labors.

**2. check_elite rechnet wie das Dashboard (U98).**
- Der Bericht vom 30.09. zeigte 0x645b…87b8 und 0x3ff5…f705 in der Elite, beide von der Masterregel gesperrt. „Dominanz 63 %“
  war 0x3ff5.
- Das Dashboard nimmt Gesperrte heraus, das Werkzeug nicht. Außerdem stufte das Werkzeug unbekannte Konten als direktional
  ein und kannte das Verhalten je Coin nicht.
- Jetzt:
  - Einstufung über `hl_viz.score_klasse`; der Lernzyklus nutzt dieselbe Funktion (aus dem Block herausgezogen, gleiches
    Verhalten).
  - Ohne Gesperrte, mit einer Zeile, wen die Masterregel herausnimmt.
  - Zusätzlich die gespeicherte Elite, die Treiber, Recorder-Vorrang und Labor tatsächlich nutzen, mit Abweichungen zur
    frischen Rechnung und „davon inzwischen gesperrt“.

**3. Entscheidungen.**
- U96 XMR: so laufen lassen (Nutzer).
- U99: Auswertung des Labors ab 11.10.; für Darwin v3 und Elite ab etwa 14.10.

**Proben:**
- `hl_labor.py --selbsttest` mit Elite-Szenario:
  - 3 Stücke zu 4k über den Labor-Neustart hinweg; eine Teilschließung von 1k wird ignoriert; Folge-Ausstieg nach 90 min.
  - „Gegen die Elite“ nimmt die Gegenseite.
  - Die 20k-Eröffnung eines gesperrten Elite-Kontos wird nie kopiert.
  - Ein Konto in beiden Vorlagen: beide kopieren es, beide mit Folge-Ausstieg.
  - Mutationen rot: Zustand nicht gespeichert, Gesperrte nicht gefiltert, gemeinsamer Zustand der Vorlagen.
- `hl_recorder.py --selbsttest-fills`: Elite-Konto außerhalb von Auswahl, Pool und Walen wird Fill-Konto, sein 5k-Fill wird
  gespeichert, der 1k-Fill nicht; ein gesperrtes Elite-Konto nie.
- Umstellungsprobe auf der Demo-Datenbank: alte Darwin-Kennungen als „alte Regelversion“, neue Elite-Kennungen aktiv, keine
  Fehler, Bericht mit Elite-Prüfung.
- check_elite auf synthetischer Datenbank: Das gesperrte Konto mit Beleg fehlt in der Elite und steht in der Masterregel-Zeile.
- `install.py --selftest-isoliert`: 27 Schritte, PNG, 7 Dashboard-Abrufe, alles grün.

## 3ι. Grid-Bots im TradeLabor: Grid Long und Grid Short (01.10., Version 2026-09-23.40, Opus 5.5)

Anlass, Nutzer 01.10. 21:05: „Das Trading-Labor um die Funktion eines Grid-Bots erweitern. Er soll die Range automatisch
erkennen und anpassen, bei einer plötzlichen starken Bewegung aufwärts das Maximum abwarten und erkennen und nicht zu früh
verkaufen, bei stark fallenden Kursen einen Notausstieg auslösen und so laufend Rendite generieren.“ Auf Rückfrage
entschieden: **Long und gespiegeltes Short** (zwei Strategien), **mit Startbestand** (klassisches Grid), **eine Variante**.

**1. Regeln (eingefroren, Gruppe „Grid“, Kennungen `grid_long@…`, `grid_short@…`; alle übrigen Kennungen unverändert).**
- Range aus den 1-min-Kursen der letzten 24 h: 10. und 90. Perzentil. Nach einem Ausstieg nur Kurse ab dann (mindestens 2 h).
- Trendmaß mit Vorzeichen: ln(Ende/Anfang) / (σ der 5-min-Renditen · √Anzahl) — für einen Zufallsweg standardnormal,
  unabhängig von der Fensterlänge. Aufgebaut und nachgeführt wird nur bei höchstens 1 gegen das Grid (Long: abwärts) und
  höchstens 2 in Grid-Richtung (`grid_trend_ok`). Start nur mit dem Kurs im mittleren Teil (60 %) der Range, nicht während
  einer Kaskade.
- Stufen geometrisch, so viele, wie mit ≥ 0,2 % Abstand passen, 4–12 (`grid_stufen`); unter 4: „Range zu eng“, warten.
- Kapital: 10.000 USD je Coin (`GRID_KAPITAL`), gleich auf die Stufen verteilt. Jeder Abstand [Li, Li+1] hält entweder ein Los
  oder eine Einstiegs-Order. Long kauft bei Li und verkauft bei Li+1, Short verkauft bei Li+1 und kauft bei Li zurück (Maker).
  Nach jedem Verkauf liegt dort wieder ein Einstieg.
- Startbestand: Die Abstände jenseits des Kurses in Gewinnrichtung (Long: darüber) bekommen beim Aufbau ein Los zum
  Marktpreis (ein gemeinsamer Taker-Auftrag, Marktauswirkung aus der Buchtiefe), die übrigen eine Order.
- Nachführen stündlich, wenn sich die Mitte um ≥ 1 Stufe verschiebt oder die Breite um ≥ 25 % ändert (Kurs innerhalb der
  neuen Range, Trendmaß erlaubt). Vorhandene Lose behalten ihr Ziel und zählen auf den Bestand an; gekauft wird nur, was zum
  klassischen Bestand fehlt, Orders nur, soweit das Kapital reicht (Lose aller Generationen + Orders ≤ 10.000).
- Halten (der Wunsch „nicht zu früh verkaufen“): Squeeze bzw. Kaskade in Grid-Richtung (Labor-Erkennung), ≥ 3 σ in 5 oder
  15 min in der Gewinnhälfte der Range, oder Kurs eine Stufe jenseits der Range in Gewinnrichtung. Dann keine Ziele mehr, alle
  Lose bleiben, Trailing-Stop 1,5 σ(1 h) vom Extrem (σ beim Start festgehalten, Stop nur nachgezogen), danach 2 h Pause und
  eine neue Range aus Kursen ab dann. Ein Maximum ist nur im Nachhinein erkennbar — der Rückfall um 1,5 σ ist die Erkennung.
  Ohne Bestand beim Ausbruch: Grid ruht 2 h.
- Notausstieg: Kaskade gegen das Grid, ≥ 3 σ in 15 min in der ungünstigen Hälfte, oder Kurs an der Notlinie eine Stufe
  jenseits der Range. Alle Lose zum Marktpreis (ein Auftrag), Orders weg, Pause 4 h; nach dem zweiten Notausstieg binnen 24 h
  12 h, nach dem dritten 24 h.

**2. Was die Probe auf dem synthetischen Markt an den Regeln geändert hat (vor dem Einfrieren).**
- Ein Auslöser nur über 15 min kam in einer schnellen Rallye zu spät: Ein enges Grid (1,9 % Range, 0,21 % Stufen) hatte seinen
  Bestand auf den Stufen schon verkauft, bevor +3 σ über 15 min erreicht waren — genau das „zu früh verkaufen“. Deshalb auch
  5 min. Danach hielt Grid Long 2 Lose durch die Rallye und verkaufte nahe dem Hoch (+124 USD statt ~+5 USD auf den Stufen).
- Ein Trendmaß ohne Richtung (|Trend| ≤ 1,5) ließ Grid Long im langsamen Abwärtstrend dreimal neu aufbauen, jedes Mal mit
  Notausstieg (−85 bis −112 USD). Deshalb streng gegen das Grid, großzügig mit ihm, und längere Pausen nach Wiederholungen.
- Der Schub-Auslöser zählt nur in der Gewinnhälfte der Range (spiegelbildlich zum Notausstieg): Unten ist ein schneller
  Anstieg ein Rücklauf innerhalb der Range, dort soll das Grid normal verkaufen.

**3. Mechanik (`hl_labor.py`).**
- Lose = `labor_position` (Notional = Kapital / n, Ereignisart „grid_los“), Einstiegs-Orders = `labor_order` (nur offene;
  gefüllte und gelöschte verschwinden), Zustand je Strategie und Coin = `labor_zustand` „g“ (Modus warten/aktiv/halten/pause,
  Stufen, Notlinie, Halten, Pause, Kerzen-Stand, Zähler, Notausstiege der letzten 24 h).
- Kerzen-Replay wie bei den übrigen Strategien: Ein Limit füllt nur, wenn eine spätere 1-min-Kerze DURCH den Preis läuft.
  Reihenfolge in einer Kerze bewusst vorsichtig: erst Einstiege in Verlustrichtung, dann Notlinie bzw. Trailing-Stop für
  ALLE Lose (auch die eben gefüllten), erst dann Ziele; Auslöser zum Kerzenschluss; zuletzt freie Abstände neu belegen.
- Auslöser zusätzlich im 15-s-Takt (Kaskade, z15 aus der Kaskaden-Erkennung, z5 aus dem Schluss vor 5 min). Halten mitten in
  der Minute: Ziele, die der Kurs bis dahin schon durchlaufen hat, gelten als verkauft; der Trailing-Stop zählt erst ab der
  nächsten vollen Kerze (die laufende enthält Kurse von vor dem Auslöser).
- Nach langem Ausfall Kerzen in Etappen (höchstens 3 Tage je Takt); bis alles nachgeholt ist, keine Auslöser und kein Aufbau
  zum Kurs von jetzt.
- Jedes Grid läuft hinter einem eigenen Sicherungspunkt (SAVEPOINT): Ein Fehler rollt nur dieses Grid in diesem Takt zurück,
  Datenbank und Zustand, statt halbe Änderungen zu speichern.
- Lose und Orders abgelöster Grid-Regelversionen (neue Kennung) werden beim ersten Takt geschlossen bzw. gelöscht.
- Die übrigen Strategien: `_orders`, `_positionen` und `_signale` überspringen das Grid; `_eroeffnen`/`_schliessen` kennen ein
  Notional je Position und eine Ereignisart (Standard wie bisher); kein Verhalten geändert.

**4. Bewertung nach Bestandswert.**
- Ein Grid zeigt laufend kleine realisierte Gewinne, während sich Verluste im Bestand sammeln. Deshalb hält das Labor den
  Bestandswert fest (`labor_grid_tag`: nach jeder Änderung und alle 5 min, ein Stand je Tag) und rechnet das
  **Tagesergebnis = realisiert im Tag + Änderung des unrealisierten Bestands** (`grid_tage`).
- Für die Grids sind die Blöcke Tage mit diesem Ergebnis (in % des Kapitals aller Coin-Konten): t, Glück, Hälften, Stufen.
  Summe, Ø/Tag und Hebel-Summe zählen den letzten Bestand mit, max DD aus den Tagen, die Bilanzlinie hat Tagespunkte.
- `_stat`: Trades mit eigenem Notional (Lose) — Liquidation kostet ihre Marge, der Kontofaktor wächst mit ihrem Anteil. Für
  10.000-USD-Trades identisch zu vorher (Selbsttest unverändert grün).
- „Ø netto“ je Los ist klein (eine Stufe abzüglich Gebühren); beurteilt wird ein Grid nach dem Tagesergebnis.

**5. Anzeige und Bericht.**
- Live: Zelle je Coin mit Modus (▦ aktiv x/n Lose, ⇡/⇣ hält, ⏸ Pause, wartet mit Grund) und Bestandswert.
- Positionen: Grid-Lose und -Orders je Grid und Coin gebündelt (Lose, Einsatz, Ø Einstieg, Bestand, Range, Schritt,
  Notlinie bzw. Trailing-Stop, Orders von–bis).
- Chart: mit gewähltem Grid Range (blau), Notlinie (rot gestrichelt), Trailing-Stop (gelb); ohne Auswahl keine Grid-Lose.
- Strategien: Summe nach Bestandswert mit Aufteilung realisiert/Bestand und Tagesergebnissen.
- Ereignisse: Aufbau, Nachführen, Halten, Notausstieg (Art „grid“); die einzelnen Lose getrennt (`ereignisse_grid`, unter
  „alles“) — sonst verdrängten Hunderte Lose am Tag alle übrigen Ereignisse aus den letzten 150.
- Trades: Netto je Los mit seinem Notional. Datenfluss: Range 24 h, Trendmaß (Long/Short darf oder wartet), Stufen.
- Bericht „★ TradeLabor“: Abschnitt „Grid-Bots“ je Grid und Coin (Modus, Range, Lose, Bestand, Runden, Aufbauten,
  Nachführungen, Halten, Notausstiege); die Kopfzeile nennt Grid-Lose und Bestand getrennt.

**Proben:**
- `hl_labor.py --selbsttest` (rund 50 s): synthetischer Markt (Sinus 1 % mit 4 h Periode, Rallye +5 % in 40 min bis +7 %,
  Crash −6 % in 10 min mit Long-Liquidationen, langsamer Abwärtstrend −0,4 %/h über 10 h), 2-min-Takt mit Neustart mitten
  im Halten: Aufbau, Kapital nie über 10.000, seitwärts jede Runde im Gewinn (je 58 Runden vor der Rallye), Long hält die
  Rallye und verkauft nahe dem Hoch, Short Notausstieg in der Rallye, Long Notausstieg im Crash und 4 h keine Lose, Short
  hält den Crash und kauft nach dem Tief zurück, Long baut nicht in den Abwärtstrend und verlässt ihn an der Notlinie,
  Tagesbilanz = realisiert + Bestand = Bilanzlinie, 10-min-Takt holt über die Kerzen nach. Mikro-Proben auf festen Kerzen:
  Kapitaldeckel mit Losen früherer Stufen, Trailing-Stop erst ab der Kerze nach dem Auslöser, Notlinie nach der Füllung in
  derselben Kerze. Dazu abgelöste Regelversion, Fehler hinter dem Sicherungspunkt, Stufen und Trendmaß.
- Mutationen (je einzeln, alle rot): ohne z5, Trendmaß ohne Richtung, Kapital ignoriert, kein Sicherungspunkt, Stop schon in
  der Startkerze, Notlinie aus, Pause nach Notausstieg 0 h.
- Browser (Handy 390 px, Desktop): alle sieben Reiter mit laufendem Labor auf einem synthetischen BTC-Markt, keine
  Labor-Fehler, keine Seitenbreite über dem Bildschirm.
- `install.py --selftest`: alle Schritte grün (Labor-Schritt jetzt mit Grid, rund 50 s in der Sandbox, auf dem Pi länger).

**Was man wissen muss:** Mit zwei Strategien mehr (35) wird „Glück“ für alle etwas strenger. Grids erzeugen viele Lose (in
der Probe rund 60 Runden je Tag und Grid bei 1,9 % Range) — die Tabelle `labor_position` wächst entsprechend (U102). XMR
handelt mit doppelten Gebühren (Runde 0,06 % bei ≥ 0,2 % Stufen). Auswertung: U101.

**Praxis-Hinweis (Frage des Nutzers 01.10. 22:26, geprüft):** Hyperliquid kennt je Konto und Coin nur EINE Netto-Position (kein
Hedge-Modus). Grid Long und Grid Short in einem Konto würden sich verrechnen -- in der Probe hielten beide in 244 von 301 Momenten
gleichzeitig Lose. Das Labor rechnet jede Strategie als eigenes Konto; in der Praxis entspricht das je Grid einem Sub-Account
(eigene Adresse, eigene Positionen und Margin; bis 10 ab 100.000 USD Handelsvolumen, gleiche Gebührenstufe wie das Hauptkonto).
Innerhalb eines Grids passt die Rechnung: alle Lose auf einer Seite = eine Position mit Durchschnittspreis, die Stufen-Verkäufe
wären Reduce-only-Limits. Self-trade prevention gilt je Adresse (die ruhende Order wird gelöscht). Gilt für alle Labor-Strategien.
Beide Grids nutzen dieselbe Range, solange beide dasselbe 24-h-Fenster sehen; auseinander laufen sie nach einem Ausstieg (Fenster ab
dem eigenen Ausstieg) und beim Nachführen (Trendprüfung mit Richtung).

## 3κ. „database is locked“ im Labor nach 23.40 (02.10., Version 2026-09-23.41, Opus 5.5)

Befund Pi 02.10. 06:57:46, Labor-Kopf „Meldungen“: „ZEC Handel: OperationalError: database is locked“.

**Ursache (eigener Fehler aus 23.40):** `_grid` öffnete die Transaktion mit einem einfachen `BEGIN` (verzögert), um jedes Grid hinter
einen Sicherungspunkt zu legen. Hatte das Labor in diesem Takt bis dahin noch nichts geschrieben, war das eine LESE-Transaktion: Das
Grid las Lose und Orders, der Lesestand war damit festgelegt. Schrieb danach ein anderer Thread in den Prognosespeicher (Prognose,
Familien, Profis), war dieser Stand veraltet -- der nächste Schreibzugriff des Labors im selben Takt (hier ZEC, Funding/MAE einmal je
Minute) scheiterte SOFORT, ohne die 30 s Wartezeit (Snapshot-Konflikt im WAL-Modus). Genau diese Falle ist im Projekt seit dem 14.09.
bekannt (`hl_recorder.db_connect`: isolation_level „IMMEDIATE“; `hl_dbcoord`: „ein von Hand ausgeführtes BEGIN“).
- Folgen: keine Datenschäden. Der Takt verliert seine Schreibzugriffe (bricht er ab, wird er ganz zurückgerollt, der Zustand neu
  geladen); Grids und Stops holen über die Kerzen nach. Verloren ist höchstens ein 15-s-Signal.
- Nachgestellt: zwei Verbindungen (`BEGIN`; lesen; fremder Commit; schreiben → sofort „database is locked“, mit `BEGIN IMMEDIATE`
  wartet der andere Schreiber); Labor-Probe mit fremdem Commit während der ZEC-Eingaben: 23.40 ein Abbruch in 240 Takten
  (`_zustand_speichern`), Korrektur 0.

**Korrektur:**
- `BEGIN IMMEDIATE`: Schreibsperre gleich zu Beginn, wartet wie jeder Schreibzugriff (30 s). Ist sie länger belegt, setzen nur die
  Grids diesen Takt aus (Meldung), statt den Takt abzubrechen.
- Grids zum Schluss des Takts statt je Coin mittendrin: Die Sperre gilt dann nur für Grids, Zustand und Commit, nicht für die
  Eingaben der übrigen Coins (Labor-Probe: fremde Commits während der ZEC-Eingaben wieder möglich, 180 von 240; Takt 7 ms wie vorher).
  Die Grids handeln getrennt von den übrigen Strategien; Ergebnisse im Selbsttest Zahl für Zahl gleich.
- Selbsttest „Grid: fremder Schreiber im Takt, kein database is locked“: ein zweiter Schreiber commitet, während das Grid liest; mit
  dem alten `BEGIN` rot (genau die Meldung vom Pi), jetzt grün.

## 3λ. Fusionsprognose, Kalibrierung v3, Kostenschwelle — Stufe 1 im Schatten (04.10., Version 2026-09-23.42, Opus 5.5)

Anlass, Nutzer nach 23.41: „Hast du Ideen oder Überlegungen, ob es mathematische oder psychologische Ansätze gibt, … die
Kursprognose mit einem fusionierten Treiber in eine Formel zu packen, die einen noch besseren prädiktiven Wert erzielt?“ Antwort:
Werkzeugkasten (Bewertungsregeln, Kostenschwelle, Teilen über Coins, Expertenmischung mit Garantie, Schwankungsmodelle, konforme
Bänder, Berührwahrscheinlichkeit, Hawkes, Einstandsanker, Stop-Jagd, Herdenmaß, Regime-Tor) in drei Stufen. Danach: „Leg los.
Mach es perfekt und fehlerfrei.“ Konzept und Begründungen: **`KONZEPT_Fusion.md`** (neu im Paket). Plan: U104–U112.

**1. Gebaut (`hl_fusion.py`, neu; alles im Schatten — angezeigte P(aufwärts), Pfad, Bias, Kaufpreise unverändert).**
- **Kostenschwelle (U104):** p* = ½ + K / (2 · E|r_h|) je Coin für 1/4/12/24 h. E|r_h| gemessen: Mittel |ln(P(t+h)/P(t))| über
  30 Tage im 15-min-Raster (≥ 288 Punkte). K Taker = 2 · (Taker-Gebühr + halber Spread, Median der letzten Stunde aus
  `book_summary`), K Maker = 2 · Maker-Gebühr, Sätze aus `hl_labor` (XMR doppelt). Je Coin stündlich, im Payload als `kosten`.
- **Kalibrierung v3 (U105):** p = sig(a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f) auf den sieben Richtungsfamilien (ohne Stärke,
  Pool-Konten, Profi-Flow), gemeinsame Gewichte β, Abweichung je Coin δ mit Strafe r · λ_β (r ∈ {∞, 64, 16, 4, 1}), Achsenabschnitt
  je Coin, Kalibrierfaktor c ∈ {0; 0,1; …; 1}. Daten wie v2 (90 Tage, früheste Prognose je Block, Toleranz-Labels, 14 Tage
  Halbwertszeit, U41). Stündlich in `_familien_takt` (erstmals 5 min nach dem Start), learned „*“/`kalib3_4`, `kalib3_24`, Fehler in
  `kalib3_h_fehler`; jede Prognose trägt `p_up_v3` (gespeichert) und `p_up_24_v3`.
- **Fusion (U106):** Mischung der Experten Basisrate, v1, v2 (ab Modellversion 2), v3, Analog (50 Pseudo-Fälle zur eigenen
  Basisrate); p geklemmt auf [0,02; 0,98]; Bayes-Update nur für wache Experten (schlafende behalten ihr Gewicht), Fixed Share
  α = min(0,05; h/336); Garantie L_Fusion − L_m ≤ ln 5 + (T − 1) · ln(1/(1 − α)). Tabelle `fusion_fall` im Prognosespeicher
  (eine Zeile je Coin, Horizont, Block; die früheste Prognose zählt), Auflösen nach h (y = −1 unter der Toleranz, −2 ohne Kurs
  nach einem Tag), einmaliger Nachtrag aus den gespeicherten Prognosen (60 Tage), prequential. Bilanz mit Abstand zur Basisrate
  ± 1 Standardfehler; im Debug zusätzlich nur live gestellte Blöcke und alle Coins zusammen (Zeitblöcke als Klumpen).
- **Labor (U107):** „Prognose Fusion“ (`prognose_fusion@40662765`, feste Schwelle wie v1) und „Fusion mit Kostenschwelle“
  (`prognose_fusion_kosten@aefe5404`: nur wenn |2p − 1| · E|r 4 h| ≥ 1,5 × (2 · Taker + Abstand zur Buchmitte bei 10.000 USD,
  Ein- und Ausstieg)). `_prog` liest `$.fusion.p_4` und `$.kosten.er_4` aus dem Payload. Die 35 übrigen Kennungen unverändert.
- **Einbau:** `hl_viz._forecast_compute_inner` ruft `hl_fusion.ergaenzen` vor `store_forecast` (ein Fehler hält die Prognose nie
  an, er steht in `fusion.fehler`); Kacheln „P(aufwärts) Fusion — Schatten“ (AI-Prognose) und „Fusion und Kalibrierung v3“
  (Selbstoptimierung); Debug „★ Fusion und v3“ und „Fusion, v3 und Kostenschwelle: Selbsttest“; Berichtsplan wöchentlich (W11),
  einmal 11.10. 19:30 (`u106-fusion-woche1`) und 25.10. 19:30 (`u108-fusion-auswertung`). `hl_forecast`: `p_up_24_v1` im Ergebnis,
  `store_forecast` lässt `fusion_info`, `kalib3`, `kalib3_24` (Anzeige) aus dem Payload. `install.py`: Selbsttest-Schritt
  „Fusion, v3, Kostenschwelle“ (28 Schritte). `update.py`: `hl_fusion.py`, `KONZEPT_Fusion.md` in PROJECT_FILES.

**2. Entscheidungen beim Bau.**
- **Familienwerte statt Treiber** in v3: 7 statt rund 30 Gewichte; Teilen über Coins braucht Größen, die überall dasselbe messen.
- **Kein Familien-Experte:** Die Familien-Prognose wird nicht je Prognose gespeichert (kein Nachtrag), und bis eine Familie
  aufsteigt, ist sie eine Basisrate ohne Halbwertszeit — ein Doppel, das nur ln M kostet (Stufe 3, U112).
- **λ-Wahl:** verglichen wird der OOF-Treiberanteil mit Achsenabschnitten je Coin aus denselben OOF-Fällen (mit denen der
  Trainingsfolds lag jeder OOF-Verlust über ln 2: Drift eines Zeitraums passt nicht auf den nächsten), 1-SE-Regel mit GEPAARTEM
  Standardfehler über Zeitblöcke (mit der Streuung der Fold-Mittel wählte sie fast immer das stärkste λ). Min-CV ohne 1-SE geprüft:
  nicht besser, dafür mutiger im Rauschen.
- **Payload schlank:** Gespeichert werden nur `fusion` (p, Anteile), `kosten`, `p_up_v3`, `p_up_24_v1` (rund 0,6 kB je Prognose);
  Bilanz, Experten und v3-Zusammenfassung zusammen wären rund 4,2 kB je Prognosezeile gewesen.
- **Schreiben mit `BEGIN IMMEDIATE`** (`_schreiben`, Lehre aus 23.41).

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- Kosten-Theorietest mit 19,9 % Abweichung auf 24 h: Stichprobenrauschen (30 Tage = 30 unabhängige Tagesfenster) — jetzt
  400 Tage und Abweichung in Standardfehlern.
- „Rauschen → die Basisrate trägt die Mischung“ war eine falsche Erwartung: Fixed Share hält die Gewichte gemischt. Richtiges
  Kriterium: Verlust innerhalb der Grenze und nicht sicherer als die Basisrate.
- Ende-zu-Ende-Prüfung auf den Gesamtgewichten (57 %): Schlafende Experten halten Gewicht — maßgeblich sind die Anteile der
  Wachen (96 %).
- Probe-Daten mit `hash()` waren je Prozess zufällig (Texte werden je Prozess anders gehasht) — feste Formel.
- v3 war übervorsichtig (siehe λ-Wahl); Teilen-Probe bei 0,60/21 Tagen wackelte — nach 20 Szenarien (v3 ≈ 3 × v2) bei 0,62/30
  Tagen mit Kriterium „v3 > 0,15 und ≥ 2 × v2“; Probe „Kante nur in einem Coin“ mit „r gewählt in ≥ 4 von 5“.
- Training gegen Vorhersage auf 10⁻⁹ verlangt: gespeicherte Koeffizienten sind auf 5 Stellen gerundet → 10⁻⁴ (gemessen 5,4·10⁻⁶).
- 1 px Überlauf am Desktop durch den langen Debug-Titel in `#dbgselect` — Titel gekürzt.
- Bei der Schlussdurchsicht dazu: Abstand zur Basisrate ± Standardfehler in Kachel und Debug, Bilanz über alle Coins mit
  Zeitblöcken als Klumpen (der naive Standardfehler war in der Probe 1,75-mal zu klein), Zeilen „nur live gestellt“, ein
  Rauchtest des Debug-Berichts im Selbsttest, Termin U108 im Berichtsplan.

**4. Proben.**
- `python3 hl_fusion.py --nulltest` (27 Prüfungen, 26 s): Kosten 4 (E|r| = Theorie in SE, Schwelle, XMR, ohne Kurse), Fusion 10
  (Grenze auf 90 Folgen auch gegnerisch und mit Schläfern: 0 Verletzungen; Rauschen +2,61 Nats über 600 Blöcke bei Grenze 8,78;
  guter Experte 85 %; Regimewechsel 234 gegen 290 Nats; Schläfer; prequential; ohne Urteil; Basisrate; Abstand ± SE; alle Coins
  mit Klumpen), Ende zu Ende 5 (Nachtrag 60 Blöcke, v2-Anteil 96 %, zweite Prognose im Block, Toleranz, unabhängige Nachrechnung
  4,9·10⁻⁶, Debug-Bericht), v3 8 (U41; Tor 0,65 → +0,48, wahr +0,62; Rauschen 0,0 Punkte; vorsichtige Wahl 5/5; Training =
  Vorhersage; Gleichlauf ≤ 3,6 Punkte; Teilen +0,26 gegen v2 +0,08; Kante in einem Coin +0,37 gegen +0,08).
- Mutationen: 19 von 19 im Fusions-Selbsttest rot (Schläfer wie 50 %, ohne Fixed Share, Mischung/Nachtrag/Basisrate sehen die
  Zukunft, Toleranz als Richtung, Schwelle ohne Faktor 2, Spread einmal, falscher Horizont, v3 ohne Abweichung/ohne Teilen,
  mutiger Kalibrierschritt, λ ohne 1-SE, Skala vergessen in Training/Vorhersage, U41, Standardfehler ohne √n, Bilanz mit Blöcken
  ohne Urteil, alle Coins ohne Klumpen); 5 von 5 im Labor-Selbsttest (Kosten nur einer Seite, Puffer ignoriert, XMR-Faktor
  vergessen, Vorsprung halbiert, falsches Feld aus dem Payload).
- `hl_labor.py --selbsttest` grün (drei neue Prüfungen), `hl_forecast.py --nulltest`, `check_treiber.py` 77/77,
  `hl_viz.py --selbsttest-last`, `node --check` beider Skriptblöcke, Namensprüfung.
- Demo (5 Coins, 18 Tage Prognosen mit 58-%-Kante im Taker-Flow): `v3_takt` 0,4 s, `ergaenzen` rund 0,05 s je Coin, v3-Fit über
  90 Tage × 6 Coins 0,9 s; Kacheln am Handy (390 px) und Desktop ohne Überlauf und ohne JS-Fehler; Labor zeigt beide Strategien.
- Last: Kostenschwelle über 30 Tage Minutenkerzen auf einer Tabelle in Recorder-Form (PK ts, coin, WITHOUT ROWID; 12 Coins,
  40 Tage) 0,06 s je Coin, Zwischenspeicher 1 h.
- `install.py --selftest` aus dem Paket: 28 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- Erste Prognose je Coin nach dem Update: einmaliger Nachtrag aus 60 Tagen gespeicherter Prognosen (je Coin und Horizont einige
  Sekunden), danach eine live gestellte Zeile je Block. Die Kachel zeigt sofort eine Fusionszahl und eine Bilanz aus dem Nachtrag.
- v3 erstmals 5 min nach dem Start, dann stündlich; „zu wenige Fälle“ ist für junge Coins möglich (je Coin ≥ 15 Fälle). Bis
  dahin schläft v3 in der Mischung.
- Labor: zwei neue Strategien in der Gruppe Prognose. „Fusion mit Kostenschwelle“ handelt selten (4 h als Taker braucht rund 57 %).
- Berichte: W11 mittwochs 19:00, einmal 11.10. 19:30, Auswertung U108 25.10. 19:30.
- Speicher: Payload +0,6 kB je Prognose, `fusion_fall` rund 7 Zeilen je Coin und Tag.

**Was man wissen muss:** Die Daten sind knapp — rund 237 effektive 4-h-Blöcke je Coin (14 Tage Halbwertszeit), Standardfehler der
Trefferquote 3,3 Punkte; eine Kante von 55 % ist je Coin nicht belegbar, auf 24 h vergehen Monate. Ohne echte Kante ist die Fusion
im Log-Verlust etwas schlechter als die Basisrate (Rauschprobe 0,004 Nats je Block); die Bilanz sagt dann „nicht belegt“. Auf 4 h
braucht ein Taker-Handel rund 57 % Trefferquote. Umgeschaltet wird nur nach U108 (Kriterien in `KONZEPT_Fusion.md`, Abschnitt 6).

## 3μ. Kaskaden-Gleichung im Schatten — Stufe 2b (04.10., Version 2026-09-23.43, Opus 5.5)

Anlass, Nutzer nach dem Einspielen von 23.42: „… ob es nicht möglich wäre eine komplexe Funktionsgleichung abzuleiten, welche den
Kurs im voraus annähernd berechnet. Hättest du Ansätze dafür?“ Antwort in Kurzform:
- Eine Gleichung für den Kurs selbst hebt sich auf (Samuelson 1965, Grossman/Stiglitz 1980).
- Ein Trend ist auf kurzen Horizonten nicht belegbar (Merton 1980: der Beleg wächst mit μ · √T / σ; 30 % im Jahr brauchen rund 9 Jahre
  für 2 Standardfehler).
- Komplexe Modelle passen sich dem Rauschen an (Stock-to-Flow).
- Für die **Verteilung** des Kurses lässt sich eine Gleichung bauen und prüfen.
- Das Power Law, ehrlich gerechnet: auf 4 h 50,6 % P(aufwärts), auf ein Jahr 76 %. Santostasis Zyklusprognose traf außerhalb der
  Stichprobe den Boden, die Spitze um den Faktor 1,7 nicht.
- Vorschlag: Strukturgleichung d ln P = [5,8/t − κ (ln P − ln PL) + β · x] dt + σ(t) dW + J dN. Zuerst der Sprung-Teil J dN, aus den
  eigenen Heatmap-Daten.

Danach: „Leg los“. Konzept: **`KONZEPT_Fusion.md`, Abschnitt 4b** (neu). Plan: U113–U117, W12.

**1. Gebaut (`hl_kaskade.py`, neu; alles im Schatten — angezeigte Prognose, v1, v2, v3 und Fusion unverändert).**
- **Mathematik:**
  - Wirkung: I(Q) = Y · σ_Tag · √(Q / V_Tag), mit σ_Tag = σ_4h · √6 und V_Tag = 24 × Median-Stundenvolumen (`hl_anker.Markt`, dieselben
    Größen wie der Heatmap-Anker).
  - Kaskade als kleinster Fixpunkt u = u_exo + I(Q(u)) (`ende`: Präfixsummen und bisect).
  - Geschlossene Form H(m), in reinem Python (`h_werte`) und als numpy-Feld über Y und Schwellen (`h_feld`).
  - P(Ausschlag ≥ m binnen h) = erfc(H / (c · σ_h · √2)) (`p_ueber` mit math.erfc). Im Feld rechnet eine erfc nach Numerical Recipes
    (relativer Fehler 1,0 · 10⁻⁷), weil scipy auf dem Pi fehlt.
  - Cluster zählen nur auf der richtigen Seite (Long unter, Short über dem Kurs), bis zur Tiefe min(25 %, 6 σ_4h).
- **Live (`zustand`):**
  - Quelle ist der jüngste Heatmap-Stand, höchstens 30 min alt.
  - Zwischenspeicher je Datenbankdatei, Coin und Prognosespeicher. Er wird je Heatmap-Stand neu gefüllt, spätestens nach 15 min. Den
    Kurs setzt jeder Aufruf neu ein.
  - Berechnet werden:
    - der Kipppunkt (Raster 0,02 σ_4h bis 3 σ_4h; die Kaskade trägt ≥ 0,5 σ_4h weiter) und sein Ende,
    - das Ende nach 1 σ und nach 3 σ Ausschlag,
    - der Mehrweg ∫ (P_Kaskade − P_Zufall) dm in σ_4h,
    - die Asymmetrie (m_auf − m_ab) / (m_auf + m_ab + 0,1), mit Y = 1 und c = 1 fest.
- **Treiber „Kaskaden-Asymmetrie“:**
  - `hl_forecast.compute_forecast` ruft `hl_kaskade.treiber` nach dem Pool-Treiber auf. Gewicht 0; ein Fehler landet mit Grund in
    `missing`.
  - Steht in `SCHATTEN_TREIBER`, bewusst NICHT in `PRIORS`.
  - Neue Familie „Kaskaden“ in `hl_familien` (4 h, Richtung). Sie ist von v3 ausgenommen (`hl_fusion._v3_familien`, weiterhin 7
    Familien).
  - In der Treibertabelle steht statt der Trefferquote „Bilanz in der Familie Kaskaden“; der Tooltip nennt den Grund.
- **Payload und Anzeige:**
  - `hl_viz._forecast_compute_inner` ruft `hl_kaskade.ergaenzen` nach der Fusion auf, im try; ein Fehler hält die Prognose nie an.
  - Gespeichert wird `kaskade` = {v, ts, A, y_kipp, kipp_ab, ende_ab, mehr_ab, kipp_auf, ende_auf, mehr_auf}. Sobald ein 4-h-Modell
    gespeichert ist, kommen Y4, belegt4, p2_ab, p2_auf und p2_basis dazu. In der Demo sind das 171–204 Zeichen.
  - `kaskade_info` dient nur der Kachel; `store_forecast` lässt es aus.
- **Kalibrierung (`kalibrieren`, `takt`):**
  - Takt: alle 6 h im Familien-Takt des Dashboards, erstmals 15 min nach dem Start. Coins: alle aus `forecast_drivers` der letzten
    24 h. Je Coin und Horizont (1 h, 4 h).
  - Daten: je Block der erste Heatmap-Stand der ersten 15 min. Zwei gezielte Abfragen je Block, siehe Abschnitt 3.
  - Ereignisse je Seite: „Ausschlag ≥ k · σ_h“ für k = 0,5/1/1,5/2/3, aus Minutenhoch und -tief, bewertet mit dem Log-Verlust.
  - Wahl:
    - Gitter Y × c (7 × 21), 5 Folds geblockt mit Embargo 1 Block.
    - 1-SE-Regel zum kleineren Y (gepaarter Standardfehler, Tage als Klumpen).
    - Mindestens 120 Blöcke.
  - Dazu: Placebo, Seitenspiegel, Brier-Skill ≥ 1 σ und ≥ 2 σ (out-of-fold), Zuverlässigkeit, Richtungsprobe (|A| ≥ 0,3, 4 h) und
    die Abdeckung der Heatmap.
  - Gespeichert als learned coin/„kaskade“, gültig 3 Tage. Ein Fehler wird je Coin gespeichert und angezeigt.
- **Dashboard:**
  - Kachel „Kaskaden-Gleichung — Schatten“ in der AI-Prognose, nach der Fusionskachel.
  - Etikett „Schatten“ mit eigenem Tooltip in der Treibertabelle.
  - Farbe der Familie „Kaskaden“.
  - Drei Debug-Einträge: „★ Kaskaden-Gleichung (Schatten)“, „… jetzt kalibrieren“ und „… Selbsttest“.
  - Berichtsplan: Wochenprüfung (W12, mittwochs 19:00), dazu einmalig `u113-kaskade-woche1` am 11.10. 19:45 und
    `u115-kaskade-auswertung` am 25.10. 19:45.
- **Labor (U114):**
  - Neue Strategie „Kaskaden-Kipppunkt“ (`kaskade_kipppunkt@738d23ea`, Gruppe Ereignisse) mit Signal `sig_kipppunkt` und Tafeltext.
  - `_prog` liest Kipppunkte und Enden aus dem Payload.
  - Die 37 übrigen Kennungen sind unverändert.
- **Einbau:**
  - `install.py`: Selbsttest-Schritt „Kaskaden-Gleichung“, damit 29 Schritte.
  - `update.py`: `hl_kaskade.py` in PROJECT_FILES.
  - `check_treiber.py`: `test_kaskade` mit 6 Szenarien.
  - `version.py`: 23.43, `hl_kaskade.py` in PROJEKTDATEIEN.

**2. Entscheidungen beim Bau.**
- **Nicht in PRIORS:** v1 lernt nur über die Namen in PRIORS, v2 nimmt PRIORS ohne SCHATTEN_TREIBER. Außerhalb von PRIORS bleibt der
  Treiber aus beidem heraus, steht aber in `forecast_drivers` und damit in Familie, Ereignis-Profilen und Hygiene.
- **Festes Y = 1 für Treiber und Kipppunkt:**
  - Die Reihe bleibt über die Zeit vergleichbar; sonst spränge sie mit jeder Kalibrierung.
  - Das kalibrierte Y wirkt auf die Wahrscheinlichkeiten. Auf Kipppunkt und Ende im Payload wirkt es erst, wenn es für 4 h belegt ist
    (`y_kipp` zeigt, welches Y galt).
  - Die Regel der Labor-Strategie bleibt dabei gleich; nur ihre Eingabe wird genauer.
- **Vier Bedingungen für „belegt“.** Das Zeit-Placebo allein reichte nicht:
  - Im Störfaktor-Markt (nahe Cluster gehen mit höherer Schwankung einher, ohne Mechanik) ließ es 1 von 4 Läufen durch.
  - Der Seitenspiegel (dieselben Cluster mit vertauschten Seiten) trennt Mechanik von bloßem Mitlaufen der Schwankung.
- **Y ist ein effektiver Wert:** Die Heatmap sieht nur die verfolgten Konten, und σ_Tag enthält die Kaskaden selbst. In der Probe wird
  ein wahres Y = 2 als 1 gefunden, und c sinkt auf 0,7.
- **Vergleichsgröße „ohne Heatmap“:** derselbe Zufallsweg, mit c₀ aus allen Blöcken. Zuerst hieß sie „ohne Kaskaden“, das war
  irreführend.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Seitenspiegel als vierte Bedingung:** Im Störfaktor-Markt (Seed 3) gab es mit dem Zeit-Placebo allein einen Fehlbefund.
- **Speicher der Kalibrierung (Lastprobe im ungünstigen Fall):**
  - Der Entwurf las jeden Block ganz (`ts % Block < 900`, alle Eimer).
  - Geprüft mit 800 Eimern je Stand, wie sie ein Coin mit vielen verfolgten Positionen im 0,25-%-Raster tragen kann.
  - 30 Tage kosteten 5,5 s und 354 MB Prozessspeicher; 90 Tage wären rund 1 GB im Dashboard-Prozess geworden.
  - Die Lastprobe vorher hatte nur 100 Eimer je Stand und das nicht gezeigt.
  - Jetzt laufen je Block zwei Abfragen über Index und Schlüssel: der erste Stand per `MIN(ts)` über `ix_heat_coin_ts`, dann nur die
    Eimer bis zur größten Clustertiefe über den Primärschlüssel.
  - Ergebnis: 30 Tage 0,4 s und 53 MB, 90 Tage 1,5 s und 91 MB.
  - Die Ausgabe ist Block für Block identisch: Lastdatei, Demo (5 Coins), Probe-Markt und eine neue Selbsttest-Prüfung mit 115.240
    zusätzlichen tiefen und falschseitigen Eimern.
- **Live-Probe:** Das Cluster mit 3 % des Tagesumsatzes trug keine 0,5 σ weiter, es gab also zu Recht keinen Kipppunkt. Die Probe
  nimmt jetzt 8 % und prüft den Kipppunkt im Raster.
- **Kachel:**
  - Sie zeigte „Kalibrierung ausstehend“, obwohl 1 h schon kalibriert war. Jetzt nennt sie den Grund je Horizont.
  - Die P-Zeile nimmt das 1-h-Modell, solange 4 h fehlt.
- **Treibertabelle:** Die Trefferzelle zeigte „nie |Score| > 0,05“, das war falsch, der Score lag bei 0,45. Grund: Der Treiber steht
  nicht in PRIORS und bekommt daher keine v1-Bilanz. Jetzt steht dort „Bilanz in der Familie Kaskaden“.
- **Selbsttest:** Unter einer Mutation brach die Textausgabe der Mathe-Probe ab (None). Jetzt meldet sie ein sauberes FEHL.
- **Docstrings:** Die Bedingungen für „belegt“ (mit Seitenspiegel) und die Payload-Größe sind nachgezogen.

**4. Proben.**
- `python3 hl_kaskade.py --nulltest`: 15 Prüfungen, 14 s.
  - Mathe 5:
    - geschlossene Form = Fixpunkt in 120.000 Vergleichen auf 300 Karten mit Y 0–8, 0 Abweichungen,
    - Feld = Schritt,
    - erfc 1,0 · 10⁻⁷,
    - ohne Kaskaden der Zufallsweg,
    - Kipppunkt und Kette exakt.
  - Positivkontrolle 1 h (Y wahr 2): Y 1 in 3 von 3, Abstand +0,36 … +0,42 je Block bei ≥ 10 SE, belegt 3 von 3.
  - Positivkontrolle 4 h: belegt 3 von 4.
  - Nulltest: Y = 0 in 4 von 4.
  - Störfaktor: nie belegt; der Spiegel verhindert einen Fehlbefund.
  - Blöcke: gezielt = alles gelesen.
  - Live 5: Kipppunkt, Spiegel, veralteter Stand, Payload, gespeicherte Kalibrierung mit Debug-Bericht.
- Mutationen: 20 von 20 rot.
  - 15 in `hl_kaskade`: Wurzel, Fluss davor, eigenes Cluster im Feld, Reflexion ohne Faktor 2, Ende ohne Kette, 1-SE zum größeren Y,
    ohne Spiegel, Placebo mit eigener Karte, falsche Seite, Kipppunkt ohne Mindest-Reichweite, Training sieht Testblöcke, veralteter
    Stand, Vorzeichen der Asymmetrie, Eimer-Fenster zu schmal, letzter statt erster Stand.
  - 4 im Labor: mehrfach, ohne Kostenfilter, Richtung vertauscht, nach dem Ende.
  - 1 in der Prognose: Treiber nicht im Schatten.
- Weitere Selbsttests, alle grün:
  - `check_treiber.py`: 83 von 83.
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`.
  - `node --check` beider Skriptblöcke.
  - Berichtsplan: alle Läufe vorhanden, Termine richtig.
- Demo (Cluster ohne Mechanik, 5 Coins, 12–18 Tage Heatmap):
  - 1 h: Y = 0 in 5 von 5, nicht belegt. Ein realistischer Nulltest.
  - 4 h: zu wenige Blöcke (71–110 von 120).
  - Richtungsprobe: |z| ≤ 1,5.
  - Kachel, Etikett, Trefferzelle, Familie und Labor-Strategie im Browser am Handy (390 px) und am Desktop ohne Überlauf und ohne
    JS-Fehler.
- Last: Live-Stand 0,02 s; Kalibrierung siehe Abschnitt 3.
- `install.py --selftest` aus dem Paket: 29 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Erste Prognose nach dem Update:** Der Treiber „Kaskaden-Asymmetrie“ steht in der Tabelle mit Etikett „Schatten“; die Kachel zeigt
  die Kipppunkte. Ohne Heatmap-Stand der letzten 30 min steht dort „—“ mit Grund.
- **Kalibrierung:** 15 min nach dem Start, dann alle 6 h.
  - 1 h hat sofort genug Blöcke (rund drei Wochen Heatmap).
  - 4 h braucht 120 Blöcke, also rund 20 Tage Aufzeichnung; das Placebo drei Tage mehr.
  - Bis Y belegt ist, rechnen Kipppunkt und Treiber mit Y = 1. „Nicht belegt“ ist ein gültiges Ergebnis.
- **Rechenlast:** rund 2–5 s je Coin alle 6 h (Sandbox 1,5 s bei 90 Tagen und 800 Eimern, der Pi ist langsamer).
- **Speicher:** Payload +0,2 kB je Prognose, eine learned-Zeile je Coin.
- **Labor:** „Kaskaden-Kipppunkt“ handelt selten, nur beim Durchbruch durch einen Kipppunkt und mit Weg ≥ 1,5 × Kosten.
- **Berichte:** W12 mittwochs 19:00, einmalig am 11.10. 19:45 (erste Woche) und am 25.10. 19:45 (Auswertung U115).

**Was man wissen muss:** Die Gleichung ist eine Hypothese mit Messung, kein Signal. Wahrscheinlich ist Y bei BTC und ETH klein oder
nicht belegt, bei ZEC, XMR und HYPE eher sichtbar. Ob die Asymmetrie die Richtung vorhersagt, ist offen: Eine Rutschgefahr nach unten
kann im Mittel durch mehr kleine Anstiege ausgeglichen sein. Eingeschaltet wird nur mit Beleg, als Sprung-Teil der Verteilungsprognose
(U116). Kriterien: U115.

## 3ν. Erste echte Kalibrierung der Kaskaden-Gleichung: gemischte Schwankung, Spiegel beim gleichen Y (04.10., Version 2026-09-23.44, Opus 5.5)

Anlass: Der Nutzer hat 23.43 eingespielt und drei Debug-Ausgaben geschickt.
- Rundum-Funktionstest: in jeder Quelle FEHL 0.
- Kaskaden-Selbsttest auf dem Pi: grün in 25 s.
- „jetzt kalibrieren“: 6 Coins in 8,5 s, 26,7 Tage Heatmap, Abdeckung 25–29 % des OI.
Die Zahlen stehen in `KONZEPT_Fusion.md`, Abschnitt 4b.1a. U110 (Berührwahrscheinlichkeit) war für heute geplant. Es kommt danach,
weil es auf dem hier korrigierten Nullmodell aufsetzt.

**1. Befunde (eigene Fehler aus 23.43).**
- **Wahrscheinlichkeiten großer Ausschläge zu niedrig, in allen Coins und beiden Horizonten.** Ausschläge ≥ 2 σ, vorhergesagt gegen
  eingetreten: BTC 1 h 2,9 → 5,8 % (n 1.268), ETH 1,9 → 4,1 %, XMR 1,7 → 5,3 %, ZEC 3,2 → 5,2 %; 4 h BTC 3,3 → 4,8 %,
  HYPE 4,1 → 6,6 %.
  - Ausschläge ≥ 1 σ waren dagegen seltener: 19–28 % statt 31,7 %.
  - Ursache: σ_h kommt aus 7 Tagen und trifft die einzelne Stunde schlecht. Ruhige und heiße Stunden ergeben zusammen eine dünne
    Mitte und dicke Ränder. Das Reflexionsprinzip mit fester Schwankung kennt das nicht.
  - Die synthetischen Märkte von 23.43 hatten keine Schwankung mit Gedächtnis und konnten das nicht zeigen. Ein Testmarkt mit ihr
    (log-σ als AR(1) je Stunde, τ 0,6) erzeugt genau das Muster vom Pi: 3,0 → 4,7 · 3,4 → 6,1 · 4,0 → 7,9 %.
- **Richtungsprobe mit n = 1:** PAXG „1 Block, 100 % ± 10 %, z +5,0“. Der Standardfehler hatte einen Boden von 0,1, und eine
  Mindestzahl fehlte.
- **Selbsttest nicht isoliert:** Die Live-Probe las den echten Prognosespeicher (auf dem Pi 268 statt 183 Zeichen Payload, Bilanz und
  Richtung des echten BTC-Modells). Geschrieben hat sie dort nichts; das Kalibrier-Speichern der Probe nutzte schon einen eigenen Pfad.

**2. Gebaut.**
- **Gemischte Schwankung (Modell v2):**
  - P(Ausschlag ≥ m) = Σ_k w_k(τ) · erfc(H(m) / (c · e^{0,05·k} · σ_h · √2)), log-normal um c mit Streuung τ; τ = 0 ist das
    Reflexionsprinzip.
  - c (log-Raster 0,41–1,57) und τ ∈ {0; 0,3; 0,6; 0,9} werden je Y in den Folds gewählt (112 Paare).
  - erfc wird einmal je Raster-Exponent gerechnet, dann je Paar als gewichtete Summe (Matrix W @ E), in Stücken zu 100 Blöcken.
  - Live (`p_ueber`) rechnet dieselbe Mischung einzeln. Kachel, Payload (`p2_*`) und Bericht nutzen (c, τ), die Basis „ohne
    Heatmap“ (c₀, τ₀).
  - `VERSION = 2`: Gespeicherte v1-Kalibrierungen gelten nicht mehr (`modell_laden`). Nach dem Update steht bis zum ersten Takt
    „Kalibrierung ausstehend“.
- **Unverändert gelassen:** Treiber „Kaskaden-Asymmetrie“ (Mehrweg mit Y = 1, c = 1, τ = 0) und Kipppunkt/Ende (deterministisch,
  Y_REF). Beide werden vorwärts gemessen (Familie „Kaskaden“, Labor „Kaskaden-Kipppunkt“). Der Selbsttest nagelt sie auf den Wert von
  23.43 fest: Treiber −0,8001767487069966, Kipppunkt 0,5045 %, Ende 1,1286 %, Mehrweg 0,40105.
- **Seitenspiegel beim gleichen Y:** Verlust Spiegel minus echt beim gewählten Y, je mit c und τ seines Folds (vorher: der Spiegel mit
  seinem eigenen Y). Bericht: „Seitenspiegel (eigenes Y …, verglichen bei Y …)“.
- **Bericht** (Debug „★ Kaskaden-Gleichung“):
  - out-of-fold „vorhergesagt, eingetreten, Abstand ± SE ✓/✗“ für ≥ 2 σ und ≥ 1 σ (Kriterium 2 von U115, `kal_2`, `kal_1`, Tage als
    Klumpen);
  - Zuverlässigkeit für ≥ 2 σ und ≥ 1 σ, nur Klassen ab 20 Fällen;
  - τ und c₀/τ₀ in den Modell- und Kalibrierzeilen;
  - eine Zeile „Richtung über alle Coins“ mit dem Hinweis auf den Mehrfachtest.
- **Richtungsprobe:** erst ab 20 Blöcken (`RICHTUNG_MIN`), z mit dem Standardfehler der Nullhypothese √(0,25/n), dazu die Treffer für
  das Poolen.
- **Selbsttest:**
  - Mathe-Prüfungen zur Mischung (Tabelle = Einzelrechnung = Integral, Ränder dicker mit τ), zur Richtungsprobe und zur
    Kreuzvalidierung (kein Blick in die Testblöcke, Embargo).
  - Testmarkt mit Schwankung mit Gedächtnis (`_probe_markt(sv_tau, sv_rho)`): ohne Kaskaden Y = 0, τ erkannt, ≥ 2 σ richtig; mit
    Kaskaden belegt.
  - Live-Probe mit eigenem Prognosespeicher (`F.STORE` umgelenkt; `learned_save` mit ausdrücklichem Pfad, weil Python Standardwerte
    beim Definieren bindet), Durchleitung einer gespeicherten 4-h-belegten Kalibrierung (v1 wirkt nicht, v2 schon).
  - `kalibrieren(horizonte=…)`, damit der Selbsttest nur den geprüften Horizont rechnet.
- **Kachel:** Die Erklärung nennt die Mischung. Sonst ist nichts geändert; Feldnamen und Payload-Felder sind gleich.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Spiegel:** Mit der Mischung wurde im Störfaktor-Markt Seed 3 belegt, ein Fehlbefund. Der Spiegel wählte Y = 0, und „Spiegel minus
  echt“ war damit dieselbe Zahl wie „Y = 0 minus gewählt“ (2,2 SE). Jetzt wird beim gleichen Y verglichen: Seed 3 liegt bei 1,4 SE,
  nicht belegt. Die Positivkontrollen sind gleich geblieben (1 h 3 von 3, 4 h 3 von 4).
- **Laufzeit:** Der Selbsttest brauchte mit allen Horizonten 48 s. Jetzt rechnet jeder Probe-Lauf nur seinen Horizont, das sind rund
  40 s.
- **Mathe-Probe:** Unter der Mutation „nur τ = 0“ brach sie mit IndexError ab. Jetzt passt sie sich dem τ-Raster an; die Mutation fängt
  der Testmarkt mit Schwankung mit Gedächtnis.
- **Kreuzvalidierung:** Die Mutation „Training sieht die Testblöcke“ blieb mit dem neuen Modell unentdeckt (24 von 25). In 23.43 fing sie
  nur nebenbei der Störfaktor-Markt; mit zwei freien Parametern je Y wirkt das Leck kaum auf die Ergebnisse. Jetzt gibt es eine eigene
  Prüfung im Mathe-Teil: Testblöcke und Nachbarblock (Embargo) bevorzugen dort einen anderen Parameter, und `_waehlen` darf ihn nicht
  nehmen. Neu dazu die Mutation „ohne Embargo“.

**4. Proben.**
- `python3 hl_kaskade.py --nulltest`: 21 Prüfungen, rund 40 s.
  - Mathe 8.
  - Kalibrierung 7:
    - Positivkontrolle 1 h: belegt 3 von 3 (Abstand +0,32 … +0,37 bei ≥ 10 SE).
    - Positivkontrolle 4 h: belegt 3 von 4.
    - Nulltest: Y = 0 in 4 von 4.
    - Störfaktor: nie belegt; der Spiegel verhindert 3 Fehlbefunde.
    - Schwankung mit Gedächtnis ohne Kaskaden: Y = 0 und τ 0,6 in 3 von 3; ≥ 2 σ 5,8 → 4,7 · 5,6 → 6,1 · 7,3 → 6,7 %, im Mittel
      −0,4 ± 0,75 Punkte.
    - Schwankung mit Gedächtnis mit Kaskaden: belegt 2 von 2.
    - Blöcke gezielt = ganz gelesen.
  - Live 6.
- Gegen einen Köder-Speicher geprüft (HL_FORECAST_DB mit belegter BTC-Kalibrierung, Y 8): Die Probe übersieht ihn (Payload 183 Zeichen),
  und seine Zeile ist danach unverändert.
- Mutationen: 26 von 26 rot. Das sind die 20 aus 23.43, die Reflexion jetzt in der Tabelle, und neu:
  - nur τ = 0;
  - Mischungsgewichte ohne Normierung;
  - Spiegel mit eigenem Y;
  - Live-Probe liest den echten Speicher (mit Köder-Speicher je Lauf);
  - Richtungsprobe ohne Mindestzahl;
  - Kreuzvalidierung ohne Embargo.
- Weitere Selbsttests grün:
  - `check_treiber.py`: 83 von 83 (Treiber unverändert).
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`.
  - `node --check` beider Skriptblöcke und die Namensprüfung.
- Demo (Gauß-Zufallsweg, 5 Coins):
  - τ = 0 in 5 von 5, Y = 0;
  - ≥ 2 σ vorhergesagt ≈ eingetreten in 5 von 5 (✓);
  - Richtung über alle Coins: 101 Blöcke, z +1,3.
- Last im ungünstigen Fall (800 Eimer je Stand, 90 Tage, 10,4 Mio Zeilen, ein Coin): Kalibrierung 5,7 s, höchstens 150 MB
  Prozessspeicher (23.43: 1,5 s, 91 MB; 30 Tage jetzt 2,1 s, 98 MB). Der Mehraufwand kommt von 112 statt 21 Parametern je Y. Die
  Tabelle läuft in Stücken zu 100 Blöcken; mit 250 waren es 204 MB. Live-Stand 0,03 s. Auf dem Pi grob das Zwei- bis Dreifache, alle
  6 h im Familien-Takt.
- `install.py --selftest` aus dem Paket: 29 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Nach dem Update:** „Kalibrierung ausstehend“ bis zum ersten Takt 15 min nach dem Start (v1 gilt nicht mehr). Sofort geht es mit
  Debug „Kaskaden-Gleichung: jetzt kalibrieren“.
- **Danach:**
  - τ je Coin wahrscheinlich 0,3–0,9 (nachgerechnet aus den Quoten: 0,4–0,7);
  - P(Rutsch ≥ 2 σ) rund 5 % statt 3 %;
  - „vorhergesagt gegen eingetreten“ mit ✓.
- **Y:** Ohne den Gewinn aus dickeren Rändern ist ein Y > 0 seltener. BTC 1 h bleibt der Kandidat. Belegt wird nur mit dem Spiegel beim
  gleichen Y.
- **Unverändert:** Treiber, Familie „Kaskaden“, Kipppunkte und die Labor-Strategie, solange kein Y für 4 h belegt ist.
- **Selbsttest auf dem Pi:** etwa 1 bis 1,5 min (vorher 25 s).

**Was man wissen muss:**
- Die synthetischen Proben müssen die bekannten Eigenschaften echter Kurse enthalten (Schwankung mit Gedächtnis, dicke Ränder), nicht nur
  die geprüfte Mechanik. Sonst bestehen Modelle Proben, die der echte Markt sofort widerlegt.
- Eine Schutzbedingung kann still in eine andere zusammenfallen. Der Spiegel mit eigenem Y wurde zur Bedingung 2. Vergleiche gehören
  auf gleiche Komplexität.
- Selbsttests dürfen den echten Speicher weder lesen noch schreiben. Beim Umlenken von `F.STORE` den Pfad ausdrücklich übergeben.

## 3ξ. Magnet-Test (U110): berührt der Kurs Cluster öfter als der Zufall? (04.10., Version 2026-09-23.45, Opus 5.5)

Anlass: Der Nutzer hat 23.44 eingespielt und die zweite Kalibrierung geschickt (20:55, 6 Coins in 19,5 s). Zugesagt war danach U110.
Zugesagt war auch: Bis zum 25.10. ändert sich nichts an Fusion, v3 und Kaskaden-Rechnung. Daran hält sich 23.45; neu ist nur
Messung.

**1. Die zweite Kalibrierung bestätigt 23.44** (Zahlen in `KONZEPT_Fusion.md` 4b.1b).
- „vorhergesagt gegen eingetreten“ (out-of-fold) liegt in allen 11 Coin-Horizonten für ≥ 2 σ und ≥ 1 σ innerhalb 2 SE: 22 von
  22 ✓. Beispiel BTC 1 h ≥ 2 σ: 5,3 → 5,7 % (+0,4 ± 0,9 Punkte); mit 23.43 waren es 2,9 → 5,8 %.
- τ 0,3–0,9 (nachgerechnet erwartet 0,4–0,7), c 0,67–0,90.
- Y = 0 außer ETH 1 h (0,25; 1,1 SE) und HYPE 4 h (0,5; Abstand +0,032 ± 0,013, also 2,5 SE; Placebo Y 0). HYPE 4 h scheitert allein
  am Spiegel: Beim gleichen Y ist er so gut wie die echten Seiten (−0,0024 ± 0,0146). Für diesen Fall ist er gebaut: Cluster nah
  auf beiden Seiten, keine Seitenmechanik.
- Richtung über alle Coins: 219 Blöcke, 46 % ± 3 % (z −1,1); ETH 34 % (z −2,1). Bei 4 Coins mit eigener Probe liegt einer mit 17 %
  Chance zufällig so weit.
- Auffällig, ohne Handlung vor dem 25.10.:
  - XMR: In einer Zuverlässigkeitsklasse kamen ≥ 2 σ seltener als vorhergesagt (5,5 → 1,2 %, n 254; ≥ 1 σ 21,8 → 15,9 %, n 760).
    Die 7-Tage-Schwankung hing in einer Phase zu hoch. Das ist eine Aufgabe für U109 (HAR).
  - PAXG: τ 0,9 am Rand des Rasters, Tagesumsatz unter 1 Mio, Placebo Y 8 bei flacher Verlustkurve. PAXG bleibt ein Sonderfall.
  - Abdeckung der Heatmap 22–24 % (XMR 18 %, PAXG 16 %) statt 25–29 % bei der ersten Kalibrierung. Die Ursache ist offen; am 05.10.
    zeigt sich, ob die Abdeckung nach dem Neustart wieder steigt.

**2. Gebaut: Magnet-Test** (`hl_magnet.py`, `KONZEPT_Fusion.md` Abschnitt 4 „U110“). Er ist nur eine Messung: ohne Wirkung auf
Prognose, Treiber, v1, v2, v3, Fusion und Labor.
- **Frage:** Berührt der Kurs Liquidationscluster öfter, als die am 04.10. bestätigte Rechnung ohne Cluster erwarten lässt?
- **Nullmodell:** das Modell „ohne Heatmap“ der Kaskaden-Gleichung (Y = 0) mit gemischter Schwankung. c und τ werden je Block
  out-of-fold gewählt (`nullmodell`: dieselben 5 Folds mit Embargo wie `K._waehlen`).
- **Fälle:** je Block, Seite und Größenklasse das nächste Cluster bis 3 σ_h (`naechste`). Klassen nach Notional / Tagesumsatz:
  klein < 0,5 %, mittel 0,5–2 %, groß ab 2 %.
- **Überschuss** = berührt − P_null, beide Seiten gleich gewichtet (`_balanciert`). Standardfehler mit Tagen als Klumpen, nie unter
  dem binomialen.
- **Kontrollen:** Spiegel (gleiches Niveau, andere Seite), Placebo (Tiefen und Größen der Karte von 3 Tagen vorher, `K._placebo`),
  Zufallsniveaus 0,25–3 σ_h.
- **Belegt** (`bedingungen`, `belegt_regel`): mindestens 60 wirksame Fälle (`n_wirksam` = 4 · unten · oben / (unten + oben)),
  Überschuss, echt − Spiegel und echt − Placebo je > 2 SE. Der Bericht nennt die fehlende Bedingung, z. B. „nicht belegt (nur eine
  Seite, Placebo ≤ 2 SE)“.
- **Testmarkt** (`hl_kaskade._probe_markt`, nur Selbsttest) mit neuen Parametern: `magnet` (Anziehung zu großen Clustern), `drift`
  (Trend), `kopplung_anteil` (Störfaktor nur durch große Cluster) und `niveau` (feste Niveaus mit großen Clustern). Ohne Wert
  ändert keiner etwas, auch nicht die Folge der Zufallszahlen; der Kaskaden-Selbsttest liefert Zahl für Zahl dasselbe wie 23.44.
- **Einbau:**
  - Familien-Takt des Dashboards alle 6 h, erstmals 20 min nach dem Start, nach der Kaskaden-Gleichung.
  - Ergebnis in learned coin/„magnet“, gilt 3 Tage, Modellversion 1.
  - Debug: „★ Magnet-Test (U110)“, „Magnet-Test: jetzt rechnen“, „Magnet-Test: Selbsttest“.
  - Berichte: Wochenprüfung (W13), einmalig `u110-magnet-woche1` am 11.10. 20:00 und `u110-magnet-auswertung` am 25.10. 20:00.
  - `install.py`: Schritt 30. `update.py` und `version.py` kennen die neue Datei.

**3. Was die Proben am Entwurf geändert haben (vor der Lieferung).**
- **Trendfalle (eigener Fehler im Entwurf):** Der Entwurf nannte das seitengleiche Mittel „trendfest“. Das stimmt nur mit Fällen auf
  beiden Seiten. Mit einer Seite fiel es auf gleiche Gewichte zurück.
  - Testmarkt: Abwärtstrend, nur Long-Cluster. Überschuss und Spiegel lagen in allen Klassen über 2 SE (+5 … +11 Punkte); nur das
    Placebo hielt.
  - Jetzt zählen wirksame Fälle; eine Seite allein ergibt 0 und damit kein Urteil.
  - Derselbe Trend mit Clustern auf beiden Seiten: Der Ausgleich hebt ihn auf (−0,9 Punkte im Mittel, einseitig +8,8).
- **Störfaktor:** Die erste Fassung koppelte wie im Kaskaden-Test alle nahen Cluster an die Schwankung. Der Überschuss kam damit nur
  einmal über 2 SE, der Spiegel wurde kaum geprüft. Jetzt koppeln nur große Cluster: Überschuss und Placebo schlagen in 4 Läufen
  an, nur der Spiegel hält.
- **Niveau-Welt:** Sie war als Falle für das Placebo gedacht, ist aber keine. Das Placebo überträgt Tiefen und Größen der alten Karte
  auf den Kurs von jetzt; feste Niveaus kennt es nicht. Ein Placebo mit den alten PREISEN würde echte Cluster mitnehmen, weil
  Positionen oft tagelang offen bleiben. Ergebnis ist eine Grenze des Tests, offen benannt in Bericht, Konzept und Selbsttest:
  Belegt heißt „die Karte sagt Berührungen vorher“, nicht „das Cluster zieht“.
- **Prüfbar gemacht:**
  - die Belegt-Regel als eigene Funktion;
  - „out-of-fold“: Bekommt Fold 1 doppelt so weite Ausschläge, bleibt sein eigener Parameter;
  - „isoliert“: Die Live-Probe prüft, dass sie im eigenen Speicher arbeitet.
  Ohne diese Prüfungen blieben die Mutationen „Nullmodell in der Stichprobe“ und „echter Speicher“ grün.
- **Standardfehler:** Mit 12 Seeds lag die Streuung der Spiegel-Differenz (klein) beim 1,38-Fachen des berechneten Standardfehlers.
  40 Seeds zeigen 0,82–1,08 über alle Klassen und Kontrollen (erwartet 1 ± 0,11). Der Fehler ist richtig geschätzt; die 1,38 war
  Zufall der kleinen Probe.

**4. Proben.**
- `python3 hl_magnet.py --nulltest`: 13 Prüfungen, rund 21 s (Pi geschätzt rund 40 s).
  - Mathe 5: nächstes Cluster je Klasse bis 3 σ; Nullmodell = Kaskaden-P (5 · 10⁻⁹); out-of-fold; Seitenausgleich, binomialer
    Boden und wirksame Fälle; belegt nur mit allen vier Bedingungen.
  - Markt 7:
    - Positivkontrolle: groß belegt 3 von 3, Überschuss +4,7 … +4,9 ± 1,4–1,5 Punkte, echt − Spiegel +9,3 … +10,2; klein nie.
    - Nulltest: nie belegt.
    - Störfaktor: nie belegt; 4 Klassen, die nur der Spiegel hält.
    - Trendfalle: nie belegt; 9 von 9 Klassen scharf, gehalten von „nur eine Seite“ (9) und Placebo (9).
    - Trend auf beiden Seiten: −0,9 Punkte.
    - Grenze (Niveau-Welt): belegt 3 von 3.
    - Schwankung mit Gedächtnis: nie belegt; Zufallsniveaus 23 von 24 innerhalb 2 SE; τ 0,6 erkannt.
  - Live 1: eigener Speicher, Takt, fremde Version gilt nicht, Bericht.
- Mutationen hl_magnet: 16 von 16 rot. Die Kontrolle ohne Mutation ist sauber, der Köder-Speicher unberührt. Rot werden:
  - Nullmodell in der Stichprobe;
  - weitestes statt nächstes Cluster; ohne 3-σ-Grenze;
  - ohne Seitenausgleich; Seitengewichte vertauscht; ohne binomialen Boden; wirksame = alle Fälle;
  - belegt schon bei genau 2 SE; belegt ohne Mindestzahl, ohne Spiegel oder ohne Placebo;
  - Placebo mit der eigenen Karte; Berührung auf der anderen Seite gezählt; Spiegel auf derselben Seite;
  - Versionsprüfung entfernt; Live-Probe im echten Speicher (Köder verändert, Prüfung rot).
- Nullwelt mit 40 weiteren Seeds (Erkundung): nie belegt in 120 Klassen-Läufen; Streuung/SE 0,82–1,08; z > 2 in 0–2 von 40.
  - Der Überschuss liegt im Mittel 0,3–0,5 Punkte unter null. Das Nullmodell überschätzt im Testmarkt kleine Abstände (0,25 σ:
    79,7 → 77,3 %), weil der Testmarkt in Teilschritten rechnet.
  - Das wirkt gegen „belegt“. Das Placebo hat dieselben Tiefen und nimmt solche Fehler mit.
- Kaskaden-Gleichung: Selbsttest unverändert (21 Prüfungen, dieselben Zahlen wie 23.44). Mutationen 26 von 26 rot.
- Last im ungünstigen Fall (800 Eimer je Stand, 90 Tage, 10,4 Mio Zeilen, ein Coin): Magnet-Test 2,0 s, höchstens 77 MB
  Prozessspeicher. Bei 30 Tagen 0,7 s und 52 MB. Zum Vergleich die Kaskaden-Kalibrierung: 5,7 s und 150 MB.
- Weitere Selbsttests grün:
  - `check_treiber.py`: 83 von 83 (Treiber unverändert);
  - `hl_labor.py --selbsttest`, `hl_forecast.py --nulltest`, `hl_fusion.py --nulltest`, `hl_familien.py --nulltest`,
    `hl_viz.py --selbsttest-last`;
  - Berichtsplan: 14 Einträge, alle Läufe bekannt;
  - `node --check` beider Skriptblöcke und die Namensprüfung.
- Demo (5 Coins, 12 Tage, älterer Demo-Erzeuger): Rechnung und Bericht laufen, nichts belegt.
- `install.py --selftest` aus dem Paket: 30 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- **Erste Rechnung** 20 min nach dem Start, sofort mit Debug „Magnet-Test: jetzt rechnen“; danach alle 6 h.
- **Reichweite:** Viele Cluster liegen weiter als 3 σ_h. Bei BTC (σ_4h 0,70 %) zählen für 1 h Cluster bis rund 1,05 %, für 4 h bis
  2,1 %.
  - Für 1 h kommen die Fälle also vor allem aus kleinen und mittleren Clustern nah am Kurs.
  - Bei ZEC lagen am 04.10. große Cluster nur unten (oben höchstens 0,23 % des Tagesumsatzes). Dort ist „nur eine Seite“ ein
    erwartbares Urteil.
- **Erwartung:** Überschuss nahe 0. Ein Beleg ist am ehesten in „groß“ bei 4 h möglich. „Nicht belegt“ ist ein Ergebnis.
- **Zufallsniveaus:** Die Zeile zeigt, ob das Nullmodell bei jedem Abstand trifft. Eine Abweichung bei kleinen Abständen kennt der
  Testmarkt (siehe oben); auf dem Pi zählt die Größe der Abweichung.

**Was man wissen muss:**
- Ein Mittel, das „trendfest“ heißt, ist es nur unter seiner Bedingung. Eigenschaften gehören mit ihrer Bedingung geprüft, nicht nur
  benannt.
- Jede Schutzbedingung braucht einen Testmarkt, in dem nur sie hält. Sonst zeigt der Selbsttest nicht, dass es sie braucht.
- Eine Falle, die keine Kontrolle fängt, ist entweder eine Lücke oder eine Grenze. Hier ist es eine Grenze (Vorhersage, nicht
  Ursache), offen benannt.

## 3ο. z explodierte bei wenigen Fällen (Nutzerfund 04.10., 21:46): exaktes z für Trefferquoten (04.10., Version 2026-09-23.46, Opus 5.5)

Anlass: Vor dem Einspielen von 23.45 sah der Nutzer im Abschnitt Treiberfamilien (BTC) bei „Kaskaden“ z = +12101198177798966,0 bei
n = 3 (Bild vom Dashboard und vom Handy). 23.46 enthält 23.45 (U110) und diese Korrektur.

**1. Ursache (eigener Fehler, seit 23.25).**
- `hl_familien._stat` rechnete z = Mittel / (Stichproben-Streuung / √n) über „Treffer − Erwartung“ je Fall.
- Drei Treffer bei einer Basisrate von 52,5 % ergeben dreimal denselben Wert 0,475. Die Streuung ist dann 0, im Fließkomma aber
  6,8 · 10⁻¹⁷; die Abfrage `sd > 0` ließ das durch.
- Nachgerechnet: z = 1,2101198177798966 · 10¹⁶, genau der Wert vom Bildschirm.
- Wie oft das unter dem Zufall vorkommt: 3 Treffer in 3 Fällen bei 52,5 % Basis in 14,5 % der Fälle, jedes Mal mit z ≈ 10¹⁶. Auch
  ohne Explosion war das z bei wenigen Fällen zu großzügig: 5 von 6 bei 50 % ergab +2,0, an der Grenze zu „gut“; exakt sind es
  +1,53. Profi-Flow (BTC, n 6, z +2,0) stand genau dort.
- Folge: Die Wochenurteile der Familien („gut“ bei z ≥ 2 über 14 Tage) hätten Familien auf wenigen gleichen Treffern befördert, am
  Wochenwechsel Donnerstag 02:00 auf „Bewährung“, nach zwei Wochen auf „aufgestiegen“ mit Gewicht in der Familien-Prognose
  (Parallelbetrieb, nicht in der Hauptprognose). Auf dem Bild sind alle BTC-Familien Kandidat.

**2. Dieselbe Rechnung an zwei weiteren Stellen.**
- `hl_anker._stat` (Heatmap-Anker, 23.28): „belegt“ (trendbereinigt z ≥ 2 in zwei Horizonten) macht Cluster zum Ziel des Pfads der
  HAUPTprognose. Mit wenigen gleichen Treffern hätte das ohne Beleg gegriffen. Ob das auf dem Pi geschah, ist nicht bekannt; die
  Bilanz läuft täglich und rechnet nach dem Update neu.
- Ereignis-Profile (`hl_konstellation`, U43): Ein toter Treiber hat in allen Fällen dieselbe Abweichung. Die Streuung ist exakt 0, z
  wird unendlich (im Selbsttest nachgewiesen); in JSON wäre das „Infinity“ geworden.
- Geprüft und unverändert, weil die Werte stetig sind oder ein Boden den Standardfehler hält:
  - Treiber-Bilanz (Mindest-Streuung im Standardfehler), Konstellationen (gepoolter Standardfehler mit Boden), Aktive Profis
    (Boden);
  - TradeLabor (t über Blockwerte in %; Stufen erst ab 15 bzw. 30 Blöcken), Elite-t (4-h-Blockrenditen), `check_magnet` (Bewegungen
    in %). Gleiche Werte in allen Blöcken kommen dort praktisch nicht vor; das steht als Restpunkt in U119.

**3. Gebaut.**
- `hl_forecast.z_treffer(paare)`: z einer Trefferquote EXAKT. paare = (Treffer 0/1, Erwartung) je Fall.
  - Unter dem Zufall ist die Zahl der Treffer eine Summe von Binomialverteilungen, je Erwartungswert eine (bei Richtungsfamilien
    zwei: Basis und 1 − Basis).
  - z = Normalwert des mittleren p-Werts P(X < k) + ½ · P(X = k), beide Ränder getrennt gerechnet.
  - Der p-Wert ist nach unten auf 10⁻¹² begrenzt; damit ist |z| höchstens rund 7,0.
  - Bei vielen Fällen ist das das Binomial-z mit dem Standardfehler der Nullhypothese (wie die Richtungsprobe seit 23.44).
- Treiberfamilien und Heatmap-Anker rechnen ihr z damit. Der Vorsprung (pp) bleibt gleich, nur z ändert sich. Die Berührung echt
  gegen Spiegel im Anker nimmt den Vorzeichentest auf den ungleichen Paaren.
- Ereignis-Profile: `_profil_zwerte` (vorher innere Funktion) gibt ohne Streuung kein z.
- Dashboard: Erklärung am Kopf der z-Spalte der Treiberfamilien.

**4. Proben.**
- `hl_forecast.py --nulltest`, neue Prüfung „z exakt“:
  - 3 von 3 bei 52,5 % → z +1,46 (vorher 1,2 · 10¹⁶);
  - 230 von 400 bei 50 % → +3,00, gleich dem Binomial-z;
  - zwei Erwartungen (60 % und 40 %) → +1,421; mit einer gemeinsamen wären es +1,394;
  - unter dem Zufall exakt ausgezählt, z ≥ 2 bei n 3–60 und p 0,15 / 0,3 / 0,5: höchstens 3,5 %, im Mittel 2,1 % (Soll 2,3 %).
- `hl_familien.py --nulltest`: die bisherigen Prüfungen grün. Großkonten-Fluss z 24,8 → 7,0 (das Stichproben-z war bei hoher
  Trefferquote zu groß; 7,0 ist die Obergrenze), Stärke 8,2 → 7,0, ETF (Rauschen) +2,1 → +2,0. Neu „Wenige Fälle“: 3 von 3 → z
  +1,46, Kandidat; 5 von 6 bei 50 % → +1,53 (vorher +2,0).
- `hl_anker.py --nulltest`: Magnet belegt, Rauschen und Trendfalle nicht, wie bisher. Neu „Wenige Fälle“: 3 von 3 bei 55 % → +1,38;
  Berührung 3 von 3 nur echt → +1,53; ohne ungleiche Paare kein z.
- `hl_konstellation.py --nulltest`: neu „ohne Streuung kein z“ (vorher z unendlich).
- Mutationen: 7 von 7 rot, Kontrollen sauber. Rot werden: z wieder über die Stichproben-Streuung (Familien, Anker), Spiegel-z über alle
  Paare, exakter statt mittlerer p-Wert, eine gemeinsame Erwartung statt Gruppen, ohne Untergrenze des p-Werts, Ereignis-Profile ohne
  Streuungs-Schutz.
- Demo (BTC, ZEC): Familien-Bericht und Anker-Bilanz laufen; Kaskaden mit 1 bis 2 Fällen ohne z.
- Batterie wie in 3ξ grün, `install.py --selftest` aus dem Paket: 30 Schritte.

**5. Was auf dem Pi zu erwarten ist.**
- Treiberfamilien: z höchstens rund ±7. Bei wenigen Fällen ist es kleiner als vorher: Kaskaden (BTC, 3 von 3) +1,46 statt 1,2 · 10¹⁶,
  Profi-Flow unter 2. Familien mit hoher Trefferquote zeigen kleinere z als vorher. Der Vorsprung (pp) bleibt gleich.
- Stufen: Eine Familie, die mit dem alten z schon „Bewährung“ oder „aufgestiegen“ erreicht hat, bleibt dort nach den Regeln, bis die
  Wochenurteile anders ausfallen.
- Heatmap-Anker: Die nächste tägliche Bilanz rechnet neu. „Belegt“ kann für einzelne Coins wegfallen, wenn es auf wenigen Fällen
  stand; dann sind Cluster nicht mehr Ziel des Pfads.

**Was man wissen muss:**
- Eine Stichproben-Streuung ist bei wenigen gleichen Werten 0, und Fließkomma macht daraus 10⁻¹⁷. `> 0` schützt dann nicht. Für
  Trefferquoten gehört der Standardfehler des Zufalls in den Nenner (Lehre 23.44, Punkt 5), hier jetzt exakt.
- Wo ein Fehler steckt, steckt er oft auch in den Kopien derselben Rechnung. Der Fund in den Familien führte zum Anker und zu den
  Ereignis-Profilen.

## 3π. Makro-Chart (U121) mit Miner-Kostenbasis und eigener `makro.db`; U120 v2-Kachel; U122 Zeitbombe im Recorder-Selbsttest (05.10., Version 2026-09-23.47, Opus 5.5)

Anlass: Nutzer 05.10. 04:20, nach der Recherche (`RECHERCHE_Makro_Chart_05-10-2026.md`): „alles obige einbauen, was kostenlos ist,
jeweils mit einem visuellen Chart; dazu ein Chart für die Miner-Kostenbasis (Ausgangsszenario S21 XP für 7,5 ct/kWh); zur
Entlastung der Datenbank eine neue zusätzliche Datenbank `makro.db`“. Im Paket außerdem U120 (war für das nächste Paket geplant) und
U122 (beim Selbsttest dieses Pakets gefunden). Fusion, v3 und Kaskaden-Rechnung unberührt (Zusage bis 25.10.).

**1. Gebaut (Einzelheiten: `KONZEPT_Makro.md`).**
- `hl_makro.py`: Abruf, Rechnung je Treiber, Nutzlast je Tab, Selbsttest (42 Prüfungen). `hl_makro_js.py`: das Skript des Abschnitts
  (`/makro.js`, 47 kB). Im Dashboard der Abschnitt „MK Makro“ (Navigation „Makro“); er lädt nur, solange er offen ist (dann alle
  2 min neu).
- Eigene Datenbank `makro.db` neben `hl_liq.db` (Tabellen `mk_reihe`, `mk_abruf`, `mk_meta`, `mk_stand`, `mk_pl`). Geschrieben nur
  vom Makro-Takt, einem Thread im Dashboard-Prozess (90 s nach dem Start, dann alle 20 s fällige Ziele), jede Transaktion
  `BEGIN IMMEDIATE`. `hl_liq.db` wird nur gelesen: der letzte BTC-Kurs aus `bars` (höchstens 15 min alt) für die Spalte „jetzt“.
- Quellen, alle frei: Coin Metrics Community (BTC ab 18.07.2010; ETH, ZEC, XMR), FRED ohne Schlüssel (12 Reihen), alternative.me,
  DefiLlama, Blockchain.com, Deribit, Binance Futures mit dem OI-Archiv data.binance.vision, Farside, BGeometrics (8 Endpunkte,
  höchstens 7 je Stunde und 14 je Tag bei 8 freien je Stunde und 15 je Tag).
- Neun Tabs; jeder Treiber ist in einem Chart zu sehen, als eigener Chart oder als Linie im Chart seiner Bezugsgröße (Delta Price
  im Realized-Price-Chart, Epochen-Hochs und -Tiefs als Marken im MVRV-Chart). NUPL = 1 − 1/MVRV wäre dieselbe Kurve wie das MVRV
  und steht deshalb im Fadenkreuz des MVRV-Charts.
  - Überblick: Satz aus den Positionen, Zonenkarte (Tagesschluss und „jetzt“, Lage als Perzentil; am Handy als Karten), Chart
    „Kurs und Kostenbasen“.
  - Bewertung: Realized Price, MVRV mit Perzentil über alles und über 4 Jahre, MVRV-Z, NUPL, Delta Price, Epochen-Hochs und -Tiefs,
    Bewertungsdivergenz (Hypothese).
  - Trend: Power Law mit Bändern und kausalem Perzentil, 200-Wochen-MA (Coin wählbar), Halving-Zyklen.
  - Kohorten (BGeometrics): Kurzfrist- und Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV,
    realisierte Verluste.
  - Miner: Kostenbasis (Punkt 2), Puell Multiple, Hash Ribbons, Difficulty Ribbon.
  - Hebel & Stimmung: Funding in % p. a., Open Interest ÷ Marktkap., DVOL, Fear & Greed, Wochen-RSI.
  - Kapitalfluss: Stablecoins, SSR, ETF-Nettoflüsse BTC und ETH.
  - Makro: Nettoliquidität, globaler Liquiditäts-Proxy, M2, Realzins, Dollar, Hochzinsspread, Leitzins, jeweils mit rollierender
    Korrelation zur BTC-Wochenrendite und Zufallsband.
  - Daten: Quellen mit Lizenz, letzte Abrufe, je Reihe Zeitraum, Alter und Grenze; Warnzeile für zu alte und fehlende Reihen.
- Jeder Chart: eine y-Achse (nie zwei), Legende ab zwei Reihen, Fadenkreuz mit allen Werten des Tages, Tabellenansicht, Quelle
  darunter; Farben geprüft (Prüfskript, dunkle Fläche).
- Recorder: das tägliche Backup sichert `makro.db` als `makro_backup.db` (plus eine Generation). Debug: „Makro: Stand und
  Quellen“, „Makro: jetzt abrufen“, „Makro: Selbsttest“. Berichtsplan: `u121-makro-erstlauf` einmal am 06.10. 20:15, „Makro: Stand“
  im Wochenplan (W14). `HL_MAKRO=0` schaltet den Takt ab.

**2. Miner-Kostenbasis (Szenario, keine Messung).**
- Stromkosten je BTC = J/TH × Strompreis × Difficulty × 2³² ÷ 10¹² ÷ 3,6 · 10⁶ ÷ (Emission + Gebühren je Block, 7-Tage-Summen aus
  Coin Metrics). Der Server liefert die Einheit (USD je BTC für 1 J/TH und 1 USD/kWh), der Browser rechnet das Szenario: umschalten
  ohne neuen Abruf.
- Ausgangsszenario: Antminer S21 XP 13,5 J/TH bei 7,5 ct/kWh. **Annahme (vom Nutzer nicht genannt): US-Cent.** Umschaltbar auf
  Euro-Cent mit dem Tageskurs EUR/USD (FRED DEXUSEU). Geräteliste (S21 XP Hydro 12, S21 Pro 15, S21 17,5, S19 XP 21,5, S19j Pro
  29,5 J/TH) oder eigener Wert, Aufschlag für sonstige Kosten in %.
- Chart: Kurs, Szenario, Band Strompreis ± 2,5 ct, ältere Flotte S19 XP gestrichelt; darunter Kurs ÷ Kosten.
- Prüfwert: Difficulty 1,318 · 10¹⁴, 3,16 BTC je Block → 50.383 USD je BTC.

**3. Entscheidungen.**
- Positionen statt Signale, keine festen Schwellen aus 2013–2021, kein Gesamtwert (Gründe im Bericht und in `KONZEPT_Makro.md` 1).
- Jede Rang-, Z- oder Anpassungsreihe ist kausal; die Power-Law-LINIE im Chart ist über alle Tage angepasst (beschreibend, so
  beschriftet), ihr Perzentil kausal (Anpassung je Monat bis zum Vormonat, Parameter in `mk_pl`).
- Die ersten 180 Tage einer MVRV-Reihe sind verworfen (BTC: 146 am 18.07.2010 ist Anlauf der realisierten Kapitalisierung, kein
  Hoch). Mit 75 Tagen blieb im November 2010 noch 8,19; mit 180 Tagen sind die Epochen-Hochs die des Berichts (7,74 …).
- Hash Ribbons: Kreuzungen im Rauschen der Hashrate sind keine Kapitulation → Rauschschwelle 3 σ/√60, σ aus den 365 Tagen vor der
  Episode. Ohne genug Vorlauf bleibt eine Episode ohne Urteil.
- Miner: kein Perzentil von Kurs ÷ Kosten (ein fester Gerätetyp über die ganze Historie ist kein Maßstab; mein erster Entwurf zeigte
  1,3 %).
- Die Zonenkarte wird einmal je Tag in `mk_stand` festgeschrieben: die eigene Bilanz außerhalb der Stichprobe, ohne Revisionen.
- Frische-Alarm (eigenes Abnahmekriterium von U121, beim Schreiben dieser Doku als fehlend bemerkt und nachgebaut):
  - Je Reihe Alter des letzten Werts gegen eine Grenze je Quelle (Coin Metrics 5 Tage, Farside 7, FRED täglich 10, wöchentlich
    veröffentlicht 14, EZB 21, M2 und BoJ 100).
  - Dazu „fehlt“: Reihen, die ein schon erfolgreich abgerufenes Ziel liefern müsste, die es aber nicht gibt.
  - Grund: Verschwindet eine Metrik aus dem freien Katalog, scheitert oft kein Abruf; die Reihe bleibt nur stehen.
- Nicht gebaut: 25-Delta-Skew (keine freie Historie), Treasury-mNAV (keine freie Schnittstelle), alles aus Stufe 3.

**4. U120: v2-Kachel (eigener Fehler seit 23.26).**
- Der Brier-Skill der v2-Kachel wurde gegen die OOF-Klimatologie der Trainingsfolds gemessen; der Achsenabschnitt des
  Kalibrierschritts kennt aber alle OOF-Fälle. So zeigte schon c = 0 (reine Basisrate) Skill.
- Jetzt gegen denselben Kalibrierschritt mit c = 0 auf denselben Fällen (wie v3). Bei c = 0 ist der Skill genau 0, die Quote heißt
  dann „Basisrate“. Die alte Zahl bleibt als `brier_skill_klima` im Debug.
- Nur Anzeige: p_up_v2, Achsenabschnitt, c, Gewichte, λ und Quote bitgleich (Positivkontrolle vorher/nachher verglichen).

**5. U122: Zeitbombe im Selbsttest „Recorder: Masterregel ohne Kleinfills“ (eigener Fehler aus 23.38).**
- Der Test lief mit der echten Uhr und legte eine vorläufige Sperre „vor dem 29.09.“ auf den 28.09. 00:00 UTC. Seit dem 05.10.
  00:00 UTC ist sie älter als 7 Tage; die Regel „vorläufig ohne zweiten Tag: nach 7 Tagen frei“ gibt sie richtig frei, die Erwartung
  „unberührt“ galt nur bis 04.10.
- Betrifft auch das gelieferte 23.46: Ein Selbsttest auf dem Pi ab dem 05.10. zeigt diesen Schritt rot. Das System rechnet richtig,
  nur der Test war datumsabhängig.
- Korrektur: feste virtuelle Uhr (02.10. 12:00 UTC plus verstrichene Zeit), wie U34/U36. Das Muster war bekannt, ich habe es hier
  nicht angewandt.

**6. Proben.**
- `hl_makro.py --selbsttest`: 42 Prüfungen in rund 2 s.
  - Mathematik je Treiber mit Positivkontrolle und Nulltest.
  - Parser je Quelle: Coin Metrics, FRED, alternative.me, DefiLlama und Deribit gegen am 05.10. gelesene Antworten;
    BGeometrics, Farside-Gesamtseiten und das Binance-Archiv gegen nachgebaute Beispiele (auf dem Pi offen).
  - Zeitplan mit falschem Netz und springender Uhr: Budget, Pause, Erstabruf mit ganzer Historie.
  - Kausalität: Zukunftsdaten × 50 angehängt, 19 Reihen bitgleich.
  - Nutzlast je Tab, Archiv, fehlende `makro.db` (Hinweis, nichts angelegt).
  - Frische mit fester Uhr: stehengebliebene Reihe gemeldet, M2 mit 80 Tagen Verzug nicht, Farside-Wochenende nicht; fehlende
    Reihe nach erfolgreichem Abruf gemeldet, vor dem ersten Abruf nicht.
- Mutationen: 27 von 27 rot (davon 4 für die Frische).
- Rückrechnung mit echten Coin-Metrics-Daten (öffentlicher GitHub-Spiegel bis 24.05.2026) gegen den Bericht:
  - MVRV 06.10.2025 2,287, Realized Price 54.576,53 USD, MVRV-Z 2,53, Puell 1,07; MVRV 21.11.2022 0,778.
  - Epochen-Hochs 7,74 · 5,88 · 4,72 · 3,96 · 2,74.
  - Power-Law-Exponent über alle Tage 5,674 (Perrenod 5,674), bis 09/2019 5,822 (Burger 5,845).
  - Hash Ribbons über der Schwelle u. a. 11/2018, 03/2020, 06/2021, 11/2022 und 01–02/2026 mit Kaufsignal 05.03.2026 (Recherche:
    CoinDesk 25.02.2026).
- Sichtprüfung aller Tabs in Desktop- und Handybreite (Playwright): keine Skriptfehler, nichts über den Rand. Fadenkreuz-Tooltip in
  Überblick, Miner und Makro geprüft. Tab „Daten“: Alter und Grenze stehen direkt neben dem Reihennamen, damit sie am Handy
  ohne Seitwärtsschieben sichtbar sind (erste Fassung hatte sie rechts außen).
- Gemessen auf der Testdatenbank: 178.508 Zeilen in 49 Reihen, 7,8 MB. Ganze Rechnung 0,6 s in der Sandbox; Nutzlast je Tab
  9–440 kB roh (Miner am größten), im Dashboard gzip.
- U120: Positivkontrolle v2, Rausch-Szenarien mit c = 0:
  - Brier-Skill vorher +0,001 bis +0,014 (Mittel +0,009), jetzt in allen 5 genau 0.
  - Mit c > 0 über 0 in 5 von 5; Tor und Gleichlauf unverändert.
  - Mutation (Skill wieder gegen die Klimatologie) macht den Nulltest rot.
- U122: vor der Korrektur rot (eigener Lauf 05.10.), danach grün.
- `install.py --selftest-isoliert`: 31 Schritte, PNG und 9 Dashboard-Abrufe grün, darunter `/makro` und `/makro.js`.
- Beide Skriptblöcke der Seite und `/makro.js` mit `node --check` geprüft.

**7. Was auf dem Pi zu erwarten ist.**
- Nach dem Update startet der Makro-Takt mit dem Dashboard und ruft 90 s später ab.
  - Coin Metrics, FRED, alternative.me, DefiLlama, Blockchain.com, Deribit, Binance und Farside binnen Minuten.
  - BGeometrics über rund eine Stunde (8 Endpunkte, 8 min Abstand, 7 je Stunde).
  - Das OI-Archiv nach und nach, eine Tagesdatei je 20 s (rund 2.200 Dateien, rund 12 h). Bis dahin zeigt OI ÷ Marktkap. nur
    die 30 Tage der REST-Schnittstelle.
- Bis zum ersten Coin-Metrics-Abruf zeigt der Abschnitt „zu wenig BTC-Kursdaten (Coin Metrics noch nicht abgerufen)“.
- Die Bewertungsfelder von Coin Metrics sind erst bei T−2 vollständig. MVRV und Realized Price enden deshalb zwei Tage vor heute;
  „jetzt“ nutzt den Live-Kurs.
- v2-Kachel: nach dem nächsten v2-Lauf (beim ersten Lernlauf nach dem Neustart, dann stündlich) bei Coins mit c = 0
  „Quote … (= Basisrate, c 0)“ und „Brier-Skill 0.000 gegen c 0“. Vor diesem Lauf steht die alte Zahl ohne „gegen c 0“.
- Selbsttest: 31 Schritte; der Makro-Schritt braucht in der Sandbox rund 2 s.
- **Bericht `u121-makro-erstlauf` am 06.10. 20:15** (Debug „Makro: Stand und Quellen“ und „Makro: Selbsttest“; Plan U123), bitte
  hochladen.
  Erst damit sind die Formate belegt, die die Sandbox nicht erreichen konnte:
  - Feldnamen von BGeometrics;
  - Farside-Gesamtseiten;
  - data.binance.vision und Binance Futures vom Pi aus.
  Abnahme: jede Quelle mit Zeilen und ohne Dauerfehler; Frische-Zeile ohne „ZU ALT“ und ohne „FEHLT“; Realized Price 03.10.2026
  ≈ 53.680 USD (Bericht); Budget BGeometrics ≤ 14 je Tag.

**Was man wissen muss:**
- Ein Test mit echter Uhr und festen Daten ist eine Zeitbombe: Er prüft am Tag des Schreibens etwas anderes als eine Woche später.
  Jeder Test, der Daten relativ zu einem festen Datum anlegt, braucht eine feste Uhr.
- Beim MVRV entscheidet der Anlauf über die Extremwerte. Wer Hochs je Epoche vergleicht, muss den Anlauf der realisierten
  Kapitalisierung verwerfen, sonst ist das erste „Hoch“ ein Rechenartefakt.
- Freie Fenster verschwinden (BGeometrics 4 Jahre, FRED-HY 3 Jahre, Binance-REST 30 Tage). `makro.db` behält, was einmal abgerufen
  wurde. Deshalb gehört sie ins Backup.
- Freie Quellen können still ausfallen: Ein Feld verschwindet, die Abfrage antwortet weiter mit 200. Deshalb prüft der Stand das
  Alter jeder Reihe, nicht nur den Erfolg des Abrufs.

## 3ρ. Erster Pi-Lauf des Makro-Charts: FRED hängt ohne Schlüssel, BGeometrics frei mit 7 Tagen Verzug (05.10., Version 2026-09-23.48, Opus 5.5)

Anlass: Bild des Tabs „Daten“ vom Pi (05.10. 12:14, Handy), Frage des Nutzers „Fehler?“. Der Pi lief seit etwa 11:35 mit 23.47.

**1. Befund vom Bild.**
- Läuft und ist damit auch im Format belegt:
  - Coin Metrics (4 Coins), alternative.me, DefiLlama, Blockchain.com (Gegenprobe Hashrate Coin Metrics ÷ Blockchain.com 1,000),
    Deribit;
  - Binance: Funding, Open Interest per REST und das Archiv data.binance.vision (53 Tage geholt, 0 fehlend);
  - Farside BTC/ETH (Alter 3 Tage: letzter Handelstag Freitag);
  - BGeometrics mit den Feldnamen `sthRealizedPrice`, `trueMarketMean`, `lthRealizedPrice` (3 von 8 Endpunkten bis 12:14).
- **FRED:** alle 12 Reihen „TimeoutError: The read operation timed out“, nacheinander 09:53–10:02 UTC. Die übrigen Quellen hatten
  ihren Erfolg um 11:46 Ortszeit; sie stehen im Zeitplan hinter FRED. Das passt zu zwei FRED-Runden zu je 12 × 45 s, die den
  Takt jeweils rund 9 Minuten anhielten (etwa 11:37–11:46 und 11:53–12:02 Ortszeit). Deshalb waren bis 12:14 erst 53 Archivtage
  und 3 BGeometrics-Abrufe da.
- **„Zu alt (3)“:** die drei BGeometrics-Reihen mit Alter 7 Tage bei Grenze 6.

**2. Ursachen.**
- **FRED:** `fredgraph.csv` ohne Schlüssel öffnet die Verbindung, die Antwort kommt nie. Das liegt nicht am Pi: Seit Mitte August
  2026 berichten mehrere Projekte dasselbe, von GitHub-Runnern und vom Heim-PC, und stellten auf die offizielle API mit kostenlosem
  Schlüssel um. Belege:
  - https://github.com/00xJS/Chronoticker/pull/2 („has timed out … since mid-August“);
  - https://github.com/Puma1939/morning-briefing-gmail/pull/5 („la connessione si apre ma la risposta non arriva mai“);
  - https://github.com/sechan9999/macropulse-alexa-mcp/pull/18 („also hangs from a home PC“).
  - Eigener Fehler: Ich hatte am 05.10. nur das Format über das Abrufwerkzeug der Sandbox geprüft, nicht die Erreichbarkeit für ein
    Skript. Und 45 s Wartezeit je Reihe ohne Abbruch je Quelle ließen eine hängende Quelle den ganzen Takt anhalten.
- **BGeometrics:** Die freie API liefert die jüngsten 7 Tage nicht. Am 05.10. an `/v1/sth-realized-price/last` gelesen: letzter Wert
  28.09., dazu `"delayed": true` und „Real-time data (last 7 days) requires an active subscription“. Das ist kein Abruffehler,
  meine Frische-Grenze von 6 Tagen war zu knapp. Die Recherche nannte nur „4 Jahre, 15 Abrufe am Tag“; der Verzug fehlte dort.

**3. Gebaut.**
- **FRED über die offizielle API**, sobald ein Schlüssel da ist: Umgebungsvariable `FRED_API_KEY` oder `accesstokens.json` →
  `"fred"` → `"api_key"`. Ohne Schlüssel bleibt `fredgraph.csv` als Versuch, mit 15 s statt 45 s Wartezeit.
- **Schlüssel eintragen:**
  - im Tab „Daten“: Feld und Knopf „prüfen und speichern“ (POST `/makro/fred_schluessel`, Schutz wie Update und Debug);
  - oder im Projektordner: `.venv/bin/python hl_makro.py --db <hl_liq.db> --fred-schluessel <SCHLÜSSEL>`.
  - Beide Wege prüfen das Format (32 Zeichen a–z, 0–9) und machen einen Probeabruf. Einen abgelehnten Schlüssel schreiben sie nicht.
    Die übrigen Einträge der Datei bleiben, die Datei wird atomar ersetzt, die FRED-Pausen werden zurückgesetzt.
  - Der Schlüssel erscheint nie in Fehlertexten, im Abrufprotokoll, in der Antwort oder in einer Adresse.
- **Abbruch je Quelle und Runde:** Antwortet ein Host nicht (Zeitüberschreitung, Verbindungsfehler), werden die übrigen Ziele
  dieser Quelle in der Runde übersprungen und pausieren mit (15 min, verdoppelt bis 6 h). HTTP-Fehler einer Reihe sperren nichts.
  Ein hängender Host kostet jetzt höchstens 15–20 s je Runde statt 9 Minuten.
- **BGeometrics:** Frische-Grenze 9 Tage (7 Tage Verzug plus Tagesabruf); Hinweise im Tab „Kohorten“, in der Zonenkarte („Linie
  frei mit 7 Tagen Verzug“) und im Stand.
- **Tab „Daten“:**
  - Fehler als eigene Zeile unter dem Ziel, über die volle Breite, mit „nächster Versuch“ (am Handy war die Fehlerspalte eine
    schmale Säule);
  - eine FRED-Zeile mit Weg (API oder CSV), Zahl der abgerufenen Reihen und Abhilfe.
- **Miner:** Hinweis bei Euro-Cent, solange EUR/USD (FRED DEXUSEU) fehlt.
- **`accesstokens.json`:** Die Vorlage hat einen Eintrag `"fred"`. Auf dem Pi bleibt die vorhandene Datei (`update.py`
  überschreibt sie nie); Feld oder Befehl ergänzen den Eintrag.

**4. Proben.**
- `hl_makro.py --selbsttest`: 49 Prüfungen. Neu sind 7:
  - FRED-API-Parser (`'.'` fehlt, Fehlerantwort leer);
  - mit Schlüssel alle 12 Reihen über die API;
  - Schlüssel nie im Fehlertext oder Protokoll;
  - eine Zeitüberschreitung je Quelle, der Rest pausiert, andere Quellen laufen weiter;
  - ein HTTP-Fehler sperrt nichts, auch ein 504 mit „timeout“ im Text nicht;
  - Umgebungsvariable vor Datei;
  - Einrichten mit Format, Ablehnung, Erhalt der übrigen Einträge, Pausen zurück, kaputte Datei unberührt.
  Der Selbsttest ist unabhängig von einem echten Schlüssel auf dem Pi (Umgebung und Datei umgelenkt).
- Mutationen: 37 von 37 rot (10 neu: Schlüssel ignoriert, nichts geschwärzt, kein Abbruch je Quelle, Übersprungene ohne Pause,
  HTTP-Antwort als Netzfehler, Umgebung ignoriert, Format nicht geprüft, Abgelehntes geschrieben, Pausen nicht zurück,
  BGeometrics-Grenze 6).
- Dashboard lokal:
  - POST ohne Kopfzeile abgelehnt;
  - falsches Format und leerer Körper ergeben eine Meldung;
  - ein gültiges Format wird eingetragen; die Antwort enthält den Schlüssel nicht, der Eintrag „coinglass“ bleibt;
  - der Tab „Daten“ zeigt sofort „mit Schlüssel“ (Antwort-Cache geleert).
- Sichtprüfung Handy und Desktop: Feld und Knopf, Fehlerzeilen über die volle Breite, Kohorten-Hinweis.
- Ein eigener Fehler im neuen Test (Prüfung auf das Wort „ablehnt“, die Meldung sagt „lehnt … ab“) fiel beim ersten Lauf auf, der
  Code war richtig.
- **Nicht prüfbar in der Sandbox:** ob `api.stlouisfed.org` vom Pi antwortet (die Sandbox erreicht FRED nicht). Die drei
  Projekte oben melden die API als funktionierend.

**5. Was auf dem Pi zu tun und zu erwarten ist.**
- Kostenlosen Schlüssel holen: Konto bei fredaccount.stlouisfed.org, dort „API Keys“ → „Request API Key“. Dann im Makro-Tab
  „Daten“ eintragen.
- Danach ruft der Takt FRED binnen einer Minute ab; die Charts folgen binnen rund 10 Minuten (gerechnet wird höchstens alle
  10 Minuten). Dann gibt es den Tab „Makro“ und im Miner-Tab Euro-Cent.
- Ohne Schlüssel ist die FRED-Zeile gelb. Es gibt einen Versuch je Runde und eine Pause bis 6 h; alles andere läuft ungebremst.
- „Zu alt“ für BGeometrics verschwindet; die Kohortenwerte enden 7 Tage vor heute.
- Der Bericht `u121-makro-erstlauf` am 06.10. 20:15 bleibt (U123).

**Was man wissen muss:**
- Ein Format prüfen heißt nicht, die Erreichbarkeit zu prüfen: Das Abrufwerkzeug der Sandbox ist kein Skript auf dem Pi.
- Eine Quelle darf den Takt nicht anhalten. Zeitüberschreitungen multiplizieren sich mit der Zahl der Ziele (12 × 45 s).
- Freie Stufen haben Bedingungen jenseits von Kontingent und Historie, hier 7 Tage Verzug. Bei jeder freien Quelle im ersten echten
  Abruf das jüngste Datum ansehen.

## 3σ. Makro-Signale (U126): Kauf- und Verkaufszonen je Chart, Rückblick, Bilanz gegen Zufall, Prognose „Rückkehr zum Median“ (05.10., Version 2026-09-23.49, Opus 5.5)

Anlass: Wunsch des Nutzers 05.10. 13:59: statistische Kauf- und Verkaufssignale in den Makro-Charts. Je Chart soll berechnet
werden, wie weit die Reihe über oder unter ihrer Referenzlinie lag (in %), dazu die idealen Kauf- und Verkaufspunkte je Zeitskala
(1 J, 2 J, 4 J, 8 J, alles), der „optimale Median“ und ein extrapolierter Wert; für alle Charts, täglich. Auf Rückfrage gewählt:
alle Charts mit Referenzlinie; Rückblick und Live getrennt; Median der Abweichung; Rückkehr zum Median, 3/6/12 Monate mit 80-%-Band.

**1. Gebaut.**
- **Neues Modul `hl_makro_signal.py`:** reine Rechnung, ohne Datenbank und ohne Netz. Es rechnet 14 Paare (Reihe gegen
  Referenzlinie):
  - Bewertung: Kurs gegen Realized Price (BTC, ETH, ZEC) und gegen Delta Price (BTC).
  - Trend: Kurs gegen den kausalen Power-Law-Fair-Value (BTC) und gegen den 200-Wochen-MA (BTC, ETH, ZEC, XMR).
  - Kohorten: Kurs gegen Kurzfrist-Kostenbasis, True Market Mean und Langfrist-Kostenbasis (BTC; BGeometrics, 7 Tage Verzug).
  - Miner: Kurs gegen die Stromkosten (S21 XP, 7,5 ct), nur 1, 2 und 4 J, weil ein fester Gerätetyp über 8 Jahre kein Maßstab
    ist; dazu Puell gegen 1.
- **Je Paar und Zeitraum** (nur wenn die Historie mindestens 90 % des Zeitraums deckt):
  - **Abweichung:** y = ln(Reihe ÷ Referenz). Angezeigt wird e^y − 1 in %.
  - **Median** der Abweichung im Zeitraum: gepunktete Linie im Hauptchart und im Signal-Chart.
  - **Rückblick:** tiefster und höchster Stand und die idealen Wendepunkte ▲▼. Sie kommen aus einem Zickzack auf dem zentrierten
    7-Tage-Mittel; die Mindestwende ist die halbe Spannweite P10–P90, mindestens 5 %. Beschriftet als „erst im Nachhinein bekannt“.
  - **Live-Signal:** Perzentil der heutigen Abweichung unter den letzten W Tagen, nur mit Daten bis heute. Kauf bei ≤ 10, Verkauf
    bei ≥ 90. Die Schwellen P10/P90 stehen gleitend als Linien im Chart, die Signalzeiten als Flächen.
  - **Bilanz des Live-Signals** (nachgerechnet): Episoden statt Tage, Rendite nach 90/180/365 T gegen Zufallstage, „belegt“ bei
    p < 0,025.
  - **Prognose:** AR(1) um den Median mit Halbwertszeit (90-%-Intervall) und Dickey-Fuller-t (belegt unter −2,86). Die
    Referenzlinie wird fortgeschrieben: Trend der letzten 365 Tage, Power Law mit den Parametern des Monats, Puell konstant 1.
    Ergebnis: Wert in 90/180/365 T mit 80-%-Band aus den eigenen Prognosefehlern der letzten 4 Jahre. Die Rückblick-Prüfung zeigt
    die Abdeckung (Soll 80 %) und den Fehler gegen „die Abweichung bleibt“.
- **Täglich:** `hl_makro.signale(D)` rechnet einmal je Datentag, mit eigenem Schloss; ein Fehler reißt die Charts nicht mit. Der
  Makro-Takt schreibt den Tagesstand nach `mk_signal` (`INSERT OR IGNORE`, `BEGIN IMMEDIATE`). Er wird nie überschrieben: Es bleibt
  der erste Stand je Datentag, so wie er zu sehen war.
- **Live gegen Nachrechnung:** Jede archivierte Zeile wird mit dem Perzentil verglichen, das die heutige Rechnung für denselben Tag
  ergibt (± 0,01). Das steht unter der Signaltabelle und im Stand; bei Abweichung gelb, mit Paaren und Beispielen.
- **Dashboard** (Tabs Bewertung, Trend, Kohorten, Miner):
  - Signaltabelle je Zeitraum, am Handy als Karten.
  - Im Hauptchart die Median-Linie und ▲▼.
  - Je Paar ein Signal-Chart: log. Skala mit %-Teilung, P10/P90 gleitend, Flächen, Prognose mit Band 365 T nach rechts.
  - Text: Lage, Rückblick, Bilanz-Tabelle (aufklappbar) und Prognose-Tabelle.
- **Debug und Berichte:**
  - „★ Makro: Stand und Quellen“ zeigt je Paar und Zeitraum Lage, Live-Signal, Belegtes und die Prognose 365 T mit Band und
    Prüfung, dazu die Nachrechnung.
  - Neu ist „Makro: Selbsttest der Signale (U126)“; der Installer hat damit 32 Schritte.
  - Berichte `u126-makro-signale` (08.10. 20:15) und `u127-makro-nachrechnung` (05.11. 20:15); die Wochenprüfung W14 ist erweitert.

**2. Kalibrierung vor der Auslieferung (eigene Fehler, gefunden durch die Nulltests).**
- **Bilanz:** Der erste Entwurf war ein Block-Bootstrap über alle Signaltage („belegt“, wenn das 90-%-Intervall die 0 ausschließt).
  Auf reinen Zufallswegen erklärte er 26–41 % der Tests für belegt statt 10 %.
  - Ursache: Läufe, in denen der Kurs weiter fällt, werden länger und zählen mit mehr Tagen.
  - Längere Blöcke und ein zirkulär verschobenes Placebo waren ebenso falsch kalibriert.
  - Jetzt: Episoden (Signaltage mit höchstens 30 Tagen Abstand, gemessen ab dem ersten Tag). Je Episode ein Zufallstag aus
    ±(Horizont + 365) Tagen, 1000-mal, einseitig p < 0,025.
  - Ergebnis auf Zufallswegen: 5 von 158 Tests belegt (3,2 %). Im Ära-Nulltest 4 von 80; mit Zufallstagen aus der ganzen Historie
    wären es 16–27 von 80.
- **Prognoseband:**
  - Das AR(1)-Modellband war auf echten Daten zu schmal.
  - Ein Band aus den Fehlern aller Jahre war zu breit (bis 97 % Abdeckung), weil die Schwankung von BTC seit 2011 sinkt.
  - Jetzt: 10.–90. Perzentil der eigenen Fehler der letzten 4 Jahre, nur aus Fehlern, deren Ziel am Ursprung schon bekannt war.
    Rückblick-Prüfung und heutiges Band nutzen dieselbe Regel (`_fehler_bekannt`). Eine Abdeckung wird erst ab 20 Prüfungen genannt.
- **Weitere eigene Fehler, vor der Lieferung behoben:**
  - Das Zickzack zählte den ersten Tag als Wendepunkt (Rand).
  - Puell bekam 26 Wendepunkte in 4 Jahren (Tagesrauschen). Deshalb glättet der Rückblick, und nur er, mit dem zentrierten
    7-Tage-Mittel.
  - „zur Realized Price“: Jedes Paar hat jetzt sein eigenes Bezugswort.
  - Eine Testerwartung für den Referenztrend war falsch angesetzt (das 365-Tage-Fenster lag über dem Knick); der Code war richtig.
  - Der Modulkopf beschrieb nach dem Umbau noch den alten Bootstrap.
  - Der Text „so wie es damals sichtbar war“ war eine Behauptung ohne Beleg. Jetzt heißt es „gewesen wäre“, und die Nachrechnung
    gegen das Archiv prüft es.

**3. Ergebnis auf echten Daten** (Test-Kopie in der Sandbox, Coin Metrics bis 23.05.2026).
- 14 Paare, 63 Paar-Zeiträume, gerechnet in 4,0 s.
- **Bilanz: 3 von 322 Tests belegt. Der Zufall allein ließe etwa 16 erwarten.**
  - Belegt sind Power Law 4 J, Kauf 90 T: +56 % gegen +13 % an Zufallstagen (p 0,014, 7 Episoden).
  - Und XMR 200-W-MA 8 J und „alles“, Verkauf 90 T: −21 % gegen +12 % (4 Episoden, dieselben in beiden Zeiträumen).
  - Damit gibt es keinen Beleg, dass die Zonen die Rendite vorhersagen.
- **Verkaufssignale kamen zu früh:** Nach dem Einstieg lag die Rendite im Median 5,3 Punkte über den Zufallstagen (in 64 % der
  Tests). Das ist Momentum: Das oberste Zehntel wurde oft noch übertroffen. Bei Kaufsignalen: +1,3 Punkte, 52 % (kein Befund).
- **Prognose „Rückkehr zum Median“:** besser als „die Abweichung bleibt“ in 83 % (90 T), 78 % (180 T) und 78 % (365 T) der
  Paar-Zeiträume. Der Median-Fehler war 15/16/19 % kleiner. Das Band traf im Rückblick im Median 81/83/85 % (Soll 80; bei 365 T eher
  zu breit, P90 98 %). Die Rückkehr ist nach Dickey-Fuller in 14 von 63 Fällen belegt.
- **Live gegen Nachrechnung:** Stände vom 06.10.2025, 05.02., 01.04. und 01.05.2026, jeweils mit der Datei nur bis zu diesem Tag,
  gegen die Nachrechnung mit allen Daten: 249 von 249 gleich (größte Abweichung 0,005 Pz = Rundung). Die Kette ist auf echten
  Reihen kausal. Ob die Quellen alte Werte nachträglich ändern, zeigt erst das Archiv auf dem Pi.
- **Live-Signale am 23.05.2026** (Datenstand der Kopie), 12 Stück:
  - BTC Kauf: Power Law 2 J, 200-W-MA 2 J, Langfrist-Kostenbasis 2 J, Stromkosten 4 J.
  - ETH Kauf: 200-W-MA 4 J.
  - ZEC Verkauf: Realized Price 2 J, 4 J, 8 J und alles; 200-W-MA 2 J, 4 J und alles.

**4. Proben.**
- `hl_makro_signal.py --selbsttest`: 12 Prüfungen, rund 3 s, ohne Netz.
  - Perzentil und P10/P50/P90 gegen eine unabhängige Nachrechnung (Lücken, Gleichstände), kausal; auf Rauschen sind je 10 % der Tage
    Kauf und Verkauf.
  - Zickzack an einer Welle, mit Rand und offenem letzten Extremwert.
  - Bilanz: Positivkontrolle (Rückkehr-Märkte, 23 von 24 belegt), Nulltest Zufallsweg (3,2 %), Nulltest Ära (4 von 80).
  - Prognose: Positivkontrolle (φ 0,985 wiedergefunden, Abdeckung 78 %), Nulltest Zufallsweg (nicht besser als „bleibt“).
  - Band ehrlich: Bei wachsender Schwankung trifft es seltener als 80 % (71 %). Das Band folgt den letzten 4 Jahren: Fällt die
    Schwankung auf ein Drittel, ist es so schmal wie ohne die alte Zeit.
  - Referenztrend nur aus der Vergangenheit; Power Law mit den Parametern des Ursprungsmonats.
  - Block: JSON ohne NaN, Median = Median des Zeitraums, die Prognose zielt darauf; Rückblick trotz Tagesrauschen ohne Scheinwenden.
  - Live gegen Nachrechnung: gleich ohne Revision, Revision erkannt.
- `hl_makro.py --selbsttest`: 52 Prüfungen, 3 davon neu.
  - Signale je Tab: alle Paare, Miner bis 4 J, Tagesstand einmal je Tag, Nachrechnung in der Nutzlast.
  - Kausalität der ganzen Kette: Zukunft × 50 ändert kein Perzentil davor (44 Reihen bitgleich).
  - Live gegen Nachrechnung mit echter Ableitung: Stand vom 01.05. gleich der Nachrechnung; eine Revision des BTC-MVRV wird
    erkannt, und zwar nur in `rp:BTC` und `delta:BTC`.
- Mutationen: 36 von 36 rot. Geprüft wurden der Signal-Code und der Signal-Teil von `hl_makro.py`; es zählen beide Selbsttests,
  weil beide im Installer laufen.
  - Darunter: Blick nach vorn im Perzentil, Kaufschwelle 20, Seiten vertauscht, Randpunkt, Rückblick ohne Glättung, Median
    durch Mittel, alle Signaltage statt Episoden, p < 0,05, Zufallstage aus der ganzen Historie.
  - Außerdem: Band kennt spätere Fehler, Band aus allen Jahren, Referenztrend aus der Zukunft, Power-Law-Paar mit Anpassung über
    alle Tage, Archiv überschrieben, Nachrechnung mit Toleranz 50 oder versetztem Tag.
  - Im ersten Lauf blieben zwei grün: „Gleichstände nicht gemittelt“ (der Test rechnete mit derselben Funktion nach) und „Band
    aus allen Jahren“ (kein Test mit Schwankungssprung). Ich habe beide Tests ergänzt; danach waren sie rot.
- Die 37 Mutationen von `hl_makro.py` aus 23.48 erneut, jetzt mit der Signal-Rechnung im Testordner: 37 von 37 rot.
- Sichtprüfung Desktop und Handy (Bewertung, Trend, Kohorten, Miner; Playwright): keine Skriptfehler, keine Seitenbreite über den
  Rand. Die Zeile „Geprüft: 249 archivierte Live-Werte … stimmen mit der Nachrechnung überein“ erscheint.
- `install.py --selftest-isoliert`: 32 Schritte grün (neu „Makro-Signale“, 2,8 s), dazu PNG und 9 Dashboard-Abrufe. Die
  Namensprüfung (symtable) fand nichts; `node --check` für beide Skriptblöcke der Seite und für `/makro.js` ist ok.

**5. Was auf dem Pi zu erwarten ist.**
- Die erste Rechnung kommt beim ersten Aufruf eines Signal-Tabs oder im Takt. In der Sandbox dauert sie 4 s; auf dem Pi 5 schätze
  ich 10–15 s (nicht gemessen; der Stand zeigt „gerechnet in … s“). Danach kommt sie aus dem Zwischenspeicher, neu einmal je Datentag.
- `mk_signal` wächst um rund 63 Zeilen am Tag (etwa 23.000 im Jahr, wenige MB).
- Die Nachrechnung ist ab dem zweiten Archivtag prüfbar; Bericht am 08.10. um 20:15.
- 23.48 und 23.49 einspielen und den FRED-Schlüssel eintragen (U124). Die Signale brauchen FRED nicht.

**Was man wissen muss:**
- Die Dreiecke ▲▼ sind Rückblick, erst im Nachhinein bekannt. Das Live-Signal heißt nur „im untersten bzw. obersten Zehntel des
  Zeitraums“.
- Die Bilanz auf echten Daten zeigt keinen Beleg. Die Zonen beschreiben eine Lage, sie sagen keine Rendite voraus. Verkaufssignale
  kamen historisch zu früh.
- Bei vielen Tests ist etwa jeder zwanzigste zufällig belegt; die Seite nennt die Erwartung neben der Zahl.
- Eine Signifikanzregel erst auf Zufallswegen kalibrieren: Fehlurteile zählen, nicht nur ein Intervall ansehen.
- Prognosebänder außerhalb der Stichprobe prüfen, nur mit Fehlern, die am Ursprung bekannt waren.
- Die Bilanz ist nachgerechnet. Ob sie dem entspricht, was live zu sehen war, zeigt erst das Archiv (U127).
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

## 3τ. OI-Chart baute sich nicht auf: das Binance-Archiv lud ab 2020 vorwärts (05.10., Version 2026-09-23.50, Opus 5.5)

Anlass: Bild des Nutzers 05.10. 16:04 (Handy, Tab „Hebel & Stimmung“, Zeitraum 4 J): Im Chart „Open Interest ÷
Marktkapitalisierung“ steht nur ein senkrechter Strich am rechten Rand. Frage: „Der Graph scheint sich nicht richtig aufzubauen,
prüfe“.

**1. Befund.**
- Die Zeichnung rechnet richtig; es fehlen Daten.
  - Binance liefert per REST (`openInterestHist`) nur die letzten 30 Tage.
  - Die Jahre davor kommen aus dem Archiv data.binance.vision, eine Tagesdatei je Takt (20 s), rund 2.200 Dateien.
- Das Archiv lief ab 01.09.2020 **vorwärts**.
  - Am Pi waren um 12:14 53 Tage da (bis etwa 23.10.2020).
  - Bis 16:04 kommt es nach meiner Rechnung kaum über Mitte 2022 hinaus, weil 23.47 zusätzlich bei FRED hängt (12 × 45 s je
    Runde, U124).
- Der Chart beginnt am ersten Datentag, höchstens beim Anfang des Zeitraums.
  - Weil schon Daten von 2020 da sind, spannt „4 J“ die volle Breite. Sichtbar sind aber nur die 30 REST-Tage.
  - 30 Tage auf rund 20 Pixel ergeben den senkrechten Strich.
- Nachgestellt in der Sandbox: Test-Datenbank mit Open Interest nur 01.09.2020–30.06.2022 und den 30 REST-Tagen, alter Code,
  Handybreite. Es entsteht dasselbe Bild.
- **Eigene Fehler:**
  - Die Reihenfolge des Archivs ließ die sichtbaren Zeiträume (1 J bis 4 J) bis zuletzt leer.
  - Solange das Archiv lud, stand am Chart kein Hinweis.
  - Die Zonenkarte rechnete das OI-Perzentil aus einer lückenhaften Historie.

**2. Gebaut.**
- **Archiv rückwärts:** vom Tag vor den REST-Daten bis 01.09.2020, jüngste Tage zuerst.
  - Vorhandene Tage werden übersprungen, also die REST-Tage und auf dem Pi der Vorwärtslauf bis zum Update.
  - Neuer Zustand `oi_archiv_rueck`; der alte Vorwärts-Cursor bleibt unbeachtet.
  - Bei einem Tag je 20 s ist das letzte Jahr nach rund 2 h da, 4 J nach rund 8 h. Das ist gerechnet, auf dem Pi nicht gemessen.
- **Hinweis unter dem OI-Chart** (gelb), solange das Archiv lädt: Tage da gegen Soll seit 01.09.2020, Abschnitte ohne Lücke,
  fehlende Tage und die Dauer in Stunden.
- **Zonenkarte:** kein OI-Perzentil, solange die Historie lückenhaft ist (Archiv nicht fertig, und mehr als 2 % bzw. 10 Tage
  fehlen). Statt des Perzentils steht „Binance-Archiv lädt noch“ mit Tagen da gegen Soll.
- **Tab „Daten“ und Stand:** „läuft rückwärts (bei …)“, Tage da gegen Soll, offen, Dauer, Abschnitte, 404-Tage.
- Neue Funktion `oi_abdeckung(con)`, die Ableitung gibt sie als `OI_ABDECKUNG` mit. Die Nutzlast des Tabs „Hebel“ trägt sie als
  `oi_archiv`.

**3. Proben.**
- `hl_makro.py --selbsttest`: 53 Prüfungen.
  - Die Archiv-Prüfung ist neu gefasst. Ein Vorwärtslauf bis 24.08. ist schon da, alter Cursor 25.08., 404 am 27.08. Abgerufen
    wird genau 05.09. … 25.08., absteigend. Der Vorwärtslauf wird übersprungen, ein Tag zählt als fehlend, dann ist das Archiv
    fertig: 2 Abschnitte, 0 offen. Zwischendurch nach 3 Schritten: 9 offen.
  - Neu: Hinweis in der Nutzlast, kein Perzentil aus lückenhafter Historie (Testdaten erst ab 12/2022); nach „fertig“ ist es
    wieder da.
- Mutationen 23.50: 9 von 9 rot (vorhandene Tage nicht übersprungen, 404 ohne Weiterschalten, vorwärts statt rückwärts, offen um
  einen Tag daneben, Abschnitte über eine Lücke, Soll ab dem ersten Datentag, lückenhaft auch nach fertig, Perzentil trotz Lücken,
  Nutzlast ohne Archivstand). Erneut mit dem neuen Stand: die 37
  Mutationen von `hl_makro.py` und die 36 der Signale, alle rot.
- Sichtprüfung mit zwei Ständen, Handy und Desktop:
  - „Pi 16:04“: mit dem alten Code der Strich am Rand wie im Bild, mit dem neuen der Hinweis „698 von 2.091 Tagen … etwa 7,7 h“.
  - „2 h rückwärts“: das letzte Jahr ist gefüllt.
  - Zonenkarte und Tab „Daten“ zeigen den Stand. Keine Skriptfehler im Makro-Abschnitt.
- `install.py --selftest-isoliert`: 32 Schritte grün, dazu PNG und 9 Dashboard-Abrufe. Namensprüfung und `node --check` ok.

**4. Auf dem Pi.** 23.50 enthält 23.48 und 23.49.
- Nach dem Update beginnt das Archiv am Tag vor den REST-Daten und füllt rückwärts. Der Hinweis unter dem Chart zeigt den Stand.
- Bis das Archiv fertig ist, steht die OI-Zeile der Zonenkarte ohne Perzentil.
- Der FRED-Schlüssel (U124) beschleunigt nichts am Archiv. Mit 23.48 hält FRED den Takt aber nicht mehr an.

**Was man wissen muss:**
- Lange Nachladeläufe holen das Sichtbare zuerst und zeigen ihren Stand am Chart.
- Ein Perzentil kommt nur aus einer vollständigen Historie. Fehlt der größte Teil, sagt die Zahl nichts.

## 3υ. Überblick: die Reihe hinter jeder Zahl als kleiner Chart (05.10., Version 2026-09-23.51, Opus 5.5)

Anlass: Wunsch des Nutzers 05.10. 16:59: im Makro-Tab „Überblick“ zusätzlich zu den Indikatoren als Zahlen die Chart-Grafiken.

**1. Gebaut.**
- **„Verlauf je Indikator“** unter der Zonenkarte: für jede Zeile ein kleiner Chart (15 Charts; die Tage seit dem Halving haben
  keinen), im Zeitraum der Filterzeile.
  - Je Chart eine Reihe, die der Titel benennt, und eine eigene Skala. Dazu eine Bezugslinie: 1 für Verhältnisse, 0 für Abstände,
    50 für Fear & Greed.
  - Ein Punkt markiert den letzten Tagesschluss. Die Kopfzeile nennt Wert, Datum und Perzentil; unter dem Chart stehen die
    Bedeutung der Bezugslinie und die Quelle.
  - Fadenkreuz-Tooltip und Tabelle wie in den Tabs. Die Farbe folgt dem Indikator wie in seinem Tab.
- **Reihen:**
  - MVRV, Kurs ÷ Fair Value (kausal), Abstand zum 200-Wochen-MA, Kurs gegen Kurzfrist-Kostenbasis und True Market Mean, MVRV-Z,
    Puell.
  - Kurs ÷ Stromkosten, nur 4 Jahre wie bei den Signalen.
  - Hash Ribbons als SMA 30 ÷ SMA 60 − 1, mit den echten Kapitulationen als Flächen.
  - Fear & Greed (30 T), Funding (30 T), OI ÷ Marktkap., DVOL, SSR, ETF-Flüsse (30 T).
- **Nutzlast** `mini` (`hl_makro.mini_reihen`):
  - Die jüngsten 730 Tage täglich, davor jeder 7. Tag. Das sind echte Tageswerte, kein Mittel.
  - Lücken stehen als `null` drin, damit die Linie abbricht statt zu überbrücken (wichtig, solange das OI-Archiv lädt).
  - Der Überblick wächst dadurch von 245 auf 482 kB roh (73 → 122 kB gzip, Test-Datenbank).
- Solange das OI-Archiv lädt, nennt der kleine OI-Chart den Ladestand statt eines Perzentils.
- Beim Wechsel des Zeitraums wird der Überblick neu aufgebaut, damit die Überschrift den Zeitraum nennt.
- Layout: auf breiten Bildschirmen nebeneinander (bei 1280 px drei Spalten) mit gleich hohen Köpfen; auf dem Handy eine Spalte,
  der Kopf darf umbrechen.

**2. Proben.**
- `hl_makro.py --selbsttest`: 54 Prüfungen. Neu ist eine:
  - Je Zeile der Zonenkarte ein kleiner Chart.
  - Jeder Punkt ist gleich dem Wert der Reihe hinter der Zeile an diesem Tag, gegen die Ableitung nachgerechnet; der letzte Punkt
    ist gleich der Zahl der Tabelle (Tag und Wert).
  - Format: 730 Tage täglich, davor Abstand 7; eine Lücke ergibt genau ein `null`; Miner nur 4 Jahre.
- Mutationen 23.51: 8 von 8 rot. Im ersten Lauf blieb „Funding als Tageswert statt 30-Tage-Mittel“ grün: Die Testdaten haben ein
  konstantes Funding, und die Probe verglich nur den letzten Punkt. Deshalb prüft sie jetzt jeden Punkt. Die älteren Proben
  erneut: 37 von 37, 36 von 36 und 9 von 9 rot.
- Sichtprüfung Desktop und Handy:
  - Ausrichtung der Köpfe, Tooltips in drei Charts, Wechsel auf 1 J (die Überschrift folgt).
  - OI-Lücke im Stand „Pi 16:04“: die Linie bricht ab, der Kopf nennt den Ladestand.
  - Keine Seitenbreite über den Rand, keine Skriptfehler im Makro-Abschnitt.
- `install.py --selftest-isoliert`: 32 Schritte grün, dazu PNG und 9 Dashboard-Abrufe. Namensprüfung und `node --check` ok.

**Was man wissen muss:**
- Kleine Vielfache brauchen je Chart eine eigene Skala; vergleichbar ist die Form, nicht die Höhe.
- Eine Probe, die nur den letzten Punkt vergleicht, übersieht vertauschte Reihen, wenn die Testdaten konstant sind.

## 3φ. Plan U130: Makro × Kurs, vorab festgelegt (05.10., nur Dokumente, Version 2026-09-23.51 unverändert, Opus 5.5)

Anlass: Nutzer 05.10. 19:11: „Makrosignale z. B. auf täglicher Basis mit der Kursbewegung korrelieren und prüfen, wie hoch hier die
Wechselwirkung tatsächlich ist … am 25.10. auswerten. Merk es dir. Oder andere Vorschläge?“

**Festgehalten:**
- U130 im Plan, Auswertung am 25.10.
- Die Tests sind in `KONZEPT_Makro.md` Abschnitt 10 vorab festgelegt (05.10. 19:15), bevor ein Ergebnis zu sehen ist: Ziel,
  Merkmale, Maß, Nullverteilung und Schwellen. Was später dazukommt, zählt nur als neue Hypothese.

**Zwei Teile, weil die Daten verschieden alt sind:**
- **Teil A — Makro × BTC-Kurs, Tagesbasis:** 15 Merkmale gegen die Rendite VORWÄRTS über 1, 7 und 30 Tage (45 Tests).
  - Die Makro-Historie reicht bis 2010 zurück; drei Wochen mehr ändern daran wenig (meist unter 1 %, bei den ETF-Flüssen seit
    01/2024 rund 3 %).
  - Teil A ginge also sofort. Mein Vorschlag an den Nutzer: das Werkzeug vorher bauen und gleich laufen lassen; der 25.10. bleibt
    als zweiter Lauf.
- **Teil B — Makro-Regime × 4-h-Prognosen:** braucht die Hyperliquid-Daten seit Mitte September.
  - Am 25.10. ist das nur ein erster Blick: Bei rund 250 Blöcken je Coin sind Unterschiede unter etwa 12 Punkten nicht zu erkennen.
  - Belegbar ab etwa Mitte Januar 2027.

**Regeln aus der eigenen Erfahrung:**
- Nur Rendite vorwärts, nie die desselben Tags.
- Nullverteilung mit erhaltener Autokorrelation, vorher auf Zufallswegen kalibriert. Der erste Bilanz-Test in U126 irrte in 26–41 %
  der Zufallsfälle.
- Belegt nur mit Korrektur für 45 Tests UND gleichem Vorzeichen in beiden Zeithälften.

Kein Code geändert; Paket nur mit den Dokumenten neu, Version und Prüfsumme bleiben (die Prüfsumme deckt nur Code).

## 3χ. Makro × Kurs, Teil A gebaut (U130): Phasen-Null statt Verschiebung (05.10., Version 2026-09-23.52, Opus 5.5)

Anlass: Nutzer 05.10. 19:19 „Ja“ auf die Frage, das Werkzeug für Teil A (Makro gegen BTC-Kurs, ganze Historie) schon vor dem 25.10.
zu bauen. Die Tests standen seit 19:15 fest (`KONZEPT_Makro.md` Abschnitt 10, UEBERGABE 3φ).

**1. Gebaut.**
- **Modul `hl_makro_korr.py`:** 15 Makro-Merkmale am Tag t (nur Daten bis t) gegen die BTC-Rendite r(t → t+h) für h = 1, 7 und 30
  Tage, also 45 Tests.
  - Maß: Spearman ρ und ρ², dazu beschreibend die Rendite im obersten gegen das unterste Drittel.
  - Null: Phasen-Surrogate (Abschnitt 2). Benjamini-Hochberg über alle gerechneten Tests, beide Hälften (bis 2021 / ab 2022),
    Nachrechnung gegen `mk_stand`.
  - Bericht mit Zufallserwartung, nicht prüfbaren Merkmalen und Merkmalen ohne erste Hälfte.
- **Debug:** „★ Makro × Kurs (U130, Teil A)“ und „Makro × Kurs: Selbsttest“.
- **Berichte:** `u130-makro-korr` am 06.10. 20:30 (erster Lauf mit allen Quellen) und `u130-makro-korr-2510` am 25.10. 20:15.
- **Installer:** 33 Schritte (neu „Makro × Kurs“, rund 14 s in der Sandbox).
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

**2. Kalibrierung vor dem ersten Blick auf echte Daten: Der Plan nannte zwei Verfahren, beide fielen durch.**
- Gerechnet wurden 4.050 Tests auf Zufallswegen mit Volatilitäts-Clustern und unabhängigen, zähen Merkmalen (AR 0,995, Perzentil
  eines Zufallswegs, 30-Tage-Mittel).
- **Zirkuläre Verschiebung:** 1,7 % Fehlurteile bei p < 0,01 und 6,5 % bei p < 0,05; bei Perzentilen bis 2,7 % und 8,7 %.
- **Blockbootstrap mit Blocklänge h:** bis 20 % bei p < 0,05.
- **Gewählt: Phasen-Randomisierung** (Ebisuzaki 1997) mit 0,8 % und 5,4 %. Sie erfüllt das Ziel des Plans: Autokorrelation erhalten,
  rund 5 % Fehlurteile.
- Grund für das Versagen der Verschiebung: Bei zähen Merkmalen tragen wenige tiefe Frequenzen die Korrelation. Eine Verschiebung
  dreht alle Phasen nur gemeinsam, die Surrogate ziehen sie unabhängig.
- Eigener Fehler: Im Plan standen nur diese zwei Verfahren zur Wahl, und ich hatte erwartet, dass die Verschiebung besteht. Erst
  die Kalibrierung mit großer Stichprobe zeigte das Gegenteil; ein erster Lauf mit 80 Märkten schwankte zu stark für ein Urteil.

**3. Vorschau in der Sandbox** (nur die 5 Merkmale aus Coin Metrics mit echten Daten bis 23.05.2026; die übrigen Reihen der
Test-Datenbank sind synthetisch).
- 0 von 15 Tests belegt, Benjamini-Hochberg 0, unkorrigiert p < 0,10 einmal (Zufall allein ≈ 1,5).
- ρ liegt zwischen −0,10 und +0,20, ρ² ist höchstens 4,2 % (Puell, 30 Tage, p 0,32).
- MVRV, MVRV-Z, 200-Wochen-MA und Power Law drehen das Vorzeichen zwischen den Hälften.
- Puell bleibt in beiden Hälften positiv, ab 2022 aber unter 0,05.
- Der ganze Bericht über alle 45 Tests der Test-Datenbank: die synthetischen Merkmale 3 von 45 unter p < 0,10 bei 4,5 erwartet. Die
  Maschine sieht dort, wie es sein soll, nichts.

**4. Proben.**
- Selbsttest: 8 Prüfungen, rund 14 s.
  - Ränge und FFT gegen direkte Rechnung; Streuung der Phasen-Null = 1/√n.
  - Nulltest auf Zufallswegen: p < 0,05 höchstens 8 %, p < 0,01 höchstens 2,5 %.
  - Positivkontrolle (ρ ≈ 0,12): 10 von 10 Märkten erkannt.
  - Ära: Die Ganzprobe ist auffällig, die Hälften nicht.
  - Urteil braucht alle drei Bedingungen; FRED-Versatz; zu kurze Reihe; ganze Auswertung mit Nachrechnung.
- Mutationen: 11 von 11 rot.
- `install.py --selftest-isoliert`: 33 Schritte grün (neu „Makro × Kurs“, 15,1 s), dazu PNG und 9 Dashboard-Abrufe. Die
  Namensprüfung ist ohne Befund (nur `__file__`, wie in `version.py`).

**5. Auf dem Pi.**
- Debug „★ Makro × Kurs“ läuft nach dem Update sofort, rund 7 s in der Sandbox; auf dem Pi geschätzt 20–30 s.
- OI fehlt, bis das Archiv fertig ist; FRED fehlt bis zum Schlüssel. Kurzfrist-Kostenbasis, DVOL und ETF-Flüsse werden gerechnet,
  haben aber keine erste Hälfte und sind nach der Regel nie belegt.
- Bericht am 06.10. 20:30, bitte hochladen.

**Was man wissen muss:**
- Ein Verfahren, das „die Autokorrelation erhält“, ist nicht automatisch kalibriert. Nur die Zählung auf Zufallswegen entscheidet,
  und zwar mit großer Stichprobe.
- Eine Abweichung vom vorab festgelegten Plan ist erlaubt, wenn sie vor dem ersten Blick auf echte Daten fällt, das Ziel des Plans
  erfüllt und dokumentiert ist.

## 3ψ. Vorbedingungen: Rückgänge ≥ 3 % wurden zu selten erfasst (Nutzerfund 05.10. 20:42; 05.10., Version 2026-09-23.53, Opus 5.5)

Anlass: Nutzer 05.10. 20:42: „Bei dem Punkt Vorbedingungen ... vor Rückgängen > 3 % noch zu wenig Ereignisse. Es gab bereits mehrere
Rückgänge, aber es steht dort nicht einmal eine Tabelle, als hätte er die Rückgänge nicht registriert. Bitte überprüfen.“

**1. Befund.** Die Tabelle erscheint ab 3 Ereignissen je Richtung. Gezählt wurde seit 23.7 (U25) so:
- Bezugskurs war nur die erste Prognose je 4-h-Block (00, 04, 08 … Uhr UTC). Ein Rückgang zählte, wenn das Tief der folgenden
  24 h mindestens 3 % unter diesem Kurs lag.
- Ereignisblöcke wurden verkettet: Ein Ereignisblock bis 24 h nach dem VORIGEN gehörte zum selben Ereignis.
- **Fehler 1, Bezug am Blockbeginn:** Liegt das Hoch mitten im Block, erscheint der Rückgang kleiner, als er war.
  - Echte BTC-Kerzen (Crypto.com BTCUSD-PERP, 4 h, abgerufen 05.10.): 02.10. Hoch 87.238 → Tief 83.855 = −3,9 %. Vom Beginn der
    Blöcke aus nur −2,59 % (08:00) und −2,94 % (12:00), also nicht gezählt.
  - Zwischen 27.09. 12:00 und 05.10. sah kein einziger Block −3 %; der Chart zeigt in dieser Zeit −3,1 % (27./28.09.) und −3,9 %.
- **Fehler 2, Verkettung:** Getrennte Bewegungen fielen zusammen. Zwei Rückgänge mit voller Erholung 30 h auseinander zählten als
  einer, ebenso eine Treppe mit 24–36 h Pause und ein neuer Rückgang nach einer Bodenbildung.
- **Fehler 3, Anzeige:** Sie zeigte weder die gezählten Ereignisse noch den Zeitraum der Rückschau. „Noch zu wenige Ereignisse“
  stand auch dann, wenn die Zahl gereicht hätte und nur kein Treiber genug Werte hatte.
- Kein Fehler, aber jetzt sichtbar: Die Rückschau reicht nur so weit wie die Ablage (`forecast` hält 60 Tage; auf dem Pi
  Prognosen seit etwa 11.09.). Die letzten 24 h sind noch offen.
- Wirkung auf Zufallswegen (40 Läufe, 24 Tage, Tagesschwankung 2 % wie BTC zuletzt): Der Chart zeigt im Mittel 8,1 Rückgänge ≥ 3 %
  binnen 24 h (10–90 %: 5–11). Die alte Zählung fand im Mittel 4,7 (3–7), in 10 % der Läufe unter 3. Bei 3 % Tagesschwankung
  13,2 gegen 6,4.
- **Eigener Fehler:** seit 23.7 so gebaut und nie gegen den Chart geprüft. Der Nulltest prüfte nur, dass Rauschen keinen Lift
  erzeugt, nicht, ob die Ereignisse vollständig sind. Welche Zahl der Nutzer auf dem Pi sah, ist von hier nicht nachzuprüfen;
  der neue Debug-Eintrag zeigt sie (bisherige Zählung neben der neuen).

**2. Gebaut (U131, `hl_konstellation.py`).**
- **Bezugspunkte:** jede gespeicherte Prognose, die erste je 15-min-Fenster (wie beim Lernen). Kandidat ist ein Punkt, wenn der Kurs
  binnen 24 h mindestens 3 % von seinem Kurs aus lief (Hoch bzw. Tief der 1-min-Bars in (t, t + 24 h], dieselbe Fensterregel wie
  bisher).
- **Ein Ereignis = eine Bewegung** (`ereignisse()`):
  - Ein Kandidat gehört zum laufenden Ereignis, wenn zwei Dinge gelten:
    - Die Bewegung läuft noch (der Kurs war noch nicht bis auf 1,5 % an ihrem Extrem, `NAEHE_V`), oder der Kandidat läuft auf
      dasselbe Ziel zu (schon das bisherige Extrem liegt 3 % unter bzw. über seinem Kurs).
    - Seit dem Eintreten der Bewegung (erster Bar jenseits der Schwelle der Vorbedingung) hat sich der Kurs nicht um 3 %
      zurückbewegt.
  - Sonst beginnt ein neues Ereignis. Die Vorbedingung ist der früheste Punkt.
  - Das Extrem ist das tiefste Tief bzw. höchste Hoch, das die Fenster der Punkte sehen. Das „Ankommen“ mit 1,5 % Abstand macht die
    Regel unabhängig davon, wo in einer flachen Bodenzone das tiefste Tief zufällig liegt.
  - „Dasselbe Ziel“ verhindert eine Doppelzählung: Ein früher Docht kann das Ereignis zu früh „ankommen“ lassen; die Punkte danach
    zählten sonst ein zweites Mal auf dasselbe Tief (auf Zufallswegen 2 von 343 Bewegungen, mit der Regel 0 von 337).
- **Unverändert:** Basis (alle 4-h-Blöcke), Lift, z und die Konstellationen. `faelle` und Konstellationen sind bitgleich zum alten
  Stand (5 von 5 Nullszenarien).
- **Anzeige:**
  - Zeitraum der Rückschau, Zeitpunkt der Berechnung, Bezug.
  - Je Richtung die erfassten Ereignisse: Zeit, Bewegung vom Kurs der Vorbedingung, größte Bewegung eines Punkts, Tief bzw. Hoch.
  - Leer-Meldung nach Ursache: „2 von mindestens 3“ oder „kein Treiber mit Werten in mindestens 3“.
  - Ein gespeicherter Stand von vor 23.53 ist gelb markiert, bis er neu gerechnet ist (stündlich).
  - Auf dem Handy stehen die beiden Spalten untereinander.
- **Debug „★ Vorbedingungen: Ereignisliste (U131)“** (`--vorbedingungen`), je Coin:
  - die erfassten Ereignisse;
  - der Abgleich mit den Kursdaten: dieselbe Erkennung auf Hoch bzw. Tief jedes 15-min-Abschnitts, also das, was der Chart zeigt.
    Jede nicht erfasste Bewegung steht mit Grund da: „vom Prognosekurs aus höchstens −2,9 %“ (15-min-Takt), „keine Prognose
    gespeichert“ (Lücke der Ablage) oder „im benachbarten Ereignis enthalten“;
  - die bisherige Zählung (`_ereignisse_alt`, gibt exakt die alten Zahlen).
- **Berichte:** `u131-vorbedingungen` am 06.10. 20:45 (mit der Probe), dazu wöchentlich in der Wochenprüfung (W8).
- Rechenzeit `berechnen` je Coin 0,36 → 0,70 s in der Sandbox (60 Tage, Prognosen zu 8,9 kB), stündlich; auf dem Pi geschätzt das
  Zwei- bis Dreifache (nicht gemessen). Debug-Eintrag 1,6 s je Coin in der Sandbox.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.). `hl_familien` nutzt aus diesem Modul nur das 15-min-Raster der
  Ereignis-Profile (U43); das ist unverändert.

**3. Proben.**
- `hl_konstellation.py --nulltest` (Installer-Schritt) enthält die Probe `_vorbed_probe`:
  - **15 Szenarien** mit bekannter Zahl von Bewegungen: Hoch mitten im Block (und Spiegelbild), zwei Rückgänge mit Erholung, langer
    Rückgang (−8 % über 20 h), Treppe mit 36 h und mit 24 h Pause, Bodenbildung mit Docht, Lücke vor dem Tief, Lücke in der Ablage,
    Docht vorab, Zwischenerholung 2 %, Docht am Fensterende, ruhig, bekannte Grenze (Abschnitt 4).
  - Je Ereignis wird geprüft: die Zahl, die Vorbedingung in den 24 h vor der Schwelle, das angezeigte Extrem nicht vor dem Ende der
    Bewegung und nicht hinter dem Beginn des nächsten Ereignisses, und der Abgleich mit den Kursdaten (alles erfasst).
  - Die alte Zählung belegt den Fehler: Hoch mitten im Block 0 statt 1, zwei Rückgänge mit Erholung 1 statt 2, Treppe (36 h, 24 h),
    Bodenbildung, Docht und Lücke in der Ablage je 1 statt 2.
  - Extrema je Punkt gegen eine Rechnung von Hand (Python-Schleife über die Bars).
  - **Positivkontrolle des Profils:** Ein Vorläufer, eingepflanzt vor 7 Rückgängen bzw. 7 Anstiegen, steht oben mit Lift +79 pp,
    z 4,4. Die Rauschtreiber bleiben bei |z| ≤ 1,4.
  - Stabil über 12 Seeds.
- **Nulltest:** unverändert bestanden. Unter Rauschen haben die Profile |z| ≥ 2 in 4,2 % der 120 Werte (Mittel −0,03, SD 1,05,
  höchstens 3,0); gepoolt mit den Paaren |z| ≥ 3 in 0,3 % (Soll ≤ 5 %).
- **Mutationen: 14 von 17 rot.** Grün blieben drei, alle ohne Wirkung auf das Ergebnis:
  - Gegenbewegung gegen das Extrem des eigenen Bars statt des vorigen; das macht nur bei einer 1-min-Kerze mit über 3 % Spanne einen
    Unterschied.
  - „Extrem nicht nachgeführt“ und „Ankommen nicht nachgeführt“: Ein Kandidat, der auf das tiefere Extrem zuläuft, hängt über
    „dasselbe Ziel“ ohnehin an.
- **Zufallswege** (40 Läufe, 2 % Tagesschwankung, 24 Tage, beide Richtungen): 660 Bewegungen laut Kursdaten, 630 erfasst (95 %).
  - 29 der 30 nicht erfassten lagen vom Prognosekurs aus knapp unter 3 % (15-min-Takt gegen das Hoch des Abschnitts).
  - Eine wurde mit der benachbarten zusammengefasst (Abschnitt 4).
  - Rückgänge: im Mittel 7,4 Ereignisse gegen 8,1 im Chart (alt 4,7); bei 3 % Tagesschwankung 12,6 gegen 13,2 (alt 6,4).
  - Doppelt gezählt (zwei Ereignisse auf dasselbe Extrem, 20 Läufe): 0 von 337.
- Lauf auf der Demo-Datenbank: Die Anzeige des ersten von zwei Rückgängen zeigte zunächst das Tief des zweiten (ZEC, zweimal
  „Tief 18:57“). Behoben: Die Anzeige endet beim Beginn des nächsten Ereignisses. Szenario „Lücke in der Ablage“ und die
  Mutation „Anzeige wie vorher“ sichern das.
- Sichtprüfung Desktop und Handy (keine Seitenbreite über den Rand), `node --check` beider Skriptblöcke, Namensprüfung ohne Befund.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Bekannte Grenze.** Steigt der Kurs in einen Rückgang hinein und folgt binnen weniger Stunden nach einer Erholung ein tieferer,
dann erreicht die früheste Vorbedingung 3 % erst mit dem zweiten Tief. Beide zählen dann als ein Ereignis (Szenario
GRENZE_ZWEITER_TIEFER; auf Zufallswegen 1 von 660 Bewegungen). Eine Zuordnung nach dem Zeitpunkt, an dem die Schwelle reißt,
würde das lösen. Nach meiner Durchrechnung von Hand zählt sie aber einen Wiederholungstest des Tiefs (W-Boden) doppelt; deshalb
ist sie nicht gebaut.

**5. Auf dem Pi.**
- Nach dem Update rechnet das Dashboard die Vorbedingungen binnen einer Stunde neu (mit der Kalibrierung v2, stündlich je Coin).
  Bis dahin steht „Stand vor 23.53“.
- Debug „★ Vorbedingungen: Ereignisliste“ zeigt sofort, welche Rückgänge und Anstiege erfasst sind und welche nicht, mit Grund.
- Bericht am 06.10. 20:45 bitte hochladen.

**Was man wissen muss:**
- Ein Ereigniszähler wird gegen das geprüft, was der Chart zeigt. Ein Nulltest belegt nur, dass kein Scheinzusammenhang entsteht.
- Bezugspunkte in einem groben Raster verkleinern Bewegungen systematisch, weil der Rasterbeginn fast nie am Hoch liegt.
- „Zusammenfassen“ braucht eine Regel für das Ende einer Bewegung. Verketten nach Zeitabstand legt getrennte Bewegungen zusammen.

## 3ω. Makro: Kursleiste unter jedem Kennzahl-Chart (Nutzerwunsch 05.10. 22:21; 05.10., Version 2026-09-23.54, Opus 5.5)

Anlass: Nutzer 05.10. 22:21: „Kann man die Makro Charts für den korrelierenden Zeitbereich überlagern mit dem BTC Kurs (orange) um
Korrelationen zu erkennen?“

**1. Entscheidung: eigenes Feld statt zweiter y-Achse.**
- Den Kurs in dasselbe Feld zu legen, braucht eine zweite y-Achse. Deren Bereich ist frei wählbar; mit passender Wahl laufen fast
  beliebige zwei steigende Reihen im Bild gleich. Der Gleichlauf wäre dann ein Werk der Skalierung, nicht der Daten.
  `KONZEPT_Makro.md` Abschnitt 5 schließt das seit U121 aus („eine y-Achse je Chart“).
- Gebaut ist die **Kursleiste**: unter jedem Kennzahl-Chart ein eigenes Feld mit dem Kurs in BTC-Orange (#f7931a, Wunsch des
  Nutzers), eigener log. Skala, derselben Zeitachse und gemeinsamem Fadenkreuz. Der Tooltip nennt Kennzahl und Kurs am selben Tag.
  Gleichlauf, Vorlauf und Wendepunkte sind so sichtbar, ohne dass eine Skalenwahl sie erzeugt.
- **Zeitraum:** kommt nur aus den Reihen des Charts; der Kurs verlängert die Achse nie (ETF-Flüsse ab 2024, Hochzinsspread mit
  kürzerer Historie). In Signal-Charts mit Prognoseteil endet die Leiste am letzten Kurstag.
- **Keine Leiste:** Charts, die den Kurs selbst zeigen (dort bleibt er die neutrale hellgraue Linie), „Halving-Zyklen übereinander“
  (Zeitachse in Tagen nach dem Halving) und die Korrelationscharts im Tab Makro (sie zeigen die Beziehung zum Kurs schon selbst).
- **Münze:** In Bewertung und Trend mit ETH zeigen die Charts der Münze deren Kurs („Kurs ETH“), alle übrigen den BTC-Kurs.
- **Schalter „BTC-Kurs“** in der Zeitraum-Leiste: Standard an, im Browser gemerkt. Die Tabellenansicht hat eine Kursspalte.
- **Farbe:** Orange liegt außerhalb des Helligkeitsbands der dunklen Palette und nahe an #d95926 (ΔE 14,6) und #c98500 (ΔE 9,0;
  `validate_palette.js`). Deshalb steht es nur im eigenen Feld, nie in derselben Fläche wie diese Farben, und immer mit der
  Beschriftung „Kurs BTC · log. Skala“.
- **Hinweis im Überblick:** Gleichlauf im Bild ist kein Beleg. Viele Kennzahlen sind aus dem Kurs gerechnet (MVRV, Puell, Abstand
  zum 200-Wochen-MA …) und laufen deshalb mit ihm. Ob eine Kennzahl die künftige Rendite vorhersagt, misst „Makro × Kurs“ (U130).

**2. Gebaut (U132).**
- `hl_makro.py`: Die Tabs Hebel & Stimmung, Kapitalfluss und Makro tragen den Kurs jetzt als `r.P`; die übrigen hatten ihn schon.
  Je dieser drei Tabs +41,9 kB roh, gepackt +17 bis +18 kB (gzip 6; der Server packt mit Stufe 1). Die anderen fünf Tabs sind
  gleich groß wie vorher.
- `hl_makro_js.py`: `mkZeichne` zeichnet die Leiste (`mkKursReihe`, `MK_BTC`; Höhe 28 % der Charthöhe, mindestens 46 px, dazu 8 px
  Abstand), `mkTabelleHtml` mit Kursspalte, Schalter `mkKursUm`, `kurs` in 26 Chart-Definitionen.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.).

**3. Proben.**
- **Makro-Selbsttest** (Installer-Schritt), neue Prüfung „Kursleiste“: Jede Nutzlast eines Chart-Tabs trägt den Kurs. JEDER Punkt
  und jede Lücke ist gleich der Ableitung am selben Tag, Anfang und Ende eingeschlossen (BTC in 8 Tabs, dazu Bewertung und Trend
  mit ETH: Kurs ETH). 10 Nutzlasten; der Selbsttest hat jetzt 55 Prüfungen, rund 10 s.
  - Mutationen 6 von 7 rot: Hebel ohne Kurs, Kurs einen Tag versetzt, 30 Tage zu früh zu Ende, grob gerundet, ETH-Charts mit
    BTC-Kurs (Trend, Bewertung). Grün blieb „Lücken gefüllt“: Der Testkurs hat keine Lücke, die Mutation wirkt dort nicht.
  - **Eigener Fehler, vor der Lieferung behoben:** Die Prüfung sah zuerst nur den Anfang der Reihe, nicht das Ende. Eine 30 Tage zu
    früh endende Kursreihe wäre durchgegangen; das zeigte erst die Mutationsliste.
- **Browserprobe** (Playwright gegen ein Dashboard mit Testdaten, Desktop 1280 px und Handy 390 px; Werkzeug der Sandbox, nicht im
  Paket):
  - Leisten je Tab: Überblick 15 von 16 Charts, Bewertung 5/6, Trend 4/7, Kohorten 7/8, Miner 7/8, Hebel 5/5, Kapitalfluss 4/4,
    Makro 7/14 (die 7 Korrelationscharts ohne). Kein Chart hat Kurslinie und Leiste zugleich.
  - **Gegen Quellen außerhalb des Browser-Codes**, an 54 Fadenkreuz-Stellen in 6 Tab/Münz-Kombinationen (Überblick, Hebel, Trend,
    Makro, Bewertung ETH, Trend ETH):
    - Der Tooltip-Kurs ist der Rohwert in `makro.db` am Tooltip-Tag (Toleranz eine Einheit der 5. Stelle, so rundet die Nutzlast).
    - Die Höhe des Leistenpfads am Fadenkreuz ist der Rohkurs auf der beschrifteten log. Skala (Fit durch die
      Achsenbeschriftungen, Abweichung höchstens 0,6 px). Das prüft gemeinsame Zeitachse und Skala zugleich.
  - Schalter: aus → keine Leiste, Charts niedriger (Hebel 264 → 200 px), nach Neuladen weiter aus; an → wieder da. Tabelle mit
    Spalte „Kurs BTC“. Keine Seitenbreite über den Rand, keine Skriptfehler.
  - Mutationen im Browser 8 von 8 rot: Pfad 30 Tage versetzt, eigene Zeitachse aus der ganzen Kurshistorie, Achsenbeschriftung ×2,
    Tooltip ohne Kurs, Kursreihe einen Tag versetzt, Name immer „Kurs BTC“, Schalter nicht gemerkt, Schalter ohne Neuzeichnen.
  - Zwei Fehler der Probe selbst, behoben: Der Filter „Chart zeigt den Kurs“ (/^Kurs/) griff auch bei „Kurs ÷ Stromkosten“. Und im
    Prognoseteil der Signal-Charts gibt es keinen Kurs; dort darf der Tooltip keinen zeigen, das ist jetzt die Regel der Probe.
  - Sichtprüfung der Bilder (Hebel Desktop und Handy, Überblick, Makro): Die unterste Beschriftung des Charts und die oberste der
    Leiste stehen getrennt, die Leiste ist beschriftet.
- `node --check` (`hl_makro_js.MAKRO_JS`), Namensprüfung ohne Befund.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Auf dem Pi.** Nach dem Update sofort sichtbar; die Daten liegen schon in `makro.db`, nichts wird neu gerechnet. Der Schalter
„BTC-Kurs“ blendet die Leisten aus.

**Was man wissen muss:**
- Zwei Reihen verschiedener Einheit nie über zwei y-Achsen in ein Feld. Getrennte Felder auf gemeinsamer Zeitachse zeigen
  Gleichlauf, Vorlauf und Wendepunkte, ohne dass eine Skalenwahl die Korrelation erzeugt.
- Bei Kennzahlen aus dem Kurs ist Gleichlauf mechanisch. Ob eine Kennzahl etwas vorhersagt, zeigt nur die Rendite danach (U130).
- Eine Probe der Anzeige vergleicht mit Quellen außerhalb des geprüften Codes: Rohdaten aus der Datenbank, Geometrie aus der
  Beschriftung. Sollwerte aus denselben JS-Funktionen bestätigen nur sich selbst.
- Eine Reihenprüfung prüft Anfang UND Ende; „jeder Punkt gleich“ über die gelieferten Punkte übersieht eine verkürzte Reihe.

## 3αα. Treiber-Hygiene: „tot“ war bei Ereignis- und jungen Treibern falsch (Nutzerfund 05.10. 23:18; 05.10., Version 2026-09-23.55, Opus 5.5)

Anlass: Nutzer 05.10. 23:18 mit zwei Fotos (BTC: Treibertabelle und aufgeklappte Hygiene „12 von 34 auffällig“): „Bei Treiber
Hygiene stehen viele Treiber als ohne Event …, aber das stimmt nicht, sie sind nur gerade in diesem Moment nicht aktiv oder haben
wenige Events.“ (Abschnitte nach 3ω laufen mit doppelten griechischen Buchstaben weiter, wie nach 3z die doppelten lateinischen.)

**1. Befund.**
- Die Hygiene (`hl_familien.hygiene`, seit 23.25, U62) bewertet nicht den Moment, sondern den ganzen Zeitraum der Familien (auf
  dem Pi Prognosen seit etwa 11.09., rund 24 Tage). „tot“ hieß ein Treiber, wenn eine von drei Regeln griff:
  - weniger als 20 % der 15-min-Punkte mit Wert;
  - weniger als 8 Blöcke im Zeitraum;
  - Streuung des Werts unter 0,02.
- Inaktive Treiber werden nicht gespeichert: `forecast_drivers` erhält nur die aktiven, die Tabelle zeigt die übrigen mit „kein
  Ereignis“. Die 20-%-Regel traf deshalb genau die Ereignis-Treiber. Auf dem Foto: Kapitulation 2 %, Vol-Spike-Reversion 6 %,
  Crowding-Extrem 7 %, Liquidationsdruck 9 %, OI-Überhitzung 10 %.
- Dazu Treiber, die erst seit Kurzem rechnen:
  - Crowding-Trend 7 T, 14 %: braucht 21 Tage `lb_trend`, also Werte ungefähr ab 02.10.
  - Kaskaden-Asymmetrie, 7 %: auf dem Pi seit 04.10. abends (23.46).
- Funding hat immer einen Wert (100 %), aber fast immer ±0,00. Der Score sättigt erst bei 0,02 %/h Prämie, das ist die
  Streuungs-Regel.
- Gemessen wurde zudem nur an festen Blockanfängen. Ein Ereignis-Treiber, der zwei Stunden aktiv ist, fiel meist zwischen zwei
  Anfänge.
- Wirkung: nur Anzeige und Debug-Bericht. Familienwerte, Darwin-Stufen, Fusion und v3 lesen die Hygiene nicht.
  - Das Wort wurde aber benutzt: Am 30.09. (3θ) hieß die Elite-Positionierung „tot“ (damals unter 20 % Werte), ein Grund für U97.
  - Die Pi-Berichte vom 30.09. zeigen „tot“ auch bei MA 200 Tage, MA 50 Wochen, Smart-Flow, Wal-Flow, Leaderboard-Flow und den
    Pool-Treibern.
- **Eigener Fehler:** seit 23.25 so gebaut. Der Selbsttest prüfte „nachlaufend“ und „umgekehrt?“ nur mit Treibern, die immer einen
  Wert haben, nie mit einem Ereignis-Treiber.

**2. Gebaut (U133, `hl_familien.py`, Anzeige in `hl_viz.py`).**
- **Fälle** (`_hyg_faelle`): Zeitpunkte MIT Wert im Abstand von mindestens einem Horizont, davor und danach je ein ganzes Fenster.
  - Ein Treiber mit Wert an jedem Punkt bekommt genau die Blockanfänge wie bisher.
  - Ereignis- und junge Treiber werden an ihren aktiven Zeiten gemessen. Die Fenster überlappen nie.
- Ab 8 Fällen wird bewertet wie bisher: nachlaufend, umgekehrt? oder ok.
- **„kein Urteil“ statt „tot“**, immer mit Grund. Es ist kein Befund gegen den Treiber.
  - „Ereignis-Treiber: 3 Fälle (8 nötig), aktiv 2 % der Zeit“
  - „Werte erst seit 1,7 Tagen: 6 Fälle (8 nötig)“
  - „nur zeitweise aktiv (… % der Zeit): … Fälle“
  - „Wert bewegt sich kaum: Streuung 0,003, größter Betrag 0,01“
  - „bei jedem Fall derselbe Wert (+0,80) … die Richtung zeigt die Trefferquote in der Treibertabelle“: Kapitulation liefert
    nur ±0,8, ein Zusammenhang braucht verschiedene Werte.
- **Neu in der Tabelle:**
  - Spalten „Fälle“, „aktiv“ (Anteil der Zeit mit Wert) und „zuletzt“ (letzter Zeitpunkt mit Wert); Marke „· Ereignis“.
  - Unter jedem r sein 95-%-Intervall (Fisher-z). Bei 10 Fällen liegt auch r = 0,61 noch im Zufall (−0,03 … 0,90).
  - Die Befund-Spalte bricht um, damit die Zahlenspalten sichtbar bleiben.
- **Kopfzeile:** „auffällig“ zählt nur nachlaufend und umgekehrt?, daneben „… ohne Urteil“ und „… ausgeschlossen“.
- **Debug-Bericht `familien`:** eine eigene Zeile „Ohne Urteil (kein Befund gegen den Treiber)“.
- Fusion, v3 und Kaskaden sind unberührt (Zusage bis 25.10.); sie lesen aus `hl_familien` nur `FAMILIEN`.

**3. Proben.**
- **Selbsttest `hl_familien.py --nulltest`** (Installer-Schritt): 22 Prüfungen statt 9.
  - Die neuen Testreihen kommen aus einem eigenen Zufallsstrom; die übrigen Reihen sind bitgleich zum bisherigen Selbsttest.
  - Der Fund ist nachgestellt: Die Regel bis 23.54 nennt alle sieben eingebauten Fälle „tot“.
  - Positivkontrolle: Liquidationsdruck in Schüben (12 % aktiv), kennt die kommenden 4 h. Er wird bewertet, Zukunft r +0,91 bei 24
    Fällen.
  - Ein Ereignis-Treiber gegen die vergangene Stunde (Vol-Spike-Reversion) fällt als „nachlaufend“ auf (r −0,77, 90 Fälle).
  - Ereignis-Rauschen bleibt unauffällig. Ein junger Treiber mit 5 Tagen wird bewertet (29 Fälle).
  - „kein Urteil“ mit dem richtigen Grund: 1 Tag („erst seit 1,0 Tagen“), Funding fast ohne Ausschlag („bewegt sich kaum“),
    immer derselbe Wert („derselbe Wert“) und 3 kurze Schübe („Ereignis-Treiber: 3 Fälle“).
  - Die 27 Treiber mit Wert an jedem Punkt sind in Befund, r und n bitgleich zur Regel bis 23.54. Die alte Regel bleibt dafür als
    `_hygiene_bis_23_54` im Modul.
  - Zeitpunkte „zuletzt“ und „erster Wert“, das Intervall exakt, der Bericht trennt „ohne Urteil“.
  - Über 12 Seeds besteht alles Neue. Bei Seed 4 fällt die ältere Prüfung „ETF (reines Rauschen) ohne Beleg“ mit z −3,2; das tat
    sie schon mit 23.54, unberührt von dieser Änderung (der Installer nutzt Seed 5).
- **Mutationen: 14 von 14 rot.** Dazu gehören: 20-%-Regel zurück, feste Blockanfänge, überlappende Fenster, ohne Streuungsprüfung,
  kein „erst seit“, kein Ereignis-Grund, „zuletzt“ verschoben, Bericht zählt „kein Urteil“ als auffällig, Mindestfälle 3, ohne
  Zeitbezug, Ereignis-Marke falsch, „derselbe Wert“ nie, Intervall mit 1/√n, Intervall fehlt.
- **Nullsimulation:** 2.000 Läufe je Art, Kurs mit Schwankungsclustern, Werte unabhängig vom Kurs.
  - Fehlalarme (nachlaufend oder umgekehrt?) je Art 0,00–0,35 %. Dauer-Treiber 0,30 % (95 %: 0,14–0,65 %), also wie bisher.
  - Schübe 0,00–0,30 %, Schübe nur bei hoher Schwankung 0,20 %, junge Treiber 0,10 %.
  - Das 95-%-Intervall enthält die 0 in 94,1–95,9 % der Fälle.
- **Sichtprobe** mit Pi-ähnlichen Testdaten: 24,5 Tage, Ereignis-Treiber 2–10 % aktiv, Crowding-Trend seit 3,5 Tagen, Kaskaden seit
  1,7 Tagen, Funding fast 0.
  - Kopf „2 von 34 auffällig (60-min-Trend, RSI) · 2 ohne Urteil · 1 ausgeschlossen“.
  - Bewertet: OI-Überhitzung (12 Fälle), Crowding-Extrem (10), Liquidationsdruck (19), Vol-Spike-Reversion (46), Crowding-Trend
    (20), Kaskaden (10). Ohne Urteil: Kapitulation (immer +0,8) und Funding.
  - Desktop und Handy ohne Seitenbreite über den Rand; die Tabelle scrollt am Handy in sich. Keine Skriptfehler, `node --check`
    beider Skriptblöcke, Namensprüfung ohne Befund.
- Rechenzeit der Hygiene 24 → 60 ms je Coin (24,5 Tage, Sandbox); der Bericht liegt 10 min im Zwischenspeicher.
- `install.py --selftest-isoliert`: 33 Schritte grün, dazu PNG und 9 Dashboard-Abrufe (siehe Paketprüfung).

**4. Auf dem Pi.** Die Anzeige rechnet beim nächsten Abruf neu (höchstens 10 min Zwischenspeicher). Nach den Prozentzahlen auf dem
Foto werden die meisten bisherigen „tot“ voraussichtlich mit 10 bis 50 Fällen bewertet, mit breiten Intervallen. Das ist geschätzt,
nicht gemessen. Kapitulation (2 %) und Funding werden wohl „kein Urteil“ zeigen.

**Was man wissen muss:**
- Bei Ereignis-Treibern heißt „kein Wert“ „kein Ereignis“, nicht „kaputt“. Eine Prüfung, die Anteile zählt, muss das wissen.
- Ein Treiber wird an seinen aktiven Zeiten gemessen, nicht an einem festen Raster, in das er selten fällt.
- Bei wenigen Fällen gehört das Intervall neben r; ein r von 0,6 aus 10 Fällen ist oft Zufall.
- Ein Befundwort wird gelesen und benutzt (30.09. Elite). Deshalb nur Wörter, die die Messung trägt.

## 3ββ. Bewertung: Warum v1 kaum lernt und welcher Weg sinnvoll ist (06.10., nur Dokumente, Version 2026-09-23.55 unverändert, Opus 5.5)

Anlass: Nutzer 06.10. 00:51 (Kachel „Gelernte Gewichte 3 von 33“): „Warum bisher nur 3 von 33 gelernt? Wie viele Events sind
nötig?“ Dann 01:02: „Evaluiere gründlich, was der sinnvollste Lösungsweg wäre.“

**1. Befund im Code (Stand 23.55).**
- v1 (`hl_forecast.calibrate_weights`, 4 h) lernt nur in einem begrenzten Fenster und nur unter Auflagen:
  - Fenster: die jüngsten 2.000 Prognosen à 15 min, das sind rund 21 Tage (auf dem Pi 136 Blöcke). Halbwertszeit 14 Tage.
  - Ein Treiber verlässt seinen Prior erst ab 50 eigenen aktiven 4-h-Blöcken (|Score| > 0,05).
  - L2-Zug zum Prior mit λ = 4/n_eff; Gewichte nur in [0, 2 × Prior].
  - Logit = β · Σ w·x / 18,6 (Summe der Priors); β ist am Wert 1 verankert.
- Die Kachel zählt Abweichungen über 0,02, die Tabelle schreibt „gelernt“ schon ab 10⁻⁹. Die beiden Anzeigen passen nicht
  zusammen.
- Gespeichert wird stündlich. Eine neue „Version“ gibt es erst bei einer Änderung über 0,10. „Version 25.09.“ ist also kein
  Stillstand.
- **Ereignis-Treiber** erreichen im 21-Tage-Fenster nie 50 Blöcke. Pi-Foto: Kapitulation 9, OI-Überhitzung 18, Liquidationsdruck
  18, Crowding-Extrem 12, Funding 5, Vol-Spike-Reversion 1.
- Pool-Treiber und Coinbase-Prämie haben den Prior 0 und können nicht lernen.
- Nenner Prior-Summe, β und Klemmung auf 2 × Prior hatte schon der K2-Neubau (23.09., `hl_kalib`) als Ursachen benannt. Deshalb
  gibt es v2.

**2. Messung: Simulation mit genau der v1-Rechnung** (Sandbox, Skripte nicht im Paket).
- Der Optimierungsteil ist nach numpy übertragen und gegen die Python-Schleife geprüft: größte Abweichung 6 · 10⁻¹⁷, β gleich.
- Markt: Zufallsweg auf 15 min mit Schwankungsclustern, 60 Tage Lernen, danach 15 Tage ungesehen. 33 Treiber mit den echten Priors
  und Aktivitätsmustern wie auf dem Pi (Dauer-, Teilzeit- und Ereignis-Treiber, Funding fast 0). 30 Läufe je Fall.
- Varianten:
  - A: wie heute;
  - B: ein Fenster je Stunde über 60 Tage;
  - C: wie B, Halbwertszeit 30 Tage;
  - D: wie A, Schwelle 15 Blöcke;
  - E: wie B, Schwelle 15 Blöcke.
- Gewinn = Log-Verlust je 4-h-Block in den ungesehenen Tagen, in Tausendstel nats, negativ = besser.

  | | A | B | C | D | E |
  |---|---|---|---|---|---|
  | kein Signal: Rauschtreiber über 0,02 je Lauf | 0,7 | 4,0 | 2,8 | 0,7 | 4,1 |
  | kein Signal: größte Rauschabweichung | 0,020 | 0,038 | 0,030 | 0,020 | 0,038 |
  | Dauertreiber 60 % (RSI): Gewicht über Prior | +0,029 | +0,084 | +0,083 | +0,029 | +0,084 |
  | Dauertreiber 60 %: Gewinn gegen die Priors | −0,05 ± 0,01 | −0,16 ± 0,03 | −0,14 ± 0,02 | −0,05 ± 0,01 | −0,16 ± 0,03 |
  | Dauertreiber 55 %: Gewicht über Prior | +0,015 | +0,041 | +0,040 | +0,015 | +0,041 |
  | Ereignis-Treiber 60 % (OI-artig, 10 % aktiv): Gewicht über Prior | 0,000 | +0,001 | +0,001 | +0,002 | +0,008 |

- **Ein frei gewichtetes Modell** (1-D-Logit) auf demselben 60-%-Treiber gewinnt −21,2 ± 4,5 gegen 50 %, v1 in der besten
  Variante −1,2 ± 0,5. v1 nutzt also rund 6 % eines starken Vorsprungs. Das liegt an der Struktur, nicht an Schwelle oder Fenster.
- **Mehr Daten, mehr Schein:** Unter reinem Rauschen weichen in B viermal so viele Treiber über 0,02 ab wie in A. „Gelernt“ ist
  kein Beleg.
- **Teststärke** (80 %, α 5 %, zweiseitig): kleinster erkennbarer Vorsprung bei 50 Blöcken 19,8 pp, bei 136 Blöcken 12,0 pp, bei
  360 Blöcken 7,4 pp, bei 1.000 Blöcken 4,4 pp.
  - Für 15 pp braucht ein Treiber rund 87 Ereignisse, für 10 pp 196.
  - Pi-Raten je 30 Tage: Kapitulation ~12, OI und Liquidationsdruck je ~24, Crowding-Extrem ~16. Das sind 4–7 Monate (15 pp) bzw.
    8–16 Monate (10 pp).
- **Ereignis-Treiber als schlafender Experte in der Fusion** (`hl_fusion.Mischung` unverändert benutzt).
  - Aufbau: wach nur im Ereignis; Trefferquote der bisherigen Ereignisse mit 20 Pseudo-Fällen zu 50 % geschrumpft; 120 Tage, 400
    Läufe.
  - Mischung minus Basisrate je Block über alle Blöcke: −0,09 ± 0,04 ohne Signal (kein Schaden), −0,26 ± 0,05 bei 55 %, −0,98 ±
    0,09 bei 60 %, −2,28 ± 0,13 bei 65 %.
  - Garantie der Mischung: höchstens ln 2 über ALLE Runden schlechter als der beste Experte.

**3. Bewertung der Wege.**
- **Schwellen senken (D, E): verworfen.** Kein Gewinn, auch nicht bei eingebautem 60-%-Ereignisvorsprung. Unter Rauschen bewegen sich
  mehr Gewichte scheinbar.
- **Fenster je Stunde und 60 Tage (B, C): verworfen für v1.** Das Signal-Gewicht verdreifacht sich, der Prognosegewinn bleibt
  winzig (−0,16 statt −0,05). Unter Rauschen gibt es viermal so viele scheinbar gelernte Treiber.
- **v1 umbauen (Nenner, Klemmung, β): verworfen.** Das wäre v2. v2 gibt es schon, mit Kreuzvalidierung und Positivkontrolle
  (Kante 0,65 → p in [0,60; 0,70]).
- **Sinnvoll:**
  - jetzt nur die Anzeige ehrlich machen;
  - am 25.10. die geplante Modellwahl (U108, U7b);
  - danach Lernen dort, wo es frei ist und eine Garantie hat: Ereignis-Experten und „v3 mit langem Gedächtnis“ in der Fusion.

**4. Empfohlener Weg (U134, Entscheidung beim Nutzer).**
1. **Jetzt, nur Anzeige, keine Zahl der Prognose ändert sich:**
   - „gelernt“ in Tabelle und Kachel nach derselben Regel (Abweichung über 0,02);
   - je Treiber der Lernstatus: „Prior: n_eff 9 von 50“, „Ereignis-Treiber: im Lernfenster nicht erreichbar“ oder „angepasst, ohne
     Beleg“ bzw. „mit Beleg (Lift-z ≥ 2)“;
   - Hinweis in der Kachel: v1 bildet einzelne Vorsprünge kaum ab, frei lernen v2 und die Fusion.
   - **Entscheidung des Nutzers 06.10. 01:21:** nicht vorab bauen, sondern zusammen mit Schritt 3 („es ist ja nur die Anzeige, lass
     es uns anpassen, wenn die richtigen Änderungen anstehen“).
2. **25.10. wie geplant (U108, U7b):** Fusion bzw. v2 nach den vorab festgelegten Kriterien. v1 bleibt einer von mehreren Experten.
3. **Nach dem 25.10. in der Fusion** (die Zusage bis 25.10. bleibt unberührt):
   - a) Ereignis-Experten wie oben, je Treiber oder je Familie „Stärke“; nur Richtung, wenn der Treiber ein Vorzeichen hat;
   - b) „v3 mit langem Gedächtnis“ (steht schon in `KONZEPT_Fusion.md` 5: 90 Tage ohne Halbwertszeit, n_eff 540 statt 237).
   - Für beides vorab festlegen: Nulltest (Rauschen: Mischung nicht schlechter als die Basisrate um mehr als die Garantie),
     Positivkontrolle (eingebauter 60-%-Vorsprung wird gefunden), Bewertung nach 60 Tagen live.
4. **v1-Lernen bleibt unverändert.** Kein Umbau eines Modells, das am 25.10. zur Wahl steht.
5. **Erwartung:** Auf echten Daten fand bisher kein Verfahren einen 4-h-Richtungsvorsprung (v2 und v3: Kalibrierfaktor c 0, also
   Basisrate; Fusion gegen Basisrate −0,0020 ± 0,0112). Die Schritte nutzen einen Vorsprung, sobald es ihn gibt. Sie erzeugen keinen.

**Was man wissen muss:**
- „Gelernt“ misst Bewegung, nicht Beleg. Mit mehr Daten bewegen sich auch Rauschgewichte mehr.
- Ein Modell, das Signale durch eine feste Summe teilt und Gewichte klemmt, kann einen starken Einzeltreiber nicht ausdrücken.
  Mehr Daten ändern daran nichts.
- Seltene Ereignisse lernt man nicht mit einer Mindestzahl im kurzen Fenster. Man gibt ihnen eine Stimme nur dann, wenn sie wach
  sind (schlafende Experten), und lässt die Mischung über ihren Wert entscheiden.

## 3γγ. Auswertung der Berichte vom 06.10.: erste Pi-Läufe Makro × Kurs und Vorbedingungen (06.10., nur Dokumente, Version 2026-09-23.55 unverändert, Opus 5.5)

Anlass: Nutzer 06.10. 21:11 lädt die Sammeldatei der geplanten Berichte hoch (letzte 24 h, 10 Berichte, Pi auf 23.55 · c442f4d455).
Neu darin: Makro-Stand und Makro-Selbsttest 20:15, Makro × Kurs 20:30 (U130 Teil A, erster Lauf mit allen Quellen), Konstellation
und Vorbedingungen 20:45 (U131, erster geplanter Bericht), Aktive Profis 19:00.

**1. Betrieb.** Alle 10 Berichte Exit 0.
- Makro-Selbsttest 55 von 55 (9,1 s). Konstellations-Nulltest samt Probe U131 bestanden; er ist deterministisch (feste Szenarien,
  fester Zeitpunkt) und bestätigt nur, dass sich nichts verändert hat.
- Makro-Stand: 51 von 51 Reihen frisch, FRED über die API 12 von 12, OI-Archiv 2.227 von 2.227 Tagen, BGeometrics 8 von 14 am
  Tag. Archiv `mk_stand` seit 05.10. (2 Tage).

**2. Makro × Kurs (U130 Teil A), BTC-Tagesschluss bis 05.10.**
- 0 von 45 Tests belegt; Benjamini-Hochberg allein 0; unkorrigiert p < 0,10: 3 (Zufall allein ≈ 4,5). Wie die Vorschau in der
  Sandbox (0 von 15; Puell 30 T ρ² 4,2 %, p 0,32).
- Größte erklärte Streuung: Puell 30 T, ρ +0,20 [90 %: −0,09; +0,49], ρ² 4,1 %, p 0,33. Kleinste p: Nettoliquidität 1 T 0,020,
  Puell 1 T 0,026, Nettoliquidität 7 T 0,047. Benjamini-Hochberg verlangt beim kleinsten p höchstens 0,10/45 = 0,0022.
- Gleichsinnig in beiden Hälften mit |ρ| ≥ 0,05, aber weit weg von BH: u. a. Puell 30 T (+0,24/+0,08), Nettoliquidität 30 T
  (+0,07/+0,10), Power Law 30 T (−0,08/−0,23), OI ÷ Marktkap. 30 T (−0,10/−0,07). Nach Abschnitt 10 nur Hypothesen für eine
  neue, eigene Runde.
- Teststärke: Das 90-%-Band der Phasen-Null ist bei h = 1 rund ±0,03 bis ±0,09 breit, bei h = 30 für zähe Merkmale ±0,16 bis
  ±0,36 (16 Jahre sind wenige unabhängige Zyklen). Bei 30 Tagen wären nur sehr starke Zusammenhänge belegbar; „nicht belegt“
  heißt dort auch „kaum messbar“.
- 25.10.: Die Historie wächst bis dahin um 19 Tage (lange Reihen unter 0,5 %, ETF-Flüsse rund 2 %). Dasselbe Urteil ist zu
  erwarten; Neues bringt Teil B.
- Die Spalte „Drittel“ (z. B. Puell 30 T +13,9 %) ist beschreibend. Überschlag: 30-Tage-Renditen streuen um 25–35 %, rund 60
  unabhängige Monate je Drittel → ±9 bis ±12 Punkte (95 %), ohne die Zähigkeit des Merkmals. Kein Beleg.
- **Nachrechnung gegen `mk_stand`: DVOL 2 von 2 und ETF-Fluss 2 von 2 abweichend, die übrigen 10 Merkmale (20 Werte) gleich.**
  Ursache, kein Rechenfehler:
  - Der Makro-Takt schreibt die Zonenkarte beim ersten Rechnen jedes UTC-Tags fest (`archivieren`, `INSERT OR IGNORE`).
  - DVOL trägt dann eine noch offene Tageskerze (Abruf alle 12 h).
  - Der 30-Tage-ETF-Fluss ist eine Kalendersumme bis heute (`summe_fenster`, fehlende Tage = 0). Die Flüsse eines Handelstags
    erscheinen erst nach US-Schluss (Abruf alle 12 h).
  - Beispiel 05.10.: DVOL 35,97 festgeschrieben, Tagesschluss 36,10; ETF 2.170,3 → 2.080,5 Mio USD (die Differenz −89,8 Mio ist
    vermutlich der Fluss vom Montag 05.10.).
  - Genau die beiden Merkmale, deren Wert am offenen Tag entsteht, weichen ab. Nicht betroffen: Fear & Greed (ein Wert je Tag),
    Funding (nur abgeschlossene Tage), OI (00:00-Stand), die Coin-Metrics-Merkmale (erscheinen 1–2 Tage später, dann endgültig).
  - Folge für das Urteil: keine. DVOL und ETF haben keine erste Hälfte und sind nach der Regel nie belegt. Der Bericht schreibt
    trotzdem „ABWEICHEND“ → U135 (2).

**3. Signale (U126) im Makro-Stand.**
- Belegt 4 von 336 Tests: Power Law 4 J und 8 J Kauf 90 T (+53 % bzw. +51 %, p 0,012/0,018, 8 bzw. 6 Episoden); XMR 200-W-MA
  8 J und alles Verkauf 90 T (−21 %, p 0,012/0,013, 4 Episoden). Nach der Kalibrierung (9.4: 3–5 % Fehlurteile je Test) liefert
  Zufall allein rund 11–17. Als Ganzes trägt die Bilanz keinen Beleg, wie 9.5 auf der Test-Kopie (3 von 322).
- Live „Verkauf“: Kurzfrist-Kostenbasis 1 J (seit 19.08.), Puell 1 J/2 J (seit 04./05.10.), ZEC Realized Price 2/4/8 J/alles und
  200-W-MA 2/4 J/alles, XMR 200-W-MA alle Zeiträume. Belegt davon nur XMR 8 J/alles (4 Episoden).
- Puell: Halbwertszeit der Abweichung 3–6 Tage (1 J/2 J), 0 von 6 Tests belegt. In U130 geht ein hohes Puell-Perzentil eher mit
  HÖHEREN Folgerenditen einher (ρ +0,08/+0,14/+0,20, nicht belegt). Das passt zu 9.5: Nach Verkaufssignalen lag die Rendite im
  Median über den Zufallstagen (Momentum).
- ZEC: Das 365-T-Band traf im Rückblick 0 % (4 J) bzw. 51 % (2 J) statt 80 %. ZEC liegt bei Perzentil 96–98 seiner Historie;
  die Fehler früherer Ursprünge beschreiben das nicht. Die ZEC-Bänder sind nicht verwendbar.
- Live gegen Nachrechnung der Signale: 64 von 64 gleich (Coin Metrics und BGeometrics sind am Datentag schon endgültig, anders
  als DVOL und ETF oben).

**4. Vorbedingungen (U131), erster geplanter Bericht (Rückschau 11.09.–05.10., 149 Blöcke Basis).**

| Coin | Rückgänge (bisher) | Kursdaten erfasst | Anstiege (bisher) | Kursdaten erfasst |
|---|---|---|---|---|
| BTC | 3 (2) | 4 von 5 | 6 (6) | 6 von 6 |
| ETH | 8 (4) | 8 von 9 | 9 (7) | 10 von 12 |
| HYPE | 15 (7) | 16 von 16 | 16 (7) | 17 von 20 |
| PAXG | 1 (1) | 1 von 1 | 0 (0) | 0 von 1 |
| XMR | 18 (5) | 20 von 21 | 17 (6) | 19 von 22 |
| ZEC | 32 (6) | 38 von 43 | 34 (4) | 42 von 49 |
| zusammen | 77 (25) | 87 von 95 (92 %) | 82 (30) | 94 von 110 (85 %) |

- Von 24 nicht erfassten Kursdaten-Bewegungen liegen 10 im benachbarten, schon gezählten Ereignis. Bei 14 sah kein
  Prognosepunkt binnen 24 h 3 %; 11 davon zwischen 2,5 und 3,0 % (Schwellenrand des 15-min-Takts, Abschnitt W8). Keine
  Ablage-Lücke („keine Prognose gespeichert“ kommt nicht vor).
- Gemeinsame Marktbewegungen zählen in mehreren Coins (14.09. 16:16 in BTC, ETH und HYPE; Tief 28.09. 16:53 in BTC, HYPE und
  XMR). Über Coins gepoolt sind die Fälle nicht unabhängig.
- BTC: 3 Rückgänge und 6 Anstiege in 24 Tagen. Das Vorbedingungen-Profil erscheint ab 3 Ereignissen (`vorbedingungen`); bei 3
  Fällen verschiebt ein Fall den Anteil um 33 Punkte, ein Lift sagt dann nichts. Für 15 Punkte braucht es, wie in U134 gerechnet,
  rund 90 Ereignisse.
- **Eigener Fehler (23.53):** Die Begründung „vom Prognosekurs aus höchstens …“ misst nur die Prognosepunkte der 24 h VOR dem
  Extrem der Kursdaten-Bewegung (`_abgleich`: `k1 − 24 h ≤ ts < k1`). Bei langen Bewegungen sagt sie nicht, wie nah die
  Prognosepunkte zu Beginn an der Schwelle lagen. BTC 11.09. 15:59 → Tief 14.09. 02:29 (58 h, −4,4 %) zeigt „höchstens −1,3 %“;
  das ist nur der Weg ab 13.09. 02:29. Richtig: je Prognosepunkt ab Beginn der Bewegung die eigene 24-h-Bewegung (`ext_*` gegen
  `p0`), davon die größte. Zählung, Ereignisliste und Profile sind nicht betroffen, nur die Begründungszeile → U135 (1).
- Anzeige: „… und N frühere“ steht unter den 15 jüngsten Ereignissen (Liste aufsteigend), gehört darüber → U135 (3).

**5. Treiberfamilien (U133) auf dem Pi** (manueller Lauf 17:14): wie erwartet. Ereignis-Treiber „kein Urteil“ mit Fallzahl (ETH
Kapitulation 7 von 8 nötig, HYPE Crowding-Extrem 5, Vol-Spike-Reversion 5), junge Treiber mit Alter (XMR Pool-Flow 4 h seit 10,9
Tagen), das ruhige Funding „bewegt sich kaum“, MA 200 T und MA 50 W „derselbe Wert“. Auffällig sind nur nachlaufende Treiber
(u. a. 60-min-Trend, RSI 14, Liquidationsdruck, Taker-Flow).

**6. Aktive Profis (19:00).** Darwin-Liste 1 Konto (x.com/SilkBtc, streng seit 30.09., 11 von 16 richtig gegen Zufall 32 %, Glück
0,2 %), keine Zu- oder Abgänge seit 30.09. Nächster Kandidat 0x926a…af36 (Glück 1,4 %, Aufnahme ≤ 1 %). Die Labor-Vorlagen
„Darwin-Liste live folgen“ und „Gegen die Darwin-Liste“ hängen damit an einem einzigen Konto. Die Gründe gegen die Aufnahme gehen
auf: 421 + 110 + 32 + 92 + 68 + 1 = 724 = 808 − 84 gesperrt.

**7. Vorgemerkt (U135), keine Code-Änderung:**
1. U131-Abgleich: Begründung über alle Prognosepunkte ab Beginn der Bewegung, je mit ihrer eigenen 24-h-Bewegung; Werte, die auf
   3,0 runden, mit zwei Nachkommastellen.
2. U130-Nachrechnung: DVOL und ETF als „am offenen Tag festgeschrieben“ statt „ABWEICHEND“. Das Urteil bleibt unberührt.
3. Ereignisliste: „… und N frühere“ über die Liste.
4. Makro-Stand: Summenzeile der Signal-Bilanz „belegt N von M Tests (Zufall allein …)“.
- Reine Anzeige. Nach der Linie des Nutzers (06.10. 01:21, U134) kommt sie mit der nächsten Code-Änderung; auf Wunsch sofort.

**Was man wissen muss:**
- „ABWEICHEND“ in der Makro-Nachrechnung heißt bei DVOL und ETF „am offenen Tag festgeschrieben“, nicht „falsch gerechnet“.
- Ein Makro-„LIVE VERKAUF“ ist eine Lage (Perzentil ≥ 90 im Zeitraum), kein belegtes Timing. 4 belegte von 336 Tests sind weniger,
  als der Zufall liefert.
- Eine Begründung muss dieselbe Spanne messen wie die Regel, die sie erklärt. Sonst klingt ein Schwellenrand wie ein großer
  Widerspruch.

## 3δδ. U135 gebaut (Berichtskorrekturen); Darwin-Aufnahme bei Glück 3 % bewertet (06.10., Version 2026-09-23.56, Opus 5.5)

Anlass: Nutzer 06.10. 22:55: „Ja, baue gleich. Vielleicht sollte man das Darwin-Kriterium lockern auf Glück < 3 %?“

**1. U135 gebaut — reine Anzeige.** Zählung, Ereignisse, Profile, die Urteile von U130 und die Signale bleiben unverändert.
- **(1) Begründung im Abgleich** (`hl_konstellation._abgleich`). Sie misst jetzt dieselbe Spanne wie die Regel: alle
  Prognosepunkte vom 15-min-Abschnitt des Beginns bis zum Extrem, je mit ihrer eigenen 24-h-Bewegung.
  - Text: „vom Prognosekurs aus binnen 24 h höchstens …“, dazu der Docht: „das 15-min-Hoch lag … % über dem höchsten
    Prognosekurs“ (bei Anstiegen das Tief unter dem tiefsten).
  - Werte, die auf 3,0 runden, aber darunter liegen, stehen mit zwei Stellen (abgeschnitten, `_pc_rand`).
  - Ein Kandidat in der Spanne heißt „im benachbarten Ereignis enthalten“. Ohne Prognose in der Spanne: „keine Prognose zwischen
    Beginn und Tief gespeichert“. Zwei Kopfzeilen erklären beide Angaben.
  - Vorher/nachher auf der Probe (Bewegung über 58 h wie BTC 11.09., alte Funktion aus dem Paket 23.55 nachgerechnet): 23.55
    „höchstens -0,7 %“, 23.56 „binnen 24 h höchstens -2,7 %; das 15-min-Hoch lag 0,6 % über dem höchsten Prognosekurs“.
  - Für BTC 11.09. zeigt der nächste Bericht damit, wie knapp die Prognosepunkte zu Beginn lagen und wie groß der Docht war.
    Ein Docht von mehreren Prozent bei BTC spräche für einen Ausreißer in den Bars.
- **(2) Nachrechnung von U130** (`hl_makro_korr.nachrechnung_stand`, `VORLAEUFIG_TAGE = {dvol: 2, etf: 3}`).
  - Lag der Datentag beim Festschreiben weniger Tage zurück, gilt der Wert als „am offenen Tag festgeschrieben (Tageswert noch
    vorläufig, nicht geprüft)“. Das ist kein Widerspruch.
  - Ein abgeschlossener Tag mit geändertem Wert bleibt „abweichend“. Alle übrigen Kennzahlen werden auch am selben Tag geprüft.
  - Für das Bündel vom 06.10. stünde da: „20 archivierte Werte geprüft, alle gleich · am offenen Tag festgeschrieben …: dvol 2,
    etf30 2“.
- **(3) Listen.** „(N frühere nicht gezeigt; es folgen die 15 jüngsten)“ steht jetzt über der Ereignisliste. Ebenso bei den nicht
  erfassten Bewegungen (10) und bei den Fällen der Ereignis-Profile U43 (12).
- **(4) Makro-Stand: Summenzeile unter den Signalen** (`signal_summe`, `signal_summe_text`;
  `hl_makro_signal.FEHLURTEILE = (0,032; 0,05)` aus 9.4).
  - Text: „Zusammen: belegt N von M Tests -- der Zufall allein liefert nach der Kalibrierung (3–5 % Fehlurteile je Test) etwa …;
    Live jetzt … Signale (… Kauf, … Verkauf), davon mit belegter Bilanz ihrer Seite: …“.
  - Ein belegter Kauf zählt bei einem Verkaufssignal nicht.
  - Test-Kopie (Coin Metrics bis 23.05.): „belegt 3 von 322“, wie 9.5. Auf dem Pi zu erwarten: 4 von 336, Zufall 11–17, live 15
    Verkauf, davon 2 mit Beleg (XMR 200-W-MA 8 J und alles).
- **Proben.**
  - Konstellations-Nulltest mit neuer Zeile „Abgleich mit den Kursdaten, Begründung (U135)“. Geprüft: lange Bewegung (Soll −2,7 %
    und Docht 0,6 %), Anstieg gespiegelt, Schwellenrand −2,96 %, Nachbarereignis, keine Prognose, offenes Fenster, die ganze
    Kette über Datenbank und `lade` mit Rauschen, Hinweise vor den Listen.
  - Makro × Kurs: Prüfung 9 (offener Tag vorläufig, Revision eines abgeschlossenen Tags abweichend, Coin Metrics am selben Tag
    geprüft).
  - Makro-Selbsttest: Prüfung 56 (Summen gegen eigene Zählung, Zufallserwartung aus `FEHLURTEILE`, Live mit belegter eigener
    Seite an einem Konstrukt).
  - Mutationen 19 von 19 rot: u. a. Spanne nur 24 h vor dem Extrem, Weg bis zum Extrem, ohne Docht, Docht gegen das falsche
    Extrem, ohne 15-min-Abschnitt des Beginns, Rundung am Rand, alle Kennzahlen vorläufig, Abstand verkehrt herum, Live-Beleg
    ohne eigene Seite, Zufall mit nominellen 2,5 %, belegt je Zeitraum statt je Test.

**2. Darwin-Aufnahme bei Glück < 3 % statt ≤ 1 %? (U136, Entscheidung beim Nutzer)**
- **Heute käme ein Konto in Frage:** 0x926a…af36 (4 von 13 richtig, Zufall 8 %, Glück 1,4 %, gedämpfter Vorsprung rund +17
  Punkte). Ob das Einstiegs-Veto greift, zeigt der Bericht nicht, er nennt nur den ersten Grund. Die Liste hätte 2 statt 1
  Mitglied.
- **Zufallserwartung im heutigen Pool** (69 geprüfte Konten aus check_profis 06.10. 19:00; exakt mit n und Zufallsquote je
  Konto, Binomial, `darwin_null.py`):

  | Glück ≤ | rein zufällig erwartet | beobachtet | P(mindestens so viele rein zufällig) |
  |---|---|---|---|
  | 1 % | 0,32 | 1 | 27 % |
  | 2 % | 0,78 | 2 | 18 % |
  | 3 % | 1,16 | 2 | 32 % |
  | 5 % | 1,72 | 5 | 3 % |

  - Zwischen 1 und 3 % erwartet der Zufall 0,84 Konten, beobachtet ist 1. In diesem Band gibt es keinen Hinweis auf Können.
  - Die Vorauswahl nach Gewinn 7 T/30 T nutzt dieselben Trades; das macht Zufallstreffer eher häufiger als hier gerechnet.
- **Simulation der Regeln v3** (`sim_darwin_v3.py`, nach `sim_regeln.py` vom 30.09.; 200 Konten ohne Vorsprung, Entscheidungen
  Median 1,1 je Tag, Zufallsquote 8–58 % wie im Pi-Bericht, 12 Läufe à 120 Tage):

  | Szenario | Glück ≤ | Könner auf der Liste | Zufallskonten auf der Liste | Anteil Zufall | Zufallsaufnahmen je Woche |
  |---|---|---|---|---|---|
  | ohne Könner | 1 % | — | 1,9 ± 0,2 | 100 % | 1,0 |
  | ohne Könner | 3 % | — | 4,9 ± 0,2 | 100 % | 2,5 |
  | 2 Könner (+20 Punkte) | 1 % | 56 ± 8 % | 2,0 ± 0,2 | 64 % | 1,0 |
  | 2 Könner | 3 % | 79 ± 3 % | 5,5 ± 0,3 | 78 % | 2,7 |
  | 10 Könner | 1 % | 62 ± 4 % | 2,1 ± 0,1 | 25 % | 1,0 |
  | 10 Könner | 3 % | 64 ± 4 % | 5,5 ± 0,3 | 46 % | 2,7 |

  - Bei 2 % liegen die Zufallskonten dazwischen (3,5–4,1).
  - Der Pi mit 1 Mitglied passt zum Szenario ohne Könner.
  - Variante „Bewährung“ (direkt bei ≤ 1 %; bei ≤ 3 % erst Kandidat, Aufnahme nach mindestens 4 späteren Entscheidungen mit
    Glück ≤ 20 % binnen 21 Tagen): ohne Könner 3,1 Zufallskonten; mit 2 Könnern 68 ± 5 % Abdeckung bei 3,0 Zufallskonten. Sie
    liegt zwischen 1 % und 3 %.
- **Bewertung.** 3 % verdreifacht etwa die Zufallsmitglieder und die Zufallsaufnahmen. Könner gewinnen nur, wenn sie selten sind
  (2 Könner: 56 → 79 %), bei vielen nicht (62 → 64 %). Die Liste würde größer, aber nicht besser. Der Engpass ist nicht die
  Schwelle, sondern dass der Pool kaum belegbares Timing enthält.
- **Empfehlung:** 1 % lassen.
  - Für mehr Daten die Beinahe-Aufnahmen (Glück 1–5 %) im Schatten vorwärts verfolgen: ihre späteren Ein- und Ausstiege gegen
    den Zufall, ohne Wirkung auf Liste, Profi-Flow und die Labor-Bilanz der Darwin-Liste. Nach 4–6 Wochen entscheiden.
  - Eine geänderte Aufnahme wäre Regeln v4 mit neuer Labor-Kennung (`liste=4`; heute gilt `liste=3` seit 23.38 -- in 23.56 stand
    hier versehentlich `liste=3`, berichtigt in 3εε).
- **Was die Darwin-Liste speist:** die Labor-Vorlagen „Darwin-Liste live folgen“ und „Gegen die Darwin-Liste“ sowie die Familie
  „Profi-Flow“ (Parallelbetrieb). Nicht v1, v2, Fusion oder Kaskaden — die Zusage bis 25.10. wäre nicht berührt.
- Skripte im Arbeitsbereich, nicht im Paket.

**Was man wissen muss:**
- Eine Glücksschwelle über viele Konten ist ein Mehrfachtest. Bei 69 geprüften Konten kommen bei 3 % rund 1,2 Konten rein
  zufällig durch, bei 1 % rund 0,3.
- Eine kleine Liste ist kein Fehler der Regel, solange im Pool kein Timing belegbar ist. Lockern füllt sie mit Glück.

## 3εε. Schatten der Darwin-Liste gebaut (U136; Nutzer 07.10. 13:37: „ja“; 07.10., Version 2026-09-23.57, Opus 5.5)

Anlass: Auf die Frage „Soll ich die Konten, die knapp an der Darwin-Aufnahme scheitern, im Hintergrund weiter beobachten?“ antwortet
der Nutzer „Ja“. Die Aufnahme bleibt bei Glück ≤ 1 %. Vorab festgelegt in `KONZEPT_Aktive_Profis.md` Abschnitt 11, bevor Daten da
sind.

**1. Was gebaut ist** (`hl_profis.py`, Abschnitt U136; Stand im Prognosespeicher `learned` „*“/„darwin_schatten“).
- **Gruppen** (`schatten_gruppe`):
  - „≤ 1 %“ = die Aufnahme;
  - „1–3 %“ und „3–5 %“ = alle Bedingungen der Aufnahme außer der Glücksschwelle;
  - Kontrolle = ebenso geprüft, aber Glück über 5 %;
  - Mitglieder der Liste nur in „≤ 1 %“.
- **Eintragen** (`schatten_tag`, einmal je UTC-Tag): beim ersten Mal mit Glück, Ein-/Ausstiegen und Zufallsquote. Ein Band bleibt;
  aus der Kontrolle führt genau ein Weg in ein Band.
- **Vorwärts** (`schatten_entscheidungen`, täglich): Ein- und Ausstiege nach dem Eintritt mit vorbeigegangenem 12-h-Fenster.
  - Richtig, Zufallsquote und „je Richtung und 4-h-Block einmal“ wie `bewerte_konto` (gemeinsamer Teil `_entscheidung`;
    `bewerte_konto` selbst unverändert).
  - Das Fenster (bis, jetzt − 12 h] rückt vor; nachgeholt wird höchstens 14 Tage.
- **Urteil** (`schatten_urteil`):
  - Δ = Mehr-Treffer im Band 1–3 % minus Mehr-Treffer der Kontrolle, Streuung aus Σ q(1−q), einseitiger z-Test.
  - „Timing belegt“ nur mit Δ ≥ 5 Punkten, p < 0,05, ≥ 60 Entscheidungen aus ≥ 3 Konten (Kontrolle ≥ 60) und Δ > 0 ohne jedes
    einzelne Konto.
  - Termin 18.11.2026, sonst 16.12.2026; davor nur Zwischenstand.
- **Anzeige:** eigener Abschnitt in `check_profis` (Debug „★ Aktive Profis“, Wochenprüfung mittwochs 19:00); Berichte
  `u136-darwin-schatten` am 18.11. 19:15 und `u136-darwin-schatten-2` am 16.12. 19:15.
- **Dashboard** (`hl_viz._schatten`): nach der Darwin-Entscheidung, einmal je Tag; ein Fehler hält die Bewertung nicht an. Liste,
  Labor und Familien lesen den Schatten nicht.

**2. Warum eine Kontrollgruppe.** Konten handeln eher in bewegten Phasen; dann treffen auch Ein- und Ausstiege ohne Können öfter
als die Zufallsquote aus beliebigen Zeitpunkten (offene Audit-Frage, KONZEPT 10).
- Simulation mit +4 Punkten Bias für alle: Der Vergleich nur mit der Zufallsquote sagt in 25–33 % der Läufe „Timing“, der Vergleich
  mit der Kontrolle in 3 %.
- Pool vom 06.10.: 68 geprüfte Konten trafen 28,1 % gegen 24,6 % Zufall (342 von 1.217, Zufall 299,6 ± 14,0). Ob das Können,
  Auswahl nach Gewinn oder der Bias ist, trennt erst der Vergleich vorwärts.

**3. Proben.**
- `hl_profis.py --nulltest`, neuer Teil „Schatten der Darwin-Liste (U136)“ (rund 11 s; ganzer Nulltest rund 12 s statt 0,6 s):
  - Gruppen gegen die Aufnahme (12 Fälle);
  - Eintragen (Band fest, Kontrolle -> Band einmal, einmal je Tag, ohne Gewinn kein Eintrag);
  - vorwärts auf Kursdaten: Treffer und mittlere Zufallsquote gleich `bewerte_konto` mit demselben Placebo; nur nach dem Eintritt;
    zwei Schritte = einer, ein 4-h-Block über die Grenze zählt einmal; der Wechsel Kontrolle -> Band teilt die Entscheidungen;
  - Statistik gegen eine Rechnung von Hand (Δ +11,6 Punkte, p 0,031), ohne ein Konto, Termine, Bericht;
  - Simulation (150 Konten, 42 Tage, echte Funktionen): ohne Können mit Bias belegt 3 % (Soll ≤ 8), nur gegen die Zufallsquote
    33 % (Soll ≥ 15), halber Pool mit +15 Punkten 100 % (Soll ≥ 80).
- Mutationen 19 von 19 rot, u. a. Bandgrenze strikt, Band ohne Vorsprung, Gründe ignoriert, Band nicht fest, auch vor dem
  Eintritt, ohne 4-h-Block, Fenster ohne „bis“, Zufall der Gegenrichtung, ohne Kontrolle, ohne Probe ohne ein Konto, Urteil vor
  dem Termin, ohne Mindestzahl Konten.
- Ende-zu-Ende in der Sandbox (`e2e_schatten.py`, nicht im Paket): Recorder-Schema, 23 Konten mit echten `bewerten`-Urteilen,
  Dashboard-Schritt an zwei Tagen mit verschobener Uhr, `check_profis`.
  - Tag 1: gute Konten in „≤ 1 %“, ein Zufallskonto in „3–5 %“, der Rest Kontrolle.
  - Ein zweiter Lauf am selben Tag ändert nichts.
  - Tag 2: vorwärts gezählt je Gruppe gleich einer Rechnung von Hand.
  - Der Bericht zeigt den Abschnitt mit „Zwischenstand“.
- Teststärke (Prototyp, 6 Wochen): wahrer Vorsprung des Bands +8,7 / +6,0 / +5,3 / +2,9 Punkte -> belegt in 93 / 63 / 53 / 30 %.

**4. Eigener Fehler (23.56, berichtigt):** In 3δδ und in der Zeile U136 stand, eine geänderte Aufnahme bekäme die Labor-Kennung
`liste=3`. Die gilt aber schon seit 23.38 (Regeln v3, `hl_labor.py`). Richtig ist `liste=4`; der Bericht nennt sie so.

**5. Auf dem Pi.**
- Der Schatten trägt bei der ersten (stündlichen) Bewertung nach dem Update ein, danach einmal je UTC-Tag (erste Bewertung nach
  00 UTC). Vorwärts zählt alles nach dem Eintrag, sobald sein 12-h-Fenster vorbei ist und der nächste Tagesschritt läuft; die
  ersten Zahlen stehen nach ein bis zwei Tagen im Bericht (in der Wochenprüfung am 14.10.).
- In der Wochenprüfung (mittwochs 19:00) steht er unter „★ Aktive Profis“.
- Heute wären in den Bändern: 0x926a…af36 (1–3 %) sowie 0x0c4a…1b19, we love u jeff und 0x9836…457e (3–5 %), sofern sie die übrigen
  Bedingungen dann noch erfüllen.

**Was man wissen muss:**
- Ein Vergleich nur mit der Zufallsquote misst auch, WANN gehandelt wird. Erst die Kontrolle aus demselben Pool trennt Können vom
  Zeitpunkt.
- Gruppen werden beim Eintritt festgelegt und gezählt wird nur danach. Wer Konten später nach ihrer Bilanz umsortiert, misst
  seine eigene Auswahl.

## 3ζζ. Wochenbündel 07.10. ausgewertet; Abgleich-Begründung berichtigt (eigener Fehler 23.56, U137) (07.10., Version 2026-09-23.58, Opus 5.5)

Anlass: Der Nutzer lädt auf meine Bitte das Wochenbündel `berichte_2026-10-07_19-44_1d.txt` hoch (Wochenprüfung 19:00 mit 23.57;
dazu die Makro- und Vorbedingungen-Berichte vom 06.10. mit 23.55).

**1. Eigener Fehler in 23.56 (U135 (1)), berichtigt in 23.58 (U137).**
- **Befund:** Vergleich der Vorbedingungen-Berichte 06.10. 20:45 (Code 23.55) und 07.10. 19:13 (Code 23.56), Zeile für Zeile:
  - 10 Bewegungen hießen vorher „im benachbarten Ereignis enthalten“ und jetzt anders. ZEC: Rückgänge 16.09. 22:44, 22.09. 07:44,
    24.09. 16:44, 30.09. 02:44 und Anstiege 11.09. 16:59, 11.09. 17:59, 23.09. 16:14, 23.09. 18:14, 30.09. 15:44 standen als
    „binnen 24 h höchstens −2,1 … −2,9 %“ bzw. „+1,8 … +2,7 %“ mit Docht da.
  - XMR, Anstieg 24.09. 22:29 (Hoch 22:30, eine Minute): „keine Prognose zwischen Beginn und Hoch gespeichert“. Das las sich wie
    eine Lücke der Ablage.
  - Eine Zahl wurde kleiner: XMR 26.09. 22:59 „+2,8 %“ (23.55), jetzt „+2,1 %“.
- **Ursache:** 23.56 ersetzte die Menge „Punkte der 24 h vor dem Extrem, je mit ihrem Weg bis dorthin“ durch die Spanne „vom
  15-min-Abschnitt des Beginns bis zum Extrem, je mit eigener 24-h-Bewegung“, statt beide zu messen. Punkte VOR dem Beginn der
  Kursdaten-Bewegung fielen heraus. Das sind genau die Fälle einer Treppe nach einer Erholung um 3 % (die Kursdaten zählen den
  zweiten Rückgang vom Docht aus neu, die Prognosepunkte vor der Erholung sahen ihn schon) und eines 1-min-Dochts ohne Prognose im
  Abschnitt. Die Probe (d) prüfte nur den Kandidaten in der Spanne; den Fall „Kandidat vor dem Beginn“ gab es in der Probe nicht,
  und den alten Bericht habe ich vor der Lieferung nicht gegen den neuen verglichen.
- **Berichtigt** (`hl_konstellation._abgleich`), beide Mengen nur mit vollständigem 24-h-Fenster (nur solche Punkte gehören zu
  Ereignissen):
  - Spanne (Abschnitt des Beginns bis Extrem) mit eigener 24-h-Bewegung; „vorher“ (die 24 h vor dem Extrem) mit dem Weg bis zu
    DIESEM Extrem.
  - „im benachbarten Ereignis enthalten“, wenn ein Punkt einer der beiden Mengen 3 % erreicht (dieselbe Schwellenform wie
    `_kandidat`). Sein Ereignis überlappt die Bewegung nicht, dessen angezeigtes Extrem liegt also davor.
  - Sonst „binnen 24 h höchstens …“ = das Größte beider Maße; der Docht gegen den extremsten Kurs derselben Punkte.
  - „keine Prognose in den 24 h vor dem Hoch/Tief gespeichert“ nur, wenn beide Mengen leer sind (bei Bewegungen über 24 h:
    „zwischen Beginn und …“).
  - Kopfzeilen des Berichts erklären die drei Begründungen.
  - Zählung, Ereignisse und Profile sind unberührt; es ändert sich nur der Text der Begründung.
- **Proben** (Konstellations-Nulltest, Zeile „Abgleich mit den Kursdaten, Begründung (U135, 23.58)“), neu:
  - (i) 1-min-Docht ohne Prognose im Abschnitt, frühere Punkte sahen ihn → „benachbart“ (23.56: „keine Prognose zwischen Beginn
    und Hoch“);
  - (j) Treppe nach einer Erholung um 3 %, ganze Kette (Ereignisse aus Prognose- und Kursdaten) → nicht erfasst, „benachbart“
    (23.56: „höchstens −2,9 %; Docht 0,5 %“ -- genau das ZEC-Bild);
  - (k) echte Lücke vor einer kurzen Bewegung → „keine Prognose in den 24 h vor dem Hoch gespeichert“;
  - (l) frühere Punkte näher an 3 %, ganze Kette → „+2,8 %; Docht 0,4 %“ (23.56: +2,1 %, 1,1 %; wie XMR 26.09.);
  - (m) Kandidat nur in der Spanne (lange Bewegung) → „benachbart“;
  - (n) Datenende: ohne bewertbare Punkte „unvollständig“, mit bewertbaren Punkten davor, die 3 % sahen, „benachbart“;
  - (a2) lange Bewegung, Abfall schon im Abschnitt des Beginns → dessen Punkt bestimmt Zahl und Docht (−2,8 %, 0,6 %).
  - (a)–(h) aus 23.56 unverändert grün.
- **Mutationen 19 von 19 rot** (`mut137.py`, nicht im Paket): ohne die Punkte davor (Stand 23.56), Punkte davor ohne
  vollständiges Fenster, Zahl nur aus der Spanne, Zahl nur aus den 24 h davor (Stand 23.55), Docht nur über die Spanne, Lücke vor
  dem Nachbarereignis geprüft, keine Unterscheidung kurz/lang, Schwelle 1,5 % statt 3 %, 48 h statt 24 h, ohne Kandidaten der
  Spanne, Rückgang mit der Schwelle des Anstiegs, dazu die acht aus 23.56 mit neuen Ankern.
  - „ohne 15-min-Abschnitt des Beginns“ blieb zuerst grün: Bei Bewegungen unter 24 h decken die Punkte „vorher“ diesen Abschnitt
    mit ab. Erst (a2) mit einer langen Bewegung macht ihn rot.
- **Im nächsten Vorbedingungen-Bericht zu erwarten:** die 10 Zeilen wieder „im benachbarten Ereignis enthalten“; XMR 26.09. etwa
  „+2,8 %“ mit kleinerem Docht. BTC 11.09. bleibt „−2,99 %; Docht 0,8 %“; die übrigen Zeilen bleiben gleich, außer wo ein Punkt
  vor dem Beginn einen extremeren Kurs hatte (dann kleinerer Docht).

**2. Schatten-Tabelle (reine Anzeige, `hl_profis.schatten_text`).** Die Spalten „Konten“ und „mit Entsch.“ lasen sich als eine
(„Konten mit Entsch. 2“, aber 0 Entscheidungen). Jetzt eine Spalte „Konten (mit Entsch.)“, z. B. „48 (0)“. Probe im
Schatten-Teil des Profis-Nulltests (ein Bandkonto ohne Entscheidung → „4 (3)“); Mutationen 3 von 3 rot.

**3. Auswertung des Bündels.**
- **System** (Vollbericht 19:00): 23.57 läuft seit 07.10. 14:43 (Update erfolgreich), Dienste aktiv, 0 Neustarts; Datenbank
  13,64 GB, 215 GB frei; API-Gewicht 94 %, keine 429er; 52–55 °C, keine Drosselung; Backup vor 7,3 h. Pool-Fills: Abholstand
  Median 21,4 h (Takt 12 h; 30.09.: 29 h); die Darwin-Ereignisse kommen aus Positionen und sind davon nicht betroffen.
- **Vorbedingungen** (19:13, Code 23.56): 190 von 215 Kursdaten-Bewegungen erfasst (06.10.: 181 von 205). Von den 25 übrigen
  liegen 10 im Nachbarereignis (siehe 1) und 15 knapp unter 3 % vom Prognosekurs (im Bericht 2,1–2,99 %, mit 23.58 2,2–2,99 %)
  mit Docht bis 1,2 %.
  - BTC 11.09. 15:59 (−4,4 % bis 14.09. 02:29): „binnen 24 h höchstens −2,99 %; das 15-min-Hoch lag 0,8 % über dem höchsten
    Prognosekurs“. Das ist ein Schwellenrand (0,01 Punkte) und ein normaler Docht am Hoch der Rallye vom 11.09., kein Ausreißer
    in den Bars. Die Diagnose aus 3γγ ist damit bestätigt.
- **Ereignis-Profile** (19:13): Rutsche 28 Fälle (Schwelle |z| ≥ 4,45, getestet ab 14 Fällen), Anstiege 34 (4,14, ab 17);
  nichts markiert.
  - Frage des Nutzers: steigt der Pool-Flow 4 h vor Rallys und fällt er vor Rücksetzern? Bisher je 12 Fälle, noch nicht
    getestet. Mittel vor Rutschen +0,03 … +0,13 (0 h +0,21), vor Anstiegen +0,05 … +0,24 (0 h +0,30). Er liegt vor BEIDEN
    Richtungen leicht über normal; ein Fallen vor Rücksetzern ist nicht zu sehen.
  - Testbar wird er, wenn er in der Hälfte der Fälle Werte hat (`n_min`): Rutsche nach etwa 4 weiteren Fällen (um den
    10.–11.10.), Anstiege nach etwa 10 (um den 14.10.).
  - Labor als Spiegel desselben Signals (Schwelle ±0,5, 4 h): „Pool folgen“ 184 Trades (62 Blöcke) Ø −0,104 %, t −0,8; „Gegen
    Pool“ 184 (63) Ø −0,144 %, t −1,5. Richtungsanteil ≈ +0,02 % je Trade vor Kosten, Kosten ≈ 0,12 %.
  - Familie „Pool-Konten“ (4 h): ZEC +15,3 Punkte (z +2,7), HYPE −14,0 (z −2,4), BTC +10,4 (z +1,8), ETH −2,8, XMR −1,1. Kein
    gemeinsames Vorzeichen.
- **Makro-Stand** (19:14): Die Summenzeile steht und stimmt nachgezählt. Belegt 4 von 337 Tests (Zufall allein etwa 11–17);
  live 13 Signale, alle Verkauf, davon 2 mit belegter Bilanz der eigenen Seite (XMR 200-W-MA 8 J und alles; p 0,013 aus 4
  Episoden, beide Zeilen teilen fast alle Daten). Live gegen Nachrechnung 128 von 128 gleich. Neu live: Puell 1 J Verkauf seit
  04.10. (Perzentil 98). Zonenkarte: DVOL 35,9 = Perzentil 3,7 (sehr niedrige implizite Schwankung; Lage, kein Signal). Die
  U130-Nachrechnung mit „vorläufig“ ist nicht im Bündel (Bericht 25.10. oder Debug „★ Makro × Kurs“).
- **Aktive Profis und Schatten** (19:18): 1 Mitglied (x.com/SilkBtc, Glück 0,4 %, Vorsprung +29). Die nächsten Kandidaten:
  0x58b2…11f3 2,1 %, 0x0c0e…8a4d 3,2 %, 0x4c6d…5ee9 3,7 %, 0x541e…071d 4,0 %. Der Schatten hat eingetragen: 2 / 1 / 3 Konten in
  den Bändern, 48 in der Kontrolle, vorwärts noch 0 (erste Zahlen nach dem Tagesschritt am 09.10.). Einzelheiten in
  `KONZEPT_Aktive_Profis.md` 11.9.
- **Fusion** (19:13): über alle Coins 4 h Fusion − Basisrate −0,0037 ± 0,0032 (nur live −0,0025 ± 0,0042), nicht belegt; 24 h
  −0,0279 ± 0,0084 ✓ (131 Blöcke in 26 Zeitblöcken). Gegen v1 bei 24 h +0,0153 ± 0,0100 (v1 allein etwas besser, nicht belegt).
  Bis 25.10. keine Änderung (U108).
- **Kaskaden** (19:14): Y = 0 in 9 von 11 Zellen mit Daten; BTC 1 h Y 0,25 (+0,0143 ± 0,0090) und ETH 1 h Y 1 (+0,0167 ± 0,0116)
  unter 2 SE, Seitenspiegel nirgends belegt. Zuverlässigkeit der ≥ 2-σ-Vorhersagen überall ✓. Richtung der Asymmetrie über alle
  Coins 46 % ± 3 % (z −1,4). Das Placebo wählte XMR 4 h Y 2 und PAXG 1 h Y 0,5: Y-Wahlen entstehen auch mit verschobener Heatmap.
- **Magnet** (U110, 19:14): nichts belegt (36 Tests). Am nächsten HYPE 1 h mittel, Überschuss +11,6 ± 3,9 Punkte (echt −
  Placebo +18,2 ± 8,0), aber nur 35 von 60 wirksamen Fällen und Spiegel unter 2 SE. In der 60-Tage-Variante A berührt ETH
  Cluster seltener als Zufallsniveaus (z −1,9 bis −2,3 über 4–24 h, n_eff 16–28); kleine Stichproben, überlappende Horizonte, im
  Test U110 nicht zu sehen.
- **Anker:** in keinem Coin ein Beleg.
- **Labor** (19:18): seit 27.09. 3.580 Trades, netto −72.792 USD (Gebühren 26.081), 24 h −13.777. Stufen: Kandidat 31, negativ 7,
  sonst nichts. Die Zufall-Kontrolle verliert (−3.821 USD, t −2,5), wie sie soll; „Glück“ der Besten 100 %, nichts schlägt den
  Zufall. „Familie Orderfluss“ −22.735 USD (290 Trades, 17 % Treffer, t −15,3): bekannt aus U96 (XMR-Markteinstiege bis 73 bps
  von der Mitte, Stopp nach einer Minute), Auswertung mit U99.
- **Familien** (19:16): nichts aufgestiegen. ZEC „Funding“ steht noch auf „Bewährung“ aus dem Wochenurteil vom 01.10. (Woche =
  Unix-Woche ab Donnerstag 00 UTC); heute z −1,5, beim Urteil am 08.10. fällt es zurück. |z| ≥ 2 in 5 von 53 Zellen (Zufall
  ≈ 2,4), vier davon in HYPE mit beiden Vorzeichen.
- **Empfehlungen, Konfluenz, Kalibrierung v2:** wie zuvor. Limit gegen Markt über alle Coins beim Kauf +0,06 % (−0,09 … +0,21);
  Konfluenz nach 4 h 54 % gegen Zufall 52 %; v2 sagt in 4 von 6 Coins die Basisrate (c = 0).

**Was man wissen muss:**
- Wer eine Begründung umbaut, prüft die Fälle der alten mit. Erst der Vergleich alter und neuer Bericht Zeile für Zeile zeigt, was
  verloren ging; eine Probe deckt nur die Fälle ab, an die man gedacht hat.
- „Nicht markiert“ heißt bei wenigen Fällen „noch nicht belegbar“. Die Schwelle der Ereignis-Profile liegt wegen des
  Mehrfachtests über alle Treiber und Vorläufe bei |z| ≈ 4–4,5.

## 3ηη. Konzept Regime-Modul: die letzten 4–8 Wochen lesen (U138; Nutzerwunsch 07.10. 21:51; 07.10., nur Dokumente, Version 2026-09-23.58 unverändert, Opus 5.5)

Anlass: Nutzer 07.10. 21:51, sinngemäß: ein weiteres Modul „wie Reverse Market Engineering“. Es soll die jüngsten 4 (oder 8)
Wochen analysieren, also den Zeithorizont, den die Marktteilnehmer gerade nutzen, und daraus ableiten, wie sich der Markt
aktuell verhält und welche nächsten Schritte möglich sind. Beispiele des Nutzers:
- Stufen über 2–3 Tage, danach ein Rücksetzer zu einem höheren Tief, Schritte von typisch x %;
- „zwischen 2 und 5 Uhr nachts geht der Kurs zurück“;
- „samstags nachts fällt der Kurs“.

Begründung: Die tatsächlichen Bewegungen sind größer als unser Vorhersagewert. Auftrag: sorgfältig recherchieren, Literatur
durchgehen, eigene Vorschläge ergänzen, ein durchdachtes Konzept erstellen.

**1. Was entstanden ist (keine Codeänderung).**
- `RECHERCHE_Regime_07-10-2026.md`: Bericht „Kurze Fenster erkennen Volatilität, nicht Richtung“ (sechs Teilrecherchen und eine
  Synthese, rund 160 Quellen, unbestätigte Angaben gekennzeichnet).
- Zufallsweg-Simulation in der Sandbox (`zufall_regime.py`, nicht im Paket; Ergebnisse in `KONZEPT_Regime.md` 2). Echte
  Kursdaten erreicht die Sandbox nicht (Binance, GitHub und PyPI gesperrt); die Prüfung an Daten ist Phase 0 auf dem Pi.
- `KONZEPT_Regime.md` (U138): acht Bausteine R1–R8, zwölf Anzeigen RG1–RG12, Prüfplan P0.1–P0.9 und V1–V4 (vorab, als Entwurf),
  Phasen 0–3, Entscheidungen 1–7 beim Nutzer.

**2. Befunde, die das Konzept tragen.**
- **Größe und Zeitpunkt sind vorhersagbar, die Richtung kaum.**
  - Tages- und Wochenprofil der Schwankung sind robust (Hansen, Kim & Kimbrough 2024). HAR erklärt bei BTC rund ein Drittel der
    Schwankung (R² 0,32–0,37, in der Lernstichprobe).
  - Richtung: Wochenmomentum bei BTC 2011–2018 R² 3–5 % (≈ 55–57 % Vorzeichentreffer), seit 2020 kleiner, verdient fast nur long.
  - Deshalb wirkt unsere Prognose „zu klein“: Bei P(aufwärts) nahe 50 % liegt der Erwartungswert nahe null, die Bewegung selbst
    hat die volle Schwankung. Das Modul gibt Verteilungen aus (Spannweite, Zonen, Zeitfenster, Berührwahrscheinlichkeiten).
- **Stufen sind zum großen Teil Zufallsgeometrie** (Simulation: 2,5 % Tagesschwankung, 5-min-Schritte, 4.000 Tage):
  - θ 4 %: rund 10 Beine je 4 Wochen, Aufwärtsbein Ø 2,07θ (≈ 8 %) in 2,8 Tagen;
  - P(höheres Tief) 0,47–0,50 (Formel 1/2), P(höheres Hoch | höheres Tief) 0,66–0,70 (Formel 2/3; ein Auswahleffekt, weil die
    Bedingung kurze Rücksetzer auswählt);
  - eine Drift von +0,2 %/Tag (≈ +6 % im Monat) hebt die höheren Tiefs nur auf 0,53–0,54;
  - Rücksetzer verteilen sich wie die geschlossene Formel; Fibonacci-Niveaus sind unauffällig;
  - 30-min-Bars verlängern Beine bei θ 4 % um rund 20 %; Nullsimulationen laufen deshalb in derselben Auflösung wie die Daten.
- **Uhrzeit- und Wochentagsmuster der Richtung sind in 4–8 Wochen nicht von Zufall zu trennen.**
  - Nachweisgrenze einer Stunde (zweiseitig, 80 % Teststärke): 24–30 bp in 4 Wochen, 17–21 bp in 8 Wochen, 3,9–4,8 bp in
    3 Jahren. Der größte dokumentierte Effekt liegt bei rund 4–5 bp, und Kalendereffekte wechseln über Stichproben das Vorzeichen.
  - Der Zufall allein liefert in 8 Wochen zu 66 % einen Wochentag mit mindestens 6 von 8 negativen Nächten (fallend oder
    steigend: 91 %) und in 28 Tagen zu 98 % irgendein 3-h-Fenster mit mindestens 18 von 28 gleichgerichteten Tagen.
- **Regime:** Ein Volatilitätswechsel ist binnen Stunden bis etwa anderthalb Tagen erkennbar (CUSUM auf 30-min-Bars: Verdopplung
  ≈ 4,5 h, Halbierung der Varianz ≈ 38 h), ein Driftwechsel erst nach Wochen bis Monaten (1 %/Tag: 34–126 Tage). Fenster werden kombiniert statt gewählt (Pesaran & Pick
  2011).
- **Neuland:** Ob Kontodaten (Pool, Darwin, Wale, Liquidationen) mehrtägige Wendepunkte erklären, hat niemand untersucht. Die
  einzige Hyperliquid-Renditestudie endet bei 30 Sekunden.

**3. Was das Konzept vorschlägt (Einzelheiten `KONZEPT_Regime.md` 3–10).**
- Grundregel: **Die Historie schätzt, das Fenster filtert.** Drei Jahre 30-min-Kerzen (`klines30`, übrige Coins über
  `hl_timestats`) liefern Profile, Parameter und Nullverteilungen. Die 4–8 Wochen liefern nur den Zustand. Die Fensterlänge folgt
  dem letzten Bruch (14–56 Tage).
- R1 Zwei-Uhren-Profil der Schwankung (New York mit Sommerzeit; UTC für Funding und volle Stunde) → RG1.
- R2 Bewegungsgröße 1–7 T: HAR (BTC zusätzlich DVOL), Spannweite ≈ 1,60·√V, Berührwahrscheinlichkeit mit Bar-Korrektur,
  Restbudget des Tags → RG2, RG3.
- R3 Regime-Zustand: CUSUM-Bruchmelder, Jump-Modell, BOCPD „seit wann“; dazu die Regime-Bilanz der vorhandenen Treiber
  (Giacomini-White) → RG4.
- R4 Stufen: Directional Change mit Schwellengitter (1,0–2,0 σ_Tag), Bein-Zustand, Rücksetzer-Zone mit Clustern, nächste Stufe
  neben 1/2 und 2/3, Beinende gegen die Baseline D/θ → RG5–RG7.
- R5 Zeitmuster der Richtung: höchstens drei vorab festgelegte Hypothesen auf der Historie (Vorschlag K1 02–05 Uhr, K2
  Samstagnacht, K3 US-Kernsitzung); live nur „Beobachtung mit Zufallsvergleich“ → RG8.
- R6 Wochenmomentum long/flat, nur BTC und ETH, nur im Trendzustand → RG9.
- R7 Teilnehmer an den Wendepunkten, das eigentliche „Reverse Engineering“: was Pool, Darwin, Wale, Liquidationen und Cluster je
  Bein tun; Hypothesen T1–T3 vorwärts, Urteil frühestens 16.12.2026 → RG10.
- R8 Regime-Analog als paralleler Experte und Pfadfächer (U116 erweitert) → RG11, RG12.
- Phasen:
  - 0: Vorprüfung auf der Historie als Debug-Bericht, berührt nichts (eine Sitzung);
  - 1: Schatten mit eigenem Abschnitt „RG Regime“;
  - 2: R8, Labor L1–L3 mit neuen Kennungen, Vorwärtsprüfung;
  - 3: Experten der Fusion erst nach dem 25.10. und nach den eigenen Urteilen.
- Keine Doppelungen (`KONZEPT_Regime.md` 8): Das HAR von R2 ist das von U109 und wird nur einmal gebaut. Der heutige
  Band-Multiplikator aus `hl_indikatoren.regime` bleibt bis zum 25.10.; die R2-Bänder werden gegen ihn geprüft. Das Zeitprofil
  (neben R1) und die Analog-Suche (neben R8a) laufen unverändert weiter. U116 geht in R2 und R8b auf. U43 und U131 bleiben
  unverändert; R4 verknüpft ihre Ereignisse nur mit den Beinen.
- Die Zusage bis 25.10. bleibt unberührt.

**4. Eigene Fehler im Entwurf (beim Gegenlesen gefunden, vor der Ablage berichtigt).**
- Die Nachweisgrenze der Stufen-Asymmetrie stand zuerst bei 0,8θ bzw. 0,6θ. Mit 80 % Teststärke sind es 1,6θ (4 Wochen) bzw.
  1,1θ (8 Wochen).
- Die Teststärke-Tabelle der Zeitmuster war teils einseitig gerechnet (aus der Recherche übernommen). Jetzt ist sie einheitlich
  zweiseitig; die Zeilen 02–05 Uhr und Samstagnacht sind neu gerechnet.
- Zuschreibungen vorsichtiger formuliert: Andersen & Bollerslev 1996, Osler (Stop-Orders beschleunigen), Ahmed, Grobys & Sapkota
  2020. Ein unbestätigtes Erscheinungsjahr (Han, Kang & Ryu) ist gestrichen.

**5. Entscheidungen beim Nutzer (`KONZEPT_Regime.md` 12).**
1. Phase 0 jetzt bauen? Empfehlung: ja, zuerst.
2. Kalenderhypothesen K1–K3 oder andere, höchstens drei, festgelegt vor dem Bau.
3. Coins: alle sechs oder zuerst BTC und ETH.
4. Anzeige: eigener Abschnitt „RG Regime“ oder Teil der Prognose.
5. Labor L1–L3 mit neuen Kennungen ab Phase 2.
6. Phase 1 im Schatten noch vor dem 25.10. oder alles danach.
7. Teilnehmer-Hypothesen T1–T3 oder eigene Fragen, festgelegt vor Phase 1.

**6. Nebenbei nachgeführt.** Die Stand-Zeile des UPDATE_PLAN nannte noch Pi-Stand 23.47 und „einzuspielen 23.55“. Jetzt: 23.57
seit 07.10. 14:43 laut Vollbericht 19:00, FRED über die API seit 06.10., einzuspielen 23.58; die vergangenen Termine sind
gestrichen.

**Was man wissen muss:**
- Ein Stufenschema, das man im Chart sieht, liefert schon der Zufall: Beine von 2–3 Tagen und höhere Hochs nach höheren Tiefs in
  zwei von drei Fällen. Information steckt nur in der Abweichung davon, und die prüft man auf der Historie, nicht im Fenster.
- Wer in 4–8 Wochen nach „fällt immer“-Fenstern sucht, findet fast sicher eines. Zu jeder solchen Beobachtung gehört die
  Zufallswahrscheinlichkeit nach der Suche.
- Eine Prognose mit P ≈ 50 % ist nicht „zu klein“. Sie sagt, dass die Richtung offen ist. Die Größe der Bewegung ist
  vorhersagbar und gehört ins Band.

## 3θθ. Regime-Modul Phase 0 gebaut: Vorprüfung auf der Historie (U138; Nutzer 07.10. 23:34: „Lass uns mit Phase 0 beginnen“; 08.10., Version 2026-09-23.59, Opus 5.5)

Anlass: Entscheidung 1 aus `KONZEPT_Regime.md` 12. Für die offenen Punkte 2 und 3 gelten die Empfehlungen: Kalenderhypothesen K1–K3
wie vorgeschlagen, alle Coins mit Historie.

**1. Vorab festgelegt, bevor ein echtes Datum gerechnet wurde.** `KONZEPT_Regime.md` 9.1a fasst die Entwurfsbedingungen so genau, wie
der Code sie rechnet: Datenquelle, Mindestlänge 456 Tage, Monats-Rollen mit Embargo, σ̂_Tag kausal, DM nach Coroneo-Iacone und je
Prüfung Rechnung, Null und „belegt“-Bedingung. Was beim Bau geändert wurde, steht dort mit Grund (Abschnitt „Beim Bau geändert“,
sieben Punkte, siehe 3).

**2. Gebaut: `hl_regime.py`** (neu, rund 2.800 Zeilen, nur numpy).
- **Daten:** eigene Datei `regime.db` neben der Hauptdatenbank, Tabelle `rg_klines` (30-min-Kerzen je Coin) und `rg_meta` (Quelle je
  Coin). Schreiben nur mit BEGIN IMMEDIATE.
  - Quelle je Coin: Binance-Futures oder Bybit, je nachdem, welche die längere Historie hat. Geprüft wird in Jahresschritten; die
    Wahl wird beim ersten Laden festgehalten, damit eine Reihe nie aus zwei Börsen gemischt wird.
  - Bis 1.096 Tage zurück, danach nur Neues; Zeitbudget 7 min je Lauf, sonst lädt der nächste weiter.
  - Ohne Netz bricht der Lauf schnell ab (eine nicht erreichbare Börse wird für die übrigen Coins nicht erneut versucht).
  - `klines30` in `hl_liq.db` bleibt unberührt. Die Analog-Suche der Prognose liest sie; neue Coins dort hätten die Prognose vor dem
    25.10. geändert.
- **P0.1:** vier Varianzprofile je 30-min-Bar (flach, UTC-Fourier, heutiges Zeitprofil wie `hl_forecast.time_vol_profile`,
  New-York-Fourier mit UTC-Funding und 8:30/9:30 ET), monatlich neu geschätzt. Dazu beschreibend der Versatz des Werktags-Buckels
  zwischen Sommer- und Winterzeit aus geglätteten Formen: +1 h heißt „folgt New York“.
- **P0.2:** HAR-log gegen EWMA und gegen die 7-Tage-Schwankung des heutigen Bands, für 1, 3 und 7 Tage. Dazu 80-%-Band aus
  Trainingsquantilen, Berührquoten an Hoch und Tief der Bars und Spannweite gegen 1,60·√V.
- **P0.3:** Directional Change mit θ = c·σ̂_Tag je Bein (c = 1,0 … 2,0), sechs Größen gegen 100 Vorzeichen-Surrogate mit gleicher
  Drift, Holm über Coins × c, Hälften. Persistenz der Asymmetrie gegen dieselbe Korrelation in den Surrogaten. Dazu beschreibend
  die Stufen in Prozent und Tagen.
- **P0.4:** Punkte alle 4 h mit D/θ 0,1–0,9. Modell gegen die kalibrierte Baseline, gepoolt über Coins, nur aufgelöste Fälle im
  Training, Verlust je Bein summiert.
- **P0.5:** K1–K3 (Holm, Vorzeichen je Jahr), 24 Stunden und 7 Wochentage (BH), Persistenz nach Heston-Korajczyk-Sadka; dazu
  beschreibend die letzten 8 Wochen.
- **P0.6:** Wochenmomentum BTC/ETH: Brier gegen die Basisrate (Holm über 6), Timing-Regel mit Kosten, Deflated Sharpe, PBO
  (berichtet).
- **P0.7:** Fenster 2/4/8 Wochen, EWMA und Historie gegen Fixed Share wie in R3; das einfache Mittel wird mit berichtet.
- **P0.8:** Die bestehende Analog-Suche ist nachgebaut; Merkmale und Auswahl sind gleich `hl_forecast` (geprüft gegen das
  Original). Sie läuft gegen das Regime-Analog und den Zufallsweg mit σ̂ (CRPS, täglich, 24 h / 72 h / 7 T).
- **P0.9:** CUSUM für Verdopplung der Schwankung und Halbierung der Varianz auf Profil-bereinigten Renditen; Schwellen auf
  GARCH-t-Nullpfaden je Coin; Verzögerung mit eingepflanzten Brüchen; Alarme auf den echten Daten.
- **Bericht:** Prüfstand je Coin, danach je Prüfung die Zahlen mit Vergleichsgröße. Rechenzeit in der Sandbox rund 2 min für sechs
  Coins zu drei Jahren, Spitzenspeicher 182 MB; auf dem Pi geschätzt 4–8 min (niedrige Priorität per `nice`).
- **Einbindung:**
  - Debug-Einträge „★ Regime: Vorprüfung auf der Historie (U138, Phase 0)“, „Regime: Historie laden bzw. ergänzen“ und „Regime:
    Selbsttest“;
  - Berichtsplan `u138-vorpruefung` einmal am 08.10. um 21:00 (erst laden, dann prüfen, je 15 min Grenze);
  - Selbsttest-Schritt in `install.py` (34 Schritte);
  - `version.py` (Prüfsumme), `update.py` (Dateiliste mit `hl_regime.py`, `KONZEPT_Regime.md`, `RECHERCHE_Regime_07-10-2026.md` --
    die beiden Dokumente fehlten dort in 23.58).

**3. Beim Bau geändert (vor jedem echten Lauf), weil Nullen oder Positivkontrollen es zeigten.**
- P0.4: Verlust je Bein summiert statt gemittelt. Das Mittel gewichtete kurze Beine anders als das Training und meldete auf einem
  Zufallsmarkt „belegt“ (p 0,0035).
- P0.6: PBO ist keine Bedingung. Bei sechs fast gleichen Varianten lag es auch für wirksames Momentum bei 0,44 bzw. 0,63.
- P0.7: Kombination = Fixed Share (wie R3). Das einfache Mittel mit Historie lag 23–65 % hinter dem besten Fenster.
- P0.8: Das Regime-Analog muss zusätzlich den Zufallsweg mit σ̂ schlagen. Gegen die bestehende Suche allein gewann schon die
  Rechnung in σ̂-Einheiten (Zufallsmarkt ohne Struktur: p 0,009 bei 24 h).
- P0.9: Verdopplung heißt Schwankung ×2 (Varianz ×4), wie in R3; dazu z² gekappt, 24 h Sperre und gemeinsame Kalibrierung.
  Getrennt kalibriert ergaben sich 2,6 statt 1 Fehlalarm je 30 Tage; ohne Kappe meldete der Melder eine Verdopplung selbst bei
  konstanter Schwankung erst nach 16 h, mit Kappe nach 10 h.
- P0.3: p aus der t-Verteilung mit 99 Freiheitsgraden (die Streuung der Null ist geschätzt).
- P0.1: Der Versatz des Buckels kommt aus Fourier-Formen statt aus Feldmitteln, die bei dicken Rändern an Einzelbars hingen.

**4. Proben.** `hl_regime.py --selbsttest`, 27 Prüfungen, rund 33 s in der Sandbox, ohne Netz:
- Bausteine:
  - Φ, Quantil, t-Verteilung, Holm, BH, CRPS (gegen Brute Force und numerisches Integral);
  - DM-Fehlurteile 3,3 % auf Rauschen und 5,7 % bei AR(0,5)-Differenzen, Newey-West.
- Daten:
  - Laden ohne Netz mit ersetzten Quellen (Quellenwahl, lückenlos bis zur letzten fertigen Kerze, zweiter Lauf nichts Neues,
    unbekanntes Symbol, Zeitbudget);
  - Parser gegen die dokumentierten Binance- und Bybit-Formate.
- Aufbereitung und Kausalität:
  - Lücke zählt nicht zur Tagesvarianz; σ̂, DC-Zustand und Regime-Merkmale sind von späteren Daten unabhängig;
  - HAR mit Band, Fixed Share, P0.4-Vorhersagen samt Modell des Monats und P0.6-Wochenprognosen bleiben vor einem Schnitt gleich,
    wenn die Kurse danach geändert werden.
- Directional Change gegen die geschlossenen Formen (Überschießen 1,02, Dauer 1,12, P(höheres Tief) 0,505, P(höheres Hoch |
  höheres Tief) 0,664); θ folgt der Schwankung (Schwankung ×3: Beine je Tag 1,15-fach).
- P0.8-Nachbau gleich der bestehenden Analog-Suche: 9 Merkmale bis 1e-15, Auswahl identisch.
- Je Prüfung Nulltest und Positivkontrolle:
  - New-York-Buckel belegt, Versatz +1,25 h; UTC-Buckel nicht, Versatz +0,17 h;
  - HAR schlägt EWMA bei Schwankungsregimen;
  - Zufallswege (einer mit Drift 0,4 %/Tag) ohne Abweichung, Momentum über 3 Tage → Überschießen in 5 von 5 Schwellen belegt;
  - P0.4 Null p 0,13, Umkehr nach 21-Tage-Trend p 0,0002, D/θ trägt (0,602 gegen 0,649);
  - K1 mit −25 bp gefunden (−24,3 bp), Vorzeichenwechsel zwischen den Jahren nicht belegt;
  - Momentum belegt (ETH L 14/21), Null nicht;
  - Fixed Share bei Schwankungsstufen ×3 nicht schlechter als das beste Fenster;
  - Regime-Analog schlägt den Zufallsweg bei Umkehr in Schwankungseinheiten, Null nicht;
  - Bruchmelder: 0,86 Fehlalarme je 30 T, Verdopplung nach 10 h, eingepflanzter Bruch nach 14 h gemeldet.
- Urteilslogik von Hand: P0.1 (Monatsanteil), P0.3 (Holm, Hälften), P0.5-Persistenz (Hälften), P0.8 (beide Vergleiche).
- Bericht mit „zu kurz“ und „keine Historie“.
- **Mutationen 29 von 31 rot** (`mut138.py`, nicht im Paket). Zwei bleiben grün, ohne Wirkung auf die Urteile: die 24-h-Sperre nach
  einem Alarm (die gemeinsame Kalibrierung gleicht sie aus) und der Melder für Varianz ×2 statt ×4 (meldet die Verdopplung ebenfalls
  binnen 12 h).
- **Nullreplikationen** (außerhalb des Selbsttests):
  - P0.1: 0 von 8 UTC-Märkten mit „New-York-Uhr“, 0 von 8 flachen Märkten belegt;
  - P0.3 mit 100 Surrogaten: 0 belegt in zwei Durchgängen zu 6 Coins;
  - P0.4: 0 von 16 belegt;
  - P0.5: eine K-Hypothese in 8 Märkten (Holm je Markt);
  - P0.6: 0 in 6 Läufen; P0.8: 0 von 8.
- Ganzer Lauf auf sechs synthetischen Coins zu 1.096 Tagen:
  - belegt sind P0.1 und P0.2 in allen sechs (eingebaut: New-York-Buckel, Schwankungsregime);
  - dazu ein Zufallstreffer bei den Stunden (BTC 02–03 UTC, +4,6 bp). Bei Benjamini-Hochberg mit q = 0,10 über 31 Tests ist das zu
    erwarten (je Coin rund 10 % Wahrscheinlichkeit für mindestens einen); die Jahresbedingung hält nicht alle ab;
  - sonst nichts belegt;
  - P0.7 und P0.9 bleiben nicht belegt: Fixed Share 1–3 SE hinter 2 Wochen, Verdopplung erst nach 19–26 h. Bei echten Kursen mit
    zäher Schwankung ist das auch zu erwarten.

**5. Eigene Fehler im Bau, vor der Lieferung gefunden.**
- Die erste Kausalitätsprobe für Fixed Share verglich nur NaN: Die Historie war als 500-Tage-Mittel gebaut, Fixed Share also vor Tag
  499 leer. Gefunden durch eine Mutation (Blick in die Zukunft blieb grün). Jetzt nutzt die Probe dieselben Fenster wie P0.7 und
  zählt die verglichenen Werte (374).
- Die erste Mutation „Fixed Share lernt mit morgen“ war gar kein Blick voraus: Der Verlust von morgen ist übermorgen bekannt. Ersetzt
  durch „übermorgen“, jetzt rot.
- Die P0.4-Kausalitätsprobe schnitt drei Tage nach Monatsanfang; Training mit unaufgelösten Fällen fiel so nicht auf. Jetzt schneidet
  sie am Monatsanfang und vergleicht zusätzlich das Modell des Monats.
- Erste Positivkontrolle P0.3 (Trendregime ±0,6 %/Tag) war je nach Startwert z 0 bis 4,5, also kein verlässlicher Test. Ersetzt durch
  Momentum über 3 Tage (z 3,2–8,1 über vier Startwerte).

**Was man wissen muss:**
- Eine Probe, die nur fehlende Werte vergleicht, besteht immer. Jede Vergleichsprobe zählt, wie viele echte Werte sie verglichen hat.
- „Besser als die bestehende Suche“ ist kein Beleg für Regime-Ähnlichkeit, solange schon die Skalierung mit σ̂ allein gewinnt. Jede
  neue Prognose muss auch gegen den einfachsten Konkurrenten mit derselben Schwankung antreten.
- Ein Kriterium, das auch eine wirksame Regel ablehnt (PBO bei fast gleichen Varianten), misst die Auswahl unter Varianten, nicht
  die Wirksamkeit.

## 3ιι. Erster echter Lauf der Regime-Vorprüfung ausgewertet; K3 war nicht driftneutral (eigener Fehler 23.59, U139) (08.10., Version 2026-09-23.60, Opus 5.5)

Anlass: Der Nutzer lädt um 02:24 den Bericht des von Hand gestarteten Laufs hoch („★ Regime: Vorprüfung auf der Historie“,
08.10. 02:06, Code 23.59, Exit 0, 480,7 s, davon Rechnen 162 s). Ergebnis im Einzelnen: `KONZEPT_Regime.md` 9.4.

**1. Daten:** BTC, ETH, ZEC und XMR von Binance-Futures, PAXG von Bybit, je 1.096 Tage (08.10.2023–07.10.2026, 52.608 Kerzen,
keine Lücke); HYPE erst ab 30.05.2025 (496 Tage). Quellenwahl, Budget und Lückenprüfung arbeiteten wie vorgesehen.

**2. Ergebnis (wie vorab festgelegt).**
- **Belegt:**
  - P0.5 bei XMR: K1 +12,3 ± 4,9 bp, also das umgekehrte Vorzeichen der Hypothese „fällt“; K3 −82,6 ± 15,9 bp; Stunden 07–08
    (+8,0), 12–13 (−11,1) und 13–14 UTC (−8,6 bp); Persistenz (HKS) Steigung +0,249, p < 0,0001.
  - P0.5 bei PAXG: K3 −13,5 ± 4,0 bp (beides mit dem rohen K3, siehe 3).
  - P0.7 bei ZEC und XMR.
- **Nicht belegt** (alles andere):
  - P0.1: D schlägt das heutige Zeitprofil in 5 von 6 Coins, aber nicht die glatte UTC-Form. Der Buckel wandert mit der
    US-Sommerzeit (+0,75 bis +1,0 h bei BTC, ETH, HYPE und PAXG).
  - P0.2: HAR schlägt EWMA bei 1 Tag in allen sechs, bei 7 Tagen nur XMR. Das Band ist bei ZEC, XMR und PAXG zu schmal (69–77 %).
    Berührquoten liegen beim 0,75- bis 0,93-Fachen der Formel.
  - P0.3: Die Beine sind Zufallsgeometrie (BTC c = 1,5: P(höheres Tief) 0,57 gegen 0,54, P(höheres Hoch | höheres Tief) 0,67
    gegen 0,68). Abweichungen gibt es nur bei der Dauer (ETH c 1,0; PAXG c 1,0 und 1,25), Persistenz nirgends.
  - P0.4: Das Modell (0,6130) ist schlechter als D/θ (0,6102), und D/θ ist kalibriert.
  - P0.6: kein Momentum (PBO 0,56, beste DSR 0,89).
  - P0.8: Der Zufallsweg mit σ̂ ist bei 72 h und 7 Tagen meist am besten.
  - P0.9: Die Fehlalarme liegen im Soll, aber eine Verdopplung wird erst nach 51–366 h gemeldet (Soll ≤ 12 h).
  - K1 und K2 sind bei BTC und ETH um null (BTC +0,6 ± 2,3 und −1,8 ± 4,9 bp). K3 ist in allen sechs Coins negativ; bei BTC und
    ETH wechseln die Jahre das Vorzeichen.

**3. Eigener Fehler in 23.59: K3 war nicht driftneutral (U139), berichtigt in 23.60.**
- **Befund beim Auswerten:** K3 verglich die Sitzung 9:30–16:00 New York (6,5 h) mit dem ganzen Rest seit 16:00 des
  Vorhandelstags, im Mittel 27,1 h (17,5 h, montags mit dem Wochenende 65,5 h). Schon eine feste Drift d je Stunde ergibt so
  (6,5 − 27,1)·d ≈ −0,86 × mittlere Tagesrendite, ohne jeden Sitzungseffekt. Grob gerechnet (Endkurse Crypto.com 08.10.:
  BTC 83.273 $, PAXG 4.116 $, ETH 2.573 $; Anfangskurse Oktober 2023 aus dem Gedächtnis) sind das bei BTC rund −8,5 bp, bei PAXG
  rund −6 bp und bei ETH rund −3,6 bp.
- **Ursache:** Nulltest und Positivkontrolle von P0.5 liefen ohne Drift, eine Positivkontrolle gab es nur für K1. Den Fall
  „Drift ohne Sitzungseffekt“ hat keine Probe gestellt. Fenster ungleicher Länge zu vergleichen, misst die Drift mit.
- **Berichtigt** (`hl_regime.p05_kalender`): K3 = Sitzung − (6,5 h ÷ Länge des Rests) × Rest, die Längen aus den Zeitstempeln
  (Zeitumstellungen eingeschlossen). Jede feste Drift hebt sich genau auf.
  - Das rohe K3 bleibt als Anzeige, mit dem Wert, den die Drift allein ergäbe (aus den eigenen Kerzen).
  - K1 und K2 bleiben absolut („fällt“ heißt Rendite < 0); ihr Driftanteil steht daneben.
  - Die Hypothese „US-Sitzung schwächer als der Rest“ meint je Stunde. Die Korrektur ist eine Fehlerbehebung, keine neue
    Hypothese (`KONZEPT_Regime.md` 9.1a Punkt 8).
- **Was der Lauf 21:00 (Berichtsplan, mit 23.60) zeigen dürfte**, grob geschätzt mit einem Zwei-Raten-Modell (Rate in der Sitzung,
  Rate im Rest, Drift aus Anfangs- und Endkurs; nicht gerechnet):
  - XMR bleibt deutlich, rund −45 bp je Sitzung oder −7 bp je Stunde gegenüber dem Rest;
  - BTC rund −10 bp, ETH rund −20 bp;
  - PAXG rund −5 bp, vermutlich nicht mehr belegt.
- **Proben** (`hl_regime.py --selbsttest`, jetzt 28 Prüfungen, neu „P0.5: Drift +40 bp je Tag …“):
  - Drift +40 bp je Tag (Start 10.11.2023, drei Frühjahrs- und zwei Herbstumstellungen): K3 bis auf 10⁻⁹ gleich wie ohne Drift,
    nicht belegt; roh −42,4 bp, p 0,0008.
  - −40 bp je US-Sitzung: K3 belegt, −40,4 bp.
  - Nullreplikationen mit 40 Märkten je Fall: berichtigt 1, 1 und 2 von 40 belegt bei Drift 0, −40 und +80 bp je Tag; roh 3, 27
    und 40 von 40 mit p < 0,05. Wirksamkeit bei −40 bp: 38 von 40.
  - Mutationen 5 von 6 rot (`mut160.py`, nicht im Paket): K3 wieder roh, Skalierung verkehrt, Rest immer 17,5 h, Sitzung 6 h,
    Zeitumstellung übergangen. Grün bleibt eine Mutation der Testhilfe (Effekt nur bis 15 Uhr: −34 statt −40 bp, innerhalb der
    Toleranz ±12 bp).
  - Die Zeitumstellung fiel erst auf, als der Testmarkt ungleich viele Frühjahrs- und Herbstumstellungen hatte; mit drei zu drei
    hoben sich die Fehler genau auf.

**4. Weitere Änderungen in 23.60 (nur Anzeige):**
- P0.3 druckt bei belegten Abweichungen „beobachtet gegen Mittel der Surrogate“; im Lauf 02:06 fehlte die Richtung der Dauer.
- P0.5 druckt bei K mit p Holm < 0,05 zusätzlich Median, Mittel ohne je 2,5 % Ränder, Anteil negativer Tage und das Mittel je Jahr.
- P0.8 druckt auch „Bestand gegen Zufall p“ (der Nachbau der Analog-Suche der Prognose gegen den Zufallsweg mit σ̂; beschreibend
  für die Auswertung nach dem 25.10.).
- Berichtsplan `u138-vorpruefung` (08.10. 21:00): Text für den zweiten Lauf. Die übrigen Urteile sollten bei einem Tag mehr Daten
  gleich bleiben; wenn nicht, ist das selbst ein Befund.

**5. Lesart und Vorschlag** (`KONZEPT_Regime.md` 9.4 und 12):
- **Richtung über Stunden bis Tage:** nicht vorhersagbar in diesen Daten. Stufen, Rücksetzer und höhere Tiefs sind
  Zufallsgeometrie bei wechselnder Schwankung.
- **Vorhersagbar ist die Größe:** HAR bei 1 Tag, ein glattes Tagesprofil statt des Zellenprofils, die kalibrierte Bein-Geometrie
  (D/θ).
- **Kalender:** Einziger möglicher Befund ist XMR in der US-Sitzung. Er ist für einen liquiden Markt verdächtig groß und braucht eine
  zweite Quelle und ältere Daten.
- **Vorschlag:**
  - Phase 0b, ein Vorhaltetest auf 10/2020–10/2023 nur für das, was getragen hat (Liste a–e vorab festschreiben), dazu XMR von
    Bybit;
  - danach Phase 1 schlank (Größe, Tagesprofil, Bein-Geometrie, Kalender nur bestätigt);
  - Bruchmelder, Regime-Analog, Wochenmomentum und Labor L1–L3 entfallen;
  - nach dem 25.10. vormerken: Zeitprofil glätten, Band mit HAR, Analog-Suche gegen den Zufallsweg bewerten.

**Was man wissen muss:**
- Wer zwei Zeitfenster ungleicher Länge vergleicht, misst die Drift mit. Jeder Fenstervergleich braucht einen Nulltest mit Drift
  (und mit Zeitumstellungen in ungleicher Zahl), nicht nur den driftfreien Zufallsweg.
- Ein Vergleich „Rohwert gegen Nachrechnung“ im eigenen Bericht (Driftanteil neben K3) macht so einen Fehler sichtbar, bevor ein
  Urteil darauf baut.

## 0. UPDATE-PLAN (ab 22.09.)

Alles Offene steht in **`UPDATE_PLAN.md`** — lebendes Dokument, wird zu Beginn jeder Sitzung gelesen
(Abschnitt A: Prüfungen) und am Ende aktualisiert (Status, neue Punkte, Version). Was dort nicht
steht, existiert nicht. Nächster Punkt (Stand 23.18): am 24.09. ab 13:15 die Neubewertung der alten Sperren (Debug „Masterregel Sperre“),
beim nächsten Start die Zeile „Pool-Fills“ (U40b), Debug „★ Ereignis-Profile (U43)“ ansehen; U29/U35 vor U7b.

## 3zz. Auditbericht v10 (Opus 5.5): Review und P0-Korrekturen (22.09., Version 2026-09-22.18)

Vollständiges Review in `REVIEW_Audit_v10_22-09-2026.md` (Status je Befund, Belege, Entscheidungen).
Kern: **K1** (HL-Limit 10 Nutzer je IP für userEvents-Abos; wir forderten 600 an und schalteten die
Ableitung für angeforderte Abos ab — Doku online bestätigt) und **K2** (Kalibrierung strukturell
lernunfähig: 93-%-Treiber → p_up 50,8 %, n_eff durch MAX_TRAIN bei ~125 gedeckelt — selbst nach-
gestellt) sind zutreffend; **H8** (t-Wert überlappender Fenster: 27 % Fehlalarme statt 16 % — selbst
nachgestellt) ebenfalls. Die „2.500" in M1 sind USD je Fill (Zähler saß im Mindestbetrag), kein
Fehler des Audits. Umgesetzt: K1, H1, H2 (matches-Kanal), H3, H4, H5, H8 (Block-t), H9, H12, M1, M2,
M6, M9, M11 (store_forecast), M12, M13, N1, N2, N5, N7, N8, S1, S4; Positivkontrolle informativ im
Nulltest. Harness 77/77 (Funding/Gegen-Flow-Erwartungen angepasst), Nulltest grün, Selbsttest 20/20.
Offen: K2-Neubau (P1), H6/H7/H10/H11/H13, M3–M5/M7/M8/M10, S2/S3.

## 3yy. Masterregel Sperre: > 2.000 Fills/Tag = dauerhaft gesperrt (22.09., Version 2026-09-22.17)

Entscheidung Nutzer: eine systemweite Blacklist statt Einzelausschlüsse; dauerhaft, weil Maschinen ihr
System nicht ändern. **Recorder:** `konto_status` (addr, status, grund, seit, quelle, fills_tag);
`sperre_pruefen()` im Fill-Lauf (Zähler `fill_zaehler` je UTC-Tag aus dem Stream für alle
beobachteten Konten inkl. Gesperrter, plus COUNT aus lb_fills 24 h) → über `SPERRE_FILLS_TAG` = 2000
dauerhaft; Rohfills des Kontos gelöscht. Manuell: labels.json `"sperre": true/false` (false schützt).
Wirkung: Stream speichert keine Fills Gesperrter (zählt nur), Poller nur Liquidationsstufe
(`SPERRE_POLL_S` 6 h, Heatmap bleibt), `order_candidates` überspringt, REST-Fill-Lauf überspringt,
Leaderboard-Zyklus überspringt (Rang 0/1), `fill_konten` = Auswahl ∪ Pool ∪ Wale (neu: Wale, damit
Fills/Tag messbar) − Gesperrte. **Dashboard:** `gesperrte_konten(con)` (60 s Cache, Tabelle +
manuell) filtert `load_whales` (current + events → Direktionale Wale, Wal-Flow), den Lernzyklus
(Scores → Elite, Smart-Flow, Gegen-Flow); Label-Marke „GESPERRT — Masterregel"; Netzwerkstatus
„Gesperrt (Masterregel): N Konten"; Pool-Vorschau mit Marke; Werkzeug `check_sperre.py`
(Debug „Masterregel Sperre": Liste mit Grund, aktivste Konten der 24 h). Probe: 2.100 Fills → gesperrt,
Poller 5 min nicht fällig / 7 h fällig, Orders-Kandidaten ohne das Konto, fill_konten ohne das Konto,
load_whales ohne das Konto, Neustart lädt die Sperre. Die Aktivitätsschranke der Elite (300 Trades)
bleibt als zweite, feinere Stufe darunter.

## 3xx. Aktivitätsschranke der Elite: > 300 Trades/Tag = keine Elite (22.09., Version 2026-09-22.16)

Beobachtung des Nutzers: Elite-Konten, die alle paar Sekunden Positionen öffnen. Prüfung der
Ausschlüsse: Hedge (Klasse 0) greift; Market-Maker-Regel verlangt ≥ 5 **ruhende** Kauf- und
Verkaufs-Limits — Taker-HFT ohne ruhende Limits rutscht durch; und weil der Poller es jede Minute
sieht, liefert es hunderte Schritte, die jeden winzigen Vorlauf „signifikant" machen (t ≥ 1 hilft
nicht). **Neu:** `hl_score.aktivitaets_filter` — Trades/Tag = Maximum aus gebündelten Fills
(`pool_fills_hourly`) und Positionsänderungs-Minuten (`whale_positions`/`lb_events`), 3-Tage-Mittel;
über `ELITE_MAX_TRADES_TAG` = 300 → ok=False. `elite_filter` vereint Gewinn- und Aktivitätsschranke;
Lernzyklus und `check_elite` nutzen sie (Spalte Tr/T), die Elite-Tabelle unter den Treibern zeigt
Trades/T (rot > 300). Der Treiber summiert nur Elite-Konten → ausgeschlossene fließen nicht ein.
Probe: 480 Ereignis-Minuten/Tag raus, 480 Fill-Trades/Tag raus, 12/Tag bleibt. PDFs angepasst.
Option für später: die Klasse „Market-Maker" auch aus der Aktivität ableiten (wirkt dann überall).

## 3ww. Pfeile bleiben bis zur nächsten Prognose; Elite-Kontentabelle unter den Treibern (22.09., Version 2026-09-22.15)

**Pfeile verschwanden nach 60 s:** `sigBewerten` verglich gegen den letzten Verlaufseintrag — beim
Nachladen derselben Prognose war das der eigene Eintrag (Δ = 0). Jetzt Vergleich gegen die VORIGE
Prognose (letzter Eintrag mit t ≠ fc.ts); Umschwung-Fenster ebenso ohne den eigenen Eintrag.
Probe: Pfeil nach neuer Prognose 1, nach zwei Nachladungen weiter 1.
**Elite-Konten sichtbar:** `compute_forecast` liefert `elite_konten` (Adresse, Name/Rang aus
lb_accounts, Score/n/α/t aus den Scores, Kontowert aus lb_accounts bzw. addresses, Position im Coin
aus lb_positions bzw. jüngster whale_positions-Zeile, uPnL %, PnL 30 T); Tabelle unter der
Treibertabelle mit HypurrScan-Links, sortiert nach Score. Jede Teilabfrage einzeln abgesichert.

## 3vv. HypurrScan-Links in Wale, Leaderboard und Trade-Tabellen (22.09., Version 2026-09-22.14)

Helfer `hsLink(addr, inner)`; verlinkt: Wal-Tabelle (Gruppenkopf und Positionszeilen), „Letzte
Änderungen" der Wale (Wal-Flow), Leaderboard-Kontozeilen, „Letzte Änderungen der Top-Konten",
Käufe/Verkäufe 3 T und 48 h. Vorschau (10) hatte den Link schon. Infozeile der Vorschau nennt die
Abdeckung der Trades/T („aus k von 24 Stunden", 22.13). Browser-Probe: Wale 8, Leaderboard 4 Links.

## 3uu. Abschnitt 10 vor den Netzwerkstatus, bis 500 Konten (22.09., Version 2026-09-22.12)

Nutzerwunsch: Abschnitt 10 „Aktive Profis" stand unter dem Netzwerkchart bei den Betriebsteilen;
jetzt zwischen „48 h" (9) und „Netzwerkstatus". Anzahl wählbar 20/100/500 (Vorgabe 500; Endpunkt
`/pool?n=` bis 600), die sortierte Spalte ist in der Kopfzeile unterstrichen. Probe: 560 Pool-Konten
→ 500 Zeilen, Reihenfolge lbact48 → pool → network.

## 3tt. Pool-Anteil am Poller-Budget sichtbar (22.09., Version 2026-09-22.11)

Frage des Nutzers: Werden die Pool-Abrufe im Netzwerkmonitor erfasst? Antwort: die Leaderboard-
Datei (anderer Host, kein API-Gewicht) erscheint nur als Dauer in „Leaderboard-Stände"; die Stream-
Fills (0 Gewicht) in „Fills live"; die Positionsabfragen der Pool-Konten laufen über den Poller und
konkurrieren dort um das feste Budget (280/min) — ~111 Gewicht/min bei 554 Konten alle 10 min.
Jetzt sichtbar: Zeile „Adress-Poller … davon Pool N (x % der letzten 10 min)" und im Netzwerkstatus
„Pool-Anteil x %" (`poller_pool_anteil`, `pool_konten` in meta). Stellschraube: `POOL_POLL_S`.
Nur der Kontoname als Link in der Vorschau (22.10).

## 3ss. Vorschau: „{links,behavior}" behoben, HypurrScan-Links (22.09., Version 2026-09-22.9)

`labels_for()` liefert je Adresse ein Objekt (links, behavior, name …); die Vorschau hatte das
ganze Objekt als Namen gezeigt. Jetzt: Name aus dem Label, sonst Kurzadresse; Verhaltensklasse als
Zusatz. Der Kontoname ist ein Link auf `hypurrscan.io/address/<addr>` (neuer Tab). „ROI 1 T" bleibt
„—", bis die erste stündliche Leaderboard-Datei nach dem Einspielen von 22.8 die neuen Spalten füllt.

## 3rr. Vorschau-Abschnitt 10 „Aktive Profis" und ein reparierter Route-Verlust (22.09., Version 2026-09-22.8)

Frage des Nutzers: Woher kommen die PnL-Daten in der Stichprobe — sie kommen aus Hyperliquids
Leaderboard-Datei (Kontowert, Tag/Woche/Monat/gesamt: PnL, ROI, Umsatz; einzahlungsbereinigt).
Sofort nutzbar als Vorschau: neuer Abschnitt **10 „Aktive Profis — Vorschau"**: die 20 Pool-Konten
mit der besten ROI (umschaltbar 1 T / 7 T / 30 T / PnL 7 T), mit Kontowert, PnL 7 T, Umsatz 1 T,
Umschlag und — sobald das Stundenaggregat läuft — gebündelte Trades/Tag (gelb außerhalb 5–150).
Ausdrücklich „ohne Aktivitätsprüfung" (Phase 2). Recorder speichert jetzt auch pnl_1d/roi_1d/
pnl_30d/roi_30d im Pool und eine **stündliche Historie** `pool_accounts_hist` (Kontowert, Tages-
und Wochenwerte) — Grundlage für 12-h-Vergleiche und Einzahlungs-Erkennung. Endpunkt `/pool`, alle
5 min, Nav-Chip, im Snapshot enthalten.

**Nebenfund, behoben:** Beim Einbau von `/debug/threads` (21.09.) war die Zeile `elif u.path ==
"/restore/info":` verloren gegangen — die Route lieferte 404 (die Info-Zeile unter dem Restore-
Knopf blieb leer), und `/debug/threads` hätte zwei Antworten gesendet. Wiederhergestellt.

## 3qq. „Aktive Profis" Phase 1 (22.09., Version 2026-09-22.7) — Grenze 150 Trades/Tag

Ergebnis Phase 0: Pool 545 von 46.651 Konten, Überlappung mit Top-75 35; Umschlag misst Größe,
nicht Aktivität (Hochrechnung wertlos) → Grenze auf **150** gebündelte Trades/Tag gesetzt
(`POOL_MAX_TRADES_TAG`, greift in Phase 2). **Phase 1 im Recorder:** Konstanten `POOL_*`;
Tabellen `pool_accounts`, `pool_fills_hourly`; Spalte `addresses.account_value`;
`pool_aktualisieren()` je Leaderboard-Datei (Aufnahme ≥ 1 Mio & ≥ 500k, Hysterese 7 T, Deckel 600
nach pnl_7d, neue Adressen ins Verzeichnis), `pool_laden()` beim Start; `fill_konten` = Auswahl ∪
Pool; Poller-Stufe Pool (10 min); Kontowert im Poller (Standard-Dex `marginSummary`);
`pool_stunden_verdichten()` (24 abgeschlossene Stunden, gebündelt = COUNT DISTINCT Minute+Richtung)
vor der Fill-Aufräumung; Rohfills 14 T (`POOL_ROH_TAGE`), Vielhandler > 500 Fills/Tag nur 1 T.
`check_pool.py` Block 2b zeigt ab dem Einspielen die echten Trades/Tag (Median, ≤/> 150, < 5,
verbleibend). Erwartung: Stream-Fills für ~620 Konten, Speicher ≤ 1 M Rohzeilen. Phase 2 (Bewertung:
Exit-/Entry-Lift, ROI 12 h, Bot-Marke) und Phase 3 (Dashboard) folgen nach 24 h Daten.

## 3pp. „Aktive Profis" — Konzept und Phase 0 (22.09., Version 2026-09-22.6)

Neues Vorhaben (Konzept in `KONZEPT_Aktive_Profis.md`, alle Entscheidungen des Nutzers eingearbeitet:
Korrektur 2 %/12 h, Bündelung je Minute, Qualifikation 7 T, Pool ≥ 1 Mio Kontowert und ≥ 500k
Tagesumsatz, Perp+Spot, Entry-Lift zusätzlich, Bot = längster Trade-Abstand ≤ 4 h, Rang nach ROI 12 h,
Hysterese 7 → 30 T). **Phase 0 umgesetzt:** `check_pool.py` liest die volle Leaderboard-Datei (alle
Konten) und zählt Pool, ROI-Verteilung, Umschlag, Überlappung mit der Top-75-Auswahl, Kosten; Debug-
Eintrag „★ Aktive Profis, Phase 0". Ändert nichts am System. Nächste Schritte nach der Zählung:
Phase 1 (Pool-Tabelle, Stream-Fills für den Pool, Kontowert der Wale, Rohfills 14 T), Phase 2
(`hl_profis.py`: Bündelung, Exit-/Entry-Lift mit Placebo, Bot-Marke, ROI 12 h), Phase 3 (Dashboard).

## 3oo. Treiber-Signale: Pfeile, Blitze, Töne (22.09., Version 2026-09-22.5)

Nutzerwunsch, drei Punkte: (1) Ton, wenn ein seltener (Ereignis-)Treiber anspringt — negativ
Sirene 5 s, positiv „Kasse" 3 s; (2) Pfeile neben dem Namen bei jeder Änderung (▲ grün / ▼ rot),
Doppelpfeil ab 0,5 Score-Änderung (die „50 %" als halbe Skala interpretiert, absolut — relative
Prozente wären bei kleinen Scores Rauschen); (3) Umschwung: ≥ 2 der 5 gewichtigsten Treiber
binnen 10 min um ≥ 0,5 gefallen → Sirene + roter ⚡ (symmetrisch: gestiegen → Kasse + grüner ⚡).
Umsetzung im Dashboard-JS (`sigBewerten`): Verlauf je Coin/Treiber 60 min in localStorage,
Fortschreibung nur bei neuer Prognose (fc.ts); Töne per Web-Audio (Sirene: Sägezahn 600↔1200 Hz
im 0,5-s-Takt; Kasse: gefiltertes Rauschen + Glocken 1568/2093 Hz, zweimal); Schalter „🔔 Töne"
(localStorage `hl_ton`) mit Probe; Sirene hat Vorrang vor Kasse, wenn beides zutrifft.
Browser-Probe: ▲ / ▼▼ / ▲▲ korrekt, zwei rote Blitze, Sirene ausgelöst, keine JS-Fehler.

## 3nn. Breiten-Regel der Flow-Treiber (22.09., Version 2026-09-22.4, Fund des Nutzers)

Leaderboard-Flow zeigte „inaktiv" bei +13,0 Mio in 60 min — von EINEM Konto. Die Bedingung
„≥ 2 Konten" (gegen kleine Einzelkonten gedacht) warf ein direktionales Top-Konto mit 13 Mio
heraus, und der Grund-Text nannte keine Zahlen. Jetzt: aktiv bei ≥ 2 Konten **oder** einem
Einzelkonto ab 1 Mio (Leaderboard) bzw. 5 Mio (Wale); ein Einzelkonto wird mit 0,7 gedämpft
(Größe ja, Breite nein) und im Text benannt. Die Inaktiv-Gründe beider Flow-Treiber nennen die
tatsächlichen Zahlen („ruhig: 0,40 Mio von 1 Konto in 60 min — nötig …"). Treiber-Test 77/77.

## 3mm. Alle 30 Treiber in EINER Tabelle, EREIGNIS-Marke (22.09., Version 2026-09-22.3)

Nutzer-Entscheidung: keine getrennte „Nicht aktiv"-Liste — alle 30 stehen in der Treibertabelle.
Inaktive Zeilen sind gedimmt, Richtung „—", Gewicht/Prior/Bilanz wie sonst, im Text der Grund
mit Zahl. Ereignis-Treiber (Kapitulation, OI-Überhitzung, Crowding-Extrem, Vol-Spike-Reversion,
Liquidationsdruck, Wal-Flow, Leaderboard-Flow) tragen die Marke **EREIGNIS**, wenn das Ereignis
anschlägt, sonst „kein Ereignis" mit dem Stand der Bedingung. Payload: `inaktiv` (Zeilen) neben
`drivers`; `missing` bleibt für Werkzeuge. Behoben: das Auffangnetz lief vor den Blöcken Analog/
Smart-Flow/Gegen-Flow/Elite (doppelter Elite-Eintrag, generische Texte) — jetzt am Ende; jeder
Treiber hat einen spezifischen Grund (`INAKTIV_GRUND`). **Am Leaderboard-Flow wurde nichts
geändert** außer der Ereignis-Form (Audit v9); seine Bedingung (≥ 75k, ≥ 2 Konten in 60 min/3 h)
ist seit Sitzung 1 dieselbe — in ruhigen Stunden ist er inaktiv, nicht abgeschaltet.

## 3ll. Jeder Treiber erklärt (22.09., Version 2026-09-22.2)

Beobachtung: 25 in der Tabelle plus 1 ausgesetzt = 26 von 30. Die vier fehlenden waren
**bedingte** Treiber ohne Meldung (Kapitulation nur bei Schub, OI-Überhitzung ab 90. Perzentil,
Crowding-Extrem nur in den äußeren Dezilen, Vol-Spike-Reversion ab 1,5× Norm) — sie verschwanden
still. Jetzt: jeder bedingte Treiber meldet seinen Grund mit Zahl („OI im 61. Perzentil, aktiv erst
ab dem 90."), alle Meldungen beginnen mit dem exakten Treibernamen (Mehrfachmeldungen mit „/"),
und ein Auffangnetz stellt sicher, dass jeder der 30 Treiber entweder in der Tabelle steht oder in
„Nicht aktiv" genannt ist. Die Zeile zählt „Nicht aktiv (n von 30; k in der Tabelle)".

## 3d. Debug-Konsole

Die neuen Werkzeuge stehen in der Debug-Liste des Dashboards (`debug_commands` in
`hl_viz.py`): **Fill-Abholstand** (`check_fills.py` — welche Konten hängen, Klasse, Fills je
Tag), **Ereignis-Signal M9** (`check_m9.py`), **Nulltest**, **Konto-Score-Selbsttest**. Jedes
neue Diagnosewerkzeug gehört dort eingetragen — vom Handy aus ist die Konsole der einzige
Weg, es zu starten.

## 4. Was beim ersten Start auf dem Pi zu erwarten ist

- `forecasts.db` bekommt die Tabelle `weights_h` und die Spalten `p_up`, `p_up_24`
  automatisch (`store_connect`). Der Reset-Marker von Sitzung 1 bleibt gesetzt; die
  Gewichte starten beim Prior in beiden Spuren.
- **Der Lernbeginn springt nach hinten**: Statt „läuft" steht für rund eine Woche
  „n_eff 4 h: x von 40". Das ist richtig — die bisherigen 40 Fenster waren zehn Stunden
  Daten. Die 24-h-Spur bleibt etwa 40 Tage beim Prior (dann Schwelle 30 Blöcke je Treiber).
- **Trefferquoten fallen und bekommen Klammern.** Beides ist richtig (M7 plus Intervall).
  Grün wird eine Quote erst, wenn das Intervall ganz über der Basisrate liegt.
- **Das Ereignis-Signal feuert seltener.** `check_m9.py` zeigt, wie viel seltener.
- `p_up` liegt anfangs nahe 50 %, auch bei deutlichem `bias`: Ohne gelerntes β und mit
  wenigen aktiven Treibern ist die kalibrierte Wahrscheinlichkeit bewusst zurückhaltend.
- **Konto-Score:** Beim ersten Lernlauf entsteht der erste Schnappschuss aus den letzten
  28 Tagen Ereignissen. `lb_stats` füllt sich erst mit dem nächsten Leaderboard-Abruf —
  bis dahin fehlen Edge und Konsistenz (zählen neutral 0,5), der Score lebt von Vorlauf,
  Größe und Klasse. Die Treiber Smart-Flow / Elite / Gegen-Flow erscheinen ab dem ersten
  Schnappschuss; Gegen-Flow erst, wenn Konten n ≥ 20 Schritte haben.

---

## 5. Nächste Schritte, in dieser Reihenfolge (Konzept Abschnitt 6)

1. **Auf dem Pi zuerst messen, nicht ändern:** `install.py --selftest` (Nulltest,
   Invarianten), `hl_recorder.py --db … --audit`, `check_m9.py --db …`, und die fünf
   Abfragen aus Anhang A des Konzepts (Pareto der Heatmap-Masse, Fill-Verbraucher je
   Klasse, Poll-Takte je Wertstufe, n gegen n_eff je Coin). Diese Zahlen legen die
   Stufen der Budget-Tabelle fest.
2. ~~P1 — Konto-Score~~ **erledigt** (hl_score.py). Offen daran: Vorlauf zusätzlich aus
   `lb_fills` (heute nur Positionsereignisse) und Score je Coin für ETH/HYPE prüfen, ob
   genug Schritte anfallen.
3. **P1 — Budget nach Score** (Recorder): Fills nur direktional/gemischt, Orders nur
   S1/S2, Stufen S1–S5, Sichtung nach Handelsgröße, **WebSocket-Abonnements für
   `learn.elite`** (`userFills` + `userEvents`, REST alle 5 min als Lückenfüller). Braucht
   einen Kanal Dashboard → Recorder für Klasse und Score (Vorschlag: Tabelle
   `account_class` in der Hauptdatenbank, vom Dashboard täglich geschrieben).
4. ~~P1 — Smart-Flow, Elite-Positionierung, Gegen-Flow~~ **erledigt**; Killkriterium
   (Konzept 3.4: Intervall enthält 50 % und Gewicht < 0,3 × Prior bei n_eff ≥ 50 → parken)
   noch offen — braucht erst n_eff 50.
5. **P2 — M1–M3** (Liquidationsableitung), Treiber-Familien, Live-Abrufe Bybit/OKX/
   Crypto.com in den Binance-Dienst, Leaderboard als Wal-Liste.
6. **P3 — Konfluenz zeigt Prognose-Beiträge; M4, M5, M12, M13, M15, M16; Git auf dem Pi.**

---

## 6. Offene Befunde aus dem Audit (unverändert seit Sitzung 1)

**Datenqualität:** M1 (Positionen über Neustart), M2 (Markpreis statt Handelspreis).
~~M3, M4, M5~~ erledigt (3c). **Betrieb:** M15 (Migration der Nebendateien); ~~M12, M13,
M16~~ erledigt (3c).
**Sicherheit, bewusst offen:** Dashboard lauscht auf allen Adressen — Entscheidung des
Nutzers.

---

## 7. Arbeitsweise, die sich bewährt hat

- **Prüfen statt behaupten.** Auch das eigene Konzept: Zwei Annahmen darin waren falsch
  (Analog-Suche läuft bereits stündlich; ihre Merkmale sind fest standardisiert) und
  sind im Konzept korrigiert.
- **Nulltest vor Vertrauen.** Er hat in dieser Sitzung zwei Fehler in frisch
  geschriebenem Code gezeigt, bevor sie ausgeliefert wurden.
- **Nach jeder Änderung:** `python -m compileall`, `node --check` der ausgelieferten
  Seite, Browsertest Handy und Desktop, alle Endpunkte, `install.py --selftest`.
- **Beim Löschen von Codeblöcken vorsichtig schneiden**; Patches mit `assert count == 1`.
- **Ein Server je Port.** „Port bereits belegt" liefert stillschweigend die alte
  Fassung aus — beim Testen immer auf einen frischen Port.
- **Tests, die Fehler festschreiben, sind gefährlicher als fehlende Tests.** Deshalb
  kommt das Soll des Nulltests aus der Mathematik.
