#!/usr/bin/env python3
"""
run_all.py — startet und überwacht alle Dienste in einem Prozess.

Startet Hyperliquid-Recorder, Binance-Stream und Dashboard gemeinsam,
mischt deren Ausgaben mit Präfix in ein Log und startet abgestürzte
Teilprozesse mit wachsender Wartezeit neu. Strg-C beendet alles sauber.

    python run_all.py                      # alles starten
    python run_all.py --no-binance         # ohne Binance
    python run_all.py --host 0.0.0.0       # Dashboard im LAN

Für echten Dauerbetrieb über Neustarts hinweg ist systemd die bessere Wahl:

    python3 install.py --enable

Dieses Skript ist für den Vordergrundbetrieb gedacht, etwa zum Beobachten
in einer SSH-Sitzung oder in tmux.
"""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_PY = ROOT / ".venv" / "bin" / "python"
PY = str(VENV_PY if VENV_PY.exists() else sys.executable)

COLORS = {"recorder": "\033[36m", "binance": "\033[33m", "dashboard": "\033[35m"}
RESET = "\033[0m"


class Service:
    def __init__(self, name: str, cmd: list[str], color: bool = True):
        self.name = name
        self.cmd = cmd
        self.proc: subprocess.Popen | None = None
        self.restarts = 0
        self.backoff = 5
        self.color = COLORS.get(name, "") if color else ""
        self.reset = RESET if color else ""

    def log(self, line: str) -> None:
        print(f"{self.color}[{self.name:<9}]{self.reset} {line}", flush=True)

    def start(self) -> None:
        self.proc = subprocess.Popen(
            self.cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1, cwd=str(ROOT))
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self) -> None:
        try:
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except (ValueError, OSError):
            pass

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def stop(self) -> None:
        if not self.alive():
            return
        self.proc.terminate()
        try:
            self.proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            self.log("reagiert nicht auf SIGTERM, wird hart beendet")
            self.proc.kill()


def main() -> None:
    p = argparse.ArgumentParser(description="Alle Dienste gemeinsam starten")
    p.add_argument("--db", default=str(ROOT / "hl_liq.db"))
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR"])
    p.add_argument("--snapshot-sec", type=int, default=600)
    p.add_argument("--oi-interval", type=int, default=600)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--no-binance", action="store_true")
    p.add_argument("--no-dashboard", action="store_true")
    p.add_argument("--durable", action="store_true",
                   help="jeden Commit sofort auf die Platte schreiben")
    p.add_argument("--no-color", action="store_true")
    args = p.parse_args()

    color = not args.no_color and sys.stdout.isatty()

    services = [Service("recorder", [
        PY, str(ROOT / "hl_recorder.py"), "--db", args.db,
        "--coins", *args.coins, "--snapshot-sec", str(args.snapshot_sec)]
        + (["--durable"] if args.durable else []), color)]

    if not args.no_binance:
        services.append(Service("binance", [
            PY, str(ROOT / "hl_binance.py"), "--db", args.db,
            "--coins", *args.coins, "--oi-interval", str(args.oi_interval)]
            + (["--durable"] if args.durable else []), color))

    if not args.no_dashboard:
        services.append(Service("dashboard", [
            PY, str(ROOT / "hl_viz.py"), "--serve", "--db", args.db,
            "--host", args.host, "--port", str(args.port)], color))

    stopping = threading.Event()

    def shutdown(*_):
        if not stopping.is_set():
            stopping.set()
            print("\nBeende alle Dienste …", flush=True)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    print(f"Interpreter : {PY}")
    print(f"Datenbank   : {args.db}")
    print(f"Coins       : {', '.join(args.coins)}")
    print(f"Snapshots   : alle {args.snapshot_sec//60} min")
    if not args.no_dashboard:
        print(f"Dashboard   : http://{args.host}:{args.port}")
    print("Strg-C beendet alles.\n")

    for i, s in enumerate(services):
        s.start()
        s.log("gestartet")
        if i < len(services) - 1:
            time.sleep(2)      # gestaffelt, damit die Logs lesbar bleiben

    try:
        while not stopping.is_set():
            time.sleep(2)
            for s in services:
                if stopping.is_set():
                    break
                if not s.alive():
                    rc = s.proc.poll()
                    s.restarts += 1
                    s.log(f"beendet (Code {rc}), Neustart in {s.backoff}s "
                          f"[{s.restarts}. Mal]")
                    for _ in range(s.backoff):
                        if stopping.is_set():
                            break
                        time.sleep(1)
                    if stopping.is_set():
                        break
                    s.start()
                    s.backoff = min(s.backoff * 2, 300)
                elif s.backoff > 5 and s.restarts:
                    # läuft wieder stabil -> Wartezeit zurücksetzen
                    s.backoff = 5
    finally:
        for s in services:
            s.stop()
        print("Alle Dienste beendet.")


if __name__ == "__main__":
    main()
