# KONZEPT Prognosemärkte (U235) — Kalshi, Polymarket und Hyperliquid-Ereignismärkte: Archiv, Rückblick, Auswertung

Stand 27.10.2026, 17:56 (gemessen). **Vorab festgelegt, bevor eine einzige echte Zahl dieser Quellen im System gerechnet wurde.**
Entwurf; nach der unabhängigen Durchsicht mit Nachtrag 13.1 (18:40) fest bis auf die Entscheidungen des Nutzers (Abschnitt 12)
und Formatbefunde des Erstlaufs. **Gebaut mit Paket 23.88; Nachtrag 13.2 beim Einbau (19:56).**
Bau mit Paket 23.88 (braucht das Zip von 23.87); Einspielen frühestens nach dem Poller-Bericht am 30.10.2026 um 08:50, damit die
vorab festgelegte Poller-Messung nicht durch einen Neustart gestört wird.

**Anlass.** Wunsch des Nutzers (27.10.2026, 17:49): „dann baue bitte einen neuen Abschnitt in das Projekt ‚Prediction Markets‘,
ziehe alle verfügbaren Daten über die verfügbaren Prognosen und erstelle eine Datenbank dafür, wo die Prognosen ausgewertet werden
ähnlich wie bei den anderen Treibern um ihre Vorhersagequalität zu prüfen. Falls sich alte Daten beziehen können und gegen die
Kursentwicklung testen lassen können um Zeit zu sparen, also eine retrospektive Analyse, dann integriere diese auch.“ Davor
(17:06): „Die Idee mit Kalshi und evtl Polymarket finde ich sehr interessant. Könnte man beide Quellen integrieren.“

**Grundlage.** `RECHERCHE_Richtungstreiber_27-10-2026.md` (Rang 3: Kalshi-Erwartungen) und die Recherche „Kalshi und Polymarket als
Datenquellen“ vom 27.10. (Notizen `kalshi.md`, `polymarket_alternativen.md`, `evidenz_nutzung.md`; Bericht folgt als
`RECHERCHE_Prognosemaerkte_27-10-2026.md`). Kein Endpunkt konnte aus der Recherche-Umgebung aufgerufen werden (Proxy-Sperre); alle
Formate stammen aus Dokumentation und Spiegeln und werden im Erstlauf auf dem Pi geprüft (8.4).

---

## 0. Kurzfassung

- **Eigener Abschnitt „PM Prognosemärkte“**, eigenes Modul `hl_prognosemarkt.py`, eigene Datei `prognosemarkt.db` neben
  `hl_liq.db`. **Wirkt auf nichts** — keine Prognose, kein Treiber-Gewicht, keine Fusion, kein Labor —, bis ein Urteil vorliegt und
  der Nutzer eigens entscheidet.
- **Drei Quellen, nur lesen, ohne Konto:** Kalshi (öffentliche REST-API), Polymarket (Gamma, CLOB, Data API v2), Hyperliquid HIP-4
  (dieselbe `info`-API, die das System schon nutzt).
- **Drei Rollen:**
  1. *Richtung kurz:* Auf/Ab-Märkte (15 min bis 1 Tag) als Wahrscheinlichkeit, dass der Kurs steigt.
  2. *Niveaus:* Schwellen-, Spannen- und Berührungsleitern (Stunden bis Jahresende) als Wahrscheinlichkeiten, gemessen gegen das
     eigene Schwankungsmodell.
  3. *Makro:* Erwartung vor US-Veröffentlichungen (Inflation, Arbeitsmarkt, Fed) → Überraschungsreihe → BTC-Reaktion. Dazu Ereignis-
     und Schwankungshinweise (beschreibend).
- **Rückblick sofort:** Kalshi liefert Kerzen abgelaufener Märkte ohne Konto; damit sind die Hauptprüfungen H1–H3 schon auf der
  Historie rechenbar (15-Minuten-Märkte seit ihrem Start, Tagesleitern, Inflation seit Juni 2021). Polymarket gibt alte Kurse nur
  grob heraus (5 min bis 60 Tage, 30 min bis 90 Tage, danach 3 h bzw. 12 h); HIP-4 nur Ergebnisse.
- **Drei Hauptprüfungen mit Urteil (Holm), vorwärts eine Wiederholung mit festem Termin;** alles andere beschreibend.

## 1. Regeln (fest)

1. **Nur lesen.** Kein Konto, kein Schlüssel, kein Handel. Daten nur privat gespeichert, keine Weitergabe. Die Nutzungsbedingungen
   beider Plattformen sind nicht vollständig geprüft (Recherche 27.10.); private Sammlung über öffentliche Schnittstellen ist dort nicht
   ausdrücklich untersagt gefunden worden.
2. **Zeitpunktgenau.** Jeder Wert mit Abrufzeit. Rückblick-Werte tragen ihre Quelle (`k1m`, `k60m`, `k1d`, `p5m`, `p30m`, `p3h`,
   `p12h`, `live`) und werden nie mit Live-Werten vermischt. Ein Wert, der später anders geliefert wird, wird neue Fassung, nicht
   überschrieben.
3. **Spotmodell als Vergleich, nicht 50 %.** Ein Auf/Ab-Kurs mitten im Fenster ist zum größten Teil ein Echo des Spots (Young 2026:
   Reaktion nach rund 0,35 s). Jede Richtungsprüfung misst deshalb, was der Markt **über** ein driftfreies Spot-und-Schwankungs-Modell
   hinaus weiß (5.1). Am Fensterbeginn ist das Modell genau 50 %.
4. **Keine 5-Minuten-Märkte** (dokumentierte Manipulation der Abrechnung, Dai, Jia & Yu 2026). Die letzte Minute eines Fensters zählt
   nie.
5. **Reibungsband.** Gebühr (Kalshi und Polymarket-Krypto je 0,07·p·(1−p), bei 50 % rund 1,75 ¢) plus halber Spread: Abweichungen
   darin gelten in Trefferquoten als „keine Meinung“; im Brier-Maß zählen alle Werte.
6. **Lange Horizonte** werden zusätzlich rekalibriert angezeigt (logistische Steigung nach Le 2026: 1,09 bei 1 Woche–1 Monat, 1,36
   darüber), Rohwert immer daneben. In Prüfungen gehen nur Rohwerte ein.
7. **Volumen von Polymarket nie als Merkmal** (Wash-Trading); Güte über Spread, offenes Interesse, Alter des letzten Handels.
8. **Uhrzeiten der US-Märkte über `zoneinfo("America/New_York")`.** Die Umstellung am 01.11.2026 verschiebt 4-h-Fenster und
   12:00-/17:00-ET-Termine um eine Stunde gegen UTC.
9. **Kein Wert aus der Zukunft.** Spot, Schwankungsmodell und jede Vergleichsgröße stammen nur aus Daten bis zum Zeitpunkt des
   Marktkurses.

## 2. Quellen und Märkte

Erste Auswahl. Der Erstlauf (8.4) prüft jede Reihe; fehlende Reihen erscheinen im Bericht, sie brechen nichts. Eine wöchentliche
Suche schlägt weitere Reihen vor (Schlagworte Bitcoin, Ethereum, Hyperliquid, Zcash, Monero, Gold, CPI, inflation, payrolls,
unemployment, Fed, FOMC, recession, CLARITY, stablecoin, SEC, ETF, shutdown, tariff); aufgenommen wird nur, was der Nutzer bestätigt.

### 2.1 Kalshi (`https://external-api.kalshi.com/trade-api/v2`, ohne Konto)

| Reihe | Inhalt | Horizont | Abrechnung | Coins des Systems |
|---|---|---|---|---|
| `KXBTC15M`, `KXETH15M`, `KXHYPE15M`, `KXZEC15M` | Auf/Ab je 15 min, rund um die Uhr | 15 min | CF-Benchmarks-Index, 60-s-Mittel vor Ende gegen 60-s-Mittel vor Beginn | BTC, ETH, HYPE, ZEC (kein XMR) |
| `KXBTCD` (und `KXETHD`, falls vorhanden) | „über X“ zu Stundenterminen ET (u. a. 17:00 ET) | Stunden bis 1 Tag | CF-Index, 60-s-Mittel | BTC (ETH) |
| `KXBTC` (und `KXETH`) | Spannen zum Termin | Stunden bis 1 Tag | wie oben | BTC (ETH) |
| `KXBTCMAXY`, `KXBTCMINY`, `KXBTCY`, `KXETHY`, `KXBTCMAX150` | Berührung bis 31.12., Jahresendkurs | Wochen bis Monate | CF-Index | BTC, ETH |
| `KXGOLDD`, `KXGOLDH` | Gold täglich (17:00 ET) und stündlich | 1 h bis 1 Tag | 1-min-Schluss Gold (Quelle im Erstlauf aus den Regeln) | PAXG (Vergleich) |
| `KXCPI`, `KXCPIYOY`, Kern-CPI (Kennung im Erstlauf), `KXPAYROLLS`, `KXU3`, `KXJOBLESSCLAIMS`, `KXGDP` | US-Daten | Tage bis Monate | Erstveröffentlichung, keine Revisionen | — |
| `KXFED`, `KXFEDDECISION`, `KXRATECUTCOUNT`, `KXRECSSNBER` | Fed, Rezession | Tage bis Monate | Fed-Beschluss, NBER | — |
| Ereignisse aus der Suche (z. B. CLARITY Act) | Gesetzgebung, Behörden | Wochen bis Jahre | laut Regeln | — |

- Endpunkte ohne Konto: `/series/{s}`, `/markets?series_ticker=…&status=…` (bis 1.000 je Seite, Cursor), `/events/{e}`,
  `/markets/{t}/orderbook`, `/series/{s}/markets/{t}/candlesticks` (1, 60, 1.440 min), `/markets/trades`, `/historical/cutoff`,
  `/historical/markets…`. Grenzen ohne Konto sind nicht dokumentiert: höchstens 2 Abrufe je Sekunde, bei 429 Pause mit Verdopplung.
- Preise kommen als Zeichenketten („0.5600“, Teilcent seit 07/2026) → gespeichert als ganze Zahl in 1/10.000 $.

### 2.2 Polymarket (ohne Schlüssel; Deutschland ist für **Handel** „nur Schließen“, Lesen ist nicht eingeschränkt)

| Familie | Kennung | Horizont | Abrechnung | Coins |
|---|---|---|---|---|
| Auf/Ab 15 min, 1 h, 4 h, Tag | `btc-updown-15m-<Start Unix>`, `btc-updown-4h-<Start>`, `bitcoin-up-or-down-<datum>-<uhrzeit>-et`, `bitcoin-up-or-down-on-<datum>`; ETH und HYPE, soweit vorhanden | 15 min bis 1 Tag | Chainlink (15 min, 4 h); Binance BTC/USDT 1-h-Kerze bzw. 1-min-Schluss 12:00 ET (1 h, Tag) | BTC, ETH, (HYPE) |
| Schwellenleiter „Bitcoin above ___ on <date>“ | `bitcoin-above-on-<datum>` | 1 Tag | Binance BTC/USDT 1-min-Schluss 12:00 ET | BTC (ETH) |
| Berührungsleitern täglich, monatlich, jährlich | `what-price-will-bitcoin-hit-…`, ETH, „Hyperliquid 2026“, Gold XAUUSD | 1 Tag bis Jahresende | laut Regeln (Erstlauf) | BTC, ETH, HYPE, PAXG (Gold) |
| Makro und Ereignisse | Fed-Entscheid je Sitzung, CPI (Monat, Kern), Rezession, CLARITY Act | Tage bis Monate | UMA-Orakel | — |

- Entdecken: Gamma `/events/slug/{slug}` (Auf/Ab-Kennungen werden berechnet), `/events/keyset` mit Schlagwort-Tags, `/public-search`;
  **beide Protokollversionen abfragen** (`version` v1 und v2): v1 nutzt `clobTokenIds`, v2 `positionIds`; wer nur v1 liest, verliert
  jeden neuen Markt still.
- Kurse: CLOB `/book`, `/midpoints`; Verlauf `/v2/prices-history` (Data API, `bucket_seconds` 300/1.800/10.800/43.200) und CLOB
  `/prices-history`; Ergebnisse aus Gamma und `/v2/resolutions`. Data API v1 ist seit 24.10.2026 abgeschaltet.
- Dokumentierte Grenzen (IP, je 10 s): Gamma `/events` 500, CLOB `/prices-history` 1.000, Data v2 `/v2/prices-history` 200 — das
  System nutzt weniger als 1 %.

### 2.3 Hyperliquid HIP-4 (`POST https://api.hyperliquid.xyz/info`)

- `{"type":"outcomeMeta"}`: offene Ausgänge, z. B. `class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d`.
- Buch: `{"type":"l2Book","coin":"#<10·outcome>"}` (Ja-Seite); abgerechnet: `{"type":"settledOutcome","outcome":<id>}`
  (`settleFraction`, `details` mit dem Abrechnungskurs).
- Abrechnung um 06:00 UTC auf den HyperCore-Markpreis (linear zwischen zwei Aktualisierungen) — derselbe Preis wie die Perps des
  Systems, also ohne Abstand zwischen Referenzkursen.
- Last: `outcomeMeta` alle 5 min, `l2Book` je offenem Ausgang einmal je Minute, `settledOutcome` einmal täglich. Das ist ein kleiner
  Bruchteil des Poller-Gewichts; der Anteil steht im Bericht.

## 3. Speicher (`prognosemarkt.db`)

| Tabelle | Inhalt | Schlüssel |
|---|---|---|
| `pm_markt` | Plattform, Markt-ID, Ereignis, Reihe, Titel, Art (`aufab`, `schwelle`, `spanne`, `beruehrung`, `makro`, `ereignis`), Basiswert, Schwelle unten/oben, Beginn und Ablauf (UTC), Abrechnungsquelle, Regeltext, Version und Kennungen, erstmals/zuletzt gesehen | (plattform, markt) |
| `pm_kurs` | Zeitpunkt der Beobachtung, Geld, Brief, Mitte, letzter Handel, offenes Interesse, Quelle (`live`, `k1m`, `p5m` …), Abrufzeit | (plattform, markt, ts, quelle), ohne rowid |
| `pm_ergebnis` | Ergebnis (1/0, Anteil bei Teilabrechnung), Abrechnungswert, Zeitpunkt, Fassung, Abrufzeit | (plattform, markt, fassung) |
| `pm_ueberraschung` | Makro-Termin, Median, Streuung, Zahl der Schwellen, Spread, Istwert (Plattform und ALFRED), z, BTC/ETH-Renditen 30 und 60 min | (reihe, termin) |
| `pm_auswertung` | Ergebnis je Prüfung und Lauf (n, Maß, Intervall, p, Hälften, Urteil, Version) | (pruefung, lauf) |
| `pm_abruf`, `pm_meta` | Protokoll (90 Tage), Zustand, Cursor des Rückblicks, Budget | — |

- Schreiben nur mit `BEGIN IMMEDIATE`; gleiche Werte erzeugen keine Zeile.
- Größe geschätzt 3–10 MB je Tag [eigene Rechnung aus den Taktzahlen in 4]; Sicherung mit dem täglichen Backup wie `makro.db`.

## 4. Takt

Ein eigener Thread im Dashboard-Prozess (wie der Makro-Takt), aus mit `HL_PM=0`, nie für Selbsttest-Datenbanken.

| Aufgabe | Takt |
|---|---|
| Kalshi 15-min-Reihen: offene Märkte samt Kursen (`/markets?series_ticker=…&status=open`) | 1 je Minute je Reihe |
| Kalshi Tages- und Stundenleitern, Gold | 5 min (nur Ereignisse mit Ablauf in ≤ 48 h) |
| Kalshi Makro | 15 min; am Veröffentlichungstag 07:30–08:35 ET jede Minute samt Orderbuch der Schwellen nahe dem Median |
| Kalshi Jahresleitern, Ereignisse | 1 h |
| Polymarket Auf/Ab (15 min, 1 h, 4 h, Tag): Entdecken der nächsten Fenster | 5 min; Kurs des laufenden und des nächsten Fensters jede Minute |
| Polymarket Leitern, Makro, Ereignisse | 5 min (Tagesleitern), 15 min (übrige) |
| HIP-4 | `outcomeMeta` 5 min, `l2Book` 1 min |
| Abschluss | nach Ablauf: Ergebnis, Kalshi-1-min-Kerzen des ganzen Markts, Polymarket-Verlauf 1 min (innerhalb von 7 Tagen) |
| Rückblick | in Schritten mit Cursor, nachts bevorzugt, höchstens 2 Kalshi-Abrufe je Sekunde |

- Fehler je Quelle: Pause 15 min, verdoppelt bis 6 h; antwortet ein Host nicht, pausieren alle Ziele dieser Quelle mit. HTTP 403 oder
  451 von Polymarket wird als „gesperrt (Region?)“ gesondert gezählt (Hinweis auf eine mögliche Netzsperre in Deutschland).
- Der Takt rechnet keine Auswertung; die läuft im Bericht (8.3) und einmal täglich für die Anzeige.

## 5. Rückblick (retrospektive Analyse)

| Datenteil | Was es gibt | Was das System holt |
|---|---|---|
| Kalshi 15-min (BTC, ETH, HYPE, ZEC) | alle abgelaufenen Märkte seit Start der Reihe, 1-min-Kerzen mit Geld/Brief | je Markt die Kerzen von Beginn − 5 min bis Ende, Ergebnis |
| Kalshi `KXBTCD`/`KXBTC` | alle Ereignisse seit Start | nur die 17:00-ET-Ereignisse; je Schwelle innerhalb ±3 σ die 60-min-Kerzen der letzten 48 h |
| Kalshi Makro | Inflation seit 06/2021, Arbeitslosenquote seit 07/2021, Payrolls seit 03/2023, Fed-Entscheid seit 05/2023 | 1-min-Kerzen des Veröffentlichungstags bis 10:00 ET, Tageskerzen der Laufzeit, Ergebnis |
| Kalshi Jahresleitern, Gold, Ereignisse | seit Start | Tageskerzen bzw. 60-min-Kerzen |
| Polymarket Auf/Ab 1 h, 4 h, Tag | 5-min-Punkte ≤ 60 Tage, 30-min ≤ 90 Tage | nur Fenster mit einem Punkt vor Beginn |
| Polymarket Leitern und Makro | 30-min ≤ 90 Tage, 3-h ab 07/2026, 12-h dauerhaft | Leitern ab 2024 mit 12-h-Punkten (für Vorlauf 7/14/28 Tage) |
| HIP-4 | Ergebnisse je Ausgang seit 02.05.2026 | `settledOutcome` je ID; Kurse nur, falls `candleSnapshot` mit `#…` Daten liefert (Erstlauf) |
| Spot für Vergleichsmodelle | Binance-Perp 30-min ab 2020 (`swing.db`), Hyperliquid 1-min ab 31.08.2026, Binance-1-min-Archiv (data.binance.vision) | 1-min-Kurse nur für die Zeitpunkte, die eine Prüfung braucht |

Reihenfolge: Makro (klein) → Kalshi 15-min BTC → Tagesleitern → übrige Coins → Polymarket → HIP-4. Fortschritt je Teil im Bericht und
im Reiter „Rückblick“. Geschätzter Umfang Kalshi 15-min: rund 96 Märkte je Coin und Tag, je ein Kerzenabruf [eigene Rechnung].

## 6. Auswertung — vorab festgelegt

### 6.1 Größen

- **Marktkurs p_M:** Mitte aus Geld und Brief der Beobachtung (Live: Schnappschuss; Kalshi-Rückblick: Schlusswerte `yes_bid`/`yes_ask`
  der 1-min-Kerze); gültig nur, wenn beide Seiten da sind und der Spread höchstens 4 ¢ beträgt. Sonst fällt der Fall aus (gezählt).
- **Prüfzeitpunkt bei Auf/Ab:** t₀ = erste gültige Beobachtung im Intervall [Beginn − 120 s, Beginn + 90 s]. Liegt sie vor dem Beginn,
  ist der Vergleich genau 50 %.
- **Spotmodell p_S:** driftfreie Normalverteilung der Log-Rendite bis zum Ablauf, σ aus dem kausalen HAR des Systems (`hl_ausblick`,
  letzte Schätzung ≤ t₀, auf die Restlaufzeit skaliert), Spot S(t₀) aus Hyperliquid-1-min-Schlüssen (ab 31.08.2026) bzw. dem
  Binance-1-min-Archiv davor. Auf/Ab: p_S = Φ(ln(S(t₀)/S_Beginn) ÷ (σ·√τ)), mit S_Beginn aus derselben Quelle. Schwelle K:
  p_S = Φ(ln(S/K) ÷ (σ·√τ) − σ·√τ/2). Berührung: Spiegelungsnäherung 2·P(jenseits), höchstens 1.
- **Zugewinn je Fall:** g = (p_S − y)² − (p_M − y)² (positiv = Markt besser), y = 1 bei „Auf“/„Ja“ laut Abrechnung der Plattform;
  50/50-Abrechnungen und Annullierungen fallen aus.
- **Brier-Skill gegen das Spotmodell:** 100 · Σg ÷ Σ(p_S − y)².
- **Makro:** Verteilung aus den Ja-Kursen der Schwellen zum letzten gültigen Kurs vor 08:30 ET (Kalshi; Handelsende laut Regeln, im
  Erstlauf geprüft), Verteilungsfunktion monoton gemacht (vom Modus nach außen), Median m und Streuung s (Abstand der 16- und
  84-%-Punkte ÷ 2). Istwert x = `expiration_value` der Plattform (Erstveröffentlichung), Gegenprobe ALFRED. **z = (x − m) ÷ s.**
  Gültig mit mindestens 4 gültigen Schwellen.

### 6.2 Hauptprüfungen mit Urteil (Holm über die prüfbaren von H1–H3, α = 0,05)

| Nr. | Frage | Daten | Maß und Test | belegt, wenn |
|---|---|---|---|---|
| **H1** | Weiß der 15-min-Markt bei Fensterbeginn mehr über die Richtung als das Spotmodell? | Kalshi `KXBTC15M`, alle Fenster mit gültigem t₀ im Rückblick | Mittel von g; Bootstrap über ganze UTC-Tage (2.000 Ziehungen), einseitig | p Holm < 0,05 **und** Mittel g > 0 in beiden Hälften (Teilung am mittleren Tag); mindestens 2.000 Fenster |
| **H2** | Sind die Wahrscheinlichkeiten der Tagesleiter besser als das Spotmodell? | Kalshi `KXBTCD`, Ereignisse 17:00 ET, Vorlauf 24 h (Kerze, die 24 h vor Ablauf endet), Schwellen mit \|ln(K/S)\| ≤ 2 σ√τ | Mittel von g je Ereignistag, Bootstrap über Tage, einseitig | wie H1; mindestens 100 Ereignistage |
| **H3** | Sagt die Kalshi-Überraschung bei der Inflation die BTC-Reaktion voraus? | Kalshi `KXCPI` (Monatsrate), alle Termine im Rückblick | Spearman ρ zwischen z und der BTC-Rendite 08:30–09:00 ET (Binance-Perp, 30-min-Kerze aus `swing.db`); Permutationsnull (10.000 Vertauschungen von z), einseitig ρ < 0 | p Holm < 0,05 **und** ρ < 0 in beiden Hälften; mindestens 30 Termine |

- **Teststärke** [eigene Rechnung, einseitig 5 %, 80 %]: H1 mit 2.000 / 5.000 / 9.600 Fenstern erkennt Trefferquoten ab 52,8 / 51,8 /
  51,3 %; H3 mit 30 / 40 / 64 Terminen erkennt |ρ| ab 0,48 / 0,41 / 0,32 (NY Fed SR 1052: R² 16 % ≈ |ρ| 0,4).
- **„Nicht prüfbar“** mit Grund, wenn die Mindestzahl fehlt — z. B. wenn Kalshi die 15-min-Märkte erst ab Fensterbeginn notiert und
  t₀ selten gültig ist. Nicht prüfbare Prüfungen zählen nicht im Holm.
- **Ein Urteil je Prüfung auf der Historie:** im ersten Bericht, in dem die Mindestzahl erreicht und der Rückblick des Teils fertig
  ist. Spätere Läufe zeigen dieselben Zahlen mit „Urteil vom …“; neue Daten gehen in die Vorwärtsprüfung (6.4), nie ins Rückblick-
  Urteil.

### 6.3 Beschreibend, ohne Urteil

- H1-Maß für ETH, HYPE, ZEC (Kalshi 15 min), Polymarket 15 min, 1 h, 4 h und Tag (BTC, ETH), HIP-4 täglich; H2-Maß für Polymarket-
  Tagesleiter (12:00 ET) und Vorläufe 6 h und 1 h.
- **Über das Fenster hinaus:** Spearman zwischen p_M − p_S bei t₀ und der Hyperliquid-Rendite der nächsten 1 h und 4 h.
- **Kalibrierung** je Familie und Horizont: Zuverlässigkeit in 10 Klassen mit 90-%-Intervall, logistische Steigung (Soll 1).
- **Markt gegen eigene Prognosen** (vorwärts, gleiche Zeitfenster): Fusion 4 h gegen Polymarket 4 h; 24-h-Schattenprognose gegen
  HIP-4 und Kalshi-Tagesleiter; Ausblick-Berührungen (7/14/28 Tage) gegen Polymarket-Monatsleiter und Kalshi-Jahresleiter. Maß: gepaarte
  Brier-Differenz. Dafür speichert der Ausblick zu jedem Anker die eigene Wahrscheinlichkeit für die gerade offenen Marktschwellen.
- **Makro weiter:** Arbeitslosenquote, Payrolls, Fed-Entscheid wie H3; Rendite 60 min; Antwortzeit der Märkte nach 08:30 ET.
- **Schwankung (nach Mohanty & Krishnamachari 2026):** tägliche absolute Neubewertung von `KXFED`, `KXCPI`, `KXRECSSNBER` gegen die
  realisierte BTC-Varianz der nächsten 5 Tage, QLIKE gegen das HAR des Systems. Wird sie später geprüft, dann als eigene Runde.
- **Ereignishinweis:** Sprung eines liquiden Ereignis- oder Makromarkts um ≥ 10 Punkte in 1 h außerhalb von Terminen; nur Anzeige.
- **Abgleich zwischen Plattformen** für gleiche Fragen (z. B. Fed-Entscheid): Abweichung über Gebühr plus Spread als Gütehinweis.

### 6.4 Vorwärts (live)

- Dieselben Maße auf Live-Schnappschüssen (Quelle `live`), getrennt vom Rückblick.
- **Wiederholung von H1 vorwärts:** Urteil, sobald 2.000 Live-Fenster BTC vorliegen (rund 21 Tage); dieselbe Regel, eigenes α = 0,05.
- Für Polymarket 4 h und HIP-4: beschreibend, bis 365 Tage vorliegen; dann eine eigene Festlegung.

### 6.5 Folgen (vorab)

- **Belegt** → Kandidat: Anzeige mit Bilanz; ein Einsatz (z. B. als Experte der Fusion, als Schatten-Treiber, als Breite) nur nach
  einer eigenen Entscheidung des Nutzers und einer zweiten, unabhängigen Prüfung.
- **Nicht belegt** → bleibt Anzeige mit Bilanz. Kein Urteil wird nachträglich gelockert; was später dazukommt, ist eine neue Runde.

## 7. Anzeige: Abschnitt „PM Prognosemärkte“

| Reiter | Inhalt |
|---|---|
| Überblick | Je Coin die Auf/Ab-Wahrscheinlichkeit des laufenden und nächsten Fensters (Kalshi 15 min, Polymarket 1 h/4 h/Tag), HIP-4 täglich mit Zielkurs, daneben das Spotmodell; Hinweis „Echo des Spots, kein Signal“ solange nichts belegt ist |
| Krypto | Tagesverteilung aus den Leitern (Kalshi 17:00 ET, Polymarket 12:00 ET) gegen das Spotmodell; Monats- und Jahresleitern roh und rekalibriert, neben den Ausblick-Wahrscheinlichkeiten |
| Makro | Nächste Termine mit Median, Streuung und Verteilung; nach dem Termin z und BTC-Reaktion; Verlauf der Erwartung über Wochen |
| Ereignisse | Liste mit Wahrscheinlichkeit, Änderung 1 h/24 h, Liquidität, Hinweisen |
| Bilanz | H1–H3 mit Urteil, Beschreibendes, Kalibrierungsdiagramme, Vergleich mit eigenen Prognosen |
| Rückblick | Fortschritt je Teil, Abdeckung, Ausfälle mit Grund |
| Daten | Quellen, letzte Abrufe, Fehler und Pausen, Gewichtsanteil am Hyperliquid-Poller, Frische je Reihe, Sperrhinweise |

Zeichenart wie die übrigen Abschnitte; Farben und Prüfungen wie in `KONZEPT_Makro.md` 5; keine Kauf- oder Verkaufswörter; jede Zahl
mit Quelle und Zeitpunkt.

## 8. Proben

### 8.1 Selbsttest (ohne Netz)

- Parser je Plattform gegen Antworten aus der Dokumentation (Kalshi Zeichenkettenpreise und Teilcent; Polymarket v1/v2-Kennungen,
  `outcomePrices` als JSON-Text; HIP-4 `description`-Felder) — nach dem Erstlauf ersetzt durch echte Antworten vom Pi.
- Kennungen: berechnete Polymarket-Slugs, Kalshi-Ticker zerlegt (`T`/`B`), ET-Zeiten rund um den 01.11.2026 und den 08.03.2027.
- Leiter → Verteilung: monoton, Median und Streuung von Hand; Spannen und Schwellen gemischt.
- Spotmodell von Hand (Auf/Ab, Schwelle, Berührung); kein Blick in die Zukunft (Daten nach t₀ ändern nichts).
- **Nulltest:** künstliche Märkte ohne Wissen (p_M = Spotmodell + Rauschen im Reibungsband) → H1/H2 „belegt“ in höchstens 5 % von
  200 Welten (mit Binomialgrenze).
- **Positivkontrolle:** Markt mit eingepflanztem Wissen (p_M aus der wahren Wahrscheinlichkeit mit einem Teil der künftigen Rendite)
  → belegt in mindestens 80 % von 200 Welten bei einer vorab gerechneten Stärke; gemessene Nachweisgrenze im Bericht.
- H3 von Hand (Rangkorrelation, Permutation), Hälftenregel, Holm, Mindestzahlen, „nicht prüfbar“.
- Takt mit falschem Netz: Pausen, Verdopplung, 429 ohne Retry-After, Host-Ausfall, Sperre 403/451, Cursor setzt fort.

### 8.2 Mutationen (müssen rot werden)

Kurs nach t₀ statt bei t₀; Spotmodell mit künftigem σ; Spread-Filter aus; letzte Minute mitgezählt; 5-min-Märkte zugelassen; ET mit
festem Versatz; v2-Märkte übersehen; Verteilungsfunktion nicht monoton; z mit Vorzeichen vertauscht; Bootstrap ohne Tagesblöcke;
Hälften ignoriert; Holm weggelassen; Mindestzahl ignoriert; Rückblick- und Live-Werte vermischt; gleiche Werte doppelt geschrieben.

### 8.3 Berichte (Debug-Nummern ab 129, Berichtsplan)

- „★ Prognosemärkte: Stand und Quellen“ (Abrufe, Fehler, Frische, Rückblick-Fortschritt), täglich.
- „★ Prognosemärkte: Auswertung“ (H1–H3 und Beschreibendes), täglich nach Abschluss des Rückblicks, sonst „vorläufig“.
- „Prognosemärkte: Erstlauf“ (8.4), einmal nach dem Einspielen.
- „Prognosemärkte: Selbsttest“.

### 8.4 Erstlauf auf dem Pi (Formatprüfung, vor jeder Auswertung)

Je Reihe und Familie: erreichbar ja/nein (HTTP-Code), Zahl offener und abgelaufener Märkte, je ein Beispiel roh (gekürzt), Felder
vorhanden, Handelsbeginn relativ zum Fensterbeginn (Kalshi 15 min, Polymarket), Handelsende vor 08:30 ET (Kalshi Makro), Rückblick-
Grenze `/historical/cutoff`, Polymarket-Geoblock-Antwort, HIP-4 `candleSnapshot` mit `#…` ja/nein. Erst danach werden Parser und
Auswahl festgeschrieben; Abweichungen von diesem Konzept stehen mit Grund im Nachtrag, bevor eine Auswertung läuft.

### 8.5 Browserprobe

Je Reiter Werte an der beschrifteten Achse gegen die Nutzlast, Handybreite, keine Skriptfehler; Mutationen der Seite rot.

## 9. Wirkung und Zusagen

- Keine Änderung an Fusion, v1/v2/v3, Konfluenz, Labor, Kaskaden, Ausblick-Rechnung oder Treibern. Der Ausblick bekommt nur einen
  lesenden Zusatz (6.3: eigene Wahrscheinlichkeit für offene Marktschwellen speichern), der seine Zahlen nicht ändert.
- Die Hyperliquid-Abrufe sind klein und laufen erst nach der Poller-Messung (Einspielen nach dem 30.10. 08:50).

## 10. Erwartung vorab (damit nichts überrascht)

- **H1:** nicht belegt. Am Fensterbeginn weicht der Kurs kaum von 50 % ab; im Fenster folgt er dem Spot. Wenn überhaupt, dann ein
  kleiner Zugewinn aus kurzfristiger Umkehr, die der Markt mitpreist.
- **H2:** knapp. Märkte sehen Schiefe und Drift, die das driftfreie Normalmodell nicht hat; ihre Längstschuss-Verzerrung kostet. Eher
  belegt bei 6 h als bei 24 h.
- **H3:** belegt mit ρ um −0,3 bis −0,4, getragen von 2022/23; in der zweiten Hälfte schwächer (Hälftenregel könnte scheitern).
- Polymarket und HIP-4 liefern zuerst vor allem Archiv; Urteile vorwärts brauchen Monate bis ein Jahr.

## 11. Grenzen

- Kein Endpunkt live geprüft; Reihenkennungen außer den bestätigten (2.1) und Handelszeiten sind Annahmen bis zum Erstlauf.
- Kalshi-Grenzen ohne Konto und die Rückblick-Fenster hinter `/historical/cutoff` sind nicht dokumentiert.
- Polymarket: Bedeutung von `p` in `/prices-history` undokumentiert; minutengenaue Historie nur 7 Tage → was nicht vorwärts gesammelt
  wird, ist verloren.
- Unterschiedliche Referenzkurse (CF-Index, Chainlink, Binance-Spot, HyperCore-Mark) gegen das Spotmodell aus Hyperliquid/Binance:
  Abstand von wenigen Basispunkten, bei 15 min nicht vernachlässigbar; im Bericht als Basisabstand ausgewiesen.
- Rechtliches: Deutschland ist bei Polymarket „nur Schließen“ (Handel); die GGL hält Prognosemärkte für unzulässig. Das System liest
  nur öffentliche Kurse; eine Netzsperre würde die Quelle abschneiden (eigene Fehlerzählung).

## 12. Entscheidungen beim Nutzer (Standard in Klammern)

1. Kalshi-Konto für Websocket, Prognose-Perzentile und CF-Index-Werte? (nein — öffentliche REST-Daten reichen; Nachtrag R8:
   nur der CF-Index mit Konto und Ausweis würde Vergleiche nach dem Fensterbeginn sauber machen)
2. Coins: BTC, ETH, HYPE, ZEC (Kalshi 15 min), BTC/ETH (Polymarket), Gold als Vergleich für PAXG? (ja)
3. Neue Reihen aus der Wochensuche automatisch aufnehmen? (nein — Vorschlag, Aufnahme nach Bestätigung)
4. Live-Minutenwerte dauerhaft behalten? (ja, geschätzt 1–4 GB je Jahr)
5. Polymarket 5-min-Märkte? (nein, Regel 1.4)

## 13. Unabhängige Durchsicht

Vor dem Bau: eigener Agent, nur Lesen, mit diesem Konzept und den Recherchenotizen; Auftrag: Blick in die Zukunft, Vermischung von
Quellen, Testgültigkeit, Teststärke, Machbarkeit auf dem Pi. Ergebnis und Änderungen als Nachtrag 13.1.

### 13.1 Nachtrag nach der Durchsicht (27.10.2026, 18:40 gemessen)

Vorab festgelegt, **bevor eine einzige Zahl dieser Quellen im System gerechnet wurde.** Ersetzt die genannten Stellen von 1–12
ausdrücklich; was nicht genannt ist, gilt unverändert. Grundlage: unabhängige Durchsicht (eigener Agent, nur Lesen, 27 Befunde:
4 kritisch, 15 wichtig, 8 klein; Datei `review_konzept.md`) und der Bau des Moduls mit Selbsttest. Übernommen sind alle kritischen und
wichtigen Befunde; Abweichungen stehen am Ende mit Grund.

**Eigene Fehler im Entwurf**
1. **Teststärke H1 falsch** (Befund 5, beim Bau der Positivkontrolle selbst bestätigt). Die Zahlen 52,8 / 51,8 / 51,3 % galten für eine
   Trefferquote. Geprüft werden sollte die Brier-Differenz g; sie hat für kleine, kalibrierte Abweichungen nur die halbe Prüfgröße
   (g = 2c − (p_M − p_S)², c = (p_M − p_S)(y − p_S)). Die Positivkontrolle brauchte einen Effektivwert von 7,4 Punkten für 94 % „belegt“
   bei 2.016 Fenstern.
2. **Sommerzeit 2027** beginnt am 14.03.2027, nicht am 08.03.2027 (Befund 20).
3. **Spotmodell nach dem Fensterbeginn falsch** (Befund 1): Der Bezug des Kalshi-15-min-Markts ist das 60-s-Mittel vor dem Beginn,
   nicht der Kurs bei Beginn. Nach dem Beginn ist ohne den CF-Index kein Vergleich sauber (Befund 2: 2 bp Basisrauschen oder 5 s alter
   Spot geben bei realistischer Fallzahl t ≈ 2–3 für einen Markt ohne eigenes Wissen).
4. **Zeitstempel-Semantik nicht festgelegt** (Befund 3) und **Zwischenstände vor dem Urteil**, kein Stichtag, Holm über Urteile zu
   verschiedenen Zeiten (Befund 4).
5. **Beim Bau gefunden:** Der Rückblick der Spotdaten hätte nach einem Live-Lauf eine Lücke gelassen (er setzte beim jüngsten Wert
   fort). Die Ende-zu-Ende-Probe wurde rot; behoben mit eigenem Cursor.

**Neue feste Regeln**

- **R1 Zeit.** Ein Wert darf zum Zeitpunkt t nur verwendet werden, wenn das Ende des Zeitraums, den er zusammenfasst, ≤ t ist.
  `pm_kurs.ts` ist dieses Ende: bei Kerzen das Periodenende, bei Live-Werten die Empfangszeit der Antwort. Spotkerzen tragen ihren
  Beginn; ihr Schluss gilt bei Beginn + 60 s. Polymarket-Verlaufspunkte gelten bis zum Erstlauf als am Eimerbeginn beschriftet mit dem
  Wert am Eimerende (gespeichert mit Ende = t + Eimerlänge).
- **R2 Stichtag.** Der Rückblick umfasst Märkte mit Handelsschluss vor dem Erstlauf; die Zeit wird beim Erstlauf festgehalten. Alles
  danach gehört zur Vorwärtsrunde (R11).
- **R3 Fertig.** Ein Teil ist fertig, wenn mindestens 95 % der gelisteten Märkte geholt oder mit Grund gescheitert sind. Fehlendes steht
  je Monat im Bericht.
- **R4 Keine Ergebnisse vor dem Urteil.** Bis zum gemeinsamen Urteil zeigen Berichte und Anzeige für H1–H3 und für alles Beschreibende
  nur Anzahlen, Abdeckung und Zeiten, keine Größe, die Kurse mit Ergebnissen verbindet (g, c, ρ, Brier, Kalibrierung, Überraschung
  gegen Rendite). „Prüfbar“ entscheidet sich nur aus Anzahl und Abdeckung.
- **R5 Ein gemeinsames Urteil** für H1–H3, einmal, sobald alle drei Teile fertig sind und die Prüfungen vor dem Urteil (R12) bestanden
  sind. **Gewichteter Holm** mit H3 0,5, H1 0,25, H2 0,25 (α gesamt 0,05). Grund: H3 hat die stärksten Vorbelege; ungewichtet wäre
  H3 bei 50–60 Terminen ein Münzwurf (Befund 16).
- **R6 Bootstrap.** Studentisierter, zentrierter Blockbootstrap über Tage mit 7-Tage-Blöcken (zirkulär), B = 9.999,
  p = (1 + #{T* ≥ T}) ÷ (B + 1). Hälften: Teilung am Median-Datum der Fälle (gleich viele Fälle); jede Hälfte mit mindestens 40 % der
  Mindestzahl.
- **R7 H1 neu: „Weiß der 15-min-Markt vor dem Fensterbeginn etwas über die Richtung?“**
  - Nur t₀ = B − 60 s (Beginn der Mittelungsminute; Länge im Erstlauf aus `rules_primary` bestätigt). Zustand: Schluss der jüngsten
    gültigen Kalshi-1-min-Kerze mit Ende in [B − 300 s, B − 60 s]; live nur eine Antwort, die bis B − 60 s empfangen wurde.
  - Vergleich p_S = 0,5 genau, für jede Referenz; Spot, Schwankung und Basis fallen heraus.
  - **Primäres Maß: Kovarianz c = cov(p_M − 0,5, y)** mit Achsenabschnitt, einseitig > 0. g und Brier-Skill als Effektgrößen.
  - Mindestens 4.000 Fenster und 60 Tage. Zu wenige Kurse vor dem Beginn → „nicht prüfbar“, ohne Ausweichen nach dem Beginn.
  - Teststärke (kalibrierter Markt mit fester Abweichung δ, ohne Haufen; Positivkontrolle misst die echte): bei α = 0,0125 erkennt c
    mit 80 % δ ab 3,5 / 2,4 / 1,6 Punkten bei 2.000 / 4.000 / 9.600 Fenstern; g bräuchte das Doppelte. Das Reibungsband ist ±2,25 Punkte.
- **R8 Nach dem Beginn nur beschreibend** (Kalshi und Polymarket im Fenster, HIP-4), immer neben einem Spot-Echo als Platzhalter.
  Sauber wäre das nur mit dem CF-Index (Kalshi-Konto mit Ausweis); das steht jetzt in Entscheidung 1.
- **R9 H2 neu: „Verteilungsgüte der Tagesleiter gegen das beste kausale Modell“.** Ausdrücklich **kein Richtungstest**: Ein „belegt“
  macht die Leiter zum Kandidaten für die Breite des Ausblicks, nicht für Fusion oder Treiber.
  - Spot: Coinbase BTC-USD 1 min (USD, Bestandteil des CF-Index) für die ganze Historie und vorwärts; kein Quellenwechsel.
  - Modell: driftfrei in der Log-Rendite (Median = S) für alle Familien. σ aus einem log-HAR mit 1-Tages-Prognose; Koeffizienten
    monatlich auf Daten vor dem Neuschätzdatum (wachsendes Fenster); Eingänge nur aus Kerzen mit Ende ≤ t₀. Mal Wochentagsfaktor
    (gleiche 24-h-Wochenphase der letzten 26 Wochen, geschrumpft) und Makrotagsfaktor (liegt ein Termin im Fenster: Verhältnis aus
    früheren Terminen, kausal).
  - Vorlauf nach Abdeckung, ohne Ergebnisse: 24 h, wenn ≥ 80 % der Ereignisse dort einen gültigen Kurs haben, sonst der längste von
    18, 12, 6 h mit derselben Regel. Zustand: jüngste Kerze mit Ende ≤ t₀, höchstens 60 min alt.
  - Alle Schwellen jedes 17:00-ET-Ereignisses werden geholt. Zulässig nur Schwellen mit Kurs bis t₀ und |ln(K/S)| ≤ 2 σ√τ bei t₀.
    g je Schwelle mit dem Schwellenabstand gewichtet (diskrete CRPS-Differenz), Tagesmittel, Test nach R6, mindestens 100 Ereignistage.
  - Beschreibend: Lagetest (Markt gegen ein Mischmodell aus Median des Modells und Breite der Leiter = Richtungsanteil); g getrennt für
    Termin- und Wochenendtage.
  - Teststärke: Simulation auf echten BTC-Tagen (mit gepflanztem Breitenvorteil, ohne Marktkurse) vor dem Urteil, im Bericht.
- **R10 H3 neu.** Überraschung **u = x − m** (primär; Spearman braucht keine Skala); z = u ÷ s nur beschreibend, mit s ≥ 0,05.
  - Leiter auf dem 0,1-Raster als Klassen [v − 0,05, v + 0,05); Verteilungsfunktion linear in den Klassen; monoton per isotoner
    Regression (statt „vom Modus nach außen“). Gültig nur, wenn 16- und 84-%-Punkt innerhalb der gültigen Schwellen liegen; mindestens
    4 gültige Schwellen; Kurs höchstens 60 min vor Handelsschluss. `strike_type` und Regeltext je Reihe lesen (> gegen ≥ verschiebt m
    um eine Klasse).
  - Eine Kursquelle für alle Termine: Mitte, wenn 1-min-Geld/Brief bei ≥ 90 % der Termine vorliegt, sonst letzte Trades für alle.
  - Ausschluss nur nach Metadaten und BLS-Kalender: keine Veröffentlichung um 08:30 ET am Bezugstag; Ersatzabrechnung, annulliert
    oder abweichender Basiswert; die Termine des Shutdowns 2025 (September verschoben auf 24.10., Oktober entfallen, November ohne
    Monatsrate). Alle CPI-Reihen einschließlich der Altnamen ohne „KX“.
  - BTC-Rendite: Binance-Perp-30-min-Kerze mit Beginn 08:30:00 ET (12:30 bzw. 13:30 UTC), ihre Existenz wird geprüft.
  - Spearman mit Permutation (10.000), einseitig ρ < 0; Hälften am Median-Datum beide < 0; mindestens 30 Termine.
  - Placebos, die null sein müssen (zweiseitig p > 0,05; sonst „H3 ungültig“): (a) u gegen 08:00–08:30 ET, (b) u gegen 08:30–09:00 ET
    eine Woche früher.
  - Teststärke (Befund 16; Holm α/3 und Hälftenregel, stetige / stark gebundene Überraschung): 50 Termine 45 / 39 % bei ρ = 0,3 und
    70 / 68 % bei ρ = 0,4; 64 Termine 56 / 52 % und 85 / 78 %. Mit Gewicht 0,5 etwas höher.
- **R11 Vorwärts** nur nach einem „belegt“ im Rückblick: gleiche Kerzenstrecke (`k1m`) auf Märkten nach dem Stichtag, Umfang für 80 %
  Teststärke bei halbem Rückblick-Effekt, mindestens 60 Tage. Live-Schnappschüsse nur als Gegenprobe. (Ersetzt 6.4: nach 2.000
  Live-Fenstern hätte die Wiederholung nur 23–38 % Teststärke gehabt.)
- **R12 Prüfungen vor dem Urteil** (echte Daten; alle müssen bestehen, sonst kein Urteil und der Grund im Bericht):
  - H1: Markt bei B + 10 min gegen 0,5 gibt c deutlich > 0 (Verknüpfung und Zeit).
  - H1: Reihenfolge von `floor_strike` und `expiration_value` ergibt `result` in ≥ 99,9 % (falls beides CF-Mittel sind; Erstlauf).
  - H2: Kalibrierungssteigung von KXBTCD 1–6 h vor Ablauf zwischen 0,8 und 1,25 (Le 2026: 0,99–1,07).
  - H3: mittlerer absoluter Fehler des Kalshi-Medians für Gesamt-CPI 2022–2025 zwischen 0,04 und 0,09 (FEDS 2026-010: 0,063; ein um
    eine Klasse verschobener Schwellenbezug zeigt etwa 0,1).
  - H3: mittlere |BTC-Rendite| 08:30–09:00 ET an CPI-Tagen mindestens 1,5-mal so groß wie an anderen Tagen (fängt Zeitzonen- und
    Kerzenversatz).
  - Nullproben auf echten Tagen (200 Welten aus 7-Tage-Blöcken, „belegt“ in höchstens 5 % mit Binomialgrenze): H1 mit einem
    synthetischen Markt ohne Wissen auf den echten Ergebnisfolgen; H2 mit Spot-Echo aus einer zweiten Börse (Binance statt Coinbase).
- **R13 Beschreibendes** nur als Effektgröße mit Blockintervall, Aufschrift „beschreibend“, ohne p-Werte, erst nach dem Urteil sichtbar
  (R4). Eine Größe wird nur als neue Runde auf frischen Daten zur Prüfung. Gepaarte Vergleiche nur auf gleichen Fenstern mit gleichem
  Ergebnis (Fusion 4 h und Polymarket 4 h decken sich nur während der US-Sommerzeit und rechnen auf verschiedene Kurse ab). Les
  Steigungen sind für 2021–2025 in der Stichprobe geschätzt (Hinweis an der Anzeige). g nach Tick-Regime (vor/nach 23.07.2026).
- **R14 Kleineres.** Einseitige Bücher sind ungültig (Geld 0, Brief 1 oder fehlende Seite). Polymarkets „Binance-1-min-Schluss
  12:00 ET“ ist die Kerze mit Beginn 12:00 (Schluss 12:00:59); „9pm ET“ ist [21:00, 22:00). HIP-4 rechnet auf dem Markpreis ab, nicht
  auf Handelskerzen: Vergleich mit dem gespeicherten `markPx` des Pollers (Einbindung). `KXBTCMINY`, `KXETHD` und die Kern-CPI-Kennung
  sind Annahmen bis zum Erstlauf. ALFRED nur als Gegenprobe mit Ständen gleicher Fassung; der Kalshi-Wert bleibt maßgeblich.
- **R15 Erstlauf** (ersetzt 8.4; nur Anzahlen, Anteile, Beispiele): Handelsbeginn der 15-min-Märkte relativ zu B und Anteil der Fenster
  mit gültigem Kurs bei B − 60 s und B − 120 s (entscheidet, ob H1 prüfbar ist); Bedeutung und Veröffentlichungszeit von
  `floor_strike` und `expiration_value`; Gleichstandsregel; Start der Reihen; Regeltexte je Monat; Kerzen-Semantik gegen eigene
  Live-Werte (nach zwei Tagen), Kerzen in Minuten ohne Änderung, `include_latest_before_start`, Geld/Brief im Archiv, Tiefe der
  1-min-Kerzen 2021–2023, Höchstzahl je Abruf, Reihenfilter im Archiv; KXBTCD Listungszeit, Schwellenabstand, Zeitpunkt neuer
  Schwellen; alle CPI-Reihen mit Handelsschluss, `strike_type`, Format von `expiration_value`, Abrechnung der Shutdown-Termine;
  Polymarket `t`/`p` gegen eigene Werte, V2-Kennungen in Verlauf, Buch und Mitte, Syntax mehrerer `version`-Werte, wie früh nächste
  Fenster erscheinen; HIP-4 Aufzählung abgerechneter Kennungen, `candleSnapshot` mit `#`, `expiry` vor und nach dem 01.11.;
  Abdeckung der Spotquelle; **Uhrabweichung des Pi** (Binance-Serverzeit).

**Mutationen zusätzlich zu 8.2** (müssen rot werden): Kerze nach ihrem Beginn beschriftet (je Quelle); S(t₀) aus der Kerze, die t₀
enthält; t₀ in (B − 60 s, B]; Wechsel der Spotquelle in der Stichprobe; HAR-Zeile nach Beschriftung statt Verfügbarkeit; HAR auf der
ganzen Stichprobe geschätzt; Schwellen zugelassen, die nach t₀ entstanden; Auswahl nach Abstand bei Ablauf statt bei t₀; Leiterkurs
nach Handelsschluss oder 08:30; Schwellenbezug um eine Klasse verschoben; Rendite 08:00–08:30 statt 08:30–09:00; Urteile einzeln zu
verschiedenen Zeiten; kein Stichtag; Perzentil- statt zentriertem Bootstrap.

**Erwartung vorab (ersetzt 10):**
- H1: nicht prüfbar oder nicht belegt. Ob Kalshi vor dem Beginn überhaupt notiert, zeigt der Erstlauf; wenn ja, liegt der Kurs dort
  nahe 50 %.
- H2: offen. Der Markt sieht Termine und implizite Schwankung, zahlt aber Varianzprämie und Außenseiter-Verzerrung; das stärkere Modell
  macht ein „belegt“ schwerer.
- H3: etwa ein Münzwurf bis wahrscheinlich (ρ um −0,3; mit 50–64 Terminen 40–85 % Teststärke).

**Abweichungen von der Durchsicht, mit Grund**
- Spotquelle für H2: Coinbase BTC-USD statt der zweiten Möglichkeit (Binance, über `floor_strike` an den CF-Index geeicht), weil
  `floor_strike` erst ab Juli 2026 vorliegt, die Tagesleiter aber weiter zurückreicht. Das System nutzt Coinbase bereits.
- HAR: eigenes log-HAR im Modul mit derselben Bauart wie im Ausblick, weil `ausblick.db` für den Rückblick keine Historie hat; Regeln
  zur Verfügbarkeit wie in Befund 13.
- Mutationen zu „Bezug als Punktkurs statt 60-s-Mittel“, „`floor_strike` vor B“ und „ALFRED aus gemischten Fassungen“ kommen mit den
  zugehörigen beschreibenden Größen bzw. der ALFRED-Gegenprobe; in diesem Bau gibt es sie noch nicht.

**Stand nach dem Nachtrag:** Das Konzept ist fest bis auf die Entscheidungen in Abschnitt 12 und Formatbefunde des Erstlaufs; jede
Abweichung davon wird vor jeder Auswertung als weiterer Nachtrag festgehalten.

**Gemessen beim Bau (18:58, synthetische Daten, noch keine echte Zahl):** Die Prüfstrecke von H1 (Kovarianz, studentisierter
7-Tage-Blockbootstrap, α · 0,25, Hälftenregel) gibt bei 63 Tagen mit 6.048 Fenstern „belegt“ in 80 % der Welten ab einem Effektivwert
von 2,6 Punkten und in 92 % ab 3,2 Punkten (je 200 Welten). Die Formel in R7 war für so wenige Blöcke zu optimistisch. Größe bei
α = 0,05: Markt ohne Wissen 4,0 %, Tageshaufen 3,5 %. Selbsttest 84 Prüfungen; jede der 30 Mutationen (8.2 und Nachtrag) muss
mindestens eine davon rot machen.

### 13.2 Nachtrag beim Einbau in Paket 23.88 (27.10.2026, 19:56 gemessen)

Weiterhin **bevor eine einzige echte Zahl dieser Quellen im System gerechnet wurde** (aus der Bau-Umgebung ist keine Quelle erreichbar).
Ersetzt oder ergänzt die genannten Stellen; was nicht genannt ist, gilt unverändert.

**Eigener Fehler (Recherche, Abschnitt „Takt und Speicher“, und Abschnitt 9):** „Die HIP-4-Abfragen laufen über die bestehende
Rangfolge des Recorders, mit dem niedrigsten Rang“ geht nicht. Die Rangfolge lebt im Recorder-Prozess (asyncio); die Prognosemärkte
laufen im Dashboard. **Neu:** eigener Deckel von **20 Gewicht je Minute** im Modul (gleitendes 60-s-Fenster), wie die Notbremse ihren
eigenen hat. Fehlt Gewicht, entfällt der Abruf in dieser Runde (Code −2, gezählt); die Aufgabe kommt mit ihrem nächsten Takt wieder
(der Erstlauf wartet bis zu zweimal 31 s). Bedarf im Mittel rund 12
je Minute (`outcomeMeta` alle 5 min mit 20, ein Buch je offenem Ausgang je Minute mit 2). Der Recorder deckelt sich auf 1.080 der 1.200
je Minute und IP; die übrigen Prozesse teilen sich den Rest. Ob die Summe in Spitzen die Grenze erreicht, zeigt erst der Betrieb. Der
Reiter „Daten“ zeigt deshalb das gemessene Gewicht je Minute gegen den eigenen Deckel (statt „Gewichtsanteil am Poller“, Abschnitt 7).
Recherche und dieses Konzept tragen die Berichtigung.

**Dienst (Abschnitt 4).** Ein Faden „prognosemarkt“ im Dashboard. Er startet 60 s nach dem Dashboard, nicht für Selbsttest-Datenbanken;
aus mit `HL_PM=0`, `HL_PM_DB` lenkt die Datei um.
- Beim ersten Start läuft der Erstlauf (R15) und setzt den Stichtag (R2).
- Danach je Runde der Takt und bis zu 10 s Rückblick; der Zustand der Quellen kommt jede Minute nach `pm_meta`.
- Die Auswertung läuft eine Stunde nach dem Start, danach täglich; vor dem Urteil zählt sie nur (R4).
- Eine Ausnahme in einem Teil des Rückblicks zählt als Fehler dieses Teils. Nach 20 in Folge wird er mit Vermerk abgebrochen; dann fehlt
  er für R3, und das Urteil wartet.
- Eine Ausnahme im Takt oder in der Runde hält den Dienst nicht an. Der Grund steht in `pm_meta` und im Bericht „Stand“.

**Spot jede Minute statt alle 5 min** (nur der Takt; der Rückblick der Spotdaten bleibt): für das Spot-Echo in der Anzeige.

**Spot-Echo in der Anzeige (Abschnitt 7, R8).** Überblick (Auf/Ab-Fenster, HIP-4) und Krypto (je Schwelle) zeigen neben dem Ja-Kurs
das Spotmodell:
- Spot: 1-min-Kurse der Quelle aus R9 und `SPOT_QUELLE` (BTC und ETH Coinbase, HYPE Binance-Perp, ZEC Binance).
- Schwankung: Tagesvarianz aus 1, 7 und 30 Tagen (wie das Spotmodell in 6.1), zum Zeitpunkt der jüngsten Spotminute. Ist sie älter als
  5 min, bleibt die Spalte leer.
- Auf/Ab vor dem Beginn genau 50 % (Kalshi bis zur Mittelungsminute B − 60 s). Polymarket nimmt den Punktkurs bei Beginn als Bezug;
  seine Referenz ist eine andere Börse.
- Schwelle und Berührung wie in 6.1.
- **Nur Anzeige, nie in einer Prüfung.** Es verbindet keine Kurse mit Ergebnissen; R4 bleibt.

**R4 technisch.** Vor dem gemeinsamen Urteil enthält die Nutzlast weder Urteil noch Beschreibendes noch vergangene Makro-Termine. Sie
kommen erst mit einer Zeile `endgueltig = 1` in `pm_auswertung`. Geprüft im Selbsttest des Moduls, über den Server
(`hl_viz.py --selbsttest-prognosemarkt`, mit Gegenprobe nach dem Urteil) und in der Browser-Probe.

**Berichte (ersetzt 8.3).**
- Debug-Läufe: 129 „★ Prognosemärkte: Stand und Quellen“ (mit Erstlauf und Dienst), 130 „★ … Auswertung“, 131 „Formatprüfung erneut
  (Erstlauf)“, 132 „Selbsttest“, 133 „Mutationsprüfung“.
- Berichtsplan: 30.10. 12:00 und 31.10. 08:45 (Erstlauf, Stand, Zählung); 01.11. 20:45 und 03.11. 20:45 (Urteil oder Zählung); Stand und
  Auswertung in der Wochenprüfung (mittwochs 19:00).
- Kein täglicher Bericht: Der Dienst zählt täglich selbst, „Stand“ ist jederzeit von Hand möglich.

**Backup.** `prognosemarkt.db` kommt in die tägliche Sicherung des Recorders (Nebendatenbanken, eine Generation).

**Entscheidungen (Abschnitt 12).** Bis zu einer Antwort des Nutzers gelten die Standards in Klammern: 1 nein, 2 ja, 3 nein, 4 ja, 5 nein.

**In 23.88 nicht gebaut** (bleibt offen, ohne Folgen für H1–H3):
- die Vorwärtsrunde R11 (erst nach einem „belegt“);
- der lesende Zusatz im Ausblick (6.3 und 9: eigene Wahrscheinlichkeit für offene Marktschwellen speichern) und damit „Markt gegen
  eigene Prognosen“; HIP-4 gegen den gespeicherten `markPx` des Pollers (R14);
- Beschreibendes: Polymarket-Maße (15 min bis Tag), „über das Fenster hinaus“ (1 h und 4 h), Schwankung nach Mohanty & Krishnamachari,
  Abgleich zwischen Plattformen, Antwortzeit nach 08:30 ET, Kalibrierungsdiagramme. Gebaut sind das H1-Maß für ETH, HYPE und ZEC,
  Kalibrierung H1 und H2, Lagetest H2, Tick-Regime und Makro für KXU3, KXPAYROLLS und KXCPIYOY; alles erst nach dem Urteil sichtbar
  (R13);
- die Mutationen „Bezug als Punktkurs“, „`floor_strike` vor B“ und „ALFRED aus gemischten Fassungen“ (wie in 13.1 angekündigt);
- ein Lebenszeichen in `check_system` (sein Selbsttest baut die Tabellen von Hand). Ob der Dienst läuft, zeigen der Reiter „Daten“
  („Dienst: letzter Zustand vor …“) und der Bericht „Stand“.

### 13.3 Nachtrag nach dem Erstlauf auf dem Pi (28.10.2026, 14:44 gemessen; vor dem gemeinsamen Urteil)

Grundlage: Debug Nr. 131 (Erstlauf von Hand, 28.10. 13:27 UTC) und Nr. 129 (Stand, 13:31 UTC). Paket 23.88 wurde auf Wunsch des
Nutzers schon am 27.10. eingespielt; der Dienst läuft seit dem Stichtag 27.10. 21:19 UTC (R2). **Keine Regel geändert.** Befunde
nach 8.4:

- **Kalshi 15 min:** Handelsbeginn genau zum Fensterbeginn B (15,0 min vor Schluss). In 0 von 30 Probefenstern gab es einen gültigen
  Kurs bei B − 60 s oder B − 120 s; die erste 1-min-Kerze endet bei B + 60 s. **H1 ist nach R7 nicht prüfbar** („ohne Ausweichen
  nach dem Beginn“; Erwartung in 10 und 13.1: „nicht prüfbar oder nicht belegt“). Nach R5 normiert der gewichtete Holm auf die
  prüfbaren Tests: H2 ⅓, H3 ⅔. Die Positivkontrolle „B + 10 min“ bleibt; die Nullprobe H1 entfällt ohne Fälle.
- **Kalshi KXBTCD:** Die 17:00-ET-Leiter öffnet 22,7 h vor Schluss. 24 h Vorlauf ist nicht erreichbar; R9 wählt den längsten von
  18, 12 und 6 h mit mindestens 80 % Abdeckung.
- **Kalshi Makro:** Schluss 08:29 ET wie angenommen. Archivgrenze 29.08.2026; das Archiv ist mit Reihenfilter lesbar. Die alten
  Reihennamen CPI, FED und U3 haben keine Märkte. Wie viele CPI-Termine H3 hat (erwartet 50–64), zeigt die Auswertung.
- **Kerzen:** Zeitstempel = Periodenende bestätigt (R1). **Uhr:** Abweichung des Pi gegen Binance 0,05 s.
- **Polymarket:** Alle Familien gefunden. Der Geoblock meldet Deutschland als gesperrt; das betrifft den Handel, gelesen wird ohne
  Einschränkung. Abweichung in der Auswahl: Vorzeitig entschiedene Leiter-Märkte ohne Orderbuch werden weiter abgefragt (404). Nur
  beschreibend.
- **HIP-4:** `outcomeMeta` hat 361 Ausgänge, die meisten in einem zweiten Beschreibungsformat (Aktien-Perps, Sport), das der Parser
  nicht kennt. `candleSnapshot` mit `#` liefert keine Kerzen; rückwirkend gibt es nur Ergebnisse. **Eigener Fehler aus dem Bau:** Die
  Abrechnung läuft direkt nach `outcomeMeta` im vollen Gewichtsfenster und bekommt nie Gewicht; der Selbsttest lief mit unbegrenztem
  Gewicht. Nur beschreibend.
- **Folge:** Parser und Auswahl für H2 und H3 bleiben, wie sie sind. Die beschreibenden Teile (Auswahl bei Polymarket, HIP-4) bessert
  U236 nach, ohne Wirkung auf H1–H3.

### 13.4 Nachtrag U236 mit Paket 23.89 (28.10.2026, 17:53 gemessen; nur beschreibende Teile)

Auf Wunsch des Nutzers sofort gebaut (28.10. 17:03: „U236 sofort“). **Die Auswertung (Abschnitt 11, `VERSION_AUSWERTUNG`
U235-2), das Tor R4 und alle Regeln R1–R15 bleiben unverändert;** ein Urteil, das 23.88 schreibt, gilt auch unter 23.89. Geändert
nach den Befunden aus 13.3:

- **HIP-4, Auswahl:** Bücher, Abrechnung und der Rückblick-Schritt nur für Krypto-Preisbinäre (`class:priceBinary`) der Coins BTC,
  ETH, HYPE, ZEC, XMR und PAXG. Das zweite Format (`perp:<Dex>:<Symbol>|…|threshold:…|time:…`, Klasse „perpSchwelle“) und das dritte
  (`participant:…`, Klasse „teilnehmer“) werden gelesen und abgelegt, aber nicht abgefragt. Ein Ausgang, den `outcomeMeta` nicht mehr
  führt, bekommt als Ende den Zeitpunkt dieser Meta.
- **HIP-4, Gewichtsplan:** Ein Schritt nur bei leerem 60-s-Fenster des eigenen Deckels (20 je Minute), denn `outcomeMeta` und
  `settledOutcome` kosten je 20. Reihum: Meta (höchstens alle 300 s), Bücher (reihum, je 2), Abrechnung (ein abgelaufener relevanter
  Ausgang ohne Ergebnis, höchstens alle 600 s je Ausgang, bis 14 Tage nach Ablauf) bzw. ein Schritt des HIP-4-Rückblicks. Dieser Teil
  schreitet im Takt voran; im Rückblick-Faden wartet er ohne Schritt und ohne Schreiben. **Eigener Fehler aus 23.88:** Die Abrechnung
  lief direkt nach der Meta im vollen Fenster und bekam nie Gewicht; der Rückblick-Teil hätte bei fehlendem Gewicht leer weitergezählt
  und jedes Mal geschrieben. Der Selbsttest lief mit unbegrenztem Gewicht; neu ist ein Selbsttest mit echtem Deckel (45 min
  simuliert).
- **Polymarket:** Eine Kennung, deren Einzelabruf 404 bringt, ruht 6 h; Leiter-Märkte mit Ergebnis werden nicht mehr abgefragt.
- **Datenschutz:** Der Erstlauf zeigt aus der Geoblock-Antwort nur Sperre, Land und Region. Der gespeicherte Erstlauf aus 23.88 wird
  beim Start des Dienstes bereinigt; der Bericht „Stand“ entfernt die Adresse auch bei der Anzeige.
- **Text:** Alter nie negativ; der Kopf des Urteils (Bericht und Seite) nennt die nach R5 auf die prüfbaren Tests normierten Gewichte.
- **Mutationen dazu (8.2):** „HIP-4 alle Bücher“, „Abrechnung direkt nach der Meta“, „Rückblick im Leerlauf“, „Kennung ohne Buch nicht
  auslassen“, „IP-Adresse ausgeben“.
