"""
hl_cockpit_js.py -- Skript des Abschnitts „Cockpit“ im Dashboard (U245 Stufe C1, 23.98), ausgeliefert unter /cockpit.js.

Seit 23.100 (U254) dazu die Karte „Unstaking“ (nur ETH; gemessen, blau); seit 23.101 (U255) darin eine Zeile mit dem Urteil der
vorab festgelegten Prüfung „Folgt darauf ein Kursrückgang?“ -- als Text, ohne Farbe. Seit 23.104 (U260) daneben die Karte
„Unstaking · Verlauf“: Schlange der Abzüge und ETH-Kurs je UTC-Tag in zwei Feldern mit gemeinsamer Zeitachse (keine zweite Skala in
einem Feld), die Wellen der Prüfung als Marken; Daten von /cockpit/unstaking, höchstens alle 30 min. Seit 23.105 (U245 Stufe C2) die
Karte „Kurs-Rechner“: Kurs eintippen, Wahrscheinlichkeit sehen, dass er in 1 und 4 Stunden, 7 und 14 Tagen berührt wird; Kurse lassen
sich im Browser merken (localStorage, je Coin); gerechnet wird auf dem Server (/cockpit/rechner). Seit 23.108 (Rest von Stufe C2) in
den Markt-Messwerten das Funding von Hyperliquid und die Varianz des Taker-Flusses (Skala mit markiertem unterstem Zehntel), die Karte
„Liquidationsdichte“ (zwölf Balken je 0,5 % um den Kurs, eine Farbe, Antippen zeigt die Stufe, die Zahlen stehen als Liste darunter)
und die Betriebslampe: Die Pille im Kopf verbindet die Lampe des Servers (Dienste, API-Gewicht, Alter des Backups) mit den Hinweisen
des Abschnitts System; die Karte „Betrieb“ nennt die Zahlen. Seit 23.110 (U269) nach „Levels“ die Karte „Durchschnittslinien“: 50- und
200-Tage-Linie mit Wert, Abstand des jetzigen Kurses, Richtung, Lage zueinander, Stand und Beleg (gemessen, neutral). Seit 23.111
(U270) je Linie zwei Werte: groß wie im Live-Chart (heutiger Tag mit dem jetzigen Kurs), klein darunter der Wert nach Tagesschluss.

Eigene Datei wie hl_volatil_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf den
Helfern der Seite auf ($, getJSON, esc) und muss deshalb NACH dem Hauptskript geladen werden.

Das Skript rechnet nichts: Zustände der Lampen, Vermerke und Belege kommen fertig von /cockpit (hl_cockpit.py). Hier nur Zahlen im
deutschen Format, Ortszeit und die Zeichnung. Regeln aus KONZEPT_Cockpit.md 4: jede Lampe trägt ein Wort und eine eigene Form (Ring =
aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert), Farbe nur für Belegtes (Klasse A) und für den Zustand des
Betriebs, Messwerte neutral blau;
kein Pfeil, kein Empfehlungswort, kein Rot/Grün im Sinn von gut/schlecht. Jedes Instrument zeigt Zahl, Stand und Beleg.
"""

COCKPIT_JS = r"""// 23.98 Cockpit (U245 Stufe C1): Spanne, Risiko, Levels, Messwerte, Kosten -- nur Belegtes oder sauber Gemessenes. Daten: /cockpit?coin=..
// (hl_cockpit.py, nur lesend). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist (höchstens einmal je Minute; Server 30 s).
const CK={d:null, coin:null, laeuft:false, lampe:null, fehler:null, geladen:0, liq:null, liqliste:false};
const CK_F={a50:'#58a6ff', a80:'#2f6fb5', a90:'#1b3a5c', kurs:'#e3b341', hinweis:'#e3b341', warnung:'#f0883e', info:'#58a6ff', ring:'#9da7b3',
 spur:'#30363d', grau:'#6e7681', text:'#e6edf3', leise:'#9da7b3'};
function ckZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}).replace('-','−'); }
function ckPx(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return ckZ(x, a>=1000?0:a>=10?2:4); }
function ckPc(x,d,vz){ if(x==null||!isFinite(x)) return '—'; const s=ckZ(x*100,d); return (vz&&x>0?'+':'')+s+' %'; }
function ckZeit(ts){ if(!ts) return '—'; const x=new Date(ts*1000); return x.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})+' '+x.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}); }
function ckTag(ts){ if(!ts) return '—'; const x=new Date(ts*1000); return ['So','Mo','Di','Mi','Do','Fr','Sa'][x.getDay()]+', '+x.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'}); }
function ckDauer(s){ s=Math.max(0,Math.round(s)); if(s<5400) return Math.max(1,Math.round(s/60))+' min'; if(s<172800) return Math.round(s/3600)+' h'; return Math.round(s/86400)+' Tagen'; }
function ckOffen(){ const p=$('sec-cockpit'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function ckCoin(){ const s=$('coin'); return (s&&s.value)||'BTC'; }      // ein Coin ohne Cockpit bekommt vom Server die Absage mit Grund, kein stilles BTC

async function ckLaden(erzwungen){
 if(!$('ckbody')||CK.laeuft) return;
 if(!erzwungen&&!ckOffen()) return;
 const coin=ckCoin();
 if(!erzwungen&&CK.d&&CK.coin===coin&&Date.now()-CK.geladen<25000) return;
 CK.laeuft=true;
 try{ const d=await getJSON('/cockpit?coin='+encodeURIComponent(coin)); if(CK.coin!==coin) CK.liq=null; CK.d=d; CK.coin=coin; CK.fehler=null; CK.geladen=Date.now(); }
 catch(e){ CK.fehler=String(e&&e.message||e); }
 CK.laeuft=false; ckrCoin(); ckZeichne();
 if(CK.d&&CK.d.unstaking) ckvLaden(false);        // 23.104: der Verlauf gehört nur zu ETH (bei den anderen Coins ist unstaking leer)
 ckrLaden(false);                                 // 23.105: gemerkte Kurse des Kurs-Rechners mit dem neuen Kurs nachrechnen (höchstens alle 50 s)
}
function ckWaehle(c){ const s=$('coin'); if(!s) return;
 if(![...s.options].some(o=>o.value===c)){ CK.fehler='Der Coin '+c+' steht in der Auswahl der Seite nicht zur Verfügung.'; ckZeichne(); return; }
 if(s.value===c) return; s.value=c; s.dispatchEvent(new Event('change')); }
function ckLampeZeigen(k){ CK.lampe=(CK.lampe===k?null:k); ckZeichne(); }
function ckGeheZu(id){ const g=$(id); if(!g) return; if(g.classList.contains('zu')&&typeof grpSchalten==='function') grpSchalten(id.replace('grp-',''));
 g.scrollIntoView({behavior:'smooth', block:'start'}); }

// ---------- Formen der Lampen: Ring = aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert ----------
function ckForm(z, klasse, gr){ const g=gr||20, r=g/2;
 if(z==='warnung') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2" width="16" height="16" rx="3" fill="${CK_F.warnung}"/></svg>`;
 if(z==='hinweis') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="8" fill="${klasse==='B'?CK_F.info:CK_F.hinweis}"/></svg>`;
 if(z==='grau') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5" fill="none" stroke="${CK_F.grau}" stroke-width="2" stroke-dasharray="3 3"/></svg>`;
 return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5" fill="none" stroke="${CK_F.ring}" stroke-width="2"/></svg>`; }
function ckLampenWert(l){ const jetzt=Date.now()/1000;
 if(l.key==='termin'&&l.ts){ if(l.zustand==='aus') return ckTag(l.ts);
  if(jetzt<l.ts) return 'in '+ckDauer(l.ts-jetzt); return 'bis '+new Date((l.ts_ende||l.ts)*1000).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}); }
 return l.wert||'—'; }
function ckLampen(d){ const L=d.lampen||[];
 let h=`<div class="ckk"><div class="ckt">Risiko</div><div class="cklampen">`
  +L.map(l=>`<button type="button" class="cklampe${CK.lampe===l.key?' an':''}" onclick="ckLampeZeigen('${l.key}')" aria-expanded="${CK.lampe===l.key}" title="${esc(l.detail||'')}">`
   +ckForm(l.zustand,l.klasse)+`<span class="ckln">${esc(l.name)}</span><span class="cklw">${esc(l.wort||'')}</span><span class="cklv">${esc(ckLampenWert(l))}</span></button>`).join('')+`</div>`;
 const a=L.find(l=>l.key===CK.lampe);
 if(a) h+=`<div class="ckdetail"><b>${esc(a.name)}: ${esc(a.wort||'')}.</b> ${esc(a.detail||'')}`
  +(a.key==='termin'&&a.ts?` Zeitpunkt: ${esc(ckZeit(a.ts))} (Ortszeit).`:'')
  +(a.ts_ende&&a.key!=='termin'?` Gilt bis ${esc(ckZeit(a.ts_ende))}.`:'')
  +(a.stand?` Stand der Quelle: ${esc(ckZeit(a.stand))}.`:'')+`<div class="ckbeleg">${esc(a.beleg||'')}</div></div>`;
 else h+=`<div class="ckleg"><span>${ckForm('aus','A',12)} aus</span><span>${ckForm('hinweis','A',12)} Hinweis</span><span>${ckForm('warnung','A',12)} Warnung</span>`
  +`<span>${ckForm('hinweis','B',12)} Messwert</span><span>${ckForm('grau','A',12)} kein Wert</span><span class="ckleise">Antippen zeigt den Beleg.</span></div>`;
 return h+`</div>`; }

// ---------- Kopf, Streifen, Kernsatz ----------
function ckKopf(d){ const k=d.kopf||{}, alt=k.kurs_ts?Date.now()/1000-k.kurs_ts:null;
 return `<div class="ckkopf"><div><div class="ckmarke">HyperBit Cockpit</div><div class="ckkurs${k.frisch?'':' ckalt'}">${ckPx(k.kurs)}</div>`
  +`<div class="ckleise">${esc(d.coin||'')} · ${k.kurs_ts?(k.frisch?'Kurs von '+esc(ckZeit(k.kurs_ts)):'Kurs nicht frisch: Stand '+esc(ckZeit(k.kurs_ts))+(alt?' (vor '+ckDauer(alt)+')':'')):'kein Kurs'}</div></div>`
  +`<button type="button" id="ck_betrieb" class="ckpille" onclick="ckGeheZu('grp-betrieb')" title="Zum Bereich Betrieb (System, Backup, Netzwerk, Update, Debug)">`
  +`<span class="ckpunkt"></span><span class="ckptext">Betrieb</span></button></div>`; }
function ckBetriebStand(){ const S=(CK.d&&CK.d.ok!==false&&CK.d.betrieb)||null, B=window.CK_BETRIEB||null;      // 23.108: Server und Seite zusammen
 if(!S&&!B) return null;
 const gr=[]; ((S&&S.gruende)||[]).concat((B&&B.prob)||[]).forEach(g=>{ if(g&&!gr.includes(g)) gr.push(g); });
 const z=(S&&S.zustand==='warnung')?'warnung':gr.length?'hinweis':(S&&S.zustand==='grau'&&!B)?'grau':'aus';
 return {z:z, gr:gr}; }
function ckBetrieb(){ const el=$('ck_betrieb'); if(!el) return;
 const t=el.querySelector('.ckptext'), p=el.querySelector('.ckpunkt'); if(!t||!p) return;
 const Z=ckBetriebStand();
 if(!Z){ t.textContent='Betrieb: wird geprüft'; p.style.background='transparent'; p.style.border='2px dashed '+CK_F.grau; p.style.borderRadius='50%'; return; }
 if(Z.z==='warnung'){ t.textContent='Betrieb: Warnung ('+Z.gr.join(', ')+')'; p.style.background=CK_F.warnung; p.style.border='0'; p.style.borderRadius='2px'; }
 else if(Z.z==='hinweis'){ t.textContent='Betrieb: Hinweis ('+Z.gr.join(', ')+')'; p.style.background=CK_F.hinweis; p.style.border='0'; p.style.borderRadius='50%'; }
 else if(Z.z==='grau'){ t.textContent='Betrieb: nicht prüfbar'; p.style.background='transparent'; p.style.border='2px dashed '+CK_F.grau; p.style.borderRadius='50%'; }
 else { t.textContent='Betrieb: ohne Hinweis'; p.style.background='transparent'; p.style.border='2px solid '+CK_F.ring; p.style.borderRadius='50%'; } }
// Karte „Betrieb“: die Zahlen hinter der Pille (Dienste, API-Gewicht, Backup) -- vom Server, mit Stand
function ckBetriebKarte(d){ const S=d.betrieb; if(!S||!(S.zeilen||[]).length) return '';
 return `<div class="ckk"><div class="ckt">Betrieb <span class="ckleise cktn">${esc(S.wort||'')}</span></div>`
  +S.zeilen.map(z=>`<div class="ckbtr">${ckForm(z.zustand,'A',14)}<div><div class="ckleise">${esc(z.name||'')}</div><div>${esc(z.text||'')}</div>`
   +(z.stand&&z.zustand!=='grau'?`<div class="ckleise ckstand">${z.key==='backup'?'gesichert ':'Stand '}${esc(ckZeit(z.stand))}</div>`:'')+`</div></div>`).join('')
  +`<div class="ckbeleg">${esc(S.beleg||'')}</div></div>`; }
function ckStreifen(d){ const S=d.streifen||[]; if(!S.length) return '';
 const m=Math.max(0.05, ...S.map(e=>Math.max(Math.abs(e.lo||0), Math.abs(e.hi||0))));
 return `<div class="ckstreifen" role="group" aria-label="Coins: 80-Prozent-Spanne der nächsten 7 Tage und Lampen">`+S.map(e=>{
  const lo=e.lo!=null?Math.abs(e.lo)/m*50:0, hi=e.hi!=null?Math.abs(e.hi)/m*50:0, an=(e.lampen||[]).filter(z=>z==='hinweis'||z==='warnung').length;
  const warn=(e.lampen||[]).includes('warnung');
  return `<button type="button" class="ckcoin${e.coin===d.coin?' an':''}" onclick="ckWaehle('${e.coin}')" aria-pressed="${e.coin===d.coin}" `
   +`title="${esc(e.coin)}: in 7 Tagen mit 80 % zwischen ${esc(ckPc(e.lo,0,true))} und ${esc(ckPc(e.hi,0,true))}; ${an} von 5 Lampen an">`
   +`<b>${esc(e.coin)}</b><span class="ckmini" aria-hidden="true"><i style="left:${(50-lo).toFixed(1)}%;width:${(lo+hi).toFixed(1)}%"></i><u></u></span>`
   +`<span class="ckminiz">${e.lo!=null?esc(ckZ(e.lo*100,0))+' / +'+esc(ckZ(e.hi*100,0))+' %':'—'}</span>`
   +`<span class="ckpunkte" aria-hidden="true">${(e.lampen||[]).map(z=>`<s class="${z}"></s>`).join('')}</span>`
   +`<span class="ckleise ckan">${an?an+(warn?' · Warnung':' an'):'keine an'}</span></button>`; }).join('')+`</div>`; }
function ckSatz(d){ const s=d.satz||{};
 return `<div class="ckk"><div class="cksatz">${esc(s.text||'')}</div><div class="ckleise">${esc(s.zusatz||'')}</div>`
  +(s.ausnahme?`<div class="ckausnahme">${esc(s.ausnahme)}</div>`:'')+(s.unstaking?`<div class="ckunst">${esc(s.unstaking)}</div>`:'')+`</div>`; }

// ---------- Schwankung: Bogen mit der erwarteten Schwankung der nächsten 7 Tage ----------
function ckBogen(wert, max){ const L=Math.PI*60, a=wert!=null&&max?Math.max(0,Math.min(1,wert/max)):0;
 return `<svg role="img" aria-label="Schwankung ${ckZ(wert,1)} Prozent pro Jahr auf einer Skala bis ${ckZ(max,0)}" width="140" height="78" viewBox="0 0 140 78">`
  +`<path d="M 10 70 A 60 60 0 0 1 130 70" fill="none" stroke="${CK_F.spur}" stroke-width="12" stroke-linecap="round"></path>`
  +(wert!=null?`<path d="M 10 70 A 60 60 0 0 1 130 70" fill="none" stroke="${CK_F.a50}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${(a*L).toFixed(1)} ${L.toFixed(1)}"></path>`:'')+`</svg>`; }
function ckSchwankung(d){ const s=d.schwankung||{}, erw=s.erwartet!=null;
 const zeile=(n,v)=>`<div class="ckzeile"><span>${n}</span><b>${v}</b></div>`;
 return `<div class="ckk${s.frisch===false&&s.anzeige!=null?' ckgrau':''}"><div class="ckt">Schwankung</div><div class="ckschw"><div class="ckbogen">`+ckBogen(s.anzeige, s.skala_max)
  +`<div class="ckgross">${s.anzeige!=null?ckZ(s.anzeige,1)+' %':'—'}</div><div class="ckleise">${erw?'erwartet, 7 Tage, pro Jahr':'realisiert, 7 Tage, pro Jahr'}</div></div>`
  +`<div class="ckliste">`+(erw?zeile('Realisiert 7 Tage', s.real7!=null?ckZ(s.real7,1)+' %':'—'):'')
  +zeile('Realisiert 30 Tage', s.real30!=null?ckZ(s.real30,1)+' %':'—')+(s.dvol!=null?zeile('DVOL', ckZ(s.dvol,1)):'')
  +zeile('In 4 h typisch', s.er4!=null?'± '+ckZ(s.er4*100,2)+' %':'—')+zeile('Perzentil 365 Tage', s.pz_n!=null?s.pz_n+'.':'—')+`</div></div>`
  +(s.fehlt&&s.fehlt.length?`<div class="ckfehlt">${s.fehlt.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(s.beleg||'')}${s.modell?' Modell: '+esc(s.modell)+'.':''}${s.stand_text?' '+esc(s.stand_text):''}</div></div>`; }

// ---------- Spanne: Balken 50 / 80 / 90 % für 7, 14 und 28 Tage mit Kursmarke ----------
function ckSpanne(d){ const S=d.spanne||{}, H=S.h||{}, sk=S.skala;
 if(!sk||!Object.keys(H).length) return `<div class="ckk"><div class="ckt">Spanne</div><div class="ckfehlt">${(S.fehlt||['Noch keine Spanne.']).map(esc).join(' ')}</div><div class="ckbeleg">${esc(S.beleg||'')}</div></div>`;
 const pos=x=>Math.max(0,Math.min(100,(x-sk[0])/(sk[1]-sk[0])*100));
 const kurs=S.kurs!=null?S.kurs:S.p0;
 const balken=(h,hoehe)=>{ const e=H[h]; if(!e) return ''; const q=e.q, p=q.map(pos);
  return `<div class="ckbz"><div class="ckbalken" style="height:${hoehe}px" role="img" aria-label="${h} Tage: 90 Prozent ${ckPx(q[0])} bis ${ckPx(q[6])}, 80 Prozent ${ckPx(q[1])} bis ${ckPx(q[5])}, 50 Prozent ${ckPx(q[2])} bis ${ckPx(q[4])}">`
   +`<i style="left:${p[0].toFixed(2)}%;width:${(p[6]-p[0]).toFixed(2)}%;background:${CK_F.a90}"></i><i style="left:${p[1].toFixed(2)}%;width:${(p[5]-p[1]).toFixed(2)}%;background:${CK_F.a80}"></i>`
   +`<i style="left:${p[2].toFixed(2)}%;width:${(p[4]-p[2]).toFixed(2)}%;background:${CK_F.a50}"></i>`
   +(kurs!=null?`<u style="left:${pos(kurs).toFixed(2)}%"></u>`:'')+`</div>`
   +`<div class="ckbtext"><b>${h} Tage · ${ckPx(q[1])} – ${ckPx(q[5])}</b><span class="ckleise">${esc(e.vermerk||'')}</span></div></div>`; };
 return `<div class="ckk${S.frisch?'':' ckgrau'}"><div class="ckt">Spanne <span class="ckleise cktn">80 % je Zeile</span></div><div class="ckspanne">`
  +balken('7',16)+balken('14',12)+balken('28',8)+`</div>`
  +`<div class="ckleg"><span><i class="sw" style="background:${CK_F.a50}"></i>50 %</span><span><i class="sw" style="background:${CK_F.a80}"></i>80 %</span>`
  +`<span><i class="sw" style="background:${CK_F.a90};border:1px solid ${CK_F.spur}"></i>90 %</span><span><i class="sw" style="background:${CK_F.kurs};width:2px"></i>${S.kurs!=null?'Kurs jetzt':'Kurs am Anker'}</span></div>`
  +(S.fehlt&&S.fehlt.length?`<div class="ckfehlt">${S.fehlt.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(S.beleg||'')} Stand der Rechnung: ${esc(ckZeit(S.anker))}, Kurs damals ${ckPx(S.p0)}.</div></div>`; }

// ---------- Levels: die nächsten Niveaus über und unter dem Kurs ----------
function ckLevels(d){ const L=d.levels||{};
 const zeile=n=>`<div class="cklevel"><div class="ckln2"><b>${esc(n.name)} ${ckPx(n.px)}</b><span class="ckleise">${esc(ckPc(n.abstand,1,true))}${n.momentaufnahme?' · Momentaufnahme':''}</span></div>`
  +`<div class="ckpb" aria-hidden="true"><span><i style="width:${(n.p7*100).toFixed(0)}%;background:${CK_F.a50}"></i></span><span><i style="width:${(n.p14*100).toFixed(0)}%;background:${CK_F.a80}"></i></span></div>`
  +`<span class="ckpz">${ckZ(n.p7*100,0)} · ${ckZ(n.p14*100,0)} %</span></div>`;
 const leer=!(L.oben||[]).length&&!(L.unten||[]).length;
 return `<div class="ckk${L.frisch===false&&!leer?' ckgrau':''}"><div class="ckt">Levels <span class="ckleise cktn">erreicht in 1 Woche · 2 Wochen</span></div>`
  +(leer?`<div class="ckfehlt">${(L.fehlt||['Keine Niveaus.']).map(esc).join(' ')}</div>`:
   (L.oben||[]).map(zeile).join('')+`<div class="ckkurslinie"><span></span><b>Kurs ${ckPx(L.kurs)}</b><span></span></div>`+(L.unten||[]).map(zeile).join(''))
  +(!leer&&L.fehlt&&L.fehlt.length?`<div class="ckfehlt">${L.fehlt.map(esc).join(' ')}</div>`:'')
  +(L.durchlaufen?`<div class="ckfehlt">${L.durchlaufen} Niveau${L.durchlaufen>1?'s':''} seit der Rechnung durchlaufen, nicht mehr gezeigt.</div>`:'')
  +`<div class="ckbeleg">${esc(L.beleg||'')}${L.anker?' Wahrscheinlichkeiten ab der Rechnung von '+esc(ckZeit(L.anker))+'.':''}</div></div>`; }

// ---------- 23.110 (U269) Durchschnittslinien: 50- und 200-Tage-Linie (gemessen). Wert, Abstand des jetzigen Kurses, Richtung, Zeile zur
// Erreich-Wahrscheinlichkeit, Lage der Linien zueinander, Stand, Hinweise und Beleg kommen als fertige Texte von /cockpit
// (hl_cockpit.linien_bauen) -- das Skript setzt sie nur: je Linie Name links und Wert rechts, darunter die Zeilen. Seit 23.111 ist der
// große Wert der wie im Live-Chart (haupt_text); der Wert nach Tagesschluss steht rechtsbündig klein darunter (neben).
function ckLinien(d){ const L=d.linien; if(!L) return '';
 const titel=`<div class="ckt">Durchschnittslinien <span class="ckleise cktn">gemessen</span></div>`;
 const beleg=`<div class="ckbeleg">${esc(L.beleg||'')}</div>`;
 if(!L.ok) return `<div class="ckk ckgrau">${titel}<div class="ckfehlt">${(L.fehlt&&L.fehlt.length?L.fehlt:['Keine Tageskerzen.']).map(esc).join(' ')}</div>${beleg}</div>`;
 const zeile=z=>`<div class="cklin"><div class="cklink"><b>${esc(z.name||'')}</b><b class="cklinw">${esc(z.haupt_text||z.px_text||'—')}</b></div>`
  +(z.px!=null&&z.neben?`<span class="ckleise cklinn">${esc(z.neben)}</span>`:'')
  +(z.px==null?[z.fehlt||'kein Wert']:[[z.lage,z.richtung].filter(Boolean).join(' · '), z.p_text||'']).filter(Boolean).map(t=>`<span class="ckleise">${esc(t)}</span>`).join('')+`</div>`;
 return `<div class="ckk">${titel}`+(L.zeilen||[]).map(zeile).join('')
  +(L.lage?`<div class="cklage">${esc(L.lage)}</div>`:'')
  +(L.stand?`<div class="ckleise ckstand">${esc(L.stand)}</div>`:'')
  +((L.hinweise||[]).length?`<div class="ckfehlt">${L.hinweise.map(esc).join(' ')}</div>`:'')
  +beleg+`</div>`; }

// ---------- 23.105 (U245 Stufe C2) Kurs-Rechner: Für einen eingetippten Kurs zeigt die Karte, wie wahrscheinlich er vom jetzigen Kurs aus
// berührt wird -- in 1 und 4 Stunden, 7 und 14 Tagen. Gerechnet wird auf dem Server (/cockpit/rechner, hl_cockpit.rechner_nutzlast); das
// Skript liest die Eingabe, merkt Kurse im Browser (localStorage, je Coin) und zeichnet. Solange im Eingabefeld getippt wird, zeichnet
// das Cockpit nicht neu (das Feld verlöre sonst Text und Tastatur) -- höchstens 15 s nach dem letzten Tastendruck.
const CKR={d:null, coin:null, kurse:[], laeuft:false, geladen:0, fehler:null, text:'', kurs:null, meldung:'', fokus:false, taste:0, offen:false, alle:null, speicher:null, anfrage:'', mehr:false};
const CKR_KEY='ck_rechner_v1';
function ckrAlle(){ if(CKR.alle) return CKR.alle; let a={}, t=null;
 try{ t=window.localStorage.getItem(CKR_KEY); CKR.speicher=true; }catch(e){ CKR.speicher=false; }
 if(t){ try{ const j=JSON.parse(t); if(j&&typeof j==='object'&&!Array.isArray(j)) a=j; }catch(e){} }     // unlesbarer Inhalt: leere Liste
 CKR.alle=a; return a; }
function ckrListe(){ const R=(CK.d&&CK.d.rechner)||{}, arten=(R.arten||[]).map(a=>a[0]), roh=ckrAlle()[CK.coin||''], out=[];
 if(Array.isArray(roh)) roh.forEach(e=>{ const px=e?+e.px:NaN; if(px>0&&isFinite(px)&&arten.includes(e.art)&&out.length<(R.merken||6)) out.push({px:px, art:e.art}); });
 return out; }
function ckrSchreiben(liste){ const a=ckrAlle(); if(liste.length) a[CK.coin]=liste; else delete a[CK.coin];
 try{ window.localStorage.setItem(CKR_KEY, JSON.stringify(a)); CKR.speicher=true; }catch(e){ CKR.speicher=false; } }
// Eingabe lesen: deutsche Schreibweise zuerst (61.500 = einundsechzigtausendfünfhundert, 65,39), dann die andere Lesart (65.39, 61,500).
// Stehen zwei Lesarten zur Wahl, gilt die, die zum jetzigen Kurs passt (zwischen einem Fünftel und dem Fünffachen).
function ckrLesen(text, kurs, faktor){ const t=String(text==null?'':text).replace(/[\s']/g,'');
 if(!t) return {ok:false, grund:'Bitte einen Kurs eintippen.'};
 if(!/^[0-9.,]+$/.test(t)||!/[0-9]/.test(t)) return {ok:false, grund:'Bitte nur Ziffern, Punkt und Komma.'};
 const K=[], nk=(t.match(/,/g)||[]).length, np=(t.match(/\./g)||[]).length;
 const zahl=s=>{ const v=parseFloat(s); return /^\d*\.?\d*$/.test(s)&&isFinite(v)&&v>0?v:null; };
 if(nk&&np){ const dez=t.lastIndexOf(',')>t.lastIndexOf('.')?',':'.', tsd=dez===','?'.':',';          // beide Zeichen: das letzte ist das Dezimalzeichen
  if((dez===','?nk:np)===1) K.push(zahl(t.split(tsd).join('').replace(dez,'.'))); }
 else if(nk){ if(nk===1) K.push(zahl(t.replace(',','.')));                                             // nur Komma: Dezimalkomma ...
  if(/^\d{1,3}(,\d{3})+$/.test(t)) K.push(zahl(t.split(',').join(''))); }                               // ... oder Tausenderkomma
 else if(np){ if(/^\d{1,3}(\.\d{3})+$/.test(t)) K.push(zahl(t.split('.').join('')));                    // Punkt vor je drei Ziffern: Tausenderpunkt ...
  if(np===1) K.push(zahl(t)); }                                                                       // ... oder Dezimalpunkt
 else K.push(zahl(t));
 const G=K.filter(v=>v!=null);
 if(!G.length) return {ok:false, grund:'Das ist kein lesbarer Kurs.'};
 if(!(kurs>0)) return {ok:true, px:G[0]};
 const f=faktor>1?faktor:5, drin=G.find(v=>v>=kurs/f&&v<=kurs*f);
 if(drin==null) return {ok:false, grund:'Der Kurs liegt außerhalb des Bereichs des Rechners ('+ckPx(kurs/f)+' bis '+ckPx(kurs*f)+').'};
 return {ok:true, px:drin}; }
function ckrKurse(){ const L=ckrListe().map(e=>e.px); if(CKR.kurs!=null&&!L.includes(CKR.kurs)) L.unshift(CKR.kurs); return L; }
function ckrUrl(){ const K=ckrKurse(); return CK.coin&&K.length?'/cockpit/rechner?coin='+encodeURIComponent(CK.coin)+'&kurs='+encodeURIComponent(K.join(',')):''; }
function ckrCoin(){ if(CKR.coin===CK.coin) return;                     // anderer Coin: Eingabe und Ergebnis gehören zum alten
 CKR.coin=CK.coin; CKR.d=null; CKR.kurse=[]; CKR.kurs=null; CKR.text=''; CKR.meldung=''; CKR.anfrage=''; CKR.fehler=null; }
async function ckrLaden(erzwungen){ const url=ckrUrl();
 if(!url){ CKR.d=null; CKR.kurse=[]; CKR.anfrage=''; CKR.fehler=null; return; }
 if(CKR.laeuft) return;
 if(!erzwungen&&CKR.d&&CKR.anfrage===url&&Date.now()-CKR.geladen<50000) return;
 CKR.laeuft=true; const K=ckrKurse(), coin=CK.coin; let d=null, f=null;
 try{ d=await getJSON(url); }catch(e){ f=String(e&&e.message||e); }
 CKR.laeuft=false;
 if(coin!==CK.coin){ ckrLaden(true); return; }                        // inzwischen ein anderer Coin: die Antwort gehört zum alten und wird verworfen
 if(f) CKR.fehler=f; else { CKR.d=d; CKR.kurse=K; CKR.anfrage=url; CKR.fehler=null; CKR.geladen=Date.now(); }
 ckZeichne();
 if(!CKR.fehler&&ckrUrl()&&ckrUrl()!==CKR.anfrage) ckrLaden(true); }  // inzwischen kam ein Kurs dazu oder weg
function ckrMeldText(d){ const R=d.rechner||{}, k=d.kopf||{};
 if(CKR.meldung) return CKR.meldung;
 return k.frisch&&k.kurs!=null?(R.hinweis||'')+' Kurs jetzt: '+ckPx(k.kurs)+'.':'Kein frischer Kurs: Der Rechner rechnet nur vom jetzigen Kurs.'; }
function ckrMeld(){ const m=$('ckr_meld'); if(m&&CK.d) m.textContent=ckrMeldText(CK.d); }
function ckrWartet(){ return CKR.fokus&&Date.now()-CKR.taste<15000; }
function ckrFokus(an){ CKR.fokus=!!an; CKR.taste=Date.now();
 if(!an) setTimeout(()=>{ if(CKR.offen&&!CKR.fokus) ckZeichne(); }, 400); }                           // erst nach dem Klick auf einen Knopf der Karte neu zeichnen
function ckrEingabe(el){ CKR.text=String(el.value||'').replace(/[^0-9.,\s]/g,'').slice(0,24); if(el.value!==CKR.text) el.value=CKR.text;
 CKR.taste=Date.now(); if(CKR.meldung){ CKR.meldung=''; ckrMeld(); } }
function ckrTaste(ev){ CKR.taste=Date.now(); if(ev.key==='Enter'){ if(ev.preventDefault) ev.preventDefault(); ckrRechnen(); } }
function ckrRechnen(){ const d=CK.d||{}, R=d.rechner||{}, k=d.kopf||{}, e=ckrLesen(CKR.text, k.frisch?k.kurs:null, R.faktor);
 if(!e.ok){ CKR.meldung=e.grund; ckrMeld(); return; }
 CKR.kurs=e.px; CKR.meldung=''; CKR.text=''; CKR.fokus=false;
 const el=$('ckr_ein'); if(el){ el.value=''; if(el.blur) el.blur(); }
 ckZeichne(); ckrLaden(true); }
function ckrMerken(art){ const R=(CK.d&&CK.d.rechner)||{}; if(CKR.kurs==null) return; const L=ckrListe();
 if(!(R.arten||[]).some(a=>a[0]===art)) return;
 if(L.some(e=>e.px===CKR.kurs&&e.art===art)){ CKR.kurs=null; ckZeichne(); return; }
 if(L.length>=(R.merken||6)){ CKR.meldung='Für '+CK.coin+' sind schon '+L.length+' Kurse gemerkt. Erst einen entfernen.'; ckZeichne(); return; }
 L.push({px:CKR.kurs, art:art}); ckrSchreiben(L); CKR.kurs=null;
 CKR.meldung=CKR.speicher===false?'Dieser Browser erlaubt kein Speichern: Der Kurs gilt bis zum Neuladen der Seite.':'';
 ckZeichne(); ckrLaden(false); }
function ckrMehr(auf){ CKR.mehr=!!auf; }
function ckrWeg(i){ if(i<0) CKR.kurs=null; else { const L=ckrListe(); if(i<L.length){ L.splice(i,1); ckrSchreiben(L); } }
 CKR.meldung=''; ckZeichne(); ckrLaden(false); }
function ckrZeile(z, name, px, i, R){ const F=R.fristen||[];
 const zellen=F.map((f,j)=>{ const p=z&&z.ok&&z.p?z.p[j]:null, t=z?((z.p_text||[])[j]||'—'):'…';
  return `<div class="ckrz"><span class="ckleise">${esc(f[2])}</span><span class="ckrbk" aria-hidden="true"><i style="width:${p!=null?Math.max(p>0?2:0,Math.round(p*100)):0}%"></i></span><b>${esc(t)}</b></div>`; }).join('');
 const lage=z&&z.ok?(z.abstand_text?z.abstand_text+' '+z.lage:z.lage):(z?'':'wird gerechnet');
 return `<div class="ckrzeile"${z&&z.satz?` role="group" aria-label="${esc(z.satz)}"`:''}><div class="ckrkopf"><div class="ckrname"><b>${name?esc(name)+' ':''}${ckPx(px)}</b>`
  +`<span class="ckleise">${esc(lage)}</span></div>`
  +`<button type="button" class="ckrx" aria-label="${esc((name||'Kurs')+' '+ckPx(px))} entfernen" title="entfernen" onclick="ckrWeg(${i})">×</button></div>`
  +(z&&z.ok===false?`<div class="ckfehlt">${esc(z.grund||'kein Wert')}</div>`:`<div class="ckrzellen">${zellen}</div>`)
  +(z&&z.hinweise&&z.hinweise.length?`<div class="ckleise">${z.hinweise.map(esc).join(' ')}</div>`:'')+`</div>`; }
function ckRechner(d){ const R=d.rechner; if(!R) return '';
 const E=CKR.d&&CKR.d.coin===d.coin&&CKR.d.ok!==false?CKR.d:null, K=CKR.kurse||[], L=ckrListe();
 const zu=px=>{ const j=E&&E.zeilen?K.indexOf(px):-1; return j>=0?(E.zeilen[j]||null):null; };
 const namen={}; (R.arten||[]).forEach(a=>{ namen[a[0]]=a[1]; });
 const neu=CKR.kurs!=null&&!L.some(e=>e.px===CKR.kurs);
 let h=`<div class="ckk"><div class="ckt">Kurs-Rechner <span class="ckleise cktn">wird ein Kurs berührt?</span></div>`
  +`<div class="ckrein"><input id="ckr_ein" class="ckrin" type="text" inputmode="decimal" autocomplete="off" enterkeyhint="go" maxlength="24" placeholder="Kurs eintippen" `
  +`aria-label="Kurs für den Kurs-Rechner" value="${esc(CKR.text)}" oninput="ckrEingabe(this)" onkeydown="ckrTaste(event)" onfocus="ckrFokus(true)" onblur="ckrFokus(false)">`
  +`<button type="button" class="ckrb" onclick="ckrRechnen()">Rechnen</button></div>`
  +`<div class="ckleise" id="ckr_meld" aria-live="polite">${esc(ckrMeldText(d))}</div>`;
 if(neu) h+=ckrZeile(zu(CKR.kurs), '', CKR.kurs, -1, R)
  +`<div class="ckrmerk"><span class="ckleise">${esc(R.merk_kurz||'Merken als')}</span><div class="ckrpillen">`
  +(R.arten||[]).map(a=>`<button type="button" class="ckvb" onclick="ckrMerken('${esc(a[0])}')">${esc(a[1])}</button>`).join('')+`</div></div>`;
 if(L.length) h+=`<div class="ckleise ckstand">Gemerkt für ${esc(d.coin||'')}</div>`+L.map((e,i)=>ckrZeile(zu(e.px), namen[e.art]||'', e.px, i, R)).join('');
 if(CKR.fehler&&(neu||L.length)) h+=`<div class="ckfehlt">Kurs-Rechner nicht erreichbar: ${esc(CKR.fehler)}</div>`;
 if(CKR.d&&CKR.d.coin===d.coin&&CKR.d.ok===false) h+=`<div class="ckfehlt">${(CKR.d.fehlt||['Kurs-Rechner: keine Antwort']).map(esc).join(' ')}</div>`;
 if(E&&(E.fehlt||[]).length) h+=`<div class="ckfehlt">${E.fehlt.map(esc).join(' ')}</div>`;
 if(E&&(E.hinweise||[]).length) h+=`<div class="ckfehlt">${E.hinweise.map(esc).join(' ')}</div>`;
 h+=`<div class="ckbeleg">${esc(E?(E.beleg_kurz||''):(R.beleg||''))}</div>`;
 if(E) h+=`<details class="ckrmehr"${CKR.mehr?' open':''} ontoggle="ckrMehr(this.open)"><summary>Beleg und Grenzen</summary>`
  +(E.belege||[]).concat([E.beleg_allg, R.merk_hinweis, 'Stand der Rechnung: '+ckZeit(E.jetzt)+'.']).filter(Boolean).map(x=>`<div class="ckbeleg">${esc(x)}</div>`).join('')+`</details>`;
 return h+`</div>`; }

// ---------- Markt-Messwerte (Klasse B, neutral) und Kosten ----------
function ckMesswerte(d){ const M=d.messwerte||[];
 return `<div class="ckk"><div class="ckt">Markt-Messwerte</div>`+M.map(m=>{
   const pz=m.pz!=null?Math.max(0,Math.min(1,m.pz)):null;
   const wert=m.key==='oi'?(m.wert!=null?ckZ(m.wert,0)+' '+esc(d.coin||''):'—'):(m.text||'—');
   const stand=m.wert==null?'':(m.stand?(m.art==='live'?'live, ':'Stand ')+ckZeit(m.stand):(m.stand_tag?'Tagesstand '+m.stand_tag:''));
   const zone=m.zone!=null?`<u style="width:${(Math.max(0,Math.min(1,m.zone))*100).toFixed(1)}%"></u>`:'';       // 23.108: markierter Bereich (unterstes Zehntel)
   return `<div class="ckmess"><div class="ckmz"><span>${esc(m.name)}</span><b>${esc(wert)}${m.marke!=null?' · Schwelle '+ckZ(m.marke,0):''}</b></div>`
    +(pz!=null&&m.pz_n!=null?`<div class="ckmz2"><span class="ckspur" role="img" aria-label="${m.pz_n}. Perzentil ${m.basis?'gegen '+esc(m.basis):'der letzten 90 Tagesstände'}">${zone}<i style="left:calc(${(pz*100).toFixed(1)}% - 5px)"></i></span>`
      +`<span class="ckleise">${m.pz_n}. Perzentil</span></div>`+(m.basis?`<div class="ckleise">gegen ${esc(m.basis)}</div>`:'')
     :`<div class="ckleise">${m.wert!=null?(m.basis?esc(m.basis):(m.key==='funding'?'z-Wert gegen 30 Tage, ohne Perzentil':'ohne Perzentil')):(m.fehlt?'kein Wert: '+esc(m.fehlt):'kein Wert')}</div>`)
    +(m.note?`<div class="ckleise">${esc(m.note)}</div>`:'')
    +(stand?`<div class="ckleise ckstand">${esc(stand)}</div>`:'')+`</div>`; }).join('')
  +`<div class="ckbeleg">${esc(d.messwerte_beleg||'')}</div></div>`; }

// ---------- 23.108 Liquidationsdichte (Klasse B, gemessen): Positionswert mit Liquidationspreis bis 3 % vom Kurs, ein Balken je 0,5 %.
// Eine Farbe (Messwert), die beiden Seiten trennt die Lage zum Kurs und die Beschriftung; kein Rot/Grün. Antippen wählt eine Stufe,
// die Zahlen aller Stufen stehen als Liste darunter. Ist der Schnappschuss nicht frisch, sind die Balken grau.
function ckUsd(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x);
 if(a>=1e9) return ckZ(x/1e9,2)+' Mrd. USD'; if(a>=1e6) return ckZ(x/1e6,1)+' Mio. USD'; if(a>=1e3) return ckZ(x/1e3,0)+' Tsd. USD'; return ckZ(x,0)+' USD'; }
function ckLiqWahl(i){ CK.liq=(CK.liq===i?null:i); ckZeichne(); }
function ckLiqListe(auf){ CK.liqliste=!!auf; }                         // die aufgeklappte Liste bleibt beim nächsten Zeichnen (jede Minute) offen
function ckLiqStufe(b){ const f=x=>(x>0?'+':'')+ckZ(x*100,1); return f(b.von)+' bis '+f(b.bis)+' %'; }
function ckLiqdichte(d){ const L=d.liqdichte; if(!L) return '';
 const kopf=`<div class="ckt">Liquidationsdichte <span class="ckleise cktn">± ${ckZ((L.breite||0)*100,0)} % um den Kurs · gemessen</span></div>`;
 if(!L.ok) return `<div class="ckk ckgrau">${kopf}<div class="ckfehlt">${(L.fehlt&&L.fehlt.length?L.fehlt:['Noch kein Stand.']).map(esc).join(' ')}</div><div class="ckbeleg">${esc(L.beleg||'')}</div></div>`;
 const B=L.balken||[], mx=Math.max(1, ...B.map(b=>b.usd||0)), farbe=L.frisch?CK_F.info:CK_F.grau, halb=B.length/2;
 const gr=B.reduce((a,b,i)=>(b.usd||0)>(B[a].usd||0)?i:a, 0), wahl=(CK.liq!=null&&B[CK.liq])?CK.liq:null;
 const text=b=>`${ckLiqStufe(b)}: ${ckUsd(b.usd)}, ${b.n===1?'1 Position':(b.n||0)+' Positionen'}`;
 const ab=[];
 if(L.abdeckung!=null) ab.push(`Erfasst: ${ckZ(L.abdeckung*100,0)} % des Open Interest.`);
 if(L.alt_coin_groesse!=null&&L.alt_dazu!=null){ const g=L.alt_coin_groesse, n=L.alt_coin_n||0, c=L.coin||'Coin';   // 23.113 (U272 Teil 2): nach Größe statt nach Köpfen
  ab.push(`Nicht enthalten, weil seit über ${ckZ((L.alter_s||3600)/60,0)} Minuten nicht abgefragt: ${ckZ(n,0)} ${c}-${n===1?'Position':'Positionen'} mit zusammen ${ckZ(g,Math.abs(g)>=100?0:(Math.abs(g)>=1?1:3))} ${c} – mit ihnen wären es ${ckZ(L.alt_dazu*100,1)} Prozentpunkte mehr.`); }
 else if(L.alt_anteil!=null) ab.push(`${ckZ(L.alt_anteil*100,0)} % der bekannten Positionen (alle Coins) sind zu lange nicht abgefragt und nicht enthalten.`);
 if(L.anlauf) ab.push(`Der Recorder läuft erst seit ${ckZ(Math.max(0,Math.floor((L.laufzeit_s||0)/60)),0)} Minuten: Der Stand ist noch im Aufbau, die Summen sind kleiner als sonst.`);
 if(L.ueberholt_n||L.ueberholt_usd) ab.push(`Vom Kurs überholt und nicht gezeigt: ${ckUsd(L.ueberholt_usd)}.`);
 return `<div class="ckk${L.frisch?'':' ckgrau'}">${kopf}`
  +`<div class="ckzeile"><span>${esc(L.name_unten||'unter dem Kurs')}</span><b>${esc(ckUsd(L.summe_unten))}</b></div>`
  +`<div class="ckzeile"><span>${esc(L.name_oben||'über dem Kurs')}</span><b>${esc(ckUsd(L.summe_oben))}</b></div>`
  +`<div class="ckliq" role="group" aria-label="Liquidationsdichte je Stufe von ${ckZ((L.stufe||0)*100,1)} %, links unter dem Kurs, rechts darüber">`
  +B.map((b,i)=>`<button type="button" class="ckliqs${wahl===i?' an':''}${i===halb?' ckliqm':''}" onclick="ckLiqWahl(${i})" aria-pressed="${wahl===i}" title="${esc(text(b))}" aria-label="${esc(text(b))}">`
   +`<i style="height:${((b.usd||0)/mx*100).toFixed(1)}%;background:${farbe}${(b.usd||0)>0?';min-height:2px':''}"></i></button>`).join('')+`</div>`
  +`<div class="ckliqa" aria-hidden="true"><span>−${ckZ((L.breite||0)*100,0)} %</span><span>Kurs ${esc(ckPx(L.kurs))}</span><span>+${ckZ((L.breite||0)*100,0)} %</span></div>`
  +`<div class="ckleise" aria-live="polite">${wahl!=null?'Gewählt: '+esc(text(B[wahl])):((B[gr]&&(B[gr].usd||0)>0)?'Größte Stufe: '+esc(text(B[gr]))+'. Antippen zeigt eine Stufe.':'In diesem Bereich liegt keine erfasste Position.')}</div>`
  +(ab.length?`<div>${ab.map(esc).join(' ')}</div>`:'')
  +`<details class="ckrmehr"${CK.liqliste?' open':''} ontoggle="ckLiqListe(this.open)"><summary>Zahlen je Stufe</summary>`+B.map(b=>`<div class="ckzeile"><span>${esc(ckLiqStufe(b))}</span><b>${esc(ckUsd(b.usd))} · ${b.n||0}</b></div>`).join('')
  +`<div class="ckleise">Betrag und Zahl der Positionen je Stufe.</div></details>`
  +(L.fehlt&&L.fehlt.length?`<div class="ckfehlt">${L.fehlt.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(L.beleg||'')} ${esc(L.magnet||'')} Stand: ${esc(ckZeit(L.stand))}.</div></div>`; }
// ---------- 23.100 (U254) Unstaking: angemeldete Abzüge aus dem Ethereum-Staking mit ihrem festen Zeitpunkt -- nur bei ETH. Gemessen: blau,
// keine Warnfarbe; große Tage unterscheiden sich in der Form (fett, höherer Balken, Punkt). 23.101 (U255): unter dem Termin steht das
// gespeicherte Urteil der Prüfung der Kursfolge (U.pruefung.kurz) -- Text, keine Farbe, auch bei „belegt“.
function ckUnstaking(d){ const U=d.unstaking; if(!U) return '';
 const kopf=`<div class="ckt">Unstaking <span class="ckleise cktn">Ethereum-Staking · gemessen${U.geschaetzt?', geschätzt':''}</span></div>`;
 if(!U.ok) return `<div class="ckk ckgrau">${kopf}<div class="ckfehlt">${(U.fehlt&&U.fehlt.length?U.fehlt:['Noch kein Stand.']).map(esc).join(' ')}</div><div class="ckbeleg">${esc(U.beleg||'')}</div></div>`;
 const T=U.tage||[];
 const zeile=t=>`<div class="ckutag${t.gross?' gross':''}"><span>${esc(t.tag)}</span><span class="ckubalken" aria-hidden="true"><i style="width:${Math.max(t.eth>0?2:0,Math.round((t.anteil||0)*100))}%"></i></span><span class="r">${ckZ(t.eth,0)}${t.gross?' ●':''}</span></div>`;
 return `<div class="ckk">${kopf}`
  +`<div class="ckuz"><span class="ckuw">${ckZ(U.summe_eth,0)} ETH</span><span class="ckleise">angemeldet, noch nicht frei${U.usd_text?' · ≈ '+esc(U.usd_text):''}</span></div>`
  +`<div>${U.ende_ts?'Alles Angemeldete ist frei bis <b>'+esc(ckZeit(U.ende_ts))+'</b> (Ortszeit).':'Nichts Angemeldetes steht aus.'}</div>`
  +`<div class="ckusatz">${esc(U.satz||'')}</div>`
  +(U.pruefung&&U.pruefung.kurz?`<div class="ckupruef">${esc(U.pruefung.kurz)}</div>`:'')
  +(T.length?`<div class="ckleise ckstand">Kalender „frei ab“ je UTC-Tag, in ETH · ● = Tag ab ${ckZ(U.schwelle,0)} ETH</div>`+T.map(zeile).join(''):'')
  +(U.tage_mehr?`<div class="ckleise ckstand">später: ${ckZ(U.tage_mehr_eth,0)} ETH an ${U.tage_mehr} weiteren Tagen</div>`:'')
  +(U.abzieher||[]).map((a,i)=>`<div class="ckuab">${i?'Weiterer':'Größter'} Abzieher ${esc(a.kurz)}: <b>${ckZ(a.eth,0)} ETH</b>${a.anteil!=null?' ('+ckZ(a.anteil*100,0)+' % der Vollabzüge)':''}, frei ${esc(a.von)} bis ${esc(a.bis)}</div>`).join('')
  +[U.gegenseite,U.nicht_gezaehlt].filter(Boolean).map(x=>`<div class="ckleise">${esc(x)}</div>`).join('')
  +(U.hinweise&&U.hinweise.length?`<div class="ckfehlt">${U.hinweise.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(U.auszahlung||'')} ${esc(U.beleg||'')} Stand: ${esc(ckZeit(U.stand))}, Quelle: ${U.quelle==='knoten'?'Beacon-Knoten':'Tagesdatei von validatorqueue.com'}.</div></div>`; }

// ---------- 23.104 (U260) Karte „Unstaking · Verlauf“: Schlange der Abzüge und ETH-Kurs je UTC-Tag in zwei Feldern mit gemeinsamer
// Zeitachse (keine zweite Skala in einem Feld), die Wellen der Prüfung der Kursfolge als Marken, Zeiträume ohne Daten grau. Daten:
// /cockpit/unstaking (hl_cockpit.verlauf_nutzlast), nur bei ETH, höchstens alle 30 min. Gemessen: ohne Warnfarbe, ohne Urteil; die Sätze
// kommen fertig vom Server, das Skript rechnet nur Lage und Achsen. Farben der beiden Linien gegen die Kartenfläche geprüft
// (Helligkeit, Farbsehschwäche, Kontrast); Text trägt nie die Farbe der Linie.
const CKV={d:null, laeuft:false, geladen:0, fehler:null, bereich:null, wahl:null, liste:false, skala:{}};
const CKV_F={q:'#388bfd', px:'#bb8009', marke:'#c9d1d9', gitter:'#21262d', luecke:'#30363d'};
const CKV_MON=['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
const CKV_RAND=[46,6];                                                 // links Platz für die Beschriftung der Achse, rechts Luft für den letzten Punkt (px)
async function ckvLaden(erzwungen){ if(CKV.laeuft) return; if(!erzwungen&&CKV.d&&Date.now()-CKV.geladen<1800000) return;
 CKV.laeuft=true;
 try{ CKV.d=await getJSON('/cockpit/unstaking'); CKV.fehler=null; CKV.geladen=Date.now(); }
 catch(e){ CKV.fehler=String(e&&e.message||e); }
 CKV.laeuft=false; ckZeichne(); }
function ckvZ2(n){ return (n<10?'0':'')+n; }
function ckvDatum(i){ const x=new Date((CKV.d.d0+i)*86400000); return ckvZ2(x.getUTCDate())+'.'+ckvZ2(x.getUTCMonth()+1)+'.'+x.getUTCFullYear(); }
function ckvQ(i){ const V=CKV.d; if(V.q&&V.q[i]!=null) return {v:V.q[i], eigen:false};       // Tagesdatei zuerst (die Reihe der Prüfung), sonst die eigene Messung
 const K=V.k; if(K&&K.w&&i>=K.ab&&i<K.ab+K.w.length&&K.w[i-K.ab]!=null) return {v:K.w[i-K.ab], eigen:true};
 return null; }
function ckvBereich(){ const V=CKV.d, B=V.bereiche||[]; return B.find(b=>b.key===(CKV.bereich||V.start))||B[B.length-1]||{key:'alles', name:'alles', tage:V.n}; }
function ckvFenster(){ const V=CKV.d, len=Math.max(2,Math.min(V.n,ckvBereich().tage||V.n)); return {i0:V.n-len, i1:V.n-1, len:len}; }
function ckvLetzter(){ const V=CKV.d; return V.letzter!=null?V.letzter:V.n-1; }
function ckvKurz(v){ const a=Math.abs(v); if(a>=1e6) return ckZ(v/1e6, a%1e6?1:0)+' Mio.'; if(a>=1e4) return ckZ(v/1e3,0)+' Tsd.'; return ckZ(v,0); }
function ckvStufen(lo,hi,ziel){ const roh=Math.max(hi-lo,1e-9)/Math.max(1,ziel), p=Math.pow(10,Math.floor(Math.log10(roh)));
 const s=[1,2,2.5,5,10].map(m=>m*p).find(m=>m>=roh-1e-12)||10*p, T=[];
 for(let v=Math.ceil(lo/s-1e-9)*s; v<=hi+s*1e-9; v+=s) T.push(Math.round(v/s)*s+0);       // +0: aus −0 wird 0
 return T; }
function ckvWelleNahe(i,tol){ let b=null; (CKV.d.wellen||[]).forEach(w=>{ const a=Math.abs(w.i-i); if(a<=tol&&(b===null||a<Math.abs(b.i-i))) b=w; }); return b; }
function ckvZeitmarken(f){ const V=CKV.d, T=[], art=f.len<=100?'m':f.len<=400?'q':'j';              // Monatsanfänge, Quartalsanfänge oder Jahresanfänge (UTC)
 for(let i=f.i0+1;i<=f.i1;i++){ const x=new Date((V.d0+i)*86400000); if(x.getUTCDate()!==1) continue; const m=x.getUTCMonth();
  if((art==='j'&&m!==0)||(art==='q'&&m%3!==0)) continue;
  T.push({i:i, text:art==='j'?String(x.getUTCFullYear()):art==='q'?CKV_MON[m]+' '+String(x.getUTCFullYear()).slice(2):'1. '+CKV_MON[m]}); }
 return T; }
function ckvLese(i){ const V=CKV.d, q=ckvQ(i), p=V.px?V.px[i]:null;       // feste Höhe: das Bild darunter verschiebt sich beim Ablesen nicht
 return `<div class="ckvld"><b>${ckvDatum(i)}</b><span class="ckleise">${q?(q.eigen?'eigene Messung am Knoten':'Tagesdatei'):'Schlange ohne Wert'}</span></div>`
  +`<div class="ckvlz"><span class="ckvlk"><i class="ckvln" style="background:${CKV_F.q}"></i>${q&&q.eigen&&V.k_name?esc(V.k_name):'Schlange'}</span><span class="ckvlk"><i class="ckvln" style="background:${CKV_F.px}"></i>ETH-Kurs</span>`
  +`<b>${q?ckZ(q.v,0)+' ETH':'kein Wert'}</b><b>${p!=null?ckPx(p)+' USD':'kein Wert'}</b></div>`; }
function ckvWelleText(i){ const w=i!=null?(CKV.d.wellen||[]).find(x=>x.i===i):null; return w?esc(w.text||''):''; }
function ckvReihe(art,f){ const V=CKV.d, P=[];
 for(let i=f.i0;i<=f.i1;i++){ if(art==='px'){ const v=V.px?V.px[i]:null; if(v!=null) P.push({i:i, v:v, e:false}); } else { const q=ckvQ(i); if(q) P.push({i:i, v:q.v, e:q.eigen}); } }
 return P; }
function ckvFeld(art,f,ZM){ const V=CKV.d, P=ckvReihe(art,f), farbe=CKV_F[art], X=i=>(i-f.i0)/(f.len-1)*1000;
 let lo=0, hi=1;
 if(P.length){ const mn=Math.min(...P.map(p=>p.v)), mx=Math.max(...P.map(p=>p.v));
  if(art==='px'){ const sp=(mx-mn)||mx*0.02||1; lo=mn-sp*0.08; hi=mx; } else { hi=mx>0?mx:1; } }           // Schlange immer ab null: die Fläche zeigt die Menge
 CKV.skala[art]={lo:lo, hi:hi};
 const Y=v=>100-(v-lo)/(hi-lo)*86;                                    // oben 14 % Luft für die Beschriftung
 let svg='', html='';
 (P.length?ckvStufen(lo,hi,art==='px'?4:3):[]).forEach(t=>{ const y=Y(t).toFixed(2);
  svg+=`<line x1="0" x2="1000" y1="${y}" y2="${y}" stroke="${CKV_F.gitter}" stroke-width="1" vector-effect="non-scaling-stroke"></line>`;
  html+=`<span class="ckvy" style="top:${y}%">${art==='px'?ckZ(t,0):ckvKurz(t)}</span>`; });
 ZM.forEach(t=>{ const x=X(t.i).toFixed(1); svg+=`<line x1="${x}" x2="${x}" y1="0" y2="100" stroke="${CKV_F.gitter}" stroke-width="1" vector-effect="non-scaling-stroke"></line>`; });
 if(art==='q') (V.luecken||[]).forEach(g=>{ const a=Math.max(g[0],f.i0), b=Math.min(g[1],f.i1); if(a>b) return;
  const x0=Math.max(0,X(a-0.5)), x1=Math.min(1000,X(b+0.5));
  svg+=`<rect x="${x0.toFixed(1)}" y="0" width="${(x1-x0).toFixed(1)}" height="100" fill="${CKV_F.luecke}" fill-opacity="0.55"></rect>`;
  if(x1-x0>=200) html+=`<span class="ckvlt" style="left:${((x0+x1)/20).toFixed(2)}%">keine Daten</span>`; });
 const S=[]; let s=[];                                                // Linie nur über Tage ohne Lücke und aus derselben Quelle
 P.forEach((p,j)=>{ if(j&&(p.i-P[j-1].i>(V.luecke_tage||3)||p.e!==P[j-1].e)){ S.push(s); s=[]; } s.push(p); }); if(s.length) S.push(s);       // Abstand über 3 = mindestens 3 Tage fehlen
 S.forEach(s=>{ if(s.length<2){ html+=`<i class="ckvpkt" style="left:${(X(s[0].i)/10).toFixed(2)}%;top:${Y(s[0].v).toFixed(2)}%;background:${farbe}"></i>`; return; }
  const d=s.map((p,j)=>(j?'L':'M')+X(p.i).toFixed(1)+' '+Y(p.v).toFixed(2)).join('');
  if(art==='q') svg+=`<path d="${d}L${X(s[s.length-1].i).toFixed(1)} 100L${X(s[0].i).toFixed(1)} 100Z" fill="${farbe}" fill-opacity="0.12" stroke="none"></path>`;
  svg+=`<path d="${d}" fill="none" stroke="${farbe}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>`; });
 (V.wellen||[]).forEach(w=>{ if(w.i<f.i0||w.i>f.i1) return; const x=X(w.i);
  svg+=`<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="0" y2="100" stroke="${CKV_F.marke}" stroke-opacity="0.5" stroke-width="1" vector-effect="non-scaling-stroke"></line>`;
  if(art==='px') html+=`<i class="ckvw${w.neu?' ckvwn':''}" style="left:${(x/10).toFixed(2)}%"></i>`; });       // 23.106: neue Welle = offener Kreis
 const i=CKV.wahl, zeigen=i!=null&&i>=f.i0&&i<=f.i1, wert=zeigen?(art==='px'?(V.px?V.px[i]:null):(ckvQ(i)||{}).v):null, xs=zeigen?(X(i)/10).toFixed(2):'0';
 html+=`<i class="ckvk" id="ckvk_${art}" style="left:${xs}%;display:${zeigen?'block':'none'}"></i>`
  +`<i class="ckvkp" id="ckvp_${art}" style="left:${xs}%;top:${wert!=null?Y(wert).toFixed(2):'0'}%;background:${farbe};display:${zeigen&&wert!=null?'block':'none'}"></i>`;
 return `<div class="ckvp"><div class="ckvpt"><i class="ckvln" style="background:${farbe}"></i>${esc((art==='px'?V.achse_px:V.achse_q)||'')}${P.length?'':' · kein Wert'}</div>`
  +`<div class="ckvfl"><div class="ckvin" style="left:${CKV_RAND[0]}px;right:${CKV_RAND[1]}px"><svg viewBox="0 0 1000 100" preserveAspectRatio="none" aria-hidden="true">${svg}</svg>${html}</div></div></div>`; }
function ckvMarke(){ const V=CKV.d; if(!V) return; const f=ckvFenster(), i=CKV.wahl, zeigen=i!=null&&i>=f.i0&&i<=f.i1;     // Auswahl nachführen, ohne neu zu zeichnen
 const L=$('ckvlese'), T=$('ckvwelle'); if(L) L.innerHTML=ckvLese(zeigen?i:ckvLetzter()); if(T) T.innerHTML=ckvWelleText(zeigen?i:null);
 ['px','q'].forEach(a=>{ const k=$('ckvk_'+a), p=$('ckvp_'+a), S=CKV.skala[a]; if(!k||!p||!S) return;
  const x=zeigen?((i-f.i0)/(f.len-1)*100).toFixed(2)+'%':'0%', w=zeigen?(a==='px'?(V.px?V.px[i]:null):(ckvQ(i)||{}).v):null;
  k.style.left=x; k.style.display=zeigen?'block':'none'; p.style.left=x; p.style.display=zeigen&&w!=null?'block':'none';
  if(w!=null) p.style.top=(100-(w-S.lo)/(S.hi-S.lo)*86).toFixed(2)+'%'; }); }
function ckvWahl(i){ if(!CKV.d) return; CKV.wahl=i; ckvMarke(); }
function ckvZeig(ev){ const el=ev&&ev.currentTarget; if(!CKV.d||!el||!el.getBoundingClientRect) return; const r=el.getBoundingClientRect();
 const b=r.width-CKV_RAND[0]-CKV_RAND[1]; if(!(b>0)) return;          // die Zeichenfläche beginnt nach dem linken Rand
 const f=ckvFenster(), a=Math.max(0,Math.min(1,(ev.clientX-r.left-CKV_RAND[0])/b)); let i=f.i0+Math.round(a*(f.len-1));
 const w=ckvWelleNahe(i, Math.max(1,Math.round((ev.pointerType==='mouse'?5:12)/b*(f.len-1))));       // nahe einer Marke rastet die Auswahl auf die Welle
 if(w&&w.i>=f.i0&&w.i<=f.i1) i=w.i;
 ckvWahl(i); }
function ckvTaste(ev){ if(!CKV.d||(ev.key!=='ArrowLeft'&&ev.key!=='ArrowRight')) return; const f=ckvFenster(), s=(ev.shiftKey?7:1)*(ev.key==='ArrowLeft'?-1:1);
 if(ev.preventDefault) ev.preventDefault(); ckvWahl(Math.max(f.i0,Math.min(f.i1,(CKV.wahl!=null?CKV.wahl:ckvLetzter())+s))); }
function ckvWaehle(k){ CKV.bereich=k; ckZeichne(); }
function ckvListe(auf){ CKV.liste=!!auf; }
function ckVerlauf(d){ if(!d.unstaking) return '';
 const kopf=`<div class="ckt">Unstaking · Verlauf <span class="ckleise cktn">gemessen</span></div>`, V=CKV.d;
 if(!V) return `<div class="ckk">${kopf}<div class="ckleise">${CKV.fehler?'Verlauf nicht erreichbar: '+esc(CKV.fehler):'Verlauf lädt …'}</div></div>`;
 if(V.ok===false||!(V.n>=2)) return `<div class="ckk ckgrau">${kopf}<div class="ckfehlt">${(V.fehlt&&V.fehlt.length?V.fehlt:['Noch kein Verlauf.']).map(esc).join(' ')}</div></div>`;
 const f=ckvFenster(), ber=ckvBereich(); if(CKV.wahl!=null&&(CKV.wahl<f.i0||CKV.wahl>f.i1)) CKV.wahl=null;
 const ZM=ckvZeitmarken(f), WF=(V.wellen||[]).filter(w=>w.i>=f.i0&&w.i<=f.i1);
 const knopf=(V.bereiche||[]).map(b=>`<button type="button" class="ckvb${b.key===ber.key?' an':''}" aria-pressed="${b.key===ber.key}" onclick="ckvWaehle('${esc(b.key)}')">${esc(b.name)}</button>`).join('');
 const achse=ZM.map(t=>{ const p=(t.i-f.i0)/(f.len-1)*100; return p<5||p>95?'':`<span style="left:${p.toFixed(2)}%">${esc(t.text)}</span>`; }).join('');
 const leg=`<div class="ckleg">`+((V.wellen||[]).some(w=>!w.neu)?`<span><i class="ckvmk"></i>Welle der Prüfung (${WF.filter(w=>!w.neu).length} im Ausschnitt)</span>`:'')
  +((V.wellen||[]).some(w=>w.neu)?`<span><i class="ckvmk ckvmkn"></i>neue Welle, noch nicht bewertet (${WF.filter(w=>w.neu).length} im Ausschnitt)</span>`:'')
  +((V.luecken||[]).length?`<span><i class="sw" style="background:${CKV_F.luecke}"></i>keine Daten</span>`:'')+`<span class="ckleise">Antippen zeigt Tag und Werte.</span></div>`;
 const liste=WF.length?`<details class="ckvliste"${CKV.liste?' open':''} ontoggle="ckvListe(this.open)"><summary>Wellen im Ausschnitt als Liste (${WF.length})</summary>`
  +`<div class="ckvtab ckvtk">`+(V.liste_kopf||[]).map((z,j)=>`<span${j>1?' class="r"':''}>${esc(z)}</span>`).join('')+`</div>`
  +WF.map(w=>`<button type="button" class="ckvtab ckvzl" onclick="ckvWahl(${w.i})">`+(w.zeile||[]).map((z,j)=>`<span${j>1?' class="r"':''}>${esc(z)}</span>`).join('')+`</button>`).join('')
  +`<div class="ckleise">${esc(V.liste_hinweis||'')}</div></details>`:'';
 return `<div class="ckk">${kopf}<div class="ckvbs" role="group" aria-label="Zeitraum">${knopf}</div>`
  +`<div class="ckvlese" id="ckvlese">${ckvLese(CKV.wahl!=null?CKV.wahl:ckvLetzter())}</div>`
  +`<div class="ckvfeld" id="ckvfeld" tabindex="0" role="group" aria-label="Verlauf vom ${ckvDatum(f.i0)} bis ${ckvDatum(f.i1)}: Schlange der Abzüge und ETH-Kurs je Tag, ${WF.length} Wellen markiert. Die Tasten links und rechts wählen den Tag." `
  +`onpointerdown="ckvZeig(event)" onpointermove="ckvZeig(event)" onkeydown="ckvTaste(event)">`+ckvFeld('px',f,ZM)+ckvFeld('q',f,ZM)+`</div>`
  +`<div class="ckvx" aria-hidden="true" style="margin:0 ${CKV_RAND[1]}px 0 ${CKV_RAND[0]}px">${achse}</div>`
  +`<div class="ckvlw" id="ckvwelle">${ckvWelleText(CKV.wahl)}</div>`+leg+liste
  +(V.hinweise&&V.hinweise.length?`<div class="ckfehlt">${V.hinweise.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(V.satz||'')} ${esc(V.quellen||'')} Stand: ${esc(ckZeit(V.jetzt))}.</div></div>`; }

function ckKosten(d){ const K=d.kosten||{}, Z=K.zeilen||[];
 return `<div class="ckk"><div class="ckt">Kosten: nötige Trefferquote</div>`
  +(Z.length?`<div class="ckkosten"><span class="ckleise">Horizont</span><span class="ckleise r">Taker</span><span class="ckleise r">Maker</span>`
   +Z.map(z=>`<span>${z.h} Stunden</span><b class="r">${ckZ(z.taker*100,1)} %</b><b class="r">${ckZ(z.maker*100,1)} %</b>`).join('')+`</div>`
   :`<div class="ckfehlt">${(K.fehlt||['Noch keine Werte.']).map(esc).join(' ')}</div>`)
  +`<div class="ckbeleg">${esc(K.beleg||'')}${K.taker!=null?' Gebühren '+ckZ(K.taker*100,3)+' % und '+ckZ(K.maker*100,3)+' % je Seite':''}`
  +`${K.halbspread_bps!=null?', halber Spread '+ckZ(K.halbspread_bps,2)+' bps':''}${K.taker!=null?'.':''}`
  +`${Z.length&&K.stand?' Stand '+esc(ckZeit(K.stand))+(K.tage?', mittlere Bewegung der letzten '+K.tage+' Tage':'')+'.':''}</div></div>`; }

function ckZeichne(){ const el=$('ckbody'); if(!el) return; const d=CK.d;
 if(ckrWartet()){ CKR.offen=true; return; }                             // 23.105: im Eingabefeld des Kurs-Rechners wird getippt -- danach zeichnen
 CKR.offen=false; CKR.fokus=false;
 if(!d){ el.innerHTML=`<div class="ckk ckleise">${CK.fehler?'Cockpit nicht erreichbar: '+esc(CK.fehler):'lädt …'}</div>`; return; }
 if(d.ok===false){ el.innerHTML=`<div class="ckk"><div class="ckfehlt">${(d.fehlt||['Cockpit: keine Daten']).map(esc).join(' ')}</div></div>`; return; }
 const allg=[...new Set(d.fehlt||[])];
 el.innerHTML=ckKopf(d)+ckStreifen(d)+(CK.fehler?`<div class="ckk ckfehlt">${esc(CK.fehler)}</div>`:'')+`<div class="ckraster">`+ckSatz(d)+ckLampen(d)+ckSchwankung(d)+ckSpanne(d)+ckLevels(d)+ckLinien(d)+ckRechner(d)+ckMesswerte(d)+ckLiqdichte(d)+ckUnstaking(d)+ckVerlauf(d)+ckKosten(d)+ckBetriebKarte(d)+`</div>`
  +(allg.length?`<div class="ckfehlt">${allg.map(esc).join(' · ')}</div>`:'')
  +`<div class="cklinks"><button type="button" onclick="ckGeheZu('grp-werkstatt')">Werkstatt · nicht belegt</button><button type="button" onclick="ckGeheZu('grp-betrieb')">Betrieb</button></div>`
  +`<div class="ckleise ckfuss">Nur Belegtes oder Gemessenes. Stand ${esc(ckZeit(d.jetzt))} · ${d.rechenzeit_ms!=null?d.rechenzeit_ms+' ms':''}</div>`;
 ckBetrieb(); }

function ckCss(){ if($('ck_css')) return; const st=document.createElement('style'); st.id='ck_css'; st.textContent=`
#sec-cockpit .ckkopf{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin:6px 0 10px}
#sec-cockpit .ckmarke{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#9da7b3}
#sec-cockpit .ckkurs{font-size:30px;font-weight:700;line-height:1.1;font-variant-numeric:tabular-nums;color:#e6edf3}
#sec-cockpit .ckkurs.ckalt{color:#9da7b3}
#sec-cockpit .ckleise{font-size:11px;color:#9da7b3;line-height:1.4}
#sec-cockpit .ckpille{display:flex;align-items:center;gap:8px;min-height:44px;padding:0 14px;border:1px solid #30363d;border-radius:22px;background:#161b22;color:#e6edf3;font:inherit;font-size:12px;font-weight:600;cursor:pointer;max-width:58%;text-align:left}
#sec-cockpit .ckpunkt{flex:none;width:10px;height:10px;box-sizing:border-box;border-radius:50%}
#sec-cockpit .ckstreifen{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:4px;margin:0 0 12px}
#sec-cockpit .ckcoin{display:flex;flex-direction:column;align-items:center;gap:3px;min-height:44px;padding:6px 2px;border:1px solid #30363d;border-radius:8px;background:#161b22;color:#e6edf3;font:inherit;font-size:12px;cursor:pointer;min-width:0}
#sec-cockpit .ckcoin.an{border-color:#58a6ff;background:#1b3a5c}
#sec-cockpit .ckcoin b{font-weight:700}
#sec-cockpit .ckmini{position:relative;width:86%;height:6px;background:#30363d;border-radius:3px}
#sec-cockpit .ckmini i{position:absolute;top:0;height:6px;background:#58a6ff;border-radius:3px}
#sec-cockpit .ckmini u{position:absolute;left:50%;top:-2px;width:2px;height:10px;background:#e3b341;text-decoration:none}
#sec-cockpit .ckminiz{font-size:10px;color:#c9d1d9;font-variant-numeric:tabular-nums;white-space:nowrap}
#sec-cockpit .ckpunkte{display:flex;gap:3px;height:8px;align-items:center}
#sec-cockpit .ckpunkte s{width:7px;height:7px;box-sizing:border-box;border-radius:50%;border:1.5px solid #9da7b3;text-decoration:none}
#sec-cockpit .ckpunkte s.hinweis{background:#e3b341;border-color:#e3b341}
#sec-cockpit .ckpunkte s.warnung{background:#f0883e;border-color:#f0883e;border-radius:1px}
#sec-cockpit .ckpunkte s.grau{border-style:dashed;border-color:#6e7681}
#sec-cockpit .ckan{font-size:10px}
#sec-cockpit .ckraster{column-width:340px;column-gap:12px}
#sec-cockpit .ckk{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:10px;min-width:0;color:#e6edf3;font-size:13px;line-height:1.4;margin:0 0 12px;break-inside:avoid}
#sec-cockpit .ckk.ckgrau{opacity:.62}
#sec-cockpit .ckt{font-size:12px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#9da7b3;display:flex;justify-content:space-between;align-items:baseline;gap:8px}
#sec-cockpit .cktn{text-transform:none;letter-spacing:0;font-weight:400}
#sec-cockpit .cksatz{font-size:15px;font-weight:600;line-height:1.35}
#sec-cockpit .ckausnahme{font-size:12px;border:1px solid #f0883e;border-radius:8px;padding:8px 10px}
#sec-cockpit .ckunst{font-size:12px;border:1px solid #30363d;border-left:3px solid #58a6ff;border-radius:8px;padding:8px 10px}
#sec-cockpit .cklampen{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px}
#sec-cockpit .cklampe{display:flex;flex-direction:column;align-items:center;gap:3px;text-align:center;min-height:44px;padding:6px 1px;border:1px solid transparent;border-radius:8px;background:none;color:#e6edf3;font:inherit;cursor:pointer;min-width:0}
#sec-cockpit .cklampe.an{border-color:#30363d;background:#0d1117}
#sec-cockpit .ckln{font-size:clamp(9px,2.7vw,11px);font-weight:600;white-space:nowrap}
#sec-cockpit .cklw{font-size:11px;color:#e6edf3}
#sec-cockpit .cklv{font-size:10px;color:#9da7b3;overflow-wrap:anywhere}
#sec-cockpit .ckdetail{font-size:12px;border-top:1px solid #30363d;padding-top:8px}
#sec-cockpit .ckbeleg{font-size:11px;color:#9da7b3;line-height:1.45}
#sec-cockpit .ckdetail .ckbeleg{margin-top:6px}
#sec-cockpit .ckfehlt{font-size:11px;color:#c9d1d9;border-left:2px solid #30363d;padding-left:8px}
#sec-cockpit .ckleg{display:flex;flex-wrap:wrap;align-items:center;gap:4px 12px;font-size:11px;color:#9da7b3}
#sec-cockpit .ckleg span{display:inline-flex;align-items:center;gap:5px}
#sec-cockpit .ckleg .sw{display:inline-block;width:12px;height:8px}
#sec-cockpit .ckschw{display:flex;align-items:center;gap:16px}
#sec-cockpit .ckbogen{display:flex;flex-direction:column;align-items:center;gap:2px;flex:none}
#sec-cockpit .ckgross{font-size:22px;font-weight:700;line-height:1.1;font-variant-numeric:tabular-nums}
#sec-cockpit .ckliste{flex:1;display:flex;flex-direction:column;gap:6px;font-variant-numeric:tabular-nums;min-width:0}
#sec-cockpit .ckzeile{display:flex;justify-content:space-between;gap:8px}
#sec-cockpit .ckzeile span{color:#9da7b3}
#sec-cockpit .ckzeile b{white-space:nowrap;flex:none}
#sec-cockpit .ckspanne{display:flex;flex-direction:column;gap:12px;padding-top:4px}
#sec-cockpit .ckbz{display:flex;flex-direction:column;gap:4px}
#sec-cockpit .ckbalken{position:relative;border-radius:4px}
#sec-cockpit .ckbalken i{position:absolute;top:0;bottom:0;border-radius:4px}
#sec-cockpit .ckbtext{display:flex;justify-content:space-between;gap:8px;font-size:12px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckbalken u{position:absolute;top:-4px;bottom:-4px;width:2px;margin-left:-1px;background:#e3b341;text-decoration:none}
#sec-cockpit .cklevel{display:flex;align-items:center;gap:10px;min-height:40px}
#sec-cockpit .ckln2{flex:1;display:flex;flex-direction:column;min-width:0}
#sec-cockpit .ckln2 b{font-weight:600;overflow-wrap:anywhere}
#sec-cockpit .ckpb{width:96px;flex:none;display:flex;flex-direction:column;gap:3px}
#sec-cockpit .ckpb span{display:flex;height:6px;background:#30363d;border-radius:3px}
#sec-cockpit .ckpb i{border-radius:3px}
#sec-cockpit .ckpz{width:62px;flex:none;text-align:right;font-weight:600;font-variant-numeric:tabular-nums}
#sec-cockpit .ckkurslinie{display:flex;align-items:center;gap:8px;min-height:26px;font-size:12px;color:#e3b341}
#sec-cockpit .ckkurslinie span{flex:1;height:1px;background:#e3b341}
#sec-cockpit .cklin{display:flex;flex-direction:column;gap:2px;min-width:0}
#sec-cockpit .cklink{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
#sec-cockpit .cklink b{font-weight:600}
#sec-cockpit .cklinw{font-size:16px;font-variant-numeric:tabular-nums;white-space:nowrap}
#sec-cockpit .cklinn{text-align:right;font-variant-numeric:tabular-nums}
#sec-cockpit .cklage{line-height:1.45}
#sec-cockpit .ckmess{display:flex;flex-direction:column;gap:5px;padding:2px 0}
#sec-cockpit .ckmz{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
#sec-cockpit .ckmz b{font-weight:600;font-variant-numeric:tabular-nums;text-align:right}
#sec-cockpit .ckmz2{display:flex;align-items:center;gap:10px}
#sec-cockpit .ckspur{position:relative;flex:1;height:6px;background:#30363d;border-radius:3px;min-width:40px}
#sec-cockpit .ckspur i{position:absolute;top:-2px;width:10px;height:10px;border-radius:50%;background:#58a6ff;box-shadow:0 0 0 2px #161b22}
#sec-cockpit .ckspur u{position:absolute;left:0;top:0;height:6px;background:#6e7681;border-radius:3px 0 0 3px;text-decoration:none}
#sec-cockpit .ckliq{display:flex;align-items:flex-end;gap:2px;height:84px;border-bottom:1px solid #30363d}
#sec-cockpit .ckliqs{flex:1;min-width:0;height:100%;display:flex;align-items:flex-end;padding:0;margin:0;border:0;border-radius:4px 4px 0 0;background:transparent;cursor:pointer;font:inherit;position:relative}
#sec-cockpit .ckliqs i{display:block;width:100%;border-radius:4px 4px 0 0}
#sec-cockpit .ckliqs.an{background:#1b3a5c}
#sec-cockpit .ckliqs:focus-visible{outline:2px solid #58a6ff;outline-offset:1px}
#sec-cockpit .ckliqm{margin-left:8px}
#sec-cockpit .ckliqm::before{content:'';position:absolute;left:-6px;top:0;bottom:0;width:2px;background:#e3b341}
#sec-cockpit .ckliqa{display:flex;justify-content:space-between;font-size:11px;color:#9da7b3;font-variant-numeric:tabular-nums}
#sec-cockpit .ckbtr{display:flex;gap:8px;align-items:flex-start}
#sec-cockpit .ckbtr svg{flex:none;margin-top:3px}
#sec-cockpit .ckkosten{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px 10px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckkosten .r{text-align:right}
#sec-cockpit .ckuz{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}
#sec-cockpit .ckuw{font-size:22px;font-weight:700;font-variant-numeric:tabular-nums}
#sec-cockpit .ckusatz{font-weight:600}
#sec-cockpit .ckupruef{font-size:12px;color:#c9d1d9;overflow-wrap:anywhere}
#sec-cockpit .ckutag{display:grid;grid-template-columns:72px minmax(0,1fr) 88px;gap:8px;align-items:center;font-size:12px;font-variant-numeric:tabular-nums;min-height:20px}
#sec-cockpit .ckutag .r{text-align:right;white-space:nowrap}
#sec-cockpit .ckutag.gross{font-weight:700}
#sec-cockpit .ckubalken{height:8px;background:#30363d;border-radius:4px;overflow:hidden}
#sec-cockpit .ckutag.gross .ckubalken{height:12px}
#sec-cockpit .ckubalken i{display:block;height:100%;background:#58a6ff;border-radius:4px}
#sec-cockpit .ckuab{font-size:12px;overflow-wrap:anywhere}
#sec-cockpit .ckvbs{display:flex;gap:6px;flex-wrap:wrap}
#sec-cockpit .ckvb{min-height:36px;padding:0 12px;border:1px solid #30363d;border-radius:18px;background:#161b22;color:#c9d1d9;font:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
#sec-cockpit .ckvb.an{border-color:#58a6ff;background:#1b3a5c;color:#e6edf3;font-weight:600}
#sec-cockpit .ckvlese{display:flex;flex-direction:column;gap:2px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckvld{display:flex;align-items:baseline;gap:8px}
#sec-cockpit .ckvlz{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 12px}
#sec-cockpit .ckvlk{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#9da7b3}
#sec-cockpit .ckvlz b{font-size:15px;white-space:nowrap}
#sec-cockpit .ckvlw{font-size:12px;color:#c9d1d9;overflow-wrap:anywhere}
#sec-cockpit .ckvlw:empty{display:none}
#sec-cockpit .ckvln{display:inline-block;width:12px;height:2px;border-radius:1px;flex:none}
#sec-cockpit .ckvfeld{display:flex;flex-direction:column;gap:8px;touch-action:pan-y;cursor:crosshair;user-select:none;-webkit-user-select:none;outline:none}
#sec-cockpit .ckvfeld:focus-visible{outline:1px solid #58a6ff;outline-offset:3px;border-radius:4px}
#sec-cockpit .ckvpt{display:flex;align-items:center;gap:6px;font-size:11px;color:#9da7b3;margin-bottom:2px}
#sec-cockpit .ckvfl{position:relative;height:92px}
#sec-cockpit .ckvin{position:absolute;top:0;bottom:0;border-bottom:1px solid #30363d}
#sec-cockpit .ckvin svg{position:absolute;left:0;top:0;width:100%;height:100%;display:block}
#sec-cockpit .ckvy{position:absolute;right:100%;margin-right:6px;transform:translateY(-50%);font-size:10px;line-height:1;color:#9da7b3;font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}
#sec-cockpit .ckvpkt{position:absolute;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;box-shadow:0 0 0 2px #161b22;pointer-events:none}
#sec-cockpit .ckvw{position:absolute;top:1px;width:8px;height:8px;margin-left:-4px;border-radius:50%;background:#c9d1d9;box-shadow:0 0 0 2px #161b22;pointer-events:none}
#sec-cockpit .ckvw.ckvwn{background:#161b22;box-shadow:inset 0 0 0 2px #c9d1d9,0 0 0 2px #161b22}
#sec-cockpit .ckvlt{position:absolute;top:50%;transform:translate(-50%,-50%);font-size:10px;color:#9da7b3;white-space:nowrap;pointer-events:none}
#sec-cockpit .ckvk{position:absolute;top:0;bottom:0;width:1px;margin-left:-0.5px;background:#8b949e;pointer-events:none}
#sec-cockpit .ckvkp{position:absolute;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;box-shadow:0 0 0 2px #161b22;pointer-events:none}
#sec-cockpit .ckvx{position:relative;height:14px;font-size:10px;color:#9da7b3;font-variant-numeric:tabular-nums}
#sec-cockpit .ckvx span{position:absolute;top:0;transform:translateX(-50%);white-space:nowrap}
#sec-cockpit .ckvmk{display:inline-block;width:8px;height:8px;border-radius:50%;background:#c9d1d9}
#sec-cockpit .ckvmk.ckvmkn{background:transparent;box-shadow:inset 0 0 0 2px #c9d1d9}
#sec-cockpit .ckvliste summary{cursor:pointer;font-size:12px;color:#c9d1d9;padding:7px 0}
#sec-cockpit .ckvtab{display:grid;grid-template-columns:24px minmax(0,1fr) 78px 52px 66px;gap:6px;align-items:center;width:100%;font-size:12px;font-variant-numeric:tabular-nums;text-align:left;box-sizing:border-box}
#sec-cockpit .ckvtab .r{text-align:right}
#sec-cockpit .ckvtk{font-size:11px;color:#9da7b3;padding:2px 0}
#sec-cockpit button.ckvzl{min-height:32px;border:0;border-top:1px solid #21262d;background:none;color:#e6edf3;font:inherit;font-size:12px;padding:0;cursor:pointer}
#sec-cockpit .ckvliste .ckleise{margin-top:6px}
#sec-cockpit .ckrein{display:flex;gap:8px}
#sec-cockpit .ckrin{flex:1;min-width:0;min-height:44px;box-sizing:border-box;padding:0 12px;border:1px solid #30363d;border-radius:8px;background:#0d1117;color:#e6edf3;font:inherit;font-size:16px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckrin:focus{outline:1px solid #58a6ff;outline-offset:1px}
#sec-cockpit .ckrb{flex:none;min-height:44px;padding:0 16px;border:1px solid #58a6ff;border-radius:8px;background:#1b3a5c;color:#e6edf3;font:inherit;font-weight:600;cursor:pointer}
#sec-cockpit .ckrzeile{display:flex;flex-direction:column;gap:6px;border-top:1px solid #21262d;padding-top:8px}
#sec-cockpit .ckrkopf{display:flex;align-items:center;justify-content:space-between;gap:8px}
#sec-cockpit .ckrname{display:flex;flex-direction:column;min-width:0}
#sec-cockpit .ckrname b{font-size:15px;font-weight:600;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
#sec-cockpit .ckrx{flex:none;width:40px;height:40px;border:1px solid #30363d;border-radius:8px;background:none;color:#c9d1d9;font:inherit;font-size:18px;line-height:1;cursor:pointer}
#sec-cockpit .ckrzellen{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
#sec-cockpit .ckrz{display:flex;flex-direction:column;gap:3px;min-width:0}
#sec-cockpit .ckrz b{font-size:12px;font-weight:600;font-variant-numeric:tabular-nums;white-space:nowrap}
#sec-cockpit .ckrbk{display:flex;height:6px;background:#30363d;border-radius:3px;overflow:hidden}
#sec-cockpit .ckrbk i{background:#58a6ff;border-radius:3px}
#sec-cockpit .ckrmerk{display:flex;flex-direction:column;gap:6px}
#sec-cockpit .ckrpillen{display:flex;flex-wrap:wrap;gap:6px}
#sec-cockpit .ckrmehr summary{cursor:pointer;font-size:12px;color:#c9d1d9;padding:7px 0}
#sec-cockpit .ckrmehr .ckbeleg{margin-bottom:6px}
#sec-cockpit .cklinks{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:0}
#sec-cockpit .cklinks button{min-height:44px;border:1px solid #30363d;border-radius:8px;background:#161b22;color:#e6edf3;font:inherit;font-weight:600;cursor:pointer}
#sec-cockpit .ckfuss{margin-top:8px}
@media (max-width:420px){ #sec-cockpit .ckschw{gap:10px} #sec-cockpit .ckminiz{font-size:9px} }
@media (max-width:380px){ #sec-cockpit .ckschw{flex-direction:column;align-items:stretch} #sec-cockpit .ckbogen{align-self:center} }`;
 document.head.appendChild(st); }
function ckStart(){ if(!$('sec-cockpit')) return; ckCss(); ckZeichne(); ckLaden(false);
 setInterval(()=>{ if(ckOffen()) ckLaden(false); }, 60000);
 setInterval(()=>{ if(ckOffen()&&CK.d&&!CK.laeuft&&CK.coin!==ckCoin()) ckLaden(true); }, 2000);   // Auswahl der Seite ohne „change“ geändert (Start, gemerkter Coin): nachziehen
 setInterval(()=>{ if(ckOffen()&&CK.d&&!CK.laeuft) ckZeichne(); }, 30000);        // Zeitangaben („in 5 h“) nachführen, ohne neu zu fragen
 document.addEventListener('visibilitychange',()=>{ if(ckOffen()) ckLaden(false); });
 const s=$('coin'); if(s) s.addEventListener('change',()=>{ CK.lampe=null; ckLaden(true); });
 const kopf=$('sec-cockpit').querySelector('h2.sech'); if(kopf) kopf.addEventListener('click',()=>setTimeout(()=>ckLaden(true),80)); }   // beim Aufklappen frisch laden
ckStart();
"""
