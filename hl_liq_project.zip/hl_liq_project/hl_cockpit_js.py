"""
hl_cockpit_js.py -- Skript des Abschnitts „Cockpit“ im Dashboard (U245 Stufe C1, 23.98), ausgeliefert unter /cockpit.js.

Seit 23.100 (U254) dazu die Karte „Unstaking“ (nur ETH; gemessen, blau); seit 23.101 (U255) darin eine Zeile mit dem Urteil der
vorab festgelegten Prüfung „Folgt darauf ein Kursrückgang?“ -- als Text, ohne Farbe.

Eigene Datei wie hl_volatil_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf den
Helfern der Seite auf ($, getJSON, esc) und muss deshalb NACH dem Hauptskript geladen werden.

Das Skript rechnet nichts: Zustände der Lampen, Vermerke und Belege kommen fertig von /cockpit (hl_cockpit.py). Hier nur Zahlen im
deutschen Format, Ortszeit und die Zeichnung. Regeln aus KONZEPT_Cockpit.md 4: jede Lampe trägt ein Wort und eine eigene Form (Ring =
aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert), Farbe nur für Belegtes (Klasse A), Messwerte neutral blau;
kein Pfeil, kein Empfehlungswort, kein Rot/Grün im Sinn von gut/schlecht. Jedes Instrument zeigt Zahl, Stand und Beleg.
"""

COCKPIT_JS = r"""// 23.98 Cockpit (U245 Stufe C1): Spanne, Risiko, Levels, Messwerte, Kosten -- nur Belegtes oder sauber Gemessenes. Daten: /cockpit?coin=..
// (hl_cockpit.py, nur lesend). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist (höchstens einmal je Minute; Server 30 s).
const CK={d:null, coin:null, laeuft:false, lampe:null, fehler:null, geladen:0};
const CK_F={a50:'#58a6ff', a80:'#2f6fb5', a90:'#1b3a5c', kurs:'#e3b341', hinweis:'#e3b341', warnung:'#f0883e', info:'#58a6ff', ring:'#9da7b3',
 spur:'#30363d', grau:'#6e7681', text:'#e6edf3', leise:'#9da7b3'};
function ckZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}).replace('-','−'); }
function ckPx(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return ckZ(x, a>=1000?0:a>=10?2:4); }
function ckPc(x,d,vz){ if(x==null||!isFinite(x)) return '—'; const s=ckZ(x*100,d); return (vz&&x>0?'+':'')+s+' %'; }
function ckZeit(ts){ if(!ts) return '—'; const x=new Date(ts*1000); return x.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})+' '+x.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}); }
function ckTag(ts){ if(!ts) return '—'; const x=new Date(ts*1000); return ['So','Mo','Di','Mi','Do','Fr','Sa'][x.getDay()]+', '+x.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'}); }
function ckDauer(s){ s=Math.max(0,Math.round(s)); if(s<5400) return Math.max(1,Math.round(s/60))+' min'; if(s<172800) return Math.round(s/3600)+' h'; return Math.round(s/86400)+' Tagen'; }
function ckOffen(){ const p=$('sec-cockpit'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function ckCoin(){ const s=$('coin'); return (s&&s.value)||'BTC'; }      // ein Coin ohne Cockpit bekommt vom Server die Absage mit Grund, kein stilles BTC

async function ckLaden(erzwungen){
 if(!$('ckbody')||CK.laeuft) return;
 if(!erzwungen&&!ckOffen()) return;
 const coin=ckCoin();
 if(!erzwungen&&CK.d&&CK.coin===coin&&Date.now()-CK.geladen<25000) return;
 CK.laeuft=true;
 try{ const d=await getJSON('/cockpit?coin='+encodeURIComponent(coin)); CK.d=d; CK.coin=coin; CK.fehler=null; CK.geladen=Date.now(); }
 catch(e){ CK.fehler=String(e&&e.message||e); }
 CK.laeuft=false; ckZeichne();
}
function ckWaehle(c){ const s=$('coin'); if(!s) return;
 if(![...s.options].some(o=>o.value===c)){ CK.fehler='Der Coin '+c+' steht in der Auswahl der Seite nicht zur Verfügung.'; ckZeichne(); return; }
 if(s.value===c) return; s.value=c; s.dispatchEvent(new Event('change')); }
function ckLampeZeigen(k){ CK.lampe=(CK.lampe===k?null:k); ckZeichne(); }
function ckGeheZu(id){ const g=$(id); if(!g) return; if(g.classList.contains('zu')&&typeof grpSchalten==='function') grpSchalten(id.replace('grp-',''));
 g.scrollIntoView({behavior:'smooth', block:'start'}); }

// ---------- Formen der Lampen: Ring = aus, Kreis = Hinweis, Quadrat = Warnung, gestrichelter Ring = kein Wert ----------
function ckForm(z, klasse, gr){ const g=gr||20, r=g/2;
 if(z==='warnung') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2" width="16" height="16" rx="3" fill="${CK_F.warnung}"/></svg>`;
 if(z==='hinweis') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="8" fill="${klasse==='B'?CK_F.info:CK_F.hinweis}"/></svg>`;
 if(z==='grau') return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5" fill="none" stroke="${CK_F.grau}" stroke-width="2" stroke-dasharray="3 3"/></svg>`;
 return `<svg width="${g}" height="${g}" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5" fill="none" stroke="${CK_F.ring}" stroke-width="2"/></svg>`; }
function ckLampenWert(l){ const jetzt=Date.now()/1000;
 if(l.key==='termin'&&l.ts){ if(l.zustand==='aus') return ckTag(l.ts);
  if(jetzt<l.ts) return 'in '+ckDauer(l.ts-jetzt); return 'bis '+new Date((l.ts_ende||l.ts)*1000).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}); }
 return l.wert||'—'; }
function ckLampen(d){ const L=d.lampen||[];
 let h=`<div class="ckk"><div class="ckt">Risiko</div><div class="cklampen">`
  +L.map(l=>`<button type="button" class="cklampe${CK.lampe===l.key?' an':''}" onclick="ckLampeZeigen('${l.key}')" aria-expanded="${CK.lampe===l.key}" title="${esc(l.detail||'')}">`
   +ckForm(l.zustand,l.klasse)+`<span class="ckln">${esc(l.name)}</span><span class="cklw">${esc(l.wort||'')}</span><span class="cklv">${esc(ckLampenWert(l))}</span></button>`).join('')+`</div>`;
 const a=L.find(l=>l.key===CK.lampe);
 if(a) h+=`<div class="ckdetail"><b>${esc(a.name)}: ${esc(a.wort||'')}.</b> ${esc(a.detail||'')}`
  +(a.key==='termin'&&a.ts?` Zeitpunkt: ${esc(ckZeit(a.ts))} (Ortszeit).`:'')
  +(a.ts_ende&&a.key!=='termin'?` Gilt bis ${esc(ckZeit(a.ts_ende))}.`:'')
  +(a.stand?` Stand der Quelle: ${esc(ckZeit(a.stand))}.`:'')+`<div class="ckbeleg">${esc(a.beleg||'')}</div></div>`;
 else h+=`<div class="ckleg"><span>${ckForm('aus','A',12)} aus</span><span>${ckForm('hinweis','A',12)} Hinweis</span><span>${ckForm('warnung','A',12)} Warnung</span>`
  +`<span>${ckForm('hinweis','B',12)} Messwert</span><span>${ckForm('grau','A',12)} kein Wert</span><span class="ckleise">Antippen zeigt den Beleg.</span></div>`;
 return h+`</div>`; }

// ---------- Kopf, Streifen, Kernsatz ----------
function ckKopf(d){ const k=d.kopf||{}, alt=k.kurs_ts?Date.now()/1000-k.kurs_ts:null;
 return `<div class="ckkopf"><div><div class="ckmarke">HyperBit Cockpit</div><div class="ckkurs${k.frisch?'':' ckalt'}">${ckPx(k.kurs)}</div>`
  +`<div class="ckleise">${esc(d.coin||'')} · ${k.kurs_ts?(k.frisch?'Kurs von '+esc(ckZeit(k.kurs_ts)):'Kurs nicht frisch: Stand '+esc(ckZeit(k.kurs_ts))+(alt?' (vor '+ckDauer(alt)+')':'')):'kein Kurs'}</div></div>`
  +`<button type="button" id="ck_betrieb" class="ckpille" onclick="ckGeheZu('grp-betrieb')" title="Zum Bereich Betrieb (System, Backup, Netzwerk, Update, Debug)">`
  +`<span class="ckpunkt"></span><span class="ckptext">Betrieb</span></button></div>`; }
function ckBetrieb(){ const el=$('ck_betrieb'); if(!el) return; const B=window.CK_BETRIEB;
 const t=el.querySelector('.ckptext'), p=el.querySelector('.ckpunkt'); if(!t||!p) return;
 if(!B){ t.textContent='Betrieb: wird geprüft'; p.style.background='transparent'; p.style.border='2px dashed '+CK_F.grau; return; }
 const prob=B.prob||[];
 if(prob.length){ t.textContent='Betrieb: Hinweis ('+prob.join(', ')+')'; p.style.background=CK_F.hinweis; p.style.border='0'; p.style.borderRadius='2px'; }
 else { t.textContent='Betrieb: ohne Hinweis'; p.style.background='transparent'; p.style.border='2px solid '+CK_F.ring; p.style.borderRadius='50%'; } }
function ckStreifen(d){ const S=d.streifen||[]; if(!S.length) return '';
 const m=Math.max(0.05, ...S.map(e=>Math.max(Math.abs(e.lo||0), Math.abs(e.hi||0))));
 return `<div class="ckstreifen" role="group" aria-label="Coins: 80-Prozent-Spanne der nächsten 7 Tage und Lampen">`+S.map(e=>{
  const lo=e.lo!=null?Math.abs(e.lo)/m*50:0, hi=e.hi!=null?Math.abs(e.hi)/m*50:0, an=(e.lampen||[]).filter(z=>z==='hinweis'||z==='warnung').length;
  const warn=(e.lampen||[]).includes('warnung');
  return `<button type="button" class="ckcoin${e.coin===d.coin?' an':''}" onclick="ckWaehle('${e.coin}')" aria-pressed="${e.coin===d.coin}" `
   +`title="${esc(e.coin)}: in 7 Tagen mit 80 % zwischen ${esc(ckPc(e.lo,0,true))} und ${esc(ckPc(e.hi,0,true))}; ${an} von 5 Lampen an">`
   +`<b>${esc(e.coin)}</b><span class="ckmini" aria-hidden="true"><i style="left:${(50-lo).toFixed(1)}%;width:${(lo+hi).toFixed(1)}%"></i><u></u></span>`
   +`<span class="ckminiz">${e.lo!=null?esc(ckZ(e.lo*100,0))+' / +'+esc(ckZ(e.hi*100,0))+' %':'—'}</span>`
   +`<span class="ckpunkte" aria-hidden="true">${(e.lampen||[]).map(z=>`<s class="${z}"></s>`).join('')}</span>`
   +`<span class="ckleise ckan">${an?an+(warn?' · Warnung':' an'):'keine an'}</span></button>`; }).join('')+`</div>`; }
function ckSatz(d){ const s=d.satz||{};
 return `<div class="ckk"><div class="cksatz">${esc(s.text||'')}</div><div class="ckleise">${esc(s.zusatz||'')}</div>`
  +(s.ausnahme?`<div class="ckausnahme">${esc(s.ausnahme)}</div>`:'')+(s.unstaking?`<div class="ckunst">${esc(s.unstaking)}</div>`:'')+`</div>`; }

// ---------- Schwankung: Bogen mit der erwarteten Schwankung der nächsten 7 Tage ----------
function ckBogen(wert, max){ const L=Math.PI*60, a=wert!=null&&max?Math.max(0,Math.min(1,wert/max)):0;
 return `<svg role="img" aria-label="Schwankung ${ckZ(wert,1)} Prozent pro Jahr auf einer Skala bis ${ckZ(max,0)}" width="140" height="78" viewBox="0 0 140 78">`
  +`<path d="M 10 70 A 60 60 0 0 1 130 70" fill="none" stroke="${CK_F.spur}" stroke-width="12" stroke-linecap="round"></path>`
  +(wert!=null?`<path d="M 10 70 A 60 60 0 0 1 130 70" fill="none" stroke="${CK_F.a50}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${(a*L).toFixed(1)} ${L.toFixed(1)}"></path>`:'')+`</svg>`; }
function ckSchwankung(d){ const s=d.schwankung||{}, erw=s.erwartet!=null;
 const zeile=(n,v)=>`<div class="ckzeile"><span>${n}</span><b>${v}</b></div>`;
 return `<div class="ckk${s.frisch===false&&s.anzeige!=null?' ckgrau':''}"><div class="ckt">Schwankung</div><div class="ckschw"><div class="ckbogen">`+ckBogen(s.anzeige, s.skala_max)
  +`<div class="ckgross">${s.anzeige!=null?ckZ(s.anzeige,1)+' %':'—'}</div><div class="ckleise">${erw?'erwartet, 7 Tage, pro Jahr':'realisiert, 7 Tage, pro Jahr'}</div></div>`
  +`<div class="ckliste">`+(erw?zeile('Realisiert 7 Tage', s.real7!=null?ckZ(s.real7,1)+' %':'—'):'')
  +zeile('Realisiert 30 Tage', s.real30!=null?ckZ(s.real30,1)+' %':'—')+(s.dvol!=null?zeile('DVOL', ckZ(s.dvol,1)):'')
  +zeile('In 4 h typisch', s.er4!=null?'± '+ckZ(s.er4*100,2)+' %':'—')+zeile('Perzentil 365 Tage', s.pz_n!=null?s.pz_n+'.':'—')+`</div></div>`
  +(s.fehlt&&s.fehlt.length?`<div class="ckfehlt">${s.fehlt.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(s.beleg||'')}${s.modell?' Modell: '+esc(s.modell)+'.':''}${s.stand_text?' '+esc(s.stand_text):''}</div></div>`; }

// ---------- Spanne: Balken 50 / 80 / 90 % für 7, 14 und 28 Tage mit Kursmarke ----------
function ckSpanne(d){ const S=d.spanne||{}, H=S.h||{}, sk=S.skala;
 if(!sk||!Object.keys(H).length) return `<div class="ckk"><div class="ckt">Spanne</div><div class="ckfehlt">${(S.fehlt||['Noch keine Spanne.']).map(esc).join(' ')}</div><div class="ckbeleg">${esc(S.beleg||'')}</div></div>`;
 const pos=x=>Math.max(0,Math.min(100,(x-sk[0])/(sk[1]-sk[0])*100));
 const kurs=S.kurs!=null?S.kurs:S.p0;
 const balken=(h,hoehe)=>{ const e=H[h]; if(!e) return ''; const q=e.q, p=q.map(pos);
  return `<div class="ckbz"><div class="ckbalken" style="height:${hoehe}px" role="img" aria-label="${h} Tage: 90 Prozent ${ckPx(q[0])} bis ${ckPx(q[6])}, 80 Prozent ${ckPx(q[1])} bis ${ckPx(q[5])}, 50 Prozent ${ckPx(q[2])} bis ${ckPx(q[4])}">`
   +`<i style="left:${p[0].toFixed(2)}%;width:${(p[6]-p[0]).toFixed(2)}%;background:${CK_F.a90}"></i><i style="left:${p[1].toFixed(2)}%;width:${(p[5]-p[1]).toFixed(2)}%;background:${CK_F.a80}"></i>`
   +`<i style="left:${p[2].toFixed(2)}%;width:${(p[4]-p[2]).toFixed(2)}%;background:${CK_F.a50}"></i>`
   +(kurs!=null?`<u style="left:${pos(kurs).toFixed(2)}%"></u>`:'')+`</div>`
   +`<div class="ckbtext"><b>${h} Tage · ${ckPx(q[1])} – ${ckPx(q[5])}</b><span class="ckleise">${esc(e.vermerk||'')}</span></div></div>`; };
 return `<div class="ckk${S.frisch?'':' ckgrau'}"><div class="ckt">Spanne <span class="ckleise cktn">80 % je Zeile</span></div><div class="ckspanne">`
  +balken('7',16)+balken('14',12)+balken('28',8)+`</div>`
  +`<div class="ckleg"><span><i class="sw" style="background:${CK_F.a50}"></i>50 %</span><span><i class="sw" style="background:${CK_F.a80}"></i>80 %</span>`
  +`<span><i class="sw" style="background:${CK_F.a90};border:1px solid ${CK_F.spur}"></i>90 %</span><span><i class="sw" style="background:${CK_F.kurs};width:2px"></i>${S.kurs!=null?'Kurs jetzt':'Kurs am Anker'}</span></div>`
  +(S.fehlt&&S.fehlt.length?`<div class="ckfehlt">${S.fehlt.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(S.beleg||'')} Stand der Rechnung: ${esc(ckZeit(S.anker))}, Kurs damals ${ckPx(S.p0)}.</div></div>`; }

// ---------- Levels: die nächsten Niveaus über und unter dem Kurs ----------
function ckLevels(d){ const L=d.levels||{};
 const zeile=n=>`<div class="cklevel"><div class="ckln2"><b>${esc(n.name)} ${ckPx(n.px)}</b><span class="ckleise">${esc(ckPc(n.abstand,1,true))}${n.momentaufnahme?' · Momentaufnahme':''}</span></div>`
  +`<div class="ckpb" aria-hidden="true"><span><i style="width:${(n.p7*100).toFixed(0)}%;background:${CK_F.a50}"></i></span><span><i style="width:${(n.p14*100).toFixed(0)}%;background:${CK_F.a80}"></i></span></div>`
  +`<span class="ckpz">${ckZ(n.p7*100,0)} · ${ckZ(n.p14*100,0)} %</span></div>`;
 const leer=!(L.oben||[]).length&&!(L.unten||[]).length;
 return `<div class="ckk${L.frisch===false&&!leer?' ckgrau':''}"><div class="ckt">Levels <span class="ckleise cktn">erreicht in 1 Woche · 2 Wochen</span></div>`
  +(leer?`<div class="ckfehlt">${(L.fehlt||['Keine Niveaus.']).map(esc).join(' ')}</div>`:
   (L.oben||[]).map(zeile).join('')+`<div class="ckkurslinie"><span></span><b>Kurs ${ckPx(L.kurs)}</b><span></span></div>`+(L.unten||[]).map(zeile).join(''))
  +(!leer&&L.fehlt&&L.fehlt.length?`<div class="ckfehlt">${L.fehlt.map(esc).join(' ')}</div>`:'')
  +(L.durchlaufen?`<div class="ckfehlt">${L.durchlaufen} Niveau${L.durchlaufen>1?'s':''} seit der Rechnung durchlaufen, nicht mehr gezeigt.</div>`:'')
  +`<div class="ckbeleg">${esc(L.beleg||'')}${L.anker?' Wahrscheinlichkeiten ab der Rechnung von '+esc(ckZeit(L.anker))+'.':''}</div></div>`; }

// ---------- Markt-Messwerte (Klasse B, neutral) und Kosten ----------
function ckMesswerte(d){ const M=d.messwerte||[];
 return `<div class="ckk"><div class="ckt">Markt-Messwerte</div>`+M.map(m=>{
   const pz=m.pz!=null?Math.max(0,Math.min(1,m.pz)):null;
   const wert=m.key==='oi'?(m.wert!=null?ckZ(m.wert,0)+' '+esc(d.coin||''):'—'):(m.text||'—');
   const stand=m.wert==null?'':(m.stand?(m.art==='live'?'live, ':'Stand ')+ckZeit(m.stand):(m.stand_tag?'Tagesstand '+m.stand_tag:''));
   return `<div class="ckmess"><div class="ckmz"><span>${esc(m.name)}</span><b>${esc(wert)}${m.marke!=null?' · Schwelle '+ckZ(m.marke,0):''}</b></div>`
    +(pz!=null&&m.pz_n!=null?`<div class="ckmz2"><span class="ckspur" role="img" aria-label="${m.pz_n}. Perzentil der letzten 90 Tagesstände"><i style="left:calc(${(pz*100).toFixed(1)}% - 5px)"></i></span>`
      +`<span class="ckleise">${m.pz_n}. Perzentil</span></div>`
     :`<div class="ckleise">${m.wert!=null?(m.key==='funding'?'z-Wert gegen 30 Tage, ohne Perzentil':'ohne Perzentil'):'kein Wert'}</div>`)
    +(stand?`<div class="ckleise ckstand">${esc(stand)}</div>`:'')+`</div>`; }).join('')
  +`<div class="ckbeleg">${esc(d.messwerte_beleg||'')} Taker-Varianz und Liquidationsdichte folgen mit dem nächsten Schritt.</div></div>`; }
// ---------- 23.100 (U254) Unstaking: angemeldete Abzüge aus dem Ethereum-Staking mit ihrem festen Zeitpunkt -- nur bei ETH. Gemessen: blau,
// keine Warnfarbe; große Tage unterscheiden sich in der Form (fett, höherer Balken, Punkt). 23.101 (U255): unter dem Termin steht das
// gespeicherte Urteil der Prüfung der Kursfolge (U.pruefung.kurz) -- Text, keine Farbe, auch bei „belegt“.
function ckUnstaking(d){ const U=d.unstaking; if(!U) return '';
 const kopf=`<div class="ckt">Unstaking <span class="ckleise cktn">Ethereum-Staking · gemessen${U.geschaetzt?', geschätzt':''}</span></div>`;
 if(!U.ok) return `<div class="ckk ckgrau">${kopf}<div class="ckfehlt">${(U.fehlt&&U.fehlt.length?U.fehlt:['Noch kein Stand.']).map(esc).join(' ')}</div><div class="ckbeleg">${esc(U.beleg||'')}</div></div>`;
 const T=U.tage||[];
 const zeile=t=>`<div class="ckutag${t.gross?' gross':''}"><span>${esc(t.tag)}</span><span class="ckubalken" aria-hidden="true"><i style="width:${Math.max(t.eth>0?2:0,Math.round((t.anteil||0)*100))}%"></i></span><span class="r">${ckZ(t.eth,0)}${t.gross?' ●':''}</span></div>`;
 return `<div class="ckk">${kopf}`
  +`<div class="ckuz"><span class="ckuw">${ckZ(U.summe_eth,0)} ETH</span><span class="ckleise">angemeldet, noch nicht frei${U.usd_text?' · ≈ '+esc(U.usd_text):''}</span></div>`
  +`<div>${U.ende_ts?'Alles Angemeldete ist frei bis <b>'+esc(ckZeit(U.ende_ts))+'</b> (Ortszeit).':'Nichts Angemeldetes steht aus.'}</div>`
  +`<div class="ckusatz">${esc(U.satz||'')}</div>`
  +(U.pruefung&&U.pruefung.kurz?`<div class="ckupruef">${esc(U.pruefung.kurz)}</div>`:'')
  +(T.length?`<div class="ckleise ckstand">Kalender „frei ab“ je UTC-Tag, in ETH · ● = Tag ab ${ckZ(U.schwelle,0)} ETH</div>`+T.map(zeile).join(''):'')
  +(U.tage_mehr?`<div class="ckleise ckstand">später: ${ckZ(U.tage_mehr_eth,0)} ETH an ${U.tage_mehr} weiteren Tagen</div>`:'')
  +(U.abzieher||[]).map((a,i)=>`<div class="ckuab">${i?'Weiterer':'Größter'} Abzieher ${esc(a.kurz)}: <b>${ckZ(a.eth,0)} ETH</b>${a.anteil!=null?' ('+ckZ(a.anteil*100,0)+' % der Vollabzüge)':''}, frei ${esc(a.von)} bis ${esc(a.bis)}</div>`).join('')
  +[U.gegenseite,U.nicht_gezaehlt].filter(Boolean).map(x=>`<div class="ckleise">${esc(x)}</div>`).join('')
  +(U.hinweise&&U.hinweise.length?`<div class="ckfehlt">${U.hinweise.map(esc).join(' ')}</div>`:'')
  +`<div class="ckbeleg">${esc(U.auszahlung||'')} ${esc(U.beleg||'')} Stand: ${esc(ckZeit(U.stand))}, Quelle: ${U.quelle==='knoten'?'Beacon-Knoten':'Tagesdatei von validatorqueue.com'}.</div></div>`; }

function ckKosten(d){ const K=d.kosten||{}, Z=K.zeilen||[];
 return `<div class="ckk"><div class="ckt">Kosten: nötige Trefferquote</div>`
  +(Z.length?`<div class="ckkosten"><span class="ckleise">Horizont</span><span class="ckleise r">Taker</span><span class="ckleise r">Maker</span>`
   +Z.map(z=>`<span>${z.h} Stunden</span><b class="r">${ckZ(z.taker*100,1)} %</b><b class="r">${ckZ(z.maker*100,1)} %</b>`).join('')+`</div>`
   :`<div class="ckfehlt">${(K.fehlt||['Noch keine Werte.']).map(esc).join(' ')}</div>`)
  +`<div class="ckbeleg">${esc(K.beleg||'')}${K.taker!=null?' Gebühren '+ckZ(K.taker*100,3)+' % und '+ckZ(K.maker*100,3)+' % je Seite':''}`
  +`${K.halbspread_bps!=null?', halber Spread '+ckZ(K.halbspread_bps,2)+' bps':''}${K.taker!=null?'.':''}`
  +`${Z.length&&K.stand?' Stand '+esc(ckZeit(K.stand))+(K.tage?', mittlere Bewegung der letzten '+K.tage+' Tage':'')+'.':''}</div></div>`; }

function ckZeichne(){ const el=$('ckbody'); if(!el) return; const d=CK.d;
 if(!d){ el.innerHTML=`<div class="ckk ckleise">${CK.fehler?'Cockpit nicht erreichbar: '+esc(CK.fehler):'lädt …'}</div>`; return; }
 if(d.ok===false){ el.innerHTML=`<div class="ckk"><div class="ckfehlt">${(d.fehlt||['Cockpit: keine Daten']).map(esc).join(' ')}</div></div>`; return; }
 const allg=[...new Set(d.fehlt||[])];
 el.innerHTML=ckKopf(d)+ckStreifen(d)+(CK.fehler?`<div class="ckk ckfehlt">${esc(CK.fehler)}</div>`:'')+`<div class="ckraster">`+ckSatz(d)+ckLampen(d)+ckSchwankung(d)+ckSpanne(d)+ckLevels(d)+ckMesswerte(d)+ckUnstaking(d)+ckKosten(d)+`</div>`
  +(allg.length?`<div class="ckfehlt">${allg.map(esc).join(' · ')}</div>`:'')
  +`<div class="cklinks"><button type="button" onclick="ckGeheZu('grp-werkstatt')">Werkstatt · nicht belegt</button><button type="button" onclick="ckGeheZu('grp-betrieb')">Betrieb</button></div>`
  +`<div class="ckleise ckfuss">Nur Belegtes oder Gemessenes. Der Kurs-Rechner folgt mit dem nächsten Schritt. Stand ${esc(ckZeit(d.jetzt))} · ${d.rechenzeit_ms!=null?d.rechenzeit_ms+' ms':''}</div>`;
 ckBetrieb(); }

function ckCss(){ if($('ck_css')) return; const st=document.createElement('style'); st.id='ck_css'; st.textContent=`
#sec-cockpit .ckkopf{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin:6px 0 10px}
#sec-cockpit .ckmarke{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#9da7b3}
#sec-cockpit .ckkurs{font-size:30px;font-weight:700;line-height:1.1;font-variant-numeric:tabular-nums;color:#e6edf3}
#sec-cockpit .ckkurs.ckalt{color:#9da7b3}
#sec-cockpit .ckleise{font-size:11px;color:#9da7b3;line-height:1.4}
#sec-cockpit .ckpille{display:flex;align-items:center;gap:8px;min-height:44px;padding:0 14px;border:1px solid #30363d;border-radius:22px;background:#161b22;color:#e6edf3;font:inherit;font-size:12px;font-weight:600;cursor:pointer;max-width:58%;text-align:left}
#sec-cockpit .ckpunkt{flex:none;width:10px;height:10px;box-sizing:border-box;border-radius:50%}
#sec-cockpit .ckstreifen{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:4px;margin:0 0 12px}
#sec-cockpit .ckcoin{display:flex;flex-direction:column;align-items:center;gap:3px;min-height:44px;padding:6px 2px;border:1px solid #30363d;border-radius:8px;background:#161b22;color:#e6edf3;font:inherit;font-size:12px;cursor:pointer;min-width:0}
#sec-cockpit .ckcoin.an{border-color:#58a6ff;background:#1b3a5c}
#sec-cockpit .ckcoin b{font-weight:700}
#sec-cockpit .ckmini{position:relative;width:86%;height:6px;background:#30363d;border-radius:3px}
#sec-cockpit .ckmini i{position:absolute;top:0;height:6px;background:#58a6ff;border-radius:3px}
#sec-cockpit .ckmini u{position:absolute;left:50%;top:-2px;width:2px;height:10px;background:#e3b341;text-decoration:none}
#sec-cockpit .ckminiz{font-size:10px;color:#c9d1d9;font-variant-numeric:tabular-nums;white-space:nowrap}
#sec-cockpit .ckpunkte{display:flex;gap:3px;height:8px;align-items:center}
#sec-cockpit .ckpunkte s{width:7px;height:7px;box-sizing:border-box;border-radius:50%;border:1.5px solid #9da7b3;text-decoration:none}
#sec-cockpit .ckpunkte s.hinweis{background:#e3b341;border-color:#e3b341}
#sec-cockpit .ckpunkte s.warnung{background:#f0883e;border-color:#f0883e;border-radius:1px}
#sec-cockpit .ckpunkte s.grau{border-style:dashed;border-color:#6e7681}
#sec-cockpit .ckan{font-size:10px}
#sec-cockpit .ckraster{column-width:340px;column-gap:12px}
#sec-cockpit .ckk{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:10px;min-width:0;color:#e6edf3;font-size:13px;line-height:1.4;margin:0 0 12px;break-inside:avoid}
#sec-cockpit .ckk.ckgrau{opacity:.62}
#sec-cockpit .ckt{font-size:12px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#9da7b3;display:flex;justify-content:space-between;align-items:baseline;gap:8px}
#sec-cockpit .cktn{text-transform:none;letter-spacing:0;font-weight:400}
#sec-cockpit .cksatz{font-size:15px;font-weight:600;line-height:1.35}
#sec-cockpit .ckausnahme{font-size:12px;border:1px solid #f0883e;border-radius:8px;padding:8px 10px}
#sec-cockpit .ckunst{font-size:12px;border:1px solid #30363d;border-left:3px solid #58a6ff;border-radius:8px;padding:8px 10px}
#sec-cockpit .cklampen{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px}
#sec-cockpit .cklampe{display:flex;flex-direction:column;align-items:center;gap:3px;text-align:center;min-height:44px;padding:6px 1px;border:1px solid transparent;border-radius:8px;background:none;color:#e6edf3;font:inherit;cursor:pointer;min-width:0}
#sec-cockpit .cklampe.an{border-color:#30363d;background:#0d1117}
#sec-cockpit .ckln{font-size:clamp(9px,2.7vw,11px);font-weight:600;white-space:nowrap}
#sec-cockpit .cklw{font-size:11px;color:#e6edf3}
#sec-cockpit .cklv{font-size:10px;color:#9da7b3;overflow-wrap:anywhere}
#sec-cockpit .ckdetail{font-size:12px;border-top:1px solid #30363d;padding-top:8px}
#sec-cockpit .ckbeleg{font-size:11px;color:#9da7b3;line-height:1.45}
#sec-cockpit .ckdetail .ckbeleg{margin-top:6px}
#sec-cockpit .ckfehlt{font-size:11px;color:#c9d1d9;border-left:2px solid #30363d;padding-left:8px}
#sec-cockpit .ckleg{display:flex;flex-wrap:wrap;align-items:center;gap:4px 12px;font-size:11px;color:#9da7b3}
#sec-cockpit .ckleg span{display:inline-flex;align-items:center;gap:5px}
#sec-cockpit .ckleg .sw{display:inline-block;width:12px;height:8px}
#sec-cockpit .ckschw{display:flex;align-items:center;gap:16px}
#sec-cockpit .ckbogen{display:flex;flex-direction:column;align-items:center;gap:2px;flex:none}
#sec-cockpit .ckgross{font-size:22px;font-weight:700;line-height:1.1;font-variant-numeric:tabular-nums}
#sec-cockpit .ckliste{flex:1;display:flex;flex-direction:column;gap:6px;font-variant-numeric:tabular-nums;min-width:0}
#sec-cockpit .ckzeile{display:flex;justify-content:space-between;gap:8px}
#sec-cockpit .ckzeile span{color:#9da7b3}
#sec-cockpit .ckzeile b{white-space:nowrap;flex:none}
#sec-cockpit .ckspanne{display:flex;flex-direction:column;gap:12px;padding-top:4px}
#sec-cockpit .ckbz{display:flex;flex-direction:column;gap:4px}
#sec-cockpit .ckbalken{position:relative;border-radius:4px}
#sec-cockpit .ckbalken i{position:absolute;top:0;bottom:0;border-radius:4px}
#sec-cockpit .ckbtext{display:flex;justify-content:space-between;gap:8px;font-size:12px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckbalken u{position:absolute;top:-4px;bottom:-4px;width:2px;margin-left:-1px;background:#e3b341;text-decoration:none}
#sec-cockpit .cklevel{display:flex;align-items:center;gap:10px;min-height:40px}
#sec-cockpit .ckln2{flex:1;display:flex;flex-direction:column;min-width:0}
#sec-cockpit .ckln2 b{font-weight:600;overflow-wrap:anywhere}
#sec-cockpit .ckpb{width:96px;flex:none;display:flex;flex-direction:column;gap:3px}
#sec-cockpit .ckpb span{display:flex;height:6px;background:#30363d;border-radius:3px}
#sec-cockpit .ckpb i{border-radius:3px}
#sec-cockpit .ckpz{width:62px;flex:none;text-align:right;font-weight:600;font-variant-numeric:tabular-nums}
#sec-cockpit .ckkurslinie{display:flex;align-items:center;gap:8px;min-height:26px;font-size:12px;color:#e3b341}
#sec-cockpit .ckkurslinie span{flex:1;height:1px;background:#e3b341}
#sec-cockpit .ckmess{display:flex;flex-direction:column;gap:5px;padding:2px 0}
#sec-cockpit .ckmz{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
#sec-cockpit .ckmz b{font-weight:600;font-variant-numeric:tabular-nums;text-align:right}
#sec-cockpit .ckmz2{display:flex;align-items:center;gap:10px}
#sec-cockpit .ckspur{position:relative;flex:1;height:6px;background:#30363d;border-radius:3px;min-width:40px}
#sec-cockpit .ckspur i{position:absolute;top:-2px;width:10px;height:10px;border-radius:50%;background:#58a6ff;box-shadow:0 0 0 2px #161b22}
#sec-cockpit .ckkosten{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px 10px;font-variant-numeric:tabular-nums}
#sec-cockpit .ckkosten .r{text-align:right}
#sec-cockpit .ckuz{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}
#sec-cockpit .ckuw{font-size:22px;font-weight:700;font-variant-numeric:tabular-nums}
#sec-cockpit .ckusatz{font-weight:600}
#sec-cockpit .ckupruef{font-size:12px;color:#c9d1d9;overflow-wrap:anywhere}
#sec-cockpit .ckutag{display:grid;grid-template-columns:72px minmax(0,1fr) 88px;gap:8px;align-items:center;font-size:12px;font-variant-numeric:tabular-nums;min-height:20px}
#sec-cockpit .ckutag .r{text-align:right;white-space:nowrap}
#sec-cockpit .ckutag.gross{font-weight:700}
#sec-cockpit .ckubalken{height:8px;background:#30363d;border-radius:4px;overflow:hidden}
#sec-cockpit .ckutag.gross .ckubalken{height:12px}
#sec-cockpit .ckubalken i{display:block;height:100%;background:#58a6ff;border-radius:4px}
#sec-cockpit .ckuab{font-size:12px;overflow-wrap:anywhere}
#sec-cockpit .cklinks{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:0}
#sec-cockpit .cklinks button{min-height:44px;border:1px solid #30363d;border-radius:8px;background:#161b22;color:#e6edf3;font:inherit;font-weight:600;cursor:pointer}
#sec-cockpit .ckfuss{margin-top:8px}
@media (max-width:420px){ #sec-cockpit .ckschw{gap:10px} #sec-cockpit .ckminiz{font-size:9px} }
@media (max-width:380px){ #sec-cockpit .ckschw{flex-direction:column;align-items:stretch} #sec-cockpit .ckbogen{align-self:center} }`;
 document.head.appendChild(st); }
function ckStart(){ if(!$('sec-cockpit')) return; ckCss(); ckZeichne(); ckLaden(false);
 setInterval(()=>{ if(ckOffen()) ckLaden(false); }, 60000);
 setInterval(()=>{ if(ckOffen()&&CK.d&&!CK.laeuft&&CK.coin!==ckCoin()) ckLaden(true); }, 2000);   // Auswahl der Seite ohne „change“ geändert (Start, gemerkter Coin): nachziehen
 setInterval(()=>{ if(ckOffen()&&CK.d&&!CK.laeuft) ckZeichne(); }, 30000);        // Zeitangaben („in 5 h“) nachführen, ohne neu zu fragen
 document.addEventListener('visibilitychange',()=>{ if(ckOffen()) ckLaden(false); });
 const s=$('coin'); if(s) s.addEventListener('change',()=>{ CK.lampe=null; ckLaden(true); });
 const kopf=$('sec-cockpit').querySelector('h2.sech'); if(kopf) kopf.addEventListener('click',()=>setTimeout(()=>ckLaden(true),80)); }   // beim Aufklappen frisch laden
ckStart();
"""
