# KONZEPT Ausblick (U146) — vier Wochen voraus: Spannen, Ziellevels mit Wahrscheinlichkeit, geprüfte Gewichte

Stand 11.10.2026, 17:00 Uhr; **ergänzt 11.10. abends (Abschnitt 13: Takt alle 30 Minuten, Aktienmarkt, gemeinsame Szenarien,
Studie U147)**. **Vorab festgelegt**, bevor irgendein Teil auf echten Daten gerechnet wurde (Opus 5.5).
Bau mit 23.66, zusammen mit U145 (Backup-Sperre) und den Chartbild-Nacharbeiten (`KONZEPT_Chartbild.md` 9.2) — Entscheidung des
Nutzers vom 11.10. gegen 16:50: „Konzept heute, alles in 23.66“. **Status: gebaut mit 23.66 (11.10. spät abends); was beim Bau
entstand, steht in 12.1 -- Nullverfahren kalibriert (Verschiebung), Nachweisgrenze gemessen, ein eigener Fehler vor jedem echten
Lauf behoben. Urteile S1–S4 nach dem ersten Rückblick auf dem Pi (12.2).**
Nachträge: 13.15 (13.10.), 13.16 (17.10.), 13.17 (18.10.), 13.18 (19.10.: Ausnahmelage durch den S&P-Perp, U179); **13.17 und 13.18
gebaut mit 23.69 (19.10. abends), Stand nach dem Bau in 13.19**. Ergebnis der Zählung der Regel (c) und Entscheidung (Schwelle je Fensterart) in 13.20 (21.10.).

**Anlass** — Wunsch des Nutzers vom 11.10. 16:42 (Tippfehler berichtigt): „Ich möchte ein Extrapolationschart hinzufügen mit einer
Perspektive von 4 Wochen, welches alle Daten miteinander in Korrelation bringt, extrapoliert, erneut korreliert, die Gewichtungen
prüft und eine 4-Wochen-Prognose auf Basis der aktuellen Daten erzeugt. Wichtig ist, wirklich alle signifikanten Daten einfließen zu
lassen. Und die möglichen nächsten 1-Wochen-, 2-Wochen- und 4-Wochen-Ziellevels im Chart kennzeichnet, mit Preis und
Wahrscheinlichkeit in %.“ Vorab dem Nutzer gesagt (16:45): Die Spannweite lässt sich gut vorhersagen, die Richtung kaum; über
jedes Gewicht entscheidet ein Test auf ungesehenen Daten; Hyperliquid-Daten sind für 4-Wochen-Gewichte noch zu jung.

---

## 0. Kurzfassung

- **Was:** je Coin (BTC, ETH, HYPE, ZEC, XMR, PAXG) eine Verteilung für den Kurs in 7, 14 und 28 Tagen. Im Chart erscheint sie
  als Fächer mit Median und den Spannen 50 %, 80 % und 90 %. An jedem wichtigen Niveau steht die Wahrscheinlichkeit, dass der
  Kurs es in 1, 2 und 4 Wochen erreicht; dazu, ob er am Ende darüber oder darunter schließt.
- **Drei Teile, fest:**
  1. *Breite* — das HAR-Modell der Regime-Vorprüfung (P0.2), je Horizont geschätzt.
  2. *Form* — die echten vergangenen 7-, 14- und 28-Tage-Pfade derselben Coins, je auf die damalige Schwankungsprognose
     normiert, auf die heutige zurückskaliert und ohne ihren mittleren Trend. Daraus ergeben sich Spannen und
     Erreich-Wahrscheinlichkeiten genau, ohne Zufallsziehung.
  3. *Richtung* — 31 Kandidaten aus Kurs, Binance-Derivaten und Makro/On-Chain. Ihre Gewichte werden rollierend neu geschätzt
     (Ridge, gepoolt über die Krypto-Coins) und außerhalb der Stichprobe geprüft. Nur wenn ein vorab festgelegtes Tor besteht,
     verschiebt die Richtung den Fächer.
- **„Alle signifikanten Daten“:** Jeder Kandidat geht ein. Jedes Gewicht wird gegen Zufall geprüft (zirkulär verschobene Reihen,
  Holm, beide Hälften). Was sich nicht bewährt, schrumpft auf ≈ 0 und steht mit Testergebnis, Spur und Status in der Tabelle
  „Gewichte“. Wale, Orders und Cluster von Hyperliquid gibt es erst seit wenigen Wochen: Sie gehen als **Niveaus** ein, nicht als
  Gewichte.
- **Prüfung vorab:**
  - Rückblick außerhalb der Stichprobe ab 01.01.2022.
  - Maße: CRPS, PIT, Deckung, Zuverlässigkeit der Wahrscheinlichkeiten.
  - Vergleich: Zufallsweg gleicher Schwankung.
  - Selbsttest mit Null-Universen, Positivkontrolle und Mutationen.
- **Erwartung vorab:**
  - Breite und Erreich-Wahrscheinlichkeiten halten.
  - Die Richtung besteht das Tor sehr wahrscheinlich nicht. Dann ist der Fächer driftfrei, und die Anzeige sagt das.
- **Wirkt auf nichts** (Zusage bis 25.10.): Eigener Abschnitt „Ausblick 4 Wochen“, eigene Datei `ausblick.db`, nur lesend aus
  den übrigen Datenbanken.
- **Ergänzung 11.10. abends (13):**
  - **Takt und Anker:** Neuberechnung alle 30 Minuten bei offenem Dashboard, stündlich im Hintergrund und sofort bei einem
    Schock; rollierende 24-h-Tage, die Gewichte weiter alle 28 Tage.
  - **Breite:** HAR-X mit DVOL, S&P-Schwankung, Finanzstress und VIX als einzeln geprüfte Zusätze.
  - **Gemeinsame Szenarien:** S&P-500-Pfade als zweite Koordinate derselben Bibliotheksfenster. Daraus bedingte Szenarien („wenn
    der S&P 500 in 4 Wochen 10 % tiefer steht …“) mit Episoden-Zählung und Kopula-Rückfall, dazu ein Stressfächer.
  - **Richtung:** vier Aktien-Kandidaten (Nasdaq-Momentum, VIX-Kurve, Kreditspread), also 35 statt 31.
  - **Beschreibend:** ein Reiter „Aktienmarkt“.
  - **Studien:** U147 „Fällt BTC, wenn der S&P 500 fällt?“; dazu eine Kurzstudie zu ETF-Flüssen und ETF-Leerverkäufen.

## 1. Auftrag und Abgrenzung

| Wunsch (Wortlaut) | Umsetzung |
|---|---|
| „alle Daten miteinander in Korrelation bringt“ | Alle Kandidaten gemeinsam in einem Modell (Ridge, gepoolt), dazu ein beschreibender Reiter „Korrelationen“: Daten untereinander, Daten gegen die Rendite der folgenden 7/14/28 Tage mit Nullband, Gleichlauf der Coins |
| „extrapoliert“ | Fächer aus echten vergangenen Pfaden, auf die heutige Schwankungsprognose skaliert (4.3, 4.7) |
| „erneut korreliert, die Gewichtungen prüft“ | Neuschätzung alle 28 Tage (Walk-forward); je Kandidat Gewicht, Spur über die Neuschätzungen, Beitrag außerhalb der Stichprobe, Test gegen Zufall (4.6) |
| „4-Wochen-Prognose auf Basis der aktuellen Daten“ | Täglich nach dem Tagesschluss aus dem Stand dieses Tages (4.1) |
| „wirklich alle signifikanten Daten“ | 31 Kandidaten mit langer Historie; „signifikant“ entscheidet der Test, nicht die Auswahl vorher (4.4–4.6) |
| „1-, 2-, 4-Wochen-Ziellevels mit Preis und Wahrscheinlichkeit in %“ | Spannen je Horizont (Preis und %), Niveaus mit Erreich- und Schluss-Wahrscheinlichkeit (4.7) |

**Nicht Teil von U146:**
- kein Handel, keine Empfehlung, kein Labor-Coin;
- keine Wirkung auf Konfluenz, Fusion, v1/v2/v3, Kaskaden, Treiber oder die 4-h-Prognose;
- keine Änderung am Chartbild außer einem Verweis auf den Abschnitt.

**Verwandte Punkte:**
- U116 (Strukturgleichung als Verteilung): Der Teil „Breite + Form“ ist deren Fassung für 7–28 Tage. Der Stunden-Teil von U116
  und eine Rolle als Experte der Fusion bleiben nach dem 25.10. eigene Schritte.
- U138 R2/R8b: dasselbe HAR; R8b endet bei 7 Tagen.
- U117 Power Law: geht als Kandidat M2 ein.
- U141/U142/U130: liefern Kandidaten und Vorwissen.

## 2. Vorwissen (warum so und nicht anders)

**Breite ist vorhersagbar.**
- Die Bewegungsgröße über 1–7 Tage ist der prognostizierbare Kern (`RECHERCHE_Regime_07-10-2026.md`).
- Eigene Prüfung P0.2: HAR schlägt EWMA bei 1 Tag in allen sechs Coins. Das 80-%-Band hielt bei BTC, ETH und HYPE (79,5–84,4 %)
  und war bei ZEC (74–76 %), XMR (76–77 %) und PAXG (69–72 %) zu schmal.
- Die Form aus echten normierten Pfaden (4.3) gleicht ein zu schmales HAR von selbst aus: Ist das HAR zu eng, sind die normierten
  Pfade entsprechend weiter. Das ist der Grundgedanke der gefilterten historischen Simulation (Barone-Adesi et al. 1999).

**Richtung ist schwach.** Belege:
- Literatur (Recherche 07.10.):
  - Wochenmomentum ist das robusteste mehrtägige Richtungssignal. Die Wochenrendite sagt bei BTC 2011–2018 die nächsten drei
    Wochen voraus, R² 3–5 % (Liu & Tsyvinski). Ab 2013 halbiert sich der Effekt. Nach 2020 bleibt **im Querschnitt der Coins**
    (Gewinner gegen Verlierer über viele Coins) nur zweiwöchiges Momentum, und das kleiner (Borri, Liu, Tsyvinski & Wu 2025); über
    die Zeitreihe eines einzelnen Coins wie BTC sagt diese Quelle nichts. *Berichtigt 27.10.2026: Hier stand das Ergebnis, als gelte
    es für BTC über die Zeit (BEWERTUNG_Wochenhorizont_27-10-2026.md, Abschnitt 5; RECHERCHE_Richtungstreiber_27-10-2026.md). Die
    Erwartung in Abschnitt 10, Wochenmomentum sei der beste Anwärter, stützte sich auch darauf; gemessen trug P1 nicht (12.2).*
  - Positionierung und Flüsse messen Risiko, nicht Richtung. Für OI, Long/Short-Quoten und Liquidationen gibt es keine
    außerhalb der Stichprobe geprüfte Studie.
  - Technische Regeln überleben nur als vorab fixierte Bündel.
- Aus der Aktienforschung:
  - Kaum ein Prädiktor schlägt außerhalb der Stichprobe den historischen Mittelwert (Welch & Goyal 2008).
  - Mit Vorzeichen- und Größenschranken entstehen kleine positive R²_OS (Campbell & Thompson 2008).
  - Die Kombination vieler schwacher Prädiktoren ist stabiler als jeder einzelne (Rapach, Strauss & Zhou 2010).
- Eigene Studien:
  - U126: 3–4 von 322–336 Tests belegt, weniger als der Zufall erwarten lässt.
  - U130 Teil A: 0 von 45 (Makro × BTC über 1/7/30 Tage).
  - U141: Rallyes und Rücksetzer wie ein Zufallsweg.
  - U142: H1 belegt (Konten ≥ 3 → häufiger Rücksetzer in 7 Tagen), H2 nicht.

**Teststärke (eigene Rechnung, grob).**
- Außerhalb der Stichprobe stehen ab 2022 rund 4,8 Jahre zur Verfügung. Nicht überlappend sind das je Coin etwa 250
  Wochenfenster, 125 Zwei-Wochen-Fenster und 62 Vier-Wochen-Fenster.
- Die fünf Krypto-Coins laufen stark gleich und zählen effektiv wie etwa zwei.
- Für einen Clark-West-Test mit 80 % Teststärke (einseitig 5 %) braucht es n ≥ 6,2/d². Bei bekanntem Drift gilt d ≈ √R²; weil
  die Gewichte geschätzt sind, braucht es grob den doppelten Effekt.
- Nachweisbar sind damit grob R²_OS ab 2–3 % bei 7 Tagen, ab etwa 5 % bei 14 Tagen und ab etwa 10 % bei 28 Tagen.
- Das Wochenmomentum der neueren Literatur liegt bei 7 Tagen am Rand. Bei 28 Tagen ist nur ein großer Effekt sichtbar.

## 3. Daten

| Familie | Inhalt | Coins | ab | Quelle (nur lesend) | Rolle |
|---|---|---|---|---|---|
| Kurs | Tageskerzen (Schluss, Hoch, Tief) und realisierte Varianz aus 30-min-Kerzen | BTC, ETH, ZEC, XMR, HYPE; PAXG | 2020 bzw. Listung | `swing.db` (Swing-Takt); PAXG `regime.db` (Takt neu mit 23.66, 7.2) | Breite, Form, Richtung (P1–P10) |
| Derivate | Funding je 8 h | 5 Krypto-Coins | 2020 | `swing.db` (`sw_funding`) | Richtung (D1, D2) |
| Positionierung | OI, Konten (Long/Short aller Konten), Top-Trader (Konten und Positionen), Taker-Verhältnis, Perp-Anteil, OI ÷ Spotvolumen | 5 Krypto-Coins (Perp-Anteil, OI ÷ Spot nur BTC/ETH) | BTC 01.09.2020; ETH/ZEC/XMR 01.12.2021; HYPE 30.05.2025 | `hebel.db` über `hl_hebel.tafel_bauen` | Richtung (D3–D10) |
| Makro/On-Chain | MVRV, Power Law, 200-Wochen-MA, Kurzfrist-Kostenbasis, MVRV-Z, Puell, DVOL, Fear & Greed, SSR, Nettoliquidität, Realzins, Dollar | marktweit (gleicher Wert für alle Krypto-Coins) | 2010–2021 je Reihe; FRED mit 7 T Versatz | `makro.db` über `hl_makro_korr.merkmale` | Richtung (M1–M12) |
| Hyperliquid | Wale, Orders der Großkonten, Liquidationscluster, Heatmap, Fills | alle | seit wenigen Wochen | `hl_liq.db` | **nur Niveaus** (4.7) |
| Niveaus | Swings, runde Zahlen, Wände, Stops, Take-Profits, Liquidationscluster, 50/200-Tage-Linie, Bestätigungsschwelle des Beins | alle | jetzt | `hl_chartbild.payload` | Ziellevels (4.7) |

**Nicht eingehend:**
- ETF-Flüsse: erst ab 01/2024, die erste Hälfte fehlt.
- OI ÷ Marktkapitalisierung und Funding 30 T aus U130: Doppel zu D2 bis D4.
- Tageszeit und Kalender: kein Wochenhorizont (Recherche: Vorzeichen wechseln).
- Analoge (Fluch der Dimension, Recherche) und agentenbasierte Simulation (erklärt Fakten, prognostiziert keine Richtung).

## 4. Modell (fest)

### 4.1 Zeitpunkt, Ziel, Horizonte

*Ergänzung 11.10. abends: Anker rollierend alle 30 Minuten, Tage als 24-h-Blöcke, Schockregel — siehe 13.1.*

- **Entscheidungszeitpunkt** ist der Tagesschluss d (00:00 UTC), der letzte abgeschlossene Tag. Nur Daten bis d. FRED-Reihen
  werden mit 7 Tagen Versatz genommen; Tagesstände wie in U141/U142 (jüngste Stundenzeile ≤ Ende d, höchstens 2 h alt).
- **Ziel:**
  - R_h = ln C(d+h) − ln C(d) für h = 7, 14 und 28 Tage;
  - dazu der Pfad über die Tageshochs und -tiefs d+1 … d+h. Berührungen werden an Hoch und Tief geprüft, nicht an den
    Schlusskursen; damit entfällt der Fehler der diskreten Beobachtung.
- **Anker im Chart:**
  - Der Fächer beginnt am Schluss d (wie das Band des Chartbilds); der Kurs jetzt wird daneben gezeigt.
  - Ein Niveau, das seit dem Schluss schon berührt wurde (Hoch bzw. Tief der 1-min-Kerzen seit 00:00 UTC), steht als „seit dem
    Schluss erreicht“ und erhält keine Wahrscheinlichkeit.

### 4.2 Breite

*Ergänzung 11.10. abends: HAR auf rollierenden 24-h-Tagen mit vier Ankerstunden (13.1), Zusätze X1–X4 (13.2).*

- **HAR-log je Horizont:** `hl_regime.har_prognosen(P, h)` für h = 1, 7, 14 und 28. Es ist dasselbe Modell wie P0.2:
  - Neuschätzung je Monat, Embargo bis zum Ende des Ziels;
  - Regressoren log RV des Tags, der Woche und des Monats, aus 30-min-Kerzen.
- **Ergebnis:** F(d, h), die erwartete Summe der Tagesvarianzen über h Tage.
- **Zwischen den Stützstellen:** ln(F(d,k)/k) wird linear in k interpoliert; so entsteht die Schwankung für jeden Tag k = 1 … 28
  des Pfads.

### 4.3 Form: Pfad-Bibliothek (gefilterte historische Simulation auf Pfadebene)

*Ergänzung 11.10. abends: Fenster an vier Ankerstunden (13.1), S&P-500-Pfad als zweite Koordinate (13.3).*

- **Bibliothek:** Für jeden vergangenen Ursprung s eines Coins, dessen Pfad vor d vollständig realisiert war (s + 28 ≤ d − 1),
  normierte Pfade für k = 1 … 28:
  - Z(s,k) = (ln C(s+k) − ln C(s)) ÷ √F(s,k)
  - ZH(s,k) = (ln H(s+k) − ln C(s)) ÷ √F(s,k), mit dem Tageshoch H
  - ZL(s,k) = (ln L(s+k) − ln C(s)) ÷ √F(s,k), mit dem Tagestief L
  - F(s,k) ist die damalige Prognose aus 4.2, also kausal.
- **Ohne Trend:** Je k wird der Mittelwert m̄(k) der Schluss-Pfade Z(·,k) von Z, ZH und ZL abgezogen; der ganze Pfad wird also
  verschoben. Der Aufwärtstrend vergangener Jahre wird so nicht in die Zukunft verlängert; Richtung kommt nur aus 4.4.
- **Umfang:**
  - Die ganze eigene Historie ab 2020 (BTC, ETH, ZEC, XMR: rund 2.000 Ursprünge).
  - Hat ein Krypto-Coin weniger als 730 Tage, gilt die gepoolte Bibliothek aller fünf Krypto-Coins (HYPE).
  - PAXG nur eigene Historie, mindestens 365 Tage, sonst kein Ausblick für PAXG.
- **Szenarien:** Alle Bibliothekspfade gelten mit gleichem Gewicht. Spannen und Wahrscheinlichkeiten sind Anteile über die
  Bibliothek — genau, reproduzierbar, ohne Zufallsziehung.
- **Prognosepfad je Szenario s:**
  - ln C(d+k) = ln C(d) + μ(k) + (Z(s,k) − m̄(k)) · √F(d,k)
  - Hoch und Tief entsprechend mit ZH und ZL.
  - μ(k) ist die Drift aus 4.4. Sie ist 0, solange das Tor (4.5) geschlossen ist.

### 4.4 Richtung: Kandidaten, Normierung, Schätzung

*Ergänzung 11.10. abends: A1–A4 kommen hinzu, zusammen 35 Kandidaten (13.5).*

**Ziel der Schätzung:** y(d,h) = R_h ÷ √F(d,h), die normierte Rendite der folgenden h Tage. σ̂(d) = √F(d,1) ist die
Tagesschwankung.

**Kandidaten (31, fest; Wert am Tag d):**

*P — Kurs (alle Coins):*

| Nr. | Kandidat | Definition |
|---|---|---|
| P1 | Wochenmomentum | ln C(d)/C(d−7) ÷ (σ̂√7) |
| P2 | Vierwochenmomentum | ln C(d)/C(d−28) ÷ (σ̂√28) |
| P3 | Quartalsmomentum | ln C(d)/C(d−91) ÷ (σ̂√91) |
| P4 | Tagesumkehr | ln C(d)/C(d−1) ÷ σ̂ |
| P5 | Abstand zur 200-Tage-Linie | ln C/MA200 ÷ (σ̂√28) |
| P6 | Steigung der 50-Tage-Linie | ln MA50(d)/MA50(d−10) ÷ (σ̂√10) |
| P7 | Bein | Richtung × Größe bisher ÷ Median der abgeschlossenen Beine dieser Richtung (U141, Schwelle 10 %, PAXG 3 %) |
| P8 | RSI 14 | (RSI − 50) ÷ 10 |
| P9 | Marktmomentum | P1 von BTC, für alle Coins |
| P10 | Schwankungslage | ln σ̂ ÷ Median σ̂ der 365 Tage davor |

*D — Derivate und Positionierung (5 Krypto-Coins):*

| Nr. | Kandidat | Definition |
|---|---|---|
| D1 | Funding-Druck | z30 (U141 C2) |
| D2 | Funding-Niveau | Mittel 7 T, Jahresrate (Carry) |
| D3 | OI-Änderung | ln OI(d)/OI(d−28), OI in Coins |
| D4 | OI-Perzentil | 90 T (U141 C1) |
| D5 | Konten | ln der Long/Short-Quote aller Konten |
| D6 | Konten-Perzentil | 90 T |
| D7 | Top-Trader, Positionen | ln der Quote |
| D8 | Top-Trader, Konten | ln der Quote |
| D9 | Taker | ln des Kauf/Verkauf-Verhältnisses, Mittel 7 T |
| D10 | Perp-Anteil am Volumen | BTC, ETH; sonst fehlend |

*M — Makro/On-Chain (marktweit, Werte aus `hl_makro_korr.merkmale`):*

| Nr. | Kandidat |
|---|---|
| M1 | MVRV-Perzentil |
| M2 | Kurs ÷ Power-Law-Fair-Value (Perzentil) |
| M3 | Abstand zum 200-Wochen-MA (Perzentil) |
| M4 | Kurs ÷ Kurzfrist-Kostenbasis − 1 |
| M5 | MVRV-Z |
| M6 | Puell (Perzentil) |
| M7 | DVOL |
| M8 | Fear & Greed 30 T |
| M9 | SSR (Perzentil) |
| M10 | Nettoliquidität, Änderung 4 Wochen |
| M11 | Realzins 10 J, Änderung 4 Wochen |
| M12 | Dollar breit, Änderung 4 Wochen |

**Normierung (kausal):**
- Jeder Kandidat wird je Coin mit Mittelwert und Standardabweichung der 730 Tage bis d z-normiert und auf ±4 gekappt.
- Hat ein Kandidat weniger als 365 Tage Historie, steht er auf 0 (neutral) und in der Tabelle als „zu kurz (seit …)“.

**Modell:**
- Ridge-Regression ohne Achsenabschnitt; die Grunddrift ist 0, wie beim Vergleich B0.
- Krypto-Coins gepoolt: ein Gewichtsvektor je Horizont, Zeilen = (Coin, Tag).
- PAXG eigens, nur mit P1–P8 und P10.

**Walk-forward:**
- Erste Schätzung am 01.01.2022 mit allen Daten ab 2020, dann alle 28 Tage neu.
- Trainiert wird nur mit Tagen, deren Ziel vor dem Schätztag endet (Embargo h).

**Strafparameter λ:**
- Gewählt in einer zeitlich geblockten Kreuzvalidierung innerhalb des Trainings: 5 zusammenhängende Teile, je h Tage Abstand
  vor und nach dem Prüfteil (López de Prado: Purging und Embargo).
- Gitter: 13 Werte λ = n · {0,01 … 10.000} (logarithmisch). Am oberen Ende sind alle Gewichte ≈ 0; „kein Signal“ ist also
  erreichbar.

**Ausgabe:**
- m̂(d,h) = Gewichte · Kandidaten, gekappt auf |m̂| ≤ 0,5. Wird gekappt, steht es in der Anzeige.
- Drift im Pfad: μ(k) = m̂ · √F(d,h) · k/h. Sie gilt nur bei offenem Tor (4.5), sonst μ = 0.

**Rechnung:** kumulierte Kreuzprodukte je Tag, damit Neuschätzungen, Weglassen eines Kandidaten und Nullläufe billig sind
(Pi: Rückblick ≤ 15 min).

### 4.5 Tor für die Richtung (je Horizont)

- **Zeitraum:** außerhalb der Stichprobe ab 01.01.2022 bis zum letzten realisierten Ziel. Hälften geteilt am mittleren Datum.
- **Clark-West** (verschachtelte Modelle, Drift 0 gegen m̂):
  - f(d) = 2 · y · m̂, gemittelt über die Coins je Tag. Für PAXG eigene Rechnung, wie dort alles.
  - Mittel > 0, einseitig; p aus einem stationären Blockbootstrap (Politis & Romano) mit mittlerer Blocklänge 2h und 2.000
    Wiederholungen. So ist die Überlappung der Ziele berücksichtigt.
- **CRPS** der ganzen Verteilung: M (mit Drift) gegen B0 (ohne), Differenz je Tag über die Coins gemittelt, derselbe Bootstrap.
- **Tor offen nur, wenn alles gilt:**
  - Clark-West p < 0,05;
  - CRPS-Gewinn p < 0,05;
  - in beiden Hälften ein Clark-West-Mittel > 0 und ein CRPS-Gewinn > 0.
- **Sonst bleibt das Tor zu:** Drift 0, Anzeige „Richtung nicht belegt“. Das Tor wird bei jedem Rückblick neu bestimmt, mit Datum.
- **Dazu angezeigt:** R²_OS = 1 − Σ(y − m̂)² ÷ Σy² (Campbell & Thompson) mit Intervall.

### 4.6 Gewichte prüfen (je Kandidat und Horizont)

*Ergänzung 11.10. abends: Das Nullverfahren wählt eine Kalibrierung auf zähen Null-Universen (13.6).*

| Größe | Bedeutung |
|---|---|
| **Gewicht** | m̂-Beitrag je Standardabweichung, letzte Neuschätzung |
| **Spur** | Kleinstes, mittleres und größtes Gewicht über alle Neuschätzungen; Anteil der Neuschätzungen mit demselben Vorzeichen wie heute („Vorzeichenstabilität“) |
| **Beitrag** | ΔMSE = Fehler ohne den Kandidaten − Fehler mit ihm, außerhalb der Stichprobe; über den ganzen Walk-forward neu geschätzt, ohne ihn |
| **Null** | 100 zirkuläre Verschiebungen der Kandidatenreihe um 365 … n−365 Tage (je Lauf ein Versatz für alle Coins; erhält Autokorrelation und Gleichlauf, bricht den Zusammenhang); λ je Neuschätzung wie im Hauptlauf; p = (1 + Anzahl ΔMSE_null ≥ ΔMSE) ÷ 101 |
| **Holm** | über die 31 Kandidaten je Horizont |
| **Status** | „trägt“: p Holm < 0,05 und ΔMSE > 0 in beiden Hälften · „Hinweis“: p roh < 0,05, aber nicht Holm (nur Hypothese für eine neue Runde) · „trägt nicht“ · „zu kurz“ |

Das Gewicht eines Kandidaten, der „trägt nicht“, wird nicht von Hand auf 0 gesetzt. Ridge schrumpft es; die Tabelle zeigt beides.
Am Fächer ändert ein Gewicht nur bei offenem Tor etwas.

### 4.7 Pfade, Spannen, Ziellevels

*Ergänzung 11.10. abends: bedingte Szenarien zum S&P 500 und Stressfächer (13.4).*

**Spannen je Horizont (7, 14, 28 Tage):**
- Quantile 5, 10, 25, 50, 75, 90 und 95 % des Schlusses — Preis und Abstand in %.
- Im Chart der Fächer für jeden Tag k: 10–90 % hell, 25–75 % dunkler, Median gestrichelt. An den Marken +1 W, +2 W und +4 W
  die Beschriftung „50 %: A–B · 80 %: C–D“.

**Ziellevels:**
- Kandidaten sind alle Niveaus des Chartbilds und die Bestätigungsschwelle des laufenden Beins:
  - Swing-Hochs und -Tiefs, runde Zahlen;
  - Wände, Stops und Take-Profits der Großkonten, Liquidationscluster;
  - 50- und 200-Tage-Linie.
- Gezeigt wird, was innerhalb der 28-Tage-Spanne von 1–99 % liegt.
- Je Niveau L und Horizont h:
  - **Erreich-Wahrscheinlichkeit** = Anteil der Szenarien, deren Pfad-Hoch (L oben) bzw. Pfad-Tief (L unten) L bis Tag h
    berührt.
  - **Schluss-Wahrscheinlichkeit** = Anteil, der am Tag h jenseits von L schließt.
- Im Chart höchstens 5 Niveaus je Seite (die nächsten), beschriftet „Name · Preis · 1 W a % · 2 W b % · 4 W c %“. Die Tabelle
  zeigt alle.
- Für die Momentaufnahmen von Hyperliquid (Wände, Stops, Cluster) gilt der Hinweis: Die Wahrscheinlichkeit gilt dem Preis; ob die
  Orders dann noch dort liegen, ist offen.
- Das Wort „Ziellevel“ steht nur in diesem Sinn: ein Preisniveau mit seiner Erreich-Wahrscheinlichkeit, keine Empfehlung.

### 4.8 Sonderfälle

- **HYPE:** gepoolte Bibliothek, solange die eigene Historie < 730 Tage ist. Positionierung ab 30.05.2025, bis 365 Tage
  Historie „zu kurz“.
- **PAXG:** eigene Bibliothek, Richtung nur aus Kurs-Kandidaten, eigenes Tor. Ohne Funding, Positionierung und Krypto-Stimmung,
  bewusst und so angezeigt wie im Chartbild.
- **Fehlender HAR-Wert** (zu kurze RV-Reihe): Für den Coin gibt es keinen Ausblick; der Grund steht in der Anzeige.

## 5. Prüfung (vorab festgelegt)

### 5.1 Rückblick

- Ursprünge täglich vom 01.01.2022 bis zum letzten Tag mit realisiertem Ziel, je Coin und Horizont.
- Bibliothek, HAR und Gewichte je Ursprung nur aus Daten davor (4.2–4.4).
- Für die Erreich-Wahrscheinlichkeiten wöchentliche Ursprünge (montags 00:00 UTC) mit Prüfniveaus:
  - L = C(d) · e^{±k·√F(d,h)} für k = 0,5 / 1 / 1,5 / 2;
  - dazu die zwei nächsten Swing-Niveaus je Seite (Regel des Chartbilds, aus den Tageskerzen bis d) und die nächsten runden
    Zahlen.
  - Orders und Cluster haben keine Historie; sie werden nur vorwärts geprüft (5.6).

### 5.2 Vergleichsmodelle

| Modell | Inhalt |
|---|---|
| **B1** | Zufallsweg mit der Schwankung der letzten 365 Tage, normalverteilt — der naive Vergleich |
| **B0** | Breite (4.2) + Form (4.3), Drift 0 |
| **M** | B0 + Drift (4.4) |

### 5.3 Maße

- **CRPS** der Rendite R_h — genau aus den Szenarien.
- **PIT-Histogramm** mit 10 Klassen.
- **Deckung** der Spannen 50/80/90 % mit Standardfehler aus dem Blockbootstrap.
- **Erreich-Wahrscheinlichkeiten:**
  - Brier-Score und Brier-Skill gegen B1;
  - Zuverlässigkeitsdiagramm (10 Klassen, beobachtete Quote mit 90-%-Intervall);
  - Kalibrierungssteigung: logistische Regression des Ereignisses auf logit(p), Soll 1.

### 5.4 Tests

- **Alle Vergleiche:** Differenzen je Tag über die Coins gemittelt; stationärer Blockbootstrap mit mittlerer Blocklänge 2h und
  2.000 Wiederholungen; beide Hälften.
- **Mehrfachtests:** Holm über Kandidaten (4.6); Tor und Urteile S1–S3 je Horizont, ohne weitere Korrektur, weil sie vorab
  einzeln festgelegt sind.

### 5.5 Urteile und was daraus folgt

- **S1 Breite** (B0 gegen B1):
  - Bedingungen: CRPS-Gewinn mit p < 0,05 gepoolt je Horizont; Deckung des 80-%-Bands bei BTC und ETH in 80 % ± 2 SE.
  - Folgt: Angezeigt wird B0.
  - Ist B1 signifikant besser, zeigt die Anzeige B1 mit Warnhinweis. Bei Deckung außerhalb der Spanne steht die gemessene
    Deckung je Coin am Fächer.
- **S2 Richtung:** das Tor (4.5). Offen → M, geschlossen → B0 und der Satz „Richtung nicht belegt“.
- **S3 Ziellevels:**
  - Bedingungen: Kalibrierungssteigung zwischen 0,8 und 1,2 und Brier-Skill gegen B1 > 0 (gepoolt, je Horizont).
  - Sonst stehen die Prozente mit dem Hinweis „im Rückblick nicht kalibriert: Steigung …“.
- **Kein Urteil wird nachträglich gelockert.** Was später dazukommt, ist eine neue Runde mit neuer Festlegung.

### 5.6 Vorwärtsbilanz

- **Gespeichert wird täglich in `ausblick.db`:**
  - Quantile je Coin und Horizont;
  - Tor-Stand und m̂;
  - die Wahrscheinlichkeiten der Prüfniveaus und der gezeigten Niveaus, samt Art.
- Nach 7, 14 und 28 Tagen wird ausgewertet.
- **Bilanz ab dem ersten Tag:** Deckung, CRPS gegen B0/B1, Zuverlässigkeit — auch für Orders und Cluster, die der Rückblick
  nicht kennt. Bis genug Fälle da sind, steht „noch zu wenige Fälle (n)“.

## 6. Anzeige: Abschnitt „AU Ausblick 4 Wochen“

*Ergänzung 11.10. abends: Szenario-Abfrage und Reiter „Aktienmarkt“ (13.7).*

**Ort:** nach dem Chartbild, Navigation „Ausblick“, Coin aus dem Kopf der Seite. Dieselbe Zeichenart wie das Chartbild:
logarithmische Skala, hohle und gefüllte Kerzen, „heute“-Linie.

**Chart:**
- Die letzten 3/6/12 Monate, rechts 28 Tage Zukunft mit dem Fächer.
- Marken +1 W, +2 W, +4 W mit den Spannen.
- Niveaus mit ihren Wahrscheinlichkeiten; Ebenen einzeln schaltbar.
- Fadenkreuz: Tag k → Quantile, Niveau → Wahrscheinlichkeiten.
- Tabelle statt Bild schaltbar.

**Lesart in vier Sätzen**, nur aus den Zahlen. Verbotene Wörter wie im Chartbild; „Ziellevel“ nur nach 4.7.
1. **Spanne:** „In 4 Wochen liegt {Coin} mit 80 % zwischen A und B (−x % / +y %), mit 50 % zwischen C und D; Median E. Im
   Rückblick traf das 80-%-Band n %.“
2. **Richtung:**
   - Tor zu: „Richtung nicht belegt — der Fächer ist driftfrei. Stärkster Kandidat: … (trägt nicht).“
   - Tor offen: „Richtung belegt für h Tage (seit …): Median +x %; tragend: …“
3. **Ziellevels:** „Nach oben {Niveau} {Preis}: in 1/2/4 Wochen erreicht mit a/b/c %; nach unten {Niveau} {Preis}: …“
4. „Wahrscheinlichkeiten aus der Verteilung, keine Empfehlung.“

**Tabellen (Reiter):**

| Reiter | Inhalt |
|---|---|
| Spannen | Horizont × Quantile, Preis und % |
| Ziellevels | alle Niveaus: Art, Preis, Abstand, Erreichen 1/2/4 W, Schluss jenseits 4 W, Quelle, Hinweis |
| Gewichte | 31 Kandidaten: Familie, Gewicht je Horizont, Spur, Vorzeichenstabilität, Beitrag, p, p Holm, Hälften, Status, seit wann |
| Bilanz | S1–S3 mit Zahlen, Deckungstabelle, Zuverlässigkeitsdiagramm, Tor je Horizont mit Datum, Vorwärtsbilanz |
| Korrelationen | Spearman der Kandidaten untereinander (3 Jahre), jeder Kandidat gegen die normierte Rendite der folgenden 7/14/28 Tage mit 90-%-Nullband (200 zirkuläre Verschiebungen), Gleichlauf der Coins (28-Tage-Renditen) — ausdrücklich beschreibend, belegt ist nur, was 4.6 besteht |
| Was fehlt | mit Grund |

## 7. Betrieb

*Ergänzung 11.10. abends: Takt aus 13.1 ersetzt Punkt 2 (täglicher Lauf); neues Archiv `aktien.db` (13.8).*

1. **Dateien:** `hl_ausblick.py` (Modell, Rückblick, Text, Selbsttest), `hl_ausblick_js.py` (Abschnitt) und `ausblick.db` neben
   `hl_liq.db`. Die Tabellen:
   - Prognose je Tag, Coin und Horizont;
   - Niveaus;
   - Gewichte je Neuschätzung;
   - Rückblick;
   - Null;
   - Vorwärtsbilanz;
   - meta.
2. **Takt** in einem eigenen Prozess mit niedriger Priorität (`nice 10`), angestoßen vom Dashboard:
   - täglich ab 00:30 UTC: Prognose für alle Coins (Ziel < 60 s auf dem Pi). Vorher wird `regime.db` für PAXG nachgeladen. Das
     behebt nebenbei den Fehler aus `KONZEPT_Chartbild.md` 9.2 Punkt 1.
   - sonntags 02:00 UTC: Rückblick, Walk-forward und Nullläufe (Ziel ≤ 15 min).
   - Sperre: höchstens ein Lauf zur Zeit.
3. **Frische:** Die Prognose gilt bis zum nächsten Tagesschluss. Ist sie älter als 2 Tage oder fehlt eine Quelle, erscheint
   „Stand vom …“ und der Grund.
4. **Debug:**
   - „★ Ausblick: Stand aller Coins als Text“;
   - „Ausblick: Rückblick und Gewichte jetzt rechnen“;
   - „Ausblick: Selbsttest“.
5. **Berichtsplan:** ein erster Lauf in der Nacht nach dem Einspielen, danach wöchentlich sonntags.

## 8. Proben (Selbsttest ohne Netz, Mutationen, Browserprobe)

*Ergänzung 11.10. abends: S4 und weitere Proben in 13.9.*

1. **Pfadstatistik von Hand.** Bibliothek aus Gauß-Pfaden (normierte Brownsche Bewegung, Tageshoch und -tief aus feinen
   Teilschritten):
   - Quantile = Φ⁻¹ innerhalb des Stichprobenfehlers;
   - Erreichen ≈ Spiegelungsprinzip 2·P(B_h ≥ a) mit Korrektur für Tageshochs;
   - Erreichen ≥ Schluss jenseits;
   - Erreichen monoton in der Entfernung.
2. **Ohne Trend.** Bibliothek mit eingepflanzter Drift: Der Fächer bleibt um den Anker zentriert, solange das Tor zu ist.
3. **Breite.** Synthetische Märkte mit Schwankungsballung (HAR- bzw. GARCH-artig, t-Innovationen): B0 deckt 80 % ± 2 SE in ≥ 90 %
   der Märkte, B1 deckt in ruhigen Phasen zu viel und in unruhigen zu wenig.
4. **Null-Universen.** 100 Märkte mit 5 gleichlaufenden Coins und 31 Rausch-Kandidaten (AR(1) mit φ 0,9 bis 0,99, teils
   marktweit):
   - Tor öffnet je Horizont in ≤ 5 % (Soll mit Binomialintervall);
   - je Kandidat „trägt“ in ≤ 5 %.
5. **Positivkontrolle.**
   - Eingepflanzt: m = 0,17 · P1 (R² ≈ 3 % bei 7 Tagen, wie das Wochenmomentum der Literatur).
   - Das Tor öffnet bei 7 Tagen in ≥ 80 %, P1 „trägt“ in ≥ 80 %, die übrigen in ≤ 5 %.
   - Erreicht die Stärke das nicht, steht die gemessene Stärke im Bericht — das ist dann die ehrliche Nachweisgrenze.
6. **Kausalität.** Prognose aus einer bei d abgeschnittenen Datenbank = Prognose für d im vollen Lauf (auf 1e-12). Training nur
   mit Zielen vor dem Schätztag (Embargo).
7. **Gleiche Rechnung wie die Studien.** HAR wie `hl_regime`, Bein wie `hl_zyklus`, Positionierung wie `hl_hebel`, Makro wie
   `hl_makro_korr`, Niveaus wie `hl_chartbild`.
8. **Ende zu Ende.** Über die Route des Dashboards; Browserprobe: Fächer-Quantile und Niveaus im SVG an der beschrifteten Achse
   gegen die Nutzlast. Skript-Mutationen müssen rot werden.
9. **Mutationen ≥ 40**, unter anderem:
   - Tor ohne Hälften, Holm weggelassen, Embargo 0;
   - Trend nicht abgezogen, Normierung mit künftigen Daten;
   - Berührung an Schlusskursen;
   - Quantile vertauscht, Kappung entfernt;
   - PAXG mit Krypto-Kandidaten, HYPE ohne gepoolte Bibliothek.

## 9. Zusagen und Abgrenzung

- Keine Änderung an Fusion, v3, Kaskaden-Rechnung, v1-Lernen, Konfluenz, Labor, Treibern oder der 4-h-Prognose (Zusage bis
  25.10.). Der Ausblick liest, er schreibt nur `ausblick.db`.
- Keine Empfehlungen, keine Kauf- oder Verkaufswörter. Die Prozente sind Wahrscheinlichkeiten einer geprüften Verteilung, mit
  ihrer Bilanz daneben.
- Die Kandidatenliste, die Maße und die Schwellen hier sind fest. Neue Kandidaten oder andere Schwellen sind eine neue Runde mit
  eigener Festlegung, nie eine stille Änderung.

## 10. Erwartung vorab (damit nichts überrascht)

*Ergänzung 11.10. abends: 13.10.*

- **S1 Breite:** besteht bei allen Horizonten (Schwankungsballung). CRPS-Gewinn gegen B1 grob 3–10 %. Deckung bei BTC/ETH im
  Soll; bei ZEC/XMR durch die echten Pfade besser als P0.2, vielleicht noch knapp.
- **S2 Richtung:**
  - bei 14 und 28 Tagen sehr wahrscheinlich Tor zu;
  - bei 7 Tagen möglich, aber unwahrscheinlich. Die besten Anwärter sind Wochenmomentum (P1/P9) und die Kontenregel (D5/D6,
    U142 H1); ihr gemeinsamer Beitrag liegt vermutlich unter der Nachweisgrenze.
  - Die Tabelle „Gewichte“ wird überwiegend „trägt nicht“ zeigen. Das ist ein Befund, kein Fehler.
- **S3 Ziellevels:** kalibriert bei BTC/ETH, bei den kleinen Coins unsicher.
- Am wahrscheinlichsten zeigt der Abschnitt also einen driftfreien Fächer mit geprüfter Breite und geprüften
  Erreich-Wahrscheinlichkeiten. Das ist nützlich: „Wie wahrscheinlich ist 87.385 in zwei Wochen?“ beantwortet er ehrlich.

## 11. Entscheidungen beim Nutzer

*Ergänzung 11.10. abends: Punkte 4–6 in 13.11.*

1. Wahrscheinlichkeiten auch an den Momentaufnahmen von Hyperliquid (Wände, Stops, Cluster) zeigen — mit dem Hinweis aus 4.7?
   Standard: ja.
2. Bei geschlossenem Tor die unbelegte Modellrichtung zusätzlich gestrichelt zeigen? Standard: nein. Eine unbelegte Richtung
   neben einer belegten Breite lädt zum Fehllesen ein.
3. Zweite Runde mit Hyperliquid-Daten als Richtungskandidaten, sobald 12 Monate Historie da sind (frühestens Herbst 2027), mit
   eigener Festlegung.

**Entschieden 11.10.2026 23:30 (Nutzer, Auswahl):**
1. ja, wie gebaut (gestrichelt, Hinweis „gilt nur jetzt“);
2. nein, wie gebaut;
3. **nein** -- Hyperliquid-Daten bleiben im Ausblick Niveaus, keine zweite Runde als Richtungskandidaten.

## 12. Ergebnis und Nachträge

### 12.1 Nachtrag beim Bau (11.10.2026 abends, Version 2026-09-23.66) — vor jedem Lauf auf echten Daten

Gebaut wie festgelegt (1–11 mit 13). Die folgenden Punkte sind beim Bau entstanden. Jeder ist begründet, und keiner kennt ein
Ergebnis auf echten Daten.

1. **36 Kandidaten, nicht 35.** 4.4 nennt 31, die Tabellen dort haben aber 32 (P1–P10, D1–D10, M1–M12). Mit A1–A4 sind es 36,
   nicht 35 wie in 13.5 — eigener Zählfehler im Konzept, die Liste selbst ist unverändert. PAXG prüft seine 9 Kurs-Kandidaten
   (P1–P8, P10). Holm rechnet über die tatsächliche Zahl.
2. **Nullverfahren gewählt (13.6).**
   - **Kalibrierung:** 100 Null-Universen (je 5 Coins, 2.450 Tage, zähe Rausch-Kandidaten bis φ 0,995) für 7 und 28 Tage, je
     Verfahren 1.200 Tests der sechs zähen Kandidaten. Fehlurteile (p < 0,05):
     - Verschiebung 65 von 1.200 = 5,4 % (95 % Wilson 4,3–6,9 %);
     - Phasen 50 von 1.200 = 4,2 % (3,2–5,5 %).
     - Das Tor öffnete in 1 von 200 Universen.
     - Die Kalibrierung lief nach der Korrektur aus Punkt 5 vollständig neu.
   - **Regel vorab:** das Verfahren mit der Rate am nächsten an 5 % und höchstens 6 %; liegen beide darüber, Phasen-Randomisierung
     mit α = 0,025. **Gewählt: zirkuläre Verschiebung mit α = 0,05** — beide Raten liegen unter 6 %, die der Verschiebung näher an
     5 %. Das ist das Verfahren aus 4.6.
   - **Schwanzprüfung** (ergänzt beim Bau, festgelegt um 22:12 vor ihrem Lauf):
     - Grund: Holm über 36 Kandidaten braucht für den besten p ≈ 0,0014, die Kalibrierung prüft aber nur p < 0,05.
     - Anlass: Im Selbsttest (10 Märkte) hatte die Verschiebung 4 p-Werte unter 0,006 (erwartet 0,6), die Phasen 2.
     - Regel: höchstens 7 von 360 Tests mit p ≤ 0,01 (erwartet 3,6; Poisson P(≥ 8) ≈ 3 %). Sonst Phasen, und liegen beide
       darüber, Phasen mit α = 0,025.
     - Ergebnis auf 30 neuen Märkten (7 Tage, 100 Surrogate mit Verlängerung wie im Betrieb):
       - beide Verfahren 2 von 360 Tests mit p ≤ 0,01;
       - p ≤ 0,05: Verschiebung 17, Phasen 14 von 360;
       - „trägt“ nach Holm in je 2 von 30 Märkten (Familienrate 6,7 %, Soll 5 %);
       - Tor 0 von 30.
     - → **Die Verschiebung bleibt.** Die 4 kleinen p-Werte im Selbsttest waren Zufall in 10 Märkten.
   - **Selbsttest-Schranke berichtigt (eigener Fehler beim Bau der Probe).**
     - Vorher hieß es „trägt höchstens 1 von 120“. Das ist bei exakter Familienrate 5 % je Markt in 9 % der Fälle verletzt.
     - Jetzt gilt höchstens 2 (P(≥ 3) ≈ 1 %). Mit der Verschiebung stehen dort 2.
   - Die Phasen-Randomisierung bleibt im Code und im Selbsttest; die Surrogate beider Verfahren werden mechanisch geprüft.
3. **Sequentielle Null (ergänzt 4.6).** Mit 100 Surrogaten ist das kleinste p 1/101 ≈ 0,0099. Holm über 36 Kandidaten verlangt
   für den besten Kandidaten aber p < 0,05/36 ≈ 0,0014. „Trägt“ wäre damit unerreichbar gewesen, auch für einen echten Effekt.
   - Deshalb gilt: Liegt kein Surrogat über dem beobachteten Beitrag, rechnet die Prüfung weiter (Besag & Clifford 1991).
   - Sie hört bei 10 Überschreitungen oder 2.000 Surrogaten auf. Dann ist p = 10/n bzw. (1 + Überschreitungen)/(1 + n).
4. **Positivkontrolle und Nachweisgrenze (8 Punkt 5).** Bei m = 0,17 · P1 (R² ≈ 3 % bei 7 Tagen) erreicht das Tor die 80 % nicht
   (3 von 10). Deshalb gilt der Ersatz aus 8 Punkt 5: Die Nachweisgrenze ist gemessen, auf je 10 Märkten:

   | eingepflanzt | R² wahr | Tor offen | P1 „trägt“ | übrige „tragen“ | R²_OS | Orakel (wahres m) |
   |---|---|---|---|---|---|---|
   | m = 0,17 · P1 | 2,8 % | 3 von 10 | 9 von 10 | 0 von 110 | 1,15 % | 2,55 % |
   | m = 0,25 · P1 | 5,9 % | 9 von 10 | 10 von 10 | 0 von 110 | 4,18 % | 5,50 % |
   | m = 0,35 · P1 | 10,9 % | 10 von 10 | 10 von 10 | 0 von 110 | 8,96 % | 10,37 % |
   | m = 0,5 · P1 | 20,0 % | 10 von 10 | 10 von 10 | 0 von 110 | 16,05 % | 19,27 % |

   - Der Selbsttest prüft die Positivkontrolle bei m = 0,35 · P1 (R² 10,9 %): Tor offen und P1 „trägt“ in mindestens 4 von
     5 Märkten, die übrigen höchstens 2 von 55.
   - Lesart: Die Gewichtsprüfung findet ein Wochenmomentum in der Größe der Literatur (R² ≈ 3 %) fast immer (9 von
     10), das Tor aber nur in 3 von 10. Das Tor verlangt zwei Tests und beide Hälften. Eine Richtung dieser Größe stünde also meist
     als „trägt“ in der Tabelle „Gewichte“, ohne den Fächer zu verschieben. Ab R² ≈ 6 % öffnet das Tor fast immer. Die Schätzung
     kostet bis R² 11 % rund 1,3–1,4 Punkte R² gegen das Orakel. Eingepflanzt ist der günstigste Fall: ein Kandidat, stabil über
     alle Jahre und Coins.
5. **Eigener Fehler, beim Bau gefunden: die λ-Kreuzvalidierung sah in die Zukunft.**
   - Beim Purging des letzten Prüfteils zog sie die h Tage *nach* dem Schätztag ab, obwohl diese nie addiert waren.
   - Damit hing λ von Zielen ab, die bis in den Schätztag reichen.
   - Gefunden hat das die vorab festgelegte Probe „Embargo der Richtung“ (8 Punkt 6). Behoben vor jedem Lauf auf echten Daten;
     Kalibrierung und Nachweisgrenze liefen danach neu.
6. **Ereignisform der Kopula (13.4).**
   - Vorher wurde verworfen: rund 2.500 Treffer je Abfrage. Die Quantile schwankten je Saat um bis zu 0,15 σ.
   - Jetzt wird genau im Ereignis gezogen: je Ziehung g = √(χ²_ν/ν) und z₁ aus der bei g·t* abgeschnittenen Normalverteilung,
     mit dem Gewicht Φ(g·t*).
   - Mit wahrem ρ und ν trifft das Verfahren die Wahrheit auf 0,02–0,03 σ (Selbsttest).
   - Grenze des Rückfalls, beschreibend: Mit geschätztem ρ und ν (ν auf dem Gitter, geschätzt 4 statt 5) weichen die bedingten
     Quantile im Test um bis zu 0,17 σ ab. Die Bibliotheksform braucht dagegen nur Fenster unter s* und liegt im Stichprobenfehler.
7. **Rechenzeit.**
   - Die t-Verteilung für ganzzahlige ν ist jetzt in geschlossener Form gerechnet (Abramowitz & Stegun 26.7.3/26.7.4) statt
     über den Kettenbruch. Das Ergebnis ist gleich auf 10⁻¹³.
   - Die Prognose aller Coins brauchte vorher 328 s, jetzt 9–17 s in der Sandbox; auf dem Pi rund dreimal so lange.
   - Der Rückblick (S1–S4, HAR-X, Walk-forward, Nullläufe) läuft als eigener Prozess mit nice 10. In der Sandbox brauchte er auf
     den Demo-Datenbanken (drei Jahre, 100 Surrogate) 241 s; auf dem Pi mit der Historie ab 2020 geschätzt 20–40 min.
8. **Takt (13.1, 7 Punkt 5).**
   - Der Rückblick läuft im Takt. Der erste kommt in der Nacht nach dem Einspielen (01–06 UTC), spätestens 24 h nach dem Start
     des Takts. Danach läuft er sonntags ab 02:00 UTC, wenn der letzte älter als 5 Tage ist.
   - Ein gescheiterter Rückblick wird frühestens nach 6 h wiederholt.
   - Gleich danach rechnet eine Prognose mit dem neuen Stand.
   - Während des Rückblicks läuft die Schockprüfung weiter (alle 5 min). Die Ausnahme steht sofort; gerechnet wird gleich nach
     dem Rückblick.
9. **Kandidatentag.** Am Anker τ gilt der letzte abgeschlossene UTC-Tag (Tag d endet um d+1 00 UTC). Das gilt auch an den
   Ankern 06/12/18 UTC: Der laufende Tag ist nie dabei. Fehlt ein Tag, gilt der davor.
10. **Proben (8, 13.9).**
    - Der Selbsttest hat 49 Prüfungen in 11 Gruppen (`--nur basis,pfad,…`, für schnelle Wiederholungen).
    - Neu gegenüber 8/13.9:
      - Normalquantil, F-Pfad, Holm und gewichtete Quantile von Hand;
      - Breite unverzerrt (Mittel realisierte Varianz ÷ Prognose 0,99, ohne den Ausgleich s²/2 rund 1,16);
      - Regressoren am Halbstundenpunkt gleich denen der Schätzung;
      - Ereignisform;
      - Bein auch gespiegelt;
      - Kandidatentag;
      - Takt in 15 Schritten;
      - Positionierung D5/D6 wie `hl_hebel`, über echte Tafeln;
      - Surrogate beider Nullverfahren mechanisch (derselbe Versatz bzw. dieselben Phasen für alle Coins);
      - Größe des Blockbootstraps bei überlappenden 7-Tage-Zielen: 8 % bei nominal 5 % auf 1.750 Tagen, also leicht großzügig
        (ohne Block rund 28 %; bei 28 Tagen und Block 56 gemessen 4 %). Das Tor fängt das auf: zwei Tests, beide Hälften. Es
        rechnet beide Tests mit Blocklänge 2h, auch im knappen Fall.
    - Die Demo-Datenbanken hatten zuerst keine Perp-Tageskerzen in `hebel.db`. Dadurch gab es keine Tafeln, und D3–D10 fehlten
      im Ende-zu-Ende-Lauf. Jetzt sind sie dabei, und die Kausalitätsprobe schneidet auch diese Kerzen bei τ ab.
    - Mutationen: 61 von 61 rot (`mut_au.py`); fünf erst nach neuen Proben (Normalquantil, Lognormal-Ausgleich, gespiegeltes Bein,
      Blocklänge im Tor, Bootstrap ohne Block).
    - Browserprobe: 4 Szenarien (BTC 6 Monate, ETH 12 Monate mit Schlusslinie, PAXG, HYPE am Handy), 82 Prüfungen gegen die
      beschrifteten Achsen; Skript-Mutationen 16 von 16 rot.

### 12.2 Ergebnis (nach dem ersten Rückblick auf dem Pi)

**Erster Rückblick: 12.10.2026 01:00 UTC** (Version 23.66, 308 s auf dem Pi; Bericht 08:30, Sammeldatei 13.10. 01:03). Ursprünge
ab 01.01.2022 außerhalb der Stichprobe, sechs Coins, Nullverfahren Verschiebung (12.1 Punkt 2).

| Prüfung | Ergebnis | Erwartung vorab (10, 13.10) |
|---|---|---|
| **Breite HAR-X** (X1–X4 gegen das Grundmodell, QLIKE, Holm, beide Hälften) | bei keinem Horizont ein Gewinn. X1 (DVOL): 7 T +0,0014, 14 T +0,0044 (p Holm 0,908), 28 T +0,0043; X2–X4 überall negativ → **Grundmodell** | X1 trägt bei BTC und ETH ab 7 Tagen — **nicht eingetroffen** |
| **S1 Breite** (B0 gegen B1) | **besteht bei keinem Horizont.** CRPS-Gewinn 7 T +1,3 % (p 0,001), 14 T +0,2 % (p 0,243), 28 T −0,8 % (p 0,840); an den Ankern 6/12/18 UTC ebenso. Deckung des 80-%-Bands bei 28 T: BTC 83,1 % ± 3,2, ETH 78,4 ± 3,4, HYPE 79,8 ± 6,7, XMR 84,3 ± 2,6, ZEC 77,3 ± 4,2, **PAXG 56,5 ± 5,3**; bei 7 T BTC 83,7 ± 1,6 (über 80 + 2 SE) und PAXG 66,8 ± 3,9 | besteht überall, Gewinn 3–10 % — **nicht eingetroffen** |
| **S2 Richtung** | Tor zu in allen sechs Fällen (Krypto und PAXG, 7/14/28 T); R²_OS überall negativ | Tor zu — eingetroffen |
| **Gewichte** | alle 36 Kandidaten „trägt nicht“ | eingetroffen |
| **S3 Ziellevels** | **besteht** bei 7/14/28 T: Brier-Skill gegen B1 +6,1/+3,5/+1,2 %, Steigung 0,95/0,91/0,89 (n 15.179) | kalibriert bei BTC/ETH — eingetroffen (gepoolt) |
| **S4 gemeinsame Form** | **belegt:** Variogramm-Gewinn 0,0617, p 0,002, Hälften 0,0303/0,0930 (n 1.718). Rosenblatt-PIT insgesamt 7 T p 0,138, 28 T p 0,033; **unter Aktienstress 7 T p 0,017, 28 T p 0,001**; Deckung 80 % Stress/Mitte/Hoch 0,87/0,81/0,82 (7 T) und 0,79/0,81/0,80 (28 T) | „vermutlich, aber knapp“ — deutlicher als erwartet; die schlechte Kalibrierung unter Stress war nicht vorhergesagt |
| **Bedingte Szenarien** | Episoden-ESS 1,3–10,3 → überall der Kopula-Rückfall | ruhiger Markt: ESS unter 15 — eingetroffen |

**Folgen nach den Regeln (5.5), nichts gelockert:**
- S1: B1 ist nicht signifikant besser (28 T: p 0,840 für B0) → angezeigt wird weiter **B0**. Die gemessene Deckung steht je Coin am
  Fächer.
- S2: driftfrei, Satz „Richtung nicht belegt“. S3: die Prozente stehen ohne Hinweis. S4: „Abhängigkeit im Rückblick belegt“.

**Nachträglich ergänzt in 23.67 (reine Anzeige, kein Urteil geändert):**
1. **Deckung mit Wertung.** 23.66 nannte die Deckung („traf das 80-%-Band 57 %“), sagte aber nicht, dass sie außerhalb der Spanne
   liegt. Jetzt steht nach 5.5 dahinter „-- zu eng (Soll 80 %)“ bzw. „-- zu weit (Soll 80 %)“, wenn die Deckung außerhalb von
   80 % ± 2 SE liegt. Am 12.10. träfe das PAXG bei 28 T.
2. **S4 mit Hinweis zur Kalibrierung unter Stress.** 13.9 verlangt nur den Stand von S4 an den Szenarien. Weil die PIT unter
   Aktienstress nicht gleichverteilt war, steht dort jetzt zusätzlich „unter Aktienstress im Rückblick nicht kalibriert (PIT p …
   bei h T)“, wenn p < 0,05 (Text und Dashboard). Für ältere Rückblicke ergänzt der Code die Prüfgrößen aus dem gespeicherten
   vollen Rückblick.
3. **Stressfächer klar beschriftet.** Der Stressfächer war bei 80 % schmaler als der normale (BTC 75.465–93.621 gegen
   73.018–97.550). Das liest sich wie „in der Krise weniger Risiko“. Er ist aber, wie in 13.4 festgelegt, die **Form** der Wege aus
   der unruhigsten Phase seit 2020 bei **heutiger Breite**. Dicke Ränder bei gleicher Varianz machen die Mitte schmaler und die
   Ränder breiter. Die Beschriftung heißt jetzt „Form der unruhigsten Phase seit 2020 (24.02.2020–23.02.2021) bei heutiger
   Schwankung“ und zeigt 80 und 90 %. Einen Fächer mit der *Größe* der Stressphase gibt es noch nicht. **Entschieden 13.10.
   (Nutzer):** er kommt zusätzlich, als Szenario (13.14, Bau mit 23.68).

**Eigene Fehleinschätzungen:**
- S1 und X1 lagen daneben. Ich hatte aus der Literatur (Schwankungsballung, implizite Volatilität) auf einen klaren Vorsprung
  gegen den naiven Vergleich geschlossen. Gegen B1 mit 365 Tagen Schwankung gewinnt B0 nur bei 7 Tagen, und das knapp.
- Die Deckung bei PAXG (57–67 %) zeigt: Für Gold ist die Bibliothek zu schmal. PAXG hat die kürzeste Historie (3.218 Fenster).
  Woran es liegt, ist nicht geprüft.

## 13. Ergänzung vom 11.10.2026 abends: Takt, Aktienmarkt, gemeinsame Szenarien

Vorab festgelegt am 11.10.2026 gegen 19:30, **vor jedem Lauf auf echten Daten** — der Ausblick ist noch nicht gebaut. Die
Ergänzung ersetzt die genannten Stellen von 1–11 ausdrücklich; was nicht genannt ist, gilt unverändert.

**Anlass:** Wunsch des Nutzers vom 11.10. 17:49, diktiert.
- Eine Aktualisierung einmal im Monat sei viel zu selten. Bei einem Black-Swan-Ereignis könne der Markt blitzschnell kippen.
  Deshalb solle der Ausblick alle 30 Minuten aktualisiert werden, wenn das Dashboard offen ist, sonst seltener im Hintergrund.
- ETF-Flüsse und MicroStrategy seien als Stimmungsmaß einzubeziehen.
- Vor allem der Aktienmarkt (S&P 500, die zehn größten Werte, Quartalszahlen, Prognosen) gehöre hinein: Fällt der S&P 500,
  falle BTC „immer“, BTC lebe von Liquidität und Debasement, und der Aktienmarkt gebe die Angst vor.
- Gewünscht ist eine gründliche Recherche der Schnittstellen und eine Prüfung des Zusammenhangs.
- Mein Missverständnis: Nur die Gewichte waren alle 28 Tage geplant, die Prognose täglich. Grundlage der Ergänzung ist
  `RECHERCHE_Aktienmarkt_11-10-2026.md`.

**Kernbefund der Recherche:** Der Aktienmarkt liefert dem Ausblick eine *Koordinate* (gemeinsame Szenarien) und einen
*Maßstab* (Breite), aber keine Richtung.
- Keine Aktiengröße sagt die BTC-Rendite über 1–4 Wochen außerhalb der Stichprobe voraus.
- Fiel der S&P 500, fiel BTC im jüngsten Jahr an 66 % der Verlusttage, bei Tagen unter −1 % an 88 %.
- Es gibt Ausnahmen in beide Richtungen (März 2023; 2025/26 BTC −43 % bei steigendem S&P).

### 13.1 Takt und Anker (ersetzt 4.1 „Tagesschluss“, 4.2 „Kalendertage“, 7 Punkt 2)

**Takt:**
- **Alle 30 Minuten**, solange der Abschnitt im Dashboard offen und sichtbar ist (auf Anfrage, Ergebnis 30 min zwischengespeichert).
- **Stündlich im Hintergrund.**
- **Sofort bei einem Schock** (siehe unten).

Jede Neuberechnung nimmt den Stand am Anker τ, dem Ende der letzten abgeschlossenen 30-min-Kerze: Kurs, Schwankung, Kandidaten,
Niveaus. Die **Gewichte** der Richtung werden weiter alle 28 Tage geschätzt (4.4). Ein Gewicht aus den letzten 30 Minuten wäre
nicht besser, es liefe dem Rauschen nach.

**Rollierende Tage:**
- Ein „Tag“ ist der 24-Stunden-Block, der am Anker endet. Grundlage sind die 30-min-Kerzen aus `swing.db` und für PAXG aus
  `regime.db`.
- RV_24h(τ) ist die Summe der quadrierten 30-min-Log-Renditen der letzten 48 Kerzen.
- Woche und Monat sind Mittel von RV_24h über 7 × 24 h und 30 × 24 h.
- Jedes Fenster enthält jede Uhrzeit genau einmal; das Tagesprofil der Schwankung mittelt sich heraus.

**HAR (ersetzt 4.2):**
- HAR-log auf diesen Größen, geschätzt an den vier Ankern 00, 06, 12 und 18 UTC je Tag, gepoolt mit je einem Achsenabschnitt
  je Ankerstunde.
- Neuschätzung je Monat mit Embargo bis zum Zielende, wie bisher.
- h = 1, 7, 14, 28 (je 24 h); dazwischen log-linear interpoliert.
- Implementiert in `hl_ausblick`, nicht in `hl_regime`; P0.2 bleibt unverändert.

**Bibliothek (ersetzt 4.3 „Ursprünge s“):**
- Fenster an denselben vier Ankerstunden.
- Pfadschritte von je 24 h ab dem Anker; Hoch und Tief je Block aus den 30-min-Kerzen.
- Gleiche Gewichte; die Normierung mit F(s,k) des eigenen Ankers.

**Richtung:**
- Die Kandidaten werden am Anker mit dem jüngsten Stand ≤ τ ausgewertet; die Gewichte kommen aus der monatlichen Schätzung.
- Geschätzt und am Tor geprüft wird auf den 00-UTC-Ankern, wie in 4.4/4.5.

**Schock (Ereignisalarm):** Sofortige Neuberechnung außerhalb des Takts, wenn für einen Coin gilt:
- (a) eine 30-min-Rendite mit |r| > 5 · √(F(τ,1)/48), also über fünf typische Halbstundenbewegungen; oder
- (b) die realisierte Varianz der letzten 6 h übersteigt das Vierfache ihres Erwartungswerts F(τ,1)·6/24; oder
- (c) der S&P-500-Perp von Hyperliquid (`xyz:SP500`, rund um die Uhr, 13.8) bewegt sich in den letzten 6 h um mehr als
  3 · √(F_S(τ,1) · 6/24). Das gilt auch am Wochenende, wenn die Börse geschlossen ist.

Der Schock geht über RV_24h sofort in den Tagesbestandteil des HAR ein: Der Fächer wird für 1–7 Tage sofort breiter, für 28
Tage weniger, weil dort der Monatsbestandteil überwiegt. Die Anzeige trägt 24 h lang „Ausnahmelage seit HH:MM“. Der Alarm
schreibt nur in `ausblick.db`, er wirkt auf nichts sonst.

*Berichtigung 19.10.2026 (U179, 13.18): Der Satz „Der Schock geht über RV_24h sofort … breiter“ gilt nur für (a) und (b). Bei
(c) löst die S&P-Bewegung nur eine Neuberechnung aus; die Spanne eines Coins kommt aus seiner eigenen Schwankung, der Perp geht
nicht ein.*

**Prüfung:**
- Rückblick wie 5.1 auf den 00-UTC-Ankern.
- Zusätzlich Deckung und CRPS an den Ankern 06/12/18 UTC: Die untertägige Fassung darf nicht schlechter kalibriert sein (Urteil
  S1 je Ankerstunde, sonst Hinweis an der Anzeige).
- Nie nur an ausgelösten Neuberechnungen prüfen.

**Rechenzeit:** Eine Neuberechnung braucht für alle Coins wenige Sekunden (Bibliothek reskalieren, gewichtete Quantile,
Vergleiche), die Datenbank-Lesezugriffe eingeschlossen.

### 13.2 Breite: HAR-X (ergänzt 4.2)

Grundmodell ist 13.1. Vier Zusätze, je einzeln geprüft:

| Nr. | Zusatz | Definition | Für |
|---|---|---|---|
| X1 | implizite Volatilität | ln IV²_h mit IV²_h = (DVOL/100)² · h/365. ETH-DVOL wird neu geladen (Deribit, wie BTC in `makro.db`). | BTC, ETH; die BTC-DVOL als Fremdregressor für HYPE, ZEC, XMR; nicht PAXG |
| X2 | Schwankung des S&P 500 | ln Mittel der quadrierten Tagesrenditen über 5 und 20 Handelstage (FRED `SP500`) | alle Krypto-Coins |
| X3 | Finanzstress | St. Louis Fed Financial Stress Index (`STLFSI4`, wöchentlich) | alle Krypto-Coins |
| X4 | Aktien-Angst | ln VIX² (`VIXCLS`) | alle Krypto-Coins |

**Prüfung:**
- QLIKE je Horizont auf den 00-UTC-Ankern gegen das Grundmodell.
- Differenzen über die Coins gemittelt; Blockbootstrap wie 5.4; Holm über X1–X4 je Horizont; beide Hälften.
- Dazu die Bewertung je VIX-Drittel, beschreibend: Die Gewinne werden sich in Stressphasen ballen.

**Regel:**
- Was einzeln besteht, kommt gemeinsam hinzu.
- Die Kombination muss das Grundmodell auf dieselbe Weise schlagen, sonst gilt nur der beste einzelne Zusatz.
- Angezeigt wird das bessere Modell mit Datum des Urteils; berechnet werden beide immer.

**Erwartung (Literatur):** X1 trägt ab 7 Tagen, X2 und X3 vielleicht in Stressphasen, X4 am wenigsten.

**Breite des S&P 500 selbst** (für 13.3):
- Gerichtete Regression der quadrierten Tagesrenditen über die S&P-Handelstage in (τ, τ+h] auf ln RV_S (5 und 20 Tage), ln VIX²
  und ln VIX3M² (`VXVCLS`).
- Walk-forward je Monat ab Ende 2016, wie die Krypto-Breite.

### 13.3 Form: gemeinsame Bibliothek mit dem S&P 500 (ergänzt 4.3)

- **S&P-Pfad im selben Fenster:** Jedes Bibliotheksfenster s trägt den S&P-Pfad aus demselben Zeitraum,
  z_S(s,k) = [ln P_S(s+k) − ln P_S(s)] ÷ √F_S(s,k) − m̄_S(k).
  - P_S(t) ist der letzte offizielle Schlusskurs ≤ t, fortgeschrieben über Wochenenden und Feiertage.
  - Der mittlere Trend wird wie bei den Krypto-Pfaden abgezogen. Bedingte Aussagen sind damit reine Aussagen über die
    Abhängigkeit, ohne Richtung.
- **Ab 2020-01-01**, weil die Abhängigkeit seit 2020 ein anderes Regime ist. Die Krypto-Bibliothek reicht ohnehin ab 2020.
- **Coins:** HYPE nutzt die gepoolte Bibliothek mit den S&P-Pfaden der jeweiligen Daten. PAXG bekommt keine S&P-Koordinate; dort
  steht der S&P nur im Barometer.
- **Der unbedingte Fächer (4.7) ändert sich dadurch nicht.** Die Koordinate trägt nur die bedingten Szenarien (13.4) und die
  Bewertung der gemeinsamen Form (13.9 S4).

### 13.4 Bedingte Szenarien und Stressfächer (ergänzt 4.7)

**Abfragen im Dashboard:** „Wenn der S&P 500 in h Tagen um x % steht“.
- Vorgaben: x ∈ {−15, −10, −5, +5} und h ∈ {7, 14, 28}.
- Dazu die Ereignisform „S&P ≤ −10 % in 28 Tagen“. Die Anzeige nennt, ob Punkt oder Ereignis gilt.

**Verfahren:**
1. **Kerngewichte:** w_i = exp(−½[(s_i − s*)/(λ · σ̂_S,h)]²) mit fester Bandbreite λ = 0,35, wobei s* = ln(1 + x).
2. **Schiefe im Kern:** lokal-lineare Korrektur b_i* = b_i − β̂ (s_i − s*), β̂ aus gewichteter Regression.
3. **Ergebnis:** gewichtete Quantile für jeden Krypto-Coin (Spanne 50/80 %, Median) und die Wahrscheinlichkeit, tiefer zu
   schließen.
4. **Effektive Stichprobe:**
   - nach Kish;
   - als **Episoden-ESS**: Fenster, deren Starts weniger als h Tage auseinanderliegen, bilden eine Episode;
     ESS = (Σ W_e)² ÷ Σ W_e².
5. **Nur ab Episoden-ESS ≥ 15** erscheint das Ergebnis aus der Bibliothek, stets mit dieser Zahl und dem Gewichtsanteil der
   größten Episode.
6. **Rückfall t-Kopula** auf den Rängen von (z_B(h), z_S(h)) der gemeinsamen Bibliothek:
   - ρ = sin(π τ_K / 2), Freiheitsgrade per Profil-Likelihood aus {3, 4, 6, 8, 12, 20, 50};
   - bedingtes Quantil zurückgerechnet über die BTC-Randverteilung der Bibliothek;
   - bei der Ereignisform über die Simulation U_S ≤ u*.
   - Existieren beide Antworten, stehen sie nebeneinander; ihr Abstand ist ein Maß der Modellunsicherheit.
7. **Daneben immer** das unbedingte 80-%-Intervall.

Eine Gewichtung nach dem Aktienzustand (Ähnlichkeit von VIX und S&P-Abstand zum Hoch) ist **nicht** Teil der Grundform. Sie
wäre eine eigene Runde als Ablation, weil sie die Episoden-ESS stark senkt.

**Stressfächer:**
- Neben dem Grundfächer, nicht in ihn gemischt.
- Die Bibliothek wird auf Fenster beschränkt, die im 365-Tage-Zeitraum seit 2020 mit dem höchsten mittleren ln VIX beginnen
  (vorab bestimmt aus `VIXCLS`), mit gleichen Gewichten und der heutigen Breite.
- Beschriftet „wie in der unruhigsten Phase seit 2020 (…–…)“.

### 13.5 Richtung: vier Aktien-Kandidaten (ergänzt 4.4, die Liste wächst von 31 auf 35)

| Nr. | Kandidat | Definition | Quelle |
|---|---|---|---|
| A1 | Nasdaq-100-Momentum, 1 Woche | ln NDX(d)/NDX(d−5 Handelstage) ÷ (σ̂_NDX √5) | FRED `NASDAQ100` |
| A2 | Nasdaq-100-Momentum, 4 Wochen | dasselbe mit 20 Handelstagen | FRED `NASDAQ100` |
| A3 | VIX-Laufzeitstruktur | ln(VIX/VIX3M) | FRED `VIXCLS`, `VXVCLS` |
| A4 | Kreditspread | Änderung über 4 Wochen von Baa minus 10 J (`BAA10Y`, täglich seit 1986, nicht revidiert) | FRED |

- **Alle marktweit** (gleicher Wert für alle Krypto-Coins); nicht für PAXG. Normierung, Ridge, Tor, Holm (jetzt über 35) wie
  4.4–4.6.
- **Kausalität:** Jede US-Schlussreihe (FRED, Cboe) zählt für den US-Handelstag d erst ab d+1 14:00 UTC. Eine Quelle, die den
  Wert nachweislich früher liefert, hat sich dafür nicht qualifiziert. Bei 7–28 Tagen kostet das fast nichts.
- **Bewusst nicht als Kandidat**, wie die Recherche empfiehlt:
  - die Regel „S&P fällt, BTC fällt“ und feste Betas;
  - Korrelationen aus kurzen Fenstern und aus Preisniveaus;
  - Liquidität (M2) mit festem Versatz;
  - Stimmungsumfragen, Put/Call, CNN Fear & Greed, NAAIM;
  - Konzentration, CAPE, IPO-Volumen und KI-Capex als Zeitgeber;
  - Coinbase- und Minerkurse.
- **ETF-Flüsse und ETF-Leerverkäufe** beginnen 2024 und können die Hälftenregel des Tors vor 2028 nicht erfüllen. Sie gehen
  in die Kurzstudie 13.13, nicht in den Ridge.

### 13.6 Null für die Gewichte (ergänzt 4.6)

- **Ausgangslage:** Bei U130 waren zirkuläre Verschiebungen für zähe Merkmale leicht zu großzügig: 6,5 % Fehlurteile bei
  nominal 5 %, bei Perzentilmerkmalen 8,7 %; Phasen-Randomisierung lag mit 5,4 % im Soll.
- **Kalibrierung vorab:** Vor dem ersten echten Lauf entscheidet sie auf 100 Null-Universen mit zähen Kandidaten (AR(1) mit
  φ bis 0,995, wie VIX-Perzentil und Spreadniveau).
- **Regel:**
  - Genommen wird das Verfahren (zirkuläre Verschiebung oder Phasen-Randomisierung mit erhaltenem Spektrum), dessen
    Fehlurteilsrate am nächsten an 5 % und höchstens bei 6 % liegt.
  - Liegen beide über 6 %, gilt Phasen-Randomisierung mit α = 0,025.
  - Die Wahl steht im Bericht.

### 13.7 Anzeige: Reiter „Aktienmarkt“ und Szenario-Abfrage (ergänzt 6)

**Szenario-Abfrage** unter dem Fächer (13.4): Vorgaben als Knöpfe, Ergebnis mit Episoden-ESS, Methode (Bibliothek bzw. Kopula)
und dem unbedingten Intervall daneben.

**Reiter „Aktienmarkt“**, ausdrücklich beschreibend:

| Teil | Inhalt |
|---|---|
| **Gleichlauf** | Korrelation BTC (und je Coin) mit dem S&P 500 über 60, 120 und 260 Handelstage. BTC wird zum S&P-Schluss abgetastet: die 30-min-Kerze, die um 16:00 New Yorker Zeit endet. Dazu 90-%-Intervall aus dem Blockbootstrap, Beta nach unten und nach oben. |
| **Tafel „BTC fiel an x von n S&P-Verlusttagen“** | letzte 260 Handelstage und seit 2020 (U147, 13.12) |
| **Stress** | VIX, VIX/VIX3M, VVIX (Cboe, optional), Hochzinsspread (Archiv), Baa − 10 J, STLFSI4, NFCI, S&P- und Nasdaq-100-Abstand zum 252-Tage-Hoch |
| **Krypto-Aktien** | ETF-Flüsse (Farside mit Abrufzeit, Revisionen sichtbar), CME-Positionierung (CFTC TFF, Kontrakt 133741: Leveraged Funds, Asset Manager, OI), IBIT-Leerverkaufsquote (FINRA); Strategy (BTC-Bestand aus 8-K, eigene mNAV-Reihe mit MSTR-Kurs von `xyz`, STRC gegen Nennwert 100 USD rund um die Uhr, Netto-BTC der Woche) |
| **Struktur** | Kurse der Top 10 rund um die Uhr über `xyz` (Abstand zum Hoch, gleich gewichtet); Indexgewichte aus der SPY-Bestandsdatei, sofern abrufbar. Forward-KGV, KI-Capex und IPO-Hitze nur als Hinweis mit Quelle und Datum, nicht automatisch. |
| **Kennzeichnung** | Überall „beschreibend, nicht geprüft“; Intervalle statt Ampeln |

### 13.8 Daten und Betrieb (ergänzt 3 und 7)

**Neues Modul `hl_aktien.py` mit eigener Datei `aktien.db`, nur Archiv:**
- Jeder abgerufene Wert mit Abrufzeit, nie überschrieben; Revisionen werden neue Zeilen.
- Vor dem Schreiben Prüfung von Schema, Frische und „HTML statt CSV“.
- Je Quelle Backoff und Schutzschalter.
- Alle Jobs in New Yorker Zeit mit NYSE-Kalender 2026–2028; „kein neuer Schluss“ = Tag geschlossen, kein Fehler.

**Frei, ohne Zutun des Nutzers:**
- **FRED** (vorhandener Schlüssel):
  - `SP500` (ab 2016), `NASDAQ100`, `VIXCLS`, `VXVCLS`, `BAA10Y`, `STLFSI4`, `NFCI`;
  - `BAMLH0A0HYM2` nur drei Jahre sichtbar, daher **ab dem ersten Tag täglich ins Archiv**.
- **Deribit:** ETH-DVOL.
- **CFTC Public Reporting** (TFF `gpe5-46if`): Bitcoin 133741, dazu E-mini S&P und Nasdaq.
- **FINRA Reg SHO Daily:** IBIT, MSTR, COIN.
- **Farside:** wie bisher, jetzt mit Abrufzeit.
- **Cboe-CSV** (VIX9D, VVIX): einmal je Abend, optional, still bei Fehler.

**Entschieden am 11.10. 18:55 (13.11):**
- **Aktienkurse rund um die Uhr: Hyperliquid, HIP-3-Dex `xyz` (trade.xyz).**
  - Hinweis des Nutzers; keine bezahlte Quelle, kein Alpaca, kein yfinance.
  - Über dieselbe Info-API, die der Recorder schon für HIP-3 nutzt: `metaAndAssetCtxs` mit `"dex": "xyz"` für den Stand
    (Oracle-, Mark- und Mittelkurs), `candleSnapshot` mit `"coin": "xyz:SP500"` usw. für Kerzen.
  - Werte, laut trade.xyz-Übersicht zu prüfen:
    - Indizes: SP500 (lizenziert von S&P DJI, seit 18.03.2026), XYZ100 (Nasdaq-100), VIX;
    - die Top 10: NVDA, MSFT, AAPL, AMZN, GOOGL, META, AVGO, TSLA, LLY, MU;
    - Krypto-Aktien: MSTR, STRC, COIN, HOOD, CRCL;
    - Anleihen: TLT.
  - Rolle: aktuelle Werte alle 30 Minuten, auch nachts und am Wochenende; Barometer und Schockregel (13.1 c).
  - Die Historie reicht nur bis zur Listung (SP500 ab März 2026, die meisten Werte ab Mai 2026). Modell und Rückblick bleiben
    deshalb bei FRED.
  - Vorbehalt: Außerhalb der US-Handelszeit ist der Perp der Ort der Preisfindung; er kann vom Index abweichen (Bindung über
    Funding, dünnere Liquidität). Die Anzeige trägt dann „Perp-Stand, Börse geschlossen“.
  - Ein einzelner Wert, der fehlt, wird still übersprungen.
- **SEC EDGAR:** User-Agent `hl_liq_project admin@localhost.com` (Vorgabe des Nutzers), in einer Einstellung änderbar.
  Sperrt die SEC die Platzhalter-Adresse, fehlen nur die Strategy-Bestände mit Grund.
- **SoSoValue: nein.** Das ist ein Datendienst für ETF-Flüsse mit kostenlosem Schlüssel nach Anmeldung. Farside mit Abrufzeit
  und die eigene Rechnung aus den IBIT-Angaben (Anteile × BTC je Anteil) reichen.

Modell und Rückblick hängen von keiner dieser Quellen ab: A1–A4, X2–X4 und die S&P-Koordinate kommen aus FRED.

**Takt:**
- Archiv: abends nach 18:00 ET und morgens 13:00 UTC für FRED.
- CFTC samstags, FINRA abends.
- Prognose wie 13.1.

### 13.9 Prüfung (ergänzt 5 und 8)

**S4 Gemeinsame Form:**
- Die gemeinsame Bibliothek schlägt die unabhängige Paarung (S&P-Pfade über die Ursprünge gemischt) im Variogramm-Score
  (p = 0,5) auf den Vektoren (BTC, S&P) × (7, 14, 28 T), standardisiert, mit Blockbootstrap und beiden Hälften.
- Die bedingte Kalibrierung prüft die Rosenblatt-PIT u2 = F̂_{B|S}(b | s) über alle 00-UTC-Ursprünge:
  - gleichverteilt insgesamt und unter Aktienstress (u1 < 0,2), mit Rohmomenten-Test nach Knüppel 2015;
  - Deckung je Aktienzustand.
- Die bedingten Szenarien erscheinen immer, aber mit dem Stand von S4: „Abhängigkeit im Rückblick belegt / nicht belegt“.

**Synthetische Proben (Selbsttest):**
- Gemeinsame Bibliothek auf einem bekannten Prozess (HAR-artige Schwankung, t-Kopula ρ = 0,4, ν = 5, 10⁴ Fenster):
  - bedingte Quantile bei s* = −2σ und −2,5σ stimmen mit der wahren bedingten Verteilung im Stichprobenfehler;
  - Episoden-ESS stimmt mit der Rechnung von Hand;
  - der Kopula-Rückfall findet ρ und ν wieder;
  - die unabhängige Paarung verliert im Variogramm-Score.
- Null-Universen mit zähen Aktienkandidaten (13.6).
- Positivkontrolle für X1 (eingepflanzter Gewinn durch implizite Volatilität).
- Kausalitätsprobe für die US-Reihen (Wert für d erst ab d+1 14:00 UTC).
- Schockregel: Eine eingepflanzte 30-min-Bewegung löst genau einmal aus, und der Fächer für 7 Tage wird breiter.
- Mutationen dazu: S&P-Trend nicht abgezogen, Episoden-ESS aus Fenstern statt Episoden, Kern ohne Korrektur, Kausalität ohne
  Verzug, Wochenenden des S&P mit Nullrenditen gefüllt.

### 13.10 Erwartung vorab (ergänzt 10)

- **Breite:** X1 (DVOL) trägt bei BTC und ETH ab 7 Tagen; X2–X4 bestehen insgesamt vermutlich nicht, gewinnen aber im obersten
  VIX-Drittel.
- **Richtung:** A1–A4 tragen nicht. Aktien-R² über 1–4 Wochen höchstens rund 2 %, durchgereicht ρ² · R² ≈ 0,3 %, weit unter der
  Nachweisgrenze.
- **Bedingte Szenarien:**
  - Bei ruhigem Markt ist „S&P −10 % in 4 Wochen“ ein Ereignis von etwa −2,4σ; die Episoden-ESS liegt meist unter 15, also gilt
    der Kopula-Rückfall.
  - Bei Stress sind es etwa −1,3σ, und die Bibliothek trägt.
  - Die Antwort hängt in ruhigen Zeiten fast allein an der Abhängigkeit (Recherche: bei ρ = 0,4 BTC 80 % zwischen −24 % und +3 %,
    bei ρ = 0,7 zwischen −29 % und −9 %).
- **S4:** Die gemeinsame Bibliothek schlägt die unabhängige Paarung vermutlich, aber knapp (rund 70 unabhängige 28-Tage-Fenster).

### 13.11 Entscheidungen beim Nutzer (ergänzt 11)

4. **Quelle für Aktien- und ETF-Kurse** — *entschieden 18:55:* Hyperliquid HIP-3 `xyz` rund um die Uhr (Hinweis des Nutzers),
   Historie aus FRED, keine bezahlte Quelle (13.8).
5. **SEC-Kontakt für Strategy-Meldungen** — *entschieden 18:55:* `admin@localhost.com`, änderbar (13.8).
6. **SoSoValue** — *entschieden 18:55 (vom Nutzer an mich übergeben):* nein (13.8).
7. **Stressfächer auch mit der Größe der Stressphase?** (13.10.2026, nach dem ersten Rückblick, 12.2 Punkt 3) Heute zeigt er die
   Form jener Zeit bei heutiger Breite. Ein zweiter Fächer mit der Schwankung von damals zeigte, wie weit es in einer solchen Phase
   gehen kann; er wäre aber kein Modell für heute, sondern ein Szenario. Standard: nein, wie gebaut.
   *Entschieden 13.10.2026 (Nutzer, Auswahl):* **ja, zusätzlich** — festgelegt in 13.14, Bau mit 23.68.

### 13.12 Studie U147: Fällt BTC, wenn der S&P 500 fällt?

Vorab festgelegt; prüft die Überzeugung des Nutzers.
- **Daten:**
  - S&P-Schlusskurse (FRED `SP500`, ab 2016-10).
  - BTC, ETH, ZEC, XMR, HYPE zum S&P-Schluss abgetastet: die 30-min-Kerze, die um 16:00 New Yorker Zeit endet, aus `swing.db`
    ab 2020.
  - Wochen und 4 Wochen zusätzlich ab 2016 mit dem Tagesschluss 00:00 UTC (Versatz von 3–4 h, auf Wochen unerheblich).
- **Zeiträume:**
  - Tag: S&P-Handelstag, BTC über dasselbe Intervall einschließlich Wochenende vor Montag.
  - Woche: Freitag bis Freitag.
  - 4 Wochen: 20 Handelstage, nicht überlappend.
- **Bedingungen:**
  - Tag: S&P < 0, < −1 %, < −2 %, < −3 %.
  - Woche: < 0, < −3 %, < −5 %.
  - 4 Wochen: < 0, < −5 %, < −10 %.
  - Spiegelbildlich nach oben für die Asymmetrie.
- **Je Bedingung:**
  - Anteil „BTC fiel“ mit Wilson-95-%-Intervall, mittlere und mittlere-Median-Rendite;
  - Beta in der Bedingung;
  - Erwartung unter der Normalverteilung mit dem gemessenen ρ (½ + arcsin(ρ)/π für < 0, Schwellen per Rechnung).
- **Je Zeitraum:** 2020–2022 und 2023–2026 getrennt.
- **Vorlauf** (vier Tests, Holm, HAC-Standardfehler):
  - S&P-Tag → BTC in den folgenden 24 h ab 16:00 ET;
  - BTC außerhalb der US-Handelszeit → S&P am Folgetag;
  - S&P-Woche → BTC-Folgewoche;
  - BTC-Woche → S&P-Folgewoche.
- **Urteil über „immer“:** bestätigt nur bei 100 % in allen Bedingungen. Berichtet wird, wie nah die großen Rückgänge herankommen.
  Die laufende Tafel steht im Reiter „Aktienmarkt“.
- **Erwartung vorab:**
  - Tag < 0: etwa zwei Drittel;
  - unter −1 %: etwa 85–90 %;
  - unter −2 %: nahe 100 % bei wenigen Tagen;
  - Vorlauf S&P → BTC nicht belegt, BTC → S&P (Wochenende) eher.
- **Ergebnis (Lauf 12.10.2026 21:30, S&P-Handelstage bis 09.10.2026):** „immer“ **nicht bestätigt**.
  - BTC seit 2020, Tag: S&P < 0 → fiel 502 von 781 = 64 % (Wilson 61–68 %, unter der Normalverteilung erwartet 62 %);
    < −1 % → 172 von 224 = 77 % (71–82 %, erwartet 70 %); < −2 % → 56 von 67 = 84 % (73–91 %, erwartet 79 %);
    < −3 % → 23 von 28 = 82 % (64–92 %).
  - Am nächsten an „immer“: 4 Wochen mit S&P < −5 % → 9 von 9 (70–100 %, erwartet 83 %).
  - In den letzten 260 Handelstagen (Reiter „Aktienmarkt“, 12.10.): unter −1 % 25 von 25 — der Gleichlauf schwankt stark über
    die Zeit.
  - Vorlauf (Holm über 4): S&P-Tag → BTC nicht belegt (p Holm 0,795); BTC über Nacht → S&P am selben Handelstag belegt
    (b 0,113, t 4,49, p Holm < 0,001) — gemeinsame Information der Nacht (die S&P-Futures handeln mit), kein Beleg, dass BTC
    führt; Wochen beide nicht belegt.
  - **Eigene Fehleinschätzung:** Für −1 % und −2 % hatte ich 85–90 % bzw. fast 100 % erwartet; gemessen sind 77 und 84 %.
    Ich hatte aus dem jüngsten Jahr (88 % unter −1 %, 3χχ) auf alle Jahre geschlossen.

### 13.13 Kurzstudie: ETF-Flüsse und ETF-Leerverkäufe über 7 Tage

- **Kandidaten:**
  - K1: Nettofluss der Spot-ETF über 20 Handelstage in BTC ÷ ETF-Bestand;
  - K2: IBIT-Leerverkaufsquote (Volumen Reg SHO ÷ Gesamtvolumen) über 5 Handelstage.
- **Ziel:** normierte BTC-Rendite der folgenden 7 Tage.
- **Zeitraum:** ab 2024-04-01 (60 Tage nach dem ETF-Start), geteilt in zwei Hälften am mittleren Datum.
- **Test:**
  - Spearman ρ, Null per Phasen-Randomisierung (13.6), Holm über 2.
  - „Belegt“ nur bei p Holm < 0,05 und gleichem Vorzeichen in beiden Hälften.
- **Nachweisgrenze:** Bei rund 120 unabhängigen Wochen ist erst |ρ| ab etwa 0,25 nachweisbar. Die Erwartung ist „nicht belegt“;
  ETF-Flüsse laufen laut Recherche mit dem Kurs, nicht voraus.
- **Ergebnis (Lauf 12.10.2026 21:30, n 631, 01.04.2024–05.10.2026):** beide **nicht belegt**, wie erwartet. K1 ρ 0,026, p 0,785,
  p Holm 1,000, Hälften −0,031/0,038; K2 ρ 0,025, p 0,787, p Holm 1,000, Hälften 0,024/0,044.

### 13.14 Stressfächer in der Größe der unruhigsten Phase (U156) — entschieden 13.10.2026, festgelegt vor dem Bau

**Anlass.** Der Stressfächer aus 13.4 zeigt die *Form* der Wege aus der unruhigsten Phase seit 2020, aber mit der *heutigen*
Breite (12.2 Punkt 3). Der Nutzer will zusätzlich sehen, wie weit es damals wirklich ging (Auswahl 13.10.: „Ja, zusätzlich“).

**Konstruktion:**
- **Fenster:** dieselben wie beim Stressfächer — Start im Zeitraum aus 13.4 (365 Tage seit 2020 mit dem höchsten mittleren ln VIX,
  heute 24.02.2020–23.02.2021), vor τ vollständig realisiert, gleiche Gewichte.
- **Nur eigene Fenster des Coins**, mindestens 100 in der Phase. Damit zeigen ihn BTC, ETH, ZEC und XMR.
  - HYPE hat in der Phase keine eigene Geschichte; seine gepoolte Bibliothek bestünde dort nur aus anderen Coins. Er bekommt den
    Hinweis „keine eigene Geschichte in dieser Phase“.
  - PAXG hat keine Szenarien mit dem Aktienmarkt (13.3) und bekommt auch diesen Fächer nicht.
- **Weg je Fenster:** der tatsächliche Weg R(j,k) = ln C(j+k) − ln C(j) für k = 1 … 28, ebenso Hoch und Tief der Tagesblöcke.
  - Keine Normierung auf die damalige Prognose und keine heutige Breite.
  - Abgezogen wird das Mittel über die Fenster je k, also der Trend der Phase (BTC stieg in diesem Jahr etwa auf das Fünffache).
    Der Fächer ist damit driftfrei wie der Grundfächer.
- **Quantile** 5/10/25/50/75/90/95 % je Tag, angesetzt am heutigen Startpreis.

**Anzeige:**
- Reiter „Spannen“: eigene Tabelle mit 80 und 90 % bei 7, 14 und 28 Tagen.
- Bild: zweite Klammern (gepunktet) neben denen des Stressfächers.
- Text: eigene Zeile.
- Dazu das Verhältnis der Breite (80 %, in Log-Rendite) zur heutigen bei 28 Tagen: „damals x-mal so breit wie heute“.
- **Beschriftung:** „Szenario: so weit gingen die Wege in der unruhigsten Phase seit 2020 (…–…), ohne deren Trend — kein Modell für
  heute“.

**Wirkung:** keine. Nicht im Rückblick, nicht in der Vorwärtsbilanz, nicht in S1–S4, nicht in Ziellevels oder Szenarien.

**Proben (für den Bau festgelegt, je mit Mutation):**
- Von Hand: Auf einer kleinen Bibliothek sind die Quantile die von R minus dem Mittel je Tag.
- Synthetischer Markt mit doppelter Schwankung und starkem Trend in der Stressphase: Der neue Fächer ist bei 28 Tagen etwa doppelt
  so breit wie der Formfächer bei normaler heutiger Schwankung (auf 10 % genau), sein Median liegt bei null (Trend abgezogen).
- HYPE ohne eigene Fenster in der Phase: Hinweis statt Fächer. Ein Coin mit weniger als 100 eigenen Fenstern ebenso.
- Kausalität: nur vor τ vollständig realisierte Fenster.
- Browserprobe: die gepunkteten Klammern an der beschrifteten Achse gegen die Nutzlast; Text und Tabelle.
- Mutationen: Trend nicht abgezogen, mit heutiger Breite statt der damaligen, ohne Prüfung auf eigene Fenster, 80 und 90 %
  vertauscht, die beiden Klammerpaare vertauscht.

**Erwartung vorab:** deutlich breiter als der heutige Fächer — bei BTC grob das Doppelte, weil die Schwankung heute niedrig ist.

**Stand 17.10.2026: gebaut mit 23.68** (`hl_ausblick.stress_groesse`, Text `stress_groesse_zeile`, Seite `auStressGroesse` und gepunktete
Klammern; Nutzlast `prognose.stress_groesse`).
- **Abweichung vom Wortlaut, begründet:** Hoch und Tief der Tagesblöcke werden nicht mitgeführt. Der Fächer zeigt nur Spannen des
  Schlusses, keine Erreich-Wahrscheinlichkeiten, und wirkt nicht auf Ziellevels; die Werte hätten keinen Leser.
- **Hinweis bei weniger als 100 eigenen Fenstern:** „nur n eigene Fenster in dieser Phase (nötig 100)“; ohne eigene Fenster „keine eigene
  Geschichte in dieser Phase“ (HYPE, obwohl seine gepoolte Bibliothek Fenster der Phase hat).
- **Proben** (Selbsttest-Gruppe „stress“, 33 s):
  - von Hand auf 487 Fenstern (Abweichung 7·10⁻¹⁶);
  - Hinweise bei 0 und 99 Fenstern, Fächer ab 100;
  - Kausalität bei τ mitten in der Phase (229 von 487 Fenstern; spätere Kurse ×10 ändern nichts);
  - synthetische Märkte: doppelte Schwankung und Trend Faktor 5 im Jahr in der Phase. Pro Markt streut das Verhältnis stark (SD ≈ 0,3),
    weil 365 Tage nur etwa 13 unabhängige 28-Tage-Wege haben. Deshalb 60 Märkte zu je 8 Jahren, mit folgenden Mitteln:
    - Verhältnis zum Grundfächer 1,93 (SE 0,04), Soll 2 ± 10 %;
    - eigene Größe 0,98 von 2·1,28·2σ√28;
    - Median +0,002 bei einem Trend von 0,12;
    - der Stressfächer der Form liegt bei 1,10 der heutigen Breite.
  - Ende zu Ende auf der Demo, mit einem Stresszeitraum im Bereich der Bibliothek: BTC, ETH, ZEC und XMR mit je 1.460 eigenen Fenstern;
    HYPE mit Hinweis; PAXG ohne. Dazu die Kausalität des ganzen Laufs und „Wirkung keine“: ohne Stresszeitraum bleiben alle übrigen
    Felder gleich.
  - Browserprobe 166 von 166; Mutationen 8 von 8 (Python) und 8 von 8 (Browser) rot.
- **Eigener Fehler, mit 23.68 behoben:** Seit 23.66 lag die gestrichelte Klammer des Stressfächers bei +4 Wochen außerhalb des
  Zeichenbereichs. Rechts der Marke blieben nur 0,6 Tage Platz, auf dem Handy rund 1,5 px. Die Klammer war damit praktisch nie zu
  sehen (gemessen am 23.67-Skript: Handy 0 px, Desktop 6 M 1,4 px, 12 M 0 px). Jetzt bleiben rechts der Marke 16 px frei; die
  Browserprobe prüft, dass jede Klammer ganz im Zeichenbereich liegt.
- **Eigener Fehler der Probe:** Die Textprobe des Stressfächers lief nie, weil die Demo keinen Stresszeitraum mit Fenstern hatte
  („in den Demodaten nicht berechnet“). Seit 23.68 legt die Ende-zu-Ende-Probe den Zeitraum in die Bibliothek.

### 13.15 Zweitläufe vom 13.10. und ein Befund zu den ETF-Flüssen (U165) — 13.10.2026 abends

**Zweitläufe** (Sammeldatei 13.10. 22:07, Pi noch mit 23.66): Ausblick und Aktienmarkt 08:30, U147 und K1/K2 21:30. Kein Urteil ändert
sich.
- **U147** mit einem S&P-Handelstag mehr (12.10.: S&P leicht im Minus, BTC nicht): BTC seit 2020, Tag, S&P < 0 → 502 von 782 = 64 %
  (61–67 %). Alle übrigen Zählungen, der Vorlauf und das Urteil („immer“ nicht bestätigt) sind gleich.
- **K1/K2** (n 632 bis 06.10.): K1 ρ 0,026, p 0,797; K2 ρ 0,024, p 0,779; beide nicht belegt, wie am 12.10.
- **Ausblick:** Der Rückblick ist noch der vom 12.10. 01:00 UTC; er läuft wöchentlich sonntags, der nächste am 18.10. Die Fächer
  zeigen dasselbe Bild wie am 12.10. (BTC 28 T 80 % 72.008–98.153, Stressfächer der Form 74.591–93.938).
- Die Befunde F1 (SEC-Fehlerzeile mit Zeilenumbruch), F2 (Aktienzahl, HTTP 404), F3 (VIX bei `xyz` steht auf 20,00) und F5
  (fehlende Textabschnitte) sind auf dem Pi noch zu sehen, weil dort 23.66 läuft. Behoben sind sie in 23.67.

**Befund: Der jüngste Farside-Tag kann unvollständig sein.**
- Der Abruf vom 13.10. 03:00 enthielt den 12.10. ohne IBIT und HODL (beide nur bis 09.10.); alle übrigen Fonds und „Total“ reichen
  bis 12.10. Die Tagessumme des 12.10. ist damit vermutlich zu klein, denn IBIT ist der größte Fonds.
- Das Archiv speichert eine spätere Vervollständigung als neue Fassung. **Nachprüfung mit Datum:** im Aktienmarkt-Bericht vom
  18.10. 08:30 muss IBIT einen Wert für den 12.10. haben und `farside:btc:Total` mindestens eine Revision zeigen.
- K1 ist nicht betroffen, denn seine Tage liegen mindestens 7 Tage zurück. Betroffen ist die Anzeige der letzten Tage (Abschnitt
  „Krypto-Aktien“ ab 23.67 und Reiter „Aktienmarkt“), die Summen über 5 und 20 Tage eingeschlossen.

**U165 (mit 23.68, nur Anzeige; vorab festgelegt):**
- Ein Tag gilt als **unvollständig**, wenn ein Fonds, der am vorigen Handelstag eine Zahl hatte, an diesem Tag keine hat („-“).
  Geprüft werden die letzten 3 Handelstage. Fehlt ein Fonds länger, gilt er als eingestellt und bekommt einen eigenen Hinweis.
- Anzeige in Text und Reiter: „unvollständig (fehlt: IBIT, HODL)“. Die Summen über 5 und 20 Tage zählen nur vollständige Tage und
  sagen, wie viele es sind.
- Dazu eine Zählung: an wie vielen der letzten 20 Abrufe der jüngste Tag unvollständig war. Danach entscheidet sich, ob ein zweiter
  Abruf am Tag nötig ist; heute ist nur der eine um 03:00 geplant.
- **Wirkung:** keine auf K1, den Ausblick oder irgendeinen Treiber.
- **Proben:**
  - Tabelle mit „-“ bei IBIT am letzten Tag: Der Tag wird markiert und fällt aus den Summen.
  - Der nächste Abruf bringt die Zahl: Die Markierung verschwindet, „Total“ bekommt eine neue Fassung.
  - Ein seit vier Tagen fehlender Fonds wird als eingestellt gemeldet und markiert den Tag nicht mehr.
  - Mutation („-“ als 0 gelesen) wird rot.

**Stand 17.10.2026: gebaut mit 23.68** (`hl_aktien.etf_vollstaendigkeit`, `etf_summen`, Zählung je Abruf in `ak_meta`
„farside_vollstaendig“; Text und Reiter „Aktienmarkt“).
- Ein Fonds mit früheren Zahlen, aber ohne Zahl an einem der letzten 3 Handelstage, markiert den Tag als unvollständig. Fehlen bei
  einem Fonds zwei Tage in Folge, werden beide markiert; die wörtliche Regel „Zahl am Vortag“ hätte nur den ersten erfasst.
- Ohne Zahl an den letzten 4 Tagen gilt der Fonds als eingestellt; dann wird kein Tag markiert, und er bekommt einen eigenen Hinweis.
- Proben grün, Mutationen 3 von 3 rot. Die Nachprüfung im Bericht vom 18.10. 08:30 bleibt (IBIT für den 12.10., Total mit Revision).

### 13.16 Zweite Quelle für ETF-Bestände: CryptoQuant (U175) — entschieden 17.10.2026, festgelegt vor dem Bau

**Anlass.** Frage des Nutzers (17.10. 15:44): „Welche sonstigen Daten könnte man bei CryptoQuant abrufen kostenlos, die wirklich
nützlich wären?“ Der freie Plan „Basic“ gibt nur Marktdaten heraus: Tageswerte, 30 Tage Rückschau, Lizenz „Personal“, 10.000 Credits
im Monat (docs.cryptoquant.com, „Plans & Limits“ und „API Credits“, 17.10. gelesen). Das meiste davon hat das System schon feiner.
Neu wären vor allem die **Bestände der Bitcoin-ETF je Fonds**. Wahl des Nutzers: „ETF-Bestände nach dem 19.10. (Vorschlag)“.

**Daten:**
- Endpunkt `btc/fund-data/digital-asset-holdings` je Fonds. Die Doku führt die Symbole `ibit`, `fbtc`, `bitb`, `arkb`, `btco`,
  `hodl`, `ezbc`, `btcw`, `brrr`, `gbtc` und `btc` (Grayscale Mini Trust), dazu `btcc_u` (Purpose, Kanada), `btce` (ETC Group) und
  `all_symbol`.
- Abgerufen werden nur die US-Fonds, die auch Farside führt. `all_symbol` enthält Fonds außerhalb der USA und passt deshalb nicht zur
  Farside-Summe.
- Feldnamen, Einheit (laut Doku BTC) und Uhrzeit der Aktualisierung prüft der erste Abruf.

**Bedingung für den Bau:**
- Der Bericht vom 19.10. 20:15 (U158) zeigt, dass der freie Schlüssel Marktdaten bekommt.
- Der Credit-Verbrauch eines Abrufs ist bekannt (Bericht oder CryptoQuant-Konto, Settings → API). Die Doku sagt nur: „The more data
  you receive, the more credits are deducted.“ Ohne Credits antwortet die API mit 402; Basic kann keine Credits nachkaufen.

**Abruf und Speicher:**
- Gleicher Schlüssel, gleicher Takt und gleiche Pausen wie U158 (einmal am Tag nach 01:00 UTC; der Schlüssel steht in keinem Text).
- **U158 hat Vorrang:** Die ETF-Abrufe laufen erst, wenn der U158-Abruf des Tages fertig ist, und nur, solange der hochgerechnete
  Monatsverbrauch unter 7.000 Credits bleibt. Sonst pausieren sie bis zum Monatswechsel; der Bericht nennt es.
- Rückschau beim ersten Abruf 30 Tage, danach 7 Tage. Spätere Änderungen werden so als neue Fassungen sichtbar.
- Speicher in `hebel.db`, Tabelle `hb_cq` (Reihen `fund:<symbol>`), mit Abrufzeit; ein gleicher Wert gibt keine neue Zeile.

**Gegenprobe zu Farside (beschreibend, kein Urteil):**
- Je Fonds und US-Handelstag d: Fluss nach CryptoQuant = Bestand(d) − Bestand(Vortag) in BTC. Fluss nach Farside = Mio. USD ÷ BTC-Kurs
  zum US-Schluss (16:00 New York, wie U147).
- Ausgewiesen je Fonds und für die Summe: Zahl der Tage mit beiden Werten, mittlere absolute Abweichung in BTC, Anteil der Tage mit
  Abweichung ≤ 5 % (bei kleinen Flüssen ≤ 50 BTC), Tage mit entgegengesetztem Vorzeichen.
- Eigens gezählt: Tage, die Farside als unvollständig markiert (U165), an denen CryptoQuant einen Wert hat.
- Anzeige zuerst nur im Bericht „Aktienmarkt“ (Debug). Ob der Reiter „Aktienmarkt“ die zweite Quelle zeigt, entscheidet der Nutzer
  nach den ersten Wochen.

**Wirkung:** keine. Nicht auf K1 (13.13), den Ausblick, Konfluenz, Labor, Prognose oder Treiber.

**Proben (für den Bau festgelegt, je mit Mutation):**
- Parser gegen eine Attrappe der dokumentierten Antwort; „kein Wert“ fällt weg.
- Archiv mit Fassungen; 7-Tage-Rückschau füllt eine Lücke.
- Vorrang von U158 und Credit-Schwelle: Steht U158 aus oder ist die Schwelle erreicht, gibt es keinen ETF-Abruf.
- Gegenprobe von Hand (drei Fonds, ein fehlender Tag, ein Tag mit entgegengesetztem Vorzeichen).
- Der Schlüssel steht in keinem Text.

**Erwartung vorab:** Bei IBIT und FBTC stimmen beide Quellen an den meisten Tagen innerhalb weniger Prozent. Abweichungen erwarte ich
an Tagen mit später Meldung (wie IBIT am 12.10.) und bei kleinen Fonds. Wie früh CryptoQuant einen Handelstag zeigt, ist offen.

### 13.17 Nachträge vom 18.10.2026: Nachprüfung U165, Zeitraum der Stressfächer (U178), Strategy-Bestand (U177)

**Nachprüfung U165 ✓** (Aktienmarkt-Bericht 18.10. 08:30): IBIT hat jetzt einen Wert für den 12.10. (694 Tage wie die übrigen großen
Fonds), `farside:btc:Total` hat 9 Fassungen. Seit dem 17.10. war der jüngste Tag in 1 von 3 Abrufen unvollständig.

**Zeitraum der Stressfächer (U178), eigener Fehler aus 23.66 und 23.68:**
- Auf dem Pi beginnt die Bibliothek erst am 01.10.2020. Das HAR braucht 800 Anker (rund 200 Tage) mit abgeschlossenem Ziel, und die
  Kerzen beginnen am 01.01.2020.
- Von der Phase aus 13.4 (24.02.2020–23.02.2021) zählen deshalb nur Fenster ab Oktober 2020: BTC und ETH 580 von 1.460 möglichen, ZEC
  und XMR 456. Der März 2020 fehlt im Formfächer (13.4) und im Größenfächer (13.14).
- Die Beschriftung nennt bisher die ganze Phase. Die Ende-zu-Ende-Probe legte die Phase in die Bibliothek und konnte die Lücke nicht zeigen.
- **Entschieden 18.10. (Nutzer, Auswahl „Beschriftung berichtigen (Vorschlag)“), Bau mit dem nächsten Paket nach dem 19.10.:**
  - Text, Dashboard und Tabelle nennen den tatsächlichen Zeitraum der Fenster (erstes bis letztes Startdatum) und die Zahl von
    möglichen.
  - Beginnen die Fenster später als die Phase, steht dabei „März 2020 nicht enthalten“ (allgemein: der fehlende Anfang der Phase).
  - Fenster, Phase und Rechnung bleiben, wie in 13.4 und 13.14 festgelegt. Eine neue Festlegung (alle Fenster für den Größenfächer oder
    eine Phase innerhalb der Bibliothek) hat der Nutzer nicht gewählt.
  - Proben: Zeitraum gleich erstem und letztem Fenster; Hinweis nur bei spätem Beginn; Browserprobe; Mutation „Phase statt Fenster
    genannt“ rot.

**Strategy-Bestand (U177), eigener Fehler aus 23.66:**
- Der Aktienmarkt-Bericht zeigt „zuletzt +846.001 BTC“ bei einem Bestand von 847.666. Der Wert davor in `sec:mstr_btc` ist falsch
  gelesen (1.665).
- Vermutete Ursache: Das Suchmuster für die Tabelle „Aggregate BTC Holdings“ nimmt die erste große Zahl danach; in einem 8-K ohne
  Fließtext sind das die gekauften BTC oder der Durchschnittspreis.
- Behebung mit dem nächsten Paket: In der Tabelle zählt die größte Zahl ohne „$“ davor; ein Wert, der mehr als 30 % vom benachbarten
  Bestand abweicht, gilt als unplausibel und wird nicht archiviert; 8-K mit unplausiblem Wert werden einmal neu gelesen.
- Probe mit einem Tabellen-8-K; Mutationen (altes Muster, ohne Plausibilität) müssen rot werden.
- Wirkung: keine. Der Bestand speist nur den Bericht und den Reiter „Aktienmarkt“.

### 13.18 Ausnahmelage durch den S&P-500-Perp (Regel c, U179) — Befund 19.10.2026, entschieden und festgelegt vor dem Bau

**Anlass.** Frage des Nutzers (19.10. 16:52, mit Bildschirmfoto des Ausblicks BTC, Anker 19.10. 14:30 UTC): Die Meldung
„Ausnahmelage seit 19.10. 02:39 UTC: S&P-500-Perp in 6 h +1,2 % (Börse geschlossen, Perp-Stand) -- die Spanne ist sofort breiter
gerechnet (24 h)“ steht, obwohl die US-Börse seit 13:30 UTC offen ist. „Wird es korrekt getracked?“

**Befund:**
- **Auslösung richtig.** 02:39 UTC war Sonntag 22:39 in New York, die Börse war zu. `hl_aktien.boerse_offen` nachgerechnet: 02:39 UTC
  geschlossen, 13:29 geschlossen, 13:30 offen, 14:50 offen, 20:00 geschlossen (Sommerzeit, Feiertage).
- **Bewegung echt.** Die S&P-Futures stiegen nach ihrem Start am Sonntag um 18:00 New York um 0,72 % auf 7.760 (Benzinga, 19.10. 00:46
  New York). Freitagsschluss 7.659,44. Der Perp lag am Wochenende bei 7.630,30 (Bericht 18.10. 08:30), 0,4 % darunter. Zusammen rund
  +1,1 %, gemeldet +1,2 %.
- Der Hinweis steht wie in 13.1 festgelegt 24 h, hier bis 20.10. 02:39 UTC. Die Zahlen des Ausblicks betrifft er nicht.
- **Eigene Fehler aus 23.66:**
  1. Der Zusatz „Börse geschlossen, Perp-Stand“ wird bei der Auslösung in den Text geschrieben und danach nicht angepasst; ein Ende
     steht nirgends. Nach Börsenbeginn liest er sich wie eine falsche Aussage über jetzt.
  2. „Die Spanne ist sofort breiter gerechnet“ gilt nur für (a) und (b). Bei (c) löst die S&P-Bewegung nur eine Neuberechnung aus. Die
     BTC-Spanne kommt aus der eigenen Schwankung (Grundmodell; der Rückblick vom 18.10. verwarf X1–X4 für alle Horizonte), der Perp
     geht nirgends ein. Nebenbefund: `G["xyz_sp"]` wird geladen, aber nirgends benutzt.
  3. Regel (c) ist ungeprüft. Der Selbsttest pflanzt nur eine 30-min-Bewegung von BTC ein (Regel a).
- **Offen, ungemessen:** die Kalibrierung von (c). Die Schwelle 3 · √(F_S · 6/24) verteilt die Varianz eines Handelstags gleichmäßig
  auf 24 h; das sind 1,5 Tages-σ. Beim S&P fällt der größte Teil in die Handelszeit und nachts wenig; am Sonntagabend kommt die
  Wochenendlücke dazu, samt dem Abdriften des Perps am Wochenende. Erwartung (Hypothese): in der Handelszeit zu häufig, nachts fast
  nie.

**Entschieden 19.10. (Nutzer, Auswahl „Text + Zählung (Vorschlag)“), Bau mit 23.69:**
- **(1) Text** in Dashboard, Lesart und Bericht:
  - „Ausnahmelage seit 19.10. 02:39 UTC, bis 20.10. 02:39 UTC: …“.
  - Regel (c): „S&P-500-Perp in 6 h +1,2 % (bei Auslösung Börse geschlossen, Perp-Stand) -- nur ein Hinweis: Die Spanne rechnet mit
    der eigenen Schwankung des Coins, die S&P-Bewegung geht nicht ein.“
  - Regeln (a) und (b): wie bisher „die Spanne ist sofort breiter gerechnet“.
  - Gespeichert werden Regel, Bewegung, Schwelle und Börsenstand bei Auslösung als eigene Felder; der Text entsteht erst bei der
    Anzeige. Alte Einträge aus 23.68 (nur `grund`) erkennt die Anzeige an der Regel „c“ und schreibt sie ebenso.
- **(2) Probe für (c)** im Selbsttest (Gruppe „schock“):
  - eingepflanzte Perp-Bewegung von 1,6 × Schwelle, einmal am Sonntagabend und einmal an einem Werktag in der Handelszeit;
  - löst je Coin genau einmal aus, PAXG nie;
  - „bei Auslösung Börse geschlossen“ steht nur beim Sonntag;
  - F von BTC vor und nach der Auslösung gleich (Verhältnis 1 auf 10⁻⁹); im Text von (c) kein „breiter“;
  - Ende = Beginn + 24 h.
  - Mutationen: Börsenstand von jetzt statt von der Auslösung; „breiter“ auch bei (c); PAXG nicht ausgenommen; Schwelle ohne
    √(6/24); ohne 24-h-Sperre.
- **(3) Zählung** (Debug-Bericht, beschreibend; festgelegt, bevor ein Perp-Wert dafür angesehen ist):
  - Daten: `xyz:SP500:30m` aus `aktien.db` ab 12.08.2026; F_S je Zeitpunkt aus `sp_breite`, nur Werte mit Verfügbarkeit bis zu diesem
    Zeitpunkt.
  - Prüfzeitpunkte: jedes Ende einer 30-min-Kerze. Die echte Prüfung läuft alle 5 min; die Zählung im 30-min-Raster ist eine Näherung.
  - 6-h-Bewegung wie in `schock_pruefen` (Schluss gegen Schluss der Kerze 6 h davor).
  - Fensterarten, Vorrang in dieser Reihenfolge:
    - „Sonntagsstart“: enthält Sonntag 18:00 New York;
    - „Wochenende“: ganz zwischen Freitag 16:00 und Sonntag 18:00 New York;
    - „Handelszeit“: mindestens 3 der 6 h in 9:30–16:00 New York an einem Handelstag;
    - „außerhalb“: der Rest, Feiertage eingeschlossen.
  - Je Fensterart:
    - Zahl der Prüfzeitpunkte;
    - Varianzverhältnis Q = Mittel(r₆²) ÷ Mittel(F_S · 6/24), mit 90-%-Intervall aus dem Blockbootstrap über Kalendertage (2.000
      Ziehungen);
    - Anteil über der Schwelle mit 95-%-Intervall (Wilson); zum Vergleich die Bauart „3 σ“ (0,27 % bei Normalverteilung).
  - Auslösungen nach der Regel mit 24-h-Sperre: Zahl je Fensterart und Liste mit Zeit, Bewegung und Schwelle.
  - Tatsächliche Auslösungen seit 23.66 aus `au_prognose` (verschiedene Beginnzeiten je Regel) als Liste.
  - Probe: synthetischer Perp mit bekanntem Tagesprofil (Handelszeit dreifache Varianz) → Q je Art auf ±10 % getroffen; ohne Profil
    Q ≈ 1 in allen Arten. Mutationen: Einteilung nach dem Fensterende statt nach dem Anteil; F_S aus der Zukunft; ohne Sperre.
- **(4) Schwelle:** Sie bleibt, bis der Nutzer nach der Zählung entscheidet. Eine neue Schwelle (etwa 3 · √(Q_Art · F_S · 6/24)) wird
  vorher festgelegt und frühestens nach dem 25.10. gebaut.
- **Wirkung:** keine. Die Ausnahmelage schreibt nur in `ausblick.db`; die Spannen bleiben, wie sie sind.

### 13.19 Bau 23.69 (19.10.2026 abends): U177, U178, U179 — Stand nach dem Bau

**U178 Zeitraum der Stressfächer (13.17), gebaut wie entschieden:**
- Beide Stress-Nutzlasten tragen ein Feld `fenster` (`stress_fenster`): Phase, Start des ersten und des letzten Fensters, Zahl,
  mögliche (je Coin der Bibliothek ein Fenster je 6-h-Anker der Phase: 1.460; gepoolt mal Zahl der Coins) und der Hinweis.
- Text (Bericht), Dashboard-Überschriften und Tabelle: „Phase 24.02.2020–23.02.2021; Fenster mit Start 01.10.2020–22.02.2021, 580 von
  1.460 möglichen; März 2020 nicht enthalten“. Der Hinweis steht nur, wenn die Fenster mehr als 7 Tage nach Beginn der Phase anfangen:
  „März 2020 nicht enthalten“ (Lücke über den ganzen März), „März 2020 nur zum Teil enthalten“, sonst „Beginn der Phase bis …
  nicht enthalten“. Fenster und Rechnung unverändert.
- Proben (Gruppe „basis“ und „stress“): Zeitraum = erstes und letztes Fenster, 580 von 1.460, Hinweis nur bei spätem Beginn, zwei
  Coins 2.920; Browserprobe des Ausblicks. Mutationen „Phase statt Fenster“ (Python und Seite), „Hinweis immer“, „Größe ohne
  Fenster“ rot.

**U179 Regel (c) (13.18), gebaut wie entschieden:**
- (1) Gespeichert werden `regel`, `bewegung`, `schwelle`, bei (c) `offen` (Börsenstand bei Auslösung) und `seit`; den Text schreibt
  `ausnahme_text` beim Rechnen jedes Ausblicks aus diesen Feldern (Lesart, Bericht, Feld `text` für das Dashboard). Nutzlasten von
  23.68 ohne Text schreibt die Seite selbst ebenso um (Beginn, Ende, „bei Auslösung“, „nur ein Hinweis“). Browserprobe: das Banner
  zeigt für BTC (neue Felder), ETH (Nutzlast von 23.68 nur mit „grund“) und ZEC (Regel a) genau den Text von `ausnahme_text`, am Rechner
  und auf dem Handy (13 von 13); Mutationen der Seite rot („Text ignoriert“, „alte Nutzlast nicht umgeschrieben“).
- (2) Probe (Gruppe „schock“): Sonntag 18:39 und Dienstag 11:09 New York mit 1,6 × Schwelle, dazu 0,8 × Schwelle als Gegenprobe;
  je Coin genau einmal, PAXG nie, „bei Auslösung Börse geschlossen“ nur am Sonntag, kein „breiter“ bei (c), Ende = Beginn + 24 h, F
  von BTC mit und ohne Perp gleich (Verhältnis 1 auf 10⁻¹²); alte Einträge. Mutationen 5 von 5 rot (Börsenstand von jetzt,
  „breiter“ auch bei (c), PAXG nicht ausgenommen, Schwelle ohne √(6/24), ohne 24-h-Sperre).
- (3) Zählung: `hl_ausblick.py --sp-zaehlung`, Debug „★ Ausblick: Zählung der Regel (c)“, Berichtsplan 20.10. 21:15 (zweiter Termin
  21.10.). Probe mit bekanntem Tagesprofil über 2.000 synthetische Tage: ohne Profil Q je Art 0,98–1,06 (erwartet 1,00), mit
  dreifacher Varianz in der Handelszeit Q je Art auf ±10 % wie erwartet (Handelszeit 2,40 gegen 2,50); Einteilung gleich einer
  unabhängigen Einteilung über Ortszeit und Börsenkalender; F_S nur aus bis dahin verfügbaren Werten; 24-h-Sperre. Mutationen 3 von 3
  rot (Einteilung nach dem Fensterende, F_S aus der Zukunft, ohne Sperre). Die Zählung nimmt die 6-h-Bewegung wie die Live-Regel,
  auch über Lücken im Perp (dann kürzer als 6 h).
- (4) Schwelle unverändert. Nebenbefund `G["xyz_sp"]` (geladen, nie benutzt) bleibt; er wirkt auf nichts.

**U177 Strategy-Bestand (13.17), gebaut mit einer Präzisierung vor dem Bau:**
- Parser: Sätze wie bisher; sonst je Tabelle mit der Spalte „Aggregate BTC Holdings“ die größte ganze Zahl mit Tausenderkomma ohne
  „$“ davor (Preise und Summen tragen „$“ oder Nachkommastellen); eine Nachbartabelle, etwa mit verkauften Aktien, zählt nicht.
- **Plausibilität nur nach unten** (statt „Abweichung über 30 %“ in beide Richtungen; festgelegt vor dem Bau, 19.10.): Ein neuer
  Bestand ist unplausibel, wenn er mehr als 30 % unter einem plausiblen Bestand liegt, der höchstens 9 Tage entfernt ist (im Normalfall
  der der Vorwoche). Grund: Strategy verkauft nicht, falsch gelesene Werte sind kleiner; eine Prüfung auch nach oben ließe einen
  einmal durchgerutschten kleinen Wert jeden richtigen der Folgewoche sperren. Neue 8-K eines Laufs werden zeitlich gelesen.
- Unplausibel: nicht archiviert, im Textarchiv vermerkt und im Bericht genannt. Bestände im Archiv, die schon falsch stehen (bis
  23.68), werden je 8-K einmal neu gelesen (höchstens 6 je Lauf); ein plausibler neuer Wert wird eine neue Fassung (die alte bleibt in
  `ak_wert`). Bericht und Reiter rechnen „zuletzt“ nur aus plausiblen Beständen.
- Proben: Tabellen-8-K (gekaufte BTC, Ø Preis mit $, Bestand, Nachbartabelle), Plausibilität und Neulesen in einem Lauf ohne Netz.
  Mutationen 3 von 3 rot (altes Muster, ohne Plausibilität, ohne Neulesen).

### 13.20 Zählung der Regel (c) vom 21.10.2026 (U179) — Ergebnis (beschreibend) und Entscheidung: Q-Schwelle, festgelegt vor dem Bau

**Lauf:** Berichtsplan 21.10. 21:15 (zweiter Termin; der erste lief am 20.10. 21:15 und wurde nicht hochgeladen), `hl_ausblick.py
--sp-zaehlung`, 0,8 s. 3.356 Kerzen `xyz:SP500:30m` vom 12.08. 21:00 bis 21.10. 19:00 UTC, 3.355 Prüfzeitpunkte mit 6-h-Bewegung und F_S.

| Fensterart | Zeitpunkte | Q = Mittel r₆² ÷ Mittel(F_S · 6/24), 90 % | über der Schwelle, 95 % (Wilson) | Auslösungen (24-h-Sperre) |
|---|---|---|---|---|
| Sonntagsstart | 120 | 1,35 (0,49–2,13) | 0 = 0,00 % (0,00–3,10 %) | 0 |
| Wochenende | 880 | 0,12 (0,08–0,18) | 0 = 0,00 % (0,00–0,43 %) | 0 |
| Handelszeit | 681 | 1,13 (0,79–1,54) | 15 = 2,20 % (1,34–3,60 %) | 2 |
| außerhalb | 1.674 | 0,46 (0,39–0,53) | 2 = 0,12 % (0,03–0,43 %) | 2 |

Bauart „3 σ“: 0,27 % bei Normalverteilung und Q = 1. Die Wilson-Intervalle habe ich nachgerechnet, sie sind gleich.

- **Auslösungen der Zählung:** 03.09. 16:00 UTC außerhalb (+1,10 % gegen ±1,01 %), 21.09. 18:30 Handelszeit (+0,95 % gegen ±0,90 %),
  14.10. 16:00 außerhalb (−1,13 % gegen ±1,02 %), 16.10. 18:00 Handelszeit (−1,20 % gegen ±1,20 %).
- **Live seit 23.66 (Regel c):** 14.10. 16:21 UTC (HYPE, XMR, ZEC; BTC, ETH und PAXG standen da schon nach Regel a in der Ausnahmelage),
  16.10. 18:31 und 19.10. 02:39 (Sonntagsstart, „bei Auslösung Börse geschlossen“). Den Sonntagsstart sieht die Zählung im 30-min-Raster
  nicht: Live wird alle 5 min mit dem laufenden Schluss der Kerze geprüft; eine kurze Spitze über der Schwelle, die zum Ende der Kerze
  wieder darunter liegt, löst live aus und fehlt in der Zählung (vorab als Näherung benannt, 13.18 Punkt 3).
- **Lesart (beschreibend):**
  - Wochenende: Der Perp bewegt sich mit rund einem Achtel der angenommenen Varianz; die Regel kann dort praktisch nicht auslösen.
  - Außerhalb der Handelszeit (werktags): rund die Hälfte; 0,12 % der Prüfzeitpunkte über der Schwelle.
  - Handelszeit: Varianz etwa wie angenommen (Q 1,13), aber die Schwelle wird achtmal so oft überschritten wie bei Normalverteilung --
    dicke Ränder.
  - Sonntagsstart: Q 1,35 mit weitem Intervall (zehn Sonntage); im Raster keine Überschreitung, live eine.
  - Die Hypothese aus 13.18 („in der Handelszeit zu häufig, nachts fast nie“) passt in der Richtung. Nicht erwartet hatte ich, dass Q in
    der Handelszeit kaum über 1 liegt: Die Häufung dort kommt aus den Rändern, nicht aus der Varianz.
- **Was die vorab genannte Form bewirken würde** (3 · √(Q_Art · F_S · 6/24), Q aus dieser Zählung fest): Schwelle am Wochenende mal 0,35,
  außerhalb mal 0,68, in der Handelszeit mal 1,06, am Sonntagsstart mal 1,16. Die Regel würde am Wochenende und nachts empfindlicher; in
  der Handelszeit bliebe sie fast so häufig wie heute. Wie oft sie ausgelöst hätte, rechnet die Zählung bisher nicht.
- **Entschieden 21.10. (Nutzer, Auswahl „Q-Schwelle direkt live“; mein Vorschlag war, sie zuerst nur in der Zählung zu zeigen).
  Festgelegt vor dem Bau, gebaut frühestens nach dem 25.10.:**
  - Schwelle je Fensterart s = 3 · √(Q_Art · F_S · 6/24) mit Q_Art fest aus dieser Zählung: Sonntagsstart 1,35, Wochenende 0,12,
    Handelszeit 1,13, außerhalb 0,46. Die Fensterart gilt für das 6-h-Fenster, das am Prüfzeitpunkt endet (Einteilung und Vorrang wie
    13.18 Punkt 3). Q wird nicht laufend neu geschätzt; eine Änderung ist eine neue Festlegung.
  - Sonst wie bisher: Prüfung alle 5 min, 24-h-Sperre je Coin, PAXG ausgenommen, nur ein Hinweis ohne Wirkung auf die Spannen. Der Text
    nennt zusätzlich die Fensterart und die Schwelle („S&P-500-Perp in 6 h −0,5 % am Wochenende, Schwelle ±0,4 %“).
  - Die Zählung (Debug) zeigt danach beide Schwellen nebeneinander, je Fensterart Anteil und Auslösungen, und die Zeit nach dem 21.10.
    getrennt (vorwärts, nicht zur Schätzung von Q benutzt).
  - Proben: Schwelle je Art von Hand; synthetischer Perp mit bekanntem Profil (Wochenende ein Achtel der Varianz) → mit der neuen Schwelle
    je Art rund 0,27 % über der Schwelle bei Normalverteilung, mit der alten am Wochenende keiner; Live-Prüfung = Zählung an denselben
    Zeitpunkten. Mutationen: Q der falschen Fensterart, Q = 1 überall, ohne Wurzel, Einteilung nach dem Fensterende, Q laufend neu.
  - **Erwartung vorab:** mehr Hinweise am Wochenende und außerhalb der Handelszeit (in den zehn Wochen der Zählung 0 bzw. 2 Auslösungen),
    in der Handelszeit etwa gleich viele (2); die dicken Ränder bleiben, dort hilft Q nicht. Wie viele es werden, zeigt erst der Betrieb.
- **Wirkung:** keine. Regel (c) ist nur ein Hinweis; die Spannen rechnen mit der eigenen Schwankung des Coins.

### 13.21 U240: Farside-Zählung je Abrufzeit – vorab festgelegt (02.11.2026, 00:51 gemessen), gebaut mit Paket 23.92

**Anlass:** Die Zählung aus 13.15 (U165) ist erreicht: Am 01.11. war der jüngste Tag in 18 der letzten 20 Abrufe unvollständig. Die
Abrufe laufen um 01:00 und 13:00 UTC (Termine in `hl_aktien.py`); die Zählung trennt beide nicht. Der Satz „entscheidet über
einen zweiten Abruf am Tag“ im Bericht passt nicht dazu (13.15 nannte nur den Abruf um 03:00 Ortszeit; eigener Fehler, nicht
abgeglichen).

- **Neu:** Jeder gemerkte Abruf zählt zu dem jüngsten Abruftermin (01:00 oder 13:00 UTC), der vor seinem Zeitpunkt liegt (ein Abruf um
  00:30 UTC gehört zu 13:00 UTC des Vortags). Der Bericht zeigt gesamt wie bisher (letzte 20 Abrufe) und je Abrufzeit; rückwirkend
  für die gemerkten Abrufe.
- **Text:** „… -- entscheidet, ob eine Abrufzeit verlegt oder ergänzt wird (U240)“.
- **Danach** entscheidet der Nutzer (verlegen, ergänzen oder lassen). Wirkt nur auf die Anzeige des jüngsten Tages; K1 und Summen nicht
  betroffen.
- **Proben:** erfundene Abrufe um 01:04 und 13:06 UTC mit bekannten Lücken → richtige Zählung je Uhrzeit; 00:30 UTC → 13:00 des Vortags.
  **Mutation:** Ortszeit statt UTC.
- **Gebaut mit Paket 23.92 (02.11.2026), Proben in der Sandbox,** ohne Abweichung von dieser Festlegung: Aktienmarkt-Selbsttest
  bestanden (36 Prüfungen). Neu: Zählung je Abrufzeit auf erfundenen Abrufen vom 21. bis 31.10. gleich einer Zählung von Hand mit
  anderer Regel (Uhrzeit des Abrufs in UTC) -- gesamt 8 von 20, 01:00 UTC 6 von 10, 13:00 UTC 2 von 10; die zwei Abrufe vom 21.10.
  fallen aus den letzten 20; 00:30 UTC zählt zu 13:00 UTC des Vortags, 02:15 UTC zu 01:00 UTC; ohne gemerkte Abrufe keine Zählung;
  Text mit Aufteilung und neuem Satz, ohne „zweiten Abruf“. Quell-Mutationen **6 von 6 rot** (01:10:07–01:10:28): Ortszeit statt UTC
  (+1 h), frühester statt jüngster Termin, ganzes Log statt der letzten 20, unvollständig je Abrufzeit nicht gezählt, Bericht ohne
  Aufteilung, alter Satz. Die Seite (Reiter Aktienmarkt) zeigt weiter nur die Zählung gesamt; die Aufteilung steht im Text (Debug
  „★ Aktienmarkt: Stand als Text“, Wochentext sonntags 08:30). Kopf des Textes: „Modul 2026-09-23.92“.

## Quellen

Für Abschnitt 13: `RECHERCHE_Aktienmarkt_11-10-2026.md`, dort mit Fundstellen. Darunter:
- Gleichlauf BTC–S&P 500: Häufigkeiten an Verlusttagen 2025/26, IMF 2022, Bruch durch den ETF-Start.
- Ausnahmen: Yousaf, Riaz & Goodell 2023 zur Bankenkrise 2023.
- Vorlauf BTC → VIX: Gu, Lin & Liu 2026.
- Volatilitätstreiber: Walther, Klein & Bouri 2019; Wang et al. 2023; Hoang & Baur 2020 (implizite BTC-Volatilität).
- Bewertung gemeinsamer Verteilungen: Alexander et al. (Variogramm-Score); Knüppel 2015 (PIT-Test bei überlappenden Zielen).
- Bedingte Szenarien: Meucci (Fully Flexible Probabilities); BoE WP 525 (Grenzen gefilterter historischer Simulation).
- Datenquellen samt Änderungen 2025/26: FRED-Fenster für S&P 500 und Hochzinsspread, Stooq-Schlüssel, NAAIM, Cboe-Domain.

Aus `RECHERCHE_Regime_07-10-2026.md` (dort mit Fundstellen):
- Liu & Tsyvinski (Wochenmomentum), Borri, Liu, Tsyvinski & Wu 2025, Han, Kang & Ryu (Zeitreihenmomentum nach Kosten);
- Detzel et al. 2021 (Kurs zu Durchschnitt), Schmeling, Schrimpf & Todorov 2023 (Carry und Crashs);
- Gneiting & Raftery 2007, Gneiting, Balabdaoui & Raftery 2007 (CRPS, Kalibrierung und Schärfe);
- Coroneo & Iacone 2020 (Diebold-Mariano mit wenigen Punkten);
- Smith & Wallis 2009, Ranjan & Gneiting 2010 (Kombination und Nachkalibrierung);
- Harvey, Liu & Zhu 2016, Bailey et al. 2014/2017 (Data Snooping, Überanpassung).

Neu geprüft am 11.10.2026:
- Clark & West (2007): Approximately normal tests for equal predictive accuracy in nested models, *Journal of Econometrics* 138
  — [NBER Technical Paper 326](https://www.nber.org/papers/t0326), [RePEc](https://ideas.repec.org/p/fip/fedkrw/rwp05-05.html).
- Campbell & Thompson (2008): Predicting excess stock returns out of sample: Can anything beat the historical average?,
  *Review of Financial Studies* 21 — [NBER WP 11468](https://nber.org/papers/w11468),
  [Harvard DASH](https://dash.harvard.edu/entities/publication/73120378-7dd1-6bd4-e053-0100007fdf3b).
- Rapach, Strauss & Zhou (2010): Out-of-sample equity premium prediction: Combination forecasts and links to the real economy,
  *Review of Financial Studies* 23(2), 821–862 — [RePEc](https://ideas.repec.org/a/oup/rfinst/v23y2010i2p821-862.html).
- Gibbs & Candès (2021): Adaptive Conformal Inference Under Distribution Shift, *NeurIPS 2021* —
  [Proceedings](https://proceedings.neurips.cc/paper/2021/hash/0d441de75945e5acbc865406fc9a2559-Abstract.html). Hier nur als
  Hintergrund: Die Form aus normierten Pfaden passt die Breite schon kausal an, eine eigene Konformschicht ist nicht vorgesehen.

Kanonisch, nicht am Original geprüft:
- Welch & Goyal 2008 (*Review of Financial Studies* 21);
- Corsi 2009 (HAR, *Journal of Financial Econometrics* 7);
- Barone-Adesi, Giannopoulos & Vosper 1999 (gefilterte historische Simulation, *Journal of Futures Markets* 19);
- Politis & Romano 1994 (stationärer Bootstrap, *JASA* 89);
- Hoerl & Kennard 1970 (Ridge, *Technometrics* 12);
- López de Prado 2018 (*Advances in Financial Machine Learning*, Purging und Embargo).
