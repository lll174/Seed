# KONZEPT Extrem-Wende (U226) — die Strategie aus dem Video „Range Deviation plus Ribbon Flip“ nachgebaut: Studie auf der Historie und gleich ins Labor

Stand 25.10.2026 13:24 (CET), Version 2026-09-23.83 (Opus 5.5). **Status: gebaut** (`hl_wende.py`, zwei Strategien im TradeLabor,
Debug „★ Wende: Extrem-Wende nach Video (BTC 8 h, U226)“). Vorab festgelegt um 10:41; danach beim Bau, nach der unabhängigen
Durchsicht (10:41–11:29, Bericht 11:29:31), nach der Kalibrierung auf Nullmärkten (ab 11:38) und nach einer zweiten Durchsicht des
Endstands (12:17–12:35) geändert (Abschnitt 8) — **alles vor jedem Lauf auf echten Daten**
(in der Sandbox gibt es keine echten Kurse; die Studie läuft nur auf dem Pi, erster Lauf im Berichtsplan 27.10. 09:40).

**Wunsch des Nutzers (25.10. 09:47):** „Hol dir das video von https://m.youtube.com/watch?v=grMDEn7QbJA. Und baue diese Strategie
nach.“ Das Video war von hier aus nicht erreichbar; der Nutzer hat um 10:26 das Transkript angehängt (`transcript_de.txt`).
**Entscheidungen des Nutzers (25.10., Auswahl):** „Studie und gleich ins Labor“; „Eine Hauptregel, Rest beschreibend (Vorschlag)“
(Hauptregel Ziel 1R); „Nur BTC 8h“.

**Zusagen bleiben:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen unberührt; Chartbild, Ausblick, Aktien, Makro-US, Datentage und
CryptoQuant fließen nicht ein. Die neuen Labor-Strategien bekommen eigene Kennungen; alle bestehenden bleiben bitgleich (Probe). Die
Volumen-Studie ist nicht betroffen (von der Durchsicht bestätigt): ihr Pool nimmt nur Strategien mit mindestens 30 gültigen Trades bis
zum 08.11., Einzelprüfungen brauchen 60; diese Strategie handelt rund siebenmal im Jahr und erscheint dort nur als Zeile.

## 1. Die Strategie laut Video (in eigenen Worten)

- **Markt und Zeitrahmen:** BTC, 8-Stunden-Kerzen.
- **Extreme Kerzen („Range Deviation“):** Im sichtbaren Chart von rund 765 Kerzen (gut 8 Monate; „genau wie im Backtest“) ist eine
  Kerze **rot**, wenn ihr Hoch zu den höchsten 10 % gehört, **blau**, wenn ihr Tief zu den tiefsten 10 % gehört. Die Farben hängen
  am Ausschnitt: Mit 1.050 Kerzen wäre das aktuelle Short-Signal keins gewesen.
- **Trendwende („Ribbon Flip“):** Von den EMA 8 bis 89 zählen nur die schnellste und die langsamste. Fällt die EMA 8 unter die EMA 89,
  kippt das Ribbon bärisch, steigt sie darüber, bullisch.
- **Short:** Seit dem letzten bullischen Flip gab es mindestens eine rote Kerze; dann kippt das Ribbon bärisch; Einstieg zum Schluss
  der Flip-Kerze; Stop 0,1 % über dem höchsten Hoch der (letzten) roten Kerzen. **Long** spiegelbildlich (blaue Kerzen, bullischer
  Flip, Stop „knapp unter“ dem tiefsten Tief der blauen Kerzen).
- **Risiko:** fester Anteil des Kontos (im Backtest 2 %) bis zum Stop; 1R = Abstand Einstieg–Stop.
- **Ausstieg:** offen („entscheidet dein Management“), der Autor steuert von Hand.
- **Zahlen des Autors** (BTC 8h, seit November 2021, ohne Gebühren): 35 Signale, 16 Long und 19 Short. Von den 34 vor dem aktuellen
  erreichten 20 mindestens 1R und 9 mindestens 2R, 8 waren praktisch sofort ausgestoppt; laufen gelassen landen 29 von 34 irgendwann
  im Stop. Mit 2 % Risiko: perfekt getradet über 700 %, bis zum Stop laufen gelassen rund 350 % — fast alles aus dem Long vom Januar
  2023, ohne ihn über 20 % im Minus. Gegen zufällige Einstiege (434 Setups, BTC und ETH, 4–12 h) bis 1R rund 5 Prozentpunkte besser,
  danach kein Vorteil. Das aktuelle Short-Signal ist „das erste seit dem Short am Allzeithoch“.
- **Im Video genannte Trades** (Grundlage der Nachrechnung, Abschnitt 3.1):
  1. Short, Flip 12.10.2025, Einstieg rund 111.700, Stop 126.315 (rote Kerzen Anfang Oktober, Hoch rund 126.200); lief über 3R.
  2. Long, Flip 08.01.2023, Einstieg rund 16.900, Stop gut 2 % darunter (blaue Kerzen um 16.600); nie ausgestoppt.
  3. Short, Juni 2024, Einstieg rund 66.400, Stop gut 5 % darüber; zwischendurch fast 5R im Plus, Monate später am Stop.
  4. Long, Ende März 2026, Einstieg rund 71.300; zwei Tage später ausgestoppt.
  5. Long, Juli 2026, Einstieg rund 64.100, Stop 10 % darunter; bis zu +36 % (gut 3,5R), nicht ausgestoppt.
  6. Short, Flip 16.10.2026, Einstieg rund **82.205** (aus 1R 76.952, 2R 71.700 und 3R 66.447 des Videos abgeleitet: (87.457 +
     76.952) ÷ 2; die Stelle „bei 825“ im Transkript ist verstümmelt), Stop 87.457 (rote Kerzen seit 21.09., Hoch rund 87.400) — das
     aktuelle Signal. Dieselbe Rechnung bestätigt bei Trade 1 den Einstieg ((126.315 + 97.100) ÷ 2 = 111.707).

## 2. Festlegungen, wo das Video offen ist

2.1 **Kerzen.** 8-h-Kerzen in UTC (00:00, 08:00, 16:00) aus den 30-min-Kerzen der Binance-USDT-Perpetuals in `swing.db`
(`sw_klines`, seit 01.01.2020, nur abgeschlossene Kerzen; der Swing-Takt im Dashboard ergänzt sie alle 5 min). Eröffnung = Eröffnung
der ersten 30-min-Kerze, Schluss = Schluss der letzten vorhandenen, Hoch/Tief über alle. Voll = mindestens 14 von 16 Kerzen samt der
ersten und der letzten; nicht volle Kerzen zählen in Fenster und EMA, Signale gibt es nur auf vollen Flip-Kerzen. Fehlt eine 8-h-Kerze
ganz, läuft die Reihe über die vorhandenen (Zahl der Lücken im Bericht). Die Datenquelle des Videos ist unbekannt — kleine
Kursunterschiede erklären Abweichungen im Nachrechnen (Toleranzen in 3.1). Datum einer Flip-Kerze = UTC-Datum ihres Beginns.

2.2 **EMA und Flip.** EMA_n auf den 8-h-Schlüssen, α = 2 ÷ (n + 1), Startwert der erste Schluss der Daten. Lage = Vorzeichen von
EMA8 − EMA89; ein Gleichstand ändert die Lage nicht. **Flip** an T, wenn die Lage an T wechselt (bärisch: vorher über, jetzt unter;
bullisch umgekehrt). So wechseln sich bärische und bullische Flips immer ab.

2.3 **Fenster.** W_T = die 765 Kerzen bis einschließlich T (das, was man zur Zeit der Flip-Kerze sieht: Chartende auf zwei Dritteln;
der Chart färbt mit dem sichtbaren Ausschnitt nach). Erst ab der 765. Kerze der Daten gibt es Signale (dann trägt der Startwert der
EMA 89 weniger als 10⁻⁷). Beschreibend auch die Färbung „je Kerze“ (jede Kerze mit ihrem eigenen Fenster, ohne Nachfärben; 4.6).

2.4 **„Höchste 10 %“ — zwei Lesarten**, beide gerechnet:
- **A (Rang):** rot, wenn Hoch ≥ 90-%-Quantil der Hochs in W_T (lineare Interpolation); blau, wenn Tief ≤ 10-%-Quantil der Tiefs.
- **B (Spanne):** mit H = höchstes Hoch, L = tiefstes Tief in W_T: rot, wenn Hoch ≥ L + 0,9·(H − L); blau, wenn Tief ≤ L + 0,1·(H − L).
Ein Wert genau auf der Schwelle zählt. Welche gilt, entscheidet allein das Nachrechnen der Video-Trades (3.2).

2.5 **Extrem-Bedingung und Stop.** Für einen bärischen Flip an T sei b der Flip davor (ein bullischer; gibt es keinen: Datenbeginn).
Signal, wenn mindestens eine Kerze i mit **b < i ≤ T** in W_T rot ist (die Flip-Kerze b selbst zählt nicht, T zählt). Stop = 1,001 ×
höchstes Hoch dieser roten Kerzen — das ist dasselbe wie das höchste Hoch in (b, T] ∩ W_T, denn die höchste Kerze ist rot, sobald eine
es ist: „rot“ entscheidet nur, ob es ein Signal ist. Long gespiegelt; **0,999 × tiefstes Tief ist eine Annahme** (das Video sagt
„knapp unter“; Trade 2 „gut 2 %“ passt dazu). „Der letzten roten Kerzen“ kann auch den letzten zusammenhängenden roten Block meinen;
das steht beschreibend in 4.6 (Stop „Block“).

2.6 **Einstieg.** Historie: zur Eröffnung der ersten 30-min-Kerze nach dem Schluss von T (das ist der Schluss bis auf die Lücke) plus
Abstand zur Mitte 1,5 bps (wie `hl_swing` für BTC). Kein Trade, wenn diese Kerze erst mehr als 60 min nach dem Schluss beginnt (wie im
Labor) oder ihre Eröffnung schon jenseits des Stops liegt. Labor: 5.

2.7 **R.** 1R = |Einstieg − Stop| in Kurs. R je Trade vor Kosten = Kursweg ÷ 1R; nach Kosten = netto ÷ Risiko (Risiko = Notional ×
Stop-Abstand), wie im Labor (`swing_bilanz`).

2.8 **Hauptregel (Ausstieg, vorab):** Ziel = Einstieg ± 1R als Limit (Maker), gefüllt nur, wenn eine spätere Kerze **durch** das Ziel
läuft (wie im Labor); Stop als Markt (Taker); geprüft auf den 30-min-Kerzen; in der Einstiegskerze nur der Stop; Stop und Ziel in
derselben Kerze: Stop; Kurslücke über den Stop: Eröffnung der Kerze; nach 120 Tagen zur Eröffnung. Kosten wie `hl_swing`: Taker
0,045 %, Maker 0,015 %, Abstand 1,5 bps je Markt-Seite, Funding aus `swing.db` auf das Notional. Dazu immer der Wert ohne Kosten.

2.9 **Überlappung.** In der Studie ist jedes Signal ein eigener Trade (wie im Video); Trades, die sich zeitlich überlappen, bilden eine
**Gruppe** (sie hängen am selben Kursweg). Im Labor hat eine Strategie höchstens eine Position; ein Signal während einer offenen
Position entfällt dort — auch wenn sie nach dem Schluss der Flip-Kerze binnen 60 min endet (8.4) — die Studie zählt, wie oft das vorkam.

2.10 **Zeitraum.** Signale ab dem 01.11.2021 (Beginn der Flip-Kerze; wie im Video). Signale davor (ab der 765. Kerze, also ab
September 2020) sind außerhalb der Stichprobe des Autors: dieselbe Prüfung, aber beschreibend (8.).

## 3. Prüfungen und Urteil

3.1 **Nachrechnen (Positivkontrolle auf echten Daten, ohne Gewinnzahlen).** Je Lesart werden die sechs genannten Trades gesucht.
Gefunden, wenn ein Signal mit derselben Richtung
- im genannten Zeitraum liegt (Beginn der Flip-Kerze; genanntes Datum ± 1 Tag; „Juni 2024“ = Juni, „Ende März 2026“ = 20.–31.03.,
  „Juli 2026“ = Juli), und
- dessen Einstieg höchstens 1,5 % vom genannten abweicht (Trades 1 und 6, deren Einstieg aus den R-Stufen genau folgt: 0,5 %), und
- (nur 1 und 6) dessen Stop höchstens 0,5 % vom genannten abweicht; (2) Stop-Abstand 1,5–3,5 %; (3) 4–7 %; (5) 8,5–11,5 %.
Dazu: die Zahl der Signale vom 01.11.2021 bis zum 17.10.2026 gegen 35 (16 Long, 19 Short); **kein Short-Signal zwischen Trade 1 und
Trade 6** (Flip-Kerzen 14.10.2025 bis 14.10.2026: „das erste seit dem Short am Allzeithoch“); **mit 1.050 Kerzen ist Trade 6 kein
Signal** (bestanden nur, wenn die Lesart Trade 6 mit 765 Kerzen findet; 8.4). **Nachgebaut**, wenn mindestens 5 der 6 Trades gefunden sind und die Zahl höchstens 5 von 35 abweicht. Die Nebenangaben
(lief über 3R, fast 5R, zwei Tage, 36 %) stehen im Bericht neben unseren Werten, ohne Bedingung.

3.2 **Lesart wählen** (vor allem anderen, ohne Gewinnzahlen), in dieser Reihenfolge: mehr gefundene Trades; kein Short in der Lücke;
die Probe mit 1.050 Kerzen; die kleinere Abweichung |n − 35| + |Long − 16| + |Short − 19|; dann A. Die andere Lesart und die Varianten
erscheinen nur beschreibend (4.6). Weicht auch die gewählte ab („nicht nachgebaut“), wird trotzdem geurteilt — dann über unsere
Fassung der Regeln, und so steht es im Kopf des Berichts.

3.3 **H1 — der Zeitpunkt trifft das Ziel öfter als dieselben Trades zu anderen Zeiten** (Haupttest). X = Zahl der Treffer (Ziel vor
Stop und vor 120 Tagen) der Trades des Urteils (3.7). Nullverteilung: **alle diese Trades gemeinsam um τ verschoben** — im Kreis über
die 8-h-Schlüsse ab dem 01.11.2021 bis mehr als 120 Tage vor dem Datenende (nur volle Kerzen mit Einstieg höchstens 60 min nach
dem Schluss, wie bei echten Signalen; 8.4), jede Verschiebung mit Kreisabstand |τ| ≥ 120 Tage (rund 4.300), so
dass die Abstände der Trades zueinander und damit ihre Überlappung erhalten bleiben; Richtung gleich; **Stop-Abstand nach der Schwankung
skaliert**: a_neu = a × σ_neu ÷ σ_echt, σ = Wurzel aus dem Mittel der quadrierten 30-min-Renditen der 10 Tage vor dem Einstieg
(mindestens 240 Renditen, sonst bleibt der Abstand unskaliert und der Bericht zählt es; a_neu in [0,05 %, 90 %]); Ziel 1R; Ausführung und 120 Tage gleich. p = (1 + #{X_τ ≥ X}) ÷ (1 + N_τ),
einseitig. **Schwelle α_H1 = 0,038** (Kalibrierung, 3.8/3.9). Beschreibend dazu: dieselbe Verschiebung ohne Skalierung und p bei
unabhängigen Trades (Poisson-binomial).

3.4 **H2 — Gewinn nach Kosten:** mittleres R netto je Trade > 0, t-Test einseitig mit **Cluster-robustem Standardfehler** über die
Gruppen überlappender Trades (G Gruppen, G − 1 Freiheitsgrade, Faktor G ÷ (G − 1)), α = 0,05.

3.5 **Beständig:** in beiden zeitlichen Hälften (nach Flip-Zeit; bei ungerader Zahl gehört der mittlere Trade zur ersten) mindestens so
viele Treffer, wie dieselben Trades in den Verschiebungen im Mittel haben.

3.6 **Mindestzahlen und Urteil:** 30 Trades in mindestens 20 Gruppen. „**Auf der Stichprobe des Videos bestätigt**“ nur, wenn 3.3, 3.4
und 3.5 zugleich gelten (jede muss allein halten, darum keine Korrektur für mehrere Tests); unter den Mindestzahlen „nicht prüfbar“;
sonst „nicht bestätigt“. Bestätigt hieße: auf der Stichprobe, auf der der Autor das Setup gezeigt (und das Fenster eingestellt) hat,
nicht von Glück zu trennen — kein unabhängiger Beleg. Unabhängig sind erst die Signale vor November 2021 (8., beschreibend, erwartete
Richtung: mehr Treffer als verschoben) und das Labor (5.: dieselbe Prüfung auf den Labor-Trades der Welt B, erst ab 30 Trades, einmal,
ohne Zwischenblicke als Abbruchgrund — bei rund sieben Signalen im Jahr in einigen Jahren).

3.7 **Welcher Lauf urteilt, welche Trades zählen:** Datenende des Urteils fest am **Stichtag 27.10.2026 00:00 UTC** (der Bericht vom
27.10. 09:40 und jeder spätere urteilen gleich; ein Lauf davor heißt „vorläufig“). Es zählen die Signale, deren Flip-Kerze ab dem
01.11.2021 beginnt und **mehr als 120 Tage vor dem Datenende schließt** — eine feste Grenze, unabhängig vom Ausgang (jeder dieser
Trades endet mit Ziel, Stop oder Zeit: die Kerze zur Zeitgrenze liegt in den Daten; strikt seit 8.4). Jüngere Signale (auch Trade 6) stehen beschreibend in der Signalliste.

3.8 **Kalibrierung (vor jedem echten Lauf):** Nullmärkte wie in der Durchsicht (1-min-Wege, Tagesschwankung log-AR(1): Mittel 2,8 %,
φ 0,985, Streuung des Logs 0,4; zu 30-min- und 8-h-Kerzen), ganze Urteilsrechnung (Signale, Grenze, Verschiebung, Skalierung).
Bestanden, wenn der Anteil p < 0,05 bei H1 höchstens 6,5 % ist und „bestätigt“ höchstens 5 %; sonst gilt als Schwelle α_H1 das 5-%-Quantil
der Null-p (ohne Drift). Ergebnisse 3.9.

3.9 **Ergebnis der Kalibrierung (25.10., `hl_wende.py --kalibrieren`):**
- **Lauf 1** (11:38:13–11:47:11, Märkte ab Seed 900.000, Schwelle noch 0,05; Lesart A, wo nicht anders genannt): Anteil p < 0,05 bei H1
  (± 2 Standardfehler), Anteil „bestätigt“, Ø p, Treffer über dem Mittel der Verschiebungen je Markt, Trades je Markt.

| Nullmarkt | Märkte | p < 0,05 | bestätigt | Ø p | Überschuss | Trades |
|---|---|---|---|---|---|---|
| ohne Drift | 1.000 | 6,4 % (± 1,4) | 3,2 % | 0,514 | +0,13 | 40,1 |
| Drift +0,05 %/Tag | 400 | 6,8 % (± 2,2) | 3,0 % | 0,528 | −0,10 | 40,6 |
| Drift −0,05 %/Tag | 400 | 8,2 % (± 2,2) | 3,5 % | 0,516 | +0,12 | 40,2 |
| starke Regime (Streuung des Logs 0,6) | 400 | 8,2 % (± 2,2) | 3,8 % | 0,528 | +0,01 | 40,1 |
| Lesart B | 400 | 8,8 % (± 2,2) | 1,0 % | 0,506 | +0,19 | 31,8 |
| ohne Skalierung (nur zum Vergleich) | 400 | 10,0 % | 4,0 % | 0,483 | +0,57 | 40,5 |

  Die Schranke (höchstens 6,5 %) hält nur ohne Drift, und das knapp → nach 3.8 gilt **α_H1 = 0,038** (5-%-Quantil der Null-p ohne
  Drift 0,0387, abgerundet). Mit 0,038 auf denselben Märkten: 4,9 % / 5,5 % / 7,2 % / 5,5 % / 5,5 % (ohne Skalierung 9,5 %), alle
  Nullvarianten zusammen 5,5 % (2.600 Märkte). „Bestätigt“ wird mit der strengeren Schwelle nur seltener.
- **Gegenprobe mit frischen Märkten** (11:48:04–11:57:48, ab Seed 950.000, Schwelle 0,038 -- nicht auf diesen Märkten bestimmt): Anteil
  p < 0,038 bei H1 ohne Drift 4,5 % (1.000 Märkte; p < 0,05: 5,7 %), Drift −0,05 %/Tag 3,2 %, starke Regime 4,5 %, Lesart B 4,8 % (je
  400), zusammen 4,3 % (2.200); „bestätigt“ 1,9 % / 1,2 % / 2,0 % / 0,8 %.
- **Lesart:** Die Skalierung nach der Schwankung bringt H1 von 10,0 % auf 6,4 % (p < 0,05); den Rest (Drift, Regime, Lesart B) fängt die
  Schwelle 0,038 auf. Einzelne Varianten mit 400 Märkten schwanken zwischen den Läufen um bis zu 4 Prozentpunkte (−0,05 %/Tag: 7,2 % und
  3,2 %); maßgeblich sind die Summen (Lauf 1 5,5 %, Gegenprobe 4,3 %). Das ganze Urteil („bestätigt“: H1, H2, Hälften und Mindestzahlen
  zugleich) liegt auf Nullmärkten bei 0,8–3,8 %.

**Ehrliche Erwartung (Trennschärfe, Endstand mit α_H1 0,038, gemessen 13:07:23–13:07:43):** Auf 60 Nullmärkten wie in der Kalibrierung (26–59 Trades, Median 39; Gruppen 17–35) braucht H1 im Median 67 % Treffer (Spanne 54–81 %) bei p0 um 49 %. Mit einem Vorteil wie im Video (+5 Prozentpunkte über p0) liegt die Wahrscheinlichkeit für p < α_H1 im Median bei 9 % (Quartile 8–10 %), bei +9 Prozentpunkten bei 19 % (16–21 %; Normalnäherung mit der Streuung der verschobenen Trefferzahlen, wie im Bericht). H2 und die Hälften drücken die Wahrscheinlichkeit für „bestätigt“
weiter. „Nicht bestätigt“ heißt dann: auf dieser Stichprobe nicht von Glück zu trennen — nicht: widerlegt. Der Bericht rechnet die
Trennschärfe mit der echten Nullverteilung.

**Folgen:** Das Labor handelt die Hauptregel ab dem Einspielen ohnehin (Wahl des Nutzers). Das Urteil ändert daran nichts
automatisch; Änderungen (andere Regel, Lesart, Abschalten) nur nach Entscheidung des Nutzers, mit neuer Kennung.

## 4. Beschreibend (ohne Urteil, mit Intervallen über die Gruppen)

4.1 **Signalliste:** jedes Signal ab November 2021 (alle Daten bis zum Lauf) mit Flip-Zeit, Richtung, Einstieg, Stop, Stop-Abstand,
Ergebnis der Hauptregel, bis zum Stop laufen lassen, bestes Zwischenhoch (MFE), p0 (Trefferanteil in den Verschiebungen) für die Trades
des Urteils.

4.2 **Vergleich mit dem Video** (ohne Kosten, wie dort, und ohne Zeitgrenze; dann mit Kosten): von den Signalen vor dem jüngsten —
mindestens 1R bzw. 2R vor dem Stop; „praktisch sofort ausgestoppt“ (Stop binnen 6 Kerzen, also 2 Tagen, ohne je +0,5R); laufen gelassen
irgendwann im Stop; „Summe R × 2 %, einfach addiert, kein Konto“ für „perfekt — **Obergrenze im Nachhinein**“ (MFE bis Stop oder
Datenende) und „bis zum Stop laufen lassen“ (offene zum letzten Schluss), dazu ohne den besten Trade.

4.3 **Ausstiege im Vergleich** (Trades des Urteils, **alle höchstens 120 Tage**, für echte und verschobene gleich): Hauptregel (1R),
Ziel 2R, Ziel 3R, bis zum Stop, Gegen-Flip (Ausstieg zur Eröffnung nach dem Schluss des nächsten Flips gegen die Position, sonst Stop).
Je Variante: Treffer, Ø R vor und nach Kosten, dieselben Trades verschoben, Vorteil (90-%-Intervall über die Gruppen), Summe R, Σ R × 2 %
(einfach addiert), Rückgang in R über die geschlossenen Trades in Ausstiegsfolge. „Perfekt“ steht nur in 4.2.

4.4 **Treffer je Stufe** (0,5R, 1R, 1,5R, 2R, 3R, 5R vor dem Stop, höchstens 120 Tage) gegen die Verschiebungen, mit 90-%-Intervall —
die Aussage des Videos „bis 1R besser, danach Münzwurf“.

4.5 **Kontrolle „Flip ohne Extrem“:** jeder Flip derselben Spanne, Stop 0,1 % jenseits des Extrems seit dem letzten Gegen-Flip im
Fenster, Hauptregel — Treffer gegen erwartet und Ø R: zeigt, was die Extrem-Bedingung beiträgt.

4.6 **Empfindlichkeit** (ohne p-Werte, weil viele Varianten nebeneinander stehen): Lesart A/B × Fenster 500/765/1.050, dazu Färbung je
Kerze und Stop „Block“: Zahl der Signale, gefundene Video-Trades, Lücke, Trades, Treffer gegen erwartet, Ø R netto. Trifft eine Variante
mehr Video-Trades als die gewählte, steht ein Hinweis im Bericht; das Urteil bleibt bei der gewählten, ein Wechsel wäre ein eigener
Plan-Punkt mit neuer Kennung im Labor.

4.7 **Vor dem Zeitraum des Videos** (September 2020 bis Oktober 2021): dieselbe Prüfung (Verschiebung über die ganze Spanne),
beschreibend, mit erwarteter Richtung.

4.8 **Stand jetzt:** jüngstes Signal (offen oder erledigt; Einstieg, Stop, 1R/2R/3R, Ergebnis), Lage des Ribbons seit dem letzten
Flip und ob seitdem rote bzw. blaue Kerzen da sind (also ob der nächste Flip ein Signal wäre, mit welchem Stop).

4.9 **Labor-Abgleich:** Signale, die das Labor wegen einer offenen Position ausgelassen hätte; Zerlegung je Trade in Kurs, Abstand zur
Mitte, Gebühren, Funding. Die Labor-Trades selbst liest die Studie nicht (Welt B; Welt A sperrt Longs): Das Labor handelt erst seit dem
Einspielen; dieselbe Prüfung auf seinen Trades folgt ab 30 Trades (3.6).

4.10 **Befunde zur Prüfung:** Schwankung vor dem Einstieg (Signale gegen alle erlaubten Einstiege), Anteil Zeitgrenze je Stop-Band
(echt gegen verschoben), Überlappung (Paare gleicher und gegensätzlicher Richtung, Gruppen mit mehreren Trades), Stop schon in der
Einstiegskerze, Ziel und Stop in derselben Kerze.

## 5. Labor

- **Zwei Strategien,** Gruppe „Swing“, nur BTC: `wende_rang` (Lesart A) und `wende_spanne` (Lesart B), sonst gleich — weil die Lesart
  erst die Studie auf dem Pi entscheidet und das Labor ab dem Einspielen handeln soll. Die Studie nennt, welche die Video-Strategie ist;
  die andere läuft als Vergleich weiter (Abschalten nur nach Entscheidung des Nutzers).
- **Regeln** fest in der Kennung (Fenster 765, Anteil 10 %, EMA 8/89, Stop-Puffer 0,1 %, Ziel 1R, 120 Tage, Einstiegsfenster 60 min,
  `h` 8, Größe fest 10.000 USD wie alle Swing-Strategien, `wende_v` 1). Eine **Goldprobe** im Selbsttest (Prüfsumme der Signale beider
  Lesarten auf einem festen erfundenen Weg) schlägt an, wenn eine Änderung am Code die Signale ändert — dann `wende_v` erhöhen (neue
  Kennung, die alte Bilanz bleibt).
- **Daten und Takt:** dieselben Funktionen wie die Studie (`hl_wende`), aus `swing.db` (Binance), neu gerechnet nur bei einer neuen
  8-h-Kerze; im Eingang des Labors nur das Signal je Lesart und die Lage (keine Reihen — die Welt A kopiert den Eingang je Takt).
- **Einstieg** zum Marktpreis auf Hyperliquid höchstens 60 min nach dem Schluss der Flip-Kerze und einmal je Signal (Zustand
  „letzter_einstieg“, überlebt Neustarts); Stop und Ziel ab der Mitte jetzt (wie `sig_swing`): Ziel = Mitte ± |Mitte − Stop|, Risiko =
  10.000 USD × |Mitte − Stop| ÷ Mitte in den Werten (für R in `swing_bilanz`). **Kein Einstieg**, wenn der Stop näher als 5 bps an der
  Mitte oder näher als die Hälfte des Abstands am Schluss liegt (sonst ließe `_eroeffnen` einen Stop auf der falschen Seite still fallen
  — eine Position ohne Stop für 120 Tage — oder 1R wäre winzig); das Signal entfällt dann ganz, auch wenn der Kurs später wieder
  passt (wie in der Historie: Eröffnung jenseits des Stops → kein Trade; 8.4). War beim Schluss der Flip-Kerze oder danach eine Position
  offen, entfällt das Signal ebenso (2.9). Die Tafel zählt „verfallen“ (Daten erst nach 60 min gesehen) und „ausgelassen“ (Position offen;
  Kurs jenseits oder zu nah am Stop) getrennt; die Werte jedes Einstiegs nennen die Verzögerung nach dem Schluss. Nach jedem Ausstieg
  wartet die Engine 15 min (wie bei allen Strategien) — endet eine Position kurz vor dem Schluss, verschiebt das den Einstieg um bis zu
  15 min.
- **Grenzen:** Die Kennung deckt die Regeln, nicht die Einstiegslogik in `sig_wende` (Fenster, Rand, einmal je Signal) — wer diese
  ändert, erhöht `wende_v`. Liegt `swing.db` länger als 8 h zurück, sieht das Labor nur die jüngste 8-h-Kerze; ein Signal dazwischen
  wird weder gehandelt noch gezählt.
- **Welt A** (Notbremse) sperrt Longs wie bei allen Strategien; der Vergleich mit der Studie gilt für Welt B.
- **Anzeige:** Live-Tafel mit Lage (Ribbon, Extreme seit dem Flip, Stop des nächsten Signals); Bilanz in R mit den Swing-Strategien.

## 6. Proben (vor dem ersten Lauf)

- **Von Hand:** 8-h-Kerzen (Ausrichtung, Lücken, „voll“, fehlende 8-h-Kerze); EMA gegen die Gewichte; Flips mit Gleichstand an T und
  T−1; Lesarten an einem kleinen Fenster; ein konstruiertes Signal (Einstieg, Stop, Ziel, R); **Grenzfälle**: rote Kerze nur an b
  (zählt nicht), nur an T (zählt), erste Kerze des Fensters (zählt), die davor (nicht), Hoch genau auf der Schwelle (zählt), erste
  Kerze erst 2 h nach dem Schluss, Eröffnung jenseits des Stops; Varianten Stop „Block“ und Färbung je Kerze; Handel (Ziel nur
  durchlaufen, nicht in der Einstiegskerze; Stop und Ziel in einer Kerze → Stop; Lücke; Zeitgrenze; offen; Gegen-Flip; Kosten).
- **Kausalität:** Kerzen ab dem Einstieg beliebig verändert → Signal, Stop und die Schwankung vor dem Einstieg gleich.
- **Erste Passage** (schnelle Suche nach Ziel/Stop für die Verschiebungen) gegen eine einfache Schleife.
- **Statistik von Hand:** Rang-p, kritische Trefferzahl, Hälften, Urteil mit allen Mindestzahlen; Cluster-t (Einzelgruppen = t-Test,
  doppelte Trades = t-Test der einzelnen); Verschiebung gemeinsam, |τ| ≥ 120 Tage, Skalierung von Hand.
- **Nulltest** (kurz im Selbsttest: 60 Nullmärkte mit 1-min-Wegen) und **Kalibrierung** (lang, 3.8/3.9).
- **Positivkontrolle:** auf erfundenen Wegen nach jedem Signal (der Reihe nach, kausal) ein Vorteil eingepflanzt (+0,8R binnen 2 Tagen;
  gemessen rund +40 Prozentpunkte Treffer über den Verschiebungen) → H1 in mindestens 11 von 12 Wegen erfüllt.
- **Nachrechnen** mit Toleranzen (knapp innerhalb/außerhalb), Lücke, 1.050-Probe, Reihenfolge der Wahl.
- **Labor:** gleiche Signale wie die Historie; nur BTC; einmal je Signal (auch nach einem Stop binnen Minuten); nicht nach 60 min (auch
  mit zwischengespeichertem Eingang); nicht mit offener Position, auch nicht nach ihrem Ende binnen 60 min; nicht jenseits oder zu nah
  am Stop (auch nicht, wenn der Kurs danach wieder passt); keine Position ohne Stop; verfallene und ausgelassene Signale getrennt gezählt; Kennungen fest, alle übrigen unverändert; Bilanz in R.
- **Goldprobe**, **Mutationen** (jede muss den Selbsttest rot machen), Laufzeit auf voller Datenmenge, Ende zu Ende auf einer erfundenen
  `swing.db` (Urteil fest bis zum Stichtag).

## 7. Berichte

Debug „★ Wende: Extrem-Wende nach Video (BTC 8 h, U226)“ (`hl_wende.py --studie --db …`, liest nur) und „Wende: Selbsttest“; im
Berichtsplan 27.10. 09:40 (urteilt mit Datenende Stichtag). Prüfsumme der Signale im Urteil im Kopf. `hl_wende.py --stand --db …`
zeigt nur die Lage jetzt; `hl_labor.py --selbsttest-wende` nur die Labor-Proben.

## 8. Beim Bau geändert und kalibriert (25.10., vor jedem Lauf auf echten Daten)

Vorab festgelegt war um 10:41 ein Poisson-binomialer Test mit 2.000 Zufallseinstiegen je Trade (gleiche Richtung, gleicher Abstand in
%) und ein gewöhnlicher t-Test. Geändert, mit Grund:
1. **Überlappung (eigener Befund beim Bau, 10:53):** Signale folgen oft dicht aufeinander; auf 80 driftlosen erfundenen Wegen meldete
   der unabhängige Test in 10 % einen Vorteil statt in 5 % (16 von 41 Signalen je Weg im Median während eines offenen Trades). → Gemeinsame
   Verschiebung (3.3) und Cluster-t (3.4); auf 200 einfachen Wegen dann 6,0 % (10:58).
2. **Unabhängige Durchsicht (zweiter Agent, 10:41:39–11:29:49, Bericht 11:29:31; 23 Befunde: 4 schwere, 16 kleinere, 3 Hinweise):** auf realistischeren Nullmärkten (1-min-Wege, log-AR(1)) kam der vorab
   festgelegte Test auf 11,6 % (704 Märkte), die gemeinsame Verschiebung allein auf 9,0 %, weil Signale in anderen Schwankungsphasen
   starten als beliebige Zeitpunkte (mit Zeitgrenze zählt das); mit nach der Schwankung skaliertem Stop-Abstand 5,7 % (300), mit Drift
   6,7 % → Skalierung (3.3), Kalibrierungsschranke (3.8). Weiter umgesetzt: feste Grenze „120 Tage vor dem Datenende“ und fester
   Stichtag (3.7; vorher wäre ein junger Trade nur mit schnellem Ausgang ins Urteil gekommen); Mindestzahl 20 Gruppen (3.6); Wortlaut
   „auf der Stichprobe des Videos bestätigt“ und die Rolle von 2020–21 und Labor (3.6); Einstieg von Trade 6 82.205 und Toleranz 0,5 %
   für Trades 1 und 6 (3.1); Lücke und 1.050-Probe in der Wahl (3.2); „perfekt“ nur in 4.2 als Obergrenze, gleiche Zeitgrenze für echte
   und verschobene Trades in 4.3/4.4, keine p in 4.6, Befunde 4.10; Varianten Färbung je Kerze und Stop „Block“ (4.6); Labor: Stop-Rand,
   kleiner Eingang, verfallene Signale, Goldprobe und `wende_v`, Kennungsprobe streng.
3. **Kalibrierung (3.9).**
4. **Zweite unabhängige Durchsicht des Endstands** (zweiter Agent, Code gegen dieses Konzept und die 23 Befunde der ersten; 12:17:29–
   12:35, Bericht 12:34:48; kein schwerer Befund, 4 kleinere, 8 Hinweise; keine Vorschau auf künftige Daten, Long und Short genau
   spiegelbildlich, die Verschiebung um τ = 0 gibt die echten Trades wieder). Umgesetzt vor jedem echten Lauf:
   - **M1:** Eine Flip-Kerze, die genau 120 Tage vor dem Datenende schloss, hatte keine Kerze zur Zeitgrenze; verfehlte der Trade Ziel
     und Stop, fiel er still aus dem Urteil, ein Treffer blieb drin. → Grenze strikt (3.3, 3.7); der Bericht meldet einen Trade ohne
     Ausgang im Urteil laut.
   - **M2:** Schloss eine offene Position binnen 60 min nach dem Schluss der Flip-Kerze, stieg das Labor noch ein (bis zu 60 min spät),
     und die Tafel zählte es danach als „verfallen“. → Signal entfällt (2.9, 5), gezählt als „ausgelassen“.
   - **M3:** Die 1.050-Probe galt auch für eine Lesart, die Trade 6 gar nicht findet, und konnte so die Wahl entscheiden. → nur bestanden,
     wenn Trade 6 mit 765 Kerzen gefunden ist (3.1).
   - **M4:** „Nicht nachgebaut“ stand nur in Teil 1 des Berichts. → auch im Kopf und in der Zeile des Urteils (3.2).
   - **Hinweise:** Pool der Verschiebung nur mit erlaubten Einstiegen (volle Kerze, höchstens 60 min; 3.3); ohne σ unskaliert und gezählt
     (3.3); Video-Vergleich und Stand jetzt mit dem jüngsten Signal, auch ohne Trade (4.2, 4.8); 4.9 ehrlich (die Studie liest das Labor
     nicht); Labor-Grenzen und Pause nach dem Ausstieg (5). Die Größe von H1 für Lesart B bei α_H1 0,038 steht in 3.9 (Hinweis N1).
     Mutationen laufen außerhalb des Moduls (Liste in UEBERGABE 3σσσσ).
   - Ein Signal, das das Labor beim ersten Prüfen jenseits oder zu nah am Stop sah, entfällt jetzt ganz (5; vorher konnte es bei
     späterem Kurs noch eingehen) — wie in der Historie.
   - **Nachprüfung der Schwelle mit dem Endstand:** 1.000 Nullmärkte ohne Drift, dieselben wie in der Gegenprobe (12:49:04–12:55:30): p < 0,038 bei 4,3 % (vorher 4,5 %), p < 0,05 bei 5,8 %, „bestätigt“ 1,8 %; die p-Werte verschieben sich im Median um 0,001 (die Spanne der Verschiebungen ist eine 8-h-Kerze kürzer), 2 Märkte wechseln die Seite der Schwelle -- die Schwelle 0,038 bleibt.
