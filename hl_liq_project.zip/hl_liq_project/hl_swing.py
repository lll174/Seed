#!/usr/bin/env python3
"""
Swing-Modul (U140): Positionen über Tage (Version 2026-09-23.61).

Regeln vorab in KONZEPT_Swing.md (08.10.2026, vor jedem Lauf auf echten Daten). Inhalt:
  - eigene Datei swing.db neben der Hauptdatenbank: 30-min-Kerzen der Binance-USDT-Perpetuals ab 01.01.2020 und die
    Funding-Historie derselben Börse (Tabellen sw_klines, sw_funding, sw_meta; Schreiben nur mit BEGIN IMMEDIATE);
  - Tageskerzen, σ_Tag, Kennzahlen; Einstieg und Nachführen der Strategien S1–S4 und der beiden Kontrollen als gemeinsame
    Funktionen für die Historie UND das TradeLabor (hl_labor ruft dieselben Funktionen);
  - Handelssimulation auf 30-min-Kerzen mit Gebühren, Abstand zur Mitte und Funding; Zeitpunkt-Placebo; vorab festgelegtes Urteil;
  - Daten-Takt im Dashboard-Prozess (ergänzt Kerzen und Funding laufend), Debug-Bericht.
Berührt weder hl_liq.db noch regime.db, Prognose, Fusion, v3, Kaskaden oder Familien.

  python3 hl_swing.py --vorpruefung --db <hl_liq.db>   Debug-Bericht „★ Swing: Vorprüfung auf der Historie (U140)“
  python3 hl_swing.py --laden --db <hl_liq.db>         Historie laden bzw. ergänzen
  python3 hl_swing.py --selbsttest                     Bausteine, Ausführung, Kausalität, Nulltests, Positivkontrollen (ohne Netz)
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sqlite3
import sys
import threading
import time

import numpy as np

import hl_regime as RG

VERSION_MODUL = "2026-09-23.61"
COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")      # die Labor-Coins
BAR = 1800
BARS_TAG = 48
TAG = 86400
START_HIST = 1577836800                          # 01.01.2020 00:00 UTC
LABOR_TAGE = 460                                 # so viele Tage liest das Labor (Kennzahlen brauchen höchstens 261)
VORLAUF_TAGE = 260                               # erster bewerteter Tag je Coin: so viele Tage nach Datenbeginn
RISIKO_USD = 100.0                               # 1 % eines 10.000-USD-Kontos je Coin
NOTIONAL_MAX = 10_000.0
GEB_TAKER = 0.00045
GEB_MAKER = 0.00015
GEB_FAKTOR = {"XMR": 2.0}                        # HIP-3-Markt auf Hyperliquid, wie im Labor
SLIP_BPS = {"BTC": 1.5, "ETH": 1.5}              # Abstand zur Mitte je Seite (Historie); übrige SLIP_STANDARD
SLIP_STANDARD = 5.0
HWZ = 20.0                                       # Halbwertszeit von σ_Tag (Tage)
N_PLACEBO = 200
MIN_TRADES = 60
HAC_LAG = 10
ALPHA = 0.05
DSR_MIN = 0.95
EIN_FENSTER_S = 6 * 3600                         # Labor: Einstieg höchstens 6 h nach dem Tagesschluss
LADE_BUDGET_TAKT = 240.0
PAUSE_ABRUF = 0.25                               # zwischen zwei Abrufen (Selbsttest: 0)
TAKT_S = 300

# Die Strategien (KONZEPT_Swing.md Abschnitt 4). Dieselben Regeln gehen unverändert ins TradeLabor (hl_labor.strategien);
# jede Änderung ergibt dort eine neue Kennung.
STRATEGIEN = {
    "swing_trend": {"art": "trend", "kanal_ein": 20, "kanal_aus": 10, "stop": 2.0, "trail": 3.0, "max_tage": 30},
    "swing_ruecksetzer": {"art": "ruecksetzer", "sma_kurz": 20, "sma_lang": 50, "hoch_tage": 10, "tiefe": 2.0, "stop": 2.0,
                          "ziel_min": 1.5, "max_tage": 10},
    "swing_kompression": {"art": "kompression", "vol_tage": 10, "perz_tage": 250, "perz": 0.20, "kanal": 10, "stop": 1.5,
                          "trail": 3.0, "max_tage": 20},
    "swing_gegenbewegung": {"art": "gegenbewegung", "tage": 3, "z": 2.5, "funding_z": 1.0, "funding_tage": 30, "stop": 2.0,
                            "ziel_anteil": 0.5, "ziel_min": 1.0, "max_tage": 5},
    "swing_zufall": {"art": "zufall", "p_tag": 0.10, "kanal_aus": 10, "stop": 2.0, "trail": 3.0, "max_tage": 30},
    "swing_ruecksetzer_zufall": {"art": "ruecksetzer_zufall", "p_tag": 0.10, "sma_kurz": 20, "sma_lang": 50, "hoch_tage": 10,
                                 "stop": 2.0, "ziel_min": 1.5, "max_tage": 10},
}
HAUPT = ("swing_trend", "swing_ruecksetzer", "swing_kompression", "swing_gegenbewegung")   # die vier geprüften
KURZ = {"swing_trend": "S1 Trend-Ausbruch", "swing_ruecksetzer": "S2 Rücksetzer im Trend", "swing_kompression": "S3 Ausbruch nach Ruhe",
        "swing_gegenbewegung": "S4 Gegenbewegung nach Übertreibung", "swing_zufall": "Zufall (Ausstiege wie S1)",
        "swing_ruecksetzer_zufall": "Zufall im Trend (Ausstiege wie S2)"}
for _r in STRATEGIEN.values():
    _r.update(risiko_usd=RISIKO_USD, notional_max=NOTIONAL_MAX)


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    return RG._de(x, nd, vz)


def _datum(ts) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(ts))) if ts is not None else "—"


def _tausend(n) -> str:
    return f"{int(n):,}".replace(",", ".")


def gebuehr(coin: str, satz: float) -> float:
    return satz * GEB_FAKTOR.get(coin, 1.0)


# ================================================================================================ Datenhaltung

SCHEMA = """
CREATE TABLE IF NOT EXISTS sw_klines (coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS sw_funding (coin TEXT, ts INTEGER, rate REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS sw_meta (k TEXT PRIMARY KEY, v TEXT);
"""


def swing_pfad(db: str) -> str:
    """swing.db liegt neben der Hauptdatenbank (wie regime.db); HL_SWING_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_SWING_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "swing.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung: Autocommit, jede Schreibtransaktion mit BEGIN IMMEDIATE (Projektregel)."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def _schreiben(con, sql: str, zeilen: list) -> None:
    if not zeilen:
        return
    con.execute("BEGIN IMMEDIATE")
    try:
        con.executemany(sql, zeilen)
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM sw_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def meta_setzen(con, k: str, v: str) -> None:
    _schreiben(con, "INSERT OR REPLACE INTO sw_meta VALUES (?,?)", [(k, v)])


def kerzen_lesen(con, coin: str, ab: int | None = None) -> dict | None:
    q = "SELECT ts, o, h, l, c, v FROM sw_klines WHERE coin=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (coin, int(ab)) if ab is not None else (coin,)).fetchall()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}


def funding_lesen(con, coin: str, ab: int | None = None) -> dict:
    q = "SELECT ts, rate FROM sw_funding WHERE coin=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (coin, int(ab)) if ab is not None else (coin,)).fetchall()
    a = np.array(rows, dtype=float) if rows else np.zeros((0, 2))
    return {"ts": a[:, 0].astype(np.int64), "rate": a[:, 1]}


def _binance_funding(coin: str, start_ms: int, ende_ms: int) -> list:
    """Bis 1000 Funding-Zahlungen ab start_ms (aufsteigend) -> [(ts in s, Rate je Zahlung)]."""
    url = f"{RG.FAPI}/fapi/v1/fundingRate?symbol={coin}USDT&startTime={int(start_ms)}&endTime={int(ende_ms)}&limit=1000"
    d, _ = RG._http_json(url)
    if not isinstance(d, list):
        raise RG.KeinSymbol(str(d)[:120])
    return sorted((int(x["fundingTime"]) // 1000, float(x["fundingRate"])) for x in d)


# Austauschbar für den Selbsttest (Laden ohne Netz)
QUELLE = {"kerzen": RG._binance_kerzen, "funding": _binance_funding}
_UNERREICHBAR: set = set()


def laden_kerzen(con, coin: str, budget_s: float, log=print, jetzt: int | None = None) -> dict:
    """Ergänzt die 30-min-Kerzen eines Coins bis zur letzten abgeschlossenen Kerze, ab START_HIST (vor der Listung liefert
    Binance ab der Listung)."""
    jetzt = int(jetzt or time.time()); t0 = time.time()
    if meta(con, f"keine:{coin}") == "1":
        return {"coin": coin, "neu": 0, "fertig": True, "keine": True}
    have = con.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=?", (coin,)).fetchone()[0]
    cursor = max(START_HIST, (int(have) + BAR) if have else START_HIST)
    letzte_zu = (jetzt // BAR) * BAR - BAR
    neu = 0
    while cursor <= letzte_zu:
        if time.time() - t0 > budget_s:
            return {"coin": coin, "neu": neu, "fertig": False}
        if "binance" in _UNERREICHBAR:
            return {"coin": coin, "neu": neu, "fertig": False, "fehler": "Binance-Futures nicht erreichbar"}
        try:
            zeilen, gewicht = QUELLE["kerzen"](coin, cursor * 1000, (letzte_zu + BAR) * 1000 - 1)
        except RG.KeinSymbol:
            if not have and not neu:
                meta_setzen(con, f"keine:{coin}", "1")
                return {"coin": coin, "neu": 0, "fertig": True, "keine": True}
            return {"coin": coin, "neu": neu, "fertig": True}
        except RuntimeError as e:
            _UNERREICHBAR.add("binance")
            log(f"  {coin}: Binance-Futures nicht erreichbar ({e})")
            return {"coin": coin, "neu": neu, "fertig": False, "fehler": str(e)[:100]}
        zeilen = [z for z in zeilen if cursor <= z[0] <= letzte_zu]
        if not zeilen:
            return {"coin": coin, "neu": neu, "fertig": True}
        _schreiben(con, "INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)", [(coin, *z) for z in zeilen])
        neu += len(zeilen)
        cursor = zeilen[-1][0] + BAR
        time.sleep(PAUSE_ABRUF if (gewicht or 0) < 1200 else 30.0)
    return {"coin": coin, "neu": neu, "fertig": True}


def laden_funding(con, coin: str, budget_s: float, log=print, jetzt: int | None = None) -> dict:
    jetzt = int(jetzt or time.time()); t0 = time.time()
    if meta(con, f"keine:{coin}") == "1":
        return {"coin": coin, "neu": 0, "fertig": True}
    have = con.execute("SELECT MAX(ts) FROM sw_funding WHERE coin=?", (coin,)).fetchone()[0]
    cursor = max(START_HIST, (int(have) + 1) if have else START_HIST)
    neu = 0
    while cursor <= jetzt:
        if time.time() - t0 > budget_s:
            return {"coin": coin, "neu": neu, "fertig": False}
        if "binance" in _UNERREICHBAR:
            return {"coin": coin, "neu": neu, "fertig": False, "fehler": "Binance-Futures nicht erreichbar"}
        try:
            zeilen = QUELLE["funding"](coin, cursor * 1000, jetzt * 1000)
        except RG.KeinSymbol:
            return {"coin": coin, "neu": neu, "fertig": True}
        except RuntimeError as e:
            _UNERREICHBAR.add("binance")
            log(f"  {coin}: Funding nicht erreichbar ({e})")
            return {"coin": coin, "neu": neu, "fertig": False, "fehler": str(e)[:100]}
        zeilen = [z for z in zeilen if cursor <= z[0] <= jetzt]
        if not zeilen:
            return {"coin": coin, "neu": neu, "fertig": True}
        _schreiben(con, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)", [(coin, t, r) for t, r in zeilen])
        neu += len(zeilen)
        cursor = zeilen[-1][0] + 1
        if len(zeilen) < 1000:
            return {"coin": coin, "neu": neu, "fertig": True}
        time.sleep(PAUSE_ABRUF)
    return {"coin": coin, "neu": neu, "fertig": True}


def laden(pfad: str, coins=COINS, budget_s: float = 420.0, log=print, jetzt: int | None = None, sperre_s: int = 900) -> dict:
    """Kerzen und Funding für alle Coins ergänzen. Läuft schon ein anderer Ladevorgang (Dashboard-Takt oder Debug-Eintrag, jünger
    als sperre_s), wird übersprungen; das Budget teilt sich auf die Coins (Rest wandert zum nächsten)."""
    _UNERREICHBAR.clear()
    con = verbinden(pfad); t0 = time.time(); erg = {}
    try:
        jetzt_ = int(jetzt or time.time())
        con.execute("BEGIN IMMEDIATE")
        try:
            r = con.execute("SELECT v FROM sw_meta WHERE k='laeuft'").fetchone()
            if r and r[0] and jetzt_ - int(r[0].split(":")[-1]) < sperre_s and r[0].split(":")[0] != str(os.getpid()):
                con.execute("COMMIT")
                return {"uebersprungen": True, "coins": {}}
            con.execute("INSERT OR REPLACE INTO sw_meta VALUES ('laeuft', ?)", (f"{os.getpid()}:{jetzt_}",))
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
        try:
            for i, coin in enumerate(coins):
                rest = budget_s - (time.time() - t0)
                anteil = max(10.0, rest / max(1, len(coins) - i))
                k = laden_kerzen(con, coin, anteil, log, jetzt)
                f = laden_funding(con, coin, max(5.0, budget_s - (time.time() - t0)) / max(1, len(coins) - i), log, jetzt)
                erg[coin] = {"kerzen": k, "funding": f}
        finally:
            meta_setzen(con, "laeuft", "")
            meta_setzen(con, "geladen", str(int(time.time())))
    finally:
        con.close()
    return {"uebersprungen": False, "coins": erg}


def bedarf(pfad: str, coins=COINS, jetzt: int | None = None) -> bool:
    """Fehlt die letzte abgeschlossene Kerze bei einem Coin (oder gibt es die Datei noch nicht)?"""
    if not os.path.exists(pfad):
        return True
    jetzt = int(jetzt or time.time()); letzte_zu = (jetzt // BAR) * BAR - BAR
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=5)
        try:
            for c in coins:
                if con.execute("SELECT v FROM sw_meta WHERE k=?", (f"keine:{c}",)).fetchone():
                    continue
                m = con.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=?", (c,)).fetchone()[0]
                if m is None or int(m) < letzte_zu:
                    return True
        finally:
            con.close()
    except sqlite3.Error:
        return True
    return False


_TAKT = {"gestartet": False, "letzter": None, "fehler": None, "laeuft": False}


def starten(db: str) -> bool:
    """Daten-Takt im Dashboard-Prozess: alle 5 min prüfen, ob Kerzen fehlen, dann ergänzen (je Runde höchstens 4 min). Nicht für
    Selbsttest-Datenbanken, aus mit HL_SWING=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_SWING") == "0":
        return False
    _TAKT["gestartet"] = True
    pfad = swing_pfad(db)

    def schleife():
        time.sleep(60)
        while True:
            try:
                if bedarf(pfad):
                    _TAKT["laeuft"] = True
                    erg = laden(pfad, budget_s=LADE_BUDGET_TAKT, log=lambda *a: None)
                    _TAKT["letzter"] = {"ts": int(time.time()), "erg": erg}; _TAKT["fehler"] = None
            except Exception as e:
                _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Swing-Takt: {_TAKT['fehler']}", flush=True)
            finally:
                _TAKT["laeuft"] = False
            time.sleep(TAKT_S)
    threading.Thread(target=schleife, daemon=True, name="swing").start()
    return True


# ================================================================================================ Tageskerzen und Kennzahlen

def tagesreihen(K: dict) -> dict | None:
    """
    30-min-Kerzen -> UTC-Tage. Schluss = Schluss der 23:30-Kerze, Eröffnung = Eröffnung der 00:00-Kerze, Hoch/Tief über alle Kerzen
    des Tages, RV = Summe der quadrierten 30-min-Renditen (nur bei 30 min Abstand), auf 48 hochgerechnet ab 40 gültigen. Ein Tag ist
    „voll“ mit ≥ 40 Kerzen, der 00:00- und der 23:30-Kerze. Die Kerzen bleiben für die Ausführung erhalten.
    """
    ts = np.asarray(K["ts"], dtype=np.int64)
    o, h, l, c = (np.asarray(K[k], dtype=float) for k in ("o", "h", "l", "c"))
    ok = np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c) & (o > 0) & (h > 0) & (l > 0) & (c > 0)
    ts, o, h, l, c = ts[ok], o[ok], h[ok], l[ok], c[ok]
    s = np.argsort(ts, kind="stable"); ts, o, h, l, c = ts[s], o[s], h[s], l[s], c[s]
    eind = np.concatenate([[True], np.diff(ts) > 0]) if len(ts) else np.zeros(0, dtype=bool)
    ts, o, h, l, c = ts[eind], o[eind], h[eind], l[eind], c[eind]
    if not len(ts):
        return None
    h = np.maximum(h, np.maximum(o, c)); l = np.minimum(l, np.minimum(o, c))
    tag = ts // TAG; d0 = int(tag[0]); di = (tag - d0).astype(np.int64); nd = int(di[-1]) + 1
    idx = np.arange(nd)
    i0 = np.searchsorted(di, idx, side="left"); i1 = np.searchsorted(di, idx, side="right")
    nb = i1 - i0
    T_o = np.full(nd, np.nan); T_c = np.full(nd, np.nan); T_h = np.full(nd, np.nan); T_l = np.full(nd, np.nan)
    erste = (ts % TAG) == 0; letzte = (ts % TAG) == TAG - BAR
    T_o[di[erste]] = o[erste]; T_c[di[letzte]] = c[letzte]
    hat = nb > 0
    if hat.any():
        T_h[hat] = np.maximum.reduceat(h, i0[hat]); T_l[hat] = np.minimum.reduceat(l, i0[hat])
    r = np.zeros(len(ts)); r[1:] = np.diff(np.log(c))
    rv_ok = np.zeros(len(ts), dtype=bool); rv_ok[1:] = np.diff(ts) == BAR
    summe = np.bincount(di, weights=np.where(rv_ok, r * r, 0.0), minlength=nd)
    anz = np.bincount(di, weights=rv_ok.astype(float), minlength=nd)
    with np.errstate(divide="ignore", invalid="ignore"):
        RV = np.where(anz >= 40, summe * BARS_TAG / np.maximum(anz, 1), np.nan)
    voll = (nb >= 40) & np.isfinite(T_o) & np.isfinite(T_c)
    return {"d0": d0, "nd": nd, "tag_ts": (d0 + idx) * TAG, "o": T_o, "h": T_h, "l": T_l, "c": T_c, "RV": RV, "voll": voll,
            "nb": nb, "i0": i0, "i1": i1, "bar_ts": ts, "bar_o": o, "bar_h": h, "bar_l": l, "bar_c": c}


def sigma_tag(RV: np.ndarray, hwz: float = HWZ) -> np.ndarray:
    """σ_Tag am Schluss von Tag d: EWMA der gültigen Tages-RV einschließlich d (Halbwertszeit hwz); Tage ohne RV tragen den
    letzten Wert weiter."""
    lam = 0.5 ** (1.0 / hwz)
    out = np.full(len(RV), np.nan); e = None
    for d, v in enumerate(RV):
        if np.isfinite(v):
            e = float(v) if e is None else lam * e + (1 - lam) * float(v)
        if e is not None:
            out[d] = e
    return np.sqrt(out)


def funding_tage(T: dict, F: dict) -> np.ndarray:
    """Tagesmittel der Funding-Raten mit Zeitpunkt im Tag [00:00, 24:00) -- am Tagesschluss bekannt."""
    fd = np.full(T["nd"], np.nan)
    if F is None or not len(F["ts"]):
        return fd
    a = np.searchsorted(F["ts"], T["tag_ts"], side="left"); b = np.searchsorted(F["ts"], T["tag_ts"] + TAG, side="left")
    cs = np.concatenate([[0.0], np.cumsum(F["rate"])])
    n = b - a
    ok = n > 0
    fd[ok] = (cs[b[ok]] - cs[a[ok]]) / n[ok]
    return fd


def _roll(a: np.ndarray, n: int, fn, mit_heute: bool) -> np.ndarray:
    """fn über [d−n, d−1] (mit_heute False) bzw. [d−n+1, d]; nur bei vollständig endlichem Fenster."""
    out = np.full(len(a), np.nan)
    for d in range(len(a)):
        lo, hi = (d - n + 1, d + 1) if mit_heute else (d - n, d)
        if lo < 0:
            continue
        w = a[lo:hi]
        if np.all(np.isfinite(w)):
            out[d] = fn(w)
    return out


class Kennzahlen:
    """Kennzahlen je Tag, bei Bedarf berechnet und gemerkt. Jede nutzt nur Tage bis d (Kanäle nur die Tage davor)."""

    def __init__(self, T: dict, F: dict | None = None):
        self.T = T; self.F = F; self._c: dict = {}
        self.sig = sigma_tag(T["RV"])

    def _m(self, key, fn):
        if key not in self._c:
            self._c[key] = fn()
        return self._c[key]

    def hh(self, n: int):
        return self._m(("hh", n), lambda: _roll(self.T["h"], n, np.max, False))

    def ll(self, n: int):
        return self._m(("ll", n), lambda: _roll(self.T["l"], n, np.min, False))

    def sma(self, n: int):
        return self._m(("sma", n), lambda: _roll(self.T["c"], n, np.mean, True))

    def maxc(self, n: int):
        return self._m(("maxc", n), lambda: _roll(self.T["c"], n, np.max, True))

    def minc(self, n: int):
        return self._m(("minc", n), lambda: _roll(self.T["c"], n, np.min, True))

    def vol(self, n: int):
        return self._m(("vol", n), lambda: np.sqrt(_roll(self.T["RV"], n, np.mean, True)))

    def ruhe(self, n: int, w: int, q: float):
        """1, wenn vol(n)[d] ≤ q-Quantil (linear) von vol(n) über [d−w, d−1] (mindestens 80 % endlich), sonst 0; NaN ohne Urteil."""
        def f():
            v = self.vol(n); out = np.full(len(v), np.nan)
            for d in range(len(v)):
                if d - w < 0 or not np.isfinite(v[d]):
                    continue
                hist = v[d - w:d]; hist = hist[np.isfinite(hist)]
                if len(hist) < 0.8 * w:
                    continue
                out[d] = 1.0 if v[d] <= np.quantile(hist, q) else 0.0
            return out
        return self._m(("ruhe", n, w, q), f)

    def rk(self, n: int):
        def f():
            c = self.T["c"]; out = np.full(len(c), np.nan)
            out[n:] = np.log(c[n:] / c[:-n])
            return out
        return self._m(("rk", n), f)

    def fz(self, w: int):
        """Funding-Druck: (Tagesmittel − Mittel der w Tage davor) / deren Standardabweichung; mindestens 2/3 der Tage endlich."""
        def f():
            fd = funding_tage(self.T, self.F); out = np.full(len(fd), np.nan)
            for d in range(len(fd)):
                if d - w < 0 or not np.isfinite(fd[d]):
                    continue
                hist = fd[d - w:d]; hist = hist[np.isfinite(hist)]
                if len(hist) < (2 * w) // 3:
                    continue
                sd = float(np.std(hist, ddof=1))
                if sd > 0:
                    out[d] = (fd[d] - float(hist.mean())) / sd
            return out
        return self._m(("fz", w), f)


# ================================================================================================ Einstieg und Nachführen (Historie UND Labor)

def _trend(R: dict, T: dict, I: Kennzahlen, d: int) -> int:
    """+1 Aufwärtstrend (kurzes Mittel > langes und Schluss > langes), −1 abwärts gespiegelt, 0 sonst."""
    k, g = I.sma(R["sma_kurz"])[d], I.sma(R["sma_lang"])[d]; c = T["c"][d]
    if not (np.isfinite(k) and np.isfinite(g) and np.isfinite(c)):
        return 0
    if k > g and c > g:
        return 1
    if k < g and c < g:
        return -1
    return 0


def ausstieg_parameter(R: dict, T: dict, I: Kennzahlen, d: int, seite: str) -> dict | None:
    """Stop, Ziel und Höchstdauer einer Position, die zum Schluss von Tag d beschlossen wird -- dieselben für Signal, Placebo und
    Labor. Ziel = (Niveau, Mindestabstand in σ) oder keins."""
    s = I.sig[d]
    if not np.isfinite(s) or s <= 0:
        return None
    art = R["art"]; out = {"sigma": float(s), "stop": R["stop"], "max_tage": int(R["max_tage"]), "ziel_level": None, "ziel_min": None}
    if art in ("ruecksetzer", "ruecksetzer_zufall"):
        lev = I.maxc(R["hoch_tage"])[d] if seite == "long" else I.minc(R["hoch_tage"])[d]
        if not np.isfinite(lev):
            return None
        out.update(ziel_level=float(lev), ziel_min=R["ziel_min"])
    elif art == "gegenbewegung":
        c, c0 = T["c"][d], T["c"][d - R["tage"]] if d >= R["tage"] else np.nan
        if not (np.isfinite(c) and np.isfinite(c0)):
            return None
        out.update(ziel_level=float(c + R["ziel_anteil"] * (c0 - c)), ziel_min=R["ziel_min"])
    return out


def einstieg(R: dict, T: dict, I: Kennzahlen, d: int, u=None) -> dict | None:
    """
    Einstieg am Schluss von Tag d (ausgeführt zur nächsten Eröffnung) oder None. u = (u1, u2) gleichverteilt für die Kontrollen
    (u1 < p_tag: Einstieg, u2 < 0,5: Long). Liefert Seite, Ausstiegsparameter, Grund und Werte.
    """
    if d < 1 or d >= T["nd"] or not T["voll"][d]:
        return None
    art = R["art"]; c = float(T["c"][d]); s = I.sig[d]
    if not np.isfinite(s) or s <= 0:
        return None
    seite = None; grund = ""; werte = {"schluss": c, "sigma": round(float(s), 6)}
    if art == "trend":
        hh, ll = I.hh(R["kanal_ein"])[d], I.ll(R["kanal_ein"])[d]
        if not (np.isfinite(hh) and np.isfinite(ll)):
            return None
        if c > hh:
            seite, grund = "long", f"Schluss {c:.6g} über dem {R['kanal_ein']}-Tage-Hoch {hh:.6g}"
        elif c < ll:
            seite, grund = "short", f"Schluss {c:.6g} unter dem {R['kanal_ein']}-Tage-Tief {ll:.6g}"
        werte.update(hoch=float(hh), tief=float(ll))
    elif art == "ruecksetzer":
        tr = _trend(R, T, I, d)
        if tr > 0:
            hoch = I.maxc(R["hoch_tage"])[d]; tiefe = math.log(hoch / c) / s
            if tiefe >= R["tiefe"]:
                seite, grund = "long", f"Aufwärtstrend, Rücksetzer {tiefe:.1f} σ unter dem {R['hoch_tage']}-Tage-Hoch {hoch:.6g}"
            werte.update(niveau=float(hoch), tiefe_sigma=round(tiefe, 2))
        elif tr < 0:
            tief = I.minc(R["hoch_tage"])[d]; tiefe = math.log(c / tief) / s
            if tiefe >= R["tiefe"]:
                seite, grund = "short", f"Abwärtstrend, Erholung {tiefe:.1f} σ über dem {R['hoch_tage']}-Tage-Tief {tief:.6g}"
            werte.update(niveau=float(tief), tiefe_sigma=round(tiefe, 2))
    elif art == "kompression":
        ru = I.ruhe(R["vol_tage"], R["perz_tage"], R["perz"])[d - 1]
        if ru != 1.0:
            return None
        hh, ll = I.hh(R["kanal"])[d], I.ll(R["kanal"])[d]
        if not (np.isfinite(hh) and np.isfinite(ll)):
            return None
        if c > hh:
            seite, grund = "long", f"nach Ruhe (Schwankung 10 T im untersten Fünftel) Schluss über dem {R['kanal']}-Tage-Hoch {hh:.6g}"
        elif c < ll:
            seite, grund = "short", f"nach Ruhe Schluss unter dem {R['kanal']}-Tage-Tief {ll:.6g}"
        werte.update(hoch=float(hh), tief=float(ll))
    elif art == "gegenbewegung":
        r = I.rk(R["tage"])[d]; fz = I.fz(R["funding_tage"])[d]
        if not (np.isfinite(r) and np.isfinite(fz)):
            return None
        z = r / (s * math.sqrt(R["tage"]))
        if z <= -R["z"] and fz <= -R["funding_z"]:
            seite, grund = "long", f"3 Tage {r * 100:+.1f} % ({z:+.1f} σ), Funding-Druck {fz:+.1f} SD -- Gegenbewegung"
        elif z >= R["z"] and fz >= R["funding_z"]:
            seite, grund = "short", f"3 Tage {r * 100:+.1f} % ({z:+.1f} σ), Funding-Druck {fz:+.1f} SD -- Gegenbewegung"
        werte.update(z3=round(z, 2), funding_z=round(float(fz), 2))
    elif art == "zufall":
        if u is None or u[0] >= R["p_tag"]:
            return None
        seite = "long" if u[1] < 0.5 else "short"; grund = "Zufall (Kontrolle, Ausstiege wie S1)"
    elif art == "ruecksetzer_zufall":
        tr = _trend(R, T, I, d)
        if tr == 0 or u is None or u[0] >= R["p_tag"]:
            return None
        seite = "long" if tr > 0 else "short"; grund = f"Zufall im {'Aufwärts' if tr > 0 else 'Abwärts'}trend (Kontrolle, Ausstiege wie S2)"
    if seite is None:
        return None
    ap = ausstieg_parameter(R, T, I, d, seite)
    if ap is None:
        return None
    return dict(ap, seite=seite, grund=grund, werte=werte)


def nachfuehren(R: dict, T: dict, I: Kennzahlen, d: int, pos: dict) -> dict:
    """
    Am Schluss von Tag d für eine offene Position {seite, e = Index des Einstiegstags, sl}: {"aus": True, "grund"} (Ausstieg zur
    nächsten Eröffnung), {"sl": neuer Stop, "grund"} (nur in Gewinnrichtung) oder {}. Vor dem Einstiegstag nichts.
    """
    if d < pos["e"] or d >= T["nd"] or not T["voll"][d]:
        return {}
    art = R["art"]; long = pos["seite"] == "long"; c = T["c"][d]
    if art in ("trend", "zufall"):
        n = R["kanal_aus"]
        g = I.ll(n)[d] if long else I.hh(n)[d]
        if np.isfinite(g) and ((long and c < g) or (not long and c > g)):
            return {"aus": True, "grund": f"Schluss {c:.6g} {'unter dem' if long else 'über dem'} {n}-Tage-{'Tief' if long else 'Hoch'} {g:.6g}"}
    if "trail" in R:
        s = I.sig[d]
        w = T["c"][pos["e"]:d + 1]; w = w[np.isfinite(w)]
        if len(w) and np.isfinite(s):
            if long:
                neu = float(w.max()) * math.exp(-R["trail"] * s)
                if pos["sl"] is None or neu > pos["sl"]:
                    return {"sl": neu, "grund": f"Nachzieh-Stop {R['trail']:g} σ unter dem besten Schluss {w.max():.6g}"}
            else:
                neu = float(w.min()) * math.exp(R["trail"] * s)
                if pos["sl"] is None or neu < pos["sl"]:
                    return {"sl": neu, "grund": f"Nachzieh-Stop {R['trail']:g} σ über dem besten Schluss {w.min():.6g}"}
    return {}


def plan(sig: dict, px: float) -> dict:
    """Stop, Ziel, Notional und Risiko einer Position bei Einstiegskurs px: Stop sigma·k, Ziel = max(Niveau, px·e^{m σ}) (Short
    gespiegelt), Notional = Risiko ÷ Stop-Abstand, höchstens NOTIONAL_MAX."""
    s = sig["sigma"]; long = sig["seite"] == "long"; k = sig["stop"]
    sl = px * math.exp(-k * s) if long else px * math.exp(k * s)
    tp = None
    if sig.get("ziel_min") is not None:
        mind = px * math.exp(sig["ziel_min"] * s) if long else px * math.exp(-sig["ziel_min"] * s)
        lev = sig.get("ziel_level")
        tp = mind if lev is None or not np.isfinite(lev) else (max(lev, mind) if long else min(lev, mind))
    frac = abs(1.0 - sl / px)
    nt = min(NOTIONAL_MAX, RISIKO_USD / frac) if frac > 0 else NOTIONAL_MAX
    return {"sl": sl, "tp": tp, "notional": nt, "risiko": nt * frac}


def tag_index(T: dict, ts: int) -> int:
    return int(ts // TAG) - int(T["d0"])


# ================================================================================================ Handelssimulation (Historie)

def _funding_summe(F: dict | None, t_a: int, t_b: int) -> float:
    if F is None or not len(F["ts"]) or t_b <= t_a:
        return 0.0
    if "_cs" not in F:
        F["_cs"] = np.concatenate([[0.0], np.cumsum(F["rate"])])
    a = int(np.searchsorted(F["ts"], t_a, side="right")); b = int(np.searchsorted(F["ts"], t_b, side="right"))
    return float(F["_cs"][b] - F["_cs"][a])


def _eroeffnung_ab(T: dict, k: int) -> int | None:
    """Index der ersten Kerze ab Tag k (Ausstieg zur Eröffnung)."""
    for kk in range(k, T["nd"]):
        if T["i1"][kk] > T["i0"][kk]:
            return int(T["i0"][kk])
    return None


def handel(coin: str, R: dict, T: dict, F: dict | None, I: Kennzahlen, e: int, sig: dict, mtm: bool = True) -> dict | None:
    """
    Ein Trade ab der Eröffnung von Tag e (beschlossen am Schluss von e−1). Stop in jeder Kerze (Lücke: Eröffnung der Kerze), Ziel als
    Limit (Maker; in der Einstiegskerze nur der Stop; Stop und Ziel in einer Kerze: Stop), am Tagesschluss Zeit- und Signal-Ausstieg
    zur nächsten Eröffnung, Nachzieh-Stop ab dem nächsten Tag. Funding je Zahlung auf das Notional. frei_ab = Tag, an dessen Schluss
    die Strategie wieder entscheiden darf.
    """
    nd = T["nd"]
    if e >= nd or T["i1"][e] <= T["i0"][e] or int(T["bar_ts"][T["i0"][e]]) != int(T["tag_ts"][e]):
        return None
    b0 = int(T["i0"][e]); long = sig["seite"] == "long"; sv = 1.0 if long else -1.0
    slip = SLIP_BPS.get(coin, SLIP_STANDARD) / 1e4
    px_in = float(T["bar_o"][b0]) * (1 + sv * slip)
    P = plan(sig, px_in); sl, tp, nt = P["sl"], P["tp"], P["notional"]; menge = nt / px_in
    f_t, f_m = gebuehr(coin, GEB_TAKER), gebuehr(coin, GEB_MAKER)
    geb_ein = nt * f_t; t_in = int(T["bar_ts"][b0])
    werte = []; nachgezogen = 0; ende = None; k = e; offen_am_ende = False
    while k < nd:
        a = b0 if k == e else int(T["i0"][k]); z = int(T["i1"][k])
        if z > a:
            if long:
                hs = T["bar_l"][a:z] <= sl
                ht = (T["bar_h"][a:z] >= tp) if tp is not None else None
            else:
                hs = T["bar_h"][a:z] >= sl
                ht = (T["bar_l"][a:z] <= tp) if tp is not None else None
            if ht is not None and k == e:
                ht = ht.copy(); ht[0] = False                                    # Einstiegskerze: nur der Stop
            js = int(np.argmax(hs)) if hs.any() else None
            jt = int(np.argmax(ht)) if (ht is not None and ht.any()) else None
            if js is not None and (jt is None or js <= jt):
                j = a + js
                o_ = px_in / (1 + sv * slip) if j == b0 else float(T["bar_o"][j])
                mitte = min(o_, sl) if long else max(o_, sl)
                px = mitte * (1 - sv * slip)
                ende = (px, f_t, "Nachzieh-Stop" if nachgezogen else "Stop", int(T["bar_ts"][j]) + BAR, k, mitte)
                break
            if jt is not None:
                j = a + jt
                ende = (tp, f_m, "Ziel", int(T["bar_ts"][j]) + BAR, k, tp)
                break
        schluss = float(T["c"][k]) if np.isfinite(T["c"][k]) else (float(T["bar_c"][z - 1]) if z > a else None)
        if mtm and schluss is not None:
            t_k = int(T["tag_ts"][k]) + TAG
            werte.append((k, sv * (schluss - px_in) * menge - geb_ein - sv * nt * _funding_summe(F, t_in, t_k)))
        if k + 1 >= nd:
            offen_am_ende = True
            break
        if T["voll"][k]:
            grund = None
            if k + 1 - e >= int(sig.get("max_tage") or R["max_tage"]):
                grund = "Zeit"
            else:
                res = nachfuehren(R, T, I, k, {"seite": sig["seite"], "e": e, "sl": sl})
                if res.get("aus"):
                    grund = "Signal"
                elif res.get("sl") is not None:
                    sl = res["sl"]; nachgezogen += 1
            if grund:
                j = _eroeffnung_ab(T, k + 1)
                if j is None:
                    offen_am_ende = True
                    break
                px = float(T["bar_o"][j]) * (1 - sv * slip)
                ende = (px, f_t, grund, int(T["bar_ts"][j]), k + 1, float(T["bar_o"][j]))
                k_frei = k
                break
        k += 1
    if offen_am_ende or ende is None:
        k_last = min(k, nd - 1)
        z = int(T["i1"][k_last])
        px = float(T["c"][k_last]) if np.isfinite(T["c"][k_last]) else float(T["bar_c"][max(z - 1, b0)])
        ende = (px, 0.0, "offen am Ende", int(T["tag_ts"][k_last]) + TAG, k_last, px)
        frei_ab = nd
    elif ende[2] in ("Zeit", "Signal"):
        frei_ab = k_frei
    else:
        frei_ab = ende[4]
    px_out, f_out, grund_aus, t_out, x_tag, mitte_aus = ende
    brutto = sv * (px_out - px_in) * menge
    kurs = sv * (mitte_aus - float(T["bar_o"][b0])) * menge                 # nur Kurs: Mitte zu Mitte, vor Abstand, Gebühren, Funding
    geb_aus = menge * px_out * f_out
    fund = sv * nt * _funding_summe(F, t_in, t_out)
    netto = brutto - geb_ein - geb_aus - fund
    tr = {"coin": coin, "seite": sig["seite"], "e": e, "t_in": t_in, "px_in": px_in, "t_out": t_out, "px_out": px_out, "x_tag": x_tag,
          "grund": grund_aus, "notional": nt, "risiko": P["risiko"], "brutto": brutto, "gebuehren": geb_ein + geb_aus, "funding": fund,
          "netto": netto, "R": netto / P["risiko"] if P["risiko"] > 0 else 0.0, "tage": (t_out - t_in) / TAG, "frei_ab": frei_ab,
          "nachgezogen": nachgezogen, "kurs": kurs, "R_kurs": kurs / P["risiko"] if P["risiko"] > 0 else 0.0}
    if mtm:
        inc = []; vorher = 0.0
        for kk, v in werte:
            if kk >= x_tag and grund_aus != "offen am Ende":
                break
            inc.append((kk, v - vorher)); vorher = v
        if grund_aus != "offen am Ende":
            inc.append((x_tag, netto - vorher))
        tr["pnl"] = inc
    return tr


def bewertungsbereich(T: dict, I: Kennzahlen) -> tuple:
    """Erster bewerteter Tag: VORLAUF_TAGE nach Datenbeginn (alle Kennzahlen stehen), letzter: der vorletzte Tag (Einstieg braucht
    den Folgetag)."""
    return VORLAUF_TAGE, T["nd"] - 2


def lauf(coin: str, R: dict, T: dict, F: dict | None, I: Kennzahlen, d_von: int, d_bis: int, mtm: bool = True) -> dict:
    """Die Strategie Tag für Tag: am Schluss eines vollen Tags ohne Position entscheiden, Trade simulieren, ab frei_ab weiter."""
    trades = []; flach = 0; flach_trend = 0; d = d_von
    while d <= d_bis:
        if not T["voll"][d]:
            d += 1; continue
        flach += 1
        if R["art"] in ("ruecksetzer", "ruecksetzer_zufall") and _trend(R, T, I, d) != 0:
            flach_trend += 1
        sig = einstieg(R, T, I, d)
        if sig is None:
            d += 1; continue
        tr = handel(coin, R, T, F, I, d + 1, sig, mtm)
        if tr is None:
            d += 1; continue
        trades.append(tr)
        d = tr["frei_ab"] if tr["frei_ab"] > d else d + 1
    return {"trades": trades, "flach": flach, "flach_trend": flach_trend}


def lauf_placebo(coin: str, R: dict, T: dict, F: dict | None, I: Kennzahlen, d_von: int, d_bis: int, q: float, p_long: float,
                 rng: np.random.Generator) -> list:
    """Zeitpunkt-Placebo: an flachen vollen Tagen mit Wahrscheinlichkeit q Einstieg (S2: nur an Trendtagen, Seite = Trend; sonst
    Long mit p_long), Ausstiege wie die Strategie. Liefert je Trade (R netto, R nur Kurs)."""
    nd = T["nd"]; U = rng.random(nd); S = rng.random(nd); rs = []; frei = d_von
    trend_art = R["art"] in ("ruecksetzer", "ruecksetzer_zufall")
    for d in np.nonzero(U < q)[0]:
        d = int(d)
        if d < frei or d < d_von or d > d_bis or not T["voll"][d]:
            continue
        if trend_art:
            tr_ = _trend(R, T, I, d)
            if tr_ == 0:
                continue
            seite = "long" if tr_ > 0 else "short"
        else:
            seite = "long" if S[d] < p_long else "short"
        ap = ausstieg_parameter(R, T, I, d, seite)
        if ap is None:
            continue
        tr = handel(coin, R, T, F, I, d + 1, dict(ap, seite=seite), mtm=False)
        if tr is None:
            continue
        rs.append((tr["R"], tr["R_kurs"])); frei = tr["frei_ab"] if tr["frei_ab"] > d else d + 1
    return rs


# ================================================================================================ Vorprüfung: Rechnung und Urteil

def _schiefe_kurt(x: np.ndarray) -> tuple:
    x = np.asarray(x, dtype=float); m = x.mean(); s = x.std()
    if s <= 0:
        return 0.0, 3.0
    z = (x - m) / s
    return float(np.mean(z ** 3)), float(np.mean(z ** 4))


def strategie_rechnen(name: str, daten: dict, n_placebo: int = N_PLACEBO, seed: int = 1, mtm: bool = True) -> dict:
    """Eine Strategie auf allen Coins: Trades, Tagesergebnis (Mark-to-Market), Kennzahlen, Zeitpunkt-Placebo."""
    R = STRATEGIEN[name]; trades = []; je_coin = {}; pnl: dict = {}; tage_von = None; tage_bis = None
    for coin, D in daten.items():
        T, F, I = D["T"], D["F"], D["I"]
        d_von, d_bis = bewertungsbereich(T, I)
        if d_bis - d_von < 30:
            continue
        L = lauf(coin, R, T, F, I, d_von, d_bis, mtm)
        tr = L["trades"]; trades += tr
        n_long = sum(1 for t in tr if t["seite"] == "long")
        flach = L["flach_trend"] if R["art"] in ("ruecksetzer", "ruecksetzer_zufall") else L["flach"]
        je_coin[coin] = {"n": len(tr), "flach": flach, "q": (len(tr) / flach) if flach else 0.0,
                         "p_long": (n_long / len(tr)) if tr else 0.5, "d_von": d_von, "d_bis": d_bis,
                         "von_ts": int(T["tag_ts"][d_von]), "bis_ts": int(T["tag_ts"][d_bis]),
                         "summe_R": float(sum(t["R"] for t in tr)), "summe_usd": float(sum(t["netto"] for t in tr)),
                         "treffer": (sum(1 for t in tr if t["netto"] > 0) / len(tr)) if tr else None,
                         "markt": float(math.log(T["c"][d_bis] / T["c"][d_von])) if np.isfinite(T["c"][d_bis]) and np.isfinite(T["c"][d_von]) else None}
        a_tag = int(T["d0"]) + d_von; b_tag = int(T["d0"]) + d_bis + 1
        tage_von = a_tag if tage_von is None else min(tage_von, a_tag)
        tage_bis = b_tag if tage_bis is None else max(tage_bis, b_tag)
        if mtm:
            for t in tr:
                for kk, v in t.get("pnl", []):
                    tag = int(T["d0"]) + kk
                    pnl[tag] = pnl.get(tag, 0.0) + v
    out = {"name": name, "trades": trades, "je_coin": je_coin, "n": len(trades)}
    if tage_von is None:
        return out
    tage = np.arange(tage_von, tage_bis + 1)
    reihe = np.array([pnl.get(int(t), 0.0) for t in tage])
    out.update(tage=tage, reihe=reihe)
    Rs = np.array([t["R"] for t in trades]) if trades else np.zeros(0)
    out["mittel_R"] = float(Rs.mean()) if len(Rs) else float("nan")
    # Zerlegung je Trade in R: Kurs (Mitte zu Mitte) − Abstand zur Mitte − Gebühren − Funding = netto
    if trades:
        out["zerlegung"] = {"kurs": float(np.mean([t["R_kurs"] for t in trades])),
                            "abstand": float(np.mean([(t["kurs"] - t["brutto"]) / t["risiko"] for t in trades])),
                            "gebuehren": float(np.mean([t["gebuehren"] / t["risiko"] for t in trades])),
                            "funding": float(np.mean([t["funding"] / t["risiko"] for t in trades]))}
    out["se_R"] = float(Rs.std(ddof=1) / math.sqrt(len(Rs))) if len(Rs) > 1 else float("nan")
    out["hac"] = RG.mittel_test(reihe, HAC_LAG)
    sd = float(reihe.std(ddof=1)) if len(reihe) > 1 else 0.0
    out["sr_tag"] = float(reihe.mean() / sd) if sd > 0 else float("nan")
    out["sharpe_jahr"] = out["sr_tag"] * math.sqrt(365) if np.isfinite(out["sr_tag"]) else float("nan")
    out["schiefe"], out["kurt"] = _schiefe_kurt(reihe) if len(reihe) > 2 else (0.0, 3.0)
    h = len(reihe) // 2
    out["haelften"] = (float(reihe[:h].sum()), float(reihe[h:].sum()))
    kum = np.cumsum(reihe); out["max_dd"] = float(np.max(np.maximum.accumulate(kum) - kum)) if len(kum) else 0.0
    # Zeitpunkt-Placebo
    if n_placebo and trades:
        rng = np.random.default_rng(seed); mittel = []; mittel_k = []
        for _ in range(n_placebo):
            rs = []
            for coin, D in daten.items():
                jc = je_coin.get(coin)
                if not jc or not jc["n"]:
                    continue
                rs += lauf_placebo(coin, R, D["T"], D["F"], D["I"], jc["d_von"], jc["d_bis"], jc["q"], jc["p_long"], rng)
            mittel.append(float(np.mean([x[0] for x in rs])) if rs else float("nan"))
            mittel_k.append(float(np.mean([x[1] for x in rs])) if rs else float("nan"))
        m = np.array(mittel); ok_ = np.isfinite(m); m = m[ok_]; mk = np.array(mittel_k)[ok_]
        se_s = _se_je_trade(out)
        v = _mehrertrag(out["mittel_R"], se_s, m, len(reihe)); vk = _mehrertrag(out["zerlegung"]["kurs"], se_s, mk, len(reihe))
        out["placebo"] = {"n": len(m), "median": float(np.median(m)) if len(m) else float("nan"),
                          "q05": float(np.quantile(m, 0.05)) if len(m) else float("nan"),
                          "q95": float(np.quantile(m, 0.95)) if len(m) else float("nan"),
                          "mehr": v["mehr"], "se": v["se"], "t": v["t"], "p": v["p"],
                          # beschreibend: Rang unter den Läufen (bis 23.61-Entwurf das Urteil; auf Nullmärkten nicht kalibriert, 6a)
                          "p_rang": float((1 + np.sum(m >= out["mittel_R"])) / (1 + len(m))) if len(m) else float("nan"),
                          # beschreibend: dasselbe nur mit dem Kurs (Mitte zu Mitte) -- kommt der Vorsprung aus dem Kurs oder aus Funding/Kosten?
                          "median_kurs": float(np.median(mk)) if len(mk) else float("nan"), "mehr_kurs": vk["mehr"], "p_kurs": vk["p"]}
    return out


def _se_je_trade(e: dict) -> float:
    """Standardfehler des mittleren R je Trade aus der Tagesreihe (HAC): gleichzeitige und überlappende Trades mehrerer Coins und
    die Schwankung je Lage gehen so ein, wie sie wirklich auftreten. SE(Ø R) = SE(Tagesmittel) · Tage ÷ (Trades · Risiko)."""
    h = e.get("hac") or {}; n = e.get("n") or 0
    if not n or not np.isfinite(h.get("se", float("nan"))):
        return float("nan")
    return float(h["se"]) * len(e["reihe"]) / (n * RISIKO_USD)


def _mehrertrag(mittel: float, se_s: float, m_pl: np.ndarray, tage: int) -> dict:
    """Mehrertrag je Trade gegen das Zeitpunkt-Placebo, studentisiert: (Ø R Strategie − Ø der Placebo-Mittel) ÷ √(SE² + SE_Placebo²),
    SE_Placebo = Streuung der Läufe ÷ √Läufe; p einseitig (t-Verteilung, Tage − 1). Ein Rang unter den Placebo-Läufen allein war auf
    Nullmärkten nicht kalibriert: Die Strategie wählt Lagen mit anderer Schwankung, ihr Mittel streut stärker als das der Läufe."""
    nan = float("nan")
    if not len(m_pl) or not np.isfinite(mittel) or not np.isfinite(se_s):
        return {"mehr": nan, "se": nan, "t": nan, "p": nan}
    mp = float(np.mean(m_pl)); se_p2 = float(np.var(m_pl, ddof=1)) / len(m_pl) if len(m_pl) > 1 else 0.0
    se = math.sqrt(se_s * se_s + se_p2)
    if se <= 0:
        return {"mehr": mittel - mp, "se": se, "t": nan, "p": nan}
    t = (mittel - mp) / se; p2 = RG.t_p2(t, max(1, tage - 1))
    return {"mehr": mittel - mp, "se": se, "t": t, "p": (p2 / 2 if t > 0 else 1 - p2 / 2) if np.isfinite(p2) else nan}


def urteil(E: dict) -> None:
    """Vorab festgelegt (KONZEPT_Swing.md 6): ≥ 60 Trades, Tagesergebnis HAC p < 0,05 und positiv, Placebo-p nach Holm < 0,05,
    beide Hälften positiv, Deflated Sharpe ≥ 0,95 über die vier Strategien. Schreibt je Strategie p_holm, dsr und belegt."""
    namen = [n for n in HAUPT if n in E]
    ps = [E[n].get("placebo", {}).get("p", float("nan")) for n in namen]
    srs = [E[n].get("sr_tag") for n in namen if np.isfinite(E[n].get("sr_tag", float("nan")))]
    for n, pa in zip(namen, RG.holm(ps)):
        e = E[n]; e["p_holm"] = pa
        if np.isfinite(e.get("sr_tag", float("nan"))) and len(srs) >= 2:
            e["dsr"] = RG._dsr(e["sr_tag"], len(e["reihe"]), e["schiefe"], e["kurt"], srs)
        else:
            e["dsr"] = float("nan")
        h = e.get("hac") or {}
        e["bedingungen"] = {
            "trades": e["n"] >= MIN_TRADES,
            "gewinn": bool(np.isfinite(h.get("p", float("nan"))) and h["p"] < ALPHA and h["mittel"] > 0),
            "placebo": bool(np.isfinite(pa) and pa < ALPHA),
            "haelften": bool(e.get("haelften") and min(e["haelften"]) > 0),
            "dsr": bool(np.isfinite(e["dsr"]) and e["dsr"] >= DSR_MIN)}
        e["belegt"] = all(e["bedingungen"].values())


def daten_aufbereiten(K: dict, F: dict | None) -> dict | None:
    T = tagesreihen(K)
    if T is None:
        return None
    return {"T": T, "F": F, "I": Kennzahlen(T, F)}


def vorpruefung_rechnen(roh: dict, n_placebo: int = N_PLACEBO, log=print, namen=HAUPT) -> dict:
    """roh = {coin: (Kerzen, Funding) oder None}. Rechnet alle vier Strategien, das Urteil und die Beschreibung."""
    t0 = time.time(); daten = {}; info = {}
    for coin, v in roh.items():
        if v is None or v[0] is None:
            info[coin] = {"status": "keine Historie"}
            continue
        D = daten_aufbereiten(v[0], v[1])
        if D is None or D["T"]["nd"] < VORLAUF_TAGE + 40:
            info[coin] = {"status": "zu kurz", "tage": D["T"]["nd"] if D else 0}
            continue
        T = D["T"]
        info[coin] = {"status": "ok", "von": int(T["tag_ts"][0]), "bis": int(T["tag_ts"][-1]), "tage": int(T["nd"]),
                      "kerzen": int(len(T["bar_ts"])), "luecken": int(np.sum(np.diff(T["bar_ts"]) > BAR)),
                      "funding": int(len(v[1]["ts"])) if v[1] is not None else 0,
                      "bewertet_ab": int(T["tag_ts"][VORLAUF_TAGE])}
        daten[coin] = D
    E = {}
    for i, n in enumerate(namen):
        log(f"  {KURZ[n]} …")
        E[n] = strategie_rechnen(n, daten, n_placebo, seed=11 + i)
    urteil(E)
    return {"E": E, "info": info, "rechenzeit": time.time() - t0, "n_placebo": n_placebo}


# ================================================================================================ Bericht

def _r(x, nd=2) -> str:
    return _de(x, nd, True) if x is not None and np.isfinite(x) else "—"


def bericht_text(V: dict, lade: dict | None = None, laufzeit: float | None = None) -> str:
    Z = []; a = Z.append
    E, info = V["E"], V["info"]
    a(f"★ Swing: Vorprüfung auf der Historie (U140) · Modul {VERSION_MODUL}")
    a("Vorab festgelegt in KONZEPT_Swing.md (08.10.2026), vor diesem Lauf. Nur Bericht: die Swing-Strategien im TradeLabor laufen")
    a("unabhängig davon vorwärts. „Belegt“ heißt: die vorab festgelegte Bedingung ist erfüllt, nicht mehr.")
    a(f"Rechenzeit {_de(V.get('rechenzeit'), 0)} s, Zeitpunkt-Placebo {V.get('n_placebo')} Läufe je Strategie"
      + (f", Laufzeit gesamt {_de(laufzeit, 0)} s" if laufzeit else "") + ".")
    a("")
    a("DATEN (eigene Datei swing.db: Binance-Futures USDT-Perpetual, 30-min-Kerzen ab 01.01.2020, Funding derselben Börse)")
    for c in COINS:
        v = info.get(c) or {"status": "nicht geladen"}
        ld = ((lade or {}).get(c) or {}).get("kerzen") or {}
        zusatz = " (Laden unvollständig)" if ld and not ld.get("fertig") else ""
        if v["status"] == "ok":
            a(f"  {c:<5} {_datum(v['von'])}–{_datum(v['bis'])}  {_tausend(v['tage'])} Tage  {_tausend(v['kerzen'])} Kerzen  Lücken "
              f"{v['luecken']}  Funding {_tausend(v['funding'])}  bewertet ab {_datum(v['bewertet_ab'])}{zusatz}")
        else:
            a(f"  {c:<5} {v['status']}{zusatz}")
    a("")
    a("PRÜFSTAND  (✓ belegt · – nicht belegt; Bedingungen: ≥ 60 Trades, Tagesergebnis p < 0,05, Placebo p Holm < 0,05, beide Hälften, DSR ≥ 0,95)")
    a(f"  {'Strategie':<38}{'Trades':>7}{'Treffer':>9}{'Ø R':>8}{'Summe R':>9}{'Sharpe/J':>9}{'p Tag':>8}{'Plac. p':>9}{'Hälften':>9}{'DSR':>6}  Urteil")
    for n in HAUPT:
        e = E.get(n)
        if not e or not e.get("n"):
            a(f"  {KURZ[n]:<38}{'0':>7}  keine Trades")
            continue
        tq = sum(1 for t in e["trades"] if t["netto"] > 0) / e["n"]
        b = e.get("bedingungen", {})
        hf = "+/+" if b.get("haelften") else ("/".join("+" if x > 0 else "−" for x in e["haelften"]) if e.get("haelften") else "—")
        a(f"  {KURZ[n]:<38}{e['n']:>7}{_de(tq * 100, 0) + ' %':>9}{_r(e['mittel_R']):>8}{_r(sum(t['R'] for t in e['trades']), 1):>9}"
          f"{_r(e.get('sharpe_jahr')):>9}{RG._pz((e.get('hac') or {}).get('p')):>8}{RG._pz(e.get('p_holm')):>9}{hf:>9}"
          f"{_de(e.get('dsr'), 2):>6}  {'✓ belegt' if e.get('belegt') else '–'}")
    for n in HAUPT:
        e = E.get(n)
        if not e or not e.get("n"):
            continue
        R = STRATEGIEN[n]; tr = e["trades"]
        a("")
        a(f"{KURZ[n].upper()} ({n})")
        nl = sum(1 for t in tr if t["seite"] == "long"); gew = [t["R"] for t in tr if t["netto"] > 0]; verl = [t["R"] for t in tr if t["netto"] <= 0]
        pf = (sum(t["netto"] for t in tr if t["netto"] > 0) / -sum(t["netto"] for t in tr if t["netto"] < 0)) if any(t["netto"] < 0 for t in tr) else None
        a(f"  {e['n']} Trades ({nl} Long, {e['n'] - nl} Short), Treffer {_de(len(gew) / e['n'] * 100, 0)} %, Gewinner Ø {_r(np.mean(gew) if gew else None)} R, "
          f"Verlierer Ø {_r(np.mean(verl) if verl else None)} R, Profitfaktor {_de(pf, 2)}, Ø Haltedauer {_de(np.mean([t['tage'] for t in tr]), 1)} Tage")
        a(f"  Ø R je Trade {_r(e['mittel_R'])} ± {_de(e['se_R'], 2)} · netto {_r(sum(t['netto'] for t in tr), 0)} USD bei 100 USD Risiko je Trade "
          f"(Gebühren {_de(sum(t['gebuehren'] for t in tr), 0)}, Funding {_r(-sum(t['funding'] for t in tr), 0)} USD) · größter Rückgang "
          f"{_de(e.get('max_dd'), 0)} USD")
        z = e.get("zerlegung") or {}
        if z:
            a(f"  Zerlegung je Trade: Kurs (Mitte zu Mitte) {_r(z['kurs'])} R, Abstand zur Mitte {_r(-z['abstand'])} R, Gebühren "
              f"{_r(-z['gebuehren'])} R, Funding {_r(-z['funding'])} R")
        h = e.get("hac") or {}
        a(f"  Tagesergebnis Ø {_r(h.get('mittel'))} USD ± {_de(h.get('se'), 2)} (HAC, Lag {HAC_LAG}), p {RG._pz(h.get('p'))}; Sharpe je Jahr "
          f"{_r(e.get('sharpe_jahr'))}; DSR {_de(e.get('dsr'), 2)}; Hälften {_r(e['haelften'][0], 0)} / {_r(e['haelften'][1], 0)} USD")
        P = e.get("placebo") or {}
        if P:
            a(f"  Zeitpunkt-Placebo (gleiche Coins, Rate, Long-Anteil{', nur Trendtage' if R['art'] == 'ruecksetzer' else ''}, gleiche Ausstiege): "
              f"Läufe Ø R Median {_r(P['median'])} (90 %: {_r(P['q05'])} … {_r(P['q95'])})")
            a(f"    Mehrertrag je Trade {_r(P.get('mehr'))} ± {_de(P.get('se'), 2)} R (SE aus der Tagesreihe), p {RG._pz(P['p'])}, p Holm "
              f"{RG._pz(e.get('p_holm'))}; Rang unter den Läufen {RG._pz(P.get('p_rang'))} (nur beschreibend)")
            a(f"    nur Kurs (beschreibend): Strategie {_r(z.get('kurs'))} R gegen Placebo-Median {_r(P.get('median_kurs'))} R, Mehrertrag "
              f"{_r(P.get('mehr_kurs'))} R, p {RG._pz(P.get('p_kurs'))} -- kommt ein Vorsprung aus dem Kurs oder aus Funding und Kosten?")
        gr: dict = {}
        for t in tr:
            gr[t["grund"]] = gr.get(t["grund"], 0) + 1
        a("  Ausstiege: " + ", ".join(f"{k} {v}" for k, v in sorted(gr.items(), key=lambda kv: -kv[1])))
        a("  Je Coin: " + "; ".join(f"{c} {jc['n']} Trades, Ø R {_r((jc['summe_R'] / jc['n']) if jc['n'] else None)}, Summe {_r(jc['summe_R'], 1)} R"
                                  for c, jc in e["je_coin"].items()))
        jahre: dict = {}
        for t in tr:
            j = time.gmtime(t["t_out"]).tm_year
            jahre.setdefault(j, []).append(t["R"])
        a("  Je Jahr (Ausstieg): " + "; ".join(f"{j} {len(v)} Trade{'' if len(v) == 1 else 's'}, Summe {_r(sum(v), 1)} R"
                                              for j, v in sorted(jahre.items())))
    a("")
    a("BEZUG: Kursveränderung im Bewertungszeitraum je Coin: " + ", ".join(
        f"{c} {_r((math.exp(jc['markt']) - 1) * 100 if jc.get('markt') is not None else None, 0)} %"
        for c, jc in (E.get(HAUPT[0], {}).get("je_coin") or {}).items()))
    a("")
    a("Lesart: Belegtes wird Kandidat für mehr Gewicht im Labor-Vergleich; Nicht-Belegtes läuft im Labor als Vorwärtsbeleg weiter")
    a("(KONZEPT_Swing.md 7). Ein Sharpe um 0,5 ist auf dieser Historie nicht nachweisbar -- „nicht belegt“ heißt nicht „wirkungslos“.")
    a("Placebo: Mehrertrag je Trade netto, studentisiert mit dem Standardfehler aus der Tagesreihe. Der bloße Rang unter den Läufen")
    a("war auf Nullmärkten nicht kalibriert -- die Strategien wählen Lagen mit anderer Schwankung (KONZEPT_Swing.md 6a). „Nur Kurs“")
    a("zeigt, ob ein Vorsprung aus dem Kurs kommt oder aus Funding und Kosten.")
    a("Echtes Geld nur nach belegter Historie und mindestens 6 Monaten Labor ohne Widerspruch, nie automatisch.")
    return "\n".join(Z)


def vorpruefung(db: str, n_placebo: int = N_PLACEBO, laden_vorher: bool = True, coins=COINS) -> str:
    t0 = time.time(); pfad = swing_pfad(db); lade = {}
    print(f"Swing-Vorprüfung: Daten in {pfad}", flush=True)
    if laden_vorher:
        erg = laden(pfad, coins, budget_s=420.0)
        if erg.get("uebersprungen"):
            print("  Laden übersprungen: ein anderer Ladevorgang läuft (Swing-Takt im Dashboard)", flush=True)
        lade = erg.get("coins") or {}
        for c, v in lade.items():
            k = v["kerzen"]
            print(f"  {c}: {_tausend(k.get('neu', 0))} neue Kerzen" + ("" if k.get("fertig") else " (noch nicht fertig)")
                  + (f" -- {k['fehler']}" if k.get("fehler") else "") + (" -- kein Symbol bei Binance-Futures" if k.get("keine") else ""), flush=True)
    con = verbinden(pfad)
    try:
        roh = {}
        for c in coins:
            K = kerzen_lesen(con, c)
            roh[c] = (K, funding_lesen(con, c)) if K is not None else None
    finally:
        con.close()
    print("Rechnen …", flush=True)
    V = vorpruefung_rechnen(roh, n_placebo, log=lambda s: print(s, flush=True))
    return bericht_text(V, lade, time.time() - t0)


# ================================================================================================ Labor-Anbindung

_LABOR_CACHE: dict = {}


def labor_daten(pfad: str, coin: str, now: int) -> dict:
    """
    Für hl_labor: Tageskerzen, Kennzahlen und der Entscheidungstag d (letzter voller Tag) eines Coins aus swing.db (nur lesend, die
    letzten LABOR_TAGE Tage bis zum Ende des letzten abgeschlossenen Tags). Neu gerechnet nur, wenn ein Tag abgeschlossen ist oder neues
    Funding für ihn kam -- einmal am Tag je Coin. frisch = d ist der gestrige UTC-Tag. Kerzen nach now zählen nicht (Selbsttest).
    """
    if not os.path.exists(pfad):
        return {"ok": False, "grund": "swing.db fehlt noch (der Swing-Takt lädt die Historie)"}
    bis = (int(now) // BAR) * BAR - BAR                                   # nur abgeschlossene Kerzen
    try:
        con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=5)
        try:
            stand = con.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=? AND ts<=?", (coin, bis)).fetchone()[0]
            if stand is None:
                return {"ok": False, "grund": f"noch keine Kerzen für {coin} in swing.db"}
            stand = int(stand)
            tag_ende = (stand // TAG + (1 if stand % TAG == TAG - BAR else 0)) * TAG      # Ende des letzten abgeschlossenen Tags
            fn = con.execute("SELECT COUNT(*) FROM sw_funding WHERE coin=? AND ts<?", (coin, tag_ende)).fetchone()[0]
            key = (tag_ende, int(fn))
            c_ = _LABOR_CACHE.get((pfad, coin))
            if c_ and c_[0] == key:
                D = c_[1]
            else:
                ab = tag_ende - LABOR_TAGE * TAG
                rows = con.execute("SELECT ts, o, h, l, c, v FROM sw_klines WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
                                   (coin, ab, tag_ende)).fetchall()
                if not rows:
                    return {"ok": False, "grund": f"noch kein abgeschlossener Tag für {coin} in swing.db"}
                a_ = np.array(rows, dtype=float)
                K = {"ts": a_[:, 0].astype(np.int64), "o": a_[:, 1], "h": a_[:, 2], "l": a_[:, 3], "c": a_[:, 4], "v": a_[:, 5]}
                fr = con.execute("SELECT ts, rate FROM sw_funding WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
                                 (coin, ab - 40 * TAG, tag_ende)).fetchall()
                fa = np.array(fr, dtype=float) if fr else np.zeros((0, 2))
                D = daten_aufbereiten(K, {"ts": fa[:, 0].astype(np.int64), "rate": fa[:, 1]})
                _LABOR_CACHE[(pfad, coin)] = (key, D)
        finally:
            con.close()
    except sqlite3.Error as e:
        return {"ok": False, "grund": f"swing.db nicht lesbar: {e}"}
    if D is None:
        return {"ok": False, "grund": "keine verwertbaren Kerzen"}
    T = D["T"]; volle = np.nonzero(T["voll"])[0]
    if not len(volle):
        return {"ok": False, "grund": "kein voller Tag"}
    d = int(volle[-1]); tag_ts = int(T["tag_ts"][d])
    heute = int(now) // TAG * TAG
    return {"ok": True, "T": T, "I": D["I"], "F": D["F"], "d": d, "tag_ts": tag_ts, "frisch": tag_ts == heute - TAG, "stand": stand,
            "sigma": float(D["I"].sig[d]) if np.isfinite(D["I"].sig[d]) else None}


def status_text(name: str, R: dict, W: dict, now: int) -> str:
    """Was die Swing-Strategie sieht (Live-Tafel)."""
    if not W or not W.get("ok"):
        return (W or {}).get("grund") or "keine Tageskerzen"
    T, I, d = W["T"], W["I"], W["d"]
    kopf = f"Tag {_datum(W['tag_ts'])}" + ("" if W["frisch"] else " (veraltet)") + f", σ {_de((W.get('sigma') or 0) * 100, 2)} %"
    c = T["c"][d]; art = R["art"]
    try:
        if art == "trend":
            return kopf + f" · Schluss {c:.6g}, Kanal {R['kanal_ein']} T {I.ll(R['kanal_ein'])[d]:.6g} – {I.hh(R['kanal_ein'])[d]:.6g}"
        if art in ("ruecksetzer", "ruecksetzer_zufall"):
            tr = _trend(R, T, I, d)
            t_txt = {1: "Aufwärtstrend", -1: "Abwärtstrend", 0: "kein Trend"}[tr]
            if tr and art == "ruecksetzer":
                lev = I.maxc(R["hoch_tage"])[d] if tr > 0 else I.minc(R["hoch_tage"])[d]
                tiefe = abs(math.log(lev / c)) / I.sig[d]
                return kopf + f" · {t_txt}, Abstand zum 10-T-{'Hoch' if tr > 0 else 'Tief'} {_de(tiefe, 1)} σ (ab {_de(R['tiefe'], 0)} σ)"
            return kopf + f" · {t_txt}" + (f", Zufall {R['p_tag'] * 100:.0f} % je Tag" if art != "ruecksetzer" else "")
        if art == "kompression":
            ru = I.ruhe(R["vol_tage"], R["perz_tage"], R["perz"])[d]
            return kopf + f" · {'Ruhe' if ru == 1.0 else 'keine Ruhe'}, Kanal {R['kanal']} T {I.ll(R['kanal'])[d]:.6g} – {I.hh(R['kanal'])[d]:.6g}"
        if art == "gegenbewegung":
            r = I.rk(R["tage"])[d]; fz = I.fz(R["funding_tage"])[d]
            z = r / (I.sig[d] * math.sqrt(R["tage"])) if np.isfinite(r) else float("nan")
            return kopf + f" · 3 Tage {_de(z, 1, True)} σ (ab ±{_de(R['z'], 1)}), Funding {_de(fz, 1, True)} SD (ab ±{_de(R['funding_z'], 0)})"
        if art == "zufall":
            return kopf + f" · Zufall {R['p_tag'] * 100:.0f} % je Tag"
    except (ValueError, ZeroDivisionError, IndexError, TypeError):
        pass
    return kopf


# ================================================================================================ Selbsttest (ohne Netz)

_START_TEST = 1609459200                          # 01.01.2021


def _x_tageseffekt(regel):
    """Effekt-Helfer für synthetische Märkte: regel(x_schluss[:k], sig_k, k) -> Drift je Tag (log) für Tag k, kausal aus den
    Schlusskursen davor; verteilt gleichmäßig auf die 48 Kerzen des Tags."""
    def f(ts, r, rng, sb):
        out = r.copy(); n = len(r); nt = n // BARS_TAG
        xs = []; rv = []
        for k in range(nt):
            a, b = k * BARS_TAG, (k + 1) * BARS_TAG
            sig_k = math.sqrt(np.mean(rv[-20:])) if rv else float(np.std(r[:BARS_TAG]) * math.sqrt(BARS_TAG))
            dr = regel(np.array(xs), sig_k, k) if k > 0 else 0.0
            if dr:
                out[a:b] += dr / BARS_TAG
            seg = out[a:b]
            rv.append(float(np.sum(seg * seg)))
            xs.append(float((xs[-1] if xs else 0.0) + seg.sum()))
        return out
    return f


def _e_ruecksetzer(staerke=0.6, tage=4):
    """Im Trend (Mittel 20 > 50, Schluss > 50) nach Rücksetzer ≥ 2 σ unter das 10-Tage-Hoch: tage lang Drift +staerke σ/Tag (gespiegelt)."""
    zustand = {"rest": 0, "vz": 0.0}

    def regel(xs, s, k):
        if zustand["rest"] > 0:
            zustand["rest"] -= 1
            return zustand["vz"] * staerke * s
        if len(xs) < 50:
            return 0.0
        m20, m50, c = xs[-20:].mean(), xs[-50:].mean(), xs[-1]
        if m20 > m50 and c > m50 and xs[-10:].max() - c >= 2 * s:
            zustand.update(rest=tage - 1, vz=1.0); return staerke * s
        if m20 < m50 and c < m50 and c - xs[-10:].min() >= 2 * s:
            zustand.update(rest=tage - 1, vz=-1.0); return -staerke * s
        return 0.0
    return regel


def _e_kompression(staerke=0.5, tage=10):
    """Nach Ruhe (10-Tage-Mittel der absoluten Tagesrenditen im untersten Fünftel der 250 Tage davor) und Ausbruch aus dem
    10-Tage-Bereich der Schlüsse: tage lang Drift in Ausbruchsrichtung."""
    zustand = {"rest": 0, "vz": 0.0}

    def regel(xs, s, k):
        if zustand["rest"] > 0:
            zustand["rest"] -= 1
            return zustand["vz"] * staerke * s
        if len(xs) < 263:
            return 0.0
        v = np.abs(np.diff(xs[-262:]))                                   # 261 Tagesrenditen bis gestern
        cs = np.concatenate([[0.0], np.cumsum(v)])
        v10 = (cs[10:] - cs[:-10]) / 10.0                                # 252 Zehn-Tage-Mittel, das letzte bis gestern
        if v10[-2] > np.quantile(v10[-252:-2], 0.2):
            return 0.0
        c = xs[-1]; hi = xs[-11:-1].max(); lo = xs[-11:-1].min()
        if c > hi or c < lo:
            vz = 1.0 if c > hi else -1.0
            zustand.update(rest=tage - 1, vz=vz); return vz * staerke * s
        return 0.0
    return regel


def _e_gegenbewegung(staerke=0.8, tage=3):
    """Nach 3-Tage-Bewegung über 2,5 σ√3: tage lang Gegendrift (das Funding des Testmarkts folgt der Bewegung, siehe _funding_test)."""
    zustand = {"rest": 0, "vz": 0.0}

    def regel(xs, s, k):
        if zustand["rest"] > 0:
            zustand["rest"] -= 1
            return zustand["vz"] * staerke * s
        if len(xs) < 4:
            return 0.0
        z = (xs[-1] - xs[-4]) / (s * math.sqrt(3))
        if abs(z) >= 2.5:
            vz = -1.0 if z > 0 else 1.0
            zustand.update(rest=tage - 1, vz=vz); return vz * staerke * s
        return 0.0
    return regel


def _funding_test(K: dict, seed: int, folgt: bool) -> dict:
    """Funding alle 8 h in realistischer Größe (bis ±0,05 % je Zahlung): folgt=True -> Rate steigt mit der Rendite der letzten 24 h
    (gedrängt nach Bewegungen), sonst nur Rauschen um +0,01 %."""
    rng = np.random.default_rng(seed)
    ts = K["ts"]; c = K["c"]; t_f = np.arange((ts[0] // (8 * 3600) + 1) * 8 * 3600, ts[-1], 8 * 3600)
    idx = np.searchsorted(ts, t_f, side="right") - 1
    rates = []
    for i, t in zip(idx, t_f):
        r24 = math.log(c[i] / c[max(0, i - 48)]) if i > 48 else 0.0
        rates.append(0.0001 + (0.0004 * math.tanh(r24 / 0.05) if folgt else 0.0) + rng.normal(0, 0.00005))
    return {"ts": t_f.astype(np.int64), "rate": np.array(rates)}


def _universum(seed: int, n: int = 5, tage: int = 1150, effekt=None, drift: float = 0.0005, folgt: bool = False,
               phi_u: float = 0.97, sd_u: float = 0.12) -> dict:
    """n synthetische Coins (30-min-Kerzen, Schwankungsregime, dicke Ränder, Drift); effekt = Fabrik, die je Coin eine frische
    Effekt-Funktion liefert (eigener Zustand je Coin)."""
    roh = {}
    for i in range(n):
        K = RG._markt(tage=tage, seed=seed + 101 * i, sigma_tag=0.03, profil="flach", drift_tag=drift, phi_u=phi_u, sd_u=sd_u,
                      start=_START_TEST, extra=effekt() if effekt else None)
        roh[f"C{i}"] = (K, _funding_test(K, seed + 7 * i, folgt))
    return roh


def _probe_tageskerzen(ok) -> None:
    rng = np.random.default_rng(3)
    ts = np.arange(_START_TEST, _START_TEST + 6 * TAG, BAR, dtype=np.int64)
    weg = np.zeros(len(ts), dtype=bool); weg[[5, 47 + 48, 48 * 3 + 0, 48 * 4 + 3, 48 * 4 + 4, 48 * 4 + 5]] = True
    weg[48 * 5 + 10: 48 * 5 + 20] = True                               # Tag 5: nur 38 Kerzen -> nicht voll
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.004, len(ts))))
    o = np.concatenate([[100.0], c[:-1]]); h = np.maximum(o, c) * 1.001; l = np.minimum(o, c) * 0.999
    K = {"ts": ts[~weg], "o": o[~weg], "h": h[~weg], "l": l[~weg], "c": c[~weg], "v": np.ones(int((~weg).sum()))}
    T = tagesreihen(K)
    soll_o, soll_c, soll_h, soll_l, soll_voll, soll_rv = [], [], [], [], [], []
    for d in range(6):
        sel = [i for i in range(len(ts)) if not weg[i] and ts[i] // TAG == _START_TEST // TAG + d]
        soll_h.append(max(h[i] for i in sel)); soll_l.append(min(l[i] for i in sel))
        soll_o.append(o[sel[0]] if ts[sel[0]] % TAG == 0 else np.nan)
        soll_c.append(c[sel[-1]] if ts[sel[-1]] % TAG == TAG - BAR else np.nan)
        rr = [math.log(c[i] / c[i_v]) for i_v, i in zip(sel[:-1], sel[1:]) if ts[i] - ts[i_v] == BAR]
        if d > 0 and not weg[sel[0] - 1] and ts[sel[0]] - ts[sel[0] - 1] == BAR:
            rr.append(math.log(c[sel[0]] / c[sel[0] - 1]))
        soll_rv.append(sum(x * x for x in rr) * 48 / len(rr) if len(rr) >= 40 else np.nan)
        soll_voll.append(len(sel) >= 40 and np.isfinite(soll_o[-1]) and np.isfinite(soll_c[-1]))
    gleich = lambda a, b: all((np.isnan(x) and np.isnan(y)) or abs(x - y) < 1e-9 * max(1, abs(y)) for x, y in zip(a, b))
    ok("Tageskerzen gegen Brute Force (Lücken, fehlende 00:00/23:30-Kerze, Tag mit 38 Kerzen)",
       gleich(T["o"], soll_o) and gleich(T["c"], soll_c) and gleich(T["h"], soll_h) and gleich(T["l"], soll_l)
       and list(T["voll"]) == soll_voll and gleich(T["RV"], soll_rv),
       f"voll {[int(v) for v in T['voll']]}, RV Tag 1 {T['RV'][1]:.3e} (Soll {soll_rv[1]:.3e})")
    rv = np.array([0.0004, np.nan, 0.0009, 0.0001])
    s = sigma_tag(rv, 20.0); lam = 0.5 ** (1 / 20)
    e2 = lam * 0.0004 + (1 - lam) * 0.0009; e3 = lam * e2 + (1 - lam) * 0.0001
    ok("σ_Tag einschließlich des Tags (EWMA, Lücke trägt weiter)", abs(s[0] - 0.02) < 1e-12 and abs(s[1] - 0.02) < 1e-12
       and abs(s[2] - math.sqrt(e2)) < 1e-12 and abs(s[3] - math.sqrt(e3)) < 1e-12, f"σ {', '.join(f'{x:.5f}' for x in s)}")


def _probe_kennzahlen(ok) -> None:
    rng = np.random.default_rng(5); nd = 400
    T = {"nd": nd, "h": 100 + rng.normal(0, 5, nd), "l": 90 + rng.normal(0, 5, nd), "c": 95 + np.cumsum(rng.normal(0, 1, nd)),
         "RV": rng.uniform(1e-4, 9e-4, nd), "tag_ts": (_START_TEST // TAG + np.arange(nd)) * TAG}
    T["h"][100] = np.nan
    fts = np.sort(rng.integers(T["tag_ts"][0], T["tag_ts"][-1] + TAG, 1200)); fr = rng.normal(1e-4, 2e-4, 1200)
    F = {"ts": fts.astype(np.int64), "rate": fr}
    I = Kennzahlen(T, F)
    fehler = []
    for d in (5, 25, 101, 115, 260, 399):
        w20h = T["h"][d - 20:d] if d >= 20 else None
        soll = float(np.max(w20h)) if w20h is not None and np.all(np.isfinite(w20h)) else np.nan
        if not ((np.isnan(soll) and np.isnan(I.hh(20)[d])) or abs(I.hh(20)[d] - soll) < 1e-12):
            fehler.append(f"hh20[{d}]")
        if d >= 49 and abs(I.sma(50)[d] - T["c"][d - 49:d + 1].mean()) > 1e-9:
            fehler.append(f"sma50[{d}]")
        if d >= 9 and abs(I.maxc(10)[d] - T["c"][d - 9:d + 1].max()) > 1e-12:
            fehler.append(f"maxc10[{d}]")
        if d >= 260:
            v = np.sqrt([T["RV"][k - 9:k + 1].mean() for k in range(d - 250, d + 1)])
            if I.ruhe(10, 250, 0.2)[d] != (1.0 if v[-1] <= np.quantile(v[:-1], 0.2) else 0.0):
                fehler.append(f"ruhe[{d}]")
        if d >= 31:
            fd = [np.mean(fr[(fts >= T["tag_ts"][k]) & (fts < T["tag_ts"][k] + TAG)]) if np.any((fts >= T["tag_ts"][k]) & (fts < T["tag_ts"][k] + TAG)) else np.nan
                  for k in range(d - 30, d + 1)]
            hist = np.array(fd[:-1]); hist = hist[np.isfinite(hist)]
            soll_fz = (fd[-1] - hist.mean()) / np.std(hist, ddof=1) if np.isfinite(fd[-1]) and len(hist) >= 20 else np.nan
            if not ((np.isnan(soll_fz) and np.isnan(I.fz(30)[d])) or abs(I.fz(30)[d] - soll_fz) < 1e-9):
                fehler.append(f"fz[{d}]")
    ok("Kennzahlen gegen Brute Force: Kanal ohne den Tag (mit Lücke), Mittel, 10-T-Hoch, Ruhe-Perzentil, Funding-Druck",
       not fehler and np.isnan(I.hh(20)[101]) and np.isnan(I.hh(20)[115]) and np.isfinite(I.hh(20)[121]), ", ".join(fehler) or "alle gleich")


def _markt_handel(spur: list, start: int = _START_TEST + 400 * TAG) -> dict:
    """Kleiner Markt für Handproben: spur = [(Tag, Kerze, o, h, l, c)] überschreibt einen ruhigen Pfad bei 100."""
    nd = 40; ts = np.arange(start, start + nd * TAG, BAR, dtype=np.int64)
    o = np.full(len(ts), 100.0); c = o.copy(); h = o * 1.0005; l = o * 0.9995
    for tg, kz, oo, hh, ll, cc in spur:
        i = tg * BARS_TAG + kz
        o[i], h[i], l[i], c[i] = oo, hh, ll, cc
    return {"ts": ts, "o": o, "h": h, "l": l, "c": c, "v": np.ones(len(ts))}


def _probe_ausfuehrung(ok) -> None:
    """Handproben der Ausführung: Stop mit Lücke, Ziel als Maker, Gebühren (XMR doppelt), Funding über Tage, Zeitausstieg,
    Nachzieh-Stop nur in Gewinnrichtung, Kanal-Ausstieg."""
    K = _markt_handel([(3, 20, 100.0, 100.05, 95.0, 95.5)])           # Tag 3, Kerze 20: Tief 95 (Stop 98 liegt darüber)
    T = tagesreihen(K); F = {"ts": np.array([K["ts"][0] + k * 8 * 3600 for k in range(120)], dtype=np.int64), "rate": np.full(120, 0.0001)}
    I = Kennzahlen(T, F); I.sig[:] = 0.01
    R = dict(STRATEGIEN["swing_ruecksetzer"])
    sig = {"seite": "long", "sigma": 0.01, "stop": 2.0, "ziel_level": 103.0, "ziel_min": 1.5, "max_tage": 10}
    tr = handel("BTC", R, T, F, I, 1, sig)
    px_in = 100.0 * (1 + 1.5e-4); sl = px_in * math.exp(-0.02); P = plan(sig, px_in)
    px_out = sl * (1 - 1.5e-4)
    t_in = int(T["tag_ts"][1]); t_out = int(T["tag_ts"][3]) + 20 * BAR + BAR
    n_f = int(np.sum((F["ts"] > t_in) & (F["ts"] <= t_out)))
    soll = (px_out - px_in) * P["notional"] / px_in - P["notional"] * GEB_TAKER - P["notional"] / px_in * px_out * GEB_TAKER - P["notional"] * 0.0001 * n_f
    ok("Stop in der Kerze, Gebühren, Funding über Tage (Handrechnung)",
       tr and tr["grund"] == "Stop" and abs(tr["px_out"] - px_out) < 1e-9 and abs(tr["netto"] - soll) < 1e-6 and abs(tr["R"] - soll / P["risiko"]) < 1e-9
       and n_f == 7 and tr["frei_ab"] == 3 and abs(sum(v for _, v in tr["pnl"]) - tr["netto"]) < 1e-9
       and abs(tr["kurs"] - (sl - 100.0) * P["notional"] / px_in) < 1e-9,
       f"netto {tr['netto']:+.4f} USD (Soll {soll:+.4f}), R {tr['R']:+.3f}, {n_f} Funding-Zahlungen, frei ab Tag {tr['frei_ab']}" if tr else "kein Trade")
    K2 = _markt_handel([(2, 0, 97.0, 97.0, 96.9, 97.0)])                # Lücke: Tag 2 öffnet bei 97 unter dem Stop 98,02
    T2 = tagesreihen(K2); I2 = Kennzahlen(T2, None); I2.sig[:] = 0.01
    tr2 = handel("XMR", R, T2, None, I2, 1, dict(sig, ziel_level=150.0))
    px_in2 = 100.0 * (1 + 5e-4); P2 = plan(dict(sig, ziel_level=150.0), px_in2)
    soll2 = (97.0 * (1 - 5e-4) - px_in2) * P2["notional"] / px_in2 - P2["notional"] * 2 * GEB_TAKER - P2["notional"] / px_in2 * 97.0 * (1 - 5e-4) * 2 * GEB_TAKER
    K3 = _markt_handel([(2, 30, 100.0, 103.5, 99.9, 103.4)])            # Ziel 103 in Tag 2
    T3 = tagesreihen(K3); I3 = Kennzahlen(T3, None); I3.sig[:] = 0.01
    tr3 = handel("BTC", R, T3, None, I3, 1, sig)
    soll3 = (103.0 - px_in) * P["notional"] / px_in - P["notional"] * GEB_TAKER - P["notional"] / px_in * 103.0 * GEB_MAKER
    tr4 = handel("BTC", R, T3, None, I3, 1, dict(sig, ziel_level=200.0, max_tage=2))   # Zeit: Ausstieg zur Eröffnung von Tag 3
    ok("Lücke über den Stop (Eröffnung), Ziel als Maker, XMR doppelte Gebühr, Zeitausstieg zur Eröffnung",
       tr2 and tr2["grund"] == "Stop" and abs(tr2["netto"] - soll2) < 1e-6 and tr3 and tr3["grund"] == "Ziel" and abs(tr3["netto"] - soll3) < 1e-6
       and tr4 and tr4["grund"] == "Zeit" and tr4["t_out"] == int(T3["tag_ts"][3]) and tr4["frei_ab"] == 2,
       f"Lücke: {tr2['px_out'] if tr2 else 0:.4f} (Soll {97.0 * (1 - 5e-4):.4f}); Ziel netto {tr3['netto'] if tr3 else 0:+.4f} (Soll {soll3:+.4f}); "
       f"Zeit: Ausstieg Tag {tag_index(T3, tr4['t_out']) if tr4 else '—'}, frei ab {tr4['frei_ab'] if tr4 else '—'}")
    # Nachzieh-Stop: steigende Schlüsse, dann ein Rückgang -- der Stop darf nur steigen
    spur = []
    for tg, cc in ((1, 101.0), (2, 103.0), (3, 106.0), (4, 104.0)):
        spur.append((tg, 47, cc, cc + 0.01, cc - 0.01, cc))
    K5 = _markt_handel(spur); T5 = tagesreihen(K5); I5 = Kennzahlen(T5, None)
    I5.sig[:] = 0.01; I5.sig[4:] = 0.02                                  # σ verdoppelt sich ab Tag 4: 3 σ unter 106 wäre 99,8
    R5 = dict(STRATEGIEN["swing_kompression"])
    stops = []
    pos = {"seite": "long", "e": 1, "sl": 98.0}
    for d in range(1, 6):
        res = nachfuehren(R5, T5, I5, d, pos)
        if res.get("sl") is not None:
            pos["sl"] = res["sl"]
        stops.append(round(pos["sl"], 4))
    best = [101.0, 103.0, 106.0, 106.0, 106.0]
    spur_s = [(tg, 47, cc, cc + 0.01, cc - 0.01, cc) for tg, cc in ((1, 99.0), (2, 97.0), (3, 94.0), (4, 96.0))]
    T5s = tagesreihen(_markt_handel(spur_s)); I5s = Kennzahlen(T5s, None); I5s.sig[:] = 0.01; I5s.sig[4:] = 0.02
    stops_s = []; pos = {"seite": "short", "e": 1, "sl": 103.0}
    for d in range(1, 6):
        res = nachfuehren(R5, T5s, I5s, d, pos)
        if res.get("sl") is not None:
            pos["sl"] = res["sl"]
        stops_s.append(round(pos["sl"], 4))
    ok("Nachzieh-Stop: 3 σ vom besten Schluss, nur in Gewinnrichtung (auch wenn σ steigt), Long und Short",
       stops == [round(b * math.exp(-0.03), 4) for b in best] and stops_s == [round(b * math.exp(0.03), 4) for b in (99.0, 97.0, 94.0, 94.0, 94.0)],
       f"Long {stops}; Short {stops_s}")
    # Kanal-Ausstieg S1 und Wiedereinstieg am selben Schluss (Short)
    R1 = STRATEGIEN["swing_trend"]
    T6 = {"nd": 40, "voll": np.ones(40, dtype=bool), "c": np.full(40, 100.0), "h": np.full(40, 101.0), "l": np.full(40, 99.0),
          "RV": np.full(40, 1e-4), "tag_ts": np.arange(40) * TAG}
    T6["c"][30] = 95.0; I6 = Kennzahlen(T6, None)
    aus = nachfuehren(R1, T6, I6, 30, {"seite": "long", "e": 25, "sl": 90.0})
    ein = einstieg(R1, T6, I6, 30)
    ok("Kanal-Ausstieg unter dem 10-Tage-Tief und Short-Einstieg unter dem 20-Tage-Tief am selben Schluss",
       aus.get("aus") is True and ein and ein["seite"] == "short", f"Ausstieg: {aus.get('grund')}; Einstieg: {ein['grund'] if ein else '—'}")
    # Stop und Ziel in derselben Kerze -> Stop (vorsichtig); Größe nach Risiko mit Deckel; Short gespiegelt
    K7 = _markt_handel([(2, 10, 100.0, 103.5, 97.0, 100.0)])           # eine Kerze berührt Ziel 103 und Stop 98,04
    T7 = tagesreihen(K7); I7 = Kennzahlen(T7, None); I7.sig[:] = 0.01
    tr7 = handel("BTC", R, T7, None, I7, 1, sig)
    T8 = tagesreihen(_markt_handel([(1, 0, 100.0, 100.05, 97.0, 97.5)])); I8 = Kennzahlen(T8, None); I8.sig[:] = 0.01
    tr8 = handel("BTC", R, T8, None, I8, 1, sig)                          # die Einstiegskerze selbst fällt durch den Stop
    P8 = plan({"seite": "long", "sigma": 0.002, "stop": 2.0}, 100.0)                       # enger Stop: 25.050 USD -> Deckel
    P9 = plan({"seite": "short", "sigma": 0.02, "stop": 2.0, "ziel_level": 90.0, "ziel_min": 1.0}, 100.0)
    ok("Stop und Ziel in einer Kerze: Stop; Stop schon in der Einstiegskerze; Größe nach Risiko mit Deckel 10.000 USD; Short gespiegelt",
       tr7 and tr7["grund"] == "Stop" and tr8 and tr8["grund"] == "Stop" and tr8["t_out"] == int(T8["tag_ts"][1]) + BAR
       and abs(tr8["px_out"] - px_in * math.exp(-0.02) * (1 - 1.5e-4)) < 1e-9 and P8["notional"] == NOTIONAL_MAX and abs(P8["risiko"] - NOTIONAL_MAX * (1 - math.exp(-0.004))) < 1e-9
       and abs(P9["sl"] - 100 * math.exp(0.04)) < 1e-12 and abs(P9["tp"] - 90.0) < 1e-12 and abs(P9["risiko"] - RISIKO_USD) < 1e-9,
       f"{tr7['grund'] if tr7 else '—'}; Einstiegskerze: {tr8['grund'] if tr8 else '—'} nach {(tr8['t_out'] - tr8['t_in']) // 60 if tr8 else '—'} min; enger Stop: {_tausend(P8['notional'])} USD, Risiko {_de(P8['risiko'], 2)}; Short: Stop "
       f"{_de(P9['sl'], 3)}, Ziel {_de(P9['tp'], 1)}, Risiko {_de(P9['risiko'], 2)}")


def _probe_kausal(ok) -> None:
    """Daten ab Tag D geändert -> Einstiege und Nachführen bis D-1 gleich; Labor-Entscheidung (letzte 460 Tage) = Historie."""
    roh = _universum(41, n=1, tage=700, folgt=True)
    K, F = roh["C0"]
    D1 = daten_aufbereiten(K, F)
    schnitt = 600 * TAG + _START_TEST
    K2 = {k: v.copy() for k, v in K.items()}
    sel = K2["ts"] >= schnitt
    K2["c"][sel] *= 1.3; K2["o"][sel] *= 1.3; K2["h"][sel] *= 1.35; K2["l"][sel] *= 1.25
    F2 = {"ts": F["ts"].copy(), "rate": np.where(F["ts"] >= schnitt, F["rate"] + 0.003, F["rate"])}
    D2 = daten_aufbereiten(K2, F2)
    verglichen = 0; versch = []
    for n, R in STRATEGIEN.items():
        for d in range(270, 599):
            u = (0.05, 0.3) if d % 3 == 0 else (0.5, 0.7)
            a, b = einstieg(R, D1["T"], D1["I"], d, u), einstieg(R, D2["T"], D2["I"], d, u)
            if (a is None) != (b is None) or (a and (a["seite"] != b["seite"] or abs(a["sigma"] - b["sigma"]) > 1e-15)):
                versch.append(f"{n}@{d}")
            pos = {"seite": "long", "e": d - 3, "sl": None}
            x, y = nachfuehren(R, D1["T"], D1["I"], d, pos), nachfuehren(R, D2["T"], D2["I"], d, pos)
            if x != y:
                versch.append(f"{n}/nf@{d}")
            verglichen += 2
    # die Kennzahlen selbst: bis Tag 599 gleich (auch die Funding-Zahlung um 00:00 von Tag 600 gehört nicht zu Tag 599), ab 600
    # verschieden (Gegenprobe: der Vergleich ist nicht leer)
    I1, I2 = D1["I"], D2["I"]
    reihen = {"σ": (I1.sig, I2.sig), "hh20": (I1.hh(20), I2.hh(20)), "ll10": (I1.ll(10), I2.ll(10)), "sma50": (I1.sma(50), I2.sma(50)),
              "maxc10": (I1.maxc(10), I2.maxc(10)), "ruhe": (I1.ruhe(10, 250, 0.2), I2.ruhe(10, 250, 0.2)), "rk3": (I1.rk(3), I2.rk(3)),
              "fz30": (I1.fz(30), I2.fz(30))}
    for k, (x, y) in reihen.items():
        if not np.array_equal(x[:600], y[:600], equal_nan=True):
            versch.append(f"Kennzahl {k}")
    for k in ("σ", "hh20", "sma50", "rk3", "fz30"):
        x, y = reihen[k]
        if np.array_equal(x[600:610], y[600:610], equal_nan=True):
            versch.append(f"Gegenprobe {k}")
    # Labor-Sicht: dieselben Kerzen ab (letzter Tag − 460) -> dieselbe Entscheidung am letzten vollen Tag wie die ganze Historie
    ab = (int(K["ts"][-1]) // TAG - LABOR_TAGE) * TAG
    sel = K["ts"] >= ab
    Kl = {k: v[sel] for k, v in K.items()}; Fl = {"ts": F["ts"][F["ts"] >= ab - 40 * TAG], "rate": F["rate"][F["ts"] >= ab - 40 * TAG]}
    Dl = daten_aufbereiten(Kl, Fl)
    gleich_l = []; n_l = 0
    off = int(Dl["T"]["d0"]) - int(D1["T"]["d0"])
    for dl in range(300, Dl["T"]["nd"] - 1):
        d = dl + off
        for n, R in STRATEGIEN.items():
            a, b = einstieg(R, D1["T"], D1["I"], d, (0.05, 0.3)), einstieg(R, Dl["T"], Dl["I"], dl, (0.05, 0.3))
            n_l += 1
            if (a is None) != (b is None) or (a and (a["seite"] != b["seite"] or abs(a["sigma"] / b["sigma"] - 1) > 1e-4)):
                gleich_l.append(f"{n}@{d}")
    ok("Kausalität: Kurse und Funding ab Tag 600 geändert -> Kennzahlen, Einstieg und Nachführen bis Tag 599 gleich; Labor-Ausschnitt = Historie",
       not versch and verglichen > 3500 and not gleich_l and n_l > 300,
       f"{verglichen} Entscheidungen verglichen, {len(versch)} verschieden; Labor-Ausschnitt {n_l} verglichen, {len(gleich_l)} verschieden "
       + ("; " + ", ".join((versch + gleich_l)[:4]) if versch or gleich_l else ""))
    # labor_daten aus swing.db: um 23:50 zählt der laufende Tag nicht (seine 23:30-Kerze ist noch offen, auch wenn sie in der Datei
    # schon stünde), um 00:01 ist er der Entscheidungstag; Entscheidung = Historie
    import tempfile
    import shutil
    tmp = tempfile.mkdtemp(prefix="hl_swing_ld_")
    try:
        pfad = os.path.join(tmp, "swing.db"); con = verbinden(pfad)
        _schreiben(con, "INSERT INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                   [("C0", int(t), float(o), float(h), float(l), float(c), 1.0) for t, o, h, l, c in zip(K["ts"], K["o"], K["h"], K["l"], K["c"])])
        _schreiben(con, "INSERT INTO sw_funding VALUES (?,?,?)", [("C0", int(t), float(r)) for t, r in zip(F["ts"], F["rate"])])
        con.close()
        T1 = D1["T"]; d = 650
        W1 = labor_daten(pfad, "C0", int(T1["tag_ts"][d]) + TAG - 600)
        W2 = labor_daten(pfad, "C0", int(T1["tag_ts"][d]) + TAG + 60)
        gleich_w = all(((einstieg(R, W2["T"], W2["I"], W2["d"], (0.05, 0.3)) or {}).get("seite")
                        == (einstieg(R, T1, D1["I"], d, (0.05, 0.3)) or {}).get("seite")) for R in STRATEGIEN.values()) if W2.get("ok") else False
        ld_ok = (W1.get("ok") and W2.get("ok") and W1["tag_ts"] == int(T1["tag_ts"][d - 1]) and W2["tag_ts"] == int(T1["tag_ts"][d])
                 and W1["frisch"] and W2["frisch"] and abs(W2["sigma"] / float(D1["I"].sig[d]) - 1) < 1e-4 and gleich_w)
        ok("Labor liest swing.db: um 23:50 zählt der laufende Tag nicht, um 00:01 schon; σ und Einstiege wie die Historie", ld_ok,
           f"23:50 -> Tag {_datum(W1.get('tag_ts'))}, 00:01 -> Tag {_datum(W2.get('tag_ts'))} (Soll {_datum(T1['tag_ts'][d - 1])} / "
           f"{_datum(T1['tag_ts'][d])}), Einstiege gleich: {gleich_w}")
    finally:
        _LABOR_CACHE.clear()
        shutil.rmtree(tmp, ignore_errors=True)


def _probe_laden(ok) -> None:
    import tempfile
    tmp = tempfile.mkdtemp(prefix="hl_swing_test_")
    global PAUSE_ABRUF
    alt = dict(QUELLE); pause_alt = PAUSE_ABRUF; PAUSE_ABRUF = 0.0; jetzt = START_HIST + 400 * TAG + 3 * BAR + 77
    try:
        listung = START_HIST + 200 * TAG
        aufrufe = {"k": 0, "f": 0}

        def k_fake(coin, s_ms, e_ms):
            aufrufe["k"] += 1
            if coin == "NIX":
                raise RG.KeinSymbol("-1121")
            s = max(int(s_ms) // 1000, listung if coin == "SPAET" else START_HIST)
            s = (s + BAR - 1) // BAR * BAR
            t = np.arange(s, min(int(e_ms) // 1000 + 1, s + 1000 * BAR), BAR)
            return [(int(x), 1.0, 1.1, 0.9, 1.0, 5.0) for x in t], 10

        def f_fake(coin, s_ms, e_ms):
            aufrufe["f"] += 1
            s = max(int(s_ms) // 1000, START_HIST); s = (s + 8 * 3600 - 1) // (8 * 3600) * (8 * 3600)
            t = np.arange(s, min(int(e_ms) // 1000 + 1, s + 1000 * 8 * 3600), 8 * 3600)
            return [(int(x), 0.0001) for x in t]
        QUELLE["kerzen"] = k_fake; QUELLE["funding"] = f_fake
        pfad = os.path.join(tmp, "swing.db")
        e1 = laden(pfad, ("AAA", "SPAET", "NIX"), budget_s=60, log=lambda *a: None, jetzt=jetzt)
        e2 = laden(pfad, ("AAA", "SPAET", "NIX"), budget_s=60, log=lambda *a: None, jetzt=jetzt)
        con = verbinden(pfad)
        n_a = con.execute("SELECT COUNT(*), MIN(ts), MAX(ts) FROM sw_klines WHERE coin='AAA'").fetchone()
        n_s = con.execute("SELECT MIN(ts) FROM sw_klines WHERE coin='SPAET'").fetchone()[0]
        n_f = con.execute("SELECT COUNT(*) FROM sw_funding WHERE coin='AAA'").fetchone()[0]
        keine = meta(con, "keine:NIX"); con.close()
        letzte_zu = (jetzt // BAR) * BAR - BAR
        soll_n = (letzte_zu - START_HIST) // BAR + 1
        # zweiter Prozess sperrt: frischer Eintrag „laeuft“ eines anderen Prozesses -> übersprungen
        con = verbinden(pfad); meta_setzen(con, "laeuft", f"999999:{jetzt - 60}"); con.close()
        e3 = laden(pfad, ("AAA",), budget_s=60, log=lambda *a: None, jetzt=jetzt)
        con = verbinden(pfad); meta_setzen(con, "laeuft", ""); con.close()
        def k_weg(coin, s_ms, e_ms):
            raise RuntimeError("Verbindung abgelehnt")
        QUELLE["kerzen"] = k_weg
        e4 = laden(pfad, ("AAA", "SPAET"), budget_s=60, log=lambda *a: None, jetzt=jetzt + 2 * TAG)
        ok("Laden ohne Netz: Historie ab 2020 lückenlos bis zur letzten fertigen Kerze, Listung später, unbekanntes Symbol, zweiter Lauf nichts "
           "Neues, Sperre, Börse weg",
           n_a[0] == soll_n and n_a[1] == START_HIST and n_a[2] == letzte_zu and n_s == listung and keine == "1" and n_f > 1000
           and e2["coins"]["AAA"]["kerzen"]["neu"] == 0 and e3.get("uebersprungen") and e4["coins"]["AAA"]["kerzen"].get("fehler")
           and not e4["coins"]["AAA"]["kerzen"]["fertig"] and "fehler" in e4["coins"]["SPAET"]["kerzen"],
           f"AAA {n_a[0]} Kerzen (Soll {soll_n}), SPAET ab Tag {(n_s - START_HIST) // TAG if n_s else '—'}, Funding {n_f}, "
           f"NIX keine={keine}, zweiter Lauf {e2['coins']['AAA']['kerzen']['neu']} neu, gesperrt {e3.get('uebersprungen')}")
    finally:
        QUELLE.update(alt); PAUSE_ABRUF = pause_alt
        _UNERREICHBAR.clear()
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _T_hand(c, rv=4e-4, h=None, l=None) -> dict:
    """Handgebaute Tagesreihe (alle Tage voll) für die Regelproben; σ_Tag = √rv bei festem rv."""
    c = np.asarray(c, dtype=float); nd = len(c)
    return {"nd": nd, "d0": _START_TEST // TAG, "voll": np.ones(nd, dtype=bool), "c": c,
            "h": c * 1.001 if h is None else np.asarray(h, dtype=float), "l": c * 0.999 if l is None else np.asarray(l, dtype=float),
            "RV": np.full(nd, float(rv)) if np.isscalar(rv) else np.asarray(rv, dtype=float),
            "tag_ts": (_START_TEST // TAG + np.arange(nd)) * TAG}


def _probe_regeln(ok) -> None:
    """Die Einstiegsregeln an ihren Schwellen (KONZEPT_Swing.md 4). Die Labor-Kennung hängt nur an den Parametern, nicht am Code --
    diese Probe hält den Code an den Parametern fest: Kanal strikt und ohne den Tag, Rücksetzer ab 2 σ nur im Trend (Schluss über dem
    langen Mittel), Ruhe am Vortag, 3-Tage-z mit √3 und Funding-Druck ab 1 SD, Ziele, Kontrollen."""
    fehler = []

    def pruef(name, bed):
        if not bed:
            fehler.append(name)
    S = STRATEGIEN; s = 0.02                                            # σ_Tag = √(4e-4)
    # S1: Schluss über dem 20-Tage-Hoch der Tage davor, strikt
    for c30, soll in ((101.0, None), (101.0001, "long"), (99.0, None), (98.9999, "short")):
        c = np.full(31, 100.0); c[30] = c30
        h = np.full(31, 101.0); l = np.full(31, 99.0); h[30] = max(102.0, c30); l[30] = min(98.0, c30)
        T = _T_hand(c, h=h, l=l); e = einstieg(S["swing_trend"], T, Kennzahlen(T), 30)
        pruef(f"S1 Schluss {c30}", (e or {}).get("seite") == soll)
        if soll and e:
            pruef("S1 Ausstiegsparameter", e["stop"] == 2.0 and e["max_tage"] == 30 and e["ziel_min"] is None and abs(e["sigma"] - s) < 1e-12)
    # S2: Rücksetzer ab 2 σ unter dem 10-Tage-Hoch der Schlüsse, nur im Aufwärtstrend (gespiegelt)
    auf = np.concatenate([80 + 0.5 * np.arange(60), [110.0]])           # Hoch 110 an Tag 60
    for delta, soll in ((1e-7, "long"), (-1e-7, None)):
        T = _T_hand(np.append(auf, 110.0 * math.exp(-(2.0 * s + delta)))); e = einstieg(S["swing_ruecksetzer"], T, Kennzahlen(T), 61)
        pruef(f"S2 Tiefe 2 σ {delta:+g}", (e or {}).get("seite") == soll)
        if soll and e:
            pruef("S2 Ziel", abs(e["ziel_level"] - 110.0) < 1e-9 and e["ziel_min"] == 1.5 and e["max_tage"] == 10)
    T = _T_hand(np.append(auf, 90.0))                                   # 10 σ tief, aber Schluss unter dem 50-Tage-Mittel
    pruef("S2 Schluss unter dem langen Mittel", einstieg(S["swing_ruecksetzer"], T, Kennzahlen(T), 61) is None)
    ab = np.concatenate([140 - 0.5 * np.arange(60), [110.0]])
    T = _T_hand(np.append(ab, 110.0 * math.exp(2.0 * s + 1e-7))); e = einstieg(S["swing_ruecksetzer"], T, Kennzahlen(T), 61)
    pruef("S2 Short gespiegelt", (e or {}).get("seite") == "short" and abs(e["ziel_level"] - 110.0) < 1e-9)
    # S3: Ruhe (10-Tage-Schwankung im untersten Fünftel) am Vortag, dann Ausbruch aus dem 10-Tage-Bereich
    rng = np.random.default_rng(12); nd, d = 300, 290
    rv0 = rng.uniform(3e-4, 9e-4, nd)
    c = np.full(nd, 100.0); h = np.full(nd, 100.5); l = np.full(nd, 99.5); c[d] = 100.6; h[d] = 100.7

    def s3(rv):
        T = _T_hand(c, rv=rv, h=h, l=l)
        return einstieg(S["swing_kompression"], T, Kennzahlen(T), d)
    rv_a = rv0.copy(); rv_a[d - 10:d] = 1e-4
    rv_b = rv0.copy(); rv_b[d - 10:d] = 1.2e-3
    rv_c = rv0.copy(); rv_c[d - 10] = 1e-2; rv_c[d - 9:d + 1] = 1e-6       # Ruhe erst am Signaltag
    pruef("S3 Ruhe bis zum Vortag", (s3(rv_a) or {}).get("seite") == "long")
    pruef("S3 keine Ruhe", s3(rv_b) is None)
    pruef("S3 Ruhe erst am Signaltag", s3(rv_c) is None)
    # S4: 3-Tage-Bewegung ≤ −2,5 σ·√3 und Funding-Druck ≤ −1 SD (gespiegelt); Ziel halber Rückweg, mindestens 1 σ
    nd, d = 80, 70
    fd_hist = np.array([1e-4 + (1e-5 if k % 2 else -1e-5) for k in range(nd)])
    m_, sd_ = fd_hist[d - 30:d].mean(), fd_hist[d - 30:d].std(ddof=1)

    def s4(r3, fd_d):
        c = np.full(nd, 100.0); c[d] = 100.0 * math.exp(r3)
        ts = np.array([(_START_TEST // TAG + k) * TAG + j * 8 * 3600 for k in range(nd) for j in range(3)], dtype=np.int64)
        rate = np.array([fd_d if k == d else fd_hist[k] for k in range(nd) for _ in range(3)])
        T = _T_hand(c)
        return einstieg(S["swing_gegenbewegung"], T, Kennzahlen(T, {"ts": ts, "rate": rate}), d)
    g = 2.5 * s * math.sqrt(3)
    e = s4(-g - 1e-7, 0.0)
    pruef("S4 Long", (e or {}).get("seite") == "long" and abs(e["ziel_level"] - (100 * math.exp(-g - 1e-7) * 0.5 + 50.0)) < 1e-9
          and e["ziel_min"] == 1.0 and e["max_tage"] == 5)
    pruef("S4 knapp unter 2,5 σ·√3", s4(-g + 1e-7, 0.0) is None)
    pruef("S4 Funding knapp über −1 SD", s4(-g - 1e-7, m_ - 0.999 * sd_) is None)
    pruef("S4 Funding knapp unter −1 SD", (s4(-g - 1e-7, m_ - 1.001 * sd_) or {}).get("seite") == "long")
    pruef("S4 Short gespiegelt", (s4(g + 1e-7, 2e-4) or {}).get("seite") == "short")
    # Kontrollen: Zufall mit p 0,10 und Seite u2; Zufall im Trend nur an Trendtagen, Seite = Trend
    T = _T_hand(np.full(40, 100.0)); I = Kennzahlen(T); z = S["swing_zufall"]
    pruef("Zufall", (einstieg(z, T, I, 30, (0.0999, 0.49)) or {}).get("seite") == "long" and einstieg(z, T, I, 30, (0.1, 0.49)) is None
          and (einstieg(z, T, I, 30, (0.05, 0.5)) or {}).get("seite") == "short" and einstieg(z, T, I, 30) is None)
    rz = S["swing_ruecksetzer_zufall"]
    T = _T_hand(np.append(auf, 109.0)); I = Kennzahlen(T)
    pruef("Zufall im Trend", (einstieg(rz, T, I, 61, (0.05, 0.99)) or {}).get("seite") == "long" and einstieg(rz, T, I, 61, (0.2, 0.1)) is None)
    T = _T_hand(np.full(62, 100.0))
    pruef("Zufall ohne Trend", einstieg(rz, T, Kennzahlen(T), 61, (0.01, 0.1)) is None)
    ok("Regeln an der Schwelle: Kanal strikt, Rücksetzer ab 2 σ nur im Trend, Ruhe am Vortag, z mit √3 und Funding ab 1 SD, Kontrollen",
       not fehler, ("abweichend: " + ", ".join(fehler)) if fehler else "S1–S4 und beide Kontrollen wie im Konzept")


def _probe_urteil(ok) -> None:
    """Das vorab festgelegte Urteil an gebauten Ergebnissen: Holm über die vier, ≥ 60 Trades, Tagesergebnis p < 0,05 UND positiv,
    beide Hälften, DSR ≥ 0,95."""
    def e_(n=100, p=0.004, hac_p=0.001, mittel=5.0, haelften=(100.0, 100.0), sr=0.12, tage=2000):
        return {"n": n, "placebo": {"p": p}, "hac": {"p": hac_p, "mittel": mittel}, "haelften": haelften, "sr_tag": sr,
                "reihe": np.zeros(tage), "schiefe": 0.0, "kurt": 3.0}
    E1 = {n: e_(p=p) for n, p in zip(HAUPT, (0.02, 0.03, 0.04, 0.045))}     # roh alle < 0,05, nach Holm 0,08 und dreimal 0,09
    urteil(E1)
    holm_ok = (all(abs(E1[n]["p_holm"] - s_) < 1e-12 for n, s_ in zip(HAUPT, (0.08, 0.09, 0.09, 0.09)))
               and not any(E1[n]["belegt"] for n in HAUPT) and all(E1[n]["bedingungen"]["gewinn"] for n in HAUPT))
    E2 = {HAUPT[0]: e_(), HAUPT[1]: e_(haelften=(150.0, -10.0)), HAUPT[2]: e_(n=MIN_TRADES - 1), HAUPT[3]: e_(hac_p=0.2)}
    urteil(E2)
    b2 = [E2[n]["belegt"] for n in HAUPT]
    falsch2 = [[k for k, v in E2[n]["bedingungen"].items() if not v] for n in HAUPT]
    E3 = {n: e_(sr=sr) for n, sr in zip(HAUPT, (0.03, 0.01, -0.01, 0.0))}   # DSR knapp: Abstand zum erwarteten Besten der vier
    urteil(E3)
    soll_dsr = RG._dsr(0.03, 2000, 0.0, 3.0, [0.03, 0.01, -0.01, 0.0])
    E4 = {n: e_(mittel=-5.0 if i == 0 else 5.0) for i, n in enumerate(HAUPT)}
    urteil(E4)
    # Mehrertrag gegen das Placebo: SE je Trade aus der Tagesreihe, studentisiert, einseitig
    se_t = _se_je_trade({"hac": {"se": 2.0}, "n": 200, "reihe": np.zeros(1000)})                      # 2 · 1000 / (200 · 100) = 0,1
    m_pl = np.array([0.0, 0.1, -0.1, 0.0])                                                              # Mittel 0, Var 0,00667
    v = _mehrertrag(0.25, se_t, m_pl, 1000)
    se_soll = math.sqrt(0.01 + np.var(m_pl, ddof=1) / 4); t_soll = 0.25 / se_soll
    v2 = _mehrertrag(-0.25, se_t, m_pl, 1000)
    formel_ok = (abs(se_t - 0.1) < 1e-12 and abs(v["se"] - se_soll) < 1e-12 and abs(v["t"] - t_soll) < 1e-12
                 and abs(v["p"] - RG.t_p2(t_soll, 999) / 2) < 1e-12 and abs(v2["p"] - (1 - RG.t_p2(-t_soll, 999) / 2)) < 1e-12 and v2["p"] > 0.9)
    ok("Urteil: Holm über die vier, ≥ 60 Trades, Tagesergebnis signifikant UND positiv, beide Hälften, DSR ≥ 0,95; Placebo studentisiert",
       holm_ok and b2 == [True, False, False, False] and falsch2[1:] == [["haelften"], ["trades"], ["gewinn"]]
       and abs(E3[HAUPT[0]]["dsr"] - soll_dsr) < 1e-12 and soll_dsr < DSR_MIN and not E3[HAUPT[0]]["belegt"]
       and [k for k, v in E3[HAUPT[0]]["bedingungen"].items() if not v] == ["dsr"] and not E4[HAUPT[0]]["belegt"]
       and not E4[HAUPT[0]]["bedingungen"]["gewinn"] and E4[HAUPT[1]]["belegt"] and formel_ok,
       f"Holm {_de(E1[HAUPT[0]]['p_holm'], 2)} (roh 0,02–0,045); verletzt je Fall {falsch2}; DSR {_de(E3[HAUPT[0]]['dsr'], 2)} bei Sharpe "
       f"0,03/Tag unter vier; Mehrertrag +0,25 R bei SE {_de(v['se'], 3)}: t {_de(v['t'], 2)}, p {RG._pz(v['p'])}")


def _probe_placebo(ok) -> None:
    """Zeitpunkt-Placebo: nur flache volle Tage im Bewertungsbereich, keine Überlappung, S2 nur an Trendtagen mit Seite = Trend,
    sonst Long-Anteil wie vorgegeben; dieselben Ausstiege wie die Strategie (ausstieg_parameter)."""
    global handel
    orig = handel; aufrufe = []

    def spion(coin, R, T, F, I, e, sig, mtm=True):
        tr = orig(coin, R, T, F, I, e, sig, mtm)
        soll = ausstieg_parameter(R, T, I, e - 1, sig["seite"])
        aufrufe.append((e, sig["seite"], tr["frei_ab"] if tr else None, soll is not None and all(sig.get(k) == v for k, v in soll.items())))
        return tr
    D = daten_aufbereiten(*_universum(55, n=1, tage=900, drift=0.001)["C0"]); T, F, I = D["T"], D["F"], D["I"]
    d_von, d_bis = bewertungsbereich(T, I)
    fehler = []; n_long = n_alle = n_s2 = 0
    try:
        handel = spion
        rng = np.random.default_rng(3)
        for name, q, p_long in (("swing_ruecksetzer", 0.3, 0.5), ("swing_trend", 0.2, 0.8)):
            R = STRATEGIEN[name]
            for _ in range(15):
                aufrufe.clear()
                rs = lauf_placebo("C0", R, T, F, I, d_von, d_bis, q, p_long, rng)
                frei = d_von
                for e, seite, fa, gleich in aufrufe:
                    d = e - 1
                    if d < frei or d < d_von or d > d_bis or not T["voll"][d]:
                        fehler.append(f"{name}: Tag {d} nicht flach/voll/im Bereich")
                    if not gleich:
                        fehler.append(f"{name}: Ausstiege anders an Tag {d}")
                    if name == "swing_ruecksetzer":
                        tr_ = _trend(R, T, I, d); n_s2 += 1
                        if tr_ == 0 or seite != ("long" if tr_ > 0 else "short"):
                            fehler.append(f"S2: Tag {d} Trend {tr_}, Seite {seite}")
                    else:
                        n_alle += 1; n_long += seite == "long"
                    if fa is not None:
                        frei = fa if fa > d else d + 1
                if len(rs) != sum(1 for a in aufrufe if a[2] is not None):
                    fehler.append(f"{name}: Zahl der R")
    finally:
        handel = orig
    anteil = n_long / n_alle if n_alle else float("nan")
    ok("Zeitpunkt-Placebo: flache volle Tage, keine Überlappung, S2 nur Trendtage mit Trendseite, Long-Anteil, gleiche Ausstiege",
       not fehler and n_s2 > 200 and n_alle > 200 and abs(anteil - 0.8) < 0.05,
       (f"{len(fehler)} Abweichungen: {fehler[:3]}" if fehler else f"S2 {n_s2} Placebo-Trades, S1 {n_alle} mit Long-Anteil {_de(anteil * 100, 1)} % (Soll 80 %)"))


def probe(verbose: bool = True) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name:<70} {text}", flush=True)

    t0 = time.time()
    for fn in (_probe_tageskerzen, _probe_kennzahlen, _probe_ausfuehrung, _probe_regeln, _probe_kausal, _probe_placebo, _probe_urteil,
               _probe_laden):
        try:
            fn(ok)
        except Exception as e:
            import traceback
            ok(f"{fn.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    # Nulltest: Zufallswege mit Drift, Schwankungsregimen und dicken Rändern -> keine Strategie belegt
    V0 = vorpruefung_rechnen(_universum(7, n=5, tage=1150, folgt=True), n_placebo=100, log=lambda s: None)
    bel0 = [n for n in HAUPT if V0["E"][n].get("belegt")]
    ok("Nulltest: Zufallswege (5 Coins, 1.150 Tage, Funding folgt der Bewegung) -> keine Strategie belegt", not bel0,
       ", ".join(f"{KURZ[n][:2]} n {V0['E'][n]['n']} p {RG._pz(V0['E'][n].get('p_holm'))}" for n in HAUPT) + (f" -- belegt: {bel0}" if bel0 else ""))
    # Positivkontrollen: je ein eingepflanzter Effekt; geprüft wird die zugehörige Strategie (Holm-Faktor 4 = vorsichtig)
    kontrollen = (
        ("swing_trend", "Momentum über 20 Tage", lambda: RG._x_rueckkopplung(0.35, 20, 1.0), False),
        ("swing_ruecksetzer", "Rücklauf nach Rücksetzern im Trend", lambda: _x_tageseffekt(_e_ruecksetzer(0.7, 4)), False),
        ("swing_kompression", "Fortsetzung nach Ausbruch aus Ruhe", lambda: _x_tageseffekt(_e_kompression(0.6, 10)), False),
        ("swing_gegenbewegung", "Gegenbewegung nach Übertreibung", lambda: _x_tageseffekt(_e_gegenbewegung(0.9, 3)), True),
    )
    for i, (n, text, fabrik, folgt) in enumerate(kontrollen):
        roh = _universum(300 + 17 * i, n=6 if folgt else 5, tage=1300 if folgt else 1150, effekt=fabrik, folgt=folgt)
        V = vorpruefung_rechnen(roh, n_placebo=100, log=lambda s: None, namen=(n,))
        e = V["E"][n]
        p4 = min(1.0, 4 * e.get("placebo", {}).get("p", 1.0))
        e["p_holm"] = p4
        e["bedingungen"]["placebo"] = p4 < ALPHA
        e["belegt"] = all(v for k, v in e["bedingungen"].items() if k != "dsr")
        ok(f"Positivkontrolle {KURZ[n][:2]}: {text} -> belegt (ohne DSR; Placebo-p × 4)", e["belegt"],
           f"n {e['n']}, Ø R {_r(e.get('mittel_R'))}, p Tag {RG._pz((e.get('hac') or {}).get('p'))}, Placebo p×4 {RG._pz(p4)}, "
           f"Hälften {_r(e['haelften'][0], 0)}/{_r(e['haelften'][1], 0)}")
    # Bericht
    roh = _universum(9, n=2, tage=900)
    roh["C9"] = None
    roh["C8"] = (RG._markt(tage=200, seed=3, start=_START_TEST), None)
    V = vorpruefung_rechnen(roh, n_placebo=20, log=lambda s: None)
    V["info"].update({c: V["info"][k] for c, k in zip(COINS, ("C0", "C1", "C8", "C9", "C9")) if k in V["info"]})
    txt = bericht_text(V)
    teile = ("PRÜFSTAND", "S1 TREND-AUSBRUCH", "Zeitpunkt-Placebo", "nur Kurs (beschreibend)", "Zerlegung je Trade", "Je Coin", "Je Jahr",
             "BEZUG", "zu kurz", "keine Historie")
    fehlt = [t for t in teile if t not in txt]
    ok("Bericht: alle Abschnitte, „zu kurz“ und „keine Historie“", not fehlt, f"fehlt: {fehlt}" if fehlt else f"{len(txt)} Zeichen")
    alles = all(p[1] for p in pruef)
    return alles, pruef, time.time() - t0


def selbsttest() -> bool:
    print("Swing-Modul (U140) -- Selbsttest: Tageskerzen, Kennzahlen, Ausführung, Kausalität, Laden ohne Netz, Nulltest, Positivkontrollen",
          flush=True)
    alles, _, dauer = probe(True)
    print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({dauer:.0f} s)", flush=True)
    return alles


# ================================================================================================ Aufruf

def main() -> int:
    ap = argparse.ArgumentParser(description="Swing-Modul (U140): Vorprüfung auf der Historie, Laden, Selbsttest")
    ap.add_argument("--vorpruefung", action="store_true")
    ap.add_argument("--laden", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--db", default=os.environ.get("HL_DB", "hl_liq.db"))
    ap.add_argument("--ohne-laden", action="store_true")
    ap.add_argument("--placebo", type=int, default=N_PLACEBO)
    ap.add_argument("--budget", type=float, default=840.0)
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.laden:
        pfad = swing_pfad(a.db)
        print(f"Swing: Historie laden bzw. ergänzen -> {pfad}", flush=True)
        erg = laden(pfad, budget_s=a.budget)
        if erg.get("uebersprungen"):
            print("  übersprungen: ein anderer Ladevorgang läuft gerade (Swing-Takt im Dashboard); in einigen Minuten erneut", flush=True)
            return 0
        con = verbinden(pfad)
        try:
            for c, v in erg["coins"].items():
                k, f = v["kerzen"], v["funding"]
                r = con.execute("SELECT COUNT(*), MIN(ts), MAX(ts) FROM sw_klines WHERE coin=?", (c,)).fetchone()
                nf = con.execute("SELECT COUNT(*) FROM sw_funding WHERE coin=?", (c,)).fetchone()[0]
                print(f"  {c:<5} +{_tausend(k.get('neu', 0))} Kerzen" + (" (fertig)" if k.get("fertig") else " (weiter im nächsten Lauf)")
                      + (f" -- {k['fehler']}" if k.get("fehler") else "") + (" -- kein Symbol" if k.get("keine") else "")
                      + f"; gespeichert {_tausend(r[0])} Kerzen {_datum(r[1]) if r[1] else '—'}–{_datum(r[2]) if r[2] else '—'}, Funding {_tausend(nf)}",
                      flush=True)
        finally:
            con.close()
        return 0
    if a.vorpruefung:
        print(vorpruefung(a.db, a.placebo, not a.ohne_laden), flush=True)
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
