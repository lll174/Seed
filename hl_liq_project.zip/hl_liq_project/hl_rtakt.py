#!/usr/bin/env python3
"""
hl_rtakt.py -- Messung: Wie lange dauert eine Runde des Recorders? (Vorarbeit zu U287, seit 23.115; Debug 157)

Wozu
  Das Dashboard beendet sich seit 23.114 selbst, wenn es hängt (systemd-Wächter). Für den Recorder gibt es das noch nicht. Bevor
  dort eine Frist gesetzt wird, muss bekannt sein, wie lange ein GESUNDER Recorder schweigen kann -- sonst beendet der Schutz
  einen Recorder, der nur gerade sichert oder aufräumt.

Was gemessen wird -- nur gelesen, am Recorder ändert sich nichts
  Der Recorder schreibt in jeder Schreibrunde (Dienst: alle 10 s) sein Lebenszeichen in die Hauptdatenbank (Tabelle meta,
  Schlüssel „recorder_alive“ = seine Uhrzeit in Sekunden). Ein Messfaden im Wächter-Dienst (hl_watchdog.py) liest diesen Wert jede
  Sekunde und hält bei jedem neuen Lebenszeichen fest:
    Abstand  neues Lebenszeichen − voriges (Uhr des Recorders, auf 1 s genau) = eine Schreibrunde samt Pause
    Alter    wie alt das vorige Lebenszeichen war, als das neue sichtbar wurde (von außen gesehen) -- das sähe ein Wächter
  Dazu: Neustarts des Recorders mit Pause und Anlauf bis zum ersten Lebenszeichen -- ein Abstand ist ein Neustart und keine
  Runde, wenn die Startzeit des Recorders (meta „started“) zwischen den beiden Lebenszeichen liegt --, die Dauer der Aufgaben, die
  der Recorder selbst meldet (meta „jobs“), und beim Bericht die Schnappschuss-Runden aus snapshot_meta.
  Seit 23.116 (U294): Der Schnappschuss, den der Recorder beim Beenden schreibt, ist keine Runde -- im ersten Bericht vom Pi
  (21.11.2026) stand deshalb „kürzeste −597 s“. Abstände unter der Pause stehen jetzt gesondert im Bericht.

Ablage
  recorder_takt.json neben der Hauptdatenbank: Stundenwerte der letzten 14 Tage, die 30 längsten Abstände, die letzten 50
  Neustarts. Geschrieben eine Minute nach dem Start und dann alle 5 Minuten, über eine Zwischendatei (ganz oder gar nicht).

Aufrufe
  hl_rtakt.py --bericht --db PFAD     Bericht als Text (Debug 157)
  hl_rtakt.py --selbsttest            Proben ohne Netz und ohne den echten Recorder
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import sys
import threading
import time

VERSION_MODUL = "2026-09-23.117"
DEBUG_NR = 157
DATEI = "recorder_takt.json"
FORMAT = 1
TAKT_S = 1.0                        # der Messfaden liest einmal je Sekunde
LUECKE_S = 5.0                      # eigene Pause des Messfadens darüber: der Abstand, in den sie fällt, gilt als unsicher
SPEICHERN_ERST_S = 60               # erste Ablage eine Minute nach dem Start (so hat der Bericht bald etwas)
SPEICHERN_S = 300                   # danach alle 5 Minuten
STUNDEN_MAX = 14 * 24               # Stundenwerte der letzten 14 Tage
LAENGSTE_MAX = 30
NEUSTARTS_MAX = 50
SPRUNG_S = 6 * 3600                 # Abstand über 6 h oder rückwärts: Uhr verstellt, keine Runde
SOLL_SCHREIBEN_S = 10               # Schreibtakt des Dienstes (--flush-sec, Voreinstellung)
SOLL_SCHNAPPSCHUSS_S = 600          # Pause zwischen zwei Schnappschüssen (--snapshot-sec, Voreinstellung)
KLASSEN = (12, 20, 30, 60, 120, 300)            # Abstand bis … Sekunden; darüber die letzte Klasse
FRISTEN = (30, 60, 120, 180, 300, 600)          # gedachte Fristen eines Wächters (Sekunden)
SCHNAPP_TAGE = 7
JOBS_REGEL = 2                      # Zählweise der Aufgaben (Abschnitt 6): 2 = ein Lauf mit Zwischenständen zählt einmal (23.117, U296)
LAUF_TOLERANZ_S = 2.0               # so weit darf der Beginn eines Laufs (last − dauer) zwischen zwei Meldungen wandern (last ist auf Sekunden gekürzt)


def datei_pfad(db: str) -> str:
    """Die Messdatei liegt neben der Hauptdatenbank (wie sys_history.json)."""
    return os.path.join(os.path.dirname(os.path.abspath(db)), DATEI)


# ================================================================================================ Zustand der Messung

class Messung:
    """Zustand und Regeln der Messung -- ohne Datenbank und ohne Uhr (beides kommt von außen; so ist alles prüfbar)."""

    def __init__(self, zustand: dict | None = None):
        z = zustand if isinstance(zustand, dict) and zustand.get("format") == FORMAT else {}
        self.z = {"format": FORMAT, "seit": z.get("seit"), "stand": z.get("stand"), "starts": int(z.get("starts") or 0),
                  "gelesen": int(z.get("gelesen") or 0), "stunden": dict(z.get("stunden") or {}), "laengste": list(z.get("laengste") or []),
                  "neustarts": list(z.get("neustarts") or []), "uhrsprung": int(z.get("uhrsprung") or 0),
                  # 23.117 (U296): Zähler einer älteren Zählweise werden verworfen -- sie zählten jeden Zwischenstand als Lauf
                  "jobs": dict(z.get("jobs") or {}) if z.get("jobs_regel") == JOBS_REGEL else {}, "jobs_regel": JOBS_REGEL,
                  "jobs_seit": z.get("jobs_seit") if z.get("jobs_regel") == JOBS_REGEL else None,
                  "fehler": dict(z.get("fehler") or {"n": 0, "letzter": "", "ts": None}), "ohne_wert": int(z.get("ohne_wert") or 0)}
        # nur im Lauf (nicht abgelegt): das vorige Lebenszeichen und die eigene Uhr
        self.hb = None
        self.mono = None; self.luecke = 0.0
        self.jobs_roh = None; self.jobs_last: dict = {}
        self.jobs_lauf: dict = {}                                           # je Aufgabe der Lauf, der gerade gemeldet wird: Beginn, Dauer, zählt er

    # -------------------------------------------------------------------------------------------- Bausteine
    def _stunde(self, ts: float) -> dict:
        k = str(int(ts) // 3600)
        s = self.z["stunden"].get(k)
        if s is None:
            s = self.z["stunden"][k] = {"n": 0, "hist": {}, "ahist": {}, "max": 0, "max_ts": None, "amax": 0.0, "unsicher": 0,
                                        "umax": 0, "uahist": {}, "mess": 0.0, "luecken": 0}
        return s

    def start(self, wall: float) -> None:
        """Der Messfaden beginnt (neu oder nach einem Neustart des Wächters): Was vorher war, ist nicht beobachtet."""
        if self.z["seit"] is None:
            self.z["seit"] = int(wall)
        self.z["starts"] += 1
        self.hb = None; self.mono = None; self.luecke = 0.0

    def fehler(self, wall: float, e: BaseException) -> None:
        f = self.z["fehler"]
        f["n"] = int(f.get("n") or 0) + 1; f["letzter"] = f"{type(e).__name__}: {e}"[:160]; f["ts"] = int(wall)

    def beobachte(self, wall: float, mono: float, hb, started=None, jobs_roh: str | None = None) -> str | None:
        """
        Ein Lesen: wall = Uhrzeit, mono = eigene Stoppuhr, hb = Lebenszeichen (Sekunden) oder None, started = Startzeit des
        Recorders, jobs_roh = Text von meta „jobs“. Rückgabe: was festgehalten wurde ("runde", "unsicher", "neustart", "sprung",
        "erster") oder None.
        """
        self.z["gelesen"] += 1
        if self.mono is not None:
            eigen = mono - self.mono
            st = self._stunde(wall)
            if 0 <= eigen <= LUECKE_S:
                st["mess"] = round(st["mess"] + eigen, 3)
            else:
                st["luecken"] += 1
                self.luecke = max(self.luecke, eigen if eigen > 0 else LUECKE_S + 1)
        self.mono = mono
        if jobs_roh is not None and jobs_roh != self.jobs_roh:
            self.jobs_roh = jobs_roh
            self._jobs(jobs_roh, wall)
        try:
            hb = None if hb is None else int(float(hb))
        except (TypeError, ValueError):
            hb = None
        try:
            started = None if started is None else int(float(started))
        except (TypeError, ValueError):
            started = None
        if hb is None:
            self.z["ohne_wert"] += 1
            return None
        if self.hb is None:                                                 # erstes Lebenszeichen dieses Laufs: noch kein Abstand
            self.hb = hb; self.luecke = 0.0
            return "erster"
        if hb == self.hb:
            return None
        d = hb - self.hb
        alter = wall - self.hb
        unsicher = self.luecke > LUECKE_S
        alt_hb = self.hb
        self.hb = hb; self.luecke = 0.0
        if started is not None and alt_hb < started <= hb:
            # Kein Rundenabstand: Der Recorder ist ZWISCHEN den beiden Lebenszeichen gestartet. Entschieden wird nach seinen eigenen
            # Zeitstempeln (Startzeit nach dem vorigen und nicht nach dem neuen Lebenszeichen) -- nicht danach, wann der Messfaden die
            # neue Startzeit zum ersten Mal sah. So stimmt es auch, wenn der Messfaden erst nach dem Start des Recorders beginnt
            # (nach jedem Einspielen starten beide Dienste fast zugleich) oder wenn er Startzeit und letztes Lebenszeichen des alten
            # Laufs in einem Lesen sieht.
            self.z["neustarts"].append({"ts": int(started), "pause": int(d), "anlauf": int(hb - started),
                                        "vorher": int(alt_hb), "unsicher": bool(unsicher)})
            del self.z["neustarts"][:-NEUSTARTS_MAX]
            return "neustart"
        if d <= 0 or d > SPRUNG_S:
            self.z["uhrsprung"] += 1
            return "sprung"
        st = self._stunde(hb)
        ak = str(int(math.ceil(alter - 1e-9)))
        L = self.z["laengste"]
        if len(L) < LAENGSTE_MAX or d > L[-1]["d"]:
            L.append({"hb": int(hb), "d": int(d), "alter": round(alter, 1), "u": bool(unsicher)})
            L.sort(key=lambda e: (-e["d"], -e["hb"]))
            del L[LAENGSTE_MAX:]
        if unsicher:
            # Der Messfaden pausierte selbst: Der Abstand kann aus mehreren Runden bestehen (nie zu klein, vielleicht zu groß). Er
            # zählt nicht in die Verteilung, bleibt aber sichtbar -- gerade wenn der ganze Pi stockt, treffen beide Pausen zusammen.
            st["unsicher"] += 1
            st["umax"] = max(int(st.get("umax") or 0), int(d))
            st["uahist"][ak] = st["uahist"].get(ak, 0) + 1
            return "unsicher"
        st["n"] += 1
        st["hist"][str(d)] = st["hist"].get(str(d), 0) + 1
        st["ahist"][ak] = st["ahist"].get(ak, 0) + 1
        if d > st["max"]:
            st["max"] = int(d); st["max_ts"] = int(hb)
        st["amax"] = max(float(st["amax"]), round(alter, 1))
        return "runde"

    def _jobs(self, roh: str, wall: float | None = None) -> None:
        """Aufgaben, die der Recorder selbst meldet: je Aufgabe Takt, Zahl der gesehenen Läufe, längste und letzte Dauer.
        23.117 (U296): Manche Aufgaben melden Zwischenstände (Leaderboard-Fills und Pool-Fills alle zehn Konten) -- „last“ rückt
        dabei vor, „dauer“ wächst, der Beginn (last − dauer) steht still. Ein Lauf ist deshalb, was denselben Beginn hat; seine
        Dauer ist die größte gemeldete. Bis 23.116 zählte jede Änderung von „last“ als Lauf (auf dem Pi am 21.11.2026: 30 „Läufe“
        einer 12-Stunden-Aufgabe in 13,5 Stunden). Nicht trennbar bleiben nur Läufe unter rund 3 s, die ohne Pause aufeinander folgen."""
        if self.z.get("jobs_seit") is None and wall is not None:
            self.z["jobs_seit"] = int(wall)
        try:
            J = json.loads(roh)
        except (TypeError, ValueError):
            return                                                          # bei 4.000 Zeichen abgeschnitten: nicht lesbar, kein Fehler
        if not isinstance(J, dict):
            return
        for name, j in J.items():
            if not isinstance(j, dict):
                continue
            last = j.get("last"); dauer = j.get("dauer")
            if (not isinstance(last, (int, float)) or isinstance(last, bool) or not isinstance(dauer, (int, float)) or isinstance(dauer, bool)):
                continue
            if self.jobs_last.get(name) == (last, dauer):
                continue                                                    # dieselbe Meldung noch einmal gelesen
            erster = name not in self.jobs_last
            self.jobs_last[name] = (last, dauer)
            e = self.z["jobs"].setdefault(str(name)[:60], {"n": 0, "max": 0.0, "max_ts": None, "letzte": None, "takt": None, "summe": 0.0})
            e["takt"] = j.get("takt") if isinstance(j.get("takt"), (int, float)) else e.get("takt")
            e["letzte"] = round(float(dauer), 1)
            beginn = float(last) - float(dauer); d = float(dauer)
            lauf = self.jobs_lauf.get(name)
            if erster or lauf is None:
                self.jobs_lauf[name] = {"beginn": beginn, "dauer": d, "zaehlt": False}   # lief vor dem Blick des Messfadens: nicht zählen
                continue
            if beginn <= lauf["beginn"] + LAUF_TOLERANZ_S:                  # derselbe Lauf: Zwischenstand oder Abschluss
                if d > lauf["dauer"]:
                    if lauf["zaehlt"]:
                        e["summe"] = round(float(e.get("summe") or 0.0) + d - lauf["dauer"], 1)
                        if d > float(e["max"]):
                            e["max"] = round(d, 1); e["max_ts"] = int(last)
                    lauf["dauer"] = d
                lauf["beginn"] = min(lauf["beginn"], beginn)
                continue
            self.jobs_lauf[name] = {"beginn": beginn, "dauer": d, "zaehlt": True}        # ein neuer Lauf
            e["n"] += 1; e["summe"] = round(float(e.get("summe") or 0.0) + d, 1)
            if d > float(e["max"]):
                e["max"] = round(d, 1); e["max_ts"] = int(last)

    # -------------------------------------------------------------------------------------------- Ablage
    def kuerzen(self, wall: float) -> None:
        grenze = int(wall) // 3600 - STUNDEN_MAX
        for k in [k for k in self.z["stunden"] if int(k) < grenze]:
            del self.z["stunden"][k]

    def speichern(self, pfad: str, wall: float) -> None:
        """Ganz oder gar nicht: erst eine Zwischendatei, dann umbenennen."""
        self.kuerzen(wall)
        self.z["stand"] = int(wall)
        tmp = pfad + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.z, fh, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, pfad)


def laden(pfad: str) -> Messung:
    """Die abgelegte Messung oder eine leere (fehlende oder unlesbare Datei ist kein Fehler)."""
    try:
        with open(pfad, encoding="utf-8") as fh:
            return Messung(json.load(fh))
    except (OSError, ValueError):
        return Messung()


# ================================================================================================ Messfaden (im Wächter-Dienst)

def _verbinden(db: str) -> sqlite3.Connection:
    """Nur lesen (mode=ro): Der Messfaden kann nichts in die Datenbank schreiben und legt keine an."""
    return sqlite3.connect(f"file:{os.path.abspath(db)}?mode=ro", uri=True, timeout=1.0, check_same_thread=False)


def lesen(con: sqlite3.Connection) -> tuple:
    """(Lebenszeichen, Startzeit des Recorders, Text der Aufgaben) -- eine Abfrage."""
    m = dict(con.execute("SELECT k, v FROM meta WHERE k IN ('recorder_alive', 'started', 'jobs')").fetchall())
    return m.get("recorder_alive"), m.get("started"), m.get("jobs")


def messfaden(db: str, stop: threading.Event | None = None, takt: float = TAKT_S, pfad: str | None = None,
              speichern_erst: float = SPEICHERN_ERST_S, speichern_s: float = SPEICHERN_S, wieder_s: float = 5.0) -> Messung:
    """Die Schleife des Messfadens. Bricht nie mit einer Ausnahme ab: Fehler werden gezählt und im Bericht genannt. Gibt nichts aus
    (die Ausgabe des Wächter-Dienstes liest Debug 20)."""
    pfad = pfad or datei_pfad(db)
    m = laden(pfad)
    m.start(time.time())
    con = None
    wieder = 0.0                                                            # nach einem Fehler: frühestens dann neu verbinden
    naechst = time.monotonic()
    ablage = time.monotonic() + speichern_erst
    while not (stop is not None and stop.is_set()):
        jetzt_m = time.monotonic()
        try:
            if con is None and jetzt_m >= wieder:
                con = _verbinden(db)
            if con is not None:
                hb, started, jobs = lesen(con)
                m.beobachte(time.time(), time.monotonic(), hb, started, jobs)
        except Exception as e:                                              # Datenbank fehlt, gesperrt, Tabelle fehlt …
            m.fehler(time.time(), e)
            try:
                if con is not None:
                    con.close()
            except Exception:
                pass
            con = None
            wieder = time.monotonic() + wieder_s
        if time.monotonic() >= ablage:
            try:
                m.speichern(pfad, time.time())
            except Exception as e:
                m.fehler(time.time(), e)
            ablage = time.monotonic() + speichern_s
        naechst += takt
        pause = naechst - time.monotonic()
        if pause < 0:                                                       # im Verzug: nicht nachholen
            naechst = time.monotonic(); pause = 0.0
        if stop is not None:
            stop.wait(pause)
        else:
            time.sleep(pause)
    try:
        m.speichern(pfad, time.time())
    except Exception:
        pass
    try:
        if con is not None:
            con.close()
    except Exception:
        pass
    return m


def starten(db: str, stop: threading.Event | None = None, **kw) -> threading.Thread:
    """Den Messfaden als Hintergrund-Faden starten (endet mit dem Prozess)."""
    t = threading.Thread(target=messfaden, args=(db, stop), kwargs=kw, name="rtakt", daemon=True)
    t.start()
    return t


# ================================================================================================ Auswertung und Bericht

def _zahl(x, d: int = 0) -> str:
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "—"
    return f"{x:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _uhr(ts, sek: bool = False) -> str:
    return "—" if ts is None else time.strftime("%d.%m.%Y %H:%M:%S" if sek else "%d.%m.%Y %H:%M", time.localtime(int(ts)))


def _dauer(s) -> str:
    if s is None:
        return "—"
    s = float(s)
    if s < 120:
        return f"{_zahl(s, 0)} s"
    if s < 7200:
        return f"{_zahl(s / 60, 1)} min"
    return f"{_zahl(s / 3600, 1)} h"


def _mz(n, ein: str, mehr: str) -> str:
    """Zahl mit Einzahl oder Mehrzahl: „1 Runde“, „2 Runden“."""
    return f"{_zahl(n)} {ein if n == 1 else mehr}"


def _quantil(hist: dict, q: float):
    """Quantil aus einem Zählwerk {Wert: Anzahl} (kleinster Wert, bis zu dem der Anteil q erreicht ist)."""
    n = sum(hist.values())
    if not n:
        return None
    ziel = q * n
    lauf = 0
    for v in sorted(hist):
        lauf += hist[v]
        if lauf >= ziel - 1e-9:
            return v
    return max(hist)


def zusammen(stunden: dict, ab_stunde: int | None = None) -> dict:
    """Stundenwerte zu einem Zeitraum zusammenfassen (ab_stunde = Stunde seit 1970, None = alle)."""
    hist: dict = {}; ahist: dict = {}; uahist: dict = {}
    out = {"n": 0, "unsicher": 0, "umax": 0, "mess": 0.0, "luecken": 0, "max": 0, "max_ts": None, "amax": 0.0, "stunden": 0}
    for k, s in stunden.items():
        if ab_stunde is not None and int(k) < ab_stunde:
            continue
        out["stunden"] += 1
        out["n"] += int(s.get("n") or 0); out["unsicher"] += int(s.get("unsicher") or 0)
        out["mess"] += float(s.get("mess") or 0.0); out["luecken"] += int(s.get("luecken") or 0)
        if int(s.get("max") or 0) > out["max"]:
            out["max"] = int(s["max"]); out["max_ts"] = s.get("max_ts")
        out["amax"] = max(out["amax"], float(s.get("amax") or 0.0))
        out["umax"] = max(out["umax"], int(s.get("umax") or 0))
        for d, c in (s.get("uahist") or {}).items():
            uahist[int(d)] = uahist.get(int(d), 0) + int(c)
        for d, c in (s.get("hist") or {}).items():
            hist[int(d)] = hist.get(int(d), 0) + int(c)
        for d, c in (s.get("ahist") or {}).items():
            ahist[int(d)] = ahist.get(int(d), 0) + int(c)
    out["hist"] = hist; out["ahist"] = ahist
    out["median"] = _quantil(hist, 0.5); out["p99"] = _quantil(hist, 0.99)
    kl = [0] * (len(KLASSEN) + 1)
    for d, c in hist.items():
        kl[next((i for i, g in enumerate(KLASSEN) if d <= g), len(KLASSEN))] += c
    out["klassen"] = kl
    out["fristen"] = {f: sum(c for a, c in ahist.items() if a > f) for f in FRISTEN}
    out["ufristen"] = {f: sum(c for a, c in uahist.items() if a > f) for f in FRISTEN}
    return out


def schnappschuesse(con, jetzt: float, soll: int = SOLL_SCHNAPPSCHUSS_S, tage: int = SCHNAPP_TAGE) -> dict | None:
    """
    Schnappschuss-Runden aus snapshot_meta: Der Recorder wartet `soll` Sekunden, schreibt dann (ts = Beginn des Schreibens). Der
    Abstand zweier Schnappschüsse minus `soll` ist also die Zeit, die eine Runde über die Pause hinaus brauchte. Abstände über das
    Doppelte des Solls und solche über einen Neustart hinweg (uptime kleiner als der Abstand) zählen als Lücke, nicht als Runde.
    Seit 23.116 (U294): Ein Abstand UNTER der Pause ist keine Runde. Beim Beenden schreibt der Recorder einen letzten Schnappschuss
    (hl_recorder.run: write_snapshot nach dem Stopp) -- er ist die letzte Zeile vor einem Neustart oder die letzte überhaupt und
    steht unter „abschluss“. Ein kurzer Abstand ohne Neustart danach steht unter „verkuerzt“ (das dürfte es nicht geben).
    """
    try:
        rows = con.execute("SELECT ts, uptime FROM snapshot_meta WHERE ts >= ? ORDER BY ts", (int(jetzt) - tage * 86400,)).fetchall()
    except sqlite3.Error:
        return None
    dauern = []; luecken = []; abschluss = []; verkuerzt = []

    def ueber_neustart(k: int) -> bool:
        """Liegt zwischen Zeile k−1 und Zeile k ein Neustart? (uptime der späteren Zeile kleiner als der Abstand)"""
        u = rows[k][1]
        return u is not None and int(u) < int(rows[k][0]) - int(rows[k - 1][0])
    for k in range(1, len(rows)):
        (t0, _u0), (t1, u1) = rows[k - 1], rows[k]
        d = int(t1) - int(t0)
        if d > 2 * soll or (u1 is not None and int(u1) < d):
            luecken.append((int(t1), d))
        elif d < soll:
            (abschluss if k == len(rows) - 1 or ueber_neustart(k + 1) else verkuerzt).append((int(t1), d))
        else:
            dauern.append((d - soll, int(t1)))
    out = {"n": len(dauern), "zeilen": len(rows), "luecken": luecken, "soll": soll, "tage": tage, "abschluss": abschluss, "verkuerzt": verkuerzt,
           "von": int(rows[0][0]) if rows else None, "bis": int(rows[-1][0]) if rows else None}
    if dauern:
        ds = sorted(d for d, _t in dauern)
        out.update(median=ds[len(ds) // 2], p90=ds[min(len(ds) - 1, int(math.ceil(0.9 * len(ds))) - 1)], max=max(dauern)[0],
                   max_ts=max(dauern)[1], min=ds[0],
                   ueber={g: sum(1 for d in ds if d > g) for g in (10, 30, 60, 120)})
    return out


def bericht(db: str, jetzt: float | None = None, pfad: str | None = None) -> str:
    """Text für Debug 157. Liest die Messdatei und die Hauptdatenbank (nur lesen)."""
    jetzt = time.time() if jetzt is None else float(jetzt)
    pfad = pfad or datei_pfad(db)
    z = []
    a = z.append
    a(f"★ Recorder: Takt der Runden (U287, Messung; Debug {DEBUG_NR}) · Modul {VERSION_MODUL} · {_uhr(jetzt)}")
    a("  Nur gelesen: Ein Messfaden im Wächter-Dienst liest jede Sekunde das Lebenszeichen des Recorders. Am Recorder ändert sich nichts.")
    a("  Zweck: wissen, wie lange ein gesunder Recorder schweigen kann -- bevor er einen Schutz gegen Hänger bekommt (U287).")
    a("")
    # ---- Messdatei
    Z = None
    try:
        with open(pfad, encoding="utf-8") as fh:
            Z = json.load(fh)
    except OSError:
        pass
    except ValueError:
        Z = "kaputt"
    hb = started = jobs_roh = None
    con = None
    db_fehler = None
    try:
        con = _verbinden(db)
        hb, started, jobs_roh = lesen(con)
    except sqlite3.Error as e:
        db_fehler = f"{type(e).__name__}: {e}"
    a("1 MESSUNG")
    if not isinstance(Z, dict) or Z.get("format") != FORMAT:
        a("  Noch keine Messdatei" + (" (die vorhandene ist nicht lesbar)" if Z is not None else "") + f": {pfad}")
        a("  Der Messfaden startet mit dem Wächter-Dienst (hl-watchdog) und legt eine Minute nach dessen Start zum ersten Mal ab, danach")
        a("  alle 5 Minuten. Fehlt die Datei länger: Läuft der Dienst? (Debug 20 nennt die Dienste.)")
        Z = None
    else:
        alt = jetzt - (Z.get("stand") or 0)
        ges = zusammen(Z.get("stunden") or {})
        spanne = max(1.0, (Z.get("stand") or jetzt) - (Z.get("seit") or jetzt))
        a(f"  läuft seit {_uhr(Z.get('seit'))} · zuletzt abgelegt vor {_dauer(alt)}"
          + (" -- ÄLTER ALS 15 MINUTEN: Der Messfaden läuft wohl nicht (Dienst hl-watchdog?)" if alt > 900 else "")
          + f" · Starts des Messfadens {Z.get('starts', 0)}")
        a(f"  beobachtet {_dauer(ges['mess'])} in {_mz(ges['stunden'], 'Stunde', 'Stunden')} mit Werten (aufbewahrt: 14 Tage) · "
          f"{_mz(ges['n'], 'Runde', 'Runden')} · Uhrsprünge {Z.get('uhrsprung', 0)}")
        if ges["unsicher"]:
            a(f"  unsicher: {_mz(ges['unsicher'], 'Abstand', 'Abstände')}, der längste {ges['umax']} s"
              + f" -- der Messfaden pausierte dabei selbst über {LUECKE_S:.0f} s; so ein Abstand kann aus mehreren Runden bestehen (nie zu")
            a("  klein, vielleicht zu groß). Er zählt nicht in die Verteilung, steht aber bei den längsten und bei den Fristen daneben.")
        else:
            a(f"  unsicher: kein Abstand (unsicher wäre einer, bei dem der Messfaden selbst über {LUECKE_S:.0f} s pausierte)")
        f = Z.get("fehler") or {}
        if f.get("n"):
            a(f"  Lesefehler des Messfadens: {f['n']} (zuletzt {_uhr(f.get('ts'))}: {f.get('letzter')})")
    if db_fehler:
        a(f"  Hauptdatenbank nicht lesbar: {db_fehler}")
    elif hb is None:
        a("  Lebenszeichen des Recorders: keines in der Datenbank (meta „recorder_alive“ fehlt) -- läuft der Recorder?")
    else:
        try:
            a(f"  Lebenszeichen jetzt: vor {_dauer(jetzt - int(float(hb)))}"
              + (f" · Recorder läuft seit {_uhr(int(float(started)))}" if started else ""))
        except (TypeError, ValueError):
            a(f"  Lebenszeichen nicht lesbar: {str(hb)[:40]!r}")
    a("")
    if Z is not None:
        std = Z.get("stunden") or {}
        h_jetzt = int(jetzt) // 3600
        # ---- 2 Schreibrunden
        a(f"2 SCHREIBRUNDEN -- Abstand zwischen zwei Lebenszeichen (Soll {SOLL_SCHREIBEN_S} s; Uhr des Recorders)")
        kopf = "bis " + " · bis ".join(f"{g} s" for g in KLASSEN) + " · darüber"
        a(f"  {'Zeitraum':<16}{'Runden':>9}{'Median':>9}{'99 %':>8}{'längste':>10}   Klassen: {kopf}")
        for name, ab in (("letzte 24 h", h_jetzt - 24), ("letzte 7 Tage", h_jetzt - 168), ("alles", None)):
            g = zusammen(std, ab)
            if not g["n"]:
                a(f"  {name:<16}{'0':>9}")
                continue
            a(f"  {name:<16}{_zahl(g['n']):>9}{str(g['median']) + ' s':>9}{str(g['p99']) + ' s':>8}{str(g['max']) + ' s':>10}   "
              + " · ".join(_zahl(c) for c in g["klassen"]))
        L = Z.get("laengste") or []
        if L:
            a("  Die längsten Abstände (Ende der Runde · Abstand · Alter des Lebenszeichens von außen):")
            for e in L[:10]:
                a(f"    {_uhr(e.get('hb'), True)} · {e.get('d')} s · {_zahl(e.get('alter'), 1)} s" + (" · unsicher" if e.get("u") else ""))
        a("  Je Stunde, letzte 24 (Ortszeit · Runden · längste · unsicher · beobachtet):")
        zeilen = []
        for k in sorted((k for k in std if int(k) >= h_jetzt - 24), key=int):
            s = std[k]
            zeilen.append(f"{time.strftime('%d.%m. %H', time.localtime(int(k) * 3600))} h · {s.get('n', 0)} · {s.get('max', 0)} s · "
                          f"{s.get('unsicher', 0)} · {min(100, round(100 * float(s.get('mess') or 0) / 3600))} %")
        for i in range(0, len(zeilen), 3):
            a("    " + "   |   ".join(zeilen[i:i + 3]))
        if not zeilen:
            a("    keine Werte")
        a("")
        # ---- 3 Fristen
        a("3 WIE OFT WÄRE EINE FRIST ÜBERSCHRITTEN WORDEN? (Alter des Lebenszeichens von außen, in der beobachteten Zeit)")
        g = zusammen(std)
        a("  " + " · ".join(f"über {f} s: {_zahl(g['fristen'][f])}-mal" + (f" (+{g['ufristen'][f]} unsicher)" if g["ufristen"][f] else "")
                           for f in FRISTEN))
        a(f"  größtes Alter: {_zahl(g['amax'], 1)} s. Dazu kämen die Neustarts (Abschnitt 4): Dort schweigt der Recorder länger -- eine Frist")
        a("  braucht deshalb eine Schonzeit nach dem Start (beim Dashboard sind es 10 Minuten).")
        a("")
        # ---- 4 Neustarts
        N = Z.get("neustarts") or []
        a(f"4 NEUSTARTS DES RECORDERS IN DER BEOBACHTETEN ZEIT ({len(N)}; aufbewahrt: die letzten {NEUSTARTS_MAX})")
        if not N:
            a("  keiner beobachtet")
        for e in N[-12:]:
            a(f"  Start {_uhr(e.get('ts'), True)} · Pause zwischen den Lebenszeichen {_dauer(e.get('pause'))} · vom Start bis zum ersten "
              f"Lebenszeichen {_dauer(e.get('anlauf'))}" + (" · unsicher (eigene Pause des Messfadens)" if e.get("unsicher") else ""))
        a("")
    # ---- 5 Schnappschüsse (aus der Datenbank, auch ohne Messdatei)
    soll = SOLL_SCHNAPPSCHUSS_S
    J = None
    try:
        J = json.loads(jobs_roh) if jobs_roh else None
        if isinstance(J, dict) and isinstance((J.get("Snapshots") or {}).get("takt"), (int, float)):
            soll = int(J["Snapshots"]["takt"])
    except (TypeError, ValueError):
        J = None
    a(f"5 SCHNAPPSCHUSS-RUNDEN -- aus snapshot_meta, letzte {SCHNAPP_TAGE} Tage (Soll: {soll} s Pause, dann schreiben)")
    S = schnappschuesse(con, jetzt, soll) if con is not None else None
    if S is None:
        a("  nicht lesbar" + (f" ({db_fehler})" if db_fehler else " (Tabelle snapshot_meta fehlt)"))
    elif not S["n"]:
        a(f"  keine zwei aufeinanderfolgenden Schnappschüsse im Zeitraum ({S['zeilen']} Zeilen)")
    else:
        a(f"  {_mz(S['n'], 'Runde', 'Runden')} von {_uhr(S['von'])} bis {_uhr(S['bis'])} · Zeit über die Pause hinaus: Median {S['median']} s · "
          f"90 % bis {S['p90']} s · längste {S['max']} s ({_uhr(S['max_ts'], True)}) · kürzeste {S['min']} s")
        a("  " + " · ".join(f"über {g_} s: {c}" for g_, c in S["ueber"].items())
          + f" · Lücken (Abstand über {2 * soll} s oder Neustart dazwischen): {len(S['luecken'])}")
        for t_, d_ in S["luecken"][-6:]:
            a(f"    Lücke bis {_uhr(t_, True)}: {_dauer(d_)}")
    if S is not None and S.get("abschluss"):
        t_, d_ = S["abschluss"][-1]
        a(f"  Nicht als Runde gezählt: {_mz(len(S['abschluss']), 'Schnappschuss', 'Schnappschüsse')} beim Beenden des Recorders -- zuletzt "
          f"{_uhr(t_, True)}, {_dauer(d_)} nach dem vorigen (der Recorder schreibt beim Beenden einen letzten Stand; die Pause war da nicht um)")
    if S is not None and S.get("verkuerzt"):
        t_, d_ = S["verkuerzt"][-1]
        a(f"  Nicht als Runde gezählt: {_mz(len(S['verkuerzt']), 'Abstand', 'Abstände')} unter der Pause OHNE Neustart danach -- zuletzt "
          f"{_uhr(t_, True)}, {_dauer(d_)} nach dem vorigen. Das dürfte es nicht geben (Hinweis auf eine verstellte Uhr).")
    a("")
    # ---- 6 Aufgaben
    a("6 AUFGABEN, DIE DER RECORDER SELBST MELDET (meta „jobs“) -- Dauer der letzten Runde; in der beobachteten Zeit: Läufe, Mittel, längste")
    ZJ = (Z or {}).get("jobs") or {}
    if (Z or {}).get("jobs_seit"):
        a(f"  gezählt seit {_uhr((Z or {}).get('jobs_seit'), True)} -- ein Lauf zählt einmal, auch wenn der Recorder Zwischenstände meldet (seit 23.117; "
          "die Zähler davor sind verworfen: sie zählten jeden Zwischenstand als Lauf)")
    namen = sorted(set(ZJ) | set(J if isinstance(J, dict) else {}))
    if not namen:
        a("  keine Angaben" + (" (meta „jobs“ ist bei 4.000 Zeichen abgeschnitten und nicht lesbar)" if jobs_roh and J is None else ""))
    for name in namen:
        j = (J or {}).get(name) if isinstance(J, dict) else None
        e = ZJ.get(name) or {}
        takt = (j or {}).get("takt") if isinstance(j, dict) else None
        takt = takt if takt is not None else e.get("takt")
        letzte = (j or {}).get("dauer") if isinstance(j, dict) else None
        letzte = letzte if letzte is not None else e.get("letzte")
        n = int(e.get("n") or 0)
        a(f"  {name[:34]:<34} Takt {_dauer(takt):>9} · zuletzt {('—' if letzte is None else _zahl(float(letzte), 1) + ' s'):>9}"
          + (f" · {_mz(n, 'Lauf', 'Läufe')} · Mittel {_zahl(float(e.get('summe') or 0) / n, 1)} s · längste {_zahl(float(e.get('max') or 0), 1)} s "
             f"({_uhr(e.get('max_ts'), True)})" if n else " · in der beobachteten Zeit kein Lauf mit Dauer")
          + ("" if not isinstance(j, dict) or j.get("ok", True) else " · zuletzt NICHT ok"))
    a("")
    # ---- 7 Lesart
    a("7 LESART")
    a("  - Abstand und Alter stammen aus dem Lebenszeichen, das der Recorder am Ende jeder Schreibrunde ablegt. Ein langer Abstand heißt:")
    a("    Der Recorder kam so lange nicht zum Schreiben (Schnappschuss, Sicherung, Aufräumen, volle Datenbank) -- nicht, dass er hing.")
    a("  - Die Messung sagt, was bisher vorkam. Eine Frist für einen Hänger-Schutz braucht Abstand zum längsten gesunden Schweigen und")
    a("    mehrere Tage Beobachtung (Sicherung täglich, Aufräumen seltener). Entschieden wird das mit U287, nicht hier.")
    a("  - Aufgaben, die öfter als alle 10 s laufen, sieht der Messfaden nur jedes zehnte Mal etwa; ihre längste Dauer kann fehlen.")
    a("  - Meldet eine Aufgabe Zwischenstände (Leaderboard-Fills, Pool-Fills), zählt ihr Lauf einmal; solange er läuft, geht er mit seiner")
    a("    bisherigen Dauer in Mittel und „längste“ ein.")
    if con is not None:
        con.close()
    return "\n".join(z) + "\n"


# ================================================================================================ Selbsttest (ohne Netz, ohne Recorder)

def _spiel(m: Messung, t0: int, sek: int, zeichen: list, started, jobs: str | None = None, pause: dict | None = None) -> list:
    """
    Nachgestellter Lauf: jede Sekunde ein Lesen ab t0. zeichen = [(sichtbar ab, Wert), …] in zeitlicher Folge; started = Zahl oder
    [(gilt ab, Wert), …]; pause = {Sekunde: zusätzliche eigene Pause des Messfadens}. Rückgabe: was je Lesen festgehalten wurde.
    """
    aus = []
    mono = 1000.0 if m.mono is None else m.mono + 1.0                       # die Stoppuhr läuft über mehrere Aufrufe weiter
    wall = float(t0)
    i = 0
    hb = None
    for k in range(sek):
        while i < len(zeichen) and zeichen[i][0] <= wall:
            hb = zeichen[i][1]; i += 1
        st = started
        if isinstance(started, list):
            st = [v for (ab, v) in started if ab <= wall][-1]
        aus.append(m.beobachte(wall, mono, hb, st, jobs))
        schritt = 1.0 + float((pause or {}).get(k, 0.0))
        wall += schritt; mono += schritt
    return aus


def selbsttest(verbose: bool = True) -> bool:
    import calendar
    import shutil
    import tempfile
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_rtakt -- Selbsttest (Messung der Recorder-Runden; ohne Netz, ohne den echten Recorder)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_rtakt_test_")
    try:
        T0 = calendar.timegm((2026, 11, 20, 12, 0, 0))                     # volle Stunde
        ST = T0 - 5000
        # ---- R1 gleichmäßige Runden
        z1 = [(T0 + 3 + 10 * i + 0.4, T0 + 3 + 10 * i) for i in range(60)]  # Schreiben um :03, :13, …; sichtbar 0,4 s später
        m1 = Messung(); m1.start(T0)
        a1 = _spiel(m1, T0, 600, z1, ST)
        s1 = m1.z["stunden"][str(T0 // 3600)]
        ok("R1 Gleichmäßige Runden: 60 Lebenszeichen im Abstand von 10 s ergeben 59 Runden von je 10 s (das erste Lebenszeichen hat "
           "keinen Vorgänger); von außen wird das Lebenszeichen 11 s alt (10 s Runde, sichtbar beim nächsten Lesen); die beobachtete "
           "Zeit ist die Summe der eigenen Leseabstände",
           a1.count("runde") == 59 and a1.count("erster") == 1 and s1["n"] == 59 and s1["hist"] == {"10": 59} and s1["ahist"] == {"11": 59}
           and s1["max"] == 10 and s1["amax"] == 11.0 and s1["unsicher"] == 0 and s1["luecken"] == 0 and abs(s1["mess"] - 599.0) < 1e-6
           and m1.z["uhrsprung"] == 0 and m1.z["neustarts"] == [] and m1.z["gelesen"] == 600 and m1.z["seit"] == T0 and m1.z["starts"] == 1
           and a1[:3] == [None, None, None] and a1[4] == "erster" and m1.z["ohne_wert"] == 4,
           f"{s1['n']} Runden, Zählwerk {s1['hist']}, Alter {s1['ahist']}")
        # ---- R2 eine lange Runde
        z2 = [(t + 0.4, t) for t in [T0 + 3 + 10 * i for i in range(20)] + [T0 + 243] + [T0 + 253 + 10 * i for i in range(20)]]
        m2 = Messung(); m2.start(T0)
        _spiel(m2, T0, 470, z2, ST)
        g2 = zusammen(m2.z["stunden"])
        ok("R2 Eine lange Runde (50 s zwischen zwei Lebenszeichen): Sie ist die längste, steht mit Uhrzeit oben in der Liste, fällt in "
           "die Klasse „bis 60 s“; eine Frist von 30 s wäre einmal überschritten worden, eine von 60 s nie; der Median bleibt 10 s (der "
           "99-%-Wert ist bei 40 Runden schon die längste)",
           g2["n"] == 40 and g2["max"] == 50 and g2["max_ts"] == T0 + 243 and g2["hist"] == {10: 39, 50: 1} and g2["median"] == 10
           and g2["p99"] == 50 and g2["klassen"] == [39, 0, 0, 1, 0, 0, 0] and g2["fristen"] == {30: 1, 60: 0, 120: 0, 180: 0, 300: 0, 600: 0}
           and m2.z["laengste"][0] == {"hb": T0 + 243, "d": 50, "alter": 51.0, "u": False} and m2.z["laengste"][1]["d"] == 10
           and g2["amax"] == 51.0 and g2["unsicher"] == 0,
           f"längste {g2['max']} s, Klassen {g2['klassen']}, Fristen {g2['fristen']}")
        # ---- R3 eigene Pause des Messfadens
        m3 = Messung(); m3.start(T0)
        a3 = _spiel(m3, T0, 300, z1[:35], ST, pause={100: 30.0})           # nach dem 100. Lesen pausiert der Messfaden 30 s
        g3 = zusammen(m3.z["stunden"])
        ok("R3 Pausiert der Messfaden selbst (30 s), ist der Abstand, in den die Pause fällt, unsicher: Er kann aus mehreren Runden "
           "bestehen (hier drei). Er zählt nicht in die Verteilung, bleibt aber sichtbar -- als längster unsicherer Abstand, in der "
           "Liste der längsten (markiert) und neben den Fristen; die Runden davor und danach zählen normal",
           a3.count("unsicher") == 1 and g3["unsicher"] == 1 and g3["umax"] == 30 and g3["hist"] == {10: g3["n"]} and g3["max"] == 10
           and g3["luecken"] == 1 and m3.z["laengste"][0]["u"] is True and m3.z["laengste"][0]["d"] == 30 and m3.z["laengste"][0]["alter"] == 38.0
           and g3["ufristen"][30] == 1 and g3["fristen"][30] == 0 and g3["n"] == a3.count("runde") >= 25
           and abs(g3["mess"] - 298.0) < 1e-6,
           f"{g3['n']} Runden, unsicher {g3['unsicher']} (längster {g3['umax']} s)")
        # ---- R4 Neustart des Recorders
        z4 = [(t + 0.4, t) for t in [T0 + 3 + 10 * i for i in range(10)]]   # letztes Lebenszeichen T0+93
        neu_start = T0 + 120
        z4 += [(t + 0.4, t) for t in [neu_start + 25 + 10 * i for i in range(10)]]
        m4 = Messung(); m4.start(T0)
        a4 = _spiel(m4, T0, 260, z4, [(T0, ST), (neu_start, neu_start)])
        g4 = zusammen(m4.z["stunden"])
        ok("R4 Neustart des Recorders (seine Startzeit in meta „started“ liegt zwischen zwei Lebenszeichen): Der Abstand über den "
           "Neustart hinweg ist keine Runde -- er steht bei den Neustarts mit Startzeit, Pause zwischen den Lebenszeichen (52 s) und "
           "Anlauf vom Start bis zum ersten Lebenszeichen (25 s)",
           a4.count("neustart") == 1 and m4.z["neustarts"] == [{"ts": neu_start, "pause": 52, "anlauf": 25, "vorher": T0 + 93, "unsicher": False}]
           and g4["hist"] == {10: 18} and g4["max"] == 10 and g4["n"] == 18 and m4.z["uhrsprung"] == 0,
           f"{m4.z['neustarts']}")
        # ---- R4b der Messfaden beginnt erst NACH dem Start des Recorders (nach einem Einspielen starten beide Dienste fast zugleich)
        z4b = [(T0 + 93.4, T0 + 93)] + [(t + 0.4, t) for t in [neu_start + 25 + 10 * i for i in range(8)]]
        m4b = Messung(); m4b.start(neu_start + 5)
        a4b = _spiel(m4b, neu_start + 5, 100, z4b, neu_start)               # erstes Lesen: altes Lebenszeichen, schon die neue Startzeit
        g4b = zusammen(m4b.z["stunden"])
        ok("R4b Beginnt der Messfaden erst nach dem Start des Recorders -- sein erstes Lesen sieht das alte Lebenszeichen und schon die "
           "neue Startzeit --, ist der Abstand bis zum ersten Lebenszeichen des neuen Laufs trotzdem ein Neustart und keine Runde "
           "(entschieden nach den Zeitstempeln des Recorders: Start nach dem vorigen, nicht nach dem neuen Lebenszeichen)",
           a4b[0] == "erster" and a4b.count("neustart") == 1 and m4b.z["neustarts"] == [{"ts": neu_start, "pause": 52, "anlauf": 25, "vorher": T0 + 93,
                                                                                         "unsicher": False}]
           and g4b["hist"] == {10: 7} and g4b["max"] == 10 and g4b["n"] == a4b.count("runde") == 7 and g4b["fristen"][30] == 0
           and all(e["d"] == 10 for e in m4b.z["laengste"]),
           f"{m4b.z['neustarts']} · Runden {g4b['hist']}")
        # ---- R4c neue Startzeit und letztes Lebenszeichen des ALTEN Laufs im selben Lesen (der Messfaden pausierte selbst)
        z4c = [(t + 0.4, t) for t in [T0 + 3 + 10 * i for i in range(10)]]  # alter Lauf bis T0+93
        z4c += [(t + 0.4, t) for t in [T0 + 130 + 10 * i for i in range(4)]]  # neuer Lauf: Start T0+105, erstes Lebenszeichen T0+130
        m4c = Messung(); m4c.start(T0)
        a4c = _spiel(m4c, T0, 140, z4c, [(T0, ST), (T0 + 105, T0 + 105)], pause={85: 30.0})   # Lesen bei T0+85, dann erst bei T0+116
        g4c = zusammen(m4c.z["stunden"])
        ok("R4c Sieht der Messfaden nach einer eigenen Pause die neue Startzeit und das letzte Lebenszeichen des alten Laufs im selben "
           "Lesen, gehört dieses Lebenszeichen noch zum alten Lauf (ein Abstand von 10 s, unsicher wegen der eigenen Pause). Der Neustart "
           "steht erst beim ersten Lebenszeichen des neuen Laufs -- mit der ganzen Pause (37 s) und dem Anlauf ab der Startzeit (25 s), "
           "nie mit einem negativen Anlauf",
           a4c.count("neustart") == 1 and m4c.z["neustarts"] == [{"ts": T0 + 105, "pause": 37, "anlauf": 25, "vorher": T0 + 93, "unsicher": False}]
           and a4c.count("unsicher") == 1 and g4c["unsicher"] == 1 and g4c["umax"] == 10 and g4c["hist"] == {10: g4c["n"]} and g4c["max"] == 10
           and g4c["n"] == a4c.count("runde") == 11 and all(e["d"] == 10 for e in m4c.z["laengste"]),
           f"{m4c.z['neustarts']} · unsicher {g4c['unsicher']} (längster {g4c['umax']} s) · Runden {g4c['hist']}")
        # ---- R4d Grenzfall: erstes Lebenszeichen des neuen Laufs in derselben Sekunde wie seine Startzeit
        z4d = [(t + 0.4, t) for t in [T0 + 3 + 10 * i for i in range(5)]]   # alter Lauf bis T0+43
        z4d += [(t + 0.4, t) for t in [T0 + 70 + 10 * i for i in range(5)]]  # neuer Lauf: Start T0+70, erstes Lebenszeichen T0+70
        m4d = Messung(); m4d.start(T0)
        a4d = _spiel(m4d, T0, 120, z4d, [(T0, ST), (T0 + 70, T0 + 70)])
        g4d = zusammen(m4d.z["stunden"])
        ok("R4d Grenzfall: Schreibt der neue Lauf sein erstes Lebenszeichen in derselben Sekunde wie seine Startzeit, steht der Neustart "
           "genau einmal da (Pause 27 s, Anlauf 0 s); die Runde danach ist eine Runde und kein zweiter Neustart",
           a4d.count("neustart") == 1 and m4d.z["neustarts"] == [{"ts": T0 + 70, "pause": 27, "anlauf": 0, "vorher": T0 + 43, "unsicher": False}]
           and g4d["hist"] == {10: 8} and g4d["n"] == a4d.count("runde") == 8 and g4d["max"] == 10,
           f"{m4d.z['neustarts']} · Runden {g4d['hist']}")
        # ---- R5 Uhrsprung
        z5 = [(T0 + 3.4, T0 + 3), (T0 + 13.4, T0 + 13), (T0 + 23.4, T0 + 23 - 3600), (T0 + 33.4, T0 + 33 - 3600),
              (T0 + 43.4, T0 + 43 + 7 * 3600), (T0 + 53.4, T0 + 53 + 7 * 3600)]
        m5 = Messung(); m5.start(T0)
        a5 = _spiel(m5, T0, 70, z5, ST)
        g5 = zusammen(m5.z["stunden"])
        ok("R5 Verstellte Uhr: Ein Lebenszeichen, das rückwärts springt oder mehr als 6 Stunden voraus, ist keine Runde -- es wird als "
           "Uhrsprung gezählt; die Runden davor und danach zählen",
           a5.count("sprung") == 2 and m5.z["uhrsprung"] == 2 and g5["n"] == 3 and g5["hist"] == {10: 3} and g5["max"] == 10,
           f"Sprünge {m5.z['uhrsprung']}, Runden {g5['n']}")
        # ---- R6 Neustart des Messfadens: kein Abstand über die Lücke
        m6 = Messung(); m6.start(T0)
        _spiel(m6, T0, 50, z1[:5], ST)
        n_vor = zusammen(m6.z["stunden"])["n"]
        m6.start(T0 + 4000)                                                # der Wächter-Dienst startet neu
        a6 = _spiel(m6, T0 + 4000, 30, [(T0 + 4003.4, T0 + 4003), (T0 + 4013.4, T0 + 4013), (T0 + 4023.4, T0 + 4023)], ST)
        g6 = zusammen(m6.z["stunden"])
        ok("R6 Startet der Messfaden neu (Wächter-Dienst neu gestartet), gibt es keinen Abstand über seine Abwesenheit: Das erste "
           "Lebenszeichen danach hat wieder keinen Vorgänger; „seit“ bleibt der erste Start, die Starts werden gezählt",
           a6.count("erster") == 1 and g6["n"] == n_vor + 2 and g6["max"] == 10 and m6.z["starts"] == 2 and m6.z["seit"] == T0
           and g6["unsicher"] == 0 and m6.z["uhrsprung"] == 0,
           f"Runden {n_vor} + 2, längste {g6['max']} s")
        # ---- R7 Ablage
        pf = os.path.join(tmp, "a", DATEI); os.makedirs(os.path.dirname(pf))
        m2.z["stunden"][str(T0 // 3600 - STUNDEN_MAX - 5)] = {"n": 7, "hist": {"10": 7}, "ahist": {"11": 7}, "max": 10, "max_ts": 1,
                                                              "amax": 11.0, "unsicher": 0, "umax": 0, "uahist": {}, "mess": 70.0, "luecken": 0}
        m2.z["stunden"][str(T0 // 3600 - STUNDEN_MAX + 5)] = {"n": 5, "hist": {"10": 5}, "ahist": {"11": 5}, "max": 10, "max_ts": 2,
                                                              "amax": 11.0, "unsicher": 0, "umax": 0, "uahist": {}, "mess": 50.0, "luecken": 0}
        m2.speichern(pf, T0 + 500)
        z_ablage = json.loads(json.dumps(m2.z))
        m2b = laden(pf)
        with open(pf, "w", encoding="utf-8") as fh:
            fh.write('{"format": 1, "stunden": {"1": {"n":')              # abgeschnitten
        leer1 = laden(pf)
        with open(pf, "w", encoding="utf-8") as fh:
            json.dump({"format": 99, "seit": 5, "stunden": {"1": {"n": 3}}}, fh)
        leer2 = laden(pf)
        pf7 = os.path.join(tmp, "a", "ganz.json")
        m1.speichern(pf7, T0 + 700)
        echt_dump = json.dump

        def halb(obj, fh, **kw):                                           # das Schreiben bricht mittendrin ab (Platte voll, Strom weg)
            fh.write('{"format": 1, "stun'); fh.flush()
            raise OSError("kein Platz mehr")
        abbruch = False
        try:
            json.dump = halb
            m2.speichern(pf7, T0 + 800)
        except OSError:
            abbruch = True
        finally:
            json.dump = echt_dump
        ganz = laden(pf7)
        m7 = Messung(); m7.start(T0)
        _spiel(m7, T0, 1200, [(T0 + 3 + sum(range(i + 1)) + 0.4, T0 + 3 + sum(range(i + 1))) for i in range(1, 45)], ST)   # Abstände 2, 3, 4, …
        for i in range(60):
            m7.z["neustarts"].append({"ts": i}); del m7.z["neustarts"][:-NEUSTARTS_MAX]
        ok("R7 Ablage: ganz oder gar nicht (Zwischendatei, dann umbenennen -- es bleibt keine Zwischendatei liegen; bricht das Schreiben "
           "mittendrin ab, steht die vorige Datei unversehrt da); gelesen ergibt sie denselben Zustand; Stunden älter als 14 Tage fallen "
           "beim Ablegen weg; eine abgeschnittene Datei oder ein fremdes Format "
           "ergibt eine leere Messung statt eines Fehlers; die Liste der längsten hält 30, absteigend; die der Neustarts 50",
           m2b.z == z_ablage and m2b.z["stand"] == T0 + 500 and not os.path.exists(pf + ".tmp")
           and abbruch and ganz.z["stand"] == T0 + 700 and ganz.z["stunden"] == m1.z["stunden"] and ganz.z["seit"] == T0
           and str(T0 // 3600 - STUNDEN_MAX - 5) not in m2b.z["stunden"] and str(T0 // 3600 - STUNDEN_MAX + 5) in m2b.z["stunden"]
           and leer1.z["stunden"] == {} and leer1.z["seit"] is None and leer2.z["stunden"] == {} and leer2.z["seit"] is None
           and laden(os.path.join(tmp, "gibt", "es", "nicht.json")).z["stunden"] == {}
           and len(m7.z["laengste"]) == LAENGSTE_MAX == 30 and [e["d"] for e in m7.z["laengste"]] == list(range(44, 14, -1))
           and len(m7.z["neustarts"]) == NEUSTARTS_MAX == 50 and m7.z["neustarts"][-1] == {"ts": 59},
           f"{len(m2b.z['stunden'])} Stunden abgelegt, längste Liste {len(m7.z['laengste'])}")
        # ---- R8 Aufgaben
        m8 = Messung(); m8.start(T0)

        def jobs(**kw):
            return json.dumps({n_: {"last": l_, "takt": 600, "dauer": d_, "ok": True} for n_, (l_, d_) in kw.items()})
        m8.beobachte(T0, 1.0, T0, ST, jobs(Snapshots=(T0 - 100, 3.2), Backup=(T0 - 9000, 300.0)))        # lief vor dem ersten Blick
        m8.beobachte(T0 + 1, 2.0, T0, ST, jobs(Snapshots=(T0 - 100, 3.2), Backup=(T0 - 9000, 300.0)))
        m8.beobachte(T0 + 2, 3.0, T0, ST, jobs(Snapshots=(T0 + 500, 41.5), Backup=(T0 - 9000, 300.0)))
        m8.beobachte(T0 + 3, 4.0, T0, ST, jobs(Snapshots=(T0 + 500, 41.5), Backup=(T0 - 9000, 300.0), Neu=(T0 + 3, 0.5)))   # derselbe Lauf, anderer Text
        m8.beobachte(T0 + 4, 5.0, T0, ST, jobs(Snapshots=(T0 + 1100, 2.5), Backup=(T0 - 9000, 300.0)))
        m8.beobachte(T0 + 5, 6.0, T0, ST, '{"Snapshots": {"last": 1, "takt": 600, "dau')                 # abgeschnitten
        m8.beobachte(T0 + 8, 9.0, T0, ST, jobs(Snapshots=(T0 + 1700, 60.0), Backup=(T0 - 9000, 300.0)))  # später ein längerer Lauf
        m8.beobachte(T0 + 6, 7.0, T0, ST, '[1, 2]')
        m8.beobachte(T0 + 9, 10.0, T0, ST, json.dumps({"X": {"last": T0, "dauer": True}, "Y": "kein Objekt", "Z": {"last": T0}}))
        j8 = m8.z["jobs"]
        ok("R8 Aufgaben aus meta „jobs“: Ein Lauf zählt, wenn sich „last“ ändert -- einmal, auch wenn er mehrmals gelesen wird; was vor "
           "dem ersten Blick lief, zählt nicht (nur als „zuletzt“); längste Dauer mit Zeit (ein späterer, längerer Lauf löst sie ab), Summe "
           "für das Mittel; abgeschnittener oder "
           "fremder Text wird übergangen",
           j8["Snapshots"] == {"n": 3, "max": 60.0, "max_ts": T0 + 1700, "letzte": 60.0, "takt": 600, "summe": 104.0}
           and j8["Backup"]["n"] == 0 and j8["Backup"]["letzte"] == 300.0 and j8["Backup"]["max"] == 0.0
           and set(j8) == {"Snapshots", "Backup", "Neu"} and j8["Neu"]["n"] == 0 and j8["Neu"]["letzte"] == 0.5,
           f"{j8['Snapshots']}")
        # ---- R8b (23.117, U296): eine Aufgabe, die Zwischenstände meldet, zählt je Lauf einmal
        m8b = Messung(); m8b.start(T0)
        folge = [dict(LF=(T0 - 50, 300.0), Orders=(T0 + 10, 74.5)),              # liefen vor dem ersten Blick
                 dict(LF=(T0 + 100, 0.0), Orders=(T0 + 10, 74.5)),               # LF beginnt: „läuft: 0/n Konten“
                 dict(LF=(T0 + 160, 60.2), Orders=(T0 + 85, 74.8)),              # Zwischenstand; Orders ohne Pause der nächste Lauf
                 dict(LF=(T0 + 290, 190.4), Orders=(T0 + 160, 74.9)),
                 dict(LF=(T0 + 400, 305.0), Orders=(T0 + 235, 74.9)),            # Abschluss von LF, gemessen ab einem früheren Beginn; Orders gleich lang
                 dict(LF=(T0 + 1300, 0.0), Orders=(T0 + 235, 74.9)),             # zweiter Lauf von LF
                 dict(LF=(T0 + 1420, 120.3), Orders=(T0 + 235, 74.9)),
                 dict(LF=(T0 + 1500, 200.9), Orders=(T0 + 235, 74.9)),
                 dict(LF=(T0 + 1500, 201.4), Orders=(T0 + 235, 74.9))]           # in derselben Sekunde der Abschluss
        for i_, f_ in enumerate(folge):
            m8b.beobachte(T0 + 10 * i_, 1.0 + i_, T0, ST, jobs(**f_))
            m8b.beobachte(T0 + 10 * i_ + 1, 1.5 + i_, T0, ST, jobs(**f_))      # dieselbe Meldung noch einmal gelesen
        j8b = m8b.z["jobs"]
        ok("R8b Aufgaben mit Zwischenständen (U296): Rückt „last“ vor und wächst „dauer“ mit, ist es derselbe Lauf -- er zählt einmal, mit "
           "seiner größten Dauer (auch wenn der Abschluss ab einem früheren Beginn misst oder in derselben Sekunde kommt); ein Lauf ohne "
           "Pause nach dem vorigen und einer mit gleicher Dauer zählen eigens; der Beginn der Zählung steht fest",
           j8b["LF"] == {"n": 2, "max": 305.0, "max_ts": T0 + 400, "letzte": 201.4, "takt": 600, "summe": 506.4}
           and j8b["Orders"] == {"n": 3, "max": 74.9, "max_ts": T0 + 160, "letzte": 74.9, "takt": 600, "summe": 224.6}
           and m8b.z["jobs_seit"] == T0 and m8b.z["jobs_regel"] == JOBS_REGEL == 2 and LAUF_TOLERANZ_S == 2.0,
           f"LF {j8b['LF']} · Orders {j8b['Orders']}")
        # ---- R8c (23.117, U296): Zähler der alten Zählweise werden verworfen, die der neuen bleiben
        alt8 = {"format": FORMAT, "seit": T0 - 5000, "starts": 3, "stunden": {"7": {"n": 4}}, "jobs_seit": T0 - 4000, "jobs_regel": 1,
                "jobs": {"Pool-Fills": {"n": 30, "max": 5421.8, "max_ts": T0 - 100, "letzte": 5421.8, "takt": 43200, "summe": 79569.0}}}
        m8c = Messung(json.loads(json.dumps(alt8)))
        vor8 = (dict(m8c.z["jobs"]), m8c.z["jobs_seit"], m8c.z["seit"], m8c.z["starts"], set(m8c.z["stunden"]))
        m8c.start(T0 + 50); m8c.beobachte(T0 + 60, 1.0, T0 + 55, ST, jobs(Snapshots=(T0 + 40, 2.0)))
        neu8 = json.loads(json.dumps(m8c.z)); neu8["jobs"]["Snapshots"]["n"] = 7
        m8d = Messung(neu8)
        ok("R8c Wechsel der Zählweise (U296): Eine Messdatei ohne die Nummer der neuen Zählweise verliert nur die Zähler der Aufgaben "
           "(Runden, Starts und Beginn der Messung bleiben); gezählt wird neu ab dem ersten Blick danach. Eine Datei der neuen Zählweise "
           "behält ihre Zähler und den Beginn der Zählung",
           vor8 == ({}, None, T0 - 5000, 3, {"7"}) and m8c.z["jobs_seit"] == T0 + 60 and m8c.z["jobs"]["Snapshots"]["n"] == 0
           and m8d.z["jobs"]["Snapshots"]["n"] == 7 and m8d.z["jobs_seit"] == T0 + 60 and m8d.z["jobs_regel"] == 2,
           f"vorher {vor8[0]} seit {vor8[1]}; danach seit {m8c.z['jobs_seit'] - T0} s nach T0; neue Datei behält n = {m8d.z['jobs']['Snapshots']['n']}")
        # ---- R9 Zählwerk und Zusammenfassung
        hist = {10: 98, 11: 1, 50: 1}
        g9 = zusammen({"100": {"n": 60, "hist": {"10": 59, "11": 1}, "ahist": {"11": 59, "12": 1}, "max": 11, "max_ts": 5, "amax": 12.0,
                               "unsicher": 1, "umax": 70, "uahist": {"71": 1}, "mess": 3500.0, "luecken": 1},
                       "101": {"n": 40, "hist": {"10": 39, "50": 1}, "ahist": {"11": 39, "121": 1}, "max": 50, "max_ts": 9, "amax": 121.0,
                               "unsicher": 0, "umax": 0, "uahist": {}, "mess": 3600.0, "luecken": 0}})
        g9b = zusammen({"100": {"n": 3, "hist": {"10": 3}}, "101": {"n": 40, "hist": {"10": 39, "50": 1}, "ahist": {"11": 39, "121": 1},
                                                                    "max": 50, "max_ts": 9, "amax": 121.0}}, 101)
        g9c = zusammen({"7": {"n": 5, "hist": {"12": 2, "13": 1, "300": 1, "301": 1}, "ahist": {"30": 1, "31": 1, "600": 1, "601": 2}}})
        ok("R9 Zusammenfassung über Stunden: Median und 99-%-Wert aus dem Zählwerk (kleinster Wert, bis zu dem der Anteil erreicht ist); "
           "Klassen bis 12 / 20 / 30 / 60 / 120 / 300 s (die Grenze gehört dazu) und darüber; Fristen zählen das Alter von außen, streng größer; unsichere "
           "Abstände daneben; ein Zeitraum nimmt nur Stunden ab seiner Grenze; leere Angaben geben keinen Wert",
           _quantil(hist, 0.5) == 10 and _quantil(hist, 0.98) == 10 and _quantil(hist, 0.99) == 11 and _quantil(hist, 0.995) == 50
           and _quantil(hist, 1.0) == 50 and _quantil({}, 0.5) is None and g9["n"] == 100 and g9["median"] == 10 and g9["p99"] == 11
           and g9["max"] == 50 and g9["max_ts"] == 9 and g9["klassen"] == [99, 0, 0, 1, 0, 0, 0] and g9["amax"] == 121.0
           and g9["fristen"] == {30: 1, 60: 1, 120: 1, 180: 0, 300: 0, 600: 0} and g9["ufristen"] == {30: 1, 60: 1, 120: 0, 180: 0, 300: 0, 600: 0}
           and g9["unsicher"] == 1 and g9["umax"] == 70 and g9["mess"] == 7100.0 and g9["stunden"] == 2 and g9["luecken"] == 1
           and g9c["klassen"] == [2, 1, 0, 0, 0, 1, 1] and g9c["fristen"] == {30: 4, 60: 3, 120: 3, 180: 3, 300: 3, 600: 2}
           and g9b["n"] == 40 and g9b["stunden"] == 1 and zusammen({})["median"] is None and zusammen({})["klassen"] == [0] * 7
           and KLASSEN == (12, 20, 30, 60, 120, 300) and FRISTEN == (30, 60, 120, 180, 300, 600),
           f"Median {g9['median']} s, 99 % {g9['p99']} s, Klassen {g9['klassen']}")
        # ---- R10 echter Faden an einer echten Datenbank (nur lesen)
        db = os.path.join(tmp, "b", "hl_liq.db"); os.makedirs(os.path.dirname(db))
        wc = sqlite3.connect(db)
        wc.execute("PRAGMA journal_mode=WAL")
        wc.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        wc.execute("CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, "
                   "n_stale_dropped INTEGER, age_median INTEGER, age_p90 INTEGER, backlog INTEGER, uptime INTEGER)")
        wc.execute("INSERT INTO meta VALUES ('started', ?)", (str(int(time.time()) - 500),))
        wc.commit()
        halt_schreiber = threading.Event()

        def schreiber():                                                    # steht für den Recorder: ein Lebenszeichen je Sekunde
            c = sqlite3.connect(db)
            while not halt_schreiber.is_set():
                c.execute("INSERT OR REPLACE INTO meta VALUES ('recorder_alive', ?)", (str(int(time.time())),))
                c.execute("INSERT OR REPLACE INTO meta VALUES ('jobs', ?)",
                          (json.dumps({"Snapshots": {"last": int(time.time()), "takt": 600, "dauer": 1.5, "ok": True}}),))
                c.commit()
                halt_schreiber.wait(1.0)
            c.close()
        ts_ = threading.Thread(target=schreiber, daemon=True); ts_.start()
        halt = threading.Event()
        pf10 = datei_pfad(db)
        faden = starten(db, halt, takt=0.1, speichern_erst=0.5, speichern_s=60.0)
        time.sleep(4.6)
        lebt = faden.is_alive()
        zwischen = os.path.exists(pf10)
        try:
            with open(pf10, encoding="utf-8") as fh:
                gelesen_vor = json.load(fh)["gelesen"]                     # Stand der ersten Ablage (danach 60 s nichts)
        except (OSError, ValueError):
            gelesen_vor = None
        halt.set(); faden.join(3.0); halt_schreiber.set(); ts_.join(3.0)
        with open(pf10, encoding="utf-8") as fh:
            Z10 = json.load(fh)
        g10 = zusammen(Z10["stunden"])
        nur_lesen = False
        c_ro = _verbinden(db)
        try:
            c_ro.execute("INSERT INTO meta VALUES ('x', 'y')")
        except sqlite3.OperationalError:
            nur_lesen = True
        finally:
            c_ro.close()
        ok("R10 Der echte Faden an einer echten Datenbank: liest zehnmal je Sekunde, sieht jedes Lebenszeichen eines nachgestellten "
           "Recorders (Abstand 1 s), legt nach einer halben Sekunde zum ersten Mal ab, endet auf das Haltezeichen und legt dabei noch "
           "einmal ab (die Datei enthält danach alles bis zum Halt); seine Verbindung kann nicht schreiben; der Name des Fadens ist „rtakt“, er ist ein Hintergrund-Faden",
           lebt and zwischen and not faden.is_alive() and faden.name == "rtakt" and faden.daemon and g10["n"] >= 2
           and set(g10["hist"]) <= {1, 2, 3, 4} and g10["max"] <= 4 and Z10["fehler"]["n"] == 0 and Z10["gelesen"] >= 12 and Z10["starts"] == 1
           and gelesen_vor is not None and Z10["gelesen"] > gelesen_vor
           and nur_lesen and os.path.dirname(pf10) == os.path.dirname(db) and os.path.basename(pf10) == "recorder_takt.json"
           and Z10["jobs"].get("Snapshots", {}).get("n", 0) >= 1 and not os.path.exists(pf10 + ".tmp") and g10["mess"] > 1.5,
           f"{Z10['gelesen']}-mal gelesen, {g10['n']} Runden, Zählwerk {g10['hist']}, Aufgaben {Z10['jobs'].get('Snapshots', {}).get('n')}")
        # ---- R11 ohne Datenbank, ohne Tabelle: der Faden läuft weiter
        def warte(bed, frist=15.0):
            """Bis die Bedingung gilt (oder die Frist um ist) -- die Probe hängt so nicht an der Geschwindigkeit des Rechners."""
            ende = time.monotonic() + frist
            while time.monotonic() < ende:
                try:
                    if bed():
                        return True
                except (OSError, ValueError, KeyError):
                    pass
                time.sleep(0.05)
            return False

        def datei11():
            with open(datei_pfad(db11), encoding="utf-8") as fh:
                return json.load(fh)
        db11 = os.path.join(tmp, "c", "fehlt.db"); os.makedirs(os.path.dirname(db11))
        halt11 = threading.Event()
        f11 = starten(db11, halt11, takt=0.05, speichern_erst=0.2, speichern_s=0.2, wieder_s=0.1)
        w1 = warte(lambda: datei11()["fehler"]["n"] >= 1)                  # die Datenbank fehlt: Fehler gezählt und abgelegt
        g_a = datei11()["fehler"]["n"] if w1 else 0
        ohne_db = os.path.exists(db11)
        c11 = sqlite3.connect(db11); c11.execute("CREATE TABLE anderes (x)"); c11.commit()
        w2 = warte(lambda: "no such table" in datei11()["fehler"]["letzter"])   # die Tabelle fehlt: weiter gezählt, weiter abgelegt
        g_b = datei11() if w2 else {"fehler": {"n": 0}}
        c11.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        c11.execute("INSERT INTO meta VALUES ('recorder_alive', '1795000003')"); c11.commit()
        w3 = warte(lambda: datei11()["gelesen"] >= 1)                      # das erste Lebenszeichen ist gelesen
        c11.execute("UPDATE meta SET v='1795000013' WHERE k='recorder_alive'"); c11.commit()
        w4 = warte(lambda: zusammen(datei11()["stunden"])["n"] == 1)       # das zweite: eine Runde von 10 s
        lebt11 = f11.is_alive()
        halt11.set(); f11.join(5.0); c11.close()
        Z11 = datei11()
        ok("R11 Fehlt die Datenbank oder die Tabelle, bricht der Faden nicht ab und legt keine Datenbank an: Er zählt die Fehler (mit dem "
           "letzten im Wortlaut), versucht es weiter, legt weiter laufend ab und misst, sobald das Lebenszeichen da ist",
           w1 and w2 and w3 and w4 and not ohne_db and lebt11 and not f11.is_alive() and Z11["fehler"]["n"] >= 2
           and "no such table" in Z11["fehler"]["letzter"] and g_a >= 1 and g_b["fehler"]["n"] > g_a
           and zusammen(Z11["stunden"])["n"] == 1 and zusammen(Z11["stunden"])["hist"] == {10: 1},
           f"{Z11['fehler']['n']} Fehler (zuletzt {Z11['fehler']['letzter'][:50]}), danach {zusammen(Z11['stunden'])['n']} Runde")
        # ---- R12 Bericht
        jetzt = T0 + 1300
        db12 = os.path.join(tmp, "d", "hl_liq.db"); os.makedirs(os.path.dirname(db12))
        c12 = sqlite3.connect(db12)
        c12.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        c12.execute("CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, "
                    "n_stale_dropped INTEGER, age_median INTEGER, age_p90 INTEGER, backlog INTEGER, uptime INTEGER)")
        c12.executemany("INSERT INTO meta VALUES (?,?)", [
            ("recorder_alive", str(jetzt - 4)), ("started", str(T0 - 90000)),
            ("jobs", json.dumps({"Snapshots": {"last": jetzt - 300, "next": jetzt + 300, "takt": 600, "dauer": 3.4, "ok": True},
                                 "Backup": {"last": jetzt - 30000, "takt": 86400, "dauer": 412.0, "ok": False},
                                 "Adress-Poller": {"last": jetzt - 2, "takt": 5, "ok": True}}))])
        t_ = T0 - 20000; zeilen = []; up = 5000
        for d_ in [603] * 10 + [650] + [604] * 5 + [1810] + [603] * 3 + [700] + [602] * 4:
            neu_ = d_ == 700
            t_ += d_; up = 640 if neu_ else up + d_
            zeilen.append((t_, 1, 1, 1, 0, 1, 1, 0, up))
        c12.executemany("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", [(T0 - 20000, 1, 1, 1, 0, 1, 1, 0, 5000)] + zeilen)
        c12.execute("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", (T0 - 9 * 86400, 1, 1, 1, 0, 1, 1, 0, 100))   # älter als 7 Tage
        c12.commit(); c12.close()
        pf12 = datei_pfad(db12)
        mb = Messung(); mb.start(T0)
        _spiel(mb, T0, 470, z2, ST, jobs(Snapshots=(T0 - 100, 3.2)))
        _spiel(mb, T0 + 470, 20, [(T0 + 470, T0 + 453), (T0 + 475.4, T0 + 475)], ST, jobs(Snapshots=(T0 + 472, 47.5)), pause={2: 9.0})
        mb.z["neustarts"].append({"ts": T0 - 3000, "pause": 52, "anlauf": 25, "vorher": T0 - 3030, "unsicher": False})
        mb.fehler(T0 + 5, sqlite3.OperationalError("database is locked"))
        mb.speichern(pf12, jetzt - 120)
        t12 = bericht(db12, jetzt)
        S12 = schnappschuesse(sqlite3.connect(db12), jetzt, 600)
        ok("R12 Schnappschuss-Runden aus snapshot_meta: Abstand minus Pause ist die Zeit über die Pause hinaus (Median 3 s, längste 50 s "
           "mit Uhrzeit); ein Abstand über das Doppelte der Pause und einer über einen Neustart hinweg (uptime kleiner als der Abstand) "
           "sind Lücken, keine Runden; Zeilen älter als 7 Tage zählen nicht",
           S12["n"] == 23 and S12["zeilen"] == 26 and S12["median"] == 3 and S12["max"] == 50 and S12["min"] == 2 and S12["p90"] == 4
           and len(S12["luecken"]) == 2 and sorted(d_ for _t, d_ in S12["luecken"]) == [700, 1810] and S12["ueber"] == {10: 1, 30: 1, 60: 0, 120: 0}
           and S12["max_ts"] == T0 - 20000 + 603 * 10 + 650,
           f"{S12['n']} Runden, Median {S12['median']} s, längste {S12['max']} s, Lücken {[d_ for _t, d_ in S12['luecken']]}")
        # ---- R12c (23.117, U296): der Bericht nennt den Beginn der Zählung und die Zählweise
        z6 = t12[t12.index("\n6 AUFGABEN"): t12.index("\n7 LESART")]
        ok("R12c Bericht, Abschnitt 6 (U296): nennt, seit wann die Aufgaben gezählt sind und dass ein Lauf mit Zwischenständen einmal zählt; "
           "die Lesart sagt, dass ein laufender Lauf mit seiner bisherigen Dauer eingeht",
           f"\n  gezählt seit {_uhr(T0, True)} -- ein Lauf zählt einmal, auch wenn der Recorder Zwischenstände meldet (seit 23.117; " in z6
           and "Snapshots" in z6 and "1 Lauf · Mittel 47,5 s · längste 47,5 s" in z6
           and "  - Meldet eine Aufgabe Zwischenstände (Leaderboard-Fills, Pool-Fills), zählt ihr Lauf einmal;" in t12,
           z6.strip().splitlines()[1][:110])
        # ---- R12b (23.116, U294): der Schnappschuss beim Beenden ist keine Runde
        db12b = os.path.join(tmp, "d12b", "hl_liq.db"); os.makedirs(os.path.dirname(db12b))
        c12b = sqlite3.connect(db12b)
        c12b.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        c12b.execute("CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, "
                     "n_orders INTEGER, n_heat INTEGER, n_cohort INTEGER, n_fail INTEGER, uptime INTEGER)")
        c12b.executemany("INSERT INTO meta VALUES (?,?)", [("recorder_alive", str(jetzt - 4)), ("started", str(T0 - 90000))])
        # Abstand, neuer Prozess?: fünf Runden; 3 s danach der Schnappschuss beim Beenden; 694 s später der erste des neuen Prozesses
        # (Lücke); eine Runde genau in der Pause (600 s = 0 s darüber); ein kurzer Abstand OHNE Neustart danach; drei Runden; zuletzt
        # ein kurzer Abstand ohne Nachfolger (der Recorder wurde eben beendet)
        folge = [(603, 0)] * 5 + [(3, 0), (694, 1), (600, 0), (200, 0), (604, 0), (603, 0), (602, 0), (40, 0)]
        t_ = T0 - 12000; up = 7000; zeilen_b = [(t_, 1, 1, 1, 0, 1, 1, 0, up)]; marken = {}
        for i_, (d_, neu_) in enumerate(folge):
            t_ += d_; up = 600 if neu_ else up + d_
            zeilen_b.append((t_, 1, 1, 1, 0, 1, 1, 0, up)); marken[i_] = t_
        c12b.executemany("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", zeilen_b)
        c12b.commit(); c12b.close()
        cb_ = sqlite3.connect(db12b); S12b = schnappschuesse(cb_, jetzt, 600); cb_.close()
        t12b = bericht(db12b, jetzt)
        z5 = t12b[t12b.index("\n5 SCHNAPPSCHUSS-RUNDEN"): t12b.index("\n6 AUFGABEN")]
        ok("R12b Schnappschuss beim Beenden (U294): Ein Abstand unter der Pause ist keine Runde -- vor einem Neustart oder als letzte Zeile "
           "ist es der Schnappschuss, den der Recorder beim Beenden schreibt (2), ohne Neustart danach ein eigener Fall (1); die kürzeste "
           "Runde ist nie negativ; ein Abstand genau in der Pause ist eine Runde mit 0 s; der Bericht nennt beides mit Zahl, Uhrzeit und "
           "Abstand",
           S12b["n"] == 9 and S12b["min"] == 0 and S12b["max"] == 4 and S12b["median"] == 3
           and S12b["abschluss"] == [(marken[5], 3), (marken[12], 40)] and S12b["verkuerzt"] == [(marken[8], 200)]
           and S12b["luecken"] == [(marken[6], 694)] and S12b["zeilen"] == 14
           and "kürzeste 0 s" in z5 and "kürzeste -" not in z5 and "kürzeste −" not in z5
           and f"Nicht als Runde gezählt: 2 Schnappschüsse beim Beenden des Recorders -- zuletzt {_uhr(marken[12], True)}, 40 s nach dem vorigen" in z5
           and f"Nicht als Runde gezählt: 1 Abstand unter der Pause OHNE Neustart danach -- zuletzt {_uhr(marken[8], True)}, 3,3 min nach dem vorigen" in z5
           and "Nicht als Runde gezählt" not in t12 and S12["abschluss"] == [] and S12["verkuerzt"] == [],
           f"{S12b['n']} Runden, kürzeste {S12b['min']} s; beim Beenden {[d_ for _t, d_ in S12b['abschluss']]}, ohne Neustart "
           f"{[d_ for _t, d_ in S12b['verkuerzt']]}, Lücken {[d_ for _t, d_ in S12b['luecken']]}")
        ok("R13 Bericht (Debug 157): Kopf mit Nummer und Modul; Messung seit wann, zuletzt abgelegt, beobachtete Zeit, Runden, unsichere "
           "Abstände, Lesefehler im Wortlaut; Lebenszeichen jetzt; Verteilung je Zeitraum mit Klassen; die längsten Abstände (unsichere "
           "markiert); Fristen; Neustarts; Schnappschüsse; Aufgaben mit letzter und längster Dauer (auch „nicht ok“); Lesart -- ohne "
           "leere Werte",
           t12.startswith(f"★ Recorder: Takt der Runden (U287, Messung; Debug 157) · Modul {VERSION_MODUL} · ")
           and "Am Recorder ändert sich nichts." in t12 and all(f"\n{i} " in t12 for i in range(1, 8))
           and "läuft seit " + _uhr(T0) in t12 and "zuletzt abgelegt vor 2,0 min" in t12 and "ÄLTER ALS" not in t12
           and "41 Runden" in t12 and "unsicher: 1 Abstand, der längste 22 s" in t12 and "in 1 Stunde mit Werten" in t12
           and "Lesefehler des Messfadens: 1 (zuletzt " in t12 and "OperationalError: database is locked" in t12
           and "Lebenszeichen jetzt: vor 4 s" in t12 and "Recorder läuft seit " + _uhr(T0 - 90000) in t12
           and "alles                  41     10 s    50 s      50 s   40 · 0 · 0 · 1 · 0 · 0 · 0" in t12
           and f"    {_uhr(T0 + 243, True)} · 50 s · 51,0 s\n" in t12 and " · 22 s · 29,0 s · unsicher\n" in t12
           and "über 30 s: 1-mal · über 60 s: 0-mal" in t12 and "größtes Alter: 51,0 s" in t12
           and "4 NEUSTARTS DES RECORDERS IN DER BEOBACHTETEN ZEIT (1;" in t12 and "Pause zwischen den Lebenszeichen 52 s" in t12
           and "ersten Lebenszeichen 25 s" in t12 and "23 Runden von " in t12 and "Median 3 s · 90 % bis 4 s · längste 50 s" in t12
           and "Lücken (Abstand über 1200 s oder Neustart dazwischen): 2" in t12
           and "Snapshots                          Takt  10,0 min · zuletzt     3,4 s · 1 Lauf · Mittel 47,5 s · längste 47,5 s" in t12
           and "Backup                             Takt    24,0 h · zuletzt   412,0 s · in der beobachteten Zeit kein Lauf mit Dauer · zuletzt NICHT ok" in t12
           and "Adress-Poller" in t12 and not any(w_ in t12 for w_ in ("None", "nan", "Traceback", "inf ")),
           t12.split("\n")[5][:120])
        # ---- R14 Bericht ohne Messdatei, ohne Datenbank, mit alter Datei
        t14a = bericht(os.path.join(tmp, "e", "hl_liq.db"), jetzt)
        os.remove(pf12)
        t14b = bericht(db12, jetzt)
        mb.speichern(pf12, jetzt - 2000)
        t14c = bericht(db12, jetzt)
        with open(pf12, "w", encoding="utf-8") as fh:
            fh.write("{kaputt")
        t14d = bericht(db12, jetzt)
        me = Messung(); me.start(T0)
        _spiel(me, T0, 60, z1[:6], ST)                                     # eine frische Messung ohne unsicheren Abstand
        me.speichern(pf12, jetzt - 120)
        t14e = bericht(db12, jetzt)
        ok("R14 Bericht in Randfällen: ohne Messdatei sagt er, wann die erste kommt und wonach zu sehen ist -- die Schnappschüsse aus der "
           "Datenbank zeigt er trotzdem; ohne Datenbank sagt er das; eine Messdatei älter als 15 Minuten wird als Stillstand des "
           "Messfadens gemeldet; eine unlesbare Datei ist kein Absturz; ohne unsicheren Abstand steht „kein Abstand“ statt des Satzes "
           "zur eigenen Pause",
           "Noch keine Messdatei" in t14a and "Hauptdatenbank nicht lesbar" in t14a and "5 SCHNAPPSCHUSS-RUNDEN" in t14a and "nicht lesbar (" in t14a
           and "Noch keine Messdatei" in t14b and "Läuft der Dienst?" in t14b and "23 Runden von " in t14b and "\n2 SCHREIBRUNDEN" not in t14b
           and "Snapshots" in t14b and "ÄLTER ALS 15 MINUTEN" in t14c and "hl-watchdog" in t14c
           and "Noch keine Messdatei (die vorhandene ist nicht lesbar)" in t14d
           and "  unsicher: kein Abstand (unsicher wäre einer, bei dem der Messfaden selbst über 5 s pausierte)\n" in t14e
           and "pausierte dabei" not in t14e and "5 Runden" in t14e and "pausierte dabei selbst über 5 s" in t12,
           t14b.split("\n")[5][:100])
        # ---- R15 nur lesen, still, Nummer
        with open(os.path.abspath(__file__), encoding="utf-8") as fh:
            rumpf = fh.read().split("\ndef _spiel(", 1)[0]
        ok("R15 Der Teil vor dem Selbsttest schreibt nichts in eine Datenbank (keine schreibenden SQL-Befehle, Verbindung nur mit "
           "mode=ro), gibt nichts aus (die Ausgabe des Wächter-Dienstes liest Debug 20) und startet keinen Prozess; die Datei liegt "
           "neben der Datenbank; Nummer 157",
           bool(rumpf) and not any(w_ in rumpf for w_ in ("INSERT", "UPDATE ", "DELETE", "CREATE ", "DROP ", "print(", "subprocess", "os.system"))
           and rumpf.count("mode=ro") == 2 and rumpf.count("sqlite3.connect(") == 1 and DEBUG_NR == 157 and DATEI == "recorder_takt.json"
           and TAKT_S == 1.0 and LUECKE_S == 5.0 and SPEICHERN_S == 300 and STUNDEN_MAX == 336,
           f"{len(rumpf)} Zeichen vor dem Selbsttest")
        # ---- R16 Vertrag mit dem Paket
        hier = os.path.dirname(os.path.abspath(__file__))
        quellen = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py", "hl_watchdog.py"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as fh:
                    quellen[n_] = fh.read()
            except OSError:
                quellen[n_] = ""
        ok("R16 Vertrag mit dem Paket: hl_rtakt.py in der Prüfsumme (version.py), in Sicherung und Wiederherstellung (update.py), im "
           "Übersetzungs- und im Prüfschritt des Installers; Debug-Lauf „recorder_takt“ im Dashboard mit --bericht und der Datenbank; der "
           "Wächter-Dienst startet den Messfaden; im Berichtsplan nach dem Einspielen von 23.115",
           '"hl_rtakt.py"' in quellen["version.py"] and '"hl_rtakt.py"' in quellen["update.py"]
           and quellen["install.py"].count('str(ROOT / "hl_rtakt.py")') == 2 and '[py, str(ROOT / "hl_rtakt.py"), "--selbsttest"]' in quellen["install.py"]
           and '[py, "hl_rtakt.py", "--bericht", "--db", db]' in quellen["hl_viz.py"] and '"recorder_takt": (' in quellen["hl_viz.py"]
           and '"laeufe": ["recorder_takt", "system_ausfall"]' in quellen["hl_viz.py"]
           and "return hl_rtakt.starten(db, stop)" in quellen["hl_watchdog.py"] and "    messfaden_starten(args.db)" in quellen["hl_watchdog.py"],
           ", ".join(n_ for n_, q_ in quellen.items() if "hl_rtakt" in q_) or "in keiner Liste")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-900:].replace("\n", " | "))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--bericht", action="store_true", help="Stand der Messung als Text (Debug 157)")
    p.add_argument("--db", default="hl_liq.db", help="Hauptdatenbank; die Messdatei liegt daneben")
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz und ohne den echten Recorder")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.bericht:
        try:
            sys.stdout.write(bericht(a.db))
        except Exception as e:                                               # der Bericht soll sagen, was geschah
            import traceback
            sys.stdout.write(f"★ Recorder: Takt der Runden (Debug {DEBUG_NR}) · Modul {VERSION_MODUL}\nFEHLER im Lauf: {type(e).__name__}: {e}\n"
                             + traceback.format_exc()[-1500:])
            sys.exit(1)
        return
    p.print_help()


if __name__ == "__main__":
    main()
