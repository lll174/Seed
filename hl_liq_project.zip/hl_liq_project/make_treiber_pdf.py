#!/usr/bin/env python3
"""Treiber-Dokumentation als PDF (Stand 15.09.2026, Codebasis hl_forecast.py / hl_indikatoren.py / hl_score.py)."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont("DV", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DVB", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DVI", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("DV", normal="DV", bold="DVB", italic="DVI", boldItalic="DVB")

INK = colors.HexColor("#1b1f24"); MUTED = colors.HexColor("#57606a"); LINE = colors.HexColor("#d0d7de"); BG = colors.HexColor("#f6f8fa")
S = {
    "h1": ParagraphStyle("h1", fontName="DVB", fontSize=17, leading=22, spaceAfter=8, textColor=INK),
    "h2": ParagraphStyle("h2", fontName="DVB", fontSize=13, leading=17, spaceBefore=12, spaceAfter=5, textColor=INK),
    "h3": ParagraphStyle("h3", fontName="DVB", fontSize=10.5, leading=14, spaceBefore=9, spaceAfter=3, textColor=INK),
    "p": ParagraphStyle("p", fontName="DV", fontSize=9.2, leading=13, spaceAfter=4, textColor=INK, alignment=TA_LEFT),
    "small": ParagraphStyle("small", fontName="DV", fontSize=8, leading=11, textColor=MUTED),
    "f": ParagraphStyle("f", fontName="DV", fontSize=9, leading=13, leftIndent=10, backColor=BG, borderPadding=(3, 4, 3, 4), spaceBefore=2, spaceAfter=5),
    "cell": ParagraphStyle("cell", fontName="DV", fontSize=8.2, leading=10.5, textColor=INK),
    "cellb": ParagraphStyle("cellb", fontName="DVB", fontSize=8.2, leading=10.5, textColor=INK),
}
story = []
P = lambda t, st="p": story.append(Paragraph(t, S[st]))
F = lambda t: story.append(Paragraph(t, S["f"]))


def treiber(name, prior, quelle, berechnung, ereignisse, hinweis=None):
    """Ein Treiber-Abschnitt: Quelle, Berechnung (Formel), Ereignisse, Hinweis."""
    teile = [Paragraph(f"{name} <font color='#57606a' size='8'>— Prior {prior}</font>", S["h3"]),
             Paragraph(f"<b>Eingangsdaten:</b> {quelle}", S["p"])]
    for b in berechnung:
        teile.append(Paragraph(b, S["f"]))
    teile.append(Paragraph(f"<b>Was ihn bewegt:</b> {ereignisse}", S["p"]))
    if hinweis:
        teile.append(Paragraph(f"<font color='#57606a'>{hinweis}</font>", S["p"]))
    story.append(KeepTogether(teile))


def tabelle(kopf, zeilen, breiten):
    data = [[Paragraph(k, S["cellb"]) for k in kopf]] + [[Paragraph(str(c), S["cell"]) for c in z] for z in zeilen]
    t = Table(data, colWidths=breiten, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), BG), ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINE),
                           ("LINEBELOW", (0, 1), (-1, -1), 0.25, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4), ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    story.append(t); story.append(Spacer(1, 6))


# =====================================================================================
P("Hyperliquid-Liquidationscluster — Die Treiber der Prognose", "h1")
P("Erklärung jedes Treibers: Eingangsdaten, Berechnung, auslösende Ereignisse. Stand 15. September 2026, "
  "Codebasis <i>hl_forecast.py</i>, <i>hl_indikatoren.py</i>, <i>hl_score.py</i>. Alle Formeln sind dem Code entnommen; wo eine "
  "Zahl ein Startwert (Prior) ist, steht das dabei — die Kalibrierung ersetzt sie durch gemessene Werte.", "small")
story.append(Spacer(1, 8))

# ---- 1. Wie eine Prognose entsteht ---------------------------------------------------
P("1. Wie eine Prognose entsteht", "h2")
P("Alle 15 Minuten berechnet das Dashboard je Coin eine Prognose. Jeder <b>Treiber</b> liefert einen <b>Score</b> "
  "zwischen −1 (abwärts) und +1 (aufwärts) und trägt ein <b>Gewicht</b>. Vor dem Lernen ist das Gewicht der Prior aus der "
  "Tabelle in Abschnitt 13; sobald genug unabhängige Fälle vorliegen, ersetzt die Kalibrierung ihn je Horizont (4 h und 24 h) "
  "durch einen gelernten Wert. Aus Scores und Gewichten entstehen drei Größen:")
F("Bias (Richtungsdruck) = Σ<sub>i</sub> Score<sub>i</sub> · Gewicht<sub>i</sub> / Σ<sub>i</sub> Gewicht<sub>i</sub>  ∈ [−1, 1], getrennt für die 4-h- und die 24-h-Spur")
F("P(aufwärts) = σ( β · Σ<sub>i</sub> Score<sub>i</sub> · Gewicht<sub>i</sub> / Σ Priors )  mit σ(z) = 1/(1+e<super>−z</super>); β ist ein gelernter Maßstab (Start 1,0, erlaubt 0,2–4,0)")
F("Einigkeit = Anteil des Gewichts, dessen Score in Richtung des Bias zeigt (dient der Anzeige und der Konfluenz)")
P("Der Bias steuert das <b>Pfadmodell</b> (Abschnitt 12): Bei |Bias| > 0,12 wird ein Ziel gewählt — das nächste große "
  "Liquidationscluster in Bias-Richtung — und die Reichweite aus der gemessenen Berührstatistik bestimmt; sonst läuft der Pfad "
  "auf dem Sigma-Band. Das <b>Regime</b> (Abschnitt 10) weitet das Band, verschiebt aber nichts. Die Prognose speichert Scores, "
  "Gewichte, P(aufwärts) und den Pfad; nach 4 h und 24 h wird sie gegen den echten Kurs bewertet.")

# ---- 2. Kalibrierung -----------------------------------------------------------------
P("2. Kalibrierung — wie aus Priors gemessene Gewichte werden", "h2")
P("Jede Prognose wird nach h Stunden zu einem Fall: Richtung des echten Kurses (aufwärts/abwärts) gegen die Scores der "
  "Treiber zu diesem Zeitpunkt. Benachbarte 15-Minuten-Prognosen teilen sich fast die ganze Zukunft, deshalb zählt nicht die "
  "Fensterzahl, sondern <b>n_eff</b> = Zahl getrennter h-Stunden-Blöcke. Gelernt wird erst ab n_eff 40 je Horizont; ein "
  "einzelner Treiber wird erst freigegeben, wenn er in n_eff 50 (4 h) bzw. 30 (24 h) Blöcken aktiv war.")
F("Modell: p<sub>t</sub> = σ( β · Σ<sub>i</sub> w<sub>i</sub> x<sub>i,t</sub> / S ),  S = Σ Priors")
F("Verlust: logistischer Fehler (p<sub>t</sub> − y<sub>t</sub>) plus Regularisierung λ · Σ (w<sub>i</sub> − Prior<sub>i</sub>)<super>2</super>,  λ = 4 / n_eff")
F("Update: w<sub>i</sub> ← clip( w<sub>i</sub> − lr · ∂Verlust/∂w<sub>i</sub>, 0, 2 · Prior<sub>i</sub> ),  β ← clip(β − lr<sub>β</sub> · ∂Verlust/∂β, 0,2, 4,0); bis 300 Runden oder Schrittweite < 10<super>−4</super>")
P("Lesart: Bei wenigen Fällen zieht λ die Gewichte zum Prior (nichts wird aus Zufall gelernt); mit wachsendem n_eff darf sich "
  "ein Gewicht bis auf null (Treiber stumm) oder das Doppelte des Priors bewegen. Ein Treiber mit Trefferquote nahe 50 % läuft "
  "gegen null — das ist das <b>Killkriterium</b>. Je Treiber werden Trefferquote, Wilson-Intervall und n_eff ausgewiesen; der "
  "<b>Nulltest</b> (reines Rauschen) muss Gewichte am Prior, β nahe 1 und Quote 50 % ergeben.")

# ---- 3. Technische Treiber -----------------------------------------------------------
P("3. Regime und Drift (technische Treiber)", "h2")
P("Quelle: Stundenkerzen der letzten 7 Tage (Hyperliquid <i>bars</i>), Tageskerzen für die gleitenden Durchschnitte (Binance <i>daily_bars</i>, sonst HL).", "small")
treiber("MA 200 Tage", "0,8", "Tagesschlusskurse, gleitender Durchschnitt über 200 Tage; p<sub>0</sub> = aktueller Kurs.",
        ["d = p<sub>0</sub> / MA200 − 1;  Score = clip(d / 0,10, −1, 1) · 0,6"],
        "Jede Kursbewegung relativ zum Jahresmittel: 10 % über dem MA sättigt bei +0,6, 10 % darunter bei −0,6. Ein Trendfolge-Treiber — kein Ereignis, sondern Lage.")
treiber("MA 50 Wochen", "0,6", "Wochenschlusskurse, Durchschnitt über 50 Wochen.",
        ["d = p<sub>0</sub> / MA50W − 1;  Score = clip(d / 0,10, −1, 1) · 0,5"],
        "Wie MA 200, auf der Wochenskala. Beide zusammen beschreiben das langfristige Regime.")
treiber("60-min-Trend", "0,5", "Stundenkerzen: Rendite der letzten 60 Minuten (trend_60m).",
        ["Score = clip( r<sub>60min</sub> / 0,01, −1, 1 ) · 0,5"],
        "Ein Prozent Bewegung in einer Stunde sättigt. Reagiert auf jede Stunde mit deutlicher Richtung; Kurzfrist-Momentum.")
treiber("RSI 14 (1 h)", "0,5", "Relative-Stärke-Index über 14 Stundenkerzen.",
        ["Score = clip( (50 − RSI) / 30, −1, 1 ) · 0,5   (Mean Reversion: überkauft drückt, überverkauft stützt)"],
        "RSI 80 → −0,5; RSI 20 → +0,5. Wirkt entgegen dem 60-min-Trend — die Kalibrierung entscheidet, welcher trägt.")
treiber("7-Tage-Drift", "0,4", "Stundenkerzen der letzten 168 h; σ = realisierte Volatilität je Stunde.",
        ["drift = ln( C<sub>jetzt</sub> / C<sub>−168h</sub> ) / 168  (je Stunde);  Score = clip( drift / (0,3 · σ), −1, 1 ) · 0,4"],
        "Eine Wochendrift, die 30 % der Stundenvolatilität erreicht, sättigt. Gedämpfter Trend, an der Volatilität normiert.")

# ---- 4. Positionierung der Konten ----------------------------------------------------
P("4. Positionierung und Fluss der Konten (Hyperliquid)", "h2")
P("Hier liegt der Kern des Projekts: Auf Hyperliquid ist jedes Konto lesbar. Der Recorder fragt ~140.000 Adressen nach Positionen "
  "ab, verfolgt die Top-Konten des Leaderboards alle 2 Minuten und empfängt jeden Trade der sechs Coins per WebSocket "
  "(Fills in Echtzeit). Konten werden klassifiziert: <b>direktional</b> (eine Seite je Coin, echter Hebel), <b>Hedge</b> (viele "
  "Coins, eine Seite, wenig Hebel), <b>Market Maker</b>, <b>gemischt</b>. Nur direktionale Konten tragen eine Richtung.", "small")
treiber("Direktionale Wale", "1,2", "Offene Positionen aller Wale (≥ 20 Mio Positionswert) <b>in diesem Coin</b> aus dem Poller (whale_positions); Klasse je Coin (eine Seite; Hedge- und Market-Maker-Konten ausgeschlossen). Bis 15.09. fehlte der Coin-Filter — der Treiber summierte alle sechs Coins (gefunden mit check_treiber).",
        ["Score = ( USD<sub>long</sub> − USD<sub>short</sub> ) / ( USD<sub>long</sub> + USD<sub>short</sub> )"],
        "Jede Eröffnung, Aufstockung, Reduzierung oder Schließung einer Wal-Position im Coin. Der höchste Prior des Systems: die Ausrichtung der großen direktionalen Konten.")
treiber("Wal-Flow 30 min", "1,3", "Positionsänderungen der direktionalen Wale in den letzten 30 min (Rückfall 60 min), Käufe und Verkäufe in USD, Zahl der Konten; Z-Wert gegen die eigene Historie; Ereignis-Signal.",
        ["Bedingung: Brutto ≥ 150.000 USD und ≥ 2 Konten",
         "Score = ( Netto / Brutto ) · clip( |Z| / 2,5, 0,4, 1,0 ) · (1,5 bei Ereignis-Signal, sonst 1,0)"],
        "Ein Schub von Käufen oder Verkäufen mehrerer Wale binnen einer halben Stunde. Das <b>Ereignis-Signal</b> (Abschnitt 11) hebt den Score um 50 %.")
treiber("Leaderboard-Flow 60 min", "1,0", "Positionsänderungen der direktionalen Top-Konten des Leaderboards (Stände alle 2 min → Ereignisse in lb_events), 60 min (Rückfall 3 h).",
        ["Bedingung: Brutto ≥ 75.000 USD und ≥ 2 Konten",
         "Score = ( Netto / Brutto ) · clip( |Z| / 2,5, 0,4, 1,0 ) · (1,5 bei Ereignis-Signal)"],
        "Wie der Wal-Flow, für die Rangliste der profitabelsten Konten statt der größten.")
treiber("Smart Money (direktional)", "1,0", "Aktuelle Positionen der Top-50 des Leaderboards im Coin, nur direktionale Konten, Netto je Konto (lb_positions).",
        ["Netto<sub>k</sub> = Σ Positionswert · (+1 long / −1 short) je Konto;  UL = Σ Netto > 0,  US = Σ |Netto < 0|",
         "Bedingung: ≥ 3 Konten;  Score = ( UL − US ) / max( UL + US, 1 )"],
        "Jede Positionsänderung eines profitablen direktionalen Kontos im Coin. Ausrichtung statt Fluss — wie „Direktionale Wale“, aber nach Profitabilität statt Größe ausgewählt.")
treiber("Käufe/Verkäufe 24 h (direktional)", "1,0", "Fills der direktionalen Top-Konten in den letzten 24 h (lb_fills, Perp und Spot), Kaufseite aus dem Feld buy.",
        ["Bedingung: Brutto ≥ 250.000 USD und ≥ 2 Konten;  Score = ( Kauf − Verkauf ) / ( Kauf + Verkauf )"],
        "Jeder Fill eines direktionalen Top-Kontos — seit dem Trade-Stream in Echtzeit, ergänzt um closedPnl/fee/dir per REST-Nachtrag.")
treiber("Top-20-Trend 24 h", "0,6", "Netto-Positionierung der Top 20 (lb_trend, stündlich): heute gegen vor 24 h.",
        ["Δ = ( Netto<sub>jetzt</sub> − Netto<sub>−24h</sub> ) / Brutto<sub>jetzt</sub>;  Score = clip( Δ / 0,5, −1, 1 ) · 0,6"],
        "Eine Verschiebung der Ausrichtung um die Hälfte des Bruttowerts binnen eines Tages sättigt. Trägheit der Großen.")
treiber("Smart-Flow 4 h", "1,0", "Positionsschritte aller Konten in den letzten 4 h (Wale + Leaderboard, entdoppelt), gewichtet mit dem Konto-Score S ∈ [0,1] aus hl_score (nur Klasse ≥ 0,6 und S > 0).",
        ["Score = Σ<sub>k</sub> S<sub>k</sub> · Richtung<sub>k</sub> · √Notional<sub>k</sub> / Σ<sub>k</sub> S<sub>k</sub> · √Notional<sub>k</sub>   (Wurzel: kein Einzelkonto ist das Signal)",
         "Bedingung: ≥ 3 bewertete Konten, Brutto ≥ 500.000 USD"],
        "Jeder Positionsschritt eines Kontos mit gutem Score. Der Score selbst: 35 % Vorlauf (mittlere 4-h-Rendite nach seinen Schritten, geschrumpft n/(n+20)), 25 % Edge je Umsatz, 20 % Konsistenz, 10 % Größe, 10 % Klasse — täglich neu, wöchentlich gegen den Folgevorlauf getestet.")
treiber("Gegen-Flow", "0,3", "Positionsschritte der Konten mit belegt <b>negativem</b> Vorlauf (α<sub>4h</sub> < 0, n ≥ 20), letzte 4 h.",
        ["Score = − Σ Richtung<sub>k</sub> · √Notional<sub>k</sub> / Σ √Notional<sub>k</sub>   (invertiert);  Bedingung ≥ 3 Konten"],
        "Handeln die Verlierer, wird dagegen gehalten. Experiment mit kleinem Prior — wenn Verlierer zufällig handeln, parkt die Kalibrierung den Treiber.")
treiber("Elite-Positionierung", "1,0", "Aktuelle Positionen der zehn besten Konten nach Score (learn.elite) im Coin; Leaderboard-Stand vor Wal-Stand, nicht doppelt. Elite-Mitglied wird seit 15.09. nur ein Konto mit <b>Beleg</b>: mindestens 10 Schritte im Coin und positiver Vorlauf (α<sub>4h</sub> > 0); gezählt werden nur Konten, die <b>in diesem Coin direktional</b> sind (Leaderboard-Gruppe; Wale ohne Leaderboard-Eintrag nur bei kontoweit reiner Klasse).",
        ["Bedingung: ≥ 3 zählbare Positionen;  anteil = größte Position / ( UL + US );  Dämpfer = clip( (1 − anteil) / 0,5, 0,5, 1 )",
         "Score = ( UL − US ) / ( UL + US ) · Dämpfer   (hält ein Konto über die Hälfte des Bruttowerts, ist es kein Gruppensignal mehr)"],
        "Jede Positionsänderung eines Elite-Kontos. Die reinste Form der goldenen Regel: Was die Besten halten — als Gruppe, nicht als Einzelkonto. Prüfwerkzeug: Debug-Eintrag „Elite-Positionierung prüfen“.")

# ---- 5. Mikrostruktur ----------------------------------------------------------------
P("5. Markt-Mikrostruktur", "h2")
treiber("Taker-Flow", "0,7", "Taker-Kauf/Verkauf-Verhältnis von Binance (5-min-Fenster, live), OKX (5 min), Bybit (letzte 500 Trades) und Crypto.com (letzte 150 Trades); Börsen mit Spanne < 60 s oder Verhältnis ≥ 9 ausgeschlossen.",
        ["avg = Mittel<sub>Börsen</sub> ln( r<sub>Börse</sub> );  Score = clip( avg / ln 1,5, −1, 1 ) · 0,7"],
        "Aggressive Käufe (Market-Orders) gegen aggressive Verkäufe. Ein Verhältnis 1,5 : 1 über alle Börsen sättigt. Log-Mittel, damit 2 : 1 und 1 : 2 symmetrisch sind.",
        "Langzeitstudien (Audit v3): auf Tageshorizonten keine Richtungsvorhersage — Prior bewusst belassen, die Kalibrierung entscheidet.")
treiber("Funding", "0,4", "Aktueller Hyperliquid-Funding-Satz je Stunde (ctx_bars, Frische 15 min).",
        ["Score = clip( −f / 0,0002, −1, 1 ) · 0,4   (Kontra: positives Funding = Longs zahlen = Squeeze-Risiko nach unten)"],
        "Funding von 0,02 %/h sättigt bei −0,4. Extremes Funding wirkt gegen die Menge.")
treiber("Orderbuch", "0,4", "Hyperliquid-Orderbuch ±50 bps (book_summary, alle 5 s aus dem WebSocket, Frische 10 min).",
        ["imb = ( Bid<sub>50</sub> − Ask<sub>50</sub> ) / ( Bid<sub>50</sub> + Ask<sub>50</sub> );  Score = clip( imb / 0,5, −1, 1 ) · 0,4"],
        "Jede Verschiebung der Tiefe nahe am Kurs. Im Mix-Modus bleiben Binance-/Crypto.com-Bücher hier außen vor (sie speisen die Wände im Pfadmodell).")
treiber("Kapitulation", "0,5", "Eingetretene Binance-Liquidationen der letzten 3 Tage (bnc_liquidations), in 30-min-Blöcken; Seite = liquidierte Position.",
        ["L<sub>jetzt</sub> = Long-Liquidationen der zwei letzten abgeschlossenen Halbstundenblöcke;  avg<sub>L</sub> = Mittel je Block über 3 Tage",
         "Long-Schub: L<sub>jetzt</sub> ≥ 4 · avg<sub>L</sub> und ≥ 3 Mio → Score +0,8 (Erholungschance);  Short-Schub analog → −0,8 (Squeeze läuft)"],
        "Eine Liquidationskaskade — viermal der Durchschnitt binnen einer Stunde. Reiner Ereignis-Treiber; sonst nicht vorhanden.",
        "Der Stream lieferte bis 14.09. nichts (Binance hatte die WebSocket-URLs umgestellt); der Treiber startet deshalb erst jetzt bei n_eff 0.")

# ---- 6. Coinbase ---------------------------------------------------------------------
P("6. Coinbase Spot (Nachfrage ohne Hebel)", "h2")
P("Quelle: Dienst hl-coinbase — Minutenkerzen mit Taker-Seite (cb_bars, 180 Tage), Orderbuch alle 30 s (cb_book). Frische: 30 min.", "small")
treiber("Coinbase-Prämie", "0,8", "Spot-Kurs gegen den Perp-Kurs in Basispunkten; Ruhewert und Streuung aus der eigenen Minutenreihe → Z-Wert.",
        ["premium = ( Spot / Perp − 1 ) · 10<super>4</super>;  Z = ( premium − Mittel ) / Streuung;  Score = clip( Z / 2,5, −1, 1 )"],
        "Ein plötzliches Anschwellen der Prämie (US-Nachfrage), nicht ihr Dauerniveau — der Z-Wert misst den Abstand vom eigenen Ruhewert.")
treiber("Spot-Taker-Flow", "0,7", "Aggressive Käufe und Verkäufe der letzten 60 Minuten (gleitend) auf Coinbase; Z-Wert gegen die Historie; Brutto ≥ 200.000 USD.",
        ["Score = ( Netto / Brutto ) · clip( |Z| / 2,5, 0,4, 1,0 )"],
        "Ein Schub echter, bezahlter Spot-Nachfrage oder -Abgabe.")
treiber("Spot-Orderbuch", "0,4", "Coinbase-Tiefe ±25 bps; Bedingung Bid + Ask ≥ 100.000 USD.",
        ["imb = ( Bid<sub>25</sub> − Ask<sub>25</sub> ) / ( Bid<sub>25</sub> + Ask<sub>25</sub> );  Score = clip( 2 · imb, −1, 1 )"],
        "Verschiebung der Spot-Tiefe. Die schwächste der drei Coinbase-Größen.")

# ---- ETF -----------------------------------------------------------------------------
P("7. ETF-Flüsse (nur BTC und ETH)", "h2")
treiber("ETF-Flows", "0,6", "Tägliche Netto-Flüsse der Spot-ETFs (Farside), letzter Tag und Summe der letzten 5 Tage in Mio USD.",
        ["Gleiche Vorzeichen (letzter Tag und 5-Tage-Summe positiv): Score = clip( Σ<sub>5T</sub> / 1000, 0,2, 1 ) · 0,6;  beide negativ: spiegelbildlich; sonst 0"],
        "Ein anhaltender Zu- oder Abfluss über mehrere Tage. Eine Milliarde in fünf Tagen sättigt.")
treiber("ETF-Momentum", "0,5", "Tägliche Flüsse aus etf_flows (unbegrenzt gespeichert); Frische: jüngster Tag höchstens 4 Tage alt; ≥ 12 Tage nötig.",
        ["Score = tanh( ( Mittel<sub>3T</sub> − Mittel<sub>10T</sub> ) / σ<sub>60T</sub> )"],
        "Beschleunigung der Flüsse: Die letzten drei Tage gegen die letzten zehn, normiert an der Streuung. Die Studien sehen die Wirkung an Tag 3–4.")

# ---- Analog --------------------------------------------------------------------------
P("8. Historie", "h2")
treiber("Analog-Suche", "0,8", "30-min-Kerzen über 3 Jahre; Merkmale des aktuellen Musters (Renditen, Volatilität, RSI, Lage zu MAs) gegen die Historie; die n ähnlichsten Momente und ihre folgenden 24 h.",
        ["p<sub>up</sub> = Anteil der Analoge mit Kurs nach 24 h über dem Start;  basis = unbedingte Aufwärtsquote der Historie",
         "Score = clip( ( p<sub>up</sub> − basis ) · 4, −1, 1 ) · 0,8;  dazu Wilson-Intervall auf n"],
        "Kein Ereignis, sondern Ähnlichkeit: Sah der Markt so aus, ging es danach häufiger aufwärts als sonst? Gegen die Basisrate gemessen, damit Aufwärtsdrift der Historie nichts vortäuscht.")

# ---- 7. Neue Indikatoren --------------------------------------------------------------
P("9. Indikatoren aus dem Auditbericht v3 (seit 14.09.2026)", "h2")
P("Kleine Priors, kontra-orientiert, wo die Langzeitstudien das stützen. Alle Perzentile als Midrank (Bindungen zählen halb); eine konstante Referenzreihe liefert keinen Rang.", "small")
treiber("OI-Überhitzung", "0,3", "Open Interest: Binance (bnc_metrics, 10 min) oder Hyperliquid (ctx_bars), Perzentil über 90 Tage; nur wenn ≥ 14 Tage Reihe und jüngster Wert ≤ 6 h alt.",
        ["ü = clip( ( pct − 0,90 ) / 0,10, 0, 1 );  Score = −0,6 · ü   (nur ab dem 90. Perzentil aktiv)"],
        "Ein Aufbau des Open Interest in die obersten zehn Prozent der eigenen Historie. Evidenz: Folgewoche breitere Spanne, mehr Drawdowns, 44 % statt 53 % aufwärts — daher leichter Kontra; zugleich Regime-Flag.")
treiber("Crowding-Extrem", "0,5", "Netto-Ausrichtung der Top-20 (lb_trend, stündlich, bis 365 Tage): crowd = (USD<sub>long</sub> − USD<sub>short</sub>) / (USD<sub>long</sub> + USD<sub>short</sub>); Perzentil der eigenen Historie; ≥ 14 Tage nötig.",
        ["pct ≤ 0,10: Score = ( 0,10 − pct ) / 0,10   (bis +1);   pct ≥ 0,90: Score = −0,5 · ( pct − 0,90 ) / 0,10   (bis −0,5);   sonst 0"],
        "Die Top-Konten so short-lastig wie selten (unterstes Dezil) → Kontra aufwärts, stark; so long-lastig wie selten → Kontra abwärts, mild. Asymmetrisch wie in der Studie (+6,9 %/30 T unten).")
treiber("Crowding-Trend 7 T", "0,4", "Dieselbe Reihe: Änderung der Ausrichtung über 7 Tage, normiert an der Streuung solcher 7-Tage-Änderungen (≥ 21 Tage nötig).",
        ["Score = tanh( Δ<sub>7T</sub> / σ<sub>Δ7T</sub> ) · 0,8"],
        "Eine Umschichtung der Großen über die Woche — Trend der Positionierung.")
treiber("Vol-Spike-Reversion", "0,3", "Parkinson-Volatilität aus Stunden-Hoch/Tief der letzten 24 h gegen Tages-Hoch/Tief der 20 Tage davor.",
        ["σ<sub>P</sub> = √( Mittel ln(H/L)<super>2</super> / (4 ln 2) );  ratio = σ<sub>24h</sub> · √24 / σ<sub>20T</sub>",
         "spike = clip( ( ratio − 1,5 ) / 1,5, 0, 1 );  Score = − sign( r<sub>24h</sub> ) · spike, falls |r<sub>24h</sub>| > 0,5 %"],
        "Ein Volatilitätsschub (ab dem 1,5-fachen der Norm) nach einer deutlichen Bewegung → Rückschlagneigung. Das Verhältnis ist zugleich der Band-Multiplikator (0,7–1,6).")
treiber("Funding-Spread", "0,4", "HL-Funding (Stundensatz × 8) gegen das Mittel der 8-h-Sätze von Bybit, OKX (ext_metrics) und Binance (bnc_metrics), stündlich verbunden; Perzentil über 30 Tage; ≥ 3 Tage nötig.",
        ["spread = f<sub>HL,8h</sub> − Mittel( f<sub>Fremd,8h</sub> );  Score = −clip( ( pct − 0,5 ) · 2, −1, 1 ) · (1,0 falls |spread| ≥ 0,01 %, sonst 0,5)"],
        "Hyperliquid teurer als die anderen Börsen (Carry-Arbitrage: short HL, long anderswo) → Kontra abwärts; umgekehrt aufwärts. Basis/Carry ist laut Literatur das stärkste der untersuchten Signale.")
treiber("Liquidationsdruck (3 Börsen)", "0,5", "Eingetretene Liquidationen von Binance (Stream), Bybit (Stream, vollständig), OKX (alle 2 min) und Hyperliquid (abgeleitet), 30 Tage; Seite = liquidierte Position.",
        ["total<sub>2h</sub> = Longs + Shorts der letzten zwei Stunden;  pct = Rang gegen rollierende 2-h-Summen der 30 Tage",
         "imb = ( Longs − Shorts ) / total;  intens = clip( ( pct − 0,90 ) / 0,10, 0, 1 );  Score = imb · intens"],
        "Eine Liquidationswelle in den obersten zehn Prozent: Long-Liquidationen → Kapitulation, Erholungschance (+); Short-Liquidationen → Squeeze, Rückschlagrisiko (−). Die Intensität ist zugleich Regime-Flag.")

# ---- 8. Regime -----------------------------------------------------------------------
P("10. Regime — was das Band weitet, aber keine Richtung hat", "h2")
P("Die Langzeitstudien zeigen: Open Interest, Volatilität, Liquidationsintensität und die Varianz-Kompression des Taker-Flows "
  "sagen <i>Bewegung</i> voraus, nicht Richtung. Sie gehen deshalb als Multiplikator in das Prognoseband, nie in den Bias.")
F("Band-Multiplikator = clip( ratio<sub>Vol</sub>, 0,7, 1,6 ) · (1 + 0,25 · ü<sub>OI</sub>) · (1 + 0,25 · intens<sub>Liq</sub>) · (1 + 0,20 · kompr), gedeckelt 0,7–2,2")
F("Varianz-Kompression: Varianz der 10-s-Salden (Kauf − Verkauf) · Kurs je Stunde (bars10), letzte abgeschlossene Stunde gegen die Verteilung der 30 Tage; kompr = clip( ( 0,10 − pct ) / 0,10, 0, 1 )")
P("Lesart: Ein ungewöhnlich ruhiger Taker-Flow (unterstes Dezil) ist die einzige placebogetestete Regularität <i>vor</i> Kaskaden — sie erhöht das Risiko, nennt aber keine Richtung. Die Regime-Zeile steht über der Treibertabelle.")

# ---- 6b Ereignis-Signale -------------------------------------------------------------
P("11. Ereignis-Signale — wann ein Fluss außergewöhnlich ist", "h2")
P("Wal-Flow und Leaderboard-Flow tragen ein Ereignis-Signal, das den Score um 50 % hebt. Es feuert nicht nach einem Z-Wert "
  "(der bei dünn besetzten Stundenreihen mit vielen Nullen 42 % der Stunden erfasste), sondern nach dem <b>Rang</b>:")
F("Ereignis, wenn |Netto<sub>Stunde</sub>| ≥ 98. Perzentil der letzten 14 Tage (ohne die laufende Stunde)  und  |Netto| ≥ Untergrenze (Wale 2 Mio, Leaderboard 500.000 USD)  und  Breite ≥ 3 Konten")
P("Ein Perzentil feuert per Konstruktion mit fester Rate (~2 % der Stunden); Untergrenze und Breite verhindern, dass in ruhigen Wochen "
  "Kleinigkeiten zum Ereignis werden. Gemessen am 13.09.: Rang traf alle drei Fälle der alten Regel und fand einen vierten (−54 Mio aus 12 Konten).")

# ---- 7. Pfadmodell --------------------------------------------------------------------
P("12. Pfadmodell — Magnete, Wände, Stops", "h2")
P("Der Pfad verbindet Richtung und Liquidationscluster. Kandidaten sind Hyperliquid-Liquidationscluster aus der Heatmap (Short-Cluster über, Long-Cluster unter dem Kurs):")
F("Magnet, wenn Notional ≥ max( 10 % des HL-Stundenvolumens, 5 Mio )   — MAGNET_VOL_ANTEIL = 0,10, MAGNET_MIN_USD = 5 Mio (gleiche Funktion in Prognose und Statistik)")
F("Wand (bremst): Limit-/TP-Orders aus HL + Binance-Buch + Crypto.com-Buch je 0,25-%-Stufe, ≥ max( 50 % des fusionierten Stundenvolumens, 5 Mio );  Stop-Auslöser: HL-Trigger-Orders ≥ max( 25 % HL-Volumen, 5 Mio )")
F("Ziel = nächster Magnet in Bias-Richtung (bei |Bias| ≤ 0,12: kein Ziel, Sigma-Band);  Reichweite = 0,5 + 0,5 · Berührquote der Abstandsklasse (0–1 %, 1–2 %, 2–3 %) aus der Magnet-Statistik; Überschuss und Rückkehr nach Berührung aus derselben Statistik")
F("Band: σ<sub>Stunde</sub> · Zeitprofil(Wochentag, Stunde) · Band-Multiplikator, kumuliert über den Horizont")
P("Die <b>Magnet-Statistik</b> misst aus den Heatmap-Schnappschüssen: Berührquote binnen 12 h gegen ein Placebo-Niveau in gleichem Abstand "
  "auf der anderen Seite (Lift), Wilson-Intervall auf n_eff (getrennte 12-h-Blöcke), nach Abstand und nach Größenklasse. "
  "Die <b>Magnet-Varianten</b> (0,5–1 % und 1–2 %, 4/8/12/24 h) prüfen nach Cho et al., Osler und Avellaneda/Lipkin, ob Cluster anziehen: "
  "Δ Berührung − Placebo mit z, Überschussbewegung mit t, „näher“ gegen Placebo, bedingte 15-min-Wahrscheinlichkeit. Erst mit diesem Beleg "
  "wird der Pfad auch bei neutralem Bias ein Cluster anlaufen.")

# ---- 9. Tabelle -----------------------------------------------------------------------
P("13. Alle Treiber auf einen Blick", "h2")
zeilen = [
    ("MA 200 Tage", "0,8", "clip(d/0,10)·0,6", "Lage zum Jahresmittel"),
    ("MA 50 Wochen", "0,6", "clip(d/0,10)·0,5", "Lage zum Wochenmittel"),
    ("60-min-Trend", "0,5", "clip(r60/0,01)·0,5", "Stundenmomentum"),
    ("RSI 14 (1 h)", "0,5", "clip((50−RSI)/30)·0,5", "Mean Reversion"),
    ("7-Tage-Drift", "0,4", "clip(drift/(0,3σ))·0,4", "gedämpfter Wochentrend"),
    ("Direktionale Wale", "1,2", "(L−S)/(L+S)", "Positionen ≥ 20 Mio, direktional"),
    ("Wal-Flow 30 min", "1,3", "Netto/Brutto·clip(|Z|/2,5,0,4,1)·Ereignis", "Positionsänderungen der Wale"),
    ("Leaderboard-Flow 60 min", "1,0", "wie Wal-Flow", "Positionsänderungen Top-Konten"),
    ("Smart Money (direktional)", "1,0", "(UL−US)/(UL+US)", "Ausrichtung Top-50 direktional"),
    ("Käufe/Verkäufe 24 h", "1,0", "(K−V)/(K+V)", "Fills direktionaler Top-Konten"),
    ("Top-20-Trend 24 h", "0,6", "clip(Δ/0,5)·0,6", "Umschichtung der Top 20"),
    ("Smart-Flow 4 h", "1,0", "Σ S·Richtung·√N / Σ S·√N", "Fluss mit Konto-Score gewichtet"),
    ("Gegen-Flow", "0,3", "−Σ Richtung·√N / Σ √N", "Verlierer invertiert (Experiment)"),
    ("Elite-Positionierung", "1,0", "(UL−US)/(UL+US)·Dämpfer, nur im Coin direktional", "die zehn besten Konten als Gruppe"),
    ("Taker-Flow", "0,7", "clip(mean ln r / ln 1,5)·0,7", "4 Börsen, aggressive Orders"),
    ("Funding", "0,4", "clip(−f/0,0002)·0,4", "Kontra bei extremem Funding"),
    ("Orderbuch", "0,4", "clip(imb50/0,5)·0,4", "HL-Tiefe ±50 bps"),
    ("Kapitulation", "0,5", "±0,8 bei Schub ≥ 4× Ø und ≥ 3 Mio", "Liquidationskaskade (Binance)"),
    ("Coinbase-Prämie", "0,8", "clip(Z/2,5)", "Anschwellen der Spot-Prämie"),
    ("Spot-Taker-Flow", "0,7", "Netto/Brutto·clip(|Z|/2,5,0,4,1)", "bezahlte Spot-Nachfrage"),
    ("Spot-Orderbuch", "0,4", "clip(2·imb25)", "Coinbase-Tiefe ±25 bps"),
    ("ETF-Flows", "0,6", "clip(Σ5T/1000, 0,2, 1)·0,6 bei gleichem Vorzeichen", "anhaltender Zu-/Abfluss"),
    ("ETF-Momentum", "0,5", "tanh((m3−m10)/σ60)", "Beschleunigung der Flüsse"),
    ("Analog-Suche", "0,8", "clip((p_up−basis)·4)·0,8", "ähnliche Momente der Historie"),
    ("OI-Überhitzung", "0,3", "−0,6·clip((pct−0,9)/0,1)", "OI im obersten Dezil"),
    ("Crowding-Extrem", "0,5", "+1…0 unten / 0…−0,5 oben", "Ausrichtung Top-20 extrem"),
    ("Crowding-Trend 7 T", "0,4", "tanh(Δ7T/σ)·0,8", "Umschichtung über die Woche"),
    ("Vol-Spike-Reversion", "0,3", "−sign(r24)·clip((ratio−1,5)/1,5)", "Vol-Schub nach Bewegung"),
    ("Funding-Spread", "0,4", "−clip((pct−0,5)·2)", "HL-Funding gegen 3 Börsen"),
    ("Liquidationsdruck (3 Börsen)", "0,5", "imb·clip((pct−0,9)/0,1)", "Liquidationswelle, 4 Quellen"),
]
tabelle(["Treiber", "Prior", "Score (Kurzform)", "Was ihn bewegt"], zeilen, [46 * mm, 12 * mm, 62 * mm, 55 * mm])
P("Gelernte Gewichte, Trefferquote, Wilson-Intervall und n_eff je Treiber stehen live in der Treibertabelle des Dashboards; „gelernt“ heißt, das Gewicht weicht vom Prior ab.", "small")

# ---- 10. Glossar -----------------------------------------------------------------------
P("14. Glossar", "h2")
gl = [
    ("clip(x, a, b)", "x auf das Intervall [a, b] begrenzt; ohne Angabe [−1, 1]."),
    ("Prior", "Startgewicht eines Treibers vor dem Lernen; zugleich Mitte der Regularisierung."),
    ("n_eff", "Zahl unabhängiger Fälle = getrennte Horizont-Blöcke, nicht Zahl der 15-min-Fenster."),
    ("Z-Wert", "Abstand vom eigenen Mittel in Einheiten der Streuung (eigene Historie der Reihe)."),
    ("Perzentil / Midrank", "Anteil kleinerer Werte in der Referenzreihe, Bindungen zählen halb; konstante Reihe → kein Rang."),
    ("Wilson-Intervall", "Konfidenzintervall einer Quote, das bei kleinem n nicht zu eng wird; hier auf n_eff."),
    ("Brier-Skill", "Güte der Wahrscheinlichkeit gegen die Basisrate „immer aufwärts“; > 0 besser als die Basisrate."),
    ("Placebo", "Vergleichsniveau in gleichem Abstand auf der anderen Kursseite zum selben Zeitpunkt; Lift = Berührquote / Placebo."),
    ("direktional", "Konto mit einer Seite je Coin und echtem Hebel; Hedge, Market Maker und gemischte Konten tragen keine Richtung."),
    ("Ereignis-Signal", "Rang ≥ 98 % der letzten 14 Tage + Untergrenze + Breite ≥ 3 Konten; hebt Flow-Scores um 50 %."),
    ("Regime", "Band-Multiplikator aus Vol-Verhältnis, OI-Überhitzung, Liquidationsintensität, Varianz-Kompression; keine Richtung."),
    ("Killkriterium", "Ein Treiber, dessen Trefferquote bei 50 % bleibt, läuft in der Kalibrierung gegen Gewicht null."),
]
tabelle(["Begriff", "Bedeutung"], gl, [40 * mm, 135 * mm])

# =====================================================================================
def kopf_fuss(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7.5); canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, 10 * mm, "Hyperliquid-Liquidationscluster · Treiber der Prognose · Stand 15.09.2026")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Seite {doc.page}")
    canvas.restoreState()


doc = SimpleDocTemplate("/mnt/user-data/outputs/Treiber_der_Prognose_2026-09-15.pdf", pagesize=A4,
                        leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                        title="Treiber der Prognose — Hyperliquid-Liquidationscluster", author="hl_liq_project")
doc.build(story, onFirstPage=kopf_fuss, onLaterPages=kopf_fuss)
print("PDF geschrieben")
