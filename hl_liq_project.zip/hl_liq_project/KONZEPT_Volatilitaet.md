# KONZEPT Volatilität (U237) — Volatilitätsindex mit Kurs, Prognose für vier Wochen, Rückblick über fünf Jahre

Stand 28.10.2026, 17:59 (gemessen). **Vorab festgelegt, bevor eine einzige Zahl dieses Moduls auf echten Daten gerechnet wurde.** Entwurf;
nach der unabhängigen Durchsicht fest bis auf die Entscheidungen des Nutzers (Abschnitt 12). Bau nach Paket 23.89 (U236);
Einspielen nach dem Poller-Bericht am 30.10.2026 um 08:50.

**Nachtrag 13 (28.10.2026, 18:41, nach der unabhängigen Durchsicht, vor jeder Zahl auf echten Daten) geht den Abschnitten 0–12 vor.**
Wo er etwas ändert, gilt er; der alte Text bleibt zur Nachvollziehbarkeit stehen. **13.21** hält fest, was beim Bau gemessen
wurde (28.10.2026, 19:17–19:57, synthetisch): Größe, Nachweisgrenze, Produktionsgröße, Browser-Probe.

**Anlass.** Wunsch des Nutzers (28.10.2026, 17:03; Tippfehler berichtigt): „Ich will einen Volatilitätsindex-Chart mit überlagertem
Kurs, Zeitraum 5 Jahre, für alle 5 Coins als zusätzlichen Abschnitt. Das Volatilitätsmodul soll erkennen, in einem Zeitfenster von
ca. 4 Wochen, wann volatile Phasen kommen könnten, und dafür Prognosen berechnen mit eigener Datenbank. Man soll auswählen können den
Zeithorizont für die Ansicht zwischen 2 Wochen, 8 Wochen, 6 Monate, 12 Monate und 4 Jahre.“

**Entscheidungen des Nutzers vor dem Konzept** (Auswahlfragen, beantwortet 28.10. zwischen 17:03 und 17:20):
- **Kurs überlagert, mit zweiter Achse** in derselben Fläche. Bewusst abweichend von der Regel aus U132 (Kursleiste im eigenen Feld,
  nie zweite Achse); die Regel und ihr Grund standen in der Frage. Gilt nur für diesen Abschnitt.
- **Prognose: Pfad und Phasen** — erwartete Schwankung je Tag für 28 Tage und je Woche die Wahrscheinlichkeit einer volatilen Phase.
- **Index: eigener und DVOL** — realisierte Schwankung für alle fünf Coins gleich gerechnet, dazu DVOL (Deribit) für BTC und ETH.
- **Paket:** U236 zuerst (23.89), die Volatilität danach in einem eigenen Paket.

**Grundlagen:**
- `RECHERCHE_Volatilitaet_28-10-2026.md` (Recherche-Agent, 28.10.; 93 Quellen; Unbestätigtes gekennzeichnet): DVOL als Quelle,
  Prognose über 1–28 Tage, Kalender- und Ereigniseffekte, „volatile Phasen“, Bewertungsmethoden, RV-Schätzer.
- Frühere Prüfungen im Projekt (auf echten Daten, vorab festgelegt):
  - Regime P0.2 (`KONZEPT_Regime.md` 9.4): log-HAR schlägt EWMA bei 1 Tag in allen sechs Coins (BTC QLIKE 0,329 gegen 0,401), bei
    7 Tagen nur bei XMR — nicht belegt.
  - Ausblick 12.2 (`KONZEPT_Ausblick.md`): HAR mit Zusätzen (DVOL, S&P, Stresslage, VIX) ohne Gewinn; die HAR-Breite verliert bei 7
    Tagen gegen eine einfache 365-Tage-Schwankung (CRPS +1,3 %) und gewinnt bei 28 Tagen knapp (−0,8 %). **[Verkehrt herum zitiert –
    berichtigt in Nachtrag 13.1.]**
  - Datentage U154 (`KONZEPT_Makro.md` 11.9): Varianz im Fenster 08:30–10:30 New York an Inflations-Tagen ×2,45, an
    Arbeitsmarkt-Tagen ×1,90 (belegt); über den ganzen UTC-Tag nur ×1,19 bzw. ×1,02.
- Bestandsaufnahme des Codes (28.10.): `swing.db` hat die nötigen Kerzen; DVOL sammelt das System schon (`aktien.db` stündlich BTC
  und ETH seit 24.03.2021, `makro.db` täglich BTC); Termine der USA in `makro.db` (`mk_termin`), Fed-Termine nur über Kalshi in
  `prognosemarkt.db`.

---

## 0. Kurzfassung

- **Was:** ein Abschnitt „VL Volatilität“. Je Coin (BTC, ETH, ZEC, HYPE, XMR):
  1. **Chart:** Volatilitätsindex = realisierte Schwankung der letzten 30 Tage in % p. a. (dazu dünn 7 Tage; für BTC und ETH DVOL
     gestrichelt), der Kurs auf einer zweiten Achse rechts (log). Vergangene volatile Phasen als Flächen. Zeitraum 2 W, 8 W, 6 M,
     12 M, 4 J (dazu 5 J, Entscheidung 12).
  2. **Prognose rechts von „heute“:** erwartete Schwankung je Tag für 28 Tage mit Band; je Woche die Wahrscheinlichkeit einer
     volatilen Phase; bekannte Termine (Inflation, Arbeitsmarkt, Fed, Optionsverfall) als Marken.
  3. **Bilanz:** vorab festgelegte Prüfung auf fünf Jahren Rückblick (Ursprünge täglich seit 28.10.2021), danach vorwärts.
- **Was vorhersagbar ist:** das *Niveau* der Schwankung der nächsten Wochen — Schwankung ballt sich und kehrt langsam zum Mittel
  zurück. Die Güte nimmt mit dem Horizont ab. Den *Zeitpunkt* einzelner Spitzen gibt es nur an bekannten Terminen, und deren Beitrag
  zum Wochenmittel ist klein. Plötzliche Schocks (Hacks, Kaskaden, Regulierung) sind nicht vorhersagbar.
- **Erwartung vorab (Abschnitt 10):** Das Modell schlägt die Persistenz vor allem in Woche 1; volatile Phasen schlägt es gegen die
  Grundrate wahrscheinlich, gegen ein einfaches Zwei-Zustands-Modell offen; DVOL bringt über das HAR hinaus wohl nichts.
- **Wirkt auf nichts:** kein Treiber, keine Prognose, keine Fusion, kein Labor. Liest `swing.db`, `aktien.db`, `makro.db` und
  `prognosemarkt.db` nur lesend; schreibt nur `volatil.db`.

## 1. Regeln (fest)

1. **Nur lesen, nur Anzeige.** Kein Abruf bei Börsen oder Deribit: Kerzen aus `swing.db`, DVOL aus der bestehenden Sammlung.
2. **Kausal.** Eine Prognose zum Ursprung D (00:00 UTC) nutzt nur Kerzen und DVOL-Stunden mit Ende ≤ D, Parameter aus Ursprüngen,
   deren Zielfenster vor D endete, Schwellen aus den 365 Tagen vor D und Termine, die vor D angekündigt waren (Abschnitt 2.5).
3. **Vorab festgelegt:** Zielgrößen, Modelle, Schwelle, Maße, Tests, Mindestzahlen, Urteilsregel (Abschnitte 4–6) — vor jeder echten
   Zahl. Änderungen nur als Nachtrag mit Grund, vor jedem Lauf der Auswertung.
4. **Ein gemeinsames Urteil** (gewichteter Holm), sobald der Rückblick fertig ist und die Prüfungen vor dem Urteil bestehen. Bis dahin
   zeigt die Bilanz nur Zählungen (wie R4 der Prognosemärkte). Die Prognose selbst wird angezeigt, mit dem Hinweis „ungeprüft — das
   Urteil steht aus“.
5. **Schwankung, nicht Richtung:** keine Kauf- oder Verkaufswörter; Farben nur für Zustände und Reihen; Quelle und Zeitpunkt je Zahl.
6. **Eigene Datei `volatil.db`** neben der Hauptdatenbank; Schreiben nur mit BEGIN IMMEDIATE; tägliche Sicherung wie
   `prognosemarkt.db`.

## 2. Daten

**2.1 Kerzen.** `swing.db` → `sw_klines` (Binance-USDT-Perpetual, 30 min): BTC und ETH ab 01.01.2020, XMR ab 03.02.2020, ZEC ab
05.02.2020, HYPE ab 30.05.2025. Nur lesend (`mode=ro`), wie `hl_labor`, `hl_ausblick` u. a. Der Swing-Faden hält sie aktuell.

**2.2 Tages-RV.** Je UTC-Tag die Summe der quadrierten 30-min-Log-Renditen von Schluss zu Schluss; die erste Rendite des Tages geht
vom letzten Schluss des Vortags aus. Gleiche Rechnung wie `hl_swing.tagesreihen` (auf 48 Kerzen hochskaliert, wenn mindestens 40
gültig sind; sonst ist der Tag ungültig) — der Selbsttest vergleicht beide. Robustheitsreihe (nur beschreibend): Rogers-Satchell je
Kerze. Annualisierung mit 365 Tagen.

**2.3 Index.** VI30(D) = 100 · √(365/30 · Σ RV der 30 Tage vor D) in % p. a.; VI7 entsprechend mit 7 Tagen. Gültig, wenn
mindestens 90 % der Tage gültig sind (Lücken: Mittel der gültigen Tage × Tageszahl).

**2.4 DVOL** (nur BTC, ETH). `aktien.db` → `ak_aktuell`, Reihen `drb:dvol_btc_h` und `drb:dvol_eth_h` (Stundenkerzen ab 24.03.2021,
Zeitstempel = Beginn, Wert = Schluss in Vol-Punkten). Tageswert für den Ursprung D: Schluss der Stunde 23:00–24:00 UTC des Vortags.
Ersatz, wenn `aktien.db` fehlt: `makro.db` → `drb:dvol_btc` (täglich, nur BTC). Kein eigener Abruf: Deribits Bedingungen erlauben
Marktdaten nur zur persönlichen Nutzung (Ziff. 2.10) und verbieten automatisierte Sammlung (27.1(i)); die bestehende Sammlung wird nur
mitgelesen (Recherche A5).

**2.5 Termine** (als vorab bekannte Zukunft):
- US-Inflation (CPI) und Arbeitsmarktbericht (Jobs/NFP) aus `makro.db` → `mk_termin` (FRED-Veröffentlichungstermine, auch künftige;
  Uhrzeit 08:30 New York). Die Termine stehen ein Jahr im Voraus fest; verschobene Termine (Shutdown 2025) zählen am tatsächlichen Tag
  — eine kleine Unschärfe im Rückblick, beschreibend vermerkt.
- Fed-Entscheid: nur über Kalshi (`prognosemarkt.db`, Reihen `KXFED`/`KXFEDDECISION`), also erst ab 05/2023 und nur so weit Kalshi
  listet → **nicht im Modell**, nur als Marke im Chart.
- Deribit-Optionsverfall: Monatsverfall (letzter Freitag des Monats) und Quartalsverfall (letzter Freitag im März, Juni, September,
  Dezember), 08:00 UTC — regelbasiert.
- Wochentage (Sa, So gegen Werktage).

## 3. Anzeige

- **Abschnitt „VL Volatilität“** wie die übrigen: Navigation, eigenes Feld, eigenes Skript `hl_volatil_js.py` nach dem Hauptskript;
  Abfragen nur, wenn der Abschnitt offen und sichtbar ist (Takt 60 s; die Daten ändern sich höchstens einmal am Tag).
- **Leiste:** Coins BTC · ETH · ZEC · HYPE · XMR; Zeitraum 2 W · 8 W · 6 M · 12 M · 4 J (· 5 J); Schalter „Kurs“ (an), „7 Tage“ (an),
  „DVOL“ (an, nur BTC und ETH), „Phasen“ (an).
- **Chart** (SVG im Stil des Makro-Charts, eigene Zeichenfunktion mit zweiter Achse):
  - links: Schwankung in % p. a. — VI30 dick, VI7 dünn, DVOL gestrichelt; rechts: Kurs (log), neutral grau, Achse beschriftet
    „Kurs (rechts, log)“; im Fuß klein: „Zwei Achsen: Gleichlauf der Linien sagt nichts.“
  - Flächen: vergangene volatile Wochen nach der Definition in 4.6 (gleiche Schwelle, nur Vergangenheit).
  - rechts von „heute“ die Prognose: erwartete Schwankung je Tag (Linie), Band 50 % und 90 % je Woche, je Woche die Beschriftung
    „W1 · 34 %“ (Wahrscheinlichkeit einer volatilen Phase), Marken für Termine an ihren Tagen.
  - Fadenkreuz mit allen Werten des Tages (Index, DVOL, Kurs, Prognose, Termine); Tabellenansicht je Chart.
- **Tabelle „Nächste 4 Wochen“:** Woche, Zeitraum, erwartete Schwankung (% p. a. und typische Tagesbewegung in %), 50-%-Band,
  Wahrscheinlichkeit einer volatilen Phase mit der Grundrate daneben, Termine der Woche.
- **Reiter:** Chart · Bilanz · Daten. Bilanz: vor dem Urteil nur Zählungen; danach das Urteil V1–V4 mit Maßen, beschreibend die
  Zuverlässigkeit je Woche. Daten: Quellen, Frische, Fortschritt des Rückblicks, Hinweise.
- **Hinweis oben:** „Schwankung, nicht Richtung. Prognose ungeprüft, bis das Urteil steht.“

## 4. Prognose (vorab festgelegt)

**4.1 Ursprung und Wochen.** Ursprung D = 00:00 UTC; Daten bis zum Ende des Vortags. Wochen ab heute (nicht Kalenderwochen):
W1 = Tage D … D+6, W2 = D+7 … D+13, W3 = D+14 … D+20, W4 = D+21 … D+27.

**4.2 Zielgröße.** Je Woche k: R_k = Mittel der Tages-RV der sieben Tage; gültig, wenn mindestens 6 der 7 Tage gültig sind.
Y_k = log R_k.

**4.3 Modell M (log-HAR, direkt je Woche, je Coin).**
Y_k = a_k + b_k · log RV(D−1) + c_k · log R7(D) + d_k · log R30(D) + ε_k, mit R7 und R30 = Mittel der Tages-RV der 7 bzw. 30 Tage
vor D.
- Schätzung: kleinste Quadrate auf den Ursprüngen s mit vollständigem Zielfenster vor D (s ≤ D − 7k), die jüngsten 730 solcher
  Ursprünge, mindestens 365; neu geschätzt am Ersten jedes Monats (wie Regime und Ausblick).
- Vorhersage: μ_k = Schätzwert; σ_k = Standardabweichung der Reste im Schätzfenster. Varianz der Woche:
  V̂_k = exp(μ_k + σ_k²/2).
- Band der Woche: R_k im 50-%-Band exp(μ_k ± 0,674 σ_k), im 90-%-Band exp(μ_k ± 1,645 σ_k).

**4.4 Variante M+ (nur BTC, ETH).** M plus x = log(DVOL(D)² / 365 / 10⁴) als fünfter Regressor; die Varianzprämie steckt im
Koeffizienten. Gleiche Schätzung. Angezeigt wird M+ für BTC und ETH nur, wenn V4 belegt ist; sonst M (Abschnitt 6).

**4.5 Tagespfad.** Tagesvarianz v_j für Tag j der Woche k: v_j = V̂_k · f_j / Mittel(f über W_k). Der Kalender verteilt nur innerhalb
der Woche um; das Wochenmittel bleibt V̂_k.
- f_j = Wochentagsfaktor × Terminfaktor. Wochentagsfaktor: mittlere RV je Wochentag geteilt durch das Mittel, über die 365 Tage vor
  D, zur Hälfte auf 1 geschrumpft. Terminfaktor (Inflation, Arbeitsmarkt, Monats- und Quartalsverfall je eigener Faktor): mittlere RV
  an solchen Tagen der drei Jahre vor D geteilt durch die mittlere RV derselben Wochentage ohne Termin, zur Hälfte geschrumpft,
  begrenzt auf [1, 3]. Fällt ein Tag unter mehrere Termine, zählt der größte Faktor.
- Anzeige: 100 · √(365 · v_j) in % p. a.

**4.6 Volatile Phase.** Woche k ist volatil, wenn R_k über der Schwelle S(D) liegt: S(D) = 80. Perzentil der gleitenden
7-Tage-Mittel der Tages-RV in den 365 Tagen vor D (nur Vergangenheit). Wahrscheinlichkeit P_k = 1 − Φ((log S(D) − μ_k) / σ_k).
Die Grundrate liegt nach Konstruktion um 20 %, schwankt aber mit Trends der Schwankung.

**4.7 Vergleichsmodelle (Baselines).**
- **B0 Persistenz:** V̂_k = R30(D) für alle vier Wochen.
- **Grundrate:** P_k = Anteil volatiler Wochen k unter den Ursprüngen des Schätzfensters von M (nur Vergangenheit).
- **Zwei-Zustands-Modell (Markov):** P_k = Anteil volatiler Wochen k unter den Ursprüngen des Schätzfensters, deren letzte Woche
  (D−7 … D−1, gemessen mit derselben Schwelle) im selben Zustand war wie heute.

**4.8 HYPE.** Tages-RV und Index ab 30.05.2025; die Schwelle braucht 365 Tage (ab 30.05.2026, vorhanden). Für eine eigene Schätzung
fehlen die Ursprünge (365 mit fertigem Ziel, frühestens 2027). Bis dahin bekommt HYPE die **gemeinsamen Koeffizienten** der vier
übrigen Coins (dieselbe Schätzung auf den gepoolten Ursprüngen, je Coin eigener Achsenabschnitt; für HYPE das Mittel der
Achsenabschnitte) auf seiner eigenen RV; angezeigt mit dem Vermerk „geliehene Koeffizienten“, nur beschreibend bewertet.

## 5. Rückblick (fünf Jahre) und Betrieb

- **Ursprünge:** täglich vom 28.10.2021 bis zum Stichtag (Erstlauf des Dienstes), je Coin BTC, ETH, ZEC, XMR; HYPE beschreibend.
  Jede Prognose nur mit Daten und Parametern vor ihrem Ursprung (4.3), gespeichert mit Quelle „rb“.
- **Stichtag** (wie R2 der Prognosemärkte): die Zeit des Erstlaufs. Ursprünge danach gehören zur Vorwärtsrunde (Quelle „live“).
- **Betrieb:** jeden Tag ab 00:15 UTC die Prognose des Tages, sobald `swing.db` den Vortag vollständig hat (sonst später erneut).
  Die monatliche Neuschätzung läuft am Ersten mit.
- **Aufwand:** etwa 4 × 1.830 Ursprünge × 4 Wochen; 60 Neuschätzungen je Coin; mit numpy Sekunden bis Minuten auf dem Pi.

## 6. Auswertung — vorab festgelegt

**6.1 Stichprobe.** Ursprünge 28.10.2021 bis Stichtag − 28 Tage (alle vier Wochen fertig), Coins BTC, ETH, ZEC, XMR gemeinsam. V4
nur BTC und ETH.

**6.2 Vier Prüfungen.**
- **V1 Niveau:** Verlust QLIKE(R_k, V̂_k) = R_k/V̂_k − log(R_k/V̂_k) − 1 je Coin, Ursprung und Woche. Maß: mittlere Differenz
  QLIKE(B0) − QLIKE(M) über alle Wochen, Coins und Ursprünge; einseitig > 0.
- **V2 Phasen gegen die Grundrate:** Brier(Grundrate) − Brier(M); einseitig > 0. Dazu Brier-Skill beschreibend.
- **V3 Phasen gegen das Zwei-Zustands-Modell:** Brier(Markov) − Brier(M); einseitig > 0.
- **V4 DVOL (BTC, ETH):** QLIKE(M) − QLIKE(M+); einseitig > 0.

**6.3 Test.** Die Differenzen werden je Ursprungstag über Coins und Wochen gemittelt (Gewicht je gültigem Wert). Studentisierter,
zentrierter Block-Bootstrap über Ursprungstage mit zirkulären Blöcken von 28 Tagen (überlappende Fenster, Horizont bis 28 Tage),
9.999 Ziehungen, p = (1 + #{T* ≥ T}) / (B + 1). Gewichteter Holm über V1–V4 mit gleichen Gewichten (je 0,25); nicht prüfbare Tests
fallen heraus, die Gewichte werden auf die prüfbaren normiert.

**6.4 Urteil je Prüfung.** „belegt“ nur bei angepasstem p < 0,05, richtigem Vorzeichen in beiden Hälften (Teilung am Median-Datum,
jede Hälfte mit mindestens 40 % der Mindestzahl) und erreichter Mindestzahl: V1–V3 mindestens 900 Ursprungstage, V4 mindestens 900
Ursprungstage mit DVOL. Sonst „nicht belegt“ bzw. „nicht prüfbar“.

**6.5 Prüfungen vor dem Urteil** (alle müssen bestehen; sonst kein Urteil, der Grund wird vor einem neuen Lauf als Nachtrag behoben):
1. **Daten:** Tages-RV gleich `hl_swing.tagesreihen` auf denselben Kerzen (Abweichung < 10⁻⁹ relativ); mindestens 98 % gültige Tage
   je Coin seit 28.10.2021.
2. **Positivkontrolle Ballung:** Korrelation von log R der Woche mit log R der Vorwoche > 0,4 je Coin (Schwankung ballt sich; sonst
   ist an den Daten etwas falsch).
3. **Positivkontrolle Wochenende:** mittlere RV an Sa/So < 0,95 × Werktage, gepoolt (Recherche B2: etwa 0,6–0,75).
4. **Kalibrierung der Bänder:** Anteil der Wochen über dem 90-%-Band zwischen 1 % und 12 % (erwartet 5 %).
5. **Nullprobe auf echten Daten:** Wahrscheinlichkeiten von M blockweise (28 Tage) zwischen Ursprüngen vertauscht → V2 in höchstens
   5 % + 2,326 · √(0,05 · 0,95 / Welten) der 200 Welten belegt.

**6.6 Beschreibend, ohne p-Werte (erst nach dem Urteil):** Maße je Woche und je Coin; Zuverlässigkeitsdiagramm der Phasen je Woche;
Mincer-Zarnowitz je Woche; Tagespfad mit und ohne Kalender (QLIKE je Tag in W1); HYPE mit geliehenen Koeffizienten; Robustheit mit
Rogers-Satchell.

**6.7 Vorwärts.** Live-Prognosen ab dem Stichtag. Nach 26 Wochen mit fertigen Zielen (etwa 150 Ursprünge je Coin) dieselben Tests
V1 und V2 auf den Live-Werten, eigenes α = 0,05, als Bestätigung. Bis dahin beschreibend.

## 7. Datenbank `volatil.db`

| Tabelle | Inhalt | Schlüssel |
|---|---|---|
| `vl_tag` | Tages-RV, Zahl gültiger Kerzen, Rogers-Satchell, Schlusskurs, VI7, VI30 | coin, tag |
| `vl_dvol` | DVOL-Tageswert (Schluss 23–24 Uhr UTC), Quelle | coin, tag |
| `vl_termin` | Termin je Tag: Art (cpi, jobs, fed, verfall_m, verfall_q), Quelle, bekannt seit | tag, art |
| `vl_prognose` | je Coin, Ursprung, Modell, Woche: μ, σ, V̂, Schwelle, P, Grundrate, Markov-P; Tagespfad als JSON; Quelle (rb/live); Zeitpunkt der Berechnung | coin, ursprung, modell, woche |
| `vl_koeff` | Koeffizienten je Coin, Modell, Woche und Schätzmonat, n, σ | coin, modell, woche, monat |
| `vl_auswertung` | Prüfung, Lauf, n, Tage, Maß, Intervall, p, p (Holm), Hälften, Urteil, endgültig, Fassung, Details | pruefung, lauf |
| `vl_meta` | Stichtag, Erstlauf, Zustand, Fehler, Zählung | k |

Schreiben nur mit BEGIN IMMEDIATE; gleiche Werte erzeugen keine neue Zeile; Prognosen werden nie überschrieben (eine Neuberechnung
desselben Ursprungs ist ein Fehler und wird gemeldet).

## 8. Dienst, Berichte, Debug

- **Faden „volatil“** im Dashboard: Start 90 s nach dem Dashboard (nach dem Swing-Faden); aus mit `HL_VOL=0`; `HL_VOL_DB` lenkt die
  Datei um; nicht für Selbsttest-Datenbanken. Schwere Rechnung (Rückblick, Auswertung) in Schritten, damit das Dashboard nicht hängt.
- **Erstlauf:** prüft je Coin Kerzen (erster und letzter Tag, Lücken), DVOL-Reihen (Bereich, Einheit), Termine (Zahl je Art,
  nächste); setzt den Stichtag; danach Rückblick in Schritten.
- **Auswertung** täglich nach dem Live-Lauf; vor dem Urteil nur Zählung.
- **Debug** (nächste freie Nummern): 134 „★ Volatilität: Stand“, 135 „★ Volatilität: Auswertung“, 136 „Volatilität: Selbsttest“,
  137 „Volatilität: Mutationen“. Berichtsplan: Stand und Auswertung am ersten und zweiten Tag nach dem Einspielen sowie in der
  Wochenprüfung.
- **Sicherung:** `volatil.db` zu `BACKUP_NEBEN` (vorab festgelegte Prognosen).

## 9. Selbsttest, Mutationen, Proben

**9.1 Selbsttest (ohne Netz, synthetische Datenbanken):** Tages-RV gleich `hl_swing.tagesreihen` (auch mit Lücken); Annualisierung und
Index von Hand; Kausalität (Kerzen, DVOL und Termine nach dem Ursprung ändern nichts); HAR von Hand auf einer kleinen Matrix; Schwelle
nur aus der Vergangenheit; P_k von Hand; Tagespfad erhält das Wochenmittel; Verfallstage (letzter Freitag, Quartal, Monatsende auf
Freitag); Termine nur, wenn vor D bekannt; Bootstrap: Größe in Nullwelten ≤ 5 % (mit Toleranz), Teststärke bei einem synthetischen
HAR-Prozess mit bekannter Ballung ≥ 80 %; Holm; Urteilsregel; Tor der Bilanz; Nutzlast ohne NaN; Ende zu Ende.

**9.2 Mutationen (müssen rot werden):** Ziel im Regressor; Schwelle mit Zukunft; Wochenfenster um einen Tag verschoben;
Annualisierung 252; QLIKE-Vorzeichen; Bootstrap ohne Blöcke; Perzentil- statt zentriertem Bootstrap; Holm weg; Hälften ignoriert;
Mindestzahl ignoriert; DVOL-Stunde vor ihrem Ende; Tagespfad ändert das Wochenmittel; Termin aus der Zukunft; Grundrate aus der
Zukunft; Markov-Zustand mit der Zielwoche; Lücke als gültiger Tag; Lücken nicht hochskaliert; Urteile einzeln; kein Stichtag; Tor
offen; Neuschätzung mit Zielen nach D.

**9.3 Browser-Probe:** zwei Datenstände (vor und nach dem Urteil) × zwei Breiten (Schreibtisch, 390 px) × drei Reiter; zwei Achsen
beschriftet und nicht verwechselbar; Prognosefläche, Bänder, Wochen-Beschriftung, Marken; Zeitraumknöpfe ändern den sichtbaren
Bereich; keine Skriptfehler; Abfragen nur bei offenem Abschnitt; dazu Seiten-Mutationen (jede muss rot sein).

## 10. Erwartung vorab (damit nichts überrascht)

- **V1:** belegt, getragen von Woche 1 (Persistenz der Schwankung). Ab Woche 3 kaum Vorsprung vor der 30-Tage-Persistenz
  (Regime P0.2; Recherche B1: Monats-R² um 13 %).
- **V2:** belegt (eine heute hohe Schwankung macht eine volatile Woche wahrscheinlicher als die Grundrate).
- **V3:** offen. Das Zwei-Zustands-Modell nimmt die Ballung schon mit; das HAR muss zusätzlich das *Maß* der heutigen Schwankung
  nutzen.
- **V4:** nicht belegt (Ausblick 12.2: DVOL im HAR ohne Gewinn; Recherche B1: keine Studie mit DVOL bei 14–28 Tagen).
- **Tagespfad:** Termine heben einzelne Tage deutlich (Inflation am ganzen Tag ×1,19), das Wochenmittel kaum.
- **Teststärke:** bei 28-Tage-Fenstern gibt es seit 10/2021 nur etwa 65 unabhängige Fenster je Coin; Unterschiede von wenigen
  Prozent sind kaum nachweisbar. Die Blöcke von 28 Tagen sind vorsichtig gewählt.

## 11. Grenzen

- Binance-Perpetual als Ersatz für den Spot; 30-min-Renditen enthalten etwas Mikrostruktur-Rauschen (bei Altcoins mehr).
- Strukturbrüche (ETF-Ära, Wochenende ruhiger seit 2024): das Schätzfenster von zwei Jahren folgt ihnen nur langsam.
- DVOL nur BTC und ETH, mit Varianzprämie (im Mittel zu hoch); im Modell kalibriert, in der Anzeige roh.
- Fed-Termine im Rückblick unvollständig (nur Kalshi ab 05/2023) → nicht im Modell.
- HYPE: kurze Historie, geliehene Koeffizienten, nur beschreibend.
- Zwei Achsen (Entscheidung des Nutzers): Die Lage der Linien zueinander hängt an der Skalierung; der Fuß sagt das.
- Deribit-Daten nur zur persönlichen Nutzung; der Abschnitt ist nicht zum Teilen gedacht.

## 12. Entscheidungen beim Nutzer (Standard in Klammern)

1. Schwelle einer volatilen Phase (80. Perzentil der 7-Tage-Mittel im Vorjahr; Alternativen 75 oder 90).
2. Zeitraum 5 J zusätzlich zu den fünf gewünschten (ja, weil der Chart fünf Jahre zeigen soll).
3. Index-Fenster (30 Tage, dazu 7 Tage dünn).
4. Wochen ab heute oder Kalenderwochen (ab heute).
5. HYPE mit geliehenen Koeffizienten zeigen (ja, gekennzeichnet).

## 13. Nachtrag nach der unabhängigen Durchsicht (28.10.2026, 18:41)

Durchsicht durch einen unabhängigen Agenten am 28.10.2026 (Konzept, Recherche, die Vorlagen in `hl_swing`, `hl_aktien`, `hl_makro`,
`hl_regime`, `hl_ausblick`, `hl_prognosemarkt` und eine synthetische Probe der Prüfstrecke): **32 Befunde, davon 3 kritisch, 14
wichtig, 15 klein.** Alle sind unten entschieden; was übernommen ist, gilt vor den Abschnitten 0–12. Gerechnet wurde bis hierhin
nichts auf echten Daten (der Bau lief parallel nur auf synthetischen Datenbanken; seine Fassung nach dem alten Text wird hier
angepasst).

### 13.1 Berichtigung (Befund 1)

Ausblick 12.2 war verkehrt herum zitiert. Dort ist der CRPS-Gewinn 1 − CRPS(B0) ÷ CRPS(B1): **+1,3 % bei 7 Tagen (p 0,001) heißt, die
HAR-Breite ist besser** als die einfache 365-Tage-Schwankung; −0,8 % bei 28 Tagen (p 0,84) heißt, sie ist dort (nicht signifikant)
schlechter. Regime P0.7: EWMA ist das beste Einzelfenster, 2–8-Wochen-Fenster sind schlechter. **Damit ist die 30-Tage-Persistenz B0
der schwächste einfache Vergleich** – für W1 zu träge, für W3/W4 ohne Rückkehr zum Mittel.

### 13.2 Vergleiche und V1 (Befunde 1, 22)

- Neu für alle vier Wochen: **B365** = Mittel der Tages-RV der 365 Tage vor D (mindestens 329 gültige Tage) und **EWMA** = λ 0,94 auf
  die Tages-RV bis D−1 (wie `hl_regime.ewma_tag`).
- **V1 ist ein Schnitt-Vereinigungs-Test** aus V1a = QLIKE(B0) − QLIKE(M) und V1b = QLIKE(B365) − QLIKE(M): „belegt“ nur, wenn beide
  Teile die volle Regel erfüllen (Maß > 0, beide Hälften > 0, Mindestzahl, angepasstes p < 0,05). Im Holm zählt
  p_V1 = max(p_V1a, p_V1b); das hält α ohne weitere Korrektur.
- EWMA steht beschreibend je Woche (Entscheidung 6: in der strengen Fassung dritter Teil des Schnitt-Tests).
- Differenzen nur aus Paaren, in denen beide Prognosen und das Ziel gültig sind. Hälften und Mindestzahl in Ursprungstagen (Teilung am
  Median-Datum), nicht in Fällen. Holm-Gewichte bleiben gleich (Entscheidung 7).

### 13.3 Blöcke, Mindestzahl, Nullprobe (Befunde 2, 5)

- **Blocklänge 112 Tage** (4 × längster Horizont) für alle Prüfungen statt 28. Die synthetische Probe der Durchsicht: bei 28 Tagen
  8,7–10,5 % Fehlurteile für V2 bei nominal 5 %, bei 112 Tagen 4,7–6,2 %.
- **Mindestzahl je Prüfung 1.344 Ursprungstage** (12 Blöcke zu 112), **je Hälfte mindestens 672** (6 Blöcke).
- **Vorzeichen-Nullprobe auf den echten Verlustdifferenzen** je Prüfung (V1a, V1b, V2, V3, V4) statt der Vertauschung aus 6.5 Punkt 5:
  d*_t = s_b · (d_t − d̄) mit zufälligem Vorzeichen s_b je 224-Tage-Block, 200 Welten, volle Urteilsregel (Bootstrap mit der Blocklänge
  der Prüfung, Hälften, Mindestzahl, α 0,05 ohne Holm). Bestanden mit höchstens 5 % + 2,326 · √(0,05 · 0,95 / 200) = 8,6 % „belegt“.
  **Automatische Blockregel:** Scheitert sie bei 112 Tagen, gilt für diese Prüfung 168, dann 224 Tage – ohne Wahl von Hand. Scheitert
  sie auch bei 224, ist die Prüfung „nicht prüfbar (Größe nicht gesichert)“ und fällt aus dem Holm. Berichtet wird nur die Rate,
  nie das Mittel von d. Die Vertauschung bleibt nur als Selbsttest der Mechanik (ohne festen Block, Nachtrag beim Bau).
- Der Selbsttest misst die Größe in synthetischen Welten mit realistischer Ballung (langsames Niveau, HAR-Abweichung, t-Schocks),
  die Verlustdifferenz um ihr Populationsmittel verschoben; Grenze 5 % + 2,326 · √(0,0475 / Welten).

### 13.4 Anzeige nach dem Zustand des Urteils (Befunde 3, 12, 14, 17, 26)

- **Kopf:** vor dem Urteil „ungeprüft – das Urteil steht aus“; ohne bestandene Prüfungen „kein Urteil (Prüfung vor dem Urteil nicht
  bestanden: …)“; danach je Prüfung „belegt“ oder „nicht belegt“ mit Datum. Immer dabei: „Daten nicht frisch: HAR wurde auf diesen
  Kursen schon geprüft (Regime, Ausblick); unabhängig ist erst die Vorwärtsrunde.“
- **Nach dem Urteil je Woche beschreibend** die Differenz mit 90-%-Blockintervall (Block der Prüfung): Niveau gegen B0, B365 und
  EWMA; Phasen gegen Grundrate und Zwei-Zustands-Modell. **Regel wie Ausblick 5.5 (S1):** Eine Baseline gilt in Woche k als besser,
  wenn das 90-%-Intervall der Differenz ganz auf ihrer Seite liegt und das Vorzeichen in beiden Hälften gleich ist. Dann zeigt die
  Tabelle für diese Woche die Baseline als Hauptwert und M daneben („im Rückblick besser: Jahresmittel“ bzw. „… 30-Tage-Mittel“,
  „… EWMA“, „… Grundrate“, „… Zwei-Zustands-Modell“); im Chart bleibt die Wochenstufe von M mit diesem Vermerk im Fadenkreuz.
- **V1 nicht belegt:** Das Niveau von M bleibt sichtbar (Auftrag des Nutzers); der Kopf sagt „Niveau im Rückblick nicht besser als
  30-Tage- und Jahresmittel“, die Tabelle zeigt B0 und B365 daneben. **V2 nicht belegt:** die Wahrscheinlichkeit mit „nicht besser
  als die Grundrate“, die Grundrate gleich groß daneben. **V3:** nur Text. **HYPE:** immer „nicht im Urteil“.
- **Vor dem Urteil (R4 technisch):** Nutzlast und Berichte enthalten nur die Prognose zum jüngsten Ursprung und Zählungen – keine
  früheren Prognosen, keine QLIKE-, Brier- oder Deckungswerte. Die Prüfungen vor dem Urteil zeigen bestanden/nicht bestanden mit
  Datenwerten, nie einen Vergleich von M mit einer Baseline. Geprüft im Selbsttest, über den Server und in der Browser-Probe.
- **Chart:** Wochenstufe = erwartetes Wochenmittel (dieselbe Größe wie VI7, also dessen Fortsetzung) mit Bändern 50 % und 90 % als
  Wochenrechtecke „Wochenmittel 50 % / 90 %“; der Tagespfad dünner, Legende „Tageswerte = Wochenprognose × Kalendermuster (nur das
  Wochenmittel ist geprüft)“; die Schwelle als waagrechte Linie „Schwelle volatil (80. Perzentil der letzten 365 Tage)“;
  Beschriftung „W1 · 34 % (üblich 18 %)“; Wahrscheinlichkeiten ganzzahlig, angezeigt zwischen 1 % und 99 %. **Ab 12 M** stehen die
  Einzelheiten nur in der Tabelle; im Chart bleiben die „heute“-Linie und die Wochenstufen. Der Kurs endet am letzten Tagesschluss.
  An der Prognose „Stand 00:00 UTC, UTC-Tage“. Tabelle: „Tagesschwankung (1 σ)“ statt „typische Tagesbewegung“.
- **Achsen (Befund 18):** links „Schwankung (% p. a.)“; rechts höchstens vier Beschriftungen in der Farbe des Kurses, Format
  „68.000 $“, keine Gitterlinien von rechts; Legende „VI30 · VI7 · DVOL (links) — Kurs (rechts, log)“; Fadenkreuz nach Achsen
  gruppiert; die linke Achse aus VI30, DVOL und den Bändern, VI7-Spitzen über dem 99. Perzentil abgeschnitten und markiert (voller
  Wert im Fadenkreuz). Farben: Index blau, DVOL grün, Phasen bernstein mit geringer Deckkraft (kein Rot/Grün für Zustände), Kurs 1 px
  grau unter den Schwankungslinien. **Fuß:** „Zwei Achsen: Gleichlauf der Linien sagt nichts.“ – „Schwankung in beide Richtungen;
  Flächen und Wahrscheinlichkeiten sagen nichts über die Richtung.“ – „DVOL schaut 30 Tage voraus und liegt im Mittel über der
  späteren Schwankung (Varianzprämie); VI30 schaut 30 Tage zurück.“ – Befund 32: „Der Ausblick zeigt eine Breite für 28 Tage aus
  24-h-Blöcken; hier wird je Woche ab heute gerechnet – die Zahlen können abweichen.“

### 13.5 σ außerhalb der Stichprobe (Befund 4)

- Form (a): Normalverteilung mit **σ_oos,k(D)** = Standardabweichung der Fehler e_s = log R_k(s) − μ_k(s) früherer gespeicherter
  Prognosen desselben Modells mit fertigem Ziel (s ≤ D − 7k), die jüngsten 730, mindestens 365. Davor σ der Reste im Schätzfenster,
  gekennzeichnet („σ im Fenster“). V̂_k = exp(μ_k + σ²/2), Bänder und P_k mit demselben σ.
- Damit früh genug Fehler vorliegen, rechnet der Rückblick je Coin ab dem ersten möglichen Monat einen **Vorlauf** (Quelle „vorlauf“,
  nur für σ, nie bewertet oder angezeigt).
- Prüfung 6.5 Punkt 4 wird reine **Fehlerprobe mit weiten Grenzen: 0,5–25 %** über dem 90-%-Band (fängt Vertauschungen und
  Einheitenfehler); die Deckung je Coin und Woche steht nach dem Urteil beschreibend.

### 13.6 V4 auf gleicher Stichprobe, DVOL (Befunde 6, 9, 24)

- V4 vergleicht M+ mit **M°** = M auf genau denselben Ursprüngen wie M+ (gleiche Auswahl, nur ohne den DVOL-Regressor):
  V4 = QLIKE(M°) − QLIKE(M+). Die Stichprobe beginnt mit dem ersten Ursprung mit M+ (etwa 05/2022). Angezeigt wird M (M+ nur nach
  „V4 belegt“); M° dient nur V4.
- **DVOL im Modell nur aus `aktien.db`**: die Stunde mit ts = D − 3.600 (Schluss um D, 00:00 UTC; kausal in beiden Lesarten des
  Zeitstempels). Der Tageswert aus `makro.db` dient nur der Anzeige, mit Datum D−2 (ob Deribits Tageskerze um 00:00 oder 08:00 UTC
  schließt, ist ungeprüft); der Erstlauf vergleicht beide Lesarten mit den Stundenschlüssen und hält das Ergebnis fest. Ohne
  `aktien.db` ist M+ „nicht verfügbar“.
- **Einheit:** Median der letzten 365 Tage in [15; 200] → Vol-Punkte; in [0,15; 2] → × 100; sonst Fehler, M+ und V4 entfallen.

### 13.7 HYPE (Befund 7)

Die Begründung in 4.8 war falsch (365 Ursprünge mit fertigem W4 gibt es seit etwa 26.07.2026). **Gemeinsame Steigungen, eigenes
Niveau:** Steigungen aus der gepoolten Schätzung der vier Prüf-Coins; der Achsenabschnitt je Woche aus HYPEs eigener Vergangenheit
(a_k = Mittel von log R_k(s) − Steigungen · x(s) über HYPEs Ursprünge mit fertigem Ziel vor dem Monatsersten, mindestens 90; sonst
das Mittel der Achsenabschnitte, gekennzeichnet); σ aus HYPEs eigenen Resten (mindestens 90, sonst gepoolt) bzw. σ_oos wie 13.5.
Beschriftung „gemeinsame Steigungen, eigenes Niveau“; nie im Urteil.

### 13.8 Termine und Kalenderfaktoren (Befunde 8, 21, 25)

- Im Tagespfad wirken nur **Inflation (CPI) und Arbeitsmarkt (Jobs)**. Optionsverfall und Fed sind nur Marken (Faktor 1; für den
  Verfall gibt es keinen Beleg eines Schwankungseffekts, Recherche B2).
- **Ein vergangener Termin zählt nur, wenn eine Erstveröffentlichung** (`makro.db`, `mk_fassung` Art „erst“) am selben Tag ihn
  bestätigt; künftige Termine laut Kalender. **Bekannt seit** = Tag − 60 für bestätigte Termine außerhalb 01.10.2025–31.01.2026;
  Termine im Zeitraum des Stillstands gelten im Rückblick erst am Tag selbst als bekannt (nur Marke, kein Faktor im Pfad; sie
  fallen aus der Tagesprüfung). Live gilt der Kalenderstand zum Ursprung; gespeicherte Prognosen ändern sich nie.
- **Fed-Termine aus einer festen Liste** im Code (federalreserve.gov, Sitzungen 2021–2027, Entscheid am zweiten Tag, 14:00 New York;
  abgerufen am 28.10.2026) statt aus Kalshi – keine Abhängigkeit von `prognosemarkt.db`.
- **Wochentagsfaktor** = exp(½ · Mittel von log(RV_Tag ÷ R7 davor)) je Wochentag über die 365 Tage vor D (mindestens 20 Tage je
  Wochentag). **Terminfaktor wie U154:** exp(½ · Mittel über die bestätigten Termine der drei Jahre vor D von (log RV_Termin − Mittel
  log RV der Werktage desselben Kalendermonats ohne Termin)), mindestens 6 Termine und je Termin 5 Vergleichstage, begrenzt auf
  [1; 3]. Das Umverteilen hält das Wochenmittel und senkt dafür die übrigen Tage einer Terminwoche (bei ×1,19 um rund 3 %).

### 13.9 Gültigkeit und Tageslauf (Befunde 10, 19, 20)

- RV(D−1) gültig mit mindestens 40 Renditen, sonst der letzte gültige Tag, höchstens 3 zurück; **R7 und VI7 mit mindestens 6 von 7**,
  R30 und VI30 mit mindestens 27 von 30; S(D) aus 7-Tage-Fenstern mit je mindestens 6 gültigen Tagen, mindestens 300 Fenster;
  RV ≤ 0 ist ungültig. Sonst keine Prognose für diesen Ursprung (gezählt). Das Datum des Index im Chart ist der letzte enthaltene Tag.
- Zustand eines Ursprungs s = Mittel s−7 … s−1 gegen S(s). **Grundrate und Zwei-Zustands-Modell täglich:** die jüngsten 730
  eingestuften Ursprünge mit s ≤ D − 7k, mindestens 365; je Zustand mindestens 30, sonst die Grundrate (gezählt). V2/V3 beginnen
  erst, wenn diese 365 vorliegen (BTC/ETH etwa 01/2022, ZEC/XMR etwa 03/2022).
- **Tageslauf ab 01:00 UTC** (DVOL holt `hl_aktien` nur alle 30 min), sobald die Kerze 23:30 des Vortags in `swing.db` steht;
  spätestens 06:00 UTC mit dem vorhandenen Stand. Kerzen ab D werden abgeschnitten. Fehlt die DVOL-Stunde, entfallen M+ und M° für
  diesen Tag (gezählt). Nachgeholte Ursprünge (Pi war aus) tragen die Quelle „nachgeholt“ mit Rechenzeit und zählen nicht zur
  Vorwärtsrunde.

### 13.10 Fassung, Speicher, Stichtag (Befunde 11, 28)

- Spalte **`fassung`** im Schlüssel von `vl_prognose`, `vl_koeff` und `vl_auswertung` (jetzt „U237-1“). Das Urteil nutzt genau eine
  Fassung; Live-Prognosen tragen ihre; eine neue Fassung nach dem Urteil ändert es nie (neue Runde).
- Je Ursprung zusätzlich gespeichert: B0, B365, EWMA, S(D), die Regressoren, σ und seine Herkunft, letzte Kerze und DVOL-Stunde,
  Quelle. Je Urteil: Saat, Blocklänge je Prüfung, Zahl der Blöcke.
- Der Stichtag steht zusätzlich in `volatil_stichtag.json` neben `volatil.db` und nach dem Einspielen in UPDATE_PLAN und UEBERGABE;
  ein neuer Erstlauf übernimmt ihn von dort und verschiebt ihn nie.

### 13.11 Vorwärtsrunde (Befund 13)

26 Wochen wären 1–2 Blöcke zu 112 Tagen – ohne Teststärke. Deshalb zunächst **nur beschreibend je Monat**: kumulierte Differenz gegen
B0, B365 und Grundrate mit 90-%-Intervall, Deckung, Zuverlässigkeit. **Bestätigungstest** (V1 und V2 wie im Rückblick, eigenes
α 0,05, Holm über die beiden) erst mit mindestens 1.344 Live-Ursprungstagen (etwa 3,7 Jahre). **Warnregel:** Liegt nach mindestens
365 Live-Tagen das 90-%-Intervall einer Differenz ganz unter 0, steht in der Anzeige „vorwärts schlechter als …“.

### 13.12 Wenige Extremwochen (Befund 15)

QLIKE bleibt. Am Urteil steht beschreibend: das Mittel ohne das 1 % einflussreichster Ursprungstage, der Median der Tagesdifferenzen,
der Beitrag der 10 größten Tage, das Ganze je Jahr und je Coin. Kippt das Vorzeichen ohne das 1 %, steht am Urteil „getragen von
wenigen Wochen (…)“.

### 13.13 Vergangene Phasen im Chart (Befund 16)

Tag t gehört zu einer Phase, wenn das 7-Tage-Mittel t−6 … t (mindestens 6 gültige Tage) über S(t−6) liegt – der Schwelle zu Beginn
dieses Fensters aus den 365 Tagen davor. Zusammenhängende Tage bilden eine Fläche; Beschriftung „realisiert, Schwelle des jeweiligen
Vorjahrs“.

### 13.14 Prüfungen vor dem Urteil, neu gefasst (Befunde 4, 5, 23, 24)

1. **Daten:** Tages-RV gleich `hl_swing.tagesreihen` vom Beginn der Kerzen an; je Coin mindestens 98 % gültige Tage ab Beginn der
   Schätzfenster. Scheitert ein Coin, fällt er mit Grund heraus; das Urteil läuft mit den übrigen, solange mindestens drei bleiben;
   scheitert BTC oder ETH, entfällt V4. Ausgeschlossene Zielwochen (weniger als 6 gültige Tage) werden mit Datum aufgelistet.
2. **Datenprobe Ballung:** Korrelation von log R der Woche mit log R der Vorwoche > 0,4 je Coin.
3. **Datenprobe Wochenende:** Varianz Sa/So < 0,95 × Werktage (erwartet 0,35–0,6).
4. **Fehlerprobe Bänder:** 0,5–25 % über dem 90-%-Band.
5. **Zuordnung:** zwei Orakel-Mischungen müssen mit T > 5 „belegt“ sein, sonst stimmt die Kette Prognose → Ziel → Verlust nicht:
   V̂* = B0^0,7 · R^0,3 gegen B0 und P* = Grundrate + 0,3 · (y − Grundrate) gegen die Grundrate. Sie sagen nichts über M.
6. **Vorzeichen-Nullprobe** je Prüfung mit der automatischen Blockregel (13.3).
7. **DVOL-Einheit** (13.6).

### 13.15 Rechnung außerhalb des Dashboards (Befund 27)

Erstlauf, Rückblick, Auswertung und Tageslauf laufen als **eigener Prozess mit nice 10** (wie Ausblick 12.1 Punkt 7); der Faden
„volatil“ im Dashboard entscheidet nur jede Minute, ob etwas fällig ist, und liest dazu `volatil.db` nur.

### 13.16 Beschreibend ergänzt (Befund 29)

Mincer-Zarnowitz in Niveaus, gewichtet (R/V̂ auf 1/V̂ und 1); für BTC/ETH „DVOL allein, kalibriert“ (Regression von log R_k auf
log DVOL², beschreibend); EWMA und Zwei-Zustands-Modell je Woche.

### 13.17 Mutationen ergänzt (Befund 30)

Zusätzlich müssen rot werden: V1 ohne B365; Schnitt-Test durch min(p) ersetzt; Block 28 statt 112; σ aus dem Schätzfenster statt
außerhalb; Flächen mit heutiger Schwelle; frühere Prognosen vor dem Urteil in der Nutzlast; Ersatz aus `makro.db` in M+; V4 mit
verschiedenen Schätzstichproben; HYPE mit dem Mittel der Achsenabschnitte; unbestätigter Kalendertag als Termin; Kurslinie im
Prognosebereich (Seiten-Mutation); Hälften in Fällen statt Tagen.

### 13.18 Erwartung neu (Befund 14)

Die Daten sind nicht frisch: log-HAR wurde auf denselben Binance-Kerzen schon geprüft (Regime P0.2/P0.7, Ausblick 12.2), die Bauart
ist in Kenntnis dieser Ergebnisse gewählt. Der Rückblick ist deshalb zum Teil Bestätigung. **V1 offen** (synthetisch eher Münzwurf:
Stärke 23–55 % je nach Zahl der Coins und α), **V2 wahrscheinlich, V3 offen bis wahrscheinlich, V4 unwahrscheinlich.** „Nicht belegt“
beim Niveau ist ein wahrscheinlicher und ehrlicher Ausgang. Die Nachweisgrenze der endgültigen Regel (Block 112, Hälften, α 0,0125
und 0,05) bei gepflanzten Effekten misst der Bau synthetisch; die Zahlen stehen in 13.21, vor dem Urteil.

### 13.19 Abgelehnt oder anders umgesetzt

- Befund 2, „Größe höchstens 6 %“ als Regel für den Blockwechsel: umgesetzt über die Vorzeichen-Nullprobe auf echten Daten mit der
  Grenze für 200 Welten (8,6 %); im Selbsttest dieselbe Grenzformel für die Zahl der Welten (eine feste 6-%-Grenze schlüge bei 200
  Welten auch bei wahren 5 % oft fehl).
- Befund 12, „Prognose damals“ im Fadenkreuz nach dem Urteil: entfällt – der Chart zeigt nur die jüngste Prognose, frühere nie.
- Befund 22, andere Holm-Gewichte: nicht übernommen (Entscheidung 7, Standard gleich).
- Der Bau prüft zusätzlich (Befund aus dem eigenen Selbsttest, vor der Durchsicht): Eine zufällige Vertauschung der Blöcke lässt im
  Mittel einen Block an seiner Stelle – die Selbsttest-Vertauschung ist deshalb ohne festen Block.

### 13.20 Entscheidungen beim Nutzer (Abschnitt 12, erweitert)

1–5 wie in Abschnitt 12 (Standard in Klammern). Dazu:

6. **Strenge der Niveau-Prüfung V1** (Vorschlag: gegen 30-Tage- und Jahresmittel; streng: zusätzlich gegen EWMA – dann ist „nicht
   belegt“ zu erwarten, synthetische Stärke 8–18 %; mild: nur gegen das 30-Tage-Mittel wie im Entwurf – nicht empfohlen, Befund 1).
7. **Holm-Gewichte** (Vorschlag: gleich, je 0,25; Alternative V1 0,3 · V2 0,2 · V3 0,3 · V4 0,2).

Schwelle (1) und Wochen (4) bestimmen alle Tests und müssen vor dem Einspielen feststehen (der Erstlauf rechnet sofort den Rückblick
und danach das Urteil).

### 13.21 Gemessen beim Bau (synthetisch, vor dem Urteil)

Gemessen am 28.10.2026 in der Sandbox (nicht auf dem Pi) mit dem Code, wie er ins Paket 23.90 geht; Zeiten mit `date` bzw. aus der
Dateizeit der Ausgabe. Nichts davon berührt echte Daten; an Nachtrag 13 ändert es nichts.

1. **Größe der Prüfstrecke** (`_groesse` im vollen Selbsttest: 150 synthetische Welten mit Ballung wie 13.3 -- langsames Niveau
   AR 0,998, HAR-Abweichung, t5-Schocks, Messrauschen --, Differenzen um ihr Populationsmittel verschoben, also ohne wahren Vorteil;
   volle Regel mit Block 112, Hälften und Mindestzahl; 499 Ziehungen): „belegt“ in **V1a 6,0 % (9 von 150), V2 4,0 % (6 von 150)**;
   Grenze 5 % + 2,326 · √(0,0475/150) = 9,1 %. Bestanden (Lauf 19:17:37–19:18:29 zusammen mit einer ersten Nachweisgrenze).
2. **Nachweisgrenze** (`hl_volatil.py --nachweisgrenze`, 19:48:53–19:49:20; dieselbe Art Welten, **eine** Münze je Welt, Effekt auf
   die zentrierten Differenzen gepflanzt; Anteil „belegt“ bei α 0,05 und bei α 0,0125 = erster Holm-Schritt bei vier Prüfungen):

   | Prüfung | gepflanzter Vorteil von M | α 0,05 | α 0,0125 |
   |---|---|---:|---:|
   | V1a | 2 % des mittleren QLIKE der 30-Tage-Persistenz | 7,3 % | 2,7 % |
   | V1a | 5 % | 13,3 % | 7,3 % |
   | V1a | 10 % | 33,3 % | 17,3 % |
   | V1a | 20 % | 75,3 % | 58,0 % |
   | V1a | 30 % | 91,3 % | 82,0 % |
   | V2 | Brier 0,002 | 8,7 % | 2,0 % |
   | V2 | Brier 0,005 | 10,0 % | 3,3 % |
   | V2 | Brier 0,01 | 12,7 % | 6,0 % |
   | V2 | Brier 0,02 | 21,3 % | 10,7 % |
   | V2 | Brier 0,05 | 88,7 % | 71,3 % |

   **Lesart:** Sicher erkannt werden nur große Vorteile -- beim Niveau ab etwa 20–30 % des QLIKE der Persistenz, bei den Phasen ein
   Brier-Vorteil um 0,05. Ein Niveau-Vorteil von 10 % wird in einer Münze nur in etwa jedem dritten (α 0,05) bzw. sechsten Fall
   (α 0,0125) belegt. **„Nicht belegt“ heißt deshalb nicht „kein Vorteil“.** Im Urteil laufen vier Münzen gemeinsam (BTC, ETH, ZEC,
   XMR; stark gleichlaufend), deren Stärke ist nicht gemessen. Wie groß die Vorteile auf echten Daten sind, ist unbekannt; die
   Erwartung aus 13.18 bleibt (V1 offen, V2 wahrscheinlich, V3 offen bis wahrscheinlich, V4 unwahrscheinlich).
3. **Produktionsgröße** (Versuchsskript außerhalb des Pakets, 19:48:25–19:48:38: fünf Coins, 2.490 synthetische Tage ab 01.01.2020,
   Rückblick ab dem 28.10.2021 wie im Betrieb, Termine, DVOL-Stunden mit Lücken): **Rückblick 9 s**, `volatil.db` danach **23,4 MB**
   (70.308 Prognosezeilen an 2.006 Ursprungstagen einschließlich des Vorlaufs für σ; hochgerechnet rund 4 MB je Jahr), **Auswertung
   mit allen Prüfungen vor dem Urteil 3 s**, ein Tageslauf 0,5 s. Alle Prüfungen vor dem Urteil grün (Daten 100 % gleich
   `hl_swing.tagesreihen`, Ballung 0,83–0,86, Wochenende 0,69, 5,9 % über dem 90-%-Band, Orakel T 7,1 und 9,9, Vorzeichen-Nullprobe
   für alle Teile Block 112). Positivkontrolle -- M ist in dieser Welt das wahre Modell: alle vier Prüfungen „belegt“ (V1a T 4,6,
   V1b T 6,3, V2 T 6,5, V3 T 4,7, V4 T 3,7). Deckung des 90-%-Bands je Coin und Woche 85,3–89,9 %, darüber 4,0–8,9 % (Soll 90 % und
   5 %; beschreibend). Auf dem Pi nicht gemessen; die Rechnung läuft dort als eigener Prozess mit nice 10.
4. **Browser-Probe der Seite** (echte Seite, Nutzlasten aus dem echten Code ohne Netz; drei Datenstände -- Rückblick fertig ohne
   gespeicherte Zählung, mit Zählung vor dem Urteil, nach dem Urteil mit V1 „nicht belegt“ und in W3 dem Jahresmittel als Hauptwert --
   × 1280 und 390 px × drei Reiter, alle sechs Zeiträume, Fadenkreuz, Abfragen nur bei offenem Abschnitt, Texte im Bild und ohne
   Überlappung): ohne Befund, nachdem beim Bau gefunden und behoben wurde:
   - **Der globale Name `VL` war auf der Seite schon vergeben** (Verlauf der Treiber): das ganze Skript brach beim Laden ab, der
     Abschnitt wäre leer geblieben. Jetzt `VOLA`; dazu prüft `hl_viz.py --selbsttest-volatil` alle Skripte der Seite auf doppelte
     globale Namen (Positivkontrolle mit `VL`). Kein Selbsttest hatte das gesehen -- nur der Browser.
   - Bild 2 px breiter als der Abschnitt (Rahmen); Wochenbeschriftungen überlappten sich, Achsentitel ragten aus dem Bild; „1 σ“ wurde
     durch die Großschreibung der Tabellenköpfe zu „1 Σ“; die Zeitachse war nicht breitenabhängig; die Schwelle konnte außerhalb des
     Bildes liegen; ohne gespeicherte Zählung zeigte die Bilanz Nullen (jetzt „Noch keine Zählung“, Mutation `zaehlung_nullen`).
   - Spalten der Tabelle „Nächste 4 Wochen“ neu geordnet (Wochenmittel, bei V1 nicht belegt 30-Tage- und Jahresmittel, volatile
     Woche, Grundrate, Band, Tages-σ, Termine), damit auf dem Telefon die Hauptwerte vorn stehen; die Tages-σ gehört zum angezeigten
     Hauptwert. Uhrzeiten der Seite in UTC wie die Texte des Servers.
   Seiten-Mutationen: 20 von 20 rot.
5. **Selbsttests und Mutationen:** Selbsttest des Moduls 59 von 59 (voll, mit der Größe aus Punkt 1; 42 s, 19:49:28–19:50:10);
   34 Mutationen, alle rot (neu `zaehlung_nullen`; 300 s, 19:50:22–19:55:22); `hl_viz.py --selbsttest-volatil` 14 von 14
   (19:50:39–19:50:44), 18 Mutationen dagegen alle rot (19:55:22–19:56:36); letzte Browser-Probe ohne Befund (bis 19:57:28).
