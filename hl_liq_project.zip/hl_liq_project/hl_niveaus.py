#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hl_niveaus.py -- U244: Tragen Niveau-Arten mehr als ihren Abstand? Anziehung und Halten über 7, 14 und 28 Tage.

Vorab festgelegt in KONZEPT_Niveaus.md (11.11.2026; Klarstellungen vor dem ersten Lauf in Abschnitt 11). Nur lesend bis auf die eigene
Tabelle au_niveaus in ausblick.db. Kein Signal, keine Empfehlung.

Rückblick: Ursprünge wie S3 des Ausblicks (Montag 00:00 UTC ab 2022). Je Ursprung die Prüfniveaus (Referenz) und die Niveaus aus dem
Kurs -- Swing, runde Zahl, 50- und 200-Tage-Linie, Bestätigungsschwelle des laufenden Beins --, dazu je Niveau sein Spiegel (−d).
Maß A (Anziehung): logit P(erreicht) = a + b·logit(pe) + c·[oben] + γ_Art. Maß B (Halten), auf den erreichten Fällen:
logit P(Schluss jenseits) = a′ + b′·logit(ps ÷ pe) + c′·[oben] + δ_Art. Unsicherheit: stationärer Blockbootstrap über Ursprungswochen.
Ein Urteil nur für 7 Tage, einmal gerechnet (im Rückblick des Ausblicks) und festgehalten. Vorwärtsteil (Orders der Großkonten und
Liquidationscluster von Hyperliquid): bis zum Stichtag nur Zählung.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone

import numpy as np

import hl_ausblick as AU
import hl_chartbild as CB

VERSION_MODUL = "2026-09-23.107"
REGEL = "U244/1"
FESTGELEGT = "11.11.2026"
KLARGESTELLT = "16.11.2026"
DEBUG_NR = 149
DEBUG_RUECKBLICK = 75                                          # „Ausblick: Rückblick und Gewichte jetzt rechnen“ (hl_viz prüft die Nummer)
TAG = 86_400
ARTEN = ("swing", "rund", "ma50", "ma200", "bein")
ART_NAME = {"ref": "Prüfniveaus", "swing": "Swing-Hoch/-Tief", "rund": "runde Zahl", "ma50": "50-Tage-Linie", "ma200": "200-Tage-Linie",
            "bein": "Bein-Schwelle"}
H_PRIM = 7
PE_MIN, PE_MAX = 0.05, 0.95                                    # zulässig: weder fast unmöglich noch fast sicher (Abschnitt 2)
REPS = 2000
ALPHA = 0.05
N_MIN = 100                                                    # Fälle je Art und Maß (Abschnitt 11)
N_MIN_AUSGANG = 20                                             # je Ausgang (eingetreten / nicht eingetreten)
W_MIN = 30                                                     # Ursprungswochen je Art
W_URTEIL = 100                                                 # Ursprungswochen insgesamt, darunter kein Urteil
SPIEGEL_SE = 2.0
# Spiegelprobe (Abschnitte 4 und 11): „abstand“ = die Art muss ihren eigenen Spiegel schlagen (γ − γ_Spiegel in der Richtung von γ und
# über 2 Standardfehlern des Abstands); „streng“ = wie am 11.11.2026 festgelegt (Spiegel außerhalb ±2 Standardfehlern -> nicht belegt).
# Die Regel gibt das Urteil; die jeweils andere Lesart steht im Bericht daneben, wenn sie abweicht. Entscheidung des Nutzers vom
# 16.11.2026 („Verfeinern“), vor dem ersten Lauf auf echten Daten: Auf synthetischen Märkten verwarf die strenge Fassung echte Effekte.
SPIEGEL_REGEL = "abstand"
SPIEGEL_VERMERK = {"streng": "Spiegel auffällig", "abstand": "vom Spiegel nicht zu unterscheiden"}
TABELLE = "CREATE TABLE IF NOT EXISTS au_niveaus (k TEXT PRIMARY KEY, stand INTEGER, v TEXT)"

# Vorwärtsteil (Abschnitt 6): Familien, gespeicherte Art-Kennungen (hl_chartbild.ORDER_ARTEN, liq_long/liq_short), erwartetes Vorzeichen
FAMILIEN = (("F1", "Take-Profits", ("tp_sell", "tp_buy"), "hält"),
            ("F2", "Stops", ("stop_sell", "stop_buy"), "Durchbruch setzt sich fort"),
            ("F3", "Liquidationen", ("liq_long", "liq_short"), "Durchbruch setzt sich fort"),
            ("F4", "Wände", ("limit_buy", "limit_sell"), "hält"))
GROESSTES = ("stop_sell", "stop_buy", "liq_long", "liq_short")   # zwei Einträge einer Art je Anker: größtes und nächstes Cluster
VORWAERTS_AB = int(datetime(2026, 10, 11, tzinfo=timezone.utc).timestamp())
BLICK_WOCHEN = (52, 104)
# Art-Kennungen der Prognose (Tabelle „Ziellevels“) -> Art des Rückblicks oder Familie des Vorwärtsteils
ART_ZU = {"swing_hoch": "swing", "swing_tief": "swing", "rund": "rund", "ma50_": "ma50", "ma200": "ma200", "bein": "bein",
          **{k: f for f, _n, ks, _e in FAMILIEN for k in ks}}

# Nachweisgrenze (Abschnitt 5), gemessen vor dem ersten Lauf auf echten Daten mit --nachweisgrenze (synthetische Märkte des Ausblicks:
# hl_regime._markt mit Schwankungsregimen, 5 Coins, 01.05.2019 bis 10.11.2026; je Stufe 10 Märkte). Punkte = Prozentpunkte.
# gemessen = mittlere rohe Wirkung der Stufe (eingetreten − erwartet); treffer = Märkte von 10, in denen die Regel die eingepflanzte Art im
# eingepflanzten Maß mit dem richtigen Vorzeichen „belegt“; treffer_streng = dasselbe mit der Spiegelprobe wie am 11.11. festgelegt;
# grenze = kleinste gemessene Wirkung mit mindestens 8 von 10. Bei runden Zahlen ließ sich keine Anziehung über rund 4 Punkte einpflanzen.
NACHWEIS = {"stand": "16.11.2026", "maerkte": 10, "regel": "abstand", "stufen": {"A": (4, 8, 12), "B": (5, 10, 15)},
            "gemessen": {"swing": {"A": (4.4, 8.4, 11.6), "B": (-7.4, -11.1, -16.0)}, "rund": {"A": (4.4, None, None), "B": (-5.9, -11.2, -16.3)}},
            "treffer": {"swing": {"A": (10, 10, 10), "B": (9, 10, 10)}, "rund": {"A": (10, None, None), "B": (7, 10, 10)}},
            "treffer_streng": {"swing": {"A": (9, 8, 5), "B": (5, 3, 8)}, "rund": {"A": (8, None, None), "B": (5, 6, 6)}},
            "grenze": {"swing": {"A": 4, "B": 7}, "rund": {"A": 4, "B": 11}}, "fehlalarm": (0, 40)}


def _z(x, nd: int = 1, vz: bool = False) -> str:
    return AU._de(x, nd, vz)


def _tsd(n) -> str:
    return "—" if n is None else f"{int(n):,}".replace(",", ".")


def _sig(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30.0, 30.0)))


# ================================================================================================ Niveaus und Fälle

def bein_schwelle(c, X: float) -> np.ndarray:
    """Bestätigungsschwelle des laufenden Beins je Tag (nach dem Schluss des Tages), Regeln wie hl_zyklus.dc_batch und
    hl_zyklus._dc_stand: im Aufschwung Hoch·(1 − X), im Abschwung Tief·(1 + X); ohne Richtung keine Schwelle. Kausal: Der Wert am Tag t
    hängt nur an den Schlüssen bis t."""
    c = np.asarray(c, dtype=float); n = len(c); out = np.full(n, np.nan)
    u, v = math.log(1 + X), -math.log(1 - X)
    with np.errstate(invalid="ignore", divide="ignore"):
        x = np.where(c > 0, np.log(c), np.nan)
    i0 = next((i for i in range(n) if np.isfinite(x[i])), None)
    if i0 is None:
        return out
    mode = 0; hi = lo = float(x[i0])
    for t in range(i0 + 1, n):
        xt = float(x[t])
        if math.isfinite(xt):
            if mode >= 0 and xt > hi:
                hi = xt
            if mode <= 0 and xt < lo:
                lo = xt
            top = mode >= 0 and xt <= hi - v
            bot = mode <= 0 and xt >= lo + u and not top
            if top:
                mode = -1; lo = xt
            elif bot:
                mode = 1; hi = xt
        if mode == 1:
            out[t] = math.exp(hi) * (1 - X)
        elif mode == -1:
            out[t] = math.exp(lo) * (1 + X)
    return out


def montage(A: dict) -> list:
    """Ursprünge wie S3: Anker Montag 00:00 UTC ab 01.01.2022."""
    tau = A["tau"]
    return [j for j in range(A["n"]) if tau[j] >= AU.OOS_AB and int(tau[j]) % TAG == 0
            and datetime.fromtimestamp(int(tau[j]), timezone.utc).weekday() == 0]


def faelle(V: dict, log=None, coins=None, horizonte=AU.H_ZIEL) -> dict:
    """
    Fälle (Coin, Ursprung, Horizont, Niveau) mit Modellgrößen und Ergebnissen. Arten: ref (Prüfniveaus C·e^{±k·√F}), swing, rund, ma50,
    ma200, bein; je Niveau aus dem Kurs zusätzlich sein Spiegel (sp, Abstand −d). pe, ps aus AU.erreichen, unverändert; ja = Tageshoch
    (-tief) erreicht das Niveau bis Tag h (wie S3); z = Schluss am Tag h jenseits. genau = der Tag vor dem Ursprung steht an seiner
    Stelle der Tagesachse (sonst zählt der Fall nur im Abgleich mit S3).
    """
    log = log or (lambda *a: None)
    rec = {k: [] for k in ("coin", "tau", "h", "art", "sp", "d", "pe", "ps", "ja", "z", "b1", "genau")}
    JT = AU.JE_TAG
    for coin, v in V.items():
        if coins is not None and coin not in coins:
            continue
        B, _ = AU.bibliothek_fuer(coin, V)
        if B is None:
            continue
        A = v["A"]; tau = A["tau"]; lc = np.log(A["C"]); lh = np.log(A["H"]); ll = np.log(A["L"])
        D = v["D"]; s365 = AU._sigma365_anker(A)
        linien = (("ma50", AU._sma(D["C"], 50)), ("ma200", AU._sma(D["C"], 200)),
                  ("bein", bein_schwelle(D["C"], (CB.SCHWELLEN_GOLD if coin == "PAXG" else CB.SCHWELLEN)[0])))
        n_u = 0
        for j in montage(A):
            if j + JT * AU.K_MAX >= A["n"]:
                break
            m = AU.bib_bis(B, tau[j])
            if m.sum() < 200 or not np.all(np.isfinite(v["Fk"][j])):
                continue
            S = AU.szenarien(B, m, v["Fk"][j])
            c0 = float(A["C"][j]); n_u += 1
            i_d = int(np.searchsorted(D["tag"], tau[j] // TAG - 1))
            genau = i_d < D["n"] and int(D["tag"][i_d]) == int(tau[j]) // TAG - 1
            fest = []
            if i_d < D["n"]:
                oben, unten = AU._swing_niveaus(D, i_d)
                fest += [("swing", math.log(x / c0), genau) for x in oben + unten]
            ru, ro, _s = CB.runde(c0)
            fest += [("rund", math.log(x / c0), True) for x in (ru, ro) if np.isfinite(x)]
            if genau:
                for art, reihe in linien:
                    x = float(reihe[i_d])
                    if math.isfinite(x) and x > 0 and x != c0:
                        fest.append((art, math.log(x / c0), True))
            b1 = bool(np.isfinite(s365[j]))
            for h in horizonte:
                hl_max = float(np.nanmax(lh[j + JT: j + JT * h + 1: JT]) - lc[j])
                ll_min = float(np.nanmin(ll[j + JT: j + JT * h + 1: JT]) - lc[j])
                y = float(lc[j + JT * h] - lc[j])
                sq = math.sqrt(v["Fk"][j, h - 1])
                niv = [("ref", sg * k * sq, False, True) for k in AU.TOUCH_K for sg in (1, -1)]
                niv += [(a, d, False, g) for a, d, g in fest] + [(a, -d, True, g) for a, d, g in fest]
                for art, d, sp, g in niv:
                    pe, ps = AU.erreichen(S, d, h)
                    ja = float(hl_max >= d) if d >= 0 else float(ll_min <= d)
                    z = float("nan") if not math.isfinite(y) else (float(y >= d) if d >= 0 else float(y <= d))
                    for k_, val in (("coin", coin), ("tau", int(tau[j])), ("h", h), ("art", art), ("sp", sp), ("d", d), ("pe", pe), ("ps", ps),
                                    ("ja", ja), ("z", z), ("b1", b1), ("genau", g)):
                        rec[k_].append(val)
        log(f"  Niveaus {coin}: {n_u} Montage")
    F = {k: np.array(v_) for k, v_ in rec.items()}
    F["sp"] = F["sp"].astype(bool); F["b1"] = F["b1"].astype(bool); F["genau"] = F["genau"].astype(bool)
    return F


def schluessel(F: dict) -> np.ndarray:
    return np.where(F["sp"], np.char.add("sp_", F["art"].astype("<U8")), F["art"].astype("<U8"))


def pruefsumme(F: dict) -> str:
    h = hashlib.sha256()
    for k in ("coin", "tau", "h", "art", "sp"):
        h.update("|".join(str(x) for x in F[k]).encode())
    for k in ("d", "pe", "ps", "ja", "z"):
        h.update(np.round(np.nan_to_num(F[k].astype(float), nan=-9.0), 10).tobytes())
    return h.hexdigest()[:12]


def abgleich_s3(F: dict, S3: dict) -> dict:
    """Probe 2 auf den Daten des Laufs: Mit den Arten ref, swing, rund, ohne Filter und ohne Spiegel ergibt die neue Rechnung n und
    Brier von S3 (alle Coins des Rückblicks). ohne_b1 = Fälle ohne 365-Tage-Schwankung: S3 zählt sie mit (dort geht B1 mit p = 1 ein)."""
    out = {"ok": True, "h": {}}
    for h in AU.H_ZIEL:
        s = ((S3 or {}).get("h") or {}).get(str(h)) or {}
        m = (F["h"] == h) & ~F["sp"] & np.isin(F["art"], ("ref", "swing", "rund")) & np.isfinite(F["pe"])
        n = int(m.sum()); br = float(np.mean((F["pe"][m] - F["ja"][m]) ** 2)) if n else None
        e = {"n": n, "n_s3": s.get("n"), "brier": br, "brier_s3": s.get("brier_b0"), "ohne_b1": int((m & ~F["b1"]).sum())}
        e["ok"] = bool(s.get("n") == n and (s.get("brier_b0") is None or (br is not None and abs(br - s["brier_b0"]) < 1e-12)))
        out["h"][str(h)] = e; out["ok"] = out["ok"] and e["ok"]
    return out


# ================================================================================================ Maße A und B

def logit_fit(X: np.ndarray, y: np.ndarray, w: np.ndarray | None = None, b: np.ndarray | None = None, it: int = 60) -> tuple:
    """Logistische Regression (Newton/IRLS), auf Wunsch mit Gewichten und Startwert. -> (Koeffizienten, konvergiert)"""
    n, k = X.shape
    b = np.zeros(k) if b is None else np.array(b, dtype=float)
    w = np.ones(n) if w is None else w
    eye = 1e-9 * np.eye(k)
    for _ in range(it):
        mu = _sig(X @ b)
        g = X.T @ (w * (y - mu)); H = (X * (w * (mu * (1 - mu) + 1e-12))[:, None]).T @ X + eye
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            return b, False
        b = b + step
        if np.max(np.abs(step)) < 1e-9:
            return b, True
    return b, False


def p_zweiseitig(g: float, gs: np.ndarray) -> float:
    """Zweiseitiges p aus der zentrierten Bootstrap-Verteilung: Anteil der Wiederholungen, die von der Schätzung mindestens so weit
    abweichen, wie die Schätzung von null entfernt ist; (1 + Zahl) ÷ (1 + Wiederholungen), nie 0."""
    gs = np.asarray(gs, dtype=float)
    return float((1 + np.sum(np.abs(gs - g) >= abs(g))) / (1 + len(gs)))


def auswahl(F: dict, h: int, mass: str, coins) -> tuple:
    """Zulässige Fälle (Abschnitt 2) -> (Maske, Modellgröße p, Ergebnis y). A: 0,05 ≤ pe ≤ 0,95; B: zusätzlich erreicht und
    0,05 ≤ q ≤ 0,95 mit q = ps ÷ pe."""
    m = (F["h"] == h) & np.isin(F["coin"], list(coins)) & F["genau"] & np.isfinite(F["pe"]) & (F["pe"] >= PE_MIN) & (F["pe"] <= PE_MAX)
    if mass == "A":
        return m, F["pe"], F["ja"]
    with np.errstate(invalid="ignore", divide="ignore"):
        q = np.where(F["pe"] > 0, F["ps"] / F["pe"], np.nan)
    m = m & (F["ja"] == 1) & np.isfinite(F["z"]) & np.isfinite(q) & (q >= PE_MIN) & (q <= PE_MAX)
    return m, q, F["z"]


def _roh(p: np.ndarray, y: np.ndarray, oben: np.ndarray) -> dict:
    def s(m):
        n = int(m.sum())
        if not n:
            return {"n": 0}
        return {"n": n, "ja": int(y[m].sum()), "erw": float(p[m].mean()), "quote": float(y[m].mean()), "diff": float(y[m].mean() - p[m].mean())}
    return dict(s(np.ones(len(p), dtype=bool)), oben=s(oben > 0.5), unten=s(oben < 0.5))


def mass_rechnen(F: dict, h: int, mass: str, coins, reps: int = REPS, saat: int = 0) -> dict:
    """
    Ein Maß bei einem Horizont: rohe Zahlen je Art, Regression mit γ je Art (Referenz ref) und je Spiegel, mittlerer Randeffekt,
    Blockbootstrap über Ursprungswochen (mittlere Blocklänge 2h Tage; p zweiseitig aus der zentrierten Verteilung), Hälften.
    reps = 0: nur rohe Zahlen und Punktschätzung.
    """
    m, p_a, y_a = auswahl(F, h, mass, coins)
    out = {"mass": mass, "h": int(h), "n": int(m.sum()), "arten": {}, "ok": False, "reps": int(reps)}
    if not m.any():
        out["grund"] = "keine zulässigen Fälle"; return out
    key = schluessel(F)[m]; p = p_a[m].astype(float); y = y_a[m].astype(float); tau = F["tau"][m]; oben = (F["d"][m] >= 0).astype(float)
    namen = ARTEN
    info = {}
    for k in ("ref",) + namen + tuple("sp_" + a for a in ARTEN):
        mk = key == k
        e = _roh(p[mk], y[mk], oben[mk]); e["wochen"] = int(len(np.unique(tau[mk])))
        n, n1 = e["n"], e.get("ja", 0)
        e["grund"] = (f"zu wenige Fälle ({n}, nötig {N_MIN})" if n < N_MIN else
                      f"ein Ausgang zu selten ({min(n1, n - n1)}, nötig {N_MIN_AUSGANG})" if min(n1, n - n1) < N_MIN_AUSGANG else
                      f"zu wenige Wochen ({e['wochen']}, nötig {W_MIN})" if e["wochen"] < W_MIN else None)
        e["faehig"] = e["grund"] is None
        info[k] = e
    out["ref"] = info["ref"]
    for a in namen:
        sp = info.get("sp_" + a) or {"n": 0, "faehig": False, "grund": "kein Spiegel"}
        out["arten"][a] = dict(info[a], spiegel={k_: sp.get(k_) for k_ in ("n", "erw", "quote", "diff", "faehig", "grund")})
    wochen = np.unique(tau)
    out.update(wochen=int(len(wochen)), von=int(wochen[0]), bis=int(wochen[-1]))
    if not info["ref"]["faehig"]:
        out["grund"] = "Referenz: " + info["ref"]["grund"]; return out
    da = [a for a in namen if info[a]["faehig"]]
    if not da:
        out["grund"] = "keine Art mit genug Fällen"; return out
    cols = da + ["sp_" + a for a in da if info.get("sp_" + a, {}).get("faehig")]
    drin = (key == "ref") | np.isin(key, cols)
    key, p, y, tau, oben = key[drin], p[drin], y[drin], tau[drin], oben[drin]
    X = np.column_stack([np.ones(len(p)), np.log(p / (1 - p)), oben] + [(key == k).astype(float) for k in cols])
    beta, konv = logit_fit(X, y)
    idx = {k: np.nonzero(key == k)[0] for k in cols}

    def ame(b, k, w=None):
        ii = idx[k]; eta = X[ii] @ b
        d = _sig(eta) - _sig(eta - b[3 + cols.index(k)])
        if w is None:
            return float(d.mean())
        ww = w[ii]
        return float(np.sum(ww * d) / ww.sum()) if ww.sum() > 0 else float("nan")

    out.update(ok=True, konvergiert=bool(konv), n_modell=int(len(y)), a=float(beta[0]), b=float(beta[1]), c=float(beta[2]),
               block_wochen=max(1.0, 2.0 * h / 7.0))
    wochen = np.unique(tau); W = len(wochen); wi = np.searchsorted(wochen, tau)
    G = AM = None; nk = 0
    if reps:
        IDX = AU.stat_idx(W, out["block_wochen"], reps, saat)
        G = np.full((reps, len(cols)), np.nan); AM = np.full((reps, len(cols)), np.nan)
        for r in range(reps):
            w = np.bincount(IDX[r], minlength=W)[wi].astype(float)
            nz = w > 0
            b_r, ok_r = logit_fit(X[nz], y[nz], w[nz], beta, it=30)
            nk += 0 if ok_r else 1
            G[r] = b_r[3:]
            for c_i, k in enumerate(cols):
                AM[r, c_i] = ame(b_r, k, w)
        out["nicht_konvergiert"] = int(nk)
    grenze = wochen[W // 2]
    halb = []
    for teil in (tau < grenze, tau >= grenze):
        okc = [k for k in cols if (teil & (key == k)).sum() >= N_MIN_AUSGANG and 0 < y[teil & (key == k)].sum() < (teil & (key == k)).sum()]
        nicht = ~np.isin(key, [k for k in cols if k not in okc]) & teil
        Xh = np.column_stack([X[nicht][:, :3]] + [X[nicht][:, 3 + cols.index(k)] for k in okc])
        bh, _ = logit_fit(Xh, y[nicht]) if nicht.sum() > 10 and 0 < y[nicht].sum() < nicht.sum() else (None, False)
        halb.append({k: (float(bh[3 + okc.index(k)]) if bh is not None and k in okc else None) for k in cols})
    out["haelfte_ab"] = int(grenze)
    for c_i, k in enumerate(cols):
        g = float(beta[3 + c_i])
        e = {"gamma": g, "ame": ame(beta, k) * 100.0, "haelften": [halb[0][k], halb[1][k]]}
        e["haelften_gleich"] = bool(g != 0 and all(x is not None and x != 0 and (x > 0) == (g > 0) for x in e["haelften"]))
        if reps:
            gs = G[:, c_i]
            e.update(se=float(np.std(gs, ddof=1)), p=p_zweiseitig(g, gs),
                     ame_lo=float(np.nanquantile(AM[:, c_i], 0.025)) * 100.0, ame_hi=float(np.nanquantile(AM[:, c_i], 0.975)) * 100.0)
        if k.startswith("sp_"):
            out["arten"][k[3:]]["spiegel"].update({k_: e.get(k_) for k_ in ("gamma", "se", "ame")})
        else:
            if reps and "sp_" + k in cols:                      # Standardfehler des Abstands Art − Spiegel (beschreibend)
                e["sp_diff_se"] = float(np.std(G[:, c_i] - G[:, cols.index("sp_" + k)], ddof=1))
            out["arten"][k].update(e)
    return out


def spiegel_stand(e: dict, regel: str | None = None) -> str:
    """Stand der Spiegelprobe einer Art: „fehlt“, „auffällig“ (die Probe spricht gegen die Art) oder „unauffällig“.
    streng: |γ_Spiegel| > 2 Standardfehler. abstand: γ − γ_Spiegel liegt nicht in der Richtung von γ über 2 Standardfehlern des Abstands."""
    regel = regel or SPIEGEL_REGEL
    sp = e.get("spiegel") or {}
    if sp.get("gamma") is None or sp.get("se") is None:
        return "fehlt"
    if regel == "streng":
        return "auffällig" if abs(sp["gamma"]) > SPIEGEL_SE * sp["se"] else "unauffällig"
    if not e.get("sp_diff_se") or e["sp_diff_se"] < 1e-12:      # kein Abstand messbar (Spiegel ohne eigene Streuung)
        return "fehlt"
    d = e["gamma"] - sp["gamma"]
    return "unauffällig" if abs(d) > SPIEGEL_SE * e["sp_diff_se"] and (d > 0) == (e["gamma"] > 0) else "auffällig"


def urteil(p_roh, p_holm, haelften_gleich: bool, spiegel: str, vermerk: str = "Spiegel auffällig") -> tuple:
    """Abschnitt 4: belegt = p Holm < 0,05 und dasselbe Vorzeichen in beiden Hälften; Hinweis = p roh < 0,05; sonst nicht belegt.
    Spricht die Spiegelprobe gegen die Art, wird aus „belegt“ oder „Hinweis“ ein „nicht belegt“ mit Vermerk. Ohne Spiegelprobe kein
    „belegt“ (Abschnitt 11)."""
    if p_holm is not None and p_holm < ALPHA and haelften_gleich and spiegel != "fehlt":
        u, v = "belegt", ""
    elif p_roh is not None and p_roh < ALPHA:
        gr = []
        if p_holm is not None and p_holm < ALPHA and not haelften_gleich:
            gr.append("Hälften uneins")
        if spiegel == "fehlt":
            gr.append("ohne Spiegelprobe")
        u, v = "Hinweis", ", ".join(gr)
    else:
        return "nicht belegt", ""
    return ("nicht belegt", vermerk) if spiegel == "auffällig" else (u, v)


def urteile_setzen(MA: dict, MB: dict) -> int:
    """Familie = alle urteilsfähigen Arten × beide Maße bei 7 Tagen (höchstens 10 Tests), Holm."""
    tests = [(M, a) for M in (MA, MB) for a in ARTEN if ((M.get("arten") or {}).get(a) or {}).get("p") is not None]
    ph = AU.holm([M["arten"][a]["p"] for M, a in tests]) if tests else []
    for (M, a), q in zip(tests, ph):
        e = M["arten"][a]; e["p_holm"] = float(q)
        e["urteil"], e["vermerk"] = urteil(e["p"], q, e["haelften_gleich"], spiegel_stand(e), SPIEGEL_VERMERK[SPIEGEL_REGEL])
        andere = "abstand" if SPIEGEL_REGEL == "streng" else "streng"
        e["urteil_andere"], e["vermerk_andere"] = urteil(e["p"], q, e["haelften_gleich"], spiegel_stand(e, andere), SPIEGEL_VERMERK[andere])
        e["spiegel_regel"] = SPIEGEL_REGEL
    return len(tests)


def rechnen(V: dict, S3: dict | None, log=None, jetzt: int | None = None, reps: int = REPS, F: dict | None = None) -> dict:
    """Der Rückblick mit Urteil: Fälle, Abgleich mit S3, Maße A und B je Horizont (Urteil nur 7 Tage), PAXG roh daneben."""
    log = log or (lambda *a: None)
    t0 = time.time(); jetzt = int(jetzt or time.time())
    F = faelle(V, log) if F is None else F
    coins = [c for c in AU.KRYPTO if c in set(F["coin"])]
    out = {"regel": REGEL, "version": VERSION_MODUL, "stand": jetzt, "coins": coins, "eingabe": pruefsumme(F), "reps": int(reps),
           "abgleich": abgleich_s3(F, S3) if S3 is not None else {"ok": False, "fehlt": True},
           "ohne_vortag": int((~F["genau"] & (F["h"] == H_PRIM) & ~F["sp"]).sum()), "h": {}}
    for h in AU.H_ZIEL:
        MA = mass_rechnen(F, h, "A", coins, reps, saat=1000 + h)
        MB = mass_rechnen(F, h, "B", coins, reps, saat=2000 + h)
        if h == H_PRIM:
            out["tests"] = urteile_setzen(MA, MB)
        out["h"][str(h)] = {"A": MA, "B": MB}
        log(f"  Niveaus h={h}: A n {MA['n']}, B n {MB['n']}, {time.time() - t0:.0f} s")
    if "PAXG" in set(F["coin"]):
        out["paxg"] = {str(h): {ms: mass_rechnen(F, h, ms, ["PAXG"], 0) for ms in ("A", "B")} for h in AU.H_ZIEL}
    P = out["h"][str(H_PRIM)]
    gruende = []
    if not out["abgleich"].get("ok"):
        gruende.append("Abgleich mit S3 misslungen" if S3 is not None else "ohne S3 kein Abgleich")
    if not P["A"].get("ok"):
        gruende.append("Maß A nicht rechenbar: " + str(P["A"].get("grund")))
    elif P["A"].get("wochen", 0) < W_URTEIL:
        gruende.append(f"zu wenige Ursprungswochen ({P['A'].get('wochen')}, nötig {W_URTEIL})")
    out["gesperrt"] = "; ".join(gruende) or None
    out["dauer"] = time.time() - t0
    return AU._ohne_nan(out)


def zaehlung(F: dict) -> dict:
    """Rohe Zahlen je Art und Horizont auf dem heutigen Stand (ohne Regression, ohne p): n, erwartet, eingetreten."""
    coins = [c for c in AU.KRYPTO if c in set(F["coin"])]
    out = {}
    for h in AU.H_ZIEL:
        out[str(h)] = {}
        for ms in ("A", "B"):
            M = mass_rechnen(F, h, ms, coins, 0)
            out[str(h)][ms] = {"n": M["n"], "wochen": M.get("wochen"), "bis": M.get("bis"), "ref": {k: M.get("ref", {}).get(k) for k in ("n", "erw", "quote", "diff")},
                               "arten": {a: {k: e.get(k) for k in ("n", "erw", "quote", "diff")} for a, e in (M.get("arten") or {}).items()}}
    return AU._ohne_nan(out)


# ================================================================================================ Vorwärtsteil: Zählung

def vorwaerts(db: str, jetzt: int | None = None) -> dict:
    """
    Zählung je Familie aus au_vorwaerts (Abschnitt 6): Anker 00:00 UTC seit 11.10.2026, ausgewertete Zeilen; Krypto-Coins gepoolt,
    PAXG daneben. A: n, erwartet (Summe pe), eingetreten (erreicht); B auf den erreichten: n, erwartet (Summe ps ÷ pe), eingetreten
    (Schluss jenseits, aus dem gespeicherten y). Stops und Liquidationen: nur das größte Cluster -- stehen je Anker zwei Niveaus einer
    Art, ist das fernere das größte (das „nächste“ wird nur gespeichert, wenn es näher liegt).
    """
    leer = lambda: {"n": 0, "erwartet": 0.0, "eingetreten": 0}
    out = {"ab": VORWAERTS_AB, "ok": False, "h": {}, "blick": list(BLICK_WOCHEN)}
    con = AU.lesen(AU.ausblick_pfad(db))
    if con is None:
        out["grund"] = "ausblick.db fehlt"; return out
    try:
        rows = con.execute("SELECT coin, anker, h, p0, niveaus, ergebnis FROM au_vorwaerts WHERE ausgewertet=1 AND anker >= ? AND anker % ? = 0 "
                           "ORDER BY anker", (VORWAERTS_AB, TAG)).fetchall()
    except sqlite3.Error as e:
        out["grund"] = f"au_vorwaerts nicht lesbar ({type(e).__name__})"; return out
    finally:
        con.close()
    out["ok"] = True
    for coin, anker, h, p0, niv, erg in rows:
        try:
            L = [x for x in json.loads(niv or "[]") if x and x[0] != "pruef"]; E = json.loads(erg or "{}")
        except ValueError:
            continue
        R = E.get("niveaus") or []; y = E.get("y")
        H = out["h"].setdefault(str(h), {"krypto": {f: {"A": leer(), "B": leer()} for f, *_ in FAMILIEN},
                                         "paxg": {f: {"A": leer(), "B": leer()} for f, *_ in FAMILIEN}, "wochen": set(), "unpassend": 0})
        if len(L) != len(R) or any(a[0] != b[0] for a, b in zip(L, R)) or not p0 or y is None:
            H["unpassend"] += 1; continue
        if coin in AU.KRYPTO:
            H["wochen"].add((int(anker) // TAG + 3) // 7)
        gruppe = H["krypto" if coin in AU.KRYPTO else "paxg"]
        for fam, _name, arten, _erw in FAMILIEN:
            for art in arten:
                ii = [i for i, x in enumerate(L) if x[0] == art and x[1]]
                if art in GROESSTES and len(ii) > 1:
                    ii = [max(ii, key=lambda i: abs(math.log(L[i][1] / p0)))]
                for i in ii:
                    pe, ps = L[i][2], L[i][3]
                    if pe is None or not PE_MIN <= pe <= PE_MAX:
                        continue
                    d = math.log(L[i][1] / p0); getr = bool(R[i][2])
                    a = gruppe[fam]["A"]; a["n"] += 1; a["erwartet"] += float(pe); a["eingetreten"] += int(getr)
                    if not getr or ps is None:
                        continue
                    q = float(ps) / float(pe)
                    if PE_MIN <= q <= PE_MAX:
                        b = gruppe[fam]["B"]; b["n"] += 1; b["erwartet"] += q; b["eingetreten"] += int(y >= d if d >= 0 else y <= d)
    for H in out["h"].values():
        H["wochen"] = len(H["wochen"])
    return out


# ================================================================================================ Speicher: ein Urteil, nicht viele

def stand_lesen(db: str) -> dict:
    """-> {"urteil": …, "zaehlung": …, "versuch": …} aus au_niveaus (nur lesen; ohne Tabelle leer)."""
    con = AU.lesen(AU.ausblick_pfad(db))
    if con is None:
        return {}
    try:
        return {k: dict(json.loads(v), gespeichert=int(st)) for k, st, v in con.execute("SELECT k, stand, v FROM au_niveaus")}
    except (sqlite3.Error, ValueError):
        return {}
    finally:
        con.close()


def _setzen(con, k: str, stand: int, wert: dict) -> None:
    AU._tx(con, lambda: con.execute("INSERT OR REPLACE INTO au_niveaus VALUES (?,?,?)", (k, int(stand), json.dumps(AU._ohne_nan(wert)))))


def im_rueckblick(db: str, V: dict, S3: dict, jetzt: int | None = None, log=None, reps: int = REPS, F: dict | None = None) -> dict:
    """
    Aufruf am Ende des wöchentlichen Rückblicks (derselbe Fächer, dieselben Daten wie S3). Gibt es für die Fassung der Regel noch kein
    Urteil, wird es jetzt gerechnet und festgehalten -- danach nie still neu. Jede Woche: die rohe Zählung je Art und der Vorwärtsteil.
    """
    log = log or (lambda *a: None)
    jetzt = int(jetzt or time.time()); t0 = time.time()
    con = AU.verbinden(AU.ausblick_pfad(db))
    try:
        con.execute(TABELLE)
        alt = {k: json.loads(v) for k, v in con.execute("SELECT k, v FROM au_niveaus")}
        F = faelle(V, log) if F is None else F
        out = {"urteil_neu": False}
        U = alt.get("urteil")
        if U is None or U.get("regel") != REGEL:
            E = rechnen(V, S3, log, jetzt, reps, F=F)
            if E.get("gesperrt"):
                _setzen(con, "versuch", jetzt, {"regel": REGEL, "stand": jetzt, "grund": E["gesperrt"], "abgleich": E.get("abgleich")})
                log(f"  Niveaus (U244): kein Urteil -- {E['gesperrt']}")
            else:
                if U is not None:
                    _setzen(con, "urteil_alt_" + str(U.get("regel")).replace("/", "_"), int(U.get("stand") or 0), U)
                _setzen(con, "urteil", jetzt, E)
                AU._tx(con, lambda: con.execute("DELETE FROM au_niveaus WHERE k='versuch'"))
                out["urteil_neu"] = True
                log(f"  Niveaus (U244): Urteil gerechnet und festgehalten ({E.get('tests')} Tests, {E['dauer']:.0f} s)")
        Z = {"stand": jetzt, "regel": REGEL, "abgleich": abgleich_s3(F, S3), "eingabe": pruefsumme(F), "h": zaehlung(F),
             "vorwaerts": vorwaerts(db, jetzt)}
        _setzen(con, "zaehlung", jetzt, Z)
    finally:
        con.close()
    out["dauer"] = time.time() - t0
    log(f"  Niveaus (U244): Zählung je Art und Vorwärtsteil in {out['dauer']:.0f} s")
    return out


# ================================================================================================ Texte: Bericht (Debug 149), Kurzform

SATZ_OFFEN = "Niveau-Arten noch nicht geprüft (U244) -- das Urteil folgt mit dem nächsten Rückblick."
SATZ_OHNE = "Niveau-Arten ohne belegte Wirkung — die Zahl folgt allein aus dem Abstand."
MASS_NAME = {"A": "Anziehung", "B": "Halten"}


def grenze_text(art: str, mass: str, M: dict | None = None) -> str:
    """Nachweisgrenze neben „nicht belegt“: gemessen für swing und rund; für die übrigen Arten nach dem Verhältnis der Standardfehler
    überschlagen (Bezug rund, sonst swing)."""
    G = NACHWEIS.get("grenze") or {}
    g = (G.get(art) or {}).get(mass)
    if g is not None:
        return f"Nachweisgrenze {g} Punkte" if isinstance(g, (int, float)) else f"Nachweisgrenze {g}"
    e = ((M or {}).get("arten") or {})
    for bezug in ("rund", "swing"):
        b = (G.get(bezug) or {}).get(mass)
        if isinstance(b, (int, float)) and (e.get(art) or {}).get("se") and (e.get(bezug) or {}).get("se"):
            return f"Nachweisgrenze überschlagen rund {_z(b * e[art]['se'] / e[bezug]['se'], 0)} Punkte"
    return "Nachweisgrenze nicht gemessen"


def _art_zeile(a: str, e: dict, mass: str, M: dict, mit_urteil: bool) -> str:
    if not e.get("n"):
        return f"    {a:<6} keine zulässigen Fälle"
    z = (f"    {a:<6} n {_tsd(e['n'])} · erwartet {_z(e['erw'] * 100)} % · eingetreten {_z(e['quote'] * 100)} % · Differenz "
         f"{_z(e['diff'] * 100, 1, True)} Punkte")
    if e.get("gamma") is None:
        return z + f" · kein Test: {e.get('grund') or 'nicht im Modell'}"
    z += f" · Randeffekt {_z(e['ame'], 1, True)} Punkte"
    if e.get("ame_lo") is not None:
        z += f" [{_z(e['ame_lo'], 1, True)}; {_z(e['ame_hi'], 1, True)}] · p {_z(e['p'], 3)}"
    if not mit_urteil:
        return z
    hf = e.get("haelften") or [None, None]
    sp = e.get("spiegel") or {}
    stand_sp = spiegel_stand(e, e.get("spiegel_regel"))
    sp_txt = ("ohne Spiegel" if sp.get("ame") is None else f"Spiegel {_z(sp['ame'], 1, True)} Punkte"
              + ((" (geschlagen)" if stand_sp == "unauffällig" else "") if e.get("spiegel_regel") == "abstand" else f" ({stand_sp})"))
    z += (f", nach Holm {_z(e.get('p_holm'), 3)} · Hälften {_z(hf[0], 2, True)} / {_z(hf[1], 2, True)} · {sp_txt}"
          + f" · {e.get('urteil')}" + (f" ({e['vermerk']})" if e.get("vermerk") else ""))
    if e.get("urteil") != "belegt":
        z += f" · {grenze_text(a, mass, M)}"
    if e.get("urteil_andere") and e["urteil_andere"] != e.get("urteil"):
        z += (f" · mit der {'Spiegelprobe wie am 11.11. festgelegt' if e.get('spiegel_regel') == 'abstand' else 'verfeinerten Spiegelprobe'}: "
              f"{e['urteil_andere']}" + (f" ({e['vermerk_andere']})" if e.get("vermerk_andere") else ""))
    return z


def _mass_block(M: dict, mit_urteil: bool) -> list:
    name = f"{M['mass']} {MASS_NAME[M['mass']]}, {M['h']} Tage" + (" (Urteil)" if mit_urteil else " (beschreibend, ohne Urteil)")
    if not M.get("n"):
        return [f"  {name}: keine zulässigen Fälle"]
    r = M.get("ref") or {}
    Z = [f"  {name} -- {_tsd(M['n'])} Fälle in {M.get('wochen')} Wochen; Referenz (Prüfniveaus): n {_tsd(r.get('n'))}, erwartet "
         f"{_z((r.get('erw') or 0) * 100)} %, eingetreten {_z((r.get('quote') or 0) * 100)} %"
         + (f"; allgemeine Terme a {_z(M.get('a'), 2, True)}, b {_z(M.get('b'), 2)}, c {_z(M.get('c'), 2, True)}" if M.get("ok") else "")]
    if not M.get("ok"):
        Z.append(f"    nicht rechenbar: {M.get('grund')}")
    for a in ARTEN:
        Z.append(_art_zeile(a, (M.get("arten") or {}).get(a) or {}, M["mass"], M, mit_urteil and M.get("ok")))
    return Z


def _seiten_zeile(M: dict) -> str:
    T = []
    for a in ARTEN:
        e = (M.get("arten") or {}).get(a) or {}
        t = [f"{s} n {_tsd(e[s]['n'])}: {_z(e[s]['quote'] * 100, 0)} % bei {_z(e[s]['erw'] * 100, 0)} %" for s in ("oben", "unten") if (e.get(s) or {}).get("n")]
        if t:
            T.append(f"{a} " + ", ".join(t))
    return "    je Seite (eingetreten bei erwartet): " + " · ".join(T) if T else ""


def vorwaerts_zeilen(VW: dict | None) -> list:
    if not VW or not VW.get("ok"):
        return [f"  keine Zählung: {(VW or {}).get('grund') or 'noch kein Stand'}"]
    H = (VW.get("h") or {}).get(str(H_PRIM))
    if not H:
        return [f"  noch keine ausgewerteten Anker 00:00 UTC seit {AU._dt(VW['ab'])}"]
    Z = [f"  Anker 00:00 UTC seit {AU._dt(VW['ab'])}, 7 Tage, Krypto-Coins gepoolt: {H['wochen']} Wochen mit Daten"
         + (f"; {H['unpassend']} Zeilen nicht zuordenbar" if H.get("unpassend") else "")]
    for f, name, _arten, erw in FAMILIEN:
        a, b = H["krypto"][f]["A"], H["krypto"][f]["B"]
        Z.append(f"    {f} {name:<14} erreicht {a['eingetreten']} von {a['n']} bei {_z(a['erwartet'], 1)} erwartet"
                 + (f" · danach Schluss jenseits {b['eingetreten']} von {b['n']} bei {_z(b['erwartet'], 1)} erwartet" if b["n"] else "")
                 + f" · Erwartung vorab: {erw}")
    Z.append(f"  noch kein Urteil ({H['wochen']} Wochen von {BLICK_WOCHEN[0]}). Erster Blick nach {BLICK_WOCHEN[0]} Wochen (belegt nur bei p Holm "
             f"< 0,01), endgültig nach {BLICK_WOCHEN[1]} Wochen (p Holm < 0,04). Bis dahin ohne p-Werte.")
    px = [f"{f} {H['paxg'][f]['A']['eingetreten']} von {H['paxg'][f]['A']['n']}" for f, *_ in FAMILIEN if H["paxg"][f]["A"]["n"]]
    if px:
        Z.append("  PAXG daneben (erreicht): " + " · ".join(px))
    return Z


def nachweis_zeilen() -> list:
    N = NACHWEIS
    if not N.get("stand"):
        return ["  noch nicht gemessen"]
    Z = [f"  Gemessen am {N['stand']} vor dem ersten Lauf auf echten Daten: synthetische Märkte des Ausblicks (Schwankungsregime, 5 Coins, "
         f"Montage 2022 bis 2026) mit eingepflanztem Effekt, je Stufe {N.get('maerkte', 10)} Märkte; „gefunden“ = die Regel sagt „belegt“ mit "
         "dem richtigen Vorzeichen. In Klammern: mit der Spiegelprobe wie am 11.11. festgelegt."]
    for art, T in (N.get("treffer") or {}).items():
        for ms in ("A", "B"):
            teile = [f"{_z(g, 1, True)} Punkte: {k} von {N.get('maerkte', 10)} ({ks})" for g, k, ks in
                     zip(N["gemessen"][art][ms], T[ms], N["treffer_streng"][art][ms]) if k is not None]
            Z.append(f"    {art}, {ms} {MASS_NAME[ms]}: " + " · ".join(teile) + f" -> {grenze_text(art, ms)}")
    fa = N.get("fehlalarm")
    if fa:
        Z.append(f"    Fehlalarm ohne Effekt: in {fa[0]} von {fa[1]} Märkten sagte irgendein Test der Familie „belegt“ (erlaubt 5 %; in beiden "
                 "Fassungen der Spiegelprobe).")
    Z.append("    Eine Anziehung ließ sich bei runden Zahlen nur bis rund 4 Punkte einpflanzen (die beiden Niveaus liegen auf entgegengesetzten "
             "Seiten des Kurses); bei Swing-Niveaus für 8 und 12 Punkte nur mit einer Zone von drei Tagesschwankungen.")
    Z.append("    Für ma50, ma200 und bein ist die Grenze nicht eigens gemessen; neben „nicht belegt“ steht ein Überschlag aus dem Verhältnis "
             "der Standardfehler.")
    return Z


def satz(U: dict | None) -> str:
    """Der Satz der Lesart (Abschnitt 7)."""
    if not U:
        return SATZ_OFFEN
    T = []
    for ms in ("A", "B"):
        for a, e in (((U.get("h") or {}).get(str(H_PRIM)) or {}).get(ms, {}).get("arten") or {}).items():
            if e.get("urteil") == "belegt":
                wie = (("häufiger" if e["gamma"] > 0 else "seltener") + " erreicht, als der Abstand erwarten lässt") if ms == "A" else \
                      ("nach dem Erreichen seltener überschritten (hält)" if e["gamma"] < 0 else "nach dem Erreichen häufiger überschritten")
                T.append(f"{ART_NAME[a]} wird {wie} ({_z(e['ame'], 1, True)} Punkte bei 7 Tagen)")
    if not T:
        return SATZ_OHNE
    return "Niveau-Art mit belegter Wirkung: " + "; ".join(T) + f" -- Art belegt seit {AU._dt(U.get('stand'))}."


def kurz(db: str) -> dict:
    """Für die Tabelle „Ziellevels“ des Ausblicks: je Art-Kennung der Prognose der Text der Spalte „Bilanz der Art“, dazu der Satz der
    Lesart und bei einer belegten Anziehung γ zum Nachstellen der Erreich-Wahrscheinlichkeit bei 7 Tagen."""
    S = stand_lesen(db)
    U, Zl = S.get("urteil"), S.get("zaehlung") or {}
    out = {"da": bool(U), "regel": REGEL, "debug": DEBUG_NR, "stand": (U or {}).get("stand"), "arten": {}, "belegt": {}, "satz": satz(U)}
    P = ((U or {}).get("h") or {}).get(str(H_PRIM)) or {}
    texte = {}
    for a in ARTEN:
        eA = ((P.get("A") or {}).get("arten") or {}).get(a) or {}
        eB = ((P.get("B") or {}).get("arten") or {}).get(a) or {}
        if not U:
            texte[a] = f"{a} · noch kein Urteil (folgt mit dem nächsten Rückblick)"
        elif not eA.get("n"):
            texte[a] = f"{a} · keine zulässigen Fälle"
        else:
            t = f"{a} · erreicht {_z(eA['quote'] * 100, 0)} % bei {_z(eA['erw'] * 100, 0)} % erwartet (n {_tsd(eA['n'])})"
            t += f" · Anziehung {eA['urteil']}" if eA.get("urteil") else f" · Anziehung ohne Test ({eA.get('grund') or 'nicht im Modell'})"
            t += f" · Halten {eB['urteil']}" if eB.get("urteil") else " · Halten ohne Test"
            if "belegt" in (eA.get("urteil"), eB.get("urteil")):
                t += f" · Art belegt seit {AU._dt(U.get('stand'))}"
            texte[a] = t
            if eA.get("urteil") == "belegt":
                out["belegt"][a] = {"gamma": eA["gamma"], "seit": U.get("stand")}
    VW = Zl.get("vorwaerts") or {}
    H = (VW.get("h") or {}).get(str(H_PRIM)) or {}
    for f, name, _arten, _erw in FAMILIEN:
        a = ((H.get("krypto") or {}).get(f) or {}).get("A") or {}
        texte[f] = (f"{name} · erreicht {a['eingetreten']} von {a['n']} bei {_z(a['erwartet'], 1)} erwartet · noch kein Urteil "
                    f"({H.get('wochen', 0)} Wochen von {BLICK_WOCHEN[0]})") if a.get("n") else f"{name} · noch keine Zählung"
    out["arten"] = {k: texte[v] for k, v in ART_ZU.items()}
    out["belegt"] = {k: out["belegt"][v] for k, v in ART_ZU.items() if v in out["belegt"]}
    return out


def bericht_text(db: str, jetzt: int | None = None) -> str:
    jetzt = int(jetzt or time.time())
    S = stand_lesen(db)
    U, Zl, VS = S.get("urteil"), S.get("zaehlung"), S.get("versuch")
    Z = [f"★ Niveaus: Bilanz je Art (U244) -- Debug {DEBUG_NR}",
         f"Stand {AU._dtz(jetzt)} · Modul {VERSION_MODUL} · Regel {REGEL}, vorab festgelegt am {FESTGELEGT} (KONZEPT_Niveaus.md; Klarstellungen "
         f"vom {KLARGESTELLT} in Abschnitt 11)",
         "Frage: Wird ein Swing-Niveau, eine runde Zahl, eine Durchschnittslinie oder die Bein-Schwelle öfter (oder seltener) erreicht, als "
         "ihr Abstand erwarten lässt (A Anziehung)? Und schließt der Kurs nach dem Erreichen öfter (oder seltener) jenseits davon (B Halten)?",
         "Vergleich: die Prüfniveaus des Ausblicks -- beliebige Kurse mit derselben Modell-Wahrscheinlichkeit. Kein Signal, keine Empfehlung.",
         "", "RÜCKBLICK (Montage seit 2022; BTC, ETH, HYPE, ZEC, XMR gepoolt)"]
    if not U:
        Z.append("Noch kein Urteil. Es wird einmal gerechnet und dann festgehalten: im Rückblick des Ausblicks (sonntags) -- oder sofort mit "
                 f"Debug {DEBUG_RUECKBLICK} „Ausblick: Rückblick und Gewichte jetzt rechnen“ (dauert einige Minuten), danach Debug {DEBUG_NR}.")
        if VS:
            ab = VS.get("abgleich") or {}
            Z.append(f"Letzter Versuch am {AU._dtz(VS.get('stand'))}: kein Urteil -- {VS.get('grund')}."
                     + " Abgleich mit S3: " + " · ".join(f"{h} T n {_tsd(e.get('n'))} gegen {_tsd(e.get('n_s3'))}" for h, e in (ab.get("h") or {}).items()))
    else:
        if U.get("regel") != REGEL:
            Z.append(f"Achtung: gespeichertes Urteil der Fassung {U.get('regel')}; die heutige Fassung {REGEL} rechnet beim nächsten Rückblick neu.")
        P = U["h"][str(H_PRIM)]; ab = U.get("abgleich") or {}
        Z.append(f"Urteil vom {AU._dtz(U.get('stand'))} -- einmal gerechnet, wird nicht neu gerechnet (Fassung {U.get('regel')}, Paket "
                 f"{U.get('version')}, {U.get('reps')} Wiederholungen, {U.get('tests')} Tests in der Familie, Prüfsumme der Eingabe {U.get('eingabe')}).")
        Z.append(f"  Daten: Ursprünge {AU._dt(P['A'].get('von'))} bis {AU._dt(P['A'].get('bis'))}, Coins {', '.join(U.get('coins') or [])}; Abgleich mit "
                 "S3 (Arten ref, swing, rund ohne Filter): bestanden -- "
                 + " · ".join(f"{h} T n {_tsd(e.get('n'))}" for h, e in (ab.get("h") or {}).items())
                 + (f"; {U['ohne_vortag']} Fälle ohne genauen Vortag ausgeschlossen" if U.get("ohne_vortag") else ""))
        ob = sum(int(e.get("ohne_b1") or 0) for e in (ab.get("h") or {}).values())
        if ob:
            Z.append(f"  Am Rand: {_tsd(ob)} Fälle von S3 haben keine 365-Tage-Schwankung; S3 zählt sie mit (im Vergleichsmaß B1 mit p = 1).")
        for ms in ("A", "B"):
            Z += _mass_block(P[ms], True)
            sz = _seiten_zeile(P[ms])
            if sz:
                Z.append(sz)
        Z.append("  Lesehilfe: Randeffekt = so viele Prozentpunkte öfter (+) oder seltener (−) als ein beliebiger Kurs mit derselben "
                 "Modell-Wahrscheinlichkeit, in Klammern die Spanne für 95 %; bei B heißt „−“: Das Niveau hält. Hälften = der Beitrag der Art in "
                 "der ersten und der zweiten Hälfte der Wochen (Logit-Skala; es zählt das Vorzeichen). Spiegel = dieselbe Rechnung für den "
                 "Kurs im selben Abstand auf der anderen Seite. „Belegt“ nur mit p nach Holm unter 0,05, gleichem Vorzeichen in beiden Hälften "
                 "und wenn die Art ihren eigenen Spiegel schlägt (Abstand über zwei Standardfehlern, in ihrer Richtung); „Hinweis“ bei p "
                 "unter 0,05.")
        for h in (14, 28):
            for ms in ("A", "B"):
                M = (U["h"].get(str(h)) or {}).get(ms)
                if M:
                    Z += _mass_block(M, False)
        if U.get("paxg"):
            Z.append("  PAXG (getrennt, nur beschreibend; roh, 7 Tage):")
            for ms in ("A", "B"):
                M = U["paxg"][str(H_PRIM)][ms]
                t = [f"{a} n {e['n']}: {_z(e['quote'] * 100, 0)} % bei {_z(e['erw'] * 100, 0)} %" for a, e in (M.get("arten") or {}).items() if e.get("n")]
                Z.append(f"    {ms} {MASS_NAME[ms]}: " + (" · ".join(t) if t else "keine zulässigen Fälle"))
    if Zl:
        Z += ["", f"ZÄHLUNG auf dem Stand vom {AU._dtz(Zl.get('stand'))} (roh, ohne Urteil; 7 Tage)"]
        ab = Zl.get("abgleich") or {}
        if not ab.get("ok"):
            Z.append("  Achtung: Der Abgleich mit S3 ist in diesem Lauf misslungen -- die Zahlen sind nicht gesichert.")
        for ms in ("A", "B"):
            M = ((Zl.get("h") or {}).get(str(H_PRIM)) or {}).get(ms) or {}
            t = [f"{a} {_z(e['quote'] * 100, 0)} % bei {_z(e['erw'] * 100, 0)} % (n {_tsd(e['n'])})" for a, e in (M.get("arten") or {}).items() if e.get("n")]
            Z.append(f"  {ms} {MASS_NAME[ms]} -- eingetreten bei erwartet: " + (" · ".join(t) if t else "keine zulässigen Fälle"))
    Z += ["", "VORWÄRTSTEIL (Momentaufnahmen von Hyperliquid: Take-Profits, Stops, Liquidationscluster, Wände)"]
    Z += vorwaerts_zeilen(vorwaerts(db, jetzt))
    Z += ["", "NACHWEISGRENZE"] + nachweis_zeilen()
    Z += ["", "Lesart: " + satz(U),
          "Grenzen: Der Vergleich nutzt denselben Fächer wie S3; der Fächer selbst steht nicht zur Prüfung. Im Vorwärtsteil gilt die "
          "Wahrscheinlichkeit dem Preis -- ob die Orders dann noch dort liegen, ist offen. Die Tage sind UTC-Tage."]
    return "\n".join(Z)


# ================================================================================================ synthetische Märkte, Nachweisgrenze

SYN_START = int(datetime(2019, 5, 1, tzinfo=timezone.utc).timestamp())
SYN_TAGE = 2750
BT = 48                                                        # 30-min-Kerzen je Tag


def _v_aus_kerzen(coin: str, K: dict) -> dict:
    """Weg wie im Betrieb (und wie AU._stress_markt): Anker, HAR-Breite je Stützstelle, F-Pfad, Bibliothek, Tagesachse."""
    A = AU.anker_reihen(K)
    W = {h: AU.har_walk(A, h) for h in AU.H_STUETZ}
    Fk = AU.F_pfad({h: W[h]["F"] for h in AU.H_STUETZ})
    return {"coin": coin, "A": A, "Fk": Fk, "B": AU.bibliothek(A, Fk, coin), "D": AU.tagesachse(A),
            "tage_hist": int((A["tau"][-1] - A["tau"][0]) // TAG)}


def _pflanzer(art: str, mass: str, kappa: float, zone: float = 1.0):
    """
    extra(ts, r, rng, sb) für hl_regime._markt: pflanzt an den Niveaus einer Art (rund oder swing; je Tag neu aus den Schlüssen bis zum
    Vortag) einen Effekt ein. A (Anziehung): Liegt das nächste noch nicht berührte Niveau innerhalb von zone Tagesschwankungen, driftet
    der Kurs je Kerze um kappa·σ_Kerze darauf zu; nach der Berührung ruht das Niveau 7 Tage (sonst hielte es den Kurs fest, und die anderen
    Niveaus der Art würden seltener erreicht). B (Halten): Nach dem Überschreiten eines Niveaus driftet der Kurs je Kerze um kappa·σ_Kerze zurück, solange
    er höchstens eine Tagesschwankung jenseits liegt (längstens 7 Tage). Zieht keine Zufallszahlen: derselbe Markt mit und ohne Effekt.
    """
    def f(ts, r, rng, sb):
        rl = np.asarray(r, dtype=float).tolist(); sl = np.asarray(sb, dtype=float).tolist(); n = len(rl)
        out = [0.0] * n; x = 4.0
        hd, ld, ph, pt = [], [], [], []                         # Tageshochs/-tiefs der Schlüsse, bestätigte Swing-Hochs/-Tiefs (Tag, log)
        niv = []; tagh = tagl = x; beruehrt = None; ruhe = {}
        w5 = math.sqrt(BT)
        for i in range(n):
            if i % BT == 0:
                d = i // BT
                if d > 0:
                    hd.append(tagh); ld.append(tagl)
                tagh = tagl = x
                if art == "rund":
                    ru, ro, _s = CB.runde(math.exp(x))
                    niv = [math.log(v) for v in (ru, ro) if v and math.isfinite(v) and v > 0]
                else:
                    t = d - 1 - 5
                    if t - 5 >= 0:
                        if hd[t] > max(hd[t - 5:t]) and hd[t] >= max(hd[t + 1:t + 6]):
                            ph.append((t, hd[t]))
                        if ld[t] < min(ld[t - 5:t]) and ld[t] <= min(ld[t + 1:t + 6]):
                            pt.append((t, ld[t]))
                    a = d - 1 - 365; lo30, hi30 = x + math.log(0.7), x + math.log(1.3)
                    niv = (sorted(v for t_, v in ph if t_ >= a and x < v <= hi30)[:2]
                           + sorted((v for t_, v in pt if t_ >= a and lo30 <= v < x), reverse=True)[:2])
            sd = sl[i] * w5; dr = 0.0
            if mass == "A":
                frei = [l for l in niv if i - ruhe.get(l, -10 ** 9) > 7 * BT]
                if frei:
                    L = min(frei, key=lambda l: abs(l - x))
                    if 0.0 < abs(L - x) <= zone * sd:
                        dr = kappa * sl[i] * (1.0 if L > x else -1.0)
            elif beruehrt is not None:
                L, ri, i0 = beruehrt; jenseits = (x - L) * ri
                if i - i0 > 7 * BT or jenseits > sd or jenseits <= 0.0:
                    beruehrt = None
                else:
                    dr = -kappa * sl[i] * ri
            xn = x + rl[i] + dr
            if mass == "A":
                for L in niv:
                    if (x < L <= xn) or (x > L >= xn):
                        ruhe[L] = i
            elif beruehrt is None:
                for L in niv:
                    if (x < L <= xn) or (x > L >= xn):
                        beruehrt = (L, 1.0 if xn > x else -1.0, i); break
            out[i] = rl[i] + dr; x = xn
            if x > tagh:
                tagh = x
            if x < tagl:
                tagl = x
        return np.array(out)
    return f


def markt_v(saat: int, coins=AU.KRYPTO, tage: int = SYN_TAGE, start: int = SYN_START, pflanz: tuple | None = None, sigma_tag: float = 0.03) -> dict:
    """Synthetischer Markt des Ausblicks je Coin (hl_regime._markt: Schwankungsregime als log-AR(1), t-Innovationen, flaches Tagesprofil)."""
    import hl_regime as RG
    V = {}
    for i, c in enumerate(coins):
        K = RG._markt(tage=tage, seed=1000 * int(saat) + i, sigma_tag=sigma_tag, profil="flach", start=start,
                      extra=_pflanzer(*pflanz) if pflanz else None)
        V[c] = _v_aus_kerzen(c, K)
    return V


def wirkung(F: dict, art: str, mass: str) -> tuple:
    """Rohe Wirkung einer Art bei 7 Tagen: eingetreten − erwartet auf den zulässigen Fällen -> (Differenz, n)."""
    m, p, y = auswahl(F, H_PRIM, mass, AU.KRYPTO)
    m = m & (F["art"] == art) & ~F["sp"]
    return (float(y[m].mean() - p[m].mean()), int(m.sum())) if m.any() else (float("nan"), 0)


def nachweis_lauf(saat: int, art: str | None = None, mass: str | None = None, kappa: float = 0.0, zone: float = 1.0, reps: int = REPS) -> dict:
    """Ein synthetischer Markt durch die ganze Regel (7 Tage, beide Maße, Familie mit Holm). -> Urteile je Art und Maß, „gefunden“."""
    V = markt_v(saat, pflanz=(art, mass, kappa, zone) if art and kappa else None)
    F = faelle(V, horizonte=(H_PRIM,))
    MA = mass_rechnen(F, H_PRIM, "A", AU.KRYPTO, reps, saat=1000 + H_PRIM); MB = mass_rechnen(F, H_PRIM, "B", AU.KRYPTO, reps, saat=2000 + H_PRIM)
    tests = urteile_setzen(MA, MB)
    U = {ms: {a: [e.get("urteil"), e.get("gamma"), e.get("p"), e.get("p_holm"), e.get("ame"), e.get("vermerk"), e.get("haelften_gleich"),
                  e.get("se"), (e.get("spiegel") or {}).get("gamma"), (e.get("spiegel") or {}).get("se"), e.get("sp_diff_se"), e.get("n")]
              for a, e in M["arten"].items() if e.get("urteil")} for ms, M in (("A", MA), ("B", MB))}
    out = {"saat": saat, "art": art, "mass": mass, "kappa": kappa, "zone": zone, "tests": tests, "urteile": U,
           "irgendein_belegt": any(u[0] == "belegt" for d in U.values() for u in d.values())}
    if art and mass:
        u = U[mass].get(art) or [None, 0.0]
        out["gefunden"] = bool(u[0] == "belegt" and ((u[1] > 0) if mass == "A" else (u[1] < 0)))
        out["wirkung"] = wirkung(F, art, mass)
    return out


# ================================================================================================ Selbsttest (Debug 150)

T0_MONTAG = 1641168000                                         # Montag 03.01.2022 00:00 UTC


def _tabelle(saat: int, wochen: int = 160, coins=("BTC", "ETH"), gamma: dict | None = None, delta: dict | None = None,
             gamma2: dict | None = None, klumpen: str | None = None) -> dict:
    """Erfundene Falltabelle mit bekannter Wahrheit (7 Tage): je Woche und Coin 8 Prüfniveaus und je Art 2 Niveaus samt Spiegel.
    ja ~ σ(logit(pe) + Wocheneffekt + γ_Art), z ~ σ(logit(q) + Wocheneffekt + δ_Art). gamma2: γ der zweiten Hälfte der Wochen.
    klumpen: Alle Fälle dieser Art teilen sich je Woche eine Zufallszahl (ein gemeinsamer Ausgang)."""
    rng = np.random.default_rng(saat)
    rec = {k: [] for k in ("coin", "tau", "h", "art", "sp", "d", "pe", "ps", "ja", "z", "b1", "genau")}
    for w in range(wochen):
        uw, uz = rng.normal(0, 0.3, 2)
        g_w = (gamma2 if (gamma2 is not None and w >= wochen // 2) else gamma) or {}
        kl = rng.random()
        for c in coins:
            for art, n in (("ref", 8),) + tuple((a, 2) for a in ARTEN):
                for _i in range(n):
                    for sp in ((False,) if art == "ref" else (False, True)):
                        key = ("sp_" if sp else "") + art
                        pe = float(rng.uniform(0.08, 0.92)); q = float(rng.uniform(0.1, 0.9))
                        d = float(rng.choice((-1.0, 1.0)) * rng.uniform(0.01, 0.1))
                        pj = float(_sig(math.log(pe / (1 - pe)) + uw + g_w.get(key, 0.0)))
                        ja = float(kl < pj) if klumpen == key else float(rng.random() < pj)
                        z = float(rng.random() < float(_sig(math.log(q / (1 - q)) + uz + (delta or {}).get(key, 0.0))))
                        for k_, v in (("coin", c), ("tau", T0_MONTAG + w * 7 * TAG), ("h", 7), ("art", art), ("sp", sp), ("d", d), ("pe", pe),
                                      ("ps", q * pe), ("ja", ja), ("z", z), ("b1", True), ("genau", True)):
                            rec[k_].append(v)
    F = {k: np.array(v) for k, v in rec.items()}
    for k in ("sp", "b1", "genau"):
        F[k] = F[k].astype(bool)
    return F


def selbsttest() -> bool:
    import copy
    import re
    import tempfile
    import hl_regime as RG
    erg = []

    def ok(name, bed, info=""):
        erg.append(bool(bed))
        print(("ok   " if bed else "FEHL ") + name + (f" -- {info}" if info and not bed else ""), flush=True)

    def gruppe(name, fn):
        try:
            fn()
        except Exception as e:                                   # eine Ausnahme darf die übrigen Proben nicht verschlucken
            ok(f"{name}: läuft ohne Ausnahme", False, f"{type(e).__name__}: {e}")

    kr = ("BTC", "ETH")
    urt = lambda M: {a: e.get("urteil") for a, e in M["arten"].items()}

    def beide(F, reps=300, saat=3):
        MA = mass_rechnen(F, 7, "A", kr, reps, saat); MB = mass_rechnen(F, 7, "B", kr, reps, saat + 1)
        return MA, MB, urteile_setzen(MA, MB)

    def stat():
        ok("Urteil: Grenzen von Hand",
           urteil(0.001, 0.049, True, "unauffällig") == ("belegt", "") and urteil(0.001, 0.05, True, "unauffällig") == ("Hinweis", "")
           and urteil(0.049, 0.4, True, "unauffällig") == ("Hinweis", "") and urteil(0.05, 0.4, True, "unauffällig") == ("nicht belegt", "")
           and urteil(0.001, 0.01, False, "unauffällig") == ("Hinweis", "Hälften uneins")
           and urteil(0.001, 0.01, True, "auffällig") == ("nicht belegt", "Spiegel auffällig")
           and urteil(0.001, 0.01, True, "fehlt") == ("Hinweis", "ohne Spiegelprobe")
           and urteil(0.3, 0.9, True, "auffällig") == ("nicht belegt", "") and urteil(0.03, 0.2, True, "auffällig", "X") == ("nicht belegt", "X")
           and urteil(0.03, 0.2, True, "unauffällig") == ("Hinweis", "") and urteil(0.001, 0.01, False, "fehlt") == ("Hinweis", "Hälften uneins, ohne Spiegelprobe"))
        ok("p zweiseitig von Hand", abs(p_zweiseitig(1.0, np.array([0.0, 1.0, 2.5, -0.1, 1.9])) - 4 / 6) < 1e-12
           and abs(p_zweiseitig(-1.0, np.array([-1.0, -0.5])) - 1 / 3) < 1e-12 and abs(p_zweiseitig(0.5, np.array([1.0, 0.0, 0.4])) - 3 / 4) < 1e-12)
        mk = lambda ps: {"arten": {a: ({"p": p, "gamma": 1.0, "sp_diff_se": 0.1, "haelften_gleich": True, "spiegel": {"gamma": 0.0, "se": 1.0}}
                                       if p is not None else {}) for a, p in zip(ARTEN, ps)}}
        HA, HB = mk([0.004, 0.02, 0.5, None, 0.03]), mk([0.9, 0.006, None, None, 0.2])
        n = urteile_setzen(HA, HB)
        ph = [HA["arten"]["swing"]["p_holm"], HB["arten"]["rund"]["p_holm"], HA["arten"]["rund"]["p_holm"], HA["arten"]["bein"]["p_holm"],
              HB["arten"]["bein"]["p_holm"], HA["arten"]["ma50"]["p_holm"], HB["arten"]["swing"]["p_holm"]]
        ok("Holm von Hand: 7 Tests", n == 7 and max(abs(a - b) for a, b in zip(ph, [0.028, 0.036, 0.1, 0.12, 0.6, 1.0, 1.0])) < 1e-12
           and [HA["arten"]["swing"]["urteil"], HB["arten"]["rund"]["urteil"], HA["arten"]["rund"]["urteil"], HA["arten"]["bein"]["urteil"],
                HB["arten"]["bein"]["urteil"]] == ["belegt", "belegt", "Hinweis", "Hinweis", "nicht belegt"] and "urteil" not in HA["arten"]["ma200"],
           f"{n} {ph}")
        rng = np.random.default_rng(5); D = (rng.random(400) < 0.4).astype(float); y = (rng.random(400) < np.where(D > 0, 0.7, 0.3)).astype(float)
        Xd = np.column_stack([np.ones(400), D]); dop = np.arange(400) % 3 == 0; lg = lambda p: math.log(p / (1 - p))
        b, kv = logit_fit(Xd, y); p1, p0 = y[D > 0].mean(), y[D == 0].mean()
        b2, _ = logit_fit(Xd, y, 1.0 + dop); b3, _ = logit_fit(np.vstack([Xd, Xd[dop]]), np.concatenate([y, y[dop]]))
        ok("Regression: geschlossene Form; Gewicht 2 = Zeile doppelt", kv and abs(b[0] - lg(p0)) < 1e-6 and abs(b[1] - (lg(p1) - lg(p0))) < 1e-6
           and float(np.max(np.abs(b2 - b3))) < 1e-6 and float(np.max(np.abs(b2 - b))) > 1e-4, f"{b} {b2} {b3}")
        F0 = _tabelle(11); MA, MB, n = beide(F0)
        ok("Null: 10 Tests, kein „belegt“", n == 10 and "belegt" not in list(urt(MA).values()) + list(urt(MB).values()), f"{n} {urt(MA)} {urt(MB)}")
        F1 = _tabelle(12, gamma={"swing": 0.8}); MA1, MB1, _ = beide(F1); e = MA1["arten"]["swing"]
        ok("Positiv A: swing belegt, γ > 0 und nahe 0,8; sonst nichts belegt",
           e.get("urteil") == "belegt" and 0.55 < e["gamma"] < 1.05 and e["ame"] > 5 and e["ame_lo"] < e["ame"] < e["ame_hi"]
           and all(u != "belegt" for a, u in urt(MA1).items() if a != "swing") and "belegt" not in urt(MB1).values(), f"{e} {urt(MA1)} {urt(MB1)}")
        m, p, _y = auswahl(F1, 7, "A", kr); ms = m & (F1["art"] == "swing") & ~F1["sp"]
        eta = MA1["a"] + MA1["b"] * np.log(p[ms] / (1 - p[ms])) + MA1["c"] * (F1["d"][ms] >= 0) + e["gamma"]
        hand = float(np.mean(_sig(eta) - _sig(eta - e["gamma"]))) * 100
        ok("Randeffekt von Hand aus den berichteten Koeffizienten", abs(hand - e["ame"]) < 1e-9 and e["n"] == int(ms.sum()), f"{hand} {e['ame']}")
        perm = np.random.default_rng(1).permutation(len(F1["tau"]))
        MA2, MB2, _ = beide(dict(F1, art=F1["art"][perm], sp=F1["sp"][perm]))
        ok("Etiketten der Arten vertauscht: kein „belegt“", "belegt" not in list(urt(MA2).values()) + list(urt(MB2).values()), f"{urt(MA2)} {urt(MB2)}")
        r = F0["art"] == "ref"
        F3 = {k: np.concatenate([v[r], v[r]]) for k, v in F0.items()}
        F3["art"] = np.concatenate([F0["art"][r], np.full(int(r.sum()), "swing")])
        M3 = mass_rechnen(F3, 7, "A", kr, 0); e3 = M3["arten"]["swing"]
        ok("Eine Art gegen sich selbst als Referenz: γ = 0", M3["ok"] and abs(e3["gamma"]) < 1e-8 and abs(e3["ame"]) < 1e-6 and e3["n"] == M3["ref"]["n"],
           f"{e3}")
        F4 = _tabelle(13, delta={"rund": -0.8}); MA4, MB4, _ = beide(F4); e4 = MB4["arten"]["rund"]
        ok("Positiv B: rund belegt, δ < 0 (hält); sonst nichts belegt", e4.get("urteil") == "belegt" and -1.1 < e4["gamma"] < -0.5 and e4["ame"] < -5
           and "belegt" not in urt(MA4).values() and all(u != "belegt" for a, u in urt(MB4).items() if a != "rund"), f"{e4} {urt(MA4)} {urt(MB4)}")
        mb, qb, zb = auswahl(F4, 7, "B", kr); mr = (F4["art"] == "rund") & ~F4["sp"] & (F4["ja"] == 1)
        q_hand = F4["ps"][mr] / F4["pe"][mr]
        ok("Maß B von Hand: nur erreichte Fälle, erwartet = Mittel von ps ÷ pe, eingetreten = Schluss jenseits",
           e4["n"] == int(mr.sum()) == int((mb & (F4["art"] == "rund") & ~F4["sp"]).sum()) and abs(e4["erw"] - float(q_hand.mean())) < 1e-12
           and abs(e4["quote"] - float(F4["z"][mr].mean())) < 1e-12 and abs(e4["diff"] - (e4["quote"] - e4["erw"])) < 1e-12, f"{e4['n']} {int(mr.sum())}")
        F8 = {k: v.copy() for k, v in F0.items()}; i8 = np.nonzero((F8["art"] == "swing") & ~F8["sp"])[0]
        F8["ja"][i8] = 1.0; F8["ja"][i8[:5]] = 0.0
        e8 = mass_rechnen(F8, 7, "A", kr, 0)["arten"]["swing"]
        ok("Ein Ausgang zu selten: kein Test", "ein Ausgang zu selten (5, nötig 20)" in str(e8.get("grund")) and e8.get("gamma") is None, f"{e8.get('grund')}")
        MA5, _, _ = beide(_tabelle(14, gamma={"swing": 0.8, "sp_swing": 0.8})); e5 = MA5["arten"]["swing"]
        ok("Spiegel mit demselben Effekt wie die Art: nicht belegt mit Vermerk -- in beiden Fassungen der Spiegelprobe",
           e5.get("urteil") == "nicht belegt" and e5.get("vermerk") == SPIEGEL_VERMERK[SPIEGEL_REGEL] and e5["p"] < 0.05 and e5["p_holm"] < 0.05
           and spiegel_stand(e5, "streng") == "auffällig" and spiegel_stand(e5, "abstand") == "auffällig" and e5.get("urteil_andere") == "nicht belegt"
           and e5.get("spiegel_regel") == SPIEGEL_REGEL, f"{e5}")
        s1 = {"gamma": -1.2, "sp_diff_se": 0.2, "spiegel": {"gamma": 0.27, "se": 0.13}}; s2 = {"gamma": 0.8, "sp_diff_se": 0.3, "spiegel": {"gamma": 0.7, "se": 0.5}}
        s3 = {"gamma": 0.8, "sp_diff_se": 0.1, "spiegel": {"gamma": 1.5, "se": 0.2}}; s4 = {"gamma": 0.8, "sp_diff_se": 0.2, "spiegel": {"gamma": 0.4, "se": 0.2}}
        ok("Spiegelprobe von Hand: „abstand“ = die Art schlägt ihren Spiegel um mehr als 2 Standardfehler des Abstands, in ihrer Richtung; "
           "„streng“ = Spiegel außerhalb ±2 Standardfehlern; ohne Spiegel „fehlt“",
           [spiegel_stand(x, "abstand") for x in (s1, s2, s3, s4)] == ["unauffällig", "auffällig", "auffällig", "auffällig"]
           and [spiegel_stand(x, "streng") for x in (s1, s2, s3, s4)] == ["auffällig", "unauffällig", "auffällig", "unauffällig"]
           and spiegel_stand(dict(s4, sp_diff_se=0.19), "abstand") == "unauffällig" and spiegel_stand(dict(s4, spiegel={"gamma": 0.41, "se": 0.2}), "streng") == "auffällig"
           and spiegel_stand({"gamma": 1.0}, "streng") == spiegel_stand({"gamma": 1.0}, "abstand") == "fehlt"
           and spiegel_stand({"gamma": 1.0, "spiegel": {"gamma": 0.0, "se": 0.1}}, "abstand") == "fehlt" and SPIEGEL_REGEL == "abstand"
           and spiegel_stand(s1) == spiegel_stand(s1, SPIEGEL_REGEL))
        gl_ = (F0["art"] == "ref") | ((F0["art"] == "swing") & ~F0["sp"]); sw_ = (F0["art"] == "swing") & ~F0["sp"]
        Fd = {k: np.concatenate([v[gl_], v[sw_]]) for k, v in F0.items()}
        Fd["sp"] = np.concatenate([F0["sp"][gl_], np.ones(int(sw_.sum()), dtype=bool)])
        ed = mass_rechnen(Fd, 7, "A", kr, 200, 9)["arten"]["swing"]
        ok("Standardfehler des Abstands Art − Spiegel aus denselben Wiederholungen: Spiegel mit denselben Fällen wie die Art -> Abstand und sein "
           "Standardfehler null", ed.get("sp_diff_se") is not None and ed["sp_diff_se"] < 1e-9 and ed["se"] > 0.02
           and abs(ed["gamma"] - ed["spiegel"]["gamma"]) < 1e-9 and spiegel_stand(ed, "abstand") == "fehlt", f"{ed.get('sp_diff_se')} {ed.get('se')}")
        MA9, _, _ = beide(_tabelle(18, gamma={"swing": 0.9, "sp_swing": -0.5})); e9 = MA9["arten"]["swing"]
        z9 = _art_zeile("swing", e9, "A", MA9, True)
        ok("Spiegel mit entgegengesetztem Effekt: verfeinert belegt, wie am 11.11. festgelegt nicht -- das Urteil folgt der Regel, die andere "
           "Lesart steht in der Zeile des Berichts", spiegel_stand(e9, "streng") == "auffällig" and spiegel_stand(e9, "abstand") == "unauffällig"
           and (e9.get("urteil"), e9.get("vermerk")) == ("belegt", "") and (e9.get("urteil_andere"), e9.get("vermerk_andere")) == ("nicht belegt", "Spiegel auffällig")
           and "· belegt · mit der Spiegelprobe wie am 11.11. festgelegt: nicht belegt (Spiegel auffällig)" in z9, f"{e9} | {z9}")
        MA6, _, _ = beide(_tabelle(15, gamma={"swing": 1.6}, gamma2={"swing": -0.4})); e6 = MA6["arten"]["swing"]
        ok("Hälften uneins: kein „belegt“, Vermerk", e6["gamma"] > 0 and e6["haelften"][0] > 0 > e6["haelften"][1] and not e6["haelften_gleich"]
           and e6["p_holm"] < 0.05 and (e6.get("urteil"), e6.get("vermerk")) == ("Hinweis", "Hälften uneins"), f"{e6}")
        F7 = {k: v.copy() for k, v in F0.items()}; i_sw = np.nonzero((F7["art"] == "swing") & ~F7["sp"])[0]
        n0 = mass_rechnen(F0, 7, "A", kr, 0)["arten"]["swing"]["n"]; nb0 = mass_rechnen(F0, 7, "B", kr, 0)["arten"]["swing"]["n"]
        ia = [i for i in i_sw if F0["ja"][i] == 0][:7]; rj = [i for i in i_sw if F0["ja"][i] == 1][:4]
        F7["pe"][ia[0]] = 0.04; F7["pe"][ia[1]] = 0.96; F7["genau"][ia[2]] = False; F7["coin"][ia[3]] = "XMR"; F7["h"][ia[4]] = 14
        F7["pe"][ia[5]] = 0.05; F7["pe"][ia[6]] = 0.95
        F7["z"][rj[0]] = np.nan; F7["ps"][rj[1]] = 0.04 * F7["pe"][rj[1]]; F7["ps"][rj[2]] = 0.96 * F7["pe"][rj[2]]; F7["ja"][rj[3]] = 0.0
        n7 = mass_rechnen(F7, 7, "A", kr, 0)["arten"]["swing"]["n"]; nb7 = mass_rechnen(F7, 7, "B", kr, 0)["arten"]["swing"]["n"]
        ok("Zulässig: Rand 0,05/0,95 zählt, außerhalb nicht; B nur erreichte Fälle mit q im Bereich", n7 == n0 - 5 and nb7 == nb0 - 4 and n0 == len(i_sw),
           f"A {n0} -> {n7}, B {nb0} -> {nb7}")
        se_i = mass_rechnen(_tabelle(16), 7, "A", kr, 300, 5)["arten"]["swing"]["se"]
        se_k = mass_rechnen(_tabelle(16, klumpen="swing"), 7, "A", kr, 300, 5)["arten"]["swing"]["se"]
        ok("Bootstrap über Wochen: ein gemeinsamer Ausgang je Woche vergrößert den Standardfehler", se_k > 1.5 * se_i, f"{se_k:.3f} gegen {se_i:.3f}")
        bl = [mass_rechnen(dict(F0, h=np.full(len(F0["h"]), h)), h, "A", kr, 0)["block_wochen"] for h in (7, 14, 28)]
        ok("Blocklänge: 2h Tage (2, 4, 8 Wochen)", bl == [2.0, 4.0, 8.0], f"{bl}")
        Mk = mass_rechnen(_tabelle(17, wochen=20), 7, "A", kr, 0); Mw = mass_rechnen(_tabelle(17, wochen=25), 7, "A", kr, 0)
        ok("Zu wenige Fälle oder Wochen: kein Test", not Mk["ok"] and "zu wenige Fälle (80" in str(Mk["arten"]["swing"]["grund"])
           and "zu wenige Wochen (25" in str(Mw["arten"]["swing"]["grund"]) and Mw["arten"]["swing"].get("gamma") is None,
           f"{Mk.get('grund')} {Mk['arten']['swing'].get('grund')} {Mw['arten']['swing'].get('grund')}")

    def markt():
        start = int(datetime(2021, 1, 1, tzinfo=timezone.utc).timestamp()); still = lambda *a: None
        V0 = markt_v(7, coins=kr, tage=1560, start=start)
        F0 = faelle(V0); S3 = AU.s3_ziellevels(V0, still)
        ab = abgleich_s3(F0, S3)
        ok("Abgleich mit S3: n und Brier gleich (7, 14, 28 Tage)", ab["ok"] and all(e["n"] > 1000 and e["n"] == e["n_s3"] for e in ab["h"].values()), f"{ab}")
        w60 = np.unique(F0["tau"])[60]; F60 = {k: v_[F0["tau"] < w60] for k, v_ in F0.items()}
        R60 = rechnen(V0, S3, None, VORWAERTS_AB, 50, F=F60); Rv = rechnen(V0, None, None, VORWAERTS_AB, 0, F=F0)
        ok("Sperren: unter 100 Ursprungswochen kein Urteil; ohne S3 kein Abgleich und kein Urteil",
           "zu wenige Ursprungswochen (60, nötig 100)" in str(R60.get("gesperrt")) and "Abgleich mit S3 misslungen" in str(R60.get("gesperrt"))
           and "ohne S3 kein Abgleich" in str(Rv.get("gesperrt")), f"{R60.get('gesperrt')} | {Rv.get('gesperrt')}")
        S3f = copy.deepcopy(S3); S3f["h"]["7"]["n"] += 1
        S3g = copy.deepcopy(S3); S3g["h"]["28"]["brier_b0"] += 1e-9
        ok("Abgleich mit S3: ein Fall oder ein Milliardstel Brier Unterschied fällt auf", not abgleich_s3(F0, S3f)["ok"] and not abgleich_s3(F0, S3g)["ok"])
        v = V0["BTC"]; A = v["A"]; D = v["D"]; B, _ = AU.bibliothek_fuer("BTC", V0); J = montage(A)
        gut = True; n_f = 0; arten_da = set(); wo = ""
        for j in (J[20], J[70], J[120]):
            tau = int(A["tau"][j]); c0 = float(A["C"][j]); i = int(np.nonzero(D["tag"] == tau // TAG - 1)[0][0])
            S = AU.szenarien(B, AU.bib_bis(B, tau), v["Fk"][j]); H_, L_, C_ = D["H"], D["L"], D["C"]
            hoch = [H_[t] for t in range(max(5, i - 365), i - 4) if H_[t] > max(H_[t - 5:t]) and H_[t] >= max(H_[t + 1:t + 6])]
            tief = [L_[t] for t in range(max(5, i - 365), i - 4) if L_[t] < min(L_[t - 5:t]) and L_[t] <= min(L_[t + 1:t + 6])]
            niv = [("swing", x) for x in sorted(x for x in hoch if c0 < x <= 1.3 * c0)[:2] + sorted((x for x in tief if 0.7 * c0 <= x < c0), reverse=True)[:2]]
            ex = math.floor(math.log10(c0)); lead = c0 / 10 ** ex; s = (1 if lead < 2 else 2 if lead < 5 else 5) * 10.0 ** (ex - 1)
            niv += [("rund", math.floor(c0 / s) * s), ("rund", math.floor(c0 / s) * s + s)]
            niv += [("ma50", float(np.mean(C_[i - 49:i + 1]))), ("ma200", float(np.mean(C_[i - 199:i + 1])))]
            bb = CB.beine_stand({"tag0": 0, "c": C_[:i + 1]}, (0.10,))[0].get("bestaetigt_ab")
            if bb:
                niv.append(("bein", float(bb)))
            soll = {}
            for h in AU.H_ZIEL:
                hoechst = max(float(A["H"][j + 4 * k]) for k in range(1, h + 1)); tiefst = min(float(A["L"][j + 4 * k]) for k in range(1, h + 1))
                schluss = float(A["C"][j + 4 * h])
                alle = [(a, False, math.log(x / c0)) for a, x in niv] + [(a, True, -math.log(x / c0)) for a, x in niv]
                alle += [("ref", False, sg * k * math.sqrt(v["Fk"][j, h - 1])) for k in (0.5, 1.0, 1.5, 2.0) for sg in (1, -1)]
                for a, sp, d in alle:
                    Lp = c0 * math.exp(d)
                    if d >= 0:
                        w4 = (float(np.mean(S["hoch_lauf"][:, h - 1] >= d)), float(np.mean(S["r"][:, h - 1] >= d)), float(hoechst >= Lp), float(schluss >= Lp))
                    else:
                        w4 = (float(np.mean(S["tief_lauf"][:, h - 1] <= d)), float(np.mean(S["r"][:, h - 1] <= d)), float(tiefst <= Lp), float(schluss <= Lp))
                    soll[(a, sp, h, round(d, 9))] = w4; arten_da.add(a)
            mm = (F0["coin"] == "BTC") & (F0["tau"] == tau)
            ist = {(str(a), bool(sp), int(h), round(float(d), 9)): (float(pe), float(ps), float(ja), float(z)) for a, sp, h, d, pe, ps, ja, z in
                   zip(F0["art"][mm], F0["sp"][mm], F0["h"][mm], F0["d"][mm], F0["pe"][mm], F0["ps"][mm], F0["ja"][mm], F0["z"][mm])}
            if set(ist) != set(soll):
                gut = False; wo = f"τ {tau}: Schlüssel {sorted(set(ist) ^ set(soll))[:4]}"
            elif any(max(abs(x - y_) for x, y_ in zip(ist[k], soll[k])) > 1e-12 for k in soll):
                gut = False; wo = f"τ {tau}: Werte {[(k, ist[k], soll[k]) for k in soll if ist[k] != soll[k]][:2]}"
            n_f += len(soll)
        ok("Drei Ursprünge von Hand: Niveaus, pe, ps, ja, z (alle Arten, Spiegel, 7/14/28 Tage)", gut and n_f > 150 and arten_da == set(ARTEN) | {"ref"},
           f"{wo} {n_f} {arten_da}")
        c = D["C"]; s_ = bein_schwelle(c, 0.10); gl = True; n_b = 0; beide_modi = set()
        for i in range(120, D["n"], 41):
            st = CB.beine_stand({"tag0": 0, "c": c[:i + 1]}, (0.10,))[0]; bb = st.get("bestaetigt_ab")
            gl = gl and ((bb is None and not np.isfinite(s_[i])) or (bb is not None and abs(bb - s_[i]) < 1e-9 * bb)); n_b += 1; beide_modi.add(st.get("mode"))
        import hl_zyklus as ZY
        xl = np.log(c); n_ = len(c); idx_ = np.arange(n_)
        E_ = ZY.dc_batch(np.where(idx_[None, :] <= idx_[:, None], xl[None, :], xl[:, None]), math.log(1.1), -math.log(0.9))["ende"]
        soll_ = np.where(E_["mode"] == 1, np.exp(E_["hi"]) * 0.9, np.where(E_["mode"] == -1, np.exp(E_["lo"]) * 1.1, np.nan))
        alle_tage = bool(np.allclose(soll_, s_, rtol=1e-12, atol=0.0, equal_nan=True)) and int(np.isfinite(s_).sum()) > 1000
        ok("Bein-Schwelle: je Tag wie hl_chartbild auf der bis dahin abgeschnittenen Reihe (kausal); an jedem Tag wie die Regeln von hl_zyklus",
           gl and n_b >= 30 and {1, -1} <= beide_modi and alle_tage, f"{n_b} {beide_modi} alle Tage {alle_tage}")
        K = RG._markt(tage=1560, seed=77, sigma_tag=0.03, profil="flach", start=start)
        cut = 1000 * BT; x0 = float(np.log(K["c"][cut - 1]))
        K2 = {k: np.array(v_, copy=True) for k, v_ in K.items()}
        for a, b_ in (("c", "c"), ("o", "o"), ("h", "l"), ("l", "h")):
            K2[a][cut:] = np.exp(2 * x0 - np.log(K[b_][cut:]))
        Fa = faelle({"BTC": _v_aus_kerzen("BTC", K)}, horizonte=(7,)); Fb = faelle({"BTC": _v_aus_kerzen("BTC", K2)}, horizonte=(7,))
        t_cut = int(K["ts"][cut]); ma, mb = Fa["tau"] <= t_cut, Fb["tau"] <= t_cut
        gleich = int(ma.sum()) == int(mb.sum()) > 500 and all(np.array_equal(Fa[k][ma], Fb[k][mb]) for k in ("tau", "art", "sp", "d", "pe", "ps"))
        anders = not np.array_equal(Fa["ja"][ma], Fb["ja"][mb]) and not np.array_equal(Fa["pe"][~ma][:300], Fb["pe"][~mb][:300])
        ok("Kausalität: Kurse nach dem Ursprung ändern weder Niveaus noch pe und ps (wohl aber die Ergebnisse)", gleich and anders,
           f"gleich {gleich}, anders {anders}, n {int(ma.sum())}/{int(mb.sum())}")
        Vp = markt_v(7, coins=kr, tage=1560, start=start, pflanz=("swing", "A", 0.12, 3.0))
        Fp = faelle(Vp); S3p = AU.s3_ziellevels(Vp, still)
        T1 = VORWAERTS_AB + 43 * TAG
        alt_env = os.environ.get("HL_AUSBLICK_DB")
        with tempfile.TemporaryDirectory() as tmp:
            try:
                os.environ["HL_AUSBLICK_DB"] = os.path.join(tmp, "a.db")
                k0 = kurz("x"); t0_ = bericht_text("x", T1)
                ok("Ohne Datenbank: kein Urteil, Satz und Spalte sagen es, der Bericht nennt den Weg",
                   not k0["da"] and k0["satz"] == SATZ_OFFEN and "noch kein Urteil" in k0["arten"]["rund"] and "noch keine Zählung" in k0["arten"]["tp_sell"]
                   and "Noch kein Urteil" in t0_ and f"Debug {DEBUG_RUECKBLICK}" in t0_ and stand_lesen("x") == {}, f"{k0}")
                r1 = im_rueckblick("x", Vp, S3p, T1, still, 300, F=Fp); U = stand_lesen("x").get("urteil") or {}
                e = (((U.get("h") or {}).get("7") or {}).get("A") or {}).get("arten", {}).get("swing") or {}
                ok("Ende zu Ende: eingepflanzte Anziehung an Swing-Niveaus wird belegt (γ > 0)", r1["urteil_neu"] and e.get("urteil") == "belegt"
                   and e["gamma"] > 0 and e["ame"] > 4 and U["abgleich"]["ok"] and not U.get("gesperrt") and U["regel"] == REGEL and U["tests"] >= 4, f"{e} {U.get('tests')}")
                con = AU.verbinden(AU.ausblick_pfad("x"))
                a0 = VORWAERTS_AB + 3 * TAG

                def zeile(coin, anker, niv, e_, h=7, ausg=1):
                    con.execute("INSERT OR REPLACE INTO au_vorwaerts VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                                (coin, anker, h, 100.0, 0.01, 0.0, 0, 0.03, "[]", json.dumps(niv), ausg, json.dumps(e_) if e_ else None))
                n1 = [["tp_sell", 104.0, 0.5, 0.2], ["stop_sell", 97.0, 0.6, 0.3], ["stop_sell", 93.0, 0.3, 0.1], ["liq_long", 95.0, 0.4, 0.3],
                      ["limit_buy", 99.9, 0.97, 0.5], ["swing_hoch", 108.0, 0.2, 0.1], ["pruef", 1.0, 0.3, 0.1]]
                e1 = {"y": math.log(1.05), "niveaus": [["tp_sell", 0.5, True], ["stop_sell", 0.6, True], ["stop_sell", 0.3, False], ["liq_long", 0.4, True],
                                                      ["limit_buy", 0.97, True], ["swing_hoch", 0.2, False]]}
                zeile("BTC", a0, n1, e1)
                zeile("ETH", a0 + 5 * TAG, [["stop_buy", 110.0, 0.2, 0.18], ["limit_sell", 103.0, 0.5, 0.01]],
                      {"y": 0.2, "niveaus": [["stop_buy", 0.2, True], ["limit_sell", 0.5, True]]})        # Montag 19.10.: neue Woche
                zeile("ETH", a0 + 4 * TAG, [["tp_buy", 98.0, 0.5, 0.25]], {"y": 0.0, "niveaus": [["tp_buy", 0.5, False]]})   # Sonntag 18.10.
                zeile("BTC", a0 + 6 * 3600, n1, e1); zeile("BTC", VORWAERTS_AB - TAG, n1, e1); zeile("BTC", a0 + TAG, n1, None, ausg=0)
                zeile("BTC", a0, n1, e1, h=14); zeile("PAXG", a0, [["tp_buy", 99.0, 0.5, 0.2]], {"y": -0.02, "niveaus": [["tp_buy", 0.5, True]]})
                zeile("XMR", a0 + 2 * TAG, n1[:2], {"y": 0.0, "niveaus": [["tp_sell", 0.5, True]]})
                con.close()
                VW = vorwaerts("x", T1); H7 = VW["h"]["7"]; kz = lambda f, ms: [H7["krypto"][f][ms]["n"], round(H7["krypto"][f][ms]["erwartet"], 9),
                                                                               H7["krypto"][f][ms]["eingetreten"]]
                ok("Vorwärtsteil: Familien, größtes Cluster, nur Anker 00:00 UTC seit 11.10.2026, Wochen von Montag bis Sonntag",
                   VW["ok"] and [kz("F1", "A"), kz("F1", "B"), kz("F2", "A"), kz("F2", "B"), kz("F3", "A"), kz("F3", "B"), kz("F4", "A"), kz("F4", "B")]
                   == [[2, 1.0, 1], [1, 0.4, 1], [2, 0.5, 1], [1, 0.9, 1], [1, 0.4, 1], [1, 0.75, 0], [1, 0.5, 1], [0, 0.0, 0]]
                   and H7["wochen"] == 2 and H7["unpassend"] == 1 and H7["paxg"]["F1"]["A"]["n"] == 1 and VW["h"]["14"]["krypto"]["F1"]["A"]["n"] == 1,
                   f"{H7}")
                r2 = im_rueckblick("x", Vp, S3p, T1 + 7 * TAG, still, 300, F=Fp); St2 = stand_lesen("x")
                ok("Ein Urteil, nicht viele: Der zweite Lauf rechnet nicht neu; die Zählung wird fortgeschrieben",
                   not r2["urteil_neu"] and St2["urteil"]["stand"] == T1 and St2["urteil"]["eingabe"] == U["eingabe"]
                   and St2["zaehlung"]["stand"] == T1 + 7 * TAG and St2["zaehlung"]["eingabe"] == U["eingabe"]
                   and St2["zaehlung"]["h"]["7"]["A"]["arten"]["rund"]["n"] == U["h"]["7"]["A"]["arten"]["rund"]["n"]
                   and St2["zaehlung"]["vorwaerts"]["h"]["7"]["wochen"] == 2, f"{r2}")
                k1 = kurz("x"); t1_ = bericht_text("x", T1 + 8 * TAG)
                muster = r"^swing · erreicht \d+ % bei \d+ % erwartet \(n [\d.]+\) · Anziehung belegt · Halten (nicht belegt|Hinweis|belegt) · Art belegt seit \d\d\.\d\d\.\d{4}$"
                ok("Kurzform mit Urteil: Spaltentext je Art-Kennung, Familien als Zählung, γ der belegten Anziehung zum Nachstellen, Satz",
                   k1["da"] and re.match(muster, k1["arten"]["swing_hoch"]) is not None and k1["arten"]["swing_hoch"] == k1["arten"]["swing_tief"]
                   and k1["arten"]["rund"].startswith("rund · erreicht ") and k1["arten"]["ma50_"].startswith("ma50 · ")
                   and k1["arten"]["stop_sell"] == "Stops · erreicht 1 von 2 bei 0,5 erwartet · noch kein Urteil (2 Wochen von 52)"
                   and k1["arten"]["stop_buy"] == k1["arten"]["stop_sell"] and k1["arten"]["limit_buy"].startswith("Wände · erreicht 1 von 1")
                   and k1["belegt"].get("swing_hoch") == {"gamma": e["gamma"], "seit": T1} and k1["belegt"].get("swing_tief") == k1["belegt"]["swing_hoch"]
                   and "Swing-Hoch/-Tief wird häufiger erreicht, als der Abstand erwarten lässt (+" in k1["satz"] and "Art belegt seit" in k1["satz"]
                   and set(k1["arten"]) == set(ART_ZU), f"{k1}")
                ok("Bericht: Urteil, beide Maße, 14/28 Tage beschreibend, Zählung, Vorwärtsteil, Nachweisgrenze -- ohne leere Werte",
                   all(t in t1_ for t in ("RÜCKBLICK", "Urteil vom", "A Anziehung, 7 Tage (Urteil)", "B Halten, 7 Tage (Urteil)",
                                          "14 Tage (beschreibend, ohne Urteil)", "28 Tage (beschreibend, ohne Urteil)", "ZÄHLUNG auf dem Stand vom",
                                          "VORWÄRTSTEIL", "noch kein Urteil (2 Wochen von 52)", "NACHWEISGRENZE", "Lesart: ", "Abgleich mit S3",
                                          "F2 Stops", "bestanden", "· belegt"))
                   and not re.search(r"\b(None|nan|NaN|inf)\b", t1_), f"{[z_ for z_ in t1_.splitlines() if re.search(r'None|nan|NaN', z_)][:3]}")
                con = AU.verbinden(AU.ausblick_pfad("x"))
                Ub = copy.deepcopy(St2["urteil"]); Ub["h"]["7"]["A"]["arten"]["swing"].update(urteil="nicht belegt")
                Ub["h"]["7"]["B"]["arten"]["rund"].update(urteil="belegt", gamma=-0.5, ame=-9.0)
                _setzen(con, "urteil", T1, Ub); con.close()
                k2 = kurz("x")
                ok("Belegtes Halten: Der Satz sagt „hält“ mit den Punkten; nachgestellt wird nur bei belegter Anziehung",
                   k2["belegt"] == {} and "runde Zahl wird nach dem Erreichen seltener überschritten (hält) (-9,0 Punkte bei 7 Tagen)" in k2["satz"]
                   and "Swing" not in k2["satz"] and "Halten belegt · Art belegt seit" in k2["arten"]["rund"]
                   and "Art belegt seit" not in k2["arten"]["swing_hoch"], f"{k2['belegt']} {k2['satz']} | {k2['arten']['rund']}")
                con = AU.verbinden(AU.ausblick_pfad("x")); _setzen(con, "urteil", T1, dict(St2["urteil"], regel="U244/0")); con.close()
                r3 = im_rueckblick("x", Vp, S3p, T1 + 14 * TAG, still, 100, F=Fp); St3 = stand_lesen("x")
                ok("Neue Fassung der Regel: neu gerechnet, das alte Urteil bleibt abgelegt", r3["urteil_neu"] and St3["urteil"]["regel"] == REGEL
                   and St3["urteil"]["stand"] == T1 + 14 * TAG and (St3.get("urteil_alt_U244_0") or {}).get("regel") == "U244/0", f"{sorted(St3)}")
                os.environ["HL_AUSBLICK_DB"] = os.path.join(tmp, "b.db")
                S3x = copy.deepcopy(S3p); S3x["h"]["7"]["n"] += 1
                r4 = im_rueckblick("x", Vp, S3x, T1, still, 100, F=Fp); St4 = stand_lesen("x"); t4 = bericht_text("x", T1)
                ok("Sperre: Weicht S3 ab, gibt es kein Urteil; der Versuch steht mit Grund im Bericht",
                   not r4["urteil_neu"] and "urteil" not in St4 and "Abgleich mit S3 misslungen" in St4["versuch"]["grund"] and "Noch kein Urteil" in t4
                   and "Letzter Versuch" in t4 and "Achtung: Der Abgleich mit S3 ist in diesem Lauf misslungen" in t4 and not kurz("x")["da"], f"{sorted(St4)}")
                r5 = im_rueckblick("x", Vp, S3p, T1 + TAG, still, 100, F=Fp); St5 = stand_lesen("x")
                ok("Sperre gelöst: Urteil gerechnet, der Versuch ist gelöscht", r5["urteil_neu"] and "urteil" in St5 and "versuch" not in St5, f"{sorted(St5)}")
                os.environ["HL_AUSBLICK_DB"] = os.path.join(tmp, "c.db")
                r6 = im_rueckblick("x", V0, S3, T1, still, 200, F=F0); k6 = kurz("x"); U6 = stand_lesen("x")["urteil"]
                keins = all(e_.get("urteil") != "belegt" for ms in ("A", "B") for e_ in U6["h"]["7"][ms]["arten"].values())
                ok("Markt ohne Effekt: nichts belegt, Satz „ohne belegte Wirkung“, nichts nachzustellen",
                   r6["urteil_neu"] and keins and k6["satz"] == SATZ_OHNE and k6["belegt"] == {}
                   and re.match(r"^swing · erreicht \d+ % bei \d+ % erwartet \(n [\d.]+\) · Anziehung (nicht belegt|Hinweis) · Halten (nicht belegt|Hinweis)$",
                                k6["arten"]["swing_hoch"]) is not None, f"{k6['satz']} | {k6['arten']['swing_hoch']}")
                ok("Urteil nur für 7 Tage: 14 und 28 Tage ohne Urteil und ohne Holm",
                   all("urteil" not in e_ and "p_holm" not in e_ for h in ("14", "28") for ms in ("A", "B") for e_ in U6["h"][h][ms]["arten"].values())
                   and any(e_.get("p") is not None for e_ in U6["h"]["14"]["A"]["arten"].values()))
            finally:
                if alt_env is None:
                    os.environ.pop("HL_AUSBLICK_DB", None)
                else:
                    os.environ["HL_AUSBLICK_DB"] = alt_env

    def nachweis():
        N = NACHWEIS; G = N.get("grenze") or {}; T = N.get("treffer") or {}
        grenze_hand = {a: {ms: next((round(abs(g)) for g, k in zip(N["gemessen"][a][ms], T[a][ms]) if k is not None and k >= 8), None)
                           for ms in ("A", "B")} for a in ("swing", "rund")}
        ok("Nachweisgrenze: vor dem ersten Lauf gemessen und eingetragen (swing und rund, beide Maße); Grenze = kleinste gemessene Wirkung mit "
           "mindestens 8 von 10; Fehlalarm höchstens 5 %; gemessen mit der Regel, die gilt",
           bool(N.get("stand")) and N.get("regel") == SPIEGEL_REGEL and G == grenze_hand
           and all(len(T[a][ms]) == len(N["stufen"][ms]) == len(N["gemessen"][a][ms]) == len(N["treffer_streng"][a][ms]) for a in T for ms in T[a])
           and bool(N.get("fehlalarm")) and N["fehlalarm"][0] <= 0.05 * N["fehlalarm"][1] + 1e-9
           and grenze_text("swing", "A") == "Nachweisgrenze 4 Punkte" and grenze_text("rund", "B") == "Nachweisgrenze 11 Punkte"
           and grenze_text("bein", "B", {"arten": {"bein": {"se": 0.2}, "rund": {"se": 0.1}}}) == "Nachweisgrenze überschlagen rund 22 Punkte"
           and grenze_text("bein", "A") == "Nachweisgrenze nicht gemessen"
           and any("swing, B Halten: -7,4 Punkte: 9 von 10 (5)" in z_ for z_ in nachweis_zeilen()), f"{N} | {grenze_hand} | {nachweis_zeilen()[1:5]}")
        ok("Feste Größen der Regel: Urteil bei 7 Tagen, zulässig 0,05 bis 0,95, 2.000 Wiederholungen, Vorwärtsteil ab 11.10.2026, Blicke nach 52 und "
           "104 Wochen", H_PRIM == 7 and (PE_MIN, PE_MAX) == (0.05, 0.95) and REPS == 2000 and ALPHA == 0.05 and SPIEGEL_SE == 2.0
           and AU._dt(VORWAERTS_AB) == "11.10.2026" and VORWAERTS_AB % TAG == 0 and BLICK_WOCHEN == (52, 104) and ARTEN == ("swing", "rund", "ma50", "ma200", "bein")
           and (N_MIN, N_MIN_AUSGANG, W_MIN, W_URTEIL) == (100, 20, 30, 100) and REGEL == "U244/1")
        ok("Art-Kennungen der Prognose: jede Familie und jede Art des Rückblicks ist zugeordnet",
           {v for v in ART_ZU.values()} == set(ARTEN) | {f for f, *_ in FAMILIEN}
           and {k for k, v in ART_ZU.items() if v in ("F1", "F2", "F3", "F4")} == {k for _a, k, *_r in CB.ORDER_ARTEN} | {"liq_long", "liq_short"})

    gruppe("Statistik", stat)
    gruppe("Markt", markt)
    gruppe("Nachweisgrenze", nachweis)
    n_ok = sum(erg)
    print(f"Selbsttest hl_niveaus: {n_ok} von {len(erg)} Proben bestanden")
    return n_ok == len(erg)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Niveaus: Bilanz je Art (U244)")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (ausblick.db liegt daneben)")
    ap.add_argument("--bericht", action="store_true", help="Debug 149: gespeichertes Urteil, Zählung, Vorwärtsteil (nur lesen)")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--nachweisgrenze", nargs="+", metavar="X",
                    help="Entwicklung: SAAT_VON SAAT_BIS [ART MASS KAPPA [ZONE]] -- synthetische Märkte durch die ganze Regel (je Markt rund eine Minute)")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.nachweisgrenze:
        x = a.nachweisgrenze
        for saat in range(int(x[0]), int(x[1]) + 1):
            r = nachweis_lauf(saat, *((x[2], x[3]) + tuple(float(v) for v in x[4:]) if len(x) > 4 else ()))
            print(json.dumps(AU._ohne_nan(r), ensure_ascii=False), flush=True)
        return 0
    db = a.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db")
    print(bericht_text(db))
    return 0


if __name__ == "__main__":
    sys.exit(main())
