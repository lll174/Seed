# KONZEPT Niveaus (U244) — tragen Niveau-Arten mehr als ihren Abstand? Anziehung und Halten über 7, 14 und 28 Tage

Stand 11.11.2026, abends. **Vorab festgelegt**, bevor irgendein Teil auf echten Daten gerechnet wurde (Fable 5.2).
Anlass: Wunsch des Nutzers vom 11.11. 20:25 („den Trend … mit einem mehrwöchigen Horizont und die Levels vorhersagen“) und sein
„Ja“ um 20:47 zum Vorschlag aus dem Audit (`AUDIT_Gesamt_11-11-2026.md`, Nachtrag). **Status: Konzept, nichts gebaut.**
Offenlegung: `s3_ziellevels` legt seit 23.66 je Niveau-Art Anzahl, mittlere Wahrscheinlichkeit und Quote im Rückblick ab
(`je_art`). Der Text-Bericht (Debug 73) zeigt sie nicht; ich habe diese Zahlen beim Schreiben nicht gesehen.

---

## 0. Kurzfassung

- **Frage:** Wird ein Swing-Niveau, eine runde Zahl, eine Durchschnittslinie oder ein Hyperliquid-Cluster öfter (oder seltener)
  erreicht, als sein Abstand erwarten lässt? Und schließt der Kurs nach dem Erreichen öfter (oder seltener) jenseits davon?
- **Warum:** Der Ausblick gibt heute jedem Niveau die Wahrscheinlichkeit seines Abstands. Zwei Niveaus beim selben Kurs
  bekommen dieselbe Zahl. Ob die *Art* etwas beiträgt, ist nie gemessen worden.
- **Zwei Teile:**
  1. *Rückblick* ab 2022 für Niveaus aus dem Kurs (Swing, runde Zahl, 50- und 200-Tage-Linie, Bein). Urteil sofort möglich.
  2. *Vorwärts* ab 11.10.2026 für Momentaufnahmen von Hyperliquid (Take-Profits, Stops, Liquidationscluster, Wände). Bis zum
     Urteil nur Zählung.
- **Vergleich:** immer gegen die Prüfniveaus des Ausblicks, also beliebige Kurse mit derselben Modell-Wahrscheinlichkeit.
- **Kein Signal, keine Empfehlung.** Ein belegtes Ergebnis ändert nur die angezeigte Wahrscheinlichkeit der Art.

## 1. Was schon bekannt ist (Stand 11.11.2026)

| Quelle | Ergebnis | Lücke |
|---|---|---|
| Ausblick S3, Rückblick 08.11. | Erreich-Wahrscheinlichkeiten bestehen: Brier-Skill +6,2 / +3,7 / +1,5 % bei 7 / 14 / 28 T, Steigung 0,96 / 0,92 / 0,89, n 15.412 | alle Arten in einem Topf |
| Vorwärtsbilanz | Deckung der Bänder; `au_vorwaerts` speichert je Niveau Art, Preis, Erreich- und Schluss-Wahrscheinlichkeit und „erreicht“ | keine Bilanz je Art, „Schluss jenseits“ nicht ausgewertet |
| Magnet-Test U110 (1 h, 4 h; 64,7 Tage) | alle Klassen nicht belegt; große Cluster BTC 1 h berührt 10,6 % statt 6,2 % (+4,2 ± 2,1) | nur Stunden, nur Cluster |
| Konfluenz-Zonen | 46 erreicht, danach 4 h in Zonenrichtung 46 % bei 46 % Zufall | n klein |
| U141 | Rallyes und Rücksetzer wie ein Zufallsweg | — |

Hintergrund aus der Literatur: Osler (2003, Journal of Finance 58, 1791–1819) fand im Devisenhandel, dass sich Take-Profit-Orders
an runden Zahlen ballen und Stop-Loss-Orders knapp dahinter. Das würde Umkehr *an* solchen Marken und Beschleunigung *nach* ihrem
Durchbruch erklären. Hyperliquid zeigt diese Orders direkt; der Vorwärtsteil prüft genau das.
Quelle: https://ideas.repec.org/a/bla/jfinan/v58y2003i5p1791-1819.html

## 2. Fälle, Niveaus, Ergebnisse

**Fall** = (Coin, Ursprung τ, Horizont h, Niveau L). d = ln(L ÷ C_τ); Seite = oben (d > 0) oder unten.

**Ursprünge im Rückblick:** wie S3 — Montag 00:00 UTC ab 01.01.2022, je Coin. Horizonte 7, 14, 28 Tage.
**Primär ist 7 Tage.** 14 und 28 Tage werden nur beschreibend berichtet (dort hat der Ausblick kaum noch Vorsprung).

**Niveau-Arten im Rückblick** (alles aus Daten vor τ):

| Kennung | Art | Bestimmung |
|---|---|---|
| ref | Prüfniveaus (Referenz) | C · e^{±k·√F}, k = 0,5 / 1 / 1,5 / 2 (wie S3) |
| swing | Swing-Hoch, Swing-Tief | die zwei nächsten je Seite innerhalb ±30 % (`_swing_niveaus`, n 5, 365 Tage) |
| rund | runde Zahl | die nächste je Seite (`hl_chartbild.runde`) |
| ma50 | 50-Tage-Linie | Tagesschlüsse bis zum Vortag |
| ma200 | 200-Tage-Linie | Tagesschlüsse bis zum Vortag |
| bein | Bestätigungsschwelle des laufenden Beins (U141) | nur, wenn `hl_chartbild` sie je Ursprung kausal liefert; die Entscheidung fällt vor dem ersten Lauf und wird in Abschnitt 11 nachgetragen |

**Modellgrößen** je Fall aus `erreichen(S, d, h)`, unverändert: pe = Erreich-Wahrscheinlichkeit, ps = Wahrscheinlichkeit, am Tag h
jenseits von L zu schließen; q = ps ÷ pe.

**Ergebnisse:**
- ja = 1, wenn ein Tageshoch (L oben) oder Tagestief (L unten) bis Tag h das Niveau erreicht (wie S3).
- z = 1, wenn der Schluss am Tag h jenseits von L liegt.

**Zulässig:** für A nur Fälle mit 0,05 ≤ pe ≤ 0,95; für B zusätzlich ja = 1 und 0,05 ≤ q ≤ 0,95. Fast sichere und fast
unmögliche Niveaus tragen keine Information.

**Coins:** BTC, ETH, HYPE, ZEC, XMR gepoolt. PAXG getrennt und nur beschreibend (sein 80-%-Band trifft 58–67 %).

## 3. Maße

- **A Anziehung:** logit P(ja) = a + b · logit(pe) + c · [oben] + γ_Art, Referenz ref.
  γ > 0: Die Art wird öfter erreicht als ein beliebiger Kurs mit derselben Modell-Wahrscheinlichkeit; γ < 0: seltener.
- **B Halten:** auf den erreichten Fällen logit P(z) = a′ + b′ · logit(q) + c′ · [oben] + δ_Art, Referenz ref.
  δ < 0: Nach dem Erreichen schließt der Kurs seltener jenseits — das Niveau hält. δ > 0: Der Durchbruch setzt sich fort.
- **Berichtet** wird je Art der mittlere Randeffekt in Prozentpunkten, mit Intervall. Daneben roh: n, mittleres pe, Quote,
  Differenz, je Seite.
- Die Terme a, b, c fangen die allgemeine Fehlkalibrierung des Fächers und eine Schieflage der Seiten ab. Gemessen wird nur, was
  die Art darüber hinaus beiträgt.

## 4. Tests und Urteile

- **Unsicherheit:** stationärer Blockbootstrap über Ursprungswochen (alle Coins und Niveaus einer Woche bleiben zusammen), mittlere
  Blocklänge 2h Tage, 2.000 Wiederholungen — wie `KONZEPT_Ausblick.md` 5.4. p zweiseitig.
- **Familie im Rückblick:** bis zu 5 Arten × 2 Maße bei 7 Tagen = höchstens 10 Tests, Holm.
- **Belegt:** p Holm < 0,05 und dasselbe Vorzeichen in beiden Hälften. **Hinweis:** p roh < 0,05. Sonst **nicht belegt**, mit der
  Nachweisgrenze daneben (Abschnitt 5).
- **Spiegelprobe** (wie U110): Zu jedem Niveau zählt das gespiegelte (−d) als Pseudo-Art „Spiegel“. Liegt γ_Spiegel oder δ_Spiegel
  außerhalb von ±2 Standardfehlern, gilt das Urteil der Art im selben Maß als nicht belegt, mit dem Vermerk „Spiegel auffällig“.
- **Kein Urteil wird nachträglich gelockert.** Weitere Arten, andere Fenster oder Schwellen sind eine neue Runde.

## 5. Nachweisgrenze und Proben (vor dem ersten Lauf auf echten Daten)

**Nachweisgrenze**, auf den synthetischen Märkten des Ausblicks (Schwankungsballung, je Stufe 10 Märkte):
- Anziehung eingepflanzt: Drift zum Niveau innerhalb einer Tages-σ, so stark, dass die Erreichquote um 4 / 8 / 12 Punkte steigt.
- Halten eingepflanzt: Rückdrift nach der Berührung, so stark, dass P(z | ja) um 5 / 10 / 15 Punkte fällt.
- Angegeben wird je Maß der kleinste Effekt, den die Regel aus Abschnitt 4 in mindestens 8 von 10 Märkten belegt. Diese Zahl steht
  später neben jedem „nicht belegt“.
- Fehlalarm: In Märkten ohne Effekt darf in höchstens 5 % der Läufe irgendein Test der Familie „belegt“ lauten.

**Proben, je mit Mutation:**
1. Drei Ursprünge von Hand: Niveaus, pe, ps, ja, z.
2. Abgleich mit S3: Mit den Arten ref, swing, rund und ohne den Filter ergibt die neue Rechnung n und Brier des Rückblicks.
3. Kausalität: Daten nach τ ändern weder Niveaus noch pe und ps.
4. Etiketten der Arten zufällig vertauscht → kein „belegt“. Eine Art gegen sich selbst als Referenz → γ = 0.
5. Positivkontrolle und Null wie oben; Hälftenregel und Holm von Hand.

## 6. Vorwärtsteil: Momentaufnahmen von Hyperliquid

**Daten:** `au_vorwaerts` seit 11.10.2026. Je Anker und Horizont stehen dort die gezeigten Niveaus mit Art, Preis, pe und ps und die
Prüfniveaus. „Erreicht“ ist ausgewertet; „Schluss jenseits“ folgt aus dem gespeicherten y. Es geht also nichts verloren, auch wenn
der Bau später kommt.

**Verwendet** wird je Tag der Anker 00:00 UTC; Klumpen sind Wochen. Primär 7 Tage.

**Familien und erwartetes Vorzeichen** (aus Osler 2003; getestet wird zweiseitig):

| Familie | Niveaus | Erwartung bei B |
|---|---|---|
| F1 Take-Profits | Take-Profits der Longs und der Shorts | hält (δ < 0) |
| F2 Stops | Buy- und Sell-Stops, größtes Cluster | Durchbruch setzt sich fort (δ > 0) |
| F3 Liquidationen | Long- und Short-Liquidationen, größtes Cluster | Durchbruch setzt sich fort (δ > 0) |
| F4 Wände | Kauf- und Verkaufswand | hält (δ < 0) |

Maße und Regel wie in den Abschnitten 3 und 4; Familie = 4 × 2 = 8 Tests, Holm.

**Urteil in zwei Blicken** (wie `KONZEPT_Makro.md` 12.5): nach 52 Wochen belegt nur bei p Holm < 0,01; endgültig nach 104 Wochen
bei p Holm < 0,04. Das Ergebnis des ersten Berichts nach dem Stichtag wird festgehalten. **Bis dahin nur Zählung:** je Familie n,
erwartet, eingetreten — ohne p-Werte, mit dem Satz „noch kein Urteil (n Wochen von 52)“.

Der Hinweis aus `KONZEPT_Ausblick.md` 4.7 bleibt: Die Wahrscheinlichkeit gilt dem Preis; ob die Orders dann noch dort liegen, ist
offen.

## 7. Anzeige und Bericht

- **Ausblick, Tabelle „Ziellevels“:** neue Spalte „Bilanz der Art“, etwa „swing · erreicht 61 % bei 58 % erwartet (n 1.240) ·
  nicht belegt“. Die Zahlen im Beispiel sind erfunden.
- **Lesart:** ein Satz. Ohne belegte Art: „Niveau-Arten ohne belegte Wirkung — die Zahl folgt allein aus dem Abstand.“
- **Bei „belegt“:** Die Erreich- oder Schluss-Wahrscheinlichkeit dieser Art wird mit γ oder δ nachgestellt und trägt den Vermerk
  „Art belegt seit …“. Alles andere bleibt, wie es ist.
- **Debug 143:** „★ Niveaus: Bilanz je Art (U244)“ — Rückblick mit Urteil, Vorwärtsteil als Zählung, Nachweisgrenze,
  Spiegelprobe. Aufnahme in die Sammeldatei.
- **Takt:** im Sonntagslauf des Rückblicks; Ziel höchstens 2 Minuten zusätzlich auf dem Pi.

## 8. Zusagen und Abgrenzung

- Nur lesend. Geschrieben wird eine neue Tabelle in `ausblick.db`. Keine Änderung an Fächer, Tor, S1–S4, 4-h-Prognose, Labor,
  Engine oder Notbremse.
- Keine Handelsregel. Eine Regel aus einem belegten Ergebnis bräuchte einen eigenen Vorwärtstest mit Kostenschwelle.
- Die Rechnung nutzt denselben Fächer wie S3. Der Fächer selbst steht nicht zur Prüfung.

## 9. Erwartung vorab (damit nichts überrascht)

- **A Anziehung, Rückblick:** bei swing und rund nicht belegt, Effekt unter der Nachweisgrenze. Dafür sprechen U141, U110 und die
  Steigung 0,96 von S3.
- **B Halten, Rückblick:** am ehesten runde Zahlen leicht negativ. Ob das über 7 Tage sichtbar wird, ist fraglich; der Effekt aus
  der Literatur ist einer von Stunden.
- **Durchschnittslinien:** nichts.
- **Vorwärts:** offen. Mit den wenigen unabhängigen Wochen sind nur große Effekte nachweisbar.
- **Am wahrscheinlichsten:** Die Arten tragen über Wochen nichts über ihren Abstand hinaus. Auch das ist ein Ergebnis: Dann sind
  die Ziellevels Preismarken, und die Erreich-Wahrscheinlichkeit ist die ganze Aussage.

## 10. Entscheidungen beim Nutzer

1. **Zeitpunkt:** mit 23.96 zusammen mit den Sofort-Punkten des Audits oder als eigenes Paket danach? Vorschlag: eigenes Paket
   danach — erst das Messgerät.
2. **Arten:** ma50, ma200 und bein zusätzlich zu swing und rund? Vorschlag: ja.
3. **Archiv der Orderebene** (ab 22.01.2026, `RECHERCHE_Richtungstreiber_27-10-2026.md`) für einen früheren ersten Blick im
   Vorwärtsteil? Vorschlag: erst nach dem Urteil des Rückblicks entscheiden.
4. **PAXG** getrennt und nur beschreibend? Vorschlag: ja.

**Entschieden 11.11.2026 20:58 (Nutzer, „Ja“ zu allen vier Vorschlägen):**
1. eigenes Paket nach 23.96;
2. ma50, ma200 und bein kommen dazu;
3. über das Archiv der Orderebene wird erst nach dem Urteil des Rückblicks entschieden;
4. PAXG getrennt und nur beschreibend.

## 11. Vor dem Bau zu klären (wird hier nachgetragen)

- Zuordnung der gespeicherten `art`-Kennungen zu den Familien F1–F4 als feste Tabelle.
- Ob `hl_chartbild` die Bein-Schwelle je Ursprung kausal liefert (sonst entfällt die Art „bein“).
- Ob `je_art` irgendwo im Dashboard schon sichtbar ist; wenn ja, wer die Zahlen kennt.
- Nachweisgrenze aus Abschnitt 5, gemessen vor dem ersten Lauf auf echten Daten.
