# KONZEPT Niveaus (U244) — tragen Niveau-Arten mehr als ihren Abstand? Anziehung und Halten über 7, 14 und 28 Tage

Stand 11.11.2026, abends. **Vorab festgelegt**, bevor irgendein Teil auf echten Daten gerechnet wurde (Fable 5.2).
Anlass: Wunsch des Nutzers vom 11.11. 20:25 („den Trend … mit einem mehrwöchigen Horizont und die Levels vorhersagen“) und sein
„Ja“ um 20:47 zum Vorschlag aus dem Audit (`AUDIT_Gesamt_11-11-2026.md`, Nachtrag). **Status: gebaut mit Paket 23.107 (17.11.2026) -- Rückblick mit Urteil, Vorwärtsteil als
Zählung. Das Urteil rechnet der erste Rückblick des Ausblicks nach dem Einspielen, einmal. Gerechnet am 17.11.2026 auf dem Pi: für keine der fünf Arten
belegt, weder Anziehung noch Halten (Abschnitt 13).** Klarstellungen vor dem ersten Lauf: Abschnitt 11 (darin eine Änderung an der Spiegelprobe, vom Nutzer entschieden).
Nachweisgrenze, gemessen: Abschnitt 12.
Offenlegung: `s3_ziellevels` legt seit 23.66 je Niveau-Art Anzahl, mittlere Wahrscheinlichkeit und Quote im Rückblick ab
(`je_art`). Der Text-Bericht (Debug 73) zeigt sie nicht; ich habe diese Zahlen beim Schreiben nicht gesehen.

---

## 0. Kurzfassung

- **Frage:** Wird ein Swing-Niveau, eine runde Zahl, eine Durchschnittslinie oder ein Hyperliquid-Cluster öfter (oder seltener)
  erreicht, als sein Abstand erwarten lässt? Und schließt der Kurs nach dem Erreichen öfter (oder seltener) jenseits davon?
- **Warum:** Der Ausblick gibt heute jedem Niveau die Wahrscheinlichkeit seines Abstands. Zwei Niveaus beim selben Kurs
  bekommen dieselbe Zahl. Ob die *Art* etwas beiträgt, ist nie gemessen worden.
- **Zwei Teile:**
  1. *Rückblick* ab 2022 für Niveaus aus dem Kurs (Swing, runde Zahl, 50- und 200-Tage-Linie, Bein). Urteil sofort möglich.
  2. *Vorwärts* ab 11.10.2026 für Momentaufnahmen von Hyperliquid (Take-Profits, Stops, Liquidationscluster, Wände). Bis zum
     Urteil nur Zählung.
- **Vergleich:** immer gegen die Prüfniveaus des Ausblicks, also beliebige Kurse mit derselben Modell-Wahrscheinlichkeit.
- **Kein Signal, keine Empfehlung.** Ein belegtes Ergebnis ändert nur die angezeigte Wahrscheinlichkeit der Art.

## 1. Was schon bekannt ist (Stand 11.11.2026)

| Quelle | Ergebnis | Lücke |
|---|---|---|
| Ausblick S3, Rückblick 08.11. | Erreich-Wahrscheinlichkeiten bestehen: Brier-Skill +6,2 / +3,7 / +1,5 % bei 7 / 14 / 28 T, Steigung 0,96 / 0,92 / 0,89, n 15.412 | alle Arten in einem Topf |
| Vorwärtsbilanz | Deckung der Bänder; `au_vorwaerts` speichert je Niveau Art, Preis, Erreich- und Schluss-Wahrscheinlichkeit und „erreicht“ | keine Bilanz je Art, „Schluss jenseits“ nicht ausgewertet |
| Magnet-Test U110 (1 h, 4 h; 64,7 Tage) | alle Klassen nicht belegt; große Cluster BTC 1 h berührt 10,6 % statt 6,2 % (+4,2 ± 2,1) | nur Stunden, nur Cluster |
| Konfluenz-Zonen | 46 erreicht, danach 4 h in Zonenrichtung 46 % bei 46 % Zufall | n klein |
| U141 | Rallyes und Rücksetzer wie ein Zufallsweg | — |

Hintergrund aus der Literatur: Osler (2003, Journal of Finance 58, 1791–1819) fand im Devisenhandel, dass sich Take-Profit-Orders
an runden Zahlen ballen und Stop-Loss-Orders knapp dahinter. Das würde Umkehr *an* solchen Marken und Beschleunigung *nach* ihrem
Durchbruch erklären. Hyperliquid zeigt diese Orders direkt; der Vorwärtsteil prüft genau das.
Quelle: https://ideas.repec.org/a/bla/jfinan/v58y2003i5p1791-1819.html

## 2. Fälle, Niveaus, Ergebnisse

**Fall** = (Coin, Ursprung τ, Horizont h, Niveau L). d = ln(L ÷ C_τ); Seite = oben (d > 0) oder unten.

**Ursprünge im Rückblick:** wie S3 — Montag 00:00 UTC ab 01.01.2022, je Coin. Horizonte 7, 14, 28 Tage.
**Primär ist 7 Tage.** 14 und 28 Tage werden nur beschreibend berichtet (dort hat der Ausblick kaum noch Vorsprung).

**Niveau-Arten im Rückblick** (alles aus Daten vor τ):

| Kennung | Art | Bestimmung |
|---|---|---|
| ref | Prüfniveaus (Referenz) | C · e^{±k·√F}, k = 0,5 / 1 / 1,5 / 2 (wie S3) |
| swing | Swing-Hoch, Swing-Tief | die zwei nächsten je Seite innerhalb ±30 % (`_swing_niveaus`, n 5, 365 Tage) |
| rund | runde Zahl | die nächste je Seite (`hl_chartbild.runde`) |
| ma50 | 50-Tage-Linie | Tagesschlüsse bis zum Vortag |
| ma200 | 200-Tage-Linie | Tagesschlüsse bis zum Vortag |
| bein | Bestätigungsschwelle des laufenden Beins (U141) | nur, wenn `hl_chartbild` sie je Ursprung kausal liefert; die Entscheidung fällt vor dem ersten Lauf und wird in Abschnitt 11 nachgetragen |

**Modellgrößen** je Fall aus `erreichen(S, d, h)`, unverändert: pe = Erreich-Wahrscheinlichkeit, ps = Wahrscheinlichkeit, am Tag h
jenseits von L zu schließen; q = ps ÷ pe.

**Ergebnisse:**
- ja = 1, wenn ein Tageshoch (L oben) oder Tagestief (L unten) bis Tag h das Niveau erreicht (wie S3).
- z = 1, wenn der Schluss am Tag h jenseits von L liegt.

**Zulässig:** für A nur Fälle mit 0,05 ≤ pe ≤ 0,95; für B zusätzlich ja = 1 und 0,05 ≤ q ≤ 0,95. Fast sichere und fast
unmögliche Niveaus tragen keine Information.

**Coins:** BTC, ETH, HYPE, ZEC, XMR gepoolt. PAXG getrennt und nur beschreibend (sein 80-%-Band trifft 58–67 %).

## 3. Maße

- **A Anziehung:** logit P(ja) = a + b · logit(pe) + c · [oben] + γ_Art, Referenz ref.
  γ > 0: Die Art wird öfter erreicht als ein beliebiger Kurs mit derselben Modell-Wahrscheinlichkeit; γ < 0: seltener.
- **B Halten:** auf den erreichten Fällen logit P(z) = a′ + b′ · logit(q) + c′ · [oben] + δ_Art, Referenz ref.
  δ < 0: Nach dem Erreichen schließt der Kurs seltener jenseits — das Niveau hält. δ > 0: Der Durchbruch setzt sich fort.
- **Berichtet** wird je Art der mittlere Randeffekt in Prozentpunkten, mit Intervall. Daneben roh: n, mittleres pe, Quote,
  Differenz, je Seite.
- Die Terme a, b, c fangen die allgemeine Fehlkalibrierung des Fächers und eine Schieflage der Seiten ab. Gemessen wird nur, was
  die Art darüber hinaus beiträgt.

## 4. Tests und Urteile

- **Unsicherheit:** stationärer Blockbootstrap über Ursprungswochen (alle Coins und Niveaus einer Woche bleiben zusammen), mittlere
  Blocklänge 2h Tage, 2.000 Wiederholungen — wie `KONZEPT_Ausblick.md` 5.4. p zweiseitig.
- **Familie im Rückblick:** bis zu 5 Arten × 2 Maße bei 7 Tagen = höchstens 10 Tests, Holm.
- **Belegt:** p Holm < 0,05 und dasselbe Vorzeichen in beiden Hälften. **Hinweis:** p roh < 0,05. Sonst **nicht belegt**, mit der
  Nachweisgrenze daneben (Abschnitt 5).
- **Spiegelprobe** (wie U110): Zu jedem Niveau zählt das gespiegelte (−d) als Pseudo-Art „Spiegel“. Liegt γ_Spiegel oder δ_Spiegel
  außerhalb von ±2 Standardfehlern, gilt das Urteil der Art im selben Maß als nicht belegt, mit dem Vermerk „Spiegel auffällig“.
  *(Vor dem ersten Lauf geändert, 16.11.2026: Abschnitt 11, Punkt 10. Diese Fassung wird mitgerechnet und daneben gezeigt.)*
- **Kein Urteil wird nachträglich gelockert.** Weitere Arten, andere Fenster oder Schwellen sind eine neue Runde.

## 5. Nachweisgrenze und Proben (vor dem ersten Lauf auf echten Daten)

**Nachweisgrenze**, auf den synthetischen Märkten des Ausblicks (Schwankungsballung, je Stufe 10 Märkte):
- Anziehung eingepflanzt: Drift zum Niveau innerhalb einer Tages-σ, so stark, dass die Erreichquote um 4 / 8 / 12 Punkte steigt.
- Halten eingepflanzt: Rückdrift nach der Berührung, so stark, dass P(z | ja) um 5 / 10 / 15 Punkte fällt.
- Angegeben wird je Maß der kleinste Effekt, den die Regel aus Abschnitt 4 in mindestens 8 von 10 Märkten belegt. Diese Zahl steht
  später neben jedem „nicht belegt“.
- Fehlalarm: In Märkten ohne Effekt darf in höchstens 5 % der Läufe irgendein Test der Familie „belegt“ lauten.

**Proben, je mit Mutation:**
1. Drei Ursprünge von Hand: Niveaus, pe, ps, ja, z.
2. Abgleich mit S3: Mit den Arten ref, swing, rund und ohne den Filter ergibt die neue Rechnung n und Brier des Rückblicks.
3. Kausalität: Daten nach τ ändern weder Niveaus noch pe und ps.
4. Etiketten der Arten zufällig vertauscht → kein „belegt“. Eine Art gegen sich selbst als Referenz → γ = 0.
5. Positivkontrolle und Null wie oben; Hälftenregel und Holm von Hand.

## 6. Vorwärtsteil: Momentaufnahmen von Hyperliquid

**Daten:** `au_vorwaerts` seit 11.10.2026. Je Anker und Horizont stehen dort die gezeigten Niveaus mit Art, Preis, pe und ps und die
Prüfniveaus. „Erreicht“ ist ausgewertet; „Schluss jenseits“ folgt aus dem gespeicherten y. Es geht also nichts verloren, auch wenn
der Bau später kommt.

**Verwendet** wird je Tag der Anker 00:00 UTC; Klumpen sind Wochen. Primär 7 Tage.

**Familien und erwartetes Vorzeichen** (aus Osler 2003; getestet wird zweiseitig):

| Familie | Niveaus | Erwartung bei B |
|---|---|---|
| F1 Take-Profits | Take-Profits der Longs und der Shorts | hält (δ < 0) |
| F2 Stops | Buy- und Sell-Stops, größtes Cluster | Durchbruch setzt sich fort (δ > 0) |
| F3 Liquidationen | Long- und Short-Liquidationen, größtes Cluster | Durchbruch setzt sich fort (δ > 0) |
| F4 Wände | Kauf- und Verkaufswand | hält (δ < 0) |

Maße und Regel wie in den Abschnitten 3 und 4; Familie = 4 × 2 = 8 Tests, Holm.

**Urteil in zwei Blicken** (wie `KONZEPT_Makro.md` 12.5): nach 52 Wochen belegt nur bei p Holm < 0,01; endgültig nach 104 Wochen
bei p Holm < 0,04. Das Ergebnis des ersten Berichts nach dem Stichtag wird festgehalten. **Bis dahin nur Zählung:** je Familie n,
erwartet, eingetreten — ohne p-Werte, mit dem Satz „noch kein Urteil (n Wochen von 52)“.

Der Hinweis aus `KONZEPT_Ausblick.md` 4.7 bleibt: Die Wahrscheinlichkeit gilt dem Preis; ob die Orders dann noch dort liegen, ist
offen.

## 7. Anzeige und Bericht

- **Ausblick, Tabelle „Ziellevels“:** neue Spalte „Bilanz der Art“, etwa „swing · erreicht 61 % bei 58 % erwartet (n 1.240) ·
  nicht belegt“. Die Zahlen im Beispiel sind erfunden.
- **Lesart:** ein Satz. Ohne belegte Art: „Niveau-Arten ohne belegte Wirkung — die Zahl folgt allein aus dem Abstand.“
- **Bei „belegt“:** Die Erreich- oder Schluss-Wahrscheinlichkeit dieser Art wird mit γ oder δ nachgestellt und trägt den Vermerk
  „Art belegt seit …“. Alles andere bleibt, wie es ist.
- **Debug 149** (143 und 144 gingen mit 23.98 an das Cockpit, 145 und 146 mit 23.100 an das Unstaking, 147 und 148 mit 23.101 an dessen Prüfung der Kursfolge)**:** „★ Niveaus: Bilanz je Art (U244)“ — Rückblick mit Urteil, Vorwärtsteil als Zählung, Nachweisgrenze,
  Spiegelprobe. Aufnahme in die Sammeldatei. **Debug 150:** Selbsttest. Das Urteil rechnet der Rückblick des Ausblicks (Debug 75
  rechnet ihn sofort); Debug 149 liest nur.
- **Takt:** im Sonntagslauf des Rückblicks; Ziel höchstens 2 Minuten zusätzlich auf dem Pi.

## 8. Zusagen und Abgrenzung

- Nur lesend. Geschrieben wird eine neue Tabelle in `ausblick.db`. Keine Änderung an Fächer, Tor, S1–S4, 4-h-Prognose, Labor,
  Engine oder Notbremse.
- Keine Handelsregel. Eine Regel aus einem belegten Ergebnis bräuchte einen eigenen Vorwärtstest mit Kostenschwelle.
- Die Rechnung nutzt denselben Fächer wie S3. Der Fächer selbst steht nicht zur Prüfung.

## 9. Erwartung vorab (damit nichts überrascht)

- **A Anziehung, Rückblick:** bei swing und rund nicht belegt, Effekt unter der Nachweisgrenze. Dafür sprechen U141, U110 und die
  Steigung 0,96 von S3.
- **B Halten, Rückblick:** am ehesten runde Zahlen leicht negativ. Ob das über 7 Tage sichtbar wird, ist fraglich; der Effekt aus
  der Literatur ist einer von Stunden.
- **Durchschnittslinien:** nichts.
- **Vorwärts:** offen. Mit den wenigen unabhängigen Wochen sind nur große Effekte nachweisbar.
- **Am wahrscheinlichsten:** Die Arten tragen über Wochen nichts über ihren Abstand hinaus. Auch das ist ein Ergebnis: Dann sind
  die Ziellevels Preismarken, und die Erreich-Wahrscheinlichkeit ist die ganze Aussage.

## 10. Entscheidungen beim Nutzer

1. **Zeitpunkt:** mit 23.96 zusammen mit den Sofort-Punkten des Audits oder als eigenes Paket danach? Vorschlag: eigenes Paket
   danach — erst das Messgerät.
2. **Arten:** ma50, ma200 und bein zusätzlich zu swing und rund? Vorschlag: ja.
3. **Archiv der Orderebene** (ab 22.01.2026, `RECHERCHE_Richtungstreiber_27-10-2026.md`) für einen früheren ersten Blick im
   Vorwärtsteil? Vorschlag: erst nach dem Urteil des Rückblicks entscheiden.
4. **PAXG** getrennt und nur beschreibend? Vorschlag: ja.

**Entschieden 11.11.2026 20:58 (Nutzer, „Ja“ zu allen vier Vorschlägen):**
1. eigenes Paket nach 23.96;
2. ma50, ma200 und bein kommen dazu;
3. über das Archiv der Orderebene wird erst nach dem Urteil des Rückblicks entschieden;
4. PAXG getrennt und nur beschreibend.

## 11. Klarstellungen vor dem ersten Lauf (16.11.2026, Paket 23.107)

Die Abschnitte 1 bis 10 bleiben, wie sie am 11.11.2026 festgelegt wurden -- mit einer Ausnahme, die der Nutzer entschieden hat (Punkt 10,
Spiegelprobe). Beim Bau waren Einzelheiten festzulegen, die dort offen sind. Sie stehen hier, festgelegt vor dem ersten Lauf auf echten
Kursen. **Offenlegung:** In der Sandbox liegen keine Daten vom Pi. Die Rechnung lief bis zur Lieferung nur auf erfundenen Märkten
(Abschnitt 12) und auf den Demo-Datenbanken der Selbsttests. Die Zahlen `je_art` von S3 kenne ich weiterhin nicht.

**Die vier Punkte von damals**
- **Art-Kennungen des Vorwärtsteils** (so speichert `au_vorwaerts` sie seit 11.10.2026): F1 Take-Profits = `tp_sell`, `tp_buy`; F2 Stops =
  `stop_sell`, `stop_buy`; F3 Liquidationen = `liq_long`, `liq_short`; F4 Wände = `limit_buy`, `limit_sell`. Für Stops und Liquidationen
  speichert der Ausblick je Art bis zu zwei Niveaus mit derselben Kennung (größtes und nächstes Cluster), das nächste nur, wenn es näher
  am Kurs liegt als das größte. „Größtes Cluster“ ist deshalb: das einzige oder das fernere von zweien. Die Kennungen der Niveaus aus dem
  Kurs in der Prognose: `swing_hoch`, `swing_tief` → swing; `rund`; `ma50_` → ma50; `ma200`; `bein`.
- **Bein-Schwelle:** ja, kausal. `hl_chartbild.beine_stand` liefert sie für jede bis zum Ursprung abgeschnittene Reihe; der Zustand am
  Tag t hängt nur an den Schlüssen bis t. Die Art „bein“ ist dabei (Schwelle 10 %, bei PAXG 3 %; auf der Tagesachse des Ausblicks). Der
  Selbsttest vergleicht jeden Tag mit den Regeln von `hl_zyklus` und Stichproben mit `hl_chartbild`.
- **`je_art`:** nirgends zu sehen -- weder im Dashboard noch in Debug 73. Die Zahlen stehen in `au_rueckblick` und gehen mit `/ausblick`
  an den Browser, werden dort aber nicht gezeigt.
- **Nachweisgrenze:** gemessen, Abschnitt 12.

**Was der Text offen ließ**
1. **Ein Urteil, nicht viele.** Das Urteil des Rückblicks wird einmal gerechnet -- im ersten Rückblick des Ausblicks nach dem Einspielen
   (sonntags ab 02:00 UTC; sofort mit Debug 75) -- und festgehalten: Tabelle `au_niveaus` in `ausblick.db`, mit Datum, Fassung `U244/1`
   und Prüfsumme der Eingabe. Jede Woche neu sind nur die rohe Zählung je Art (n, erwartet, eingetreten) und der Vorwärtsteil. Neu
   gerechnet wird nur mit einer neuen Fassung der Regel; das alte Urteil bleibt abgelegt. Grund: Ein wöchentlich neu gerechneter Test
   wären viele Blicke auf fast dieselben Daten. (Abschnitt 7 nennt den Sonntagslauf als Takt; das gilt für Zählung und Bericht.)
2. **Sperren.** Kein Urteil, wenn die neue Rechnung n und Brier von S3 nicht genau trifft (Probe 2 aus Abschnitt 5, hier auf den Daten
   des Laufs: Arten ref, swing, rund, ohne Filter, alle Coins des Rückblicks), und keines mit weniger als 100 Ursprungswochen. Der
   Versuch steht mit seinem Grund in Debug 149; der nächste Rückblick versucht es wieder.
3. **Niveaus je Ursprung.** ref, swing, rund genau wie S3. ma50 und ma200: Mittel der letzten 50 und 200 Tagesschlüsse bis zum Schluss um
   00:00 UTC des Ursprungs (das ist der Schluss des Vortags), nur wenn alle Tage da sind. bein: die Schwelle nach diesem Schluss. Liegt
   der Vortag nicht an seiner Stelle der Tagesachse (Lücke in den Daten), zählt der Fall nur im Abgleich mit S3.
4. **Ergebnisse.** ja wie S3: Hoch oder Tief der 24-Stunden-Blöcke der Tage 1 bis h. z: Schluss am Tag h auf oder jenseits des Niveaus
   (so zählt auch `erreichen` die Schluss-Wahrscheinlichkeit).
5. **Zulässig:** Die Grenzen zählen mit (0,05 ≤ pe ≤ 0,95; ebenso q).
6. **Ein Test je Art und Maß nur** mit mindestens 100 zulässigen Fällen, mindestens 20 je Ausgang und mindestens 30 Ursprungswochen. Sonst
   „kein Test“ mit Grund; die Art gehört dann nicht zur Familie. Dasselbe gilt für ihren Spiegel.
7. **Regression.** Eine je Maß und Horizont über Referenz, Arten und Spiegel; γ je Art und je Spiegel der Art (jede Art hat ihren eigenen
   Spiegel, nicht alle einen gemeinsamen). Randeffekt = Mittel über die Fälle der Art von σ(η) − σ(η − γ), in Prozentpunkten.
8. **Unsicherheit.** Stationärer Blockbootstrap über Ursprungswochen; mittlere Blocklänge 2h Tage, also 2, 4 und 8 Wochen; 2.000
   Wiederholungen, je Wiederholung neu geschätzt; feste Saat. p zweiseitig aus der zentrierten Verteilung: (1 + Zahl der Wiederholungen
   mit |γ* − γ| ≥ |γ|) ÷ 2.001. Intervall des Randeffekts: 2,5- und 97,5-%-Punkt der Wiederholungen.
9. **Hälften.** Die Ursprungswochen nach der Zeit in zwei Hälften, γ je Hälfte neu geschätzt. „Dasselbe Vorzeichen“ heißt: beide wie das
   Ganze. Lässt sich eine Hälfte nicht schätzen, gilt die Bedingung als nicht erfüllt.
10. **Spiegelprobe -- geändert gegenüber Abschnitt 4 (Entscheidung des Nutzers, 16.11.2026 gegen 23:27, vor dem ersten Lauf).**
    Abschnitt 4 legt fest: Liegt der Spiegel außerhalb von ±2 Standardfehlern, gilt die Art als nicht belegt. Auf den erfundenen Märkten
    mit eingebautem Effekt verwarf diese Fassung echte Effekte, und zwar umso öfter, je stärker sie waren (Abschnitt 12): Ein Niveau, das
    den Kurs wirklich anzieht oder hält, verschiebt auch die Quote seines Spiegels. Auf die Frage zum Anklicken -- mit den Zahlen beider
    Fassungen -- wählte der Nutzer „Verfeinern“. **Es gilt:** Eine Art ist nur belegt, wenn sie ihren eigenen Spiegel schlägt: Der
    Abstand γ − γ_Spiegel liegt in der Richtung von γ und über zwei Standardfehlern des Abstands (aus denselben Wiederholungen). Sonst
    wird aus „belegt“ oder „Hinweis“ ein „nicht belegt“ mit dem Vermerk „vom Spiegel nicht zu unterscheiden“. Ohne Spiegel (zu wenige
    Fälle) gibt es kein „belegt“. Die Fassung vom 11.11. wird weiter mitgerechnet; weicht ihr Urteil ab, steht es im Bericht daneben.
    Die übrige Regel (p nach Holm unter 0,05, gleiche Hälften) ist unverändert. Offen gesagt: Die Änderung macht die Regel durchlässiger
    für echte Effekte; der Fehlalarm blieb auf den Märkten ohne Effekt in beiden Fassungen bei 0 von 40.
11. **Familie.** Alle Arten mit Test × beide Maße bei 7 Tagen, Holm über genau diese. 14 und 28 Tage: dieselbe Rechnung ohne Holm und
    ohne Urteil.
12. **PAXG:** rohe Zahlen je Art, ohne Test.
13. **Vorwärtsteil.** Anker 00:00 UTC ab 11.10.2026, 7 Tage, Krypto-Coins gepoolt, PAXG daneben; eine Woche reicht von Montag bis
    Sonntag; zulässig wie im Rückblick; „Schluss jenseits“ aus dem gespeicherten y. Die Prüfniveaus stehen in `au_vorwaerts` ohne
    „erreicht“ -- für das Urteil nach 52 Wochen ist ihr Erreichen aus den Kerzen nachzurechnen (U265). Bis dahin Zählung.
14. **Anzeige bei „belegt“.** Bei belegter Anziehung wird die Erreich-Wahrscheinlichkeit für 1 Woche mit γ nachgestellt (logit(p) + γ,
    höchstens bis zur Zahl für 2 Wochen) und trägt Stern und Vermerk; 2 und 4 Wochen bleiben. Ein belegtes Halten steht als Text da: Die Tabelle zeigt „Schluss jenseits“
    nur für 4 Wochen, das Urteil gilt für 7 Tage.

**Wo es steht:** Modul `hl_niveaus.py`; **Debug 149** „★ Niveaus: Bilanz je Art (U244)“ (liest nur), **Debug 150** Selbsttest; das Urteil
rechnet der Rückblick des Ausblicks (**Debug 75** rechnet ihn sofort). Im Ausblick: Spalte „Bilanz der Art“ in der Tabelle „Ziellevels“
und ein Satz in der Lesart; Debug 73 trägt den Satz am Ende. Sonntags um 08:30 legt der Berichtsplan Debug 149 zu den neuen Berichten.

## 12. Nachweisgrenze und Proben -- gemessen vor dem ersten Lauf (16.11.2026)

**Märkte.** Die synthetischen Märkte des Ausblicks (`hl_regime._markt`: Schwankungsregime als log-AR(1), t-verteilte Renditen,
30-Minuten-Kerzen), je Markt 5 Coins vom 01.05.2019 bis 10.11.2026, derselbe Weg wie im Betrieb (Anker, HAR-Breite, Bibliothek); rund 250
Montage je Coin. Je Stufe 10 Märkte, ohne Effekt 40 Märkte. Jeder Markt lief durch die ganze Regel (7 Tage, beide Maße, Familie mit
Holm, Hälften, Spiegelprobe).

**Eingepflanzt** wurde je eine Art (swing oder rund) in einem Maß:
- *Anziehung:* Liegt das nächste noch nicht berührte Niveau nahe genug, driftet der Kurs je Kerze darauf zu; nach der Berührung ruht das
  Niveau sieben Tage.
- *Halten:* Nach dem Überschreiten eines Niveaus driftet der Kurs zurück, solange er höchstens eine Tagesschwankung jenseits liegt
  (längstens sieben Tage).
- Die Stärke ist so gewählt, dass die rohe Wirkung (eingetreten − erwartet) die Stufe trifft; angegeben ist die gemessene Wirkung.

**Abweichungen von Abschnitt 5, offen gesagt**
- Eine Anziehung „innerhalb einer Tages-σ“ sättigt bei rund 4 Punkten: Wer so nah ist, erreicht das Niveau meist ohnehin. Für 8 und 12
  Punkte reicht die Zone deshalb bis drei Tagesschwankungen (bei 4 Punkten: anderthalb).
- Bei runden Zahlen ließ sich keine Anziehung über rund 4 Punkte einpflanzen: Je Ursprung liegt eine runde Zahl über und eine unter dem
  Kurs; was die eine anzieht, fehlt der anderen. Gemessen ist dort nur diese eine Stufe.
- Beim Halten fielen die Stufen etwas größer aus als geplant (statt 5, 10 und 15 Punkten gemessen 5,9 bis 7,4, rund 11 und rund 16).

**Ergebnis** (Märkte von 10, in denen die eingepflanzte Art im eingepflanzten Maß mit dem richtigen Vorzeichen „belegt“ wurde)

| Art, Maß | gemessene Wirkung in Punkten | Regel (verfeinerte Spiegelprobe) | Fassung vom 11.11. | Nachweisgrenze |
|---|---|---|---|---|
| swing, A Anziehung | +4,4 / +8,4 / +11,6 | 10 / 10 / 10 | 9 / 8 / 5 | 4 Punkte |
| rund, A Anziehung | +4,4 | 10 | 8 | 4 Punkte |
| swing, B Halten | −7,4 / −11,1 / −16,0 | 9 / 10 / 10 | 5 / 3 / 8 | 7 Punkte |
| rund, B Halten | −5,9 / −11,2 / −16,3 | 7 / 10 / 10 | 5 / 6 / 6 | 11 Punkte |

- **Fehlalarm:** In 0 von 40 Märkten ohne Effekt sagte irgendein Test der Familie „belegt“ (erlaubt: 5 %), in beiden Fassungen. Von den
  400 Tests dieser Märkte hatten 25 ein p unter 0,05 -- bei Zufall sind rund 20 zu erwarten; 20 Spiegel lagen außerhalb von ±2
  Standardfehlern.
- **Die Fassung vom 11.11. verliert an Schärfe, wo der Effekt stark ist** (swing, Anziehung: 9, 8 und 5 von 10 mit wachsender Wirkung).
  Grund: Ein echtes Niveau verändert auch die Quote seines Spiegels. Daher Punkt 10 in Abschnitt 11.
- **In den Märkten mit eingepflanztem Effekt wurden oft auch andere Arten „belegt“.** Ein Fehlalarm der Regel ist das nicht: Die Mechanik
  verändert den ganzen Markt (Swing-Niveaus entstehen dort, wo der Kurs gehalten wird; Linien und Schwellen liegen in fester Lage dazu).
  Für echte Daten heißt das: Ein belegter Effekt einer Art kann von einer anderen herrühren, die am selben Kurs liegt.
- **Für ma50, ma200 und bein** ist die Grenze nicht eigens gemessen. Neben „nicht belegt“ steht ein Überschlag: die Grenze von rund, im
  Verhältnis der Standardfehler.
- Eine Nachweisgrenze von 4 bis 11 Punkten heißt: Kleinere Wirkungen bleiben unentdeckt. „Nicht belegt“ ist dann „mit diesen Daten nicht
  zu zeigen“, nicht „widerlegt“.

**Proben aus Abschnitt 5** (alle im Selbsttest, Debug 150; je mit Mutationen, Zahlen in der Übergabe): drei Ursprünge von Hand (Niveaus
aller Arten und Spiegel, pe, ps, ja, z bei 7, 14 und 28 Tagen); Abgleich mit S3 (n und Brier genau -- auch auf dem echten Weg mit HAR-X,
gepoolter Bibliothek und PAXG, im Ende-zu-Ende-Lauf des Ausblicks); Kausalität (geänderte Kurse nach dem Ursprung ändern weder Niveaus
noch pe und ps); vertauschte Etiketten (kein „belegt“); eine Art gegen sich selbst (γ = 0); Positivkontrolle und Null; Hälften, Holm und
Spiegelprobe von Hand.

**Am Rand gefunden -- S3 und sein Vergleichsmaß B1:** Fehlt einem Ursprung die 365-Tage-Schwankung (junge Historie), geht der Fall in B1
mit der Wahrscheinlichkeit 1 ein (`min(1.0, p1)` ergibt 1, wenn p1 keine Zahl ist). Der Brier von B1 fällt dadurch schlechter aus, der
Skill von S3 entsprechend besser. Wie viele Fälle das sind, zeigt Debug 149 nach dem ersten Lauf. S3 ist nicht angefasst (U264).

## 13. Urteil vom 17.11.2026 -- erster Lauf auf echten Daten (Paket 23.107 auf dem Pi; Debug 75, Debug 149)

Gerechnet im Rückblick des Ausblicks am 17.11.2026, festgehalten 09:53 UTC (Fassung U244/1, 2.000 Wiederholungen, zehn Tests in
der Familie, Prüfsumme der Eingabe fc447cac6479). Ursprünge 03.01.2022 bis 19.10.2026, 251 Wochen; BTC, ETH, HYPE, ZEC, XMR
gepoolt. Abgleich mit S3 bestanden (n 15.577 bei 7, 14 und 28 Tagen). Rechenzeit auf dem Pi 393 s (Debug 75 zusammen 795 s).

**Für keine der fünf Arten ist eine Wirkung belegt -- weder Anziehung noch Halten.**

A Anziehung, 7 Tage (22.734 Fälle; Referenz: Prüfniveaus n 7.504, erwartet 25,7 %, eingetreten 26,1 %):

| Art | n | erwartet | eingetreten | Randeffekt (95 %) | p | nach Holm | Spiegel | Nachweisgrenze |
|---|---|---|---|---|---|---|---|---|
| swing | 3.300 | 49,4 % | 49,4 % | −0,6 [−1,9; +0,7] | 0,419 | 1,000 | +1,1 | 4 Punkte |
| rund | 1.884 | 63,3 % | 63,5 % | −0,5 [−2,1; +0,9] | 0,499 | 1,000 | +1,3 | 4 Punkte |
| ma50 | 896 | 36,6 % | 37,7 % | +0,6 [−2,3; +3,5] | 0,695 | 1,000 | −1,7 | rund 8 (Überschlag) |
| ma200 | 546 | 30,7 % | 30,2 % | −0,9 [−3,9; +2,2] | 0,580 | 1,000 | −1,9 | rund 10 (Überschlag) |
| bein | 1.021 | 39,5 % | 39,9 % | −0,1 [−3,1; +2,9] | 0,947 | 1,000 | +2,1 | rund 8 (Überschlag) |

B Halten, 7 Tage (9.512 Fälle; Referenz n 1.961, erwartet 48,1 %, eingetreten 47,0 %; „−“ heißt: das Niveau hält):

| Art | n | erwartet | eingetreten | Randeffekt (95 %) | p | nach Holm | Spiegel | Nachweisgrenze |
|---|---|---|---|---|---|---|---|---|
| swing | 1.631 | 48,9 % | 45,7 % | −2,0 [−4,9; +0,9] | 0,187 | 1,000 | −0,5 | 7 Punkte |
| rund | 1.196 | 48,9 % | 49,3 % | +1,7 [−1,3; +4,9] | 0,298 | 1,000 | −2,1 | 11 Punkte |
| ma50 | 338 | 48,8 % | 44,7 % | −2,9 [−8,3; +2,7] | 0,289 | 1,000 | +3,4 | rund 19 (Überschlag) |
| ma200 | 165 | 47,3 % | 49,1 % | +2,8 [−5,0; +10,1] | 0,468 | 1,000 | +10,1 | rund 27 (Überschlag) |
| bein | 407 | 48,8 % | 43,5 % | −4,1 [−8,7; +0,6] | 0,092 | 0,925 | −2,1 | rund 17 (Überschlag) |

- **Lesart des Berichts:** Niveau-Arten ohne belegte Wirkung -- die Wahrscheinlichkeit, ein Niveau zu erreichen, folgt allein aus
  dem Abstand. Im Ausblick steht in der Spalte „Bilanz der Art“ entsprechend „nicht belegt“. *Berichtigt mit 23.110: Hier stand
  „Im Cockpit und im Ausblick“ -- das Cockpit hatte keine solche Spalte. Seit 23.110 nennt es das Urteil im Beleg der Karten
  „Levels“ und „Durchschnittslinien“.*
- **Was das nicht heißt:** „widerlegt“. Wirkungen unter der Nachweisgrenze (4 Punkte bei der Anziehung von Swing-Niveaus und runden
  Zahlen, 7 und 11 beim Halten, deutlich mehr bei den drei anderen Arten) wären unentdeckt geblieben. Am nächsten an einem Hinweis
  liegt das Halten der Bein-Schwelle (−4,1 Punkte, p 0,092, beide Hälften mit gleichem Vorzeichen); nach Holm 0,925.
- **14 und 28 Tage** (beschreibend, ohne Urteil): kein Randeffekt mit p unter 0,2.
- **Erwartung vorab (Abschnitt 9):** Der dort als am wahrscheinlichsten genannte Ausgang ist eingetreten -- die Arten tragen über
  ihren Abstand hinaus nichts Belegbares. Die Vermutung „runde Zahlen halten leicht“ zeigt sich nicht (Randeffekt +1,7 Punkte,
  nicht belegt).
- **Vorwärtsteil** (Momentaufnahmen seit 11.10.2026, 5 von 52 Wochen, ohne p-Werte): F1 Take-Profits erreicht 64 von 151 bei 59,6
  erwartet, danach Schluss jenseits 42 von 64 bei 30,8 erwartet (vorab erwartet: hält); F2 Stops 120 von 214 bei 109,5, danach 59
  von 120 bei 57,4; F3 Liquidationen 50 von 157 bei 46,6, danach 24 von 50 bei 23,4; F4 Wände 114 von 251 bei 113,0, danach 48 von
  114 bei 53,1. Erster Blick nach 52 Wochen (U265).
- **Das Urteil wird nicht neu gerechnet.** Eine neue Fassung bräuchte neue, vorab festgelegte Regeln.
