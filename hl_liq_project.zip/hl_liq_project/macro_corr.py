#!/usr/bin/env python3
"""
macro_corr.py — Prüft, welche Makro-Größen Gold und Bitcoin treiben.

Holt drei Tagesreihen und rechnet die verzögerte Korrelation der RENDITEN,
nicht der Preise. Preise zweier steigender Assets korrelieren fast immer;
das sagt nichts. Nur die Veränderungen sagen etwas.

    python macro_corr.py                      # 2 Jahre, Standardreihen
    python macro_corr.py --years 5
    python macro_corr.py --series DFII10 DGS10 DTWEXBGS
    python macro_corr.py --csv ergebnis.csv   # Rohdaten mitschreiben

Quellen, alle ohne Schlüssel:
  Realzins/Nominalzins/Dollar : FRED CSV (fredgraph.csv)
  Gold                        : Stooq (XAUUSD)
  Bitcoin                     : Binance Klines (BTCUSDT, Tagesschluss)

Abhängigkeiten: numpy (pandas nicht nötig)
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone

import numpy as np

UA = {"User-Agent": "Mozilla/5.0 (compatible; macro-corr/1.0)"}

# FRED-Serien, die als Treiber in Frage kommen
KNOWN = {
    "DFII10": "10J-Realzins (TIPS)",
    "DFII5": "5J-Realzins (TIPS)",
    "DGS10": "10J-Nominalzins",
    "T10YIE": "10J-Inflationserwartung (Breakeven)",
    "DTWEXBGS": "Dollar-Index (breit)",
    "VIXCLS": "VIX",
    "BAMLH0A0HYM2": "High-Yield-Spread",
}


def get(url: str, tries: int = 3) -> bytes:
    last = None
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA),
                                        timeout=30) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"Abruf fehlgeschlagen: {url}\n  {last}")


def fred(series: str, start: str) -> dict[str, float]:
    """Tagesreihe von FRED. '.' bedeutet Feiertag und wird übersprungen."""
    url = (f"https://fred.stlouisfed.org/graph/fredgraph.csv"
           f"?id={series}&cosd={start}")
    text = get(url).decode("utf-8", "replace")
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        vals = list(row.values())
        d, v = vals[0], vals[1]
        try:
            out[d[:10]] = float(v)
        except (TypeError, ValueError):
            continue
    if not out:
        raise RuntimeError(f"FRED-Serie {series} leer — Kürzel prüfen")
    return out


def stooq_gold(start: str) -> dict[str, float]:
    """Gold-Spot XAU/USD, Tagesschluss."""
    text = get("https://stooq.com/q/d/l/?s=xauusd&i=d").decode("utf-8", "replace")
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        d = row.get("Date", "")
        if d >= start:
            try:
                out[d] = float(row["Close"])
            except (KeyError, TypeError, ValueError):
                continue
    if not out:
        raise RuntimeError("Stooq lieferte keine Gold-Daten")
    return out


def binance_btc(start: str) -> dict[str, float]:
    """BTCUSDT-Tageskerzen von Binance, paginiert."""
    t0 = int(datetime.fromisoformat(start).replace(tzinfo=timezone.utc)
             .timestamp() * 1000)
    now = int(time.time() * 1000)
    out, cursor = {}, t0
    while cursor < now:
        url = ("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1d"
               f"&limit=1000&startTime={cursor}&endTime={now}")
        rows = json.loads(get(url))
        if not rows:
            break
        for k in rows:
            d = datetime.fromtimestamp(k[0] / 1000, timezone.utc).strftime("%Y-%m-%d")
            out[d] = float(k[4])
        newest = int(rows[-1][0])
        if newest <= cursor:
            break
        cursor = newest + 86_400_000
        time.sleep(0.2)
    if not out:
        raise RuntimeError("Binance lieferte keine BTC-Daten")
    return out


# ---------------------------------------------------------------------------

def wilson_crit(n: int) -> float:
    """Ab welchem |r| ist bei n Beobachtungen p < 0,05 erreicht?"""
    if n < 4:
        return 1.0
    t = 1.96 + 2.4 / max(n - 2, 1)      # Näherung des t-Werts
    return t / math.sqrt(t * t + n - 2)


def analyze(name: str, driver: dict, assets: dict[str, dict], max_lag: int = 3,
            csv_path: str | None = None) -> None:
    dates = sorted(set(driver) & set.intersection(*(set(a) for a in assets.values())))
    if len(dates) < 30:
        print(f"  {name}: nur {len(dates)} gemeinsame Tage — zu wenig.")
        return

    dv = np.diff([driver[d] for d in dates])        # Änderung des Treibers
    rets = {k: np.diff(np.log([v[d] for d in dates])) for k, v in assets.items()}
    n = len(dv)
    crit = wilson_crit(n)

    print(f"\n{name}  ({KNOWN.get(name, name)})")
    print(f"  {len(dates)} gemeinsame Handelstage, {dates[0]} bis {dates[-1]}")
    print(f"  Signifikanz ab |r| > {crit:.2f}\n")
    header = f"  {'Lag':>4}" + "".join(f"{k:>12}" for k in assets)
    print(header)
    for lag in range(0, max_lag + 1):
        x = dv if lag == 0 else dv[:-lag]
        line = f"  {lag:>4}"
        for k in assets:
            y = rets[k] if lag == 0 else rets[k][lag:]
            r = float(np.corrcoef(x, y)[0, 1])
            mark = "*" if abs(r) > crit else " "
            line += f"{r:>+11.2f}{mark}"
        print(line + ("   gleichtägig" if lag == 0 else f"   Treiber {lag}d vorher"))

    # Kontrast: Korrelation der Niveaus, die trügerische Zahl
    lv = np.array([driver[d] for d in dates])
    print("\n  Zum Kontrast, Korrelation der NIVEAUS (nicht der Änderungen):")
    for k, v in assets.items():
        r = float(np.corrcoef(lv, [v[d] for d in dates])[0, 1])
        print(f"    {k:<10} r = {r:+.2f}   <- hoch, aber meist bedeutungslos")

    if csv_path:
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            w.writerow(["date", name] + list(assets))
            for i, d in enumerate(dates):
                w.writerow([d, driver[d]] + [assets[k][d] for k in assets])


def main() -> None:
    p = argparse.ArgumentParser(description="Makro-Treiber gegen Gold und BTC")
    p.add_argument("--years", type=float, default=2)
    p.add_argument("--series", nargs="+", default=["DFII10", "DTWEXBGS", "T10YIE"],
                   help=f"FRED-Kürzel. Bekannt: {', '.join(KNOWN)}")
    p.add_argument("--max-lag", type=int, default=3)
    p.add_argument("--csv")
    args = p.parse_args()

    start = (datetime.now(timezone.utc)
             - timedelta(days=int(args.years * 365.25))).strftime("%Y-%m-%d")
    print(f"Zeitraum ab {start}\n")

    print("Lade Gold (Stooq) …", end=" ", flush=True)
    gold = stooq_gold(start); print(f"{len(gold)} Tage")
    print("Lade BTC (Binance) …", end=" ", flush=True)
    btc = binance_btc(start); print(f"{len(btc)} Tage")

    assets = {"Gold": gold, "BTC": btc}
    for s in args.series:
        print(f"Lade {s} (FRED) …", end=" ", flush=True)
        try:
            d = fred(s, start); print(f"{len(d)} Tage")
        except RuntimeError as e:
            print(f"FEHLER: {e}"); continue
        analyze(s, d, assets, args.max_lag, args.csv)

    # Gold als "Treiber" für BTC — die ursprüngliche These
    print("\n" + "=" * 60)
    analyze("GOLD", gold, {"BTC": btc}, args.max_lag)

    print("\nLesehilfe: * markiert Werte über der Signifikanzschwelle.")
    print("Ein Wert bei Lag 0 heißt gleichzeitige Reaktion auf dieselbe Nachricht,")
    print("nicht Vorhersagekraft. Erst Lag 1 und höher wäre ein Frühindikator.")


if __name__ == "__main__":
    main()
