#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Volatilität (U237, 23.90): Volatilitätsindex mit Kurs, Prognose der Schwankung für vier Wochen, Rückblick über fünf Jahre.

Vorab festgelegt in KONZEPT_Volatilitaet.md (28.10.2026, vor jeder Zahl dieses Moduls auf echten Daten) mit Nachtrag 13 nach der
unabhängigen Durchsicht (geht dem übrigen Text vor). Nur lesen, nur Anzeige: liest swing.db (30-min-Kerzen der Binance-Perpetuals),
aktien.db (DVOL-Stunden) und makro.db (Termine, DVOL-Tageswert nur zur Anzeige) ausschließlich lesend und schreibt nur volatil.db.
Wirkt auf nichts im übrigen System (kein Treiber, keine Prognose, keine Fusion, kein Labor) und ruft nichts im Netz ab. Einziges
Projektmodul, das es liest: hl_swing (Vergleich der Tages-RV, Prüfung vor dem Urteil).

Schwankung, nicht Richtung: Das Modul sagt, wie stark sich ein Kurs in den nächsten vier Wochen bewegen dürfte – nie, wohin.

Aufbau dieser Datei:
  1. Konstanten, Zeit, Zahlen
  2. Tageswerte aus Kerzen (gleiche Rechnung wie hl_swing.tagesreihen), Index, DVOL-Tageswert, Verfall- und Fed-Termine
  3. Reihe je Coin: Fenstermittel, Ziele, Vergleiche (B0, B365, EWMA), Schwelle, Zustand, Grundrate je Ursprung, Kalender
  4. Modelle M, M+ (DVOL), M° (M auf den Ursprüngen von M+), geliehen (HYPE: gemeinsame Steigungen, eigenes Niveau); σ außerhalb
  5. Tagespfad (Wochentag und bestätigte Termine verteilen nur innerhalb der Woche um) und Prognose je Ursprung
  6. Speicher volatil.db (BEGIN IMMEDIATE; Fassung im Schlüssel; Prognosen werden nie überschrieben)
  7. Aktualisieren (Tage, DVOL, Termine), Erstlauf, Rückblick in Schritten (mit Vorlauf für σ), Tageslauf
  8. Auswertung: Zählung bis zur Freigabe, Prüfungen vor dem Urteil (mit Vorzeichen-Nullprobe und Blockregel), ein gemeinsames
     Urteil (V1 als Schnitt-Test, gewichteter Holm), beschreibend, Vorwärtsrunde
  9. Berichte und Nutzlast (vor dem Urteil nur die jüngste Prognose und Zählungen)
 10. Selbsttest und Mutationen
 11. Dienst: Faden „volatil“ im Dashboard (entscheidet nur), Rechnung als eigener Prozess mit nice 10; Befehlszeile
"""

from __future__ import annotations

import contextlib
import json
import math
import os
import sqlite3
import sys
import threading
import time
import urllib.parse
import warnings
from datetime import date, datetime, timedelta, timezone

import numpy as np

# Mutationsschalter für den Selbsttest (Konzept 9.2, Nachtrag 13.17). Im Betrieb immer None.
_MUT: str | None = None

# ---------------------------------------------------------------------------
# 1. Konstanten, Zeit, Zahlen
# ---------------------------------------------------------------------------

VERSION_MODUL = "2026-09-23.90"
FASSUNG = "U237-1"               # Fassung von Prognose und Auswertung (Nachtrag 13.10); im Schlüssel der Tabellen
NAME = "Volatilität (U237)"
UTC = timezone.utc
TAG = 86400
BAR = 1800
BARS_TAG = 48
MIN_BARS = 40                    # wie hl_swing.tagesreihen: Tag gültig ab 40 gültigen 30-min-Renditen
JAHR = 365                       # Annualisierung (Krypto handelt an allen Tagen)
COINS = ("BTC", "ETH", "ZEC", "HYPE", "XMR")
PRUEF_COINS = ("BTC", "ETH", "ZEC", "XMR")     # Urteil (Konzept 6.1)
DVOL_COINS = ("BTC", "ETH")                    # DVOL und die Modelle M+ / M° (Konzept 2.4, 4.4; Nachtrag 13.6)
GELIEHEN = ("HYPE",)                           # gemeinsame Steigungen, eigenes Niveau (Nachtrag 13.7)
EPOCHE = date(1970, 1, 1)
RB_START = (date(2021, 10, 28) - EPOCHE).days  # erster bewerteter Ursprung des Rückblicks (Konzept 5)
WOCHEN = (1, 2, 3, 4)
FENSTER_MAX = 730                # Schätzfenster: die jüngsten 730 Ursprünge mit fertigem Ziel …
FENSTER_MIN = 365                # … mindestens 365
SCHWELLE_TAGE = 365
SCHWELLE_PERZ = 80.0
SCHWELLE_MIN = 300               # mindestens so viele gültige 7-Tage-Mittel für die Schwelle
RATE_MAX = 730                   # Grundrate und Zwei-Zustands-Modell: die jüngsten 730 eingestuften Ursprünge …
RATE_MIN = 365                   # … mindestens 365 (Nachtrag 13.9)
MARKOV_MIN = 30                  # je Zustand mindestens 30, sonst die Grundrate
SIGMA_MAX = 730                  # σ außerhalb: Fehler der jüngsten 730 früheren Prognosen mit fertigem Ziel …
SIGMA_MIN = 365                  # … mindestens 365, sonst σ im Schätzfenster (Nachtrag 13.5)
HYPE_MIN = 90                    # eigenes Niveau und σ von HYPE ab 90 eigenen Ursprüngen (Nachtrag 13.7)
EWMA_L = 0.94
R1_ZURUECK = 3                   # RV des Vortags ungültig: der letzte gültige Tag, höchstens 3 zurück (Nachtrag 13.9)
WT_TAGE = 365                    # Wochentagsfaktor aus den 365 Tagen vor D
WT_MIN = 20
TERMIN_TAGE = 3 * 365            # Terminfaktor aus den drei Jahren vor D
TERMIN_MIN = 6                   # mindestens 6 bestätigte Termine …
TERMIN_VERGLEICH_MIN = 5         # … mit je mindestens 5 Vergleichstagen (Werktage desselben Monats ohne Termin, wie U154)
TERMIN_GRENZEN = (1.0, 3.0)
STILLSTAND = ((date(2025, 10, 1) - EPOCHE).days, (date(2026, 1, 31) - EPOCHE).days)   # Termine dort erst am Tag bekannt
Z50 = 0.6744897501960817
Z90 = 1.6448536269514722
BLOECKE = (112, 168, 224)        # Blocklänge des Bootstraps: 112 Tage, automatisch länger nach der Vorzeichen-Nullprobe (13.3)
VZ_BLOCK = 224                   # Vorzeichen-Block der Nullprobe
ZIEHUNGEN = 9999
SAAT = 237
WELTEN = 200
PRUEFUNGEN = ("V1", "V2", "V3", "V4")          # das gemeinsame Urteil (Holm über diese vier)
TEILE = ("V1a", "V1b", "V2", "V3", "V4")       # getestete Differenzen; V1 = Schnitt aus V1a und V1b (Nachtrag 13.2)
MIN_TAGE = 1344                  # 12 Blöcke zu 112 Tagen je Prüfung …
MIN_HAELFTE = 672                # … und 6 Blöcke je Hälfte
GEWICHT = {"V1": 0.25, "V2": 0.25, "V3": 0.25, "V4": 0.25}
VORWAERTS_MIN = 1344             # Bestätigungstest vorwärts erst mit 1.344 Live-Ursprungstagen (13.11)
VORWAERTS_WARN = 365
TERMIN_ARTEN = ("cpi", "jobs")                 # wirken im Tagespfad (Nachtrag 13.8)
MARKEN_ARTEN = ("fed", "verfall_m", "verfall_q")
TERMIN_TEXT = {"cpi": "Inflation USA (CPI)", "jobs": "Arbeitsmarktbericht USA", "fed": "Fed-Entscheid",
               "verfall_m": "Optionsverfall Deribit (Monat)", "verfall_q": "Optionsverfall Deribit (Quartal)"}
FRED_TERMINE = {"CPIAUCSL": "cpi", "UNRATE": "jobs"}
# Fed-Entscheide (zweiter Sitzungstag, 14:00 New York) laut federalreserve.gov, Seite „Meeting calendars, statements, and minutes
# (2021-2027)“, abgerufen am 28.10.2026 (Nachtrag 13.8). Nur Marken. 2027 laut Fed noch vorläufig.
FOMC = ("2021-01-27", "2021-03-17", "2021-04-28", "2021-06-16", "2021-07-28", "2021-09-22", "2021-11-03", "2021-12-15",
        "2022-01-26", "2022-03-16", "2022-05-04", "2022-06-15", "2022-07-27", "2022-09-21", "2022-11-02", "2022-12-14",
        "2023-02-01", "2023-03-22", "2023-05-03", "2023-06-14", "2023-07-26", "2023-09-20", "2023-11-01", "2023-12-13",
        "2024-01-31", "2024-03-20", "2024-05-01", "2024-06-12", "2024-07-31", "2024-09-18", "2024-11-07", "2024-12-18",
        "2025-01-29", "2025-03-19", "2025-05-07", "2025-06-18", "2025-07-30", "2025-09-17", "2025-10-29", "2025-12-10",
        "2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29", "2026-09-16", "2026-10-28", "2026-12-09",
        "2027-01-27", "2027-03-17", "2027-04-28", "2027-06-09", "2027-07-28", "2027-09-15", "2027-10-27", "2027-12-08")
MODELLE = ("M", "M+", "M0", "geliehen")
MODELL_TEXT = {"M": "M (log-HAR)", "M+": "M+ (mit DVOL)", "M0": "M° (M auf den Ursprüngen von M+, nur für V4)",
               "geliehen": "gemeinsame Steigungen, eigenes Niveau"}
TITEL = {"V1": "V1 Niveau: M gegen 30-Tage- und Jahresmittel (beide müssen geschlagen sein)",
         "V1a": "V1a Niveau: QLIKE der 30-Tage-Persistenz minus QLIKE von M",
         "V1b": "V1b Niveau: QLIKE des Jahresmittels minus QLIKE von M",
         "V2": "V2 Phasen: Brier der Grundrate minus Brier von M",
         "V3": "V3 Phasen: Brier des Zwei-Zustands-Modells minus Brier von M",
         "V4": "V4 DVOL (BTC, ETH): QLIKE von M° minus QLIKE von M+",
         "V1v": "V1 vorwärts", "V2v": "V2 vorwärts"}
HINWEIS = "Schwankung, nicht Richtung. Prognose ungeprüft – das Urteil steht aus."
NICHT_FRISCH = ("Daten nicht frisch: HAR wurde auf diesen Kursen schon geprüft (Regime, Ausblick); unabhängig ist erst die "
                "Vorwärtsrunde.")


def wochentag(t):
    """0 = Montag … 6 = Sonntag für UTC-Tage seit 1970 (der 01.01.1970 war ein Donnerstag)."""
    if isinstance(t, (int, np.integer)):
        return (int(t) + 3) % 7
    return (np.asarray(t, dtype=np.int64) + 3) % 7


def tag_datum(t) -> date:
    return EPOCHE + timedelta(days=int(t))


def datum_tag(d: date) -> int:
    return (d - EPOCHE).days


def monatserster(t: int) -> int:
    d = tag_datum(t)
    return datum_tag(date(d.year, d.month, 1))


def naechster_monat(t: int) -> int:
    d = tag_datum(monatserster(t))
    return datum_tag(date(d.year + (d.month == 12), d.month % 12 + 1, 1))


def _de(x, nd: int = 2) -> str:
    if x is None:
        return "–"
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not math.isfinite(xf):
        return "–"
    return f"{xf:,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".").replace("-", "−")


def _pz(x, nd: int = 1) -> str:
    return "–" if not _endlich(x) else _de(100.0 * float(x), nd) + " %"


def _datum(t) -> str:
    return "–" if t is None else tag_datum(int(t)).strftime("%d.%m.%Y")


def _uhr(ts) -> str:
    return "–" if not ts else datetime.fromtimestamp(int(ts), UTC).strftime("%d.%m.%Y %H:%M UTC")


def _endlich(x) -> bool:
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def jahresfaktor() -> int:
    return 252 if _MUT == "annualisierung_252" else JAHR


def ann(v):
    """Tagesvarianz -> Schwankung in % p. a. (100 · √(365 · v)); ungültig -> None bzw. NaN."""
    if isinstance(v, np.ndarray):
        with np.errstate(invalid="ignore"):
            return 100.0 * np.sqrt(jahresfaktor() * v)
    if not _endlich(v) or float(v) < 0:
        return None
    return 100.0 * math.sqrt(jahresfaktor() * float(v))


def qlike(r, v):
    """QLIKE(R, V) = R/V − log(R/V) − 1 (≥ 0, 0 bei R = V)."""
    with np.errstate(invalid="ignore", divide="ignore"):
        q = np.asarray(r, dtype=float) / np.asarray(v, dtype=float)
        return q - np.log(q) - 1.0


def phi(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


# ---------------------------------------------------------------------------
# 2. Tageswerte, Index, DVOL, Kalender
# ---------------------------------------------------------------------------

def tageswerte(ts, o, h, l, c) -> dict | None:  # noqa: E741 — Namen wie hl_swing.tagesreihen
    """30-min-Kerzen -> UTC-Tage (Konzept 2.2). RV = Summe der quadrierten Log-Renditen von Schluss zu Schluss (nur bei 30 min
    Abstand; die erste Rendite eines Tages geht vom letzten Schluss des Vortags aus), auf 48 hochgerechnet ab 40 gültigen, sonst
    ungültig – dieselbe Rechnung wie hl_swing.tagesreihen (Selbsttest und Prüfung 1 vor dem Urteil vergleichen beide). Dazu
    Rogers-Satchell je Kerze (nur beschreibend; ab 40 Kerzen, auf 48 hochgerechnet) und der letzte Schluss des Tages."""
    ts = np.asarray(ts, dtype=np.int64)
    o, h, l, c = (np.asarray(x, dtype=float) for x in (o, h, l, c))
    ok = np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c) & (o > 0) & (h > 0) & (l > 0) & (c > 0)
    ts, o, h, l, c = ts[ok], o[ok], h[ok], l[ok], c[ok]
    s = np.argsort(ts, kind="stable")
    ts, o, h, l, c = ts[s], o[s], h[s], l[s], c[s]
    eind = np.concatenate([[True], np.diff(ts) > 0]) if len(ts) else np.zeros(0, dtype=bool)
    ts, o, h, l, c = ts[eind], o[eind], h[eind], l[eind], c[eind]
    if not len(ts):
        return None
    h = np.maximum(h, np.maximum(o, c))
    l = np.minimum(l, np.minimum(o, c))
    tag = ts // TAG
    d0 = int(tag[0])
    di = (tag - d0).astype(np.int64)
    nd = int(di[-1]) + 1
    r = np.zeros(len(ts))
    r[1:] = np.diff(np.log(c))
    rv_ok = np.zeros(len(ts), dtype=bool)
    rv_ok[1:] = np.diff(ts) == BAR
    summe = np.bincount(di, weights=np.where(rv_ok, r * r, 0.0), minlength=nd)
    anz = np.bincount(di, weights=rv_ok.astype(float), minlength=nd)
    grenze = 1 if _MUT == "luecke_gueltig" else MIN_BARS
    with np.errstate(divide="ignore", invalid="ignore"):
        if _MUT == "luecken_nicht_hochskaliert":
            rv = np.where(anz >= grenze, summe, np.nan)
        else:
            rv = np.where(anz >= grenze, summe * BARS_TAG / np.maximum(anz, 1), np.nan)
        rs_k = np.log(h / c) * np.log(h / o) + np.log(l / c) * np.log(l / o)
    nb = np.bincount(di, minlength=nd)
    rs_s = np.bincount(di, weights=rs_k, minlength=nd)
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = np.where(nb >= MIN_BARS, rs_s * BARS_TAG / np.maximum(nb, 1), np.nan)
    i1 = np.searchsorted(di, np.arange(nd), side="right")
    schluss = np.where(nb > 0, c[np.maximum(i1 - 1, 0)], np.nan)
    return {"d0": d0, "rv": rv, "anz": anz.astype(np.int64), "rs": rs, "schluss": schluss, "nb": nb}


def _praefix(rv: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    g = np.isfinite(rv) & (rv > 0)
    cs = np.concatenate([[0.0], np.cumsum(np.where(g, rv, 0.0))])
    cn = np.concatenate([[0], np.cumsum(g.astype(np.int64))])
    return cs, cn


def _fenster(cs: np.ndarray, cn: np.ndarray, a, b, min_n: int) -> np.ndarray:
    """Mittel der gültigen Tageswerte über die Indizes [a, b); NaN außerhalb der Daten oder mit weniger als min_n gültigen Tagen
    (Lücken: Mittel der gültigen Tage)."""
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    n = len(cs) - 1
    drin = (a >= 0) & (b <= n) & (b > a)
    a2 = np.clip(a, 0, n)
    b2 = np.clip(b, 0, n)
    cnt = cn[b2] - cn[a2]
    s = cs[b2] - cs[a2]
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(drin & (cnt >= min_n), s / np.maximum(cnt, 1), np.nan)


def min_gueltig(laenge: int) -> int:
    """Gültig mit (Nachtrag 13.9): 7 Tage -> 6, 30 -> 27, 365 -> 329 (90 %)."""
    if laenge == 7:
        return 6
    return int(math.ceil(0.9 * laenge - 1e-9))


def index_tage(rv: np.ndarray, laenge: int) -> np.ndarray:
    """VI je Tag e über die Tage e − laenge + 1 … e (Stand am Ende von Tag e) in % p. a.: 100 · √(365 · Mittel der gültigen) –
    bei vollem Fenster gleich 100 · √(365/laenge · Σ RV)."""
    cs, cn = _praefix(np.asarray(rv, dtype=float))
    e = np.arange(len(rv))
    return ann(_fenster(cs, cn, e - laenge + 1, e + 1, min_gueltig(laenge)))


def ewma_reihe(rv: np.ndarray, lam: float = EWMA_L) -> np.ndarray:
    """EWMA der Tages-RV einschließlich des Tags e (wie hl_regime.ewma_tag); ungültige Tage tragen den letzten Wert weiter."""
    out = np.full(len(rv), np.nan)
    e = None
    for d, v in enumerate(rv):
        if np.isfinite(v) and v > 0:
            e = float(v) if e is None else lam * e + (1 - lam) * float(v)
        if e is not None:
            out[d] = e
    return out


def dvol_tage(stunden) -> dict[int, tuple[float, int]]:
    """DVOL-Tageswert für Tag e = die Stunde mit Zeitstempel (e+1)·86400 − 3600 (Zeitstempel = Beginn, Wert = Schluss um 24:00
    UTC); bekannt ab dem Ursprung D = e + 1 – kausal in beiden Lesarten des Zeitstempels (Nachtrag 13.6). -> {e: (Wert, ts)}"""
    aus: dict[int, tuple[float, int]] = {}
    for ts, w in stunden:
        if not _endlich(w) or float(w) <= 0:
            continue
        ts = int(ts)
        if _MUT == "dvol_stunde_vor_ende":
            if ts % TAG == 0:
                aus[ts // TAG - 1] = (float(w), ts)
        elif ts % TAG == TAG - 3600:
            aus[ts // TAG] = (float(w), ts)
    return aus


def verfallstage(von_tag: int, bis_tag: int) -> dict[int, str]:
    """Deribit-Optionsverfall nach Regel (08:00 UTC): letzter Freitag jedes Monats; im März, Juni, September und Dezember der
    Quartalsverfall (eigene Art). Nur Marke (Nachtrag 13.8)."""
    aus: dict[int, str] = {}
    d = tag_datum(monatserster(von_tag))
    while datum_tag(d) <= bis_tag:
        letzter = date(d.year + (d.month == 12), d.month % 12 + 1, 1) - timedelta(days=1)
        fr = letzter - timedelta(days=(letzter.weekday() - 4) % 7)
        t = datum_tag(fr)
        if von_tag <= t <= bis_tag:
            aus[t] = "verfall_q" if fr.month in (3, 6, 9, 12) else "verfall_m"
        d = letzter + timedelta(days=1)
    return aus


def fed_tage() -> list[int]:
    return [datum_tag(date.fromisoformat(s)) for s in FOMC]


# ---------------------------------------------------------------------------
# 3. Reihe je Coin
# ---------------------------------------------------------------------------

UNBEKANNT = 10 ** 9


class Reihe:
    """Tageswerte eines Coins und alle Größen je Ursprung D. Tage: Index e = Tag − d0 (0 … n−1). Ursprünge: Index i = D − d0
    (0 … n; i = n ist der Tag nach dem letzten Datentag). Eine Größe am Ursprung i nutzt nur Tage < i (Kausalität, Regel 2) –
    ausgenommen die Ziele (Wochen ab D), die nur zum Schätzen (Ursprünge mit fertigem Ziel) und Bewerten dienen.

    termine: {Tag: [(Art, bekannt_ab_Tag, bestätigt)]} für die Arten im Pfad (cpi, jobs); dvol: {Tag e: Wert} nur aus aktien.db."""

    def __init__(self, coin: str, d0: int, rv, dvol: dict | None = None, rs=None, termine: dict | None = None):
        self.coin = coin
        self.d0 = int(d0)
        self.rv = np.asarray(rv, dtype=float)
        self.n = len(self.rv)
        self.rs = None if rs is None else np.asarray(rs, dtype=float)
        self.cs, self.cn = _praefix(self.rv)
        n = self.n
        i = np.arange(n + 1)
        F = self._mittel
        gueltig = np.isfinite(self.rv) & (self.rv > 0)
        r1 = np.full(n + 1, np.nan)
        if _MUT == "ziel_im_regressor":
            r1[:n] = np.where(gueltig, self.rv, np.nan)
        else:
            for z in range(1, R1_ZURUECK + 1):        # Vortag, sonst der letzte gültige Tag, höchstens 3 zurück
                j = i - z
                ok = np.isnan(r1) & (j >= 0)
                jj = np.clip(j, 0, max(0, n - 1))
                r1 = np.where(ok & gueltig[jj] if n else ok, self.rv[jj] if n else np.nan, r1)
        self.r1 = r1
        self.r7 = F(i - 7, i, min_gueltig(7))
        self.r30 = F(i - 30, i, min_gueltig(30))
        self.b365 = F(i - 365, i, min_gueltig(365))
        ew = ewma_reihe(self.rv)
        self.ewma = np.concatenate([[np.nan], ew])        # Ursprung i: EWMA bis einschließlich Tag i − 1
        v = 1 if _MUT == "wochenfenster_verschoben" else 0
        self.ziel = {k: F(i + 7 * (k - 1) + v, i + 7 * k + v, 6) for k in WOCHEN}
        self.vorwoche = F(i - 7, i, 6)
        e = np.arange(n)
        self.m7 = F(e - 6, e + 1, 6)                     # Mittel der 7 Tage bis einschließlich e
        self.schwelle = self._schwelle()
        with np.errstate(invalid="ignore"):
            self.vol = {k: np.where(np.isfinite(self.ziel[k]) & np.isfinite(self.schwelle),
                                    (self.ziel[k] > self.schwelle).astype(float), np.nan) for k in WOCHEN}
            z = self.ziel[1] if _MUT == "markov_zielwoche" else self.vorwoche
            self.zustand = np.where(np.isfinite(z) & np.isfinite(self.schwelle), (z > self.schwelle).astype(float), np.nan)
        self._raten_vorbereiten()
        self.dvol_tag = {int(t): float(w) for t, w in (dvol or {}).items() if _endlich(w) and float(w) > 0}
        dx = np.full(n + 1, np.nan)
        for t, w in self.dvol_tag.items():
            j = t - self.d0 + 1                            # Tageswert von Tag e gilt ab dem Ursprung e + 1
            if 0 <= j <= n:
                dx[j] = math.log((w / 100.0) ** 2 / JAHR)
        self.dvol_x = dx
        self.kalender_setzen(termine or {})
        self._x_cache: dict = {}

    def _mittel(self, a, b, min_n):
        return _fenster(self.cs, self.cn, a, b, min_n)

    def _schwelle(self) -> np.ndarray:
        """S(D) = 80. Perzentil der gleitenden 7-Tage-Mittel, deren Fenster ganz in den 365 Tagen vor D liegen (359 Werte, nur
        Vergangenheit; Konzept 4.6); mindestens 300 gültige."""
        L = SCHWELLE_TAGE - 6
        S = np.full(self.n + 1, np.nan)
        if self.n < L:
            return S
        m = self.m7
        if _MUT == "schwelle_zukunft":
            m = np.concatenate([m[1:], [np.nan]])
        win = np.lib.stride_tricks.sliding_window_view(m, L)      # win[j] = m[j : j + L] -> Ursprung i = j + L
        cnt = np.sum(np.isfinite(win), axis=1)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            q = np.nanpercentile(win, SCHWELLE_PERZ, axis=1)
        q[cnt < SCHWELLE_MIN] = np.nan
        S[L:L + len(q)] = q
        return S

    def _raten_vorbereiten(self) -> None:
        """Präfixsummen über die eingestuften Ursprünge je Woche (Grundrate und Zwei-Zustands-Modell je Ursprung, Nachtrag 13.9)."""
        self._rate = {}
        for k in WOCHEN:
            pos = np.nonzero(np.isfinite(self.vol[k]))[0]
            v = self.vol[k][pos]
            z = self.zustand[pos]
            z1 = np.isfinite(z) & (z == 1)
            z0 = np.isfinite(z) & (z == 0)
            pre = lambda a: np.concatenate([[0.0], np.cumsum(a)])  # noqa: E731
            self._rate[k] = (pos, pre(v), pre(z1.astype(float)), pre(z0.astype(float)), pre(v * z1), pre(v * z0))

    def raten(self, i: int, k: int) -> tuple[float, float, float, int]:
        """(Grundrate, P bei Zustand 0, P bei Zustand 1, Zahl) aus den jüngsten 730 eingestuften Ursprüngen s ≤ i − 7k (≥ 365)."""
        pos, cv, c1, c0, cv1, cv0 = self._rate[k]
        grenze = i if _MUT == "grundrate_zukunft" else i - 7 * k
        hi = int(np.searchsorted(pos, grenze, side="right"))
        lo = max(0, hi - RATE_MAX)
        n = hi - lo
        if n < RATE_MIN:
            return float("nan"), float("nan"), float("nan"), n
        g = (cv[hi] - cv[lo]) / n
        n1, n0 = c1[hi] - c1[lo], c0[hi] - c0[lo]
        p1 = (cv1[hi] - cv1[lo]) / n1 if n1 >= MARKOV_MIN else g
        p0 = (cv0[hi] - cv0[lo]) / n0 if n0 >= MARKOV_MIN else g
        return float(g), float(p0), float(p1), n

    def kalender_setzen(self, termine: dict) -> None:
        """Termine im Pfad (cpi, jobs) über die Tage d0 … d0 + n + 27: bekannt_ab (Tag, ab dem der Termin als bekannt gilt) und
        bestätigt (Erstveröffentlichung am Tag; nur bestätigte vergangene Termine gehen in den Terminfaktor). Kalendertage ohne
        Bestätigung sind keine Termine (Nachtrag 13.8) – außer unter der Mutation „unbestaetigt_als_termin“."""
        lang = self.n + 28
        tage = self.d0 + np.arange(lang)
        self.wt = wochentag(tage)
        self.werktag = self.wt < 5
        self.monat = np.array([tag_datum(int(t)).year * 12 + tag_datum(int(t)).month for t in tage], dtype=np.int64) if lang else \
            np.zeros(0, dtype=np.int64)
        self.tm_bekannt = {a: np.full(lang, UNBEKANNT, dtype=np.int64) for a in TERMIN_ARTEN}
        self.tm_bestaetigt = {a: np.zeros(lang, dtype=bool) for a in TERMIN_ARTEN}
        kalender = np.zeros(lang, dtype=bool)
        for t, eintraege in termine.items():
            j = int(t) - self.d0
            if not 0 <= j < lang:
                continue
            for art, bekannt, best in eintraege:
                if art not in TERMIN_ARTEN:
                    continue
                kalender[j] = True
                if best or _MUT == "unbestaetigt_als_termin":
                    self.tm_bestaetigt[art][j] = True
                if bekannt is not None:
                    self.tm_bekannt[art][j] = min(self.tm_bekannt[art][j], int(bekannt))
        self.ohne_termin = ~kalender

    def i_von(self, tag: int) -> int:
        return int(tag) - self.d0


# ---------------------------------------------------------------------------
# 4. Modelle
# ---------------------------------------------------------------------------

def merkmale(r: Reihe, idx, mit_dvol: bool) -> np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        sp = [np.ones(len(idx)), np.log(r.r1[idx]), np.log(r.r7[idx]), np.log(r.r30[idx])]
        if mit_dvol:
            sp.append(r.dvol_x[idx])
    return np.column_stack(sp)


def auswahl(r: Reihe, k: int, monat_i: int, mit_dvol: bool) -> np.ndarray:
    """Schätzfenster (Konzept 4.3): Ursprünge s mit fertigem Ziel vor dem Monatsersten (s + 7k ≤ M1), Merkmale und Ziel endlich;
    die jüngsten 730. mit_dvol: nur Ursprünge mit DVOL (M+ und M°)."""
    grenze = monat_i if _MUT == "neuschaetzung_zukunft" else monat_i - 7 * k
    hoch = min(grenze, r.n)
    if hoch < 0:
        return np.zeros(0, dtype=np.int64)
    s = np.arange(0, hoch + 1)
    ok = np.isfinite(r.r1[s]) & np.isfinite(r.r7[s]) & np.isfinite(r.r30[s]) & np.isfinite(r.ziel[k][s])
    if mit_dvol:
        ok &= np.isfinite(r.dvol_x[s])
    return s[ok][-FENSTER_MAX:]


def modell_dvol(modell: str) -> tuple[bool, bool]:
    """(Auswahl nur mit DVOL, DVOL als Regressor) je Modell. M° = M auf den Ursprüngen von M+ (Nachtrag 13.6)."""
    if modell == "M+":
        return True, True
    if modell == "M0":
        return _MUT != "v4_verschiedene_stichproben", False
    return False, False


def schaetzen(r: Reihe, k: int, monat: int, modell: str) -> dict | None:
    """Kleinste Quadrate für Woche k zum Monatsersten `monat` (Tag). σ im Fenster = Standardabweichung der Reste (n − Parameter)."""
    m_i = r.i_von(monat)
    mit_auswahl, mit_x = modell_dvol(modell)
    sel = auswahl(r, k, m_i, mit_auswahl)
    if len(sel) < FENSTER_MIN:
        return None
    X = merkmale(r, sel, mit_x)
    y = np.log(r.ziel[k][sel])
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    rest = y - X @ beta
    sigma = math.sqrt(float(rest @ rest) / max(1, len(sel) - X.shape[1]))
    return {"beta": [float(b) for b in beta], "sigma": sigma, "n": int(len(sel)), "von": r.d0 + int(sel[0]),
            "bis": r.d0 + int(sel[-1]), "niveau": "eigen"}


def schaetzen_gepoolt(reihen: dict, k: int, monat: int, ziel: str = "HYPE") -> dict | None:
    """Nachtrag 13.7: Steigungen aus der gemeinsamen Schätzung der vier Prüf-Coins (je Coin eigener Achsenabschnitt); der
    Achsenabschnitt für HYPE aus HYPEs eigenen Ursprüngen mit fertigem Ziel (mindestens 90, sonst das Mittel der Achsenabschnitte),
    σ aus HYPEs eigenen Resten (mindestens 90, sonst gepoolt)."""
    Xs, ys, coins = [], [], []
    for c in PRUEF_COINS:
        r = reihen.get(c)
        if r is None:
            continue
        sel = auswahl(r, k, r.i_von(monat), False)
        if len(sel) < FENSTER_MIN:
            continue
        Xs.append(merkmale(r, sel, False)[:, 1:])
        ys.append(np.log(r.ziel[k][sel]))
        coins.append(c)
    if len(coins) < 2:
        return None
    m = len(coins)
    N = sum(len(y) for y in ys)
    D = np.zeros((N, m))
    a = 0
    for j, y in enumerate(ys):
        D[a:a + len(y), j] = 1.0
        a += len(y)
    X = np.column_stack([D, np.vstack(Xs)])
    y = np.concatenate(ys)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    rest = y - X @ beta
    sigma = math.sqrt(float(rest @ rest) / max(1, N - X.shape[1]))
    steig = [float(b) for b in beta[m:]]
    a0, niveau, sg = float(np.mean(beta[:m])), "Mittel der Achsenabschnitte", sigma
    h = reihen.get(ziel)
    if h is not None and _MUT != "hype_mittel_achsenabschnitt":
        selh = auswahl(h, k, h.i_von(monat), False)
        if len(selh) >= HYPE_MIN:
            xh = merkmale(h, selh, False)[:, 1:]
            yh = np.log(h.ziel[k][selh])
            a0 = float(np.mean(yh - xh @ np.array(steig)))
            niveau = "eigen"
            rh = yh - a0 - xh @ np.array(steig)
            sg = math.sqrt(float(rh @ rh) / max(1, len(selh) - 1))
    return {"beta": [a0] + steig, "sigma": sg, "n": int(N), "von": None, "bis": None, "coins": coins, "niveau": niveau}


def koeff_rechnen(reihen: dict, coin: str, modell: str, monat: int) -> dict | None:
    """Schätzung für alle vier Wochen zum Monatsersten; None, wenn eine Woche fehlt."""
    fits = {}
    for k in WOCHEN:
        if modell == "geliehen":
            f = schaetzen_gepoolt(reihen, k, monat, coin)
        else:
            r = reihen.get(coin)
            f = schaetzen(r, k, monat, modell) if r is not None else None
        if f is None:
            return None
        fits[k] = f
    return fits


class Fehler:
    """σ außerhalb der Stichprobe (Nachtrag 13.5): Fehler e_s = log R_k(s) − μ_k(s) früherer Prognosen desselben Modells mit
    fertigem Ziel (s ≤ D − 7k), die jüngsten 730, mindestens 365 – über Präfixsummen je Woche."""

    def __init__(self, r: Reihe, mu: dict):
        self.daten = {}
        for k in WOCHEN:
            m = np.asarray(mu.get(k, np.full(r.n + 1, np.nan)), dtype=float)
            with np.errstate(divide="ignore", invalid="ignore"):
                e = np.log(r.ziel[k]) - m
            pos = np.nonzero(np.isfinite(e))[0]
            ee = e[pos]
            self.daten[k] = (pos, np.concatenate([[0.0], np.cumsum(ee)]), np.concatenate([[0.0], np.cumsum(ee * ee)]))

    def sigma(self, i: int, k: int) -> tuple[float | None, int]:
        pos, c1, c2 = self.daten[k]
        hi = int(np.searchsorted(pos, i - 7 * k, side="right"))
        lo = max(0, hi - SIGMA_MAX)
        n = hi - lo
        if n < SIGMA_MIN:
            return None, n
        m = (c1[hi] - c1[lo]) / n
        var = max(0.0, (c2[hi] - c2[lo]) / n - m * m) * n / (n - 1)
        return math.sqrt(var), n


# ---------------------------------------------------------------------------
# 5. Tagespfad und Prognose
# ---------------------------------------------------------------------------

def _termin_x(r: Reihe, art: str, e: int, ende: int) -> float | None:
    """Termin am Tag e: log RV(e) − Mittel log RV der Werktage desselben Kalendermonats ohne Termin, nur Tage < ende (wie U154)."""
    if not (np.isfinite(r.rv[e]) and r.rv[e] > 0):
        return None
    m = r.monat[e]
    a = int(np.searchsorted(r.monat[:ende], m, side="left"))
    b = int(np.searchsorted(r.monat[:ende], m, side="right"))
    if b <= a:
        return None
    rv = r.rv[a:b]
    ok = r.werktag[a:b] & r.ohne_termin[a:b] & np.isfinite(rv) & (rv > 0)
    if ok.sum() < TERMIN_VERGLEICH_MIN:
        return None
    return float(math.log(r.rv[e]) - np.mean(np.log(rv[ok])))


def tagesfaktoren(r: Reihe, i: int) -> np.ndarray:
    """f_j für die 28 Tage D … D+27 (Nachtrag 13.8): Wochentagsfaktor exp(½ · Mittel log(RV ÷ R7 davor)) über die 365 Tage vor D ×
    größter Terminfaktor des Tags (nur Termine, die zum Ursprung bekannt sind), Terminfaktor exp(½ · Mittel x) über die bestätigten
    Termine der drei Jahre vor D, begrenzt auf [1, 3]."""
    D = r.d0 + i
    fw = np.ones(7)
    a = max(0, i - WT_TAGE)
    rv = r.rv[a:i]
    r7 = r.r7[a:i]
    with np.errstate(divide="ignore", invalid="ignore"):
        lr = np.log(rv / r7)
    g = np.isfinite(lr)
    if g.sum() >= 7 * WT_MIN:
        wt = r.wt[a:i]
        summe = np.bincount(wt[g], weights=lr[g], minlength=7)
        anz = np.bincount(wt[g], minlength=7)
        for w in range(7):
            if anz[w] >= WT_MIN:
                fw[w] = math.exp(0.5 * summe[w] / anz[w])
    ende = min(i + 28, r.n) if _MUT == "termin_zukunft" else i
    a2 = max(0, i - TERMIN_TAGE)
    fa = {}
    for art in TERMIN_ARTEN:
        xs = []
        for e in np.nonzero(r.tm_bestaetigt[art][a2:ende])[0] + a2:
            e = int(e)
            schluss = ende
            schluessel = (art, e)
            fertig = r.monat[e] != r.monat[min(ende, len(r.monat) - 1)] if ende < len(r.monat) else True
            if fertig and schluessel in r._x_cache:
                x = r._x_cache[schluessel]
            else:
                x = _termin_x(r, art, e, schluss)
                if fertig:
                    r._x_cache[schluessel] = x
            if x is not None:
                xs.append(x)
        if len(xs) >= TERMIN_MIN:
            fa[art] = min(TERMIN_GRENZEN[1], max(TERMIN_GRENZEN[0], math.exp(0.5 * float(np.mean(xs)))))
        else:
            fa[art] = 1.0
    j = np.arange(i, i + 28)
    f = fw[r.wt[j]].copy()
    ft = np.ones(28)
    for art in TERMIN_ARTEN:
        ft = np.where(r.tm_bekannt[art][j] <= D, np.maximum(ft, fa[art]), ft)
    return f * ft


def vorhersage(r: Reihe, i: int, fits: dict, modell: str, fehler: Fehler | None = None, pfad: bool = True) -> list[dict] | None:
    """Prognose zum Ursprung D = d0 + i für die Wochen 1–4 (Konzept 4, Nachtrag 13.5–13.9). fits: {k: Schätzung zum Monatsersten};
    fehler: σ außerhalb aus früheren Prognosen desselben Modells (sonst σ im Fenster, gekennzeichnet). None, wenn ein Merkmal
    fehlt."""
    if i < 1 or i > r.n or any(fits.get(k) is None for k in WOCHEN):
        return None
    _, mit_x = modell_dvol(modell)
    x = merkmale(r, np.array([i]), mit_x)[0]
    if not np.all(np.isfinite(x)):
        return None
    S = float(r.schwelle[i])
    z = r.zustand[i]
    f = tagesfaktoren(r, i) if pfad else None
    aus = []
    for k in WOCHEN:
        ft = fits[k]
        mu = float(np.dot(ft["beta"], x))
        sg_oos, n_oos = fehler.sigma(i, k) if (fehler is not None and _MUT != "sigma_fenster") else (None, 0)
        sg = sg_oos if sg_oos is not None and sg_oos > 0 else float(ft["sigma"])
        v = math.exp(mu + sg * sg / 2.0)
        p = (1.0 - phi((math.log(S) - mu) / sg)) if (math.isfinite(S) and S > 0 and sg > 0) else None
        g, p0, p1, n_r = r.raten(i, k)
        markov = p1 if z == 1 else p0 if z == 0 else None
        zeile = {"woche": k, "mu": mu, "sigma": sg, "sigma_quelle": "oos" if sg_oos is not None else "fenster",
                 "sigma_fenster": float(ft["sigma"]), "v": v, "v_b0": float(r.r30[i]), "v_b365": float(r.b365[i]),
                 "v_ewma": float(r.ewma[i]), "schwelle": S if math.isfinite(S) else None, "p": p,
                 "p_grund": g if math.isfinite(g) else None, "p_markov": markov if (markov is not None and math.isfinite(markov)) else None,
                 "zustand": None if not np.isfinite(z) else int(z), "x": [float(t) for t in x[1:]], "n_rate": n_r, "n_sigma": n_oos}
        if f is not None:
            fw = f[7 * (k - 1):7 * k]
            zeile["pfad"] = [float(x_) for x_ in (v * fw if _MUT == "pfad_aendert_mittel" else v * fw / fw.mean())]
        aus.append(zeile)
    return aus


# ---------------------------------------------------------------------------
# 6. Speicher volatil.db
# ---------------------------------------------------------------------------

SCHEMA = (
    """CREATE TABLE IF NOT EXISTS vl_tag(
        coin TEXT NOT NULL, tag INTEGER NOT NULL, rv REAL, anz INTEGER, rs REAL, schluss REAL, vi7 REAL, vi30 REAL,
        PRIMARY KEY(coin, tag)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS vl_dvol(
        coin TEXT NOT NULL, tag INTEGER NOT NULL, quelle TEXT NOT NULL, wert REAL, ts INTEGER,
        PRIMARY KEY(coin, tag, quelle)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS vl_termin(
        tag INTEGER NOT NULL, art TEXT NOT NULL, quelle TEXT, bekannt INTEGER, bestaetigt INTEGER, PRIMARY KEY(tag, art))
        WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS vl_prognose(
        coin TEXT NOT NULL, ursprung INTEGER NOT NULL, modell TEXT NOT NULL, woche INTEGER NOT NULL, fassung TEXT NOT NULL,
        mu REAL, sigma REAL, sigma_quelle TEXT, sigma_fenster REAL, v REAL, v_b0 REAL, v_b365 REAL, v_ewma REAL, schwelle REAL,
        p REAL, p_grund REAL, p_markov REAL, zustand INTEGER, x TEXT, pfad TEXT, quelle TEXT, daten TEXT, berechnet INTEGER,
        PRIMARY KEY(coin, ursprung, modell, woche, fassung)) WITHOUT ROWID""",
    """CREATE INDEX IF NOT EXISTS vl_prognose_quelle ON vl_prognose(quelle, ursprung)""",
    """CREATE TABLE IF NOT EXISTS vl_koeff(
        coin TEXT NOT NULL, modell TEXT NOT NULL, woche INTEGER NOT NULL, monat INTEGER NOT NULL, fassung TEXT NOT NULL,
        beta TEXT, sigma REAL, n INTEGER, von INTEGER, bis INTEGER, niveau TEXT, berechnet INTEGER,
        PRIMARY KEY(coin, modell, woche, monat, fassung)) WITHOUT ROWID""",
    """CREATE TABLE IF NOT EXISTS vl_auswertung(
        pruefung TEXT NOT NULL, lauf INTEGER NOT NULL, fassung TEXT NOT NULL, n INTEGER, tage INTEGER, mass REAL, lo REAL,
        hi REAL, p REAL, p_holm REAL, h1 REAL, h2 REAL, urteil TEXT, endgueltig INTEGER DEFAULT 0, details TEXT,
        PRIMARY KEY(pruefung, lauf, fassung))""",
    """CREATE TABLE IF NOT EXISTS vl_meta(k TEXT PRIMARY KEY, v TEXT)""",
)


@contextlib.contextmanager
def schreiben(con: sqlite3.Connection):
    """Schreibtransaktion mit BEGIN IMMEDIATE (eiserne Regel)."""
    con.execute("BEGIN IMMEDIATE")
    try:
        yield con
    except BaseException:
        con.execute("ROLLBACK")
        raise
    else:
        con.execute("COMMIT")


def verbinden(p: str) -> sqlite3.Connection:
    con = sqlite3.connect(p, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA busy_timeout=30000")
    with schreiben(con):
        for s in SCHEMA:
            con.execute(s)
    return con


def meta(con, k: str, standard=None):
    r = con.execute("SELECT v FROM vl_meta WHERE k=?", (k,)).fetchone()
    if r is None:
        return standard
    try:
        return json.loads(r[0])
    except (TypeError, ValueError):
        return r[0]


def meta_setzen(con, k: str, wert) -> None:
    """Nur innerhalb von `schreiben(con)` aufrufen."""
    con.execute("INSERT INTO vl_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                (k, json.dumps(_ohne_nan(wert), ensure_ascii=False)))


def _ohne_nan(x):
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if isinstance(x, (float, np.floating)):
        return float(x) if math.isfinite(float(x)) else None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, dict):
        return {k: _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_ohne_nan(v) for v in x]
    if isinstance(x, np.ndarray):
        return [_ohne_nan(v) for v in x.tolist()]
    return x


def _f(x):
    """Zahl für die Datenbank: NaN/inf -> NULL."""
    return float(x) if _endlich(x) else None


def stichtag(con) -> int | None:
    st = meta(con, "stichtag")
    return int(st) if st else None


def stichtag_tag(con, jetzt: int | None = None) -> int | None:
    """Tag des Erstlaufs. Ursprünge bis einschließlich dieses Tags gehören zum Rückblick („rb“), spätere zur Vorwärtsrunde."""
    if _MUT == "kein_stichtag" and jetzt is not None:
        return int(jetzt) // TAG
    st = stichtag(con)
    return st // TAG if st else None


def pfad(db: str) -> str:
    """volatil.db liegt neben der Hauptdatenbank (wie prognosemarkt.db); HL_VOL_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_VOL_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "volatil.db")


def quellen(db: str) -> dict:
    """Die gelesenen Dateien (alle neben der Hauptdatenbank; Umlenkung wie in den jeweiligen Modulen) und volatil.db."""
    nebenan = os.path.dirname(os.path.abspath(db))
    return {"swing": os.environ.get("HL_SWING_DB") or os.path.join(nebenan, "swing.db"),
            "aktien": os.environ.get("HL_AKTIEN_DB") or os.path.join(nebenan, "aktien.db"),
            "makro": os.environ.get("HL_MAKRO_DB") or os.path.join(nebenan, "makro.db"),
            "vol": pfad(db)}


def stichtag_datei(q: dict) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(q["vol"])), "volatil_stichtag.json")


def lesen(p: str):
    """Nur-Lese-Verbindung; None, wenn die Datei fehlt."""
    if not p or not os.path.exists(p):
        return None
    con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=10,
                          check_same_thread=False)
    con.execute("PRAGMA busy_timeout=10000")
    return con


def _gleich(a, b) -> bool:
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) <= 1e-12 * max(1.0, abs(float(a)))
    return a == b


# ---------------------------------------------------------------------------
# 7. Aktualisieren, Erstlauf, Rückblick, Tageslauf
# ---------------------------------------------------------------------------

def kerzen_lesen(sc, coin: str):
    rows = sc.execute("SELECT ts, o, h, l, c FROM sw_klines WHERE coin=? ORDER BY ts", (coin,)).fetchall()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1], a[:, 2], a[:, 3], a[:, 4]


def tage_aktualisieren(con, swing_p: str, jetzt: int | None = None, coins=COINS) -> dict:
    """Tageswerte aller Coins aus swing.db (nur lesend) neu rechnen; nur abgeschlossene Tage (vor heute, UTC) – Kerzen ab dem Tag
    des Laufs werden abgeschnitten. Geänderte und neue Tage werden geschrieben (gleiche Werte erzeugen keine Zeile)."""
    heute = int(jetzt or time.time()) // TAG
    sc = lesen(swing_p)
    if sc is None:
        return {"fehlt": "swing.db fehlt"}
    aus = {}
    try:
        for coin in coins:
            try:
                K = kerzen_lesen(sc, coin)
            except sqlite3.Error as e:
                aus[coin] = {"fehler": str(e)[:120]}
                continue
            if K is None:
                aus[coin] = {"kerzen": 0}
                continue
            vor = K[0] < heute * TAG
            K = tuple(x[vor] for x in K)
            T = tageswerte(*K) if len(K[0]) else None
            if T is None:
                aus[coin] = {"kerzen": len(K[0])}
                continue
            n = min(len(T["rv"]), max(0, heute - T["d0"]))
            vi7 = index_tage(T["rv"], 7)
            vi30 = index_tage(T["rv"], 30)
            neu = {}
            for e in range(n):
                neu[T["d0"] + e] = (_f(T["rv"][e]), int(T["anz"][e]), _f(T["rs"][e]), _f(T["schluss"][e]), _f(vi7[e]),
                                    _f(vi30[e]))
            alt = {int(r[0]): tuple(r[1:]) for r in con.execute(
                "SELECT tag, rv, anz, rs, schluss, vi7, vi30 FROM vl_tag WHERE coin=?", (coin,))}
            schreib = [(coin, t, *w) for t, w in neu.items()
                       if t not in alt or not all(_gleich(x, y) for x, y in zip(w, alt[t]))]
            if schreib:
                with schreiben(con):
                    con.executemany("INSERT OR REPLACE INTO vl_tag VALUES (?,?,?,?,?,?,?,?)", schreib)
            gueltig = [t for t, w in neu.items() if w[0] is not None]
            aus[coin] = {"kerzen": len(K[0]), "von": min(neu) if neu else None, "bis": max(neu) if neu else None,
                         "neu": sum(1 for z in schreib if z[1] not in alt), "geaendert": sum(1 for z in schreib if z[1] in alt),
                         "gueltig": len(gueltig), "tage": len(neu), "letzte_kerze": int(K[0][-1])}
    finally:
        sc.close()
    return aus


def dvol_aktualisieren(con, aktien_p: str, makro_p: str) -> dict:
    """DVOL-Tageswerte: aktien.db Stundenreihen (Stunde 23:00–24:00 UTC) – nur sie gehen ins Modell (Nachtrag 13.6); der Tageswert
    aus makro.db (Tageskerze, Lage des Tagesschlusses ungeprüft) wird nur für die Anzeige gespeichert. Kein eigener Abruf."""
    neu: dict[tuple, tuple] = {}
    ac = lesen(aktien_p)
    if ac is not None:
        try:
            for coin in DVOL_COINS:
                try:
                    zeilen = ac.execute("SELECT ts, wert FROM ak_aktuell WHERE reihe=? ORDER BY ts",
                                        ("drb:dvol_%s_h" % coin.lower(),)).fetchall()
                except sqlite3.Error:
                    zeilen = []
                for t, (w, ts) in dvol_tage(zeilen).items():
                    neu[(coin, t, "aktien")] = (w, ts)
        finally:
            ac.close()
    mc = lesen(makro_p)
    if mc is not None:
        try:
            try:
                zeilen = mc.execute("SELECT ts, wert FROM mk_reihe WHERE reihe='drb:dvol_btc' ORDER BY ts").fetchall()
            except sqlite3.Error:
                zeilen = []
            for ts, w in zeilen:
                if _endlich(w) and float(w) > 0:
                    neu[("BTC", int(ts) // TAG, "makro")] = (float(w), int(ts))
        finally:
            mc.close()
    alt = {(r[0], int(r[1]), r[2]): (r[3], r[4]) for r in con.execute("SELECT coin, tag, quelle, wert, ts FROM vl_dvol")}
    schreib = [(c, t, q_, w, ts) for (c, t, q_), (w, ts) in neu.items()
               if (c, t, q_) not in alt or not _gleich(alt[(c, t, q_)][0], w) or alt[(c, t, q_)][1] != ts]
    if schreib:
        with schreiben(con):
            con.executemany("INSERT OR REPLACE INTO vl_dvol VALUES (?,?,?,?,?)", schreib)
    aus = {"neu": len(schreib)}
    for c in DVOL_COINS:
        tage = sorted(t for (cc, t, q_) in neu if cc == c and q_ == "aktien")
        letzte = [neu[(c, t, "aktien")][0] for t in tage[-365:]]
        aus[c] = {"tage": len(tage), "von": tage[0] if tage else None, "bis": tage[-1] if tage else None,
                  "median": float(np.median(letzte)) if letzte else None,
                  "makro": sum(1 for (cc, _, q_) in neu if cc == c and q_ == "makro")}
    return aus


def dvol_einheit(median) -> tuple[float | None, str]:
    """Nachtrag 13.6: Median der letzten 365 Tage in [15; 200] -> Vol-Punkte; in [0,15; 2] -> × 100; sonst Fehler."""
    if median is None:
        return None, "keine DVOL-Daten"
    if 15 <= median <= 200:
        return 1.0, "Vol-Punkte"
    if 0.15 <= median <= 2:
        return 100.0, "Anteile (× 100)"
    return None, f"Einheit unklar (Median {median:.4g})"


def _alfred_tage(mc, sid: str) -> set[int]:
    try:
        return {int(a) // TAG for (a,) in mc.execute("SELECT abgerufen FROM mk_fassung WHERE reihe=? AND art='erst'",
                                                     ("fred:" + sid,))}
    except sqlite3.Error:
        return set()


def termine_aktualisieren(con, makro_p: str, heute: int) -> dict:
    """Termine (Nachtrag 13.8): Inflation und Arbeitsmarkt aus dem FRED-Kalender in makro.db, bestätigt durch die
    Erstveröffentlichung (mk_fassung „erst“) am selben Tag; bekannt ab Tag − 60, im Stillstand 10/2025–01/2026 erst nach dem Tag;
    künftige ab ihrem ersten Abruf. Fed (feste Liste) und Optionsverfall (Regel) nur als Marke."""
    zeilen: dict[tuple, tuple] = {}
    for t, art in verfallstage(datum_tag(date(2018, 1, 1)), heute + 62).items():
        zeilen[(t, art)] = ("regel", None, 0)
    for t in fed_tage():
        zeilen[(t, "fed")] = ("federalreserve.gov", None, 0)
    geliefert = {"regel", "federalreserve.gov"}
    mc = lesen(makro_p)
    bestaetigt_n = 0
    if mc is not None:
        try:
            for sid, art in FRED_TERMINE.items():
                try:
                    z = mc.execute("SELECT v FROM mk_meta WHERE k=?", ("release:" + sid,)).fetchone()
                    rid = int(json.loads(z[0]).get("id")) if z else None
                except (sqlite3.Error, ValueError, TypeError, AttributeError):
                    rid = None
                if rid is None:
                    continue
                erst = _alfred_tage(mc, sid)
                try:
                    kal = mc.execute("SELECT tag, abgerufen FROM mk_termin WHERE release=?", (rid,)).fetchall()
                except sqlite3.Error:
                    kal = []
                for t, ab in kal:
                    t = int(t) // TAG
                    best = t in erst
                    bestaetigt_n += best
                    if best:
                        bekannt = t + 1 if STILLSTAND[0] <= t <= STILLSTAND[1] else t - 60
                    elif t >= heute:
                        bekannt = int(ab) // TAG if ab else heute
                    else:
                        bekannt = None                      # vergangener Kalendertag ohne Erstveröffentlichung: kein Termin
                    zeilen[(t, art)] = ("fred", bekannt, int(best))
                    geliefert.add("fred")
        finally:
            mc.close()
    alt = {(int(r[0]), r[1]): (r[2], r[3], r[4]) for r in con.execute("SELECT tag, art, quelle, bekannt, bestaetigt FROM vl_termin")}
    weg = [k for k, v in alt.items() if v[0] in geliefert and k not in zeilen]
    schreib = [(t, a, *v) for (t, a), v in zeilen.items() if alt.get((t, a)) != v]
    if weg or schreib:
        with schreiben(con):
            con.executemany("DELETE FROM vl_termin WHERE tag=? AND art=?", weg)
            con.executemany("INSERT OR REPLACE INTO vl_termin VALUES (?,?,?,?,?)", schreib)
    aus = {a: sum(1 for (_, aa) in zeilen if aa == a) for a in TERMIN_TEXT}
    aus.update({"quellen": sorted(geliefert), "neu": len(schreib), "weg": len(weg), "bestaetigt": bestaetigt_n})
    return aus


def termine_laden(con) -> dict[int, list]:
    """Tag -> [(Art, bekannt_ab, bestätigt)] der Arten im Pfad (cpi, jobs)."""
    aus: dict[int, list] = {}
    for t, a, b, best in con.execute("SELECT tag, art, bekannt, bestaetigt FROM vl_termin WHERE art IN ('cpi','jobs')"):
        aus.setdefault(int(t), []).append((a, None if b is None else int(b), bool(best)))
    return aus


def reihen_laden(con, bis_tag: int | None = None, coins=COINS) -> dict[str, Reihe]:
    """Reihen aus volatil.db (nur Tage < bis_tag), DVOL nur aus aktien.db (Einheit nach dem Erstlauf), Termine."""
    termine = termine_laden(con)
    faktor = meta(con, "dvol_faktor", {}) or {}
    aus = {}
    for coin in coins:
        q = "SELECT tag, rv, rs FROM vl_tag WHERE coin=?" + (" AND tag<?" if bis_tag is not None else "") + " ORDER BY tag"
        rows = con.execute(q, (coin, int(bis_tag)) if bis_tag is not None else (coin,)).fetchall()
        if not rows:
            continue
        d0 = int(rows[0][0])
        n = int(rows[-1][0]) - d0 + 1
        rv = np.full(n, np.nan)
        rs = np.full(n, np.nan)
        for t, v, s in rows:
            rv[int(t) - d0] = v if v is not None else np.nan
            rs[int(t) - d0] = s if s is not None else np.nan
        dv = {}
        f = faktor.get(coin, 1.0)
        quelle_m = ("aktien", "makro") if _MUT == "makro_in_mplus" else ("aktien",)
        if coin in DVOL_COINS and f:
            for t, w, qq in con.execute("SELECT tag, wert, quelle FROM vl_dvol WHERE coin=?" +
                                        (" AND tag<?" if bis_tag is not None else "") + " ORDER BY quelle",
                                        (coin, int(bis_tag)) if bis_tag is not None else (coin,)):
                if w is not None and qq in quelle_m and (qq == "aktien" or int(t) not in dv):
                    dv[int(t)] = float(w) * float(f)
        aus[coin] = Reihe(coin, d0, rv, dv, rs, termine)
    return aus


def modelle_fuer(coin: str) -> tuple[str, ...]:
    if coin in GELIEHEN:
        return ("geliehen",)
    return ("M", "M+", "M0") if coin in DVOL_COINS else ("M",)


def koeff_holen(con, coin: str, modell: str, monat: int) -> dict | None:
    rows = con.execute("SELECT woche, beta, sigma, n, von, bis, niveau FROM vl_koeff WHERE coin=? AND modell=? AND monat=? AND "
                       "fassung=?", (coin, modell, int(monat), FASSUNG)).fetchall()
    if len(rows) < len(WOCHEN):
        return None
    return {int(k): {"beta": json.loads(beta), "sigma": sg, "n": n, "von": von, "bis": bis, "niveau": niv}
            for k, beta, sg, n, von, bis, niv in rows}


def _koeff_zeilen(coin, modell, monat, fits, jetzt) -> list[tuple]:
    return [(coin, modell, k, int(monat), FASSUNG, json.dumps(f["beta"]), _f(f["sigma"]), int(f["n"]), f.get("von"), f.get("bis"),
             f.get("niveau"), int(jetzt)) for k, f in fits.items()]


def _prognose_zeilen(coin, D, modell, pr, quelle, jetzt, daten=None) -> list[tuple]:
    return [(coin, int(D), modell, z["woche"], FASSUNG, _f(z["mu"]), _f(z["sigma"]), z["sigma_quelle"], _f(z["sigma_fenster"]),
             _f(z["v"]), _f(z["v_b0"]), _f(z["v_b365"]), _f(z["v_ewma"]), _f(z["schwelle"]), _f(z["p"]), _f(z["p_grund"]),
             _f(z["p_markov"]), z["zustand"], json.dumps([float("%.8g" % x) for x in z["x"]]),
             json.dumps([float("%.6g" % x) for x in z["pfad"]]) if z.get("pfad") is not None else None, quelle,
             json.dumps(daten) if daten else None, int(jetzt)) for z in pr]


def _einfuegen(con, koeff: list, prognosen: list) -> dict:
    """Prognosen und Koeffizienten werden nie überschrieben: ein schon vorhandener Schlüssel (gleiche Fassung) ist ein Fehler und
    wird gezählt (vl_meta „doppelt“)."""
    d_k = d_p = 0
    for z in koeff:
        d_k += con.execute("INSERT OR IGNORE INTO vl_koeff VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", z).rowcount == 0
    for z in prognosen:
        d_p += con.execute("INSERT OR IGNORE INTO vl_prognose VALUES (" + ",".join("?" * 23) + ")", z).rowcount == 0
    if d_k or d_p:
        alt = meta(con, "doppelt", {}) or {}
        meta_setzen(con, "doppelt", {"koeff": int(alt.get("koeff", 0)) + d_k, "prognose": int(alt.get("prognose", 0)) + d_p,
                                     "zuletzt": int(time.time())})
    return {"doppelt_koeff": d_k, "doppelt_prognose": d_p}


def mu_laden(con, r: Reihe, modell: str) -> dict:
    """μ früherer Prognosen desselben Modells (gleiche Fassung, alle Quellen) als Felder je Woche über die Ursprünge der Reihe."""
    mu = {k: np.full(r.n + 1, np.nan) for k in WOCHEN}
    for D, k, m in con.execute("SELECT ursprung, woche, mu FROM vl_prognose WHERE coin=? AND modell=? AND fassung=?",
                               (r.coin, modell, FASSUNG)):
        i = int(D) - r.d0
        if 0 <= i <= r.n and m is not None:
            mu[int(k)][i] = float(m)
    return mu


def dvol_lage(q: dict) -> str:
    """Nachtrag 13.6: Liegt der Tageswert aus makro.db (Datum t) beim Stundenschluss 00:00 oder 08:00 UTC von t + 1? Nur Bericht."""
    ac, mc = lesen(q["aktien"]), lesen(q["makro"])
    try:
        if ac is None or mc is None:
            return "nicht prüfbar (aktien.db oder makro.db fehlt)"
        try:
            tagw = {int(ts) // TAG: float(w) for ts, w in mc.execute("SELECT ts, wert FROM mk_reihe WHERE reihe='drb:dvol_btc' "
                                                                       "ORDER BY ts DESC LIMIT 400")}
            std = {int(ts): float(w) for ts, w in ac.execute("SELECT ts, wert FROM ak_aktuell WHERE reihe='drb:dvol_btc_h' AND ts>=?",
                                                              ((min(tagw) if tagw else 0) * TAG,))}
        except sqlite3.Error as e:
            return "nicht prüfbar (" + str(e)[:60] + ")"
        n0 = n8 = n = 0
        for t, w in tagw.items():
            a, b = std.get((t + 1) * TAG - 3600), std.get((t + 1) * TAG + 7 * 3600)
            if a is None or b is None:
                continue
            n += 1
            n0 += abs(a - w) < 0.01
            n8 += abs(b - w) < 0.01
        return f"{n} Tage verglichen: gleich dem Schluss 00:00 UTC {n0}, 08:00 UTC {n8}" if n else "keine gemeinsamen Tage"
    finally:
        for c in (ac, mc):
            if c is not None:
                c.close()


def erstlauf(con, q: dict, jetzt: int | None = None, rb_start: int = RB_START) -> str:
    """Prüft Kerzen, DVOL (Einheit, Lage der Tageskerze) und Termine; setzt den Stichtag beim ersten Lauf mit ausreichenden Kerzen –
    oder übernimmt ihn aus volatil_stichtag.json (Nachtrag 13.10)."""
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    z = ["Erstlauf Volatilität " + _uhr(jetzt) + " (Modul " + VERSION_MODUL + ", Fassung " + FASSUNG + ")"]
    t = tage_aktualisieren(con, q["swing"], jetzt)
    d = dvol_aktualisieren(con, q["aktien"], q["makro"])
    m = termine_aktualisieren(con, q["makro"], heute)
    ok = True
    if t.get("fehlt"):
        z.append("  Kerzen: " + t["fehlt"])
        ok = False
    else:
        for coin in COINS:
            e = t.get(coin) or {}
            if not e.get("tage"):
                z.append(f"  {coin}: keine Kerzen in swing.db")
                ok = ok and coin not in PRUEF_COINS
                continue
            von, bis = e["von"], e["bis"]
            g = con.execute("SELECT COUNT(*) FROM vl_tag WHERE coin=? AND rv IS NOT NULL", (coin,)).fetchone()[0]
            luecken = [r[0] for r in con.execute("SELECT tag FROM vl_tag WHERE coin=? AND rv IS NULL ORDER BY tag", (coin,))]
            z.append(f"  {coin}: Tage {_datum(von)} bis {_datum(bis)} ({e['tage']} Tage, {e['kerzen']} Kerzen), gültig "
                     f"{_pz(g / max(1, e['tage']))}; ungültige Tage: {len(luecken)}"
                     + (" (zuletzt " + _datum(luecken[-1]) + ")" if luecken else ""))
            if coin in PRUEF_COINS and (von > rb_start - (FENSTER_MIN + 30 + 28) or bis < heute - 3):
                ok = False
                z.append(f"    ⚠ {coin}: zu wenig Vorlauf vor {_datum(rb_start)} oder nicht aktuell (swing.db)")
    faktor = {}
    for c in DVOL_COINS:
        e = d.get(c) or {}
        f, text = dvol_einheit(e.get("median"))
        faktor[c] = f
        z.append(f"  DVOL {c} (aktien.db, Stunde 23 UTC): {e.get('tage', 0)} Tage, {_datum(e.get('von'))} bis {_datum(e.get('bis'))},"
                 f" Median der letzten 365 Tage {_de(e.get('median'), 1)}: {text}" + ("" if f else "  ⚠ M+ und V4 entfallen"))
    z.append("  DVOL BTC aus makro.db (nur Anzeige): " + dvol_lage(q))
    for a in TERMIN_TEXT:
        r = con.execute("SELECT MIN(tag) FROM vl_termin WHERE art=? AND tag>=?", (a, heute)).fetchone()[0]
        z.append(f"  Termine {TERMIN_TEXT[a]}: {m.get(a, 0)}, nächster {_datum(r)}")
    z.append(f"  Bestätigte Inflations- und Arbeitsmarkttermine (Erstveröffentlichung am Tag): {m.get('bestaetigt', 0)}")
    if "fred" not in m.get("quellen", []):
        z.append("  ⚠ keine FRED-Termine in makro.db (Inflation, Arbeitsmarkt): Terminfaktoren bleiben 1")
    st = stichtag(con)
    datei = stichtag_datei(q)
    try:
        with open(datei, encoding="utf-8") as fh:
            aus_datei = int(json.load(fh).get("stichtag"))
    except (OSError, ValueError, TypeError, AttributeError):
        aus_datei = None
    with schreiben(con):
        meta_setzen(con, "dvol_faktor", faktor)
        if not st and aus_datei:
            meta_setzen(con, "stichtag", aus_datei)
            st = aus_datei
            z.append("  Stichtag aus volatil_stichtag.json übernommen (volatil.db war neu)")
        elif ok and not st:
            meta_setzen(con, "stichtag", jetzt)
            st = jetzt
    if st and aus_datei != st:
        try:
            tmp = datei + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"stichtag": st, "uhr": _uhr(st), "fassung": FASSUNG}, fh)
            os.replace(tmp, datei)
        except OSError as e:
            z.append("  ⚠ volatil_stichtag.json nicht geschrieben: " + str(e)[:100])
    z.append("  Stichtag: " + (_uhr(st) + " (Ursprünge bis " + _datum(st // TAG) + " Rückblick, danach vorwärts)" if st else
                               "noch nicht gesetzt (Kerzen unvollständig; neuer Versuch in einer Stunde)"))
    with schreiben(con):
        meta_setzen(con, "erstlauf", {"ts": jetzt, "ok": ok, "bericht": z})
    return "\n".join(z)


class Rueckblick:
    """Rückblick in Schritten (Konzept 5, Nachtrag 13.5): je Schritt ein Coin und ein Monat – Schätzung zum Monatsersten und die
    Prognosen der Ursprünge dieses Monats, nur mit Tagen vor dem Stichtag. Vor dem Start des Rückblicks ein Vorlauf ab dem ersten
    möglichen Monat (Quelle „vorlauf“, nur für σ außerhalb). Fortschritt in vl_meta „rb“."""

    def __init__(self, con, rb_start: int = RB_START):
        self.con = con
        self.rb_start = rb_start
        self.reihen = None
        self.mu: dict = {}

    def zustand(self) -> dict:
        return meta(self.con, "rb", {}) or {}

    def fertig(self) -> bool:
        return bool(self.zustand().get("fertig"))

    def _monate(self, coin: str, st: int) -> list[int]:
        r = self.reihen.get(coin)
        if r is None:
            return []
        aus, m = [], monatserster(r.d0 + (31 if coin in GELIEHEN else 30 + FENSTER_MIN))
        while m <= st:
            aus.append(m)
            m = naechster_monat(m)
        return aus

    def schritt(self, jetzt: int | None = None) -> bool:
        """Ein Schritt; False, wenn nichts mehr zu tun ist."""
        st = stichtag_tag(self.con)
        if st is None:
            return False
        z = self.zustand()
        if z.get("fertig"):
            return False
        if self.reihen is None:
            self.reihen = reihen_laden(self.con, bis_tag=st)
        erledigt = dict(z.get("erledigt") or {})
        jetzt = int(jetzt or time.time())
        offen = None
        for coin in PRUEF_COINS + GELIEHEN:
            letzter = erledigt.get(coin)
            for m in self._monate(coin, st):
                if letzter is None or m > letzter:
                    offen = (coin, m)
                    break
            if offen:
                break
        if offen is None:
            n = self.con.execute("SELECT COUNT(DISTINCT coin || ':' || ursprung) FROM vl_prognose WHERE quelle='rb'").fetchone()[0]
            with schreiben(self.con):
                meta_setzen(self.con, "rb", {**z, "erledigt": erledigt, "fertig": True, "ende": jetzt, "ursprünge": n,
                                             "coins_fertig": list(PRUEF_COINS + GELIEHEN)})
            return False
        coin, m = offen
        r = self.reihen[coin]
        koeff, prog = [], []
        von = max(m, r.d0 + 1)
        bis = min(naechster_monat(m) - 1, st)
        for modell in modelle_fuer(coin):
            fits = koeff_rechnen(self.reihen, coin, modell, m)
            if fits is None:
                continue
            koeff += _koeff_zeilen(coin, modell, m, fits, jetzt)
            key = (coin, modell)
            if key not in self.mu:
                self.mu[key] = mu_laden(self.con, r, modell)
            mu = self.mu[key]
            _, mit_x = modell_dvol(modell)
            for D in range(von, bis + 1):                 # erst alle μ des Monats (σ außerhalb braucht sie für spätere Ursprünge)
                i = D - r.d0
                x = merkmale(r, np.array([i]), mit_x)[0]
                if np.all(np.isfinite(x)) and not (modell == "M0" and not np.isfinite(r.dvol_x[i])):
                    for k in WOCHEN:
                        mu[k][i] = float(np.dot(fits[k]["beta"], x))
            fehler = Fehler(r, mu)
            for D in range(von, bis + 1):
                i = D - r.d0
                if modell == "M0" and not np.isfinite(r.dvol_x[i]):
                    continue
                pr = vorhersage(r, i, fits, modell, fehler, pfad=D >= self.rb_start)
                if pr:
                    prog += _prognose_zeilen(coin, D, modell, pr, "rb" if D >= self.rb_start else "vorlauf", jetzt)
        erledigt[coin] = m
        plan = {c: self._monate(c, st) for c in PRUEF_COINS + GELIEHEN}
        n_plan = sum(len(v) for v in plan.values())
        n_fertig = sum(sum(1 for mm in v if mm <= erledigt.get(c, -1)) for c, v in plan.items())
        coins_fertig = [c for c, v in plan.items() if not v or erledigt.get(c, -1) >= v[-1]]
        with schreiben(self.con):
            _einfuegen(self.con, koeff, prog)
            meta_setzen(self.con, "rb", {"erledigt": erledigt, "fertig": False, "start": z.get("start") or jetzt,
                                         "schritte": n_fertig, "plan": n_plan, "coins_fertig": coins_fertig,
                                         "zuletzt": coin + " " + _datum(m)})
        return True


def rb_coins_fertig(con) -> list[str]:
    z = meta(con, "rb", {}) or {}
    if z.get("fertig"):
        return list(PRUEF_COINS + GELIEHEN)
    return list(z.get("coins_fertig") or [])


def swing_vollstaendig(swing_p: str, heute: int, coins=PRUEF_COINS) -> bool:
    """Hat swing.db die letzte Kerze des Vortags (23:30 UTC) für alle Prüf-Coins?"""
    sc = lesen(swing_p)
    if sc is None:
        return False
    try:
        for c in coins:
            m = sc.execute("SELECT MAX(ts) FROM sw_klines WHERE coin=?", (c,)).fetchone()[0]
            if m is None or int(m) < heute * TAG - BAR:
                return False
        return True
    except sqlite3.Error:
        return False
    finally:
        sc.close()


def tageslauf(con, q: dict, jetzt: int | None = None, daten: bool = True) -> dict:
    """Prognosen ab dem Tag nach dem Stichtag bis heute (Quelle „live“ am eigenen Tag, „spaet“ nachgeholt), mit der Schätzung des
    Monatsersten (gespeichert in vl_koeff; fehlt sie, wird sie jetzt mit den Tagen vor dem Monatsersten gerechnet) und σ aus den
    Fehlern früherer Prognosen desselben Modells."""
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    aus = {"ts": jetzt, "neu": 0, "fehlt": {}}
    if daten:
        aus["tage"] = tage_aktualisieren(con, q["swing"], jetzt)
        aus["dvol"] = dvol_aktualisieren(con, q["aktien"], q["makro"])
        aus["termine"] = termine_aktualisieren(con, q["makro"], heute)
    st = stichtag_tag(con)
    if st is None or not Rueckblick(con).fertig():
        aus["grund"] = "Rückblick noch nicht fertig"
        return aus
    reihen = reihen_laden(con, bis_tag=heute)
    for coin in COINS:
        r = reihen.get(coin)
        if r is None:
            continue
        letzte = con.execute("SELECT MAX(ursprung) FROM vl_prognose WHERE coin=? AND quelle IN ('live','spaet') AND fassung=?",
                             (coin, FASSUNG)).fetchone()[0]
        start = max(st + 1, (int(letzte) + 1) if letzte is not None else st + 1)
        letzter_tag = con.execute("SELECT MAX(tag) FROM vl_tag WHERE coin=?", (coin,)).fetchone()[0]
        prog = []
        for modell in modelle_fuer(coin):
            mu = mu_laden(con, r, modell)
            for D in range(start, heute + 1):
                monat = monatserster(D)
                fits = koeff_holen(con, coin, modell, monat)
                if fits is None:
                    vor = reihen_laden(con, bis_tag=monat)     # die monatliche Neuschätzung: nur Tage vor dem Monatsersten
                    fits = koeff_rechnen(vor, coin, modell, monat) if (coin in vor or modell == "geliehen") else None
                    if fits is not None:
                        with schreiben(con):
                            _einfuegen(con, _koeff_zeilen(coin, modell, monat, fits, jetzt), [])
                if fits is None:
                    aus["fehlt"][coin + " " + modell] = "keine Schätzung für " + _datum(monat)
                    continue
                i = D - r.d0
                if not 0 <= i <= r.n:
                    aus["fehlt"][coin + " " + modell] = "keine Tageswerte bis " + _datum(D - 1)
                    continue
                if modell == "M0" and not np.isfinite(r.dvol_x[i]):
                    aus["fehlt"][coin + " " + modell] = "keine DVOL-Stunde für " + _datum(D)
                    continue
                pr = vorhersage(r, i, fits, modell, Fehler(r, mu))
                if pr is None:
                    aus["fehlt"][coin + " " + modell] = "Merkmale fehlen am " + _datum(D)
                    continue
                for z_ in pr:
                    mu[z_["woche"]][i] = z_["mu"]
                prog += _prognose_zeilen(coin, D, modell, pr, "live" if D == heute else "spaet", jetzt,
                                         {"letzter_tag": letzter_tag, "dvol_tag": (D - 1) if np.isfinite(r.dvol_x[i]) else None})
        if prog:
            with schreiben(con):
                _einfuegen(con, [], prog)
            aus["neu"] += len(prog)
    with schreiben(con):
        meta_setzen(con, "tageslauf", {"ts": jetzt, "neu": aus["neu"], "fehlt": aus["fehlt"], "heute": heute})
    return aus


# ---------------------------------------------------------------------------
# 8. Auswertung (Konzept 6, Nachtrag 13.2–13.3, 13.11–13.14)
# ---------------------------------------------------------------------------

def bloecke() -> tuple[int, ...]:
    return (28, 42, 56) if _MUT == "block_28" else BLOECKE


def block_bootstrap(n_t, s_t, ziehungen: int = ZIEHUNGEN, block: int = BLOECKE[0], saat: int = SAAT, starts=None) -> dict:
    """Studentisierter, zentrierter Block-Bootstrap über Ursprungstage (Konzept 6.3): θ = Σs / Σn (Gewicht je gültigem Wert),
    zirkuläre Blöcke, p = (1 + #{T* ≥ T}) / (B + 1), einseitig für θ > 0; dazu ein 90-%-Intervall (Perzentil-t)."""
    n_t = np.asarray(n_t, dtype=float)
    s_t = np.asarray(s_t, dtype=float)
    k = len(n_t)
    N = float(n_t.sum())
    leer = {"n": int(N), "tage": k, "mass": None, "se": None, "T": None, "p": None, "lo": None, "hi": None, "block": block,
            "bloecke": 0}
    if k < 2 or N <= 0:
        return leer
    th = float(s_t.sum()) / N
    b = 1 if _MUT == "bootstrap_ohne_bloecke" else max(1, min(int(block), k))
    idx = np.arange(0, k, b)
    bn0 = np.add.reduceat(n_t, idx)
    bs0 = np.add.reduceat(s_t, idx)
    se0 = math.sqrt(float(np.sum((bs0 - th * bn0) ** 2))) / N
    if se0 <= 0:
        return dict(leer, mass=th, se=se0)
    T = th / se0
    n2 = np.concatenate([n_t, n_t[:b - 1]])
    s2 = np.concatenate([s_t, s_t[:b - 1]])
    cn = np.concatenate([[0.0], np.cumsum(n2)])
    cs = np.concatenate([[0.0], np.cumsum(s2)])
    kn = cn[b:b + k] - cn[:k]
    ks = cs[b:b + k] - cs[:k]
    nb = -(-k // b)
    if starts is None:
        starts = np.random.default_rng(saat).integers(0, k, size=(ziehungen, nb))
    BN = kn[starts]
    BS = ks[starts]
    Nst = BN.sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        tst = BS.sum(axis=1) / Nst
        sest = np.sqrt(np.sum((BS - tst[:, None] * BN) ** 2, axis=1)) / Nst
    ok = np.isfinite(tst) & (sest > 0)
    tt = (tst[ok] - th) / sest[ok]
    p = (1 + int(np.sum(tt >= T))) / (len(starts) + 1)
    if _MUT == "bootstrap_perzentil":
        p = float(np.sum(tst <= 0)) / len(starts)
    lo = hi = None
    if len(tt):
        q05, q95 = np.quantile(tt, [0.05, 0.95])
        lo, hi = th - float(q95) * se0, th - float(q05) * se0
    return {"n": int(N), "tage": k, "mass": th, "se": se0, "T": T, "p": p, "lo": lo, "hi": hi, "block": b, "bloecke": len(idx)}


def block_bootstrap_schleife(n_t, s_t, starts, block: int) -> float:
    """Langsame Vergleichsfassung (Selbsttest): dieselben Startpunkte, Schleife statt Feldrechnung -> p."""
    k = len(n_t)
    b = min(block, k)
    N = sum(n_t)
    th = sum(s_t) / N
    se0 = math.sqrt(sum((sum(s_t[j:j + b]) - th * sum(n_t[j:j + b])) ** 2 for j in range(0, k, b))) / N
    T = th / se0
    groesser = 0
    for zeile in starts:
        bl = [(sum(n_t[(st + i) % k] for i in range(b)), sum(s_t[(st + i) % k] for i in range(b))) for st in zeile]
        n = sum(x[0] for x in bl)
        t_st = sum(x[1] for x in bl) / n
        se = math.sqrt(sum((x[1] - t_st * x[0]) ** 2 for x in bl)) / n
        if se > 0 and (t_st - th) / se >= T:
            groesser += 1
    return (1 + groesser) / (len(starts) + 1)


def haelften(n_t, s_t) -> tuple:
    """Hälften am Median-Datum der Ursprungstage (Konzept 6.4, Nachtrag 13.2): (θ erste, θ zweite, Tage erste, Tage zweite)."""
    n_t = np.asarray(n_t, dtype=float)
    s_t = np.asarray(s_t, dtype=float)
    k = len(n_t) // 2
    if _MUT == "haelften_faelle" and len(n_t):
        cum = np.cumsum(n_t)
        k = int(np.searchsorted(cum, cum[-1] / 2.0))
    aus = []
    for a, b in ((0, k), (k, len(n_t))):
        N = n_t[a:b].sum()
        aus.append(float(s_t[a:b].sum() / N) if b - a >= 2 and N > 0 else None)
    return aus[0], aus[1], k, len(n_t) - k


def holm_gewichtet(p: dict, w: dict) -> dict:
    """Gewichteter Holm: angepasste p-Werte; Gewichte auf die prüfbaren Tests normiert (Konzept 6.3)."""
    gueltig = {k: v for k, v in p.items() if v is not None}
    aus = {k: None for k in p}
    if _MUT == "holm_weg":
        return dict(p)
    if not gueltig:
        return aus
    summe = sum(w[k] for k in gueltig)
    gew = {k: w[k] / summe for k in gueltig}
    rest = set(gueltig)
    vorher = 0.0
    for k in sorted(gueltig, key=lambda x: gueltig[x] / gew[x]):
        wert = min(1.0, max(vorher, gueltig[k] * sum(gew[j] for j in rest) / gew[k]))
        aus[k] = wert
        vorher = wert
        rest.discard(k)
    return aus


def regel_teil(e: dict, min_tage: int = MIN_TAGE, min_haelfte: int = MIN_HAELFTE) -> tuple[bool, str]:
    """Bedingungen außer p: Mindestzahl an Ursprungstagen, Maß > 0, beide Hälften > 0 und groß genug."""
    if (e.get("tage") or 0) < min_tage and _MUT != "mindestzahl_ignoriert":
        return False, "nicht prüfbar"
    if e.get("mass") is None:
        return False, "nicht prüfbar"
    h1, h2 = e.get("h1"), e.get("h2")
    halb = (h1 is not None and h2 is not None and min(e.get("k1") or 0, e.get("k2") or 0) >= min_haelfte and h1 > 0 and h2 > 0)
    if _MUT == "haelften_ignoriert":
        halb = True
    return (e["mass"] > 0 and halb), ""


def urteil(e: dict, p_holm, min_tage: int = MIN_TAGE, min_haelfte: int = MIN_HAELFTE) -> str:
    """Konzept 6.4: belegt nur mit angepasstem p < 0,05, Maß > 0, beiden Hälften > 0 (jede mit mindestens min_haelfte Tagen) und
    erreichter Mindestzahl an Ursprungstagen."""
    ok, grund = regel_teil(e, min_tage, min_haelfte)
    if grund:
        return grund
    if p_holm is None:
        return "nicht prüfbar"
    return "belegt" if (ok and p_holm < 0.05) else "nicht belegt"


def v1_diff(R, vb, vm):
    """Niveau je Fall: QLIKE des Vergleichs minus QLIKE von M (positiv = M besser)."""
    d = qlike(R, vb) - qlike(R, vm)
    return -d if _MUT == "qlike_vorzeichen" else d


class Faelle:
    """Dichte Felder [Ursprungstag × Coin × Woche] aus vl_prognose und den eingetretenen Wochen (Konzept 6.1–6.2)."""

    FELDER = ("mu", "sigma", "v", "v_b0", "v_b365", "v_ewma", "schwelle", "p", "p_grund", "p_markov")

    def __init__(self, con, reihen: dict, von: int, bis: int, coins=PRUEF_COINS, quellen=("rb",), modelle=("M", "M+", "M0"),
                 mit_pfad: bool = False):
        self.tage = np.arange(int(von), int(bis) + 1)
        self.coins = tuple(coins)
        T, C, K = len(self.tage), len(self.coins), len(WOCHEN)
        self.R = np.full((T, C, K), np.nan)
        self.RRS = np.full((T, C, K), np.nan)
        self.A = {m: {f: np.full((T, C, K), np.nan) for f in self.FELDER} for m in modelle}
        self.pfad = {} if mit_pfad else None
        self.quellen_gesehen: dict[str, int] = {}
        self.max_ursprung = None
        if T <= 0 or not self.coins:
            return
        ci = {c: j for j, c in enumerate(self.coins)}
        ph = lambda xs: ",".join("?" * len(xs))  # noqa: E731
        for zeile in con.execute(
                "SELECT coin, ursprung, modell, woche, " + ", ".join(self.FELDER) + ", " + ("pfad" if mit_pfad else "NULL") +
                ", quelle FROM vl_prognose WHERE fassung=? AND quelle IN (" + ph(quellen) + ") AND coin IN (" + ph(self.coins) +
                ") AND modell IN (" + ph(modelle) + ") AND ursprung BETWEEN ? AND ?",
                (FASSUNG, *quellen, *self.coins, *modelle, int(von), int(bis))):
            coin, D, modell, k = zeile[:4]
            t, c, kk = int(D) - int(von), ci[coin], int(k) - 1
            for f, w in zip(self.FELDER, zeile[4:4 + len(self.FELDER)]):
                self.A[modell][f][t, c, kk] = np.nan if w is None else w
            if mit_pfad and kk == 0 and zeile[-2] and modell == modelle[0]:
                self.pfad[(t, c)] = json.loads(zeile[-2])
            self.quellen_gesehen[zeile[-1]] = self.quellen_gesehen.get(zeile[-1], 0) + 1
            self.max_ursprung = int(D) if self.max_ursprung is None else max(self.max_ursprung, int(D))
        for c, j in ci.items():
            r = reihen.get(c)
            if r is None:
                continue
            i = self.tage - r.d0
            drin = (i >= 0) & (i <= r.n)
            ii = i[drin]
            cs, cn = _praefix(r.rs) if r.rs is not None else (None, None)
            for kk, k in enumerate(WOCHEN):
                self.R[drin, j, kk] = r.ziel[k][ii]
                if cs is not None:
                    self.RRS[drin, j, kk] = _fenster(cs, cn, ii + 7 * (k - 1), ii + 7 * k, 6)

    def a(self, modell: str, feld: str) -> np.ndarray:
        m = self.A.get(modell)
        return m[feld] if m is not None else np.full(self.R.shape, np.nan)

    def y(self) -> np.ndarray:
        S = self.a("M", "schwelle")
        with np.errstate(invalid="ignore"):
            return np.where(np.isfinite(self.R) & np.isfinite(S), (self.R > S).astype(float), np.nan)

    def diff(self, teil: str, R=None) -> np.ndarray:
        """Verlustdifferenz je Fall (positiv = M besser bzw. M+ besser)."""
        R = self.R if R is None else R
        vm = self.a("M", "v")
        if teil == "V1a":
            return v1_diff(R, self.a("M", "v_b0"), vm)
        if teil == "V1b":
            return v1_diff(R, self.a("M", "v_b365"), vm)
        if teil == "EWMA":
            return v1_diff(R, self.a("M", "v_ewma"), vm)
        if teil in ("V2", "V3"):
            y = self.y()
            basis = self.a("M", "p_grund" if teil == "V2" else "p_markov")
            return (basis - y) ** 2 - (self.a("M", "p") - y) ** 2
        if teil == "V4":
            return qlike(R, self.a("M0", "v")) - qlike(R, self.a("M+", "v"))
        if teil == "orakel_b0":                         # Zuordnung (13.14 Punkt 5): B0^0,7 · R^0,3 gegen B0
            b0 = self.a("M", "v_b0")
            with np.errstate(invalid="ignore"):
                return qlike(R, b0) - qlike(R, b0 ** 0.7 * R ** 0.3)
        if teil == "orakel_p":
            y = self.y()
            g = self.a("M", "p_grund")
            return (g - y) ** 2 - (g + 0.3 * (y - g) - y) ** 2
        raise ValueError(teil)

    @staticmethod
    def je_tag(d: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """(Indizes der Tage mit mindestens einem Wert, n je Tag, Summe je Tag)."""
        if d.size == 0:
            return np.zeros(0, dtype=np.int64), np.zeros(0), np.zeros(0)
        g = np.isfinite(d)
        n = g.reshape(len(d), -1).sum(axis=1)
        s = np.where(g, d, 0.0).reshape(len(d), -1).sum(axis=1)
        ok = n > 0
        return np.nonzero(ok)[0], n[ok].astype(float), s[ok]


def pruefe_teil(F: Faelle, teil: str, block: int, ziehungen: int = ZIEHUNGEN, saat: int = SAAT, d=None) -> dict:
    t, n, s = F.je_tag(F.diff(teil) if d is None else d)
    e = block_bootstrap(n, s, ziehungen, block, saat)
    e["h1"], e["h2"], e["k1"], e["k2"] = haelften(n, s)
    e["von"] = int(F.tage[t[0]]) if len(t) else None
    e["bis"] = int(F.tage[t[-1]]) if len(t) else None
    e["saat"] = saat
    return e


def vorzeichen_rate(tage, n_t, s_t, block: int, welten: int = WELTEN, ziehungen: int = 999, min_tage: int = MIN_TAGE,
                    min_haelfte: int = MIN_HAELFTE, vz_block: int = VZ_BLOCK, saat: int = 7000) -> float:
    """Vorzeichen-Nullprobe (Nachtrag 13.3): Tagessummen um ihr Mittel verschoben, Vorzeichen zufällig je 224-Tage-Block (nach
    Kalendertag), volle Urteilsregel ohne Holm -> Anteil „belegt“."""
    n_t = np.asarray(n_t, dtype=float)
    s_t = np.asarray(s_t, dtype=float)
    if len(n_t) < 2 or n_t.sum() <= 0:
        return 1.0
    zentriert = s_t - n_t * (s_t.sum() / n_t.sum())
    gruppe = (np.asarray(tage) - int(tage[0])) // vz_block
    ng = int(gruppe.max()) + 1
    belegt = 0
    for w in range(welten):
        rng = np.random.default_rng(saat + w)
        vz = rng.choice((-1.0, 1.0), size=ng)[gruppe]
        sw = vz * zentriert
        e = block_bootstrap(n_t, sw, ziehungen, block, saat + 50_000 + w)
        e["h1"], e["h2"], e["k1"], e["k2"] = haelften(n_t, sw)
        belegt += urteil(e, e["p"], min_tage, min_haelfte) == "belegt"
    return belegt / welten


def blockregel(F: Faelle, teil: str, welten: int = WELTEN, ziehungen: int = 999, min_tage: int = MIN_TAGE,
               min_haelfte: int = MIN_HAELFTE, bl: tuple | None = None, vz_block: int = VZ_BLOCK) -> tuple[int | None, dict]:
    """Automatische Blockregel (13.3): die erste Blocklänge, bei der die Vorzeichen-Nullprobe besteht; sonst None."""
    t, n, s = F.je_tag(F.diff(teil))
    grenze = 0.05 + 2.326 * math.sqrt(0.05 * 0.95 / welten)
    raten = {}
    for b in (bl or bloecke()):
        rate = vorzeichen_rate(F.tage[t] if len(t) else t, n, s, b, welten, ziehungen, min_tage, min_haelfte, vz_block)
        raten[b] = rate
        if rate <= grenze:
            return b, raten
    return None, raten


def freigabe(con) -> tuple[bool, str]:
    """Gemeinsames Urteil erst, wenn der Stichtag gesetzt und der Rückblick aller Prüf-Coins fertig ist (Regel 4)."""
    if stichtag(con) is None:
        return False, "kein Stichtag (Erstlauf fehlt)"
    fertig = rb_coins_fertig(con)
    fehlend = [c for c in PRUEF_COINS if c not in fertig]
    if _MUT == "urteile_einzeln" and len(fehlend) < len(PRUEF_COINS):
        return True, ""
    return (not fehlend), ("Rückblick offen: " + ", ".join(fehlend) if fehlend else "")


def _korr(x, y) -> float | None:
    g = np.isfinite(x) & np.isfinite(y)
    if g.sum() < 10:
        return None
    return float(np.corrcoef(x[g], y[g])[0, 1])


def daten_pruefung(con, reihen: dict, q: dict | None, st: int) -> dict:
    """Prüfung 1 (13.14): Tages-RV gleich hl_swing.tagesreihen vom Beginn der Kerzen an; je Coin ≥ 98 % gültige Tage ab Beginn der
    Schätzfenster (erster Tag mit R30). -> {coin: (ok, Text)}"""
    aus = {}
    sc = lesen(q["swing"]) if q else None
    try:
        import hl_swing
        for coin in PRUEF_COINS:
            r = reihen.get(coin)
            if r is None:
                aus[coin] = (False, "keine Tageswerte")
                continue
            abw, fehl, n_vgl = 0.0, 0, 0
            if sc is None:
                aus[coin] = (False, "swing.db nicht lesbar")
                continue
            K = hl_swing.kerzen_lesen(sc, coin)
            T = hl_swing.tagesreihen(K) if K else None
            if T is None:
                aus[coin] = (False, "keine Kerzen")
                continue
            for e in range(T["nd"]):
                t = T["d0"] + e
                if t >= st or t < r.d0 or t - r.d0 >= r.n:
                    continue
                a, b = T["RV"][e], r.rv[t - r.d0]
                n_vgl += 1
                if bool(np.isfinite(a)) != bool(np.isfinite(b)):
                    fehl += 1
                elif np.isfinite(a):
                    abw = max(abw, float(abs(a - b) / max(abs(a), 1e-300)))
            a0 = min(r.n, 30)
            anteil = float(np.mean(np.isfinite(r.rv[a0:max(a0, min(r.n, st - r.d0))]))) if r.n > a0 else 0.0
            ok = fehl == 0 and abw < 1e-9 and n_vgl > 0 and anteil >= 0.98
            aus[coin] = (bool(ok), f"{n_vgl} Tage verglichen, größte Abweichung {abw:.1e}, abweichende Gültigkeit {fehl}, "
                                   f"gültig {_pz(anteil)}")
    finally:
        if sc is not None:
            sc.close()
    return aus


def pruefungen_vor_urteil(con, F: Faelle, reihen: dict, q: dict | None, st: int, welten: int = WELTEN, ziehungen: int = 999,
                          min_tage: int = MIN_TAGE, min_haelfte: int = MIN_HAELFTE, bl: tuple | None = None,
                          vz_block: int = VZ_BLOCK, orakel_t: float = 5.0) -> dict:
    """Nachtrag 13.14. Rückgabe: {"liste": [(Name, bestanden, Wert)], "ok": global bestanden, "coins": verbleibende Prüf-Coins,
    "bloecke": {Teil: Blocklänge oder None}, "raten": {Teil: {Block: Rate}}, "v4": V4 möglich}."""
    liste = []
    dp = daten_pruefung(con, reihen, q, st)
    coins = [c for c in PRUEF_COINS if dp.get(c, (False, ""))[0]]
    raus = [c for c in PRUEF_COINS if c not in coins]
    liste.append(("Daten: Tages-RV gleich hl_swing.tagesreihen, mindestens 98 % gültige Tage je Coin", len(coins) >= 3,
                  "; ".join(f"{c} {'✓' if dp[c][0] else '✗'} {dp[c][1]}" for c in dp) + (f"; ohne {', '.join(raus)}" if raus else "")))
    faktor = meta(con, "dvol_faktor", {}) or {}
    v4 = all(c in coins for c in DVOL_COINS) and all(faktor.get(c) for c in DVOL_COINS)
    liste.append(("DVOL: Einheit und BTC/ETH in den Daten (sonst entfällt V4)", True,
                  "V4 möglich" if v4 else "V4 entfällt (" + ", ".join(f"{c}: {faktor.get(c)}" for c in DVOL_COINS) + ")"))
    if len(coins) < len(F.coins):
        F = Faelle(con, reihen, F.tage[0], F.tage[-1], coins=coins) if len(F.tage) else F
    # 2. Datenprobe Ballung
    ks = {}
    for coin in coins:
        r = reihen.get(coin)
        i = F.tage - r.d0
        i = i[(i >= 0) & (i <= r.n)]
        with np.errstate(divide="ignore", invalid="ignore"):
            ks[coin] = _korr(np.log(r.vorwoche[i]), np.log(r.ziel[1][i]))
    liste.append(("Datenprobe Ballung: Korrelation Woche gegen Vorwoche > 0,4 je Coin",
                  bool(ks) and all(v is not None and v > 0.4 for v in ks.values()), ", ".join(f"{c} {_de(v, 2)}" for c, v in ks.items())))
    # 3. Datenprobe Wochenende
    qs = []
    for coin in coins:
        r = reihen.get(coin)
        b = min(r.n, st - r.d0)
        rv, wt = r.rv[:b], r.wt[:b]
        g = np.isfinite(rv)
        we, wk = rv[g & (wt >= 5)], rv[g & (wt < 5)]
        if len(we) and len(wk):
            qs.append(float(we.mean() / wk.mean()))
    v = float(np.mean(qs)) if qs else None
    liste.append(("Datenprobe Wochenende: Varianz Sa/So < 0,95 × Werktage", v is not None and v < 0.95, "Faktor " + _de(v, 2)))
    # 4. Fehlerprobe Bänder
    with np.errstate(invalid="ignore", over="ignore"):
        ober = np.exp(F.a("M", "mu") + Z90 * F.a("M", "sigma"))
        g = np.isfinite(F.R) & np.isfinite(ober)
        ant = float(np.mean(F.R[g] > ober[g])) if g.sum() else None
    liste.append(("Fehlerprobe Bänder: 0,5–25 % über dem 90-%-Band", ant is not None and 0.005 <= ant <= 0.25,
                  _pz(ant) + f" von {int(g.sum())} Wochen"))
    # 5. Zuordnung: zwei Orakel-Mischungen müssen deutlich belegt sein
    b0 = (bl or bloecke())[0]
    oz = []
    for teil, name in (("orakel_b0", "B0^0,7 · R^0,3 gegen B0"), ("orakel_p", "Grundrate + 0,3 · (y − Grundrate) gegen Grundrate")):
        e = pruefe_teil(F, teil, b0, ziehungen)
        oz.append((name, e))
    liste.append(("Zuordnung: Orakel-Mischungen mit T > " + _de(orakel_t, 1) + " belegt",
                  all((e.get("T") or 0) > orakel_t and urteil(e, e.get("p"), min_tage, min_haelfte) == "belegt" for _, e in oz),
                  "; ".join(f"{n}: T {_de(e.get('T'), 1)}, {urteil(e, e.get('p'), min_tage, min_haelfte)}" for n, e in oz)))
    # 6. Vorzeichen-Nullprobe je Teil mit automatischer Blockregel
    bloecke_ = {}
    raten = {}
    for teil in TEILE:
        if teil == "V4" and not v4:
            bloecke_[teil], raten[teil] = None, {}
            continue
        bloecke_[teil], raten[teil] = blockregel(F, teil, welten, ziehungen, min_tage, min_haelfte, bl, vz_block)
    liste.append(("Vorzeichen-Nullprobe je Prüfung (Blockregel 112 → 168 → 224 Tage)", True,
                  "; ".join(f"{t}: " + (f"Block {b}" if b else "Größe nicht gesichert") + " (" +
                            ", ".join(f"{k_} {_pz(v_)}" for k_, v_ in raten[t].items()) + ")" for t, b in bloecke_.items())))
    ok = all(b for _, b, _ in liste)
    return {"liste": liste, "ok": ok, "coins": coins, "bloecke": bloecke_, "raten": raten, "v4": v4, "F": F}


def zaehlung(F: Faelle, min_tage: int) -> dict:
    aus = {}
    for k in TEILE:
        t, n, s = F.je_tag(F.diff(k))
        aus[k] = {"tage": int(len(t)), "faelle": int(n.sum()), "min": int(min_tage)}
    return aus


def auswerten(con, q: dict | None = None, lauf: int | None = None, jetzt: int | None = None, ziehungen: int = ZIEHUNGEN,
              welten: int = WELTEN, null_ziehungen: int = 999, min_tage: int = MIN_TAGE, min_haelfte: int = MIN_HAELFTE,
              rb_start: int = RB_START, bl: tuple | None = None, vz_block: int = VZ_BLOCK, orakel_t: float = 5.0) -> dict:
    """Vor der Freigabe nur Zählung (Regel 4). Dann einmal das gemeinsame Urteil mit den Prüfungen vor dem Urteil; danach nur noch
    beschreibend die Vorwärtsrunde (13.11)."""
    lauf = int(lauf or time.time())
    jetzt = int(jetzt or lauf)
    frueher = con.execute("SELECT MIN(lauf) FROM vl_auswertung WHERE endgueltig=1 AND fassung=? AND pruefung IN "
                          "('V1','V2','V3','V4')", (FASSUNG,)).fetchone()[0]
    if frueher and _MUT != "urteil_neu":
        return {"lauf": lauf, "phase": "urteil", "urteil_vom": frueher,
                "vorwaerts": vorwaerts(con, lauf, jetzt, ziehungen, rb_start=rb_start)}
    st = stichtag_tag(con, jetzt)
    if st is None:
        with schreiben(con):
            meta_setzen(con, "zaehlung", {"lauf": lauf, "freigabe": False, "grund": "kein Stichtag (Erstlauf fehlt)"})
        return {"lauf": lauf, "phase": "zaehlung", "grund": "kein Stichtag"}
    von, bis = rb_start, st - 28
    reihen = reihen_laden(con, bis_tag=st if _MUT != "kein_stichtag" else jetzt // TAG)
    quellen_ = ("rb", "live", "spaet") if _MUT == "kein_stichtag" else ("rb",)
    F = Faelle(con, reihen, von, bis, quellen=quellen_)
    zaehl = zaehlung(F, min_tage)
    ok, grund = freigabe(con)
    with schreiben(con):
        meta_setzen(con, "zaehlung", {"lauf": lauf, "zaehlung": zaehl, "freigabe": ok, "grund": grund, "von": von, "bis": bis})
    if not ok:
        return {"lauf": lauf, "phase": "zaehlung", "zaehlung": zaehl, "grund": grund}
    vor = pruefungen_vor_urteil(con, F, reihen, q, st, welten, null_ziehungen, min_tage, min_haelfte, bl, vz_block, orakel_t)
    F = vor.pop("F")
    teile = {}
    for t in TEILE:
        b = vor["bloecke"].get(t)
        if b is None:
            teile[t] = {"tage": 0, "n": 0, "mass": None, "p": None, "grund": "Größe nicht gesichert" if (t != "V4" or vor["v4"])
                        else "V4 entfällt"}
            continue
        teile[t] = pruefe_teil(F, t, b, ziehungen, SAAT + TEILE.index(t))
    p_v1 = v1_p(teile["V1a"].get("p"), teile["V1b"].get("p"))
    teile_v1 = ("V1a",) if _MUT == "v1_ohne_b365" else ("V1a", "V1b")
    testbar = {}
    for k in PRUEFUNGEN:
        if k == "V1":
            genug = all((teile[t].get("tage") or 0) >= min_tage for t in teile_v1)
            testbar[k] = p_v1 if genug else None
        else:
            testbar[k] = teile[k].get("p") if (teile[k].get("tage") or 0) >= min_tage else None
    ph = holm_gewichtet(testbar, GEWICHT)
    urt = {}
    for k in PRUEFUNGEN:
        if not vor["ok"]:
            urt[k] = "kein Urteil (Prüfung vor dem Urteil nicht bestanden)"
        elif k == "V1":
            if any(teile[t].get("grund") for t in teile_v1):
                urt[k] = "nicht prüfbar (" + "; ".join(teile[t]["grund"] for t in teile_v1 if teile[t].get("grund")) + ")"
            else:
                urt[k] = v1_urteil(teile["V1a"], teile["V1b"], ph.get("V1"), min_tage, min_haelfte)
        elif teile[k].get("grund"):
            urt[k] = "nicht prüfbar (" + teile[k]["grund"] + ")"
        else:
            urt[k] = urteil(teile[k], ph.get(k), min_tage, min_haelfte)
    with schreiben(con):
        if con.execute("SELECT 1 FROM vl_auswertung WHERE endgueltig=1 AND fassung=? AND pruefung IN ('V1','V2','V3','V4') LIMIT 1",
                       (FASSUNG,)).fetchone() and _MUT != "urteil_neu":
            return {"lauf": lauf, "phase": "urteil", "hinweis": "Urteil schon von einem anderen Lauf geschrieben"}
        meta_setzen(con, "pruefungen_vor_urteil", {"lauf": lauf, "liste": vor["liste"], "ok": vor["ok"], "coins": vor["coins"],
                                                   "bloecke": vor["bloecke"], "raten": vor["raten"]})
        endg = 1 if vor["ok"] else 0
        for k in PRUEFUNGEN:
            if k == "V1":
                ea, eb = teile["V1a"], teile["V1b"]
                e = {"n": ea.get("n"), "tage": min(ea.get("tage") or 0, eb.get("tage") or 0),
                     "mass": None if ea.get("mass") is None or eb.get("mass") is None else min(ea["mass"], eb["mass"]),
                     "lo": None, "hi": None, "p": p_v1, "h1": None, "h2": None}
            else:
                e = teile[k]
            det = {"teile": ["V1a", "V1b"] if k == "V1" else [k], "stichprobe_bis": bis, "quellen": F.quellen_gesehen,
                   "max_ursprung": F.max_ursprung, "coins": list(F.coins), "min_tage": min_tage, "min_haelfte": min_haelfte,
                   "block": e.get("block"), "bloecke": e.get("bloecke"), "saat": e.get("saat"), "k1": e.get("k1"),
                   "k2": e.get("k2"), "von": e.get("von"), "bis": e.get("bis"), "se": e.get("se"), "T": e.get("T")}
            con.execute("INSERT OR REPLACE INTO vl_auswertung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (k, lauf, FASSUNG, e.get("n"), e.get("tage"), _f(e.get("mass")), _f(e.get("lo")), _f(e.get("hi")),
                         _f(e.get("p")) if endg else None, _f(ph.get(k)) if endg else None, _f(e.get("h1")) if endg else None,
                         _f(e.get("h2")) if endg else None, urt[k], endg, json.dumps(_ohne_nan(det), ensure_ascii=False)))
        for t in ("V1a", "V1b"):
            e = teile[t]
            det = {"block": e.get("block"), "bloecke": e.get("bloecke"), "saat": e.get("saat"), "k1": e.get("k1"), "k2": e.get("k2"),
                   "von": e.get("von"), "bis": e.get("bis"), "se": e.get("se"), "T": e.get("T"), "grund": e.get("grund")}
            con.execute("INSERT OR REPLACE INTO vl_auswertung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (t, lauf, FASSUNG, e.get("n"), e.get("tage"), _f(e.get("mass")), _f(e.get("lo")), _f(e.get("hi")),
                         _f(e.get("p")) if endg else None, None, _f(e.get("h1")) if endg else None, _f(e.get("h2")) if endg else None,
                         "Teil von V1", endg, json.dumps(_ohne_nan(det), ensure_ascii=False)))
    aus = {"lauf": lauf, "phase": "urteil" if vor["ok"] else "pruefung_nicht_bestanden", "vor_urteil": vor["liste"], "urteile": urt,
           "teile": teile}
    if vor["ok"]:
        try:
            b = beschreibend(con, F, reihen, st, vor["bloecke"], rb_start)
        except Exception as ex:  # noqa: BLE001 — beschreibend darf das Urteil nicht kippen
            b = {"fehler": (type(ex).__name__ + ": " + str(ex))[:300]}
        with schreiben(con):
            meta_setzen(con, "beschreibend", {"lauf": lauf, "werte": b})
        aus["beschreibend"] = b
    return aus


def _intervall(F: Faelle, d: np.ndarray, block: int, ziehungen: int = 1999, saat: int = SAAT) -> dict:
    t, n, s = F.je_tag(d)
    e = block_bootstrap(n, s, ziehungen, block, saat)
    h1, h2, _, _ = haelften(n, s)
    return {"mass": e.get("mass"), "lo": e.get("lo"), "hi": e.get("hi"), "h1": h1, "h2": h2, "tage": int(len(t))}


def besser_regel(iv: dict) -> bool:
    """Wie Ausblick 5.5 (S1): Die Baseline ist in dieser Woche besser, wenn das 90-%-Intervall der Differenz (Baseline − M) ganz
    unter 0 liegt und beide Hälften unter 0 sind."""
    return (iv.get("hi") is not None and iv["hi"] < 0 and iv.get("h1") is not None and iv.get("h2") is not None
            and iv["h1"] < 0 and iv["h2"] < 0)


def beschreibend(con, F: Faelle, reihen: dict, st: int, bl: dict, rb_start: int = RB_START) -> dict:
    """Konzept 6.6 und Nachtrag 13.4, 13.12, 13.16 – ohne p-Werte, erst nach dem Urteil."""
    aus: dict = {"je_woche": [], "je_coin": [], "zuverlaessigkeit": [], "mincer_zarnowitz": [], "deckung": [], "regel": {}}
    y = F.y()
    vergleiche = (("B0", "V1a", "V1a"), ("B365", "V1b", "V1b"), ("EWMA", "EWMA", "V1a"), ("grund", "V2", "V2"),
                  ("markov", "V3", "V3"))
    D = {name: F.diff(teil) for name, teil, _ in vergleiche}
    for kk, k in enumerate(WOCHEN):
        zeile = {"woche": k}
        regel = {}
        for name, teil, test in vergleiche:
            b = bl.get(test) or bloecke()[0]
            d = D[name].copy()
            maske = np.zeros_like(d, dtype=bool)
            maske[:, :, kk] = True
            iv = _intervall(F, np.where(maske, d, np.nan), b, saat=SAAT + 10 * k + len(name))
            zeile[name] = iv
            regel[name] = besser_regel(iv)
        aus["je_woche"].append(zeile)
        aus["regel"][str(k)] = regel
        p = F.a("M", "p")[:, :, kk]
        yy = y[:, :, kk]
        gg = np.isfinite(p) & np.isfinite(yy)
        klassen = []
        for j in range(10):
            m = gg & (p >= j / 10) & ((p < (j + 1) / 10) if j < 9 else (p <= 1.0))
            if m.sum():
                klassen.append({"von": j / 10, "n": int(m.sum()), "p": float(p[m].mean()), "anteil": float(yy[m].mean())})
        aus["zuverlaessigkeit"].append({"woche": k, "klassen": klassen})
        v = F.a("M", "v")[:, :, kk]
        R = F.R[:, :, kk]
        g2 = np.isfinite(v) & np.isfinite(R) & (v > 0)
        if g2.sum() > 10:
            X = np.column_stack([1.0 / v[g2], np.ones(int(g2.sum()))])
            a_, b_ = np.linalg.lstsq(X, R[g2] / v[g2], rcond=None)[0]
            aus["mincer_zarnowitz"].append({"woche": k, "a": float(a_), "b": float(b_), "n": int(g2.sum())})
        mu, sg = F.a("M", "mu")[:, :, kk], F.a("M", "sigma")[:, :, kk]
        for j, c in enumerate(F.coins):
            g3 = np.isfinite(R[:, j]) & np.isfinite(mu[:, j]) & np.isfinite(sg[:, j])
            if g3.sum():
                lr = np.log(R[:, j][g3])
                aus["deckung"].append({"coin": c, "woche": k, "n": int(g3.sum()),
                                       "in50": float(np.mean(np.abs(lr - mu[:, j][g3]) <= Z50 * sg[:, j][g3])),
                                       "in90": float(np.mean(np.abs(lr - mu[:, j][g3]) <= Z90 * sg[:, j][g3])),
                                       "ueber90": float(np.mean(lr > mu[:, j][g3] + Z90 * sg[:, j][g3]))})
    # Robustheit gegen wenige Extremwochen (13.12)
    rob = {}
    for teil in ("V1a", "V1b", "V2", "V3"):
        t, n, s = F.je_tag(F.diff(teil))
        if not len(t):
            continue
        th = s.sum() / n.sum()
        einfluss = np.abs(s - th * n)
        weg = np.argsort(einfluss)[::-1][:max(1, int(math.ceil(0.01 * len(t))))]
        rest = np.ones(len(t), dtype=bool)
        rest[weg] = False
        ohne = float(s[rest].sum() / n[rest].sum()) if rest.any() else None
        top10 = np.argsort(np.abs(s))[::-1][:10]
        jahre = {}
        for jt in sorted({tag_datum(int(F.tage[x])).year for x in t}):
            m = np.array([tag_datum(int(F.tage[x])).year == jt for x in t])
            jahre[str(jt)] = float(s[m].sum() / n[m].sum())
        rob[teil] = {"mittel": float(th), "ohne_1_prozent": ohne, "median_tag": float(np.median(s / n)),
                     "anteil_top10": float(s[top10].sum() / s.sum()) if s.sum() != 0 else None, "je_jahr": jahre,
                     "getragen_von_wenigen": bool(ohne is not None and (ohne > 0) != (th > 0))}
        jc = {}
        d = F.diff(teil)
        for j, c in enumerate(F.coins):
            g = np.isfinite(d[:, j, :])
            jc[c] = float(d[:, j, :][g].mean()) if g.any() else None
        rob[teil]["je_coin"] = jc
    aus["robust"] = rob
    for j, c in enumerate(F.coins):
        d1 = F.diff("V1a")
        g = np.isfinite(d1[:, j, :])
        aus["je_coin"].append({"coin": c, "n": int(g.sum()), "v1a": float(d1[:, j, :][g].mean()) if g.any() else None})
    # Tagespfad mit und ohne Kalender (QLIKE je Tag in Woche 1)
    try:
        Fp = Faelle(con, reihen, F.tage[0], F.tage[-1], coins=F.coins, quellen=("rb",), modelle=("M",), mit_pfad=True)
        mit, ohne = [], []
        for (t, c), pf in Fp.pfad.items():
            r = reihen.get(Fp.coins[c])
            D0 = int(Fp.tage[t])
            vflat = Fp.a("M", "v")[t, c, 0]
            for j in range(7):
                e = D0 + j - r.d0
                if 0 <= e < r.n and np.isfinite(r.rv[e]) and np.isfinite(vflat):
                    mit.append(float(qlike(r.rv[e], pf[j])))
                    ohne.append(float(qlike(r.rv[e], vflat)))
        aus["tagespfad"] = {"n": len(mit), "qlike_mit": float(np.mean(mit)) if mit else None,
                            "qlike_ohne": float(np.mean(ohne)) if ohne else None}
    except Exception as ex:  # noqa: BLE001
        aus["tagespfad"] = {"fehler": str(ex)[:200]}
    drs = F.diff("V1a", R=F.RRS)
    g = np.isfinite(drs)
    aus["v1a_rogers_satchell"] = {"n": int(g.sum()), "mittel": float(drs[g].mean()) if g.any() else None}
    # DVOL allein, kalibriert (BTC, ETH): log R_k auf log DVOL²
    dv = {}
    for c in DVOL_COINS:
        r = reihen.get(c)
        if r is None or c not in F.coins:
            continue
        j = F.coins.index(c)
        i = F.tage - r.d0
        drin = (i >= 0) & (i <= r.n)
        for kk, k in enumerate(WOCHEN):
            x = np.full(len(F.tage), np.nan)
            x[drin] = r.dvol_x[i[drin]]
            with np.errstate(divide="ignore", invalid="ignore"):
                yv = np.log(F.R[:, j, kk])
            g = np.isfinite(x) & np.isfinite(yv)
            if g.sum() > 30:
                b_, a_ = np.polyfit(x[g], yv[g], 1)
                rq = float(np.corrcoef(x[g], yv[g])[0, 1] ** 2)
                dv[f"{c} W{k}"] = {"a": float(a_), "b": float(b_), "r2": rq, "n": int(g.sum())}
    aus["dvol_allein"] = dv
    try:
        Fh = Faelle(con, reihen, F.tage[0], st, coins=("HYPE",), quellen=("rb",), modelle=("geliehen",))
        dh = v1_diff(Fh.R, Fh.a("geliehen", "v_b0"), Fh.a("geliehen", "v"))
        g = np.isfinite(dh)
        aus["hype"] = {"n": int(g.sum()), "v1a": float(dh[g].mean()) if g.any() else None}
    except Exception as ex:  # noqa: BLE001
        aus["hype"] = {"fehler": str(ex)[:200]}
    return aus


def vorwaerts(con, lauf: int, jetzt: int, ziehungen: int = ZIEHUNGEN, vorwaerts_min: int = VORWAERTS_MIN,
              rb_start: int = RB_START) -> dict:
    """Nachtrag 13.11: Live-Prognosen ab dem Stichtag, beschreibend je Monat (Differenz gegen B0, B365, Grundrate mit
    90-%-Intervall, Deckung); Warnregel nach 365 Live-Tagen; Bestätigungstest erst ab 1.344 Live-Ursprungstagen (einmal)."""
    st = stichtag_tag(con)
    heute = int(jetzt) // TAG
    if st is None:
        return {"phase": "kein Stichtag"}
    reihen = reihen_laden(con, bis_tag=heute)
    F = Faelle(con, reihen, st + 1, heute - 28, quellen=("live",), modelle=("M",))
    werte = {}
    for name, teil in (("B0", "V1a"), ("B365", "V1b"), ("Grundrate", "V2")):
        werte[name] = _intervall(F, F.diff(teil), BLOECKE[0], 999)
    tage = max((w["tage"] for w in werte.values()), default=0)
    warn = [n for n, w in werte.items() if tage >= VORWAERTS_WARN and w.get("hi") is not None and w["hi"] < 0]
    monate = {}
    for t in F.tage:
        monate.setdefault(tag_datum(int(t)).strftime("%Y-%m"), []).append(int(t) - int(F.tage[0]))
    je_monat = {}
    for mo, idx in monate.items():
        sub = {}
        for name, teil in (("B0", "V1a"), ("B365", "V1b"), ("Grundrate", "V2")):
            d = F.diff(teil)[idx]
            g = np.isfinite(d)
            sub[name] = float(d[g].mean()) if g.any() else None
        je_monat[mo] = sub
    zust = {"lauf": lauf, "tage": tage, "werte": werte, "warnung": warn, "je_monat": je_monat, "min": vorwaerts_min}
    with schreiben(con):
        meta_setzen(con, "vorwaerts", zust)
    if tage < vorwaerts_min or con.execute("SELECT 1 FROM vl_auswertung WHERE endgueltig=1 AND pruefung IN ('V1v','V2v') "
                                           "AND fassung=? LIMIT 1", (FASSUNG,)).fetchone():
        return {"phase": "beschreibend", "tage": tage, "warnung": warn}
    ta, tb, t2 = (pruefe_teil(F, t, BLOECKE[0], ziehungen) for t in ("V1a", "V1b", "V2"))
    p1 = None if ta.get("p") is None or tb.get("p") is None else max(ta["p"], tb["p"])
    ph = holm_gewichtet({"V1v": p1, "V2v": t2.get("p")}, {"V1v": 0.5, "V2v": 0.5})
    u1 = ("belegt" if ph["V1v"] is not None and ph["V1v"] < 0.05 and all(regel_teil(e, vorwaerts_min)[0] for e in (ta, tb))
          else "nicht belegt")
    u2 = urteil(t2, ph["V2v"], vorwaerts_min)
    with schreiben(con):
        for k, e, u in (("V1v", ta, u1), ("V2v", t2, u2)):
            con.execute("INSERT OR REPLACE INTO vl_auswertung VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (k, lauf, FASSUNG, e.get("n"), e.get("tage"), _f(e.get("mass")), _f(e.get("lo")), _f(e.get("hi")),
                         _f(p1 if k == "V1v" else e.get("p")), _f(ph[k]), _f(e.get("h1")), _f(e.get("h2")), u, 1,
                         json.dumps(_ohne_nan({"block": e.get("block"), "k1": e.get("k1"), "k2": e.get("k2")}))))
    return {"phase": "vorwaerts_urteil", "V1v": u1, "V2v": u2}


# ---------------------------------------------------------------------------
# 9. Berichte und Nutzlast (vor dem Urteil nur die jüngste Prognose und Zählungen; Nachtrag 13.4)
# ---------------------------------------------------------------------------

QUELLE_TEXT = {"rb": "Rückblick", "vorlauf": "Vorlauf (nur σ)", "live": "live", "spaet": "nachgeholt"}
VERGLEICH_TEXT = {"B0": "30-Tage-Mittel", "B365": "Jahresmittel", "EWMA": "EWMA", "grund": "Grundrate", "markov": "Zwei-Zustands-Modell"}


def urteil_zeilen(con, endgueltig_nur: bool = True, pruefungen=PRUEFUNGEN + ("V1a", "V1b")) -> list[dict]:
    ph = ",".join("?" * len(pruefungen))
    bed = " AND endgueltig=1" if endgueltig_nur else ""
    lauf = con.execute("SELECT MAX(lauf) FROM vl_auswertung WHERE fassung=? AND pruefung IN (" + ph + ")" + bed,
                       (FASSUNG, *pruefungen)).fetchone()[0]
    if lauf is None:
        return []
    aus = []
    for r in con.execute("SELECT pruefung, lauf, n, tage, mass, lo, hi, p, p_holm, h1, h2, urteil, endgueltig, details "
                         "FROM vl_auswertung WHERE lauf=? AND fassung=? AND pruefung IN (" + ph + ") ORDER BY pruefung",
                         (lauf, FASSUNG, *pruefungen)):
        d = dict(zip(("pruefung", "lauf", "n", "tage", "mass", "lo", "hi", "p", "p_holm", "h1", "h2", "urteil", "endgueltig",
                      "details"), r))
        try:
            d["details"] = json.loads(d["details"] or "{}")
        except ValueError:
            d["details"] = {}
        d["titel"] = TITEL.get(d["pruefung"], d["pruefung"])
        aus.append(d)
    return aus


def urteile(con) -> dict:
    """{Prüfung: Urteil} des gemeinsamen Urteils (leer vor dem Urteil)."""
    return {z["pruefung"]: z["urteil"] for z in urteil_zeilen(con, True, PRUEFUNGEN)}


def anzeige_modell(coin: str, u: dict) -> str:
    """Konzept 4.4: M+ für BTC und ETH nur, wenn V4 belegt ist; HYPE: gemeinsame Steigungen, eigenes Niveau."""
    if coin in GELIEHEN:
        return "geliehen"
    if coin in DVOL_COINS and u.get("V4") == "belegt":
        return "M+"
    return "M"


def letzte_prognose(con, coin: str, modell: str) -> tuple[int | None, list]:
    r = con.execute("SELECT MAX(ursprung) FROM vl_prognose WHERE coin=? AND modell=? AND fassung=? AND quelle!='vorlauf'",
                    (coin, modell, FASSUNG)).fetchone()[0]
    if r is None:
        return None, []
    zeilen = con.execute("SELECT woche, mu, sigma, v, v_b0, v_b365, v_ewma, schwelle, p, p_grund, p_markov, zustand, pfad, quelle, "
                         "berechnet, sigma_quelle FROM vl_prognose WHERE coin=? AND modell=? AND ursprung=? AND fassung=? "
                         "ORDER BY woche", (coin, modell, r, FASSUNG)).fetchall()
    return int(r), zeilen


def zonen(r: Reihe, von_tag: int, bis_tag: int) -> list[list[int]]:
    """Vergangene Phasen (Nachtrag 13.13): Tag t, wenn das 7-Tage-Mittel t−6 … t über S(t−6) lag (Schwelle des jeweiligen
    Vorjahrs); zusammenhängende Tage bilden eine Fläche."""
    iv = []
    e = np.arange(r.n)
    i0 = e - 6
    S = np.full(r.n, np.nan)
    ok = i0 >= 0
    S[ok] = r.schwelle[i0[ok]]
    if _MUT == "flaechen_heutige_schwelle":
        S = np.full(r.n, r.schwelle[r.n])
    with np.errstate(invalid="ignore"):
        an = np.isfinite(r.m7) & np.isfinite(S) & (r.m7 > S)
    for j in np.nonzero(an)[0]:
        t = r.d0 + int(j)
        if t < von_tag or t > bis_tag:
            continue
        if iv and t == iv[-1][1] + 1:
            iv[-1][1] = t
        else:
            iv.append([t, t])
    return iv


def _runde(x, nd: int = 2):
    return None if not _endlich(x) else round(float(x), nd)


def _signifikant(x, s: int = 6):
    return None if not _endlich(x) else float("%.*g" % (s, float(x)))


def _p_anzeige(p):
    """Wahrscheinlichkeiten ganzzahlig, angezeigt zwischen 1 % und 99 % (Nachtrag 13.4)."""
    return None if not _endlich(p) else min(0.99, max(0.01, round(float(p), 2)))


def status(con) -> dict:
    """Zustand für Kopf und Text: vor dem Urteil, ohne bestandene Prüfungen, nach dem Urteil."""
    u = urteil_zeilen(con, True, PRUEFUNGEN)
    if u:
        return {"art": "urteil", "vom": u[0]["lauf"], "urteile": {z["pruefung"]: z["urteil"] for z in u}}
    nicht = urteil_zeilen(con, False, PRUEFUNGEN)
    if nicht:
        vor = (meta(con, "pruefungen_vor_urteil", {}) or {}).get("liste") or []
        return {"art": "kein_urteil", "vom": nicht[0]["lauf"], "gruende": [n for n, ok, _ in vor if not ok]}
    rb = meta(con, "rb", {}) or {}
    if not stichtag(con):
        return {"art": "erstlauf"}
    if not rb.get("fertig"):
        return {"art": "rueckblick", "schritte": rb.get("schritte", 0), "plan": rb.get("plan")}
    return {"art": "zaehlung", "grund": (meta(con, "zaehlung", {}) or {}).get("grund")}


def status_text(con) -> str:
    s = status(con)
    if s["art"] == "urteil":
        return "Urteil vom " + _uhr(s["vom"]) + ": " + ", ".join(k + " " + v for k, v in s["urteile"].items())
    if s["art"] == "kein_urteil":
        return "kein Urteil (Prüfung vor dem Urteil nicht bestanden: " + "; ".join(s["gruende"])[:200] + ")"
    if s["art"] == "erstlauf":
        return "Erstlauf steht aus"
    if s["art"] == "rueckblick":
        return f"Rückblick {s['schritte']} von {s.get('plan') or '?'} Schritten – ungeprüft, das Urteil steht aus"
    return "ungeprüft – das Urteil steht aus" + (" (" + str(s["grund"]) + ")" if s.get("grund") else "")


def kopf_text(con) -> list[str]:
    """Hinweise oben im Abschnitt (Nachtrag 13.4)."""
    s = status(con)
    z = ["Schwankung, nicht Richtung."]
    if s["art"] == "urteil":
        u = s["urteile"]
        z.append("Urteil vom " + _uhr(s["vom"]) + ": Niveau (V1) " + u.get("V1", "–") + ", Phasen gegen die Grundrate (V2) "
                 + u.get("V2", "–") + ", gegen das Zwei-Zustands-Modell (V3) " + u.get("V3", "–") + ", DVOL (V4) " + u.get("V4", "–") + ".")
        if u.get("V1") != "belegt":
            z.append("Niveau im Rückblick nicht besser als 30-Tage- und Jahresmittel – beide stehen in der Tabelle daneben.")
        if u.get("V2") != "belegt":
            z.append("Wahrscheinlichkeit einer volatilen Woche im Rückblick nicht besser als die Grundrate.")
    elif s["art"] == "kein_urteil":
        z.append(status_text(con) + ".")
    else:
        z.append("Prognose ungeprüft – das Urteil steht aus.")
    z.append(NICHT_FRISCH)
    vw = meta(con, "vorwaerts", {}) or {}
    for n in vw.get("warnung") or []:
        z.append("Vorwärts schlechter als " + {"B0": "das 30-Tage-Mittel", "B365": "das Jahresmittel",
                                               "Grundrate": "die Grundrate"}.get(n, n) + " (90-%-Intervall ganz unter 0).")
    return z


def _dvol_anzeige(con, coin: str, von: int, bis: int) -> dict[int, float]:
    """DVOL je Tag e für die Anzeige: Stunde 23 UTC aus aktien.db; fehlt sie, der Tageswert aus makro.db mit Datum e − 1
    (Nachtrag 13.6: Lage der Tageskerze ungeprüft, deshalb einen Tag älter)."""
    aus = {}
    f = (meta(con, "dvol_faktor", {}) or {}).get(coin) or 1.0
    for t, w, qq in con.execute("SELECT tag, wert, quelle FROM vl_dvol WHERE coin=? AND tag BETWEEN ? AND ?", (coin, von - 1, bis)):
        if w is None:
            continue
        if qq == "aktien":
            aus[int(t)] = float(w) * f
    for t, w, qq in con.execute("SELECT tag, wert, quelle FROM vl_dvol WHERE coin=? AND quelle='makro' AND tag BETWEEN ? AND ?",
                                (coin, von - 1, bis)):
        if w is not None and int(t) + 1 not in aus:
            aus[int(t) + 1] = float(w)
    return aus


def nutzlast(con, tab: str = "chart", coin: str = "BTC", jetzt: int | None = None) -> dict:
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    tl = meta(con, "tageslauf", {}) or {}
    el = meta(con, "erstlauf", {}) or {}
    stand = tl.get("ts") or el.get("ts")
    st = status(con)
    u = st.get("urteile", {}) if st["art"] == "urteil" else {}
    basis = {"ok": True, "tab": tab, "jetzt": jetzt, "heute": heute, "stand": stand, "hinweis": " ".join(kopf_text(con)),
             "kopf": kopf_text(con), "status": st["art"], "auswertung": status_text(con), "coins": list(COINS)}
    if tab == "chart":
        if coin not in COINS:
            coin = "BTC"
        reihen = reihen_laden(con, bis_tag=heute, coins=(coin,))
        r = reihen.get(coin)
        if r is None:
            return {**basis, "ok": False, "coin": coin, "fehlt": ["Noch keine Tageswerte für " + coin + " (Erstlauf ausstehend; der "
                                                                  "Dienst startet 90 s nach dem Dashboard, aus mit HL_VOL=0)."]}
        von = max(r.d0, heute - 1830)
        bis = r.d0 + r.n - 1
        werte = {int(t): (vi7, vi30, s) for t, vi7, vi30, s in con.execute(
            "SELECT tag, vi7, vi30, schluss FROM vl_tag WHERE coin=? AND tag BETWEEN ? AND ?", (coin, von, bis))}
        tage = range(von, bis + 1)
        leer = (None, None, None)
        reihe = {"t0": von, "vi30": [_runde(werte.get(t, leer)[1]) for t in tage], "vi7": [_runde(werte.get(t, leer)[0]) for t in tage],
                 "kurs": [_signifikant(werte.get(t, leer)[2]) for t in tage]}
        if coin in DVOL_COINS:
            dv = _dvol_anzeige(con, coin, von, bis)
            if dv:
                reihe["dvol"] = [_runde(dv.get(t)) for t in tage]
        modell = anzeige_modell(coin, u)
        D, zeilen = letzte_prognose(con, coin, modell)
        if not zeilen and modell == "M+":
            modell = "M"
            D, zeilen = letzte_prognose(con, coin, modell)
        regel = ((meta(con, "beschreibend", {}) or {}).get("werte") or {}).get("regel") or {} if u else {}
        termine_alle = [(int(t), a) for t, a, b, best in con.execute(
            "SELECT tag, art, bekannt, bestaetigt FROM vl_termin WHERE tag BETWEEN ? AND ? ORDER BY tag", (heute - 60, heute + 60))
            if a not in TERMIN_ARTEN or best or int(t) >= heute]
        prognose = None
        if zeilen and D is not None and D >= heute - 3:
            wochen, pfad_ = [], []
            for (k, mu, sg, v, vb0, vb365, vew, S, p, pg, pmk, zst, pf, quelle, ber, sq) in zeilen:
                a = D + 7 * (k - 1)
                besser = [VERGLEICH_TEXT[n] for n, ja in (regel.get(str(k)) or {}).items() if ja]
                wochen.append({"k": k, "a": a, "b": a + 6, "mitte": _runde(ann(v)),
                               "lo50": _runde(ann(math.exp(mu - Z50 * sg))), "hi50": _runde(ann(math.exp(mu + Z50 * sg))),
                               "lo90": _runde(ann(math.exp(mu - Z90 * sg))), "hi90": _runde(ann(math.exp(mu + Z90 * sg))),
                               "p": _p_anzeige(p), "grund": _p_anzeige(pg), "markov": _p_anzeige(pmk),
                               "b0": _runde(ann(vb0)), "b365": _runde(ann(vb365)), "ewma": _runde(ann(vew)),
                               "besser": besser, "sigma": sq,
                               "termine": [{"tag": t, "art": aa} for t, aa in termine_alle if a <= t <= a + 6]})
                pfad_ += [_runde(ann(x)) for x in (json.loads(pf) if pf else [v] * 7)]
            S0 = zeilen[0][7]
            prognose = {"ursprung": D, "modell": modell, "modell_text": MODELL_TEXT.get(modell, modell), "ungeprueft": not u,
                        "urteil": u, "pfad": pfad_, "wochen": wochen, "schwelle": _runde(ann(S0)) if S0 is not None else None,
                        "quelle": zeilen[0][13], "berechnet": zeilen[0][14], "nicht_im_urteil": coin in GELIEHEN}
        ende = (D + 27) if prognose else heute
        aus = {**basis, "coin": coin, "reihe": reihe, "dvol": "dvol" in reihe, "zonen": zonen(r, von, bis),
               "prognose": prognose, "termine": [{"tag": t, "art": a} for t, a in termine_alle if heute - 56 <= t <= ende],
               "quelle": "Binance-Perpetual 30 min, Tagesschluss UTC (swing.db); DVOL Deribit (aktien.db, nur persönliche Nutzung); "
                         "Termine FRED (bestätigt), federalreserve.gov, Regel"}
        if _MUT == "fruehere_prognosen":
            aus["historie"] = [list(z) for z in con.execute("SELECT ursprung, woche, v FROM vl_prognose WHERE coin=? AND modell='M' "
                                                            "AND quelle='rb' LIMIT 50", (coin,))]
        return aus
    if tab == "bilanz":
        zeilen = urteil_zeilen(con, endgueltig_nur=_MUT != "tor_offen")
        z = meta(con, "zaehlung", {}) or {}
        pv = meta(con, "pruefungen_vor_urteil", {}) or {}
        vor = pv.get("liste")
        if vor and not zeilen:                         # vor dem Urteil keine Deckungswerte (13.4)
            vor = [[n, ok, ("" if n.startswith("Fehlerprobe") else w)] for n, ok, w in vor]
        aus = {**basis, "urteil": None, "vor_urteil": vor}
        if zeilen:
            aus["urteil"] = {"vom": zeilen[0]["lauf"], "holm": "gewichteter Holm über V1–V4 (je 0,25; nicht prüfbare fallen heraus); "
                                                               "V1 = Schnitt aus V1a und V1b (p = größeres)",
                             "zeilen": [{k: zz.get(k) for k in ("pruefung", "titel", "urteil", "mass", "lo", "hi", "p", "p_holm",
                                                                "h1", "h2", "tage")} | {"n": zz.get("tage"),
                                                                                        "block": zz["details"].get("block")}
                                        for zz in zeilen]}
            aus["beschreibend"] = (meta(con, "beschreibend", {}) or {}).get("werte")
        elif z.get("zaehlung") or _MUT == "zaehlung_nullen":     # ohne gespeicherte Zählung keine Nullen (Browser-Probe 28.10.)
            zl = []
            for k in TEILE:
                e = (z.get("zaehlung") or {}).get(k) or {}
                zl.append({"name": TITEL[k], "n": e.get("tage", 0), "min": e.get("min", MIN_TAGE), "dazu": f"{_de(e.get('faelle', 0), 0)} Wochenwerte"})
            aus["zaehlung"] = {"freigabe": bool(z.get("freigabe")), "grund": z.get("grund") or status_text(con), "zeilen": zl}
        else:
            aus["zaehlung"] = None
        vw = urteil_zeilen(con, True, ("V1v", "V2v"))
        aus["vorwaerts"] = ({"zeilen": [{k: zz.get(k) for k in ("pruefung", "titel", "urteil", "mass", "p", "p_holm", "tage")}
                                        for zz in vw]} if vw else (meta(con, "vorwaerts", None) if zeilen else None))
        return aus
    if tab == "daten":
        q = []
        for c in COINS:
            v0, bis, n_g, n_t = con.execute("SELECT MIN(tag), MAX(tag), SUM(rv IS NOT NULL), COUNT(*) FROM vl_tag WHERE coin=?",
                                            (c,)).fetchone()
            dv = con.execute("SELECT MIN(tag), MAX(tag), COUNT(*) FROM vl_dvol WHERE coin=? AND quelle='aktien'", (c,)).fetchone()
            pr = dict(con.execute("SELECT quelle, COUNT(DISTINCT ursprung) FROM vl_prognose WHERE coin=? AND fassung=? GROUP BY quelle",
                                  (c, FASSUNG)))
            q.append({"coin": c, "von": v0, "bis": bis, "anteil": (n_g / n_t) if n_t else None,
                      "dvol": (_datum(dv[0]) + " – " + _datum(dv[1]) + f" ({dv[2]} Tage)") if dv and dv[2] else None,
                      "prognosen": " · ".join(QUELLE_TEXT.get(k, k) + " " + str(n) for k, n in sorted(pr.items())) or None})
        rb = meta(con, "rb", {}) or {}
        hinweise = []
        for k in ("fehler_dienst", "fehler_erstlauf", "fehler_auswertung", "fehler_tageslauf"):
            f = meta(con, k)
            if f:
                hinweise.append(k.replace("fehler_", "Fehler ") + " " + _uhr(f.get("ts")) + ": " + str(f.get("fehler")))
        dop = meta(con, "doppelt")
        if dop:
            hinweise.append(f"Schon vorhandene Prognosen oder Koeffizienten nicht überschrieben: {dop}")
        if not el.get("ok", True):
            hinweise.append("Erstlauf nicht vollständig: " + " / ".join((el.get("bericht") or [])[-3:]))
        tf = (tl.get("fehlt") or {})
        if tf:
            hinweise.append("Tageslauf ohne Prognose: " + "; ".join(f"{k_}: {v_}" for k_, v_ in tf.items()))
        hinweise.append("Fed-Termine aus einer festen Liste (federalreserve.gov, bis 2027), Optionsverfall nach Regel – beide nur als "
                        "Marke. Im Tagespfad wirken nur bestätigte Inflations- und Arbeitsmarkttermine.")
        hinweise.append("DVOL nur zur persönlichen Nutzung (Deribit). Im Modell nur die Stunde 23 UTC aus aktien.db.")
        hinweise.append("Der Ausblick zeigt eine Breite für 28 Tage aus 24-h-Blöcken; hier wird je Woche ab heute gerechnet – die "
                        "Zahlen können abweichen.")
        return {**basis, "quellen": q, "stichtag": stichtag(con),
                "rueckblick": ("fertig " + _uhr(rb.get("ende")) if rb.get("fertig") else
                               f"{rb.get('schritte', 0)} von {rb.get('plan', '?')} Schritten" + (" (zuletzt " + rb["zuletzt"] + ")"
                                                                                                  if rb.get("zuletzt") else "")),
                "dienst": (meta(con, "dienst", {}) or {}).get("ts"), "hinweise": hinweise}
    return {**basis, "ok": False, "fehlt": ["unbekannter Reiter " + str(tab)[:20]]}


def payload_json(p: str, tab: str = "chart", coin: str = "BTC", jetzt: int | None = None) -> bytes:
    """/volatil?tab=…&coin=…: Nutzlast als JSON; bei jedem Fehler eine Antwort mit Grund (nie eine leere Seite)."""
    try:
        con = lesen(p)
        if con is None:
            return json.dumps({"ok": False, "tab": tab, "fehlt": ["volatil.db fehlt noch – der Dienst legt sie rund 90 s nach dem "
                                                                  "Start des Dashboards an (aus mit HL_VOL=0)."]},
                              ensure_ascii=False).encode()
        try:
            d = nutzlast(con, tab, coin, jetzt)
        finally:
            con.close()
        return json.dumps(_ohne_nan(d), ensure_ascii=False, allow_nan=False).encode()
    except Exception as e:  # noqa: BLE001 — die Seite bekommt immer eine Antwort
        return json.dumps({"ok": False, "tab": tab, "fehlt": [("Volatilität: " + type(e).__name__ + ": " + str(e))[:300]]},
                          ensure_ascii=False).encode()


def _prognose_text(con, coin: str, u: dict) -> list[str]:
    modell = anzeige_modell(coin, u)
    D, zeilen = letzte_prognose(con, coin, modell)
    if not zeilen and modell == "M+":
        modell = "M"
        D, zeilen = letzte_prognose(con, coin, modell)
    if not zeilen:
        return [f"  {coin}: noch keine Prognose"]
    z = [f"  {coin} ({MODELL_TEXT.get(modell, modell)}, Ursprung {_datum(D)}, {QUELLE_TEXT.get(zeilen[0][13], zeilen[0][13])}, "
         f"Schwelle {_de(ann(zeilen[0][7]), 1)} % p. a.):"]
    for (k, mu, sg, v, vb0, vb365, vew, S, p, pg, pmk, zst, pf, quelle, ber, sq) in zeilen:
        z.append(f"    W{k}: Mitte {_de(ann(v), 1)} % p. a. (50 % {_de(ann(math.exp(mu - Z50 * sg)), 1)}–"
                 f"{_de(ann(math.exp(mu + Z50 * sg)), 1)}; σ {'außerhalb' if sq == 'oos' else 'im Fenster'}), 30-Tage "
                 f"{_de(ann(vb0), 1)}, Jahr {_de(ann(vb365), 1)}, EWMA {_de(ann(vew), 1)}; volatile Woche {_pz(p, 0)} "
                 f"(Grundrate {_pz(pg, 0)}, Zwei-Zustands {_pz(pmk, 0)})")
    return z


def bericht_stand(con, jetzt: int | None = None) -> str:
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    z = ["★ Volatilität: Stand (U237) – " + _uhr(jetzt), "  Modul " + VERSION_MODUL + " · Fassung " + FASSUNG + " · "
         + status_text(con)]
    el = meta(con, "erstlauf")
    z.append("Erstlauf: " + ("noch nicht" if not el else _uhr(el.get("ts")) + (" (vollständig)" if el.get("ok") else " (UNVOLLSTÄNDIG)")))
    if el:
        z += ["  " + x for x in (el.get("bericht") or [])[1:]]
    st = stichtag(con)
    z.append("Stichtag: " + (_uhr(st) if st else "–"))
    z.append("Tageswerte (vl_tag):")
    for c in COINS:
        r = con.execute("SELECT MIN(tag), MAX(tag), COUNT(*), SUM(rv IS NULL) FROM vl_tag WHERE coin=?", (c,)).fetchone()
        last = con.execute("SELECT vi7, vi30, schluss FROM vl_tag WHERE coin=? ORDER BY tag DESC LIMIT 1", (c,)).fetchone()
        if not r[2]:
            z.append(f"  {c}: keine")
            continue
        z.append(f"  {c}: {_datum(r[0])} – {_datum(r[1])} ({r[2]} Tage, {r[3]} ungültig); zuletzt 30 Tage {_de(last[1], 1)} % p. a., "
                 f"7 Tage {_de(last[0], 1)} % p. a., Schluss {_de(last[2], 2)}" + ("" if r[1] >= heute - 2 else "  ⚠ nicht aktuell"))
    for c in DVOL_COINS:
        r = con.execute("SELECT MIN(tag), MAX(tag), COUNT(*) FROM vl_dvol WHERE coin=? AND quelle='aktien'", (c,)).fetchone()
        w = con.execute("SELECT wert FROM vl_dvol WHERE coin=? AND quelle='aktien' ORDER BY tag DESC LIMIT 1", (c,)).fetchone()
        z.append(f"  DVOL {c} (aktien.db): {_datum(r[0])} – {_datum(r[1])} ({r[2]} Tage), zuletzt {_de(w[0] if w else None, 1)}")
    for a in TERMIN_TEXT:
        n, nx = con.execute("SELECT COUNT(*), MIN(CASE WHEN tag>=? THEN tag END) FROM vl_termin WHERE art=?", (heute, a)).fetchone()
        nb = con.execute("SELECT COUNT(*) FROM vl_termin WHERE art=? AND bestaetigt=1", (a,)).fetchone()[0]
        z.append(f"  Termine {TERMIN_TEXT[a]}: {n}" + (f" (bestätigt {nb})" if a in TERMIN_ARTEN else "") + f", nächster {_datum(nx)}")
    rb = meta(con, "rb", {}) or {}
    z.append("Rückblick: " + ("fertig " + _uhr(rb.get("ende")) if rb.get("fertig") else
                              f"{rb.get('schritte', 0)} von {rb.get('plan', '?')} Schritten" + (", zuletzt " + rb["zuletzt"]
                                                                                                if rb.get("zuletzt") else "")))
    for qq, n, mx in con.execute("SELECT quelle, COUNT(DISTINCT coin || ':' || ursprung), MAX(ursprung) FROM vl_prognose "
                                 "WHERE fassung=? GROUP BY quelle ORDER BY quelle", (FASSUNG,)):
        z.append(f"  Prognosen {QUELLE_TEXT.get(qq, qq)}: {n} Ursprünge (Coin × Tag), letzter {_datum(mx)}")
    so = dict(con.execute("SELECT sigma_quelle, COUNT(*) FROM vl_prognose WHERE fassung=? AND quelle!='vorlauf' GROUP BY sigma_quelle",
                          (FASSUNG,)))
    if so:
        z.append(f"  σ außerhalb der Stichprobe: {so.get('oos', 0)} Zeilen, im Fenster (früh, gekennzeichnet): {so.get('fenster', 0)}")
    tl = meta(con, "tageslauf")
    if tl:
        z.append("Tageslauf: " + _uhr(tl.get("ts")) + f", neu {tl.get('neu')} Zeilen"
                 + ("; fehlt: " + "; ".join(f"{k}: {v}" for k, v in (tl.get("fehlt") or {}).items()) if tl.get("fehlt") else ""))
    for k in ("doppelt", "fehler_dienst", "fehler_erstlauf", "fehler_tageslauf", "fehler_auswertung"):
        v = meta(con, k)
        if v:
            z.append(f"{k}: {json.dumps(v, ensure_ascii=False)[:300]}")
    d = meta(con, "dienst")
    z.append("Dienst: " + ("letzter Schritt " + _uhr(d.get("ts")) + (" · " + str(d.get("schritt")) if d.get("schritt") else "")
                           if d else "noch kein Lauf (startet 90 s nach dem Dashboard; aus mit HL_VOL=0)"))
    z += ["Hinweis: " + x for x in kopf_text(con)]
    u = urteile(con)
    z.append("Aktuelle Prognose (Schwankung, nicht Richtung" + ("" if u else "; ungeprüft, das Urteil steht aus") + "):")
    for c in COINS:
        z += _prognose_text(con, c, u)
    return "\n".join(z)


def bericht_auswertung(con) -> str:
    z = ["★ Volatilität: Auswertung (U237, vorab festgelegt in KONZEPT_Volatilitaet.md 6 und Nachtrag 13) – " + _uhr(time.time()),
         "  Fassung " + FASSUNG + " · " + NICHT_FRISCH]
    zeilen = urteil_zeilen(con)
    zz = meta(con, "zaehlung", {}) or {}
    vor = (meta(con, "pruefungen_vor_urteil", {}) or {}).get("liste")
    if not zeilen:
        z.append("Phase: Zählung (Regel 4: bis zum gemeinsamen Urteil nur Anzahlen). " + status_text(con))
        for k in TEILE:
            e = (zz.get("zaehlung") or {}).get(k) or {}
            z.append(f"  {TITEL[k]}: {e.get('tage', 0)} Ursprungstage (mindestens {e.get('min', MIN_TAGE)}), "
                     f"{e.get('faelle', 0)} Wochenwerte")
        z.append("  Freigabe: " + ("ja" if zz.get("freigabe") else "nein – " + str(zz.get("grund") or "")))
        if vor:
            z.append("Prüfungen vor dem Urteil (ohne Deckungswerte, Nachtrag 13.4):")
            z += [f"  {'✓' if ok else '✗'} {n}" + ("" if n.startswith("Fehlerprobe") else f": {w}") for n, ok, w in vor]
        return "\n".join(z)
    z.append("Gemeinsames Urteil vom " + _uhr(zeilen[0]["lauf"]) + " (gewichteter Holm über V1–V4; V1 = Schnitt aus V1a und V1b; "
             "studentisierter Block-Bootstrap über Ursprungstage, Blocklänge je Prüfung nach der Vorzeichen-Nullprobe, 9.999 "
             "Ziehungen):")
    for e in zeilen:
        d = e["details"]
        z.append(f"  {e['titel']}: {str(e['urteil']).upper()}")
        if e["pruefung"] == "V1":
            z.append(f"    p {_de(e['p'], 4)} (größeres von V1a und V1b), p (Holm) {_de(e['p_holm'], 4)}; Maß und Hälften je Teil:")
            continue
        z.append(f"    Maß {_de(e['mass'], 5)} (90 % {_de(e['lo'], 5)} … {_de(e['hi'], 5)}), p {_de(e['p'], 4)}"
                 + (f", p (Holm) {_de(e['p_holm'], 4)}" if e["pruefung"] not in ("V1a", "V1b") else "")
                 + f", Hälften {_de(e['h1'], 5)} / {_de(e['h2'], 5)}, {e['tage']} Ursprungstage, {e['n']} Werte; "
                 f"Block {d.get('block')} Tage ({d.get('bloecke')} Blöcke), Stichprobe {_datum(d.get('von'))} – {_datum(d.get('bis'))}")
    if vor:
        z.append("Prüfungen vor dem Urteil:")
        z += [f"  {'✓' if ok else '✗'} {n}: {w}" for n, ok, w in vor]
    b = (meta(con, "beschreibend", {}) or {}).get("werte")
    if b:
        z.append("Beschreibend (ohne p-Werte):")
        for w in b.get("je_woche", []):
            teile = []
            for n in ("B0", "B365", "EWMA", "grund", "markov"):
                iv = w.get(n) or {}
                teile.append(f"{VERGLEICH_TEXT[n]} {_de(iv.get('mass'), 4)} [{_de(iv.get('lo'), 4)}; {_de(iv.get('hi'), 4)}]")
            besser = [VERGLEICH_TEXT[n] for n, ja in ((b.get("regel") or {}).get(str(w["woche"])) or {}).items() if ja]
            z.append(f"  W{w['woche']}: " + " · ".join(teile) + (" → im Rückblick besser: " + ", ".join(besser) if besser else ""))
        for w in b.get("deckung", []):
            z.append(f"  Deckung {w['coin']} W{w['woche']}: im 50-%-Band {_pz(w['in50'])}, im 90-%-Band {_pz(w['in90'])}, darüber "
                     f"{_pz(w['ueber90'])} (n {w['n']})")
        for t, w in (b.get("robust") or {}).items():
            z.append(f"  Robust {t}: Mittel {_de(w['mittel'], 5)}, ohne 1 % {_de(w['ohne_1_prozent'], 5)}, Median je Tag "
                     f"{_de(w['median_tag'], 5)}, Anteil der 10 größten Tage {_pz(w['anteil_top10'])}"
                     + (" – GETRAGEN VON WENIGEN WOCHEN" if w.get("getragen_von_wenigen") else "")
                     + "; je Jahr " + ", ".join(f"{j} {_de(v, 4)}" for j, v in w["je_jahr"].items()))
        for w in b.get("mincer_zarnowitz", []):
            z.append(f"  Mincer-Zarnowitz (gewichtet) W{w['woche']}: a {_de(w['a'], 6)}, b {_de(w['b'], 3)} (n {w['n']})")
        for w in b.get("zuverlaessigkeit", []):
            z.append(f"  Zuverlässigkeit W{w['woche']}: " + "; ".join(f"{_pz(k['p'], 0)}→{_pz(k['anteil'], 0)} ({k['n']})"
                                                                     for k in w["klassen"]))
        tp = b.get("tagespfad") or {}
        z.append(f"  Tagespfad Woche 1: QLIKE mit Kalender {_de(tp.get('qlike_mit'), 4)}, ohne {_de(tp.get('qlike_ohne'), 4)} "
                 f"(n {tp.get('n')})")
        for k, w in (b.get("dvol_allein") or {}).items():
            z.append(f"  DVOL allein {k}: a {_de(w['a'], 3)}, b {_de(w['b'], 3)}, R² {_de(w['r2'], 3)} (n {w['n']})")
        rs = b.get("v1a_rogers_satchell") or {}
        z.append(f"  V1a mit Rogers-Satchell: {_de(rs.get('mittel'), 5)} (n {rs.get('n')})")
        hy = b.get("hype") or {}
        z.append(f"  HYPE (gemeinsame Steigungen, eigenes Niveau; nicht im Urteil): V1a-Maß {_de(hy.get('v1a'), 5)} (n {hy.get('n')})")
    vw = urteil_zeilen(con, True, ("V1v", "V2v"))
    v = meta(con, "vorwaerts")
    if vw:
        z.append("Vorwärts, Bestätigungstest:")
        z += [f"  {e['titel']}: {e['urteil']} (Maß {_de(e['mass'], 5)}, p (Holm) {_de(e['p_holm'], 4)}, {e['tage']} Tage)" for e in vw]
    if v:
        z.append(f"Vorwärts (beschreibend): {v.get('tage')} Ursprungstage mit fertigen Zielen; Test erst ab {v.get('min')}; "
                 + "; ".join(f"{n} {_de((w or {}).get('mass'), 5)} [{_de((w or {}).get('lo'), 5)}; {_de((w or {}).get('hi'), 5)}]"
                             for n, w in (v.get("werte") or {}).items())
                 + ("; WARNUNG: " + ", ".join(v["warnung"]) if v.get("warnung") else ""))
    return "\n".join(z)


# ---------------------------------------------------------------------------
# 10. Selbsttest und Mutationen (Konzept 9, Nachtrag 13.3, 13.17)
# ---------------------------------------------------------------------------

MUTATIONEN = ("ziel_im_regressor", "schwelle_zukunft", "wochenfenster_verschoben", "annualisierung_252", "qlike_vorzeichen",
              "bootstrap_ohne_bloecke", "bootstrap_perzentil", "holm_weg", "haelften_ignoriert", "mindestzahl_ignoriert",
              "dvol_stunde_vor_ende", "pfad_aendert_mittel", "termin_zukunft", "grundrate_zukunft", "markov_zielwoche",
              "luecke_gueltig", "luecken_nicht_hochskaliert", "urteile_einzeln", "kein_stichtag", "tor_offen",
              "neuschaetzung_zukunft",
              # Nachtrag 13.17
              "v1_ohne_b365", "schnitt_min", "block_28", "sigma_fenster", "flaechen_heutige_schwelle", "fruehere_prognosen",
              "makro_in_mplus", "v4_verschiedene_stichproben", "hype_mittel_achsenabschnitt", "unbestaetigt_als_termin",
              "haelften_faelle", "urteil_neu",
              # Browser-Probe beim Bau (28.10.): ohne gespeicherte Zählung zeigte die Bilanz Nullen
              "zaehlung_nullen")


def v1_p(pa, pb):
    """p von V1 als Schnitt-Test: das größere der beiden (Nachtrag 13.2)."""
    if pa is None or (pb is None and _MUT != "v1_ohne_b365"):
        return None
    if _MUT == "v1_ohne_b365":
        return pa
    return min(pa, pb) if _MUT == "schnitt_min" else max(pa, pb)


def v1_urteil(ea: dict, eb: dict, p_holm, min_tage: int = MIN_TAGE, min_haelfte: int = MIN_HAELFTE) -> str:
    """V1 belegt nur, wenn V1a und V1b jede für sich die Regel erfüllen und das angepasste p von V1 unter 0,05 liegt."""
    teile = (ea,) if _MUT == "v1_ohne_b365" else (ea, eb)
    regeln = [regel_teil(e, min_tage, min_haelfte) for e in teile]
    if any(g for _, g in regeln):
        return "nicht prüfbar"
    if p_holm is None:
        return "nicht prüfbar"
    return "belegt" if (p_holm < 0.05 and all(o for o, _ in regeln)) else "nicht belegt"


def _synth_varianz(rng, d0: int, tage: int, phi_: float = 0.97, sd: float = 0.22, mittel: float = -7.6, termine=frozenset(),
                   we: float = 0.7, tf: float = 1.6) -> np.ndarray:
    """Tagesvarianz mit Ballung (log-AR(1)), ruhigerem Wochenende und lauteren Termintagen."""
    h = rng.normal() * sd / math.sqrt(1 - phi_ ** 2)
    s2 = np.empty(tage)
    for t in range(tage):
        h = phi_ * h + sd * rng.normal()
        f = (we if wochentag(d0 + t) >= 5 else 1.0) * (tf if (d0 + t) in termine else 1.0)
        s2[t] = math.exp(mittel + h) * f
    return s2


def _synth_kerzen(rng, d0: int, s2: np.ndarray, preis: float = 100.0, luecken=()):
    """48 Kerzen je Tag mit Rendite N(0, s2/48); luecken: [(Tagesindex, Anzahl fehlender Kerzen ab 10:00)]."""
    n = len(s2) * BARS_TAG
    sd = np.repeat(np.sqrt(s2 / BARS_TAG), BARS_TAG)
    r = rng.normal(size=n) * sd
    c = preis * np.exp(np.cumsum(r))
    o = np.concatenate([[preis], c[:-1]])
    sp = np.abs(rng.normal(size=n)) * sd * 0.5
    h = np.maximum(o, c) * np.exp(sp)
    lo = np.minimum(o, c) * np.exp(-sp)
    ts = d0 * TAG + np.arange(n, dtype=np.int64) * BAR
    behalten = np.ones(n, dtype=bool)
    for t, anz in luecken:
        a = t * BARS_TAG + (20 if anz < BARS_TAG else 0)
        behalten[a:a + anz] = False
    return ts[behalten], o[behalten], h[behalten], lo[behalten], c[behalten]


def _synth_kalender(d0: int, tage: int) -> dict[int, str]:
    """Inflation am 13. (oder dem nächsten Werktag), Arbeitsmarkt am ersten Freitag."""
    aus: dict[int, str] = {}
    d = tag_datum(monatserster(d0))
    while datum_tag(d) <= d0 + tage:
        c = date(d.year, d.month, 13)
        while c.weekday() >= 5:
            c += timedelta(days=1)
        f = date(d.year, d.month, 1)
        while f.weekday() != 4:
            f += timedelta(days=1)
        for t, a in ((datum_tag(c), "cpi"), (datum_tag(f), "jobs")):
            if d0 <= t <= d0 + tage:
                aus[t] = a
        d = date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    return aus


def _termine_reihe(kal: dict, unbestaetigt=frozenset(), heute: int | None = None) -> dict:
    """Kalender -> Format der Reihe: bestätigt (außer `unbestaetigt`), bekannt ab Tag − 60."""
    aus = {}
    for t, a in kal.items():
        best = t not in unbestaetigt
        aus[t] = [(a, (t - 60) if best else None, best)]
    return aus


def _gleich_rel(a, b, tol: float = 1e-12) -> bool:
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (list, tuple)):
        return isinstance(b, (list, tuple)) and len(a) == len(b) and all(_gleich_rel(x, y, tol) for x, y in zip(a, b))
    if isinstance(a, str) or isinstance(b, str):
        return a == b
    a, b = float(a), float(b)
    if not (math.isfinite(a) and math.isfinite(b)):
        return (math.isnan(a) and math.isnan(b)) or a == b
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def _st_tageswerte(pruef, rng) -> None:
    import hl_swing
    d0 = datum_tag(date(2024, 1, 1))
    s2 = _synth_varianz(rng, d0, 40)
    ts, o, h, lo, c = _synth_kerzen(rng, d0, s2, luecken=((3, 5), (7, 8), (10, 48)))
    T = hl_swing.tagesreihen({"ts": ts, "o": o, "h": h, "l": lo, "c": c, "v": np.ones(len(ts))})
    W = tageswerte(ts, o, h, lo, c)
    gleich = (W["d0"] == T["d0"] and len(W["rv"]) == len(T["RV"]) and np.array_equal(np.isfinite(W["rv"]), np.isfinite(T["RV"]))
              and np.allclose(W["rv"][np.isfinite(W["rv"])], T["RV"][np.isfinite(T["RV"])], rtol=1e-12, atol=0))
    pruef("Tages-RV gleich hl_swing.tagesreihen (mit Lücken: 5 Kerzen fehlen = gültig, 8 = ungültig, ganzer Tag)", gleich,
          f"gültig {np.isfinite(W['rv']).sum()} / {np.isfinite(T['RV']).sum()}")
    pruef("Lücken: Tag mit 42 gültigen Renditen hochgerechnet, Tag mit 39 ungültig",
          np.isfinite(W["rv"][3]) and not np.isfinite(W["rv"][7]) and int(W["anz"][3]) == 42 and int(W["anz"][7]) == 39,
          f"anz {W['anz'][3]}, {W['anz'][7]}")
    j = np.nonzero(ts // TAG == d0)[0]
    hh = np.maximum(h[j], np.maximum(o[j], c[j]))
    ll = np.minimum(lo[j], np.minimum(o[j], c[j]))
    rs = float(np.sum(np.log(hh / c[j]) * np.log(hh / o[j]) + np.log(ll / c[j]) * np.log(ll / o[j])))
    k3 = np.nonzero(ts // TAG == d0 + 3)[0]
    pruef("Rogers-Satchell und Tagesschluss von Hand", _gleich_rel(W["rs"][0], rs, 1e-10) and W["schluss"][3] == c[k3[-1]],
          f"{W['rs'][0]} / {rs}")


def _st_index(pruef) -> None:
    rv = np.full(60, 4e-4)
    soll = 100 * math.sqrt(365 * 4e-4)
    v30 = index_tage(rv, 30)
    v7 = index_tage(rv, 7)
    pruef("Index von Hand: 100 · √(365/30 · Σ RV) und Beginn erst mit vollem Fenster",
          _gleich_rel(v30[29], soll) and np.isnan(v30[28]) and _gleich_rel(v7[6], soll) and np.isnan(v7[5]), f"{v30[29]} / {soll}")
    x = np.linspace(1e-4, 9e-4, 60)
    pruef("Index von Hand mit wechselnden Werten", _gleich_rel(index_tage(x, 30)[45], 100 * math.sqrt(365 / 30 * x[16:46].sum())))
    r2, r3, r4, r5 = rv.copy(), rv.copy(), rv.copy(), rv.copy()
    r2[40:43] = np.nan
    r3[40:44] = np.nan
    r4[44] = np.nan
    r5[44:46] = np.nan
    pruef("Index: 3 ungültige von 30 Tagen gültig, 4 nicht; 7 Tage mit 6 gültigen (Nachtrag 13.9), mit 5 nicht",
          _gleich_rel(index_tage(r2, 30)[45], soll) and np.isnan(index_tage(r3, 30)[45]) and _gleich_rel(index_tage(r4, 7)[46], soll)
          and np.isnan(index_tage(r5, 7)[47]))


def _st_reihe(pruef, rng) -> None:
    d0 = datum_tag(date(2022, 3, 1))
    rv = rng.uniform(1e-4, 1e-3, 900)
    rv[[45, 300, 301, 302, 303]] = np.nan
    r = Reihe("X", d0, rv)
    i = 60
    ok = (_gleich_rel(r.r1[i], rv[59]) and _gleich_rel(r.r7[i], np.mean(rv[53:60])) and _gleich_rel(r.r7[50], np.nanmean(rv[43:50]))
          and _gleich_rel(r.r30[i], np.nanmean(rv[30:60])) and _gleich_rel(r.r30[50], np.nanmean(rv[20:50])))
    for k in WOCHEN:
        ok = ok and _gleich_rel(r.ziel[k][i], np.mean(rv[i + 7 * (k - 1):i + 7 * k]))
    ok = ok and _gleich_rel(r.ziel[1][40], np.nanmean(rv[40:47])) and _gleich_rel(r.vorwoche[i], np.mean(rv[53:60]))
    ok = ok and np.isnan(r.ziel[1][r.n - 3])
    pruef("Reihe von Hand: Vortag, 7 Tage (6 von 7), 30 Tage (27 von 30) vor D, Wochen ab D (6 von 7), Vorwoche", ok)
    pruef("RV des Vortags: ungültig -> letzter gültiger Tag, höchstens 3 zurück",
          _gleich_rel(r.r1[46], rv[44]) and _gleich_rel(r.r1[302], rv[299]) and np.isnan(r.r1[303]) and np.isnan(r.r1[304]))
    ew = None
    for v in rv[:599]:
        if np.isfinite(v):
            ew = v if ew is None else 0.94 * ew + 0.06 * v
    pruef("B365 (329 von 365) und EWMA 0,94 bis D−1 von Hand",
          _gleich_rel(r.b365[700], np.nanmean(rv[335:700])) and np.isnan(r.b365[364]) and _gleich_rel(r.ewma[599], ew))
    i = 700
    m7 = [np.nanmean(rv[e - 6:e + 1]) if np.isfinite(rv[e - 6:e + 1]).sum() >= 6 else np.nan for e in range(i - 359, i)]
    soll = np.percentile([x for x in m7 if np.isfinite(x)], 80)
    pruef("Schwelle von Hand: 80. Perzentil der 359 Wochenmittel in den 365 Tagen vor D; vorher keine",
          _gleich_rel(r.schwelle[i], soll) and np.isnan(r.schwelle[300]), f"{r.schwelle[i]} / {soll}")
    steigend = Reihe("X", d0, np.linspace(1e-4, 1e-3, 800))
    m7s = [np.mean(steigend.rv[e - 6:e + 1]) for e in range(700 - 359, 700)]
    fallend = np.linspace(1e-3, 1e-4, 800)
    spitze = fallend.copy()
    spitze[700] *= 100.0
    pruef("Schwelle von Hand auf steigender Reihe und nur aus Tagen vor D (Spitze am Tag D ändert sie nicht)",
          _gleich_rel(steigend.schwelle[700], np.percentile(m7s, 80))
          and _gleich_rel(Reihe("X", d0, fallend).schwelle[700], Reihe("X", d0, spitze).schwelle[700]))
    vol_ok = r.vol[2][i] == float(r.ziel[2][i] > r.schwelle[i]) and r.zustand[i] == float(r.vorwoche[i] > r.schwelle[i])
    pruef("Volatile Woche und Zustand mit der Schwelle des Ursprungs", vol_ok)
    i = 850
    pos = [s for s in range(0, i - 14 + 1) if np.isfinite(r.vol[2][s])][-RATE_MAX:]
    v = np.array([r.vol[2][s] for s in pos])
    z = np.array([r.zustand[s] for s in pos])
    g, p0, p1, n = r.raten(i, 2)
    soll1 = v[z == 1].mean() if (z == 1).sum() >= MARKOV_MIN else v.mean()
    pruef("Grundrate und Zwei-Zustands-Modell je Ursprung von Hand (jüngste 730 eingestufte mit s ≤ D − 7k, je Zustand ≥ 30)",
          len(pos) >= RATE_MIN and _gleich_rel(g, v.mean()) and _gleich_rel(p0, v[z == 0].mean()) and _gleich_rel(p1, soll1)
          and n == len(pos) and np.isnan(r.raten(380, 2)[0]), f"{g} / {v.mean()}")
    e = np.arange(r.n)
    zz = zonen(r, d0, d0 + r.n)
    an = {d0 + int(t) for t in e[6:] if np.isfinite(r.m7[t]) and np.isfinite(r.schwelle[t - 6]) and r.m7[t] > r.schwelle[t - 6]}
    aus_z = {t for a, b in zz for t in range(a, b + 1)}
    pruef("Vergangene Phasen von Hand: Tag t, wenn das 7-Tage-Mittel t−6 … t über S(t−6) lag", an == aus_z and len(an) > 10,
          f"{len(an)} / {len(aus_z)}")
    st = [(t * 3600, 50.0 + t % 24) for t in range(d0 * 24, (d0 + 5) * 24)]
    dv = dvol_tage(st)
    pruef("DVOL-Tageswert = Stunde mit Zeitstempel (e+1)·86400 − 3600, gilt ab dem Folgetag",
          dv.get(d0, (None,))[0] == 73.0 and dv.get(d0 + 4, (None,))[0] == 73.0 and len(dv) == 5, str(sorted(dv.items())[:2]))
    r2 = Reihe("X", d0, rv, {t: w for t, (w, _) in dv.items()})
    pruef("DVOL-Merkmal am Ursprung D aus dem Tageswert von D − 1",
          _gleich_rel(r2.dvol_x[1], math.log(0.73 ** 2 / 365)) and np.isnan(r2.dvol_x[0]) and np.isnan(r2.dvol_x[6]))


def _mu_historie(reihen: dict, coin: str, modell: str, von: int, bis: int) -> dict:
    """μ früherer Prognosen (nur für Selbsttest und Nachweisgrenze): Monat für Monat mit der Schätzung zum Monatsersten."""
    r = reihen[coin]
    mu = {k: np.full(r.n + 1, np.nan) for k in WOCHEN}
    m = monatserster(von)
    _, mit_x = modell_dvol(modell)
    while m <= bis:
        fits = koeff_rechnen(reihen, coin, modell, m)
        if fits is not None:
            a, b = max(m, von), min(naechster_monat(m) - 1, bis)
            idx = np.arange(a - r.d0, b - r.d0 + 1)
            idx = idx[(idx >= 1) & (idx <= r.n)]
            if len(idx):
                X = merkmale(r, idx, mit_x)
                ok = np.all(np.isfinite(X), axis=1)
                for k in WOCHEN:
                    mu[k][idx[ok]] = X[ok] @ np.array(fits[k]["beta"])
        m = naechster_monat(m)
    return mu


def _st_schaetzen(pruef, rng) -> None:
    d0 = datum_tag(date(2020, 1, 1))
    kal = _synth_kalender(d0, 1330)
    unbest = frozenset(sorted(t for t, a in kal.items() if a == "cpi")[5:8])     # drei Kalendertage ohne Veröffentlichung
    termine = _termine_reihe(kal, unbest)
    s2 = _synth_varianz(rng, d0, 1300, termine=frozenset(t for t, a in kal.items() if a == "cpi" and t not in unbest))
    rv = s2 * rng.chisquare(BARS_TAG, size=1300) / BARS_TAG
    stunden = [((d0 * 24 + h) * 3600, 100 * math.sqrt(365 * s2[h // 24]) * 1.1) for h in range(500 * 24, 1300 * 24)]
    dv = {t: w for t, (w, _) in dvol_tage(stunden).items()}
    r = Reihe("BTC", d0, rv, dv, rv * 0.9, termine)
    monat = monatserster(d0 + 1000)
    m_i = monat - d0
    ok = True
    for k in WOCHEN:
        sel = auswahl(r, k, m_i, False)
        ok = ok and len(sel) == FENSTER_MAX and sel.max() == m_i - 7 * k
    pruef("Schätzfenster: jüngste 730 Ursprünge mit Ziel vor dem Monatsersten (s + 7k ≤ M1)", ok)
    f = schaetzen(r, 2, monat, "M")
    sel = auswahl(r, 2, m_i, False)
    X = merkmale(r, sel, False)
    y = np.log(r.ziel[2][sel])
    b = np.linalg.solve(X.T @ X, X.T @ y)
    res = y - X @ b
    sg = math.sqrt(res @ res / (len(y) - 4))
    pruef("HAR von Hand (Normalgleichungen) und σ der Reste im Fenster",
          _gleich_rel(f["beta"], list(b), 1e-8) and _gleich_rel(f["sigma"], sg, 1e-8), f"{f['beta']} / {list(b)}")
    fp, f0 = schaetzen(r, 2, monat, "M+"), schaetzen(r, 2, monat, "M0")
    pruef("M° auf genau den Ursprüngen von M+ (gleiche Auswahl, ohne DVOL-Regressor)",
          fp is not None and f0 is not None and fp["n"] == f0["n"] and fp["von"] == f0["von"] and len(f0["beta"]) == 4
          and len(fp["beta"]) == 5 and f0["n"] < FENSTER_MAX + 1, f"{fp and fp['n']} / {f0 and f0['n']}")
    reihen = {"BTC": r}
    mu = _mu_historie(reihen, "BTC", "M", d0 + 420, d0 + 1100)
    fe = Fehler(r, mu)
    i = monat - d0 + 5
    k = 3
    pos = [s for s in range(0, i - 7 * k + 1) if np.isfinite(mu[k][s]) and np.isfinite(r.ziel[k][s])][-SIGMA_MAX:]
    e = np.array([math.log(r.ziel[k][s]) - mu[k][s] for s in pos])
    so, n = fe.sigma(i, k)
    pruef("σ außerhalb von Hand: Fehler der jüngsten 730 früheren Prognosen mit fertigem Ziel (s ≤ D − 7k), mindestens 365",
          len(pos) >= SIGMA_MIN and _gleich_rel(so, float(np.std(e, ddof=1)), 1e-9) and n == len(pos), f"{so} / {np.std(e, ddof=1)}")
    fits = {kk: schaetzen(r, kk, monat, "M") for kk in WOCHEN}
    pr = vorhersage(r, i, fits, "M", fe)
    x = merkmale(r, np.array([i]), False)[0]
    mu3 = float(np.dot(fits[3]["beta"], x))
    p_soll = 0.5 * (1 - math.erf((math.log(r.schwelle[i]) - mu3) / (so * math.sqrt(2))))
    pruef("Prognose von Hand: μ, σ außerhalb, V̂ = exp(μ + σ²/2), P = 1 − Φ((log S − μ)/σ), B0, B365, EWMA",
          _gleich_rel(pr[2]["mu"], mu3) and _gleich_rel(pr[2]["sigma"], so) and pr[2]["sigma_quelle"] == "oos"
          and _gleich_rel(pr[2]["v"], math.exp(mu3 + so * so / 2)) and _gleich_rel(pr[2]["p"], p_soll, 1e-9)
          and _gleich_rel(pr[2]["v_b0"], r.r30[i]) and _gleich_rel(pr[2]["v_b365"], r.b365[i]) and _gleich_rel(pr[2]["v_ewma"], r.ewma[i]))
    pruef("Tagespfad erhält das Wochenmittel (Kalender verteilt nur um)", all(_gleich_rel(np.mean(z_["pfad"]), z_["v"], 1e-12) for z_ in pr))
    # Terminfaktor von Hand: nur bestätigte Termine der drei Jahre vor D, Vergleich Werktage desselben Monats ohne Termin
    D = monat + 5
    xs = []
    for t, a in kal.items():
        if a != "cpi" or t in unbest or not (D - TERMIN_TAGE <= t < D):
            continue
        dt = tag_datum(t)
        vgl = [u for u in range(datum_tag(date(dt.year, dt.month, 1)), min(naechster_monat(t), D))
               if wochentag(u) < 5 and u not in kal and np.isfinite(r.rv[u - d0])]
        if len(vgl) >= TERMIN_VERGLEICH_MIN and np.isfinite(r.rv[t - d0]):
            xs.append(math.log(r.rv[t - d0]) - np.mean([math.log(r.rv[u - d0]) for u in vgl]))
    fa = min(3.0, max(1.0, math.exp(0.5 * np.mean(xs))))
    f_ = tagesfaktoren(r, i)
    a_ = max(0, i - WT_TAGE)
    with np.errstate(divide="ignore", invalid="ignore"):
        lr = np.log(r.rv[a_:i] / r.r7[a_:i])
    wt = r.wt[a_:i]
    fw = [math.exp(0.5 * np.nanmean(lr[(wt == w) & np.isfinite(lr)])) for w in range(7)]
    cpi_fenster = [t for t, a in kal.items() if a == "cpi" and D <= t < D + 28]
    ok = bool(cpi_fenster) and fa > 1.05
    for t in cpi_fenster:
        ok = ok and _gleich_rel(f_[t - D], fw[wochentag(t)] * fa, 1e-9)
    ok = ok and all(_gleich_rel(f_[j], fw[wochentag(D + j)], 1e-9) for j in range(28) if (D + j) not in kal)
    pruef("Kalenderfaktoren von Hand: Wochentag exp(½ · Mittel log(RV/R7)), Termin wie U154 nur aus bestätigten Terminen",
          ok, f"Termin {fa:.4f}, {len(xs)} Termine")
    t2 = dict(termine)
    t2[D + 28] = [("cpi", D + 28 - 60, True)]
    t3 = dict(termine)
    for t in cpi_fenster:
        t3[t] = [("cpi", t + 1, True)]                 # wie im Stillstand: erst nach dem Tag bekannt
    r_b = Reihe("BTC", d0, r.rv, dv, r.rs, t2)
    r_c = Reihe("BTC", d0, r.rv, dv, r.rs, t3)
    f_c = tagesfaktoren(r_c, i)
    pruef("Termin außerhalb der vier Wochen ändert den Pfad nicht; ein erst nach dem Tag bekannter Termin wirkt nicht",
          np.allclose(tagesfaktoren(r_b, i), f_, rtol=0, atol=0)
          and all(_gleich_rel(f_c[t - D], fw[wochentag(t)], 1e-9) for t in cpi_fenster))


def _st_hype(pruef, rng) -> None:
    d0 = datum_tag(date(2020, 1, 1))
    reihen = {}
    for j, c in enumerate(PRUEF_COINS):
        s2 = _synth_varianz(rng, d0, 1300, mittel=-7.6 + 0.3 * j)
        reihen[c] = Reihe(c, d0, s2 * rng.chisquare(BARS_TAG, size=1300) / BARS_TAG)
    a = d0 + 800
    s2 = _synth_varianz(rng, a, 500, mittel=-6.4)
    reihen["HYPE"] = Reihe("HYPE", a, s2 * rng.chisquare(BARS_TAG, size=500) / BARS_TAG)
    monat = monatserster(d0 + 1290)
    f = schaetzen_gepoolt(reihen, 1, monat)
    h = reihen["HYPE"]
    sel = auswahl(h, 1, h.i_von(monat), False)
    xh = merkmale(h, sel, False)[:, 1:]
    soll = float(np.mean(np.log(h.ziel[1][sel]) - xh @ np.array(f["beta"][1:])))
    pruef("HYPE: gemeinsame Steigungen, eigenes Niveau von Hand (Mittel der eigenen Reste, ≥ 90 Ursprünge)",
          f is not None and f["niveau"] == "eigen" and len(sel) >= HYPE_MIN and _gleich_rel(f["beta"][0], soll, 1e-9),
          f"{f and f['beta'][0]} / {soll}")
    f2 = schaetzen_gepoolt(reihen, 1, monatserster(a + 120))
    pruef("HYPE mit weniger als 90 eigenen Ursprüngen: Mittel der Achsenabschnitte, gekennzeichnet",
          f2 is not None and f2["niveau"] == "Mittel der Achsenabschnitte")


def _st_kausal(pruef, rng) -> None:
    """Kerzen, DVOL und Termine nach dem Ursprung ändern nichts an der Prognose (Regel 2) – mit σ außerhalb und Tagespfad."""
    d0 = datum_tag(date(2020, 1, 1))
    tage = 1250
    kal = _synth_kalender(d0, tage + 60)
    termine = _termine_reihe(kal)
    cpi = frozenset(t for t, a in kal.items() if a == "cpi")
    basis, stunden = {}, {}
    for c in PRUEF_COINS + ("HYPE",):
        a = d0 + (600 if c == "HYPE" else 0)
        s2 = _synth_varianz(rng, a, tage - (a - d0), termine=cpi)
        rv = s2 * rng.chisquare(BARS_TAG, size=len(s2)) / BARS_TAG
        basis[c] = (a, rv)
        if c in DVOL_COINS:
            stunden[c] = [((a * 24 + h) * 3600, 100 * math.sqrt(365 * s2[h // 24]) * 1.1 + rng.normal()) for h in range(len(s2) * 24)]
    fehler, geaendert = [], 0
    for D in (monatserster(d0 + 1100), d0 + 1117, monatserster(d0 + 1100) + 31):
        def bauen(stoer: bool) -> dict:
            aus = {}
            for c, (a, rv) in basis.items():
                rv2 = rv.copy()
                if stoer:
                    j = max(0, D - a)
                    rv2[j:] = rv2[j:] * np.random.default_rng(D).uniform(0.2, 4.0, size=len(rv2) - j)
                dv = None
                if c in stunden:
                    dv = {t: w for t, (w, _) in dvol_tage([(t, w * (1.7 if stoer and t >= D * TAG else 1.0)) for t, w in stunden[c]]).items()}
                aus[c] = Reihe(c, a, rv2, dv, rv2 * 0.9, termine)
            return aus
        A, B = bauen(False), bauen(True)
        m = monatserster(D)
        for c in ("BTC", "ETH", "XMR", "HYPE"):
            for modell in modelle_fuer(c):
                ergebnis = []
                for W in (A, B):
                    mu = _mu_historie(W, c, modell, max(W[c].d0 + 420, D - 400), D - 1)
                    fe = Fehler(W[c], mu)
                    ergebnis.append((vorhersage(W[c], D - W[c].d0, koeff_rechnen(W, c, modell, m), modell, fe),
                                     vorhersage(W[c], D + 10 - W[c].d0, koeff_rechnen(W, c, modell, monatserster(D + 10)), modell, fe)))
                (pa_, pc_), (pb_, pd_) = ergebnis
                if pa_ is None or pb_ is None:
                    fehler.append(f"{c} {modell} {_datum(D)}: keine Prognose")
                    continue
                for za, zb in zip(pa_, pb_):
                    for kk in za:
                        if not _gleich_rel(za[kk], zb[kk], 1e-12):
                            fehler.append(f"{c} {modell} {_datum(D)} W{za['woche']} {kk}")
                if pc_ and pd_ and not _gleich_rel(pc_[0]["mu"], pd_[0]["mu"], 1e-9):
                    geaendert += 1
    pruef("Kausalität: Tage, DVOL-Stunden und Termin-Tage nach D ändern keine Prognose zu D (M, M+, M°, geliehen; σ außerhalb; "
          "3 Ursprünge)", not fehler, "; ".join(sorted(set(fehler))[:6]))
    pruef("Kausalität, Gegenprobe: dieselbe Störung wirkt auf Prognosen nach ihr", geaendert >= 10, f"{geaendert} geändert")


def _st_kalender(pruef) -> None:
    v = verfallstage(datum_tag(date(2021, 12, 1)), datum_tag(date(2026, 8, 31)))
    soll = {date(2021, 12, 31): "verfall_q", date(2022, 1, 28): "verfall_m", date(2024, 3, 29): "verfall_q",
            date(2025, 10, 31): "verfall_m", date(2026, 7, 31): "verfall_m", date(2026, 6, 26): "verfall_q"}
    ok = all(v.get(datum_tag(d)) == a for d, a in soll.items()) and len(v) == 57
    ok = ok and all(tag_datum(t).weekday() == 4 and (tag_datum(t) + timedelta(days=7)).month != tag_datum(t).month for t in v)
    pruef("Verfallstage: letzter Freitag, Quartal im März/Juni/September/Dezember, Monatsende auf Freitag", ok, f"{len(v)} Tage")
    f = fed_tage()
    jahre = {tag_datum(t).year: 0 for t in f}
    for t in f:
        jahre[tag_datum(t).year] += 1
    pruef("Fed-Termine: feste Liste 2021–2027, je Jahr 8, aufsteigend, Dienstag bis Donnerstag",
          f == sorted(set(f)) and set(jahre) == set(range(2021, 2028)) and all(n == 8 for n in jahre.values())
          and all(1 <= tag_datum(t).weekday() <= 3 for t in f), str(jahre))


def _welt_d(rng, tage: int = 2600, von: int = 760) -> dict:
    """Eine synthetische Welt mit realistischer Ballung (13.3): langsames Niveau (AR 0,998), HAR-Abweichung (0,35/0,35/0,2),
    t5-Schocks, Messrauschen Gamma(16). Prognosen wie im Betrieb (Schätzung je Monat, σ im Fenster genügt für die Größe)."""
    d0 = datum_tag(date(2018, 1, 1))
    L = np.empty(tage)
    yv = np.zeros(tage)
    L[0] = rng.normal(0, 0.4)
    sl = 0.4 * math.sqrt(1 - 0.998 ** 2)
    eps = rng.standard_t(5, tage) / math.sqrt(5 / 3)
    for t in range(1, tage):
        L[t] = 0.998 * L[t - 1] + sl * rng.normal()
        yv[t] = 0.35 * yv[t - 1] + 0.35 * yv[max(0, t - 7):t].mean() + 0.2 * yv[max(0, t - 30):t].mean() + 0.35 * eps[t]
    rv = np.exp(math.log(0.6 ** 2 / 365) + L + yv) * rng.gamma(16, 1 / 16, tage)
    r = Reihe("W", d0, rv)
    bis = d0 + tage - 29
    d1 = np.full((bis - (d0 + von) + 1, 4), np.nan)
    d2 = np.full_like(d1, np.nan)
    qb = np.full_like(d1, np.nan)
    m = monatserster(d0 + von)
    while m <= bis:
        fits = koeff_rechnen({"W": r}, "W", "M", m)
        a, b = max(m, d0 + von), min(naechster_monat(m) - 1, bis)
        if fits is not None:
            idx = np.arange(a - d0, b - d0 + 1)
            X = merkmale(r, idx, False)
            for kk, k in enumerate(WOCHEN):
                mu = X @ np.array(fits[k]["beta"])
                sg = fits[k]["sigma"]
                v = np.exp(mu + sg * sg / 2)
                R = r.ziel[k][idx]
                d1[idx - von, kk] = v1_diff(R, r.r30[idx], v)
                qb[idx - von, kk] = qlike(R, r.r30[idx])
                S = r.schwelle[idx]
                with np.errstate(invalid="ignore", divide="ignore"):
                    p = 0.5 * np.array([math.erfc((math.log(s) - u) / (sg * math.sqrt(2))) if np.isfinite(s) and s > 0 else np.nan
                                        for s, u in zip(S, mu)])
                    y = np.where(np.isfinite(R) & np.isfinite(S), (R > S).astype(float), np.nan)
                g = np.array([r.raten(int(i), k)[0] for i in idx])
                d2[idx - von, kk] = (g - y) ** 2 - (p - y) ** 2
        m = naechster_monat(m)
    return {"V1a": d1, "V2": d2, "q_b0": qb}


def _groesse(welten: int, ziehungen: int, saat: int = 41) -> dict:
    """Größe der Prüfstrecke (13.3): Verlustdifferenzen um ihr Populationsmittel verschoben, volle Urteilsregel mit dem ersten Block."""
    rng = np.random.default_rng(saat)
    W = [_welt_d(rng) for _ in range(welten)]
    aus = {}
    for teil in ("V1a", "V2"):
        mittel = float(np.nanmean([np.nanmean(w[teil]) for w in W]))
        belegt = 0
        for j, w in enumerate(W):
            d = w[teil] - mittel
            g = np.isfinite(d)
            n = g.sum(axis=1).astype(float)
            s = np.where(g, d, 0.0).sum(axis=1)
            ok = n > 0
            e = block_bootstrap(n[ok], s[ok], ziehungen, bloecke()[0], 500 + j)
            e["h1"], e["h2"], e["k1"], e["k2"] = haelften(n[ok], s[ok])
            belegt += urteil(e, e["p"]) == "belegt"
        aus[teil] = belegt / welten
    return aus


def _st_bootstrap(pruef, schnell: bool) -> None:
    rng = np.random.default_rng(5)
    n = rng.integers(8, 17, size=60).astype(float)
    s = n * (rng.normal(size=60) * 0.5 + 0.1)
    starts = rng.integers(0, 60, size=(300, 3))
    p1 = block_bootstrap(n, s, block=28, starts=starts)["p"]
    p2 = block_bootstrap_schleife(list(n), list(s), starts, 28)
    pruef("Bootstrap gleich der langsamen Vergleichsfassung (zentriert, studentisiert, zirkuläre Blöcke)", _gleich_rel(p1, p2, 1e-12),
          f"{p1} / {p2}")
    pruef("Blockregel vorab: 112, dann 168, dann 224 Tage; Vorzeichen-Block 224 Tage", bloecke() == (112, 168, 224) and VZ_BLOCK == 224,
          str(bloecke()))
    tage = np.arange(1800) + 19000
    nn = np.full(1800, 16.0)
    ss = 16.0 * (np.convolve(rng.normal(size=1800 + 111), np.ones(112) / 112, mode="valid") + 0.05)
    r1 = vorzeichen_rate(tage, nn, ss, 112, 40, 199)
    r2 = vorzeichen_rate(tage, nn, ss + 16.0 * 3.0, 112, 40, 199)
    pruef("Vorzeichen-Nullprobe zentriert (ein konstanter Effekt ändert die Rate nicht) und liegt zwischen 0 und 1",
          _gleich_rel(r1, r2, 1e-9) and 0 <= r1 <= 1, f"{r1} / {r2}")
    if not schnell:                                # die Mutationen der Prüfstrecke fängt schon der Vergleich und die Blockregel
        welten = 150
        gr = _groesse(welten, 499)
        grenze = 0.05 + 2.326 * math.sqrt(0.05 * 0.95 / welten)
        pruef("Größe in synthetischen Welten mit realistischer Ballung (Block 112, Hälften, Mindestzahl) höchstens 5 % plus Toleranz",
              all(v <= grenze for v in gr.values()), f"{', '.join(f'{k} {_pz(v)}' for k, v in gr.items())} (Grenze {_pz(grenze)}, "
                                                      f"{welten} Welten)")


def _st_regeln(pruef) -> None:
    ph = holm_gewichtet({"V1": 0.01, "V2": 0.04, "V3": 0.03, "V4": None}, GEWICHT)
    pruef("Gewichteter Holm von Hand (nicht prüfbare fallen heraus, Gewichte normiert)",
          _gleich_rel(ph["V1"], 0.03) and _gleich_rel(ph["V3"], 0.06) and _gleich_rel(ph["V2"], 0.06) and ph["V4"] is None, ph)
    e = {"tage": 1500, "mass": 0.1, "h1": 0.1, "h2": 0.05, "k1": 750, "k2": 750}
    ok = urteil(e, 0.01) == "belegt"
    ok = ok and urteil(dict(e, tage=1300), 0.01) == "nicht prüfbar"
    ok = ok and urteil(dict(e, h2=-0.01), 0.01) == "nicht belegt"
    ok = ok and urteil(e, 0.06) == "nicht belegt"
    ok = ok and urteil(dict(e, k1=600, k2=900), 0.01) == "nicht belegt"
    pruef("Urteilsregel: Mindestzahl 1.344 Tage, Hälften (je ≥ 672 Tage, beide > 0), angepasstes p < 0,05", ok)
    eb = dict(e, mass=-0.02, h1=-0.01, h2=-0.03)
    pruef("V1 als Schnitt-Test: p = größeres p; belegt nur, wenn 30-Tage- und Jahresmittel geschlagen sind",
          _gleich_rel(v1_p(0.01, 0.03), 0.03) and v1_urteil(e, e, 0.02) == "belegt" and v1_urteil(e, eb, 0.02) == "nicht belegt")
    pruef("QLIKE und Vorzeichen von Hand: Differenz positiv, wenn M näher am Ergebnis liegt als der Vergleich",
          _gleich_rel(float(qlike(2.0, 1.0)), 2.0 - math.log(2.0) - 1.0) and float(v1_diff(1.0, 2.0, 1.1)) > 0
          and float(v1_diff(1.0, 1.1, 2.0)) < 0)
    n = np.array([1.0] * 10 + [10.0] * 10)
    s = np.array([1.0] * 10 + [-10.0] * 10)
    h1, h2, k1, k2 = haelften(n, s)
    pruef("Hälften am Median-Datum in Ursprungstagen (nicht in Fällen)", k1 == 10 and k2 == 10 and h1 == 1.0 and h2 == -1.0,
          (h1, h2, k1, k2))


# --- Ende zu Ende auf synthetischen Datenbanken -----------------------------------------------------------------------------

def _e2e_quellen(tmp: str, rng, d0: int, tage: int) -> tuple[dict, dict]:
    """swing.db, aktien.db und makro.db wie auf dem Pi, synthetisch."""
    q = {"swing": os.path.join(tmp, "swing.db"), "aktien": os.path.join(tmp, "aktien.db"), "makro": os.path.join(tmp, "makro.db"),
         "vol": os.path.join(tmp, "volatil.db")}
    kal = _synth_kalender(d0, tage + 60)
    cpi = sorted(t for t, a in kal.items() if a == "cpi")
    unbest = frozenset(cpi[3:5])                      # zwei Kalendertage ohne Erstveröffentlichung
    wirkt = frozenset(t for t in cpi if t not in unbest)
    sc = sqlite3.connect(q["swing"])
    sc.execute("CREATE TABLE sw_klines (coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY (coin, ts)) "
               "WITHOUT ROWID")
    ac = sqlite3.connect(q["aktien"])
    ac.execute("CREATE TABLE ak_aktuell (reihe TEXT NOT NULL, ts INTEGER NOT NULL, wert REAL, abgerufen INTEGER, fassungen INTEGER, "
               "PRIMARY KEY (reihe, ts)) WITHOUT ROWID")
    varianz = {}
    for c in COINS:
        a = d0 + (500 if c == "HYPE" else 0)
        s2 = _synth_varianz(rng, a, tage - (a - d0), termine=wirkt)
        varianz[c] = (a, s2)
        luecken = ((50, 5), (90, 8)) if c == "ETH" else ()
        ts, o, h, lo, cc = _synth_kerzen(rng, a, s2, 100.0 * (1 + COINS.index(c)), luecken)
        sc.executemany("INSERT INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                       zip((c,) * len(ts), ts.tolist(), o.tolist(), h.tolist(), lo.tolist(), cc.tolist(), (1.0,) * len(ts)))
        if c in DVOL_COINS:
            zeilen = []
            for j in range(100 * 24, len(s2) * 24):
                t = (a * 24 + j) * 3600
                if c == "BTC" and j // 24 in (900, 901) and j % 24 == 23:
                    continue                                   # zwei fehlende Stunden 23 Uhr (makro.db hat den Tageswert)
                zeilen.append(("drb:dvol_%s_h" % c.lower(), t, 100 * math.sqrt(365 * s2[j // 24]) * 1.15 + rng.normal(), t + 60, 1))
            ac.executemany("INSERT INTO ak_aktuell VALUES (?,?,?,?,?)", zeilen)
    sc.commit()
    sc.close()
    ac.commit()
    ac.close()
    mc = sqlite3.connect(q["makro"])
    mc.execute("CREATE TABLE mk_reihe (reihe TEXT NOT NULL, ts INTEGER NOT NULL, wert REAL, abgerufen INTEGER, PRIMARY KEY (reihe, ts)) "
               "WITHOUT ROWID")
    mc.execute("CREATE TABLE mk_meta (k TEXT PRIMARY KEY, v TEXT)")
    mc.execute("CREATE TABLE mk_termin (release INTEGER NOT NULL, tag INTEGER NOT NULL, abgerufen INTEGER, PRIMARY KEY (release, tag)) "
               "WITHOUT ROWID")
    mc.execute("CREATE TABLE mk_fassung (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, wert REAL, art TEXT, "
               "PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID")
    mc.executemany("INSERT INTO mk_meta VALUES (?,?)", [("release:CPIAUCSL", json.dumps({"id": 10, "name": "CPI"})),
                                                        ("release:UNRATE", json.dumps({"id": 50, "name": "Employment"}))])
    mc.executemany("INSERT INTO mk_termin VALUES (?,?,?)", [(10 if a == "cpi" else 50, t * TAG, (d0 + tage) * TAG)
                                                            for t, a in kal.items()])
    mc.executemany("INSERT INTO mk_fassung VALUES (?,?,?,?,?)", [("fred:" + ("CPIAUCSL" if a == "cpi" else "UNRATE"), (t - 40) * TAG,
                                                                  t * TAG + 45000, 1.0, "erst")
                                                                 for t, a in kal.items() if t not in unbest and t < d0 + tage - 20])
    a, s2 = varianz["BTC"]
    mc.executemany("INSERT INTO mk_reihe VALUES (?,?,?,?)", [("drb:dvol_btc", (a + j) * TAG, 100 * math.sqrt(365 * s2[j]) * 1.15, 0)
                                                             for j in range(899, 903)])
    mc.commit()
    mc.close()
    return q, {"kal": kal, "unbest": unbest}


def _ende_zu_ende(pruef, schnell: bool) -> None:
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="vl_st_")
    try:
        rng = np.random.default_rng(77)
        d0 = datum_tag(date(2019, 1, 7))
        tage = 1100
        rb_start = d0 + 800
        st_tag = d0 + 1040
        q, info = _e2e_quellen(tmp, rng, d0, tage)
        con = verbinden(q["vol"])
        jetzt = st_tag * TAG + 3600
        bericht = erstlauf(con, q, jetzt, rb_start)
        pruef("E2E Erstlauf: Stichtag gesetzt und in volatil_stichtag.json, Kerzen, DVOL (Einheit), Termine gefunden",
              stichtag(con) == jetzt and "Vol-Punkte" in bericht and "Fed-Entscheid" in bericht and "⚠" not in bericht
              and os.path.exists(stichtag_datei(q)), bericht[-700:])
        tdb = {(int(t), a): (qq, b, best) for t, a, qq, b, best in con.execute("SELECT tag, art, quelle, bekannt, bestaetigt FROM vl_termin")}
        u0 = sorted(info["unbest"])[0]
        cpi_b = [t for t, a in info["kal"].items() if a == "cpi" and t not in info["unbest"] and t < d0 + tage - 20]
        pruef("E2E Termine: bestätigte Inflationstage mit „bekannt ab Tag − 60“, Kalendertag ohne Erstveröffentlichung ohne Wirkung, "
              "Fed aus der festen Liste, Verfall nach Regel",
              all(tdb.get((t, "cpi")) == ("fred", t - 60, 1) for t in cpi_b) and tdb.get((u0, "cpi")) == ("fred", None, 0)
              and any(a == "fed" for (_, a) in tdb) and any(a == "verfall_q" for (_, a) in tdb), str(tdb.get((u0, "cpi"))))
        rb = Rueckblick(con, rb_start)
        teil = False
        while rb.schritt(jetzt):
            if not teil and "BTC" in rb_coins_fertig(con) and "XMR" not in rb_coins_fertig(con):
                teil = True
                pruef("E2E Freigabe erst mit dem ganzen Rückblick (ein Coin fertig genügt nicht)", not freigabe(con)[0])
        pruef("E2E Rückblick in Schritten fertig", rb.fertig() and teil, json.dumps(meta(con, "rb"))[:300])
        n_rb = con.execute("SELECT COUNT(*) FROM vl_prognose WHERE quelle='rb' AND coin='BTC' AND modell='M'").fetchone()[0]
        mx = con.execute("SELECT MIN(ursprung), MAX(ursprung) FROM vl_prognose WHERE quelle='rb'").fetchone()
        n_vl = con.execute("SELECT COUNT(*), MAX(ursprung) FROM vl_prognose WHERE quelle='vorlauf' AND coin='BTC' AND modell='M'").fetchone()
        so = con.execute("SELECT MIN(ursprung) FROM vl_prognose WHERE quelle='rb' AND coin='BTC' AND modell='M' AND sigma_quelle='oos'"
                         ).fetchone()[0]
        pruef("E2E Rückblick: Ursprünge vom Start bis zum Stichtag; Vorlauf davor (ohne Pfad); σ außerhalb, sobald 365 Fehler da sind",
              n_rb == 4 * (st_tag - rb_start + 1) and mx == (rb_start, st_tag) and n_vl[0] > 0 and n_vl[1] == rb_start - 1
              and so is not None and con.execute("SELECT COUNT(*) FROM vl_prognose WHERE quelle='vorlauf' AND pfad IS NOT NULL"
                                                  ).fetchone()[0] == 0, f"{n_rb}, {mx}, Vorlauf {n_vl}, σ außerhalb ab {_datum(so)}")
        aD = d0 + 902                                    # Ursprung, dessen DVOL-Stunde fehlt (Tageswert nur aus makro.db)
        n_p = con.execute("SELECT COUNT(*) FROM vl_prognose WHERE coin='BTC' AND modell='M+' AND ursprung IN (?,?)",
                          (aD - 1, aD)).fetchone()[0]
        n_m0 = con.execute("SELECT COUNT(*) FROM vl_prognose WHERE coin='BTC' AND modell='M0' AND ursprung IN (?,?)",
                           (aD - 1, aD)).fetchone()[0]
        n_mp = con.execute("SELECT COUNT(*) FROM vl_prognose WHERE coin='BTC' AND modell='M+'").fetchone()[0]
        pruef("E2E M+ und M° nur mit DVOL-Stunde aus aktien.db (der Tageswert aus makro.db geht nie ins Modell)",
              n_p == 0 and n_m0 == 0 and n_mp > 0, f"{n_p}, {n_m0}, {n_mp}")
        niv = con.execute("SELECT COUNT(*), SUM(niveau='eigen') FROM vl_koeff WHERE coin='HYPE' AND modell='geliehen'").fetchone()
        pruef("E2E HYPE: gemeinsame Steigungen, eigenes Niveau (sobald 90 eigene Ursprünge da sind)", niv[0] > 0 and (niv[1] or 0) > 0,
              niv)
        nl = nutzlast(con, "bilanz", "BTC", jetzt)
        nc = nutzlast(con, "chart", "BTC", jetzt)
        roh = json.dumps(_ohne_nan(nc))
        zm = (meta(con, "zaehlung", {}) or {}).get("zaehlung")
        pruef("E2E Tor vor dem Urteil: Bilanz nur Zählung (ohne gespeicherte Zählung keine Nullen); Chart nur die jüngste Prognose, "
              "keine Vergleiche mit Ergebnissen",
              nl["urteil"] is None and "zaehlung" in nl and "beschreibend" not in nl and "historie" not in nc
              and ((nl["zaehlung"] is None) if not zm else bool((nl["zaehlung"] or {}).get("zeilen")))
              and (nc.get("prognose") or {}).get("ursprung") == st_tag and "besser" in roh and '"besser": []' in roh,
              f"Zählung gespeichert {bool(zm)}, gezeigt {nl.get('zaehlung') is not None}")
        zeile = con.execute("SELECT * FROM vl_prognose WHERE quelle='rb' LIMIT 1").fetchone()
        with schreiben(con):
            d = _einfuegen(con, [], [tuple(zeile[:9]) + (zeile[9] * 2,) + tuple(zeile[10:])])
        zeile2 = con.execute("SELECT * FROM vl_prognose WHERE coin=? AND ursprung=? AND modell=? AND woche=? AND fassung=?",
                             zeile[:5]).fetchone()
        pruef("E2E Prognosen nie überschrieben (gleiche Fassung; Neuberechnung gezählt)", d["doppelt_prognose"] == 1 and zeile2 == zeile
              and (meta(con, "doppelt") or {}).get("prognose") == 1)
        n_live = 14 if schnell else 40
        tage_aktualisieren(con, q["swing"], (st_tag + n_live + 1) * TAG)
        for D in range(st_tag + 1, st_tag + n_live + 1):
            if D == st_tag + 5:
                continue
            tageslauf(con, q, D * TAG + 3600, daten=False)
        qq = dict(con.execute("SELECT quelle, COUNT(DISTINCT ursprung) FROM vl_prognose WHERE coin='BTC' AND modell='M' AND "
                              "ursprung>? GROUP BY quelle", (st_tag,)))
        pruef("E2E Tageslauf: live je Tag, ein ausgelassener Tag als nachgeholt", qq == {"live": n_live - 1, "spaet": 1}, qq)
        mon_db = [int(r_[0]) for r_ in con.execute("SELECT DISTINCT monat FROM vl_koeff WHERE coin='BTC' AND modell='M' ORDER BY monat")]
        mon = []
        m = mon_db[0] if mon_db else 0
        while mon_db and m <= st_tag + n_live:
            mon.append(m)
            m = naechster_monat(m)
        pruef("E2E Neuschätzung je Monat lückenlos bis in den Tageslauf", mon_db == mon and mon_db[-1] == monatserster(st_tag + n_live),
              f"{len(mon_db)} / {len(mon)}")
        z_ = (st_tag + n_live) * TAG + 1800
        kw = dict(ziehungen=199 if schnell else 999, welten=20 if schnell else 60, null_ziehungen=199, min_tage=150, min_haelfte=60,
                  rb_start=rb_start, bl=(28, 42, 56), vz_block=56, orakel_t=2.5)
        aus = auswerten(con, q, z_, z_, **kw)
        vor = aus.get("vor_urteil") or []
        pruef("E2E Prüfungen vor dem Urteil bestanden (Daten, DVOL, Ballung, Wochenende, Bänder, Zuordnung, Vorzeichen-Nullprobe)",
              len(vor) == 7 and all(b for _, b, _ in vor), "; ".join(f"{n}: {w}" for n, b, w in vor if not b)[:300])
        u = urteil_zeilen(con)
        det = next((z["details"] for z in u if z["pruefung"] == "V2"), {})
        pruef("E2E Urteil einmal geschrieben (endgültig, Fassung), Stichprobe endet am Stichtag − 28 und enthält nur den Rückblick",
              len(u) == 6 and all(z["endgueltig"] == 1 for z in u) and det.get("max_ursprung") == st_tag - 28
              and set((det.get("quellen") or {}).keys()) == {"rb"} and det.get("block") in (28, 42, 56), json.dumps(det)[:300])
        uu = {z["pruefung"]: z for z in u}
        pruef("E2E Urteil: V1 aus V1a und V1b, alle mit Maß und Hälften; V4 nur mit BTC und ETH", len(uu) == 6 and
              all(_endlich(uu[t]["mass"]) and _endlich(uu[t]["h1"]) for t in ("V1a", "V1b", "V2", "V3", "V4"))
              and uu["V1"]["urteil"] in ("belegt", "nicht belegt") and uu["V4"]["n"] < uu["V2"]["n"]
              and _gleich_rel(uu["V1"]["p"], max(uu["V1a"]["p"], uu["V1b"]["p"])),
              [(z["pruefung"], z["urteil"], z["mass"], z["p"], z["p_holm"], z["tage"]) for z in u])
        aus2 = auswerten(con, q, z_ + 86400, z_ + 86400, **kw)
        pruef("E2E zweiter Lauf schreibt kein neues Urteil", aus2.get("phase") == "urteil"
              and con.execute("SELECT COUNT(DISTINCT lauf) FROM vl_auswertung WHERE pruefung='V1'").fetchone()[0] == 1)
        fehler = []
        for tab in ("chart", "bilanz", "daten"):
            for c in (COINS if tab == "chart" else ("BTC",)):
                try:
                    d = json.loads(payload_json(q["vol"], tab, c, z_))
                    if not d.get("ok"):
                        fehler.append(f"{tab}/{c}: {d.get('fehlt')}")
                    if tab == "chart":
                        p = d.get("prognose") or {}
                        if len(p.get("wochen") or []) != 4 or len(p.get("pfad") or []) != 28 or not d["reihe"]["vi30"]:
                            fehler.append(f"chart/{c}: Prognose oder Reihe unvollständig")
                        if (c in DVOL_COINS) != bool(d.get("dvol")):
                            fehler.append(f"chart/{c}: DVOL")
                except (ValueError, KeyError, TypeError) as e:
                    fehler.append(f"{tab}/{c}: {type(e).__name__} {e}")
        pruef("E2E Nutzlast aller Reiter und Coins ohne NaN, Prognose mit vier Wochen und 28 Tagen", not fehler, "; ".join(fehler[:5]))
        b = nutzlast(con, "bilanz", "BTC", z_)
        bw = (b.get("beschreibend") or {})
        pruef("E2E Bilanz nach dem Urteil: Urteil mit Teilen, Prüfungen vor dem Urteil, beschreibend je Woche mit Regel „besser“",
              b.get("urteil") and len(b["urteil"]["zeilen"]) == 6 and b.get("vor_urteil") and len(bw.get("je_woche") or []) == 4
              and set((bw.get("regel") or {}).get("1", {})) == {"B0", "B365", "EWMA", "grund", "markov"} and bw.get("robust"))
        c2 = verbinden(os.path.join(tmp, "zwei.db"))
        with schreiben(c2):
            c2.execute("INSERT INTO vl_auswertung VALUES ('V1', 1, ?, 10, 10, 0.5, 0.1, 0.9, NULL, NULL, NULL, NULL, 'kein Urteil', 0, "
                       "'{}')", (FASSUNG,))
            meta_setzen(c2, "stichtag", jetzt)
        b2 = nutzlast(c2, "bilanz", "BTC", z_)
        c2.close()
        pruef("E2E Tor: ein Lauf ohne bestandene Prüfungen zeigt kein Maß", b2.get("urteil") is None)
        q3 = dict(q, vol=os.path.join(tmp, "drei.db"))
        c3 = verbinden(q3["vol"])
        erstlauf(c3, q3, z_ + 7 * 86400, rb_start)
        st3 = stichtag(c3)
        c3.close()
        pruef("E2E Neuer Erstlauf übernimmt den Stichtag aus volatil_stichtag.json (verschiebt ihn nie)", st3 == jetzt, st3)
        t1 = bericht_stand(con, z_)
        t2 = bericht_auswertung(con)
        pruef("E2E Berichte Stand und Auswertung", "Rückblick: fertig" in t1 and "W4" in t1 and "Gemeinsames Urteil" in t2
              and "Tagespfad Woche 1" in t2 and "Robust V1a" in t2, t2[:200])
        con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def selbsttest(schnell: bool = False) -> list[tuple[str, bool, str]]:
    erg: list[tuple[str, bool, str]] = []

    def pruef(name, bed, info=""):
        erg.append((name, bool(bed), str(info)[:300]))

    rng = np.random.default_rng(237)
    for teil in (lambda: _st_tageswerte(pruef, rng), lambda: _st_index(pruef), lambda: _st_reihe(pruef, rng),
                 lambda: _st_schaetzen(pruef, rng), lambda: _st_hype(pruef, rng), lambda: _st_kausal(pruef, rng),
                 lambda: _st_kalender(pruef), lambda: _st_bootstrap(pruef, schnell), lambda: _st_regeln(pruef),
                 lambda: _ende_zu_ende(pruef, schnell)):
        try:
            teil()
        except Exception as e:  # noqa: BLE001 — eine Ausnahme ist ein roter Befund, kein Abbruch
            import traceback
            pruef("Ausnahme im Selbsttest", False, type(e).__name__ + ": " + str(e) + " " + traceback.format_exc()[-300:])
    return erg


def mutationen_pruefen() -> list[tuple[str, bool, list[str]]]:
    """Jede Mutation muss mindestens eine Prüfung des (schnellen) Selbsttests rot machen; vorher muss er ohne Mutation grün sein."""
    global _MUT
    _MUT = None
    basis = [n for n, ok, _ in selbsttest(schnell=True) if not ok]
    if basis:
        return [("(ohne Mutation)", False, basis)]
    aus = []
    for m in MUTATIONEN:
        _MUT = m
        try:
            rot = [n for n, ok, _ in selbsttest(schnell=True) if not ok]
        finally:
            _MUT = None
        aus.append((m, bool(rot), rot))
    return aus


def nachweisgrenze(welten: int = 150, ziehungen: int = 499, saat: int = 61) -> str:
    """Nachtrag 13.18: Stärke der endgültigen Regel (erster Block, Hälften, Mindestzahl) bei gepflanzten Effekten, synthetisch.
    Gepflanzt wird auf die um ihr Populationsmittel verschobenen Differenzen: relative QLIKE-Verbesserung 2, 5, 10, 20, 30 % des
    mittleren QLIKE der Persistenz bzw. Brier-Differenz 0,002, 0,005, 0,01, 0,02, 0,05. α 0,05 und 0,0125 (erster Holm-Schritt bei
    vier Prüfungen). Eine Münze je Welt (im Betrieb fünf, stark gleichlaufend -- deren Stärke ist nicht gemessen)."""
    rng = np.random.default_rng(saat)
    W = [_welt_d(rng) for _ in range(welten)]
    z = [f"Nachweisgrenze (synthetisch, {welten} Welten, {ziehungen} Ziehungen, Block {bloecke()[0]}, Mindestzahl {MIN_TAGE}, "
         f"Hälften je {MIN_HAELFTE})"]
    for teil, effekte, einheit in (("V1a", (0.02, 0.05, 0.10, 0.20, 0.30), "rel"), ("V2", (0.002, 0.005, 0.01, 0.02, 0.05), "abs")):
        mittel = float(np.nanmean([np.nanmean(w[teil]) for w in W]))
        basis = float(np.nanmean([np.nanmean(w["q_b0"]) for w in W])) if teil == "V1a" else 1.0
        for eff in effekte:
            delta = eff * basis if einheit == "rel" else eff
            a5 = a1 = 0
            for j, w in enumerate(W):
                d = w[teil] - mittel + delta
                g = np.isfinite(d)
                n = g.sum(axis=1).astype(float)
                s = np.where(g, d, 0.0).sum(axis=1)
                ok = n > 0
                e = block_bootstrap(n[ok], s[ok], ziehungen, bloecke()[0], 900 + j)
                e["h1"], e["h2"], e["k1"], e["k2"] = haelften(n[ok], s[ok])
                a5 += urteil(e, e["p"]) == "belegt"
                a1 += urteil(e, e["p"] * 4) == "belegt" if e["p"] is not None else 0
            z.append(f"  {teil} Effekt {eff:g}{' (relativ)' if einheit == 'rel' else ''}: Stärke α 0,05 {_pz(a5 / welten)}, "
                     f"α 0,0125 {_pz(a1 / welten)}")
    return "\n".join(z)


# ---------------------------------------------------------------------------
# 11. Dienst und Befehlszeile (Nachtrag 13.15: Rechnung als eigener Prozess mit nice 10)
# ---------------------------------------------------------------------------

_DIENST: dict = {"gestartet": False, "proc": None, "art": None, "start": {}, "fehler": None}
WIEDER_S = {"erstlauf": 3600, "rueckblick": 600, "auswertung": 1800, "tageslauf": 600}


def faellig(q: dict, jetzt: int | None = None) -> str | None:
    """Was steht an? Liest volatil.db nur (der Faden im Dashboard rechnet nichts)."""
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    con = lesen(q["vol"])
    if con is None:
        return "erstlauf"
    try:
        try:
            if stichtag(con) is None:
                return "erstlauf"
            if not (meta(con, "rb", {}) or {}).get("fertig"):
                return "rueckblick"
            u = con.execute("SELECT 1 FROM vl_auswertung WHERE fassung=? AND pruefung='V1' LIMIT 1", (FASSUNG,)).fetchone()
            if not u:
                return "auswertung"
            tl = meta(con, "tageslauf", {}) or {}
        except sqlite3.Error:
            return "erstlauf"
    finally:
        con.close()
    if (tl.get("heute") != heute and jetzt >= heute * TAG + 3600
            and (swing_vollstaendig(q["swing"], heute) or jetzt >= heute * TAG + 6 * 3600)):
        return "tageslauf"
    return None


def dienst_lauf(con, q: dict, jetzt: int | None = None) -> list[str]:
    """Ein Lauf des Dienstes (eigener Prozess): Erstlauf -> Rückblick bis zum Ende -> Urteil -> Tageslauf, je nachdem was fällig ist."""
    jetzt = int(jetzt or time.time())
    heute = jetzt // TAG
    erledigt = []

    def schritt(name, fn):
        try:
            fn()
            erledigt.append(name)
        except Exception as e:  # noqa: BLE001 — Grund in vl_meta, der nächste Lauf versucht es wieder
            with schreiben(con):
                meta_setzen(con, "fehler_" + name, {"ts": int(time.time()), "fehler": (type(e).__name__ + ": " + str(e))[:300]})
            raise
    if stichtag(con) is None:
        schritt("erstlauf", lambda: erstlauf(con, q, jetzt))
        if stichtag(con) is None:
            return erledigt
    rb = Rueckblick(con)
    if not rb.fertig():
        def rueck():
            while rb.schritt():
                pass
        schritt("rueckblick", rueck)
    if not con.execute("SELECT 1 FROM vl_auswertung WHERE fassung=? AND pruefung='V1' LIMIT 1", (FASSUNG,)).fetchone():
        schritt("auswertung", lambda: auswerten(con, q))
    tl = meta(con, "tageslauf", {}) or {}
    if tl.get("heute") != heute and jetzt >= heute * TAG + 3600 and (swing_vollstaendig(q["swing"], heute) or
                                                                      jetzt >= heute * TAG + 6 * 3600):
        schritt("tageslauf", lambda: tageslauf(con, q, jetzt))
        schritt("auswertung", lambda: auswerten(con, q))
    with schreiben(con):
        meta_setzen(con, "dienst", {"ts": int(time.time()), "schritt": ", ".join(erledigt) or "nichts fällig"})
    return erledigt


def takt_schritt(db: str, jetzt: float | None = None) -> str | None:
    """Jede Minute im Dashboard: läuft kein Prozess und ist etwas fällig, startet `hl_volatil.py --dienst` mit nice 10."""
    import subprocess
    jetzt = float(jetzt or time.time())
    p = _DIENST.get("proc")
    if p is not None and p.poll() is None:
        return None
    q = quellen(db)
    art = faellig(q, int(jetzt))
    if not art or jetzt - _DIENST["start"].get(art, 0.0) < WIEDER_S.get(art, 600):
        return None
    log = os.path.join(os.path.dirname(os.path.abspath(q["vol"])), "volatil_takt.log")
    try:
        if os.path.exists(log) and os.path.getsize(log) > 2_000_000:
            os.replace(log, log + ".1")
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%d.%m. %H:%M:%S')}] Start {art}\n")
            f.flush()
            _DIENST["proc"] = subprocess.Popen([sys.executable, "-B", os.path.abspath(__file__), "--dienst", "--db", db], stdout=f,
                                               stderr=subprocess.STDOUT, preexec_fn=lambda: os.nice(10),
                                               cwd=os.path.dirname(os.path.abspath(__file__)))
    except OSError as e:
        _DIENST["fehler"] = f"{type(e).__name__}: {e}"
        return None
    _DIENST["art"] = art
    _DIENST["start"][art] = jetzt
    return art


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen (Konzept 8). Nicht für Selbsttest-Datenbanken; aus mit HL_VOL=0. Start 90 s nach dem
    Dashboard (nach dem Swing-Faden)."""
    if _DIENST["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_VOL") == "0":
        return False
    _DIENST["gestartet"] = True

    def schleife():
        time.sleep(90)
        while True:
            try:
                takt_schritt(db)
            except Exception as e:  # noqa: BLE001
                _DIENST["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Volatilität-Takt: {_DIENST['fehler']}", flush=True)
            time.sleep(60)
    threading.Thread(target=schleife, daemon=True, name="volatil").start()
    return True


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Volatilität (U237): Index, Prognose für vier Wochen, Rückblick – nur lesen")
    ap.add_argument("--db", default=None, help="Hauptdatenbank (hl_liq.db); volatil.db liegt daneben")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--schnell", action="store_true", help="Selbsttest wie bei den Mutationen (ohne Größenmessung)")
    ap.add_argument("--mutationen", action="store_true")
    ap.add_argument("--nachweisgrenze", action="store_true", help="Stärke bei gepflanzten Effekten (synthetisch, Nachtrag 13.18)")
    ap.add_argument("--dienst", action="store_true", help="was fällig ist (so startet es der Faden im Dashboard, mit nice 10)")
    ap.add_argument("--erstlauf", action="store_true", help="Prüfung der Daten erneut (setzt den Stichtag nur, wenn er fehlt)")
    ap.add_argument("--rueckblick", type=int, default=None, metavar="SCHRITTE", help="Rückblick-Schritte (0 = bis zum Ende)")
    ap.add_argument("--tageslauf", action="store_true")
    ap.add_argument("--auswertung", action="store_true", help="Zählung bzw. das gemeinsame Urteil, sobald freigegeben")
    ap.add_argument("--stand", action="store_true")
    ap.add_argument("--nutzlast", default=None, metavar="TAB")
    ap.add_argument("--coin", default="BTC")
    a = ap.parse_args(argv)
    if a.selbsttest:
        t0 = time.time()
        erg = selbsttest(schnell=a.schnell)
        for n, ok, info in erg:
            print(("ok    " if ok else "ROT   ") + n + ("" if ok or not info else "  -- " + info))
        rot = [n for n, ok, _ in erg if not ok]
        print(("Selbsttest bestanden: " if not rot else "Selbsttest ROT: ") + str(len(erg) - len(rot)) + " von " + str(len(erg))
              + " (" + _de(time.time() - t0, 0) + " s)")
        return 1 if rot else 0
    if a.mutationen:
        t0 = time.time()
        aus = mutationen_pruefen()
        for m, rot, welche in aus:
            print(("rot       " if rot else "NICHT ROT ") + m + (" — " + "; ".join(welche[:3]) if welche else ""))
        print(str(sum(1 for _, r, _ in aus if r)) + " von " + str(len(aus)) + " Mutationen rot (" + _de(time.time() - t0, 0) + " s)")
        return 0 if aus and aus[0][0] != "(ohne Mutation)" and all(r for _, r, _ in aus) else 1
    if a.nachweisgrenze:
        print(nachweisgrenze())
        return 0
    if not a.db:
        ap.error("--db fehlt (Pfad der Hauptdatenbank)")
    p = pfad(a.db)
    q = quellen(a.db)
    if a.nutzlast:
        print(payload_json(p, a.nutzlast, a.coin).decode())
        return 0
    if a.stand and not (a.erstlauf or a.rueckblick is not None or a.tageslauf or a.auswertung or a.dienst):
        con = lesen(p)
        if con is None:
            print("★ Volatilität: Stand (U237)\nvolatil.db fehlt noch – der Dienst legt sie rund 90 s nach dem Start des Dashboards an "
                  "(aus mit HL_VOL=0).")
            return 0
        try:
            print(bericht_stand(con))
        finally:
            con.close()
        return 0
    con = verbinden(p)
    if a.dienst:
        t0 = time.time()
        try:
            erl = dienst_lauf(con, q)
            print(f"[{time.strftime('%d.%m. %H:%M:%S')}] fertig: {', '.join(erl) or 'nichts fällig'} ({time.time() - t0:.0f} s)",
                  flush=True)
        except Exception as e:  # noqa: BLE001
            print(f"[{time.strftime('%d.%m. %H:%M:%S')}] Fehler: {type(e).__name__}: {e}", flush=True)
            return 1
    if a.erstlauf:
        print(erstlauf(con, q))
    if a.rueckblick is not None:
        rb = Rueckblick(con)
        n = 0
        while rb.schritt() and (a.rueckblick == 0 or n + 1 < a.rueckblick):
            n += 1
        print("Rückblick: " + json.dumps(meta(con, "rb", {}), ensure_ascii=False)[:400])
    if a.tageslauf:
        print(json.dumps(_ohne_nan(tageslauf(con, q)), ensure_ascii=False, default=str)[:2000])
    if a.auswertung:
        auswerten(con, q)
        print(bericht_auswertung(con))
    if a.stand:
        print(bericht_stand(con))
    return 0


if __name__ == "__main__":
    sys.exit(main())
