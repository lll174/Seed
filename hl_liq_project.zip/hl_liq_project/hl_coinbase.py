#!/usr/bin/env python3
"""
Coinbase-Spot-Aufzeichnung — der US-regulierte Spotmarkt als eigene Quelle.

Warum überhaupt: Hyperliquid und Binance sind Perp-Märkte mit Hebel; die Nachfrage aus
den USA zeigt sich zuerst im Spot. Die Differenz zwischen dem Coinbase-Spotpreis und
dem Perp-Kurs — die Coinbase-Prämie — gilt als Anzeiger dafür, ob US-Adressen kaufen
oder verkaufen. Dazu kommen Taker-Flow und Orderbuch-Tiefe eines Marktes, der ohne
Hebel auskommt: Was dort gekauft wird, muss bezahlt werden.

Quellen (beide ohne Schlüssel, Grenze 10 Anfragen/s je IP):
  * WebSocket wss://ws-feed.exchange.coinbase.com, Kanal "ticker"
    liefert bei jedem Handel Preis, Menge, Seite UND das beste Gebot/Angebot mit Mengen.
  * REST /products/{id}/book?level=2 alle 30 s: Tiefe je Preisstufe, daraus Wände.
  * REST /products/{id}/candles?granularity=60 beim Start und alle 15 min: Lücken füllen.

WICHTIG — Vorzeichen: Bei Coinbase bezeichnet das Feld "side" die Seite des MAKERS.
"side": "sell" heißt, eine ruhende Verkaufsorder wurde getroffen, der Taker hat also
GEKAUFT. Das ist genau umgekehrt zu Binance und Hyperliquid. Ein Vorzeichenfehler
an dieser Stelle würde jedes Flow-Signal umdrehen.

  python3 hl_coinbase.py --db hl_liq.db --coins BTC ETH SOL
  python3 hl_coinbase.py --selftest        # ohne Netz: Rechenwege prüfen
  python3 hl_coinbase.py --status --db ...
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sqlite3
import sys
import time
from pathlib import Path

WS_URL = "wss://ws-feed.exchange.coinbase.com"
REST = "https://api.exchange.coinbase.com"

SCHEMA = """
PRAGMA journal_mode=WAL;
-- Eine Minute Coinbase-Spot je Coin. buy_usd/sell_usd sind TAKER-Seiten in USD:
-- buy_usd = aggressiv gekauft, sell_usd = aggressiv verkauft.
CREATE TABLE IF NOT EXISTS cb_bars (
    ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL,
    volume REAL, trades INTEGER, buy_usd REAL, sell_usd REAL,
    PRIMARY KEY (ts, coin)
);
CREATE INDEX IF NOT EXISTS ix_cb_bars_coin_ts ON cb_bars(coin, ts);
-- Orderbuch-Zusammenfassung alle 30 s: bestes Gebot/Angebot und die Tiefe in USD
-- innerhalb von 5, 25 und 100 Basispunkten um die Mitte. walls = größte ruhende
-- Orders als JSON [{side, px, usd}, ...].
CREATE TABLE IF NOT EXISTS cb_book (
    ts INTEGER, coin TEXT, bid REAL, bid_sz REAL, ask REAL, ask_sz REAL,
    bid5 REAL, ask5 REAL, bid25 REAL, ask25 REAL, bid100 REAL, ask100 REAL,
    walls TEXT,
    PRIMARY KEY (ts, coin)
);
CREATE INDEX IF NOT EXISTS ix_cb_book_coin_ts ON cb_book(coin, ts);
CREATE TABLE IF NOT EXISTS cb_meta (k TEXT PRIMARY KEY, v TEXT);
"""

BARS_DAYS = 180         # 1-min-Bars so lange halten (Audit v3 S7: Prämien-/Spot-Flow-Reihen für Wochenhorizonte; 1-min-Spot ist klein)
BOOK_DAYS = 14


# ---------------------------------------------------------------------------
# Rechenwege — bewusst als freie Funktionen, damit sie ohne Netz prüfbar sind
# ---------------------------------------------------------------------------

def taker_side(maker_side: str) -> str:
    """
    Coinbase liefert die MAKER-Seite. Der Taker handelt entgegengesetzt:
    maker sell  -> Taker hat gekauft (Aufwärts-Tick)
    maker buy   -> Taker hat verkauft (Abwärts-Tick)
    """
    s = str(maker_side or "").lower()
    if s == "sell":
        return "buy"
    if s == "buy":
        return "sell"
    return ""


def book_depth(bids: list, asks: list, bps: tuple = (5, 25, 100)) -> dict:
    """
    Tiefe in USD innerhalb mehrerer Basispunkt-Abstände um die Buchmitte.

    bids/asks sind Listen von [Preis, Menge, Anzahl Orders] -- Coinbase liefert auf
    Stufe 2 DREI Werte je Zeile, nicht zwei. Deshalb wird nur auf die ersten beiden
    zugegriffen. Die Mitte ist der Mittelwert aus bestem Gebot und bestem Angebot,
    nicht der letzte Handelspreis; der kann danebenliegen.
    """
    if not bids or not asks:
        return {}
    best_bid = float(bids[0][0]); best_ask = float(asks[0][0])
    mid = (best_bid + best_ask) / 2
    if mid <= 0:
        return {}
    out = {"bid": best_bid, "ask": best_ask, "mid": mid,
           "bid_sz": float(bids[0][1]), "ask_sz": float(asks[0][1])}
    for b in bps:
        grenze_b = mid * (1 - b / 10_000)
        grenze_a = mid * (1 + b / 10_000)
        out[f"bid{b}"] = sum(float(z[0]) * float(z[1]) for z in bids if float(z[0]) >= grenze_b)
        out[f"ask{b}"] = sum(float(z[0]) * float(z[1]) for z in asks if float(z[0]) <= grenze_a)
    return out


def find_walls(bids: list, asks: list, mid: float, min_usd: float, max_n: int = 6) -> list:
    """Größte ruhende Orders innerhalb von 2 % um die Mitte -- Widerstand und Unterstützung."""
    walls = []
    for seite, buch in (("bid", bids), ("ask", asks)):
        for zeile in buch:
            p = float(zeile[0]); usd = p * float(zeile[1])
            if usd >= min_usd and abs(p / mid - 1) <= 0.02:
                walls.append({"side": seite, "px": p, "usd": usd})
    walls.sort(key=lambda w: -w["usd"])
    return walls[:max_n]


def premium_bps(spot: float, perp: float) -> float | None:
    """
    Coinbase-Prämie in Basispunkten: positiv = Spot teurer als der Perp-Kurs,
    also zahlt jemand in den USA einen Aufschlag für echte Ware.
    """
    if not spot or not perp or perp <= 0:
        return None
    return (spot / perp - 1) * 10_000


def zscore(wert: float, reihe: list) -> float | None:
    """Z-Wert gegen die eigene Verteilung; unter 20 Werten sinnlos."""
    reihe = [x for x in reihe if x is not None]
    if len(reihe) < 20:
        return None
    m = sum(reihe) / len(reihe)
    sd = (sum((x - m) ** 2 for x in reihe) / max(1, len(reihe) - 1)) ** 0.5
    return (wert - m) / sd if sd > 0 else 0.0


# ---------------------------------------------------------------------------

def db_connect(path: str) -> sqlite3.Connection:
    import hl_dbcoord
    con = sqlite3.connect(path, timeout=30, isolation_level=None, factory=hl_dbcoord.KoordinierteVerbindung)
    con.koordination(path, "coinbase")                    # prozessübergreifende Schreibsperre je Statement (Autocommit)
    # Kürzer als der WebSocket-Heartbeat (20 s): Ein Schreibzugriff, der 60 s auf eine Sperre
    # wartet, hält die Ereignisschleife an, der Heartbeat bleibt aus, die Verbindung fällt --
    # Reconnect-Flattern (Re-Audit N6). Bei Sperre wird der Datenpunkt übersprungen und gezählt.
    con.execute("PRAGMA busy_timeout=5000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA temp_store=MEMORY")
    con.executescript(SCHEMA)
    return con


class Coinbase:
    def __init__(self, con: sqlite3.Connection, coins: list[str], flush_sec: int = 30,
                 book_sec: int = 30, candle_sec: int = 900):
        self.con = con
        self.coins = coins
        self.flush_sec = flush_sec
        self.book_sec = book_sec
        self.candle_sec = candle_sec
        self.produkt: dict = {}          # coin -> product_id ("BTC" -> "BTC-USD")
        self.bars: dict = {}             # (minute, coin) -> dict
        self.stop = asyncio.Event()
        self.stats = {"ticks": 0, "bars": 0, "books": 0, "reconnects": 0, "errors": 0, "db_locked": 0}
        self.jobs: dict = {}
        self.session = None

    # -- Hilfen -------------------------------------------------------------
    def note(self, name: str, takt: float | None = None, info: str = "", ok: bool = True) -> None:
        j = self.jobs.setdefault(name, {})
        j["last"] = int(time.time())
        if takt:
            j["next"] = int(time.time() + takt); j["takt"] = int(takt)
        if info:
            j["info"] = info[:120]
        j["ok"] = ok

    def meta(self, k: str, v) -> None:
        self.con.execute("INSERT OR REPLACE INTO cb_meta VALUES (?,?)", (k, str(v)))

    async def get(self, pfad: str, timeout: int = 20):
        import aiohttp
        for versuch in range(3):
            try:
                async with self.session.get(REST + pfad, timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                    if r.status == 429:
                        await asyncio.sleep(2 + versuch * 3)
                        continue
                    if r.status >= 400:
                        return None
                    return await r.json()
            except Exception:
                await asyncio.sleep(1 + versuch)
        self.stats["errors"] += 1
        return None

    # -- Produkte auflösen --------------------------------------------------
    async def resolve(self) -> None:
        """
        Welche unserer Coins handelt Coinbase gegen USD? Coins ohne Paar fallen still
        heraus -- HYPE etwa ist dort nicht gelistet, das darf den Dienst nicht aufhalten.
        """
        data = await self.get("/products")
        vorhanden: dict = {}
        if isinstance(data, list):
            for p in data:
                pid = str(p.get("id") or "")
                if p.get("status") == "online" and not p.get("trading_disabled"):
                    vorhanden[pid] = p

        # Nicht blind das USD-Paar nehmen. Coinbase führt viele Coins zusätzlich gegen
        # USDC, und bei kleineren Märkten liegt dort mitunter der größere Teil des
        # Umsatzes -- wer stur USD wählt, misst dann den Nebenschauplatz und hält das
        # Ergebnis für den ganzen Markt. Entschieden wird nach dem tatsächlichen
        # 24-Stunden-Volumen in Basiseinheiten, das ist zwischen den Paaren vergleichbar.
        QUOTES = ("USD", "USDC")
        gewaehlt: dict = {}
        for c in self.coins:
            kandidaten = [f"{c}-{q}" for q in QUOTES if f"{c}-{q}" in vorhanden]
            if not kandidaten:
                continue
            if len(kandidaten) == 1:
                gewaehlt[c] = (kandidaten[0], None, None)
                continue
            mengen = {}
            for pid in kandidaten:
                st = await self.get(f"/products/{pid}/stats")
                try:
                    mengen[pid] = float((st or {}).get("volume") or 0)
                except (TypeError, ValueError):
                    mengen[pid] = 0.0
                await asyncio.sleep(0.2)
            best = max(mengen, key=lambda k: mengen[k])
            rest = sorted((v for k, v in mengen.items() if k != best), reverse=True)
            gewaehlt[c] = (best, mengen[best], rest[0] if rest else None)

        for c, (pid, v_best, v_rest) in gewaehlt.items():
            self.produkt[c] = pid
        fehlend = [c for c in self.coins if c not in self.produkt]

        print(f"  Coinbase: {len(self.produkt)} Paare aktiv"
              + (f" · nicht gelistet: {', '.join(fehlend)}" if fehlend else ""))
        for c, (pid, v_best, v_rest) in sorted(gewaehlt.items()):
            if v_best is None:
                print(f"    {c:<6} {pid:<12} (einziges Paar)")
            else:
                anteil = v_best / (v_best + (v_rest or 0)) * 100 if (v_best + (v_rest or 0)) > 0 else 0
                print(f"    {c:<6} {pid:<12} gewählt · 24-h-Volumen {v_best:,.0f} gegen {v_rest or 0:,.0f} "
                      f"beim anderen Paar ({anteil:.0f} % des Umsatzes)")
        self.meta("paarwahl", json.dumps({c: {"pid": p, "vol": v, "vol_alt": r}
                                          for c, (p, v, r) in gewaehlt.items()})[:1500])
        self.meta("products", ",".join(self.produkt.values()))
        self.meta("coins", ",".join(self.produkt.keys()))
        self.meta("fehlend", ",".join(fehlend))

    # -- WebSocket ----------------------------------------------------------
    def on_ticker(self, m: dict) -> None:
        """
        Eine Ticker-Nachricht: entsteht bei jedem Handel und enthält zugleich die Spitze
        des Buches. Daraus wird die Minutenkerze aufgebaut.
        """
        pid = str(m.get("product_id") or "")
        coin = pid.split("-")[0]
        if coin not in self.produkt:
            return
        try:
            px = float(m.get("price") or 0)
            sz = float(m.get("last_size") or 0)
        except (TypeError, ValueError):
            return
        if px <= 0:
            return
        ts = int(time.time())
        # Nachrichtenzeit statt lokaler Uhr, wenn vorhanden (Re-Audit N9): Bei Rückstau der
        # Verarbeitung landen Trades sonst in der falschen Minute.
        t_msg = m.get("time")
        if isinstance(t_msg, str):
            try:
                from datetime import datetime, timezone
                dt = datetime.fromisoformat(t_msg.replace("Z", "+00:00"))
                t_iso = int(dt.timestamp())
                if abs(t_iso - ts) < 600:                 # nur bei plausibler Uhr des Absenders
                    ts = t_iso
            except (ValueError, TypeError):
                pass
        minute = ts // 60 * 60
        b = self.bars.get((minute, coin))
        if b is None:
            b = self.bars[(minute, coin)] = {"o": px, "h": px, "l": px, "c": px,
                                             "v": 0.0, "n": 0, "buy": 0.0, "sell": 0.0}
        b["h"] = max(b["h"], px); b["l"] = min(b["l"], px); b["c"] = px
        if sz > 0:
            b["v"] += sz; b["n"] += 1
            seite = taker_side(m.get("side"))
            if seite == "buy":
                b["buy"] += px * sz
            elif seite == "sell":
                b["sell"] += px * sz
        self.stats["ticks"] += 1
        self.note("Coinbase-Feed")

    def flush_bars(self, final: bool = False) -> None:
        cur = int(time.time()) // 60 * 60
        fertig = [k for k in self.bars if final or k[0] < cur]
        if not fertig:
            return
        rows = []
        for k in fertig:
            b = self.bars.pop(k)
            rows.append((k[0], k[1], b["o"], b["h"], b["l"], b["c"], b["v"], b["n"], b["buy"], b["sell"]))
        if self.schreibe("INSERT OR REPLACE INTO cb_bars VALUES (?,?,?,?,?,?,?,?,?,?)", rows, viele=True):
            self.stats["bars"] += len(rows)

    def schreibe(self, sql: str, args=(), viele: bool = False) -> bool:
        """Schreiben mit Sperr-Toleranz: bei 'database is locked' zählen und weiterlaufen."""
        try:
            (self.con.executemany if viele else self.con.execute)(sql, args)
            return True
        except sqlite3.OperationalError as e:
            if "locked" in str(e) or "busy" in str(e):
                self.stats["db_locked"] += 1
                return False
            raise

    async def run_ws(self) -> None:
        import aiohttp
        wartezeit = 1
        # aiohttp >= 3.10 erwartet ein Timeout-Objekt statt einer Zahl (Re-Audit N8)
        tmo = aiohttp.ClientWSTimeout(ws_close=20.0) if hasattr(aiohttp, "ClientWSTimeout") else 20
        while not self.stop.is_set():
            try:
                async with self.session.ws_connect(WS_URL, heartbeat=20, timeout=tmo) as ws:
                    await ws.send_json({"type": "subscribe",
                                        "product_ids": list(self.produkt.values()),
                                        "channels": ["ticker"]})
                    verbunden_seit = time.time()
                    print(f"  Coinbase: Feed verbunden ({len(self.produkt)} Paare)", flush=True)
                    # Audit v3 L5: Empfangs-Timeout -- eine stille Verbindung, die nur Pongs beantwortet,
                    # hing sonst unbegrenzt. 120 s ohne Ticker heißt: neu verbinden.
                    while True:
                        try:
                            msg = await asyncio.wait_for(ws.receive(), timeout=120)
                        except asyncio.TimeoutError:
                            print("  Coinbase: 120 s ohne Nachricht -- neu verbinden", flush=True)
                            break
                        if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING, aiohttp.WSMsgType.ERROR):
                            break
                        if self.stop.is_set():
                            break
                        # Backoff erst nach einer stabilen Minute zurücksetzen, nicht beim Verbinden --
                        # sonst flattert eine sofort abbrechende Verbindung im Sekundentakt (Re-Audit N7)
                        if wartezeit > 1 and time.time() - verbunden_seit > 60:
                            wartezeit = 1
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            continue
                        try:
                            d = json.loads(msg.data)
                        except ValueError:
                            continue
                        if d.get("type") == "ticker":
                            self.on_ticker(d)
                        elif d.get("type") == "error":
                            print(f"  Coinbase-Feed meldet: {d.get('message')}", flush=True)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                if self.stop.is_set():
                    return
                self.stats["reconnects"] += 1
                print(f"  Coinbase-Feed getrennt ({type(e).__name__}), neu in {wartezeit} s", flush=True)
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=wartezeit)
                return
            except asyncio.TimeoutError:
                pass
            wartezeit = min(wartezeit * 2, 60)

    # -- Orderbuch ----------------------------------------------------------
    async def run_book(self) -> None:
        await asyncio.sleep(5)
        while not self.stop.is_set():
            t0 = time.time()
            for coin, pid in self.produkt.items():
                if self.stop.is_set():
                    return
                data = await self.get(f"/products/{pid}/book?level=2")
                if not isinstance(data, dict):
                    continue
                bids = data.get("bids") or []; asks = data.get("asks") or []
                d = book_depth(bids, asks)
                if not d:
                    continue
                # Mindestgröße für eine Wand: zwei Prozent der Tiefe innerhalb 100 bps,
                # mindestens 100.000 USD -- so passt sich die Schwelle dem Markt an.
                min_wand = max(100_000.0, (d.get("bid100", 0) + d.get("ask100", 0)) * 0.02)
                walls = find_walls(bids, asks, d["mid"], min_wand)
                self.schreibe("INSERT OR REPLACE INTO cb_book VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                 (int(time.time()), coin, d["bid"], d["bid_sz"], d["ask"], d["ask_sz"],
                                  d.get("bid5", 0), d.get("ask5", 0), d.get("bid25", 0), d.get("ask25", 0),
                                  d.get("bid100", 0), d.get("ask100", 0), json.dumps(walls)))
                self.stats["books"] += 1
                await asyncio.sleep(0.3)
            self.note("Coinbase-Orderbuch", takt=self.book_sec, info=f"{len(self.produkt)} Paare",
                      ok=True)
            rest = self.book_sec - (time.time() - t0)
            if rest > 0:
                try:
                    await asyncio.wait_for(self.stop.wait(), timeout=rest)
                    return
                except asyncio.TimeoutError:
                    pass

    # -- Kerzen nachziehen --------------------------------------------------
    async def run_candles(self) -> None:
        """
        Minutenkerzen der letzten Stunden von der REST-Schnittstelle. Zweck: Lücken nach
        einem Neustart oder einer Feed-Unterbrechung füllen. Die Kerzen haben kein
        Taker-Volumen -- buy_usd/sell_usd bleiben dort leer, deshalb überschreiben sie
        niemals eine aus dem Feed gebaute Kerze.
        """
        while not self.stop.is_set():
            for coin, pid in self.produkt.items():
                if self.stop.is_set():
                    return
                data = await self.get(f"/products/{pid}/candles?granularity=60")
                if not isinstance(data, list):
                    continue
                rows = []
                for k in data:
                    try:
                        ts, lo, hi, op, cl, vol = (int(k[0]), float(k[1]), float(k[2]),
                                                   float(k[3]), float(k[4]), float(k[5]))
                    except (TypeError, ValueError, IndexError):
                        continue
                    rows.append((ts, coin, op, hi, lo, cl, vol, 0, 0.0, 0.0))
                if rows:
                    # OR IGNORE: eine vorhandene Kerze aus dem Feed ist reicher
                    self.con.executemany("INSERT OR IGNORE INTO cb_bars VALUES (?,?,?,?,?,?,?,?,?,?)", rows)
                await asyncio.sleep(0.4)
            self.note("Coinbase-Kerzen", takt=self.candle_sec, info=f"{len(self.produkt)} Paare je Lauf")
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=self.candle_sec)
                return
            except asyncio.TimeoutError:
                pass

    # -- Schreiben und Aufräumen -------------------------------------------
    async def run_flush(self) -> None:
        letzte_pflege = time.time()
        while not self.stop.is_set():
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=self.flush_sec)
                break
            except asyncio.TimeoutError:
                pass
            try:
                self.flush_bars()
                self.meta("alive", int(time.time()))
                self.meta("stats", json.dumps(self.stats))
                self.meta("jobs", json.dumps(self.jobs))
                if time.time() - letzte_pflege > 3600:
                    now = int(time.time())
                    self.con.execute("DELETE FROM cb_bars WHERE ts < ?", (now - BARS_DAYS * 86_400,))
                    self.con.execute("DELETE FROM cb_book WHERE ts < ?", (now - BOOK_DAYS * 86_400,))
                    letzte_pflege = time.time()
            except sqlite3.Error as e:
                self.stats["errors"] += 1
                print(f"  Coinbase: Schreibfehler {e}", flush=True)

    async def run(self) -> None:
        import aiohttp
        async with aiohttp.ClientSession() as sess:
            self.session = sess
            await self.resolve()
            if not self.produkt:
                print("  Coinbase: kein Paar aktiv — Dienst beendet sich.")
                return
            aufgaben = [asyncio.create_task(self.bewache(n, f)) for n, f in
                        (("Feed", self.run_ws), ("Orderbuch", self.run_book),
                         ("Kerzen", self.run_candles), ("Schreiben", self.run_flush))]
            await self.stop.wait()
            for t in aufgaben:
                t.cancel()
            await asyncio.gather(*aufgaben, return_exceptions=True)
        self.flush_bars(final=True)
        print("\nCoinbase sauber beendet.")

    async def bewache(self, name: str, factory) -> None:
        """Wie im Recorder: ein Absturz wird gemeldet und die Aufgabe neu gestartet."""
        wartezeit = 5
        while not self.stop.is_set():
            try:
                await factory()
                if not self.stop.is_set():
                    print(f"  Coinbase-Aufgabe {name}: unerwartet beendet, Neustart in {wartezeit} s", flush=True)
                else:
                    return
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.stats["errors"] += 1
                self.note(f"Coinbase-{name}", info=f"{type(e).__name__}: {e}", ok=False)
                print(f"  Coinbase-Aufgabe {name} ABGESTÜRZT: {type(e).__name__}: {e} — "
                      f"Neustart in {wartezeit} s", flush=True)
            try:
                await asyncio.wait_for(self.stop.wait(), timeout=wartezeit)
                return
            except asyncio.TimeoutError:
                pass
            wartezeit = min(wartezeit * 2, 300)


# ---------------------------------------------------------------------------

def selftest() -> int:
    fehler = []

    def pruefe(name, bedingung, zusatz=""):
        print(f"  [{'ok' if bedingung else 'FEHLER'}] {name}{' · ' + zusatz if zusatz else ''}")
        if not bedingung:
            fehler.append(name)

    print("Coinbase-Selbsttest (ohne Netz)")
    # 1. Maker/Taker
    pruefe("maker sell  -> Taker kauft", taker_side("sell") == "buy")
    pruefe("maker buy   -> Taker verkauft", taker_side("buy") == "sell")
    pruefe("unbekannt   -> leer", taker_side("") == "" and taker_side(None) == "")

    # 2. Tiefe
    # Coinbase liefert [Preis, Menge, Anzahl Orders] -- die dritte Spalte muss folgenlos bleiben
    bids = [["100.0", "1", 3], ["99.95", "2", 1], ["99.0", "10", 7], ["90.0", "100", 2]]
    asks = [["100.1", "1", 2], ["100.15", "2", 4], ["101.0", "10", 1], ["110.0", "100", 9]]
    d = book_depth(bids, asks)
    mid = 100.05
    pruefe("Mitte", abs(d["mid"] - mid) < 1e-9, f"{d['mid']}")
    # 5 bps = 0.05 % -> Grenze bei 100.0 / 100.1
    pruefe("Tiefe 5 bps Gebot", abs(d["bid5"] - 100.0 * 1) < 1e-6, f"{d['bid5']:.2f}")
    pruefe("Tiefe 5 bps Angebot", abs(d["ask5"] - 100.1 * 1) < 1e-6, f"{d['ask5']:.2f}")
    # 25 bps -> 99.80 / 100.30: zusätzlich 99.95 bzw. 100.15
    pruefe("Tiefe 25 bps Gebot", abs(d["bid25"] - (100.0 + 99.95 * 2)) < 1e-6, f"{d['bid25']:.2f}")
    pruefe("Tiefe 100 bps Angebot", abs(d["ask100"] - (100.1 + 100.15 * 2 + 101.0 * 10)) < 1e-6, f"{d['ask100']:.2f}")
    pruefe("leeres Buch ergibt leeres Ergebnis", book_depth([], []) == {})
    pruefe("zweispaltige Form geht auch",
           abs(book_depth([("100.0", "1")], [("100.1", "1")])["mid"] - 100.05) < 1e-9)

    # 3. Wände
    w = find_walls(bids, asks, mid, min_usd=500)
    pruefe("Wände nur innerhalb 2 %", all(abs(x["px"] / mid - 1) <= 0.02 for x in w), f"{len(w)} gefunden")
    pruefe("Wände absteigend", all(w[i]["usd"] >= w[i + 1]["usd"] for i in range(len(w) - 1)))
    pruefe("Wand unter der Schwelle fehlt", not any(x["usd"] < 500 for x in w))

    # 4. Prämie
    pruefe("Prämie positiv, wenn Spot teurer", round(premium_bps(100.5, 100.0), 4) == 50.0,
           f"{premium_bps(100.5, 100.0):.1f} bps")
    pruefe("Prämie negativ, wenn Spot billiger", premium_bps(99.5, 100.0) < 0)
    pruefe("Prämie ohne Kurs ist None", premium_bps(0, 100) is None and premium_bps(100, 0) is None)

    # 5. Z-Wert
    pruefe("Z-Wert unter 20 Werten ist None", zscore(5, [1, 2, 3]) is None)
    reihe = [0] * 30
    pruefe("Z-Wert ohne Streuung ist 0", zscore(5, reihe) == 0.0)
    reihe = list(range(30))
    z = zscore(40, reihe)
    pruefe("Z-Wert über dem Mittel positiv", z and z > 2, f"{z:.2f}")

    # 6. Kerzenaufbau mit Taker-Seiten
    con = db_connect(":memory:")
    cb = Coinbase(con, ["BTC"]); cb.produkt = {"BTC": "BTC-USD"}
    for seite, sz in (("sell", 1.0), ("sell", 0.5), ("buy", 2.0)):     # Maker-Seite!
        cb.on_ticker({"product_id": "BTC-USD", "price": "100", "last_size": str(sz), "side": seite})
    cb.flush_bars(final=True)
    r = con.execute("SELECT volume, trades, buy_usd, sell_usd FROM cb_bars").fetchone()
    pruefe("Kerze: Volumen", abs(r[0] - 3.5) < 1e-9, f"{r[0]}")
    pruefe("Kerze: drei Trades", r[1] == 3)
    pruefe("Kerze: Taker-Käufe 150 USD", abs(r[2] - 150.0) < 1e-9, f"{r[2]}")
    pruefe("Kerze: Taker-Verkäufe 200 USD", abs(r[3] - 200.0) < 1e-9, f"{r[3]}")
    # unbekannter Coin wird ignoriert
    cb.on_ticker({"product_id": "DOGE-USD", "price": "1", "last_size": "1", "side": "buy"})
    pruefe("fremdes Paar wird ignoriert", not cb.bars)
    con.close()

    print(f"\n{'Alles in Ordnung.' if not fehler else 'FEHLER: ' + ', '.join(fehler)}")
    return 1 if fehler else 0


def status(db: str) -> int:
    if not os.path.exists(db):
        print(f"Datenbank fehlt: {db}")
        return 1
    con = db_connect(db); con.row_factory = sqlite3.Row
    now = int(time.time())
    try:
        meta = dict(con.execute("SELECT k, v FROM cb_meta"))
    except sqlite3.Error:
        meta = {}
    alive = int(meta.get("alive") or 0)
    print(f"Coinbase — Lebenszeichen {'vor ' + str((now - alive) // 60) + ' min' if alive else 'FEHLT'}")
    try:
        wahl = json.loads(meta.get("paarwahl") or "{}")
    except ValueError:
        wahl = {}
    if wahl:
        print("  Paarwahl (nach 24-h-Volumen in Basiseinheiten):")
        for c, d in sorted(wahl.items()):
            alt = d.get("vol_alt")
            print(f"    {c:<6} {d['pid']:<12}"
                  + (f" · {d['vol']:,.0f} gegen {alt:,.0f} beim anderen Paar" if d.get("vol") and alt is not None
                     else " · einziges Paar"))
    if meta.get("fehlend"):
        print(f"  Dort nicht gelistet: {meta['fehlend']}")
    print(f"  Zähler: {meta.get('stats', '—')}")
    for tab, label in (("cb_bars", "Minutenkerzen"), ("cb_book", "Buch-Stände")):
        try:
            n, letzte = con.execute(f"SELECT COUNT(*), MAX(ts) FROM {tab}").fetchone()
            print(f"  {label:<16} {n:>8,} · letzter vor {(now - (letzte or now)) // 60} min")
        except sqlite3.Error:
            print(f"  {label:<16} Tabelle fehlt")
    for r in con.execute("""SELECT coin, COUNT(*) n, ROUND(SUM(buy_usd)/1e6,1) b, ROUND(SUM(sell_usd)/1e6,1) s
                            FROM cb_bars WHERE ts > ? GROUP BY coin ORDER BY n DESC""", (now - 3600,)):
        print(f"    {r['coin']:<6} {r['n']:>4} Kerzen in 1 h · Taker-Käufe {r['b']} Mio · Verkäufe {r['s']} Mio")
    con.close()
    return 0


def main() -> None:
    p = argparse.ArgumentParser(description="Coinbase-Spot-Aufzeichnung")
    p.add_argument("--db", default=str(Path(__file__).resolve().parent / "hl_liq.db"))
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"],
                   help="Projektliste wie in install.py; nicht gelistete Paare werden gemeldet und ausgelassen")
    p.add_argument("--book-sec", type=int, default=30)
    p.add_argument("--candle-sec", type=int, default=900)
    p.add_argument("--selftest", action="store_true")
    p.add_argument("--status", action="store_true")
    a = p.parse_args()

    if a.selftest:
        sys.exit(selftest())
    if a.status:
        sys.exit(status(a.db))

    con = db_connect(a.db)
    cb = Coinbase(con, [c.upper() for c in a.coins], book_sec=a.book_sec, candle_sec=a.candle_sec)

    import signal
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, cb.stop.set)
        except NotImplementedError:
            pass
    try:
        loop.run_until_complete(cb.run())
    finally:
        con.close()


if __name__ == "__main__":
    main()
