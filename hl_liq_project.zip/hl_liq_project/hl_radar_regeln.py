#!/usr/bin/env python3
"""
hl_radar_regeln.py -- Risikoradar: Prüfung der Regeln R1 bis R7 (U308, KONZEPT_Risikoradar.md Abschnitt 5; Debug 163)

Kündigt eines von sieben vorab festgelegten Zeichen einen Rücksetzer an -- über das hinaus, was die Schwankung des Tages ohnehin sagt?
Geprüft wird auf den Tagesreihen der Hebel-Studie (hebel.db, swing.db, makro.db; nur lesen) für BTC und ETH zusammen, getrennt für die
zwei Ereignisse des Radars: Tief der nächsten 7 Tage 10 % · Faktor unter dem Schluss (E7) und Tief der nächsten 2 Tage 7 % · Faktor
darunter (E2). Maß ist das Risikoverhältnis nach Mantel-Haenszel über die Zehntel der Schwankung je Coin; Null ist die zirkuläre
Verschiebung des Signals um 30 bis 365 Tage (672 Verschiebungen); Holm je Ereignis über die prüfbaren Regeln; beide Kalenderhälften.
Der erste Lauf mit vollständiger Historie legt das Urteil in radar.db ab, spätere zeigen es. ZEC, XMR und HYPE stehen beschreibend da.

Eine belegte Regel ist ein Kandidat für einen Aufschlag auf die Prozentzahl (Paket 2, nur nach eigener Entscheidung des Nutzers); eine
nicht belegte bleibt Messwert. Dieses Modul ändert keine Zahl der Karte.

Aufrufe:
  python3 hl_radar_regeln.py --text --db hl_liq.db        Bericht (Debug 163); rechnet, wenn noch kein Urteil abgelegt ist
  python3 hl_radar_regeln.py --selbsttest                 ohne Netz, ohne Datenbank
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import sys
import time

import numpy as np

VERSION_MODUL = "2026-09-23.128"                  # 23.128: gleich wie hl_radar (Probe VP5); inhaltlich unverändert
FASSUNG = 1                                   # Fassung der Regeln; ein abgelegtes Urteil einer anderen Fassung wird neu gerechnet
TAG = 86_400
COINS_URTEIL = ("BTC", "ETH")                 # gepoolt im Urteil
COINS_BESCHR = ("ZEC", "XMR", "HYPE")         # nur beschreibend
EREIGNISSE = (("e7", 7, 0.10, "−10 % · Faktor in 7 Tagen"), ("e2", 2, 0.07, "−7 % · Faktor in 48 Stunden"))
REGELN = (("r1", "R1", "Kontenquote", "Kontenquote Binance ≥ 3"),
          ("r2", "R2", "Hebel-Aufbau im Stillstand",
           "Open Interest in 7 Tagen im obersten Zehntel der 365 Tage davor gewachsen, Kurs in 7 Tagen höchstens ½ σ·√7 bewegt"),
          ("r3", "R3", "Funding-Niveau", "Funding Binance, Mittel der letzten 7 Tage, auf ein Jahr gerechnet ≥ 15 %"),
          ("r4", "R4", "Spot trägt nicht", "Kurs in 7 Tagen gestiegen, Spot-Taker-Saldo über 7 Tage unter 0, Perp-Taker-Saldo über 0"),
          ("r5", "R5", "OI-Überhitzung", "Open Interest im Perzentil ≥ 0,90 der 90 Tage davor"),
          ("r6", "R6", "Termin", "am Folgetag Verbraucherpreise, Arbeitsmarktbericht oder Fed-Entscheid"),
          ("r7", "R7", "Druck-Index", "Druck-Index auf Tagesschlüssen im obersten Zehntel der 365 Tage davor"))
KONTEN_SCHWELLE = 3.0                         # R1
R2_PZ = 0.90                                  # R2: Zuwachs des Open Interest im obersten Zehntel
R2_STILL = 0.5                                # R2: |Kursänderung über 7 Tage| ≤ 0,5 · σ_d · √7
R3_FUNDING = 0.15                             # R3: 15 % im Jahr
R5_PZ = 0.90                                  # R5
R7_PZ = 0.90                                  # R7
PZ_KURZ = (90, 60)                            # Perzentil gegen 90 Tage davor, mindestens 60 (A1, A2, R5 -- wie Cockpit und U141)
PZ_LANG = (365, 180)                          # Perzentil gegen 365 Tage davor, mindestens 180 (A3, A4, A7, R2, R7)
ZEHNTEL = 10                                  # Schichten der Schwankung je Coin
MIN_SIGNALTAGE, MIN_EPISODEN, MIN_OHNE = 30, 5, 30
N_BOOT = 1000
BLOCK = 60
ALPHA = 0.05
SAAT = 308
ZEILE_MAX = 150
DEBUG_NR, DEBUG_NR_TEST = 163, 164            # Debug-Läufe radar_regeln und radar_regeln_test (hl_viz)
# Nachweisgrenze: vor dem ersten echten Lauf auf erfundenen Märkten gemessen (nachweis(), nur in der Probe; 24.11.2026 08:55 bis 09:17,
# 7 Fälle je 200 Märkte, Saaten 5000 ff.; die Aufschlüsselung zu R7 auf den ersten 80 Märkten des Falls „häufig, q 0,10“)
NACHWEIS_MESSUNG = {"datum": "24.11.2026", "welten": 200, "tage": 2520,
                    "ohne": {"e7": 0.06, "e2": 0.07},
                    "haeufig": {"signaltage": 430, "faelle": ((1.8, 1.8, 0.495, 0.445), (2.7, 2.8, 0.94, 0.96), (3.4, 3.8, 1.0, 0.995))},
                    "selten": {"signaltage": 100, "faelle": ((1.8, 1.7, 0.16, 0.135), (2.6, 2.6, 0.375, 0.415), (3.3, 3.7, 0.65, 0.675))},
                    "r7_mit": {"welten": 80, "e7": 14, "e2": 7}}
NACHWEIS_GRENZE = 0.10                        # Konzept, Abschnitt 5: ohne Effekt höchstens 10 % „belegt“


# ================================================================================================ Zahlen und Text

def _de(x, nd: int = 2) -> str:
    if x is None or not isinstance(x, (int, float, np.floating, np.integer)) or not math.isfinite(float(x)):
        return "—"
    return f"{float(x):.{nd}f}".replace(".", ",").replace("-", "−")


def _tsd(x) -> str:
    """Ganze Zahl mit Tausenderpunkt."""
    return f"{int(round(float(x))):,}".replace(",", ".").replace("-", "−")


def _pc(x, nd: int = 1) -> str:
    return "—" if x is None or not math.isfinite(float(x)) else _de(100.0 * float(x), nd) + " %"


def _p(x) -> str:
    if x is None or not math.isfinite(float(x)):
        return "—"
    return "unter 0,002" if float(x) < 0.002 else _de(x, 3)


def _rr_txt(x) -> str:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "—"
    return "∞" if math.isinf(float(x)) else _de(x, 2)


def _tag_txt(tag) -> str:
    return "—" if tag is None else time.strftime("%d.%m.%Y", time.gmtime(int(tag) * TAG))


def monatserster(tag: int) -> int:
    import calendar
    t = time.gmtime(int(tag) * TAG)
    return calendar.timegm((t.tm_year, t.tm_mon, 1, 0, 0, 0)) // TAG


# ================================================================================================ Bausteine der Reihen

def pz_reihe(x, fenster: int, mind: int) -> np.ndarray:
    """Mittelrang jeder Stelle unter den endlichen Werten der `fenster` Stellen davor (gleiche zählen halb); NaN unter `mind` Werten
    oder wenn alle gleich sind -- dieselbe Rechnung wie hl_radar.pz_davor, für die ganze Reihe."""
    x = np.asarray(x, dtype=float); n = len(x); out = np.full(n, np.nan)
    for i in range(n):
        v = x[i]
        if not np.isfinite(v):
            continue
        w = x[max(0, i - fenster):i]; w = w[np.isfinite(w)]
        if len(w) < mind or w.max() == w.min():
            continue
        out[i] = (np.sum(w < v) + 0.5 * np.sum(w == v)) / len(w)
    return out


def diff7(x: np.ndarray) -> np.ndarray:
    """x[d] − x[d−7]; die ersten sieben Stellen NaN."""
    out = np.full(len(x), np.nan)
    if len(x) > 7:
        out[7:] = x[7:] - x[:-7]
    return out


def ereignis(c: np.ndarray, tief: np.ndarray, f1: np.ndarray, x: float, h: int) -> tuple:
    """
    Ereignis am Schluss von Tag d: kleinstes Tief der Tage d+1 … d+h ≤ c_d · (1 − x · f). f1[d] ist der Faktor des Monats, in dem der
    Tag d+1 liegt. Gültig nur mit h Folgetagen, Schluss und Faktor. -> (eingetreten, gültig)
    """
    n = len(c); lo = np.full(n, np.inf)
    for j in range(1, h + 1):
        if n - j > 0:
            lo[:n - j] = np.minimum(lo[:n - j], tief[j:])
    gl = np.zeros(n, dtype=bool); gl[:max(0, n - h)] = True
    gl &= np.isfinite(c) & (c > 0) & np.isfinite(f1) & np.isfinite(lo)
    with np.errstate(invalid="ignore"):
        e = (lo <= c * (1.0 - x * f1)) & gl
    return e, gl


def zehntel(sig: np.ndarray, ev: np.ndarray) -> np.ndarray:
    """Klasse 0 … 9 der Schwankung je Tag unter den Auswertungstagen des Coins (gleich große Klassen; an der Grenze die untere); −1 ohne."""
    out = np.full(len(sig), -1, dtype=np.int16)
    ok = ev & np.isfinite(sig) & (sig > 0)
    if ok.sum() < ZEHNTEL * 3:
        return out
    grenzen = np.quantile(sig[ok], np.arange(1, ZEHNTEL) / ZEHNTEL)
    out[ok] = np.searchsorted(grenzen, sig[ok], side="left").astype(np.int16)
    return out


def faktor_tage(coin: str, tag0: int, n: int, rc: dict | None, rb: dict | None) -> np.ndarray:
    """Faktor je Tag d für das Ereignis ab d: der Faktor des Monats, in dem d+1 liegt (hl_radar.faktor_rechnen); NaN ohne Faktor."""
    if coin == "BTC":
        return np.ones(n)
    import hl_radar as RD
    out = np.full(n, np.nan); merk = {}
    for d in range(n):
        st = monatserster(tag0 + d + 1)
        if st not in merk:
            f = RD.faktor_rechnen(coin, rc, rb, st).get("f")
            merk[st] = float(f) if f is not None else float("nan")
        out[d] = merk[st]
    return out


def kalender_laden(db: str) -> dict:
    """Tage (UTC) mit Verbraucherpreisen, Arbeitsmarktbericht (makro.db, mk_termin) oder Fed-Entscheid (hl_volatil.FOMC)."""
    out = {"cpi": [], "nfp": [], "fed": [], "von": None, "bis": None, "fehlt": None}
    try:
        import hl_volatil as VL
        out["fed"] = sorted(int(t) for t in VL.fed_tage())
    except Exception as e:  # noqa: BLE001
        out["fehlt"] = f"Fed-Kalender nicht lesbar ({type(e).__name__})"
    try:
        import hl_makro as MK
        con = MK.lesen(MK.makro_pfad(db))
        if con is None:
            out["fehlt"] = "makro.db fehlt (Veröffentlichungstermine)"
        else:
            try:
                for sid, key in (("CPIAUCSL", "cpi"), ("UNRATE", "nfp")):
                    try:
                        rid = int(json.loads(MK.meta(con, f"release:{sid}") or "{}").get("id"))
                    except (ValueError, TypeError):
                        continue
                    out[key] = sorted({int(t) // TAG for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=?", (rid,))})
            finally:
                con.close()
    except Exception as e:  # noqa: BLE001
        out["fehlt"] = f"makro.db nicht lesbar ({type(e).__name__})"
    return kalender_fertig(out)


def kalender_fertig(out: dict) -> dict:
    """Zeitraum, in dem alle drei Kalender Termine tragen: vom spätesten ersten bis zum frühesten letzten Termin."""
    if all(out.get(k) for k in ("cpi", "nfp", "fed")):
        out["von"] = max(out[k][0] for k in ("cpi", "nfp", "fed")); out["bis"] = min(out[k][-1] for k in ("cpi", "nfp", "fed"))
        if out["von"] > out["bis"]:
            out["von"] = out["bis"] = None
            out["fehlt"] = out.get("fehlt") or "die drei Kalender überlappen nicht"
    elif not out.get("fehlt"):
        leer = [n for k, n in (("cpi", "Verbraucherpreise"), ("nfp", "Arbeitsmarktbericht"), ("fed", "Fed")) if not out.get(k)]
        out["fehlt"] = "keine Termine für " + ", ".join(leer)
    return out


def _auf_achse(tag0: int, n: int, t0: int, werte) -> np.ndarray:
    """Reihe `werte` (ab Tag t0, lückenlos) auf die Achse (tag0, n) legen."""
    out = np.full(n, np.nan)
    if werte is None:
        return out
    w = np.asarray(werte, dtype=float)
    a = max(tag0, t0); b = min(tag0 + n, t0 + len(w))
    if b > a:
        out[a - tag0:b - tag0] = w[a - t0:b - t0]
    return out


def reihen_bauen(coin: str, T: dict, L: dict | None, kal: dict, f1: np.ndarray) -> dict:
    """
    Alle Reihen eines Coins auf der Tagesachse der Hebel-Studie: Ereignisse, Schichten und die sieben Signale mit ihrer Definiertheit.
    T: Tafel aus hl_hebel (c, l, sig, oi, konten, ev0); L: hl_radar.lange_reihen (fund7, spot7, perp7) oder None; kal: Termine.
    """
    import hl_zyklus as ZY
    n = int(T["n"]); tag0 = int(T["tag0"]); c = np.asarray(T["c"], dtype=float); tief = np.asarray(T["l"], dtype=float)
    sig = np.asarray(T["sig"], dtype=float)
    ev = np.zeros(n, dtype=bool); ev[int(T.get("ev0", 0)):] = True
    ev &= np.isfinite(sig) & (sig > 0)
    x = np.log(c); dc7 = diff7(x)
    nan = np.full(n, np.nan)
    konten = np.asarray(T["konten"], dtype=float) if T.get("konten") is not None else nan
    oi = np.asarray(T["oi"], dtype=float) if T.get("oi") is not None else nan
    with np.errstate(invalid="ignore", divide="ignore"):
        lnoi = np.log(np.where(oi > 0, oi, np.nan))
    doi7 = diff7(lnoi)
    if L is not None:
        fund7 = _auf_achse(tag0, n, int(L["tag0"]), L["fund7"]); spot7 = _auf_achse(tag0, n, int(L["tag0"]), L["spot7"])
        perp7 = _auf_achse(tag0, n, int(L["tag0"]), L["perp7"])
    else:
        fund7 = spot7 = perp7 = nan
    konten_pz = ZY.oi_perzentil(konten, *PZ_KURZ); oi_pz = ZY.oi_perzentil(oi, *PZ_KURZ)
    doi7_pz = pz_reihe(doi7, *PZ_LANG)
    a3 = pz_reihe(fund7, *PZ_LANG); a4 = 1.0 - pz_reihe(spot7, *PZ_LANG); a7 = pz_reihe(sig, *PZ_LANG)
    achsen = np.stack([konten_pz, oi_pz, a3, a4, a7]) * 100.0
    k = np.isfinite(achsen).sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        index = np.where(k >= 4, np.nansum(achsen, axis=0) / np.where(k > 0, k, 1), np.nan)
    index_pz = pz_reihe(index, *PZ_LANG)
    termin = np.zeros(n, dtype=bool); t_def = np.zeros(n, dtype=bool)
    if kal.get("von") is not None:
        tage = set(kal["cpi"]) | set(kal["nfp"]) | set(kal["fed"])
        folgetag = tag0 + np.arange(n) + 1
        t_def = (folgetag >= kal["von"]) & (folgetag <= kal["bis"])
        termin = np.array([int(t) in tage for t in folgetag], dtype=bool)
    fin = np.isfinite
    with np.errstate(invalid="ignore"):
        regeln = {
            "r1": (konten >= KONTEN_SCHWELLE, fin(konten)),
            "r2": ((doi7_pz >= R2_PZ) & (np.abs(dc7) <= R2_STILL * sig * math.sqrt(7)), fin(doi7_pz) & fin(dc7) & fin(sig)),
            "r3": (fund7 >= R3_FUNDING, fin(fund7)),
            "r4": ((dc7 > 0) & (spot7 < 0) & (perp7 > 0), fin(dc7) & fin(spot7) & fin(perp7)),
            "r5": (oi_pz >= R5_PZ, fin(oi_pz)),
            "r6": (termin, t_def),
            "r7": (index_pz >= R7_PZ, fin(index_pz)),
        }
    regeln = {k_: (np.asarray(s, dtype=bool) & d, np.asarray(d, dtype=bool)) for k_, (s, d) in regeln.items()}
    E = {key: ereignis(c, tief, f1, xx, h) for key, h, xx, _ in EREIGNISSE}
    return {"coin": coin, "tag0": tag0, "n": n, "c": c, "sig": sig, "ev": ev, "zehntel": zehntel(sig, ev), "f1": f1, "E": E, "regeln": regeln,
            "werte": {"konten": konten, "doi7_pz": doi7_pz, "dc7": dc7, "fund7": fund7, "spot7": spot7, "perp7": perp7, "oi_pz": oi_pz,
                      "index": index, "index_pz": index_pz, "termin": termin}}


# ================================================================================================ Statistik

def _mh(k4s: np.ndarray) -> float:
    """Mantel-Haenszel-Risikoverhältnis über Schichten: k4s (Schichten, 4) mit a, b, c, d. Schichten ohne Signal- oder ohne
    Vergleichstage tragen nichts bei. NaN ohne Nenner."""
    a, b, c, d = (k4s[:, i] for i in range(4))
    nn = a + b + c + d; m = nn > 0; nz = np.where(m, nn, 1.0)
    num = float(np.where(m, a * (c + d) / nz, 0.0).sum()); den = float(np.where(m, c * (a + b) / nz, 0.0).sum())
    return num / den if den > 0 else float("nan")


def _rr4(k4) -> float:
    a, b, c, d = (float(v) for v in k4)
    if a + b <= 0 or c + d <= 0:
        return float("nan")
    if c <= 0:
        return float("inf") if a > 0 else float("nan")
    return (a / (a + b)) / (c / (c + d))


def _k4s(sig: np.ndarray, m: np.ndarray, E: np.ndarray, strat: np.ndarray, S: int) -> np.ndarray:
    """Vierfeldertafel je Schicht: Signal und Ereignis, Signal ohne, kein Signal mit, kein Signal ohne -- nur Tage in der Maske m."""
    idx = strat[m]; s = sig[m]; e = E[m]
    return np.stack([np.bincount(idx[s & e], minlength=S), np.bincount(idx[s & ~e], minlength=S),
                     np.bincount(idx[~s & e], minlength=S), np.bincount(idx[~s & ~e], minlength=S)], axis=1).astype(float)


def shifts() -> np.ndarray:
    """Verschiebungen in Tagen: 30 … 365 in beide Richtungen (672), nie 0."""
    return np.array([t for t in range(-365, 366) if abs(t) >= 30], dtype=np.int64)


def gitter(R: dict, coins: list, regel: str, ev_key: str) -> dict:
    """Signal, Definiertheit, Ereignis, Gültigkeit und Schicht je Coin auf dem gemeinsamen Kalender."""
    g0 = min(R[c]["tag0"] for c in coins); g1 = max(R[c]["tag0"] + R[c]["n"] - 1 for c in coins); G = g1 - g0 + 1; C = len(coins)
    sig = np.zeros((C, G), dtype=bool); sdef = np.zeros((C, G), dtype=bool); E = np.zeros((C, G), dtype=bool)
    val = np.zeros((C, G), dtype=bool); strat = np.full((C, G), -1, dtype=np.int64)
    for i, c in enumerate(coins):
        r = R[c]; off = r["tag0"] - g0; n = r["n"]
        s, d = r["regeln"][regel]; e, gl = r["E"][ev_key]; z = r["zehntel"]
        sig[i, off:off + n] = s & d; sdef[i, off:off + n] = d & r["ev"]
        E[i, off:off + n] = e; val[i, off:off + n] = gl & (z >= 0)
        strat[i, off:off + n] = np.where(z >= 0, i * ZEHNTEL + z, -1)
    return {"sig": sig, "sdef": sdef, "E": E, "val": val, "strat": strat, "g0": g0, "G": G, "S": C * ZEHNTEL, "coins": list(coins)}


def _mh_band(sig, m, E, strat, S: int, n_boot: int, block: int, saat: int) -> tuple:
    """90-%-Band des Mantel-Haenszel-RR aus dem zirkulären Kalender-Blockbootstrap (dieselben Blöcke für alle Coins und Schichten)."""
    G = sig.shape[1]
    if G < 2 * block or n_boot <= 0:
        return (float("nan"), float("nan"))
    k = np.zeros((S, 4, G))
    for i in range(sig.shape[0]):
        mi = m[i]; gi = np.nonzero(mi)[0]; si = strat[i][mi]; s = sig[i][mi]; e = E[i][mi]
        feld = np.where(s & e, 0, np.where(s & ~e, 1, np.where(~s & e, 2, 3)))
        np.add.at(k, (si, feld, gi), 1.0)
    kk = np.concatenate([k, k], axis=2); cs = np.concatenate([np.zeros((S, 4, 1)), np.cumsum(kk, axis=2)], axis=2)
    rng = np.random.default_rng(saat); nb = int(math.ceil(G / block)); werte = np.empty(n_boot)
    for j in range(n_boot):
        st = rng.integers(0, G, nb)
        werte[j] = _mh((cs[:, :, st + block] - cs[:, :, st]).sum(axis=2))
    werte = werte[np.isfinite(werte)]
    return (float(np.quantile(werte, 0.05)), float(np.quantile(werte, 0.95))) if len(werte) else (float("nan"), float("nan"))


def _episoden(idx: np.ndarray, h: int) -> int:
    """Zahl der Episoden: Signaltage, die mehr als h Tage auseinanderliegen, beginnen eine neue."""
    return 0 if not len(idx) else 1 + int(np.sum(np.diff(idx) > h))


def pruefen(Gt: dict, h: int, n_boot: int = N_BOOT, saat: int = SAAT, taus: np.ndarray | None = None, mit_null: bool = False) -> dict:
    """Eine Regel gegen ein Ereignis: Tafel, RR roh und nach Mantel-Haenszel, Null aus den Verschiebungen, Band, Hälften, Episoden."""
    sig, sdef, E, val, strat, S = Gt["sig"], Gt["sdef"], Gt["E"], Gt["val"], Gt["strat"], Gt["S"]
    G = Gt["G"]; taus = shifts() if taus is None else taus
    m = sdef & val
    k4s = _k4s(sig, m, E, strat, S); k4 = k4s.sum(axis=0)
    mh = _mh(k4s)
    dm = m.any(axis=0)
    if dm.any():
        idx = np.nonzero(dm)[0]; mi = int(idx[0] + (idx[-1] - idx[0]) // 2); spanne = (Gt["g0"] + int(idx[0]), Gt["g0"] + int(idx[-1]))
    else:
        mi = G // 2; spanne = None
    h1 = np.zeros((1, G), dtype=bool); h1[0, :mi + 1] = True
    hm = (m & h1, m & ~h1)
    mh_h = [_mh(_k4s(sig, x, E, strat, S)) for x in hm]
    null = np.empty(len(taus)); null_h = [np.empty(len(taus)), np.empty(len(taus))]
    for i, t in enumerate(taus):
        s2 = np.roll(sig, int(t), axis=1); m2 = np.roll(sdef, int(t), axis=1) & val
        null[i] = _mh(_k4s(s2, m2, E, strat, S))
        null_h[0][i] = _mh(_k4s(s2, m2 & h1, E, strat, S)); null_h[1][i] = _mh(_k4s(s2, m2 & ~h1, E, strat, S))
    fin = null[np.isfinite(null)]
    p = float((1 + np.sum(fin >= mh)) / (len(fin) + 1)) if np.isfinite(mh) and len(fin) else float("nan")
    med = lambda v: float(np.median(v[np.isfinite(v)])) if np.isfinite(v).any() else float("nan")   # noqa: E731
    epi = 0; je_coin = {}
    for i, c in enumerate(Gt["coins"]):
        ii = np.nonzero(sig[i] & m[i])[0]; epi += _episoden(ii, h)
        kc = _k4s(sig[i:i + 1], m[i:i + 1], E[i:i + 1], strat[i:i + 1], S)
        je_coin[c] = {"k4": [int(v) for v in kc.sum(axis=0)], "rr": _rr4(kc.sum(axis=0)), "mh": _mh(kc)}
    out = {"coins": list(Gt["coins"]), "k4": [int(v) for v in k4], "rr": _rr4(k4), "mh": mh,
           "p_sig": float(k4[0] / (k4[0] + k4[1])) if k4[0] + k4[1] else float("nan"),
           "p_ohne": float(k4[2] / (k4[2] + k4[3])) if k4[2] + k4[3] else float("nan"),
           "signaltage": int(k4[0] + k4[1]), "ohne": int(k4[2] + k4[3]), "episoden": int(epi), "p": p, "n_shift": int(len(fin)),
           "null_median": med(null), "band": _mh_band(sig, m, E, strat, S, n_boot, BLOCK, saat),
           "haelften": [(mh_h[0], med(null_h[0])), (mh_h[1], med(null_h[1]))], "je_coin": je_coin, "spanne": spanne, "h": int(h),
           "mitte": Gt["g0"] + mi}
    if mit_null:
        out["null"] = null
    return out


def pruefbar(o: dict) -> bool:
    return bool(o.get("signaltage", 0) >= MIN_SIGNALTAGE and o.get("episoden", 0) >= MIN_EPISODEN and o.get("ohne", 0) >= MIN_OHNE
                and math.isfinite(o.get("p", float("nan"))))


def haelften_ok(o: dict) -> bool:
    """RR in beiden Kalenderhälften über 1 und über dem Median der Null der Hälfte."""
    hv = o.get("haelften") or []
    return len(hv) == 2 and all(math.isfinite(a) and math.isfinite(b) and a > 1.0 and a > b for a, b in hv)


def holm(p: list) -> list:
    idx = [i for i, v in enumerate(p) if v is not None and math.isfinite(v)]
    m = len(idx); adj = [float("nan")] * len(p); lauf = 0.0
    for r, i in enumerate(sorted(idx, key=lambda k: p[k])):
        lauf = max(lauf, min(1.0, (m - r) * p[i])); adj[i] = lauf
    return adj


def urteile(V: dict, vollstaendig: bool) -> None:
    """Holm je Ereignis über die prüfbaren Regeln; belegt = prüfbar, p Holm < 0,05, beide Hälften -- und nur mit vollständiger Historie."""
    for key, _h, _x, _n in EREIGNISSE:
        T = V["tests"].get(key) or {}
        ks = [r[0] for r in REGELN if r[0] in T]
        pb = [k for k in ks if pruefbar(T[k])]
        for k in ks:
            T[k].update({"pruefbar": k in pb, "p_holm": float("nan"), "haelften_ok": haelften_ok(T[k]), "bedingung": False, "belegt": False})
        for k, ph in zip(pb, holm([T[k]["p"] for k in pb])):
            o = T[k]; o["p_holm"] = ph
            o["bedingung"] = bool(math.isfinite(ph) and ph < ALPHA and o["haelften_ok"])
            o["belegt"] = bool(o["bedingung"] and vollstaendig)
    V["vollstaendig"] = bool(vollstaendig)


def auswerten(R: dict, vollstaendig: bool = True, n_boot: int = N_BOOT, saat: int = SAAT, log=lambda s: None) -> dict:
    """Alle Regeln gegen beide Ereignisse für die Coins des Urteils; die übrigen beschreibend (Tafel, RR roh und geschichtet)."""
    coins = [c for c in COINS_URTEIL if c in R]
    V = {"fassung": FASSUNG, "coins": coins, "tests": {}, "beschreibend": {}, "basis": {}}
    taus = shifts()
    if coins:
        for i, (key, h, _x, _name) in enumerate(EREIGNISSE):
            V["tests"][key] = {}
            for j, (rk, *_rest) in enumerate(REGELN):
                V["tests"][key][rk] = pruefen(gitter(R, coins, rk, key), h, n_boot, saat + 17 * i + j, taus)
            log(f"rechnet Ereignis {key.upper()}: {len(REGELN)} Regeln, je {len(taus)} Verschiebungen …")
    urteile(V, vollstaendig)
    for c in R:
        V["basis"][c] = {}
        for key, _h, _x, _name in EREIGNISSE:
            e, gl = R[c]["E"][key]; g = gl & R[c]["ev"]
            V["basis"][c][key] = {"gueltig": int(g.sum()), "quote": float((e & g).sum() / g.sum()) if g.sum() else float("nan")}
    for c in COINS_BESCHR:
        if c not in R:
            continue
        V["beschreibend"][c] = {}
        for key, h, _x, _name in EREIGNISSE:
            V["beschreibend"][c][key] = {}
            for rk, *_rest in REGELN:
                Gt = gitter(R, [c], rk, key); m = Gt["sdef"] & Gt["val"]
                k4s = _k4s(Gt["sig"], m, Gt["E"], Gt["strat"], Gt["S"]); k4 = k4s.sum(axis=0)
                V["beschreibend"][c][key][rk] = {"k4": [int(v) for v in k4], "rr": _rr4(k4), "mh": _mh(k4s),
                                                 "episoden": _episoden(np.nonzero(Gt["sig"][0] & m[0])[0], h)}
    return V


def stand_heute(R: dict) -> dict:
    """Je Coin und Regel: Steht das Signal am letzten Tag der Reihe? Mit dem Wert, an dem es hängt."""
    out = {}
    for c, r in R.items():
        i = r["n"] - 1; w = r["werte"]; z = {}
        for rk, *_rest in REGELN:
            s, d = r["regeln"][rk]
            z[rk] = {"an": bool(s[i]) if d[i] else None}
        z["r1"]["wert"] = "Kontenquote " + _de(w["konten"][i], 2)
        z["r2"]["wert"] = f"OI-Zuwachs im Perzentil {_de(w['doi7_pz'][i] * 100 if np.isfinite(w['doi7_pz'][i]) else None, 0)}, Kurs in 7 Tagen {_pc(math.expm1(w['dc7'][i]) if np.isfinite(w['dc7'][i]) else None)}"
        z["r3"]["wert"] = "Funding " + _pc(w["fund7"][i]) + " im Jahr"
        z["r4"]["wert"] = f"Kurs {_pc(math.expm1(w['dc7'][i]) if np.isfinite(w['dc7'][i]) else None)}, Spot-Saldo {_pc(w['spot7'][i], 2)}, Perp-Saldo {_pc(w['perp7'][i], 2)}"
        z["r5"]["wert"] = "Open Interest im Perzentil " + _de(w["oi_pz"][i] * 100 if np.isfinite(w["oi_pz"][i]) else None, 0)
        z["r6"]["wert"] = "Termin am Folgetag" if w["termin"][i] else "kein Termin am Folgetag"
        z["r7"]["wert"] = (f"Druck-Index {_de(w['index'][i], 0)}, Perzentil {_de(w['index_pz'][i] * 100 if np.isfinite(w['index_pz'][i]) else None, 0)}")
        out[c] = {"tag": int(r["tag0"] + i), "regeln": z}
    return out


# ================================================================================================ Laden, Rechnen, Ablage

def ladestand_offen(Ld) -> str:
    """Was am Ladestand der Hebel-Studie (hl_hebel.ladestand) noch offen ist -- kurzer Text für die Zeile „VORLÄUFIG“; leer, wenn nichts."""
    if not isinstance(Ld, dict):
        return "kein Ladestand lesbar"
    k = [str(c) for c, o in (Ld.get("coins") or {}).items() if not (o or {}).get("fertig")]
    teile = ["Kennzahlen " + ", ".join(k)] if k else []
    for schl, o in (Ld.get("kerzen") or {}).items():
        if isinstance(schl, (tuple, list)) and len(schl) == 2:               # (Markt, Symbol) wie in hl_hebel: „um“ ist der Perp-Markt
            name = f"{schl[1]} ({ {'um': 'Perp', 'spot': 'Spot'}.get(str(schl[0]), str(schl[0])) })"
        else:
            name = " ".join(str(x) for x in schl) if isinstance(schl, (tuple, list)) else str(schl)
        if (o or {}).get("widerspruch"):
            teile.append(f"Kerzen {name}: {int(o.get('ohne_zeilen') or 0)} Monatsdatei(en) ohne Zeilen")
        elif int((o or {}).get("offen") or 0) > 1:                      # der Vormonat darf fehlen (wie in hl_hebel.ladestand)
            teile.append(f"Kerzen {name}: {int(o['offen'])} Monate offen")
    return "; ".join(teile[:5]) + (f"; und {len(teile) - 5} weitere" if len(teile) > 5 else "")


def laden(db: str) -> dict:
    """Reihen aller Coins aus hebel.db (Hebel-Studie), swing.db (Funding) und makro.db (Termine); nur lesen."""
    import hl_hebel as HB
    import hl_radar as RD
    D = HB.daten_laden(db, log=lambda s: None)
    tafeln = D.get("tafeln") or {}
    fehlt = list((D.get("info") or {}).get("fehlt") or [])
    voll = bool(D.get("laden") and D["laden"].get("vollstaendig"))
    kal = kalender_laden(db)
    if kal.get("fehlt"):
        fehlt.append("Termine (R6): " + kal["fehlt"])
    KR = RD.kerzen_lesen(db, RD.COINS) if tafeln else {}
    fund = {}
    try:
        import hl_swing as SW
        sc = HB._lesen(SW.swing_pfad(db))
        if sc is not None:
            try:
                for c in tafeln:
                    F = SW.funding_lesen(sc, c)
                    if len(F["ts"]):
                        fund[c] = (F["ts"], F["rate"])
            finally:
                sc.close()
    except Exception as e:  # noqa: BLE001 -- ohne Funding sind R3 und die Achse im Index undefiniert, der Rest steht
        fehlt.append(f"Funding nicht lesbar ({type(e).__name__}) -- R3 ohne Wert")
    rb = RD._renditen_je_tag(KR["BTC"]["tag"], KR["BTC"]["c"]) if "BTC" in KR else None
    R = {}
    for c, T in tafeln.items():
        L = RD.lange_reihen(KR[c], *(fund.get(c) or (None, None))) if c in KR else None
        rc = RD._renditen_je_tag(KR[c]["tag"], KR[c]["c"]) if c in KR else None
        R[c] = reihen_bauen(c, T, L, kal, faktor_tage(c, int(T["tag0"]), int(T["n"]), rc, rb))
    return {"R": R, "voll": voll, "kal": kal, "fehlt": fehlt, "offen": "" if voll else ladestand_offen(D.get("laden"))}


def _sauber(x):
    """Für die Ablage als JSON: keine NaN/∞ (-> None bzw. Text), keine numpy-Typen."""
    if isinstance(x, dict):
        return {str(k): _sauber(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_sauber(v) for v in x]
    if isinstance(x, (np.floating, float)):
        x = float(x)
        return x if math.isfinite(x) else ("inf" if x > 0 and math.isinf(x) else None)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    return x


def _zahl(x):
    """Aus der Ablage zurück: None -> NaN, "inf" -> ∞."""
    if x is None:
        return float("nan")
    if x == "inf":
        return float("inf")
    return float(x)


def rechnen(db: str, n_boot: int = N_BOOT, log=lambda s: None, jetzt: int | None = None) -> dict:
    """Daten lesen und alles rechnen. -> Ergebnis mit Urteilen (vorläufig ohne vollständige Historie), Stand heute, Zeitraum."""
    t0 = time.time(); jetzt = int(jetzt if jetzt is not None else time.time())
    L = laden(db); R = L["R"]
    V = auswerten(R, L["voll"], n_boot, log=log)
    V["stand"] = stand_heute(R)
    V["zeitraum"] = {c: {"von": int(r["tag0"] + int(np.argmax(r["ev"]))) if r["ev"].any() else None, "bis": int(r["tag0"] + r["n"] - 1),
                         "tage": int(r["ev"].sum())} for c, r in R.items()}
    k = L["kal"]
    V["kalender"] = {"von": k.get("von"), "bis": k.get("bis"), "fehlt": k.get("fehlt"), "n": {a: len(k.get(a) or []) for a in ("cpi", "nfp", "fed")}}
    V["fehlt"] = L["fehlt"]; V["ts"] = jetzt; V["rechenzeit"] = time.time() - t0
    V["laden_offen"] = L.get("offen") or ""
    return _sauber(V)


def abgelegt(db: str) -> dict | None:
    """Das abgelegte Urteil dieser Fassung aus radar.db oder None."""
    import hl_radar as RD
    con = RD.lesen(RD.pfad(db))
    if con is None:
        return None
    try:
        v = RD.meta(con, "regeln")
    except sqlite3.Error:
        return None
    finally:
        con.close()
    return v if isinstance(v, dict) and v.get("fassung") == FASSUNG and v.get("vollstaendig") and v.get("tests") else None


def holen(db: str, n_boot: int = N_BOOT, log=lambda s: None, jetzt: int | None = None) -> dict:
    """
    Debug 163: Liegt ein Urteil dieser Fassung in radar.db, wird es gezeigt (mit dem Stand von heute); sonst wird gerechnet und --
    nur mit vollständiger Historie und mindestens einem Coin -- abgelegt. Ein abgelegtes Urteil wird nicht still neu gerechnet.
    """
    import hl_radar as RD
    alt = abgelegt(db)
    if alt is not None:
        out = dict(alt); out["aus_ablage"] = True
        try:
            L = laden(db); out["stand"] = _sauber(stand_heute(L["R"])); out["fehlt_heute"] = L["fehlt"]
        except Exception as e:  # noqa: BLE001 -- das Urteil steht auch ohne den Stand von heute
            out["stand"] = {}; out["fehlt_heute"] = [f"Stand von heute nicht lesbar ({type(e).__name__})"]
        return out
    V = rechnen(db, n_boot, log, jetzt)
    V["aus_ablage"] = False; V["abgelegt"] = False
    if V.get("vollstaendig") and V.get("coins") and V.get("tests"):
        con = RD.verbinden(RD.pfad(db))
        try:
            RD.meta_setzen(con, "regeln", {k: v for k, v in V.items() if k not in ("stand", "aus_ablage", "abgelegt")})
            V["abgelegt"] = True
        finally:
            con.close()
    return V


def urteil_kurz(db: str) -> dict | None:
    """Für die Karte: das abgelegte Urteil in der Kurzform des Radars (hl_radar.regeln_kurz); None, solange keines abgelegt ist."""
    import hl_radar as RD
    return RD.regeln_kurz(abgelegt(db))


# ================================================================================================ Bericht (Debug 163)

def _umbruch(zeilen, breite: int = ZEILE_MAX) -> list:
    out = []
    for z in zeilen:
        z = str(z)
        if len(z) <= breite:
            out.append(z); continue
        einzug = " " * (len(z) - len(z.lstrip(" ")) + 2); rest = z; erste = True
        while len(rest) > breite:
            k = rest.rfind(" ", len(einzug) + 1 if not erste else 1, breite + 1)
            if k <= (0 if erste else len(einzug)):
                k = breite
            out.append(rest[:k].rstrip()); rest = einzug + rest[k:].lstrip(); erste = False
        out.append(rest)
    return out


def urteil_wort(o: dict, voll: bool) -> str:
    if not o.get("pruefbar"):
        g = []
        if o.get("signaltage", 0) < MIN_SIGNALTAGE:
            g.append(f"{o.get('signaltage', 0)} Signaltage, gebraucht {MIN_SIGNALTAGE}")
        if o.get("episoden", 0) < MIN_EPISODEN:
            g.append(f"{o.get('episoden', 0)} Episoden, gebraucht {MIN_EPISODEN}")
        if o.get("ohne", 0) < MIN_OHNE:
            g.append(f"{o.get('ohne', 0)} Vergleichstage, gebraucht {MIN_OHNE}")
        if not g:
            g.append("kein Risikoverhältnis in den Schichten")
        return "nicht prüfbar (" + "; ".join(g) + ")"
    if o.get("belegt"):
        return "BELEGT"
    if o.get("bedingung") and not voll:
        return "vorläufig erfüllt (Historie unvollständig)"
    g = []
    ph = _zahl(o.get("p_holm"))
    if not (math.isfinite(ph) and ph < ALPHA):
        g.append("p nach Holm " + _p(ph))
    if not o.get("haelften_ok"):
        g.append("nicht in beiden Hälften")
    return "nicht belegt (" + ", ".join(g) + ")"


def _anteil(x) -> str:
    """Anteil als Prozent: ganze Zahl, wo sie stimmt, sonst eine Stelle (49,5 %)."""
    v = 100.0 * float(x)
    return _de(v, 0 if abs(v - round(v)) < 1e-9 else 1) + " %"


def nachweis_zeilen(M: dict | None = None) -> list:
    """Die gemessene Nachweisgrenze als Zeilen des Berichts (aus NACHWEIS_MESSUNG)."""
    M = M or NACHWEIS_MESSUNG

    def reihe(F):
        return "   ".join(f"RR {_de(r7, 1)}" + (f" bzw. {_de(r2, 1)}" if abs(r7 - r2) > 1e-9 else "") + f" → {_anteil(b7)} · {_anteil(b2)}"
                          for r7, r2, b7, b2 in F["faelle"])
    o = M["ohne"]; r7 = M["r7_mit"]
    return [f"Nachweisgrenze (gemessen am {M['datum']} auf je {M['welten']} erfundenen Märkten: zwei Coins, je {_tsd(M['tage'])} Tage, sieben Regeln):",
            f"   ohne jeden Effekt: irgendeine Regel „belegt“ in {_anteil(o['e7'])} der Märkte (E7) und in {_anteil(o['e2'])} (E2) -- zulässig nach "
            f"Konzept: höchstens {_anteil(NACHWEIS_GRENZE)}",
            "   Effekt nur in R1 eingepflanzt: gemessenes RR σ (Median; E7 bzw. E2) → Anteil der Märkte, in denen R1 belegt wurde (E7 · E2)",
            f"      häufiges Zeichen (rund {M['haeufig']['signaltage']} Signaltage): " + reihe(M["haeufig"]),
            f"      seltenes Zeichen (rund {M['selten']['signaltage']} Signaltage): " + reihe(M["selten"]),
            "   Folge: Ein seltenes Zeichen mit einem echten RR um 2 bleibt meist unbelegt -- „nicht belegt“ heißt dort „nicht nachweisbar“.",
            "   R7 hängt an R1 und R5: Der Druck-Index enthält Kontenquote und Open Interest. Mit starkem Effekt nur in R1 (RR 3,4) wurde R7 in "
            f"{r7['e7']} von {r7['welten']} Märkten (E7) und in {r7['e2']} von {r7['welten']} (E2) mit belegt. „R7 belegt“ neben R1 oder R5 ist "
            "darum kein zweiter, eigener Beleg."]


def text(V: dict) -> str:
    """Bericht für Debug 163; keine Zeile über 150 Zeichen."""
    Z = []; a = Z.append
    voll = bool(V.get("vollstaendig")); coins = V.get("coins") or []
    a(f"★ Risikoradar: Prüfung der Regeln R1 bis R7 (U308, Debug {DEBUG_NR}) · Modul {VERSION_MODUL} · gerechnet am "
      + time.strftime("%d.%m.%Y %H:%M UTC", time.gmtime(int(V.get("ts") or time.time()))))
    a("Kündigt eines von sieben vorab festgelegten Zeichen einen Rücksetzer an -- über das hinaus, was die Schwankung des Tages ohnehin sagt? "
      "Regeln, Maß und Urteil stehen seit dem 23.11.2026 in KONZEPT_Risikoradar.md, Abschnitt 5; hier wird nichts an den Daten gesucht.")
    if V.get("aus_ablage"):
        a("Gezeigt ist das abgelegte Urteil (erster Lauf mit vollständiger Historie). Es wird nicht neu gerechnet; nur „Stand heute“ ist frisch.")
    elif V.get("abgelegt"):
        a("Dieser Lauf hat das Urteil gerechnet und in radar.db abgelegt. Spätere Läufe zeigen es und rechnen nicht neu.")
    elif coins:
        offen = str(V.get("laden_offen") or "")
        a("VORLÄUFIG: Die Historie in hebel.db ist noch nicht vollständig geladen" + (f" (offen: {offen})" if offen else "")
          + " -- nichts ist abgelegt, kein Urteil gilt. Der Hebel-Takt lädt weiter; danach Debug 163 noch einmal starten (einen Tag nach dem "
          "Einspielen von 23.123 startet er einmal von selbst).")
    for f in V.get("fehlt") or []:
        a("  fehlt: " + str(f))
    if not coins:
        a("")
        a("KEIN ERGEBNIS: Für BTC und ETH liegen keine Tagesreihen vor (hebel.db). Die Hebel-Studie lädt sie im Hintergrund; "
          "Debug 67 lädt sofort.")
        return "\n".join(_umbruch(Z))
    if voll:
        a("ERGEBNIS: " + " · ".join(
            f"{name} -- " + (("belegt: " + ", ".join(kurz for rk, kurz, _n, _w in REGELN if ((V.get("tests") or {}).get(key) or {}).get(rk, {}).get("belegt")))
                             if any(o_.get("belegt") for o_ in ((V.get("tests") or {}).get(key) or {}).values()) else "keine Regel belegt")
            for key, _h, _x, name in EREIGNISSE) + ".")
    zr = V.get("zeitraum") or {}
    a("Daten: " + " · ".join(f"{c} {_tag_txt(zr[c]['von'])} bis {_tag_txt(zr[c]['bis'])} ({zr[c]['tage']} Auswertungstage)" for c in coins if c in zr)
      + " · im Urteil " + " und ".join(coins) + " zusammen.")
    a(f"Maß: Risikoverhältnis nach Mantel-Haenszel über die {ZEHNTEL} Zehntel der Schwankung je Coin (RR σ). Null: Signal um 30 bis 365 Tage "
      f"verschoben, {len(shifts())} Verschiebungen, einseitig. Band: 90 % aus {N_BOOT} Ziehungen von {BLOCK}-Tage-Blöcken. Belegt heißt: prüfbar "
      f"(≥ {MIN_SIGNALTAGE} Signaltage, ≥ {MIN_EPISODEN} Episoden, ≥ {MIN_OHNE} Vergleichstage), p nach Holm unter 0,05 und RR in beiden "
      "Kalenderhälften über 1 und über der Null.")
    basis = V.get("basis") or {}
    for key, h, _x, name in EREIGNISSE:
        T = (V.get("tests") or {}).get(key) or {}
        a("")
        a(f"== Ereignis {key.upper()}: {name}" + (" (Hauptfamilie)" if key == "e7" else " (zweite Familie)")
          + " · Grundquote " + " · ".join(f"{c} {_pc((basis.get(c) or {}).get(key, {}).get('quote'))}" for c in coins))
        a("   Regel                           Signal-  Epi-   Quote nach    RR     RR σ   90-%-Band     Null            p       p Holm  Hälften RR σ")
        a("                                    tage    soden  Signal·sonst  roh                         Median                             (gegen Null)")
        for rk, kurz, nm, _wort in REGELN:
            o = T.get(rk)
            if not o:
                continue
            b = o.get("band") or [None, None]; hv = o.get("haelften") or [[None, None], [None, None]]
            a(f"   {kurz} {nm:<28.28s} {o.get('signaltage', 0):>6d}  {o.get('episoden', 0):>5d}   "
              f"{_pc(_zahl(o.get('p_sig'))):>6s}·{_pc(_zahl(o.get('p_ohne'))):<6s} {_rr_txt(_zahl(o.get('rr'))):>5s}  {_rr_txt(_zahl(o.get('mh'))):>5s}  "
              f"{_rr_txt(_zahl(b[0])):>5s}–{_rr_txt(_zahl(b[1])):<5s}  {_rr_txt(_zahl(o.get('null_median'))):>5s}  {_p(_zahl(o.get('p'))):>11s}  "
              f"{_p(_zahl(o.get('p_holm'))):>11s}  {_rr_txt(_zahl(hv[0][0]))}·{_rr_txt(_zahl(hv[1][0]))} ({_rr_txt(_zahl(hv[0][1]))}·{_rr_txt(_zahl(hv[1][1]))})")
            a(f"         Urteil {kurz}: {urteil_wort(o, voll)}")
        bel = [kurz for rk, kurz, _n, _w in REGELN if (T.get(rk) or {}).get("belegt")]
        a("   " + (("Belegt für dieses Ereignis: " + ", ".join(bel) + ".") if bel else "Für dieses Ereignis ist keine Regel belegt."))
    a("")
    a("Die Regeln im Wortlaut:")
    for _rk, kurz, nm, wort in REGELN:
        a(f"   {kurz} {nm}: {wort}.")
    a("   Das Signal gilt am Schluss des Tages (00:00 UTC); das Ereignis zählt das Tief der Folgetage. Faktor: Schwankung des Coins gegenüber "
      "BTC aus den 365 Tagen vor dem Monatsersten (BTC 1).")
    k = V.get("kalender") or {}
    if k.get("von") is not None:
        a(f"   R6: Termine vom {_tag_txt(k['von'])} bis {_tag_txt(k['bis'])} ({k['n'].get('cpi', 0)} Verbraucherpreise, {k['n'].get('nfp', 0)} "
          f"Arbeitsmarktberichte, {k['n'].get('fed', 0)} Fed-Entscheide). Termine kehren im Monatstakt wieder; ein Teil der Verschiebungen trifft "
          "deshalb wieder Termine. Die Null ist für R6 darum streng (eher zu wenig „belegt“ als zu viel).")
    a("")
    a("Je Coin (roh · nach Schichten), nur zur Einordnung:")
    for key, _h, _x, name in EREIGNISSE:
        T = (V.get("tests") or {}).get(key) or {}
        for rk, kurz, _nm, _wort in REGELN:
            jc = (T.get(rk) or {}).get("je_coin") or {}
            if jc:
                a(f"   {key.upper()} {kurz}: " + " · ".join(
                    f"{c} {v['k4'][0]} von {v['k4'][0] + v['k4'][1]} nach Signal, {v['k4'][2]} von {v['k4'][2] + v['k4'][3]} sonst, RR "
                    f"{_rr_txt(_zahl(v.get('rr')))} · {_rr_txt(_zahl(v.get('mh')))}" for c, v in jc.items()))
    B = V.get("beschreibend") or {}
    if B:
        a("")
        a("Beschreibend, ohne Urteil (kürzere oder lückenhafte Historie): " + ", ".join(B) + " -- Signaltage, Episoden, RR roh · RR σ")
        for c, Bc in B.items():
            for key, _h, _x, _name in EREIGNISSE:
                a(f"   {c} {key.upper()}: " + " · ".join(
                    f"{kurz} {o['k4'][0] + o['k4'][1]}/{o['episoden']} {_rr_txt(_zahl(o.get('rr')))}·{_rr_txt(_zahl(o.get('mh')))}"
                    for rk, kurz, _n, _w in REGELN for o in [(Bc.get(key) or {}).get(rk)] if o))
    S = V.get("stand") or {}
    if S:
        a("")
        a("Stand heute (letzter voller Tag der Reihe; „an“ heißt: das Zeichen der Regel steht -- kein Urteil, keine Empfehlung):")
        for c, s in S.items():
            a(f"   {c} · Tag {_tag_txt(s.get('tag'))}")
            for rk, kurz, nm, _wort in REGELN:
                z = (s.get("regeln") or {}).get(rk) or {}
                wort = "an " if z.get("an") is True else ("aus" if z.get("an") is False else "—  ")
                a(f"      {kurz} {nm:<28.28s} {wort}  {z.get('wert') or ''}")
    for f in V.get("fehlt_heute") or []:
        a("  fehlt heute: " + str(f))
    a("")
    for z_ in nachweis_zeilen():
        a(z_)
    a("Lesart: „Belegt“ heißt, dass nach dem Zeichen der Rücksetzer häufiger kam als an vergleichbar unruhigen Tagen ohne das Zeichen -- "
      "nicht, dass er dann kommt. „Nicht belegt“ heißt bei kleinen Effekten „nicht nachweisbar“. Eine belegte Regel ist ein Kandidat für einen "
      "Aufschlag auf die Prozentzahl (Paket 2); gerechnet wird damit erst nach deiner Entscheidung. An den Zahlen der Karte ändert dieser "
      "Bericht nichts; die Karte nennt das Urteil in einem Satz und am Druck-Index.")
    if V.get("rechenzeit") is not None and not V.get("aus_ablage"):
        a(f"Rechenzeit: {_de(_zahl(V.get('rechenzeit')), 1)} s")
    return "\n".join(_umbruch(Z))


# ================================================================================================ Aufschlag (Regel A, Konzept 14.4)

AUF_EREIGNIS = "e2"                           # A1: nur die 48-Stunden-Zahl
AUF_FRIST = 2                                 # … mit ihrer Frist in Tagen
AUF_DECKEL = 3.0                              # A3: Faktor höchstens 3 (Abschnitt 5), mindestens 1
AUF_MIN_TAGE = 365                            # A3: so viele Tage mit bekanntem Zustand, bevor es einen Faktor gibt


def _mh_or(k4s: np.ndarray) -> float:
    """Mantel-Haenszel-Chancenverhältnis über Schichten: Σ a·d/n ÷ Σ b·c/n (a Zustand mit Ereignis, b Zustand ohne, c „keins“ mit,
    d „keins“ ohne). Schichten ohne Tage tragen nichts bei. NaN ohne Nenner."""
    a, b, c, d = (k4s[:, i] for i in range(4))
    nn = a + b + c + d; m = nn > 0; nz = np.where(m, nn, 1.0)
    num = float(np.where(m, a * d / nz, 0.0).sum()); den = float(np.where(m, b * c / nz, 0.0).sum())
    return num / den if den > 0 else float("nan")


def auf_ordnung(belegt) -> list:
    """A2: die belegten Regeln in der Reihenfolge R1 … R7 (die frühere hat Vorrang)."""
    return [rk for rk, *_rest in REGELN if rk in set(belegt or [])]


def auf_zustand(r: dict, belegt) -> np.ndarray:
    """
    A2: Zustand je Tag eines Coins -- 0 „keins“; k ≥ 1: die k-te belegte Regel (Reihenfolge R1 … R7) ist die erste, deren Zeichen
    ansteht; −1 „unbekannt“ (kein Auswertungstag oder eine belegte Regel ist an dem Tag nicht definiert).
    """
    ordnung = auf_ordnung(belegt)
    z = np.zeros(int(r["n"]), dtype=np.int16); bekannt = np.asarray(r["ev"], dtype=bool).copy()
    for rk in ordnung:
        bekannt &= np.asarray(r["regeln"][rk][1], dtype=bool)
    for k in range(len(ordnung), 0, -1):                                 # rückwärts: die frühere Regel überschreibt die spätere
        z[np.asarray(r["regeln"][ordnung[k - 1]][0], dtype=bool)] = k
    z[~bekannt] = -1
    return z


def auf_faktoren(R: dict, coins, belegt, M: int) -> dict:
    """
    A3 für den Monatsersten M (Tagnummer): je Zustand das Mantel-Haenszel-Chancenverhältnis des Ereignisses E2 gegen „keins“,
    geschichtet nach Coin und Zehntel der Schwankung -- nur aus Tagen d, deren Frist abgelaufen war (d + 2 < M); die Zehntel nur aus
    diesen Tagen. Ein Faktor (1 … 3) nur mit mindestens AUF_MIN_TAGE Tagen bekannten Zustands, 30 Tagen in 5 Episoden im Zustand und
    30 Tagen „keins“; sonst None. Dazu je Coin der Anteil der Tage in jedem Zustand.
    -> {"monat", "f": {regel: Faktor|None}, "anteil": {coin: {regel: π}}, "n": {regel: {tage, episoden, ohne, or}}, "tage"}
    """
    ordnung = auf_ordnung(belegt); coins = [c for c in coins if c in R]
    out = {"monat": int(M), "f": {rk: None for rk in ordnung}, "anteil": {}, "n": {}, "tage": 0}
    teile = []; bekannt_tage = set()
    for i, c in enumerate(coins):
        r = R[c]; nf = min(int(r["n"]), int(M) - AUF_FRIST - int(r["tag0"]))     # Tage tag0 … tag0 + nf − 1 erfüllen d + 2 < M
        if nf <= 0:
            continue
        z = auf_zustand(r, ordnung)[:nf]
        e, gl = r["E"][AUF_EREIGNIS]
        e = np.asarray(e, dtype=bool)[:nf]; gl = np.asarray(gl, dtype=bool)[:nf]
        zt = zehntel(np.asarray(r["sig"], dtype=float)[:nf], np.asarray(r["ev"], dtype=bool)[:nf])
        teile.append((i, z, e, (z >= 0) & gl & (zt >= 0), zt))
        bekannt_tage |= set((int(r["tag0"]) + np.nonzero(z >= 0)[0]).tolist())
        nb = int((z >= 0).sum())
        out["anteil"][c] = {rk: (float((z == k + 1).sum()) / nb if nb else 0.0) for k, rk in enumerate(ordnung)}
    out["tage"] = len(bekannt_tage)
    S = max(1, len(coins)) * ZEHNTEL
    for k, rk in enumerate(ordnung):
        k4s = np.zeros((S, 4)); n_z = n_0 = epi = 0
        for i, z, e, ok, zt in teile:
            s = (z == k + 1) & ok; o = (z == 0) & ok
            idx = i * ZEHNTEL + zt
            k4s[:, 0] += np.bincount(idx[s & e], minlength=S); k4s[:, 1] += np.bincount(idx[s & ~e], minlength=S)
            k4s[:, 2] += np.bincount(idx[o & e], minlength=S); k4s[:, 3] += np.bincount(idx[o & ~e], minlength=S)
            n_z += int(s.sum()); n_0 += int(o.sum()); epi += _episoden(np.nonzero(s)[0], AUF_FRIST)
        orr = _mh_or(k4s)
        out["n"][rk] = {"tage": n_z, "episoden": epi, "ohne": n_0, "or": (orr if math.isfinite(orr) else None)}
        if (out["tage"] >= AUF_MIN_TAGE and n_z >= MIN_SIGNALTAGE and epi >= MIN_EPISODEN and n_0 >= MIN_OHNE and math.isfinite(orr)):
            out["f"][rk] = float(min(AUF_DECKEL, max(1.0, orr)))
    return out


def auf_daten(R: dict, belegt, bis_tag: int, coins=COINS_URTEIL) -> dict:
    """
    Für den Rückblick des Radars (A5): je Coin des Urteils der Zustand je Tag und je Monatserstem -- vom ersten Monat der Reihen bis
    zum Monat von bis_tag -- Faktoren und Anteile nach A3.
    -> {"regeln": [..], "coins": {coin: {"tag0", "zustand": Feld}}, "monate": {M: auf_faktoren}}
    """
    ordnung = auf_ordnung(belegt); coins = [c for c in coins if c in R]
    out = {"regeln": ordnung, "coins": {}, "monate": {}}
    if not ordnung or not coins:
        return out
    for c in coins:
        out["coins"][c] = {"tag0": int(R[c]["tag0"]), "zustand": auf_zustand(R[c], ordnung)}
    M = monatserster(min(int(R[c]["tag0"]) for c in coins)); ende = monatserster(int(bis_tag))
    while M <= ende:
        out["monate"][int(M)] = auf_faktoren(R, coins, ordnung, M)
        M = monatserster(M + 32)
    return out


def auf_laden(db: str, belegt, bis_tag: int) -> dict:
    """Wie auf_daten, aus den Dateien (hebel.db, swing.db, makro.db; nur lesen). „fehlt“ nennt, was beim Laden fehlte."""
    L = laden(db)
    out = auf_daten(L["R"], belegt, bis_tag)
    out["fehlt"] = list(L.get("fehlt") or [])
    return out


def auf_stand(db: str, belegt) -> dict:
    """
    A7: der Zustand des letzten vollen Tages je Coin des Urteils -- für die Karte (einmal am Tag vom Takt des Radars geholt).
    -> {"regeln": [..], "coins": {coin: {"tag", "k": −1|0|1…, "regel": Schlüssel der anstehenden Regel oder None}}}
    """
    ordnung = auf_ordnung(belegt)
    out = {"regeln": ordnung, "coins": {}}
    if not ordnung:
        return out
    R = laden(db)["R"]
    for c in COINS_URTEIL:
        if c not in R or not int(R[c]["n"]):
            continue
        z = auf_zustand(R[c], ordnung); i = int(R[c]["n"]) - 1; k = int(z[i])
        out["coins"][c] = {"tag": int(R[c]["tag0"]) + i, "k": k, "regel": (ordnung[k - 1] if k >= 1 else None)}
    return out


# ================================================================================================ erfundene Märkte (Selbsttest, Nachweisgrenze)

def _ar1(rng, n: int, mitte: float, s: float, phi: float) -> np.ndarray:
    """AR(1) um `mitte` mit stationärer Streuung s."""
    x = np.empty(n); x[0] = mitte + s * rng.normal(); e = rng.normal(0.0, s * math.sqrt(1.0 - phi * phi), n)
    for t in range(1, n):
        x[t] = mitte + phi * (x[t - 1] - mitte) + e[t]
    return x


def welt_bauen(saat: int, n: int = 2520, pflanz: str | None = None, q: float = 0.0, konten_mitte: float = 1.9, tag0: int = 18262,
               coins=COINS_URTEIL) -> dict:
    """
    Erfundener Markt für zwei Coins (kein echter Kurs): Tagesschlüsse mit Schwankungsballung (GARCH, t-Schocks, die Coins hängen
    zusammen), Tiefs im Tag, dazu Kontenquote, Open Interest, Funding und Taker-Salden als eigene träge Reihen OHNE Bezug zum künftigen
    Kurs. Mit pflanz="r1" … "r7" und q > 0 folgt auf jeden Signaltag dieser Regel mit Wahrscheinlichkeit q am nächsten Tag ein Tief
    12 % · Faktor unter dem Schluss (ein eingepflanzter Effekt). -> {"R": Reihen wie reihen_bauen, "roh": Eingaben}
    """
    import hl_zyklus as ZY
    rng = np.random.default_rng(saat)
    nu = 4.0; zc = rng.standard_t(nu, n) / math.sqrt(nu / (nu - 2)); kal_tage = {"cpi": [], "nfp": [], "fed": []}
    for t in range(tag0, tag0 + n + 40):
        m = (t - tag0) % 30
        if m == 11:
            kal_tage["cpi"].append(t)
        if m == 4:
            kal_tage["nfp"].append(t)
        if (t - tag0) % 46 == 20:
            kal_tage["fed"].append(t)
    kal = kalender_fertig({"cpi": kal_tage["cpi"], "nfp": kal_tage["nfp"], "fed": kal_tage["fed"], "von": None, "bis": None, "fehlt": None})
    roh = {}; R = {}
    for i, coin in enumerate(coins):
        sigma0 = 0.028 + 0.009 * i; a_, b_ = 0.08, 0.90
        zi = rng.standard_t(nu, n) / math.sqrt(nu / (nu - 2))
        z = zc if i == 0 else 0.8 * zc + 0.6 * zi
        om = sigma0 * sigma0 * (1 - a_ - b_); h = sigma0 * sigma0; x = np.empty(n); x[0] = math.log(100.0 * (1 + i))
        sd = np.empty(n); sd[0] = sigma0
        for t in range(1, n):
            sd[t] = math.sqrt(h); r = sd[t] * z[t]; h = om + a_ * r * r + b_ * h; x[t] = x[t - 1] + r
        c = np.exp(x)
        tief = np.minimum(c, np.concatenate([[c[0]], c[:-1]])) * np.exp(-np.abs(rng.normal(0.0, 1.0, n)) * sd * 0.6)
        konten = np.exp(_ar1(rng, n, math.log(konten_mitte), 0.35, 0.97))
        oi = 1e5 * np.exp(np.cumsum(rng.normal(0.0002, 0.02, n)) + _ar1(rng, n, 0.0, 0.10, 0.9))
        fund7 = _ar1(rng, n, 0.08, 0.06, 0.95); spot7 = _ar1(rng, n, 0.0, 0.01, 0.9); perp7 = _ar1(rng, n, 0.0, 0.01, 0.9)
        f1 = np.ones(n) if coin == "BTC" else np.full(n, 1.35)
        T = {"coin": coin, "tag0": tag0, "n": n, "c": c, "l": tief, "sig": ZY.sigma_batch(ZY.renditen(c[None, :]))[0], "oi": oi, "konten": konten,
             "ev0": 245}
        L = {"tag0": tag0, "n": n, "fund7": fund7, "spot7": spot7, "perp7": perp7}
        r0 = reihen_bauen(coin, T, L, kal, f1)
        if pflanz and q > 0:
            s, d = r0["regeln"][pflanz]
            tief = tief.copy()
            for t in np.nonzero(s & d)[0]:
                if t + 1 < n and rng.random() < q:
                    tief[t + 1] = min(tief[t + 1], c[t] * (1.0 - 0.12 * f1[t]))
            T["l"] = tief
            r0 = reihen_bauen(coin, T, L, kal, f1)
        roh[coin] = {"T": T, "L": L, "f1": f1}; R[coin] = r0
    return {"R": R, "roh": roh, "kal": kal}


def nachweis_welt(saat: int, pflanz: str | None, q: float, konten_mitte: float = 1.9) -> dict:
    """Eine erfundene Welt ganz durchgerechnet (ohne Band): je Ereignis die belegten Regeln und RR der gepflanzten Regel."""
    W = welt_bauen(saat, pflanz=pflanz, q=q, konten_mitte=konten_mitte)
    V = auswerten(W["R"], True, n_boot=0, saat=saat)
    out = {"belegt": {k: [rk for rk, o in V["tests"][k].items() if o.get("belegt")] for k in V["tests"]},
           "pruefbar": {k: [rk for rk, o in V["tests"][k].items() if o.get("pruefbar")] for k in V["tests"]}}
    if pflanz:
        out["ziel"] = {k: {f: V["tests"][k][pflanz].get(f) for f in ("rr", "mh", "p", "p_holm", "signaltage", "episoden", "belegt")} for k in V["tests"]}
    return out


def nachweis(n_welten: int = 200, saat0: int = 5000, log=print, prozesse: int = 1) -> dict:
    """
    Nachweisgrenze auf erfundenen Märkten (KONZEPT_Risikoradar.md Abschnitt 5): ohne Effekt der Anteil der Welten, in denen irgendeine
    Regel „belegt“ wäre; mit eingepflanztem Effekt in R1 (häufiges Zeichen: Kontenquote um 1,9; seltenes: um 1,5) der Anteil der Welten,
    in denen R1 belegt wird, und der gemessene RR. Rechnet lange -- nur in der Probe, nicht auf dem Pi.
    """
    plan = [("ohne Effekt", None, 0.0, 1.9)]
    for name, km in (("häufig", 1.9), ("selten", 1.5)):
        for q in (0.03, 0.06, 0.10):
            plan.append((f"R1 {name}, q {q}", "r1", q, km))
    aufgaben = [(saat0 + 1000 * j + i, pf, q, km) for j, (_n, pf, q, km) in enumerate(plan) for i in range(n_welten)]
    if prozesse > 1:
        import multiprocessing as mp
        with mp.Pool(prozesse) as pool:
            erg = pool.starmap(nachweis_welt, aufgaben, chunksize=4)
    else:
        erg = [nachweis_welt(*a) for a in aufgaben]
    out = {}
    for j, (name, pf, q, km) in enumerate(plan):
        teil = erg[j * n_welten:(j + 1) * n_welten]
        z = {"welten": n_welten}
        for key, _h, _x, _nm in EREIGNISSE:
            if pf is None:
                z[key] = {"irgendeine": sum(1 for e in teil if e["belegt"][key]) / n_welten,
                          "je_regel": {rk: sum(1 for e in teil if rk in e["belegt"][key]) / n_welten for rk, *_r in REGELN},
                          "pruefbar": {rk: sum(1 for e in teil if rk in e["pruefbar"][key]) / n_welten for rk, *_r in REGELN}}
            else:
                rr = [e["ziel"][key]["mh"] for e in teil if e["ziel"][key]["mh"] is not None and math.isfinite(e["ziel"][key]["mh"])]
                st = [e["ziel"][key]["signaltage"] for e in teil]
                z[key] = {"belegt": sum(1 for e in teil if e["ziel"][key]["belegt"]) / n_welten, "rr_median": float(np.median(rr)) if rr else None,
                          "signaltage_median": float(np.median(st)), "falsch": sum(1 for e in teil if [r for r in e["belegt"][key] if r != pf]) / n_welten}
        out[name] = z
        log(f"{name}: " + json.dumps(z, ensure_ascii=False))
    return out


# ================================================================================================ Proben zum Aufschlag (Regel A, 23.124)

def _probe_auf_reihen(n: int = 700, tag0: int = 19000) -> dict:
    """
    Tagesreihen von Hand für die Proben zu Regel A3 (nur die Felder, die der Aufschlag liest). Tage in Blöcken von 10; der Blocktyp
    wiederholt sich alle 60 Tage: Typ 0 = R1 steht an, Typ 4 = R7 steht an, sonst keines. Die Schwankung läuft im Block von 0,01 bis
    0,10 (Zehntel = Tag im Block). Ereignis: an R1-Tagen in jedem zweiten 60-Tage-Abschnitt; ohne Zeichen in den Zehnteln 0 bis 4 bei
    BTC in den Typen 1, 2, 3, bei ETH nur im Typ 1; an R7-Tagen nie. Bei ETH sind die Tage ab 300 keine Auswertungstage.
    """
    t = np.arange(n); blk = (t // 10) % 6; dez = t % 10; bi = t // 60
    R = {}
    for coin in ("BTC", "ETH"):
        s1 = blk == 0; s7 = blk == 4
        ohne_typen = (1, 2, 3) if coin == "BTC" else (1,)
        e = (s1 & (bi % 2 == 0)) | (np.isin(blk, ohne_typen) & (dez < 5))
        ev = np.ones(n, dtype=bool)
        if coin == "ETH":
            ev[300:] = False
        gl = np.ones(n, dtype=bool); gl[n - 2:] = False
        alle = np.ones(n, dtype=bool)
        R[coin] = {"coin": coin, "tag0": tag0, "n": n, "sig": (dez + 1) / 100.0, "ev": ev, "E": {"e2": (e & gl, gl), "e7": (e & gl, gl)},
                   "regeln": {"r1": (s1.copy(), alle.copy()), "r7": (s7.copy(), alle.copy()), "r3": (blk == 2, alle.copy())}}
    return R


def _proben_auf(ok) -> None:
    """Die Proben zu Regel A in der Regel-Prüfung: Chancenverhältnis, Zustand je Tag, Faktoren je Monat (kausal), Daten für den Rückblick."""
    k2 = np.array([[10.0, 20.0, 5.0, 65.0], [4.0, 6.0, 10.0, 80.0], [0.0, 0.0, 0.0, 0.0]])
    ok("RA1 Chancenverhältnis nach Mantel-Haenszel von Hand: zwei Schichten (10·65/100 + 4·80/100) ÷ (20·5/100 + 6·10/100) = 9,7 ÷ 1,6 = "
       "6,0625; eine leere Schicht ändert nichts; eine einzelne Schicht gibt das gewöhnliche Verhältnis (10·65) ÷ (20·5) = 6,5; ohne Nenner "
       "(kein Tag ohne Ereignis im Zustand oder kein Ereignis ohne Zeichen) kein Wert; kein Ereignis im Zustand: 0",
       abs(_mh_or(k2) - 6.0625) < 1e-12 and abs(_mh_or(k2[:2]) - 6.0625) < 1e-12 and abs(_mh_or(k2[:1]) - 6.5) < 1e-12
       and math.isnan(_mh_or(np.array([[5.0, 0.0, 3.0, 9.0]]))) and math.isnan(_mh_or(np.array([[5.0, 4.0, 0.0, 9.0]])))
       and math.isnan(_mh_or(np.zeros((3, 4)))) and _mh_or(np.array([[0.0, 4.0, 3.0, 9.0]])) == 0.0, f"{_mh_or(k2)}")
    w = lambda s_: np.array([c_ == "1" for c_ in s_])                       # noqa: E731
    rz = {"n": 8, "ev": w("01111111"),
          "regeln": {"r1": (w("11001000"), w("11111101")), "r7": (w("10101010"), w("11111110")), "r3": (w("00010000"), w("11111111"))}}
    z_a = auf_zustand(rz, ["r7", "r1"]); z_b = auf_zustand(rz, ["r7"]); z_c = auf_zustand(rz, [])
    ok("RA2 Zustand je Tag von Hand (Regel A2), belegt R1 und R7: kein Auswertungstag -> unbekannt; R1 an -> 1; nur R7 an -> 2; keines (ein "
       "nicht belegtes R3 zählt nicht) -> 0; beide an -> 1 (die frühere Regel hat Vorrang); eine belegte Regel ohne Wert -> unbekannt, auch "
       "wenn die andere ansteht. Ist nur R7 belegt, zählt allein R7. Die Reihenfolge ist immer R1 … R7, unbekannte Schlüssel fallen weg",
       [int(v) for v in z_a] == [-1, 1, 2, 0, 1, 0, -1, -1] and [int(v) for v in z_b] == [-1, 0, 1, 0, 1, 0, 1, -1]
       and [int(v) for v in z_c] == [-1, 0, 0, 0, 0, 0, 0, 0] and auf_ordnung(["r7", "r1", "r9"]) == ["r1", "r7"] and auf_ordnung(None) == []
       and auf_ordnung(("r5", "r2")) == ["r2", "r5"], f"{[int(v) for v in z_a]} {[int(v) for v in z_b]}")
    R = _probe_auf_reihen(); T0 = 19000; M = T0 + 602                         # Tage 0 … 599 erfüllen d + 2 < M
    F = auf_faktoren(R, ("BTC", "ETH"), ["r7", "r1"], M)
    Rk = {c_: dict(r_, n=600, sig=r_["sig"][:600], ev=r_["ev"][:600], E={k_: (v_[0][:600], v_[1][:600]) for k_, v_ in r_["E"].items()},
                   regeln={k_: (v_[0][:600], v_[1][:600]) for k_, v_ in r_["regeln"].items()}) for c_, r_ in R.items()}
    Rs = _probe_auf_reihen()
    for c_ in Rs:                                                           # nach Tag 600 alles anders: darf für M nicht zählen
        e_, g_ = Rs[c_]["E"]["e2"]; e_ = e_.copy(); e_[600:] = True; Rs[c_]["E"]["e2"] = (e_ & g_, g_)
        Rs[c_]["regeln"]["r1"][0][600:] = True; Rs[c_]["sig"] = np.concatenate([Rs[c_]["sig"][:600], np.full(100, 0.5)])
    Fs = auf_faktoren(Rs, ("BTC", "ETH"), ["r1", "r7"], M); Fk = auf_faktoren(Rk, ("BTC", "ETH"), ["r1", "r7"], M)
    Rs2 = _probe_auf_reihen()
    for c_ in Rs2:                                                          # dieselbe Änderung ohne die Schwankung: mit späterem M zählt sie
        e_, g_ = Rs2[c_]["E"]["e2"]; e_ = e_.copy(); e_[600:] = True; Rs2[c_]["E"]["e2"] = (e_ & g_, g_)
        Rs2[c_]["regeln"]["r1"][0][600:] = True
    Fsp = auf_faktoren(Rs2, ("BTC", "ETH"), ["r1", "r7"], T0 + 702)
    Rg = _probe_auf_reihen(); eg, gg = Rg["BTC"]["E"]["e2"]; gg = gg.copy(); gg[15] = False; Rg["BTC"]["E"]["e2"] = (eg & gg, gg)
    Fg = auf_faktoren(Rg, ("BTC", "ETH"), ["r1", "r7"], M)
    Fb = auf_faktoren(R, ("BTC",), ["r1", "r7"], M)
    ok("RA3 Faktoren von Hand (Regel A3), zwei Coins, Schichten = Coin × Zehntel der Schwankung, nur Tage mit abgelaufener Frist: "
       "R1 gegen „keins“ = 46 ÷ 17 = 2,7059 (BTC je Zehntel 0–4: 5·10/50 gegen 5·30/50, 5–9: 5·40/50; ETH mit halber Historie: 3·15/25 "
       "gegen 2·5/25, 3·20/25) -- über die Coins zusammengeworfen wären es 2,7755; R7 ohne ein einziges Ereignis: Verhältnis 0 -> Faktor 1 "
       "(nie unter 1); Anteil der Tage je Coin 1/6 und 1/6; 150 Tage in 15 Episoden gegen 600 Tage ohne Zeichen; 600 Tage mit bekanntem "
       "Zustand. Tage ab M − 2 zählen nicht (alles danach geändert: gleiches Ergebnis; dieselben Reihen bei Tag 600 abgeschnitten: "
       "gleiches Ergebnis; mit einem M hundert Tage später zählen die geänderten Tage: Verhältnis über 5, Faktor 3). Ein Tag ohne gültiges Ereignis fällt aus der Tafel (45,98 ÷ 17), zählt aber "
       "beim Anteil mit. Nur BTC: 25 ÷ 15 = 1,6667",
       F["monat"] == M and abs(F["n"]["r1"]["or"] - 46.0 / 17.0) < 1e-9 and abs(F["f"]["r1"] - 46.0 / 17.0) < 1e-9 and abs(F["f"]["r1"] - 2.7755) > 0.05
       and F["n"]["r7"]["or"] == 0.0 and F["f"]["r7"] == 1.0 and list(F["f"]) == ["r1", "r7"]
       and F["n"]["r1"] == {"tage": 150, "episoden": 15, "ohne": 600, "or": F["n"]["r1"]["or"]} and F["n"]["r7"]["tage"] == 150 and F["n"]["r7"]["ohne"] == 600
       and all(abs(F["anteil"][c_][rk] - 1.0 / 6.0) < 1e-12 for c_ in ("BTC", "ETH") for rk in ("r1", "r7")) and F["tage"] == 600
       and Fs == F and Fk == F and auf_faktoren(Rs2, ("BTC", "ETH"), ["r1", "r7"], M) == F
       and Fsp["n"]["r1"]["or"] > 5 and Fsp["f"]["r1"] == 3.0 and Fsp["tage"] == 700 and Fsp["n"]["r1"]["tage"] == 248
       and abs(Fg["n"]["r1"]["or"] - (46.0 - 4.0 + 5.0 * 39.0 / 49.0) / 17.0) < 1e-9 and Fg["n"]["r1"]["ohne"] == 599 and Fg["anteil"] == F["anteil"]
       and abs(Fb["f"]["r1"] - 25.0 / 15.0) < 1e-9 and list(Fb["anteil"]) == ["BTC"] and Fb["n"]["r1"]["tage"] == 100 and Fb["n"]["r1"]["episoden"] == 10,
       f"R1 {F['n']['r1']}, R7 {F['n']['r7']}, Anteile {F['anteil']}; später {Fsp['f']}")
    Rh = _probe_auf_reihen()
    for c_ in Rh:                                                           # ein starkes Zeichen: an R1-Tagen fast immer, sonst nur selten ein Ereignis
        g_ = Rh[c_]["E"]["e2"][1]; t_ = np.arange(700)
        e_ = (((t_ // 10) % 6 == 0) & ~((t_ % 10 == 0) & (t_ // 60 == 0))) | (((t_ // 10) % 6 == 1) & (t_ % 10 == 0))
        Rh[c_]["E"]["e2"] = (e_ & g_, g_)
    Fh = auf_faktoren(Rh, ("BTC", "ETH"), ["r1"], M)
    F364 = auf_faktoren(R, ("BTC", "ETH"), ["r1", "r7"], T0 + 2 + 364); F365 = auf_faktoren(R, ("BTC", "ETH"), ["r1", "r7"], T0 + 2 + 365)
    def eng(n_bloecke: int, ohne: int):
        """Eine Schicht (gleiche Schwankung), 400 Tage: R1 in n_bloecke Blöcken von 10 Tagen -- oder überall außer an `ohne` Tagen, die in
        Gruppen von drei aufeinanderfolgenden Tagen liegen (so bleiben es viele Episoden)."""
        n_ = 400; t_ = np.arange(n_); alle = np.ones(n_, dtype=bool); gl = alle.copy()
        if ohne:
            s1 = alle.copy(); s1[np.concatenate([np.arange(3) + 20 + 40 * i_ for i_ in range(10)])[:ohne]] = False
        else:
            s1 = ((t_ // 10) % 6 == 0) & (t_ // 60 < n_bloecke)
        e = (t_ % 2 == 0)
        return {"BTC": {"coin": "BTC", "tag0": T0, "n": n_, "sig": np.full(n_, 0.02), "ev": alle, "E": {"e2": (e, gl)}, "regeln": {"r1": (s1, alle)}}}
    f_ep4 = auf_faktoren(eng(4, 0), ("BTC",), ["r1"], T0 + 402); f_ep5 = auf_faktoren(eng(5, 0), ("BTC",), ["r1"], T0 + 402)
    f_o29 = auf_faktoren(eng(0, 29), ("BTC",), ["r1"], T0 + 402); f_o30 = auf_faktoren(eng(0, 30), ("BTC",), ["r1"], T0 + 402)
    f_t29 = auf_faktoren(eng(3, 0), ("BTC",), ["r1"], T0 + 402)
    ok("RA4 Grenzen (Regel A3): der Faktor ist höchstens 3 (ein Verhältnis weit darüber -> 3,0; das gemessene Verhältnis steht daneben); "
       "es gibt ihn erst ab 365 Tagen mit bekanntem Zustand (364: keiner), ab 30 Tagen im Zustand in 5 Episoden (40 Tage in 4 Episoden: "
       "keiner; 50 in 5: ja; 30 Tage in 3 Episoden: keiner) und ab 30 Tagen ohne Zeichen (29: keiner; 30: ja); Anteile und Zählung stehen "
       "auch ohne Faktor da",
       Fh["f"]["r1"] == AUF_DECKEL == 3.0 and Fh["n"]["r1"]["or"] > 20 and F364["tage"] == 364 and F364["f"] == {"r1": None, "r7": None}
       and F364["n"]["r1"]["tage"] > 30 and abs(F364["anteil"]["BTC"]["r1"] - 64.0 / 364.0) < 1e-12 and F365["tage"] == 365 and F365["f"]["r1"] is not None
       and f_ep4["n"]["r1"]["tage"] == 40 and f_ep4["n"]["r1"]["episoden"] == 4 and f_ep4["f"]["r1"] is None
       and f_ep5["n"]["r1"]["tage"] == 50 and f_ep5["n"]["r1"]["episoden"] == 5 and f_ep5["f"]["r1"] is not None
       and f_t29["n"]["r1"]["tage"] == 30 and f_t29["n"]["r1"]["episoden"] == 3 and f_t29["f"]["r1"] is None
       and f_o29["n"]["r1"]["ohne"] == 29 and f_o29["f"]["r1"] is None and f_o29["n"]["r1"]["episoden"] >= 5
       and f_o30["n"]["r1"]["ohne"] == 30 and f_o30["f"]["r1"] is not None and 1.0 <= f_o30["f"]["r1"] <= 3.0
       and (AUF_EREIGNIS, AUF_FRIST, AUF_MIN_TAGE, MIN_SIGNALTAGE, MIN_EPISODEN, MIN_OHNE) == ("e2", 2, 365, 30, 5, 30),
       f"Deckel {Fh['n']['r1']}; 364 Tage {F364['f']}; 4 Episoden {f_ep4['n']['r1']}; 29 ohne {f_o29['n']['r1']}; 30 ohne {f_o30['n']['r1']}")
    k_u = np.array([[10.0, 20.0, 5.0, 65.0], [2.0, 3.0, 5.0, 40.0]])
    F_0 = auf_faktoren(R, ("BTC", "ETH"), ["r1", "r7"], T0 + 2)
    Ru = _probe_auf_reihen(); Ru["BTC"]["ev"][400:450] = False; F_u = auf_faktoren(Ru, ("BTC", "ETH"), ["r1", "r7"], M)

    def eng2(s1, e, n_=400):
        """Eine Schicht, n_ Tage, alle Tage bekannt: R1 an den Tagen s1, Ereignis an den Tagen e."""
        alle = np.ones(n_, dtype=bool)
        return {"BTC": {"coin": "BTC", "tag0": T0, "n": n_, "sig": np.full(n_, 0.02), "ev": alle, "E": {"e2": (np.asarray(e, dtype=bool), alle.copy())},
                        "regeln": {"r1": (np.asarray(s1, dtype=bool), alle.copy())}}}
    t4 = np.arange(400)
    f_30 = auf_faktoren(eng2(((t4 // 6) % 10 == 0) & (t4 // 60 < 5), t4 % 2 == 0), ("BTC",), ["r1"], T0 + 402)
    f_g2 = auf_faktoren(eng2((t4 % 2 == 0) & (t4 < 60), t4 % 3 == 0), ("BTC",), ["r1"], T0 + 402)
    s_n = ((t4 // 10) % 6 == 0) & (t4 // 60 < 5); f_nan = auf_faktoren(eng2(s_n, s_n), ("BTC",), ["r1"], T0 + 402)
    ok("RA6 weitere Grenzen von Hand: Mantel-Haenszel mit verschieden großen Schichten (100 und 50 Tage): (10·65/100 + 2·40/50) ÷ "
       "(20·5/100 + 3·5/50) = 8,1 ÷ 1,3 = 6,2308 -- ohne die Teilung durch die Schichtgröße wären es 6,3478; ein Monatserster genau zwei "
       "Tage nach Beginn der Reihen: kein Tag zählt, kein Coin hat einen Anteil; die Tage mit bekanntem Zustand zählen über die Coins "
       "vereinigt (BTC ohne Auswertung an den Tagen 400–449, ETH ab 300: 550 Tage); genau 30 Tage in genau 5 Episoden genügen (Faktor 1, "
       "Chancenverhältnis 1); Signaltage im Abstand von 2 Tagen sind eine Episode (die Frist der 48-Stunden-Zahl), 30 Tage in 1 Episode "
       "genügen nicht; ohne einen Tag ohne Ereignis im Zustand gibt es kein Chancenverhältnis und keinen Faktor (auch nicht 1)",
       abs(_mh_or(k_u) - 8.1 / 1.3) < 1e-12 and abs(_mh_or(k_u) - 730.0 / 115.0) > 0.1
       and F_0 == {"monat": T0 + 2, "f": {"r1": None, "r7": None}, "anteil": {}, "tage": 0,
                   "n": {rk: {"tage": 0, "episoden": 0, "ohne": 0, "or": None} for rk in ("r1", "r7")}}
       and F_u["tage"] == 550 and F_u["anteil"]["ETH"] == F["anteil"]["ETH"]
       and f_30["n"]["r1"]["tage"] == 30 and f_30["n"]["r1"]["episoden"] == 5 and f_30["f"]["r1"] == 1.0 and abs(f_30["n"]["r1"]["or"] - 1.0) < 1e-9
       and f_g2["n"]["r1"]["tage"] == 30 and f_g2["n"]["r1"]["episoden"] == 1 and f_g2["f"]["r1"] is None
       and f_nan["n"]["r1"]["or"] is None and f_nan["f"]["r1"] is None and f_nan["n"]["r1"]["tage"] == 50 and f_nan["n"]["r1"]["episoden"] == 5,
       f"MH {_mh_or(k_u)}; Monat 2: {F_0}; vereinigt {F_u['tage']}; 30/5 {f_30['n']['r1']} {f_30['f']}; Abstand 2 {f_g2['n']['r1']}; ohne Nenner {f_nan['n']['r1']} {f_nan['f']}")
    Rz = dict(R, ZEC=R["BTC"])
    D = auf_daten(Rz, ["r7", "r1"], T0 + 650); Ms = sorted(D["monate"]); M1 = monatserster(T0 + 650)
    D0 = auf_daten(Rz, [], T0 + 650); D1 = auf_daten({"ZEC": R["BTC"]}, ["r1"], T0 + 650)
    alt_l = globals()["laden"]
    try:
        Rl = _probe_auf_reihen(); Rl["BTC"]["regeln"]["r1"][0][-1] = True; Rl["ETH"]["regeln"]["r7"][0][-1] = True
        Rl["ZEC"] = Rl["BTC"]; Rl["HYPE"] = dict(Rl["BTC"], n=0)
        globals()["laden"] = lambda db: {"R": Rl, "fehlt": ["Probe: Funding fehlt"]}
        St = auf_stand("x.db", ["r7", "r1"]); St7 = auf_stand("x.db", ["r7"]); St0 = auf_stand("x.db", [])
        DL = auf_laden("x.db", ["r1"], T0 + 650)
        globals()["laden"] = lambda db: {"R": {"BTC": dict(Rl["BTC"], n=0), "ETH": Rl["ETH"]}, "fehlt": []}
        Stn = auf_stand("x.db", ["r1", "r7"])
    finally:
        globals()["laden"] = alt_l
    ok("RA5 Daten für den Rückblick des Radars (Regel A5) und Stand für die Karte (A7): je Coin des Urteils (BTC, ETH -- andere Coins "
       "nicht) der Zustand je Tag; je Monatserstem vom ersten Monat der Reihen bis zum Monat des Laufs die Faktoren -- jeder genau der, den "
       "A3 für diesen Monatsersten rechnet; ohne belegte Regel oder ohne Coin des Urteils nichts. Stand: der letzte Tag der Reihe je Coin "
       "mit Nummer und Regel (BTC: R1 steht an -> 1; ETH: kein Auswertungstag -> unbekannt, auch wenn R7 ansteht); mit nur R7 belegt zählt "
       "allein R7 (BTC: keines); ein Coin ohne Tage fehlt im Stand; das Laden nennt, was fehlte",
       D["regeln"] == ["r1", "r7"] and sorted(D["coins"]) == ["BTC", "ETH"] and D["coins"]["BTC"]["tag0"] == T0
       and np.array_equal(D["coins"]["BTC"]["zustand"], auf_zustand(R["BTC"], ["r1", "r7"])) and int((D["coins"]["ETH"]["zustand"] == -1).sum()) == 400
       and Ms[0] == monatserster(T0) == 18993 and Ms[-1] == M1 and all(monatserster(m_) == m_ for m_ in Ms) and len(Ms) == 22
       and all(Ms[i_ + 1] == monatserster(Ms[i_] + 32) for i_ in range(len(Ms) - 1))
       and D["monate"][M1] == auf_faktoren(R, ("BTC", "ETH"), ["r1", "r7"], M1) and D["monate"][Ms[3]]["f"] == {"r1": None, "r7": None}
       and D["monate"][M1]["f"]["r1"] is not None
       and D0 == {"regeln": [], "coins": {}, "monate": {}} and D1 == {"regeln": ["r1"], "coins": {}, "monate": {}}
       and St == {"regeln": ["r1", "r7"], "coins": {"BTC": {"tag": T0 + 699, "k": 1, "regel": "r1"}, "ETH": {"tag": T0 + 699, "k": -1, "regel": None}}}
       and St7["regeln"] == ["r7"] and St7["coins"]["BTC"] == {"tag": T0 + 699, "k": 0, "regel": None} and St0 == {"regeln": [], "coins": {}}
       and sorted(Stn["coins"]) == ["ETH"]
       and DL["fehlt"] == ["Probe: Funding fehlt"] and DL["regeln"] == ["r1"] and sorted(DL["coins"]) == ["BTC", "ETH"] and sorted(DL["monate"]) == Ms,
       f"{len(Ms)} Monate bis {_tag_txt(Ms[-1])}; Stand {St.get('coins')}")


# ================================================================================================ Selbsttest (ohne Netz)

def _tafel(n: int, tag0: int = 20000, c=None, tief=None, sig=0.02, oi=None, konten=None, ev0: int = 0) -> dict:
    """Tafel wie aus der Hebel-Studie, mit festen Vorgaben: Schluss 100, Tief = Schluss, σ 2 %."""
    c = np.full(n, 100.0) if c is None else np.asarray(c, dtype=float)
    return {"coin": "BTC", "tag0": tag0, "n": n, "c": c, "l": c.copy() if tief is None else np.asarray(tief, dtype=float),
            "sig": np.full(n, float(sig)) if np.isscalar(sig) else np.asarray(sig, dtype=float), "oi": oi, "konten": konten, "ev0": ev0}


def _lang(n: int, tag0: int = 20000, fund7=None, spot7=None, perp7=None) -> dict:
    nan = np.full(n, np.nan)
    return {"tag0": tag0, "n": n, "fund7": nan if fund7 is None else np.asarray(fund7, dtype=float),
            "spot7": nan if spot7 is None else np.asarray(spot7, dtype=float), "perp7": nan if perp7 is None else np.asarray(perp7, dtype=float)}


_KAL_LEER = {"cpi": [], "nfp": [], "fed": [], "von": None, "bis": None, "fehlt": "keine Termine"}


def _einfach(sig, sdef, E, val=None, strat=None, g0: int = 20000) -> dict:
    """Gitter für einen Coin aus fertigen Reihen (eine Schicht, wenn nichts anderes gesagt ist)."""
    sig = np.asarray(sig, dtype=bool)[None, :]; G = sig.shape[1]
    return {"sig": sig, "sdef": np.asarray(sdef, dtype=bool)[None, :], "E": np.asarray(E, dtype=bool)[None, :],
            "val": (np.ones(G, dtype=bool) if val is None else np.asarray(val, dtype=bool))[None, :],
            "strat": (np.zeros(G, dtype=np.int64) if strat is None else np.asarray(strat, dtype=np.int64))[None, :],
            "g0": g0, "G": G, "S": ZEHNTEL, "coins": ["BTC"]}


def _tage(*bereiche, n: int) -> np.ndarray:
    out = np.zeros(n, dtype=bool)
    for a, b in bereiche:
        out[a:b] = True
    return out


def demo_dateien(verz: str, saat: int = 3, pflanz: str | None = None, q: float = 0.0, fertig: bool = True, jetzt: int | None = None) -> str:
    """
    Erzeugte Dateien für die Probe Ende zu Ende (keine echten Kurse): hebel.db mit Tageskerzen (Perpetual und Spot) und stündlichen
    Kennzahlen zum Tagesende für BTC und ETH ab 01.01.2020 bis gestern, vollständigem Ladestand (fertig=False: BTC noch nicht fertig),
    swing.db mit Funding, makro.db mit Veröffentlichungsterminen. -> Pfad der Hauptdatenbank (die es nicht geben muss)
    """
    import hl_hebel as HB
    import hl_makro as MK
    import hl_swing as SW
    jetzt = int(jetzt if jetzt is not None else time.time()); heute = jetzt // TAG
    tag0 = HB.tag_von("2020-01-01"); n = heute - tag0
    W = welt_bauen(saat, n=n, pflanz=pflanz, q=q, tag0=tag0)
    db = os.path.join(verz, "hl_liq.db")
    hb = HB.verbinden(os.path.join(verz, "hebel.db"))
    kz = []; mz = []
    for coin in COINS_URTEIL:
        T = W["roh"][coin]["T"]; L = W["roh"][coin]["L"]
        for i in range(n):
            tag = tag0 + i; c = float(T["c"][i]); lo = float(T["l"][i])
            kz.append(("um", coin + "USDT", tag, c, max(c, lo), lo, c, 10.0, 1e6, 1e6 * (0.5 + float(L["perp7"][i]) / 2), 100))
            kz.append(("spot", coin + "USDT", tag, c, max(c, lo), lo, c, 1.0, 4e5, 4e5 * (0.5 + float(L["spot7"][i]) / 2), 50))
            mz.append((coin, (tag + 1) * TAG - 300, float(T["oi"][i]), float(T["oi"][i]) * c, 1.0, 1.0, float(T["konten"][i]), 1.0))
    HB._schreiben(hb, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)", kz)
    HB._schreiben(hb, "INSERT OR REPLACE INTO hb_metrics VALUES (?,?,?,?,?,?,?,?)", mz)
    bis = HB.monat_plus(HB.monat_von(heute), -1); dz = []
    for markt, symbol, coin in HB.symbole():
        hat = coin in COINS_URTEIL and symbol == coin + "USDT" and markt in ("um", "spot")
        for m in HB.monate(HB.START_KERZEN, bis):
            dz.append(("kerzen_m", HB._dk(markt, symbol), m, 1 if hat else 0, 30 if hat else 0, jetzt))
    HB._schreiben(hb, "INSERT OR REPLACE INTO hb_dateien VALUES (?,?,?,?,?,?)", dz)
    HB.meta_setzen(hb, {f"m_fertig:{c}": ("1" if (fertig or c != "BTC") else "0") for c in HB.COINS})
    hb.close()
    sw = SW.verbinden(os.path.join(verz, "swing.db"))
    fz = []
    for coin in COINS_URTEIL:
        f = W["roh"][coin]["L"]["fund7"]
        fz += [(coin, (tag0 + i) * TAG + st * 3600, float(f[i]) / 365.0 / 3.0) for i in range(n) for st in (0, 8, 16)]
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)", fz)
    sw.close()
    mk = MK.verbinden(os.path.join(verz, "makro.db"))
    mk.execute("BEGIN IMMEDIATE")
    mk.executemany("INSERT OR REPLACE INTO mk_meta VALUES (?,?)", [("release:CPIAUCSL", json.dumps({"id": 10, "name": "Consumer Price Index"})),
                                                                   ("release:UNRATE", json.dumps({"id": 50, "name": "Employment Situation"}))])
    mk.executemany("INSERT OR IGNORE INTO mk_termin VALUES (?,?,?)",
                   [(10, t * TAG, jetzt) for t in W["kal"]["cpi"]] + [(50, t * TAG, jetzt) for t in W["kal"]["nfp"]])
    mk.execute("COMMIT"); mk.close()
    return db


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import subprocess
    import tempfile
    import hl_radar as RD
    gut = [0, 0]

    def ok(name, bed, info=""):
        gut[1] += 1
        if bed:
            gut[0] += 1
        if verbose or not bed:
            print(("  ok   " if bed else "  FEHL ") + name + (("  " + str(info)) if info != "" else ""), flush=True)

    print("hl_radar_regeln -- Selbsttest (Prüfung der Regeln R1 bis R7: Reihen, Ereignisse, Regeln von Hand, Statistik, erfundene Märkte; ohne Netz)",
          flush=True)
    rng = np.random.default_rng(7)

    # ---- Bausteine
    x = rng.normal(0, 1, 600); x[rng.integers(0, 600, 40)] = np.nan; x[100:110] = 0.5
    ab = max(abs((pz_reihe(x, f, m)[i] if np.isfinite(pz_reihe(x, f, m)[i]) else -1.0) - (RD.pz_davor(x, i, f, m) if RD.pz_davor(x, i, f, m) is not None else -1.0))
             for f, m in (PZ_LANG, PZ_KURZ) for i in range(0, 600, 7))
    gl = np.full(300, 2.0)
    ok("B1 Perzentil der ganzen Reihe gleich hl_radar.pz_davor an jeder Stelle (365/180 und 90/60, mit Lücken und gleichen Werten); "
       "lauter gleiche Werte geben keins; unter der Mindestzahl keins",
       ab < 1e-12 and not np.isfinite(pz_reihe(gl, 365, 180)).any() and not np.isfinite(pz_reihe(x, 365, 180)[:150]).any()
       and np.isfinite(pz_reihe(x, 365, 180)[230:]).sum() > 300, f"größte Abweichung {ab:.1e}")
    d7 = diff7(np.arange(20.0) ** 2)
    ok("B2 Änderung über 7 Tage: Stelle minus die Stelle sieben davor; die ersten sieben ohne Wert",
       not np.isfinite(d7[:7]).any() and d7[7] == 49.0 and d7[19] == 19.0 ** 2 - 12.0 ** 2)

    # ---- Ereignis
    n = 60; c = np.full(n, 100.0); tief = c.copy(); tief[10] = 89.0; tief[30] = 90.0; tief[45] = 90.01
    e7, g7 = ereignis(c, tief, np.ones(n), 0.10, 7); e2, g2 = ereignis(c, tief, np.ones(n), 0.07, 2)
    ok("E1 Fristen von Hand: ein Tief am Tag 10 zählt für die Schlüsse der Tage 3 bis 9 (7 Tage) und 8 bis 9 (48 Stunden); genau an der "
       "Schwelle (90,00 bei 10 %) zählt, 90,01 nicht",
       [int(i) for i in np.nonzero(e7)[0]] == list(range(3, 10)) + list(range(23, 30)) and [int(i) for i in np.nonzero(e2)[0]] == [8, 9, 28, 29, 43, 44],
       f"{[int(i) for i in np.nonzero(e7)[0]][:4]} … {[int(i) for i in np.nonzero(e2)[0]]}")
    ef, _ = ereignis(c, tief, np.full(n, 1.5), 0.10, 7); fn = np.ones(n); fn[5] = np.nan; cn = c.copy(); cn[6] = np.nan
    _, gf = ereignis(c, tief, fn, 0.10, 7); _, gc = ereignis(cn, tief, np.ones(n), 0.10, 7)
    ok("E2 Faktor und Gültigkeit: mit Faktor 1,5 liegt die Schwelle bei 85 (das Tief 89 zählt nicht); gültig nur mit 7 bzw. 2 Folgetagen, "
       "mit Faktor und mit Schluss",
       not ef.any() and g7[:n - 7].all() and not g7[n - 7:].any() and g2[:n - 2].all() and not g2[n - 2:].any() and not gf[5] and gf[4]
       and not gc[6] and gc[7])

    # ---- Faktor je Tag
    alt_fr = RD.faktor_rechnen
    try:
        RD.faktor_rechnen = lambda coin, rc, rb, st: {"f": float(st)}        # der Monatserste selbst als „Faktor“
        t_jan31 = RD.monatserster(20500) - 1                                 # letzter Tag eines Monats
        ft = faktor_tage("ETH", t_jan31 - 3, 8, {}, {})
        RD.faktor_rechnen = lambda coin, rc, rb, st: {"f": None}
        fo = faktor_tage("ETH", 20000, 5, {}, {})
        RD.faktor_rechnen = lambda *a: (_ for _ in ()).throw(RuntimeError("BTC darf nicht rechnen"))
        fb = faktor_tage("BTC", 20000, 5, None, None)
    finally:
        RD.faktor_rechnen = alt_fr
    ok("F1 Faktor je Tag: es gilt der Faktor des Monats, in dem der Folgetag liegt (am vorletzten Tag des Monats noch der alte, am letzten "
       "schon der neue); ohne Faktor kein Wert; BTC immer 1",
       ft[2] == RD.monatserster(t_jan31) and ft[3] == t_jan31 + 1 and ft[4] == t_jan31 + 1 and not np.isfinite(fo).any() and (fb == 1.0).all(),
       f"{ft[2]:.0f} {ft[3]:.0f}")

    # ---- Zehntel
    sg = rng.permutation(np.arange(1.0, 101.0)) / 1000.0; evz = np.ones(100, dtype=bool)
    z = zehntel(sg, evz); z2 = zehntel(sg, _tage((0, 29), n=100)); evh = evz.copy(); evh[:10] = False
    ok("S1 Zehntel der Schwankung: zehn gleich große Klassen (je 10 von 100 Tagen), der kleinste Wert in Klasse 0, der größte in 9; "
       "unter 30 Auswertungstagen keine; Tage außerhalb der Auswertung ohne Klasse",
       [int((z == k).sum()) for k in range(10)] == [10] * 10 and z[np.argmin(sg)] == 0 and z[np.argmax(sg)] == 9 and (z2 == -1).all()
       and (zehntel(sg, evh)[:10] == -1).all() and (zehntel(sg, evh)[10:] >= 0).all())
    zg = zehntel(np.arange(1.0, 42.0), np.ones(41, dtype=bool))            # 41 Werte 1 … 41: die erste Grenze liegt genau auf dem Wert 5
    sg2 = np.concatenate([np.full(40, 50.0), np.arange(1.0, 61.0)]); ev2 = np.concatenate([np.zeros(40, dtype=bool), np.ones(60, dtype=bool)])
    z3 = zehntel(sg2, ev2)
    ok("S2 Zehntel an der Grenze und nur aus Auswertungstagen: Ein Wert genau auf der Grenze gehört zur unteren Klasse (5 von 1 … 41 in "
       "Klasse 0, 6 in Klasse 1); die Grenzen kommen allein aus den Auswertungstagen -- 40 Tage davor mit viel höherer Schwankung "
       "verschieben nichts (je 6 von 60 Tagen je Klasse) und bleiben ohne Klasse",
       float(np.quantile(np.arange(1.0, 42.0), 0.1)) == 5.0 and zg[4] == 0 and zg[5] == 1 and zg[0] == 0 and zg[40] == 9
       and (z3[:40] == -1).all() and [int((z3[40:] == k_).sum()) for k_ in range(10)] == [6] * 10, f"{[int((z3[40:] == k_).sum()) for k_ in range(10)]}")
    sgn = np.full(120, 0.02); sgn[60] = np.nan; sgn[61] = 0.0
    Rv = reihen_bauen("BTC", _tafel(120, sig=sgn, ev0=50), None, _KAL_LEER, np.ones(120))
    ok("S3 Auswertungstage: erst ab dem Beginn der Auswertung der Hebel-Studie (hier Tag 50) und nur mit einer Schwankung über 0 -- davor und "
       "an Tagen ohne Schwankung keine Klasse",
       not Rv["ev"][:50].any() and Rv["ev"][50:60].all() and not Rv["ev"][60] and not Rv["ev"][61] and Rv["ev"][62:].all()
       and (Rv["zehntel"][:50] == -1).all() and Rv["zehntel"][60] == -1 and (Rv["zehntel"][62:] >= 0).all(), f"{int(Rv['ev'].sum())} von 120 Tagen")

    # ---- Regeln von Hand
    n = 420
    kq = np.full(n, 2.0); kq[400] = 2.99; kq[401] = 3.0; kq[402] = np.nan
    r = reihen_bauen("BTC", _tafel(n, konten=kq), None, _KAL_LEER, np.ones(n))
    s1, d1 = r["regeln"]["r1"]
    ok("R1 Kontenquote: 2,99 kein Signal, 3,00 Signal, ohne Wert nicht definiert", (not s1[400]) and s1[401] and d1[400] and not d1[402] and not s1[402])
    v = np.zeros(n); v[7:207] = np.arange(1, 201) * 1e-4                    # Zuwachs des OI über 7 Tage: 200 verschiedene Werte
    def oi_aus(v_):                                                          # OI, dessen 7-Tage-Zuwachs (log) genau v_ ist
        lo = np.zeros(n)
        for t in range(7, n):
            lo[t] = lo[t - 7] + v_[t]
        return np.exp(lo) * 1000.0
    grenze = R2_STILL * 0.02 * math.sqrt(7)
    def r2(wert, kurs_d7=0.0):
        vv = v.copy(); vv[207] = wert
        cc = np.full(n, 100.0); cc[207] = 100.0 * math.exp(kurs_d7)
        return reihen_bauen("BTC", _tafel(n, c=cc, oi=oi_aus(vv)), None, _KAL_LEER, np.ones(n))["regeln"]["r2"]
    a_, b_, c_, e_, f_ = r2(180.5e-4), r2(179.5e-4), r2(180.5e-4, grenze * 0.999999), r2(180.5e-4, grenze * 1.001), r2(180.5e-4, -grenze * 1.001)
    ok("R2 Hebel-Aufbau im Stillstand: Zuwachs größer als 180 von 200 Werten davor (Perzentil 0,90) -> Signal, größer als 179 (0,895) -> "
       "keins; Kurs über 7 Tage bis ½ σ·√7 bewegt -> Signal, darüber (auf oder ab) keins; ohne 180 Werte davor nicht definiert",
       a_[0][207] and a_[1][207] and (not b_[0][207]) and b_[1][207] and c_[0][207] and not e_[0][207] and not f_[0][207] and not a_[1][150],
       f"Grenze {grenze:.5f}")
    # genau auf der Grenze: eine Schwankung suchen, bei der die Kursänderung über 7 Tage (so, wie das Modul sie rechnet) genau ½ σ·√7 ist
    fund = None
    for k_ in range(40000):
        sx = 0.02 + k_ * 1e-7; gx = R2_STILL * sx * math.sqrt(7)
        cx = np.array([100.0, 100.0 * math.exp(gx)]); dx = float(np.log(cx)[1] - np.log(cx)[0])
        if dx == gx:
            fund = (sx, float(cx[1])); break
    if fund is not None:
        vv = v.copy(); vv[207] = 180.5e-4
        cc_g = np.full(n, 100.0); cc_g[207] = fund[1]
        Rg = reihen_bauen("BTC", _tafel(n, c=cc_g, oi=oi_aus(vv), sig=fund[0]), None, _KAL_LEER, np.ones(n))
        cc_h = cc_g.copy(); cc_h[207] = fund[1] * (1.0 + 1e-9)
        Rh = reihen_bauen("BTC", _tafel(n, c=cc_h, oi=oi_aus(vv), sig=fund[0]), None, _KAL_LEER, np.ones(n))
        ok("R2 genau auf der Grenze: Ist die Kursänderung über 7 Tage genau ½ σ·√7, gilt das noch als Stillstand (Signal); ein Milliardstel "
           "darüber nicht mehr",
           abs(float(Rg["werte"]["dc7"][207])) == R2_STILL * fund[0] * math.sqrt(7) and bool(Rg["regeln"]["r2"][0][207])
           and not Rh["regeln"]["r2"][0][207] and bool(Rh["regeln"]["r2"][1][207]), f"σ {fund[0]:.7f}, Änderung {float(Rg['werte']['dc7'][207]):.9f}")
    else:
        ok("R2 genau auf der Grenze: kein Wert gefunden, an dem Kursänderung und Grenze in der Rechnung dieses Rechners genau gleich sind", False)
    f7 = np.full(n, 0.05); f7[300] = 0.15; f7[301] = 0.1499; f7[302] = np.nan
    s3, d3 = reihen_bauen("BTC", _tafel(n), _lang(n, fund7=f7), _KAL_LEER, np.ones(n))["regeln"]["r3"]
    ok("R3 Funding-Niveau: genau 15 % im Jahr -> Signal, 14,99 % keins, ohne Wert nicht definiert",
       s3[300] and not s3[301] and d3[301] and not d3[302])
    cc = np.full(n, 100.0); cc[300:] = 101.0                                # Tage 300 … 306: Kurs über 7 Tage gestiegen
    sp = np.full(n, 0.01); pp = np.full(n, 0.01)
    sp[300] = -0.01; sp[301] = 0.0; sp[302] = -0.01; pp[302] = 0.0; sp[303] = -0.01; sp[304] = np.nan; sp[310] = -0.01
    s4, d4 = reihen_bauen("BTC", _tafel(n, c=cc), _lang(n, spot7=sp, perp7=pp), _KAL_LEER, np.ones(n))["regeln"]["r4"]
    ok("R4 Spot trägt nicht: Kurs gestiegen, Spot-Saldo unter 0, Perp-Saldo über 0 -> Signal; Spot-Saldo genau 0, Perp-Saldo genau 0 oder "
       "Kurs nicht gestiegen -> keins; ohne Spot-Saldo nicht definiert",
       s4[300] and not s4[301] and not s4[302] and s4[303] and not d4[304] and (not s4[310]) and d4[310])
    oi5 = np.full(n, np.nan); oi5[100:190] = np.arange(1.0, 91.0) * 10.0
    def r5(wert):
        o = oi5.copy(); o[190] = wert
        return reihen_bauen("BTC", _tafel(n, oi=o), None, _KAL_LEER, np.ones(n))["regeln"]["r5"]
    ok("R5 OI-Überhitzung: Open Interest über 81 von 90 Tageswerten davor (Perzentil 0,90) -> Signal, über 80 (0,889) keins",
       r5(815.0)[0][190] and not r5(805.0)[0][190] and r5(805.0)[1][190])
    kal = kalender_fertig({"cpi": [20100, 20130, 20390], "nfp": [20104, 20200, 20395], "fed": [20120, 20300, 20400], "von": None, "bis": None, "fehlt": None})
    s6, d6 = reihen_bauen("BTC", _tafel(n), None, kal, np.ones(n))["regeln"]["r6"]
    ok("R6 Termin: Signal am Tag VOR Verbraucherpreisen (20130, 20390), Arbeitsmarktbericht (20200) oder Fed-Entscheid (20120, 20300), nicht am Tag selbst; definiert nur, "
       "solange der Folgetag im Zeitraum aller drei Kalender liegt (vom spätesten ersten bis zum frühesten letzten Termin)",
       kal["von"] == 20120 and kal["bis"] == 20390 and [int(i) + 20000 for i in np.nonzero(s6)[0]] == [20119, 20129, 20199, 20299, 20389]
       and not d6[118] and d6[119] and d6[389] and not d6[390] and not s6[103] and not s6[200] and not s6[300],
       f"{[int(i) + 20000 for i in np.nonzero(s6)[0]]}")
    rs = np.random.default_rng(3)
    kq7 = np.exp(rs.normal(0.6, 0.2, n)); oi7 = np.exp(rs.normal(10, 0.2, n)); fu7 = rs.normal(0.08, 0.05, n); sp7 = rs.normal(0, 0.01, n)
    sg7 = np.abs(rs.normal(0.02, 0.005, n)) + 0.005
    for arr, hoch in ((kq7, True), (oi7, True), (fu7, True), (sp7, False), (sg7, True)):
        arr[419] = (arr[:419].max() * 1.5 + 1.0) if hoch else (arr[:419].min() - 1.0)
    R7 = reihen_bauen("BTC", _tafel(n, konten=kq7, oi=oi7, sig=sg7), _lang(n, fund7=fu7, spot7=sp7), _KAL_LEER, np.ones(n))
    import hl_zyklus as ZY
    i7 = 300
    hand = np.mean([ZY.oi_perzentil(kq7, 90, 60)[i7], ZY.oi_perzentil(oi7, 90, 60)[i7], RD.pz_davor(fu7, i7), 1 - RD.pz_davor(sp7, i7),
                    RD.pz_davor(sg7, i7)]) * 100
    R7b = reihen_bauen("BTC", _tafel(n, konten=kq7, oi=oi7, sig=sg7), _lang(n, spot7=sp7), _KAL_LEER, np.ones(n))
    R7c = reihen_bauen("BTC", _tafel(n, konten=kq7, sig=sg7), _lang(n, spot7=sp7), _KAL_LEER, np.ones(n))
    hand4 = np.mean([ZY.oi_perzentil(kq7, 90, 60)[i7], ZY.oi_perzentil(oi7, 90, 60)[i7], 1 - RD.pz_davor(sp7, i7), RD.pz_davor(sg7, i7)]) * 100
    ok("R7 Druck-Index auf Tagesschlüssen: Mittel der fünf Achsen (Kontenquote und Open Interest gegen 90 Tage, Funding, Spot-Saldo "
       "umgekehrt und Schwankung gegen 365 Tage) von Hand; mit vier Achsen das Mittel der vier, mit drei kein Wert; alle fünf am "
       "höchsten -> Index 100 und Signal (oberstes Zehntel der 365 Tage davor)",
       abs(R7["werte"]["index"][i7] - hand) < 1e-9 and abs(R7b["werte"]["index"][i7] - hand4) < 1e-9 and not np.isfinite(R7c["werte"]["index"][i7])
       and not R7c["regeln"]["r7"][1][i7] and abs(R7["werte"]["index"][419] - 100.0) < 1e-9 and R7["regeln"]["r7"][0][419]
       and R7["regeln"]["r7"][0][i7] == (R7["werte"]["index_pz"][i7] >= 0.9),
       f"Index {R7['werte']['index'][i7]:.2f} gegen {hand:.2f}; mit vier {R7b['werte']['index'][i7]:.2f}")
    # genau am Zehntel: eine erzeugte Reihe suchen, in der der Index an einem Tag genau im Perzentil 0,90 steht (Suche über Saaten; die Probe
    # nennt Saat und Tag und schlägt fehl, wenn sie keinen findet)
    fund7 = None
    for saat_ in range(1000, 1400):
        rz = np.random.default_rng(saat_)
        kq_ = np.exp(rz.normal(0.6, 0.2, n)); oi_ = np.exp(rz.normal(10, 0.2, n)); fu_ = rz.normal(0.08, 0.05, n); sp_ = rz.normal(0, 0.01, n)
        sg_ = np.abs(rz.normal(0.02, 0.005, n)) + 0.005
        Rz = reihen_bauen("BTC", _tafel(n, konten=kq_, oi=oi_, sig=sg_), _lang(n, fund7=fu_, spot7=sp_), _KAL_LEER, np.ones(n))
        tz = np.nonzero(Rz["werte"]["index_pz"] == R7_PZ)[0]
        if len(tz):
            fund7 = (saat_, int(tz[0]), bool(Rz["regeln"]["r7"][0][tz[0]]), bool(Rz["regeln"]["r7"][1][tz[0]])); break
    ok("R7 genau am Zehntel: Steht der Index genau im Perzentil 0,90 der 365 Tage davor, ist das Signal an (≥, nicht >)",
       fund7 is not None and fund7[2] and fund7[3], f"Saat und Tag {fund7[:2] if fund7 else 'nicht gefunden'}")
    # kein Blick voraus: spätere Werte ändern frühere Signale nicht
    W0 = welt_bauen(21, n=900)
    ro = W0["roh"]["ETH"]; T2 = dict(ro["T"]); L2 = dict(ro["L"]); st = 700
    for k_ in ("c", "l", "oi", "konten", "sig"):
        a2 = np.array(T2[k_], dtype=float); a2[st + 1:] = a2[st + 1:] * 1.37 + 0.001; T2[k_] = a2
    for k_ in ("fund7", "spot7", "perp7"):
        a2 = np.array(L2[k_], dtype=float); a2[st + 1:] += 0.5; L2[k_] = a2
    Ra = W0["R"]["ETH"]; Rb = reihen_bauen("ETH", T2, L2, W0["kal"], ro["f1"])
    ok("K1 kein Blick voraus: Werden alle Eingaben NACH einem Tag verändert, bleiben Signale und Definiertheit aller sieben Regeln bis zu "
       "diesem Tag gleich (und ändern sich danach)",
       all(np.array_equal(Ra["regeln"][k_][0][:st + 1], Rb["regeln"][k_][0][:st + 1]) and np.array_equal(Ra["regeln"][k_][1][:st + 1], Rb["regeln"][k_][1][:st + 1])
           for k_ in Ra["regeln"]) and any(not np.array_equal(Ra["regeln"][k_][0], Rb["regeln"][k_][0]) for k_ in Ra["regeln"]))

    # ---- Statistik von Hand
    k2 = np.zeros((ZEHNTEL, 4)); k2[0] = [10, 10, 20, 60]; k2[1] = [5, 15, 5, 75]; k2[2] = [3, 2, 0, 0]
    falle = np.zeros((ZEHNTEL, 4)); falle[0] = [0, 0, 5, 95]; falle[9] = [40, 60, 4, 6]
    ok("M1 Mantel-Haenszel von Hand: zwei Schichten -> (8 + 4) ÷ (4 + 1) = 2,40; eine Schicht ohne Vergleichstage trägt nichts bei; ein "
       "Zeichen, das nur die unruhigste Schicht markiert (dort 40 % mit wie ohne Zeichen), hat roh RR 4,89 und geschichtet 1,00",
       abs(_mh(k2) - 2.4) < 1e-12 and abs(_mh(falle) - 1.0) < 1e-12 and abs(_rr4(falle.sum(axis=0)) - (40 / 100) / (9 / 110)) < 1e-12
       and math.isnan(_mh(np.zeros((ZEHNTEL, 4)))) and math.isinf(_rr4([3, 1, 0, 9])) and math.isnan(_rr4([0, 0, 2, 2])),
       f"{_mh(k2):.2f} · roh {_rr4(falle.sum(axis=0)):.2f} geschichtet {_mh(falle):.2f}")
    sgn = _tage((0, 4), n=12); mm = _tage((0, 10), n=12); Ee = np.array([1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1], dtype=bool)
    stt = np.array([0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0])
    kk = _k4s(sgn[None, :], mm[None, :], Ee[None, :], stt[None, :], ZEHNTEL)
    ok("M2 Tafel je Schicht von Hand: nur Tage in der Maske zählen; Schicht 0: 1 · 1 · 2 · 2, Schicht 1: 0 · 2 · 0 · 2",
       [int(v) for v in kk[0]] == [1, 1, 2, 2] and [int(v) for v in kk[1]] == [0, 2, 0, 2] and kk.sum() == 10)
    ts = shifts()
    ok("M3 Verschiebungen: 672, jede zwischen 30 und 365 Tagen in beide Richtungen, keine 0, keine doppelt",
       len(ts) == 672 and int(np.abs(ts).min()) == 30 and int(np.abs(ts).max()) == 365 and 0 not in ts and len(set(int(t) for t in ts)) == 672
       and int(ts.sum()) == 0)
    G = 800
    Gt = _einfach(_tage((380, 400), n=G), _tage((0, 400), n=G), _tage((415, 420), (100, 110), n=G))
    o = pruefen(Gt, 7, n_boot=0, mit_null=True)
    i30 = int(np.nonzero(shifts() == 30)[0][0])
    ok("M4 Verschiebung von Hand: Signal und Definiertheit wandern gemeinsam (+30 Tage: 20 Signaltage, 5 davon mit Ereignis, gegen 10 von "
       "380 sonst -> RR 9,50); Ereignisse und Gültigkeit bleiben stehen",
       abs(o["null"][i30] - (5 / 20) / (10 / 380)) < 1e-9 and o["k4"] == [0, 20, 10, 370], f"{o['null'][i30]:.2f}")
    sgA = _tage((100, 120), (300, 320), (500, 520), (650, 670), (720, 740), n=G); EA = sgA.copy(); EA[::3] = False   # Ereignis an 2 von 3 Signaltagen
    EA |= _tage((40, 42), (230, 232), (430, 432), (600, 602), n=G)                                                       # und selten sonst
    oA = pruefen(_einfach(sgA, np.ones(G, dtype=bool), EA), 7, n_boot=200, saat=1)
    ok("M5 p-Wert: Trifft keine der 672 Verschiebungen das beobachtete RR, ist p = 1 ÷ 673; das Band (90 %) liegt um den Wert und über 1; "
       "fünf Episoden von je 20 Tagen",
       abs(oA["p"] - 1 / 673) < 1e-12 and oA["n_shift"] == 672 and oA["band"][0] > 1.0 and oA["band"][0] <= oA["mh"] <= oA["band"][1]
       and oA["episoden"] == 5 and oA["signaltage"] == 100, f"RR {oA['mh']:.1f}, Band {oA['band'][0]:.1f}–{oA['band'][1]:.1f}")
    # Band von Hand nachgezogen: dieselben Ziehungen (Saat 77), jede Ziehung aus fünf Blöcken von 60 Tagen rund um den Kalender, die Tafel je
    # Ziehung neu gezählt; 5. und 95. Perzentil der 200 Werte
    rb_ = np.random.default_rng(11); Gn = 300
    sgB = rb_.random(Gn) < 0.2; EB = rb_.random(Gn) < np.where(sgB, 0.35, 0.12); stB = rb_.integers(0, 3, Gn)
    GB = _einfach(sgB, np.ones(Gn, dtype=bool), EB, strat=stB)
    mB = GB["sdef"] & GB["val"]
    band_m = _mh_band(GB["sig"], mB, GB["E"], GB["strat"], GB["S"], 200, 60, 77)
    rz_ = np.random.default_rng(77); wb = []
    for _j in range(200):
        st_ = rz_.integers(0, Gn, 5)
        ix = np.concatenate([np.arange(int(s0_), int(s0_) + 60) % Gn for s0_ in st_])
        wb.append(_mh(_k4s(GB["sig"][:, ix], mB[:, ix], GB["E"][:, ix], GB["strat"][:, ix], GB["S"])))
    wb = np.array([w_ for w_ in wb if math.isfinite(w_)])
    ok("M13 Band von Hand nachgezogen: 200 Ziehungen, jede aus fünf Blöcken von 60 aufeinanderfolgenden Tagen (rund um den Kalender), die Tafel "
       "je Ziehung neu gezählt -- das Band des Moduls ist das 5. und das 95. Perzentil dieser Werte (90 %)",
       len(wb) == 200 and abs(band_m[0] - float(np.quantile(wb, 0.05))) < 1e-12 and abs(band_m[1] - float(np.quantile(wb, 0.95))) < 1e-12
       and band_m[0] < band_m[1] and float(np.quantile(wb, 0.025)) < band_m[0], f"Band {band_m[0]:.3f}–{band_m[1]:.3f}")
    ok("M6 Episoden: Signaltage, die mehr als h Tage auseinanderliegen, beginnen eine neue (1, 2, 3 · 20, 21 · 40 bei h = 7: drei; bei "
       "h = 20: eine; genau h Tage Abstand: dieselbe)",
       _episoden(np.array([1, 2, 3, 20, 21, 40]), 7) == 3 and _episoden(np.array([1, 2, 3, 20, 21, 40]), 20) == 1
       and _episoden(np.array([1, 8]), 7) == 1 and _episoden(np.array([1, 9]), 7) == 2 and _episoden(np.array([], dtype=int), 7) == 0)
    hp = holm([0.001, 0.02, 0.03, float("nan")]); hp2 = holm([0.04, 0.01]); hp3 = holm([0.6, 0.7])
    ok("M7 Holm von Hand: 0,001 · 0,02 · 0,03 -> 0,003 · 0,04 · 0,04 (ohne Wert bleibt ohne); 0,04 · 0,01 -> 0,04 · 0,02; nie über 1 "
       "(0,6 · 0,7 -> 1 · 1)",
       abs(hp[0] - 0.003) < 1e-12 and abs(hp[1] - 0.04) < 1e-12 and abs(hp[2] - 0.04) < 1e-12 and math.isnan(hp[3])
       and abs(hp2[0] - 0.04) < 1e-12 and abs(hp2[1] - 0.02) < 1e-12 and hp3 == [1.0, 1.0])
    basis = {"signaltage": 30, "episoden": 5, "ohne": 30, "p": 0.01}
    ok("M8 prüfbar: ab 30 Signaltagen, 5 Episoden und 30 Vergleichstagen mit einem p-Wert; 29 Signaltage, 4 Episoden, 29 Vergleichstage "
       "oder kein p-Wert -> nicht prüfbar",
       pruefbar(basis) and not pruefbar(dict(basis, signaltage=29)) and not pruefbar(dict(basis, episoden=4)) and not pruefbar(dict(basis, ohne=29))
       and not pruefbar(dict(basis, p=float("nan"))))
    ok("M9 Hälften: RR in beiden Kalenderhälften über 1 UND über dem Median der Null der Hälfte; 1,0 genügt nicht; unter der Null genügt nicht; "
       "gleich der Null genügt nicht",
       haelften_ok({"haelften": [(1.5, 1.0), (1.2, 1.1)]}) and not haelften_ok({"haelften": [(1.5, 1.0), (1.0, 0.9)]})
       and not haelften_ok({"haelften": [(1.5, 1.5), (2.0, 1.0)]}) and not haelften_ok({"haelften": [(2.0, 1.0), (1.3, 1.3)]})
       and not haelften_ok({"haelften": [(1.5, 1.0), (1.2, 1.3)]}) and not haelften_ok({"haelften": [(1.5, 1.0), (float("nan"), 1.0)]})
       and not haelften_ok({"haelften": [(1.5, 1.0)]}))
    sgH = _tage((100, 120), (200, 220), (300, 320), (500, 520), (600, 620), (700, 720), n=G); EH = _tage((100, 120), (200, 220), (300, 320), n=G)
    EH |= _tage((40, 44), (450, 454), (560, 564), (660, 664), (760, 764), n=G)
    oH = pruefen(_einfach(sgH, np.ones(G, dtype=bool), EH), 7, n_boot=0)
    ok("M10 Hälften von Hand: Der Effekt steht nur in der ersten Hälfte des Zeitraums (dort folgt auf jedes Signal das Ereignis, in der "
       "zweiten nie) -> RR der zweiten Hälfte 0, „nicht in beiden Hälften“; die Mitte liegt in der Mitte der definierten Tage",
       oH["haelften"][0][0] > 5 and oH["haelften"][1][0] == 0.0 and not haelften_ok(oH) and oH["mitte"] == 20000 + 399, f"{oH['haelften']}")

    def test_(p, **kw):
        d = {"signaltage": 100, "episoden": 10, "ohne": 500, "p": p, "haelften": [(1.5, 1.0), (1.4, 1.0)]}
        d.update(kw); return d
    Vu = {"tests": {"e7": {"r1": test_(0.001), "r2": test_(0.02), "r3": test_(0.5), "r4": test_(0.0001, signaltage=10),
                           "r5": test_(0.004, haelften=[(1.5, 1.0), (0.9, 1.0)])}, "e2": {"r1": test_(0.04), "r6": test_(0.04)}}}
    urteile(Vu, True); T7 = Vu["tests"]["e7"]; Vv = json.loads(json.dumps({"tests": {"e7": {"r1": test_(0.001)}}})); urteile(Vv, False)
    Vg = {"tests": {"e7": {"r1": test_(0.05)}, "e2": {"r1": test_(0.0499)}}}; urteile(Vg, True)
    def _m(tage, n_):
        a_ = np.zeros(n_, dtype=bool); a_[list(tage)] = True
        return a_
    zA = np.where(np.arange(40) >= 5, np.arange(40) % 10, -1).astype(np.int16); evA = np.arange(40) >= 5
    glg = np.arange(40) < 33
    dB = np.ones(40, dtype=bool); dB[1] = False
    Rg2 = {"A": {"tag0": 20000, "n": 40, "regeln": {"r1": (_m((10, 11, 30), 40), np.ones(40, dtype=bool))}, "E": {"e7": (_m((11, 31), 40), glg)},
                 "zehntel": zA, "ev": evA},
           "B": {"tag0": 20010, "n": 40, "regeln": {"r1": (_m((0,), 40), dB)}, "E": {"e7": (_m((1, 35), 40), glg)},
                 "zehntel": (np.arange(40) % 10).astype(np.int16), "ev": np.ones(40, dtype=bool)}}
    Gg = gitter(Rg2, ["A", "B"], "r1", "e7")
    ok("G1 Gitter von Hand, zwei Coins mit verschiedenem Beginn (A ab Tag 20000, B zehn Tage später): gemeinsamer Kalender von 50 Tagen; "
       "jede Reihe an ihrem Platz; definiert erst ab dem Beginn der Auswertung des Coins; gültig nur mit voller Frist und einer Klasse; "
       "jeder Coin hat seine eigenen zehn Schichten (A 0 … 9, B 10 … 19)",
       Gg["g0"] == 20000 and Gg["G"] == 50 and Gg["S"] == 20 and Gg["coins"] == ["A", "B"]
       and [int(i_) for i_ in np.nonzero(Gg["sig"][0])[0]] == [10, 11, 30] and [int(i_) for i_ in np.nonzero(Gg["sig"][1])[0]] == [10]
       and not Gg["sdef"][0][:5].any() and Gg["sdef"][0][5:40].all() and not Gg["sdef"][0][40:].any()
       and not Gg["sdef"][1][:10].any() and not Gg["sdef"][1][11] and Gg["sdef"][1][10] and Gg["sdef"][1][12:].all()
       and [int(i_) for i_ in np.nonzero(Gg["E"][1])[0]] == [11, 45] and not Gg["val"][0][:5].any() and Gg["val"][0][5:33].all()
       and not Gg["val"][0][33:].any() and Gg["val"][1][10:43].all() and not Gg["val"][1][43:].any()
       and (Gg["strat"][0][:5] == -1).all() and [int(x_) for x_ in Gg["strat"][0][5:12]] == [5, 6, 7, 8, 9, 0, 1]
       and [int(x_) for x_ in Gg["strat"][1][10:13]] == [10, 11, 12] and int(Gg["strat"][1].max()) == 19 and (Gg["strat"][1][:10] == -1).all())
    og = pruefen(Gg, 7, n_boot=0, taus=np.array([30, -30], dtype=np.int64))
    ok("G2 Prüfung auf diesem Gitter von Hand: Gezählt werden nur definierte Tage mit gültigem Ereignis -- A 28 Tage (5 … 32), B 32 Tage (0 … 32 "
       "ohne den undefinierten Tag 1); die letzten sieben Tage jedes Coins zählen nicht, obwohl sie eine Klasse haben. Tafel 1 · 3 · 1 · 55, "
       "Quote nach Signal 1 von 4, sonst 1 von 56, RR roh 14; "
       "Episoden je Coin gezählt und summiert (A zwei: 10–11 und 30; B eine) = 3; je Coin die eigene Tafel",
       og["k4"] == [1, 3, 1, 55] and og["signaltage"] == 4 and og["ohne"] == 56 and og["episoden"] == 3
       and og["p_sig"] == 1 / 4 and abs(og["p_ohne"] - 1 / 56) < 1e-15 and abs(og["rr"] - 14.0) < 1e-12
       and og["je_coin"]["A"]["k4"] == [1, 2, 1, 24] and og["je_coin"]["B"]["k4"] == [0, 1, 0, 31], f"{og['k4']}; Episoden {og['episoden']}; {og['je_coin']['A']['k4']} {og['je_coin']['B']['k4']}")
    tg_ = np.arange(200)
    Gp = _einfach(tg_ % 10 == 0, np.ones(200, dtype=bool), (tg_ % 20 == 0) | (tg_ % 20 == 5))
    op = pruefen(Gp, 7, n_boot=0, taus=np.array([20, 40, 3, -20], dtype=np.int64))
    ok("M11 p bei Gleichstand: Signal alle 10 Tage, Ereignis an jedem zweiten Signaltag und an 10 anderen Tagen (RR 9,00). Um 20 oder 40 Tage "
       "verschoben ist die Tafel dieselbe (Gleichstand, dreimal), um 3 Tage verschoben trifft das Signal kein Ereignis (RR 0). Gleichstand zählt "
       "mit: p = (1 + 3) ÷ (4 + 1)",
       op["k4"] == [10, 10, 10, 170] and abs(op["mh"] - 9.0) < 1e-12 and op["p"] == 4 / 5 and op["n_shift"] == 4, f"RR {op['mh']:.2f}, p {op['p']}")
    e_h = np.where(np.arange(400) < 200, np.arange(400) % 2 == 0, np.arange(400) % 4 == 0)
    Gh = _einfach(np.arange(400) % 4 == 0, np.ones(400, dtype=bool), e_h)
    oh = pruefen(Gh, 7, n_boot=0, taus=np.array([2], dtype=np.int64))
    ok("M12 Null je Hälfte von Hand: Um zwei Tage verschoben trifft das Signal in der ersten Hälfte nur Tage mit Ereignis (RR der Null 3,00), "
       "in der zweiten keinen einzigen (RR der Null 0) -- jede Hälfte wird gegen ihre eigene Null gestellt",
       oh["mitte"] == 20000 + 199 and oh["haelften"][0][1] == 3.0 and oh["haelften"][1][1] == 0.0 and oh["null_median"] > 0,
       f"Null der Hälften {oh['haelften'][0][1]} · {oh['haelften'][1][1]}")
    ok("U1 Urteile: Holm je Ereignis nur über die prüfbaren Regeln (vier bei E7: 0,001 -> 0,004; 0,004 -> 0,012; 0,02 -> 0,04; 0,5 bleibt), eine "
       "nicht prüfbare zählt nicht mit; belegt nur mit p Holm unter 0,05 UND beiden Hälften; E2 für sich (zwei Tests: 0,04 -> 0,08, nicht "
       "belegt); ohne vollständige Historie ist nichts belegt",
       abs(T7["r1"]["p_holm"] - 0.004) < 1e-12 and abs(T7["r5"]["p_holm"] - 0.012) < 1e-12 and abs(T7["r2"]["p_holm"] - 0.04) < 1e-12
       and T7["r1"]["belegt"] and T7["r2"]["belegt"] and not T7["r3"]["belegt"] and not T7["r4"]["pruefbar"] and math.isnan(T7["r4"]["p_holm"])
       and not T7["r5"]["belegt"] and not T7["r5"]["haelften_ok"] and abs(Vu["tests"]["e2"]["r1"]["p_holm"] - 0.08) < 1e-12
       and not Vu["tests"]["e2"]["r1"]["belegt"] and Vv["tests"]["e7"]["r1"]["bedingung"] and not Vv["tests"]["e7"]["r1"]["belegt"]
       and Vu["vollstaendig"] is True and Vv["vollstaendig"] is False)
    ok("U3 genau an der Grenze: p nach Holm von genau 0,05 genügt nicht (verlangt ist „unter 0,05“); 0,0499 genügt",
       Vg["tests"]["e7"]["r1"]["p_holm"] == 0.05 and not Vg["tests"]["e7"]["r1"]["bedingung"] and not Vg["tests"]["e7"]["r1"]["belegt"]
       and Vg["tests"]["e2"]["r1"]["belegt"] is True)
    ok("U2 Urteil in Worten: belegt; nicht prüfbar mit den fehlenden Zahlen; nicht belegt mit dem Grund (p nach Holm, Hälften); ohne "
       "vollständige Historie „vorläufig erfüllt“",
       urteil_wort(T7["r1"], True) == "BELEGT" and "10 Signaltage, gebraucht 30" in urteil_wort(T7["r4"], True)
       and urteil_wort(T7["r3"], True).startswith("nicht belegt (p nach Holm") and "nicht in beiden Hälften" in urteil_wort(T7["r5"], True)
       and "vorläufig" in urteil_wort(Vv["tests"]["e7"]["r1"], False)
       and urteil_wort({"pruefbar": False, "signaltage": 40, "episoden": 3, "ohne": 500}, True) == "nicht prüfbar (3 Episoden, gebraucht 5)"
       and urteil_wort({"pruefbar": False, "signaltage": 40, "episoden": 9, "ohne": 12}, True) == "nicht prüfbar (12 Vergleichstage, gebraucht 30)"
       and urteil_wort({"pruefbar": False, "signaltage": 40, "episoden": 9, "ohne": 500}, True) == "nicht prüfbar (kein Risikoverhältnis in den Schichten)",
       urteil_wort(T7["r5"], True))

    V0 = auswerten(W0["R"], True, n_boot=0, saat=1)
    e0, gl0 = W0["R"]["BTC"]["E"]["e7"]; g0_ = gl0 & W0["R"]["BTC"]["ev"]
    e2_, gl2 = W0["R"]["ETH"]["E"]["e2"]; g2_ = gl2 & W0["R"]["ETH"]["ev"]
    epi7 = [V0["tests"]["e7"][r_[0]]["episoden"] for r_ in REGELN]; epi2 = [V0["tests"]["e2"][r_[0]]["episoden"] for r_ in REGELN]
    ok("A1 Auswertung einer Welt: jede Regel gegen E7 mit der Frist 7 und gegen E2 mit der Frist 2 (kürzere Frist -> nie weniger Episoden, "
       "bei mindestens einer Regel mehr); Grundquote je Coin = Ereignisse ÷ gültige Auswertungstage (nicht ÷ alle Tage der Reihe)",
       all(V0["tests"]["e7"][r_[0]]["h"] == 7 and V0["tests"]["e2"][r_[0]]["h"] == 2 for r_ in REGELN)
       and all(b_ >= a_ for a_, b_ in zip(epi7, epi2)) and any(b_ > a_ for a_, b_ in zip(epi7, epi2))
       and V0["basis"]["BTC"]["e7"]["gueltig"] == int(g0_.sum()) < W0["R"]["BTC"]["n"]
       and abs(V0["basis"]["BTC"]["e7"]["quote"] - float((e0 & g0_).sum()) / float(g0_.sum())) < 1e-15
       and abs(V0["basis"]["ETH"]["e2"]["quote"] - float((e2_ & g2_).sum()) / float(g2_.sum())) < 1e-15
       and V0["basis"]["BTC"]["e7"]["quote"] > float((e0 & g0_).sum()) / W0["R"]["BTC"]["n"],
       f"Episoden E7 {epi7}, E2 {epi2}; Grundquote BTC {V0['basis']['BTC']['e7']['quote']:.4f} aus {int(g0_.sum())} von {W0['R']['BTC']['n']} Tagen")
    kqh = np.full(120, 1.0); kqh[119] = 3.2; kqn = kqh.copy(); kqn[119] = np.nan
    Sh = stand_heute({"BTC": reihen_bauen("BTC", _tafel(120, konten=kqh), None, _KAL_LEER, np.ones(120))})
    Sn = stand_heute({"BTC": reihen_bauen("BTC", _tafel(120, konten=kqn), None, _KAL_LEER, np.ones(120))})
    Ld_ = {"coins": {"BTC": {"fertig": True}, "ETH": {"fertig": False}, "ZEC": {"fertig": False}},
           "kerzen": {("spot", "BTCUSDT"): {"offen": 3, "widerspruch": False, "ohne_zeilen": 0},
                      ("um", "BTCUSDT"): {"offen": 1, "widerspruch": False, "ohne_zeilen": 0},
                      ("um", "ETHUSDT"): {"offen": 0, "widerspruch": True, "ohne_zeilen": 2}}, "vollstaendig": False}
    ok("L1 Ladestand in Worten, von Hand: Kennzahlen der nicht fertigen Coins; Kerzen mit mehr als einem offenen Monat; Monatsdateien ohne "
       "Zeilen; ein einzelner offener Monat (der Vormonat) zählt nicht; nichts offen -> leer; mehr als fünf Teile werden gekürzt; der Markt "
       "steht in Worten dabei (seit 23.124: „BTCUSDT (Spot)“, „ETHUSDT (Perp)“ statt der Kürzel „spot“ und „um“)",
       ladestand_offen(Ld_) == "Kennzahlen ETH, ZEC; Kerzen BTCUSDT (Spot): 3 Monate offen; Kerzen ETHUSDT (Perp): 2 Monatsdatei(en) ohne Zeilen"
       and ladestand_offen({"coins": {"BTC": {"fertig": True}}, "kerzen": {("um", "BTCUSDT"): {"offen": 1}}}) == ""
       and ladestand_offen({"coins": {"BTC": {"fertig": True}}, "kerzen": {("um", "BTCUSDT"): {"offen": 2}}}) == "Kerzen BTCUSDT (Perp): 2 Monate offen"
       and ladestand_offen({"kerzen": {("coinm", "BTCUSD"): {"offen": 2}, "x": {"offen": 5}}}) == "Kerzen BTCUSD (coinm): 2 Monate offen; Kerzen x: 5 Monate offen"
       and ladestand_offen(None) == "kein Ladestand lesbar"
       and ladestand_offen({"kerzen": {("um", f"S{i_}"): {"offen": 4} for i_ in range(7)}}).endswith("; und 2 weitere"),
       ladestand_offen(Ld_))
    ok("A2 Stand heute von Hand: Es gilt der letzte Tag der Reihe (Kontenquote am letzten Tag 3,20, davor 1,00 -> R1 an); fehlt der Wert am "
       "letzten Tag, steht „ohne Angabe“ da (nicht „aus“); Regeln ohne Daten ebenso",
       Sh["BTC"]["tag"] == 20000 + 119 and Sh["BTC"]["regeln"]["r1"] == {"an": True, "wert": "Kontenquote 3,20"}
       and Sn["BTC"]["regeln"]["r1"]["an"] is None and Sh["BTC"]["regeln"]["r3"]["an"] is None and Sh["BTC"]["regeln"]["r6"]["an"] is None,
       f"{Sh['BTC']['regeln']['r1']} · {Sn['BTC']['regeln']['r1']}")

    # ---- erfundene Märkte: Nullwelten, eingepflanzter Effekt, Falle
    Wn = [auswerten(welt_bauen(900 + i, n=1800)["R"], True, n_boot=0, saat=900 + i) for i in range(6)]
    falsch = sum(1 for V_ in Wn for k_ in V_["tests"] if any(o_["belegt"] for o_ in V_["tests"][k_].values()))
    pruefb = sum(1 for V_ in Wn for k_ in V_["tests"] for o_ in V_["tests"][k_].values() if o_["pruefbar"])
    ok("N1 Nullwelten: in sechs erfundenen Märkten ohne Effekt (zwei Coins, sieben Regeln, zwei Ereignisse) ist in höchstens einer der zwölf "
       "Familien (Markt mal Ereignis) eine Regel belegt -- auf 200 Märkten gemessen sind es 6 bis 7 % der Familien; fast alle Tests sind prüfbar",
       falsch <= 1 and pruefb >= 70, f"{falsch} von 12 Familien mit einer belegten Regel, {pruefb} von 84 Tests prüfbar")
    Wp = [auswerten(welt_bauen(700 + i, n=1800, pflanz="r1", q=0.10)["R"], True, n_boot=0, saat=700 + i) for i in range(5)]
    tref = sum(1 for V_ in Wp if V_["tests"]["e7"]["r1"]["belegt"]); rrp = float(np.median([V_["tests"]["e7"]["r1"]["mh"] for V_ in Wp]))
    fremd = sum(1 for V_ in Wp for rk_, o_ in V_["tests"]["e7"].items() if rk_ != "r1" and o_["belegt"])
    ok("N2 eingepflanzter Effekt: Folgt auf Signaltage von R1 mit 10 % Wahrscheinlichkeit am nächsten Tag ein Tief 12 % · Faktor unter dem "
       "Schluss, ist R1 in mindestens vier von fünf Märkten belegt (RR im Median über 1,5); in diesen fünf Märkten ist keine andere Regel "
       "belegt (auf 80 Märkten gemessen wird R7, dessen Index die Kontenquote enthält, in 9 bis 18 % mit belegt)",
       tref >= 4 and rrp > 1.5 and fremd == 0, f"R1 belegt in {tref} von 5, RR Median {rrp:.2f}, andere {fremd}")
    nz = nachweis_zeilen(); nzt = "\n".join(_umbruch(nz))
    ok("N4 Nachweisgrenze im Bericht: die Messung vom 24.11.2026 mit ihren Zahlen (ohne Effekt 6 % und 7 %, unter der Grenze des Konzepts von "
       "10 %; häufiges und seltenes Zeichen je drei Stärken mit dem Anteil belegter Märkte für beide Ereignisse; R7 mit belegt in 14 und 7 von "
       "80 Märkten); Anteile als ganze Prozent, wo sie stimmen, sonst mit einer Stelle; keine Zeile über 150 Zeichen",
       nz[0] == "Nachweisgrenze (gemessen am 24.11.2026 auf je 200 erfundenen Märkten: zwei Coins, je 2.520 Tage, sieben Regeln):"
       and "in 6 % der Märkte (E7) und in 7 % (E2) -- zulässig nach Konzept: höchstens 10 %" in nz[1]
       and nz[3].endswith("(rund 430 Signaltage): RR 1,8 → 49,5 % · 44,5 %   RR 2,7 bzw. 2,8 → 94 % · 96 %   RR 3,4 bzw. 3,8 → 100 % · 99,5 %")
       and nz[4].endswith("(rund 100 Signaltage): RR 1,8 bzw. 1,7 → 16 % · 13,5 %   RR 2,6 → 37,5 % · 41,5 %   RR 3,3 bzw. 3,7 → 65 % · 67,5 %")
       and "in 14 von 80 Märkten (E7) und in 7 von 80 (E2) mit belegt" in " ".join(nzt.split()) and len(nz) == 7
       and "R7 hängt an R1 und R5: Der Druck-Index enthält Kontenquote und Open Interest." in " ".join(nzt.split())
       and "„R7 belegt“ neben R1 oder R5 ist darum kein zweiter, eigener Beleg." in " ".join(nzt.split())
       and "Folge: Ein seltenes Zeichen mit einem echten RR um 2 bleibt meist unbelegt" in nzt
       and max(NACHWEIS_MESSUNG["ohne"].values()) <= NACHWEIS_GRENZE and max(len(z_) for z_ in nzt.split("\n")) <= ZEILE_MAX
       and _anteil(0.06) == "6 %" and _anteil(0.495) == "49,5 %" and _anteil(1.0) == "100 %" and _tsd(2520) == "2.520"
       and "@@" not in nzt, nz[3].strip()[:140])
    Wf = welt_bauen(41, n=1800); Rf = Wf["R"]
    for c_ in Rf:
        hoch = Rf[c_]["zehntel"] == 9
        Rf[c_]["regeln"]["r1"] = (hoch, np.ones(Rf[c_]["n"], dtype=bool))
    of = pruefen(gitter(Rf, list(Rf), "r1", "e7"), 7, n_boot=0)
    ok("N3 Falle: Ein Zeichen, das nur die unruhigsten Tage markiert (oberstes Zehntel der Schwankung), hat roh ein hohes RR -- geschichtet "
       "bleibt nichts, was sich prüfen ließe (kein Risikoverhältnis in den Schichten)",
       of["rr"] > 1.5 and not pruefbar(of) and math.isnan(of["mh"]), f"roh {of['rr']:.2f}, geschichtet {of['mh']}")

    # ---- Aufschlag für belegte Zeichen (Regel A, 23.124)
    try:
        _proben_auf(ok)
    except Exception as e_:  # noqa: BLE001 -- eine Ausnahme ist eine gescheiterte Probe mit Namen, kein Abbruch des Selbsttests
        import traceback
        ok("RA Proben zum Aufschlag ohne Ausnahme", False, f"{type(e_).__name__}: {e_} -- {traceback.format_exc().splitlines()[-3].strip()}")

    # ---- Ende zu Ende auf erzeugten Dateien
    tmp = tempfile.mkdtemp(prefix="hl_regeln_")
    alt_env = {k_: os.environ.get(k_) for k_ in ("HL_RADAR_DB", "HL_HEBEL_DB", "HL_SWING_DB", "HL_MAKRO_DB")}
    try:
        for k_ in alt_env:
            os.environ.pop(k_, None)
        v1 = os.path.join(tmp, "voll"); os.makedirs(v1)
        jetzt_d = int(time.time())
        db1 = demo_dateien(v1, saat=5, pflanz="r1", q=0.10, jetzt=jetzt_d)
        Ld = laden(db1)
        import hl_hebel as HBd
        import hl_volatil as VLd
        t0d = HBd.tag_von("2020-01-01")
        Wd = welt_bauen(5, n=jetzt_d // TAG - t0d, pflanz="r1", q=0.10, tag0=t0d)
        ok("D0 Termine aus den Dateien: Verbraucherpreise und Arbeitsmarktbericht je aus ihrer eigenen Reihe in makro.db (nicht vertauscht, "
           "nicht doppelt), Fed-Entscheide aus dem Kalender des Pakets; Zeitraum vom spätesten ersten bis zum frühesten letzten Termin",
           Ld["kal"]["cpi"] == sorted(int(t_) for t_ in Wd["kal"]["cpi"]) and Ld["kal"]["nfp"] == sorted(int(t_) for t_ in Wd["kal"]["nfp"])
           and Ld["kal"]["cpi"] != Ld["kal"]["nfp"] and Ld["kal"]["fed"] == sorted(int(t_) for t_ in VLd.fed_tage())
           and Ld["kal"]["von"] == max(Ld["kal"][k_][0] for k_ in ("cpi", "nfp", "fed")) and Ld["kal"]["bis"] == min(Ld["kal"][k_][-1] for k_ in ("cpi", "nfp", "fed")),
           f"{len(Ld['kal']['cpi'])} · {len(Ld['kal']['nfp'])} · {len(Ld['kal']['fed'])} Termine")
        ok("D1 Laden aus den Dateien: BTC und ETH mit allen sieben Regeln, Ladestand vollständig; ETH mit Faktor über 1 ab dem Monat nach "
           "180 gemeinsamen Tagen (vorher ungültig); Termine aus makro.db und dem Fed-Kalender",
           sorted(Ld["R"]) == ["BTC", "ETH"] and Ld["voll"] and all(len(Ld["R"][c_]["regeln"]) == 7 for c_ in Ld["R"])
           and not np.isfinite(Ld["R"]["ETH"]["f1"][:150]).any() and np.nanmin(Ld["R"]["ETH"]["f1"]) >= 1.0 and np.isfinite(Ld["R"]["ETH"]["f1"][400:]).all()
           and abs(float(np.nanmedian(Ld["R"]["ETH"]["f1"])) - 1.32) < 0.15                    # ETH schwankt in der Welt 0,037 ÷ 0,028 = 1,32-mal so stark
           and (Ld["R"]["BTC"]["f1"] == 1.0).all() and Ld["kal"]["von"] is not None and Ld["R"]["BTC"]["regeln"]["r6"][0].sum() > 100,
           f"Faktor ETH {np.nanmedian(Ld['R']['ETH']['f1']):.2f}; R6 definiert ab {_tag_txt(Ld['kal']['von'])}")
        Sd = auf_stand(db1, ["r7", "r1"]); Dd = auf_laden(db1, ["r1", "r7"], jetzt_d // TAG); m_akt = monatserster(jetzt_d // TAG)
        zb_ = auf_zustand(Ld["R"]["BTC"], ["r1", "r7"]); ze_ = auf_zustand(Ld["R"]["ETH"], ["r1", "r7"])
        ok("D1b Regel A auf den Dateien: Der Stand der belegten Zeichen gilt dem letzten Tag der Reihen (gestern) und nennt je Coin Nummer "
           "und Regel -- dieselbe wie der Zustand je Tag; die Daten für den Rückblick tragen den Zustand jedes Tages und Faktoren bis zum "
           "laufenden Monat; das eingepflanzte R1 hat dort ein Chancenverhältnis weit über 1 und damit einen Faktor über 1,5 (höchstens 3)",
           Sd["regeln"] == ["r1", "r7"] and sorted(Sd["coins"]) == ["BTC", "ETH"] and Sd["coins"]["BTC"]["tag"] == jetzt_d // TAG - 1 == Sd["coins"]["ETH"]["tag"]
           and Sd["coins"]["BTC"]["k"] == int(zb_[-1]) and Sd["coins"]["ETH"]["k"] == int(ze_[-1])
           and Sd["coins"]["BTC"]["regel"] == {1: "r1", 2: "r7"}.get(int(zb_[-1]))
           and np.array_equal(Dd["coins"]["BTC"]["zustand"], zb_) and np.array_equal(Dd["coins"]["ETH"]["zustand"], ze_)
           and int((zb_ == 1).sum()) > 30 and int((zb_ == 2).sum()) > 30 and int((zb_ == 0).sum()) > 1000
           and max(Dd["monate"]) == m_akt and min(Dd["monate"]) == monatserster(t0d) and isinstance(Dd["fehlt"], list)
           and Dd["monate"][m_akt]["n"]["r1"]["or"] > 2.0 and 1.5 < Dd["monate"][m_akt]["f"]["r1"] <= 3.0 and Dd["monate"][m_akt]["tage"] > 2000
           and Dd["monate"][min(Dd["monate"])]["f"] == {"r1": None, "r7": None},
           f"Stand {Sd.get('coins')}; laufender Monat {Dd['monate'][m_akt]['n']}, Faktoren {Dd['monate'][m_akt]['f']}")
        V1 = holen(db1, n_boot=200)
        t1 = text(V1)
        ok("D2 Debug 163 Ende zu Ende: rechnet, legt das Urteil in radar.db ab (vollständige Historie) und zeigt es; das eingepflanzte R1 ist "
           "für E7 belegt; der Bericht nennt Regeln, Maß, beide Ereignisse, den Stand von heute und die Nachweisgrenze; keine Zeile über 150 Zeichen",
           V1["abgelegt"] and not V1["aus_ablage"] and V1["tests"]["e7"]["r1"]["belegt"] and "== Ereignis E7" in t1 and "== Ereignis E2" in t1
           and "         Urteil R1: BELEGT" in t1.split("\n") and "Stand heute" in t1 and "Nachweisgrenze (gemessen am 24.11.2026" in t1
           and "in radar.db abgelegt" in t1 and t1.count("         Urteil R") == 14 and "(U308, Debug 163) · Modul " in t1.split("\n")[0]
           and " · gerechnet am " in t1.split("\n")[0]
           and any(z_.startswith("ERGEBNIS: −10 % · Faktor in 7 Tagen -- belegt: R1") and " · −7 % · Faktor in 48 Stunden -- " in z_ for z_ in t1.split("\n"))
           and max(len(z_) for z_ in t1.split("\n")) <= ZEILE_MAX and json.dumps(V1, allow_nan=False) is not None,
           f"{len(t1.splitlines())} Zeilen, längste {max(len(z_) for z_ in t1.split(chr(10)))}")
        import hl_hebel as HB
        hb = HB.verbinden(os.path.join(v1, "hebel.db")); hb.execute("UPDATE hb_metrics SET konten = 1.0"); hb.close()   # die Daten ändern sich danach
        V2 = holen(db1, n_boot=200); t2 = text(V2)
        Sd2 = auf_stand(db1, ["r1"])
        ok("D3c der Stand der Zeichen für die Karte ist frisch wie „Stand heute“: Nach der Änderung der Daten (alle Kontenquoten auf 1) "
           "steht R1 für BTC und ETH nicht mehr an",
           Sd2["regeln"] == ["r1"] and all(Sd2["coins"][c_]["k"] == 0 and Sd2["coins"][c_]["regel"] is None for c_ in ("BTC", "ETH")),
           f"{Sd2.get('coins')}")
        ok("D3 kein stilles Neurechnen: Der zweite Lauf zeigt das abgelegte Urteil -- auch nachdem sich die Daten geändert haben (alle "
           "Kontenquoten auf 1); nur „Stand heute“ ist frisch (R1 aus)",
           V2["aus_ablage"] and V2["tests"]["e7"]["r1"]["belegt"] and V2["tests"]["e7"]["r1"]["p"] == V1["tests"]["e7"]["r1"]["p"]
           and (((V2.get("stand") or {}).get("BTC") or {}).get("regeln") or {}).get("r1", {}).get("an") is False and "abgelegte Urteil" in t2
           and "Kontenquote 1,00" in t2 and "stand" not in (abgelegt(db1) or {"stand": 1}))
        import hl_radar as RDf
        alt_v = abgelegt(db1)
        cf = RDf.verbinden(RDf.pfad(db1))
        try:
            RDf.meta_setzen(cf, "regeln", dict(alt_v or {}, fassung=FASSUNG + 1))
            fremd_f = abgelegt(db1)
            RDf.meta_setzen(cf, "regeln", dict(alt_v or {}, vollstaendig=False))
            fremd_v = abgelegt(db1)
            RDf.meta_setzen(cf, "regeln", alt_v)
        finally:
            cf.close()
        ok("D3b ein abgelegtes Urteil einer anderen Fassung der Regeln oder eines ohne vollständige Historie gilt nicht (der nächste Lauf "
           "rechnet dann neu); das eigene gilt wieder",
           alt_v is not None and fremd_f is None and fremd_v is None and abgelegt(db1) is not None and abgelegt(db1)["ts"] == alt_v["ts"])
        import hl_radar as RDm
        uk = urteil_kurz(db1)
        ok("D4 Kurzform für die Karte (aus hl_radar): je Ereignis die belegten und die prüfbaren Regeln; der Satz der Karte nennt R1 für 7 Tage; "
           "die Fassung der Regeln ist dieselbe wie im Radar; ohne abgelegtes Urteil nichts",
           uk is not None and "r1" in uk["belegt"]["e7"] and set(uk["belegt"]) == {"e7", "e2"} and set(uk["pruefbar"]) == {"e7", "e2"}
           and set(uk["belegt"]["e7"]) <= set(uk["pruefbar"]["e7"]) <= {rk for rk, *_r in REGELN} and uk["fassung"] == FASSUNG == RDm.REGELN_FASSUNG
           and uk["ts"] == V1["ts"] and "für 7 Tage belegt: " in RDm.regeln_satz(uk) and "R1 Kontenquote" in RDm.regeln_satz(uk).split("für 48 Stunden")[0]
           and urteil_kurz(os.path.join(tmp, "nichts", "hl_liq.db")) is None, f"{uk and uk['belegt']}")
        v3 = os.path.join(tmp, "halb"); os.makedirs(v3)
        db3 = demo_dateien(v3, saat=5, fertig=False)
        V3 = holen(db3, n_boot=0); t3 = text(V3)
        ok("D5 unvollständige Historie (BTC noch nicht fertig geladen): alles vorläufig, nichts belegt, nichts abgelegt; der Bericht sagt es",
           V3["vollstaendig"] is False and not V3["abgelegt"] and abgelegt(db3) is None and "VORLÄUFIG" in t3 and "ERGEBNIS:" not in t3
           and "BELEGT" not in t3 and t3.count("         Urteil R") == 14
           and not any(o_["belegt"] for k_ in V3["tests"] for o_ in V3["tests"][k_].values()))
        import hl_hebel as HBl
        Ld1 = HBl.daten_laden(db1, log=lambda s_: None).get("laden"); Ld3 = HBl.daten_laden(db3, log=lambda s_: None).get("laden")
        t3e = " ".join(z_.strip() for z_ in t3.split("\n"))
        ok("D5b die Zeile „VORLÄUFIG“ nennt, was am Ladestand der Hebel-Studie offen ist -- gelesen aus dem, was hl_hebel selbst als Ladestand "
           "liefert: hier „Kennzahlen BTC“; bei vollständigem Ladestand ist nichts offen (leer genau dann, wenn hl_hebel „vollständig“ sagt); "
           "der Satz nennt den Lauf, der einen Tag nach dem Einspielen von selbst kommt",
           isinstance(Ld1, dict) and isinstance(Ld3, dict) and Ld1["vollstaendig"] is True and Ld3["vollstaendig"] is False
           and ladestand_offen(Ld1) == "" and ladestand_offen(Ld3) == "Kennzahlen BTC" and V3.get("laden_offen") == "Kennzahlen BTC"
           and V1.get("laden_offen") == ""
           and "noch nicht vollständig geladen (offen: Kennzahlen BTC) -- nichts ist abgelegt" in t3e
           and "(einen Tag nach dem Einspielen von 23.123 startet er einmal von selbst)" in t3e and "offen:" not in text(V1),
           f"{ladestand_offen(Ld3)!r} · {V3.get('laden_offen')!r}")
        v4 = os.path.join(tmp, "leer"); os.makedirs(v4)
        V4 = holen(os.path.join(v4, "hl_liq.db"), n_boot=0); t4 = text(V4)
        ok("D6 ohne hebel.db: kein Absturz, „KEIN ERGEBNIS“ mit dem Grund, nichts abgelegt (radar.db wird nicht angelegt)",
           "KEIN ERGEBNIS" in t4 and not V4["abgelegt"] and not os.path.exists(os.path.join(v4, "radar.db")), t4.split("\n")[2][:90])
        hier = os.path.dirname(os.path.abspath(__file__))
        pr = subprocess.run([sys.executable, "-B", os.path.join(hier, "hl_radar_regeln.py"), "--text", "--db", db1], capture_output=True, text=True,
                            timeout=300, cwd=hier, env={k_: v_ for k_, v_ in os.environ.items() if not k_.startswith("HL_")})
        ok("D7 Aufruf wie im Dashboard (hl_radar_regeln.py --text --db …): Exit 0, der Bericht mit dem abgelegten Urteil",
           pr.returncode == 0 and "abgelegte Urteil" in pr.stdout and "== Ereignis E7" in pr.stdout, (pr.stderr or "")[-200:])
    except Exception as e_:  # noqa: BLE001 -- eine Ausnahme ist eine gescheiterte Probe mit Namen, kein Abbruch des Selbsttests
        import traceback
        ok("D Proben auf erzeugten Dateien ohne Ausnahme", False, f"{type(e_).__name__}: {e_} -- {traceback.format_exc().splitlines()[-3].strip()}")
    finally:
        for k_, v_ in alt_env.items():
            if v_ is not None:
                os.environ[k_] = v_
        shutil.rmtree(tmp, ignore_errors=True)

    # ---- Vertrag
    ok("V1 Zahlen des Konzepts im Modul (festgehalten): E7 10 % in 7 Tagen, E2 7 % in 2 Tagen; Kontenquote 3; Zehntel 0,90 gegen 365 Tage "
       "(mindestens 180) und gegen 90 Tage (mindestens 60); Stillstand ½ σ·√7; Funding 15 %; 30 Signaltage, 5 Episoden, 30 Vergleichstage; "
       "672 Verschiebungen; Blöcke 60 Tage, 1000 Ziehungen; α 0,05; zehn Schichten; Urteil für BTC und ETH",
       EREIGNISSE[0][:3] == ("e7", 7, 0.10) and EREIGNISSE[1][:3] == ("e2", 2, 0.07) and KONTEN_SCHWELLE == 3.0 and R2_PZ == R5_PZ == R7_PZ == 0.90
       and PZ_LANG == (365, 180) and PZ_KURZ == (90, 60) and R2_STILL == 0.5 and R3_FUNDING == 0.15
       and (MIN_SIGNALTAGE, MIN_EPISODEN, MIN_OHNE) == (30, 5, 30) and len(shifts()) == 672 and (BLOCK, N_BOOT, ALPHA, ZEHNTEL) == (60, 1000, 0.05, 10)
       and COINS_URTEIL == ("BTC", "ETH") and [r_[0] for r_ in REGELN] == ["r1", "r2", "r3", "r4", "r5", "r6", "r7"])
    ok("V2 dieselben Ereignisse wie die Karte: Abstand und Frist aus hl_radar (10 % in 7 Tagen, 7 % in 2 Tagen); Debug-Nummern 163 (Lauf) "
       "und 164 (Selbsttest), die Fassung der Regeln und ihre Namen wie im Radar; beide Module tragen dieselbe Version",
       all(RD.EREIGNIS[k_]["tage"] == h_ and RD.EREIGNIS[k_]["x"] == x_ for k_, h_, x_, _ in EREIGNISSE)
       and (DEBUG_NR, DEBUG_NR_TEST) == (RD.DEBUG_NR_REGELN, RD.DEBUG_NR_REGELN_TEST) == (163, 164) and FASSUNG == RD.REGELN_FASSUNG
       and RD.REGELN_NAMEN == {r_[0]: r_[2] for r_ in REGELN}
       and VERSION_MODUL == RD.VERSION_MODUL)
    kpf = os.path.join(os.path.dirname(os.path.abspath(__file__)), "KONZEPT_Risikoradar.md")
    if os.path.exists(kpf):
        kz = " ".join(open(kpf, encoding="utf-8").read().split())
        ok("V3 dieselben Zahlen stehen im Konzept (KONZEPT_Risikoradar.md neben dem Modul, Abschnitte 5 und 13): Regeln, Prüfbarkeit, Null, "
           "Band, Präzisierungen und die gemessene Nachweisgrenze",
           all(t_ in kz for t_ in ("Kontenquote ≥ 3", "auf ein Jahr gerechnet ≥ 15 %", "Perzentil ≥ 0,90 der 90 Tage davor", "672 Verschiebungen",
                                   "60-Tage-Blöcke", "1000 Ziehungen", "mindestens 30 Signaltage, 5 Episoden", "30 Vergleichstage",
                                   "p nach Holm < 0,05", "Mittelrang ≥ 0,90 gegen die 365 Tage davor, mindestens 180 Werte",
                                   "gegen 90 Tage davor, mindestens 60", "ab 01.09.2020", "für BTC und ETH zusammen 20 Schichten",
                                   "| ohne Effekt: irgendeine der sieben Regeln „belegt“ | 6 % | 7 % |",
                                   "| häufiges Zeichen (rund 430 Signaltage), RR 1,8 | 49,5 % | 44,5 % |",
                                   "| seltenes Zeichen, RR 3,3 bzw. 3,7 | 65 % | 67,5 % |", "in 14 von 80 Märkten (E7) und in 7 von 80 (E2)")),
           f"{len(kz)} Zeichen")
    else:
        ok("V3 Konzept nicht geprüft: KONZEPT_Risikoradar.md liegt nicht neben dem Modul", True)
    print(f"hl_radar_regeln -- Selbsttest: {gut[0]} von {gut[1]} Proben bestanden", flush=True)
    return gut[0] == gut[1]


def haupt(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    db_ = argv[argv.index("--db") + 1] if "--db" in argv else os.environ.get("HL_DB", "hl_liq.db")
    if "--selbsttest" in argv:
        return 0 if selbsttest() else 1
    if "--text" in argv:
        print(text(holen(db_, log=lambda s: print(s, flush=True))))
        return 0
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(haupt())
