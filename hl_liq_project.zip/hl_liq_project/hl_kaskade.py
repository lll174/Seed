#!/usr/bin/env python3
"""
hl_kaskade.py -- Kaskaden-Gleichung (KONZEPT_Fusion.md, Stufe 2b; 04.10.2026, Version 2026-09-23.43). Alles im SCHATTEN:
nichts davon wirkt auf die angezeigte Prognose, auf v1, v2 oder v3.

Frage: Wie weit trägt der erzwungene Fluss aus Liquidationen eine Bewegung, wenn der Kurs Cluster der Heatmap erreicht?

1. WURZELGESETZ DER MARKTWIRKUNG (Tóth u. a. 2011; Bouchaud u. a. 2018)
       I(Q) = Y · σ_Tag · √(Q / V_Tag)            Kursverschiebung (Log-Rendite) durch einen Fluss Q (USD)
   σ_Tag Tagesschwankung (15-min-Renditen der letzten 7 Tage), V_Tag Tagesumsatz (24 × Median-Stundenvolumen) -- dieselben
   Größen wie im Heatmap-Anker (hl_anker.Markt). Y liegt für gewöhnliche Großaufträge bei 0,5–1; für Liquidationen (Markt-
   Aufträge in Serie) ist es unbekannt, und die Heatmap sieht nur die verfolgten Konten. Deshalb wird Y je Coin geschätzt und
   ist ein effektiver Wert.

2. KASKADE ALS FIXPUNKT
   Tiefe u = ln(P0 / Kurs) unter dem Kurs beim Heatmap-Stand, Q(u) = Notional der Long-Liquidationscluster bis zur Tiefe u.
   Ein exogener Ausschlag u_exo endet bei der kleinsten Lösung u ≥ u_exo von    u = u_exo + I(Q(u)).
   Spiegelbildlich nach oben mit den Short-Clustern.

3. GESCHLOSSENE FORM: P(Rutsch ≥ m binnen h)
   Um die Tiefe m zu erreichen, braucht der Markt den exogenen Ausschlag
       H(m) = max( max_{k: d_k ≤ m} (d_k − I(Q_{k−1})),  m − I(Q(m)) )
   (d_k Tiefe des k-ten Clusters, Q_{k−1} Fluss aller Cluster davor; Kaskade endet jenseits von m  ⇔  u_exo ≥ H(m)).
   Mit dem Reflexionsprinzip für den größten exogenen Ausschlag binnen h:
       P(Rutsch ≥ m binnen h) = 2 · (1 − Φ(H(m) / (c · σ_h)))
   Ohne Kaskaden (Y = 0) ist H(m) = m: der reine Zufallsweg. c gleicht die Schwankung ab (geschätzt, 0,4–1,6).
   GEMISCHTE SCHWANKUNG (seit 23.44, Modell v2): σ_h kommt aus 7 Tagen und passt nicht zu jeder Stunde -- in ruhigen Stunden
   ist die wahre Schwankung kleiner, in heißen größer. Auf dem Pi (04.10., 6 Coins, 1 h und 4 h) kamen Ausschläge ≥ 2 σ deshalb
   rund doppelt so oft vor wie mit dem Reflexionsprinzip allein vorhergesagt, Ausschläge ≥ 1 σ seltener. Darum wird über die
   wahre Schwankung gemischt (log-normal um c, Streuung τ):
       P(Rutsch ≥ m binnen h) = Σ_k w_k(τ) · erfc(H(m) / (c · e^{k·δ} · σ_h · √2)),   δ = 0,05, w_k ∝ exp(−(kδ)² / (2τ²))
   τ = 0 ist das Reflexionsprinzip. c und die Mischung liegen auf demselben log-Raster: Jede Kombination (c, τ) ist eine
   gewichtete Summe derselben erfc-Werte (eine Matrix-Multiplikation). Der Treiber „Kaskaden-Asymmetrie“ und der Kipppunkt
   bleiben beim festen Gauß-Ansatz (Y = 1, c = 1): Beide werden vorwärts gemessen (Familie „Kaskaden“, Labor), ihre Reihe
   muss vergleichbar bleiben.

4. KALIBRIERUNG je Coin und Horizont (1 h, 4 h) über die ganze Historie (bis 90 Tage)
   Je Block (erster Heatmap-Stand im Block) und Seite die Ereignisse „Ausschlag ≥ k · σ_h“ für k = 0,5; 1; 1,5; 2; 3,
   Log-Verlust. Y ∈ {0; 0,25; 0,5; 1; 2; 4; 8}, c ∈ [0,4; 1,6] (log-Raster), τ ∈ {0; 0,3; 0,6; 0,9} -- c und τ je Y auf den
   Trainingsblöcken. Geblockte Kreuzvalidierung über die Zeit (5 Folds, Embargo
   ein Block), 1-SE-Regel mit Vorrang für das KLEINERE Y (Standardfehler gepaart, Tage als Klumpen). BELEGT erst, wenn Y > 0
   gewählt ist, der Abstand zu Y = 0 mehr als 2 Standardfehler beträgt, das Placebo kein Y > 0 findet UND der Seitenspiegel
   um mehr als 2 Standardfehler schlechter ist.
   Placebo: dieselbe Rechnung mit der Heatmap von drei Tagen vorher -- echte Cluster, falsche Zeit.
   Seitenspiegel: dieselben Cluster mit vertauschten Seiten. Liegen Cluster nahe am Kurs, ist die Schwankung oft ohnehin höher,
   auf BEIDEN Seiten; das ist keine Kaskaden-Mechanik. Nur wenn die Seite zählt, ist es eine.

5. SCHATTEN-TREIBER „Kaskaden-Asymmetrie“ = (Mehrweg oben − Mehrweg unten) / (Mehrweg oben + unten + 0,1)
   Mehrweg = erwarteter zusätzlicher Ausschlag binnen 4 h durch Kaskaden, in σ_4h, mit FESTEM Y = 1 (Literaturwert) und c = 1,
   damit die Reihe über die Zeit vergleichbar bleibt. Gewicht 0 in v1, nicht in v2 und v3; Familie „Kaskaden“ im
   Parallelbetrieb der Treiberfamilien. Ob die Asymmetrie die RICHTUNG vorhersagt, ist offen -- eine sichere Rutschgefahr
   nach unten kann im Mittel durch mehr kleine Anstiege ausgeglichen sein (Martingal mit Schiefe). Das misst die Bilanz.

Selbsttest (Installationsschritt): python3 hl_kaskade.py --nulltest
Stand je Coin (Debug):             python3 hl_kaskade.py --stand --db PFAD
"""
import bisect
import json
import math
import os
import sqlite3
import sys
import time

import numpy as np

import hl_forecast as F

VERSION = 2                                       # 23.44: Modell v2 (gemischte Schwankung); gespeicherte v1-Kalibrierungen gelten nicht
NAME = "Kaskaden-Asymmetrie"
Y_REF = 1.0                                       # Literaturwert: Treiber und Reichweite, solange Y nicht belegt ist
Y_GITTER = (0.0, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0)   # aufsteigend (die 1-SE-Regel nimmt das kleinste)
LOG_SCHRITT = 0.05                                # gemeinsames log-Raster für c und die Mischung der Schwankung
C_EXP = tuple(range(-18, 10))                     # c = e^{δ·k}: 0,41 … 1,57
C_GITTER = tuple(math.exp(LOG_SCHRITT * k) for k in C_EXP)
T_GITTER = (0.0, 0.3, 0.6, 0.9)                   # τ: Streuung der wahren Schwankung um die gemessene (log), 0 = Gauß wie bis 23.43
PARAM = tuple((ci, ti) for ti in range(len(T_GITTER)) for ci in range(len(C_GITTER)))
SCHWELLEN = (0.5, 1.0, 1.5, 2.0, 3.0)             # Ereignisse „Ausschlag ≥ k · σ_h“
HORIZONTE = (1, 4)
TAGE = 90
SNAP_ALTER = 1800                                 # Heatmap-Stand höchstens 30 min alt
D_MAX_SIGMA = 6.0                                 # Cluster bis 6 σ_4h Tiefe …
D_MAX = 0.25                                      # … und höchstens 25 % vom Kurs
KIPP_EXT = 0.5                                    # Kipppunkt: die Kaskade trägt mindestens 0,5 σ_4h weiter
EXO_MAX = 3.0                                     # Suche bis 3 σ_4h exogenem Ausschlag
FOLDS = 5
MIN_BLOECKE = 120                                 # je Coin und Horizont, sonst keine Kalibrierung
PLACEBO_S = 3 * 86_400
P_KLEMME = 1e-4
RICHTUNG_A = 0.3                                  # Richtungsprobe: nur Blöcke mit |Asymmetrie| ab 0,3
RICHTUNG_MIN = 20                                 # … und erst ab 20 solchen Blöcken (23.44: PAXG zeigte „1 Block, z +5,0“)
ZUVERL_MIN = 20                                   # Zuverlässigkeit: Klassen mit weniger Fällen nur gezählt, nicht gezeigt
MODELL_ALTER = 3 * 86_400                         # gespeicherte Kalibrierung gilt 3 Tage (Takt alle 6 h)
_CACHE: dict = {}


# ------------------------------------------------------------------------------------------------ Mathematik
def wirkung(q: float, y: float, sig_tag: float, v_tag: float) -> float:
    """I(Q) = Y · σ_Tag · √(Q / V_Tag) als Log-Rendite (0 ohne Fluss, ohne Y oder ohne Umsatz)."""
    if q <= 0 or y <= 0 or not v_tag or v_tag <= 0 or not sig_tag or sig_tag <= 0:
        return 0.0
    return y * sig_tag * math.sqrt(q / v_tag)


def h_werte(d: list, q: list, y: float, sig_tag: float, v_tag: float, m_liste) -> list:
    """Nötiger exogener Ausschlag H(m) je Tiefe m (aufsteigend); d aufsteigend (Tiefen der Cluster), q ihr Notional."""
    out = []; j = 0; Q = 0.0; lauf = -math.inf
    for m in m_liste:
        while j < len(d) and d[j] <= m:
            lauf = max(lauf, d[j] - wirkung(Q, y, sig_tag, v_tag))     # bis Cluster j hilft der Fluss aller Cluster davor
            Q += q[j]; j += 1
        out.append(max(lauf, m - wirkung(Q, y, sig_tag, v_tag)))
    return out


def h_feld(d, q, sig_tag: float, v_tag: float, m, y) -> np.ndarray:
    """Wie h_werte, für viele Y und Tiefen zugleich (Felder: y (nY,), m (nM,) aufsteigend) → (nY, nM)."""
    m = np.asarray(m, dtype=float); y = np.asarray(y, dtype=float)
    if len(d) == 0 or not v_tag or v_tag <= 0 or not sig_tag:
        return np.tile(m, (len(y), 1))
    d = np.asarray(d, dtype=float)
    Q = np.concatenate([[0.0], np.cumsum(np.asarray(q, dtype=float))])          # Q[k] = Fluss der ersten k Cluster
    b = sig_tag * np.sqrt(Q / v_tag)                                            # Wirkung je Y = 1
    noetig = d[None, :] - y[:, None] * b[None, :-1]                             # (nY, n): exogener Ausschlag bis Cluster k
    lauf = np.maximum.accumulate(noetig, axis=1)
    j = np.searchsorted(d, m, side="right")                                     # Cluster mit Tiefe ≤ m
    H = m[None, :] - y[:, None] * b[j][None, :]
    mit = j > 0
    if mit.any():
        H[:, mit] = np.maximum(H[:, mit], lauf[:, j[mit] - 1])
    return H


def ende(d: list, q: list, y: float, sig_tag: float, v_tag: float, u_exo: float) -> float:
    """Wo eine Kaskade nach dem exogenen Ausschlag u_exo endet: kleinste Lösung u ≥ u_exo von u = u_exo + I(Q(u))."""
    praefix = [0.0]
    for x in q:
        praefix.append(praefix[-1] + x)
    u = u_exo
    for _ in range(len(d) + 2):                                                 # jede Runde nimmt mindestens ein Cluster mit
        neu = u_exo + wirkung(praefix[bisect.bisect_right(d, u)], y, sig_tag, v_tag)
        if neu <= u + 1e-15:
            return u
        u = neu
    return u


def _mischung(tau: float) -> tuple:
    """Log-normale Mischung der Schwankung auf dem Raster LOG_SCHRITT: (Exponenten k, Gewichte w) mit Σ w = 1, bis ±4 τ.
    τ = 0: nur k = 0 (Reflexionsprinzip)."""
    if tau <= 0:
        return (0,), (1.0,)
    K = int(math.ceil(4.0 * tau / LOG_SCHRITT))
    ks = tuple(range(-K, K + 1)); w = [math.exp(-0.5 * (k * LOG_SCHRITT / tau) ** 2) for k in ks]; sw = sum(w)
    return ks, tuple(x / sw for x in w)


def p_ueber(h_m: float, c: float, sig_h: float, tau: float = 0.0) -> float:
    """P(größter Ausschlag binnen h ≥ m) = Σ_k w_k(τ) · erfc(H(m) / (c · e^{kδ} · σ_h · √2)), höchstens 1. Mit τ = 0 das
    Reflexionsprinzip 2 · (1 − Φ(H / (c σ_h))); mit τ > 0 über die wahre Schwankung gemischt (log-normal, Streuung τ)."""
    if h_m <= 0:
        return 1.0
    ks, ws = _mischung(tau)
    return min(1.0, sum(w * math.erfc(h_m / (c * math.exp(k * LOG_SCHRITT) * sig_h * math.sqrt(2.0))) for k, w in zip(ks, ws)))


def _p_tabelle(x: np.ndarray, params) -> np.ndarray:
    """P(Ausschlag ≥ m) für normierte Tiefen x = H / σ_h (beliebige Form) und Parameter (Index in C_GITTER, Index in T_GITTER)
    → (len(params), x.size). erfc nur einmal je Raster-Exponent, dann je Parameter die gewichtete Summe (Matrix W @ E)."""
    xf = np.asarray(x, dtype=float).reshape(-1)
    mis = {ti: _mischung(T_GITTER[ti]) for ti in {t for _, t in params}}
    exps = sorted({C_EXP[ci] + k for ci, ti in params for k in mis[ti][0]})
    pos = {e: i for i, e in enumerate(exps)}
    E = np.empty((len(exps), xf.size))
    for e, i in pos.items():
        E[i] = _erfc_np(xf / (math.exp(e * LOG_SCHRITT) * math.sqrt(2.0)))
    W = np.zeros((len(params), len(exps)))
    for j, (ci, ti) in enumerate(params):
        for k, w in zip(*mis[ti]):
            W[j, pos[C_EXP[ci] + k]] += w
    return np.minimum(W @ E, 1.0)


def _erfc_np(x) -> np.ndarray:
    """erfc für Felder (Numerical Recipes 6.2, relativer Fehler < 1,2e-7) -- ohne scipy, das auf dem Pi nicht installiert ist."""
    x = np.asarray(x, dtype=float); z = np.abs(x); t = 1.0 / (1.0 + 0.5 * z)
    r = t * np.exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807
        + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))))
    return np.where(x >= 0, r, 2.0 - r)


def cluster_aus(rows, p0: float, sig4: float | None) -> dict:
    """Heatmap-Zeilen (px, side, notional) → je Seite (Tiefen aufsteigend, Notional). Nur die richtige Seite des Kurses
    (Long-Liquidationen darunter, Short-Liquidationen darüber; ein veralteter Stand kann andere enthalten) und bis
    min(6 σ_4h; 25 %) Tiefe."""
    dmax = min(D_MAX, D_MAX_SIGMA * sig4) if sig4 else D_MAX
    seiten: dict = {"ab": {}, "auf": {}}
    for px, side, usd in rows:
        if not px or not usd or usd <= 0 or px <= 0 or not p0:
            continue
        if side == "long" and px < p0:
            s, dd = "ab", math.log(p0 / px)
        elif side == "short" and px > p0:
            s, dd = "auf", math.log(px / p0)
        else:
            continue
        if dd <= dmax:
            k = round(dd, 10)
            seiten[s][k] = seiten[s].get(k, 0.0) + float(usd)
    return {s: (sorted(v), [v[k] for k in sorted(v)]) for s, v in seiten.items()}


def reichweite(d, q, y: float, sig_tag: float, v_tag: float, sig4: float) -> dict:
    """Kipppunkt = kleinster exogener Ausschlag (Raster 0,02 σ_4h bis 3 σ_4h), ab dem die Kaskade mindestens 0,5 σ_4h weiter
    trägt; dazu ihr Ende, das Ende nach 1 σ_4h und nach 3 σ_4h (alles als Tiefe in Log-Einheiten)."""
    out = {"kipp": None, "ende_kipp": None, "ende_1s": ende(d, q, y, sig_tag, v_tag, sig4), "ende_3s": ende(d, q, y, sig_tag, v_tag, EXO_MAX * sig4)}
    if not d or y <= 0:
        return out
    schritt = 0.02 * sig4
    for i in range(int(round(EXO_MAX / 0.02)) + 1):
        u = i * schritt
        e = ende(d, q, y, sig_tag, v_tag, u)
        if e - u >= KIPP_EXT * sig4:
            out["kipp"] = u; out["ende_kipp"] = e
            break
    return out


def mehrweg(d, q, y: float, sig_tag: float, v_tag: float, sig_h: float, c: float = 1.0) -> float:
    """Erwarteter zusätzlicher Ausschlag binnen h durch Kaskaden, in σ_h: ∫ (P_Kaskade(≥ m) − P_Zufall(≥ m)) dm bis 6 σ_h."""
    if not d or y <= 0 or not sig_h:
        return 0.0
    m = np.arange(1, 301) * 0.02 * sig_h
    H = h_feld(d, q, sig_tag, v_tag, m, [y])[0]
    p = np.minimum(1.0, _erfc_np(H / (c * sig_h * math.sqrt(2.0))))
    p0 = np.minimum(1.0, _erfc_np(m / (c * sig_h * math.sqrt(2.0))))
    return float(np.sum(p - p0) * 0.02)


def asymmetrie(m_auf: float, m_ab: float) -> float:
    return (m_auf - m_ab) / (m_auf + m_ab + 0.1)


# ------------------------------------------------------------------------------------------------ Live-Stand
def _markt(con, coin: str, now: int) -> dict:
    """σ_4h, Stundenvolumen und Kurs wie im Heatmap-Anker (hl_anker.Markt, 9 Tage Minutenkerzen)."""
    import hl_anker
    M = hl_anker.Markt(con, coin, now - 86_400, now)
    return {"sig4": M.sigma(now), "vol_h": M.volumen(now), "p": M.preis(now) or (M.cl[-1] if M.cl else None)}


def modell_laden(coin: str, path: str | None = None) -> dict | None:
    """Gespeicherte Kalibrierung (learned coin/„kaskade“), höchstens MODELL_ALTER alt und nur aus dieser Modellversion -- eine
    v1-Kalibrierung (Reflexionsprinzip ohne Mischung) gilt nach dem Update nicht mehr; bis zum nächsten Takt „ausstehend“."""
    try:
        m = F.learned_load(coin, "kaskade", MODELL_ALTER, path=path or F.STORE)
    except Exception:
        return None
    return m if isinstance(m, dict) and m.get("version") == VERSION else None


def zustand(con, coin: str, now: int | None = None, p0: float | None = None, path: str | None = None) -> dict:
    """Kaskaden-Stand jetzt: Cluster, Kipppunkt und Ende je Seite, Mehrweg, Asymmetrie, Wahrscheinlichkeiten nach Modell.
    Zwischenspeicher je Coin und Heatmap-Stand (neue Stände alle 10 min); der Kurs wird bei jedem Aufruf neu eingesetzt."""
    now = int(now or time.time())
    try:
        r = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin=? AND ts>=? AND ts<=?", (coin, now - SNAP_ALTER, now)).fetchone()
        t = int(r[0]) if r and r[0] else None
    except sqlite3.Error as e:
        return {"fehlt": f"Heatmap nicht lesbar ({type(e).__name__})"}
    if not t:
        return {"fehlt": "kein Heatmap-Stand der letzten 30 min"}
    try:
        datei = (con.execute("PRAGMA database_list").fetchone() or (None, None, None))[2]     # Verbindungen sind kurzlebig, die Datei nicht
    except sqlite3.Error:
        datei = None
    schluessel = (datei or id(con), coin, path)
    c_ = _CACHE.get(schluessel)
    if c_ and c_["t"] == t and 0 <= now - c_["berechnet"] < 900:
        rows, mk = c_["rows"], c_["markt"]
    else:
        try:
            rows = con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?", (coin, t)).fetchall()
            mk = _markt(con, coin, now)
        except sqlite3.Error as e:
            return {"fehlt": f"Daten nicht lesbar ({type(e).__name__})"}
        _CACHE[schluessel] = {"t": t, "berechnet": now, "rows": rows, "markt": mk}
    p0 = p0 or mk["p"]; sig4 = mk["sig4"]; vol_h = mk["vol_h"]
    if not p0 or not sig4 or not vol_h:
        return {"fehlt": "zu wenige Kursdaten für σ und Umsatz (mindestens 3,5 Tage Minutenkerzen)", "ts": t}
    sig_tag = sig4 * math.sqrt(6.0); v_tag = 24.0 * vol_h
    cl = cluster_aus(rows, p0, sig4)
    mod = modell_laden(coin, path)
    out = {"ts": t, "alter": now - t, "p0": p0, "sig4": sig4, "sig_tag": sig_tag, "v_tag": v_tag, "y_ref": Y_REF, "seiten": {}}
    mw = {}
    for s in ("ab", "auf"):
        d, q = cl[s]
        ref = reichweite(d, q, Y_REF, sig_tag, v_tag, sig4)
        mw[s] = mehrweg(d, q, Y_REF, sig_tag, v_tag, sig4)
        groesste = sorted(zip(q, d), reverse=True)[:3]
        out["seiten"][s] = {"n": len(d), "summe": sum(q), "ref": ref, "mehrweg": mw[s],
                            "groesste": [{"tiefe": dd, "usd": qq, "anteil_tag": qq / v_tag} for qq, dd in groesste]}
    out["A"] = asymmetrie(mw["auf"], mw["ab"])
    out["modell"] = None
    if mod and not mod.get("fehler"):
        kurz = {}
        for h in HORIZONTE:
            mh = (mod.get("h") or {}).get(str(h)) or {}
            if mh.get("zu_wenig") or mh.get("Y") is None:
                continue
            y, c, c0 = float(mh["Y"]), float(mh.get("c") or 1.0), float(mh.get("c0") or 1.0)
            tau, tau0 = float(mh.get("tau") or 0.0), float(mh.get("tau0") or 0.0)
            sig_h = sig4 * math.sqrt(h / 4.0)
            p = {}
            for s in ("ab", "auf"):
                d, q = cl[s]
                Hm = h_werte(d, q, y, sig_tag, v_tag, [1.0 * sig_h, 2.0 * sig_h])
                p[s] = {"1": p_ueber(Hm[0], c, sig_h, tau), "2": p_ueber(Hm[1], c, sig_h, tau),
                        "1_basis": p_ueber(1.0 * sig_h, c0, sig_h, tau0), "2_basis": p_ueber(2.0 * sig_h, c0, sig_h, tau0)}
            kurz[str(h)] = {"Y": y, "c": c, "tau": tau, "belegt": bool(mh.get("belegt")), "p": p}
        out["modell"] = {"ts": mod.get("ts"), "h": kurz} if kurz else {"ts": mod.get("ts"), "h": {}, "zu_wenig": True}
        m4 = kurz.get("4") or {}
        if m4.get("belegt") and m4.get("Y"):                                   # belegtes Y: Reichweite auch damit
            for s in ("ab", "auf"):
                d, q = cl[s]
                out["seiten"][s]["kal"] = reichweite(d, q, m4["Y"], sig_tag, v_tag, sig4)
    return out


def _px(p0: float, u: float | None, s: str) -> float | None:
    if u is None:
        return None
    return p0 * math.exp(-u) if s == "ab" else p0 * math.exp(u)


def treiber(con, coin: str, p0: float, add, missing: list, now: int | None = None) -> dict | None:
    """Schatten-Treiber „Kaskaden-Asymmetrie“ für compute_forecast (Gewicht 0; nie im v1-Bias, nicht in v2/v3)."""
    z = zustand(con, coin, now, p0)
    if not z or z.get("fehlt"):
        missing.append(f"{NAME} ({(z or {}).get('fehlt') or 'kein Stand'})")
        return z
    teile = []
    for s, wort in (("ab", "unten"), ("auf", "oben")):
        S = z["seiten"][s]; r = S["ref"]
        if S["n"] == 0:
            teile.append(f"{wort} keine Cluster in Reichweite")
        elif r["kipp"] is None:
            teile.append(f"{wort} kein Kipppunkt bis {EXO_MAX:g} σ ({S['n']} Cluster, {S['summe'] / 1e6:.1f} Mio)")
        else:
            teile.append(f"{wort} Kipppunkt {_tiefe(r['kipp'], s)} → Ende {_tiefe(r['ende_kipp'], s)}")
    text = (f"Wurzelgesetz mit Y = {Y_REF:g}: " + " · ".join(teile)
            + f" · Mehrweg 4 h unten {z['seiten']['ab']['mehrweg']:.2f} σ, oben {z['seiten']['auf']['mehrweg']:.2f} σ (Schatten)".replace(".", ","))
    add(NAME, max(-1.0, min(1.0, z["A"])), 0.0, text)
    return z


def kompakt(z: dict) -> dict | None:
    """Was im Payload gespeichert wird (rund 0,2 kB): Asymmetrie, Kipppunkt und Ende je Seite als Kurs, Modell-p für 4 h."""
    if not z or z.get("fehlt"):
        return {"v": VERSION, "fehlt": (z or {}).get("fehlt")} if z else None
    p0 = z["p0"]; out = {"v": VERSION, "ts": z["ts"], "A": round(z["A"], 4), "y_kipp": Y_REF}
    for s in ("ab", "auf"):
        S = z["seiten"][s]; r = S.get("kal") or S["ref"]
        if S.get("kal"):
            out["y_kipp"] = (((z.get("modell") or {}).get("h") or {}).get("4") or {}).get("Y")
        out[f"kipp_{s}"] = round(_px(p0, r["kipp"], s), 8) if r["kipp"] is not None else None
        out[f"ende_{s}"] = round(_px(p0, r["ende_kipp"], s), 8) if r["ende_kipp"] is not None else None
        out[f"mehr_{s}"] = round(S["mehrweg"], 4)
    m4 = ((z.get("modell") or {}).get("h") or {}).get("4")
    if m4:
        out["Y4"] = m4["Y"]; out["belegt4"] = m4["belegt"]
        out["p2_ab"] = round(m4["p"]["ab"]["2"], 4); out["p2_auf"] = round(m4["p"]["auf"]["2"], 4)
        out["p2_basis"] = round(m4["p"]["ab"]["2_basis"], 4)
    return out


def anzeige(z: dict) -> dict | None:
    """Für die Kachel (nicht im Payload): je Seite Kipppunkt und Ende als Kurs und %, größte Cluster, Modell und Bilanz."""
    if not z or z.get("fehlt"):
        return {"fehlt": (z or {}).get("fehlt")} if z else None
    p0 = z["p0"]
    out = {"ts": z["ts"], "alter": z["alter"], "A": round(z["A"], 3), "sig4": z["sig4"], "y_ref": Y_REF, "seiten": {}, "modell": z.get("modell")}
    for s in ("ab", "auf"):
        S = z["seiten"][s]; zeig = {}
        for art in ("ref", "kal"):
            r = S.get(art)
            if not r:
                continue
            zeig[art] = {"kipp_px": _px(p0, r["kipp"], s), "kipp_pct": (None if r["kipp"] is None else (math.exp(-r["kipp"] if s == "ab" else r["kipp"]) - 1) * 100),
                         "ende_px": _px(p0, r["ende_kipp"], s), "ende_pct": (None if r["ende_kipp"] is None else (math.exp(-r["ende_kipp"] if s == "ab" else r["ende_kipp"]) - 1) * 100),
                         "ende_1s_pct": (math.exp(-r["ende_1s"] if s == "ab" else r["ende_1s"]) - 1) * 100}
        out["seiten"][s] = dict(zeig, n=S["n"], summe=S["summe"], mehrweg=round(S["mehrweg"], 3),
                                groesste=[{"px": _px(p0, g["tiefe"], s), "usd": g["usd"], "anteil_tag": g["anteil_tag"]} for g in S["groesste"]])
    return out


def ergaenzen(con, fc: dict, path: str | None = None, now: int | None = None) -> dict:
    """Hängt den Kaskaden-Stand an eine frisch berechnete Prognose (vor store_forecast): `kaskade` (Payload) und
    `kaskade_info` (nur Anzeige). Nutzt den Zwischenspeicher aus treiber(); ein Fehler hält die Prognose nie an."""
    try:
        z = zustand(con, fc["coin"], now or fc.get("ts"), fc.get("price"), path=path)
        fc["kaskade"] = kompakt(z)
        info = anzeige(z) or {}
        mod = modell_laden(fc["coin"], path)
        if mod:
            info["bilanz"] = {h: {k: (mod.get("h") or {}).get(h, {}).get(k) for k in ("n", "tage", "Y", "belegt", "d_loss", "se", "skill_2", "skill_1",
                                                                                   "n_ereig_2", "zu_wenig")}
                              | {"placebo_Y": (((mod.get("h") or {}).get(h) or {}).get("placebo") or {}).get("Y")}
                              for h in ("1", "4")}
            info["bilanz"]["ts"] = mod.get("ts"); info["richtung"] = mod.get("richtung")
        fc["kaskade_info"] = info
    except Exception as e:
        fc["kaskade"] = {"v": VERSION, "fehler": f"{type(e).__name__}: {e}"}
    return fc


# ------------------------------------------------------------------------------------------------ Kalibrierung
def _klumpen_se(x, klumpen) -> float:
    """Standardfehler des Mittels von x, Abhängigkeit innerhalb eines Klumpens (Tag)."""
    x = np.asarray(x, dtype=float); n = len(x)
    if n < 2:
        return float("nan")
    u = x - x.mean(); s: dict = {}
    for k, v in zip(klumpen, u.tolist()):
        s[k] = s.get(k, 0.0) + v
    G = len(s)
    if G < 2:
        return float("nan")
    return math.sqrt(G / (G - 1) * sum(v * v for v in s.values())) / n


def bloecke(con, coin: str, h: int, von: int, bis: int, M) -> list:
    """Je h-Block der erste Heatmap-Stand (höchstens 15 min nach Blockbeginn): Kurs, σ_4h, Umsatz, Cluster, eingetretene
    Ausschläge nach unten und oben binnen h (Minutenkerzen, mindestens 90 % vorhanden) und die Rendite zum Blockende.
    Je Block zwei gezielte Abfragen über Index und Schlüssel (erster Stand; nur Eimer bis zur größten Clustertiefe): Ein Stand
    kann einige hundert Eimer je Coin tragen; alles zu lesen kostete in der Lastprobe (800 Eimer je Stand, 30 Tage) 5,5 s und
    354 MB Prozessspeicher, gezielt 0,4 s und 53 MB (90 Tage: 1,5 s, 91 MB) -- Ergebnis identisch (Selbsttest „Blöcke“)."""
    block = h * 3600
    out = []
    for b in range(von // block, (bis - block) // block + 1):
        a = max(b * block, von); z = min(b * block + 899, bis - block)
        if a > z:
            continue
        r = con.execute("SELECT MIN(ts) FROM heatmap WHERE coin=? AND ts>=? AND ts<=?", (coin, a, z)).fetchone()
        if not r or r[0] is None:
            continue
        ts = int(r[0])
        p0 = M.preis(ts); sig4 = M.sigma(ts); vol_h = M.volumen(ts)
        if not (p0 and sig4 and vol_h):
            continue
        i = bisect.bisect_right(M.ts, ts); j = bisect.bisect_right(M.ts, ts + block)
        if j - i < 0.9 * block / 60 or M.ts[j - 1] < ts + block - 180:
            continue
        lo = min(M.lo[i:j]); hi = max(M.hi[i:j])
        if not lo or not hi:
            continue
        dmax = min(D_MAX, D_MAX_SIGMA * sig4)                                    # wie cluster_aus, mit Rand für Rundung
        rows = con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE ts=? AND coin=? AND bucket_px>=? AND bucket_px<=?",
                           (ts, coin, p0 * math.exp(-dmax) * (1 - 1e-9), p0 * math.exp(dmax) * (1 + 1e-9))).fetchall()
        p1 = M.preis(ts + block)
        out.append({"ts": ts, "p0": p0, "sig4": sig4, "sig_h": sig4 * math.sqrt(h / 4.0), "sig_tag": sig4 * math.sqrt(6.0),
                    "v_tag": 24.0 * vol_h, "cl": cluster_aus(rows, p0, sig4),
                    "M": (max(0.0, math.log(p0 / lo)), max(0.0, math.log(hi / p0))),
                    "r": math.log(p1 / p0) if p1 else None})
    return out


def _h_bloecke(bl: list, karten: list | None = None) -> np.ndarray:
    """H je Block, Y, Seite und Schwelle → (B, nY, 2, nK). karten: andere Cluster je Block (Placebo), sonst die eigenen."""
    Y = np.array(Y_GITTER); K = np.array(SCHWELLEN)
    H = np.zeros((len(bl), len(Y), 2, len(K)))
    for i, b in enumerate(bl):
        cl = karten[i] if karten is not None else b["cl"]
        for k, s in enumerate(("ab", "auf")):
            d, q = cl[s]
            H[i, :, k, :] = h_feld(d, q, b["sig_tag"], b["v_tag"], K * b["sig_h"], Y)
    return H


def _verluste(H: np.ndarray, sig_h: np.ndarray, E: np.ndarray) -> np.ndarray:
    """Log-Verlust je Y, Parameter (c, τ) und Block → (nY, len(PARAM), B), summiert über Seiten und Schwellen. In Stücken zu
    100 Blöcken, damit der Speicher klein bleibt (90 Tage zu 1 h sind rund 2.200 Blöcke)."""
    B, nY = H.shape[0], H.shape[1]; nP = len(PARAM); out = np.zeros((nY, nP, B))
    for a in range(0, B, 100):
        e = min(B, a + 100)
        x = H[a:e] / sig_h[a:e, None, None, None]                                 # (b, nY, 2, nK)
        p = np.clip(_p_tabelle(x, PARAM), P_KLEMME, 1 - P_KLEMME).reshape((nP,) + x.shape)
        ev = E[a:e][:, None, :, :]                                                 # (b, 1, 2, nK)
        ll = -(ev * np.log(p) + (1 - ev) * np.log(1 - p))                         # (nP, b, nY, 2, nK)
        out[:, :, a:e] = ll.sum(axis=(3, 4)).transpose(2, 0, 1)
    return out


def _waehlen(L: np.ndarray, tage) -> dict:
    """Geblockte Kreuzvalidierung über die Zeit (5 Folds, Embargo ein Block): c je Y auf den Trainingsblöcken, Verlust auf den
    Testblöcken; 1-SE-Regel mit Vorrang für das kleinste Y (Standardfehler gepaart, Tage als Klumpen)."""
    nY, nC, B = L.shape; grenzen = np.linspace(0, B, FOLDS + 1).astype(int)
    oof = np.full((nY, B), np.nan); c_fold = np.full((nY, B), np.nan)
    for f in range(FOLDS):
        a, e = grenzen[f], grenzen[f + 1]
        if e <= a:
            continue
        tr = np.ones(B, dtype=bool); tr[max(0, a - 1):min(B, e + 1)] = False
        if tr.sum() < 30:
            continue
        beste_c = L[:, :, tr].sum(axis=2).argmin(axis=1)
        for y in range(nY):
            oof[y, a:e] = L[y, beste_c[y], a:e]; c_fold[y, a:e] = beste_c[y]
    m = np.isfinite(oof).all(axis=0)
    if m.sum() < 30:
        return {"wahl": 0, "tabelle": {}, "n_oof": int(m.sum())}
    mittel = oof[:, m].mean(axis=1); best = int(np.argmin(mittel)); tg = np.asarray(tage)[m]
    se = [(_klumpen_se(oof[y, m] - oof[best, m], tg) if y != best else 0.0) for y in range(nY)]
    kand = [y for y in range(nY) if mittel[y] - mittel[best] <= (se[y] if np.isfinite(se[y]) else 0.0)]
    wahl = min(kand)
    d0 = oof[0, m] - oof[wahl, m]
    return {"wahl": wahl, "best": best, "mittel": mittel, "se": se, "maske": m, "c_fold": c_fold, "n_oof": int(m.sum()), "oof": oof,
            "d0": float(d0.mean()), "d0_se": _klumpen_se(d0, tg) if wahl else 0.0}


def _oof_p(H: np.ndarray, sig_h: np.ndarray, y: int, p_idx: np.ndarray) -> np.ndarray:
    """P je Block, Seite und Schwelle mit dem Parameter (c, τ) seines Folds (out-of-fold) → (B, 2, nK)."""
    x = H[:, y] / sig_h[:, None, None]; out = np.zeros(x.shape); pi = p_idx.astype(int)
    for j in np.unique(pi):
        sel = pi == j
        out[sel] = _p_tabelle(x[sel], [PARAM[j]])[0].reshape(x[sel].shape)
    return np.clip(out, 0.0, 1.0)


def _kalibrierung(p: np.ndarray, e: np.ndarray, tage) -> dict:
    """Vorhergesagt gegen eingetreten über alle Blöcke (beide Seiten gemittelt), Standardfehler mit Tagen als Klumpen."""
    d = (e - p).mean(axis=1)
    se = _klumpen_se(d, tage)
    return {"p": round(float(p.mean()), 4), "e": round(float(e.mean()), 4), "se": round(se, 4) if np.isfinite(se) else None}


def _zuverl(p: np.ndarray, e: np.ndarray, grenzen) -> list:
    out = []
    for lo_, hi_ in zip(grenzen[:-1], grenzen[1:]):
        sel = (p >= lo_) & (p < hi_)
        if sel.sum():
            out.append([lo_, min(hi_, 1.0), int(sel.sum()), round(float(p[sel].mean()), 4), round(float(e[sel].mean()), 4)])
    return out


def _auswertung(bl: list, H: np.ndarray, Hp: np.ndarray | None, mp, Hs: np.ndarray | None = None) -> dict:
    sig_h = np.array([b["sig_h"] for b in bl]); E = np.array([[[1.0 if b["M"][k] >= x * b["sig_h"] else 0.0 for x in SCHWELLEN]
                                                             for k in range(2)] for b in bl])
    tage = [b["ts"] // 86_400 for b in bl]
    L = _verluste(H, sig_h, E); w = _waehlen(L, tage)
    out = {"n": len(bl), "tage": round((bl[-1]["ts"] - bl[0]["ts"]) / 86_400, 1), "n_ereig_2": int(E[:, :, SCHWELLEN.index(2.0)].sum()),
           "n_ereig_1": int(E[:, :, SCHWELLEN.index(1.0)].sum())}
    if "mittel" not in w:
        return dict(out, zu_wenig=True, Y=None)
    y = w["wahl"]; p_all = int(L[y].sum(axis=1).argmin()); p_0 = int(L[0].sum(axis=1).argmin())
    out.update(Y=Y_GITTER[y], c=round(C_GITTER[PARAM[p_all][0]], 4), tau=T_GITTER[PARAM[p_all][1]],
               c0=round(C_GITTER[PARAM[p_0][0]], 4), tau0=T_GITTER[PARAM[p_0][1]], n_oof=w["n_oof"],
               bester_Y=Y_GITTER[w["best"]], d_loss=round(w["d0"], 5), se=round(w["d0_se"], 5) if np.isfinite(w["d0_se"]) else None,
               cv={str(Y_GITTER[i]): {"loss": round(float(w["mittel"][i]), 5), "diff": round(float(w["mittel"][i] - w["mittel"][w["best"]]), 5),
                                      "se": (round(float(w["se"][i]), 5) if np.isfinite(w["se"][i]) else None)} for i in range(len(Y_GITTER))})
    m = w["maske"]
    pm = _oof_p(H[m], sig_h[m], y, w["c_fold"][y, m]); pb = _oof_p(H[m], sig_h[m], 0, w["c_fold"][0, m]); Em = E[m]
    for k, nm in ((SCHWELLEN.index(2.0), "skill_2"), (SCHWELLEN.index(1.0), "skill_1")):
        bm = float(np.mean((pm[:, :, k] - Em[:, :, k]) ** 2)); bb = float(np.mean((pb[:, :, k] - Em[:, :, k]) ** 2))
        out[nm] = round(1 - bm / bb, 4) if bb > 1e-12 else None
    k1, k2 = SCHWELLEN.index(1.0), SCHWELLEN.index(2.0); tm = np.asarray(tage)[m]
    out["zuverl_2"] = _zuverl(pm[:, :, k2], Em[:, :, k2], (0.0, 0.02, 0.05, 0.1, 0.2, 1.01))
    out["zuverl_1"] = _zuverl(pm[:, :, k1], Em[:, :, k1], (0.0, 0.1, 0.2, 0.3, 0.5, 1.01))
    out["kal_2"] = _kalibrierung(pm[:, :, k2], Em[:, :, k2], tm)                  # U115 (2): vorhergesagt ≈ eingetreten?
    out["kal_1"] = _kalibrierung(pm[:, :, k1], Em[:, :, k1], tm)
    if Hp is not None and mp is not None and mp.sum() >= MIN_BLOECKE:
        Lp = _verluste(Hp[mp], sig_h[mp], E[mp]); wp = _waehlen(Lp, np.asarray(tage)[mp])
        out["placebo"] = {"n": int(mp.sum()), "Y": Y_GITTER[wp["wahl"]] if "mittel" in wp else None, "d_loss": round(wp.get("d0", 0.0), 5),
                          "se": round(wp["d0_se"], 5) if np.isfinite(wp.get("d0_se", float("nan"))) else None}
    else:
        out["placebo"] = {"n": int(mp.sum()) if mp is not None else 0, "Y": None}
    # Seiten-Probe: dieselben Cluster mit vertauschten Seiten (Long-Cluster oben, Short-Cluster unten). Liegt der Nutzen nur
    # darin, dass Cluster in der Nähe ohnehin mit höherer Schwankung einhergehen (auf beiden Seiten), passt der Spiegel genauso
    # gut; nur wenn die SEITE stimmt, ist es Kaskaden-Mechanik. Verglichen: Verlust Spiegel minus echt BEIM GLEICHEN Y (dem
    # gewählten), je mit den c, τ ihres Folds, gepaart. 23.44: Bis dahin trat der Spiegel mit seinem eigenen Y an -- wählte er
    # (1-SE-Regel, Vorrang für kleines Y) Y = 0, war der Vergleich derselbe wie „Y = 0 gegen gewählt“ und schützte nicht mehr;
    # im Störfaktor-Markt mit gemischter Schwankung ließ das einen Fehlbefund durch.
    if Hs is not None:
        Ls = _verluste(Hs, sig_h, E); ws = _waehlen(Ls, tage)
        if "mittel" in ws:
            ms = m & ws["maske"]
            dsp = ws["oof"][y, ms] - w["oof"][y, ms]
            se_sp = _klumpen_se(dsp, np.asarray(tage)[ms])
            out["spiegel"] = {"Y": Y_GITTER[ws["wahl"]], "Y_vergleich": Y_GITTER[y], "d_loss": round(float(dsp.mean()), 5),
                              "se": round(se_sp, 5) if np.isfinite(se_sp) else None}
    sp = out.get("spiegel") or {}
    pl = out["placebo"]
    out["belegt"] = bool(out["Y"] and out["Y"] > 0 and out.get("se") is not None and out["d_loss"] > 2 * out["se"]
                         and pl.get("Y") is not None and pl["Y"] == 0
                         and sp.get("se") is not None and sp["d_loss"] > 2 * sp["se"])
    return out


def _placebo(bl: list) -> tuple:
    """Je Block die Cluster des Blocks drei Tage vorher (±1 h), sonst keiner; Tiefen und Notional wie damals."""
    ts = [b["ts"] for b in bl]; karten = []; maske = []
    for b in bl:
        k = bisect.bisect_left(ts, b["ts"] - PLACEBO_S - 1800)
        if k < len(ts) and abs(ts[k] - (b["ts"] - PLACEBO_S)) <= 1800:
            karten.append(bl[k]["cl"]); maske.append(True)
        else:
            karten.append({"ab": ([], []), "auf": ([], [])}); maske.append(False)
    return karten, np.array(maske, dtype=bool)


def _richtung(bl4: list) -> dict:
    """Sagt die Asymmetrie (fester Y = 1) die Richtung der nächsten 4 h vorher? Blöcke mit |A| ≥ 0,3, Bewegung über der Toleranz."""
    treffer = []
    for b in bl4:
        if b["r"] is None or abs(b["r"]) < F.TOLERANZ:
            continue
        mw = {s: mehrweg(*b["cl"][s], Y_REF, b["sig_tag"], b["v_tag"], b["sig4"]) for s in ("ab", "auf")}
        a = asymmetrie(mw["auf"], mw["ab"])
        if abs(a) >= RICHTUNG_A:
            treffer.append(1.0 if (a > 0) == (b["r"] > 0) else 0.0)
    n = len(treffer); k = int(sum(treffer))
    if n < RICHTUNG_MIN:
        return {"n": n, "treffer": k, "zu_wenig": True}
    q = k / n
    # z gegen den Zufall mit dem Standardfehler UNTER der Nullhypothese (q = ½); ± ist der Standardfehler der Quote selbst
    return {"n": n, "treffer": k, "quote": round(q, 4), "se": round(math.sqrt(q * (1 - q) / n), 4),
            "z": round((q - 0.5) / math.sqrt(0.25 / n), 2)}


def kalibrieren(con, coin: str, now: int | None = None, path: str | None = None, speichern: bool = True, tage: int = TAGE,
                horizonte: tuple = HORIZONTE) -> dict:
    """Y und c je Horizont aus der Historie (bis 90 Tage), mit Placebo und Richtungsprobe; speichert learned coin/„kaskade“."""
    import hl_anker
    now = int(now or time.time()); von = now - tage * 86_400
    M = hl_anker.Markt(con, coin, von, now)
    out = {"version": VERSION, "coin": coin, "ts": now, "y_gitter": list(Y_GITTER), "h": {}, "min_bloecke": MIN_BLOECKE}
    bl4 = None
    for h in horizonte:                                                     # Selbsttest: nur der geprüfte Horizont (spart die Hälfte der Zeit)
        bl = bloecke(con, coin, h, von, now, M)
        if h == 4:
            bl4 = bl
        if len(bl) < MIN_BLOECKE:
            out["h"][str(h)] = {"n": len(bl), "zu_wenig": True, "Y": None}
            continue
        H = _h_bloecke(bl); karten, mp = _placebo(bl)
        Hp = _h_bloecke(bl, karten) if mp.sum() >= MIN_BLOECKE else None
        Hs = _h_bloecke(bl, [{"ab": b["cl"]["auf"], "auf": b["cl"]["ab"]} for b in bl])
        out["h"][str(h)] = _auswertung(bl, H, Hp, mp if Hp is not None else None, Hs)
    out["richtung"] = _richtung(bl4 or [])
    try:
        r = con.execute("SELECT ratio FROM coverage WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1", (coin, now)).fetchone()
        out["abdeckung"] = float(r[0]) if r and r[0] is not None else None
    except sqlite3.Error:
        out["abdeckung"] = None
    if speichern:
        F.learned_save(coin, "kaskade", out, path=path or F.STORE)
    return out


def takt(con, path: str | None = None, now: int | None = None) -> dict:
    """Alle 6 h aus dem Familien-Takt des Dashboards: je Coin mit Prognosen der letzten 24 h; Fehler je Coin sichtbar."""
    now = int(now or time.time()); erg = {}
    st = F.store_connect(path or F.STORE)
    try:
        coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ?", (now - 86_400,))]
    finally:
        st.close()
    for c in coins:
        try:
            m = kalibrieren(con, c, now, path=path)
            erg[c] = {h: (m["h"].get(h) or {}).get("Y") for h in ("1", "4")}
        except Exception as e:
            erg[c] = {"fehler": f"{type(e).__name__}: {e}"}
            F.learned_save(c, "kaskade", {"version": VERSION, "coin": c, "ts": now, "fehler": erg[c]["fehler"]}, path=path or F.STORE)
    return erg


# ------------------------------------------------------------------------------------------------ Stand (Debug)
def _pc(x, d: int = 1, vz: bool = False) -> str:
    if x is None:
        return "—"
    return (f"{x * 100:+.{d}f} %" if vz else f"{x * 100:.{d}f} %").replace(".", ",")


def _tiefe(u: float | None, s: str) -> str:
    """Tiefe u (Log) als Prozent zum Kurs mit Vorzeichen der Seite."""
    if u is None:
        return "—"
    return f"{(math.exp(-u) - 1 if s == 'ab' else math.exp(u) - 1) * 100:+.2f} %".replace(".", ",").replace("-", "−")


def _zahl(x, d: int = 0) -> str:
    return "—" if x is None else f"{x:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def stand_text(con, path: str | None = None, now: int | None = None, coins: list | None = None) -> str:
    now = int(now or time.time())
    z = ["Kaskaden-Gleichung -- Stand je Coin (Schatten: wirkt nicht auf die Prognose, nicht auf v1, v2 oder v3)",
         "I(Q) = Y · σ_Tag · √(Q / V_Tag) · Kaskade endet bei u = u_exo + I(Q(u)) · P(Ausschlag ≥ m binnen h) = Σ_k w_k(τ) · erfc(H(m) / "
         "(c · e^{0,05·k} · σ_h · √2)), mit τ = 0 genau 2 · (1 − Φ(H(m) / (c · σ_h)))",
         f"Kipppunkt = kleinster Ausschlag, ab dem die Kaskade ≥ {KIPP_EXT:g} σ_4h weiter trägt · Treiber und Reichweite mit Y = {Y_REF:g} "
         "(Literatur), bis Y je Coin belegt ist: Y > 0 gewählt, Abstand zu Y = 0 > 2 SE, Placebo ohne Befund, Seitenspiegel beim gleichen Y > 2 SE schlechter",
         "„ohne Heatmap“ = derselbe Zufallsweg, Schwankung aus allen Blöcken, ohne die Cluster -- die Vergleichsgröße der Bilanz",
         "Seit 23.44 gemischte Schwankung: τ = Streuung der wahren Schwankung einer Stunde um die gemessene (7 Tage); τ = 0 ist das "
         "Reflexionsprinzip allein. Treiber und Kipppunkt rechnen weiter fest mit Y = 1, c = 1, τ = 0 (vorwärts gemessen).", ""]
    if coins is None:
        st = F.store_connect(path or F.STORE)
        try:
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ? ORDER BY coin", (now - 86_400,))]
        finally:
            st.close()
    pool = [0, 0, 0]                                                    # Richtungsprobe über alle Coins: Blöcke, Treffer, Coins
    for coin in coins:
        s_ = zustand(con, coin, now, path=path) if con is not None else {"fehlt": "keine Hauptdatenbank"}
        mod = modell_laden(coin, path)
        if s_.get("fehlt"):
            z.append(f"{coin} · {s_['fehlt']}")
        else:
            p0 = s_["p0"]
            z.append(f"{coin} · Heatmap-Stand {time.strftime('%d.%m. %H:%M', time.localtime(s_['ts']))} (vor {s_['alter'] // 60} min) · Kurs "
                     f"{_zahl(p0, 2 if p0 < 1000 else 0)} · σ_4h {_pc(s_['sig4'], 2)} · Tagesumsatz {_zahl(s_['v_tag'] / 1e6, 0)} Mio"
                     + (f" · Heatmap deckt {_pc((mod or {}).get('abdeckung'), 0)} des OI ab" if (mod or {}).get("abdeckung") is not None else ""))
            for s, wort in (("ab", "unten"), ("auf", "oben ")):
                S = s_["seiten"][s]
                gr = " · ".join(f"{_zahl(g['usd'] / 1e6, 1)} Mio bei {_zahl(_px(p0, g['tiefe'], s), 2 if p0 < 1000 else 0)} "
                                f"({_tiefe(g['tiefe'], s)}, {_pc(g['anteil_tag'], 2)} des Tagesumsatzes)" for g in S["groesste"])
                z.append(f"   {wort}: {S['n']} Cluster, {_zahl(S['summe'] / 1e6, 1)} Mio" + (f"; größte {gr}" if gr else ""))
                for art, titel in (("ref", f"Wurzelgesetz Y = {Y_REF:g}"), ("kal", "kalibriert")):
                    r = S.get(art)
                    if not r:
                        continue
                    kipp = (f"Kipppunkt {_zahl(_px(p0, r['kipp'], s), 2 if p0 < 1000 else 0)} ({_tiefe(r['kipp'], s)}) → Ende "
                            f"{_zahl(_px(p0, r['ende_kipp'], s), 2 if p0 < 1000 else 0)} ({_tiefe(r['ende_kipp'], s)})") if r["kipp"] is not None \
                        else f"kein Kipppunkt bis {EXO_MAX:g} σ"
                    z.append(f"          {titel}: {kipp}; nach 1 σ Ausschlag Ende {_tiefe(r['ende_1s'], s)}, nach 3 σ {_tiefe(r['ende_3s'], s)}")
            z.append(f"   Mehrweg 4 h: unten {s_['seiten']['ab']['mehrweg']:.3f} σ, oben {s_['seiten']['auf']['mehrweg']:.3f} σ → Asymmetrie {s_['A']:+.2f} "
                     f"(Schatten-Treiber „{NAME}“)")
            for h, mh in ((s_.get("modell") or {}).get("h") or {}).items():
                z.append(f"   Modell {h} h (Y {mh['Y']:g}, c {mh['c']:.2f}, τ {mh.get('tau', 0):g}{', belegt' if mh['belegt'] else ', nicht belegt'}): P(Rutsch ≥ 2 σ) "
                         f"{_pc(mh['p']['ab']['2'])} · P(Anstieg ≥ 2 σ) {_pc(mh['p']['auf']['2'])} · ohne Heatmap je Seite {_pc(mh['p']['ab']['2_basis'])}")
        if not mod:
            z.append("   Kalibrierung: noch keine (alle 6 h im Familien-Takt des Dashboards, erstmals 15 min nach dem Start)")
        elif mod.get("fehler"):
            z.append(f"   Kalibrierung: Fehler {mod['fehler']}")
        else:
            z.append(f"   Kalibrierung vom {time.strftime('%d.%m. %H:%M', time.localtime(mod['ts']))}:")
            f4 = lambda x, vz=True: "—" if x is None else (f"{x:+.4f}" if vz else f"{x:.4f}")
            for h in ("1", "4"):
                m = (mod.get("h") or {}).get(h) or {}
                if m.get("zu_wenig"):
                    z.append(f"      {h} h: zu wenige Blöcke ({m.get('n')} von {mod.get('min_bloecke', MIN_BLOECKE)})"); continue
                pl = m.get("placebo") or {}; sp = m.get("spiegel") or {}
                z.append(f"      {h} h: {m['n']} Blöcke in {str(m['tage']).replace('.', ',')} Tagen · gewählt Y {m['Y']:g} (bestes {m['bester_Y']:g}), "
                         f"c {m['c']:.2f}, τ {m.get('tau', 0):g} (ohne Heatmap c {m.get('c0', 1):.2f}, τ {m.get('tau0', 0):g}) · "
                         f"Verlust Y=0 minus gewählt {f4(m.get('d_loss'))} ± {f4(m.get('se'), False)} je Block · Brier-Skill ≥ 2 σ {f4(m.get('skill_2'))}, "
                         f"≥ 1 σ {f4(m.get('skill_1'))} (out-of-fold)")
                z.append(f"           Placebo (Heatmap von 3 Tagen vorher): Y {pl.get('Y') if pl.get('Y') is not None else '—'} (n {pl.get('n', 0)}) · "
                         f"Seitenspiegel (eigenes Y {sp.get('Y') if sp.get('Y') is not None else '—'}, verglichen bei Y {sp.get('Y_vergleich', m['Y'])}): "
                         f"Verlust Spiegel minus echt {f4(sp.get('d_loss'))} ± "
                         f"{f4(sp.get('se'), False)} → {'BELEGT' if m['belegt'] else 'nicht belegt'}")
                def kz(kk):
                    """Vorhergesagt gegen eingetreten (out-of-fold) mit Abstand ± Standardfehler; ✓ innerhalb 2 SE (U115, Kriterium 2)."""
                    if not kk:
                        return "—"
                    d_ = f"{(kk['e'] - kk['p']) * 100:+.1f}".replace(".", ","); se_ = f"{(kk['se'] or 0) * 100:.1f}".replace(".", ",")
                    gut = bool(kk.get("se")) and abs(kk["e"] - kk["p"]) <= 2 * kk["se"]
                    return f"vorhergesagt {_pc(kk['p'])}, eingetreten {_pc(kk['e'])}, Abstand {d_} ± {se_} Punkte {'✓' if gut else '✗'}"
                zv = lambda liste: " · ".join(f"{_pc(b_[3])} → {_pc(b_[4])} ({b_[2]})" for b_ in liste or [] if b_[2] >= ZUVERL_MIN) or "—"
                z.append(f"           Ereignisse ≥ 2 σ: {m['n_ereig_2']} (≥ 1 σ: {m['n_ereig_1']}) · out-of-fold ≥ 2 σ: {kz(m.get('kal_2'))} · "
                         f"≥ 1 σ: {kz(m.get('kal_1'))}")
                z.append(f"           Zuverlässigkeit (vorhergesagt → eingetreten, n; Klassen ab {ZUVERL_MIN}) ≥ 2 σ: {zv(m.get('zuverl_2'))} · "
                         f"≥ 1 σ: {zv(m.get('zuverl_1'))}")
                z.append("           Kreuzvalidierung (Verlust je Block, Abstand zum besten ± SE): " + " · ".join(
                    f"Y {k} {v['loss']:.4f}" + (f" ({v['diff']:+.4f} ± {v['se']:.4f})" if v.get("se") else "") for k, v in (m.get("cv") or {}).items()))
            ri = mod.get("richtung") or {}
            if ri.get("n"):
                pool[0] += ri["n"]; pool[1] += ri.get("treffer", 0); pool[2] += 1 if ri.get("quote") is not None else 0
            z.append(f"      Richtung (|Asymmetrie| ≥ {RICHTUNG_A:g}, 4 h, Bewegung über der Toleranz): "
                     + (f"{ri['n']} Blöcke, Quote {_pc(ri['quote'], 0)} ± {_pc(ri['se'], 0)} (z {ri['z']:+.1f})" if ri.get("quote") is not None
                        else f"{ri.get('n', 0)} Blöcke -- zu wenige (ab {RICHTUNG_MIN})"))
        z.append("")
    if pool[0]:
        q = pool[1] / pool[0]; zz = (q - 0.5) / math.sqrt(0.25 / pool[0])
        z.append(f"Richtung über alle Coins: {pool[0]} Blöcke, Quote {_pc(q, 0)} ± {_pc(math.sqrt(q * (1 - q) / pool[0]), 0)} (z {zz:+.1f}). "
                 + (f"Je Coin ist ein |z| ≥ 2 bei {pool[2]} Coins mit eigener Probe kein Beleg: Die Chance, dass einer davon zufällig so weit "
                    f"liegt, ist {_pc(1 - (1 - 0.0455) ** pool[2], 0)}." if pool[2] > 1 else ""))
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
PROBE_NOW = 1_790_006_400


def _probe_markt(pfad: str, seed: int, tage: int = 30, y_wahr: float = 2.0, periode_h: int = 1, vorlauf: int = 8,
                 kl_median: float = 0.004, sig_min: float = 0.0006, v_tag: float = 1.5e9, coin: str = "BTC", kopplung: float = 0.0,
                 sv_tau: float = 0.0, sv_rho: float = 0.9) -> tuple:
    """Synthetischer Markt mit erzwungenem Fluss: Zufallsweg (0,06 % je Minute, vier Teilschritte), je Periode eine neue
    Cluster-Karte um den Kurs (2–8 Cluster je Seite, 0,1–3 σ_4h tief, Notional log-normal um kl_median · V_Tag). Erreicht der
    Kurs ein Cluster, wird es liquidiert, und die Wirkung Y · σ_Tag · √(Q / V_Tag) des seit Periodenbeginn liquidierten Flusses
    verschiebt den Kurs dauerhaft weiter -- genau das Modell, mit Y = y_wahr. Heatmap-Stände alle 10 min (30 s nach der vollen
    Minute, mit den noch nicht liquidierten Clustern), Minutenkerzen mit dem Umsatz V_Tag / 1440.
    sv_tau > 0 (23.44): Schwankung mit Gedächtnis wie im echten Markt -- log-σ als AR(1) je Stunde (Gedächtnis sv_rho), Streuung
    sv_tau, im Mittel der Quadrate 1 (die 7-Tage-Schwankung bleibt gleich). Erzeugt dünne Mitte und dicke Ränder der auf 7 Tage
    normierten Ausschläge, wie auf dem Pi gemessen."""
    import random as _r
    rng = _r.Random(seed)
    con = sqlite3.connect(pfad)
    con.executescript("""CREATE TABLE IF NOT EXISTS bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL,
                             trades INTEGER, PRIMARY KEY (ts, coin)) WITHOUT ROWID;
                         CREATE TABLE IF NOT EXISTS heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER,
                             lev_wavg REAL, entry_wavg REAL, cross_share REAL, PRIMARY KEY (ts, coin, bucket_px, side)) WITHOUT ROWID;
                         CREATE INDEX IF NOT EXISTS ix_heat_coin_ts ON heatmap(coin, ts);""")
    now = PROBE_NOW; start = now - (tage + vorlauf) * 86_400
    sig_tag = sig_min * math.sqrt(1440); sig4 = sig_min * math.sqrt(240)
    stufe = math.log1p(0.0025)
    eimer = lambda px: round(math.exp(round(math.log(px) / stufe) * stufe), 8)
    x = math.log(60_000.0)
    karte: dict = {"ab": {}, "auf": {}}; Qa = Qu = Ja = Ju = 0.0
    bars, heat = [], []
    periode = periode_h * 3600; sub = sig_min / 2.0; faktor = 1.0; lv = 0.0; f_sv = 1.0
    naechst = lambda: (max(karte["ab"]) if karte["ab"] else 0.0, min(karte["auf"]) if karte["auf"] else math.inf)
    for t in range(start, now + 60, 60):
        if sv_tau and t % 3600 == 0:                                          # Schwankung mit Gedächtnis (log-σ als AR(1) je Stunde)
            lv = sv_rho * lv + math.sqrt(1 - sv_rho ** 2) * sv_tau * rng.gauss(0, 1); f_sv = math.exp(lv - sv_tau ** 2)
        if t % periode == 0:
            p = math.exp(x); karte = {"ab": {}, "auf": {}}; Qa = Qu = Ja = Ju = 0.0
            for s in ("ab", "auf"):
                for _ in range(rng.randint(2, 8)):
                    d = rng.uniform(0.1, 3.0) * sig4
                    px = eimer(p * math.exp(-d if s == "ab" else d))
                    karte[s][px] = karte[s].get(px, 0.0) + v_tag * kl_median * math.exp(rng.gauss(0, 0.8))
            nah = sum(1 for s in ("ab", "auf") for px in karte[s] if abs(math.log(px / p)) <= sig4)
            faktor = 1.0 + kopplung * nah                                    # Störfaktor: nahe Cluster, höhere Schwankung (beide Seiten)
        n_ab, n_auf = naechst()
        o = math.exp(x); hi = lo = o
        for _ in range(4):
            x += rng.gauss(0, sub * faktor * f_sv)
            while math.exp(x) <= n_ab or math.exp(x) >= n_auf:                 # Kaskade: erreichte Cluster liquidieren, Wirkung neu
                kurs = math.exp(x)
                for px in [px for px in karte["ab"] if kurs <= px]:
                    Qa += karte["ab"].pop(px)
                for px in [px for px in karte["auf"] if kurs >= px]:
                    Qu += karte["auf"].pop(px)
                ja = wirkung(Qa, y_wahr, sig_tag, v_tag); ju = wirkung(Qu, y_wahr, sig_tag, v_tag)
                x += -(ja - Ja) + (ju - Ju); Ja, Ju = ja, ju
                n_ab, n_auf = naechst()
            hi = max(hi, math.exp(x)); lo = min(lo, math.exp(x))
        c = math.exp(x)
        bars.append((t, coin, o, hi, lo, c, v_tag / 1440.0 / c, 10))
        if t % 600 == 0:
            heat += [(t + 30, coin, px, "long" if s == "ab" else "short", usd, 1, None, None, None) for s in ("ab", "auf") for px, usd in karte[s].items()]
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", bars)
    con.executemany("INSERT OR REPLACE INTO heatmap VALUES (?,?,?,?,?,?,?,?,?)", heat)
    con.commit()
    return con, now


def _zeigen(pruef: list, verbose: bool) -> None:
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<62} {txt}")


def mathe_probe(verbose: bool = True) -> tuple:
    """Geschlossene Form gegen den Fixpunkt, Feld gegen Schritt, erfc, Grenzfall ohne Kaskaden, exakte Kleinbeispiele."""
    import random as _r
    from statistics import NormalDist
    pruef = []; rng = _r.Random(3); fehl = n_ = 0; abw = 0.0
    for _ in range(300):
        n = rng.randint(0, 12); d = sorted(rng.uniform(0.0005, 0.05) for _ in range(n))
        q = [rng.lognormvariate(math.log(5e6), 1.2) for _ in range(n)]
        y = rng.choice(Y_GITTER); st = rng.uniform(0.01, 0.06); vt = rng.uniform(2e8, 5e9)
        m_l = sorted(rng.uniform(0.0, 0.08) for _ in range(20))
        Hm = h_werte(d, q, y, st, vt, m_l); Hn = h_feld(d, q, st, vt, m_l, [y])[0]
        abw = max(abw, max(abs(a - b) for a, b in zip(Hm, Hn)))
        for _ in range(20):
            u = rng.uniform(0.0, 0.08); e = ende(d, q, y, st, vt, u)
            for m, H in zip(m_l, Hm):
                if abs(u - H) < 1e-12 or abs(e - m) < 1e-12:
                    continue
                n_ += 1; fehl += (e >= m) != (u >= H)
    pruef.append(("Mathe: Kaskade endet jenseits m genau dann, wenn Ausschlag ≥ H(m)", fehl == 0,
                  f"{n_} Vergleiche auf 300 zufälligen Karten (Y 0–8): {fehl} Abweichungen"))
    pruef.append(("Mathe: H als Feld = H Schritt für Schritt", abw < 1e-12, f"größte Abweichung {abw:.1e}"))
    xs = [i * 0.05 - 2 for i in range(200)]
    rel = max(abs(float(_erfc_np(x)) - math.erfc(x)) / math.erfc(x) for x in xs)
    pruef.append(("Mathe: erfc ohne scipy", rel < 2e-7, f"größter relativer Fehler {rel:.1e} auf [−2; 8]"))
    d, q = [0.01, 0.02], [5e7, 5e7]
    ok = (h_werte(d, q, 0.0, 0.03, 1e9, [0.005, 0.015, 0.03]) == [0.005, 0.015, 0.03] and mehrweg([], [], 1.0, 0.03, 1e9, 0.01) == 0.0
          and mehrweg(d, q, 0.0, 0.03, 1e9, 0.01) == 0.0 and abs(p_ueber(0.02, 1.0, 0.01) - 2 * (1 - NormalDist().cdf(2.0))) < 1e-12)
    pruef.append(("Mathe: ohne Kaskaden der reine Zufallsweg", ok, "Y = 0: H(m) = m, Mehrweg 0; P = 2 · (1 − Φ(m/σ))"))
    # Kleinbeispiele zum Nachrechnen: ein Cluster in 1 % Tiefe mit 8 % des Tagesumsatzes, σ_Tag 3 %, σ_4h 1 %:
    # I = 0,03 · √0,08 = 0,849 % ≥ 0,5 σ_4h → Kipppunkt genau 1 %, Ende 1,849 %; mit zweitem Cluster bei 1,5 % (1 %): Ende 1 % + 0,03 · √0,09 = 1,9 %
    r1 = reichweite([0.01], [8e7], 1.0, 0.03, 1e9, 0.01); e2 = ende([0.01, 0.015], [8e7, 1e7], 1.0, 0.03, 1e9, 0.01)
    r0 = reichweite([0.01], [1e6], 1.0, 0.03, 1e9, 0.01)
    ok = (r1["kipp"] is not None and abs(r1["kipp"] - 0.01) < 1e-9 and abs(r1["ende_kipp"] - (0.01 + 0.03 * math.sqrt(0.08))) < 1e-12
          and abs(e2 - 0.019) < 1e-12 and r0["kipp"] is None)
    pruef.append(("Mathe: Kipppunkt und Kettenreaktion exakt", ok, f"Kipppunkt {(r1['kipp'] or 0) * 100:.3f} %, Ende {(r1['ende_kipp'] or 0) * 100:.3f} % (soll 1,849 %); "
                  f"Kette bis {e2 * 100:.3f} % (soll 1,900 %); kleines Cluster ohne Kipppunkt"))
    # 23.44: gemischte Schwankung -- τ = 0 ist das Reflexionsprinzip, Tabelle (Kalibrierung) = Einzelrechnung (Live), Gewichte 1,
    # dickere Ränder mit τ, und das Gemisch selbst nachgerechnet (log-normal, Trapez über z mit 2.001 Punkten)
    xs = [0.25 * i for i in range(1, 17)]; abw_t = 0.0
    for ci, ti in [(ci_, min(ti_, len(T_GITTER) - 1)) for ci_, ti_ in ((0, 0), (9, 1), (18, 2), (27, 3), (4, 3))]:
        tab = _p_tabelle(np.array(xs), [(ci, ti)])[0]
        abw_t = max(abw_t, max(abs(float(a) - p_ueber(x, C_GITTER[ci], 1.0, T_GITTER[ti])) for a, x in zip(tab, xs)))
    gew = max(abs(sum(_mischung(t)[1]) - 1.0) for t in T_GITTER)
    def gemisch(x, tau):                                                     # unabhängig: ∫ erfc(x / (e^{τz} √2)) φ(z) dz
        zs = [-10 + 0.01 * i for i in range(2001)]
        f = [math.erfc(x / (math.exp(tau * z) * math.sqrt(2.0))) * math.exp(-0.5 * z * z) / math.sqrt(2 * math.pi) for z in zs]
        return 0.01 * (sum(f) - 0.5 * (f[0] + f[-1]))
    abw_g = max(abs(p_ueber(x, 1.0, 1.0, tau) - gemisch(x, tau)) / gemisch(x, tau) for x in (1.0, 2.0, 3.0) for tau in (0.3, 0.6, 0.9))
    ränder = [p_ueber(3.0, 1.0, 1.0, t) for t in T_GITTER]
    ok = (abw_t < 1e-6 and gew < 1e-12 and abw_g < 2e-3 and abs(p_ueber(2.0, 1.0, 1.0, 0.0) - math.erfc(2.0 / math.sqrt(2.0))) < 1e-15
          and all(a < b for a, b in zip(ränder, ränder[1:])))
    # 23.44: Richtungsprobe -- unter RICHTUNG_MIN Blöcken kein z (vorher „1 Block, z +5,0“), z mit dem Standardfehler der Nullhypothese
    blk = lambda r: {"r": r, "cl": {"ab": ([0.005], [8e7]), "auf": ([], [])}, "sig_tag": 0.03, "v_tag": 1e9, "sig4": 0.01}   # A ≈ −0,8
    r1_ = _richtung([blk(-0.01)]); r40 = _richtung([blk(-0.01)] * 30 + [blk(0.01)] * 10); r0_ = _richtung([blk(0.0001)] * 30)
    ok_r = (r1_.get("zu_wenig") is True and r1_.get("z") is None and r40.get("n") == 40 and r40.get("treffer") == 30
            and abs(r40["z"] - (0.75 - 0.5) / math.sqrt(0.25 / 40)) < 0.01 and r0_.get("n") == 0)
    # 23.44: Kreuzvalidierung ohne Blick in die Testblöcke -- in den Testblöcken eines Folds ist Parameter 1 weit besser, ebenso im
    # Nachbarblock dahinter (Embargo); überall sonst Parameter 0. Wer nur auf den Trainingsblöcken wählt, nimmt dort Parameter 0.
    Lcv = np.zeros((1, 2, 100)); Lcv[0, 1, :] = 1.0; gz = np.linspace(0, 100, FOLDS + 1).astype(int); a2, e2 = int(gz[2]), int(gz[3])
    Lcv[0, 1, a2:e2] = -50.0; Lcv[0, 1, e2] = -500.0
    wcv = _waehlen(Lcv, list(range(100))); cf = wcv.get("c_fold")
    ok_cv = cf is not None and bool(np.all(cf[0, a2:e2] == 0)) and bool(np.all(cf[0, e2 + 1:int(gz[4])] == 1))
    pruef.append(("Mathe: Kreuzvalidierung ohne Blick in die Testblöcke (Embargo 1 Block)", ok_cv,
                  f"Fold {a2}–{e2 - 1}: gewählt {sorted(set(cf[0, a2:e2].astype(int).tolist())) if cf is not None else '—'} (soll [0]); Folgefold sieht die "
                  f"Blöcke davor: {sorted(set(cf[0, e2 + 1:int(gz[4])].astype(int).tolist())) if cf is not None else '—'} (soll [1])"))
    pruef.append(("Mathe: Richtungsprobe erst ab 20 Blöcken, z gegen den Zufall", ok_r,
                  f"1 Block → {'zu wenige' if r1_.get('zu_wenig') else r1_} · 30 von 40 → z {r40.get('z')} (soll +3,16) · Bewegung unter der Toleranz → n {r0_.get('n')}"))
    pruef.append(("Mathe: gemischte Schwankung (Tabelle = Einzelrechnung = Integral)", ok,
                  f"Tabelle gegen Einzelrechnung {abw_t:.1e}, Gewichte {gew:.0e}, gegen das Integral relativ {abw_g:.1e}; P(≥ 3 σ) mit "
                  f"τ = {', '.join(f'{t:g}' for t in T_GITTER)}: {', '.join(f'{r * 100:.2f} %' for r in ränder)}"))
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def kalib_probe(verbose: bool = True) -> tuple:
    """Positivkontrolle (eingebaute Kaskaden, Y = 2), Nulltest (Cluster ohne Wirkung), Störfaktor (Schwankung an nahe Cluster
    gekoppelt, keine Kaskaden) -- auf synthetischen Märkten mit 30 Tagen; dieselbe Rechnung wie auf dem Pi."""
    import shutil
    import tempfile
    pruef = []; tmp = tempfile.mkdtemp(prefix="hl_kaskade_")
    try:
        def lauf(seed, y_wahr, periode=1, kopplung=0.0, sv=0.0, horizonte=(1,)):
            con, now = _probe_markt(os.path.join(tmp, f"m_{seed}_{y_wahr}_{periode}_{kopplung}_{sv}.db"), seed, tage=30, y_wahr=y_wahr,
                                    periode_h=periode, kopplung=kopplung, sv_tau=sv)
            try:
                return kalibrieren(con, "BTC", now, speichern=False, tage=30, horizonte=horizonte)
            finally:
                con.close()
        nein = lambda x: (x.get("placebo") or {}).get("Y") == 0 and (x.get("spiegel") or {}).get("Y") == 0
        pos = [lauf(s, 2.0)["h"]["1"] for s in (1, 2, 3)]
        pruef.append(("Positivkontrolle 1 h (Y wahr 2): Y gefunden, Placebo und Spiegel leer",
                      all(0.5 <= x["Y"] <= 4.0 and (x.get("skill_2") or 0) > 0 and nein(x) for x in pos) and sum(x["belegt"] for x in pos) >= 2,
                      " · ".join(f"Y {x['Y']:g}, Abstand {x['d_loss']:+.3f} ± {x['se']:.3f}, Skill ≥ 2 σ {x['skill_2']:+.3f}, "
                                 f"{'belegt' if x['belegt'] else 'nicht belegt'}" for x in pos)))
        pos4 = [lauf(s, 2.0, periode=4, horizonte=(4,))["h"]["4"] for s in (1, 2, 3, 4)]
        pruef.append(("Positivkontrolle 4 h (Y wahr 2, 180 Blöcke): mindestens 2 von 4 belegt",
                      sum(x["belegt"] for x in pos4) >= 2 and sum((x["Y"] or 0) > 0 for x in pos4) >= 3 and all(nein(x) for x in pos4),
                      " · ".join(f"Y {x['Y']:g} {'belegt' if x['belegt'] else 'nicht belegt'}" for x in pos4)))
        nul = [lauf(s, 0.0, horizonte=(1, 4)) for s in (1, 2, 3, 4)]
        pruef.append(("Nulltest (Cluster ohne Wirkung): Y = 0, nie belegt",
                      all(m["h"]["1"]["Y"] == 0 and not m["h"]["1"]["belegt"] and not m["h"]["4"].get("belegt") for m in nul),
                      " · ".join(f"1 h Y {m['h']['1']['Y']:g}, 4 h Y {m['h']['4'].get('Y')}" for m in nul)))
        stoer = [lauf(s, 0.0, kopplung=0.3)["h"]["1"] for s in (1, 2, 3, 4)]
        ohne_spiegel = sum(1 for x in stoer if x["Y"] > 0 and x.get("se") and x["d_loss"] > 2 * x["se"] and (x.get("placebo") or {}).get("Y") == 0)
        pruef.append(("Störfaktor (nahe Cluster, höhere Schwankung, keine Kaskade): nie belegt", not any(x["belegt"] for x in stoer),
                      f"Seitenspiegel verhindert {ohne_spiegel} Fehlbefund(e), die Zeit-Placebo allein durchgelassen hätte · "
                      + " · ".join(f"Y {x['Y']:g}, Spiegel {(x.get('spiegel') or {}).get('d_loss', 0):+.3f} ± {(x.get('spiegel') or {}).get('se') or 0:.3f}" for x in stoer)))
        # 23.44: Schwankung mit Gedächtnis wie auf dem Pi (τ wahr 0,6) -- ohne Kaskaden: Y = 0, die Mischung wird erkannt, große
        # Ausschläge werden richtig vorhergesagt (vorher: ≥ 2 σ rund halb so oft vorhergesagt wie eingetreten); mit Kaskaden: belegt
        svn = [lauf(s_, 0.0, sv=0.6)["h"]["1"] for s_ in (1, 2, 3)]
        dd = [x["kal_2"]["e"] - x["kal_2"]["p"] for x in svn]; sse = math.sqrt(sum((x["kal_2"]["se"] or 0) ** 2 for x in svn)) / len(svn)
        pruef.append(("Schwankung mit Gedächtnis ohne Kaskaden: Y = 0, τ erkannt, ≥ 2 σ richtig vorhergesagt",
                      all(x["Y"] == 0 and x.get("tau", 0) >= 0.3 for x in svn) and abs(sum(dd) / len(dd)) <= 2 * sse,
                      " · ".join(f"Y {x['Y']:g}, τ {x.get('tau', 0):g}, ≥ 2 σ {x['kal_2']['p'] * 100:.1f} → {x['kal_2']['e'] * 100:.1f} %" for x in svn)
                      + f" · Abstand im Mittel {sum(dd) / len(dd) * 100:+.2f} ± {sse * 100:.2f} Punkte"))
        svp = [lauf(s_, 2.0, sv=0.6)["h"]["1"] for s_ in (1, 2)]
        pruef.append(("Schwankung mit Gedächtnis mit Kaskaden (Y wahr 2): gefunden und belegt",
                      all((x["Y"] or 0) >= 0.5 for x in svp) and any(x["belegt"] for x in svp),
                      " · ".join(f"Y {x['Y']:g}, τ {x.get('tau', 0):g}, Abstand {x['d_loss']:+.3f} ± {x['se']:.3f}, Spiegel {(x.get('spiegel') or {}).get('d_loss', 0):+.3f}, "
                                 f"{'belegt' if x['belegt'] else 'nicht belegt'}" for x in svp)))
        # Blöcke über gezielte Abfragen (erster Stand je Block, Eimer nur bis zur größten Tiefe) = alles lesen und dann filtern
        # (der Weg bis 23.43-Entwurf, hier als Orakel) -- mit zusätzlichen tiefen und falschseitigen Eimern in jedem Stand
        import hl_anker
        import random as _r
        con, now = _probe_markt(os.path.join(tmp, "voll.db"), 5, tage=12, y_wahr=2.0)
        try:
            rng = _r.Random(5); extra = []; kurs = dict(con.execute("SELECT ts, close FROM bars WHERE coin='BTC'"))
            for (t_,) in con.execute("SELECT DISTINCT ts FROM heatmap WHERE coin='BTC'").fetchall():
                p_ = kurs.get(t_ // 60 * 60)
                for _ in range(40 if p_ else 0):
                    extra.append((t_, "BTC", round(p_ * math.exp(rng.uniform(-0.4, 0.4)), 6), rng.choice(("long", "short")),
                                  rng.uniform(1e5, 5e7), 1, None, None, None))
            con.executemany("INSERT OR REPLACE INTO heatmap VALUES (?,?,?,?,?,?,?,?,?)", extra); con.commit()
            von = now - 12 * 86_400; M = hl_anker.Markt(con, "BTC", von, now)

            def orakel(h):
                block = h * 3600; snaps: dict = {}; out = []
                for t_, px, side, usd in con.execute("SELECT ts, bucket_px, side, notional FROM heatmap WHERE coin='BTC' AND ts>=? AND ts<=? "
                                                     "AND ts % ? < 900 ORDER BY ts", (von, now - block, block)).fetchall():
                    e_ = snaps.setdefault(int(t_) // block, [int(t_), []])
                    if e_[0] == int(t_):
                        e_[1].append((px, side, usd))
                for b_ in sorted(snaps):
                    t_, r_ = snaps[b_]; p0 = M.preis(t_); s4 = M.sigma(t_); vh = M.volumen(t_)
                    i = bisect.bisect_right(M.ts, t_); j = bisect.bisect_right(M.ts, t_ + block)
                    if not (p0 and s4 and vh) or j - i < 0.9 * block / 60 or M.ts[j - 1] < t_ + block - 180:
                        continue
                    out.append((t_, cluster_aus(r_, p0, s4)))
                return out
            vgl = {h: ([(b_["ts"], b_["cl"]) for b_ in bloecke(con, "BTC", h, von, now, M)], orakel(h)) for h in (1, 4)}
            n_cl = sum(len(c_[s]) for _, c_ in vgl[1][0] for s in ("ab", "auf"))
            pruef.append(("Blöcke: gezielte Abfrage = ganze Heatmap gelesen und gefiltert", all(a_ == o_ and a_ for a_, o_ in vgl.values()),
                          f"1 h {len(vgl[1][0])} von {len(vgl[1][1])} Blöcken, 4 h {len(vgl[4][0])} von {len(vgl[4][1])}; {len(extra)} zusätzliche Eimer "
                          f"bis ±40 % (auch falschseitig), {n_cl} Cluster in Reichweite (1 h)"))
        finally:
            con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def live_probe(verbose: bool = True) -> tuple:
    """Stand jetzt, Treiber, Payload und Anzeige auf einer Karte zum Nachrechnen; veralteter Stand; gespeicherte Kalibrierung."""
    import random as _r
    import shutil
    import tempfile
    pruef = []; tmp = tempfile.mkdtemp(prefix="hl_kaskade_live_")
    store_alt = F.STORE
    F.STORE = os.path.join(tmp, "prognosen.db")                       # 23.44: nie den echten Prognosespeicher lesen (auf dem Pi: 268 statt 183 Zeichen)
    try:
        con = sqlite3.connect(os.path.join(tmp, "live.db"))
        con.executescript("""CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER,
                                 PRIMARY KEY (ts, coin)) WITHOUT ROWID;
                             CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER, lev_wavg REAL,
                                 entry_wavg REAL, cross_share REAL, PRIMARY KEY (ts, coin, bucket_px, side)) WITHOUT ROWID;""")
        rng = _r.Random(8); now = PROBE_NOW; x = math.log(60_000.0); v_tag = 1.5e9; rows = []
        for t in range(now - 10 * 86_400, now + 60, 60):
            o = math.exp(x); x += rng.gauss(0, 0.0006); c = math.exp(x)
            rows.append((t, "BTC", o, max(o, c), min(o, c), c, v_tag / 1440 / c, 5))
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
        p = math.exp(x)

        def karte(ts, seite_gross):
            con.execute("DELETE FROM heatmap")
            g, k = ("long", "short") if seite_gross == "ab" else ("short", "long")
            f = -1 if seite_gross == "ab" else 1
            con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?,?,?,?)",
                            [(ts, "BTC", p * math.exp(f * 0.005), g, 0.08 * v_tag, 40, None, None, None),     # Wirkung 0,65 % > 0,5 σ_4h
                             (ts, "BTC", p * math.exp(-f * 0.03), k, 0.001 * v_tag, 3, None, None, None)])
            con.commit(); _CACHE.clear()
        karte(now - 120, "ab")
        z = zustand(con, "BTC", now, p0=p)
        drv, fehlt = [], []
        treiber(con, "BTC", p, lambda n, s, w, t: drv.append((n, s, w, t)), fehlt, now)
        ref = (z.get("seiten") or {}).get("ab", {}).get("ref") or {}
        ok = (not z.get("fehlt") and z["A"] < -0.5 and ref.get("kipp") is not None and 0.005 - 1e-9 <= ref["kipp"] <= 0.005 + 0.02 * z["sig4"]
              and ref["ende_kipp"] - ref["kipp"] >= KIPP_EXT * z["sig4"] and z["seiten"]["auf"]["ref"]["kipp"] is None
              and len(drv) == 1 and drv[0][0] == NAME and drv[0][1] < -0.5 and drv[0][2] == 0.0 and not fehlt)
        # Treiber und Kipppunkt werden vorwärts gemessen (Familie „Kaskaden“, Labor „Kaskaden-Kipppunkt“): auf dieser Karte genau
        # die Werte von 23.43, sonst wäre ihre Reihe nicht mehr vergleichbar
        ok = (ok and abs(drv[0][1] - (-0.8001767487069966)) < 1e-9 and abs(ref["kipp"] - 0.005044758667849047) < 1e-12
              and abs(ref["ende_kipp"] - 0.011286028899733359) < 1e-12 and abs(z["seiten"]["ab"]["mehrweg"] - 0.40104796107540175) < 1e-9)
        pruef.append(("Live: großes Long-Cluster 0,5 % unter dem Kurs", ok,
                      f"Asymmetrie {z.get('A', 0):+.2f}, Kipppunkt −{(ref.get('kipp') or 0) * 100:.2f} % → Ende −{(ref.get('ende_kipp') or 0) * 100:.2f} %, "
                      f"Treiber {drv[0][1] if drv else '—'} (Gewicht {drv[0][2] if drv else '—'})"))
        karte(now - 120, "auf")
        z2 = zustand(con, "BTC", now, p0=p)
        pruef.append(("Live: gespiegelt (Short-Cluster darüber) → Vorzeichen dreht", not z2.get("fehlt") and abs(z2["A"] + z["A"]) < 0.05 and z2["A"] > 0.5,
                      f"Asymmetrie {z2.get('A', 0):+.2f} gegen {z.get('A', 0):+.2f}"))
        karte(now - 2 * 3600, "ab")
        fehlt2 = []; drv2 = []
        treiber(con, "BTC", p, lambda n, s, w, t: drv2.append(n), fehlt2, now)
        pruef.append(("Live: Heatmap-Stand älter als 30 min → kein Treiber", not drv2 and len(fehlt2) == 1 and NAME in fehlt2[0], fehlt2[0] if fehlt2 else "—"))
        karte(now - 120, "ab")
        fc = {"coin": "BTC", "ts": now, "price": p}
        ergaenzen(con, fc, now=now)
        k = fc.get("kaskade") or {}; info = fc.get("kaskade_info") or {}
        ok = (k.get("A") is not None and k["A"] < -0.5 and k.get("kipp_ab") and k["kipp_ab"] < p and k.get("kipp_auf") is None
              and len(json.dumps(k)) < 600 and (info.get("seiten") or {}).get("ab", {}).get("ref", {}).get("kipp_pct", 0) < 0)
        ok = ok and "bilanz" not in info and k.get("v") == VERSION                 # leerer eigener Speicher: kein Modell, keine Bilanz
        pruef.append(("Live: Payload schlank, Anzeige vollständig", ok, f"Payload {len(json.dumps(k))} Zeichen, Kipppunkt {k.get('kipp_ab')}, Anzeige "
                      f"{', '.join(sorted(info))}"))
        # Durchleitung: eine gespeicherte, für 4 h belegte Kalibrierung (Y 2) wirkt in Treiber-Weg und Payload; eine v1-Kalibrierung nicht
        F.learned_save("BTC", "kaskade", {"version": 1, "coin": "BTC", "ts": now, "h": {"4": {"Y": 2.0, "c": 1.0, "belegt": True}}}, path=F.STORE)
        _CACHE.clear(); fc1 = {"coin": "BTC", "ts": now, "price": p}; ergaenzen(con, fc1, now=now)
        F.learned_save("BTC", "kaskade", {"version": VERSION, "coin": "BTC", "ts": now, "h": {"4": {"Y": 2.0, "c": 1.0, "tau": 0.6, "c0": 1.0, "tau0": 0.6,
                                                                                                 "belegt": True}}}, path=F.STORE)
        _CACHE.clear(); fc2 = {"coin": "BTC", "ts": now, "price": p}; ergaenzen(con, fc2, now=now)
        k1, k2_ = fc1.get("kaskade") or {}, fc2.get("kaskade") or {}
        ok = (k1.get("y_kipp") == Y_REF and k1.get("Y4") is None and k2_.get("y_kipp") == 2.0 and k2_.get("belegt4") is True
              and k2_.get("ende_ab") and k2_["ende_ab"] < k1["ende_ab"] and k2_.get("p2_ab", 0) > k2_.get("p2_basis", 1))
        pruef.append(("Live: gespeicherte Kalibrierung wird durchgeleitet (v1 nicht)", ok,
                      f"v1 → y_kipp {k1.get('y_kipp')}, Ende {k1.get('ende_ab', 0):.2f} · v2 (4 h belegt, Y 2) → y_kipp {k2_.get('y_kipp')}, Ende "
                      f"{(k2_.get('ende_ab') or 0):.2f}, P(Rutsch ≥ 2 σ) {k2_.get('p2_ab', 0) * 100:.1f} % gegen ohne Heatmap {k2_.get('p2_basis', 0) * 100:.1f} %"))
        con.close()
        # Gespeicherte Kalibrierung wird genutzt (Positivkontrolle, Y wahr 2)
        con, now2 = _probe_markt(os.path.join(tmp, "kal.db"), 1, tage=30, y_wahr=2.0, periode_h=1)
        sp = os.path.join(tmp, "f.db")
        m = kalibrieren(con, "BTC", now2, path=sp, speichern=True, tage=30); _CACHE.clear()
        z3 = zustand(con, "BTC", now2, path=sp)
        mh = ((z3.get("modell") or {}).get("h") or {}).get("1") or {}
        txt = stand_text(con, path=sp, now=now2, coins=["BTC"])
        ok = (mh.get("Y") == m["h"]["1"]["Y"] and mh.get("belegt") == m["h"]["1"]["belegt"] and "Kalibrierung vom" in txt and "Seitenspiegel" in txt
              and "Kipppunkt" in txt and "Richtung" in txt)
        pruef.append(("Live: gespeicherte Kalibrierung wirkt, Debug-Bericht läuft", ok,
                      f"Modell 1 h: Y {mh.get('Y')}, {'belegt' if mh.get('belegt') else 'nicht belegt'} · Bericht {len(txt.splitlines())} Zeilen"))
        con.close()
    finally:
        F.STORE = store_alt
        _CACHE.clear()
        shutil.rmtree(tmp, ignore_errors=True)
    _zeigen(pruef, verbose)
    return all(p[1] for p in pruef), pruef


def nulltest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Kaskaden-Gleichung -- Selbsttest (Mathematik, Positivkontrolle, Nulltest, Störfaktor, Live)")
    ok = True
    for teil in (mathe_probe, kalib_probe, live_probe):
        try:
            gut, _ = teil(verbose)
        except Exception as e:
            import traceback
            gut = False
            if verbose:
                print(f"  FEHL {teil.__name__}: {type(e).__name__}: {e}")
                traceback.print_exc()
        ok = ok and gut
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--stand" in sys.argv or "--kalibrieren" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True, timeout=30) if os.path.exists(_db) else None
        if "--kalibrieren" in sys.argv and _con is not None:
            print("Kalibrierung je Coin:", json.dumps(takt(_con), ensure_ascii=False))
        print(stand_text(_con))
        sys.exit(0)
    print(__doc__)
