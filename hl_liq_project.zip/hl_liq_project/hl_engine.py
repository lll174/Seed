#!/usr/bin/env python3
"""
Trading Engine (U241, KONZEPT_TradingEngine.md Fassung 3, Entscheidung des Nutzers 03.11.2026 23:23 „Wie vorgeschlagen“).

Das TradeLabor bleibt unverändert der Schatten. Die Engine wählt aus seinen Strategien die belegten aus und übernimmt nur deren Trades auf
ein Papierkonto mit gemeinsamem Kapital (100.000 USD, 10.000 USD je Trade, höchstens 10 Positionen, 4 je Coin, 6 in dieselbe Richtung,
Bremse bei −10 % vom Höchststand). Sie liest nur: keine Order, kein Gewicht, keine Wirkung auf das Labor oder eine Prognose. Grundlage
ist Welt B (das Labor in forecasts.db, ohne Notbremse).

Regeln (vorab festgelegt, Konzept Abschnitt 4):
  Daten        Tagessumme je Strategie (Netto aller an einem UTC-Tag eröffneten Trades, Summe wie im Konto) und Zahl der Trades; ein Tag
               gilt, wenn alle seine Trades geschlossen sind; ein Ausfalltag (Labor > 1 h ohne Takt) fehlt; Wochen Montag–Sonntag.
  Aufnahme     dienstags 00:30 UTC für die Woche bis Sonntag, sobald alle ihre Trades geschlossen sind (sonst am nächsten Tag 00:30):
               (A) ganze Geschichte, ≥ 9 Wochen und 30 Trades, t ≥ 4,0, beide Hälften positiv; oder (B) letzte 17 Wochen, ≥ 15 gültige
               Wochen und 30 Trades, t ≥ 4,5, beide Hälften positiv. Nach einer Pause frühestens 30 Tage danach, über (A) nur mit
               positiver Summe seit der Pause; nach „gescheitert“ nur (B).
  Pause        täglich 00:30 UTC: CUSUM in Handelszeit seit der Aufnahme (Bezug: halbe Netto-Rendite je Trade bei der Aufnahme, Mittel
               minus ein Standardfehler; je Tag gekappt bei ±3·√n); Grenze aus Siegmunds Näherung für 730 Tage × Trades je Tag.
  Gescheitert  Bezeichnung, wöchentlich: ≥ 13 Wochen und 90 Tage, t ≤ −3, beide Hälften negativ, Tagesmittel negativ in steigenden und
               in fallenden BTC-Monaten (je ≥ 28 Tage); gezählt seit dem Start bzw. seit der letzten Rückkehr.

Bau (vor dem ersten Lauf festgelegt, KONZEPT Abschnitt 15): Der Zustand wird bei jeder Rechnung aus den Labor-Trades neu abgespielt
(deterministisch, je Prüfung nur Trades, die bis dahin geschlossen waren); jede Entscheidung seit dem Start steht zusätzlich im Protokoll
in engine.db, und der Bericht meldet, wenn eine Neuberechnung davon abweicht. Ausfälle kennt die Engine erst ab dem Einspielen (Puls
alle 5 min, solange der Labor-Takt fortschreitet). Die Bremse prüft das realisierte Konto täglich um 00:30 UTC; gelöst wird sie nur von
Hand (seit 23.94 Button „Bremse lösen“ im Reiter „Engine“ des TradeLabors, mit Nachfrage; in 23.93 Debug 142): ab der nächsten Prüfung
gilt der Kontostand als neuer Höchststand, von der Bremse pausierte Strategien gelten als beobachtet und werden sofort nach (A)/(B)
geprüft (ohne Abkühlung; die Bremse ist kein Befund über die einzelne Strategie). Ein vorgemerktes Lösen zeigt der Stand als
„loesen_vorgemerkt“ (aus den Ereignissen in engine.db beim Lesen bestimmt, nicht im gespeicherten Stand).
"""
import heapq
import json
import math
import os
import sqlite3
import sys
import threading
import time

import numpy as np

VERSION_MODUL = "2026-09-23.94"
FASSUNG = 3
TAG = 86_400
PRUEF_S = 1_800                       # Prüfung um 00:30 UTC
KAPITAL = 100_000.0
NOTIONAL = 10_000.0
MAX_POS, MAX_COIN, MAX_RICHTUNG = 10, 4, 6
BREMSE_ANTEIL = 0.10
C_A, C_B = 4.0, 4.5
MIN_WOCHEN_A, FENSTER_B, MIN_GUELTIG_B, MIN_TRADES = 9, 17, 15, 30
ABK_TAGE = 30
ARL0_TAGE = 730
KAPPUNG = 3.0
FAIL_T, FAIL_WOCHEN, FAIL_TAGE, MONAT_MIN_TAGE = -3.0, 13, 90, 28
AUSFALL_S, PULS_S, RECHNEN_S = 3_600, 300, 600
HAENGER_S = 72 * 3_600            # Trade 72 h nach dem Ende seines Tages noch offen: die Überwachung steht
# Die 34 Kandidaten (Konzept 3): Händler, Darwin, Elite, Prognose, Kauf-/Verkaufspreise, Familien, Ereignisse -- höchstens 24 h Haltedauer
UMFANG = ("wale_folgen", "wale_gegen", "leaderboard_folgen", "leaderboard_gegen", "smartmoney_folgen", "smartmoney_gegen", "pool_folgen",
          "pool_gegen", "darwin_folgen", "darwin_gegen", "elite_folgen", "elite_gegen", "prognose_v1", "prognose_v2", "prognose_fusion",
          "prognose_fusion_kosten", "empfehlung_limit", "familie_grosskonten", "familie_trend", "familie_momentum", "familie_orderfluss",
          "familie_funding", "familie_etf", "familie_analog", "familie_pool", "familie_profi", "kaskade_umkehr", "kaskade_fortsetzung",
          "docht_fangen", "magnet", "kaskade_kipppunkt", "funding_extrem", "ausbruch_ruhe", "twap_druck")
KONTROLLEN = ("zufall", "halten_long")
ZUSTAND_TEXT = {0: "beobachtet", 1: "aktiv", 2: "pausiert", 3: "beendet"}
_MUT = None                            # nur für die Mutationsprüfung (mutationen_pruefen setzt sie im Prozess)
MUTATIONEN = {
    "mittel_statt_summe": "Tageswert als Mittel je Trade statt als Summe",
    "offene_mitzaehlen": "Tage mit offenen Trades zählen schon",
    "ausfall_als_null": "Ausfalltag zählt als Tag ohne Trade (statt zu fehlen)",
    "woche_unvollstaendig": "die laufende Woche zählt schon",
    "nur_A": "nur (A), ohne das 17-Wochen-Fenster",
    "ohne_abkuehlung": "nach einer Pause ohne Abkühlung",
    "abkuehlung_summe_auch_B": "positive Summe seit der Pause auch für (B) verlangt",
    "cusum_in_tagen": "Überwachung in Tagen statt in Trades",
    "bezug_ohne_abschlag": "Bezug ohne Abschlag eines Standardfehlers",
    "grenze_fest": "Grenze fest statt aus der Laufzeit",
    "ohne_kappung": "Überwachung ohne Kappung je Tag",
    "gescheitert_ohne_monate": "„gescheitert“ ohne die Bedingung steigender und fallender Monate",
    "gescheitert_ohne_haelften": "„gescheitert“ ohne die Bedingung beider Hälften",
    "nach_gescheitert_A": "nach „gescheitert“ auch (A) erlaubt",
    "ohne_mindestzahl": "ohne Mindestzahl von 30 Trades",
    "pausierte_uebernommen": "Trades pausierter Strategien übernommen",
    "kapazitaet_ignoriert": "Kapazität von 10 Positionen ignoriert",
    "coin_grenze_ignoriert": "Grenze von 4 Positionen je Coin ignoriert",
    "richtung_grenze_ignoriert": "Grenze von 6 Positionen je Richtung ignoriert",
    "bremse_aus": "Bremse bei −10 % aus",
    "kontrollen_kandidat": "Kontrollen (Zufall, Halten Long) als Kandidaten",
    "zukunft": "Zustand nutzt Trades, die erst nach dem Prüfzeitpunkt schließen",
    "rueckkehr_alte_daten": "„gescheitert“ zählt nach einer Rückkehr die alten Wochen mit",
    "nur_aktuelle_version": "nur die aktuelle Regelversion gelesen (übernommene Trades einer abgelösten Version fallen weg)",
    "bremse_nach_aufnahme": "Bremse erst nach der Aufnahme derselben Prüfung",
    "ausfall_vorausgesehen": "Ausfall gilt schon vor dem Zeitpunkt, ab dem er bekannt war",
    "haenger_ignoriert": "Strategie bleibt aktiv, obwohl ihre Überwachung wegen eines offenen Trades steht",
    "monat_ohne_vormonat": "Monatsart auch ohne den letzten Tag des Vormonats",
    "loesen_ohne_vormerkung": "ein Lösen der Bremse wird nicht als vorgemerkt gezeigt (der Button käme wieder, zweiter Eintrag)",
    "loesen_ohne_bremse": "Lösen auch ohne gesetzte Bremse eingetragen",
}
SCHEMA = """
CREATE TABLE IF NOT EXISTS eng_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS eng_puls (ts INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS eng_protokoll (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, sid TEXT, name TEXT, alt TEXT, neu TEXT,
    grund TEXT, werte TEXT, geschrieben INTEGER, UNIQUE (ts, sid, neu));
CREATE TABLE IF NOT EXISTS eng_stand (k TEXT PRIMARY KEY, ts INTEGER, v TEXT);
"""


def umfang() -> tuple:
    """Die Kandidaten; mit der Mutation „kontrollen_kandidat“ auch die Kontrollen (der Selbsttest muss rot werden)."""
    return UMFANG + (KONTROLLEN if _MUT == "kontrollen_kandidat" else ())


def engine_pfad(db: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(db)), "engine.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def meta(con, k, standard=None):
    r = con.execute("SELECT v FROM eng_meta WHERE k=?", (k,)).fetchone()
    if not r:
        return standard
    try:
        return json.loads(r[0])
    except ValueError:
        return standard


def meta_setzen(con, k, v) -> None:
    con.execute("BEGIN IMMEDIATE")
    try:
        con.execute("INSERT OR REPLACE INTO eng_meta VALUES (?, ?)", (k, json.dumps(v)))
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def _jd(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, (np.ndarray, set, tuple)):
        return list(o)
    raise TypeError(type(o).__name__)


def _z(x, nd=3):
    """Zahl für die Nutzlast: gerundet, nicht endlich → None."""
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return round(x, nd) if math.isfinite(x) else None


def _de(x, nd=1) -> str:
    try:
        x = float(x)
    except (TypeError, ValueError):
        return "—"
    return f"{x:.{nd}f}".replace(".", ",").replace("-", "−") if math.isfinite(x) else "—"


def _datum(ts) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(ts))) if ts is not None else "—"


# ------------------------------------------------------------------------------------------------ Statistik
def siegmund_grenze(k: float, arl0: float) -> float:
    """Grenze h der einseitigen CUSUM mit Bezug k (in Streuungen) für die mittlere Laufzeit arl0 (in Trades): Siegmunds Näherung
    (exp(2kb) − 2kb − 1)/(2k²) = arl0 mit b = h + 1,166; für k → 0 gilt b = √arl0; nie unter 2."""
    if _MUT == "grenze_fest":
        return 12.0
    arl0 = max(float(arl0), 4.0)
    k = float(k)
    if k < 1e-4:
        b = math.sqrt(arl0)
    else:
        lo, hi = 0.0, 400.0
        for _ in range(100):
            b = (lo + hi) / 2
            x = min(2 * k * b, 700.0)
            v = (math.exp(x) - x - 1) / (2 * k * k)
            lo, hi = (lo, b) if v > arl0 else (b, hi)
        b = (lo + hi) / 2
    return max(2.0, b - 1.166)


def cusum_zuwachs(n_tag, y_tag, k, s_t):
    """Zuwachs der Pause-Summe für vollständige Tage in Handelszeit: n · k − y / s, gekappt bei ±3 · √n; ohne Trade 0 (auch vektoriell)."""
    n_tag = np.asarray(n_tag, dtype=float); y_tag = np.asarray(y_tag, dtype=float)
    k = np.asarray(k, dtype=float); s_t = np.asarray(s_t, dtype=float)
    if _MUT == "cusum_in_tagen":                                     # Fehler: Bezug je Tag (drei Trades) statt je Trade
        inc = 3.0 * k - y_tag / (s_t * math.sqrt(3.0))
        return np.clip(inc, -KAPPUNG * math.sqrt(3.0), KAPPUNG * math.sqrt(3.0))
    inc = n_tag * k - y_tag / s_t
    if _MUT == "ohne_kappung":
        return np.where(n_tag > 0, inc, 0.0)
    lim = KAPPUNG * np.sqrt(np.maximum(n_tag, 1.0))
    return np.where(n_tag > 0, np.clip(inc, -lim, lim), 0.0)


def t_wert(x) -> tuple:
    """(t, Mittel, Mittel erste Hälfte, Mittel zweite Hälfte, n) einer Reihe (Stichprobenstreuung; Hälften n//2 und Rest)."""
    x = np.asarray(x, dtype=float)
    n = int(x.size)
    if n < 3:
        return float("nan"), float("nan"), float("nan"), float("nan"), n
    mu = float(x.mean()); sd = float(x.std(ddof=1))
    h = n // 2
    if sd > 0:
        t = mu / (sd / math.sqrt(n))
    else:
        t = math.inf if mu > 0 else (-math.inf if mu < 0 else float("nan"))
    return t, mu, float(x[:h].mean()), float(x[h:].mean()), n


def bezug(y_tage, n_tage, w_summen) -> dict:
    """Bezug der Überwachung aus dem Fenster der Aufnahme: Tagesmittel minus ein Standardfehler (aus den Wochensummen ÷ 7), je Trade;
    Streuung je Trade aus Var(Tageswert) = λ · s²; k = μ_Trade / s / 2; Grenze aus Siegmund für 730 Tage × λ Trades."""
    y_tage = np.asarray(y_tage, dtype=float); n_tage = np.asarray(n_tage, dtype=float); w_summen = np.asarray(w_summen, dtype=float)
    nd = max(int(y_tage.size), 1)
    mu_d = float(y_tage.mean()) if y_tage.size else 0.0
    var_d = float(y_tage.var(ddof=1)) if y_tage.size > 1 else 0.0
    se_d = (float(w_summen.std(ddof=1)) / math.sqrt(w_summen.size)) / 7 if w_summen.size > 1 else 0.0
    mu_ref = mu_d if _MUT == "bezug_ohne_abschlag" else max(mu_d - abs(se_d), 0.0)
    lam = max(float(n_tage.sum()) / nd, 1e-9)
    mu_t = mu_ref / lam
    s_t = math.sqrt(max(var_d / lam, 1e-12))
    k = mu_t / s_t / 2
    return {"mu_tag": mu_d, "se_tag": se_d, "mu_ref": mu_ref, "lam": lam, "mu_trade": mu_t, "s_trade": s_t, "k": k,
            "h": siegmund_grenze(k, ARL0_TAGE * lam)}


# ------------------------------------------------------------------------------------------------ Kalender
def wochen_nr(tag: int) -> int:
    """Kalenderwoche ab Montag (Tag 0 = Donnerstag, 01.01.1970; Tag 4 = Montag)."""
    return (int(tag) - 4) // 7


def montag(w: int) -> int:
    return 7 * int(w) + 4


def monat_nr(tag: int) -> int:
    t = time.gmtime(int(tag) * TAG)
    return t.tm_year * 12 + (t.tm_mon - 1)


# ------------------------------------------------------------------------------------------------ Zustände (Abspielen)
class Abspielen:
    """Die Regeln Tag für Tag, vektoriell über die Zeilen (= Strategien bzw. ihre Regelversionen). Eingaben je Zeile und Tag (Index
    j = Tag − g0): Y Tagessumme (USD), N Zahl der Trades, C späteste Schließung der Trades dieses Tages (inf, solange einer offen ist;
    0 ohne Trade); start_tag (erster voller Tag) je Zeile; ende_ts je Zeile (Beginn der nächsten Regelversion im Labor, sonst None);
    je Tag: Ausfall als Zeitpunkt, ab dem der Tag als Ausfalltag bekannt ist (inf = kein Ausfall; bool = von Anfang an bekannt), und
    Monatsart (+1 steigend, −1 fallend, 0 unbekannt; auch je Zeile) samt dem Zeitpunkt, ab dem sie bekannt ist. Jede Prüfung sieht nur
    Tage und Wochen, die bis zu ihrem Zeitpunkt vollständig waren, und nur Ausfälle, die bis dahin bekannt waren."""

    def __init__(self, Y, N, C, start_tag, g0, ausfall=None, monat_art=None, monat_bekannt=None, namen=None, sids=None, ende_ts=None):
        Y = np.array(Y, dtype=float, ndmin=2); N = np.array(N, dtype=float, ndmin=2); C = np.array(C, dtype=float, ndmin=2)
        if _MUT == "mittel_statt_summe":
            Y = np.where(N > 0, Y / np.maximum(N, 1.0), 0.0)
        if _MUT == "zukunft":                                        # Fehler: Schließungen gelten schon am Tagesende als bekannt
            C = np.where(np.isfinite(C), 0.0, C)
        R, T = Y.shape
        self.R, self.T, self.g0 = R, T, int(g0)
        self.Y, self.N = Y, N
        self.ri = np.arange(R)
        self.start = np.array(np.broadcast_to(np.asarray(start_tag, dtype=np.int64), (R,)))
        if ausfall is None:
            aus_bek = np.full(T, np.inf)
        else:
            a_ = np.asarray(ausfall)
            aus_bek = np.where(a_, -np.inf, np.inf) if a_.dtype == bool else a_.astype(float).copy()
        if _MUT == "ausfall_als_null":                               # Fehler: Ausfalltage zählen wie Tage ohne Trade
            aus_bek = np.full(T, np.inf)
        elif _MUT == "ausfall_vorausgesehen":                        # Fehler: ein Ausfall gilt schon vor seiner Bekanntheit
            aus_bek = np.where(np.isfinite(aus_bek), -np.inf, aus_bek)
        self.aus_bek = aus_bek
        self.monat_art = np.zeros(T, dtype=int) if monat_art is None else np.asarray(monat_art, dtype=int)
        self.monat_bekannt = np.full(T, np.inf) if monat_bekannt is None else np.asarray(monat_bekannt, dtype=float)
        self.namen = list(namen) if namen is not None else [f"s{i}" for i in range(R)]
        self.sids = list(sids) if sids is not None else list(self.namen)
        self.ende_ts = (np.full(R, np.inf) if ende_ts is None
                        else np.array([np.inf if e is None else float(e) for e in ende_ts], dtype=float))
        # Tag j ist fertig, wenn er vorbei und jeder seiner Trades geschlossen ist; in der Reihe (ein offener Tag hält die folgenden auf)
        tagende = (self.g0 + np.arange(T) + 1.0) * TAG
        if _MUT == "offene_mitzaehlen":
            fertig = np.repeat(tagende[None, :], R, axis=0)
        else:
            fertig = np.maximum(C, tagende[None, :])
        cm = np.maximum.accumulate(fertig, axis=1)
        self.ptag = np.ceil((cm - PRUEF_S) / TAG)                   # erster Prüftag (absolut), an dem der Tag zählt
        # Wochen Montag–Sonntag relativ zur Woche von g0
        self.w0 = wochen_nr(self.g0)
        self.nW = nW = wochen_nr(self.g0 + T - 1) - self.w0 + 1
        mo = np.array([montag(self.w0 + w) for w in range(nW)], dtype=np.int64) - self.g0
        aa = np.clip(mo, 0, T); bb = np.clip(mo + 7, 0, T)
        self.wa, self.wb = aa, bb
        self.voll = (bb - aa) == 7
        cY = np.concatenate([np.zeros((R, 1)), np.cumsum(Y, axis=1)], axis=1)
        cN = np.concatenate([np.zeros((R, 1)), np.cumsum(N, axis=1)], axis=1)
        self.WY = cY[:, bb] - cY[:, aa]; self.WN = cN[:, bb] - cN[:, aa]
        self.W_aus_bek = np.array([aus_bek[aa[w]:bb[w]].min() if bb[w] > aa[w] else np.inf for w in range(nW)], dtype=float)
        if _MUT == "woche_unvollstaendig":                           # Fehler: schon am Dienstag derselben Woche
            wt = np.repeat((mo + self.g0 + 1).astype(float)[None, :], R, axis=0)
        else:                                                         # Dienstag nach der Woche, sobald alles geschlossen ist
            wt = np.maximum(self.ptag[:, np.clip(bb - 1, 0, max(T - 1, 0))], (mo + self.g0 + 8).astype(float)[None, :])
        wt[:, ~self.voll] = np.inf
        self.wtag = wt
        self.tag_woche = np.full(T, -1, dtype=np.int64)
        for w in range(nW):
            self.tag_woche[aa[w]:bb[w]] = w
        erste = np.array([wochen_nr(s) + (0 if (int(s) - 4) % 7 == 0 else 1) for s in self.start], dtype=np.int64) - self.w0
        self.w_erste = np.maximum(erste, 0)                           # erste volle Woche ab dem Start
        # Zustand (0 beobachtet, 1 aktiv, 2 pausiert, 3 beendet)
        self.zust = np.zeros(R, dtype=np.int8)
        self.gesch = np.zeros(R, bool); self.gesch_seit = np.full(R, -1, dtype=np.int64); self.fail_w = self.w_erste.copy()
        self.zurueck = np.full(R, -1, dtype=np.int64)
        self.t_pause = np.full(R, -10 ** 12, dtype=np.int64); self.tag_pause = np.full(R, -1, dtype=np.int64)
        self.durch_bremse = np.zeros(R, bool)
        self.durch_haenger = np.zeros(R, bool); self.haenger_tag = np.full(R, -1, dtype=np.int64)
        self.auf_tag = np.full(R, -1, dtype=np.int64); self.auf_ts = np.full(R, -1, dtype=np.int64)
        self.auf_fenster = [""] * R
        self.S = np.zeros(R); self.k = np.zeros(R); self.s_t = np.ones(R); self.h = np.full(R, np.inf)
        self.zeiger = np.clip(self.start - self.g0, 0, T)             # nächster Tag für die Überwachung
        self.wz = np.minimum(self.w_erste, nW)                        # nächste Woche, deren Bereitschaft geprüft wird
        self.w_aus = np.full(R, -1, dtype=np.int64)                   # zuletzt ausgewertete Woche
        self.bremse = False; self.bremse_seit = -1
        self.protokoll: list = []
        self.letzte_pruefung: dict = {}
        self.aktiv_tage = np.zeros((R, T), bool)                      # Zustand „aktiv“ nach der Prüfung des Tages
        self.n_pause = np.zeros(R, dtype=int); self.n_auf = np.zeros(R, dtype=int)
        self.erst_auf = np.full(R, -1, dtype=np.int64); self.erst_fail = np.full(R, -1, dtype=np.int64)
        self.auf_tage = [[] for _ in range(R)]; self.pause_tage = [[] for _ in range(R)]

    # --- Hilfen
    def _art(self, i):
        return self.monat_art[i] if self.monat_art.ndim == 2 else self.monat_art

    def gueltige(self, i, w_von, w_bis, R_ts) -> np.ndarray:
        """Gültige Wochen (voll, ohne bis R_ts bekannten Ausfall) der Zeile i von w_von bis w_bis (einschließlich, nicht vor der ersten
        vollen Woche)."""
        lo = max(int(w_von), int(self.w_erste[i]), 0); hi = min(int(w_bis) + 1, self.nW)
        if hi <= lo:
            return np.zeros(0, dtype=np.int64)
        idx = np.arange(lo, hi)
        return idx[self.voll[lo:hi] & ~(self.W_aus_bek[lo:hi] <= R_ts)]

    def tage_der_wochen(self, idx) -> np.ndarray:
        m = np.zeros(self.nW, bool); m[np.asarray(idx, dtype=np.int64)] = True
        tw = self.tag_woche
        return np.nonzero((tw >= 0) & m[np.maximum(tw, 0)])[0]

    def monatsmittel(self, i, tage, R_ts) -> tuple:
        """Tagesmittel und Zahl der Tage in steigenden und fallenden (bis R_ts abgeschlossenen) Monaten über die gegebenen Tage."""
        tage = np.asarray(tage, dtype=np.int64)
        if not tage.size:
            return float("nan"), 0, float("nan"), 0
        a = np.where(self.monat_bekannt[tage] <= R_ts, self._art(i)[tage], 0)
        y = self.Y[i, tage]
        n_up, n_dn = int((a > 0).sum()), int((a < 0).sum())
        return (float(y[a > 0].mean()) if n_up else float("nan"), n_up, float(y[a < 0].mean()) if n_dn else float("nan"), n_dn)

    def summe_seit_pause(self, i, R_ts) -> float:
        """Summe der seit der Pause gezählten Tage (ohne bis R_ts bekannte Ausfalltage)."""
        j0 = max(int(self.tag_pause[i]), 0); j1 = min(int(self.zeiger[i]), self.T)
        if j1 <= j0:
            return 0.0
        return float(self.Y[i, j0:j1][~(self.aus_bek[j0:j1] <= R_ts)].sum())

    def ausfalltage(self, R_ts) -> int:
        return int((self.aus_bek <= R_ts).sum())

    def _log(self, i, R_ts, alt, neu, grund, werte=None):
        self.protokoll.append({"ts": int(R_ts), "sid": self.sids[i] if i is not None else "engine",
                               "name": self.namen[i] if i is not None else "Engine", "alt": alt, "neu": neu, "grund": grund,
                               "werte": werte or {}})

    # --- Prüfung (in abspielen: beenden, ueberwachen, Bremse, wochen)
    def pruefen(self, D: int, R_ts: int) -> None:
        """Prüfung am Tag D (absolut) um R_ts ohne Konto: Regelversionen, Überwachung, Wochen."""
        self.beenden(D, R_ts)
        self.ueberwachen(D, R_ts)
        self.wochen(D, R_ts)

    def beenden(self, D: int, R_ts: int) -> None:
        """Eine Regelversion, die im Labor abgelöst wurde, endet an der ersten Prüfung danach: kein Trade, keine Prüfung mehr."""
        for i in np.nonzero((self.ende_ts <= R_ts) & (self.zust != 3))[0]:
            i = int(i)
            alt = ZUSTAND_TEXT[int(self.zust[i])]
            self.zust[i] = 3; self.durch_bremse[i] = False; self.durch_haenger[i] = False
            self._log(i, R_ts, alt, "beendet", f"neue Regelversion im Labor seit {time.strftime('%d.%m.%Y %H:%M', time.gmtime(self.ende_ts[i]))}"
                      " UTC -- von dieser Kennung übernimmt die Engine keinen Trade mehr")

    def ueberwachen(self, D: int, R_ts: int) -> None:
        """Überwachung über die neu vollständigen Tage (in der Reihe); danach Hänger: steht die Überwachung einer aktiven Strategie,
        weil ein Trade 72 h nach dem Ende seines Tages noch offen ist, pausiert sie (ohne Abkühlung, zurück, sobald der Tag zählt)."""
        T = self.T
        while True:
            m = self.zeiger < T
            if not m.any():
                break
            jj = np.minimum(self.zeiger, T - 1)
            adv = m & (self.ptag[self.ri, jj] <= D)
            if not adv.any():
                break
            rr = np.nonzero(adv)[0]; jr = jj[rr]
            akt = (self.zust[rr] == 1) & (jr >= self.auf_tag[rr]) & ~(self.aus_bek[jr] <= R_ts)
            if akt.any():
                r2 = rr[akt]; j2 = jr[akt]
                S = np.maximum(0.0, self.S[r2] + cusum_zuwachs(self.N[r2, j2], self.Y[r2, j2], self.k[r2], self.s_t[r2]))
                self.S[r2] = S
                for i in r2[S >= self.h[r2]]:
                    i = int(i)
                    self._pausieren(i, D, R_ts, f"Überwachung: Summe {_de(self.S[i], 1)} erreicht die Grenze {_de(self.h[i], 1)}",
                                    {"S": _z(self.S[i], 2), "h": _z(self.h[i], 2)})
            self.zeiger[rr] += 1
        for i in np.nonzero(self.durch_haenger & (self.zust == 2) & (self.zeiger > self.haenger_tag))[0]:
            i = int(i)
            self.zust[i] = 0; self.durch_haenger[i] = False
            self._log(i, R_ts, "pausiert", "beobachtet", "Überwachung läuft wieder: wieder Kandidat ohne Abkühlung")
        if _MUT == "haenger_ignoriert":
            return
        jj = np.minimum(self.zeiger, max(T - 1, 0))
        steht = (self.zust == 1) & (self.zeiger < T) & ((self.g0 + jj + 1) * TAG + HAENGER_S <= R_ts)
        for i in np.nonzero(steht)[0]:
            i = int(i); j = int(jj[i])
            self._pausieren(i, D, R_ts, f"Überwachung steht: ein Trade vom {_datum((self.g0 + j) * TAG)} ist 72 h nach dem Ende "
                            "seines Tages noch offen", {"tag": self.g0 + j})
            self.durch_haenger[i] = True; self.haenger_tag[i] = j

    def wochen(self, D: int, R_ts: int) -> None:
        """Die neu vollständigen Wochen (frühestens dienstags): „gescheitert“, dann die Aufnahme (nicht bei gesetzter Bremse)."""
        neu = np.zeros(self.R, bool)
        while True:
            m = self.wz < self.nW
            if not m.any():
                break
            wi = np.minimum(self.wz, self.nW - 1)
            adv = m & (self.wtag[self.ri, wi] <= D)
            if not adv.any():
                break
            self.wz[adv] += 1; neu |= adv
        for i in np.nonzero(neu)[0]:
            i = int(i)
            if self.zust[i] == 3:
                continue
            w_bis = int(self.wz[i]) - 1
            self.w_aus[i] = w_bis
            self._gescheitert_pruefen(i, w_bis, D, R_ts)
            if self.zust[i] != 1 and not self.bremse and not self.durch_haenger[i]:
                self._aufnahme_pruefen(i, w_bis, D, R_ts)

    def _pausieren(self, i, D, R_ts, grund, werte, neu="pausiert"):
        alt = ZUSTAND_TEXT[int(self.zust[i])]
        self.zust[i] = 2; self.t_pause[i] = R_ts; self.tag_pause[i] = D - self.g0; self.n_pause[i] += 1
        self.pause_tage[i].append(D - self.g0)
        if neu == "pausiert":
            self._log(i, R_ts, alt, "pausiert", grund, werte)

    def _gescheitert_pruefen(self, i, w_bis, D, R_ts):
        if self.gesch[i]:
            return
        w_von = self.w_erste[i] if _MUT == "rueckkehr_alte_daten" else self.fail_w[i]
        idx = self.gueltige(i, w_von, w_bis, R_ts)
        if idx.size < FAIL_WOCHEN or self.wb[idx[-1]] - self.wa[idx[0]] < FAIL_TAGE:
            return
        t, mu, m1, m2, n = t_wert(self.WY[i, idx])
        if not t <= FAIL_T:
            return
        if _MUT != "gescheitert_ohne_haelften" and not (m1 < 0 and m2 < 0):
            return
        mu_up, n_up, mu_dn, n_dn = self.monatsmittel(i, self.tage_der_wochen(idx), R_ts)
        if _MUT != "gescheitert_ohne_monate" and not (n_up >= MONAT_MIN_TAGE and n_dn >= MONAT_MIN_TAGE and mu_up < 0 and mu_dn < 0):
            return
        self.gesch[i] = True; self.gesch_seit[i] = R_ts
        if self.erst_fail[i] < 0:
            self.erst_fail[i] = D - self.g0
        werte = {"t": _z(t, 2), "wochen": n, "haelften": [_z(m1, 1), _z(m2, 1)], "tage_auf": n_up, "tage_ab": n_dn,
                 "mittel_auf": _z(mu_up, 1), "mittel_ab": _z(mu_dn, 1)}
        alt = ZUSTAND_TEXT[int(self.zust[i])]
        if self.zust[i] == 1:
            self._pausieren(i, D, R_ts, "", {}, neu="gescheitert")
        self._log(i, R_ts, alt, "gescheitert", f"t {_de(t, 2)} über {n} Wochen, beide Hälften negativ; steigende BTC-Monate Ø "
                  f"{_de(mu_up, 0)} USD/Tag ({n_up} Tage), fallende Ø {_de(mu_dn, 0)} USD/Tag ({n_dn} Tage)", werte)

    def _aufnahme_pruefen(self, i, w_bis, D, R_ts):
        idx = self.gueltige(i, self.w_erste[i], w_bis, R_ts)
        info = {"w_bis": int(w_bis)}
        ok_a = ok_b = False
        if idx.size and not (self.gesch[i] and _MUT != "nach_gescheitert_A"):
            t, mu, m1, m2, n = t_wert(self.WY[i, idx]); tr = float(self.WN[i, idx].sum())
            info["A"] = {"t": t, "n": n, "trades": tr, "h1": m1, "h2": m2}
            ok_a = bool(n >= MIN_WOCHEN_A and (tr >= MIN_TRADES or _MUT == "ohne_mindestzahl") and t >= C_A and m1 > 0 and m2 > 0)
        elif self.gesch[i]:
            info["A"] = {"gesperrt": True}
        lang = int(w_bis - self.w_erste[i] + 1)
        ib = idx[idx > w_bis - FENSTER_B]
        if _MUT == "nur_A":
            info["B"] = {"aus": True}
        elif lang >= FENSTER_B and ib.size:
            t, mu, m1, m2, n = t_wert(self.WY[i, ib]); tr = float(self.WN[i, ib].sum())
            info["B"] = {"t": t, "n": n, "trades": tr, "h1": m1, "h2": m2}
            ok_b = bool(n >= MIN_GUELTIG_B and (tr >= MIN_TRADES or _MUT == "ohne_mindestzahl") and t >= C_B and m1 > 0 and m2 > 0)
        else:
            info["B"] = {"wochen_bisher": max(lang, 0)}
        if ok_a or ok_b:
            if self.zust[i] == 2 and _MUT != "ohne_abkuehlung":           # nach einer Pause
                if R_ts - self.t_pause[i] < ABK_TAGE * TAG:
                    info["abkuehlung_bis"] = int(self.t_pause[i] + ABK_TAGE * TAG)
                    self.letzte_pruefung[i] = info
                    return
                seit = self.summe_seit_pause(i, R_ts)
                info["summe_seit_pause"] = seit
                if ok_a and not seit > 0:
                    ok_a = False
                if ok_b and _MUT == "abkuehlung_summe_auch_B" and not seit > 0:
                    ok_b = False
        if not (ok_a or ok_b):
            self.letzte_pruefung[i] = info
            return
        fenster = "A" if ok_a else "B"
        iw = idx if ok_a else ib
        tage = self.tage_der_wochen(iw)
        bz = bezug(self.Y[i, tage], self.N[i, tage], self.WY[i, iw])
        alt = "gescheitert" if self.gesch[i] else ZUSTAND_TEXT[int(self.zust[i])]
        if self.gesch[i]:
            self.gesch[i] = False; self.zurueck[i] = R_ts; self.fail_w[i] = w_bis + 1
        self.zust[i] = 1; self.auf_tag[i] = D - self.g0; self.auf_ts[i] = R_ts; self.auf_fenster[i] = fenster
        self.S[i] = 0.0; self.k[i] = bz["k"]; self.s_t[i] = bz["s_trade"]; self.h[i] = bz["h"]
        self.durch_bremse[i] = False
        self.n_auf[i] += 1; self.auf_tage[i].append(D - self.g0)
        if self.erst_auf[i] < 0:
            self.erst_auf[i] = D - self.g0
        q = info[fenster]
        self._log(i, R_ts, alt, "aktiv", f"über ({fenster}): t {_de(q['t'], 2)} über {q['n']} Wochen, {int(q['trades'])} Trades"
                  + (" -- zurückgekehrt" if alt == "gescheitert" else ""),
                  {"fenster": fenster, "t": _z(q["t"], 3), "wochen": q["n"], "trades": int(q["trades"]),
                   **{k_: _z(v_, 6) for k_, v_ in bz.items()}})
        self.letzte_pruefung[i] = info

    def bremsen(self, D, R_ts, grund):
        """Bremse: alle aktiven Strategien pausieren, keine Aufnahme bis zum Lösen."""
        self.bremse = True; self.bremse_seit = R_ts
        self._log(None, R_ts, "läuft", "Bremse", grund)
        for i in np.nonzero(self.zust == 1)[0]:
            i = int(i)
            self._pausieren(i, D, R_ts, "Bremse des Kontos", {})
            self.durch_bremse[i] = True

    def loesen(self, D, R_ts, t_loesen):
        """Lösen von Hand: von der Bremse pausierte Strategien gelten als beobachtet; alle nicht aktiven Strategien werden einmal mit der
        zuletzt ausgewerteten Woche geprüft (was die Bremse an Aufnahmen aufgehalten hat; Abkühlung nur nach einer eigenen Pause)."""
        self.bremse = False
        self._log(None, R_ts, "Bremse", "läuft", f"Bremse von Hand gelöst ({time.strftime('%d.%m.%Y %H:%M', time.gmtime(t_loesen))} UTC)")
        for i in np.nonzero(self.durch_bremse & (self.zust == 2))[0]:
            i = int(i)
            self.zust[i] = 0
            self._log(i, R_ts, "pausiert", "beobachtet", "Bremse gelöst: wieder Kandidat ohne Abkühlung")
        self.durch_bremse[:] = False
        for i in range(self.R):
            if self.zust[i] not in (1, 3) and self.w_aus[i] >= 0 and not self.durch_haenger[i]:
                self._aufnahme_pruefen(i, int(self.w_aus[i]), D, R_ts)

    def tag_abschliessen(self, D):
        j = D - self.g0
        if 0 <= j < self.T:
            self.aktiv_tage[:, j] = self.zust == 1


# ------------------------------------------------------------------------------------------------ Konto
class Konto:
    """Papierkonto der Engine: übernimmt Labor-Trades aktiver Strategien in der Reihenfolge ihrer Eröffnung, sofern Platz ist; realisiert
    wird beim Schließen im Labor (gleiche Preise, Kosten und Ausstiege)."""

    def __init__(self, start_ts: int):
        self.start = int(start_ts)
        self.offen: list = []                  # Heap (geschlossen, id, coin, seite) -- inf, solange offen
        self.real: list = []                   # Heap (geschlossen, id, netto)
        self.kapital = KAPITAL; self.hoch = KAPITAL; self.max_rueckgang = 0.0
        self.uebernommen: list = []; self.ausgelassen = {"Kapazität": 0, "Coin": 0, "Richtung": 0}
        self.tage: list = []                   # (Prüfzeit, Konto, offene Positionen)

    def _aufraeumen(self, t):
        while self.offen and self.offen[0][0] <= t:
            heapq.heappop(self.offen)

    def realisieren_bis(self, t):
        while self.real and self.real[0][0] <= t:
            _, _, netto = heapq.heappop(self.real)
            self.kapital += netto
            self.hoch = max(self.hoch, self.kapital)
            self.max_rueckgang = max(self.max_rueckgang, (self.hoch - self.kapital) / self.hoch)

    def offen_bei(self, t) -> int:
        return sum(1 for x in self.offen if x[0] > t)

    def anbieten(self, tr: dict) -> str | None:
        """tr: id, coin, seite, eroeffnet, geschlossen (None = offen), netto_usd. Rückgabe None = übernommen, sonst der Grund."""
        t = int(tr["eroeffnet"])
        self._aufraeumen(t)
        if len(self.offen) >= MAX_POS and _MUT != "kapazitaet_ignoriert":
            self.ausgelassen["Kapazität"] += 1
            return "Kapazität"
        if sum(1 for x in self.offen if x[2] == tr["coin"]) >= MAX_COIN and _MUT != "coin_grenze_ignoriert":
            self.ausgelassen["Coin"] += 1
            return "Coin"
        if sum(1 for x in self.offen if x[3] == tr["seite"]) >= MAX_RICHTUNG and _MUT != "richtung_grenze_ignoriert":
            self.ausgelassen["Richtung"] += 1
            return "Richtung"
        zu = tr.get("geschlossen")
        heapq.heappush(self.offen, (float(zu) if zu is not None else math.inf, int(tr["id"]), tr["coin"], tr["seite"]))
        if zu is not None:
            heapq.heappush(self.real, (int(zu), int(tr["id"]), float(tr.get("netto_usd") or 0.0)))
        self.uebernommen.append(tr)
        return None

    def bremse_faellig(self) -> bool:
        if _MUT == "bremse_aus":
            return False
        return self.kapital < (1 - BREMSE_ANTEIL) * self.hoch

    def tageswert(self, ts):
        self.tage.append((int(ts), round(self.kapital, 2), self.offen_bei(ts)))


# ------------------------------------------------------------------------------------------------ Lauf über die Labor-Daten
def tagesreihen(strat: list, trades: dict, g0: int, g1: int) -> tuple:
    """Y, N, C je Strategie und Tag aus den Trades (nach Einstiegstag)."""
    R, T = len(strat), g1 - g0 + 1
    Y = np.zeros((R, T)); N = np.zeros((R, T)); C = np.zeros((R, T))
    for i, s in enumerate(strat):
        for tr in trades.get(s["sid"], ()):
            j = int(tr["eroeffnet"]) // TAG - g0
            if 0 <= j < T:
                N[i, j] += 1
                if tr.get("geschlossen") is None:
                    C[i, j] = math.inf
                else:
                    Y[i, j] += float(tr.get("netto_usd") or 0.0)
                    C[i, j] = max(C[i, j], float(tr["geschlossen"]))
    return Y, N, C


def monatsarten(btc: dict, g0: int, g1: int) -> tuple:
    """Je Tag: Monatsart (+1 steigend, −1 fallend, 0 nicht bekannt) aus dem BTC-Schlusskurs des letzten Monatstags gegen den letzten
    Tag des Vormonats -- nur wenn beide Tage vorliegen -- und der Zeitpunkt, ab dem sie bekannt ist: 00:00 UTC am zweiten Tag nach dem
    Monatsende (die Tageskerzen kommen alle 6 h; dann ist die letzte sicher endgültig). btc: {Tag: Schlusskurs} (nur abgeschlossene Tage)."""
    T = g1 - g0 + 1
    art = np.zeros(max(T, 0), dtype=int); bek = np.full(max(T, 0), np.inf)
    letzte: dict = {}
    for g in sorted(btc):
        letzte[monat_nr(g)] = (g, btc[g])
    for j in range(T):
        m = monat_nr(g0 + j)
        if m in letzte and (m - 1) in letzte:
            g_letzt, c = letzte[m]
            g_vor, c_vor = letzte[m - 1]
            voll = monat_nr(g_letzt + 1) != m                         # der letzte Tag des Monats liegt vor
            vor_voll = monat_nr(g_vor + 1) != m - 1 or _MUT == "monat_ohne_vormonat"
            if voll and vor_voll:
                art[j] = 1 if c > c_vor else (-1 if c < c_vor else 0)
                bek[j] = (g_letzt + 2) * TAG
    return art, bek


def ausfalltage(puls, g0: int, g1: int, jetzt: int) -> np.ndarray:
    """Je Tag der Zeitpunkt, ab dem er als Ausfalltag bekannt ist (inf = kein Ausfall): Eine Lücke im Puls von mehr als 1 h macht jeden
    Tag, den sie berührt, zum Ausfalltag -- bekannt, sobald sie 1 h überschreitet (auch die laufende Lücke bis jetzt). Vor dem ersten
    Puls ist nichts bekannt."""
    T = g1 - g0 + 1
    aus = np.full(max(T, 0), np.inf)
    p = sorted(int(x) for x in puls)
    if not p:
        return aus
    luecken = [(a, b) for a, b in zip(p, p[1:]) if b - a > AUSFALL_S]
    if int(jetzt) - p[-1] > AUSFALL_S:
        luecken.append((p[-1], int(jetzt)))
    for a, b in luecken:
        bekannt = a + AUSFALL_S + 1
        for g in range(a // TAG, b // TAG + 1):
            if g0 <= g <= g1:
                aus[g - g0] = min(aus[g - g0], bekannt)
    return aus


def abspielen(strat: list, trades: dict, btc: dict, puls, engine_start: int, bis: int, loesen_ts=()) -> dict | None:
    """Die Regeln ab dem frühesten Start bis `bis` (je Prüfung nur, was bis dahin geschlossen bzw. bekannt war) samt Konto ab
    engine_start. Je Prüfung um 00:30 UTC: Konto realisieren, Lösen der Bremse (Zeitpunkte loesen_ts, wirken ab der nächsten Prüfung),
    abgelöste Regelversionen beenden, Überwachung, Bremse, Wochen; dann die Trades bis zur nächsten Prüfung."""
    if not strat:
        return None
    bis = int(bis)
    g0 = min(int(s["erstellt"]) // TAG for s in strat)
    g1 = bis // TAG
    if g1 < g0:
        return None
    Y, N, C = tagesreihen(strat, trades, g0, g1)
    art, bek = monatsarten(btc, g0, g1)
    ausf = ausfalltage(puls, g0, g1, bis)
    A = Abspielen(Y, N, C, [-(-int(s["erstellt"]) // TAG) for s in strat], g0, ausf, art, bek, [s["name"] for s in strat],
                  [s["sid"] for s in strat], [s.get("ende") for s in strat])
    K = Konto(engine_start)
    zeile = {s["sid"]: i for i, s in enumerate(strat)}
    alle = sorted((dict(tr, sid=sid) for sid, v in trades.items() if sid in zeile for tr in v),
                  key=lambda x: (int(x["eroeffnet"]), int(x["id"])))
    loes = sorted(int(x) for x in loesen_ts)
    p = 0
    for D in range(g0, g1 + 1):
        R_ts = D * TAG + PRUEF_S
        if R_ts > bis:
            break
        K.realisieren_bis(R_ts)
        if A.bremse:
            gel = [t for t in loes if A.bremse_seit < t <= R_ts]
            if gel:
                K.hoch = K.kapital
                A.loesen(D, R_ts, gel[0])
        A.beenden(D, R_ts)
        A.ueberwachen(D, R_ts)
        if _MUT == "bremse_nach_aufnahme":
            A.wochen(D, R_ts)
        if not A.bremse and R_ts >= engine_start and K.bremse_faellig():
            A.bremsen(D, R_ts, f"Konto {_tsd(K.kapital)} USD, mehr als 10 % unter dem Höchststand {_tsd(K.hoch)} USD")
        if _MUT != "bremse_nach_aufnahme":
            A.wochen(D, R_ts)
        A.tag_abschliessen(D)
        if R_ts >= engine_start:
            K.tageswert(R_ts)
        t_ende = min(R_ts + TAG, bis + 1)
        while p < len(alle) and int(alle[p]["eroeffnet"]) < t_ende:
            tr = alle[p]; p += 1
            if int(tr["eroeffnet"]) < max(int(engine_start), R_ts):
                continue
            i = zeile[tr["sid"]]
            if A.zust[i] == 1 or (_MUT == "pausierte_uebernommen" and A.zust[i] == 2):
                K.anbieten(tr)
    K.realisieren_bis(bis)
    return {"A": A, "K": K, "g0": g0, "g1": g1, "ausfall": ausf}


def _grund_text(A, i, info, jetzt) -> str:
    """Zustand der Zeile in Worten."""
    z = int(A.zust[i])
    if z == 3:
        letzt = next((e for e in reversed(A.protokoll) if e["sid"] == A.sids[i] and e["neu"] == "beendet"), None)
        return "beendet: " + (letzt["grund"] if letzt else "neue Regelversion im Labor")
    if z == 1:
        return (f"aktiv seit {_datum(A.auf_ts[i])} über ({A.auf_fenster[i]}); Überwachung {_de(A.S[i], 1)} von {_de(A.h[i], 1)}"
                + (f"; zurückgekehrt am {_datum(A.zurueck[i])}" if A.zurueck[i] >= 0 else ""))
    teile = []
    if A.gesch[i]:
        teile.append(f"gescheitert seit {_datum(A.gesch_seit[i])}, zurück nur über (B)")
    if z == 2:
        letzt = next((e for e in reversed(A.protokoll) if e["sid"] == A.sids[i] and e["neu"] in ("pausiert", "gescheitert")), None)
        teile.append(f"pausiert seit {_datum(A.t_pause[i])}" + (f" ({letzt['grund']})" if letzt and letzt["neu"] == "pausiert" else ""))
        if info.get("abkuehlung_bis"):
            teile.append(f"Abkühlung bis {_datum(info['abkuehlung_bis'])}")
        elif info.get("summe_seit_pause") is not None and not info["summe_seit_pause"] > 0:
            teile.append(f"(A) erst mit positiver Summe seit der Pause (jetzt {_de(info['summe_seit_pause'], 0)} USD)")
    if A.bremse:
        teile.append("Bremse gesetzt: keine Aufnahme bis zum Lösen")
        return "; ".join(teile)
    a = info.get("A") or {}
    b = info.get("B") or {}
    fa = []
    if a.get("gesperrt"):
        pass
    elif a:
        if a["n"] < MIN_WOCHEN_A:
            fa.append(f"{a['n']} von {MIN_WOCHEN_A} Wochen")
        if a["trades"] < MIN_TRADES:
            fa.append(f"{int(a['trades'])} von {MIN_TRADES} Trades")
        if not (a["t"] >= C_A):
            fa.append(f"t {_de(a['t'], 2)} unter {_de(C_A, 1)}")
        if not (a["h1"] > 0 and a["h2"] > 0) and a["n"] >= 3:
            fa.append("eine Hälfte nicht positiv")
    elif A.w_aus[i] < 0:
        fa.append("noch keine vollständige Woche")
    fb = []
    if "wochen_bisher" in b:
        fb.append(f"{b['wochen_bisher']} von {FENSTER_B} Wochen")
    elif b and not b.get("aus"):
        if b["n"] < MIN_GUELTIG_B:
            fb.append(f"{b['n']} von {MIN_GUELTIG_B} gültigen Wochen")
        if b["trades"] < MIN_TRADES:
            fb.append(f"{int(b['trades'])} von {MIN_TRADES} Trades")
        if not (b["t"] >= C_B):
            fb.append(f"t {_de(b['t'], 2)} unter {_de(C_B, 1)}")
        if not (b["h1"] > 0 and b["h2"] > 0) and b["n"] >= 3:
            fb.append("eine Hälfte nicht positiv")
    if z != 2 or not info.get("abkuehlung_bis"):
        if fa:
            teile.append("(A): " + ", ".join(fa))
        if fb:
            teile.append("(B): " + ", ".join(fb))
    return "; ".join(teile) or "beobachtet"


def stand_aus(res: dict, strat: list, bis: int, engine_start: int, vergleich: dict | None = None) -> dict:
    """Nutzlast für Reiter und Bericht (nur endliche Zahlen)."""
    A, K = res["A"], res["K"]
    zeilen = []
    for i, s in enumerate(strat):
        lp = A.letzte_pruefung.get(i, {})
        idx = A.gueltige(i, A.w_erste[i], A.w_aus[i], bis) if A.w_aus[i] >= 0 else np.zeros(0, dtype=np.int64)
        mu_up, n_up, mu_dn, n_dn = A.monatsmittel(i, A.tage_der_wochen(idx), bis) if idx.size else (None, 0, None, 0)
        version = "aktuell" if s.get("aktiv", 1) == 1 else ("früher" if s.get("ende") else "entfernt")
        titel = (s.get("titel") or s["name"]) + {"aktuell": "", "früher": " (alte Regeln)", "entfernt": " (nicht mehr im Labor)"}[version]
        z = {"sid": s["sid"], "name": s["name"], "titel": titel, "gruppe": s.get("gruppe"), "version": version,
             "ende": int(s["ende"]) if s.get("ende") else None,
             "engine_zustand": ZUSTAND_TEXT[int(A.zust[i])], "gescheitert": bool(A.gesch[i]),
             "gescheitert_seit": int(A.gesch_seit[i]) if A.gesch[i] else None,
             "zurueck": int(A.zurueck[i]) if A.zurueck[i] >= 0 else None,
             "seit": int(A.auf_ts[i]) if A.zust[i] == 1 else (int(A.t_pause[i]) if A.zust[i] == 2 else None),
             "fenster": A.auf_fenster[i] if A.zust[i] == 1 else None,
             "wochen": int(idx.size), "trades": int(A.WN[i, idx].sum()) if idx.size else 0,
             "summe_usd": _z(A.WY[i, idx].sum(), 2) if idx.size else 0.0,
             "t_A": _z((lp.get("A") or {}).get("t"), 2), "t_B": _z((lp.get("B") or {}).get("t"), 2),
             "ueberwachung": ({"S": _z(A.S[i], 2), "h": _z(A.h[i], 2), "anteil": _z(A.S[i] / A.h[i] if A.h[i] > 0 else 0.0, 3)}
                              if A.zust[i] == 1 else None),
             "mittel_auf": _z(mu_up, 1), "tage_auf": n_up, "mittel_ab": _z(mu_dn, 1), "tage_ab": n_dn,
             "aufnahmen": int(A.n_auf[i]), "pausen": int(A.n_pause[i]),
             "grund": _grund_text(A, i, lp, bis)}
        zeilen.append(z)
    konto = {"start": int(engine_start), "kapital": round(K.kapital, 2), "hoch": round(K.hoch, 2),
             "groesster_rueckgang": round(K.max_rueckgang, 4), "netto": round(K.kapital - KAPITAL, 2),
             "uebernommen": len(K.uebernommen), "offen": K.offen_bei(bis), "ausgelassen": dict(K.ausgelassen),
             "bremse": bool(A.bremse), "bremse_seit": int(A.bremse_seit) if A.bremse else None, "tage": K.tage[-800:],
             "letzte": [{k_: tr.get(k_) for k_ in ("sid", "coin", "seite", "eroeffnet", "geschlossen", "netto_usd")}
                        for tr in K.uebernommen[-60:]][::-1],
             "begonnen": int(bis) >= int(engine_start)}
    namen = {z["sid"]: z["titel"] for z in zeilen}
    for e in konto["letzte"]:
        e["name"] = namen.get(e["sid"], e["sid"])
    je_tag: dict = {}                                                  # realisiert je UTC-Tag der Schließung (wie der Vergleich)
    for tr in K.uebernommen:
        zu = tr.get("geschlossen")
        if zu is not None and int(zu) <= int(bis):
            z_ = je_tag.setdefault(int(zu) // TAG * TAG, [0.0, 0])
            z_[0] += float(tr.get("netto_usd") or 0.0); z_[1] += 1
    tn, kum, kum_r = [], 0.0, 0.0                                      # gerundet über die Summe: die Tage ergeben genau das Netto
    for t, v in sorted(je_tag.items()):
        kum += v[0]
        tn.append([t, round(round(kum, 2) - kum_r, 2), v[1]]); kum_r = round(kum, 2)
    konto["tage_netto"] = tn[-800:]
    prot = [dict(e, vorher=e["ts"] < int(engine_start)) for e in A.protokoll]
    return {"ok": True, "version": VERSION_MODUL, "fassung": FASSUNG, "ts": int(bis), "engine_start": int(engine_start),
            "strategien": zeilen, "protokoll": prot[-300:], "n_protokoll": len(prot), "konto": konto,
            "kandidaten": sum(1 for z in zeilen if z["version"] == "aktuell"),
            "aktiv": sum(1 for z in zeilen if z["engine_zustand"] == "aktiv" and z["version"] == "aktuell"),
            "pausiert": sum(1 for z in zeilen if z["engine_zustand"] == "pausiert" and z["version"] == "aktuell"),
            "gescheitert": sum(1 for z in zeilen if z["gescheitert"] and z["version"] == "aktuell"),
            "fruehere": sum(1 for z in zeilen if z["version"] != "aktuell"),
            "ausfalltage": A.ausfalltage(bis), "vergleich": vergleich or {},
            "regeln": {"C_A": C_A, "C_B": C_B, "min_wochen_A": MIN_WOCHEN_A, "fenster_B": FENSTER_B, "min_gueltig_B": MIN_GUELTIG_B,
                       "min_trades": MIN_TRADES, "abkuehlung_tage": ABK_TAGE, "arl0_tage": ARL0_TAGE, "fail_t": FAIL_T,
                       "fail_wochen": FAIL_WOCHEN, "fail_tage": FAIL_TAGE, "monat_min_tage": MONAT_MIN_TAGE, "kapital": KAPITAL,
                       "notional": NOTIONAL, "max_pos": MAX_POS, "max_coin": MAX_COIN, "max_richtung": MAX_RICHTUNG,
                       "bremse": BREMSE_ANTEIL, "kandidaten": len(umfang())}}


def labor_lesen(store: str) -> tuple:
    """(Strategien im Umfang -- jede Regelversion eine Zeile --, Trades je sid). Liest nur. Je Name zählt die Reihenfolge der
    Regelversionen nach ihrem Start; eine abgelöste Version (aktiv = 0) endet mit dem Start der nächsten („ende“), die aktuelle hat
    keines. So bleiben Trades, die die Engine unter einer alten Version übernommen hat, im Konto und im Protokoll."""
    con = sqlite3.connect(f"file:{store}?mode=ro", uri=True, timeout=30)
    try:
        je_name: dict = {}
        for sid, name, titel, gruppe, erstellt, aktiv in con.execute(
                "SELECT sid, name, titel, gruppe, erstellt, aktiv FROM labor_strategie ORDER BY name, erstellt, sid"):
            if name in umfang() and (int(aktiv or 0) == 1 or _MUT != "nur_aktuelle_version"):
                je_name.setdefault(name, []).append({"sid": sid, "name": name, "titel": titel, "gruppe": gruppe,
                                                     "erstellt": int(erstellt or 0), "aktiv": int(aktiv or 0)})
        strat = [v for vs in je_name.values() for v in vs]
        trades: dict = {}
        if strat:
            q_ = ",".join("?" * len(strat))
            for r in con.execute(f"SELECT id, sid, coin, seite, status, eroeffnet, geschlossen, netto_usd FROM labor_position "
                                 f"WHERE sid IN ({q_}) ORDER BY eroeffnet, id", [s["sid"] for s in strat]):
                zu = int(r[6]) if (r[4] == "geschlossen" and r[6] is not None) else None
                trades.setdefault(r[1], []).append({"id": int(r[0]), "coin": r[2], "seite": r[3], "eroeffnet": int(r[5]),
                                                    "geschlossen": zu, "netto_usd": float(r[7] or 0.0) if zu is not None else None})
        for s in strat:                                                # ohne Startzeit: ab dem ersten Trade (sonst noch kein Kandidat)
            if s["erstellt"] <= 0:
                s["erstellt"] = min((t["eroeffnet"] for t in trades.get(s["sid"], ())), default=0)
        strat = [s for s in strat if s["erstellt"] > 0]
        for vs in je_name.values():
            vs = sorted((v for v in vs if v["erstellt"] > 0), key=lambda v: (v["erstellt"], v["aktiv"], v["sid"]))
            for k, v in enumerate(vs):
                spaeter = [w["erstellt"] for w in vs[k + 1:]]
                v["ende"] = None if v["aktiv"] == 1 or not spaeter else min(spaeter)
        return strat, trades
    finally:
        con.close()


def labor_vergleich(store: str, seit: int, sids: list) -> dict:
    """Realisiertes Netto im selben Zeitraum (Trades, die seit dem Start der Engine eröffnet und geschlossen wurden), nach Tag der
    Schließung: Labor gesamt (alle Strategien, je eigenes Konto), die Kandidaten ungefiltert und Halten Long."""
    con = sqlite3.connect(f"file:{store}?mode=ro", uri=True, timeout=30)
    try:
        def reihe(wo, par):
            r = con.execute(f"SELECT geschlossen / 86400, SUM(netto_usd), COUNT(*) FROM labor_position WHERE status='geschlossen' "
                            f"AND eroeffnet >= ?{wo} GROUP BY 1 ORDER BY 1", [int(seit)] + list(par)).fetchall()
            return [[int(a) * TAG, round(float(b or 0.0), 2), int(c)] for a, b, c in r]
        q_ = ",".join("?" * len(sids)) or "''"
        hl = [r[0] for r in con.execute("SELECT sid FROM labor_strategie WHERE name='halten_long'")]
        q2 = ",".join("?" * len(hl)) or "''"
        aus = {"labor": reihe("", []), "kandidaten": reihe(f" AND sid IN ({q_})", sids), "halten_long": reihe(f" AND sid IN ({q2})", hl)}
        for k in ("labor", "kandidaten", "halten_long"):
            aus[k + "_netto"] = round(sum(x[1] for x in aus[k]), 2)
            aus[k + "_trades"] = sum(x[2] for x in aus[k])
        return aus
    finally:
        con.close()


def btc_lesen(db: str, jetzt: int) -> dict:
    """BTC-Schlusskurse der abgeschlossenen Tage (daily_bars der Hauptdatenbank). Ohne Tabelle leer; ein Lesefehler bricht die Rechnung
    ab (sonst stünden Entscheidungen ohne Monatsart im Protokoll)."""
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=30)
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='daily_bars'").fetchone():
            return {}
        return {int(ts) // TAG: float(c) for ts, c in con.execute(
            "SELECT ts, close FROM daily_bars WHERE coin='BTC' AND close > 0 AND ts < ?", ((int(jetzt) // TAG) * TAG,))}
    finally:
        con.close()


def store_pfad() -> str:
    import hl_forecast
    return hl_forecast.STORE


def rechnen(db: str, store: str | None = None, jetzt: int | None = None, rueckblick: bool = False) -> dict:
    """Ganzer Lauf: liest Labor, BTC-Tageskerzen und Puls, spielt die Regeln ab und gibt die Nutzlast zurück (dazu unter
    „_protokoll_voll“ alle Entscheidungen für den Abgleich mit engine.db)."""
    jetzt = int(jetzt or time.time())
    store = store or store_pfad()
    con = verbinden(engine_pfad(db))
    try:
        start = meta(con, "start")
        puls = [r[0] for r in con.execute("SELECT ts FROM eng_puls ORDER BY ts")]
        loesen = [int(e["ts"]) for e in (meta(con, "bremse_ereignisse", []) or []) if e.get("art") == "geloest"]
    finally:
        con.close()
    if not os.path.exists(store):
        return {"ok": True, "hinweis": "Labor-Speicher (forecasts.db) fehlt -- das Labor hat noch nicht getaktet.", "strategien": [],
                "protokoll": [], "konto": None}
    strat, trades = labor_lesen(store)
    if not strat:
        return {"ok": True, "hinweis": "Keine Kandidaten im Labor (die Strategien werden beim ersten Takt angelegt).", "strategien": [],
                "protokoll": [], "konto": None}
    if rueckblick:
        e_start = min(-(-int(s["erstellt"]) // TAG) for s in strat) * TAG
        loesen = []
    else:
        if start is None:
            return {"ok": True, "hinweis": "Die Engine beginnt mit dem ersten Takt nach dem Einspielen (Konto ab 00:00 UTC des Folgetags).",
                    "strategien": [], "protokoll": [], "konto": None}
        e_start = int(start)
        # abgelöste Regelversionen nur, wenn sie erst nach dem Start des Kontos endeten (vorher gehören sie zu keiner Entscheidung)
        strat = [s for s in strat if s["aktiv"] == 1 or (s["ende"] is not None and s["ende"] > e_start)
                 or (s["ende"] is None and any(t["eroeffnet"] >= e_start for t in trades.get(s["sid"], ())))]
    res = abspielen(strat, trades, btc_lesen(db, jetzt), puls, e_start, jetzt, loesen)
    if res is None:
        return {"ok": True, "hinweis": "Noch kein voller Tag seit dem Start der Strategien.", "strategien": [], "protokoll": [],
                "konto": None}
    d = stand_aus(res, strat, jetzt, e_start, labor_vergleich(store, e_start, [s["sid"] for s in strat]))
    d["rueckblick"] = bool(rueckblick)
    d["_protokoll_voll"] = res["A"].protokoll
    return d


# ------------------------------------------------------------------------------------------------ Dienst im Dashboard
_DIENST = {"gestartet": False, "fehler": None, "letzter": None, "puls": 0, "labor_t": None}


def protokoll_abgleich(con, voll: list, start: int) -> dict:
    """Stimmen die gespeicherten Entscheidungen seit dem Start mit der Neuberechnung überein? Schlüssel (Zeit, Strategie, neuer Zustand)."""
    gesp = {(r[0], r[1], r[2]) for r in con.execute("SELECT ts, sid, neu FROM eng_protokoll WHERE ts >= ?", (int(start),))}
    neu = {(e["ts"], e["sid"], e["neu"]) for e in voll if e["ts"] >= int(start)}
    fehlt = sorted(gesp - neu)
    return {"gleich": not fehlt, "nur_im_protokoll": len(fehlt), "beispiel": list(fehlt[0]) if fehlt else None}


def takt_schritt(db: str, labor_t=None, jetzt: int | None = None, store: str | None = None) -> dict:
    """Ein Schritt des Fadens: Start festlegen (00:00 UTC des Folgetags), Puls schreiben (wenn der Labor-Takt fortschreitet, höchstens alle
    5 min), alle 10 min den Stand rechnen, neue Entscheidungen seit dem Start ins Protokoll; meldet Abweichungen vom Protokoll."""
    jetzt = int(jetzt or time.time())
    con = verbinden(engine_pfad(db))
    try:
        if meta(con, "start") is None:
            meta_setzen(con, "start", (jetzt // TAG + 1) * TAG)
            meta_setzen(con, "installiert", jetzt)
            meta_setzen(con, "fassung", FASSUNG)
        if labor_t is not None and labor_t != _DIENST.get("labor_t") and jetzt - int(_DIENST.get("puls") or 0) >= PULS_S:
            con.execute("BEGIN IMMEDIATE")
            con.execute("INSERT OR IGNORE INTO eng_puls VALUES (?)", (jetzt,))
            con.execute("COMMIT")
            _DIENST["puls"] = jetzt; _DIENST["labor_t"] = labor_t
        r = con.execute("SELECT ts FROM eng_stand WHERE k='stand'").fetchone()
        if r and 0 <= jetzt - int(r[0]) < RECHNEN_S:
            return {"neu": False}
    finally:
        con.close()
    d = rechnen(db, store=store, jetzt=jetzt)
    voll = d.pop("_protokoll_voll", [])
    con = verbinden(engine_pfad(db))
    try:
        start = int(meta(con, "start") or 0)
        neu = 0
        con.execute("BEGIN IMMEDIATE")
        for e in voll:
            if e["ts"] >= start:
                cur = con.execute("INSERT OR IGNORE INTO eng_protokoll (ts, sid, name, alt, neu, grund, werte, geschrieben) "
                                  "VALUES (?,?,?,?,?,?,?,?)", (e["ts"], e["sid"], e["name"], e["alt"], e["neu"], e["grund"],
                                                              json.dumps(e["werte"], default=_jd), jetzt))
                neu += cur.rowcount
        con.execute("COMMIT")
        d["abweichung"] = protokoll_abgleich(con, voll, start)
        K = d.get("konto") or {}
        kurz = {"ts": jetzt, "start": start, "begonnen": bool(K.get("begonnen")), "kapital": K.get("kapital"), "netto": K.get("netto"),
                "aktiv": d.get("aktiv", 0), "pausiert": d.get("pausiert", 0), "gescheitert": d.get("gescheitert", 0),
                "n": d.get("kandidaten", len(d.get("strategien") or [])), "bremse": bool(K.get("bremse")), "hinweis": d.get("hinweis"),
                "abweichung": not (d["abweichung"] or {}).get("gleich", True)}
        con.execute("BEGIN IMMEDIATE")
        con.execute("INSERT OR REPLACE INTO eng_stand VALUES ('stand', ?, ?)", (jetzt, json.dumps(d, default=_jd)))
        con.execute("INSERT OR REPLACE INTO eng_stand VALUES ('kopf', ?, ?)", (jetzt, json.dumps(kurz, default=_jd)))
        con.execute("COMMIT")
    finally:
        con.close()
    _DIENST["letzter"] = jetzt
    return {"neu": True, "eintraege": neu, "abweichung": d.get("abweichung")}


def stand_lesen(db: str) -> dict:
    """Gespeicherter Stand (für Reiter und Bericht); ohne Stand ein Hinweis."""
    p = engine_pfad(db)
    dienst = {"gestartet": _DIENST["gestartet"], "fehler": _DIENST["fehler"], "letzter": _DIENST["letzter"],
              "aus": os.environ.get("HL_ENGINE") == "0"}
    if not os.path.exists(p):
        return {"ok": True, "hinweis": "Die Engine hat noch nicht gerechnet (Faden „engine“ startet 120 s nach dem Dashboard).",
                "strategien": [], "protokoll": [], "konto": None, "dienst": dienst}
    try:
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=10)
        try:
            r = con.execute("SELECT ts, v FROM eng_stand WHERE k='stand'").fetchone()
            gesp = [{"ts": x[0], "sid": x[1], "name": x[2], "alt": x[3], "neu": x[4], "grund": x[5], "geschrieben": x[6]}
                    for x in con.execute("SELECT ts, sid, name, alt, neu, grund, geschrieben FROM eng_protokoll "
                                         "ORDER BY ts DESC, id DESC LIMIT 300")]
            n_puls = con.execute("SELECT COUNT(*), MIN(ts), MAX(ts) FROM eng_puls").fetchone()
            ev = meta(con, "bremse_ereignisse", []) or []
        finally:
            con.close()
    except sqlite3.Error as e:
        return {"ok": False, "fehler": f"engine.db: {type(e).__name__}: {e}", "strategien": [], "protokoll": [], "konto": None,
                "dienst": dienst}
    if not r:
        return {"ok": True, "hinweis": "Noch kein Stand gerechnet (alle 10 min).", "strategien": [], "protokoll": [], "konto": None,
                "dienst": dienst}
    d = json.loads(r[1])
    d["protokoll_gespeichert"] = gesp
    d["puls"] = {"n": n_puls[0], "erster": n_puls[1], "letzter": n_puls[2]}
    d["dienst"] = dienst
    K = d.get("konto")
    if isinstance(K, dict):
        vm = None if _MUT == "loesen_ohne_vormerkung" else _vorgemerkt(K, ev)
        K["loesen_vorgemerkt"] = vm
        K["loesen_wirksam"] = _loesen_wirksam(vm) if vm else None
    return d


def _loesen_wirksam(ts: int) -> int:
    """Erste Prüfung (00:30 UTC) ab dem Zeitpunkt ts: dort wirkt ein Lösen der Bremse (abspielen: bremse_seit < t <= R_ts)."""
    return -(-(int(ts) - PRUEF_S) // TAG) * TAG + PRUEF_S


def _vorgemerkt(K: dict, ereignisse) -> int | None:
    """Zeitpunkt eines vorgemerkten Lösens: das erste „geloest“ nach dem Setzen der Bremse, solange sie im Stand noch gesetzt ist."""
    if not K.get("bremse"):
        return None
    seit = int(K.get("bremse_seit") or 0)
    t = [int(e["ts"]) for e in ereignisse or [] if isinstance(e, dict) and e.get("art") == "geloest" and int(e.get("ts") or 0) > seit]
    return min(t) if t else None


def kopf(db: str) -> dict | None:
    """Kurzstand für den Kopf des Labors (eine kleine Zeile aus engine.db); ohne Datei None."""
    p = engine_pfad(db)
    if not os.path.exists(p):
        return None
    try:
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=5)
        try:
            r = con.execute("SELECT v FROM eng_stand WHERE k='kopf'").fetchone()
        finally:
            con.close()
        return json.loads(r[0]) if r else None
    except (sqlite3.Error, ValueError) as e:
        return {"fehler": f"engine.db: {type(e).__name__}"}


def starten(db: str, labor_t_fn=None) -> bool:
    """Vom Dashboard aufgerufen. Nicht für Selbsttest-Datenbanken; aus mit HL_ENGINE=0. Erster Schritt 120 s nach dem Dashboard,
    dann jede Minute (Puls; gerechnet wird alle 10 min)."""
    if _DIENST["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_ENGINE") == "0":
        return False
    _DIENST["gestartet"] = True

    def schleife():
        time.sleep(120)
        while True:
            try:
                takt_schritt(db, labor_t_fn() if labor_t_fn else None)
                _DIENST["fehler"] = None
            except Exception as e:  # noqa: BLE001 -- der Faden läuft weiter, der Fehler steht im Reiter
                _DIENST["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Trading Engine: {_DIENST['fehler']}", flush=True)
            time.sleep(60)
    threading.Thread(target=schleife, daemon=True, name="engine").start()
    return True


def bremse_loesen(db: str, jetzt: int | None = None) -> dict:
    """Bremse lösen -- Button „Bremse lösen“ im Reiter „Engine“ (POST /labor/engine/bremse_loesen, seit 23.94) und --bremse-loesen.
    Nur wenn die Bremse gesetzt und noch kein Lösen vorgemerkt ist (die Prüfung wiederholt sich in der Schreibsperre, zwei Klicks
    ergeben einen Eintrag); wirkt ab der nächsten Prüfung um 00:30 UTC. Der gespeicherte Stand bleibt (die Vormerkung bestimmt
    stand_lesen aus den Ereignissen). Rückgabe {"ok", "msg", "vorgemerkt", "wirksam"}."""
    jetzt = int(jetzt or time.time())
    d = stand_lesen(db)
    K = d.get("konto") or {}
    if not K.get("bremse") and _MUT != "loesen_ohne_bremse":
        return {"ok": False, "msg": "Die Bremse ist nicht gesetzt -- nichts zu lösen.", "vorgemerkt": None, "wirksam": None}

    def schon(vm):
        return {"ok": False, "msg": f"Das Lösen ist schon vorgemerkt (am {_uhr(vm)}); es wirkt mit der Prüfung am "
                                   f"{_uhr(_loesen_wirksam(vm))} (00:30 UTC).", "vorgemerkt": vm, "wirksam": _loesen_wirksam(vm)}
    if K.get("loesen_vorgemerkt"):
        return schon(int(K["loesen_vorgemerkt"]))
    con = verbinden(engine_pfad(db))
    try:
        con.execute("BEGIN IMMEDIATE")
        try:
            ev = meta(con, "bremse_ereignisse", []) or []
            vm = None if _MUT == "loesen_ohne_vormerkung" else _vorgemerkt(K, ev)
            if vm:
                con.execute("ROLLBACK")
                return schon(vm)
            ev.append({"ts": jetzt, "art": "geloest"})
            con.execute("INSERT OR REPLACE INTO eng_meta VALUES (?, ?)", ("bremse_ereignisse", json.dumps(ev)))
            con.execute("COMMIT")
        except Exception:
            if con.in_transaction:
                con.execute("ROLLBACK")
            raise
    finally:
        con.close()
    w = _loesen_wirksam(jetzt)
    return {"ok": True, "msg": f"Bremse gelöst am {_uhr(jetzt)}: ab der Prüfung am {_uhr(w)} (00:30 UTC) gilt der Kontostand als neuer "
                               "Höchststand; von der Bremse pausierte Strategien gelten dann als beobachtet, und alle nicht aktiven "
                               "werden einmal nach (A)/(B) geprüft (nach einer eigenen Pause mit Abkühlung).",
            "vorgemerkt": jetzt, "wirksam": w}


# ------------------------------------------------------------------------------------------------ Bericht
def _uhr(ts) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(int(ts))) if ts else "—"


def _usd(x) -> str:
    return "—" if x is None else f"{x:+,.0f}".replace(",", ".").replace("-", "−")


def _tsd(x) -> str:
    return "—" if x is None else f"{x:,.0f}".replace(",", ".")


def text(d: dict) -> str:
    z = []
    rb = bool(d.get("rueckblick"))
    z.append("★ Trading Engine (U241)" + (" · Rückblick: die Regeln seit dem Start des Labors (beschreibend)" if rb else "")
             + f" · Modul {VERSION_MODUL} · Regeln Fassung {FASSUNG} · Papier, kein echtes Geld (Zeiten Ortszeit des Pi)")
    if not d.get("ok", True):
        z.append("Fehler: " + str(d.get("fehler")))
        return "\n".join(z)
    if d.get("hinweis"):
        z.append(d["hinweis"])
        return "\n".join(z)
    K = d.get("konto") or {}
    n_k = d.get("kandidaten", len(d["strategien"]))
    z.append(f"Stand {_uhr(d['ts'])} · Konto ab {_uhr(d.get('engine_start'))} · aktiv {d.get('aktiv', 0)}, pausiert "
             f"{d.get('pausiert', 0)}, beobachtet {n_k - d.get('aktiv', 0) - d.get('pausiert', 0)} von {n_k} Kandidaten · gescheitert "
             f"{d.get('gescheitert', 0)} · Ausfalltage {d.get('ausfalltage', 0)}"
             + (f" · frühere Regelversionen {d['fruehere']}" if d.get("fruehere") else ""))
    if K and K.get("begonnen"):
        z.append(f"Konto {_tsd(K['kapital'])} USD (netto {_usd(K['netto'])}) · Höchststand {_tsd(K['hoch'])} · größter Rückgang "
                 f"{_de(K['groesster_rueckgang'] * 100, 1)} % · übernommen {K['uebernommen']} Trades, offen {K['offen']} · ausgelassen "
                 f"Kapazität {K['ausgelassen'].get('Kapazität', 0)}, Coin {K['ausgelassen'].get('Coin', 0)}, Richtung "
                 f"{K['ausgelassen'].get('Richtung', 0)} · Bremse {'GESETZT seit ' + _uhr(K.get('bremse_seit')) if K['bremse'] else 'aus'}")
        if K.get("bremse") and K.get("loesen_vorgemerkt"):
            z.append(f"Die Bremse ist gesetzt; gelöst am {_uhr(K['loesen_vorgemerkt'])}, wirksam mit der Prüfung am "
                     f"{_uhr(K.get('loesen_wirksam'))} (00:30 UTC).")
        elif K.get("bremse"):
            z.append("Die Bremse ist gesetzt: keine Aufnahme, kein neuer Trade. Weiter nur nach deiner Entscheidung (Button „Bremse lösen“ "
                     "im Reiter „Engine“ des TradeLabors).")
    elif K:
        z.append(f"Konto beginnt am {_uhr(K['start'])} mit {_tsd(KAPITAL)} USD")
    v = d.get("vergleich") or {}
    if v and K.get("begonnen"):
        z.append(f"Im selben Zeitraum realisiert (seit dem Start eröffnet): Labor gesamt {_usd(v.get('labor_netto'))} USD "
                 f"({v.get('labor_trades')} Trades, je Strategie und Coin ein eigenes Konto) · die Kandidaten "
                 f"ungefiltert {_usd(v.get('kandidaten_netto'))} USD ({v.get('kandidaten_trades')} Trades) · Halten Long "
                 f"{_usd(v.get('halten_long_netto'))} USD")
    ab = d.get("abweichung") or {}
    if ab and not ab.get("gleich", True):
        z.append(f"ACHTUNG: {ab['nur_im_protokoll']} gespeicherte Entscheidungen fehlen in der Neuberechnung (z. B. {ab['beispiel']})")
    z.append("")
    z.append(f"{'Strategie':34s} {'Zustand':11s} {'Wo.':>4s} {'Trades':>6s} {'t (A)':>6s} {'t (B)':>6s} {'Überw.':>6s} "
             f"{'Ø auf':>7s} {'Ø ab':>7s}  Grund")
    reihenf = {"aktiv": 0, "pausiert": 1, "beobachtet": 2, "beendet": 3}
    for s in sorted(d["strategien"], key=lambda s: (reihenf[s["engine_zustand"]], s["name"])):
        ue = s.get("ueberwachung") or {}
        uet = f"{ue['anteil'] * 100:.0f} %" if ue and ue.get("anteil") is not None else "—"
        z.append(f"{(s['titel'] or s['name'])[:34]:34s} {s['engine_zustand'] + ('*' if s['gescheitert'] else ''):11s} {s['wochen']:4d} "
                 f"{s['trades']:6d} {_de(s['t_A'], 2):>6s} {_de(s['t_B'], 2):>6s} {uet:>6s} {_de(s['mittel_auf'], 0):>7s} "
                 f"{_de(s['mittel_ab'], 0):>7s}  {s['grund']}")
    z.append("")
    z.append(f"Regeln: Aufnahme (A) ganze Geschichte t ≥ {_de(C_A, 1)} (≥ {MIN_WOCHEN_A} Wochen) oder (B) letzte {FENSTER_B} Wochen t ≥ "
             f"{_de(C_B, 1)}; je beide Hälften positiv und ≥ {MIN_TRADES} Trades; nach einer Pause frühestens nach {ABK_TAGE} Tagen. "
             f"Pause per Überwachung in Handelszeit (Grenze für {ARL0_TAGE} Tage). „gescheitert“ (*): ≥ {FAIL_WOCHEN} Wochen, t ≤ "
             f"−{_de(-FAIL_T, 0)}, beide Hälften und steigende wie fallende BTC-Monate negativ. Ø auf/ab: Tagesmittel in USD in "
             "steigenden/fallenden Monaten.")
    prot = d.get("protokoll") or []
    seit = [e for e in prot if not e.get("vorher")]
    titel = {s["sid"]: s.get("titel") or s["name"] for s in d["strategien"]}
    z.append(f"Entscheidungen seit dem Start des Kontos ({len(seit)}, neueste zuerst):" if not rb else
             f"Entscheidungen im Rückblick ({d.get('n_protokoll', len(prot))}, neueste zuerst):")
    for e in (prot if rb else seit)[::-1][:60]:
        z.append(f"  {_uhr(e['ts'])}  {titel.get(e['sid'], e['name'])}: {e['alt']} → {e['neu']} -- {e['grund']}")
    if not (prot if rb else seit):
        z.append("  keine")
    vorher = [e for e in prot if e.get("vorher")]
    if vorher and not rb:
        z.append(f"Vorgeschichte (Regeln auf die Labor-Trades vor dem Start des Kontos, beschreibend): {len(vorher)} Entscheidungen, "
                 f"zuletzt {_uhr(vorher[-1]['ts'])}")
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
G0T = 20_458                            # Montag, 05.01.2026 (Tag 20.454 = Donnerstag, 01.01.2026)


def _wochenfall(werte, je_tag=3.0, nur_montag=False, art=None, laenge=None, g0=G0T):
    """Eine Zeile aus Wochensummen: je Tag ein Siebtel (bzw. alles am Montag mit einem Trade); jeder Tag ist um 01:00 UTC des
    Folgetags vollständig (also am übernächsten Tag um 00:30 geprüft). Monatsart je Tag bekannt ab dem Tagesende (Vereinfachung)."""
    W = len(werte); T = 7 * W if laenge is None else int(laenge)
    y = np.zeros(T); n = np.zeros(T)
    for w, v in enumerate(werte):
        a = 7 * w
        if a >= T:
            break
        if nur_montag:
            y[a] = v; n[a] = 1
        else:
            y[a:a + 7] = v / 7; n[a:a + 7] = je_tag
    tage = np.arange(T)
    C = np.where(n > 0, (g0 + tage + 1) * TAG + 3600.0, 0.0)
    a_ = np.zeros(T, dtype=int) if art is None else np.asarray(art, dtype=int)[:T]
    return y, n, C, a_, (g0 + tage + 1.0) * TAG


def _laufen(y, n, C, art, bek, bis_tag=None, vorher=None, g0=G0T):
    A = Abspielen(y[None, :], n[None, :], C[None, :], [g0], g0, None, art, bek)
    if vorher is not None:
        vorher(A)
    for D in range(g0, g0 + (y.size if bis_tag is None else int(bis_tag))):
        A.pruefen(D, D * TAG + PRUEF_S)
        A.tag_abschliessen(D)
    return A


def _art_wechsel(T):
    return np.where((np.arange(T) // 30) % 2 == 0, 1, -1)


def _hand_pruefungen(ok):
    """Rechnung von Hand an kurzen erfundenen Reihen."""
    g0 = G0T
    # 1. Tagessumme (Summe, nicht Mittel), offener Trade, spät schließender Trade
    strat = [{"sid": "s1", "name": "magnet", "erstellt": g0 * TAG}, {"sid": "s2", "name": "docht_fangen", "erstellt": g0 * TAG}]
    tr = {"s1": [{"id": 1, "coin": "BTC", "seite": "long", "eroeffnet": g0 * TAG + 3600, "geschlossen": g0 * TAG + 7200, "netto_usd": 30.0},
                 {"id": 2, "coin": "ETH", "seite": "long", "eroeffnet": g0 * TAG + 5000, "geschlossen": g0 * TAG + 9000, "netto_usd": -10.0},
                 {"id": 3, "coin": "BTC", "seite": "short", "eroeffnet": (g0 + 1) * TAG + 100, "geschlossen": None, "netto_usd": None}],
          "s2": [{"id": 4, "coin": "ZEC", "seite": "long", "eroeffnet": g0 * TAG + 80_000, "geschlossen": (g0 + 2) * TAG + 3600,
                  "netto_usd": 5.0}]}
    Y, N, C = tagesreihen(strat, tr, g0, g0 + 4)
    A = Abspielen(Y, N, C, [g0, g0], g0)
    ok("Tagessumme nach Einstiegstag als Summe (30 − 10 = 20 USD aus 2 Trades)", A.Y[0, 0] == 20.0 and N[0, 0] == 2,
       f"{A.Y[0, 0]:g} USD, {N[0, 0]:g} Trades")
    ok("Ein Tag zählt erst, wenn alle seine Trades geschlossen sind: offener Trade nie; Schluss am übernächsten Tag 01:00 → Prüfung "
       "am Tag danach", A.ptag[0, 0] == g0 + 1 and math.isinf(A.ptag[0, 1]) and A.ptag[1, 0] == g0 + 3,
       f"Prüftage {A.ptag[0, 0] - g0:g}, {A.ptag[0, 1] - g0:g}, {A.ptag[1, 0] - g0:g}")
    # 2. Wochen Montag–Sonntag, dienstags; Ausfallwoche fällt aus; laufende Woche zählt nicht
    T = 21
    Y = np.vstack([np.arange(T, dtype=float)] * 2); N = np.ones((2, T))
    C = np.vstack([(g0 + np.arange(T) + 1) * TAG + 3600.0, (g0 + np.arange(T)) * TAG + 7200.0])
    aus = np.zeros(T, bool); aus[9] = True                       # Mittwoch der zweiten Woche
    A = Abspielen(Y, N, C, [g0, g0], g0, aus)
    for D in range(g0, g0 + 21):
        A.pruefen(D, D * TAG + PRUEF_S)
    wd = A.gueltige(0, 0, A.w_aus[0], (g0 + 21) * TAG)
    ok("Wochen Montag–Sonntag, geprüft dienstags (auch wenn schon montags vollständig); Ausfallwoche fällt aus; laufende Woche nicht",
       A.w_aus[0] == 1 and list(wd) == [0] and A.WY[0, 0] == float(sum(range(7))) and A.wtag[1, 0] == g0 + 8 and A.wtag[0, 0] == g0 + 8,
       f"bis {int(A.w_aus[0])}, gültig {[int(x) for x in wd]}, Summe {A.WY[0, 0]:g}, Prüftag {A.wtag[1, 0] - g0:g}")
    # 3. t und Hälften
    t, mu, m1, m2, n_ = t_wert([1.0, 2.0, 3.0, 4.0])
    sd = float(np.std([1, 2, 3, 4], ddof=1))
    ok("t der Wochensummen und Hälften von Hand", abs(t - 2.5 / (sd / 2)) < 1e-12 and m1 == 1.5 and m2 == 3.5 and n_ == 4, f"{t:.4f}")
    # 4. Siegmund
    k, arl = 0.1, 2190.0
    h = siegmund_grenze(k, arl); b = h + 1.166
    v = (math.exp(2 * k * b) - 2 * k * b - 1) / (2 * k * k)
    ok("Grenze aus Siegmunds Näherung (Gleichung erfüllt; k = 0 ergibt √ARL − 1,166; nie unter 2)",
       abs(v - arl) / arl < 1e-6 and abs(siegmund_grenze(0.0, 400.0) - (20 - 1.166)) < 1e-9 and siegmund_grenze(3.0, 100.0) == 2.0,
       f"h {h:.3f}, ARL {v:.1f}")
    # 5. Zuwachs in Handelszeit
    z = cusum_zuwachs([0, 4, 1], [0.0, -1000.0, 50.0], 0.1, 100.0)
    ok("Überwachung in Handelszeit: Tag ohne Trade ändert nichts, Zuwachs n·k − y/s, Kappung bei ±3·√n",
       z[0] == 0.0 and abs(z[1] - 6.0) < 1e-12 and abs(z[2] - (0.1 - 0.5)) < 1e-12, f"{z}")
    # 6. Bezug
    y_t = np.array([100.0, 300.0] * 35); n_t = np.full(70, 2.0)
    w = [1400.0, 1300.0, 1500.0, 1400.0, 1400.0, 1300.0, 1500.0, 1400.0, 1400.0, 1400.0]
    bz = bezug(y_t, n_t, w)
    se = float(np.std(w, ddof=1)) / math.sqrt(10) / 7
    ok("Bezug der Überwachung: (Tagesmittel − Standardfehler) je Trade, Streuung je Trade, k und Grenze für 730 Tage",
       abs(bz["mu_ref"] - (200.0 - se)) < 1e-9 and abs(bz["mu_trade"] - (200.0 - se) / 2) < 1e-9
       and abs(bz["s_trade"] - math.sqrt(np.var(y_t, ddof=1) / 2)) < 1e-9 and abs(bz["h"] - siegmund_grenze(bz["k"], 730 * 2)) < 1e-12,
       f"μ {bz['mu_ref']:.3f}, k {bz['k']:.4f}, h {bz['h']:.2f}")
    # 7. Umfang
    try:
        import hl_labor
        S = hl_labor.strategien()
        soll = sorted(s["name"] for s in S if s["gruppe"] in ("Händler", "Prognose", "Familien", "Ereignisse"))
        lang = [s["name"] for s in S if s["name"] in umfang() and float(s["regeln"].get("h", 4)) > 24]
    except Exception as e:  # noqa: BLE001
        soll, lang = [f"Fehler {e}"], []
    ok("Umfang: genau die 34 Strategien mit höchstens 24 h (Händler, Prognose, Familien, Ereignisse), keine Kontrolle",
       sorted(umfang()) == soll and len(umfang()) == 34 and not lang and not set(KONTROLLEN) & set(umfang()), f"{len(umfang())}")
    # 8. Monatsart aus BTC: Januar steigt, Februar fällt, März offen
    d0 = 20_453                                                  # 31.12.2025
    btc = {d0: 100.0}
    btc.update({d0 + 1 + i: 100.0 + i for i in range(31)})        # Januar bis 31.01. (130)
    btc.update({d0 + 32 + i: 129.0 - i for i in range(28)})       # Februar (102 am 28.02.)
    btc.update({d0 + 60 + i: 150.0 for i in range(15)})           # März bis 15.03.
    art, bek = monatsarten(btc, d0 + 1, d0 + 74)
    btc2 = {g: c for g, c in btc.items() if g != d0 + 31}           # Kerze vom 31.01. fehlt
    art2, _ = monatsarten(btc2, d0 + 1, d0 + 74)
    ok("Monatsart: Schluss des letzten Monatstags gegen den letzten Tag des Vormonats, bekannt ab dem zweiten Tag nach dem Monatsende; "
       "offener Monat unbekannt; fehlt der letzte Tag eines Monats, sind er und der Folgemonat unbekannt",
       art[0] == 1 and art[30] == 1 and art[31] == -1 and art[58] == -1 and art[59] == 0 and bek[0] == (d0 + 33) * TAG
       and bek[31] == (d0 + 61) * TAG and art2[0] == 0 and art2[31] == 0, f"{art[[0, 30, 31, 58, 59]]} / {art2[[0, 31]]}")
    # 9. Ausfalltage aus dem Puls
    t0 = g0 * TAG
    puls = list(range(t0 + 3600, t0 + 22 * 3600, 300)) + list(range(t0 + 24 * 3600 + 1800, t0 + 30 * 3600, 300))  # Lücke 22:00–00:30
    puls += list(range(t0 + 31 * 3600 - 600, t0 + 40 * 3600, 300))                                             # Lücke 50 min
    au = ausfalltage(puls, g0 - 1, g0 + 3, t0 + 3 * TAG + 7200)
    ok("Ausfall: eine Lücke von mehr als 1 h macht jeden berührten Tag zum Ausfall, bekannt ab 1 h nach ihrem Beginn; 50 min nicht; "
       "vor dem ersten Puls unbekannt; laufende Lücke zählt", [bool(np.isfinite(x)) for x in au] == [False, True, True, True, True]
       and au[1] == au[2] == t0 + 22 * 3600 - 300 + 3601 and au[3] == au[4] == t0 + 40 * 3600 - 300 + 3601,
       f"{[bool(np.isfinite(x)) for x in au]}")
    # 10. Ausfall nur mit dem Wissen der Prüfung: ein Tag zählt in der Überwachung, wenn sein Ausfall erst nach der Prüfung bekannt wurde
    T = 10
    S_ = []
    for verschiebung in (900, -1):
        Y = np.full((1, T), -500.0); N = np.full((1, T), 3.0); C = (g0 + np.arange(T)[None, :] + 1) * TAG - 3600.0
        R_chk = (g0 + 6) * TAG + PRUEF_S                           # die Prüfung am Tag 6 zählt den Tag 5
        aus = np.full(T, np.inf); aus[5] = R_chk + verschiebung
        A = Abspielen(Y, N, C, [g0], g0, aus)
        A.zust[:] = 1; A.auf_tag[:] = 0; A.k[:] = 0.1; A.s_t[:] = 100.0; A.h[:] = np.inf; A.zeiger[:] = 5
        A.ueberwachen(g0 + 6, R_chk)
        S_.append(float(A.S[0]))
    ok("Ausfall kausal: Tag in der Überwachung gezählt, wenn der Ausfall erst 15 min nach der Prüfung bekannt wurde; übersprungen, "
       "wenn er vorher bekannt war", S_[0] > 0 and S_[1] == 0.0, f"{S_}")


def _regel_pruefungen(ok):
    """Gebaute Fälle für einzelne Regeln (deterministisch)."""
    rng = np.random.default_rng(7)
    # (a) Aufnahme über (A) nach 9 vollständigen Wochen, dienstags
    A = _laufen(*_wochenfall(1000 + 150 * rng.standard_normal(40)))
    e = next((x for x in A.protokoll if x["neu"] == "aktiv"), {})
    ok("Aufnahme über (A) am Dienstag nach der 9. vollständigen Woche (Tag 64)", A.erst_auf[0] == 64 and e.get("werte", {}).get("fenster") == "A",
       f"Tag {A.erst_auf[0]}")
    # (a2) Mindestzahl: ein Trade je Woche → erst nach 30 Wochen
    A = _laufen(*_wochenfall(1000 + 50 * rng.standard_normal(34), nur_montag=True))
    ok("Mindestzahl 30 Trades: ein Trade je Woche wird erst nach 30 Wochen aufgenommen (Tag 211)", A.erst_auf[0] == 211, f"Tag {A.erst_auf[0]}")
    # (b) Rückkehr über (B) nach 20 schlechten Wochen
    A = _laufen(*_wochenfall(list(-800 + 100 * rng.standard_normal(20)) + list(1200 + 100 * rng.standard_normal(20))))
    fe = [x["werte"].get("fenster") for x in A.protokoll if x["neu"] == "aktiv"]
    ok("Aufnahme über das 17-Wochen-Fenster (B) nach 20 schlechten Wochen ((A) bleibt zu)", fe[:1] == ["B"], f"{fe} Tag {A.erst_auf[0]}")
    # (c) Abkühlung nach einer Pause (Einheitsprüfung): 12 gute Wochen, (B) noch nicht möglich
    y, n, C, art, bek = _wochenfall(1000 + 100 * rng.standard_normal(12), laenge=7 * 12 + 7)
    Y = np.vstack([y] * 3); Y[2, 84] = Y[2, 85] = -5000.0                # Zeile 2: Summe seit der Pause negativ (Tage nach Woche 11)
    A = Abspielen(Y, np.vstack([n] * 3), np.vstack([C] * 3), [G0T] * 3, G0T)
    D = G0T + 86; R_ts = D * TAG + PRUEF_S
    A.zust[:] = 2; A.zeiger[:] = 86
    for i, tage in ((0, 20), (1, 31), (2, 31)):
        A.t_pause[i] = R_ts - tage * TAG; A.tag_pause[i] = 86 - tage
        A._aufnahme_pruefen(i, 11, D, R_ts)
    ok("Nach einer Pause: frühestens nach 30 Tagen; über (A) nur mit positiver Summe seit der Pause",
       [int(x) for x in A.zust] == [2, 1, 2], f"Zustände {[int(x) for x in A.zust]} (20 Tage; 31 Tage und Summe > 0; 31 Tage und Summe < 0)")
    # (d) über (B) ohne die Summen-Bedingung
    werte = list(-5000 + 100 * rng.standard_normal(3)) + list(1000 + 100 * rng.standard_normal(17))
    y, n, C, art, bek = _wochenfall(werte, laenge=7 * 20 + 1)
    y[140] = -30000.0; n[140] = 3
    A = Abspielen(y[None, :], n[None, :], C[None, :], [G0T], G0T)
    D = G0T + 141; R_ts = D * TAG + PRUEF_S
    A.zust[0] = 2; A.zeiger[0] = 141; A.t_pause[0] = R_ts - 48 * TAG; A.tag_pause[0] = 93
    A._aufnahme_pruefen(0, 19, D, R_ts)
    ok("Nach einer Pause über (B) auch mit negativer Summe seit der Pause ((A) bleibt zu)",
       A.zust[0] == 1 and A.auf_fenster[0] == "B" and A.summe_seit_pause(0, R_ts) < 0,
       f"Zustand {A.zust[0]}, Summe {A.summe_seit_pause(0, R_ts):.0f}")
    # (e) gescheitert: alle Bedingungen
    T = 7 * 40
    aw = _art_wechsel(T)
    A1 = _laufen(*_wochenfall(-1000 + 100 * rng.standard_normal(40), art=aw))
    y = np.where(aw > 0, 100.0, -1500.0); n = np.full(T, 3.0)
    C = (G0T + np.arange(T) + 1) * TAG + 3600.0
    A2 = _laufen(y, n, C, aw, (G0T + np.arange(T) + 1.0) * TAG)
    werte = list(50 + 10 * rng.standard_normal(10)) + list(-2000 + 10 * rng.standard_normal(12))
    A3 = _laufen(*_wochenfall(werte, art=_art_wechsel(7 * 22)), bis_tag=150)
    ok("„gescheitert“ (t ≤ −3, 13 Wochen, beide Hälften negativ) erst, wenn auch steigende und fallende Monate negativ sind",
       A1.erst_fail[0] == 92 and A2.erst_fail[0] < 0 and A3.erst_fail[0] < 0,
       f"schlecht: Tag {A1.erst_fail[0]}; nur in fallenden Monaten negativ: {A2.erst_fail[0]}; erste Hälfte positiv: {A3.erst_fail[0]}")
    # (f) nach „gescheitert“ keine Aufnahme über (A)
    werte = 1000 + 100 * rng.standard_normal(12)
    A = _laufen(*_wochenfall(werte), vorher=lambda a: (a.gesch.__setitem__(0, True), a.gesch_seit.__setitem__(0, 0)))
    A0 = _laufen(*_wochenfall(werte))
    ok("Nach „gescheitert“ keine Aufnahme über (A) (ohne die Bezeichnung: Tag 64)", A.erst_auf[0] < 0 and A0.erst_auf[0] == 64,
       f"{A.erst_auf[0]} / {A0.erst_auf[0]}")
    # (g) Rückkehr über (B); danach zählt „gescheitert“ neu
    werte = list(-1000 + 100 * rng.standard_normal(30)) + list(100 + 10 * rng.standard_normal(17)) + list(-50 + 10 * rng.standard_normal(10))
    A = _laufen(*_wochenfall(werte, art=_art_wechsel(7 * 57)))
    ges = [x for x in A.protokoll if x["neu"] == "gescheitert"]
    ok("Rückkehr über (B) nach „gescheitert“ (Tag 330); danach zählt „gescheitert“ nur die Wochen seit der Rückkehr",
       len(ges) == 1 and A.zurueck[0] >= 0 and A.erst_auf[0] == 330, f"gescheitert {len(ges)}×, zurück Tag {A.erst_auf[0]}")


def _trades_aus(strat_zeilen, g0, tage, rng, je_tag=3, halten_s=3600, coins=("BTC", "ETH", "ZEC", "HYPE", "XMR")):
    """Erfundene Labor-Trades: je Strategie (sid, Seite, Funktion Tag → netto je Trade)."""
    trades, k = {}, 0
    for sid, seite, f in strat_zeilen:
        trades[sid] = []
        for j in range(tage):
            for m in range(je_tag):
                t = (g0 + j) * TAG + 2 * 3600 + m * 5 * 3600 + int(rng.integers(0, 600))
                trades[sid].append({"id": k, "coin": coins[(k // 2) % len(coins)], "seite": seite, "eroeffnet": t,
                                    "geschlossen": t + halten_s, "netto_usd": float(f(j))})
                k += 1
    return trades


def _gesehen_bis(trades, cut):
    """Die Trades so, wie das Labor sie zum Zeitpunkt cut kannte (später schließende sind offen, spätere fehlen)."""
    aus = {}
    for sid, v in trades.items():
        aus[sid] = [dict(tr, geschlossen=None, netto_usd=None) if tr["geschlossen"] > cut else dict(tr) for tr in v if tr["eroeffnet"] <= cut]
    return aus


def _konto_pruefungen(ok):
    """Papierkonto: Kapazität, Grenzen je Coin und Richtung, Bremse; Ende zu Ende über abspielen; Kausalität."""
    t0 = G0T * TAG
    K = Konto(t0)
    gr = [K.anbieten({"id": i, "coin": ["BTC", "ETH", "ZEC", "HYPE"][i % 4], "seite": "long" if i % 2 else "short",
                      "eroeffnet": t0 + 60 * i, "geschlossen": t0 + 86_000, "netto_usd": 1.0}) for i in range(12)]
    ok("Konto: höchstens 10 offene Positionen (11. und 12. ausgelassen und gezählt)", gr[:10] == [None] * 10 and gr[10] == "Kapazität"
       and K.ausgelassen["Kapazität"] == 2, f"{gr}")
    K = Konto(t0)
    g = [K.anbieten({"id": i, "coin": "BTC", "seite": "long" if i < 2 else "short", "eroeffnet": t0 + i, "geschlossen": None,
                     "netto_usd": None}) for i in range(5)]
    K2 = Konto(t0)
    g2 = [K2.anbieten({"id": i, "coin": ["BTC", "ETH", "ZEC", "HYPE", "XMR", "BTC", "ETH"][i], "seite": "long", "eroeffnet": t0 + i,
                       "geschlossen": None, "netto_usd": None}) for i in range(7)]
    K3 = Konto(t0)
    g3 = [K3.anbieten({"id": i, "coin": "BTC", "seite": "long", "eroeffnet": t0 + 10 * i, "geschlossen": t0 + 10 * i + 5,
                       "netto_usd": 1.0}) for i in range(6)]
    ok("Konto: höchstens 4 je Coin und 6 in dieselbe Richtung; geschlossene Positionen geben den Platz frei",
       g == [None] * 4 + ["Coin"] and g2 == [None] * 6 + ["Richtung"] and g3 == [None] * 6, f"{g} {g2} {g3}")
    K = Konto(t0)
    for i in range(3):
        K.anbieten({"id": i, "coin": "BTC", "seite": "long", "eroeffnet": t0 + i, "geschlossen": t0 + 100 + i,
                    "netto_usd": [3000.0, -6000.0, -8000.0][i]})
    K.realisieren_bis(t0 + 101); b1 = K.bremse_faellig()
    K.realisieren_bis(t0 + 102); b2 = K.bremse_faellig()
    ok("Bremse bei mehr als 10 % unter dem Höchststand (realisiert)", not b1 and b2 and K.hoch == 103_000.0 and K.kapital == 89_000.0,
       f"{K.kapital} {K.hoch}")
    # Ende zu Ende: a gut 12 Wochen, dann schlecht; b immer schlecht
    rng = np.random.default_rng(3)
    strat = [{"sid": "a", "name": "magnet", "erstellt": t0}, {"sid": "b", "name": "docht_fangen", "erstellt": t0}]
    tr = _trades_aus([("a", "long", lambda j: 200.0 + 30 * rng.standard_normal() if j < 84 else -300.0 + 30 * rng.standard_normal()),
                      ("b", "short", lambda j: -20.0 + 30 * rng.standard_normal())], G0T, 7 * 16, rng)
    bis = (G0T + 7 * 16) * TAG
    res = abspielen(strat, tr, {}, [], t0, bis)
    A, K = res["A"], res["K"]
    auf, pz = int(A.auf_ts[0]), (int(A.t_pause[0]) if A.n_pause[0] else None)
    nur_a = all(x["sid"] == "a" for x in K.uebernommen)
    im_fenster = all(auf <= int(x["eroeffnet"]) < (pz or bis + 1) for x in K.uebernommen)
    ok("Ende zu Ende: übernommen nur Trades der aktiven Strategie, erst ab ihrer Aufnahme und nicht mehr nach ihrer Pause",
       A.erst_auf[0] == 64 and pz is not None and bool(K.uebernommen) and nur_a and im_fenster and A.erst_auf[1] < 0,
       f"Aufnahme Tag {A.erst_auf[0]}, Pause {None if pz is None else pz // TAG - G0T}, übernommen {len(K.uebernommen)}")
    # Limit-Order: es zählt die Füllung (Eröffnung), nicht die Order: 1 s vor der Aufnahme nicht, 1 s danach schon
    tr2 = {s: [dict(x) for x in v] for s, v in tr.items()}
    tr2["a"].append({"id": 10 ** 6, "coin": "XMR", "seite": "short", "eroeffnet": auf - 1, "geschlossen": auf + 600, "netto_usd": 1.0})
    tr2["a"].append({"id": 10 ** 6 + 1, "coin": "XMR", "seite": "short", "eroeffnet": auf + 1, "geschlossen": auf + 700, "netto_usd": 1.0})
    K2 = abspielen(strat, tr2, {}, [], t0, bis)["K"]
    ids = {x["id"] for x in K2.uebernommen}
    ok("Limit-Order nach dem Zustand bei der Füllung: 1 s vor der Aufnahme nicht, 1 s danach übernommen",
       10 ** 6 not in ids and 10 ** 6 + 1 in ids, "")
    # Kausal: der Stand zum Zeitpunkt cut hängt nur von Trades ab, die bis dahin geschlossen waren
    tr3 = _trades_aus([("a", "long", lambda j: 200.0 + 30 * rng.standard_normal() if j < 84 else -300.0 + 30 * rng.standard_normal()),
                       ("b", "short", lambda j: -20.0 + 30 * rng.standard_normal())], G0T, 7 * 16, rng, halten_s=20 * 3600)
    gleich = []
    for cut in ((G0T + 85) * TAG + 3600, (G0T + 64) * TAG + 3600, (G0T + 90) * TAG + 3600):
        r1 = abspielen(strat, tr3, {}, [], t0, cut); r2 = abspielen(strat, _gesehen_bis(tr3, cut), {}, [], t0, cut)
        p1 = [(x["ts"], x["sid"], x["neu"]) for x in r1["A"].protokoll]; p2 = [(x["ts"], x["sid"], x["neu"]) for x in r2["A"].protokoll]
        gleich.append(p1 == p2 and np.array_equal(r1["A"].zeiger, r2["A"].zeiger) and np.allclose(r1["A"].S, r2["A"].S)
                      and np.array_equal(r1["A"].zust, r2["A"].zust) and abs(r1["K"].kapital - r2["K"].kapital) < 1e-6)
    ok("Kausal: der Stand zu drei Zeitpunkten ist derselbe, ob das Labor die späteren Schließungen schon kennt oder nicht",
       all(gleich), f"{gleich}")
    # Bremse Ende zu Ende: c stark, dann tiefe Verluste (Trades 23 h); d gut und aktiv, wird von der Bremse pausiert; Lösen von Hand
    rng = np.random.default_rng(5)
    strat = [{"sid": "c", "name": "magnet", "erstellt": t0}, {"sid": "d", "name": "docht_fangen", "erstellt": t0}]
    tr = _trades_aus([("c", "long", lambda j: 300.0 + 30 * rng.standard_normal() if j < 71 else -5000.0),
                      ("d", "short", lambda j: 150.0 + 20 * rng.standard_normal())], G0T, 7 * 14, rng, halten_s=23 * 3600)
    loes = (G0T + 80) * TAG + 3600
    bis = (G0T + 7 * 14) * TAG
    res = abspielen(strat, tr, {}, [], t0, bis, [loes])
    A, K = res["A"], res["K"]
    br = [x for x in A.protokoll if x["neu"] == "Bremse"]
    t_br = br[0]["ts"] if br else None
    auf_zw = [x for x in A.protokoll if x["neu"] == "aktiv" and t_br and t_br < x["ts"] <= (G0T + 80) * TAG + PRUEF_S]
    d_zurueck = [x for x in A.protokoll if x["sid"] == "d" and x["neu"] == "aktiv" and x["ts"] == (G0T + 81) * TAG + PRUEF_S]
    zw = [x for x in K.uebernommen if t_br and t_br <= int(x["eroeffnet"]) < (G0T + 81) * TAG + PRUEF_S]
    ok("Bremse Ende zu Ende: −10 % → alle pausiert, keine Aufnahme und kein Trade bis zum Lösen; danach neuer Höchststand und die "
       "von der Bremse pausierte Strategie sofort wieder aktiv", bool(br) and not auf_zw and not zw and bool(d_zurueck)
       and A.zust[1] == 1 and K.hoch >= K.kapital, f"Bremse {None if t_br is None else t_br // TAG - G0T}, Aufnahmen dazwischen "
       f"{len(auf_zw)}, Trades dazwischen {len(zw)}, d zurück {bool(d_zurueck)}")
    # Reihenfolge in derselben Prüfung: Überwachung, Bremse, erst dann Aufnahmen. c verliert ab Tag 64 (Bremse am Tag 65); e (Trades
    # 40 h) wäre am Tag 65 aufgenommen worden, weil ihre 9. Woche erst dann vollständig ist
    rng = np.random.default_rng(8)
    strat = [{"sid": "c", "name": "magnet", "erstellt": t0}, {"sid": "e", "name": "docht_fangen", "erstellt": t0}]
    tr = _trades_aus([("c", "long", lambda j: 300.0 + 30 * rng.standard_normal() if j < 64 else -5000.0)], G0T, 7 * 12, rng)
    tr.update(_trades_aus([("e", "short", lambda j: 150.0 + 20 * rng.standard_normal())], G0T, 7 * 12, rng, halten_s=40 * 3600))
    for x in tr["e"]:
        x["id"] += 10 ** 6
    A = abspielen(strat, tr, {}, [], t0, (G0T + 7 * 12) * TAG)["A"]
    br = [x["ts"] for x in A.protokoll if x["neu"] == "Bremse"]
    gleich = [x for x in A.protokoll if x["neu"] == "aktiv" and br and x["ts"] == br[0]]
    ok("Bremse vor der Aufnahme derselben Prüfung: am Tag der Bremse wird keine Strategie aufgenommen (auch nicht kurz)",
       bool(br) and br[0] == (G0T + 65) * TAG + PRUEF_S and not gleich and A.zust[1] != 1,
       f"Bremse {[b_ // TAG - G0T for b_ in br]}, aufgenommen zugleich {[x['sid'] for x in gleich]}")
    # Hänger: ein Trade von a bleibt offen → a pausiert 72 h nach dem Ende seines Tages und übernimmt nichts mehr; schließt er später,
    # ist a wieder beobachtet und wird ohne Abkühlung bei der nächsten Wochenprüfung aufgenommen
    rng = np.random.default_rng(9)
    strat = [{"sid": "a", "name": "magnet", "erstellt": t0}]
    tr = _trades_aus([("a", "long", lambda j: 200.0 + 30 * rng.standard_normal())], G0T, 7 * 14, rng)
    h_id = next(x["id"] for x in tr["a"] if x["eroeffnet"] // TAG == G0T + 70)
    bis = (G0T + 7 * 14) * TAG
    res = abspielen(strat, {"a": [dict(x, geschlossen=None, netto_usd=None) if x["id"] == h_id else x for x in tr["a"]]}, {}, [], t0, bis)
    A, K = res["A"], res["K"]
    p_ = [x for x in A.protokoll if x["neu"] == "pausiert" and "Überwachung steht" in x["grund"]]
    nach = [x for x in K.uebernommen if p_ and int(x["eroeffnet"]) >= p_[0]["ts"]]
    A2 = abspielen(strat, {"a": [dict(x, geschlossen=(G0T + 76) * TAG + 43_200) if x["id"] == h_id else x for x in tr["a"]]}, {}, [],
                   t0, bis)["A"]
    wieder = [x for x in A2.protokoll if x["neu"] == "beobachtet" and "läuft wieder" in x["grund"]]
    auf2 = [x for x in A2.protokoll if x["neu"] == "aktiv" and wieder and x["ts"] >= wieder[0]["ts"]]
    ok("Hänger: ein Trade 72 h nach dem Ende seines Tages noch offen → Pause am Tag 74, kein Trade mehr; schließt er, wieder beobachtet "
       "und ohne Abkühlung bei der nächsten Wochenprüfung aufgenommen",
       bool(p_) and p_[0]["ts"] == (G0T + 74) * TAG + PRUEF_S and not nach and bool(wieder) and bool(auf2)
       and auf2[0]["ts"] - wieder[0]["ts"] < 8 * TAG, f"Pause {[x['ts'] // TAG - G0T for x in p_]}, danach übernommen {len(nach)}, "
       f"wieder {[x['ts'] // TAG - G0T for x in wieder]}, aufgenommen {[x['ts'] // TAG - G0T for x in auf2]}")


def probe_dateien(tmp: str, wechsel: bool = False, bremse: bool = False) -> dict:
    """Probeordner für Selbsttests (auch den des Dashboards): Labor-Speicher mit dem Schema des Labors (fünf Strategien, davon zwei
    Kandidaten in der aktuellen Regelversion, zwei Kontrollen, eine alte Regelversion), Hauptdatenbank mit BTC-Tageskerzen. Mit wechsel:
    Magnet handelt bis Tag 80 unter der alten Kennung (gut, wird aufgenommen), ab Tag 80 14:00 UTC gilt eine neue Regelversion. Mit
    bremse: Magnet verliert ab Tag 75 je Trade 5.000 USD -- das Konto fällt mehr als 10 % unter seinen Höchststand, die Bremse greift."""
    import hl_labor
    g0, T = G0T, 7 * 14
    db = os.path.join(tmp, "hl_liq.db"); store = os.path.join(tmp, "forecasts.db")
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE daily_bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, source TEXT)")
    con.executemany("INSERT INTO daily_bars VALUES (?,?,?,?,?,?,?,?)", [((g0 + j) * TAG, "BTC", 1, 1, 1, 100.0 + j, 1, "probe")
                                                                        for j in range(-40, T + 2)])
    con.commit(); con.close()
    st = sqlite3.connect(store); hl_labor.schema(st)
    t_neu = (g0 + 80) * TAG + 14 * 3600 if wechsel else g0 * TAG + 3600
    zeilen = (("magnet@neu", "magnet", "Ereignisse", 1, t_neu), ("docht@1", "docht_fangen", "Ereignisse", 1, g0 * TAG + 3600),
              ("zufall@1", "zufall", "Kontrolle", 1, g0 * TAG + 3600), ("halten@1", "halten_long", "Kontrolle", 1, g0 * TAG + 3600),
              ("magnet@alt", "magnet", "Ereignisse", 0, g0 * TAG + 3600))
    for sid, name, gr, akt, erstellt in zeilen:
        st.execute("INSERT INTO labor_strategie VALUES (?,?,?,?,?,?,?,?)", (sid, name, name.replace("_", " ").title(), gr, "{}", "Probe",
                                                                          erstellt, akt))
    rng = np.random.default_rng(11)
    tr = _trades_aus([("magnet@neu", "long", (lambda j: 300.0 + 30 * rng.standard_normal() if j < 75 else -5000.0) if bremse
                       else (lambda j: 200.0 + 30 * rng.standard_normal())),
                      ("docht@1", "short", lambda j: -50.0 + 30 * rng.standard_normal()), ("zufall@1", "long", lambda j: 500.0),
                      ("halten@1", "long", lambda j: 10.0),
                      ("magnet@alt", "long", (lambda j: 200.0 + 30 * rng.standard_normal()) if wechsel else (lambda j: 999.0))], g0, T, rng)
    if wechsel:                                                         # alte Kennung bis zum Wechsel, neue erst danach
        tr["magnet@alt"] = [x for x in tr["magnet@alt"] if x["geschlossen"] < t_neu]
        tr["magnet@neu"] = [x for x in tr["magnet@neu"] if x["eroeffnet"] > t_neu]
    jetzt = (g0 + T) * TAG + 7200
    for sid, v in tr.items():
        for x in v:
            zu = x["geschlossen"] if x["geschlossen"] <= jetzt else None
            st.execute("INSERT INTO labor_position (sid, coin, seite, status, eroeffnet, geschlossen, netto_usd, notional) "
                       "VALUES (?,?,?,?,?,?,?,?)", (sid, x["coin"], x["seite"], "geschlossen" if zu else "offen", x["eroeffnet"], zu,
                                                    x["netto_usd"] if zu else None, NOTIONAL))
    st.commit(); st.close()
    return {"db": db, "store": store, "g0": g0, "T": T, "jetzt": jetzt}


def probe_laufen(pr: dict) -> tuple:
    """Dienst über den Probeordner: erster Schritt am Tag 60 (Start am Tag 61), Puls mit einer Lücke von 2 h am Tag 70, zweiter
    Schritt am Ende, dritter eine Minute später (rechnet nicht). Rückgabe (Start, r1, r2, r3)."""
    db, store, g0, jetzt = pr["db"], pr["store"], pr["g0"], pr["jetzt"]
    alt = dict(_DIENST)
    try:
        _DIENST.update({"puls": 0, "labor_t": None})
        t_ein = (g0 + 60) * TAG + 5000
        r1 = takt_schritt(db, labor_t=1, jetzt=t_ein, store=store)
        con = verbinden(engine_pfad(db))
        start = meta(con, "start")
        luecke = ((g0 + 70) * TAG + 3600, (g0 + 70) * TAG + 3 * 3600)
        p = [t for t in range(t_ein, jetzt - 600, 300) if not luecke[0] < t < luecke[1]]
        con.execute("BEGIN IMMEDIATE"); con.executemany("INSERT OR IGNORE INTO eng_puls VALUES (?)", [(t,) for t in p])
        con.execute("COMMIT"); con.close()
        _DIENST.update({"puls": 0, "labor_t": None})
        r2 = takt_schritt(db, labor_t=2, jetzt=jetzt, store=store)
        r3 = takt_schritt(db, labor_t=3, jetzt=jetzt + 60, store=store)
    finally:
        _DIENST.clear(); _DIENST.update(alt)
    return start, r1, r2, r3


def _ende_zu_ende(ok):
    """Dienst über echte Dateien in einem Probeordner: Labor-Speicher mit Schema des Labors, Hauptdatenbank mit BTC-Tageskerzen,
    engine.db; Start, Puls mit einer Lücke, Protokoll, Abgleich, gespeicherter Stand, Bericht, Rückblick."""
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="engine_probe_")
    try:
        pr = probe_dateien(tmp)
        db, store, g0, jetzt = pr["db"], pr["store"], pr["g0"], pr["jetzt"]
        start, r1, r2, r3 = probe_laufen(pr)
        d = stand_lesen(db)
        alt = dict(_DIENST)
        S = {s["sid"]: s for s in d.get("strategien") or []}
        K = d.get("konto") or {}
        gesp = d.get("protokoll_gespeichert") or []
        ok("Ende zu Ende: Start am Folgetag 00:00 UTC; nur die aktuelle Regelversion der Kandidaten (keine Kontrolle); gute Strategie "
           "aktiv, schlechte nicht", start == (g0 + 61) * TAG and set(S) == {"magnet@neu", "docht@1"}
           and S["magnet@neu"]["engine_zustand"] == "aktiv" and S["docht@1"]["engine_zustand"] == "beobachtet" and r1.get("neu"),
           f"Start Tag {None if start is None else start // TAG - g0}, Zeilen {sorted(S)}")
        kp = kopf(db) or {}
        ok("Ende zu Ende: Konto ab dem Start nur mit Trades der aktiven Strategie (Tagessummen ergeben das Netto); Vergleich Labor, "
           "Kandidaten und Halten Long; ein Ausfalltag aus der Pulslücke; Kurzstand für den Kopf",
           K.get("begonnen") and K.get("uebernommen", 0) > 0 and K.get("netto", 0) > 0
           and all(x["sid"] == "magnet@neu" and x["eroeffnet"] >= start for x in K.get("letzte") or [])
           and abs(sum(x[1] for x in K.get("tage_netto") or []) - K.get("netto", 0)) < 0.05
           and (d.get("vergleich") or {}).get("halten_long_trades", 0) > 0 and d.get("ausfalltage") == 1
           and kp.get("aktiv") == 1 and kp.get("n") == 2 and kp.get("begonnen") is True,
           f"übernommen {K.get('uebernommen')}, netto {K.get('netto')}, Ausfalltage {d.get('ausfalltage')}, Kopf {kp}")
        ok("Ende zu Ende: Entscheidungen seit dem Start im Protokoll, Abgleich ohne Abweichung, Rechnung höchstens alle 10 min",
           r2.get("neu") and (r2.get("abweichung") or {}).get("gleich") and r3 == {"neu": False}
           and all(e["ts"] >= start for e in gesp) and d.get("puls", {}).get("n", 0) > 100,
           f"gespeichert {len(gesp)}, Abgleich {r2.get('abweichung')}, Puls {d.get('puls')}")
        con = verbinden(engine_pfad(db))
        con.execute("BEGIN IMMEDIATE")
        con.execute("INSERT INTO eng_protokoll (ts, sid, name, alt, neu, grund, werte, geschrieben) VALUES (?,?,?,?,?,?,?,?)",
                    (start + 999, "docht@1", "docht_fangen", "beobachtet", "aktiv", "erfunden", "{}", jetzt))
        con.execute("DELETE FROM eng_stand"); con.execute("COMMIT"); con.close()
        _DIENST.update({"puls": 0, "labor_t": None})
        try:
            r4 = takt_schritt(db, labor_t=None, jetzt=jetzt + 700, store=store)
        finally:
            _DIENST.clear(); _DIENST.update(alt)
        txt = text(stand_lesen(db))
        rb = rechnen(db, store=store, jetzt=jetzt, rueckblick=True)
        ok("Ende zu Ende: eine erfundene Entscheidung im Protokoll meldet der Abgleich; Bericht, Rückblick ab dem Start des Labors, "
           "Bremse ohne Anlass nicht gelöst", not (r4.get("abweichung") or {}).get("gleich", True) and "ACHTUNG" in txt
           and "Magnet" in txt and rb.get("engine_start") == (g0 + 1) * TAG and rb.get("rueckblick")
           and (lambda o: o["ok"] is False and "nicht gesetzt" in o["msg"])(bremse_loesen(db)),
           f"Abgleich {r4.get('abweichung')}, Rückblick ab Tag {(rb.get('engine_start') or 0) // TAG - g0}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _bremse_dateien(ok):
    """Lösen der Bremse über Dateien wie der Button im Reiter (seit 23.94): nur bei gesetzter Bremse, einmal, vorgemerkt bis zur
    nächsten Prüfung um 00:30 UTC (der Stand zeigt die Vormerkung, die Bremse bleibt bis dahin), danach gelöst mit neuem Höchststand."""
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="engine_probe_b_")
    alt = dict(_DIENST)
    try:
        pr = probe_dateien(tmp, bremse=True)
        db, store, jetzt = pr["db"], pr["store"], pr["jetzt"]
        probe_laufen(pr)
        K0 = (stand_lesen(db).get("konto") or {})
        klick = jetzt + 120
        a1 = bremse_loesen(db, jetzt=klick)
        d1 = stand_lesen(db); K1 = d1.get("konto") or {}
        a2 = bremse_loesen(db, jetzt=klick + 60)
        con = verbinden(engine_pfad(db))
        n_ev = len(meta(con, "bremse_ereignisse", []) or []); con.close()
        w = K1.get("loesen_wirksam")
        txt1 = text(d1)
        _DIENST.update({"puls": 0, "labor_t": None})
        r = takt_schritt(db, labor_t=None, jetzt=(w or 0) + 600, store=store)
        d2 = stand_lesen(db); K2 = d2.get("konto") or {}
        gel = [e for e in d2.get("protokoll") or [] if e.get("sid") == "engine" and e.get("neu") == "läuft"]
        a3 = bremse_loesen(db, jetzt=(w or 0) + 700)
        ok("Bremse lösen über Dateien (Button): nur bei gesetzter Bremse und nur einmal; bis zur nächsten Prüfung um 00:30 UTC "
           "vorgemerkt (Bremse noch gesetzt, im Bericht genannt), dort gelöst mit dem Kontostand als neuem Höchststand",
           K0.get("bremse") is True and K0.get("loesen_vorgemerkt") is None and a1.get("ok") is True
           and K1.get("bremse") is True and K1.get("loesen_vorgemerkt") == klick and w == ((klick - PRUEF_S) // TAG + 1) * TAG + PRUEF_S
           and a1.get("wirksam") == w and a2.get("ok") is False and "schon vorgemerkt" in a2.get("msg", "") and n_ev == 1
           and "gelöst am" in txt1 and r.get("neu") is not None and K2.get("bremse") is False and K2.get("loesen_vorgemerkt") is None
           and bool(gel) and gel[0]["ts"] == w and abs(K2.get("hoch", 0) - max(K2.get("kapital", 0), K1.get("kapital", 0))) < 1
           and a3.get("ok") is False and "nicht gesetzt" in a3.get("msg", ""),
           f"vorher {K0.get('bremse')}/{K0.get('loesen_vorgemerkt')}, Klick {a1.get('ok')}, vorgemerkt {K1.get('loesen_vorgemerkt')} "
           f"wirksam {w}, zweiter {a2.get('ok')}, Einträge {n_ev}, danach Bremse {K2.get('bremse')}, gelöst {[e['ts'] for e in gel]}, "
           f"Höchststand {K2.get('hoch')} Konto {K2.get('kapital')}")
    finally:
        _DIENST.clear(); _DIENST.update(alt)
        shutil.rmtree(tmp, ignore_errors=True)


def _versionswechsel(ok):
    """Neue Regelversion im Labor nach dem Start des Kontos: die alte Kennung endet, ihre übernommenen Trades bleiben, das Protokoll stimmt."""
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="engine_probe_v_")
    try:
        pr = probe_dateien(tmp, wechsel=True)
        start, r1, r2, r3 = probe_laufen(pr)
        d = stand_lesen(pr["db"])
        S = {s["sid"]: s for s in d.get("strategien") or []}
        K = d.get("konto") or {}
        ende = (G0T + 80) * TAG + 14 * 3600
        beendet = [e for e in d.get("protokoll") or [] if e["sid"] == "magnet@alt" and e["neu"] == "beendet"]
        alt_tr = [x for x in K.get("letzte") or [] if x["sid"] == "magnet@alt" and x["eroeffnet"] < ende]
        kp = kopf(pr["db"]) or {}
        ok("Neue Regelversion nach dem Start: die alte Kennung endet an der ersten Prüfung danach („beendet“), ihre übernommenen Trades "
           "bleiben im Konto, das Protokoll stimmt; die neue Kennung beginnt beobachtet und zählt als Kandidat",
           (S.get("magnet@alt") or {}).get("engine_zustand") == "beendet" and (S.get("magnet@alt") or {}).get("version") == "früher"
           and (S.get("magnet@neu") or {}).get("engine_zustand") == "beobachtet" and bool(beendet)
           and beendet[0]["ts"] == (G0T + 81) * TAG + PRUEF_S and K.get("uebernommen", 0) > 0 and K.get("netto", 0) > 0
           and len(alt_tr) == len(K.get("letzte") or []) > 0 and (r2.get("abweichung") or {}).get("gleich") is True
           and kp.get("n") == 2 and kp.get("aktiv") == 0 and d.get("fruehere") == 1,
           f"Zeilen {sorted((k, v.get('engine_zustand')) for k, v in S.items())}, übernommen {K.get('uebernommen')}, netto "
           f"{K.get('netto')}, Abgleich {r2.get('abweichung')}, Kopf {kp.get('n')}/{kp.get('aktiv')}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _synthetisch(rng, R, T, lam, sig, netto, bias=0.0, h=4.0, netto_tag=None, lam_tag=None, gruppe=1, g0=G0T, phase=None):
    """Tagesreihen wie die Simulation (sim3.welt3): je Trade Student-t-Ränder (ν = 3), Schwankungsballung, Richtung auf die realisierte
    Marktbewegung (Anteil Long (1 + bias)/2), Monatsart aus derselben Bewegung je Kalendermonat; ein Tag ist 23 h nach seinem Ende
    vollständig. Rückgabe in USD bei 10.000 USD je Trade (1 % = 100 USD). phase=(a, b): Abwärtsphase an den Tagen a bis b − 1."""
    lam_rows = np.broadcast_to(np.asarray(lam, dtype=float), (R,))
    G = R // gruppe
    phi = 0.97
    e = rng.standard_normal((G, T)); lv = np.empty((G, T)); lv[:, 0] = 0.4 * e[:, 0]
    for t in range(1, T):
        lv[:, t] = phi * lv[:, t - 1] + 0.4 * math.sqrt(1 - phi ** 2) * e[:, t]
    v = np.exp(lv); v /= np.sqrt(np.mean(v ** 2))
    st = np.empty((G, T), dtype=np.int8); st[:, 0] = rng.integers(-1, 2, G)
    sw = rng.random((G, T)) < 1 / 60; nx = rng.integers(1, 3, (G, T))
    for t in range(1, T):
        st[:, t] = np.where(sw[:, t], ((st[:, t - 1] + 1 + nx[:, t]) % 3) - 1, st[:, t - 1])
    if phase is not None:
        st[:, phase[0]:phase[1]] = -1
    mr = st * 0.4 + 3.0 * v * rng.standard_normal((G, T))
    v = np.repeat(v, gruppe, axis=0); mrr = np.repeat(mr, gruppe, axis=0)
    lam_m = lam_rows[:, None] * (np.asarray(lam_tag, dtype=float)[None, :] if lam_tag is not None else np.ones((1, T)))
    n = rng.poisson(lam_m)
    tot = int(n.sum())
    eps = rng.standard_t(3, tot) / math.sqrt(3.0)
    dirs = np.where(rng.random(tot) < (1 + bias) / 2, 1.0, -1.0)
    flat = n.ravel(); idx = np.repeat(np.arange(flat.size), flat)
    se = np.bincount(idx, weights=eps, minlength=flat.size).reshape(R, T)
    Dm = np.bincount(idx, weights=dirs, minlength=flat.size).reshape(R, T)
    sk = netto if netto_tag is None else np.asarray(netto_tag, dtype=float)[None, :]
    y = n * sk + Dm * mrr * (h / 24) + sig * v * se
    tage = np.arange(g0, g0 + T)
    mon = np.array([monat_nr(g) for g in tage])
    art = np.zeros((G, T), dtype=int); bek = np.full(T, np.inf)
    for m in np.unique(mon):
        sel = mon == m
        ende = int(tage[sel].max())
        if monat_nr(ende + 1) != m:
            bek[sel] = (ende + 1) * TAG
            art[:, sel] = np.where(mr[:, sel].sum(axis=1) > 0, 1, -1)[:, None]
    art = np.repeat(art, gruppe, axis=0)
    C = np.where(n > 0, (tage[None, :] + 1.0) * TAG + 23 * 3600, 0.0)
    return y * 100.0, n.astype(float), C, art, bek


def _synth_laufen(y, n, C, art, bek, g0=G0T):
    R, T = y.shape
    A = Abspielen(y, n, C, np.full(R, g0), g0, None, art, bek)
    for D in range(g0, g0 + T):
        A.pruefen(D, D * TAG + PRUEF_S)
        A.tag_abschliessen(D)
    return A


MIX_34 = (30.4, 20.8, 18.6, 18.5, 18.5, 14.3, 12.6, 12.6, 11.9, 11.6, 11.3, 10.8, 10.5, 8.7, 8.5, 4.5, 4.5, 4.1, 3.8, 3.8, 3.2, 3.1, 2.6,
          2.4, 2.4, 1.7, 1.6, 1.3, 1.3, 1.0, 0.6, 0.6, 0.4, 0.06)       # Trades je Tag der 34 Kandidaten (Bericht 28.10.2026)


def _statistik_pruefungen(ok, schnell=False):
    """Nullprobe, Positivkontrolle, Rückkehr, Ruhe und Phase -- synthetisch, mit dem Code dieser Datei (Konzept 9)."""
    R = 100 if schnell else 300
    T = 735
    rng = np.random.default_rng(241)
    tage = np.arange(T)
    welten = 12 if schnell else 30
    y, n, C, art, bek = _synthetisch(rng, 34 * welten, T, np.tile(MIX_34, welten), 1.0, 0.0, gruppe=34)
    A = _synth_laufen(y, n, C, art, bek)
    auf = (A.erst_auf >= 0).reshape(welten, 34).sum(axis=1)
    pnl = np.where(A.aktiv_tage, y, 0.0).sum(axis=1).reshape(welten, 34).sum(axis=1) / 100.0
    ok(f"Nullprobe: 34 Strategien mit netto 0 und echter Häufigkeit, ein Markt je Welt ({welten} Welten, zwei Jahre) → im Mittel "
       "höchstens 0,5 grundlose Aufnahmen je Welt, Ergebnis im Mittel nicht unter −5 Punkten (Simulation 0,27 und −1,7)",
       auf.mean() <= 0.5 and pnl.mean() >= -5.0, f"Aufnahmen {_de(auf.mean(), 2)} je Welt (Welten mit ≥ 1: {int((auf > 0).sum())}), "
       f"Ergebnis {_de(pnl.mean(), 1)} Punkte")
    y, n, C, art, bek = _synthetisch(rng, R, T, 3, 1.0, 0.0, netto_tag=np.where(tage < 180, 0.30, -0.15))
    A = _synth_laufen(y, n, C, art, bek)
    erst = A.erst_auf[A.erst_auf >= 0]
    dauer = []
    for i in np.nonzero(A.aktiv_tage[:, 180])[0]:
        w_ = np.nonzero(~A.aktiv_tage[i, 180:])[0]
        dauer.append(int(w_[0]) if w_.size else T - 180)
    med_auf = float(np.median(erst)) if erst.size else float("nan"); med_p = float(np.median(dauer)) if dauer else float("nan")
    ok("Positivkontrolle: netto +0,30 % je Trade aufgenommen (Median höchstens 80 Tage); nach dem Ende des Vorsprungs (netto −0,15 %) "
       "pausiert (Median höchstens 30 Tage)", erst.size >= 0.9 * R and med_auf <= 80 and med_p <= 30,
       f"aufgenommen {erst.size}/{R}, Median Tag {_de(med_auf, 0)}; Pause nach {_de(med_p, 0)} Tagen ({len(dauer)} aktiv am Tag 180)")
    y, n, C, art, bek = _synthetisch(rng, R, T, 3, 1.0, 0.0, netto_tag=np.where(tage < 365, -0.30, 0.30))
    A = _synth_laufen(y, n, C, art, bek)
    zur = np.array([any(d >= 365 for d in A.auf_tage[i]) for i in range(R)])
    y, n, C, art, bek = _synthetisch(rng, R, T, 3, 1.0, 0.0, netto_tag=np.where(tage < 180, 0.30, np.where(tage < 450, -0.30, 0.30)))
    A2 = _synth_laufen(y, n, C, art, bek)
    zur2 = np.array([any(d >= 450 for d in A2.auf_tage[i]) for i in range(R)])
    war = np.array([any(d < 450 for d in A2.pause_tage[i]) for i in range(R)])
    ok("Rückkehr: nach einem Jahr −0,30 % im Jahr +0,30 % aufgenommen (mindestens 95 %); gut – schlecht (pausiert) – gut (mindestens 90 %)",
       zur.mean() >= 0.95 and zur2.mean() >= 0.90, f"{_de(zur.mean() * 100, 1)} % / {_de(zur2.mean() * 100, 1)} % "
       f"(in der schlechten Zeit pausiert: {_de(war.mean() * 100, 0)} %)")
    ruhe = np.where((tage >= 300) & (tage < 420), 0.1, 1.0)
    y, n, C, art, bek = _synthetisch(rng, R, T, 3, 1.0, 0.30, lam_tag=ruhe)
    A = _synth_laufen(y, n, C, art, bek)
    vorher = A.aktiv_tage[:, 299]
    pausiert = vorher & ~A.aktiv_tage[:, 425]
    ok("Ruhe: eine gute Strategie mit 120 ruhigen Tagen (ein Zehntel der Trades) pausiert in höchstens 5 %",
       vorher.mean() >= 0.8 and pausiert.sum() <= 0.05 * max(vorher.sum(), 1),
       f"vorher aktiv {_de(vorher.mean() * 100, 0)} %, in der Ruhe pausiert {int(pausiert.sum())}")
    y, n, C, art, bek = _synthetisch(rng, R, T, 1, 2.0, 0.15, bias=0.8, h=24.0, phase=(200, 320))
    A = _synth_laufen(y, n, C, art, bek)
    ok("Phase: eine gute Long-lastige Strategie (24 h, netto +0,15 %) in einer 120-Tage-Abwärtsphase heißt nicht „gescheitert“ "
       "(höchstens 2 % der Welten)", (A.erst_fail >= 0).mean() <= 0.02, f"{_de((A.erst_fail >= 0).mean() * 100, 1)} %")


def selbsttest(schnell: bool = False) -> list:
    erg: list = []

    def ok(name, bed, info=""):
        erg.append((name, bool(bed), str(info)[:300]))

    for teil in (_hand_pruefungen, _regel_pruefungen, _konto_pruefungen, _ende_zu_ende, _versionswechsel, _bremse_dateien,
                 lambda o: _statistik_pruefungen(o, schnell)):
        try:
            teil(ok)
        except Exception as e:  # noqa: BLE001 -- eine Ausnahme ist ein roter Befund, kein Abbruch
            import traceback
            ok("Ausnahme im Selbsttest", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-300:])
    return erg


def mutationen_pruefen() -> list:
    """Jede Mutation muss mindestens eine Prüfung des (schnellen) Selbsttests rot machen; vorher muss er ohne Mutation grün sein."""
    global _MUT
    _MUT = None
    basis = [n for n, g, _ in selbsttest(schnell=True) if not g]
    if basis:
        return [("(ohne Mutation)", False, basis)]
    aus = []
    for m in MUTATIONEN:
        _MUT = m
        try:
            rot = [n for n, g, _ in selbsttest(schnell=True) if not g]
        finally:
            _MUT = None
        aus.append((m, bool(rot), rot))
    return aus


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Trading Engine (U241): Auswahl belegter Strategien des TradeLabors, Papierkonto -- liest nur")
    ap.add_argument("--db", default=None, help="Hauptdatenbank (hl_liq.db); engine.db liegt daneben")
    ap.add_argument("--stand", action="store_true", help="gespeicherter Stand (sonst neu gerechnet)")
    ap.add_argument("--rueckblick", action="store_true", help="die Regeln ab dem Start des Labors (beschreibend)")
    ap.add_argument("--bremse-loesen", action="store_true", help="Bremse lösen (Entscheidung des Nutzers)")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--schnell", action="store_true", help="Selbsttest wie bei den Mutationen (kleinere synthetische Proben)")
    ap.add_argument("--mutationen", action="store_true")
    a = ap.parse_args(argv)
    if a.selbsttest:
        t0 = time.time()
        erg = selbsttest(schnell=a.schnell)
        print("Trading Engine (U241) -- Selbsttest ohne Netz" + (" (schnell)" if a.schnell else ""))
        for n, g, info in erg:
            print(("ok    " if g else "ROT   ") + n + ("  -- " + info if info else ""))
        rot = [n for n, g, _ in erg if not g]
        print(("Selbsttest bestanden: " if not rot else "Selbsttest ROT: ") + f"{len(erg) - len(rot)} von {len(erg)} ({time.time() - t0:.0f} s)")
        return 1 if rot else 0
    if a.mutationen:
        t0 = time.time()
        aus = mutationen_pruefen()
        for m, rot, welche in aus:
            print(("rot       " if rot else "NICHT ROT ") + m + (f" ({MUTATIONEN[m]})" if m in MUTATIONEN else "")
                  + (" — " + "; ".join(w[:70] for w in welche[:2]) if welche else ""))
        print(f"{sum(1 for _, r, _ in aus if r)} von {len(aus)} Mutationen rot ({time.time() - t0:.0f} s)")
        return 0 if aus and aus[0][0] != "(ohne Mutation)" and all(r for _, r, _ in aus) else 1
    if not a.db:
        ap.error("--db fehlt (Pfad der Hauptdatenbank)")
    if a.bremse_loesen:
        print(bremse_loesen(a.db)["msg"])
        return 0
    if a.rueckblick:
        try:
            d = rechnen(a.db, rueckblick=True)
        except (sqlite3.Error, OSError) as e:
            print(f"★ Trading Engine (U241) · Rückblick\nFehler beim Lesen: {type(e).__name__}: {e}")
            return 1
        d.pop("_protokoll_voll", None)
        print(text(d))
        return 0
    d = stand_lesen(a.db)
    if not d.get("strategien") and d.get("ok", True):
        try:
            d2 = rechnen(a.db)
        except (sqlite3.Error, OSError) as e:
            d2 = {"ok": False, "fehler": f"{type(e).__name__}: {e}"}
        d2.pop("_protokoll_voll", None)
        if d2.get("strategien") or d2.get("hinweis") or not d2.get("ok", True):
            d = d2
    print(text(d))
    return 0


if __name__ == "__main__":
    sys.exit(main())
