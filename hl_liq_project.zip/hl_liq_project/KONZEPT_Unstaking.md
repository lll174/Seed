# KONZEPT Unstaking (U254, U255) — wann wird gestaktes ETH frei, und folgt darauf ein Kursrückgang?

Stand 16.11.2026 (Fable 5.2). Anlass: Nachricht des Nutzers vom 14.11.2026 19:57 — „wenn sehr große Mengen Ethereum vom Staking
abgerufen werden, [kommt] es häufig zu signifikanten Kursrückgängen … Prüfe, ob diese Daten bereits im Projekt erfasst werden und
erstelle einen Indikator in den Cockpit hinein, welcher einen Termin nennt, wann größere Mengen unstaked werden.“
**Status: Stufe 1 gebaut mit Paket 23.100 (U254): Daten und Anzeige; der Abruf vom Pi aus gelingt (Debug 145 vom 15.11.2026).
Stufe 2 (U255): Die Prüfung ist am 15.11.2026 auf dem Pi gelaufen -- Urteil „nicht belegt“ für die Wellen bis 25.10.2026 (Abschnitt 6b;
Regeln in 6, Klarstellungen in 6a). Die Tagesdatei der Quelle endet am 25.10.2026; seit Paket 23.102 führt das Projekt eine eigene
Tagesreihe aus dem Knoten (Abschnitt 3a); seit Paket 23.103 sichert das tägliche Backup `staking.db` mit (Abschnitt 3b); seit Paket
23.104 zeigt das Cockpit den Verlauf der Schlange und des ETH-Kurses mit den Wellen der Prüfung (Abschnitt 4a). Seit Paket 23.106 ist
die zweite Prüfung vorab festgelegt -- nur neue Wellen der eigenen Messung, einmal gerechnet nach acht Wellen (Abschnitt 6c).
Gerechnet ist sie nicht.**

---

## 0. Kurzfassung

- **Bestand:** Das Projekt erfasste bisher keine Staking-Daten (Suche im ganzen Paket nach Staking, Validator, Warteschlange: nichts).
- **Der Termin ist keine Prognose, sondern steht in der Kette.** Wer ETH aus dem Staking abzieht, bekommt vom Protokoll einen festen
  Zeitpunkt zugeteilt. Das neue Modul `hl_staking.py` liest diese Zeitpunkte und bildet daraus einen Kalender „frei ab“.
- **Im Cockpit (nur ETH):** Karte „Unstaking“ mit Summe, „alles frei bis“, der nächsten großen Freigabe als Termin, Kalender je Tag,
  größtem Abzieher und der Gegenseite; dazu eine Zeile mit dem Termin direkt unter dem Kernsatz. Klasse B (gemessen): blau, ohne
  Warnfarbe.
- **Nicht belegt ist die zweite Hälfte der Beobachtung** — dass auf große Abzüge Kursrückgänge folgen. Die vorab festgelegte Prüfung
  (Abschnitt 6) lief am 15.11.2026: 18 Wellen seit Mai 2023, ETH gegen BTC danach im Mittel 1,0 Prozentpunkte schwächer als sonst
  (14 von 18 Fällen negativ), vom Zufall nicht zu unterscheiden (p 0,21; Nachweisgrenze 3,5 %). **Das Urteil reicht bis zum
  25.10.2026; die Welle vom November 2026 ist nicht in den Daten** (Abschnitte 3a und 6b). Die Karte nennt das Urteil als Text. Erst
  ein bestandener Test macht aus dem Messwert ein Warnsignal und einen Teil der Prognose.
- **Die Tagesdatei der Quelle steht seit 25.10.2026.** Stand und Kalender kommen vom Knoten und sind davon nicht betroffen; die
  Gegenseite fehlt. Seit 23.102 führt das Projekt eine eigene Tagesreihe aus dem Knoten (Abschnitt 3a).
- **Verlauf (seit 23.104):** Die Karte „Unstaking · Verlauf“ im Cockpit zeigt je Tag seit Mai 2023 die Schlange der Abzüge und den
  ETH-Kurs in zwei Feldern, mit den 18 Wellen der Prüfung als Marken (Abschnitt 4a). Gemessen -- der Verlauf allein belegt nichts.
  Ab der eigenen Messung zeigt sie seit 23.106 die angemeldeten Abzüge (Schlange + Sperrfrist + Teilabzüge).
- **Zweite Prüfung (festgelegt mit 23.106, Abschnitt 6c):** Sie zählt nur neue Wellen der eigenen Messung, gemessen am Zuwachs der
  angemeldeten Abzüge, und wird einmal gerechnet, sobald acht Wellen bewertet sind -- bei gut fünf Wellen im Jahr in rund anderthalb
  Jahren. Erwartung: wieder „nicht belegt“, außer der Nachteil ist groß (rund 5 %-Punkte). Bis dahin zeigt das Projekt neue Wellen
  mit Zähler, aber ohne Kursfolgen. Eine neue Welle kann frühestens am 01.12.2026 beginnen.
- **Die Kette ändert voraussichtlich ihr Kontingent** (EIP-8061 im Upgrade Glamsterdam; Hauptnetz am 16.11.2026 noch ohne Termin):
  rund 247.000 statt 57.600 ETH Austritte am Tag. Deshalb misst die zweite Prüfung nicht die Schlange, sondern die angemeldeten
  Abzüge (Abschnitt 6c). Was im Modul sonst anzupassen ist, steht in Abschnitt 8 (U262).
- **Debug 145** (★ Unstaking: Stand als Text) fragt beide Quellen selbst ab und zeigt, ob der Abruf vom Pi aus gelingt. **Debug 146**
  ist der Selbsttest. **Debug 147** (★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?) ist die Prüfung, **Debug 148** ihr
  Selbsttest.

## 1. Bestand im Projekt

Geprüft am 14.11.2026 im Paket 23.99: kein Modul, keine Tabelle und kein Abruf zu Staking, Validatoren oder Warteschlangen der
Beacon-Chain. Die Makro-Daten (ETF-Flüsse, Stablecoins) und die Börsenflüsse sind etwas anderes. Die Daten sind neu zu erfassen.

## 2. Wie Unstaking bei Ethereum abläuft

Quelle der Regeln: Konsens-Spezifikation „Electra“ (https://ethereum.github.io/consensus-specs/electra/beacon-chain/, gelesen
14.11.2026).

1. **Anmeldung.** Ein Validator meldet den Austritt an. Die Kette teilt ihm sofort eine Austritts-Epoche zu (`exit_epoch`).
2. **Warteschlange.** Je Epoche (384 s) dürfen höchstens 256 ETH das Staking verlassen (`MAX_PER_EPOCH_ACTIVATION_EXIT_CHURN_LIMIT`).
   Das sind 57.600 ETH am Tag. Ist mehr angemeldet, verschiebt sich der Austritt nach hinten.
3. **Sperrfrist.** Nach dem Austritt dauert es 256 Epochen, rund 27,3 Stunden, bis das ETH ausgezahlt werden darf
   (`withdrawable_epoch`). Diesen Zeitpunkt nennt das Modul **„frei ab“**.
4. **Auszahlung.** Vollabzüge zahlt der Auszahlungslauf aus: 16 Auszahlungen je Block, der Reihe nach über alle Validatoren. Eine
   Runde dauert bei 796.121 Validatoren 6,9 Tage (so zeigt es validatorqueue.com am 14.11.2026 als „Sweep Delay“). Ein Vollabzug kommt
   also zwischen „frei ab“ und knapp 7 Tage danach auf dem Konto an.
5. **Teilabzüge** (seit Mai 2025 möglich, für Validatoren mit bis zu 2.048 ETH): Sie durchlaufen dieselbe Begrenzung, bekommen
   ebenfalls ein „frei ab“ und werden dann sofort ausgezahlt (bis zu 8 je Block), ohne den Auszahlungslauf.
6. **Zusammenlegungen** sehen in der Liste der Kette aus wie Abzüge: Der Quell-Validator bekommt eine Austritts-Epoche. Sein ETH
   geht aber an einen anderen Validator und bleibt gestakt. Sie müssen abgezogen werden — am 14.11.2026 waren das 194.432 ETH neben
   251.274 ETH echter Abzüge.

Was die Kette nicht zeigt: ob frei gewordenes ETH an den Markt kommt. Ein Abzug kann ein Wechsel des Betreibers sein, eine
Vorsichtsmaßnahme oder der erste Schritt zu einem neuen Staking.

## 3. Datenquellen

| Quelle | Was | Schlüssel | Rolle |
|---|---|---|---|
| Beacon-Knoten, Standard-API (Voreinstellung `https://ethereum-beacon-api.publicnode.com`) | jeder angemeldete Abzug mit seinem Zeitpunkt | nein | Hauptquelle, stündlich |
| Tagesdatei von validatorqueue.com (`historical_data.json` im GitHub-Projekt `etheralpha/validatorqueue-com`) | Warteschlangen je Tag seit 21.05.2023, Zahl der Validatoren | nein | Rückblick, Gegenseite, Ersatz; alle 6 Stunden. **Endet am 25.10.2026** (Abschnitt 3a) |
| Eigene Tagesreihe (Tabelle `st_tag_knoten`, seit 23.102) | erster Stand des Knotens je UTC-Tag: Schlange, Wartezeit, Sperrfrist, Teilabzüge, Zusammenlegungen | — | Rückblick ab dem Einspielen von 23.102; Grundlage einer späteren Prüfung |

Fünf Fragen an den Knoten je Lauf: Kopf der Kette (`/eth/v1/beacon/headers/head`), Zusammenlegungen
(`…/states/finalized/pending_consolidations`), Validatoren mit Status `active_exiting` und `exited_unslashed`
(`…/states/finalized/validators?status=…`), Teilabzüge (`…/pending_partial_withdrawals`).

- **Sicherungen.** Liegt der Kopf des Knotens mehr als 150 Slots (30 Minuten) neben der Uhr, gilt sein Stand nicht: Seine
  Zeitpunkte wären falsch (Knoten kommt nicht mit, oder die Zeitrechnung der Kette wurde geändert). Ohne die Liste der
  Zusammenlegungen gibt es keinen Stand vom Knoten: Die Summe wäre zu hoch. Fehlen nur Teilabzüge oder die Sperrfrist-Liste, gilt der
  Stand mit Hinweis.
- **Ersatz.** Antwortet der Knoten nicht und ist die Tagesdatei höchstens 2 Tage alt, zeigt das Cockpit einen Kalender, der aus der
  Länge der Schlange geschätzt ist (57.600 ETH je Tag, dann die Sperrfrist) — gekennzeichnet als Schätzung, ohne Teilabzüge und ohne
  Abzieher. Sonst zeigt es keinen Wert und nennt die Gründe.
- **Eigener Knoten.** Die Umgebungsvariable `HL_STAKING_KNOTEN` setzt andere Knoten (mehrere mit Komma, der Reihe nach).
  `HL_STAKING=0` schaltet den Abruf ab.
- **Verworfen:** die Schnittstelle von beaconcha.in. Sie liefert dieselben Größen fertig gerechnet, verlangt aber einen Schlüssel;
  der kostenlose Zugang endet nach 30 Tagen (https://docs.beaconcha.in/, gelesen 14.11.2026).
- **Abruf über das Netz:** aus der Sandbox nicht prüfbar. **Bewiesen am 15.11.2026 mit Debug 145 auf dem Pi:** fünf Fragen an den
  öffentlichen Knoten, alle HTTP 200 (Kopf 0,7 kB; Zusammenlegungen 313,9 kB mit 6.045 Einträgen; Schlange 3,0 MB mit 6.538;
  Sperrfrist 1,6 MB mit 3.429; Teilabzüge 7,8 kB mit 94), zusammen 4,9 MB in 1,5 s.
- **Was die Tagesdatei ist** (laut ihrer Beschreibung, am 14.11.2026 nachgelesen): Die Quelle misst alle rund 15 Minuten und hält
  je UTC-Tag die erste Messung fest. Bis zum 06.05.2025 zählte die Kette die Schlangen in Validatoren; die Datei trägt für diese Zeit
  Validatoren × 32 als ETH (Umrechnung der Quelle; die Zeilen vom Mai 2023 sind durch 32 teilbar). Vom 07.05. bis 21.05.2025 stehen
  Validatoren statt ETH in den Feldern -- diese 15 Tage nutzt das Projekt nicht. Einzelne Tage fehlen; die Berichte zählen sie.

Last: Bei einer Schlange von 250.000 ETH sind das stündlich wenige MB (gepackt übertragen). Die Antwort wird in Stücken gelesen; im
Speicher bleibt je Validator nur ein kleiner Eintrag, nicht der Text der Liste. Ein ganzer Abruf am Knoten darf höchstens 150
Sekunden dauern, die Tagesdatei 60.

## 3a. Befund vom 15.11.2026: Die Tagesdatei steht — eigene Tagesreihe (Paket 23.102)

**Was Debug 145 auf dem Pi zeigte (15.11.2026, 03:23 UTC):** Der Knoten antwortet (fünf Fragen, alle HTTP 200, zusammen 4,9 MB in
1,5 s). Die Tagesdatei kommt auch an (342,6 kB, 1.243 Einträge) — ihr letzter Tag ist aber der **25.10.2026**. Seit drei Wochen hat sie
keinen neuen Eintrag. Die Ursache kenne ich nicht: Auf validatorqueue.com steht inzwischen „Data provided by pectrified.com“; die
Beschreibung im GitHub-Projekt nennt weiter beaconcha.in und kein Ende der Datei. Eine andere Tagesquelle ohne Schlüssel habe ich
nicht gefunden (gesucht am 15.11.2026).

**Mein Fehler dabei:** Am 14.11. hatte ich die Datei als laufend angenommen und das nicht geprüft. Der Bericht der Prüfung (Debug 147,
Paket 23.101) schrieb deshalb, vom 01. bis 14.11.2026 habe es „nach der Regel keine Welle“ gegeben. Das war falsch: Für diese Tage gab
es keine Daten. Seit 23.102 unterscheidet der Bericht „keine Welle“ von „nicht in den Daten“.

**Folgen, und was 23.102 daran ändert**
- **Gegenseite** (ETH, das gestakt werden soll): kommt nur aus der Tagesdatei und fehlt deshalb. Die Karte ließ die Zeile bisher still
  weg; jetzt sagt sie, dass der Wert fehlt und bis wann die Quelle reicht.
- **Dauer des Auszahlungslaufs:** rechnet mit der Zahl der Validatoren aus der Tagesdatei (819.745 am 25.10.2026 → bis zu 7,1 Tage).
  Die Zahl ändert sich langsam. Sie gilt jetzt 120 statt 30 Tage als brauchbar (bis 21.02.2027); Karte und Bericht nennen den Tag, von
  dem sie stammt. Mit 30 Tagen wäre die Angabe am 24.11.2026 weggefallen.
- **Ersatzkalender** (wenn der Knoten ausfällt): entfällt, solange die Tagesdatei älter als 2 Tage ist. Dann zeigt die Karte keinen
  Wert und nennt den Grund.
- **Abgleich Knoten gegen Tagesdatei** in Debug 145: nur noch mit frischer Tagesdatei. Vorher verglich der Bericht den Stand von heute
  mit einem drei Wochen alten Wert und nannte das „nur ungefähr gleich“.
- **Rückblick und Prüfung der Kursfolge** enden am 25.10.2026. Bericht und Karte sagen das jetzt („Wellen bis 25.10.2026“).

**Eigene Tagesreihe (Tabelle `st_tag_knoten` in `staking.db`, seit 23.102).** Je UTC-Tag hält das Modul den ersten Stand des Knotens
fest: Schlange der Vollabzüge (noch nicht ausgetreten; ohne Sperrfrist, ohne Zusammenlegungen), ihre Wartezeit bis zum letzten
zugeteilten Austritt, dazu getrennt Sperrfrist, Teilabzüge, Zusammenlegungen und „alles frei bis“. Damit die erste Messung am
Tagesbeginn liegt, fragt der Dienst den Knoten zwei Minuten nach Mitternacht UTC einmal außer der Reihe; danach gilt wieder der
Stundentakt. Die Zeile trägt die Uhrzeit ihrer Messung. Debug 145 zeigt die letzten acht Tage.
- Die Reihe beginnt mit dem Einspielen von 23.102 -- auf dem Pi am 15.11.2026: erste Zeile 09:33 UTC, Schlange 160.003 ETH (3,4
  Tage), Sperrfrist 65.135 ETH, Teilabzüge 35.023 ETH, Zusammenlegungen 190.331 ETH (Debug 145). **Die Tage vom 26.10.2026 bis dahin
  fehlen und lassen sich aus dem Knoten nicht nachholen** (er zeigt nur den jetzigen Stand). Die Welle vom November 2026 (laut Berichten 06. bis 13.11.: 4.320 → 269.951 ETH) ist
  deshalb in keiner Reihe des Projekts.
- Die Reihe lässt sich nicht neu laden. Seit Paket 23.103 sichert das tägliche Backup `staking.db` deshalb mit (Abschnitt 3b).
- **Seit 23.106 (U259):** Misslingt der Abruf um 00:02 UTC, versucht der Dienst es alle 5 Minuten, bis die Zeile des Tages steht --
  bis 03:00 UTC; danach gilt wieder der Stundentakt. Eine Zeile gilt als „zu Tagesbeginn gemessen“, wenn ihre Messung vor 03:00 UTC
  liegt; nur solche Tage zählt die zweite Prüfung (Abschnitt 6c). Debug 145 zeigt je Zeile die Summe „angemeldet“ (Schlange +
  Sperrfrist + Teilabzüge), ihren Zuwachs gegen den Vortag (nur wenn beide Tage zu Tagesbeginn gemessen sind) und einen Vermerk an
  Zeilen, die zu spät am Tag gemessen wurden. Auf dem Pi am 16.11.2026: Zeile um 00:02 UTC, Schlange 147.225 ETH, Sperrfrist 65.951,
  Teilabzüge 35.047 -- angemeldet 248.223 ETH.

**Zweifel an der Zählweise der Tagesdatei.** In ihren letzten acht Tagen (18. bis 25.10.2026) fiel die Schlange an fünf von sieben
Tagen um 76.389 bis 121.960 ETH. Abzüge allein lassen höchstens 57.600 ETH am Tag zu; der Kalender des Knotens vom 15.11.2026 zeigt
diese Grenze (57.708 und 58.748 ETH an den vollen Tagen). Eine mögliche Erklärung: Die Datei zählt Zusammenlegungen mit. Sie haben
in der Kette ein eigenes Kontingent neben dem der Abzüge (Konsens-Spezifikation Electra). **Nicht geprüft** — es gibt keinen Tag mit
beiden Messungen. Was daraus folgt:
- Debug 145 zählt seit 23.102 im Rückblick die Tage seit 22.05.2025, an denen die Schlange der Tagesdatei um mehr als 60.480 ETH fiel
  (5 % über dem Tagesdurchsatz, als Abstand für die Uhrzeit der Messung). **Ergebnis vom Pi (15.11.2026, 09:33 UTC): an 19 von 510
  Tagen, am stärksten um 128.494 ETH am 27.06.2026.** Fünf der 19 Tage liegen in der letzten Woche der Datei; dort fiel die
  Schlange an jedem der sieben Tage, ohne Rücksprung -- ein Aussetzer der Quelle war es in dieser Woche nicht. Das stützt die
  Vermutung; bewiesen ist sie damit nicht. Für die übrigen 14 Tage zeigt die Zählung nicht, ob am Folgetag ein Rücksprung kam (dann
  wäre es ein Aussetzer gewesen, und der Rücksprung zählte in der Prüfung als Tag mit Zuwachs) -- zu klären vor einer zweiten
  Prüfung (U259). Seit 23.106 listet Debug 147 diese Tage einzeln mit den Mustern Zacke und Delle (Abschnitt 6c, „Befund am Rand“);
  das Ergebnis vom Pi steht noch aus.
- Für die Prüfung der Kursfolge heißt das: Einzelne der acht Wellen seit Mai 2025 könnten Zusammenlegungen gewesen sein, also kein
  ETH, das das Staking verlässt. Der Bericht nennt das als offenen Punkt.
- Ein einzelner Vergleichspunkt, Stunden auseinander: validatorqueue.com zeigte am Abend des 14.11.2026 Abzüge von 251.274 ETH und
  getrennt davon 194.432 ETH Zusammenlegungen. Der Knoten zeigte am 15.11. um 03:20 UTC 167.896 ETH in der Schlange, 227.280 ETH mit
  Sperrfrist und 193.499 ETH Zusammenlegungen. Die Zahl der Website liegt näher an „mit Sperrfrist“. Was die Tagesdatei bis zum
  25.10. zählte, sagt das nicht. Die eigene Reihe hält deshalb alle Teile getrennt fest; kommt die Tagesdatei wieder, zeigt Debug 145
  die drei Zählweisen des Knotens neben ihrem Wert.

## 3b. Sicherung von `staking.db` (Paket 23.103, U257)

**Warum:** In `staking.db` liegen zwei Dinge, die sich nicht neu laden lassen -- die eigene Tagesreihe aus dem Knoten (Abschnitt 3a)
und das gespeicherte Urteil der Prüfung (Abschnitt 6b). Ginge die Datei verloren, wäre die Reihe weg, und Debug 147 rechnete ein
zweites Urteil mit den dann vorhandenen Daten.

**Was 23.103 tut:** Das tägliche Backup des Recorders nimmt `staking.db` mit, wie die anderen Nebendatenbanken: Kopie über die
SQLite-Backup-API in einem Schritt (der Dienst des Dashboards darf währenddessen schreiben), Prüfung der Kopie, dann erst ersetzt sie
die vorige. Im Backup-Ordner liegen `staking_backup.db` und der vorige Stand `staking_backup.db.1`. Ist die Quelle beschädigt, bleibt
die gute Kopie liegen und der Fehler steht in `backup.json` (`staking_db_error`). Die Datei ist klein (wenige MB).

**Wann:** beim täglichen Backup -- es läuft, sobald das letzte gelungene 24 Stunden alt ist (nicht bei jedem Neustart des Recorders),
oder sofort mit „Jetzt sichern“ im Abschnitt System.

**Wo man es sieht:** **Debug 145** trägt die Zeile „Sicherung …“ mit Zeit, Größe und Ordner der Kopie. Ohne Kopie steht das da; ein
Fehler der Kopie steht mit seinem Wortlaut da und nennt die vorige; war die Datei im letzten Lauf nicht dabei, ist der Lauf
misslungen oder die Kopie älter als zwei Tage, steht es dabei. Den Ordner liest `hl_staking.py` aus der Hauptdatenbank (`meta`,
`backup_dir`; sonst wie der Recorder „dbbackup“ neben der Datenbank). Die Kachel „Letztes Backup“ zeigt nur die Hauptdatenbank.

**Wiederherstellen** (von Hand, wie bei den anderen Nebendatenbanken):
1. Dashboard-Dienst stoppen (`sudo systemctl stop hl-dashboard`) -- sein Faden „staking“ schreibt in die Datei.
2. Neben der Hauptdatenbank `staking.db-wal` und `staking.db-shm` löschen, falls vorhanden (sonst spielte SQLite alte Änderungen in
   die neue Datei).
3. `staking_backup.db` aus dem Backup-Ordner als `staking.db` neben die Hauptdatenbank kopieren.
4. Dienst starten. **Debug 145** zeigt die Tagesreihe, **Debug 147** das gespeicherte Urteil -- ohne neu zu rechnen.

**Grenzen:** Das Backup läuft einmal am Tag; verloren gehen können die Stundenstände seit der letzten Sicherung und höchstens die
Zeile der Tagesreihe von heute. Nach einem Zurückrollen auf ein Paket vor 23.103 bleibt `staking_backup.db` im Backup-Ordner liegen;
das alte Programm kennt sie nicht (es zeigt sie nicht an und nimmt sie bei einem Wechsel des Backup-Orts nicht mit).

## 4. Was gemessen und gezeigt wird — Schwellen fest und vorab

- **Angemeldet, noch nicht frei** = Vollabzüge (in der Schlange und in der Sperrfrist) + Teilabzüge, in ETH nach Kontostand;
  im Cockpit dazu der Wert in USD zum frischen Kurs.
- **Kalender „frei ab“** je UTC-Tag. Schon Fälliges zählt unter heute.
- **Alles Angemeldete frei bis** = spätester Zeitpunkt „frei ab“.
- **Große Freigabe** = die nächste Folge von UTC-Tagen mit jeweils mindestens **28.800 ETH** „frei ab“ (die Hälfte des
  Höchstdurchsatzes von 57.600 ETH). Das ist der Termin, den das Cockpit nennt.
- **Abzieher:** Vollabzüge je Auszahlungsadresse, genannt ab **10.000 ETH**, höchstens drei.
- **Gegenseite:** ETH, das darauf wartet, gestakt zu werden (Tagesdatei).
- **Frische:** Stand des Knotens höchstens 3 Stunden alt; Tagesdatei als Ersatz und für die Gegenseite höchstens 2 Tage zurück (eine
  ältere Gegenseite wird nicht gezeigt -- die Karte sagt dann, dass der Wert fehlt); die Dauer des Auszahlungslaufs aus der Zahl
  der Validatoren bis 120 Tage (sie ändert sich langsam; bis 23.101: 30 Tage), bei älterer Tagesdatei mit dem Tag der Zahl.
- **Farbe:** keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer Balken, Punkt).

Nicht enthalten: ETH, das schon frei ist und auf den Auszahlungslauf wartet; Abzüge aus Liquid-Staking-Pools, die ohne Austritt
eines Validators bedient werden; der genaue Auszahlungstag eines einzelnen Vollabzugs.

## 4a. Verlauf im Cockpit: Karte „Unstaking · Verlauf“ (Paket 23.104, U260)

**Anlass:** Am 15.11.2026 um 11:47 fragte der Nutzer nach dem Einspielen von 23.103: „Wo sehe ich den Chart mit dem Unstaking?“ Einen
Verlauf über die Zeit gab es nicht -- die Karte „Unstaking“ zeigt den Stand und die nächsten Tage als Balken. Auf die Frage, ob ein
Verlauf dazukommen soll, wählte er „Ja, bauen“.

**Was die Karte zeigt** (nur bei ETH, zwischen „Unstaking“ und „Kosten“; Klasse B, gemessen, ohne Warnfarbe):
- **Zwei Felder mit gemeinsamer Zeitachse**, je UTC-Tag: oben der ETH-Kurs in USD zu Beginn des Tages, unten die Schlange der Abzüge
  in ETH, ab null, als Linie mit Fläche. Bewusst keine zweite Skala in einem Feld: Zwei Skalen übereinander ließen sich so
  verschieben, dass jeder Zusammenhang zu sehen wäre.
- **Schlange:** bis zum Ende der Tagesdatei genau die Reihe, die die Prüfung liest (`schlange_lesen`, ohne 07.05.–21.05.2025); ab dem
  Beginn der eigenen Tagesreihe die Messung am Knoten -- seit 23.106 die **angemeldeten Abzüge, die noch nicht frei sind** (Schlange +
  Sperrfrist + Teilabzüge, ohne Zusammenlegungen; bis 23.105 nur die Schlange). Das ist die Größe, an der die zweite Prüfung neue
  Wellen misst (Abschnitt 6c); sie liegt höher als die Schlange allein. Feldname, Quellenzeile und Ablesezeile sagen, welche Größe ein
  Tag zeigt. Hat ein Tag beide, gilt die Tagesdatei. Die beiden Reihen werden nicht durch eine Linie verbunden.
- **Keine Daten:** Fehlt die Schlange drei Tage oder länger in Folge, steht dort eine graue Fläche (die ausgeschlossene Zeit im Mai
  2025; die Tage vom 26.10.2026 bis zum Beginn der eigenen Reihe). Über ein oder zwei fehlende Tage läuft die Linie durch.
- **Wellen:** Marken an den Falltagen A des gespeicherten Urteils (Abschnitt 6b: 18 Wellen). Sie werden nicht neu bestimmt.
- **Neue Wellen** der eigenen Messung (Regel aus Abschnitt 6c) tragen seit 23.106 einen offenen Kreis und eine eigene Nummer (N1 …).
  Ihr Text und ihre Zeile in der Liste nennen Tag und Zuwachs, aber keine Kursfolge -- die steht erst mit dem Urteil der zweiten
  Prüfung da. Die Legende zählt Wellen der Prüfung und neue Wellen getrennt. Der Unterschied liegt in der Form, nicht in der Farbe.
- **Ausschnitt:** 3 Monate (92 Tage), 1 Jahr (366 Tage) oder alles; beim Öffnen 1 Jahr.
- **Ablesen:** Antippen oder Ziehen im Bild zeigt den Tag mit Quelle, Schlange und Kurs; nahe einer Marke (12 px mit dem Finger, 5 px
  mit der Maus) rastet die Auswahl auf die Welle, und ihr Satz erscheint unter dem Bild. Die Tasten links und rechts wählen den
  Nachbartag (mit Umschalttaste sieben Tage).
- **Wellen als Liste** (aufklappbar): Nummer, Tag der Messung, Zuwachs, ETH über 7 Tage, ETH gegen BTC über 7 Tage -- dieselben
  Zahlen wie in Debug 147 (Log-Renditen in %).
- **Darunter:** der Satz zu den Wellen mit den Zahlen der Frage A des Urteils (Mittel nach den Wellen, Mittel aller Tage, Urteil mit
  p nach Holm), seit 23.106 ein Satz zur zweiten Prüfung mit ihrem Zähler („bisher x“) und dem frühesten Tag einer neuen Welle, die
  Quellen, die Zeiträume ohne Daten und der Satz „Gemessen, keine Vorhersage: Der Verlauf allein belegt keinen Zusammenhang.“

**Was der Verlauf nicht ist:** kein Beleg. Das Urteil der Prüfung bleibt „nicht belegt“ (Abschnitt 6b). Wer die Marken ansieht,
findet Wellen mit fallendem und mit steigendem Kurs danach; ob die fallenden häufiger sind, als der Zufall erwarten lässt, sagt nur
die Prüfung.

**Technik:** `hl_staking_studie.verlauf` liest die Reihen (Schlange, eigene Tagesreihe, ETH-Kurs zu Tagesbeginn über
`kurs_tagesbeginn` -- zwei Kerzen je Tag, derselbe Kurs wie `kurse_lesen` --, Fälle des gespeicherten Urteils); `hl_cockpit.py`
formt daraus die Antwort (`verlauf_bauen`: Lage je Tag, Rundung, Zeiträume ohne Daten, Texte) und liefert sie unter
`/cockpit/unstaking` (10 min im Zwischenspeicher des Dashboards; rund 24 kB für 1.275 Tage, gepackt rund 9 kB). Das Skript holt sie
nur bei ETH und höchstens alle 30 min. Nur lesen: kein Urteil, keine neue Welle, kein Eintrag in `staking.db`. **Debug 143** nennt
unter ETH den Umfang der Reihen, die Zeiträume ohne Daten, den letzten Tag mit einer Schlange und den Satz zu den Wellen.

**Farben:** Schlange `#388bfd`, Kurs `#bb8009`. Die beiden üblichen Farben des Cockpits (Blau `#58a6ff`, Gelb `#e3b341`) sind für
zwei Linien auf der dunklen Kartenfläche heller, als die Prüfregel für Diagrammfarben erlaubt; die genannten Töne sind die nächsten
dunkleren Stufen derselben Farben und bestehen die Prüfung (Helligkeit, Unterscheidbarkeit bei Farbsehschwäche, Kontrast zur
Fläche). Text trägt nie die Farbe einer Linie.

**Grenzen:**
- Die Tage vom 26.10. bis 14.11.2026 fehlen und bleiben grau; dort liegt die Welle, die den Anlass zu allem gab.
- An der Nahtstelle wechseln Quelle und Größe: bis 25.10.2026 die Schlange der Tagesdatei (Zählweise offen, Abschnitt 3a), ab
  15.11.2026 die angemeldeten Abzüge der eigenen Messung (Schlange + Sperrfrist + Teilabzüge). Ein Sprung an der Naht ist deshalb
  kein Abzug.
- Der Kurs ist der zu Beginn des UTC-Tags, nicht der jetzige (der steht im Kopf des Cockpits).
- Die Tage sind UTC-Tage.

## 5. Einordnung — was über Abzüge und Kurs bekannt ist

Bekannte Wellen aus Berichten (nicht systematisch geprüft, Quellen in Abschnitt 9):

| Zeit | Schlange | Anlass laut Berichten | Kurs im Umfeld |
|---|---|---|---|
| Juli 2025 | 1.920 → über 520.000 ETH in einer Woche | nach einem Kursanstieg von rund 160 % | Anstieg davor |
| September 2025 | Höchststand 2,67 Mio. ETH | — | — |
| Anfang Oktober 2026 | 166.000 → 850.736 ETH in drei Tagen | Sicherheitsvorfall bei MetaMask, vorsorgliche Austritte | — |
| 06.–13.11.2026 | 4.320 → 269.951 ETH | — | ETH in einer Woche −12,4 % auf 1.958 USD; ETF-Abflüsse 696 Mio. USD in acht Handelstagen |

Drei Lesarten sind möglich, und die Fälle oben passen zu verschiedenen:
1. **Abzug vor Verkauf** (die Beobachtung des Nutzers): große Abzüge kündigen Angebot an.
2. **Abzug als Folge:** Nach einem starken Anstieg (Juli 2025) oder während eines Rückgangs (November 2026) wird abgezogen. Dann
   läuft der Kurs voraus, nicht hinterher.
3. **Abzug ohne Verkauf:** Betreiberwechsel und Vorsichtsmaßnahmen (MetaMask) setzen kein ETH frei, das an den Markt soll.

Größenordnung: Das Protokoll gibt höchstens 57.600 ETH am Tag frei — beim Kurs vom 13.11.2026 rund 113 Mio. USD. Das liegt in der
Größe der täglichen ETF-Abflüsse dieses Monats (rund 87 Mio. USD je Handelstag). Zugleich warteten am 14.11.2026 mehr als dreimal so
viele ETH auf den Weg ins Staking (904.393) wie heraus (251.274).

## 6. Studie, vorab festgelegt (U255) — gebaut mit Paket 23.101, gerechnet am 15.11.2026 (Ergebnis in 6b)

Festgelegt am 14.11.2026, bevor die Tagesdatei mit Kursen zusammengeführt wurde. **Offenlegung:** Bekannt waren mir nur die vier
Wellen aus Abschnitt 5 und die dort genannten Kurse; eine Auswertung gab es nicht.

- **Daten.** Schlange der Abzüge je UTC-Tag aus der Tagesdatei (erste Messung des Tages), ab 21.05.2023. Ausgeschlossen: 07.05. bis
  21.05.2025 und Tage ohne Eintrag. Tagesschlüsse von ETH und BTC (UTC) aus den Kerzen, die der Ausblick nutzt.
- **Fall A — Anmeldung.** Tag d, an dem die Schlange gegen den Vortag um mindestens 57.600 ETH wächst (ein voller Tagesdurchsatz).
  Ein neuer Fall beginnt erst nach 14 Tagen ohne solchen Tag.
- **Fall B — Freigabe.** Der UTC-Tag, an dem das erste ETH der Welle frei wird: d − 1 + Wartezeit des Vortags + 27,3 Stunden,
  aufgerundet.
- **Zielgröße.** Log-Rendite von ETH minus der von BTC über 7 Tage ab dem Beginn des Falltags. So zählt nur, was ETH für sich
  verliert. Beschreibend daneben: ETH allein, 14 Tage, tiefster Stand im Fenster.
- **Test.** Mittel der Zielgröße nach den Fällen minus Mittel über alle Tage; einseitig (nach den Fällen niedriger). Nullverteilung
  durch Verschieben der Fallreihe gegen die Kursreihe im Kreis (alle Verschiebungen um mindestens 30 Tage). Zwei Hypothesen (A, B),
  Holm.
- **Urteil.** „Belegt“ nur mit p Holm < 0,05, mindestens 8 Fällen und gleichem Vorzeichen in beiden Hälften der Fälle. Mit weniger
  als 8 Fällen: „zu wenige Fälle“, kein Urteil. Sonst „nicht belegt“.
- **Proben.** Nullprobe: zufällig gelegte Fälle gleicher Zahl werden in höchstens 5 % der Läufe „belegt“. Positivkontrolle: ein
  eingebauter Nachteil von 3 % wird gefunden; der Bericht nennt die Nachweisgrenze bei der vorhandenen Zahl von Fällen.
- **Erwartung, ehrlich:** Seit 2023 gibt es vermutlich nur ein bis zwei Dutzend Wellen. Die Nachweisgrenze wird hoch liegen; ein
  „nicht belegt“ hieße dann „mit diesen Daten nicht zu zeigen“, nicht „widerlegt“.
- **Folgen.** Belegt: eigene Lampe mit Warnfarbe im Cockpit, Termin im Ausblick (als Ausnahmelage oder als breitere Spanne — das
  wird dann eigens festgelegt). Nicht belegt: Die Karte bleibt ein Messwert. Neue Prüfung frühestens nach fünf weiteren Wellen.

## 6a. Klarstellungen vor dem ersten Lauf (14.11.2026, Paket 23.101)

Abschnitt 6 bleibt, wie er ist. Beim Bau waren Einzelheiten festzulegen, die dort offen sind. Sie stehen hier, festgelegt am
14.11.2026, bevor die Prüfung auf echten Daten lief. **Offenlegung:** Gesehen habe ich beim Bau acht Zeilen der Tagesdatei (fünf vom
Mai 2023, drei vom 16. bis 18.05.2024 mit einem Sprung der Schlange) und die Beschreibung der Quelle -- keine Kurse dazu und keine
Auswertung. Die allgemeine Kursgeschichte von ETH ist mir bekannt; die Regeln aus Abschnitt 6 standen vorher fest.

**Daten**
- Schlange und Wartezeit: Tabelle `st_tag` (Tagesdatei, erste Messung des UTC-Tags). Der Zuwachs „gegen den Vortag“ ist damit zu
  Beginn des Falltags bekannt; angemeldet wurde im Lauf des Vortags.
- Kurs zu Beginn eines UTC-Tags: Schluss der letzten 30-Minuten-Kerze des Vortags aus `swing.db` (Binance-Perpetuals, dieselben
  Kerzen, die der Ausblick nutzt); fehlt sie, die Eröffnung der ersten Kerze des Tags. „Tiefster Stand“: kleinstes Tagestief der 7
  Tage, nur aus Tagen mit mindestens 40 von 48 Kerzen.
- Bewertet werden die Tage vom zweiten Tag der Schlange bis zu ihrem letzten, soweit das 7-Tage-Fenster abgeschlossen ist.
- **Sperren:** Gerechnet wird nur mit mindestens 365 solchen Tagen und Kursen für mindestens 98 % von ihnen. Sonst nennt der Bericht
  den Grund und speichert nichts.

**Beschreibend, ohne Test** (neben den Größen aus Abschnitt 6): ETH gegen BTC in den 7 Tagen vor dem Falltag (lief der Kurs voraus --
Lesart 2 aus Abschnitt 5?) und über 7 Tage ab dem Tag nach dem Falltag (hält der Unterschied, wenn man einen Tag später misst?).
Hintergrund der zweiten Größe: Die Prüfung nimmt an, dass die erste Messung des Tages kurz nach Mitternacht UTC liegt (laut Quelle
misst sie alle rund 15 Minuten). Läge sie später am Tag, enthielte die Zielgröße Stunden vor der Messung.

**Fälle**
- Fall A: Fehlt die Messung des Vortags (Lücke oder ausgeschlossene Zeit), kann der Tag kein Fall sein. Die 14 Tage Ruhe zählen ab
  dem letzten Tag mit Zuwachs ab der Schwelle, nicht ab dem Beginn der Welle; Tage ohne Messung gelten dabei nicht als solcher Tag.
  Fälle, in deren 14 Tagen Vorlauf Messungen fehlen, kennzeichnet der Bericht.
- Fall B: Vortag + aufgerundet(Wartezeit des Vortags in Tagen + 98.304 s ÷ 86.400 s). Das ist der erste UTC-Tag, der beginnt,
  nachdem das erste ETH der Welle frei geworden sein kann. Ohne Wartezeit des Vortags gibt es keinen Fall B. Fallen zwei Wellen auf
  denselben Tag B, zählt er einmal.
- Ein Fall zählt nur, wenn sein 7-Tage-Fenster abgeschlossen ist; sonst steht er im Bericht als „offen“.

**Test**
- Verschoben wird um 30 bis N − 30 Tage (N = Zahl der bewerteten Tage), also N − 59 Lagen. p = (1 + Zahl der Lagen mit einem
  Unterschied mindestens so niedrig wie beobachtet) ÷ (1 + Zahl der Lagen). p wird nie 0.
- Holm zählt immer zwei Fragen. Hat eine Frage weniger als 8 Fälle, geht sie mit p = 1 ein -- die andere muss dann p < 0,025 zeigen.
- Hälften: die Fälle nach der Zeit geordnet, die ersten ⌊n ÷ 2⌋ und der Rest; jede Hälfte gegen das Mittel aller bewerteten Tage.
  „Gleiches Vorzeichen“ heißt: beide negativ.
- Gesamturteil: „belegt“, wenn A oder B belegt ist; „zu wenige Fälle“, wenn beide zu wenige haben; sonst „nicht belegt“.

**Proben im Bericht**
- Nullprobe: 2.000 zufällige Lagen -- Fälle A gleicher Zahl mit mindestens 15 Tagen Abstand, Fälle B = A plus einer der echten
  Abstände -- durchlaufen das ganze Verfahren. „Höchstens 5 %“ gilt als eingehalten bis 5 % plus drei Standardfehler der Simulation
  (bei 2.000 Läufen 6,5 %). Grund der Toleranz: Holm hält das Verfahren knapp unter 5 % (beim Bau gemessen auf erfundenen
  Kursreihen: 4,4 bis 4,9 %); die Probe soll grobe Fehler finden, nicht am Zufall der Simulation scheitern. **Fällt sie durch, lautet
  das Urteil „kein Urteil“.**
- Positivkontrolle und Nachweisgrenze: In 400 zufälligen Lagen wird die Zielgröße an den Falltagen um einen Nachteil gesenkt (0,5 %
  bis 20 % in Schritten von 0,5 %). „Gefunden“ heißt: p < 0,025 (Holm bei zwei Fragen), Unterschied und beide Hälften negativ. Der
  Bericht nennt die Fundquote bei 3 % und als Nachweisgrenze den kleinsten Nachteil mit mindestens 80 % Fundquote. Dass ein
  eingebauter Nachteil von 3 % gefunden wird, zeigt der Selbsttest an einer erfundenen Welt (dort in die Kurse eingebaut).
- Feste Saat für alle Zufallszahlen: Der Bericht ist wiederholbar.

**Ein Urteil, nicht viele**
- Der erste Lauf mit ausreichenden Daten rechnet, speichert das Urteil mit Datum, Zahlen und Prüfsumme der Eingabe (`staking.db`,
  Tabelle `st_meta`, Schlüssel `studie_u255`) und zeigt es von da an nur noch. Kein stilles Neurechnen mit jedem neuen Tag.
- Neu gerechnet wird nur mit einer neuen Fassung der Regeln (Kennung im Modul, heute `U255/1`); das alte Urteil wird dann mit Datum
  abgelegt. Der Bericht zählt die Wellen seit dem Urteil; die neue Prüfung nach fünf weiteren Wellen wird eigens festgelegt.
- **Anlass-Welle:** Die Beobachtung des Nutzers stammt aus den Tagen vor dem 14.11.2026. Wellen mit Falltag A vom 01. bis 14.11.2026
  zählt das Urteil nach der Regel mit. Daneben steht eine Gegenprobe ohne sie -- zur Einordnung; sie ändert das Urteil nicht.

**Nicht geändert:** Schwelle (57.600 ETH), Ruhe (14 Tage), Zielgröße, einseitiger Test, mindestens 30 Tage Verschiebung, Holm, die drei
Bedingungen für „belegt“, die Folgen.

**Wo es steht:** Modul `hl_staking_studie.py`; **Debug 147** „★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?“ (rechnet beim
ersten Lauf; lädt vorher die Tagesdatei, wenn sie fehlt oder älter als 6 Stunden ist); **Debug 148** Selbsttest. Die Karte
„Unstaking“ im Cockpit nennt das gespeicherte Urteil als Text unter dem Termin; Debug 143 und Debug 145 nennen es auch.

## 6b. Ergebnis des ersten Laufs (15.11.2026, Debug 147 auf dem Pi)

**Urteil: nicht belegt — für die Wellen bis 25.10.2026.** Gerechnet am 15.11.2026 um 03:24 UTC mit Paket 23.101, Fassung U255/1,
gespeichert in `staking.db` (Prüfsumme der Eingabe a94d28f2fe91). Es wird nicht neu gerechnet.

| Frage | Fälle | Mittel nach den Fällen | alle Tage | Unterschied | negativ | p | p nach Holm | Hälften | Urteil |
|---|---|---|---|---|---|---|---|---|---|
| A Anmeldung | 18 | −1,48 % | −0,48 % | −1,00 %-Punkte | 14 von 18 | 0,211 | 0,422 | +0,67 / −2,67 | nicht belegt |
| B Freigabe | 18 | −0,27 % | −0,48 % | +0,21 %-Punkte | 11 von 18 | 0,596 | 0,596 | +0,24 / +0,17 | nicht belegt |

- **Daten:** Schlange an 1.228 Tagen vom 21.05.2023 bis 25.10.2026 (11 Tage fehlen, 15 ausgeschlossen); bewertet 1.253 Tage; Kurse zu
  100 %. 47 Tage mit Zuwachs ab 57.600 ETH, daraus 18 Wellen; kein Fenster offen. 1.194 Verschiebungen.
- **Proben:** Nullprobe 87 von 2.000 Läufen „belegt“ (4,3 %; erlaubt bis 6,5 %): bestanden. Ein eingebauter Nachteil von 3 % wurde in
  76 % (A) und 73 % (B) der Läufe gefunden. **Nachweisgrenze 3,5 %** bei beiden Fragen: Ein kleinerer Nachteil wäre mit 18 Wellen oft
  nicht zu erkennen.
- **Bei zufälliger Lage** der Fälle liegt der Unterschied in 90 % der Verschiebungen zwischen −1,83 und +2,03 %-Punkten (A). Die
  beobachteten −1,00 liegen mitten darin.

**Wie das zu lesen ist**
- Die Richtung bei A passt zur Beobachtung des Nutzers: Nach der Anmeldung großer Abzüge war ETH gegen BTC im Mittel um 1,0
  Prozentpunkte schwächer als sonst, in 14 von 18 Fällen negativ. **Vom Zufall unterscheiden lässt sich das nicht.** „Nicht belegt“
  heißt hier: mit diesen Daten nicht zu zeigen — nicht: widerlegt.
- Nach der Freigabe (B) zeigt sich nichts (+0,21 %-Punkte).
- Die beiden Hälften bei A gehen auseinander: die ersten neun Wellen +0,67, die letzten neun −2,67. In der ersten Hälfte liegen zwei
  starke Gegenbeispiele (17.05.2024: +21,0 %; 05.01.2024: +9,5 %). Das sind Beobachtungen nach dem Lauf, außerhalb der festgelegten
  Regel — kein Beleg, höchstens eine Frage für die nächste Prüfung.
- **Lief der Kurs voraus?** In den 7 Tagen vor dem Falltag A war ETH gegen BTC im Mittel +1,44 % (alle Tage −0,46 %). Große Abzüge
  wurden also eher nach einer Stärke von ETH angemeldet. Das passt zu Lesart 2 aus Abschnitt 5 („Abzug als Folge“) — beschreibend,
  ohne Test.
- **Hängt es an der Uhrzeit der Messung?** Ab dem Tag nach dem Falltag gemessen: A −1,24 % gegen −0,48 % für alle Tage. Der
  Unterschied bleibt etwa gleich; ein Hinweis auf einen Messfehler ist das nicht.
- Daneben: ETH allein über 7 Tage +0,24 % (A) gegen +0,13 %; über 14 Tage gegen BTC −1,32 % (A) und −2,04 % (B) gegen −0,95 %;
  tiefster Stand in den 7 Tagen −8,45 % (A) und −7,96 % (B) gegen −7,20 %.

**Was das Urteil nicht abdeckt**
- **Die Welle vom November 2026 — der Anlass der Prüfung.** Die Tagesdatei endet am 25.10.2026 (Abschnitt 3a). Der Bericht von 23.101
  nannte für den 01. bis 14.11. fälschlich „keine Welle“; richtig ist „nicht in den Daten“ (berichtigt mit 23.102).
- Ob die Wellen seit Mai 2025 alle Abzüge waren (Abschnitt 3a, Zählweise der Tagesdatei).
- Ob frei gewordenes ETH an den Markt kam, und ob der Abzug Ursache oder Folge einer Kursbewegung war.

**Folgen (wie in Abschnitt 6 festgelegt):** Die Karte bleibt ein Messwert ohne Warnfarbe und nennt das Urteil als Text, seit 23.102
mit „Wellen bis 25.10.2026“. Das Unstaking geht in keine Prognose ein. **Neue Prüfung frühestens nach fünf weiteren Wellen** — und
erst, wenn feststeht, woher deren Daten kommen (eigene Tagesreihe aus dem Knoten; wie sie an die Tagesdatei anschließt, ist vor dem
Lauf festzulegen).

**Schlange am Vortag der Wellen** (Spalte „Vortag“ seit 23.102; Debug 147 vom 15.11.2026 09:34 UTC), in der Reihenfolge der Liste
unten, in ETH: 1.792 · 256 · 832 · 5.952 · 0 · 26.592 · 5.056 · 3.936 · 28.448 · 2.304 · 93.248 · 507.689 · 1.991.984 · 2.167.402 ·
1.642.461 · 5.160 · 0 · 205.011. Zwei Wellen begannen bei leerer Schlange (12.03.2024, 10.04.2026); drei lagen auf einer Schlange von
1,6 bis 2,2 Mio. ETH (Oktober und November 2025). Ob hinter „Vortag 0“ am 12.03.2024 (ein Tag, +73.376 ETH) ein Aussetzer der Quelle
steckt, zeigt die Spalte allein nicht.

Die 18 Wellen (Falltag A, Zuwachs der Schlange, ETH gegen BTC über 7 Tage nach A und nach B):
13.06.2023 +88.128 ETH (−3,9 / −5,8) · 13.11.2023 +61.504 (−2,4 / −4,2) · 05.01.2024 +535.680 (+9,5 / +13,7) · 22.02.2024 +102.592
(−5,5 / −5,9) · 12.03.2024 +73.376 (−8,0 / −8,8) · 17.05.2024 +97.184 (+21,0 / +16,4) · 11.10.2024 +58.272 (−2,3 / −1,0) · 11.12.2024
+71.008 (−2,4 / −4,6) · 08.01.2025 +107.712 (−4,3 / −1,9) · 01.04.2025 +77.728 (−11,8 / −14,8) · 19.07.2025 +162.336 (+5,2 / +1,2) ·
13.08.2025 +60.011 (−5,7 / +6,5) · 05.10.2025 +497.015 (−7,9 / −0,3) · 26.10.2025 +290.817 (−0,7 / +8,7) · 26.11.2025 +75.902
(−3,2 / +0,8) · 14.02.2026 +58.160 (−2,7 / −2,9) · 10.04.2026 +196.760 (+2,4 / +2,0) · 01.10.2026 +568.436 (−3,9 / −4,0).

## 6c. Zweite Prüfung, vorab festgelegt (U255/2; 16.11.2026, Paket 23.106, U259)

Festgelegt am 16.11.2026, bevor es in der eigenen Messung eine neue Welle gibt. Gerechnet ist nichts. **Offenlegung:** Ich kenne die 18
Wellen der ersten Prüfung, ihre Kursfolgen und das Ergebnis (Abschnitt 6b). Von der Welle im November 2026 kenne ich die Berichte
(Abschnitte 5 und 9); sie steht in keiner Reihe und zählt nirgends. Von der eigenen Messung kenne ich zwei Zeilen (15. und 16.11.2026).
Kurse nach neuen Wellen kann es noch nicht geben. Die Regeln lassen sich ändern, solange keine neue Welle bewertet ist (frühestens am
08.12.2026) -- danach nicht mehr.

**Die Entscheidung in einem Satz:** Die zweite Prüfung ist eine Bestätigung an neuen Daten -- sie zählt nur Wellen aus der eigenen
Messung am Knoten und wird genau einmal gerechnet, sobald acht davon bewertet sind.

**Warum nur neue Wellen, und warum acht**
- Die 18 alten Wellen sind ausgewertet. Nähme die zweite Prüfung sie wieder auf, sähe sie dieselben Daten ein zweites Mal -- mit
  Zahlen, die beim Festlegen der Regeln schon bekannt sind. Beispiel: Bei 23 Wellen wären die ersten elf alle alt, und ihr Unterschied
  zu „sonst“ liegt bekanntermaßen bei rund null; ob „beide Hälften negativ“ hielte, stünde damit schon heute fast fest.
- Die alten Wellen stammen aus der Tagesdatei, deren Zählweise offen ist (Abschnitt 3a). Die neuen misst das Projekt selbst.
  Nahtstelle und Lücke (26.10. bis 15.11.2026) spielen für die Prüfung dann keine Rolle.
- Unter acht Fällen gibt das Verfahren kein Urteil (Abschnitt 6). „Frühestens nach fünf weiteren Wellen“ bleibt gewahrt; mit fünf bis
  sieben Wellen könnte das Ergebnis nur „zu wenige Fälle“ lauten.
- Überschlag: Weil die alten Wellen im Mittel nur 1,0 %-Punkte unter „sonst“ lagen, müssten acht neue Wellen in einer gemeinsamen
  Rechnung deutlicher ausfallen (rund −4,4 %-Punkte je Welle) als in einer Rechnung für sich (rund −3,7).

**Erwartung, ehrlich.** Mit acht Wellen wird die Nachweisgrenze bei rund 5 %-Punkten liegen (überschlagen aus Abschnitt 6b: 3,5 % ×
√(18 ÷ 8)). Ein Nachteil von 1 %-Punkt, wie ihn die erste Prüfung als Richtung zeigte, ist so nicht zu belegen -- dafür bräuchte es
gut 200 Wellen. Acht Wellen dauern bei bisher gut fünf im Jahr rund anderthalb Jahre. Das wahrscheinlichste Ergebnis ist wieder „nicht
belegt“. Festgelegt wird trotzdem: damit nicht nach jeder auffälligen Welle neu gerechnet wird.

**Messgröße: angemeldete Abzüge, nicht die Schlange allein**
- V = Vollabzüge in der Schlange + Vollabzüge in der Sperrfrist + Teilabzüge, ohne Zusammenlegungen -- die Zahl „angemeldet, noch
  nicht frei“ im Kopf der Karte. Je UTC-Tag aus der eigenen Tagesreihe (Abschnitt 3a).
- **Grund: Die Kette ändert voraussichtlich ihr Kontingent.** EIP-8061 steht in der Liste des Upgrades Glamsterdam (EIP-7773; dort
  für die Testnetze Sepolia am 06.10.2026 und Hoodi am 26.10.2026 angesetzt, für das Hauptnetz am 16.11.2026 noch ohne Termin). Es
  hebt das Kontingent der Austritte von 256 ETH je Epoche auf den gestakten Bestand ÷ 32.768 -- bei 36 Mio. ETH rund 1.100 ETH je
  Epoche, also rund 247.000 statt 57.600 ETH am Tag. Die Schlange wäre danach meist binnen Stunden leer und zeigte Wellen kaum noch.
  V hält jeden Antrag fest, bis er frei ist -- nach heutigem Stand mindestens 27,3 Stunden (Sperrfrist).
- V zählt auch Teilabzüge. Sie nutzen dasselbe Kontingent wie Vollabzüge (Spezifikation Electra) und sind ebenfalls ETH, das das
  Staking verlässt. Am 16.11.2026 um 18:39 UTC standen 114.190 ETH Vollabzüge in der Schlange und 42.024 ETH Teilabzüge an; zusammen
  füllen sie die 607,7 Epochen bis zum Ende der Schlange mit 257 ETH je Epoche. Das Kontingent war an diesem Tag also noch 256 ETH
  (Debug 145).
- **Schwelle: 57.600 ETH Zuwachs gegen den Vortag -- als feste Zahl.** Sie bleibt, auch wenn das Kontingent steigt.

**Welche Tage zählen**
- Ein Tag ist gemessen, wenn die erste Messung des UTC-Tags **vor 03:00 UTC** liegt und alle drei Teile da sind. Eine spätere Messung
  enthielte Anträge, die erst nach dem Beginn des Falltags kamen. Der Dienst misst um 00:02 UTC; misslingt das, versucht er es seit
  23.106 alle 5 Minuten bis 03:00 UTC.
- Die erste Zeile der Reihe (15.11.2026, 09:33 UTC) zählt deshalb nicht. Erster gemessener Tag: 16.11.2026 (00:02 UTC).
- Der Zuwachs eines Tages ist bekannt, wenn er und der Vortag gemessen sind.

**Fall A -- Anmeldung**
- **Tag mit Zuwachs:** V(Tag) − V(Vortag) ≥ 57.600 ETH.
- **Wiederbeginn:** Ist V über eine Lücke hinweg -- vom letzten gemessenen Tag bis zum ersten wieder gemessenen -- um mindestens
  57.600 ETH gewachsen, gilt der erste wieder gemessene Tag als Tag mit Zuwachs. Am Beginn der Reihe gibt es keinen Tag davor; dort
  gilt der erste gemessene Tag als Tag mit Zuwachs, wenn V bei mindestens 57.600 ETH steht. In beiden Fällen ist in der Zeit ohne
  Messung eine Welle angemeldet worden. Der Tag ist selbst kein Fall (wann der Zuwachs kam, ist nicht gemessen); Zuwachs in den 14
  Tagen danach gehört zu dieser Welle ohne Fall. Eine Lücke bei hoher, aber nicht gewachsener Summe ist kein Wiederbeginn. So zählt
  die Welle vom November 2026 nicht: Die Reihe begann am 16.11.2026 mit 248.223 ETH. **Eine neue Welle kann frühestens am 01.12.2026
  beginnen.**
- **Neuer Fall:** ein Tag mit Zuwachs, dessen Vorgänger (Tag mit Zuwachs oder Wiederbeginn) mehr als 14 Tage zurückliegt. Tage ohne
  Messung gelten wie bisher nicht als Tag mit Zuwachs; Fälle mit einer Lücke in den 14 Tagen davor werden gekennzeichnet.
- Ohne Wiederbeginn gibt die Regel dieselben Fälle wie die der ersten Prüfung (der Selbsttest vergleicht beide auf Zufallsreihen).

**Fall B -- Freigabe.** Wie bisher: Vortag + aufgerundet(Wartezeit des Vortags + 27,3 Stunden). Wartezeit = Tage bis zum Ende alles
Angemeldeten in der Schlange der Kette: der größere Wert aus der Wartezeit der Vollabzüge und „alles frei bis“ ohne Sperrfrist
(Teilabzüge können hinter dem letzten Vollabzug stehen).

**Stichtag -- bis wohin gezählt wird**
- Stichtag = der späteste von: Falltag A der achten neuen Welle; den Falltagen B der ersten acht Wellen; 364 Tagen nach dem ersten
  Tag mit bekanntem Zuwachs.
- Bewertet werden die Tage vom ersten Tag mit bekanntem Zuwachs bis zum Stichtag (mindestens 365 Tage) -- alle Kalendertage mit
  Kursen, auch solche ohne Messung; sie können nur kein Fall sein (wie in der ersten Prüfung). Fälle sind alle Falltage A und B bis
  zum Stichtag. Tage und Wellen danach zählen nicht -- gleich, wann gerechnet wird.
- Gerechnet wird einmal, sobald die Kurse bis 7 Tage nach dem Stichtag da sind. Das Urteil wird in `staking.db` unter
  `studie_u255_2` festgehalten.

**Unverändert aus den Abschnitten 6 und 6a:** Zielgröße (ETH gegen BTC über 7 Tage ab Tagesbeginn), einseitiger Test,
Kreisverschiebung um mindestens 30 Tage, zwei Fragen mit Holm, „belegt“ nur mit p nach Holm unter 0,05, mindestens 8 Fällen und beiden
Hälften negativ, Nullprobe (2.000 Läufe, erlaubt 5 % plus drei Standardfehler; fällt sie durch: „kein Urteil“), Positivkontrolle
mit Nachweisgrenze, Sperre bei Kursen für weniger als 98 % der Tage, feste Saat. Das Niveau bleibt 5 %: Die erste Prüfung ist
abgeschlossen und ging negativ aus; ein falsches „belegt“ kann nur noch aus der zweiten kommen.

**Was bis zum Urteil gezeigt wird**
- Die Karte „Unstaking · Verlauf“ und die Debug-Läufe 147, 145 und 143 zeigen neue Wellen mit Tag, Zuwachs und Zähler („x von 8“).
- **Die Kursfolgen neuer Wellen werden bis zum Urteil nicht gezeigt** -- keine Zahl je Welle, kein Mittel. Der Kurs im Bild bleibt
  sichtbar; ausgewertet wird er nicht.

**Daneben, nur beschreibend** (im Bericht der zweiten Prüfung, ohne Urteil): alle Wellen zusammen (die 18 alten und die neuen);
dieselbe Regel auf der Schlange allein; Wellen vor und nach einem Wechsel des Kontingents; die Größen aus Abschnitt 6a (7 Tage davor,
ab dem Folgetag, ETH allein, 14 Tage, tiefster Stand); Fälle mit Lücke im Vorlauf für sich.

**Folgen.** „Belegt“: wie in Abschnitt 6 (Lampe und Einbau in den Ausblick werden dann eigens festgelegt). Sonst bleibt die Karte ein
Messwert. Eine dritte Prüfung ist nicht vorgesehen; sie wäre eigens und vorab festzulegen.

**Grenzen**
- Die Welle vom November 2026 -- der Anlass -- bleibt ungeprüft. Sie zählt auch dann nicht, wenn die Tagesdatei ihre Tage
  nachliefert: Ihr Ausgang ist bekannt.
- Die erste Messung des Tages kann bis zu drei Stunden nach Mitternacht liegen; der Zuwachs enthält dann Anträge aus diesen Stunden.
  Die Größe „ab dem Folgetag“ zeigt, ob das Ergebnis daran hängt.
- Fällt die Messung einen Tag aus, kann eine Welle unbemerkt beginnen. Ihr späterer Zuwachs zählt dann als Fall mit Vermerk -- oder
  gar nicht.
- V enthält nicht: ETH, das schon frei ist; Abzüge aus Liquid-Staking-Pools ohne Austritt eines Validators.

**Gebaut mit 23.106:** die Regeln der Fälle (`hl_staking_studie.reihe_lesen`, `faelle_eigen`, `stichtag_2`, `neue_wellen`), Zähler
und Anzeige. **Noch nicht gebaut:** die Rechnung selbst -- dieselben Schritte wie `rechnen()` auf diesen Fällen. Sie kommt mit einem
eigenen Paket vor dem Stichtag (U261). Ist der Stichtag erreicht, meldet Debug 147 „fällig“.

**Befund am Rand: die Tage mit zu schnellem Abbau der Tagesdatei.** Debug 147 listet seit 23.106 die Tage seit 22.05.2025, an denen
die Schlange der Tagesdatei um mehr als 60.480 ETH fiel, und prüft zwei Muster eines Aussetzers der Quelle: **Zacke** (am Vortag um
mindestens die Hälfte des Abbaus gestiegen) und **Delle** (am Folgetag um mindestens die Hälfte wieder gestiegen). Der Bericht sagt
auch, ob der Sprung nach oben ein Falltag A der ersten Prüfung war -- dann hinge eine der 18 Wellen an einem Aussetzer. Nur die
Schlange, keine Kurse; das Urteil ändert sich dadurch nicht.
Dazu passt eine Rechnung aus der Spezifikation: Die Kette baut Zusammenlegungen mit einem eigenen Kontingent ab (gestakter Bestand ÷
65.536, abzüglich der 256 ETH für Austritte, je Epoche). Bei 36 bis 38 Mio. gestakten ETH sind das rund 66.000 bis 73.000 ETH am
Tag, zusammen mit den Austritten rund 124.000 bis 130.000 ETH. Der größte Abbau der Tagesdatei (128.494 ETH am 27.06.2026) liegt in
dieser Spanne. Das stützt die Vermutung, dass die Datei Zusammenlegungen mitzählt. Den gestakten Bestand habe ich nicht nachgeprüft;
bewiesen ist es nicht.

## 7. Proben (Pakete 23.100 bis 23.106)

- `hl_staking.py --selbsttest` (Debug 146): Zeitrechnung der Kette (Gegenprobe an einer fremden Angabe: Epoche 454.434 = 13.06.2026
  04:57:59 UTC), Lesen der Listen in Stücken jeder Größe, andere Feldreihenfolge, kaputte Einträge, Zusammenlegungen abgezogen
  (Gegenprobe: ohne die Liste wäre die Summe zu hoch), Kalender gegen eine Rechnung von Hand, große Freigabe an ihrer Schwelle,
  Tagesdatei mit alten und neuen Feldnamen, Ersatzkalender, Frische auf die Sekunde, über Mitternacht, Fehlerfälle je Quelle, der
  echte Abruf (urllib, gzip, HTTP-Fehler, keine Verbindung) gegen einen Webserver auf demselben Rechner, Wortprobe.
- `hl_cockpit.py --selbsttest`: Abgleich der Karte mit der Quelle, Schwelle, Satz mit Termin, ohne Quelle kein Wert, nur ETH; Vertrag
  mit `hl_staking` auf einer Datenbank, die das Modul selbst gefüllt hat.
- `hl_viz.py --selbsttest-cockpit`: Karte und Zeile unter dem Kernsatz im Skript, Debug-Läufe 145 und 146, Start des Fadens.
- `hl_staking_studie.py --selbsttest` (Debug 148, seit 23.101): Fälle A und B von Hand (Schwelle, Ruhe, Lücke, ausgeschlossene
  Zeit), drei echte Zeilen der Tagesdatei vom Mai 2024, Kurs zu Tagesbeginn und Zielgröße gegen eine Rechnung von Hand, Kreistest
  gegen eine Gegenrechnung ohne numpy, Holm, Urteil an den Grenzen, zufällige Lagen, Nullprobe mit Gegenprobe (ein zu großzügiges
  Verfahren fällt durch), Fundquote (abgekürzte gegen volle Rechnung), Welten Ende zu Ende (ohne Nachteil: nicht belegt; mit
  eingebautem Nachteil: belegt; wenige Wellen: kein Urteil), Speichern ohne stilles Neurechnen, Sperren bei fehlenden Daten,
  Anlass-Welle.
- Seit 23.101 im Cockpit: die Zeile mit dem Urteil in allen Fällen (ohne Urteil, nicht belegt, belegt, zu wenige Fälle, kein Urteil,
  ältere Fassung), Vertrag mit `hl_staking_studie` auf einem vom Modul gerechneten Urteil; im Skript die Zeile unter dem Termin,
  maskiert und ohne Farbe.
- Seit 23.102: eigene Tagesreihe (erster Stand je UTC-Tag bleibt; späterer Stand und misslungener Abruf ändern nichts; UTC-Tag,
  nicht Ortszeit; Datenbank von vor 23.102 wird beim Öffnen ergänzt), Takt zu Tagesbeginn (2 Minuten nach Mitternacht UTC einmal
  außer der Reihe, nicht jede Minute), stehengebliebene Tagesdatei in Antwort, Bericht und Karte, Tage mit Abbau über dem
  Tagesdurchsatz (an den letzten acht Tagen der echten Datei: fünf von sieben), Nachstellung des Stands vom 15.11.2026. In der
  Prüfung: Ende der Daten im Bericht („nicht in den Daten“ gegen „keine Welle“, Vermerk beim Urteil, Alltag mit bewerteten Tagen bis
  vor einer Woche ohne Vermerk). Kreuzprobe beim Bau: Urteil mit dem Code von 23.101 gespeichert, mit 23.102 gelesen -- unverändert.
- Seit 23.103 (Sicherung): `hl_recorder.py --selbsttest-backup` prüft für jede Nebendatenbank den Inhalt der Kopie, den vorigen
  Stand und den Fall „Quelle beschädigt“ (unlesbar und in sich widersprüchlich: die gute Kopie bleibt); `hl_viz.py
  --selbsttest-cockpit` sichert eine von `hl_staking` und `hl_staking_studie` gefüllte `staking.db` mit `do_backup`, stellt sie an
  einem neuen Ort wieder her und vergleicht Tagesreihe, Tagesdatei, Stand, gespeichertes Urteil und den Text von Debug 147 mit dem
  Original; dazu der Vertrag der Zeile „Sicherung“ (derselbe Ordner wie `hl_recorder.resolve_backup_dir`, Zeit und Größe aus der
  `backup.json` des echten Laufs). `hl_staking.py --selbsttest` prüft die Zeile in allen Fällen.
- Seit 23.104 (Verlauf): `hl_staking_studie.py --selbsttest` prüft, dass `kurs_tagesbeginn` für jeden Tag denselben Kurs gibt wie
  `kurse_lesen` (auch den Ersatz und den Tag ohne Kurs), dass die Schlange des Verlaufs genau die Reihe der Prüfung ist, die eigene
  Tagesreihe an ihrem Tag steht, die Wellen die Fälle des gespeicherten Urteils sind und nichts geschrieben wird; `hl_cockpit.py
  --selbsttest` prüft die Antwort an einer Beispielreihe (Rundung, Zeiträume ohne Daten ab drei Tagen, Wellen mit Text und Zeile,
  Sätze in allen Fällen des Urteils, Ausschnitte, Debug-Text) und den Vertrag mit `hl_staking_studie.verlauf` auf einer erfundenen
  Welt; `hl_viz.py --selbsttest-cockpit` prüft `/cockpit/unstaking` und zeichnet die Karte in einem nachgebauten Dokument
  (Ausschnitte, Linienbruch, Marken, Antippen mit Rand und Rasten, Tasten, Liste, Laden nur bei ETH und frühestens nach 30 min,
  UTC-Tage in einer anderen Zeitzone).
- Seit 23.106 (zweite Prüfung, vorab festgelegt): `hl_staking.py --selbsttest` prüft den Tagesbeginn auf die Sekunde (02:59:59 ja,
  03:00:00 nein), die Summe „angemeldet“ (fehlt ein Teil: keine Summe), das Nachholen (alle 5 Minuten, nicht früher; nicht mehr,
  wenn die Zeile steht; nicht nach 03:00 UTC) und die Zeilen der Tagesreihe in Debug 145 (Zuwachs nur zwischen zwei Tagen, die zu
  Tagesbeginn gemessen sind; „Tag mit Zuwachs“ genau ab 57.600 ETH). `hl_staking_studie.py --selbsttest` prüft die eigene Reihe, die
  Fälle von Hand (Schwelle, Wiederbeginn am Anfang und über eine Lücke hinweg -- nicht bei hoher, aber nicht gewachsener Summe --,
  14 gegen 15 Tage Ruhe, Tag B), die neue Regel gegen die
  der ersten Prüfung auf 300 Zufallsreihen (ohne Wiederbeginn dieselben Fälle), den Stichtag, den Stand wie am 16.11.2026 (0 von 8,
  früheste neue Welle 01.12.2026), „fällig“ auf den Tag, den Bericht (neue Welle ohne Kursfolge, obwohl Fenster und Kurse da sind)
  und die Tage mit zu schnellem Abbau (Zacke, Delle, Grenze, fehlender Nachbartag, die letzten acht Tage der echten Datei, Vertrag
  mit der Zählung von Debug 145). `hl_cockpit.py --selbsttest` prüft neue Wellen in der Antwort der Karte (Nummer, Text ohne
  Kursfolge, Punkte in der Liste, Satz mit Zähler), den Wortlaut zur Summe und den Vertrag mit `hl_staking_studie`;
  `hl_viz.py --selbsttest-cockpit` zeichnet zwei neue Wellen (offener Kreis, Legende, Ablesezeile „Angemeldet“, Liste).
- Mutationen und Browser-Probe: Zahlen in der Übergabe (Abschnitte zu den Paketen 23.100 bis 23.106).

## 8. Offen

- **Rechnung der zweiten Prüfung** (U261): festgelegt in Abschnitt 6c, noch nicht gebaut. Nötig zum Stichtag (frühestens ein Jahr
  nach dem 17.11.2026); Debug 147 meldet dann „fällig“.
- **EIP-8061 im Modul** (U262): Steigt das Kontingent der Austritte (Upgrade Glamsterdam; Hauptnetz am 16.11.2026 ohne Termin),
  stimmen im Modul nicht mehr: der Satz „höchstens 57.600 ETH am Tag“, die Schwelle der großen Freigabe (28.800 ETH = die Hälfte
  davon), der Ersatzkalender aus der Tagesdatei und die Grenze der Tage mit zu schnellem Abbau. Der Kalender „frei ab“ kommt aus den
  Zeitpunkten der Kette und bleibt richtig. Woran man den Wechsel sieht: In Debug 145 leert sich die Schlange dann schneller als mit
  256 ETH je Epoche.
- **Gegenseite ohne Tagesdatei** (U258): die Liste der wartenden Einzahlungen direkt vom Knoten (`pending_deposits`). Ob der
  öffentliche Knoten sie liefert und wie groß sie ist, ist auf dem Pi zu prüfen. Ebenso die Zahl der Validatoren für die Dauer des
  Auszahlungslaufs -- spätestens bis 21.02.2027, dann ist die Zahl vom 25.10.2026 zu alt.
- **Zählweise der Tagesdatei** (Abschnitt 3a): Zählt sie Zusammenlegungen mit? Debug 145 zeigt seit 23.102 die Tage mit zu
  schnellem Abbau seit Mai 2025; Debug 147 listet sie seit 23.106 einzeln mit Zacke und Delle (Abschnitt 6c). Das Ergebnis vom Pi
  steht noch aus.
- **Quelle für die Lücke** 26.10.2026 bis zum Beginn der eigenen Reihe: keine gefunden.
- Auszahlungstag je Vollabzug aus dem Stand des Auszahlungslaufs (heute nur als Fenster „bis zu 6,9 Tage danach“).
- ETH, das frei ist und auf die Auszahlung wartet (Status `withdrawal_possible`): eine große Liste, vorerst weggelassen.
- Namen zu den Adressen der großen Abzieher (keine Quelle ohne Schlüssel).
- Einstellung des Knotens im Dashboard statt über die Umgebung.
- U255: gerechnet am 15.11.2026, „nicht belegt“ (Abschnitt 6b). Die Karte bleibt ein Messwert. **Zweite Prüfung:** festgelegt am
  16.11.2026 (Abschnitt 6c) -- nur neue Wellen der eigenen Messung, einmal gerechnet nach acht Wellen.

## 9. Quellen (gelesen 14.11.2026; validatorqueue.com und das GitHub-Projekt erneut am 15.11.2026; EIP-8061, EIP-7773 und die
Spezifikation am 16.11.2026)

- Konsens-Spezifikation Electra: https://ethereum.github.io/consensus-specs/electra/beacon-chain/ (am 16.11.2026 erneut gelesen:
  Kontingent der Austritte = kleinerer Wert aus 256 ETH und gestaktem Bestand ÷ Quotient; Kontingent der Zusammenlegungen = der Rest;
  Teilabzüge nutzen das Kontingent der Austritte; die Quelle einer Zusammenlegung bekommt einen Austrittszeitpunkt)
- EIP-8061 „Increase Exit and Consolidation Churn“ (Status am 16.11.2026: Last Call; Austritte ohne Obergrenze, Quotient 32.768; bei
  36 Mio. ETH rund 1.098 ETH je Epoche): https://eips.ethereum.org/EIPS/eip-8061
- EIP-7773, Übersicht des Upgrades Glamsterdam (EIP-8061 unter „Scheduled for Inclusion“; Sepolia 06.10.2026 13:53 UTC, Hoodi
  26.10.2026 17:42 UTC, Hauptnetz ohne Eintrag; gelesen 16.11.2026): https://eips.ethereum.org/EIPS/eip-7773
- validatorqueue.com (Stand 14.11.2026: Abzug 251.274 ETH, Zugang 904.393 ETH, Zusammenlegungen 194.432 ETH, 796.121 Validatoren,
  Auszahlungslauf 6,9 Tage): https://www.validatorqueue.com/
- Tagesdatei und ihre Beschreibung: https://github.com/etheralpha/validatorqueue-com (Beschreibung und `pectra_convert.py` am
  14.11.2026 für Abschnitt 6a erneut gelesen: erste Messung je UTC-Tag; alte Werte × 32 umgerechnet; am 15.11.2026: kein Hinweis auf
  ein Ende der Datei, Quelle laut Beschreibung beaconcha.in; die Website nennt „Data provided by pectrified.com“)
- Berichte vom Pi: Debug 145 vom 15.11.2026 03:23 UTC (Abruf, Stand, letzte acht Tage der Tagesdatei) und Debug 147 vom 15.11.2026
  03:24 UTC (Urteil, alle Zahlen in Abschnitt 6b); mit Paket 23.102: Debug 145 vom 15.11.2026 09:33 UTC (erste Zeile der eigenen
  Tagesreihe, Tage mit zu schnellem Abbau) und Debug 147 vom 15.11.2026 09:34 UTC (berichtigter Bericht, Spalte „Vortag“); mit
  Paket 23.104: Debug 143 vom 16.11.2026 18:37 UTC (Verlauf: 1.276 Tage, 18 Wellen) und Debug 145 vom 16.11.2026 18:39 UTC (Zeile
  der Tagesreihe um 00:02 UTC, Sicherung vom 16.11. 02:34 UTC, Schlange 114.190 ETH und Teilabzüge 42.024 ETH bis 19.11. 11:28 UTC)
- beaconcha.in, Warteschlangen und Zugang: https://docs.beaconcha.in/use-cases/queue-wait-times ,
  https://docs.beaconcha.in/
- Fremde Auswertung über den öffentlichen Knoten: https://oanor.com/el/api/ethstakingqueue-api/get-v1-exit
- Juli 2025: https://www.fxstreet.com/cryptocurrencies/news/ethereum-validator-exit-hits-nine-days-waiting-with-nearly-2b-in-eth-ready-to-exit-the-network-202507230524
- September 2025 und Januar 2026: https://www.tradingview.com/news/cointelegraph:4c0307acc094b:0-ethereum-staking-sees-tidal-shift-as-validator-exit-queue-clears-out/
- Oktober 2026: https://thedefiant.io/news/blockchains/ethereum-exit-queue-eases-to-767-000-eth-after-metamask-validator-exits ,
  https://cryptonews.net/news/ethereum/33541370/
- November 2026: https://cryptoticker.io/en/ethereum-price-below-2000-record-staking-etf-outflows/ ,
  https://cryptoticker.io/en/ethereum-price-1958-dollars-staking-exit-queue-november-13-2026/
