# KONZEPT Unstaking (U254, U255) — wann wird gestaktes ETH frei, und folgt darauf ein Kursrückgang?

Stand 15.11.2026 (Fable 5.2). Anlass: Nachricht des Nutzers vom 14.11.2026 19:57 — „wenn sehr große Mengen Ethereum vom Staking
abgerufen werden, [kommt] es häufig zu signifikanten Kursrückgängen … Prüfe, ob diese Daten bereits im Projekt erfasst werden und
erstelle einen Indikator in den Cockpit hinein, welcher einen Termin nennt, wann größere Mengen unstaked werden.“
**Status: Stufe 1 gebaut mit Paket 23.100 (U254): Daten und Anzeige; der Abruf vom Pi aus gelingt (Debug 145 vom 15.11.2026).
Stufe 2 (U255): Die Prüfung ist am 15.11.2026 auf dem Pi gelaufen -- Urteil „nicht belegt“ für die Wellen bis 25.10.2026 (Abschnitt 6b;
Regeln in 6, Klarstellungen in 6a). Die Tagesdatei der Quelle endet am 25.10.2026; seit Paket 23.102 führt das Projekt eine eigene
Tagesreihe aus dem Knoten (Abschnitt 3a).**

---

## 0. Kurzfassung

- **Bestand:** Das Projekt erfasste bisher keine Staking-Daten (Suche im ganzen Paket nach Staking, Validator, Warteschlange: nichts).
- **Der Termin ist keine Prognose, sondern steht in der Kette.** Wer ETH aus dem Staking abzieht, bekommt vom Protokoll einen festen
  Zeitpunkt zugeteilt. Das neue Modul `hl_staking.py` liest diese Zeitpunkte und bildet daraus einen Kalender „frei ab“.
- **Im Cockpit (nur ETH):** Karte „Unstaking“ mit Summe, „alles frei bis“, der nächsten großen Freigabe als Termin, Kalender je Tag,
  größtem Abzieher und der Gegenseite; dazu eine Zeile mit dem Termin direkt unter dem Kernsatz. Klasse B (gemessen): blau, ohne
  Warnfarbe.
- **Nicht belegt ist die zweite Hälfte der Beobachtung** — dass auf große Abzüge Kursrückgänge folgen. Die vorab festgelegte Prüfung
  (Abschnitt 6) lief am 15.11.2026: 18 Wellen seit Mai 2023, ETH gegen BTC danach im Mittel 1,0 Prozentpunkte schwächer als sonst
  (14 von 18 Fällen negativ), vom Zufall nicht zu unterscheiden (p 0,21; Nachweisgrenze 3,5 %). **Das Urteil reicht bis zum
  25.10.2026; die Welle vom November 2026 ist nicht in den Daten** (Abschnitte 3a und 6b). Die Karte nennt das Urteil als Text. Erst
  ein bestandener Test macht aus dem Messwert ein Warnsignal und einen Teil der Prognose.
- **Die Tagesdatei der Quelle steht seit 25.10.2026.** Stand und Kalender kommen vom Knoten und sind davon nicht betroffen; die
  Gegenseite fehlt. Seit 23.102 führt das Projekt eine eigene Tagesreihe aus dem Knoten (Abschnitt 3a).
- **Debug 145** (★ Unstaking: Stand als Text) fragt beide Quellen selbst ab und zeigt, ob der Abruf vom Pi aus gelingt. **Debug 146**
  ist der Selbsttest. **Debug 147** (★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?) ist die Prüfung, **Debug 148** ihr
  Selbsttest.

## 1. Bestand im Projekt

Geprüft am 14.11.2026 im Paket 23.99: kein Modul, keine Tabelle und kein Abruf zu Staking, Validatoren oder Warteschlangen der
Beacon-Chain. Die Makro-Daten (ETF-Flüsse, Stablecoins) und die Börsenflüsse sind etwas anderes. Die Daten sind neu zu erfassen.

## 2. Wie Unstaking bei Ethereum abläuft

Quelle der Regeln: Konsens-Spezifikation „Electra“ (https://ethereum.github.io/consensus-specs/electra/beacon-chain/, gelesen
14.11.2026).

1. **Anmeldung.** Ein Validator meldet den Austritt an. Die Kette teilt ihm sofort eine Austritts-Epoche zu (`exit_epoch`).
2. **Warteschlange.** Je Epoche (384 s) dürfen höchstens 256 ETH das Staking verlassen (`MAX_PER_EPOCH_ACTIVATION_EXIT_CHURN_LIMIT`).
   Das sind 57.600 ETH am Tag. Ist mehr angemeldet, verschiebt sich der Austritt nach hinten.
3. **Sperrfrist.** Nach dem Austritt dauert es 256 Epochen, rund 27,3 Stunden, bis das ETH ausgezahlt werden darf
   (`withdrawable_epoch`). Diesen Zeitpunkt nennt das Modul **„frei ab“**.
4. **Auszahlung.** Vollabzüge zahlt der Auszahlungslauf aus: 16 Auszahlungen je Block, der Reihe nach über alle Validatoren. Eine
   Runde dauert bei 796.121 Validatoren 6,9 Tage (so zeigt es validatorqueue.com am 14.11.2026 als „Sweep Delay“). Ein Vollabzug kommt
   also zwischen „frei ab“ und knapp 7 Tage danach auf dem Konto an.
5. **Teilabzüge** (seit Mai 2025 möglich, für Validatoren mit bis zu 2.048 ETH): Sie durchlaufen dieselbe Begrenzung, bekommen
   ebenfalls ein „frei ab“ und werden dann sofort ausgezahlt (bis zu 8 je Block), ohne den Auszahlungslauf.
6. **Zusammenlegungen** sehen in der Liste der Kette aus wie Abzüge: Der Quell-Validator bekommt eine Austritts-Epoche. Sein ETH
   geht aber an einen anderen Validator und bleibt gestakt. Sie müssen abgezogen werden — am 14.11.2026 waren das 194.432 ETH neben
   251.274 ETH echter Abzüge.

Was die Kette nicht zeigt: ob frei gewordenes ETH an den Markt kommt. Ein Abzug kann ein Wechsel des Betreibers sein, eine
Vorsichtsmaßnahme oder der erste Schritt zu einem neuen Staking.

## 3. Datenquellen

| Quelle | Was | Schlüssel | Rolle |
|---|---|---|---|
| Beacon-Knoten, Standard-API (Voreinstellung `https://ethereum-beacon-api.publicnode.com`) | jeder angemeldete Abzug mit seinem Zeitpunkt | nein | Hauptquelle, stündlich |
| Tagesdatei von validatorqueue.com (`historical_data.json` im GitHub-Projekt `etheralpha/validatorqueue-com`) | Warteschlangen je Tag seit 21.05.2023, Zahl der Validatoren | nein | Rückblick, Gegenseite, Ersatz; alle 6 Stunden. **Endet am 25.10.2026** (Abschnitt 3a) |
| Eigene Tagesreihe (Tabelle `st_tag_knoten`, seit 23.102) | erster Stand des Knotens je UTC-Tag: Schlange, Wartezeit, Sperrfrist, Teilabzüge, Zusammenlegungen | — | Rückblick ab dem Einspielen von 23.102; Grundlage einer späteren Prüfung |

Fünf Fragen an den Knoten je Lauf: Kopf der Kette (`/eth/v1/beacon/headers/head`), Zusammenlegungen
(`…/states/finalized/pending_consolidations`), Validatoren mit Status `active_exiting` und `exited_unslashed`
(`…/states/finalized/validators?status=…`), Teilabzüge (`…/pending_partial_withdrawals`).

- **Sicherungen.** Liegt der Kopf des Knotens mehr als 150 Slots (30 Minuten) neben der Uhr, gilt sein Stand nicht: Seine
  Zeitpunkte wären falsch (Knoten kommt nicht mit, oder die Zeitrechnung der Kette wurde geändert). Ohne die Liste der
  Zusammenlegungen gibt es keinen Stand vom Knoten: Die Summe wäre zu hoch. Fehlen nur Teilabzüge oder die Sperrfrist-Liste, gilt der
  Stand mit Hinweis.
- **Ersatz.** Antwortet der Knoten nicht und ist die Tagesdatei höchstens 2 Tage alt, zeigt das Cockpit einen Kalender, der aus der
  Länge der Schlange geschätzt ist (57.600 ETH je Tag, dann die Sperrfrist) — gekennzeichnet als Schätzung, ohne Teilabzüge und ohne
  Abzieher. Sonst zeigt es keinen Wert und nennt die Gründe.
- **Eigener Knoten.** Die Umgebungsvariable `HL_STAKING_KNOTEN` setzt andere Knoten (mehrere mit Komma, der Reihe nach).
  `HL_STAKING=0` schaltet den Abruf ab.
- **Verworfen:** die Schnittstelle von beaconcha.in. Sie liefert dieselben Größen fertig gerechnet, verlangt aber einen Schlüssel;
  der kostenlose Zugang endet nach 30 Tagen (https://docs.beaconcha.in/, gelesen 14.11.2026).
- **Abruf über das Netz:** aus der Sandbox nicht prüfbar. **Bewiesen am 15.11.2026 mit Debug 145 auf dem Pi:** fünf Fragen an den
  öffentlichen Knoten, alle HTTP 200 (Kopf 0,7 kB; Zusammenlegungen 313,9 kB mit 6.045 Einträgen; Schlange 3,0 MB mit 6.538;
  Sperrfrist 1,6 MB mit 3.429; Teilabzüge 7,8 kB mit 94), zusammen 4,9 MB in 1,5 s.
- **Was die Tagesdatei ist** (laut ihrer Beschreibung, am 14.11.2026 nachgelesen): Die Quelle misst alle rund 15 Minuten und hält
  je UTC-Tag die erste Messung fest. Bis zum 06.05.2025 zählte die Kette die Schlangen in Validatoren; die Datei trägt für diese Zeit
  Validatoren × 32 als ETH (Umrechnung der Quelle; die Zeilen vom Mai 2023 sind durch 32 teilbar). Vom 07.05. bis 21.05.2025 stehen
  Validatoren statt ETH in den Feldern -- diese 15 Tage nutzt das Projekt nicht. Einzelne Tage fehlen; die Berichte zählen sie.

Last: Bei einer Schlange von 250.000 ETH sind das stündlich wenige MB (gepackt übertragen). Die Antwort wird in Stücken gelesen; im
Speicher bleibt je Validator nur ein kleiner Eintrag, nicht der Text der Liste. Ein ganzer Abruf am Knoten darf höchstens 150
Sekunden dauern, die Tagesdatei 60.

## 3a. Befund vom 15.11.2026: Die Tagesdatei steht — eigene Tagesreihe (Paket 23.102)

**Was Debug 145 auf dem Pi zeigte (15.11.2026, 03:23 UTC):** Der Knoten antwortet (fünf Fragen, alle HTTP 200, zusammen 4,9 MB in
1,5 s). Die Tagesdatei kommt auch an (342,6 kB, 1.243 Einträge) — ihr letzter Tag ist aber der **25.10.2026**. Seit drei Wochen hat sie
keinen neuen Eintrag. Die Ursache kenne ich nicht: Auf validatorqueue.com steht inzwischen „Data provided by pectrified.com“; die
Beschreibung im GitHub-Projekt nennt weiter beaconcha.in und kein Ende der Datei. Eine andere Tagesquelle ohne Schlüssel habe ich
nicht gefunden (gesucht am 15.11.2026).

**Mein Fehler dabei:** Am 14.11. hatte ich die Datei als laufend angenommen und das nicht geprüft. Der Bericht der Prüfung (Debug 147,
Paket 23.101) schrieb deshalb, vom 01. bis 14.11.2026 habe es „nach der Regel keine Welle“ gegeben. Das war falsch: Für diese Tage gab
es keine Daten. Seit 23.102 unterscheidet der Bericht „keine Welle“ von „nicht in den Daten“.

**Folgen, und was 23.102 daran ändert**
- **Gegenseite** (ETH, das gestakt werden soll): kommt nur aus der Tagesdatei und fehlt deshalb. Die Karte ließ die Zeile bisher still
  weg; jetzt sagt sie, dass der Wert fehlt und bis wann die Quelle reicht.
- **Dauer des Auszahlungslaufs:** rechnet mit der Zahl der Validatoren aus der Tagesdatei (819.745 am 25.10.2026 → bis zu 7,1 Tage).
  Die Zahl ändert sich langsam. Sie gilt jetzt 120 statt 30 Tage als brauchbar (bis 21.02.2027); Karte und Bericht nennen den Tag, von
  dem sie stammt. Mit 30 Tagen wäre die Angabe am 24.11.2026 weggefallen.
- **Ersatzkalender** (wenn der Knoten ausfällt): entfällt, solange die Tagesdatei älter als 2 Tage ist. Dann zeigt die Karte keinen
  Wert und nennt den Grund.
- **Abgleich Knoten gegen Tagesdatei** in Debug 145: nur noch mit frischer Tagesdatei. Vorher verglich der Bericht den Stand von heute
  mit einem drei Wochen alten Wert und nannte das „nur ungefähr gleich“.
- **Rückblick und Prüfung der Kursfolge** enden am 25.10.2026. Bericht und Karte sagen das jetzt („Wellen bis 25.10.2026“).

**Eigene Tagesreihe (Tabelle `st_tag_knoten` in `staking.db`, seit 23.102).** Je UTC-Tag hält das Modul den ersten Stand des Knotens
fest: Schlange der Vollabzüge (noch nicht ausgetreten; ohne Sperrfrist, ohne Zusammenlegungen), ihre Wartezeit bis zum letzten
zugeteilten Austritt, dazu getrennt Sperrfrist, Teilabzüge, Zusammenlegungen und „alles frei bis“. Damit die erste Messung am
Tagesbeginn liegt, fragt der Dienst den Knoten zwei Minuten nach Mitternacht UTC einmal außer der Reihe; danach gilt wieder der
Stundentakt. Die Zeile trägt die Uhrzeit ihrer Messung. Debug 145 zeigt die letzten acht Tage.
- Die Reihe beginnt mit dem Einspielen von 23.102. **Die Tage vom 26.10.2026 bis dahin fehlen und lassen sich aus dem Knoten nicht
  nachholen** (er zeigt nur den jetzigen Stand). Die Welle vom November 2026 (laut Berichten 06. bis 13.11.: 4.320 → 269.951 ETH) ist
  deshalb in keiner Reihe des Projekts.
- `staking.db` ist noch nicht im Backup (U257). Seit es diese Reihe gibt, wiegt das schwerer: Sie lässt sich nicht neu laden.

**Zweifel an der Zählweise der Tagesdatei.** In ihren letzten acht Tagen (18. bis 25.10.2026) fiel die Schlange an fünf von sieben
Tagen um 76.389 bis 121.960 ETH. Abzüge allein lassen höchstens 57.600 ETH am Tag zu; der Kalender des Knotens vom 15.11.2026 zeigt
diese Grenze (57.708 und 58.748 ETH an den vollen Tagen). Eine mögliche Erklärung: Die Datei zählt Zusammenlegungen mit. Sie haben
in der Kette ein eigenes Kontingent neben dem der Abzüge (Konsens-Spezifikation Electra). **Nicht geprüft** — es gibt keinen Tag mit
beiden Messungen. Was daraus folgt:
- Debug 145 zählt seit 23.102 im Rückblick die Tage seit 22.05.2025, an denen die Schlange der Tagesdatei um mehr als 60.480 ETH fiel
  (5 % über dem Tagesdurchsatz, als Abstand für die Uhrzeit der Messung).
- Für die Prüfung der Kursfolge heißt das: Einzelne der acht Wellen seit Mai 2025 könnten Zusammenlegungen gewesen sein, also kein
  ETH, das das Staking verlässt. Der Bericht nennt das als offenen Punkt.
- Ein einzelner Vergleichspunkt, Stunden auseinander: validatorqueue.com zeigte am Abend des 14.11.2026 Abzüge von 251.274 ETH und
  getrennt davon 194.432 ETH Zusammenlegungen. Der Knoten zeigte am 15.11. um 03:20 UTC 167.896 ETH in der Schlange, 227.280 ETH mit
  Sperrfrist und 193.499 ETH Zusammenlegungen. Die Zahl der Website liegt näher an „mit Sperrfrist“. Was die Tagesdatei bis zum
  25.10. zählte, sagt das nicht. Die eigene Reihe hält deshalb alle Teile getrennt fest; kommt die Tagesdatei wieder, zeigt Debug 145
  die drei Zählweisen des Knotens neben ihrem Wert.

## 4. Was gemessen und gezeigt wird — Schwellen fest und vorab

- **Angemeldet, noch nicht frei** = Vollabzüge (in der Schlange und in der Sperrfrist) + Teilabzüge, in ETH nach Kontostand;
  im Cockpit dazu der Wert in USD zum frischen Kurs.
- **Kalender „frei ab“** je UTC-Tag. Schon Fälliges zählt unter heute.
- **Alles Angemeldete frei bis** = spätester Zeitpunkt „frei ab“.
- **Große Freigabe** = die nächste Folge von UTC-Tagen mit jeweils mindestens **28.800 ETH** „frei ab“ (die Hälfte des
  Höchstdurchsatzes von 57.600 ETH). Das ist der Termin, den das Cockpit nennt.
- **Abzieher:** Vollabzüge je Auszahlungsadresse, genannt ab **10.000 ETH**, höchstens drei.
- **Gegenseite:** ETH, das darauf wartet, gestakt zu werden (Tagesdatei).
- **Frische:** Stand des Knotens höchstens 3 Stunden alt; Tagesdatei als Ersatz und für die Gegenseite höchstens 2 Tage zurück (eine
  ältere Gegenseite wird nicht gezeigt -- die Karte sagt dann, dass der Wert fehlt); die Dauer des Auszahlungslaufs aus der Zahl
  der Validatoren bis 120 Tage (sie ändert sich langsam; bis 23.101: 30 Tage), bei älterer Tagesdatei mit dem Tag der Zahl.
- **Farbe:** keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer Balken, Punkt).

Nicht enthalten: ETH, das schon frei ist und auf den Auszahlungslauf wartet; Abzüge aus Liquid-Staking-Pools, die ohne Austritt
eines Validators bedient werden; der genaue Auszahlungstag eines einzelnen Vollabzugs.

## 5. Einordnung — was über Abzüge und Kurs bekannt ist

Bekannte Wellen aus Berichten (nicht systematisch geprüft, Quellen in Abschnitt 9):

| Zeit | Schlange | Anlass laut Berichten | Kurs im Umfeld |
|---|---|---|---|
| Juli 2025 | 1.920 → über 520.000 ETH in einer Woche | nach einem Kursanstieg von rund 160 % | Anstieg davor |
| September 2025 | Höchststand 2,67 Mio. ETH | — | — |
| Anfang Oktober 2026 | 166.000 → 850.736 ETH in drei Tagen | Sicherheitsvorfall bei MetaMask, vorsorgliche Austritte | — |
| 06.–13.11.2026 | 4.320 → 269.951 ETH | — | ETH in einer Woche −12,4 % auf 1.958 USD; ETF-Abflüsse 696 Mio. USD in acht Handelstagen |

Drei Lesarten sind möglich, und die Fälle oben passen zu verschiedenen:
1. **Abzug vor Verkauf** (die Beobachtung des Nutzers): große Abzüge kündigen Angebot an.
2. **Abzug als Folge:** Nach einem starken Anstieg (Juli 2025) oder während eines Rückgangs (November 2026) wird abgezogen. Dann
   läuft der Kurs voraus, nicht hinterher.
3. **Abzug ohne Verkauf:** Betreiberwechsel und Vorsichtsmaßnahmen (MetaMask) setzen kein ETH frei, das an den Markt soll.

Größenordnung: Das Protokoll gibt höchstens 57.600 ETH am Tag frei — beim Kurs vom 13.11.2026 rund 113 Mio. USD. Das liegt in der
Größe der täglichen ETF-Abflüsse dieses Monats (rund 87 Mio. USD je Handelstag). Zugleich warteten am 14.11.2026 mehr als dreimal so
viele ETH auf den Weg ins Staking (904.393) wie heraus (251.274).

## 6. Studie, vorab festgelegt (U255) — gebaut mit Paket 23.101, gerechnet am 15.11.2026 (Ergebnis in 6b)

Festgelegt am 14.11.2026, bevor die Tagesdatei mit Kursen zusammengeführt wurde. **Offenlegung:** Bekannt waren mir nur die vier
Wellen aus Abschnitt 5 und die dort genannten Kurse; eine Auswertung gab es nicht.

- **Daten.** Schlange der Abzüge je UTC-Tag aus der Tagesdatei (erste Messung des Tages), ab 21.05.2023. Ausgeschlossen: 07.05. bis
  21.05.2025 und Tage ohne Eintrag. Tagesschlüsse von ETH und BTC (UTC) aus den Kerzen, die der Ausblick nutzt.
- **Fall A — Anmeldung.** Tag d, an dem die Schlange gegen den Vortag um mindestens 57.600 ETH wächst (ein voller Tagesdurchsatz).
  Ein neuer Fall beginnt erst nach 14 Tagen ohne solchen Tag.
- **Fall B — Freigabe.** Der UTC-Tag, an dem das erste ETH der Welle frei wird: d − 1 + Wartezeit des Vortags + 27,3 Stunden,
  aufgerundet.
- **Zielgröße.** Log-Rendite von ETH minus der von BTC über 7 Tage ab dem Beginn des Falltags. So zählt nur, was ETH für sich
  verliert. Beschreibend daneben: ETH allein, 14 Tage, tiefster Stand im Fenster.
- **Test.** Mittel der Zielgröße nach den Fällen minus Mittel über alle Tage; einseitig (nach den Fällen niedriger). Nullverteilung
  durch Verschieben der Fallreihe gegen die Kursreihe im Kreis (alle Verschiebungen um mindestens 30 Tage). Zwei Hypothesen (A, B),
  Holm.
- **Urteil.** „Belegt“ nur mit p Holm < 0,05, mindestens 8 Fällen und gleichem Vorzeichen in beiden Hälften der Fälle. Mit weniger
  als 8 Fällen: „zu wenige Fälle“, kein Urteil. Sonst „nicht belegt“.
- **Proben.** Nullprobe: zufällig gelegte Fälle gleicher Zahl werden in höchstens 5 % der Läufe „belegt“. Positivkontrolle: ein
  eingebauter Nachteil von 3 % wird gefunden; der Bericht nennt die Nachweisgrenze bei der vorhandenen Zahl von Fällen.
- **Erwartung, ehrlich:** Seit 2023 gibt es vermutlich nur ein bis zwei Dutzend Wellen. Die Nachweisgrenze wird hoch liegen; ein
  „nicht belegt“ hieße dann „mit diesen Daten nicht zu zeigen“, nicht „widerlegt“.
- **Folgen.** Belegt: eigene Lampe mit Warnfarbe im Cockpit, Termin im Ausblick (als Ausnahmelage oder als breitere Spanne — das
  wird dann eigens festgelegt). Nicht belegt: Die Karte bleibt ein Messwert. Neue Prüfung frühestens nach fünf weiteren Wellen.

## 6a. Klarstellungen vor dem ersten Lauf (14.11.2026, Paket 23.101)

Abschnitt 6 bleibt, wie er ist. Beim Bau waren Einzelheiten festzulegen, die dort offen sind. Sie stehen hier, festgelegt am
14.11.2026, bevor die Prüfung auf echten Daten lief. **Offenlegung:** Gesehen habe ich beim Bau acht Zeilen der Tagesdatei (fünf vom
Mai 2023, drei vom 16. bis 18.05.2024 mit einem Sprung der Schlange) und die Beschreibung der Quelle -- keine Kurse dazu und keine
Auswertung. Die allgemeine Kursgeschichte von ETH ist mir bekannt; die Regeln aus Abschnitt 6 standen vorher fest.

**Daten**
- Schlange und Wartezeit: Tabelle `st_tag` (Tagesdatei, erste Messung des UTC-Tags). Der Zuwachs „gegen den Vortag“ ist damit zu
  Beginn des Falltags bekannt; angemeldet wurde im Lauf des Vortags.
- Kurs zu Beginn eines UTC-Tags: Schluss der letzten 30-Minuten-Kerze des Vortags aus `swing.db` (Binance-Perpetuals, dieselben
  Kerzen, die der Ausblick nutzt); fehlt sie, die Eröffnung der ersten Kerze des Tags. „Tiefster Stand“: kleinstes Tagestief der 7
  Tage, nur aus Tagen mit mindestens 40 von 48 Kerzen.
- Bewertet werden die Tage vom zweiten Tag der Schlange bis zu ihrem letzten, soweit das 7-Tage-Fenster abgeschlossen ist.
- **Sperren:** Gerechnet wird nur mit mindestens 365 solchen Tagen und Kursen für mindestens 98 % von ihnen. Sonst nennt der Bericht
  den Grund und speichert nichts.

**Beschreibend, ohne Test** (neben den Größen aus Abschnitt 6): ETH gegen BTC in den 7 Tagen vor dem Falltag (lief der Kurs voraus --
Lesart 2 aus Abschnitt 5?) und über 7 Tage ab dem Tag nach dem Falltag (hält der Unterschied, wenn man einen Tag später misst?).
Hintergrund der zweiten Größe: Die Prüfung nimmt an, dass die erste Messung des Tages kurz nach Mitternacht UTC liegt (laut Quelle
misst sie alle rund 15 Minuten). Läge sie später am Tag, enthielte die Zielgröße Stunden vor der Messung.

**Fälle**
- Fall A: Fehlt die Messung des Vortags (Lücke oder ausgeschlossene Zeit), kann der Tag kein Fall sein. Die 14 Tage Ruhe zählen ab
  dem letzten Tag mit Zuwachs ab der Schwelle, nicht ab dem Beginn der Welle; Tage ohne Messung gelten dabei nicht als solcher Tag.
  Fälle, in deren 14 Tagen Vorlauf Messungen fehlen, kennzeichnet der Bericht.
- Fall B: Vortag + aufgerundet(Wartezeit des Vortags in Tagen + 98.304 s ÷ 86.400 s). Das ist der erste UTC-Tag, der beginnt,
  nachdem das erste ETH der Welle frei geworden sein kann. Ohne Wartezeit des Vortags gibt es keinen Fall B. Fallen zwei Wellen auf
  denselben Tag B, zählt er einmal.
- Ein Fall zählt nur, wenn sein 7-Tage-Fenster abgeschlossen ist; sonst steht er im Bericht als „offen“.

**Test**
- Verschoben wird um 30 bis N − 30 Tage (N = Zahl der bewerteten Tage), also N − 59 Lagen. p = (1 + Zahl der Lagen mit einem
  Unterschied mindestens so niedrig wie beobachtet) ÷ (1 + Zahl der Lagen). p wird nie 0.
- Holm zählt immer zwei Fragen. Hat eine Frage weniger als 8 Fälle, geht sie mit p = 1 ein -- die andere muss dann p < 0,025 zeigen.
- Hälften: die Fälle nach der Zeit geordnet, die ersten ⌊n ÷ 2⌋ und der Rest; jede Hälfte gegen das Mittel aller bewerteten Tage.
  „Gleiches Vorzeichen“ heißt: beide negativ.
- Gesamturteil: „belegt“, wenn A oder B belegt ist; „zu wenige Fälle“, wenn beide zu wenige haben; sonst „nicht belegt“.

**Proben im Bericht**
- Nullprobe: 2.000 zufällige Lagen -- Fälle A gleicher Zahl mit mindestens 15 Tagen Abstand, Fälle B = A plus einer der echten
  Abstände -- durchlaufen das ganze Verfahren. „Höchstens 5 %“ gilt als eingehalten bis 5 % plus drei Standardfehler der Simulation
  (bei 2.000 Läufen 6,5 %). Grund der Toleranz: Holm hält das Verfahren knapp unter 5 % (beim Bau gemessen auf erfundenen
  Kursreihen: 4,4 bis 4,9 %); die Probe soll grobe Fehler finden, nicht am Zufall der Simulation scheitern. **Fällt sie durch, lautet
  das Urteil „kein Urteil“.**
- Positivkontrolle und Nachweisgrenze: In 400 zufälligen Lagen wird die Zielgröße an den Falltagen um einen Nachteil gesenkt (0,5 %
  bis 20 % in Schritten von 0,5 %). „Gefunden“ heißt: p < 0,025 (Holm bei zwei Fragen), Unterschied und beide Hälften negativ. Der
  Bericht nennt die Fundquote bei 3 % und als Nachweisgrenze den kleinsten Nachteil mit mindestens 80 % Fundquote. Dass ein
  eingebauter Nachteil von 3 % gefunden wird, zeigt der Selbsttest an einer erfundenen Welt (dort in die Kurse eingebaut).
- Feste Saat für alle Zufallszahlen: Der Bericht ist wiederholbar.

**Ein Urteil, nicht viele**
- Der erste Lauf mit ausreichenden Daten rechnet, speichert das Urteil mit Datum, Zahlen und Prüfsumme der Eingabe (`staking.db`,
  Tabelle `st_meta`, Schlüssel `studie_u255`) und zeigt es von da an nur noch. Kein stilles Neurechnen mit jedem neuen Tag.
- Neu gerechnet wird nur mit einer neuen Fassung der Regeln (Kennung im Modul, heute `U255/1`); das alte Urteil wird dann mit Datum
  abgelegt. Der Bericht zählt die Wellen seit dem Urteil; die neue Prüfung nach fünf weiteren Wellen wird eigens festgelegt.
- **Anlass-Welle:** Die Beobachtung des Nutzers stammt aus den Tagen vor dem 14.11.2026. Wellen mit Falltag A vom 01. bis 14.11.2026
  zählt das Urteil nach der Regel mit. Daneben steht eine Gegenprobe ohne sie -- zur Einordnung; sie ändert das Urteil nicht.

**Nicht geändert:** Schwelle (57.600 ETH), Ruhe (14 Tage), Zielgröße, einseitiger Test, mindestens 30 Tage Verschiebung, Holm, die drei
Bedingungen für „belegt“, die Folgen.

**Wo es steht:** Modul `hl_staking_studie.py`; **Debug 147** „★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?“ (rechnet beim
ersten Lauf; lädt vorher die Tagesdatei, wenn sie fehlt oder älter als 6 Stunden ist); **Debug 148** Selbsttest. Die Karte
„Unstaking“ im Cockpit nennt das gespeicherte Urteil als Text unter dem Termin; Debug 143 und Debug 145 nennen es auch.

## 6b. Ergebnis des ersten Laufs (15.11.2026, Debug 147 auf dem Pi)

**Urteil: nicht belegt — für die Wellen bis 25.10.2026.** Gerechnet am 15.11.2026 um 03:24 UTC mit Paket 23.101, Fassung U255/1,
gespeichert in `staking.db` (Prüfsumme der Eingabe a94d28f2fe91). Es wird nicht neu gerechnet.

| Frage | Fälle | Mittel nach den Fällen | alle Tage | Unterschied | negativ | p | p nach Holm | Hälften | Urteil |
|---|---|---|---|---|---|---|---|---|---|
| A Anmeldung | 18 | −1,48 % | −0,48 % | −1,00 %-Punkte | 14 von 18 | 0,211 | 0,422 | +0,67 / −2,67 | nicht belegt |
| B Freigabe | 18 | −0,27 % | −0,48 % | +0,21 %-Punkte | 11 von 18 | 0,596 | 0,596 | +0,24 / +0,17 | nicht belegt |

- **Daten:** Schlange an 1.228 Tagen vom 21.05.2023 bis 25.10.2026 (11 Tage fehlen, 15 ausgeschlossen); bewertet 1.253 Tage; Kurse zu
  100 %. 47 Tage mit Zuwachs ab 57.600 ETH, daraus 18 Wellen; kein Fenster offen. 1.194 Verschiebungen.
- **Proben:** Nullprobe 87 von 2.000 Läufen „belegt“ (4,3 %; erlaubt bis 6,5 %): bestanden. Ein eingebauter Nachteil von 3 % wurde in
  76 % (A) und 73 % (B) der Läufe gefunden. **Nachweisgrenze 3,5 %** bei beiden Fragen: Ein kleinerer Nachteil wäre mit 18 Wellen oft
  nicht zu erkennen.
- **Bei zufälliger Lage** der Fälle liegt der Unterschied in 90 % der Verschiebungen zwischen −1,83 und +2,03 %-Punkten (A). Die
  beobachteten −1,00 liegen mitten darin.

**Wie das zu lesen ist**
- Die Richtung bei A passt zur Beobachtung des Nutzers: Nach der Anmeldung großer Abzüge war ETH gegen BTC im Mittel um 1,0
  Prozentpunkte schwächer als sonst, in 14 von 18 Fällen negativ. **Vom Zufall unterscheiden lässt sich das nicht.** „Nicht belegt“
  heißt hier: mit diesen Daten nicht zu zeigen — nicht: widerlegt.
- Nach der Freigabe (B) zeigt sich nichts (+0,21 %-Punkte).
- Die beiden Hälften bei A gehen auseinander: die ersten neun Wellen +0,67, die letzten neun −2,67. In der ersten Hälfte liegen zwei
  starke Gegenbeispiele (17.05.2024: +21,0 %; 05.01.2024: +9,5 %). Das sind Beobachtungen nach dem Lauf, außerhalb der festgelegten
  Regel — kein Beleg, höchstens eine Frage für die nächste Prüfung.
- **Lief der Kurs voraus?** In den 7 Tagen vor dem Falltag A war ETH gegen BTC im Mittel +1,44 % (alle Tage −0,46 %). Große Abzüge
  wurden also eher nach einer Stärke von ETH angemeldet. Das passt zu Lesart 2 aus Abschnitt 5 („Abzug als Folge“) — beschreibend,
  ohne Test.
- **Hängt es an der Uhrzeit der Messung?** Ab dem Tag nach dem Falltag gemessen: A −1,24 % gegen −0,48 % für alle Tage. Der
  Unterschied bleibt etwa gleich; ein Hinweis auf einen Messfehler ist das nicht.
- Daneben: ETH allein über 7 Tage +0,24 % (A) gegen +0,13 %; über 14 Tage gegen BTC −1,32 % (A) und −2,04 % (B) gegen −0,95 %;
  tiefster Stand in den 7 Tagen −8,45 % (A) und −7,96 % (B) gegen −7,20 %.

**Was das Urteil nicht abdeckt**
- **Die Welle vom November 2026 — der Anlass der Prüfung.** Die Tagesdatei endet am 25.10.2026 (Abschnitt 3a). Der Bericht von 23.101
  nannte für den 01. bis 14.11. fälschlich „keine Welle“; richtig ist „nicht in den Daten“ (berichtigt mit 23.102).
- Ob die Wellen seit Mai 2025 alle Abzüge waren (Abschnitt 3a, Zählweise der Tagesdatei).
- Ob frei gewordenes ETH an den Markt kam, und ob der Abzug Ursache oder Folge einer Kursbewegung war.

**Folgen (wie in Abschnitt 6 festgelegt):** Die Karte bleibt ein Messwert ohne Warnfarbe und nennt das Urteil als Text, seit 23.102
mit „Wellen bis 25.10.2026“. Das Unstaking geht in keine Prognose ein. **Neue Prüfung frühestens nach fünf weiteren Wellen** — und
erst, wenn feststeht, woher deren Daten kommen (eigene Tagesreihe aus dem Knoten; wie sie an die Tagesdatei anschließt, ist vor dem
Lauf festzulegen).

Die 18 Wellen (Falltag A, Zuwachs der Schlange, ETH gegen BTC über 7 Tage nach A und nach B):
13.06.2023 +88.128 ETH (−3,9 / −5,8) · 13.11.2023 +61.504 (−2,4 / −4,2) · 05.01.2024 +535.680 (+9,5 / +13,7) · 22.02.2024 +102.592
(−5,5 / −5,9) · 12.03.2024 +73.376 (−8,0 / −8,8) · 17.05.2024 +97.184 (+21,0 / +16,4) · 11.10.2024 +58.272 (−2,3 / −1,0) · 11.12.2024
+71.008 (−2,4 / −4,6) · 08.01.2025 +107.712 (−4,3 / −1,9) · 01.04.2025 +77.728 (−11,8 / −14,8) · 19.07.2025 +162.336 (+5,2 / +1,2) ·
13.08.2025 +60.011 (−5,7 / +6,5) · 05.10.2025 +497.015 (−7,9 / −0,3) · 26.10.2025 +290.817 (−0,7 / +8,7) · 26.11.2025 +75.902
(−3,2 / +0,8) · 14.02.2026 +58.160 (−2,7 / −2,9) · 10.04.2026 +196.760 (+2,4 / +2,0) · 01.10.2026 +568.436 (−3,9 / −4,0).

## 7. Proben (Pakete 23.100 bis 23.102)

- `hl_staking.py --selbsttest` (Debug 146): Zeitrechnung der Kette (Gegenprobe an einer fremden Angabe: Epoche 454.434 = 13.06.2026
  04:57:59 UTC), Lesen der Listen in Stücken jeder Größe, andere Feldreihenfolge, kaputte Einträge, Zusammenlegungen abgezogen
  (Gegenprobe: ohne die Liste wäre die Summe zu hoch), Kalender gegen eine Rechnung von Hand, große Freigabe an ihrer Schwelle,
  Tagesdatei mit alten und neuen Feldnamen, Ersatzkalender, Frische auf die Sekunde, über Mitternacht, Fehlerfälle je Quelle, der
  echte Abruf (urllib, gzip, HTTP-Fehler, keine Verbindung) gegen einen Webserver auf demselben Rechner, Wortprobe.
- `hl_cockpit.py --selbsttest`: Abgleich der Karte mit der Quelle, Schwelle, Satz mit Termin, ohne Quelle kein Wert, nur ETH; Vertrag
  mit `hl_staking` auf einer Datenbank, die das Modul selbst gefüllt hat.
- `hl_viz.py --selbsttest-cockpit`: Karte und Zeile unter dem Kernsatz im Skript, Debug-Läufe 145 und 146, Start des Fadens.
- `hl_staking_studie.py --selbsttest` (Debug 148, seit 23.101): Fälle A und B von Hand (Schwelle, Ruhe, Lücke, ausgeschlossene
  Zeit), drei echte Zeilen der Tagesdatei vom Mai 2024, Kurs zu Tagesbeginn und Zielgröße gegen eine Rechnung von Hand, Kreistest
  gegen eine Gegenrechnung ohne numpy, Holm, Urteil an den Grenzen, zufällige Lagen, Nullprobe mit Gegenprobe (ein zu großzügiges
  Verfahren fällt durch), Fundquote (abgekürzte gegen volle Rechnung), Welten Ende zu Ende (ohne Nachteil: nicht belegt; mit
  eingebautem Nachteil: belegt; wenige Wellen: kein Urteil), Speichern ohne stilles Neurechnen, Sperren bei fehlenden Daten,
  Anlass-Welle.
- Seit 23.101 im Cockpit: die Zeile mit dem Urteil in allen Fällen (ohne Urteil, nicht belegt, belegt, zu wenige Fälle, kein Urteil,
  ältere Fassung), Vertrag mit `hl_staking_studie` auf einem vom Modul gerechneten Urteil; im Skript die Zeile unter dem Termin,
  maskiert und ohne Farbe.
- Seit 23.102: eigene Tagesreihe (erster Stand je UTC-Tag bleibt; späterer Stand und misslungener Abruf ändern nichts; UTC-Tag,
  nicht Ortszeit; Datenbank von vor 23.102 wird beim Öffnen ergänzt), Takt zu Tagesbeginn (2 Minuten nach Mitternacht UTC einmal
  außer der Reihe, nicht jede Minute), stehengebliebene Tagesdatei in Antwort, Bericht und Karte, Tage mit Abbau über dem
  Tagesdurchsatz (an den letzten acht Tagen der echten Datei: fünf von sieben), Nachstellung des Stands vom 15.11.2026. In der
  Prüfung: Ende der Daten im Bericht („nicht in den Daten“ gegen „keine Welle“, Vermerk beim Urteil, Alltag mit bewerteten Tagen bis
  vor einer Woche ohne Vermerk). Kreuzprobe beim Bau: Urteil mit dem Code von 23.101 gespeichert, mit 23.102 gelesen -- unverändert.
- Mutationen und Browser-Probe: Zahlen in der Übergabe (Abschnitte zu den Paketen 23.100 bis 23.102).

## 8. Offen

- **Gegenseite ohne Tagesdatei** (U258): die Liste der wartenden Einzahlungen direkt vom Knoten (`pending_deposits`). Ob der
  öffentliche Knoten sie liefert und wie groß sie ist, ist auf dem Pi zu prüfen. Ebenso die Zahl der Validatoren für die Dauer des
  Auszahlungslaufs -- spätestens bis 21.02.2027, dann ist die Zahl vom 25.10.2026 zu alt.
- **Zählweise der Tagesdatei** (Abschnitt 3a): Zählt sie Zusammenlegungen mit? Debug 145 zeigt seit 23.102 die Tage mit zu
  schnellem Abbau seit Mai 2025.
- **Quelle für die Lücke** 26.10.2026 bis zum Beginn der eigenen Reihe: keine gefunden.
- Auszahlungstag je Vollabzug aus dem Stand des Auszahlungslaufs (heute nur als Fenster „bis zu 6,9 Tage danach“).
- ETH, das frei ist und auf die Auszahlung wartet (Status `withdrawal_possible`): eine große Liste, vorerst weggelassen.
- Namen zu den Adressen der großen Abzieher (keine Quelle ohne Schlüssel).
- `staking.db` ist noch nicht im Backup (U257). Die Tagesdatei lässt sich neu laden; die eigene Tagesreihe, die Stundenstände und
  das gespeicherte Urteil nicht.
- Einstellung des Knotens im Dashboard statt über die Umgebung.
- U255: gerechnet am 15.11.2026, „nicht belegt“ (Abschnitt 6b). Die Karte bleibt ein Messwert. **Zweite Prüfung** frühestens nach
  fünf weiteren Wellen; vorher festzulegen: Datenquelle (eigene Tagesreihe), Anschluss an die Tagesdatei, Umgang mit der Lücke.

## 9. Quellen (gelesen 14.11.2026; validatorqueue.com und das GitHub-Projekt erneut am 15.11.2026)

- Konsens-Spezifikation Electra: https://ethereum.github.io/consensus-specs/electra/beacon-chain/
- validatorqueue.com (Stand 14.11.2026: Abzug 251.274 ETH, Zugang 904.393 ETH, Zusammenlegungen 194.432 ETH, 796.121 Validatoren,
  Auszahlungslauf 6,9 Tage): https://www.validatorqueue.com/
- Tagesdatei und ihre Beschreibung: https://github.com/etheralpha/validatorqueue-com (Beschreibung und `pectra_convert.py` am
  14.11.2026 für Abschnitt 6a erneut gelesen: erste Messung je UTC-Tag; alte Werte × 32 umgerechnet; am 15.11.2026: kein Hinweis auf
  ein Ende der Datei, Quelle laut Beschreibung beaconcha.in; die Website nennt „Data provided by pectrified.com“)
- Berichte vom Pi: Debug 145 vom 15.11.2026 03:23 UTC (Abruf, Stand, letzte acht Tage der Tagesdatei) und Debug 147 vom 15.11.2026
  03:24 UTC (Urteil, alle Zahlen in Abschnitt 6b)
- beaconcha.in, Warteschlangen und Zugang: https://docs.beaconcha.in/use-cases/queue-wait-times ,
  https://docs.beaconcha.in/
- Fremde Auswertung über den öffentlichen Knoten: https://oanor.com/el/api/ethstakingqueue-api/get-v1-exit
- Juli 2025: https://www.fxstreet.com/cryptocurrencies/news/ethereum-validator-exit-hits-nine-days-waiting-with-nearly-2b-in-eth-ready-to-exit-the-network-202507230524
- September 2025 und Januar 2026: https://www.tradingview.com/news/cointelegraph:4c0307acc094b:0-ethereum-staking-sees-tidal-shift-as-validator-exit-queue-clears-out/
- Oktober 2026: https://thedefiant.io/news/blockchains/ethereum-exit-queue-eases-to-767-000-eth-after-metamask-validator-exits ,
  https://cryptonews.net/news/ethereum/33541370/
- November 2026: https://cryptoticker.io/en/ethereum-price-below-2000-record-staking-etf-outflows/ ,
  https://cryptoticker.io/en/ethereum-price-1958-dollars-staking-exit-queue-november-13-2026/
