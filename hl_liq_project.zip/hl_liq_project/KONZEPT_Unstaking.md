# KONZEPT Unstaking (U254, U255) — wann wird gestaktes ETH frei, und folgt darauf ein Kursrückgang?

Stand 14.11.2026 (Fable 5.2). Anlass: Nachricht des Nutzers vom 14.11.2026 19:57 — „wenn sehr große Mengen Ethereum vom Staking
abgerufen werden, [kommt] es häufig zu signifikanten Kursrückgängen … Prüfe, ob diese Daten bereits im Projekt erfasst werden und
erstelle einen Indikator in den Cockpit hinein, welcher einen Termin nennt, wann größere Mengen unstaked werden.“
**Status: Stufe 1 gebaut mit Paket 23.100 (U254): Daten und Anzeige. Stufe 2 (U255): Die Prüfung ist mit Paket 23.101 gebaut
(`hl_staking_studie.py`, Debug 147) und rechnet beim ersten Lauf auf dem Pi -- ein Urteil gibt es erst dann. Regeln in Abschnitt 6,
Klarstellungen vor dem ersten Lauf in 6a.**

---

## 0. Kurzfassung

- **Bestand:** Das Projekt erfasste bisher keine Staking-Daten (Suche im ganzen Paket nach Staking, Validator, Warteschlange: nichts).
- **Der Termin ist keine Prognose, sondern steht in der Kette.** Wer ETH aus dem Staking abzieht, bekommt vom Protokoll einen festen
  Zeitpunkt zugeteilt. Das neue Modul `hl_staking.py` liest diese Zeitpunkte und bildet daraus einen Kalender „frei ab“.
- **Im Cockpit (nur ETH):** Karte „Unstaking“ mit Summe, „alles frei bis“, der nächsten großen Freigabe als Termin, Kalender je Tag,
  größtem Abzieher und der Gegenseite; dazu eine Zeile mit dem Termin direkt unter dem Kernsatz. Klasse B (gemessen): blau, ohne
  Warnfarbe.
- **Nicht belegt ist die zweite Hälfte der Beobachtung** — dass auf große Abzüge Kursrückgänge folgen. Dafür ist eine Prüfung vorab
  festgelegt (Abschnitt 6) und seit 23.101 gebaut: **Debug 147** rechnet sie einmal und hält das Urteil fest; die Karte im Cockpit
  nennt es als Text. Erst ein bestandener Test macht aus dem Messwert ein Warnsignal und einen Teil der Prognose.
- **Debug 145** (★ Unstaking: Stand als Text) fragt beide Quellen selbst ab und zeigt, ob der Abruf vom Pi aus gelingt. **Debug 146**
  ist der Selbsttest. **Debug 147** (★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?) ist die Prüfung, **Debug 148** ihr
  Selbsttest.

## 1. Bestand im Projekt

Geprüft am 14.11.2026 im Paket 23.99: kein Modul, keine Tabelle und kein Abruf zu Staking, Validatoren oder Warteschlangen der
Beacon-Chain. Die Makro-Daten (ETF-Flüsse, Stablecoins) und die Börsenflüsse sind etwas anderes. Die Daten sind neu zu erfassen.

## 2. Wie Unstaking bei Ethereum abläuft

Quelle der Regeln: Konsens-Spezifikation „Electra“ (https://ethereum.github.io/consensus-specs/electra/beacon-chain/, gelesen
14.11.2026).

1. **Anmeldung.** Ein Validator meldet den Austritt an. Die Kette teilt ihm sofort eine Austritts-Epoche zu (`exit_epoch`).
2. **Warteschlange.** Je Epoche (384 s) dürfen höchstens 256 ETH das Staking verlassen (`MAX_PER_EPOCH_ACTIVATION_EXIT_CHURN_LIMIT`).
   Das sind 57.600 ETH am Tag. Ist mehr angemeldet, verschiebt sich der Austritt nach hinten.
3. **Sperrfrist.** Nach dem Austritt dauert es 256 Epochen, rund 27,3 Stunden, bis das ETH ausgezahlt werden darf
   (`withdrawable_epoch`). Diesen Zeitpunkt nennt das Modul **„frei ab“**.
4. **Auszahlung.** Vollabzüge zahlt der Auszahlungslauf aus: 16 Auszahlungen je Block, der Reihe nach über alle Validatoren. Eine
   Runde dauert bei 796.121 Validatoren 6,9 Tage (so zeigt es validatorqueue.com am 14.11.2026 als „Sweep Delay“). Ein Vollabzug kommt
   also zwischen „frei ab“ und knapp 7 Tage danach auf dem Konto an.
5. **Teilabzüge** (seit Mai 2025 möglich, für Validatoren mit bis zu 2.048 ETH): Sie durchlaufen dieselbe Begrenzung, bekommen
   ebenfalls ein „frei ab“ und werden dann sofort ausgezahlt (bis zu 8 je Block), ohne den Auszahlungslauf.
6. **Zusammenlegungen** sehen in der Liste der Kette aus wie Abzüge: Der Quell-Validator bekommt eine Austritts-Epoche. Sein ETH
   geht aber an einen anderen Validator und bleibt gestakt. Sie müssen abgezogen werden — am 14.11.2026 waren das 194.432 ETH neben
   251.274 ETH echter Abzüge.

Was die Kette nicht zeigt: ob frei gewordenes ETH an den Markt kommt. Ein Abzug kann ein Wechsel des Betreibers sein, eine
Vorsichtsmaßnahme oder der erste Schritt zu einem neuen Staking.

## 3. Datenquellen

| Quelle | Was | Schlüssel | Rolle |
|---|---|---|---|
| Beacon-Knoten, Standard-API (Voreinstellung `https://ethereum-beacon-api.publicnode.com`) | jeder angemeldete Abzug mit seinem Zeitpunkt | nein | Hauptquelle, stündlich |
| Tagesdatei von validatorqueue.com (`historical_data.json` im GitHub-Projekt `etheralpha/validatorqueue-com`) | Warteschlangen je Tag seit 21.05.2023, Zahl der Validatoren | nein | Rückblick, Gegenseite, Ersatz; alle 6 Stunden |

Fünf Fragen an den Knoten je Lauf: Kopf der Kette (`/eth/v1/beacon/headers/head`), Zusammenlegungen
(`…/states/finalized/pending_consolidations`), Validatoren mit Status `active_exiting` und `exited_unslashed`
(`…/states/finalized/validators?status=…`), Teilabzüge (`…/pending_partial_withdrawals`).

- **Sicherungen.** Liegt der Kopf des Knotens mehr als 150 Slots (30 Minuten) neben der Uhr, gilt sein Stand nicht: Seine
  Zeitpunkte wären falsch (Knoten kommt nicht mit, oder die Zeitrechnung der Kette wurde geändert). Ohne die Liste der
  Zusammenlegungen gibt es keinen Stand vom Knoten: Die Summe wäre zu hoch. Fehlen nur Teilabzüge oder die Sperrfrist-Liste, gilt der
  Stand mit Hinweis.
- **Ersatz.** Antwortet der Knoten nicht und ist die Tagesdatei höchstens 2 Tage alt, zeigt das Cockpit einen Kalender, der aus der
  Länge der Schlange geschätzt ist (57.600 ETH je Tag, dann die Sperrfrist) — gekennzeichnet als Schätzung, ohne Teilabzüge und ohne
  Abzieher. Sonst zeigt es keinen Wert und nennt die Gründe.
- **Eigener Knoten.** Die Umgebungsvariable `HL_STAKING_KNOTEN` setzt andere Knoten (mehrere mit Komma, der Reihe nach).
  `HL_STAKING=0` schaltet den Abruf ab.
- **Verworfen:** die Schnittstelle von beaconcha.in. Sie liefert dieselben Größen fertig gerechnet, verlangt aber einen Schlüssel;
  der kostenlose Zugang endet nach 30 Tagen (https://docs.beaconcha.in/, gelesen 14.11.2026).
- **Nicht aus der Sandbox prüfbar:** der Abruf über das Netz. Die Form der Antworten folgt der Spezifikation der Beacon-API; dass
  der öffentliche Knoten diese Fragen ohne Schlüssel beantwortet, zeigt eine fremde Auswertung, die ihn als Quelle nennt
  (https://oanor.com/el/api/ethstakingqueue-api/get-v1-exit). **Den Beweis liefert erst Debug 145 auf dem Pi.**
- **Was die Tagesdatei ist** (laut ihrer Beschreibung, am 14.11.2026 nachgelesen): Die Quelle misst alle rund 15 Minuten und hält
  je UTC-Tag die erste Messung fest. Bis zum 06.05.2025 zählte die Kette die Schlangen in Validatoren; die Datei trägt für diese Zeit
  Validatoren × 32 als ETH (Umrechnung der Quelle; die Zeilen vom Mai 2023 sind durch 32 teilbar). Vom 07.05. bis 21.05.2025 stehen
  Validatoren statt ETH in den Feldern -- diese 15 Tage nutzt das Projekt nicht. Einzelne Tage fehlen; die Berichte zählen sie.

Last: Bei einer Schlange von 250.000 ETH sind das stündlich wenige MB (gepackt übertragen). Die Antwort wird in Stücken gelesen; im
Speicher bleibt je Validator nur ein kleiner Eintrag, nicht der Text der Liste. Ein ganzer Abruf am Knoten darf höchstens 150
Sekunden dauern, die Tagesdatei 60.

## 4. Was gemessen und gezeigt wird — Schwellen fest und vorab

- **Angemeldet, noch nicht frei** = Vollabzüge (in der Schlange und in der Sperrfrist) + Teilabzüge, in ETH nach Kontostand;
  im Cockpit dazu der Wert in USD zum frischen Kurs.
- **Kalender „frei ab“** je UTC-Tag. Schon Fälliges zählt unter heute.
- **Alles Angemeldete frei bis** = spätester Zeitpunkt „frei ab“.
- **Große Freigabe** = die nächste Folge von UTC-Tagen mit jeweils mindestens **28.800 ETH** „frei ab“ (die Hälfte des
  Höchstdurchsatzes von 57.600 ETH). Das ist der Termin, den das Cockpit nennt.
- **Abzieher:** Vollabzüge je Auszahlungsadresse, genannt ab **10.000 ETH**, höchstens drei.
- **Gegenseite:** ETH, das darauf wartet, gestakt zu werden (Tagesdatei).
- **Frische:** Stand des Knotens höchstens 3 Stunden alt; Tagesdatei als Ersatz und für die Gegenseite höchstens 2 Tage zurück (eine
  ältere Gegenseite wird nicht gezeigt); die Dauer des Auszahlungslaufs aus der Zahl der Validatoren bis 30 Tage (sie ändert sich
  langsam).
- **Farbe:** keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer Balken, Punkt).

Nicht enthalten: ETH, das schon frei ist und auf den Auszahlungslauf wartet; Abzüge aus Liquid-Staking-Pools, die ohne Austritt
eines Validators bedient werden; der genaue Auszahlungstag eines einzelnen Vollabzugs.

## 5. Einordnung — was über Abzüge und Kurs bekannt ist

Bekannte Wellen aus Berichten (nicht systematisch geprüft, Quellen in Abschnitt 9):

| Zeit | Schlange | Anlass laut Berichten | Kurs im Umfeld |
|---|---|---|---|
| Juli 2025 | 1.920 → über 520.000 ETH in einer Woche | nach einem Kursanstieg von rund 160 % | Anstieg davor |
| September 2025 | Höchststand 2,67 Mio. ETH | — | — |
| Anfang Oktober 2026 | 166.000 → 850.736 ETH in drei Tagen | Sicherheitsvorfall bei MetaMask, vorsorgliche Austritte | — |
| 06.–13.11.2026 | 4.320 → 269.951 ETH | — | ETH in einer Woche −12,4 % auf 1.958 USD; ETF-Abflüsse 696 Mio. USD in acht Handelstagen |

Drei Lesarten sind möglich, und die Fälle oben passen zu verschiedenen:
1. **Abzug vor Verkauf** (die Beobachtung des Nutzers): große Abzüge kündigen Angebot an.
2. **Abzug als Folge:** Nach einem starken Anstieg (Juli 2025) oder während eines Rückgangs (November 2026) wird abgezogen. Dann
   läuft der Kurs voraus, nicht hinterher.
3. **Abzug ohne Verkauf:** Betreiberwechsel und Vorsichtsmaßnahmen (MetaMask) setzen kein ETH frei, das an den Markt soll.

Größenordnung: Das Protokoll gibt höchstens 57.600 ETH am Tag frei — beim Kurs vom 13.11.2026 rund 113 Mio. USD. Das liegt in der
Größe der täglichen ETF-Abflüsse dieses Monats (rund 87 Mio. USD je Handelstag). Zugleich warteten am 14.11.2026 mehr als dreimal so
viele ETH auf den Weg ins Staking (904.393) wie heraus (251.274).

## 6. Studie, vorab festgelegt (U255) — gebaut mit Paket 23.101, rechnet beim ersten Lauf von Debug 147

Festgelegt am 14.11.2026, bevor die Tagesdatei mit Kursen zusammengeführt wurde. **Offenlegung:** Bekannt waren mir nur die vier
Wellen aus Abschnitt 5 und die dort genannten Kurse; eine Auswertung gab es nicht.

- **Daten.** Schlange der Abzüge je UTC-Tag aus der Tagesdatei (erste Messung des Tages), ab 21.05.2023. Ausgeschlossen: 07.05. bis
  21.05.2025 und Tage ohne Eintrag. Tagesschlüsse von ETH und BTC (UTC) aus den Kerzen, die der Ausblick nutzt.
- **Fall A — Anmeldung.** Tag d, an dem die Schlange gegen den Vortag um mindestens 57.600 ETH wächst (ein voller Tagesdurchsatz).
  Ein neuer Fall beginnt erst nach 14 Tagen ohne solchen Tag.
- **Fall B — Freigabe.** Der UTC-Tag, an dem das erste ETH der Welle frei wird: d − 1 + Wartezeit des Vortags + 27,3 Stunden,
  aufgerundet.
- **Zielgröße.** Log-Rendite von ETH minus der von BTC über 7 Tage ab dem Beginn des Falltags. So zählt nur, was ETH für sich
  verliert. Beschreibend daneben: ETH allein, 14 Tage, tiefster Stand im Fenster.
- **Test.** Mittel der Zielgröße nach den Fällen minus Mittel über alle Tage; einseitig (nach den Fällen niedriger). Nullverteilung
  durch Verschieben der Fallreihe gegen die Kursreihe im Kreis (alle Verschiebungen um mindestens 30 Tage). Zwei Hypothesen (A, B),
  Holm.
- **Urteil.** „Belegt“ nur mit p Holm < 0,05, mindestens 8 Fällen und gleichem Vorzeichen in beiden Hälften der Fälle. Mit weniger
  als 8 Fällen: „zu wenige Fälle“, kein Urteil. Sonst „nicht belegt“.
- **Proben.** Nullprobe: zufällig gelegte Fälle gleicher Zahl werden in höchstens 5 % der Läufe „belegt“. Positivkontrolle: ein
  eingebauter Nachteil von 3 % wird gefunden; der Bericht nennt die Nachweisgrenze bei der vorhandenen Zahl von Fällen.
- **Erwartung, ehrlich:** Seit 2023 gibt es vermutlich nur ein bis zwei Dutzend Wellen. Die Nachweisgrenze wird hoch liegen; ein
  „nicht belegt“ hieße dann „mit diesen Daten nicht zu zeigen“, nicht „widerlegt“.
- **Folgen.** Belegt: eigene Lampe mit Warnfarbe im Cockpit, Termin im Ausblick (als Ausnahmelage oder als breitere Spanne — das
  wird dann eigens festgelegt). Nicht belegt: Die Karte bleibt ein Messwert. Neue Prüfung frühestens nach fünf weiteren Wellen.

## 6a. Klarstellungen vor dem ersten Lauf (14.11.2026, Paket 23.101)

Abschnitt 6 bleibt, wie er ist. Beim Bau waren Einzelheiten festzulegen, die dort offen sind. Sie stehen hier, festgelegt am
14.11.2026, bevor die Prüfung auf echten Daten lief. **Offenlegung:** Gesehen habe ich beim Bau acht Zeilen der Tagesdatei (fünf vom
Mai 2023, drei vom 16. bis 18.05.2024 mit einem Sprung der Schlange) und die Beschreibung der Quelle -- keine Kurse dazu und keine
Auswertung. Die allgemeine Kursgeschichte von ETH ist mir bekannt; die Regeln aus Abschnitt 6 standen vorher fest.

**Daten**
- Schlange und Wartezeit: Tabelle `st_tag` (Tagesdatei, erste Messung des UTC-Tags). Der Zuwachs „gegen den Vortag“ ist damit zu
  Beginn des Falltags bekannt; angemeldet wurde im Lauf des Vortags.
- Kurs zu Beginn eines UTC-Tags: Schluss der letzten 30-Minuten-Kerze des Vortags aus `swing.db` (Binance-Perpetuals, dieselben
  Kerzen, die der Ausblick nutzt); fehlt sie, die Eröffnung der ersten Kerze des Tags. „Tiefster Stand“: kleinstes Tagestief der 7
  Tage, nur aus Tagen mit mindestens 40 von 48 Kerzen.
- Bewertet werden die Tage vom zweiten Tag der Schlange bis zu ihrem letzten, soweit das 7-Tage-Fenster abgeschlossen ist.
- **Sperren:** Gerechnet wird nur mit mindestens 365 solchen Tagen und Kursen für mindestens 98 % von ihnen. Sonst nennt der Bericht
  den Grund und speichert nichts.

**Beschreibend, ohne Test** (neben den Größen aus Abschnitt 6): ETH gegen BTC in den 7 Tagen vor dem Falltag (lief der Kurs voraus --
Lesart 2 aus Abschnitt 5?) und über 7 Tage ab dem Tag nach dem Falltag (hält der Unterschied, wenn man einen Tag später misst?).
Hintergrund der zweiten Größe: Die Prüfung nimmt an, dass die erste Messung des Tages kurz nach Mitternacht UTC liegt (laut Quelle
misst sie alle rund 15 Minuten). Läge sie später am Tag, enthielte die Zielgröße Stunden vor der Messung.

**Fälle**
- Fall A: Fehlt die Messung des Vortags (Lücke oder ausgeschlossene Zeit), kann der Tag kein Fall sein. Die 14 Tage Ruhe zählen ab
  dem letzten Tag mit Zuwachs ab der Schwelle, nicht ab dem Beginn der Welle; Tage ohne Messung gelten dabei nicht als solcher Tag.
  Fälle, in deren 14 Tagen Vorlauf Messungen fehlen, kennzeichnet der Bericht.
- Fall B: Vortag + aufgerundet(Wartezeit des Vortags in Tagen + 98.304 s ÷ 86.400 s). Das ist der erste UTC-Tag, der beginnt,
  nachdem das erste ETH der Welle frei geworden sein kann. Ohne Wartezeit des Vortags gibt es keinen Fall B. Fallen zwei Wellen auf
  denselben Tag B, zählt er einmal.
- Ein Fall zählt nur, wenn sein 7-Tage-Fenster abgeschlossen ist; sonst steht er im Bericht als „offen“.

**Test**
- Verschoben wird um 30 bis N − 30 Tage (N = Zahl der bewerteten Tage), also N − 59 Lagen. p = (1 + Zahl der Lagen mit einem
  Unterschied mindestens so niedrig wie beobachtet) ÷ (1 + Zahl der Lagen). p wird nie 0.
- Holm zählt immer zwei Fragen. Hat eine Frage weniger als 8 Fälle, geht sie mit p = 1 ein -- die andere muss dann p < 0,025 zeigen.
- Hälften: die Fälle nach der Zeit geordnet, die ersten ⌊n ÷ 2⌋ und der Rest; jede Hälfte gegen das Mittel aller bewerteten Tage.
  „Gleiches Vorzeichen“ heißt: beide negativ.
- Gesamturteil: „belegt“, wenn A oder B belegt ist; „zu wenige Fälle“, wenn beide zu wenige haben; sonst „nicht belegt“.

**Proben im Bericht**
- Nullprobe: 2.000 zufällige Lagen -- Fälle A gleicher Zahl mit mindestens 15 Tagen Abstand, Fälle B = A plus einer der echten
  Abstände -- durchlaufen das ganze Verfahren. „Höchstens 5 %“ gilt als eingehalten bis 5 % plus drei Standardfehler der Simulation
  (bei 2.000 Läufen 6,5 %). Grund der Toleranz: Holm hält das Verfahren knapp unter 5 % (beim Bau gemessen auf erfundenen
  Kursreihen: 4,4 bis 4,9 %); die Probe soll grobe Fehler finden, nicht am Zufall der Simulation scheitern. **Fällt sie durch, lautet
  das Urteil „kein Urteil“.**
- Positivkontrolle und Nachweisgrenze: In 400 zufälligen Lagen wird die Zielgröße an den Falltagen um einen Nachteil gesenkt (0,5 %
  bis 20 % in Schritten von 0,5 %). „Gefunden“ heißt: p < 0,025 (Holm bei zwei Fragen), Unterschied und beide Hälften negativ. Der
  Bericht nennt die Fundquote bei 3 % und als Nachweisgrenze den kleinsten Nachteil mit mindestens 80 % Fundquote. Dass ein
  eingebauter Nachteil von 3 % gefunden wird, zeigt der Selbsttest an einer erfundenen Welt (dort in die Kurse eingebaut).
- Feste Saat für alle Zufallszahlen: Der Bericht ist wiederholbar.

**Ein Urteil, nicht viele**
- Der erste Lauf mit ausreichenden Daten rechnet, speichert das Urteil mit Datum, Zahlen und Prüfsumme der Eingabe (`staking.db`,
  Tabelle `st_meta`, Schlüssel `studie_u255`) und zeigt es von da an nur noch. Kein stilles Neurechnen mit jedem neuen Tag.
- Neu gerechnet wird nur mit einer neuen Fassung der Regeln (Kennung im Modul, heute `U255/1`); das alte Urteil wird dann mit Datum
  abgelegt. Der Bericht zählt die Wellen seit dem Urteil; die neue Prüfung nach fünf weiteren Wellen wird eigens festgelegt.
- **Anlass-Welle:** Die Beobachtung des Nutzers stammt aus den Tagen vor dem 14.11.2026. Wellen mit Falltag A vom 01. bis 14.11.2026
  zählt das Urteil nach der Regel mit. Daneben steht eine Gegenprobe ohne sie -- zur Einordnung; sie ändert das Urteil nicht.

**Nicht geändert:** Schwelle (57.600 ETH), Ruhe (14 Tage), Zielgröße, einseitiger Test, mindestens 30 Tage Verschiebung, Holm, die drei
Bedingungen für „belegt“, die Folgen.

**Wo es steht:** Modul `hl_staking_studie.py`; **Debug 147** „★ Unstaking: Folgt auf große Abzüge ein Kursrückgang?“ (rechnet beim
ersten Lauf; lädt vorher die Tagesdatei, wenn sie fehlt oder älter als 6 Stunden ist); **Debug 148** Selbsttest. Die Karte
„Unstaking“ im Cockpit nennt das gespeicherte Urteil als Text unter dem Termin; Debug 143 und Debug 145 nennen es auch.

## 7. Proben (Pakete 23.100 und 23.101)

- `hl_staking.py --selbsttest` (Debug 146): Zeitrechnung der Kette (Gegenprobe an einer fremden Angabe: Epoche 454.434 = 13.06.2026
  04:57:59 UTC), Lesen der Listen in Stücken jeder Größe, andere Feldreihenfolge, kaputte Einträge, Zusammenlegungen abgezogen
  (Gegenprobe: ohne die Liste wäre die Summe zu hoch), Kalender gegen eine Rechnung von Hand, große Freigabe an ihrer Schwelle,
  Tagesdatei mit alten und neuen Feldnamen, Ersatzkalender, Frische auf die Sekunde, über Mitternacht, Fehlerfälle je Quelle, der
  echte Abruf (urllib, gzip, HTTP-Fehler, keine Verbindung) gegen einen Webserver auf demselben Rechner, Wortprobe.
- `hl_cockpit.py --selbsttest`: Abgleich der Karte mit der Quelle, Schwelle, Satz mit Termin, ohne Quelle kein Wert, nur ETH; Vertrag
  mit `hl_staking` auf einer Datenbank, die das Modul selbst gefüllt hat.
- `hl_viz.py --selbsttest-cockpit`: Karte und Zeile unter dem Kernsatz im Skript, Debug-Läufe 145 und 146, Start des Fadens.
- `hl_staking_studie.py --selbsttest` (Debug 148, seit 23.101): Fälle A und B von Hand (Schwelle, Ruhe, Lücke, ausgeschlossene
  Zeit), drei echte Zeilen der Tagesdatei vom Mai 2024, Kurs zu Tagesbeginn und Zielgröße gegen eine Rechnung von Hand, Kreistest
  gegen eine Gegenrechnung ohne numpy, Holm, Urteil an den Grenzen, zufällige Lagen, Nullprobe mit Gegenprobe (ein zu großzügiges
  Verfahren fällt durch), Fundquote (abgekürzte gegen volle Rechnung), Welten Ende zu Ende (ohne Nachteil: nicht belegt; mit
  eingebautem Nachteil: belegt; wenige Wellen: kein Urteil), Speichern ohne stilles Neurechnen, Sperren bei fehlenden Daten,
  Anlass-Welle.
- Seit 23.101 im Cockpit: die Zeile mit dem Urteil in allen Fällen (ohne Urteil, nicht belegt, belegt, zu wenige Fälle, kein Urteil,
  ältere Fassung), Vertrag mit `hl_staking_studie` auf einem vom Modul gerechneten Urteil; im Skript die Zeile unter dem Termin,
  maskiert und ohne Farbe.
- Mutationen und Browser-Probe: Zahlen in der Übergabe (Abschnitte zu den Paketen 23.100 und 23.101).

## 8. Offen

- **Abruf vom Pi aus** (Debug 145 nach dem Einspielen).
- Auszahlungstag je Vollabzug aus dem Stand des Auszahlungslaufs (heute nur als Fenster „bis zu 6,9 Tage danach“).
- ETH, das frei ist und auf die Auszahlung wartet (Status `withdrawal_possible`): eine große Liste, vorerst weggelassen.
- Namen zu den Adressen der großen Abzieher (keine Quelle ohne Schlüssel).
- `staking.db` ist noch nicht im Backup. Die Tagesdatei lässt sich neu laden; die eigenen Stundenstände nicht.
- Einstellung des Knotens im Dashboard statt über die Umgebung.
- U255: **der erste Lauf der Prüfung auf dem Pi (Debug 147).** Danach, je nach Urteil: bei „belegt“ Lampe und Platz im Ausblick eigens
  festlegen; sonst bleibt die Karte ein Messwert.

## 9. Quellen (gelesen 14.11.2026)

- Konsens-Spezifikation Electra: https://ethereum.github.io/consensus-specs/electra/beacon-chain/
- validatorqueue.com (Stand 14.11.2026: Abzug 251.274 ETH, Zugang 904.393 ETH, Zusammenlegungen 194.432 ETH, 796.121 Validatoren,
  Auszahlungslauf 6,9 Tage): https://www.validatorqueue.com/
- Tagesdatei und ihre Beschreibung: https://github.com/etheralpha/validatorqueue-com (Beschreibung und `pectra_convert.py` am
  14.11.2026 für Abschnitt 6a erneut gelesen: erste Messung je UTC-Tag; alte Werte × 32 umgerechnet)
- beaconcha.in, Warteschlangen und Zugang: https://docs.beaconcha.in/use-cases/queue-wait-times ,
  https://docs.beaconcha.in/
- Fremde Auswertung über den öffentlichen Knoten: https://oanor.com/el/api/ethstakingqueue-api/get-v1-exit
- Juli 2025: https://www.fxstreet.com/cryptocurrencies/news/ethereum-validator-exit-hits-nine-days-waiting-with-nearly-2b-in-eth-ready-to-exit-the-network-202507230524
- September 2025 und Januar 2026: https://www.tradingview.com/news/cointelegraph:4c0307acc094b:0-ethereum-staking-sees-tidal-shift-as-validator-exit-queue-clears-out/
- Oktober 2026: https://thedefiant.io/news/blockchains/ethereum-exit-queue-eases-to-767-000-eth-after-metamask-validator-exits ,
  https://cryptonews.net/news/ethereum/33541370/
- November 2026: https://cryptoticker.io/en/ethereum-price-below-2000-record-staking-etf-outflows/ ,
  https://cryptoticker.io/en/ethereum-price-1958-dollars-staking-exit-queue-november-13-2026/
