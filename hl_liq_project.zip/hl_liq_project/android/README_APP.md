# HL Liquidationen — Android-App

Ein schlanker Rahmen um das Dashboard des Pi: WebView mit Adressverwaltung,
Ziehen-zum-Neuladen, dunklem Vollbild und verständlicher Fehlermeldung. Die
Darstellung selbst kommt von `hl_viz.py`, das für Handy-Bildschirme umgebaut
wurde — die App enthält keine eigene Chart-Logik, deshalb ist sie klein und
robust.

## APK bauen (Android Studio, einmalig ~10 Minuten)

1. Android Studio installieren (https://developer.android.com/studio).
2. „Open" → diesen Ordner `android/` wählen. Beim ersten Öffnen lädt Studio
   Gradle und das SDK 34 nach (Internet nötig, einige hundert MB).
3. Menü **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Die Datei liegt danach unter `app/build/outputs/apk/release/app-release.apk`
   (mit dem Debug-Schlüssel signiert — für den Eigengebrauch ausreichend).
5. APK aufs Handy kopieren, antippen, „Installation aus unbekannten Quellen"
   erlauben.

Ohne Android Studio, per Kommandozeile (JDK 17, Android-SDK und Gradle 8.7
installiert, `ANDROID_HOME` gesetzt):

    gradle assembleRelease

## Ohne APK: als Web-App

Chrome auf dem Handy → `http://<Pi-Adresse>:8765` → Menü ⋮ →
**Zum Startbildschirm hinzufügen**. Das Dashboard bekommt ein Icon und läuft
wie eine App (das Manifest liefert Name, Icon und Vollbild). Einziger
Unterschied zur APK: kein Ziehen-zum-Neuladen — dafür „Neu laden" auf der Seite.

## Voraussetzungen auf dem Pi

Das Dashboard muss im LAN erreichbar sein: `hl_viz.py --serve --host 0.0.0.0`
(die systemd-Unit macht das bereits). Die Adresse des Pi zeigt `hostname -I`.
Handy und Pi müssen im selben WLAN sein; die App spricht http, kein TLS.

## Erststart

Die App fragt nach der Adresse, etwa `192.168.1.50` — Schema und Port 8765
ergänzt sie selbst. Ändern: Zurück-Taste lange drücken.
