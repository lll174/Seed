package de.hlliq.dashboard

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.graphics.Bitmap
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

/**
 * Zeigt das Dashboard des Pi in einem WebView. Die Seite selbst ist für
 * Handy-Bildschirme gebaut; die App liefert nur Rahmen, Adressverwaltung,
 * Ziehen-zum-Neuladen und eine verständliche Fehlermeldung.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private val prefs by lazy { getSharedPreferences("hl", MODE_PRIVATE) }
    private var lastError: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        swipe = findViewById(R.id.swipe)

        with(web.settings) {
            javaScriptEnabled = true            // das Dashboard ist reines JavaScript
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_NO_CACHE  // immer die aktuelle Seite vom Pi
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        web.setBackgroundColor(0xFF0D1117.toInt())
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                lastError = null
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                swipe.isRefreshing = false
                lastError?.let { showError(it) }
            }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?,
                                         error: WebResourceError?) {
                // nur der Hauptrahmen zählt; einzelne Datenabfragen meldet die Seite selbst
                if (request?.isForMainFrame == true) {
                    lastError = error?.description?.toString() ?: "unbekannter Fehler"
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false   // alles im WebView bleiben lassen
            }
        }
        swipe.setOnRefreshListener { web.reload() }
        swipe.setColorSchemeColors(0xFF3BA55D.toInt())

        // Beim ersten Start nach der Adresse fragen, danach merken
        val url = prefs.getString("url", null)
        if (url.isNullOrBlank()) askAddress(first = true) else web.loadUrl(url)
    }

    private fun askAddress(first: Boolean) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            hint = getString(R.string.prompt_hint)
            setText(prefs.getString("url", "http://"))
            setSelection(text.length)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.prompt_title)
            .setView(input)
            .setPositiveButton(R.string.prompt_ok) { _, _ ->
                var u = input.text.toString().trim()
                if (u.isEmpty()) { if (first) askAddress(true); return@setPositiveButton }
                if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
                if (!Regex(":\\d+$").containsMatchIn(u.removeSuffix("/"))) u = u.removeSuffix("/") + ":8765"
                prefs.edit().putString("url", u).apply()
                web.loadUrl(u)
            }
        if (!first) dlg.setNegativeButton(R.string.prompt_cancel, null)
        dlg.setCancelable(!first)
        dlg.show()
    }

    private fun showError(msg: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.app_name)
            .setMessage(getString(R.string.err_load, msg))
            .setPositiveButton(R.string.btn_retry) { _, _ -> web.reload() }
            .setNeutralButton(R.string.btn_address) { _, _ -> askAddress(first = false) }
            .show()
    }

    /** Zurück-Taste: erst im WebView zurück, langes Drücken öffnet die Adresseingabe. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyLongPress(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) { askAddress(first = false); return true }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
