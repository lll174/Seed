#!/usr/bin/env python3
"""
hl_aktien.py -- Aktienmarkt als Barometer (U148), Studie U147 und Kurzstudie K1/K2 (Version 2026-09-23.66).

Regeln: KONZEPT_Ausblick.md 13.7, 13.8, 13.12, 13.13 (vorab festgelegt am 11.10.2026, vor jedem Lauf auf echten Daten).
Eigene Datei aktien.db neben hl_liq.db, ein ARCHIV: jeder abgerufene Wert mit Abrufzeit, nie überschrieben; eine Revision wird
eine neue Zeile (ak_wert), die jüngste Fassung je Tag steht in ak_aktuell. Vor dem Schreiben prüft jede Quelle Schema, Frische
und ob statt CSV/JSON eine HTML-Seite kam; je Quelle Backoff und Schutzschalter. Zeiten der Jobs in New Yorker Zeit mit dem
NYSE-Kalender; „kein neuer Schluss“ heißt Tag geschlossen, kein Fehler.

Quellen (frei, ohne Konto):
  FRED (Schlüssel aus hl_makro): SP500, NASDAQ100, VIXCLS, VXVCLS, BAA10Y, STLFSI4, NFCI, BAMLH0A0HYM2 (nur 3 Jahre sichtbar --
        beim ersten Lauf wird die Historie aus makro.db übernommen, dort seit 05.10. gesichert)
  Deribit: DVOL BTC und ETH stündlich (Zusatz X1 im Ausblick)
  Hyperliquid HIP-3 „xyz“ (trade.xyz): S&P 500, Nasdaq-100, VIX, Top 10, MSTR, STRC, COIN, HOOD, CRCL, TLT rund um die Uhr --
        Stand je 30 min (metaAndAssetCtxs) und 30-min-/Tageskerzen (candleSnapshot); Historie nur seit der Listung
  CFTC TFF (gpe5-46if): Bitcoin 133741, E-mini S&P 500 13874A, E-mini Nasdaq-100 209742 (samstags)
  FINRA Reg SHO (CNMSshvol, abends): IBIT, MSTR, COIN
  Farside: Spot-ETF-Flüsse BTC je Fonds, mit Abrufzeit (Revisionen sichtbar)
  Cboe-CSV (optional, still bei Fehler): VIX9D, VVIX
  SEC EDGAR: Strategy (CIK 1050446) -- BTC-Bestand aus den 8-K, Aktienzahl (XBRL); User-Agent einstellbar (accesstokens.json
        „sec“ -> „user_agent“ oder HL_SEC_UA), Vorgabe des Nutzers „hl_liq_project admin@localhost.com“
Schreibt nur aktien.db; wirkt auf nichts sonst (Zusage bis 25.10.: keine Konfluenz, kein Labor, keine Prognose, kein Treiber).

  python3 hl_aktien.py --abrufen --db <hl_liq.db> [--quelle fred,drb,xyz,cftc,finra,farside,cboe,sec]
  python3 hl_aktien.py --text --db <hl_liq.db>          Stand des Archivs und Barometer als Text
  python3 hl_aktien.py --u147 --db <hl_liq.db>          Studie U147 „Fällt BTC, wenn der S&P 500 fällt?“ (Bericht)
  python3 hl_aktien.py --k12 --db <hl_liq.db>           Kurzstudie K1/K2 ETF-Flüsse und IBIT-Leerverkäufe (Bericht)
  python3 hl_aktien.py --selbsttest
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import numpy as np

VERSION_MODUL = "2026-09-23.66"
TAG = 86_400
BAR = 1800
NY = ZoneInfo("America/New_York")
UTC = timezone.utc
UA_BROWSER = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0 (aktien)"}
SEC_UA_STANDARD = "hl_liq_project admin@localhost.com"
HL_INFO = "https://api.hyperliquid.xyz/info"
XYZ_DEX = "xyz"
# laut trade.xyz-Übersicht (13.8); fehlt ein Wert im Dex, wird er still übersprungen
XYZ_INDIZES = ("SP500", "XYZ100", "VIX")
XYZ_TOP10 = ("NVDA", "MSFT", "AAPL", "AMZN", "GOOGL", "META", "AVGO", "TSLA", "LLY", "MU")
XYZ_KRYPTO = ("MSTR", "STRC", "COIN", "HOOD", "CRCL")
XYZ_ANLEIHEN = ("TLT",)
XYZ_ALLE = XYZ_INDIZES + XYZ_TOP10 + XYZ_KRYPTO + XYZ_ANLEIHEN
XYZ_30M = ("SP500", "XYZ100", "VIX", "MSTR", "STRC")          # 30-min-Kerzen (Schockregel 13.1 c, Barometer)
FRED_REIHEN = {
    "SP500": ("S&P 500 (Schluss)", "2016-01-01"),
    "NASDAQ100": ("Nasdaq-100 (Schluss)", "2000-01-01"),
    "VIXCLS": ("VIX (Schluss)", "2000-01-01"),
    "VXVCLS": ("VIX3M (Schluss)", "2007-12-01"),
    "BAA10Y": ("Baa minus 10 J (%)", "2000-01-01"),
    "STLFSI4": ("Finanzstress St. Louis (wöchentlich)", "2000-01-01"),
    "NFCI": ("Finanzbedingungen Chicago (wöchentlich)", "2000-01-01"),
    "BAMLH0A0HYM2": ("Hochzinsaufschlag ICE BofA (%), nur 3 Jahre sichtbar", "2000-01-01"),
}
FRED_FRISCH_TAGE = {"STLFSI4": 16, "NFCI": 16}                  # wöchentlich; sonst 10 Tage (Feiertage, Wochenende)
CFTC_URL = "https://publicreporting.cftc.gov/resource/gpe5-46if.json"
CFTC_KONTRAKTE = {"133741": "Bitcoin (CME, 5 BTC)", "13874A": "E-mini S&P 500", "209742": "E-mini Nasdaq-100"}
CFTC_FELDER = {                                                # Feldnamen des Socrata-Schemas (TFF); tolerant gesucht
    "oi": (r"^open_interest_all$",),
    "lev_long": (r"^lev_money_positions_long(_all)?$",), "lev_short": (r"^lev_money_positions_short(_all)?$",),
    "am_long": (r"^asset_mgr_positions_long(_all)?$",), "am_short": (r"^asset_mgr_positions_short(_all)?$",),
    "dealer_long": (r"^dealer_positions_long(_all)?$",), "dealer_short": (r"^dealer_positions_short(_all)?$",),
}
FINRA_URL = "https://cdn.finra.org/equity/regsho/daily/CNMSshvol{tag}.txt"
FINRA_SYMBOLE = ("IBIT", "MSTR", "COIN")
FINRA_AB = "2024-01-02"
FINRA_JE_LAUF = 20
FARSIDE_BTC = "https://farside.co.uk/bitcoin-etf-flow-all-data/"
CBOE_URLS = {"VVIX": ("https://cdn.cboe.com/api/global/us_indices/daily_prices/VVIX_History.csv",
                      "https://cdn-api.cboe.com/api/global/us_indices/daily_prices/VVIX_History.csv"),
             "VIX9D": ("https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX9D_History.csv",
                       "https://cdn-api.cboe.com/api/global/us_indices/daily_prices/VIX9D_History.csv")}
SEC_CIK = "0001050446"                                          # Strategy Inc (vormals MicroStrategy)
SEC_SUBMISSIONS = f"https://data.sec.gov/submissions/CIK{SEC_CIK}.json"
SEC_AKTIEN = f"https://data.sec.gov/api/xbrl/companyconcept/CIK{SEC_CIK}/dei/EntityCommonStockSharesOutstanding.json"
SEC_8K_AB = "2024-01-01"
SEC_8K_JE_LAUF = 12
DRB_AB = "2021-03-24"                                           # Beginn von DVOL bei Deribit
DRB_FENSTER_H = 999
GBTC_START_BTC = 619_000.0                                      # ≈ GBTC-Bestand bei der Umwandlung (10.01.2024), Anker für K1
PAUSE_S = 1.0
TAKT_S = 60
SCHUTZ_MAX_S = 24 * 3600


# ================================================================================================ Kalender (NYSE, New York)

def _ostern(j: int) -> date:
    """Ostersonntag (gregorianisch, Meeus/Jones/Butcher)."""
    a = j % 19; b = j // 100; c = j % 100; d = b // 4; e = b % 4; f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30; i = c // 4; k = c % 4; L = (32 + 2 * e + 2 * i - h - k) % 7; m = (a + 11 * h + 22 * L) // 451
    mon = (h + L - 7 * m + 114) // 31; tag = ((h + L - 7 * m + 114) % 31) + 1
    return date(j, mon, tag)


def _nter_wochentag(j: int, mon: int, wtag: int, n: int) -> date:
    """n-ter Wochentag (0 = Montag) im Monat; n = -1: letzter."""
    if n > 0:
        d = date(j, mon, 1)
        d += timedelta(days=(wtag - d.weekday()) % 7)
        return d + timedelta(days=7 * (n - 1))
    d = date(j + (mon == 12), mon % 12 + 1, 1) - timedelta(days=1)
    return d - timedelta(days=(d.weekday() - wtag) % 7)


def _beobachtet(d: date, samstag_vorziehen: bool = True) -> date | None:
    """Fällt der Feiertag auf Samstag: Freitag davor (NYSE: nicht beim Neujahrstag); auf Sonntag: Montag danach."""
    if d.weekday() == 5:
        return d - timedelta(days=1) if samstag_vorziehen else None
    if d.weekday() == 6:
        return d + timedelta(days=1)
    return d


_SONDER_GESCHLOSSEN = {date(2018, 12, 5), date(2025, 1, 9)}     # Staatstrauer (Bush, Carter)


def nyse_feiertage(j: int) -> set:
    f = set()
    for d, vor in ((date(j, 1, 1), False), (date(j, 7, 4), True), (date(j, 12, 25), True)):
        b = _beobachtet(d, vor)
        if b is not None:
            f.add(b)
    if j >= 2022:
        b = _beobachtet(date(j, 6, 19))
        if b is not None:
            f.add(b)
    f |= {_nter_wochentag(j, 1, 0, 3), _nter_wochentag(j, 2, 0, 3), _ostern(j) - timedelta(days=2), _nter_wochentag(j, 5, 0, -1),
          _nter_wochentag(j, 9, 0, 1), _nter_wochentag(j, 11, 3, 4)}
    return f | {d for d in _SONDER_GESCHLOSSEN if d.year == j}


def handelstag(d: date) -> bool:
    return d.weekday() < 5 and d not in nyse_feiertage(d.year)


def ny_jetzt(ts: float | None = None) -> datetime:
    return datetime.fromtimestamp(time.time() if ts is None else ts, NY)


def boerse_offen(ts: float | None = None) -> bool:
    """Reguläre Handelszeit 9:30–16:00 New York an einem Handelstag (frühe Schlüsse nicht berücksichtigt)."""
    n = ny_jetzt(ts)
    return handelstag(n.date()) and (n.hour, n.minute) >= (9, 30) and n.hour < 16


def letzter_handelstag(bis: date) -> date:
    d = bis
    while not handelstag(d):
        d -= timedelta(days=1)
    return d


def ny_ts(d: date, stunde: int, minute: int = 0) -> int:
    """Unix-Zeit eines New Yorker Zeitpunkts an Tag d (Sommer-/Winterzeit richtig)."""
    return int(datetime(d.year, d.month, d.day, stunde, minute, tzinfo=NY).timestamp())


def tag_ts(s: str) -> int | None:
    try:
        return int(datetime.strptime(s[:10], "%Y-%m-%d").replace(tzinfo=UTC).timestamp())
    except (ValueError, TypeError):
        return None


def ts_datum(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), UTC).date()


# ================================================================================================ Datenhaltung (aktien.db)

SCHEMA = """
CREATE TABLE IF NOT EXISTS ak_wert (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, wert REAL,
    PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_aktuell (reihe TEXT NOT NULL, ts INTEGER NOT NULL, wert REAL, abgerufen INTEGER, fassungen INTEGER,
    PRIMARY KEY (reihe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_kerze (reihe TEXT NOT NULL, ts INTEGER NOT NULL, o REAL, h REAL, l REAL, c REAL, v REAL, abgerufen INTEGER,
    PRIMARY KEY (reihe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_text (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, inhalt TEXT,
    PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_abruf (ts INTEGER, quelle TEXT, ziel TEXT, ok INTEGER, zeilen INTEGER, ms INTEGER, fehler TEXT);
CREATE INDEX IF NOT EXISTS ix_ak_abruf ON ak_abruf(quelle, ts);
CREATE TABLE IF NOT EXISTS ak_meta (k TEXT PRIMARY KEY, v TEXT);
"""


def aktien_pfad(db: str) -> str:
    """aktien.db liegt neben der Hauptdatenbank (wie makro.db); HL_AKTIEN_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_AKTIEN_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "aktien.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung: Autocommit, jede Schreibtransaktion mit BEGIN IMMEDIATE (Projektregel)."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def lesen(pfad: str) -> sqlite3.Connection | None:
    """Nur lesen; legt nichts an."""
    if not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, check_same_thread=False)


def _transaktion(con, fn):
    con.execute("BEGIN IMMEDIATE")
    try:
        r = fn()
        con.execute("COMMIT")
        return r
    except BaseException:
        con.execute("ROLLBACK")
        raise


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM ak_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def meta_setzen(con, paare: dict) -> None:
    _transaktion(con, lambda: con.executemany("INSERT INTO ak_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                                              [(k, str(v)) for k, v in paare.items()]))


def _gleich(a, b) -> bool:
    if a is None or b is None:
        return a is None and b is None
    return abs(a - b) <= 1e-12 * max(1.0, abs(a), abs(b))


def archivieren(con, zeilen: list, abgerufen: int | None = None) -> int:
    """
    (reihe, ts, wert) ins Archiv: neu, wenn es (reihe, ts) noch nicht gibt oder der Wert von der jüngsten Fassung abweicht -- dann
    eine NEUE Zeile mit dieser Abrufzeit (Revision), die alte bleibt. ak_aktuell trägt die jüngste Fassung und die Zahl der Fassungen.
    Eine Transaktion. -> Zahl neuer Fassungen.
    """
    ab = int(abgerufen if abgerufen is not None else time.time())
    daten = [(str(r), int(t), float(w)) for r, t, w in zeilen if w is not None and math.isfinite(float(w))]
    if not daten:
        return 0
    reihen = sorted({r for r, _, _ in daten})

    def schreib():
        alt = {}
        for r in reihen:
            for t, w, n in con.execute("SELECT ts, wert, fassungen FROM ak_aktuell WHERE reihe=?", (r,)):
                alt[(r, int(t))] = (w, int(n or 1))
        neu_w, neu_a = [], []
        for r, t, w in daten:
            a = alt.get((r, t))
            if a is not None and _gleich(a[0], w):
                continue
            neu_w.append((r, t, ab, w))
            neu_a.append((r, t, w, ab, (a[1] + 1) if a else 1))
            alt[(r, t)] = (w, (a[1] + 1) if a else 1)
        con.executemany("INSERT OR IGNORE INTO ak_wert VALUES (?,?,?,?)", neu_w)
        con.executemany("INSERT INTO ak_aktuell VALUES (?,?,?,?,?) ON CONFLICT(reihe, ts) DO UPDATE SET wert=excluded.wert, "
                        "abgerufen=excluded.abgerufen, fassungen=excluded.fassungen", neu_a)
        return len(neu_w)
    return _transaktion(con, schreib)


def kerzen_schreiben(con, reihe: str, kerzen: list, abgerufen: int | None = None) -> int:
    """Nur abgeschlossene Kerzen (ts, o, h, l, c, v); eine schon gespeicherte bleibt (INSERT OR IGNORE). -> neue Kerzen."""
    ab = int(abgerufen if abgerufen is not None else time.time())
    zeilen = [(reihe, int(k[0]), *(float(x) for x in k[1:6]), ab) for k in kerzen]
    if not zeilen:
        return 0

    def schreib():
        vorher = con.total_changes
        con.executemany("INSERT OR IGNORE INTO ak_kerze VALUES (?,?,?,?,?,?,?,?)", zeilen)
        return con.total_changes - vorher
    return _transaktion(con, schreib)


def text_archivieren(con, reihe: str, ts: int, inhalt: dict, abgerufen: int | None = None) -> bool:
    ab = int(abgerufen if abgerufen is not None else time.time())
    s = json.dumps(inhalt, ensure_ascii=False, sort_keys=True)
    alt = con.execute("SELECT inhalt FROM ak_text WHERE reihe=? AND ts=? ORDER BY abgerufen DESC LIMIT 1", (reihe, int(ts))).fetchone()
    if alt and alt[0] == s:
        return False
    _transaktion(con, lambda: con.execute("INSERT OR IGNORE INTO ak_text VALUES (?,?,?,?)", (reihe, int(ts), ab, s)))
    return True


def protokoll(con, quelle: str, ziel: str, ok: bool, zeilen: int, ms: int, fehler: str = "") -> None:
    def schreib():
        con.execute("INSERT INTO ak_abruf VALUES (?,?,?,?,?,?,?)", (int(time.time()), quelle, ziel, int(bool(ok)), int(zeilen), int(ms),
                                                                    (fehler or "")[:240]))
        con.execute("DELETE FROM ak_abruf WHERE ts < ?", (int(time.time()) - 90 * TAG,))
    _transaktion(con, schreib)


def reihe(con, name: str, ab: int | None = None) -> tuple:
    """Jüngste Fassung einer Reihe: (ts, wert) als Arrays, aufsteigend."""
    q = "SELECT ts, wert FROM ak_aktuell WHERE reihe=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (name, int(ab)) if ab is not None else (name,)).fetchall()
    if not rows:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    a = np.array(rows, dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1]


def reihe_stand(con, name: str, stand: int) -> tuple:
    """Fassung, wie sie zum Zeitpunkt stand vorlag (Abrufzeit ≤ stand) -- für Rückblicke ohne spätere Revisionen."""
    rows = con.execute("SELECT w.ts, w.wert FROM ak_wert w JOIN (SELECT ts, MAX(abgerufen) AS a FROM ak_wert WHERE reihe=? AND "
                       "abgerufen<=? GROUP BY ts) m ON w.ts=m.ts AND w.abgerufen=m.a WHERE w.reihe=? ORDER BY w.ts",
                       (name, int(stand), name)).fetchall()
    if not rows:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    a = np.array(rows, dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1]


def kerzen(con, name: str, ab: int | None = None) -> dict | None:
    q = "SELECT ts, o, h, l, c, v FROM ak_kerze WHERE reihe=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (name, int(ab)) if ab is not None else (name,)).fetchall()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}


def letzter_ts(con, name: str, tabelle: str = "ak_aktuell") -> int | None:
    r = con.execute(f"SELECT MAX(ts) FROM {tabelle} WHERE reihe=?", (name,)).fetchone()
    return int(r[0]) if r and r[0] is not None else None


# ================================================================================================ Netz

def http(url: str, timeout: int = 30, art: str = "json", kopf: dict | None = None, daten: bytes | None = None):
    """(Inhalt, Fehlertext, HTTP-Status) -- wirft nie. art: json | text | bytes. daten: POST-Körper (JSON)."""
    h = dict(kopf or UA_BROWSER)
    if daten is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, headers=h, data=daten)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            roh = r.read(60 * 1024 * 1024)
            status = r.status
    except urllib.error.HTTPError as e:
        try:
            rest = e.read()[:160].decode("utf-8", "replace")
        except Exception:
            rest = ""
        return None, f"HTTP {e.code}: {rest}".strip(), e.code
    except Exception as e:
        return None, f"{type(e).__name__}: {e}", None
    if art == "bytes":
        return roh, None, status
    text = roh.decode("utf-8", "replace")
    if art == "text":
        return text, None, status
    try:
        return json.loads(text), None, status
    except ValueError:
        return None, "kein JSON: " + text[:80].replace("\n", " "), status


def ist_html(text: str) -> bool:
    """Der Stooq-Fall: statt CSV/Text kommt eine HTML-Seite (Sperre, Anmeldung, Fehlerseite)."""
    t = (text or "").lstrip()[:200].lower()
    return t.startswith("<!doctype html") or t.startswith("<html") or "<head" in t or "<body" in t


def sec_user_agent(datei: str | None = None) -> str:
    """User-Agent für SEC EDGAR: HL_SEC_UA, sonst accesstokens.json -> "sec" -> "user_agent", sonst die Vorgabe des Nutzers."""
    k = (os.environ.get("HL_SEC_UA") or "").strip()
    if k:
        return k
    datei = datei or os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
    try:
        with open(datei, encoding="utf-8") as f:
            d = json.load(f)
        v = str((d.get("sec") or {}).get("user_agent") or "").strip()
        return v or SEC_UA_STANDARD
    except (OSError, ValueError, AttributeError):
        return SEC_UA_STANDARD


# ================================================================================================ Parser (reine Funktionen)

def _zahl(v) -> float | None:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) if math.isfinite(float(v)) else None
    s = str(v).strip().replace(",", "").replace("$", "")
    if s in ("", ".", "-", "–", "—", "NaN", "nan", "null", "None"):
        return None
    neg = s.startswith("(") and s.endswith(")")
    try:
        x = float(s.strip("()"))
    except ValueError:
        return None
    return -x if neg else x


def drb_stunden_parse(waehrung: str, d) -> tuple:
    """Deribit get_volatility_index_data (resolution 3600): {"result":{"data":[[ts_ms, o, h, l, c]], "continuation": ts|null}}."""
    r = (d or {}).get("result") or {} if isinstance(d, dict) else {}
    zeilen = []
    for z in r.get("data") or []:
        if not isinstance(z, (list, tuple)) or len(z) < 5:
            continue
        t = _zahl(z[0]); w = _zahl(z[4])
        if t and w is not None and w > 0:
            zeilen.append((f"drb:dvol_{waehrung.lower()}_h", int(t // 1000) // 3600 * 3600, w))
    return sorted(zeilen, key=lambda z: z[1]), r.get("continuation")


def xyz_stand_parse(d, dex: str = XYZ_DEX) -> dict:
    """
    metaAndAssetCtxs mit "dex": [meta, ctxs]; meta.universe[i].name („xyz:SP500“ oder „SP500“), ctxs[i] mit markPx, oraclePx,
    midPx, prevDayPx, dayNtlVlm, funding, openInterest (Zeichenketten). -> {Kürzel: {mark, oracle, mid, vortag, funding, oi, vol}}.
    """
    if not isinstance(d, list) or len(d) < 2 or not isinstance(d[0], dict) or not isinstance(d[1], list):
        raise ValueError("unerwartetes Format (metaAndAssetCtxs)")
    uni = d[0].get("universe") or []
    out = {}
    for a, c in zip(uni, d[1]):
        if not isinstance(a, dict) or not isinstance(c, dict):
            continue
        name = str(a.get("name") or "")
        kurz = name.split(":", 1)[1] if name.startswith(dex + ":") else name
        if not kurz:
            continue
        e = {"mark": _zahl(c.get("markPx")), "oracle": _zahl(c.get("oraclePx")), "mid": _zahl(c.get("midPx")),
             "vortag": _zahl(c.get("prevDayPx")), "funding": _zahl(c.get("funding")), "oi": _zahl(c.get("openInterest")),
             "vol": _zahl(c.get("dayNtlVlm")), "delisted": bool(a.get("isDelisted"))}
        out[kurz.upper()] = e
    return out


def xyz_kerzen_parse(d, jetzt_ms: int) -> list:
    """candleSnapshot: [{"t": open_ms, "T": close_ms, "o","h","l","c","v": str, "n": int}] -> abgeschlossene (ts_s, o, h, l, c, v)."""
    if not isinstance(d, list):
        raise ValueError("unerwartetes Format (candleSnapshot)")
    out = []
    for k in d:
        if not isinstance(k, dict):
            continue
        t, T = _zahl(k.get("t")), _zahl(k.get("T"))
        werte = [_zahl(k.get(x)) for x in ("o", "h", "l", "c", "v")]
        if t is None or T is None or any(w is None for w in werte) or T >= jetzt_ms:
            continue
        out.append((int(t // 1000), *werte))
    return sorted(out)


def _feld(datensatz: dict, muster: tuple) -> str | None:
    for m in muster:
        for k in datensatz:
            if re.match(m, k):
                return k
    return None


def cftc_parse(d) -> tuple:
    """
    Socrata (TFF, Futures only): [{"report_date_as_yyyy_mm_dd": "2026-10-06T00:00:00.000", "cftc_contract_market_code": "133741",
    "open_interest_all": "21432", "lev_money_positions_long": "5731", ...}] -> (Zeilen (reihe, ts, wert), fehlende Felder).
    """
    if not isinstance(d, list):
        raise ValueError("unerwartetes Format (CFTC)")
    zeilen, fehlen = [], set()
    for r in d:
        if not isinstance(r, dict):
            continue
        t = tag_ts(str(r.get("report_date_as_yyyy_mm_dd") or "")[:10])
        code = str(r.get("cftc_contract_market_code") or "").strip()
        if t is None or not code:
            continue
        for name, muster in CFTC_FELDER.items():
            k = _feld(r, muster)
            if k is None:
                fehlen.add(name); continue
            w = _zahl(r.get(k))
            if w is not None:
                zeilen.append((f"cftc:{code}:{name}", t, w))
    return zeilen, sorted(fehlen)


def finra_parse(text: str, symbole=FINRA_SYMBOLE) -> list:
    """CNMSshvol: 'Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market' (Werte mit Nachkommastellen). -> Zeilen."""
    if ist_html(text):
        raise ValueError("HTML statt Textdatei")
    zeilen_txt = (text or "").strip().splitlines()
    if not zeilen_txt or not zeilen_txt[0].startswith("Date|Symbol|ShortVolume"):
        raise ValueError("unerwarteter Kopf: " + (zeilen_txt[0][:60] if zeilen_txt else "leer"))
    kopf = zeilen_txt[0].split("|")
    i_s, i_e, i_t = kopf.index("ShortVolume"), kopf.index("ShortExemptVolume"), kopf.index("TotalVolume")
    out = []
    for z in zeilen_txt[1:]:
        f = z.split("|")
        if len(f) < len(kopf) or f[1] not in symbole:
            continue
        t = tag_ts(f"{f[0][:4]}-{f[0][4:6]}-{f[0][6:8]}")
        if t is None:
            continue
        for name, i in (("short", i_s), ("exempt", i_e), ("total", i_t)):
            w = _zahl(f[i])
            if w is not None:
                out.append((f"finra:{f[1]}:{name}", t, w))
    return out


_MONATE = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def farside_fonds_parse(html: str, coin: str = "btc") -> list:
    """
    Farside-Tabelle je Fonds: Kopfzeile mit den Kürzeln (IBIT, FBTC, … GBTC, BTC, Total), Datenzeilen „11 Jan 2024“ mit Mio USD;
    Klammern = negativ, „-“ = keine Daten (nicht null). Zeilen ohne Datum (Total, Average, Maximum, Minimum) fallen weg.
    """
    if not html or "<tr" not in html:
        raise ValueError("keine Tabelle")
    kopf = None; out = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S):
        cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
        if len(cells) < 3:
            continue
        if kopf is None and any(c in ("IBIT", "GBTC", "FBTC", "ETHA", "ETHE") for c in cells):
            kopf = [re.sub(r"\s+", "", c) for c in cells]
            continue
        m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
        if kopf is None or not m or m.group(2) not in _MONATE:
            continue
        t = tag_ts(f"{m.group(3)}-{_MONATE[m.group(2)]:02d}-{int(m.group(1)):02d}")
        for name, c in zip(kopf[1:], cells[1:]):
            if not name:
                continue
            w = _zahl(c)
            if w is not None:
                out.append((f"farside:{coin}:{name}", t, w))
    if kopf is None:
        raise ValueError("Kopfzeile mit den Fonds nicht gefunden")
    return out


def cboe_parse(name: str, text: str) -> list:
    """Cboe-CSV: 'DATE,OPEN,HIGH,LOW,CLOSE' (VIX9D) bzw. 'DATE,VVIX'; Datum MM/DD/YYYY. Schluss bzw. letzte Spalte."""
    if ist_html(text):
        raise ValueError("HTML statt CSV")
    r = list(csv.reader(io.StringIO(text or "")))
    if not r or not r[0] or r[0][0].strip().upper() != "DATE":
        raise ValueError("unerwarteter Kopf: " + (",".join(r[0])[:60] if r else "leer"))
    kopf = [c.strip().upper() for c in r[0]]
    j = kopf.index("CLOSE") if "CLOSE" in kopf else len(kopf) - 1
    out = []
    for z in r[1:]:
        if len(z) <= j:
            continue
        s = z[0].strip()
        try:
            d = datetime.strptime(s, "%m/%d/%Y") if "/" in s else datetime.strptime(s[:10], "%Y-%m-%d")
        except ValueError:
            continue
        w = _zahl(z[j])
        if w is not None:
            out.append((f"cboe:{name}", int(d.replace(tzinfo=UTC).timestamp()), w))
    return out


def sec_8k_liste(d, ab: str = SEC_8K_AB) -> list:
    """submissions JSON: filings.recent (Spalten als Listen) -> [{acc, datum, doc, form}] der 8-K ab Datum, aufsteigend."""
    rec = ((d or {}).get("filings") or {}).get("recent") or {} if isinstance(d, dict) else {}
    acc, dat, form, doc = (rec.get(k) or [] for k in ("accessionNumber", "filingDate", "form", "primaryDocument"))
    out = []
    for a, t, f, p in zip(acc, dat, form, doc):
        if str(f).strip().upper() in ("8-K", "8-K/A") and str(t) >= ab and p:
            out.append({"acc": str(a), "datum": str(t)[:10], "doc": str(p), "form": str(f)})
    return sorted(out, key=lambda x: (x["datum"], x["acc"]))


def sec_dok_url(acc: str, doc: str, cik: str = SEC_CIK) -> str:
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-', '')}/{doc}"


_BESTAND_MUSTER = (
    re.compile(r"aggregate\s+of\s+approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
    re.compile(r"held\s+(?:an\s+aggregate\s+of\s+)?approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
    re.compile(r"holds?\s+(?:an\s+aggregate\s+of\s+)?approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
    re.compile(r"Aggregate\s+BTC\s+Holdings.{0,400}?(\d{1,3}(?:,\d{3})+)", re.I | re.S),
)


def sec_bestand_parse(html: str) -> float | None:
    """BTC-Bestand aus dem Text eines Strategy-8-K („… held an aggregate of approximately 640,031 bitcoins“ oder Tabelle
    „Aggregate BTC Holdings“). Nichts gefunden -> None (das 8-K betrifft dann etwas anderes)."""
    text = re.sub(r"<[^>]+>", " ", html or "")
    text = re.sub(r"&nbsp;|&#160;", " ", text)
    text = re.sub(r"\s+", " ", text)
    for m in _BESTAND_MUSTER:
        g = m.search(text)
        if g:
            w = _zahl(g.group(1))
            if w is not None and 1_000 <= w <= 5_000_000:
                return w
    return None


def sec_aktien_parse(d) -> list:
    """companyconcept dei:EntityCommonStockSharesOutstanding: units.shares [{end, val, accn, filed}] -> [(ts_end, Summe je Meldung)].
    Mehrere Einträge mit gleichem Stichtag und gleicher Meldung (Aktienklassen) werden addiert."""
    if not isinstance(d, dict):
        raise ValueError("unerwartetes Format (companyconcept)")
    je = {}
    for e in ((d.get("units") or {}).get("shares") or []):
        t = tag_ts(str(e.get("end") or ""))
        w = _zahl(e.get("val"))
        if t is None or w is None:
            continue
        je.setdefault((t, str(e.get("accn") or "")), set()).add(w)
    beste = {}
    for (t, acc), ws in je.items():
        s = float(sum(ws))                                         # gleiche Werte doppelt gemeldet: einmal; verschiedene Klassen: Summe
        if t not in beste or acc > beste[t][1]:
            beste[t] = (s, acc)
    return sorted((t, v[0]) for t, v in beste.items())


# ================================================================================================ Abruf je Quelle (Schutzschalter)

QUELLEN = ("xyz", "drb", "fred", "farside", "finra", "cboe", "cftc", "sec")
QUELLEN_NAME = {"xyz": "Hyperliquid xyz (Aktien-Perps)", "drb": "Deribit DVOL (stündlich)", "fred": "FRED", "farside": "Farside (ETF-Flüsse)",
                "finra": "FINRA Reg SHO", "cboe": "Cboe-CSV (optional)", "cftc": "CFTC (TFF)", "sec": "SEC EDGAR (Strategy)"}
OPTIONAL = {"cboe"}
# Termine (13.8): Archiv abends nach 18:00 ET und morgens 13:00 UTC für FRED, CFTC freitags nach der Veröffentlichung (15:30 ET)
# mit Nachholtermin montags, FINRA abends, xyz und DVOL alle 30 min.
TERMINE = {
    "xyz": {"alle_s": 1800},
    "drb": {"alle_s": 1800},
    "fred": {"slots": (("utc", 13, 0), ("ny", 18, 15))},
    "farside": {"slots": (("utc", 13, 0), ("utc", 1, 0))},
    "finra": {"slots": (("ny", 18, 45),), "rueckstand_s": 1800},
    "cboe": {"slots": (("ny", 18, 30),)},
    "cftc": {"slots": (("nywt", 4, 16, 0), ("nywt", 0, 10, 0))},
    "sec": {"slots": (("utc", 13, 30), ("utc", 23, 30))},
}


def _slot_ts(slot: tuple, jetzt: float) -> int:
    """Jüngster Zeitpunkt des Slots ≤ jetzt."""
    if slot[0] == "utc":
        d = datetime.fromtimestamp(jetzt, UTC).date()
        for k in range(0, 3):
            t = int(datetime(d.year, d.month, d.day, slot[1], slot[2], tzinfo=UTC).timestamp()) - k * TAG
            if t <= jetzt:
                return t
    if slot[0] == "ny":
        d = ny_jetzt(jetzt).date()
        for k in range(0, 3):
            t = ny_ts(d - timedelta(days=k), slot[1], slot[2])
            if t <= jetzt:
                return t
    if slot[0] == "nywt":                                        # (Wochentag 0 = Montag, Stunde, Minute) in New York
        d = ny_jetzt(jetzt).date()
        for k in range(0, 8):
            dd = d - timedelta(days=k)
            if dd.weekday() == slot[1]:
                t = ny_ts(dd, slot[2], slot[3])
                if t <= jetzt:
                    return t
    return 0


def faellig(con, quelle: str, jetzt: float) -> bool:
    pause = meta(con, f"pause_bis:{quelle}")
    if pause and jetzt < float(pause):
        return False
    letzt = meta(con, f"versuch:{quelle}")
    if letzt is None:
        return True
    letzt = float(letzt)
    T = TERMINE[quelle]
    if "alle_s" in T:
        return jetzt - letzt >= T["alle_s"] - 30
    if T.get("rueckstand_s") and int(meta(con, f"rueckstand:{quelle}", "0") or 0) > 0 and jetzt - letzt >= T["rueckstand_s"]:
        return True
    return letzt < max(_slot_ts(s, jetzt) for s in T["slots"])


class Abruf:
    """Ein Abruf-Lauf: eigene Schreibverbindung, Protokoll je Quelle, Schutzschalter (Pause 30 min · 2^(n−1), höchstens 24 h)."""

    def __init__(self, pfad: str, makro_pfad: str | None = None, http_fn=None, jetzt_fn=None, log=None, schlafen=True):
        self.pfad = pfad; self.con = verbinden(pfad); self.http = http_fn or http; self.jetzt = jetzt_fn or time.time
        self.log = log or (lambda *a: None); self.makro_pfad = makro_pfad; self.schlafen = schlafen

    def close(self):
        self.con.close()

    def _pause(self, s: float):
        if self.schlafen:
            time.sleep(s)

    def lauf(self, quelle: str) -> dict:
        t0 = time.time(); jetzt = self.jetzt()
        meta_setzen(self.con, {f"versuch:{quelle}": int(jetzt)})
        try:
            neu, info = getattr(self, "_" + quelle)()
            ok, fehler = True, ""
        except Exception as e:
            neu, info, ok, fehler = 0, "", False, f"{type(e).__name__}: {e}"[:240]
        ms = int((time.time() - t0) * 1000)
        protokoll(self.con, quelle, info[:60] if ok else "", ok, neu, ms, fehler if not ok else info)
        if ok:
            meta_setzen(self.con, {f"ok:{quelle}": int(jetzt), f"fehler_n:{quelle}": 0, f"pause_bis:{quelle}": 0, f"info:{quelle}": info[:200]})
        else:
            n = int(meta(self.con, f"fehler_n:{quelle}", "0") or 0) + 1
            pause = 0 if quelle in OPTIONAL else min(SCHUTZ_MAX_S, 1800 * 2 ** (n - 1))
            meta_setzen(self.con, {f"fehler_n:{quelle}": n, f"pause_bis:{quelle}": int(jetzt + pause), f"fehler:{quelle}": fehler})
        self.log(f"  {QUELLEN_NAME.get(quelle, quelle)}: {'ok' if ok else 'FEHLER'} · {neu} neue Fassungen · {ms} ms"
                 + (f" · {info}" if ok and info else "") + (f" · {fehler}" if not ok else ""))
        return {"quelle": quelle, "ok": ok, "neu": neu, "ms": ms, "info": info, "fehler": fehler}

    # ---------------------------------------------------------------- FRED (Schlüssel aus hl_makro)
    def _makro_import(self) -> int:
        """Einmalig: die Historie des Hochzinsaufschlags aus makro.db (dort seit 05.10. gesichert) mit ihren Abrufzeiten übernehmen --
        nur Tage vor dem ersten eigenen Wert, damit keine ältere Fassung eine jüngere verdeckt."""
        if meta(self.con, "import_makro_hy") is not None or not self.makro_pfad or not os.path.exists(self.makro_pfad):
            return 0
        try:
            mc = sqlite3.connect(f"file:{self.makro_pfad}?mode=ro", uri=True, timeout=10)
            try:
                rows = mc.execute("SELECT ts, wert, abgerufen FROM mk_reihe WHERE reihe='fred:BAMLH0A0HYM2' ORDER BY ts").fetchall()
            finally:
                mc.close()
        except sqlite3.Error:
            return 0
        erst = self.con.execute("SELECT MIN(ts) FROM ak_aktuell WHERE reihe='fred:BAMLH0A0HYM2'").fetchone()[0]
        neu = 0
        je_abruf: dict = {}
        for t, w, ab in rows:
            if erst is None or int(t) < int(erst):
                je_abruf.setdefault(int(ab or 0), []).append(("fred:BAMLH0A0HYM2", int(t), w))
        for ab in sorted(je_abruf):
            neu += archivieren(self.con, je_abruf[ab], ab or int(self.jetzt()))
        meta_setzen(self.con, {"import_makro_hy": neu})
        return neu

    def _fred(self) -> tuple:
        import hl_makro as MK
        neu = self._makro_import()
        k = MK.fred_schluessel_lesen()
        jetzt = int(self.jetzt()); fehler = []; alt = []
        for sid, (_, start0) in FRED_REIHEN.items():
            letzt = letzter_ts(self.con, f"fred:{sid}")
            start = start0 if letzt is None else ts_datum(letzt - 60 * TAG).isoformat()     # Revisionen der letzten 60 Tage
            if k:
                d, err, _ = self.http(MK.fred_api_url(sid, start, k), timeout=MK.FRED_TIMEOUT_API)
                zeilen = MK.fred_api_parse(sid, d) if not err else []
            else:
                text, err, _ = self.http(MK.fred_url(sid, start), timeout=MK.FRED_TIMEOUT_CSV, art="text")
                if not err and ist_html(text):
                    err = "HTML statt CSV"
                zeilen = MK.fred_parse(sid, text) if not err else []
            if err:
                fehler.append(f"{sid}: {MK._geschwaerzt(err, k)}"); continue
            if not zeilen:
                fehler.append(f"{sid}: keine Zeilen"); continue
            neu += archivieren(self.con, zeilen, jetzt)
            juengst = max(t for _, t, _ in zeilen)
            if (jetzt - juengst) / TAG > FRED_FRISCH_TAGE.get(sid, 10):
                alt.append(f"{sid} zuletzt {ts_datum(juengst).strftime('%d.%m.')}")
            self._pause(PAUSE_S)
        if len(fehler) == len(FRED_REIHEN):
            raise RuntimeError("; ".join(fehler)[:240] + ("" if k else " (kein FRED-Schlüssel)"))
        return neu, "; ".join(fehler + alt)[:200]

    # ---------------------------------------------------------------- Deribit DVOL stündlich
    def _drb(self) -> tuple:
        neu = 0; jetzt = int(self.jetzt()); t0 = time.time(); rest = []
        for w in ("BTC", "ETH"):
            name = f"drb:dvol_{w.lower()}_h"
            letzt = letzter_ts(self.con, name)
            von = tag_ts(DRB_AB) if letzt is None else letzt - 2 * 3600
            while von < jetzt - 3600:
                if time.time() - t0 > 90:
                    rest.append(w); break
                bis = min(jetzt, von + DRB_FENSTER_H * 3600)
                d, err, _ = self.http("https://www.deribit.com/api/v2/public/get_volatility_index_data?currency="
                                      f"{w}&start_timestamp={von * 1000}&end_timestamp={bis * 1000}&resolution=3600")
                if err:
                    raise RuntimeError(f"{w}: {err}")
                z, _ = drb_stunden_parse(w, d)
                neu += archivieren(self.con, [x for x in z if x[1] + 3600 <= jetzt], jetzt)       # nur abgeschlossene Stunden
                von = bis
                self._pause(0.3)
        return neu, (f"Historie lädt noch: {', '.join(rest)}" if rest else "")

    # ---------------------------------------------------------------- Hyperliquid xyz
    def _hl(self, body: dict):
        d, err, _ = self.http(HL_INFO, daten=json.dumps(body).encode(), kopf={"User-Agent": "hl-dashboard/1.0 (aktien)"}, timeout=20)
        if err:
            raise RuntimeError(err)
        return d

    def _xyz(self) -> tuple:
        jetzt = int(self.jetzt())
        stand = xyz_stand_parse(self._hl({"type": "metaAndAssetCtxs", "dex": XYZ_DEX}))
        minute = jetzt // 60 * 60
        zeilen = []
        for kurz in XYZ_ALLE:
            e = stand.get(kurz)
            if not e or e.get("delisted"):
                continue
            for f in ("mark", "oracle", "mid"):
                if e.get(f) is not None:
                    zeilen.append((f"xyz:{kurz}:{f}", minute, e[f]))
        neu = archivieren(self.con, zeilen, jetzt)
        fehlt = [k for k in XYZ_ALLE if k not in stand]
        meta_setzen(self.con, {"xyz_stand": json.dumps({k: stand[k] for k in XYZ_ALLE if k in stand}), "xyz_ts": jetzt,
                               "xyz_fehlt": ",".join(fehlt)})
        info = []
        for kurz in XYZ_30M:
            if kurz not in stand:
                continue
            name = f"xyz:{kurz}:30m"
            letzt = letzter_ts(self.con, name, "ak_kerze")
            start = (jetzt - 60 * TAG) if letzt is None else letzt + BAR
            if start > jetzt - BAR:
                continue
            try:
                d = self._hl({"type": "candleSnapshot", "req": {"coin": f"{XYZ_DEX}:{kurz}", "interval": "30m",
                                                                "startTime": start * 1000, "endTime": jetzt * 1000}})
                neu += kerzen_schreiben(self.con, name, xyz_kerzen_parse(d, jetzt * 1000), jetzt)
            except (RuntimeError, ValueError) as e:
                info.append(f"{kurz} 30m: {e}"[:60])
            self._pause(1.0)
        heute = datetime.fromtimestamp(jetzt, UTC).date().isoformat()
        if meta(self.con, "xyz_1d_tag") != heute:                       # Tageskerzen einmal je Tag (Abstand zum Hoch, Struktur)
            for kurz in XYZ_ALLE:
                if kurz not in stand:
                    continue
                name = f"xyz:{kurz}:1d"
                letzt = letzter_ts(self.con, name, "ak_kerze")
                start = (jetzt - 500 * TAG) if letzt is None else letzt + TAG
                if start > jetzt - TAG:
                    continue
                try:
                    d = self._hl({"type": "candleSnapshot", "req": {"coin": f"{XYZ_DEX}:{kurz}", "interval": "1d",
                                                                    "startTime": start * 1000, "endTime": jetzt * 1000}})
                    neu += kerzen_schreiben(self.con, name, xyz_kerzen_parse(d, jetzt * 1000), jetzt)
                except (RuntimeError, ValueError) as e:
                    info.append(f"{kurz} 1d: {e}"[:60])
                self._pause(1.0)
            meta_setzen(self.con, {"xyz_1d_tag": heute})
        if fehlt:
            info.insert(0, "nicht im Dex: " + ", ".join(fehlt))
        return neu, "; ".join(info)[:200]

    # ---------------------------------------------------------------- CFTC TFF
    def _cftc(self) -> tuple:
        codes = list(CFTC_KONTRAKTE)
        letzt = [letzter_ts(self.con, f"cftc:{c}:oi") for c in codes]
        ab = "2017-12-01" if any(x is None for x in letzt) else ts_datum(min(letzt) - 35 * TAG).isoformat()
        where = (f"cftc_contract_market_code in({','.join(repr(c) for c in codes)}) AND "
                 f"report_date_as_yyyy_mm_dd >= '{ab}T00:00:00.000'")
        url = CFTC_URL + "?" + urllib.parse.urlencode({"$where": where, "$order": "report_date_as_yyyy_mm_dd", "$limit": "50000"})
        d, err, _ = self.http(url, timeout=60)
        if err:
            raise RuntimeError(err)
        zeilen, fehlen = cftc_parse(d)
        if not zeilen:
            raise RuntimeError("keine Zeilen" + (f"; Felder fehlen: {', '.join(fehlen)}" if fehlen else ""))
        neu = archivieren(self.con, zeilen, int(self.jetzt()))
        juengst = max(t for _, t, _ in zeilen)
        info = f"Bericht vom {ts_datum(juengst).strftime('%d.%m.%Y')}" + (f"; Felder fehlen: {', '.join(fehlen)}" if fehlen else "")
        return neu, info

    # ---------------------------------------------------------------- FINRA Reg SHO
    def _finra(self) -> tuple:
        jetzt = self.jetzt()
        try:
            erledigt = set(json.loads(meta(self.con, "finra_tage", "[]") or "[]"))
        except ValueError:
            erledigt = set()
        n = ny_jetzt(jetzt)
        bis = n.date() if (n.hour, n.minute) >= (18, 45) else n.date() - timedelta(days=1)
        tage, d = [], bis
        start = datetime.strptime(FINRA_AB, "%Y-%m-%d").date()
        while d >= start:
            if handelstag(d) and d.strftime("%Y%m%d") not in erledigt:
                tage.append(d)
            d -= timedelta(days=1)
        neu = 0; fehler = []; geholt = 0; fehlend = 0
        for d in tage[:FINRA_JE_LAUF]:
            s = d.strftime("%Y%m%d")
            text, err, st = self.http(FINRA_URL.format(tag=s), art="text", timeout=60)
            if st == 404:
                if (n.date() - d).days > 5:                              # nach 5 Tagen ohne Datei: als fehlend vermerken, nicht ewig fragen
                    erledigt.add(s); fehlend += 1
                continue
            if err:
                fehler.append(f"{s}: {err}"[:80]); continue
            try:
                z = finra_parse(text)
            except ValueError as e:
                fehler.append(f"{s}: {e}"); continue
            neu += archivieren(self.con, z, int(jetzt)); erledigt.add(s); geholt += 1
            self._pause(0.5)
        rest = max(0, len(tage) - FINRA_JE_LAUF)
        meta_setzen(self.con, {"finra_tage": json.dumps(sorted(erledigt)), "rueckstand:finra": rest})
        if tage and not geholt and not fehlend and fehler:
            raise RuntimeError("; ".join(fehler)[:240])
        return neu, (f"{geholt} Tage geladen, {rest} im Rückstand" + (f", {fehlend} Tage ohne Datei bei FINRA" if fehlend else "")
                     + (f"; {'; '.join(fehler)}" if fehler else ""))[:200]

    # ---------------------------------------------------------------- Farside
    def _farside(self) -> tuple:
        html, err, _ = self.http(FARSIDE_BTC, art="text", timeout=45)
        if err:
            raise RuntimeError(err)
        z = farside_fonds_parse(html, "btc")
        if not z:
            raise RuntimeError("keine Zeilen")
        jetzt = int(self.jetzt())
        neu = archivieren(self.con, z, jetzt)
        juengst = max(t for _, t, _ in z)
        return neu, f"jüngster Tag {ts_datum(juengst).strftime('%d.%m.%Y')}"

    # ---------------------------------------------------------------- Cboe (optional)
    def _cboe(self) -> tuple:
        neu = 0; fehler = []
        for name, urls in CBOE_URLS.items():
            text = None; err = "kein Versuch"
            for u in urls:
                text, err, _ = self.http(u, art="text", timeout=40)
                if not err and text and not ist_html(text):
                    break
                err = err or "HTML statt CSV"
            if err:
                fehler.append(f"{name}: {err}"[:80]); continue
            try:
                neu += archivieren(self.con, cboe_parse(name, text), int(self.jetzt()))
            except ValueError as e:
                fehler.append(f"{name}: {e}")
            self._pause(PAUSE_S)
        if len(fehler) == len(CBOE_URLS):
            raise RuntimeError("; ".join(fehler))
        return neu, "; ".join(fehler)

    # ---------------------------------------------------------------- SEC EDGAR (Strategy)
    def _sec(self) -> tuple:
        ua = {"User-Agent": sec_user_agent(), "Accept": "application/json, text/html"}
        d, err, st = self.http(SEC_SUBMISSIONS, kopf=ua, timeout=30)
        if err:
            raise RuntimeError(f"{err} (User-Agent „{ua['User-Agent']}“)")
        liste = sec_8k_liste(d)
        bekannt = set()
        for (inh,) in self.con.execute("SELECT inhalt FROM ak_text WHERE reihe='sec:8k'"):
            try:
                bekannt.add(json.loads(inh).get("acc"))
            except ValueError:
                pass
        offen = [e for e in reversed(liste) if e["acc"] not in bekannt]
        neu = 0; fehler = []; jetzt = int(self.jetzt())
        for e in offen[:SEC_8K_JE_LAUF]:
            html, err, _ = self.http(sec_dok_url(e["acc"], e["doc"]), art="text", kopf=ua, timeout=40)
            if err:
                fehler.append(f"{e['acc']}: {err}"[:80]); continue
            btc = sec_bestand_parse(html)
            t = tag_ts(e["datum"])
            text_archivieren(self.con, "sec:8k", t, {"acc": e["acc"], "datum": e["datum"], "doc": e["doc"], "btc": btc}, jetzt)
            if btc:
                neu += archivieren(self.con, [("sec:mstr_btc", t, btc)], jetzt)
            self._pause(0.5)
        if jetzt - float(meta(self.con, "sec_aktien_ts", "0") or 0) > 7 * TAG:
            d2, err2, _ = self.http(SEC_AKTIEN, kopf=ua, timeout=30)
            if err2:
                fehler.append(f"Aktienzahl: {err2}"[:80])
            else:
                try:
                    neu += archivieren(self.con, [("sec:mstr_aktien", t, v) for t, v in sec_aktien_parse(d2)], jetzt)
                    meta_setzen(self.con, {"sec_aktien_ts": jetzt})
                except ValueError as e:
                    fehler.append(f"Aktienzahl: {e}")
        rest = max(0, len(offen) - SEC_8K_JE_LAUF)
        return neu, (f"{min(len(offen), SEC_8K_JE_LAUF)} 8-K gelesen, {rest} offen" + (f"; {'; '.join(fehler)}" if fehler else ""))[:200]


# ================================================================================================ Takt (Dashboard-Prozess)

_TAKT = {"gestartet": False, "laeuft": None, "letzter": None, "fehler": None}
_LAUF = threading.Lock()


def abrufen(db: str, quellen=QUELLEN, nur_faellige: bool = True, log=None, http_fn=None, jetzt_fn=None) -> list:
    """Fällige (bzw. alle genannten) Quellen nacheinander abrufen; höchstens ein Lauf zur Zeit (Sperre im Prozess)."""
    import hl_makro as MK
    erg = []
    with _LAUF:
        A = Abruf(aktien_pfad(db), MK.makro_pfad(db), http_fn=http_fn, jetzt_fn=jetzt_fn, log=log)
        try:
            for q in quellen:
                if nur_faellige and not faellig(A.con, q, A.jetzt()):
                    continue
                _TAKT["laeuft"] = q
                erg.append(A.lauf(q))
        finally:
            _TAKT["laeuft"] = None
            A.close()
    return erg


def xyz_auffrischen(db: str, max_alter: int = 1800) -> bool:
    """
    Für den Ausblick (13.1): den xyz-Stand im Hintergrund holen, wenn er älter als max_alter ist. Kehrt sofort zurück -- die
    Anfrage des Dashboards wartet nie auf einen Abruf; läuft gerade ein Lauf des Takts, geschieht nichts (er holt xyz ohnehin).
    """
    if os.environ.get("HL_AKTIEN") == "0":
        return False
    con = lesen(aktien_pfad(db))
    alt = None
    if con is not None:
        try:
            alt = meta(con, "xyz_ts")
        finally:
            con.close()
    if alt and time.time() - float(alt) < max_alter:
        return False
    if _LAUF.locked():
        return False
    threading.Thread(target=lambda: abrufen(db, ("xyz",), nur_faellige=False), daemon=True, name="aktien-xyz").start()
    return True


def starten(db: str) -> bool:
    """Takt im Dashboard-Prozess: jede Minute nachsehen, welche Quelle fällig ist. Nicht für Selbsttest-Datenbanken, aus mit HL_AKTIEN=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_AKTIEN") == "0":
        return False
    _TAKT["gestartet"] = True

    def schleife():
        time.sleep(75)
        while True:
            try:
                r = abrufen(db)
                if r:
                    _TAKT["letzter"] = {"ts": int(time.time()), "erg": r}
                _TAKT["fehler"] = None
            except Exception as e:
                _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Aktien-Takt: {_TAKT['fehler']}", flush=True)
            time.sleep(TAKT_S)
    threading.Thread(target=schleife, daemon=True, name="aktien").start()
    return True


def quellen_stand(db: str) -> list:
    """Je Quelle: zuletzt ok, letzter Fehler, Pause, Info -- für die Anzeige „Datenquellen“ des Reiters Aktienmarkt."""
    con = lesen(aktien_pfad(db))
    out = []
    for q in QUELLEN:
        e = {"quelle": q, "name": QUELLEN_NAME[q], "optional": q in OPTIONAL}
        if con is not None:
            for k in ("ok", "versuch", "pause_bis", "fehler_n"):
                v = meta(con, f"{k}:{q}")
                e[k] = float(v) if v not in (None, "") else None
            e["fehler"] = meta(con, f"fehler:{q}") if (e.get("fehler_n") or 0) > 0 else None
            e["info"] = meta(con, f"info:{q}")
        out.append(e)
    if con is not None:
        con.close()
    return out


# ================================================================================================ Statistik-Bausteine

def phi(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def phi2(h: float, k: float, rho: float, n: int = 4000) -> float:
    """Standardisierte bivariate Normalverteilung P(X ≤ h, Y ≤ k; ρ) per Integration über Y (Trapez auf [−9, k])."""
    if abs(rho) >= 1:
        return phi(min(h, k)) if rho > 0 else max(0.0, phi(h) + phi(k) - 1)
    k = min(k, 9.0)
    t = np.linspace(-9.0, k, n)
    f = np.exp(-0.5 * t * t) / math.sqrt(2 * math.pi) * 0.5 * np.vectorize(math.erfc)(-(h - rho * t) / math.sqrt(2 * (1 - rho * rho)))
    return float(np.trapz(f, t)) if hasattr(np, "trapz") else float(np.trapezoid(f, t))


def wilson(k: int, n: int, z: float = 1.959964) -> tuple:
    if n <= 0:
        return (float("nan"), float("nan"))
    p = k / n; d = 1 + z * z / n
    m = (p + z * z / (2 * n)) / d; w = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, m - w), min(1.0, m + w))


def holm(p: list) -> list:
    """Holm-Bonferroni: angepasste p-Werte in der Reihenfolge der Eingabe."""
    m = len(p); o = sorted(range(m), key=lambda i: p[i]); out = [1.0] * m; best = 0.0
    for r, i in enumerate(o):
        best = max(best, min(1.0, (m - r) * p[i]))
        out[i] = best
    return out


def ols_hac(y: np.ndarray, x: np.ndarray, lag: int) -> dict:
    """y = a + b·x, Newey-West-Standardfehler (Bartlett, lag). -> {b, se, t, p, n}."""
    ok = np.isfinite(y) & np.isfinite(x)
    y, x = y[ok], x[ok]; n = len(y)
    if n < 10:
        return {"n": n}
    X = np.column_stack([np.ones(n), x])
    XtX_inv = np.linalg.inv(X.T @ X)
    b = XtX_inv @ X.T @ y
    u = y - X @ b
    Xu = X * u[:, None]
    S = Xu.T @ Xu
    for L in range(1, min(lag, n - 1) + 1):
        w = 1 - L / (lag + 1)
        G = Xu[L:].T @ Xu[:-L]
        S += w * (G + G.T)
    V = XtX_inv @ S @ XtX_inv
    se = math.sqrt(max(V[1, 1], 0.0))
    t = b[1] / se if se > 0 else float("nan")
    return {"b": float(b[1]), "se": se, "t": float(t), "p": float(2 * (1 - phi(abs(t)))) if math.isfinite(t) else float("nan"), "n": n}


def stat_bootstrap_idx(n: int, mittel_block: float, reps: int, rng) -> np.ndarray:
    """Stationärer Bootstrap (Politis & Romano 1994): Indexmatrix (reps, n), Blocklänge geometrisch mit Mittel mittel_block."""
    p = 1.0 / max(mittel_block, 1.0)
    start = rng.integers(0, n, size=(reps, n))
    neu = rng.random((reps, n)) < p
    neu[:, 0] = True
    idx = np.empty((reps, n), dtype=np.int64)
    for r in range(reps):
        cur = start[r, 0]
        for t in range(n):
            if neu[r, t]:
                cur = start[r, t]
            else:
                cur = (cur + 1) % n
            idx[r, t] = cur
    return idx


def phasen_null_spearman(x: np.ndarray, y: np.ndarray, k: int = 2000, seed: int = 0) -> tuple:
    """
    Spearman ρ und Nullverteilung aus k Phasen-Surrogaten des Merkmals (Ebisuzaki 1997) -- dieselbe Rechnung wie
    hl_makro_korr.phasen_null (U130), aber ohne deren Mindestlänge von 3 Jahren (die Kurzstudie hat 2,5 Jahre).
    """
    import hl_makro_korr as MKK
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 30:
        return float("nan"), None, n
    rx = MKK.raenge(xs); ry = MKK.raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    norm = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not norm > 0:
        return float("nan"), None, n
    rho = float(np.dot(zx, zy) / norm)
    a = np.abs(np.fft.rfft(zx)) * np.abs(np.fft.rfft(zy))
    gerade = n % 2 == 0
    mitte = a[1:-1] if gerade else a[1:]
    rng = np.random.default_rng(seed)
    out = np.empty(k)
    for s0 in range(0, k, 250):
        m = min(250, k - s0)
        v = 2.0 * (np.cos(rng.uniform(0.0, 2 * np.pi, (m, len(mitte)))) @ mitte)
        if gerade:
            v = v + a[-1] * rng.choice((-1.0, 1.0), m)
        out[s0:s0 + m] = v / n / norm
    return rho, out, n


def korrelation_ki(a: np.ndarray, b: np.ndarray, reps: int = 1000, block: float = 5.0, seed: int = 0) -> dict:
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]; n = len(a)
    if n < 20:
        return {"n": n}
    r = float(np.corrcoef(a, b)[0, 1])
    idx = stat_bootstrap_idx(n, block, reps, np.random.default_rng(seed))
    A, B = a[idx], b[idx]
    A = A - A.mean(axis=1, keepdims=True); B = B - B.mean(axis=1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        rr = (A * B).sum(axis=1) / np.sqrt((A * A).sum(axis=1) * (B * B).sum(axis=1))
    rr = rr[np.isfinite(rr)]
    return {"n": n, "r": r, "lo": float(np.quantile(rr, 0.05)), "hi": float(np.quantile(rr, 0.95))}


# ================================================================================================ Daten für die Studien

def kerzen_30m(db: str, coin: str) -> dict | None:
    """30-min-Kerzen eines Coins: swing.db (BTC, ETH, ZEC, XMR, HYPE ab 2020), regime.db (PAXG). Nur lesend."""
    import hl_regime as RG
    import hl_swing as SW
    pfad, tab = (SW.swing_pfad(db), "sw_klines") if coin in SW.COINS else (RG.regime_pfad(db), "rg_klines")
    if not os.path.exists(pfad):
        return None
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        rows = con.execute(f"SELECT ts, o, h, l, c FROM {tab} WHERE coin=? ORDER BY ts", (coin,)).fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        con.close()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4]}


def kurs_um(K: dict, zeiten: np.ndarray, max_frueher: int = 3600) -> np.ndarray:
    """Schlusskurs der 30-min-Kerze, die zum Zeitpunkt t endet (Eröffnung t − 30 min); fehlt sie, die jüngere davor, höchstens
    max_frueher Sekunden früher. Sonst NaN."""
    out = np.full(len(zeiten), np.nan)
    if K is None or not len(K["ts"]):
        return out
    ziel = np.asarray(zeiten, dtype=np.int64) - BAR
    j = np.searchsorted(K["ts"], ziel, side="right") - 1
    ok = (j >= 0)
    jj = np.clip(j, 0, None)
    ok &= K["ts"][jj] >= ziel - max_frueher
    out[ok] = K["c"][jj[ok]]
    return out


def btc_tagesschluss_00(db: str) -> tuple:
    """BTC-Tagesschluss 00:00 UTC ab 2016 (Coin Metrics PriceUSD aus makro.db): (Tag d, Kurs am Ende von d)."""
    import hl_makro as MK
    con = MK.lesen(MK.makro_pfad(db))
    if con is None:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    try:
        t, w = MK.Reihen(con)("cm:btc:PriceUSD")
    finally:
        con.close()
    return t, w


def sp500_reihe(db: str) -> tuple:
    con = lesen(aktien_pfad(db))
    if con is None:
        return [], np.zeros(0)
    try:
        t, w = reihe(con, "fred:SP500")
    finally:
        con.close()
    return [ts_datum(x) for x in t], w


# ================================================================================================ Studie U147 (13.12)

U147_TAG = (0.0, -0.01, -0.02, -0.03)
U147_WOCHE = (0.0, -0.03, -0.05)
U147_4W = (0.0, -0.05, -0.10)
U147_ZEITRAEUME = (("2020–2022", date(2020, 1, 1), date(2022, 12, 31)), ("2023–2026", date(2023, 1, 1), date(2099, 1, 1)),
                   ("seit 2020", date(2020, 1, 1), date(2099, 1, 1)))
U147_COINS = ("BTC", "ETH", "ZEC", "XMR", "HYPE")


def _wochen_letzte(datums: list) -> list:
    """Index des letzten Handelstags je Kalenderwoche (Freitag bzw. der letzte vor einem Feiertag)."""
    out = []
    for i, d in enumerate(datums):
        if i + 1 == len(datums) or datums[i + 1].isocalendar()[:2] != d.isocalendar()[:2]:
            out.append(i)
    return out


def _bedingung(rS: np.ndarray, rB: np.ndarray, schwelle: float, richtung: int, rho: float, sig_s: float) -> dict:
    """richtung −1: S&P < schwelle (bzw. < 0), Ereignis „BTC fiel“; +1: S&P > |schwelle|, Ereignis „BTC stieg“."""
    ok = np.isfinite(rS) & np.isfinite(rB)
    m = ok & ((rS < schwelle) if richtung < 0 else (rS > -schwelle))
    n = int(m.sum())
    if n == 0:
        return {"n": 0}
    k = int(((rB[m] < 0) if richtung < 0 else (rB[m] > 0)).sum())
    lo, hi = wilson(k, n)
    e = {"n": n, "k": k, "anteil": k / n, "lo": lo, "hi": hi, "mittel": float(np.mean(rB[m])), "median": float(np.median(rB[m]))}
    if n >= 5 and np.std(rS[m]) > 0:
        e["beta"] = float(np.polyfit(rS[m], rB[m], 1)[0])
    if math.isfinite(rho) and sig_s > 0:
        if schwelle == 0:
            e["normal"] = 0.5 + math.asin(max(-1.0, min(1.0, rho))) / math.pi
        else:
            a = schwelle / sig_s                                   # Symmetrie (Mittel 0): P(B>0 | S>x) = P(B<0 | S<−x)
            e["normal"] = phi2(0.0, a, rho) / max(phi(a), 1e-300)
    return e


def _tafel(rS, rB, schwellen) -> dict:
    ok = np.isfinite(rS) & np.isfinite(rB)
    if ok.sum() < 10:
        return {"n": int(ok.sum())}
    rho = float(np.corrcoef(rS[ok], rB[ok])[0, 1]); sig = float(np.std(rS[ok]))
    return {"n": int(ok.sum()), "rho": rho, "beta": float(np.polyfit(rS[ok], rB[ok], 1)[0]),
            "ab": [dict(_bedingung(rS, rB, s, -1, rho, sig), schwelle=s) for s in schwellen],
            "auf": [dict(_bedingung(rS, rB, s, 1, rho, sig), schwelle=-s) for s in schwellen]}


def u147_rechnen(datums: list, sp: np.ndarray, Bk: dict, btc00: tuple | None = None, heute: date | None = None) -> dict:
    """
    datums/sp: S&P-Handelstage und Schlüsse; Bk: {coin: Kurs zum S&P-Schluss (16:00 New York) je Handelstag}. btc00: (Tag, Kurs)
    Tagesschluss 00:00 UTC ab 2016 für Wochen und 4 Wochen. -> Tafeln je Coin, Zeitraum, Frequenz; Vorlauf-Tests; Urteil „immer“.
    """
    n = len(datums)
    out = {"coins": {}, "n_tage": n, "von": datums[0].isoformat() if n else None, "bis": datums[-1].isoformat() if n else None}
    if n < 30:
        out["fehlt"] = "zu wenige S&P-Tage"
        return out
    lsp = np.log(sp)
    wl = _wochen_letzte(datums)
    for coin, B in Bk.items():
        lb = np.log(B)
        C = {}
        for name, a, b in U147_ZEITRAEUME:
            im = np.array([a <= d <= b for d in datums])
            # Tag: aufeinanderfolgende Handelstage (BTC über dasselbe Intervall, Wochenende eingeschlossen)
            rS = np.full(n, np.nan); rB = np.full(n, np.nan)
            rS[1:] = lsp[1:] - lsp[:-1]; rB[1:] = lb[1:] - lb[:-1]
            m = im.copy(); m[0] = False
            T_tag = _tafel(rS[m], rB[m], U147_TAG)
            # Woche: Freitag bis Freitag (letzter Handelstag der Woche), nur aufeinanderfolgende Wochen
            w = np.array(wl)
            wS = lsp[w[1:]] - lsp[w[:-1]]; wB = lb[w[1:]] - lb[w[:-1]]
            folge = np.array([(datums[w[i + 1]] - datums[w[i]]).days <= 10 for i in range(len(w) - 1)])
            mw = folge & np.array([a <= datums[w[i + 1]] <= b for i in range(len(w) - 1)])
            T_wo = _tafel(wS[mw], wB[mw], U147_WOCHE)
            # 4 Wochen: 20 Handelstage, nicht überlappend, ab dem ersten Tag des Zeitraums
            ii = np.nonzero(im)[0]
            blk = ii[::20]
            vS = lsp[blk[1:]] - lsp[blk[:-1]]; vB = lb[blk[1:]] - lb[blk[:-1]]
            T_4w = _tafel(vS, vB, U147_4W)
            C[name] = {"tag": T_tag, "woche": T_wo, "4w": T_4w}
        out["coins"][coin] = C
    # Wochen und 4 Wochen ab 2016 mit dem BTC-Tagesschluss 00:00 UTC (Versatz 3–4 h)
    if btc00 is not None and len(btc00[0]):
        tage, pr = btc00
        idx = {int(t): float(v) for t, v in zip(tage, pr)}
        b00 = np.array([idx.get((datetime(d.year, d.month, d.day, tzinfo=UTC).timestamp() // TAG), np.nan) for d in datums])
        lb0 = np.log(b00)
        w = np.array(wl)
        folge = np.array([(datums[w[i + 1]] - datums[w[i]]).days <= 10 for i in range(len(w) - 1)])
        wS = (lsp[w[1:]] - lsp[w[:-1]])[folge]; wB = (lb0[w[1:]] - lb0[w[:-1]])[folge]
        blk = np.arange(0, n, 20)
        out["ab2016"] = {"woche": _tafel(wS, wB, U147_WOCHE), "4w": _tafel(lsp[blk[1:]] - lsp[blk[:-1]], lb0[blk[1:]] - lb0[blk[:-1]], U147_4W),
                         "von": datums[0].isoformat()}
    # Urteil „immer“ (BTC, alle fallenden Bedingungen, alle Zeiträume): bestätigt nur bei 100 % überall
    B0 = out["coins"].get("BTC") or {}
    alle = []
    for name, T in B0.items():
        for frq in ("tag", "woche", "4w"):
            for e in (T.get(frq) or {}).get("ab") or []:
                if e.get("n"):
                    alle.append((name, frq, e["schwelle"], e["k"], e["n"], e["anteil"]))
    out["immer"] = {"bestaetigt": bool(alle) and all(a[5] == 1.0 for a in alle), "bedingungen": alle,
                    "naechste": sorted([a for a in alle if a[2] <= -0.02 or (a[1] != "tag" and a[2] <= -0.05)], key=lambda a: -a[5])[:6]}
    return out


def u147_vorlauf(datums: list, sp: np.ndarray, K: dict | None) -> dict:
    """Vier Vorlauf-Tests (13.12), Holm über 4, HAC: S&P-Tag -> BTC 24 h; BTC über Nacht -> S&P Folgetag; Wochen in beide Richtungen."""
    if K is None or len(datums) < 60:
        return {"fehlt": "zu wenige Daten"}
    t16 = np.array([ny_ts(d, 16, 0) for d in datums]); t0930 = np.array([ny_ts(d, 9, 30) for d in datums])
    b16 = kurs_um(K, t16); b16_24 = kurs_um(K, t16 + TAG); b0930 = kurs_um(K, t0930)
    lsp = np.log(sp)
    rS = np.full(len(datums), np.nan); rS[1:] = lsp[1:] - lsp[:-1]
    T = []
    y1 = np.log(b16_24 / b16)
    T.append(("S&P-Tag → BTC in den folgenden 24 h (ab 16:00 New York)", ols_hac(y1, rS, 5)))
    x2 = np.full(len(datums), np.nan); x2[1:] = np.log(b0930[1:] / b16[:-1])          # 16:00 am Vortag bis 9:30 am Handelstag
    T.append(("BTC außerhalb der Handelszeit (16:00 bis 9:30) → S&P an diesem Handelstag", ols_hac(rS, x2, 5)))
    wl = np.array(_wochen_letzte(datums))
    wS = lsp[wl[1:]] - lsp[wl[:-1]]; wB = np.log(b16[wl[1:]] / b16[wl[:-1]])
    T.append(("S&P-Woche → BTC-Folgewoche", ols_hac(wB[1:], wS[:-1], 4)))
    T.append(("BTC-Woche → S&P-Folgewoche", ols_hac(wS[1:], wB[:-1], 4)))
    ps = [t[1].get("p", 1.0) if math.isfinite(t[1].get("p", float("nan"))) else 1.0 for t in T]
    ph = holm(ps)
    return {"tests": [dict(e, name=nm, p_holm=h, belegt=bool(h < 0.05)) for (nm, e), h in zip(T, ph)],
            "hinweis": "Vorlauf gegenüber dem Kassamarkt: S&P-Futures handeln über Nacht mit -- ein Zusammenhang über Nacht ist "
                       "gemeinsame Information, kein Beleg, dass BTC den Aktienmarkt führt."}


def u147(db: str) -> dict:
    datums, sp = sp500_reihe(db)
    if len(datums) < 30:
        return {"fehlt": "S&P 500 (FRED) noch nicht im Archiv -- der Aktien-Takt lädt ihn nach dem Einspielen"}
    t16 = np.array([ny_ts(d, 16, 0) for d in datums])
    Bk, Kb = {}, None
    for coin in U147_COINS:
        K = kerzen_30m(db, coin)
        if K is None:
            continue
        if coin == "BTC":
            Kb = K
        Bk[coin] = kurs_um(K, t16)
    if not Bk:
        return {"fehlt": "keine 30-min-Kerzen (swing.db)"}
    erg = u147_rechnen(datums, sp, Bk, btc00_or_none(db))
    erg["vorlauf"] = u147_vorlauf([d for d in datums if d >= date(2020, 1, 1)], sp[np.array([d >= date(2020, 1, 1) for d in datums])], Kb)
    return erg


def btc00_or_none(db: str):
    t, w = btc_tagesschluss_00(db)
    return (t, w) if len(t) else None


# ================================================================================================ Kurzstudie K1/K2 (13.13)

K12_AB = date(2024, 4, 1)


def k12_rechnen(datums: list, flow_usd: np.ndarray, b16: np.ndarray, b16_7: np.ndarray, sig: np.ndarray, short: np.ndarray,
                total: np.ndarray, k: int = 2000) -> dict:
    """
    Je US-Handelstag d (ab 01.04.2024): K1 = Nettofluss der Spot-ETF über 20 Handelstage in BTC ÷ ETF-Bestand (Bestand = GBTC bei der
    Umwandlung + aufsummierte Flüsse in BTC), K2 = IBIT-Leerverkaufsquote über 5 Handelstage. Ziel: ln(B(d+7 T)/B(d)) ÷ (σ̂ √7).
    Spearman, Phasen-Randomisierung (13.6), Holm über 2; „belegt“ nur bei p Holm < 0,05 und gleichem Vorzeichen in beiden Hälften.
    """
    import hl_makro_korr as MKK
    n = len(datums)
    with np.errstate(invalid="ignore", divide="ignore"):
        f_btc = flow_usd * 1e6 / b16
    f0 = np.where(np.isfinite(f_btc), f_btc, 0.0)
    bestand = GBTC_START_BTC + np.cumsum(f0)
    k1 = np.full(n, np.nan); k2 = np.full(n, np.nan)
    for i in range(n):
        if i >= 19 and np.isfinite(f_btc[i - 19:i + 1]).sum() >= 18:
            k1[i] = np.nansum(f_btc[i - 19:i + 1]) / bestand[i]
        if i >= 4 and np.isfinite(short[i - 4:i + 1]).all() and np.isfinite(total[i - 4:i + 1]).all() and total[i - 4:i + 1].sum() > 0:
            k2[i] = short[i - 4:i + 1].sum() / total[i - 4:i + 1].sum()
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.log(b16_7 / b16) / (sig * math.sqrt(7))
    im = np.array([d >= K12_AB for d in datums])
    out = {"tests": []}
    ps = []
    for key, name, x in (("K1", "ETF-Nettofluss 20 Handelstage ÷ Bestand", k1), ("K2", "IBIT-Leerverkaufsquote 5 Handelstage", k2)):
        m = im & np.isfinite(x) & np.isfinite(y)
        e = {"key": key, "name": name, "n": int(m.sum())}
        if m.sum() < 60:
            e["grund"] = "zu wenige Tage"; out["tests"].append(e); ps.append(1.0); continue
        ii = np.nonzero(m)[0]
        rho, null, nn = phasen_null_spearman(x[ii], y[ii], k=k, seed=11 if key == "K1" else 12)
        p = MKK.p_zweiseitig(rho, null) if null is not None else 1.0
        mitte = ii[len(ii) // 2]
        h1 = ii[ii < mitte]; h2 = ii[ii >= mitte]
        r1 = MKK.spearman(x[h1], y[h1]) if len(h1) > 20 else float("nan")
        r2 = MKK.spearman(x[h2], y[h2]) if len(h2) > 20 else float("nan")
        e.update(rho=rho, p=p, h1=r1, h2=r2, von=datums[ii[0]].isoformat(), bis=datums[ii[-1]].isoformat(), mitte=datums[mitte].isoformat())
        out["tests"].append(e); ps.append(p)
    for e, h in zip(out["tests"], holm(ps)):
        e["p_holm"] = h
        e["belegt"] = bool(h < 0.05 and e.get("h1") is not None and math.isfinite(e.get("h1", float("nan")))
                           and np.sign(e["h1"]) == np.sign(e["h2"]) == np.sign(e.get("rho", 0)))
    return out


def k12(db: str) -> dict:
    datums, _sp = sp500_reihe(db)
    con = lesen(aktien_pfad(db))
    if con is None or not datums:
        return {"fehlt": "aktien.db oder S&P-Tage fehlen"}
    try:
        f = dict(zip(*[x.tolist() for x in reihe(con, "farside:btc:Total")]))
        sh = dict(zip(*[x.tolist() for x in reihe(con, "finra:IBIT:short")]))
        to = dict(zip(*[x.tolist() for x in reihe(con, "finra:IBIT:total")]))
    finally:
        con.close()
    if not f:
        return {"fehlt": "keine ETF-Flüsse (Farside) im Archiv"}
    datums = [d for d in datums if d >= date(2024, 1, 11)]
    K = kerzen_30m(db, "BTC")
    t16 = np.array([ny_ts(d, 16, 0) for d in datums])
    b16 = kurs_um(K, t16); b16_7 = kurs_um(K, t16 + 7 * TAG)
    tk = [int(datetime(d.year, d.month, d.day, tzinfo=UTC).timestamp()) for d in datums]
    flow = np.array([f.get(t, np.nan) for t in tk], dtype=float)
    short = np.array([sh.get(t, np.nan) for t in tk], dtype=float); total = np.array([to.get(t, np.nan) for t in tk], dtype=float)
    t00, p00 = btc_tagesschluss_00(db)
    sig = np.full(len(datums), np.nan)
    if len(t00) > 60:
        import hl_zyklus as ZY
        r = np.full(len(p00), np.nan); r[1:] = np.log(p00[1:] / p00[:-1])
        s = ZY.sigma_batch(r[None, :])[0]
        pos = {int(t): i for i, t in enumerate(t00)}
        for i, t in enumerate(tk):
            j = pos.get(t // TAG - 1)                                   # σ bis zum Vortag (bei d bekannt)
            if j is not None:
                sig[i] = s[j]
    return dict(k12_rechnen(datums, flow, b16, b16_7, sig, short, total), n_tage=len(datums))


# ================================================================================================ Reiter „Aktienmarkt“ (13.7, beschreibend)

_MEMO: dict = {"lock": threading.Lock(), "items": {}}


def _memo(key, fn, ttl: float):
    with _MEMO["lock"]:
        hit = _MEMO["items"].get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    v = fn()
    with _MEMO["lock"]:
        _MEMO["items"][key] = (time.time(), v)
    return v


def _letzt(t: np.ndarray, w: np.ndarray) -> tuple:
    ok = np.isfinite(w)
    if not ok.any():
        return None, None
    i = int(np.nonzero(ok)[0][-1])
    return int(t[i]), float(w[i])


def _perz(w: np.ndarray, v: float) -> float | None:
    x = w[np.isfinite(w)]
    if len(x) < 100 or v is None:
        return None
    return float((np.sum(x < v) + 0.5 * np.sum(x == v)) / len(x))


def gleichlauf(datums: list, sp: np.ndarray, B: np.ndarray) -> dict:
    """Korrelation der Tagesrenditen (S&P-Schluss gegen Kurs zum S&P-Schluss) über 60/120/260 Handelstage mit 90-%-Intervall
    (stationärer Blockbootstrap, Blocklänge 5); Beta nach unten und nach oben über 260 Tage."""
    lsp = np.log(sp); lb = np.log(B)
    rS = lsp[1:] - lsp[:-1]; rB = lb[1:] - lb[:-1]
    out = {}
    for n in (60, 120, 260):
        out[str(n)] = korrelation_ki(rS[-n:], rB[-n:], reps=1000, seed=n)
    a, b = rS[-260:], rB[-260:]
    ok = np.isfinite(a) & np.isfinite(b)
    for k, m in (("beta_ab", ok & (a < 0)), ("beta_auf", ok & (a > 0))):
        out[k] = float(np.polyfit(a[m], b[m], 1)[0]) if m.sum() >= 20 else None
    for k, m in (("tafel_260", slice(-260, None)), ("tafel_2020", np.array([d >= date(2020, 1, 1) for d in datums[1:]]))):
        x, y = rS[m], rB[m]
        okk = np.isfinite(x) & np.isfinite(y)
        z = {}
        for s_ in (0.0, -0.01):
            mm = okk & (x < s_)
            z[str(s_)] = {"n": int(mm.sum()), "k": int((y[mm] < 0).sum())}
        out[k] = z
    return out


def nutzlast(db: str) -> dict:
    """Reiter „Aktienmarkt“: Barometer (xyz), Gleichlauf, Tafel U147, Stress, Krypto-Aktien, Struktur, Quellen. Beschreibend."""
    return _memo(("aktien", db), lambda: _nutzlast(db), 600)


def _nutzlast(db: str) -> dict:
    t0 = time.time()
    out = {"ok": True, "version": VERSION_MODUL, "erzeugt": int(time.time()), "kennzeichnung": "beschreibend, nicht geprüft",
           "fehlt": [], "quellen": quellen_stand(db), "boerse_offen": boerse_offen()}
    con = lesen(aktien_pfad(db))
    if con is None:
        out["fehlt"].append("aktien.db fehlt noch -- der Aktien-Takt legt sie nach dem Einspielen an")
        return out
    try:
        st = json.loads(meta(con, "xyz_stand", "{}") or "{}"); xts = meta(con, "xyz_ts")
        out["barometer"] = {"ts": int(float(xts)) if xts else None, "werte": {}}
        for k in XYZ_INDIZES + XYZ_KRYPTO + XYZ_ANLEIHEN + XYZ_TOP10:
            e = st.get(k)
            if e and e.get("mark") is not None:
                out["barometer"]["werte"][k] = {"mark": e["mark"], "vortag": e.get("vortag"),
                                                "aend": (e["mark"] / e["vortag"] - 1) if e.get("vortag") else None}
        # Stress
        S = {}
        for name, r in (("vix", "fred:VIXCLS"), ("vix3m", "fred:VXVCLS"), ("vvix", "cboe:VVIX"), ("vix9d", "cboe:VIX9D"),
                        ("hy", "fred:BAMLH0A0HYM2"), ("baa10y", "fred:BAA10Y"), ("stlfsi", "fred:STLFSI4"), ("nfci", "fred:NFCI"),
                        ("sp", "fred:SP500"), ("ndx", "fred:NASDAQ100")):
            t, w = reihe(con, r)
            lt, lw = _letzt(t, w)
            S[name] = {"ts": lt, "wert": lw, "pz": _perz(w, lw), "seit": int(t[0]) if len(t) else None, "n": int(len(t))}
            if name in ("sp", "ndx") and len(w) >= 252 and lw:
                S[name]["abstand_hoch"] = lw / float(np.nanmax(w[-252:])) - 1
        if S["vix"]["wert"] and S["vix3m"]["wert"] and S["vix"]["ts"] == S["vix3m"]["ts"]:
            S["vix_vix3m"] = S["vix"]["wert"] / S["vix3m"]["wert"]
        out["stress"] = S
        # Krypto-Aktien: ETF-Flüsse (Farside, mit Abrufzeit und Zahl der Fassungen), CFTC, IBIT-Leerverkäufe, Strategy
        rows = con.execute("SELECT ts, wert, abgerufen, fassungen FROM ak_aktuell WHERE reihe='farside:btc:Total' ORDER BY ts DESC LIMIT 20").fetchall()
        out["etf"] = {"tage": [{"ts": r[0], "mio_usd": r[1], "abgerufen": r[2], "fassungen": r[3]} for r in rows],
                      "summe5": float(sum(r[1] for r in rows[:5])) if len(rows) >= 5 else None,
                      "summe20": float(sum(r[1] for r in rows[:20])) if len(rows) >= 20 else None}
        cf = {}
        for code, name in CFTC_KONTRAKTE.items():
            e = {"name": name}
            for f in CFTC_FELDER:
                t, w = reihe(con, f"cftc:{code}:{f}")
                if len(t):
                    e[f] = float(w[-1]); e["ts"] = int(t[-1])
                    if len(w) >= 2:
                        e[f + "_vor"] = float(w[-2])
            if "lev_long" in e and "lev_short" in e:
                e["lev_netto"] = e["lev_long"] - e["lev_short"]
            if "am_long" in e and "am_short" in e:
                e["am_netto"] = e["am_long"] - e["am_short"]
            cf[code] = e
        out["cftc"] = cf
        fi = {}
        for sym in FINRA_SYMBOLE:
            ts_, sh = reihe(con, f"finra:{sym}:short"); _t2, to = reihe(con, f"finra:{sym}:total")
            if len(sh) >= 5 and len(to) >= 5 and len(ts_) == len(_t2):
                fi[sym] = {"ts": int(ts_[-1]), "quote5": float(sh[-5:].sum() / to[-5:].sum()) if to[-5:].sum() > 0 else None,
                           "quote1": float(sh[-1] / to[-1]) if to[-1] > 0 else None}
        out["finra"] = fi
        tb, wb = reihe(con, "sec:mstr_btc"); ta, wa = reihe(con, "sec:mstr_aktien")
        ms = {"btc": float(wb[-1]) if len(wb) else None, "btc_ts": int(tb[-1]) if len(tb) else None,
              "netto_woche": float(wb[-1] - wb[-2]) if len(wb) >= 2 else None, "aktien": float(wa[-1]) if len(wa) else None,
              "aktien_ts": int(ta[-1]) if len(ta) else None, "mstr": (st.get("MSTR") or {}).get("mark"), "strc": (st.get("STRC") or {}).get("mark")}
        ms["strc_nennwert"] = (ms["strc"] / 100.0 - 1) if ms["strc"] else None
        out["strategy"] = ms
        # Struktur: Top 10 über xyz-Tageskerzen (Abstand zum Hoch seit der Listung, gleich gewichtet)
        tops = []
        for k in XYZ_TOP10:
            K = kerzen(con, f"xyz:{k}:1d")
            mark = (st.get(k) or {}).get("mark")
            if K is None or not len(K["c"]):
                continue
            hoch = float(np.max(K["h"])); px = mark or float(K["c"][-1])
            tops.append({"k": k, "px": px, "hoch": hoch, "abstand": px / hoch - 1, "seit": int(K["ts"][0])})
        out["struktur"] = {"top10": tops, "mittel_abstand": float(np.mean([t["abstand"] for t in tops])) if tops else None}
    finally:
        con.close()
    # Gleichlauf und Tafel U147 je Coin (Kurs zum S&P-Schluss)
    datums, sp = sp500_reihe(db)
    gl = {}
    if len(datums) >= 270:
        t16 = np.array([ny_ts(d, 16, 0) for d in datums])
        for coin in U147_COINS:
            K = kerzen_30m(db, coin)
            if K is None:
                continue
            B = kurs_um(K, t16)
            if np.isfinite(B[-260:]).sum() < 200:
                continue
            gl[coin] = gleichlauf(datums, sp, B)
        if "BTC" in gl and sp is not None:
            dd = [i for i, d in enumerate(datums) if d >= date(2020, 1, 1)]
            out["sp_tage"] = len(dd)
    else:
        out["fehlt"].append("S&P 500 (FRED) mit weniger als 270 Handelstagen im Archiv -- Gleichlauf folgt")
    out["gleichlauf"] = gl
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return out


# ================================================================================================ Text (Debug, Berichte)

def _p(x, d=1) -> str:
    return "—" if x is None or not math.isfinite(x) else f"{x * 100:+.{d}f} %".replace(".", ",")


def _z(x, d=2) -> str:
    return "—" if x is None or not math.isfinite(x) else f"{x:.{d}f}".replace(".", ",")


def _dt(ts) -> str:
    return "—" if not ts else datetime.fromtimestamp(int(ts), UTC).strftime("%d.%m.%Y")


def text(db: str) -> str:
    Z = []; a = Z.append
    a(f"★ Aktienmarkt (U148) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')} · beschreibend, nicht geprüft")
    a(f"Archiv: {aktien_pfad(db)}")
    a("")
    a("QUELLEN (zuletzt ok · Fehler · Pause)")
    for q in quellen_stand(db):
        ok = _dt(q.get("ok")) + (" " + time.strftime("%H:%M", time.localtime(q["ok"])) if q.get("ok") else "")
        pa = q.get("pause_bis") or 0
        a(f"  {q['name']:<34} ok {ok:<17} · Fehler in Folge {int(q.get('fehler_n') or 0)}"
          + (f" · Pause bis {time.strftime('%d.%m. %H:%M', time.localtime(pa))}" if pa and pa > time.time() else "")
          + (f" · {q['fehler']}" if q.get("fehler") else "") + (f" · {q['info']}" if q.get("info") else ""))
    con = lesen(aktien_pfad(db))
    if con is not None:
        try:
            a("")
            a("ARCHIV (Reihen, Tage, Fassungen)")
            for r, n, mn, mx, fa in con.execute("SELECT reihe, COUNT(*), MIN(ts), MAX(ts), SUM(fassungen) FROM ak_aktuell GROUP BY reihe ORDER BY reihe"):
                if r.startswith("xyz:") and not r.endswith(":mark"):
                    continue
                a(f"  {r:<28} {n:>6} Werte {_dt(mn)}–{_dt(mx)} · {fa - n} Revisionen")
            for r, n, mn, mx in con.execute("SELECT reihe, COUNT(*), MIN(ts), MAX(ts) FROM ak_kerze GROUP BY reihe ORDER BY reihe"):
                a(f"  {r:<28} {n:>6} Kerzen {_dt(mn)}–{_dt(mx)}")
        finally:
            con.close()
    N = nutzlast(db)
    a("")
    a("BAROMETER (Hyperliquid xyz, rund um die Uhr" + ("" if N.get("boerse_offen") else "; Börse geschlossen -- Perp-Stand") + ")")
    for k, e in ((N.get("barometer") or {}).get("werte") or {}).items():
        a(f"  {k:<8} {_z(e['mark'], 2):>12}  {_p(e.get('aend'))} gegen Vortag")
    S = N.get("stress") or {}
    if S:
        a("")
        a("STRESS (Wert, Stand, Perzentil in der eigenen Historie)")
        for k, nm in (("vix", "VIX"), ("vix3m", "VIX3M"), ("vvix", "VVIX"), ("hy", "Hochzinsaufschlag %"), ("baa10y", "Baa − 10 J %"),
                      ("stlfsi", "STLFSI4"), ("nfci", "NFCI"), ("sp", "S&P 500"), ("ndx", "Nasdaq-100")):
            e = S.get(k) or {}
            a(f"  {nm:<22} {_z(e.get('wert')):>10}  {_dt(e.get('ts'))}  Perzentil {_z((e.get('pz') or float('nan')) * 100, 0)}"
              + (f"  Abstand zum 252-T-Hoch {_p(e.get('abstand_hoch'))}" if e.get("abstand_hoch") is not None else ""))
        if S.get("vix_vix3m"):
            a(f"  VIX ÷ VIX3M            {_z(S['vix_vix3m'], 3):>10}")
    G = N.get("gleichlauf") or {}
    if G:
        a("")
        a("GLEICHLAUF mit dem S&P 500 (Tagesrenditen, Kurs zum S&P-Schluss 16:00 New York; 90-%-Intervall Blockbootstrap)")
        for c, g in G.items():
            k = "  ".join(f"{n} T {_z(g[n].get('r'))} ({_z(g[n].get('lo'))}…{_z(g[n].get('hi'))})" for n in ("60", "120", "260") if g.get(n, {}).get("r") is not None)
            t = g.get("tafel_260", {})
            a(f"  {c:<5} {k}  Beta ab {_z(g.get('beta_ab'))} / auf {_z(g.get('beta_auf'))}"
              f"  · fiel an {t.get('0.0', {}).get('k')} von {t.get('0.0', {}).get('n')} Verlusttagen, unter −1 %: "
              f"{t.get('-0.01', {}).get('k')} von {t.get('-0.01', {}).get('n')}")
    for f in N.get("fehlt") or []:
        a(f"  fehlt: {f}")
    return "\n".join(Z)


def u147_text(E: dict) -> str:
    Z = []; a = Z.append
    a(f"★ Studie U147: Fällt BTC, wenn der S&P 500 fällt? · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}")
    a("Vorab festgelegt (KONZEPT_Ausblick.md 13.12). S&P: FRED SP500; Coins zum S&P-Schluss (30-min-Kerze bis 16:00 New York, swing.db).")
    if E.get("fehlt"):
        a(f"fehlt: {E['fehlt']}"); return "\n".join(Z)
    a(f"S&P-Handelstage {E.get('von')} bis {E.get('bis')} ({E.get('n_tage')})")
    for coin, C in (E.get("coins") or {}).items():
        a("")
        a(f"== {coin} ==")
        for zr, T in C.items():
            for frq, nm in (("tag", "Tag"), ("woche", "Woche"), ("4w", "4 Wochen")):
                t = T.get(frq) or {}
                if not t.get("ab"):
                    continue
                a(f"  {zr} · {nm}: n {t['n']}, ρ {_z(t.get('rho'))}, Beta {_z(t.get('beta'))}")
                for e in t["ab"]:
                    if e.get("n"):
                        a(f"     S&P {'< 0' if e['schwelle'] == 0 else '< ' + _p(e['schwelle'], 0)}: {coin} fiel {e['k']} von {e['n']} = "
                          f"{_z(e['anteil'] * 100, 0)} % ({_z(e['lo'] * 100, 0)}–{_z(e['hi'] * 100, 0)} %), normal erwartet "
                          f"{_z(e.get('normal', float('nan')) * 100, 0)} %, Mittel {_p(e['mittel'])}, Median {_p(e['median'])}"
                          + (f", Beta {_z(e['beta'])}" if e.get("beta") is not None else ""))
                for e in t["auf"]:
                    if e.get("n"):
                        a(f"     S&P {'> 0' if e['schwelle'] == 0 else '> ' + _p(e['schwelle'], 0)}: {coin} stieg {e['k']} von {e['n']} = "
                          f"{_z(e['anteil'] * 100, 0)} % (normal {_z(e.get('normal', float('nan')) * 100, 0)} %)")
    if E.get("ab2016"):
        a("")
        a(f"== BTC ab {E['ab2016'].get('von')} (Tagesschluss 00:00 UTC, Versatz 3–4 h) ==")
        for frq, nm in (("woche", "Woche"), ("4w", "4 Wochen")):
            t = E["ab2016"].get(frq) or {}
            for e in t.get("ab") or []:
                if e.get("n"):
                    a(f"  {nm} S&P {'< 0' if e['schwelle'] == 0 else '< ' + _p(e['schwelle'], 0)}: BTC fiel {e['k']} von {e['n']} = "
                      f"{_z(e['anteil'] * 100, 0)} % (normal {_z(e.get('normal', float('nan')) * 100, 0)} %)")
    V = E.get("vorlauf") or {}
    if V.get("tests"):
        a("")
        a("VORLAUF (Holm über 4, Newey-West)")
        for t in V["tests"]:
            a(f"  {t['name']}: b {_z(t.get('b'), 3)}, t {_z(t.get('t'))}, p {_z(t.get('p'), 3)}, p Holm {_z(t.get('p_holm'), 3)} -> "
              f"{'belegt' if t.get('belegt') else 'nicht belegt'} (n {t.get('n')})")
        a("  " + V.get("hinweis", ""))
    I = E.get("immer") or {}
    a("")
    a("URTEIL „immer“: " + ("bestätigt (100 % in allen Bedingungen)" if I.get("bestaetigt") else "nicht bestätigt -- nicht in allen Bedingungen 100 %"))
    for zr, frq, s_, k, n, an in I.get("naechste") or []:
        a(f"  am nächsten: {zr} · {frq} · S&P < {_p(s_, 0)}: {k} von {n} ({_z(an * 100, 0)} %)")
    return "\n".join(Z)


def k12_text(E: dict) -> str:
    Z = [f"★ Kurzstudie K1/K2: ETF-Flüsse und IBIT-Leerverkäufe über 7 Tage · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}",
         "Vorab festgelegt (KONZEPT_Ausblick.md 13.13): Spearman, Phasen-Randomisierung, Holm über 2, beide Hälften. Erwartung: nicht belegt."]
    if E.get("fehlt"):
        Z.append(f"fehlt: {E['fehlt']}"); return "\n".join(Z)
    for t in E.get("tests") or []:
        if t.get("grund"):
            Z.append(f"  {t['key']} {t['name']}: {t['grund']} (n {t['n']})"); continue
        Z.append(f"  {t['key']} {t['name']}: ρ {_z(t['rho'], 3)}, p {_z(t['p'], 3)}, p Holm {_z(t['p_holm'], 3)}, Hälften "
                 f"{_z(t['h1'], 3)} / {_z(t['h2'], 3)} (Teilung {t['mitte']}), n {t['n']} ({t['von']}–{t['bis']}) -> "
                 f"{'belegt' if t['belegt'] else 'nicht belegt'}")
    Z.append(f"ETF-Bestand für K1: ≈ {GBTC_START_BTC:,.0f} BTC (GBTC bei der Umwandlung) plus aufsummierte Flüsse; ein anderer Anker "
             "ändert die Reihe fast nur um einen Faktor.".replace(",", "."))
    return "\n".join(Z)


# ================================================================================================ Selbsttest (ohne Netz)

def _beispiele() -> dict:
    """Antworten nach den dokumentierten bzw. am 11.10.2026 gelesenen Formaten (FINRA: Kopf und Zeilen wie die Datei vom 09.10.)."""
    return {
        "fred": {"observations": [{"date": "2026-10-08", "value": "6650.12"}, {"date": "2026-10-09", "value": "."},
                                  {"date": "2026-10-10", "value": "6612.50"}]},
        "drb": {"jsonrpc": "2.0", "result": {"data": [[1791590400000, 50.1, 51.0, 49.9, 50.5], [1791594000000, 50.5, 52.0, 50.2, 51.7]],
                                             "continuation": None}},
        "xyz_stand": [{"universe": [{"name": "xyz:SP500", "szDecimals": 3}, {"name": "xyz:MSTR", "szDecimals": 2},
                                    {"name": "xyz:OLD", "isDelisted": True}]},
                      [{"markPx": "6620.5", "oraclePx": "6618.0", "midPx": "6620.4", "prevDayPx": "6580.0", "funding": "0.0000125",
                        "openInterest": "1234.5", "dayNtlVlm": "98765432.1"},
                       {"markPx": "171.25", "oraclePx": "171.0", "midPx": "171.2", "prevDayPx": "175.0"},
                       {"markPx": "1.0"}]],
        "xyz_kerzen": [{"t": 1791590400000, "T": 1791592199999, "s": "xyz:SP500", "i": "30m", "o": "6600.0", "c": "6610.5",
                        "h": "6612.0", "l": "6598.0", "v": "12.5", "n": 40},
                       {"t": 1791592200000, "T": 1791593999999, "s": "xyz:SP500", "i": "30m", "o": "6610.5", "c": "6611.0",
                        "h": "6615.0", "l": "6609.0", "v": "3.0", "n": 9}],
        "cftc": [{"report_date_as_yyyy_mm_dd": "2026-10-06T00:00:00.000", "market_and_exchange_names": "BITCOIN - CHICAGO MERCANTILE EXCHANGE",
                  "cftc_contract_market_code": "133741", "open_interest_all": "21432", "dealer_positions_long_all": "1200",
                  "dealer_positions_short_all": "900", "asset_mgr_positions_long": "8100", "asset_mgr_positions_short": "1500",
                  "lev_money_positions_long": "5731", "lev_money_positions_short": "12583"}],
        "finra": "Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market\n20261009|A|334518.963110|0|768616.578491|B,Q,N\n"
                 "20261009|COIN|1200000.5|1500|2500000.25|B,Q,N\n20261009|IBIT|9000000|20000|30000000|B,Q,N\n"
                 "20261009|MSTR|3000000|0|7000000.75|B,Q,N\n",
        "farside": "<table><tr><th></th><th>IBIT</th><th>FBTC</th><th>GBTC</th><th>Total</th></tr>"
                   "<tr><td>11 Jan 2024</td><td>111.7</td><td>227.0</td><td>(95.1)</td><td>655.3</td></tr>"
                   "<tr><td>12 Jan 2024</td><td>386.0</td><td>-</td><td>(484.1)</td><td>203.0</td></tr>"
                   "<tr><td>Total</td><td>1</td><td>2</td><td>3</td><td>4</td></tr></table>",
        "cboe_vvix": "DATE,VVIX\n01/03/2007,87.63\n10/09/2026,92.10\n",
        "cboe_vix9d": "DATE,OPEN,HIGH,LOW,CLOSE\n01/03/2011,17.0,18.1,16.5,17.62\n10/09/2026,15.5,16.0,15.1,15.80\n",
        "sec_sub": {"cik": "1050446", "filings": {"recent": {"accessionNumber": ["0001193125-26-400001", "0001193125-26-400002",
                                                                                  "0001193125-23-100000"],
                                                             "filingDate": ["2026-10-05", "2026-09-29", "2023-05-01"],
                                                             "form": ["8-K", "10-Q", "8-K"],
                                                             "primaryDocument": ["d1.htm", "q.htm", "old.htm"]}}},
        "sec_8k": "<html><body><p>As of October 4, 2026, Strategy held an aggregate of approximately 847,999 bitcoins acquired for "
                  "an aggregate purchase price of approximately $60.1 billion.</p></body></html>",
        "sec_aktien": {"units": {"shares": [{"end": "2026-07-28", "val": 250000000, "accn": "0001-26-1", "filed": "2026-08-01"},
                                            {"end": "2026-07-28", "val": 19600000, "accn": "0001-26-1", "filed": "2026-08-01"},
                                            {"end": "2026-04-25", "val": 260000000, "accn": "0001-26-0", "filed": "2026-05-01"},
                                            {"end": "2026-04-25", "val": 260000000, "accn": "0001-26-0", "filed": "2026-05-01"}]}},
    }


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    import shutil
    ok_all = [True]

    def ok(name, bed, detail=""):
        ok_all[0] &= bool(bed)
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f" — {detail}" if detail and (not bed or verbose) else ""), flush=True)

    if verbose:
        print("Aktienmarkt (U148) und Studien U147/K1/K2 -- Selbsttest ohne Netz", flush=True)
    t_start = time.time()
    # 1) Kalender
    f26, f27, f28 = nyse_feiertage(2026), nyse_feiertage(2027), nyse_feiertage(2028)
    soll26 = {date(2026, 1, 1), date(2026, 1, 19), date(2026, 2, 16), date(2026, 4, 3), date(2026, 5, 25), date(2026, 6, 19),
              date(2026, 7, 3), date(2026, 9, 7), date(2026, 11, 26), date(2026, 12, 25)}
    soll27 = {date(2027, 1, 1), date(2027, 1, 18), date(2027, 2, 15), date(2027, 3, 26), date(2027, 5, 31), date(2027, 6, 18),
              date(2027, 7, 5), date(2027, 9, 6), date(2027, 11, 25), date(2027, 12, 24)}
    soll28 = {date(2028, 1, 17), date(2028, 2, 21), date(2028, 4, 14), date(2028, 5, 29), date(2028, 6, 19), date(2028, 7, 4),
              date(2028, 9, 4), date(2028, 11, 23), date(2028, 12, 25)}
    ok("Kalender: NYSE-Feiertage 2026–2028 nach den Regeln (Karfreitag, beobachtete Tage, Neujahr am Samstag ohne Ersatztag)",
       f26 == soll26 and f27 == soll27 and f28 == soll28, f"{sorted(f26 ^ soll26)} {sorted(f27 ^ soll27)} {sorted(f28 ^ soll28)}")
    t_som = int(datetime(2026, 10, 9, 19, 59, tzinfo=UTC).timestamp()); t_win = int(datetime(2026, 12, 9, 20, 59, tzinfo=UTC).timestamp())
    ok("Kalender: Handelszeit in New Yorker Zeit (Sommerzeit 19:59 UTC offen, Winterzeit 20:59 UTC offen, 21:01 zu, Samstag zu)",
       boerse_offen(t_som) and boerse_offen(t_win) and not boerse_offen(t_win + 120) and not boerse_offen(t_som + 86400)
       and ny_ts(date(2026, 10, 9), 16) == t_som + 60 and ny_ts(date(2026, 12, 9), 16) == t_win + 60)
    # 2) Archiv
    tmp = tempfile.mkdtemp(prefix="hl_aktien_test_")
    try:
        con = verbinden(os.path.join(tmp, "aktien.db"))
        n1 = archivieren(con, [("x", 100, 1.0), ("x", 200, 2.0)], 1000)
        n2 = archivieren(con, [("x", 100, 1.0), ("x", 200, 2.0)], 2000)
        n3 = archivieren(con, [("x", 100, 1.5), ("x", 300, 3.0)], 3000)
        alle = con.execute("SELECT ts, abgerufen, wert FROM ak_wert WHERE reihe='x' ORDER BY ts, abgerufen").fetchall()
        t, w = reihe(con, "x"); ts2, ws2 = reihe_stand(con, "x", 2500)
        fa = con.execute("SELECT fassungen FROM ak_aktuell WHERE reihe='x' AND ts=100").fetchone()[0]
        ok("Archiv: gleicher Wert keine neue Zeile, Revision eine neue Fassung (alte bleibt), jüngste Fassung lesbar, Stand zu einem "
           "früheren Abrufzeitpunkt rekonstruierbar",
           (n1, n2, n3) == (2, 0, 2) and alle == [(100, 1000, 1.0), (100, 3000, 1.5), (200, 1000, 2.0), (300, 3000, 3.0)]
           and list(w) == [1.5, 2.0, 3.0] and list(ws2) == [1.0, 2.0] and fa == 2, f"{alle}")
        k1 = kerzen_schreiben(con, "k", [(10, 1, 2, 0.5, 1.5, 9)], 1); k2 = kerzen_schreiben(con, "k", [(10, 9, 9, 9, 9, 9), (20, 1, 1, 1, 1, 1)], 2)
        K = kerzen(con, "k")
        ok("Archiv: gespeicherte Kerzen bleiben (eine abgeschlossene Kerze ändert sich nicht)", (k1, k2) == (1, 1) and K["o"][0] == 1.0)
        con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # 3) Parser
    B = _beispiele()
    import hl_makro as MK
    zf = MK.fred_api_parse("SP500", B["fred"])
    zd, cont = drb_stunden_parse("ETH", B["drb"])
    xs = xyz_stand_parse(B["xyz_stand"])
    xk = xyz_kerzen_parse(B["xyz_kerzen"], 1791593000000)
    zc, fe = cftc_parse(B["cftc"])
    zc2, fe2 = cftc_parse([{k: v for k, v in B["cftc"][0].items() if not k.startswith("dealer")}])
    zfi = finra_parse(B["finra"])
    zfs = farside_fonds_parse(B["farside"])
    zcb = cboe_parse("VVIX", B["cboe_vvix"]); zcb9 = cboe_parse("VIX9D", B["cboe_vix9d"])
    l8 = sec_8k_liste(B["sec_sub"])
    sa = sec_aktien_parse(B["sec_aktien"])
    try:
        finra_parse("<!DOCTYPE html><html><head></head><body>Access denied</body></html>"); html_fang = False
    except ValueError:
        html_fang = True
    ok("Parser FRED (fehlender Wert „.“ fällt weg), Deribit stündlich, xyz-Stand (Präfix, Delisting) und -Kerzen (nur abgeschlossene)",
       zf == [("fred:SP500", tag_ts("2026-10-08"), 6650.12), ("fred:SP500", tag_ts("2026-10-10"), 6612.5)]
       and [z[1:] for z in zd] == [(1791590400, 50.5), (1791594000, 51.7)] and cont is None
       and set(xs) == {"SP500", "MSTR", "OLD"} and xs["SP500"]["mark"] == 6620.5 and xs["OLD"]["delisted"] and xs["MSTR"]["oi"] is None
       and xk == [(1791590400, 6600.0, 6612.0, 6598.0, 6610.5, 12.5)], f"{xk}")
    ok("Parser CFTC (Felder tolerant, fehlendes Feld gemeldet), FINRA (Kopf, Nachkommastellen, nur IBIT/MSTR/COIN, HTML abgewiesen)",
       ("cftc:133741:lev_short", tag_ts("2026-10-06"), 12583.0) in zc and not fe and fe2 == ["dealer_long", "dealer_short"]
       and len(zfi) == 9 and ("finra:COIN:total", tag_ts("2026-10-09"), 2500000.25) in zfi and html_fang, f"{fe2}")
    ok("Parser Farside je Fonds (Klammern negativ, „-“ ist keine Null, Summenzeilen ohne Datum fallen weg), Cboe (beide Formate)",
       ("farside:btc:GBTC", tag_ts("2024-01-11"), -95.1) in zfs and not any(z[0] == "farside:btc:FBTC" and z[1] == tag_ts("2024-01-12") for z in zfs)
       and len(zfs) == 7 and zcb[-1] == ("cboe:VVIX", tag_ts("2026-10-09"), 92.1) and zcb9[-1][2] == 15.8)
    ok("Parser SEC: nur 8-K ab 2024, BTC-Bestand aus dem Text (drei Formulierungen, Tabelle), Aktienzahl je Meldung (Klassen addiert, "
       "doppelte Meldung einmal)",
       [e["acc"] for e in l8] == ["0001193125-26-400001"] and sec_bestand_parse(B["sec_8k"]) == 847999.0
       and sec_bestand_parse("MicroStrategy holds approximately 640,031 BTC") == 640031.0
       and sec_bestand_parse("<td>Aggregate BTC Holdings</td><td>&nbsp;</td><td>640,250</td>") == 640250.0
       and sec_bestand_parse("an 8-K about the annual meeting") is None
       and sa == [(tag_ts("2026-04-25"), 260000000.0), (tag_ts("2026-07-28"), 269600000.0)], f"{sa}")
    # 4) Abruf ohne Netz: alle Quellen über eine Ersatz-Funktion; Schutzschalter; Fälligkeit; Übernahme aus makro.db
    tmp = tempfile.mkdtemp(prefix="hl_aktien_abruf_")
    try:
        mk = MK.verbinden(os.path.join(tmp, "makro.db"))
        MK.schreiben(mk, [("fred:BAMLH0A0HYM2", tag_ts("2023-10-02"), 4.5), ("fred:BAMLH0A0HYM2", tag_ts("2026-10-08"), 3.1)], 1759600000)
        mk.close()
        aufrufe = []
        stoerung = {"finra": False}

        def h(url, timeout=30, art="json", kopf=None, daten=None):
            aufrufe.append(url)
            if "stlouisfed" in url:
                q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                sid = (q.get("series_id") or q.get("id") or ["?"])[0]
                obs = {"observations": [{"date": "2026-10-08", "value": "3.0" if sid == "BAMLH0A0HYM2" else "100"},
                                        {"date": "2026-10-09", "value": "101"}]}
                return (obs if art == "json" else "observation_date,X\n2026-10-08,100\n"), None, 200
            if "deribit" in url:
                return B["drb"], None, 200
            if "hyperliquid" in url:
                body = json.loads(daten.decode())
                return (B["xyz_stand"] if body["type"] == "metaAndAssetCtxs" else B["xyz_kerzen"]), None, 200
            if "cftc" in url:
                return B["cftc"], None, 200
            if "finra" in url:
                if stoerung["finra"]:
                    return None, "HTTP 503: Service Unavailable", 503
                return (B["finra"] if "20261009" in url else None), (None if "20261009" in url else "HTTP 404: Not Found"), (200 if "20261009" in url else 404)
            if "farside" in url:
                return B["farside"], None, 200
            if "cboe" in url:
                return (B["cboe_vvix"] if "VVIX" in url else B["cboe_vix9d"]), None, 200
            if "submissions" in url:
                return B["sec_sub"], None, 200
            if "companyconcept" in url:
                return B["sec_aktien"], None, 200
            if "Archives/edgar" in url:
                return B["sec_8k"], None, 200
            return None, "HTTP 404: unbekannt", 404
        jetzt = [float(datetime(2026, 10, 10, 14, 0, tzinfo=UTC).timestamp())]
        alt_key = os.environ.pop("FRED_API_KEY", None)
        os.environ["FRED_API_KEY"] = "a" * 32
        try:
            A = Abruf(os.path.join(tmp, "aktien.db"), os.path.join(tmp, "makro.db"), http_fn=h, jetzt_fn=lambda: jetzt[0], schlafen=False)
            R = {q: A.lauf(q) for q in QUELLEN}
            con = A.con
            hy = con.execute("SELECT ts, wert, abgerufen FROM ak_wert WHERE reihe='fred:BAMLH0A0HYM2' ORDER BY ts, abgerufen").fetchall()
            ok("Abruf ohne Netz: jede Quelle schreibt ins Archiv (FRED, DVOL, xyz-Stand und -Kerzen, CFTC, FINRA, Farside, Cboe, SEC)",
               all(r["ok"] for r in R.values()) and all(r["neu"] > 0 for q, r in R.items() if q != "finra") and R["finra"]["ok"]
               and reihe(con, "finra:IBIT:total")[1].tolist() == [30000000.0] and reihe(con, "sec:mstr_btc")[1].tolist() == [847999.0]
               and kerzen(con, "xyz:SP500:30m") is not None and reihe(con, "xyz:SP500:mark")[1].tolist() == [6620.5],
               "; ".join(f"{q} {r['ok']} {r['neu']} {r['fehler'] or r['info']}"[:70] for q, r in R.items()))
            ok("Übernahme aus makro.db: Hochzinsaufschlag mit alter Abrufzeit, nur Tage vor dem ersten eigenen Wert; eigener Abruf danach "
               "als neue Fassung", hy[0] == (tag_ts("2023-10-02"), 4.5, 1759600000) and any(r[0] == tag_ts("2026-10-08") and r[1] == 3.0 for r in hy)
               and int(meta(con, "import_makro_hy")) == 2, f"{hy}")
            n_sec = len([u for u in aufrufe if "Archives/edgar" in u])
            r2 = A.lauf("sec")
            ok("SEC: ein gelesenes 8-K wird nicht erneut geholt; User-Agent aus der Einstellung (Vorgabe admin@localhost.com)",
               len([u for u in aufrufe if "Archives/edgar" in u]) == n_sec and r2["ok"] and sec_user_agent("/nicht/da") == SEC_UA_STANDARD)
            # Schutzschalter
            stoerung["finra"] = True
            meta_setzen(con, {"finra_tage": "[]"})
            rf1 = A.lauf("finra"); p1 = float(meta(con, "pause_bis:finra")) - jetzt[0]
            rf2 = A.lauf("finra"); p2 = float(meta(con, "pause_bis:finra")) - jetzt[0]
            stoerung["finra"] = False
            jetzt[0] += 3 * 3600
            rf3 = A.lauf("finra")
            ok("Schutzschalter: Fehler in Folge -> Pause 30 min, dann 60 min; ein Erfolg setzt zurück; optionale Quelle (Cboe) ohne Pause",
               not rf1["ok"] and not rf2["ok"] and abs(p1 - 1800) < 2 and abs(p2 - 3600) < 2 and rf3["ok"]
               and int(meta(con, "fehler_n:finra")) == 0, f"{p1} {p2} {rf3}")
            # Fälligkeit
            t_fr = float(datetime(2026, 10, 9, 21, 30, tzinfo=UTC).timestamp())      # Fr 17:30 New York
            meta_setzen(con, {"versuch:cftc": t_fr - 3 * TAG, "pause_bis:cftc": 0, "versuch:fred": t_fr - 3600, "pause_bis:fred": 0,
                              "versuch:xyz": t_fr - 1700, "pause_bis:xyz": 0})
            f_cftc = faellig(con, "cftc", t_fr); f_cftc_vorher = faellig(con, "cftc", t_fr - 2 * 3600)
            f_fred = faellig(con, "fred", t_fr); f_fred_abend = faellig(con, "fred", t_fr + 3600)
            f_xyz = faellig(con, "xyz", t_fr); f_xyz2 = faellig(con, "xyz", t_fr + 120)
            ok("Fälligkeit: CFTC nach Freitag 16:00 New York, FRED nach 18:15 New York, xyz alle 30 min",
               f_cftc and not f_cftc_vorher and not f_fred and f_fred_abend and not f_xyz and f_xyz2,
               f"{f_cftc} {f_cftc_vorher} {f_fred} {f_fred_abend} {f_xyz} {f_xyz2}")
            A.close()
        finally:
            os.environ.pop("FRED_API_KEY", None)
            if alt_key is not None:
                os.environ["FRED_API_KEY"] = alt_key
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # 5) Statistik-Bausteine
    ok("phi2: P(X≤0, Y≤0; ρ) = 1/4 + arcsin(ρ)/(2π); Wilson von Hand; Holm von Hand",
       all(abs(phi2(0, 0, r) - (0.25 + math.asin(r) / (2 * math.pi))) < 2e-4 for r in (-0.6, 0.0, 0.3, 0.8))
       and abs(wilson(8, 10)[0] - 0.4902) < 1e-3 and abs(wilson(8, 10)[1] - 0.9433) < 1e-3
       and holm([0.01, 0.04, 0.03]) == [0.03, 0.06, 0.06])
    rng = np.random.default_rng(5)
    x = rng.normal(size=4000); e_ = rng.normal(size=4000)
    r_iid = ols_hac(0.3 * x + e_, x, 0)
    ok("OLS mit Newey-West: bei unabhängigen Fehlern Lag 0 = klassischer Standardfehler, Steigung getroffen",
       abs(r_iid["b"] - 0.3) < 0.05 and abs(r_iid["se"] - 1 / math.sqrt(4000)) < 0.003, f"{r_iid}")
    # 6) U147 auf synthetischen Daten: Normalmodell -> Anteile bei der Erwartung; „immer“-Welt -> bestätigt
    n = 1500
    datums = []
    d = date(2020, 1, 2)
    while len(datums) < n:
        if handelstag(d):
            datums.append(d)
        d += timedelta(days=1)
    rho = 0.4
    zS = rng.normal(size=n); zB = rho * zS + math.sqrt(1 - rho * rho) * rng.normal(size=n)
    sp = 3000 * np.exp(np.cumsum(0.012 * zS)); bt = 30000 * np.exp(np.cumsum(0.035 * zB))
    E = u147_rechnen(datums, sp, {"BTC": bt})
    T = E["coins"]["BTC"]["seit 2020"]["tag"]
    e0 = T["ab"][0]; e1 = T["ab"][1]
    ok("U147 Positivkontrolle Normalmodell (ρ 0,4): Anteil „BTC fiel“ an Verlusttagen im Wilson-Intervall um ½ + arcsin(ρ)/π, "
       "unter −1 % um die Rechnung; ρ und Beta getroffen",
       e0["lo"] - 0.03 <= e0["normal"] <= e0["hi"] + 0.03 and e1["lo"] - 0.05 <= e1["normal"] <= e1["hi"] + 0.05
       and abs(T["rho"] - rho) < 0.06 and abs(T["beta"] - rho * 0.035 / 0.012) < 0.25 and not E["immer"]["bestaetigt"],
       f"{e0['k']}/{e0['n']} ({e0['anteil']:.3f}, normal {e0['normal']:.3f}); <−1 %: {e1.get('anteil', 0):.3f} normal {e1.get('normal', 0):.3f}")
    eb0 = _bedingung(np.array([-1.0, 1.0]), np.array([-1.0, 1.0]), 0.0, -1, 0.4, 0.012)
    eb1 = _bedingung(np.array([-1.0, 1.0]), np.array([-1.0, 1.0]), -0.01, -1, 0.4, 0.012)
    rngm = np.random.default_rng(77)
    zz1 = rngm.standard_normal(2_000_000); zz2 = 0.4 * zz1 + math.sqrt(1 - 0.16) * rngm.standard_normal(2_000_000)
    p_mc = float(np.mean(zz2[zz1 < -0.01 / 0.012] < 0))
    ok("U147 Normalwert: Schwelle 0 = ½ + arcsin(ρ)/π genau; Schwelle −1 % = Φ₂(0, a; ρ)/Φ(a) wie 2·10⁶ Ziehungen (± 0,003)",
       abs(eb0["normal"] - (0.5 + math.asin(0.4) / math.pi)) < 1e-12 and abs(eb1["normal"] - p_mc) < 0.003,
       f"{eb0['normal']:.4f}; {eb1['normal']:.4f} gegen {p_mc:.4f}")
    bt2 = 30000 * np.exp(np.cumsum(np.where(zS < 0, -np.abs(0.03 * zB) - 0.001, 0.035 * zB)))
    E2 = u147_rechnen(datums, sp, {"BTC": bt2})
    ok("U147 Urteil: in einer Welt, in der BTC an jedem S&P-Verlusttag fällt, ist „immer“ bestätigt (Tag); sonst nicht",
       all(e["anteil"] == 1.0 for e in E2["coins"]["BTC"]["seit 2020"]["tag"]["ab"] if e.get("n")) and not E["immer"]["bestaetigt"])
    # Vorlauf: eingepflanzter Vorlauf S&P-Tag -> BTC 24 h; ein unabhängiger Lauf belegt nichts
    t16 = np.array([ny_ts(dd, 16, 0) for dd in datums])
    ts_k = np.arange(t16[0] - 10 * TAG, t16[-1] + 3 * TAG, BAR)
    preis = np.full(len(ts_k), np.nan)
    rS = np.diff(np.log(sp), prepend=np.log(sp[0]))
    lvl = np.log(30000.0) + np.cumsum(rng.normal(0, 0.004, len(ts_k)))
    for i, tt in enumerate(t16):                                       # nach dem Schluss des Tages i: BTC zieht 0,8 · S&P-Tag nach
        j0 = np.searchsorted(ts_k, tt); j1 = np.searchsorted(ts_k, tt + TAG)
        lvl[j0:j1] += 0.8 * rS[i] * np.linspace(0, 1, j1 - j0)
        lvl[j1:] += 0.8 * rS[i]
    Kp = {"ts": ts_k, "c": np.exp(lvl)}
    V = u147_vorlauf(datums, sp, Kp)
    Kn = {"ts": ts_k, "c": np.exp(np.log(30000.0) + np.cumsum(rng.normal(0, 0.004, len(ts_k))))}
    V0 = u147_vorlauf(datums, sp, Kn)
    ok("U147 Vorlauf: eingepflanzter Nachlauf von BTC (24 h) wird belegt (Holm), ein unabhängiger BTC-Pfad belegt nichts",
       V["tests"][0]["belegt"] and not any(t["belegt"] for t in V0["tests"]),
       f"{[round(t['p_holm'], 4) for t in V['tests']]} / {[round(t['p_holm'], 3) for t in V0['tests']]}")
    ku_ = kurs_um({"ts": np.array([ny_ts(date(2026, 10, 9), 15, 30), ny_ts(date(2026, 10, 9), 16, 0), ny_ts(date(2026, 12, 9), 15, 0)]),
                   "c": np.array([1.0, 9.0, 2.0])},
                  np.array([ny_ts(date(2026, 10, 9), 16), ny_ts(date(2026, 12, 9), 16), ny_ts(date(2026, 12, 9), 18)]))
    ok("kurs_um: Kerze bis 16:00 New York (Sommer- und Winterzeit; nicht die ab 16:00), fehlt sie, die bis zu 1 h ältere; sonst NaN",
       ku_.tolist()[:2] == [1.0, 2.0] and np.isnan(ku_[2]), f"{ku_.tolist()}")
    import hl_makro_korr as MKK
    xl = np.cumsum(rng.normal(size=1600)); yl = rng.normal(size=1600)
    r1_, n1_, _ = MKK.phasen_null(xl, yl, k=500, seed=3); r2_, n2_, _ = phasen_null_spearman(xl, yl, k=500, seed=3)
    ok("Phasen-Null der Kurzstudie gleich der Rechnung von U130 (hl_makro_korr.phasen_null) bei langer Reihe",
       n1_ is not None and abs(r1_ - r2_) < 1e-12 and np.allclose(n1_, n2_))
    # 7) K1/K2: eingepflanzter Zusammenhang belegt, Rauschen nicht
    m = 700
    dk = [d0 for d0 in (date(2024, 1, 11) + timedelta(days=i) for i in range(1100)) if handelstag(d0)][:m]
    flow = rng.normal(0, 300, m); bb = 50000 * np.exp(np.cumsum(rng.normal(0, 0.02, m)))
    sh = rng.uniform(0.2, 0.5, m) * 1e7; to = np.full(m, 1e7)
    f20 = np.convolve(flow, np.ones(20), "full")[:m]
    sig = np.full(m, 0.025)
    y_plant = 0.6 * (f20 - f20.mean()) / f20.std() + rng.normal(0, 1, m)
    b7 = bb * np.exp(y_plant * 0.025 * math.sqrt(7))
    Kp = k12_rechnen(dk, flow, bb, b7, sig, sh, to, k=1000)
    b7n = bb * np.exp(rng.normal(0, 1, m) * 0.025 * math.sqrt(7))
    Kn0 = k12_rechnen(dk, flow, bb, b7n, sig, sh, to, k=1000)
    ok("K1/K2: eingepflanzter Fluss-Zusammenhang (K1) belegt, K2 nicht; reines Rauschen belegt nichts",
       Kp["tests"][0]["belegt"] and not Kp["tests"][1]["belegt"] and not any(t["belegt"] for t in Kn0["tests"]),
       f"{[(t['key'], round(t.get('rho', 0), 3), round(t.get('p_holm', 1), 4)) for t in Kp['tests']]}")
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok_all[0] else 'NICHT bestanden'} ({time.time() - t_start:.0f} s)", flush=True)
    return ok_all[0]


# ================================================================================================ Befehlszeile

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Aktienmarkt (U148): Archiv, Barometer, Studien U147 und K1/K2")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (aktien.db liegt daneben)")
    ap.add_argument("--abrufen", action="store_true", help="Quellen jetzt abrufen (alle oder --quelle)")
    ap.add_argument("--quelle", default=",".join(QUELLEN))
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--u147", action="store_true")
    ap.add_argument("--k12", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    db = a.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db")
    if a.abrufen:
        qs = tuple(q.strip() for q in a.quelle.split(",") if q.strip() in QUELLEN)
        print(f"Abruf {', '.join(qs)} -> {aktien_pfad(db)}", flush=True)
        r = abrufen(db, qs, nur_faellige=False, log=lambda s: print(s, flush=True))
        return 0 if all(x["ok"] or x["quelle"] in OPTIONAL for x in r) else 1
    if a.u147:
        print(u147_text(u147(db)))
        return 0
    if a.k12:
        print(k12_text(k12(db)))
        return 0
    print(text(db))
    return 0


if __name__ == "__main__":
    sys.exit(main())
