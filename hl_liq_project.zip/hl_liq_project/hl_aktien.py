#!/usr/bin/env python3
"""
hl_aktien.py -- Aktienmarkt als Barometer (U148), Studie U147 und Kurzstudie K1/K2 (Version 2026-09-23.66).

Regeln: KONZEPT_Ausblick.md 13.7, 13.8, 13.12, 13.13 (vorab festgelegt am 11.10.2026, vor jedem Lauf auf echten Daten).
Eigene Datei aktien.db neben hl_liq.db, ein ARCHIV: jeder abgerufene Wert mit Abrufzeit, nie überschrieben; eine Revision wird
eine neue Zeile (ak_wert), die jüngste Fassung je Tag steht in ak_aktuell. Vor dem Schreiben prüft jede Quelle Schema, Frische
und ob statt CSV/JSON eine HTML-Seite kam; je Quelle Backoff und Schutzschalter. Zeiten der Jobs in New Yorker Zeit mit dem
NYSE-Kalender; „kein neuer Schluss“ heißt Tag geschlossen, kein Fehler.

Quellen (frei, ohne Konto):
  FRED (Schlüssel aus hl_makro): SP500, NASDAQ100, VIXCLS, VXVCLS, BAA10Y, STLFSI4, NFCI, BAMLH0A0HYM2 (nur 3 Jahre sichtbar --
        beim ersten Lauf wird die Historie aus makro.db übernommen, dort seit 05.10. gesichert)
  Deribit: DVOL BTC und ETH stündlich (Zusatz X1 im Ausblick)
  Hyperliquid HIP-3 „xyz“ (trade.xyz): S&P 500, Nasdaq-100, VIX, Top 10, MSTR, STRC, COIN, HOOD, CRCL, TLT rund um die Uhr --
        Stand je 30 min (metaAndAssetCtxs) und 30-min-/Tageskerzen (candleSnapshot); Historie nur seit der Listung
  CFTC TFF (gpe5-46if): Bitcoin 133741, E-mini S&P 500 13874A, E-mini Nasdaq-100 209742 (samstags)
  FINRA Reg SHO (CNMSshvol, abends): IBIT, MSTR, COIN
  Farside: Spot-ETF-Flüsse BTC je Fonds, mit Abrufzeit (Revisionen sichtbar)
  Cboe-CSV (optional, still bei Fehler): VIX9D, VVIX
  SEC EDGAR: Strategy (CIK 1050446) -- BTC-Bestand aus den 8-K, Aktienzahl (XBRL); User-Agent einstellbar (accesstokens.json
        „sec“ -> „user_agent“ oder HL_SEC_UA), Vorgabe des Nutzers „hl_liq_project admin@localhost.com“
Schreibt nur aktien.db; wirkt auf nichts sonst (Zusage bis 25.10.: keine Konfluenz, kein Labor, keine Prognose, kein Treiber).

  python3 hl_aktien.py --abrufen --db <hl_liq.db> [--quelle fred,drb,xyz,cftc,finra,farside,cboe,sec]
  python3 hl_aktien.py --text --db <hl_liq.db>          Stand des Archivs und Barometer als Text
  python3 hl_aktien.py --u147 --db <hl_liq.db>          Studie U147 „Fällt BTC, wenn der S&P 500 fällt?“ (Bericht)
  python3 hl_aktien.py --k12 --db <hl_liq.db>           Kurzstudie K1/K2 ETF-Flüsse und IBIT-Leerverkäufe (Bericht)
  python3 hl_aktien.py --selbsttest
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import numpy as np

VERSION_MODUL = "2026-09-23.92"
TAG = 86_400
BAR = 1800
NY = ZoneInfo("America/New_York")
UTC = timezone.utc
UA_BROWSER = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0 (aktien)"}
SEC_UA_STANDARD = "hl_liq_project admin@localhost.com"
HL_INFO = "https://api.hyperliquid.xyz/info"
XYZ_DEX = "xyz"
# laut trade.xyz-Übersicht (13.8); fehlt ein Wert im Dex, wird er still übersprungen
XYZ_INDIZES = ("SP500", "XYZ100", "VIX")
XYZ_TOP10 = ("NVDA", "MSFT", "AAPL", "AMZN", "GOOGL", "META", "AVGO", "TSLA", "LLY", "MU")
XYZ_KRYPTO = ("MSTR", "STRC", "COIN", "HOOD", "CRCL")
XYZ_ANLEIHEN = ("TLT",)
XYZ_ALLE = XYZ_INDIZES + XYZ_TOP10 + XYZ_KRYPTO + XYZ_ANLEIHEN
XYZ_30M = ("SP500", "XYZ100", "VIX", "MSTR", "STRC")          # 30-min-Kerzen (Schockregel 13.1 c, Barometer)
FRED_REIHEN = {
    "SP500": ("S&P 500 (Schluss)", "2016-01-01"),
    "NASDAQ100": ("Nasdaq-100 (Schluss)", "2000-01-01"),
    "VIXCLS": ("VIX (Schluss)", "2000-01-01"),
    "VXVCLS": ("VIX3M (Schluss)", "2007-12-01"),
    "BAA10Y": ("Baa minus 10 J (%)", "2000-01-01"),
    "STLFSI4": ("Finanzstress St. Louis (wöchentlich)", "2000-01-01"),
    "NFCI": ("Finanzbedingungen Chicago (wöchentlich)", "2000-01-01"),
    "BAMLH0A0HYM2": ("Hochzinsaufschlag ICE BofA (%), nur 3 Jahre sichtbar", "2000-01-01"),
}
FRED_FRISCH_TAGE = {"STLFSI4": 16, "NFCI": 16}                  # wöchentlich; sonst 10 Tage (Feiertage, Wochenende)
CFTC_URL = "https://publicreporting.cftc.gov/resource/gpe5-46if.json"
CFTC_KONTRAKTE = {"133741": "Bitcoin (CME, 5 BTC)", "13874A": "E-mini S&P 500", "209742": "E-mini Nasdaq-100"}
CFTC_FELDER = {                                                # Feldnamen des Socrata-Schemas (TFF); tolerant gesucht
    "oi": (r"^open_interest_all$",),
    "lev_long": (r"^lev_money_positions_long(_all)?$",), "lev_short": (r"^lev_money_positions_short(_all)?$",),
    "am_long": (r"^asset_mgr_positions_long(_all)?$",), "am_short": (r"^asset_mgr_positions_short(_all)?$",),
    "dealer_long": (r"^dealer_positions_long(_all)?$",), "dealer_short": (r"^dealer_positions_short(_all)?$",),
}
FINRA_URL = "https://cdn.finra.org/equity/regsho/daily/CNMSshvol{tag}.txt"
FINRA_SYMBOLE = ("IBIT", "MSTR", "COIN")
FINRA_AB = "2024-01-02"
FINRA_JE_LAUF = 20
FARSIDE_BTC = "https://farside.co.uk/bitcoin-etf-flow-all-data/"
CBOE_URLS = {"VVIX": ("https://cdn.cboe.com/api/global/us_indices/daily_prices/VVIX_History.csv",
                      "https://cdn-api.cboe.com/api/global/us_indices/daily_prices/VVIX_History.csv"),
             "VIX9D": ("https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX9D_History.csv",
                       "https://cdn-api.cboe.com/api/global/us_indices/daily_prices/VIX9D_History.csv")}
SEC_CIK = "0001050446"                                          # Strategy Inc (vormals MicroStrategy)
SEC_SUBMISSIONS = f"https://data.sec.gov/submissions/CIK{SEC_CIK}.json"
# 23.67: Die XBRL-Schnittstelle führt nur Angaben ohne Dimension. Strategy meldet die Aktienzahl auf dem Deckblatt offenbar nur je
# Aktienklasse -- companyconcept dei:EntityCommonStockSharesOutstanding antwortete am 12.10. mit HTTP 404 „NoSuchKey“. Deshalb der
# Reihe nach drei Abgrenzungen; gespeichert wird die erste, die Werte liefert, mit ihrem Namen (meta sec_aktien_quelle).
SEC_AKTIEN_KONZEPTE = (("dei", "EntityCommonStockSharesOutstanding", "Deckblatt", False),
                       ("us-gaap", "CommonStockSharesOutstanding", "Bilanz", False),
                       ("us-gaap", "WeightedAverageNumberOfSharesOutstandingBasic", "gewichteter Quartalsdurchschnitt", True))


def sec_aktien_url(tax: str, konzept: str) -> str:
    return f"https://data.sec.gov/api/xbrl/companyconcept/CIK{SEC_CIK}/{tax}/{konzept}.json"


SEC_AKTIEN = sec_aktien_url("dei", "EntityCommonStockSharesOutstanding")
SEC_8K_AB = "2024-01-01"
SEC_8K_JE_LAUF = 12
DRB_AB = "2021-03-24"                                           # Beginn von DVOL bei Deribit
DRB_FENSTER_H = 999
GBTC_START_BTC = 619_000.0                                      # ≈ GBTC-Bestand bei der Umwandlung (10.01.2024), Anker für K1
PAUSE_S = 1.0
TAKT_S = 60
SCHUTZ_MAX_S = 24 * 3600


# ================================================================================================ Kalender (NYSE, New York)

def _ostern(j: int) -> date:
    """Ostersonntag (gregorianisch, Meeus/Jones/Butcher)."""
    a = j % 19; b = j // 100; c = j % 100; d = b // 4; e = b % 4; f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30; i = c // 4; k = c % 4; L = (32 + 2 * e + 2 * i - h - k) % 7; m = (a + 11 * h + 22 * L) // 451
    mon = (h + L - 7 * m + 114) // 31; tag = ((h + L - 7 * m + 114) % 31) + 1
    return date(j, mon, tag)


def _nter_wochentag(j: int, mon: int, wtag: int, n: int) -> date:
    """n-ter Wochentag (0 = Montag) im Monat; n = -1: letzter."""
    if n > 0:
        d = date(j, mon, 1)
        d += timedelta(days=(wtag - d.weekday()) % 7)
        return d + timedelta(days=7 * (n - 1))
    d = date(j + (mon == 12), mon % 12 + 1, 1) - timedelta(days=1)
    return d - timedelta(days=(d.weekday() - wtag) % 7)


def _beobachtet(d: date, samstag_vorziehen: bool = True) -> date | None:
    """Fällt der Feiertag auf Samstag: Freitag davor (NYSE: nicht beim Neujahrstag); auf Sonntag: Montag danach."""
    if d.weekday() == 5:
        return d - timedelta(days=1) if samstag_vorziehen else None
    if d.weekday() == 6:
        return d + timedelta(days=1)
    return d


_SONDER_GESCHLOSSEN = {date(2018, 12, 5), date(2025, 1, 9)}     # Staatstrauer (Bush, Carter)


def nyse_feiertage(j: int) -> set:
    f = set()
    for d, vor in ((date(j, 1, 1), False), (date(j, 7, 4), True), (date(j, 12, 25), True)):
        b = _beobachtet(d, vor)
        if b is not None:
            f.add(b)
    if j >= 2022:
        b = _beobachtet(date(j, 6, 19))
        if b is not None:
            f.add(b)
    f |= {_nter_wochentag(j, 1, 0, 3), _nter_wochentag(j, 2, 0, 3), _ostern(j) - timedelta(days=2), _nter_wochentag(j, 5, 0, -1),
          _nter_wochentag(j, 9, 0, 1), _nter_wochentag(j, 11, 3, 4)}
    return f | {d for d in _SONDER_GESCHLOSSEN if d.year == j}


def handelstag(d: date) -> bool:
    return d.weekday() < 5 and d not in nyse_feiertage(d.year)


def ny_jetzt(ts: float | None = None) -> datetime:
    return datetime.fromtimestamp(time.time() if ts is None else ts, NY)


def boerse_offen(ts: float | None = None) -> bool:
    """Reguläre Handelszeit 9:30–16:00 New York an einem Handelstag (frühe Schlüsse nicht berücksichtigt)."""
    n = ny_jetzt(ts)
    return handelstag(n.date()) and (n.hour, n.minute) >= (9, 30) and n.hour < 16


def letzter_handelstag(bis: date) -> date:
    d = bis
    while not handelstag(d):
        d -= timedelta(days=1)
    return d


def ny_ts(d: date, stunde: int, minute: int = 0) -> int:
    """Unix-Zeit eines New Yorker Zeitpunkts an Tag d (Sommer-/Winterzeit richtig)."""
    return int(datetime(d.year, d.month, d.day, stunde, minute, tzinfo=NY).timestamp())


def tag_ts(s: str) -> int | None:
    try:
        return int(datetime.strptime(s[:10], "%Y-%m-%d").replace(tzinfo=UTC).timestamp())
    except (ValueError, TypeError):
        return None


def ts_datum(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), UTC).date()


# ================================================================================================ Datenhaltung (aktien.db)

SCHEMA = """
CREATE TABLE IF NOT EXISTS ak_wert (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, wert REAL,
    PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_aktuell (reihe TEXT NOT NULL, ts INTEGER NOT NULL, wert REAL, abgerufen INTEGER, fassungen INTEGER,
    PRIMARY KEY (reihe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_kerze (reihe TEXT NOT NULL, ts INTEGER NOT NULL, o REAL, h REAL, l REAL, c REAL, v REAL, abgerufen INTEGER,
    PRIMARY KEY (reihe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_text (reihe TEXT NOT NULL, ts INTEGER NOT NULL, abgerufen INTEGER NOT NULL, inhalt TEXT,
    PRIMARY KEY (reihe, ts, abgerufen)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ak_abruf (ts INTEGER, quelle TEXT, ziel TEXT, ok INTEGER, zeilen INTEGER, ms INTEGER, fehler TEXT);
CREATE INDEX IF NOT EXISTS ix_ak_abruf ON ak_abruf(quelle, ts);
CREATE TABLE IF NOT EXISTS ak_meta (k TEXT PRIMARY KEY, v TEXT);
"""


def aktien_pfad(db: str) -> str:
    """aktien.db liegt neben der Hauptdatenbank (wie makro.db); HL_AKTIEN_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_AKTIEN_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "aktien.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung: Autocommit, jede Schreibtransaktion mit BEGIN IMMEDIATE (Projektregel)."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


def lesen(pfad: str) -> sqlite3.Connection | None:
    """Nur lesen; legt nichts an."""
    if not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10, check_same_thread=False)


def _transaktion(con, fn):
    con.execute("BEGIN IMMEDIATE")
    try:
        r = fn()
        con.execute("COMMIT")
        return r
    except BaseException:
        con.execute("ROLLBACK")
        raise


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM ak_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r else standard


def meta_setzen(con, paare: dict) -> None:
    _transaktion(con, lambda: con.executemany("INSERT INTO ak_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                                              [(k, str(v)) for k, v in paare.items()]))


def _gleich(a, b) -> bool:
    if a is None or b is None:
        return a is None and b is None
    return abs(a - b) <= 1e-12 * max(1.0, abs(a), abs(b))


def archivieren(con, zeilen: list, abgerufen: int | None = None) -> int:
    """
    (reihe, ts, wert) ins Archiv: neu, wenn es (reihe, ts) noch nicht gibt oder der Wert von der jüngsten Fassung abweicht -- dann
    eine NEUE Zeile mit dieser Abrufzeit (Revision), die alte bleibt. ak_aktuell trägt die jüngste Fassung und die Zahl der Fassungen.
    Eine Transaktion. -> Zahl neuer Fassungen.
    """
    ab = int(abgerufen if abgerufen is not None else time.time())
    daten = [(str(r), int(t), float(w)) for r, t, w in zeilen if w is not None and math.isfinite(float(w))]
    if not daten:
        return 0
    reihen = sorted({r for r, _, _ in daten})

    def schreib():
        alt = {}
        for r in reihen:
            for t, w, n in con.execute("SELECT ts, wert, fassungen FROM ak_aktuell WHERE reihe=?", (r,)):
                alt[(r, int(t))] = (w, int(n or 1))
        neu_w, neu_a = [], []
        for r, t, w in daten:
            a = alt.get((r, t))
            if a is not None and _gleich(a[0], w):
                continue
            neu_w.append((r, t, ab, w))
            neu_a.append((r, t, w, ab, (a[1] + 1) if a else 1))
            alt[(r, t)] = (w, (a[1] + 1) if a else 1)
        con.executemany("INSERT OR IGNORE INTO ak_wert VALUES (?,?,?,?)", neu_w)
        con.executemany("INSERT INTO ak_aktuell VALUES (?,?,?,?,?) ON CONFLICT(reihe, ts) DO UPDATE SET wert=excluded.wert, "
                        "abgerufen=excluded.abgerufen, fassungen=excluded.fassungen", neu_a)
        return len(neu_w)
    return _transaktion(con, schreib)


def kerzen_schreiben(con, reihe: str, kerzen: list, abgerufen: int | None = None) -> int:
    """Nur abgeschlossene Kerzen (ts, o, h, l, c, v); eine schon gespeicherte bleibt (INSERT OR IGNORE). -> neue Kerzen."""
    ab = int(abgerufen if abgerufen is not None else time.time())
    zeilen = [(reihe, int(k[0]), *(float(x) for x in k[1:6]), ab) for k in kerzen]
    if not zeilen:
        return 0

    def schreib():
        vorher = con.total_changes
        con.executemany("INSERT OR IGNORE INTO ak_kerze VALUES (?,?,?,?,?,?,?,?)", zeilen)
        return con.total_changes - vorher
    return _transaktion(con, schreib)


def text_archivieren(con, reihe: str, ts: int, inhalt: dict, abgerufen: int | None = None) -> bool:
    ab = int(abgerufen if abgerufen is not None else time.time())
    s = json.dumps(inhalt, ensure_ascii=False, sort_keys=True)
    alt = con.execute("SELECT inhalt FROM ak_text WHERE reihe=? AND ts=? ORDER BY abgerufen DESC LIMIT 1", (reihe, int(ts))).fetchone()
    if alt and alt[0] == s:
        return False
    _transaktion(con, lambda: con.execute("INSERT OR IGNORE INTO ak_text VALUES (?,?,?,?)", (reihe, int(ts), ab, s)))
    return True


def protokoll(con, quelle: str, ziel: str, ok: bool, zeilen: int, ms: int, fehler: str = "") -> None:
    def schreib():
        con.execute("INSERT INTO ak_abruf VALUES (?,?,?,?,?,?,?)", (int(time.time()), quelle, ziel, int(bool(ok)), int(zeilen), int(ms),
                                                                    (fehler or "")[:240]))
        con.execute("DELETE FROM ak_abruf WHERE ts < ?", (int(time.time()) - 90 * TAG,))
    _transaktion(con, schreib)


def reihe(con, name: str, ab: int | None = None) -> tuple:
    """Jüngste Fassung einer Reihe: (ts, wert) als Arrays, aufsteigend."""
    q = "SELECT ts, wert FROM ak_aktuell WHERE reihe=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (name, int(ab)) if ab is not None else (name,)).fetchall()
    if not rows:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    a = np.array(rows, dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1]


def reihe_stand(con, name: str, stand: int) -> tuple:
    """Fassung, wie sie zum Zeitpunkt stand vorlag (Abrufzeit ≤ stand) -- für Rückblicke ohne spätere Revisionen."""
    rows = con.execute("SELECT w.ts, w.wert FROM ak_wert w JOIN (SELECT ts, MAX(abgerufen) AS a FROM ak_wert WHERE reihe=? AND "
                       "abgerufen<=? GROUP BY ts) m ON w.ts=m.ts AND w.abgerufen=m.a WHERE w.reihe=? ORDER BY w.ts",
                       (name, int(stand), name)).fetchall()
    if not rows:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    a = np.array(rows, dtype=float)
    return a[:, 0].astype(np.int64), a[:, 1]


def kerzen(con, name: str, ab: int | None = None) -> dict | None:
    q = "SELECT ts, o, h, l, c, v FROM ak_kerze WHERE reihe=?" + (" AND ts>=?" if ab is not None else "") + " ORDER BY ts"
    rows = con.execute(q, (name, int(ab)) if ab is not None else (name,)).fetchall()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}


def letzter_ts(con, name: str, tabelle: str = "ak_aktuell") -> int | None:
    r = con.execute(f"SELECT MAX(ts) FROM {tabelle} WHERE reihe=?", (name,)).fetchone()
    return int(r[0]) if r and r[0] is not None else None


# ================================================================================================ Netz

def fehlertext(code, rest: str) -> str:
    """23.67: Fehlertext einzeilig. Ein XML-Fehlerkörper (Amazon S3, z. B. SEC „NoSuchKey“) wird auf seinen Code verkürzt,
    sonst Leerraum und Zeilenumbrüche zusammengefasst (der Bericht vom 12.10. brach die Zeile mitten im XML um)."""
    rest = rest or ""
    m = re.search(r"<Code>\s*([^<]{1,60}?)\s*</Code>", rest)
    if m:
        rest = m.group(1)
    rest = " ".join(rest.split())
    return (f"HTTP {code}: {rest}" if code is not None else rest).strip()


def http(url: str, timeout: int = 30, art: str = "json", kopf: dict | None = None, daten: bytes | None = None):
    """(Inhalt, Fehlertext, HTTP-Status) -- wirft nie. art: json | text | bytes. daten: POST-Körper (JSON)."""
    h = dict(kopf or UA_BROWSER)
    if daten is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, headers=h, data=daten)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            roh = r.read(60 * 1024 * 1024)
            status = r.status
    except urllib.error.HTTPError as e:
        try:
            rest = e.read()[:160].decode("utf-8", "replace")
        except Exception:
            rest = ""
        return None, fehlertext(e.code, rest), e.code
    except Exception as e:
        return None, fehlertext(None, f"{type(e).__name__}: {e}"), None
    if art == "bytes":
        return roh, None, status
    text = roh.decode("utf-8", "replace")
    if art == "text":
        return text, None, status
    try:
        return json.loads(text), None, status
    except ValueError:
        return None, "kein JSON: " + text[:80].replace("\n", " "), status


def ist_html(text: str) -> bool:
    """Der Stooq-Fall: statt CSV/Text kommt eine HTML-Seite (Sperre, Anmeldung, Fehlerseite)."""
    t = (text or "").lstrip()[:200].lower()
    return t.startswith("<!doctype html") or t.startswith("<html") or "<head" in t or "<body" in t


def sec_user_agent(datei: str | None = None) -> str:
    """User-Agent für SEC EDGAR: HL_SEC_UA, sonst accesstokens.json -> "sec" -> "user_agent", sonst die Vorgabe des Nutzers."""
    k = (os.environ.get("HL_SEC_UA") or "").strip()
    if k:
        return k
    datei = datei or os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
    try:
        with open(datei, encoding="utf-8") as f:
            d = json.load(f)
        v = str((d.get("sec") or {}).get("user_agent") or "").strip()
        return v or SEC_UA_STANDARD
    except (OSError, ValueError, AttributeError):
        return SEC_UA_STANDARD


# ================================================================================================ Parser (reine Funktionen)

def _zahl(v) -> float | None:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) if math.isfinite(float(v)) else None
    s = str(v).strip().replace(",", "").replace("$", "")
    if s in ("", ".", "-", "–", "—", "NaN", "nan", "null", "None"):
        return None
    neg = s.startswith("(") and s.endswith(")")
    try:
        x = float(s.strip("()"))
    except ValueError:
        return None
    return -x if neg else x


def drb_stunden_parse(waehrung: str, d) -> tuple:
    """Deribit get_volatility_index_data (resolution 3600): {"result":{"data":[[ts_ms, o, h, l, c]], "continuation": ts|null}}."""
    r = (d or {}).get("result") or {} if isinstance(d, dict) else {}
    zeilen = []
    for z in r.get("data") or []:
        if not isinstance(z, (list, tuple)) or len(z) < 5:
            continue
        t = _zahl(z[0]); w = _zahl(z[4])
        if t and w is not None and w > 0:
            zeilen.append((f"drb:dvol_{waehrung.lower()}_h", int(t // 1000) // 3600 * 3600, w))
    return sorted(zeilen, key=lambda z: z[1]), r.get("continuation")


def xyz_stand_parse(d, dex: str = XYZ_DEX) -> dict:
    """
    metaAndAssetCtxs mit "dex": [meta, ctxs]; meta.universe[i].name („xyz:SP500“ oder „SP500“), ctxs[i] mit markPx, oraclePx,
    midPx, prevDayPx, dayNtlVlm, funding, openInterest (Zeichenketten). -> {Kürzel: {mark, oracle, mid, vortag, funding, oi, vol}}.
    """
    if not isinstance(d, list) or len(d) < 2 or not isinstance(d[0], dict) or not isinstance(d[1], list):
        raise ValueError("unerwartetes Format (metaAndAssetCtxs)")
    uni = d[0].get("universe") or []
    out = {}
    for a, c in zip(uni, d[1]):
        if not isinstance(a, dict) or not isinstance(c, dict):
            continue
        name = str(a.get("name") or "")
        kurz = name.split(":", 1)[1] if name.startswith(dex + ":") else name
        if not kurz:
            continue
        e = {"mark": _zahl(c.get("markPx")), "oracle": _zahl(c.get("oraclePx")), "mid": _zahl(c.get("midPx")),
             "vortag": _zahl(c.get("prevDayPx")), "funding": _zahl(c.get("funding")), "oi": _zahl(c.get("openInterest")),
             "vol": _zahl(c.get("dayNtlVlm")), "delisted": bool(a.get("isDelisted"))}
        out[kurz.upper()] = e
    return out


def xyz_kerzen_parse(d, jetzt_ms: int) -> list:
    """candleSnapshot: [{"t": open_ms, "T": close_ms, "o","h","l","c","v": str, "n": int}] -> abgeschlossene (ts_s, o, h, l, c, v)."""
    if not isinstance(d, list):
        raise ValueError("unerwartetes Format (candleSnapshot)")
    out = []
    for k in d:
        if not isinstance(k, dict):
            continue
        t, T = _zahl(k.get("t")), _zahl(k.get("T"))
        werte = [_zahl(k.get(x)) for x in ("o", "h", "l", "c", "v")]
        if t is None or T is None or any(w is None for w in werte) or T >= jetzt_ms:
            continue
        out.append((int(t // 1000), *werte))
    return sorted(out)


def _feld(datensatz: dict, muster: tuple) -> str | None:
    for m in muster:
        for k in datensatz:
            if re.match(m, k):
                return k
    return None


def cftc_parse(d) -> tuple:
    """
    Socrata (TFF, Futures only): [{"report_date_as_yyyy_mm_dd": "2026-10-06T00:00:00.000", "cftc_contract_market_code": "133741",
    "open_interest_all": "21432", "lev_money_positions_long": "5731", ...}] -> (Zeilen (reihe, ts, wert), fehlende Felder).
    """
    if not isinstance(d, list):
        raise ValueError("unerwartetes Format (CFTC)")
    zeilen, fehlen = [], set()
    for r in d:
        if not isinstance(r, dict):
            continue
        t = tag_ts(str(r.get("report_date_as_yyyy_mm_dd") or "")[:10])
        code = str(r.get("cftc_contract_market_code") or "").strip()
        if t is None or not code:
            continue
        for name, muster in CFTC_FELDER.items():
            k = _feld(r, muster)
            if k is None:
                fehlen.add(name); continue
            w = _zahl(r.get(k))
            if w is not None:
                zeilen.append((f"cftc:{code}:{name}", t, w))
    return zeilen, sorted(fehlen)


def finra_parse(text: str, symbole=FINRA_SYMBOLE) -> list:
    """CNMSshvol: 'Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market' (Werte mit Nachkommastellen). -> Zeilen."""
    if ist_html(text):
        raise ValueError("HTML statt Textdatei")
    zeilen_txt = (text or "").strip().splitlines()
    if not zeilen_txt or not zeilen_txt[0].startswith("Date|Symbol|ShortVolume"):
        raise ValueError("unerwarteter Kopf: " + (zeilen_txt[0][:60] if zeilen_txt else "leer"))
    kopf = zeilen_txt[0].split("|")
    i_s, i_e, i_t = kopf.index("ShortVolume"), kopf.index("ShortExemptVolume"), kopf.index("TotalVolume")
    out = []
    for z in zeilen_txt[1:]:
        f = z.split("|")
        if len(f) < len(kopf) or f[1] not in symbole:
            continue
        t = tag_ts(f"{f[0][:4]}-{f[0][4:6]}-{f[0][6:8]}")
        if t is None:
            continue
        for name, i in (("short", i_s), ("exempt", i_e), ("total", i_t)):
            w = _zahl(f[i])
            if w is not None:
                out.append((f"finra:{f[1]}:{name}", t, w))
    return out


_MONATE = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def farside_fonds_parse(html: str, coin: str = "btc") -> list:
    """
    Farside-Tabelle je Fonds: Kopfzeile mit den Kürzeln (IBIT, FBTC, … GBTC, BTC, Total), Datenzeilen „11 Jan 2024“ mit Mio USD;
    Klammern = negativ, „-“ = keine Daten (nicht null). Zeilen ohne Datum (Total, Average, Maximum, Minimum) fallen weg.
    """
    if not html or "<tr" not in html:
        raise ValueError("keine Tabelle")
    kopf = None; out = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S):
        cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
        if len(cells) < 3:
            continue
        if kopf is None and any(c in ("IBIT", "GBTC", "FBTC", "ETHA", "ETHE") for c in cells):
            kopf = [re.sub(r"\s+", "", c) for c in cells]
            continue
        m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
        if kopf is None or not m or m.group(2) not in _MONATE:
            continue
        t = tag_ts(f"{m.group(3)}-{_MONATE[m.group(2)]:02d}-{int(m.group(1)):02d}")
        for name, c in zip(kopf[1:], cells[1:]):
            if not name:
                continue
            w = _zahl(c)
            if w is not None:
                out.append((f"farside:{coin}:{name}", t, w))
    if kopf is None:
        raise ValueError("Kopfzeile mit den Fonds nicht gefunden")
    return out


FARSIDE_PRUEF_TAGE = 3          # 23.68 (U165): die letzten 3 Handelstage werden auf fehlende Fonds geprüft
FARSIDE_EINGESTELLT_TAGE = 4    # ohne Zahl an den letzten 4 Handelstagen: Fonds gilt als eingestellt (eigener Hinweis, markiert nichts)
FARSIDE_LOG_N = 40              # gemerkte Abrufe für die Zählung „jüngster Tag unvollständig“ (ausgewertet die letzten 20)


def etf_vollstaendigkeit(je_fonds: dict, tage: list, pruef: int = FARSIDE_PRUEF_TAGE, eingestellt_ab: int = FARSIDE_EINGESTELLT_TAGE) -> dict:
    """
    23.68 (U165): Der jüngste Farside-Tag kann unvollständig sein (13.10.: der 12.10. ohne IBIT und HODL, die Tagessumme damit zu klein).
    je_fonds: {Fonds: {tag_ts: Mio USD}} ohne „Total“; „-“ steht nicht darin (keine Daten, nicht null). tage: Handelstage aufsteigend
    (Tage mit „Total“). Ein geprüfter Tag (die letzten `pruef`) ist unvollständig, wenn ein aktiver Fonds, der schon vorher Zahlen hatte,
    dort keine hat. Ohne Zahl an den letzten `eingestellt_ab` Handelstagen gilt ein Fonds als eingestellt: eigener Hinweis, er markiert keinen Tag.
    -> {"geprueft": [tag], "unvollstaendig": {tag: [Fonds]}, "eingestellt": [Fonds]}
    """
    tage = sorted(int(t) for t in tage)
    out = {"geprueft": tage[-pruef:], "unvollstaendig": {}, "eingestellt": []}
    if not tage:
        return out
    grenze = tage[-eingestellt_ab] if len(tage) >= eingestellt_ab else tage[0]
    for f, w in sorted(je_fonds.items()):
        da = sorted(t for t in w if t <= tage[-1])
        if not da:
            continue
        if da[-1] < grenze:
            out["eingestellt"].append(f)
            continue
        for d in out["geprueft"]:
            if d not in w and da[0] < d:
                out["unvollstaendig"].setdefault(d, []).append(f)
    return out


def etf_summen(total: list, unvollstaendig: dict) -> dict:
    """total: [(tag, Mio USD)] absteigend. Summen über die letzten 5 und 20 Handelstage nur mit vollständigen Tagen, mit deren Zahl."""
    out = {}
    for n in (5, 20):
        teil = total[:n]
        voll = [w for t, w in teil if t not in unvollstaendig]
        out[f"summe{n}"] = float(sum(voll)) if len(teil) >= n and voll else None
        out[f"voll{n}"] = len(voll)
    return out


FARSIDE_ZAEHL_N = 20            # 23.68 (U165): ausgewertet werden die letzten 20 gemerkten Abrufe


def _slot_name(slot: tuple) -> str:
    """Abruftermin als Text, z. B. „13:00 UTC“."""
    if slot[0] == "utc":
        return f"{slot[1]:02d}:{slot[2]:02d} UTC"
    if slot[0] == "ny":
        return f"{slot[1]:02d}:{slot[2]:02d} New York"
    return str(slot)


def farside_zaehlung(log: list, slots: tuple | None = None) -> dict:
    """23.68 (U165): an wie vielen der letzten 20 gemerkten Abrufe der jüngste Tag unvollständig war. Seit 23.92 (U240, KONZEPT_Ausblick.md
    13.21) auch je Abrufzeit: Ein Abruf zählt zu dem jüngsten Abruftermin vor seinem Zeitpunkt (UTC; ein Abruf um 00:30 UTC gehört zu
    13:00 UTC des Vortags). Rückwirkend für alle gemerkten Abrufe, denn jeder trägt seinen Zeitpunkt."""
    slots = tuple(slots or TERMINE["farside"]["slots"])
    log = [e for e in (log or []) if isinstance(e, dict) and e.get("ts")][-FARSIDE_ZAEHL_N:]
    je: dict = {}
    for e in log:
        bezug = int(e["ts"])                                   # Zeitpunkt des Abrufs (Unix, also UTC)
        s = max(slots, key=lambda sl: _slot_ts(sl, bezug))
        z = je.setdefault(_slot_name(s), {"n": 0, "unvollstaendig": 0})
        z["n"] += 1
        z["unvollstaendig"] += 1 if e.get("fehlt") else 0
    return {"n": len(log), "unvollstaendig": sum(1 for e in log if e.get("fehlt")), "seit": int(log[0]["ts"]) if log else None,
            "je_uhrzeit": [dict(uhrzeit=k, **v) for k, v in sorted(je.items())]}


def farside_fonds(con) -> tuple:
    """(je Fonds {tag: wert}, Total [(tag, wert, abgerufen, fassungen)] absteigend) aus ak_aktuell."""
    je, total = {}, []
    for r, t, w, ab, fa in con.execute("SELECT reihe, ts, wert, abgerufen, fassungen FROM ak_aktuell WHERE reihe LIKE 'farside:btc:%' ORDER BY ts"):
        name = r.split(":", 2)[2]
        if name == "Total":
            total.append((int(t), float(w), ab, fa))
        else:
            je.setdefault(name, {})[int(t)] = float(w)
    return je, sorted(total, key=lambda x: -x[0])


def cboe_parse(name: str, text: str) -> list:
    """Cboe-CSV: 'DATE,OPEN,HIGH,LOW,CLOSE' (VIX9D) bzw. 'DATE,VVIX'; Datum MM/DD/YYYY. Schluss bzw. letzte Spalte."""
    if ist_html(text):
        raise ValueError("HTML statt CSV")
    r = list(csv.reader(io.StringIO(text or "")))
    if not r or not r[0] or r[0][0].strip().upper() != "DATE":
        raise ValueError("unerwarteter Kopf: " + (",".join(r[0])[:60] if r else "leer"))
    kopf = [c.strip().upper() for c in r[0]]
    j = kopf.index("CLOSE") if "CLOSE" in kopf else len(kopf) - 1
    out = []
    for z in r[1:]:
        if len(z) <= j:
            continue
        s = z[0].strip()
        try:
            d = datetime.strptime(s, "%m/%d/%Y") if "/" in s else datetime.strptime(s[:10], "%Y-%m-%d")
        except ValueError:
            continue
        w = _zahl(z[j])
        if w is not None:
            out.append((f"cboe:{name}", int(d.replace(tzinfo=UTC).timestamp()), w))
    return out


def sec_8k_liste(d, ab: str = SEC_8K_AB) -> list:
    """submissions JSON: filings.recent (Spalten als Listen) -> [{acc, datum, doc, form}] der 8-K ab Datum, aufsteigend."""
    rec = ((d or {}).get("filings") or {}).get("recent") or {} if isinstance(d, dict) else {}
    acc, dat, form, doc = (rec.get(k) or [] for k in ("accessionNumber", "filingDate", "form", "primaryDocument"))
    out = []
    for a, t, f, p in zip(acc, dat, form, doc):
        if str(f).strip().upper() in ("8-K", "8-K/A") and str(t) >= ab and p:
            out.append({"acc": str(a), "datum": str(t)[:10], "doc": str(p), "form": str(f)})
    return sorted(out, key=lambda x: (x["datum"], x["acc"]))


def sec_dok_url(acc: str, doc: str, cik: str = SEC_CIK) -> str:
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-', '')}/{doc}"


_BESTAND_MUSTER = (
    re.compile(r"aggregate\s+of\s+approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
    re.compile(r"held\s+(?:an\s+aggregate\s+of\s+)?approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
    re.compile(r"holds?\s+(?:an\s+aggregate\s+of\s+)?approximately\s+([\d,]{4,})\s+(?:bitcoins?|BTC)", re.I),
)
# 23.69 (U177): Tabelle „Aggregate BTC Holdings“ -- bis 23.68 nahm ein viertes Muster die ERSTE große Zahl nach der Spalte, in der
# Tabelle die gekauften BTC (Bericht 18.10.: „zuletzt +846.001 BTC“). Jetzt: in der Tabelle mit dieser Spalte die größte ganze Zahl mit
# Tausenderkomma ohne vorangestelltes „$“ (gekaufte BTC < Bestand; Preise stehen mit „$“ oder mit Nachkommastellen).
_BESTAND_SPALTE = re.compile(r"Aggregate\s+BTC\s+Holdings", re.I)
_BESTAND_ZAHL = re.compile(r"(\$\s*)?(?<![\d.,])(\d{1,3}(?:,\d{3})+)(\.\d+)?(?!\d|,\d)")
MSTR_PLAUSIBEL = 0.30                     # Abweichung zum Nachbarbestand, ab der ein gelesener Bestand „unplausibel“ ist
MSTR_NACHBAR_S = 9 * TAG                  # Nachbar = ein anderer Bestand höchstens 9 Tage entfernt (die 8-K kommen wöchentlich)
SEC_NEULESEN_JE_LAUF = 6                  # unplausible Bestände im Archiv: je Lauf so viele 8-K einmal neu lesen


def _sec_text(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html or "")
    text = re.sub(r"&nbsp;|&#160;|&#xa0;", " ", text, flags=re.I)
    text = text.replace("&#36;", "$")
    return re.sub(r"\s+", " ", text)


def _tabelle_bestand(text: str) -> float | None:
    """Text nach der Spalte „Aggregate BTC Holdings“ -> größte ganze Zahl mit Tausenderkomma ohne „$“ davor (1.000 … 5 Mio.)."""
    m = _BESTAND_SPALTE.search(text)
    if not m:
        return None
    best = None
    for g in _BESTAND_ZAHL.finditer(text[m.end():]):
        if g.group(1) or g.group(3):
            continue
        w = _zahl(g.group(2))
        if w is not None and 1_000 <= w <= 5_000_000 and (best is None or w > best):
            best = w
    return best


def sec_bestand_parse(html: str) -> float | None:
    """BTC-Bestand aus dem Text eines Strategy-8-K („… held an aggregate of approximately 640,031 bitcoins“) oder aus der Tabelle mit
    der Spalte „Aggregate BTC Holdings“ (23.69, U177: je Tabelle für sich, damit eine Nachbartabelle etwa mit verkauften Aktien nicht
    mitzählt; ohne Tabellen-Tags die 600 Zeichen nach der Spalte). Nichts gefunden -> None (das 8-K betrifft dann etwas anderes)."""
    text = _sec_text(html)
    for m in _BESTAND_MUSTER:
        g = m.search(text)
        if g:
            w = _zahl(g.group(1))
            if w is not None and 1_000 <= w <= 5_000_000:
                return w
    tabellen = re.findall(r"<table\b.*?</table\s*>", html or "", re.I | re.S)
    for t in tabellen:
        w = _tabelle_bestand(_sec_text(t))
        if w is not None:
            return w
    if not any(_BESTAND_SPALTE.search(_sec_text(t)) for t in tabellen):
        m = _BESTAND_SPALTE.search(text)
        if m:
            return _tabelle_bestand(text[m.start():m.end() + 600])
    return None


def mstr_plausibel(P: list) -> list:
    """23.69 (U177): je gelesenem Bestand (ts, BTC), zeitlich sortiert, ob er zu seinen Nachbarn passt -- unplausibel, wenn ein anderer
    Bestand höchstens 9 Tage entfernt um mehr als 30 % größer ist (falsch gelesene Werte sind kleiner: gekaufte BTC, Preise). Ohne
    Nachbarn bleibt ein Wert stehen (nicht beurteilbar)."""
    out = []
    for i, (t, w) in enumerate(P):
        nb = [w2 for j, (t2, w2) in enumerate(P) if j != i and abs(int(t2) - int(t)) <= MSTR_NACHBAR_S]
        out.append(not (nb and w < (1 - MSTR_PLAUSIBEL) * max(nb)))
    return out


def mstr_pruefen(P: list, t: int, w: float) -> str | None:
    """Neuer Bestand w zum Tag t gegen die plausiblen Bestände im Archiv, die höchstens 9 Tage entfernt sind (im Normalfall der letzte
    Bestand der Vorwoche): mehr als 30 % darunter -> Begründung, sonst None. Nur nach unten (vor dem Bau festgelegt, 19.10.): Strategy
    verkauft nicht, falsch gelesene Werte sind kleiner (gekaufte BTC, Preise); eine Prüfung auch nach oben ließe einen einmal
    durchgerutschten kleinen Wert jeden richtigen der Folgewoche sperren."""
    nb = [(t2, w2) for (t2, w2), g in zip(P, mstr_plausibel(P)) if g and abs(int(t2) - int(t)) <= MSTR_NACHBAR_S and int(t2) != int(t)]
    if not nb:
        return None
    t_r, w_r = max(nb, key=lambda x: x[1])
    if w < (1 - MSTR_PLAUSIBEL) * w_r:
        return f"{w:,.0f} gegen {w_r:,.0f} am {ts_datum(int(t_r)).strftime('%d.%m.%Y')} ({(w / w_r - 1) * 100:+.0f} %)".replace(",", ".")
    return None


def mstr_unplausibel_8k(con, n: int = 6) -> list:
    """Die jüngsten 8-K, deren gelesener Bestand nicht übernommen wurde (neu oder beim Neulesen): [[Datum, Grund]] (U177)."""
    rec = {}
    try:
        for inh, in con.execute("SELECT inhalt FROM ak_text WHERE reihe='sec:8k' ORDER BY abgerufen"):
            try:
                d = json.loads(inh)
            except ValueError:
                continue
            if isinstance(d, dict) and d.get("acc"):
                rec[d["acc"]] = d
    except sqlite3.Error:
        return []
    return [[d.get("datum"), d["unplausibel"]] for d in sorted(rec.values(), key=lambda d: str(d.get("datum"))) if d.get("unplausibel")][-n:]


def mstr_bestand(con) -> dict:
    """Bestandsreihe für Bericht und Dashboard ohne unplausible Werte (U177): {ts, w, unplausibel [(ts, BTC)]}."""
    tb, wb = reihe(con, "sec:mstr_btc")
    P = [(int(t), float(w)) for t, w in zip(tb, wb)]
    g = mstr_plausibel(P)
    return {"ts": [t for (t, _w), k in zip(P, g) if k], "w": [w for (_t, w), k in zip(P, g) if k],
            "unplausibel": [(t, w) for (t, w), k in zip(P, g) if not k]}


def sec_aktien_parse(d, dauer: bool = False) -> list:
    """companyconcept (Aktienzahl): units.shares [{end, val, accn, filed}] -> [(ts_end, Summe je Meldung)].
    Mehrere Einträge mit gleichem Stichtag und gleicher Meldung (Aktienklassen) werden addiert.
    dauer=True (23.67, Zeitraum-Größe wie der gewichtete Durchschnitt): nur Quartale (80–100 Tage zwischen start und end); dieselbe
    Meldung nennt zum selben Stichtag oft auch das Halb- oder Dreivierteljahr -- das wird nicht addiert."""
    if not isinstance(d, dict):
        raise ValueError("unerwartetes Format (companyconcept)")
    je = {}
    for e in ((d.get("units") or {}).get("shares") or []):
        t = tag_ts(str(e.get("end") or ""))
        w = _zahl(e.get("val"))
        if t is None or w is None:
            continue
        if dauer:
            t0 = tag_ts(str(e.get("start") or ""))
            if t0 is None or not (80 <= (t - t0) / TAG <= 100):
                continue
        je.setdefault((t, str(e.get("accn") or "")), set()).add(w)
    beste = {}
    for (t, acc), ws in je.items():
        s = float(sum(ws))                                         # gleiche Werte doppelt gemeldet: einmal; verschiedene Klassen: Summe
        if t not in beste or acc > beste[t][1]:
            beste[t] = (s, acc)
    return sorted((t, v[0]) for t, v in beste.items())


# ================================================================================================ Abruf je Quelle (Schutzschalter)

QUELLEN = ("xyz", "drb", "fred", "farside", "finra", "cboe", "cftc", "sec")
QUELLEN_NAME = {"xyz": "Hyperliquid xyz (Aktien-Perps)", "drb": "Deribit DVOL (stündlich)", "fred": "FRED", "farside": "Farside (ETF-Flüsse)",
                "finra": "FINRA Reg SHO", "cboe": "Cboe-CSV (optional)", "cftc": "CFTC (TFF)", "sec": "SEC EDGAR (Strategy)"}
OPTIONAL = {"cboe"}
# Termine (13.8): Archiv abends nach 18:00 ET und morgens 13:00 UTC für FRED, CFTC freitags nach der Veröffentlichung (15:30 ET)
# mit Nachholtermin montags, FINRA abends, xyz und DVOL alle 30 min.
TERMINE = {
    "xyz": {"alle_s": 1800},
    "drb": {"alle_s": 1800},
    "fred": {"slots": (("utc", 13, 0), ("ny", 18, 15))},
    "farside": {"slots": (("utc", 13, 0), ("utc", 1, 0))},
    "finra": {"slots": (("ny", 18, 45),), "rueckstand_s": 1800},
    "cboe": {"slots": (("ny", 18, 30),)},
    "cftc": {"slots": (("nywt", 4, 16, 0), ("nywt", 0, 10, 0))},
    "sec": {"slots": (("utc", 13, 30), ("utc", 23, 30))},
}


def _slot_ts(slot: tuple, jetzt: float) -> int:
    """Jüngster Zeitpunkt des Slots ≤ jetzt."""
    if slot[0] == "utc":
        d = datetime.fromtimestamp(jetzt, UTC).date()
        for k in range(0, 3):
            t = int(datetime(d.year, d.month, d.day, slot[1], slot[2], tzinfo=UTC).timestamp()) - k * TAG
            if t <= jetzt:
                return t
    if slot[0] == "ny":
        d = ny_jetzt(jetzt).date()
        for k in range(0, 3):
            t = ny_ts(d - timedelta(days=k), slot[1], slot[2])
            if t <= jetzt:
                return t
    if slot[0] == "nywt":                                        # (Wochentag 0 = Montag, Stunde, Minute) in New York
        d = ny_jetzt(jetzt).date()
        for k in range(0, 8):
            dd = d - timedelta(days=k)
            if dd.weekday() == slot[1]:
                t = ny_ts(dd, slot[2], slot[3])
                if t <= jetzt:
                    return t
    return 0


def faellig(con, quelle: str, jetzt: float) -> bool:
    pause = meta(con, f"pause_bis:{quelle}")
    if pause and jetzt < float(pause):
        return False
    letzt = meta(con, f"versuch:{quelle}")
    if letzt is None:
        return True
    letzt = float(letzt)
    T = TERMINE[quelle]
    if "alle_s" in T:
        return jetzt - letzt >= T["alle_s"] - 30
    if T.get("rueckstand_s") and int(meta(con, f"rueckstand:{quelle}", "0") or 0) > 0 and jetzt - letzt >= T["rueckstand_s"]:
        return True
    return letzt < max(_slot_ts(s, jetzt) for s in T["slots"])


class Abruf:
    """Ein Abruf-Lauf: eigene Schreibverbindung, Protokoll je Quelle, Schutzschalter (Pause 30 min · 2^(n−1), höchstens 24 h)."""

    def __init__(self, pfad: str, makro_pfad: str | None = None, http_fn=None, jetzt_fn=None, log=None, schlafen=True):
        self.pfad = pfad; self.con = verbinden(pfad); self.http = http_fn or http; self.jetzt = jetzt_fn or time.time
        self.log = log or (lambda *a: None); self.makro_pfad = makro_pfad; self.schlafen = schlafen

    def close(self):
        self.con.close()

    def _pause(self, s: float):
        if self.schlafen:
            time.sleep(s)

    def lauf(self, quelle: str) -> dict:
        t0 = time.time(); jetzt = self.jetzt()
        meta_setzen(self.con, {f"versuch:{quelle}": int(jetzt)})
        try:
            neu, info = getattr(self, "_" + quelle)()
            ok, fehler = True, ""
        except Exception as e:
            neu, info, ok, fehler = 0, "", False, f"{type(e).__name__}: {e}"[:240]
        ms = int((time.time() - t0) * 1000)
        protokoll(self.con, quelle, info[:60] if ok else "", ok, neu, ms, fehler if not ok else info)
        if ok:
            meta_setzen(self.con, {f"ok:{quelle}": int(jetzt), f"fehler_n:{quelle}": 0, f"pause_bis:{quelle}": 0, f"info:{quelle}": info[:200]})
        else:
            n = int(meta(self.con, f"fehler_n:{quelle}", "0") or 0) + 1
            pause = 0 if quelle in OPTIONAL else min(SCHUTZ_MAX_S, 1800 * 2 ** (n - 1))
            meta_setzen(self.con, {f"fehler_n:{quelle}": n, f"pause_bis:{quelle}": int(jetzt + pause), f"fehler:{quelle}": fehler})
        self.log(f"  {QUELLEN_NAME.get(quelle, quelle)}: {'ok' if ok else 'FEHLER'} · {neu} neue Fassungen · {ms} ms"
                 + (f" · {info}" if ok and info else "") + (f" · {fehler}" if not ok else ""))
        return {"quelle": quelle, "ok": ok, "neu": neu, "ms": ms, "info": info, "fehler": fehler}

    # ---------------------------------------------------------------- FRED (Schlüssel aus hl_makro)
    def _makro_import(self) -> int:
        """Einmalig: die Historie des Hochzinsaufschlags aus makro.db (dort seit 05.10. gesichert) mit ihren Abrufzeiten übernehmen --
        nur Tage vor dem ersten eigenen Wert, damit keine ältere Fassung eine jüngere verdeckt."""
        if meta(self.con, "import_makro_hy") is not None or not self.makro_pfad or not os.path.exists(self.makro_pfad):
            return 0
        try:
            mc = sqlite3.connect(f"file:{self.makro_pfad}?mode=ro", uri=True, timeout=10)
            try:
                rows = mc.execute("SELECT ts, wert, abgerufen FROM mk_reihe WHERE reihe='fred:BAMLH0A0HYM2' ORDER BY ts").fetchall()
            finally:
                mc.close()
        except sqlite3.Error:
            return 0
        erst = self.con.execute("SELECT MIN(ts) FROM ak_aktuell WHERE reihe='fred:BAMLH0A0HYM2'").fetchone()[0]
        neu = 0
        je_abruf: dict = {}
        for t, w, ab in rows:
            if erst is None or int(t) < int(erst):
                je_abruf.setdefault(int(ab or 0), []).append(("fred:BAMLH0A0HYM2", int(t), w))
        for ab in sorted(je_abruf):
            neu += archivieren(self.con, je_abruf[ab], ab or int(self.jetzt()))
        meta_setzen(self.con, {"import_makro_hy": neu})
        return neu

    def _fred(self) -> tuple:
        import hl_makro as MK
        neu = self._makro_import()
        k = MK.fred_schluessel_lesen()
        jetzt = int(self.jetzt()); fehler = []; alt = []
        for sid, (_, start0) in FRED_REIHEN.items():
            letzt = letzter_ts(self.con, f"fred:{sid}")
            start = start0 if letzt is None else ts_datum(letzt - 60 * TAG).isoformat()     # Revisionen der letzten 60 Tage
            if k:
                d, err, _ = self.http(MK.fred_api_url(sid, start, k), timeout=MK.FRED_TIMEOUT_API)
                zeilen = MK.fred_api_parse(sid, d) if not err else []
            else:
                text, err, _ = self.http(MK.fred_url(sid, start), timeout=MK.FRED_TIMEOUT_CSV, art="text")
                if not err and ist_html(text):
                    err = "HTML statt CSV"
                zeilen = MK.fred_parse(sid, text) if not err else []
            if err:
                fehler.append(f"{sid}: {MK._geschwaerzt(err, k)}"); continue
            if not zeilen:
                fehler.append(f"{sid}: keine Zeilen"); continue
            neu += archivieren(self.con, zeilen, jetzt)
            juengst = max(t for _, t, _ in zeilen)
            if (jetzt - juengst) / TAG > FRED_FRISCH_TAGE.get(sid, 10):
                alt.append(f"{sid} zuletzt {ts_datum(juengst).strftime('%d.%m.')}")
            self._pause(PAUSE_S)
        if len(fehler) == len(FRED_REIHEN):
            raise RuntimeError("; ".join(fehler)[:240] + ("" if k else " (kein FRED-Schlüssel)"))
        return neu, "; ".join(fehler + alt)[:200]

    # ---------------------------------------------------------------- Deribit DVOL stündlich
    def _drb(self) -> tuple:
        neu = 0; jetzt = int(self.jetzt()); t0 = time.time(); rest = []
        for w in ("BTC", "ETH"):
            name = f"drb:dvol_{w.lower()}_h"
            letzt = letzter_ts(self.con, name)
            von = tag_ts(DRB_AB) if letzt is None else letzt - 2 * 3600
            while von < jetzt - 3600:
                if time.time() - t0 > 90:
                    rest.append(w); break
                bis = min(jetzt, von + DRB_FENSTER_H * 3600)
                d, err, _ = self.http("https://www.deribit.com/api/v2/public/get_volatility_index_data?currency="
                                      f"{w}&start_timestamp={von * 1000}&end_timestamp={bis * 1000}&resolution=3600")
                if err:
                    raise RuntimeError(f"{w}: {err}")
                z, _ = drb_stunden_parse(w, d)
                neu += archivieren(self.con, [x for x in z if x[1] + 3600 <= jetzt], jetzt)       # nur abgeschlossene Stunden
                von = bis
                self._pause(0.3)
        return neu, (f"Historie lädt noch: {', '.join(rest)}" if rest else "")

    # ---------------------------------------------------------------- Hyperliquid xyz
    def _hl(self, body: dict):
        d, err, _ = self.http(HL_INFO, daten=json.dumps(body).encode(), kopf={"User-Agent": "hl-dashboard/1.0 (aktien)"}, timeout=20)
        if err:
            raise RuntimeError(err)
        return d

    def _xyz(self) -> tuple:
        jetzt = int(self.jetzt())
        stand = xyz_stand_parse(self._hl({"type": "metaAndAssetCtxs", "dex": XYZ_DEX}))
        minute = jetzt // 60 * 60
        zeilen = []
        for kurz in XYZ_ALLE:
            e = stand.get(kurz)
            if not e or e.get("delisted"):
                continue
            for f in ("mark", "oracle", "mid"):
                if e.get(f) is not None:
                    zeilen.append((f"xyz:{kurz}:{f}", minute, e[f]))
        neu = archivieren(self.con, zeilen, jetzt)
        fehlt = [k for k in XYZ_ALLE if k not in stand]
        meta_setzen(self.con, {"xyz_stand": json.dumps({k: stand[k] for k in XYZ_ALLE if k in stand}), "xyz_ts": jetzt,
                               "xyz_fehlt": ",".join(fehlt)})
        info = []
        for kurz in XYZ_30M:
            if kurz not in stand or stand[kurz].get("delisted"):          # 23.67: eingestellte Märkte nicht mehr abfragen
                continue
            name = f"xyz:{kurz}:30m"
            letzt = letzter_ts(self.con, name, "ak_kerze")
            start = (jetzt - 60 * TAG) if letzt is None else letzt + BAR
            if start > jetzt - BAR:
                continue
            try:
                d = self._hl({"type": "candleSnapshot", "req": {"coin": f"{XYZ_DEX}:{kurz}", "interval": "30m",
                                                                "startTime": start * 1000, "endTime": jetzt * 1000}})
                neu += kerzen_schreiben(self.con, name, xyz_kerzen_parse(d, jetzt * 1000), jetzt)
            except (RuntimeError, ValueError) as e:
                info.append(f"{kurz} 30m: {e}"[:60])
            self._pause(1.0)
        heute = datetime.fromtimestamp(jetzt, UTC).date().isoformat()
        if meta(self.con, "xyz_1d_tag") != heute:                       # Tageskerzen einmal je Tag (Abstand zum Hoch, Struktur)
            for kurz in XYZ_ALLE:
                if kurz not in stand or stand[kurz].get("delisted"):
                    continue
                name = f"xyz:{kurz}:1d"
                letzt = letzter_ts(self.con, name, "ak_kerze")
                start = (jetzt - 500 * TAG) if letzt is None else letzt + TAG
                if start > jetzt - TAG:
                    continue
                try:
                    d = self._hl({"type": "candleSnapshot", "req": {"coin": f"{XYZ_DEX}:{kurz}", "interval": "1d",
                                                                    "startTime": start * 1000, "endTime": jetzt * 1000}})
                    neu += kerzen_schreiben(self.con, name, xyz_kerzen_parse(d, jetzt * 1000), jetzt)
                except (RuntimeError, ValueError) as e:
                    info.append(f"{kurz} 1d: {e}"[:60])
                self._pause(1.0)
            meta_setzen(self.con, {"xyz_1d_tag": heute})
        if fehlt:
            info.insert(0, "nicht im Dex: " + ", ".join(fehlt))
        return neu, "; ".join(info)[:200]

    # ---------------------------------------------------------------- CFTC TFF
    def _cftc(self) -> tuple:
        codes = list(CFTC_KONTRAKTE)
        letzt = [letzter_ts(self.con, f"cftc:{c}:oi") for c in codes]
        ab = "2017-12-01" if any(x is None for x in letzt) else ts_datum(min(letzt) - 35 * TAG).isoformat()
        where = (f"cftc_contract_market_code in({','.join(repr(c) for c in codes)}) AND "
                 f"report_date_as_yyyy_mm_dd >= '{ab}T00:00:00.000'")
        url = CFTC_URL + "?" + urllib.parse.urlencode({"$where": where, "$order": "report_date_as_yyyy_mm_dd", "$limit": "50000"})
        d, err, _ = self.http(url, timeout=60)
        if err:
            raise RuntimeError(err)
        zeilen, fehlen = cftc_parse(d)
        if not zeilen:
            raise RuntimeError("keine Zeilen" + (f"; Felder fehlen: {', '.join(fehlen)}" if fehlen else ""))
        neu = archivieren(self.con, zeilen, int(self.jetzt()))
        juengst = max(t for _, t, _ in zeilen)
        info = f"Bericht vom {ts_datum(juengst).strftime('%d.%m.%Y')}" + (f"; Felder fehlen: {', '.join(fehlen)}" if fehlen else "")
        return neu, info

    # ---------------------------------------------------------------- FINRA Reg SHO
    def _finra(self) -> tuple:
        jetzt = self.jetzt()
        try:
            erledigt = set(json.loads(meta(self.con, "finra_tage", "[]") or "[]"))
        except ValueError:
            erledigt = set()
        n = ny_jetzt(jetzt)
        bis = n.date() if (n.hour, n.minute) >= (18, 45) else n.date() - timedelta(days=1)
        tage, d = [], bis
        start = datetime.strptime(FINRA_AB, "%Y-%m-%d").date()
        while d >= start:
            if handelstag(d) and d.strftime("%Y%m%d") not in erledigt:
                tage.append(d)
            d -= timedelta(days=1)
        neu = 0; fehler = []; geholt = 0; fehlend = 0
        for d in tage[:FINRA_JE_LAUF]:
            s = d.strftime("%Y%m%d")
            text, err, st = self.http(FINRA_URL.format(tag=s), art="text", timeout=60)
            if st == 404:
                if (n.date() - d).days > 5:                              # nach 5 Tagen ohne Datei: als fehlend vermerken, nicht ewig fragen
                    erledigt.add(s); fehlend += 1
                continue
            if err:
                fehler.append(f"{s}: {err}"[:80]); continue
            try:
                z = finra_parse(text)
            except ValueError as e:
                fehler.append(f"{s}: {e}"); continue
            neu += archivieren(self.con, z, int(jetzt)); erledigt.add(s); geholt += 1
            self._pause(0.5)
        rest = max(0, len(tage) - FINRA_JE_LAUF)
        meta_setzen(self.con, {"finra_tage": json.dumps(sorted(erledigt)), "rueckstand:finra": rest})
        if tage and not geholt and not fehlend and fehler:
            raise RuntimeError("; ".join(fehler)[:240])
        return neu, (f"{geholt} Tage geladen, {rest} im Rückstand" + (f", {fehlend} Tage ohne Datei bei FINRA" if fehlend else "")
                     + (f"; {'; '.join(fehler)}" if fehler else ""))[:200]

    # ---------------------------------------------------------------- Farside
    def _farside(self) -> tuple:
        html, err, _ = self.http(FARSIDE_BTC, art="text", timeout=45)
        if err:
            raise RuntimeError(err)
        z = farside_fonds_parse(html, "btc")
        if not z:
            raise RuntimeError("keine Zeilen")
        jetzt = int(self.jetzt())
        neu = archivieren(self.con, z, jetzt)
        juengst = max(t for _, t, _ in z)
        # 23.68 (U165): ist der jüngste Tag vollständig? Je Abruf gemerkt -- daraus die Zählung im Bericht; seit 23.92 (U240) je Abrufzeit
        # (01:00 und 13:00 UTC); danach entscheidet der Nutzer, ob eine Abrufzeit verlegt oder ergänzt wird
        je, tot = farside_fonds(self.con)
        V = etf_vollstaendigkeit(je, [t for t, *_ in tot])
        j0 = tot[0][0] if tot else juengst
        try:
            log = json.loads(meta(self.con, "farside_vollstaendig") or "[]")
        except ValueError:
            log = []
        log = (log + [{"ts": jetzt, "tag": j0, "fehlt": V["unvollstaendig"].get(j0, [])}])[-FARSIDE_LOG_N:]
        meta_setzen(self.con, {"farside_vollstaendig": json.dumps(log)})
        fehlt = V["unvollstaendig"].get(j0)
        return neu, f"jüngster Tag {ts_datum(juengst).strftime('%d.%m.%Y')}" + (f", unvollständig (fehlt: {', '.join(fehlt)})" if fehlt else "")

    # ---------------------------------------------------------------- Cboe (optional)
    def _cboe(self) -> tuple:
        neu = 0; fehler = []
        for name, urls in CBOE_URLS.items():
            text = None; err = "kein Versuch"
            for u in urls:
                text, err, _ = self.http(u, art="text", timeout=40)
                if not err and text and not ist_html(text):
                    break
                err = err or "HTML statt CSV"
            if err:
                fehler.append(f"{name}: {err}"[:80]); continue
            try:
                neu += archivieren(self.con, cboe_parse(name, text), int(self.jetzt()))
            except ValueError as e:
                fehler.append(f"{name}: {e}")
            self._pause(PAUSE_S)
        if len(fehler) == len(CBOE_URLS):
            raise RuntimeError("; ".join(fehler))
        return neu, "; ".join(fehler)

    # ---------------------------------------------------------------- SEC EDGAR (Strategy)
    def _sec(self) -> tuple:
        ua = {"User-Agent": sec_user_agent(), "Accept": "application/json, text/html"}
        d, err, st = self.http(SEC_SUBMISSIONS, kopf=ua, timeout=30)
        if err:
            raise RuntimeError(f"{err} (User-Agent „{ua['User-Agent']}“)")
        liste = sec_8k_liste(d)
        bekannt = set()
        for (inh,) in self.con.execute("SELECT inhalt FROM ak_text WHERE reihe='sec:8k'"):
            try:
                bekannt.add(json.loads(inh).get("acc"))
            except ValueError:
                pass
        offen = [e for e in reversed(liste) if e["acc"] not in bekannt]
        neu = 0; fehler = []; jetzt = int(self.jetzt()); unpl = []
        tb, wb = reihe(self.con, "sec:mstr_btc"); P = [(int(t_), float(w_)) for t_, w_ in zip(tb, wb)]
        for e in sorted(offen[:SEC_8K_JE_LAUF], key=lambda x: (x["datum"], x["acc"])):     # die jüngsten, zeitlich (Plausibilität, U177)
            html, err, _ = self.http(sec_dok_url(e["acc"], e["doc"]), art="text", kopf=ua, timeout=40)
            if err:
                fehler.append(f"{e['acc']}: {err}"[:80]); continue
            btc = sec_bestand_parse(html)
            t = tag_ts(e["datum"])
            rec = {"acc": e["acc"], "datum": e["datum"], "doc": e["doc"], "btc": btc}
            grund = mstr_pruefen(P, t, btc) if btc else None                 # 23.69 (U177): Plausibilität, unplausibel nicht archiviert
            if grund:
                rec.update(btc=None, btc_roh=btc, unplausibel=grund); unpl.append(f"8-K {e['datum']}: {grund}"); btc = None
            text_archivieren(self.con, "sec:8k", t, rec, jetzt)
            if btc:
                neu += archivieren(self.con, [("sec:mstr_btc", t, btc)], jetzt)
                P = sorted([x for x in P if x[0] != t] + [(t, btc)])
            self._pause(0.5)
        n_nl, nl_info = self._sec_neulesen(ua, jetzt)
        neu += n_nl
        hinweis = "; ".join(x for x in (("unplausibel, nicht übernommen: " + "; ".join(unpl)) if unpl else "",
                                         ("neu gelesen: " + nl_info) if nl_info else "") if x)
        if jetzt - float(meta(self.con, "sec_aktien_ts", "0") or 0) > 7 * TAG:
            gefunden = None; nicht_da = []
            for tax, konzept, name, dauer in SEC_AKTIEN_KONZEPTE:
                d2, err2, st2 = self.http(sec_aktien_url(tax, konzept), kopf=ua, timeout=30)
                if err2:
                    if st2 == 404:                                   # Abgrenzung nicht gemeldet: kein Fehler, nächste versuchen
                        nicht_da.append(name); self._pause(0.3); continue
                    fehler.append(f"Aktienzahl ({name}): {err2}"[:80]); break
                try:
                    werte = sec_aktien_parse(d2, dauer=dauer)
                except ValueError as e:
                    fehler.append(f"Aktienzahl ({name}): {e}"[:80]); break
                if werte:
                    gefunden = (tax, konzept, name, werte); break
                nicht_da.append(name)
            if gefunden:
                tax, konzept, name, werte = gefunden
                neu += archivieren(self.con, [("sec:mstr_aktien", t, v) for t, v in werte], jetzt)
                meta_setzen(self.con, {"sec_aktien_ts": jetzt, "sec_aktien_quelle": f"{tax}:{konzept}", "sec_aktien_name": name})
                hinweis = "; ".join(x for x in (hinweis, f"Aktienzahl: {name}") if x)
            elif not fehler:                                         # nirgends gemeldet: in 7 Tagen wieder versuchen, kein Fehler;
                meta_setzen(self.con, {"sec_aktien_ts": jetzt})        # die Abgrenzung der schon gespeicherten Werte bleibt
                hinweis = "; ".join(x for x in (hinweis, "Aktienzahl in keiner Abgrenzung ohne Klassen gemeldet (" + ", ".join(nicht_da) + ")") if x)
        rest = max(0, len(offen) - SEC_8K_JE_LAUF)
        return neu, (f"{min(len(offen), SEC_8K_JE_LAUF)} 8-K gelesen, {rest} offen" + (f"; {hinweis}" if hinweis else "")
                     + (f"; {'; '.join(fehler)}" if fehler else ""))[:400]

    def _sec_neulesen(self, ua: dict, jetzt: int) -> tuple:
        """23.69 (U177): Bestände im Archiv, die nicht zu ihren Nachbarn passen (bis 23.68 aus Tabellen falsch gelesen), je 8-K EINMAL neu
        lesen (Vermerk „neu_gelesen“ im Textarchiv); plausibel -> neue Fassung im Archiv, sonst bleibt der Wert und zählt nicht
        (mstr_bestand). Höchstens SEC_NEULESEN_JE_LAUF 8-K je Lauf; ein Abruffehler zählt nicht als gelesen. -> (neue Fassungen, Text)"""
        tb, wb = reihe(self.con, "sec:mstr_btc"); P = [(int(t), float(w)) for t, w in zip(tb, wb)]
        schlecht = {t for (t, _w), g in zip(P, mstr_plausibel(P)) if not g}
        if not schlecht:
            return 0, ""
        rec = {}
        for ts_, inh in self.con.execute("SELECT ts, inhalt FROM ak_text WHERE reihe='sec:8k' ORDER BY abgerufen"):
            try:
                d = json.loads(inh)
            except ValueError:
                continue
            if isinstance(d, dict) and d.get("acc"):
                rec[(int(ts_), d["acc"])] = d                             # jüngster Eintrag je 8-K
        kand = sorted(((t, d) for (t, _a), d in rec.items() if t in schlecht and d.get("btc") and d.get("doc") and not d.get("neu_gelesen")),
                      key=lambda x: (x[0], x[1]["acc"]))
        n = 0; info = []
        for t, d in kand[:SEC_NEULESEN_JE_LAUF]:
            html, err, _ = self.http(sec_dok_url(d["acc"], d["doc"]), art="text", kopf=ua, timeout=40)
            if err:
                info.append(f"{d.get('datum')}: {err}"[:60]); continue
            w = sec_bestand_parse(html)
            P_ohne = [x for x in P if x[0] != t]
            grund = (mstr_pruefen(P_ohne, t, w) if w else "kein Bestand im 8-K")
            neu_d = dict(d, neu_gelesen=jetzt, btc_alt=d.get("btc"), btc=None if grund else w)
            if grund:
                neu_d["unplausibel"] = grund
            text_archivieren(self.con, "sec:8k", t, neu_d, jetzt)
            if not grund:
                n += archivieren(self.con, [("sec:mstr_btc", t, w)], jetzt)
                P = sorted(P_ohne + [(t, w)])
                info.append(f"{d.get('datum')} {d.get('btc'):,.0f} → {w:,.0f}".replace(",", "."))
            else:
                info.append(f"{d.get('datum')} {grund}")
            self._pause(0.5)
        return n, "; ".join(info)


# ================================================================================================ Takt (Dashboard-Prozess)

_TAKT = {"gestartet": False, "laeuft": None, "letzter": None, "fehler": None}
_LAUF = threading.Lock()


def abrufen(db: str, quellen=QUELLEN, nur_faellige: bool = True, log=None, http_fn=None, jetzt_fn=None) -> list:
    """Fällige (bzw. alle genannten) Quellen nacheinander abrufen; höchstens ein Lauf zur Zeit (Sperre im Prozess)."""
    import hl_makro as MK
    erg = []
    with _LAUF:
        A = Abruf(aktien_pfad(db), MK.makro_pfad(db), http_fn=http_fn, jetzt_fn=jetzt_fn, log=log)
        try:
            for q in quellen:
                if nur_faellige and not faellig(A.con, q, A.jetzt()):
                    continue
                _TAKT["laeuft"] = q
                erg.append(A.lauf(q))
        finally:
            _TAKT["laeuft"] = None
            A.close()
    return erg


def xyz_auffrischen(db: str, max_alter: int = 1800) -> bool:
    """
    Für den Ausblick (13.1): den xyz-Stand im Hintergrund holen, wenn er älter als max_alter ist. Kehrt sofort zurück -- die
    Anfrage des Dashboards wartet nie auf einen Abruf; läuft gerade ein Lauf des Takts, geschieht nichts (er holt xyz ohnehin).
    """
    if os.environ.get("HL_AKTIEN") == "0":
        return False
    con = lesen(aktien_pfad(db))
    alt = None
    if con is not None:
        try:
            alt = meta(con, "xyz_ts")
        finally:
            con.close()
    if alt and time.time() - float(alt) < max_alter:
        return False
    if _LAUF.locked():
        return False
    threading.Thread(target=lambda: abrufen(db, ("xyz",), nur_faellige=False), daemon=True, name="aktien-xyz").start()
    return True


def starten(db: str) -> bool:
    """Takt im Dashboard-Prozess: jede Minute nachsehen, welche Quelle fällig ist. Nicht für Selbsttest-Datenbanken, aus mit HL_AKTIEN=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_AKTIEN") == "0":
        return False
    _TAKT["gestartet"] = True

    def schleife():
        time.sleep(75)
        while True:
            try:
                r = abrufen(db)
                if r:
                    _TAKT["letzter"] = {"ts": int(time.time()), "erg": r}
                _TAKT["fehler"] = None
            except Exception as e:
                _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Aktien-Takt: {_TAKT['fehler']}", flush=True)
            time.sleep(TAKT_S)
    threading.Thread(target=schleife, daemon=True, name="aktien").start()
    return True


def quellen_stand(db: str) -> list:
    """Je Quelle: zuletzt ok, letzter Fehler, Pause, Info -- für die Anzeige „Datenquellen“ des Reiters Aktienmarkt."""
    con = lesen(aktien_pfad(db))
    out = []
    for q in QUELLEN:
        e = {"quelle": q, "name": QUELLEN_NAME[q], "optional": q in OPTIONAL}
        if con is not None:
            for k in ("ok", "versuch", "pause_bis", "fehler_n"):
                v = meta(con, f"{k}:{q}")
                e[k] = float(v) if v not in (None, "") else None
            e["fehler"] = meta(con, f"fehler:{q}") if (e.get("fehler_n") or 0) > 0 else None
            e["info"] = meta(con, f"info:{q}")
        out.append(e)
    if con is not None:
        con.close()
    return out


# ================================================================================================ Statistik-Bausteine

def phi(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def phi2(h: float, k: float, rho: float, n: int = 4000) -> float:
    """Standardisierte bivariate Normalverteilung P(X ≤ h, Y ≤ k; ρ) per Integration über Y (Trapez auf [−9, k])."""
    if abs(rho) >= 1:
        return phi(min(h, k)) if rho > 0 else max(0.0, phi(h) + phi(k) - 1)
    k = min(k, 9.0)
    t = np.linspace(-9.0, k, n)
    f = np.exp(-0.5 * t * t) / math.sqrt(2 * math.pi) * 0.5 * np.vectorize(math.erfc)(-(h - rho * t) / math.sqrt(2 * (1 - rho * rho)))
    return float(np.trapz(f, t)) if hasattr(np, "trapz") else float(np.trapezoid(f, t))


def wilson(k: int, n: int, z: float = 1.959964) -> tuple:
    if n <= 0:
        return (float("nan"), float("nan"))
    p = k / n; d = 1 + z * z / n
    m = (p + z * z / (2 * n)) / d; w = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, m - w), min(1.0, m + w))


def holm(p: list) -> list:
    """Holm-Bonferroni: angepasste p-Werte in der Reihenfolge der Eingabe."""
    m = len(p); o = sorted(range(m), key=lambda i: p[i]); out = [1.0] * m; best = 0.0
    for r, i in enumerate(o):
        best = max(best, min(1.0, (m - r) * p[i]))
        out[i] = best
    return out


def ols_hac(y: np.ndarray, x: np.ndarray, lag: int) -> dict:
    """y = a + b·x, Newey-West-Standardfehler (Bartlett, lag). -> {b, se, t, p, n}."""
    ok = np.isfinite(y) & np.isfinite(x)
    y, x = y[ok], x[ok]; n = len(y)
    if n < 10:
        return {"n": n}
    X = np.column_stack([np.ones(n), x])
    XtX_inv = np.linalg.inv(X.T @ X)
    b = XtX_inv @ X.T @ y
    u = y - X @ b
    Xu = X * u[:, None]
    S = Xu.T @ Xu
    for L in range(1, min(lag, n - 1) + 1):
        w = 1 - L / (lag + 1)
        G = Xu[L:].T @ Xu[:-L]
        S += w * (G + G.T)
    V = XtX_inv @ S @ XtX_inv
    se = math.sqrt(max(V[1, 1], 0.0))
    t = b[1] / se if se > 0 else float("nan")
    return {"b": float(b[1]), "se": se, "t": float(t), "p": float(2 * (1 - phi(abs(t)))) if math.isfinite(t) else float("nan"), "n": n}


def stat_bootstrap_idx(n: int, mittel_block: float, reps: int, rng) -> np.ndarray:
    """Stationärer Bootstrap (Politis & Romano 1994): Indexmatrix (reps, n), Blocklänge geometrisch mit Mittel mittel_block."""
    p = 1.0 / max(mittel_block, 1.0)
    start = rng.integers(0, n, size=(reps, n))
    neu = rng.random((reps, n)) < p
    neu[:, 0] = True
    idx = np.empty((reps, n), dtype=np.int64)
    for r in range(reps):
        cur = start[r, 0]
        for t in range(n):
            if neu[r, t]:
                cur = start[r, t]
            else:
                cur = (cur + 1) % n
            idx[r, t] = cur
    return idx


def phasen_null_spearman(x: np.ndarray, y: np.ndarray, k: int = 2000, seed: int = 0) -> tuple:
    """
    Spearman ρ und Nullverteilung aus k Phasen-Surrogaten des Merkmals (Ebisuzaki 1997) -- dieselbe Rechnung wie
    hl_makro_korr.phasen_null (U130), aber ohne deren Mindestlänge von 3 Jahren (die Kurzstudie hat 2,5 Jahre).
    """
    import hl_makro_korr as MKK
    ok = np.isfinite(x) & np.isfinite(y)
    xs, ys = np.asarray(x, dtype=float)[ok], np.asarray(y, dtype=float)[ok]
    n = len(xs)
    if n < 30:
        return float("nan"), None, n
    rx = MKK.raenge(xs); ry = MKK.raenge(ys)
    zx = rx - rx.mean(); zy = ry - ry.mean()
    norm = math.sqrt(float(np.dot(zx, zx)) * float(np.dot(zy, zy)))
    if not norm > 0:
        return float("nan"), None, n
    rho = float(np.dot(zx, zy) / norm)
    a = np.abs(np.fft.rfft(zx)) * np.abs(np.fft.rfft(zy))
    gerade = n % 2 == 0
    mitte = a[1:-1] if gerade else a[1:]
    rng = np.random.default_rng(seed)
    out = np.empty(k)
    for s0 in range(0, k, 250):
        m = min(250, k - s0)
        v = 2.0 * (np.cos(rng.uniform(0.0, 2 * np.pi, (m, len(mitte)))) @ mitte)
        if gerade:
            v = v + a[-1] * rng.choice((-1.0, 1.0), m)
        out[s0:s0 + m] = v / n / norm
    return rho, out, n


def korrelation_ki(a: np.ndarray, b: np.ndarray, reps: int = 1000, block: float = 5.0, seed: int = 0) -> dict:
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]; n = len(a)
    if n < 20:
        return {"n": n}
    r = float(np.corrcoef(a, b)[0, 1])
    idx = stat_bootstrap_idx(n, block, reps, np.random.default_rng(seed))
    A, B = a[idx], b[idx]
    A = A - A.mean(axis=1, keepdims=True); B = B - B.mean(axis=1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        rr = (A * B).sum(axis=1) / np.sqrt((A * A).sum(axis=1) * (B * B).sum(axis=1))
    rr = rr[np.isfinite(rr)]
    return {"n": n, "r": r, "lo": float(np.quantile(rr, 0.05)), "hi": float(np.quantile(rr, 0.95))}


# ================================================================================================ Daten für die Studien

def kerzen_30m(db: str, coin: str) -> dict | None:
    """30-min-Kerzen eines Coins: swing.db (BTC, ETH, ZEC, XMR, HYPE ab 2020), regime.db (PAXG). Nur lesend."""
    import hl_regime as RG
    import hl_swing as SW
    pfad, tab = (SW.swing_pfad(db), "sw_klines") if coin in SW.COINS else (RG.regime_pfad(db), "rg_klines")
    if not os.path.exists(pfad):
        return None
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        rows = con.execute(f"SELECT ts, o, h, l, c FROM {tab} WHERE coin=? ORDER BY ts", (coin,)).fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        con.close()
    if not rows:
        return None
    a = np.array(rows, dtype=float)
    return {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4]}


def kurs_um(K: dict, zeiten: np.ndarray, max_frueher: int = 3600) -> np.ndarray:
    """Schlusskurs der 30-min-Kerze, die zum Zeitpunkt t endet (Eröffnung t − 30 min); fehlt sie, die jüngere davor, höchstens
    max_frueher Sekunden früher. Sonst NaN."""
    out = np.full(len(zeiten), np.nan)
    if K is None or not len(K["ts"]):
        return out
    ziel = np.asarray(zeiten, dtype=np.int64) - BAR
    j = np.searchsorted(K["ts"], ziel, side="right") - 1
    ok = (j >= 0)
    jj = np.clip(j, 0, None)
    ok &= K["ts"][jj] >= ziel - max_frueher
    out[ok] = K["c"][jj[ok]]
    return out


def btc_tagesschluss_00(db: str) -> tuple:
    """BTC-Tagesschluss 00:00 UTC ab 2016 (Coin Metrics PriceUSD aus makro.db): (Tag d, Kurs am Ende von d)."""
    import hl_makro as MK
    con = MK.lesen(MK.makro_pfad(db))
    if con is None:
        return np.zeros(0, dtype=np.int64), np.zeros(0)
    try:
        t, w = MK.Reihen(con)("cm:btc:PriceUSD")
    finally:
        con.close()
    return t, w


def sp500_reihe(db: str) -> tuple:
    con = lesen(aktien_pfad(db))
    if con is None:
        return [], np.zeros(0)
    try:
        t, w = reihe(con, "fred:SP500")
    finally:
        con.close()
    return [ts_datum(x) for x in t], w


# ================================================================================================ Studie U147 (13.12)

U147_TAG = (0.0, -0.01, -0.02, -0.03)
U147_WOCHE = (0.0, -0.03, -0.05)
U147_4W = (0.0, -0.05, -0.10)
U147_ZEITRAEUME = (("2020–2022", date(2020, 1, 1), date(2022, 12, 31)), ("2023–2026", date(2023, 1, 1), date(2099, 1, 1)),
                   ("seit 2020", date(2020, 1, 1), date(2099, 1, 1)))
U147_COINS = ("BTC", "ETH", "ZEC", "XMR", "HYPE")


def _wochen_letzte(datums: list) -> list:
    """Index des letzten Handelstags je Kalenderwoche (Freitag bzw. der letzte vor einem Feiertag)."""
    out = []
    for i, d in enumerate(datums):
        if i + 1 == len(datums) or datums[i + 1].isocalendar()[:2] != d.isocalendar()[:2]:
            out.append(i)
    return out


def _bedingung(rS: np.ndarray, rB: np.ndarray, schwelle: float, richtung: int, rho: float, sig_s: float) -> dict:
    """richtung −1: S&P < schwelle (bzw. < 0), Ereignis „BTC fiel“; +1: S&P > |schwelle|, Ereignis „BTC stieg“."""
    ok = np.isfinite(rS) & np.isfinite(rB)
    m = ok & ((rS < schwelle) if richtung < 0 else (rS > -schwelle))
    n = int(m.sum())
    if n == 0:
        return {"n": 0}
    k = int(((rB[m] < 0) if richtung < 0 else (rB[m] > 0)).sum())
    lo, hi = wilson(k, n)
    e = {"n": n, "k": k, "anteil": k / n, "lo": lo, "hi": hi, "mittel": float(np.mean(rB[m])), "median": float(np.median(rB[m]))}
    if n >= 5 and np.std(rS[m]) > 0:
        e["beta"] = float(np.polyfit(rS[m], rB[m], 1)[0])
    if math.isfinite(rho) and sig_s > 0:
        if schwelle == 0:
            e["normal"] = 0.5 + math.asin(max(-1.0, min(1.0, rho))) / math.pi
        else:
            a = schwelle / sig_s                                   # Symmetrie (Mittel 0): P(B>0 | S>x) = P(B<0 | S<−x)
            e["normal"] = phi2(0.0, a, rho) / max(phi(a), 1e-300)
    return e


def _tafel(rS, rB, schwellen) -> dict:
    ok = np.isfinite(rS) & np.isfinite(rB)
    if ok.sum() < 10:
        return {"n": int(ok.sum())}
    rho = float(np.corrcoef(rS[ok], rB[ok])[0, 1]); sig = float(np.std(rS[ok]))
    return {"n": int(ok.sum()), "rho": rho, "beta": float(np.polyfit(rS[ok], rB[ok], 1)[0]),
            "ab": [dict(_bedingung(rS, rB, s, -1, rho, sig), schwelle=s) for s in schwellen],
            "auf": [dict(_bedingung(rS, rB, s, 1, rho, sig), schwelle=-s) for s in schwellen]}


def u147_rechnen(datums: list, sp: np.ndarray, Bk: dict, btc00: tuple | None = None, heute: date | None = None) -> dict:
    """
    datums/sp: S&P-Handelstage und Schlüsse; Bk: {coin: Kurs zum S&P-Schluss (16:00 New York) je Handelstag}. btc00: (Tag, Kurs)
    Tagesschluss 00:00 UTC ab 2016 für Wochen und 4 Wochen. -> Tafeln je Coin, Zeitraum, Frequenz; Vorlauf-Tests; Urteil „immer“.
    """
    n = len(datums)
    out = {"coins": {}, "n_tage": n, "von": datums[0].isoformat() if n else None, "bis": datums[-1].isoformat() if n else None}
    if n < 30:
        out["fehlt"] = "zu wenige S&P-Tage"
        return out
    lsp = np.log(sp)
    wl = _wochen_letzte(datums)
    for coin, B in Bk.items():
        lb = np.log(B)
        C = {}
        for name, a, b in U147_ZEITRAEUME:
            im = np.array([a <= d <= b for d in datums])
            # Tag: aufeinanderfolgende Handelstage (BTC über dasselbe Intervall, Wochenende eingeschlossen)
            rS = np.full(n, np.nan); rB = np.full(n, np.nan)
            rS[1:] = lsp[1:] - lsp[:-1]; rB[1:] = lb[1:] - lb[:-1]
            m = im.copy(); m[0] = False
            T_tag = _tafel(rS[m], rB[m], U147_TAG)
            # Woche: Freitag bis Freitag (letzter Handelstag der Woche), nur aufeinanderfolgende Wochen
            w = np.array(wl)
            wS = lsp[w[1:]] - lsp[w[:-1]]; wB = lb[w[1:]] - lb[w[:-1]]
            folge = np.array([(datums[w[i + 1]] - datums[w[i]]).days <= 10 for i in range(len(w) - 1)])
            mw = folge & np.array([a <= datums[w[i + 1]] <= b for i in range(len(w) - 1)])
            T_wo = _tafel(wS[mw], wB[mw], U147_WOCHE)
            # 4 Wochen: 20 Handelstage, nicht überlappend, ab dem ersten Tag des Zeitraums
            ii = np.nonzero(im)[0]
            blk = ii[::20]
            vS = lsp[blk[1:]] - lsp[blk[:-1]]; vB = lb[blk[1:]] - lb[blk[:-1]]
            T_4w = _tafel(vS, vB, U147_4W)
            C[name] = {"tag": T_tag, "woche": T_wo, "4w": T_4w}
        out["coins"][coin] = C
    # Wochen und 4 Wochen ab 2016 mit dem BTC-Tagesschluss 00:00 UTC (Versatz 3–4 h)
    if btc00 is not None and len(btc00[0]):
        tage, pr = btc00
        idx = {int(t): float(v) for t, v in zip(tage, pr)}
        b00 = np.array([idx.get((datetime(d.year, d.month, d.day, tzinfo=UTC).timestamp() // TAG), np.nan) for d in datums])
        lb0 = np.log(b00)
        w = np.array(wl)
        folge = np.array([(datums[w[i + 1]] - datums[w[i]]).days <= 10 for i in range(len(w) - 1)])
        wS = (lsp[w[1:]] - lsp[w[:-1]])[folge]; wB = (lb0[w[1:]] - lb0[w[:-1]])[folge]
        blk = np.arange(0, n, 20)
        out["ab2016"] = {"woche": _tafel(wS, wB, U147_WOCHE), "4w": _tafel(lsp[blk[1:]] - lsp[blk[:-1]], lb0[blk[1:]] - lb0[blk[:-1]], U147_4W),
                         "von": datums[0].isoformat()}
    # Urteil „immer“ (BTC, alle fallenden Bedingungen, alle Zeiträume): bestätigt nur bei 100 % überall
    B0 = out["coins"].get("BTC") or {}
    alle = []
    for name, T in B0.items():
        for frq in ("tag", "woche", "4w"):
            for e in (T.get(frq) or {}).get("ab") or []:
                if e.get("n"):
                    alle.append((name, frq, e["schwelle"], e["k"], e["n"], e["anteil"]))
    out["immer"] = {"bestaetigt": bool(alle) and all(a[5] == 1.0 for a in alle), "bedingungen": alle,
                    "naechste": sorted([a for a in alle if a[2] <= -0.02 or (a[1] != "tag" and a[2] <= -0.05)], key=lambda a: -a[5])[:6]}
    return out


def u147_vorlauf(datums: list, sp: np.ndarray, K: dict | None) -> dict:
    """Vier Vorlauf-Tests (13.12), Holm über 4, HAC: S&P-Tag -> BTC 24 h; BTC über Nacht -> S&P Folgetag; Wochen in beide Richtungen."""
    if K is None or len(datums) < 60:
        return {"fehlt": "zu wenige Daten"}
    t16 = np.array([ny_ts(d, 16, 0) for d in datums]); t0930 = np.array([ny_ts(d, 9, 30) for d in datums])
    b16 = kurs_um(K, t16); b16_24 = kurs_um(K, t16 + TAG); b0930 = kurs_um(K, t0930)
    lsp = np.log(sp)
    rS = np.full(len(datums), np.nan); rS[1:] = lsp[1:] - lsp[:-1]
    T = []
    y1 = np.log(b16_24 / b16)
    T.append(("S&P-Tag → BTC in den folgenden 24 h (ab 16:00 New York)", ols_hac(y1, rS, 5)))
    x2 = np.full(len(datums), np.nan); x2[1:] = np.log(b0930[1:] / b16[:-1])          # 16:00 am Vortag bis 9:30 am Handelstag
    T.append(("BTC außerhalb der Handelszeit (16:00 bis 9:30) → S&P an diesem Handelstag", ols_hac(rS, x2, 5)))
    wl = np.array(_wochen_letzte(datums))
    wS = lsp[wl[1:]] - lsp[wl[:-1]]; wB = np.log(b16[wl[1:]] / b16[wl[:-1]])
    T.append(("S&P-Woche → BTC-Folgewoche", ols_hac(wB[1:], wS[:-1], 4)))
    T.append(("BTC-Woche → S&P-Folgewoche", ols_hac(wS[1:], wB[:-1], 4)))
    ps = [t[1].get("p", 1.0) if math.isfinite(t[1].get("p", float("nan"))) else 1.0 for t in T]
    ph = holm(ps)
    return {"tests": [dict(e, name=nm, p_holm=h, belegt=bool(h < 0.05)) for (nm, e), h in zip(T, ph)],
            "hinweis": "Vorlauf gegenüber dem Kassamarkt: S&P-Futures handeln über Nacht mit -- ein Zusammenhang über Nacht ist "
                       "gemeinsame Information, kein Beleg, dass BTC den Aktienmarkt führt."}


def u147(db: str) -> dict:
    datums, sp = sp500_reihe(db)
    if len(datums) < 30:
        return {"fehlt": "S&P 500 (FRED) noch nicht im Archiv -- der Aktien-Takt lädt ihn nach dem Einspielen"}
    t16 = np.array([ny_ts(d, 16, 0) for d in datums])
    Bk, Kb = {}, None
    for coin in U147_COINS:
        K = kerzen_30m(db, coin)
        if K is None:
            continue
        if coin == "BTC":
            Kb = K
        Bk[coin] = kurs_um(K, t16)
    if not Bk:
        return {"fehlt": "keine 30-min-Kerzen (swing.db)"}
    erg = u147_rechnen(datums, sp, Bk, btc00_or_none(db))
    erg["vorlauf"] = u147_vorlauf([d for d in datums if d >= date(2020, 1, 1)], sp[np.array([d >= date(2020, 1, 1) for d in datums])], Kb)
    return erg


def btc00_or_none(db: str):
    t, w = btc_tagesschluss_00(db)
    return (t, w) if len(t) else None


# ================================================================================================ Kurzstudie K1/K2 (13.13)

K12_AB = date(2024, 4, 1)


def k12_rechnen(datums: list, flow_usd: np.ndarray, b16: np.ndarray, b16_7: np.ndarray, sig: np.ndarray, short: np.ndarray,
                total: np.ndarray, k: int = 2000) -> dict:
    """
    Je US-Handelstag d (ab 01.04.2024): K1 = Nettofluss der Spot-ETF über 20 Handelstage in BTC ÷ ETF-Bestand (Bestand = GBTC bei der
    Umwandlung + aufsummierte Flüsse in BTC), K2 = IBIT-Leerverkaufsquote über 5 Handelstage. Ziel: ln(B(d+7 T)/B(d)) ÷ (σ̂ √7).
    Spearman, Phasen-Randomisierung (13.6), Holm über 2; „belegt“ nur bei p Holm < 0,05 und gleichem Vorzeichen in beiden Hälften.
    """
    import hl_makro_korr as MKK
    n = len(datums)
    with np.errstate(invalid="ignore", divide="ignore"):
        f_btc = flow_usd * 1e6 / b16
    f0 = np.where(np.isfinite(f_btc), f_btc, 0.0)
    bestand = GBTC_START_BTC + np.cumsum(f0)
    k1 = np.full(n, np.nan); k2 = np.full(n, np.nan)
    for i in range(n):
        if i >= 19 and np.isfinite(f_btc[i - 19:i + 1]).sum() >= 18:
            k1[i] = np.nansum(f_btc[i - 19:i + 1]) / bestand[i]
        if i >= 4 and np.isfinite(short[i - 4:i + 1]).all() and np.isfinite(total[i - 4:i + 1]).all() and total[i - 4:i + 1].sum() > 0:
            k2[i] = short[i - 4:i + 1].sum() / total[i - 4:i + 1].sum()
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.log(b16_7 / b16) / (sig * math.sqrt(7))
    im = np.array([d >= K12_AB for d in datums])
    out = {"tests": []}
    ps = []
    for key, name, x in (("K1", "ETF-Nettofluss 20 Handelstage ÷ Bestand", k1), ("K2", "IBIT-Leerverkaufsquote 5 Handelstage", k2)):
        m = im & np.isfinite(x) & np.isfinite(y)
        e = {"key": key, "name": name, "n": int(m.sum())}
        if m.sum() < 60:
            e["grund"] = "zu wenige Tage"; out["tests"].append(e); ps.append(1.0); continue
        ii = np.nonzero(m)[0]
        rho, null, nn = phasen_null_spearman(x[ii], y[ii], k=k, seed=11 if key == "K1" else 12)
        p = MKK.p_zweiseitig(rho, null) if null is not None else 1.0
        mitte = ii[len(ii) // 2]
        h1 = ii[ii < mitte]; h2 = ii[ii >= mitte]
        r1 = MKK.spearman(x[h1], y[h1]) if len(h1) > 20 else float("nan")
        r2 = MKK.spearman(x[h2], y[h2]) if len(h2) > 20 else float("nan")
        e.update(rho=rho, p=p, h1=r1, h2=r2, von=datums[ii[0]].isoformat(), bis=datums[ii[-1]].isoformat(), mitte=datums[mitte].isoformat())
        out["tests"].append(e); ps.append(p)
    for e, h in zip(out["tests"], holm(ps)):
        e["p_holm"] = h
        e["belegt"] = bool(h < 0.05 and e.get("h1") is not None and math.isfinite(e.get("h1", float("nan")))
                           and np.sign(e["h1"]) == np.sign(e["h2"]) == np.sign(e.get("rho", 0)))
    return out


def k12(db: str) -> dict:
    datums, _sp = sp500_reihe(db)
    con = lesen(aktien_pfad(db))
    if con is None or not datums:
        return {"fehlt": "aktien.db oder S&P-Tage fehlen"}
    try:
        f = dict(zip(*[x.tolist() for x in reihe(con, "farside:btc:Total")]))
        sh = dict(zip(*[x.tolist() for x in reihe(con, "finra:IBIT:short")]))
        to = dict(zip(*[x.tolist() for x in reihe(con, "finra:IBIT:total")]))
    finally:
        con.close()
    if not f:
        return {"fehlt": "keine ETF-Flüsse (Farside) im Archiv"}
    datums = [d for d in datums if d >= date(2024, 1, 11)]
    K = kerzen_30m(db, "BTC")
    t16 = np.array([ny_ts(d, 16, 0) for d in datums])
    b16 = kurs_um(K, t16); b16_7 = kurs_um(K, t16 + 7 * TAG)
    tk = [int(datetime(d.year, d.month, d.day, tzinfo=UTC).timestamp()) for d in datums]
    flow = np.array([f.get(t, np.nan) for t in tk], dtype=float)
    short = np.array([sh.get(t, np.nan) for t in tk], dtype=float); total = np.array([to.get(t, np.nan) for t in tk], dtype=float)
    t00, p00 = btc_tagesschluss_00(db)
    sig = np.full(len(datums), np.nan)
    if len(t00) > 60:
        import hl_zyklus as ZY
        r = np.full(len(p00), np.nan); r[1:] = np.log(p00[1:] / p00[:-1])
        s = ZY.sigma_batch(r[None, :])[0]
        pos = {int(t): i for i, t in enumerate(t00)}
        for i, t in enumerate(tk):
            j = pos.get(t // TAG - 1)                                   # σ bis zum Vortag (bei d bekannt)
            if j is not None:
                sig[i] = s[j]
    return dict(k12_rechnen(datums, flow, b16, b16_7, sig, short, total), n_tage=len(datums))


# ================================================================================================ Reiter „Aktienmarkt“ (13.7, beschreibend)

_MEMO: dict = {"lock": threading.Lock(), "items": {}}


def _memo(key, fn, ttl: float):
    with _MEMO["lock"]:
        hit = _MEMO["items"].get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    v = fn()
    with _MEMO["lock"]:
        _MEMO["items"][key] = (time.time(), v)
    return v


def _letzt(t: np.ndarray, w: np.ndarray) -> tuple:
    ok = np.isfinite(w)
    if not ok.any():
        return None, None
    i = int(np.nonzero(ok)[0][-1])
    return int(t[i]), float(w[i])


def _perz(w: np.ndarray, v: float) -> float | None:
    x = w[np.isfinite(w)]
    if len(x) < 100 or v is None:
        return None
    return float((np.sum(x < v) + 0.5 * np.sum(x == v)) / len(x))


def gleichlauf(datums: list, sp: np.ndarray, B: np.ndarray) -> dict:
    """Korrelation der Tagesrenditen (S&P-Schluss gegen Kurs zum S&P-Schluss) über 60/120/260 Handelstage mit 90-%-Intervall
    (stationärer Blockbootstrap, Blocklänge 5); Beta nach unten und nach oben über 260 Tage."""
    lsp = np.log(sp); lb = np.log(B)
    rS = lsp[1:] - lsp[:-1]; rB = lb[1:] - lb[:-1]
    out = {}
    for n in (60, 120, 260):
        out[str(n)] = korrelation_ki(rS[-n:], rB[-n:], reps=1000, seed=n)
    a, b = rS[-260:], rB[-260:]
    ok = np.isfinite(a) & np.isfinite(b)
    for k, m in (("beta_ab", ok & (a < 0)), ("beta_auf", ok & (a > 0))):
        out[k] = float(np.polyfit(a[m], b[m], 1)[0]) if m.sum() >= 20 else None
    for k, m in (("tafel_260", slice(-260, None)), ("tafel_2020", np.array([d >= date(2020, 1, 1) for d in datums[1:]]))):
        x, y = rS[m], rB[m]
        okk = np.isfinite(x) & np.isfinite(y)
        z = {}
        for s_ in (0.0, -0.01):
            mm = okk & (x < s_)
            z[str(s_)] = {"n": int(mm.sum()), "k": int((y[mm] < 0).sum())}
        out[k] = z
    return out


def nutzlast(db: str) -> dict:
    """Reiter „Aktienmarkt“: Barometer (xyz), Gleichlauf, Tafel U147, Stress, Krypto-Aktien, Struktur, Quellen. Beschreibend."""
    return _memo(("aktien", db), lambda: _nutzlast(db), 600)


def _nutzlast(db: str) -> dict:
    t0 = time.time()
    out = {"ok": True, "version": VERSION_MODUL, "erzeugt": int(time.time()), "kennzeichnung": "beschreibend, nicht geprüft",
           "fehlt": [], "quellen": quellen_stand(db), "boerse_offen": boerse_offen()}
    con = lesen(aktien_pfad(db))
    if con is None:
        out["fehlt"].append("aktien.db fehlt noch -- der Aktien-Takt legt sie nach dem Einspielen an")
        return out
    try:
        st = json.loads(meta(con, "xyz_stand", "{}") or "{}"); xts = meta(con, "xyz_ts")
        out["barometer"] = {"ts": int(float(xts)) if xts else None, "werte": {}, "eingestellt": []}
        for k in XYZ_INDIZES + XYZ_KRYPTO + XYZ_ANLEIHEN + XYZ_TOP10:
            e = st.get(k)
            if e and e.get("delisted"):                       # 23.67: eingestellter Markt -- sein letzter Kurs ist eingefroren
                out["barometer"]["eingestellt"].append(k)
                continue
            if e and e.get("mark") is not None:
                out["barometer"]["werte"][k] = {"mark": e["mark"], "vortag": e.get("vortag"),
                                                "aend": (e["mark"] / e["vortag"] - 1) if e.get("vortag") else None}
        # Stress
        S = {}
        for name, r in (("vix", "fred:VIXCLS"), ("vix3m", "fred:VXVCLS"), ("vvix", "cboe:VVIX"), ("vix9d", "cboe:VIX9D"),
                        ("hy", "fred:BAMLH0A0HYM2"), ("baa10y", "fred:BAA10Y"), ("stlfsi", "fred:STLFSI4"), ("nfci", "fred:NFCI"),
                        ("sp", "fred:SP500"), ("ndx", "fred:NASDAQ100")):
            t, w = reihe(con, r)
            lt, lw = _letzt(t, w)
            S[name] = {"ts": lt, "wert": lw, "pz": _perz(w, lw), "seit": int(t[0]) if len(t) else None, "n": int(len(t))}
            if name in ("sp", "ndx") and len(w) >= 252 and lw:
                S[name]["abstand_hoch"] = lw / float(np.nanmax(w[-252:])) - 1
        if S["vix"]["wert"] and S["vix3m"]["wert"] and S["vix"]["ts"] == S["vix3m"]["ts"]:
            S["vix_vix3m"] = S["vix"]["wert"] / S["vix3m"]["wert"]
        out["stress"] = S
        # Krypto-Aktien: ETF-Flüsse (Farside, mit Abrufzeit und Zahl der Fassungen), CFTC, IBIT-Leerverkäufe, Strategy
        # 23.68 (U165): die letzten 3 Handelstage auf fehlende Fonds geprüft; Summen nur über vollständige Tage
        je_f, tot = farside_fonds(con)
        V = etf_vollstaendigkeit(je_f, [t for t, *_ in tot])
        rows = tot[:20]
        try:
            log = json.loads(meta(con, "farside_vollstaendig") or "[]")
        except ValueError:
            log = []
        out["etf"] = dict({"tage": [{"ts": r[0], "mio_usd": r[1], "abgerufen": r[2], "fassungen": r[3], "fehlt": V["unvollstaendig"].get(r[0], [])}
                                    for r in rows],
                           "eingestellt": V["eingestellt"], "geprueft": V["geprueft"],
                           "zaehlung": farside_zaehlung(log)},                    # 23.92 (U240): auch je Abrufzeit
                          **etf_summen([(r[0], r[1]) for r in rows], V["unvollstaendig"]))
        cf = {}
        for code, name in CFTC_KONTRAKTE.items():
            e = {"name": name}
            for f in CFTC_FELDER:
                t, w = reihe(con, f"cftc:{code}:{f}")
                if len(t):
                    e[f] = float(w[-1]); e["ts"] = int(t[-1])
                    if len(w) >= 2:
                        e[f + "_vor"] = float(w[-2])
            if "lev_long" in e and "lev_short" in e:
                e["lev_netto"] = e["lev_long"] - e["lev_short"]
            if "am_long" in e and "am_short" in e:
                e["am_netto"] = e["am_long"] - e["am_short"]
            cf[code] = e
        out["cftc"] = cf
        fi = {}
        for sym in FINRA_SYMBOLE:
            ts_, sh = reihe(con, f"finra:{sym}:short"); _t2, to = reihe(con, f"finra:{sym}:total")
            if len(sh) >= 5 and len(to) >= 5 and len(ts_) == len(_t2):
                fi[sym] = {"ts": int(ts_[-1]), "quote5": float(sh[-5:].sum() / to[-5:].sum()) if to[-5:].sum() > 0 else None,
                           "quote1": float(sh[-1] / to[-1]) if to[-1] > 0 else None}
        out["finra"] = fi
        MB = mstr_bestand(con); tb, wb = MB["ts"], MB["w"]; ta, wa = reihe(con, "sec:mstr_aktien")       # 23.69 (U177): ohne unplausible
        ms = {"btc": float(wb[-1]) if len(wb) else None, "btc_ts": int(tb[-1]) if len(tb) else None,
              "netto_woche": float(wb[-1] - wb[-2]) if len(wb) >= 2 else None, "aktien": float(wa[-1]) if len(wa) else None,
              "unplausibel": [[int(t), float(w)] for t, w in MB["unplausibel"]], "unplausibel_8k": mstr_unplausibel_8k(con),
              "aktien_ts": int(ta[-1]) if len(ta) else None, "aktien_name": meta(con, "sec_aktien_name") or None,
              "mstr": (st.get("MSTR") or {}).get("mark") if not (st.get("MSTR") or {}).get("delisted") else None,
              "strc": (st.get("STRC") or {}).get("mark") if not (st.get("STRC") or {}).get("delisted") else None}
        ms["strc_nennwert"] = (ms["strc"] / 100.0 - 1) if ms["strc"] else None
        out["strategy"] = ms
        # Struktur: Top 10 über xyz-Tageskerzen (Abstand zum Hoch seit der Listung, gleich gewichtet)
        tops = []
        for k in XYZ_TOP10:
            if (st.get(k) or {}).get("delisted"):
                continue
            K = kerzen(con, f"xyz:{k}:1d")
            mark = (st.get(k) or {}).get("mark")
            if K is None or not len(K["c"]):
                continue
            hoch = float(np.max(K["h"])); px = mark or float(K["c"][-1])
            tops.append({"k": k, "px": px, "hoch": hoch, "abstand": px / hoch - 1, "seit": int(K["ts"][0])})
        out["struktur"] = {"top10": tops, "mittel_abstand": float(np.mean([t["abstand"] for t in tops])) if tops else None}
    finally:
        con.close()
    # Gleichlauf und Tafel U147 je Coin (Kurs zum S&P-Schluss)
    datums, sp = sp500_reihe(db)
    gl = {}
    if len(datums) >= 270:
        t16 = np.array([ny_ts(d, 16, 0) for d in datums])
        for coin in U147_COINS:
            K = kerzen_30m(db, coin)
            if K is None:
                continue
            B = kurs_um(K, t16)
            if np.isfinite(B[-260:]).sum() < 200:
                continue
            gl[coin] = gleichlauf(datums, sp, B)
        if "BTC" in gl and sp is not None:
            dd = [i for i, d in enumerate(datums) if d >= date(2020, 1, 1)]
            out["sp_tage"] = len(dd)
    else:
        out["fehlt"].append("S&P 500 (FRED) mit weniger als 270 Handelstagen im Archiv -- Gleichlauf folgt")
    out["gleichlauf"] = gl
    out["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return out


# ================================================================================================ Text (Debug, Berichte)

def _g(x) -> str:
    """Ganze Zahl mit Tausenderpunkt (23.67, Abschnitt Krypto-Aktien im Text)."""
    return "—" if x is None or not math.isfinite(x) else f"{x:,.0f}".replace(",", ".")


def _p(x, d=1) -> str:
    return "—" if x is None or not math.isfinite(x) else f"{x * 100:+.{d}f} %".replace(".", ",")


def _z(x, d=2) -> str:
    return "—" if x is None or not math.isfinite(x) else f"{x:.{d}f}".replace(".", ",")


def _dt(ts) -> str:
    return "—" if not ts else datetime.fromtimestamp(int(ts), UTC).strftime("%d.%m.%Y")


def text(db: str) -> str:
    Z = []; a = Z.append
    a(f"★ Aktienmarkt (U148) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')} · beschreibend, nicht geprüft")
    a(f"Archiv: {aktien_pfad(db)}")
    a("")
    a("QUELLEN (zuletzt ok · Fehler · Pause)")
    for q in quellen_stand(db):
        # 23.67: Datum und Uhrzeit beide in Ortszeit (bis 23.66 Datum in UTC und Uhrzeit in Ortszeit -- „11.10. 00:15“ war der 12.10.)
        ok = time.strftime("%d.%m.%Y %H:%M", time.localtime(q["ok"])) if q.get("ok") else "—"
        pa = q.get("pause_bis") or 0
        a(f"  {q['name']:<34} ok {ok:<17} · Fehler in Folge {int(q.get('fehler_n') or 0)}"
          + (f" · Pause bis {time.strftime('%d.%m. %H:%M', time.localtime(pa))}" if pa and pa > time.time() else "")
          + (f" · {q['fehler']}" if q.get("fehler") else "") + (f" · {q['info']}" if q.get("info") else ""))
    con = lesen(aktien_pfad(db))
    if con is not None:
        try:
            a("")
            a("ARCHIV (Reihen, Tage, Fassungen)")
            for r, n, mn, mx, fa in con.execute("SELECT reihe, COUNT(*), MIN(ts), MAX(ts), SUM(fassungen) FROM ak_aktuell GROUP BY reihe ORDER BY reihe"):
                if r.startswith("xyz:") and not r.endswith(":mark"):
                    continue
                a(f"  {r:<28} {n:>6} Werte {_dt(mn)}–{_dt(mx)} · {fa - n} Revisionen")
            for r, n, mn, mx in con.execute("SELECT reihe, COUNT(*), MIN(ts), MAX(ts) FROM ak_kerze GROUP BY reihe ORDER BY reihe"):
                a(f"  {r:<28} {n:>6} Kerzen {_dt(mn)}–{_dt(mx)}")
        finally:
            con.close()
    N = nutzlast(db)
    a("")
    a("BAROMETER (Hyperliquid xyz, rund um die Uhr" + ("" if N.get("boerse_offen") else "; Börse geschlossen -- Perp-Stand") + ")")
    for k, e in ((N.get("barometer") or {}).get("werte") or {}).items():
        a(f"  {k:<8} {_z(e['mark'], 2):>12}  {_p(e.get('aend'))} gegen Vortag")
    if (N.get("barometer") or {}).get("eingestellt"):
        a(f"  eingestellt auf xyz (nicht gezeigt, letzter Kurs eingefroren): {', '.join(N['barometer']['eingestellt'])}")
    S = N.get("stress") or {}
    if S:
        a("")
        a("STRESS (Wert, Stand, Perzentil in der eigenen Historie)")
        for k, nm in (("vix", "VIX"), ("vix3m", "VIX3M"), ("vvix", "VVIX"), ("hy", "Hochzinsaufschlag %"), ("baa10y", "Baa − 10 J %"),
                      ("stlfsi", "STLFSI4"), ("nfci", "NFCI"), ("sp", "S&P 500"), ("ndx", "Nasdaq-100")):
            e = S.get(k) or {}
            a(f"  {nm:<22} {_z(e.get('wert')):>10}  {_dt(e.get('ts'))}  Perzentil {_z((e.get('pz') or float('nan')) * 100, 0)}"
              + (f"  Abstand zum 252-T-Hoch {_p(e.get('abstand_hoch'))}" if e.get("abstand_hoch") is not None else ""))
        if S.get("vix_vix3m"):
            a(f"  VIX ÷ VIX3M            {_z(S['vix_vix3m'], 3):>10}")
    G = N.get("gleichlauf") or {}
    if G:
        a("")
        a("GLEICHLAUF mit dem S&P 500 (Tagesrenditen, Kurs zum S&P-Schluss 16:00 New York; 90-%-Intervall Blockbootstrap)")
        for c, g in G.items():
            k = "  ".join(f"{n} T {_z(g[n].get('r'))} ({_z(g[n].get('lo'))}…{_z(g[n].get('hi'))})" for n in ("60", "120", "260") if g.get(n, {}).get("r") is not None)
            t = g.get("tafel_260", {})
            a(f"  {c:<5} {k}  Beta ab {_z(g.get('beta_ab'))} / auf {_z(g.get('beta_auf'))}"
              f"  · letzte 260 T: fiel an {t.get('0.0', {}).get('k')} von {t.get('0.0', {}).get('n')} Verlusttagen, unter −1 %: "
              f"{t.get('-0.01', {}).get('k')} von {t.get('-0.01', {}).get('n')}")
    # 23.67: die Abschnitte des Reiters, die im Text fehlten (ETF-Flüsse, CFTC, Leerverkäufe, Strategy, Struktur)
    E = N.get("etf") or {}; CF = N.get("cftc") or {}; FI = N.get("finra") or {}; MS = N.get("strategy") or {}
    if (E.get("tage") or []) or CF or FI or MS.get("btc") is not None:
        a("")
        a("KRYPTO-AKTIEN UND POSITIONIERUNG")
        if E.get("tage"):
            e0 = E["tage"][0]
            a(f"  Spot-ETF-Flüsse BTC (Farside)  {_z(e0['mio_usd'], 1):>10} Mio USD am {_dt(e0['ts'])}"
              + (f" -- unvollständig (fehlt: {', '.join(e0['fehlt'])})" if e0.get("fehlt") else "")
              + f" · 5 T {_z(E.get('summe5'), 0)} Mio ({E.get('voll5', 0)} vollständige Tage) · "
              f"20 T {_z(E.get('summe20'), 0)} Mio ({E.get('voll20', 0)} vollständige Tage)" + (f" · {e0['fassungen']} Fassungen" if (e0.get("fassungen") or 0) > 1 else ""))
            for e_ in E["tage"][1:FARSIDE_PRUEF_TAGE]:                         # 23.68 (U165): die übrigen geprüften Tage
                if e_.get("fehlt"):
                    a(f"    {_dt(e_['ts'])} unvollständig (fehlt: {', '.join(e_['fehlt'])}), zählt nicht in den Summen")
            if E.get("eingestellt"):
                a(f"    eingestellt (keine Zahl an den letzten {FARSIDE_EINGESTELLT_TAGE} Handelstagen, markiert keinen Tag): {', '.join(E['eingestellt'])}")
            zl = E.get("zaehlung") or {}
            if zl.get("n"):
                ju = " · ".join(f"{u['uhrzeit']} {u['unvollstaendig']} von {u['n']}" for u in zl.get("je_uhrzeit") or [])
                a(f"    jüngster Tag beim Abruf unvollständig: {zl['unvollstaendig']} von {zl['n']} Abrufen"
                  + (f" (gezählt seit {_dt(zl['seit'])}, 23.68)" if zl.get("seit") else "") + (f"; je Abrufzeit {ju}" if ju else "")
                  + " -- entscheidet, ob eine Abrufzeit verlegt oder ergänzt wird (U240)")
        for code, e in CF.items():
            if e.get("ts"):
                a(f"  CFTC {e['name']:<26} Leveraged Funds netto {_g(e.get('lev_netto'))} · Asset Manager netto {_g(e.get('am_netto'))}"
                  f" · OI {_g(e.get('oi'))} Kontrakte · Stand {_dt(e['ts'])}")
        for sym, e in FI.items():
            a(f"  Leerverkaufsquote {sym:<5} (FINRA)  5 T {_p(e.get('quote5'))[1:] if e.get('quote5') is not None else '—'} · letzter Tag "
              f"{_p(e.get('quote1'))[1:] if e.get('quote1') is not None else '—'} ({_dt(e.get('ts'))})")
        if MS.get("btc") is not None:
            a(f"  Strategy: BTC-Bestand (SEC 8-K) {_g(MS['btc'])} am {_dt(MS.get('btc_ts'))}"
              + (f" · zuletzt {'+' if (MS.get('netto_woche') or 0) > 0 else ''}{_g(MS.get('netto_woche'))} BTC" if MS.get("netto_woche") is not None else "")
              + (f" · MSTR {_z(MS['mstr'], 2)}" if MS.get("mstr") else "") + (f" · STRC {_z(MS['strc'], 2)}" if MS.get("strc") else ""))
        if MS.get("unplausibel"):                                          # 23.69 (U177)
            a("  Strategy: unplausible Bestände im Archiv, nicht verwendet (über 30 % unter einem Nachbarn binnen 9 Tagen; das 8-K wird "
              "einmal neu gelesen): " + ", ".join(f"{_dt(t)} {_g(w)}" for t, w in MS["unplausibel"][-6:]))
        for dat, grund in MS.get("unplausibel_8k") or []:
            a(f"  Strategy: 8-K vom {dat} -- gelesener Bestand unplausibel, nicht übernommen: {grund}")
        a("  Strategy: Aktienzahl " + (f"{_g(MS['aktien'])} am {_dt(MS.get('aktien_ts'))} ({MS.get('aktien_name') or 'Abgrenzung unbekannt'})"
                                       if MS.get("aktien") is not None else "noch keine (SEC, Abgrenzungen siehe Quellen)"))
    ST = (N.get("struktur") or {}).get("top10") or []
    if ST:
        a("")
        a(f"STRUKTUR (die zehn größten Werte auf xyz, Abstand zum Hoch seit der Listung) · Mittel {_p(N['struktur'].get('mittel_abstand'))}")
        a("  " + " · ".join(f"{t_['k']} {_p(t_['abstand'])}" for t_ in ST))
    for f in N.get("fehlt") or []:
        a(f"  fehlt: {f}")
    return "\n".join(Z)


def u147_text(E: dict) -> str:
    Z = []; a = Z.append
    a(f"★ Studie U147: Fällt BTC, wenn der S&P 500 fällt? · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}")
    a("Vorab festgelegt (KONZEPT_Ausblick.md 13.12). S&P: FRED SP500; Coins zum S&P-Schluss (30-min-Kerze bis 16:00 New York, swing.db).")
    if E.get("fehlt"):
        a(f"fehlt: {E['fehlt']}"); return "\n".join(Z)
    a(f"S&P-Handelstage {E.get('von')} bis {E.get('bis')} ({E.get('n_tage')})")
    for coin, C in (E.get("coins") or {}).items():
        a("")
        a(f"== {coin} ==")
        for zr, T in C.items():
            for frq, nm in (("tag", "Tag"), ("woche", "Woche"), ("4w", "4 Wochen")):
                t = T.get(frq) or {}
                if not t.get("ab"):
                    continue
                a(f"  {zr} · {nm}: n {t['n']}, ρ {_z(t.get('rho'))}, Beta {_z(t.get('beta'))}")
                for e in t["ab"]:
                    if e.get("n"):
                        a(f"     S&P {'< 0' if e['schwelle'] == 0 else '< ' + _p(e['schwelle'], 0)}: {coin} fiel {e['k']} von {e['n']} = "
                          f"{_z(e['anteil'] * 100, 0)} % ({_z(e['lo'] * 100, 0)}–{_z(e['hi'] * 100, 0)} %), normal erwartet "
                          f"{_z(e.get('normal', float('nan')) * 100, 0)} %, Mittel {_p(e['mittel'])}, Median {_p(e['median'])}"
                          + (f", Beta {_z(e['beta'])}" if e.get("beta") is not None else ""))
                for e in t["auf"]:
                    if e.get("n"):
                        a(f"     S&P {'> 0' if e['schwelle'] == 0 else '> ' + _p(e['schwelle'], 0)}: {coin} stieg {e['k']} von {e['n']} = "
                          f"{_z(e['anteil'] * 100, 0)} % (normal {_z(e.get('normal', float('nan')) * 100, 0)} %)")
    if E.get("ab2016"):
        a("")
        a(f"== BTC ab {E['ab2016'].get('von')} (Tagesschluss 00:00 UTC, Versatz 3–4 h) ==")
        for frq, nm in (("woche", "Woche"), ("4w", "4 Wochen")):
            t = E["ab2016"].get(frq) or {}
            for e in t.get("ab") or []:
                if e.get("n"):
                    a(f"  {nm} S&P {'< 0' if e['schwelle'] == 0 else '< ' + _p(e['schwelle'], 0)}: BTC fiel {e['k']} von {e['n']} = "
                      f"{_z(e['anteil'] * 100, 0)} % (normal {_z(e.get('normal', float('nan')) * 100, 0)} %)")
    V = E.get("vorlauf") or {}
    if V.get("tests"):
        a("")
        a("VORLAUF (Holm über 4, Newey-West)")
        for t in V["tests"]:
            a(f"  {t['name']}: b {_z(t.get('b'), 3)}, t {_z(t.get('t'))}, p {_z(t.get('p'), 3)}, p Holm {_z(t.get('p_holm'), 3)} -> "
              f"{'belegt' if t.get('belegt') else 'nicht belegt'} (n {t.get('n')})")
        a("  " + V.get("hinweis", ""))
    I = E.get("immer") or {}
    a("")
    a("URTEIL „immer“: " + ("bestätigt (100 % in allen Bedingungen)" if I.get("bestaetigt") else "nicht bestätigt -- nicht in allen Bedingungen 100 %"))
    for zr, frq, s_, k, n, an in I.get("naechste") or []:
        a(f"  am nächsten: {zr} · {frq} · S&P < {_p(s_, 0)}: {k} von {n} ({_z(an * 100, 0)} %)")
    return "\n".join(Z)


def k12_text(E: dict) -> str:
    Z = [f"★ Kurzstudie K1/K2: ETF-Flüsse und IBIT-Leerverkäufe über 7 Tage · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}",
         "Vorab festgelegt (KONZEPT_Ausblick.md 13.13): Spearman, Phasen-Randomisierung, Holm über 2, beide Hälften. Erwartung: nicht belegt."]
    if E.get("fehlt"):
        Z.append(f"fehlt: {E['fehlt']}"); return "\n".join(Z)
    for t in E.get("tests") or []:
        if t.get("grund"):
            Z.append(f"  {t['key']} {t['name']}: {t['grund']} (n {t['n']})"); continue
        Z.append(f"  {t['key']} {t['name']}: ρ {_z(t['rho'], 3)}, p {_z(t['p'], 3)}, p Holm {_z(t['p_holm'], 3)}, Hälften "
                 f"{_z(t['h1'], 3)} / {_z(t['h2'], 3)} (Teilung {t['mitte']}), n {t['n']} ({t['von']}–{t['bis']}) -> "
                 f"{'belegt' if t['belegt'] else 'nicht belegt'}")
    Z.append(f"ETF-Bestand für K1: ≈ {GBTC_START_BTC:,.0f} BTC (GBTC bei der Umwandlung) plus aufsummierte Flüsse; ein anderer Anker "
             "ändert die Reihe fast nur um einen Faktor.".replace(",", "."))
    return "\n".join(Z)


# ================================================================================================ Selbsttest (ohne Netz)

def _beispiele() -> dict:
    """Antworten nach den dokumentierten bzw. am 11.10.2026 gelesenen Formaten (FINRA: Kopf und Zeilen wie die Datei vom 09.10.)."""
    return {
        "fred": {"observations": [{"date": "2026-10-08", "value": "6650.12"}, {"date": "2026-10-09", "value": "."},
                                  {"date": "2026-10-10", "value": "6612.50"}]},
        "drb": {"jsonrpc": "2.0", "result": {"data": [[1791590400000, 50.1, 51.0, 49.9, 50.5], [1791594000000, 50.5, 52.0, 50.2, 51.7]],
                                             "continuation": None}},
        "xyz_stand": [{"universe": [{"name": "xyz:SP500", "szDecimals": 3}, {"name": "xyz:MSTR", "szDecimals": 2},
                                    {"name": "xyz:OLD", "isDelisted": True}]},
                      [{"markPx": "6620.5", "oraclePx": "6618.0", "midPx": "6620.4", "prevDayPx": "6580.0", "funding": "0.0000125",
                        "openInterest": "1234.5", "dayNtlVlm": "98765432.1"},
                       {"markPx": "171.25", "oraclePx": "171.0", "midPx": "171.2", "prevDayPx": "175.0"},
                       {"markPx": "1.0"}]],
        "xyz_kerzen": [{"t": 1791590400000, "T": 1791592199999, "s": "xyz:SP500", "i": "30m", "o": "6600.0", "c": "6610.5",
                        "h": "6612.0", "l": "6598.0", "v": "12.5", "n": 40},
                       {"t": 1791592200000, "T": 1791593999999, "s": "xyz:SP500", "i": "30m", "o": "6610.5", "c": "6611.0",
                        "h": "6615.0", "l": "6609.0", "v": "3.0", "n": 9}],
        "cftc": [{"report_date_as_yyyy_mm_dd": "2026-10-06T00:00:00.000", "market_and_exchange_names": "BITCOIN - CHICAGO MERCANTILE EXCHANGE",
                  "cftc_contract_market_code": "133741", "open_interest_all": "21432", "dealer_positions_long_all": "1200",
                  "dealer_positions_short_all": "900", "asset_mgr_positions_long": "8100", "asset_mgr_positions_short": "1500",
                  "lev_money_positions_long": "5731", "lev_money_positions_short": "12583"}],
        "finra": "Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market\n20261009|A|334518.963110|0|768616.578491|B,Q,N\n"
                 "20261009|COIN|1200000.5|1500|2500000.25|B,Q,N\n20261009|IBIT|9000000|20000|30000000|B,Q,N\n"
                 "20261009|MSTR|3000000|0|7000000.75|B,Q,N\n",
        "farside": "<table><tr><th></th><th>IBIT</th><th>FBTC</th><th>GBTC</th><th>Total</th></tr>"
                   "<tr><td>11 Jan 2024</td><td>111.7</td><td>227.0</td><td>(95.1)</td><td>655.3</td></tr>"
                   "<tr><td>12 Jan 2024</td><td>386.0</td><td>-</td><td>(484.1)</td><td>203.0</td></tr>"
                   "<tr><td>Total</td><td>1</td><td>2</td><td>3</td><td>4</td></tr></table>",
        "cboe_vvix": "DATE,VVIX\n01/03/2007,87.63\n10/09/2026,92.10\n",
        "cboe_vix9d": "DATE,OPEN,HIGH,LOW,CLOSE\n01/03/2011,17.0,18.1,16.5,17.62\n10/09/2026,15.5,16.0,15.1,15.80\n",
        "sec_sub": {"cik": "1050446", "filings": {"recent": {"accessionNumber": ["0001193125-26-400001", "0001193125-26-400002",
                                                                                  "0001193125-23-100000"],
                                                             "filingDate": ["2026-10-05", "2026-09-29", "2023-05-01"],
                                                             "form": ["8-K", "10-Q", "8-K"],
                                                             "primaryDocument": ["d1.htm", "q.htm", "old.htm"]}}},
        "sec_8k": "<html><body><p>As of October 4, 2026, Strategy held an aggregate of approximately 847,999 bitcoins acquired for "
                  "an aggregate purchase price of approximately $60.1 billion.</p></body></html>",
        "sec_aktien": {"units": {"shares": [{"end": "2026-07-28", "val": 250000000, "accn": "0001-26-1", "filed": "2026-08-01"},
                                            {"end": "2026-07-28", "val": 19600000, "accn": "0001-26-1", "filed": "2026-08-01"},
                                            {"end": "2026-04-25", "val": 260000000, "accn": "0001-26-0", "filed": "2026-05-01"},
                                            {"end": "2026-04-25", "val": 260000000, "accn": "0001-26-0", "filed": "2026-05-01"}]}},
    }


def _farside_html(tage: list, fonds: list, werte: dict) -> str:
    """Farside-Tabelle für die Probe: werte {(Fonds, Tag): Mio USD oder None („-“)}, Total = Summe der Zahlen."""
    kopf = "<tr><th></th>" + "".join(f"<th>{f}</th>" for f in fonds) + "<th>Total</th></tr>"
    zeilen = []
    for d in tage:
        zellen = []; s = 0.0
        for f in fonds:
            w = werte.get((f, d))
            zellen.append("-" if w is None else (f"({abs(w):.1f})" if w < 0 else f"{w:.1f}")); s += w or 0.0
        zeilen.append(f"<tr><td>{d.day} {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.month - 1]} {d.year}</td>"
                      + "".join(f"<td>{c}</td>" for c in zellen) + f"<td>{s:.1f}</td></tr>")
    return "<table>" + kopf + "".join(zeilen) + "<tr><td>Total</td>" + "<td>0</td>" * (len(fonds) + 1) + "</tr></table>"


def _u165_probe(tmp: str, ok) -> None:
    """23.68 (U165): unvollständige Farside-Tage -- „-“ beim größten Fonds am letzten Tag markiert ihn und nimmt ihn aus den Summen; der
    nächste Abruf mit der Zahl hebt die Markierung auf und gibt „Total“ eine neue Fassung; ein seit vier Handelstagen fehlender Fonds gilt
    als eingestellt und markiert keinen Tag; Zählung je Abruf."""
    tage = [d for d in (date(2026, 9, 21) + timedelta(days=i) for i in range(28)) if handelstag(d)][-22:]
    fonds = ["IBIT", "FBTC", "HODL", "ALT"]
    werte = {(f, d): round(10.0 * (1 + i) + j, 1) for i, f in enumerate(fonds) for j, d in enumerate(tage)}
    for d in tage[-4:]:
        werte[("ALT", d)] = None                                             # ALT seit vier Handelstagen ohne Zahl: eingestellt
    werte[("IBIT", tage[-1])] = None; werte[("HODL", tage[-1])] = None       # wie am 13.10.: der jüngste Tag ohne IBIT und HODL
    con = verbinden(os.path.join(tmp, "u165.db"))
    z1 = farside_fonds_parse(_farside_html(tage, fonds, werte))
    archivieren(con, z1, 1000)
    je, tot = farside_fonds(con); V1 = etf_vollstaendigkeit(je, [t for t, *_ in tot]); S1 = etf_summen([(t, w) for t, w, *_ in tot[:20]], V1["unvollstaendig"])
    t_l = tag_ts(tage[-1].isoformat()); t_v = tag_ts(tage[-2].isoformat())
    hand5 = sum(sum(werte[(f, d)] or 0.0 for f in fonds) for d in tage[-5:-1])
    ok("Farside (U165): jüngster Tag ohne IBIT und HODL als unvollständig markiert, die übrigen geprüften Tage vollständig; 5-Tage-Summe nur "
       "über die 4 vollständigen Tage (von Hand), 20 Tage mit 19",
       V1["unvollstaendig"] == {t_l: ["HODL", "IBIT"]} and V1["eingestellt"] == ["ALT"] and abs((S1["summe5"] or 0) - hand5) < 1e-6
       and S1["voll5"] == 4 and S1["voll20"] == 19 and len(V1["geprueft"]) == 3,
       f"{ {ts_datum(k).isoformat(): v for k, v in V1['unvollstaendig'].items()} }, eingestellt {V1['eingestellt']}, 5 T {S1['summe5']} (Hand {hand5:.1f})")
    werte2 = dict(werte); werte2[("IBIT", tage[-1])] = 99.9; werte2[("HODL", tage[-1])] = 5.5
    archivieren(con, farside_fonds_parse(_farside_html(tage, fonds, werte2)), 2000)
    je2, tot2 = farside_fonds(con); V2 = etf_vollstaendigkeit(je2, [t for t, *_ in tot2])
    fa = con.execute("SELECT fassungen FROM ak_aktuell WHERE reihe='farside:btc:Total' AND ts=?", (t_l,)).fetchone()[0]
    ok("Farside (U165): der nächste Abruf bringt die Zahlen -- Markierung weg, „Total“ des Tages mit einer neuen Fassung (2)",
       V2["unvollstaendig"] == {} and fa == 2 and tot2[0][1] > tot[0][1], f"Fassungen {fa}, Total {tot[0][1]} → {tot2[0][1]}")
    werte3 = dict(werte); werte3[("IBIT", tage[-1])] = 99.9; werte3[("HODL", tage[-1])] = 5.5; werte3[("FBTC", tage[-2])] = None
    je3 = {}
    for r, t, w in farside_fonds_parse(_farside_html(tage, fonds, werte3)):
        if not r.endswith(":Total"):
            je3.setdefault(r.split(":")[2], {})[t] = w
    V3 = etf_vollstaendigkeit(je3, [tag_ts(d.isoformat()) for d in tage])
    ok("Farside (U165): ein Fonds fehlt nur am vorletzten Tag -- dieser Tag markiert, der jüngste nicht; ALT (vier Tage) bleibt „eingestellt“",
       V3["unvollstaendig"] == {t_v: ["FBTC"]} and V3["eingestellt"] == ["ALT"], f"{V3}")
    con.close()


def _u240_log() -> list:
    """23.92 (U240): erfundene Abrufe -- 21.10. (fällt aus den letzten 20), 22.–30.10. je um 01:04 und 13:06 UTC, dazu zwei verspätete am
    31.10. (00:30 UTC gehört zu 13:00 UTC des 30.10., 02:15 UTC zu 01:00 UTC)."""
    def t(tag, h, m):
        return int(datetime(2026, 10, tag, h, m, tzinfo=UTC).timestamp())
    log = [{"ts": t(21, 1, 4), "tag": 0, "fehlt": ["IBIT"]}, {"ts": t(21, 13, 6), "tag": 0, "fehlt": ["IBIT"]}]
    for tag in range(22, 31):
        log.append({"ts": t(tag, 1, 4), "tag": 0, "fehlt": ["IBIT"] if tag % 3 else []})
        log.append({"ts": t(tag, 13, 6), "tag": 0, "fehlt": ["HODL"] if tag == 25 else []})
    log.append({"ts": t(31, 0, 30), "tag": 0, "fehlt": ["IBIT"]})
    log.append({"ts": t(31, 2, 15), "tag": 0, "fehlt": []})
    return log


def _u240_hand(log: list) -> dict:
    """Zählung von Hand für die Termine 01:00 und 13:00 UTC (andere Regel als im Code: Uhrzeit des Abrufs in UTC)."""
    je = {"01:00 UTC": [0, 0], "13:00 UTC": [0, 0]}
    for e in log[-20:]:
        d = datetime.fromtimestamp(e["ts"], UTC)
        k = "13:00 UTC" if (d.hour, d.minute) >= (13, 0) or (d.hour, d.minute) < (1, 0) else "01:00 UTC"
        je[k][0] += 1
        je[k][1] += 1 if e["fehlt"] else 0
    return je


def _u240_probe(ok) -> None:
    """23.92 (U240, KONZEPT_Ausblick.md 13.21): Zählung „jüngster Tag unvollständig“ je Abrufzeit, rückwirkend aus den Zeitpunkten."""
    log = _u240_log()
    Z = farside_zaehlung(log, (("utc", 13, 0), ("utc", 1, 0)))
    hand = _u240_hand(log)
    ju = {u["uhrzeit"]: (u["n"], u["unvollstaendig"]) for u in Z["je_uhrzeit"]}
    ok("Farside (U240): Zählung je Abrufzeit gleich der Zählung von Hand (letzte 20 Abrufe; 00:30 UTC zählt zu 13:00 UTC des Vortags, "
       "02:15 UTC zu 01:00 UTC); gesamt wie bisher",
       ju == {k: tuple(v) for k, v in hand.items()} and Z["n"] == 20 and Z["unvollstaendig"] == 8 and ju["01:00 UTC"] == (10, 6)
       and ju["13:00 UTC"] == (10, 2) and Z["seit"] == log[2]["ts"], f"{Z} · Hand {hand}")
    ok("Farside (U240): ohne gemerkte Abrufe keine Zählung", farside_zaehlung([]) == {"n": 0, "unvollstaendig": 0, "seit": None,
                                                                                   "je_uhrzeit": []})


def _sec_tabelle_8k(gekauft: str | None, bestand: str | None, mit_aktien: bool = True) -> str:
    """Tabellen-8-K wie bei Strategy seit 2025: gekaufte BTC, Kaufpreis ($, Millionen), Ø Preis ($), Bestand, Summe ($, Mrd.), Ø ($);
    dahinter eine eigene Tabelle der Aktienverkäufe (größere Zahl ohne „$“, darf nicht mitzählen)."""
    kopf = ("<tr><td>Period</td><td>BTC Acquired</td><td>Aggregate Purchase Price (in millions)</td><td>Average Purchase Price</td>"
            "<td>Aggregate BTC Holdings</td><td>Aggregate Purchase Price (in billions)</td><td>Average Purchase Price</td></tr>")
    zeile = (f"<tr><td>10/13/2026 - 10/19/2026</td><td>{gekauft or ''}</td><td>$</td><td>205.1</td><td>$&nbsp;</td><td>123,203</td>"
             f"<td>{bestand or ''}</td><td>$</td><td>47.38</td><td>$</td><td>74,000</td></tr>")
    aktien = "<table><tr><td>MSTR ATM</td><td>Shares Sold</td><td>1,234,567</td><td>Net Proceeds</td><td>$</td><td>401.2</td></tr></table>" if mit_aktien else ""
    return f"<html><body><p>The following table sets forth the BTC update.</p><table>{kopf}{zeile}</table>{aktien}</body></html>"


def _sec_tabellen_probe(tmp: str, ok) -> None:
    """23.69 (U177): Tabellen-8-K, Plausibilität gegen den Nachbarbestand, einmaliges Neulesen eines falsch gelesenen Bestands."""
    tab = _sec_tabelle_8k("1,665", "640,250")
    ok("SEC-Tabelle (U177): Bestand aus der Spalte „Aggregate BTC Holdings“ (größte Zahl ohne $; nicht gekaufte BTC, nicht der Ø Preis, "
       "nicht die Aktien der Nachbartabelle); Text-8-K wie bisher",
       sec_bestand_parse(tab) == 640250.0 and sec_bestand_parse(_sec_tabelle_8k("1,665", None, mit_aktien=False)) == 1665.0
       and sec_bestand_parse("<td>Aggregate BTC Holdings</td><td>&nbsp;</td><td>640,250</td>") == 640250.0
       and sec_bestand_parse("Strategy held an aggregate of approximately 847,999 bitcoins") == 847999.0,
       f"Tabelle {sec_bestand_parse(tab)}, ohne Bestandszelle {sec_bestand_parse(_sec_tabelle_8k('1,665', None, mit_aktien=False))}")
    d0 = os.path.join(tmp, "u177"); os.makedirs(d0, exist_ok=True)
    t1, t2, t3, t4 = (tag_ts(x) for x in ("2026-09-28", "2026-10-05", "2026-10-12", "2026-10-19"))
    con = verbinden(os.path.join(d0, "aktien.db"))
    archivieren(con, [("sec:mstr_btc", t1, 640000.0), ("sec:mstr_btc", t2, 1665.0)], 1790000000)      # Stand wie aus 23.68
    text_archivieren(con, "sec:8k", t1, {"acc": "A-1", "datum": "2026-09-28", "doc": "a1.htm", "btc": 640000.0}, 1790000000)
    text_archivieren(con, "sec:8k", t2, {"acc": "A-2", "datum": "2026-10-05", "doc": "a2.htm", "btc": 1665.0}, 1790000000)
    con.close()
    sub = {"filings": {"recent": {"accessionNumber": ["A-1", "A-2", "A-3", "A-4"], "filingDate": ["2026-09-28", "2026-10-05", "2026-10-12", "2026-10-19"],
                                  "form": ["8-K"] * 4, "primaryDocument": ["a1.htm", "a2.htm", "a3.htm", "a4.htm"]}}}
    dok = {"a2.htm": _sec_tabelle_8k("1,665", "647,500"), "a3.htm": _sec_tabelle_8k("7,500", "655,000"),
           "a4.htm": _sec_tabelle_8k("1,700", None, mit_aktien=False)}
    geholt = []

    def h(url, timeout=30, art="json", kopf=None, daten=None):
        if "submissions" in url:
            return sub, None, 200
        if "companyconcept" in url:
            return None, "HTTP 404: Not Found", 404
        for k_, v_ in dok.items():
            if url.endswith(k_):
                geholt.append(k_); return v_, None, 200
        return None, "HTTP 404: unbekannt", 404
    A = Abruf(os.path.join(d0, "aktien.db"), os.path.join(d0, "makro.db"), http_fn=h, jetzt_fn=lambda: 1792500000.0, schlafen=False)
    try:
        r1 = A.lauf("sec"); g1 = list(geholt)
        r2 = A.lauf("sec"); g2 = geholt[len(g1):]
        tb, wb = reihe(A.con, "sec:mstr_btc"); arch = dict(zip((int(x) for x in tb), (float(x) for x in wb)))
        MB = mstr_bestand(A.con); un8 = mstr_unplausibel_8k(A.con)
        rec2 = [json.loads(x) for x, in A.con.execute("SELECT inhalt FROM ak_text WHERE reihe='sec:8k' AND ts=? ORDER BY abgerufen", (t2,))]
    finally:
        A.con.close()
    ok("SEC-Plausibilität (U177): ein neues 8-K mit unplausiblem Bestand (1.700 gegen 655.000 der Vorwoche) wird nicht übernommen und "
       "genannt; der falsch gelesene Bestand 1.665 vom 05.10. wird einmal neu gelesen (647.500) und ersetzt; „zuletzt“ = 655.000 − 647.500",
       r1["ok"] and arch.get(t2) == 647500.0 and arch.get(t3) == 655000.0 and t4 not in arch and sorted(g1) == ["a2.htm", "a3.htm", "a4.htm"]
       and g2 == [] and rec2[-1].get("neu_gelesen") and rec2[-1].get("btc_alt") == 1665.0 and MB["w"][-2:] == [647500.0, 655000.0]
       and not MB["unplausibel"] and un8 and un8[-1][0] == "2026-10-19" and "1.700 gegen 655.000" in un8[-1][1]
       and "unplausibel" in (r1["info"] or "") and "neu gelesen" in (r1["info"] or ""),
       f"Archiv {sorted(arch.values())}, geholt {g1} / {g2}, unplausibel {un8}, Info „{(r1['info'] or '')[:160]}“")


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    import shutil
    ok_all = [True]

    def ok(name, bed, detail=""):
        ok_all[0] &= bool(bed)
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f" — {detail}" if detail and (not bed or verbose) else ""), flush=True)

    if verbose:
        print("Aktienmarkt (U148) und Studien U147/K1/K2 -- Selbsttest ohne Netz", flush=True)
    t_start = time.time()
    # 1) Kalender
    f26, f27, f28 = nyse_feiertage(2026), nyse_feiertage(2027), nyse_feiertage(2028)
    soll26 = {date(2026, 1, 1), date(2026, 1, 19), date(2026, 2, 16), date(2026, 4, 3), date(2026, 5, 25), date(2026, 6, 19),
              date(2026, 7, 3), date(2026, 9, 7), date(2026, 11, 26), date(2026, 12, 25)}
    soll27 = {date(2027, 1, 1), date(2027, 1, 18), date(2027, 2, 15), date(2027, 3, 26), date(2027, 5, 31), date(2027, 6, 18),
              date(2027, 7, 5), date(2027, 9, 6), date(2027, 11, 25), date(2027, 12, 24)}
    soll28 = {date(2028, 1, 17), date(2028, 2, 21), date(2028, 4, 14), date(2028, 5, 29), date(2028, 6, 19), date(2028, 7, 4),
              date(2028, 9, 4), date(2028, 11, 23), date(2028, 12, 25)}
    ok("Kalender: NYSE-Feiertage 2026–2028 nach den Regeln (Karfreitag, beobachtete Tage, Neujahr am Samstag ohne Ersatztag)",
       f26 == soll26 and f27 == soll27 and f28 == soll28, f"{sorted(f26 ^ soll26)} {sorted(f27 ^ soll27)} {sorted(f28 ^ soll28)}")
    t_som = int(datetime(2026, 10, 9, 19, 59, tzinfo=UTC).timestamp()); t_win = int(datetime(2026, 12, 9, 20, 59, tzinfo=UTC).timestamp())
    ok("Kalender: Handelszeit in New Yorker Zeit (Sommerzeit 19:59 UTC offen, Winterzeit 20:59 UTC offen, 21:01 zu, Samstag zu)",
       boerse_offen(t_som) and boerse_offen(t_win) and not boerse_offen(t_win + 120) and not boerse_offen(t_som + 86400)
       and ny_ts(date(2026, 10, 9), 16) == t_som + 60 and ny_ts(date(2026, 12, 9), 16) == t_win + 60)
    # 2) Archiv
    tmp = tempfile.mkdtemp(prefix="hl_aktien_test_")
    try:
        con = verbinden(os.path.join(tmp, "aktien.db"))
        n1 = archivieren(con, [("x", 100, 1.0), ("x", 200, 2.0)], 1000)
        n2 = archivieren(con, [("x", 100, 1.0), ("x", 200, 2.0)], 2000)
        n3 = archivieren(con, [("x", 100, 1.5), ("x", 300, 3.0)], 3000)
        alle = con.execute("SELECT ts, abgerufen, wert FROM ak_wert WHERE reihe='x' ORDER BY ts, abgerufen").fetchall()
        t, w = reihe(con, "x"); ts2, ws2 = reihe_stand(con, "x", 2500)
        fa = con.execute("SELECT fassungen FROM ak_aktuell WHERE reihe='x' AND ts=100").fetchone()[0]
        ok("Archiv: gleicher Wert keine neue Zeile, Revision eine neue Fassung (alte bleibt), jüngste Fassung lesbar, Stand zu einem "
           "früheren Abrufzeitpunkt rekonstruierbar",
           (n1, n2, n3) == (2, 0, 2) and alle == [(100, 1000, 1.0), (100, 3000, 1.5), (200, 1000, 2.0), (300, 3000, 3.0)]
           and list(w) == [1.5, 2.0, 3.0] and list(ws2) == [1.0, 2.0] and fa == 2, f"{alle}")
        k1 = kerzen_schreiben(con, "k", [(10, 1, 2, 0.5, 1.5, 9)], 1); k2 = kerzen_schreiben(con, "k", [(10, 9, 9, 9, 9, 9), (20, 1, 1, 1, 1, 1)], 2)
        K = kerzen(con, "k")
        ok("Archiv: gespeicherte Kerzen bleiben (eine abgeschlossene Kerze ändert sich nicht)", (k1, k2) == (1, 1) and K["o"][0] == 1.0)
        con.close()
        _u165_probe(tmp, ok)                                                        # 23.68 (U165)
        _u240_probe(ok)                                                             # 23.92 (U240)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # 3) Parser
    B = _beispiele()
    import hl_makro as MK
    zf = MK.fred_api_parse("SP500", B["fred"])
    zd, cont = drb_stunden_parse("ETH", B["drb"])
    xs = xyz_stand_parse(B["xyz_stand"])
    xk = xyz_kerzen_parse(B["xyz_kerzen"], 1791593000000)
    zc, fe = cftc_parse(B["cftc"])
    zc2, fe2 = cftc_parse([{k: v for k, v in B["cftc"][0].items() if not k.startswith("dealer")}])
    zfi = finra_parse(B["finra"])
    zfs = farside_fonds_parse(B["farside"])
    zcb = cboe_parse("VVIX", B["cboe_vvix"]); zcb9 = cboe_parse("VIX9D", B["cboe_vix9d"])
    l8 = sec_8k_liste(B["sec_sub"])
    sa = sec_aktien_parse(B["sec_aktien"])
    try:
        finra_parse("<!DOCTYPE html><html><head></head><body>Access denied</body></html>"); html_fang = False
    except ValueError:
        html_fang = True
    ok("Parser FRED (fehlender Wert „.“ fällt weg), Deribit stündlich, xyz-Stand (Präfix, Delisting) und -Kerzen (nur abgeschlossene)",
       zf == [("fred:SP500", tag_ts("2026-10-08"), 6650.12), ("fred:SP500", tag_ts("2026-10-10"), 6612.5)]
       and [z[1:] for z in zd] == [(1791590400, 50.5), (1791594000, 51.7)] and cont is None
       and set(xs) == {"SP500", "MSTR", "OLD"} and xs["SP500"]["mark"] == 6620.5 and xs["OLD"]["delisted"] and xs["MSTR"]["oi"] is None
       and xk == [(1791590400, 6600.0, 6612.0, 6598.0, 6610.5, 12.5)], f"{xk}")
    ok("Parser CFTC (Felder tolerant, fehlendes Feld gemeldet), FINRA (Kopf, Nachkommastellen, nur IBIT/MSTR/COIN, HTML abgewiesen)",
       ("cftc:133741:lev_short", tag_ts("2026-10-06"), 12583.0) in zc and not fe and fe2 == ["dealer_long", "dealer_short"]
       and len(zfi) == 9 and ("finra:COIN:total", tag_ts("2026-10-09"), 2500000.25) in zfi and html_fang, f"{fe2}")
    ok("Parser Farside je Fonds (Klammern negativ, „-“ ist keine Null, Summenzeilen ohne Datum fallen weg), Cboe (beide Formate)",
       ("farside:btc:GBTC", tag_ts("2024-01-11"), -95.1) in zfs and not any(z[0] == "farside:btc:FBTC" and z[1] == tag_ts("2024-01-12") for z in zfs)
       and len(zfs) == 7 and zcb[-1] == ("cboe:VVIX", tag_ts("2026-10-09"), 92.1) and zcb9[-1][2] == 15.8)
    ok("Parser SEC: nur 8-K ab 2024, BTC-Bestand aus dem Text (drei Formulierungen, Tabelle), Aktienzahl je Meldung (Klassen addiert, "
       "doppelte Meldung einmal)",
       [e["acc"] for e in l8] == ["0001193125-26-400001"] and sec_bestand_parse(B["sec_8k"]) == 847999.0
       and sec_bestand_parse("MicroStrategy holds approximately 640,031 BTC") == 640031.0
       and sec_bestand_parse("<td>Aggregate BTC Holdings</td><td>&nbsp;</td><td>640,250</td>") == 640250.0
       and sec_bestand_parse("an 8-K about the annual meeting") is None
       and sa == [(tag_ts("2026-04-25"), 260000000.0), (tag_ts("2026-07-28"), 269600000.0)], f"{sa}")
    # 4) Abruf ohne Netz: alle Quellen über eine Ersatz-Funktion; Schutzschalter; Fälligkeit; Übernahme aus makro.db
    tmp = tempfile.mkdtemp(prefix="hl_aktien_abruf_")
    try:
        mk = MK.verbinden(os.path.join(tmp, "makro.db"))
        MK.schreiben(mk, [("fred:BAMLH0A0HYM2", tag_ts("2023-10-02"), 4.5), ("fred:BAMLH0A0HYM2", tag_ts("2026-10-08"), 3.1)], 1759600000)
        mk.close()
        aufrufe = []
        stoerung = {"finra": False}

        def h(url, timeout=30, art="json", kopf=None, daten=None):
            aufrufe.append(url)
            if "stlouisfed" in url:
                q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                sid = (q.get("series_id") or q.get("id") or ["?"])[0]
                obs = {"observations": [{"date": "2026-10-08", "value": "3.0" if sid == "BAMLH0A0HYM2" else "100"},
                                        {"date": "2026-10-09", "value": "101"}]}
                return (obs if art == "json" else "observation_date,X\n2026-10-08,100\n"), None, 200
            if "deribit" in url:
                return B["drb"], None, 200
            if "hyperliquid" in url:
                body = json.loads(daten.decode())
                return (B["xyz_stand"] if body["type"] == "metaAndAssetCtxs" else B["xyz_kerzen"]), None, 200
            if "cftc" in url:
                return B["cftc"], None, 200
            if "finra" in url:
                if stoerung["finra"]:
                    return None, "HTTP 503: Service Unavailable", 503
                return (B["finra"] if "20261009" in url else None), (None if "20261009" in url else "HTTP 404: Not Found"), (200 if "20261009" in url else 404)
            if "farside" in url:
                return B["farside"], None, 200
            if "cboe" in url:
                return (B["cboe_vvix"] if "VVIX" in url else B["cboe_vix9d"]), None, 200
            if "submissions" in url:
                return B["sec_sub"], None, 200
            if "companyconcept" in url:
                return B["sec_aktien"], None, 200
            if "Archives/edgar" in url:
                return B["sec_8k"], None, 200
            return None, "HTTP 404: unbekannt", 404
        jetzt = [float(datetime(2026, 10, 10, 14, 0, tzinfo=UTC).timestamp())]
        alt_key = os.environ.pop("FRED_API_KEY", None)
        os.environ["FRED_API_KEY"] = "a" * 32
        try:
            A = Abruf(os.path.join(tmp, "aktien.db"), os.path.join(tmp, "makro.db"), http_fn=h, jetzt_fn=lambda: jetzt[0], schlafen=False)
            R = {q: A.lauf(q) for q in QUELLEN}
            con = A.con
            hy = con.execute("SELECT ts, wert, abgerufen FROM ak_wert WHERE reihe='fred:BAMLH0A0HYM2' ORDER BY ts, abgerufen").fetchall()
            ok("Abruf ohne Netz: jede Quelle schreibt ins Archiv (FRED, DVOL, xyz-Stand und -Kerzen, CFTC, FINRA, Farside, Cboe, SEC)",
               all(r["ok"] for r in R.values()) and all(r["neu"] > 0 for q, r in R.items() if q != "finra") and R["finra"]["ok"]
               and reihe(con, "finra:IBIT:total")[1].tolist() == [30000000.0] and reihe(con, "sec:mstr_btc")[1].tolist() == [847999.0]
               and kerzen(con, "xyz:SP500:30m") is not None and reihe(con, "xyz:SP500:mark")[1].tolist() == [6620.5],
               "; ".join(f"{q} {r['ok']} {r['neu']} {r['fehler'] or r['info']}"[:70] for q, r in R.items()))
            lg_ = json.loads(meta(con, "farside_vollstaendig") or "[]")
            ok("Farside-Abruf (U165): Vollständigkeit des jüngsten Tags je Abruf gemerkt (12.01.2024 ohne FBTC, das am Vortag eine Zahl hatte), "
               "im Abrufergebnis genannt", lg_ and lg_[-1]["tag"] == tag_ts("2024-01-12") and lg_[-1]["fehlt"] == ["FBTC"]
               and "unvollständig (fehlt: FBTC)" in (R["farside"]["info"] or ""), f"{lg_[-1:]} · {R['farside']['info']}")
            meta_setzen(con, {"farside_vollstaendig": json.dumps(_u240_log())})       # 23.92 (U240): Text mit erfundenen Abrufen
            T1 = text(os.path.join(tmp, "hl_liq.db"))
            zu = next((z for z in T1.splitlines() if "jüngster Tag beim Abruf unvollständig" in z), "")
            ok("Text (U240): Zählung gesamt und je Abrufzeit, neuer Satz zur Entscheidung (kein „zweiter Abruf am Tag“ mehr)",
               "unvollständig: 8 von 20 Abrufen" in zu and "; je Abrufzeit 01:00 UTC 6 von 10 · 13:00 UTC 2 von 10" in zu
               and zu.endswith("-- entscheidet, ob eine Abrufzeit verlegt oder ergänzt wird (U240)") and "zweiten Abruf" not in T1, zu)
            ok("Übernahme aus makro.db: Hochzinsaufschlag mit alter Abrufzeit, nur Tage vor dem ersten eigenen Wert; eigener Abruf danach "
               "als neue Fassung", hy[0] == (tag_ts("2023-10-02"), 4.5, 1759600000) and any(r[0] == tag_ts("2026-10-08") and r[1] == 3.0 for r in hy)
               and int(meta(con, "import_makro_hy")) == 2, f"{hy}")
            n_sec = len([u for u in aufrufe if "Archives/edgar" in u])
            r2 = A.lauf("sec")
            ok("SEC: ein gelesenes 8-K wird nicht erneut geholt; User-Agent aus der Einstellung (Vorgabe admin@localhost.com)",
               len([u for u in aufrufe if "Archives/edgar" in u]) == n_sec and r2["ok"] and sec_user_agent("/nicht/da") == SEC_UA_STANDARD)
            _sec_tabellen_probe(tmp, ok)                                        # 23.69 (U177)
            # Schutzschalter
            stoerung["finra"] = True
            meta_setzen(con, {"finra_tage": "[]"})
            rf1 = A.lauf("finra"); p1 = float(meta(con, "pause_bis:finra")) - jetzt[0]
            rf2 = A.lauf("finra"); p2 = float(meta(con, "pause_bis:finra")) - jetzt[0]
            stoerung["finra"] = False
            jetzt[0] += 3 * 3600
            rf3 = A.lauf("finra")
            ok("Schutzschalter: Fehler in Folge -> Pause 30 min, dann 60 min; ein Erfolg setzt zurück; optionale Quelle (Cboe) ohne Pause",
               not rf1["ok"] and not rf2["ok"] and abs(p1 - 1800) < 2 and abs(p2 - 3600) < 2 and rf3["ok"]
               and int(meta(con, "fehler_n:finra")) == 0, f"{p1} {p2} {rf3}")
            # Fälligkeit
            t_fr = float(datetime(2026, 10, 9, 21, 30, tzinfo=UTC).timestamp())      # Fr 17:30 New York
            meta_setzen(con, {"versuch:cftc": t_fr - 3 * TAG, "pause_bis:cftc": 0, "versuch:fred": t_fr - 3600, "pause_bis:fred": 0,
                              "versuch:xyz": t_fr - 1700, "pause_bis:xyz": 0})
            f_cftc = faellig(con, "cftc", t_fr); f_cftc_vorher = faellig(con, "cftc", t_fr - 2 * 3600)
            f_fred = faellig(con, "fred", t_fr); f_fred_abend = faellig(con, "fred", t_fr + 3600)
            f_xyz = faellig(con, "xyz", t_fr); f_xyz2 = faellig(con, "xyz", t_fr + 120)
            ok("Fälligkeit: CFTC nach Freitag 16:00 New York, FRED nach 18:15 New York, xyz alle 30 min",
               f_cftc and not f_cftc_vorher and not f_fred and f_fred_abend and not f_xyz and f_xyz2,
               f"{f_cftc} {f_cftc_vorher} {f_fred} {f_fred_abend} {f_xyz} {f_xyz2}")
            A.close()
        finally:
            os.environ.pop("FRED_API_KEY", None)
            if alt_key is not None:
                os.environ["FRED_API_KEY"] = alt_key
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # 4b) 23.67: Befunde aus den Berichten vom 12.10. -- Fehlertexte einzeilig, Aktienzahl über Abgrenzungen, eingestellte
    #     xyz-Märkte, Ortszeit in der Quellenliste, Abschnitt Krypto-Aktien im Text
    ft = fehlertext(404, '<?xml version="1.0" encoding="UTF-8"?>\n<Error><Code>NoSuchKey</Code><Message>The specified key does not exist.</Message></Error>')
    ft2 = fehlertext(503, "Service\n  Unavailable\r\n")
    ok("Fehlertext einzeilig: XML-Fehlerkörper auf den Code verkürzt („HTTP 404: NoSuchKey“), Zeilenumbrüche zusammengefasst",
       ft == "HTTP 404: NoSuchKey" and ft2 == "HTTP 503: Service Unavailable" and "\n" not in ft + ft2, f"{ft!r} {ft2!r}")
    dauer_bsp = {"units": {"shares": [
        {"start": "2026-04-01", "end": "2026-06-30", "val": 280000000, "accn": "0001-26-2"},
        {"start": "2026-01-01", "end": "2026-06-30", "val": 270000000, "accn": "0001-26-2"},
        {"start": "2026-01-01", "end": "2026-03-31", "val": 262000000, "accn": "0001-26-1"},
        {"end": "2026-03-31", "val": 1, "accn": "0001-26-1"}]}}
    sd = sec_aktien_parse(dauer_bsp, dauer=True)
    ok("SEC gewichteter Durchschnitt: nur Quartale (80–100 Tage), das Halbjahr zum selben Stichtag nicht addiert",
       sd == [(tag_ts("2026-03-31"), 262000000.0), (tag_ts("2026-06-30"), 280000000.0)], f"{sd}")
    tmp = tempfile.mkdtemp(prefix="hl_aktien_b12_")
    alt_tz = os.environ.get("TZ")
    try:
        fall = {"modus": "bilanz"}
        aufr = []

        def h2(url, timeout=30, art="json", kopf=None, daten=None):
            aufr.append(url)
            if "submissions" in url:
                return B["sec_sub"], None, 200
            if "Archives/edgar" in url:
                return B["sec_8k"], None, 200
            if "companyconcept" in url:
                if "/dei/" in url or fall["modus"] == "keine":
                    return None, fehlertext(404, "<Error><Code>NoSuchKey</Code></Error>"), 404
                if "CommonStockSharesOutstanding" in url:
                    return B["sec_aktien"], None, 200
            if "hyperliquid" in url:
                body = json.loads(daten.decode())
                if body["type"] == "metaAndAssetCtxs":
                    return [{"universe": [{"name": "xyz:SP500"}, {"name": "xyz:VIX", "isDelisted": True}, {"name": "xyz:MSTR"}]},
                            [{"markPx": "6620.5", "prevDayPx": "6580.0"}, {"markPx": "20.0", "prevDayPx": "20.0"},
                             {"markPx": "171.25", "prevDayPx": "175.0"}]], None, 200
                return B["xyz_kerzen"], None, 200
            return None, "HTTP 404: unbekannt", 404
        jetzt2 = [float(datetime(2026, 10, 11, 22, 15, tzinfo=UTC).timestamp())]
        A2 = Abruf(os.path.join(tmp, "aktien.db"), None, http_fn=h2, jetzt_fn=lambda: jetzt2[0], schlafen=False)
        rs = A2.lauf("sec")
        q1 = meta(A2.con, "sec_aktien_quelle"); w1 = reihe(A2.con, "sec:mstr_aktien")[1].tolist()
        n_konzept = len([u for u in aufr if "companyconcept" in u])
        rs_b = A2.lauf("sec")                                        # binnen 7 Tagen: Aktienzahl nicht erneut
        n_konzept_b = len([u for u in aufr if "companyconcept" in u])
        jetzt2[0] += 8 * TAG; fall["modus"] = "keine"
        rs2 = A2.lauf("sec")
        ok("SEC Aktienzahl: Deckblatt 404 -> Bilanz gespeichert mit Abgrenzung; 404 ist kein Fehler; binnen 7 Tagen kein neuer Abruf; "
           "nirgends gemeldet -> Hinweis ohne Fehler",
           rs["ok"] and q1 == "us-gaap:CommonStockSharesOutstanding" and w1 == [260000000.0, 269600000.0] and "Aktienzahl: Bilanz" in rs["info"]
           and "404" not in rs["info"] and n_konzept == 2 and n_konzept_b == 2 and rs_b["ok"]
           and rs2["ok"] and "in keiner Abgrenzung" in rs2["info"] and int(meta(A2.con, "fehler_n:sec") or 0) == 0,
           f"{rs['info']} | {rs2['info']} | {q1} {w1} {n_konzept} {n_konzept_b}")
        rx = A2.lauf("xyz")
        kerzen_vix = A2.con.execute("SELECT COUNT(*) FROM ak_kerze WHERE reihe LIKE 'xyz:VIX:%'").fetchone()[0]
        werte_vix = A2.con.execute("SELECT COUNT(*) FROM ak_wert WHERE reihe LIKE 'xyz:VIX:%'").fetchone()[0]
        A2.close()
        db2 = os.path.join(tmp, "hl_liq.db")
        N2 = _nutzlast(db2)
        bw = (N2.get("barometer") or {}).get("werte") or {}
        ok("xyz: eingestellter Markt (VIX) nicht im Barometer, als „eingestellt“ genannt, nicht archiviert, keine Kerzen abgefragt",
           rx["ok"] and "VIX" not in bw and "SP500" in bw and (N2.get("barometer") or {}).get("eingestellt") == ["VIX"]
           and kerzen_vix == 0 and werte_vix == 0, f"{list(bw)} {(N2.get('barometer') or {}).get('eingestellt')} {kerzen_vix} {werte_vix}")
        os.environ["TZ"] = "Europe/Berlin"; time.tzset()
        T2 = text(db2)
        zeile = next((z for z in T2.splitlines() if z.strip().startswith(QUELLEN_NAME["sec"])), "")
        ok("Text: Quellenliste in Ortszeit (22:15 UTC am 19.10. = 20.10. 00:15 Berlin); Abschnitt Krypto-Aktien mit Strategy-Bestand "
           "und Aktienzahl samt Abgrenzung; eingestellte Märkte genannt",
           "20.10.2026 00:15" in zeile and "KRYPTO-AKTIEN UND POSITIONIERUNG" in T2 and "Strategy: BTC-Bestand (SEC 8-K) 847.999" in T2
           and "(Bilanz)" in T2 and "eingestellt auf xyz" in T2 and "VIX" in T2.split("eingestellt auf xyz")[1].splitlines()[0],
           zeile + " | " + " / ".join(z for z in T2.splitlines() if "Strategy" in z or "eingestellt" in z))
    finally:
        if alt_tz is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = alt_tz
        time.tzset()
        shutil.rmtree(tmp, ignore_errors=True)
    # 5) Statistik-Bausteine
    ok("phi2: P(X≤0, Y≤0; ρ) = 1/4 + arcsin(ρ)/(2π); Wilson von Hand; Holm von Hand",
       all(abs(phi2(0, 0, r) - (0.25 + math.asin(r) / (2 * math.pi))) < 2e-4 for r in (-0.6, 0.0, 0.3, 0.8))
       and abs(wilson(8, 10)[0] - 0.4902) < 1e-3 and abs(wilson(8, 10)[1] - 0.9433) < 1e-3
       and holm([0.01, 0.04, 0.03]) == [0.03, 0.06, 0.06])
    rng = np.random.default_rng(5)
    x = rng.normal(size=4000); e_ = rng.normal(size=4000)
    r_iid = ols_hac(0.3 * x + e_, x, 0)
    ok("OLS mit Newey-West: bei unabhängigen Fehlern Lag 0 = klassischer Standardfehler, Steigung getroffen",
       abs(r_iid["b"] - 0.3) < 0.05 and abs(r_iid["se"] - 1 / math.sqrt(4000)) < 0.003, f"{r_iid}")
    # 6) U147 auf synthetischen Daten: Normalmodell -> Anteile bei der Erwartung; „immer“-Welt -> bestätigt
    n = 1500
    datums = []
    d = date(2020, 1, 2)
    while len(datums) < n:
        if handelstag(d):
            datums.append(d)
        d += timedelta(days=1)
    rho = 0.4
    zS = rng.normal(size=n); zB = rho * zS + math.sqrt(1 - rho * rho) * rng.normal(size=n)
    sp = 3000 * np.exp(np.cumsum(0.012 * zS)); bt = 30000 * np.exp(np.cumsum(0.035 * zB))
    E = u147_rechnen(datums, sp, {"BTC": bt})
    T = E["coins"]["BTC"]["seit 2020"]["tag"]
    e0 = T["ab"][0]; e1 = T["ab"][1]
    ok("U147 Positivkontrolle Normalmodell (ρ 0,4): Anteil „BTC fiel“ an Verlusttagen im Wilson-Intervall um ½ + arcsin(ρ)/π, "
       "unter −1 % um die Rechnung; ρ und Beta getroffen",
       e0["lo"] - 0.03 <= e0["normal"] <= e0["hi"] + 0.03 and e1["lo"] - 0.05 <= e1["normal"] <= e1["hi"] + 0.05
       and abs(T["rho"] - rho) < 0.06 and abs(T["beta"] - rho * 0.035 / 0.012) < 0.25 and not E["immer"]["bestaetigt"],
       f"{e0['k']}/{e0['n']} ({e0['anteil']:.3f}, normal {e0['normal']:.3f}); <−1 %: {e1.get('anteil', 0):.3f} normal {e1.get('normal', 0):.3f}")
    eb0 = _bedingung(np.array([-1.0, 1.0]), np.array([-1.0, 1.0]), 0.0, -1, 0.4, 0.012)
    eb1 = _bedingung(np.array([-1.0, 1.0]), np.array([-1.0, 1.0]), -0.01, -1, 0.4, 0.012)
    rngm = np.random.default_rng(77)
    zz1 = rngm.standard_normal(2_000_000); zz2 = 0.4 * zz1 + math.sqrt(1 - 0.16) * rngm.standard_normal(2_000_000)
    p_mc = float(np.mean(zz2[zz1 < -0.01 / 0.012] < 0))
    ok("U147 Normalwert: Schwelle 0 = ½ + arcsin(ρ)/π genau; Schwelle −1 % = Φ₂(0, a; ρ)/Φ(a) wie 2·10⁶ Ziehungen (± 0,003)",
       abs(eb0["normal"] - (0.5 + math.asin(0.4) / math.pi)) < 1e-12 and abs(eb1["normal"] - p_mc) < 0.003,
       f"{eb0['normal']:.4f}; {eb1['normal']:.4f} gegen {p_mc:.4f}")
    bt2 = 30000 * np.exp(np.cumsum(np.where(zS < 0, -np.abs(0.03 * zB) - 0.001, 0.035 * zB)))
    E2 = u147_rechnen(datums, sp, {"BTC": bt2})
    ok("U147 Urteil: in einer Welt, in der BTC an jedem S&P-Verlusttag fällt, ist „immer“ bestätigt (Tag); sonst nicht",
       all(e["anteil"] == 1.0 for e in E2["coins"]["BTC"]["seit 2020"]["tag"]["ab"] if e.get("n")) and not E["immer"]["bestaetigt"])
    # Vorlauf: eingepflanzter Vorlauf S&P-Tag -> BTC 24 h; ein unabhängiger Lauf belegt nichts
    t16 = np.array([ny_ts(dd, 16, 0) for dd in datums])
    ts_k = np.arange(t16[0] - 10 * TAG, t16[-1] + 3 * TAG, BAR)
    preis = np.full(len(ts_k), np.nan)
    rS = np.diff(np.log(sp), prepend=np.log(sp[0]))
    lvl = np.log(30000.0) + np.cumsum(rng.normal(0, 0.004, len(ts_k)))
    for i, tt in enumerate(t16):                                       # nach dem Schluss des Tages i: BTC zieht 0,8 · S&P-Tag nach
        j0 = np.searchsorted(ts_k, tt); j1 = np.searchsorted(ts_k, tt + TAG)
        lvl[j0:j1] += 0.8 * rS[i] * np.linspace(0, 1, j1 - j0)
        lvl[j1:] += 0.8 * rS[i]
    Kp = {"ts": ts_k, "c": np.exp(lvl)}
    V = u147_vorlauf(datums, sp, Kp)
    Kn = {"ts": ts_k, "c": np.exp(np.log(30000.0) + np.cumsum(rng.normal(0, 0.004, len(ts_k))))}
    V0 = u147_vorlauf(datums, sp, Kn)
    ok("U147 Vorlauf: eingepflanzter Nachlauf von BTC (24 h) wird belegt (Holm), ein unabhängiger BTC-Pfad belegt nichts",
       V["tests"][0]["belegt"] and not any(t["belegt"] for t in V0["tests"]),
       f"{[round(t['p_holm'], 4) for t in V['tests']]} / {[round(t['p_holm'], 3) for t in V0['tests']]}")
    ku_ = kurs_um({"ts": np.array([ny_ts(date(2026, 10, 9), 15, 30), ny_ts(date(2026, 10, 9), 16, 0), ny_ts(date(2026, 12, 9), 15, 0)]),
                   "c": np.array([1.0, 9.0, 2.0])},
                  np.array([ny_ts(date(2026, 10, 9), 16), ny_ts(date(2026, 12, 9), 16), ny_ts(date(2026, 12, 9), 18)]))
    ok("kurs_um: Kerze bis 16:00 New York (Sommer- und Winterzeit; nicht die ab 16:00), fehlt sie, die bis zu 1 h ältere; sonst NaN",
       ku_.tolist()[:2] == [1.0, 2.0] and np.isnan(ku_[2]), f"{ku_.tolist()}")
    import hl_makro_korr as MKK
    xl = np.cumsum(rng.normal(size=1600)); yl = rng.normal(size=1600)
    r1_, n1_, _ = MKK.phasen_null(xl, yl, k=500, seed=3); r2_, n2_, _ = phasen_null_spearman(xl, yl, k=500, seed=3)
    ok("Phasen-Null der Kurzstudie gleich der Rechnung von U130 (hl_makro_korr.phasen_null) bei langer Reihe",
       n1_ is not None and abs(r1_ - r2_) < 1e-12 and np.allclose(n1_, n2_))
    # 7) K1/K2: eingepflanzter Zusammenhang belegt, Rauschen nicht
    m = 700
    dk = [d0 for d0 in (date(2024, 1, 11) + timedelta(days=i) for i in range(1100)) if handelstag(d0)][:m]
    flow = rng.normal(0, 300, m); bb = 50000 * np.exp(np.cumsum(rng.normal(0, 0.02, m)))
    sh = rng.uniform(0.2, 0.5, m) * 1e7; to = np.full(m, 1e7)
    f20 = np.convolve(flow, np.ones(20), "full")[:m]
    sig = np.full(m, 0.025)
    y_plant = 0.6 * (f20 - f20.mean()) / f20.std() + rng.normal(0, 1, m)
    b7 = bb * np.exp(y_plant * 0.025 * math.sqrt(7))
    Kp = k12_rechnen(dk, flow, bb, b7, sig, sh, to, k=1000)
    b7n = bb * np.exp(rng.normal(0, 1, m) * 0.025 * math.sqrt(7))
    Kn0 = k12_rechnen(dk, flow, bb, b7n, sig, sh, to, k=1000)
    ok("K1/K2: eingepflanzter Fluss-Zusammenhang (K1) belegt, K2 nicht; reines Rauschen belegt nichts",
       Kp["tests"][0]["belegt"] and not Kp["tests"][1]["belegt"] and not any(t["belegt"] for t in Kn0["tests"]),
       f"{[(t['key'], round(t.get('rho', 0), 3), round(t.get('p_holm', 1), 4)) for t in Kp['tests']]}")
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok_all[0] else 'NICHT bestanden'} ({time.time() - t_start:.0f} s)", flush=True)
    return ok_all[0]


# ================================================================================================ Befehlszeile

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Aktienmarkt (U148): Archiv, Barometer, Studien U147 und K1/K2")
    ap.add_argument("--db", help="Hauptdatenbank hl_liq.db (aktien.db liegt daneben)")
    ap.add_argument("--abrufen", action="store_true", help="Quellen jetzt abrufen (alle oder --quelle)")
    ap.add_argument("--quelle", default=",".join(QUELLEN))
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--u147", action="store_true")
    ap.add_argument("--k12", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    a = ap.parse_args(argv)
    if a.selbsttest:
        return 0 if selbsttest() else 1
    db = a.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "hl_liq.db")
    if a.abrufen:
        qs = tuple(q.strip() for q in a.quelle.split(",") if q.strip() in QUELLEN)
        print(f"Abruf {', '.join(qs)} -> {aktien_pfad(db)}", flush=True)
        r = abrufen(db, qs, nur_faellige=False, log=lambda s: print(s, flush=True))
        return 0 if all(x["ok"] or x["quelle"] in OPTIONAL for x in r) else 1
    if a.u147:
        print(u147_text(u147(db)))
        return 0
    if a.k12:
        print(k12_text(k12(db)))
        return 0
    print(text(db))
    return 0


if __name__ == "__main__":
    sys.exit(main())
