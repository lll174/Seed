"""
Adress-Strom (23.33): Jeder Trade im öffentlichen Trade-Feed von Hyperliquid trägt BEIDE Adressen (users = [Käufer,
Verkäufer]) und die Seite des Aggressors (side "B" = der Käufer hat genommen, "A" = der Verkäufer). Der Recorder sieht
diese Trades ohnehin (0 API-Gewicht). Hier wird daraus je Minute, Coin und Adresse eine Zeile:

  taker_kauf / taker_verk   USD, die die Adresse als Nehmer gekauft / verkauft hat (aggressiv, zahlt den Spread)
  maker_kauf / maker_verk   USD, die sie als Geber (Limit-Order im Buch) gekauft / verkauft hat
  n                         Anzahl Fills
  twap                      Netto-USD ihrer Nehmer-Fills mit Null-Hash (+ Kauf, − Verkauf)

dazu je Minute und Coin eine Summenzeile (Trades, davon Null-Hash, Adressen, Umsatz, TWAP-Käufe/-Verkäufe).

Null-Hash: Trades mit hash 0x000…0 stammen nicht aus einer einzeln signierten Transaktion -- nach allem, was bekannt ist,
Teilaufträge laufender TWAP-Orders. Die Diagnose zeigt den Anteil je Coin; bestätigt ist die Deutung erst, wenn die
Null-Hash-Käufe/-Verkäufe gleichmäßig über Minuten verteilt je Adresse auftreten (Prüfung im Bericht).

Gespeichert wird in einer EIGENEN Datei adressfluss.db neben der Hauptdatenbank: nicht in hl_liq.db (keine Schreiblast
dort, keine Sperre für andere Schreiber), nicht im Backup (Rohdaten, groß). Vorhalt 14 Tage (--af-tage), Größendeckel
3 GB belegte Seiten (--af-max-gb): darüber werden die ältesten Stunden gelöscht. Adressen als 20-Byte-Blob, Beträge
als ganze USD -- das halbiert den Platz gegenüber Text und Gleitkomma.

Nutzer: TradeLabor (TWAP-Druck, Datenfluss), Netzwerkstatus (Diagnose); als Nächstes der informierte Fluss je Adresse
(Markouts: wie lief der Kurs nach ihren Nehmer-Käufen und -Verkäufen, 23.34).
"""
import os
import sqlite3
import sys
import time

NULL_HASH = "0x" + "0" * 64
TAGE = 14
MAX_GB = 3.0
STAT_TAGE = 90
GNADE_S = 10                    # eine Minute gilt 10 s nach ihrem Ende als abgeschlossen (späte Trades: Upsert)
REST_MAX = 200_000              # Zeilen, die bei Schreibfehlern für den nächsten Versuch gehalten werden

SCHEMA = """
CREATE TABLE IF NOT EXISTS af_1m (minute INTEGER, coin TEXT, addr BLOB, taker_kauf INTEGER, taker_verk INTEGER,
    maker_kauf INTEGER, maker_verk INTEGER, n INTEGER, twap INTEGER, PRIMARY KEY (minute, coin, addr)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS af_stat (minute INTEGER, coin TEXT, trades INTEGER, nullhash INTEGER, adressen INTEGER, usd INTEGER,
    twap_kauf INTEGER, twap_verk INTEGER, PRIMARY KEY (minute, coin)) WITHOUT ROWID;
"""
UPSERT_1M = ("INSERT INTO af_1m VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(minute, coin, addr) DO UPDATE SET "
             "taker_kauf = taker_kauf + excluded.taker_kauf, taker_verk = taker_verk + excluded.taker_verk, "
             "maker_kauf = maker_kauf + excluded.maker_kauf, maker_verk = maker_verk + excluded.maker_verk, "
             "n = n + excluded.n, twap = twap + excluded.twap")
UPSERT_STAT = ("INSERT INTO af_stat VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(minute, coin) DO UPDATE SET "
               "trades = trades + excluded.trades, nullhash = nullhash + excluded.nullhash, "
               "adressen = MAX(adressen, excluded.adressen), usd = usd + excluded.usd, "
               "twap_kauf = twap_kauf + excluded.twap_kauf, twap_verk = twap_verk + excluded.twap_verk")


def pfad_neben(db: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(db)), "adressfluss.db")


def adresse_bytes(a: str) -> bytes:
    a = str(a).lower()
    if a.startswith("0x") and len(a) == 42:
        try:
            return bytes.fromhex(a[2:])
        except ValueError:
            pass
    return a.encode()


def adresse_text(b) -> str:
    if isinstance(b, (bytes, bytearray)):
        return "0x" + bytes(b).hex() if len(b) == 20 else bytes(b).decode("utf-8", "replace")
    return str(b)


def verbinden(pfad: str, schreiben: bool = True) -> sqlite3.Connection:
    if not schreiben:
        return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=5)
    con = sqlite3.connect(pfad, timeout=30, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    return con


class Adressfluss:
    """Sammelt im Ereignis-Thread des Recorders (trade, abholen) und schreibt in einem Hilfsthread (schreiben)."""

    def __init__(self, pfad: str, tage: int = TAGE, max_gb: float = MAX_GB):
        self.pfad = pfad; self.tage = int(tage); self.max_gb = float(max_gb)
        self.puffer: dict = {}; self.stat: dict = {}
        self.rest: tuple = ([], [])
        self.con = None; self._pflege = 0
        self.st = {"trades_min": 0, "nullhash_min": 0, "zeilen_min": 0, "adressen_min": 0, "letzte_minute": None, "adressen_h": None,
                   "groesse_mb": None, "seit": None, "geschrieben": 0, "verworfen": 0, "gekappt_h": 0, "schreib_ms": None,
                   "fehler": None, "fehler_ts": None}

    # --- im Ereignis-Thread (schnell, ohne Datenbank)
    def trade(self, coin: str, ts_ms: int, usd: float, users, taker_kauf: bool, nullhash: bool) -> None:
        if not users or len(users) < 2:
            return
        m = int(ts_ms) // 60_000 * 60
        for i in (0, 1):
            a = users[i]
            if not isinstance(a, str):
                continue
            k = (m, coin, a.lower())
            e = self.puffer.get(k)
            if e is None:
                e = self.puffer[k] = [0.0, 0.0, 0.0, 0.0, 0, 0.0]
            kauf = i == 0
            if kauf == taker_kauf:                                     # diese Seite hat genommen
                e[0 if kauf else 1] += usd
                if nullhash:
                    e[5] += usd if kauf else -usd
            else:
                e[2 if kauf else 3] += usd
            e[4] += 1
        s = self.stat.get((m, coin))
        if s is None:
            s = self.stat[(m, coin)] = [0, 0, 0.0, 0.0, 0.0]
        s[0] += 1; s[4] += usd
        if nullhash:
            s[1] += 1; s[2 if taker_kauf else 3] += usd

    def abholen(self, now: int, alles: bool = False) -> tuple:
        """Abgeschlossene Minuten aus dem Speicher nehmen: (Adresszeilen, Summenzeilen)."""
        fertig = [k for k in self.puffer if alles or k[0] + 60 + GNADE_S <= now]
        rows = []
        adr: dict = {}
        for k in fertig:
            e = self.puffer.pop(k)
            rows.append((k[0], k[1], adresse_bytes(k[2]), round(e[0]), round(e[1]), round(e[2]), round(e[3]), e[4], round(e[5])))
            adr[(k[0], k[1])] = adr.get((k[0], k[1]), 0) + 1
        stat = []
        for k in [k for k in self.stat if alles or k[0] + 60 + GNADE_S <= now]:
            s = self.stat.pop(k)
            stat.append((k[0], k[1], s[0], s[1], adr.get(k, 0), round(s[4]), round(s[2]), round(s[3])))
        if stat:
            m_ = max(r[0] for r in stat)
            self.st.update(letzte_minute=m_, trades_min=sum(r[2] for r in stat if r[0] == m_), nullhash_min=sum(r[3] for r in stat if r[0] == m_),
                           adressen_min=sum(r[4] for r in stat if r[0] == m_), zeilen_min=sum(1 for r in rows if r[0] == m_))
        return rows, stat

    # --- im Hilfsthread
    def schreiben(self, rows: list, stat: list, now: int | None = None) -> bool:
        now = int(now or time.time()); t0 = time.time()
        rows = self.rest[0] + list(rows); stat = self.rest[1] + list(stat); self.rest = ([], [])
        try:
            if self.con is None:
                self.con = verbinden(self.pfad)
            if rows:
                self.con.executemany(UPSERT_1M, rows)
            if stat:
                self.con.executemany(UPSERT_STAT, stat)
            self.con.commit()
        except sqlite3.Error as e:
            try:
                if self.con is not None:
                    self.con.rollback()
            except sqlite3.Error:
                pass
            self.st["fehler"] = f"{type(e).__name__}: {e}"; self.st["fehler_ts"] = now
            if len(rows) <= REST_MAX:
                self.rest = (rows, stat)                               # beim nächsten Takt erneut
            else:
                self.st["verworfen"] += len(rows)
            return False
        self.st["geschrieben"] += len(rows); self.st["schreib_ms"] = round((time.time() - t0) * 1000)
        if self.st["fehler"] and now - (self.st["fehler_ts"] or 0) > 3600:
            self.st["fehler"] = None
        if now - self._pflege >= 3600:
            self._pflege = now
            try:
                self.pflege(now)
            except sqlite3.Error as e:
                self.st["fehler"] = f"Pflege: {type(e).__name__}: {e}"; self.st["fehler_ts"] = now
        return True

    def pflege(self, now: int) -> None:
        """Stündlich: Vorhalt (Tage), Größendeckel, Kennzahlen, WAL falten."""
        c = self.con
        grenze = (now - self.tage * 86_400) // 60 * 60
        lo = c.execute("SELECT MIN(minute) FROM af_1m").fetchone()[0]
        while lo is not None and lo < grenze:                          # stundenweise, Commit je Stück
            hi = min(grenze, lo + 3600)
            c.execute("DELETE FROM af_1m WHERE minute >= ? AND minute < ?", (lo, hi)); c.commit()
            lo = hi
        c.execute("DELETE FROM af_stat WHERE minute < ?", (now - STAT_TAGE * 86_400,)); c.commit()
        seite = c.execute("PRAGMA page_size").fetchone()[0]

        def belegt():
            return (c.execute("PRAGMA page_count").fetchone()[0] - c.execute("PRAGMA freelist_count").fetchone()[0]) * seite
        n = 0
        while belegt() > self.max_gb * 1e9 and n < 48:
            lo = c.execute("SELECT MIN(minute) FROM af_1m").fetchone()[0]
            if lo is None:
                break
            c.execute("DELETE FROM af_1m WHERE minute < ?", (lo + 3600,)); c.commit(); n += 1
        self.st["gekappt_h"] += n
        self.st["adressen_h"] = c.execute("SELECT COUNT(DISTINCT addr) FROM af_1m WHERE minute >= ?", (now - 3600,)).fetchone()[0]
        self.st["seit"] = c.execute("SELECT MIN(minute) FROM af_1m").fetchone()[0]
        try:
            c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except sqlite3.Error:
            pass
        self.st["groesse_mb"] = round(sum(os.path.getsize(p) for p in (self.pfad, self.pfad + "-wal") if os.path.exists(p)) / 1e6, 1)

    def kennzahlen(self) -> dict:
        return dict(self.st, puffer=len(self.puffer), tage=self.tage, max_gb=self.max_gb, rueckstand=len(self.rest[0]))


# ------------------------------------------------------------------------------------------------ Lesen (TradeLabor, Bericht)
def lesen(pfad: str, coin: str, now: int, vol_h=None) -> dict | None:
    """Letzte 60 min eines Coins: Trades, Adressen, Null-Hash-Anteil, TWAP-Netto (absolut und relativ zum Stundenvolumen),
    die drei größten Netto-Nehmer. None, solange die Datei fehlt."""
    if not os.path.exists(pfad):
        return None
    try:
        c = verbinden(pfad, schreiben=False)
        try:
            r = c.execute("SELECT SUM(trades), SUM(nullhash), SUM(twap_kauf) - SUM(twap_verk), MAX(minute), COUNT(*), SUM(usd), "
                          "SUM(twap_kauf), SUM(twap_verk) FROM af_stat WHERE minute >= ? AND coin = ?", (now - 3600, coin)).fetchone()
            a = c.execute("SELECT COUNT(DISTINCT addr) FROM af_1m WHERE minute >= ? AND coin = ?", (now - 3600, coin)).fetchone()
            top = c.execute("SELECT addr, SUM(taker_kauf) - SUM(taker_verk) AS netto, SUM(taker_kauf + taker_verk + maker_kauf + maker_verk), "
                            "SUM(twap) FROM af_1m WHERE minute >= ? AND coin = ? GROUP BY addr ORDER BY ABS(netto) DESC LIMIT 3",
                            (now - 3600, coin)).fetchall()
            seit = c.execute("SELECT MIN(minute) FROM af_stat").fetchone()
        finally:
            c.close()
    except sqlite3.Error:
        return None
    seit = seit[0] if seit else None
    if not r or not r[0]:
        return {"trades_h": 0, "adressen_h": 0, "nullhash_anteil": None, "tw_netto_h": 0.0, "tw_anteil": None, "ts": None, "seit": seit, "top": []}
    return {"trades_h": int(r[0]), "adressen_h": int(a[0] or 0), "nullhash_anteil": (r[1] or 0) / r[0], "tw_netto_h": float(r[2] or 0.0),
            "tw_kauf_h": float(r[6] or 0.0), "tw_verk_h": float(r[7] or 0.0), "usd_h": float(r[5] or 0.0),
            "tw_anteil": (float(r[2] or 0.0) / vol_h) if vol_h else None, "ts": int(r[3] or 0) + 60, "minuten": int(r[4] or 0), "seit": seit,
            "top": [{"addr": adresse_text(t[0]), "netto": float(t[1] or 0), "umsatz": float(t[2] or 0), "twap": float(t[3] or 0)} for t in top]}


def bericht(pfad: str, now: int | None = None) -> str:
    """Kurzbericht je Coin: Aufzeichnung, Null-Hash-Anteil, TWAP-Netto und die Verteilung der Null-Hash-Trades über Minuten."""
    now = int(now or time.time())
    if not os.path.exists(pfad):
        return f"Adress-Strom: {pfad} fehlt noch (Recorder ab 23.33 legt die Datei an)."
    c = verbinden(pfad, schreiben=False)
    try:
        z = [f"Adress-Strom · {pfad} · {os.path.getsize(pfad) / 1e6:.1f} MB"]
        seit = c.execute("SELECT MIN(minute), MAX(minute) FROM af_stat").fetchone()
        z.append(f"Aufzeichnung {time.strftime('%d.%m. %H:%M', time.localtime(seit[0])) if seit and seit[0] else '—'} bis "
                 f"{time.strftime('%d.%m. %H:%M', time.localtime(seit[1] + 60)) if seit and seit[1] else '—'}")
        z.append(f"{'Coin':<6}{'Trades 24 h':>12}{'Null-Hash':>11}{'Adressen 1 h':>14}{'TWAP netto 24 h':>17}{'Min. mit TWAP':>15}")
        for coin, tr, nh, tk, tv, mins in c.execute(
                "SELECT coin, SUM(trades), SUM(nullhash), SUM(twap_kauf), SUM(twap_verk), SUM(nullhash > 0) FROM af_stat "
                "WHERE minute >= ? GROUP BY coin ORDER BY SUM(usd) DESC", (now - 86_400,)).fetchall():
            ad = c.execute("SELECT COUNT(DISTINCT addr) FROM af_1m WHERE minute >= ? AND coin = ?", (now - 3600, coin)).fetchone()[0]
            z.append(f"{coin:<6}{tr:>12,}{(nh or 0) / tr * 100 if tr else 0:>10.2f}%{ad:>14,}{((tk or 0) - (tv or 0)) / 1e6:>+15.2f} M{mins or 0:>15}".replace(",", "."))
        z.append("")
        z.append("Größte TWAP-Adressen (Null-Hash-Nehmer, 24 h): Minuten mit Fills, netto USD")
        for coin, addr, mins, netto in c.execute(
                "SELECT coin, addr, COUNT(*), SUM(twap) FROM af_1m WHERE minute >= ? AND twap <> 0 GROUP BY coin, addr "
                "ORDER BY ABS(SUM(twap)) DESC LIMIT 12", (now - 86_400,)).fetchall():
            z.append(f"  {coin:<6}{adresse_text(addr)}  {mins:>5} min  {netto / 1e6:+.2f} Mio")
    finally:
        c.close()
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    tmp = tempfile.mkdtemp(prefix="hl_af_test_")
    try:
        pfad = os.path.join(tmp, "adressfluss.db")
        A = Adressfluss(pfad, tage=14, max_gb=3.0)
        T = 1_790_000_040                                         # Minute 1_790_000_040 (volle Minute)
        k1, k2, mm = "0x" + "a1" * 20, "0x" + "b2" * 20, "0x" + "cc" * 20
        # Minute 1: k1 kauft als Nehmer 10.000 von mm; k2 verkauft als Nehmer 4.000 an mm; TWAP-Kauf k1 2.000 (Null-Hash)
        A.trade("BTC", T * 1000 + 1_000, 10_000.0, [k1, mm], True, False)
        A.trade("BTC", T * 1000 + 2_000, 4_000.0, [mm, k2], False, False)
        A.trade("BTC", T * 1000 + 3_000, 2_000.0, [k1.upper().replace("0X", "0x"), mm], True, True)
        A.trade("ETH", T * 1000 + 4_000, 1_500.0, [k2, k1], False, False)          # k1 verkauft als Nehmer an k2 (Maker-Kauf k2)
        # Minute 2 (noch offen, wenn abgeholt wird)
        A.trade("BTC", (T + 60) * 1000 + 5_000, 7_000.0, [mm, k1], False, True)    # TWAP-Verkauf k1
        rows, stat = A.abholen(T + 60 + GNADE_S)
        ok("Nur abgeschlossene Minuten", {r[0] for r in rows} == {T} and len(A.puffer) == 2, f"{len(rows)} Zeilen, {len(A.puffer)} im Puffer")
        A.schreiben(rows, stat, T + 80)
        c = sqlite3.connect(pfad)
        z = {(r[1], adresse_text(r[2])): r[3:] for r in c.execute("SELECT * FROM af_1m")}
        ok("Nehmer/Geber je Seite", z[("BTC", k1)] == (12_000, 0, 0, 0, 2, 2_000) and z[("BTC", mm)] == (0, 0, 4_000, 12_000, 3, 0)
           and z[("BTC", k2)] == (0, 4_000, 0, 0, 1, 0) and z[("ETH", k1)] == (0, 1_500, 0, 0, 1, 0) and z[("ETH", k2)] == (0, 0, 1_500, 0, 1, 0),
           f"BTC k1 {z.get(('BTC', k1))}, mm {z.get(('BTC', mm))}")
        s = {r[1]: r[2:] for r in c.execute("SELECT * FROM af_stat")}
        ok("Summenzeile je Minute und Coin", s["BTC"] == (3, 1, 3, 16_000, 2_000, 0) and s["ETH"] == (1, 0, 2, 1_500, 0, 0), f"BTC {s.get('BTC')}")
        ok("Adresse als 20-Byte-Blob", c.execute("SELECT length(addr) FROM af_1m LIMIT 1").fetchone()[0] == 20, "20 Byte")
        c.close()
        # späte Trades derselben Minute: aufaddiert, nicht überschrieben
        A.trade("BTC", T * 1000 + 59_500, 1_000.0, [k1, mm], True, False)
        rows, stat = A.abholen(T + 135)
        A.schreiben(rows, stat, T + 135)
        c = sqlite3.connect(pfad)
        v = c.execute("SELECT taker_kauf, n FROM af_1m WHERE minute=? AND coin='BTC' AND addr=?", (T, adresse_bytes(k1))).fetchone()
        v2 = c.execute("SELECT twap FROM af_1m WHERE minute=? AND coin='BTC' AND addr=?", (T + 60, adresse_bytes(k1))).fetchone()
        ok("Nachzügler per Upsert addiert", v == (13_000, 3) and v2 == (-7_000,), f"k1 Minute 1: {v}, Minute 2 TWAP {v2}")
        c.close()
        L = lesen(pfad, "BTC", T + 135, vol_h=1_000_000)
        ok("Lesen für TradeLabor", L and L["trades_h"] == 5 and abs(L["tw_netto_h"] - (2_000 - 7_000)) < 1 and abs(L["tw_anteil"] + 0.005) < 1e-9
           and L["adressen_h"] == 3 and L["top"][0]["addr"] == k1,
           f"Trades {L and L['trades_h']}, TWAP netto {L and L['tw_netto_h']:+.0f}, Anteil {L and L['tw_anteil']:+.4f}, Spitze {L and L['top'][0]['addr'][:8]}")
        # Schreibfehler: Zeilen bleiben für den nächsten Versuch
        B = Adressfluss(os.path.join(tmp, "fehlt", "x.db"))
        B.trade("BTC", T * 1000, 100.0, [k1, k2], True, False)
        r_, s_ = B.abholen(T + 200)
        gut = B.schreiben(r_, s_, T + 200)
        B.pfad = os.path.join(tmp, "x.db")
        gut2 = B.schreiben([], [], T + 260)
        c = sqlite3.connect(B.pfad); nx = c.execute("SELECT COUNT(*) FROM af_1m").fetchone()[0]; c.close()
        ok("Schreibfehler verliert nichts", (not gut) and gut2 and nx == 2 and B.st["fehler"], f"erst Fehler ({B.st['fehler'][:40] if B.st['fehler'] else '—'}), dann {nx} Zeilen")
        # Vorhalt und Größendeckel
        C = Adressfluss(os.path.join(tmp, "c.db"), tage=1, max_gb=3.0)
        alt = T - 3 * 86_400
        for i in range(0, 3 * 1440, 30):
            C.trade("BTC", (alt + i * 60) * 1000, 100.0, [k1, k2], True, False)
        r_, s_ = C.abholen(T, alles=True)
        C.schreiben(r_, s_, T)
        c = sqlite3.connect(C.pfad); rest = c.execute("SELECT MIN(minute) FROM af_1m").fetchone()[0]; c.close()
        ok("Vorhalt: ältere Minuten gelöscht", rest is not None and rest >= T - 86_400, f"älteste Minute {(T - rest) / 3600:.1f} h alt")
        D = Adressfluss(os.path.join(tmp, "d.db"), tage=30, max_gb=0.0002)           # 200 kB Deckel (Daten ~350 kB)
        for i in range(0, 2 * 1440, 1):
            D.trade("BTC", (alt + i * 60) * 1000, 100.0, ["0x%040x" % (i * 7 + 1), "0x%040x" % (i * 7 + 2)], True, False)
        r_, s_ = D.abholen(T, alles=True)
        D.schreiben(r_, s_, T)
        c = sqlite3.connect(D.pfad); nd = c.execute("SELECT COUNT(*) FROM af_1m").fetchone()[0]; c.close()
        ok("Größendeckel kappt die ältesten Stunden", 0 < nd < 2 * 2 * 1440 and D.st["gekappt_h"] > 0, f"{D.st['gekappt_h']} Stunden gekappt, {nd} Zeilen übrig")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p[1] for p in pruef)
    if verbose:
        print("Adress-Strom -- Selbsttest")
        for name, gut, text in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<40} {text}")
        print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


if __name__ == "__main__":
    if "--selbsttest" in sys.argv:
        sys.exit(0 if selbsttest() else 1)
    if "--bericht" in sys.argv:
        db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else "hl_liq.db"
        print(bericht(pfad_neben(db)))
        sys.exit(0)
    print("Aufruf: hl_adressfluss.py --selbsttest | --bericht --db <hl_liq.db>")
