# KONZEPT Makro-Chart (U121) — Lage im mittel- und langfristigen Zyklus

Stand 05.10.2026, Version 2026-09-23.47 (Opus 5.5). Grundlage: `RECHERCHE_Makro_Chart_05-10-2026.md` (Bericht „Kostenbasis verortet den
Zyklus, feste Schwellen versagen“). Wunsch des Nutzers (05.10.): alles Kostenlose aus Stufe 1 und 2 einbauen, jeden Treiber mit
eigenem Chart, dazu die Miner-Kostenbasis (Ausgangsszenario Antminer S21 XP bei 7,5 ct/kWh); eigene Datenbank `makro.db`.

Code: `hl_makro.py` (Abruf, Rechnung, Nutzlast, Selbsttest), `hl_makro_js.py` (Skript des Abschnitts, `/makro.js`),
Abschnitt „MK Makro“ in `hl_viz.py`. Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein API-Gewicht.

## 1. Regeln (aus dem Bericht, fest eingebaut)

1. **Positionen statt Signale.** Bänder im Kurschart (Realized Price, 200-Wochen-MA, Power-Law-Fair-Value, Kurzfrist-Kostenbasis,
   Stromkosten eines Miners) und Perzentile der eigenen Historie. Keine festen Schwellen aus 2013–2021 (MVRV 3,7/1, MVRV-Z 7/0,
   NUPL 0,75/0, Puell 4/0,5, LTH-SOPR 10/0,6, Pi Cycle …): 2025/26 oben und unten verfehlt, weil die Ausschläge seit 2011 schrumpfen
   (MVRV-Hochs je Halving-Epoche 7,74 · 5,88 · 4,72 · 3,96 · 2,74; Tiefs 0,39 · 0,56 · 0,69 · 0,75, dann rund 1,1).
2. **Kausal.** Jede Rang-, Z- oder Anpassungsreihe nutzt am Tag t nur Daten bis t. Der Selbsttest hängt extreme Zukunftsdaten an
   (× 50) und verlangt die Vergangenheit bitgleich (19 Reihen). Ausnahme mit Ansage: die Power-Law-Linie und ihre Bänder im Chart
   (Anpassung über alle Tage, beschreibend); das Perzentil daneben ist kausal (Anpassung je Monat bis zum Vormonat).
3. **Kein Gesamtwert.** Wer Perzentile mittelt, baut einen ungetesteten Composite; die geprüften Composites (CBBI, CoinGlass 30
   Signale) scheiterten an ihren Schwellen. Die Zonenkarte zeigt jeden Treiber einzeln.
4. **Makro nur als Kulisse.** Liquidität, Zinsen, Dollar mit rollierender Korrelation zur BTC-Wochenrendite und Zufallsband ±2/√n;
   kein verschobener M2-Lag (Lag wanderte 0–3 Monate, Vorzeichen seit 2023 gedreht).
5. **Eine Quelle je Reihe, Abrufe archiviert.** Freie Fenster verschwinden (BGeometrics 4 Jahre, FRED-Hochzinsspread 3 Jahre,
   Binance-REST 30 Tage); `makro.db` behält alles, der Tagesstand der Zonenkarte wird einmal je Tag festgeschrieben (`mk_stand`) —
   die eigene, revisionsfreie Bilanz außerhalb der Stichprobe.

## 2. Quellen (alle frei)

| Quelle | Reihen in makro.db | Abruf | Historie | Lizenz, Grenzen |
|---|---|---|---|---|
| Coin Metrics Community API v4 | `cm:<asset>:<Metrik>` — BTC: PriceUSD, CapMrktCurUSD, CapMVRVCur, SplyCur, HashRate (TH/s), IssTotNtv, IssTotUSD, FeeTotNtv, BlkCnt; ETH/ZEC: Preis, Marktkap., MVRV, Angebot; XMR: Preis, Marktkap., Angebot | alle 6 h, `paging_from=start`, `page_size=10000`; danach ab letztem Tag − 14 | BTC ab 18.07.2010 | CC BY-NC 4.0 (Namensnennung unter jedem Chart); Bewertungsfelder erst bei T−2 vollständig; Realized Cap nicht frei → RC = Marktkap. ÷ MVRV |
| FRED (fredgraph.csv, ohne Schlüssel) | `fred:<ID>` — WALCL, WTREGEN, RRPONTSYD, M2SL, DFII10, DTWEXBGS, BAMLH0A0HYM2, DFF, ECBASSETSW, JPNASSETS, DEXUSEU, DEXJPUS | alle 12 h; danach ab letztem Tag − 400 | ab 2008 (HY nur 3 Jahre) | HY-Spread: ICE-Daten, nur private Anzeige |
| alternative.me | `fng:wert` | alle 6 h (`limit=0`, danach 40) | ab 02/2018 | Quellenangabe direkt am Chart (Pflicht) |
| DefiLlama | `llama:stable_usd` (alle Bindungen in USD summiert) | alle 12 h (ganze Reihe) | ab 29.11.2017 | Zählweise des Anbieters |
| Blockchain.com Charts | `bc:difficulty`, `bc:hashrate` (Gegenprobe) | alle 12 bzw. 24 h | ab 2009 | — |
| Deribit | `drb:dvol_btc` (Tagesschluss) | alle 12 h, Seiten über `continuation` | ab 24.03.2021 | — |
| Binance Futures | `bnc:funding_btc_tag` (Tagessumme der Raten, nur abgeschlossene UTC-Tage), `bnc:oi_btc_usd`/`_coins` | Funding alle 8 h (ab 09/2019), OI-REST alle 12 h (30 Tage) | Funding ab 2019, OI ab 09/2020 über das Archiv | — |
| data.binance.vision | OI-Archiv: Tagesdateien ZIP/CSV, früheste Zeile des Tages (wie REST: Stand zu Tagesbeginn) | eine Datei je Takt (20 s) bis vor den ersten REST-Tag, dann fertig | ab 01.09.2020 | 404 zählt als fehlend |
| Farside | `fs:etf_btc`, `fs:etf_eth` (Mio USD je Tag) | alle 12 h (Gesamtseiten „…-etf-flow-all-data“) | ab 11.01.2024 | privat; Parser wie hl_ext |
| BGeometrics (bitcoin-data.com) | `bgm:<Endpunkt>:<Feld>` — sth-realized-price, true-market-mean, lth-realized-price, sth-mvrv, lth-sopr, asopr, aviv, realized-loss | je Endpunkt einmal am Tag, höchstens 7 je Stunde, 14 je Tag, 8 min Abstand (frei: 8/h, 15/Tag) | letzte 4 Jahre | nicht kommerziell; Feldnamen undokumentiert → jedes Zahlenfeld eine Reihe |

Nicht gebaut (nicht frei oder nicht belegt): 25-Delta-Skew (keine freie Historie), Treasury-mNAV (keine freie Schnittstelle),
alles aus Stufe 3 (Pi Cycle, Mayer > 2,4, 2-Jahres-MA × 5, Golden Ratio, Rainbow, Stock-to-Flow, Schwellen-Composites, M2 mit festem
Lag, NVT, Börsenbestände als Trend, selbst geschätzte Produktionskosten der ganzen Flotte).

## 3. Treiber, Rechnung, Selbsttest

| Treiber (Tab) | Rechnung | Positivkontrolle / Nulltest im Selbsttest |
|---|---|---|
| Realized Price, MVRV, NUPL (Bewertung) | RC = Marktkap. ÷ MVRV; RP = RC ÷ Angebot; NUPL = 1 − 1/MVRV; erste 180 Tage einer MVRV-Reihe verworfen (BTC: 146 am 18.07.2010) | Formeln exakt; MVRV 1 → NUPL 0; Anlauf NaN |
| MVRV-Perzentil (Bewertung) | Rang unter allen Werten bis heute (Gleichstände gemittelt), dazu 4-Jahres-Fenster | steigend 100, fallend 0, gleich 50; Rauschen gleichverteilt (Mittel 50 ± 3 SE, Zehntel); kausal |
| MVRV-Z (Bewertung) | (Marktkap. − RC) ÷ Streuung der Marktkap. bis heute (Population) | Handrechnung; MVRV 1 → Z 0 |
| Delta Price (Bewertung) | (RC − mittlere Marktkap. bis heute) ÷ Angebot | Handrechnung; kausal |
| Epochen-Hoch/-Tief, Bewertungsdivergenz (Bewertung) | Max./Min. von MVRV je Halving-Epoche; neues Kurshoch der Epoche bei MVRV ≥ 5 % unter dem bisherigen Epochenhoch (Hypothese, ungetestet) | Divergenz erkannt; MVRV ∝ Kurs → keine |
| Power Law (Trend) | log10(Kurs) = a + b · log10(Tage seit Genesis); je Monat kausal angepasst, Residuum, Lage in σ, Perzentil; Parameter je Monat in `mk_pl` | b = 5,8 gefunden (± 0,1); ohne Trend b ≈ 0; 4 σ → Perzentil > 99; kausal |
| 200-Wochen-MA (Trend, Coin wählbar) | 199 abgeschlossene Sonntagsschlüsse (UTC) + laufender Kurs, ÷ 200; Abstand und Perzentil | konstant = Kurs; Sonntag = Mittel der 200 Sonntage; Wochenmitte mit Tageskurs |
| Halving-Zyklen (Trend) | Kurs ÷ Kurs am Halving-Tag, Tag 0–1460 | Tag 534 am 06.10.2025; Halving-Tag zählt zur neuen Epoche |
| Kurzfrist-/Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV (z), realisierte Verluste (Kohorten) | Werte von BGeometrics; Regime = Kurs über/unter der Linie; AVIV-z expandierend | Parser (Feldnamen, ms, Text-Zahlen); AVIV-z: Ausreißer > 10, Rauschen ≈ 0 |
| Puell Multiple (Miner) | Emission USD ÷ 365-Tage-Mittel; Perzentil innerhalb der Halving-Epoche | gleiche Emission → 1; Halbierung → 0,5 |
| Hash Ribbons (Miner) | SMA30 < SMA60 der Hashrate = Kapitulation; Erholung beim Kreuz; Kaufsignal nach Capriole (Kurs-SMA10 > SMA20); **Rauschschwelle 3 σ/√60** (σ = Tagesrauschen der Hashrate, 365 Tage vor der Episode) | Rückgang 15 % echt, mit Erholung und Signal; reines Rauschen σ 8 %: 1,2 % der Episoden über der Schwelle (Simulation 0,7 %) |
| Difficulty Ribbon (Miner) | SMA 9, 14, 25, 40, 60, 90, 128, 200 der Difficulty; Breite = größtes ÷ kleinstes − 1 | konstant → Breite 0; Rückgang → Breite > 5 % |
| Miner-Kostenbasis (Miner, Überblick) | siehe Abschnitt 4 | Prüfwert 50.383 USD je BTC; linear in der Difficulty |
| Funding (Hebel) | Tagessumme der Raten × 365 (% p. a.), 30-Tage-Mittel, Perzentil | 3 × 0,01 % → 10,95 % p. a.; doppelte Zeitpunkte einmal; nur abgeschlossene Tage |
| Open Interest ÷ Marktkap. (Hebel) | OI Binance (USD, Tagesbeginn) ÷ BTC-Marktkap. | Parser REST und Archiv (früheste Zeile) |
| DVOL, Fear & Greed (30 T), Wochen-RSI 14 (Hebel) | Tagesschluss; 30-Tage-Mittel; RSI nach Wilder auf Sonntagsschlüssen | Wilders Rechenbeispiel exakt (70,53 · 66,32 · 66,55 …); steigend 100, fallend 0 |
| Stablecoins, SSR (Kapitalfluss) | Summe aller Bindungen; SSR = BTC-Marktkap. ÷ Stablecoins; Perzentil | Handrechnung |
| ETF-Nettoflüsse (Kapitalfluss) | kumuliert ab Start, Summe 30 Tage | Farside-Parser (Klammern, Tausenderkomma, „-“) |
| Makro (Makro) | Nettoliquidität = WALCL − WTREGEN − RRP × 1000 (Mio USD → Bio); globaler Proxy = Fed + EZB × EUR/USD + BoJ × 100 ÷ JPY/USD (Veränderung zum Vorjahr); M2 zum Vorjahr; Realzins, Dollar, HY-Spread, Leitzins; Korrelation der Wochenänderung mit der BTC-Wochenrendite über 52 Wochen (M2: Monate, 24) | gleich +1, gespiegelt −1; unabhängig 0 ± 1/√51; Regimelabel nennt Zufallsband und Vorzeichenwechsel |

## 4. Miner-Kostenbasis (Szenario, keine Messung)

Stromkosten je BTC = J/TH × Strompreis × (Difficulty × 2³² ÷ 10¹² TH je Block) ÷ 3,6 · 10⁶ J/kWh ÷ (Emission + Gebühren je Block).
Erlös je Block aus Coin Metrics als 7-Tage-Summen (IssTotNtv + FeeTotNtv) ÷ BlkCnt — über dieselben Tage. Der Server liefert die
„Einheit“ (USD je BTC für 1 J/TH und 1 USD/kWh); der Browser rechnet das Szenario, also ohne neuen Abruf umschaltbar:
- Ausgangsszenario des Nutzers: **Antminer S21 XP (Luft) 13,5 J/TH bei 7,5 ct/kWh**. Standard US-Cent; Euro-Cent wird mit dem
  Tageskurs EUR/USD (FRED DEXUSEU) umgerechnet. Geräteliste: S21 XP Hydro 12, S21 Pro 15, S21 17,5, S19 XP 21,5, S19j Pro 29,5 J/TH
  oder eigener Wert; Aufschlag für sonstige Kosten in % (0 = nur Strom).
- Chart: Kurs, Szenario, Band Strompreis ± 2,5 ct, ältere Flotte S19 XP (21,5 J/TH) gestrichelt; darunter Kurs ÷ Kosten.
- Prüfwert (Selbsttest): Difficulty 1,318 · 10¹⁴, Erlös 3,16 BTC je Block → Einheit 49.761 → 50.383 USD je BTC.
- Kein Perzentil: Ein fester Gerätetyp über die ganze Historie ist kein Vergleichsmaßstab (2011 kostete ein BTC mit heutiger Technik
  fast nichts).

## 5. Darstellung (Abschnitt „MK Makro“)

- Tabs Überblick, Bewertung, Trend, Kohorten, Miner, Hebel & Stimmung, Kapitalfluss, Makro, Daten (Quellen, Abrufe, Frische je
  Reihe); eine Filterzeile oben
  (Zeitraum 1 J / 2 J / 4 J / 8 J / Alles; Coin dort, wo es zählt); gemerkt im Browser (`hl_makro`).
- Überblick: Satz aus den Positionen (MVRV, Power Law, Regime STH/TMM, 200-Wochen-MA, Halving-Tag; „kein Timing-Signal“),
  Zonenkarte (Tagesschluss, „jetzt“ mit dem Live-Kurs aus `bars`, Lage als Perzentil, Bezug, Einordnung; auf dem Handy als Karten),
  Chart „Kurs und Kostenbasen“.
- Ein generischer SVG-Chart (`mkZeichne`): eine y-Achse je Chart (nie zwei), Legende ab zwei Reihen, Endbeschriftung nur bis vier
  Reihen und ab 520 px, Fadenkreuz mit allen Reihen am Tag, Tabellenansicht je Chart (Monatsenden), Quelle unter jedem Chart.
- Farben: acht Kategorien in fester Reihenfolge (`#3987e5 #d95926 #199e70 #c98500 #d55181 #008300 #9085e9 #e66767`), mit dem
  Prüfskript für die dunkle Fläche `#01030a` geprüft (Helligkeitsband, Chroma, Farbsehschwäche benachbart ΔE ≥ 8,4, normal ≥ 19,3,
  Kontrast ≥ 3:1). Kurs neutral; die Farbe folgt dem Treiber (Realized Price immer blau, 200-Wochen-MA orange …).

## 6. Speicher und Takt

- `makro.db` neben `hl_liq.db` (wie `forecasts.db`, `adressfluss.db`); `HL_MAKRO_DB` lenkt um (Selbsttest). Tabellen: `mk_reihe`
  (reihe, ts in Sekunden, wert, abgerufen; ohne rowid), `mk_abruf` (Protokoll, 90 Tage), `mk_meta` (Zustand je Ziel, Budget, Cursor,
  Datenversion), `mk_stand` (Tagesstand der Zonenkarte, einmal je Tag), `mk_pl` (Power-Law-Parameter je Monat, einmal).
- Schreiben nur im Makro-Takt (ein Thread im Dashboard, 90 s nach dem Start, dann alle 20 s fällige Ziele) und über
  `hl_makro.py --abrufen`; jede Transaktion `BEGIN IMMEDIATE`; gleiche Werte bleiben unberührt, Revisionen bekommen einen neuen
  Abrufzeitpunkt und erhöhen die Datenversion.
- Fehler je Ziel: Pause 15 min, verdoppelt bis 6 h; die anderen Ziele laufen weiter. Aus mit `HL_MAKRO=0`; nie für
  Selbsttest-Datenbanken (`_selftest*`).
- Dashboard: `/makro?tab=…&coin=…` (Zwischenspeicher je Datenversion, höchstens alle 10 min neu gerechnet, Einzelflug, Antwort-Cache
  60 s), `/makro.js`. Fehlt `makro.db`, kommt ein Hinweis — angelegt wird beim Lesen nichts.
- Sicherung: Der Recorder sichert `makro.db` mit dem täglichen Backup als `makro_backup.db` (plus eine Generation).
- **Frische je Reihe** (Abnahme U121): Alter des letzten Werts (heute UTC minus letzter Tag) gegen eine Grenze je Quelle — Coin
  Metrics 5 Tage (Bewertung erst bei T−2), alternative.me, DefiLlama, Deribit, Binance 4, Blockchain.com 5, BGeometrics 6, Farside 7
  (Wochenenden, Feiertage), FRED täglich 10, wöchentlich veröffentlicht (Wechselkurse, Dollar, Fed-Bilanz, TGA) 14, EZB 21, M2 und
  BoJ (monatlich, rund vier Wochen Verzug, auf den Monatsersten datiert) 100. Dazu „fehlt“: eine Reihe, die ein schon erfolgreich
  abgerufenes Ziel liefern müsste, aber nicht gibt (Metrik aus dem freien Katalog oder Feld verschwunden; vor dem ersten Erfolg
  kein Befund). Sichtbar im Tab „Daten“ (Spalten Alter und Grenze, Warnzeile) und im Stand (Debug, Wochenbericht W14). Grund: Wenn
  eine Metrik verschwindet oder eine Seite ihr Format ändert, scheitert oft kein Abruf — die Reihe bleibt nur stehen.

## 7. Proben (23.47)

- `python3 hl_makro.py --selbsttest`: 42 Prüfungen in rund 2 s (Mathematik je Treiber, Parser, Zeitplan mit falschem Netz und
  springender Uhr, Gesamtrechnung mit Kausalität, Nutzlast je Tab, Archiv, Frische und fehlende Reihen mit fester Uhr). Eigener
  Schritt im Installations-Selbsttest (nach dem Magnet-Test; der Selbsttest hat damit 31 Schritte).
- Mutationen: 27 von 27 rot (u. a. Blick nach vorn im Power Law, Realized Price ohne MVRV, 200 statt 199 Wochen, Funding × 3,
  angefangener Tag, RSI-Glättung, Rauschschwelle 1, Budget 8/h, Fehler ohne Pause, Erstabruf ohne Historie; Frische: Grenze nie
  erreicht, Monatswerte ohne eigene Grenze, Alter vom ersten Tag, Fehlen vor dem ersten Abruf).
- Rückrechnung mit echten Coin-Metrics-Daten (öffentlicher GitHub-Spiegel bis 24.05.2026) gegen den Bericht: 06.10.2025 MVRV 2,287,
  Realized Price 54.576,53 USD, MVRV-Z 2,53, Puell 1,07; 11.03.2024 MVRV 2,776, Puell 2,43; 21.11.2022 MVRV 0,778, Realized Price
  20.290,85; Epochen-Hochs 7,74 · 5,88 · 4,72 · 3,96 · 2,74, Tiefs 0,39 · 0,56 · 0,69 · 0,75; Power-Law-Exponent über alle Tage 5,674
  (Perrenod 5,674), Anpassung bis 09/2019 5,822 (Burger 5,845); Kurs ÷ Fair Value (Burger) am ATH 0,949. Hash Ribbons über der
  Rauschschwelle seit 2017: 11/2018, 03/2020, 05/2020, 10/2020, 06/2021 (−19,3 %), 07/2022, 11/2022, 01–02/2026 mit Kaufsignal
  05.03.2026 (Recherche: CoinDesk 25.02.2026), 03–05/2026.
- Sichtprüfung aller Tabs in Desktop- und Handybreite (Playwright), keine Skriptfehler, keine waagrechte Seitenbreite über den Rand;
  Fadenkreuz-Tooltip in Überblick, Miner und Makro geprüft; Tab „Daten“ mit Warnzeile und den Spalten Alter/Grenze direkt neben
  dem Reihennamen (am Handy ohne Seitwärtsschieben sichtbar).

## 8. Grenzen und offene Punkte

- **Formate auf dem Pi erst nach dem ersten Abruf belegt** (die Sandbox erreicht die Quellen nicht): Coin Metrics, FRED,
  alternative.me, DefiLlama und Deribit sind gegen am 05.10. gelesene Antworten geprüft; offen sind die Feldnamen von BGeometrics
  (deshalb jedes Zahlenfeld), die Farside-Gesamtseiten, data.binance.vision und die Erreichbarkeit von Binance-Futures-Daten vom Pi.
  Bericht `u121-makro-erstlauf` am 06.10. 20:15 (Debug „Makro: Stand und Quellen“).
- BGeometrics liefert frei nur 4 Jahre; seine Werte weichen methodisch von Glassnode ab (Entitäten, Börsen-Etiketten).
- Power Law ist eine Beschreibung, kein Gesetz: Exponent driftete 5,845 → 5,674; die Oberseite schrumpft (Top 2025 bei ~1× Fair
  Value), die Unterseite lag bisher bei 0,34–0,51×.
- Perzentile über die ganze Historie gegenüber 4-Jahres-Fenster oder 2-Jahres-σ: welches besser trifft, ist außerhalb der
  Stichprobe ungeprüft — deshalb beide (MVRV) bzw. das kausale Gesamtperzentil.
- Halving-Overlay und Bewertungsdivergenz sind Zeitachse bzw. Hypothese, kein Fahrplan.
- `migrate_db.py` verschiebt `makro.db` nicht mit (wie `adressfluss.db`); nach einem Umzug von Hand mitnehmen.
- Frische-Grenzen sind aus Veröffentlichungsrhythmen abgeleitet, nicht gemessen. Ein Fehlalarm ist nur eine Warnzeile; nach vier
  Wochen Betrieb gegen die echten Abstände prüfen (U123).
