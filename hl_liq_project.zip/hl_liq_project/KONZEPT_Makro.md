# KONZEPT Makro-Chart (U121) — Lage im mittel- und langfristigen Zyklus

Stand 11.10.2026: Abschnitt 11 neu (Arbeitsmarkt und Preise der USA, Datentage; entschieden, Bau mit 23.67). Davor Stand 05.10.2026, Version 2026-09-23.54 (Opus 5.5; erstellt mit 23.47, Signale seit 23.49 in Abschnitt 9, OI-Archiv rückwärts seit 23.50, kleine Charts im Überblick seit 23.51, Plan U130 in Abschnitt 10, Teil A gebaut seit 23.52, Kursleiste seit 23.54 in Abschnitt 5). Grundlage: `RECHERCHE_Makro_Chart_05-10-2026.md` (Bericht „Kostenbasis verortet den
Zyklus, feste Schwellen versagen“). Wunsch des Nutzers (05.10.): alles Kostenlose aus Stufe 1 und 2 einbauen, jeden Treiber mit
eigenem Chart, dazu die Miner-Kostenbasis (Ausgangsszenario Antminer S21 XP bei 7,5 ct/kWh); eigene Datenbank `makro.db`.

Code: `hl_makro.py` (Abruf, Rechnung, Nutzlast, Selbsttest), `hl_makro_signal.py` (Signale je Chart, seit 23.49),
`hl_makro_js.py` (Skript des Abschnitts, `/makro.js`),
Abschnitt „MK Makro“ in `hl_viz.py`. Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein API-Gewicht.

## 1. Regeln (aus dem Bericht, fest eingebaut)

1. **Positionen statt Signale.** Bänder im Kurschart (Realized Price, 200-Wochen-MA, Power-Law-Fair-Value, Kurzfrist-Kostenbasis,
   Stromkosten eines Miners) und Perzentile der eigenen Historie. Keine festen Schwellen aus 2013–2021 (MVRV 3,7/1, MVRV-Z 7/0,
   NUPL 0,75/0, Puell 4/0,5, LTH-SOPR 10/0,6, Pi Cycle …): 2025/26 oben und unten verfehlt, weil die Ausschläge seit 2011 schrumpfen
   (MVRV-Hochs je Halving-Epoche 7,74 · 5,88 · 4,72 · 3,96 · 2,74; Tiefs 0,39 · 0,56 · 0,69 · 0,75, dann rund 1,1).
   Seit 23.49 auf Wunsch des Nutzers zusätzlich Kauf- und Verkaufszonen je Chart (Abschnitt 9): relativ zum gewählten Zeitraum
   (unterstes/oberstes Zehntel), nicht feste Schwellen, und immer mit ihrer Bilanz gegen Zufall — auf echten Daten bisher ohne Beleg.
2. **Kausal.** Jede Rang-, Z- oder Anpassungsreihe nutzt am Tag t nur Daten bis t. Der Selbsttest hängt extreme Zukunftsdaten an
   (× 50) und verlangt die Vergangenheit bitgleich (19 Reihen). Ausnahme mit Ansage: die Power-Law-Linie und ihre Bänder im Chart
   (Anpassung über alle Tage, beschreibend); das Perzentil daneben ist kausal (Anpassung je Monat bis zum Vormonat).
3. **Kein Gesamtwert.** Wer Perzentile mittelt, baut einen ungetesteten Composite; die geprüften Composites (CBBI, CoinGlass 30
   Signale) scheiterten an ihren Schwellen. Die Zonenkarte zeigt jeden Treiber einzeln.
4. **Makro nur als Kulisse.** Liquidität, Zinsen, Dollar mit rollierender Korrelation zur BTC-Wochenrendite und Zufallsband ±2/√n;
   kein verschobener M2-Lag (Lag wanderte 0–3 Monate, Vorzeichen seit 2023 gedreht).
5. **Eine Quelle je Reihe, Abrufe archiviert.** Freie Fenster verschwinden (BGeometrics 4 Jahre, FRED-Hochzinsspread 3 Jahre,
   Binance-REST 30 Tage); `makro.db` behält alles, der Tagesstand der Zonenkarte wird einmal je Tag festgeschrieben (`mk_stand`) —
   die eigene, revisionsfreie Bilanz außerhalb der Stichprobe.

## 2. Quellen (alle frei)

| Quelle | Reihen in makro.db | Abruf | Historie | Lizenz, Grenzen |
|---|---|---|---|---|
| Coin Metrics Community API v4 | `cm:<asset>:<Metrik>` — BTC: PriceUSD, CapMrktCurUSD, CapMVRVCur, SplyCur, HashRate (TH/s), IssTotNtv, IssTotUSD, FeeTotNtv, BlkCnt; ETH/ZEC: Preis, Marktkap., MVRV, Angebot; XMR: Preis, Marktkap., Angebot | alle 6 h, `paging_from=start`, `page_size=10000`; danach ab letztem Tag − 14 | BTC ab 18.07.2010 | CC BY-NC 4.0 (Namensnennung unter jedem Chart); Bewertungsfelder erst bei T−2 vollständig; Realized Cap nicht frei → RC = Marktkap. ÷ MVRV |
| FRED (seit 23.48: offizielle API `api.stlouisfed.org` mit kostenlosem Schlüssel; ohne Schlüssel `fredgraph.csv`, das seit Mitte August 2026 vielerorts nicht antwortet) | `fred:<ID>` — WALCL, WTREGEN, RRPONTSYD, M2SL, DFII10, DTWEXBGS, BAMLH0A0HYM2, DFF, ECBASSETSW, JPNASSETS, DEXUSEU, DEXJPUS | alle 12 h; danach ab letztem Tag − 400; Wartezeit 20 s (API) bzw. 15 s (CSV) | ab 2008 (HY nur 3 Jahre) | HY-Spread: ICE-Daten, nur private Anzeige; Schlüssel in `accesstokens.json` → "fred" oder `FRED_API_KEY` |
| alternative.me | `fng:wert` | alle 6 h (`limit=0`, danach 40) | ab 02/2018 | Quellenangabe direkt am Chart (Pflicht) |
| DefiLlama | `llama:stable_usd` (alle Bindungen in USD summiert) | alle 12 h (ganze Reihe) | ab 29.11.2017 | Zählweise des Anbieters |
| Blockchain.com Charts | `bc:difficulty`, `bc:hashrate` (Gegenprobe) | alle 12 bzw. 24 h | ab 2009 | — |
| Deribit | `drb:dvol_btc` (Tagesschluss) | alle 12 h, Seiten über `continuation` | ab 24.03.2021 | — |
| Binance Futures | `bnc:funding_btc_tag` (Tagessumme der Raten, nur abgeschlossene UTC-Tage), `bnc:oi_btc_usd`/`_coins` | Funding alle 8 h (ab 09/2019), OI-REST alle 12 h (30 Tage) | Funding ab 2019, OI ab 09/2020 über das Archiv | — |
| data.binance.vision | OI-Archiv: Tagesdateien ZIP/CSV, früheste Zeile des Tages (wie REST: Stand zu Tagesbeginn) | eine Datei je Takt (20 s), seit 23.50 RÜCKWÄRTS vom Tag vor den REST-Daten bis 01.09.2020 (jüngste zuerst; vorhandene Tage übersprungen), dann fertig | ab 01.09.2020 | 404 zählt als fehlend; solange es lädt: Hinweis unter dem OI-Chart, kein OI-Perzentil in der Zonenkarte (U128) |
| Farside | `fs:etf_btc`, `fs:etf_eth` (Mio USD je Tag) | alle 12 h (Gesamtseiten „…-etf-flow-all-data“) | ab 11.01.2024 | privat; Parser wie hl_ext |
| BGeometrics (bitcoin-data.com) | `bgm:<Endpunkt>:<Feld>` — sth-realized-price, true-market-mean, lth-realized-price, sth-mvrv, lth-sopr, asopr, aviv, realized-loss | je Endpunkt einmal am Tag, höchstens 7 je Stunde, 14 je Tag, 8 min Abstand (frei: 8/h, 15/Tag) | letzte 4 Jahre, **ohne die jüngsten 7 Tage** (frei verzögert, am 05.10. belegt) | nicht kommerziell; Feldnamen undokumentiert → jedes Zahlenfeld eine Reihe (auf dem Pi: sthRealizedPrice, trueMarketMean, lthRealizedPrice) |

Nicht gebaut (nicht frei oder nicht belegt): 25-Delta-Skew (keine freie Historie), Treasury-mNAV (keine freie Schnittstelle),
alles aus Stufe 3 (Pi Cycle, Mayer > 2,4, 2-Jahres-MA × 5, Golden Ratio, Rainbow, Stock-to-Flow, Schwellen-Composites, M2 mit festem
Lag, NVT, Börsenbestände als Trend, selbst geschätzte Produktionskosten der ganzen Flotte).

## 3. Treiber, Rechnung, Selbsttest

| Treiber (Tab) | Rechnung | Positivkontrolle / Nulltest im Selbsttest |
|---|---|---|
| Realized Price, MVRV, NUPL (Bewertung) | RC = Marktkap. ÷ MVRV; RP = RC ÷ Angebot; NUPL = 1 − 1/MVRV; erste 180 Tage einer MVRV-Reihe verworfen (BTC: 146 am 18.07.2010) | Formeln exakt; MVRV 1 → NUPL 0; Anlauf NaN |
| MVRV-Perzentil (Bewertung) | Rang unter allen Werten bis heute (Gleichstände gemittelt), dazu 4-Jahres-Fenster | steigend 100, fallend 0, gleich 50; Rauschen gleichverteilt (Mittel 50 ± 3 SE, Zehntel); kausal |
| MVRV-Z (Bewertung) | (Marktkap. − RC) ÷ Streuung der Marktkap. bis heute (Population) | Handrechnung; MVRV 1 → Z 0 |
| Delta Price (Bewertung) | (RC − mittlere Marktkap. bis heute) ÷ Angebot | Handrechnung; kausal |
| Epochen-Hoch/-Tief, Bewertungsdivergenz (Bewertung) | Max./Min. von MVRV je Halving-Epoche; neues Kurshoch der Epoche bei MVRV ≥ 5 % unter dem bisherigen Epochenhoch (Hypothese, ungetestet) | Divergenz erkannt; MVRV ∝ Kurs → keine |
| Power Law (Trend) | log10(Kurs) = a + b · log10(Tage seit Genesis); je Monat kausal angepasst, Residuum, Lage in σ, Perzentil; Parameter je Monat in `mk_pl` | b = 5,8 gefunden (± 0,1); ohne Trend b ≈ 0; 4 σ → Perzentil > 99; kausal |
| 200-Wochen-MA (Trend, Coin wählbar) | 199 abgeschlossene Sonntagsschlüsse (UTC) + laufender Kurs, ÷ 200; Abstand und Perzentil | konstant = Kurs; Sonntag = Mittel der 200 Sonntage; Wochenmitte mit Tageskurs |
| Halving-Zyklen (Trend) | Kurs ÷ Kurs am Halving-Tag, Tag 0–1460 | Tag 534 am 06.10.2025; Halving-Tag zählt zur neuen Epoche |
| Kurzfrist-/Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV (z), realisierte Verluste (Kohorten) | Werte von BGeometrics; Regime = Kurs über/unter der Linie; AVIV-z expandierend | Parser (Feldnamen, ms, Text-Zahlen); AVIV-z: Ausreißer > 10, Rauschen ≈ 0 |
| Puell Multiple (Miner) | Emission USD ÷ 365-Tage-Mittel; Perzentil innerhalb der Halving-Epoche | gleiche Emission → 1; Halbierung → 0,5 |
| Hash Ribbons (Miner) | SMA30 < SMA60 der Hashrate = Kapitulation; Erholung beim Kreuz; Kaufsignal nach Capriole (Kurs-SMA10 > SMA20); **Rauschschwelle 3 σ/√60** (σ = Tagesrauschen der Hashrate, 365 Tage vor der Episode) | Rückgang 15 % echt, mit Erholung und Signal; reines Rauschen σ 8 %: 1,2 % der Episoden über der Schwelle (Simulation 0,7 %) |
| Difficulty Ribbon (Miner) | SMA 9, 14, 25, 40, 60, 90, 128, 200 der Difficulty; Breite = größtes ÷ kleinstes − 1 | konstant → Breite 0; Rückgang → Breite > 5 % |
| Miner-Kostenbasis (Miner, Überblick) | siehe Abschnitt 4 | Prüfwert 50.383 USD je BTC; linear in der Difficulty |
| Funding (Hebel) | Tagessumme der Raten × 365 (% p. a.), 30-Tage-Mittel, Perzentil | 3 × 0,01 % → 10,95 % p. a.; doppelte Zeitpunkte einmal; nur abgeschlossene Tage |
| Open Interest ÷ Marktkap. (Hebel) | OI Binance (USD, Tagesbeginn) ÷ BTC-Marktkap. | Parser REST und Archiv (früheste Zeile) |
| DVOL, Fear & Greed (30 T), Wochen-RSI 14 (Hebel) | Tagesschluss; 30-Tage-Mittel; RSI nach Wilder auf Sonntagsschlüssen | Wilders Rechenbeispiel exakt (70,53 · 66,32 · 66,55 …); steigend 100, fallend 0 |
| Stablecoins, SSR (Kapitalfluss) | Summe aller Bindungen; SSR = BTC-Marktkap. ÷ Stablecoins; Perzentil | Handrechnung |
| ETF-Nettoflüsse (Kapitalfluss) | kumuliert ab Start, Summe 30 Tage | Farside-Parser (Klammern, Tausenderkomma, „-“) |
| Makro (Makro) | Nettoliquidität = WALCL − WTREGEN − RRP × 1000 (Mio USD → Bio); globaler Proxy = Fed + EZB × EUR/USD + BoJ × 100 ÷ JPY/USD (Veränderung zum Vorjahr); M2 zum Vorjahr; Realzins, Dollar, HY-Spread, Leitzins; Korrelation der Wochenänderung mit der BTC-Wochenrendite über 52 Wochen (M2: Monate, 24) | gleich +1, gespiegelt −1; unabhängig 0 ± 1/√51; Regimelabel nennt Zufallsband und Vorzeichenwechsel |

## 4. Miner-Kostenbasis (Szenario, keine Messung)

Stromkosten je BTC = J/TH × Strompreis × (Difficulty × 2³² ÷ 10¹² TH je Block) ÷ 3,6 · 10⁶ J/kWh ÷ (Emission + Gebühren je Block).
Erlös je Block aus Coin Metrics als 7-Tage-Summen (IssTotNtv + FeeTotNtv) ÷ BlkCnt — über dieselben Tage. Der Server liefert die
„Einheit“ (USD je BTC für 1 J/TH und 1 USD/kWh); der Browser rechnet das Szenario, also ohne neuen Abruf umschaltbar:
- Ausgangsszenario des Nutzers: **Antminer S21 XP (Luft) 13,5 J/TH bei 7,5 ct/kWh**. Standard US-Cent; Euro-Cent wird mit dem
  Tageskurs EUR/USD (FRED DEXUSEU) umgerechnet. Geräteliste: S21 XP Hydro 12, S21 Pro 15, S21 17,5, S19 XP 21,5, S19j Pro 29,5 J/TH
  oder eigener Wert; Aufschlag für sonstige Kosten in % (0 = nur Strom).
- Chart: Kurs, Szenario, Band Strompreis ± 2,5 ct, ältere Flotte S19 XP (21,5 J/TH) gestrichelt; darunter Kurs ÷ Kosten.
- Prüfwert (Selbsttest): Difficulty 1,318 · 10¹⁴, Erlös 3,16 BTC je Block → Einheit 49.761 → 50.383 USD je BTC.
- Kein Perzentil: Ein fester Gerätetyp über die ganze Historie ist kein Vergleichsmaßstab (2011 kostete ein BTC mit heutiger Technik
  fast nichts).

## 5. Darstellung (Abschnitt „MK Makro“)

- Tabs Überblick, Bewertung, Trend, Kohorten, Miner, Hebel & Stimmung, Kapitalfluss, Makro, Daten (Quellen, Abrufe, Frische je
  Reihe); eine Filterzeile oben
  (Zeitraum 1 J / 2 J / 4 J / 8 J / Alles; Coin dort, wo es zählt); gemerkt im Browser (`hl_makro`).
- Überblick: Satz aus den Positionen (MVRV, Power Law, Regime STH/TMM, 200-Wochen-MA, Halving-Tag; „kein Timing-Signal“),
  Zonenkarte (Tagesschluss, „jetzt“ mit dem Live-Kurs aus `bars`, Lage als Perzentil, Bezug, Einordnung; auf dem Handy als Karten),
  Chart „Kurs und Kostenbasen“. Seit 23.51 darunter „Verlauf je Indikator“: kleine Vielfache, je Zeile der Zonenkarte ein Chart
  (ohne Halving), eine Reihe, eigene Skala, Bezugslinie, Punkt auf dem letzten Tagesschluss, gleicher Zeitraum wie die Filterzeile.
  Nutzlast `mini` (`mini_reihen`): jüngste 730 Tage täglich, davor jeder 7. Tag (echte Tageswerte, kein Mittel), Lücken als `null`
  (die Linie bricht ab), Miner nur 4 Jahre; `mini_zonen` mit den echten Kapitulationen der Hash Ribbons. Probe: jeder Punkt gleich
  dem Wert der Reihe hinter der Zeile, letzter Punkt gleich der Zahl der Tabelle.
- Ein generischer SVG-Chart (`mkZeichne`): eine y-Achse je Feld (nie zwei in einem Feld), Legende ab zwei Reihen, Endbeschriftung
  nur bis vier Reihen und ab 520 px, Fadenkreuz mit allen Reihen am Tag, Tabellenansicht je Chart (Monatsenden), Quelle unter jedem
  Chart.
- **Kursleiste (seit 23.54, U132; Wunsch des Nutzers 05.10. 22:21: Makro-Charts mit dem BTC-Kurs in Orange überlagern, um
  Korrelationen zu erkennen).** Unter jedem Kennzahl-Chart ein eigenes Feld im selben SVG: Kurs mit eigener log. Skala (höchstens
  drei Beschriftungen), dieselbe Zeitachse, gemeinsames Fadenkreuz; Tooltip und Tabelle nennen den Kurs am selben Tag.
  - Warum keine zweite y-Achse im selben Feld: Ihr Bereich ist frei wählbar, mit passender Wahl laufen fast beliebige zwei Reihen
    im Bild gleich. Getrennte Felder auf gemeinsamer Zeitachse zeigen Gleichlauf, Vorlauf und Wendepunkte, ohne dass die
    Skalenwahl sie erzeugt.
  - Zeitraum nur aus den eigenen Reihen des Charts; der Kurs verlängert die Achse nie (Signal-Charts mit Prognoseteil: die Leiste
    endet am letzten Kurstag).
  - Kurs der Münze: In Bewertung und Trend mit anderem Coin zeigen dessen Charts dessen Kurs („Kurs ETH“); sonst BTC.
  - Keine Leiste: Charts, die den Kurs selbst als Linie zeigen, „Halving-Zyklen übereinander“ (Zeitachse in Tagen), die
    Korrelationscharts im Tab Makro.
  - Schalter „BTC-Kurs“ (Standard an, gemerkt in `hl_makro`). Höhe der Leiste 28 % der Charthöhe, mindestens 46 px, 8 px Abstand.
  - Nutzlast: Jeder Chart-Tab trägt den Kurs als `r.P` (Hebel, Kapitalfluss und Makro neu, je +41,9 kB roh).
  - Hinweis im Überblick: Gleichlauf im Bild ist kein Beleg. Kennzahlen aus dem Kurs (MVRV, Puell, Abstand zum 200-Wochen-MA …)
    laufen mechanisch mit ihm; ob eine Kennzahl die künftige Rendite vorhersagt, misst Abschnitt 10 (U130).
- Farben: acht Kategorien in fester Reihenfolge (`#3987e5 #d95926 #199e70 #c98500 #d55181 #008300 #9085e9 #e66767`), mit dem
  Prüfskript für die dunkle Fläche `#01030a` geprüft (Helligkeitsband, Chroma, Farbsehschwäche benachbart ΔE ≥ 8,4, normal ≥ 19,3,
  Kontrast ≥ 3:1). Kurs neutral (hellgrau `#c9d1d9`) in Charts, die ihn als Linie zeigen; die Farbe folgt dem Treiber (Realized
  Price immer blau, 200-Wochen-MA orange …). Ausnahme Kursleiste: BTC-Orange `#f7931a` auf Wunsch des Nutzers. Es liegt außerhalb
  des Helligkeitsbands und nahe an `#d95926` (ΔE 14,6) und `#c98500` (ΔE 9,0) und steht deshalb nur im eigenen Feld, nie in
  derselben Fläche wie diese Farben, immer mit der Beschriftung „Kurs BTC · log. Skala“.

## 6. Speicher und Takt

- `makro.db` neben `hl_liq.db` (wie `forecasts.db`, `adressfluss.db`); `HL_MAKRO_DB` lenkt um (Selbsttest). Tabellen: `mk_reihe`
  (reihe, ts in Sekunden, wert, abgerufen; ohne rowid), `mk_abruf` (Protokoll, 90 Tage), `mk_meta` (Zustand je Ziel, Budget, Cursor,
  Datenversion), `mk_stand` (Tagesstand der Zonenkarte, einmal je Tag), `mk_pl` (Power-Law-Parameter je Monat, einmal),
  `mk_signal` (seit 23.49: Tagesstand der Signale je Paar und Zeitraum, einmal je Tag, nie überschrieben).
- Schreiben nur im Makro-Takt (ein Thread im Dashboard, 90 s nach dem Start, dann alle 20 s fällige Ziele) und über
  `hl_makro.py --abrufen`; jede Transaktion `BEGIN IMMEDIATE`; gleiche Werte bleiben unberührt, Revisionen bekommen einen neuen
  Abrufzeitpunkt und erhöhen die Datenversion.
- Fehler je Ziel: Pause 15 min, verdoppelt bis 6 h; die anderen Ziele laufen weiter. Seit 23.48: Antwortet ein Host nicht
  (Zeitüberschreitung, Verbindungsfehler), überspringt die Runde die übrigen Ziele dieser Quelle, und sie pausieren mit; HTTP-Fehler
  einer Reihe sperren nichts. Aus mit `HL_MAKRO=0`; nie für Selbsttest-Datenbanken (`_selftest*`).
- FRED-Schlüssel (23.48): Feld im Tab „Daten“ (POST `/makro/fred_schluessel`) oder `--fred-schluessel`; Format 32 Zeichen a–z0–9,
  Probeabruf vor dem Speichern, abgelehnte Schlüssel werden nicht geschrieben, die FRED-Pausen werden zurückgesetzt. Der Schlüssel
  erscheint nie in Fehlertexten, Protokoll, Antwort oder Adresse.
- Dashboard: `/makro?tab=…&coin=…` (Zwischenspeicher je Datenversion, höchstens alle 10 min neu gerechnet, Einzelflug, Antwort-Cache
  60 s), `/makro.js`. Fehlt `makro.db`, kommt ein Hinweis — angelegt wird beim Lesen nichts.
- Sicherung: Der Recorder sichert `makro.db` mit dem täglichen Backup als `makro_backup.db` (plus eine Generation).
- **Frische je Reihe** (Abnahme U121): Alter des letzten Werts (heute UTC minus letzter Tag) gegen eine Grenze je Quelle — Coin
  Metrics 5 Tage (Bewertung erst bei T−2), alternative.me, DefiLlama, Deribit, Binance 4, Blockchain.com 5, BGeometrics 9 (frei
  7 Tage Verzug; bis 23.47 fälschlich 6), Farside 7
  (Wochenenden, Feiertage), FRED täglich 10, wöchentlich veröffentlicht (Wechselkurse, Dollar, Fed-Bilanz, TGA) 14, EZB 21, M2 und
  BoJ (monatlich, rund vier Wochen Verzug, auf den Monatsersten datiert) 100. Dazu „fehlt“: eine Reihe, die ein schon erfolgreich
  abgerufenes Ziel liefern müsste, aber nicht gibt (Metrik aus dem freien Katalog oder Feld verschwunden; vor dem ersten Erfolg
  kein Befund). Sichtbar im Tab „Daten“ (Spalten Alter und Grenze, Warnzeile) und im Stand (Debug, Wochenbericht W14). Grund: Wenn
  eine Metrik verschwindet oder eine Seite ihr Format ändert, scheitert oft kein Abruf — die Reihe bleibt nur stehen.

## 7. Proben (23.47)

- `python3 hl_makro.py --selbsttest`: 49 Prüfungen in rund 3 s (Mathematik je Treiber, Parser, Zeitplan mit falschem Netz und
  springender Uhr, Gesamtrechnung mit Kausalität, Nutzlast je Tab, Archiv, Frische und fehlende Reihen mit fester Uhr; seit 23.48
  FRED über API, Schlüssel geschwärzt, Abbruch je Quelle, Einrichten des Schlüssels). Eigener
  Schritt im Installations-Selbsttest (nach dem Magnet-Test; der Selbsttest hat damit 31 Schritte).
- Mutationen: 37 von 37 rot (u. a. Blick nach vorn im Power Law, Realized Price ohne MVRV, 200 statt 199 Wochen, Funding × 3,
  angefangener Tag, RSI-Glättung, Rauschschwelle 1, Budget 8/h, Fehler ohne Pause, Erstabruf ohne Historie; Frische: Grenze nie
  erreicht, Monatswerte ohne eigene Grenze, Alter vom ersten Tag, Fehlen vor dem ersten Abruf; 23.48: Schlüssel ignoriert, nichts
  geschwärzt, kein Abbruch je Quelle, Übersprungene ohne Pause, HTTP-Antwort als Netzfehler, Umgebung ignoriert, Format nicht
  geprüft, Abgelehntes geschrieben, Pausen nicht zurück, BGeometrics-Grenze 6).
- Rückrechnung mit echten Coin-Metrics-Daten (öffentlicher GitHub-Spiegel bis 24.05.2026) gegen den Bericht: 06.10.2025 MVRV 2,287,
  Realized Price 54.576,53 USD, MVRV-Z 2,53, Puell 1,07; 11.03.2024 MVRV 2,776, Puell 2,43; 21.11.2022 MVRV 0,778, Realized Price
  20.290,85; Epochen-Hochs 7,74 · 5,88 · 4,72 · 3,96 · 2,74, Tiefs 0,39 · 0,56 · 0,69 · 0,75; Power-Law-Exponent über alle Tage 5,674
  (Perrenod 5,674), Anpassung bis 09/2019 5,822 (Burger 5,845); Kurs ÷ Fair Value (Burger) am ATH 0,949. Hash Ribbons über der
  Rauschschwelle seit 2017: 11/2018, 03/2020, 05/2020, 10/2020, 06/2021 (−19,3 %), 07/2022, 11/2022, 01–02/2026 mit Kaufsignal
  05.03.2026 (Recherche: CoinDesk 25.02.2026), 03–05/2026.
- Sichtprüfung aller Tabs in Desktop- und Handybreite (Playwright), keine Skriptfehler, keine waagrechte Seitenbreite über den Rand;
  Fadenkreuz-Tooltip in Überblick, Miner und Makro geprüft; Tab „Daten“ mit Warnzeile und den Spalten Alter/Grenze direkt neben
  dem Reihennamen (am Handy ohne Seitwärtsschieben sichtbar).

- 23.49 (Signale): `python3 hl_makro_signal.py --selbsttest` 12 Prüfungen in rund 3 s; `hl_makro.py --selbsttest` jetzt 52 (neu:
  Signale je Tab, Kausalität der ganzen Kette, Live gegen Nachrechnung mit echter Ableitung). Einzelheiten in Abschnitt 9.
- 23.54 (Kursleiste): `hl_makro.py --selbsttest` jetzt 55 Prüfungen, rund 10 s; neu „Kursleiste“: jede Nutzlast eines Chart-Tabs
  trägt den Kurs, jeder Punkt und jede Lücke gleich der Ableitung am selben Tag, Anfang und Ende eingeschlossen (BTC in 8 Tabs,
  Bewertung und Trend mit ETH). Mutationen 6 von 7 rot; grün blieb „Lücken gefüllt“, wirkungslos auf den lückenlosen Testkurs.
  Browserprobe (Playwright, Desktop und Handy) gegen Quellen außerhalb des JS-Codes: an 54 Fadenkreuz-Stellen Tooltip-Kurs =
  Rohwert in `makro.db`, Pfadhöhe = Rohkurs auf der beschrifteten log. Skala (≤ 0,6 px); Schalter, Tabelle, Breite; Browser-
  Mutationen 8 von 8 rot.

## 8. Grenzen und offene Punkte

- **Erster Pi-Lauf 05.10. (Bild 12:14):** Coin Metrics, alternative.me, DefiLlama, Blockchain.com, Deribit, Binance (Funding, OI,
  Archiv), Farside und BGeometrics liefern; ihre Formate sind belegt. FRED ohne Schlüssel hängt (→ API mit Schlüssel, 23.48); ob
  `api.stlouisfed.org` vom Pi antwortet, zeigt erst der eingetragene Schlüssel. Bericht `u121-makro-erstlauf` am 06.10. 20:15
  (Debug „Makro: Stand und Quellen“).
- BGeometrics liefert frei nur 4 Jahre und ohne die jüngsten 7 Tage; die Regimezeile vergleicht deshalb den Live-Kurs mit einer
  7 Tage alten Linie. Seine Werte weichen methodisch von Glassnode ab (Entitäten, Börsen-Etiketten).
- Power Law ist eine Beschreibung, kein Gesetz: Exponent driftete 5,845 → 5,674; die Oberseite schrumpft (Top 2025 bei ~1× Fair
  Value), die Unterseite lag bisher bei 0,34–0,51×.
- Perzentile über die ganze Historie gegenüber 4-Jahres-Fenster oder 2-Jahres-σ: welches besser trifft, ist außerhalb der
  Stichprobe ungeprüft — deshalb beide (MVRV) bzw. das kausale Gesamtperzentil.
- Halving-Overlay und Bewertungsdivergenz sind Zeitachse bzw. Hypothese, kein Fahrplan.
- `migrate_db.py` verschiebt `makro.db` nicht mit (wie `adressfluss.db`); nach einem Umzug von Hand mitnehmen.
- Frische-Grenzen sind aus Veröffentlichungsrhythmen abgeleitet, nicht gemessen. Ein Fehlalarm ist nur eine Warnzeile; nach vier
  Wochen Betrieb gegen die echten Abstände prüfen (U123).
- Signale (Abschnitt 9): Die Bilanz ist nachgerechnet; ob sie dem Live-Stand entspricht, zeigt erst das Archiv `mk_signal` auf dem Pi
  (U127). Rechenzeit auf dem Pi nicht gemessen (Sandbox 4 s).

## 9. Signale je Chart (U126, seit 23.49)

Wunsch des Nutzers (05.10. 13:59): je Chart die Abweichung zur Referenzlinie in %, ideale Kauf- und Verkaufspunkte je Zeitskala,
den „optimalen Median“ und einen extrapolierten Wert; für alle Charts, täglich. Entscheidungen auf Rückfrage: alle Charts mit
Referenzlinie; Rückblick und Live getrennt; Median der Abweichung; Rückkehr zum Median, 3/6/12 Monate mit 80-%-Band.

**9.1 Paare.** 14 Reihen gegen ihre Referenzlinie, je Zeitraum 1 J, 2 J, 4 J, 8 J und alles (nur bei Historie ≥ 90 % des Zeitraums):

| Tab | Paar | Referenz fortgeschrieben mit |
|---|---|---|
| Bewertung | Kurs gegen Realized Price (BTC, ETH, ZEC); Kurs gegen Delta Price (BTC) | Trend der letzten 365 Tage |
| Trend | Kurs gegen Power-Law-Fair-Value (kausal, Anpassung je Monat); Kurs gegen 200-Wochen-MA (BTC, ETH, ZEC, XMR) | Power Law mit den Parametern des Monats; Trend 365 Tage |
| Kohorten | Kurs gegen Kurzfrist-Kostenbasis, True Market Mean, Langfrist-Kostenbasis (BTC, BGeometrics, 7 Tage Verzug) | Trend 365 Tage |
| Miner | Kurs gegen Stromkosten S21 XP bei 7,5 ct (nur 1, 2, 4 J: ein fester Gerätetyp ist über 8 Jahre kein Maßstab); Puell gegen 1 | Trend 365 Tage; konstant 1 |

**9.2 Rechnung je Paar und Zeitraum** (`hl_makro_signal.paar_signal`):
- Abweichung y = ln(Reihe ÷ Referenz); angezeigt e^y − 1 in % (symmetrisch rechnen, verständlich zeigen).
- Median von y im Zeitraum — Mittellinie im Haupt- und Signal-Chart.
- Rückblick: Minimum, Maximum, Wendepunkte per Zickzack auf dem zentrierten 7-Tage-Mittel (nur hier zentriert; das Live-Signal nutzt
  es nie). Mindestwende θ = max(5 %, (P90 − P10)/2) im Zeitraum. Der erste Extremwert am Rand und der letzte, unbestätigte fehlen.
  Erst im Nachhinein bekannt.
- Live-Signal: rollierendes Perzentil von y unter den letzten W Tagen bis einschließlich heute (W = 0: seit Beginn; mindestens 292
  Werte), Gleichstände gemittelt. Kauf bei ≤ 10, Verkauf bei ≥ 90 — feste Ränder, nicht auf die Historie angepasst. Auf Rauschen
  liegen je 10 % der Tage in jeder Zone (Probe).
- Bilanz: Episoden (Signaltage mit höchstens 30 Tagen Abstand), Einstieg am ersten Tag, Rendite nach 90/180/365 Tagen
  (geometrisches Mittel). Nullverteilung: je Episode ein Zufallstag aus ±(Horizont + 365) Tagen um den Einstieg, 1000-mal;
  p einseitig in Richtung der Seite; „belegt“ bei p < 0,025, mindestens 3 Episoden.
- Prognose: AR(1) auf x = y − Median (nur aufeinanderfolgende Tage), φ ≤ 1 gekappt; Erwartung μ + φ^h (y₀ − μ); Halbwertszeit
  ln 0,5 / ln φ mit 90-%-Intervall aus dem Standardfehler; Dickey-Fuller-t < −2,86 = Rückkehr belegt. Wert = fortgeschriebene
  Referenz × e^y. Band: 10.–90. Perzentil der eigenen Fehler (ln Ist − ln Prognose, inklusive Fortschreibung der Referenz) aus den
  Ursprüngen der letzten 4 Jahre, deren Ziel bekannt ist; unter 20 Fehlern das AR(1)-Modellband (gekennzeichnet).
- Rückblick-Prüfung: Ursprünge alle 30 Tage, an jedem nur Daten bis dahin (Median, AR(1), Referenztrend); Abdeckung des Bands
  außerhalb der Stichprobe (erst ab 20 Prüfungen genannt), Fehler gegen „die Abweichung bleibt“.

**9.3 Betrieb.** `hl_makro.signale(D)` einmal je Datentag (Zwischenspeicher, eigenes Schloss, Fehler → Charts laufen ohne Signale);
der Makro-Takt schreibt den Tagesstand nach `mk_signal` (Tag, Paar, Zeitraum, Signal, Perzentil, Abweichung, Median, Prognose
365 T, Zeitpunkt; `INSERT OR IGNORE`). **Live gegen Nachrechnung** (`hl_makro_signal.nachrechnung`): jede archivierte Zeile früherer
Tage gegen das Perzentil der heutigen Rechnung für denselben Tag (± 0,01, Signal gleich); Anzeige unter der Signaltabelle, im Stand
und im Wochenbericht. Nutzlast je Signal-Tab: `signale` (Blöcke je Paar; ganze Perzentil-Reihen bleiben im Speicher, nie in der
Nutzlast) und `signal_regeln` (Schwellen, Horizonte, Stand, Nachrechnung).

**9.4 Kalibrierung (vor der Auslieferung).**
- Block-Bootstrap über alle Signaltage: 26–41 % Fehlurteile auf Zufallswegen (Soll 10 %) — Läufe, in denen der Kurs weiter fällt,
  sind länger und zählen mit mehr Tagen. Längere Blöcke und zirkulär verschobene Placebos ebenso daneben. Episoden mit lokalem
  Placebo: 3,2 % (5 von 158); Ära-Nulltest (Niveau der Abweichung und Drift wechseln gemeinsam) 4 von 80, mit Zufallstagen aus der
  ganzen Historie 16–27 von 80.
- Modellband (AR(1)) zu schmal; Band aus allen Jahren zu breit (bis 97 %) → Fehler der letzten 4 Jahre, eine Regel für Prüfung und
  heutiges Band. Wachsende Schwankung: Abdeckung 71 % (ein Band, das spätere Fehler kennt, träfe genau 80 %).

**9.5 Ergebnis auf echten Daten** (Coin Metrics bis 23.05.2026, Test-Kopie): 63 Paar-Zeiträume in 4,0 s. Bilanz 3 von 322 Tests
belegt (Zufall allein ≈ 16): Power Law 4 J Kauf 90 T (+56 % gegen +13 %, p 0,014, 7 Episoden), XMR 200-W-MA 8 J/alles Verkauf
90 T (−21 % gegen +12 %, 4 Episoden). Nach Verkaufssignalen lag die Rendite im Median 5,3 Punkte über den Zufallstagen (64 % der
Tests; Momentum), nach Kaufsignalen +1,3 Punkte (52 %). Prognose besser als „bleibt“ in 83/78/78 % (90/180/365 T), Median-Fehler
15/16/19 % kleiner; Band traf 81/83/85 % (Soll 80). Rückkehr nach Dickey-Fuller belegt in 14 von 63. Nachrechnung: Stände vom
06.10.2025, 05.02., 01.04., 01.05.2026 (Datei nur bis dahin) gegen alle Daten 249 von 249 gleich.

**9.5a Erster Stand auf dem Pi** (Bericht 06.10.2026 20:15, Daten bis 05.10.): 336 Tests, belegt 4 -- Power Law 4 J und 8 J Kauf
90 T (+53 % bzw. +51 %, p 0,012/0,018, 8 bzw. 6 Episoden), XMR 200-W-MA 8 J und alles Verkauf 90 T (−21 %, p 0,012/0,013,
4 Episoden). Zufall allein liefert nach 9.4 (3–5 % Fehlurteile je Test) rund 11–17; als Ganzes trägt die Bilanz keinen Beleg.
Live gegen Nachrechnung 64 von 64 gleich. Band 365 T bei ZEC im Rückblick 0 % (4 J) bzw. 51 % (2 J) statt 80 % -- ZEC liegt bei
Perzentil 96–98 seiner Historie, die ZEC-Bänder sind nicht verwendbar. Seit 23.56 (U135) steht unter den Signalen im Stand
die Summenzeile „belegt N von M Tests -- der Zufall allein liefert … etwa …“ (`hl_makro_signal.FEHLURTEILE` = 3,2 % und 5 % aus
9.4) und die Zahl der Live-Signale mit belegter Bilanz ihrer eigenen Seite; auf der Test-Kopie „belegt 3 von 322“ wie 9.5.

**9.6 Proben.** Signal-Selbsttest (12): Perzentil gegen unabhängige Nachrechnung, kausal, Zehntel auf Rauschen; Zickzack; Bilanz
Positivkontrolle (23 von 24), Nulltest Zufallsweg (≤ 6 %), Nulltest Ära (≤ 10 %); Prognose Positivkontrolle (φ, Halbwertszeit,
Abdeckung 70–90 %, besser als „bleibt“), Nulltest Zufallsweg (nicht besser als „bleibt“, Formeln exakt), Band ehrlich (wachsende
Schwankung < 76 %), Band folgt 4 Jahren (Schwankungssprung); Referenz nur aus der Vergangenheit, Power Law des Ursprungsmonats;
Block (JSON, Median, Prognoseziel, Rückblick trotz Rauschen); Nachrechnung (gleich, Revision erkannt). Im Makro-Selbsttest
zusätzlich: Signale je Tab, Kausalität der ganzen Kette (Zukunft × 50, 44 Perzentil-Reihen bitgleich), Nachrechnung mit echter
Ableitung (Revision des BTC-MVRV nur in `rp:BTC` und `delta:BTC`); seit 23.56 die Summenzeile im Stand (Summen gegen eigene
Zählung, Zufallserwartung, Live mit belegter eigener Seite an einem Konstrukt). Mutationen: 36 von 36 rot (Signal-Code und Signal-Teil von `hl_makro.py`), `hl_makro.py` erneut 37 von 37; Summenzeile 4 von 4.

**9.7 Grenzen.** Die Zonen beschreiben eine Lage; ein Beleg für Timing fehlt. Viele Tests: etwa jeder zwanzigste ist zufällig
belegt. Die Tests je Paar sind nicht unabhängig (überlappende Zeiträume und Horizonte). Die Prognose setzt eine Rückkehr zum
Median voraus; wo Dickey-Fuller sie nicht belegt, ist die Erwartung nur so gut wie „bleibt“ plus Referenztrend. Der Referenztrend
der letzten 365 Tage schreibt Kostenbasen fort, die in Wenden knicken.

## 10. Makro × Kurs und Makro-Regime × Prognosen (U130) — vorab festgelegt am 05.10.2026, 19:15

Wunsch des Nutzers (05.10. 19:11): die Makrosignale auf Tagesbasis mit der Kursbewegung korrelieren und prüfen, wie stark die
Wechselwirkung tatsächlich ist; Auswertung am 25.10. Dieser Abschnitt legt Ziel, Merkmale, Maße und Schwellen fest, BEVOR ein
Ergebnis zu sehen ist. Was später dazukommt, zählt nur als Hypothese für eine neue, eigene Runde.

**10.1 Teil A — Makro × BTC-Kurs, Tagesbasis, ganze Historie.** Braucht keine neuen Daten: Coin Metrics reicht bis 2010 zurück,
Funding bis 2019, Fear & Greed bis 2018, DVOL bis 2021, Stablecoins bis 2017, ETF-Flüsse bis 01/2024.
- Ziel: log-Rendite von BTC VORWÄRTS, r(t → t+h) mit h = 1, 7 und 30 Tagen (Tagesschluss UTC). Nie die Rendite desselben Tags --
  die beschreibt nur, nicht voraus.
- Merkmale am Tag t, nur mit Daten bis t (wie die Zonenkarte), 15 Stück:
  - MVRV (Perzentil), Kurs ÷ Power-Law-Fair-Value (Perzentil, kausal), Abstand zum 200-Wochen-MA (Perzentil);
  - Kurs ÷ Kurzfrist-Kostenbasis − 1, MVRV-Z, Puell (Perzentil in der Epoche);
  - Funding 30 T, OI ÷ Marktkapitalisierung (erst mit vollständigem Archiv), DVOL, Fear & Greed 30 T, SSR (Perzentil),
    ETF-Fluss 30 T;
  - nur wenn FRED läuft: Änderung über 4 Wochen von Nettoliquidität, Realzins 10 J und Dollarindex.
  - Zusammen 15 × 3 = 45 Tests.
- Maß: Spearman-Rangkorrelation ρ zwischen Merkmal(t) und r(t → t+h), dazu ρ² als Anteil der erklärten Streuung („wie hoch ist
  die Wechselwirkung“). Ergänzend die Richtung: Rendite nach Tagen im obersten gegen das unterste Drittel des Merkmals.
- Unsicherheit: Die Renditen überlappen (bei h = 30 teilen sich Nachbartage fast alles). Die Nullverteilung muss die
  Autokorrelation beider Reihen erhalten (zirkuläre Verschiebung des Merkmals um mindestens 365 Tage oder Blockbootstrap mit
  Blocklänge h). Welche, entscheidet die Kalibrierung auf Zufallswegen VOR dem ersten Blick auf echte Daten (Soll: rund 5 %
  Fehlurteile).
- Belegt nur, wenn alle drei gelten:
  1. Benjamini-Hochberg über alle 45 Tests mit q = 0,10;
  2. gleiches Vorzeichen und |ρ| ≥ 0,05 in beiden Hälften (bis 31.12.2021 und ab 01.01.2022);
  3. die Nachrechnung gegen das Archiv (`mk_stand`) widerspricht nicht.
- Bericht: je Test ρ mit 90-%-Intervall, ρ², p, beide Hälften, Zahl der Tage; daneben die Zufallserwartung (bei 45 Tests rund 4
  bis 5 Fehlurteile ohne Korrektur).
- Vorwissen, damit nichts überrascht: Die Signal-Bilanz (U126) fand auf echten Daten 3 von 322 Tests belegt. Der Großteil wird
  nahe null liegen; interessant ist, was beide Hälften übersteht.

**10.2 Teil B — Makro-Regime × 4-h-Prognosen.** Braucht die neuen Daten: Hyperliquid-Prognosen gibt es erst seit Mitte September.
- Regime am Tag (Zonenkarte, kausal), 6 Stück: Funding 30 T im oberen Drittel; OI ÷ Marktkapitalisierung im oberen Drittel;
  DVOL im oberen bzw. unteren Drittel; Fear & Greed 30 T ≥ 75 bzw. ≤ 25; Kurs unter der Kurzfrist-Kostenbasis; MVRV-Drittel.
- Ziel: Trefferquote und Brier-Skill gegen die Basisrate der 4-h-Prognosen v1, v2 und Fusion je Coin, im Regime gegen außerhalb.
- Unsicherheit: Blockbootstrap über ganze Tage; Placebo: der Regime-Kalender um zufällige ganze Wochen verschoben.
- Belegt nur mit Placebo-p < 0,025, gleichem Vorzeichen in zwei Zeithälften und Benjamini-Hochberg (q = 0,10) über Regime × Quelle
  × Coin.
- 25.10. ist nur ein erster Blick: rund 6 Wochen, etwa 250 Blöcke je Coin, im Regime und außerhalb je rund die Hälfte. Der
  Standardfehler eines Unterschieds zweier Trefferquoten liegt dann bei etwa 6 Punkten; kleinere Unterschiede als rund 12 Punkte
  sind nicht zu erkennen. Belegbar frühestens nach rund drei Monaten (Mitte Januar 2027).

**10.3 Was daraus folgt.** Ein belegter Zusammenhang wird ein Kandidat, kein Signal: Einbau (etwa als Regime-Merkmal in v3 oder
als Experte der Fusion) erst nach einer zweiten, unabhängigen Prüfung und nicht vor dem Ende der Zusage (25.10.). Das Werkzeug
(Debug-Bericht) berührt Fusion, v3 und Kaskaden nicht und darf vorher gebaut werden.

**10.4 Umsetzung Teil A (23.52, `hl_makro_korr.py`, gebaut auf Wunsch des Nutzers 05.10. 19:19).**
- Debug „★ Makro × Kurs (U130, Teil A)“ (`python3 hl_makro_korr.py --db <hl_liq.db>`) und „Makro × Kurs: Selbsttest“; Berichte am
  06.10. 20:30 (erster Lauf mit allen Quellen) und 25.10. 20:15 (vereinbarter Termin, mit dem Stand).
- **Abweichung vom Plan beim Nullverfahren, entschieden VOR dem ersten Blick auf echte Daten.** Beide vorab genannten Verfahren
  fielen in der Kalibrierung durch -- 4.050 Tests auf Zufallswegen mit Volatilitäts-Clustern und unabhängigen, zähen Merkmalen (AR
  0,995, Perzentil eines Zufallswegs, 30-Tage-Mittel), je 450 je Art und Horizont:

  | Verfahren | p < 0,01 | p < 0,05 | p < 0,10 | schlechteste Art |
  |---|---|---|---|---|
  | zirkuläre Verschiebung ≥ 365 Tage | 1,7 % | 6,5 % | 11,5 % | Perzentil: 2,7 % / 8,7 % |
  | Blockbootstrap, Blocklänge h (erster Lauf, 720 Tests) | — | bis 20 % | bis 29 % | Perzentil h = 7 |
  | **Phasen-Randomisierung (Ebisuzaki 1997), gewählt** | **0,8 %** | **5,4 %** | **10,2 %** | Perzentil: 1,3 % / 6,9 % |

  Grund: Bei zähen Merkmalen tragen wenige tiefe Frequenzen fast die ganze Korrelation. Die Verschiebung dreht alle Phasen nur
  gemeinsam (eine einzige Familie von Mustern), die Phasen-Surrogate ziehen sie unabhängig -- das ist unter der Nullhypothese
  (stationär, unabhängig) die richtige Verteilung. Das Ziel des Plans („Autokorrelation beider Reihen erhalten, Soll rund 5 %
  Fehlurteile“) erfüllt nur sie. 2000 Surrogate je Test.
- Klarstellungen, die aus der Regel folgen:
  - FRED-Merkmale nehmen den Wert von t − 7 (Veröffentlichungsverzug; „nur Daten bis t“).
  - Reihen unter 760 Tagen sind nicht prüfbar und zählen nicht im Benjamini-Hochberg.
  - Ohne erste Hälfte (weniger als 365 Tage vor 2022) wird gerechnet, aber nie belegt: Kurzfrist-Kostenbasis (BGeometrics frei
    nur 4 Jahre), DVOL (ab 03/2021), ETF-Flüsse (ab 01/2024).
  - OI erst mit vollständigem Archiv, FRED erst mit Schlüssel.
- **Vorschau in der Sandbox** (nur die 5 Merkmale aus Coin Metrics mit echten Daten bis 23.05.2026; die übrigen Reihen der Test-Datenbank
  sind synthetisch): 0 von 15 Tests belegt, Benjamini-Hochberg 0, unkorrigiert p < 0,10 einmal (Zufall allein ≈ 1,5).
  - ρ zwischen −0,10 und +0,20, ρ² höchstens 4,2 % (Puell, 30 Tage; p 0,32).
  - MVRV, MVRV-Z, 200-Wochen-MA und Power Law wechseln zwischen den Hälften das Vorzeichen.
  - Puell bleibt in beiden Hälften positiv, ab 2022 aber unter 0,05.
  - Maßgeblich ist der Lauf auf dem Pi mit allen Quellen.
- Proben: Selbsttest 8 Prüfungen (rund 14 s) -- Ränge und FFT gegen direkte Rechnung, Streuung der Phasen-Null = 1/√n, Nulltest auf
  Zufallswegen, Positivkontrolle (ρ ≈ 0,12, 10 von 10), Ära (Ganzprobe auffällig, Hälften nicht), Urteil braucht alle drei
  Bedingungen, FRED-Versatz, zu kurze Reihe, ganze Auswertung mit Nachrechnung. Mutationen 11 von 11 rot (u. a. Rendite rückwärts,
  Phasen-Null ohne Spektrum des Merkmals, Hälften ohne Schwelle oder ohne Vorzeichen der Ganzprobe, Urteil ohne BH, FRED ohne
  Versatz).

**10.5 Erster Lauf auf dem Pi mit allen Quellen** (Bericht 06.10.2026 20:30, BTC-Tagesschluss bis 05.10.; UEBERGABE 3γγ).
- 0 von 45 Tests belegt, Benjamini-Hochberg allein 0, unkorrigiert p < 0,10: 3 (Zufall allein ≈ 4,5). Wie die Vorschau.
  - Größtes ρ²: Puell 30 T, ρ +0,20 [90 %: −0,09; +0,49], 4,1 %, p 0,33; beide Hälften positiv (+0,24/+0,08).
  - Kleinste p: Nettoliquidität 1 T 0,020 (Hälften +0,04/+0,01), Puell 1 T 0,026, Nettoliquidität 7 T 0,047 (+0,07/+0,05).
    Benjamini-Hochberg verlangt beim kleinsten p höchstens 0,0022.
  - Gleichsinnig in beiden Hälften, weit weg von BH (nur Hypothesen für eine neue Runde): Puell 30 T, Nettoliquidität 30 T
    (+0,07/+0,10), Power Law 30 T (−0,08/−0,23), OI ÷ Marktkap. 30 T (−0,10/−0,07).
  - Puell: Ein hohes Perzentil (in der Epoche) geht eher mit höheren Folgerenditen einher (ρ +0,08/+0,14/+0,20, nicht belegt)
    -- entgegen dem Wort „Verkauf“ im Live-Signal (9.5: nach Verkaufssignalen im Median über den Zufallstagen).
- Teststärke: 90-%-Band der Phasen-Null bei h = 1 rund ±0,03 bis ±0,09, bei h = 30 für zähe Merkmale ±0,16 bis ±0,36. Bei
  30 Tagen wären nur sehr starke Zusammenhänge belegbar.
- 25.10.: 19 Tage mehr (lange Reihen unter 0,5 %, ETF rund 2 %); dasselbe Urteil ist zu erwarten.
- **Nachrechnung gegen `mk_stand`:** 20 von 24 Werten gleich; DVOL 2 von 2 und ETF-Fluss 2 von 2 abweichend. Ursache: Der
  Makro-Takt schreibt die Zonenkarte beim ersten Rechnen jedes UTC-Tags fest. DVOL trägt dann eine offene Tageskerze, der
  30-Tage-ETF-Fluss ist eine Kalendersumme bis heute, in der die Flüsse des Tags erst nach US-Schluss erscheinen (beide Abrufe
  alle 12 h). Beispiel 05.10.: DVOL 35,97 → Tagesschluss 36,10; ETF 2.170,3 → 2.080,5 Mio USD. Fear & Greed, Funding, OI und
  die Coin-Metrics-Merkmale sind beim Festschreiben schon endgültig und stimmen. Ohne Folge fürs Urteil: DVOL und ETF haben
  keine erste Hälfte. Seit 23.56 (U135, `VORLAEUFIG_TAGE = {dvol: 2, etf: 3}`): Lag der Datentag beim Festschreiben weniger
  Tage zurück, steht der Wert als „am offenen Tag festgeschrieben (Tageswert noch vorläufig, nicht geprüft)“ und zählt nicht
  als Widerspruch; ein abgeschlossener Tag mit geändertem Wert bleibt „abweichend“, alle übrigen Kennzahlen werden auch am
  selben Tag geprüft. Selbsttest Prüfung 9.

## 11. Arbeitsmarkt und Preise der USA (U153) und Datentage (U154) -- entschieden 11.10.2026 gegen 23:50, Bau mit 23.67

**Anlass.** Frage des Nutzers (11.10. 23:44): Sind Arbeitsmarktdaten, Verbraucher- und Erzeugerpreise der USA im Makro-Teil?
Gibt es sie bei FRED?
- Befund: nicht im System (UEBERGABE 3ααα); bei FRED alle vorhanden.
- Entschieden per Auswahl mit Vorschlag:
  - sammeln und zeigen;
  - die Datentage prüfen. Zuerst war das für nach dem 25.10. geplant; auf Nachfrage des Nutzers (12.10. 00:01) kommt es mit
    23.67 (11.7).

**11.1 Reihen.** FRED, derselbe Schlüssel und derselbe Takt wie die übrigen FRED-Ziele.

| Reihe | FRED | ab | Takt | gezeigt als | Frische-Grenze |
|---|---|---|---|---|---|
| Arbeitslosenquote (%) | UNRATE | 1948 | monatlich, meist 1. Freitag | Wert | 100 Tage |
| Stellenzahl außerhalb der Landwirtschaft (Tsd.) | PAYEMS | 1939 | monatlich, mit der Quote | Veränderung zum Vormonat und 3-Monats-Mittel | 100 |
| Erstanträge auf Arbeitslosenhilfe | ICSA | 1967 | wöchentlich (Woche bis Samstag), donnerstags | 4-Wochen-Mittel | 16 |
| Verbraucherpreise gesamt | CPIAUCNS / CPIAUCSL | 1913 / 1947 | monatlich, Monatsmitte | Vorjahresrate aus NSA, Monatsrate aus SA (%) | 100 |
| Verbraucherpreise ohne Lebensmittel und Energie | CPILFENS / CPILFESL | 1957 | monatlich | wie oben | 100 |
| Erzeugerpreise Endnachfrage | PPIFID / PPIFIS | Nov. 2009 | monatlich, meist in derselben Woche wie die Verbraucherpreise | wie oben | 100 |

- **Vorjahresrate aus den nicht bereinigten Reihen:** So rechnet BLS die Zahl der Schlagzeile. Die Monatsrate kommt aus den
  bereinigten Reihen.
- **Erzeugerpreise:** Die Endnachfrage beginnt im November 2009 und reicht damit über die ganze Bitcoin-Zeit.
- **Frische-Grenzen:**
  - Monatsreihen wie M2: auf den Monatsersten datiert. Vor dem nächsten Termin ist der letzte Wert rund 65–75 Tage alt, nach
    einem Stillstand mehr. Grenze 100.
  - Erstanträge: Veröffentlichung 5 Tage nach Wochenende, dazu Feiertage. Grenze 16 wie bei STLFSI4.
- Herkunft der Angaben:
  - „ab“ der bereinigten Reihen und alle Termine: von den FRED-Seiten am 11.10. abgelesen.
  - Die nicht bereinigten Reihen (CPIAUCNS „ab 1913“, CPILFENS, PPIFID) sind beim Bau gegen die Antwort zu prüfen.

**11.2 Speicher mit Fassungen.**
- `mk_reihe` behält wie bisher nur den jüngsten Wert; daraus rechnen die Charts.
- Neu ist `mk_fassung` (reihe, ts, abgerufen, wert; Schlüssel aus allen drei) für diese Reihen:
  - Jede neue oder geänderte Zahl kommt mit Abrufzeit hinein, ein gleicher Wert erzeugt keine Zeile. Das ist dieselbe Regel wie
    bei `ak_wert` in `aktien.db`.
  - Grund: `schreiben()` überschreibt einen geänderten Wert (Schlüssel reihe, ts). Die erste Veröffentlichung ginge sonst
    verloren.
- **Vergangenheit:**
  - Einmal je Reihe aus ALFRED: `fred/series/observations` mit `output_type=4` („Initial Release Only“) und einem Echtzeitraum
    über die ganze Geschichte.
  - Gespeichert als eigene Reihe `fred1:<ID>` mit dem Tag der Erstveröffentlichung.
  - Die genauen Parameter (FRED-Konvention `realtime_start=1776-07-04`, `realtime_end=9999-12-31`) sind beim Bau gegen eine
    echte Antwort zu prüfen.
- Die übrigen Makro-Reihen bleiben unverändert. Ob M2 und die Bilanzen auch Fassungen brauchen, ist eine eigene Frage.

**11.3 Termine.**
- Abruf über `fred/release/dates` je Veröffentlichung mit `include_release_dates_with_no_data=true`, sonst fehlen die künftigen
  Termine. Einmal täglich, in eine eigene Tabelle `mk_termin` (release, tag, abgerufen).
- Die Nummer der Veröffentlichung bestimmt der Bau aus der Reihe (`fred/series/release`), nicht von Hand.
- Uhrzeit fest 8:30 New York mit Sommerzeit, für alle vier Veröffentlichungen: Arbeitsmarktbericht, Erstanträge,
  Verbraucherpreise, Erzeugerpreise.
- Laut API-Beschreibung sind die Termine die der Behörden und nicht der Zeitpunkt, an dem FRED die Zahl führt. Gezeigt wird
  deshalb der Behördentermin; der Abruf danach folgt im normalen Takt.

**11.4 Darstellung (Tab Makro).**
- **Chart „Arbeitsmarkt“:** drei Felder auf gemeinsamer Zeitachse, nie zwei Größen in einem Feld (Regel aus 5):
  - Arbeitslosenquote;
  - Stellen je Monat (Veränderung und 3-Monats-Mittel);
  - Erstanträge (4-Wochen-Mittel).
- **Chart „Preise“:** zwei Felder:
  - Vorjahresraten von Verbraucherpreisen gesamt und Kern sowie Erzeugerpreisen;
  - Monatsraten derselben drei.
- Wie alle Charts: Kursleiste, Fadenkreuz, Tabelle (Monatsenden) und Quelle („FRED; BLS“, Erstanträge „FRED; ETA“).
- Unter jedem Chart „nächster Termin: Mi 14.10., 14:30 Uhr“ in Berliner Zeit. Oben im Tab eine Zeile „Termine der nächsten
  14 Tage“.
- **Lücken bleiben Lücken:**
  - Oktober 2025 ist nicht gefüllt. Hinweis: „Oktober 2025 nicht erhoben (Stillstand der US-Regierung)“.
  - Eine Vorjahresrate über eine Lücke fehlt, ebenso wie bei BLS die Rate für Oktober 2026. Keine eigene Schätzung.
- **Korrelation mit BTC** wie bei den übrigen Makro-Reihen (Abschnitt 3), beschreibend mit Zufallsband:
  - Monatsreihen: Monatsänderung gegen die BTC-Monatsrendite über 24 Monate;
  - Erstanträge: Wochenänderung gegen die BTC-Wochenrendite über 52 Wochen.

**11.5 Wirkung.** Keine. Die Reihen erzeugen:
- keine Zonen und Signale (Abschnitt 9), keine Zeile in der Zonenkarte und keinen Kandidaten in „Makro × Kurs“ (Abschnitt 10);
- nichts in Konfluenz, Labor, Prognose, Treiber oder Ausblick.

Die Zusagen bis 25.10. bleiben unberührt.

**11.6 Proben (für den Bau festgelegt, je mit Mutation).**
- **Parser:** „.“ fällt weg. Die Lücke Oktober 2025 bleibt Lücke. Eine Vorjahresrate über eine Lücke fehlt und wird nicht
  interpoliert.
- **Fassungen:**
  - Ein geänderter Wert gibt eine neue Zeile, die alte bleibt. Ein gleicher Wert gibt keine Zeile.
  - `mk_reihe` zeigt den jüngsten Wert.
  - Die Erstveröffentlichung stimmt mit einer von Hand gelesenen Antwort überein; ihr Tag liegt nicht nach dem Abruftag.
- **Termine:**
  - Künftige Termine nur mit dem Schalter.
  - 8:30 New York → UTC mit Sommerzeit (14.10. 12:30 UTC, 06.11. 13:30 UTC).
  - Die Anzeige in Berliner Zeit stimmt auch in der Woche 25.10.–01.11. (13:30).
- **Rechnung:** Vorjahresrate, Monatsrate, 3-Monats- und 4-Wochen-Mittel von Hand.
- **Frische:** Die Grenzen 100 und 16 Tage greifen. „Fehlt“ gilt erst nach einem erfolgreichen Abruf.
- **Browserprobe:** Chartwerte an der beschrifteten Achse gegen `makro.db`; Termin-Zeile gegen `mk_termin`; Handybreite.

**11.7 Studie „Datentage“ (U154) -- festgelegt am 13.10.2026 vor dem Bau, bevor eine Zahl auf echten Daten zu sehen war**

- **Zeitpunkt:**
  - Zuerst „nach dem 25.10.“ vorgeschlagen, damit das Paket schlank bleibt und die Tage für die ersten Auswertungen frei
    sind. Das war Bequemlichkeit, keine Regel.
  - Die Studie liest nur Historie und berührt nichts, was bis 25.10. fest bleibt. Deshalb auf Nachfrage des Nutzers
    vorgezogen (12.10. 00:01). Gebaut mit 23.67.
- **Frage:** Schwanken BTC und ETH im Fenster 8:30–10:30 New York an US-Datentagen stärker als an Werktagen ohne Termin im selben
  Monat? Nur die Schwankung, nicht die Richtung: Ohne Erwartungswerte gibt es keine Überraschungsgröße.
- **Hypothesen mit Urteil:**
  - H1 Verbraucherpreise (Veröffentlichung der Reihe CPIAUCSL);
  - H2 Arbeitsmarktbericht (Veröffentlichung der Reihe UNRATE).
  - Beschreibend, ohne Urteil: Erzeugerpreise (PPIFIS), Erstanträge (ICSA).
- **Termine:**
  - aus `mk_termin` (FRED `fred/release/dates`, U153): nur vergangene, vom 01.01.2020 bis zum letzten Tag mit vollständigen
    Kerzen;
  - verschobene Termine (etwa nach dem Stillstand 2025) zählen am tatsächlichen Tag.
  - Gegenüber der Rohskizze geändert: Die Termine kommen aus dem Kalender der Veröffentlichung statt aus den ALFRED-
    Erstveröffentlichungen. Die Information ist dieselbe, ohne Umweg. Beschreibend wird gezählt, an wie vielen Terminen der Tag
    der Erstveröffentlichung (ALFRED, `mk_fassung` „erst“) abweicht; erwartet: an keinem.
- **Kurse:** `swing.db`, 30-min-Kerzen der Binance-USDT-Perps BTC und ETH.
  - Fenster = die vier Renditen der Kerzen, die um 8:30, 9:00, 9:30 und 10:00 New York beginnen, je gegen den Schluss der Kerze davor
    (Sommer- und Winterzeit richtig). Nötig sind also fünf Kerzen ab 8:00.
  - RV_w = Σ r² über die vier Renditen. Ein Tag zählt nur mit allen fünf Kerzen.
- **Vergleichstage C(e):**
  - Werktage (Mo–Fr) desselben Kalendermonats, an denen keiner der vier Termine lag und die NYSE nicht geschlossen war (Kalender
    nach den Regeln aus `hl_aktien`);
  - mindestens 5, sonst fällt der Termin weg.
- **Maß:**
  - je Termin e und Coin k: x_{e,k} = ln(RV_w(e) + ε) − Mittel über C(e) von ln(RV_w(c) + ε), mit ε = 10⁻⁸;
  - x_e = Mittel über BTC und ETH (beide nötig);
  - Prüfgröße T = Mittel über die Termine; exp(T) ist der typische Faktor der Varianz.
  - Gegenüber der Rohskizze geändert: Der Vergleich im selben Monat nimmt das Schwankungsniveau ohne Modell heraus. Die Division
    durch die HAR-Erwartung des Vortags entfällt, weil sie eine eigene Fehlerquelle wäre.
- **Null:**
  - Jeder Termin wird auf einen zufällig gezogenen Vergleichstag c* desselben Monats verschoben;
    x* = ln RV(c*) − Mittel über C(e) ohne c*.
  - 10.000 Ziehungen, feste Saat; p = (1 + Zahl der T* ≥ T) / (1 + 10.000), einseitig.
- **Intervall:** 90 % für exp(T) aus dem Blockbootstrap über Kalendermonate (2.000 Ziehungen; die Termine eines Monats bleiben
  zusammen).
- **Urteil „belegt“:** p nach Holm über H1 und H2 unter 0,05 **und** T > 0 in beiden Hälften (Teilung am mittleren Termin der
  Hypothese).
- **Positivkontrolle und Nullprobe (Selbsttest, synthetisch):**
  - 30-min-Renditen mit Tagesprofil, Schwankungsballung über Tage und t-Rändern (ν = 4), an den echten Kalendern 2020–2026, mit
    synthetischen Terminen (je Monat zwei Werktage);
  - eingepflanzter Varianzfaktor im Fenster an den Terminen:
    - bei Faktor 1,5: „belegt“ in mindestens 80 % von 40 Märkten;
    - ohne Faktor: „belegt“ in höchstens 4 von 40 Märkten (10 %). Bei genau 5 % Fehlurteilen wäre P(≥ 5 von 40) rund 5 %; mit der
      Hälftenregel liegt die Rate darunter.
    - Im Selbsttest je Markt 2.000 statt 10.000 Ziehungen (Rechenzeit); je Markt eine Hypothese.
  - Nachweisgrenze: Anteil „belegt“ bei den Faktoren 1,2 / 1,3 / 1,5 / 2,0, gemessen und im Bericht genannt.
- **Beschreibend, ohne Urteil:**
  - je Coin;
  - je Jahr;
  - Erzeugerpreise und Erstanträge mit demselben Maß;
  - der ganze UTC-Tag (Σ r² über 48 Kerzen, Vergleich wie oben);
  - die mittlere absolute Fensterrendite gegen die Vergleichstage. Die Richtung wird nicht geprüft.
- **Erwartung vorab:**
  - H1 belegt, Faktor 1,5–3; die Inflationsphase 2022 trägt viel.
  - H2 belegt, Faktor 1,3–2.
  - Seit 2024 kleiner.
  - Über den ganzen Tag kleiner als im Fenster.
- **Folge:**
  - Belegt: Der Nutzer entscheidet eigens, ob der Ausblick (Breite) oder die Strukturgleichung (U116, σ(t) mit Makro-Kalender) die
    Termine nutzt. Jede Nutzung muss außerhalb der Stichprobe gegen das bestehende HAR gewinnen
    (`RECHERCHE_Aktienmarkt_11-10-2026.md`, Rolle „Breite“).
  - Nicht belegt: Die Termine bleiben Anzeige.
- **Bericht:** Debug „★ Datentage: Schwankung an US-Terminen (U154)“ (`hl_datentage.py --studie`); im Berichtsplan 15.10. 21:45,
  zweiter Termin 16.10. 21:45 (falls die Termine am 15.10. noch nicht geladen waren).
- **Kein Urteil wird nachträglich gelockert.** Was später dazukommt, ist eine neue Runde mit neuer Festlegung.

**11.8 Gebaut mit 23.67 (13.10.2026) -- Abweichungen vom Plan und Proben**

- **Erstveröffentlichungen** stehen in `mk_fassung` mit der Art „erst“ (Zeitpunkt = 8:30 New York am Tag `realtime_start`), nicht
  als eigene Reihe `fred1:<ID>` wie in 11.2 skizziert. Dieselbe Information in einer Tabelle; eigene Abrufe tragen die Art „abruf“.
  `fred1` ist nur noch der Name des Abrufziels (einmal im Monat je Reihe), `fredtermin` der der Termine (einmal am Tag). Ohne
  FRED-Schlüssel versucht der Takt beide nicht.
- **Charts:** fünf eigene Felder statt zwei Charts mit Teilfeldern -- Arbeitslosenquote, neue Stellen je Monat (mit 3-Monats-Mittel),
  Erstanträge (4-Wochen-Mittel), Vorjahresraten (Verbraucherpreise gesamt und Kern, Erzeugerpreise), Monatsraten derselben. Jedes
  mit Kursleiste, Fadenkreuz, Tabelle, Quelle und dem nächsten passenden Termin. Die Lücke steht im Fuß („Okt 2025 nicht erhoben
  … -- nicht gefüllt“).
- **Korrelation mit BTC** unter Quote, Stellen, Erstanträgen und Monatsraten, **nicht** unter den Vorjahresraten: Deren
  Monatsänderung ist fast die Monatsrate (minus der von vor zwölf Monaten), also keine eigene Information.
- **Fadenkreuz in strenger Lesart:** Der Wert eines Tages ist der der jüngsten Stützstelle davor, auch wenn er fehlt. In einer
  Lücke steht deshalb „—“ und nicht der Vormonat (die übrigen Makro-Charts suchen bis 8 bzw. 40 Tage zurück).
- **Termine in Ortszeit** des Browsers (beim Nutzer Berlin): Kopfzeile „Termine der nächsten 14 Tage“, unter jedem Chart „nächster
  Termin …“. Ein Termin, dessen 8:30 New York schon vorbei ist, zählt nicht mehr als „nächster“.
- **Proben (11.6, alle gebaut):** Makro-Selbsttest mit 9 neuen Prüfungen, jetzt 65 (Fassungen, 8:30 New York in UTC, Parser,
  Termine, Abruf ohne Netz mit Schalter für künftige Termine, Rechnung mit Lücke von Hand, Frische, nächster Termin und 14 Tage,
  Erstanträge über eine fehlende Woche). Browserprobe gegen eine eigene Rechnung aus `makro.db` (nicht mit den JS-Funktionen): fünf Charts,
  Korrelationen, Termine und Ortszeit auch in der Woche 25.10.–01.11. (13:30), Lücke im Fuß, Fadenkreuz-Werte, gezielt in den
  ersten Tagen der Lücke kein Wert, Tabelle, Handybreite, Skriptfehler.
- **Mutationen:** Python 14 von 14 rot. Fünf davon prüft erst eine Probe, die ich beim Entwurf der Mutationen ergänzt habe:
  „nächster Termin auch vorbei“ und „7 statt 14 Tage“ (Probe zu `usa_termine`), „Erstanträge über eine Lücke gemittelt“ (eine
  fehlende Woche), „Monatsrate aus der nicht bereinigten Reihe“ (Monatsrate von Hand), „ohne Schalter für künftige Termine“ (das
  falsche Netz liefert künftige Termine jetzt wie die echte API nur mit dem Schalter). Browser 9 von 9 rot -- zwei zuerst grün („strenge Lesart aus“, „Lücke gefüllt“): Die Probe zielte in die
  Mitte der Lücke, wo auch die alte Lesart nichts zeigt, weil der Vormonat schon über 40 Tage zurückliegt. Jetzt zielt sie auf den
  2.–9. Oktober 2025.
- **Datentage (11.7):** `hl_datentage.py`, gebaut wie festgelegt. Selbsttest 10 Prüfungen (rund 12 s): Fenster, Vergleichstage,
  Null und Holm von Hand, Urteilsregel, Hälften von Hand, Positivkontrolle (Faktor 1,5: 40 von 40 Märkten belegt, Median 1,45),
  Nullprobe (1 von 40), Deckung des 90-%-Intervalls (170 von 200 Läufen, 85 %; Soll mindestens 80 %), Ende zu Ende auf
  Demo-Datenbanken (H1 mit Faktor 2 eingepflanzt: 2,08 belegt; H2 ohne Effekt nicht; die Gegenprobe findet einen eingepflanzten
  Tag nur in ALFRED), Lauf ohne `makro.db`. Nachweisgrenze: Faktor 1,2 in 22 von 40, 1,3 in 33, 1,5 und 2,0 in 40 von 40.
  Prüfgröße unverzerrt: auf 200 weiteren Nullmärkten Mittel T +0,0009 ± 0,0058. Mutationen 14 von 14 rot; fünf davon (Urteil ohne
  Hälften, ohne Holm, Intervall 50 statt 90 %, Gegenprobe vertauscht, Hälften = Gesamtmittel) prüft erst eine beim Entwurf der
  Mutationen ergänzte Probe. Der Studienlauf auf
  echten Daten ist für 15.10. 21:45 geplant (zweiter Termin 16.10. 21:45); vorher holt der Makro-Takt die Termine.
