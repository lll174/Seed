# KONZEPT Makro-Chart (U121) — Lage im mittel- und langfristigen Zyklus

Stand 05.10.2026, Version 2026-09-23.49 (Opus 5.5; erstellt mit 23.47, Signale seit 23.49 in Abschnitt 9). Grundlage: `RECHERCHE_Makro_Chart_05-10-2026.md` (Bericht „Kostenbasis verortet den
Zyklus, feste Schwellen versagen“). Wunsch des Nutzers (05.10.): alles Kostenlose aus Stufe 1 und 2 einbauen, jeden Treiber mit
eigenem Chart, dazu die Miner-Kostenbasis (Ausgangsszenario Antminer S21 XP bei 7,5 ct/kWh); eigene Datenbank `makro.db`.

Code: `hl_makro.py` (Abruf, Rechnung, Nutzlast, Selbsttest), `hl_makro_signal.py` (Signale je Chart, seit 23.49),
`hl_makro_js.py` (Skript des Abschnitts, `/makro.js`),
Abschnitt „MK Makro“ in `hl_viz.py`. Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein API-Gewicht.

## 1. Regeln (aus dem Bericht, fest eingebaut)

1. **Positionen statt Signale.** Bänder im Kurschart (Realized Price, 200-Wochen-MA, Power-Law-Fair-Value, Kurzfrist-Kostenbasis,
   Stromkosten eines Miners) und Perzentile der eigenen Historie. Keine festen Schwellen aus 2013–2021 (MVRV 3,7/1, MVRV-Z 7/0,
   NUPL 0,75/0, Puell 4/0,5, LTH-SOPR 10/0,6, Pi Cycle …): 2025/26 oben und unten verfehlt, weil die Ausschläge seit 2011 schrumpfen
   (MVRV-Hochs je Halving-Epoche 7,74 · 5,88 · 4,72 · 3,96 · 2,74; Tiefs 0,39 · 0,56 · 0,69 · 0,75, dann rund 1,1).
   Seit 23.49 auf Wunsch des Nutzers zusätzlich Kauf- und Verkaufszonen je Chart (Abschnitt 9): relativ zum gewählten Zeitraum
   (unterstes/oberstes Zehntel), nicht feste Schwellen, und immer mit ihrer Bilanz gegen Zufall — auf echten Daten bisher ohne Beleg.
2. **Kausal.** Jede Rang-, Z- oder Anpassungsreihe nutzt am Tag t nur Daten bis t. Der Selbsttest hängt extreme Zukunftsdaten an
   (× 50) und verlangt die Vergangenheit bitgleich (19 Reihen). Ausnahme mit Ansage: die Power-Law-Linie und ihre Bänder im Chart
   (Anpassung über alle Tage, beschreibend); das Perzentil daneben ist kausal (Anpassung je Monat bis zum Vormonat).
3. **Kein Gesamtwert.** Wer Perzentile mittelt, baut einen ungetesteten Composite; die geprüften Composites (CBBI, CoinGlass 30
   Signale) scheiterten an ihren Schwellen. Die Zonenkarte zeigt jeden Treiber einzeln.
4. **Makro nur als Kulisse.** Liquidität, Zinsen, Dollar mit rollierender Korrelation zur BTC-Wochenrendite und Zufallsband ±2/√n;
   kein verschobener M2-Lag (Lag wanderte 0–3 Monate, Vorzeichen seit 2023 gedreht).
5. **Eine Quelle je Reihe, Abrufe archiviert.** Freie Fenster verschwinden (BGeometrics 4 Jahre, FRED-Hochzinsspread 3 Jahre,
   Binance-REST 30 Tage); `makro.db` behält alles, der Tagesstand der Zonenkarte wird einmal je Tag festgeschrieben (`mk_stand`) —
   die eigene, revisionsfreie Bilanz außerhalb der Stichprobe.

## 2. Quellen (alle frei)

| Quelle | Reihen in makro.db | Abruf | Historie | Lizenz, Grenzen |
|---|---|---|---|---|
| Coin Metrics Community API v4 | `cm:<asset>:<Metrik>` — BTC: PriceUSD, CapMrktCurUSD, CapMVRVCur, SplyCur, HashRate (TH/s), IssTotNtv, IssTotUSD, FeeTotNtv, BlkCnt; ETH/ZEC: Preis, Marktkap., MVRV, Angebot; XMR: Preis, Marktkap., Angebot | alle 6 h, `paging_from=start`, `page_size=10000`; danach ab letztem Tag − 14 | BTC ab 18.07.2010 | CC BY-NC 4.0 (Namensnennung unter jedem Chart); Bewertungsfelder erst bei T−2 vollständig; Realized Cap nicht frei → RC = Marktkap. ÷ MVRV |
| FRED (seit 23.48: offizielle API `api.stlouisfed.org` mit kostenlosem Schlüssel; ohne Schlüssel `fredgraph.csv`, das seit Mitte August 2026 vielerorts nicht antwortet) | `fred:<ID>` — WALCL, WTREGEN, RRPONTSYD, M2SL, DFII10, DTWEXBGS, BAMLH0A0HYM2, DFF, ECBASSETSW, JPNASSETS, DEXUSEU, DEXJPUS | alle 12 h; danach ab letztem Tag − 400; Wartezeit 20 s (API) bzw. 15 s (CSV) | ab 2008 (HY nur 3 Jahre) | HY-Spread: ICE-Daten, nur private Anzeige; Schlüssel in `accesstokens.json` → "fred" oder `FRED_API_KEY` |
| alternative.me | `fng:wert` | alle 6 h (`limit=0`, danach 40) | ab 02/2018 | Quellenangabe direkt am Chart (Pflicht) |
| DefiLlama | `llama:stable_usd` (alle Bindungen in USD summiert) | alle 12 h (ganze Reihe) | ab 29.11.2017 | Zählweise des Anbieters |
| Blockchain.com Charts | `bc:difficulty`, `bc:hashrate` (Gegenprobe) | alle 12 bzw. 24 h | ab 2009 | — |
| Deribit | `drb:dvol_btc` (Tagesschluss) | alle 12 h, Seiten über `continuation` | ab 24.03.2021 | — |
| Binance Futures | `bnc:funding_btc_tag` (Tagessumme der Raten, nur abgeschlossene UTC-Tage), `bnc:oi_btc_usd`/`_coins` | Funding alle 8 h (ab 09/2019), OI-REST alle 12 h (30 Tage) | Funding ab 2019, OI ab 09/2020 über das Archiv | — |
| data.binance.vision | OI-Archiv: Tagesdateien ZIP/CSV, früheste Zeile des Tages (wie REST: Stand zu Tagesbeginn) | eine Datei je Takt (20 s) bis vor den ersten REST-Tag, dann fertig | ab 01.09.2020 | 404 zählt als fehlend |
| Farside | `fs:etf_btc`, `fs:etf_eth` (Mio USD je Tag) | alle 12 h (Gesamtseiten „…-etf-flow-all-data“) | ab 11.01.2024 | privat; Parser wie hl_ext |
| BGeometrics (bitcoin-data.com) | `bgm:<Endpunkt>:<Feld>` — sth-realized-price, true-market-mean, lth-realized-price, sth-mvrv, lth-sopr, asopr, aviv, realized-loss | je Endpunkt einmal am Tag, höchstens 7 je Stunde, 14 je Tag, 8 min Abstand (frei: 8/h, 15/Tag) | letzte 4 Jahre, **ohne die jüngsten 7 Tage** (frei verzögert, am 05.10. belegt) | nicht kommerziell; Feldnamen undokumentiert → jedes Zahlenfeld eine Reihe (auf dem Pi: sthRealizedPrice, trueMarketMean, lthRealizedPrice) |

Nicht gebaut (nicht frei oder nicht belegt): 25-Delta-Skew (keine freie Historie), Treasury-mNAV (keine freie Schnittstelle),
alles aus Stufe 3 (Pi Cycle, Mayer > 2,4, 2-Jahres-MA × 5, Golden Ratio, Rainbow, Stock-to-Flow, Schwellen-Composites, M2 mit festem
Lag, NVT, Börsenbestände als Trend, selbst geschätzte Produktionskosten der ganzen Flotte).

## 3. Treiber, Rechnung, Selbsttest

| Treiber (Tab) | Rechnung | Positivkontrolle / Nulltest im Selbsttest |
|---|---|---|
| Realized Price, MVRV, NUPL (Bewertung) | RC = Marktkap. ÷ MVRV; RP = RC ÷ Angebot; NUPL = 1 − 1/MVRV; erste 180 Tage einer MVRV-Reihe verworfen (BTC: 146 am 18.07.2010) | Formeln exakt; MVRV 1 → NUPL 0; Anlauf NaN |
| MVRV-Perzentil (Bewertung) | Rang unter allen Werten bis heute (Gleichstände gemittelt), dazu 4-Jahres-Fenster | steigend 100, fallend 0, gleich 50; Rauschen gleichverteilt (Mittel 50 ± 3 SE, Zehntel); kausal |
| MVRV-Z (Bewertung) | (Marktkap. − RC) ÷ Streuung der Marktkap. bis heute (Population) | Handrechnung; MVRV 1 → Z 0 |
| Delta Price (Bewertung) | (RC − mittlere Marktkap. bis heute) ÷ Angebot | Handrechnung; kausal |
| Epochen-Hoch/-Tief, Bewertungsdivergenz (Bewertung) | Max./Min. von MVRV je Halving-Epoche; neues Kurshoch der Epoche bei MVRV ≥ 5 % unter dem bisherigen Epochenhoch (Hypothese, ungetestet) | Divergenz erkannt; MVRV ∝ Kurs → keine |
| Power Law (Trend) | log10(Kurs) = a + b · log10(Tage seit Genesis); je Monat kausal angepasst, Residuum, Lage in σ, Perzentil; Parameter je Monat in `mk_pl` | b = 5,8 gefunden (± 0,1); ohne Trend b ≈ 0; 4 σ → Perzentil > 99; kausal |
| 200-Wochen-MA (Trend, Coin wählbar) | 199 abgeschlossene Sonntagsschlüsse (UTC) + laufender Kurs, ÷ 200; Abstand und Perzentil | konstant = Kurs; Sonntag = Mittel der 200 Sonntage; Wochenmitte mit Tageskurs |
| Halving-Zyklen (Trend) | Kurs ÷ Kurs am Halving-Tag, Tag 0–1460 | Tag 534 am 06.10.2025; Halving-Tag zählt zur neuen Epoche |
| Kurzfrist-/Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR, AVIV (z), realisierte Verluste (Kohorten) | Werte von BGeometrics; Regime = Kurs über/unter der Linie; AVIV-z expandierend | Parser (Feldnamen, ms, Text-Zahlen); AVIV-z: Ausreißer > 10, Rauschen ≈ 0 |
| Puell Multiple (Miner) | Emission USD ÷ 365-Tage-Mittel; Perzentil innerhalb der Halving-Epoche | gleiche Emission → 1; Halbierung → 0,5 |
| Hash Ribbons (Miner) | SMA30 < SMA60 der Hashrate = Kapitulation; Erholung beim Kreuz; Kaufsignal nach Capriole (Kurs-SMA10 > SMA20); **Rauschschwelle 3 σ/√60** (σ = Tagesrauschen der Hashrate, 365 Tage vor der Episode) | Rückgang 15 % echt, mit Erholung und Signal; reines Rauschen σ 8 %: 1,2 % der Episoden über der Schwelle (Simulation 0,7 %) |
| Difficulty Ribbon (Miner) | SMA 9, 14, 25, 40, 60, 90, 128, 200 der Difficulty; Breite = größtes ÷ kleinstes − 1 | konstant → Breite 0; Rückgang → Breite > 5 % |
| Miner-Kostenbasis (Miner, Überblick) | siehe Abschnitt 4 | Prüfwert 50.383 USD je BTC; linear in der Difficulty |
| Funding (Hebel) | Tagessumme der Raten × 365 (% p. a.), 30-Tage-Mittel, Perzentil | 3 × 0,01 % → 10,95 % p. a.; doppelte Zeitpunkte einmal; nur abgeschlossene Tage |
| Open Interest ÷ Marktkap. (Hebel) | OI Binance (USD, Tagesbeginn) ÷ BTC-Marktkap. | Parser REST und Archiv (früheste Zeile) |
| DVOL, Fear & Greed (30 T), Wochen-RSI 14 (Hebel) | Tagesschluss; 30-Tage-Mittel; RSI nach Wilder auf Sonntagsschlüssen | Wilders Rechenbeispiel exakt (70,53 · 66,32 · 66,55 …); steigend 100, fallend 0 |
| Stablecoins, SSR (Kapitalfluss) | Summe aller Bindungen; SSR = BTC-Marktkap. ÷ Stablecoins; Perzentil | Handrechnung |
| ETF-Nettoflüsse (Kapitalfluss) | kumuliert ab Start, Summe 30 Tage | Farside-Parser (Klammern, Tausenderkomma, „-“) |
| Makro (Makro) | Nettoliquidität = WALCL − WTREGEN − RRP × 1000 (Mio USD → Bio); globaler Proxy = Fed + EZB × EUR/USD + BoJ × 100 ÷ JPY/USD (Veränderung zum Vorjahr); M2 zum Vorjahr; Realzins, Dollar, HY-Spread, Leitzins; Korrelation der Wochenänderung mit der BTC-Wochenrendite über 52 Wochen (M2: Monate, 24) | gleich +1, gespiegelt −1; unabhängig 0 ± 1/√51; Regimelabel nennt Zufallsband und Vorzeichenwechsel |

## 4. Miner-Kostenbasis (Szenario, keine Messung)

Stromkosten je BTC = J/TH × Strompreis × (Difficulty × 2³² ÷ 10¹² TH je Block) ÷ 3,6 · 10⁶ J/kWh ÷ (Emission + Gebühren je Block).
Erlös je Block aus Coin Metrics als 7-Tage-Summen (IssTotNtv + FeeTotNtv) ÷ BlkCnt — über dieselben Tage. Der Server liefert die
„Einheit“ (USD je BTC für 1 J/TH und 1 USD/kWh); der Browser rechnet das Szenario, also ohne neuen Abruf umschaltbar:
- Ausgangsszenario des Nutzers: **Antminer S21 XP (Luft) 13,5 J/TH bei 7,5 ct/kWh**. Standard US-Cent; Euro-Cent wird mit dem
  Tageskurs EUR/USD (FRED DEXUSEU) umgerechnet. Geräteliste: S21 XP Hydro 12, S21 Pro 15, S21 17,5, S19 XP 21,5, S19j Pro 29,5 J/TH
  oder eigener Wert; Aufschlag für sonstige Kosten in % (0 = nur Strom).
- Chart: Kurs, Szenario, Band Strompreis ± 2,5 ct, ältere Flotte S19 XP (21,5 J/TH) gestrichelt; darunter Kurs ÷ Kosten.
- Prüfwert (Selbsttest): Difficulty 1,318 · 10¹⁴, Erlös 3,16 BTC je Block → Einheit 49.761 → 50.383 USD je BTC.
- Kein Perzentil: Ein fester Gerätetyp über die ganze Historie ist kein Vergleichsmaßstab (2011 kostete ein BTC mit heutiger Technik
  fast nichts).

## 5. Darstellung (Abschnitt „MK Makro“)

- Tabs Überblick, Bewertung, Trend, Kohorten, Miner, Hebel & Stimmung, Kapitalfluss, Makro, Daten (Quellen, Abrufe, Frische je
  Reihe); eine Filterzeile oben
  (Zeitraum 1 J / 2 J / 4 J / 8 J / Alles; Coin dort, wo es zählt); gemerkt im Browser (`hl_makro`).
- Überblick: Satz aus den Positionen (MVRV, Power Law, Regime STH/TMM, 200-Wochen-MA, Halving-Tag; „kein Timing-Signal“),
  Zonenkarte (Tagesschluss, „jetzt“ mit dem Live-Kurs aus `bars`, Lage als Perzentil, Bezug, Einordnung; auf dem Handy als Karten),
  Chart „Kurs und Kostenbasen“.
- Ein generischer SVG-Chart (`mkZeichne`): eine y-Achse je Chart (nie zwei), Legende ab zwei Reihen, Endbeschriftung nur bis vier
  Reihen und ab 520 px, Fadenkreuz mit allen Reihen am Tag, Tabellenansicht je Chart (Monatsenden), Quelle unter jedem Chart.
- Farben: acht Kategorien in fester Reihenfolge (`#3987e5 #d95926 #199e70 #c98500 #d55181 #008300 #9085e9 #e66767`), mit dem
  Prüfskript für die dunkle Fläche `#01030a` geprüft (Helligkeitsband, Chroma, Farbsehschwäche benachbart ΔE ≥ 8,4, normal ≥ 19,3,
  Kontrast ≥ 3:1). Kurs neutral; die Farbe folgt dem Treiber (Realized Price immer blau, 200-Wochen-MA orange …).

## 6. Speicher und Takt

- `makro.db` neben `hl_liq.db` (wie `forecasts.db`, `adressfluss.db`); `HL_MAKRO_DB` lenkt um (Selbsttest). Tabellen: `mk_reihe`
  (reihe, ts in Sekunden, wert, abgerufen; ohne rowid), `mk_abruf` (Protokoll, 90 Tage), `mk_meta` (Zustand je Ziel, Budget, Cursor,
  Datenversion), `mk_stand` (Tagesstand der Zonenkarte, einmal je Tag), `mk_pl` (Power-Law-Parameter je Monat, einmal),
  `mk_signal` (seit 23.49: Tagesstand der Signale je Paar und Zeitraum, einmal je Tag, nie überschrieben).
- Schreiben nur im Makro-Takt (ein Thread im Dashboard, 90 s nach dem Start, dann alle 20 s fällige Ziele) und über
  `hl_makro.py --abrufen`; jede Transaktion `BEGIN IMMEDIATE`; gleiche Werte bleiben unberührt, Revisionen bekommen einen neuen
  Abrufzeitpunkt und erhöhen die Datenversion.
- Fehler je Ziel: Pause 15 min, verdoppelt bis 6 h; die anderen Ziele laufen weiter. Seit 23.48: Antwortet ein Host nicht
  (Zeitüberschreitung, Verbindungsfehler), überspringt die Runde die übrigen Ziele dieser Quelle, und sie pausieren mit; HTTP-Fehler
  einer Reihe sperren nichts. Aus mit `HL_MAKRO=0`; nie für Selbsttest-Datenbanken (`_selftest*`).
- FRED-Schlüssel (23.48): Feld im Tab „Daten“ (POST `/makro/fred_schluessel`) oder `--fred-schluessel`; Format 32 Zeichen a–z0–9,
  Probeabruf vor dem Speichern, abgelehnte Schlüssel werden nicht geschrieben, die FRED-Pausen werden zurückgesetzt. Der Schlüssel
  erscheint nie in Fehlertexten, Protokoll, Antwort oder Adresse.
- Dashboard: `/makro?tab=…&coin=…` (Zwischenspeicher je Datenversion, höchstens alle 10 min neu gerechnet, Einzelflug, Antwort-Cache
  60 s), `/makro.js`. Fehlt `makro.db`, kommt ein Hinweis — angelegt wird beim Lesen nichts.
- Sicherung: Der Recorder sichert `makro.db` mit dem täglichen Backup als `makro_backup.db` (plus eine Generation).
- **Frische je Reihe** (Abnahme U121): Alter des letzten Werts (heute UTC minus letzter Tag) gegen eine Grenze je Quelle — Coin
  Metrics 5 Tage (Bewertung erst bei T−2), alternative.me, DefiLlama, Deribit, Binance 4, Blockchain.com 5, BGeometrics 9 (frei
  7 Tage Verzug; bis 23.47 fälschlich 6), Farside 7
  (Wochenenden, Feiertage), FRED täglich 10, wöchentlich veröffentlicht (Wechselkurse, Dollar, Fed-Bilanz, TGA) 14, EZB 21, M2 und
  BoJ (monatlich, rund vier Wochen Verzug, auf den Monatsersten datiert) 100. Dazu „fehlt“: eine Reihe, die ein schon erfolgreich
  abgerufenes Ziel liefern müsste, aber nicht gibt (Metrik aus dem freien Katalog oder Feld verschwunden; vor dem ersten Erfolg
  kein Befund). Sichtbar im Tab „Daten“ (Spalten Alter und Grenze, Warnzeile) und im Stand (Debug, Wochenbericht W14). Grund: Wenn
  eine Metrik verschwindet oder eine Seite ihr Format ändert, scheitert oft kein Abruf — die Reihe bleibt nur stehen.

## 7. Proben (23.47)

- `python3 hl_makro.py --selbsttest`: 49 Prüfungen in rund 3 s (Mathematik je Treiber, Parser, Zeitplan mit falschem Netz und
  springender Uhr, Gesamtrechnung mit Kausalität, Nutzlast je Tab, Archiv, Frische und fehlende Reihen mit fester Uhr; seit 23.48
  FRED über API, Schlüssel geschwärzt, Abbruch je Quelle, Einrichten des Schlüssels). Eigener
  Schritt im Installations-Selbsttest (nach dem Magnet-Test; der Selbsttest hat damit 31 Schritte).
- Mutationen: 37 von 37 rot (u. a. Blick nach vorn im Power Law, Realized Price ohne MVRV, 200 statt 199 Wochen, Funding × 3,
  angefangener Tag, RSI-Glättung, Rauschschwelle 1, Budget 8/h, Fehler ohne Pause, Erstabruf ohne Historie; Frische: Grenze nie
  erreicht, Monatswerte ohne eigene Grenze, Alter vom ersten Tag, Fehlen vor dem ersten Abruf; 23.48: Schlüssel ignoriert, nichts
  geschwärzt, kein Abbruch je Quelle, Übersprungene ohne Pause, HTTP-Antwort als Netzfehler, Umgebung ignoriert, Format nicht
  geprüft, Abgelehntes geschrieben, Pausen nicht zurück, BGeometrics-Grenze 6).
- Rückrechnung mit echten Coin-Metrics-Daten (öffentlicher GitHub-Spiegel bis 24.05.2026) gegen den Bericht: 06.10.2025 MVRV 2,287,
  Realized Price 54.576,53 USD, MVRV-Z 2,53, Puell 1,07; 11.03.2024 MVRV 2,776, Puell 2,43; 21.11.2022 MVRV 0,778, Realized Price
  20.290,85; Epochen-Hochs 7,74 · 5,88 · 4,72 · 3,96 · 2,74, Tiefs 0,39 · 0,56 · 0,69 · 0,75; Power-Law-Exponent über alle Tage 5,674
  (Perrenod 5,674), Anpassung bis 09/2019 5,822 (Burger 5,845); Kurs ÷ Fair Value (Burger) am ATH 0,949. Hash Ribbons über der
  Rauschschwelle seit 2017: 11/2018, 03/2020, 05/2020, 10/2020, 06/2021 (−19,3 %), 07/2022, 11/2022, 01–02/2026 mit Kaufsignal
  05.03.2026 (Recherche: CoinDesk 25.02.2026), 03–05/2026.
- Sichtprüfung aller Tabs in Desktop- und Handybreite (Playwright), keine Skriptfehler, keine waagrechte Seitenbreite über den Rand;
  Fadenkreuz-Tooltip in Überblick, Miner und Makro geprüft; Tab „Daten“ mit Warnzeile und den Spalten Alter/Grenze direkt neben
  dem Reihennamen (am Handy ohne Seitwärtsschieben sichtbar).

- 23.49 (Signale): `python3 hl_makro_signal.py --selbsttest` 12 Prüfungen in rund 3 s; `hl_makro.py --selbsttest` jetzt 52 (neu:
  Signale je Tab, Kausalität der ganzen Kette, Live gegen Nachrechnung mit echter Ableitung). Einzelheiten in Abschnitt 9.

## 8. Grenzen und offene Punkte

- **Erster Pi-Lauf 05.10. (Bild 12:14):** Coin Metrics, alternative.me, DefiLlama, Blockchain.com, Deribit, Binance (Funding, OI,
  Archiv), Farside und BGeometrics liefern; ihre Formate sind belegt. FRED ohne Schlüssel hängt (→ API mit Schlüssel, 23.48); ob
  `api.stlouisfed.org` vom Pi antwortet, zeigt erst der eingetragene Schlüssel. Bericht `u121-makro-erstlauf` am 06.10. 20:15
  (Debug „Makro: Stand und Quellen“).
- BGeometrics liefert frei nur 4 Jahre und ohne die jüngsten 7 Tage; die Regimezeile vergleicht deshalb den Live-Kurs mit einer
  7 Tage alten Linie. Seine Werte weichen methodisch von Glassnode ab (Entitäten, Börsen-Etiketten).
- Power Law ist eine Beschreibung, kein Gesetz: Exponent driftete 5,845 → 5,674; die Oberseite schrumpft (Top 2025 bei ~1× Fair
  Value), die Unterseite lag bisher bei 0,34–0,51×.
- Perzentile über die ganze Historie gegenüber 4-Jahres-Fenster oder 2-Jahres-σ: welches besser trifft, ist außerhalb der
  Stichprobe ungeprüft — deshalb beide (MVRV) bzw. das kausale Gesamtperzentil.
- Halving-Overlay und Bewertungsdivergenz sind Zeitachse bzw. Hypothese, kein Fahrplan.
- `migrate_db.py` verschiebt `makro.db` nicht mit (wie `adressfluss.db`); nach einem Umzug von Hand mitnehmen.
- Frische-Grenzen sind aus Veröffentlichungsrhythmen abgeleitet, nicht gemessen. Ein Fehlalarm ist nur eine Warnzeile; nach vier
  Wochen Betrieb gegen die echten Abstände prüfen (U123).
- Signale (Abschnitt 9): Die Bilanz ist nachgerechnet; ob sie dem Live-Stand entspricht, zeigt erst das Archiv `mk_signal` auf dem Pi
  (U127). Rechenzeit auf dem Pi nicht gemessen (Sandbox 4 s).

## 9. Signale je Chart (U126, seit 23.49)

Wunsch des Nutzers (05.10. 13:59): je Chart die Abweichung zur Referenzlinie in %, ideale Kauf- und Verkaufspunkte je Zeitskala,
den „optimalen Median“ und einen extrapolierten Wert; für alle Charts, täglich. Entscheidungen auf Rückfrage: alle Charts mit
Referenzlinie; Rückblick und Live getrennt; Median der Abweichung; Rückkehr zum Median, 3/6/12 Monate mit 80-%-Band.

**9.1 Paare.** 14 Reihen gegen ihre Referenzlinie, je Zeitraum 1 J, 2 J, 4 J, 8 J und alles (nur bei Historie ≥ 90 % des Zeitraums):

| Tab | Paar | Referenz fortgeschrieben mit |
|---|---|---|
| Bewertung | Kurs gegen Realized Price (BTC, ETH, ZEC); Kurs gegen Delta Price (BTC) | Trend der letzten 365 Tage |
| Trend | Kurs gegen Power-Law-Fair-Value (kausal, Anpassung je Monat); Kurs gegen 200-Wochen-MA (BTC, ETH, ZEC, XMR) | Power Law mit den Parametern des Monats; Trend 365 Tage |
| Kohorten | Kurs gegen Kurzfrist-Kostenbasis, True Market Mean, Langfrist-Kostenbasis (BTC, BGeometrics, 7 Tage Verzug) | Trend 365 Tage |
| Miner | Kurs gegen Stromkosten S21 XP bei 7,5 ct (nur 1, 2, 4 J: ein fester Gerätetyp ist über 8 Jahre kein Maßstab); Puell gegen 1 | Trend 365 Tage; konstant 1 |

**9.2 Rechnung je Paar und Zeitraum** (`hl_makro_signal.paar_signal`):
- Abweichung y = ln(Reihe ÷ Referenz); angezeigt e^y − 1 in % (symmetrisch rechnen, verständlich zeigen).
- Median von y im Zeitraum — Mittellinie im Haupt- und Signal-Chart.
- Rückblick: Minimum, Maximum, Wendepunkte per Zickzack auf dem zentrierten 7-Tage-Mittel (nur hier zentriert; das Live-Signal nutzt
  es nie). Mindestwende θ = max(5 %, (P90 − P10)/2) im Zeitraum. Der erste Extremwert am Rand und der letzte, unbestätigte fehlen.
  Erst im Nachhinein bekannt.
- Live-Signal: rollierendes Perzentil von y unter den letzten W Tagen bis einschließlich heute (W = 0: seit Beginn; mindestens 292
  Werte), Gleichstände gemittelt. Kauf bei ≤ 10, Verkauf bei ≥ 90 — feste Ränder, nicht auf die Historie angepasst. Auf Rauschen
  liegen je 10 % der Tage in jeder Zone (Probe).
- Bilanz: Episoden (Signaltage mit höchstens 30 Tagen Abstand), Einstieg am ersten Tag, Rendite nach 90/180/365 Tagen
  (geometrisches Mittel). Nullverteilung: je Episode ein Zufallstag aus ±(Horizont + 365) Tagen um den Einstieg, 1000-mal;
  p einseitig in Richtung der Seite; „belegt“ bei p < 0,025, mindestens 3 Episoden.
- Prognose: AR(1) auf x = y − Median (nur aufeinanderfolgende Tage), φ ≤ 1 gekappt; Erwartung μ + φ^h (y₀ − μ); Halbwertszeit
  ln 0,5 / ln φ mit 90-%-Intervall aus dem Standardfehler; Dickey-Fuller-t < −2,86 = Rückkehr belegt. Wert = fortgeschriebene
  Referenz × e^y. Band: 10.–90. Perzentil der eigenen Fehler (ln Ist − ln Prognose, inklusive Fortschreibung der Referenz) aus den
  Ursprüngen der letzten 4 Jahre, deren Ziel bekannt ist; unter 20 Fehlern das AR(1)-Modellband (gekennzeichnet).
- Rückblick-Prüfung: Ursprünge alle 30 Tage, an jedem nur Daten bis dahin (Median, AR(1), Referenztrend); Abdeckung des Bands
  außerhalb der Stichprobe (erst ab 20 Prüfungen genannt), Fehler gegen „die Abweichung bleibt“.

**9.3 Betrieb.** `hl_makro.signale(D)` einmal je Datentag (Zwischenspeicher, eigenes Schloss, Fehler → Charts laufen ohne Signale);
der Makro-Takt schreibt den Tagesstand nach `mk_signal` (Tag, Paar, Zeitraum, Signal, Perzentil, Abweichung, Median, Prognose
365 T, Zeitpunkt; `INSERT OR IGNORE`). **Live gegen Nachrechnung** (`hl_makro_signal.nachrechnung`): jede archivierte Zeile früherer
Tage gegen das Perzentil der heutigen Rechnung für denselben Tag (± 0,01, Signal gleich); Anzeige unter der Signaltabelle, im Stand
und im Wochenbericht. Nutzlast je Signal-Tab: `signale` (Blöcke je Paar; ganze Perzentil-Reihen bleiben im Speicher, nie in der
Nutzlast) und `signal_regeln` (Schwellen, Horizonte, Stand, Nachrechnung).

**9.4 Kalibrierung (vor der Auslieferung).**
- Block-Bootstrap über alle Signaltage: 26–41 % Fehlurteile auf Zufallswegen (Soll 10 %) — Läufe, in denen der Kurs weiter fällt,
  sind länger und zählen mit mehr Tagen. Längere Blöcke und zirkulär verschobene Placebos ebenso daneben. Episoden mit lokalem
  Placebo: 3,2 % (5 von 158); Ära-Nulltest (Niveau der Abweichung und Drift wechseln gemeinsam) 4 von 80, mit Zufallstagen aus der
  ganzen Historie 16–27 von 80.
- Modellband (AR(1)) zu schmal; Band aus allen Jahren zu breit (bis 97 %) → Fehler der letzten 4 Jahre, eine Regel für Prüfung und
  heutiges Band. Wachsende Schwankung: Abdeckung 71 % (ein Band, das spätere Fehler kennt, träfe genau 80 %).

**9.5 Ergebnis auf echten Daten** (Coin Metrics bis 23.05.2026, Test-Kopie): 63 Paar-Zeiträume in 4,0 s. Bilanz 3 von 322 Tests
belegt (Zufall allein ≈ 16): Power Law 4 J Kauf 90 T (+56 % gegen +13 %, p 0,014, 7 Episoden), XMR 200-W-MA 8 J/alles Verkauf
90 T (−21 % gegen +12 %, 4 Episoden). Nach Verkaufssignalen lag die Rendite im Median 5,3 Punkte über den Zufallstagen (64 % der
Tests; Momentum), nach Kaufsignalen +1,3 Punkte (52 %). Prognose besser als „bleibt“ in 83/78/78 % (90/180/365 T), Median-Fehler
15/16/19 % kleiner; Band traf 81/83/85 % (Soll 80). Rückkehr nach Dickey-Fuller belegt in 14 von 63. Nachrechnung: Stände vom
06.10.2025, 05.02., 01.04., 01.05.2026 (Datei nur bis dahin) gegen alle Daten 249 von 249 gleich.

**9.6 Proben.** Signal-Selbsttest (12): Perzentil gegen unabhängige Nachrechnung, kausal, Zehntel auf Rauschen; Zickzack; Bilanz
Positivkontrolle (23 von 24), Nulltest Zufallsweg (≤ 6 %), Nulltest Ära (≤ 10 %); Prognose Positivkontrolle (φ, Halbwertszeit,
Abdeckung 70–90 %, besser als „bleibt“), Nulltest Zufallsweg (nicht besser als „bleibt“, Formeln exakt), Band ehrlich (wachsende
Schwankung < 76 %), Band folgt 4 Jahren (Schwankungssprung); Referenz nur aus der Vergangenheit, Power Law des Ursprungsmonats;
Block (JSON, Median, Prognoseziel, Rückblick trotz Rauschen); Nachrechnung (gleich, Revision erkannt). Im Makro-Selbsttest
zusätzlich: Signale je Tab, Kausalität der ganzen Kette (Zukunft × 50, 44 Perzentil-Reihen bitgleich), Nachrechnung mit echter
Ableitung (Revision des BTC-MVRV nur in `rp:BTC` und `delta:BTC`). Mutationen: 36 von 36 rot (Signal-Code und Signal-Teil von `hl_makro.py`), `hl_makro.py` erneut 37 von 37.

**9.7 Grenzen.** Die Zonen beschreiben eine Lage; ein Beleg für Timing fehlt. Viele Tests: etwa jeder zwanzigste ist zufällig
belegt. Die Tests je Paar sind nicht unabhängig (überlappende Zeiträume und Horizonte). Die Prognose setzt eine Rückkehr zum
Median voraus; wo Dickey-Fuller sie nicht belegt, ist die Erwartung nur so gut wie „bleibt“ plus Referenztrend. Der Referenztrend
der letzten 365 Tage schreibt Kostenbasen fort, die in Wenden knicken.
