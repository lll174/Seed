#!/usr/bin/env python3
"""
hl_backtest.py — Backtest-Framework für eine Trendfolge-Strategie auf Hyperliquid-Perps.

Strategie: Donchian-Breakout mit EMA-Trendfilter und ATR-Trailing-Stop.
  - Long-Entry  : Close > Hoch der letzten N Bars UND Close > EMA(trend)
  - Short-Entry : Close < Tief  der letzten N Bars UND Close < EMA(trend)
  - Exit        : ATR-Trailing-Stop oder Gegensignal
  - Sizing      : Risiko-basiert — pro Trade wird risk_pct des Equity riskiert,
                  begrenzt durch max_leverage.

Realismus-Annahmen (bewusst konservativ):
  - Signal entsteht am CLOSE von Bar t, Ausführung am OPEN von Bar t+1 (kein Lookahead).
  - Slippage + Taker-Gebühren auf beiden Seiten.
  - Funding wird optional aus der echten fundingHistory gerechnet (Hyperliquid
    settled stündlich), sonst über eine pauschale Jahresrate approximiert.
  - Stop-Prüfung intrabar über High/Low; öffnet die Bar jenseits des Stops,
    wird zum Open gefüllt (nicht zum Stop-Preis).

Wichtig: candleSnapshot liefert nur die letzten ~5000 Kerzen. Für mehrjährige
Historie also "4h" oder "1d" verwenden, nicht "1m"/"5m".

Nutzung:
    python hl_backtest.py --coin BTC --interval 1h --days 200
    python hl_backtest.py --coin ETH --interval 4h --days 700 --funding
    python hl_backtest.py --coin BTC --interval 4h --days 700 --sweep
    python hl_backtest.py --synthetic            # offline-Testlauf ohne API
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import os
import time
import urllib.request
from dataclasses import dataclass, field, asdict
from typing import Iterable

import numpy as np
import pandas as pd

INFO_URL = "https://api.hyperliquid.xyz/info"
CACHE_DIR = "data"

INTERVAL_MS = {
    "1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000, "30m": 1_800_000,
    "1h": 3_600_000, "2h": 7_200_000, "4h": 14_400_000, "8h": 28_800_000,
    "12h": 43_200_000, "1d": 86_400_000, "3d": 259_200_000, "1w": 604_800_000,
}


# --------------------------------------------------------------------------
# Daten
# --------------------------------------------------------------------------

def _post(payload: dict, retries: int = 4) -> list | dict:
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        INFO_URL, data=body, headers={"Content-Type": "application/json"}
    )
    last = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:  # Rate-Limit / Netzwerk
            last = e
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"API-Request fehlgeschlagen: {last}")


def fetch_candles(coin: str, interval: str, days: int, use_cache: bool = True) -> pd.DataFrame:
    """Holt OHLCV-Kerzen und paginiert vorwärts durch den Zeitraum."""
    if interval not in INTERVAL_MS:
        raise ValueError(f"Unbekanntes Intervall: {interval}")

    os.makedirs(CACHE_DIR, exist_ok=True)
    cache = os.path.join(CACHE_DIR, f"{coin}_{interval}_{days}d.csv")
    if use_cache and os.path.exists(cache):
        age_h = (time.time() - os.path.getmtime(cache)) / 3600
        if age_h < 6:
            df = pd.read_csv(cache, parse_dates=["time"])
            return df.set_index("time")

    step = INTERVAL_MS[interval]
    end = int(time.time() * 1000)
    start = end - days * 86_400_000

    rows: list[dict] = []
    cursor = start
    while cursor < end:
        chunk_end = min(cursor + step * 4900, end)
        data = _post({
            "type": "candleSnapshot",
            "req": {"coin": coin, "interval": interval,
                    "startTime": cursor, "endTime": chunk_end},
        })
        if not data:
            break
        rows.extend(data)
        newest = max(int(c["t"]) for c in data)
        if newest <= cursor:
            break
        cursor = newest + step
        time.sleep(0.25)  # Rate-Limit schonen

    if not rows:
        raise RuntimeError(
            f"Keine Kerzen für {coin}/{interval} erhalten. "
            "Coin-Symbol prüfen (z. B. 'BTC', 'ETH', 'SOL')."
        )

    df = pd.DataFrame(rows).drop_duplicates(subset="t").sort_values("t")
    df["time"] = pd.to_datetime(df["t"], unit="ms", utc=True)
    for c in ("o", "h", "l", "c", "v"):
        df[c] = df[c].astype(float)
    df = df.rename(columns={"o": "open", "h": "high", "l": "low",
                            "c": "close", "v": "volume"})
    df = df[["time", "open", "high", "low", "close", "volume"]].set_index("time")

    df.reset_index().to_csv(cache, index=False)
    print(f"  {len(df)} Kerzen: {df.index[0]:%Y-%m-%d} bis {df.index[-1]:%Y-%m-%d}")
    return df


def fetch_funding(coin: str, start_ms: int, end_ms: int) -> pd.Series:
    """Stündliche Funding-Raten. Positiv = Longs zahlen."""
    rows, cursor = [], start_ms
    while cursor < end_ms:
        data = _post({"type": "fundingHistory", "coin": coin,
                      "startTime": cursor, "endTime": end_ms})
        if not data:
            break
        rows.extend(data)
        newest = max(int(d["time"]) for d in data)
        if newest <= cursor:
            break
        cursor = newest + 1
        time.sleep(0.25)
        if len(rows) > 60_000:
            break
    if not rows:
        return pd.Series(dtype=float)
    df = pd.DataFrame(rows).drop_duplicates(subset="time")
    idx = pd.to_datetime(df["time"], unit="ms", utc=True)
    return pd.Series(df["fundingRate"].astype(float).values, index=idx).sort_index()


def spot_universe() -> dict[str, str]:
    """Mapping Token-Name -> Spot-Kerzen-Symbol ("@107" o. Ä.)."""
    meta = _post({"type": "spotMeta"})
    tokens = {t["index"]: t["name"] for t in meta["tokens"]}
    out: dict[str, str] = {}
    for pair in meta["universe"]:
        base, quote = pair["tokens"][0], pair["tokens"][1]
        if quote != 0:                       # nur USDC-Paare
            continue
        name = tokens.get(base, "?")
        # PURR ist der einzige Sonderfall mit Klarnamen
        out[name] = "PURR/USDC" if name == "PURR" else f"@{pair['index']}"
    return out


def resolve_spot_coin(name: str) -> str:
    """'HYPE' -> '@107'. Akzeptiert auch direkt '@107'."""
    if name.startswith("@") or "/" in name:
        return name
    uni = spot_universe()
    if name in uni:
        return uni[name]
    # UI-Namen weichen teils vom L1-Namen ab (BTC/USDC in der App = UBTC auf HyperCore)
    for alt in (f"U{name}", f"{name}0"):
        if alt in uni:
            print(f"  Hinweis: '{name}' ist auf HyperCore '{alt}'.")
            return uni[alt]
    near = sorted(k for k in uni if name.upper() in k.upper())[:15]
    raise ValueError(
        f"Spot-Token '{name}' nicht gefunden. Ähnlich: {near or 'nichts'}\n"
        f"  Vollständige Liste mit: python hl_backtest.py --list-spot"
    )


def synthetic_data(n: int = 4000, seed: int = 7) -> pd.DataFrame:
    """Offline-Testdaten: GBM mit Trendphasen — nur zum Prüfen der Engine."""
    rng = np.random.default_rng(seed)
    drift = np.repeat(rng.normal(0, 0.0006, n // 200 + 1), 200)[:n]
    ret = drift + rng.normal(0, 0.012, n)
    close = 30_000 * np.exp(np.cumsum(ret))
    noise = np.abs(rng.normal(0, 0.004, n)) * close
    df = pd.DataFrame({
        "open": np.r_[close[0], close[:-1]],
        "high": close + noise,
        "low": close - noise,
        "close": close,
        "volume": rng.uniform(50, 500, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="4h", tz="UTC"))
    df["high"] = df[["high", "open", "close"]].max(axis=1)
    df["low"] = df[["low", "open", "close"]].min(axis=1)
    return df


# --------------------------------------------------------------------------
# Indikatoren
# --------------------------------------------------------------------------

def atr(df: pd.DataFrame, n: int) -> pd.Series:
    prev = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


# --------------------------------------------------------------------------
# Konfiguration
# --------------------------------------------------------------------------

@dataclass
class Config:
    # Strategie
    donchian: int = 40          # Lookback für Ausbruchskanal
    ema_trend: int = 200        # Trendfilter
    atr_len: int = 20
    atr_stop: float = 3.0       # Trailing-Stop-Abstand in ATR
    allow_short: bool = True
    is_spot: bool = False       # Spot: long-only, kein Hebel, kein Funding

    # Risiko
    equity0: float = 10_000.0
    risk_pct: float = 0.01      # 1 % Equity-Risiko pro Trade
    max_leverage: float = 3.0
    max_dd_stop: float = 0.35   # Kill-Switch: Backtest endet bei -35 % Drawdown

    # Kosten
    fee: float = 0.00045        # Taker, Basis-Tier
    slippage: float = 0.0005    # 5 bps pro Seite
    funding_apr: float = 0.10   # Pauschale, falls keine echten Funding-Daten

    bars_per_year: float = 2190.0  # wird aus dem Intervall gesetzt


@dataclass
class Trade:
    side: int
    entry_time: pd.Timestamp
    entry: float
    exit_time: pd.Timestamp = None
    exit: float = 0.0
    qty: float = 0.0
    pnl: float = 0.0
    r_multiple: float = 0.0
    reason: str = ""
    bars: int = 0


@dataclass
class Result:
    equity: pd.Series
    trades: list[Trade] = field(default_factory=list)
    stats: dict = field(default_factory=dict)


# --------------------------------------------------------------------------
# Backtest-Engine
# --------------------------------------------------------------------------

def backtest(df: pd.DataFrame, cfg: Config,
             funding: pd.Series | None = None) -> Result:
    d = df.copy()
    d["ema"] = d["close"].ewm(span=cfg.ema_trend, adjust=False).mean()
    d["atr"] = atr(d, cfg.atr_len)
    d["hh"] = d["high"].rolling(cfg.donchian).max().shift(1)
    d["ll"] = d["low"].rolling(cfg.donchian).min().shift(1)

    o = d["open"].to_numpy(); h = d["high"].to_numpy()
    lo = d["low"].to_numpy(); c = d["close"].to_numpy()
    ema = d["ema"].to_numpy(); a = d["atr"].to_numpy()
    hh = d["hh"].to_numpy(); ll = d["ll"].to_numpy()
    idx = d.index
    n = len(d)

    # Funding pro Bar aufsummieren (Hyperliquid settled stündlich)
    if cfg.is_spot:
        fund_bar = np.zeros(n)               # Spot kennt kein Funding
    elif funding is not None and len(funding) > 0:
        fund_bar = funding.reindex(idx, method=None)
        fund_bar = funding.resample(_freq(idx)).sum().reindex(idx).fillna(0.0).to_numpy()
    else:
        per_bar = cfg.funding_apr / cfg.bars_per_year
        fund_bar = np.full(n, per_bar)

    warmup = max(cfg.donchian, cfg.ema_trend, cfg.atr_len) + 2
    equity = cfg.equity0
    peak = equity
    curve = np.full(n, np.nan)

    side = 0
    qty = 0.0
    mark = 0.0
    stop = 0.0
    init_risk = 0.0
    pending = 0          # gewünschte Position für die nächste Bar
    trades: list[Trade] = []
    cur: Trade | None = None
    bars_in_pos = 0
    halted = False

    def close_pos(px: float, t, reason: str):
        nonlocal equity, side, qty, mark, cur, bars_in_pos
        fill = px * (1 - cfg.slippage) if side > 0 else px * (1 + cfg.slippage)
        equity += side * qty * (fill - mark)
        equity -= abs(qty) * fill * cfg.fee
        cur.exit_time, cur.exit, cur.reason = t, fill, reason
        cur.pnl = side * qty * (fill - cur.entry) - abs(qty) * (cur.entry + fill) * cfg.fee
        cur.r_multiple = cur.pnl / init_risk if init_risk > 0 else 0.0
        cur.bars = bars_in_pos
        trades.append(cur)
        cur, side, qty, mark, bars_in_pos = None, 0, 0.0, 0.0, 0

    def open_pos(direction: int, px: float, t, atr_val: float):
        nonlocal equity, side, qty, mark, stop, cur, init_risk, bars_in_pos
        dist = cfg.atr_stop * atr_val
        if dist <= 0 or not np.isfinite(dist):
            return
        size = (equity * cfg.risk_pct) / dist
        fill = px * (1 + cfg.slippage) if direction > 0 else px * (1 - cfg.slippage)
        size = min(size, equity * cfg.max_leverage / fill)
        if size * fill < 10:  # Mindestordergröße
            return
        equity -= size * fill * cfg.fee
        side, qty, mark = direction, size, fill
        stop = fill - dist if direction > 0 else fill + dist
        init_risk = size * dist
        bars_in_pos = 0
        cur = Trade(side=direction, entry_time=t, entry=fill, qty=size)

    for i in range(warmup, n):
        # ---- 1. Order aus dem Signal der Vorbar am Open ausführen
        if pending != side and not halted:
            if side != 0:
                close_pos(o[i], idx[i], "signal")
            if pending != 0 and np.isfinite(a[i - 1]):
                open_pos(pending, o[i], idx[i], a[i - 1])
        pending = side

        # ---- 2. Stop intrabar prüfen
        if side > 0 and lo[i] <= stop:
            close_pos(min(o[i], stop), idx[i], "stop")
            pending = 0
        elif side < 0 and h[i] >= stop:
            close_pos(max(o[i], stop), idx[i], "stop")
            pending = 0

        # ---- 3. Mark-to-Market + Funding
        if side != 0:
            equity += side * qty * (c[i] - mark)
            mark = c[i]
            equity -= side * qty * c[i] * fund_bar[i]  # Longs zahlen bei positivem Funding
            bars_in_pos += 1

        curve[i] = equity
        peak = max(peak, equity)
        if equity <= 0 or (peak - equity) / peak > cfg.max_dd_stop:
            if side != 0:
                close_pos(c[i], idx[i], "kill-switch")
            halted = True
            curve[i:] = equity
            break

        # ---- 4. Trailing-Stop nachziehen
        if side > 0:
            stop = max(stop, c[i] - cfg.atr_stop * a[i])
        elif side < 0:
            stop = min(stop, c[i] + cfg.atr_stop * a[i])

        # ---- 5. Signal am Close berechnen -> gilt für die nächste Bar
        if not halted:
            long_ok = c[i] > hh[i] and c[i] > ema[i]
            short_ok = cfg.allow_short and c[i] < ll[i] and c[i] < ema[i]
            if side == 0:
                pending = 1 if long_ok else (-1 if short_ok else 0)
            elif side > 0 and short_ok:
                pending = -1
            elif side < 0 and long_ok:
                pending = 1
            else:
                pending = side

    eq = pd.Series(curve, index=idx).ffill().fillna(cfg.equity0)
    return Result(equity=eq, trades=trades, stats=compute_stats(eq, trades, cfg, d))


def _freq(idx: pd.DatetimeIndex) -> str:
    delta = (idx[1] - idx[0]).total_seconds()
    return f"{int(delta)}s"


# --------------------------------------------------------------------------
# Kennzahlen
# --------------------------------------------------------------------------

def compute_stats(eq: pd.Series, trades: list[Trade],
                  cfg: Config, d: pd.DataFrame) -> dict:
    ret = eq.pct_change().fillna(0.0)
    years = max((eq.index[-1] - eq.index[0]).days / 365.25, 1e-9)
    total = eq.iloc[-1] / cfg.equity0 - 1
    cagr = (eq.iloc[-1] / cfg.equity0) ** (1 / years) - 1 if eq.iloc[-1] > 0 else -1.0

    sd = ret.std()
    sharpe = (ret.mean() / sd * math.sqrt(cfg.bars_per_year)) if sd > 0 else 0.0
    neg = ret[ret < 0].std()
    sortino = (ret.mean() / neg * math.sqrt(cfg.bars_per_year)) if neg and neg > 0 else 0.0

    dd = (eq / eq.cummax() - 1)
    maxdd = dd.min()

    wins = [t for t in trades if t.pnl > 0]
    losses = [t for t in trades if t.pnl <= 0]
    gross_w = sum(t.pnl for t in wins)
    gross_l = abs(sum(t.pnl for t in losses))

    bh = d["close"].iloc[-1] / d["close"].iloc[0] - 1

    return {
        "Endkapital": round(eq.iloc[-1], 2),
        "Gesamtrendite": f"{total:.1%}",
        "CAGR": f"{cagr:.1%}",
        "Buy&Hold": f"{bh:.1%}",
        "Sharpe": round(sharpe, 2),
        "Sortino": round(sortino, 2),
        "Max Drawdown": f"{maxdd:.1%}",
        "Calmar": round(cagr / abs(maxdd), 2) if maxdd < 0 else 0.0,
        "Trades": len(trades),
        "Trefferquote": f"{len(wins)/len(trades):.1%}" if trades else "—",
        "Profit-Faktor": round(gross_w / gross_l, 2) if gross_l > 0 else float("inf"),
        "Ø R-Multiple": round(np.mean([t.r_multiple for t in trades]), 2) if trades else 0.0,
        "Ø Haltedauer (Bars)": round(np.mean([t.bars for t in trades]), 1) if trades else 0.0,
        "_cagr": cagr, "_sharpe": sharpe, "_maxdd": maxdd, "_n": len(trades),
    }


def print_stats(stats: dict, title: str = "Ergebnis") -> None:
    print(f"\n{title}")
    print("-" * 46)
    for k, v in stats.items():
        if not k.startswith("_"):
            print(f"  {k:<22} {v}")


# --------------------------------------------------------------------------
# Parameter-Sweep mit Walk-Forward-Split
# --------------------------------------------------------------------------

def sweep(df: pd.DataFrame, cfg: Config, funding=None, split: float = 0.65) -> pd.DataFrame:
    """Optimiert in-sample, berichtet out-of-sample. Nur die OOS-Zahlen zählen."""
    cut = int(len(df) * split)
    is_df, oos_df = df.iloc[:cut], df.iloc[cut:]
    print(f"\nIn-Sample  : {is_df.index[0]:%Y-%m-%d} – {is_df.index[-1]:%Y-%m-%d}")
    print(f"Out-of-Sample: {oos_df.index[0]:%Y-%m-%d} – {oos_df.index[-1]:%Y-%m-%d}")

    grid = list(itertools.product(
        [20, 30, 40, 55, 80],       # donchian
        [100, 150, 200],            # ema_trend
        [2.0, 3.0, 4.0],            # atr_stop
    ))
    rows = []
    for don, ema_n, stp in grid:
        c = Config(**{**asdict(cfg), "donchian": don, "ema_trend": ema_n, "atr_stop": stp})
        r_is = backtest(is_df, c, funding)
        r_oos = backtest(oos_df, c, funding)
        rows.append({
            "donchian": don, "ema": ema_n, "atr_stop": stp,
            "IS_CAGR": r_is.stats["_cagr"], "IS_Sharpe": r_is.stats["_sharpe"],
            "OOS_CAGR": r_oos.stats["_cagr"], "OOS_Sharpe": r_oos.stats["_sharpe"],
            "OOS_MaxDD": r_oos.stats["_maxdd"], "OOS_Trades": r_oos.stats["_n"],
        })
    out = pd.DataFrame(rows).sort_values("IS_Sharpe", ascending=False)
    print("\nTop 10 nach In-Sample-Sharpe (OOS-Spalten sind das, was zählt):")
    print(out.head(10).to_string(index=False,
          float_format=lambda x: f"{x:,.2f}"))
    corr = out["IS_Sharpe"].corr(out["OOS_Sharpe"])
    print(f"\nKorrelation IS- vs. OOS-Sharpe: {corr:.2f}")
    print("  < 0.3 heißt: die Parameter-Wahl ist weitgehend Rauschen.")
    return out


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Hyperliquid Trendfolge-Backtest")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--interval", default="4h", choices=list(INTERVAL_MS))
    p.add_argument("--days", type=int, default=700)
    p.add_argument("--equity", type=float, default=10_000)
    p.add_argument("--risk", type=float, default=0.01, help="Risiko pro Trade")
    p.add_argument("--donchian", type=int, default=40)
    p.add_argument("--ema", type=int, default=200)
    p.add_argument("--atr-stop", type=float, default=3.0)
    p.add_argument("--no-short", action="store_true")
    p.add_argument("--spot", action="store_true",
                   help="Spot statt Perps: long-only, kein Hebel, kein Funding")
    p.add_argument("--list-spot", action="store_true",
                   help="verfügbare Spot-Paare auflisten und beenden")
    p.add_argument("--fee", type=float, default=None,
                   help="Taker-Gebühr, Default 0.00045 (Perp) / 0.0007 (Spot)")
    p.add_argument("--slippage", type=float, default=None,
                   help="pro Seite, Default 0.0005 (Perp) / 0.0015 (Spot)")
    p.add_argument("--funding", action="store_true", help="echte Funding-Historie laden")
    p.add_argument("--sweep", action="store_true")
    p.add_argument("--synthetic", action="store_true", help="offline mit Testdaten")
    p.add_argument("--plot", action="store_true")
    args = p.parse_args()

    if args.list_spot:
        uni = spot_universe()
        print(f"{len(uni)} Spot-Paare gegen USDC:\n")
        for name, sym in sorted(uni.items()):
            print(f"  {name:<14} {sym}")
        return

    if args.synthetic:
        print("Synthetische Testdaten (kein API-Zugriff).")
        df, interval, label = synthetic_data(), "4h", "SYNTH"
    else:
        symbol = resolve_spot_coin(args.coin) if args.spot else args.coin
        markt = "Spot" if args.spot else "Perp"
        label = f"{args.coin} ({markt})"
        print(f"Lade {args.coin} [{symbol}] {markt} {args.interval}, {args.days} Tage …")
        df, interval = fetch_candles(symbol, args.interval, args.days), args.interval

    bars_per_year = 365.25 * 86_400_000 / INTERVAL_MS[interval]
    cfg = Config(
        donchian=args.donchian, ema_trend=args.ema, atr_stop=args.atr_stop,
        allow_short=(not args.no_short) and not args.spot,
        is_spot=args.spot,
        equity0=args.equity, risk_pct=args.risk,
        # Spot ist teurer (0.070 % Taker) und dünner im Buch
        fee=args.fee if args.fee is not None else (0.0007 if args.spot else 0.00045),
        slippage=args.slippage if args.slippage is not None else (0.0015 if args.spot else 0.0005),
        max_leverage=1.0 if args.spot else 3.0,
        bars_per_year=bars_per_year,
    )
    if args.spot:
        print("  Spot-Modus: long-only, max. 1x, kein Funding, "
              f"{cfg.fee:.2%} Taker + {cfg.slippage:.2%} Slippage")

    fund = None
    if args.funding and args.spot:
        print("  --funding wird im Spot-Modus ignoriert.")
    elif args.funding and not args.synthetic:
        print("Lade Funding-Historie …")
        s = int(df.index[0].timestamp() * 1000)
        e = int(df.index[-1].timestamp() * 1000)
        fund = fetch_funding(args.coin, s, e)
        print(f"  {len(fund)} Funding-Einträge")

    if args.sweep:
        sweep(df, cfg, fund)
        return

    res = backtest(df, cfg, fund)
    print_stats(res.stats, f"{label} {interval} — Donchian {cfg.donchian}"
                           f"/EMA {cfg.ema_trend}/ATR {cfg.atr_stop}")

    if res.trades:
        print("\nLetzte 5 Trades:")
        for t in res.trades[-5:]:
            d = "LONG " if t.side > 0 else "SHORT"
            print(f"  {t.entry_time:%Y-%m-%d %H:%M} {d} "
                  f"{t.entry:>10.2f} -> {t.exit:>10.2f}  "
                  f"PnL {t.pnl:>9.2f}  {t.r_multiple:>5.2f}R  ({t.reason})")

    if args.plot:
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(12, 7), sharex=True,
                               gridspec_kw={"height_ratios": [2, 1]})
        ax[0].plot(res.equity, label="Strategie")
        bh = cfg.equity0 * df["close"] / df["close"].iloc[0]
        ax[0].plot(bh, alpha=0.5, label="Buy & Hold")
        ax[0].set_yscale("log"); ax[0].legend(); ax[0].set_ylabel("Equity")
        ax[1].fill_between(res.equity.index,
                           (res.equity / res.equity.cummax() - 1) * 100, 0,
                           color="crimson", alpha=0.4)
        ax[1].set_ylabel("Drawdown %")
        plt.tight_layout(); plt.savefig("backtest.png", dpi=120)
        print("\nChart gespeichert: backtest.png")


if __name__ == "__main__":
    main()
