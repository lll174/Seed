"""
hl_chartbild_js.py -- Skript des Abschnitts „Chartbild“ im Dashboard (U143 Stufe 1, 23.65; Korrekturen 23.66), ausgeliefert unter /chartbild.js.

Eigene Datei statt im großen Seiten-Text von hl_viz (wie hl_makro_js): wird mit `node --check` geprüft (A7) und ändert den
Seiten-Text kaum. Baut auf den Helfern der Seite auf ($, getJSON, esc, hideTip, #tip) und muss deshalb NACH dem Hauptskript
geladen werden. Daten: /chartbild?coin=.. (hl_chartbild.payload_json); gefragt wird nur, solange der Abschnitt offen und sichtbar ist.

Bild: abgeschlossene Tageskerzen auf log. Skala mit 50-/200-Tage-Linie, Bein (Zickzack, laufendes Bein gestrichelt), Swing-Hochs und
-Tiefs; rechts der Linie „heute“ die Zone „jetzt und danach“ mit den Niveaus (Momentaufnahmen -- deshalb nicht in die Vergangenheit
verlängert, Nummern wie in der Tabelle) und der 80-%-Spanne für den Schluss heute und in 7 Tagen; darunter RSI 14 im eigenen Feld
(eigene Skala, gleiche Zeitachse, gemeinsames Fadenkreuz -- nie eine zweite Achse im selben Feld). Tabellenansicht, Legende immer.
Farben für die dunkle Fläche #01030a mit dem Prüfskript gewählt (alle Paare): MA 50 #3987e5, MA 200 #c98500, Bein #d55181.
Kerzen neutral: hohl = Tag im Plus, gefüllt = Tag im Minus -- Rot/Grün trennt für Farbfehlsichtige nicht (ΔE 3,0 deutan), die Form schon.
"""

CHARTBILD_JS = r"""// 23.65 Chartbild (U143 Stufe 1): die Lage je Coin in Worten und im Bild -- Trend, Bein, Niveaus, Schwankung. Kein Signal.
// Daten: /chartbild?coin=.. (hl_chartbild.py). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist (alle 120 s).
// Farben (Prüfskript, Fläche #01030a, alle Paare bestanden): MA 50 #3987e5, MA 200 #c98500, Bein #d55181. Kerzen neutral mit
// Form statt Farbe (hohl = Plus, gefüllt = Minus); Niveaus in den Farben des Live-Charts, dazu Nummer und Name (nie Farbe allein).
const CB={bereich:0, tabelle:false, sch:{bein:true, swings:true, niveaus:true, band:true}, cache:{}, laeuft:{}, d:null, geo:null};
try{ const s_=JSON.parse(localStorage.getItem('hl_chartbild')||'{}'); if([30,90,180,365,730].includes(+s_.bereich)) CB.bereich=+s_.bereich;
 if(s_.sch&&typeof s_.sch==='object') Object.keys(CB.sch).forEach(k=>{ if(typeof s_.sch[k]==='boolean') CB.sch[k]=s_.sch[k]; }); }catch(e){}
if(!CB.bereich) CB.bereich=innerWidth<700?90:180;
function cbMerken(){ try{ localStorage.setItem('hl_chartbild', JSON.stringify({bereich:CB.bereich, sch:CB.sch})); }catch(e){} }
const CB_BEREICH=[[30,'1 M'],[90,'3 M'],[180,'6 M'],[365,'1 J'],[730,'2 J']];
const CB_SCH=[['bein','Bein'],['swings','Swings'],['niveaus','Niveaus'],['band','Spanne']];
const CB_F={ma50:'#3987e5', ma200:'#c98500', bein:'#d55181', kerze:'#8b949e', linie:'#c9d1d9', kurs:'#e6edf3', spanne:'#c9d1d9',
 swing:'#adbac7', grid:'#161b22', ref:'#30363d', muted:'#8b949e', text:'#c9d1d9', flaeche:'#01030a', zone:'#0a0e15'};
const CB_PRUEF_FOLGE=['trend','bein','swing','orders','liq','rund','band','rsi','funding','oi','konten','top_pos','fng'];
const CB_KURZ={support:'Kaufwand', resistance:'Verkaufswand', tp_long:'TP der Longs', tp_short:'TP der Shorts', stop_sell:'Sell-Stops',
 stop_sell_near:'Sell-Stops nah', stop_buy:'Buy-Stops', stop_buy_near:'Buy-Stops nah', liq_long:'Long-Liq.', liq_long_nah:'Long-Liq. nah',
 liq_short:'Short-Liq.', liq_short_nah:'Short-Liq. nah', rund_oben:'runde Zahl', rund_unten:'runde Zahl'};

// ---------- Zahlen und Datum (Dezimalkomma, echtes Minus) ----------
function cbZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}); }
function cbPx(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return cbZ(x, a>=1000?0:a>=100?1:a>=1?2:4); }
function cbV(x,d){ if(x==null||!isFinite(x)) return '—'; const t=cbZ(Math.abs(x),d); return (/[1-9]/.test(t)?(x>0?'+':'−'):'')+t; }   // 23.66: gerundete Null ohne Vorzeichen
function cbPct(x,d){ return x==null||!isFinite(x)?'—':cbV(x*100,d==null?1:d)+' %'; }
function cbPctL(x,d){ return x==null||!isFinite(x)?'—':cbPct(Math.expm1(x),d); }
function cbUsd(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); if(a>=1e9) return cbZ(x/1e9,2)+' Mrd'; if(a>=1e6) return cbZ(x/1e6,1)+' Mio';
 if(a>=1e3) return cbZ(x/1e3,0)+' Tsd'; return cbZ(x,0); }
function cbMenge(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return a>=1e6?cbZ(x/1e6,2)+' Mio':cbZ(x, a>=100?0:a>=1?2:4); }
function cbDatum(tag){ if(tag==null||!isFinite(tag)) return '—'; const d=new Date(tag*864e5); return String(d.getUTCDate()).padStart(2,'0')+'.'+String(d.getUTCMonth()+1).padStart(2,'0')+'.'+d.getUTCFullYear(); }
function cbKurz(tag){ const d=new Date(tag*864e5); return String(d.getUTCDate()).padStart(2,'0')+'.'+String(d.getUTCMonth()+1).padStart(2,'0')+'.'; }
function cbMonat(tag){ const d=new Date(tag*864e5); return ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'][d.getUTCMonth()]+' '+String(d.getUTCFullYear()).slice(2); }
function cbUhr(ts){ if(!ts) return '—'; const d=new Date(ts*1000); return String(d.getUTCHours()).padStart(2,'0')+':'+String(d.getUTCMinutes()).padStart(2,'0')+' UTC'; }
function cbAlter(s){ if(s==null||!isFinite(s)) return '—'; if(s<90) return 'vor '+Math.max(0,Math.round(s))+' s'; if(s<5400) return 'vor '+Math.round(s/60)+' min';
 return 'vor '+cbZ(s/3600,1)+' h'; }
function cbMinus(s){ return String(s).replace(/(^|[\s(\/])-(?=\d)/g,'$1−'); }
function cbTage(k){ return k==null||!isFinite(k)?'—':cbZ(k,0)+' '+(Math.round(k)===1?'Tag':'Tage'); }

// ---------- Achsen ----------
function cbSchritte(lo,hi,n){ const roh=(hi-lo)/(n||5); if(!(roh>0)) return {w:[lo], st:1}; const mag=Math.pow(10,Math.floor(Math.log10(roh)));
 const st=[1,2,2.5,5,10].map(f=>f*mag).find(s=>s>=roh)||10*mag; const out=[]; for(let v=Math.ceil(lo/st)*st; v<=hi+st*1e-9; v+=st) out.push(+v.toPrecision(12));
 return {w:out, st}; }
function cbTickFmt(st){ const s_=String(+(+st).toPrecision(6)), i=s_.indexOf('.'), nd=s_.includes('e')?4:i<0?0:Math.min(4,s_.length-i-1); return v=>cbZ(v,nd); }
function cbXSchritte(x0,x1){ const tage=x1-x0, out=[]; const d0=new Date(x0*864e5), sprung=tage>540?3:tage>200?2:1;
 let j=d0.getUTCFullYear(), m=d0.getUTCMonth()+1; if(m>11){ m=0; j++; }
 while(true){ const t=Date.UTC(j,m,1)/864e5; if(t>x1) break; if(m%sprung===0) out.push([t,cbMonat(t)]); m++; if(m>11){ m=0; j++; } }
 return out; }
// Beschriftungen ohne Überlappung: P nach y sortiert, setzt ly (mindestens abst Pixel Abstand, innerhalb oben..unten)
function cbVerteilen(P, oben, unten, abst){
 for(let i=0;i<P.length;i++) P[i].ly=Math.max(P[i].y, i?P[i-1].ly+abst:oben);
 for(let i=P.length-1;i>=0;i--){ const g=i===P.length-1?unten:P[i+1].ly-abst; if(P[i].ly>g) P[i].ly=g; }
 for(let i=0;i<P.length;i++) if(P[i].ly<oben) P[i].ly=oben; }
function cbSetzen(L, oben, unten){ const box=[]; const ueber=(p,q)=>p.x1>q.x0&&p.x0<q.x1&&Math.abs(p.y-q.y)<12;
 L.forEach(l=>{ const w=String(l.t).length*5.7+4, x0=l.a==='end'?l.x-w:l.x, x1=l.a==='end'?l.x:l.x+w;
  for(const dy of [0,-12,12,-24,24,-36,36]){ const y=l.y+dy; if(y<oben||y>unten) continue; const b={x0,x1,y}; if(!box.some(q=>ueber(q,b))){ box.push(b); l.ly=y; break; } } });
 return L.filter(l=>l.ly!=null); }
function cbStil(art){ if(art==='stop_sell'||art==='stop_buy') return {w:1.6, d:'1.5,3', o:0.95};
 if(art==='liq_long'||art==='liq_short') return {w:1.6, d:'6,3', o:0.9};
 if(art==='tp_sell'||art==='tp_buy') return {w:1.2, d:'', o:0.85};
 if(art==='swing_hoch'||art==='swing_tief') return {w:1, d:'', o:0.55};
 if(art==='rund') return {w:1, d:'1,4', o:0.8};
 return {w:1.8, d:'', o:0.95}; }
function cbSwingTag(d,l){ const S=d.swings||{}; const L=(l.art==='swing_hoch'?S.hoch:S.tief)||[]; const f=L.find(z=>Math.abs(z[1]/l.px-1)<1e-5); return f?f[0]:null; }
function cbKurzname(d,l){ if(l.art==='swing_hoch'||l.art==='swing_tief'){ const t=cbSwingTag(d,l); return (l.art==='swing_hoch'?'Swing-Hoch':'Swing-Tief')+(t!=null?' '+cbKurz(t):''); }
 return CB_KURZ[l.key]||l.name; }
function cbNr(nr,farbe){ return `<span class="cbnr" style="border-color:${farbe}">${nr}</span>`; }

// ---------- Laden ----------
function cbOffen(){ const p=$('sec-chartbild'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function cbCoin(){ const c=$('coin'); return ((c&&c.value)||'BTC').toUpperCase(); }
async function cbLaden(zwang){ if(!cbOffen()) return; const el=$('cbbody'); if(!el) return;
 if(!$('cbzeile')) cbLeiste();
 const coin=cbCoin(), c=CB.cache[coin];
 if(c&&!zwang&&Date.now()-c.zeit<110000){ if(CB.d!==c.d) cbZeigen(c.d); return; }
 if(CB.laeuft[coin]) return; CB.laeuft[coin]=true; if(CB.d) el.style.opacity='0.55';
 try{ const d=await getJSON('/chartbild?coin='+encodeURIComponent(coin)); CB.cache[coin]={d, zeit:Date.now()}; if(cbCoin()===coin) cbZeigen(d); }
 catch(e){ if(!c&&cbCoin()===coin) el.innerHTML='<div class="sub">Chartbild nicht erreichbar.</div>'; }
 finally{ CB.laeuft[coin]=false; el.style.opacity='1'; } }
function cbLeiste(){ const el=$('cbbar'); if(!el) return;
 el.innerHTML=`<div class="cbzeile" id="cbzeile"><span class="lbl">Zeitraum</span>${CB_BEREICH.map(([k,n])=>`<button class="tog ${k===CB.bereich?'on':'off'}" onclick="cbBereich(${k})">${n}</button>`).join('')}`
  +`<span class="lbl cbab">Ebenen</span>${CB_SCH.map(([k,n])=>`<button class="tog ${CB.sch[k]?'on':'off'}" onclick="cbSchicht('${k}')">${n}</button>`).join('')}`
  +`<button class="tog cbtabbtn ${CB.tabelle?'on':'off'}" onclick="cbTabelleUm()" title="Tageswerte als Tabelle statt Bild">Tabelle</button></div>`; }
function cbBereich(k){ CB.bereich=k; cbMerken(); cbLeiste(); cbZeichne(); }
function cbSchicht(k){ CB.sch[k]=!CB.sch[k]; cbMerken(); cbLeiste(); cbZeichne(); }
function cbTabelleUm(){ CB.tabelle=!CB.tabelle; cbLeiste(); cbZeichne(); }

// ---------- Kopf, Lesart, Tabellen ----------
function cbZeigen(d){ const el=$('cbbody'); if(!el) return; CB.d=d; if(typeof hideTip==='function') hideTip();
 if(!d||!d.ok||!d.tage&&!d.band&&!(d.lesart||[]).length){ el.innerHTML=`<div class="sub" style="margin:8px 0">${esc(((d&&d.fehlt)||['keine Daten']).join(' · '))}</div>`; return; }
 const k=d.kurs||{}, T=d.tage, les=d.lesart||[];
 const kopf=`<div class="cbkopf"><b>${esc(d.coin)}</b> · Kurs <b>${cbPx(k.px)}</b> · ${esc(k.quelle||'—')}${k.ts?' '+cbUhr(k.ts):''}`
  +(T?` · Tageskerzen bis ${cbDatum(T.letzter_tag)} (${esc(T.quelle||'—')})`:'')+` · Prüfstände Stand ${esc(d.pruef_stand||'—')}</div>`;
 const lesart=`<ul class="cblesart">${les.map((s,i)=>`<li${i===les.length-1?' class="schluss"':''}>${esc(cbMinus(s))}</li>`).join('')}</ul>`;
 el.innerHTML=kopf+lesart+`<div id="cbleg" class="leg cbleg"></div><div id="cbplot" class="cbplot"></div><div id="cbplottab" class="cbscroll cbtabelle"></div>`
  +`<div class="sub cbnote">Rechts der gestrichelten Linie „heute“: die Niveaus als Momentaufnahme (Orders und Liquidationscluster jetzt -- deshalb nicht in die Vergangenheit verlängert; Swing-Linien ab ihrem Tag) und die 80-%-Spanne für den Schluss heute und in 7 Tagen. Nummern wie in der Tabelle. Beschreibung, kein Signal.</div>`
  +cbTabellen(d);
 cbZeichne(); }
function cbJetztZeile(d){ const k=d.kurs||{}; return `<tr class="cbjetzt"><td></td><td>Kurs jetzt<span class="lz">${esc(k.quelle||'—')}${k.ts?', '+cbUhr(k.ts):''}</span></td><td class="n">${cbPx(k.px)}</td><td class="n">0 %</td><td class="n">0 σ</td><td></td><td></td><td></td><td></td></tr>`; }
function cbSpark(werte, jetzt){ const v=(werte||[]).filter(x=>x!=null&&isFinite(x)); if(v.length<2) return '';
 const alle=jetzt!=null&&isFinite(jetzt)?v.concat([jetzt]):v; let lo=Math.min(...alle), hi=Math.max(...alle); if(hi===lo){ hi+=1; lo-=1; }
 const W=92, H=20, n=werte.length, X=i=>1+i/(n)*(W-6), Y=x=>2+(hi-x)/(hi-lo)*(H-4); let p='', an=false;
 werte.forEach((x,i)=>{ if(x==null||!isFinite(x)){ an=false; return; } p+=(an?'L':'M')+X(i).toFixed(1)+','+Y(x).toFixed(1); an=true; });
 const e=jetzt!=null&&isFinite(jetzt)?`<circle cx="${X(n).toFixed(1)}" cy="${Y(jetzt).toFixed(1)}" r="2.5" fill="${CB_F.kurs}"/>`:'';
 return `<svg width="${W}" height="${H}" style="vertical-align:middle" aria-hidden="true"><path d="${p}" fill="none" stroke="${CB_F.muted}" stroke-width="1.2"/>${e}</svg>`; }
function cbTabellen(d){ const P=d.pruef||{}, pr=k=>P[k]?`<span title="${esc(P[k][1])}">${esc(P[k][0])}</span>`:'—';
 const k=d.kurs&&d.kurs.px, Bd=d.band||{}; let h='';
 // Niveaus
 const NV=d.niveaus||[];
 if(NV.length){ let z='', jetzt=false;
  NV.forEach((l,i)=>{ if(!jetzt&&k&&l.px<k){ z+=cbJetztZeile(d); jetzt=true; }
   z+=`<tr><td>${cbNr(i+1,l.farbe)}</td><td>${esc(l.name)}<span class="lz">${esc(l.quelle||'')}</span></td><td class="n">${cbPx(l.px)}</td><td class="n">${cbPct(l.dist,1)}</td>`
    +`<td class="n">${l.sigma!=null?cbV(l.sigma,1)+' σ':'—'}</td><td class="n">${l.usd?cbUsd(l.usd):'—'}</td><td class="n">${l.n!=null?l.n:'—'}</td>`
    +`<td>${l.alter_s!=null?cbAlter(l.alter_s):'—'}</td><td>${pr(l.pruef)}</td></tr>`; });
  if(!jetzt) z+=cbJetztZeile(d);
  const sg=Bd.sigma_tag;
  h+=`<h3 class="cbh3">Niveaus — von oben nach unten, Abstand zum Kurs in % und in Tages-σ</h3><div class="cbscroll"><table class="w"><tr><th>Nr.</th><th>Niveau</th><th class="n">Preis</th><th class="n">Abstand</th><th class="n">σ</th><th class="n">Größe USD</th><th class="n">Konten/Pos.</th><th>Stand</th><th>Prüfstand</th></tr>${z}</table></div>`
   +`<div class="sub">σ = erwartete Tagesschwankung${sg?` (HAR, 1 Tag: ${cbZ(sg*100,2)} %)`:' (EWMA der Tagesrenditen)'}. Orders der Großkonten: je Art das größte Cluster innerhalb ±30 %, wenn es mindestens das halbe Stundenvolumen erreicht (sonst „kein nennenswertes Cluster“ unter den Lücken), und das nächste Stop-Cluster ohne Mindestgröße (wie im Live-Chart);
     Liquidationscluster −12 %/+15 %: je Seite das größte und das nächste, beide ab dem halben Stundenvolumen; Swing-Hoch/-Tief: Hoch über den 5 Tagen davor und mindestens so hoch wie die 5 danach (Tief spiegelbildlich), die zwei nächsten je Seite;
     runde Zahl: Schritt 1/2/5 der zweiten Stelle. Ob der Kurs an diesen Niveaus umkehrt oder von ihnen angezogen wird, ist ungeprüft (Stufe 2) bzw. offen (U110).</div>`; }
 // Beine
 const BE=d.beine||[];
 if(BE.length){ const st=(n,m,q,dm,dq)=>n?`n ${n} · Median ${cbPctL(m,0)} in ${cbTage(dm)}<span class="lz">25–75 %: ${cbPctL(q&&q[0],0)} bis ${cbPctL(q&&q[1],0)}${dq?` · ${cbZ(dq[0],0)}–${cbZ(dq[1],0)} Tage`:''}</span>`:'—';
  const z=BE.map(b=>{ const ri=b.mode===1?'aufwärts':b.mode===-1?'abwärts':'noch keins';
   const seit=b.start_px?`${b.mode===1?'tiefster':'höchster'} Schluss ${cbPx(b.start_px)} am ${cbDatum(b.start_tag)}<span class="lz">vor ${cbTage(b.alter_tage)}</span>`:'—';
   const bis=b.extrem_px?`${cbPct(b.groesse_bisher,1)}<span class="lz lzn">bis ${b.mode===1?'höchster':'tiefster'} Schluss ${cbPx(b.extrem_px)} · ${cbKurz(b.extrem_tag)}</span>`:'—';
   return `<tr><td>${cbZ(b.X*100,0)} %</td><td>${ri}</td><td>${seit}</td><td class="n">${bis}</td><td class="n">${cbPct(b.vom_extrem,1)}</td><td class="n">${cbPx(b.bestaetigt_ab)}</td>`
    +`<td class="cbw">${st(b.n_auf,b.med_auf,b.q_auf,b.dauer_auf,b.dauer_auf_q)}</td><td class="cbw">${st(b.n_ab,b.med_ab,b.q_ab,b.dauer_ab,b.dauer_ab_q)}</td></tr>`; }).join('');
  const j=BE[0]&&BE[0].jahre;
  h+=`<h3 class="cbh3">Bein je Schwelle (Directional Change wie U141 Teil A)</h3><div class="cbscroll"><table class="w"><tr><th>Schwelle</th><th>Bein jetzt</th><th>seit</th><th class="n">bisher</th><th class="n">vom Extrem</th><th class="n">Gegenbein ab</th><th>abgeschlossene Rallyes</th><th>abgeschlossene Rücksetzer</th></tr>${z}</table></div>`
   +`<div class="sub">Ein Rücksetzer (Aufschwung) gilt als bestätigt, sobald ein Tagesschluss die Schwelle unter dem Hoch (über dem Tief) liegt -- „Gegenbein ab“ ist dieser Preis, eine Definition, kein Ziel.
     Größen und Dauern der abgeschlossenen Beine${j?` der letzten ${cbZ(j,1)} Jahre`:''}: wie ein Zufallsweg mit derselben Drift und Schwankung (U141 A, p Holm 0,89/0,89/0,93) -- beschreibend.</div>`; }
 // Spanne
 if(Bd.h1||Bd.h7){ const z=[[1,Bd.h1,'Schluss heute (00:00 UTC)'],[7,Bd.h7,`Schluss in 7 Tagen (${Bd.basis_tag!=null?cbDatum(Bd.basis_tag+7):'—'})`]].filter(x=>x[1]).map(([hz,b,txt])=>
   `<tr><td>${txt}</td><td class="n">${cbPx(b.lo)} – ${cbPx(b.hi)}</td><td class="n">${cbPct(b.lo/Bd.basis_px-1,1)} / ${cbPct(b.hi/Bd.basis_px-1,1)}</td><td class="n">${cbZ(b.sigma*100,2)} %</td>`
   +`<td class="n">${b.treffer!=null?`${cbZ(b.treffer*100,0)} % <span class="lz">n ${b.n}, ± ${cbZ((b.se||0)*100,0)} Pp.</span>`:`— <span class="lz">erst ab 90 Prognosetagen (${b.n||0})</span>`}</td></tr>`).join('');
  h+=`<h3 class="cbh3">Erwartete Spanne (80 %) — Schwankung, keine Richtung</h3><div class="cbscroll"><table class="w"><tr><th>Horizont</th><th class="n">80-%-Spanne</th><th class="n">zum Schluss</th><th class="n">σ</th><th class="n">Trefferquote 365 T</th></tr>${z}</table></div>`
   +`<div class="sub">HAR wie U138 P0.2 aus 30-min-Kerzen (${esc(Bd.quelle||'—')}), ab dem Schluss ${cbPx(Bd.basis_px)} am ${cbDatum(Bd.basis_tag)}: Prognose der Schwankung, Bandgrenzen aus den 10-/90-%-Quantilen der eigenen standardisierten Renditen. Soll 80 %; ${esc(Bd.p02||'—')}. Die Spanne sagt nichts über die Richtung.</div>`; }
 // Daneben
 const lg=d.lage||{}, zz=[];
 if(d.rsi&&d.rsi.wert!=null) zz.push(['RSI 14 (Wilder, Tagesschluss)', cbZ(d.rsi.wert,0), '', cbDatum(d.rsi.tag), 'rsi']);
 if(d.funding&&d.funding.z!=null) zz.push(['Funding-Druck (z über 30 Tage, Binance)', cbV(d.funding.z,1), `jüngste Rate ${cbV(d.funding.rate*100,4)} %`, `${cbDatum(d.funding.tag)} · Rate ${cbUhr(d.funding.rate_ts)}`, 'funding']);
 [['oi','Open Interest (Binance, in '+esc(d.coin)+')',cbMenge],['konten','Konten long/short (Binance, alle Konten)',x=>cbZ(x,2)],['top_pos','Top-Trader nach Positionen (Binance)',x=>cbZ(x,2)]].forEach(([key,nm,f])=>{
  const e=lg[key]; if(!e||e.wert==null) return;
  zz.push([nm, f(e.wert), `${e.pz!=null?cbZ(e.pz*100,0)+'. Perzentil der 90 Tage':'Perzentil: zu wenig Tage'} ${cbSpark(e.verlauf, e.art==='live'?e.wert:null)}`, e.art==='live'?`live ${cbUhr(e.ts)}`:`Tagesstand ${cbDatum(e.tag)}`, key]); });
 if(d.fng) zz.push(['Fear & Greed (alternative.me)', `${cbZ(d.fng.wert,0)} <span class="lz">${esc(d.fng.klasse||'')}</span>`, '', cbDatum(d.fng.tag), 'fng']);
 if(zz.length) h+=`<h3 class="cbh3">Daneben — Stimmung und Positionierung</h3><div class="cbscroll"><table class="w"><tr><th>Kennzahl</th><th class="n">Wert</th><th>Einordnung</th><th>Stand</th><th>Prüfstand</th></tr>`
  +zz.map(r=>`<tr><td>${r[0]}</td><td class="n">${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${pr(r[4])}<span class="lz">${esc((P[r[4]]||['',''])[1])}</span></td></tr>`).join('')+`</table></div>`
  +`<div class="sub">Perzentil = Mittelrang des Werts unter den letzten 90 Tagesständen (Tagesende UTC, wie U142). Belegt ist davon nur die Kontenregel (U142 H1, 11.10.): nach Konten ≥ 3 folgte ein Rücksetzer in 7 Tagen in 20 % statt 7 % der Fälle -- ein Risikohinweis, in rund 4 von 5 Fällen folgte keiner${lg.konten&&lg.konten.wert!=null?` (jetzt ${cbZ(lg.konten.wert,2)}: ${lg.konten.wert>=3?'erfüllt':'nicht erfüllt'})`:''}. Die übrigen Werte ohne belegtes Timing (U141/U142).</div>`;
 // Prüfstände und Lücken
 h+=`<details class="cbdetails"><summary>Prüfstände (Stand ${esc(d.pruef_stand||'—')}) — was die Studien zu jedem Baustein zeigen</summary><ul class="cbpruef">`
  +CB_PRUEF_FOLGE.filter(k_=>P[k_]).map(k_=>`<li><b>${esc(P[k_][0])}</b> — ${esc(P[k_][1])}</li>`).join('')+`</ul></details>`;
 const F=(d.fehlt||[]).concat((lg.fehlt||[]).map(x=>'Positionierung: '+x));
 if(F.length) h+=`<h3 class="cbh3">Was fehlt</h3><ul class="cbfehlt">${F.map(x=>`<li>${esc(cbMinus(x))}</li>`).join('')}</ul>`;
 const NG=d.nicht_gezeigt||[];
 if(NG.length) h+=`<h3 class="cbh3">Bewusst nicht gezeigt</h3><ul class="cbfehlt">${NG.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`;
 const T=d.tage;
 h+=`<div class="cbfuss">Rechenzeit ${cbZ(d.rechenzeit_ms,0)} ms · Modul ${esc(d.version||'—')}${T?` · Tageskerzen gesamt ${cbZ(T.n_gesamt,0)}${T.gefuellt?`, davon ${T.gefuellt} aufgefüllt (Lücke bis 3 Tage)`:''}`:''} · Regeln: KONZEPT_Chartbild.md · Debug „Chartbild: Lage aller Coins als Text“</div>`;
 return h; }
function cbTageTabelle(d,a){ const T=d.tage, n=T.c.length, z=[];
 for(let i=n-1;i>=a;i--){ const dz=i>0&&T.c[i-1]?T.c[i]/T.c[i-1]-1:null;
  z.push(`<tr><td>${cbDatum(T.t0+i)}</td><td class="n">${cbPx(T.o[i])}</td><td class="n">${cbPx(T.h[i])}</td><td class="n">${cbPx(T.l[i])}</td><td class="n">${cbPx(T.c[i])}</td><td class="n">${cbPct(dz,1)}</td><td class="n">${cbPx(T.ma50[i])}</td><td class="n">${cbPx(T.ma200[i])}</td><td class="n">${cbZ(T.rsi[i],0)}</td></tr>`); }
 return `<table class="w"><tr><th>Tag (UTC)</th><th class="n">Eröffnung</th><th class="n">Hoch</th><th class="n">Tief</th><th class="n">Schluss</th><th class="n">zum Vortag</th><th class="n">MA 50</th><th class="n">MA 200</th><th class="n">RSI 14</th></tr>${z.join('')}</table>`; }

// ---------- Legende ----------
function cbLegende(d, modus){ const el=$('cbleg'); if(!el) return; if(!modus){ el.innerHTML=''; return; }
 const li=(c,dash,w)=>`<svg width="20" height="8" aria-hidden="true"><line x1="1" y1="4" x2="19" y2="4" stroke="${c}" stroke-width="${w||2}"${dash?` stroke-dasharray="${dash}"`:''}/></svg>`;
 const T=[];
 if(modus.kerzen) T.push(`<span><svg width="24" height="12" aria-hidden="true"><rect x="2.5" y="2.5" width="6" height="7" fill="none" stroke="${CB_F.kerze}"/><rect x="14" y="2" width="7" height="8" fill="${CB_F.kerze}"/></svg>Tageskerze: hohl = Tag im Plus, gefüllt = Tag im Minus</span>`);
 else T.push(`<span>${li(CB_F.linie,'',1.5)}Tagesschluss, Fläche = Hoch bis Tief (Kerzen ab 4 px je Tag: kürzerer Zeitraum)</span>`);
 T.push(`<span>${li(CB_F.ma50)}MA 50</span>`, `<span>${li(CB_F.ma200)}MA 200</span>`);
 if(modus.bein) T.push(`<span>${li(CB_F.bein,'',1.6)}Bein ${modus.bein} % (Zickzack)</span><span>${li(CB_F.bein,'5,3',1.6)}laufendes Bein · Gegenbein ab</span>`);
 if(modus.swings) T.push(`<span><svg width="18" height="12" aria-hidden="true"><path d="M2,2L9,2L5.5,7Z" fill="${CB_F.swing}"/><path d="M10,11L17,11L13.5,6Z" fill="${CB_F.swing}"/></svg>Swing-Hoch / -Tief</span>`);
 if(modus.band) T.push(`<span><svg width="20" height="12" aria-hidden="true"><path d="M1,6L19,1L19,11Z" fill="${CB_F.spanne}" opacity="0.22"/></svg>80-%-Spanne heute und +7 Tage</span>`);
 if(modus.kurs) T.push(`<span>${li(CB_F.kurs,'3,3',1)}Kurs jetzt</span>`);
 if(modus.niveaus) T.push(`<span>${cbNr(1,'#39d3ff')} Niveaus (Nummer wie in der Tabelle; gepunktet Stops, gestrichelt Liquidationscluster)</span>`);
 el.innerHTML=T.join(''); }

// ---------- Bild ----------
function cbZeichne(){ const d=CB.d, el=$('cbplot'), tabEl=$('cbplottab'); if(!d||!el) return; if(typeof hideTip==='function') hideTip();
 const T=d.tage;
 if(!T||!T.c||!T.c.length){ el.innerHTML='<div class="sub cbleer">Keine Tageskerzen für das Bild — die Gründe stehen unter „Was fehlt“.</div>'; if(tabEl) tabEl.innerHTML=''; cbLegende(d,null); return; }
 const n=T.c.length, t0=T.t0, tl=t0+n-1, ber=Math.min(CB.bereich,n), a=n-ber, ta=t0+a;
 if(CB.tabelle){ el.innerHTML=''; if(tabEl) tabEl.innerHTML=cbTageTabelle(d,a); cbLegende(d,null); return; }
 if(tabEl) tabEl.innerHTML='';
 const W=Math.max(300,el.clientWidth||600), breit=W>=700, NVall=d.niveaus||[];
 const L=6, R=breit?62:52, LC=breit&&CB.sch.niveaus&&NVall.length?206:0, T_=10, PH=breit?340:270, G=12, RH=breit?72:58, B=20;
 const H=T_+PH+G+RH+B, pwGes=W-L-R-LC;
 // Zone „jetzt und danach“: mindestens 9 Tage (Spanne bis +7) und mindestens 46 px
 const ZF=Math.max(9, Math.ceil(46*ber/Math.max(1,pwGes-46))), pd=pwGes/(ber+ZF);
 const xa=ta-0.5, X=t=>L+(t-xa)*pd, xJetzt=X(tl+0.5), xRechts=L+pwGes, kerzen=pd>=4;
 // y-Bereich: Kerzen, Kurs, Spanne, Gegenbein; die Linien nur, wenn sie höchstens 15 % darüber hinausragen (sonst drücken sie die
 // Kerzen im kurzen Zeitraum zusammen -- dann am Rand beschriftet); die Niveaus nie (sie stehen in der Tabelle)
 let lo=Infinity, hi=-Infinity; const nimm=v=>{ if(v!=null&&isFinite(v)&&v>0){ if(v<lo) lo=v; if(v>hi) hi=v; } };
 for(let i=a;i<n;i++){ nimm(T.h[i]); nimm(T.l[i]); }
 const k=d.kurs&&d.kurs.px, Bd=d.band, b0=(d.beine||[])[0], mitBand=CB.sch.band&&Bd&&Bd.basis_px&&(Bd.h1||Bd.h7);
 nimm(k); if(mitBand){ [Bd.h1,Bd.h7].forEach(b=>{ if(b){ nimm(b.lo); nimm(b.hi); } }); }
 if(CB.sch.bein&&b0&&b0.bestaetigt_ab&&b0.extrem_tag>=ta) nimm(b0.bestaetigt_ab);
 { const lo0=lo, hi0=hi; for(let i=a;i<n;i++) [T.ma50[i],T.ma200[i]].forEach(v=>{ if(v!=null&&v>=lo0/1.15&&v<=hi0*1.15) nimm(v); }); }
 if(!isFinite(lo)){ el.innerHTML='<div class="sub cbleer">Keine Werte im gewählten Zeitraum.</div>'; return; }
 const la=Math.log(lo), lb=Math.log(hi), pad=Math.max((lb-la)*0.05,0.01), y0=la-pad, y1=lb+pad;
 const Y=v=>T_+(y1-Math.log(v))/(y1-y0)*PH, yLo=Math.exp(y0), yHi=Math.exp(y1);
 const T2=T_+PH+G, Yr=v=>T2+(100-v)/100*RH, f1=v=>v.toFixed(1);
 let s=`<svg width="${W}" height="${H}" role="img" aria-label="Chartbild ${esc(d.coin)}: Tageskerzen ${cbZ(ber,0)} Tage mit 50- und 200-Tage-Linie" style="display:block;background:${CB_F.flaeche};border:1px solid #21262d;border-radius:6px">`
  +`<defs><clipPath id="cbclip"><rect x="${L}" y="${T_}" width="${f1(pwGes)}" height="${PH}"/></clipPath></defs>`;
 s+=`<rect x="${f1(xJetzt)}" y="${T_}" width="${f1(xRechts-xJetzt)}" height="${PH}" fill="${CB_F.zone}"/>`;
 // Gitter und Achsen
 const yt=cbSchritte(yLo,yHi,breit?6:5), yf=cbTickFmt(yt.st);
 yt.w.forEach(v=>{ const y=Y(v); if(y<T_+3||y>T_+PH-3) return; s+=`<line x1="${L}" x2="${W-R}" y1="${f1(y)}" y2="${f1(y)}" stroke="${CB_F.grid}"/><text x="${W-R+4}" y="${f1(y+3)}" fill="${CB_F.muted}" font-size="10">${yf(v)}</text>`; });
 cbXSchritte(ta,tl).forEach(([t,txt])=>{ const x=X(t); if(x<L+2||x>xJetzt-36) return; s+=`<line x1="${f1(x)}" x2="${f1(x)}" y1="${T_}" y2="${T2+RH}" stroke="${CB_F.grid}"/><text x="${f1(x+3)}" y="${H-6}" fill="${CB_F.muted}" font-size="10">${txt}</text>`; });
 s+=`<line x1="${f1(xJetzt)}" x2="${f1(xJetzt)}" y1="${T_}" y2="${T2+RH}" stroke="${CB_F.ref}" stroke-dasharray="3,3"/><text x="${f1(xJetzt+3)}" y="${H-6}" fill="${CB_F.muted}" font-size="10">heute</text>`;
 s+=`<g clip-path="url(#cbclip)">`;
 // runde Zahlen: zeitlos, ganze Breite, leise
 const NV=CB.sch.niveaus?NVall.map((l,i)=>Object.assign({nr:i+1},l)):[];
 const sicht=NV.filter(l=>l.px>=yLo&&l.px<=yHi);
 sicht.filter(l=>l.art==='rund').forEach(l=>{ const y=f1(Y(l.px)); s+=`<line x1="${L}" x2="${f1(xRechts)}" y1="${y}" y2="${y}" stroke="${l.farbe}" stroke-dasharray="1,4" opacity="0.8"/>`; });
 // Kerzen oder Linie
 if(kerzen){ const bw=Math.max(2,Math.min(11,pd*0.64));
  for(let i=a;i<n;i++){ const o=T.o[i], h=T.h[i], l=T.l[i], c=T.c[i]; if(o==null||c==null||h==null||l==null) continue;
   const x=X(t0+i), yo=Y(o), yc=Y(c), top=Math.min(yo,yc), bot=Math.max(yo,yc), hh=Math.max(1,bot-top), xs=f1(x);
   s+=`<line x1="${xs}" x2="${xs}" y1="${f1(Y(h))}" y2="${f1(top)}" stroke="${CB_F.kerze}"/><line x1="${xs}" x2="${xs}" y1="${f1(bot)}" y2="${f1(Y(l))}" stroke="${CB_F.kerze}"/>`;
   s+=c>=o?`<rect x="${f1(x-bw/2+0.5)}" y="${f1(top)}" width="${f1(Math.max(1,bw-1))}" height="${f1(hh)}" fill="${CB_F.flaeche}" stroke="${CB_F.kerze}"/>`
          :`<rect x="${f1(x-bw/2)}" y="${f1(top)}" width="${f1(bw)}" height="${f1(hh)}" fill="${CB_F.kerze}"/>`; } }
 else{ let pc='', an=false; const ob=[], un=[];
  for(let i=a;i<n;i++){ const x=f1(X(t0+i)); if(T.c[i]!=null){ pc+=(an?'L':'M')+x+','+f1(Y(T.c[i])); an=true; } else an=false;
   if(T.h[i]!=null&&T.l[i]!=null){ ob.push(x+','+f1(Y(T.h[i]))); un.push(x+','+f1(Y(T.l[i]))); } }
  if(ob.length>1) s+=`<path d="M${ob.join('L')}L${un.reverse().join('L')}Z" fill="${CB_F.linie}" opacity="0.10"/>`;
  s+=`<path d="${pc}" fill="none" stroke="${CB_F.linie}" stroke-width="1.3" stroke-linejoin="round"/>`; }
 // 50- und 200-Tage-Linie
 const pfad=arr=>{ let p='', an=false; for(let i=a;i<n;i++){ const v=arr[i]; if(v==null||!(v>0)){ an=false; continue; } p+=(an?'L':'M')+f1(X(t0+i))+','+f1(Y(v)); an=true; } return p; };
 const enden=[];
 [['ma200','MA 200'],['ma50','MA 50']].forEach(([key,nm])=>{ const p=pfad(T[key]); if(!p) return;
  s+=`<path d="${p}" fill="none" stroke="${CB_F[key]}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>`;
  const v=T[key][n-1]; if(!(v>0)) return;
  if(v>yHi) enden.push({y:T_+14, t:`${nm} ${cbPx(v)} ▲ (außerhalb)`}); else if(v<yLo) enden.push({y:T_+PH-2, t:`${nm} ${cbPx(v)} ▼ (außerhalb)`}); else enden.push({y:Y(v)-4, t:nm}); });
 // Swing-Hochs und -Tiefs
 if(CB.sch.swings&&d.swings){ (d.swings.hoch||[]).forEach(([t,p])=>{ if(t<ta||t>tl) return; const x=X(t), y=Y(p)-3; s+=`<path d="M${f1(x-4)},${f1(y-6)}L${f1(x+4)},${f1(y-6)}L${f1(x)},${f1(y)}Z" fill="${CB_F.swing}"/>`; });
  (d.swings.tief||[]).forEach(([t,p])=>{ if(t<ta||t>tl) return; const x=X(t), y=Y(p)+3; s+=`<path d="M${f1(x-4)},${f1(y+6)}L${f1(x+4)},${f1(y+6)}L${f1(x)},${f1(y)}Z" fill="${CB_F.swing}"/>`; }); }
 // Bein: Zickzack der bestätigten Extreme, laufendes Bein gestrichelt, danach bis zum letzten Schluss gepunktet, Gegenbein-Schwelle
 let beinX=null; const texte=[];
 if(CB.sch.bein&&b0){ const Z=d.zickzack||[]; let p='', an=false;
  for(let j=0;j<Z.length;j++){ const [t,px]=Z[j]; if(t<ta&&!(j+1<Z.length&&Z[j+1][0]>=ta)) continue; p+=(an?'L':'M')+f1(X(t))+','+f1(Y(px)); an=true; }
  if(p) s+=`<path d="${p}" fill="none" stroke="${CB_F.bein}" stroke-width="1.6" stroke-linejoin="round" opacity="0.95"/>`;
  if(b0.start_px&&b0.extrem_px){ beinX=Math.round(b0.X*100);
   s+=`<path d="M${f1(X(b0.start_tag))},${f1(Y(b0.start_px))}L${f1(X(b0.extrem_tag))},${f1(Y(b0.extrem_px))}" fill="none" stroke="${CB_F.bein}" stroke-width="1.6" stroke-dasharray="5,3"/>`;
   if(b0.extrem_tag<tl) s+=`<path d="M${f1(X(b0.extrem_tag))},${f1(Y(b0.extrem_px))}L${f1(X(tl))},${f1(Y(T.c[n-1]))}" fill="none" stroke="${CB_F.bein}" stroke-width="1" stroke-dasharray="1,3" opacity="0.8"/>`;
   if(X(b0.extrem_tag)>=L){ const oben=b0.mode===1;
    texte.push({x:Math.min(X(b0.extrem_tag),xJetzt-4), y:Y(b0.extrem_px)+(oben?-9:16), t:`${oben?'Schlusshoch':'Schlusstief'} ${cbPx(b0.extrem_px)}`, a:'end'}); }
   if(b0.bestaetigt_ab&&b0.bestaetigt_ab>=yLo&&b0.bestaetigt_ab<=yHi){ const yb=Y(b0.bestaetigt_ab), xb=Math.max(L,X(b0.extrem_tag));
    s+=`<line x1="${f1(xb)}" x2="${f1(xRechts)}" y1="${f1(yb)}" y2="${f1(yb)}" stroke="${CB_F.bein}" stroke-dasharray="5,3" opacity="0.6"/>`;
    texte.push({x:xb-4>L+170?xb-4:Math.max(L+4,xb+4), y:yb-4, t:`${b0.mode===1?'Rücksetzer':'Aufschwung'} bestätigt ab ${cbPx(b0.bestaetigt_ab)}`, a:xb-4>L+170?'end':'start'}); } } }
 // Niveaus: Momentaufnahmen ab heute nach rechts, Swing-Linien ab ihrem Tag
 sicht.filter(l=>l.art!=='rund').forEach(l=>{ const y=f1(Y(l.px)), st=cbStil(l.art); let xs=xJetzt;
  if(l.art==='swing_hoch'||l.art==='swing_tief'){ const t=cbSwingTag(d,l); xs=t!=null?Math.max(L,X(t)):L; }
  s+=`<line x1="${f1(xs)}" x2="${f1(xRechts)}" y1="${y}" y2="${y}" stroke="${l.farbe}" stroke-width="${st.w}"${st.d?` stroke-dasharray="${st.d}"`:''} opacity="${st.o}"/>`; });
 // 80-%-Spanne: Schluss heute (+1) und in 7 Tagen (+7), dazwischen nur verbunden
 if(mitBand){ const tb=Bd.basis_tag, xb=X(tb+0.5), yb=Y(Bd.basis_px), H1=Bd.h1, H7=Bd.h7;
  const pts=[[xb,yb]]; if(H1) pts.push([X(tb+1.5),Y(H1.hi)]); if(H7) pts.push([X(tb+7.5),Y(H7.hi)],[X(tb+7.5),Y(H7.lo)]); if(H1) pts.push([X(tb+1.5),Y(H1.lo)]);
  s+=`<path d="M${pts.map(q=>f1(q[0])+','+f1(q[1])).join('L')}Z" fill="${CB_F.spanne}" opacity="0.13"/>`;
  [[1,H1],[7,H7]].forEach(([hz,b])=>{ if(!b) return; const x=f1(X(tb+hz+0.5)), ya=f1(Y(b.hi)), yu=f1(Y(b.lo));
   s+=`<line x1="${x}" x2="${x}" y1="${ya}" y2="${yu}" stroke="${CB_F.spanne}" stroke-width="1.5" opacity="0.85"/><line x1="${f1(+x-3)}" x2="${f1(+x+3)}" y1="${ya}" y2="${ya}" stroke="${CB_F.spanne}" opacity="0.85"/><line x1="${f1(+x-3)}" x2="${f1(+x+3)}" y1="${yu}" y2="${yu}" stroke="${CB_F.spanne}" opacity="0.85"/>`
    +(pd*ZF>=60?`<text x="${x}" y="${f1(+yu+12)}" fill="${CB_F.muted}" font-size="9" text-anchor="middle">${hz===1?'heute':'+7 T'}</text>`:''); }); }
 // Kurs jetzt: Linie über alles, Punkt an der Uhrzeit von heute
 if(k){ const yk=Y(k); if(yk>=T_&&yk<=T_+PH){ const ts=(d.kurs&&d.kurs.ts)||d.jetzt, fr=Math.max(0,Math.min(1,ts/86400-(tl+1)));
   s+=`<line x1="${L}" x2="${f1(xRechts)}" y1="${f1(yk)}" y2="${f1(yk)}" stroke="${CB_F.kurs}" stroke-dasharray="3,3" opacity="0.55"/><circle cx="${f1(X(tl+0.5+fr))}" cy="${f1(yk)}" r="3" fill="${CB_F.kurs}" stroke="${CB_F.flaeche}" stroke-width="1.5"/>`; } }
 s+=`</g>`;
 // Beschriftungen im Bild (Bein-Extrem, Gegenbein, Linienenden) gemeinsam setzen: nie übereinander, sonst eine Zeile versetzt oder weg
 enden.forEach(e=>texte.push({x:xJetzt-6, y:e.y, t:e.t, a:'end'}));
 cbSetzen(texte, T_+10, T_+PH-3).forEach(e=>{ s+=`<text x="${f1(e.x)}" y="${f1(e.ly)}" fill="${CB_F.text}" font-size="10" text-anchor="${e.a}" paint-order="stroke" stroke="${CB_F.flaeche}" stroke-width="3">${esc(e.t)}</text>`; });
 // Niveau-Beschriftung: breit in der Spalte rechts (Nummer, Name, Preis, Abstand), schmal nur die Nummer am Ende der Linie
 const lab=sicht.map(l=>({l, y:Y(l.px)})).sort((p,q)=>p.y-q.y); cbVerteilen(lab, T_+7, T_+PH-7, breit?13:13);
 const badge=(x,y,nr,farbe)=>`<rect x="${f1(x)}" y="${f1(y-6.5)}" width="17" height="13" rx="3" fill="${CB_F.flaeche}" stroke="${farbe}"/><text x="${f1(x+8.5)}" y="${f1(y+3.5)}" fill="${CB_F.text}" font-size="9" text-anchor="middle">${nr}</text>`;
 lab.forEach(p=>{ const l=p.l;
  if(LC){ const x0=xRechts+4; s+=`<path d="M${f1(xRechts)},${f1(p.y)}L${f1(x0)},${f1(p.ly)}" stroke="${l.farbe}" fill="none" opacity="0.7"/>`+badge(x0,p.ly,l.nr,l.farbe)
    +`<text x="${f1(x0+21)}" y="${f1(p.ly+3.5)}" fill="${CB_F.text}" font-size="10">${esc(cbKurzname(d,l))} ${cbPx(l.px)} <tspan fill="${CB_F.muted}">${cbPct(l.dist,1)}</tspan><title>${esc(l.name)} · ${esc(l.quelle||'')}</title></text>`; }
  else{ const x0=xRechts-19; if(Math.abs(p.ly-p.y)>1) s+=`<path d="M${f1(x0-6)},${f1(p.y)}L${f1(x0)},${f1(p.ly)}" stroke="${l.farbe}" fill="none" opacity="0.7"/>`; s+=badge(x0,p.ly,l.nr,l.farbe); } });
 const ob_=NV.filter(l=>l.px>yHi).length, un_=NV.filter(l=>l.px<yLo).length;
 if(ob_) s+=`<text x="${f1(LC?xRechts+6:xRechts-4)}" y="${T_+10}" fill="${CB_F.muted}" font-size="9" text-anchor="${LC?'start':'end'}">▲ ${ob_} weitere darüber (Tabelle)</text>`;
 if(un_) s+=`<text x="${f1(LC?xRechts+6:xRechts-4)}" y="${T_+PH-4}" fill="${CB_F.muted}" font-size="9" text-anchor="${LC?'start':'end'}">▼ ${un_} weitere darunter (Tabelle)</text>`;
 // Kurs jetzt auf der Preisachse
 if(k){ const yk=Y(k); if(yk>=T_&&yk<=T_+PH) s+=`<rect x="${W-R+1}" y="${f1(yk-7)}" width="${R-3}" height="14" rx="3" fill="${CB_F.kurs}"/><text x="${W-R+4}" y="${f1(yk+3.5)}" fill="${CB_F.flaeche}" font-size="10" font-weight="600">${cbPx(k)}</text>`; }
 // RSI 14 im eigenen Feld
 s+=`<rect x="${L}" y="${T2}" width="${f1(pwGes)}" height="${RH}" fill="none" stroke="${CB_F.grid}"/>`;
 [30,50,70].forEach(v=>{ const y=f1(Yr(v)); s+=`<line x1="${L}" x2="${f1(xRechts)}" y1="${y}" y2="${y}" stroke="${CB_F.grid}"${v===50?'':' stroke-dasharray="2,3"'}/><text x="${W-R+4}" y="${f1(+y+3)}" fill="${CB_F.muted}" font-size="10">${v}</text>`; });
 let pr='', an=false; for(let i=a;i<n;i++){ const v=T.rsi[i]; if(v==null){ an=false; continue; } pr+=(an?'L':'M')+f1(X(t0+i))+','+f1(Yr(v)); an=true; }
 if(pr) s+=`<path d="${pr}" fill="none" stroke="${CB_F.linie}" stroke-width="1.3" stroke-linejoin="round"/>`;
 const rl=T.rsi[n-1];
 s+=`<text x="${L+4}" y="${T2+11}" fill="${CB_F.muted}" font-size="10" paint-order="stroke" stroke="${CB_F.flaeche}" stroke-width="3">RSI 14 (Wilder)${rl!=null?' · '+cbZ(rl,0):''} · eigenes Feld, Skala 0–100</text>`;
 // Fadenkreuz
 s+=`<line class="cbkreuz" x1="0" x2="0" y1="${T_}" y2="${T2+RH}" stroke="#58a6ff" opacity="0"/><line class="cbkreuzy" x1="${L}" x2="${f1(xRechts)}" y1="0" y2="0" stroke="#58a6ff" stroke-dasharray="3,3" opacity="0"/>`
  +`<rect class="cbhit" x="${L}" y="${T_}" width="${f1(pwGes)}" height="${T2+RH-T_}" fill="transparent" style="cursor:crosshair;touch-action:pan-y"/></svg>`;
 el.innerHTML=s;
 CB.geo={X, Y, L, pd, xa, T_, PH, T2, RH, tl, t0, n, a, ta, lab, y0, y1};
 cbLegende(d, {kerzen, bein:CB.sch.bein&&b0&&(d.zickzack||[]).length?Math.round(b0.X*100):0, swings:CB.sch.swings&&d.swings, band:mitBand, kurs:!!k, niveaus:CB.sch.niveaus&&sicht.length});
 const svg=el.querySelector('svg'), hit=el.querySelector('.cbhit'), kr=el.querySelector('.cbkreuz'), kry=el.querySelector('.cbkreuzy');
 const zeige=ev=>{ const r=svg.getBoundingClientRect(), px=ev.clientX-r.left, py=ev.clientY-r.top, g=CB.geo;
  const tag=Math.round(g.xa+(px-g.L)/g.pd); if(tag<g.ta||tag>g.tl+ZF){ kr.setAttribute('opacity','0'); kry.setAttribute('opacity','0'); hideTip(); return; }
  const x=f1(g.X(tag)); kr.setAttribute('x1',x); kr.setAttribute('x2',x); kr.setAttribute('opacity','0.7');
  const imBild=py>=g.T_&&py<=g.T_+g.PH; if(imBild){ kry.setAttribute('y1',f1(py)); kry.setAttribute('y2',f1(py)); kry.setAttribute('opacity','0.5'); } else kry.setAttribute('opacity','0');
  const Z=[], sw=c=>`<span style="display:inline-block;width:12px;height:2px;background:${c};vertical-align:middle;margin-right:5px"></span>`;
  let titel;
  if(tag<=g.tl){ const i=tag-g.t0; titel=`${cbDatum(tag)} (Tageskerze, Schluss 00:00 UTC)`;
   const o=T.o[i], h=T.h[i], l=T.l[i], c=T.c[i];
   if(o!=null&&o===h&&h===l&&l===c&&i>0&&T.c[i-1]===c) Z.push(['', 'aufgefüllter Tag (Lücke in den Daten)']);
   Z.push(['Eröffnung', cbPx(o)], ['Hoch', cbPx(h)], ['Tief', cbPx(l)], ['Schluss', cbPx(c)+(i>0&&T.c[i-1]?` <span style="color:#8b949e">(${cbPct(c/T.c[i-1]-1,1)})</span>`:'')]);
   if(T.ma50[i]!=null) Z.push([sw(CB_F.ma50)+'MA 50', cbPx(T.ma50[i])]); if(T.ma200[i]!=null) Z.push([sw(CB_F.ma200)+'MA 200', cbPx(T.ma200[i])]);
   if(T.rsi[i]!=null) Z.push(['RSI 14', cbZ(T.rsi[i],0)]);
   if(CB.sch.swings&&d.swings){ (d.swings.hoch||[]).forEach(z=>{ if(z[0]===tag) Z.push(['', 'Swing-Hoch '+cbPx(z[1])]); }); (d.swings.tief||[]).forEach(z=>{ if(z[0]===tag) Z.push(['', 'Swing-Tief '+cbPx(z[1])]); }); }
   if(CB.sch.bein) (d.zickzack||[]).forEach(z=>{ if(z[0]===tag) Z.push([sw(CB_F.bein)+'Bein', (z[2]>0?'Schlusshoch ':'Schlusstief ')+cbPx(z[1])+' (bestätigt)']); });
   if(CB.sch.bein&&b0&&b0.extrem_tag===tag) Z.push([sw(CB_F.bein)+'Bein', (b0.mode===1?'Schlusshoch ':'Schlusstief ')+cbPx(b0.extrem_px)+' (laufend, unbestätigt)']); }
  else{ const kk=tag-g.tl; titel=kk===1?'heute (Schluss 00:00 UTC morgen)':`+${kk} Tage nach dem letzten Schluss (${cbDatum(tag)})`;
   const b=kk===1?(Bd&&Bd.h1):kk===7?(Bd&&Bd.h7):null;
   if(b) Z.push(['80-%-Spanne', `${cbPx(b.lo)} – ${cbPx(b.hi)}`], ['Trefferquote 365 T', b.treffer!=null?cbZ(b.treffer*100,0)+' % (Soll 80 %)':'— (zu kurz)']);
   else if(mitBand&&kk<7) Z.push(['', 'Spanne nur für heute und +7 Tage, dazwischen verbunden']);
   if(k) Z.push(['Kurs jetzt', cbPx(k)]); }
  if(imBild){ const v=Math.exp(g.y1-(py-g.T_)/g.PH*(g.y1-g.y0)); Z.push(['Zeiger', cbPx(v)+(k?` <span style="color:#8b949e">(${cbPct(v/k-1,1)} zum Kurs)</span>`:'')]);
   const nah=g.lab.filter(p=>Math.abs(p.y-py)<7).slice(0,2); nah.forEach(p=>Z.push([cbNr(p.l.nr,p.l.farbe)+' ', esc(p.l.name)+' '+cbPx(p.l.px)])); }
  cbTip(ev, titel, Z); };
 hit.addEventListener('pointermove', zeige); hit.addEventListener('pointerdown', zeige);
 hit.addEventListener('pointerleave', ()=>{ kr.setAttribute('opacity','0'); kry.setAttribute('opacity','0'); hideTip(); }); }
function cbTip(ev, titel, zeilen){ const t=$('tip'); if(!t) return;
 t.innerHTML=`<div class="t">${titel}</div>`+zeilen.map(z=>`<div class="r"><i>${z[0]}</i><b style="color:#e6edf3">${z[1]}</b></div>`).join('');
 t.style.display='block'; const w=t.offsetWidth, h=t.offsetHeight; let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14; if(y<8) y=ev.clientY+18; x=Math.max(6,Math.min(x,innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; } t.style.left=x+'px'; t.style.top=y+'px'; }

// ---------- Start ----------
function cbCss(){ if($('cbcss')) return; const st=document.createElement('style'); st.id='cbcss';
 st.textContent=`#sec-chartbild .cbzeile{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0 8px}
 #sec-chartbild .cbzeile button.tog{min-width:0;padding:4px 9px}
 #sec-chartbild .cbzeile .lbl{font-size:10px;color:#8b949e;text-transform:uppercase;letter-spacing:.4px;margin-right:2px}
 #sec-chartbild .cbzeile .cbab{margin-left:10px} #sec-chartbild .cbzeile .cbtabbtn{margin-left:auto}
 #sec-chartbild .cbkopf{font-size:11px;color:#8b949e;margin:6px 0 4px;line-height:1.5} #sec-chartbild .cbkopf b{color:#e6edf3}
 #sec-chartbild .cblesart{margin:6px 0 10px;padding:8px 12px 8px 26px;background:#0d1117;border:1px solid #21262d;border-radius:6px}
 #sec-chartbild .cblesart li{font-size:12.5px;color:#c9d1d9;line-height:1.55;margin:3px 0}
 #sec-chartbild .cblesart li.schluss{list-style:none;margin-left:-14px;color:#8b949e;font-size:11px;margin-top:6px}
 #sec-chartbild .cbleg{margin:4px 0 6px} #sec-chartbild .cbleg span{display:inline-flex;align-items:center;gap:4px}
 #sec-chartbild .cbplot{width:100%} #sec-chartbild .cbnote{margin:5px 0 4px}
 #sec-chartbild .cbscroll{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #sec-chartbild .cbtabelle{max-height:440px;overflow-y:auto}
 #sec-chartbild h3.cbh3{font-size:12px;color:#e6edf3;margin:16px 0 4px;font-weight:600}
 #sec-chartbild table.w td{vertical-align:top}
 #sec-chartbild .lz{display:block;font-size:10px;color:#8b949e;white-space:normal;max-width:300px;line-height:1.35;margin-top:1px}
 #sec-chartbild .cbnr,#tip .cbnr{display:inline-block;min-width:13px;padding:0 3px;border:1px solid;border-radius:4px;font-size:10px;line-height:14px;text-align:center;color:#c9d1d9;background:#01030a;font-style:normal}
 #sec-chartbild .lz.lzn{white-space:nowrap} #sec-chartbild td.cbw{white-space:normal;min-width:190px;max-width:260px}
 #sec-chartbild tr.cbjetzt td{background:#161b22;color:#e6edf3;font-weight:600}
 #sec-chartbild .cbleer{padding:18px 8px;border:1px dashed #21262d;border-radius:6px}
 #sec-chartbild .cbdetails{margin:14px 0 4px} #sec-chartbild .cbdetails summary{cursor:pointer;color:#c9d1d9;font-size:12px}
 #sec-chartbild .cbpruef li,#sec-chartbild .cbfehlt li{font-size:11px;color:#8b949e;line-height:1.5;margin:2px 0}
 #sec-chartbild .cbpruef b{color:#c9d1d9;font-weight:600}
 #sec-chartbild .cbfuss{font-size:10px;color:#6e7681;margin-top:10px}
 @media (max-width:700px){ #sec-chartbild .cblesart{padding:8px 10px 8px 22px} #sec-chartbild .cblesart li{font-size:12px}
  #sec-chartbild .cbzeile button.tog{padding:6px 10px} #sec-chartbild .cbzeile .cbab{margin-left:0} #sec-chartbild .cbzeile .cbtabbtn{margin-left:0} }`;
 document.head.appendChild(st); }
function cbStart(){ if(!$('sec-chartbild')) return; cbCss(); cbLeiste();
 // erst laden, wenn die Coin-Liste der Seite steht (sonst würde BTC statt des gewählten Coins geladen)
 let n_=0; const warte=()=>{ const c=$('coin'); if((c&&c.options.length)||++n_>40) cbLaden(false); else setTimeout(warte,300); }; warte();
 const c=$('coin'); if(c) c.addEventListener('change',()=>{ if(cbOffen()) cbLaden(false); });
 setInterval(()=>{ if(cbOffen()) cbLaden(false); }, 120000);
 document.addEventListener('visibilitychange',()=>{ if(cbOffen()) cbLaden(false); });
 let rz=null; addEventListener('resize',()=>{ clearTimeout(rz); rz=setTimeout(()=>{ if(cbOffen()&&CB.d) cbZeichne(); },250); }); }
cbStart();
"""
