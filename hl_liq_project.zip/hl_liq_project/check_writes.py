#!/usr/bin/env python3
"""
Schreiblast messen: WAS wächst, und WIE VIEL wird tatsächlich auf den Datenträger geschrieben?

  python3 check_writes.py --db /pfad/hl_liq.db --seconds 60

Teil 1: Zeilen und Speicher je Tabelle jetzt (dbstat, sonst Schätzung), nach der Wartezeit
        erneut -> Zuwachs je Stunde. Das zeigt, welche Tabelle die Datenbank wachsen lässt.
Teil 2: Datei- und WAL-Größe vorher/nachher.
Teil 3: Geschriebene Bytes des Datenträgers aus /proc/diskstats (Kernel-Zähler, alle Prozesse)
        -> MB/h tatsächliche Schreiblast. Ist die viel größer als der Zuwachs, ist es
        Schreibverstärkung (WAL + Checkpoint + Indexseiten), nicht Datenmenge.
"""
import argparse, os, re, sqlite3, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def db_path() -> str:
    try:
        m = re.search(r"--db\s+(\S+)", Path("/etc/systemd/system/hl-recorder.service").read_text())
        if m:
            return m.group(1)
    except OSError:
        pass
    return str(ROOT / "hl_liq.db")


def table_stats(con) -> dict:
    """{tabelle: (zeilen, bytes)} -- bytes aus dbstat, sonst Schätzung über die Seitenzahl."""
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    out = {}
    has_dbstat = True
    try:
        con.execute("SELECT 1 FROM dbstat LIMIT 1")
    except sqlite3.Error:
        has_dbstat = False
    for t in tables:
        try:
            n = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            n = -1
        b = None
        if has_dbstat:
            try:
                # Tabelle plus ihre Indizes
                names = [t] + [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name=?", (t,))]
                b = sum(con.execute("SELECT COALESCE(SUM(pgsize),0) FROM dbstat WHERE name=?", (nm,)).fetchone()[0] for nm in names)
            except sqlite3.Error:
                b = None
        out[t] = (n, b)
    return out, has_dbstat


def all_devices() -> dict:
    """Geschriebene Bytes je Blockgerät (ohne Partitionen doppelt zu zählen ist egal -- wir zeigen alle)."""
    out = {}
    try:
        for line in open("/proc/diskstats"):
            f = line.split()
            if len(f) >= 10:
                w = int(f[9]) * 512
                if w > 0:
                    out[f[2]] = w
    except OSError:
        pass
    return out


def proc_writes() -> dict:
    """
    Geschriebene Bytes je Prozess aus /proc/<pid>/io.
    write_bytes = zum Datenträger geschickt; cancelled_write_bytes = wieder verworfen
    (z. B. gelöschte temporäre Dateien). Lesbar nur für eigene Prozesse -- sonst mit sudo.
    """
    out = {}
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            io = {}
            for line in open(f"/proc/{pid}/io"):
                k, _, v = line.partition(":")
                io[k.strip()] = int(v)
            cmd = open(f"/proc/{pid}/cmdline").read().replace("\0", " ").strip()
            if io.get("write_bytes", 0) or io.get("cancelled_write_bytes", 0):
                out[int(pid)] = (cmd[:70] or "?", io.get("write_bytes", 0), io.get("cancelled_write_bytes", 0))
        except (OSError, ValueError, PermissionError):
            continue
    return out


def swap_out() -> int | None:
    try:
        for line in open("/proc/vmstat"):
            if line.startswith("pswpout "):
                return int(line.split()[1]) * 4096
    except OSError:
        pass
    return None


def dir_size(path: str) -> int:
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def disk_written(dev: str) -> int | None:
    """Geschriebene Bytes des Blockgeräts laut /proc/diskstats (Sektoren × 512)."""
    try:
        for line in open("/proc/diskstats"):
            f = line.split()
            if len(f) >= 10 and f[2] == dev:
                return int(f[9]) * 512
    except OSError:
        pass
    return None


def device_of(path: str) -> str | None:
    try:
        st = os.stat(path); major, minor = os.major(st.st_dev), os.minor(st.st_dev)
        for line in open("/proc/diskstats"):
            f = line.split()
            if int(f[0]) == major and int(f[1]) == minor:
                return f[2]
    except (OSError, ValueError):
        pass
    return None


def fmt_b(b):
    return "—" if b is None else f"{b/1e6:,.1f} MB" if b < 1e9 else f"{b/1e9:,.2f} GB"


def main():
    p = argparse.ArgumentParser(); p.add_argument("--db", default=db_path()); p.add_argument("--seconds", type=int, default=60)
    a = p.parse_args()
    print(f"Datenbank {a.db} · Messdauer {a.seconds} s\n")
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    size0 = os.path.getsize(a.db); wal0 = os.path.getsize(a.db + "-wal") if os.path.exists(a.db + "-wal") else 0
    dev = device_of(a.db); w0 = disk_written(dev) if dev else None
    dev0 = all_devices(); p0_io = proc_writes(); sw0 = swap_out()
    jrn0 = dir_size("/var/log/journal") if os.path.isdir("/var/log/journal") else 0
    s0, has_dbstat = table_stats(con)
    print(f"Datei {fmt_b(size0)} · WAL {fmt_b(wal0)} · Datenträger {dev or '?'} · dbstat {'verfügbar' if has_dbstat else 'nicht verfügbar (nur Zeilen)'}")
    print(f"warte {a.seconds} s …", flush=True)
    time.sleep(a.seconds)
    size1 = os.path.getsize(a.db); wal1 = os.path.getsize(a.db + "-wal") if os.path.exists(a.db + "-wal") else 0
    w1 = disk_written(dev) if dev else None
    dev1 = all_devices(); p1_io = proc_writes(); sw1 = swap_out()
    jrn1 = dir_size("/var/log/journal") if os.path.isdir("/var/log/journal") else 0
    s1, _ = table_stats(con)
    con.close()
    k = 3600 / a.seconds
    print("\n1) Zuwachs je Tabelle (hochgerechnet auf eine Stunde):")
    rows = []
    for t in s1:
        n0, b0 = s0.get(t, (0, None)); n1, b1 = s1[t]
        dn = (n1 - n0) * k if n0 >= 0 and n1 >= 0 else None
        db_ = (b1 - b0) * k if (b0 is not None and b1 is not None) else None
        rows.append((t, n1, b1, dn, db_))
    rows.sort(key=lambda r: -(r[4] or 0) if any(r[4] for r in rows) else -(r[3] or 0))
    print(f"   {'Tabelle':<20} {'Zeilen jetzt':>14} {'Größe jetzt':>12} {'Zeilen/h':>12} {'MB/h':>10}")
    for t, n1, b1, dn, db_ in rows[:25]:
        if (dn or 0) == 0 and (db_ or 0) == 0 and n1 < 1000:
            continue
        print(f"   {t:<20} {n1:>14,} {fmt_b(b1):>12} {('—' if dn is None else f'{dn:,.0f}'):>12} {('—' if db_ is None else f'{db_/1e6:,.1f}'):>10}")
    print(f"\n2) Datei: {fmt_b(size0)} -> {fmt_b(size1)} ({(size1-size0)*k/1e6:+,.1f} MB/h) · WAL: {fmt_b(wal0)} -> {fmt_b(wal1)}")
    if w0 is not None and w1 is not None:
        print(f"3) Datenträger {dev}: {fmt_b(w1-w0)} in {a.seconds} s geschrieben -> {(w1-w0)*k/1e9:,.2f} GB/h tatsächliche Schreiblast (alle Prozesse auf diesem Gerät)")
        growth = (size1 - size0) * k
        if growth > 0 and (w1 - w0) * k > 3 * growth:
            print(f"   -> Schreiblast ist {((w1-w0)*k)/max(growth,1):.0f}× größer als der Zuwachs: Schreibverstärkung (WAL, Checkpoints, Indexseiten), nicht Datenmenge.")
        elif growth <= 0:
            print("   -> Datei wächst nicht: Schreiblast kommt aus Überschreiben/WAL/Checkpoints oder anderen Prozessen.")
    else:
        print("3) Datenträger-Zähler nicht lesbar (/proc/diskstats)")
    # Prognose-Ablage: liegt sie neben der Hauptdatenbank, zählt ihre Schreiblast in Teil 3 mit
    try:
        sys.path.insert(0, str(ROOT))
        import hl_forecast
        store = hl_forecast.STORE
        same = os.path.dirname(os.path.abspath(store)) == os.path.dirname(os.path.abspath(a.db))
        sz = os.path.getsize(store) / 1e6 if os.path.exists(store) else 0
        print(f"\n4) Prognose-Ablage: {store} ({sz:,.1f} MB) — {'auf demselben Medium, in Teil 3 enthalten' if same else 'ANDERES Medium (z. B. SD-Karte), NICHT in Teil 3 enthalten'}")
    except Exception:
        pass
    # ---- Wer schreibt wohin? ----------------------------------------------------------------
    print("\n5) Schreiblast JE LAUFWERK (so sieht man, was auf die SD-Karte geht):")
    rows = sorted(((n_, dev1.get(n_, 0) - v0) for n_, v0 in dev0.items()), key=lambda x: -x[1])
    for n_, d in rows[:8]:
        if d <= 0:
            continue
        root = ""
        try:
            for line in open("/proc/mounts"):
                f = line.split()
                if f[0].endswith(n_) or f[0].endswith("/" + n_):
                    root = f" ({f[1]})"; break
        except OSError:
            pass
        tag = "  <- SD-Karte" if n_.startswith("mmcblk") else "  <- Datenbank-Medium" if n_ == dev else ""
        print(f"   {n_:<12}{root:<28} {d/1e6:>9,.1f} MB in {a.seconds} s  =  {d*k/1e9:>6,.2f} GB/h{tag}")
    print("\n6) Schreiblast JE PROZESS (write_bytes aus /proc; nur eigene Prozesse — für alle: sudo):")
    procs = []
    for pid, (cmd, w, c) in p1_io.items():
        w0_, c0_ = (p0_io.get(pid) or ("", 0, 0))[1:]
        dw, dc = w - w0_, c - c0_
        if dw > 0 or dc > 0:
            procs.append((dw, dc, pid, cmd))
    procs.sort(reverse=True)
    if procs:
        for dw, dc, pid, cmd in procs[:10]:
            note = f" · davon verworfen {dc/1e6:,.1f} MB" if dc > 0 else ""
            print(f"   {dw/1e6:>9,.1f} MB ({dw*k/1e9:>5,.2f} GB/h)  PID {pid:<7} {cmd}{note}")
    else:
        print("   keine Schreibvorgänge sichtbar — mit sudo erneut ausführen, um fremde Prozesse zu sehen")
    if sw0 is not None and sw1 is not None and sw1 > sw0:
        print(f"\n   ACHTUNG Swap: {(sw1-sw0)/1e6:,.1f} MB ausgelagert ({(sw1-sw0)*k/1e9:,.2f} GB/h) — "
              f"Auslagerungsdatei liegt meist auf der SD-Karte. Speicher knapp?")
    if jrn1 > jrn0:
        print(f"   systemd-Journal: +{(jrn1-jrn0)/1e6:,.1f} MB ({(jrn1-jrn0)*k/1e9:,.2f} GB/h) in /var/log/journal (SD-Karte)")
    print("\nHinweis: Für einen aussagekräftigen Wert 5 Minuten messen: --seconds 300")


if __name__ == "__main__":
    main()
