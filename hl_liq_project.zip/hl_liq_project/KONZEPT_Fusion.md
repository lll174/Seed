# KONZEPT Fusion — ein fusionierter Treiber für die Kursprognose

**Stand 04.10.2026 · Version 2026-09-23.42 · Claude Opus 5.5**
**Stufe 1 gebaut und im Schatten (U104–U107), Auswertung U108, Stufen 2–3 geplant (U109–U112, `UPDATE_PLAN.md`)**

> Anlass (Nutzer, nach 23.41): „Hast du Ideen oder Überlegungen, ob es mathematische oder psychologische Ansätze gibt, aus
> den gesammelten Daten, der Dynamik der Kurse, der Historie etc. die Kursprognose mit einem fusionierten Treiber in eine
> Formel zu packen, die einen noch besseren prädiktiven Wert erzielt?“ — danach: „Leg los. Mach es perfekt und fehlerfrei.“

---

## 0. Kurz

Eine einzelne Zauberformel, die alles schlägt, gibt es nicht. Es gibt aber einen mathematisch sauberen Weg, alle Quellen zu
EINER Wahrscheinlichkeit zu verschmelzen, und jeder Schritt darauf ist prüfbar:

1. **Jede Quelle liefert eine Wahrscheinlichkeit** (v1, v2, v3, Analog-Suche, Basisrate) — nicht einen Punktwert. Wie viel
   sie taugt, entscheidet die Mischung an ihren Ergebnissen, nicht ihr Ruf.
2. **Stärke über Coins leihen:** Was in allen Coins gleich wirkt, wird gemeinsam geschätzt; eine Abweichung je Coin nur gegen
   Beleg (v3).
3. **Online mischen, mit Garantie:** Die Mischung lernt nach jedem aufgelösten Block, welchem Experten sie wie weit traut.
   Sie ist beweisbar höchstens um eine feste Konstante schlechter als der beste einzelne Experte (Abschnitt 3.3).
4. **Erst handeln, wenn der Vorsprung die Kosten trägt:** p* = ½ + K / (2·E|r|) (Abschnitt 3.1).
5. **Psychologie als Messung, nicht als Erzählung:** Einstandsanker, Stop-Jagd, Herden, Selbstanregung von Kaskaden werden zu
   Treibern mit Nulltest und Positivkontrolle (Stufe 2) und laufen dann durch dieselbe Maschine.

Die fusionierte Formel (Stufe 1, gebaut):

```
p_Fusion(t) = Σ_m π_m(t) · p_m(t) / Σ_m π_m(t)        Summe über die Experten m, die zur Zeit t eine Zahl haben
p_v3        = sig( a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f )
handeln, wenn |2 · p_Fusion − 1| · E|r_h| ≥ 1,5 · K    (Labor-Strategie „Fusion mit Kostenschwelle“)
```

**Was 23.42 gebaut hat (alles im Schatten, die angezeigte P(aufwärts) bleibt v1 bzw. v2):** Kostenschwelle je Coin und Horizont
(Anzeige und Payload), Kalibrierung v3 (v2 über alle Coins geteilt), Fusionsprognose als Expertenmischung, zwei neue
Labor-Strategien mit eigener Kennung. Modul `hl_fusion.py`, Selbsttest `python3 hl_fusion.py --nulltest` (Installationsschritt).

---

## 1. Leitlinien

1. **Bewertet wird mit dem Log-Verlust** −ln q (q = vorhergesagte Wahrscheinlichkeit des Eingetretenen), dazu Brier. Beide sind
   strikt richtige Bewertungsregeln: Den kleinsten erwarteten Verlust erreicht nur, wer seine wahre Überzeugung nennt. Die
   Trefferquote allein belohnt Überzeugung ohne Kalibrierung (55 % und 95 % zählen gleich).
2. **Prequential** (Dawid 1984): Jede Zahl steht fest, bevor ihr Ergebnis bekannt ist, und wird erst danach bewertet. Das gilt
   auch für den Nachtrag aus gespeicherten Prognosen.
3. **n_eff = getrennte Horizont-Blöcke** (eiserne Regel 4), nie Fensterzahl. Standardfehler über Coins zählen Zeitblöcke als
   Klumpen: Fälle verschiedener Coins im selben Block hängen zusammen.
4. **Jede Komponente hat einen Nulltest und eine Positivkontrolle**, und die Proben werden mit Mutationen geprüft: Eine
   absichtlich falsche Regel muss im Selbsttest rot werden.
5. **Schatten zuerst.** Umgeschaltet wird nur mit Beleg (U108), wie bei v2.
6. **Die Daten sind knapp.** Mit 14 Tagen Halbwertszeit über 90 Tage hat ein Coin rund **237 effektive 4-h-Blöcke**
   (Kish-n_eff der Gewichte), die Trefferquote also einen Standardfehler von **3,3 Punkten**. Auf 24 h sind es rund 40 Blöcke
   (8 Punkte). Deshalb: wenige Parameter, Schrumpfen überall, keine tiefen Netze, keine Interaktionsmodelle ohne Vorbelegung.

---

## 2. Werkzeugkasten

| Werkzeug | Was es leistet | Stufe |
|---|---|---|
| Strikt richtige Bewertungsregeln (Log-Verlust, Brier) | ehrliche Wahrscheinlichkeiten, Vergleich aller Modelle auf einer Skala | alle |
| Entscheidungsregel mit Kosten | nötige Trefferquote p* aus Kosten und mittlerer Bewegung | 1 |
| Hierarchisches Teilen (James-Stein, empirischer Bayes; L2-Strafe gegen den gemeinsamen Wert) | Stärke über Coins leihen, Abweichung je Coin nur gegen Beleg | 1 (v3) |
| Expertenmischung: aggregierender Algorithmus (Vovk 1990), Bayes-Mischung, schlafende Experten (Freund, Schapire, Singer, Warmuth 1997), Fixed Share (Herbster, Warmuth 1998) | Garantie gegenüber dem besten Experten, Anpassung an Regimewechsel | 1 |
| HAR-RV (Corsi 2009) | Volatilitätsprognose aus Tages-, Wochen- und Monatsschwankung | 2 |
| Konforme Vorhersage (Vovk, Gammerman, Shafer 2005; adaptiv: Gibbs, Candès 2021) | Bänder mit garantierter Abdeckung, auch bei Drift | 2 |
| Reflexionsprinzip der Brownschen Bewegung | Berührwahrscheinlichkeit eines Niveaus — Nullmodell für „Magnete“ | 2 |
| Hawkes-Prozess (Hawkes 1971) | Selbstanregung von Liquidationen, Nähe zur Kaskade | 2 |
| Dispositionseffekt (Shefrin, Statman 1985), Ankern (Tversky, Kahneman 1974) | Einstandsanker, Schmerzindex | 2 |
| Herdenmaß LSV (Lakonishok, Shleifer, Vishny 1992) | Herdenverhalten der verfolgten Konten | 2 |
| Mischung mit Tor / Spezialisten (Jacobs, Jordan, Nowlan, Hinton 1991) | Gewichte je Marktregime | 3 |

---

## 3. Stufe 1 — gebaut in 23.42 (Schatten)

### 3.1 Kostenschwelle (U104)

**Herleitung.** Ein Richtungsurteil mit Trefferquote p über den Horizont h bringt im Mittel
p · E|r_h| − (1 − p) · E|r_h| = (2p − 1) · E|r_h|, wenn die Größe der Bewegung nicht davon abhängt, ob das Urteil stimmt.
Es lohnt sich erst, wenn das die Kosten K eines Hin- und Rückwegs deckt:

```
p* = 1/2 + K / (2 · E|r_h|)
```

- **E|r_h|** wird gemessen, nicht aus einer Normalverteilung angenommen: Mittel von |ln(P(t+h)/P(t))| über die letzten 30 Tage,
  t im 15-min-Raster (überlappende Fenster; der Mittelwert bleibt unverzerrt), Kurs der Minutenkerze zur Zeit t oder bis
  2 min davor, mindestens 288 Punkte (3 Tage). Horizonte 1, 4, 12, 24 h.
- **K Taker** = 2 · (Taker-Gebühr + halber Spread), der halbe Spread als Median der Buch-Snapshots der letzten Stunde.
  **K Maker** = 2 · Maker-Gebühr. Sätze wie im TradeLabor (0,045 % / 0,015 % je Seite; XMR als HIP-3-Markt doppelt, angenommen).
- Je Coin stündlich neu (Zwischenspeicher 1 h). Die Schwelle kann über 100 % liegen: Dann ist der Horizont mit diesen Kosten
  nicht zu schlagen (Anzeige „unerreichbar“).

**Größenordnung** (45 % Jahresschwankung = 0,062 % je Minute, BTC-typisch; halber Spread 1 bp):

| Horizont | E\|r\| | Taker | Maker | XMR Taker |
|---|---|---|---|---|
| 1 h | 0,38 % | 64,3 % | 53,9 % | 73,5 % |
| 4 h | 0,77 % | 57,2 % | 52,0 % | 61,7 % |
| 12 h | 1,33 % | 54,1 % | 51,1 % | 56,8 % |
| 24 h | 1,88 % | 52,9 % | 50,8 % | 54,8 % |

**Folgerung:** Auf 4 h braucht ein Taker-Handel rund 57 % Trefferquote. Eine echte Kante von 55 % lohnt dort nur als Maker
(Limit-Order, deren Füllung nicht sicher ist) oder auf längeren Horizonten. Die echten Zahlen je Coin zeigt das Dashboard.

**Anzeige:** Kachel „P(aufwärts) Fusion — Schatten“ in der AI-Prognose (Taker/Maker für 4 h und 24 h, „darüber/darunter“ für die
Fusion in ihrer Richtung, E|r| 4 h); Debug „★ Fusion und v3“ mit allen vier Horizonten. **Gespeichert** im Payload als `kosten`
(flache Schlüssel `er_h`, `p_taker_h`, `p_maker_h`, `k_taker`, `k_maker`, …), damit das Labor sie lesen kann.

**Grenze:** Das 30-Tage-Mittel hinkt einem Regimewechsel der Schwankung nach — Stufe 2 (U109, HAR).

### 3.2 Kalibrierung v3 — v2 über alle Coins geteilt (U105)

```
p = sig( a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f )
```

| Zeichen | Bedeutung |
|---|---|
| x_f | Familienwert: Mittel der vorhandenen Treiber-Scores der Richtungsfamilie f (Score-Skala −1 … +1) |
| s_c,f | Streuung des Familienwerts je Coin im Trainingsfenster (mindestens 0,05; unter 10 Werten 1,0) — β wirkt je Standardabweichung |
| β_f | gemeinsames Gewicht aller Coins, L2-Strafe λ_β · Σβ² / F |
| δ_f,c | Abweichung eines Coins vom gemeinsamen Gewicht, L2-Strafe λ_δ = r · λ_β (r = ∞: ganz geteilt) |
| a_c | Achsenabschnitt je Coin (eigene Drift) |
| c | Kalibrierfaktor aus den OOF-Vorhersagen (0 = Basisrate je Coin) |

**Die sieben Richtungsfamilien** (aus `hl_familien.py`): Großkonten-Fluss (9 Treiber), Trend lang (3), Momentum kurz (3),
Orderfluss (4), Funding (2), ETF (2), Analog (1). Nicht dabei: „Stärke“ (sagt die Größe einer Bewegung vorher, nicht die
Richtung), die Schatten-Familie „Pool-Konten“ (ihre Treiber sind auch aus v1 und v2 ausgenommen, die Historie ist kurz) und der
Live-Profi-Flow (keine gespeicherten Treiber). Sieben Familien statt rund 30 Treiber: weniger Parameter für wenige Daten.

**Daten wie v2:** 90 Tage aus `forecast_slim`/`forecast_drivers`, je Coin und h-Block die früheste Prognose, Toleranz-Labels
(Bewegung unter 0,2 % ohne Urteil, M7), Alters-Gewicht mit 14 Tagen Halbwertszeit, Spot-Taker-Flow erst ab der Seiten-Umstellung
(U41). Ein Coin braucht mindestens 15 Fälle, das Modell mindestens 60.

**Wahl von λ_β und r:** geblockte Kreuzvalidierung über die Zeit (5 Folds; alle Coins eines Zeitraums im selben Fold, Embargo h).
Verglichen wird der Treiberanteil out-of-fold, mit den Achsenabschnitten je Coin aus denselben OOF-Fällen — mit den
Achsenabschnitten der Trainingsfolds lag der OOF-Verlust in der Probe bei jeder Einstellung über ln 2 (die Drift eines Zeitraums
passt nicht auf den nächsten), und dieses Rauschen überdeckte die Kante. Dann die 1-SE-Regel mit **gepaartem** Standardfehler
(Zeitblöcke als Klumpen) mit Vorrang für das Teilen (größtes r), dann das größte λ_β. Mit der Streuung der Fold-Mittel als
Standardfehler wählte die Regel fast immer das stärkste λ.

**Kalibrierschritt:** p = sig(a_c + c · η) auf den OOF-Vorhersagen, c ∈ {0; 0,1; …; 1}: das KLEINSTE c innerhalb eines
(blockweisen) Standardfehlers des besten. Ohne Beleg c = 0 — dann nennt v3 je Coin die Basisrate.

**Betrieb:** stündlich im Familien-Takt des Dashboards (erstmals 5 min nach dem Start), beide Horizonte, gespeichert als
learned „*“/`kalib3_4` und `kalib3_24` (Fehler sichtbar in `kalib3_h_fehler`). Jede Prognose trägt `p_up_v3` (gespeichert) und
`p_up_24_v3`, die Kachel „Fusion und Kalibrierung v3“ zeigt n, n_eff, Coins, λ, Teilen, c und die OOF-Kennzahlen.

**Probe (Selbsttest, 5 Szenarien je Prüfung, synthetischer Markt mit 6 korrelierten Coins):**

| Prüfung | Soll | Ergebnis 23.42 |
|---|---|---|
| Tor: Kante 0,65 in allen Coins | Log-Odds-Beitrag bei Familienwert +0,6 zwischen 0,20 und 1,00 (wahr +0,62) | Mittel +0,48 (0,39 … 0,61) |
| Rauschen | p bewegt sich < 5 Punkte, Brier-Skill ≤ 0,02 | 0,0 Punkte, +0,000 |
| Rauschen: vorsichtige Wahl | stärkstes λ und ganz geteilt in ≥ 4 von 5, c = 0 in ≥ 3 von 5 | 5 von 5, c = 0 in 4 von 5 |
| Gleichlauf aller Treiber ohne Signal | ≤ 7 Punkte | höchstens 3,6 Punkte |
| Teilen: gemeinsame Kante 0,62, 30 Tage | v3 im Mittel > 0,15 und ≥ 2 × v2 je Coin allein | v3 +0,26 gegen v2 +0,08 (wahr +0,49) |
| Kante nur in einem Coin (0,80) | Abweichung je Coin gewählt (≥ 4 von 5), dort ≥ 2 × der übrigen | 5 von 5, +0,37 gegen +0,08 |
| Training = Vorhersage | dieselbe Zahl über `p_up_v3` aus `forecast_drivers` | größte Abweichung 5,4·10⁻⁶ (Rundung) |
| U41 | Spot-Taker-Flow vor der Seiten-Umstellung nicht in „Orderfluss“ | 0 von 28 davor, 24 von 24 danach |

Eine Erkundung mit 20 Szenarien bei einer gemeinsamen Kante von 0,60 ergab v3 im Mittel rund dreimal so stark wie v2 je Coin.

### 3.3 Fusionsprognose — Expertenmischung (U106)

**Experten:** Basisrate (geglättete Aufwärtsquote der aufgelösten Blöcke, 14 Tage Halbwertszeit, je ein Pseudo-Fall auf und
ab), v1, v2 (nur Modelle ab Version 2, die übersicherten vor 23.26 nicht), v3, Analog-Suche (Anteil steigender Analoge, mit
50 Pseudo-Fällen zur eigenen Basisrate geschrumpft: Aus rund 50 Analogen schwankt die Quote ohne jeden Inhalt um ±7 Punkte).
Alle Wahrscheinlichkeiten werden auf [0,02; 0,98] geklemmt — ein Block kostet dann höchstens ln 50 = 3,9 Nats.

**Vorhersage und Lernen** (je Coin und Horizont, nach jedem aufgelösten Block):

```
p_Fusion = Σ_wach π_m · p_m / Σ_wach π_m
π_m ← π_m · q_m(y) / q_Fusion(y)          nur für wache Experten (q = vorhergesagte Wahrscheinlichkeit des Eingetretenen)
π   ← (1 − α) · π + α / M                  Fixed Share, α = min(0,05; h / (14 · 24))
```

Schlafende Experten (ohne Zahl in diesem Block, z. B. v3 vor dem ersten Modell) behalten ihr Gewicht; die Summe der wachen
Gewichte bleibt beim Lernschritt gleich. **Garantie** für jede Folge von Ergebnissen, auch gegnerisch gewählte, und für jeden
Experten m über seine wachen Runden:

```
L_Fusion − L_m ≤ ln M + (T − 1) · ln(1 / (1 − α))          M = 5:  ln 5 = 1,61 Nats
```

α entspricht einer erwarteten Regimedauer von 14 Tagen (4 h: α = 0,0119; 24 h: gedeckelt bei 0,05, also 20 Tage). Fixed Share kostet in einer
stillstehenden Welt etwas (die Mischung legt sich nie ganz fest) und holt nach einem Regimewechsel schneller auf (Probe: 234
gegen 290 Nats über 400 Blöcke nach dem Wechsel).

**Speicherung:** Tabelle `fusion_fall` im Prognosespeicher, eine Zeile je Coin, Horizont und Block (die früheste Prognose des
Blocks zählt, eine zweite ändert nichts): Experten-Zahlen, Fusionszahl, Gewichte, Quelle (`live`/`nachtrag`), Rendite, Richtung
y (1/0; −1 = unter der Toleranz, ohne Urteil; −2 = einen Tag nach Ablauf noch ohne Kurs). Im Payload jeder Prognose stehen nur
`fusion` (p und Anteile je Horizont) und `kosten`; die Bilanz und die Experten (`fusion_info`) sowie die v3-Zusammenfassung
(`kalib3`) sind reine Anzeige — sonst wüchse jede Prognosezeile um rund 4 kB.

**Nachtrag beim ersten Lauf:** Ist `fusion_fall` für einen Coin und Horizont leer, werden die gespeicherten Prognosen (60 Tage
Vorhalt) als Blöcke nachgetragen — ebenfalls prequential: Jeder nachgetragene Block sieht nur Ergebnisse, die zu seinem Zeitpunkt
schon feststanden; v3 gab es damals nicht (schläft). Für die Auswertung U108 zählen die live gestellten Blöcke getrennt.

**Bilanz** (Kachel und Debug): Log-Verlust je Block der Fusion gegen die Basisrate und jeden Experten auf denselben Blöcken,
**Abstand Fusion − Basisrate je Block ± 1 Standardfehler** (gepaart; belegt erst jenseits von 2 Standardfehlern), bester Experte,
Quote (Enthaltung unter 2 Punkten), Brier-Skill, Grenze der Nachrechnung. Der Debug-Bericht zeigt dazu je Coin die live gestellten
Blöcke getrennt und am Ende **alle Coins zusammen** (Abschnitt „Alle Coins (Auswertung U108)“): Fusion minus jeden Experten auf
dessen Blöcken, Standardfehler mit Zeitblöcken als Klumpen (Blöcke verschiedener Coins zur selben Zeit hängen über den gemeinsamen
Markt zusammen; als unabhängig gezählt wäre der Standardfehler zu klein), ✓ = belegt besser, ✗ = belegt schlechter.

**Probe:**

| Prüfung | Ergebnis 23.42 |
|---|---|
| Grenze auf 90 Folgen × 5 Experten (zufällig, gegnerisch, mit Schläfern; α = 0 / 0,012 / 0,05) | 0 Verletzungen |
| Rauschen (Experten ohne Wissen, Ergebnis mit 55 % Drift) | Fusion − Basisrate +2,61 Nats über 600 Blöcke (Grenze 8,78), nicht sicherer als die Basisrate (6,0 gegen 10,4 Punkte von 50 %) |
| Ein Experte kennt die wahre Wahrscheinlichkeit | Gewicht 85 % |
| Regimewechsel | Fixed Share 234 gegen reine Bayes-Mischung 290 Nats |
| Schläfer stören die Wachen nicht | Anteile identisch (auf 10⁻⁹) |
| Nur Ergebnisse, die feststanden; Blöcke ohne Urteil zählen nicht; Basisrate nur aus Feststehendem | ok |
| Abstand zur Basisrate mit Standardfehler | unabhängig nachgerechnet, gleich |
| Alle Coins: Standardfehler mit Zeitblöcken als Klumpen (3 Coins mit gleicher Richtung je Block) | unabhängig nachgerechnet, gleich; 1,75-mal so groß wie der naive |
| Ende zu Ende über `ergaenzen()`: Nachtrag, Auflösen, Mischung, Zeile je Block, Bilanz, Debug-Bericht | 60 Blöcke nachgetragen; v2 (immer richtige Richtung, 62 %) hat 96 % Anteil; zweite Prognose im Block ändert nichts; Toleranz ohne Urteil; Fusionszahl und Basisrate je Block unabhängig nachgerechnet (Abweichung 4,9·10⁻⁶) |

### 3.4 Zwei neue Labor-Strategien (U107)

| Strategie | Kennung | Regel |
|---|---|---|
| Prognose Fusion | `prognose_fusion@40662765` | P(aufwärts 4 h) der Fusion ≥ 58 % → Long, ≤ 42 % → Short (dieselbe Schwelle wie „Prognose v1“); Stop 1,5 σ, Ziel 2 σ, 4 h |
| Fusion mit Kostenschwelle | `prognose_fusion_kosten@aefe5404` | in Richtung der Fusion, nur wenn \|2p − 1\| · E\|r 4 h\| ≥ 1,5 × K; K = Taker-Gebühr beider Seiten (XMR doppelt) plus Abstand zur Buchmitte einer Markt-Order von 10.000 USD beim Ein- und Ausstieg, aus dem aktuellen Buch; Stop 1,5 σ, Ziel 2 σ, 4 h |

Beide lesen `fusion.p_4` und `kosten.er_4` aus dem Payload der jüngsten Prognose (höchstens 30 min alt). Der Vergleich beider an
DERSELBEN Prognose zeigt, was der Kostenfilter bringt. Der Faktor 1,5 ist ein Puffer gegen den Schätzfehler von p. Die übrigen
35 Kennungen sind unverändert.

### 3.5 Was Stufe 1 bewusst nicht tut

- **Keine Wirkung** auf die angezeigte P(aufwärts), den Pfad, Bias, Kauf- und Verkaufspreise.
- **Kein Familien-Experte:** Die Familien-Prognose (`hl_familien`) wird nicht je Prognose gespeichert (kein Nachtrag möglich), und
  bis eine Familie aufgestiegen ist, ist sie eine Basisrate ohne Halbwertszeit — ein Doppel der Basisrate, das nur ln M kostet.
  Kommt in Stufe 3, sobald eine Familie aufsteigt.
- **Keine Pool-Konten in v3** (siehe 3.2) und **keine Wechselwirkungen** zwischen Familien (zu wenige Daten; Konstellationen
  bleiben Stufe 2 der Konstellations-Statistik).
- **Kein Umschalten** — erst nach U108.

### 3.6 Ehrliche Erwartungen

- **Datenmenge:** Rund 237 effektive 4-h-Blöcke je Coin → Standardfehler der Trefferquote 3,3 Punkte. Eine Kante von 55 % liegt
  je Coin bei 1,5 Standardfehlern — nicht belegbar. In der Probe fand selbst ein Modell, das nur die eine richtige Familie kennt,
  eine 55-%-Kante über 90 Tage kaum. Auf 24 h (rund 40 effektive Blöcke) ist jede Aussage noch Wochen lang Rauschen.
- **Wert einer Kante im Log-Verlust je Block:** 55 % → 0,005 Nats, 58 % → 0,013, 60 % → 0,020. In der Rauschprobe kostete die
  Mischung 0,004 Nats je Block gegenüber der Basisrate. Ohne echte Kante ist die Fusion also erwartbar ein wenig schlechter als die
  Basisrate — die Bilanz sagt dann „nicht belegt“, und genau das ist die richtige Antwort.
- **Schlimmster Fall der Mischung** gegen den besten einzelnen Experten über 120 Tage: 4 h höchstens 10,2 Nats (0,014 je Block),
  24 h höchstens 7,7 Nats (0,064 je Block). Real liegt der Abstand meist weit darunter, die Grenze ist eine Garantie, keine
  Erwartung.
- **Kosten:** Auf 4 h braucht ein Taker-Handel rund 57 % Trefferquote. „Fusion mit Kostenschwelle“ wird deshalb selten handeln;
  das ist gewollt.
- **Teilen hilft, wenn die Kante gemeinsam ist** (Probe: v3 zwei- bis dreimal so stark wie v2), nicht bei einer Kante, die nur ein
  Coin hat — dort braucht die Abweichung je Coin starke Belege.
- **Ein realistischer Erfolg** wäre: Fusion 4 h über alle Coins belegt besser als die Basisrate (Abstand jenseits von 2 SE) und
  nicht schlechter als der beste einzelne Experte. Wahrscheinlich ist ein kleiner, langsam belegbarer Vorsprung — oder keiner.

---

## 4. Stufe 2 — neue Information (U109–U111)

Jede neue Größe kommt als Treiber oder Familie mit **Nulltest** (gemischte Zeitachse bzw. Zufallsniveaus: kein Vorsprung) und
**Positivkontrolle** (synthetischer Markt mit eingebauter Wirkung: wird gefunden) in `check_treiber.py`, läuft zuerst im
Parallelbetrieb der Familien und geht danach als Familie in v3 oder als eigener Experte in die Mischung.

### U109 — Schwankung: HAR-RV, konforme Bänder, Grid-Variante

- **HAR-RV** (Corsi 2009): RV_morgen = b0 + b_d · RV_Tag + b_w · RV_Woche + b_m · RV_Monat, geschätzt je Coin auf 5-min-Renditen.
  Ersetzt das 30-Tage-Mittel in E|r_h| (Kostenschwelle) und die Breite des Pfadbands. Abnahme: kleinerer Prognosefehler von |r_h|
  als das 30-Tage-Mittel außerhalb der Stichprobe (QLIKE, Diebold-Mariano auf Blöcken).
- **Konforme Bänder:** Bandbreite aus den eigenen Fehlern der letzten Wochen so gewählt, dass die Abdeckung garantiert ist
  (adaptiv nach Gibbs/Candès, damit die Garantie bei Drift hält). Abnahme: 80-%-Band trifft 80 % ± 2 SE über 4 Wochen.
- **Grid-Variante** mit Stufen aus dem HAR-σ statt fester 0,2 %: nur als neue Labor-Kennung (Regeln eingefroren).

### U110 — Anker mit Berührwahrscheinlichkeit

Für eine Bewegung ohne Drift mit Schwankung σ ist die Wahrscheinlichkeit, ein Niveau im Log-Abstand d binnen h zu berühren,
P = 2 · (1 − Φ(|d| / (σ · √h))) (Reflexionsprinzip). Das ist das **Nullmodell für „Magnete“**: Ein Cluster zieht nur dann an, wenn
es öfter berührt wird, als P vorhersagt. Schritte: (1) Kalibrierung des Nullmodells auf allen Clustern (Berührquote je Klasse von
P innerhalb 2 SE), (2) Überschuss je Clustergröße (relativ zum Volumen), (3) Treiber „Zug“ = Σ Notional · P_Berühr oben minus
unten, nur bei belegtem Überschuss. Ergänzt den Heatmap-Anker (23.28) um eine saubere Basis.

### U111 — Psychologie als Messung

- **Einstandsanker und Schmerzindex** (Dispositionseffekt, Ankern): Aus `whale_positions`/`pool_positions` (Einstandspreis,
  Größe, uPnL) je Coin: Notional der Longs, deren Einstand knapp ÜBER dem Kurs liegt (bis 1 σ), minus Notional der Shorts mit
  Einstand knapp DARUNTER — „Angebot zum Einstand“ (wer im Minus liegt, verkauft gern bei plus/minus null). Dazu der
  Schmerzindex: Anteil des Notionals unter Wasser, gewichtet mit dem Abstand zur Liquidation. Normiert auf das Stundenvolumen.
- **Stop-Topologie und Jagd-Rentabilität:** Für Ziele oberhalb und unterhalb (Liquidationen aus der Heatmap, Stops aus
  `trigger_orders`): erzwungener Fluss am Ziel geteilt durch die Buchtiefe bis dorthin (`book_summary`). Ist das Verhältnis groß,
  lohnt eine Jagd — Treiber = Log-Verhältnis oben minus unten.
- **Herdenmaß LSV:** je Coin und Stunde unter den handelnden verfolgten Konten (Adress-Strom) p = Anteil der Netto-Käufer,
  H = |p − p̄| − E|p − p̄| (Erwartung unter der Binomialverteilung), mit Vorzeichen: Kauf- gegen Verkaufsherde.
- **Hawkes-Intensität (Kaskadennähe):** λ(t) = μ + Σ a · e^{−b (t − t_i)} je Coin und Seite für Liquidationen und große
  Taker-Aufträge; Verzweigungsrate n = a/b nahe 1 heißt kaskadenanfällig. Zur Familie „Stärke“ (Größe) und mit Seitenvorzeichen
  als Richtungstreiber. Nulltest: Poisson-Ereignisse → n ≈ 0; Positivkontrolle: simulierter Hawkes-Prozess mit n = 0,7 → 0,6–0,8.

---

## 5. Stufe 3 — Struktur (U112) und Umschalten

- **Regime-Tor über Spezialisten:** Die schlafenden Experten der Mischung erlauben Experten, die nur in einem Regime wach sind
  (z. B. „v2 bei hoher Schwankung“, „v2 bei niedriger“, nach dem Vol-Regime aus `hl_indikatoren`; Trend/kein Trend;
  Funding-Extrem). Die Garantie gilt dann je Regime, ohne neue Parameter außer der Regime-Einteilung.
- **Familien-Experte**, sobald eine Familie aufsteigt: dann deren Prognose je Prognose speichern und als Experten aufnehmen.
- **v3 mit langem Gedächtnis** als zusätzlicher Experte (ohne Halbwertszeit, 90 Tage gleich gewichtet: n_eff 540 statt 237,
  Standardfehler 1,5-mal kleiner). Die Mischung entscheidet zwischen schneller Anpassung und statistischer Kraft — die
  Antwort auf die 55-%-Grenze.
- **Pool-Konten in v3**, sobald die Familie 60 Tage Historie hat und ihren Nulltest besteht.
- **Umschalten:** Die Fusion trägt die angezeigte P(aufwärts) nur, wenn U108 bestanden ist — Schalter im Prognosespeicher wie bei
  v2, jederzeit zurück. Pfad und Bias folgen dann der Fusion (wie bei U7b für v2 vorgesehen).

---

## 6. Auswertung und Abnahme (U108)

**Termine:** einmaliger Bericht 11.10. 19:30 (Berichtsplan `u106-fusion-woche1`: „★ Fusion und v3“, Selbsttest, „★ TradeLabor“),
wöchentlich mittwochs 19:00 (W11) und zur Auswertung U108 am **25.10. 19:30** (`u108-fusion-auswertung`: „★ Fusion und v3“,
v2-Stand, „★ TradeLabor“; drei Wochen live, rund 126 gestellte 4-h-Blöcke je Coin). 24 h erst ab rund 60 live gestellten
Blöcken je Coin (Anfang Dezember).

**Kriterien (alle auf live gestellten Blöcken; Debug „★ Fusion und v3“, Abschnitt „Alle Coins (Auswertung U108)“, Zeile
„nur live gestellt“, und je Coin die Zeile „nur live gestellt“):**
1. **Fusion 4 h gegen die Basisrate:** Abstand je Block über alle Coins (Standardfehler mit Zeitblöcken als Klumpen) unter
   −2 Standardfehlern (✓); je Coin keine belegte Verschlechterung (Abstand über +2 SE).
2. **Fusion gegen jeden einzelnen Experten:** über alle Coins nicht belegt schlechter (kein ✗).
3. **v3:** OOF-Brier-Skill > 0 in den wöchentlichen Läufen, Vorzeichen der gemeinsamen Gewichte über drei Wochen stabil,
   Selbsttest (Tor) grün.
4. **Labor:** „Fusion mit Kostenschwelle“ gegen „Prognose Fusion“: weniger Trades, besseres Ø netto je Trade; zählt nur mit
   „Glück“ unter 5 % (sonst Zwischenstand).
5. **Kostenschwelle:** E|r_h| der letzten 30 Tage gegen die danach eingetretene Bewegung (Bias und Streuung je Coin) — Vorarbeit
   für U109.

**Entscheidung:** Kriterien 1 und 2 erfüllt → Vorschlag zum Umschalten (Stufe 3). Sonst bleibt die Fusion im Schatten, der
Grund steht im Plan, und die Arbeit geht bei der Information weiter (Stufe 2) statt bei der Mischung.

---

## 7. Betrieb

- **Wo es läuft:** `hl_fusion.ergaenzen` in jeder Prognoseberechnung des Dashboards (vor dem Speichern; ein Fehler hält die
  Prognose nie an, er steht in `fusion.fehler` bzw. `kosten.fehler`), `hl_fusion.v3_takt` stündlich im Familien-Takt.
- **Kosten (Sandbox):** `ergaenzen` rund 0,05 s je Coin; Kostenschwelle mit 30 Tagen Minutenkerzen 0,06 s je Coin (Tabelle
  mit 12 Coins und 40 Tagen, Zwischenspeicher 1 h); v3-Fit über 90 Tage und 6 Coins 0,9 s; `v3_takt` in der Demo 0,4 s.
- **Speicher:** `fusion_fall` rund 7 Zeilen je Coin und Tag (4 h und 24 h), Payload je Prognose rund 0,6 kB mehr.
- **Schreiben** mit `BEGIN IMMEDIATE` (Lehre aus 23.41).
- **Werkzeuge:** Debug „★ Fusion und v3“ (`python3 hl_fusion.py --stand --db PFAD`) und „Fusion, v3 und Kostenschwelle:
  Selbsttest“ (`python3 hl_fusion.py --nulltest`, rund 30 s; Installationsschritt, seit 23.42 28 Schritte).

---

## 8. Literatur (Kurzform)

Brier 1950 (Bewertungsregel) · Good 1952, Gneiting/Raftery 2007 (strikt richtige Bewertungsregeln) · Dawid 1984
(Prequential-Prinzip) · James/Stein 1961, Efron/Morris 1975 (Schrumpfen) · Vovk 1990 (aggregierender Algorithmus) ·
Littlestone/Warmuth 1994 (gewichtete Mehrheit) · Freund/Schapire/Singer/Warmuth 1997 (schlafende Experten) · Herbster/Warmuth
1998 (Fixed Share) · Cesa-Bianchi/Lugosi 2006 (Lehrbuch) · Corsi 2009 (HAR-RV) · Vovk/Gammerman/Shafer 2005, Gibbs/Candès 2021
(konforme Vorhersage) · Hawkes 1971 · Bacry/Mastromatteo/Muzy 2015 (Hawkes in Finanzmärkten) · Shefrin/Statman 1985
(Dispositionseffekt) · Tversky/Kahneman 1974 (Ankern) · Lakonishok/Shleifer/Vishny 1992 (Herdenmaß) · Jacobs/Jordan/Nowlan/
Hinton 1991 (Mischung mit Tor).
