# KONZEPT Fusion — ein fusionierter Treiber für die Kursprognose

**Stand 04.10.2026 · Version 2026-09-23.43 · Claude Opus 5.5**
**Stufe 1 gebaut und im Schatten (U104–U107), Auswertung U108; Stufe 2b: Kaskaden-Gleichung gebaut (U113, U114), Auswertung U115;
Stufen 2–3 und der Rest von 2b geplant (U109–U112, U116, U117, `UPDATE_PLAN.md`)**

> Anlass (Nutzer, nach 23.41): „Hast du Ideen oder Überlegungen, ob es mathematische oder psychologische Ansätze gibt, aus
> den gesammelten Daten, der Dynamik der Kurse, der Historie etc. die Kursprognose mit einem fusionierten Treiber in eine
> Formel zu packen, die einen noch besseren prädiktiven Wert erzielt?“ — danach: „Leg los. Mach es perfekt und fehlerfrei.“

---

## 0. Kurz

Eine einzelne Zauberformel, die alles schlägt, gibt es nicht. Es gibt aber einen mathematisch sauberen Weg, alle Quellen zu
EINER Wahrscheinlichkeit zu verschmelzen, und jeder Schritt darauf ist prüfbar:

1. **Jede Quelle liefert eine Wahrscheinlichkeit** (v1, v2, v3, Analog-Suche, Basisrate) — nicht einen Punktwert. Wie viel
   sie taugt, entscheidet die Mischung an ihren Ergebnissen, nicht ihr Ruf.
2. **Stärke über Coins leihen:** Was in allen Coins gleich wirkt, wird gemeinsam geschätzt; eine Abweichung je Coin nur gegen
   Beleg (v3).
3. **Online mischen, mit Garantie:** Die Mischung lernt nach jedem aufgelösten Block, welchem Experten sie wie weit traut.
   Sie ist beweisbar höchstens um eine feste Konstante schlechter als der beste einzelne Experte (Abschnitt 3.3).
4. **Erst handeln, wenn der Vorsprung die Kosten trägt:** p* = ½ + K / (2·E|r|) (Abschnitt 3.1).
5. **Psychologie als Messung, nicht als Erzählung:** Einstandsanker, Stop-Jagd, Herden, Selbstanregung von Kaskaden werden zu
   Treibern mit Nulltest und Positivkontrolle (Stufe 2) und laufen dann durch dieselbe Maschine.

Die fusionierte Formel (Stufe 1, gebaut):

```
p_Fusion(t) = Σ_m π_m(t) · p_m(t) / Σ_m π_m(t)        Summe über die Experten m, die zur Zeit t eine Zahl haben
p_v3        = sig( a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f )
handeln, wenn |2 · p_Fusion − 1| · E|r_h| ≥ 1,5 · K    (Labor-Strategie „Fusion mit Kostenschwelle“)
```

**Was 23.42 gebaut hat (alles im Schatten, die angezeigte P(aufwärts) bleibt v1 bzw. v2):** Kostenschwelle je Coin und Horizont
(Anzeige und Payload), Kalibrierung v3 (v2 über alle Coins geteilt), Fusionsprognose als Expertenmischung, zwei neue
Labor-Strategien mit eigener Kennung. Modul `hl_fusion.py`, Selbsttest `python3 hl_fusion.py --nulltest` (Installationsschritt).

**Was 23.43 dazu gebaut hat (Stufe 2b, Abschnitt 4b):** die Kaskaden-Gleichung -- wie weit erzwungener Fluss aus Liquidationen eine
Bewegung trägt, als geschlossene Formel mit je Coin geschätztem Y, Placebo und Seitenspiegel; dazu ein Schatten-Treiber, die
Familie „Kaskaden“ und die Labor-Strategie „Kaskaden-Kipppunkt“. Modul `hl_kaskade.py`, Selbsttest `python3 hl_kaskade.py --nulltest`.

---

## 1. Leitlinien

1. **Bewertet wird mit dem Log-Verlust** −ln q (q = vorhergesagte Wahrscheinlichkeit des Eingetretenen), dazu Brier. Beide sind
   strikt richtige Bewertungsregeln: Den kleinsten erwarteten Verlust erreicht nur, wer seine wahre Überzeugung nennt. Die
   Trefferquote allein belohnt Überzeugung ohne Kalibrierung (55 % und 95 % zählen gleich).
2. **Prequential** (Dawid 1984): Jede Zahl steht fest, bevor ihr Ergebnis bekannt ist, und wird erst danach bewertet. Das gilt
   auch für den Nachtrag aus gespeicherten Prognosen.
3. **n_eff = getrennte Horizont-Blöcke** (eiserne Regel 4), nie Fensterzahl. Standardfehler über Coins zählen Zeitblöcke als
   Klumpen: Fälle verschiedener Coins im selben Block hängen zusammen.
4. **Jede Komponente hat einen Nulltest und eine Positivkontrolle**, und die Proben werden mit Mutationen geprüft: Eine
   absichtlich falsche Regel muss im Selbsttest rot werden.
5. **Schatten zuerst.** Umgeschaltet wird nur mit Beleg (U108), wie bei v2.
6. **Die Daten sind knapp.** Mit 14 Tagen Halbwertszeit über 90 Tage hat ein Coin rund **237 effektive 4-h-Blöcke**
   (Kish-n_eff der Gewichte), die Trefferquote also einen Standardfehler von **3,3 Punkten**. Auf 24 h sind es rund 40 Blöcke
   (8 Punkte). Deshalb: wenige Parameter, Schrumpfen überall, keine tiefen Netze, keine Interaktionsmodelle ohne Vorbelegung.

---

## 2. Werkzeugkasten

| Werkzeug | Was es leistet | Stufe |
|---|---|---|
| Strikt richtige Bewertungsregeln (Log-Verlust, Brier) | ehrliche Wahrscheinlichkeiten, Vergleich aller Modelle auf einer Skala | alle |
| Entscheidungsregel mit Kosten | nötige Trefferquote p* aus Kosten und mittlerer Bewegung | 1 |
| Hierarchisches Teilen (James-Stein, empirischer Bayes; L2-Strafe gegen den gemeinsamen Wert) | Stärke über Coins leihen, Abweichung je Coin nur gegen Beleg | 1 (v3) |
| Expertenmischung: aggregierender Algorithmus (Vovk 1990), Bayes-Mischung, schlafende Experten (Freund, Schapire, Singer, Warmuth 1997), Fixed Share (Herbster, Warmuth 1998) | Garantie gegenüber dem besten Experten, Anpassung an Regimewechsel | 1 |
| HAR-RV (Corsi 2009) | Volatilitätsprognose aus Tages-, Wochen- und Monatsschwankung | 2 |
| Konforme Vorhersage (Vovk, Gammerman, Shafer 2005; adaptiv: Gibbs, Candès 2021) | Bänder mit garantierter Abdeckung, auch bei Drift | 2 |
| Reflexionsprinzip der Brownschen Bewegung | Berührwahrscheinlichkeit eines Niveaus — Nullmodell für „Magnete“ | 2 |
| Hawkes-Prozess (Hawkes 1971) | Selbstanregung von Liquidationen, Nähe zur Kaskade | 2 |
| Dispositionseffekt (Shefrin, Statman 1985), Ankern (Tversky, Kahneman 1974) | Einstandsanker, Schmerzindex | 2 |
| Herdenmaß LSV (Lakonishok, Shleifer, Vishny 1992) | Herdenverhalten der verfolgten Konten | 2 |
| Mischung mit Tor / Spezialisten (Jacobs, Jordan, Nowlan, Hinton 1991) | Gewichte je Marktregime | 3 |

---

## 3. Stufe 1 — gebaut in 23.42 (Schatten)

### 3.1 Kostenschwelle (U104)

**Herleitung.** Ein Richtungsurteil mit Trefferquote p über den Horizont h bringt im Mittel
p · E|r_h| − (1 − p) · E|r_h| = (2p − 1) · E|r_h|, wenn die Größe der Bewegung nicht davon abhängt, ob das Urteil stimmt.
Es lohnt sich erst, wenn das die Kosten K eines Hin- und Rückwegs deckt:

```
p* = 1/2 + K / (2 · E|r_h|)
```

- **E|r_h|** wird gemessen, nicht aus einer Normalverteilung angenommen: Mittel von |ln(P(t+h)/P(t))| über die letzten 30 Tage,
  t im 15-min-Raster (überlappende Fenster; der Mittelwert bleibt unverzerrt), Kurs der Minutenkerze zur Zeit t oder bis
  2 min davor, mindestens 288 Punkte (3 Tage). Horizonte 1, 4, 12, 24 h.
- **K Taker** = 2 · (Taker-Gebühr + halber Spread), der halbe Spread als Median der Buch-Snapshots der letzten Stunde.
  **K Maker** = 2 · Maker-Gebühr. Sätze wie im TradeLabor (0,045 % / 0,015 % je Seite; XMR als HIP-3-Markt doppelt, angenommen).
- Je Coin stündlich neu (Zwischenspeicher 1 h). Die Schwelle kann über 100 % liegen: Dann ist der Horizont mit diesen Kosten
  nicht zu schlagen (Anzeige „unerreichbar“).

**Größenordnung** (45 % Jahresschwankung = 0,062 % je Minute, BTC-typisch; halber Spread 1 bp):

| Horizont | E\|r\| | Taker | Maker | XMR Taker |
|---|---|---|---|---|
| 1 h | 0,38 % | 64,3 % | 53,9 % | 73,5 % |
| 4 h | 0,77 % | 57,2 % | 52,0 % | 61,7 % |
| 12 h | 1,33 % | 54,1 % | 51,1 % | 56,8 % |
| 24 h | 1,88 % | 52,9 % | 50,8 % | 54,8 % |

**Folgerung:** Auf 4 h braucht ein Taker-Handel rund 57 % Trefferquote. Eine echte Kante von 55 % lohnt dort nur als Maker
(Limit-Order, deren Füllung nicht sicher ist) oder auf längeren Horizonten. Die echten Zahlen je Coin zeigt das Dashboard.

**Anzeige:** Kachel „P(aufwärts) Fusion — Schatten“ in der AI-Prognose (Taker/Maker für 4 h und 24 h, „darüber/darunter“ für die
Fusion in ihrer Richtung, E|r| 4 h); Debug „★ Fusion und v3“ mit allen vier Horizonten. **Gespeichert** im Payload als `kosten`
(flache Schlüssel `er_h`, `p_taker_h`, `p_maker_h`, `k_taker`, `k_maker`, …), damit das Labor sie lesen kann.

**Grenze:** Das 30-Tage-Mittel hinkt einem Regimewechsel der Schwankung nach — Stufe 2 (U109, HAR).

### 3.2 Kalibrierung v3 — v2 über alle Coins geteilt (U105)

```
p = sig( a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f )
```

| Zeichen | Bedeutung |
|---|---|
| x_f | Familienwert: Mittel der vorhandenen Treiber-Scores der Richtungsfamilie f (Score-Skala −1 … +1) |
| s_c,f | Streuung des Familienwerts je Coin im Trainingsfenster (mindestens 0,05; unter 10 Werten 1,0) — β wirkt je Standardabweichung |
| β_f | gemeinsames Gewicht aller Coins, L2-Strafe λ_β · Σβ² / F |
| δ_f,c | Abweichung eines Coins vom gemeinsamen Gewicht, L2-Strafe λ_δ = r · λ_β (r = ∞: ganz geteilt) |
| a_c | Achsenabschnitt je Coin (eigene Drift) |
| c | Kalibrierfaktor aus den OOF-Vorhersagen (0 = Basisrate je Coin) |

**Die sieben Richtungsfamilien** (aus `hl_familien.py`): Großkonten-Fluss (9 Treiber), Trend lang (3), Momentum kurz (3),
Orderfluss (4), Funding (2), ETF (2), Analog (1). Nicht dabei: „Stärke“ (sagt die Größe einer Bewegung vorher, nicht die
Richtung), die Schatten-Familie „Pool-Konten“ (ihre Treiber sind auch aus v1 und v2 ausgenommen, die Historie ist kurz) und der
Live-Profi-Flow (keine gespeicherten Treiber). Sieben Familien statt rund 30 Treiber: weniger Parameter für wenige Daten.

**Daten wie v2:** 90 Tage aus `forecast_slim`/`forecast_drivers`, je Coin und h-Block die früheste Prognose, Toleranz-Labels
(Bewegung unter 0,2 % ohne Urteil, M7), Alters-Gewicht mit 14 Tagen Halbwertszeit, Spot-Taker-Flow erst ab der Seiten-Umstellung
(U41). Ein Coin braucht mindestens 15 Fälle, das Modell mindestens 60.

**Wahl von λ_β und r:** geblockte Kreuzvalidierung über die Zeit (5 Folds; alle Coins eines Zeitraums im selben Fold, Embargo h).
Verglichen wird der Treiberanteil out-of-fold, mit den Achsenabschnitten je Coin aus denselben OOF-Fällen — mit den
Achsenabschnitten der Trainingsfolds lag der OOF-Verlust in der Probe bei jeder Einstellung über ln 2 (die Drift eines Zeitraums
passt nicht auf den nächsten), und dieses Rauschen überdeckte die Kante. Dann die 1-SE-Regel mit **gepaartem** Standardfehler
(Zeitblöcke als Klumpen) mit Vorrang für das Teilen (größtes r), dann das größte λ_β. Mit der Streuung der Fold-Mittel als
Standardfehler wählte die Regel fast immer das stärkste λ.

**Kalibrierschritt:** p = sig(a_c + c · η) auf den OOF-Vorhersagen, c ∈ {0; 0,1; …; 1}: das KLEINSTE c innerhalb eines
(blockweisen) Standardfehlers des besten. Ohne Beleg c = 0 — dann nennt v3 je Coin die Basisrate.

**Betrieb:** stündlich im Familien-Takt des Dashboards (erstmals 5 min nach dem Start), beide Horizonte, gespeichert als
learned „*“/`kalib3_4` und `kalib3_24` (Fehler sichtbar in `kalib3_h_fehler`). Jede Prognose trägt `p_up_v3` (gespeichert) und
`p_up_24_v3`, die Kachel „Fusion und Kalibrierung v3“ zeigt n, n_eff, Coins, λ, Teilen, c und die OOF-Kennzahlen.

**Probe (Selbsttest, 5 Szenarien je Prüfung, synthetischer Markt mit 6 korrelierten Coins):**

| Prüfung | Soll | Ergebnis 23.42 |
|---|---|---|
| Tor: Kante 0,65 in allen Coins | Log-Odds-Beitrag bei Familienwert +0,6 zwischen 0,20 und 1,00 (wahr +0,62) | Mittel +0,48 (0,39 … 0,61) |
| Rauschen | p bewegt sich < 5 Punkte, Brier-Skill ≤ 0,02 | 0,0 Punkte, +0,000 |
| Rauschen: vorsichtige Wahl | stärkstes λ und ganz geteilt in ≥ 4 von 5, c = 0 in ≥ 3 von 5 | 5 von 5, c = 0 in 4 von 5 |
| Gleichlauf aller Treiber ohne Signal | ≤ 7 Punkte | höchstens 3,6 Punkte |
| Teilen: gemeinsame Kante 0,62, 30 Tage | v3 im Mittel > 0,15 und ≥ 2 × v2 je Coin allein | v3 +0,26 gegen v2 +0,08 (wahr +0,49) |
| Kante nur in einem Coin (0,80) | Abweichung je Coin gewählt (≥ 4 von 5), dort ≥ 2 × der übrigen | 5 von 5, +0,37 gegen +0,08 |
| Training = Vorhersage | dieselbe Zahl über `p_up_v3` aus `forecast_drivers` | größte Abweichung 5,4·10⁻⁶ (Rundung) |
| U41 | Spot-Taker-Flow vor der Seiten-Umstellung nicht in „Orderfluss“ | 0 von 28 davor, 24 von 24 danach |

Eine Erkundung mit 20 Szenarien bei einer gemeinsamen Kante von 0,60 ergab v3 im Mittel rund dreimal so stark wie v2 je Coin.

### 3.3 Fusionsprognose — Expertenmischung (U106)

**Experten:** Basisrate (geglättete Aufwärtsquote der aufgelösten Blöcke, 14 Tage Halbwertszeit, je ein Pseudo-Fall auf und
ab), v1, v2 (nur Modelle ab Version 2, die übersicherten vor 23.26 nicht), v3, Analog-Suche (Anteil steigender Analoge, mit
50 Pseudo-Fällen zur eigenen Basisrate geschrumpft: Aus rund 50 Analogen schwankt die Quote ohne jeden Inhalt um ±7 Punkte).
Alle Wahrscheinlichkeiten werden auf [0,02; 0,98] geklemmt — ein Block kostet dann höchstens ln 50 = 3,9 Nats.

**Vorhersage und Lernen** (je Coin und Horizont, nach jedem aufgelösten Block):

```
p_Fusion = Σ_wach π_m · p_m / Σ_wach π_m
π_m ← π_m · q_m(y) / q_Fusion(y)          nur für wache Experten (q = vorhergesagte Wahrscheinlichkeit des Eingetretenen)
π   ← (1 − α) · π + α / M                  Fixed Share, α = min(0,05; h / (14 · 24))
```

Schlafende Experten (ohne Zahl in diesem Block, z. B. v3 vor dem ersten Modell) behalten ihr Gewicht; die Summe der wachen
Gewichte bleibt beim Lernschritt gleich. **Garantie** für jede Folge von Ergebnissen, auch gegnerisch gewählte, und für jeden
Experten m über seine wachen Runden:

```
L_Fusion − L_m ≤ ln M + (T − 1) · ln(1 / (1 − α))          M = 5:  ln 5 = 1,61 Nats
```

α entspricht einer erwarteten Regimedauer von 14 Tagen (4 h: α = 0,0119; 24 h: gedeckelt bei 0,05, also 20 Tage). Fixed Share kostet in einer
stillstehenden Welt etwas (die Mischung legt sich nie ganz fest) und holt nach einem Regimewechsel schneller auf (Probe: 234
gegen 290 Nats über 400 Blöcke nach dem Wechsel).

**Speicherung:** Tabelle `fusion_fall` im Prognosespeicher, eine Zeile je Coin, Horizont und Block (die früheste Prognose des
Blocks zählt, eine zweite ändert nichts): Experten-Zahlen, Fusionszahl, Gewichte, Quelle (`live`/`nachtrag`), Rendite, Richtung
y (1/0; −1 = unter der Toleranz, ohne Urteil; −2 = einen Tag nach Ablauf noch ohne Kurs). Im Payload jeder Prognose stehen nur
`fusion` (p und Anteile je Horizont) und `kosten`; die Bilanz und die Experten (`fusion_info`) sowie die v3-Zusammenfassung
(`kalib3`) sind reine Anzeige — sonst wüchse jede Prognosezeile um rund 4 kB.

**Nachtrag beim ersten Lauf:** Ist `fusion_fall` für einen Coin und Horizont leer, werden die gespeicherten Prognosen (60 Tage
Vorhalt) als Blöcke nachgetragen — ebenfalls prequential: Jeder nachgetragene Block sieht nur Ergebnisse, die zu seinem Zeitpunkt
schon feststanden; v3 gab es damals nicht (schläft). Für die Auswertung U108 zählen die live gestellten Blöcke getrennt.

**Bilanz** (Kachel und Debug): Log-Verlust je Block der Fusion gegen die Basisrate und jeden Experten auf denselben Blöcken,
**Abstand Fusion − Basisrate je Block ± 1 Standardfehler** (gepaart; belegt erst jenseits von 2 Standardfehlern), bester Experte,
Quote (Enthaltung unter 2 Punkten), Brier-Skill, Grenze der Nachrechnung. Der Debug-Bericht zeigt dazu je Coin die live gestellten
Blöcke getrennt und am Ende **alle Coins zusammen** (Abschnitt „Alle Coins (Auswertung U108)“): Fusion minus jeden Experten auf
dessen Blöcken, Standardfehler mit Zeitblöcken als Klumpen (Blöcke verschiedener Coins zur selben Zeit hängen über den gemeinsamen
Markt zusammen; als unabhängig gezählt wäre der Standardfehler zu klein), ✓ = belegt besser, ✗ = belegt schlechter.

**Probe:**

| Prüfung | Ergebnis 23.42 |
|---|---|
| Grenze auf 90 Folgen × 5 Experten (zufällig, gegnerisch, mit Schläfern; α = 0 / 0,012 / 0,05) | 0 Verletzungen |
| Rauschen (Experten ohne Wissen, Ergebnis mit 55 % Drift) | Fusion − Basisrate +2,61 Nats über 600 Blöcke (Grenze 8,78), nicht sicherer als die Basisrate (6,0 gegen 10,4 Punkte von 50 %) |
| Ein Experte kennt die wahre Wahrscheinlichkeit | Gewicht 85 % |
| Regimewechsel | Fixed Share 234 gegen reine Bayes-Mischung 290 Nats |
| Schläfer stören die Wachen nicht | Anteile identisch (auf 10⁻⁹) |
| Nur Ergebnisse, die feststanden; Blöcke ohne Urteil zählen nicht; Basisrate nur aus Feststehendem | ok |
| Abstand zur Basisrate mit Standardfehler | unabhängig nachgerechnet, gleich |
| Alle Coins: Standardfehler mit Zeitblöcken als Klumpen (3 Coins mit gleicher Richtung je Block) | unabhängig nachgerechnet, gleich; 1,75-mal so groß wie der naive |
| Ende zu Ende über `ergaenzen()`: Nachtrag, Auflösen, Mischung, Zeile je Block, Bilanz, Debug-Bericht | 60 Blöcke nachgetragen; v2 (immer richtige Richtung, 62 %) hat 96 % Anteil; zweite Prognose im Block ändert nichts; Toleranz ohne Urteil; Fusionszahl und Basisrate je Block unabhängig nachgerechnet (Abweichung 4,9·10⁻⁶) |

### 3.4 Zwei neue Labor-Strategien (U107)

| Strategie | Kennung | Regel |
|---|---|---|
| Prognose Fusion | `prognose_fusion@40662765` | P(aufwärts 4 h) der Fusion ≥ 58 % → Long, ≤ 42 % → Short (dieselbe Schwelle wie „Prognose v1“); Stop 1,5 σ, Ziel 2 σ, 4 h |
| Fusion mit Kostenschwelle | `prognose_fusion_kosten@aefe5404` | in Richtung der Fusion, nur wenn \|2p − 1\| · E\|r 4 h\| ≥ 1,5 × K; K = Taker-Gebühr beider Seiten (XMR doppelt) plus Abstand zur Buchmitte einer Markt-Order von 10.000 USD beim Ein- und Ausstieg, aus dem aktuellen Buch; Stop 1,5 σ, Ziel 2 σ, 4 h |

Beide lesen `fusion.p_4` und `kosten.er_4` aus dem Payload der jüngsten Prognose (höchstens 30 min alt). Der Vergleich beider an
DERSELBEN Prognose zeigt, was der Kostenfilter bringt. Der Faktor 1,5 ist ein Puffer gegen den Schätzfehler von p. Die übrigen
35 Kennungen sind unverändert.

### 3.5 Was Stufe 1 bewusst nicht tut

- **Keine Wirkung** auf die angezeigte P(aufwärts), den Pfad, Bias, Kauf- und Verkaufspreise.
- **Kein Familien-Experte:** Die Familien-Prognose (`hl_familien`) wird nicht je Prognose gespeichert (kein Nachtrag möglich), und
  bis eine Familie aufgestiegen ist, ist sie eine Basisrate ohne Halbwertszeit — ein Doppel der Basisrate, das nur ln M kostet.
  Kommt in Stufe 3, sobald eine Familie aufsteigt.
- **Keine Pool-Konten in v3** (siehe 3.2) und **keine Wechselwirkungen** zwischen Familien (zu wenige Daten; Konstellationen
  bleiben Stufe 2 der Konstellations-Statistik).
- **Kein Umschalten** — erst nach U108.

### 3.6 Ehrliche Erwartungen

- **Datenmenge:** Rund 237 effektive 4-h-Blöcke je Coin → Standardfehler der Trefferquote 3,3 Punkte. Eine Kante von 55 % liegt
  je Coin bei 1,5 Standardfehlern — nicht belegbar. In der Probe fand selbst ein Modell, das nur die eine richtige Familie kennt,
  eine 55-%-Kante über 90 Tage kaum. Auf 24 h (rund 40 effektive Blöcke) ist jede Aussage noch Wochen lang Rauschen.
- **Wert einer Kante im Log-Verlust je Block:** 55 % → 0,005 Nats, 58 % → 0,013, 60 % → 0,020. In der Rauschprobe kostete die
  Mischung 0,004 Nats je Block gegenüber der Basisrate. Ohne echte Kante ist die Fusion also erwartbar ein wenig schlechter als die
  Basisrate — die Bilanz sagt dann „nicht belegt“, und genau das ist die richtige Antwort.
- **Schlimmster Fall der Mischung** gegen den besten einzelnen Experten über 120 Tage: 4 h höchstens 10,2 Nats (0,014 je Block),
  24 h höchstens 7,7 Nats (0,064 je Block). Real liegt der Abstand meist weit darunter, die Grenze ist eine Garantie, keine
  Erwartung.
- **Kosten:** Auf 4 h braucht ein Taker-Handel rund 57 % Trefferquote. „Fusion mit Kostenschwelle“ wird deshalb selten handeln;
  das ist gewollt.
- **Teilen hilft, wenn die Kante gemeinsam ist** (Probe: v3 zwei- bis dreimal so stark wie v2), nicht bei einer Kante, die nur ein
  Coin hat — dort braucht die Abweichung je Coin starke Belege.
- **Ein realistischer Erfolg** wäre: Fusion 4 h über alle Coins belegt besser als die Basisrate (Abstand jenseits von 2 SE) und
  nicht schlechter als der beste einzelne Experte. Wahrscheinlich ist ein kleiner, langsam belegbarer Vorsprung — oder keiner.

---

## 4. Stufe 2 — neue Information (U109–U111)

Jede neue Größe kommt als Treiber oder Familie mit **Nulltest** (gemischte Zeitachse bzw. Zufallsniveaus: kein Vorsprung) und
**Positivkontrolle** (synthetischer Markt mit eingebauter Wirkung: wird gefunden) in `check_treiber.py`, läuft zuerst im
Parallelbetrieb der Familien und geht danach als Familie in v3 oder als eigener Experte in die Mischung.

### U109 — Schwankung: HAR-RV, konforme Bänder, Grid-Variante

- **HAR-RV** (Corsi 2009): RV_morgen = b0 + b_d · RV_Tag + b_w · RV_Woche + b_m · RV_Monat, geschätzt je Coin auf 5-min-Renditen.
  Ersetzt das 30-Tage-Mittel in E|r_h| (Kostenschwelle) und die Breite des Pfadbands. Abnahme: kleinerer Prognosefehler von |r_h|
  als das 30-Tage-Mittel außerhalb der Stichprobe (QLIKE, Diebold-Mariano auf Blöcken).
- **Konforme Bänder:** Bandbreite aus den eigenen Fehlern der letzten Wochen so gewählt, dass die Abdeckung garantiert ist
  (adaptiv nach Gibbs/Candès, damit die Garantie bei Drift hält). Abnahme: 80-%-Band trifft 80 % ± 2 SE über 4 Wochen.
- **Grid-Variante** mit Stufen aus dem HAR-σ statt fester 0,2 %: nur als neue Labor-Kennung (Regeln eingefroren).

### U110 — Anker mit Berührwahrscheinlichkeit

Für eine Bewegung ohne Drift mit Schwankung σ ist die Wahrscheinlichkeit, ein Niveau im Log-Abstand d binnen h zu berühren,
P = 2 · (1 − Φ(|d| / (σ · √h))) (Reflexionsprinzip). Das ist das **Nullmodell für „Magnete“**: Ein Cluster zieht nur dann an, wenn
es öfter berührt wird, als P vorhersagt. Schritte: (1) Kalibrierung des Nullmodells auf allen Clustern (Berührquote je Klasse von
P innerhalb 2 SE), (2) Überschuss je Clustergröße (relativ zum Volumen), (3) Treiber „Zug“ = Σ Notional · P_Berühr oben minus
unten, nur bei belegtem Überschuss. Ergänzt den Heatmap-Anker (23.28) um eine saubere Basis.

### U111 — Psychologie als Messung

- **Einstandsanker und Schmerzindex** (Dispositionseffekt, Ankern): Aus `whale_positions`/`pool_positions` (Einstandspreis,
  Größe, uPnL) je Coin: Notional der Longs, deren Einstand knapp ÜBER dem Kurs liegt (bis 1 σ), minus Notional der Shorts mit
  Einstand knapp DARUNTER — „Angebot zum Einstand“ (wer im Minus liegt, verkauft gern bei plus/minus null). Dazu der
  Schmerzindex: Anteil des Notionals unter Wasser, gewichtet mit dem Abstand zur Liquidation. Normiert auf das Stundenvolumen.
- **Stop-Topologie und Jagd-Rentabilität:** Für Ziele oberhalb und unterhalb (Liquidationen aus der Heatmap, Stops aus
  `trigger_orders`): erzwungener Fluss am Ziel geteilt durch die Buchtiefe bis dorthin (`book_summary`). Ist das Verhältnis groß,
  lohnt eine Jagd — Treiber = Log-Verhältnis oben minus unten.
- **Herdenmaß LSV:** je Coin und Stunde unter den handelnden verfolgten Konten (Adress-Strom) p = Anteil der Netto-Käufer,
  H = |p − p̄| − E|p − p̄| (Erwartung unter der Binomialverteilung), mit Vorzeichen: Kauf- gegen Verkaufsherde.
- **Hawkes-Intensität (Kaskadennähe):** λ(t) = μ + Σ a · e^{−b (t − t_i)} je Coin und Seite für Liquidationen und große
  Taker-Aufträge; Verzweigungsrate n = a/b nahe 1 heißt kaskadenanfällig. Zur Familie „Stärke“ (Größe) und mit Seitenvorzeichen
  als Richtungstreiber. Nulltest: Poisson-Ereignisse → n ≈ 0; Positivkontrolle: simulierter Hawkes-Prozess mit n = 0,7 → 0,6–0,8.

---

## 4b. Stufe 2b — eine Strukturgleichung für die Verteilung des Kurses (Nutzerfrage 04.10.)

> Nutzer (04.10., nach dem Einspielen von 23.42): „… ob es nicht möglich wäre, eine komplexe Funktionsgleichung abzuleiten, welche
> den Kurs im Voraus annähernd berechnet. Hättest du Ansätze dafür?“ — danach: „Leg los“.

**Antwort in einem Satz:** Eine Gleichung für den Kurs selbst hebt sich auf; eine Gleichung für seine **Verteilung** (Mitte,
Breite, Ränder, Sprünge) lässt sich bauen und prüfen.

**Drei harte Grenzen.**
1. **Die Vorhersage ändert den Kurs** (Samuelson 1965): Wüsste eine Formel, dass der Kurs morgen höher steht, kauften alle heute.
   Übrig bleiben Vorsprünge unter der Kostenschwelle, Risikoprämien (Funding), erzwungene Flüsse (Liquidationen — wer liquidiert
   wird, handelt nicht nach Information) und Verhalten, gegen das zu wetten riskant ist. Im Gleichgewicht ist der Vorsprung
   ungefähr so groß wie die Kosten, ihn zu finden (Grossman/Stiglitz 1980).
2. **Feinere Daten helfen bei der Richtung nicht** (Merton 1980): Der Beleg für einen Trend μ wächst mit μ · √T / σ, T ist die
   Zeitspanne, nicht die Zahl der Datenpunkte. Bei 45 % Jahresschwankung braucht ein Trend von 30 % im Jahr rund 9 Jahre für
   2 Standardfehler, 20 % rund 20 Jahre, 10 % rund 81 Jahre. Minutendaten machen die Schwankung genau, nicht die Richtung.
3. **Komplex heißt überangepasst:** viele Größen auf wenige unabhängige Beobachtungen (drei bis vier Halving-Zyklen, rund 237
   effektive 4-h-Blöcke je Coin). Lehrbeispiel: das Stock-to-Flow-Modell (2019) mit hohem R², 2022 um ein Mehrfaches daneben.

**Das Power-Law-Modell, ehrlich gerechnet.** P = A · Tage^5,8 seit dem Genesis-Block (Santostasi). Ableitung: Trend 5,8 / t =
0,33 je Jahr (rund 39 %, fallend). Wenn das Modell exakt stimmt (45 % Jahresschwankung, Funding 0,01 % je 8 h):

| Horizont | Trend laut Modell | Schwankung (1 σ) | P(aufwärts) nur aus dem Trend | Kosten Long-Perp |
|---|---|---|---|---|
| 4 h | +0,01 % | 0,96 % | 50,6 % | 0,12 % |
| 1 Tag | +0,09 % | 2,4 % | 51,5 % | 0,14 % |
| 1 Woche | +0,6 % | 6,2 % | 54,0 % | 0,32 % |
| 1 Monat | +2,8 % | 13 % | 58,3 % | 1,0 % |
| 3 Monate | +8,5 % | 23 % | 64,1 % | 2,9 % |
| 1 Jahr | +37 % | 45 % | 76,0 % | 11 % |

Auf 4 h trägt das Gesetz 0,6 Punkte bei; über Monate wiegt es spürbar. Außerhalb der Stichprobe: Santostasis eigene Zyklusprognose
(Spitze rund 210.000 USD im Januar 2026, danach rund 60.000 USD) traf den Boden (Tief um 57.000–58.000 USD im Juni/Juli 2026), die
Spitze lag mit 126.198 USD (Oktober 2025) um den Faktor 1,7 und drei Monate daneben — ein Wachstumsgesetz beschreibt den Korridor,
nicht den Weg. (Stand 04.10.2026: BTC 84.750 USD, Modellwert laut Newhedge 149.670 USD, Boden 62.860 USD.)

**Die Strukturgleichung** — jeder Term aus der Quelle, die auf seinem Horizont etwas weiß:

```
d ln P = [ 5,8/t − κ · (ln P − ln PL(t)) + β · x(t) ] dt  +  σ(t) · dW  +  J · dN(t)
```

- 5,8/t und κ-Term: Trend des Power Law und Rückkehr in den Korridor (Monate, Jahre) → U117.
- β · x(t): die Fusion (Flüsse, Funding, Positionen); Makro als Regime, nicht als Signal → U112.
- σ(t): HAR × Tageszeitprofil × Makro-Kalender (CPI, FOMC: Zeitpunkt bekannt, Richtung nicht); dW mit dicken Rändern
  (Student-t, große Bewegungen werden ungefähr wie x⁻³ seltener — das echte Potenzgesetz der Märkte) → U109, U116.
- **J · dN: die Kaskaden-Gleichung — gebaut in 23.43 (U113).** Sie nutzt die Daten, die nur dieses System so hat.
- Gerechnet wird am Ende mit simulierten Pfaden (Median, Bänder, Berührwahrscheinlichkeiten), bewertet mit einer strikt
  richtigen Regel für Verteilungen (CRPS, Log-Score); ihr P(aufwärts) wird ein Experte der Fusion → U116.

### 4b.1 Die Kaskaden-Gleichung (gebaut in 23.43, `hl_kaskade.py`, Schatten)

**Wurzelgesetz der Marktwirkung** (Tóth u. a. 2011; Bouchaud u. a. 2018): Ein Fluss Q (USD) verschiebt den Kurs um

```
I(Q) = Y · σ_Tag · √(Q / V_Tag)          (Log-Rendite; σ_Tag, V_Tag wie im Heatmap-Anker aus 7 Tagen Minutenkerzen)
```

**Kaskade als Fixpunkt:** Tiefe u = ln(P0 / Kurs) unter dem Kurs beim Heatmap-Stand, Q(u) = Notional der Long-Liquidationscluster
bis zur Tiefe u. Ein exogener Ausschlag u_exo endet bei der kleinsten Lösung u ≥ u_exo von u = u_exo + I(Q(u)); nach oben
spiegelbildlich mit den Short-Clustern.

**Geschlossene Form:** Um die Tiefe m zu erreichen, braucht der Markt den exogenen Ausschlag

```
H(m) = max( max_{k: d_k ≤ m} (d_k − I(Q_{k−1})),  m − I(Q(m)) )        (die Kaskade endet jenseits m  ⇔  u_exo ≥ H(m))
P(Rutsch ≥ m binnen h) = 2 · (1 − Φ(H(m) / (c · σ_h)))                   (Reflexionsprinzip)
```

Ohne Kaskaden (Y = 0) ist H(m) = m — der reine Zufallsweg. Daraus:
- **Kipppunkt** je Seite: der kleinste exogene Ausschlag (Raster 0,02 σ_4h bis 3 σ_4h), ab dem die Kaskade mindestens 0,5 σ_4h
  weiter trägt, und ihr **Ende**; dazu das Ende nach 1 σ und nach 3 σ Ausschlag.
- **Mehrweg** = erwarteter zusätzlicher Ausschlag binnen 4 h durch Kaskaden, ∫ (P_Kaskade(≥ m) − P_Zufall(≥ m)) dm in σ_4h.
- **Schatten-Treiber „Kaskaden-Asymmetrie“** = (Mehrweg oben − Mehrweg unten) / (Summe + 0,1) mit FESTEM Y = 1 (Literaturwert),
  damit die Reihe über die Zeit vergleichbar bleibt. Gewicht 0 in v1, bewusst nicht in PRIORS (also nicht im v1-Lernen), nicht in
  v2 und v3; Familie „Kaskaden“ im Parallelbetrieb der Treiberfamilien. Ob die Asymmetrie die RICHTUNG vorhersagt, ist offen: Eine
  sichere Rutschgefahr nach unten kann im Mittel durch mehr kleine Anstiege ausgeglichen sein (Martingal mit Schiefe).

**Kalibrierung je Coin und Horizont (1 h, 4 h), alle 6 h:** Je Block der erste Heatmap-Stand, je Seite die Ereignisse „Ausschlag
≥ k · σ_h“ (k = 0,5; 1; 1,5; 2; 3), Log-Verlust. Y ∈ {0; 0,25; 0,5; 1; 2; 4; 8}, c ∈ [0,6; 1,6]. Geblockte Kreuzvalidierung über
die Zeit (5 Folds, Embargo ein Block), 1-SE-Regel mit Vorrang für das KLEINERE Y (Standardfehler gepaart, Tage als Klumpen).
Mindestens 120 Blöcke je Horizont (1 h: 5 Tage, 4 h: 20 Tage). **Belegt** erst, wenn alle vier gelten:
1. Y > 0 gewählt,
2. Verlust mit Y = 0 minus gewählt > 2 Standardfehler,
3. **Placebo** (die Heatmap von drei Tagen vorher, echte Cluster zur falschen Zeit) wählt Y = 0,
4. **Seitenspiegel** (dieselben Cluster mit vertauschten Seiten) ist um mehr als 2 Standardfehler schlechter. Grund: Liegen Cluster
   nahe am Kurs, ist die Schwankung oft ohnehin höher (auf BEIDEN Seiten); das allein ist keine Kaskaden-Mechanik. Nur wenn die
   SEITE stimmt, ist es eine. In der Probe ließ das Zeit-Placebo allein einen solchen Störfaktor einmal durch, der Spiegel nie.

Y ist ein effektiver Wert: Die Heatmap sieht nur die verfolgten Konten (Abdeckung im Bericht), und σ_Tag enthält die Kaskaden
selbst (in der Probe wird ein wahres Y = 2 als 1 gefunden, c sinkt auf 0,7). Bis Y belegt ist, rechnen Kipppunkt und Treiber mit
Y = 1; die Wahrscheinlichkeiten in Kachel und Bericht nehmen das kalibrierte Modell (mit Y = 0 also den Zufallsweg).

**Proben (Selbsttest `hl_kaskade.py --nulltest`, rund 15 s; synthetische Märkte mit genau dieser Mechanik):**

| Prüfung | Ergebnis 23.43 |
|---|---|
| Geschlossene Form = Fixpunkt (120.000 Vergleiche auf 300 zufälligen Karten, Y 0–8) | 0 Abweichungen |
| Feld = Schritt; erfc ohne scipy; ohne Kaskaden der Zufallsweg; Kipppunkt und Kettenreaktion exakt nachgerechnet | ok (erfc 1,0 · 10⁻⁷) |
| Positivkontrolle 1 h (Y wahr 2, 30 Tage, 720 Blöcke) | Y 1 in 3 von 3, Abstand +0,36 … +0,42 je Block (≥ 10 SE), Brier-Skill ≥ 2 σ +0,05 … +0,09, Placebo und Spiegel 0, belegt 3 von 3 |
| Positivkontrolle 4 h (180 Blöcke) | belegt 3 von 4 |
| Nulltest (Cluster ohne Wirkung) | Y = 0 in 4 von 4, nie belegt |
| Störfaktor (nahe Cluster → höhere Schwankung, keine Kaskade) | nie belegt (Zeit-Placebo allein hätte 1 von 4 durchgelassen) |
| Live: Kipppunkt, Vorzeichen gespiegelt, veralteter Stand → kein Treiber, Payload unter 600 Zeichen, gespeicherte Kalibrierung wirkt | ok |
| Blöcke über gezielte Abfragen = ganze Heatmap gelesen und gefiltert (dazu 115.240 tiefe und falschseitige Eimer bis ±40 %) | 287 von 287 und 71 von 71 Blöcken gleich |

Trennschärfe (Erkundung, synthetisch, 21 Tage, 1 h): Y = 1 mit Clustern um 0,2–0,4 % des Tagesumsatzes in 4 von 4 belegt, Y = 0,5
in 3 von 4. Lastprobe in Recorder-Form: Live-Stand 0,02 s. Ungünstiger Fall für die Kalibrierung: 800 Eimer je Stand (0,25-%-Raster bis
rund ±63 %), alle 10 min, 90 Tage, 10,4 Mio Zeilen für einen Coin. Ergebnis: 1,5 s je Coin, der ganze Prozess höchstens 91 MB.
Der erste Entwurf las jeden Stand ganz: 30 Tage kosteten 5,5 s und 354 MB Prozessspeicher (jetzt 0,4 s und 53 MB), 90 Tage
wären rund 1 GB im Dashboard-Prozess geworden. Jetzt laufen je Block zwei Abfragen über Index und Schlüssel (erster Stand; Eimer nur bis
zur größten Clustertiefe). Das Ergebnis ist Block für Block identisch (Lastdatei, Demo mit 5 Coins, Probe-Markt).

### 4b.2 Labor-Strategie „Kaskaden-Kipppunkt“ (U114, `kaskade_kipppunkt@738d23ea`)

Fällt der Kurs durch den unteren Kipppunkt (im vorigen 15-s-Takt darüber, jetzt darunter), Short bis zum berechneten Ende; steigt er
durch den oberen, Long. Nur wenn der Weg zum Ende mindestens das 1,5-Fache der Kosten zum Marktpreis ist (Taker beider Seiten plus
Abstand zur Buchmitte bei 10.000 USD) und das Ende noch nicht erreicht ist; Stop 0,5 σ(1 h) hinter dem Kipppunkt, spätestens nach
2 h; je Kipppunkt einmal. Kipppunkt und Ende kommen aus dem Payload der jüngsten Prognose (höchstens 30 min alt). Vergleich:
„Kaskaden-Fortsetzung“ (dieselbe Idee ohne Gleichung, festes Ziel 1,5 σ). Die 37 übrigen Kennungen sind unverändert.

### 4b.3 Ehrliche Erwartungen

- Auf dem Pi liegen rund drei Wochen Heatmap-Stände: 1 h ist sofort kalibrierbar (rund 500 Blöcke je Coin), 4 h erst ab etwa
  20 Tagen nach Beginn der Aufzeichnung; das Placebo braucht weitere drei Tage.
- Die Heatmap sieht nur die verfolgten Konten; wer viel hebelt und klein ist, fehlt. Kipppunkte können deshalb zu weit weg liegen.
- Hyperliquid-Positionen sind öffentlich: Wenn Kaskaden-Mechanik wirkt, sehen das auch andere. Der Vorsprung liegt nur in der
  besseren Rechnung, nicht in exklusiven Daten.
- Wahrscheinlich ist: Y ist bei liquiden Coins (BTC, ETH) klein oder nicht belegt, bei dünnen (ZEC, XMR, HYPE) eher sichtbar.
  Ein „nicht belegt“ ist ein Ergebnis, kein Fehler.

### 4b.4 Plan

- **U115 Auswertung** (erster Blick 11.10. 19:45, Bericht `u113-kaskade-woche1`; Urteil ab 25.10., Bericht `u115-kaskade-auswertung` 19:45): Y je Coin und Horizont belegt
  (alle vier Bedingungen), Zuverlässigkeit der ≥ 2-σ-Vorhersagen, Richtung der Asymmetrie (Familie „Kaskaden“: Vorsprung gegen
  den Zufall), Labor „Kaskaden-Kipppunkt“ gegen „Kaskaden-Fortsetzung“ (nur mit Glück < 5 %).
- **U116 Strukturgleichung als Verteilung:** simulierte Pfade aus σ(t) (HAR, Tageszeit, Makro-Kalender), Student-t und den
  Sprüngen der Kaskaden-Gleichung (belegtes Y); Bewertung mit CRPS; P(aufwärts) daraus als Experte der Fusion. Braucht U109, U115.
- **U117 Langfrist-Kompass:** Lage im Power-Law-Korridor (in σ), Trend je Jahr, P(aufwärts) für 1/3/12 Monate mit der
  Unsicherheit des Exponenten — eigene Kachel, getrennt von der 4-h-Prognose. Braucht einmalig Tageskurse ab 2010 (ab 2017 ist
  der Exponent kaum bestimmt).

---

## 5. Stufe 3 — Struktur (U112) und Umschalten

- **Regime-Tor über Spezialisten:** Die schlafenden Experten der Mischung erlauben Experten, die nur in einem Regime wach sind
  (z. B. „v2 bei hoher Schwankung“, „v2 bei niedriger“, nach dem Vol-Regime aus `hl_indikatoren`; Trend/kein Trend;
  Funding-Extrem). Die Garantie gilt dann je Regime, ohne neue Parameter außer der Regime-Einteilung.
- **Familien-Experte**, sobald eine Familie aufsteigt: dann deren Prognose je Prognose speichern und als Experten aufnehmen.
- **v3 mit langem Gedächtnis** als zusätzlicher Experte (ohne Halbwertszeit, 90 Tage gleich gewichtet: n_eff 540 statt 237,
  Standardfehler 1,5-mal kleiner). Die Mischung entscheidet zwischen schneller Anpassung und statistischer Kraft — die
  Antwort auf die 55-%-Grenze.
- **Pool-Konten in v3**, sobald die Familie 60 Tage Historie hat und ihren Nulltest besteht.
- **Umschalten:** Die Fusion trägt die angezeigte P(aufwärts) nur, wenn U108 bestanden ist — Schalter im Prognosespeicher wie bei
  v2, jederzeit zurück. Pfad und Bias folgen dann der Fusion (wie bei U7b für v2 vorgesehen).

---

## 6. Auswertung und Abnahme (U108)

**Termine:** einmaliger Bericht 11.10. 19:30 (Berichtsplan `u106-fusion-woche1`: „★ Fusion und v3“, Selbsttest, „★ TradeLabor“),
wöchentlich mittwochs 19:00 (W11) und zur Auswertung U108 am **25.10. 19:30** (`u108-fusion-auswertung`: „★ Fusion und v3“,
v2-Stand, „★ TradeLabor“; drei Wochen live, rund 126 gestellte 4-h-Blöcke je Coin). 24 h erst ab rund 60 live gestellten
Blöcken je Coin (Anfang Dezember).

**Kriterien (alle auf live gestellten Blöcken; Debug „★ Fusion und v3“, Abschnitt „Alle Coins (Auswertung U108)“, Zeile
„nur live gestellt“, und je Coin die Zeile „nur live gestellt“):**
1. **Fusion 4 h gegen die Basisrate:** Abstand je Block über alle Coins (Standardfehler mit Zeitblöcken als Klumpen) unter
   −2 Standardfehlern (✓); je Coin keine belegte Verschlechterung (Abstand über +2 SE).
2. **Fusion gegen jeden einzelnen Experten:** über alle Coins nicht belegt schlechter (kein ✗).
3. **v3:** OOF-Brier-Skill > 0 in den wöchentlichen Läufen, Vorzeichen der gemeinsamen Gewichte über drei Wochen stabil,
   Selbsttest (Tor) grün.
4. **Labor:** „Fusion mit Kostenschwelle“ gegen „Prognose Fusion“: weniger Trades, besseres Ø netto je Trade; zählt nur mit
   „Glück“ unter 5 % (sonst Zwischenstand).
5. **Kostenschwelle:** E|r_h| der letzten 30 Tage gegen die danach eingetretene Bewegung (Bias und Streuung je Coin) — Vorarbeit
   für U109.

**Entscheidung:** Kriterien 1 und 2 erfüllt → Vorschlag zum Umschalten (Stufe 3). Sonst bleibt die Fusion im Schatten, der
Grund steht im Plan, und die Arbeit geht bei der Information weiter (Stufe 2) statt bei der Mischung.

---

## 7. Betrieb

- **Wo es läuft:** `hl_fusion.ergaenzen` in jeder Prognoseberechnung des Dashboards (vor dem Speichern; ein Fehler hält die
  Prognose nie an, er steht in `fusion.fehler` bzw. `kosten.fehler`), `hl_fusion.v3_takt` stündlich im Familien-Takt.
- **Kosten (Sandbox):** `ergaenzen` rund 0,05 s je Coin; Kostenschwelle mit 30 Tagen Minutenkerzen 0,06 s je Coin (Tabelle
  mit 12 Coins und 40 Tagen, Zwischenspeicher 1 h); v3-Fit über 90 Tage und 6 Coins 0,9 s; `v3_takt` in der Demo 0,4 s.
- **Speicher:** `fusion_fall` rund 7 Zeilen je Coin und Tag (4 h und 24 h), Payload je Prognose rund 0,6 kB mehr.
- **Schreiben** mit `BEGIN IMMEDIATE` (Lehre aus 23.41).
- **Werkzeuge:** Debug „★ Fusion und v3“ (`python3 hl_fusion.py --stand --db PFAD`) und „Fusion, v3 und Kostenschwelle:
  Selbsttest“ (`python3 hl_fusion.py --nulltest`, rund 30 s; Installationsschritt, seit 23.42 28 Schritte).
- **Kaskaden-Gleichung (23.43):** Treiber in jeder Prognoseberechnung (`compute_forecast`, Zwischenspeicher je Heatmap-Stand),
  Anzeige über `hl_kaskade.ergaenzen` (`kaskade` im Payload, rund 0,2 kB; `kaskade_info` nur Anzeige), Kalibrierung alle 6 h im
  Familien-Takt (erstmals 15 min nach dem Start; learned coin/„kaskade“). Debug „★ Kaskaden-Gleichung“ (`--stand`), „jetzt
  kalibrieren“ (`--kalibrieren`) und „Selbsttest“ (`--nulltest`); Installationsschritt, seit 23.43 29 Schritte.

---

## 8. Literatur (Kurzform)

Brier 1950 (Bewertungsregel) · Good 1952, Gneiting/Raftery 2007 (strikt richtige Bewertungsregeln) · Dawid 1984
(Prequential-Prinzip) · James/Stein 1961, Efron/Morris 1975 (Schrumpfen) · Vovk 1990 (aggregierender Algorithmus) ·
Littlestone/Warmuth 1994 (gewichtete Mehrheit) · Freund/Schapire/Singer/Warmuth 1997 (schlafende Experten) · Herbster/Warmuth
1998 (Fixed Share) · Cesa-Bianchi/Lugosi 2006 (Lehrbuch) · Corsi 2009 (HAR-RV) · Vovk/Gammerman/Shafer 2005, Gibbs/Candès 2021
(konforme Vorhersage) · Hawkes 1971 · Bacry/Mastromatteo/Muzy 2015 (Hawkes in Finanzmärkten) · Shefrin/Statman 1985
(Dispositionseffekt) · Tversky/Kahneman 1974 (Ankern) · Lakonishok/Shleifer/Vishny 1992 (Herdenmaß) · Jacobs/Jordan/Nowlan/
Hinton 1991 (Mischung mit Tor) · Samuelson 1965 (vorweggenommene Kurse schwanken zufällig) · Grossman/Stiglitz 1980 (Unmöglichkeit
informationseffizienter Märkte) · Merton 1980 (Schätzung erwarteter Renditen) · Tóth u. a. 2011, Bouchaud u. a. 2018 (Wurzelgesetz
der Marktwirkung) · Gopikrishnan u. a. 1999, Gabaix u. a. 2003 (Potenzgesetze in Renditen und Umsätzen) · Santostasi (Bitcoin Power
Law; Exponent 5,8).
