#!/usr/bin/env python3
"""
hl_watchdog.py — Überwacht die Aufzeichnung und schlägt Alarm.

Zwei Ebenen, weil eine allein nicht reicht:

  1. LOKAL — Alarmton über die Audioausgabe, dazu wahlweise die ACT-LED.
     Funktioniert ohne Internet, also genau dann, wenn der Ausfall die
     Verbindung betrifft.

     Achtung: Der Pi 5 hat KEINEN eingebauten Lautsprecher und auch keine
     Klinkenbuchse mehr. Ton braucht HDMI mit angeschlossenem Bildschirm,
     einen USB-Soundstick, Bluetooth oder ein I2S-DAC-HAT. Ohne eines davon
     bleibt es still — dann sind LED und Totmannschalter die Alternative.
  2. EXTERN — regelmäßiger Lebenszeichen-Ping an einen Dienst wie
     healthchecks.io. Bleibt er aus, alarmiert der Dienst DICH. Das ist die
     einzige Ebene, die auch dann greift, wenn der Pi tot ist oder brennt.

Zusätzlich Push-Nachrichten über ntfy.sh, solange die Verbindung steht.

    python hl_watchdog.py --once                      # einmalig prüfen
    python hl_watchdog.py --alarm-interval 120        # Ton alle 2 min bei Störung
    python hl_watchdog.py --ntfy mein-geheimes-topic \\
                          --heartbeat https://hc-ping.com/DEINE-UUID
    python hl_watchdog.py --test-alarm                # Signalgeber prüfen

Geprüft wird: Alter der Bars, der Snapshots und der Binance-Daten, Rückstand
des Pollers, Erreichbarkeit der Börsen, Plattenplatz, Uhrzeit-Synchronisation
und der Zustand der systemd-Dienste.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

DB_PATH = "hl_liq.db"
OK, WARN, CRIT = 0, 1, 2
LABEL = {OK: "ok", WARN: "WARNUNG", CRIT: "KRITISCH"}


@dataclass
class Check:
    name: str
    level: int
    detail: str


# ---------------------------------------------------------------------------
# Signalgeber
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tonausgabe
# ---------------------------------------------------------------------------

def _square_wave(freq: float, ms: int, rate: int = 22050,
                 vol: float = 0.35, duty: float = 0.5) -> bytearray:
    """Rechteckschwingung — der Klang der 8-Bit-Ära, erzeugt statt abgespielt."""
    import array
    n = int(rate * ms / 1000)
    buf = array.array("h")
    period = rate / freq if freq > 0 else 1
    amp = int(32767 * vol)
    for i in range(n):
        # weiche Flanken am Ende, sonst knackt es
        fade = min(1.0, (n - i) / (rate * 0.012)) if n - i < rate * 0.012 else 1.0
        val = amp if (i % period) < period * duty else -amp
        buf.append(int(val * fade))
    return bytearray(buf.tobytes())


def make_alarm_wav(critical: bool) -> bytes:
    """
    Retro-Alarm im Stil alter Spielautomaten: schnelle Arpeggien aus
    Rechteckschwingungen. Bei Warnung ein aufsteigender Zweiklang, bei
    kritischem Zustand eine schrille Sirene aus wechselnden Tönen.
    """
    import io, wave
    rate = 22050
    pcm = bytearray()
    silence = bytearray(int(rate * 0.03) * 2)

    if critical:
        # dreimal: schneller Auf- und Abstieg, dann zwei Sirenentöne
        for _ in range(3):
            for f in (1046, 1318, 1568, 2093, 1568, 1318):
                pcm += _square_wave(f, 45, rate, 0.40, 0.25)
            pcm += silence
        for _ in range(2):
            pcm += _square_wave(880, 180, rate, 0.42)
            pcm += _square_wave(587, 180, rate, 0.42)
    else:
        for _ in range(2):
            for f in (523, 659, 784):
                pcm += _square_wave(f, 70, rate, 0.30, 0.5)
            pcm += silence

    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(pcm))
    return out.getvalue()


class Sound:
    """Spielt den Alarm über die vorhandene Audioausgabe."""

    PLAYERS = [
        (["aplay", "-q"], "ALSA (HDMI, USB-Audio, DAC-HAT)"),
        (["paplay"], "PulseAudio/PipeWire"),
        (["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"], "ffmpeg"),
    ]

    def __init__(self, enabled: bool = True):
        self.cmd = None
        self.why = ""
        if not enabled:
            self.why = "abgeschaltet"
            return
        for cmd, label in self.PLAYERS:
            if shutil.which(cmd[0]):
                self.cmd = cmd
                self.why = label
                break
        if not self.cmd:
            self.why = ("kein Abspielprogramm gefunden — "
                        "sudo apt install alsa-utils")
            return
        if self.cmd[0] == "aplay" and not self._alsa_devices():
            self.why = ("aplay vorhanden, aber kein Ausgabegerät. Der Pi 5 hat "
                        "weder eingebauten Lautsprecher noch Klinkenbuchse — "
                        "es braucht HDMI-Ton, einen USB-Soundstick oder ein DAC-HAT.")
            self.cmd = None

    @staticmethod
    def _alsa_devices() -> bool:
        try:
            r = subprocess.run(["aplay", "-l"], capture_output=True, text=True, timeout=10)
            return r.returncode == 0 and "card" in r.stdout
        except (OSError, subprocess.SubprocessError):
            return False

    def available(self) -> bool:
        return self.cmd is not None

    def play(self, critical: bool) -> bool:
        if not self.cmd:
            # letzter Rückfall: Terminalglocke, nützt nur bei offener Konsole
            sys.stdout.write("\a"); sys.stdout.flush()
            return False
        import tempfile
        path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(make_alarm_wav(critical))
                path = f.name
            subprocess.run(self.cmd + [path], capture_output=True, timeout=30)
            return True
        except (OSError, subprocess.SubprocessError):
            return False
        finally:
            if path:
                try:
                    os.unlink(path)
                except OSError:
                    pass


class Buzzer:
    """Aktiver Summer an einem GPIO-Pin. Auf dem Pi 5 über lgpio."""

    def __init__(self, pin: int | None, quiet: bool = False):
        self.dev = None
        self.quiet = quiet
        if pin is None:
            return
        try:
            from gpiozero import Buzzer as GZBuzzer
            self.dev = GZBuzzer(pin)
            if not quiet:
                print(f"Summer an GPIO {pin} bereit.")
        except Exception as e:
            if not quiet:
                print(f"Summer nicht verfügbar ({e}).")
                print("  Auf dem Pi 5: sudo apt install python3-gpiozero python3-lgpio")
                print("  RPi.GPIO funktioniert dort nicht, der Chip ist ein anderer.")

    def beep(self, times: int, on: float = 0.2, off: float = 0.2) -> None:
        if not self.dev:
            return
        for _ in range(times):
            self.dev.on(); time.sleep(on)
            self.dev.off(); time.sleep(off)


class StatusLed:
    """Blinkt die ACT-LED des Pi. Braucht Schreibrechte in /sys/class/leds."""

    def __init__(self, enabled: bool, quiet: bool = False):
        self.path = None
        if not enabled:
            return
        for cand in ("/sys/class/leds/ACT", "/sys/class/leds/led0"):
            p = Path(cand)
            if p.exists() and os.access(p / "brightness", os.W_OK):
                self.path = p
                try:
                    (p / "trigger").write_text("none")
                except OSError:
                    pass
                if not quiet:
                    print(f"Status-LED {cand} bereit.")
                return
        if not quiet:
            print("Status-LED nicht beschreibbar — der Dienst müsste als root laufen.")

    def blink(self, times: int, on: float = 0.15, off: float = 0.15) -> None:
        if not self.path:
            return
        try:
            for _ in range(times):
                (self.path / "brightness").write_text("1"); time.sleep(on)
                (self.path / "brightness").write_text("0"); time.sleep(off)
        except OSError:
            pass


def notify(topic: str | None, title: str, msg: str, priority: str = "default") -> bool:
    """Push über ntfy.sh. Scheitert lautlos, wenn keine Verbindung besteht."""
    if not topic:
        return False
    url = topic if topic.startswith("http") else f"https://ntfy.sh/{topic}"
    try:
        req = urllib.request.Request(
            url, data=msg.encode("utf-8"),
            headers={"Title": title, "Priority": priority, "Tags": "warning"})
        urllib.request.urlopen(req, timeout=10).read()
        return True
    except Exception:
        return False


def heartbeat(url: str | None, failed: bool = False) -> bool:
    """
    Lebenszeichen an einen externen Dienst.

    Der eigentliche Wert liegt im Ausbleiben: Meldet sich der Pi nicht mehr,
    schlägt der Dienst Alarm — auch dann, wenn hier nichts mehr läuft.
    """
    if not url:
        return False
    try:
        urllib.request.urlopen(url + ("/fail" if failed else ""), timeout=10).read()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Prüfungen
# ---------------------------------------------------------------------------

def _probe(url: str, expect: str, post: dict | None = None,
           timeout: float = 8) -> bool:
    """
    Erreichbarkeit über den erwarteten INHALT prüfen, nicht über den Statuscode.

    Ein Captive Portal, ein Proxy oder eine Router-Fehlerseite antwortet mit
    HTTP 200 oder 403 und sähe bei einer reinen Status- oder Socket-Prüfung
    wie eine funktionierende Verbindung aus. Nur wer das erwartete Stück Text
    zurückliefert, ist wirklich der gemeinte Server.
    """
    try:
        data = json.dumps(post).encode() if post else None
        headers = {"User-Agent": "hl-watchdog/1.0"}
        if post:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers)
        body = urllib.request.urlopen(req, timeout=timeout).read(4096).decode(
            "utf-8", "replace")
        return expect in body
    except Exception:
        return False


def check_connectivity() -> Check:
    probes = [
        # Firefox' Portal-Erkennung liefert exakt "success" — der Standardtrick
        ("Internet", "http://detectportal.firefox.com/success.txt", "success", None),
        ("Binance", "https://fapi.binance.com/fapi/v1/ping", "{", None),
        ("Hyperliquid", "https://api.hyperliquid.xyz/info", "universe",
         {"type": "meta"}),
    ]
    down = [name for name, url, expect, post in probes if not _probe(url, expect, post)]
    if not down:
        return Check("Verbindung", OK, "alle Endpunkte antworten korrekt")
    if "Internet" in down:
        return Check("Verbindung", CRIT,
                     "keine nutzbare Internetverbindung "
                     f"({', '.join(down)} ohne gültige Antwort)")
    return Check("Verbindung", WARN, f"keine gültige Antwort von: {', '.join(down)}")


def run_checks(db: str, snapshot_sec: int, coins: list[str]) -> list[Check]:
    out: list[Check] = []
    now = int(time.time())

    out.append(check_connectivity())

    # --- Datenbank
    if not os.path.exists(db):
        out.append(Check("Datenbank", CRIT, f"{db} fehlt"))
        return out
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        con.execute("PRAGMA temp_store=MEMORY")
    except sqlite3.Error as e:
        out.append(Check("Datenbank", CRIT, f"nicht lesbar: {e}"))
        return out

    def newest(table: str, where: str = "", args: tuple = ()) -> int | None:
        try:
            r = con.execute(f"SELECT MAX(ts) FROM {table} {where}", args).fetchone()
            return r[0]
        except sqlite3.Error:
            return None

    # --- Bars: der empfindlichste Indikator, es handelt praktisch immer jemand
    ts = newest("bars")
    if ts is None:
        out.append(Check("Kursdaten", CRIT, "keine Bars vorhanden"))
    else:
        age = (now - ts) // 60
        lvl = OK if age <= 10 else (WARN if age <= 30 else CRIT)
        out.append(Check("Kursdaten", lvl, f"jüngste Bar vor {age} min"))

    # --- Coins einzeln: erkennt Delistings und tote Einzelfeeds
    stale = []
    for c in coins:
        ts = newest("bars", "WHERE coin=?", (c,))
        if ts is None or now - ts > 3600:
            stale.append(c if ts else f"{c} (nie)")
    if stale:
        out.append(Check("Coin-Feeds", WARN, f"seit über 1 h still: {', '.join(stale)}"))
    else:
        out.append(Check("Coin-Feeds", OK, f"{len(coins)} Feeds aktiv"))

    # --- Heatmap-Snapshots
    ts = newest("heatmap")
    if ts is None:
        out.append(Check("Snapshots", WARN, "noch keine — normal in der Anlaufzeit"))
    else:
        age = now - ts
        lvl = OK if age <= snapshot_sec * 2 else (
            WARN if age <= snapshot_sec * 4 else CRIT)
        out.append(Check("Snapshots", lvl, f"letzter vor {age//60} min "
                                           f"(Takt {snapshot_sec//60} min)"))

    # --- Abdeckung des Open Interest: die ehrlichste Kennzahl für die Datenqualität
    try:
        cov = con.execute(
            "SELECT coin, ratio FROM coverage WHERE ts = (SELECT MAX(ts) FROM coverage)"
        ).fetchall()
        if cov:
            low = [f"{c} {r*100:.0f}%" for c, r in cov if r < 0.25]
            txt = "  ".join(f"{c} {r*100:.0f}%" for c, r in sorted(cov))
            out.append(Check("Abdeckung", WARN if low else OK,
                             txt + ("  (unter 25 % ist die Heatmap kaum repräsentativ)"
                                    if low else "")))
        ts = newest("ctx_bars")
        if ts is not None and now - ts > 900:
            out.append(Check("Marktkontext", WARN,
                             f"Markpreis-Feed seit {(now-ts)//60} min still"))
    except sqlite3.Error:
        pass

    # --- API-Budget: Gewicht der letzten Minute gegen das Hyperliquid-Limit
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN ('api_weight_1m','api_weight_budget')"))
        if "api_weight_1m" in rows:
            used, budget = int(rows["api_weight_1m"]), int(rows.get("api_weight_budget", 1200))
            pct = used / budget * 100
            out.append(Check("API-Budget", OK if pct < 80 else (WARN if pct < 95 else CRIT),
                             f"{used} von {budget} Gewicht/min ({pct:.0f} %)"
                             + ("  — --polls-per-min oder --stop-budget senken" if pct >= 80 else "")))
    except (sqlite3.Error, ValueError):
        pass

    # --- Rate-Limit-Treffer: schreibt der Recorder bei jedem Snapshot in meta
    try:
        r429 = con.execute("SELECT v FROM meta WHERE k='rate_limited'").fetchone()
        if r429:
            n429 = int(r429[0])
            out.append(Check("Rate-Limit", OK if n429 == 0 else (WARN if n429 < 50 else CRIT),
                             f"{n429} Antworten mit 429 seit Prozessstart"
                             + ("  — --polls-per-min senken" if n429 else "")))
    except (sqlite3.Error, ValueError):
        pass

    # --- Poller-Rückstand
    try:
        ages = sorted(now - r[0] for r in con.execute(
            "SELECT last_poll FROM addresses WHERE notional>0 AND last_poll>0"))
        if ages:
            p90 = ages[int(len(ages) * 0.9)] // 60
            lvl = OK if p90 <= 45 else (WARN if p90 <= 120 else CRIT)
            out.append(Check("Poller", lvl, f"90 % der Positionen jünger als {p90} min"))
    except sqlite3.Error:
        pass

    # --- Binance: Open Interest wird im festen Takt geschrieben,
    #     Liquidationen sind sporadisch und taugen nicht als Lebenszeichen
    ts = newest("bnc_metrics")
    if ts is not None:
        age = (now - ts) // 60
        lvl = OK if age <= 25 else (WARN if age <= 60 else CRIT)
        out.append(Check("Binance", lvl, f"jüngster Wert vor {age} min"))

    # --- Backup-Alter: Ort aus meta (der Recorder trägt ihn ein), sonst neben der DB.
    #     Muss VOR con.close() laufen -- vorher stand es dahinter und lief still ins Leere.
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    try:
        r0 = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
        if r0 and r0[0]:
            bdir = r0[0]
    except sqlite3.Error:
        pass
    oldest_bar = None
    try:
        oldest_bar = con.execute("SELECT MIN(ts) FROM bars").fetchone()[0]
    except sqlite3.Error:
        pass
    con.close()
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            st = json.load(f)
        if st.get("ok"):
            age_h = (now - st["ts"]) / 3600
            out.append(Check("Backup", OK if age_h < 26 else (WARN if age_h < 50 else CRIT),
                             f"vor {age_h:.1f} h, {st['size']/1e6:.0f} MB in {bdir}"))
        else:
            out.append(Check("Backup", WARN, f"fehlgeschlagen: {st.get('error')}"))
    except (OSError, ValueError):
        # kein Backup: harmlos in den ersten Stunden, danach eine Warnung wert
        if oldest_bar and now - oldest_bar > 26 * 3600:
            out.append(Check("Backup", WARN, f"keines gefunden in {bdir} — Recorder-Log prüfen"))

    # --- Plattenplatz
    free = shutil.disk_usage(os.path.dirname(os.path.abspath(db))).free / 1e9
    lvl = OK if free >= 5 else (WARN if free >= 1.5 else CRIT)
    out.append(Check("Speicherplatz", lvl, f"{free:.1f} GB frei"))

    # --- Uhrzeit: ohne NTP sind alle Zeitstempel wertlos
    try:
        r = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
                           capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip() != "yes":
            out.append(Check("Systemzeit", WARN, "nicht per NTP synchronisiert"))
        elif r.returncode == 0:
            out.append(Check("Systemzeit", OK, "synchronisiert"))
    except (OSError, subprocess.SubprocessError):
        pass

    # --- systemd-Dienste
    if shutil.which("systemctl"):
        dead = []
        for unit in ("hl-recorder", "hl-binance", "hl-dashboard"):
            r = subprocess.run(["systemctl", "is-enabled", unit],
                               capture_output=True, text=True)
            if r.stdout.strip() not in ("enabled", "enabled-runtime"):
                continue                     # nicht eingerichtet, also egal
            a = subprocess.run(["systemctl", "is-active", unit],
                               capture_output=True, text=True)
            if a.stdout.strip() != "active":
                dead.append(f"{unit} ({a.stdout.strip() or 'unbekannt'})")
        if dead:
            out.append(Check("Dienste", CRIT, "; ".join(dead)))
        else:
            out.append(Check("Dienste", OK, "alle aktiven Units laufen"))

    return out


# ---------------------------------------------------------------------------
# Alarmsteuerung
# ---------------------------------------------------------------------------

@dataclass
class AlarmState:
    level: int = OK
    since: float = 0.0
    last_notify: float = 0.0
    last_beep: float = 0.0
    history: list = field(default_factory=list)


def report(checks: list[Check], quiet: bool = False) -> int:
    worst = max((c.level for c in checks), default=OK)
    if not quiet:
        print(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} — Gesamtstatus: {LABEL[worst]}")
        print("-" * 62)
        for c in checks:
            mark = {OK: "  ok   ", WARN: "  !    ", CRIT: "  XXX  "}[c.level]
            print(f"{mark}{c.name:<16}{c.detail}")
    return worst


def main() -> None:
    p = argparse.ArgumentParser(description="Wächter mit Alarm")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"])
    p.add_argument("--snapshot-sec", type=int, default=600)
    p.add_argument("--interval", type=int, default=300, help="Prüftakt in Sekunden")
    p.add_argument("--no-sound", action="store_true",
                   help="Tonausgabe abschalten")
    p.add_argument("--alarm-interval", type=int, default=120,
                   help="Abstand wiederholter Alarmtöne in Sekunden")
    p.add_argument("--buzzer", type=int, metavar="GPIO",
                   help="optional: GPIO-Pin eines aktiven Summers")
    p.add_argument("--led", action="store_true", help="ACT-LED blinken lassen")
    p.add_argument("--ntfy", help="ntfy.sh-Topic oder vollständige URL")
    p.add_argument("--heartbeat", help="URL für den Totmannschalter, z. B. hc-ping.com/UUID")
    p.add_argument("--renotify", type=int, default=3600,
                   help="Abstand wiederholter Meldungen in Sekunden")
    p.add_argument("--once", action="store_true")
    p.add_argument("--json", action="store_true", help="Ausgabe als JSON")
    p.add_argument("--test-alarm", action="store_true")
    args = p.parse_args()

    sound = Sound(not args.no_sound)
    if not (args.once and args.json):
        # In der JSON-Ausgabe darf nichts vor dem Dokument stehen
        print(f"Tonausgabe: {sound.why}")
    quiet = bool(args.once and args.json)
    buzzer = Buzzer(args.buzzer, quiet)
    led = StatusLed(args.led, quiet)

    if args.test_alarm:
        print("Warnung — aufsteigender Zweiklang …")
        sound.play(False); buzzer.beep(2); led.blink(2)
        time.sleep(1)
        print("Kritisch — Sirene …")
        sound.play(True); buzzer.beep(5, 0.4, 0.15); led.blink(5, .3, .1)
        if not sound.available():
            print("\nEs kam kein Ton: " + sound.why)
        ok = notify(args.ntfy, "Wächter-Test", "Wenn du das liest, funktioniert ntfy.")
        print(f"ntfy: {'zugestellt' if ok else 'nicht zugestellt oder nicht gesetzt'}")
        print(f"Heartbeat: {'gesendet' if heartbeat(args.heartbeat) else 'nicht gesetzt'}")
        return

    if args.once:
        checks = run_checks(args.db, args.snapshot_sec, args.coins)
        if args.json:
            print(json.dumps({"status": LABEL[report(checks, quiet=True)],
                              "checks": [{"name": c.name, "level": LABEL[c.level],
                                          "detail": c.detail} for c in checks]},
                             indent=2, ensure_ascii=False))
        else:
            report(checks)
        sys.exit(report(checks, quiet=True))

    st = AlarmState()
    print(f"Wächter läuft, Prüftakt {args.interval//60} min. Strg-C beendet.")
    if not sound.available() and not args.buzzer and not args.led and not args.heartbeat:
        print("Hinweis: kein Signalgeber aktiv — es wird nur geloggt.")

    try:
        while True:
            checks = run_checks(args.db, args.snapshot_sec, args.coins)
            worst = report(checks)
            bad = [c for c in checks if c.level >= WARN]
            now = time.time()

            vorher = st.level          # VOR der Zuweisung merken: Die Entwarnung unten
            if worst != st.level:          # verglich sonst gegen den bereits neu gesetzten
                st.level, st.since = worst, now     # Wert und konnte nie zutreffen.
                st.last_notify = 0.0          # Zustandswechsel meldet sofort

            if worst >= WARN:
                # Lokaler Signalgeber im eingestellten Takt, solange die
                # Störung anhält. Warnungen seltener als kritische Zustände.
                every = args.alarm_interval if worst == CRIT else args.alarm_interval * 4
                if now - st.last_beep >= every:
                    sound.play(worst == CRIT)
                    buzzer.beep(5 if worst == CRIT else 2,
                                0.4 if worst == CRIT else 0.2)
                    led.blink(5 if worst == CRIT else 2)
                    st.last_beep = now

                if now - st.last_notify >= args.renotify:
                    msg = "\n".join(f"{LABEL[c.level]}: {c.name} — {c.detail}"
                                    for c in bad)
                    dur = int((now - st.since) // 60)
                    if notify(args.ntfy, f"Recorder: {LABEL[worst]}",
                              f"{msg}\n\nZustand seit {dur} min.",
                              "urgent" if worst == CRIT else "high"):
                        st.last_notify = now

            # Heartbeat: bei kritischem Zustand als Fehlschlag melden,
            # damit der externe Dienst sofort und nicht erst nach Ablauf warnt
            heartbeat(args.heartbeat, failed=(worst == CRIT))

            if worst == OK and vorher != OK:
                notify(args.ntfy, "Recorder: wieder in Ordnung",
                       "Alle Prüfungen bestanden.", "default")

            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nWächter beendet.")


if __name__ == "__main__":
    main()
