#!/usr/bin/env python3
"""
hl_watchdog.py — Überwacht die Aufzeichnung und schlägt Alarm.

Zwei Ebenen, weil eine allein nicht reicht:

  1. LOKAL — Alarmton über die Audioausgabe, dazu wahlweise die ACT-LED.
     Funktioniert ohne Internet, also genau dann, wenn der Ausfall die
     Verbindung betrifft.

     Achtung: Der Pi 5 hat KEINEN eingebauten Lautsprecher und auch keine
     Klinkenbuchse mehr. Ton braucht HDMI mit angeschlossenem Bildschirm,
     einen USB-Soundstick, Bluetooth oder ein I2S-DAC-HAT. Ohne eines davon
     bleibt es still — dann sind LED und Totmannschalter die Alternative.
  2. EXTERN — regelmäßiger Lebenszeichen-Ping an einen Dienst wie
     healthchecks.io. Bleibt er aus, alarmiert der Dienst DICH. Das ist die
     einzige Ebene, die auch dann greift, wenn der Pi tot ist oder brennt.

Zusätzlich Push-Nachrichten über ntfy.sh, solange die Verbindung steht.

    python hl_watchdog.py --once                      # einmalig prüfen
    python hl_watchdog.py --alarm-interval 120        # Ton alle 2 min bei Störung
    python hl_watchdog.py --ntfy mein-geheimes-topic \\
                          --heartbeat https://hc-ping.com/DEINE-UUID
    python hl_watchdog.py --test-alarm                # Signalgeber prüfen

Geprüft wird: Alter der Bars, der Snapshots und der Binance-Daten, Rückstand
des Pollers, Erreichbarkeit der Börsen, Plattenplatz, Uhrzeit-Synchronisation
und der Zustand der systemd-Dienste; seit 23.78 auch, ob das Dashboard auf
seinem Port antwortet (am 23.10. lief der Prozess knapp 5 h weiter, ohne zu
antworten -- systemd und dieser Wächter meldeten „aktiv“). Seit 23.80 (U218)
messen Poller und Abdeckung gegen ihren eigenen Normalwert der letzten 7 Tage
statt gegen feste Schwellen: Bis dahin stand der Wächter wegen des bekannt zu
knappen Abfragebudgets dauernd auf KRITISCH und meldete so keinen echten
Ausfall mehr.

    python hl_watchdog.py --selbsttest                # Proben der Dashboard-Prüfung
"""

from __future__ import annotations

import argparse
import json
import os
import re
import statistics
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

DB_PATH = "hl_liq.db"
DASH_URL = "http://127.0.0.1:8765/lebt"     # 23.78: Lebenszeichen-Seite des Dashboards (ältere Stände: 404 -- zählt auch als Antwort)
OK, WARN, CRIT = 0, 1, 2
LABEL = {OK: "ok", WARN: "WARNUNG", CRIT: "KRITISCH"}


@dataclass
class Check:
    name: str
    level: int
    detail: str


# ---------------------------------------------------------------------------
# Signalgeber
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tonausgabe
# ---------------------------------------------------------------------------

def _square_wave(freq: float, ms: int, rate: int = 22050,
                 vol: float = 0.35, duty: float = 0.5) -> bytearray:
    """Rechteckschwingung — der Klang der 8-Bit-Ära, erzeugt statt abgespielt."""
    import array
    n = int(rate * ms / 1000)
    buf = array.array("h")
    period = rate / freq if freq > 0 else 1
    amp = int(32767 * vol)
    for i in range(n):
        # weiche Flanken am Ende, sonst knackt es
        fade = min(1.0, (n - i) / (rate * 0.012)) if n - i < rate * 0.012 else 1.0
        val = amp if (i % period) < period * duty else -amp
        buf.append(int(val * fade))
    return bytearray(buf.tobytes())


def make_alarm_wav(critical: bool) -> bytes:
    """
    Retro-Alarm im Stil alter Spielautomaten: schnelle Arpeggien aus
    Rechteckschwingungen. Bei Warnung ein aufsteigender Zweiklang, bei
    kritischem Zustand eine schrille Sirene aus wechselnden Tönen.
    """
    import io, wave
    rate = 22050
    pcm = bytearray()
    silence = bytearray(int(rate * 0.03) * 2)

    if critical:
        # dreimal: schneller Auf- und Abstieg, dann zwei Sirenentöne
        for _ in range(3):
            for f in (1046, 1318, 1568, 2093, 1568, 1318):
                pcm += _square_wave(f, 45, rate, 0.40, 0.25)
            pcm += silence
        for _ in range(2):
            pcm += _square_wave(880, 180, rate, 0.42)
            pcm += _square_wave(587, 180, rate, 0.42)
    else:
        for _ in range(2):
            for f in (523, 659, 784):
                pcm += _square_wave(f, 70, rate, 0.30, 0.5)
            pcm += silence

    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(pcm))
    return out.getvalue()


class Sound:
    """Spielt den Alarm über die vorhandene Audioausgabe."""

    PLAYERS = [
        (["aplay", "-q"], "ALSA (HDMI, USB-Audio, DAC-HAT)"),
        (["paplay"], "PulseAudio/PipeWire"),
        (["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"], "ffmpeg"),
    ]

    def __init__(self, enabled: bool = True):
        self.cmd = None
        self.why = ""
        if not enabled:
            self.why = "abgeschaltet"
            return
        for cmd, label in self.PLAYERS:
            if shutil.which(cmd[0]):
                self.cmd = cmd
                self.why = label
                break
        if not self.cmd:
            self.why = ("kein Abspielprogramm gefunden — "
                        "sudo apt install alsa-utils")
            return
        if self.cmd[0] == "aplay" and not self._alsa_devices():
            self.why = ("aplay vorhanden, aber kein Ausgabegerät. Der Pi 5 hat "
                        "weder eingebauten Lautsprecher noch Klinkenbuchse — "
                        "es braucht HDMI-Ton, einen USB-Soundstick oder ein DAC-HAT.")
            self.cmd = None

    @staticmethod
    def _alsa_devices() -> bool:
        try:
            r = subprocess.run(["aplay", "-l"], capture_output=True, text=True, timeout=10)
            return r.returncode == 0 and "card" in r.stdout
        except (OSError, subprocess.SubprocessError):
            return False

    def available(self) -> bool:
        return self.cmd is not None

    def play(self, critical: bool) -> bool:
        if not self.cmd:
            # letzter Rückfall: Terminalglocke, nützt nur bei offener Konsole
            sys.stdout.write("\a"); sys.stdout.flush()
            return False
        import tempfile
        path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(make_alarm_wav(critical))
                path = f.name
            subprocess.run(self.cmd + [path], capture_output=True, timeout=30)
            return True
        except (OSError, subprocess.SubprocessError):
            return False
        finally:
            if path:
                try:
                    os.unlink(path)
                except OSError:
                    pass


class Buzzer:
    """Aktiver Summer an einem GPIO-Pin. Auf dem Pi 5 über lgpio."""

    def __init__(self, pin: int | None, quiet: bool = False):
        self.dev = None
        self.quiet = quiet
        if pin is None:
            return
        try:
            from gpiozero import Buzzer as GZBuzzer
            self.dev = GZBuzzer(pin)
            if not quiet:
                print(f"Summer an GPIO {pin} bereit.")
        except Exception as e:
            if not quiet:
                print(f"Summer nicht verfügbar ({e}).")
                print("  Auf dem Pi 5: sudo apt install python3-gpiozero python3-lgpio")
                print("  RPi.GPIO funktioniert dort nicht, der Chip ist ein anderer.")

    def beep(self, times: int, on: float = 0.2, off: float = 0.2) -> None:
        if not self.dev:
            return
        for _ in range(times):
            self.dev.on(); time.sleep(on)
            self.dev.off(); time.sleep(off)


class StatusLed:
    """Blinkt die ACT-LED des Pi. Braucht Schreibrechte in /sys/class/leds."""

    def __init__(self, enabled: bool, quiet: bool = False):
        self.path = None
        if not enabled:
            return
        for cand in ("/sys/class/leds/ACT", "/sys/class/leds/led0"):
            p = Path(cand)
            if p.exists() and os.access(p / "brightness", os.W_OK):
                self.path = p
                try:
                    (p / "trigger").write_text("none")
                except OSError:
                    pass
                if not quiet:
                    print(f"Status-LED {cand} bereit.")
                return
        if not quiet:
            print("Status-LED nicht beschreibbar — der Dienst müsste als root laufen.")

    def blink(self, times: int, on: float = 0.15, off: float = 0.15) -> None:
        if not self.path:
            return
        try:
            for _ in range(times):
                (self.path / "brightness").write_text("1"); time.sleep(on)
                (self.path / "brightness").write_text("0"); time.sleep(off)
        except OSError:
            pass


def notify(topic: str | None, title: str, msg: str, priority: str = "default") -> bool:
    """Push über ntfy.sh. Scheitert lautlos, wenn keine Verbindung besteht."""
    if not topic:
        return False
    url = topic if topic.startswith("http") else f"https://ntfy.sh/{topic}"
    try:
        req = urllib.request.Request(
            url, data=msg.encode("utf-8"),
            headers={"Title": title, "Priority": priority, "Tags": "warning"})
        urllib.request.urlopen(req, timeout=10).read()
        return True
    except Exception:
        return False


def heartbeat(url: str | None, failed: bool = False) -> bool:
    """
    Lebenszeichen an einen externen Dienst.

    Der eigentliche Wert liegt im Ausbleiben: Meldet sich der Pi nicht mehr,
    schlägt der Dienst Alarm — auch dann, wenn hier nichts mehr läuft.
    """
    if not url:
        return False
    try:
        urllib.request.urlopen(url + ("/fail" if failed else ""), timeout=10).read()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Prüfungen
# ---------------------------------------------------------------------------

def _probe(url: str, expect: str, post: dict | None = None,
           timeout: float = 8) -> bool:
    """
    Erreichbarkeit über den erwarteten INHALT prüfen, nicht über den Statuscode.

    Ein Captive Portal, ein Proxy oder eine Router-Fehlerseite antwortet mit
    HTTP 200 oder 403 und sähe bei einer reinen Status- oder Socket-Prüfung
    wie eine funktionierende Verbindung aus. Nur wer das erwartete Stück Text
    zurückliefert, ist wirklich der gemeinte Server.
    """
    try:
        data = json.dumps(post).encode() if post else None
        headers = {"User-Agent": "hl-watchdog/1.0"}
        if post:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers)
        body = urllib.request.urlopen(req, timeout=timeout).read(4096).decode(
            "utf-8", "replace")
        return expect in body
    except Exception:
        return False


def check_connectivity() -> Check:
    probes = [
        # Firefox' Portal-Erkennung liefert exakt "success" — der Standardtrick
        ("Internet", "http://detectportal.firefox.com/success.txt", "success", None),
        ("Binance", "https://fapi.binance.com/fapi/v1/ping", "{", None),
        ("Hyperliquid", "https://api.hyperliquid.xyz/info", "universe",
         {"type": "meta"}),
    ]
    down = [name for name, url, expect, post in probes if not _probe(url, expect, post)]
    if not down:
        return Check("Verbindung", OK, "alle Endpunkte antworten korrekt")
    if "Internet" in down:
        return Check("Verbindung", CRIT,
                     "keine nutzbare Internetverbindung "
                     f"({', '.join(down)} ohne gültige Antwort)")
    return Check("Verbindung", WARN, f"keine gültige Antwort von: {', '.join(down)}")


# ---------------------------------------------------------------------------
# 23.80 (U218): Poller und Abdeckung gegen den eigenen Normalwert
# ---------------------------------------------------------------------------
# Bis 23.79 stand der Wächter dauernd auf KRITISCH: „Poller 90 % der Positionen jünger als ~1.100 min“ (kritisch ab 120 min) und
# „Abdeckung unter 25 %“. Beides beschreibt einen bekannten Dauerzustand, keinen Ausfall: Der Poller braucht laut Recorder rund das
# Vierfache seines Abfragebudgets (Auslastung 396 % am 23.10.), das 90-%-Quantil lief über ALLE Adressen mit Position einschließlich der
# kleinen, die planmäßig nur alle 2 h drankommen, und `addresses.last_poll` schreibt der Recorder nur stündlich. Ein Wächter, der immer rot
# ist, meldet keinen echten Ausfall mehr. Jetzt:
#  * Poller KRITISCH, wenn er steht (letzte Runde laut meta 'jobs' über 5 min her; sonst alle 5 s) oder der Snapshot leer ist;
#    WARNUNG, wenn der Anteil zu alter Positionen im Snapshot über 20 Prozentpunkte über seinem Normalwert der letzten 7 Tage liegt oder
#    mindestens 97 % beträgt. Die Kapazität selbst (U218, nach dem 25.10.) steht im Text, nicht als Alarm.
#  * Abdeckung WARNUNG, wenn ein Coin unter die Hälfte seines Normalwerts fällt (Median der letzten 7 Tage).
#  * Anlauf nach einem Neustart des Recorders (die ersten 45 min): die Abdeckung fällt dann rund 15–35 min lang (gemessen 23.10.: 17:45,
#    19:10) -- kein Alarm, nur Hinweis. Damit der Anlauf eine Neustart-Schleife nicht verdeckt: ab 3 Starts in 2 h WARNUNG (Updates kommen
#    nicht so dicht; am 23.10. lagen sie 17:30, 18:55, 20:29).
ANLAUF_S = 2700
NORMAL_TAGE = 7
NORMAL_MIN_N = 36                   # mindestens 6 h Verlauf (Snapshot alle 10 min) für einen Normalwert
NEUSTART_FENSTER_S = 7200
NEUSTART_MAX = 3


def recorder_starts(rows, now: int, fenster: int = NEUSTART_FENSTER_S) -> int:
    """Starts des Recorders in den letzten `fenster` Sekunden aus snapshot_meta (Start = ts - uptime; Werte desselben Laufs liegen wenige
    Sekunden auseinander und zählen einmal). Ein Lauf ohne Snapshot (unter 10 min) fehlt -- dann hilft die Zeile „Snapshots“."""
    starts = sorted({int(r[0] - r[4]) for r in rows if r[4] is not None and r[0] >= now - fenster - 900})
    n, letzte = 0, None
    for s_ in starts:
        if s_ >= now - fenster and (letzte is None or s_ - letzte > 120):
            n += 1
        letzte = s_
    return n


def poller_lauf(con) -> int | None:
    """Letzte Runde des Adress-Pollers: meta 'jobs' (JSON, alle 30 s geschrieben, bei 4.000 Zeichen abgeschnitten -- dann per Muster)."""
    try:
        r = con.execute("SELECT v FROM meta WHERE k='jobs'").fetchone()
    except sqlite3.Error:
        return None
    if not r or not r[0]:
        return None
    try:
        last = (json.loads(r[0]).get("Adress-Poller") or {}).get("last")
        return int(last) if last else None
    except (ValueError, AttributeError, TypeError):
        m = re.search(r'"Adress-Poller":\s*\{"last":\s*(\d+)', r[0])
        return int(m.group(1)) if m else None


def check_poller(con, now: int, anlauf_s: int = ANLAUF_S, tage: int = NORMAL_TAGE) -> Check | None:
    """Poller: läuft er (KRITISCH, wenn nicht), und wie viel des letzten Snapshots fiel wegen Alters heraus -- gegen den Normalwert."""
    lauf = poller_lauf(con)
    teile = []
    if lauf is not None:
        alter = now - lauf
        if alter > 300:
            return Check("Poller", CRIT, f"steht: letzte Runde vor {alter // 60} min (sonst alle 5 s) -- Recorder-Log prüfen")
        teile.append(f"läuft (letzte Runde vor {max(0, alter)} s)")
    try:
        rows = con.execute("SELECT ts, n_positions, n_stale_dropped, backlog, uptime FROM snapshot_meta WHERE ts >= ? ORDER BY ts",
                           (now - tage * 86_400,)).fetchall()
    except sqlite3.Error:
        rows = []
    if not rows:
        return Check("Poller", OK, "; ".join(teile) or "kein Snapshot-Verlauf") if teile else None
    _ts, n_pos, n_alt, backlog, up = rows[-1]
    n_pos, n_alt = int(n_pos or 0), int(n_alt or 0)
    gesamt = n_pos + n_alt
    anteil = n_alt / gesamt if gesamt else None
    basis = [r[2] / (r[1] + r[2]) for r in rows[:-1] if (r[1] or 0) + (r[2] or 0) and (r[4] or 0) >= anlauf_s]
    med = statistics.median(basis) if len(basis) >= NORMAL_MIN_N else None
    txt = (f"Snapshot {n_pos} Positionen, {anteil * 100:.0f} % zu alt ausgelassen" if anteil is not None else f"Snapshot {n_pos} Positionen")
    txt += f" (üblich {med * 100:.0f} %)" if med is not None else " (Normalwert ab 6 h Verlauf)"
    if backlog:
        txt += f", überfällig {backlog}"
    if up is not None and up < anlauf_s:
        n_st = recorder_starts(rows, now)
        if n_st >= NEUSTART_MAX:
            return Check("Poller", WARN, "; ".join(teile + [f"Recorder in 2 h {n_st}-mal gestartet -- Neustart-Schleife? Recorder-Log prüfen",
                                                            txt]))
        return Check("Poller", OK, "; ".join(teile + [f"Anlauf nach Neustart des Recorders (seit {up // 60} min)", txt]))
    if gesamt and n_pos == 0:
        return Check("Poller", CRIT, "; ".join(teile + [f"Snapshot leer: alle {n_alt} Positionen zu alt -- der Poller liefert nichts"]))
    lvl = OK
    if anteil is not None and (anteil >= 0.97 or (med is not None and anteil - med > 0.20)):
        lvl = WARN
    if anteil is not None and anteil > 0.5 and lvl == OK:
        txt += " -- Abfragebudget zu knapp, bekannt (U218)"
    return Check("Poller", lvl, "; ".join(teile + [txt]))


def check_abdeckung(con, now: int, anlauf_s: int = ANLAUF_S, tage: int = NORMAL_TAGE) -> Check | None:
    """Abdeckung des Open Interest je Coin gegen den eigenen Normalwert (Median der letzten 7 Tage ohne Anlaufzeiten)."""
    r = con.execute("SELECT MAX(ts) FROM coverage").fetchone()
    if not r or not r[0]:
        return None
    t1 = int(r[0])
    cov = sorted(con.execute("SELECT coin, ratio FROM coverage WHERE ts=?", (t1,)).fetchall())
    if not cov:
        return None
    try:
        u = con.execute("SELECT uptime FROM snapshot_meta WHERE ts=?", (t1,)).fetchone()
        hist = con.execute("SELECT c.coin, c.ratio FROM coverage c JOIN snapshot_meta s ON s.ts = c.ts WHERE c.ts >= ? AND c.ts < ? "
                           "AND s.uptime >= ?", (now - tage * 86_400, t1, anlauf_s)).fetchall()
    except sqlite3.Error:
        u, hist = None, []
    up = u[0] if u else None
    je: dict = {}
    for c_, v in hist:
        je.setdefault(c_, []).append(v)
    med = {c_: statistics.median(v) for c_, v in je.items() if len(v) >= NORMAL_MIN_N}
    txt = "  ".join(f"{c_} {v * 100:.0f}%" + (f" (üblich {med[c_] * 100:.0f}%)" if c_ in med else "") for c_, v in cov)
    if any(v < 0.25 for _c, v in cov):
        txt += "  -- unter 25 % ist die Heatmap kaum repräsentativ (Abfragebudget des Pollers, U218)"
    if up is not None and up < anlauf_s:
        return Check("Abdeckung", OK, f"Anlauf nach Neustart des Recorders (seit {up // 60} min): " + txt)
    schlecht = [f"{c_} {v * 100:.0f}% statt üblich {med[c_] * 100:.0f}%" for c_, v in cov if c_ in med and med[c_] >= 0.02 and v < 0.5 * med[c_]]
    schlecht += [f"{c_} {v * 100:.0f}% (noch kein Normalwert, unter 2 %)" for c_, v in cov if c_ not in med and v < 0.02]
    if schlecht:
        return Check("Abdeckung", WARN, "deutlich unter dem Normalwert: " + ", ".join(schlecht) + " · " + txt)
    return Check("Abdeckung", OK, txt)


def check_dashboard(url: str = DASH_URL, versuche: int = 2, warten_s: float = 5.0, timeout: float = 15.0) -> Check:
    """23.78: Antwortet das Dashboard auf seinem Port? Jede HTTP-Antwort zählt (auch 404 eines älteren Stands ohne /lebt). Keine Antwort
    (Zeitüberschreitung, Verbindung abgelehnt) zweimal im Abstand von `warten_s` -> KRITISCH. Gerufen nur, wenn systemd den Dienst als
    aktiv führt -- genau der Fall vom 23.10."""
    import urllib.error
    ziel = url.split("/")[2] if "//" in url else url
    grund = ""
    for i in range(versuche):
        try:
            with urllib.request.urlopen(url, timeout=timeout) as r:
                r.read(64)
            return Check("Dashboard", OK, f"antwortet auf {ziel}")
        except urllib.error.HTTPError:
            return Check("Dashboard", OK, f"antwortet auf {ziel}")
        except Exception as e:
            grund = type(e).__name__ + (f": {e.reason}" if getattr(e, "reason", None) else "")
        if i + 1 < versuche:
            time.sleep(warten_s)
    return Check("Dashboard", CRIT, f"{ziel} antwortet nicht ({grund}), obwohl der Dienst läuft -- hängt? Seit 23.78 startet systemd es nach "
                                    "15 min ohne Lebenszeichen neu")


def check_backup(bdir: str, now: int, oldest_bar, db: str | None = None) -> "Check | None":
    """
    Alter und Ergebnis der letzten Sicherung aus backup.json im Backup-Ordner (den trägt der Recorder in meta ein).
    23.95 (U243): Fehlt backup.json, weil das Laufwerk des Backup-Ordners nicht eingehängt ist (USB abgezogen, nach einem Neustart
    nicht eingehängt), sagt die Warnung das sofort -- bis 23.94 erst nach 26 h und nur „keines gefunden“. Dieselbe Prüfung wie vor
    jedem Backup (hl_recorder.backup_ziel_fehler); fehlt das Modul, bleibt es beim alten Text. Fehlt sie, weil der Ordner eben erst
    gewählt wurde (die erste Sicherung dort läuft oder folgt, höchstens 2 h nach der Wahl), ist das kein Alarm -- bis 23.94 warnte
    der Wächter nach jedem Wechsel bis zum Ende der ersten Sicherung.
    """
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            st = json.load(f)
        if st.get("ok"):
            age_h = (now - st["ts"]) / 3600
            return Check("Backup", OK if age_h < 26 else (WARN if age_h < 50 else CRIT),
                         f"vor {age_h:.1f} h, {st['size']/1e6:.0f} MB in {bdir}")
        return Check("Backup", WARN, f"fehlgeschlagen: {st.get('error')}")
    except (OSError, ValueError):
        pass
    try:
        import hl_recorder as _R
        zf = _R.backup_ziel_fehler(bdir)
    except Exception:
        _R = None
        zf = None
    if zf:
        return Check("Backup", WARN, zf.split(";")[0])
    if _R is not None:
        try:
            lf = _R.backup_laeuft(db, bdir) if db else None
            ein = _R.speicher_einstellung()
            neu_gewaehlt = (ein.get("backup_dir") and os.path.realpath(ein["backup_dir"]) == os.path.realpath(bdir)
                            and 0 <= now - float(ein.get("gesetzt") or 0) < 2 * 3600)
        except Exception:
            lf, neu_gewaehlt = None, False
        if lf:
            return Check("Backup", OK, f"erste Sicherung in {bdir} läuft ({lf.get('wer')})")
        if neu_gewaehlt:
            return Check("Backup", OK, f"Ordner vor {(now - float(ein.get('gesetzt') or 0)) / 60:.0f} min gewählt, erste Sicherung folgt ({bdir})")
    # kein Backup: harmlos in den ersten Stunden, danach eine Warnung wert
    if oldest_bar and now - oldest_bar > 26 * 3600:
        return Check("Backup", WARN, f"keines gefunden in {bdir} — Recorder-Log prüfen")
    return None


def run_checks(db: str, snapshot_sec: int, coins: list[str], dash_url: str | None = DASH_URL) -> list[Check]:
    out: list[Check] = []
    now = int(time.time())

    out.append(check_connectivity())

    # --- Datenbank
    if not os.path.exists(db):
        out.append(Check("Datenbank", CRIT, f"{db} fehlt"))
        return out
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        con.execute("PRAGMA temp_store=MEMORY")
    except sqlite3.Error as e:
        out.append(Check("Datenbank", CRIT, f"nicht lesbar: {e}"))
        return out

    def newest(table: str, where: str = "", args: tuple = ()) -> int | None:
        try:
            r = con.execute(f"SELECT MAX(ts) FROM {table} {where}", args).fetchone()
            return r[0]
        except sqlite3.Error:
            return None

    # --- Bars: der empfindlichste Indikator, es handelt praktisch immer jemand
    ts = newest("bars")
    if ts is None:
        out.append(Check("Kursdaten", CRIT, "keine Bars vorhanden"))
    else:
        age = (now - ts) // 60
        lvl = OK if age <= 10 else (WARN if age <= 30 else CRIT)
        out.append(Check("Kursdaten", lvl, f"jüngste Bar vor {age} min"))

    # --- Coins einzeln: erkennt Delistings und tote Einzelfeeds
    stale = []
    for c in coins:
        ts = newest("bars", "WHERE coin=?", (c,))
        if ts is None or now - ts > 3600:
            stale.append(c if ts else f"{c} (nie)")
    if stale:
        out.append(Check("Coin-Feeds", WARN, f"seit über 1 h still: {', '.join(stale)}"))
    else:
        out.append(Check("Coin-Feeds", OK, f"{len(coins)} Feeds aktiv"))

    # --- Heatmap-Snapshots
    ts = newest("heatmap")
    if ts is None:
        out.append(Check("Snapshots", WARN, "noch keine — normal in der Anlaufzeit"))
    else:
        age = now - ts
        lvl = OK if age <= snapshot_sec * 2 else (
            WARN if age <= snapshot_sec * 4 else CRIT)
        out.append(Check("Snapshots", lvl, f"letzter vor {age//60} min "
                                           f"(Takt {snapshot_sec//60} min)"))

    # --- Abdeckung des Open Interest: die ehrlichste Kennzahl für die Datenqualität -- seit 23.80 (U218) gegen den eigenen Normalwert
    try:
        c_ab = check_abdeckung(con, now)
        if c_ab:
            out.append(c_ab)
        ts = newest("ctx_bars")
        if ts is not None and now - ts > 900:
            out.append(Check("Marktkontext", WARN,
                             f"Markpreis-Feed seit {(now-ts)//60} min still"))
    except sqlite3.Error:
        pass

    # --- API-Budget: Gewicht der letzten Minute gegen das Hyperliquid-Limit
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN ('api_weight_1m','api_weight_budget','api_weight_limit')"))
        if "api_weight_1m" in rows:
            used = int(rows["api_weight_1m"]); deckel = int(rows.get("api_weight_budget", 1080)); limit = int(rows.get("api_weight_limit", 1200))
            pct = used / limit * 100
            # api_weight_budget ist seit 17.09. der EFFEKTIVE Deckel (90 %, thermisch skaliert); Auslastung
            # nahe 100 % des Deckels ist das Ziel. Gewarnt wird gegen das harte Limit.
            out.append(Check("API-Budget", OK if pct < 93 else (WARN if pct < 98 else CRIT),
                             f"{used} Gewicht/min = {used / max(deckel, 1) * 100:.0f} % des Deckels {deckel} ({pct:.0f} % des Limits {limit})"
                             + ("  — Begrenzer hält nicht: Deckel prüfen" if used > deckel * 1.05 else "")))
    except (sqlite3.Error, ValueError):
        pass

    # --- Rate-Limit-Treffer: schreibt der Recorder bei jedem Snapshot in meta
    try:
        r429 = con.execute("SELECT v FROM meta WHERE k='rate_limited'").fetchone()
        if r429:
            n429 = int(r429[0])
            out.append(Check("Rate-Limit", OK if n429 == 0 else (WARN if n429 < 50 else CRIT),
                             f"{n429} Antworten mit 429 seit Prozessstart"
                             + ("  — --polls-per-min senken" if n429 else "")))
    except (sqlite3.Error, ValueError):
        pass

    # --- Poller: läuft er, und wie viel des Snapshots fällt wegen Alters heraus (seit 23.80, U218: gegen den eigenen Normalwert; vorher
    #     das 90-%-Quantil über alle Adressen mit Position -- dauernd rot)
    try:
        c_po = check_poller(con, now)
        if c_po:
            out.append(c_po)
    except sqlite3.Error:
        pass

    # --- Binance: Open Interest wird im festen Takt geschrieben,
    #     Liquidationen sind sporadisch und taugen nicht als Lebenszeichen
    ts = newest("bnc_metrics")
    if ts is not None:
        age = (now - ts) // 60
        lvl = OK if age <= 25 else (WARN if age <= 60 else CRIT)
        out.append(Check("Binance", lvl, f"jüngster Wert vor {age} min"))

    # --- Backup-Alter: Ort aus meta (der Recorder trägt ihn ein), sonst neben der DB.
    #     Muss VOR con.close() laufen -- vorher stand es dahinter und lief still ins Leere.
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    try:
        r0 = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
        if r0 and r0[0]:
            bdir = r0[0]
    except sqlite3.Error:
        pass
    oldest_bar = None
    try:
        oldest_bar = con.execute("SELECT MIN(ts) FROM bars").fetchone()[0]
    except sqlite3.Error:
        pass
    con.close()
    c_bk = check_backup(bdir, now, oldest_bar, db)
    if c_bk:
        out.append(c_bk)

    # --- Plattenplatz
    free = shutil.disk_usage(os.path.dirname(os.path.abspath(db))).free / 1e9
    lvl = OK if free >= 5 else (WARN if free >= 1.5 else CRIT)
    out.append(Check("Speicherplatz", lvl, f"{free:.1f} GB frei"))

    # --- Uhrzeit: ohne NTP sind alle Zeitstempel wertlos
    try:
        r = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
                           capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip() != "yes":
            out.append(Check("Systemzeit", WARN, "nicht per NTP synchronisiert"))
        elif r.returncode == 0:
            out.append(Check("Systemzeit", OK, "synchronisiert"))
    except (OSError, subprocess.SubprocessError):
        pass

    # --- systemd-Dienste
    if shutil.which("systemctl"):
        dead = []
        for unit in ("hl-recorder", "hl-binance", "hl-dashboard"):
            r = subprocess.run(["systemctl", "is-enabled", unit],
                               capture_output=True, text=True)
            if r.stdout.strip() not in ("enabled", "enabled-runtime"):
                continue                     # nicht eingerichtet, also egal
            a = subprocess.run(["systemctl", "is-active", unit],
                               capture_output=True, text=True)
            if a.stdout.strip() != "active":
                dead.append(f"{unit} ({a.stdout.strip() or 'unbekannt'})")
        if dead:
            out.append(Check("Dienste", CRIT, "; ".join(dead)))
        else:
            out.append(Check("Dienste", OK, "alle aktiven Units laufen"))
        # 23.78: läuft das Dashboard laut systemd, muss es auch antworten
        if dash_url and not any(d.startswith("hl-dashboard ") for d in dead):
            r = subprocess.run(["systemctl", "is-active", "hl-dashboard"], capture_output=True, text=True)
            if r.stdout.strip() == "active":
                out.append(check_dashboard(dash_url))

    return out


def _probe_db(pfad: str, now: int, anteil_alt: float = 0.80, anteil_jetzt: float | None = None, n_jetzt: int | None = None,
              up_jetzt: int = 86_400, poller_vor: int | None = 3, jobs_kaputt: bool = False, cov_normal: dict | None = None,
              cov_jetzt: dict | None = None, tage: float = 7, neustart_alle: int = 144) -> None:
    """Erfundene Recorder-Datenbank für die Proben: snapshot_meta und coverage alle 10 min über `tage`, meta 'jobs' mit dem Adress-Poller."""
    import random
    rnd = random.Random(7)
    if os.path.exists(pfad):
        os.remove(pfad)
    con = sqlite3.connect(pfad)
    con.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    con.execute("CREATE TABLE snapshot_meta (ts INTEGER PRIMARY KEY, n_addresses INTEGER, n_with_pos INTEGER, n_positions INTEGER, "
                "n_stale_dropped INTEGER, age_median INTEGER, age_p90 INTEGER, backlog INTEGER, uptime INTEGER)")
    con.execute("CREATE TABLE coverage (ts INTEGER, coin TEXT, tracked_size REAL, oi REAL, ratio REAL, PRIMARY KEY (ts, coin))")
    cov_normal = cov_normal or {"BTC": 0.26, "ETH": 0.26, "HYPE": 0.25, "PAXG": 0.18, "XMR": 0.14, "ZEC": 0.20}
    t0 = now - int(tage * 86_400) // 600 * 600
    ts_liste = list(range(t0, now - 599, 600)) + [now - 30]
    start = t0 - 86_400
    for i, ts in enumerate(ts_liste):
        letzt = i == len(ts_liste) - 1
        if i % neustart_alle == 70 % neustart_alle:           # einmal am Tag ein Neustart des Recorders: 40 min Anlauf, schlechte Werte
            start = ts
        up = up_jetzt if letzt else ts - start
        anlauf = up < 2700
        a_ = anteil_jetzt if (letzt and anteil_jetzt is not None) else (0.97 if anlauf else anteil_alt + rnd.uniform(-0.03, 0.03))
        n_ges = 20_000
        n_pos = n_jetzt if (letzt and n_jetzt is not None) else int(n_ges * (1 - a_))
        con.execute("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", (ts, 319_000, 9_300, n_pos, n_ges - n_pos, 30_000, 60_000, 70_000, up))
        for c_, v in cov_normal.items():
            r = (cov_jetzt or {}).get(c_, v) if letzt else (v * 0.4 if anlauf else v + rnd.uniform(-0.01, 0.01))
            con.execute("INSERT INTO coverage VALUES (?,?,?,?,?)", (ts, c_, 1.0, 1.0, r))
    if poller_vor is not None:
        jobs = {"Snapshots": {"last": now - 30, "next": now + 570, "takt": 600, "info": "x" * 100, "ok": True},
                "Adress-Poller": {"last": now - poller_vor, "next": now + 5, "takt": 5, "info": "23/23 Adressen je Runde", "ok": True}}
        for k in range(30):
            jobs[f"Aufgabe {k}"] = {"last": now - 100, "info": "y" * 110, "ok": True}
        js = json.dumps(jobs)
        con.execute("INSERT INTO meta VALUES ('jobs', ?)", (js[:4000] if jobs_kaputt else js,))
    con.commit(); con.close()


def selbsttest() -> bool:
    """23.78: Dashboard-Prüfung -- antwortet (200), älterer Stand ohne /lebt (404 zählt als Antwort), hängt (gebunden, nimmt nichts an ->
    KRITISCH nach zwei Versuchen), Port zu (abgelehnt -> KRITISCH). Server in diesem Prozess, nur 127.0.0.1.
    23.80 (U218): Poller und Abdeckung gegen den Normalwert -- Nulltest (Dauerzustand wie am 23.10.: 80 % zu alt, Abdeckung 14–26 %) ->
    ok; Positivkontrollen: Poller steht -> KRITISCH, Snapshot leer -> KRITISCH, 26 Prozentpunkte schlechter -> WARNUNG, ein Coin unter der
    Hälfte seines Normalwerts -> WARNUNG; Anlauf nach Neustart -> ok mit Hinweis, Neustart-Schleife -> WARNUNG; ohne Verlauf; Normalwert ohne
    Anlaufzeiten (Neustart alle 2 h); abgeschnittenes meta 'jobs'."""
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/lebt":
                b = b"ok 1 2"
                self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            else:
                self.send_error(404)

        def log_message(self, *a):
            pass
    pruef = []
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        c1 = check_dashboard(f"http://127.0.0.1:{port}/lebt", 2, 0.1, 2)
        c2 = check_dashboard(f"http://127.0.0.1:{port}/gibt-es-nicht", 2, 0.1, 2)
        srv.shutdown()                                           # gebunden, nimmt nichts an -- wie am 23.10.
        t0 = time.time(); c3 = check_dashboard(f"http://127.0.0.1:{port}/lebt", 2, 0.1, 0.5); d3 = time.time() - t0
        srv.server_close()
        s_ = socket.socket(); s_.bind(("127.0.0.1", 0)); frei = s_.getsockname()[1]; s_.close()
        c4 = check_dashboard(f"http://127.0.0.1:{frei}/lebt", 2, 0.1, 0.5)
    finally:
        try:
            srv.server_close()
        except OSError:
            pass
    pruef.append(("Dashboard antwortet (200) -> ok", c1.level == OK, c1.detail))
    pruef.append(("älterer Stand ohne /lebt (404) zählt als Antwort -> ok", c2.level == OK, c2.detail))
    pruef.append(("Dashboard hängt (Port gebunden, keine Antwort) -> KRITISCH nach zwei Versuchen", c3.level == CRIT and d3 >= 1.0,
                  f"{c3.detail[:90]} ({d3:.1f} s)"))
    pruef.append(("Port zu (Verbindung abgelehnt) -> KRITISCH", c4.level == CRIT, c4.detail[:90]))
    # 23.80 (U218): Poller und Abdeckung
    import tempfile
    d = tempfile.mkdtemp(prefix="hl_wd_")
    try:
        now = int(time.time()) // 60 * 60
        pfad = os.path.join(d, "probe.db")

        def lauf(**kw):
            _probe_db(pfad, now, **kw)
            con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True)
            try:
                return check_poller(con, now), check_abdeckung(con, now)
            finally:
                con.close()
        po, ab = lauf()
        pruef.append(("Nulltest Dauerzustand (80 % zu alt, Abdeckung 14–26 %): Poller ok, Abdeckung ok, Text nennt das Übliche",
                      po.level == OK and ab.level == OK and "üblich 80 %" in po.detail and "XMR 14% (üblich 14%)" in ab.detail
                      and "läuft" in po.detail and "U218" in po.detail, f"{po.detail[:80]} | {ab.detail[:60]}"))
        po, _ab = lauf(poller_vor=20 * 60)
        pruef.append(("Poller steht seit 20 min -> KRITISCH", po.level == CRIT and "steht" in po.detail, po.detail[:80]))
        po, _ab = lauf(anteil_jetzt=1.0, n_jetzt=0)
        pruef.append(("Snapshot leer (alle Positionen zu alt) -> KRITISCH", po.level == CRIT and "leer" in po.detail, po.detail[:80]))
        po, _ab = lauf(anteil_alt=0.60, anteil_jetzt=0.86)
        po2, _ab = lauf(anteil_jetzt=0.98)
        po3, _ab = lauf(anteil_jetzt=0.92)
        pruef.append(("26 Prozentpunkte mehr zu alte Positionen als üblich (60 % -> 86 %) -> WARNUNG; 98 % -> WARNUNG; 92 % bei üblich 80 % -> ok",
                      po.level == WARN and po2.level == WARN and po3.level == OK, f"{po.detail[-60:]} | {po2.level} | {po3.level}"))
        _po, ab = lauf(cov_jetzt={"XMR": 0.04})
        pruef.append(("Abdeckung XMR 4 % statt üblich 14 % -> WARNUNG mit Coin", ab.level == WARN and "XMR 4% statt üblich 14%" in ab.detail, ab.detail[:90]))
        po, ab = lauf(up_jetzt=10 * 60, anteil_jetzt=0.99, cov_jetzt={"BTC": 0.05, "XMR": 0.02})
        pruef.append(("Anlauf 10 min nach Neustart (schlechte Werte) -> beide ok mit Hinweis", po.level == OK and ab.level == OK
                      and "Anlauf" in po.detail and "Anlauf" in ab.detail, f"{po.detail[:60]} | {ab.detail[:50]}"))
        po, ab = lauf(tage=0.1, cov_jetzt={"BTC": 0.20, "XMR": 0.01})
        pruef.append(("Ohne Verlauf (neu eingerichtet): Normalwert erst ab 6 h; Abdeckung 1 % -> WARNUNG, 20 % -> kein Alarm",
                      "ab 6 h" in po.detail and ab.level == WARN and "XMR 1%" in ab.detail and "BTC 20%" not in ab.detail.split(" · ")[0],
                      f"{po.level} {po.detail[:60]} | {ab.detail[:70]}"))
        po, ab = lauf(neustart_alle=3, up_jetzt=10 * 60)
        pruef.append(("Neustart-Schleife (alle 30 min, jetzt im Anlauf) -> WARNUNG trotz Anlauf; einmaliger Neustart -> ok (siehe Anlauf)",
                      po.level == WARN and "gestartet" in po.detail and recorder_starts([(1000, 0, 0, 0, 100), (1600, 0, 0, 0, 699),
                                                                                         (1650, 0, 0, 0, 30)], 2000) == 2,
                      po.detail[:90]))
        po, ab = lauf(neustart_alle=12)
        pruef.append(("Normalwert ohne Anlaufzeiten: Neustart alle 2 h (5 von 12 Snapshots im Anlauf) -> üblich bleibt 80 % und 26 %",
                      po.level == OK and ab.level == OK and "(üblich 80 %)" in po.detail and "BTC 26% (üblich 26%)" in ab.detail,
                      f"{po.detail[po.detail.find('Snapshot'):][:70]} | {ab.detail[:40]}"))
        po, _ab = lauf(jobs_kaputt=True, poller_vor=900)
        pruef.append(("meta 'jobs' bei 4.000 Zeichen abgeschnitten: Poller-Runde trotzdem gelesen (steht -> KRITISCH)", po.level == CRIT,
                      po.detail[:80]))
    finally:
        import shutil as _sh
        _sh.rmtree(d, ignore_errors=True)
    # 23.95 (U243): Backup-Prüfung -- Laufwerk nicht eingehängt sofort, sonst wie bisher
    d = tempfile.mkdtemp(prefix="hl_wd_bk_")
    try:
        import hl_recorder as _R
        now = int(time.time())
        ok_dir = os.path.join(d, "ok"); os.makedirs(ok_dir)
        with open(os.path.join(ok_dir, "backup.json"), "w") as f:
            json.dump({"ok": True, "ts": now - 3600, "size": 5e9}, f)
        c_ok = check_backup(ok_dir, now, now - 30 * 86400)
        leer = os.path.join(d, "leer"); os.makedirs(leer)
        c_jung = check_backup(leer, now, now - 3600)
        c_alt = check_backup(leer, now, now - 30 * 86400)
        echt_w = _R.BACKUP_MEDIEN_WURZELN
        _R.BACKUP_MEDIEN_WURZELN = (os.path.join(d, "medien") + "/",)
        try:
            c_usb = check_backup(os.path.join(d, "medien", "usb", "hl_backup"), now, now - 3600)
        finally:
            _R.BACKUP_MEDIEN_WURZELN = echt_w
        pruef.append(("Backup vor 1 h -> ok", c_ok is not None and c_ok.level == OK, c_ok.detail if c_ok else "—"))
        pruef.append(("keine backup.json, Daten jünger als 26 h -> keine Meldung; älter -> WARNUNG „keines gefunden“",
                      c_jung is None and c_alt is not None and c_alt.level == WARN and "keines gefunden" in c_alt.detail,
                      f"{c_jung} | {c_alt.detail[:60] if c_alt else '—'}"))
        pruef.append(("Laufwerk des Backup-Ordners nicht eingehängt -> WARNUNG sofort (auch in den ersten 26 h), mit Grund",
                      c_usb is not None and c_usb.level == WARN and "nicht eingehängt" in c_usb.detail, c_usb.detail[:90] if c_usb else "—"))
        # eben gewählter Ordner: erste Sicherung läuft (Sperre gehalten) bzw. folgt (gewählt vor 10 min) -> ok; vor 3 h -> WARNUNG
        neu_ = os.path.join(d, "neu"); os.makedirs(neu_)
        dbp = os.path.join(d, "hl_liq.db")
        sp_ = _R.BackupSperre(dbp, neu_, "Test Wächter")
        sp_.versuchen()
        try:
            c_lauf = check_backup(neu_, now, now - 30 * 86400, dbp)
        finally:
            sp_.freigeben()
        sp_json = os.path.join(d, "speicherorte.json")
        echt_sp = _R.speicher_pfad
        _R.speicher_pfad = lambda: sp_json
        try:
            with open(sp_json, "w") as f:
                json.dump({"backup_dir": neu_, "gesetzt": now - 600}, f)
            c_gew = check_backup(neu_, now, now - 30 * 86400, dbp)
            with open(sp_json, "w") as f:
                json.dump({"backup_dir": neu_, "gesetzt": now - 3 * 3600}, f)
            c_spaet = check_backup(neu_, now, now - 30 * 86400, dbp)
        finally:
            _R.speicher_pfad = echt_sp
        pruef.append(("Ordner eben gewählt: erste Sicherung läuft -> ok; gewählt vor 10 min -> ok („folgt“); vor 3 h ohne Sicherung -> WARNUNG",
                      c_lauf is not None and c_lauf.level == OK and "läuft" in c_lauf.detail and c_gew is not None and c_gew.level == OK
                      and "folgt" in c_gew.detail and c_spaet is not None and c_spaet.level == WARN and "keines gefunden" in c_spaet.detail,
                      f"{c_lauf.detail[:40] if c_lauf else '—'} | {c_gew.detail[:40] if c_gew else '—'} | {c_spaet.detail[:30] if c_spaet else '—'}"))
    finally:
        import shutil as _sh
        _sh.rmtree(d, ignore_errors=True)
    alles = all(p[1] for p in pruef)
    print("hl_watchdog -- Selbsttest: Dashboard-Prüfung (23.78), Poller und Abdeckung gegen den Normalwert (23.80), Backup (23.95)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<70} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


# ---------------------------------------------------------------------------
# Alarmsteuerung
# ---------------------------------------------------------------------------

@dataclass
class AlarmState:
    level: int = OK
    since: float = 0.0
    last_notify: float = 0.0
    last_beep: float = 0.0
    history: list = field(default_factory=list)


def report(checks: list[Check], quiet: bool = False) -> int:
    worst = max((c.level for c in checks), default=OK)
    if not quiet:
        print(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} — Gesamtstatus: {LABEL[worst]}")
        print("-" * 62)
        for c in checks:
            mark = {OK: "  ok   ", WARN: "  !    ", CRIT: "  XXX  "}[c.level]
            print(f"{mark}{c.name:<16}{c.detail}")
    return worst


def main() -> None:
    p = argparse.ArgumentParser(description="Wächter mit Alarm")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"])
    p.add_argument("--snapshot-sec", type=int, default=600)
    p.add_argument("--interval", type=int, default=300, help="Prüftakt in Sekunden")
    p.add_argument("--no-sound", action="store_true",
                   help="Tonausgabe abschalten")
    p.add_argument("--alarm-interval", type=int, default=120,
                   help="Abstand wiederholter Alarmtöne in Sekunden")
    p.add_argument("--buzzer", type=int, metavar="GPIO",
                   help="optional: GPIO-Pin eines aktiven Summers")
    p.add_argument("--led", action="store_true", help="ACT-LED blinken lassen")
    p.add_argument("--ntfy", help="ntfy.sh-Topic oder vollständige URL")
    p.add_argument("--heartbeat", help="URL für den Totmannschalter, z. B. hc-ping.com/UUID")
    p.add_argument("--renotify", type=int, default=3600,
                   help="Abstand wiederholter Meldungen in Sekunden")
    p.add_argument("--once", action="store_true")
    p.add_argument("--json", action="store_true", help="Ausgabe als JSON")
    p.add_argument("--test-alarm", action="store_true")
    p.add_argument("--dashboard-url", default=DASH_URL, help="Lebenszeichen-Seite des Dashboards (leer: nicht prüfen)")
    p.add_argument("--selbsttest", action="store_true", help="23.78: Proben der Dashboard-Prüfung")
    args = p.parse_args()
    if args.selbsttest:
        sys.exit(0 if selbsttest() else 1)

    sound = Sound(not args.no_sound)
    if not (args.once and args.json):
        # In der JSON-Ausgabe darf nichts vor dem Dokument stehen
        print(f"Tonausgabe: {sound.why}")
    quiet = bool(args.once and args.json)
    buzzer = Buzzer(args.buzzer, quiet)
    led = StatusLed(args.led, quiet)

    if args.test_alarm:
        print("Warnung — aufsteigender Zweiklang …")
        sound.play(False); buzzer.beep(2); led.blink(2)
        time.sleep(1)
        print("Kritisch — Sirene …")
        sound.play(True); buzzer.beep(5, 0.4, 0.15); led.blink(5, .3, .1)
        if not sound.available():
            print("\nEs kam kein Ton: " + sound.why)
        ok = notify(args.ntfy, "Wächter-Test", "Wenn du das liest, funktioniert ntfy.")
        print(f"ntfy: {'zugestellt' if ok else 'nicht zugestellt oder nicht gesetzt'}")
        print(f"Heartbeat: {'gesendet' if heartbeat(args.heartbeat) else 'nicht gesetzt'}")
        return

    if args.once:
        checks = run_checks(args.db, args.snapshot_sec, args.coins, args.dashboard_url or None)
        if args.json:
            print(json.dumps({"status": LABEL[report(checks, quiet=True)],
                              "checks": [{"name": c.name, "level": LABEL[c.level],
                                          "detail": c.detail} for c in checks]},
                             indent=2, ensure_ascii=False))
        else:
            report(checks)
        sys.exit(report(checks, quiet=True))

    st = AlarmState()
    print(f"Wächter läuft, Prüftakt {args.interval//60} min. Strg-C beendet.")
    if not sound.available() and not args.buzzer and not args.led and not args.heartbeat:
        print("Hinweis: kein Signalgeber aktiv — es wird nur geloggt.")

    try:
        while True:
            checks = run_checks(args.db, args.snapshot_sec, args.coins, args.dashboard_url or None)
            worst = report(checks)
            bad = [c for c in checks if c.level >= WARN]
            now = time.time()

            vorher = st.level          # VOR der Zuweisung merken: Die Entwarnung unten
            if worst != st.level:          # verglich sonst gegen den bereits neu gesetzten
                st.level, st.since = worst, now     # Wert und konnte nie zutreffen.
                st.last_notify = 0.0          # Zustandswechsel meldet sofort

            if worst >= WARN:
                # Lokaler Signalgeber im eingestellten Takt, solange die
                # Störung anhält. Warnungen seltener als kritische Zustände.
                every = args.alarm_interval if worst == CRIT else args.alarm_interval * 4
                if now - st.last_beep >= every:
                    sound.play(worst == CRIT)
                    buzzer.beep(5 if worst == CRIT else 2,
                                0.4 if worst == CRIT else 0.2)
                    led.blink(5 if worst == CRIT else 2)
                    st.last_beep = now

                if now - st.last_notify >= args.renotify:
                    msg = "\n".join(f"{LABEL[c.level]}: {c.name} — {c.detail}"
                                    for c in bad)
                    dur = int((now - st.since) // 60)
                    if notify(args.ntfy, f"Recorder: {LABEL[worst]}",
                              f"{msg}\n\nZustand seit {dur} min.",
                              "urgent" if worst == CRIT else "high"):
                        st.last_notify = now

            # Heartbeat: bei kritischem Zustand als Fehlschlag melden,
            # damit der externe Dienst sofort und nicht erst nach Ablauf warnt
            heartbeat(args.heartbeat, failed=(worst == CRIT))

            if worst == OK and vorher != OK:
                notify(args.ntfy, "Recorder: wieder in Ordnung",
                       "Alle Prüfungen bestanden.", "default")

            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nWächter beendet.")


if __name__ == "__main__":
    main()
