#!/usr/bin/env python3
"""
Hebel-Studie (U142): Positionierung und Hebel gegen Spot -- Binance-Top-Trader, Konten und Perp-Anteil vor Liquidationswellen
(Version 2026-09-23.64).

Regeln vorab in KONZEPT_Hebel.md (09.10.2026, vor jedem Lauf auf echten Daten und vor dem Ergebnis von U141). Inhalt:
  - eigene Datei hebel.db neben der Hauptdatenbank (Tabellen hb_metrics, hb_kerzen, hb_dateien, hb_liq, hb_buch, hb_meta; Schreiben
    nur mit BEGIN IMMEDIATE): das Binance-Archiv data.binance.vision -- „metrics“ (OI, Top-Trader, Konten, Taker; eine Zeile je
    Stunde) für BTC, ETH, ZEC, XMR, HYPE ab 01.09.2020 und die Tageskerzen der Spot-, USDⓈ-M- und COIN-M-Märkte ab 2020; dazu eine
    Sicherung der Bybit/OKX-Liquidationen und der Binance-Buchtiefe aus hl_liq.db (nur lesend), bevor deren Vorhaltefrist sie löscht;
  - Daten-Takt im Dashboard-Prozess (lädt im Hintergrund, aus mit HL_HEBEL=0), Laden von Hand, Debug-Bericht;
  - Studie: H1 Konten ≥ 3 vor Rücksetzern, H2 Top-Trader-Regel der Konfluenz und die Richtung des nächsten Tages, H3 Perp-Anteil
    ≥ 95 % und H4 Perp-Anteil im obersten Zehntel vor Liquidationswellen; Nullmodelle Vorzeichen-Surrogate (H1, H2, wie U141 Teil C)
    und Zeitverschiebung des Signals um 30–365 Tage (H3, H4); Holm, beide Hälften, Kalender-Blockbootstrap; beschreibende Teile;
    Abgleich Archiv gegen die Live-Reihe; Stand heute.
Seit 23.64 (nach dem ersten Lauf, KONZEPT_Hebel.md 12.3): Dateischlüssel der Tageskerzen mit Markt (bis 23.63 galten die Spotpaare
BTC/ETH gegen USDT, USDC, BUSD als geladen, weil das gleichnamige Perp schon da war -- H3/H4 blieben ohne Daten), einmalige Umstellung
der alten Einträge; beschreibend ergänzt: H1 mit dem Stand 1 h und 24 h früher und H1 geschichtet nach der Rendite der 7 Tage davor.
Nur Bericht. Berührt weder Prognose, Fusion, v3, Kaskaden, Konfluenz noch Labor; hl_liq.db wird nur gelesen.

  python3 hl_hebel.py --studie --db <hl_liq.db>   Debug-Bericht „★ Hebel: Positionierung und Hebel gegen Spot (U142)“
  python3 hl_hebel.py --laden --db <hl_liq.db>    Historie laden bzw. ergänzen (höchstens --budget Sekunden, Standard 600)
  python3 hl_hebel.py --selbsttest                Parser, Laden ohne Netz, Sicherung, Kausalität, Ereignisse, Nulltests,
                                                  Positivkontrollen (ohne Netz)
  python3 hl_hebel.py --s5 --db <hl_liq.db>       23.68 (U158): CryptoQuant-Anteil der Derivate (BTC, alle Börsen) und S5
  python3 hl_hebel.py --cq-abruf --db <hl_liq.db> 23.68 (U158): CryptoQuant jetzt abrufen

23.68 (U158, KONZEPT_Hebel.md 14): Abruf der CryptoQuant-Tagesvolumen (Spot und Perpetual, all_exchange, in BTC) einmal am Tag nach
01:00 UTC mit dem kostenlosen Schlüssel des Nutzers (Feld im Tab „Daten“ oder accesstokens.json -> cryptoquant.api_key; der Schlüssel
steht in keinem Text), Archiv mit Abrufzeit (hb_cq), Kennzahl D = Perps ÷ (Perps + Spot), Prüfung S5 (D ≥ 0,95 vor Liquidationswellen,
zirkuläre Verschiebung 30 … L − 30 Tage; die erste prüfbare Auswertung ist das Urteil). Wirkt auf nichts.
"""
from __future__ import annotations

import argparse
import calendar
import csv
import io
import json
import math
import os
import re
import sqlite3
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

import hl_regime as RG
import hl_swing as SW
import hl_zyklus as ZY

VERSION_MODUL = "2026-09-23.68"
TAG = 86400
COINS = ("BTC", "ETH", "ZEC", "XMR", "HYPE")              # Positionierung (H1, H2): alle, gepoolt
COINS_ANTEIL = ("BTC", "ETH")                              # Perp-Anteil (H3, H4): dauerhaft am Binance-Spot gelistet
START_METRICS = "2020-09-01"
START_KERZEN = "2020-01"                                   # erster Monat der Tageskerzen
ARCHIV = "https://data.binance.vision/data"
SPOT_QUOTES = ("USDT", "FDUSD", "USDC", "BUSD", "TUSD")
PERP_QUOTES = ("USDT", "USDC", "BUSD")
KONTRAKT_USD = {"BTC": 100.0, "ETH": 10.0}                 # COIN-M: USD je Kontrakt
H_HAUPT = 7                                                # Horizont H1, H3, H4 (Tage)
H_RICHTUNG = 1                                             # Horizont H2 (Tage)
H_RR_BESCHR = (3, 14)
H_RICHTUNG_BESCHR = (3, 7)
K_KURS = 1.5
K_OI = 1.5
OI_ABDECKUNG = 0.80                                        # Anteil der Stunden im Fenster mit OI
SNAPSHOT_MAX_ALTER = 7200                                  # Verhältnisse/OI zum Tagesende: höchstens 2 h alt
PERZ_FENSTER, PERZ_MIN = 90, 60
SCHWELLE_KONTEN = 3.0
TOP_LONG, TOP_SHORT = 1.5, 0.67
ANTEIL_ABS = 0.95
ANTEIL_PZ = 0.90
PZ_HOCH, PZ_TIEF = 0.90, 0.10
VORLAUF = 60                                               # erste bewertete Tage je Reihe (σ)
N_SURR = 1000
SHIFT_MIN, SHIFT_MAX = 30, 365
N_BOOT = 1000
BLOCK = 60
ALPHA = 0.05
SAAT = 142
CHUNK = 250
MIN_SIGNALTAGE, MIN_EPISODEN, MIN_OHNE = 30, 3, 30
# Laden
PAUSE = 0.35
LADE_BUDGET_TAKT = 240.0
TAKT_S = 300
ENDE_404 = 30                                              # so viele Tage in Folge ohne Datei = vor der Listung
FRISCH_TAGE = 2                                            # jüngere fehlende Tage werden später erneut versucht
WIEDER_S = 3600                                            # frühestens so oft je Datei erneut versuchen
SICHERUNG_S = 3600
SICHERUNG_ZEILEN = 50_000
HAUPT = (("H1", "Konten ≥ 3 vor einem Rücksetzer in 7 Tagen"),
         ("H2", "Top-Trader-Regel der Konfluenz (≥ 1,5 Kauf, ≤ 0,67 Verkauf) und die Richtung des nächsten Tages"),
         ("H3", "Perp-Anteil ≥ 95 % vor einer Liquidationswelle in 7 Tagen"),
         ("H4", "Perp-Anteil im obersten Zehntel der 90 Tage vor einer Liquidationswelle in 7 Tagen"))
KENNZAHLEN = (("konten", "Konten (alle)"), ("top_konten", "Top-Trader nach Konten"), ("top_pos", "Top-Trader nach Positionen"),
              ("taker", "Taker Kauf/Verkauf"))
SCHEMA_DATEIEN = "2"                                       # hb_dateien: Kerzen unter „markt:symbol“ (seit 23.64)
# nach dem ersten Lauf ergänzt (10.10.2026, KONZEPT_Hebel.md 12.3), beschreibend, kein Urteil:
STAND_FRUEHER = (("v1h", 3600, "1 h früher"), ("v24h", TAG, "24 h früher"))
R7_GRENZEN = (-1.0, -1.0 / 3.0, 1.0 / 3.0, 1.0)           # Klassen der Rendite der 7 Tage davor in σ·√7 (5 Klassen)


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    return RG._de(x, nd, vz)


def _pz(p) -> str:
    return RG._pz(p)


def _dt(tag) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(tag) * TAG)) if tag is not None else "—"


def _pr(x, nd: int = 1, vz: bool = False) -> str:
    if x is None or not np.isfinite(x):
        return "—"
    return _de(float(x) * 100.0, nd, vz) + " %"


def _tausend(n) -> str:
    return f"{int(n):,}".replace(",", ".")


def _r(x, nd: int = 2) -> str:
    return _de(x, nd) if x is not None and np.isfinite(x) else "—"


def _mio(x) -> str:
    if x is None or not np.isfinite(x):
        return "—"
    return _de(x / 1e9, 2) + " Mrd" if abs(x) >= 1e9 else _de(x / 1e6, 1) + " Mio"


# ================================================================================================ Kalender

def tag_von(datum: str) -> int:
    return calendar.timegm(time.strptime(datum, "%Y-%m-%d")) // TAG


def datum_von(tag: int) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(int(tag) * TAG))


def monat_von(tag: int) -> str:
    return time.strftime("%Y-%m", time.gmtime(int(tag) * TAG))


def monat_plus(m: str, k: int) -> str:
    j, mo = int(m[:4]), int(m[5:7]) - 1 + k
    return f"{j + mo // 12:04d}-{mo % 12 + 1:02d}"


def monate(von: str, bis: str) -> list:
    out, m = [], von
    while m <= bis:
        out.append(m); m = monat_plus(m, 1)
    return out


def monatstage(m: str) -> list:
    t0 = tag_von(m + "-01"); t1 = tag_von(monat_plus(m, 1) + "-01")
    return list(range(t0, t1))


# ================================================================================================ Datenhaltung

SCHEMA = """
CREATE TABLE IF NOT EXISTS hb_metrics (coin TEXT, ts INTEGER, oi REAL, oi_usd REAL, top_konten REAL, top_pos REAL, konten REAL,
    taker REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS hb_kerzen (markt TEXT, symbol TEXT, tag INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, v_usd REAL,
    taker_usd REAL, n INTEGER, PRIMARY KEY (markt, symbol, tag)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS hb_dateien (art TEXT, symbol TEXT, periode TEXT, status INTEGER, zeilen INTEGER, ts INTEGER,
    PRIMARY KEY (art, symbol, periode)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS hb_liq (exchange TEXT, uid TEXT, ts INTEGER, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL,
    PRIMARY KEY (exchange, uid)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_hb_liq_ts ON hb_liq(ts);
CREATE TABLE IF NOT EXISTS hb_buch (ts INTEGER, coin TEXT, mid REAL, bid5 REAL, ask5 REAL, bid25 REAL, ask25 REAL, bid100 REAL,
    ask100 REAL, PRIMARY KEY (ts, coin)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS hb_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS hb_cq (reihe TEXT, tag INTEGER, abgerufen INTEGER, wert REAL, PRIMARY KEY (reihe, tag, abgerufen)) WITHOUT ROWID;
"""


def hebel_pfad(db: str) -> str:
    """hebel.db liegt neben der Hauptdatenbank (wie swing.db); HL_HEBEL_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_HEBEL_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "hebel.db")


def verbinden(pfad: str) -> sqlite3.Connection:
    """Schreibverbindung: Autocommit, jede Schreibtransaktion mit BEGIN IMMEDIATE (Projektregel)."""
    con = sqlite3.connect(pfad, timeout=30, isolation_level=None)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)
    _umstellen(con)
    return con


def _dk(markt: str, symbol: str) -> str:
    """Schlüssel einer Kerzendatei in hb_dateien: Markt und Symbol (BTCUSDT gibt es als Spotpaar und als USDⓈ-M-Perp)."""
    return f"{markt}:{symbol}"


def _umstellen(con) -> None:
    """
    Einmalig (23.64): Bis 23.63 standen Kerzendateien ohne Markt in hb_dateien. Bei gleichem Namen (BTCUSDT, BTCUSDC, BTCBUSD und
    dieselben für ETH: Spot und USDⓈ-M) hat immer das erste Symbol in symbole() geladen -- die Laderunde arbeitet in dieser
    Reihenfolge, und der gemeinsame Schlüssel ließ das zweite als „schon da“ aus. Alte Einträge bekommen deshalb den Markt des
    ersten gleichnamigen Symbols; danach k_fertig = 0, und der Takt lädt die ausgelassenen Spotpaare nach.
    """
    if meta(con, "schema_dateien") == SCHEMA_DATEIEN:
        return
    erst: dict = {}
    for markt, symbol, _ in symbole():
        erst.setdefault(symbol, markt)
    con.execute("BEGIN IMMEDIATE")
    try:
        r = con.execute("SELECT v FROM hb_meta WHERE k='schema_dateien'").fetchone()
        if r and r[0] == SCHEMA_DATEIEN:                       # ein anderer Prozess war schneller
            con.execute("COMMIT")
            return
        n = 0
        for (s,) in con.execute("SELECT DISTINCT symbol FROM hb_dateien WHERE art IN ('kerzen_m', 'kerzen_t') AND instr(symbol, ':') = 0").fetchall():
            if s in erst:
                n += con.execute("UPDATE OR REPLACE hb_dateien SET symbol = ? WHERE art IN ('kerzen_m', 'kerzen_t') AND symbol = ?",
                                 (_dk(erst[s], s), s)).rowcount
        con.executemany("INSERT OR REPLACE INTO hb_meta VALUES (?,?)",
                        [("schema_dateien", SCHEMA_DATEIEN), ("k_fertig", "0"), ("umgestellt", f"{int(time.time())}:{n}")])
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def _schreiben(con, sql: str, zeilen: list) -> None:
    if not zeilen:
        return
    con.execute("BEGIN IMMEDIATE")
    try:
        con.executemany(sql, zeilen)
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def meta(con, k: str, standard=None):
    try:
        r = con.execute("SELECT v FROM hb_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    return r[0] if r and r[0] is not None else standard


def meta_setzen(con, paare: dict) -> None:
    _schreiben(con, "INSERT OR REPLACE INTO hb_meta VALUES (?,?)", [(k, str(v)) for k, v in paare.items()])


def _lesen(pfad: str):
    if not pfad or not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)


# ================================================================================================ Netz und Parser

UA = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0 (hebel)"}


def _holen(url: str, timeout: int = 30) -> tuple:
    """("ok", Inhalt, "") | ("404", None, "") | ("fehler", None, Text) -- wirft nie."""
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return "ok", r.read(), ""
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return "404", None, ""
        return "fehler", None, f"HTTP {e.code}"
    except Exception as e:
        return "fehler", None, f"{type(e).__name__}: {e}"[:160]


QUELLE = {"holen": _holen}                                  # austauschbar für den Selbsttest (Laden ohne Netz)


def url_metrics(coin: str, tag: int) -> str:
    return f"{ARCHIV}/futures/um/daily/metrics/{coin}USDT/{coin}USDT-metrics-{datum_von(tag)}.zip"


def url_kerzen(markt: str, symbol: str, periode: str) -> str:
    basis = {"spot": "spot", "um": "futures/um", "cm": "futures/cm"}[markt]
    art = "monthly" if len(periode) == 7 else "daily"
    return f"{ARCHIV}/{basis}/{art}/klines/{symbol}/1d/{symbol}-1d-{periode}.zip"


def _csv_aus_zip(roh: bytes) -> str | None:
    try:
        with zipfile.ZipFile(io.BytesIO(roh)) as z:
            namen = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not namen:
                return None
            return z.read(namen[0]).decode("utf-8", "replace")
    except (zipfile.BadZipFile, KeyError, OSError, ValueError):
        return None


def _zahl(s) -> float:
    try:
        x = float(str(s).strip())
    except (TypeError, ValueError):
        return float("nan")
    return x if math.isfinite(x) else float("nan")


def _verh(s) -> float:
    """Verhältnis: nur 0 < x < 1000, sonst NaN."""
    x = _zahl(s)
    return x if 0.0 < x < 1000.0 else float("nan")


def _pos(s) -> float:
    x = _zahl(s)
    return x if x > 0 else float("nan")


def _n(x):
    return None if x is None or not math.isfinite(x) else float(x)


def metrics_parse(roh: bytes, coin: str) -> list:
    """
    Tagesdatei „metrics“ (ZIP mit CSV, 5-min-Zeilen, Kopfzeile create_time,symbol,sum_open_interest,...) -> je Stunde die früheste
    Zeile: (coin, ts, oi_coins, oi_usd, top_konten, top_pos, konten, taker); fehlende Werte NULL.
    """
    text = _csv_aus_zip(roh)
    if text is None:
        return []
    beste: dict = {}
    for z in csv.DictReader(io.StringIO(text)):
        zeit = (z.get("create_time") or "").strip()[:19]
        try:
            ts = calendar.timegm(time.strptime(zeit, "%Y-%m-%d %H:%M:%S"))
        except ValueError:
            continue
        werte = (_pos(z.get("sum_open_interest")), _pos(z.get("sum_open_interest_value")), _verh(z.get("count_toptrader_long_short_ratio")),
                 _verh(z.get("sum_toptrader_long_short_ratio")), _verh(z.get("count_long_short_ratio")),
                 _verh(z.get("sum_taker_long_short_vol_ratio")))
        if not any(math.isfinite(w) for w in werte):
            continue
        stunde = ts // 3600
        if stunde not in beste or ts < beste[stunde][0]:
            beste[stunde] = (ts, werte)
    return [(coin, ts, *(_n(w) for w in werte)) for _, (ts, werte) in sorted(beste.items())]


def kerzen_parse(roh: bytes, markt: str, symbol: str, coin: str) -> list:
    """
    Tageskerzen (ZIP mit CSV, mit oder ohne Kopfzeile). Spot-Zeitstempel ab 2025 in Mikrosekunden. Spalten Spot/USDⓈ-M: Öffnung,
    O, H, L, C, Volumen, Schluss, Quote-Volumen, Trades, Taker-Kauf Basis, Taker-Kauf Quote; COIN-M: Volumen und Taker-Kauf in
    Kontrakten (× Kontraktgröße = USD). -> (markt, symbol, tag, o, h, l, c, v, v_usd, taker_usd, n)
    """
    text = _csv_aus_zip(roh)
    if text is None:
        return []
    out = []
    for f in csv.reader(io.StringIO(text)):
        if len(f) < 11:
            continue
        try:
            t = int(float(f[0]))
        except ValueError:
            continue                                          # Kopfzeile
        if t > 10 ** 14:
            t //= 1000                                        # Mikrosekunden -> Millisekunden
        tag = t // (TAG * 1000)
        o, h, l, c, v = (_zahl(x) for x in f[1:6])
        if not all(math.isfinite(x) and x > 0 for x in (o, h, l, c)):
            continue
        if markt == "cm":
            k = KONTRAKT_USD.get(coin, float("nan"))
            v_usd = v * k; taker = _zahl(f[9]) * k
        else:
            v_usd = _zahl(f[7]); taker = _zahl(f[10])
        try:
            n = int(float(f[8]))
        except ValueError:
            n = None
        out.append((markt, symbol, int(tag), o, h, l, c, _n(v), _n(v_usd), _n(taker), n))
    return out


def symbole() -> list:
    """(markt, symbol, coin) aller Tageskerzen: Kurs aller Coins (USDⓈ-M USDT), für BTC/ETH alle Derivate und Spotpaare (vorab)."""
    out = [("um", f"{c}USDT", c) for c in COINS]
    for c in COINS_ANTEIL:
        out += [("um", f"{c}{q}", c) for q in PERP_QUOTES if q != "USDT"]
        out.append(("cm", f"{c}USD_PERP", c))
        out += [("spot", f"{c}{q}", c) for q in SPOT_QUOTES]
    return out


# ================================================================================================ Laden (Takt und von Hand)

_ZULETZT: dict = {}                                         # (art, Schlüssel, periode) -> Zeit des letzten Versuchs (frische Dateien)


class _Abbruch(Exception):
    pass


class Lader:
    """Eine Laderunde: Sicherung, frische Tage, Monatskerzen, metrics rückwärts -- alles im Zeitbudget."""

    def __init__(self, con, budget_s: float, jetzt: int, log=print, pause: float = PAUSE):
        self.con = con; self.budget = budget_s; self.t0 = time.time(); self.jetzt = int(jetzt); self.log = log; self.pause = pause
        self.heute = self.jetzt // TAG; self.gestern = self.heute - 1
        self.erg = {"ok": 0, "404": 0, "fehler": 0, "zeilen": 0, "dateien": 0, "abbruch": None}

    def zeit_um(self) -> bool:
        return time.time() - self.t0 > self.budget

    def status(self, art: str, symbol: str, periode: str):
        r = self.con.execute("SELECT status FROM hb_dateien WHERE art=? AND symbol=? AND periode=?", (art, symbol, periode)).fetchone()
        return None if r is None else int(r[0])

    def _merken(self, art, symbol, periode, status, zeilen) -> None:
        _schreiben(self.con, "INSERT OR REPLACE INTO hb_dateien VALUES (?,?,?,?,?,?)",
                   [(art, symbol, periode, int(status), int(zeilen), int(time.time()))])

    def holen(self, url: str) -> tuple:
        if self.zeit_um():
            raise _Abbruch("Budget")
        art, roh, text = QUELLE["holen"](url)
        self.erg["dateien"] += 1
        if art == "fehler":
            self.erg["fehler"] += 1
            n = int(meta(self.con, "fehlversuche", "0") or 0) + 1
            meta_setzen(self.con, {"pause_bis": int(time.time() + min(6 * 3600, 900 * 2 ** (n - 1))), "fehlversuche": n,
                                   "fehler": f"{time.strftime('%d.%m. %H:%M')} {url.rsplit('/', 1)[-1]}: {text}"[:240]})
            raise _Abbruch(f"Netzfehler: {text}")
        if self.pause:
            time.sleep(self.pause)
        return art, roh

    def _frisch_erlaubt(self, schluessel) -> bool:
        t = _ZULETZT.get(schluessel)
        return t is None or time.time() - t >= WIEDER_S

    # -- metrics -----------------------------------------------------------------------------------------------------
    def metrics_tag(self, coin: str, tag: int, frisch: bool) -> str:
        """Eine Tagesdatei; liefert "ok", "404" (gemerkt) oder "spaeter" (frische Datei noch nicht da)."""
        sym, per = f"{coin}USDT", datum_von(tag)
        if frisch and not self._frisch_erlaubt(("metrics", sym, per)):
            return "spaeter"
        art, roh = self.holen(url_metrics(coin, tag))
        if art == "404":
            if tag >= self.heute - FRISCH_TAGE:
                _ZULETZT[("metrics", sym, per)] = time.time()
                return "spaeter"
            self._merken("metrics", sym, per, 0, 0); self.erg["404"] += 1
            return "404"
        zeilen = metrics_parse(roh, coin)
        _schreiben(self.con, "INSERT OR REPLACE INTO hb_metrics VALUES (?,?,?,?,?,?,?,?)", zeilen)
        self._merken("metrics", sym, per, 1 if zeilen else 0, len(zeilen)); self.erg["ok"] += 1; self.erg["zeilen"] += len(zeilen)
        return "ok" if zeilen else "404"

    def metrics_vorwaerts(self, coin: str) -> None:
        """Neue Tage bis gestern; beim ersten Mal nur gestern (die Historie lädt rückwärts)."""
        vor = meta(self.con, f"m_vor:{coin}")
        tag = int(vor) + 1 if vor not in (None, "") else self.gestern
        if vor in (None, ""):
            meta_setzen(self.con, {f"m_vor:{coin}": self.gestern - 1, f"m_rueck:{coin}": self.gestern - 1})
        while tag <= self.gestern:
            e = self.metrics_tag(coin, tag, frisch=tag >= self.heute - FRISCH_TAGE)
            if e == "spaeter":
                return
            meta_setzen(self.con, {f"m_vor:{coin}": tag})
            if e == "ok" and meta(self.con, f"m_beginn:{coin}") in (None, ""):
                meta_setzen(self.con, {f"m_beginn:{coin}": tag})
            tag += 1

    def metrics_rueckwaerts(self, coin: str) -> None:
        if meta(self.con, f"m_fertig:{coin}") == "1":
            return
        start = tag_von(START_METRICS)
        cur = meta(self.con, f"m_rueck:{coin}")
        if cur in (None, ""):
            return                                                        # erst vorwärts initialisieren
        cur = int(cur); folge = int(meta(self.con, f"m_404folge:{coin}", "0") or 0)
        while cur >= start:
            if self.status("metrics", f"{coin}USDT", datum_von(cur)) is not None:
                cur -= 1; continue
            e = self.metrics_tag(coin, cur, frisch=False)
            if e == "ok":
                folge = 0
                meta_setzen(self.con, {f"m_beginn:{coin}": cur})
            else:
                folge += 1
            cur -= 1
            meta_setzen(self.con, {f"m_rueck:{coin}": cur, f"m_404folge:{coin}": folge})
            if folge >= ENDE_404:
                break
        meta_setzen(self.con, {f"m_fertig:{coin}": 1, f"m_rueck:{coin}": cur})

    # -- Tageskerzen -------------------------------------------------------------------------------------------------
    def kerzen_monat(self, markt: str, symbol: str, coin: str, m: str, juengster: bool) -> str:
        dk = _dk(markt, symbol)
        if self.status("kerzen_m", dk, m) is not None:
            return "da"
        if juengster and not self._frisch_erlaubt(("kerzen_m", dk, m)):
            return "spaeter"
        art, roh = self.holen(url_kerzen(markt, symbol, m))
        if art == "404":
            if juengster and int(time.strftime("%d", time.gmtime(self.jetzt))) <= 7:
                _ZULETZT[("kerzen_m", dk, m)] = time.time()
                return "spaeter"                                          # Monatsdatei kommt erst einige Tage nach Monatsende
            self._merken("kerzen_m", dk, m, 0, 0); self.erg["404"] += 1
            return "404"
        zeilen = kerzen_parse(roh, markt, symbol, coin)
        _schreiben(self.con, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)", zeilen)
        self._merken("kerzen_m", dk, m, 1 if zeilen else 0, len(zeilen)); self.erg["ok"] += 1; self.erg["zeilen"] += len(zeilen)
        return "ok"

    def kerzen_tag(self, markt: str, symbol: str, coin: str, tag: int) -> str:
        per = datum_von(tag); dk = _dk(markt, symbol)
        if self.status("kerzen_t", dk, per) is not None:
            return "da"
        frisch = tag >= self.heute - FRISCH_TAGE
        if frisch and not self._frisch_erlaubt(("kerzen_t", dk, per)):
            return "spaeter"
        art, roh = self.holen(url_kerzen(markt, symbol, per))
        if art == "404":
            if frisch:
                _ZULETZT[("kerzen_t", dk, per)] = time.time()
                return "spaeter"
            self._merken("kerzen_t", dk, per, 0, 0); self.erg["404"] += 1
            return "404"
        zeilen = kerzen_parse(roh, markt, symbol, coin)
        _schreiben(self.con, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)", zeilen)
        self._merken("kerzen_t", dk, per, 1 if zeilen else 0, len(zeilen)); self.erg["ok"] += 1; self.erg["zeilen"] += len(zeilen)
        return "ok"

    def kerzen_frisch(self) -> None:
        """Laufender Monat (und der Vormonat, solange seine Monatsdatei fehlt) über Tagesdateien."""
        akt = monat_von(self.heute); vor = monat_plus(akt, -1)
        for markt, symbol, coin in symbole():
            dk = _dk(markt, symbol)
            if self.status("kerzen_m", dk, vor) == 0 or self.status("kerzen_m", dk, monat_plus(vor, -1)) == 0:
                continue                                                  # ohne Monatsdatei davor: Symbol nicht (mehr) gelistet
            for m in ((vor,) if self.status("kerzen_m", dk, vor) is None else ()) + (akt,):
                for tag in monatstage(m):
                    if tag > self.gestern:
                        break
                    self.kerzen_tag(markt, symbol, coin, tag)

    def kerzen_historie(self) -> bool:
        """Alle Monatsdateien bis zum Vormonat; True, wenn nichts mehr offen ist (außer dem noch nicht erschienenen Vormonat)."""
        bis = monat_plus(monat_von(self.heute), -1); offen = False
        for markt, symbol, coin in symbole():
            for m in monate(START_KERZEN, bis):
                e = self.kerzen_monat(markt, symbol, coin, m, juengster=(m == bis))
                if e == "spaeter":
                    offen = True
        return not offen


def laden(pfad: str, db_haupt: str | None = None, budget_s: float = 600.0, log=print, jetzt: int | None = None,
          sperre_s: int = 900, pause: float = PAUSE) -> dict:
    """Eine Laderunde (Takt oder Debug-Eintrag). Läuft schon eine andere (jünger als sperre_s), wird übersprungen."""
    con = verbinden(pfad); jetzt_ = int(jetzt or time.time())
    try:
        con.execute("BEGIN IMMEDIATE")
        try:
            r = con.execute("SELECT v FROM hb_meta WHERE k='laeuft'").fetchone()
            if r and r[0] and jetzt_ - int(r[0].split(":")[-1]) < sperre_s and r[0].split(":")[0] != str(os.getpid()):
                con.execute("COMMIT")
                return {"uebersprungen": True}
            con.execute("INSERT OR REPLACE INTO hb_meta VALUES ('laeuft', ?)", (f"{os.getpid()}:{jetzt_}",))
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
        L = Lader(con, budget_s, jetzt_, log, pause)
        erg = {"uebersprungen": False}
        try:
            pause_bis = int(meta(con, "pause_bis", "0") or 0)
            if pause_bis > time.time():
                erg["pause"] = pause_bis
            else:
                if db_haupt:
                    erg["sicherung"] = sichern(con, db_haupt, jetzt_)
                for coin in COINS:
                    L.metrics_vorwaerts(coin)
                k_fertig = L.kerzen_historie()                    # zuerst die Monate: ohne Monatsdatei keine Tagesdateien
                meta_setzen(con, {"k_fertig": 1 if k_fertig else 0})
                L.kerzen_frisch()
                for coin in COINS:
                    L.metrics_rueckwaerts(coin)
        except _Abbruch as e:
            L.erg["abbruch"] = str(e)
        finally:
            fertig = {"laeuft": "", "geladen": int(time.time())}
            if not L.erg["fehler"]:
                fertig["fehlversuche"] = 0
            meta_setzen(con, fertig)
        erg.update(L.erg)
        erg["stand"] = ladestand(con, jetzt_)
        return erg
    finally:
        con.close()


def ladestand(con, jetzt: int | None = None) -> dict:
    """Je Coin: metrics von/bis/fertig; Kerzen: Monate ok/404/offen; vollständig?"""
    jetzt = int(jetzt or time.time()); bis = monat_plus(monat_von(jetzt // TAG), -1)
    out = {"coins": {}, "kerzen": {}, "vollstaendig": True}
    for coin in COINS:
        r = con.execute("SELECT MIN(ts), MAX(ts), COUNT(*) FROM hb_metrics WHERE coin=?", (coin,)).fetchone()
        f = meta(con, f"m_fertig:{coin}") == "1"
        fehl = con.execute("SELECT COUNT(*) FROM hb_dateien WHERE art='metrics' AND symbol=? AND status=0", (f"{coin}USDT",)).fetchone()[0]
        out["coins"][coin] = {"von": r[0], "bis": r[1], "zeilen": r[2], "fertig": f, "fehlend": fehl}
        out["vollstaendig"] &= f
    soll = len(monate(START_KERZEN, bis))
    for markt, symbol, coin in symbole():
        rr = dict(con.execute("SELECT status, COUNT(*) FROM hb_dateien WHERE art='kerzen_m' AND symbol=? AND periode<=? GROUP BY status",
                              (_dk(markt, symbol), bis)).fetchall())
        tage = con.execute("SELECT MIN(tag), MAX(tag), COUNT(*) FROM hb_kerzen WHERE markt=? AND symbol=?", (markt, symbol)).fetchone()
        offen = soll - rr.get(1, 0) - rr.get(0, 0)
        # seit 23.64: die Buchführung gegen die Zeilen, die die Studie liest -- jede gemerkte Monatsdatei braucht Zeilen in ihrem Monat
        ohne_zeilen = con.execute(
            "SELECT COUNT(*) FROM hb_dateien d WHERE d.art='kerzen_m' AND d.symbol=? AND d.status=1 AND d.periode<=? AND NOT EXISTS "
            "(SELECT 1 FROM hb_kerzen k WHERE k.markt=? AND k.symbol=? AND k.tag >= CAST(julianday(d.periode || '-01') - 2440587.5 AS INTEGER) "
            "AND k.tag < CAST(julianday(d.periode || '-01', '+1 month') - 2440587.5 AS INTEGER))",
            (_dk(markt, symbol), bis, markt, symbol)).fetchone()[0]
        widerspruch = ohne_zeilen > 0
        out["kerzen"][(markt, symbol)] = {"ok": rr.get(1, 0), "fehlend": rr.get(0, 0), "offen": offen, "von": tage[0], "bis": tage[1],
                                          "tage": tage[2], "ohne_zeilen": ohne_zeilen, "widerspruch": widerspruch}
        out["vollstaendig"] &= offen <= 1 and not widerspruch               # der Vormonat darf noch fehlen
    out["pause_bis"] = int(meta(con, "pause_bis", "0") or 0)
    out["fehler"] = meta(con, "fehler", "")
    out["geladen"] = meta(con, "geladen")
    return out


# ================================================================================================ Sicherung (nur lesend aus hl_liq.db)

def sichern(con, db_haupt: str, jetzt: int, max_zeilen: int = SICHERUNG_ZEILEN, erzwingen: bool = False) -> dict:
    """Bybit/OKX-Liquidationen (ext_liquidations) und Binance-Buchtiefe ohne Wände (bnc_book) nach hebel.db, ab dem jüngsten
    gesicherten Zeitstempel. Höchstens stündlich (außer erzwingen)."""
    letzte = int(meta(con, "sicherung_lauf", "0") or 0)
    if not erzwingen and jetzt - letzte < SICHERUNG_S:
        return {"faellig": False}
    ro = _lesen(db_haupt)
    if ro is None:
        return {"faellig": True, "grund": "Hauptdatenbank fehlt"}
    out = {"faellig": True}
    try:
        for tab, ziel, felder, sql_ziel in (
                ("ext_liquidations", "hb_liq", "exchange, uid, ts, coin, side, price, qty, notional",
                 "INSERT OR IGNORE INTO hb_liq VALUES (?,?,?,?,?,?,?,?)"),
                ("bnc_book", "hb_buch", "ts, coin, mid, bid5, ask5, bid25, ask25, bid100, ask100",
                 "INSERT OR IGNORE INTO hb_buch VALUES (?,?,?,?,?,?,?,?,?)")):
            try:
                ab = int(meta(con, f"sicherung:{tab}", "0") or 0)
                rows = ro.execute(f"SELECT {felder} FROM {tab} WHERE ts >= ? ORDER BY ts LIMIT ?", (ab, int(max_zeilen))).fetchall()
            except sqlite3.Error as e:
                out[tab] = {"fehler": f"{type(e).__name__}: {e}"[:120]}
                continue
            if rows:
                _schreiben(con, sql_ziel, rows)
                ts_max = max(int(r[2] if tab == "ext_liquidations" else r[0]) for r in rows)
                meta_setzen(con, {f"sicherung:{tab}": ts_max})
            out[tab] = {"zeilen": len(rows)}
    finally:
        ro.close()
    meta_setzen(con, {"sicherung_lauf": jetzt})
    return out


# ================================================================================================ Takt im Dashboard-Prozess

_TAKT = {"gestartet": False, "letzter": None, "fehler": None, "laeuft": False}


def bedarf(pfad: str, jetzt: int | None = None) -> bool:
    """Noch nicht vollständig -> jede Runde; danach stündlich (frische Tage, Sicherung)."""
    if not os.path.exists(pfad):
        return True
    jetzt = int(jetzt or time.time())
    con = _lesen(pfad)
    if con is None:
        return True
    try:
        if meta(con, "schema_dateien") != SCHEMA_DATEIEN:
            return True                                                   # Umstellung (23.64) steht aus: gleich laden
        if int(meta(con, "pause_bis", "0") or 0) > jetzt:
            return False
        fertig = all(meta(con, f"m_fertig:{c}") == "1" for c in COINS) and meta(con, "k_fertig") == "1"
        geladen = int(meta(con, "geladen", "0") or 0)
        return (not fertig) or jetzt - geladen >= 3600
    except sqlite3.Error:
        return True
    finally:
        con.close()


def starten(db: str) -> bool:
    """Daten-Takt im Dashboard-Prozess: alle 5 min prüfen, dann höchstens 4 min laden. Nicht für Selbsttest-Datenbanken, aus mit
    HL_HEBEL=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_HEBEL") == "0":
        return False
    _TAKT["gestartet"] = True
    pfad = hebel_pfad(db)

    def schleife():
        time.sleep(90)
        while True:
            try:                                                          # 23.68 (U158): CryptoQuant einmal am Tag nach 01:00 UTC
                _TAKT["cq"] = cq_abruf(pfad)
            except Exception as e:
                _TAKT["cq"] = {"fehler": cq_geschwaerzt(f"{type(e).__name__}: {e}", cq_schluessel_lesen()[0])[:200]}
            try:
                if bedarf(pfad):
                    _TAKT["laeuft"] = True
                    erg = laden(pfad, db, budget_s=LADE_BUDGET_TAKT, log=lambda *a: None)
                    _TAKT["letzter"] = {"ts": int(time.time()), "erg": {k: v for k, v in erg.items() if k != "stand"}}
                    _TAKT["fehler"] = None
            except Exception as e:
                _TAKT["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
                print(f"Hebel-Takt: {_TAKT['fehler']}", flush=True)
            finally:
                _TAKT["laeuft"] = False
            time.sleep(TAKT_S)
    threading.Thread(target=schleife, daemon=True, name="hebel").start()
    return True


# ================================================================================================ Tafel je Coin (nur lesend)

def _auf_achse(tag0: int, n: int, tage, werte) -> np.ndarray:
    out = np.full(n, np.nan)
    tage = np.asarray(tage, dtype=np.int64); werte = np.asarray(werte, dtype=float)
    i = tage - tag0; m = (i >= 0) & (i < n)
    out[i[m]] = werte[m]
    return out


def tafel_bauen(coin: str, K: dict, M: dict | None) -> dict | None:
    """
    Tagesachse aus der Perp-Tageskerze <COIN>USDT (Lücken bis 3 Tage aufgefüllt, nach längeren beginnt die Reihe neu, wie U141),
    σ (EWMA, Halbwertszeit 20 T), Verhältnisse und OI zum Tagesende (jüngste Stundenzeile ≤ Ende d, höchstens 2 h alt), stündliches
    OI für den OI-Abbau, Perzentile (90 Tage davor), für BTC/ETH Perp-Anteil, OI ÷ Spotvolumen.
    """
    k = K.get(("um", f"{coin}USDT"))
    if k is None:
        return None
    ax = ZY.achse(k["tag"], k["c"])
    if ax is None or len(ax["c"]) < VORLAUF + 30:
        return None
    tag0 = int(ax["tag0"]); c = ax["c"]; n = len(c)
    h_ = _auf_achse(tag0, n, k["tag"], k["h"]); l_ = _auf_achse(tag0, n, k["tag"], k["l"])
    h_ = np.where(np.isfinite(h_), np.maximum(h_, c), c); l_ = np.where(np.isfinite(l_), np.minimum(l_, c), c)
    T = {"coin": coin, "tag0": tag0, "n": n, "c": c, "h": h_, "l": l_, "sig": ZY.sigma_batch(ZY.renditen(c[None, :]))[0],
         "gefuellt": ax["gefuellt"], "lange_luecken": ax["lange_luecken"]}
    for name in ("oi", "oi_usd", "top_konten", "top_pos", "konten", "taker", "s_oi") + tuple("konten_" + s for s, _, _ in STAND_FRUEHER):
        T[name] = None
    T["ln_oi_h"] = None; T["oi_h0"] = None; T["metrics_ab"] = None
    if M is not None and len(M["ts"]):
        ziel = (tag0 + np.arange(n) + 1) * TAG
        j = np.searchsorted(M["ts"], ziel, side="right") - 1
        jj = np.clip(j, 0, None)
        ok = (j >= 0) & (M["ts"][jj] >= ziel - SNAPSHOT_MAX_ALTER)
        for name in ("oi", "oi_usd", "top_konten", "top_pos", "konten", "taker"):
            v = np.full(n, np.nan); v[ok] = M[name][jj[ok]]; T[name] = v
        for sfx, versatz, _ in STAND_FRUEHER:                            # nachträglich (12.3): Konten-Stand früher am Tag bzw. Vortag
            zv = ziel - versatz
            jv = np.searchsorted(M["ts"], zv, side="right") - 1; jjv = np.clip(jv, 0, None)
            okv = (jv >= 0) & (M["ts"][jjv] >= zv - SNAPSHOT_MAX_ALTER)
            v = np.full(n, np.nan); v[okv] = M["konten"][jjv[okv]]; T["konten_" + sfx] = v
        h0 = int(M["ts"].min() // 3600); nh = int(M["ts"].max() // 3600) - h0 + 1
        lh = np.full(nh, np.nan); m = np.isfinite(M["oi"]) & (M["oi"] > 0)
        lh[(M["ts"][m] // 3600 - h0).astype(np.int64)] = np.log(M["oi"][m])
        T["ln_oi_h"] = lh; T["oi_h0"] = h0
        lo = np.log(np.where(T["oi"] > 0, T["oi"], np.nan))
        d_oi = np.full(n, np.nan); d_oi[1:] = lo[1:] - lo[:-1]
        T["s_oi"] = ZY.sigma_batch(d_oi[None, :])[0]
        irgend = np.isfinite(T["konten"]) | np.isfinite(T["top_pos"]) | np.isfinite(T["oi"])
        T["metrics_ab"] = tag0 + int(np.argmax(irgend)) if irgend.any() else None
    for name, _ in KENNZAHLEN:
        T[name + "_pz"] = ZY.oi_perzentil(T[name], PERZ_FENSTER, PERZ_MIN) if T[name] is not None else None
    T["anteil"] = T["anteil_pz"] = T["oi_spot"] = T["oi_spot_pz"] = None; T["spot_paare"] = {}; T["derivat_paare"] = {}
    if coin in COINS_ANTEIL:
        deriv = np.zeros(n); spot = np.zeros(n); pflicht_d = pflicht_s = None
        for markt, symbol, cc in symbole():
            if cc != coin or (markt, symbol) not in K:
                continue
            kk = K[(markt, symbol)]
            v = _auf_achse(tag0, n, kk["tag"], kk["v_usd"])
            v0 = np.where(np.isfinite(v) & (v > 0), v, 0.0)
            if markt == "spot":
                spot += v0; T["spot_paare"][symbol] = v0
                if symbol == f"{coin}USDT":
                    pflicht_s = v0 > 0
            else:
                deriv += v0; T["derivat_paare"][symbol] = v0
                if markt == "um" and symbol == f"{coin}USDT":
                    pflicht_d = v0 > 0
        if pflicht_d is not None and pflicht_s is not None:
            ok = pflicht_d & pflicht_s
            with np.errstate(invalid="ignore", divide="ignore"):
                a = np.where(ok, deriv / (deriv + spot), np.nan)
                T["anteil"] = a; T["derivat_usd"] = np.where(ok, deriv, np.nan); T["spot_usd"] = np.where(ok, spot, np.nan)
                T["anteil_pz"] = ZY.oi_perzentil(a, PERZ_FENSTER, PERZ_MIN)
                if T["oi_usd"] is not None:
                    T["oi_spot"] = np.where(ok & np.isfinite(T["oi_usd"]), T["oi_usd"] / np.where(ok, spot, np.nan), np.nan)
                    T["oi_spot_pz"] = ZY.oi_perzentil(T["oi_spot"], PERZ_FENSTER, PERZ_MIN)
    T["ev0"] = int(min(n, max(VORLAUF, tag_von(START_METRICS) - tag0)))
    return T


def daten_laden(db: str, log=print) -> dict:
    """Alle Reihen der Studie aus hebel.db (nur lesend), Funding beschreibend aus swing.db."""
    pfad = hebel_pfad(db); info = {"pfad": pfad, "fehlt": []}
    con = _lesen(pfad)
    if con is None:
        info["fehlt"].append(f"hebel.db fehlt ({pfad}) -- der Hebel-Takt legt sie nach dem Einspielen an und lädt im Hintergrund")
        return {"tafeln": {}, "info": info, "laden": None, "roh_m": {}}
    try:
        stand = ladestand(con)
        K = {}
        for markt, symbol, coin in symbole():
            rows = con.execute("SELECT tag, h, l, c, v_usd, taker_usd FROM hb_kerzen WHERE markt=? AND symbol=? ORDER BY tag",
                               (markt, symbol)).fetchall()
            if rows:
                a = np.array(rows, dtype=float)
                K[(markt, symbol)] = {"tag": a[:, 0].astype(np.int64), "h": a[:, 1], "l": a[:, 2], "c": a[:, 3], "v_usd": a[:, 4],
                                      "taker_usd": a[:, 5]}
        M = {}
        for coin in COINS:
            rows = con.execute("SELECT ts, oi, oi_usd, top_konten, top_pos, konten, taker FROM hb_metrics WHERE coin=? ORDER BY ts",
                               (coin,)).fetchall()
            if rows:
                a = np.array(rows, dtype=float)
                M[coin] = {"ts": a[:, 0].astype(np.int64), "oi": a[:, 1], "oi_usd": a[:, 2], "top_konten": a[:, 3], "top_pos": a[:, 4],
                           "konten": a[:, 5], "taker": a[:, 6]}
        sich = {}
        for tab, sql in (("hb_liq", "SELECT COUNT(*), MIN(ts), MAX(ts) FROM hb_liq"), ("hb_buch", "SELECT COUNT(*), MIN(ts), MAX(ts) FROM hb_buch")):
            sich[tab] = con.execute(sql).fetchone()
        liq_tage = con.execute("SELECT exchange, ts / 86400 AS d, SUM(notional), COUNT(*) FROM hb_liq GROUP BY exchange, d ORDER BY d").fetchall()
    finally:
        con.close()
    tafeln = {}
    for coin in COINS:
        if ("um", f"{coin}USDT") not in K:
            info["fehlt"].append(f"{coin}: keine Tageskerzen des Perpetuals {coin}USDT"); continue
        T = tafel_bauen(coin, K, M.get(coin))
        if T is None:
            info["fehlt"].append(f"{coin}: zu wenige Tage"); continue
        if T["konten"] is None:
            info["fehlt"].append(f"{coin}: keine metrics (Positionierung)")
        tafeln[coin] = T
    funding_tage(db, tafeln, info)
    return {"tafeln": tafeln, "info": info, "laden": stand, "roh_m": M, "sicherung": sich, "liq_tage": liq_tage, "K": K}


def funding_tage(db: str, tafeln: dict, info: dict) -> None:
    """Funding je Tag (Summe der Zahlungen des Tages, swing.db) für die Richtungsbeschreibung der Wellen."""
    con = _lesen(SW.swing_pfad(db))
    for coin, T in tafeln.items():
        T["funding"] = None
    if con is None:
        info["fehlt"].append("swing.db fehlt (Funding für die Richtungsbeschreibung)")
        return
    try:
        for coin, T in tafeln.items():
            F = SW.funding_lesen(con, coin)
            if len(F["ts"]):
                d = F["ts"] // TAG - T["tag0"]; m = (d >= 0) & (d < T["n"])
                f = np.full(T["n"], np.nan); s = np.zeros(T["n"])
                np.add.at(s, d[m], F["rate"][m]); hat = np.zeros(T["n"], dtype=bool); hat[d[m]] = True
                f[hat] = s[hat]; T["funding"] = f
    except sqlite3.Error as e:
        info["fehlt"].append(f"swing.db nicht lesbar: {e}")
    finally:
        con.close()


# ================================================================================================ Ereignisse

def ereignis_kurs(c: np.ndarray, h_: np.ndarray, l_: np.ndarray, sig: np.ndarray, h: int) -> tuple:
    """Ausschlag ab/auf: tiefstes Tief bzw. höchstes Hoch der Tage d+1 … d+h jenseits c_d·e^{∓1,5 σ_d √h}; gültig mit h Folgetagen."""
    n = len(c); X = np.log(c); lo = np.full(n, np.inf); hi = np.full(n, -np.inf)
    L = np.log(l_); H = np.log(h_)
    for j in range(1, h + 1):
        lo[:n - j] = np.minimum(lo[:n - j], L[j:]); hi[:n - j] = np.maximum(hi[:n - j], H[j:])
    gl = np.zeros(n, dtype=bool); gl[:max(0, n - h)] = True
    gl &= np.isfinite(sig) & (sig > 0)
    with np.errstate(invalid="ignore"):
        thr = K_KURS * sig * math.sqrt(h)
        ab = (lo <= X - thr) & gl; auf = (hi >= X + thr) & gl
    return ab, auf, gl


def oi_abbau(T: dict, h: int) -> tuple:
    """O(h): tiefstes stündliches ln OI (Coins) in (Ende d, Ende d+h] ≤ ln OI_d − 1,5·s_d·√h; gültig mit ≥ 80 % der Stunden."""
    n = T["n"]; O = np.zeros(n, dtype=bool); gl = np.zeros(n, dtype=bool)
    lh = T.get("ln_oi_h")
    if lh is None or T.get("oi") is None:
        return O, gl
    L = 24 * h
    if len(lh) < L + 1:
        return O, gl
    gross = np.where(np.isfinite(lh), lh, np.inf)
    mins = sliding_window_view(gross, L).min(axis=1)
    cs = np.concatenate([[0], np.cumsum(np.isfinite(lh).astype(np.int64))]); cnt = cs[L:] - cs[:-L]
    hd = ((T["tag0"] + np.arange(n) + 1) * TAG) // 3600 - T["oi_h0"]
    s = hd + 1
    ok = (s >= 0) & (s < len(mins))
    sj = np.clip(s, 0, len(mins) - 1)
    lo_d = np.log(np.where(T["oi"] > 0, T["oi"], np.nan)); so = T["s_oi"]
    with np.errstate(invalid="ignore"):
        gl = ok & (cnt[sj] >= OI_ABDECKUNG * L) & np.isfinite(lo_d) & np.isfinite(so) & (so > 0)
        O = gl & (mins[sj] <= lo_d - K_OI * so * math.sqrt(h))
    return O, gl


def welle(T: dict, h: int) -> dict:
    """Liquidationswelle E_D(h) = OI-Abbau und Ausschlag (ab oder auf); Richtung 1 ab, 2 auf, 3 beide."""
    ab, auf, glk = ereignis_kurs(T["c"], T["h"], T["l"], T["sig"], h)
    O, glo = oi_abbau(T, h)
    E = O & (ab | auf); gl = glk & glo
    richt = np.where(E, np.where(ab & auf, 3, np.where(ab, 1, 2)), 0)
    return {"E": E & gl, "gl": gl, "richt": richt, "O": O & gl, "ab": ab, "auf": auf}


# ================================================================================================ Signale

def _sig_konten(T):
    return None if T.get("konten") is None else (T["konten"] >= SCHWELLE_KONTEN, np.isfinite(T["konten"]))


def _sig_konten_frueher(sfx: str):
    """Nachträglich (12.3): Konten ≥ 3 mit dem Stand 1 h bzw. 24 h vor dem Tagesende (Archiv-Versatz, Haltbarkeit)."""
    def f(T):
        x = T.get("konten_" + sfx)
        if x is None:
            return None
        with np.errstate(invalid="ignore"):
            return x >= SCHWELLE_KONTEN, np.isfinite(x)
    return f


def _sig_pz(name: str, hoch: bool):
    def f(T):
        x = T.get(name + "_pz")
        if x is None:
            return None
        with np.errstate(invalid="ignore"):
            return ((x >= PZ_HOCH) if hoch else (x <= PZ_TIEF), np.isfinite(x))
    return f


def _richt_top(T):
    x = T.get("top_pos")
    if x is None:
        return None
    with np.errstate(invalid="ignore"):
        s = np.where(x >= TOP_LONG, 1, np.where(x <= TOP_SHORT, -1, 0)).astype(np.int8)
    return s, np.isfinite(x)


def _richt_pz(name: str):
    def f(T):
        x = T.get(name + "_pz")
        if x is None:
            return None
        with np.errstate(invalid="ignore"):
            s = np.where(x >= PZ_HOCH, 1, np.where(x <= PZ_TIEF, -1, 0)).astype(np.int8)
        return s, np.isfinite(x)
    return f


def _sig_anteil(T):
    x = T.get("anteil")
    if x is None:
        return None
    with np.errstate(invalid="ignore"):
        return x >= ANTEIL_ABS, np.isfinite(x)


def _sig_anteil_pz(T):
    x = T.get("anteil_pz")
    if x is None:
        return None
    with np.errstate(invalid="ignore"):
        return x >= ANTEIL_PZ, np.isfinite(x)


def _sig_oi_spot(T):
    x = T.get("oi_spot_pz")
    if x is None:
        return None
    with np.errstate(invalid="ignore"):
        return x >= PZ_HOCH, np.isfinite(x)


def rr_tests_def() -> list:
    """(Schlüssel, Titel, Signal, h, Haupt) für Rücksetzer E_A gegen die Vorzeichen-Surrogate."""
    out = [("H1", HAUPT[0][1], _sig_konten, H_HAUPT, True)]
    out += [(f"H1_h{h}", f"Konten ≥ 3, Rücksetzer in {h} Tagen", _sig_konten, h, False) for h in H_RR_BESCHR]
    for name, titel in KENNZAHLEN:
        out.append((f"P_{name}_hoch", f"{titel} im obersten Zehntel", _sig_pz(name, True), H_HAUPT, False))
        out.append((f"P_{name}_tief", f"{titel} im untersten Zehntel", _sig_pz(name, False), H_HAUPT, False))
    out += [(f"H1_{sfx}", f"Konten ≥ 3 mit dem Stand {lab}, Rücksetzer in 7 Tagen", _sig_konten_frueher(sfx), H_HAUPT, False)
            for sfx, _, lab in STAND_FRUEHER]                                     # nachträglich (12.3), beschreibend
    return out


def richt_tests_def() -> list:
    """(Schlüssel, Titel, Signal ±1, Horizont k, Haupt) für die vorzeichenrichtige Rendite gegen die Vorzeichen-Surrogate."""
    out = [("H2", HAUPT[1][1], _richt_top, H_RICHTUNG, True)]
    out += [(f"H2_k{k}", f"Top-Trader-Regel, Richtung über {k} Tage", _richt_top, k, False) for k in H_RICHTUNG_BESCHR]
    for name, titel in KENNZAHLEN:
        for k in (1, 3, 7):
            out.append((f"R_{name}_k{k}", f"{titel}: oberstes Zehntel +1, unterstes −1, {k} T", _richt_pz(name), k, False))
    return out


def risiko_tests_def() -> list:
    """(Schlüssel, Titel, Signal, h, Haupt) für Liquidationswellen gegen die Zeitverschiebung (BTC, ETH)."""
    out = [("H3", HAUPT[2][1], _sig_anteil, H_HAUPT, True), ("H4", HAUPT[3][1], _sig_anteil_pz, H_HAUPT, True)]
    for h in H_RR_BESCHR:
        out.append((f"H3_h{h}", f"Perp-Anteil ≥ 95 %, Welle in {h} Tagen", _sig_anteil, h, False))
        out.append((f"H4_h{h}", f"Perp-Anteil oberstes Zehntel, Welle in {h} Tagen", _sig_anteil_pz, h, False))
    out.append(("D_oi_spot", "OI ÷ Spotvolumen im obersten Zehntel, Welle in 7 Tagen", _sig_oi_spot, H_HAUPT, False))
    return out


def shifts() -> np.ndarray:
    return np.array([t for t in range(-SHIFT_MAX, SHIFT_MAX + 1) if abs(t) >= SHIFT_MIN], dtype=np.int64)


def _episoden(idx: np.ndarray, h: int) -> int:
    return 0 if not len(idx) else 1 + int(np.sum(np.diff(idx) > h))


def _rr4(k4) -> float:
    """RR = (a/(a+b)) / (c/(c+d)); ohne Signal- oder Vergleichstage NaN, ohne Ereignis im Vergleich ∞ (bzw. NaN bei 0/0)."""
    a, b, c, d = (float(x) for x in k4)
    if a + b <= 0 or c + d <= 0:
        return float("nan")
    if c <= 0:
        return float("inf") if a > 0 else float("nan")
    return (a / (a + b)) / (c / (c + d))


# ================================================================================================ Tests mit Vorzeichen-Surrogaten (H1, H2)

def richtungs_tests(tafeln: dict, n_surr: int = N_SURR, n_boot: int = N_BOOT, log=lambda s: None, saat: int = SAAT) -> dict:
    """
    H1 und H2 samt beschreibenden Varianten. Kurse aller Coins gleichzeitig neu ausgelost (ein Vorzeichen je Kalendertag, Drift
    bleibt; wie U141 Teil C), Signale fest. RR je Signal gepoolt; T = Mittel von s·r/(σ√k) über die Signaltage.
    """
    coins = [c for c in COINS if c in tafeln and tafeln[c].get("konten") is not None]
    if not coins:
        return {}
    g0 = min(tafeln[c]["tag0"] for c in coins); g1 = max(tafeln[c]["tag0"] + tafeln[c]["n"] - 1 for c in coins); G = g1 - g0 + 1
    V = ZY.vorzeichen(max(n_surr, 1), g0, g1, saat)
    RRD = rr_tests_def(); RID = richt_tests_def()
    hs = sorted({d[3] for d in RRD}); ks = sorted({d[3] for d in RID})
    kal = {d[0]: np.zeros((4, G)) for d in RRD}
    nul = {d[0]: np.zeros((max(n_surr, 1), 4)) for d in RRD}
    nul_h = {d[0]: [np.zeros((max(n_surr, 1), 4)), np.zeros((max(n_surr, 1), 4))] for d in RRD}
    sum_g = {d[0]: np.zeros(G) for d in RID}; cnt_g = {d[0]: np.zeros(G) for d in RID}; pos_g = {d[0]: np.zeros(G) for d in RID}
    S_n = {d[0]: np.zeros(max(n_surr, 1)) for d in RID}; N_n = {d[0]: np.zeros(max(n_surr, 1)) for d in RID}
    S_h = {d[0]: [np.zeros(max(n_surr, 1)), np.zeros(max(n_surr, 1))] for d in RID}
    N_h = {d[0]: [np.zeros(max(n_surr, 1)), np.zeros(max(n_surr, 1))] for d in RID}
    sigtage = {d[0]: [] for d in RRD + RID}; abdeckung = {d[0]: [] for d in RRD + RID}; je_coin = {d[0]: {} for d in RRD + RID}
    # Signale je Coin (fest) und Kalenderhälften (Mitte der Spanne mit definiertem Signal und gültigem Ereignis)
    sig_c = {}; spannen = {}
    for coin in coins:
        T = tafeln[coin]; n = T["n"]; ev = np.zeros(n, dtype=bool); ev[T["ev0"]:] = True
        sig_c[coin] = {}
        for key, _, fn, h, _ in RRD + RID:
            s = fn(T)
            if s is None:
                continue
            sig_c[coin][key] = s
            dm = s[1] & ev; dm[max(0, n - h):] = False
            if dm.any():
                idx = np.nonzero(dm)[0]; a_, b_ = T["tag0"] + int(idx[0]), T["tag0"] + int(idx[-1])
                spannen[key] = (min(spannen.get(key, (a_, b_))[0], a_), max(spannen.get(key, (a_, b_))[1], b_))
    mitte = {k: v[0] + (v[1] - v[0]) // 2 for k, v in spannen.items()}
    for coin in coins:
        T = tafeln[coin]; n = T["n"]; off = T["tag0"] - g0
        ev = np.zeros(n, dtype=bool); ev[T["ev0"]:] = True
        r = np.diff(np.log(T["c"])); mu = float(np.mean(r[T["ev0"]:])) if n - T["ev0"] > 2 else 0.0
        R = {"c": T["c"], "tag0": T["tag0"], "n": n}
        for a in [-1] + list(range(0, n_surr, CHUNK)):
            if a == -1:
                Cb = T["c"][None, :].copy(); zeilen = None
            else:
                zeilen = np.arange(a, min(n_surr, a + CHUNK)); Cb = ZY.surrogate(R, V, g0, mu, zeilen)[1:]
            SIG = ZY.sigma_batch(ZY.renditen(Cb))
            E = {}; GL = {}
            for h in hs:
                E[h], _, GL[h] = ZY.ereignis_batch(Cb, SIG, h, K_KURS)
            X = np.log(Cb); Z = {}
            for k in ks:
                z = np.full(Cb.shape, np.nan)
                with np.errstate(invalid="ignore", divide="ignore"):
                    z[:, :n - k] = (X[:, k:] - X[:, :n - k]) / (SIG[:, :n - k] * math.sqrt(k))
                Z[k] = z
            blk = slice(a, a + len(zeilen)) if a >= 0 else None
            for key, _, fn, h, _ in RRD:
                if key not in sig_c[coin]:
                    continue
                sg, sd = sig_c[coin][key]
                m = GL[h] & (sd & ev)[None, :]
                Ee = E[h]
                A_ = sg & m & Ee; B_ = sg & m & ~Ee; C_ = ~sg & m & Ee; D_ = ~sg & m & ~Ee
                if a == -1:
                    for i, M_ in enumerate((A_, B_, C_, D_)):
                        kal[key][i, off:off + n] += M_[0]
                    idx = np.nonzero(A_[0] | B_[0])[0]; sigtage[key].append((coin, idx)); abdeckung[key].append(coin)
                    k4 = [int(M_[0].sum()) for M_ in (A_, B_, C_, D_)]
                    je_coin[key][coin] = {"k4": k4, "rr": _rr4(k4)}
                else:
                    nul[key][blk] += np.stack([M_.sum(axis=1) for M_ in (A_, B_, C_, D_)], axis=1)
                    if key in mitte:
                        mi = mitte[key] - T["tag0"]
                        for hh, sl_ in enumerate((slice(0, max(0, mi)), slice(max(0, mi), n))):
                            nul_h[key][hh][blk] += np.stack([M_[:, sl_].sum(axis=1) for M_ in (A_, B_, C_, D_)], axis=1)
            for key, _, fn, k, _ in RID:
                if key not in sig_c[coin]:
                    continue
                s, sd = sig_c[coin][key]
                gv = (sd & ev & (s != 0))[None, :] & np.isfinite(Z[k])
                beitrag = np.where(gv, s[None, :] * Z[k], 0.0)
                if a == -1:
                    sum_g[key][off:off + n] += beitrag[0]; cnt_g[key][off:off + n] += gv[0]
                    pos_g[key][off:off + n] += gv[0] & (beitrag[0] > 0)
                    idx = np.nonzero(gv[0])[0]; sigtage[key].append((coin, idx)); abdeckung[key].append(coin)
                    je_coin[key][coin] = {"n": int(gv[0].sum()), "t": float(beitrag[0].sum() / gv[0].sum()) if gv[0].any() else float("nan"),
                                          "long": int((gv[0] & (s > 0)).sum()), "short": int((gv[0] & (s < 0)).sum())}
                else:
                    S_n[key][blk] += beitrag.sum(axis=1); N_n[key][blk] += gv.sum(axis=1)
                    if key in mitte:
                        mi = mitte[key] - T["tag0"]
                        for hh, sl_ in enumerate((slice(0, max(0, mi)), slice(max(0, mi), n))):
                            S_h[key][hh][blk] += beitrag[:, sl_].sum(axis=1); N_h[key][hh][blk] += gv[:, sl_].sum(axis=1)
        log(f"    {coin}: Positionierung gezählt")
    out = {}
    for key, titel, _, h, haupt in RRD:
        if not abdeckung[key]:
            out[key] = {"titel": titel, "coins": [], "art": "rr", "h": h, "haupt": haupt}
            continue
        k4 = kal[key].sum(axis=1); rr = _rr4(k4)
        rr_null = ZY._rr(nul[key][:, 0], nul[key][:, 1], nul[key][:, 2], nul[key][:, 3]) if n_surr else np.array([np.nan])
        hv = {}
        if key in mitte:
            mi = mitte[key] - g0
            for hh, sl_ in enumerate((slice(0, mi), slice(mi, G))):
                e_rr = _rr4(kal[key][:, sl_].sum(axis=1)); zz = nul_h[key][hh]
                n_rr = ZY._rr(zz[:, 0], zz[:, 1], zz[:, 2], zz[:, 3]) if n_surr else np.array([np.nan])
                hv[hh] = (e_rr, ZY._nanmed(n_rr))
        epi = sum(_episoden(idx, h) for _, idx in sigtage[key])
        out[key] = {"titel": titel, "art": "rr", "h": h, "haupt": haupt, "coins": abdeckung[key], "k4": [int(x) for x in k4], "rr": rr,
                    "p": ZY._p_groesser(rr, rr_null) if n_surr else float("nan"), "null_median": ZY._nanmed(rr_null) if n_surr else float("nan"),
                    "p_sig": k4[0] / (k4[0] + k4[1]) if k4[0] + k4[1] else float("nan"),
                    "p_ohne": k4[2] / (k4[2] + k4[3]) if k4[2] + k4[3] else float("nan"),
                    "signaltage": int(k4[0] + k4[1]), "ohne": int(k4[2] + k4[3]), "episoden": epi,
                    "q": ZY._rr_bootstrap(kal[key], n_boot, BLOCK, saat + 51), "haelften_werte": hv, "je_coin": je_coin[key],
                    "spanne": spannen.get(key)}
    for key, titel, _, k, haupt in RID:
        if not abdeckung[key] or cnt_g[key].sum() == 0:
            out[key] = {"titel": titel, "coins": abdeckung[key], "art": "richtung", "h": k, "haupt": haupt, "signaltage": 0, "episoden": 0}
            continue
        t = float(sum_g[key].sum() / cnt_g[key].sum())
        with np.errstate(invalid="ignore", divide="ignore"):
            t_null = S_n[key] / N_n[key] if n_surr else np.array([np.nan])
        hv = {}
        if key in mitte:
            mi = mitte[key] - g0
            for hh, sl_ in enumerate((slice(0, mi), slice(mi, G))):
                c_ = cnt_g[key][sl_].sum()
                e_t = float(sum_g[key][sl_].sum() / c_) if c_ else float("nan")
                with np.errstate(invalid="ignore", divide="ignore"):
                    n_t = S_h[key][hh] / N_h[key][hh] if n_surr else np.array([np.nan])
                hv[hh] = (e_t, ZY._nanmed(n_t))
        epi = sum(_episoden(idx, k) for _, idx in sigtage[key])
        out[key] = {"titel": titel, "art": "richtung", "h": k, "haupt": haupt, "coins": abdeckung[key], "t": t,
                    "p": ZY._p_zweiseitig(t, t_null) if n_surr else float("nan"), "null_median": ZY._nanmed(t_null) if n_surr else float("nan"),
                    "signaltage": int(cnt_g[key].sum()), "treffer": float(pos_g[key].sum() / cnt_g[key].sum()), "episoden": epi,
                    "q": _t_bootstrap(sum_g[key], cnt_g[key], n_boot, BLOCK, saat + 52), "haelften_werte": hv, "je_coin": je_coin[key],
                    "spanne": spannen.get(key)}
    return out


def _t_bootstrap(s: np.ndarray, c: np.ndarray, n_boot: int, block: int, saat: int) -> tuple:
    """90-%-Band von T = Σs/Σc aus dem zirkulären Kalender-Blockbootstrap."""
    G = len(s)
    if G < 2 * block or n_boot <= 0 or c.sum() == 0:
        return (float("nan"), float("nan"))
    ss = np.concatenate([[0.0], np.cumsum(np.concatenate([s, s]))]); cc = np.concatenate([[0.0], np.cumsum(np.concatenate([c, c]))])
    rng = np.random.default_rng(saat); nb = int(math.ceil(G / block)); out = np.empty(n_boot)
    for i in range(n_boot):
        st = rng.integers(0, G, nb)
        num = (ss[st + block] - ss[st]).sum(); den = (cc[st + block] - cc[st]).sum()
        out[i] = num / den if den > 0 else np.nan
    out = out[np.isfinite(out)]
    return (float(np.quantile(out, 0.05)), float(np.quantile(out, 0.95))) if len(out) else (float("nan"), float("nan"))


# ================================================================================================ Nachträglich (12.3): H1 geschichtet

def _z7(T: dict) -> np.ndarray:
    """Rendite der 7 Tage bis zum Schluss von d in σ: (ln c_d − ln c_{d−7}) / (σ_d·√7) -- nur Vergangenheit."""
    x = np.log(T["c"]); z = np.full(len(x), np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        z[7:] = (x[7:] - x[:-7]) / (T["sig"][7:] * math.sqrt(7))
    return z


def _r7_klasse(T: dict) -> np.ndarray:
    """Klasse 0 … 4 der Rendite der 7 Tage davor (Grenzen −1, −⅓, +⅓, +1 in σ·√7; je an der Grenze die untere); −1 undefiniert."""
    z = _z7(T)
    k = np.searchsorted(np.asarray(R7_GRENZEN), z, side="left").astype(np.int8)
    k[~np.isfinite(z)] = -1
    return k


def _mh(k4s: np.ndarray) -> np.ndarray:
    """Mantel-Haenszel-RR über die vorletzte Achse: k4s (…, Schichten, 4) mit a, b, c, d je Schicht."""
    a, b, c, d = (k4s[..., i] for i in range(4))
    nn = a + b + c + d; m = nn > 0; nz = np.where(m, nn, 1.0)
    num = np.where(m, a * (c + d) / nz, 0.0).sum(axis=-1); den = np.where(m, c * (a + b) / nz, 0.0).sum(axis=-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan)


def h1_geschichtet(tafeln: dict, n_surr: int = N_SURR, saat: int = SAAT, klassen: bool = True, je_coin: bool = True,
                   log=lambda s: None) -> dict:
    """
    Nachträglich (10.10.2026, KONZEPT_Hebel.md 12.3), beschreibend: Ist H1 nur ein Spiegel des Kursverlaufs der Vorwoche? Dieselben
    Tage, Signale und Rücksetzer wie H1, geschichtet nach Coin × Klasse der Rendite der 7 Tage davor; Mantel-Haenszel-RR. Null aus
    denselben Vorzeichen-Surrogaten wie H1 (gleiche Saat), Schichten fest aus den echten Kursen. klassen=False, je_coin=False: eine
    Schicht -- dann ist der Wert der rohe RR von H1 (Prüfung im Selbsttest).
    """
    coins = [c for c in COINS if c in tafeln and tafeln[c].get("konten") is not None]
    if not coins:
        return {}
    g0 = min(tafeln[c]["tag0"] for c in coins); g1 = max(tafeln[c]["tag0"] + tafeln[c]["n"] - 1 for c in coins)
    V = ZY.vorzeichen(max(n_surr, 1), g0, g1, saat)
    nk = len(R7_GRENZEN) + 1 if klassen else 1; h = H_HAUPT
    echt_c = []; null_c = []
    for coin in coins:
        T = tafeln[coin]; n = T["n"]; ev = np.zeros(n, dtype=bool); ev[T["ev0"]:] = True
        sg, sd = _sig_konten(T)
        kl = _r7_klasse(T) if klassen else np.where(np.isfinite(_z7(T)), 0, -1).astype(np.int8)
        basis = sd & ev & (kl >= 0)
        r = np.diff(np.log(T["c"])); mu = float(np.mean(r[T["ev0"]:])) if n - T["ev0"] > 2 else 0.0
        R = {"c": T["c"], "tag0": T["tag0"], "n": n}
        echt = np.zeros((nk, 4)); null = np.zeros((max(n_surr, 1), nk, 4))
        for a in [-1] + list(range(0, n_surr, CHUNK)):
            if a == -1:
                Cb = T["c"][None, :].copy(); zeilen = None
            else:
                zeilen = np.arange(a, min(n_surr, a + CHUNK)); Cb = ZY.surrogate(R, V, g0, mu, zeilen)[1:]
            SIG = ZY.sigma_batch(ZY.renditen(Cb))
            E, _, GL = ZY.ereignis_batch(Cb, SIG, h, K_KURS)
            m = GL & basis[None, :]
            vier = (sg & m & E, sg & m & ~E, ~sg & m & E, ~sg & m & ~E)
            for z in range(nk):
                w = (kl == z)[None, :]
                c4 = np.stack([(M_ & w).sum(axis=1) for M_ in vier], axis=1)
                if a == -1:
                    echt[z] += c4[0]
                else:
                    null[a:a + len(zeilen), z] += c4
        echt_c.append(echt); null_c.append(null)
        log(f"    {coin}: geschichtet gezählt")
    if je_coin:
        E4 = np.concatenate(echt_c, axis=0); N4 = np.concatenate(null_c, axis=1)
    else:
        E4 = np.sum(echt_c, axis=0); N4 = np.sum(null_c, axis=0)
    mh = float(_mh(E4)); mh_null = _mh(N4) if n_surr else np.array([np.nan])
    pool = np.sum(echt_c, axis=0)                                          # je Klasse über die Coins
    tot = pool.sum(axis=0)
    out = {"coins": coins, "klassen": nk, "mh": mh, "null_median": ZY._nanmed(mh_null), "p": ZY._p_groesser(mh, mh_null) if n_surr else float("nan"),
           "roh": _rr4(tot), "signaltage": int(tot[0] + tot[1]),
           "je_klasse": [{"k4": [int(x) for x in pool[z]], "rr": _rr4(pool[z]),
                          "anteil_signal": float((pool[z][0] + pool[z][1]) / (tot[0] + tot[1])) if tot[0] + tot[1] else float("nan"),
                          "p_sig": pool[z][0] / (pool[z][0] + pool[z][1]) if pool[z][0] + pool[z][1] else float("nan"),
                          "p_ohne": pool[z][2] / (pool[z][2] + pool[z][3]) if pool[z][2] + pool[z][3] else float("nan")} for z in range(nk)]}
    return out


# ================================================================================================ Tests mit Zeitverschiebung (H3, H4)

def _gitter(tafeln: dict, coins: list, g0: int, G: int, fn, h: int, W: dict) -> dict | None:
    """Signal, Definiertheit, Ereignis und Gültigkeit je Coin auf dem gemeinsamen Kalendergitter."""
    C = len(coins)
    sig = np.zeros((C, G), dtype=bool); sdef = np.zeros((C, G), dtype=bool); E = np.zeros((C, G), dtype=bool)
    val = np.zeros((C, G), dtype=bool); richt = np.zeros((C, G), dtype=np.int8); terz = np.full((C, G), -1, dtype=np.int8)
    fund = np.full((C, G), np.nan)
    hat = False
    for i, coin in enumerate(coins):
        T = tafeln[coin]; n = T["n"]; off = T["tag0"] - g0
        s = fn(T)
        if s is None:
            continue
        hat = True
        ev = np.zeros(n, dtype=bool); ev[T["ev0"]:] = True
        w = W[(coin, h)]
        sig[i, off:off + n] = s[0]; sdef[i, off:off + n] = s[1] & ev
        E[i, off:off + n] = w["E"]; val[i, off:off + n] = w["gl"]; richt[i, off:off + n] = w["richt"]
        sg = T["sig"]; ok = np.isfinite(sg) & ev
        if ok.sum() >= 30:
            q1, q2 = np.quantile(sg[ok], [1 / 3, 2 / 3])
            tz = np.where(sg <= q1, 0, np.where(sg <= q2, 1, 2)).astype(np.int8); tz[~ok] = -1
            terz[i, off:off + n] = tz
        if T.get("funding") is not None:
            fund[i, off:off + n] = T["funding"]
    if not hat:
        return None
    return {"sig": sig, "sdef": sdef, "E": E, "val": val, "richt": richt, "terz": terz, "fund": fund}


def _k4(sig, sdef, E, val, maske=None) -> np.ndarray:
    m = sdef & val
    if maske is not None:
        m = m & maske
    return np.array([np.sum(sig & m & E), np.sum(sig & m & ~E), np.sum(~sig & m & E), np.sum(~sig & m & ~E)], dtype=float)


def _mh_rr(gt: dict) -> float:
    """Mantel-Haenszel-RR über die Schwankungsdrittel (beschreibend: trägt das Signal über die heutige Schwankung hinaus?)."""
    num = den = 0.0
    for z in (0, 1, 2):
        a, b, c, d = _k4(gt["sig"], gt["sdef"], gt["E"], gt["val"], gt["terz"] == z)
        nn = a + b + c + d
        if nn and a + b and c + d:
            num += a * (c + d) / nn; den += c * (a + b) / nn
    return num / den if den > 0 else float("nan")


def risiko_tests(tafeln: dict, n_boot: int = N_BOOT, log=lambda s: None, saat: int = SAAT) -> dict:
    coins = [c for c in COINS_ANTEIL if c in tafeln and tafeln[c].get("anteil") is not None and tafeln[c].get("ln_oi_h") is not None]
    if not coins:
        return {}, {}
    g0 = min(tafeln[c]["tag0"] for c in coins); g1 = max(tafeln[c]["tag0"] + tafeln[c]["n"] - 1 for c in coins); G = g1 - g0 + 1
    D = risiko_tests_def(); hs = sorted({d[3] for d in D})
    W = {(c, h): welle(tafeln[c], h) for c in coins for h in hs}
    taus = shifts(); out = {}
    for key, titel, fn, h, haupt in D:
        gt = _gitter(tafeln, coins, g0, G, fn, h, W)
        if gt is None:
            out[key] = {"titel": titel, "art": "risiko", "h": h, "haupt": haupt, "coins": []}
            continue
        sig, sdef, E, val = gt["sig"], gt["sdef"], gt["E"], gt["val"]
        k4 = _k4(sig, sdef, E, val); rr = _rr4(k4)
        dm = (sdef & val).any(axis=0)
        if dm.any():
            idx = np.nonzero(dm)[0]; mi = int(idx[0] + (idx[-1] - idx[0]) // 2)
        else:
            mi = G // 2
        haelfte = np.zeros(G, dtype=bool); haelfte[:mi] = True
        rr_t = np.empty(len(taus)); rr_h = [np.empty(len(taus)), np.empty(len(taus))]
        for i, t in enumerate(taus):
            s2 = np.roll(sig, int(t), axis=1); d2 = np.roll(sdef, int(t), axis=1)
            rr_t[i] = _rr4(_k4(s2, d2, E, val))
            rr_h[0][i] = _rr4(_k4(s2, d2, E, val, haelfte[None, :])); rr_h[1][i] = _rr4(_k4(s2, d2, E, val, ~haelfte[None, :]))
        hv = {0: (_rr4(_k4(sig, sdef, E, val, haelfte[None, :])), ZY._nanmed(rr_h[0])),
              1: (_rr4(_k4(sig, sdef, E, val, ~haelfte[None, :])), ZY._nanmed(rr_h[1]))}
        kal = np.stack([(sig & sdef & val & E).sum(axis=0), (sig & sdef & val & ~E).sum(axis=0),
                        (~sig & sdef & val & E).sum(axis=0), (~sig & sdef & val & ~E).sum(axis=0)]).astype(float)
        epi = 0; je_coin = {}
        for i, coin in enumerate(coins):
            ii = np.nonzero(sig[i] & sdef[i] & val[i])[0]; epi += _episoden(ii, h)
            kk = _k4(sig[i], sdef[i], E[i], val[i])
            je_coin[coin] = {"k4": [int(x) for x in kk], "rr": _rr4(kk)}
        treffer = sig & sdef & val & E
        r_ab = int(np.sum(treffer & (gt["richt"] == 1))); r_auf = int(np.sum(treffer & (gt["richt"] == 2)))
        r_beide = int(np.sum(treffer & (gt["richt"] == 3)))
        f = gt["fund"]; gegen = mit = 0
        with np.errstate(invalid="ignore"):
            gegen = int(np.sum(treffer & (((f > 0) & (gt["richt"] == 1)) | ((f < 0) & (gt["richt"] == 2)))))
            mit = int(np.sum(treffer & (((f > 0) & (gt["richt"] == 2)) | ((f < 0) & (gt["richt"] == 1)))))
        out[key] = {"titel": titel, "art": "risiko", "h": h, "haupt": haupt, "coins": coins, "k4": [int(x) for x in k4], "rr": rr,
                    "p": ZY._p_groesser(rr, rr_t), "null_median": ZY._nanmed(rr_t), "n_shift": len(taus),
                    "p_sig": k4[0] / (k4[0] + k4[1]) if k4[0] + k4[1] else float("nan"),
                    "p_ohne": k4[2] / (k4[2] + k4[3]) if k4[2] + k4[3] else float("nan"),
                    "signaltage": int(k4[0] + k4[1]), "ohne": int(k4[2] + k4[3]), "episoden": epi,
                    "q": ZY._rr_bootstrap(kal, n_boot, BLOCK, saat + 53), "haelften_werte": hv, "je_coin": je_coin,
                    "mh_rr": _mh_rr(gt), "richtung": {"ab": r_ab, "auf": r_auf, "beide": r_beide, "gegen_ueberfuellt": gegen,
                                                      "mit_ueberfuellt": mit},
                    "spanne": (g0 + int(np.nonzero(dm)[0][0]), g0 + int(np.nonzero(dm)[0][-1])) if dm.any() else None}
        log(f"    {key}: {len(taus)} Verschiebungen")
    basis = {(c, h): {"quote": float(W[(c, h)]["E"].sum() / W[(c, h)]["gl"].sum()) if W[(c, h)]["gl"].sum() else float("nan"),
                      "gueltig": int(W[(c, h)]["gl"].sum()), "o": float(W[(c, h)]["O"].sum() / W[(c, h)]["gl"].sum()) if W[(c, h)]["gl"].sum() else float("nan")}
             for c in coins for h in hs}
    return out, basis


# ================================================================================================ Urteile (vorab)

def pruefbar(o: dict) -> bool:
    if not o.get("coins") or not np.isfinite(o.get("p", float("nan"))):
        return False
    ok = o.get("signaltage", 0) >= MIN_SIGNALTAGE and o.get("episoden", 0) >= MIN_EPISODEN
    if o.get("art") in ("rr", "risiko"):
        ok = ok and o.get("ohne", 0) >= MIN_OHNE
    return bool(ok)


def haelften_ok(o: dict) -> bool:
    hv = o.get("haelften_werte") or {}
    if len(hv) != 2:
        return False
    if o.get("art") == "richtung":
        ganz = o["t"] - o["null_median"]
        if not np.isfinite(ganz) or ganz == 0:
            return False
        return all(np.isfinite(a) and np.isfinite(b) and np.sign(a - b) == np.sign(ganz) for a, b in hv.values())
    return all(np.isfinite(a) and np.isfinite(b) and a > b for a, b in hv.values())


def urteile(V: dict, vollstaendig: bool) -> None:
    """Holm über die prüfbaren Hauptprüfungen H1–H4; belegt mit p Holm < 0,05 und beiden Hälften; ohne vollständige Historie nur
    vorläufig."""
    alle = {**(V.get("richtung") or {}), **(V.get("risiko") or {})}
    haupt = [k for k, _ in HAUPT if k in alle]
    tests = [k for k in haupt if pruefbar(alle[k])]
    for k in haupt:
        o = alle[k]; o["pruefbar"] = k in tests; o["p_holm"] = float("nan"); o["bedingung"] = False; o["belegt"] = False
    for k, ph in zip(tests, RG.holm([alle[k]["p"] for k in tests])):
        o = alle[k]; o["p_holm"] = ph
        o["haelften"] = haelften_ok(o)
        o["bedingung"] = bool(np.isfinite(ph) and ph < ALPHA and o["haelften"])
        o["belegt"] = bool(o["bedingung"] and vollstaendig)
    for o in alle.values():
        if "haelften" not in o and o.get("haelften_werte"):
            o["haelften"] = haelften_ok(o)
    V["vollstaendig"] = bool(vollstaendig)


# ================================================================================================ Abgleich Archiv gegen Live, Stand

LIVE_ZU_ARCHIV = {"global_ls_account": "konten", "top_ls_account": "top_konten", "top_ls_position": "top_pos", "taker_ls": "taker"}


def abgleich(db: str, M: dict, tage: int = 60) -> dict:
    """
    bnc_metrics (hl_liq.db, live seit 14.09., nur lesen) gegen hb_metrics (Archiv) an denselben Zeitpunkten: je Live-Kennzahl die
    beste Archivspalte und der beste Versatz (0, ±300 s). Zuordnung ok, wenn die erwartete Spalte am besten passt. OI: Coins,
    nächster Live-Wert binnen 150 s. Dazu die Zahl der Zeilen mit Zeitstempel in Millisekunden.
    """
    ro = _lesen(db)
    if ro is None:
        return {"grund": "Hauptdatenbank nicht lesbar"}
    out = {"metriken": {}}
    try:
        try:
            out["ms_zeilen"] = int(ro.execute("SELECT COUNT(*) FROM bnc_metrics WHERE ts > 100000000000").fetchone()[0])
        except sqlite3.Error as e:
            return {"grund": f"bnc_metrics nicht lesbar: {type(e).__name__}"}
        for live, spalte in list(LIVE_ZU_ARCHIV.items()) + [("open_interest", "oi")]:
            paare: dict = {}
            for coin, m in M.items():
                if not len(m["ts"]):
                    continue
                ab = int(m["ts"][-1]) - tage * TAG
                rows = ro.execute("SELECT ts, value FROM bnc_metrics WHERE coin=? AND metric=? AND ts >= ? AND ts < 100000000000 ORDER BY ts",
                                  (coin, live, ab)).fetchall()
                if not rows:
                    continue
                lt = np.array([r[0] for r in rows], dtype=np.int64); lv = np.array([r[1] for r in rows], dtype=float)
                mm = m["ts"] >= ab; at = m["ts"][mm]
                kand = ("oi",) if live == "open_interest" else ("konten", "top_konten", "top_pos", "taker")
                for sp in kand:
                    av = m[sp][mm]
                    for vers in ((0,) if live == "open_interest" else (0, 300, -300)):
                        if live == "open_interest":
                            j = np.clip(np.searchsorted(lt, at), 1, len(lt) - 1) if len(lt) > 1 else np.zeros(len(at), dtype=np.int64)
                            jn = np.where(np.abs(lt[j - 1] - at) <= np.abs(lt[j] - at), j - 1, j) if len(lt) > 1 else j
                            hit = np.abs(lt[jn] - at) <= 150
                        else:
                            jn = np.clip(np.searchsorted(lt, at + vers), 0, len(lt) - 1)
                            hit = lt[jn] == at + vers
                        x = av[hit]; y = lv[jn[hit]]
                        ok = np.isfinite(x) & np.isfinite(y) & (y != 0)
                        paare.setdefault((sp, vers), []).append(np.abs(x[ok] - y[ok]) / np.abs(y[ok]))
            st = {}
            for kk, lst in paare.items():
                rel = np.concatenate(lst) if lst else np.zeros(0)
                if len(rel) >= 10:
                    st[kk] = {"n": int(len(rel)), "median": float(np.median(rel)), "anteil": float(np.mean(rel <= 0.005))}
            if not st:
                out["metriken"][live] = {"n": 0, "erwartet": spalte}
                continue
            best = min(st, key=lambda k: (st[k]["median"], -st[k]["n"]))
            erw = [k for k in st if k[0] == spalte]
            eb = min(erw, key=lambda k: (st[k]["median"], -st[k]["n"])) if erw else None
            out["metriken"][live] = {"erwartet": spalte, "bestes": best, "best": st[best], "erw": st.get(eb) if eb else None,
                                     "versatz": eb[1] if eb else None, "zuordnung_ok": best[0] == spalte, "n": st[best]["n"]}
    finally:
        ro.close()
    return out


def live_werte(db: str, alter_s: int = 3 * 3600) -> dict:
    """Jüngste Live-Werte je Coin aus bnc_metrics (höchstens alter_s alt)."""
    ro = _lesen(db); out = {}
    if ro is None:
        return out
    try:
        ab = int(time.time()) - alter_s
        for coin in COINS:
            for live, sp in LIVE_ZU_ARCHIV.items():
                r = ro.execute("SELECT ts, value FROM bnc_metrics WHERE coin=? AND metric=? AND ts >= ? AND ts < 100000000000 ORDER BY ts DESC LIMIT 1",
                               (coin, live, ab)).fetchone()
                if r:
                    out.setdefault(coin, {})[sp] = (int(r[0]), float(r[1]))
    except sqlite3.Error:
        pass
    finally:
        ro.close()
    return out


def stand_heute(tafeln: dict, live: dict) -> dict:
    out = {}
    for coin, T in tafeln.items():
        o = {"live": live.get(coin, {})}
        if T.get("konten") is not None:
            ok = np.isfinite(T["konten"]) | np.isfinite(T["top_pos"])
            if ok.any():
                d = int(np.nonzero(ok)[0][-1])
                o.update(tag=T["tag0"] + d, konten=T["konten"][d], top_pos=T["top_pos"][d], top_konten=T["top_konten"][d])
                o["s1"] = bool(np.isfinite(T["konten"][d]) and T["konten"][d] >= SCHWELLE_KONTEN)
                tp = T["top_pos"][d]
                o["s2"] = (1 if tp >= TOP_LONG else (-1 if tp <= TOP_SHORT else 0)) if np.isfinite(tp) else None
        if T.get("anteil") is not None:
            ok = np.isfinite(T["anteil"])
            if ok.any():
                d = int(np.nonzero(ok)[0][-1])
                pz = T["anteil_pz"][d] if T.get("anteil_pz") is not None else float("nan")
                o.update(anteil_tag=T["tag0"] + d, anteil=T["anteil"][d], anteil_pz=pz, s3=bool(T["anteil"][d] >= ANTEIL_ABS),
                         s4=bool(np.isfinite(pz) and pz >= ANTEIL_PZ),
                         oi_spot=T["oi_spot"][d] if T.get("oi_spot") is not None else float("nan"))
        o["kurs"] = float(T["c"][-1]); o["kurs_tag"] = T["tag0"] + T["n"] - 1
        out[coin] = o
    return out


# ================================================================================================ Beschreibend: je Jahr, Perp-Anteil

def _jahr(tag: int) -> int:
    return int(time.strftime("%Y", time.gmtime(int(tag) * TAG)))


def je_jahr(tafeln: dict) -> dict:
    """Je Jahr: H1-Quote mit/ohne (Rücksetzer in 7 T, alle Coins), H3/H4-Wellenquote mit/ohne (BTC+ETH)."""
    out = {"H1": {}, "H3": {}, "H4": {}}
    for coin, T in tafeln.items():
        if T.get("konten") is None:
            continue
        n = T["n"]; ev = np.zeros(n, dtype=bool); ev[T["ev0"]:] = True
        E, _, gl = ZY.ereignis_batch(T["c"][None, :], T["sig"][None, :], H_HAUPT, K_KURS)
        sg, sd = _sig_konten(T); m = gl[0] & sd & ev
        for d in np.nonzero(m)[0]:
            j = _jahr(T["tag0"] + d); z = out["H1"].setdefault(j, [0, 0, 0, 0])
            z[0 if sg[d] else 2] += 1; z[1 if sg[d] else 3] += int(E[0, d])
        if coin in COINS_ANTEIL and T.get("anteil") is not None and T.get("ln_oi_h") is not None:
            w = welle(T, H_HAUPT)
            for key, fn in (("H3", _sig_anteil), ("H4", _sig_anteil_pz)):
                s = fn(T)
                if s is None:
                    continue
                m = w["gl"] & s[1] & ev
                for d in np.nonzero(m)[0]:
                    j = _jahr(T["tag0"] + d); z = out[key].setdefault(j, [0, 0, 0, 0])
                    z[0 if s[0][d] else 2] += 1; z[1 if s[0][d] else 3] += int(w["E"][d])
    return out


def anteil_jahre(tafeln: dict) -> dict:
    out = {}
    for coin in COINS_ANTEIL:
        T = tafeln.get(coin)
        if not T or T.get("anteil") is None:
            continue
        a = T["anteil"]; jahre = {}
        for d in np.nonzero(np.isfinite(a))[0]:
            jahre.setdefault(_jahr(T["tag0"] + d), []).append(d)
        zeilen = {}
        for j, idx in sorted(jahre.items()):
            idx = np.array(idx); x = a[idx]
            sp = {s_: float(v[idx].sum()) for s_, v in T["spot_paare"].items()}; tot = sum(sp.values())
            zeilen[j] = {"n": len(idx), "median": float(np.median(x)), "q10": float(np.quantile(x, 0.1)), "q90": float(np.quantile(x, 0.9)),
                         "ab95": int(np.sum(x >= ANTEIL_ABS)), "spot": {k: v / tot for k, v in sp.items() if tot > 0 and v > 0}}
        out[coin] = zeilen
    return out


# ================================================================================================ U158: CryptoQuant-Anteil (14)
# KONZEPT_Hebel.md 14 (festgelegt 13.10.2026, vor dem Bau und vor jeder Zahl): D = Perps ÷ (Perps + Spot) über alle Börsen in BTC je
# UTC-Tag aus der CryptoQuant-API (kostenloser Schlüssel, Stufe Basic: Tageswerte, 30 Tage Rückschau, 10 Abrufe je Minute); Archiv mit
# Abrufzeit in hebel.db (hb_cq); S5 = D ≥ 0,95 gegen die Liquidationswelle E_D(7) bei BTC wie H3. Wirkung: keine.

CQ_URL = "https://api.cryptoquant.com/v1/btc/market-data/price-ohlcv"
CQ_SEITE = "https://cryptoquant.com/apis"
CQ_MAERKTE = ("spot", "perpetual")
CQ_REIHE = {"spot": "cq:btc:spot:volume", "perpetual": "cq:btc:perpetual:volume"}
CQ_RUECK = 30                                              # Tage je Abruf (Basic: 30 Tage Rückschau)
CQ_AB_S = 3600                                             # frühestens 01:00 UTC: der Vortag ist geschlossen
CQ_PAUSE = {"netz": 3600, "fehler": 3600, "format": 3600, "grenze": 900, "schluessel": 24 * 3600, "credits": 24 * 3600}
CQ_ABSTAND_S = 7.0                                         # zwischen den zwei Abrufen (höchstens 10 je Minute)
CQ_SCHWELLE = 0.95                                         # S5, die Regel wie formuliert
CQ_SHIFT_RAND = 30                                         # Verschiebung τ = 30 … L − 30 Tage
CQ_MIN_L = 180
CQ_BLOCK = 30                                              # Kalender-Blockbootstrap (H3 nutzte 60)
CQ_ZEICHEN = re.compile(r"[A-Za-z0-9._~+/=-]{16,256}")
TOKENS_DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")


def cq_schluessel_lesen(datei: str | None = None) -> tuple:
    """(Schlüssel, Herkunft): Umgebungsvariable CRYPTOQUANT_API_KEY, sonst accesstokens.json -> "cryptoquant" -> "api_key"; sonst ("", "")."""
    k = (os.environ.get("CRYPTOQUANT_API_KEY") or "").strip()
    if k:
        return k, "Umgebungsvariable CRYPTOQUANT_API_KEY"
    try:
        with open(datei or TOKENS_DATEI, encoding="utf-8") as f:
            d = json.load(f)
        k = str((d.get("cryptoquant") or {}).get("api_key") or "").strip()
        return (k, "accesstokens.json") if k else ("", "")
    except (OSError, ValueError, AttributeError):
        return "", ""


def cq_geschwaerzt(text, schluessel: str = "") -> str:
    """Der Schlüssel erscheint nie in Fehlertexten, Bericht oder Anzeige (auch nicht als „Bearer …“ oder api_key=…)."""
    t = str(text or "")
    if schluessel:
        t = t.replace(schluessel, "***")
    t = re.sub(r"(?i)(bearer\s+)[^\s\"',;]+", r"\1***", t)
    return re.sub(r"(?i)(api_key=|access_token=|token=)[^&\s\"']+", r"\1***", t)


def _cq_holen(url: str, schluessel: str, timeout: int = 30) -> tuple:
    """(art, Antwort, Text, HTTP-Code) mit art "ok" | "http" | "netz" | "format" -- wirft nie; Text ohne Schlüssel."""
    req = urllib.request.Request(url, headers={**UA, "Accept": "application/json", "Authorization": f"Bearer {schluessel}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            roh = r.read()
    except urllib.error.HTTPError as e:
        try:
            koerper = e.read()[:300].decode("utf-8", "replace")
        except Exception:
            koerper = ""
        return "http", None, cq_geschwaerzt(f"HTTP {e.code} {koerper}".strip(), schluessel)[:240], int(e.code)
    except Exception as e:
        return "netz", None, cq_geschwaerzt(f"{type(e).__name__}: {e}", schluessel)[:200], None
    try:
        return "ok", json.loads(roh.decode("utf-8")), "", 200
    except (ValueError, UnicodeDecodeError):
        return "format", None, cq_geschwaerzt("Antwort ist kein JSON: " + roh[:80].decode("utf-8", "replace"), schluessel), 200


QUELLE["cq_holen"] = _cq_holen                              # austauschbar für den Selbsttest (ohne Netz)


def cq_url(markt: str, von_tag: int, bis_tag: int) -> str:
    """Tageswerte all_exchange, von/bis als YYYYMMDD (window=day). Der Schlüssel steht nie in der Adresse (Kopfzeile Authorization)."""
    q = {"market": markt, "exchange": "all_exchange", "window": "day", "from": datum_von(von_tag).replace("-", ""),
         "to": datum_von(bis_tag).replace("-", ""), "limit": 100, "format": "json"}
    return CQ_URL + "?" + urllib.parse.urlencode(q)


def cq_parse(d, markt: str, heute: int) -> tuple:
    """
    Dokumentierte Antwortform {"status": {"code": 200, "message": "success"}, "result": {"window": "day", "data": [{"date": "2026-10-12",
    "open": …, "high": …, "low": …, "close": …, "volume": …}]}} -> ([(reihe, tag, volumen in BTC)], Befund). Nur abgeschlossene Tage
    (tag < heute); „kein Wert“ (fehlt, null, leer, NaN, nicht numerisch, ≤ 0) fällt weg; doppelte Tage: nur der erste zählt.
    Befund: Zeilen, verworfen, erster/letzter Tag, Median des Volumens, Felder des ersten Eintrags -- für die Prüfung der Einheit beim
    ersten echten Abruf (all_exchange: laut Doku in BTC).
    """
    b = {"markt": markt, "zeilen": 0, "verworfen": 0, "datum_fehler": 0, "felder": [], "status": None, "fehler": ""}
    if not isinstance(d, dict):
        b["fehler"] = "Antwort ohne JSON-Objekt"
        return [], b
    st = d.get("status") if isinstance(d.get("status"), dict) else {}
    b["status"] = f"{st.get('code')} {st.get('message') or ''}".strip() if st else None
    if st and st.get("code") not in (None, 200, "200"):
        b["fehler"] = f"Status {b['status']}"
        return [], b
    res = d.get("result") if isinstance(d.get("result"), dict) else {}
    daten = res.get("data")
    if not isinstance(daten, list):
        b["fehler"] = "result.data fehlt"
        return [], b
    if res.get("window") not in (None, "day"):
        b["fehler"] = f"window {res.get('window')!r} statt day"
        return [], b
    zeilen, gesehen, vol = [], set(), []
    for e in daten:
        if not isinstance(e, dict):
            b["verworfen"] += 1; continue
        if not b["felder"]:
            b["felder"] = sorted(str(k) for k in e)
        datum = str(e.get("date") or e.get("datetime") or "")[:10]
        try:
            tag = tag_von(datum)
        except (ValueError, OverflowError):
            b["verworfen"] += 1; b["datum_fehler"] += 1; continue
        try:
            v = float(e.get("volume"))
        except (TypeError, ValueError):
            b["verworfen"] += 1; continue
        if not (math.isfinite(v) and v > 0) or tag >= heute or tag in gesehen:
            b["verworfen"] += 1; continue
        gesehen.add(tag); zeilen.append((CQ_REIHE[markt], tag, v)); vol.append(v)
    zeilen.sort(key=lambda z: z[1])
    b["zeilen"] = len(zeilen)
    if zeilen:
        b.update(von=zeilen[0][1], bis=zeilen[-1][1], median=float(np.median(vol)))
    return zeilen, b


def cq_archivieren(con, zeilen: list, abgerufen: int) -> int:
    """(reihe, tag, wert) nach hb_cq: neu, wenn (reihe, tag) noch fehlt oder der Wert von der jüngsten Fassung abweicht -- dann eine neue
    Zeile mit dieser Abrufzeit, die alte bleibt (wie ak_wert). Eine Transaktion mit BEGIN IMMEDIATE. -> neue Zeilen."""
    if not zeilen:
        return 0
    con.execute("BEGIN IMMEDIATE")
    try:
        neu = []
        for reihe, tag, w in zeilen:
            r = con.execute("SELECT wert FROM hb_cq WHERE reihe=? AND tag=? ORDER BY abgerufen DESC LIMIT 1", (reihe, int(tag))).fetchone()
            if r is not None and r[0] is not None and abs(float(r[0]) - w) <= 1e-12 * max(1.0, abs(w)):
                continue
            neu.append((reihe, int(tag), int(abgerufen), float(w)))
        con.executemany("INSERT OR IGNORE INTO hb_cq VALUES (?,?,?,?)", neu)
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    return len(neu)


def _cq_klasse(art: str, code) -> tuple:
    """(Pause in s, Grund) je Fehlerart: Abrufgrenze 15 min, Schlüssel/Zugang und Credits 24 h, sonst 1 h."""
    if art == "netz":
        return CQ_PAUSE["netz"], "Netzfehler"
    if art == "format":
        return CQ_PAUSE["format"], "Antwortform unerwartet"
    if code == 429:
        return CQ_PAUSE["grenze"], "Abrufgrenze erreicht (HTTP 429)"
    if code in (401, 403):
        return CQ_PAUSE["schluessel"], f"Schlüssel abgelehnt oder ohne Zugang (HTTP {code})"
    if code == 402:
        return CQ_PAUSE["credits"], "Credits aufgebraucht (HTTP 402)"
    return CQ_PAUSE["fehler"], f"Fehler (HTTP {code})" if code else "Fehler"


def cq_abruf(pfad: str, jetzt: int | None = None, schluessel: str | None = None, holen=None, erzwingen: bool = False,
             warte=time.sleep) -> dict:
    """
    Einmal am Tag nach 01:00 UTC (14): je Markt (Spot, Perpetual) die letzten 30 abgeschlossenen Tage; ohne Schlüssel kein Abruf. Pause
    bei Fehler (1 h), bei der Abrufgrenze (15 min), bei abgelehntem Schlüssel oder fehlendem Zugang und bei aufgebrauchten Credits
    (24 h). Erst wenn beide Märkte gelesen sind, gilt der Tag als abgerufen. erzwingen: auch vor 01:00 und mehrmals am Tag (von Hand),
    eine Pause gilt trotzdem. Der Schlüssel steht in keinem Text.
    """
    jetzt = int(jetzt if jetzt is not None else time.time()); heute = jetzt // TAG
    k = schluessel if schluessel is not None else cq_schluessel_lesen()[0]
    if not k:
        return {"abruf": False, "grund": "kein Schlüssel"}
    holen = holen or QUELLE["cq_holen"]
    con = verbinden(pfad)
    try:
        pause = int(meta(con, "cq:pause_bis", "0") or 0)
        if pause > jetzt:
            return {"abruf": False, "grund": f"Pause bis {time.strftime('%d.%m. %H:%M', time.gmtime(pause))} UTC"}
        if not erzwingen:
            if jetzt % TAG < CQ_AB_S:
                return {"abruf": False, "grund": "vor 01:00 UTC"}
            if int(meta(con, "cq:ok_tag", "-1") or -1) >= heute:
                return {"abruf": False, "grund": "heute schon abgerufen"}
        von, bis = heute - CQ_RUECK, heute - 1
        befund = {}; neu = 0; zeilen_alle = []
        for i, markt in enumerate(CQ_MAERKTE):
            if i:
                warte(CQ_ABSTAND_S)
            art, d, text, code = holen(cq_url(markt, von, bis), k)
            zeilen, b = cq_parse(d, markt, heute) if art == "ok" else ([], {"markt": markt, "fehler": text})
            if art == "ok" and not zeilen:
                art, text = "format", b.get("fehler") or "keine Tageswerte in der Antwort"
            if art != "ok":
                p_s, grund = _cq_klasse(art, code)
                meta_setzen(con, {"cq:pause_bis": jetzt + p_s, "cq:fehler_ts": jetzt,
                                  "cq:fehler": cq_geschwaerzt(f"{markt}: {grund} -- {text}", k)[:300]})
                return {"abruf": True, "ok": False, "markt": markt, "grund": grund, "pause_s": p_s}
            befund[markt] = b; zeilen_alle += zeilen
        neu = cq_archivieren(con, zeilen_alle, jetzt)
        meta_setzen(con, {"cq:ok_tag": heute, "cq:ok_ts": jetzt, "cq:fehler": "", "cq:neu": neu,
                          "cq:befund": json.dumps(befund, ensure_ascii=False)})
        return {"abruf": True, "ok": True, "neu": neu, "befund": befund}
    finally:
        con.close()


def cq_schluessel_einrichten(schluessel: str, pfad: str | None, datei: str | None = None, holen=None, jetzt: int | None = None) -> tuple:
    """
    -> (ok, Meldung). Für das Feld im Tab „Daten“ (POST /makro/cq_schluessel) und --cq-schluessel: Format prüfen, ein Probeabruf
    (Spot, 3 Tage), in accesstokens.json eintragen (übrige Einträge bleiben, Datei wird atomar ersetzt), Pause und Tagesmarke in
    hebel.db zurücksetzen, damit der Takt binnen 5 Minuten abruft (ab 01:00 UTC). Ein abgelehnter Schlüssel (HTTP 401/403) wird nicht
    geschrieben; bei jedem anderen Fehler im Probeabruf (Netz, Abrufgrenze, Credits, Antwortform) mit Warnung schon. Der Schlüssel
    steht nie in der Meldung.
    """
    datei = datei or TOKENS_DATEI
    k = (schluessel or "").strip()
    if not CQ_ZEICHEN.fullmatch(k):
        return False, (f"CryptoQuant-Schlüssel ungültig: erwartet 16–256 Zeichen ohne Leerzeichen (bekommen: {len(k)} Zeichen). "
                       "Nichts geschrieben.")
    maske = k[:3] + "…" + k[-2:]
    jetzt = int(jetzt if jetzt is not None else time.time()); heute = jetzt // TAG
    art, d, text, code = (holen or QUELLE["cq_holen"])(cq_url("spot", heute - 3, heute - 1), k)
    if art == "http" and code in (401, 403):                   # nur ein abgelehnter Schlüssel wird nicht geschrieben
        _, grund = _cq_klasse(art, code)
        return False, cq_geschwaerzt(f"CryptoQuant lehnt den Probeabruf mit {maske} ab: {grund} -- {text}"[:260], k) + ". Nichts geschrieben."
    n = len(cq_parse(d, "spot", heute)[0]) if art == "ok" else 0
    probe = (f"{n} Tageswerte (Spot, alle Börsen)." if art == "ok" and n else
             f"ohne Tageswerte (Antwortform?) -- Schlüssel trotzdem gespeichert, der Bericht zeigt die Antwort." if art == "ok" else
             f"{_cq_klasse(art, code)[1]} ({cq_geschwaerzt(text, k)[:100]}) -- Schlüssel trotzdem gespeichert.")
    roh: dict = {}
    if os.path.exists(datei):
        try:
            with open(datei, encoding="utf-8") as f:
                roh = json.load(f)
        except ValueError as e:
            return False, f"{os.path.basename(datei)} ist kein gültiges JSON ({e}) -- nichts überschrieben. Bitte die Datei prüfen."
        if not isinstance(roh, dict):
            return False, f"{os.path.basename(datei)} hat kein JSON-Objekt -- nichts überschrieben."
    eintrag = roh.get("cryptoquant") if isinstance(roh.get("cryptoquant"), dict) else {}
    eintrag["api_key"] = k
    eintrag.setdefault("_wofuer", "U158: Anteil der Perpetuals am BTC-Volumen aller Börsen (api.cryptoquant.com, kostenlose Stufe Basic: "
                                  + CQ_SEITE + ")")
    roh["cryptoquant"] = eintrag
    tmp = datei + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(roh, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, datei)
    z = [f"CryptoQuant-Schlüssel {maske} in {os.path.basename(datei)} eingetragen. Probeabruf: {probe}"]
    if (os.environ.get("CRYPTOQUANT_API_KEY") or "").strip():
        z.append("Hinweis: Die Umgebungsvariable CRYPTOQUANT_API_KEY ist gesetzt und hat Vorrang vor der Datei.")
    if pfad:
        con = verbinden(pfad)
        try:
            meta_setzen(con, {"cq:pause_bis": 0, "cq:ok_tag": -1})
        finally:
            con.close()
        z.append("Der Hebel-Takt ruft binnen 5 Minuten ab (frühestens 01:00 UTC), danach einmal am Tag.")
    return True, " ".join(z)


def cq_tage(con) -> dict:
    """Jüngste Fassung je Reihe und Tag; D = Perps ÷ (Perps + Spot) an Tagen mit beiden Werten. -> {"tage", "D", "spot", "perp",
    "fassungen"} (Arrays, aufsteigend) -- leer, wenn nichts da ist."""
    werte = {"spot": {}, "perpetual": {}}; fass = 0
    try:
        rows = con.execute("SELECT reihe, tag, wert, abgerufen FROM hb_cq ORDER BY reihe, tag, abgerufen").fetchall()
    except sqlite3.Error:
        rows = []
    umgekehrt = {v: k for k, v in CQ_REIHE.items()}
    for reihe, tag, w, _ in rows:
        m = umgekehrt.get(reihe)
        if m is None:
            continue
        if int(tag) in werte[m]:
            fass += 1
        werte[m][int(tag)] = w                                  # aufsteigend nach Abrufzeit: die jüngste Fassung bleibt
    tage = sorted(set(werte["spot"]) & set(werte["perpetual"]))
    tage = [t for t in tage if (werte["spot"][t] or 0) > 0 and (werte["perpetual"][t] or 0) > 0]
    sp = np.array([werte["spot"][t] for t in tage], dtype=float); pe = np.array([werte["perpetual"][t] for t in tage], dtype=float)
    return {"tage": np.array(tage, dtype=np.int64), "D": pe / (pe + sp) if len(tage) else np.zeros(0), "spot": sp, "perp": pe,
            "revisionen": fass, "nur_spot": len(set(werte["spot"]) - set(werte["perpetual"])),
            "nur_perp": len(set(werte["perpetual"]) - set(werte["spot"]))}


def cq_stand(pfad: str, jetzt: int | None = None) -> dict:
    """Für den Tab „Daten“ und den Bericht (nur lesend): Schlüssel da?, letzter Abruf, Fehler (ohne Schlüssel), Pause, Tage, Befund."""
    k, herkunft = cq_schluessel_lesen()
    out = {"schluessel": bool(k), "herkunft": herkunft, "seite": CQ_SEITE, "tage": 0}
    con = _lesen(pfad)
    if con is None:
        return out
    try:
        out.update(ok_ts=int(meta(con, "cq:ok_ts", "0") or 0) or None, fehler=cq_geschwaerzt(meta(con, "cq:fehler", "") or "", k),
                   fehler_ts=int(meta(con, "cq:fehler_ts", "0") or 0) or None, pause_bis=int(meta(con, "cq:pause_bis", "0") or 0))
        try:
            out["befund"] = json.loads(meta(con, "cq:befund", "{}") or "{}")
        except ValueError:
            out["befund"] = {}
        A = cq_tage(con)
        if len(A["tage"]):
            out.update(tage=len(A["tage"]), von=int(A["tage"][0]), bis=int(A["tage"][-1]), letzter=float(A["D"][-1]),
                       ab95=int(np.sum(A["D"] >= CQ_SCHWELLE)), revisionen=A["revisionen"])
    finally:
        con.close()
    if out.get("fehler") and out.get("ok_ts") and out.get("fehler_ts") and out["ok_ts"] > out["fehler_ts"]:
        out["fehler"] = ""                                     # ein späterer Erfolg löscht den alten Fehler aus der Anzeige
    return out


def cq_chart(pfad: str) -> dict | None:
    """Reihe für den Tab „Hebel & Stimmung“ (nur lesend): Tage und D; None ohne Daten."""
    con = _lesen(pfad)
    if con is None:
        return None
    try:
        A = cq_tage(con)
    finally:
        con.close()
    if not len(A["tage"]):
        return None
    return {"t": [int(t) for t in A["tage"]], "v": [round(float(x), 5) for x in A["D"]], "schwelle": CQ_SCHWELLE,
            "ab95": int(np.sum(A["D"] >= CQ_SCHWELLE))}


def s5_rechnen(T: dict, A: dict, n_boot: int = N_BOOT, saat: int = SAAT) -> dict:
    """
    S5 (14): Fenster = gesammelte Reihe [erster, letzter Tag] (L Tage) auf der BTC-Tafel; Signal D_d ≥ 0,95 (Entscheidung am Ende von
    Tag d), Ereignis E_D(7) wie H3 (welle), gültig ab ev0. RR mit/ohne; Null: zirkuläre Verschiebung des Signals um jedes τ von 30 bis
    L − 30 Tage, einseitig; Hälften: Kalenderhälften des Fensters, RR über dem Null-Median je Hälfte; 90 % aus dem zirkulären
    Kalender-Blockbootstrap (Block 30 Tage). Prüfbar ab 30 Signaltagen in 3 Episoden, 30 gültigen Tagen ohne Signal und L ≥ 180.
    Beschreibend: Perzentil der eigenen 90 Tage (ab 60 Werten) ≥ 0,90 gegen E_D(7) mit derselben Null, Richtung der Wellen, Abstand zu
    Binance allein (Perp-Anteil H3) am selben Tag, Tage ≥ 95 % je Monat.
    """
    out = {"L": 0, "pruefbar": False, "belegt": False}
    tage = np.asarray(A.get("tage"), dtype=np.int64)
    if not len(tage) or T is None:
        out["grund"] = "keine CryptoQuant-Tage" if not len(tage) else "keine BTC-Tafel"
        return out
    t0 = int(tage[0]); L = int(tage[-1]) - t0 + 1
    D = np.full(L, np.nan); D[tage - t0] = np.asarray(A["D"], dtype=float)
    w = welle(T, H_HAUPT)
    E = np.zeros(L, dtype=bool); val = np.zeros(L, dtype=bool); richt = np.zeros(L, dtype=np.int8); bnc = np.full(L, np.nan)
    j = np.arange(L); i = t0 - T["tag0"] + j; da = (i >= 0) & (i < T["n"])
    ii = i[da]
    E[da] = w["E"][ii]; val[da] = w["gl"][ii] & (ii >= T["ev0"]); richt[da] = w["richt"][ii]
    if T.get("anteil") is not None:
        bnc[da] = T["anteil"][ii]
    sdef = np.isfinite(D)
    with np.errstate(invalid="ignore"):
        sig = sdef & (D >= CQ_SCHWELLE)
    k4 = _k4(sig, sdef, E, val); rr = _rr4(k4)
    taus = np.arange(CQ_SHIFT_RAND, L - CQ_SHIFT_RAND + 1)
    mi = L // 2; h1 = j < mi
    rr_t = np.full(len(taus), np.nan); rr_h = [np.full(len(taus), np.nan), np.full(len(taus), np.nan)]
    for n_, t in enumerate(taus):
        s2 = np.roll(sig, int(t)); d2 = np.roll(sdef, int(t))
        rr_t[n_] = _rr4(_k4(s2, d2, E, val))
        rr_h[0][n_] = _rr4(_k4(s2, d2, E, val, h1)); rr_h[1][n_] = _rr4(_k4(s2, d2, E, val, ~h1))
    hv = {0: (_rr4(_k4(sig, sdef, E, val, h1)), ZY._nanmed(rr_h[0])), 1: (_rr4(_k4(sig, sdef, E, val, ~h1)), ZY._nanmed(rr_h[1]))}
    kal = np.stack([sig & sdef & val & E, sig & sdef & val & ~E, ~sig & sdef & val & E, ~sig & sdef & val & ~E]).astype(float)
    epi = _episoden(np.nonzero(sig & sdef & val)[0], H_HAUPT)
    p = ZY._p_groesser(rr, rr_t) if len(taus) else float("nan")
    treffer = sig & sdef & val & E
    out.update(L=L, von=t0, bis=int(tage[-1]), tage_mit_wert=int(sdef.sum()), k4=[int(x) for x in k4], rr=rr, p=p,
               null_median=ZY._nanmed(rr_t), n_shift=int(len(taus)), haelften_werte=hv, signaltage=int(k4[0] + k4[1]),
               ohne=int(k4[2] + k4[3]), episoden=epi, p_sig=k4[0] / (k4[0] + k4[1]) if k4[0] + k4[1] else float("nan"),
               p_ohne=k4[2] / (k4[2] + k4[3]) if k4[2] + k4[3] else float("nan"),
               q=ZY._rr_bootstrap(kal, n_boot, CQ_BLOCK, saat + 158) if L >= 2 * CQ_BLOCK else (float("nan"), float("nan")),
               richtung={"ab": int(np.sum(treffer & (richt == 1))), "auf": int(np.sum(treffer & (richt == 2))),
                         "beide": int(np.sum(treffer & (richt == 3)))},
               gueltig=int(np.sum(sdef & val)))
    out["haelften"] = all(np.isfinite(a) and np.isfinite(b) and a > b for a, b in hv.values())
    out["pruefbar"] = bool(np.isfinite(p) and out["signaltage"] >= MIN_SIGNALTAGE and epi >= MIN_EPISODEN and out["ohne"] >= MIN_OHNE
                           and L >= CQ_MIN_L)
    out["belegt"] = bool(out["pruefbar"] and p < ALPHA and out["haelften"])
    # beschreibend (ohne Urteil)
    pz = ZY.oi_perzentil(D, PERZ_FENSTER, PERZ_MIN)
    pdef = np.isfinite(pz)
    with np.errstate(invalid="ignore"):
        psig = pdef & (pz >= ANTEIL_PZ)
    k4p = _k4(psig, pdef, E, val)
    rr_p = np.array([_rr4(_k4(np.roll(psig, int(t)), np.roll(pdef, int(t)), E, val)) for t in taus]) if len(taus) else np.zeros(0)
    out["perzentil"] = {"k4": [int(x) for x in k4p], "rr": _rr4(k4p), "p": ZY._p_groesser(_rr4(k4p), rr_p) if len(rr_p) else float("nan"),
                        "null_median": ZY._nanmed(rr_p), "tage": int(pdef.sum())}
    ab = np.isfinite(bnc) & sdef
    if ab.any():
        dd = D[ab] - bnc[ab]
        out["binance"] = {"n": int(ab.sum()), "median": float(np.median(dd)), "q10": float(np.quantile(dd, 0.1)),
                          "q90": float(np.quantile(dd, 0.9)), "bnc_median": float(np.median(bnc[ab]))}
    monate_: dict = {}
    for tg, x in zip(tage, A["D"]):
        m_ = monat_von(int(tg)); z = monate_.setdefault(m_, [0, 0])
        z[1] += 1; z[0] += int(x >= CQ_SCHWELLE)
    out["je_monat"] = monate_
    out["heute"] = float(A["D"][-1]); out["median"] = float(np.median(A["D"])); out["ab95"] = int(np.sum(np.asarray(A["D"]) >= CQ_SCHWELLE))
    return out


def s5_grund(S: dict) -> str:
    """Warum (noch) nicht prüfbar -- „n Signaltage, m Episoden, L Tage“ wie 14."""
    if S.get("grund"):
        return S["grund"]
    g = []
    if S.get("signaltage", 0) < MIN_SIGNALTAGE:
        g.append(f"{S.get('signaltage', 0)} Signaltage < {MIN_SIGNALTAGE}")
    if S.get("episoden", 0) < MIN_EPISODEN:
        g.append(f"{S.get('episoden', 0)} Episoden < {MIN_EPISODEN}")
    if S.get("ohne", 0) < MIN_OHNE:
        g.append(f"{S.get('ohne', 0)} gültige Tage ohne Signal < {MIN_OHNE}")
    if S.get("L", 0) < CQ_MIN_L:
        g.append(f"{S.get('L', 0)} Tage < {CQ_MIN_L}")
    return ", ".join(g) or "kein p"


def s5_urteil_festhalten(con, S: dict, jetzt: int) -> dict | None:
    """
    „Die erste prüfbare Auswertung ist das Urteil“ (14): Ist S5 prüfbar und noch kein Urteil abgelegt, wird es einmal in hb_meta
    „s5_urteil“ geschrieben (BEGIN IMMEDIATE); danach nur gelesen, nie überschrieben. -> das gültige Urteil oder None.
    """
    alt = meta(con, "s5_urteil")
    if alt:
        try:
            return json.loads(alt)
        except ValueError:
            return {"fehler": "s5_urteil unlesbar"}
    if not S.get("pruefbar"):
        return None
    U = {"stand": int(jetzt), "L": S["L"], "von": S["von"], "bis": S["bis"], "rr": S["rr"], "p": S["p"], "null_median": S["null_median"],
         "q": list(S["q"]), "haelften": bool(S["haelften"]), "haelften_werte": {str(k): list(v) for k, v in S["haelften_werte"].items()},
         "signaltage": S["signaltage"], "episoden": S["episoden"], "ohne": S["ohne"], "belegt": bool(S["belegt"]), "version": VERSION_MODUL}
    con.execute("BEGIN IMMEDIATE")
    try:
        r = con.execute("SELECT v FROM hb_meta WHERE k='s5_urteil'").fetchone()
        if r and r[0]:                                           # ein anderer Lauf war schneller: dessen Urteil gilt
            con.execute("COMMIT")
            return json.loads(r[0])
        con.execute("INSERT INTO hb_meta VALUES ('s5_urteil', ?)", (json.dumps(U, allow_nan=True),))
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    return U


def btc_tafel(db: str) -> tuple:
    """Nur BTC aus hebel.db (Perp- und Spot-Tageskerzen, metrics) -> (Tafel oder None, Info). Leichter als daten_laden."""
    pfad = hebel_pfad(db); con = _lesen(pfad)
    if con is None:
        return None, f"hebel.db fehlt ({pfad})"
    try:
        K = {}
        for markt, symbol, coin in symbole():
            if coin != "BTC":
                continue
            rows = con.execute("SELECT tag, h, l, c, v_usd, taker_usd FROM hb_kerzen WHERE markt=? AND symbol=? ORDER BY tag", (markt, symbol)).fetchall()
            if rows:
                a = np.array(rows, dtype=float)
                K[(markt, symbol)] = {"tag": a[:, 0].astype(np.int64), "h": a[:, 1], "l": a[:, 2], "c": a[:, 3], "v_usd": a[:, 4], "taker_usd": a[:, 5]}
        rows = con.execute("SELECT ts, oi, oi_usd, top_konten, top_pos, konten, taker FROM hb_metrics WHERE coin='BTC' ORDER BY ts").fetchall()
        M = None
        if rows:
            a = np.array(rows, dtype=float)
            M = {"ts": a[:, 0].astype(np.int64), "oi": a[:, 1], "oi_usd": a[:, 2], "top_konten": a[:, 3], "top_pos": a[:, 4], "konten": a[:, 5],
                 "taker": a[:, 6]}
    finally:
        con.close()
    if ("um", "BTCUSDT") not in K:
        return None, "keine Tageskerzen des Perpetuals BTCUSDT"
    T = tafel_bauen("BTC", K, M)
    return T, "" if T is not None else "zu wenige Tage"


def s5_bericht(db: str, jetzt: int | None = None, n_boot: int = N_BOOT, festhalten: bool = True) -> str:
    """„★ Hebel: CryptoQuant-Anteil der Derivate (U158)“ -- Abruf, Kennzahl, Urteil S5 (einmal festgehalten), Beschreibendes."""
    jetzt = int(jetzt if jetzt is not None else time.time())
    pfad = hebel_pfad(db)
    Z = []; a = Z.append
    a(f"★ Hebel: CryptoQuant-Anteil der Perpetuals am BTC-Volumen aller Börsen (U158) · Modul {VERSION_MODUL}")
    a("Vorab festgelegt in KONZEPT_Hebel.md 14 (13.10.2026). Nur Bericht; wirkt auf nichts (nicht Konfluenz, Labor, Prognose, Treiber,")
    a("Ausblick). Keine Anlageberatung -- gezählt wird, was war.")
    st = cq_stand(pfad, jetzt)
    a("")
    a("ABRUF (api.cryptoquant.com, btc/market-data/price-ohlcv, exchange=all_exchange, window=day; einmal am Tag nach 01:00 UTC)")
    if not st["schluessel"]:
        a(f"  kein Schlüssel -- kein Abruf. Eintragen im Dashboard: Makro, Tab „Daten“, Feld „CryptoQuant-Schlüssel (kostenlos)“ ({CQ_SEITE}),")
        a("  oder accesstokens.json -> \"cryptoquant\" -> \"api_key\".")
    else:
        a(f"  Schlüssel: vorhanden ({st['herkunft']}) · letzter Erfolg: "
          + (time.strftime("%d.%m.%Y %H:%M UTC", time.gmtime(st["ok_ts"])) if st.get("ok_ts") else "noch keiner")
          + (f" · Pause bis {time.strftime('%d.%m. %H:%M UTC', time.gmtime(st['pause_bis']))}" if st.get("pause_bis", 0) > jetzt else ""))
        if st.get("fehler"):
            a(f"  letzter Fehler: {st['fehler']}")
    for markt, b in sorted((st.get("befund") or {}).items()):
        a(f"  Antwort {markt}: Status {b.get('status') or '—'}, {b.get('zeilen', 0)} Tage"
          + (f" ({_dt(b['von'])}–{_dt(b['bis'])})" if b.get("von") is not None else "") + f", verworfen {b.get('verworfen', 0)}"
          + (f" (davon Datum unlesbar {b['datum_fehler']} -- Datumsformat prüfen)" if b.get("datum_fehler") else "")
          + (f", Volumen Median {_tausend(b['median'])} (Einheit laut Doku BTC)" if b.get("median") is not None else "")
          + (f"; Felder {', '.join(b.get('felder') or [])}" if b.get("felder") else "") + (f"; {b['fehler']}" if b.get("fehler") else ""))
    con = _lesen(pfad)
    A = cq_tage(con) if con is not None else {"tage": np.zeros(0, dtype=np.int64), "D": np.zeros(0)}
    if con is not None:
        con.close()
    a("")
    a("KENNZAHL D = Perps ÷ (Perps + Spot), in BTC, je UTC-Tag (CryptoQuant kennt Spot und Perpetuals, keine Termin-Futures)")
    if not len(A["tage"]):
        a("  noch keine Tage mit beiden Werten.")
    else:
        a(f"  {len(A['tage'])} Tage ({_dt(int(A['tage'][0]))}–{_dt(int(A['tage'][-1]))}), zuletzt {_pr(float(A['D'][-1]))}, Median "
          f"{_pr(float(np.median(A['D'])))}, Spanne {_pr(float(np.min(A['D'])))}–{_pr(float(np.max(A['D'])))}; ≥ 95 % an "
          f"{int(np.sum(A['D'] >= CQ_SCHWELLE))} Tagen; Revisionen {A.get('revisionen', 0)}"
          + (f"; nur Spot an {A['nur_spot']} Tagen" if A.get("nur_spot") else "") + (f"; nur Perps an {A['nur_perp']} Tagen" if A.get("nur_perp") else ""))
    T, info = btc_tafel(db)
    S = s5_rechnen(T, A, n_boot) if len(A["tage"]) else {"L": 0, "grund": "noch keine CryptoQuant-Tage", "pruefbar": False}
    U = None
    if festhalten and len(A["tage"]):
        cw = verbinden(pfad)
        try:
            U = s5_urteil_festhalten(cw, S, jetzt)
        finally:
            cw.close()
    a("")
    a("S5: D ≥ 95 % am Ende von Tag d -> Liquidationswelle E_D(7) bei BTC (OI-Abbau mit großem Ausschlag, wie H3)")
    if info:
        a(f"  BTC-Tafel: {info}")
    if U and not U.get("fehler"):
        q = U.get("q") or [float("nan"), float("nan")]
        a(f"  URTEIL (erste prüfbare Auswertung vom {time.strftime('%d.%m.%Y', time.gmtime(U['stand']))}, festgehalten): "
          + ("✓ belegt" if U.get("belegt") else "nicht belegt")
          + f" -- RR {_r(U.get('rr'))} (90 %: {_r(q[0])}–{_r(q[1])}), Null {_r(U.get('null_median'))}, p {_pz(U.get('p'))}, Hälften "
          + ("beide über der Null" if U.get("haelften") else "nicht beide über der Null")
          + f"; {U.get('signaltage')} Signaltage in {U.get('episoden')} Episoden, L {U.get('L')} Tage")
        a("  Das Urteil wird nicht neu gefällt („die erste prüfbare Auswertung ist das Urteil“); die Zahlen unten sind beschreibend.")
    elif U and U.get("fehler"):
        a(f"  Urteil: {U['fehler']}")
    else:
        a(f"  noch nicht prüfbar ({s5_grund(S)}) -- kein Urteil.")
    if S.get("L"):
        q = S.get("q") or (float("nan"), float("nan"))
        a(f"  {'heute (beschreibend)' if U else 'Stand'}: Quote {_pr(S.get('p_sig'))} nach Signal gegen {_pr(S.get('p_ohne'))} sonst, RR "
          f"{_r(S.get('rr'))} (90 %: {_r(q[0])}–{_r(q[1])}), Null {_r(S.get('null_median'))} aus {S.get('n_shift')} Verschiebungen, "
          f"p {_pz(S.get('p'))}; {S.get('signaltage')} Signaltage in {S.get('episoden')} Episoden, {S.get('ohne')} gültige Tage ohne, "
          f"L {S.get('L')} Tage")
        hv = S.get("haelften_werte") or {}
        if hv:
            a("  Hälften: " + " · ".join(f"{k + 1}. Hälfte RR {_r(v[0])} gegen Null {_r(v[1])}" for k, v in sorted(hv.items())))
        r = S.get("richtung") or {}
        a(f"  Wellen nach S5-Tagen: ab {r.get('ab', 0)}, auf {r.get('auf', 0)}, beide {r.get('beide', 0)}")
        pz = S.get("perzentil") or {}
        a(f"  beschreibend: D im obersten Zehntel der eigenen 90 Tage (ab 60 Werten, wie H4): RR {_r(pz.get('rr'))}, Null "
          f"{_r(pz.get('null_median'))}, p {_pz(pz.get('p'))} ({pz.get('tage', 0)} Tage mit Perzentil)")
        bn = S.get("binance")
        if bn:
            a(f"  Abstand zu Binance allein (Perp-Anteil aus H3) am selben Tag: Median {_de(bn['median'] * 100, 1, True)} Punkte (10–90 %: "
              f"{_de(bn['q10'] * 100, 1, True)} … {_de(bn['q90'] * 100, 1, True)}), Binance Median {_pr(bn['bnc_median'])}, {bn['n']} Tage")
        jm = sorted((S.get("je_monat") or {}).items())[-12:]
        if jm:
            a("  Tage ≥ 95 % je Monat (letzte 12): " + " · ".join(f"{m[5:]}/{m[:4]} {z[0]} von {z[1]}" for m, z in jm))
    a("")
    a("LESART")
    a("  Prüfbar erst ab 30 Signaltagen in 3 Episoden, 30 gültigen Tagen ohne Signal und 180 Tagen Reihe. Tage mit 95 % sind selten;")
    a("  das kann ein Jahr oder länger dauern. Erwartung vorab: RR nahe 1 bis 1,5 (nach hohem Binance-Anteil kamen Wellen eher seltener).")
    a(f"  Nachweisgrenze (Selbsttest): {CQ_NACHWEIS}.")
    return "\n".join(Z)


# ================================================================================================ Studie

def studie_rechnen(tafeln: dict, n_surr: int = N_SURR, n_boot: int = N_BOOT, vollstaendig: bool = True, log=print, saat: int = SAAT) -> dict:
    t0 = time.time()
    V = {"n_surr": n_surr, "n_boot": n_boot, "n_shift": len(shifts())}
    log("  Positionierung (H1, H2) gegen Vorzeichen-Surrogate …")
    V["richtung"] = richtungs_tests(tafeln, n_surr, n_boot, log, saat)
    log("  Perp-Anteil (H3, H4) gegen Zeitverschiebung …")
    V["risiko"], V["basis"] = risiko_tests(tafeln, n_boot, log, saat)
    urteile(V, vollstaendig)
    log("  nachträglich (12.3, beschreibend): H1 geschichtet nach der Rendite der 7 Tage davor …")
    V["h1_geschichtet"] = h1_geschichtet(tafeln, n_surr, saat, log=log)
    V["rechenzeit"] = time.time() - t0
    return V


def studie(db: str, n_surr: int = N_SURR) -> str:
    t0 = time.time()
    print("Hebel-Studie (U142): Daten lesen …", flush=True)
    L = daten_laden(db)
    for coin, T in L["tafeln"].items():
        print(f"  {coin}: Kurs {_dt(T['tag0'])}–{_dt(T['tag0'] + T['n'] - 1)}, metrics ab {_dt(T['metrics_ab']) if T.get('metrics_ab') else '—'}",
              flush=True)
    for f in L["info"]["fehlt"]:
        print(f"  fehlt: {f}", flush=True)
    voll = bool(L["laden"] and L["laden"]["vollstaendig"])
    print("Rechnen …", flush=True)
    V = studie_rechnen(L["tafeln"], n_surr, N_BOOT, voll, log=lambda s: print(s, flush=True)) if L["tafeln"] else {"richtung": {}, "risiko": {},
                                                                                                                      "basis": {}, "rechenzeit": 0.0}
    V["tafeln"] = L["tafeln"]; V["info"] = L["info"]; V["laden"] = L["laden"]; V["sicherung"] = L.get("sicherung"); V["liq_tage"] = L.get("liq_tage")
    V["je_jahr"] = je_jahr(L["tafeln"]); V["anteil_jahre"] = anteil_jahre(L["tafeln"])
    V["abgleich"] = abgleich(db, L.get("roh_m") or {})
    V["stand"] = stand_heute(L["tafeln"], live_werte(db))
    return bericht_text(V, time.time() - t0)


# ================================================================================================ Bericht

def _urteil_text(o: dict, voll: bool) -> str:
    if not o or not o.get("coins"):
        return "ohne Daten"
    if not o.get("pruefbar"):
        grund = []
        if o.get("signaltage", 0) < MIN_SIGNALTAGE:
            grund.append(f"{o.get('signaltage', 0)} Signaltage < {MIN_SIGNALTAGE}")
        if o.get("episoden", 0) < MIN_EPISODEN:
            grund.append(f"{o.get('episoden', 0)} Episoden < {MIN_EPISODEN}")
        if o.get("art") != "richtung" and o.get("ohne", 0) < MIN_OHNE:
            grund.append(f"{o.get('ohne', 0)} Tage ohne Signal < {MIN_OHNE}")
        return "nicht prüfbar (" + ", ".join(grund or ["kein p"]) + ")"
    if o.get("bedingung"):
        return "✓ belegt" if voll else "wäre belegt -- VORLÄUFIG (Historie unvollständig)"
    teile = []
    if not (np.isfinite(o.get("p_holm", np.nan)) and o["p_holm"] < ALPHA):
        teile.append(f"p Holm {_pz(o.get('p_holm'))}")
    if not o.get("haelften"):
        teile.append("Hälften nicht gleich")
    return "nicht belegt (" + ", ".join(teile) + ")" + ("" if voll else ", vorläufig")


def _zeile_rr(o: dict) -> str:
    q = o.get("q") or (float("nan"), float("nan"))
    return (f"Quote {_pr(o.get('p_sig'))} nach Signal gegen {_pr(o.get('p_ohne'))} sonst, RR {_r(o.get('rr'))} (90 %: {_r(q[0])}–{_r(q[1])}), "
            f"Null {_r(o.get('null_median'))}, p {_pz(o.get('p'))}")


def _zeile_t(o: dict) -> str:
    q = o.get("q") or (float("nan"), float("nan"))
    return (f"T {_de(o.get('t'), 3, True)} σ (90 %: {_de(q[0], 3, True)}…{_de(q[1], 3, True)}), Null {_de(o.get('null_median'), 3, True)}, "
            f"Treffer {_pr(o.get('treffer'), 0)}, p zweiseitig {_pz(o.get('p'))}")


def bericht_text(V: dict, laufzeit: float | None = None) -> str:
    Z = []; a = Z.append
    voll = bool(V.get("vollstaendig"))
    a(f"★ Hebel: Positionierung und Hebel gegen Spot (U142) · Modul {VERSION_MODUL}")
    a("Vorab festgelegt in KONZEPT_Hebel.md (09.10.2026), vor diesem Lauf. Nur Bericht, nur lesend. „Belegt“ heißt: die vorab festgelegte")
    a("Bedingung ist erfüllt, nicht mehr. Keine Anlageberatung -- die Studie misst, was war.")
    a(f"Nullmodelle: {V.get('n_surr')} Vorzeichen-Surrogate für H1/H2 (ein Vorzeichen je Kalendertag für alle Coins, Drift und Schwankung "
      f"bleiben), {V.get('n_shift')} Zeitverschiebungen für H3/H4 (30–365 Tage, beide Richtungen); Rechenzeit {_de(V.get('rechenzeit'), 0)} s"
      + (f", Laufzeit gesamt {_de(laufzeit, 0)} s" if laufzeit else "") + ".")
    a("")
    _bericht_daten(V, a)
    _bericht_ergebnis(V, a, voll)
    _bericht_stand(V, a)
    _bericht_einzeln(V, a)
    _bericht_beschreibend(V, a)
    _bericht_nachtrag(V, a)
    a("LESART")
    a("  H1 und H2 zählen nur Richtung: Ein Signal, das bloß hohe Schwankung anzeigt, erzeugt auch auf den Surrogaten mehr Rücksetzer.")
    a("  H3 und H4 fragen nach Risiko: Kommt nach dem Signal öfter eine Liquidationswelle (OI-Abbau mit großem Ausschlag, egal wohin)")
    a("  als an anderen Tagen derselben Jahre? Die Zeitverschiebung behält alle Ballungen und löst nur „Signal vor Welle“. Der")
    a("  Mantel-Haenszel-RR über die Schwankungsdrittel zeigt, ob das Signal über die heutige Schwankung hinaus etwas sagt.")
    a("  „Fast immer“ ist kein Maßstab: Zählt nur die Quote nach dem Signal, sieht jedes Signal gut aus, wenn Wellen ohnehin häufig sind.")
    a("  Echtes Geld nur nach belegter Historie und mindestens 6 Monaten Beobachtung ohne Widerspruch, nie automatisch.")
    return "\n".join(Z)


def _bericht_daten(V: dict, a) -> None:
    info = V.get("info") or {}; L = V.get("laden")
    a(f"DATEN (hebel.db: {info.get('pfad', '—')})")
    if L is None:
        a("  hebel.db fehlt -- der Hebel-Takt legt sie nach dem Einspielen an und lädt das Archiv im Hintergrund (rund 2–3 h).")
    else:
        a("  Ladestand: " + ("vollständig" if L["vollstaendig"] else "NOCH NICHT VOLLSTÄNDIG -- alle Urteile vorläufig (der Hebel-Takt lädt weiter)")
          + (f"; Netzpause bis {time.strftime('%d.%m. %H:%M', time.localtime(L['pause_bis']))}" if L.get("pause_bis", 0) > time.time() else "")
          + (f"; letzter Fehler: {L['fehler']}" if L.get("fehler") else ""))
        for coin, o in L["coins"].items():
            a(f"  metrics {coin:<5} " + (f"{time.strftime('%d.%m.%Y', time.gmtime(o['von']))}–{time.strftime('%d.%m.%Y %H:%M', time.gmtime(o['bis']))} UTC, "
                                         f"{_tausend(o['zeilen'])} Stunden, " if o["zeilen"] else "keine Zeilen, ")
              + ("fertig" if o["fertig"] else "lädt") + (f", {o['fehlend']} Tage ohne Datei" if o["fehlend"] else ""))
        teile = []
        for (markt, symbol), o in L["kerzen"].items():
            if o.get("widerspruch"):
                teile.append(f"{markt} {symbol} WIDERSPRUCH ({o.get('ohne_zeilen')} gemerkte Monatsdateien ohne Zeilen)")
            elif o["tage"]:
                teile.append(f"{markt} {symbol} {_dt(o['von'])}–{_dt(o['bis'])}" + (f" ({o['offen']} Monate offen)" if o["offen"] > 1 else ""))
            elif o["offen"] > 1:
                teile.append(f"{markt} {symbol} lädt")
            else:
                teile.append(f"{markt} {symbol} ohne Datei")
        for i in range(0, len(teile), 3):
            a("  Kerzen: " + " · ".join(teile[i:i + 3]))
    for coin, T in (V.get("tafeln") or {}).items():
        extra = []
        if T["gefuellt"]:
            extra.append(f"{T['gefuellt']} Tage aufgefüllt")
        if T["lange_luecken"]:
            extra.append("beginnt nach einer Lücke " + ", ".join(f"{_dt(x)}–{_dt(y)}" for x, y in T["lange_luecken"][-2:]))
        a(f"  Kurs {coin:<5} {_dt(T['tag0'])}–{_dt(T['tag0'] + T['n'] - 1)}, bewertet ab {_dt(T['tag0'] + T['ev0'])}"
          + (f"; {'; '.join(extra)}" if extra else ""))
    for f in info.get("fehlt", []):
        a(f"  fehlt: {f}")
    a("")


def _bericht_ergebnis(V: dict, a, voll: bool) -> None:
    alle = {**(V.get("richtung") or {}), **(V.get("risiko") or {})}
    a("ERGEBNIS (Regeln vorab, KONZEPT_Hebel.md 5)" + ("" if voll else " -- VORLÄUFIG, Historie unvollständig"))
    for k, titel in HAUPT:
        o = alle.get(k) or {}
        a(f"  {k} {titel}:")
        if not o.get("coins"):
            a("     ohne Daten")
            continue
        det = _zeile_t(o) if o.get("art") == "richtung" else _zeile_rr(o)
        a(f"     {det}; p Holm {_pz(o.get('p_holm'))}; Hälften {'✓' if o.get('haelften') else '✗'}; "
          f"{o.get('signaltage')} Signaltage in {o.get('episoden')} Episoden ({', '.join(o['coins'])})")
        a(f"     -> {_urteil_text(o, voll)}")
    a("  Was daraus folgt (vorab, KONZEPT_Hebel.md 8):")
    for k, ja, nein in (("H1", "der Hinweis „Kaskadenrisiko nach unten“ bekommt eine gemessene Grundlage",
                         "Vorschlag: Hinweis entfernen oder als „ungeprüft“ kennzeichnen (Entscheidung Nutzer)"),
                        ("H2", "Konfluenz-Punkt bleibt bzw. wird umgedreht (Richtung siehe T)",
                         "Vorschlag: Konfluenz-Punkt der Top-Trader entfernen (Entscheidung Nutzer)"),
                        ("H3", "Kandidat für eine Warnkachel „Hebel-Anteil hoch“ (eigener Plan-Punkt)", "nur Anzeige im Bericht"),
                        ("H4", "Kandidat für eine Warnkachel „Hebel-Anteil hoch“ (eigener Plan-Punkt)", "nur Anzeige im Bericht")):
        o = alle.get(k) or {}
        if not o.get("coins"):
            continue
        if o.get("belegt"):
            txt = ja
            if k == "H2":
                txt = "folgen: Konfluenz-Punkt bleibt" if o["t"] > o["null_median"] else "dagegen: Vorschlag, den Konfluenz-Punkt umzudrehen"
        elif not voll:
            txt = "erst nach vollständiger Historie"
        else:
            txt = nein
        a(f"     {k}: {txt}")
    a("")


def _bericht_stand(V: dict, a) -> None:
    st = V.get("stand") or {}
    if not st:
        return
    a("STAND HEUTE (nur Lage, keine Empfehlung)")
    for coin, o in st.items():
        z = f"  {coin:<5} "
        if "tag" in o:
            z += (f"Tagesende {_dt(o['tag'])}: Konten {_r(o['konten'])}, Top-Trader Positionen {_r(o['top_pos'])}, Top-Trader Konten "
                  f"{_r(o['top_konten'])} -- S1 {'an' if o.get('s1') else 'aus'}, S2 "
                  + {1: "Kauf", -1: "Verkauf", 0: "aus", None: "—"}[o.get("s2")])
        else:
            z += "keine metrics"
        lv = o.get("live") or {}
        if lv:
            z += "; live " + ", ".join(f"{n} {_r(v[1])}" for n, v in (("Konten", lv.get("konten")), ("Top-Pos.", lv.get("top_pos")))
                                       if v) + (f" ({time.strftime('%H:%M', time.localtime(max(v[0] for v in lv.values())))})" if lv else "")
        a(z)
        if "anteil" in o:
            a(f"        Perp-Anteil {_dt(o['anteil_tag'])}: {_pr(o['anteil'])} (Perzentil der 90 Tage {_r(o['anteil_pz'])}) -- S3 "
              f"{'an' if o['s3'] else 'aus'}, S4 {'an' if o['s4'] else 'aus'}; OI ÷ Spotvolumen {_r(o.get('oi_spot'))} Tage")
    a("")


def _bericht_einzeln(V: dict, a) -> None:
    alle = {**(V.get("richtung") or {}), **(V.get("risiko") or {})}
    a("H1–H4 IM EINZELNEN")
    for k, titel in HAUPT:
        o = alle.get(k) or {}
        if not o.get("coins"):
            continue
        hv = o.get("haelften_werte") or {}
        a(f"  {k}: " + "; ".join(f"Hälfte {i + 1} {_de(v[0], 3) if o.get('art') == 'richtung' else _r(v[0])} gegen Null {_de(v[1], 3) if o.get('art') == 'richtung' else _r(v[1])}"
                                 for i, v in sorted(hv.items())))
        jc = o.get("je_coin") or {}
        if o.get("art") == "richtung":
            a("     je Coin: " + "; ".join(f"{c} T {_de(v['t'], 3, True)} ({v['n']} Tage: {v['long']} Kauf, {v['short']} Verkauf)" for c, v in jc.items()))
        else:
            a("     je Coin: " + "; ".join(f"{c} RR {_r(v['rr'])} ({v['k4'][0]}/{v['k4'][0] + v['k4'][1]} gegen {v['k4'][2]}/{v['k4'][2] + v['k4'][3]})"
                                          for c, v in jc.items()))
        if o.get("art") == "risiko":
            r = o.get("richtung") or {}
            a(f"     Wellen nach dem Signal: ab {r.get('ab')}, auf {r.get('auf')}, beide {r.get('beide')}; gegen die überfüllte Seite (Funding) "
              f"{r.get('gegen_ueberfuellt')}, mit ihr {r.get('mit_ueberfuellt')}; Mantel-Haenszel-RR über die Schwankungsdrittel {_r(o.get('mh_rr'))}")
    b = V.get("basis") or {}
    if b:
        a("  Grundquoten der Liquidationswelle (alle Tage): " + "; ".join(f"{c} {h} T {_pr(v['quote'])} (OI-Abbau {_pr(v['o'])}, {v['gueltig']} Tage)"
                                                                           for (c, h), v in sorted(b.items(), key=lambda x: (x[0][0], x[0][1]))))
    a("")


def _bericht_beschreibend(V: dict, a) -> None:
    R = V.get("richtung") or {}; K = V.get("risiko") or {}
    a("BESCHREIBEND (kein Urteil, p roh)")
    a("  1. Perzentile der eigenen 90 Tage vor einem Rücksetzer in 7 Tagen (RR gegen die Surrogate):")
    for name, titel in KENNZAHLEN:
        zz = []
        for sfx, lab in (("hoch", "oberstes Zehntel"), ("tief", "unterstes Zehntel")):
            o = R.get(f"P_{name}_{sfx}") or {}
            if o.get("coins"):
                zz.append(f"{lab} RR {_r(o.get('rr'))} ({o.get('signaltage')} T, p {_pz(o.get('p'))})")
        if zz:
            a(f"     {titel}: " + "; ".join(zz))
    a("  2. Richtung nach den Perzentilen (oberstes Zehntel +1, unterstes −1; T in σ, p zweiseitig):")
    for name, titel in KENNZAHLEN:
        zz = [f"{k} T {_de((R.get(f'R_{name}_k{k}') or {}).get('t'), 3, True)} (p {_pz((R.get(f'R_{name}_k{k}') or {}).get('p'))})"
              for k in (1, 3, 7) if (R.get(f"R_{name}_k{k}") or {}).get("coins")]
        if zz:
            a(f"     {titel}: " + "; ".join(zz))
    a("  3. Andere Horizonte:")
    for key in [f"H1_h{h}" for h in H_RR_BESCHR] + [f"H3_h{h}" for h in H_RR_BESCHR] + [f"H4_h{h}" for h in H_RR_BESCHR] + ["D_oi_spot"]:
        o = R.get(key) or K.get(key) or {}
        if o.get("coins"):
            a(f"     {o['titel']}: {_zeile_rr(o)}")
    for key in [f"H2_k{k}" for k in H_RICHTUNG_BESCHR]:
        o = R.get(key) or {}
        if o.get("coins") and o.get("signaltage"):
            a(f"     {o['titel']}: {_zeile_t(o)}")
    jj = V.get("je_jahr") or {}
    if any(jj.values()):
        a("  4. Je Jahr (Quote mit Signal / ohne; Signaltage):")
        for key, lab in (("H1", "H1 Konten ≥ 3, Rücksetzer 7 T"), ("H3", "H3 Perp-Anteil ≥ 95 %, Welle 7 T"), ("H4", "H4 Perp-Anteil oberstes Zehntel, Welle 7 T")):
            if jj.get(key):
                a(f"     {lab}: " + "; ".join(f"{j} {_pr(z[1] / z[0] if z[0] else float('nan'), 0)}/{_pr(z[3] / z[2] if z[2] else float('nan'), 0)} ({z[0]})"
                                            for j, z in sorted(jj[key].items())))
    aj = V.get("anteil_jahre") or {}
    if aj:
        a("  5. Perp-Anteil am Binance-Volumen je Jahr (Median, 10–90 %, Tage ≥ 95 %; Spotpaare in % des Spotvolumens):")
        for coin, zeilen in aj.items():
            for j, z in zeilen.items():
                a(f"     {coin} {j}: {_pr(z['median'])} ({_pr(z['q10'])}–{_pr(z['q90'])}), ≥ 95 % an {z['ab95']} von {z['n']} Tagen; Spot "
                  + ", ".join(f"{s_.replace(coin, '')} {_pr(v, 0)}" for s_, v in sorted(z["spot"].items(), key=lambda x: -x[1])))
    ab = V.get("abgleich") or {}
    a("  6. Abgleich Archiv gegen Live (bnc_metrics in hl_liq.db, letzte 60 Tage des Archivs):")
    if ab.get("grund"):
        a(f"     {ab['grund']}")
    else:
        for live, o in (ab.get("metriken") or {}).items():
            if not o.get("n"):
                a(f"     {live}: keine gemeinsamen Zeitpunkte"); continue
            e = o.get("erw") or {}
            a(f"     {live} -> Archiv „{o['erwartet']}“: {e.get('n', 0)} Paare, Median der Abweichung {_pr(e.get('median'), 2)}, ≤ 0,5 % bei "
              f"{_pr(e.get('anteil'), 0)}, Versatz {o.get('versatz')} s"
              + ("" if o.get("zuordnung_ok") else f" -- ZUORDNUNG PRÜFEN: am besten passt „{o['bestes'][0]}“ (Versatz {o['bestes'][1]} s, Median {_pr(o['best']['median'], 2)})"))
        if ab.get("ms_zeilen"):
            a(f"     Achtung: {ab['ms_zeilen']} Zeilen in bnc_metrics mit Zeitstempel in Millisekunden (altes hl_binance.py --backfill) -- "
              "sie liegen „in der Zukunft“ und sollten gelöscht werden (Plan-Punkt)")
        else:
            a("     keine Zeilen mit Zeitstempel in Millisekunden in bnc_metrics")
    s = V.get("sicherung") or {}
    if s:
        a("  7. Gesichert in hebel.db (Vorhaltefrist in hl_liq.db: Liquidationen 90 Tage, Buch 60 Tage):")
        for tab, lab in (("hb_liq", "Liquidationen Bybit/OKX"), ("hb_buch", "Binance-Buchtiefe")):
            r = s.get(tab)
            if r and r[0]:
                a(f"     {lab}: {_tausend(r[0])} Zeilen, {time.strftime('%d.%m.%Y', time.gmtime(r[1]))}–{time.strftime('%d.%m.%Y %H:%M', time.gmtime(r[2]))} UTC")
            else:
                a(f"     {lab}: noch nichts gesichert")
        lt = V.get("liq_tage") or []
        if lt:
            letzte = {}
            for ex, d, summe, anz in lt:
                letzte.setdefault(int(d), {})[ex] = (summe, anz)
            for d in sorted(letzte)[-7:]:
                a(f"     {_dt(d)}: " + ", ".join(f"{ex} {_mio(v[0])} USD ({v[1]})" for ex, v in sorted(letzte[d].items())))
    a("")


R7_NAMEN = ("≤ −1", "−1…−⅓", "−⅓…+⅓", "+⅓…+1", "> +1")


def _bericht_nachtrag(V: dict, a) -> None:
    R = V.get("richtung") or {}; G = V.get("h1_geschichtet") or {}
    teile = [(f"H1_{sfx}", lab) for sfx, _, lab in STAND_FRUEHER]
    if not G and not any((R.get(k) or {}).get("coins") for k, _ in teile):
        return
    a("NACHTRÄGLICH ERGÄNZT (nach dem ersten Lauf am 10.10.2026, KONZEPT_Hebel.md 12.3 -- beschreibend, kein Urteil, p roh)")
    erkl = {"H1_v1h": "23 Uhr statt Mitternacht UTC; schließt den 5-min-Versatz des Archivs aus",
            "H1_v24h": "Ende des Vortags; wie lange trägt der Stand?"}
    for k, lab in teile:
        o = R.get(k) or {}
        if o.get("coins"):
            a(f"  H1 mit dem Stand {lab} ({erkl.get(k, '')}): {_zeile_rr(o)}; {o.get('signaltage')} Signaltage in {o.get('episoden')} Episoden")
    if G:
        a(f"  H1 geschichtet nach der Rendite der 7 Tage davor (Coin × {G['klassen']} Klassen in σ·√7, Mantel-Haenszel): RR {_r(G.get('mh'))} "
          f"gegen Null {_r(G.get('null_median'))}, p {_pz(G.get('p'))} (ungeschichtet {_r(G.get('roh'))}, {G.get('signaltage')} Signaltage)")
        if G.get("klassen") == len(R7_NAMEN):
            a("     je Klasse (Anteil der Signaltage; Rücksetzer-Quote mit/ohne Signal; RR): " + "; ".join(
                f"{R7_NAMEN[z]}: {_pr(kz['anteil_signal'], 0)}, {_pr(kz['p_sig'], 0)}/{_pr(kz['p_ohne'], 0)}, RR {_r(kz['rr'])}"
                for z, kz in enumerate(G["je_klasse"])))
        a("     Lesart: Fällt der geschichtete RR auf die Null, war H1 vor allem ein Spiegel der Vorwoche (Rückgang -> viele Konten long ->")
        a("     weiterer Rückgang); bleibt er nahe am ungeschichteten, sagt der Konten-Stand mehr als der Kursverlauf allein.")
    a("")


# ================================================================================================ Selbsttest (ohne Netz)

_T0_TEST = "2020-01-01"


def _ar1(rng, n: int, phi: float, sd: float) -> np.ndarray:
    x = np.empty(n); e = rng.normal(0.0, sd * math.sqrt(1 - phi * phi), n); x[0] = rng.normal(0.0, sd)
    for t in range(1, n):
        x[t] = phi * x[t - 1] + e[t]
    return x


def _universum(saat: int, n: int = 1600, effekt: str | None = None, staerke: float = 1.0, coins=COINS, cq: dict | None = None) -> tuple:
    """
    Synthetische Rohdaten wie aus hebel.db (Kerzen K, stündliche metrics M): GARCH-Kurse mit gemeinsamem Faktor, persistente
    Verhältnisse (AR(1)), Perp-Anteil mit einer „Null-Gebühren-Zeit“, stündliches OI als Zufallsweg. Effekte (kausal, nur nach dem
    Signaltag): H1 Drift −0,35 σ in den 7 Tagen nach Konten ≥ 3; H2 ±0,30 σ am Tag nach der Top-Trader-Regel; H3/H4 doppelte
    Schwankung in den 7 Tagen nach dem Signal und ein OI-Abbau (−0,18 in ln) zu zufälliger Stunde.
    23.68 (U158): cq (Ausgabe) bekommt für BTC einen CryptoQuant-Anteil D (logistisches AR(1) um 92,5 %, eigener Zufallsstrom, die
    übrigen Reihen bleiben gleich); effekt "S5" pflanzt nach D ≥ 0,95 ab Tag cq["ab"] dieselbe Welle wie H3 (Stärke staerke).
    """
    tag0 = tag_von(_T0_TEST); rng0 = np.random.default_rng(saat)
    f = rng0.standard_t(4, n) / math.sqrt(2.0)
    K = {}; M = {}
    tage = tag0 + np.arange(n)
    for i, coin in enumerate(coins):
        rg = np.random.default_rng(saat * 31 + 7 * i + 1)
        konten = np.exp(math.log(1.9) + _ar1(rg, n, 0.97, 0.30))
        top_pos = np.exp(math.log(1.1) + _ar1(rg, n, 0.95, 0.25))
        top_konten = np.exp(math.log(1.6) + _ar1(rg, n, 0.97, 0.30))
        taker = np.exp(_ar1(rg, n, 0.3, 0.06))
        anteil = None; s34 = np.zeros(n, dtype=bool)
        if coin in COINS_ANTEIL:
            lg = math.log(0.88 / 0.12) + _ar1(rg, n, 0.97, 0.5)
            lg[min(n, 700):min(n, 950)] -= 0.7
            anteil = 1.0 / (1.0 + np.exp(-lg))
            if effekt == "H3":
                s34 = anteil >= ANTEIL_ABS
            elif effekt == "H4":
                pz = ZY.oi_perzentil(anteil, PERZ_FENSTER, PERZ_MIN)
                s34 = np.where(np.isfinite(pz), pz, 0.0) >= ANTEIL_PZ
        if coin == "BTC" and cq is not None:                       # 23.68 (U158): eigener Zufallsstrom, ändert keine andere Reihe
            rq = np.random.default_rng(saat * 97 + 5)
            Dq = 1.0 / (1.0 + np.exp(-(math.log(0.925 / 0.075) + _ar1(rq, n, 0.90, 0.40))))
            cq.update(tag0=tag0, D=Dq)
            if effekt == "S5":
                s34 = (Dq >= CQ_SCHWELLE) & (np.arange(n) >= int(cq.get("ab", 0))) & (np.arange(n) < int(cq.get("bis", n)))
        s1 = konten >= SCHWELLE_KONTEN
        s2 = np.where(top_pos >= TOP_LONG, 1, np.where(top_pos <= TOP_SHORT, -1, 0))
        sig_c = 0.03 + 0.004 * i; a_, b_ = 0.08, 0.90; om = sig_c * sig_c * (1 - a_ - b_); hv = sig_c * sig_c
        x = np.empty(n); x[0] = math.log(100.0 * (i + 1)); sd = np.full(n, sig_c)
        lam = 0.5 ** (1.0 / ZY.HWZ); ew = float("nan"); z7 = np.full(n, np.nan)       # σ und z7 wie in der Studie (Momentum)
        for t in range(1, n):
            s = math.sqrt(hv); mult = 1.0; drift = 0.0003
            if effekt == "H1" and s1[max(0, t - 7):t].any():
                drift -= 0.35 * s * staerke
            if effekt == "H2" and s2[t - 1] != 0:
                drift += 0.30 * s * s2[t - 1] * staerke
            if effekt in ("H3", "H4", "S5") and s34[max(0, t - 7):t].any():
                mult = 1.0 + 1.0 * staerke
            if effekt == "Momentum" and np.isfinite(z7[t - 1]) and z7[t - 1] <= R7_GRENZEN[1]:
                drift -= 0.30 * s * staerke                                   # nach einer schwachen Woche weiter abwärts
            z = 0.6 * f[t] + 0.8 * rg.standard_t(4) / math.sqrt(2.0)
            x[t] = x[t - 1] + drift + mult * s * z; sd[t] = mult * s
            hv = om + a_ * (s * z) ** 2 + b_ * hv
            r_ = x[t] - x[t - 1]; ew = r_ * r_ if not np.isfinite(ew) else lam * ew + (1 - lam) * r_ * r_
            if t >= 7 and ew > 0:
                z7[t] = (x[t] - x[t - 7]) / (math.sqrt(ew) * math.sqrt(7))
        if effekt == "Momentum":
            # Konten hängen nur an der Klasse der Vorwoche (untere zwei Klassen: 40 % der Tage ≥ 3), sonst unter 3: kein eigener Gehalt
            schwach = np.isfinite(z7) & (z7 <= R7_GRENZEN[1])
            konten = np.where(schwach & (rg.random(n) < 0.4), 3.4, np.minimum(konten, 2.9))
        c = np.exp(x)
        vor = np.concatenate([[c[0]], c[:-1]])
        h_ = np.maximum(vor, c) * np.exp(np.abs(rg.normal(0, 0.4, n)) * sd)
        l_ = np.minimum(vor, c) * np.exp(-np.abs(rg.normal(0, 0.4, n)) * sd)
        tot = 1e9 * np.exp(rg.normal(0, 0.3, n))
        basis = {"tag": tage, "h": h_, "l": l_, "c": c}
        if anteil is not None:
            deriv = anteil * tot; spot = tot - deriv
            K[("um", f"{coin}USDT")] = {**basis, "v_usd": 0.7 * deriv, "taker_usd": 0.35 * deriv}
            K[("um", f"{coin}USDC")] = {**basis, "v_usd": 0.1 * deriv, "taker_usd": 0.05 * deriv}
            K[("cm", f"{coin}USD_PERP")] = {**basis, "v_usd": 0.2 * deriv, "taker_usd": 0.1 * deriv}
            K[("spot", f"{coin}USDT")] = {**basis, "v_usd": 0.6 * spot, "taker_usd": 0.3 * spot}
            K[("spot", f"{coin}FDUSD")] = {**basis, "v_usd": 0.25 * spot, "taker_usd": 0.12 * spot}
            K[("spot", f"{coin}USDC")] = {**basis, "v_usd": 0.15 * spot, "taker_usd": 0.07 * spot}
        else:
            K[("um", f"{coin}USDT")] = {**basis, "v_usd": tot, "taker_usd": 0.5 * tot}
        nh = n * 24
        lo = math.log(1e5) + np.cumsum(rg.normal(0, 0.03 / math.sqrt(24), nh))
        if effekt in ("H3", "H4", "S5") and anteil is not None:
            letzte = -99
            for d in np.nonzero(s34)[0]:
                if d - letzte >= 7 and (d + 8) * 24 < nh:
                    st = (d + 1) * 24 + int(rg.integers(1, 24 * 7)); lo[st:] -= 0.18 * staerke; letzte = d
        ts = (tag0 * 24 + np.arange(nh)) * 3600
        di = np.clip((ts - 1) // TAG - tag0, 0, n - 1)
        M[coin] = {"ts": ts.astype(np.int64), "oi": np.exp(lo), "oi_usd": np.exp(lo) * c[di], "top_konten": top_konten[di],
                   "top_pos": top_pos[di], "konten": konten[di], "taker": taker[di]}
    return K, M


def _tafeln(K: dict, M: dict) -> dict:
    out = {}
    for coin in COINS:
        if ("um", f"{coin}USDT") in K:
            T = tafel_bauen(coin, K, M.get(coin))
            if T is not None:
                T["funding"] = None
                out[coin] = T
    return out


def _zip(name: str, text: str) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr(name, text)
    return b.getvalue()


def _metrics_csv(tag: int, werte: dict | None = None, je_5min: bool = True) -> str:
    kopf = ("create_time,symbol,sum_open_interest,sum_open_interest_value,count_toptrader_long_short_ratio,"
            "sum_toptrader_long_short_ratio,count_long_short_ratio,sum_taker_long_short_vol_ratio")
    zeilen = [kopf]
    for k in range(0, 24 * 60, 5 if je_5min else 60):
        ts = tag * TAG + k * 60; w = (werte or {}).get(k, None)
        oi = 1000.0 + tag % 97 + k / 1000.0
        vals = w or (oi, oi * 50000.0, 1.5, 1.2, 2.0, 1.01)
        zeilen.append(time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts)) + ",BTCUSDT," + ",".join("" if v is None else str(v) for v in vals))
    return "\n".join(zeilen) + "\n"


def _kerzen_csv(tage: list, markt: str, kopf: bool = False, mikro: bool = False, preis: float = 100.0) -> str:
    z = ["open_time,open,high,low,close,volume,close_time,quote_volume,count,taker_buy_volume,taker_buy_quote_volume,ignore"] if kopf else []
    for t in tage:
        ms = t * TAG * 1000; ot = ms * 1000 if mikro else ms
        if markt == "cm":
            z.append(f"{ot},{preis},{preis * 1.02},{preis * 0.97},{preis * 1.01},5000,{ot + TAG * 1000 - 1},48.1,900,2600,25.0,0")
        else:
            z.append(f"{ot},{preis},{preis * 1.02},{preis * 0.97},{preis * 1.01},12.5,{ot + TAG * 1000 - 1},1262.5,900,6.0,606.0,0")
    return "\n".join(z) + "\n"


def probe(verbose: bool = True, schnell: bool = False) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name:<72} {text}", flush=True)
    t_start = time.time()
    for fn in (_probe_parser, _probe_laden, _probe_sicherung, _probe_tafel, _probe_schichten, _probe_ereignisse, _probe_identitaet,
               _probe_urteile, _probe_abgleich, _probe_ende_zu_ende, _probe_signale, _probe_statistik, _probe_cq, _probe_s5):
        try:
            fn(ok)
        except Exception as e:
            import traceback
            tb = traceback.format_exc().splitlines()
            ok(f"{fn.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {tb[-3].strip() if len(tb) >= 3 else ''}")
    return all(p[1] for p in pruef), pruef, time.time() - t_start


def _probe_parser(ok) -> None:
    tag = tag_von("2021-03-05")
    w = {0: (1000.0, 5e7, 1.5, None, 2.0, 1.01), 5: (1001.0, 5.1e7, 1.6, 1.3, 2.1, 1.02), 60: (1010.0, 5.2e7, 1.7, 1.4, 2.2, 0.99),
         65: (999.0, 5.0e7, -1.0, 1.4, 2.2, 0.99)}
    text = _metrics_csv(tag, w)
    text += "kaputt,BTCUSDT,1,1,1,1,1,1\n" + text.splitlines()[1] + "\n"           # ungültige Zeit, doppelte Zeile
    z = metrics_parse(_zip("BTCUSDT-metrics-2021-03-05.csv", text), "BTC")
    ok("metrics: je Stunde die früheste Zeile, 24 Stunden, leere Felder NULL, Doppelte und kaputte Zeilen ohne Wirkung",
       len(z) == 24 and z[0][1] == tag * TAG and z[0][5] is None and z[0][4] == 1.5 and z[1][1] == tag * TAG + 3600 and z[1][2] == 1010.0
       and z[1][4] == 1.7, f"{len(z)} Zeilen; erste {z[0][:8] if z else None}")
    z2 = metrics_parse(_zip("x.csv", _metrics_csv(tag, {0: (1000.0, 5e7, -1.0, 2000.0, 0.0, 1.0)}, je_5min=False)), "BTC")
    ok("metrics: Verhältnisse ≤ 0 oder ≥ 1000 werden NULL", z2 and z2[0][4] is None and z2[0][5] is None and z2[0][6] is None,
       f"{z2[0][2:] if z2 else None}")
    ok("metrics: kein ZIP -> leer", metrics_parse(b"kein zip", "BTC") == [])
    t = [tag_von("2025-01-01"), tag_von("2025-01-02")]
    um = kerzen_parse(_zip("a.csv", _kerzen_csv(t, "um", kopf=True)), "um", "BTCUSDT", "BTC")
    sp = kerzen_parse(_zip("b.csv", _kerzen_csv(t, "spot", mikro=True)), "spot", "BTCUSDT", "BTC")
    cm = kerzen_parse(_zip("c.csv", _kerzen_csv(t, "cm", preis=50000.0)), "cm", "BTCUSD_PERP", "BTC")
    ok("Kerzen: Kopfzeile übersprungen, Tag aus Millisekunden; Spot in Mikrosekunden (ab 2025) richtig",
       [r[2] for r in um] == t and [r[2] for r in sp] == t and um[0][8] == 1262.5 and um[0][9] == 606.0,
       f"um {[r[2] for r in um]}, spot {[r[2] for r in sp]}")
    ok("Kerzen COIN-M: Volumen und Taker in Kontrakten × 100 USD (BTC)", cm and cm[0][8] == 500000.0 and cm[0][9] == 260000.0,
       f"{cm[0][7:10] if cm else None}")
    bad = kerzen_parse(_zip("d.csv", "1,0,0,0,0,1,2,3,4,5,6,0\n"), "um", "BTCUSDT", "BTC")
    ok("Kerzen: Zeile mit Preis 0 übersprungen", bad == [])
    syms = symbole()
    ok("Symbole vorab: 5 Kurs-Perps, je BTC/ETH 2 weitere USDⓈ-M, 1 COIN-M, 5 Spot (21)",
       len(syms) == 21 and ("cm", "ETHUSD_PERP", "ETH") in syms and ("spot", "BTCFDUSD", "BTC") in syms and ("um", "HYPEUSDT", "HYPE") in syms,
       f"{len(syms)}")


class _FakeArchiv:
    def __init__(self, dateien: dict, fehler: set | None = None):
        self.dateien = dateien; self.fehler = fehler or set(); self.aufrufe = []

    def __call__(self, url: str, timeout: int = 30):
        self.aufrufe.append(url)
        if url in self.fehler:
            return "fehler", None, "URLError: timed out"
        if url in self.dateien:
            return "ok", self.dateien[url], ""
        return "404", None, ""


def _probe_laden(ok) -> None:
    global START_METRICS, START_KERZEN
    alt = (START_METRICS, START_KERZEN, QUELLE["holen"])
    heute = tag_von("2026-03-06"); jetzt = heute * TAG + 5 * 3600
    START_METRICS = datum_von(heute - 60); START_KERZEN = "2026-01"
    d = {}
    for t in range(heute - 40, heute):                                   # BTC: 40 Tage, eine Lücke
        if t != heute - 20:
            d[url_metrics("BTC", t)] = _zip("m.csv", _metrics_csv(t))
    for t in range(heute - 10, heute):                                   # ETH: 10 Tage
        d[url_metrics("ETH", t)] = _zip("m.csv", _metrics_csv(t))
    for markt, symbol, coin in symbole():
        if symbol in ("BTCUSDT", "ETHUSDT", "BTCUSD_PERP"):
            d[url_kerzen(markt, symbol, "2026-01")] = _zip("k.csv", _kerzen_csv(monatstage("2026-01"), markt))
            for t in monatstage("2026-02") + monatstage("2026-03"):
                if t < heute:
                    d[url_kerzen(markt, symbol, datum_von(t))] = _zip("k.csv", _kerzen_csv([t], markt))
    fake = _FakeArchiv(d); QUELLE["holen"] = fake; _ZULETZT.clear()
    tmp = tempfile.mkdtemp(prefix="hebel_test_"); pfad = os.path.join(tmp, "hebel.db")
    try:
        e1 = laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
        con = sqlite3.connect(pfad)
        n_btc = con.execute("SELECT COUNT(*) FROM hb_metrics WHERE coin='BTC'").fetchone()[0]
        n_eth = con.execute("SELECT COUNT(*) FROM hb_metrics WHERE coin='ETH'").fetchone()[0]
        luecke = con.execute("SELECT status FROM hb_dateien WHERE art='metrics' AND symbol='BTCUSDT' AND periode=?", (datum_von(heute - 20),)).fetchone()
        st = ladestand(con, jetzt); m = {k: meta(con, k) for k in ("m_fertig:BTC", "m_beginn:BTC", "m_fertig:ETH", "m_beginn:ETH", "m_fertig:ZEC",
                                                                    "m_beginn:ZEC", "m_vor:ZEC")}
        feb = con.execute("SELECT COUNT(*) FROM hb_dateien WHERE art='kerzen_m' AND periode='2026-02'").fetchone()[0]
        tage_btc = con.execute("SELECT COUNT(*) FROM hb_kerzen WHERE markt='um' AND symbol='BTCUSDT'").fetchone()[0]
        tage_sp = {s: con.execute("SELECT COUNT(*) FROM hb_kerzen WHERE markt='spot' AND symbol=?", (s,)).fetchone()[0] for s in ("BTCUSDT", "ETHUSDT")}
        ohne_markt = con.execute("SELECT COUNT(*) FROM hb_dateien WHERE art IN ('kerzen_m', 'kerzen_t') AND instr(symbol, ':') = 0").fetchone()[0]
        con.close()
        ok("Laden: BTC 39 Tage × 24 Stunden, Lücke als fehlend gemerkt; ETH 10 Tage; alle fertig nach 30 Tagen ohne Datei",
           n_btc == 39 * 24 and n_eth == 240 and luecke == (0,) and m["m_fertig:BTC"] == "1" and m["m_beginn:BTC"] == str(heute - 40)
           and m["m_fertig:ETH"] == "1" and m["m_beginn:ETH"] == str(heute - 10) and m["m_fertig:ZEC"] == "1" and m["m_beginn:ZEC"] is None,
           f"BTC {n_btc}, ETH {n_eth}, Lücke {luecke}, {m}")
        ok("Laden: Vormonat ohne Monatsdatei (Tag ≤ 7) nicht als fehlend gemerkt, Tagesdateien statt dessen; Januar aus der Monatsdatei",
           feb == 0 and tage_btc == 31 + 28 + 5, f"Feb-Einträge {feb}, BTCUSDT-Tage {tage_btc}")
        kp = st["kerzen"]
        ok("Laden: Spotpaar und Perp gleichen Namens getrennt (spot BTCUSDT/ETHUSDT je 64 Tage wie um; Schlüssel mit Markt, Ladestand je Markt)",
           tage_sp == {"BTCUSDT": 64, "ETHUSDT": 64} and ohne_markt == 0 and kp[("spot", "BTCUSDT")]["ok"] == 1 and kp[("spot", "BTCUSDT")]["tage"] == 64
           and kp[("um", "BTCUSDC")]["ok"] == 0 and kp[("spot", "BTCUSDC")]["ok"] == 0,
           f"Spot {tage_sp}, Einträge ohne Markt {ohne_markt}, Ladestand spot BTCUSDT {kp[('spot', 'BTCUSDT')]}")
        ok("Laden: Ladestand vollständig -- alle Coins fertig, nur der noch nicht erschienene Vormonat offen", st["vollstaendig"] is True,
           f"vollständig {st['vollstaendig']}")
        txt = bericht_text({"laden": st, "info": {"pfad": pfad, "fehlt": []}})
        ok("Bericht: Datenteil mit echtem Ladestand (metrics je Coin, Kerzen je Symbol)", "metrics BTC" in txt and "um BTCUSDT" in txt
           and "ohne Datei" in txt, f"{len(txt.splitlines())} Zeilen")
        con = verbinden(pfad); con.execute("DELETE FROM hb_meta WHERE k='m_fertig:XMR'"); st2 = ladestand(con, jetzt)
        meta_setzen(con, {"m_fertig:XMR": 1}); con.close()
        ok("Laden: ein Coin nicht fertig -> nicht vollständig", st2["vollstaendig"] is False)
        n_vorher = len(fake.aufrufe)
        laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
        neu = fake.aufrufe[n_vorher:]
        ok("Laden: zweiter Lauf holt nichts Bekanntes erneut (frische Dateien höchstens stündlich)", len(neu) == 0, f"{len(neu)} Abrufe: {neu[:3]}")
        _ZULETZT.clear()
        laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt + 2 * 3600, pause=0)
        neu2 = fake.aufrufe[n_vorher:]
        con = sqlite3.connect(pfad)
        zec_gestern = con.execute("SELECT COUNT(*) FROM hb_dateien WHERE symbol IN ('ZECUSDT', 'um:ZECUSDT') AND periode=?",
                                  (datum_von(heute - 1),)).fetchone()[0]
        con.close()
        ok("Laden: eine fehlende Datei von gestern wird nicht als fehlend gemerkt (kommt später)", zec_gestern == 0, f"{zec_gestern}")
        ok("Laden: nach einer Stunde nur die frischen Dateien erneut (gestern fehlend, Vormonat-Monatsdatei)",
           0 < len(neu2) <= 5 + 21 + 21 * 2 and all(("metrics" in u and (datum_von(heute - 1) in u or datum_von(heute - 2) in u)) or "2026-02" in u
                                                     or datum_von(heute - 1) in u or datum_von(heute - 2) in u for u in neu2), f"{len(neu2)} Abrufe")
        d[url_metrics("ZEC", heute - 1)] = _zip("m.csv", _metrics_csv(heute - 1)); _ZULETZT.clear()
        laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt + 4 * 3600, pause=0)
        con = sqlite3.connect(pfad); n_zec = con.execute("SELECT COUNT(*) FROM hb_metrics WHERE coin='ZEC'").fetchone()[0]; con.close()
        ok("Laden: die Datei von gestern erscheint später und wird dann geholt", n_zec == 24, f"ZEC {n_zec} Stunden")
        _probe_umstellung(ok, d, tmp, jetzt)
        # Netzfehler -> Pause, Abbruch
        pfad2 = os.path.join(tmp, "hebel2.db"); _ZULETZT.clear()
        fake2 = _FakeArchiv(d, fehler={url_metrics("BTC", heute - 1)}); QUELLE["holen"] = fake2
        e2 = laden(pfad2, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
        con = sqlite3.connect(pfad2); pb = int(meta(con, "pause_bis", "0")); con.close()
        ok("Laden: Netzfehler -> Abbruch der Runde und Pause (15 min)", e2.get("abbruch", "").startswith("Netzfehler") and pb > time.time() + 800,
           f"{e2.get('abbruch')}, Pause {pb - int(time.time())} s")
        e3 = laden(pfad2, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
        ok("Laden: während der Pause keine Abrufe", "pause" in e3 and e3.get("dateien") == 0, f"{ {k: e3.get(k) for k in ('pause', 'dateien')} }")
        # Sperre und Budget
        pfad3 = os.path.join(tmp, "hebel3.db"); con = verbinden(pfad3)
        meta_setzen(con, {"laeuft": f"999999:{jetzt - 60}"}); con.close()
        e4 = laden(pfad3, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
        QUELLE["holen"] = _FakeArchiv(d)
        e5 = laden(os.path.join(tmp, "hebel4.db"), None, budget_s=0.0, log=lambda *a: None, jetzt=jetzt, pause=0)
        ok("Laden: Sperre eines anderen Laufs wird beachtet; Budget 0 -> Abbruch ohne Abruf", e4.get("uebersprungen") is True
           and e5.get("abbruch") == "Budget" and e5.get("dateien") == 0, f"{e4.get('uebersprungen')}, {e5.get('abbruch')}, {e5.get('dateien')}")
    finally:
        START_METRICS, START_KERZEN, QUELLE["holen"] = alt
        _ZULETZT.clear()
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _probe_umstellung(ok, d: dict, tmp: str, jetzt: int) -> None:
    """Stand von 23.63 nachstellen (Kerzeneinträge ohne Markt, gleichnamige Spotpaare nie geladen) -> Umstellung, dann Nachladen."""
    pfad = os.path.join(tmp, "hebel_alt.db"); _ZULETZT.clear(); QUELLE["holen"] = _FakeArchiv(d)
    laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
    namen: dict = {}
    for markt, symbol, _ in symbole():
        namen.setdefault(symbol, []).append(markt)
    doppelt = sorted(s for s, mm in namen.items() if len(mm) > 1)
    con = verbinden(pfad)
    vorher = dict(con.execute("SELECT art || '|' || symbol || '|' || periode, status FROM hb_dateien").fetchall())
    n_metrics = con.execute("SELECT COUNT(*) FROM hb_dateien WHERE art='metrics'").fetchone()[0]
    con.execute("BEGIN IMMEDIATE")                                       # 23.63 nachstellen
    for s in doppelt:
        con.execute("DELETE FROM hb_dateien WHERE art IN ('kerzen_m', 'kerzen_t') AND symbol=?", (_dk("spot", s),))
        con.execute("DELETE FROM hb_kerzen WHERE markt='spot' AND symbol=?", (s,))
    con.execute("UPDATE hb_dateien SET symbol = substr(symbol, instr(symbol, ':') + 1) WHERE art IN ('kerzen_m', 'kerzen_t')")
    con.execute("DELETE FROM hb_meta WHERE k IN ('schema_dateien', 'umgestellt')")
    con.execute("INSERT OR REPLACE INTO hb_meta VALUES ('k_fertig', '1')")
    con.execute("COMMIT"); con.close()
    bedarf_alt = bedarf(pfad, jetzt)
    con = verbinden(pfad)                                                # hier stellt verbinden() um
    nachher = dict(con.execute("SELECT art || '|' || symbol || '|' || periode, status FROM hb_dateien").fetchall())
    m1 = {k: meta(con, k) for k in ("schema_dateien", "k_fertig")}
    meta_setzen(con, {"k_fertig": 1}); con.close()
    con = verbinden(pfad); k2 = meta(con, "k_fertig"); con.close()          # zweites Öffnen: nichts mehr umstellen
    soll = {k: v for k, v in vorher.items() if k.split("|")[1] not in {_dk("spot", s) for s in doppelt}}
    ok("Umstellung 23.64: alte Kerzeneinträge bekommen den Markt (gleichnamig: der erste in symbole(), das Perp), metrics bleiben, "
       "k_fertig = 0, nur einmal", nachher == soll and m1 == {"schema_dateien": SCHEMA_DATEIEN, "k_fertig": "0"} and k2 == "1"
       and bedarf_alt is True and n_metrics > 0 and len(doppelt) == 6,
       f"gleich {nachher == soll} ({len(nachher)}/{len(soll)}), {m1}, zweites Öffnen k_fertig {k2}, Bedarf vorher {bedarf_alt}, gleichnamig {doppelt}")
    fake = _FakeArchiv(d); QUELLE["holen"] = fake                         # _ZULETZT bleibt: frische Dateien schon versucht
    laden(pfad, None, budget_s=600, log=lambda *a: None, jetzt=jetzt, pause=0)
    con = sqlite3.connect(pfad)
    sp = {s: con.execute("SELECT COUNT(*) FROM hb_kerzen WHERE markt='spot' AND symbol=?", (s,)).fetchone()[0] for s in ("BTCUSDT", "ETHUSDT")}
    um = con.execute("SELECT COUNT(*) FROM hb_kerzen WHERE markt='um' AND symbol='BTCUSDT'").fetchone()[0]
    st = ladestand(con, jetzt); con.close()
    kl = [u for u in fake.aufrufe if "/klines/" in u]
    ok("Umstellung 23.64: der nächste Lauf lädt nur die ausgelassenen Spotpaare nach (spot BTCUSDT/ETHUSDT je 64 Tage), kein Perp erneut",
       sp == {"BTCUSDT": 64, "ETHUSDT": 64} and um == 64 and len(kl) > 0 and all("/spot/" in u for u in kl) and st["vollstaendig"] is True,
       f"Spot {sp}, um BTCUSDT {um}, {len(kl)} Kerzen-Abrufe, davon Spot {sum('/spot/' in u for u in kl)}, vollständig {st['vollstaendig']}")
    con = verbinden(pfad)
    _schreiben(con, "DELETE FROM hb_kerzen WHERE markt='spot' AND symbol='BTCUSDT' AND tag < ?", [(tag_von("2026-02-01"),)])
    st2 = ladestand(con, jetzt); con.close()
    txt = bericht_text({"laden": st2, "info": {"pfad": pfad, "fehlt": []}})
    ok("Ladestand prüft die Buchführung gegen die Zeilen: gemerkte Monatsdatei ohne Zeilen -> Widerspruch, nicht vollständig "
       "(so wäre der Fehler bis 23.63 aufgefallen)", st2["kerzen"][("spot", "BTCUSDT")]["widerspruch"] and st2["vollstaendig"] is False
       and not st2["kerzen"][("um", "BTCUSDT")]["widerspruch"] and "WIDERSPRUCH" in txt, f"{st2['kerzen'][('spot', 'BTCUSDT')]}")


def _probe_sicherung(ok) -> None:
    tmp = tempfile.mkdtemp(prefix="hebel_sich_")
    try:
        haupt = os.path.join(tmp, "hl_liq.db"); h = sqlite3.connect(haupt)
        h.executescript("""CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL,
                           uid TEXT, PRIMARY KEY (exchange, uid));
                           CREATE TABLE bnc_book (ts INTEGER, coin TEXT, bid REAL, ask REAL, mid REAL, bid5 REAL, ask5 REAL, bid25 REAL,
                           ask25 REAL, bid100 REAL, ask100 REAL, walls TEXT, PRIMARY KEY (ts, coin));""")
        h.executemany("INSERT INTO ext_liquidations VALUES (?,?,?,?,?,?,?,?)",
                      [(1000 + i, "bybit", "BTC", "long", 100.0, 1.0, 100.0, f"u{i}") for i in range(10)])
        h.executemany("INSERT INTO bnc_book VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      [(2000 + 300 * i, "BTC", 99.0, 101.0, 100.0, 1, 2, 3, 4, 5, 6, "[wände]") for i in range(5)])
        h.commit()
        pfad = os.path.join(tmp, "hebel.db"); con = verbinden(pfad)
        s1 = sichern(con, haupt, 10_000, max_zeilen=4, erzwingen=True)
        s2 = sichern(con, haupt, 10_001, max_zeilen=4, erzwingen=True)
        s3 = sichern(con, haupt, 10_002, max_zeilen=4, erzwingen=True)
        s4 = sichern(con, haupt, 10_003, max_zeilen=100, erzwingen=False)
        n_liq = con.execute("SELECT COUNT(*) FROM hb_liq").fetchone()[0]; n_buch = con.execute("SELECT COUNT(*) FROM hb_buch").fetchone()[0]
        h.execute("INSERT INTO ext_liquidations VALUES (5000, 'okx', 'ETH', 'short', 10.0, 2.0, 20.0, 'x1')"); h.commit()
        sichern(con, haupt, 20_000, erzwingen=False)
        n_liq2 = con.execute("SELECT COUNT(*) FROM hb_liq").fetchone()[0]
        spalten = [r[1] for r in con.execute("PRAGMA table_info(hb_buch)").fetchall()]
        con.close(); h.close()
        ok("Sicherung: in Teilen ab dem jüngsten Zeitstempel, ohne Doppelte, Wände nicht übernommen, höchstens stündlich",
           n_liq == 10 and n_buch == 5 and "walls" not in spalten and s4 == {"faellig": False} and n_liq2 == 11,
           f"Liquidationen {n_liq} -> {n_liq2}, Buch {n_buch}, Teile {[s['ext_liquidations'] for s in (s1, s2, s3)]}")
        con = verbinden(os.path.join(tmp, "leer.db"))
        s5 = sichern(con, os.path.join(tmp, "gibtsnicht.db"), 1, erzwingen=True)
        h2 = os.path.join(tmp, "alt.db"); sqlite3.connect(h2).execute("CREATE TABLE x (a)").connection.commit()
        s6 = sichern(con, h2, 2, erzwingen=True); con.close()
        ok("Sicherung: fehlende Datenbank bzw. Tabellen ohne Absturz", s5.get("grund") and "fehler" in s6.get("ext_liquidations", {}),
           f"{s5}, {list(s6)}")
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _probe_tafel(ok) -> None:
    tag0 = tag_von("2020-06-01"); n = 300
    tage = tag0 + np.arange(n); c = 100.0 * np.exp(np.cumsum(np.random.default_rng(3).normal(0, 0.02, n)))
    basis = {"tag": tage, "h": c * 1.01, "l": c * 0.99, "c": c}
    K = {("um", "BTCUSDT"): {**basis, "v_usd": np.full(n, 70.0), "taker_usd": np.full(n, 35.0)},
         ("um", "BTCUSDC"): {**basis, "v_usd": np.full(n, 10.0), "taker_usd": np.full(n, 5.0)},
         ("cm", "BTCUSD_PERP"): {**basis, "v_usd": np.full(n, 20.0), "taker_usd": np.full(n, 10.0)},
         ("spot", "BTCUSDT"): {**basis, "v_usd": np.full(n, 6.0), "taker_usd": np.full(n, 3.0)},
         ("spot", "BTCFDUSD"): {**basis, "v_usd": np.full(n, 4.0), "taker_usd": np.full(n, 2.0)}}
    K[("spot", "BTCUSDT")]["v_usd"][150] = np.nan                         # an diesem Tag fehlt das Pflichtpaar
    ts = (tag0 * 24 + np.arange(n * 24)) * 3600
    di = (ts - 1) // TAG - tag0
    konten = 1.0 + (di % 7) * 0.5
    M = {"ts": ts.astype(np.int64), "oi": np.full(len(ts), 1000.0), "oi_usd": np.full(len(ts), 5e7), "top_konten": np.full(len(ts), 1.5),
         "top_pos": np.full(len(ts), 1.2), "konten": konten.astype(float), "taker": np.full(len(ts), 1.0)}
    # Tag 100: 00:00-Zeile von Tag 101 fehlt -> 23:00 gilt; Tag 120: 22:00–00:00 fehlen -> NaN
    weg = np.isin(ts, [(tag0 + 101) * TAG, (tag0 + 121) * TAG, (tag0 + 121) * TAG - 3600, (tag0 + 121) * TAG - 7200])
    M2 = {k: (v[~weg] if hasattr(v, "__len__") else v) for k, v in M.items()}
    T = tafel_bauen("BTC", K, M2)
    erwartet = 1.0 + (np.arange(n) % 7) * 0.5
    ok("Tafel: Verhältnis zum Tagesende = Zeile 00:00 des Folgetags; fehlt sie, gilt 23:00; fehlen 2 h, fehlt der Tag",
       np.allclose(T["konten"][:100], erwartet[:100]) and T["konten"][100] == erwartet[100] and np.isnan(T["konten"][120])
       and T["konten"][121] == erwartet[121], f"Tag 100 {T['konten'][100]} (soll {erwartet[100]}), Tag 120 {T['konten'][120]}")
    M3 = {k: v.copy() for k, v in M2.items()}
    spaet = M3["ts"] > (tag0 + 201) * TAG; M3["konten"][spaet] = 99.0; M3["oi"][spaet] = 1.0
    T3 = tafel_bauen("BTC", K, M3)
    ok("Tafel: kausal -- spätere metrics ändern die Tage bis 200 nicht (Verhältnis, OI, Perzentil, s_OI)",
       np.allclose(T3["konten"][:201], T["konten"][:201], equal_nan=True) and np.allclose(T3["oi"][:201], T["oi"][:201], equal_nan=True)
       and np.allclose(T3["konten_pz"][:201], T["konten_pz"][:201], equal_nan=True) and np.allclose(T3["s_oi"][:201], T["s_oi"][:201], equal_nan=True))
    ok("Tafel: Perp-Anteil = (70+10+20)/(70+10+20+6+4) = 0,909; ohne Spot-USDT fehlt der Tag",
       abs(T["anteil"][10] - 100 / 110) < 1e-12 and np.isnan(T["anteil"][150]), f"{T['anteil'][10]}, Tag 150 {T['anteil'][150]}")
    x = np.array([float(v) for v in range(1, 11)] + [5.0] + [3.0] * 100)
    pz = ZY.oi_perzentil(x, 10, 6)
    ok("Perzentil: Mittelrang unter den 10 Tagen davor (ohne heute), Gleichstand halb: 5 unter 1…10 -> 0,45", abs(pz[10] - 0.45) < 1e-12
       and np.isnan(pz[5]), f"{pz[10]}")
    ok("Tafel: Bewertung beginnt am 01.09.2020 bzw. nach 60 Tagen σ", T["ev0"] == max(VORLAUF, tag_von(START_METRICS) - tag0), f"{T['ev0']}")
    M4 = {k: v.copy() for k, v in M.items()}; M4["konten"] = (M4["ts"] // 3600).astype(float)
    T4 = tafel_bauen("BTC", K, M4); d = 50; ende = (tag0 + d + 1) * 24
    ok("Tafel (nachträglich): Konten-Stand zum Tagesende, 1 h früher (23 Uhr UTC) und 24 h früher (Ende des Vortags)",
       T4["konten"][d] == ende and T4["konten_v1h"][d] == ende - 1 and T4["konten_v24h"][d] == ende - 24,
       f"{T4['konten'][d]}, {T4['konten_v1h'][d]}, {T4['konten_v24h'][d]} (soll {ende}, {ende - 1}, {ende - 24})")


def _probe_schichten(ok) -> None:
    n = 40; sig = np.full(n, 0.01); x = np.zeros(n); w = 0.01 * math.sqrt(7)
    zs = {10: -1.5, 15: -0.5, 20: 0.0, 25: 0.5, 30: 2.0}
    for dd, z in zs.items():
        x[dd] = x[dd - 7] + z * w
    sig[35] = np.nan
    T = {"c": np.exp(x), "sig": sig}
    z7 = _z7(T); kl = _r7_klasse(T)
    ok("Schichtung (nachträglich): Rendite der 7 Tage davor in σ·√7, Klassen ≤ −1, −1…−⅓, −⅓…+⅓, +⅓…+1, > +1; vor Tag 7 und ohne σ keine",
       all(abs(z7[dd] - z) < 1e-9 for dd, z in zs.items()) and [int(kl[dd]) for dd in zs] == [0, 1, 2, 3, 4] and (kl[:7] == -1).all() and kl[35] == -1,
       f"z7 {[round(float(z7[dd]), 6) for dd in zs]}, Klassen {[int(kl[dd]) for dd in zs]}")
    T2 = {"c": np.exp(np.where(np.arange(n) > 20, x + 0.3, x)), "sig": sig}
    ok("Schichtung: kausal -- spätere Kurse ändern die Klassen bis Tag 20 nicht", np.array_equal(_r7_klasse(T2)[:21], kl[:21]))
    k4s = np.array([[10, 90, 5, 95], [20, 80, 10, 90], [0, 0, 0, 0]], dtype=float)
    ok("Mantel-Haenszel: zwei Schichten (10/100 gegen 5/100, 20/100 gegen 10/100) -> 2,0; leere Schicht ohne Wirkung; eine Schicht = RR",
       abs(float(_mh(k4s)) - 2.0) < 1e-12 and abs(float(_mh(k4s[:1])) - _rr4(k4s[0])) < 1e-12, f"{float(_mh(k4s))}")


def _probe_ereignisse(ok) -> None:
    n = 40; c = np.full(n, 100.0); h_ = c.copy(); l_ = c.copy(); sig = np.full(n, 0.02)
    thr = math.exp(-K_KURS * 0.02 * math.sqrt(7))
    l_[10] = 100.0 * thr * 0.999                                            # Tief an Tag 10: Ausschlag ab für d = 3 … 9
    h_[30] = 100.0 / thr * 1.001                                            # Hoch an Tag 30: auf für d = 23 … 29
    ab, auf, gl = ereignis_kurs(c, h_, l_, sig, 7)
    ok("Ausschlag ab/auf über Tief/Hoch der Tage d+1 … d+7; die letzten 7 Tage ungültig",
       list(np.nonzero(ab)[0]) == list(range(3, 10)) and list(np.nonzero(auf)[0]) == list(range(23, 30)) and not gl[33:].any() and gl[32],
       f"ab {list(np.nonzero(ab)[0])}, auf {list(np.nonzero(auf)[0])}")
    l2 = c.copy(); l2[10] = 100.0 * math.exp(-K_KURS * 0.02 * 2.0)              # tiefer als 1,5 σ, aber nicht 1,5 σ·√7
    ab2, _, _ = ereignis_kurs(c, c.copy(), l2, sig, 7)
    ok("Ausschlag: Schwelle wächst mit √h (ein Tief bei 3 σ zählt nicht bei h = 7)", not ab2.any(), f"{list(np.nonzero(ab2)[0])}")
    tag0 = tag_von("2021-01-01"); n = 30
    T = {"tag0": tag0, "n": n, "oi": np.full(n, 1000.0), "s_oi": np.full(n, 0.02), "oi_h0": tag0 * 24}
    lh = np.full(n * 24, math.log(1000.0)); d = 10; hd = (d + 1) * 24
    schritt = K_OI * 0.02 * math.sqrt(7) * 1.01
    lh1 = lh.copy(); lh1[hd + 24 * 7] -= schritt                             # letzte Stunde im Fenster
    lh2 = lh.copy(); lh2[hd + 24 * 7 + 1] -= schritt                         # erste Stunde danach
    lh3 = lh.copy(); lh3[hd] -= schritt                                      # die Stunde des Stands selbst
    T1 = dict(T, ln_oi_h=lh1); T2 = dict(T, ln_oi_h=lh2); T3 = dict(T, ln_oi_h=lh3)
    O1, g1 = oi_abbau(T1, 7); O2, _ = oi_abbau(T2, 7); O3, _ = oi_abbau(T3, 7)
    ok("OI-Abbau: Fenster (Ende d, Ende d+7] in Stunden -- letzte Stunde zählt, erste danach und die Stunde des Stands nicht",
       O1[d] and not O2[d] and not O3[d] and O3[d - 1], f"{O1[d]}, {O2[d]}, {O3[d]}, d−1 {O3[d - 1]}")
    lh4 = lh.copy(); lh4[hd + 1:hd + 1 + 40] = np.nan
    O4, g4 = oi_abbau(dict(T, ln_oi_h=lh4), 7)
    ok("OI-Abbau: weniger als 80 % der Stunden -> ungültig", g1[d] and not g4[d], f"{g1[d]}, {g4[d]}")
    w = welle({**T1, "c": np.full(n, 100.0), "h": np.full(n, 100.0), "l": np.where(np.arange(n) == 14, 100.0 * thr * 0.99, 100.0),
               "sig": np.full(n, 0.02)}, 7)
    ok("Welle = OI-Abbau und Ausschlag; Richtung „ab“", w["E"][d] and w["richt"][d] == 1 and not w["E"][d - 5], f"{w['E'][d]}, {w['richt'][d]}")


def _probe_signale(ok) -> None:
    T = {"konten": np.array([2.99, 3.0, 3.01, np.nan]), "top_pos": np.array([1.5, 1.49, 0.67, 0.68, np.nan]),
         "anteil": np.array([0.95, 0.9499, np.nan]), "anteil_pz": np.array([0.90, 0.899, np.nan])}
    s1 = _sig_konten(T); s2 = _richt_top(T); s3 = _sig_anteil(T); s4 = _sig_anteil_pz(T)
    ok("Signale an der Schwelle: Konten ≥ 3, Top-Trader ≥ 1,5 Kauf / ≤ 0,67 Verkauf, Perp-Anteil ≥ 0,95, Perzentil ≥ 0,90; NaN undefiniert",
       list(s1[0]) == [False, True, True, False] and list(s1[1]) == [True, True, True, False] and list(s2[0]) == [1, 0, -1, 0, 0]
       and list(s2[1]) == [True, True, True, True, False] and list(s3[0]) == [True, False, False] and list(s4[0]) == [True, False, False],
       f"{list(s1[0])} {list(s2[0])} {list(s3[0])} {list(s4[0])}")


def _probe_identitaet(ok) -> None:
    t = shifts()
    ok("Verschiebungen: 672, 30–365 Tage, beide Richtungen, ohne kleine", len(t) == 672 and np.abs(t).min() == SHIFT_MIN and np.abs(t).max() == SHIFT_MAX
       and (t > 0).sum() == (t < 0).sum(), f"{len(t)}")
    c = 100.0 * np.exp(np.cumsum(np.random.default_rng(5).normal(0, 0.02, 200)))
    V = np.ones((3, 200), dtype=np.int8)
    X = ZY.surrogate({"c": c, "tag0": 100, "n": 200}, V, 100, 0.0005)
    ok("Surrogat mit Vorzeichen +1 = echter Kurs", np.allclose(X[1], c) and np.allclose(X[0], c))


def _probe_urteile(ok) -> None:
    def rr(p, hv=((1.5, 1.0), (1.4, 1.0)), st=60, ep=5, ohne=500):
        return {"coins": ["BTC"], "art": "rr", "p": p, "signaltage": st, "episoden": ep, "ohne": ohne,
                "haelften_werte": {0: hv[0], 1: hv[1]}, "t": None}
    def ri(p, t=0.1, nm=0.0, hv=((0.12, 0.0), (0.08, 0.0))):
        return {"coins": ["BTC"], "art": "richtung", "p": p, "signaltage": 60, "episoden": 5, "t": t, "null_median": nm,
                "haelften_werte": {0: hv[0], 1: hv[1]}}
    V = {"richtung": {"H1": rr(0.01), "H2": ri(0.04)}, "risiko": {"H3": {**rr(0.001), "art": "risiko", "signaltage": 10}, "H4": {**rr(0.02), "art": "risiko"}}}
    urteile(V, True)
    a = {**V["richtung"], **V["risiko"]}
    ok("Urteil: Holm über die prüfbaren (H3 mit 10 Signaltagen nicht prüfbar); 0,01·3, 0,02·2, 0,04 -> alle belegt",
       a["H1"]["belegt"] and a["H2"]["belegt"] and a["H4"]["belegt"] and not a["H3"]["pruefbar"] and abs(a["H1"]["p_holm"] - 0.03) < 1e-12
       and abs(a["H2"]["p_holm"] - 0.04) < 1e-12, f"{[(k, round(o['p_holm'], 3) if np.isfinite(o['p_holm']) else None, o['belegt']) for k, o in a.items()]}")
    urteile(V, False)
    ok("Urteil: Historie unvollständig -> Bedingung ja, belegt nein (vorläufig)", a["H1"]["bedingung"] and not a["H1"]["belegt"])
    V2 = {"richtung": {"H1": rr(0.001, hv=((1.5, 1.0), (0.9, 1.0))), "H2": ri(0.001, hv=((0.12, 0.0), (-0.02, 0.0)))}, "risiko": {}}
    urteile(V2, True)
    ok("Urteil: eine Hälfte gegen die Richtung -> nicht belegt (RR und T)", not V2["richtung"]["H1"]["belegt"] and not V2["richtung"]["H2"]["belegt"])
    V3 = {"richtung": {"H2": ri(0.001, t=-0.1, nm=0.0, hv=((-0.12, 0.0), (-0.05, 0.0)))}, "risiko": {}}
    urteile(V3, True)
    ok("Urteil H2: „dagegen“ in beiden Hälften ist belegbar (zweiseitig)", V3["richtung"]["H2"]["belegt"])
    V4 = {"richtung": {"H1": rr(0.001, ep=2)}, "risiko": {}}
    urteile(V4, True)
    ok("Urteil: weniger als 3 Episoden -> nicht prüfbar", not V4["richtung"]["H1"]["pruefbar"] and not V4["richtung"]["H1"]["belegt"])


def _probe_abgleich(ok) -> None:
    tmp = tempfile.mkdtemp(prefix="hebel_abgl_")
    try:
        haupt = os.path.join(tmp, "hl_liq.db"); h = sqlite3.connect(haupt)
        h.execute("CREATE TABLE bnc_metrics (ts INTEGER, coin TEXT, metric TEXT, value REAL, PRIMARY KEY (ts, coin, metric))")
        ts = np.arange(100) * 3600 + 1_700_000_000 // 3600 * 3600
        rg = np.random.default_rng(9)
        M = {"BTC": {"ts": ts.astype(np.int64), "konten": 1.5 + rg.random(100), "top_konten": 1.2 + rg.random(100), "top_pos": 0.8 + rg.random(100),
                     "taker": 0.9 + rg.random(100) * 0.2, "oi": 1000 + rg.random(100) * 10}}
        rows = []
        for i, t in enumerate(ts):
            rows += [(int(t) + 300, "BTC", "global_ls_account", float(M["BTC"]["konten"][i])),          # Versatz +300 s
                     (int(t), "BTC", "top_ls_account", float(M["BTC"]["top_pos"][i])),                   # vertauscht
                     (int(t), "BTC", "top_ls_position", float(M["BTC"]["top_pos"][i]) * 1.001),
                     (int(t) + 40, "BTC", "open_interest", float(M["BTC"]["oi"][i]))]
        rows.append((1_700_000_000_000, "BTC", "taker_ls", 1.0))
        h.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", rows); h.commit(); h.close()
        A = abgleich(haupt, M)
        g = A["metriken"]
        ok("Abgleich: Versatz +300 s erkannt, vertauschte Spalte gemeldet, OI binnen 150 s, ms-Zeilen gezählt",
           g["global_ls_account"]["versatz"] == 300 and g["global_ls_account"]["zuordnung_ok"] and not g["top_ls_account"]["zuordnung_ok"]
           and g["top_ls_account"]["bestes"][0] == "top_pos" and g["top_ls_position"]["zuordnung_ok"] and g["open_interest"]["zuordnung_ok"]
           and A["ms_zeilen"] == 1 and g["taker_ls"]["n"] == 0,
           f"{ {k: (v.get('versatz'), v.get('zuordnung_ok'), v.get('bestes')) for k, v in g.items()} }, ms {A['ms_zeilen']}")
        txt = bericht_text({"abgleich": A, "info": {"pfad": "x"}, "laden": None})
        ok("Bericht: ohne Studie und mit Abgleich ohne Absturz; Zuordnung und ms-Zeilen genannt", "ZUORDNUNG PRÜFEN" in txt and "Millisekunden" in txt)
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _kerzen_archiv(K: dict) -> dict:
    """Monatsdateien der Tageskerzen aus synthetischen Reihen K, wie im Archiv (COIN-M: Volumen in Kontrakten)."""
    d = {}
    for (markt, symbol), k in K.items():
        coin = symbol[:3] if symbol[:3] in KONTRAKT_USD else symbol[:4]
        je_monat: dict = {}
        for i, t in enumerate(k["tag"]):
            je_monat.setdefault(monat_von(int(t)), []).append(i)
        for m, idx in je_monat.items():
            z = []
            for i in idx:
                ms = int(k["tag"][i]) * TAG * 1000; c = float(k["c"][i]); vu = float(k["v_usd"][i]); tu = float(k["taker_usd"][i])
                if markt == "cm":
                    kg = KONTRAKT_USD[coin]; v, q, tb, tq = vu / kg, 0.0, tu / kg, 0.0
                else:
                    v, q, tb, tq = vu / c, vu, tu / c, tu
                z.append(f"{ms},{c!r},{float(k['h'][i])!r},{float(k['l'][i])!r},{c!r},{v!r},{ms + TAG * 1000 - 1},{q!r},100,{tb!r},{tq!r},0")
            d[url_kerzen(markt, symbol, m)] = _zip("k.csv", "\n".join(z) + "\n")
    return d


def _probe_ende_zu_ende(ok) -> None:
    """Synthetische hebel.db -> studie() wie auf dem Pi, mit wenigen Surrogaten. Seit 23.64 kommen die Kerzen über den Lader aus einem
    Archiv ohne Netz (bis 23.63 direkt in die Datenbank geschrieben -- so blieb der Ladefehler unentdeckt); metrics direkt."""
    tmp = tempfile.mkdtemp(prefix="hebel_e2e_"); alt = os.environ.get("HL_HEBEL_DB"); alt_s = os.environ.get("HL_SWING_DB")
    alt_q = QUELLE["holen"]
    try:
        K, M = _universum(31, n=700, effekt="H4")
        pfad = os.path.join(tmp, "hebel.db"); con = verbinden(pfad)
        zeilen = []
        for coin, m in M.items():
            for i in range(0, len(m["ts"])):
                zeilen.append((coin, int(m["ts"][i]), float(m["oi"][i]), float(m["oi_usd"][i]), float(m["top_konten"][i]), float(m["top_pos"][i]),
                               None if coin == "XMR" else float(m["konten"][i]), float(m["taker"][i])))
        _schreiben(con, "INSERT OR REPLACE INTO hb_metrics VALUES (?,?,?,?,?,?,?,?)", zeilen)
        meta_setzen(con, {f"m_fertig:{c}": 1 for c in COINS})
        con.close()
        QUELLE["holen"] = _FakeArchiv(_kerzen_archiv(K)); _ZULETZT.clear()
        e = laden(pfad, None, budget_s=600, log=lambda *a: None, pause=0)       # echte Uhr wie studie(): spätere Monate ohne Datei
        os.environ["HL_HEBEL_DB"] = pfad; os.environ["HL_SWING_DB"] = os.path.join(tmp, "fehlt_swing.db")
        L = daten_laden(os.path.join(tmp, "hl_liq.db"))
        n_k = {s: len(K[s]["tag"]) for s in K}
        n_db = {s: len(L["K"][s]["tag"]) if s in L["K"] else 0 for s in K}
        ok("Ende zu Ende: Kerzen über den Lader (alle 15 synthetischen Reihen vollständig, Spot und Perp gleichen Namens), fünf Tafeln, "
           "NULL wird NaN (XMR ohne Konten), Perp-Anteil für BTC/ETH",
           n_db == n_k and len(L["tafeln"]) == 5 and np.isnan(L["tafeln"]["XMR"]["konten"]).all() and L["tafeln"]["BTC"]["anteil"] is not None
           and np.isfinite(L["tafeln"]["ETH"]["anteil"]).sum() > 500 and L["tafeln"]["ZEC"]["anteil"] is None and not e.get("abbruch"),
           f"{e.get('dateien')} Abrufe; Reihen {sum(n_db[s] == n_k[s] for s in K)}/{len(K)} vollständig; {list(L['tafeln'])}")
        txt = studie(os.path.join(tmp, "hl_liq.db"), n_surr=60)
        teil = txt.split(f"H4 {HAUPT[3][1]}:", 1); h4 = teil[1].splitlines()[1:2] if len(teil) == 2 else []
        ok("Ende zu Ende: studie() wie auf dem Pi -- Ladestand vollständig, H4 mit Daten, Bericht mit Ergebnis und Nachtrag, ohne Absturz",
           "ERGEBNIS" in txt and "Ladestand: vollständig" in txt and h4 and "ohne Daten" not in h4[0] and "NACHTRÄGLICH ERGÄNZT" in txt
           and "Hauptdatenbank nicht lesbar" in txt and "swing.db fehlt" in txt, f"{len(txt.splitlines())} Zeilen; H4: {h4[0][:80] if h4 else '—'}")
    finally:
        QUELLE["holen"] = alt_q; _ZULETZT.clear()
        for k, v in (("HL_HEBEL_DB", alt), ("HL_SWING_DB", alt_s)):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


CQ_TESTSCHLUESSEL = "cqTEST_k3y-0123456789abcdefXYZ"                # nur im Selbsttest
CQ_NACHWEIS = ("gemessen 17.10.2026 auf synthetischen Märkten (Wellenquote ohne Signal rund 4 %, wie H4 auf echten Daten 5,5 %): bei "
               "RR ≈ 3 belegt mit 450 Tagen Reihe 8 von 30, mit 720 Tagen 14–19 von 30, mit 1095 Tagen 23 von 30; ohne Effekt 4 von 80 "
               "(450 T), 3 von 80 (720 T), 1 von 60 (1095 T)")


def _cq_antwort(tage, werte, status=(200, "success")) -> dict:
    """Antwort in der dokumentierten Form (status, result.window, result.data mit date YYYY-MM-DD und volume)."""
    return {"status": {"code": status[0], "message": status[1]},
            "result": {"window": "day", "data": [{"date": datum_von(int(t)), "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": w}
                                                 for t, w in zip(tage, werte)]}}


class _CqNetz:
    """Attrappe der CryptoQuant-API ohne Netz: je Markt eine Tagesreihe {tag: volumen}; merkt jede Anfrage; fehler: Liste von
    (art, text, code), je Aufruf einer (danach wieder Daten)."""

    def __init__(self, spot: dict, perp: dict, fehler: list | None = None):
        self.werte = {"spot": dict(spot), "perpetual": dict(perp)}; self.aufrufe = []; self.fehler = list(fehler or [])

    def __call__(self, url, schluessel, timeout=30):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        self.aufrufe.append({"url": url, "q": q, "schluessel": schluessel})
        if self.fehler:
            art, text, code = self.fehler.pop(0)
            return art, None, text, code
        m = q["market"][0]
        f = lambda s: tag_von(f"{s[:4]}-{s[4:6]}-{s[6:8]}")
        von, bis = f(q["from"][0]), f(q["to"][0])
        tage = [t for t in sorted(self.werte[m]) if von <= t <= bis]
        return "ok", _cq_antwort(tage, [self.werte[m][t] for t in tage]), "", 200


def _probe_cq(ok) -> None:
    """U158: Parser, Adresse, Archiv mit Abrufzeit, Rückschau füllt Lücken, Takt, Schlüssel, Pausen, Kennzahl von Hand."""
    tmp = tempfile.mkdtemp(prefix="hebel_cq_"); alt_env = os.environ.pop("CRYPTOQUANT_API_KEY", None); alt_q = QUELLE["cq_holen"]
    k = CQ_TESTSCHLUESSEL
    try:
        heute = tag_von("2026-10-17"); jetzt = heute * TAG + 2 * 3600                       # 02:00 UTC
        # 1) Parser gegen die dokumentierte Antwortform
        tage = list(range(heute - 31, heute + 1))
        werte = [100000.0 + i for i in range(len(tage))]
        roh = _cq_antwort(tage, werte)
        dat = roh["result"]["data"]
        dat[3]["volume"] = None; dat[4]["volume"] = ""; dat[5]["volume"] = "NaN"; dat[6]["volume"] = -5.0; dat[7]["date"] = "2026-13-40"
        dat.append(dict(dat[10]))                                                          # doppelter Tag
        z, b = cq_parse(roh, "spot", heute)
        soll = [(CQ_REIHE["spot"], t, w) for i, (t, w) in enumerate(zip(tage, werte)) if i not in (3, 4, 5, 6, 7) and t < heute]
        z401, b401 = cq_parse({"status": {"code": 401, "message": "unauthorized"}}, "spot", heute)
        z_ohne, b_ohne = cq_parse({"status": {"code": 200, "message": "success"}, "result": {"window": "day"}}, "spot", heute)
        ok("U158 Parser: dokumentierte Antwort (status, result.data mit date/volume), nur abgeschlossene Tage, „kein Wert“ (null, leer, NaN, "
           "≤ 0, Datum unlesbar) fällt weg, doppelter Tag einmal; Volumen unverändert (BTC); Status ≠ 200 und fehlendes data ohne Zeilen",
           z == soll and b["zeilen"] == 26 and b["verworfen"] == 7 and b["datum_fehler"] == 1 and b["status"] == "200 success"
           and "volume" in b["felder"] and b["von"] == heute - 31 and b["bis"] == heute - 1 and not z401 and "401" in b401["fehler"]
           and not z_ohne and "data" in b_ohne["fehler"], f"{b}")
        url = cq_url("perpetual", heute - CQ_RUECK, heute - 1)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        ok("U158 Adresse: btc/market-data/price-ohlcv mit market, exchange=all_exchange, window=day, from/to als YYYYMMDD (30 Tage bis "
           "gestern), ohne Schlüssel in der Adresse",
           url.startswith(CQ_URL + "?") and q["market"] == ["perpetual"] and q["exchange"] == ["all_exchange"] and q["window"] == ["day"]
           and q["from"] == [datum_von(heute - 30).replace("-", "")] and q["to"] == [datum_von(heute - 1).replace("-", "")], url)
        # 2) Abruf, Archiv, Takt
        pfad = os.path.join(tmp, "hebel.db")
        rng = np.random.default_rng(158)
        spot = {t: float(rng.uniform(2e5, 4e5)) for t in range(heute - 400, heute + 30)}
        perp = {t: spot[t] * float(rng.uniform(10, 20)) for t in spot}
        N0 = _CqNetz(spot, perp)
        e0 = cq_abruf(pfad, jetzt, schluessel="", holen=N0)
        ok("U158 ohne Schlüssel kein Abruf", e0 == {"abruf": False, "grund": "kein Schlüssel"} and not N0.aufrufe, f"{e0}")
        warte_log = []
        Nn = _CqNetz(spot, perp)
        e_frueh = cq_abruf(pfad, heute * TAG + 1800, schluessel=k, holen=Nn)
        e1 = cq_abruf(pfad, jetzt, schluessel=k, holen=Nn, warte=warte_log.append)
        e2 = cq_abruf(pfad, jetzt + 3600, schluessel=k, holen=Nn)
        con = verbinden(pfad)
        n1 = con.execute("SELECT COUNT(*) FROM hb_cq").fetchone()[0]
        con.close()
        ok("U158 Takt: vor 01:00 UTC kein Abruf; danach zwei Abrufe (Spot, Perpetual, Abstand 7 s), je 30 Tage bis gestern mit dem "
           "Schlüssel in der Kopfzeile; am selben Tag kein zweiter",
           e_frueh.get("grund") == "vor 01:00 UTC" and e1.get("ok") and e1["neu"] == 60 and n1 == 60 and len(Nn.aufrufe) == 2
           and [a_["q"]["market"][0] for a_ in Nn.aufrufe] == ["spot", "perpetual"] and all(a_["schluessel"] == k and k not in a_["url"] for a_ in Nn.aufrufe)
           and warte_log == [CQ_ABSTAND_S] and e2.get("grund") == "heute schon abgerufen",
           f"{e1.get('neu')} neu, {n1} Zeilen, {len(Nn.aufrufe)} Abrufe, {e2}")
        e3 = cq_abruf(pfad, jetzt + 7200, schluessel=k, holen=Nn, erzwingen=True, warte=lambda s: None)
        perp2 = dict(perp); perp2[heute - 5] = perp[heute - 5] * 1.01
        e4 = cq_abruf(pfad, jetzt + 3 * 3600, schluessel=k, holen=_CqNetz(spot, perp2), erzwingen=True, warte=lambda s: None)
        con = verbinden(pfad)
        fass = con.execute("SELECT COUNT(*) FROM hb_cq WHERE reihe=? AND tag=?", (CQ_REIHE["perpetual"], heute - 5)).fetchone()[0]
        A = cq_tage(con)
        con.close()
        i5 = int(np.nonzero(A["tage"] == heute - 5)[0][0])
        hand = perp2[heute - 5] / (perp2[heute - 5] + spot[heute - 5])
        ok("U158 Archiv mit Abrufzeit: gleicher Wert keine Zeile, Korrektur eine neue (alte bleibt), die jüngste Fassung zählt; Kennzahl von "
           "Hand D = Perps ÷ (Perps + Spot)",
           e3.get("neu") == 0 and e4.get("neu") == 1 and fass == 2 and A["revisionen"] == 1 and abs(A["D"][i5] - hand) < 1e-15
           and len(A["tage"]) == 30, f"neu {e3.get('neu')}/{e4.get('neu')}, Fassungen {fass}, D {A['D'][i5]:.6f} gegen {hand:.6f}")
        e5 = cq_abruf(pfad, jetzt + 6 * TAG, schluessel=k, holen=_CqNetz(spot, perp2), warte=lambda s: None)  # 5 Tage Ausfall
        con = verbinden(pfad); A5 = cq_tage(con); con.close()
        ok("U158 Rückschau 30 Tage füllt einen Ausfall von 5 Tagen ohne Lücke", e5.get("ok") and len(A5["tage"]) == 36
           and int(A5["tage"][-1] - A5["tage"][0]) == 35, f"{len(A5['tage'])} Tage {_dt(int(A5['tage'][0]))}–{_dt(int(A5['tage'][-1]))}")
        # 3) Fehler, Pausen, Schlüssel in keinem Text
        pf2 = os.path.join(tmp, "hebel2.db")
        leck = _CqNetz(spot, perp, fehler=[("http", f'HTTP 401 {{"message":"invalid token {k}"}} Authorization: Bearer {k}', 401)])
        f1 = cq_abruf(pf2, jetzt, schluessel=k, holen=leck)
        con = verbinden(pf2)
        txt1 = meta(con, "cq:fehler", ""); p1 = int(meta(con, "cq:pause_bis", "0"))
        con.close()
        g1 = cq_abruf(pf2, jetzt + 3600, schluessel=k, holen=leck)
        grenze = _CqNetz(spot, perp, fehler=[("http", "HTTP 429 too_many_requests", 429)])
        pf3 = os.path.join(tmp, "hebel3.db")
        f2 = cq_abruf(pf3, jetzt, schluessel=k, holen=grenze)
        g2 = cq_abruf(pf3, jetzt + 600, schluessel=k, holen=grenze)
        h2 = cq_abruf(pf3, jetzt + 901, schluessel=k, holen=grenze, warte=lambda s: None)
        netz = _CqNetz(spot, perp, fehler=[("netz", "URLError: timed out", None)])
        pf4 = os.path.join(tmp, "hebel4.db")
        f3 = cq_abruf(pf4, jetzt, schluessel=k, holen=netz)
        g_b = cq_geschwaerzt(f"Bearer {k} x api_key={k}&y token=abc", k)
        ok("U158 Pausen und Schlüssel: 401 -> 24 h Pause, Fehlertext ohne Schlüssel (auch nicht als Bearer); 429 -> 15 min, danach wieder; "
           "Netzfehler -> 1 h; während der Pause kein Abruf",
           f1.get("ok") is False and p1 == jetzt + 24 * 3600 and k not in txt1 and "Bearer ***" in txt1 and g1.get("abruf") is False
           and len(leck.aufrufe) == 1 and f2.get("pause_s") == 900 and g2.get("abruf") is False and h2.get("ok") and len(grenze.aufrufe) == 3
           and f3.get("pause_s") == 3600 and k not in g_b and g_b.count("***") == 3, f"{txt1[:120]} | {f2} | {h2.get('ok')} | {f3.get('grund')}")
        # 4) Schlüssel eintragen (Feld im Tab „Daten“)
        dt = os.path.join(tmp, "accesstokens.json")
        with open(dt, "w", encoding="utf-8") as f:
            json.dump({"fred": {"api_key": "f" * 32}, "coinglass": {"api_key": "cg"}}, f)
        r_kurz = cq_schluessel_einrichten("abc", pf2, datei=dt, holen=_CqNetz(spot, perp), jetzt=jetzt)
        r_401 = cq_schluessel_einrichten(k, pf2, datei=dt, holen=_CqNetz(spot, perp, fehler=[("http", f"HTTP 401 {k}", 401)]), jetzt=jetzt)
        unveraendert = "cryptoquant" not in json.load(open(dt, encoding="utf-8"))
        r_ok = cq_schluessel_einrichten(k, pf2, datei=dt, holen=_CqNetz(spot, perp), jetzt=jetzt)
        roh_t = json.load(open(dt, encoding="utf-8"))
        con = verbinden(pf2); pause_neu = int(meta(con, "cq:pause_bis", "1")); okt = int(meta(con, "cq:ok_tag", "0")); con.close()
        r_netz = cq_schluessel_einrichten(k, None, datei=os.path.join(tmp, "leer.json"), holen=_CqNetz(spot, perp, fehler=[("netz", "timed out", None)]),
                                          jetzt=jetzt)
        gelesen = cq_schluessel_lesen(dt)
        os.environ["CRYPTOQUANT_API_KEY"] = "  envKEY_0123456789abcdef  "
        gelesen_env = cq_schluessel_lesen(dt)
        os.environ.pop("CRYPTOQUANT_API_KEY", None)
        meld = " ".join(m for _, m in (r_kurz, r_401, r_ok, r_netz))
        ok("U158 Schlüssel eintragen: falsches Format und 401 schreiben nichts; sonst in accesstokens.json (FRED und CoinGlass bleiben), "
           "Pause zurückgesetzt; Netzfehler im Probeabruf: mit Warnung gespeichert; Umgebungsvariable vor Datei; nie in einer Meldung",
           not r_kurz[0] and not r_401[0] and unveraendert and r_ok[0] and roh_t["cryptoquant"]["api_key"] == k and roh_t["fred"]["api_key"] == "f" * 32
           and roh_t["coinglass"]["api_key"] == "cg" and pause_neu == 0 and okt == -1 and r_netz[0] and "trotzdem gespeichert" in r_netz[1]
           and gelesen == (k, "accesstokens.json") and gelesen_env[0] == "envKEY_0123456789abcdef" and k not in meld,
           f"{r_kurz[1][:60]} | {r_401[1][:70]} | {r_ok[1][:80]}")
        # 5) Stand für den Tab „Daten“ und Chart „Hebel & Stimmung“
        QUELLE["cq_holen"] = _CqNetz(spot, perp)
        os.environ["CRYPTOQUANT_API_KEY"] = k
        st = cq_stand(pfad, jetzt); ch = cq_chart(pfad); st_leer = cq_stand(os.path.join(tmp, "fehlt.db"), jetzt)
        os.environ.pop("CRYPTOQUANT_API_KEY", None)
        ok("U158 Stand und Chart: Schlüssel ja/nein, Tage, letzter Wert, Befund der Antwort; Chart mit Tagen, D und 95-%-Linie",
           st["schluessel"] and st["tage"] == 36 and abs(st["letzter"] - float(A5["D"][-1])) < 1e-12 and st["befund"].get("spot", {}).get("zeilen") == 30
           and ch["t"] == [int(t) for t in A5["tage"]] and abs(ch["v"][-1] - float(A5["D"][-1])) < 1e-5 and ch["schwelle"] == 0.95
           and st_leer["tage"] == 0 and k not in json.dumps(st), f"{ {kk: st.get(kk) for kk in ('schluessel', 'tage', 'letzter')} }")
    finally:
        QUELLE["cq_holen"] = alt_q
        os.environ.pop("CRYPTOQUANT_API_KEY", None)
        if alt_env is not None:
            os.environ["CRYPTOQUANT_API_KEY"] = alt_env
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _s5_markt(saat: int, effekt: str | None, staerke: float, n: int, L: int) -> tuple:
    """Synthetische BTC-Tafel mit CryptoQuant-Anteil D an den letzten L Tagen (die „gesammelte Reihe“)."""
    cq = {"ab": n - L}
    K, M = _universum(saat, n=n, effekt=effekt, staerke=staerke, coins=("BTC",), cq=cq)
    T = tafel_bauen("BTC", K, M.get("BTC"))
    return T, {"tage": cq["tag0"] + np.arange(n - L, n), "D": cq["D"][n - L:]}, K, M


def _probe_s5(ok) -> None:
    """U158: S5 von Hand, Sperre „prüfbar“, Urteil einmal festgehalten, Positivkontrolle und Nullprobe, Bericht Ende zu Ende."""
    T, A, K, M = _s5_markt(41, None, 0.0, 900, 450)
    S = s5_rechnen(T, A, n_boot=200)
    w = welle(T, H_HAUPT); t0 = int(A["tage"][0]); L = len(A["tage"])
    zaehl = [0, 0, 0, 0]; sig_tage = []
    for jj in range(L):
        i = t0 - T["tag0"] + jj
        if not (0 <= i < T["n"]) or not w["gl"][i] or i < T["ev0"]:
            continue
        s_ = A["D"][jj] >= CQ_SCHWELLE
        zaehl[(0 if s_ else 2) + (0 if w["E"][i] else 1)] += 1
        if s_:
            sig_tage.append(jj)
    rr_h = (zaehl[0] / (zaehl[0] + zaehl[1])) / (zaehl[2] / (zaehl[2] + zaehl[3]))
    epi = (1 + sum(1 for a_, b_ in zip(sig_tage[:-1], sig_tage[1:]) if b_ - a_ > H_HAUPT)) if sig_tage else 0
    ok("U158 S5 von Hand: Signal D ≥ 0,95 am Ende von Tag d, Welle E_D(7) wie H3, Zählung, RR und Episoden (Abstand > 7 Tage); "
       "Verschiebungen 30 … L − 30 (L − 59)",
       S["k4"] == zaehl and abs(S["rr"] - rr_h) < 1e-12 and S["n_shift"] == L - 59 and S["L"] == L and S["episoden"] == epi,
       f"k4 {S['k4']} gegen {zaehl}, RR {_r(S['rr'])}, Episoden {S['episoden']} gegen {epi}, {S['n_shift']} Verschiebungen")
    # Sperre „prüfbar“
    D_kurz = np.full(150, 0.90)
    for a_ in (5, 35, 65, 95):
        D_kurz[a_:a_ + 10] = 0.96                                                          # 40 Signaltage in 4 Episoden, nur 150 Tage
    A_kurz = {"tage": A["tage"][:150], "D": D_kurz}
    D_ein = np.full(L, 0.90); D_ein[100:140] = 0.96
    A_ein = {"tage": A["tage"], "D": D_ein}
    A_wenig = {"tage": A["tage"], "D": np.where(np.arange(L) % 40 == 0, CQ_SCHWELLE, 0.90)}          # genau 95 % zählt (≥)
    S_kurz, S_ein, S_wenig = s5_rechnen(T, A_kurz, n_boot=0), s5_rechnen(T, A_ein, n_boot=0), s5_rechnen(T, A_wenig, n_boot=0)
    ok("U158 Sperre „prüfbar“: unter 180 Tagen, mit nur einer Episode oder unter 30 Signaltagen kein Urteil; Grund im Text",
       not S_kurz["pruefbar"] and S_kurz["signaltage"] >= 30 and S_kurz["episoden"] >= 3 and "Tage < 180" in s5_grund(S_kurz)
       and not S_ein["pruefbar"] and S_ein["episoden"] == 1 and S_ein["signaltage"] >= 30 and "Episoden < 3" in s5_grund(S_ein)
       and not S_wenig["pruefbar"] and S_wenig["signaltage"] < 30 and S_wenig["episoden"] >= 3 and "Signaltage < 30" in s5_grund(S_wenig)
       and S["pruefbar"], f"{s5_grund(S_kurz)} | {s5_grund(S_ein)} | {s5_grund(S_wenig)}")
    # Hälften: Effekt nur in der ersten Hälfte des Fensters (Markt 50) -> p < 0,05, aber die zweite Hälfte nicht über der Null
    cq_h = {"ab": 1100 - 720, "bis": 1100 - 360}
    K_h, M_h = _universum(50, n=1100, effekt="S5", staerke=1.0, coins=("BTC",), cq=cq_h)
    S_h = s5_rechnen(tafel_bauen("BTC", K_h, M_h.get("BTC")), {"tage": cq_h["tag0"] + np.arange(380, 1100), "D": cq_h["D"][380:]}, n_boot=0)
    ok("U158 Hälften: Effekt nur in der ersten Hälfte -> p < 0,05, die zweite Hälfte nicht über ihrer Null -> nicht belegt",
       S_h["pruefbar"] and S_h["p"] < 0.05 and not S_h["haelften"] and not S_h["belegt"]
       and S_h["haelften"] == all(a_ > b_ for a_, b_ in S_h["haelften_werte"].values()),
       f"p {_pz(S_h['p'])}, Hälften {[(round(a_, 2), round(b_, 2)) for a_, b_ in S_h['haelften_werte'].values()]}")
    # Urteil einmal festgehalten
    tmp = tempfile.mkdtemp(prefix="hebel_s5_")
    try:
        con = verbinden(os.path.join(tmp, "hebel.db"))
        u0 = s5_urteil_festhalten(con, S_ein, 1000)
        u1 = s5_urteil_festhalten(con, S, 2000)
        S_anders = dict(S, rr=99.0, belegt=not S["belegt"])
        u2 = s5_urteil_festhalten(con, S_anders, 3000)
        u3 = s5_urteil_festhalten(con, S_ein, 4000)                       # später nicht (mehr) prüfbar: das Urteil bleibt
        con.close()
        ok("U158 Urteil: die erste prüfbare Auswertung wird festgehalten (vorher keins), später nie überschrieben, auch nicht von einem "
           "nicht prüfbaren Stand verdrängt",
           u0 is None and u1["stand"] == 2000 and u1["rr"] == S["rr"] and u2["stand"] == 2000 and u2["rr"] == S["rr"] and u2["belegt"] == S["belegt"]
           and (u3 or {}).get("stand") == 2000, f"{u0} | {u1['stand']} | {u2['stand']}, RR {u2['rr']} | {(u3 or {}).get('stand')}")
        # Bericht Ende zu Ende: Kerzen und metrics in hebel.db, Kennzahl über die Attrappe der API in 30-Tage-Abrufen
        pfad = os.path.join(tmp, "e2e", "hebel.db"); os.makedirs(os.path.dirname(pfad))
        T2, A2, K2, M2 = _s5_markt(43, "S5", 1.0, 900, 450)
        con = verbinden(pfad)
        _schreiben(con, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                   [(mk, sy, int(kk["tag"][i]), float(kk["c"][i]), float(kk["h"][i]), float(kk["l"][i]), float(kk["c"][i]), 0.0,
                     float(kk["v_usd"][i]), float(kk["taker_usd"][i]), 0) for (mk, sy), kk in K2.items() for i in range(len(kk["tag"]))])
        m2 = M2["BTC"]
        _schreiben(con, "INSERT OR REPLACE INTO hb_metrics VALUES (?,?,?,?,?,?,?,?)",
                   [("BTC", int(m2["ts"][i]), float(m2["oi"][i]), float(m2["oi_usd"][i]), float(m2["top_konten"][i]), float(m2["top_pos"][i]),
                     float(m2["konten"][i]), float(m2["taker"][i])) for i in range(len(m2["ts"]))])
        con.close()
        sp = {int(t): 1e5 for t in A2["tage"]}; pe = {int(t): 1e5 * d / (1 - d) for t, d in zip(A2["tage"], A2["D"])}
        netz = _CqNetz(sp, pe)
        letzt = int(A2["tage"][-1]) + 1
        for tag_abruf in range(int(A2["tage"][0]) + 1, letzt + 1, 25):
            cq_abruf(pfad, tag_abruf * TAG + 2 * 3600, schluessel=CQ_TESTSCHLUESSEL, holen=netz, warte=lambda s: None)
        cq_abruf(pfad, letzt * TAG + 2 * 3600, schluessel=CQ_TESTSCHLUESSEL, holen=netz, warte=lambda s: None)
        alt = os.environ.get("HL_HEBEL_DB"); os.environ["HL_HEBEL_DB"] = pfad; os.environ["CRYPTOQUANT_API_KEY"] = CQ_TESTSCHLUESSEL
        try:
            txt = s5_bericht(os.path.join(tmp, "e2e", "hl_liq.db"), jetzt=letzt * TAG + 3 * 3600, n_boot=100)
            txt2 = s5_bericht(os.path.join(tmp, "e2e", "hl_liq.db"), jetzt=letzt * TAG + 4 * 3600, n_boot=100)
            con = _lesen(pfad); A_db = cq_tage(con); con.close()
            T_db, _ = btc_tafel(os.path.join(tmp, "e2e", "hl_liq.db"))
        finally:
            os.environ.pop("CRYPTOQUANT_API_KEY", None)
            if alt is None:
                os.environ.pop("HL_HEBEL_DB", None)
            else:
                os.environ["HL_HEBEL_DB"] = alt
        S_db = s5_rechnen(T_db, A_db, n_boot=100)
        ok("U158 Bericht Ende zu Ende: Kennzahl über die API-Attrappe in 30-Tage-Abrufen vollständig (450 Tage, D wie gesetzt), BTC-Tafel aus "
           "hebel.db, Urteil festgehalten und im zweiten Lauf gleich; Abschnitte vollständig; Schlüssel in keinem Text",
           len(A_db["tage"]) == 450 and np.max(np.abs(A_db["D"] - A2["D"])) < 1e-12 and "URTEIL (erste prüfbare Auswertung" in txt
           and txt.split("URTEIL", 1)[1].splitlines()[0] == txt2.split("URTEIL", 1)[1].splitlines()[0] and "ABRUF" in txt and "KENNZAHL" in txt
           and "Tage ≥ 95 % je Monat" in txt and "Abstand zu Binance allein" in txt and CQ_TESTSCHLUESSEL not in txt + txt2
           and f"RR {_r(S_db['rr'])}" in txt and S_db["belegt"] == ("✓ belegt" in txt.split("URTEIL", 1)[1].splitlines()[0]),
           f"{len(A_db['tage'])} Tage, RR {_r(S_db['rr'])}, p {_pz(S_db['p'])}, {txt.split('URTEIL', 1)[1].splitlines()[0][:90] if 'URTEIL' in txt else '—'}")
        os.environ["HL_HEBEL_DB"] = os.path.join(tmp, "leer", "hebel.db"); os.makedirs(os.path.join(tmp, "leer"))
        alt_tok = globals()["TOKENS_DATEI"]; globals()["TOKENS_DATEI"] = os.path.join(tmp, "keine_accesstokens.json")   # nicht die des Pi
        alt_env = os.environ.pop("CRYPTOQUANT_API_KEY", None)
        try:
            txt0 = s5_bericht(os.path.join(tmp, "leer", "hl_liq.db"), n_boot=10)
        finally:
            globals()["TOKENS_DATEI"] = alt_tok
            if alt_env is not None:
                os.environ["CRYPTOQUANT_API_KEY"] = alt_env
            if alt is None:
                os.environ.pop("HL_HEBEL_DB", None)
            else:
                os.environ["HL_HEBEL_DB"] = alt
        ok("U158 Bericht ohne Schlüssel und ohne Daten: „kein Schlüssel -- kein Abruf“, „noch nicht prüfbar“, kein Absturz",
           "kein Schlüssel -- kein Abruf" in txt0 and "noch nicht prüfbar" in txt0 and "noch keine Tage" in txt0, txt0.splitlines()[5][:80])
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    # Positivkontrolle (RR ≈ 3, Reihe 3 Jahre) und Nullprobe (ohne Effekt, Reihe 450 Tage)
    pos = [s5_rechnen(*_s5_markt(2000 + i, "S5", 0.35, 1300, 1095)[:2], n_boot=0) for i in range(20)]
    ps = np.array([r["p_sig"] for r in pos]); po = np.array([r["p_ohne"] for r in pos]); rr_pool = float(np.mean(ps) / np.mean(po))
    nb = sum(r["belegt"] for r in pos)
    ok("U158 Positivkontrolle: eingepflanzter RR ≈ 3 nach S5-Tagen (gepoolt 2–4), Reihe 1095 Tage -> belegt in den meisten von 20 Märkten",
       nb >= 11 and 2.0 <= rr_pool <= 4.0, f"belegt {nb} von 20, RR gepoolt {_r(rr_pool)}")
    nul = [s5_rechnen(*_s5_markt(1000 + i, None, 0.0, 900, 450)[:2], n_boot=0) for i in range(40)]
    n0 = sum(r["belegt"] for r in nul)
    n_pr = sum(r["pruefbar"] for r in nul)
    ok("U158 Nullprobe: ohne Effekt, Reihe 450 Tage -> höchstens 10 % belegt (40 Märkte; die meisten prüfbar)", n0 <= 4 and n_pr >= 30,
       f"belegt {n0} von 40, prüfbar {n_pr}")


def _probe_statistik(ok) -> None:
    still = lambda s: None
    nS, nB = 200, 100                                   # zweiseitig kleinstes p 2/201, mit Holm über 4 rund 0,04
    K, M = _universum(11)
    V0 = studie_rechnen(_tafeln(K, M), nS, nB, True, still)
    alle = {**V0["richtung"], **V0["risiko"]}
    bel = [k for k, _ in HAUPT if (alle.get(k) or {}).get("bedingung")]
    ok("Nulltest: Zufallsmarkt (5 Coins, GARCH, persistente Verhältnisse, Null-Gebühren-Bruch) -> H1–H4 ohne Beleg", not bel,
       "p " + ", ".join(f"{k} {_pz((alle.get(k) or {}).get('p'))}" for k, _ in HAUPT) + (f" -- belegt: {bel}" if bel else ""))
    ok("Nulltest: alle vier Hauptprüfungen prüfbar (genug Signaltage und Episoden)", all((alle.get(k) or {}).get("pruefbar") for k, _ in HAUPT),
       ", ".join(f"{k} {(alle.get(k) or {}).get('signaltage')}/{(alle.get(k) or {}).get('episoden')}" for k, _ in HAUPT))
    txt = bericht_text({**V0, "tafeln": _tafeln(K, M), "info": {"pfad": "synthetisch", "fehlt": []}, "laden": None, "je_jahr": je_jahr(_tafeln(K, M)),
                        "anteil_jahre": anteil_jahre(_tafeln(K, M)), "stand": stand_heute(_tafeln(K, M), {})})
    ok("Bericht: Studie mit allen Teilen ohne Absturz", all(s in txt for s in ("ERGEBNIS", "STAND HEUTE", "H1–H4 IM EINZELNEN", "BESCHREIBEND",
                                                                              "NACHTRÄGLICH ERGÄNZT", "LESART")), f"{len(txt.splitlines())} Zeilen")
    G0 = V0.get("h1_geschichtet") or {}; h1 = V0["richtung"]["H1"]
    G1 = h1_geschichtet(_tafeln(K, M), nS, klassen=False, je_coin=False)
    ok("Geschichtet (nachträglich): eine Schicht = roher H1-RR mit derselben Null und demselben p (dieselben Surrogate)",
       abs(G1["mh"] - h1["rr"]) < 1e-9 and abs(G1["null_median"] - h1["null_median"]) < 1e-9 and G1["p"] == h1["p"] and G0.get("klassen") == 5,
       f"{_r(G1['mh'])} gegen {_r(h1['rr'])}, Null {_r(G1['null_median'])} gegen {_r(h1['null_median'])}, p {_pz(G1['p'])} gegen {_pz(h1['p'])}")
    ok("Nulltest geschichtet: Zufallsmarkt -> kein Hinweis (p ≥ 0,05)", G0.get("p", 0.0) >= 0.05,
       f"RR {_r(G0.get('mh'))} gegen Null {_r(G0.get('null_median'))}, p {_pz(G0.get('p'))}")
    K, M = _universum(500, effekt="Momentum")
    Vm = studie_rechnen(_tafeln(K, M), nS, nB, True, still); om = Vm["richtung"]["H1"]; Gm = Vm["h1_geschichtet"]
    ok("Negativkontrolle (nachträglich): Konten spiegeln nur die Vorwoche, Kurs mit Momentum -> roh p < 0,05 (die Surrogate sehen Momentum "
       "nicht), geschichtet p ≥ 0,05", om["p"] < 0.05 and Gm["p"] >= 0.05,
       f"roh RR {_r(om['rr'])} gegen Null {_r(om['null_median'])}, p {_pz(om['p'])}; geschichtet RR {_r(Gm['mh'])} gegen Null "
       f"{_r(Gm['null_median'])}, p {_pz(Gm['p'])}")
    for eff, key, teil, st, name in (("H1", "H1", "richtung", 1.0, "H1"), ("H2", "H2", "richtung", 1.0, "H2 folgen"),
                                     ("H2", "H2", "richtung", -1.0, "H2 dagegen"), ("H3", "H3", "risiko", 1.0, "H3"), ("H4", "H4", "risiko", 1.0, "H4")):
        K, M = _universum(20 + int(key[1]) + (5 if st < 0 else 0), effekt=eff, staerke=st)
        V = studie_rechnen(_tafeln(K, M), nS, nB, True, still)
        o = V[teil][key]
        if teil == "richtung" and key == "H2":
            extra = f"T {_de(o.get('t'), 3, True)} gegen Null {_de(o.get('null_median'), 3, True)}"
            richtig = (o.get("t", 0) - o.get("null_median", 0)) * st > 0
        else:
            extra = f"RR {_r(o.get('rr'))} gegen Null {_r(o.get('null_median'))}"
            richtig = o.get("rr", 0) > o.get("null_median", np.inf)
        ok(f"Positivkontrolle {name}: gepflanzter Effekt -> {key} belegt, in der richtigen Richtung", o.get("belegt") and richtig,
           f"{extra}, p Holm {_pz(o.get('p_holm'))}")
        if key == "H1":
            G = V["h1_geschichtet"]
            ok("Positivkontrolle geschichtet (nachträglich): echter Konten-Effekt bleibt nach der Schichtung (p < 0,05)",
               G["p"] < 0.05 and G["mh"] > G["null_median"], f"RR {_r(G['mh'])} gegen Null {_r(G['null_median'])}, p {_pz(G['p'])}")


def selbsttest(schnell: bool = False) -> bool:
    print("Hebel-Studie (U142) -- Selbsttest: Parser, Laden ohne Netz (Spot und Perp getrennt, Umstellung 23.64), Sicherung, Tafel und "
          "Kausalität, Schichtung, Ereignisse, Verschiebungen, Urteile, Abgleich, Bericht, Nulltest, Positiv- und Negativkontrollen", flush=True)
    alles, _, dauer = probe(True, schnell)
    print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({dauer:.0f} s)", flush=True)
    return alles


# ================================================================================================ Aufruf

def main() -> int:
    ap = argparse.ArgumentParser(description="Hebel-Studie (U142): Positionierung und Hebel gegen Spot")
    ap.add_argument("--studie", action="store_true")
    ap.add_argument("--laden", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--db", default=os.environ.get("HL_DB", "hl_liq.db"))
    ap.add_argument("--budget", type=float, default=600.0, help="Sekunden für --laden (geplante Berichte enden nach 15 min)")
    ap.add_argument("--surrogate", type=int, default=None, help="weniger Surrogate (nur zum Ausprobieren; das Urteil gilt mit 1000)")
    ap.add_argument("--s5", action="store_true", help="U158: CryptoQuant-Anteil der Derivate und S5 (Bericht; hält das erste prüfbare "
                                                      "Urteil fest, danach nur beschreibend)")
    ap.add_argument("--cq-abruf", action="store_true", help="U158: CryptoQuant jetzt abrufen (auch vor 01:00 UTC; eine Pause gilt)")
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.laden:
        pfad = hebel_pfad(a.db)
        print(f"Hebel: Historie laden bzw. ergänzen -> {pfad} (höchstens {a.budget:.0f} s) …", flush=True)
        e = laden(pfad, a.db, budget_s=a.budget)
        if e.get("uebersprungen"):
            print("  übersprungen: ein anderer Ladevorgang läuft (Hebel-Takt) -- er lädt weiter", flush=True)
            return 0
        print(f"  Dateien {e.get('dateien')}, neu {e.get('ok')}, ohne Datei {e.get('404')}, Fehler {e.get('fehler')}, Zeilen {e.get('zeilen')}"
              + (f", Abbruch: {e['abbruch']}" if e.get("abbruch") else "") + (", Netzpause" if e.get("pause") else ""), flush=True)
        if e.get("sicherung"):
            print(f"  Sicherung: {e['sicherung']}", flush=True)
        st = e.get("stand") or {}
        print("  Ladestand: " + ("vollständig" if st.get("vollstaendig") else "noch nicht vollständig"), flush=True)
        for coin, o in (st.get("coins") or {}).items():
            print(f"    {coin}: {o['zeilen']} Stunden" + (f" ab {time.strftime('%d.%m.%Y', time.gmtime(o['von']))}" if o["von"] else "")
                  + (", fertig" if o["fertig"] else ", lädt"), flush=True)
        return 0
    if a.studie:
        print(studie(a.db, a.surrogate or N_SURR), flush=True)
        return 0
    if a.cq_abruf:                                                       # 23.68 (U158)
        e = cq_abruf(hebel_pfad(a.db), erzwingen=True)
        if not e.get("abruf"):
            print(f"CryptoQuant: kein Abruf -- {e.get('grund')}", flush=True)
        elif e.get("ok"):
            print(f"CryptoQuant: abgerufen, {e.get('neu')} neue Fassungen; " + "; ".join(
                f"{m}: {b.get('zeilen')} Tage, verworfen {b.get('verworfen')}" for m, b in (e.get("befund") or {}).items()), flush=True)
        else:
            print(f"CryptoQuant: Fehler bei {e.get('markt')}: {e.get('grund')} -- Pause {int(e.get('pause_s') or 0) // 60} min "
                  "(Text im Bericht --s5)", flush=True)
        return 0
    if a.s5:
        print(s5_bericht(a.db), flush=True)
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
