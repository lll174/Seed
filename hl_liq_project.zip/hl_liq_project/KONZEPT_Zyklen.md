# KONZEPT Zyklen (U141) — Rallyes, Rücksetzer, Warnsignale und „Dip kaufen, laufen lassen“: Regeln vorab, lange Historie zuerst

Stand 09.10.2026, Version 2026-09-23.62 (Opus 5.5). **Status: gebaut** (`hl_zyklus.py`, drei Strategien im TradeLabor, Debug-Bericht
„★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141)“, Berichtsplan 09.10. 12:00). Vorab festgelegt am 09.10.2026 gegen 00:30 Uhr,
**bevor ein einziger echter Kurs für diese Studie gerechnet wurde**; die Kalibrierung (Abschnitt 3a) lief nur auf synthetischen
Märkten. Vor dem ersten echten Lauf an fünf Stellen begründet geändert (Abschnitt 12). Vorschlag zum weiteren Vorgehen: Abschnitt 13.

**Wunsch des Nutzers (08.10. 23:45, gekürzt):** „Dieser Markt funktioniert immer und immer wieder nach dem Pump-and-Dump-Prinzip.
Wenn ein Dump passiert und bestätigt ist, ist der Zeitpunkt zum Einkaufen. Dann muss man den Markt laufen lassen, ohne massenhaft
Trades … HODL, aber nicht zu lange. Wie lange dauert der Zyklus bis zum nächsten Rücksetzer? Nach wie vielen Prozent passiert
durchschnittlich ein Rücksetzer, wo man safe austreten kann? Was sind die genauen Signale, die auf einen Rücksetzer hindeuten
(Overheat, Crowding)? Du hast die Daten: analysiere, bewerte, evaluiere, validiere. Was ist die sicherste Strategie? … Fokus
HYPE, Bitcoin, Ethereum, Gold langfristig; Zcash spekulativ. Mit 500 Trades am Tag wird das nichts.“

**Zusage bis 25.10. bleibt:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen bleiben unberührt. Die 44 bestehenden Labor-Strategien
(38 bis 23.60 und 6 Swing seit 23.61) behalten ihre Kennungen; die drei neuen bekommen eigene (Probe im Labor-Selbsttest).

## 0. Kurzfassung

1. **Eine Studie auf den langen Tageskursen** (Coin Metrics in `makro.db`: BTC ab 2013, ETH und XMR ab 2016, ZEC ab 2017; HYPE
   aus `swing.db` und Gold/PAXG aus `regime.db` nur beschreibend) beantwortet die vier Fragen mit Zahlen und Intervallen:
   - **Teil A Zyklen:** Wie groß werden Rallyes nach einem bestätigten Tief, wie lange dauern sie, wie tief und lang sind die
     Rücksetzer — bei festen Schwellen 10/20/30 %? Und: sind die Rallyes länger oder kürzer, als ein Zufallsweg mit derselben Drift
     und Schwankung sie erzeugt (1000 Vorzeichen-Surrogate; Urteil je Schwelle gepoolt über die vier Coins, Abschnitt 4 und 12)?
   - **Teil B Strategien:** die Idee des Nutzers als feste Regel (Z1 „Dip halten“: Dump ≥ 5 σ, bestätigt durch 1 σ Erholung, Stop
     unter dem Tief, Nachzieh-Stop 3 σ, höchstens 60 Tage) mit zwei Ausstiegs-Varianten (Z2 Überhitzung, Z3 Ziel bei der typischen
     Rallye) gegen HODL, Trendfilter (200-Tage-Mittel) und Volatilitätssteuerung. Zwei Urteile: **Timing** (besser als derselbe
     Ablauf auf Zufallswegen) und **sicherer als HODL** (höheres Sharpe im Kern-Portfolio BTC+ETH, Blockbootstrap).
   - **Teil C Warnsignale:** Sagen Überhitzung (OI), Funding-Druck, RSI ≥ 80 oder Gier (Fear & Greed ≥ 80) einen Rücksetzer in den
     nächsten 14 Tagen voraus — mehr als die Schwankung allein erklärt?
   - **Teil D Gegenprobe:** Z1 und Z2 mit echter Ausführung (Binance-30-min-Kerzen ab 2020, Kosten, Funding) — beschreibend.
2. **Im TradeLabor** laufen ab dieser Version drei neue Swing-Strategien vorwärts: `zyklus_dip` (Z1), `zyklus_dip_heiss` (Z2) und
   die Kontrolle `zyklus_dip_zufall` (zufälliger Long-Einstieg, Ausstiege wie Z1). Wenige Trades: im Mittel rund 4–8 je Coin und Jahr.
3. **Ehrliche Erwartung aus der Mathematik (Abschnitt 2):** Auf einem Zufallsweg ist „nach X % Erholung kaufen, nach X % Rücksetzer
   verkaufen“ vor Kosten ein Nullsummenspiel; Rallyes sind im Mittel doppelt so groß wie die Bestätigungsschwelle, ihre Größe streut
   wie eine Exponentialverteilung. Einen „sicheren Ausstieg bei durchschnittlich X %“ gibt es nur, wenn die echten Kurse davon
   abweichen — genau das misst Teil A. Und wer nur 40 % der Zeit im Markt ist, hat ohne echtes Timing ein um √0,4 ≈ 0,63 kleineres
   Sharpe als HODL.
4. **Vorab festgelegte Urteile** (Abschnitte 4–6): Holm über die Tests jedes Teils, dazu dieselbe Richtung in beiden Zeithälften.
   „Belegt“ heißt: diese Bedingung ist erfüllt, nicht mehr. Echtes Geld wie bei U140 nur nach belegter Historie und mindestens
   6 Monaten Labor ohne Widerspruch, nie automatisch.
5. **Berührt nichts Bestehendes:** `hl_zyklus.py` liest `makro.db`, `swing.db` und `regime.db` nur lesend; neu in `hl_swing.py`
   sind nur drei Strategie-Einträge, die RSI-Kennzahl und die Regeln der Art „dip“ (die sechs bestehenden Swing-Regeln bitgleich).

## 1. Die Fragen des Nutzers, messbar gemacht

| Frage des Nutzers | Messgröße (Teil) |
|---|---|
| „Wie lange dauert der Zyklus bis zum nächsten Rücksetzer?“ | Tage vom bestätigten Tief bis zum Hoch und bis zur Bestätigung des Rücksetzers (A) |
| „Nach wie vielen Prozent passiert durchschnittlich ein Rücksetzer?“ | Größe der Rallye Tief→Hoch (Median, Quartile), Weg ab der Bestätigung, Treffer eines festen Ziels (A, B: Z3) |
| „Wo kann man safe austreten?“ | Ausstieg am Rücksetzer (Z1), bei Überhitzung (Z2) oder am typischen Ziel (Z3) — welcher ist besser? (B) |
| „Was sind die exakten Signale für einen Rücksetzer?“ | Risikoverhältnis eines Rücksetzers in 14 Tagen mit und ohne Signal, gegen die Zufalls-Null (C) |
| „Was ist die sicherste Strategie?“ | Sharpe, größter Rückgang, Calmar im Kern-Portfolio BTC+ETH; Urteil „sicherer als HODL“ (B2) |
| „Dump bestätigt → kaufen, laufen lassen“ | Z1 als feste Regel, Timing-Urteil gegen Zufallswege (B1), Labor vorwärts (D) |

„Crowding“ (Positionierung der Leaderboard-Konten) hat keine lange Historie und bleibt deshalb vorwärts: Die Labor-Strategien
`leaderboard_folgen/gegen` messen es schon, die Familie „Crowding-Trend“ in der Fusion ebenfalls.

## 2. Was die Zufallsgeometrie schon vorher sagt

- **Beine (Directional Change):** Bestätigt man eine Wende erst nach einer Gegenbewegung um θ (log), dann ist auf einem
  driftlosen Zufallsweg der Weg nach der Bestätigung bis zum Extrem exponentialverteilt mit Mittel θ (Gedächtnislosigkeit). Ein
  Bein misst im Mittel 2θ, im Median θ·(1 + ln 2) ≈ 1,7θ. Phase 0 (U138, P0.3) hat das auf drei Jahren 30-min-Kursen bestätigt
  (Beinlängen ≈ 1,86θ, Überschuss BTC 1,12 gegen 1,09 in den Surrogaten, an der Holm-Grenze nicht stabil).
- **Folge für „bestätigt kaufen, bestätigt verkaufen“:** Man kauft θ über dem Tief und verkauft θ unter dem Hoch. Erwarteter
  Gewinn je Runde = Beinlänge − 2θ = 0 vor Kosten, plus Drift × Haltedauer. Ein Vorsprung entsteht nur, wenn die echten Beine
  länger sind als die des Zufallswegs (Schwung) — sind sie kürzer (Umkehr), kauft man systematisch zu spät.
- **Folge für „sicher aussteigen bei durchschnittlich X %“:** Bei exponentialverteilten Rallyes erreicht ein Ziel in Höhe des
  Medians genau die Hälfte der Fälle; die andere Hälfte endet im Rücksetzer. Ein festes Ziel ist nur dann „sicherer“, wenn die
  Rallyegrößen enger streuen als exponentiell (Teil A misst die Quartile, Z3 den Handel).
- **Folge für die Sicherheit:** Wer zufällig nur den Anteil f der Tage im Markt ist, hat Mittel f·μ und Schwankung √f·σ — Sharpe
  √f-mal HODL. Weniger Rückgang allein ist deshalb kein Beleg; „sicherer“ heißt hier: höheres Sharpe (Teil B2).
- **Vorwissen aus diesem Projekt:** Phase 0 (U138) fand auf drei Jahren keine Richtungsvorhersage über Tage; U130 (Makro × Kurs)
  0 von 45 Merkmalen; U126 Makro-Signale 4 von 336 belegt (Zufall allein 11–17); U140 Swing (2020–2026) nichts belegt, die
  Ausbruchsregeln positiv, aber nicht von Glück zu trennen. Die ehrliche Erwartung ist also: Die Zyklen sehen aus wie Zufall mit
  Drift, und die sicherste Strategie ist eine Frage der Größe und Streuung, nicht des Timings. Die Studie kann das widerlegen.

## 3. Daten

| Coin | Quelle (nur lesend) | Studie ab (S) | Teil B ab | Rolle |
|---|---|---|---|---|
| BTC | `makro.db` `cm:btc:PriceUSD` (ab 18.07.2010) | 01.01.2013 | 01.01.2013 | Tests A, B, C; Kern-Portfolio |
| ETH | `cm:eth:PriceUSD` (ab 08.08.2015) | 01.01.2016 | 07.08.2016 | Tests A, B, C; Kern-Portfolio |
| XMR | `cm:xmr:PriceUSD` (ab 20.05.2014) | 01.01.2016 | 01.01.2016 | Tests A, B1, C |
| ZEC | `cm:zec:PriceUSD` (ab 29.10.2016) | 01.01.2017 | 29.10.2017 | Tests A, B1, C |
| HYPE | `swing.db` (Binance-Perp, 30-min → Tagesschluss, ab 30.05.2025) | Datenbeginn | — (zu kurz) | nur beschreibend (A, Stand) |
| PAXG | `regime.db` (30-min → Tagesschluss, rund 3 Jahre) | Datenbeginn | Datenbeginn + 365 T | nur beschreibend (A mit 3/5/10 %, B) |

- **Tagesschluss:** Coin Metrics „PriceUSD“ ist der Schlusskurs des UTC-Tags (Stand 00:00 UTC des Folgetags); bei `swing.db`/`regime.db`
  der Schluss der 23:30-Kerze voller Tage (`hl_swing.tagesreihen`). Vor S werden bis zu 400 Tage als Vorlauf geladen (σ,
  200-Tage-Mittel, 365-Tage-Median); Teil B beginnt erst, wenn alle Kennzahlen stehen (Datenbeginn + 365 Tage).
- **Lücken:** bis 3 Tage gilt der letzte Kurs weiter (Rendite 0, der volle Schritt am ersten Tag danach); längere Lücken beenden
  die Reihe dort (der Bericht nennt sie).
- **Rendite und Schwankung:** r_t = ln(c_t/c_{t−1}); σ_t = √EWMA(r²) mit Halbwertszeit 20 Tage einschließlich t (wie `hl_swing.sigma_tag`,
  dort aus der 30-min-RV; hier aus dem Tagesschluss, weil Coin Metrics nur Tagesschlüsse hat). Die Tagesreihe wird als
  `hl_swing`-Tagesreihe mit RV_t = r_t² gebaut — dieselben Funktionen `Kennzahlen`, `einstieg`, `nachfuehren` wie im Labor.
- **Signale:** BTC-Funding `bnc:funding_btc_tag` (Tagessumme, ab 10.09.2019); ETH/ZEC/XMR/HYPE-Funding aus `swing.db` (ab 2020);
  BTC-OI in Coins `bnc:oi_btc_coins` (Stand 00:00 UTC des Tags, ab 01.09.2020 — in Coins, weil der USD-Wert mit dem Kurs
  mechanisch steigt); Fear & Greed `fng:wert` (Tageswert, ab 01.02.2018). Alle am Tagesschluss bekannt.
- **Ende:** der letzte Tag mit Kurs je Coin (Coin Metrics meist gestern). Der aktuelle Stand im Bericht nennt das Datum.

### 3a. Kalibrierung vorab (nur synthetische Märkte, 09.10. 00:20)

GARCH(1,1) mit t-verteilten Schocks (ν = 4), σ ≈ 2,8 % je Tag, Drift 0,13–0,21 % je Tag, 5000 Tage, vier Wiederholungen:

| Dump-Schwelle (Hoch der 20 Tage → Tief der letzten 10) | Einstiege je Jahr | Anteil der Tage im Markt | Ø Haltedauer |
|---|---|---|---|
| ≥ 3 σ | 13,5 | 75 % | 20 T |
| ≥ 4 σ | 10,8 | 59 % | 20 T |
| **≥ 5 σ (gewählt)** | **7,6** | **41 %** | **20 T** |
| ≥ 6 σ | 5,1 | 27 % | 19 T |

Mit 3 σ wäre Z1 drei Viertel der Zeit im Markt — praktisch HODL mit kurzen Pausen, also kein Test der Idee. Ein Rückgang um
3 σ in 20 Tagen ist auf einem Zufallsweg Alltag (der erwartete größte Rückgang in 20 Tagen ist ≈ 1,25·σ·√20 ≈ 5,6 σ). 5 σ
entspricht beim heutigen σ_Tag rund −10 bis −12 % bei BTC, −16 % bei ETH, −25 % bei HYPE: das, was man einen Dump nennt.
Teil-C-Ereignis (Abschnitt 6) auf denselben Märkten: Basisrate 8–9 % der Tage.

## 4. Teil A — Zyklen (Rallyes und Rücksetzer)

**Beine:** Directional Change auf den log. Tagesschlüssen ab S mit festen Schwellen X ∈ {10 %, 20 %, 30 %} (PAXG {3 %, 5 %,
10 %}): ein Tief gilt als bestätigt, sobald ein Schluss ≥ Tief·(1+X) ist; ein Hoch, sobald ein Schluss ≤ Hoch·(1−X). Start ohne
Richtung (laufendes Hoch und Tief; die erste Bestätigung entscheidet, Abwärts zuerst geprüft). Neue Extreme nur bei strikt
höherem Hoch bzw. tieferem Tief (bei Gleichstand gilt das erste). Gewertet werden nur abgeschlossene Beine; das erste Extrem jeder
Reihe beginnt kein Bein (es kann vor dem Datenbeginn liegen).

**Je Coin und Schwelle (beschreibend):** Zahl der Rallyes und je Jahr; Rallye Tief→Hoch in % (Median, Quartile, Mittel) und
Tage (Median, Quartile); Rücksetzer Hoch→Tief in % und Tage; ganzer Zyklus Tief→Tief in Tagen; Tage von der Bestätigung des
Tiefs bis zum Hoch; Weg ab der Bestätigung bis zum Hoch (Hoch ÷ Schluss am Bestätigungstag − 1, Median); die Runde „am
Bestätigungstag des Tiefs kaufen, am Bestätigungstag des Hochs verkaufen“ (Median, Mittel, Treffer) — echte Kurse gegen den
Median der Surrogate mit 90-%-Band; Anteil der Rallyes ≥ 2X und ≥ 3X.

**Null:** 1000 Vorzeichen-Surrogate je Coin: r*_t = μ + s_t·(r_t − μ) mit μ = mittlere Tagesrendite ab S und s_t = ±1 zufällig,
**ein Vorzeichen je Kalendertag für alle Coins** (hält den Gleichlauf der Coins), Saat fest. Erhalten bleiben Drift,
Schwankungsballung und Verteilung der Tagesbewegungen; zerstört wird jede Abhängigkeit der Vorzeichen (Schwung, Umkehr,
Pump-and-Dump-Muster).

**Test (vorab; geändert vor dem ersten echten Lauf, Abschnitt 12):** je Schwelle (10/20/30 %) die mittlere log. Rallyegröße
ln(Hoch/Tief) je Coin, gleich gewichtet gemittelt über BTC, ETH, ZEC und XMR, gegen dieselbe Größe auf den 1000 gemeinsamen
Surrogaten; p zweiseitig = 2·min(Anteil ≥, Anteil ≤) mit +1-Korrektur; Holm über 3. **Belegt:** p Holm < 0,05 UND in beiden
Zeithälften (Mitte des Zeitraums je Coin, Bein nach dem Datum seines Tiefs) dieselbe Richtung gegen den Surrogat-Median der
Hälfte, mit mindestens 3 Rallyes je Hälfte (über die Coins). Richtung „länger als Zufall“ (Schwung auf der Bein-Skala: laufen
lassen lohnt) oder „kürzer als Zufall“ (Umkehr: früh Gewinne mitnehmen lohnt). Je Coin und Schwelle dasselbe beschreibend
(p ohne Holm), dazu die Dauer echt gegen Zufall.

**Aktueller Stand je Coin (beschreibend, oben im Bericht):** letzter Schluss mit Datum, 1/7/30-Tage-Veränderung, Abstand zum
90-Tage-Hoch und zum Höchststand der Daten; je Schwelle das laufende Bein (seit wann, wie weit, ab welchem Kurs die Gegenrichtung
bestätigt wäre) und der heutige Rücksetzer im Vergleich mit dem Median-Rücksetzer; Z1 heute (Dump in σ, Erholung in σ, Signal
ja/nein); die Warnsignale heute (RSI, Funding-z, OI-Perzentil, Fear & Greed). Nur Lage, keine Empfehlung.

## 5. Teil B — Strategien

**Gemeinsam:** nur Long; Entscheidung und Ausführung zum Tagesschluss (Coin Metrics: 00:00 UTC); Stops wirken auf den
Tagesschluss (Ausstieg zu diesem Schluss); Kosten je Seite 0,10 % (BTC, ETH) bzw. 0,20 % (ZEC, XMR, HYPE, PAXG), bei VOL anteilig
zur Änderung; kein Funding (Kassa), Bargeld ohne Zins. Nach einem Ausstieg frühestens am nächsten Schluss wieder Einstieg.
Je Coin eine Position (ganzes Kapital des Coin-Anteils).

| Kürzel | Regel |
|---|---|
| HODL | am ersten Tag von Teil B kaufen und halten |
| T200 | Long, solange der Schluss über dem 200-Tage-Mittel (einschließlich heute) liegt, sonst Bargeld |
| VOL | Anteil w = min(1, σ*/σ_t), σ* = Median von σ über die 365 Tage davor; umschichten, wenn sich w um ≥ 0,10 ändern würde |
| **Z1 Dip halten** | siehe unten — die Idee des Nutzers |
| Z2 | Z1 + Ausstieg zum Schluss bei Überhitzung: RSI(14, Wilder) ≥ 80 oder Funding-Druck z30 ≥ 2 |
| Z3 | Z1 + Ziel bei der typischen Rallye: Ausstieg zum Schluss, sobald ln(Schluss/L) ≥ m·σ_e |
| Z0 | Kontrolle: Einstieg an flachen Tagen zufällig mit der Rate von Z1 je Coin, Ausstiege wie Z1; 200 Läufe (beschreibend) |

**Z1 Dip halten** (`zyklus_dip`), am Schluss von Tag d ohne Position:
- L = tiefster Schluss der 10 Tage davor (d−10 … d−1; bei Gleichstand der jüngste), an Tag j;
- H = höchster Schluss der 20 Tage bis j (j−19 … j);
- **Dump:** ln(H/L) ≥ 5·σ_d; **bestätigt:** ln(c_d/L) ≥ 1·σ_d (Erholung vom Tief) und ln(H/c_d) ≥ 1·σ_d (noch nicht zurückgelaufen);
- Einstieg zum Schluss c_d; **Stop** min(L, c_d)·e^{−σ_d} (ein σ unter dem Tief; in `hl_swing.plan` als Stop-Abstand
  k = ln(c_d/min(L, c_d))/σ_d + 1); **Nachzieh-Stop** 3·σ_t unter dem besten Schluss seit dem Einstieg (nur nach oben, ab dem
  Einstiegstag wie `nachfuehren`); **spätestens nach 60 Tagen** zum Schluss.
- Alle Fenster müssen vollständig sein (sonst kein Signal).

**Z2 Überhitzung** (`zyklus_dip_heiss`): wie Z1, zusätzlich Ausstieg am Schluss, an dem RSI14 ≥ 80 oder z30 ≥ 2 ist
(z30 = (Funding des Tags − Mittel der 30 Tage davor) ÷ deren Standardabweichung, mindestens 20 Tage endlich; wie `Kennzahlen.fz`).
Ohne Funding-Daten (BTC vor 09/2019, die anderen vor 2020) zählt nur der RSI.

**Z3 Ziel** (nur Historie): wie Z1, zusätzlich Ziel L·e^{m·σ_e}, mindestens c_e·e^{0,5·σ_e}; m = Median des Höchststands
ln(max. Schluss im Trade ÷ L)/σ_e über alle **Z1-Trades desselben Coins, die vor dem Einstiegstag endeten** (mindestens 10,
sonst kein Ziel). Kausal, aus der eigenen Geschichte: „aussteigen bei der durchschnittlichen Rallye“.

**Kennzahlen je Coin und Strategie (beschreibend):** CAGR, Schwankung p. a., Sharpe (Tagesrendite × √365, Bargeld 0), größter
Rückgang, Calmar, Anteil im Markt, Trades je Jahr, Kosten p. a., schlechtestes Kalenderjahr; Z0 als Median und 90-%-Band der
200 Läufe; Empfindlichkeit „einen Tag später ausgeführt“ (Positionen um einen Tag verschoben).

**B1 Timing (vorab):** Statistik je Strategie Z1, Z2, Z3 = Mehrertrag je Markttag über BTC, ETH, ZEC und XMR gepoolt:
Σ_coins Σ_t [pos_{t−1}·(r_t − μ_coin) − Kosten_t] ÷ Σ Markttage (log). Null: dieselbe Rechnung auf 200 gemeinsamen
Vorzeichen-Surrogaten (dieselben wie Teil A, die ersten 200); p einseitig (größer), Holm über 3. **Belegt:** p Holm < 0,05 UND in
beiden Hälften über dem Surrogat-Median der Hälfte. Unter der Null ist der Mehrertrag je Markttag genau 0 minus Kosten
(die Entscheidung kennt nur die Vergangenheit, die Vorzeichen danach sind fair) — gleich welche Coins wann im Markt sind.

**B2 Sicherer als HODL (vorab):** Kern-Portfolio BTC+ETH, gleich gewichtet über die verfügbaren Coins (bis 07.08.2016 nur BTC),
täglich ausgeglichen; je Strategie T200, VOL, Z1, Z2, Z3 die Differenz der Sharpe-Werte ΔSR = SR(Strategie) − SR(HODL),
p einseitig aus dem zirkulären Blockbootstrap gepaarter Tagesrenditen (Block 30 Tage, 2000 Ziehungen, zentriert:
Anteil von ΔSR* − ΔSR ≥ ΔSR); Holm über 5. **Belegt:** p Holm < 0,05 UND ΔSR > 0 in beiden Hälften. Dazu beschreibend CAGR,
größter Rückgang, Calmar und ein 90-%-Intervall für ΔSR.

## 6. Teil C — Warnsignale vor Rücksetzern

**Ereignis an Tag d:** der tiefste Schluss der folgenden 14 Tage liegt mindestens 1,5·σ_d·√14 unter c_d (bei σ_Tag 2–2,5 % wie
BTC zuletzt rund −11 bis −14 %, bei 3,3 % wie ETH rund −19 %); nur Tage mit 14 Folgetagen. Beschreibend zusätzlich fest −10 % in 14 Tagen.

| Signal | Regel am Schluss von d | Coins, Zeitraum |
|---|---|---|
| C1 OI-Überhitzung | OI in Coins im Perzentil ≥ 0,90 der 90 Tage davor (Mittelrang wie `hl_indikatoren.oi_perzentil` im Dashboard, mindestens 60 Werte) | BTC ab 09/2020 |
| C2 Funding-Druck | z30 ≥ 2 (wie Z2) | BTC ab 09/2019, ETH/ZEC/XMR ab 2020 |
| C3 RSI ≥ 80 | RSI(14, Wilder) auf den Tagesschlüssen | BTC, ETH, ZEC, XMR |
| C4 Gier | Fear & Greed ≥ 80 („extreme Gier“) | BTC, ETH ab 02/2018 |

**Statistik:** Risikoverhältnis RR = P(Ereignis | Signal) ÷ P(Ereignis | kein Signal), gepoolt über die Coins mit Abdeckung.
**Null:** dieselben 1000 Vorzeichen-Surrogate: Kurse, σ, Ereignis und RSI neu gerechnet, OI, Funding und Fear & Greed bleiben.
Damit zählt nur Richtungsinformation — ein Signal, das bloß hohe Schwankung anzeigt, erzeugt auch auf den Surrogaten mehr
Ereignisse. p einseitig (größer), Holm über 4. **Belegt:** p Holm < 0,05 UND RR über dem Surrogat-Median in beiden Hälften.
**Intervall:** 90-%-Band des RR aus dem Kalender-Blockbootstrap (60-Tage-Blöcke, für alle Coins dieselben Blöcke, 1000 Ziehungen).
Beschreibend: Signaltage, unabhängige Episoden (Signaltage mehr als 14 Tage auseinander), beide Wahrscheinlichkeiten in %.

## 7. Teil D — Gegenprobe mit Ausführung und TradeLabor

**Neue Strategien** in `hl_swing.STRATEGIEN` (Art „dip“, neue Kennungen; die sechs bestehenden Einträge bitgleich):

| Name | Regeln |
|---|---|
| `zyklus_dip` (Z1) | `{"art": "dip", "dump": 5.0, "erholung": 1.0, "abstand": 1.0, "tief_tage": 10, "hoch_tage": 20, "stop_unter_tief": 1.0, "trail": 3.0, "max_tage": 60}` |
| `zyklus_dip_heiss` (Z2) | wie Z1 mit `"art": "dip_heiss", "rsi_tage": 14, "rsi_max": 80.0, "funding_tage": 30, "funding_z": 2.0` |
| `zyklus_dip_zufall` (Kontrolle) | `{"art": "dip_zufall", "p_tag": 0.03, "tief_tage": 10, "stop_unter_tief": 1.0, "trail": 3.0, "max_tage": 60}`, immer Long |

Dazu wie bei allen Swing-Strategien `risiko_usd` 100 und `notional_max` 10.000. Im Labor: Entscheidung nach dem Tagesschluss aus
`swing.db` (Binance, σ aus der 30-min-RV), Ausführung auf Hyperliquid, Stops auf den Minutenkerzen, Größe 100 USD Risiko bis zum
Stop — wie die übrigen Swing-Strategien (`sig_swing` unverändert). **Unterschiede zur Historie, bewusst:** σ aus der 30-min-RV
statt aus dem Tagesschluss; Stops jederzeit statt am Schluss; Perp mit Funding statt Kassa; Größe nach Risiko statt ganzes
Kapital. Die Regel (wann Einstieg, wo Stop, wann Ausstieg) ist dieselbe Funktion.

**Gegenprobe im Bericht (beschreibend):** Z1 und Z2 mit der U140-Rechnung (`strategie_rechnen`: 30-min-Kerzen ab 2020, Gebühren,
Abstand zur Mitte, Funding, R je Trade, Zeitpunkt-Placebo mit zufälligem Long-Einstieg und denselben Ausstiegen). Kein Urteil —
zeigt nur, ob die Regel mit echter Ausführung dieselbe Richtung hat wie auf den Tagesschlüssen.

## 8. Bericht

Debug „★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141)“ (`python3 hl_zyklus.py --studie --db <hl_liq.db>`), Selbsttest
„Zyklen: Selbsttest“ (`--selbsttest`), Berichtsplan einmalig. Aufbau: Kopf (vorab festgelegt, Laufzeit, Surrogate) — ERGEBNIS
(kurz, nach den Regeln unten) — AKTUELLER STAND — TEIL A — TEIL B — TEIL C — TEIL D — Lesart.

**ERGEBNIS-Regeln (vorab):**
1. Zyklen: je Schwelle „Rallyes länger/kürzer als Zufall (belegt bei …)“ oder „wie ein Zufallsweg mit derselben Drift und
   Schwankung“; dazu die Mediane der Rallye in % und Tagen je Coin.
2. Sicherer als HODL: die belegten Strategien nach ΔSR geordnet, sonst „keine Strategie belegt sicherer als HODL“.
3. Timing: Z1–Z3 belegt oder nicht.
4. Warnsignale: die belegten mit RR und Intervall, sonst „kein Signal belegt“.
5. Was daraus folgt (fest): Belegtes Timing oder Sicherheit bei Z1–Z3 → Kandidat, Labor 6 Monate; nur T200/VOL belegt → die
   einfachste Regel trägt, die Dip-Idee bringt nichts darüber hinaus; nichts belegt → HODL im Kern ist der Maßstab, Sicherheit
   kommt aus Größe und Streuung (Rückgänge beschreibend).

## 9. Proben (Selbsttest ohne Netz, Ziel unter 2 min auf dem Pi)

- **Von Hand:** Directional Change auf einer Reihe mit bekannten Beinen (Tiefs, Hochs, Bestätigungstage, Runde); RSI gegen
  Wilders Rechenbeispiel (70,53 66,32 66,55 69,41 66,36 57,97) und gegen `hl_makro.rsi_wilder` auf Zufallsreihen; Z1 auf einem
  gebauten Dump mit Erholung (Einstiegstag, Stop = L·e^{−σ}, Nachzieh-Stop, Ausstieg nach Zeit/Stop/Signal/Ziel, keine Wiederkehr
  am selben Schluss); Kosten (eine Runde = 2 × Satz); T200 und VOL auf einfachen Reihen; Sharpe-Differenz gleicher Reihen = 0,
  p ≈ 1; Holm.
- **Gleichheit mit dem Labor:** die schnelle Rechnung von Z1/Z2 (über viele Pfade gleichzeitig) gegen `hl_swing.einstieg` und
  `nachfuehren` Tag für Tag auf einem Zufallsmarkt: dieselben Einstiege, Stops, Ausstiege.
- **Kausalität:** Kurse nach Tag d verändern → Signale, Positionen und Kennzahlen bis d bitgleich.
- **Nulltests:** Zufallsmärkte (GARCH, Drift, faire Vorzeichen) → Teil A, B1, C ohne Beleg; Fehlerquote in Wiederholungen nahe
  dem Niveau (Nullreplikationen im Scratchpad, Ergebnis in Abschnitt 12).
- **Positivkontrollen:** Schwung (Vorzeichen folgen einander) → A „länger“, Umkehr → A „kürzer“; gepflanzte Erholung nach Dumps
  → B1 Z1 belegt; lange Trends mit Crashs → B2 T200 belegt; gepflanzter Rücksetzer nach RSI ≥ 80 → C3 belegt; ein äußeres Signal,
  das Rücksetzer ankündigt → C belegt.
- **Bericht:** alle Abschnitte, fehlende Reihen (kein HYPE, kein PAXG, kein OI, kein Funding) ohne Absturz.
- **Labor:** bestehende Kennungen unverändert (38 + 6), drei neue; `zyklus_dip` eröffnet auf einem gebauten Dump am richtigen Tag
  mit dem Stop unter dem Tief.
- **Mutationen** (Scratchpad, nicht im Paket): Vergleiche umkehren, Fenster um einen Tag verschieben, Zukunft in σ, Kosten weg,
  Vorzeichen je Coin statt gemeinsam, Holm weg → der Selbsttest muss rot werden.

## 10. Grenzen und Risiken

- **Wenige unabhängige Zyklen:** 30-%-Beine gibt es bei BTC nur einige Dutzend; Bull-/Bärenphasen im Kern rund vier. Die Tests
  sind ehrlich, aber schwach; „nicht belegt“ heißt nicht „wirkungslos“.
- **Überlebende Coins:** BTC, ETH, XMR und ZEC sind Coins, die es noch gibt. Dips in Coins, die verschwanden, fehlen — die Studie
  ist für diese Coins gültig, nicht für Krypto allgemein.
- **Tagesschluss-Stops:** in der Historie wirken Stops nur am Schluss (keine Dochte), im Labor jederzeit. Die Gegenprobe (Teil D)
  zeigt, wie viel das ausmacht.
- **Gold:** PAXG hat nur rund 3 Jahre und andere Dynamik (σ ≈ 1 % je Tag); beschreibend.
- **HYPE:** 16 Monate — nur Zyklen und Stand, keine Strategiestatistik.
- **Mehrfachtests:** 12 + 3 + 5 + 4 vorab festgelegte Tests, jeweils Holm; die Beschreibungen sind keine Tests.
- **Keine Anlageberatung:** Die Studie misst, was war. Entscheidungen über echtes Geld trifft der Nutzer.

## 11. Entscheidungen beim Nutzer

1. Nach dem ersten Lauf: welche Variante (Z1/Z2/Z3, T200, VOL) das Labor zusätzlich mit echtem Größenmaß verfolgen soll.
2. Ob Gold (PAXG auf Hyperliquid) als Labor-Coin dazukommt (heute nicht in `swing.db`; eigener Schritt mit Laden und Kennung).
3. Ob die Labor-Tabelle Brutto, Kosten und Netto getrennt zeigt (Vorschlag zur Labor-Aufräumrunde nach U99, 11.10.).

## 12. Änderungen vor dem ersten echten Lauf (09.10. 01:00–03:00, nur synthetische Märkte gesehen)

1. **Teil A: gepoolter Mittelwert statt Median je Coin und Schwelle.** Die Kalibrierung zeigte zwei Dinge. (a) Schwung oder
   Umkehr von Tag zu Tag (AR(1) ±0,25 der Tagesrenditen) verändert die Beingröße eines Zufallswegs grundsätzlich nicht: Die
   Größe eines Beins nach Bestätigung bei θ ist exponentiell mit Mittel θ, gleich wie groß die Schwankung ist — Schwung macht die
   Beine nur schneller (Dauer), nicht größer. Das ist die Antwort auf „nach wie vielen Prozent kommt der Rücksetzer“, wenn die
   Kurse auf der Bein-Skala wie ein Zufallsweg laufen: genau das, was die Schwelle vorgibt. (b) Struktur auf der Bein-Skala
   (Drift-Regime ±0,5 %/Tag mit Wechsel alle 100 Tage; Rücklauf zum 200-Tage-Mittel) erkennt der Median je Coin und Schwelle mit
   Holm über 12 kaum (1 von 12 bzw. 0 von 12 belegt; bei 120 Surrogaten ist er zweiseitig nach Holm gar nicht unter 0,05 zu bringen),
   der Mittelwert gepoolt über die Coins mit Holm über 3 dagegen sicher: Drift-Regime 10 von 10, Rücklauf 9 von 10, nie die falsche
   Richtung (je 4 Coins, 2.600 Tage, 600 Surrogate). Darum jetzt dieser Test (Abschnitt 4); der Median bleibt die beschreibende Zahl.
2. **Lücken über 3 Tage:** die Reihe beginnt nach der letzten solchen Lücke (statt dort zu enden — eine frühe Lücke kostete sonst
   die ganze jüngere Historie). Coin Metrics hat für die vier Coins keine Lücken erwartet; der Bericht nennt sie.
3. **Erstes Extrem:** beginnt kein Bein (Abschnitt 4).
4. **Regel-Eintrag „abstand“:** ausdrücklich `"abstand": 1.0` statt stillschweigend `erholung` für beide Bedingungen (Abschnitt 7).
5. **Nachzieh-Stop ab dem Schluss nach dem Einstieg:** wie im Labor und in `hl_swing.handel` (dort ist der Einstiegstag der
   Folgetag der Entscheidung); bitgleich geprüft gegen `hl_swing.einstieg/plan/nachfuehren` (146 Trades auf drei Märkten).
6. **Selbsttest** mit weniger Surrogaten (A 600, B 100, C 160) — Holm wie im Bericht, so dass die Positivkontrollen den Schwellen
   gewachsen sind. Robustheit (je 10 Wiederholungen): Teil A Drift-Regime 10/10, Rücklauf 9/10; B1 Erholung nach Dumps 10/10; C3
   Rücksetzer nach RSI ≥ 80 10/10; B2 lange Trends (±0,6 %/Tag, Wechsel alle 250 Tage) 12/12. Nullreplikationen: GARCH mit fairen
   Vorzeichen, 24 Universen (4 Coins, 3.600 Tage, volle Surrogatzahl): Teil A 0 von 72 Tests roh unter 0,05, B1 0 von 72, B2 nichts
   belegt; Teil C auf 80 weiteren Universen roh unter 0,05 je Signal 2,5–7,5 %, irgendein Beleg in 5 von 80 (Soll ≤ 5 %, Intervall
   2–14 %); B2 auf unabhängigen Renditen 0 von 40 belegt (0 von 200 Tests roh unter 0,05). Mutationen 37 von 37 rot (`mut141.py`;
   drei erst nach neuen Proben: Z3-Ziel kausal, VOL-Schritt, Identität echter Kurse mit Surrogaten aus Vorzeichen +1).
7. **Teil B, Rendite-Spalte „Kurs“** als Vielfaches (×), sobald der Kurs über das Zehnfache stieg (BTC seit 2013) — reine Anzeige.

## 13. Vorschlag: so arbeiten wir weiter (09.10.2026, für den Nutzer)

**Grundsätze**
1. **Wenige Entscheidungen.** Einmal am Tag nach dem Tagesschluss, im Mittel wenige Trades je Coin und Monat. Die Kosten stehen
   neben jedem Ergebnis (das Labor zeigt seit 27.09.: viele kurze Trades verlieren an den Kosten, nicht an einem Rechenfehler).
2. **Kern zuerst.** BTC und ETH: lange Historie, tiefe Märkte, niedrige Kosten. HYPE (16 Monate Historie) klein und beschreibend,
   bis die Historie trägt; Gold getrennt (andere Dynamik, eigener Schritt, Entscheidung 2); ZEC und XMR nur im Labor.
3. **Größe vor Richtung.** Bis eine Richtungsregel belegt ist, ist die sicherste „Strategie“ eine Größenregel: festes Risiko je
   Position (im Labor 100 USD bis zum Stop) und Streuung über den Kern.
4. **Erst Historie, dann Labor, dann — nur auf Entscheidung des Nutzers — echtes Geld.** Nichts automatisch.

**Fahrplan**
- **09.10.:** 23.62 einspielen. Die Studie läuft um 12:00 von selbst (verpasst bis 12 h nachgeholt) oder sofort über den
  Debug-Eintrag; den Bericht hochladen. Auswertung als Abschnitt 14 hier (Ergebnis des ersten Laufs).
- **Ab 09.10.:** Das Labor zeichnet Z1, Z2 und die Zufall-Kontrolle vorwärts auf (zusammen mit S1–S4).
- **11.10. (U99):** Labor-Auswertung; Vorschlag zur Aufräumrunde: Strategien, die nach Kosten klar unter ihrer Zufall-Kontrolle
  liegen, pausieren (keine neuen Trades, Bilanz bleibt sichtbar); Tabelle mit Brutto, Kosten und Netto getrennt (Entscheidung 3).
- **25.10.:** die vereinbarten Auswertungen (U108, U115, U110, U130). Bis dahin keine Änderung an Fusion, v3, Kaskaden, v1-Lernen.
- **Nach dem Studienbericht, nach den vorab festgelegten Folgen (Abschnitt 8, Regel 5):**
  - T200 oder VOL belegt sicherer als HODL → eine „Kern-Strategie“ als neue Labor-Strategie (BTC/ETH, Entscheidung täglich,
    wenige Wechsel im Jahr) und als Lage-Anzeige im Dashboard (über/unter dem 200-Tage-Mittel, Anteil nach Schwankung).
  - Z1–Z3 belegt (Timing oder Sicherheit) → Kandidat, 6 Monate Labor ohne Widerspruch, dann Entscheidung des Nutzers.
  - Ein Warnsignal belegt → als Ausstiegsregel mit eigener Kennung ins Labor und als Anzeige im Dashboard.
  - Nichts belegt → kein Timing-Werkzeug bauen; das Labor läuft als Vorwärtsbeleg weiter, der Fokus liegt auf Größe und Streuung.
- **Beim Nutzer offen:** Entscheidung 2 hier (Gold als Labor-Coin), Entscheidung 4 in `KONZEPT_Swing.md` (Vorhaltetest S1/S3 in
  der Breite), Entscheidungen 8 und 9 in `KONZEPT_Regime.md`.

