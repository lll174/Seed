#!/usr/bin/env python3
"""
Abdeckung der Heatmap im Verlauf (U159, 23.68) -- beschreibender Debug-Bericht, nur lesend.

  python3 check_abdeckung.py --db /pfad/hl_liq.db [--tage 21]
  python3 check_abdeckung.py --selbsttest

Anlass: Die Abdeckung (verfolgte Größe ÷ 2 × OI der Positionen, die höchstens max_pos_age = 3.600 s alt sind) sank zwischen den
Berichten (04.10. 22–24 %, 11.10. 7–19 %) und stieg nach dem Neustart mit 23.67 wieder (14.10. 24–27 %). Vermutet, nicht geprüft:
ein Neustart-Muster (hoch direkt danach, dann Rückgang über Tage). Der Bericht legt die Zahlen dazu nebeneinander:
  - je Coin und UTC-Tag die Abdeckung als Mittel, kleinster und größter Wert, dazu verfolgte Größe und OI (Mittel, in Coins);
  - je Tag aus snapshot_meta: Positionen im Stand, wegen Alters ausgelassene (n_stale_dropped), Alter der Abfragen (Median, 90 %),
    Rückstand; Neustarts (Laufzeit unter 15 min) als Marke; Anteil des Pollers am API-Gewicht, soweit api_load reicht (3 Tage);
  - beschreibend: erster Tag nach jedem Neustart gegen die Tage danach.
Keine Änderung am Recorder vor der Ursache; Kaskaden und Magnet rechnen weiter mit der kleineren Karte. Kein Urteil.
"""
from __future__ import annotations

import argparse
import math
import os
import sqlite3
import sys
import time

TAG = 86_400
NEUSTART_S = 900                    # Laufzeit unter 15 min = Neustart (snapshot_meta.uptime)
MAX_POS_ALTER = 3600


def _db_lesen(db: str):
    return sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)


def _tag(ts: int) -> int:
    return int(ts) // TAG * TAG


def _d(ts) -> str:
    return time.strftime("%d.%m.", time.gmtime(int(ts)))


def _dz(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(int(ts)))


def _pc(x, nd: int = 0) -> str:
    return "—" if x is None else f"{x * 100:.{nd}f} %".replace(".", ",")


def _z(x, nd: int = 0) -> str:
    return "—" if x is None else f"{x:,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def je_coin_tag(con, seit: int) -> dict:
    """{coin: {tag: {"n", "mittel", "min", "max", "tracked", "oi"}}} aus coverage (Abdeckung = ratio)."""
    out: dict = {}
    for coin, tag, n, m, lo, hi, tr, oi in con.execute(
            "SELECT coin, ts / 86400 * 86400, COUNT(*), AVG(ratio), MIN(ratio), MAX(ratio), AVG(tracked_size), AVG(oi) FROM coverage "
            "WHERE ts >= ? AND ratio IS NOT NULL GROUP BY 1, 2 ORDER BY 1, 2", (seit,)):
        out.setdefault(coin, {})[int(tag)] = {"n": n, "mittel": m, "min": lo, "max": hi, "tracked": tr, "oi": oi}
    return out


def neustarts(con, seit: int) -> list:
    """Zeitpunkte der Neustarts (ts − uptime) aus snapshot_meta-Zeilen mit uptime < 15 min; nah beieinander = einer."""
    roh = sorted(int(ts) - int(up) for ts, up in con.execute(
        "SELECT ts, uptime FROM snapshot_meta WHERE ts >= ? AND uptime IS NOT NULL AND uptime < ?", (seit, NEUSTART_S)))
    out: list = []
    for t in roh:
        if not out or t - out[-1] > NEUSTART_S:
            out.append(t)
    return out


def je_tag_meta(con, seit: int) -> dict:
    """{tag: {"n", "positionen", "ausgelassen", "alter_median", "alter_p90", "rueckstand"}} -- Mittel über die Snapshots des Tags."""
    out = {}
    for tag, n, p, a, am, a90, b in con.execute(
            "SELECT ts / 86400 * 86400, COUNT(*), AVG(n_positions), AVG(n_stale_dropped), AVG(age_median), AVG(age_p90), AVG(backlog) "
            "FROM snapshot_meta WHERE ts >= ? AND n_positions IS NOT NULL GROUP BY 1 ORDER BY 1", (seit,)):
        out[int(tag)] = {"n": n, "positionen": p, "ausgelassen": a, "alter_median": am, "alter_p90": a90, "rueckstand": b}
    return out


def poller_anteil(con, seit: int) -> dict:
    """{tag: Anteil des Pollers am API-Gewicht} aus api_load (der Recorder hält dort 3 Tage)."""
    out = {}
    try:
        for tag, p, g in con.execute("SELECT ts / 86400 * 86400, SUM(CASE WHEN quelle='Poller' THEN weight ELSE 0 END), SUM(weight) "
                                     "FROM api_load WHERE ts >= ? GROUP BY 1 ORDER BY 1", (seit,)):
            out[int(tag)] = (p / g) if g else None
    except sqlite3.Error:
        pass
    return out


def nach_neustart(con, starts: list, bis: int) -> list:
    """Beschreibend: Mittel der Abdeckung je Coin im ersten Tag (24 h) nach jedem Neustart gegen die Zeit danach bis zum nächsten."""
    out = []
    for i, t in enumerate(starts):
        ende = starts[i + 1] if i + 1 < len(starts) else bis
        e = {"start": t, "ende": ende, "tag1": {}, "danach": {}}
        for coin, m1, n1 in con.execute("SELECT coin, AVG(ratio), COUNT(*) FROM coverage WHERE ts >= ? AND ts < ? AND ratio IS NOT NULL "
                                        "GROUP BY coin", (t, min(t + TAG, ende))):
            e["tag1"][coin] = (m1, n1)
        if ende > t + TAG:
            for coin, m2, n2 in con.execute("SELECT coin, AVG(ratio), COUNT(*) FROM coverage WHERE ts >= ? AND ts < ? AND ratio IS NOT NULL "
                                            "GROUP BY coin", (t + TAG, ende)):
                e["danach"][coin] = (m2, n2)
        out.append(e)
    return out


def bericht(db: str, tage: int = 21, now: int | None = None) -> str:
    now = int(now or time.time())
    seit = _tag(now) - (tage - 1) * TAG
    if not os.path.exists(db):
        return f"Abdeckung der Heatmap (U159): Datenbank fehlt: {db}"
    con = _db_lesen(db)
    try:
        C = je_coin_tag(con, seit)
        M = je_tag_meta(con, seit)
        P = poller_anteil(con, seit)
        N = neustarts(con, seit - 2 * TAG)
        V = nach_neustart(con, [t for t in N if t >= seit - TAG], now)
    finally:
        con.close()
    neu_tage = {_tag(t) for t in N}
    z = [f"★ Abdeckung der Heatmap im Verlauf (U159) · {time.strftime('%d.%m.%Y %H:%M', time.localtime(now))} · letzte {tage} Tage · "
         "nur lesend, beschreibend, kein Urteil",
         f"Abdeckung = verfolgte Größe ÷ (2 × OI) der Positionen, die höchstens {_z(MAX_POS_ALTER)} s alt sind (max_pos_age). UTC-Tage; "
         "„N“ = Neustart an diesem Tag (Laufzeit unter 15 min in snapshot_meta).", ""]
    z.append("JE COIN UND TAG: Abdeckung Mittel (kleinster–größter Wert) · verfolgte Größe und OI im Mittel (Coins, OI eine Seite) · Messungen")
    if not C:
        z.append("  keine Zeilen in coverage")
    for coin in sorted(C):
        z.append(f"  {coin}")
        for tag in sorted(C[coin]):
            e = C[coin][tag]
            z.append(f"    {_d(tag)}{' N' if tag in neu_tage else '  '} {_pc(e['mittel']):>6} ({_pc(e['min'])}–{_pc(e['max'])}) · verfolgt "
                     f"{_z(e['tracked'], 1)} · OI {_z(e['oi'], 1)} · {e['n']} Messungen")
    z.append("")
    z.append("JE TAG AUS snapshot_meta (Mittel über die Snapshots des Tags) und Anteil des Pollers am API-Gewicht (api_load, 3 Tage):")
    z.append(f"  {'Tag':<8}{'Snapsh.':>8}{'Positionen':>12}{'ausgelassen':>13}{'Alter Med.':>12}{'Alter 90 %':>12}{'Rückstand':>11}{'Poller':>8}")
    for tag in sorted(set(M) | set(P)):
        m = M.get(tag) or {}
        z.append(f"  {_d(tag)}{' N' if tag in neu_tage else '  '}{m.get('n', 0):>6}{_z(m.get('positionen')):>12}{_z(m.get('ausgelassen')):>13}"
                 f"{(_z(m.get('alter_median')) + ' s') if m.get('alter_median') is not None else '—':>12}"
                 f"{(_z(m.get('alter_p90')) + ' s') if m.get('alter_p90') is not None else '—':>12}{_z(m.get('rueckstand')):>11}"
                 f"{_pc(P.get(tag)):>8}")
    z.append("")
    z.append("NEUSTARTS (Laufzeit unter 15 min): " + (", ".join(_dz(t) for t in N if t >= seit - TAG) or "keine im Zeitraum"))
    z.append("BESCHREIBEND: erster Tag (24 h) nach jedem Neustart gegen die Zeit danach bis zum nächsten Neustart -- Mittel der Abdeckung")
    for e in V:
        coins = sorted(set(e["tag1"]) | set(e["danach"]))
        m1 = [e["tag1"][c][0] for c in coins if c in e["tag1"]]; m2 = [e["danach"][c][0] for c in coins if c in e["danach"]]
        z.append(f"  Neustart {_dz(e['start'])}: Tag 1 {_pc(sum(m1) / len(m1)) if m1 else '—'} · danach "
                 + (f"{_pc(sum(m2) / len(m2))} bis {_dz(e['ende'])}" if m2 else "— (noch kein ganzer Tag)") + " · je Coin: "
                 + " · ".join(f"{c} {_pc(e['tag1'][c][0]) if c in e['tag1'] else '—'} → {_pc(e['danach'][c][0]) if c in e['danach'] else '—'}"
                              for c in coins))
    if not V:
        z.append("  kein Neustart im Zeitraum")
    z.append("")
    z.append("Lesehilfe: Sinkt die Abdeckung bei gleichem OI, während „ausgelassen“ und das Alter der Abfragen steigen, werden Positionen zu "
             "selten abgefragt (Poller); sinkt sie bei steigendem OI und gleicher verfolgter Größe, wächst der Markt schneller als die "
             "verfolgten Konten. Nur beschreibend; die Ursache ist damit nicht geprüft.")
    return "\n".join(z)


# ---------------------------------------------------------------------------- Selbsttest

def selbsttest() -> int:
    import random
    import tempfile
    import shutil
    rot = []

    def ok(name, bed, detail=""):
        print(f"  {'ok  ' if bed else 'FEHL'} {name}" + ("" if bed else f" -- {detail}"), flush=True)
        if not bed:
            rot.append(name)
    print("check_abdeckung.py --selbsttest (U159)")
    tmp = tempfile.mkdtemp(prefix="abdeckung_")
    try:
        db = os.path.join(tmp, "a.db")
        con = sqlite3.connect(db)
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_recorder
        con.executescript(hl_recorder.SCHEMA)
        now = 1_790_006_400 + 20 * 3600                       # 20:00 UTC
        t0 = _tag(now) - 9 * TAG
        rng = random.Random(159)
        cov, meta, api = [], [], []
        start_alt = t0 - 3 * TAG                              # Prozess lief schon; Neustart (Bruch) am Tag 4 um 06:00
        bruch = t0 + 4 * TAG + 6 * 3600 + 7 * 60              # 06:07 UTC -- zwischen zwei Snapshots (alle 15 min)
        for k in range(0, 10 * 96):
            ts = t0 + k * 900
            if ts > now:
                break
            up = ts - (start_alt if ts < bruch else bruch)
            seit_neu = ts - bruch
            for coin, basis in (("BTC", 0.24), ("ETH", 0.20)):
                r = basis * 0.9 if ts < bruch else basis * 1.25 * math.exp(-seit_neu / (6 * TAG))   # nach dem Neustart hoch, dann Abfall
                r *= 1 + 0.05 * rng.uniform(-1, 1)
                oi = 10_000.0 if coin == "BTC" else 200_000.0
                cov.append((ts, coin, r * 2 * oi, oi, r))
            meta.append((ts, 50_000, 6_000, 4_000 + rng.randint(-50, 50), 100 + (0 if ts >= bruch else 300), 600, 3000, 20, up))
            if ts >= now - 3 * TAG:
                api.append((ts // 60 * 60, "Poller", 600)); api.append((ts // 60 * 60, "Leaderboard", 400))
        con.executemany("INSERT INTO coverage VALUES (?,?,?,?,?)", cov)
        con.executemany("INSERT INTO snapshot_meta VALUES (?,?,?,?,?,?,?,?,?)", meta)
        con.executemany("INSERT OR REPLACE INTO api_load VALUES (?,?,?)", api)
        con.commit(); con.close()
        con = _db_lesen(db)
        C = je_coin_tag(con, t0); N = neustarts(con, t0 - TAG); P = poller_anteil(con, t0); V = nach_neustart(con, N, now)
        M = je_tag_meta(con, t0)
        con.close()
        # Nachrechnung von Hand aus den eingefügten Zeilen
        hand = {}
        for ts, coin, tr, oi, r in cov:
            hand.setdefault((coin, _tag(ts)), []).append((r, tr, oi))
        gleich = all(abs(C[c][t]["mittel"] - sum(x[0] for x in v) / len(v)) < 1e-12 and abs(C[c][t]["min"] - min(x[0] for x in v)) < 1e-12
                     and abs(C[c][t]["max"] - max(x[0] for x in v)) < 1e-12 and C[c][t]["n"] == len(v)
                     and abs(C[c][t]["tracked"] - sum(x[1] for x in v) / len(v)) < 1e-6 for (c, t), v in hand.items())
        ok("Je Coin und Tag gleich der Nachrechnung von Hand aus coverage (Mittel, kleinster, größter Wert, verfolgte Größe, Zahl)",
           gleich and len(hand) == sum(len(v) for v in C.values()), f"{len(hand)} Coin-Tage")
        ok("Neustart (Bruch) zur richtigen Zeit erkannt (Laufzeit unter 15 min → ts − uptime), genau einer",
           N == [bruch], f"{[_dz(t) for t in N]} statt {_dz(bruch)}")
        t1 = [r for ts, c, tr, oi, r in cov if c == "BTC" and bruch <= ts < bruch + TAG]
        t2 = [r for ts, c, tr, oi, r in cov if c == "BTC" and bruch + TAG <= ts < now]           # bis jetzt (ausschließlich)
        e = V[0] if V else {"tag1": {}, "danach": {}}
        ok("Erster Tag nach dem Neustart gegen die Zeit danach (BTC von Hand), Tag 1 höher als danach (eingepflanzter Abfall)",
           V and abs(e["tag1"]["BTC"][0] - sum(t1) / len(t1)) < 1e-12 and abs(e["danach"]["BTC"][0] - sum(t2) / len(t2)) < 1e-12
           and e["tag1"]["BTC"][0] > e["danach"]["BTC"][0], f"{e}")
        ok("Poller-Anteil am API-Gewicht nur, soweit api_load reicht (60 %), snapshot_meta je Tag (ausgelassen vor dem Bruch 400, danach 100)",
           all(abs(v - 0.6) < 1e-12 for v in P.values()) and len(P) in (3, 4) and abs(M[t0]["ausgelassen"] - 400) < 1e-9
           and abs(M[_tag(now)]["ausgelassen"] - 100) < 1e-9, f"{P} {M.get(t0)}")
        txt = bericht(db, 10, now)
        ok("Bericht vollständig: Abschnitte, Marke „N“ am Neustart-Tag, Neustart mit Uhrzeit, Vergleich Tag 1 gegen danach",
           "JE COIN UND TAG" in txt and "JE TAG AUS snapshot_meta" in txt and f"{_d(_tag(bruch))} N" in txt and _dz(bruch) in txt
           and "Tag 1" in txt and "→" in txt, txt[:300])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"Ergebnis: {'alle Proben grün' if not rot else str(len(rot)) + ' ROT'}")
    return 0 if not rot else 1


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=os.environ.get("HL_DB", "hl_liq.db"))
    p.add_argument("--tage", type=int, default=21)
    p.add_argument("--selbsttest", action="store_true")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(selbsttest())
    print(bericht(a.db, max(2, min(a.tage, 120))))


if __name__ == "__main__":
    main()
