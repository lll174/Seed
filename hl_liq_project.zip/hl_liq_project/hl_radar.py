#!/usr/bin/env python3
"""
hl_radar.py -- Risikoradar (U307, KONZEPT_Risikoradar.md; Paket 23.122)

Auftrag des Nutzers (23.11.2026 19:41): „eine Art Risikoradar zu zeigen, und das Risiko in Prozenten einzuschätzen … Sollte das Risiko
zu sehr ansteigen, sollte es zusätzlich eine Audiomitteilung geben. Die neue Funktion sollte zu sehen sein im Cockpit.“ Entscheidungen
vom 23.11.2026 20:04: zwei Zahlen (groß „−10 % in 7 Tagen“, darunter „−7 % in 48 Stunden“); Meldung als Push, Ton und Ansage.

Was das Modul tut (alle Regeln stehen im Konzept, vorab festgelegt):
  Ereignisse   E7: das Tief der nächsten 7 Tage liegt mindestens 10 % · f unter dem jetzigen Kurs; E2: 7 % · f in 48 Stunden.
               f = Faktor gegenüber BTC nach der Schwankung (Tagesschlüsse aus hebel.db, 365 Tage vor dem Monatsersten).
  Grundrisiko  p7 und p2 aus der abgelegten Verteilung des laufenden Tiefs der jüngsten Rechnung des Ausblicks
               (hl_ausblick.erreichen_aus_lauf) -- dieselbe Quelle wie der Kurs-Rechner des Cockpits.
  Rückblick    G7 und G2: beide Zahlen ab 2022 an Tagesursprüngen nachgerechnet, gegen die laufende Grundrate; besteht eine Zahl
               nicht, steht sie grau und löst keinen Alarm aus. Aus demselben Lauf Grundrate und Schwellen (80. und 95. Perzentil).
  Achsen       acht Achsen von 0 bis 100 (höher = mehr Druck); A1, A2, A3, A4 und A7 bilden den Druck-Index. Messwerte, keine
               Vorhersage, bis eine Regel geprüft ist (R1–R7 mit Paket 23.123).
  Alarm        beim Eintritt in „hoch“ (endet erst unter 0,8 · Schwelle), Sperrzeit 12 Stunden; Entwarnung leise; Hinweis, wenn die
               Kontenquote auf 3 steigt, nachdem sie unter 2,8 lag (höchstens einmal in 7 Tagen). Vorgabe nur BTC.
  Speicher     radar.db neben der Hauptdatenbank: rd_stand (Stunde, Coin), rd_alarm, rd_meta. Liest sonst nur.
Wirkung: keine auf Prognose, Labor, Engine und Notbremse. Kein Abruf im Netz außer dem Push (hl_berichte.senden).

Aufrufe:  hl_radar.py --text [--db PFAD] | --rueckblick [--db PFAD] | --rueckblick-text [--db PFAD] | --selbsttest
"""
from __future__ import annotations

import calendar
import json
import math
import os
import sqlite3
import sys
import threading
import time
import urllib.parse
from decimal import ROUND_HALF_UP, Decimal

import numpy as np

VERSION_MODUL = "2026-09-23.122"
DEBUG_NR_STAND, DEBUG_NR_RUECKBLICK, DEBUG_NR_TEST = 160, 161, 162     # Debug-Läufe radar_stand, radar_rueckblick, radar_test (hl_viz)
DEBUG_NR_REGELN = 163                                                  # reserviert: Prüfung der Regeln R1–R7 (U308, Paket 23.123)
TAG = 86_400
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR")
NAMEN = {"BTC": "Bitcoin", "ETH": "Ethereum", "HYPE": "Hype", "ZEC": "Zcash", "XMR": "Monero"}       # für die Ansage
EREIGNIS = {"e7": {"tage": 7, "x": 0.10, "name": "7 Tagen", "kurz": "7 Tage"},
            "e2": {"tage": 2, "x": 0.07, "name": "48 Stunden", "kurz": "48 Stunden"}}
FAKTOR_TAGE, FAKTOR_MIN = 365, 180            # Abschnitt 1: Tage vor dem Monatsersten, mindestens gemeinsame Tage
FRISCH_KURS_S = 300                           # Abschnitt 2: Kurs höchstens 5 Minuten alt
FRISCH_AUSBLICK_S = 3 * 3600                  # Abschnitt 2: Rechnung des Ausblicks höchstens 3 Stunden alt
FRISCH_TAGE = 3                               # Tageswerte (A3, A4, A7) höchstens 3 Tage alt
PZ_ERHOEHT, PZ_HOCH = 0.80, 0.95              # Abschnitt 3: Schwellen als Perzentile der Rückblick-Werte
PZ_WAHL = (0.95, 0.975, 0.99)                 # Abschnitt 6: im Dashboard verstellbar
PZ_ABLAGE = (0.80, 0.90, 0.95, 0.975, 0.99)
HYSTERESE = 0.8                               # „hoch“ endet unter 0,8 · Schwelle
SPERRZEIT_S = 12 * 3600
KONTEN_AN, KONTEN_AUS, HINWEIS_SPERRE_S = 3.0, 2.8, 7 * TAG
TAKT_S, ABLAGE_S = 300, 3600
RUECKBLICK_MAX_ALTER_S = 30 * TAG
RUECKBLICK_WIEDER_S = 6 * 3600                # ein gescheiterter Rückblick wird frühestens nach 6 h wiederholt
RUECKBLICK_WARTEN_S = 600                     # Debug 161 wartet so lange auf einen Rückblick, den gerade ein anderer Lauf rechnet
G_MIN_TAGE, G_MIN_EREIGNISSE = 1000, 50
G_STEIGUNG = (0.8, 1.2)
G_ALPHA, G_BLOCK, G_BOOT = 0.05, 28, 2000
G_NIVEAU = (0.8, 1.25)                        # Mittel der Zahl ÷ eingetretene Quote (Präzisierung beim Bau, vor jeder echten Zahl)
ZEILE_MAX = 150                               # Berichte: keine Zeile länger (Lesen am Handy)
GRUNDRATE_MIN, BIB_MIN = 100, 200
ZUV_KLASSEN = (0.0, 0.02, 0.05, 0.10, 0.20, 0.40, 1.0000001)
PZ_TAGE, PZ_TAGE_MIN = 365, 180               # A3, A4, A7: Perzentil gegen die Tageswerte der 365 Tage davor
A5_GRENZE = 0.05                              # Liquidationspreise bis 5 % unter dem Kurs
A5_TAGE, A5_MIN = 90, 336                     # eigene Stundenwerte: höchstens 90 Tage, mindestens 14 Tage (336 Werte; Konzept Abschnitt 4)
A6_TAGE, A6_MIN = 30, 240                     # Stundenmittel der letzten 30 Tage, mindestens 240 (10 Tage)
TIEFE_MIN_ZEILEN = 60                         # Mittel der letzten 60 Minuten: mindestens so viele Zeilen (5-s-Raster)
INDEX_ACHSEN = ("a1", "a2", "a3", "a4", "a7")
INDEX_MIN = 4
PUSH_VERSUCHE, PUSH_FRIST_S = 5, 3600
MELDUNG_ALT_S = 600                           # der Browser spielt nur Meldungen der letzten 10 Minuten
ACHSEN_NAMEN = (("a1", "Positionierung"), ("a2", "Hebel-Menge"), ("a3", "Preis des Hebels"), ("a4", "Spot-Nachfrage"),
                ("a5", "Liquidations-Nähe"), ("a6", "Markttiefe"), ("a7", "Schwankung"), ("a8", "Umfeld"))
ACHSEN_KURZ = {"a1": "Position", "a2": "Hebel", "a3": "Preis", "a4": "Spot", "a5": "Liq.-Nähe", "a6": "Tiefe", "a7": "Schw.", "a8": "Umfeld"}   # im Netz
STUFEN_WORT = {"ohne": "ohne Stufe", "normal": "normal", "erhoeht": "erhöht", "hoch": "hoch"}
BELEG_U142 = ("U142 H1: Ab einer Kontenquote von 3 folgte in 7 Tagen häufiger ein Rücksetzer (20,3 % der Fälle gegen 7,3 % sonst). "
              "Geprüft wurde dort ein anderes Ereignis (1,5 übliche Wochenschwankungen), nicht die Zahl dieser Karte.")
GRENZEN = ("Das Radar zeigt, wie hoch das Risiko ist, nicht wann etwas geschieht. Einen Schock durch Nachrichten sieht es nicht kommen. "
           "Achsen und Druck-Index sind Messwerte; ob sie etwas ankündigen, prüft Paket 23.123 (Regeln R1 bis R7).")

SCHEMA = (
    "CREATE TABLE IF NOT EXISTS rd_stand (stunde INTEGER, coin TEXT, ts INTEGER, p7 REAL, p2 REAL, idx REAL, a5 REAL, a6 REAL, json TEXT, "
    "PRIMARY KEY (stunde, coin)) WITHOUT ROWID",
    "CREATE TABLE IF NOT EXISTS rd_alarm (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, coin TEXT, ereignis TEXT, art TEXT, p REAL, "
    "titel TEXT, text TEXT, ansage TEXT, prio INTEGER, push INTEGER, versuche INTEGER DEFAULT 0, push_fehler TEXT)",
    "CREATE INDEX IF NOT EXISTS ix_rd_alarm_ts ON rd_alarm(ts)",
    "CREATE TABLE IF NOT EXISTS rd_meta (k TEXT PRIMARY KEY, v TEXT)",
)
PUSH_AUS, PUSH_OFFEN, PUSH_GESENDET, PUSH_AUFGEGEBEN = 0, 1, 2, 3


# ================================================================================================ Zahlen und Zeit

def _zahl(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _hu(x: float, nd: int = 0) -> Decimal:
    """Kaufmännisch runden (5 nach oben), ohne den Umweg über die Binärdarstellung: 32,5 -> 33, 0,125 -> 0,13."""
    return Decimal(str(x)).quantize(Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP)


def _de(x, nd: int = 1, vz: bool = False) -> str:
    """Zahl im deutschen Format; eine gerundete Null trägt kein Vorzeichen."""
    v = _zahl(x)
    if v is None:
        return "—"
    d = _hu(v, nd)
    s = f"{abs(d):,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("−" if d < 0 else ("+" if vz and d > 0 else "")) + s


def _px(x) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    return _de(v, 0 if abs(v) >= 1000 else (2 if abs(v) >= 1 else 4))


def p_text(p, lage: str = "innen") -> str:
    """Wahrscheinlichkeit für die Anzeige: unter 10 % mit einer Nachkommastelle, sonst ganzzahlig; die Ränder des Rasters als Schranke."""
    v = _zahl(p)
    if v is None or lage == "fehlt":
        return "—"
    if lage == "unter" or v < 0.005:
        return "unter 0,5 %"
    if lage == "ueber" or v > 0.995:
        return "über 99,5 %"
    return (_de(v * 100, 1) if _hu(v * 100, 1) < 10 else _de(v * 100, 0)) + " %"


def x_text(x) -> str:
    """Abstand der Schwelle: „10 %“, „13,9 %“."""
    v = _zahl(x)
    if v is None:
        return "—"
    d = _hu(v * 100, 1)
    return (_de(v * 100, 0) if d == d.to_integral_value() else _de(v * 100, 1)) + " %"


def _umbruch(zeilen, breite: int = ZEILE_MAX) -> list:
    """Zeilen an Leerzeichen umbrechen; Folgezeilen behalten den Einzug der ersten und rücken um zwei Zeichen ein."""
    out = []
    for z in zeilen:
        z = str(z)
        if len(z) <= breite:
            out.append(z); continue
        einzug = " " * (len(z) - len(z.lstrip(" ")) + 2)
        rest = z
        erste = True
        while len(rest) > breite:
            k = rest.rfind(" ", len(einzug) + 1 if not erste else 1, breite + 1)
            if k <= (0 if erste else len(einzug)):
                k = breite
            out.append(rest[:k].rstrip()); rest = einzug + rest[k:].lstrip(); erste = False
        out.append(rest)
    return out


def _dt(ts) -> str:
    v = _zahl(ts)
    return time.strftime("%d.%m. %H:%M UTC", time.gmtime(v)) if v is not None else "—"


def _orts(ts) -> str:
    """Zeit einer Meldung in der Ortszeit des Rechners mit dem Kürzel der Zeitzone (etwa „23.11. 21:29 CET“) -- die Meldung liest ein Mensch
    auf dem Handy; Berichte nennen dagegen UTC."""
    v = _zahl(ts)
    if v is None:
        return "—"
    lt = time.localtime(v)
    return time.strftime("%d.%m. %H:%M ", lt) + (time.strftime("%Z", lt) or "Ortszeit")


def _tag_txt(tag) -> str:
    v = _zahl(tag)
    return time.strftime("%d.%m.%Y", time.gmtime(v * TAG)) if v is not None else "—"


def monatserster(tag: int) -> int:
    """UTC-Tag (Tage seit 1970) des Monatsersten, in dessen Monat `tag` liegt."""
    t = time.gmtime(int(tag) * TAG)
    return calendar.timegm((t.tm_year, t.tm_mon, 1, 0, 0, 0)) // TAG


def pz_davor(reihe, i: int, fenster: int = PZ_TAGE, mind: int = PZ_TAGE_MIN):
    """Mittelrang von reihe[i] unter den endlichen Werten der `fenster` Stellen davor (gleiche zählen halb); None unter `mind` Werten
    oder wenn alle gleich sind. -> Anteil 0 … 1."""
    x = _zahl(reihe[i]) if 0 <= i < len(reihe) else None
    if x is None:
        return None
    w = [u for u in (_zahl(a) for a in reihe[max(0, i - fenster):i]) if u is not None]
    if len(w) < mind or max(w) == min(w):
        return None
    return (sum(1 for a in w if a < x) + 0.5 * sum(1 for a in w if a == x)) / len(w)


def pz_unter(x, werte, mind: int):
    """Mittelrang von x unter `werte` (wie pz_davor, für eine lose Liste)."""
    v = _zahl(x)
    w = [u for u in (_zahl(a) for a in (werte or [])) if u is not None]
    if v is None or len(w) < mind or max(w) == min(w):
        return None
    return (sum(1 for a in w if a < v) + 0.5 * sum(1 for a in w if a == v)) / len(w)


# ================================================================================================ Speicher

def pfad(db: str) -> str:
    """radar.db liegt neben der Hauptdatenbank; HL_RADAR_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_RADAR_DB")
    return p if p else os.path.join(os.path.dirname(os.path.abspath(db)), "radar.db")


def verbinden(p: str) -> sqlite3.Connection:
    con = sqlite3.connect(p, timeout=30, isolation_level=None, check_same_thread=False)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA busy_timeout=30000")
        for s in SCHEMA:
            con.execute(s)
    except sqlite3.Error:
        con.close()
        raise
    return con


def lesen(p: str):
    """Nur-Lese-Verbindung; None, wenn die Datei fehlt."""
    if not p or not os.path.exists(p):
        return None
    con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=10, check_same_thread=False)
    con.execute("PRAGMA busy_timeout=10000")
    return con


def meta(con, k: str, standard=None):
    if con is None:
        return standard
    try:
        r = con.execute("SELECT v FROM rd_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    if r is None:
        return standard
    try:
        return json.loads(r[0])
    except (TypeError, ValueError):
        return standard


def meta_setzen(con, k: str, wert) -> None:
    con.execute("INSERT INTO rd_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, json.dumps(_ohne_nan(wert), ensure_ascii=False)))


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, (np.floating,)):
        return float(x) if np.isfinite(x) else None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, dict):
        return {str(k): _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, np.ndarray)):
        return [_ohne_nan(v) for v in x]
    return x


EINSTELLUNG_VORGABE = {"push": True, "coins": ["BTC"], "pz": PZ_HOCH}


def einstellung_pruefen(e) -> dict:
    """Einstellung aus rd_meta oder aus einer Anfrage -> gültige Fassung; Unbekanntes fällt auf die Vorgabe zurück."""
    e = e if isinstance(e, dict) else {}
    coins = [c for c in COINS if c in (e.get("coins") if isinstance(e.get("coins"), (list, tuple)) else EINSTELLUNG_VORGABE["coins"])]
    pz = _zahl(e.get("pz"))
    return {"push": bool(e.get("push", True)), "coins": coins,
            "pz": next((w for w in PZ_WAHL if pz is not None and abs(w - pz) < 1e-9), PZ_HOCH)}


def einstellung_lesen(con) -> dict:
    return einstellung_pruefen(meta(con, "einstellung", EINSTELLUNG_VORGABE))


def einstellung_setzen(db: str, neu: dict) -> dict:
    """Vom Dashboard: Schalter „Push“, Coins der Meldungen, Perzentil der Schwelle „hoch“. -> die gespeicherte Fassung."""
    con = verbinden(pfad(db))
    try:
        e = einstellung_lesen(con)
        if isinstance(neu, dict):
            for k in ("push", "coins", "pz"):
                if k in neu:
                    e[k] = neu[k]
        e = einstellung_pruefen(e)
        meta_setzen(con, "einstellung", e)
        return e
    finally:
        con.close()


def _qk(pz: float) -> str:
    return f"{pz:g}"


# ================================================================================================ Faktor (Abschnitt 1)

def kerzen_lesen(db: str, coins=COINS, ab_tag: int | None = None) -> dict:
    """
    Tageskerzen aus hebel.db (nur lesen): je Coin der Perpetual <COIN>USDT (tag, c, v_usd, taker_usd) und die Summe seiner Spot-Paare
    je Tag (Umsatz und Taker-Kauf in USD). -> {coin: {"tag", "c", "pv", "pt", "stag", "sv", "st"}}; ohne hebel.db {}.
    """
    import hl_hebel as HB
    con = HB._lesen(HB.hebel_pfad(db))
    if con is None:
        return {}
    out = {}
    ab = int(ab_tag) if ab_tag is not None else 0
    try:
        for coin in coins:
            r = con.execute("SELECT tag, c, v_usd, taker_usd FROM hb_kerzen WHERE markt='um' AND symbol=? AND tag>=? ORDER BY tag",
                            (f"{coin}USDT", ab)).fetchall()
            if not r:
                continue
            sym = [f"{coin}{q}" for q in HB.SPOT_QUOTES]
            s = con.execute("SELECT tag, SUM(v_usd), SUM(taker_usd), SUM(CASE WHEN taker_usd IS NULL THEN 1 ELSE 0 END) FROM hb_kerzen "
                            f"WHERE markt='spot' AND symbol IN ({','.join('?' * len(sym))}) AND tag>=? AND v_usd>0 GROUP BY tag ORDER BY tag",
                            (*sym, ab)).fetchall()
            f = lambda v: float(v) if v is not None else float("nan")   # noqa: E731
            out[coin] = {"tag": np.array([int(x[0]) for x in r], dtype=np.int64), "c": np.array([f(x[1]) for x in r]),
                         "pv": np.array([f(x[2]) for x in r]), "pt": np.array([f(x[3]) for x in r]),
                         "stag": np.array([int(x[0]) for x in s], dtype=np.int64), "sv": np.array([f(x[1]) for x in s]),
                         "st": np.array([f(x[2]) if not x[3] else float("nan") for x in s])}
    except sqlite3.Error:
        return out
    finally:
        con.close()
    return out


def _renditen_je_tag(tage, c) -> dict:
    """{Tag: Log-Rendite} für Tage, an denen der Tag selbst und der Vortag einen Schluss haben."""
    d = {}
    for i in range(1, len(tage)):
        if int(tage[i]) - int(tage[i - 1]) == 1 and c[i] > 0 and c[i - 1] > 0 and math.isfinite(c[i]) and math.isfinite(c[i - 1]):
            d[int(tage[i])] = math.log(c[i] / c[i - 1])
    return d


def faktor_rechnen(coin: str, rc: dict | None, rb: dict | None, stichtag: int) -> dict:
    """
    Faktor gegenüber BTC am Monatsersten `stichtag` aus den Tagesrenditen rc (Coin) und rb (BTC): σ̄_c ÷ σ̄_BTC über die Tage d mit
    stichtag − 365 ≤ d < stichtag, an denen beide eine Rendite haben; mindestens 1, auf zwei Stellen. Unter 180 gemeinsamen Tagen kein
    Faktor. BTC selbst hat 1.
    """
    if coin == "BTC":
        return {"f": 1.0, "n": None, "stichtag": int(stichtag), "grund": None}
    if not rc or not rb:
        return {"f": None, "n": 0, "stichtag": int(stichtag), "grund": f"Für {coin} oder BTC fehlen Tagesschlüsse in hebel.db."}
    gem = [t for t in rc if t in rb and stichtag - FAKTOR_TAGE <= t < stichtag]
    n = len(gem)
    if n < FAKTOR_MIN:
        return {"f": None, "n": n, "stichtag": int(stichtag),
                "grund": f"Für {coin} gibt es erst {n} gemeinsame Tage mit BTC (gebraucht werden {FAKTOR_MIN})."}
    sc = math.sqrt(sum(rc[t] ** 2 for t in gem) / n); sb = math.sqrt(sum(rb[t] ** 2 for t in gem) / n)
    if not sb > 0:
        return {"f": None, "n": n, "stichtag": int(stichtag), "grund": "Die Schwankung von BTC ist null."}
    return {"f": max(1.0, float(_hu(sc / sb, 2))), "n": n, "roh": sc / sb, "stichtag": int(stichtag), "grund": None}


_FAKTOR_CACHE: dict = {}


def faktor(db: str, coin: str, jetzt: int, K: dict | None = None) -> dict:
    """Faktor des laufenden Monats (im Speicher gemerkt, bis der Monat wechselt oder er noch fehlt)."""
    st = monatserster(int(jetzt) // TAG)
    key = (os.path.abspath(db), coin, st)
    hit = _FAKTOR_CACHE.get(key)
    if hit is not None and hit.get("f") is not None and K is None:
        return hit
    if coin == "BTC":
        out = faktor_rechnen("BTC", None, None, st)
    else:
        K = K if K is not None else kerzen_lesen(db, (coin, "BTC"), st - FAKTOR_TAGE - 2)
        if coin not in K or "BTC" not in K:
            out = {"f": None, "n": 0, "stichtag": st, "grund": f"Für {coin} oder BTC fehlen Tagesschlüsse in hebel.db (die Hebel-Studie lädt sie)."}
        else:
            out = faktor_rechnen(coin, _renditen_je_tag(K[coin]["tag"], K[coin]["c"]), _renditen_je_tag(K["BTC"]["tag"], K["BTC"]["c"]), st)
    _FAKTOR_CACHE[key] = out
    return out


# ================================================================================================ Grundrisiko und Stufe (Abschnitte 2, 6)

def stufe_von(p, s_erhoeht, s_hoch, war_hoch: bool) -> str:
    """normal · erhoeht · hoch. „Hoch“ beginnt bei p ≥ Schwelle und endet erst, wenn p unter 0,8 · Schwelle fällt."""
    p = _zahl(p); s_hoch = _zahl(s_hoch)
    if p is None or s_hoch is None:
        return "ohne"
    if p >= s_hoch or (war_hoch and p >= HYSTERESE * s_hoch):
        return "hoch"
    s_erhoeht = _zahl(s_erhoeht)
    return "erhoeht" if s_erhoeht is not None and p >= s_erhoeht else "normal"


def p_wert_text(p) -> str:
    """p-Wert für Sätze: drei Stellen; unter 0,001 steht die Schranke (2000 Ziehungen können nicht „0,000“ belegen)."""
    v = _zahl(p)
    if v is None:
        return "p —"
    return "p unter 0,001" if v < 0.001 else f"p {_de(v, 3)}"


def urteil_satz(key: str, u: dict | None, rb: dict | None) -> str:
    """Ein Satz zum Rückblick dieser Zahl (G7 bzw. G2)."""
    name = "G7" if key == "e7" else "G2"
    if not rb:
        return f"Noch nicht geprüft: Der Rückblick ({name}) hat auf diesem Rechner noch nicht gerechnet (Debug 161)."
    if not u:
        return f"Der Rückblick ({name}) hat für diese Zahl kein Urteil abgelegt."
    kopf = (f"Rückblick {name} vom {_dt(rb.get('stand'))}: {_tsd(u.get('n'))} Ursprünge an {_tsd(u.get('n_tage'))} Tagen, "
            f"{_tsd(u.get('n_ereignisse'))} Ereignisse, Skill {_de((_zahl(u.get('skill')) or 0) * 100, 1, True)} % ({p_wert_text(u.get('p'))}), "
            f"Steigung {_de(u.get('steigung'), 2)}, Niveau {_de(u.get('niveau'), 2)}")
    if u.get("besteht"):
        return kopf + " — besteht."
    return kopf + f" — im Rückblick nicht bestätigt: {u.get('grund') or 'ohne Angabe'}."


def niveau_satz(coin: str, niveau) -> str | None:
    """Hinweis, wenn die Zahl dieses Coins im Rückblick im Mittel deutlich über oder unter der eingetretenen Quote lag."""
    v = _zahl(niveau)
    if v is None or G_NIVEAU[0] <= v <= G_NIVEAU[1]:
        return None
    return (f"Für {coin} lag diese Zahl im Rückblick im Mittel beim {_de(v, 2)}-Fachen der eingetretenen Quote -- "
            + ("sie kann zu hoch sein." if v > 1 else "sie kann zu niedrig sein."))


def _tsd(n) -> str:
    v = _zahl(n)
    return _de(v, 0) if v is not None else "—"


def ereignisse_bauen(coin: str, lauf: dict | None, lauf_fehlt: str | None, f: dict, kurs, kurs_frisch: bool, jetzt: int, rb: dict | None,
                     zust: dict | None, pz_wahl: float = PZ_HOCH) -> dict:
    """Beide Zahlen mit Schwelle, Grundrate, Urteil des Rückblicks und Stufe. Ohne frische Quelle steht der Grund statt der Zahl."""
    import hl_ausblick as AU
    rc = ((rb or {}).get("coins") or {}).get(coin) or {}
    kurs = _zahl(kurs)
    out = {}
    for key, E in EREIGNIS.items():
        u = ((rb or {}).get("urteil") or {}).get(key)
        r = rc.get(key) or {}
        e = {"key": key, "tage": E["tage"], "frist": E["name"], "x": None, "x_text": "—", "kurs_schwelle": None, "p": None, "lage": "fehlt",
             "p_text": "—", "fehlt": None, "grundrate": _zahl(r.get("grundrate")), "stufe": "ohne", "s_erhoeht": None, "s_hoch": None,
             "besteht": (bool(u.get("besteht")) if u else None), "urteil": urteil_satz(key, u, rb), "niveau": niveau_satz(coin, r.get("niveau"))}
        fz = _zahl((f or {}).get("f"))
        if fz is None:
            e["fehlt"] = (f or {}).get("grund") or f"Für {coin} gibt es keinen Faktor."
        else:
            x = E["x"] * fz
            e["x"] = x; e["x_text"] = x_text(x)
            if kurs:
                e["kurs_schwelle"] = kurs * (1 - x) if x < 1 else None
            if x >= 0.9:
                e["fehlt"] = f"Die Schwelle läge bei {x_text(x)} -- dafür rechnet das Radar nicht."
            elif not kurs or not kurs_frisch:
                e["fehlt"] = "Kein frischer Kurs (höchstens 5 Minuten alt)."
            elif lauf is None:
                e["fehlt"] = lauf_fehlt or f"Der Ausblick hat für {coin} noch keine Verteilung abgelegt."
            elif int(jetzt) - int(lauf.get("anker") or 0) > FRISCH_AUSBLICK_S:
                e["fehlt"] = f"Die Rechnung des Ausblicks ist älter als 3 Stunden (Stand {_dt(lauf.get('anker'))})."
            else:
                p, lage = AU.erreichen_aus_lauf(lauf.get("h"), math.log(1 - x), E["tage"])
                if lage == "fehlt" or _zahl(p) is None:
                    e["fehlt"] = (f"Der Ausblick hat die Verteilung für {E['tage']} Tage noch nicht abgelegt "
                                  "(kommt mit seiner nächsten Rechnung, spätestens in einer Stunde).")
                else:
                    e["p"] = float(p); e["lage"] = lage; e["p_text"] = p_text(p, lage)
        q = r.get("q") or {}
        if e["p"] is not None and e["besteht"] is True and _zahl(q.get(_qk(pz_wahl))) is not None:
            e["s_erhoeht"] = _zahl(q.get(_qk(PZ_ERHOEHT))); e["s_hoch"] = _zahl(q.get(_qk(pz_wahl)))
            e["stufe"] = stufe_von(e["p"], e["s_erhoeht"], e["s_hoch"], bool(((zust or {}).get(key) or {}).get("hoch")))
        e["stufe_wort"] = STUFEN_WORT[e["stufe"]]
        e["grundrate_text"] = p_text(e["grundrate"]) if e["grundrate"] is not None else None
        e["schwellen"] = (f"erhöht ab {p_text(e['s_erhoeht'])}, hoch ab {p_text(e['s_hoch'])} (endet unter {p_text(HYSTERESE * e['s_hoch'])})"
                          if e["s_hoch"] is not None and e["s_erhoeht"] is not None else None)
        e["satz"] = ereignis_satz(coin, e)
        out[key] = e
    return out


def ereignis_satz(coin: str, e: dict) -> str:
    """Der Satz der Karte und des Berichts zu einer Zahl."""
    if e.get("x") is None:
        return f"{coin}, {e['frist']}: {e.get('fehlt') or 'keine Zahl'}"
    kopf = f"Risiko, dass {coin} in {e['frist']} {e['x_text']} tiefer berührt wird" + (f" (bei {_px(e['kurs_schwelle'])})" if e.get("kurs_schwelle") else "")
    if e.get("p") is None:
        return kopf + f": keine Zahl. {e.get('fehlt') or ''}".rstrip()
    s = kopf + f": {e['p_text']}"
    if e.get("grundrate") is not None:
        s += f" · üblich {p_text(e['grundrate'])}"
    if e.get("besteht") is True:
        s += f" · Stufe {e['stufe_wort']}" if e.get("stufe") != "ohne" else " · ohne Stufe (für diesen Coin gibt es im Rückblick keine Schwellen)"
    elif e.get("besteht") is False:
        s += " · im Rückblick nicht bestätigt"
    else:
        s += " · noch nicht geprüft"
    return s + "."


# ================================================================================================ Achsen (Abschnitt 4)

def _auf_achse(tag0: int, n: int, tage, werte) -> np.ndarray:
    out = np.full(n, np.nan)
    if tage is None or not len(tage):
        return out
    i = np.asarray(tage, dtype=np.int64) - int(tag0)
    m = (i >= 0) & (i < n)
    out[i[m]] = np.asarray(werte, dtype=float)[m]
    return out


def _summe7(x: np.ndarray, mind: int = 6) -> tuple:
    """Gleitende Summe über 7 Stellen (die Stelle selbst und sechs davor) und die Zahl der endlichen Werte darin."""
    ok = np.isfinite(x); v = np.where(ok, x, 0.0)
    cs = np.concatenate([[0.0], np.cumsum(v)]); cn = np.concatenate([[0], np.cumsum(ok.astype(np.int64))])
    n = len(x); a = np.maximum(0, np.arange(n) - 6); b = np.arange(n) + 1
    s = cs[b] - cs[a]; k = cn[b] - cn[a]
    return np.where(k >= mind, s, np.nan), k


def lange_reihen(K: dict, fund_ts=None, fund_rate=None) -> dict | None:
    """
    Tagesreihen eines Coins auf lückenloser Achse (hl_zyklus.achse, wie U142): σ (EWMA, Halbwertszeit 20 Tage), Funding als Mittel der
    letzten 7 Tage auf ein Jahr gerechnet, Spot- und Perp-Taker-Saldo über 7 Tage. -> {tag0, n, c, sig, fund7, spot7, perp7}
    """
    import hl_zyklus as ZY
    ax = ZY.achse(K["tag"], K["c"])
    if ax is None or len(ax["c"]) < 30:
        return None
    tag0 = int(ax["tag0"]); c = np.asarray(ax["c"], dtype=float); n = len(c)
    sig = ZY.sigma_batch(ZY.renditen(c[None, :]))[0]
    fund7 = np.full(n, np.nan)
    if fund_ts is not None and len(fund_ts):
        d = np.asarray(fund_ts, dtype=np.int64) // TAG - tag0
        m = (d >= 0) & (d < n)
        s = np.zeros(n); hat = np.zeros(n, dtype=bool)
        np.add.at(s, d[m], np.asarray(fund_rate, dtype=float)[m]); hat[d[m]] = True
        su, k = _summe7(np.where(hat, s, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            fund7 = su / k * 365.0
    def saldo(tage, v, tk):                                              # Σ(2·Taker-Kauf − Umsatz) ÷ Σ Umsatz über 7 Tage
        va = _auf_achse(tag0, n, tage, v); ta = _auf_achse(tag0, n, tage, tk)
        ok = np.isfinite(va) & np.isfinite(ta) & (va > 0)
        z, k = _summe7(np.where(ok, 2 * ta - va, np.nan)); nn, _ = _summe7(np.where(ok, va, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(nn > 0, z / nn, np.nan)
    return {"tag0": tag0, "n": n, "c": c, "sig": sig, "fund7": fund7, "spot7": saldo(K.get("stag"), K.get("sv"), K.get("st")),
            "perp7": saldo(K["tag"], K["pv"], K["pt"])}


def lange_achsen_aus(R: dict | None, heute: int) -> dict:
    """A3, A4 und A7 aus den Tagesreihen: Wert am letzten Tag der Achse und Perzentil gegen die 365 Tage davor."""
    out = {}
    namen = {"a3": ("fund7", "Funding Binance, Mittel der letzten 7 Tage"), "a4": ("spot7", "Spot-Taker-Saldo Binance über 7 Tage"),
             "a7": ("sig", "Schwankung je Tag (σ)")}
    for key, (feld, name) in namen.items():
        if R is None:
            out[key] = {"roh": None, "pz": None, "tag": None, "grau": "Für diesen Coin fehlen Tageskerzen in hebel.db."}; continue
        i = R["n"] - 1; tag = R["tag0"] + i
        roh = _zahl(R[feld][i])
        e = {"roh": roh, "pz": None, "tag": int(tag), "grau": None}
        if heute - tag > FRISCH_TAGE:
            e["grau"] = f"Tageswerte nur bis {_tag_txt(tag)}."
        elif roh is None:
            e["grau"] = (f"{name}: kein Wert am {_tag_txt(tag)}"
                         + (" (in hebel.db liegen für diesen Coin keine Spot-Kerzen von Binance)." if key == "a4" and not np.isfinite(R["spot7"]).any() else "."))
        else:
            e["pz"] = pz_davor(R[feld], i)
            if e["pz"] is None:
                e["grau"] = f"{name}: für das Perzentil fehlt Verlauf (gebraucht werden {PZ_TAGE_MIN} Tageswerte)."
        out[key] = e
    return out


_LANG_CACHE: dict = {}


def lange_achsen(db: str, coin: str, jetzt: int) -> dict:
    """A3, A4, A7 für einen Coin aus hebel.db und swing.db; je Stunde einmal gelesen."""
    key = (os.path.abspath(db), coin, int(jetzt) // 3600)
    if key in _LANG_CACHE:
        return _LANG_CACHE[key]
    heute = int(jetzt) // TAG
    R = None
    try:
        K = kerzen_lesen(db, (coin,), heute - PZ_TAGE - 200)
        if coin in K:
            ft = fr = None
            try:
                import hl_swing as SW
                import hl_hebel as HB
                sc = HB._lesen(SW.swing_pfad(db))
                if sc is not None:
                    try:
                        F = SW.funding_lesen(sc, coin); ft, fr = F["ts"], F["rate"]
                    finally:
                        sc.close()
            except Exception:  # noqa: BLE001 -- ohne Funding bleibt A3 grau, der Rest steht
                ft = fr = None
            R = lange_reihen(K[coin], ft, fr)
    except Exception:  # noqa: BLE001 -- die Karte nennt dann den Grund je Achse
        R = None
    out = lange_achsen_aus(R, heute)
    if len(_LANG_CACHE) > 64:
        _LANG_CACHE.clear()
    _LANG_CACHE[key] = out
    return out


_TIEFE_CACHE: dict = {}


def tiefen_stunden(con, jetzt: int) -> dict:
    """Stundenmittel der Gebote bis −1 % (bid_100, USD) je Coin über die letzten 30 Tage aus book_summary_1m und book_summary --
    ein Durchlauf für alle Coins, je Stunde einmal. -> {coin: {stunde: mittel}}"""
    try:
        datei = con.execute("PRAGMA database_list").fetchone()[2]
    except (sqlite3.Error, TypeError, IndexError):
        datei = ""
    key = (datei, int(jetzt) // 3600)
    hit = _TIEFE_CACHE.get("hist")
    if hit is not None and hit[0] == key:
        return hit[1]
    out: dict = {}
    ab = (key[1] - A6_TAGE * 24) * 3600; bis = key[1] * 3600
    for tab in ("book_summary_1m", "book_summary"):
        try:
            for coin, h, m in con.execute(f"SELECT coin, ts / 3600, AVG(bid_100) FROM {tab} WHERE ts >= ? AND ts < ? AND bid_100 > 0 "
                                          "GROUP BY coin, ts / 3600", (ab, bis)):
                if m is not None:
                    out.setdefault(coin, {})[int(h)] = float(m)                 # die genaueren Zeilen (book_summary) zählen zuletzt
        except sqlite3.Error:
            continue
    _TIEFE_CACHE["hist"] = (key, out)
    return out


def tiefe_lesen(con, coin: str, jetzt: int) -> dict:
    """Gebote bis −1 % im Hyperliquid-Buch: Mittel der letzten 60 Minuten und die Stundenmittel der letzten 30 Tage."""
    out = {"usd": None, "n": 0, "stunden": [], "fehlt": None}
    if con is None:
        out["fehlt"] = "Datenbank des Recorders fehlt."; return out
    try:
        r = con.execute("SELECT AVG(bid_100), COUNT(*) FROM book_summary WHERE coin=? AND ts>? AND ts<=? AND bid_100>0",
                        (coin, int(jetzt) - 3600, int(jetzt))).fetchone()
        out["n"] = int(r[1] or 0) if r else 0
        if out["n"] >= TIEFE_MIN_ZEILEN and r[0] is not None:
            out["usd"] = float(r[0])
        else:
            out["fehlt"] = f"Orderbuch: in den letzten 60 Minuten nur {out['n']} Werte (gebraucht werden {TIEFE_MIN_ZEILEN})."
        out["stunden"] = list((tiefen_stunden(con, jetzt).get(coin) or {}).values())
    except sqlite3.Error as e:
        out["fehlt"] = ("Orderbuch: Die Tabelle book_summary fehlt in der Datenbank des Recorders." if "no such table" in str(e)
                        else f"Orderbuch nicht lesbar ({type(e).__name__}).")
    return out


def liq_naehe(zeilen, kurs, grenze: float = A5_GRENZE) -> float:
    """Long-Positionswert (USD) der Heatmap mit Liquidationspreis im Bereich [Kurs · (1 − grenze), Kurs)."""
    k = _zahl(kurs)
    if not k:
        return 0.0
    return float(sum(n for b, s, n, _ in (zeilen or []) if s == "long" and k * (1 - grenze) <= b < k))


def a5_verlauf(con_r, coin: str, jetzt: int) -> list:
    """Die eigenen Stundenwerte von A5 (Rohwert) der letzten 90 Tage aus rd_stand."""
    if con_r is None:
        return []
    try:
        return [float(r[0]) for r in con_r.execute("SELECT a5 FROM rd_stand WHERE coin=? AND stunde>=? AND a5 IS NOT NULL",
                                                   (coin, int(jetzt) // 3600 - A5_TAGE * 24))]
    except sqlite3.Error:
        return []


def kurze_achsen(L: dict | None, kurs, kurs_frisch: bool, T: dict, a5_hist: list, jetzt: int, frisch_liq_s: int = 1800) -> dict:
    """A5 (Zwangsverkauf gegen Buchtiefe) und A6 (Markttiefe, umgekehrt) aus dem Schnappschuss der Heatmap und dem Orderbuch."""
    a5 = {"roh": None, "pz": None, "liq_usd": None, "tiefe_usd": T.get("usd"), "grau": None, "n_hist": len(a5_hist or []), "abdeckung": None}
    a6 = {"roh": T.get("usd"), "pz": None, "grau": None, "n_hist": len(T.get("stunden") or [])}
    L = L or {}
    if isinstance(L.get("abdeckung"), dict):
        a5["abdeckung"] = _zahl(L["abdeckung"].get("anteil"))
    if T.get("usd") is None:
        a6["grau"] = T.get("fehlt") or "Orderbuch: kein Wert."
    else:
        pz = pz_unter(T["usd"], T.get("stunden"), A6_MIN)
        if pz is None:
            a6["grau"] = f"Markttiefe: für das Perzentil fehlt Verlauf ({a6['n_hist']} von {A6_MIN} Stundenwerten)."
        else:
            a6["pz"] = 1.0 - pz                                         # dünnes Buch = hoher Wert
    if L.get("ts") is None or (L.get("fehlt") or []):
        a5["grau"] = "Heatmap: " + ("; ".join(L.get("fehlt") or []) or "noch kein Schnappschuss") + "."
    elif int(jetzt) - int(L["ts"]) > frisch_liq_s:
        a5["grau"] = f"Heatmap nicht frisch (Stand {_dt(L['ts'])})."
    elif not _zahl(kurs) or not kurs_frisch:
        a5["grau"] = "Kein frischer Kurs."
    elif T.get("usd") is None:
        a5["grau"] = T.get("fehlt") or "Orderbuch: kein Wert."
    else:
        a5["liq_usd"] = liq_naehe(L.get("zeilen"), kurs)
        a5["roh"] = a5["liq_usd"] / T["usd"]
        a5["pz"] = pz_unter(a5["roh"], a5_hist, A5_MIN)
        if a5["pz"] is None:
            a5["grau"] = f"Für das Perzentil fehlt eigener Verlauf ({a5['n_hist']} von {A5_MIN} Stundenwerten; das Radar sammelt sie seit dem Einspielen)."
    return {"a5": a5, "a6": a6}


def umfeld(lampen: dict, nb_stufe) -> dict:
    """
    A8, Stufen: 0 nichts · 33 Wochenende · 66 Termin binnen 24 h · 100 Aktien-Lampe an oder Notbremse ab Stufe 1; der höchste Wert gilt.
    Ist die Termin- oder die Aktien-Lampe grau (oder fehlt sie) und könnte sie mehr bedeuten als das Bekannte, gibt es keinen Wert
    (grau) -- „0“ hieße dann „nichts Besonderes“, ohne dass es jemand weiß. „offen“ nennt diese Lampen.
    """
    zust = lambda k: (lampen.get(k) or {}).get("zustand")                          # noqa: E731
    an = lambda k: zust(k) in ("hinweis", "warnung")                               # noqa: E731
    gruende = []; wert = 0
    if an("wochenende"):
        wert = max(wert, 33); gruende.append("Wochenende")
    if an("termin"):
        wert = max(wert, 66); gruende.append("Termin: " + str((lampen.get("termin") or {}).get("wert") or ""))
    if an("aktien"):
        wert = max(wert, 100); gruende.append("Aktien-Lampe an (" + str((lampen.get("aktien") or {}).get("wert") or "") + ")")
    nb = _zahl(nb_stufe)
    if nb is not None and nb >= 1:
        wert = max(wert, 100); gruende.append(f"Notbremse Stufe {int(nb)}")
    offen = [name for k, name, stufe in (("termin", "Termin", 66), ("aktien", "Aktien", 100))
             if zust(k) not in ("aus", "hinweis", "warnung") and wert < stufe]
    return {"wert": (None if offen else wert), "gruende": gruende, "offen": offen}


def achsen_bauen(B: dict, LA: dict, KA: dict, nb_stufe, coin: str = "") -> list:
    """Die acht Achsen der Karte aus dem Cockpit (Messwerte, Lampen), den Tagesreihen (A3, A4, A7) und den kurzen Achsen (A5, A6)."""
    mw = {m.get("key"): m for m in (B.get("messwerte") or []) if isinstance(m, dict)}
    lp = {m.get("key"): m for m in (B.get("lampen") or []) if isinstance(m, dict)}
    out = []
    def achse(key, wert, leit, vergleich, stand, grau):
        w = _zahl(wert)
        out.append({"key": key, "name": dict(ACHSEN_NAMEN)[key], "kurz": ACHSEN_KURZ[key], "wert": (None if grau or w is None else float(_hu(max(0.0, min(100.0, w)), 0))),
                    "leit": leit, "vergleich": vergleich, "stand": stand, "grau": grau, "index": key in INDEX_ACHSEN})
    for key, mk, name in (("a1", "konten", "Kontenquote Binance"), ("a2", "oi", "Open Interest Binance")):
        m = mw.get(mk) or {}
        pz = _zahl(m.get("pz")); w = _zahl(m.get("wert"))
        mf = str(m.get("fehlt") or "").strip()                               # Grund des Cockpits, wenn es einen nennt
        grau = None if (pz is not None and w is not None) else (
            f"{name}: {mf}" if mf else (f"{name}: kein Wert." if w is None else f"{name}: für das Perzentil fehlt Verlauf (gebraucht werden 60 Tagesstände)."))
        leit = f"{name} {_de(w, 2) if mk == 'konten' else _tsd(w) + ' ' + coin}".strip() if w is not None else name
        out_stand = _dt(m.get("stand")) if m.get("stand") else (_tag_txt(m.get("stand_tag")) if m.get("stand_tag") else "—")
        achse(key, None if pz is None else pz * 100, leit, "Perzentil gegen die letzten 90 Tagesstände", out_stand, grau)
    a3 = LA.get("a3") or {}
    achse("a3", None if a3.get("pz") is None else a3["pz"] * 100,
          "Funding Binance, Mittel der letzten 7 Tage: " + (_de((a3.get("roh") or 0) * 100, 1, True) + " % im Jahr" if a3.get("roh") is not None else "—"),
          "Perzentil gegen die 365 Tage davor", _tag_txt(a3.get("tag")), a3.get("grau"))
    a4 = LA.get("a4") or {}
    achse("a4", None if a4.get("pz") is None else (1.0 - a4["pz"]) * 100,
          "Spot-Taker-Saldo Binance über 7 Tage: " + (_de((a4.get("roh") or 0) * 100, 2, True) + " % des Umsatzes" if a4.get("roh") is not None else "—"),
          "100 − Perzentil gegen die 365 Tage davor (schwache Nachfrage = hoher Wert)", _tag_txt(a4.get("tag")), a4.get("grau"))
    a5 = KA.get("a5") or {}
    achse("a5", None if a5.get("pz") is None else a5["pz"] * 100,
          ("Long-Liquidationen bis −5 %: " + _mio(a5.get("liq_usd")) + " = " + _de(a5.get("roh"), 1) + "-mal die Gebote bis −1 % (" + _mio(a5.get("tiefe_usd")) + ")"
           if a5.get("roh") is not None else "Long-Liquidationen bis −5 % gegen die Gebote bis −1 %")
          + (f"; erfasst sind {_de(a5['abdeckung'] * 100, 0)} % des Open Interest" if a5.get("abdeckung") is not None else ""),
          "Perzentil gegen die eigenen Stundenwerte", "live", a5.get("grau"))
    a6 = KA.get("a6") or {}
    achse("a6", None if a6.get("pz") is None else a6["pz"] * 100,
          "Gebote bis −1 % im Hyperliquid-Buch: " + (_mio(a6.get("roh")) if a6.get("roh") is not None else "—"),
          "100 − Perzentil gegen die Stundenwerte der letzten 30 Tage (dünnes Buch = hoher Wert)", "Mittel der letzten 60 Minuten", a6.get("grau"))
    a7 = LA.get("a7") or {}
    achse("a7", None if a7.get("pz") is None else a7["pz"] * 100,
          "Schwankung je Tag (σ): " + (_de((a7.get("roh") or 0) * 100, 2) + " %" if a7.get("roh") is not None else "—"),
          "Perzentil gegen die 365 Tage davor", _tag_txt(a7.get("tag")), a7.get("grau"))
    u = umfeld(lp, nb_stufe)
    achse("a8", u["wert"], "Umfeld: " + (", ".join(u["gruende"]) if u["gruende"] else ("nichts Besonderes" if not u["offen"] else "nichts Bekanntes")),
          "Stufen 0 · 33 · 66 · 100, kein Perzentil", "live",
          (("Lampe " if len(u["offen"]) == 1 else "Lampen ") + " und ".join(u["offen"]) + " grau -- ob das Umfeld belastet ist, ist nicht belegt.") if u["offen"] else None)
    out.sort(key=lambda a: a["key"])
    return out


def _mio(x) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    return (_de(v / 1e6, 1) + " Mio. USD") if abs(v) >= 1e6 else (_de(v / 1e3, 0) + " Tsd. USD")


def index_bauen(achsen: list) -> dict:
    """Druck-Index: Mittel der vorhandenen Achsen A1, A2, A3, A4, A7; mindestens vier."""
    w = [a["wert"] for a in achsen if a["key"] in INDEX_ACHSEN and a.get("wert") is not None]
    fehlen = [a["name"] for a in achsen if a["key"] in INDEX_ACHSEN and a.get("wert") is None]
    if len(w) < INDEX_MIN:
        return {"wert": None, "n": len(w), "fehlen": fehlen,
                "text": f"Druck-Index: kein Wert ({len(w)} von {len(INDEX_ACHSEN)} Achsen, gebraucht werden {INDEX_MIN}; es fehlen {', '.join(fehlen)})."}
    v = float(_hu(sum(w) / len(w), 0))
    return {"wert": v, "n": len(w), "fehlen": fehlen,
            "text": f"Druck-Index {_de(v, 0)} von 100 (Mittel aus {len(w)} Achsen" + (f"; ohne {', '.join(fehlen)}" if fehlen else "") + ") — gemessen, ungeprüft."}


def treiber_satz(achsen: list) -> str:
    """Die zwei höchsten Achsen in einem Satz."""
    da = sorted([a for a in achsen if a.get("wert") is not None], key=lambda a: (-a["wert"], a["key"]))
    if not da:
        return "Keine Achse hat einen Wert."
    if da[0]["wert"] <= 0:
        return "Keine Achse zeigt Druck (alle Werte bei 0, die übrigen grau)."
    return "Am höchsten: " + " und ".join(f"{a['name']} ({_de(a['wert'], 0)})" for a in da[:2] if a["wert"] > 0) + "."


def warnzeichen_bauen(B: dict) -> dict:
    """Kontenquote ≥ 3 (U142 H1, belegt) als eigene Zeile."""
    m = next((x for x in (B.get("messwerte") or []) if isinstance(x, dict) and x.get("key") == "konten"), {}) or {}
    w = _zahl(m.get("wert"))
    if w is None:
        return {"aktiv": None, "wert": None, "text": "Warnzeichen Kontenquote: kein Wert.", "beleg": BELEG_U142}
    aktiv = w >= KONTEN_AN
    return {"aktiv": aktiv, "wert": w, "beleg": BELEG_U142,
            "text": (f"Warnzeichen an: Kontenquote Binance {_de(w, 2)} (ab 3)." if aktiv else f"Warnzeichen aus: Kontenquote Binance {_de(w, 2)} (ab 3).")}


# ================================================================================================ Stand eines Coins

def stand(db: str, coin: str, jetzt: int | None = None, gemeinsam: dict | None = None, rb: dict | None = None, zust: dict | None = None,
          einst: dict | None = None, con_r=None) -> dict:
    """Alles für die Karte und den Alarm -- nur lesen. rb, zust, einst und con_r können mitgegeben werden (Takt), sonst liest die Funktion."""
    import hl_cockpit as HC
    jetzt = int(jetzt or time.time())
    if coin not in COINS:
        return {"ok": False, "coin": coin, "jetzt": jetzt, "fehlt": [f"Für {coin} rechnet das Risikoradar nicht (nur {', '.join(COINS)})."]}
    eigen = con_r is None
    if eigen:
        con_r = lesen(pfad(db))
    try:
        rb = rb if rb is not None else meta(con_r, "rueckblick")
        zust = zust if zust is not None else (meta(con_r, "zustand", {}) or {}).get(coin)
        einst = einst if einst is not None else einstellung_lesen(con_r)
        a5_hist = a5_verlauf(con_r, coin, jetzt)
    finally:
        if eigen and con_r is not None:
            con_r.close()
    G = gemeinsam if gemeinsam is not None else HC.gemeinsam_lesen(db, jetzt)
    Q = HC.quellen_lesen(db, coin, jetzt, gemeinsam=G)
    B = HC.bauen(Q)
    kurs = _zahl((Q.get("kurs") or {}).get("px")); kurs_ts = (Q.get("kurs") or {}).get("ts")
    kurs_frisch = bool(kurs and kurs_ts is not None and jetzt - int(kurs_ts) <= FRISCH_KURS_S)
    lauf = None; lauf_fehlt = None
    try:
        import hl_ausblick as AU
        ac = AU.lesen(AU.ausblick_pfad(db))
        if ac is None:
            lauf_fehlt = "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."
        else:
            try:
                lauf = AU.lauf_lesen(ac, coin)
            finally:
                ac.close()
    except Exception as e:  # noqa: BLE001
        lauf_fehlt = f"Ausblick: {type(e).__name__}: {e}"[:160]
    trend = None
    try:                                                                 # enthält die jüngste Rechnung einen Trend (eines der Tore des Ausblicks offen)?
        P = HC._prognose_lesen(db, coin)
        if P and lauf and int(P.get("anker") or 0) == int(lauf.get("anker") or -1):
            trend = ((P.get("richtung") or {}).get("mhat")) or None
    except Exception:  # noqa: BLE001 -- ohne lesbare Rechnung gibt es keinen Hinweis
        trend = None
    f = faktor(db, coin, jetzt)
    LA = lange_achsen(db, coin, jetzt)
    con = HC._ro(db)
    try:
        T = tiefe_lesen(con, coin, jetzt)
    finally:
        if con is not None:
            con.close()
    KA = kurze_achsen(Q.get("liqdichte"), kurs, kurs_frisch, T, a5_hist, jetzt, HC.FRISCH_LIQ_S)
    nb = None
    try:
        import hl_notbremse as NB
        nb = NB.banner_daten(db, jetzt).get("stufe")
    except Exception:  # noqa: BLE001 -- ohne Notbremse zählt sie in A8 nicht
        nb = None
    return stand_bauen(coin, jetzt, kurs, kurs_ts, kurs_frisch, lauf, lauf_fehlt, f, rb, zust, einst, B, LA, KA, nb, trend)


def trend_satz(mhat: dict | None) -> str | None:
    """
    Hinweis, wenn die jüngste Rechnung des Ausblicks einen Trend enthält (eines seiner Tore ist offen; m̂ je Horizont in üblichen
    Schwankungen des Horizonts). Der Rückblick des Radars rechnet ohne Trend (wie S3 des Ausblicks) -- das soll dastehen.
    """
    if not isinstance(mhat, dict):
        return None
    teile = []
    for h, v in sorted(mhat.items(), key=lambda kv: int(kv[0]) if str(kv[0]).isdigit() else 0):
        w = _zahl(v)
        if w is not None and _hu(w, 2) != 0:
            teile.append(f"{h} Tage {_de(w, 2, True)} σ")
    if not teile:
        return None
    return ("Die jüngste Rechnung des Ausblicks enthält einen Trend (" + ", ".join(teile) + "); er steckt in beiden Zahlen. "
            "Der Rückblick des Radars hat die Zahlen ohne Trend geprüft.")


def stand_bauen(coin: str, jetzt: int, kurs, kurs_ts, kurs_frisch: bool, lauf, lauf_fehlt, f: dict, rb, zust, einst: dict, B: dict, LA: dict,
                KA: dict, nb, trend: dict | None = None) -> dict:
    """Der Stand eines Coins aus seinen Teilen -- ohne Zugriff auf Dateien (die Proben bauen ihn von Hand)."""
    E = ereignisse_bauen(coin, lauf, lauf_fehlt, f, kurs, kurs_frisch, jetzt, rb, zust, (einst or EINSTELLUNG_VORGABE)["pz"])
    achsen = achsen_bauen(B, LA, KA, nb, coin)
    idx = index_bauen(achsen)
    return {"ok": True, "coin": coin, "jetzt": int(jetzt), "version": VERSION_MODUL,
            "kurs": {"px": kurs, "ts": kurs_ts, "frisch": bool(kurs_frisch)}, "faktor": f, "ereignis": E, "achsen": achsen, "index": idx,
            "treiber": treiber_satz(achsen), "warnzeichen": warnzeichen_bauen(B), "a5_roh": KA["a5"].get("roh"), "a6_roh": KA["a6"].get("roh"),
            "rueckblick_stand": (rb or {}).get("stand"), "trend": trend_satz(trend)}


# ================================================================================================ Alarm (Abschnitt 6)

def meldung_bauen(art: str, S: dict, key: str | None) -> dict:
    """Titel, Text und Ansage einer Meldung. Kein Pfeil, kein Empfehlungswort; Thema und Schlüssel kommen hier nicht vor."""
    coin = S["coin"]
    hoechste = [a for a in sorted([a for a in S.get("achsen") or [] if a.get("wert") is not None], key=lambda a: (-a["wert"], a["key"]))][:2]
    achsen_txt = ("Höchste Achsen: " + ", ".join(f"{a['name']} {_de(a['wert'], 0)}" for a in hoechste) + ". ") if hoechste else ""
    wz = S.get("warnzeichen") or {}
    wz_txt = (f"Warnzeichen: Kontenquote {_de(wz.get('wert'), 2)}. " if wz.get("aktiv") else "")
    stand_txt = f"Stand {_orts(S.get('jetzt'))}."
    if art == "hinweis":
        return {"art": art, "coin": coin, "ereignis": None, "p": None, "prio": 3, "titel": f"Risikoradar {coin}: Warnzeichen Kontenquote",
                "text": (f"Kontenquote Binance {_de(wz.get('wert'), 2)} (ab 3). In solchen Lagen folgte in 7 Tagen häufiger ein Rücksetzer "
                         f"(U142: 20,3 % gegen 7,3 %). {stand_txt}"),
                "ansage": None}
    e = (S.get("ereignis") or {}).get(key) or {}
    zahl = f"−{e.get('x_text')} in {e.get('frist')}: {e.get('p_text')}" + (f" (üblich {p_text(e['grundrate'])})" if e.get("grundrate") is not None else "")
    if art == "entwarnung":
        return {"art": art, "coin": coin, "ereignis": key, "p": e.get("p"), "prio": 2, "titel": f"Risikoradar {coin}: nicht mehr hoch",
                "text": f"{zahl}. Die Stufe „hoch“ ist beendet. {stand_txt}", "ansage": None}
    pz = _zahl(e.get("p"))
    proz = (_de(pz * 100, 1) if pz is not None and _hu(pz * 100, 1) < 10 else _de((pz or 0) * 100, 0)).replace(",", " Komma ")
    x_an = str(e.get("x_text") or "").replace(" %", "").replace(",", " Komma ")
    return {"art": "alarm", "coin": coin, "ereignis": key, "p": e.get("p"), "prio": 5, "titel": f"Risikoradar {coin}: Risiko hoch",
            "text": f"{zahl}. {achsen_txt}{wz_txt}{stand_txt}",
            "ansage": f"Risikoradar. {NAMEN.get(coin, coin)}. Risiko hoch. {proz} Prozent für minus {x_an} Prozent in {e.get('frist')}."}


def alarm_schritt(Z: dict | None, S: dict, jetzt: int, melden: bool = True) -> tuple:
    """
    Ein Schritt der Zustände eines Coins. Z = {e7: {hoch, seit, alarm_ts, gemeldet}, e2: …, konten: {scharf, hinweis_ts}}.
    -> (neuer Zustand, Meldungen). Ohne Zahl oder ohne Stufe bleibt der Zustand, wie er ist (eine Lücke löst nichts aus und beendet nichts).
    melden=False (der Coin ist nicht für Meldungen gewählt): „hoch“ und die Kontenquote laufen mit, aber nichts gilt als gemeldet --
    keine Sperrzeit aus einem Alarm, den es nicht gab, und später keine Entwarnung ohne Alarm.
    """
    Z = json.loads(json.dumps(Z)) if isinstance(Z, dict) else {}
    M = []
    jetzt = int(jetzt)
    for key in EREIGNIS:
        z = Z.setdefault(key, {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False})
        e = (S.get("ereignis") or {}).get(key) or {}
        if e.get("stufe") in (None, "ohne"):
            continue
        ist = e["stufe"] == "hoch"
        if ist and not z.get("hoch"):
            z["hoch"] = True; z["seit"] = jetzt; z["gemeldet"] = False
            if melden and jetzt - int(z.get("alarm_ts") or 0) >= SPERRZEIT_S:
                z["alarm_ts"] = jetzt; z["gemeldet"] = True
                M.append(meldung_bauen("alarm", S, key))
        elif z.get("hoch") and not ist:
            z["hoch"] = False; z["seit"] = None
            if melden and z.get("gemeldet"):
                M.append(meldung_bauen("entwarnung", S, key))
            z["gemeldet"] = False
    k = Z.setdefault("konten", {"scharf": None, "hinweis_ts": 0})
    w = _zahl((S.get("warnzeichen") or {}).get("wert"))
    if w is not None:
        if w < KONTEN_AUS:
            k["scharf"] = True
        elif w >= KONTEN_AN:
            if k.get("scharf"):
                if melden and jetzt - int(k.get("hinweis_ts") or 0) >= HINWEIS_SPERRE_S:
                    k["hinweis_ts"] = jetzt
                    M.append(meldung_bauen("hinweis", S, None))
            k["scharf"] = False
        elif k.get("scharf") is None:
            k["scharf"] = False
    return Z, M


def push_einstellung() -> dict:
    """{"thema", "server"} der Benachrichtigung (hl_berichte); das Thema verlässt diese Funktion nur in Richtung senden()."""
    try:
        import hl_berichte as HBR
        return HBR.einstellung_lesen()
    except Exception:  # noqa: BLE001
        return {"thema": "", "server": ""}


def meldungen_ablegen(con, M: list, einst: dict, jetzt: int, eingerichtet: bool) -> list:
    """Meldungen in rd_alarm eintragen. Push ist offen, wenn der Schalter an, das Thema eingerichtet und der Coin gewählt ist."""
    ids = []
    for m in M:
        gewaehlt = m["coin"] in (einst.get("coins") or [])
        push = PUSH_OFFEN if (gewaehlt and einst.get("push") and eingerichtet) else PUSH_AUS
        if not gewaehlt:
            continue                                                     # Zustand läuft mit, gemeldet wird nur für gewählte Coins
        cur = con.execute("INSERT INTO rd_alarm (ts, coin, ereignis, art, p, titel, text, ansage, prio, push) VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (int(jetzt), m["coin"], m.get("ereignis"), m["art"], m.get("p"), m["titel"], m["text"], m.get("ansage"), int(m["prio"]), push))
        ids.append(cur.lastrowid)
    return ids


def push_senden(con, jetzt: int, http_fn=None, einstellung: dict | None = None) -> dict:
    """Offene Meldungen senden (höchstens fünf Versuche, binnen einer Stunde); Fehlertexte ohne Thema."""
    out = {"gesendet": 0, "fehler": 0, "aufgegeben": 0}
    offen = con.execute("SELECT id, ts, titel, text, prio, versuche FROM rd_alarm WHERE push=? ORDER BY id", (PUSH_OFFEN,)).fetchall()
    if not offen:
        return out
    ein = einstellung if einstellung is not None else push_einstellung()
    import hl_berichte as HBR
    for id_, ts, titel, text_, prio, versuche in offen:
        if int(jetzt) - int(ts) > PUSH_FRIST_S or int(versuche or 0) >= PUSH_VERSUCHE or not ein.get("thema"):
            con.execute("UPDATE rd_alarm SET push=?, push_fehler=COALESCE(push_fehler, ?) WHERE id=?",
                        (PUSH_AUFGEGEBEN, "nicht gesendet (Frist, Versuche oder Benachrichtigung nicht eingerichtet)", id_))
            out["aufgegeben"] += 1; continue
        try:
            kw = {"prio": int(prio), "tags": ("rotating_light",) if int(prio) >= 5 else ("information_source",)}
            if http_fn is not None:
                kw["http_fn"] = http_fn
            ok, info = HBR.senden(ein["thema"], titel, text_, ein.get("server") or HBR.NTFY_SERVER, **kw)[:2]
        except Exception as e:  # noqa: BLE001
            ok, info = False, type(e).__name__
        if ok:
            con.execute("UPDATE rd_alarm SET push=?, versuche=versuche+1, push_fehler=NULL WHERE id=?", (PUSH_GESENDET, id_)); out["gesendet"] += 1
        else:
            fehler = str(info or "Fehler")[:160].replace(ein.get("thema") or "\x00", "…")
            con.execute("UPDATE rd_alarm SET versuche=versuche+1, push_fehler=? WHERE id=?", (fehler, id_)); out["fehler"] += 1
    return out


# ================================================================================================ Takt

_TAKT = {"gestartet": False, "stop": None, "proc": None, "letzter_rueckblick_start": 0.0, "fehler": None, "schritte": 0}


class RbSperre:
    """
    Ein Rückblick zur selben Zeit (der Takt des Dashboards und Debug 161 können ihn beide anstoßen): flock auf
    <radar.db>.rueckblick.lock. Der Kernel gibt die Sperre frei, wenn der Prozess endet -- auch nach einem Abbruch; es bleibt nichts
    hängen. Wo es fcntl nicht gibt oder die Datei nicht sperrbar ist, rechnet der Lauf ohne Sperre (doppelt rechnen ist nur Zeit).
    """

    def __init__(self, db: str):
        self.datei = pfad(db) + ".rueckblick.lock"
        self.fd = None

    def nehmen(self) -> bool:
        try:
            import fcntl
        except ImportError:
            return True
        try:
            self.fd = os.open(self.datei, os.O_CREAT | os.O_RDWR, 0o644)
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:                                          # ein anderer Lauf hält sie
            os.close(self.fd); self.fd = None
            return False
        except OSError:
            if self.fd is not None:
                os.close(self.fd); self.fd = None
            return True

    def lassen(self) -> None:
        if self.fd is not None:
            try:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_UN)
            except (ImportError, OSError):
                pass
            os.close(self.fd); self.fd = None


def rueckblick_faellig(rb: dict | None, jetzt: float, letzter_start: float) -> bool:
    if jetzt - letzter_start < RUECKBLICK_WIEDER_S:
        return False
    return (not isinstance(rb, dict)) or rb.get("version") != VERSION_MODUL or jetzt - float(rb.get("stand") or 0) > RUECKBLICK_MAX_ALTER_S


def _starte_rueckblick(db: str) -> bool:
    """Der Rückblick rechnet in einem eigenen Prozess; er senkt seine Priorität selbst (wie hl_ausblick seit 23.114, ohne preexec_fn)."""
    import subprocess
    import hl_ausblick as AU
    p = _TAKT.get("proc")
    if p is not None and p.poll() is None:
        return False
    log = os.path.join(os.path.dirname(pfad(db)), "radar_takt.log")
    try:
        if os.path.exists(log) and os.path.getsize(log) > 1_000_000:
            os.replace(log, log + ".1")
        f = open(log, "a")
        f.write(f"[{time.strftime('%d.%m. %H:%M:%S')}] Start Rückblick\n"); f.flush()
        _TAKT["proc"] = subprocess.Popen([sys.executable, os.path.abspath(__file__), "--rueckblick", "--db", db], stdout=f,
                                         stderr=subprocess.STDOUT, env=AU.kind_umgebung(), cwd=os.path.dirname(os.path.abspath(__file__)))
        f.close()
    except OSError as e:
        _TAKT["fehler"] = f"{type(e).__name__}: {e}"
        return False
    _TAKT["letzter_rueckblick_start"] = time.time()
    return True


def takt_schritt(db: str, con, jetzt: int | None = None, http_fn=None, push_ein: dict | None = None, starte_rb=None, stand_fn=None,
                 gemeinsam_fn=None) -> dict:
    """
    Ein Schritt: Stand je Coin (gewählte Coins jedes Mal, alle zur vollen Stunde), Zustände und Meldungen, Ablage je Stunde, Push.
    Fehler eines Coins bleiben im Ergebnis stehen, die anderen laufen weiter.
    """
    jetzt = int(jetzt or time.time())
    if gemeinsam_fn is None:
        import hl_cockpit as HC
        gemeinsam_fn = HC.gemeinsam_lesen
    stand_fn = stand_fn or stand
    out = {"coins": [], "meldungen": 0, "abgelegt": 0, "fehler": [], "rueckblick_gestartet": False}
    rb = meta(con, "rueckblick")
    if rueckblick_faellig(rb, jetzt, _TAKT["letzter_rueckblick_start"]):
        out["rueckblick_gestartet"] = bool((starte_rb or _starte_rueckblick)(db))
        if out["rueckblick_gestartet"]:
            _TAKT["letzter_rueckblick_start"] = float(jetzt)
    einst = einstellung_lesen(con)
    Zalle = meta(con, "zustand", {}) or {}
    stunde = jetzt // ABLAGE_S
    letzte = int(meta(con, "letzte_ablage", 0) or 0)
    alle = stunde > letzte
    coins = COINS if alle else tuple(c for c in COINS if c in einst["coins"])
    ein = push_ein if push_ein is not None else push_einstellung()
    G = None
    for coin in coins:
        try:
            G = G if G is not None else gemeinsam_fn(db, jetzt)
            S = stand_fn(db, coin, jetzt, gemeinsam=G, rb=rb or {}, zust=Zalle.get(coin) or {}, einst=einst, con_r=con)
            if not S.get("ok"):
                out["fehler"].append(f"{coin}: {' '.join(S.get('fehlt') or [])}"); continue
            Z, M = alarm_schritt(Zalle.get(coin), S, jetzt, melden=coin in einst["coins"])
            Zalle[coin] = Z
            out["meldungen"] += len(meldungen_ablegen(con, M, einst, jetzt, bool(ein.get("thema"))))
            if alle:
                kurz = {"e": {k: {"p": e.get("p"), "stufe": e.get("stufe"), "x": e.get("x")} for k, e in S["ereignis"].items()},
                        "achsen": {a["key"]: a.get("wert") for a in S["achsen"]}, "konten": (S.get("warnzeichen") or {}).get("wert"),
                        "kurs": S["kurs"].get("px")}
                con.execute("INSERT OR REPLACE INTO rd_stand VALUES (?,?,?,?,?,?,?,?,?)",
                            (stunde, coin, jetzt, S["ereignis"]["e7"].get("p"), S["ereignis"]["e2"].get("p"), S["index"].get("wert"),
                             S.get("a5_roh"), S.get("a6_roh"), json.dumps(_ohne_nan(kurz), ensure_ascii=False)))
                out["abgelegt"] += 1
            out["coins"].append(coin)
        except Exception as e:  # noqa: BLE001 -- ein Coin darf den Takt nicht anhalten
            out["fehler"].append(f"{coin}: {type(e).__name__}: {e}"[:200])
    meta_setzen(con, "zustand", Zalle)
    if alle:
        meta_setzen(con, "letzte_ablage", stunde)
    out["push"] = push_senden(con, jetzt, http_fn=http_fn, einstellung=ein)
    meta_setzen(con, "takt", {"ts": jetzt, "coins": out["coins"], "fehler": out["fehler"][:5]})
    _TAKT["schritte"] += 1
    return out


def starte(db: str, stop: threading.Event | None = None, verzoegerung: float = 90.0, schritt=None, takt_s: float = TAKT_S):
    """
    Eigener Faden „radar“ im Dashboard-Prozess: nach 90 s der erste Schritt, dann alle 5 Minuten. Aus mit HL_RADAR=0. Ein Fehler
    (Laufwerk nicht eingehängt, Datenbank gesperrt) beendet den Faden nicht: Er meldet ihn in der Ausgabe des Dashboards und versucht
    es beim nächsten Schritt wieder -- nach einem Fehler der Datenbank mit einer neuen Verbindung.
    """
    if os.environ.get("HL_RADAR", "1") == "0" or not db or db == ":memory:":
        return None
    stop = stop or threading.Event()
    schritt = schritt or takt_schritt

    def lauf():
        if stop.wait(verzoegerung):
            return
        con = None
        while not stop.is_set():
            try:
                if con is None:
                    con = verbinden(pfad(db))
                schritt(db, con)
                _TAKT["fehler"] = None
            except Exception as e:  # noqa: BLE001 -- der Faden läuft weiter
                _TAKT["fehler"] = f"{type(e).__name__}: {e}"[:200]
                print("Risikoradar: " + _TAKT["fehler"], flush=True)
                if isinstance(e, sqlite3.Error) and con is not None:
                    try:
                        con.close()
                    except sqlite3.Error:
                        pass
                    con = None
            stop.wait(takt_s)
        if con is not None:
            try:
                con.close()
            except sqlite3.Error:
                pass

    t = threading.Thread(target=lauf, name="radar", daemon=True)
    t.start()
    return t


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen. Nicht für Selbsttest-Datenbanken; aus mit HL_RADAR=0."""
    if _TAKT["gestartet"] or os.path.basename(db or "").startswith("_selftest"):
        return False
    stop = threading.Event()
    if starte(db, stop=stop) is None:                                    # HL_RADAR=0 oder keine Datenbank: nichts gestartet, nichts gemerkt
        return False
    _TAKT["gestartet"] = True
    _TAKT["stop"] = stop
    return True


# ================================================================================================ Rückblick des Grundrisikos (Abschnitt 3)

def grundrate_laufend(tau: np.ndarray, ja: np.ndarray, h_tage: int, mind: int = GRUNDRATE_MIN) -> np.ndarray:
    """g(τ) je Ursprung eines Coins (tau aufsteigend): Anteil der früheren Ursprünge mit eingetretenem Ereignis, deren Frist bei τ
    abgelaufen war (τ' + h Tage ≤ τ); unter `mind` solchen Ursprüngen NaN."""
    tau = np.asarray(tau, dtype=np.int64); ja = np.asarray(ja, dtype=float)
    cs = np.concatenate([[0.0], np.cumsum(ja)])
    k = np.searchsorted(tau, tau - int(h_tage) * TAG, side="right")
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(k >= mind, cs[k] / np.maximum(k, 1), np.nan)


def rueckblick_coin(A: dict, Fk: np.ndarray, B: dict, f_fn, je_tag: int, oos_ab: int) -> dict:
    """
    Beide Zahlen an jedem Tagesursprung (00:00 UTC) ab `oos_ab` nachrechnen -- mit den Szenarien des Ausblicks (hl_ausblick.szenarien:
    Tief = (ZL − m̄) · √F, ohne Drift), nur aus Fenstern der Bibliothek, die vor τ vollständig abgelaufen waren. f_fn(Tag) gibt den
    Faktor des Monats oder None. Jede Zahl ist wie in der Anzeige auf das Raster der abgelegten Verteilung begrenzt (0,5 % bis 99,5 %):
    Erreicht kein Szenario die Schwelle, zählt der Ursprung mit 0,5 % -- so wie die Karte dann „unter 0,5 %“ zeigt.
    -> {tau, p7, p2, ja7, ja2, ohne_bib, ohne_faktor}
    """
    import hl_ausblick as AU
    p_min, p_max = float(AU.LAUF_Q[0]), float(AU.LAUF_Q[-1])
    tau = np.asarray(A["tau"], dtype=np.int64); n = int(A["n"])
    with np.errstate(invalid="ignore", divide="ignore"):
        lc = np.log(np.asarray(A["C"], dtype=float)); ll = np.log(np.asarray(A["L"], dtype=float))
    order = np.argsort(B["ende"], kind="stable"); ende = np.asarray(B["ende"])[order]
    Z7 = np.asarray(B["Z"])[order][:, :7].astype(float); ZL7 = np.asarray(B["ZL"])[order][:, :7].astype(float)
    cz = np.cumsum(Z7, axis=0)
    rec = {k: [] for k in ("tau", "p7", "p2", "ja7", "ja2")}
    ohne_bib = ohne_faktor = 0
    x7, x2 = EREIGNIS["e7"]["x"], EREIGNIS["e2"]["x"]
    for j in range(n):
        t = int(tau[j])
        if t < oos_ab or t % TAG:
            continue
        if j + je_tag * 7 >= n:
            break
        k = int(np.searchsorted(ende, t - TAG, side="right"))
        if k < BIB_MIN or not np.all(np.isfinite(Fk[j, :7])) or not np.isfinite(lc[j]):
            ohne_bib += 1; continue
        f = f_fn(t // TAG)
        if f is None or EREIGNIS["e7"]["x"] * f >= 0.9:
            ohne_faktor += 1; continue
        lo = (ZL7[:k] - cz[k - 1] / k) * np.sqrt(Fk[j, :7])
        d7 = math.log(1 - x7 * f); d2 = math.log(1 - x2 * f)
        tief = ll[j + je_tag: j + je_tag * 7 + 1: je_tag] - lc[j]
        if not np.isfinite(tief).any():
            ohne_bib += 1; continue
        rec["tau"].append(t)
        rec["p7"].append(min(max(float(np.mean(lo.min(axis=1) <= d7)), p_min), p_max))
        rec["p2"].append(min(max(float(np.mean(lo[:, :2].min(axis=1) <= d2)), p_min), p_max))
        rec["ja7"].append(float(np.nanmin(tief) <= d7))
        rec["ja2"].append(float(np.nanmin(tief[:2]) <= d2) if np.isfinite(tief[:2]).any() else float("nan"))
    out = {k: np.array(v, dtype=(np.int64 if k == "tau" else float)) for k, v in rec.items()}
    out["ohne_bib"] = ohne_bib; out["ohne_faktor"] = ohne_faktor
    return out


def g_urteil(key: str, tau, coin_i, p, ja, g, seed: int = 0) -> dict:
    """Urteil G7 bzw. G2 über alle Coins: Brier-Skill gegen die laufende Grundrate, Steigung, Zuverlässigkeit, Block-Bootstrap."""
    import hl_ausblick as AU
    import hl_aktien as AK
    tau = np.asarray(tau, dtype=np.int64); p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float); g = np.asarray(g, dtype=float)
    ok = np.isfinite(p) & np.isfinite(g) & np.isfinite(ja)
    out = {"n": int(ok.sum()), "n_tage": 0, "n_ereignisse": 0, "brier": None, "brier_grund": None, "skill": None, "steigung": None, "p": None,
           "zuverlaessigkeit": [], "besteht": False, "grund": None, "von": None, "bis": None, "je_coin": {}, "niveau": None}
    if not ok.any():
        out["grund"] = "keine auswertbaren Ursprünge"; return out
    t, p_, y, g_ = tau[ok], p[ok], ja[ok], g[ok]
    tage, inv = np.unique(t // TAG, return_inverse=True)
    out["n_tage"] = int(len(tage)); out["n_ereignisse"] = int(y.sum()); out["von"] = int(t.min()); out["bis"] = int(t.max())
    bp = float(np.mean((p_ - y) ** 2)); bg = float(np.mean((g_ - y) ** 2))
    out["brier"] = bp; out["brier_grund"] = bg; out["skill"] = (1 - bp / bg) if bg > 0 else None
    out["steigung"] = float(AU.logit_steigung(y, p_))
    out["niveau"] = float(p_.mean() / y.mean()) if y.mean() > 0 else None
    d = (g_ - y) ** 2 - (p_ - y) ** 2
    f = np.bincount(inv, weights=d) / np.maximum(np.bincount(inv), 1)
    bt = AU.boot_p(f, G_BLOCK, G_BOOT, seed)
    out["p"] = bt.get("p")
    for a, b in zip(ZUV_KLASSEN[:-1], ZUV_KLASSEN[1:]):
        m = (p_ >= a) & (p_ < b)
        if m.any():
            lo, hi = AK.wilson(int(y[m].sum()), int(m.sum()), 1.645)
            out["zuverlaessigkeit"].append([a, min(b, 1.0), int(m.sum()), float(p_[m].mean()), float(y[m].mean()), lo, hi])
    ci = np.asarray(coin_i)[ok]
    for c in np.unique(ci):
        m = ci == c
        out["je_coin"][str(c)] = {"n": int(m.sum()), "ereignisse": int(y[m].sum()), "p": float(p_[m].mean()), "quote": float(y[m].mean())}
    sk, st, pw, nv = out["skill"], out["steigung"], out["p"], out["niveau"]
    if out["n_tage"] < G_MIN_TAGE or out["n_ereignisse"] < G_MIN_EREIGNISSE:
        out["grund"] = (f"zu wenig Historie für ein Urteil ({out['n_tage']} Ursprungstage, {out['n_ereignisse']} Ereignisse; "
                        f"gebraucht werden {G_MIN_TAGE} und {G_MIN_EREIGNISSE})")
    elif sk is None or not sk > 0 or pw is None or not math.isfinite(pw) or not pw < G_ALPHA:
        out["grund"] = (f"die Zahl trifft nicht belegbar besser als die Grundrate (Skill {_de((sk or 0) * 100, 1, True)} %, "
                        f"{p_wert_text(pw)}; verlangt ist p unter {_de(G_ALPHA, 2)})")
    elif not math.isfinite(st) or not G_STEIGUNG[0] <= st <= G_STEIGUNG[1]:
        out["grund"] = (f"Steigung {_de(st, 2)} außerhalb von {_de(G_STEIGUNG[0], 1)} bis {_de(G_STEIGUNG[1], 1)} "
                        + ("(die Zahl schlägt zu stark aus)" if math.isfinite(st) and st < G_STEIGUNG[0] else "(die Zahl schlägt zu schwach aus)"))
    elif nv is None or not G_NIVEAU[0] <= nv <= G_NIVEAU[1]:
        out["grund"] = (f"Niveau: die Zahl lag im Mittel beim {_de(nv, 2)}-Fachen der eingetretenen Quote "
                        f"(zulässig {_de(G_NIVEAU[0], 1)} bis {_de(G_NIVEAU[1], 2)})")
    else:
        out["besteht"] = True
    return out


def schwellen_bauen(p, ja) -> dict:
    """Grundrate und Perzentile der Rückblick-Werte eines Coins für ein Ereignis."""
    p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float)
    ok = np.isfinite(p) & np.isfinite(ja)
    if ok.sum() < GRUNDRATE_MIN:
        return {"n": int(ok.sum()), "grundrate": None, "q": {}, "niveau": None}
    gr = float(ja[ok].mean())
    return {"n": int(ok.sum()), "grundrate": gr, "q": {_qk(q): float(np.quantile(p[ok], q)) for q in PZ_ABLAGE},
            "niveau": (float(p[ok].mean()) / gr if gr > 0 else None)}


def alarm_tabelle(tau, p, ja, s_hoch) -> dict:
    """
    Beschreibend: die Regel aus Abschnitt 6 auf den Tageswerten des Rückblicks. Eintritte in „hoch“ (Beginn bei p ≥ Schwelle, Ende unter
    0,8 · Schwelle), Eintritte je Jahr, Anteil der Eintritte, nach denen das Ereignis in der Frist kam, und Anteil der Ereignis-Episoden
    (aufeinanderfolgende Ursprungstage mit Ereignis), in denen das Radar an mindestens einem Tag auf „hoch“ stand.
    """
    tau = np.asarray(tau, dtype=np.int64); p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float)
    s = _zahl(s_hoch)
    out = {"schwelle": s, "eintritte": 0, "je_jahr": None, "treffer": 0, "episoden": 0, "gedeckt": 0, "tage_hoch": 0, "n": int(len(tau))}
    if s is None or len(tau) < 2:
        return out
    hoch = False; zust = np.zeros(len(tau), dtype=bool); ein = []
    for i in range(len(tau)):
        if np.isfinite(p[i]):
            if not hoch and p[i] >= s:
                hoch = True; ein.append(i)
            elif hoch and p[i] < HYSTERESE * s:
                hoch = False
        zust[i] = hoch
    out["eintritte"] = len(ein); out["tage_hoch"] = int(zust.sum())
    jahre = (int(tau[-1]) - int(tau[0])) / (365.25 * TAG)
    out["je_jahr"] = len(ein) / jahre if jahre > 0 else None
    out["treffer"] = int(sum(1 for i in ein if ja[i] == 1))
    i = 0
    while i < len(tau):
        if ja[i] == 1:
            j = i
            while j + 1 < len(tau) and ja[j + 1] == 1 and tau[j + 1] - tau[j] <= TAG:
                j += 1
            out["episoden"] += 1; out["gedeckt"] += int(zust[i:j + 1].any())
            i = j + 1
        else:
            i += 1
    return out


def rueckblick_auswerten(R: dict) -> dict:
    """Aus den Ursprüngen je Coin ({coin: rueckblick_coin}) die beiden Urteile, Grundraten, Schwellen und die Tabelle der Alarme."""
    out = {"urteil": {}, "coins": {}, "ohne": {}}
    for key, E in EREIGNIS.items():
        pk, jk = ("p7", "ja7") if key == "e7" else ("p2", "ja2")
        tau = []; ci = []; p = []; ja = []; g = []
        for coin, r in R.items():
            if not len(r["tau"]):
                continue
            ok = np.isfinite(r[jk])
            gl = np.full(len(r["tau"]), np.nan)
            gl[ok] = grundrate_laufend(r["tau"][ok], r[jk][ok], E["tage"])
            tau.append(r["tau"]); ci.append(np.full(len(r["tau"]), coin)); p.append(r[pk]); ja.append(r[jk]); g.append(gl)
            sw = schwellen_bauen(r[pk], r[jk])
            sw["alarme"] = alarm_tabelle(r["tau"][ok], r[pk][ok], r[jk][ok], (sw.get("q") or {}).get(_qk(PZ_HOCH)))
            out["coins"].setdefault(coin, {})[key] = sw
            out["ohne"][coin] = {"bibliothek": int(r.get("ohne_bib") or 0), "faktor": int(r.get("ohne_faktor") or 0)}
        if tau:
            out["urteil"][key] = g_urteil(key, np.concatenate(tau), np.concatenate(ci), np.concatenate(p), np.concatenate(ja),
                                          np.concatenate(g), seed=7 if key == "e7" else 2)
        else:
            out["urteil"][key] = {"n": 0, "n_tage": 0, "n_ereignisse": 0, "besteht": False, "grund": "keine Ursprünge (der Ausblick hat keine Historie geliefert)"}
    return out


def rueckblick_rechnen(db: str, log=print, jetzt: int | None = None, schreiben: bool = True) -> dict:
    """
    Der Lauf von Debug 161: Daten des Ausblicks laden, je Coin nachrechnen, auswerten, in radar.db ablegen (rd_meta „rueckblick“).
    Rechnet schon ein anderer Lauf (RbSperre), rechnet dieser nicht: -> {"laeuft": True}.
    """
    sperre = RbSperre(db) if schreiben else None
    if sperre is not None and not sperre.nehmen():
        return {"laeuft": True}
    try:
        return _rueckblick_rechnen(db, log, jetzt, schreiben)
    finally:
        if sperre is not None:
            sperre.lassen()


def rueckblick_holen(db: str, log=print, warten_s: float = RUECKBLICK_WARTEN_S, schlaf=time.sleep, uhr=time.time, rechnen=None) -> tuple:
    """
    Für Debug 161: den gespeicherten Rückblick dieser Fassung lesen; fehlt er, rechnen; rechnet schon ein anderer Lauf, auf ihn warten
    (höchstens warten_s). -> (Rückblick oder None, gerechnet: bool, gewartet: bool).
    """
    rechnen = rechnen or rueckblick_rechnen
    ende = uhr() + float(warten_s)
    gewartet = False
    while True:
        con = lesen(pfad(db))
        try:
            rb = meta(con, "rueckblick")
        finally:
            if con is not None:
                con.close()
        if isinstance(rb, dict) and rb.get("version") == VERSION_MODUL:
            return rb, False, gewartet
        if not gewartet:
            log("Der Rückblick fehlt oder stammt von einer anderen Fassung -- dieser Lauf rechnet ihn jetzt.")
        r = rechnen(db, log=log)
        if not r.get("laeuft"):
            return r, True, gewartet
        if not gewartet:
            log(f"Ein anderer Lauf (der Takt des Dashboards) rechnet ihn gerade -- dieser Lauf wartet bis zu {int(warten_s) // 60} Minuten.")
        if uhr() >= ende:
            return None, False, True
        gewartet = True
        schlaf(5)


def _rueckblick_rechnen(db: str, log, jetzt: int | None, schreiben: bool) -> dict:
    import hl_ausblick as AU
    t0 = time.time(); jetzt = int(jetzt or time.time())
    G = AU.lade(db, log=lambda *a: None)
    wahl = None
    ac = AU.lesen(AU.ausblick_pfad(db))
    if ac is not None:
        try:
            wahl = AU._json_meta(ac, "breite_wahl", None)
        finally:
            ac.close()
    V = {}
    for c in AU.COINS:
        if c in G["coins"]:
            v = AU.vorbereiten(c, G, wahl)
            if v is not None:
                V[c] = v
    K = kerzen_lesen(db, COINS)
    rend = {c: _renditen_je_tag(K[c]["tag"], K[c]["c"]) for c in K}
    R = {}; fehlt = list(G.get("fehlt") or [])
    if "BTC" not in rend:
        fehlt.append("hebel.db: keine Tagesschlüsse für BTC -- ohne sie gibt es keinen Faktor und keinen Rückblick")
    for coin in COINS:
        if coin not in V:
            fehlt.append(f"{coin}: keine Historie im Ausblick"); continue
        B, bart = AU.bibliothek_fuer(coin, V)
        if B is None or not len(B["ende"]):
            fehlt.append(f"{coin}: keine Bibliothek ({bart})"); continue
        fm: dict = {}
        def f_fn(tag, coin=coin, fm=fm):
            st = monatserster(tag)
            if st not in fm:
                fm[st] = faktor_rechnen(coin, rend.get(coin), rend.get("BTC"), st)["f"] if (coin == "BTC" or "BTC" in rend) else None
            return fm[st]
        R[coin] = rueckblick_coin(V[coin]["A"], V[coin]["Fk"], B, f_fn, AU.JE_TAG, AU.OOS_AB)
        log(f"  {coin}: {len(R[coin]['tau'])} Ursprünge, Bibliothek {bart}; ausgelassen {R[coin]['ohne_bib']} (Bibliothek oder Prognose), "
            f"{R[coin]['ohne_faktor']} (Faktor)")
    erg = rueckblick_auswerten(R)
    erg.update({"stand": jetzt, "version": VERSION_MODUL, "dauer": time.time() - t0, "fehlt": fehlt, "breite_wahl": wahl,
                "ausblick_version": getattr(AU, "VERSION_MODUL", None)})
    if schreiben:
        con = verbinden(pfad(db))
        try:
            meta_setzen(con, "rueckblick", erg)
        finally:
            con.close()
    return erg


def rueckblick_text(rb: dict | None) -> str:
    """Debug 161 als Text."""
    z = []; a = z.append
    a("★ Risikoradar: Rückblick des Grundrisikos (U307, KONZEPT_Risikoradar.md 3) -- beide Zahlen ab 2022 an Tagesursprüngen nachgerechnet")
    if not isinstance(rb, dict):
        a("  Der Rückblick hat auf diesem Rechner noch nicht gerechnet. Der Takt startet ihn von selbst; dieser Lauf rechnet ihn sonst jetzt.")
        return "\n".join(z)
    a(f"  Modul {rb.get('version')} · gerechnet {_dt(rb.get('stand'))} in {_de(rb.get('dauer'), 0)} s · Regeln vorab fest: mindestens "
      f"{G_MIN_TAGE} Ursprungstage und {G_MIN_EREIGNISSE} Ereignisse, Skill > 0 mit p < {_de(G_ALPHA, 2)}, Steigung {_de(G_STEIGUNG[0], 1)} bis {_de(G_STEIGUNG[1], 1)}, "
      f"Niveau (Mittel der Zahl ÷ Quote) {_de(G_NIVEAU[0], 1)} bis {_de(G_NIVEAU[1], 2)}")
    for f in rb.get("fehlt") or []:
        a(f"  fehlt: {f}")
    for key, E in EREIGNIS.items():
        u = (rb.get("urteil") or {}).get(key) or {}
        name = "G7" if key == "e7" else "G2"
        a("")
        a(f"== {name} · Tief mindestens {x_text(E['x'])} · Faktor unter dem Kurs, binnen {E['name']} (BTC: Faktor 1)")
        a("   " + urteil_satz(key, u, rb))
        if u.get("n"):
            a(f"   Ursprünge vom {_tag_txt((u.get('von') or 0) // TAG)} bis {_tag_txt((u.get('bis') or 0) // TAG)} · Brier {_de(u.get('brier'), 4)} gegen Grundrate {_de(u.get('brier_grund'), 4)}")
            a("   Zuverlässigkeit (vorhergesagt · eingetreten, 90-%-Band):")
            for kl in u.get("zuverlaessigkeit") or []:
                a(f"     {_de(kl[0] * 100, 0):>3}–{_de(kl[1] * 100, 0):<3} %  {_tsd(kl[2]):>6} Ursprünge   vorhergesagt {_de(kl[3] * 100, 1):>5} %   "
                  f"eingetreten {_de(kl[4] * 100, 1):>5} %  ({_de(kl[5] * 100, 1)}–{_de(kl[6] * 100, 1)} %)")
            a("   Je Coin (Mittel der Zahl · Quote): " + " · ".join(
                f"{c} {_de(v['p'] * 100, 1)} % · {_de(v['quote'] * 100, 1)} % ({_tsd(v['ereignisse'])} von {_tsd(v['n'])})" for c, v in (u.get("je_coin") or {}).items()))
    a("")
    a("== Grundrate, Schwellen und Alarme im Rückblick je Coin (beschreibend)")
    for coin in COINS:
        c = (rb.get("coins") or {}).get(coin)
        if not c:
            a(f"   {coin}: kein Rückblick"); continue
        for key, E in EREIGNIS.items():
            s = c.get(key) or {}
            if s.get("grundrate") is None:
                a(f"   {coin} {E['kurz']}: zu wenige Ursprünge ({_tsd(s.get('n'))})"); continue
            q = s.get("q") or {}; al = s.get("alarme") or {}
            a(f"   {coin} {E['kurz']:<10} Grundrate {_de(s['grundrate'] * 100, 1):>5} % · erhöht ab {p_text(q.get(_qk(PZ_ERHOEHT)))} · hoch ab "
              f"{p_text(q.get(_qk(PZ_HOCH)))} (97,5.: {p_text(q.get(_qk(0.975)))}, 99.: {p_text(q.get(_qk(0.99)))}) · Eintritte in „hoch“ {_tsd(al.get('eintritte'))} "
              f"({_de(al.get('je_jahr'), 1)} je Jahr), danach kam das Ereignis {_tsd(al.get('treffer'))}-mal · von {_tsd(al.get('episoden'))} "
              f"Ereignis-Episoden stand das Radar bei {_tsd(al.get('gedeckt'))} auf „hoch“")
    a("")
    a("Lesart: „besteht“ heißt, die Zahl traf im Rückblick besser als die Grundrate und war richtig gestuft -- nicht, dass sie den nächsten")
    a("Rücksetzer ankündigt. Die Eintritte sind auf Tageswerten gezählt; live prüft das Radar alle 5 Minuten und kann öfter melden.")
    return "\n".join(_umbruch(z))


# ================================================================================================ Karte und Bericht

def meldungen_lesen(con, n: int = 5) -> list:
    if con is None:
        return []
    try:
        rows = con.execute("SELECT id, ts, coin, ereignis, art, p, titel, text, ansage, push, push_fehler FROM rd_alarm ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    except sqlite3.Error:
        return []
    wort = {PUSH_AUS: "kein Push", PUSH_OFFEN: "Push offen", PUSH_GESENDET: "Push gesendet", PUSH_AUFGEGEBEN: "Push nicht gesendet"}
    return [{"id": r[0], "ts": r[1], "coin": r[2], "ereignis": r[3], "art": r[4], "p": r[5], "titel": r[6], "text": r[7], "ansage": r[8],
             "push": wort.get(r[9], "—"), "push_fehler": r[10]} for r in rows]


def alle_stufen(con, coin_jetzt: str | None = None, S: dict | None = None) -> list:
    """Stufe von p7 je Coin aus der letzten Ablage (für die Zeile „alle Coins“); der gewählte Coin aus dem frischen Stand."""
    out = []
    for c in COINS:
        e = None
        if S is not None and c == coin_jetzt:
            e = {"p": S["ereignis"]["e7"].get("p"), "stufe": S["ereignis"]["e7"].get("stufe"), "ts": S.get("jetzt")}
        elif con is not None:
            try:
                r = con.execute("SELECT ts, json FROM rd_stand WHERE coin=? ORDER BY stunde DESC LIMIT 1", (c,)).fetchone()
                if r:
                    d = (json.loads(r[1]).get("e") or {}).get("e7") or {}
                    e = {"p": d.get("p"), "stufe": d.get("stufe"), "ts": r[0]}
            except (sqlite3.Error, ValueError, TypeError):
                e = None
        e = e or {"p": None, "stufe": "ohne", "ts": None}
        out.append({"coin": c, "p": e.get("p"), "p_text": p_text(e.get("p")) if e.get("p") is not None else "—", "stufe": e.get("stufe") or "ohne",
                    "stufe_wort": STUFEN_WORT.get(e.get("stufe") or "ohne", "ohne Stufe"), "ts": e.get("ts")})
    return out


def nutzlast(db: str, coin: str = "BTC", jetzt: int | None = None) -> dict:
    """Antwort für die Karte „Risikoradar“ (/cockpit/radar)."""
    t0 = time.time()
    jetzt = int(jetzt or time.time())
    S = stand(db, coin, jetzt)
    if not S.get("ok"):
        return S
    con = lesen(pfad(db))
    try:
        einst = einstellung_lesen(con)
        S["meldungen"] = meldungen_lesen(con)
        S["alle"] = alle_stufen(con, coin, S)
        takt = meta(con, "takt")
    finally:
        if con is not None:
            con.close()
    S = karte_bauen(S, einst, S.pop("meldungen"), S.pop("alle"), takt, bool(push_einstellung().get("thema")), jetzt)
    S["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return S


def karte_bauen(S: dict, einst: dict, meldungen: list, alle: list, takt: dict | None, push_ok: bool, jetzt: int) -> dict:
    """Die Antwort der Karte aus dem Stand und dem, was aus radar.db kommt -- ohne Zugriff auf Dateien."""
    S = dict(S)
    S["meldungen"] = meldungen; S["alle"] = alle
    S["einstellung"] = einst
    S["push_eingerichtet"] = bool(push_ok)
    S["takt"] = {"ts": (takt or {}).get("ts"), "laeuft": bool(takt and jetzt - int(takt.get("ts") or 0) <= 3 * TAKT_S)}
    S["pz_wahl"] = [{"pz": w, "text": ("95." if w == 0.95 else "97,5." if w == 0.975 else "99.") + " Perzentil",
                     "kurz": _de((1 - w) * 100, 1 if w == 0.975 else 0) + " %"} for w in PZ_WAHL]
    S["beleg"] = {"zahl": ("Beide Zahlen kommen aus der Verteilung des Ausblicks am jetzigen Kurs -- dieselbe Quelle wie der Kurs-Rechner. "
                           "Stufen: erhöht = riskanteste 20 % der Tage im Rückblick, hoch = riskanteste 5 %."),
                  "achsen": "Achsen von 0 bis 100: höher heißt mehr Druck. Gemessen, keine Vorhersage. Der Druck-Index zählt A1, A2, A3, A4 und A7.",
                  "grenzen": GRENZEN, "meldung_alt_s": MELDUNG_ALT_S}
    return S


def meldungen_json(db: str) -> bytes:
    """Antwort für /cockpit/radar/meldungen: nur die letzten Meldungen (für Ton und Ansage bei geschlossenem Cockpit-Abschnitt)."""
    con = lesen(pfad(db))
    try:
        m = meldungen_lesen(con)
    finally:
        if con is not None:
            con.close()
    return json.dumps({"ok": True, "meldungen": _ohne_nan(m), "meldung_alt_s": MELDUNG_ALT_S}, ensure_ascii=False, allow_nan=False).encode("utf-8")


def payload_json(db: str, coin: str = "BTC", jetzt: int | None = None) -> bytes:
    return json.dumps(_ohne_nan(nutzlast(db, coin, jetzt)), ensure_ascii=False, allow_nan=False).encode("utf-8")


def stand_text(S: dict, mit_urteil: bool = True) -> list:
    """Ein Coin als Text (Debug 160). mit_urteil=False: ohne den Satz des Rückblicks je Zahl (der Bericht nennt ihn einmal im Kopf)."""
    z = []; a = z.append
    if not S.get("ok"):
        return [f"== {S.get('coin')}: " + " ".join(S.get("fehlt") or [])]
    k = S["kurs"]
    a(f"== {S['coin']} · Kurs {_px(k.get('px'))} ({'frisch' if k.get('frisch') else 'nicht frisch'}, Stand {_dt(k.get('ts'))})"
      + (f" · Faktor gegenüber BTC {_de(S['faktor'].get('f'), 2)}" if S["faktor"].get("f") is not None and S["coin"] != "BTC" else ""))
    for key in ("e7", "e2"):
        e = S["ereignis"][key]
        a("   " + e["satz"])
        if e.get("schwellen"):
            a("      Schwellen: " + e["schwellen"])
        if mit_urteil:
            a("      " + e["urteil"])
        if e.get("niveau"):
            a("      " + e["niveau"])
    if S.get("trend"):
        a("   " + S["trend"])
    a("   Achsen (0 bis 100, höher = mehr Druck; „—“ = grau):")
    for x in S["achsen"]:
        a(f"      {x['key'].upper()} {x['name']:<18} {(_de(x['wert'], 0) if x.get('wert') is not None else '—'):>3}  {x['leit']}"
          + (f" · {x['vergleich']}" if x.get("wert") is not None and x.get("vergleich") else "") + f" · Stand {x['stand']}"
          + (f" · grau: {x['grau']}" if x.get("grau") else "")
          + ((" · fehlt im Index" if x.get("wert") is None else " · im Index") if x.get("index") else ""))
    a("   " + S["index"]["text"])
    a("   " + S["treiber"])
    a("   " + S["warnzeichen"]["text"])
    return z


def text(db: str, coins=COINS, jetzt: int | None = None) -> str:
    """Debug 160: Stand je Coin, Einstellungen, letzte Meldungen, Vorwärtsbilanz in Zahlen."""
    jetzt = int(jetzt or time.time()); t0 = time.time()
    z = []; a = z.append
    a(f"★ Risikoradar (U307) · Modul {VERSION_MODUL} · {_dt(jetzt)} · Risiko eines Rücksetzers in Prozent, acht Achsen, Alarm")
    a("Zwei Zahlen je Coin: −10 % · Faktor in 7 Tagen und −7 % · Faktor in 48 Stunden (BTC: Faktor 1). Stufen: normal · erhöht (riskanteste "
      "20 % der Tage im Rückblick) · hoch (riskanteste 5 %). Achsen und Druck-Index sind Messwerte, keine Vorhersage.")
    con = lesen(pfad(db))
    try:
        rb = meta(con, "rueckblick"); einst = einstellung_lesen(con); takt = meta(con, "takt"); meld = meldungen_lesen(con, 8)
        n_stand = n_alarm = None; erste = None
        if con is not None:
            try:
                n_stand, erste = con.execute("SELECT COUNT(*), MIN(ts) FROM rd_stand").fetchone()
                n_alarm = con.execute("SELECT COUNT(*) FROM rd_alarm WHERE art='alarm'").fetchone()[0]
            except sqlite3.Error:
                pass
    finally:
        if con is not None:
            con.close()
    if con is None:
        a("radar.db fehlt noch -- der Takt legt sie rund 90 Sekunden nach dem Start des Dashboards an.")
    a("Rückblick: " + (f"gerechnet {_dt(rb.get('stand'))} in {_de(rb.get('dauer'), 0)} s (Debug 161)" if isinstance(rb, dict)
                       else "noch nicht gerechnet (Debug 161) -- bis dahin gibt es keine Stufe und keinen Alarm"))
    if isinstance(rb, dict):
        for key in EREIGNIS:
            a("   " + urteil_satz(key, (rb.get("urteil") or {}).get(key), rb))
    if isinstance(takt, dict) and takt.get("ts"):
        ohne_s = jetzt - int(takt["ts"])
        takt_txt = (f"zuletzt {_dt(takt['ts'])}" if ohne_s <= 3 * TAKT_S else
                    f"steht seit {_dt(takt['ts'])} (seit {_tsd(ohne_s // 60)} Minuten kein Schritt -- ohne Takt gibt es keinen Alarm; läuft das Dashboard?)")
    else:
        takt_txt = "noch kein Schritt"
    a(f"Meldungen: Push {'an' if einst['push'] else 'aus'} ({'eingerichtet' if push_einstellung().get('thema') else 'Benachrichtigung nicht eingerichtet'}) · "
      f"Coins {', '.join(einst['coins']) or 'keiner'} · Schwelle „hoch“ = {('95.' if einst['pz'] == 0.95 else '97,5.' if einst['pz'] == 0.975 else '99.')} Perzentil · "
      f"Takt: {takt_txt}")
    for f in (takt.get("fehler") or [] if isinstance(takt, dict) else []):
        a(f"   Fehler im letzten Schritt des Takts: {f}")
    a("")
    G = None
    try:
        import hl_cockpit as HC
        G = HC.gemeinsam_lesen(db, jetzt)                                 # einmal für alle Coins
    except Exception:  # noqa: BLE001 -- dann liest stand() je Coin selbst und nennt den Grund
        G = None
    for coin in coins:
        try:
            z.extend(stand_text(stand(db, coin, jetzt, gemeinsam=G), mit_urteil=not isinstance(rb, dict)))
        except Exception as e:  # noqa: BLE001
            a(f"== {coin}: {type(e).__name__}: {e}")
        a("")
    a(f"Vorwärtsbilanz: {_tsd(n_stand or 0)} abgelegte Stände" + (f" seit {_dt(erste)}" if erste else "") + f" · {_tsd(n_alarm or 0)} {'Alarm' if n_alarm == 1 else 'Alarme'}. "
      "Ausgewertet wird sie, wenn genug Ereignisse zusammengekommen sind (Paket 2).")
    if meld:
        a("Letzte Meldungen:")
        for m in meld:
            a(f"   {_dt(m['ts'])} · {m['art']} · {m['titel']} · {m['push']}" + (f" ({m['push_fehler']})" if m.get("push_fehler") else ""))
            a(f"      {m['text']}")
    else:
        a("Letzte Meldungen: keine.")
    a("")
    a(GRENZEN)
    a(f"Rechenzeit dieses Berichts: {_de(time.time() - t0, 1)} s")
    return "\n".join(_umbruch(z))


# ================================================================================================ Selbsttest (ohne Netz)

def _drin(teil: str, text) -> bool:
    """„teil in text“ für die Proben -- ohne Ausnahme, wenn der Text fehlt (None): Die Probe soll dann scheitern, nicht abbrechen."""
    return isinstance(text, str) and teil in text


def _probe_lauf(jetzt: int, alter_s: int = 600, mit2: bool = True) -> dict:
    """Abgelegte Verteilung in der Form von hl_ausblick.lauf_quantile: laufendes Tief als gerade Linie über dem Raster."""
    n = 199
    h = {"7": {"hoch": [0.003 + 0.0015 * i for i in range(n)], "tief": [-0.300 + 0.0015 * i for i in range(n)]},
         "14": {"hoch": [0.004 + 0.002 * i for i in range(n)], "tief": [-0.400 + 0.002 * i for i in range(n)]}}
    if mit2:
        h["2"] = {"hoch": [0.001 + 0.0006 * i for i in range(n)], "tief": [-0.1200 + 0.0006 * i for i in range(n)]}
    return {"anker": jetzt - alter_s, "p0": 60000.0, "erzeugt": jetzt - alter_s + 60, "n": 3000, "h": h}


def _probe_rb(jetzt: int) -> dict:
    """Rückblick in der abgelegten Form: G7 besteht, G2 nicht; Schwellen für BTC und ETH."""
    q7 = {"0.8": 0.50, "0.9": 0.58, "0.95": 0.64, "0.975": 0.70, "0.99": 0.80}
    q2 = {"0.8": 0.30, "0.9": 0.50, "0.95": 0.70, "0.975": 0.80, "0.99": 0.90}
    return {"stand": jetzt - 7200, "version": VERSION_MODUL,
            "urteil": {"e7": {"besteht": True, "n": 8000, "n_tage": 1700, "n_ereignisse": 700, "skill": 0.061, "p": 0.001, "steigung": 0.95,
                              "niveau": 1.04, "grund": None},
                       "e2": {"besteht": False, "n": 8000, "n_tage": 1700, "n_ereignisse": 300, "skill": 0.004, "p": 0.31, "steigung": 0.9,
                              "niveau": 1.1, "grund": "die Zahl trifft nicht belegbar besser als die Grundrate (Skill +0,4 %, p 0,310; verlangt ist p unter 0,05)"}},
            "coins": {"BTC": {"e7": {"n": 1700, "grundrate": 0.09, "q": q7, "niveau": 1.37}, "e2": {"n": 1700, "grundrate": 0.031, "q": q2, "niveau": 1.0}},
                      "ETH": {"e7": {"n": 1700, "grundrate": 0.12, "q": q7, "niveau": 0.7}, "e2": {"n": 1700, "grundrate": 0.04, "q": q2, "niveau": 1.0}}}}


def _probe_cockpit(konten=3.45, konten_pz=0.9722, oi_pz=0.51, wochenende="aus", termin="aus", aktien="aus", jetzt=1_795_000_000) -> dict:
    """Antwort des Cockpits in der Form von hl_cockpit.bauen, nur die Teile, die das Radar liest."""
    pzn = lambda v: None if v is None else int(v * 100 + 1e-9)             # noqa: E731 -- wie hl_cockpit.pz_zahl: die Perzentilzahl, abgeschnitten
    return {"messwerte": [{"key": "oi", "wert": 97074.0, "pz": oi_pz, "pz_n": pzn(oi_pz), "stand": jetzt - 60, "text": "97.074 BTC"},
                          {"key": "konten", "wert": konten, "pz": konten_pz, "pz_n": pzn(konten_pz), "stand": jetzt - 120,
                           "text": "—" if konten is None else f"{konten:.2f}".replace(".", ",")},
                          {"key": "funding_hl", "wert": 0.000011, "pz": 0.29, "pz_n": 29, "text": "+0,0011 %/h"}],
            "lampen": [{"key": "hebel", "zustand": "hinweis" if (konten or 0) >= 3 else "aus", "wert": "3,45 ≥ 3"},
                       {"key": "termin", "zustand": termin, "wert": "Arbeitsmarktbericht"}, {"key": "wochenende", "zustand": wochenende, "wert": "Sa"},
                       {"key": "aktien", "zustand": aktien, "wert": "S&P −2,6 %"}, {"key": "schwankung", "zustand": "hinweis", "wert": "80. Perzentil"}]}


def _probe_stand(coin: str, jetzt: int, p7, stufe7: str, p2=0.02, stufe2: str = "normal", konten=2.0) -> dict:
    """Stand eines Coins in der Form von stand(), für die Proben des Alarms und des Takts."""
    e = lambda key, p, st, x, frist: {"key": key, "p": p, "stufe": st, "x": x, "x_text": x_text(x), "frist": frist, "p_text": p_text(p) if p is not None else "—",  # noqa: E731
                                     "grundrate": 0.09 if key == "e7" else 0.031}
    return {"ok": True, "coin": coin, "jetzt": jetzt, "kurs": {"px": 60000.0, "ts": jetzt - 30, "frisch": True},
            "ereignis": {"e7": e("e7", p7, stufe7, 0.10, "7 Tagen"), "e2": e("e2", p2, stufe2, 0.07, "48 Stunden")},
            "achsen": [{"key": "a1", "name": "Positionierung", "wert": 97.0}, {"key": "a7", "name": "Schwankung", "wert": 80.0},
                       {"key": "a2", "name": "Hebel-Menge", "wert": 51.0}, {"key": "a3", "name": "Preis des Hebels", "wert": None}],
            "index": {"wert": 62.0}, "warnzeichen": {"aktiv": konten >= 3 if konten is not None else None, "wert": konten},
            "a5_roh": 1.5, "a6_roh": 4.0e6}


def _probe_nutzlast(jetzt: int, coin: str = "BTC", mit_rb: bool = True, konten=3.45, meldungen: list | None = None) -> dict:
    """Antwort der Karte von Hand, in der Form von nutzlast(): alle acht Achsen (A7 und A5 mit Wert), G7 besteht, G2 nicht."""
    n_ = 420; tg = np.arange(20350, 20350 + n_)
    cc = 100.0 * np.exp(np.cumsum(np.where(np.arange(n_) % 2 == 0, 0.02, -0.02) * np.where(np.arange(n_) >= n_ - 20, 1.5, 1.0)))
    K_ = {"tag": tg, "c": cc, "pv": np.full(n_, 1000.0), "pt": np.full(n_, 520.0), "stag": tg, "sv": np.full(n_, 500.0), "st": np.full(n_, 240.0)}
    K_["st"][-7:] = 200.0
    f_ts = np.array([int(t) * TAG + h * 3600 for t in tg for h in (0, 8, 16)]); f_rate = np.full(len(f_ts), 0.0001); f_rate[-21:] = 0.0004
    LA = lange_achsen_aus(lange_reihen(K_, f_ts, f_rate), int(tg[-1]) + 1)
    zl = [(57000.0, "long", 5e6, 3), (59999.0, "long", 2e6, 2), (61000.0, "short", 8e6, 2)]
    KA = kurze_achsen({"ts": jetzt - 600, "zeilen": zl, "fehlt": [], "abdeckung": {"anteil": 0.29}}, 60000.0, True,
                      {"usd": 3.5e6, "n": 700, "stunden": [1e6 + 1e4 * i for i in range(300)], "fehlt": None}, [0.1 * i for i in range(A5_MIN)], jetzt)
    f = {"f": 1.0} if coin == "BTC" else {"f": 1.38}
    einst = {"push": True, "coins": ["BTC"], "pz": 0.95}
    S = stand_bauen(coin, jetzt, 60000.0 if coin == "BTC" else 2000.0, jetzt - 30, True, _probe_lauf(jetzt), None, f, _probe_rb(jetzt) if mit_rb else None,
                    {}, einst, _probe_cockpit(konten=konten, konten_pz=0.9722 if konten is not None else None, termin="hinweis", jetzt=jetzt), LA, KA, None)
    alle = [{"coin": c, "p": (S["ereignis"]["e7"]["p"] if c == coin else None), "p_text": (S["ereignis"]["e7"]["p_text"] if c == coin else "—"),
             "stufe": (S["ereignis"]["e7"]["stufe"] if c == coin else "ohne"), "stufe_wort": STUFEN_WORT[S["ereignis"]["e7"]["stufe"] if c == coin else "ohne"],
             "ts": jetzt if c == coin else None} for c in COINS]
    return karte_bauen(S, einst, meldungen or [], alle, {"ts": jetzt - 120}, True, jetzt)


def _kleine_welt(verz: str, jetzt: int) -> str:
    """
    Kleine Welt aus echten Dateien für die Proben E1 bis E9 (alles erzeugt, keine echten Kurse): hebel.db mit 420 Tagesschlüssen für
    BTC und ETH (ETH mit doppelter Schwankung; Spot nur für ETH, in den letzten 7 Tagen mit schwächerer Nachfrage), swing.db mit
    Funding (in den letzten 7 Tagen doppelt so hoch; an einem Tag fehlt einem Spot-Paar die Taker-Angabe), ausblick.db mit der abgelegten Verteilung für beide und einer Rechnung mit Trend
    für ETH, die Hauptdatenbank mit dem Orderbuch (5-s-Tabelle für die letzten 300 Stunden, Minutentabelle für ältere) und radar.db
    mit 340 eigenen Stundenwerten der Liquidations-Nähe. -> Pfad der Hauptdatenbank
    """
    import hl_ausblick as AU
    import hl_hebel as HB
    import hl_swing as SW
    db = os.path.join(verz, "hl_liq.db")
    heute = jetzt // TAG; st = jetzt // 3600
    hb = HB.verbinden(os.path.join(verz, "hebel.db"))
    zeilen = []
    for coin, amp in (("BTC", 0.01), ("ETH", 0.02)):
        c = 100.0
        for i in range(420, 0, -1):
            tag = heute - i
            c *= math.exp((amp if tag % 2 == 0 else -amp) * (1.5 if i <= 30 else 1.0))
            zeilen.append(("um", coin + "USDT", tag, c, c, c, c, 10.0, 1000.0, 520.0, 100))
            if coin == "ETH":
                for q, vol in (("USDT", 400.0), ("FDUSD", 100.0)):
                    tk = None if (i == 200 and q == "FDUSD") else vol * (0.48 if i <= 7 else 0.52)   # Tag −200: ein Paar ohne Taker-Angabe
                    zeilen.append(("spot", coin + q, tag, c, c, c, c, 1.0, vol, tk, 10))
    HB._schreiben(hb, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)", zeilen); hb.close()
    sw = SW.verbinden(os.path.join(verz, "swing.db"))
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)",
                  [(coin, (heute - i) * TAG + h * 3600, 0.0002 if i <= 7 else 0.0001) for coin in ("BTC", "ETH") for i in range(420, 0, -1) for h in (0, 8, 16)])
    sw.close()
    ac = AU.verbinden(os.path.join(verz, "ausblick.db"))
    L = _probe_lauf(jetzt)
    AU.meta_setzen(ac, {"lauf": json.dumps({"version": AU.LAUF_VERSION, "raster": list(AU.LAUF_Q), "coins": {"BTC": L, "ETH": L}})})
    AU._tx(ac, lambda: ac.execute("INSERT OR REPLACE INTO au_prognose VALUES (?,?,?,?,?)",
                                  ("ETH", L["anker"], L["erzeugt"], "stuendlich", json.dumps({"coin": "ETH", "anker": L["anker"], "richtung": {"mhat": {"7": 0.12}}}))))
    AU._tx(ac, lambda: ac.execute("INSERT OR REPLACE INTO au_prognose VALUES (?,?,?,?,?)",
                                  ("BTC", L["anker"] - 3600, L["erzeugt"] - 3600, "stuendlich", json.dumps({"coin": "BTC", "anker": L["anker"] - 3600, "richtung": {"mhat": {"7": 0.3}}}))))
    ac.close()
    spalten = ("ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, bid_10 REAL, ask_10 REAL, bid_25 REAL, ask_25 REAL, bid_50 REAL, ask_50 REAL, "
               "bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin)")
    hc = sqlite3.connect(db)
    hc.execute(f"CREATE TABLE book_summary ({spalten}) WITHOUT ROWID"); hc.execute(f"CREATE TABLE book_summary_1m ({spalten})")
    z5 = lambda ts, coin, b100: (int(ts), coin, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, float(b100), 0.0, 0.0)   # noqa: E731
    roh = []
    for k in range(2, 301):                                               # Stunden st−2 … st−300: je zwei Zeilen um den Stundenwert 1 Mio. + 10.000 · k
        roh += [z5((st - k) * 3600 + 5, "BTC", 1e6 + 1e4 * k - 1000), z5((st - k) * 3600 + 3000, "BTC", 1e6 + 1e4 * k + 1000),
                z5((st - k) * 3600 + 5, "ETH", 7e5)]
    roh += [z5(jetzt - 3600 + 50 * i, "BTC", 2.0e6) for i in range(1, 71)]   # die letzten 60 Minuten: 70 Zeilen zu 2,0 Mio.
    roh += [z5(jetzt - 3600, "BTC", 2.0e6), z5(jetzt - 1801, "BTC", 0.0), z5(jetzt + 5, "BTC", 9e9)]   # genau 60 min alt, ohne Gebot, in der Zukunft: zählen nicht
    roh += [z5(jetzt - 3600 + 600 * i, "ETH", 7e5) for i in range(1, 6)]     # ETH: nur fünf Zeilen in der letzten Stunde
    hc.executemany("INSERT OR REPLACE INTO book_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", roh)
    alt = [z5((st - k) * 3600 + 60, "BTC", 5e6) for k in range(350, 401)]   # 51 ältere Stunden, nur als Minutenmittel
    alt += [z5((st - 30 * 24 - 5) * 3600, "BTC", 9e9), z5((st - 10) * 3600 + 60, "BTC", 9e9)]   # älter als 30 Tage; und eine Stunde, die auch im 5-s-Raster steht
    hc.executemany("INSERT OR REPLACE INTO book_summary_1m VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", alt)
    hc.commit(); hc.close()
    rc = verbinden(os.path.join(verz, "radar.db"))
    rc.executemany("INSERT OR REPLACE INTO rd_stand (stunde, coin, ts, p7, p2, idx, a5, a6, json) VALUES (?,?,?,?,?,?,?,?,?)",
                   [(st - i - 1, "BTC", (st - i - 1) * 3600, None, None, None, i / 10, None, "{}") for i in range(340)])
    rc.close()
    return db


def selbsttest(verbose: bool = True) -> bool:
    import contextlib
    import io
    import shutil
    import tempfile
    import hl_ausblick as AU
    erg = []

    def ok(name, bed, info=""):
        erg.append(bool(bed))
        if verbose or not bed:
            print(("  ok   " if bed else "  FEHLER  ") + name + (f"  {info}" if info else ""), flush=True)

    print("hl_radar -- Selbsttest (Risikoradar: Zahlen, Faktor, Grundrisiko, Achsen, Alarm, Push an einen nachgebauten Server, Rückblick; ohne Netz)", flush=True)
    jetzt = 1_795_000_000 // 300 * 300                                   # fester Zeitpunkt (19.11.2026), Viertelstunde
    alt_env = {k: os.environ.get(k) for k in ("HL_RADAR_DB",)}
    tmp = tempfile.mkdtemp(prefix="hl_radar_test_")
    try:
        # ---------------------------------------------------------------- Zahlen
        ok("Z1 Zahlen: kaufmännisch gerundet (32,5 -> 33; 0,125 -> 0,13), deutsches Format, eine gerundete Null ohne Vorzeichen",
           _de(32.5, 0) == "33" and _de(0.125, 2) == "0,13" and _de(-0.004, 2) == "0,00" and _de(-0.006, 2) == "−0,01" and _de(1234567.8, 1) == "1.234.567,8"
           and _de(2.5, 0, True) == "+3" and _de(None) == "—" and _de(float("nan")) == "—", f"{_de(32.5, 0)} {_de(-0.004, 2)} {_de(1234567.8, 1)}")
        ok("Z2 Wahrscheinlichkeit: unter 10 % mit einer Stelle, sonst ganzzahlig; die Ränder des Rasters als Schranke",
           p_text(0.0049) == "unter 0,5 %" and p_text(0.005) == "0,5 %" and p_text(0.0994) == "9,9 %" and p_text(0.0995) == "10 %"
           and p_text(0.325) == "33 %" and p_text(0.995) == "100 %" and p_text(0.9951) == "über 99,5 %" and p_text(0.3, "unter") == "unter 0,5 %"
           and p_text(0.3, "ueber") == "über 99,5 %" and p_text(None) == "—" and p_text(0.3, "fehlt") == "—",
           f"{p_text(0.0995)} {p_text(0.325)} {p_text(0.995)}")
        ok("Z3 Abstand der Schwelle: 10 % · 13,8 % · 9,7 % (7 % · 1,38 = 9,66 %)",
           x_text(0.10) == "10 %" and x_text(0.10 * 1.38) == "13,8 %" and x_text(0.07 * 1.38) == "9,7 %" and x_text(0.07) == "7 %" and x_text(None) == "—",
           f"{x_text(0.138)} {x_text(0.0966)}")
        ok("Z4 Monatserster: 19.11.2026 -> 01.11.2026; der Erste selbst; Jahreswechsel",
           monatserster(20776) == calendar.timegm((2026, 11, 1, 0, 0, 0)) // TAG and monatserster(calendar.timegm((2026, 11, 1, 0, 0, 0)) // TAG) == monatserster(20776)
           and monatserster(calendar.timegm((2027, 1, 1, 0, 0, 0)) // TAG - 1) == calendar.timegm((2026, 12, 1, 0, 0, 0)) // TAG, str(monatserster(20776)))
        r_ = [float(i % 10) for i in range(360)]
        ok("Z5 Perzentil gegen die Stellen davor: Mittelrang (gleiche zählen halb), mindestens 180 Werte, nicht alle gleich; nur die 365 Stellen davor zählen",
           pz_davor(r_ + [4.0], 360) == 0.45 and pz_davor(r_ + [9.5], 360) == 1.0 and pz_davor(r_ + [-1.0], 360) == 0.0
           and pz_davor(r_[:179] + [4.0], 179) is None and pz_davor(r_[:180] + [4.0], 180) is not None and pz_davor([2.0] * 360 + [2.0], 360) is None
           and pz_davor(r_ + [float("nan")], 360) is None and pz_davor(r_, 360) is None
           and pz_davor([100.0] * 40 + r_ + [50.0], 400) == 360 / 365
           and pz_unter(4.0, r_, 240) == 0.45 and pz_unter(4.0, r_[:239], 240) is None, f"{pz_davor(r_ + [4.0], 360)} {pz_davor([100.0] * 40 + r_ + [50.0], 400)}")
        lz = _umbruch(["   " + "Wort " * 60, "kurz"])
        ok("Z6 Berichte: keine Zeile über 150 Zeichen; Folgezeilen eingerückt; der Text bleibt vollständig",
           all(len(z) <= ZEILE_MAX for z in lz) and len(lz) == 4 and lz[-1] == "kurz" and lz[1].startswith("     Wort") and not lz[1].startswith("      ")
           and " ".join(" ".join(lz[:3]).split()) == " ".join(("Wort " * 60).split()), f"{[len(z) for z in lz]}")

        # ---------------------------------------------------------------- Faktor
        tage = list(range(20000, 20400)); rb_ = {t: (0.02 if t % 2 else -0.02) for t in tage}
        st = 20400
        f3 = faktor_rechnen("XMR", {t: 3 * v for t, v in rb_.items()}, rb_, st)
        f1 = faktor_rechnen("ETH", dict(rb_), rb_, st)
        fr = faktor_rechnen("PAX", {t: 0.5 * v for t, v in rb_.items()}, rb_, st)
        fk = faktor_rechnen("HYPE", {t: 2 * v for t, v in rb_.items() if t >= st - 179}, rb_, st)
        fg = faktor_rechnen("HYPE", {t: 2 * v for t, v in rb_.items() if t >= st - 180}, rb_, st)
        rand = dict(rb_); rand[st] = 9.0; rand[st - 366] = 9.0            # der Stichtag selbst und ein Tag vor dem Fenster zählen nicht
        fw = faktor_rechnen("ZEC", {t: 1.385 * v for t, v in rand.items()}, rand, st)
        ok("F1 Faktor: Schwankung 3-mal so groß -> 3,00; gleich -> 1,00; ruhiger -> 1,00 (Untergrenze); BTC immer 1",
           f3["f"] == 3.0 and f3["n"] == 365 and f1["f"] == 1.0 and fr["f"] == 1.0 and abs(fr["roh"] - 0.5) < 1e-12
           and faktor_rechnen("BTC", None, None, st) == {"f": 1.0, "n": None, "stichtag": st, "grund": None}, f"{f3} {fr}")
        ok("F2 Faktor: unter 180 gemeinsamen Tagen keiner (mit Grund und Zahl), mit 180 einer; ohne Reihen keiner",
           fk["f"] is None and fk["n"] == 179 and "179 gemeinsame Tage" in fk["grund"] and fg["f"] == 2.0 and fg["n"] == 180
           and faktor_rechnen("ETH", None, rb_, st)["f"] is None and faktor_rechnen("ETH", rb_, {}, st)["f"] is None, f"{fk}")
        ok("F3 Faktor: Fenster sind die 365 Tage vor dem Monatsersten (der Erste selbst und ältere Tage zählen nicht); auf zwei Stellen, 5 nach oben",
           fw["n"] == 365 and fw["f"] == 1.39 and abs(fw["roh"] - 1.385) < 1e-9, f"{fw}")
        ok("F4 Tagesrenditen: nur wenn der Tag und der Vortag einen Schluss haben (eine Lücke gibt keine Rendite über zwei Tage)",
           _renditen_je_tag([10, 11, 13, 14], [100.0, 110.0, 121.0, 133.1]) == {11: math.log(1.1), 14: math.log(133.1 / 121.0)}
           and _renditen_je_tag([10, 11], [100.0, float("nan")]) == {} and _renditen_je_tag([10, 11], [0.0, 5.0]) == {})

        # ---------------------------------------------------------------- Grundrisiko und Stufe
        L = _probe_lauf(jetzt); RB = _probe_rb(jetzt)
        soll7 = 0.005 + ((math.log(0.9) + 0.300) / 0.0015) * 0.005; soll2 = 0.005 + ((math.log(0.93) + 0.1200) / 0.0006) * 0.005
        E = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        ok("G1 Grundrisiko BTC: p7 und p2 aus der abgelegten Verteilung, von Hand nachgerechnet; Schwelle 10 % und 7 % als Kurs",
           abs(E["e7"]["p"] - soll7) < 1e-9 and abs(E["e2"]["p"] - soll2) < 1e-9 and E["e7"]["x"] == 0.10 and E["e2"]["x"] == 0.07
           and abs(E["e7"]["kurs_schwelle"] - 54000.0) < 1e-6 and abs(E["e2"]["kurs_schwelle"] - 55800.0) < 1e-6 and E["e7"]["lage"] == "innen",
           f"{E['e7']['p']:.6f} gegen {soll7:.6f}; {E['e2']['p']:.6f} gegen {soll2:.6f}")
        pa, la = AU.erreichen_aus_lauf(L["h"], math.log(0.9), 7)
        ok("G2 dieselbe Quelle wie der Kurs-Rechner: p7 für BTC ist hl_ausblick.erreichen_aus_lauf am Abstand −10 % über 7 Tage",
           E["e7"]["p"] == float(pa) and la == "innen")
        Ee = ereignisse_bauen("ETH", L, None, {"f": 1.38}, 2000.0, True, jetzt, RB, {})
        s7e = 0.005 + ((math.log(1 - 0.138) + 0.300) / 0.0015) * 0.005
        ok("G3 anderer Coin: Schwelle = 10 % · Faktor (13,8 %) und 7 % · Faktor (9,7 %), Zahl am größeren Abstand kleiner",
           abs(Ee["e7"]["p"] - s7e) < 1e-9 and Ee["e7"]["x_text"] == "13,8 %" and Ee["e2"]["x_text"] == "9,7 %" and Ee["e7"]["p"] < E["e7"]["p"]
           and abs(Ee["e7"]["kurs_schwelle"] - 2000.0 * (1 - 0.138)) < 1e-9, f"{Ee['e7']['p']:.6f} gegen {s7e:.6f}")
        Ealt = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, False, jetzt, RB, {})
        Eal = ereignisse_bauen("BTC", _probe_lauf(jetzt, FRISCH_AUSBLICK_S + 1), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Egr = ereignisse_bauen("BTC", _probe_lauf(jetzt, FRISCH_AUSBLICK_S), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eo2 = ereignisse_bauen("BTC", _probe_lauf(jetzt, mit2=False), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eol = ereignisse_bauen("BTC", None, "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt).", {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eof = ereignisse_bauen("HYPE", L, None, {"f": None, "grund": "Für HYPE gibt es erst 90 gemeinsame Tage mit BTC (gebraucht werden 180)."}, 30.0, True, jetzt, RB, {})
        Egf = ereignisse_bauen("XMR", L, None, {"f": 9.5}, 300.0, True, jetzt, RB, {})
        ok("G4 ohne frische Quelle steht der Grund statt der Zahl: alter Kurs; Rechnung des Ausblicks älter als 3 Stunden (genau 3 Stunden gilt noch); "
           "kein Ausblick; kein Faktor; Schwelle über 90 %",
           Ealt["e7"]["p"] is None and "Kein frischer Kurs" in Ealt["e7"]["fehlt"] and Ealt["e7"]["stufe"] == "ohne" and Ealt["e7"]["kurs_schwelle"] == 54000.0
           and Eal["e7"]["p"] is None and "älter als 3 Stunden" in Eal["e7"]["fehlt"] and Egr["e7"]["p"] is not None
           and Eol["e2"]["p"] is None and "ausblick.db fehlt" in Eol["e2"]["fehlt"]
           and Eof["e7"]["p"] is None and "90 gemeinsame Tage" in Eof["e7"]["fehlt"] and Eof["e7"]["x"] is None and "90 gemeinsame Tage" in Eof["e7"]["satz"]
           and Egf["e7"]["p"] is None and "95 %" in Egf["e7"]["fehlt"] and Egf["e2"]["p"] is not None, f"{Eal['e7']['fehlt']} | {Egf['e7']['fehlt']}")
        ok("G5 der Ausblick hat Tag 2 noch nicht abgelegt (Rechnung von vor dem Einspielen): die 48-Stunden-Zahl nennt den Grund, die 7-Tage-Zahl steht",
           Eo2["e2"]["p"] is None and "für 2 Tage noch nicht abgelegt" in Eo2["e2"]["fehlt"] and Eo2["e7"]["p"] is not None)
        Lr = _probe_lauf(jetzt); Lr["h"]["7"]["tief"] = [-0.05 + 0.0001 * i for i in range(199)]
        Er = ereignisse_bauen("BTC", Lr, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Lu = _probe_lauf(jetzt); Lu["h"]["7"]["tief"] = [-0.9 + 0.001 * i for i in range(199)]
        Eu = ereignisse_bauen("BTC", Lu, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        ok("G6 Ränder des Rasters: Schwelle tiefer als alle Szenarien -> „unter 0,5 %“; höher als alle -> „über 99,5 %“",
           Er["e7"]["lage"] == "unter" and Er["e7"]["p_text"] == "unter 0,5 %" and Eu["e7"]["lage"] == "ueber" and Eu["e7"]["p_text"] == "über 99,5 %",
           f"{Er['e7']['p_text']} {Eu['e7']['p_text']}")
        ok("S1 Stufe: unter der Schwelle „erhöht“ normal, ab ihr erhöht, ab „hoch“ hoch; ohne Zahl oder Schwelle keine Stufe",
           stufe_von(0.49, 0.5, 0.64, False) == "normal" and stufe_von(0.50, 0.5, 0.64, False) == "erhoeht" and stufe_von(0.6399, 0.5, 0.64, False) == "erhoeht"
           and stufe_von(0.64, 0.5, 0.64, False) == "hoch" and stufe_von(None, 0.5, 0.64, False) == "ohne" and stufe_von(0.7, 0.5, None, True) == "ohne"
           and stufe_von(0.3, None, 0.64, False) == "normal")
        ok("S2 „hoch“ endet erst unter 0,8 · Schwelle: 0,512 bleibt hoch, wenn es schon hoch war; 0,5119 nicht mehr; ohne Vorzustand ist 0,6 erhöht",
           stufe_von(0.512, 0.5, 0.64, True) == "hoch" and stufe_von(0.5119, 0.5, 0.64, True) == "erhoeht" and stufe_von(0.6, 0.5, 0.64, False) == "erhoeht"
           and abs(HYSTERESE * 0.64 - 0.512) < 1e-12)
        ok("S3 Stufe der Karte: G7 besteht -> Stufe aus den Schwellen des Coins (p7 0,654 ≥ 0,64: hoch); G2 besteht nicht -> keine Stufe, Satz „nicht bestätigt“",
           E["e7"]["stufe"] == "hoch" and E["e7"]["s_hoch"] == 0.64 and E["e7"]["s_erhoeht"] == 0.50 and E["e7"]["besteht"] is True
           and E["e2"]["stufe"] == "ohne" and E["e2"]["besteht"] is False and "im Rückblick nicht bestätigt" in E["e2"]["satz"] and E["e2"]["s_hoch"] is None
           and "Stufe hoch" in E["e7"]["satz"] and "üblich 9,0 %" in E["e7"]["satz"], E["e7"]["satz"])
        E975 = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {}, 0.975)
        E975h = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {"e7": {"hoch": True}}, 0.975)
        ok("S4 Schwelle verstellt (97,5. Perzentil = 0,70): p7 0,654 ist nur noch erhöht; war der Zustand schon hoch, bleibt er es (über 0,8 · 0,70)",
           E975["e7"]["stufe"] == "erhoeht" and E975["e7"]["s_hoch"] == 0.70 and E975h["e7"]["stufe"] == "hoch")
        Eor = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, None, {})
        ok("S5 ohne Rückblick: Zahl ja, Stufe nein, Satz „noch nicht geprüft“, Hinweis auf Debug 161",
           Eor["e7"]["p"] is not None and Eor["e7"]["stufe"] == "ohne" and Eor["e7"]["besteht"] is None and "noch nicht geprüft" in Eor["e7"]["satz"]
           and "Debug 161" in Eor["e7"]["urteil"] and Eor["e7"]["grundrate"] is None and "üblich" not in Eor["e7"]["satz"])
        ok("S6 Hinweis zum Niveau je Coin: BTC lag im Rückblick beim 1,37-Fachen der Quote (kann zu hoch sein), ETH beim 0,70-Fachen (zu niedrig); im Band kein Hinweis",
           _drin("1,37-Fachen", E["e7"]["niveau"]) and _drin("zu hoch", E["e7"]["niveau"]) and _drin("0,70-Fachen", Ee["e7"]["niveau"])
           and _drin("zu niedrig", Ee["e7"]["niveau"])
           and E["e2"]["niveau"] is None and niveau_satz("BTC", 1.25) is None and niveau_satz("BTC", 0.8) is None and niveau_satz("BTC", 1.2501) is not None
           and niveau_satz("BTC", 0.7999) is not None and niveau_satz("BTC", None) is None, str(E["e7"]["niveau"]))
        RBo = _probe_rb(jetzt); RBo["coins"]["HYPE"] = {"e7": {"n": 60, "grundrate": None, "q": {}, "niveau": None}, "e2": {"n": 60, "grundrate": None, "q": {}, "niveau": None}}
        Eh = ereignisse_bauen("HYPE", L, None, {"f": 1.5}, 30.0, True, jetzt, RBo, {})
        ok("S9 G7 besteht, aber der Coin hat im Rückblick keine Schwellen (unter 100 Ursprünge): Zahl ja, keine Stufe -- der Satz sagt „ohne Stufe“ "
           "mit dem Grund und nicht „Stufe ohne Stufe“; ohne Grundrate steht kein „üblich“",
           Eh["e7"]["p"] is not None and Eh["e7"]["besteht"] is True and Eh["e7"]["stufe"] == "ohne" and Eh["e7"]["s_hoch"] is None and Eh["e7"]["schwellen"] is None
           and Eh["e7"]["satz"].endswith(": " + Eh["e7"]["p_text"] + " · ohne Stufe (für diesen Coin gibt es im Rückblick keine Schwellen).")
           and "Stufe ohne" not in Eh["e7"]["satz"] and "üblich" not in Eh["e7"]["satz"] and Eh["e7"]["x_text"] == "15 %", Eh["e7"]["satz"])
        St_ = stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, _probe_lauf(jetzt), None, {"f": 1.0}, None, {}, None, _probe_cockpit(jetzt=jetzt), {},
                          {"a5": {}, "a6": {}}, None, {"7": 0.12, "14": -0.3, "28": 0.004})
        ok("S8 Trend im Ausblick: enthält die jüngste Rechnung einen Trend (Tor offen), sagt der Stand es mit den Werten je Horizont; ohne Trend, "
           "mit lauter Nullen oder ohne Angabe steht nichts",
           St_["trend"] == ("Die jüngste Rechnung des Ausblicks enthält einen Trend (7 Tage +0,12 σ, 14 Tage −0,30 σ); er steckt in beiden Zahlen. "
                            "Der Rückblick des Radars hat die Zahlen ohne Trend geprüft.")
           and trend_satz(None) is None and trend_satz({}) is None and trend_satz({"7": 0.0, "14": None, "28": 0.004}) is None
           and stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, _probe_lauf(jetzt), None, {"f": 1.0}, None, {}, None, _probe_cockpit(jetzt=jetzt), {},
                           {"a5": {}, "a6": {}}, None)["trend"] is None and "enthält einen Trend" in "\n".join(stand_text(St_)), str(St_["trend"]))
        ok("S7 Satz zum Urteil: Zahl der Ursprünge, Tage, Ereignisse, Skill, p, Steigung, Niveau und das Wort „besteht“; sonst der Grund",
           "8.000 Ursprünge an 1.700 Tagen, 700 Ereignisse, Skill +6,1 % (p 0,001), Steigung 0,95, Niveau 1,04 — besteht." in E["e7"]["urteil"]
           and p_wert_text(0.0005) == "p unter 0,001" and p_wert_text(0.001) == "p 0,001" and p_wert_text(0.31) == "p 0,310" and p_wert_text(None) == "p —"
           and "(p unter 0,001)" in urteil_satz("e7", dict(RB["urteil"]["e7"], p=0.0004998), RB)
           and "nicht bestätigt: die Zahl trifft nicht belegbar besser" in E["e2"]["urteil"], E["e7"]["urteil"])

        # ---------------------------------------------------------------- lange Achsen
        n_ = 420; tg = np.arange(20350, 20350 + n_)
        cc = 100.0 * np.exp(np.cumsum(np.where(np.arange(n_) % 2 == 0, 0.02, -0.02)))
        K_ = {"tag": tg, "c": cc, "pv": np.full(n_, 1000.0), "pt": np.full(n_, 520.0), "stag": tg, "sv": np.full(n_, 500.0), "st": np.full(n_, 240.0)}
        f_ts = np.array([int(t) * TAG + h * 3600 for t in tg for h in (0, 8, 16)]); f_rate = np.full(len(f_ts), 0.0001)
        R_ = lange_reihen(K_, f_ts, f_rate)
        ok("A1 Tagesreihen von Hand: Funding 3 Zahlungen zu 0,01 % je Tag = 10,95 % im Jahr; Spot-Saldo (2·240 − 500) ÷ 500 = −4 %; Perp +4 %; σ = 2 %",
           abs(R_["fund7"][-1] - 0.0003 * 365) < 1e-12 and abs(R_["spot7"][-1] + 0.04) < 1e-12 and abs(R_["perp7"][-1] - 0.04) < 1e-12
           and abs(R_["sig"][-1] - 0.02) < 1e-9 and R_["tag0"] == 20350 and R_["n"] == n_, f"{R_['fund7'][-1]:.6f} {R_['spot7'][-1]:.4f} {R_['sig'][-1]:.5f}")
        K1 = {k: v.copy() for k, v in K_.items()}; K1["sv"][-3] = float("nan")
        K2 = {k: v.copy() for k, v in K_.items()}; K2["sv"][-3] = float("nan"); K2["st"][-5] = float("nan")
        K3 = {k: v.copy() for k, v in K_.items()}; K3["st"][-1] = 300.0
        ok("A2 sieben Tage mit Lücke: ein fehlender Tag zählt nicht mit (sechs genügen), zwei fehlende geben keinen Wert; ein Tag mit 60 % Taker-Kauf hebt den Saldo",
           abs(lange_reihen(K1, f_ts, f_rate)["spot7"][-1] + 0.04) < 1e-12 and not np.isfinite(lange_reihen(K2, f_ts, f_rate)["spot7"][-1])
           and abs(lange_reihen(K3, f_ts, f_rate)["spot7"][-1] - (6 * (-20.0) + 100.0) / 3500.0) < 1e-12)
        f2 = f_rate.copy(); f2[-21:] = 0.0004                                # die letzten 7 Tage: 0,12 % je Tag = 43,8 % im Jahr
        K4 = {k: v.copy() for k, v in K_.items()}; K4["st"][-7:] = 200.0      # die letzten 7 Tage: Saldo −20 %
        Rh = lange_reihen(K4, f_ts, f2); heute = int(tg[-1]) + 1
        LAh = lange_achsen_aus(Rh, heute)
        ok("A3 Achsen aus den Tagesreihen: höchstes Funding und schwächster Spot-Saldo der 365 Tage davor -> Perzentil 1 bzw. 0; Stand = letzter Tag der Achse",
           LAh["a3"]["pz"] == 1.0 and abs(LAh["a3"]["roh"] - 0.0012 * 365) < 1e-12 and LAh["a4"]["pz"] == 0.0 and abs(LAh["a4"]["roh"] + 0.2) < 1e-12
           and LAh["a3"]["tag"] == int(tg[-1]) and LAh["a3"]["grau"] is None and LAh["a7"]["grau"] is not None, f"{LAh['a3']} {LAh['a7']['grau']}")
        LAalt = lange_achsen_aus(Rh, heute + 3); LAgr = lange_achsen_aus(Rh, heute + 2)   # letzter Tageswert 4 bzw. 3 Tage alt
        Kk = {k: v[-170:].copy() for k, v in K4.items()}
        LAk = lange_achsen_aus(lange_reihen(Kk, f_ts, f2), heute)
        Ko = dict(K4); Ko["stag"] = np.array([], dtype=np.int64); Ko["sv"] = np.array([]); Ko["st"] = np.array([])
        LAo = lange_achsen_aus(lange_reihen(Ko, f_ts, f2), heute)
        LAf = lange_achsen_aus(lange_reihen(K4, None, None), heute)
        ok("A4 grau mit Grund: Tageswerte älter als 3 Tage (genau 3 Tage gelten noch); unter 180 Tagen Verlauf; Coin ohne Spot-Kerzen in hebel.db; "
           "ohne Funding; ohne Kerzen",
           _drin("Tageswerte nur bis", LAalt["a3"]["grau"]) and _drin("Tageswerte nur bis", LAalt["a7"]["grau"]) and LAgr["a3"]["grau"] is None
           and LAgr["a3"]["pz"] == 1.0 and _drin("fehlt Verlauf", LAk["a3"]["grau"]) and LAk["a3"]["roh"] is not None
           and _drin("keine Spot-Kerzen von Binance", LAo["a4"]["grau"]) and LAo["a3"]["grau"] is None and _drin("kein Wert", LAf["a3"]["grau"])
           and LAf["a4"]["grau"] is None and all(_drin("fehlen Tageskerzen", v["grau"]) for v in lange_achsen_aus(None, heute).values()),
           f"{LAalt['a3']['grau']} | {LAk['a3']['grau']} | {LAo['a4']['grau']}")

        # ---------------------------------------------------------------- kurze Achsen, Umfeld, Zusammenbau
        zl = [(57000.0, "long", 5e6, 3), (57000.0 - 0.01, "long", 7e6, 1), (59999.0, "long", 2e6, 2), (60000.0, "long", 9e6, 1), (58000.0, "short", 4e6, 1),
              (61000.0, "short", 8e6, 2)]
        ok("K1 Liquidations-Nähe: Long-Positionen mit Liquidationspreis von genau −5 % bis knapp unter dem Kurs zählen; der Kurs selbst, tiefer liegende und Short nicht",
           liq_naehe(zl, 60000.0) == 7e6 and liq_naehe(zl, None) == 0.0 and liq_naehe([], 60000.0) == 0.0 and liq_naehe(zl, 60000.0, 0.06) == 14e6)
        Lq = {"ts": jetzt - 600, "zeilen": zl, "fehlt": [], "abdeckung": {"anteil": 0.29}}
        T_ = {"usd": 3.5e6, "n": 700, "stunden": [1e6 + 1e4 * i for i in range(300)], "fehlt": None}
        h5 = [0.1 * i for i in range(A5_MIN)]
        KA = kurze_achsen(Lq, 60000.0, True, T_, h5, jetzt)
        ok("K2 A5 = 7 Mio. ÷ 3,5 Mio. = 2,0-mal die Gebote; Perzentil gegen 336 eigene Stundenwerte (14 Tage); A6 umgekehrt: 3,5 Mio. Gebote sind mehr als 250 von 300 Stunden -> Wert 16,7",
           KA["a5"]["roh"] == 2.0 and KA["a5"]["liq_usd"] == 7e6 and abs(KA["a5"]["pz"] - (20 + 0.5) / 336) < 1e-12 and KA["a5"]["grau"] is None and A5_MIN == 336 and A6_MIN == 240
           and KA["a5"]["abdeckung"] == 0.29 and abs(KA["a6"]["pz"] - (1 - 250.5 / 300)) < 1e-12 and KA["a6"]["grau"] is None, f"{KA['a5']['pz']} {KA['a6']['pz']}")
        Kg1 = kurze_achsen(Lq, 60000.0, True, T_, h5[:335], jetzt); Kg2 = kurze_achsen(dict(Lq, ts=jetzt - 1801), 60000.0, True, T_, h5, jetzt)
        Kg3 = kurze_achsen(Lq, 60000.0, False, T_, h5, jetzt); Kg4 = kurze_achsen(None, 60000.0, True, T_, h5, jetzt)
        Kg5 = kurze_achsen(Lq, 60000.0, True, {"usd": None, "n": 3, "stunden": [], "fehlt": "Orderbuch: in den letzten 60 Minuten nur 3 Werte (gebraucht werden 60)."}, h5, jetzt)
        Kg6 = kurze_achsen(dict(Lq, ts=jetzt - 1800), 60000.0, True, dict(T_, stunden=T_["stunden"][:239]), h5, jetzt)
        ok("K3 grau mit Grund: 335 eigene Stundenwerte (einer zu wenig); Heatmap älter als 30 Minuten (genau 30 gilt); kein frischer Kurs; keine Heatmap; kein Orderbuch; Markttiefe mit 239 Stundenwerten",
           _drin("335 von 336", Kg1["a5"]["grau"]) and Kg1["a5"]["roh"] == 2.0 and _drin("nicht frisch", Kg2["a5"]["grau"]) and Kg6["a5"]["grau"] is None
           and _drin("Kein frischer Kurs", Kg3["a5"]["grau"]) and _drin("noch kein Schnappschuss", Kg4["a5"]["grau"]) and _drin("nur 3 Werte", Kg5["a5"]["grau"])
           and _drin("nur 3 Werte", Kg5["a6"]["grau"]) and _drin("239 von 240", Kg6["a6"]["grau"]), f"{Kg1['a5']['grau']} | {Kg2['a5']['grau']}")
        lpd = lambda **kw: {m["key"]: m for m in _probe_cockpit(**kw)["lampen"]}   # noqa: E731
        ug1 = umfeld(lpd(aktien="grau", termin="grau"), 0); ug2 = umfeld(lpd(aktien="grau", termin="hinweis"), None); ug3 = umfeld(lpd(aktien="hinweis", termin="grau"), None)
        ug4 = umfeld({k: v for k, v in lpd().items() if k != "termin"}, None); ug5 = umfeld(lpd(aktien="grau"), 1)
        axg = [a for a in achsen_bauen(_probe_cockpit(aktien="grau", termin="grau", jetzt=jetzt), {}, {"a5": {}, "a6": {}}, None, "BTC") if a["key"] == "a8"][0]
        ok("U2 Umfeld mit grauer Lampe: könnte die graue Lampe mehr bedeuten als das Bekannte, gibt es keinen Wert (grau mit Grund) statt „0“; "
           "ist schon die höchste Stufe erreicht, bleibt der Wert; eine fehlende Lampe zählt wie eine graue",
           ug1["wert"] is None and ug1["offen"] == ["Termin", "Aktien"] and ug2["wert"] is None and ug2["offen"] == ["Aktien"] and ug2["gruende"][0].startswith("Termin")
           and ug3["wert"] == 100 and ug3["offen"] == [] and ug4["wert"] is None and ug4["offen"] == ["Termin"] and ug5["wert"] == 100
           and axg["wert"] is None and axg["grau"] == "Lampen Termin und Aktien grau -- ob das Umfeld belastet ist, ist nicht belegt."
           and axg["leit"] == "Umfeld: nichts Bekanntes", f"{ug1} {axg['grau']}")
        ok("U1 Umfeld in Stufen: nichts 0 · Wochenende 33 · Termin 66 · Aktien-Lampe 100 · Notbremse ab Stufe 1 100; der höchste Wert gilt, alle Gründe stehen da",
           umfeld(lpd(), None)["wert"] == 0 and umfeld(lpd(wochenende="hinweis"), 0)["wert"] == 33 and umfeld(lpd(termin="hinweis", wochenende="hinweis"), None)["wert"] == 66
           and umfeld(lpd(termin="warnung"), None)["wert"] == 66 and umfeld(lpd(aktien="hinweis"), None)["wert"] == 100 and umfeld(lpd(), 1)["wert"] == 100
           and umfeld(lpd(), 2)["gruende"] == ["Notbremse Stufe 2"] and umfeld(lpd(), 0)["offen"] == []
           and len(umfeld(lpd(termin="hinweis", wochenende="hinweis", aktien="hinweis"), 1)["gruende"]) == 4)
        Bc = _probe_cockpit(jetzt=jetzt)
        AX = achsen_bauen(Bc, LAh, KA, None, "BTC")
        w = {a["key"]: a["wert"] for a in AX}
        ok("B1 acht Achsen in fester Reihenfolge; Werte: A1 97 (Perzentil 0,9722), A2 51, A3 100, A4 100 (schwächste Nachfrage), A5 6 (20,5 von 336), A6 17, A7 grau, A8 0",
           [a["key"] for a in AX] == ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8"] and w == {"a1": 97.0, "a2": 51.0, "a3": 100.0, "a4": 100.0, "a5": 6.0, "a6": 17.0, "a7": None, "a8": 0.0}
           and [a["index"] for a in AX] == [True, True, True, True, False, False, True, False] and AX[0]["leit"] == "Kontenquote Binance 3,45"
           and AX[1]["leit"] == "Open Interest Binance 97.074 BTC" and "+43,8 % im Jahr" in AX[2]["leit"] and "−20,00 % des Umsatzes" in AX[3]["leit"]
           and "2,0-mal die Gebote" in AX[4]["leit"] and "erfasst sind 29 % des Open Interest" in AX[4]["leit"] and "3,5 Mio. USD" in AX[5]["leit"], f"{w}")
        I5 = index_bauen(achsen_bauen(Bc, dict(LAh, a7={"roh": 0.03, "pz": 0.805, "tag": 1, "grau": None}), KA, None, "BTC"))
        I4 = index_bauen(AX)
        I3 = index_bauen(achsen_bauen(_probe_cockpit(konten=None, konten_pz=None), LAh, KA, None, "BTC"))
        ok("B2 Druck-Index: Mittel der fünf Achsen (97 + 51 + 100 + 100 + 81) ÷ 5 = 85,8 -> 86; mit vier Achsen 87; mit drei kein Wert, mit Namen der fehlenden",
           I5["wert"] == 86.0 and I5["n"] == 5 and I4["wert"] == 87.0 and I4["n"] == 4 and I4["fehlen"] == ["Schwankung"] and "ohne Schwankung" in I4["text"]
           and "gemessen, ungeprüft" in I4["text"] and I3["wert"] is None and I3["n"] == 3 and "Positionierung" in I3["text"] and "gebraucht werden 4" in I3["text"],
           f"{I5['wert']} {I4['wert']} {I3['text']}")
        ag1 = achsen_bauen(_probe_cockpit(konten=None, konten_pz=None), LAh, KA, None)[0]
        ag2 = achsen_bauen({"messwerte": [{"key": "konten", "wert": None, "pz": None, "text": "—", "fehlt": "Stand älter als 30 Minuten"},
                                          {"key": "oi", "wert": 5.0, "pz": None, "pz_n": None, "text": "5 BTC"}], "lampen": []}, LAh, KA, None, "BTC")
        ok("B3 graue Achse nennt den Grund: Kontenquote ohne Wert; mit dem Grund des Cockpits, wenn es einen nennt; Open Interest ohne Perzentil "
           "(der formatierte Wert des Cockpits ist kein Grund); der Vergleich nennt die 90 Tagesstände",
           ag1["grau"] == "Kontenquote Binance: kein Wert." and ag1["wert"] is None and ag2[0]["grau"] == "Kontenquote Binance: Stand älter als 30 Minuten"
           and ag2[1]["grau"] == "Open Interest Binance: für das Perzentil fehlt Verlauf (gebraucht werden 60 Tagesstände)." and ag2[1]["wert"] is None
           and ag2[1]["leit"] == "Open Interest Binance 5 BTC" and AX[0]["vergleich"] == "Perzentil gegen die letzten 90 Tagesstände" == AX[1]["vergleich"],
           f"{ag1['grau']} | {ag2[0]['grau']} | {ag2[1]['grau']}")
        ok("B4 „Was den Druck treibt“: die zwei höchsten Achsen (bei Gleichstand die frühere); nur Nullen -> eigener Satz; nichts -> eigener Satz",
           treiber_satz(AX) == "Am höchsten: Preis des Hebels (100) und Spot-Nachfrage (100)."
           and treiber_satz([{"key": "a8", "name": "Umfeld", "wert": 0.0}, {"key": "a1", "name": "Positionierung", "wert": None}]).startswith("Keine Achse zeigt Druck")
           and treiber_satz([{"key": "a1", "name": "Positionierung", "wert": None}]) == "Keine Achse hat einen Wert."
           and treiber_satz([{"key": "a8", "name": "Umfeld", "wert": 33.0}, {"key": "a1", "name": "Positionierung", "wert": 0.0}]) == "Am höchsten: Umfeld (33).")
        ok("B5 Warnzeichen Kontenquote: 2,99 aus, 3,00 an (mit dem Beleg aus U142 und dem Hinweis auf das andere Ereignis); ohne Wert kein Zustand",
           warnzeichen_bauen(_probe_cockpit(konten=2.99))["aktiv"] is False and warnzeichen_bauen(_probe_cockpit(konten=3.0))["aktiv"] is True
           and "Kontenquote Binance 3,00 (ab 3)" in warnzeichen_bauen(_probe_cockpit(konten=3.0))["text"] and warnzeichen_bauen(_probe_cockpit(konten=None))["aktiv"] is None
           and "20,3 %" in BELEG_U142 and "anderes Ereignis" in BELEG_U142)
        try:
            import hl_cockpit as HC
            Bv = HC.bauen(HC._probe_quellen(jetzt, "BTC"))
            mk = {m.get("key"): m for m in Bv.get("messwerte") or []}; lk = {m.get("key"): m for m in Bv.get("lampen") or []}
            import hl_chartbild as CBv
            axv = {a["key"]: a for a in achsen_bauen(Bv, {}, {"a5": {}, "a6": {}}, None, "BTC")}
            ok("V1 Vertrag mit dem Cockpit: Messwerte „konten“ und „oi“ mit wert, pz (Anteil 0 … 1), stand; pz_n ist die abgeschnittene Perzentilzahl "
               "(keine Anzahl), text der formatierte Wert (kein Grund); das Perzentil kommt aus 90 Tagesständen, mindestens 60; A1 und A2 der Karte "
               "sind dieses Perzentil mal 100; fünf Lampen mit Zustand aus der bekannten Menge",
               all(k in mk and all(f in mk[k] for f in ("wert", "pz", "pz_n", "stand", "text")) for k in ("konten", "oi"))
               and all(mk[k]["pz"] is not None and 0 <= mk[k]["pz"] <= 1 and mk[k]["pz_n"] == HC.pz_zahl(mk[k]["pz"]) for k in ("konten", "oi"))
               and mk["konten"]["text"] == _de(mk["konten"]["wert"], 2) and mk["oi"]["text"].endswith(" BTC")
               and CBv.PERZ_FENSTER == 90 and not np.isfinite(CBv.perzentil(1.0, np.arange(59.0))) and np.isfinite(CBv.perzentil(1.0, np.arange(60.0)))
               and axv["a1"]["wert"] == float(_hu(mk["konten"]["pz"] * 100, 0)) and axv["a2"]["wert"] == float(_hu(mk["oi"]["pz"] * 100, 0))
               and axv["a1"]["grau"] is None and axv["a1"]["leit"] == "Kontenquote Binance " + mk["konten"]["text"]
               and set(lk) >= {"hebel", "termin", "wochenende", "aktien", "schwankung"}
               and all(lk[k].get("zustand") in ("aus", "hinweis", "warnung", "grau") for k in lk) and HC.FRISCH_LIQ_S == 1800 and HC.FRISCH_KURS_S == FRISCH_KURS_S,
               f"{sorted(mk)} {sorted(lk)}; pz_n {mk['konten']['pz_n']} bei pz {mk['konten']['pz']}; A1 {axv['a1']['wert']}")
        except Exception as e_:  # noqa: BLE001
            ok("V1 Vertrag mit dem Cockpit", False, f"{type(e_).__name__}: {e_}")

        # ---------------------------------------------------------------- Alarm
        Sn = lambda p7, st7, **kw: _probe_stand("BTC", jetzt, p7, st7, **kw)   # noqa: E731
        Z0, M0 = alarm_schritt(None, Sn(0.3, "normal"), jetzt)
        Z1, M1 = alarm_schritt(Z0, Sn(0.66, "hoch"), jetzt + 300)
        Z2, M2 = alarm_schritt(Z1, Sn(0.60, "hoch"), jetzt + 600)
        Z3, M3 = alarm_schritt(Z2, Sn(0.40, "normal"), jetzt + 900)
        Z4, M4 = alarm_schritt(Z3, Sn(0.70, "hoch"), jetzt + 1200)                       # erneut hoch binnen 12 h: gesperrt
        Z5, M5 = alarm_schritt(Z4, Sn(0.40, "erhoeht"), jetzt + 1500)                    # Ende ohne gemeldeten Beginn: keine Entwarnung
        Z6, M6 = alarm_schritt(Z5, Sn(0.70, "hoch"), jetzt + 300 + SPERRZEIT_S - 1)      # eine Sekunde vor Ablauf der Sperrzeit
        Z7, M7 = alarm_schritt(Z5, Sn(0.70, "hoch"), jetzt + 300 + SPERRZEIT_S)          # genau 12 h nach dem Alarm
        ok("M1 Alarm: Beginn von „hoch“ -> ein Alarm; solange hoch -> nichts; Ende -> eine Entwarnung",
           M0 == [] and [m["art"] for m in M1] == ["alarm"] and M2 == [] and [m["art"] for m in M3] == ["entwarnung"] and Z1["e7"]["hoch"] is True
           and Z1["e7"]["alarm_ts"] == jetzt + 300 and Z3["e7"]["hoch"] is False and Z0 == {"e7": {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False},
           "e2": {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False}, "konten": {"scharf": True, "hinweis_ts": 0}}, f"{Z0}")
        ok("M2 Sperrzeit 12 Stunden: erneuter Beginn davor -> kein Alarm und am Ende keine Entwarnung; genau nach 12 Stunden wieder ein Alarm",
           M4 == [] and Z4["e7"]["hoch"] is True and Z4["e7"]["gemeldet"] is False and M5 == [] and M6 == [] and [m["art"] for m in M7] == ["alarm"]
           and Z7["e7"]["alarm_ts"] == jetzt + 300 + SPERRZEIT_S)
        Zl, Ml = alarm_schritt(Z1, _probe_stand("BTC", jetzt, None, "ohne"), jetzt + 600)
        ok("M3 eine Lücke (keine Zahl, keine Stufe) löst nichts aus und beendet nichts: der Zustand bleibt hoch, keine Meldung",
           Ml == [] and Zl["e7"] == Z1["e7"])
        Zb, Mb = alarm_schritt(None, _probe_stand("BTC", jetzt, 0.7, "hoch", p2=0.75, stufe2="hoch"), jetzt)
        ok("M4 beide Zahlen werden für sich geführt: beide beginnen -> zwei Alarme (7 Tage und 48 Stunden)",
           [(m["art"], m["ereignis"]) for m in Mb] == [("alarm", "e7"), ("alarm", "e2")] and Zb["e2"]["hoch"] is True)
        a1 = M1[0]
        ok("M5 Text des Alarms: Titel, Zahl mit Grundrate, die zwei höchsten Achsen, Stand; Priorität 5; Ansage in ganzen Wörtern",
           a1["titel"] == "Risikoradar BTC: Risiko hoch" and a1["prio"] == 5 and a1["coin"] == "BTC" and a1["ereignis"] == "e7" and a1["p"] == 0.66
           and a1["text"] == f"−10 % in 7 Tagen: 66 % (üblich 9,0 %). Höchste Achsen: Positionierung 97, Schwankung 80. Stand {_orts(jetzt)}."
           and a1["ansage"] == "Risikoradar. Bitcoin. Risiko hoch. 66 Prozent für minus 10 Prozent in 7 Tagen.", a1["text"] + " | " + str(a1["ansage"]))
        Se = _probe_stand("ETH", jetzt, 0.087, "hoch", konten=3.2); Se["ereignis"]["e7"]["x"] = 0.138; Se["ereignis"]["e7"]["x_text"] = "13,8 %"
        ae = alarm_schritt(None, Se, jetzt)[1][0]
        ok("M6 Ansage mit Komma-Zahlen („8 Komma 7 Prozent für minus 13 Komma 8 Prozent“); aktives Warnzeichen steht im Text",
           ae["ansage"] == "Risikoradar. Ethereum. Risiko hoch. 8 Komma 7 Prozent für minus 13 Komma 8 Prozent in 7 Tagen."
           and "Warnzeichen: Kontenquote 3,20." in ae["text"] and ae["titel"] == "Risikoradar ETH: Risiko hoch", str(ae["ansage"]))
        alt_tz = os.environ.get("TZ"); orts_ = None
        if hasattr(time, "tzset"):
            try:
                os.environ["TZ"] = "Europe/Berlin"; time.tzset()
                orts_ = (_orts(calendar.timegm((2026, 11, 23, 20, 29, 0))), _orts(calendar.timegm((2026, 7, 1, 12, 0, 0))), _orts(None))
            finally:
                if alt_tz is None:
                    os.environ.pop("TZ", None)
                else:
                    os.environ["TZ"] = alt_tz
                time.tzset()
        ok("M12 Zeit in den Meldungen: Ortszeit des Rechners mit dem Kürzel der Zeitzone (in Berlin: 20:29 UTC = 21:29 CET, im Sommer CEST); Berichte nennen UTC",
           (orts_ is None or orts_ == ("23.11. 21:29 CET", "01.07. 14:00 CEST", "—")) and _dt(calendar.timegm((2026, 11, 23, 20, 29, 0))) == "23.11. 20:29 UTC"
           and a1["text"].endswith(f"Stand {_orts(jetzt)}."), f"{orts_}")
        e3 = M3[0]
        ok("M7 Entwarnung: leise (Priorität 2), ohne Ansage, mit der Zahl; Titel „nicht mehr hoch“",
           e3["prio"] == 2 and e3["ansage"] is None and e3["titel"] == "Risikoradar BTC: nicht mehr hoch" and "Die Stufe „hoch“ ist beendet." in e3["text"]
           and "−10 % in 7 Tagen: 40 %" in e3["text"])
        Zk0, Mk0 = alarm_schritt(None, Sn(0.1, "normal", konten=3.4), jetzt)                                 # erster Blick, schon über 3: kein Hinweis
        Zk1, Mk1 = alarm_schritt(Zk0, Sn(0.1, "normal", konten=2.85), jetzt + 300)                           # zwischen 2,8 und 3: nicht scharf
        Zk2, Mk2 = alarm_schritt(Zk1, Sn(0.1, "normal", konten=3.1), jetzt + 600)
        Zk3, Mk3 = alarm_schritt(Zk2, Sn(0.1, "normal", konten=2.79), jetzt + 900)                           # unter 2,8: scharf
        Zk4, Mk4 = alarm_schritt(Zk3, Sn(0.1, "normal", konten=2.99), jetzt + 1200)
        Zk5, Mk5 = alarm_schritt(Zk4, Sn(0.1, "normal", konten=3.0), jetzt + 1500)                           # steigt auf 3: Hinweis
        Zk6, Mk6 = alarm_schritt(Zk5, Sn(0.1, "normal", konten=2.5), jetzt + 1800)
        Zk7, Mk7 = alarm_schritt(Zk6, Sn(0.1, "normal", konten=3.3), jetzt + 1500 + HINWEIS_SPERRE_S - 1)     # binnen 7 Tagen: kein zweiter
        Zk8, Mk8 = alarm_schritt(Zk6, Sn(0.1, "normal", konten=3.3), jetzt + 1500 + HINWEIS_SPERRE_S)
        Zk9, Mk9 = alarm_schritt(Zk5, Sn(0.1, "normal", konten=None), jetzt + 1800)
        ok("M8 Hinweis Warnzeichen: nur wenn die Kontenquote auf 3 steigt, nachdem sie unter 2,8 lag; beim ersten Blick über 3 keiner; höchstens einer in 7 Tagen",
           Mk0 == [] and Zk0["konten"]["scharf"] is False and Mk1 == [] and Zk1["konten"]["scharf"] is False and Mk2 == [] and Zk3["konten"]["scharf"] is True
           and Mk4 == [] and Zk4["konten"]["scharf"] is True and [m["art"] for m in Mk5] == ["hinweis"] and Zk5["konten"] == {"scharf": False, "hinweis_ts": jetzt + 1500}
           and Zk6["konten"]["scharf"] is True and Mk7 == [] and Zk7["konten"]["scharf"] is False and [m["art"] for m in Mk8] == ["hinweis"]
           and Mk9 == [] and Zk9["konten"] == Zk5["konten"])
        h5_ = Mk5[0]
        ok("M9 Text des Hinweises: Priorität 3, ohne Ansage, mit dem gemessenen Verhältnis aus U142",
           h5_["prio"] == 3 and h5_["ansage"] is None and h5_["titel"] == "Risikoradar BTC: Warnzeichen Kontenquote"
           and h5_["text"].startswith("Kontenquote Binance 3,00 (ab 3). In solchen Lagen folgte in 7 Tagen häufiger ein Rücksetzer (U142: 20,3 % gegen 7,3 %)."))
        alle_texte = " ".join(str(v) for m in (M1 + M3 + Mk5 + [ae]) for v in (m["titel"], m["text"], m.get("ansage") or "")) + " " + GRENZEN + " " + BELEG_U142
        ok("M10 Wortprobe: kein Pfeil, kein Empfehlungswort in Meldungen, Beleg und Grenzen",
           not any(w_ in alle_texte.lower() for w_ in ("kaufen", "verkaufen", "empfehl", "einsteigen", "aussteigen", "short gehen", "long gehen", "jetzt handeln", "↑", "↓", "➚", "➘", "▲", "▼")))

        # ---------------------------------------------------------------- Speicher, Meldungen, Push
        os.environ["HL_RADAR_DB"] = os.path.join(tmp, "radar.db")
        dbp = os.path.join(tmp, "hl_liq.db")
        con = verbinden(pfad(dbp))
        ok("P1 Speicher: radar.db am umgelenkten Ort, drei Tabellen; ohne Umlenkung neben der Hauptdatenbank; Meta hin und zurück ohne NaN",
           pfad(dbp) == os.path.join(tmp, "radar.db") and {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")} >= {"rd_stand", "rd_alarm", "rd_meta"}
           and (meta_setzen(con, "x", {"a": float("nan"), "b": np.float64(2.5), "c": [np.int64(3)]}) or meta(con, "x") == {"a": None, "b": 2.5, "c": [3]})
           and meta(con, "fehlt", "vorgabe") == "vorgabe" and meta(None, "x", 7) == 7 and lesen(os.path.join(tmp, "gibt_es_nicht.db")) is None)
        os.environ.pop("HL_RADAR_DB")
        ok("P2 Ort ohne Umlenkung: radar.db neben der Hauptdatenbank", pfad("/daten/x/hl_liq.db") == "/daten/x/radar.db")
        os.environ["HL_RADAR_DB"] = os.path.join(tmp, "radar.db")
        ok("P3 Einstellung: Vorgabe Push an, nur BTC, 95. Perzentil; Unbekanntes fällt weg (fremder Coin, anderes Perzentil); Reihenfolge der Coins fest",
           einstellung_lesen(con) == {"push": True, "coins": ["BTC"], "pz": 0.95} and einstellung_pruefen({"coins": ["XMR", "DOGE", "BTC"], "pz": 0.9, "push": 0})
           == {"push": False, "coins": ["BTC", "XMR"], "pz": 0.95} and einstellung_pruefen({"coins": [], "pz": 0.975})["coins"] == []
           and einstellung_pruefen({"pz": "0.99"})["pz"] == 0.99 and einstellung_pruefen("unsinn") == {"push": True, "coins": ["BTC"], "pz": 0.95})
        e_neu = einstellung_setzen(dbp, {"coins": ["BTC", "ETH"], "pz": 0.975, "fremd": 1})
        ok("P4 Einstellung setzen: nur die bekannten Felder, gespeichert und wieder gelesen",
           e_neu == {"push": True, "coins": ["BTC", "ETH"], "pz": 0.975} and einstellung_lesen(con) == e_neu and einstellung_setzen(dbp, {"push": False})["coins"] == ["BTC", "ETH"])
        einstellung_setzen(dbp, {"push": True, "coins": ["BTC"], "pz": 0.95})
        thema = "abcdefghijklmnopqrstuvwxyz0123456"; gesendet = []
        def http_ok(url, rumpf, timeout):
            gesendet.append((url, json.loads(rumpf.decode("utf-8")))); return 200, "ok"
        def http_500(url, rumpf, timeout):
            gesendet.append((url, json.loads(rumpf.decode("utf-8")))); return 500, "kaputt " + thema
        ein = {"thema": thema, "server": "https://ntfy.example.org"}
        ids = meldungen_ablegen(con, M1 + M3 + Mk5, einstellung_lesen(con), jetzt, True)
        fremd = meldungen_ablegen(con, [dict(M1[0], coin="ETH")], einstellung_lesen(con), jetzt, True)
        r1 = push_senden(con, jetzt + 5, http_fn=http_ok, einstellung=ein)
        ok("P5 Push über eine nachgebaute Sendefunktion: drei Meldungen (Alarm 5, Entwarnung 2, Hinweis 3) an die Wurzel des Servers, Thema nur im Rumpf; "
           "für einen nicht gewählten Coin wird nichts abgelegt",
           len(ids) == 3 and fremd == [] and r1 == {"gesendet": 3, "fehler": 0, "aufgegeben": 0} and [g[1]["priority"] for g in gesendet] == [5, 2, 3]
           and all(g[0] == "https://ntfy.example.org/" and g[1]["topic"] == thema for g in gesendet) and gesendet[0][1]["title"] == "Risikoradar BTC: Risiko hoch"
           and gesendet[0][1]["tags"] == ["rotating_light"] and gesendet[1][1]["tags"] == ["information_source"] and thema not in gesendet[0][1]["message"]
           and [r[0] for r in con.execute("SELECT push FROM rd_alarm ORDER BY id")] == [PUSH_GESENDET] * 3
           and push_senden(con, jetzt + 6, http_fn=http_ok, einstellung=ein) == {"gesendet": 0, "fehler": 0, "aufgegeben": 0}, f"{r1} {[g[1]['priority'] for g in gesendet]}")
        gesendet.clear()
        id_f = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 10, True)[0]
        rf = [push_senden(con, jetzt + 10 + i, http_fn=http_500, einstellung=ein) for i in range(1, 7)]
        zf = con.execute("SELECT push, versuche, push_fehler FROM rd_alarm WHERE id=?", (id_f,)).fetchone()
        ok("P6 Fehlversuche: fünf Versuche, dann aufgegeben; der Fehlertext nennt das Thema nicht",
           [r["fehler"] for r in rf] == [1, 1, 1, 1, 1, 0] and rf[5]["aufgegeben"] == 1 and len(gesendet) == 5 and zf[0] == PUSH_AUFGEGEBEN and zf[1] == 5
           and thema not in (zf[2] or "") and "HTTP 500" in (zf[2] or ""), f"{zf}")
        gesendet.clear()
        id_g = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 100, True)[0]
        rg = push_senden(con, jetzt + 100 + 3600, http_fn=http_ok, einstellung=ein)            # genau eine Stunde offen: wird noch gesendet
        n_g = len(gesendet); gesendet.clear()
        id_a = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 100, True)[0]
        ra = push_senden(con, jetzt + 100 + 3601, http_fn=http_ok, einstellung=ein)            # eine Sekunde länger: aufgegeben
        id_n = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 200, True)[0]
        rn = push_senden(con, jetzt + 201, http_fn=http_ok, einstellung={"thema": "", "server": ""})
        ok("P7 eine Meldung, die länger als eine Stunde offen ist, wird nicht mehr gesendet (genau eine Stunde gilt noch); ohne eingerichtetes "
           "Thema wird nichts gesendet",
           rg == {"gesendet": 1, "fehler": 0, "aufgegeben": 0} and n_g == 1 and ra == {"gesendet": 0, "fehler": 0, "aufgegeben": 1} and rn["aufgegeben"] == 1
           and gesendet == [] and con.execute("SELECT push FROM rd_alarm WHERE id IN (?,?,?) ORDER BY id", (id_g, id_a, id_n)).fetchall()
           == [(PUSH_GESENDET,), (PUSH_AUFGEGEBEN,), (PUSH_AUFGEGEBEN,)], f"{rg} {ra} {rn}")
        aus1 = meldungen_ablegen(con, M1, {"push": False, "coins": ["BTC"], "pz": 0.95}, jetzt + 300, True)[0]
        aus2 = meldungen_ablegen(con, M1, {"push": True, "coins": ["BTC"], "pz": 0.95}, jetzt + 300, False)[0]
        ok("P8 Schalter „Push“ aus oder Benachrichtigung nicht eingerichtet: die Meldung steht in der Liste (für Ton und Ansage), gesendet wird nichts",
           con.execute("SELECT push FROM rd_alarm WHERE id IN (?,?)", (aus1, aus2)).fetchall() == [(PUSH_AUS,), (PUSH_AUS,)]
           and push_senden(con, jetzt + 301, http_fn=http_ok, einstellung=ein)["gesendet"] == 0 and gesendet == [])
        # echter Versand über hl_berichte (urllib) an einen Webserver auf diesem Rechner: was wirklich über die Leitung geht
        import http.server
        emp = []; antw = {"status": 200}
        class _Ntfy(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                n_ = int(self.headers.get("Content-Length") or 0)
                emp.append((self.path, self.headers.get("Content-Type"), self.rfile.read(n_)))
                self.send_response(antw["status"]); self.send_header("Content-Length", "2"); self.end_headers(); self.wfile.write(b"{}")
            def log_message(self, *a_):
                pass
        nt = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Ntfy)
        threading.Thread(target=nt.serve_forever, daemon=True).start()
        try:
            ein_l = {"thema": thema, "server": f"http://127.0.0.1:{nt.server_address[1]}"}
            id_l = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 400, True)[0]
            rl1 = push_senden(con, jetzt + 401, einstellung=ein_l)
            antw["status"] = 500
            id_l2 = meldungen_ablegen(con, M3, einstellung_lesen(con), jetzt + 402, True)[0]
            rl2 = push_senden(con, jetzt + 403, einstellung=ein_l)
            zl2 = con.execute("SELECT push, versuche, push_fehler FROM rd_alarm WHERE id=?", (id_l2,)).fetchone()
        finally:
            nt.shutdown(); nt.server_close()
        rumpf_l = json.loads(emp[0][2].decode("utf-8")) if emp else {}
        ok("P10 echter Versand an einen Webserver auf diesem Rechner (über hl_berichte, ohne nachgebaute Sendefunktion): POST an die Wurzel, "
           "JSON in UTF-8 mit Thema, Titel, Text (Minuszeichen und Umlaute unversehrt), Priorität 5 und Zeichen; Antwort 500 zählt als "
           "Fehlversuch, der Fehlertext nennt das Thema nicht",
           rl1 == {"gesendet": 1, "fehler": 0, "aufgegeben": 0} and len(emp) == 2 and emp[0][0] == "/" and "application/json" in (emp[0][1] or "")
           and rumpf_l == {"topic": thema, "title": "Risikoradar BTC: Risiko hoch", "message": M1[0]["text"], "tags": ["rotating_light"], "priority": 5}
           and "−10 % in 7 Tagen" in rumpf_l["message"] and "üblich" in rumpf_l["message"] and "−10 %".encode("utf-8") in emp[0][2]
           and con.execute("SELECT push FROM rd_alarm WHERE id=?", (id_l,)).fetchone()[0] == PUSH_GESENDET
           and rl2 == {"gesendet": 0, "fehler": 1, "aufgegeben": 0} and zl2[0] == PUSH_OFFEN and zl2[1] == 1 and "HTTP 500" in (zl2[2] or "")
           and thema not in (zl2[2] or ""), f"{rl1} {rl2} {zl2} {len(emp)} Anfragen")
        con.execute("DELETE FROM rd_alarm WHERE id IN (?,?)", (id_l, id_l2))
        ml = meldungen_lesen(con, 3)
        ok("P9 Liste der Meldungen für die Karte: die jüngsten zuerst, mit Art, Text, Ansage und dem Stand des Push in Worten",
           len(ml) == 3 and ml[0]["id"] == aus2 and ml[0]["push"] == "kein Push" and ml[2]["push"] == "Push nicht gesendet" and ml[0]["art"] == "alarm"
           and ml[0]["ansage"].startswith("Risikoradar. Bitcoin.") and meldungen_lesen(None) == [])

        # ---------------------------------------------------------------- Takt
        con.execute("DELETE FROM rd_alarm"); gesendet.clear()
        aufrufe = []; rb_starts = []; stufe_jetzt = {"BTC": ("hoch", 0.66)}
        zust_e7 = lambda coin_: ((meta(con, "zustand") or {}).get(coin_) or {}).get("e7") or {}   # noqa: E731 -- fehlt der Zustand, scheitert die Probe (kein Abbruch)
        def stand_fn(db, coin, jetzt_, gemeinsam=None, rb=None, zust=None, einst=None, con_r=None):
            aufrufe.append((coin, gemeinsam, bool(rb), dict(zust or {}).get("e7", {}).get("hoch")))
            if coin == "ZEC":
                raise RuntimeError("Probe-Fehler")
            st_, p_ = stufe_jetzt.get(coin, ("normal", 0.1))
            return _probe_stand(coin, jetzt_, p_, st_)
        gem = lambda db, j: {"gemeinsam": j}                                   # noqa: E731
        _TAKT["letzter_rueckblick_start"] = 0.0
        t1 = takt_schritt(dbp, con, jetzt, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: rb_starts.append(d) or True, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T1 erster Schritt: alle fünf Coins gerechnet und abgelegt (volle Stunde neu), der Rückblick wird gestartet (noch keiner da), "
           "ein Fehler bei einem Coin hält die anderen nicht auf",
           t1["coins"] == ["BTC", "ETH", "HYPE", "XMR"] and t1["abgelegt"] == 4 and t1["rueckblick_gestartet"] is True and rb_starts == [dbp]
           and len(t1["fehler"]) == 1 and t1["fehler"][0].startswith("ZEC: RuntimeError: Probe-Fehler") and [a[0] for a in aufrufe] == list(COINS)
           and all(a[1] == {"gemeinsam": jetzt} for a in aufrufe) and con.execute("SELECT COUNT(*) FROM rd_stand").fetchone()[0] == 4, f"{t1}")
        zeile = con.execute("SELECT stunde, ts, p7, p2, idx, a5, a6, json FROM rd_stand WHERE coin='BTC'").fetchone()
        ok("T2 Ablage je Stunde: p7, p2, Index, Rohwerte von A5 und A6 und der Stand in Kurzform",
           zeile[0] == jetzt // 3600 and zeile[1] == jetzt and zeile[2] == 0.66 and zeile[3] == 0.02 and zeile[4] == 62.0 and zeile[5] == 1.5 and zeile[6] == 4.0e6
           and json.loads(zeile[7])["e"]["e7"] == {"p": 0.66, "stufe": "hoch", "x": 0.10} and json.loads(zeile[7])["achsen"]["a1"] == 97.0
           and json.loads(zeile[7])["konten"] == 2.0, f"{zeile[:7]}")
        ok("T3 Alarm im Takt: BTC beginnt „hoch“ -> eine Meldung abgelegt und gesendet (Priorität 5); Zustand gespeichert",
           t1["meldungen"] == 1 and t1["push"]["gesendet"] == 1 and [g[1]["priority"] for g in gesendet] == [5] and zust_e7("BTC").get("hoch") is True
           and zust_e7("ETH").get("hoch") is False and (meta(con, "takt") or {}).get("ts") == jetzt and meta(con, "letzte_ablage") == jetzt // 3600)
        aufrufe.clear()
        t2 = takt_schritt(dbp, con, jetzt + 300, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: rb_starts.append(d) or True, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T4 zweiter Schritt in derselben Stunde: nur die gewählten Coins (BTC), nichts abgelegt, kein zweiter Alarm, der Vorzustand geht in den Stand ein; "
           "der Rückblick wird binnen 6 Stunden nicht noch einmal gestartet",
           t2["coins"] == ["BTC"] and t2["abgelegt"] == 0 and t2["meldungen"] == 0 and aufrufe == [("BTC", {"gemeinsam": jetzt + 300}, False, True)]
           and t2["rueckblick_gestartet"] is False and len(rb_starts) == 1 and len(gesendet) == 1, f"{t2} {aufrufe}")
        stufe_jetzt["ETH"] = ("hoch", 0.7); stufe_jetzt["BTC"] = ("normal", 0.2); aufrufe.clear()
        t3 = takt_schritt(dbp, con, jetzt + 3600, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: False, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T5 nächste Stunde: wieder alle Coins abgelegt; BTC endet -> Entwarnung gesendet (Priorität 2); ETH beginnt „hoch“, ist aber nicht gewählt: "
           "Zustand läuft mit, keine Meldung",
           t3["abgelegt"] == 4 and t3["meldungen"] == 1 and [g[1]["priority"] for g in gesendet] == [5, 2] and zust_e7("ETH").get("hoch") is True
           and zust_e7("BTC").get("hoch") is False and con.execute("SELECT COUNT(*) FROM rd_alarm").fetchone()[0] == 2
           and con.execute("SELECT COUNT(*) FROM rd_stand").fetchone()[0] == 8, f"{t3}")
        ok("T6 wann der Rückblick fällig ist: keiner da; andere Fassung; älter als 30 Tage (genau 30 Tage noch nicht); nicht binnen 6 Stunden "
           "nach dem letzten Start (genau 6 Stunden danach wieder)",
           rueckblick_faellig(None, 1e9, 0) and rueckblick_faellig({"version": "alt", "stand": 1e9}, 1e9, 0)
           and rueckblick_faellig({"version": VERSION_MODUL, "stand": 1e9 - 30 * 86400 - 1}, 1e9, 0)
           and not rueckblick_faellig({"version": VERSION_MODUL, "stand": 1e9 - 30 * 86400}, 1e9, 0)
           and not rueckblick_faellig(None, 1e9, 1e9 - 6 * 3600 + 1) and rueckblick_faellig(None, 1e9, 1e9 - 6 * 3600))
        al = alle_stufen(con, "BTC", _probe_stand("BTC", jetzt + 3700, 0.3, "erhoeht"))
        ok("T7 Zeile „alle Coins“: der gewählte Coin aus dem frischen Stand, die anderen aus der letzten Ablage; ein Coin ohne Ablage ohne Stufe",
           [a["coin"] for a in al] == list(COINS) and al[0]["stufe"] == "erhoeht" and al[0]["p_text"] == "30 %" and al[1]["stufe"] == "hoch" and al[1]["p_text"] == "70 %"
           and al[3]["stufe"] == "ohne" and al[3]["p_text"] == "—" and al[3]["stufe_wort"] == "ohne Stufe", f"{[(a['coin'], a['stufe']) for a in al]}")
        # Ein Coin, der nicht gewählt ist: der Zustand läuft mit, aber nichts gilt als gemeldet
        Zn1, Mn1 = alarm_schritt(None, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=2.5), jetzt, melden=False)
        Zn2, Mn2 = alarm_schritt(Zn1, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 300, melden=False)
        Zn3, Mn3 = alarm_schritt(Zn2, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 600)       # jetzt gewählt, schon hoch: kein Alarm nachträglich
        Zn4, Mn4 = alarm_schritt(Zn3, _probe_stand("ETH", jetzt, 0.2, "normal", konten=2.5), jetzt + 900)    # Ende: keine Entwarnung ohne Alarm
        Zn5, Mn5 = alarm_schritt(Zn4, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 1200)     # neuer Beginn: Alarm und Hinweis, keine Sperrzeit
        Zn6, Mn6 = alarm_schritt(Zn5, _probe_stand("ETH", jetzt, 0.2, "normal", konten=3.2), jetzt + 1500, melden=False)   # abgewählt: Ende ohne Entwarnung
        ok("M11 ein Coin, der nicht für Meldungen gewählt ist: „hoch“ und die Kontenquote laufen mit, aber ohne Meldung, ohne Sperrzeit und ohne "
           "spätere Entwarnung; wird er dazugeschaltet, kommt der Alarm erst beim nächsten Beginn",
           Mn1 == [] and Zn1["e7"] == {"hoch": True, "seit": jetzt, "alarm_ts": 0, "gemeldet": False} and Mn2 == [] and Zn2["konten"] == {"scharf": False, "hinweis_ts": 0}
           and Mn3 == [] and Mn4 == [] and Zn4["e7"]["hoch"] is False and [m["art"] for m in Mn5] == ["alarm", "hinweis"] and Zn5["e7"]["alarm_ts"] == jetzt + 1200
           and Mn6 == [] and Zn6["e7"]["hoch"] is False and Zn6["e7"]["gemeldet"] is False, f"{Zn1['e7']} {[m['art'] for m in Mn5]}")
        a5v = a5_verlauf(con, "BTC", jetzt + 3700)
        ok("T8 eigener Verlauf von A5: die abgelegten Rohwerte des Coins", a5v == [1.5, 1.5] and a5_verlauf(None, "BTC", jetzt) == [])
        stufe_jetzt["ETH"] = ("normal", 0.1); con.execute("DELETE FROM rd_alarm"); gesendet.clear()
        meta_setzen(con, "einstellung", {"push": True, "coins": ["BTC", "ETH"], "pz": 0.95})
        t4 = takt_schritt(dbp, con, jetzt + 7200, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: False, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T9 ETH war „hoch“, ohne gewählt zu sein, wird dann gewählt und endet: keine Entwarnung (es gab keinen Alarm), nichts gesendet",
           t4["meldungen"] == 0 and gesendet == [] and zust_e7("ETH") == {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False}
           and con.execute("SELECT COUNT(*) FROM rd_alarm").fetchone()[0] == 0, f"{t4}")
        meta_setzen(con, "einstellung", {"push": True, "coins": ["BTC"], "pz": 0.95})
        con.close()
        alt_hr = os.environ.get("HL_RADAR"); alt_takt = (_TAKT["gestartet"], _TAKT["stop"])
        try:
            _TAKT["gestartet"] = False; _TAKT["stop"] = None
            os.environ["HL_RADAR"] = "0"
            aus_s = starten(os.path.join(tmp, "aus.db")); aus_t = starte(os.path.join(tmp, "aus.db")); aus_g = _TAKT["gestartet"]
            os.environ.pop("HL_RADAR")
            st_s = starten("/probe/_selftest.db"); st_g = _TAKT["gestartet"]
            los = starten(os.path.join(tmp, "dienst.db")); los_g = _TAKT["gestartet"]; los_stop = _TAKT["stop"]; nochmal = starten(os.path.join(tmp, "dienst.db"))
            if los_stop is not None:
                los_stop.set()                                           # der Faden wartet 90 s auf seinen ersten Schritt: gleich wieder anhalten
            ok("D1 Dienst: nicht für Selbsttest-Datenbanken; aus mit HL_RADAR=0 (nichts gestartet, nichts gemerkt); nicht ohne Datenbank; "
               "sonst startet er genau einmal",
               st_s is False and st_g is False and starte(":memory:") is None and starte("") is None and aus_s is False and aus_t is None and aus_g is False
               and los is True and los_g is True and los_stop is not None and nochmal is False and _TAKT["stop"] is los_stop)
            _TAKT["gestartet"] = False; _TAKT["stop"] = None
            ev_f = threading.Event(); rufe_f = []

            def schritt_probe(db_, con_):
                rufe_f.append((db_, con_, con_.execute("SELECT COUNT(*) FROM rd_meta").fetchone()[0]))
                if len(rufe_f) == 1:
                    raise RuntimeError("Probe-Fehler im Schritt")
                if len(rufe_f) == 2:
                    raise sqlite3.OperationalError("Probe: Datenbank gesperrt")
                ev_f.set()
            puf_f = io.StringIO()
            with contextlib.redirect_stdout(puf_f):
                fd_ = starte(dbp, stop=ev_f, verzoegerung=0.0, schritt=schritt_probe, takt_s=0.01)
                if fd_ is not None:
                    fd_.join(20)
            ev_n = threading.Event(); ev_n.set()
            fd_n = starte(dbp, stop=ev_n, verzoegerung=30.0, schritt=lambda db_, con_: rufe_f.append("nie"))
            if fd_n is not None:
                fd_n.join(20)
            ok("D2 Faden „radar“: läuft als Daemon mit eigener Verbindung zu radar.db; ein Fehler im Schritt beendet ihn nicht (gemeldet in der "
               "Ausgabe, nächster Schritt mit derselben Verbindung); nach einem Fehler der Datenbank öffnet er eine neue Verbindung; "
               "wird er vor dem ersten Schritt angehalten, rechnet er nicht",
               fd_ is not None and not fd_.is_alive() and fd_.name == "radar" and fd_.daemon is True and len(rufe_f) == 3
               and all(r_[0] == dbp and r_[2] >= 1 for r_ in rufe_f) and rufe_f[1][1] is rufe_f[0][1] and rufe_f[2][1] is not rufe_f[1][1]
               and "Risikoradar: RuntimeError: Probe-Fehler im Schritt" in puf_f.getvalue()
               and "Risikoradar: OperationalError: Probe: Datenbank gesperrt" in puf_f.getvalue() and _TAKT["fehler"] is None
               and fd_n is not None and not fd_n.is_alive(), f"{len(rufe_f)} Schritte; {puf_f.getvalue().strip().splitlines()}")
        finally:
            if _TAKT["stop"] is not None and _TAKT["stop"] is not alt_takt[1]:
                _TAKT["stop"].set()
            _TAKT["gestartet"], _TAKT["stop"] = alt_takt
            if alt_hr is None:
                os.environ.pop("HL_RADAR", None)
            else:
                os.environ["HL_RADAR"] = alt_hr

        # ---------------------------------------------------------------- Rückblick
        tau_ = np.arange(0, 400) * TAG; ja_ = (np.arange(400) % 10 == 0).astype(float)
        g_ = grundrate_laufend(tau_, ja_, 7)
        ok("R1 laufende Grundrate: nur Ursprünge, deren Frist abgelaufen war (7 Tage), mindestens 100; von Hand an zwei Stellen",
           np.isnan(g_[:106]).all() and abs(g_[106] - 10 / 100) < 1e-12 and abs(g_[399] - 40 / 393) < 1e-12 and np.isnan(grundrate_laufend(tau_[:50], ja_[:50], 7)).all(),
           f"{g_[106]} {g_[399]}")
        rng = np.random.default_rng(7)
        nA = 4 * 700; tauA = AU.OOS_AB - 200 * TAG + np.arange(nA) * 6 * 3600
        rr = rng.normal(0, 0.012, nA) * (1 + 0.8 * np.sin(np.arange(nA) / 300.0))
        lcA = np.log(100.0) + np.cumsum(rr); CA = np.exp(lcA)
        HA = CA * np.exp(np.abs(rng.normal(0, 0.01, nA))); LA_ = CA * np.exp(-np.abs(rng.normal(0, 0.012, nA)))
        A_ = {"tau": tauA, "C": CA, "H": HA, "L": LA_, "n": nA}
        Fk_ = np.outer(0.0006 * (1 + 0.8 * np.sin(np.arange(nA) / 300.0)) ** 2, np.arange(1, AU.K_MAX + 1))
        alt_lib = AU.LIB_AB
        try:
            AU.LIB_AB = int(tauA[0])
            B_ = AU.bibliothek(A_, Fk_, "BTC")
        finally:
            AU.LIB_AB = alt_lib
        Rc = rueckblick_coin(A_, Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
        abw = []
        for i_ in (0, len(Rc["tau"]) // 2, len(Rc["tau"]) - 1):
            j_ = int(np.searchsorted(tauA, Rc["tau"][i_]))
            S_ = AU.szenarien(B_, AU.bib_bis(B_, int(tauA[j_])), Fk_[j_])
            gr_ = lambda v_: min(max(v_, 0.005), 0.995)                 # noqa: E731 -- wie die Anzeige: Raster 0,5 % bis 99,5 %
            abw.append(abs(gr_(AU.erreichen(S_, math.log(0.9), 7)[0]) - Rc["p7"][i_]) + abs(gr_(AU.erreichen(S_, math.log(0.93), 2)[0]) - Rc["p2"][i_]))
            lo7 = np.nanmin(np.log(LA_[j_ + 4: j_ + 29: 4])) - lcA[j_]; lo2 = np.nanmin(np.log(LA_[j_ + 4: j_ + 9: 4])) - lcA[j_]
            abw.append(abs(float(lo7 <= math.log(0.9)) - Rc["ja7"][i_]) + abs(float(lo2 <= math.log(0.93)) - Rc["ja2"][i_]))
        ok("R2 Rückblick eines Coins gegen den Ausblick selbst: p7 und p2 an drei Ursprüngen gleich hl_ausblick.szenarien/erreichen; "
           "eingetreten = kleinstes Tief der Tagesblöcke der nächsten 7 bzw. 2 Tage, von Hand",
           len(Rc["tau"]) > 300 and max(abw) < 1e-12 and all(int(t) % TAG == 0 and t >= AU.OOS_AB for t in Rc["tau"]) and Rc["ohne_faktor"] == 0
           and 0 < Rc["ja7"].mean() < 1 and Rc["ja2"].sum() <= Rc["ja7"].sum(), f"{len(Rc['tau'])} Ursprünge, größte Abweichung {max(abw):.2e}, Quote {Rc['ja7'].mean():.3f}")
        i0 = next((i_ for i_ in range(1, len(Rc["tau"])) if Rc["ja7"][i_] == 0 and Rc["ja7"][i_ - 1] == 0 and Rc["ja2"][i_] == 0 and Rc["ja2"][i_ - 1] == 0
                   and Rc["tau"][i_] - Rc["tau"][i_ - 1] == TAG), None)
        if i0 is not None:
            j0 = int(np.searchsorted(tauA, Rc["tau"][i0]))
            L7_ = LA_.copy(); L7_[j0 + 28] = CA[j0] * 0.5                    # ein Tief von −50 % genau im siebten Tagesblock nach dem Ursprung
            L2_ = LA_.copy(); L2_[j0 + 8] = CA[j0] * 0.5                     # … genau im zweiten Tagesblock
            R7_ = rueckblick_coin(dict(A_, L=L7_), Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
            R2_ = rueckblick_coin(dict(A_, L=L2_), Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
        ok("R14 Fristen des Rückblicks von Hand: ein Tief im siebten Tagesblock zählt für 7 Tage, für den Ursprung des Vortags (achter Block) nicht; "
           "ein Tief im zweiten Block zählt für 48 Stunden, für den Ursprung des Vortags (dritter Block) nur für 7 Tage; die Zahlen selbst ändern sich nicht",
           i0 is not None and len(R7_["tau"]) == len(Rc["tau"]) and R7_["ja7"][i0] == 1 and R7_["ja7"][i0 - 1] == 0 and R7_["ja2"][i0] == 0
           and R2_["ja2"][i0] == 1 and R2_["ja7"][i0] == 1 and R2_["ja2"][i0 - 1] == 0 and R2_["ja7"][i0 - 1] == 1
           and np.array_equal(R7_["p7"], Rc["p7"]) and np.array_equal(R2_["p2"], Rc["p2"]), f"Ursprung {i0}")
        Rf = rueckblick_coin(A_, Fk_, B_, lambda tag: (None if tag % 2 else 1.5), AU.JE_TAG, AU.OOS_AB)
        Rsp = rueckblick_coin(A_, Fk_, B_, lambda tag: 1.0, AU.JE_TAG, int(tauA[-1]) + TAG)
        Rgr = rueckblick_coin(A_, Fk_, B_, lambda tag: 8.0, AU.JE_TAG, AU.OOS_AB)                # Schwelle −80 %: kein Szenario erreicht sie
        ok("R13 Rückblick wie die Anzeige: Die Zahl ist auf das Raster 0,5 % bis 99,5 % begrenzt -- erreicht kein Szenario die Schwelle, zählt der "
           "Ursprung mit 0,5 % (nicht mit 0); nichts liegt außerhalb",
           len(Rgr["tau"]) == len(Rc["tau"]) and float(Rgr["p7"].max()) == 0.005 == float(Rgr["p7"].min()) and Rgr["ja7"].sum() == 0
           and Rc["p7"].min() >= 0.005 and Rc["p7"].max() <= 0.995 and Rc["p2"].min() >= 0.005 and (Rc["p2"] == 0.005).any() and AU.LAUF_Q[0] == 0.005
           and AU.LAUF_Q[-1] == 0.995, f"p7 {Rgr['p7'].min()}–{Rgr['p7'].max()}; p2 kleinste {Rc['p2'].min()}")
        ok("R3 Rückblick: ohne Faktor zählt der Ursprung nicht (gezählt als ausgelassen); größerer Faktor -> kleinere Zahl; keine Ursprünge vor dem Beginn",
           Rf["ohne_faktor"] > 100 and len(Rf["tau"]) + Rf["ohne_faktor"] == len(Rc["tau"]) and Rf["p7"].mean() < Rc["p7"].mean() and len(Rsp["tau"]) == 0)
        nG = 6000; tG = np.repeat(np.arange(3000) * TAG, 2); cG = np.tile(np.array(["BTC", "ETH"]), 3000)
        pw = np.clip(rng.beta(1.2, 9.0, nG), 0.002, 0.9); yG = (rng.random(nG) < pw).astype(float); gG = np.full(nG, yG.mean())
        U1 = g_urteil("e7", tG, cG, pw, yG, gG, seed=1)
        U2 = g_urteil("e7", tG, cG, np.clip(pw ** 2 * 4, 0.0005, 0.99), yG, gG, seed=1)        # zu stark gespreizt: Steigung um 0,5
        U3 = g_urteil("e7", tG, cG, rng.permutation(pw), yG, gG, seed=1)                        # ohne Zusammenhang
        pb = np.where(rng.random(nG) < 0.5, 0.02, 0.40); yb = (rng.random(nG) < pb).astype(float); gb = np.full(nG, yb.mean())
        U4 = g_urteil("e7", tG, cG, pb * 1.3, yb, gb, seed=1)                                   # trennt gut, liegt aber im Mittel 1,3-mal zu hoch
        U4k = g_urteil("e7", tG, cG, pb, yb, gb, seed=1)                                        # dieselbe Zahl ohne den Fehler besteht
        U5 = g_urteil("e7", tG[:1200], cG[:1200], pw[:1200], yG[:1200], gG[:1200], seed=1)      # 600 Tage
        ok("R4 Urteil: eine richtig gestufte Zahl besteht (Skill > 0, p < 0,05, Steigung 0,8–1,2, Niveau 0,8–1,25)",
           U1["besteht"] is True and U1["skill"] > 0.02 and U1["p"] < 0.05 and 0.8 <= U1["steigung"] <= 1.2 and 0.8 <= U1["niveau"] <= 1.25 and U1["n"] == nG
           and U1["n_tage"] == 3000 and U1["n_ereignisse"] == int(yG.sum()) and U1["grund"] is None and set(U1["je_coin"]) == {"BTC", "ETH"},
           f"Skill {U1['skill']:.3f}, p {U1['p']:.4f}, Steigung {U1['steigung']:.2f}, Niveau {U1['niveau']:.2f}")
        ok("R5 Urteil fällt durch -- mit dem Grund: zu stark gespreizte Zahl an der Steigung; Zahl ohne Zusammenhang am Skill; im Mittel zu hohe Zahl am Niveau; "
           "600 Tage an der Historie",
           U2["besteht"] is False and "schlägt zu stark aus" in (U2["grund"] or "") and U3["besteht"] is False and "nicht belegbar besser" in (U3["grund"] or "")
           and U4["besteht"] is False and (U4["grund"] or "").startswith("Niveau") and 1.25 < U4["niveau"] < 1.36 and U4["skill"] > 0 and U4["p"] < 0.05
           and 0.8 <= U4["steigung"] <= 1.2 and U4k["besteht"] is True
           and U5["besteht"] is False and "zu wenig Historie" in (U5["grund"] or "") and U5["n_tage"] == 600,
           f"{U2['grund']} | {U3['grund']} | {U4['grund']} | {U5['grund']}")
        nD = 2000; iD = np.arange(nD); yD = (iD % 10 == 0).astype(float)      # jeder zehnte Tag ein Ereignis; Grundrate 0,1
        pD = np.where(iD < 1000, np.where(yD == 1, 0.6, 0.05), np.where(yD == 1, 0.03, 0.26))   # erste Hälfte trifft gut, zweite daneben
        U6 = g_urteil("e7", iD * TAG, np.full(nD, "BTC"), pD, yD, np.full(nD, 0.1), seed=1)
        bg_h = 0.1 * 0.81 + 0.9 * 0.01; bp_h = 0.5 * (0.1 * 0.16 + 0.9 * 0.0025) + 0.5 * (0.1 * 0.9409 + 0.9 * 0.0676)
        ok("R15 Urteil von Hand: Brier der Zahl 0,08659 gegen Brier der Grundrate 0,09 -> Skill +3,8 %; der Vorsprung kommt nur aus der ersten "
           "Hälfte der Tage und ist nicht belegt (p über 0,05) -> besteht nicht, mit dem Grund",
           abs(U6["brier"] - bp_h) < 1e-12 and abs(U6["brier_grund"] - bg_h) < 1e-12 and abs(U6["skill"] - (1 - bp_h / bg_h)) < 1e-12
           and abs(bp_h - 0.08659) < 1e-12 and U6["p"] is not None and U6["p"] >= 0.05 and U6["besteht"] is False and U6["n_tage"] == 2000
           and U6["n_ereignisse"] == 200 and _drin("nicht belegbar besser", U6["grund"]) and _drin("Skill +3,8 %", U6["grund"]),
           f"Skill {U6['skill']:.4f}, p {U6['p']}, {U6['grund']}")
        zv = U1["zuverlaessigkeit"]
        ok("R6 Zuverlässigkeit in den sechs Klassen: Zahl der Ursprünge summiert sich, vorhergesagt liegt in der Klasse, eingetreten im Band",
           sum(k[2] for k in zv) == nG and all(k[0] <= k[3] < k[1] + 1e-9 for k in zv) and all(k[5] <= k[4] <= k[6] for k in zv) and len(zv) >= 5, f"{[(k[0], k[2]) for k in zv]}")
        ps = np.linspace(0.0, 0.99, 100); js = (np.arange(100) % 4 == 0).astype(float)
        sw = schwellen_bauen(ps, js)
        ok("R7 Grundrate und Schwellen eines Coins: Anteil der Ereignisse; 80., 90., 95., 97,5. und 99. Perzentil der Rückblick-Werte; Niveau = Mittel ÷ Quote; "
           "unter 100 Ursprüngen nichts",
           sw["grundrate"] == 0.25 and abs(sw["q"]["0.8"] - 0.792) < 1e-9 and abs(sw["q"]["0.95"] - 0.9405) < 1e-9 and set(sw["q"]) == {"0.8", "0.9", "0.95", "0.975", "0.99"}
           and abs(sw["niveau"] - 0.495 / 0.25) < 1e-9 and schwellen_bauen(ps[:99], js[:99]) == {"n": 99, "grundrate": None, "q": {}, "niveau": None}, f"{sw}")
        tt = np.arange(0, 20) * TAG
        pp = np.array([0.1, 0.5, 0.45, 0.41, 0.39, 0.2, 0.6, 0.3, 0.5, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.55, 0.5, 0.1, 0.1, 0.1])
        jj = np.array([0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0], dtype=float)
        at = alarm_tabelle(tt, pp, jj, 0.5)
        ok("R8 Tabelle der Alarme von Hand (Schwelle 0,5, Ende unter 0,4): vier Eintritte, sieben Tage „hoch“, ein Treffer; drei Ereignis-Episoden, eine davon gedeckt",
           at["eintritte"] == 4 and at["tage_hoch"] == 7 and at["treffer"] == 1 and at["episoden"] == 3 and at["gedeckt"] == 1
           and abs(at["je_jahr"] - 4 / (19 / 365.25)) < 1e-9 and alarm_tabelle(tt, pp, jj, None)["eintritte"] == 0, f"{at}")
        Rw = {"BTC": {"tau": tG[::2], "p7": pw[::2], "p2": pw[::2] * 0.5, "ja7": yG[::2], "ja2": (rng.random(3000) < pw[::2] * 0.5).astype(float), "ohne_bib": 3, "ohne_faktor": 0},
              "ETH": {"tau": tG[1::2], "p7": pw[1::2], "p2": pw[1::2] * 0.5, "ja7": yG[1::2], "ja2": (rng.random(3000) < pw[1::2] * 0.5).astype(float), "ohne_bib": 0, "ohne_faktor": 5},
              "HYPE": {"tau": np.array([], dtype=np.int64), "p7": np.array([]), "p2": np.array([]), "ja7": np.array([]), "ja2": np.array([]), "ohne_bib": 0, "ohne_faktor": 0}}
        RA = rueckblick_auswerten(Rw)
        ok("R9 Auswertung über alle Coins: zwei Urteile (G7, G2), je Coin und Ereignis Grundrate, Schwellen und Tabelle; ein Coin ohne Ursprünge fehlt",
           set(RA["urteil"]) == {"e7", "e2"} and RA["urteil"]["e7"]["besteht"] is True and set(RA["coins"]) == {"BTC", "ETH"} and RA["urteil"]["e7"]["n"] < nG
           and abs(RA["coins"]["BTC"]["e7"]["grundrate"] - yG[::2].mean()) < 1e-12 and RA["coins"]["BTC"]["e7"]["alarme"]["schwelle"] == RA["coins"]["BTC"]["e7"]["q"]["0.95"]
           and RA["ohne"]["ETH"] == {"bibliothek": 0, "faktor": 5} and rueckblick_auswerten({})["urteil"]["e7"]["besteht"] is False,
           f"G7 {RA['urteil']['e7']['besteht']}, G2 {RA['urteil']['e2']['besteht']}")
        rt = rueckblick_text(dict(RA, stand=jetzt, version=VERSION_MODUL, dauer=12.3, fehlt=["Probe-Hinweis"]))
        ok("R10 Bericht des Rückblicks: Kopf mit den Regeln, je Urteil ein Satz, Zuverlässigkeit, je Coin Grundrate und Schwellen, Lesart; keine Zeile über 150 Zeichen",
           "Rückblick des Grundrisikos" in rt and "== G7" in rt and "== G2" in rt and "— besteht." in " ".join(rt.split()) and "fehlt: Probe-Hinweis" in rt
           and "Zuverlässigkeit" in rt
           and "BTC 7 Tage" in rt and "Lesart:" in rt and max(len(z) for z in rt.split("\n")) <= ZEILE_MAX and "noch nicht gerechnet" in rueckblick_text(None),
           f"längste Zeile {max(len(z) for z in rt.split(chr(10)))}")

        # Sperre: ein Rückblick zur selben Zeit
        sp1 = RbSperre(dbp); sp2 = RbSperre(dbp)
        n1 = sp1.nehmen(); n2 = sp2.nehmen(); belegt = rueckblick_rechnen(dbp, log=lambda *a: None)
        sp1.lassen(); n3 = sp2.nehmen(); sp2.lassen(); sp2.lassen()
        ok("R11 Sperre: während ein Lauf den Rückblick rechnet, rechnet ein zweiter nicht (Antwort „läuft“); nach dem Ende ist sie wieder frei; "
           "die Sperrdatei liegt neben radar.db",
           n1 is True and n2 is False and belegt == {"laeuft": True} and n3 is True and sp1.datei == pfad(dbp) + ".rueckblick.lock"
           and os.path.exists(sp1.datei) and sp1.fd is None and sp2.fd is None, f"{n1} {n2} {belegt} {n3}")
        zeit_ = {"t": 0.0}; logs_ = []; rufe_ = []
        def rechnen_belegt(db, log=None):
            rufe_.append(zeit_["t"])
            return {"laeuft": True}
        cs = verbinden(pfad(dbp))
        cs.execute("DELETE FROM rd_meta WHERE k='rueckblick'")
        h1 = rueckblick_holen(dbp, log=logs_.append, warten_s=12, schlaf=lambda s_: zeit_.__setitem__("t", zeit_["t"] + s_), uhr=lambda: zeit_["t"], rechnen=rechnen_belegt)
        def rechnen_fertig(db, log=None):
            rufe_.append("fertig")
            return {"version": VERSION_MODUL, "stand": jetzt, "neu": True}
        h2 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        meta_setzen(cs, "rueckblick", {"version": VERSION_MODUL, "stand": jetzt, "alt": True})
        h3 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        meta_setzen(cs, "rueckblick", {"version": "2026-09-23.000", "stand": jetzt})
        h4 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        cs.execute("DELETE FROM rd_meta WHERE k='rueckblick'"); cs.close()
        ok("R12 Debug 161 holt den Rückblick: rechnet ein anderer Lauf, wartet er (alle 5 s ein Blick, höchstens die Frist) und meldet dann „nichts“; "
           "fehlt er, rechnet er; liegt einer dieser Fassung vor, liest er nur; einer aus einer anderen Fassung wird neu gerechnet",
           h1 == (None, False, True) and rufe_[:5] == [0.0, 5.0, 10.0, 15.0, "fertig"] and h2 == ({"version": VERSION_MODUL, "stand": jetzt, "neu": True}, True, False)
           and h3 == ({"version": VERSION_MODUL, "stand": jetzt, "alt": True}, False, False) and h4[1] is True and h4[0]["neu"] is True
           and rufe_.count("fertig") == 2 and sum("wartet bis zu 0 Minuten" in l_ for l_ in logs_) == 1
           and sum("rechnet ihn jetzt" in l_ for l_ in logs_) == 3, f"{h1} {rufe_} {len(logs_)}")

        # ---------------------------------------------------------------- Bericht
        S_voll = {"ok": True, "coin": "BTC", "jetzt": jetzt, "kurs": {"px": 60000.0, "ts": jetzt - 30, "frisch": True}, "faktor": {"f": 1.0}, "ereignis": E,
                  "achsen": AX, "index": I4, "treiber": treiber_satz(AX), "warnzeichen": warnzeichen_bauen(Bc)}
        st_ = "\n".join(_umbruch(stand_text(S_voll)))
        ok("X1 Stand eines Coins als Text: Kurs, beide Sätze mit Schwellen und Urteil, Hinweis zum Niveau, acht Achsen, Index, Treiber, Warnzeichen",
           "== BTC · Kurs 60.000 (frisch" in st_ and "Risiko, dass BTC in 7 Tagen 10 % tiefer berührt wird (bei 54.000): 65 %" in st_
           and "Schwellen: erhöht ab 50 %, hoch ab 64 % (endet unter 51 %)" in st_ and "1,37-Fachen" in st_ and st_.count("\n      A") >= 8
           and "Druck-Index 87 von 100" in st_ and "Am höchsten:" in st_ and "Warnzeichen an: Kontenquote Binance 3,45 (ab 3)." in st_
           and max(len(z) for z in st_.split("\n")) <= ZEILE_MAX, st_.split("\n")[1])
        N_ = _probe_nutzlast(jetzt)
        roh_ = json.dumps(_ohne_nan(N_), ensure_ascii=False, allow_nan=False)
        ok("X3 Antwort der Karte: Stand, Einstellung, Meldungen, Stufe je Coin, Wahl der Schwelle, Belege; gültiges JSON ohne NaN; kein Thema, kein Schlüssel",
           N_["ok"] is True and set(N_) >= {"ereignis", "achsen", "index", "treiber", "warnzeichen", "einstellung", "meldungen", "alle", "pz_wahl", "beleg", "takt",
                                          "push_eingerichtet"} and [w_["pz"] for w_ in N_["pz_wahl"]] == [0.95, 0.975, 0.99] and N_["takt"]["laeuft"] is True
           and N_["beleg"]["meldung_alt_s"] == 600 and "NaN" not in roh_ and "thema" not in roh_.lower() and "api_key" not in roh_
           and [a["wert"] is not None for a in N_["achsen"]] == [True] * 8 and N_["index"]["n"] == 5, f"{len(roh_)} Zeichen")
        # ---------------------------------------------------------------- Ende zu Ende auf echten Dateien (kleine Welt, erzeugt)
        import contextlib
        import io
        import subprocess as _sp
        import hl_cockpit as HCe
        tmp_e = tempfile.mkdtemp(prefix="hl_radar_e2e_")
        umg_e = ("HL_RADAR_DB", "HL_HEBEL_DB", "HL_SWING_DB", "HL_AUSBLICK_DB")
        alt_e = {k: os.environ.pop(k, None) for k in umg_e}
        alt_q, alt_g, alt_popen = HCe.quellen_lesen, HCe.gemeinsam_lesen, _sp.Popen
        zl_e = [(57000.0, "long", 5e6, 3), (59999.0, "long", 2e6, 2), (61000.0, "short", 8e6, 2)]
        try:
            _FAKTOR_CACHE.clear(); _LANG_CACHE.clear(); _TIEFE_CACHE.clear()
            dbe = _kleine_welt(tmp_e, jetzt)
            st_e = jetzt // 3600

            alter_e = {"s": 30}

            def q_probe(db_, coin_, jetzt_, gemeinsam=None):
                Q_ = HCe._probe_quellen(jetzt_, coin_)
                Q_["kurs"] = {"px": 60000.0 if coin_ == "BTC" else 2000.0, "ts": jetzt_ - alter_e["s"]}
                Q_["liqdichte"] = {"ts": jetzt_ - 600, "zeilen": zl_e, "fehlt": [], "abdeckung": {"anteil": 0.29}}
                return Q_
            HCe.quellen_lesen = q_probe; HCe.gemeinsam_lesen = lambda db_, j_: {"probe": True}
            hc_ = HCe._ro(dbe)
            TS = tiefen_stunden(hc_, jetzt); TB = tiefe_lesen(hc_, "BTC", jetzt); TE = tiefe_lesen(hc_, "ETH", jetzt)
            hc_.close()
            ok("E1 Stundenmittel der Gebote bis −1 % aus beiden Tabellen: 299 Stunden aus dem 5-s-Raster (je das Mittel ihrer Zeilen), die Stunde "
               "davor aus den Zeilen der letzten 60 Minuten, 51 ältere aus den Minutenmitteln; steht eine Stunde in beiden, zählt das 5-s-Raster; "
               "älter als 30 Tage, die laufende Stunde und Zeilen ohne Gebot zählen nicht; je Coin getrennt",
               len(TS["BTC"]) == 351 and TS["BTC"][st_e - 10] == 1e6 + 1e5 and TS["BTC"][st_e - 300] == 4e6 and TS["BTC"][st_e - 350] == 5e6
               and TS["BTC"][st_e - 400] == 5e6 and st_e not in TS["BTC"] and (st_e - 30 * 24 - 5) not in TS["BTC"] and max(TS["BTC"].values()) == 5e6
               and abs(TS["BTC"][st_e - 1] - 2.0e6) < 1e-6 and len(TS["ETH"]) == 300 and set(TS["ETH"].values()) == {7e5},
               f"{len(TS['BTC'])} Stunden BTC, {len(TS['ETH'])} ETH; größter Wert {max(TS['BTC'].values()):.0f}")
            hl_ = sqlite3.connect(os.path.join(tmp_e, "leer.db")); TL = tiefe_lesen(hl_, "BTC", jetzt); hl_.close()
            ok("E2 Gebote der letzten 60 Minuten: Mittel der 70 Zeilen (2,0 Mio.) -- die Zeile von genau vor 60 Minuten, die ohne Gebot und die aus "
               "der Zukunft zählen nicht; unter 60 Zeilen kein Wert, mit Grund; ohne die Tabelle der Grund „fehlt“; ohne Datenbank der Grund",
               TB["usd"] == 2.0e6 and TB["n"] == 70 and TB["fehlt"] is None and len(TB["stunden"]) == 351 and TE["usd"] is None and TE["n"] == 5
               and "nur 5 Werte (gebraucht werden 60)" in TE["fehlt"] and TL["usd"] is None and "Tabelle book_summary fehlt" in TL["fehlt"]
               and "Datenbank des Recorders fehlt" in tiefe_lesen(None, "BTC", jetzt)["fehlt"], f"{TB['usd']} {TB['n']} | {TE['fehlt']} | {TL['fehlt']}")
            Ke = kerzen_lesen(dbe, ("BTC", "ETH", "XMR")); Kab = kerzen_lesen(dbe, ("ETH",), jetzt // TAG - 10)
            ok("E3 Tageskerzen aus hebel.db: je Coin 420 Schlüsse des Perpetuals mit Umsatz und Taker-Kauf; Spot als Summe der Paare je Tag "
               "(400 + 100 = 500, Taker 0,52 · 500 = 260); fehlt einem Paar an einem Tag die Taker-Angabe, hat der Tag keinen Taker-Wert "
               "(nicht die Teilsumme); ein Coin ohne Kerzen fehlt; „ab Tag“ schneidet ab",
               set(Ke) == {"BTC", "ETH"} and len(Ke["ETH"]["tag"]) == 420 and Ke["ETH"]["tag"][-1] == jetzt // TAG - 1 and Ke["ETH"]["pv"][0] == 1000.0
               and Ke["ETH"]["pt"][0] == 520.0 and len(Ke["ETH"]["stag"]) == 420 and abs(Ke["ETH"]["sv"][0] - 500.0) < 1e-9 and abs(Ke["ETH"]["st"][0] - 260.0) < 1e-9
               and abs(Ke["ETH"]["st"][-1] - 240.0) < 1e-9 and math.isnan(Ke["ETH"]["st"][220]) and abs(Ke["ETH"]["sv"][220] - 500.0) < 1e-9
               and Ke["ETH"]["stag"][220] == jetzt // TAG - 200 and not math.isnan(Ke["ETH"]["st"][219]) and len(Ke["BTC"]["stag"]) == 0 and len(Kab["ETH"]["tag"]) == 10 and len(Kab["ETH"]["stag"]) == 10,
               f"{sorted(Ke)}; ETH {len(Ke['ETH']['tag'])} Tage, Spot {Ke['ETH']['sv'][0]} / {Ke['ETH']['st'][0]}")
            fe = faktor(dbe, "ETH", jetzt); fe2 = faktor(dbe, "ETH", jetzt); fb = faktor(dbe, "BTC", jetzt); fx = faktor(dbe, "XMR", jetzt)
            ok("E4 Faktor aus der Datei: ETH schwankt doppelt so stark wie BTC -> 2,00 aus 365 gemeinsamen Tagen vor dem Monatsersten (01.11.2026); "
               "der zweite Aufruf kommt aus dem Speicher; BTC 1; ein Coin ohne Kerzen bekommt den Grund",
               fe["f"] == 2.0 and fe["n"] == 365 and fe["stichtag"] == monatserster(jetzt // TAG) and fe2 is fe and fb["f"] == 1.0 and fx["f"] is None
               and "fehlen Tagesschlüsse" in fx["grund"] and _tag_txt(fe["stichtag"]) == "01.11.2026", f"{fe}")
            LE = lange_achsen(dbe, "ETH", jetzt); LB_ = lange_achsen(dbe, "BTC", jetzt); LX = lange_achsen(dbe, "XMR", jetzt)
            ok("E5 Tagesachsen aus den Dateien: Funding der letzten 7 Tage 3 · 0,02 % · 365 = 21,9 % im Jahr, höher als an allen Tagen davor "
               "(Perzentil 1); Spot-Saldo ETH (2 · 240 − 500) ÷ 500 = −4 %, tiefer als an allen Tagen davor (Perzentil 0); Schwankung gestiegen; "
               "Stand ist der Vortag; BTC ohne Spot-Kerzen: grau mit Grund; ein Coin ohne Kerzen: alles grau",
               abs(LE["a3"]["roh"] - 0.219) < 1e-9 and LE["a3"]["pz"] == 1.0 and abs(LE["a4"]["roh"] + 0.04) < 1e-9 and LE["a4"]["pz"] == 0.0
               and LE["a7"]["pz"] is not None and LE["a7"]["pz"] > 0.9 and LE["a3"]["tag"] == jetzt // TAG - 1 and LE["a3"]["grau"] is None
               and LB_["a4"]["pz"] is None and "keine Spot-Kerzen von Binance" in LB_["a4"]["grau"] and abs(LB_["a3"]["roh"] - 0.219) < 1e-9
               and all(LX[k]["grau"] == "Für diesen Coin fehlen Tageskerzen in hebel.db." for k in ("a3", "a4", "a7")) and lange_achsen(dbe, "ETH", jetzt) is LE,
               f"A3 {LE['a3']['roh']} pz {LE['a3']['pz']}; A4 {LE['a4']['roh']} pz {LE['a4']['pz']}; A7 pz {LE['a7']['pz']}")
            SB = stand(dbe, "BTC", jetzt); SE = stand(dbe, "ETH", jetzt)
            axb = {a["key"]: a for a in SB["achsen"]}; axe = {a["key"]: a for a in SE["achsen"]}
            p7_hand = AU.erreichen_aus_lauf(_probe_lauf(jetzt)["h"], math.log(0.9), 7)[0]
            p7e_hand = AU.erreichen_aus_lauf(_probe_lauf(jetzt)["h"], math.log(1 - 0.10 * 2.0), 7)[0]
            ok("E6 Stand aus den Dateien (das Cockpit liefert Kurs, Messwerte und Heatmap aus seiner Probe): BTC p7 aus der abgelegten Verteilung "
               "am Abstand −10 %, ETH am Abstand −20 % (Faktor 2,00, Schwelle 1.600); A5 = 7 Mio. ÷ 2 Mio. = 3,5-mal die Gebote, Perzentil gegen "
               "340 eigene Stundenwerte (35,5 von 340 -> 10); A6 = 100 − 99 von 351 -> 72; ETH ohne eigene Stundenwerte und ohne 60 Zeilen: beide "
               "grau mit Grund; der Trend-Hinweis steht nur, wo die Rechnung desselben Ankers einen Trend trägt (ETH)",
               SB["ok"] and abs(SB["ereignis"]["e7"]["p"] - p7_hand) < 1e-12 and SB["ereignis"]["e7"]["kurs_schwelle"] == 54000.0 and SB["faktor"]["f"] == 1.0
               and abs(SE["ereignis"]["e7"]["p"] - p7e_hand) < 1e-12 and SE["ereignis"]["e7"]["x_text"] == "20 %" and SE["ereignis"]["e7"]["kurs_schwelle"] == 1600.0
               and SE["ereignis"]["e7"]["p"] < SB["ereignis"]["e7"]["p"] and SB["a5_roh"] == 3.5 and axb["a5"]["wert"] == 10.0 and SB["a6_roh"] == 2.0e6
               and axb["a6"]["wert"] == 72.0 and axb["a3"]["wert"] == 100.0 and axb["a4"]["wert"] is None and axe["a4"]["wert"] == 100.0
               and axe["a5"]["wert"] is None and "nur 5 Werte" in axe["a5"]["grau"] and axe["a6"]["wert"] is None
               and SB["trend"] is None and SE["trend"] is not None and "7 Tage +0,12 σ" in SE["trend"] and SB["ereignis"]["e7"]["stufe"] == "ohne"
               and "noch nicht gerechnet" in SB["ereignis"]["e7"]["urteil"],
               f"BTC p7 {SB['ereignis']['e7']['p']:.4f}, ETH {SE['ereignis']['e7']['p']:.4f}; A5 {axb['a5']['wert']} A6 {axb['a6']['wert']}; ETH A5 {axe['a5']['grau']}")
            alter_e["s"] = 301; SBa = stand(dbe, "BTC", jetzt); alter_e["s"] = 300; SBg = stand(dbe, "BTC", jetzt); alter_e["s"] = 30
            axa = {a["key"]: a for a in SBa.get("achsen") or []}
            ok("E11 Kurs im Stand: älter als 5 Minuten -> beide Zahlen und die Liquidations-Nähe nennen den Grund statt eines Werts, der Kurs "
               "gilt als nicht frisch; genau 5 Minuten alt gilt noch",
               SBa["ok"] and SBa["kurs"]["frisch"] is False and SBa["ereignis"]["e7"]["p"] is None and SBa["ereignis"]["e2"]["p"] is None
               and _drin("Kein frischer Kurs", SBa["ereignis"]["e7"]["fehlt"]) and (axa.get("a5") or {}).get("wert") is None
               and _drin("Kein frischer Kurs", (axa.get("a5") or {}).get("grau")) and SBa["ereignis"]["e7"]["kurs_schwelle"] == 54000.0
               and SBg["kurs"]["frisch"] is True and SBg["ereignis"]["e7"]["p"] == SB["ereignis"]["e7"]["p"], f"{SBa['ereignis']['e7']['fehlt']}")
            Ne = nutzlast(dbe, "BTC", jetzt); roh_e = payload_json(dbe, "BTC", jetzt).decode("utf-8"); Mj = json.loads(meldungen_json(dbe).decode("utf-8"))
            puf = io.StringIO()
            with contextlib.redirect_stdout(puf):
                rc_t = haupt(["--text", "--coin", "ETH", "--db", dbe])
            te = puf.getvalue()
            ok("E7 Antwort der Karte und Debug 160 aus den Dateien: gültiges JSON ohne NaN mit Stand, Einstellung, Meldungen und der Zeile „Stufe je "
               "Coin“; der Bericht (hl_radar.py --text --coin ETH) nennt Faktor, beide Sätze, die Achsen und die Rechenzeit, keine Zeile über 150 Zeichen",
               Ne["ok"] and Ne["einstellung"] == EINSTELLUNG_VORGABE and Ne["meldungen"] == [] and [a["coin"] for a in Ne["alle"]] == list(COINS)
               and Ne["alle"][0]["p_text"] == SB["ereignis"]["e7"]["p_text"] and json.loads(roh_e)["coin"] == "BTC" and "NaN" not in roh_e
               and Mj == {"ok": True, "meldungen": [], "meldung_alt_s": 600} and rc_t == 0 and "== ETH · Kurs 2.000 (frisch" in te
               and "Faktor gegenüber BTC 2,00" in te and "Risiko, dass ETH in 7 Tagen 20 % tiefer berührt wird (bei 1.600)" in te and "A4 Spot-Nachfrage" in te
               and "enthält einen Trend (7 Tage +0,12 σ)" in te and "Rechenzeit dieses Berichts:" in te and "== BTC" not in te
               and max(len(z_) for z_ in te.split("\n")) <= 150, f"{len(roh_e)} Zeichen JSON; Bericht {len(te.splitlines())} Zeilen")
            # Rückblick auf einer Welt ohne Historie des Ausblicks: kein Urteil, aber ein abgelegtes Ergebnis mit Grund -- und der Bericht dazu
            puf = io.StringIO()
            with contextlib.redirect_stdout(puf):
                rc_r = haupt(["--rueckblick-text", "--db", dbe])
            tr = puf.getvalue()
            cr = lesen(pfad(dbe)); rb_e = meta(cr, "rueckblick"); cr.close()
            sp_e = RbSperre(dbe); frei_e = sp_e.nehmen(); sp_e.lassen()
            puf2 = io.StringIO()
            with contextlib.redirect_stdout(puf2):
                rc_r2 = haupt(["--rueckblick-text", "--db", dbe])
            ok("E8 Debug 161 (hl_radar.py --rueckblick-text) auf einer Welt ohne Historie des Ausblicks: rechnet, legt das Ergebnis mit Fassung "
               "und Zeit in radar.db ab und sagt, warum es kein Urteil gibt (keine Ursprünge); danach ist die Sperre wieder frei; der zweite "
               "Aufruf rechnet nicht noch einmal",
               rc_r == 0 and "rechnet ihn jetzt" in tr and isinstance(rb_e, dict) and rb_e.get("version") == VERSION_MODUL and frei_e is True
               and ((rb_e.get("urteil") or {}).get("e7") or {}).get("besteht") is False
               and _drin("keine Ursprünge", ((rb_e.get("urteil") or {}).get("e7") or {}).get("grund")) and "Rückblick des Grundrisikos" in tr and rc_r2 == 0
               and "rechnet ihn jetzt" not in puf2.getvalue() and "Rückblick des Grundrisikos" in puf2.getvalue()
               and not os.path.exists(pfad(dbe) + ".rueckblick.lock.x") and os.path.exists(pfad(dbe) + ".rueckblick.lock"), f"{rb_e and rb_e.get('fehlt')}")
            # Start des Rückblicks als eigener Prozess: Befehl, Umgebung, kein preexec_fn; kein zweiter, solange der erste läuft
            rufe_p = []

            class _FakePopen:
                def __init__(self, cmd, **kw):
                    rufe_p.append((list(cmd), dict(kw)))

                def poll(self):
                    return None
            _TAKT["proc"] = None
            _sp.Popen = _FakePopen
            try:
                s1_ = _starte_rueckblick(dbe); s2_ = _starte_rueckblick(dbe)
            finally:
                _sp.Popen = alt_popen; _TAKT["proc"] = None
            kw_p = rufe_p[0][1] if rufe_p else {}
            ok("E9 Start des Rückblicks aus dem Takt: eigener Prozess „hl_radar.py --rueckblick --db …“ mit der Umgebung für gesenkte Priorität "
               "(HL_NICE), ohne preexec_fn; Ausgabe in radar_takt.log neben radar.db; solange er läuft, kein zweiter",
               s1_ is True and s2_ is False and len(rufe_p) == 1 and rufe_p[0][0][1:] == [os.path.abspath(__file__), "--rueckblick", "--db", dbe]
               and "preexec_fn" not in kw_p and (kw_p.get("env") or {}).get(AU.NICE_VAR) == str(AU.NICE_KIND)
               and os.path.exists(os.path.join(tmp_e, "radar_takt.log")) and "Start Rückblick" in open(os.path.join(tmp_e, "radar_takt.log")).read(),
               f"{rufe_p[0][0][1:] if rufe_p else None}")
            ev_e = threading.Event(); erg_e = []; ges_e = []

            def schritt_e(db_, con_):
                try:
                    erg_e.append(takt_schritt(db_, con_, jetzt, http_fn=lambda u_, r_, t_: ges_e.append(u_) or (200, "ok"),
                                              push_ein={"thema": "probethemaprobethemaprobethema123", "server": "https://ntfy.example.org"},
                                              starte_rb=lambda d_: False))
                finally:
                    ev_e.set()
            fd_e = starte(dbe, stop=ev_e, verzoegerung=0.0, schritt=schritt_e, takt_s=0.01)
            if fd_e is not None:
                fd_e.join(60)
            ce = lesen(pfad(dbe))
            ze = ce.execute("SELECT stunde, ts, p7, p2, a5, a6, json FROM rd_stand WHERE coin='BTC' AND stunde=?", (st_e,)).fetchone()
            ne_ = ce.execute("SELECT COUNT(*) FROM rd_stand WHERE stunde=?", (st_e,)).fetchone()[0]; takt_e = meta(ce, "takt"); zu_e = meta(ce, "zustand")
            ce.close()
            t_e = erg_e[0] if erg_e else {}
            ok("E10 ein Schritt des Fadens auf den echten Dateien: alle fünf Coins gerechnet und für die Stunde abgelegt (BTC mit p7, p2 und den "
               "Rohwerten von A5 und A6 wie im Stand), Zustand und Zeit des Takts gespeichert; ohne Schwellen keine Meldung, nichts gesendet",
               fd_e is not None and not fd_e.is_alive() and len(erg_e) == 1 and t_e.get("coins") == list(COINS) and t_e.get("abgelegt") == 5
               and t_e.get("fehler") == [] and t_e.get("meldungen") == 0 and ges_e == [] and ne_ == 5 and ze is not None and ze[1] == jetzt
               and abs(ze[2] - SB["ereignis"]["e7"]["p"]) < 1e-12 and abs(ze[3] - SB["ereignis"]["e2"]["p"]) < 1e-12 and ze[4] == 3.5 and ze[5] == 2.0e6
               and json.loads(ze[6])["e"]["e7"]["stufe"] == "ohne" and json.loads(ze[6])["achsen"]["a6"] == 72.0 and (takt_e or {}).get("ts") == jetzt
               and set(zu_e or {}) == set(COINS) and ((zu_e or {}).get("BTC") or {}).get("e7", {}).get("hoch") is False, f"{t_e}")
            tx_l = text(dbe, ("BTC",), jetzt + 900); tx_s = text(dbe, ("BTC",), jetzt + 901)
            ok("E12 steht der Takt (kein Schritt seit mehr als 15 Minuten), sagen es Debug 160 und die Antwort der Karte; genau 15 Minuten "
               "gelten noch als laufend",
               "Takt: zuletzt " + _dt(jetzt) in " ".join(tx_l.split()) and "steht seit" not in tx_l
               and "keine Spot-Kerzen von Binance). · fehlt im Index" in " ".join(tx_l.split()) and " ".join(tx_l.split()).count(" · im Index") == 4
               and " ".join(tx_l.split()).count("fehlt im Index") == 1
               and ("Takt: steht seit " + _dt(jetzt) + " (seit 15 Minuten kein Schritt -- ohne Takt gibt es keinen Alarm; läuft das Dashboard?)") in " ".join(tx_s.split())
               and max(len(z_) for z_ in tx_s.split("\n")) <= 150
               and nutzlast(dbe, "BTC", jetzt + 900)["takt"] == {"ts": jetzt, "laeuft": True}
               and nutzlast(dbe, "BTC", jetzt + 901)["takt"] == {"ts": jetzt, "laeuft": False},
               next((z_.strip() for z_ in tx_s.split("\n") if "steht seit" in z_), "ohne Zeile"))
        except Exception as e_:  # noqa: BLE001
            import traceback
            ok("E Proben auf echten Dateien ohne Ausnahme", False, f"{type(e_).__name__}: {e_} -- {traceback.format_exc().splitlines()[-3].strip()}")
        finally:
            HCe.quellen_lesen, HCe.gemeinsam_lesen = alt_q, alt_g
            _sp.Popen = alt_popen
            for k, v in alt_e.items():
                if v is not None:
                    os.environ[k] = v
            _FAKTOR_CACHE.clear(); _LANG_CACHE.clear(); _TIEFE_CACHE.clear()
            shutil.rmtree(tmp_e, ignore_errors=True)
        # ---------------------------------------------------------------- Vertrag mit dem Paket
        hier = os.path.dirname(os.path.abspath(__file__))
        qu = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py", "hl_cockpit.py", "hl_cockpit_js.py", "hl_recorder.py", "hl_ausblick.py", "KONZEPT_Risikoradar.md"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as fh:
                    qu[n_] = fh.read()
            except OSError:
                qu[n_] = None
        if all(v_ is not None for n_, v_ in qu.items() if n_ != "KONZEPT_Risikoradar.md"):
            ok("VP1 Vertrag mit dem Paket: hl_radar.py und hl_radar_js.py in der Prüfsumme (version.py), mit dem Konzept in Sicherung und "
               "Wiederherstellung (update.py), im Übersetzungs- und in beiden Prüfschritten des Installers und mit drei Adressen in seinem "
               "Dashboard-Schritt; radar.db im täglichen Backup; der "
               "Recorder führt die beiden Tabellen des Orderbuchs mit der Spalte der Gebote bis −1 % (bid_100)",
               '"hl_radar.py", "hl_radar_js.py")' in qu["version.py"] and '"hl_radar.py", "hl_radar_js.py", "KONZEPT_Risikoradar.md"}' in qu["update.py"]
               and 'str(ROOT / "hl_radar.py"), str(ROOT / "hl_radar_js.py"),' in qu["install.py"]
               and '[py, str(ROOT / "hl_radar.py"), "--selbsttest"]' in qu["install.py"] and '[py, str(ROOT / "hl_viz.py"), "--selbsttest-radar"]' in qu["install.py"]
               and all(t_ in qu["install.py"] for t_ in ('("/cockpit/radar?coin=BTC", lambda b:', '("/radar.js", lambda b: b"function rdKarte" in b',
                                                          '("/cockpit/radar/meldungen", lambda b:'))
               and '"engine", "staking", "radar")' in qu["hl_recorder.py"]
               and "CREATE TABLE IF NOT EXISTS book_summary (" in qu["hl_recorder.py"] and "CREATE TABLE IF NOT EXISTS book_summary_1m (" in qu["hl_recorder.py"]
               and "bid_100 REAL, ask_100 REAL," in qu["hl_recorder.py"] and "bid_50 REAL, ask_50 REAL, bid_100 REAL, ask_100 REAL, imb_50 REAL, PRIMARY KEY (ts, coin));" in qu["hl_recorder.py"],
               ", ".join(n_ for n_, q_ in qu.items() if q_ and "hl_radar" in q_))
            ok("VP2 Vertrag mit dem Dashboard: Adressen /cockpit/radar, /cockpit/radar/meldungen, /radar.js und die Einstellung per POST; der Faden "
               "startet mit dem Dashboard; Debug-Läufe 160 bis 162 mit ihren Befehlen; /radar.js steht vor /cockpit.js; das Cockpit ruft "
               "Karte und Daten nur, wenn es das Skript gibt; der Ausblick legt Tag 2 ab",
               all(t_ in qu["hl_viz.py"] for t_ in ('elif u.path == "/cockpit/radar":', 'elif u.path == "/cockpit/radar/meldungen":', 'elif u.path == "/radar.js":',
                                                      'elif u.path == "/cockpit/radar/einstellung":', "    radar_start(db) ", "if hl_radar.starten(db):",
                                                      '[py, "hl_radar.py", "--text", "--db", db]', '[py, "hl_radar.py", "--rueckblick-text", "--db", db]',
                                                      '[py, "hl_radar.py", "--selbsttest"]', '"/cockpit/radar": 30, "/cockpit/radar/meldungen": 20}'))
               and """'<script src="/radar.js"></script><script src="/cockpit.js"></script></body></html>'""" in qu["hl_cockpit.py"]
               and "(typeof rdKarte==='function'?rdKarte(d):'')" in qu["hl_cockpit_js.py"] and "if(typeof rdLaden==='function') rdLaden(false);" in qu["hl_cockpit_js.py"]
               and "LAUF_H = (2,) + H_ZIEL" in qu["hl_ausblick.py"] and AU.LAUF_H == (2, 7, 14, 28))
        else:
            ok("VP1 Vertrag mit dem Paket (die übrigen Dateien des Pakets liegen nicht neben dem Modul -- nicht geprüft)", True,
               "fehlen: " + ", ".join(n_ for n_, v_ in qu.items() if v_ is None))
        ok("VP3 Zahlen des Konzepts im Modul (festgehalten): 10 % in 7 Tagen und 7 % in 48 Stunden; Faktor aus 365 Tagen (mindestens 180); Frische 5 Minuten und "
           "3 Stunden; Stufen am 80. und 95. Perzentil; Ende unter 0,8; Sperrzeit 12 Stunden; Kontenquote 3 und 2,8, höchstens einmal in 7 Tagen; "
           "Rückblick ab 1000 Tagen und 50 Ereignissen, Steigung 0,8 bis 1,2, Niveau 0,8 bis 1,25, Block 28, 2000 Ziehungen; Index aus fünf Achsen, "
           "mindestens vier",
           (EREIGNIS["e7"]["tage"], EREIGNIS["e7"]["x"], EREIGNIS["e2"]["tage"], EREIGNIS["e2"]["x"]) == (7, 0.10, 2, 0.07) and (FAKTOR_TAGE, FAKTOR_MIN) == (365, 180)
           and (FRISCH_KURS_S, FRISCH_AUSBLICK_S) == (300, 10800) and (PZ_ERHOEHT, PZ_HOCH, PZ_WAHL) == (0.80, 0.95, (0.95, 0.975, 0.99)) and HYSTERESE == 0.8
           and SPERRZEIT_S == 43200 and (KONTEN_AN, KONTEN_AUS, HINWEIS_SPERRE_S) == (3.0, 2.8, 7 * TAG) and (G_MIN_TAGE, G_MIN_EREIGNISSE) == (1000, 50)
           and G_STEIGUNG == (0.8, 1.2) and G_NIVEAU == (0.8, 1.25) and (G_ALPHA, G_BLOCK, G_BOOT) == (0.05, 28, 2000) and INDEX_ACHSEN == ("a1", "a2", "a3", "a4", "a7")
           and INDEX_MIN == 4 and (TAKT_S, ABLAGE_S) == (300, 3600) and (A5_GRENZE, A5_TAGE, A5_MIN, A6_TAGE, A6_MIN) == (0.05, 90, 336, 30, 240))
        if qu["KONZEPT_Risikoradar.md"] is not None:
            kz = " ".join(qu["KONZEPT_Risikoradar.md"].split())
            ok("VP4 dieselben Zahlen stehen im Konzept (KONZEPT_Risikoradar.md neben dem Modul)",
               all(t_ in kz for t_ in ("P · (1 − 0,10 · f_c)", "P · (1 − 0,07 · f_c)", "mindestens 180 solche Tage", "Kurs höchstens 5 Minuten alt",
                                            "höchstens 3 Stunden alt", "80. Perzentil", "95. Perzentil", "unter 0,8 · Schwelle „hoch“", "letzten 12 Stunden",
                                            "unter 2,8 lag", "mindestens 1000 Ursprungstage und 50 eingetretene Ereignisse", "zwischen 0,8 und 1,2",
                                            "Niveau zwischen 0,8 und 1,25", "Block 28 Tage, 2000 Ziehungen", "(mindestens vier)", "mindestens 14 Tage, höchstens 90")), f"{len(kz)} Zeichen")
        else:
            ok("VP4 Konzept nicht geprüft: KONZEPT_Risikoradar.md liegt nicht neben dem Modul (auf dem Pi kommt es erst mit dem nächsten Update -- "
               "das update.py von 23.121 übernimmt neue .md-Dateien nicht)", True)
        ok("X2 ein Coin außerhalb der Liste bekommt eine Absage mit Grund", stand(dbp, "DOGE", jetzt)["ok"] is False and "nur BTC, ETH, HYPE, ZEC, XMR" in stand(dbp, "DOGE", jetzt)["fehlt"][0])
    finally:
        for k, v in alt_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"hl_radar -- Selbsttest: {sum(erg)} von {len(erg)} Proben bestanden", flush=True)
    return all(erg)


def haupt(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    db_ = argv[argv.index("--db") + 1] if "--db" in argv else os.environ.get("HL_DB", "hl_liq.db")
    if "--selbsttest" in argv:
        return 0 if selbsttest() else 1
    if "--rueckblick" in argv:
        try:
            import hl_ausblick as AU
            AU.nice_aus_umgebung()                                      # der vom Dashboard gestartete Lauf senkt seine Priorität selbst
        except Exception:  # noqa: BLE001
            pass
        t0 = time.time()
        rb = rueckblick_rechnen(db_, log=lambda s: print(s, flush=True))
        if rb.get("laeuft"):
            print("Ein anderer Lauf rechnet den Rückblick gerade -- dieser Lauf endet, ohne zu rechnen.", flush=True)
            return 0
        print(rueckblick_text(rb))
        print(f"\nRückblick abgelegt in {pfad(db_)} · {time.time() - t0:.0f} s")
        return 0
    if "--rueckblick-text" in argv:
        rb, _gerechnet, _gewartet = rueckblick_holen(db_, log=lambda s: print(s, flush=True))
        if rb is None:
            print(f"Nach {RUECKBLICK_WARTEN_S // 60} Minuten liegt noch kein Rückblick vor -- bitte Debug 161 später noch einmal starten.")
            return 0
        print(rueckblick_text(rb))
        return 0
    if "--text" in argv:
        coins_ = (argv[argv.index("--coin") + 1].upper(),) if "--coin" in argv else COINS
        print(text(db_, coins_))
        return 0
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(haupt())
