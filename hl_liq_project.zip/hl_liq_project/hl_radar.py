#!/usr/bin/env python3
"""
hl_radar.py -- Risikoradar (U307, KONZEPT_Risikoradar.md; Paket 23.122; seit 23.123 mit Nachkalibrierung, Regel K; seit 23.124 mit
Aufschlag für belegte Zeichen, Regel A, und der 48-Stunden-Zahl vorn)

Auftrag des Nutzers (23.11.2026 19:41): „eine Art Risikoradar zu zeigen, und das Risiko in Prozenten einzuschätzen … Sollte das Risiko
zu sehr ansteigen, sollte es zusätzlich eine Audiomitteilung geben. Die neue Funktion sollte zu sehen sein im Cockpit.“ Entscheidungen
vom 23.11.2026 20:04: zwei Zahlen (groß „−10 % in 7 Tagen“, darunter „−7 % in 48 Stunden“); Meldung als Push, Ton und Ansage.

Was das Modul tut (alle Regeln stehen im Konzept, vorab festgelegt):
  Ereignisse   E7: das Tief der nächsten 7 Tage liegt mindestens 10 % · f unter dem jetzigen Kurs; E2: 7 % · f in 48 Stunden.
               f = Faktor gegenüber BTC nach der Schwankung (Tagesschlüsse aus hebel.db, 365 Tage vor dem Monatsersten).
  Grundrisiko  p7 und p2 aus der abgelegten Verteilung des laufenden Tiefs der jüngsten Rechnung des Ausblicks
               (hl_ausblick.erreichen_aus_lauf) -- dieselbe Quelle wie der Kurs-Rechner des Cockpits.
  Rückblick    G7 und G2: beide Zahlen ab 2022 an Tagesursprüngen nachgerechnet, gegen die laufende Grundrate; besteht eine Zahl
               nicht, steht sie grau und löst keinen Alarm aus. Aus demselben Lauf Grundrate und Schwellen (80. und 95. Perzentil).
  Regel K      seit 23.123 (Konzept 13.2, Entscheidung des Nutzers vom 24.11.2026): logit p′ = a + b · logit p, je Monatserstem neu
               aus Ursprüngen mit abgelaufener Frist; besteht die kalibrierte Reihe denselben Rückblick (G7k, G2k), gelten Karte,
               Stufen und Alarm für sie -- sonst bleibt es bei der Rohzahl und ihrem Urteil. Zweite Prüfung auf denselben Daten.
  Regel A      seit 23.124 (Konzept 14.4, Entscheidung des Nutzers vom 24.11.2026): Steht ein belegtes Zeichen an (Urteil von
               hl_radar_regeln, erste Regel in der Reihenfolge R1 … R7), wird die Chance der nachkalibrierten 48-Stunden-Zahl mit einem
               Faktor malgenommen (1 bis 3, je Monat kausal geschätzt); ohne Zeichen liegt sie etwas tiefer, so dass das Mittel
               bleibt. Nur BTC und ETH. Gilt nur, wenn die Zahl damit denselben Rückblick besteht (G2a) und besser trifft als ohne.
               Seit 23.124 steht in der Karte die 48-Stunden-Zahl groß und die 7-Tage-Zahl klein (Entscheidung vom 24.11.2026).
  Achsen       acht Achsen von 0 bis 100 (höher = mehr Druck); A1, A2, A3, A4 und A7 bilden den Druck-Index. Messwerte, keine
               Vorhersage. Markttiefe und Liquidations-Nähe messen seit 23.125 die Gebote bis −1 % im Hyperliquid-Buch (Recorder,
               Aufgabe „Buch-Tiefe“: je Minute aus gerundeten Preisstufen, book_tiefe; der eigene Verlauf von A5 beginnt mit 23.125,
               rd_meta „tiefe_ab“). Ob ein Zeichen einen Rücksetzer ankündigt, prüft hl_radar_regeln.py (R1–R7, Debug 163);
               Karte und Debug 160 nennen das abgelegte Urteil.
  Alarm        beim Eintritt in „hoch“ (endet erst unter 0,8 · Schwelle), Sperrzeit 12 Stunden; Entwarnung leise; Hinweis, wenn die
               Kontenquote auf 3 steigt, nachdem sie unter 2,8 lag (höchstens einmal in 7 Tagen). Vorgabe nur BTC.
  Speicher     radar.db neben der Hauptdatenbank: rd_stand (Stunde, Coin), rd_alarm, rd_meta. Liest sonst nur.
Wirkung: keine auf Prognose, Labor, Engine und Notbremse. Kein Abruf im Netz außer dem Push (hl_berichte.senden).

Aufrufe:  hl_radar.py --text [--db PFAD] | --rueckblick [--db PFAD] | --rueckblick-text [--db PFAD] | --selbsttest
"""
from __future__ import annotations

import calendar
import json
import math
import os
import sqlite3
import sys
import threading
import time
import urllib.parse
from decimal import ROUND_HALF_UP, Decimal

import numpy as np

VERSION_MODUL = "2026-09-23.127"
DEBUG_NR_STAND, DEBUG_NR_RUECKBLICK, DEBUG_NR_TEST = 160, 161, 162     # Debug-Läufe radar_stand, radar_rueckblick, radar_test (hl_viz)
DEBUG_NR_REGELN, DEBUG_NR_REGELN_TEST = 163, 164                       # Prüfung der Regeln R1–R7 und ihr Selbsttest (hl_radar_regeln, seit 23.123)
TAG = 86_400
COINS = ("BTC", "ETH", "HYPE", "ZEC", "XMR")
NAMEN = {"BTC": "Bitcoin", "ETH": "Ethereum", "HYPE": "Hype", "ZEC": "Zcash", "XMR": "Monero"}       # für die Ansage
EREIGNIS = {"e7": {"tage": 7, "x": 0.10, "name": "7 Tagen", "kurz": "7 Tage"},
            "e2": {"tage": 2, "x": 0.07, "name": "48 Stunden", "kurz": "48 Stunden"}}
FAKTOR_TAGE, FAKTOR_MIN = 365, 180            # Abschnitt 1: Tage vor dem Monatsersten, mindestens gemeinsame Tage
FRISCH_KURS_S = 300                           # Abschnitt 2: Kurs höchstens 5 Minuten alt
FRISCH_AUSBLICK_S = 3 * 3600                  # Abschnitt 2: Rechnung des Ausblicks höchstens 3 Stunden alt
FRISCH_TAGE = 3                               # Tageswerte (A3, A4, A7) höchstens 3 Tage alt
PZ_ERHOEHT, PZ_HOCH = 0.80, 0.95              # Abschnitt 3: Schwellen als Perzentile der Rückblick-Werte
PZ_WAHL = (0.95, 0.975, 0.99)                 # Abschnitt 6: im Dashboard verstellbar
PZ_ABLAGE = (0.80, 0.90, 0.95, 0.975, 0.99)
REGELN_FASSUNG = 1                            # Abschnitt 5: Fassung der Regeln R1 bis R7, deren abgelegtes Urteil (Debug 163) die Karte zeigt
REGELN_NAMEN = {"r1": "Kontenquote", "r2": "Hebel-Aufbau im Stillstand", "r3": "Funding-Niveau", "r4": "Spot trägt nicht", "r5": "OI-Überhitzung",
                "r6": "Termin", "r7": "Druck-Index"}             # dieselben Namen wie in hl_radar_regeln.REGELN (dort geprüft)
HYSTERESE = 0.8                               # „hoch“ endet unter 0,8 · Schwelle
SPERRZEIT_S = 12 * 3600
KONTEN_AN, KONTEN_AUS, HINWEIS_SPERRE_S = 3.0, 2.8, 7 * TAG
TAKT_S, ABLAGE_S = 300, 3600
RUECKBLICK_MAX_ALTER_S = 30 * TAG
RUECKBLICK_WIEDER_S = 6 * 3600                # ein gescheiterter Rückblick wird frühestens nach 6 h wiederholt
RUECKBLICK_WARTEN_S = 600                     # Debug 161 wartet so lange auf einen Rückblick, den gerade ein anderer Lauf rechnet
G_MIN_TAGE, G_MIN_EREIGNISSE = 1000, 50
G_STEIGUNG = (0.8, 1.2)
G_ALPHA, G_BLOCK, G_BOOT = 0.05, 28, 2000
G_NIVEAU = (0.8, 1.25)                        # Mittel der Zahl ÷ eingetretene Quote (Präzisierung beim Bau, vor jeder echten Zahl)
KAL_MIN_TAGE = 365                            # Regel K2 (Abschnitt 13): mindestens so viele Ursprungstage in einer Anpassung
KAL_MIN_EREIGNISSE = 50                       # … und so viele Ereignisse
KAL_P = (0.005, 0.995)                        # Roh- und kalibrierte Zahl bleiben auf dem Raster der Anzeige
LEIT = "e2"                                   # Abschnitt 14.3: diese Zahl steht in der Karte groß (seit 23.124 die 48-Stunden-Zahl)
REIHE = (LEIT,) + tuple(k_ for k_ in EREIGNIS if k_ != LEIT)       # … und in Karte und Berichten zuerst
AUF_KEY = "e2"                                # Regel A1 (Abschnitt 14.4): Aufschlag nur für die 48-Stunden-Zahl
AUF_DECKEL = 3.0                              # … Faktor auf die Chance höchstens 3 (Abschnitt 5)
AUF_ALT_TAGE = 2                              # A7: ein Stand der Zeichen, der älter als zwei Tage ist, gilt als unbekannt
ZEICHEN_WIEDER_S = 3600                       # A7: der Takt versucht höchstens einmal je Stunde, den Stand der Zeichen zu holen
AUF_NACHWEIS = {"datum": "24.11.2026", "welten": 400,          # 14.6: Messung auf erfundenen Reihen (24.11.2026, 22:52 bis 23:03; je Fall
                "ohne": {"basis": 149, "auf": 1},            # Reihen mit bestandener Grundlage und davon mit geltendem Aufschlag; "or":
                "r1": {"basis": 173, "auf": 32, "or": 2.351},  # gemessenes Chancenverhältnis, Median -- im dritten Fall das Mittel der
                "beide": {"basis": 215, "auf": 66, "or": 2.410}}  # Mediane von R1 (2,37) und R7 (2,45))
NIEDRIG_HINWEIS = "Ein niedriger Wert ist keine Entwarnung."      # 14.3: steht bei der 7-Tage-Zahl, solange sie nicht bestätigt ist
ZEILE_MAX = 150                               # Berichte: keine Zeile länger (Lesen am Handy)
GRUNDRATE_MIN, BIB_MIN = 100, 200
ZUV_KLASSEN = (0.0, 0.02, 0.05, 0.10, 0.20, 0.40, 1.0000001)
PZ_TAGE, PZ_TAGE_MIN = 365, 180               # A3, A4, A7: Perzentil gegen die Tageswerte der 365 Tage davor
A5_GRENZE = 0.05                              # Liquidationspreise bis 5 % unter dem Kurs
A5_TAGE, A5_MIN = 90, 336                     # eigene Stundenwerte: höchstens 90 Tage, mindestens 14 Tage (336 Werte; Konzept Abschnitt 4)
A6_TAGE, A6_MIN = 30, 240                     # Stundenmittel der letzten 30 Tage, mindestens 240 (10 Tage)
TIEFE_MIN_ZEILEN = 30                         # Mittel der letzten 60 Minuten: mindestens so viele vollständige Zeilen (der Recorder schreibt seit
                                              # 23.125 je Minute eine in book_tiefe; bis 23.124: 60 Zeilen aus book_summary, je 30-s-Fenster eine)
INDEX_ACHSEN = ("a1", "a2", "a3", "a4", "a7")
INDEX_MIN = 4
PUSH_VERSUCHE, PUSH_FRIST_S = 5, 3600
MELDUNG_ALT_S = 600                           # der Browser spielt nur Meldungen der letzten 10 Minuten
ACHSEN_NAMEN = (("a1", "Positionierung"), ("a2", "Hebel-Menge"), ("a3", "Preis des Hebels"), ("a4", "Spot-Nachfrage"),
                ("a5", "Liquidations-Nähe"), ("a6", "Markttiefe"), ("a7", "Schwankung"), ("a8", "Umfeld"))
ACHSEN_KURZ = {"a1": "Position", "a2": "Hebel", "a3": "Preis", "a4": "Spot", "a5": "Liq.-Nähe", "a6": "Tiefe", "a7": "Schw.", "a8": "Umfeld"}   # im Netz
STUFEN_WORT = {"ohne": "ohne Stufe", "normal": "normal", "erhoeht": "erhöht", "hoch": "hoch"}
BELEG_U142 = ("U142 H1: Ab einer Kontenquote von 3 folgte in 7 Tagen häufiger ein Rücksetzer (20,3 % der Fälle gegen 7,3 % sonst). "
              "Geprüft wurde dort ein anderes Ereignis (1,5 übliche Wochenschwankungen), nicht die Zahl dieser Karte.")
GRENZEN = ("Das Radar zeigt, wie hoch das Risiko ist, nicht wann etwas geschieht. Einen Schock durch Nachrichten sieht es nicht kommen. "
           "Achsen und Druck-Index sind Messwerte; ob eines der Zeichen einen Rücksetzer ankündigt, sagt die Prüfung der Regeln R1 bis R7 "
           "(Debug 163; das Urteil steht im Beleg).")

SCHEMA = (
    "CREATE TABLE IF NOT EXISTS rd_stand (stunde INTEGER, coin TEXT, ts INTEGER, p7 REAL, p2 REAL, idx REAL, a5 REAL, a6 REAL, json TEXT, "
    "PRIMARY KEY (stunde, coin)) WITHOUT ROWID",
    "CREATE TABLE IF NOT EXISTS rd_alarm (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, coin TEXT, ereignis TEXT, art TEXT, p REAL, "
    "titel TEXT, text TEXT, ansage TEXT, prio INTEGER, push INTEGER, versuche INTEGER DEFAULT 0, push_fehler TEXT)",
    "CREATE INDEX IF NOT EXISTS ix_rd_alarm_ts ON rd_alarm(ts)",
    "CREATE TABLE IF NOT EXISTS rd_meta (k TEXT PRIMARY KEY, v TEXT)",
)
PUSH_AUS, PUSH_OFFEN, PUSH_GESENDET, PUSH_AUFGEGEBEN = 0, 1, 2, 3


# ================================================================================================ Zahlen und Zeit

def _zahl(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _hu(x: float, nd: int = 0) -> Decimal:
    """Kaufmännisch runden (5 nach oben), ohne den Umweg über die Binärdarstellung: 32,5 -> 33, 0,125 -> 0,13."""
    return Decimal(str(x)).quantize(Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP)


def _de(x, nd: int = 1, vz: bool = False) -> str:
    """Zahl im deutschen Format; eine gerundete Null trägt kein Vorzeichen."""
    v = _zahl(x)
    if v is None:
        return "—"
    d = _hu(v, nd)
    s = f"{abs(d):,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("−" if d < 0 else ("+" if vz and d > 0 else "")) + s


def _px(x) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    return _de(v, 0 if abs(v) >= 1000 else (2 if abs(v) >= 1 else 4))


def p_text(p, lage: str = "innen") -> str:
    """Wahrscheinlichkeit für die Anzeige: unter 10 % mit einer Nachkommastelle, sonst ganzzahlig; die Ränder des Rasters als Schranke."""
    v = _zahl(p)
    if v is None or lage == "fehlt":
        return "—"
    if lage == "unter" or v < 0.005:
        return "unter 0,5 %"
    if lage == "ueber" or v > 0.995:
        return "über 99,5 %"
    return (_de(v * 100, 1) if _hu(v * 100, 1) < 10 else _de(v * 100, 0)) + " %"


def x_text(x) -> str:
    """Abstand der Schwelle: „10 %“, „13,9 %“."""
    v = _zahl(x)
    if v is None:
        return "—"
    d = _hu(v * 100, 1)
    return (_de(v * 100, 0) if d == d.to_integral_value() else _de(v * 100, 1)) + " %"


def _umbruch(zeilen, breite: int = ZEILE_MAX) -> list:
    """Zeilen an Leerzeichen umbrechen; Folgezeilen behalten den Einzug der ersten und rücken um zwei Zeichen ein."""
    out = []
    for z in zeilen:
        z = str(z)
        if len(z) <= breite:
            out.append(z); continue
        einzug = " " * (len(z) - len(z.lstrip(" ")) + 2)
        rest = z
        erste = True
        while len(rest) > breite:
            k = rest.rfind(" ", len(einzug) + 1 if not erste else 1, breite + 1)
            if k <= (0 if erste else len(einzug)):
                k = breite
            out.append(rest[:k].rstrip()); rest = einzug + rest[k:].lstrip(); erste = False
        out.append(rest)
    return out


def _dt(ts) -> str:
    v = _zahl(ts)
    return time.strftime("%d.%m. %H:%M UTC", time.gmtime(v)) if v is not None else "—"


def _orts(ts) -> str:
    """Zeit einer Meldung in der Ortszeit des Rechners mit dem Kürzel der Zeitzone (etwa „23.11. 21:29 CET“) -- die Meldung liest ein Mensch
    auf dem Handy; Berichte nennen dagegen UTC."""
    v = _zahl(ts)
    if v is None:
        return "—"
    lt = time.localtime(v)
    return time.strftime("%d.%m. %H:%M ", lt) + (time.strftime("%Z", lt) or "Ortszeit")


def _tag_txt(tag) -> str:
    v = _zahl(tag)
    return time.strftime("%d.%m.%Y", time.gmtime(v * TAG)) if v is not None else "—"


def monatserster(tag: int) -> int:
    """UTC-Tag (Tage seit 1970) des Monatsersten, in dessen Monat `tag` liegt."""
    t = time.gmtime(int(tag) * TAG)
    return calendar.timegm((t.tm_year, t.tm_mon, 1, 0, 0, 0)) // TAG


def pz_davor(reihe, i: int, fenster: int = PZ_TAGE, mind: int = PZ_TAGE_MIN):
    """Mittelrang von reihe[i] unter den endlichen Werten der `fenster` Stellen davor (gleiche zählen halb); None unter `mind` Werten
    oder wenn alle gleich sind. -> Anteil 0 … 1."""
    x = _zahl(reihe[i]) if 0 <= i < len(reihe) else None
    if x is None:
        return None
    w = [u for u in (_zahl(a) for a in reihe[max(0, i - fenster):i]) if u is not None]
    if len(w) < mind or max(w) == min(w):
        return None
    return (sum(1 for a in w if a < x) + 0.5 * sum(1 for a in w if a == x)) / len(w)


def pz_unter(x, werte, mind: int):
    """Mittelrang von x unter `werte` (wie pz_davor, für eine lose Liste)."""
    v = _zahl(x)
    w = [u for u in (_zahl(a) for a in (werte or [])) if u is not None]
    if v is None or len(w) < mind or max(w) == min(w):
        return None
    return (sum(1 for a in w if a < v) + 0.5 * sum(1 for a in w if a == v)) / len(w)


# ================================================================================================ Speicher

def pfad(db: str) -> str:
    """radar.db liegt neben der Hauptdatenbank; HL_RADAR_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_RADAR_DB")
    return p if p else os.path.join(os.path.dirname(os.path.abspath(db)), "radar.db")


def verbinden(p: str) -> sqlite3.Connection:
    con = sqlite3.connect(p, timeout=30, isolation_level=None, check_same_thread=False)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA busy_timeout=30000")
        for s in SCHEMA:
            con.execute(s)
    except sqlite3.Error:
        con.close()
        raise
    return con


def lesen(p: str):
    """Nur-Lese-Verbindung; None, wenn die Datei fehlt."""
    if not p or not os.path.exists(p):
        return None
    con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=10, check_same_thread=False)
    con.execute("PRAGMA busy_timeout=10000")
    return con


def meta(con, k: str, standard=None):
    if con is None:
        return standard
    try:
        r = con.execute("SELECT v FROM rd_meta WHERE k=?", (k,)).fetchone()
    except sqlite3.Error:
        return standard
    if r is None:
        return standard
    try:
        return json.loads(r[0])
    except (TypeError, ValueError):
        return standard


def meta_setzen(con, k: str, wert) -> None:
    con.execute("INSERT INTO rd_meta VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, json.dumps(_ohne_nan(wert), ensure_ascii=False)))


def _ohne_nan(x):
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, (np.floating,)):
        return float(x) if np.isfinite(x) else None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, dict):
        return {str(k): _ohne_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, np.ndarray)):
        return [_ohne_nan(v) for v in x]
    return x


EINSTELLUNG_VORGABE = {"push": True, "coins": ["BTC"], "pz": PZ_HOCH}


def einstellung_pruefen(e) -> dict:
    """Einstellung aus rd_meta oder aus einer Anfrage -> gültige Fassung; Unbekanntes fällt auf die Vorgabe zurück."""
    e = e if isinstance(e, dict) else {}
    coins = [c for c in COINS if c in (e.get("coins") if isinstance(e.get("coins"), (list, tuple)) else EINSTELLUNG_VORGABE["coins"])]
    pz = _zahl(e.get("pz"))
    return {"push": bool(e.get("push", True)), "coins": coins,
            "pz": next((w for w in PZ_WAHL if pz is not None and abs(w - pz) < 1e-9), PZ_HOCH)}


def einstellung_lesen(con) -> dict:
    return einstellung_pruefen(meta(con, "einstellung", EINSTELLUNG_VORGABE))


def einstellung_setzen(db: str, neu: dict) -> dict:
    """Vom Dashboard: Schalter „Push“, Coins der Meldungen, Perzentil der Schwelle „hoch“. -> die gespeicherte Fassung."""
    con = verbinden(pfad(db))
    try:
        e = einstellung_lesen(con)
        if isinstance(neu, dict):
            for k in ("push", "coins", "pz"):
                if k in neu:
                    e[k] = neu[k]
        e = einstellung_pruefen(e)
        meta_setzen(con, "einstellung", e)
        return e
    finally:
        con.close()


def _qk(pz: float) -> str:
    return f"{pz:g}"


# ================================================================================================ Faktor (Abschnitt 1)

def kerzen_lesen(db: str, coins=COINS, ab_tag: int | None = None) -> dict:
    """
    Tageskerzen aus hebel.db (nur lesen): je Coin der Perpetual <COIN>USDT (tag, c, v_usd, taker_usd) und die Summe seiner Spot-Paare
    je Tag (Umsatz und Taker-Kauf in USD). -> {coin: {"tag", "c", "pv", "pt", "stag", "sv", "st"}}; ohne hebel.db {}.
    """
    import hl_hebel as HB
    con = HB._lesen(HB.hebel_pfad(db))
    if con is None:
        return {}
    out = {}
    ab = int(ab_tag) if ab_tag is not None else 0
    try:
        for coin in coins:
            r = con.execute("SELECT tag, c, v_usd, taker_usd FROM hb_kerzen WHERE markt='um' AND symbol=? AND tag>=? ORDER BY tag",
                            (f"{coin}USDT", ab)).fetchall()
            if not r:
                continue
            sym = [f"{coin}{q}" for q in HB.SPOT_QUOTES]
            s = con.execute("SELECT tag, SUM(v_usd), SUM(taker_usd), SUM(CASE WHEN taker_usd IS NULL THEN 1 ELSE 0 END) FROM hb_kerzen "
                            f"WHERE markt='spot' AND symbol IN ({','.join('?' * len(sym))}) AND tag>=? AND v_usd>0 GROUP BY tag ORDER BY tag",
                            (*sym, ab)).fetchall()
            f = lambda v: float(v) if v is not None else float("nan")   # noqa: E731
            out[coin] = {"tag": np.array([int(x[0]) for x in r], dtype=np.int64), "c": np.array([f(x[1]) for x in r]),
                         "pv": np.array([f(x[2]) for x in r]), "pt": np.array([f(x[3]) for x in r]),
                         "stag": np.array([int(x[0]) for x in s], dtype=np.int64), "sv": np.array([f(x[1]) for x in s]),
                         "st": np.array([f(x[2]) if not x[3] else float("nan") for x in s])}
    except sqlite3.Error:
        return out
    finally:
        con.close()
    return out


def _renditen_je_tag(tage, c) -> dict:
    """{Tag: Log-Rendite} für Tage, an denen der Tag selbst und der Vortag einen Schluss haben."""
    d = {}
    for i in range(1, len(tage)):
        if int(tage[i]) - int(tage[i - 1]) == 1 and c[i] > 0 and c[i - 1] > 0 and math.isfinite(c[i]) and math.isfinite(c[i - 1]):
            d[int(tage[i])] = math.log(c[i] / c[i - 1])
    return d


def faktor_rechnen(coin: str, rc: dict | None, rb: dict | None, stichtag: int) -> dict:
    """
    Faktor gegenüber BTC am Monatsersten `stichtag` aus den Tagesrenditen rc (Coin) und rb (BTC): σ̄_c ÷ σ̄_BTC über die Tage d mit
    stichtag − 365 ≤ d < stichtag, an denen beide eine Rendite haben; mindestens 1, auf zwei Stellen. Unter 180 gemeinsamen Tagen kein
    Faktor. BTC selbst hat 1.
    """
    if coin == "BTC":
        return {"f": 1.0, "n": None, "stichtag": int(stichtag), "grund": None}
    if not rc or not rb:
        return {"f": None, "n": 0, "stichtag": int(stichtag), "grund": f"Für {coin} oder BTC fehlen Tagesschlüsse in hebel.db."}
    gem = [t for t in rc if t in rb and stichtag - FAKTOR_TAGE <= t < stichtag]
    n = len(gem)
    if n < FAKTOR_MIN:
        return {"f": None, "n": n, "stichtag": int(stichtag),
                "grund": f"Für {coin} gibt es erst {n} gemeinsame Tage mit BTC (gebraucht werden {FAKTOR_MIN})."}
    sc = math.sqrt(sum(rc[t] ** 2 for t in gem) / n); sb = math.sqrt(sum(rb[t] ** 2 for t in gem) / n)
    if not sb > 0:
        return {"f": None, "n": n, "stichtag": int(stichtag), "grund": "Die Schwankung von BTC ist null."}
    return {"f": max(1.0, float(_hu(sc / sb, 2))), "n": n, "roh": sc / sb, "stichtag": int(stichtag), "grund": None}


_FAKTOR_CACHE: dict = {}


def faktor(db: str, coin: str, jetzt: int, K: dict | None = None) -> dict:
    """Faktor des laufenden Monats (im Speicher gemerkt, bis der Monat wechselt oder er noch fehlt)."""
    st = monatserster(int(jetzt) // TAG)
    key = (os.path.abspath(db), coin, st)
    hit = _FAKTOR_CACHE.get(key)
    if hit is not None and hit.get("f") is not None and K is None:
        return hit
    if coin == "BTC":
        out = faktor_rechnen("BTC", None, None, st)
    else:
        K = K if K is not None else kerzen_lesen(db, (coin, "BTC"), st - FAKTOR_TAGE - 2)
        if coin not in K or "BTC" not in K:
            out = {"f": None, "n": 0, "stichtag": st, "grund": f"Für {coin} oder BTC fehlen Tagesschlüsse in hebel.db (die Hebel-Studie lädt sie)."}
        else:
            out = faktor_rechnen(coin, _renditen_je_tag(K[coin]["tag"], K[coin]["c"]), _renditen_je_tag(K["BTC"]["tag"], K["BTC"]["c"]), st)
    _FAKTOR_CACHE[key] = out
    return out


# ================================================================================================ Grundrisiko und Stufe (Abschnitte 2, 6)

def stufe_von(p, s_erhoeht, s_hoch, war_hoch: bool) -> str:
    """normal · erhoeht · hoch. „Hoch“ beginnt bei p ≥ Schwelle und endet erst, wenn p unter 0,8 · Schwelle fällt."""
    p = _zahl(p); s_hoch = _zahl(s_hoch)
    if p is None or s_hoch is None:
        return "ohne"
    if p >= s_hoch or (war_hoch and p >= HYSTERESE * s_hoch):
        return "hoch"
    s_erhoeht = _zahl(s_erhoeht)
    return "erhoeht" if s_erhoeht is not None and p >= s_erhoeht else "normal"


def p_wert_text(p) -> str:
    """p-Wert für Sätze: drei Stellen; unter 0,001 steht die Schranke (2000 Ziehungen können nicht „0,000“ belegen)."""
    v = _zahl(p)
    if v is None:
        return "p —"
    return "p unter 0,001" if v < 0.001 else f"p {_de(v, 3)}"


def urteil_satz(key: str, u: dict | None, rb: dict | None) -> str:
    """Ein Satz zum Rückblick dieser Zahl (G7 bzw. G2)."""
    name = "G7" if key == "e7" else "G2"
    if not rb:
        return f"Noch nicht geprüft: Der Rückblick ({name}) hat auf diesem Rechner noch nicht gerechnet (Debug 161)."
    if not u:
        return f"Der Rückblick ({name}) hat für diese Zahl kein Urteil abgelegt."
    kopf = (f"Rückblick {name} vom {_dt(rb.get('stand'))}: {_tsd(u.get('n'))} Ursprünge an {_tsd(u.get('n_tage'))} Tagen, "
            f"{_tsd(u.get('n_ereignisse'))} Ereignisse, Skill {_de((_zahl(u.get('skill')) or 0) * 100, 1, True)} % ({p_wert_text(u.get('p'))}), "
            f"Steigung {_de(u.get('steigung'), 2)}, Niveau {_de(u.get('niveau'), 2)}")
    if u.get("besteht"):
        return kopf + " — besteht."
    return kopf + f" — im Rückblick nicht bestätigt: {u.get('grund') or 'ohne Angabe'}."


def niveau_satz(coin: str, niveau) -> str | None:
    """Hinweis, wenn die Zahl dieses Coins im Rückblick im Mittel deutlich über oder unter der eingetretenen Quote lag."""
    v = _zahl(niveau)
    if v is None or G_NIVEAU[0] <= v <= G_NIVEAU[1]:
        return None
    return (f"Für {coin} lag diese Zahl im Rückblick im Mittel beim {_de(v, 2)}-Fachen der eingetretenen Quote -- "
            + ("sie kann zu hoch sein." if v > 1 else "sie kann zu niedrig sein."))


def _tsd(n) -> str:
    v = _zahl(n)
    return _de(v, 0) if v is not None else "—"


def ereignisse_bauen(coin: str, lauf: dict | None, lauf_fehlt: str | None, f: dict, kurs, kurs_frisch: bool, jetzt: int, rb: dict | None,
                     zust: dict | None, pz_wahl: float = PZ_HOCH, zeichen: dict | None = None) -> dict:
    """Beide Zahlen mit Schwelle, Grundrate, Urteil des Rückblicks und Stufe. Ohne frische Quelle steht der Grund statt der Zahl.
    zeichen: der abgelegte Stand der belegten Zeichen (rd_meta „zeichen“) für den Aufschlag nach Regel A."""
    import hl_ausblick as AU
    rc = ((rb or {}).get("coins") or {}).get(coin) or {}
    kurs = _zahl(kurs)
    out = {}
    for key, E in EREIGNIS.items():
        u = ((rb or {}).get("urteil") or {}).get(key)
        r = rc.get(key) or {}
        e = {"key": key, "tage": E["tage"], "frist": E["name"], "x": None, "x_text": "—", "kurs_schwelle": None, "p": None, "lage": "fehlt",
             "p_text": "—", "fehlt": None, "grundrate": _zahl(r.get("grundrate")), "stufe": "ohne", "s_erhoeht": None, "s_hoch": None,
             "besteht": (bool(u.get("besteht")) if u else None), "urteil": urteil_satz(key, u, rb), "niveau": niveau_satz(coin, r.get("niveau"))}
        fz = _zahl((f or {}).get("f"))
        if fz is None:
            e["fehlt"] = (f or {}).get("grund") or f"Für {coin} gibt es keinen Faktor."
        else:
            x = E["x"] * fz
            e["x"] = x; e["x_text"] = x_text(x)
            if kurs:
                e["kurs_schwelle"] = kurs * (1 - x) if x < 1 else None
            if x >= 0.9:
                e["fehlt"] = f"Die Schwelle läge bei {x_text(x)} -- dafür rechnet das Radar nicht."
            elif not kurs or not kurs_frisch:
                e["fehlt"] = "Kein frischer Kurs (höchstens 5 Minuten alt)."
            elif lauf is None:
                e["fehlt"] = lauf_fehlt or f"Der Ausblick hat für {coin} noch keine Verteilung abgelegt."
            elif int(jetzt) - int(lauf.get("anker") or 0) > FRISCH_AUSBLICK_S:
                e["fehlt"] = f"Die Rechnung des Ausblicks ist älter als 3 Stunden (Stand {_dt(lauf.get('anker'))})."
            else:
                p, lage = AU.erreichen_aus_lauf(lauf.get("h"), math.log(1 - x), E["tage"])
                if lage == "fehlt" or _zahl(p) is None:
                    e["fehlt"] = (f"Der Ausblick hat die Verteilung für {E['tage']} Tage noch nicht abgelegt "
                                  "(kommt mit seiner nächsten Rechnung, spätestens in einer Stunde).")
                else:
                    e["p"] = float(p); e["lage"] = lage; e["p_text"] = p_text(p, lage)
        kf = kal_fuer(rb, coin, key)                                       # 23.123, Regel K4: besteht die kalibrierte Fassung, gilt sie
        if kf is not None:
            u = kf["urteil"]; r = dict(kf["r"])
            e["kal"] = True; e["besteht"] = True; e["urteil"] = kal_urteil_satz(key, u, rb); e["niveau"] = niveau_satz(coin, r.get("niveau"))
            if e["p"] is not None:
                e["p_roh"] = e["p"]; e["p_roh_text"] = e["p_text"]
                e["p"] = kal_zahl(e["p"], kf["a"], kf["b"]); e["lage"] = "innen"; e["p_text"] = p_text(e["p"])
        af = auf_fuer(rb, coin, key) if (kf is not None and key == AUF_KEY) else None      # 23.124, Regel A6: besteht der Aufschlag, gilt er
        if af is not None:
            lage_z = zeichen_lage(zeichen, coin, jetzt, af["regeln"])
            u = af["urteil"]; r = dict(af["r"])
            e["auf"] = {"k": lage_z["k"], "regel": lage_z.get("regel"), "tag": lage_z.get("tag"), "grund": lage_z.get("grund"),
                        "name": (regel_name(lage_z["regel"]) if lage_z.get("regel") else None)}
            e["urteil"] = auf_urteil_satz(((rb or {}).get("auf") or {}).get(key), rb); e["niveau"] = niveau_satz(coin, r.get("niveau"))
            if e["p"] is not None:
                e["p_ohne"] = e["p"]; e["p_ohne_text"] = e["p_text"]
                if lage_z["k"] >= 0:
                    e["p"] = auf_zahl(e["p"], lage_z["k"], af["F"], af["PI"]); e["p_text"] = p_text(e["p"])
        if key == "e7" and e["besteht"] is False:
            e["hinweis"] = NIEDRIG_HINWEIS                                 # 14.3: die 7-Tage-Zahl scheitert am unteren Rand
        q = r.get("q") or {}
        if e["p"] is not None and e["besteht"] is True and _zahl(q.get(_qk(pz_wahl))) is not None:
            e["s_erhoeht"] = _zahl(q.get(_qk(PZ_ERHOEHT))); e["s_hoch"] = _zahl(q.get(_qk(pz_wahl)))
            e["stufe"] = stufe_von(e["p"], e["s_erhoeht"], e["s_hoch"], bool(((zust or {}).get(key) or {}).get("hoch")))
        e["stufe_wort"] = STUFEN_WORT[e["stufe"]]
        e["grundrate_text"] = p_text(e["grundrate"]) if e["grundrate"] is not None else None
        e["schwellen"] = (f"erhöht ab {p_text(e['s_erhoeht'])}, hoch ab {p_text(e['s_hoch'])} (endet unter {p_text(HYSTERESE * e['s_hoch'])})"
                          if e["s_hoch"] is not None and e["s_erhoeht"] is not None else None)
        e["satz"] = ereignis_satz(coin, e)
        out[key] = e
    return out


def ereignis_satz(coin: str, e: dict) -> str:
    """Der Satz der Karte und des Berichts zu einer Zahl."""
    if e.get("x") is None:
        return f"{coin}, {e['frist']}: {e.get('fehlt') or 'keine Zahl'}"
    kopf = f"Risiko, dass {coin} in {e['frist']} {e['x_text']} tiefer berührt wird" + (f" (bei {_px(e['kurs_schwelle'])})" if e.get("kurs_schwelle") else "")
    if e.get("p") is None:
        return kopf + f": keine Zahl. {e.get('fehlt') or ''}".rstrip()
    s = kopf + f": {e['p_text']}"
    if e.get("grundrate") is not None:
        s += f" · üblich {p_text(e['grundrate'])}"
    if e.get("besteht") is True:
        s += f" · Stufe {e['stufe_wort']}" if e.get("stufe") != "ohne" else " · ohne Stufe (für diesen Coin gibt es im Rückblick keine Schwellen)"
    elif e.get("besteht") is False:
        s += " · im Rückblick nicht bestätigt"
    else:
        s += " · noch nicht geprüft"
    if e.get("kal") and e.get("p_roh_text"):
        s += f" · nachkalibriert (roh {e['p_roh_text']})"
    if e.get("auf") and e.get("p_ohne_text"):
        k_ = e["auf"].get("k", -1)
        s += (f" · mit Aufschlag für {regel_name(e['auf'].get('regel'))} (ohne {e['p_ohne_text']})" if k_ >= 1 else
              (f" · kein belegtes Zeichen an (ohne Aufschlag {e['p_ohne_text']})" if k_ == 0 else " · Stand der Zeichen unbekannt, ohne Aufschlag"))
    return s + "." + (" " + e["hinweis"] if e.get("hinweis") else "")


# ================================================================================================ Achsen (Abschnitt 4)

def _auf_achse(tag0: int, n: int, tage, werte) -> np.ndarray:
    out = np.full(n, np.nan)
    if tage is None or not len(tage):
        return out
    i = np.asarray(tage, dtype=np.int64) - int(tag0)
    m = (i >= 0) & (i < n)
    out[i[m]] = np.asarray(werte, dtype=float)[m]
    return out


def _summe7(x: np.ndarray, mind: int = 6) -> tuple:
    """Gleitende Summe über 7 Stellen (die Stelle selbst und sechs davor) und die Zahl der endlichen Werte darin."""
    ok = np.isfinite(x); v = np.where(ok, x, 0.0)
    cs = np.concatenate([[0.0], np.cumsum(v)]); cn = np.concatenate([[0], np.cumsum(ok.astype(np.int64))])
    n = len(x); a = np.maximum(0, np.arange(n) - 6); b = np.arange(n) + 1
    s = cs[b] - cs[a]; k = cn[b] - cn[a]
    return np.where(k >= mind, s, np.nan), k


def lange_reihen(K: dict, fund_ts=None, fund_rate=None) -> dict | None:
    """
    Tagesreihen eines Coins auf lückenloser Achse (hl_zyklus.achse, wie U142): σ (EWMA, Halbwertszeit 20 Tage), Funding als Mittel der
    letzten 7 Tage auf ein Jahr gerechnet, Spot- und Perp-Taker-Saldo über 7 Tage. -> {tag0, n, c, sig, fund7, spot7, perp7}
    """
    import hl_zyklus as ZY
    ax = ZY.achse(K["tag"], K["c"])
    if ax is None or len(ax["c"]) < 30:
        return None
    tag0 = int(ax["tag0"]); c = np.asarray(ax["c"], dtype=float); n = len(c)
    sig = ZY.sigma_batch(ZY.renditen(c[None, :]))[0]
    fund7 = np.full(n, np.nan)
    if fund_ts is not None and len(fund_ts):
        d = np.asarray(fund_ts, dtype=np.int64) // TAG - tag0
        m = (d >= 0) & (d < n)
        s = np.zeros(n); hat = np.zeros(n, dtype=bool)
        np.add.at(s, d[m], np.asarray(fund_rate, dtype=float)[m]); hat[d[m]] = True
        su, k = _summe7(np.where(hat, s, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            fund7 = su / k * 365.0
    def saldo(tage, v, tk):                                              # Σ(2·Taker-Kauf − Umsatz) ÷ Σ Umsatz über 7 Tage
        va = _auf_achse(tag0, n, tage, v); ta = _auf_achse(tag0, n, tage, tk)
        ok = np.isfinite(va) & np.isfinite(ta) & (va > 0)
        z, k = _summe7(np.where(ok, 2 * ta - va, np.nan)); nn, _ = _summe7(np.where(ok, va, np.nan))
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(nn > 0, z / nn, np.nan)
    return {"tag0": tag0, "n": n, "c": c, "sig": sig, "fund7": fund7, "spot7": saldo(K.get("stag"), K.get("sv"), K.get("st")),
            "perp7": saldo(K["tag"], K["pv"], K["pt"])}


def lange_achsen_aus(R: dict | None, heute: int) -> dict:
    """A3, A4 und A7 aus den Tagesreihen: Wert am letzten Tag der Achse und Perzentil gegen die 365 Tage davor."""
    out = {}
    namen = {"a3": ("fund7", "Funding Binance, Mittel der letzten 7 Tage"), "a4": ("spot7", "Spot-Taker-Saldo Binance über 7 Tage"),
             "a7": ("sig", "Schwankung je Tag (σ)")}
    for key, (feld, name) in namen.items():
        if R is None:
            out[key] = {"roh": None, "pz": None, "tag": None, "grau": "Für diesen Coin fehlen Tageskerzen in hebel.db."}; continue
        i = R["n"] - 1; tag = R["tag0"] + i
        roh = _zahl(R[feld][i])
        e = {"roh": roh, "pz": None, "tag": int(tag), "grau": None}
        if heute - tag > FRISCH_TAGE:
            e["grau"] = f"Tageswerte nur bis {_tag_txt(tag)}."
        elif roh is None:
            e["grau"] = (f"{name}: kein Wert am {_tag_txt(tag)}"
                         + (" (in hebel.db liegen für diesen Coin keine Spot-Kerzen von Binance)." if key == "a4" and not np.isfinite(R["spot7"]).any() else "."))
        else:
            e["pz"] = pz_davor(R[feld], i)
            if e["pz"] is None:
                e["grau"] = f"{name}: für das Perzentil fehlt Verlauf (gebraucht werden {PZ_TAGE_MIN} Tageswerte)."
        out[key] = e
    return out


_LANG_CACHE: dict = {}


def lange_achsen(db: str, coin: str, jetzt: int) -> dict:
    """A3, A4, A7 für einen Coin aus hebel.db und swing.db; je Stunde einmal gelesen."""
    key = (os.path.abspath(db), coin, int(jetzt) // 3600)
    if key in _LANG_CACHE:
        return _LANG_CACHE[key]
    heute = int(jetzt) // TAG
    R = None
    try:
        K = kerzen_lesen(db, (coin,), heute - PZ_TAGE - 200)
        if coin in K:
            ft = fr = None
            try:
                import hl_swing as SW
                import hl_hebel as HB
                sc = HB._lesen(SW.swing_pfad(db))
                if sc is not None:
                    try:
                        F = SW.funding_lesen(sc, coin); ft, fr = F["ts"], F["rate"]
                    finally:
                        sc.close()
            except Exception:  # noqa: BLE001 -- ohne Funding bleibt A3 grau, der Rest steht
                ft = fr = None
            R = lange_reihen(K[coin], ft, fr)
    except Exception:  # noqa: BLE001 -- die Karte nennt dann den Grund je Achse
        R = None
    out = lange_achsen_aus(R, heute)
    if len(_LANG_CACHE) > 64:
        _LANG_CACHE.clear()
    _LANG_CACHE[key] = out
    return out


_TIEFE_CACHE: dict = {}


def tiefen_stunden(con, jetzt: int) -> dict:
    """Stundenmittel der Gebote bis −1 % (USD, book_tiefe, nur Zeilen mit vollständigen Geboten; seit 23.125 -- bis 23.124 die obersten
    10 Preisstufen aus book_summary) je Coin über die letzten 30 Tage, ohne die laufende Stunde -- ein Durchlauf für alle Coins, je
    Stunde einmal. -> {coin: {stunde: mittel}}"""
    try:
        datei = con.execute("PRAGMA database_list").fetchone()[2]
    except (sqlite3.Error, TypeError, IndexError):
        datei = ""
    key = (datei, int(jetzt) // 3600)
    hit = _TIEFE_CACHE.get("hist")
    if hit is not None and hit[0] == key:
        return hit[1]
    out: dict = {}
    ab = (key[1] - A6_TAGE * 24) * 3600; bis = key[1] * 3600
    try:
        for coin, h, m in con.execute("SELECT coin, ts / 3600, AVG(bid_1) FROM book_tiefe WHERE ts >= ? AND ts < ? AND (voll & 1) = 1 "
                                      "AND bid_1 > 0 GROUP BY coin, ts / 3600", (ab, bis)):
            if m is not None:
                out.setdefault(coin, {})[int(h)] = float(m)
    except sqlite3.Error:
        pass
    _TIEFE_CACHE["hist"] = (key, out)
    return out


def tiefe_lesen(con, coin: str, jetzt: int) -> dict:
    """Gebote bis −1 % im Hyperliquid-Buch (seit 23.125: book_tiefe, je Minute aus gerundeten Preisstufen -- nur Zeilen, deren Gebote bis
    −1 % vollständig sind): Mittel der letzten 60 Minuten, die Stundenmittel der letzten 30 Tage und die Stufe der jüngsten Zeile. Bis
    23.124 standen hier die obersten 10 Preisstufen des ungerundeten Buchs (bid_100) -- bis −1 % reichten sie nicht (Konzept 13.3)."""
    out = {"usd": None, "n": 0, "stunden": [], "fehlt": None, "schritt": None}
    if con is None:
        out["fehlt"] = "Datenbank des Recorders fehlt."; return out
    try:
        r = con.execute("SELECT AVG(bid_1), COUNT(*) FROM book_tiefe WHERE coin=? AND ts>? AND ts<=? AND (voll & 1) = 1 AND bid_1>0",
                        (coin, int(jetzt) - 3600, int(jetzt))).fetchone()
        out["n"] = int(r[1] or 0) if r else 0
        if out["n"] >= TIEFE_MIN_ZEILEN and r[0] is not None:
            out["usd"] = float(r[0])
        else:
            out["fehlt"] = (f"Tiefe des Buchs: in den letzten 60 Minuten nur {out['n']} Werte bis −1 % (gebraucht werden "
                            f"{TIEFE_MIN_ZEILEN}; der Recorder misst sie seit 23.125 je Minute).")
        sr = con.execute("SELECT schritt FROM book_tiefe WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1", (coin, int(jetzt))).fetchone()
        out["schritt"] = _zahl(sr[0]) if sr else None
        out["stunden"] = list((tiefen_stunden(con, jetzt).get(coin) or {}).values())
    except sqlite3.Error as e:
        out["fehlt"] = ("Tiefe des Buchs: Die Tabelle book_tiefe fehlt in der Datenbank des Recorders (er legt sie ab 23.125 beim Start an)."
                        if "no such table" in str(e) else f"Tiefe des Buchs nicht lesbar ({type(e).__name__}).")
    return out


def schritt_text(s) -> str:
    """Stufe des gerundeten Buchs in Worten: „Stufen zu 100 USD“, „Stufen zu 0,1 USD“; ohne Wert leer."""
    w = _zahl(s)
    if w is None or w <= 0:
        return ""
    nach = max(0, -int(math.floor(math.log10(w) + 1e-9)))
    return f"Stufen zu {_de(w, nach)} USD"


def liq_naehe(zeilen, kurs, grenze: float = A5_GRENZE) -> float:
    """Long-Positionswert (USD) der Heatmap mit Liquidationspreis im Bereich [Kurs · (1 − grenze), Kurs)."""
    k = _zahl(kurs)
    if not k:
        return 0.0
    return float(sum(n for b, s, n, _ in (zeilen or []) if s == "long" and k * (1 - grenze) <= b < k))


def a5_verlauf(con_r, coin: str, jetzt: int) -> list:
    """Die eigenen Stundenwerte von A5 (Rohwert) der letzten 90 Tage aus rd_stand -- seit 23.125 nur ab der ersten Stunde, die mit den
    Geboten bis −1 % abgelegt wurde (rd_meta „tiefe_ab“; ältere Werte haben einen anderen Nenner). Ohne den Vermerk: keiner."""
    if con_r is None:
        return []
    ab = _zahl(meta(con_r, "tiefe_ab"))
    if ab is None:
        return []
    try:
        return [float(r[0]) for r in con_r.execute("SELECT a5 FROM rd_stand WHERE coin=? AND stunde>=? AND a5 IS NOT NULL",
                                                   (coin, max(int(jetzt) // 3600 - A5_TAGE * 24, int(ab))))]
    except sqlite3.Error:
        return []


def kurze_achsen(L: dict | None, kurs, kurs_frisch: bool, T: dict, a5_hist: list, jetzt: int, frisch_liq_s: int = 1800) -> dict:
    """A5 (Zwangsverkauf gegen Buchtiefe) und A6 (Markttiefe, umgekehrt) aus dem Schnappschuss der Heatmap und dem Orderbuch."""
    a5 = {"roh": None, "pz": None, "liq_usd": None, "tiefe_usd": T.get("usd"), "grau": None, "n_hist": len(a5_hist or []), "abdeckung": None}
    a6 = {"roh": T.get("usd"), "pz": None, "grau": None, "n_hist": len(T.get("stunden") or []), "schritt": T.get("schritt")}
    L = L or {}
    if isinstance(L.get("abdeckung"), dict):
        a5["abdeckung"] = _zahl(L["abdeckung"].get("anteil"))
    if T.get("usd") is None:
        a6["grau"] = T.get("fehlt") or "Orderbuch: kein Wert."
    else:
        pz = pz_unter(T["usd"], T.get("stunden"), A6_MIN)
        if pz is None:
            a6["grau"] = (f"Markttiefe: für das Perzentil fehlt Verlauf ({a6['n_hist']} von {A6_MIN} Stundenwerten; die Gebote bis −1 % misst "
                          "der Recorder seit 23.125).")
        else:
            a6["pz"] = 1.0 - pz                                         # dünnes Buch = hoher Wert
    if L.get("ts") is None or (L.get("fehlt") or []):
        a5["grau"] = "Heatmap: " + ("; ".join(L.get("fehlt") or []) or "noch kein Schnappschuss") + "."
    elif int(jetzt) - int(L["ts"]) > frisch_liq_s:
        a5["grau"] = f"Heatmap nicht frisch (Stand {_dt(L['ts'])})."
    elif not _zahl(kurs) or not kurs_frisch:
        a5["grau"] = "Kein frischer Kurs."
    elif T.get("usd") is None:
        a5["grau"] = T.get("fehlt") or "Orderbuch: kein Wert."
    else:
        a5["liq_usd"] = liq_naehe(L.get("zeilen"), kurs)
        a5["roh"] = a5["liq_usd"] / T["usd"]
        a5["pz"] = pz_unter(a5["roh"], a5_hist, A5_MIN)
        if a5["pz"] is None:
            a5["grau"] = (f"Für das Perzentil fehlt eigener Verlauf ({a5['n_hist']} von {A5_MIN} Stundenwerten; das Radar sammelt sie seit 23.125 "
                          "neu, mit den Geboten bis −1 %).")
    return {"a5": a5, "a6": a6}


def umfeld(lampen: dict, nb_stufe) -> dict:
    """
    A8, Stufen: 0 nichts · 33 Wochenende · 66 Termin binnen 24 h · 100 Aktien-Lampe an oder Notbremse ab Stufe 1; der höchste Wert gilt.
    Ist die Termin- oder die Aktien-Lampe grau (oder fehlt sie) und könnte sie mehr bedeuten als das Bekannte, gibt es keinen Wert
    (grau) -- „0“ hieße dann „nichts Besonderes“, ohne dass es jemand weiß. „offen“ nennt diese Lampen.
    """
    zust = lambda k: (lampen.get(k) or {}).get("zustand")                          # noqa: E731
    an = lambda k: zust(k) in ("hinweis", "warnung")                               # noqa: E731
    gruende = []; wert = 0
    if an("wochenende"):
        wert = max(wert, 33); gruende.append("Wochenende")
    if an("termin"):
        wert = max(wert, 66); gruende.append("Termin: " + str((lampen.get("termin") or {}).get("wert") or ""))
    if an("aktien"):
        wert = max(wert, 100); gruende.append("Aktien-Lampe an (" + str((lampen.get("aktien") or {}).get("wert") or "") + ")")
    nb = _zahl(nb_stufe)
    if nb is not None and nb >= 1:
        wert = max(wert, 100); gruende.append(f"Notbremse Stufe {int(nb)}")
    offen = [name for k, name, stufe in (("termin", "Termin", 66), ("aktien", "Aktien", 100))
             if zust(k) not in ("aus", "hinweis", "warnung") and wert < stufe]
    return {"wert": (None if offen else wert), "gruende": gruende, "offen": offen}


def umfeld_grund(lampen: dict, offen: list) -> str:
    """Der Grund, den das Cockpit für eine graue Lampe nennt -- angehängt an den Satz der Achse Umfeld (seit 23.123)."""
    teile = []
    for name in offen or []:
        d = str((lampen.get(str(name).lower()) or {}).get("detail") or "").strip()
        if d:
            teile.append(f"{name}: {d}")
    return (" Grund laut Cockpit -- " + " ".join(teile)) if teile else ""


def achsen_bauen(B: dict, LA: dict, KA: dict, nb_stufe, coin: str = "") -> list:
    """Die acht Achsen der Karte aus dem Cockpit (Messwerte, Lampen), den Tagesreihen (A3, A4, A7) und den kurzen Achsen (A5, A6)."""
    mw = {m.get("key"): m for m in (B.get("messwerte") or []) if isinstance(m, dict)}
    lp = {m.get("key"): m for m in (B.get("lampen") or []) if isinstance(m, dict)}
    out = []
    def achse(key, wert, leit, vergleich, stand, grau):
        w = _zahl(wert)
        out.append({"key": key, "name": dict(ACHSEN_NAMEN)[key], "kurz": ACHSEN_KURZ[key], "wert": (None if grau or w is None else float(_hu(max(0.0, min(100.0, w)), 0))),
                    "leit": leit, "vergleich": vergleich, "stand": stand, "grau": grau, "index": key in INDEX_ACHSEN})
    for key, mk, name in (("a1", "konten", "Kontenquote Binance"), ("a2", "oi", "Open Interest Binance")):
        m = mw.get(mk) or {}
        pz = _zahl(m.get("pz")); w = _zahl(m.get("wert"))
        mf = str(m.get("fehlt") or "").strip()                               # Grund des Cockpits, wenn es einen nennt
        grau = None if (pz is not None and w is not None) else (
            f"{name}: {mf}" if mf else (f"{name}: kein Wert." if w is None else f"{name}: für das Perzentil fehlt Verlauf (gebraucht werden 60 Tagesstände)."))
        leit = f"{name} {_de(w, 2) if mk == 'konten' else _tsd(w) + ' ' + coin}".strip() if w is not None else name
        out_stand = _dt(m.get("stand")) if m.get("stand") else (_tag_txt(m.get("stand_tag")) if m.get("stand_tag") else "—")
        achse(key, None if pz is None else pz * 100, leit, "Perzentil gegen die letzten 90 Tagesstände", out_stand, grau)
    a3 = LA.get("a3") or {}
    achse("a3", None if a3.get("pz") is None else a3["pz"] * 100,
          "Funding Binance, Mittel der letzten 7 Tage: " + (_de((a3.get("roh") or 0) * 100, 1, True) + " % im Jahr" if a3.get("roh") is not None else "—"),
          "Perzentil gegen die 365 Tage davor", _tag_txt(a3.get("tag")), a3.get("grau"))
    a4 = LA.get("a4") or {}
    achse("a4", None if a4.get("pz") is None else (1.0 - a4["pz"]) * 100,
          "Spot-Taker-Saldo Binance über 7 Tage: " + (_de((a4.get("roh") or 0) * 100, 2, True) + " % des Umsatzes" if a4.get("roh") is not None else "—"),
          "100 − Perzentil gegen die 365 Tage davor (schwache Nachfrage = hoher Wert)", _tag_txt(a4.get("tag")), a4.get("grau"))
    a5 = KA.get("a5") or {}
    achse("a5", None if a5.get("pz") is None else a5["pz"] * 100,
          ("Long-Liquidationen bis −5 %: " + _mio(a5.get("liq_usd")) + " = " + _de(a5.get("roh"), 1) + "-mal die Gebote bis −1 % (" + _mio(a5.get("tiefe_usd")) + ")"
           if a5.get("roh") is not None else "Long-Liquidationen bis −5 % gegen die Gebote bis −1 %")
          + (f"; erfasst sind {_de(a5['abdeckung'] * 100, 0)} % des Open Interest" if a5.get("abdeckung") is not None else ""),
          "Perzentil gegen die eigenen Stundenwerte", "live", a5.get("grau"))
    a6 = KA.get("a6") or {}
    achse("a6", None if a6.get("pz") is None else a6["pz"] * 100,
          "Gebote bis −1 % im Hyperliquid-Buch: " + (_mio(a6.get("roh")) if a6.get("roh") is not None else "—")
          + (f" ({schritt_text(a6['schritt'])})" if a6.get("roh") is not None and schritt_text(a6.get("schritt")) else ""),
          "100 − Perzentil gegen die Stundenwerte der letzten 30 Tage (dünnes Buch = hoher Wert)", "Mittel der letzten 60 Minuten", a6.get("grau"))
    a7 = LA.get("a7") or {}
    achse("a7", None if a7.get("pz") is None else a7["pz"] * 100,
          "Schwankung je Tag (σ): " + (_de((a7.get("roh") or 0) * 100, 2) + " %" if a7.get("roh") is not None else "—"),
          "Perzentil gegen die 365 Tage davor", _tag_txt(a7.get("tag")), a7.get("grau"))
    u = umfeld(lp, nb_stufe)
    achse("a8", u["wert"], "Umfeld: " + (", ".join(u["gruende"]) if u["gruende"] else ("nichts Besonderes" if not u["offen"] else "nichts Bekanntes")),
          "Stufen 0 · 33 · 66 · 100, kein Perzentil", "live",
          (("Lampe " if len(u["offen"]) == 1 else "Lampen ") + " und ".join(u["offen"]) + " grau -- ob das Umfeld belastet ist, ist nicht belegt."
           + umfeld_grund(lp, u["offen"])) if u["offen"] else None)
    out.sort(key=lambda a: a["key"])
    return out


def _mio(x) -> str:
    v = _zahl(x)
    if v is None:
        return "—"
    return (_de(v / 1e6, 1) + " Mio. USD") if abs(v) >= 1e6 else (_de(v / 1e3, 0) + " Tsd. USD")


def index_bauen(achsen: list) -> dict:
    """Druck-Index: Mittel der vorhandenen Achsen A1, A2, A3, A4, A7; mindestens vier."""
    w = [a["wert"] for a in achsen if a["key"] in INDEX_ACHSEN and a.get("wert") is not None]
    fehlen = [a["name"] for a in achsen if a["key"] in INDEX_ACHSEN and a.get("wert") is None]
    if len(w) < INDEX_MIN:
        return {"wert": None, "n": len(w), "fehlen": fehlen,
                "text": f"Druck-Index: kein Wert ({len(w)} von {len(INDEX_ACHSEN)} Achsen, gebraucht werden {INDEX_MIN}; es fehlen {', '.join(fehlen)})."}
    v = float(_hu(sum(w) / len(w), 0))
    return {"wert": v, "n": len(w), "fehlen": fehlen,
            "text": f"Druck-Index {_de(v, 0)} von 100 (Mittel aus {len(w)} Achsen" + (f"; ohne {', '.join(fehlen)}" if fehlen else "") + ") — gemessen, ungeprüft."}


def treiber_satz(achsen: list) -> str:
    """Die zwei höchsten Achsen in einem Satz."""
    da = sorted([a for a in achsen if a.get("wert") is not None], key=lambda a: (-a["wert"], a["key"]))
    if not da:
        return "Keine Achse hat einen Wert."
    if da[0]["wert"] <= 0:
        return "Keine Achse zeigt Druck (alle Werte bei 0, die übrigen grau)."
    return "Am höchsten: " + " und ".join(f"{a['name']} ({_de(a['wert'], 0)})" for a in da[:2] if a["wert"] > 0) + "."


def warnzeichen_bauen(B: dict) -> dict:
    """Kontenquote ≥ 3 (U142 H1, belegt) als eigene Zeile."""
    m = next((x for x in (B.get("messwerte") or []) if isinstance(x, dict) and x.get("key") == "konten"), {}) or {}
    w = _zahl(m.get("wert"))
    if w is None:
        return {"aktiv": None, "wert": None, "text": "Warnzeichen Kontenquote: kein Wert.", "beleg": BELEG_U142}
    aktiv = w >= KONTEN_AN
    return {"aktiv": aktiv, "wert": w, "beleg": BELEG_U142,
            "text": (f"Warnzeichen an: Kontenquote Binance {_de(w, 2)} (ab 3)." if aktiv else f"Warnzeichen aus: Kontenquote Binance {_de(w, 2)} (ab 3).")}


# ================================================================================================ Stand eines Coins

def stand(db: str, coin: str, jetzt: int | None = None, gemeinsam: dict | None = None, rb: dict | None = None, zust: dict | None = None,
          einst: dict | None = None, con_r=None) -> dict:
    """Alles für die Karte und den Alarm -- nur lesen. rb, zust, einst und con_r können mitgegeben werden (Takt), sonst liest die Funktion."""
    import hl_cockpit as HC
    jetzt = int(jetzt or time.time())
    if coin not in COINS:
        return {"ok": False, "coin": coin, "jetzt": jetzt, "fehlt": [f"Für {coin} rechnet das Risikoradar nicht (nur {', '.join(COINS)})."]}
    eigen = con_r is None
    if eigen:
        con_r = lesen(pfad(db))
    try:
        rb = rb if rb is not None else meta(con_r, "rueckblick")
        zust = zust if zust is not None else (meta(con_r, "zustand", {}) or {}).get(coin)
        einst = einst if einst is not None else einstellung_lesen(con_r)
        a5_hist = a5_verlauf(con_r, coin, jetzt)
        regeln_roh = meta(con_r, "regeln")                               # 23.123: das abgelegte Urteil der Regeln R1 bis R7 (Debug 163)
        zeichen = meta(con_r, "zeichen")                                 # 23.124: der Stand der belegten Zeichen (Regel A7; der Takt holt ihn)
    finally:
        if eigen and con_r is not None:
            con_r.close()
    zeit = {}; t_ = time.time()                                          # 23.123: wo bleibt die Rechenzeit? (Debug 160 nennt die Summen)
    G = gemeinsam if gemeinsam is not None else HC.gemeinsam_lesen(db, jetzt)
    Q = HC.quellen_lesen(db, coin, jetzt, gemeinsam=G)
    B = HC.bauen(Q)
    zeit["cockpit"] = time.time() - t_; t_ = time.time()
    kurs = _zahl((Q.get("kurs") or {}).get("px")); kurs_ts = (Q.get("kurs") or {}).get("ts")
    kurs_frisch = bool(kurs and kurs_ts is not None and jetzt - int(kurs_ts) <= FRISCH_KURS_S)
    lauf = None; lauf_fehlt = None
    try:
        import hl_ausblick as AU
        ac = AU.lesen(AU.ausblick_pfad(db))
        if ac is None:
            lauf_fehlt = "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt)."
        else:
            try:
                lauf = AU.lauf_lesen(ac, coin)
            finally:
                ac.close()
    except Exception as e:  # noqa: BLE001
        lauf_fehlt = f"Ausblick: {type(e).__name__}: {e}"[:160]
    trend = None
    try:                                                                 # enthält die jüngste Rechnung einen Trend (eines der Tore des Ausblicks offen)?
        P = HC._prognose_lesen(db, coin)
        if P and lauf and int(P.get("anker") or 0) == int(lauf.get("anker") or -1):
            trend = ((P.get("richtung") or {}).get("mhat")) or None
    except Exception:  # noqa: BLE001 -- ohne lesbare Rechnung gibt es keinen Hinweis
        trend = None
    zeit["ausblick"] = time.time() - t_; t_ = time.time()
    f = faktor(db, coin, jetzt)
    LA = lange_achsen(db, coin, jetzt)
    zeit["tagesreihen"] = time.time() - t_; t_ = time.time()
    con = HC._ro(db)
    try:
        T = tiefe_lesen(con, coin, jetzt)
    finally:
        if con is not None:
            con.close()
    zeit["orderbuch"] = time.time() - t_; t_ = time.time()
    KA = kurze_achsen(Q.get("liqdichte"), kurs, kurs_frisch, T, a5_hist, jetzt, HC.FRISCH_LIQ_S)
    nb = None
    try:
        import hl_notbremse as NB
        nb = NB.banner_daten(db, jetzt).get("stufe")
    except Exception:  # noqa: BLE001 -- ohne Notbremse zählt sie in A8 nicht
        nb = None
    zeit["notbremse"] = time.time() - t_
    S_ = stand_bauen(coin, jetzt, kurs, kurs_ts, kurs_frisch, lauf, lauf_fehlt, f, rb, zust, einst, B, LA, KA, nb, trend, zeichen)
    S_["zeit"] = zeit
    regeln_anhaengen(S_, regeln_roh)
    zeichen_anhaengen(S_, zeichen, jetzt, rb)
    return S_


ZEIT_NAMEN = (("cockpit", "Quellen des Cockpits"), ("ausblick", "Ausblick"), ("tagesreihen", "Tagesreihen"), ("orderbuch", "Orderbuch"),
              ("notbremse", "Notbremse"))


def zeit_satz(summen: dict, gemeinsam_s: float | None = None) -> str:
    """Wo die Rechenzeit des Berichts blieb: Summen je Abschnitt über alle Coins (Sekunden)."""
    teile = ([f"gemeinsame Quellen {_de(gemeinsam_s, 1)} s"] if gemeinsam_s is not None else [])
    teile += [f"{name} {_de(summen.get(key) or 0.0, 1)} s" for key, name in ZEIT_NAMEN]
    return "davon " + " · ".join(teile)


def regeln_kurz(v) -> dict | None:
    """Das abgelegte Urteil der Regeln (rd_meta „regeln“, geschrieben von hl_radar_regeln) in Kurzform: je Ereignis die Schlüssel der
    belegten und der prüfbaren Regeln. None, solange kein vollständiges Urteil abgelegt ist."""
    if (not isinstance(v, dict) or v.get("fassung") != REGELN_FASSUNG or not v.get("vollstaendig") or not isinstance(v.get("tests"), dict)
            or not v.get("tests")):
        return None
    out = {"ts": v.get("ts"), "fassung": v.get("fassung"), "belegt": {}, "pruefbar": {}, "coins": [str(c) for c in v.get("coins") or []]}
    for key in EREIGNIS:
        T = v["tests"].get(key) or {}
        out["belegt"][key] = sorted(rk for rk, o in T.items() if isinstance(o, dict) and o.get("belegt"))
        out["pruefbar"][key] = sorted(rk for rk, o in T.items() if isinstance(o, dict) and o.get("pruefbar"))
    return out


def regeln_satz(kurz: dict | None) -> str:
    """Ein Satz für Karte und Debug 160: was die Prüfung der Regeln R1 bis R7 ergeben hat."""
    if not kurz:
        return ("Warnzeichen R1 bis R7: noch nicht geprüft (Debug 163 rechnet das Urteil, sobald die Historie der Hebel-Studie vollständig geladen ist).")
    teile = []
    for key, E in EREIGNIS.items():
        b = [(r.upper() + " " + REGELN_NAMEN[r]) if r in REGELN_NAMEN else r.upper() for r in kurz["belegt"].get(key) or []]
        teile.append(f"für {E['kurz']} " + (("belegt: " + ", ".join(b)) if b else "keine belegt"))
    return f"Warnzeichen R1 bis R7 (Debug 163, geprüft {_dt(kurz.get('ts'))}): " + "; ".join(teile) + ". Belegt heißt: häufiger als sonst, nicht: es kommt."


def regeln_anhaengen(S: dict, regeln_roh) -> dict:
    """Urteil der Regeln an den Stand hängen: Kurzform, Satz und der Vermerk am Druck-Index (R7), sobald er geprüft ist."""
    kurz = regeln_kurz(regeln_roh)
    S["regeln"] = kurz; S["regeln_satz"] = regeln_satz(kurz)
    idx = S.get("index") or {}
    if kurz and isinstance(idx.get("text"), str) and idx["text"].endswith("— gemessen, ungeprüft."):
        wo = [EREIGNIS[k_]["kurz"] for k_ in EREIGNIS if "r7" in (kurz["belegt"].get(k_) or [])]
        idx["text"] = idx["text"][:-len("gemessen, ungeprüft.")] + ("gemessen; als Warnzeichen geprüft (R7): "
                                                                     + (("belegt für " + " und ".join(wo)) if wo else "nicht belegt") + ".")
    return S


def takt_dauer_satz(takt) -> str:
    """Wie lange der letzte Schritt des Takts gedauert hat und wo die Zeit blieb (leer, solange der Takt es nicht festgehalten hat)."""
    if not isinstance(takt, dict) or _zahl(takt.get("dauer_s")) is None:
        return ""
    n = len(takt.get("coins") or [])
    return (f" · der Schritt dauerte {_de(takt['dauer_s'], 1)} s für {n} Coin{'s' if n != 1 else ''}"
            + (f" ({zeit_satz(takt['zeit'])})" if isinstance(takt.get("zeit"), dict) and takt["zeit"] else "")
            + (f", dazu {_de(takt['zeichen_s'], 1)} s für den Stand der Zeichen" if _zahl(takt.get("zeichen_s")) is not None else ""))


def takt_voll_satz(voll, takt=None) -> str:
    """23.125 (U312): der letzte Schritt zur vollen Stunde, der alle Coins rechnet und ablegt -- leer, solange keiner festgehalten ist
    oder wenn er selbst der letzte Schritt ist (dann steht er schon da)."""
    if not isinstance(voll, dict) or not voll.get("ts") or _zahl(voll.get("dauer_s")) is None:
        return ""
    if isinstance(takt, dict) and takt.get("ts") == voll.get("ts"):
        return ""
    return f"; zur vollen Stunde zuletzt {_dt(voll['ts'])}:" + takt_dauer_satz(voll)[2:]


def trend_satz(mhat: dict | None) -> str | None:
    """
    Hinweis, wenn die jüngste Rechnung des Ausblicks einen Trend enthält (eines seiner Tore ist offen; m̂ je Horizont in üblichen
    Schwankungen des Horizonts). Der Rückblick des Radars rechnet ohne Trend (wie S3 des Ausblicks) -- das soll dastehen.
    """
    if not isinstance(mhat, dict):
        return None
    teile = []
    for h, v in sorted(mhat.items(), key=lambda kv: int(kv[0]) if str(kv[0]).isdigit() else 0):
        w = _zahl(v)
        if w is not None and _hu(w, 2) != 0:
            teile.append(f"{h} Tage {_de(w, 2, True)} σ")
    if not teile:
        return None
    return ("Die jüngste Rechnung des Ausblicks enthält einen Trend (" + ", ".join(teile) + "); er steckt in beiden Zahlen. "
            "Der Rückblick des Radars hat die Zahlen ohne Trend geprüft.")


def stand_bauen(coin: str, jetzt: int, kurs, kurs_ts, kurs_frisch: bool, lauf, lauf_fehlt, f: dict, rb, zust, einst: dict, B: dict, LA: dict,
                KA: dict, nb, trend: dict | None = None, zeichen: dict | None = None) -> dict:
    """Der Stand eines Coins aus seinen Teilen -- ohne Zugriff auf Dateien (die Proben bauen ihn von Hand)."""
    E = ereignisse_bauen(coin, lauf, lauf_fehlt, f, kurs, kurs_frisch, jetzt, rb, zust, (einst or EINSTELLUNG_VORGABE)["pz"], zeichen)
    achsen = achsen_bauen(B, LA, KA, nb, coin)
    idx = index_bauen(achsen)
    return {"ok": True, "coin": coin, "jetzt": int(jetzt), "version": VERSION_MODUL,
            "kurs": {"px": kurs, "ts": kurs_ts, "frisch": bool(kurs_frisch)}, "faktor": f, "ereignis": E, "achsen": achsen, "index": idx,
            "treiber": treiber_satz(achsen), "warnzeichen": warnzeichen_bauen(B), "a5_roh": KA["a5"].get("roh"), "a6_roh": KA["a6"].get("roh"),
            "rueckblick_stand": (rb or {}).get("stand"), "trend": trend_satz(trend)}


# ================================================================================================ Alarm (Abschnitt 6)

def meldung_bauen(art: str, S: dict, key: str | None) -> dict:
    """Titel, Text und Ansage einer Meldung. Kein Pfeil, kein Empfehlungswort; Thema und Schlüssel kommen hier nicht vor."""
    coin = S["coin"]
    hoechste = [a for a in sorted([a for a in S.get("achsen") or [] if a.get("wert") is not None], key=lambda a: (-a["wert"], a["key"]))][:2]
    achsen_txt = ("Höchste Achsen: " + ", ".join(f"{a['name']} {_de(a['wert'], 0)}" for a in hoechste) + ". ") if hoechste else ""
    wz = S.get("warnzeichen") or {}
    wz_txt = (f"Warnzeichen: Kontenquote {_de(wz.get('wert'), 2)}. " if wz.get("aktiv") else "")
    stand_txt = f"Stand {_orts(S.get('jetzt'))}."
    if art == "hinweis":
        return {"art": art, "coin": coin, "ereignis": None, "p": None, "prio": 3, "titel": f"Risikoradar {coin}: Warnzeichen Kontenquote",
                "text": (f"Kontenquote Binance {_de(wz.get('wert'), 2)} (ab 3). In solchen Lagen folgte in 7 Tagen häufiger ein Rücksetzer "
                         f"(U142: 20,3 % gegen 7,3 %). {stand_txt}"),
                "ansage": None}
    e = (S.get("ereignis") or {}).get(key) or {}
    zahl = f"−{e.get('x_text')} in {e.get('frist')}: {e.get('p_text')}" + (f" (üblich {p_text(e['grundrate'])})" if e.get("grundrate") is not None else "")
    if art == "entwarnung":
        return {"art": art, "coin": coin, "ereignis": key, "p": e.get("p"), "prio": 2, "titel": f"Risikoradar {coin}: nicht mehr hoch",
                "text": f"{zahl}. Die Stufe „hoch“ ist beendet. {stand_txt}", "ansage": None}
    af = e.get("auf") or {}
    auf_txt = (f"Darin der Aufschlag für das Warnzeichen {af.get('name') or regel_name(af.get('regel'))} (ohne ihn {e.get('p_ohne_text')}). "
               if af.get("k", 0) >= 1 and e.get("p_ohne_text") else "")
    pz = _zahl(e.get("p"))
    proz = (_de(pz * 100, 1) if pz is not None and _hu(pz * 100, 1) < 10 else _de((pz or 0) * 100, 0)).replace(",", " Komma ")
    x_an = str(e.get("x_text") or "").replace(" %", "").replace(",", " Komma ")
    return {"art": "alarm", "coin": coin, "ereignis": key, "p": e.get("p"), "prio": 5, "titel": f"Risikoradar {coin}: Risiko hoch",
            "text": f"{zahl}. {auf_txt}{achsen_txt}{wz_txt}{stand_txt}",
            "ansage": f"Risikoradar. {NAMEN.get(coin, coin)}. Risiko hoch. {proz} Prozent für minus {x_an} Prozent in {e.get('frist')}."}


def alarm_schritt(Z: dict | None, S: dict, jetzt: int, melden: bool = True) -> tuple:
    """
    Ein Schritt der Zustände eines Coins. Z = {e7: {hoch, seit, alarm_ts, gemeldet}, e2: …, konten: {scharf, hinweis_ts}}.
    -> (neuer Zustand, Meldungen). Ohne Zahl oder ohne Stufe bleibt der Zustand, wie er ist (eine Lücke löst nichts aus und beendet nichts).
    melden=False (der Coin ist nicht für Meldungen gewählt): „hoch“ und die Kontenquote laufen mit, aber nichts gilt als gemeldet --
    keine Sperrzeit aus einem Alarm, den es nicht gab, und später keine Entwarnung ohne Alarm.
    """
    Z = json.loads(json.dumps(Z)) if isinstance(Z, dict) else {}
    M = []
    jetzt = int(jetzt)
    for key in EREIGNIS:
        z = Z.setdefault(key, {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False})
        e = (S.get("ereignis") or {}).get(key) or {}
        if e.get("stufe") in (None, "ohne"):
            continue
        ist = e["stufe"] == "hoch"
        if ist and not z.get("hoch"):
            z["hoch"] = True; z["seit"] = jetzt; z["gemeldet"] = False
            if melden and jetzt - int(z.get("alarm_ts") or 0) >= SPERRZEIT_S:
                z["alarm_ts"] = jetzt; z["gemeldet"] = True
                M.append(meldung_bauen("alarm", S, key))
        elif z.get("hoch") and not ist:
            z["hoch"] = False; z["seit"] = None
            if melden and z.get("gemeldet"):
                M.append(meldung_bauen("entwarnung", S, key))
            z["gemeldet"] = False
    k = Z.setdefault("konten", {"scharf": None, "hinweis_ts": 0})
    w = _zahl((S.get("warnzeichen") or {}).get("wert"))
    if w is not None:
        if w < KONTEN_AUS:
            k["scharf"] = True
        elif w >= KONTEN_AN:
            if k.get("scharf"):
                if melden and jetzt - int(k.get("hinweis_ts") or 0) >= HINWEIS_SPERRE_S:
                    k["hinweis_ts"] = jetzt
                    M.append(meldung_bauen("hinweis", S, None))
            k["scharf"] = False
        elif k.get("scharf") is None:
            k["scharf"] = False
    return Z, M


def push_einstellung() -> dict:
    """{"thema", "server"} der Benachrichtigung (hl_berichte); das Thema verlässt diese Funktion nur in Richtung senden()."""
    try:
        import hl_berichte as HBR
        return HBR.einstellung_lesen()
    except Exception:  # noqa: BLE001
        return {"thema": "", "server": ""}


def meldungen_ablegen(con, M: list, einst: dict, jetzt: int, eingerichtet: bool) -> list:
    """Meldungen in rd_alarm eintragen. Push ist offen, wenn der Schalter an, das Thema eingerichtet und der Coin gewählt ist."""
    ids = []
    for m in M:
        gewaehlt = m["coin"] in (einst.get("coins") or [])
        push = PUSH_OFFEN if (gewaehlt and einst.get("push") and eingerichtet) else PUSH_AUS
        if not gewaehlt:
            continue                                                     # Zustand läuft mit, gemeldet wird nur für gewählte Coins
        cur = con.execute("INSERT INTO rd_alarm (ts, coin, ereignis, art, p, titel, text, ansage, prio, push) VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (int(jetzt), m["coin"], m.get("ereignis"), m["art"], m.get("p"), m["titel"], m["text"], m.get("ansage"), int(m["prio"]), push))
        ids.append(cur.lastrowid)
    return ids


def push_senden(con, jetzt: int, http_fn=None, einstellung: dict | None = None) -> dict:
    """Offene Meldungen senden (höchstens fünf Versuche, binnen einer Stunde); Fehlertexte ohne Thema."""
    out = {"gesendet": 0, "fehler": 0, "aufgegeben": 0}
    offen = con.execute("SELECT id, ts, titel, text, prio, versuche FROM rd_alarm WHERE push=? ORDER BY id", (PUSH_OFFEN,)).fetchall()
    if not offen:
        return out
    ein = einstellung if einstellung is not None else push_einstellung()
    import hl_berichte as HBR
    for id_, ts, titel, text_, prio, versuche in offen:
        if int(jetzt) - int(ts) > PUSH_FRIST_S or int(versuche or 0) >= PUSH_VERSUCHE or not ein.get("thema"):
            con.execute("UPDATE rd_alarm SET push=?, push_fehler=COALESCE(push_fehler, ?) WHERE id=?",
                        (PUSH_AUFGEGEBEN, "nicht gesendet (Frist, Versuche oder Benachrichtigung nicht eingerichtet)", id_))
            out["aufgegeben"] += 1; continue
        try:
            kw = {"prio": int(prio), "tags": ("rotating_light",) if int(prio) >= 5 else ("information_source",)}
            if http_fn is not None:
                kw["http_fn"] = http_fn
            ok, info = HBR.senden(ein["thema"], titel, text_, ein.get("server") or HBR.NTFY_SERVER, **kw)[:2]
        except Exception as e:  # noqa: BLE001
            ok, info = False, type(e).__name__
        if ok:
            con.execute("UPDATE rd_alarm SET push=?, versuche=versuche+1, push_fehler=NULL WHERE id=?", (PUSH_GESENDET, id_)); out["gesendet"] += 1
        else:
            fehler = str(info or "Fehler")[:160].replace(ein.get("thema") or "\x00", "…")
            con.execute("UPDATE rd_alarm SET versuche=versuche+1, push_fehler=? WHERE id=?", (fehler, id_)); out["fehler"] += 1
    return out


# ================================================================================================ Takt

_TAKT = {"gestartet": False, "stop": None, "proc": None, "letzter_rueckblick_start": 0.0, "fehler": None, "schritte": 0}


class RbSperre:
    """
    Ein Rückblick zur selben Zeit (der Takt des Dashboards und Debug 161 können ihn beide anstoßen): flock auf
    <radar.db>.rueckblick.lock. Der Kernel gibt die Sperre frei, wenn der Prozess endet -- auch nach einem Abbruch; es bleibt nichts
    hängen. Wo es fcntl nicht gibt oder die Datei nicht sperrbar ist, rechnet der Lauf ohne Sperre (doppelt rechnen ist nur Zeit).
    """

    def __init__(self, db: str):
        self.datei = pfad(db) + ".rueckblick.lock"
        self.fd = None

    def nehmen(self) -> bool:
        try:
            import fcntl
        except ImportError:
            return True
        try:
            self.fd = os.open(self.datei, os.O_CREAT | os.O_RDWR, 0o644)
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:                                          # ein anderer Lauf hält sie
            os.close(self.fd); self.fd = None
            return False
        except OSError:
            if self.fd is not None:
                os.close(self.fd); self.fd = None
            return True

    def lassen(self) -> None:
        if self.fd is not None:
            try:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_UN)
            except (ImportError, OSError):
                pass
            os.close(self.fd); self.fd = None


def rueckblick_faellig(rb: dict | None, jetzt: float, letzter_start: float, regeln_ts=None) -> bool:
    if jetzt - letzter_start < RUECKBLICK_WIEDER_S:
        return False
    if (isinstance(rb, dict) and rb.get("version") == VERSION_MODUL and _zahl(regeln_ts) is not None
            and float(regeln_ts) > float(rb.get("stand") or 0)):
        return True                                                       # Regel A: das Urteil der Regeln ist jünger als der Rückblick
    if isinstance(rb, dict) and rb.get("version") == VERSION_MODUL and monatserster(int(jetzt) // TAG) != monatserster(int(float(rb.get("stand") or 0)) // TAG):
        return True                                                       # Regel K5: neuer Monat -> neue Anpassung
    return (not isinstance(rb, dict)) or rb.get("version") != VERSION_MODUL or jetzt - float(rb.get("stand") or 0) > RUECKBLICK_MAX_ALTER_S


def _starte_rueckblick(db: str) -> bool:
    """Der Rückblick rechnet in einem eigenen Prozess; er senkt seine Priorität selbst (wie hl_ausblick seit 23.114, ohne preexec_fn)."""
    import subprocess
    import hl_ausblick as AU
    p = _TAKT.get("proc")
    if p is not None and p.poll() is None:
        return False
    log = os.path.join(os.path.dirname(pfad(db)), "radar_takt.log")
    try:
        if os.path.exists(log) and os.path.getsize(log) > 1_000_000:
            os.replace(log, log + ".1")
        f = open(log, "a")
        f.write(f"[{time.strftime('%d.%m. %H:%M:%S')}] Start Rückblick\n"); f.flush()
        _TAKT["proc"] = subprocess.Popen([sys.executable, os.path.abspath(__file__), "--rueckblick", "--db", db], stdout=f,
                                         stderr=subprocess.STDOUT, env=AU.kind_umgebung(), cwd=os.path.dirname(os.path.abspath(__file__)))
        f.close()
    except OSError as e:
        _TAKT["fehler"] = f"{type(e).__name__}: {e}"
        return False
    _TAKT["letzter_rueckblick_start"] = time.time()
    return True


def takt_schritt(db: str, con, jetzt: int | None = None, http_fn=None, push_ein: dict | None = None, starte_rb=None, stand_fn=None,
                 gemeinsam_fn=None, zeichen_fn=None) -> dict:
    """
    Ein Schritt: Stand je Coin (gewählte Coins jedes Mal, alle zur vollen Stunde), Zustände und Meldungen, Ablage je Stunde, Push.
    Fehler eines Coins bleiben im Ergebnis stehen, die anderen laufen weiter.
    """
    jetzt = int(jetzt or time.time()); t0_ = time.time(); zsum = {}
    if gemeinsam_fn is None:
        import hl_cockpit as HC
        gemeinsam_fn = HC.gemeinsam_lesen
    stand_fn = stand_fn or stand
    out = {"coins": [], "meldungen": 0, "abgelegt": 0, "fehler": [], "rueckblick_gestartet": False}
    rb = meta(con, "rueckblick")
    if rueckblick_faellig(rb, jetzt, _TAKT["letzter_rueckblick_start"], (regeln_kurz(meta(con, "regeln")) or {}).get("ts")):
        out["rueckblick_gestartet"] = bool((starte_rb or _starte_rueckblick)(db))
        if out["rueckblick_gestartet"]:
            _TAKT["letzter_rueckblick_start"] = float(jetzt)
    zeichen_s = None
    try:                                                                 # Regel A7: einmal am Tag der Stand der belegten Zeichen
        tz_ = time.time()
        if (zeichen_fn or zeichen_pflegen)(db, con, jetzt):
            zeichen_s = round(time.time() - tz_, 2)
    except Exception as e:  # noqa: BLE001 -- ohne Stand der Zeichen bleibt die Zahl ohne Aufschlag
        out["fehler"].append(f"Zeichen: {type(e).__name__}: {e}"[:200])
    einst = einstellung_lesen(con)
    Zalle = meta(con, "zustand", {}) or {}
    stunde = jetzt // ABLAGE_S
    letzte = int(meta(con, "letzte_ablage", 0) or 0)
    alle = stunde > letzte
    coins = COINS if alle else tuple(c for c in COINS if c in einst["coins"])
    if alle and meta(con, "tiefe_ab") is None:
        meta_setzen(con, "tiefe_ab", stunde)                             # 23.125 (U311): ab hier zählt der eigene Verlauf von A5 (Gebote bis −1 %)
    ein = push_ein if push_ein is not None else push_einstellung()
    G = None
    for coin in coins:
        try:
            G = G if G is not None else gemeinsam_fn(db, jetzt)
            S = stand_fn(db, coin, jetzt, gemeinsam=G, rb=rb or {}, zust=Zalle.get(coin) or {}, einst=einst, con_r=con)
            if not S.get("ok"):
                out["fehler"].append(f"{coin}: {' '.join(S.get('fehlt') or [])}"); continue
            for k_, v_ in (S.get("zeit") or {}).items():
                zsum[k_] = zsum.get(k_, 0.0) + float(v_)
            Z, M = alarm_schritt(Zalle.get(coin), S, jetzt, melden=coin in einst["coins"])
            Zalle[coin] = Z
            out["meldungen"] += len(meldungen_ablegen(con, M, einst, jetzt, bool(ein.get("thema"))))
            if alle:
                kurz = {"e": {k: {"p": e.get("p"), "stufe": e.get("stufe"), "x": e.get("x")} for k, e in S["ereignis"].items()},
                        "achsen": {a["key"]: a.get("wert") for a in S["achsen"]}, "konten": (S.get("warnzeichen") or {}).get("wert"),
                        "kurs": S["kurs"].get("px")}
                if any(e.get("kal") for e in S["ereignis"].values()):
                    kurz["roh"] = {k: e.get("p_roh") for k, e in S["ereignis"].items() if e.get("kal")}   # Regel K: die Rohzahl dazu
                if any(e.get("auf") for e in S["ereignis"].values()):     # Regel A7: Zustand und die Zahl ohne Aufschlag dazu
                    kurz["ohne"] = {k: e.get("p_ohne") for k, e in S["ereignis"].items() if e.get("auf")}
                    kurz["zeichen"] = {k: e["auf"].get("k") for k, e in S["ereignis"].items() if e.get("auf")}
                con.execute("INSERT OR REPLACE INTO rd_stand VALUES (?,?,?,?,?,?,?,?,?)",
                            (stunde, coin, jetzt, S["ereignis"]["e7"].get("p"), S["ereignis"]["e2"].get("p"), S["index"].get("wert"),
                             S.get("a5_roh"), S.get("a6_roh"), json.dumps(_ohne_nan(kurz), ensure_ascii=False)))
                out["abgelegt"] += 1
            out["coins"].append(coin)
        except Exception as e:  # noqa: BLE001 -- ein Coin darf den Takt nicht anhalten
            out["fehler"].append(f"{coin}: {type(e).__name__}: {e}"[:200])
    meta_setzen(con, "zustand", Zalle)
    if alle:
        meta_setzen(con, "letzte_ablage", stunde)
    out["push"] = push_senden(con, jetzt, http_fn=http_fn, einstellung=ein)
    out["dauer_s"] = round(time.time() - t0_, 2); out["zeit"] = {k_: round(v_, 2) for k_, v_ in zsum.items()}
    if zeichen_s is not None:
        out["zeichen_s"] = zeichen_s
    meta_setzen(con, "takt", {"ts": jetzt, "coins": out["coins"], "fehler": out["fehler"][:5], "dauer_s": out["dauer_s"], "zeit": out["zeit"],
                              **({"zeichen_s": zeichen_s} if zeichen_s is not None else {})})
    if alle:                                                             # 23.125 (U312): der Schritt zur vollen Stunde (alle Coins) eigens
        meta_setzen(con, "takt_voll", {"ts": jetzt, "coins": out["coins"], "dauer_s": out["dauer_s"], "zeit": out["zeit"],
                                       **({"zeichen_s": zeichen_s} if zeichen_s is not None else {})})
    _TAKT["schritte"] += 1
    return out


def starte(db: str, stop: threading.Event | None = None, verzoegerung: float = 90.0, schritt=None, takt_s: float = TAKT_S):
    """
    Eigener Faden „radar“ im Dashboard-Prozess: nach 90 s der erste Schritt, dann alle 5 Minuten. Aus mit HL_RADAR=0. Ein Fehler
    (Laufwerk nicht eingehängt, Datenbank gesperrt) beendet den Faden nicht: Er meldet ihn in der Ausgabe des Dashboards und versucht
    es beim nächsten Schritt wieder -- nach einem Fehler der Datenbank mit einer neuen Verbindung.
    """
    if os.environ.get("HL_RADAR", "1") == "0" or not db or db == ":memory:":
        return None
    stop = stop or threading.Event()
    schritt = schritt or takt_schritt

    def lauf():
        if stop.wait(verzoegerung):
            return
        con = None
        while not stop.is_set():
            try:
                if con is None:
                    con = verbinden(pfad(db))
                schritt(db, con)
                _TAKT["fehler"] = None
            except Exception as e:  # noqa: BLE001 -- der Faden läuft weiter
                _TAKT["fehler"] = f"{type(e).__name__}: {e}"[:200]
                print("Risikoradar: " + _TAKT["fehler"], flush=True)
                if isinstance(e, sqlite3.Error) and con is not None:
                    try:
                        con.close()
                    except sqlite3.Error:
                        pass
                    con = None
            stop.wait(takt_s)
        if con is not None:
            try:
                con.close()
            except sqlite3.Error:
                pass

    t = threading.Thread(target=lauf, name="radar", daemon=True)
    t.start()
    return t


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen. Nicht für Selbsttest-Datenbanken; aus mit HL_RADAR=0."""
    if _TAKT["gestartet"] or os.path.basename(db or "").startswith("_selftest"):
        return False
    stop = threading.Event()
    if starte(db, stop=stop) is None:                                    # HL_RADAR=0 oder keine Datenbank: nichts gestartet, nichts gemerkt
        return False
    _TAKT["gestartet"] = True
    _TAKT["stop"] = stop
    return True
# ================================================================================================ Nachkalibrierung (Regel K, Abschnitt 13)

def logit_anpassen(y, p):
    """
    Regel K1: logistische Regression des Eintritts auf logit p (Newton/IRLS, dieselbe Rechnung wie hl_ausblick.logit_steigung -- deren
    Steigung ist b). -> (a, b) oder None (unter 30 Werten, nur ein Ausgang, keine Konvergenz).
    """
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    ok = np.isfinite(p) & np.isfinite(y)
    y = y[ok]; p = np.clip(p[ok], 1e-4, 1 - 1e-4)
    if len(y) < 30 or y.min() == y.max():
        return None
    X = np.column_stack([np.ones(len(y)), np.log(p / (1 - p))])
    b = np.array([0.0, 1.0]); fertig = False
    for _ in range(50):
        eta = np.clip(X @ b, -30, 30); mu = 1 / (1 + np.exp(-eta))
        W = mu * (1 - mu) + 1e-12
        g = X.T @ (y - mu); H = (X * W[:, None]).T @ X
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            return None
        b = b + step
        if np.max(np.abs(step)) < 1e-10:
            fertig = True
            break
    if not fertig or not np.all(np.isfinite(b)):
        return None
    return float(b[0]), float(b[1])


def kal_zahl(p_roh, a, b):
    """Regel K1: kalibrierte Zahl aus der Rohzahl -- logit p' = a + b · logit p; Rohzahl und Ergebnis auf 0,5 % … 99,5 % begrenzt."""
    v = _zahl(p_roh); a = _zahl(a); b = _zahl(b)
    if v is None or a is None or b is None:
        return None
    v = min(max(v, KAL_P[0]), KAL_P[1])
    z = a + b * math.log(v / (1 - v))
    return min(max(1.0 / (1.0 + math.exp(-z)), KAL_P[0]), KAL_P[1])


def kal_reihen(tau, p, ja, h_tage: int, bis_tag: int) -> dict:
    """
    Regel K2: je Monatserstem M (UTC) eine Anpassung aus allen Ursprüngen, deren Frist bis dahin abgelaufen ist (τ + h Tage ≤ M) --
    mindestens KAL_MIN_TAGE Ursprungstage und KAL_MIN_EREIGNISSE Ereignisse, sonst keine. Sie gilt für die Ursprünge des Monats M.
    -> {"p": kalibrierte Zahl je Ursprung (NaN ohne Anpassung), "fits": [[M, a, b, Tage, Ereignisse], …] bis zum Monat von bis_tag,
        "aktuell": die Anpassung des letzten Monats oder None}
    """
    tau = np.asarray(tau, dtype=np.int64); p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float)
    out = np.full(len(tau), np.nan); fits = []
    if not len(tau):
        return {"p": out, "fits": fits, "aktuell": None}
    tage = tau // TAG
    erste = {int(t): monatserster(int(t)) for t in np.unique(tage)}
    mon = np.array([erste[int(t)] for t in tage], dtype=np.int64)
    ok = np.isfinite(p) & np.isfinite(ja)
    M = monatserster(int(tage.min())); ende = monatserster(int(max(int(bis_tag), int(tage.max()))))
    while M <= ende:
        m = ok & (tau + int(h_tage) * TAG <= M * TAG)
        n_tage = int(len(np.unique(tage[m]))); n_er = int(ja[m].sum())
        ab = logit_anpassen(ja[m], p[m]) if (n_tage >= KAL_MIN_TAGE and n_er >= KAL_MIN_EREIGNISSE) else None
        if ab is not None:
            sel = (mon == M) & np.isfinite(p)
            if sel.any():
                pc = np.clip(p[sel], KAL_P[0], KAL_P[1])
                out[sel] = np.clip(1.0 / (1.0 + np.exp(-(ab[0] + ab[1] * np.log(pc / (1 - pc))))), KAL_P[0], KAL_P[1])
        fits.append([int(M), ab[0] if ab else None, ab[1] if ab else None, n_tage, n_er])
        M = monatserster(M + 32)
    le = fits[-1]
    akt = {"monat": le[0], "a": le[1], "b": le[2], "n_tage": le[3], "n_ereignisse": le[4]} if le[1] is not None else None
    return {"p": out, "fits": fits, "aktuell": akt}


def kal_auswerten(out: dict, key: str, E: dict, R: dict, tau, ci, p, ja, g, bis_tag) -> np.ndarray:
    """Regel K für ein Ereignis: kalibrierte Reihe (K2), Urteil G7k bzw. G2k mit denselben Kriterien (K3), Schwellen und Alarme je Coin
    auf der kalibrierten Zahl, Entscheidung der Anzeige (K4): „kal“ nur, wenn die kalibrierte Fassung besteht und die Anpassung des
    laufenden Monats vorliegt."""
    bt = int(bis_tag) if bis_tag is not None else int(np.max(tau) // TAG)
    KL = kal_reihen(tau, p, ja, E["tage"], bt)
    u = g_urteil(key + "k", tau, ci, KL["p"], ja, g, seed=17 if key == "e7" else 12)
    coins = {}
    for coin in R:
        m = np.asarray(ci) == coin
        if not m.any():
            continue
        pk = KL["p"][m]; jk = np.asarray(ja)[m]; tk = np.asarray(tau)[m]
        okc = np.isfinite(pk) & np.isfinite(jk)
        sw = schwellen_bauen(pk, jk)
        alarme_fuer(tk[okc], pk[okc], jk[okc], sw)
        coins[coin] = sw
    besteht = bool(u.get("besteht")) and KL["aktuell"] is not None
    out.setdefault("kal", {})[key] = {"urteil": u, "fits": KL["fits"], "aktuell": KL["aktuell"], "coins": coins, "besteht": besteht}
    out.setdefault("anzeige", {})[key] = "kal" if besteht else "roh"
    return KL["p"]                                                        # die kalibrierte Reihe -- Grundlage des Aufschlags (Regel A)


def kal_abschluss(out: dict) -> dict:
    """Ohne kalibrierte Fassung (keine Ursprünge) bleibt es bei der Rohzahl."""
    out.setdefault("kal", {}); out.setdefault("anzeige", {})
    for key in EREIGNIS:
        out["anzeige"].setdefault(key, "roh")
    return out


def kal_fuer(rb: dict | None, coin: str, key: str) -> dict | None:
    """Regel K4 für die Anzeige: die kalibrierte Fassung dieser Zahl, wenn sie im Rückblick besteht und eine Anpassung vorliegt; sonst None."""
    k = ((rb or {}).get("kal") or {}).get(key) or {}
    ak = k.get("aktuell") or {}
    if ((rb or {}).get("anzeige") or {}).get(key) not in ("kal", "auf") or not (k.get("urteil") or {}).get("besteht"):
        return None
    if _zahl(ak.get("a")) is None or _zahl(ak.get("b")) is None:
        return None
    return {"a": float(ak["a"]), "b": float(ak["b"]), "monat": ak.get("monat"), "urteil": k["urteil"], "r": (k.get("coins") or {}).get(coin) or {}}


def kal_urteil_satz(key: str, u: dict | None, rb: dict | None) -> str:
    """Ein Satz zum Rückblick der nachkalibrierten Zahl (G7k bzw. G2k)."""
    name = "G7k" if key == "e7" else "G2k"
    if not u:
        return f"Für die nachkalibrierte Zahl ({name}) liegt kein Urteil vor."
    kk = (f"Rückblick {name} (nachkalibriert) vom {_dt((rb or {}).get('stand'))}: {_tsd(u.get('n'))} Ursprünge an {_tsd(u.get('n_tage'))} Tagen, "
          f"{_tsd(u.get('n_ereignisse'))} Ereignisse, Skill {_de((_zahl(u.get('skill')) or 0) * 100, 1, True)} % ({p_wert_text(u.get('p'))}), "
          f"Steigung {_de(u.get('steigung'), 2)}, Niveau {_de(u.get('niveau'), 2)}")
    if u.get("besteht"):
        return kk + " — besteht."
    return kk + f" — nicht bestätigt: {u.get('grund') or 'ohne Angabe'}."


KAL_VERMERK = ("Nachkalibriert (Regel K): Die Rohzahl aus der Verteilung des Ausblicks schlug im Rückblick zu stark aus (hohe Werte zu hoch, "
               "niedrige zu niedrig). Eine feste Formel gleicht sie an das an, was früher eintrat -- je Monat neu, nur aus Tagen, deren Frist "
               "abgelaufen war. Die angepasste Zahl hat dieselbe Prüfung bestanden wie die Rohzahl; es war eine zweite Prüfung auf denselben "
               "Daten. Der Kurs-Rechner zeigt weiter die Rohzahl.")


def kal_zeilen(rb: dict) -> list:
    """Abschnitt „Nachkalibrierung“ von Debug 161."""
    z = []; a = z.append
    K = rb.get("kal") or {}
    if not K:
        return z
    a("")
    a("== Nachkalibrierung (Regel K, KONZEPT_Risikoradar.md 13; Entscheidung des Nutzers vom 24.11.2026) -- zweite Prüfung auf denselben Daten")
    a(f"   logit p′ = a + b · logit p, je Monatserstem neu aus allen Ursprüngen mit abgelaufener Frist (mindestens {KAL_MIN_TAGE} Ursprungstage und "
      f"{KAL_MIN_EREIGNISSE} Ereignisse). Besteht die kalibrierte Fassung dieselben vier Kriterien, zeigt die Karte sie; sonst bleibt es bei der "
      "Rohzahl und ihrem Urteil. Kein dritter Versuch.")
    for key, E in EREIGNIS.items():
        k = K.get(key) or {}; u = k.get("urteil") or {}
        name = "G7k" if key == "e7" else "G2k"
        a("")
        a(f"   {name} · {E['kurz']}: " + kal_urteil_satz(key, u, rb))
        ak = k.get("aktuell")
        fits = [f for f in (k.get("fits") or []) if f[1] is not None]
        if fits:
            bs = [f[2] for f in fits]
            a(f"      Anpassungen: {len(fits)} Monate ab {_tag_txt(fits[0][0])}; b zwischen {_de(min(bs), 2)} und {_de(max(bs), 2)}"
              + (f" · laufender Monat ({_tag_txt(ak['monat'])}): a {_de(ak['a'], 3, True)}, b {_de(ak['b'], 3)} aus {_tsd(ak['n_tage'])} Tagen und "
                 f"{_tsd(ak['n_ereignisse'])} Ereignissen" if ak else " · für den laufenden Monat liegt keine Anpassung vor"))
            if ak:
                a("      Beispiele (roh -> kalibriert): " + " · ".join(f"{p_text(x)} -> {p_text(kal_zahl(x, ak['a'], ak['b']))}" for x in (0.02, 0.05, 0.10, 0.20, 0.30, 0.45)))
        else:
            a("      Keine Anpassung: zu wenige Ursprungstage oder Ereignisse mit abgelaufener Frist.")
        if u.get("n"):
            a(f"      Ursprünge vom {_tag_txt((u.get('von') or 0) // TAG)} bis {_tag_txt((u.get('bis') or 0) // TAG)} · Brier {_de(u.get('brier'), 4)} gegen Grundrate {_de(u.get('brier_grund'), 4)}")
            a("      Zuverlässigkeit (vorhergesagt · eingetreten, 90-%-Band):")
            for kl in u.get("zuverlaessigkeit") or []:
                a(f"        {_de(kl[0] * 100, 0):>3}–{_de(kl[1] * 100, 0):<3} %  {_tsd(kl[2]):>6} Ursprünge   vorhergesagt {_de(kl[3] * 100, 1):>5} %   "
                  f"eingetreten {_de(kl[4] * 100, 1):>5} %  ({_de(kl[5] * 100, 1)}–{_de(kl[6] * 100, 1)} %)")
        anz = (rb.get("anzeige") or {}).get(key)
        roh_ok = bool(((rb.get("urteil") or {}).get(key) or {}).get("besteht"))
        a("      Folge: " + ("Die Karte zeigt die nachkalibrierte Zahl; Stufen, Schwellen und Alarm gelten für sie." if anz == "kal" else
                             "Die nachkalibrierte Zahl ist die Grundlage; die Karte zeigt sie mit Aufschlag (nächster Abschnitt)." if anz == "auf" else
                             ("Die Karte bleibt bei der Rohzahl mit ihren Stufen und ihrem Alarm." if roh_ok else
                              "Die Zahl bleibt matt, ohne Stufe und ohne Alarm.")))
        if anz == "kal":
            for coin in COINS:
                s = (k.get("coins") or {}).get(coin) or {}
                if s.get("grundrate") is None:
                    continue
                q = s.get("q") or {}; al = s.get("alarme") or {}
                a(f"      {coin:<5} erhöht ab {p_text(q.get(_qk(PZ_ERHOEHT)))} · hoch ab {p_text(q.get(_qk(PZ_HOCH)))} (97,5.: {p_text(q.get(_qk(0.975)))}, 99.: "
                  f"{p_text(q.get(_qk(0.99)))}) · Eintritte in „hoch“ {_tsd(al.get('eintritte'))} ({_de(al.get('je_jahr'), 1)} je Jahr), danach kam das Ereignis "
                  f"{_tsd(al.get('treffer'))}-mal · von {_tsd(al.get('episoden'))} Ereignis-Episoden bei {_tsd(al.get('gedeckt'))} auf „hoch“")
    return z




# ================================================================================================ Aufschlag für belegte Zeichen (Regel A, Abschnitt 14.4)

def auf_o0(p, F, PI):
    """
    Regel A4: die Chance o₀ für „keins“, so dass das Mittel über die Zustände wieder p ergibt --
    Σ π_r · P(F_r · o₀) + (1 − Σ π_r) · P(o₀) = p mit P(o) = o ÷ (1 + o). p ist ein Feld; F und PI sind Listen je Zustand, jedes
    Element eine Zahl oder ein Feld wie p. Die linke Seite wächst mit o₀: Bisektion im Logit (60 Schritte).
    """
    p = np.asarray(p, dtype=float)
    F = [np.asarray(f, dtype=float) for f in F]; PI = [np.asarray(q, dtype=float) for q in PI]
    pi0 = 1.0 - (sum(PI) if PI else 0.0)
    lo = np.full(p.shape, -30.0); hi = np.full(p.shape, 30.0)
    for _ in range(60):
        mid = (lo + hi) / 2.0; o = np.exp(mid)
        m = pi0 * o / (1.0 + o)
        for f, q in zip(F, PI):
            m = m + q * (f * o) / (1.0 + f * o)
        hoch = m > p
        hi = np.where(hoch, mid, hi); lo = np.where(hoch, lo, mid)
    return np.exp((lo + hi) / 2.0)


def auf_zahl(p_kal, k, F, PI):
    """
    Regel A4 für eine Zahl: k = 0 „keins“, k ≥ 1 die k-te belegte Regel steht an; alles andere heißt „unbekannt“ -- dann bleibt
    die nachkalibrierte Zahl. F und PI: je belegter Regel Faktor (None zählt als 1) und Anteil der Tage. Ergebnis auf 0,5 % … 99,5 %.
    """
    v = _zahl(p_kal)
    if v is None:
        return None
    if not isinstance(k, (int, np.integer)) or isinstance(k, bool) or k < 0 or k > len(F):
        return v
    Fz = [1.0 if _zahl(f) is None else float(f) for f in F]; Pz = [float(_zahl(q) or 0.0) for q in PI]
    v = min(max(v, KAL_P[0]), KAL_P[1])
    o = float(auf_o0(np.array([v]), Fz, Pz)[0]) * (Fz[k - 1] if k >= 1 else 1.0)
    return min(max(o / (1.0 + o), KAL_P[0]), KAL_P[1])


def auf_reihe(tau, ci, p_kal, D: dict) -> dict:
    """
    Regel A5: die Zahl mit Aufschlag an jedem Ursprung. D kommt aus hl_radar_regeln.auf_daten. Für einen Ursprung um 00:00 UTC des
    Tages T gilt der Zustand des Vortags (T − 1) und gelten Faktoren und Anteile des Monats von T. Coins ohne Tagesreihe, ein
    unbekannter Zustand und Monate ohne Faktor lassen die nachkalibrierte Zahl, wie sie ist.
    -> {"p": Feld, "z": Zustand je Ursprung (−2 Coin ohne Aufschlag, −1 unbekannt, 0 keins, k die k-te Regel), "pi": angewandter Anteil je
    Regel und Ursprung (NaN, wo nichts angewandt wurde; 23.125, beschreibend), "auf": wo der Aufschlag angewandt wurde}
    """
    tau = np.asarray(tau, dtype=np.int64); ci = np.asarray(ci); pk = np.asarray(p_kal, dtype=float)
    out = pk.copy(); zst = np.full(len(tau), -2, dtype=np.int16)
    regeln = list((D or {}).get("regeln") or []); nR = len(regeln)
    pi_all = np.full((nR, len(tau)), np.nan); auf_ja = np.zeros(len(tau), dtype=bool)
    if not nR or not len(tau):
        return {"p": out, "z": zst, "pi": pi_all, "auf": auf_ja}
    tage = tau // TAG
    erste = {int(t): monatserster(int(t)) for t in np.unique(tage)}
    mon = np.array([erste[int(t)] for t in tage], dtype=np.int64)
    for coin, dc in ((D or {}).get("coins") or {}).items():
        idx = np.nonzero(ci == coin)[0]
        if not len(idx):
            continue
        zz = np.asarray(dc["zustand"]); d = tage[idx] - 1 - int(dc["tag0"])
        z = np.where((d >= 0) & (d < len(zz)), zz[np.clip(d, 0, max(0, len(zz) - 1))] if len(zz) else -1, -1).astype(np.int16)
        zst[idx] = z
        F = np.ones((nR, len(idx))); PI = np.zeros((nR, len(idx))); hat = np.zeros(len(idx), dtype=bool)
        for M in np.unique(mon[idx]):
            fm = ((D or {}).get("monate") or {}).get(int(M))
            if not fm:
                continue
            sel = mon[idx] == M
            for k, rk in enumerate(regeln):
                f = _zahl((fm.get("f") or {}).get(rk))
                if f is not None:
                    F[k, sel] = f; hat[sel] = True
                PI[k, sel] = float(_zahl(((fm.get("anteil") or {}).get(coin) or {}).get(rk)) or 0.0)
        ok = np.isfinite(pk[idx]) & (z >= 0) & hat
        if ok.any():
            pc = np.clip(pk[idx][ok], KAL_P[0], KAL_P[1]); zk = z[ok]
            o = auf_o0(pc, [F[k][ok] for k in range(nR)], [PI[k][ok] for k in range(nR)])
            for k in range(nR):
                o = np.where(zk == k + 1, o * F[k][ok], o)
            neu = out[idx]; neu[ok] = np.clip(o / (1.0 + o), KAL_P[0], KAL_P[1]); out[idx] = neu
            sel_ok = idx[ok]; auf_ja[sel_ok] = True
            for k in range(nR):
                pi_all[k, sel_ok] = PI[k][ok]
    return {"p": out, "z": zst, "pi": pi_all, "auf": auf_ja}


def auf_aufteilung(S: dict, ci, p_kal, ja, regeln) -> dict:
    """
    23.125, beschreibend (Konzept 15.1): je Coin mit Aufschlag und Zustand die Ursprünge, ihr Anteil an den Ursprüngen des Coins gegen den
    angewandten Anteil (Mittel über diese Ursprünge; „keins“ = 1 − Summe der Regeln) und das Mittel der Zahl ohne und mit Aufschlag --
    daran sieht man, warum das Niveau mit Aufschlag vom Niveau ohne abweicht. Nur Ursprünge, an denen der Aufschlag angewandt wurde.
    -> {coin: {"n": …, "zustaende": {"keins"|regel: {"n", "anteil", "angewandt", "p_ohne", "p_mit"}}}}
    """
    ci = np.asarray(ci); pk = np.asarray(p_kal, dtype=float); ja = np.asarray(ja, dtype=float); pa = np.asarray(S["p"], dtype=float)
    z = np.asarray(S["z"]); pi = np.asarray(S["pi"], dtype=float); auf = np.asarray(S["auf"], dtype=bool)
    out = {}
    for coin in sorted(set(ci[auf].tolist())):
        m = auf & (ci == coin) & np.isfinite(pk) & np.isfinite(ja)
        n = int(m.sum())
        if not n:
            continue
        summe = np.nansum(pi[:, m], axis=0) if len(regeln) else np.zeros(n)
        zst = {}
        for k, name in [(0, "keins")] + [(i + 1, rk) for i, rk in enumerate(regeln)]:
            mk = m & (z == k)
            nk = int(mk.sum())
            ang = float(np.mean(1.0 - summe)) if k == 0 else float(np.nanmean(pi[k - 1, m]))
            zst[name] = {"n": nk, "anteil": nk / n, "angewandt": ang,
                         "p_ohne": (float(np.mean(pk[mk])) if nk else None), "p_mit": (float(np.mean(pa[mk])) if nk else None)}
        out[coin] = {"n": n, "zustaende": zst, "p_ohne": float(np.mean(pk[m])), "p_mit": float(np.mean(pa[m]))}
    return out


def auf_besser(tau, p_ohne, p_mit, ja, seed: int = 23) -> dict:
    """Regel A5 (b): Trifft die Zahl mit Aufschlag auf denselben Ursprüngen besser als ohne? Mittlerer Brier-Unterschied je Tag,
    einseitig gegen 0 mit demselben Block-Bootstrap wie der Skill (Blöcke von G_BLOCK Tagen, G_BOOT Ziehungen)."""
    import hl_ausblick as AU
    tau = np.asarray(tau, dtype=np.int64); a = np.asarray(p_ohne, dtype=float); b = np.asarray(p_mit, dtype=float); y = np.asarray(ja, dtype=float)
    ok = np.isfinite(a) & np.isfinite(b) & np.isfinite(y)
    out = {"n": int(ok.sum()), "geaendert": 0, "brier_ohne": None, "brier_mit": None, "diff": None, "p": None}
    if not ok.any():
        return out
    t, a, b, y = tau[ok], a[ok], b[ok], y[ok]
    d = (a - y) ** 2 - (b - y) ** 2
    _tage, inv = np.unique(t // TAG, return_inverse=True)
    f = np.bincount(inv, weights=d) / np.maximum(np.bincount(inv), 1)
    bt = AU.boot_p(f, G_BLOCK, G_BOOT, seed)
    out.update({"geaendert": int(np.sum(a != b)), "brier_ohne": float(np.mean((a - y) ** 2)), "brier_mit": float(np.mean((b - y) ** 2)),
                "diff": float(np.mean(d)), "p": bt.get("p")})
    return out


def auf_besser_ok(b: dict | None) -> bool:
    d = _zahl((b or {}).get("diff")); p = _zahl((b or {}).get("p"))
    return d is not None and d > 0 and p is not None and p < G_ALPHA


def auf_auswerten(out: dict, key: str, R: dict, tau, ci, p_kal, ja, g, bis_tag, D: dict | None) -> None:
    """
    Regel A für die 48-Stunden-Zahl: Reihe mit Aufschlag (A5), Urteil G2a mit denselben vier Kriterien, Vergleich mit der
    nachkalibrierten Zahl, Schwellen und Alarme je Coin auf der Zahl mit Aufschlag, Entscheidung der Anzeige (A6): „auf“ nur, wenn
    G2a besteht, die Zahl besser trifft und für den laufenden Monat ein Faktor vorliegt. Grundlage ist die nachkalibrierte Zahl (A1).
    """
    A = {"regeln": list((D or {}).get("regeln") or []), "besteht": False, "grund": None}
    out.setdefault("auf", {})[key] = A
    if (out.get("anzeige") or {}).get(key) != "kal":
        A["grund"] = "Die nachkalibrierte Zahl besteht nicht -- ohne sie gibt es keinen Aufschlag (Regel A1)."
        return
    if not D or not A["regeln"] or not D.get("coins"):
        A["grund"] = str((D or {}).get("grund") or "Für diese Zahl ist kein Zeichen belegt, oder die Tagesreihen der Regel-Prüfung fehlen.")
        return
    tau = np.asarray(tau, dtype=np.int64); ci = np.asarray(ci); pk = np.asarray(p_kal, dtype=float); ja = np.asarray(ja, dtype=float)
    S = auf_reihe(tau, ci, pk, D)
    u = g_urteil(key + "a", tau, ci, S["p"], ja, g, seed=22)
    b = auf_besser(tau, pk, S["p"], ja, seed=23)
    bt = int(bis_tag) if bis_tag is not None else int(np.max(tau) // TAG)
    fm = (D.get("monate") or {}).get(int(monatserster(bt)))
    akt = ({"monat": int(fm["monat"]), "f": dict(fm.get("f") or {}), "anteil": dict(fm.get("anteil") or {}), "n": dict(fm.get("n") or {}),
            "tage": fm.get("tage")} if fm else None)
    hat_f = bool(akt and any(_zahl(v) is not None for v in akt["f"].values()))
    coins = {}
    for coin in R:
        m = ci == coin
        if not m.any():
            continue
        pa = S["p"][m]; jk = ja[m]; tk = tau[m]
        okc = np.isfinite(pa) & np.isfinite(jk)
        sw = schwellen_bauen(pa, jk)
        alarme_fuer(tk[okc], pa[okc], jk[okc], sw)
        coins[coin] = sw
    gilt = np.isfinite(pk) & np.isfinite(ja)
    zaehl = {"keins": int(np.sum(gilt & (S["z"] == 0))), "unbekannt": int(np.sum(gilt & (S["z"] == -1)))}
    monate = {}
    for k, rk in enumerate(A["regeln"]):
        zaehl[rk] = int(np.sum(gilt & (S["z"] == k + 1)))
        fs = [float(v["f"][rk]) for v in (D.get("monate") or {}).values() if _zahl((v.get("f") or {}).get(rk)) is not None]
        monate[rk] = {"n": len(fs), "min": (min(fs) if fs else None), "max": (max(fs) if fs else None)}
    A.update({"urteil": u, "besser": b, "aktuell": akt, "coins": coins, "zaehlung": zaehl, "monate": monate,
              "coins_auf": [c for c in D.get("coins") or {}], "fehlt": list(D.get("fehlt") or [])[:5],
              "aufteilung": auf_aufteilung(S, ci, pk, ja, A["regeln"])})
    A["besteht"] = bool(u.get("besteht")) and auf_besser_ok(b) and hat_f
    if A["besteht"]:
        out.setdefault("anzeige", {})[key] = "auf"
    elif not u.get("besteht"):
        A["grund"] = "G2a besteht nicht: " + str(u.get("grund") or "ohne Angabe") + "."
    elif not auf_besser_ok(b):
        A["grund"] = (f"Die Zahl mit Aufschlag trifft nicht belegbar besser als ohne (Brier {_de(b.get('brier_mit'), 4)} gegen "
                      f"{_de(b.get('brier_ohne'), 4)}, {p_wert_text(b.get('p'))}; verlangt ist p unter {_de(G_ALPHA, 2)}).")
    else:
        A["grund"] = "Für den laufenden Monat liegt kein Faktor vor."


def auf_fuer(rb: dict | None, coin: str, key: str) -> dict | None:
    """Regel A6 für die Anzeige: Faktoren und Anteile des laufenden Monats für diesen Coin, wenn der Aufschlag im Rückblick besteht
    und der Coin zu denen mit Aufschlag gehört; sonst None."""
    A = ((rb or {}).get("auf") or {}).get(key) or {}
    if ((rb or {}).get("anzeige") or {}).get(key) != "auf" or not A.get("besteht"):
        return None
    akt = A.get("aktuell") or {}; regeln = list(A.get("regeln") or [])
    if not regeln or coin not in (akt.get("anteil") or {}) or not (A.get("urteil") or {}).get("besteht"):
        return None
    return {"regeln": regeln, "F": [(akt.get("f") or {}).get(rk) for rk in regeln], "PI": [(akt["anteil"][coin] or {}).get(rk) or 0.0 for rk in regeln],
            "urteil": A["urteil"], "besser": A.get("besser"), "r": (A.get("coins") or {}).get(coin) or {}, "monat": akt.get("monat")}


def zeichen_lage(zeichen, coin: str, jetzt: int, regeln) -> dict:
    """
    Regel A7: der Zustand der belegten Zeichen für diesen Coin aus dem abgelegten Stand (rd_meta „zeichen“). -> {"k", "regel",
    "tag", "grund"}; k = −1 (unbekannt), wenn kein Stand da ist, er zu anderen Regeln gehört oder älter als zwei Tage ist.
    """
    z = zeichen if isinstance(zeichen, dict) else {}
    c = (z.get("coins") or {}).get(coin)
    if not isinstance(c, dict) or list(z.get("regeln") or []) != list(regeln or []) or c.get("tag") is None:
        return {"k": -1, "regel": None, "tag": None, "grund": "Der Stand der Zeichen liegt noch nicht vor (der Takt holt ihn einmal am Tag)."}
    tag = int(c["tag"]); k = c.get("k")
    if int(jetzt) // TAG - tag > AUF_ALT_TAGE:
        return {"k": -1, "regel": None, "tag": tag, "grund": f"Der Stand der Zeichen ist älter als zwei Tage (Tag {_tag_txt(tag)})."}
    if not isinstance(k, int) or isinstance(k, bool) or k < 0 or k > len(list(regeln)):
        return {"k": -1, "regel": None, "tag": tag, "grund": f"Am {_tag_txt(tag)} war ein belegtes Zeichen nicht bestimmbar."}
    return {"k": int(k), "regel": (list(regeln)[k - 1] if k >= 1 else None), "tag": tag, "grund": None}


def regel_name(rk) -> str:
    return (str(rk).upper() + " " + REGELN_NAMEN[rk]) if rk in REGELN_NAMEN else str(rk).upper()


def auf_urteil_satz(A: dict | None, rb: dict | None) -> str:
    """Ein Satz zum Rückblick der Zahl mit Aufschlag (G2a)."""
    u = (A or {}).get("urteil"); b = (A or {}).get("besser") or {}
    if not u:
        return "Für die Zahl mit Aufschlag (G2a) liegt kein Urteil vor" + (": " + str(A.get("grund")) if (A or {}).get("grund") else ".")
    kk = (f"Rückblick G2a (mit Aufschlag) vom {_dt((rb or {}).get('stand'))}: {_tsd(u.get('n'))} Ursprünge an {_tsd(u.get('n_tage'))} Tagen, "
          f"{_tsd(u.get('n_ereignisse'))} Ereignisse, Skill {_de((_zahl(u.get('skill')) or 0) * 100, 1, True)} % ({p_wert_text(u.get('p'))}), "
          f"Steigung {_de(u.get('steigung'), 2)}, Niveau {_de(u.get('niveau'), 2)}; gegen die Zahl ohne Aufschlag: Brier "
          f"{_de(b.get('brier_mit'), 4)} gegen {_de(b.get('brier_ohne'), 4)} ({p_wert_text(b.get('p'))})")
    if (A or {}).get("besteht"):
        return kk + " — besteht."
    return kk + " — nicht bestätigt: " + str((A or {}).get("grund") or "ohne Angabe")


AUF_VERMERK = ("Aufschlag (Regel A): Steht ein belegtes Warnzeichen an, liegt die 48-Stunden-Zahl höher -- um einen Faktor auf die Chance "
               "(höchstens 3), geschätzt je Monat neu nur aus Tagen, deren Frist abgelaufen war. An Tagen ohne Zeichen liegt sie etwas "
               "tiefer, damit sie im Mittel stimmt. Gilt nur für BTC und ETH. Die Zahl mit Aufschlag hat dieselbe Prüfung bestanden und "
               "traf im Rückblick besser als ohne; es war die dritte Prüfung auf denselben Daten.")


def zeichen_text(lage: dict | None, regeln, in_zahl: bool, grund_nicht: str | None = None) -> str | None:
    """Der Satz der Karte und von Debug 160 zum Stand der belegten Zeichen eines Coins (None ohne belegte Zeichen)."""
    regeln = list(regeln or [])
    if not regeln or not isinstance(lage, dict):
        return None
    namen = ", ".join(regel_name(rk) for rk in regeln)
    if lage.get("k", -1) < 0:
        return f"Belegte Zeichen ({namen}): kein Stand. {lage.get('grund') or ''}".rstrip()
    kopf = f"Belegte Zeichen ({namen}), Stand Tagesschluss {_tag_txt(lage.get('tag'))}: "
    if lage["k"] == 0:
        return kopf + "keines steht an." + (" Die 48-Stunden-Zahl liegt deshalb etwas unter der Zahl ohne Aufschlag." if in_zahl else "")
    return (kopf + f"{regel_name(lage.get('regel'))} steht an. "
            + ("Das steckt in der 48-Stunden-Zahl (Aufschlag nach Regel A)." if in_zahl else
               "Die 48-Stunden-Zahl enthält es nicht" + (f" ({grund_nicht})." if grund_nicht else ".")))


def zeichen_anhaengen(S: dict, zeichen, jetzt: int, rb: dict | None) -> dict:
    """Stand der belegten Zeichen an den Stand eines Coins hängen (nur für die Coins des Urteils und nur mit belegten Regeln)."""
    kurz = S.get("regeln") or {}
    regeln = [rk for rk in REGELN_NAMEN if rk in set((kurz.get("belegt") or {}).get(AUF_KEY) or [])]
    S["zeichen"] = None
    if not regeln or S.get("coin") not in (kurz.get("coins") or []):
        return S
    lage = zeichen_lage(zeichen, S["coin"], jetzt, regeln)
    e = (S.get("ereignis") or {}).get(AUF_KEY) or {}
    in_zahl = bool(e.get("auf"))
    A = ((rb or {}).get("auf") or {}).get(AUF_KEY) or {}
    grund = None
    if not in_zahl:
        grund = ("der Aufschlag hat den Rückblick nicht bestanden" if A.get("urteil") else "der Aufschlag ist im Rückblick noch nicht geprüft")
    S["zeichen"] = {"regeln": regeln, "k": lage["k"], "regel": lage.get("regel"), "tag": lage.get("tag"), "in_zahl": in_zahl,
                    "text": zeichen_text(lage, regeln, in_zahl, grund)}
    return S


def zeichen_stand_satz(z) -> str | None:
    """Debug 160: wann der Takt den Stand der belegten Zeichen zuletzt geholt hat, für welche Regeln, und ob der letzte Versuch scheiterte."""
    if not isinstance(z, dict) or not (z.get("ts") or z.get("fehler")):
        return None
    teile = []
    for coin, c in (z.get("coins") or {}).items():
        if isinstance(c, dict) and c.get("tag") is not None:
            k = c.get("k")
            teile.append(f"{coin} {_tag_txt(c['tag'])}: " + ("unbekannt" if not isinstance(k, int) or k < 0 else
                                                             ("keines" if k == 0 else regel_name(c.get("regel")))))
    s = ("Belegte Zeichen für den Aufschlag (Regel A): Stand geholt " + (_dt(z.get("ts")) if z.get("ts") else "noch nie")
         + (" -- " + " · ".join(teile) if teile else ""))
    if z.get("fehler"):
        s += f" · letzter Versuch {_dt(z.get('versuch'))} gescheitert: {z['fehler']}"
    return s + "."


def zeichen_pflegen(db: str, con, jetzt: int, holen=None) -> bool:
    """
    Regel A7 im Takt: einmal am Tag den Zustand der belegten Zeichen holen (hl_radar_regeln.auf_stand) und in rd_meta „zeichen“
    ablegen. Nichts zu tun ohne abgelegtes Urteil mit belegten Regeln für die 48-Stunden-Zahl, bei frischem Stand (alle Coins mit dem
    Tagesschluss von gestern) und binnen ZEICHEN_WIEDER_S nach dem letzten Versuch. Ein Fehler bleibt im Stand stehen. -> True,
    wenn geholt wurde.
    """
    kurz = regeln_kurz(meta(con, "regeln"))
    belegt = [rk for rk in REGELN_NAMEN if rk in set(((kurz or {}).get("belegt") or {}).get(AUF_KEY) or [])]
    if not belegt:
        return False
    alt = meta(con, "zeichen")
    alt = alt if isinstance(alt, dict) else {}
    heute = int(jetzt) // TAG
    coins = alt.get("coins") if isinstance(alt.get("coins"), dict) else {}
    frisch = (list(alt.get("regeln") or []) == belegt and bool(coins)
              and all(isinstance(c, dict) and c.get("tag") is not None and int(c["tag"]) >= heute - 1 for c in coins.values()))
    if frisch or int(jetzt) - int(alt.get("versuch") or 0) < ZEICHEN_WIEDER_S:
        return False
    try:
        if holen is None:
            import hl_radar_regeln as RG
            holen = RG.auf_stand
        st = holen(db, belegt) or {}
        neu = {"ts": int(jetzt), "versuch": int(jetzt), "regeln": list(st.get("regeln") or []), "coins": dict(st.get("coins") or {})}
    except Exception as e:  # noqa: BLE001 -- der Takt läuft weiter; der alte Stand bleibt, bis er zu alt ist
        neu = dict(alt); neu["versuch"] = int(jetzt); neu["fehler"] = f"{type(e).__name__}: {e}"[:160]
    meta_setzen(con, "zeichen", neu)
    return True


def auf_zeilen(rb: dict) -> list:
    """Abschnitt „Aufschlag“ von Debug 161."""
    z = []; a = z.append
    A = ((rb or {}).get("auf") or {}).get(AUF_KEY)
    if not isinstance(A, dict):
        return z
    a("")
    a("== Aufschlag für belegte Zeichen (Regel A, KONZEPT_Risikoradar.md 14.4; Entscheidung des Nutzers vom 24.11.2026) -- dritte Prüfung "
      "der 48-Stunden-Zahl auf denselben Daten")
    a("   Nur 48 Stunden, nur BTC und ETH. Steht ein belegtes Zeichen an (die erste Regel in der Reihenfolge R1 … R7), wird die Chance mit "
      f"einem Faktor malgenommen (1 bis {_de(AUF_DECKEL, 0)}; Chancenverhältnis nach Mantel-Haenszel über Coin und Zehntel der Schwankung, je "
      "Monat neu aus Tagen mit abgelaufener Frist); ohne Zeichen liegt die Zahl etwas tiefer, so dass sie im Mittel gleich bleibt. Der "
      "Aufschlag gilt nur, wenn die Zahl damit dieselben vier Kriterien erfüllt und besser trifft als ohne. Kein weiterer Versuch.")
    u = A.get("urteil")
    if not u:
        a("   Kein Urteil: " + str(A.get("grund") or "ohne Angabe"))
        return z
    a("")
    a("   G2a · 48 Stunden: " + auf_urteil_satz(A, rb))
    b = A.get("besser") or {}
    a(f"      Vergleich auf {_tsd(b.get('n'))} Ursprüngen ({_tsd(b.get('geaendert'))} davon mit geänderter Zahl): Brier mit Aufschlag "
      f"{_de(b.get('brier_mit'), 5)}, ohne {_de(b.get('brier_ohne'), 5)}, Unterschied {_de((_zahl(b.get('diff')) or 0) * 1e4, 2, True)} · 10⁻⁴ "
      f"({p_wert_text(b.get('p'))})")
    zl = A.get("zaehlung") or {}
    a("      Ursprünge von " + " und ".join(A.get("coins_auf") or []) + " nach Zustand des Vortags: "
      + " · ".join([f"{regel_name(rk)} {_tsd(zl.get(rk))}" for rk in A.get("regeln") or []]
                   + [f"keins {_tsd(zl.get('keins'))}", f"unbekannt {_tsd(zl.get('unbekannt'))}"]))
    akt = A.get("aktuell")
    for rk in A.get("regeln") or []:
        mo = (A.get("monate") or {}).get(rk) or {}; n = ((akt or {}).get("n") or {}).get(rk) or {}
        f = _zahl(((akt or {}).get("f") or {}).get(rk))
        a(f"      {regel_name(rk)}: Faktor in {_tsd(mo.get('n'))} Monaten" + (f" zwischen {_de(mo.get('min'), 2)} und {_de(mo.get('max'), 2)}" if mo.get("n") else "")
          + (f" · laufender Monat ({_tag_txt(akt['monat'])}): " + (f"Faktor {_de(f, 2)}" if f is not None else "kein Faktor")
             + f" (Chancenverhältnis {_de(_zahl(n.get('or')), 2)} aus {_tsd(n.get('tage'))} Tagen in {_tsd(n.get('episoden'))} Episoden gegen "
               f"{_tsd(n.get('ohne'))} Tage ohne Zeichen)" if akt else " · für den laufenden Monat liegen keine Faktoren vor"))
    if akt:
        for coin in A.get("coins_auf") or []:
            an = (akt.get("anteil") or {}).get(coin)
            if not an:
                continue
            Fs = [(akt.get("f") or {}).get(rk) for rk in A["regeln"]]; Ps = [an.get(rk) or 0.0 for rk in A["regeln"]]
            a(f"      {coin}: Anteil der Tage " + " · ".join(f"{regel_name(rk)} {_de((an.get(rk) or 0) * 100, 1)} %" for rk in A["regeln"])
              + " · Beispiele (ohne Aufschlag -> ohne Zeichen / " + " / ".join(regel_name(rk).split(" ")[0] for rk in A["regeln"]) + "): "
              + " · ".join(f"{p_text(x)} -> " + " / ".join(p_text(auf_zahl(x, k, Fs, Ps)) for k in range(len(A["regeln"]) + 1)) for x in (0.05, 0.10, 0.20)))
    for zeile in aufteilung_zeilen(A):
        a(zeile)
    if u.get("n"):
        a(f"      Ursprünge vom {_tag_txt((u.get('von') or 0) // TAG)} bis {_tag_txt((u.get('bis') or 0) // TAG)} · Brier {_de(u.get('brier'), 4)} gegen Grundrate {_de(u.get('brier_grund'), 4)}")
        a("      Zuverlässigkeit (vorhergesagt · eingetreten, 90-%-Band):")
        for kl in u.get("zuverlaessigkeit") or []:
            a(f"        {_de(kl[0] * 100, 0):>3}–{_de(kl[1] * 100, 0):<3} %  {_tsd(kl[2]):>6} Ursprünge   vorhergesagt {_de(kl[3] * 100, 1):>5} %   "
              f"eingetreten {_de(kl[4] * 100, 1):>5} %  ({_de(kl[5] * 100, 1)}–{_de(kl[6] * 100, 1)} %)")
    anz = (rb.get("anzeige") or {}).get(AUF_KEY)
    a("      Folge: " + ("Die Karte zeigt die Zahl mit Aufschlag; Stufen, Schwellen und Alarm gelten für sie." if anz == "auf" else
                         "Die Karte bleibt bei der nachkalibrierten Zahl ohne Aufschlag. Ein anstehendes belegtes Zeichen steht als Hinweis da."))
    if anz == "auf":
        for coin in COINS:
            s = (A.get("coins") or {}).get(coin) or {}
            if s.get("grundrate") is None:
                continue
            q = s.get("q") or {}; al = s.get("alarme") or {}
            a(f"      {coin:<5} erhöht ab {p_text(q.get(_qk(PZ_ERHOEHT)))} · hoch ab {p_text(q.get(_qk(PZ_HOCH)))} (97,5.: {p_text(q.get(_qk(0.975)))}, 99.: "
              f"{p_text(q.get(_qk(0.99)))}) · Eintritte in „hoch“ {_tsd(al.get('eintritte'))} ({_de(al.get('je_jahr'), 1)} je Jahr), danach kam das Ereignis "
              f"{_tsd(al.get('treffer'))}-mal · von {_tsd(al.get('episoden'))} Ereignis-Episoden bei {_tsd(al.get('gedeckt'))} auf „hoch“")
    for zeile in auf_nachweis_zeilen():
        a(zeile)
    return z


def aufteilung_zeilen(A: dict) -> list:
    """23.125 (Konzept 15.1, beschreibend): die Aufteilung je Coin und Zustand für Debug 161 -- leer, solange sie nicht gerechnet ist."""
    auft = (A or {}).get("aufteilung") or {}
    if not auft:
        return []
    z = ["      Aufteilung (A4, beschreibend, seit 23.125): je Coin und Zustand die Ursprünge, ihr Anteil (in Klammern der angewandte Anteil im "
         "Mittel) und die Zahl ohne -> mit Aufschlag im Mittel"]
    for coin in list((A or {}).get("coins_auf") or []) or sorted(auft):
        t_ = auft.get(coin)
        if not t_:
            continue
        for name in ["keins"] + list(A.get("regeln") or []):
            q_ = (t_.get("zustaende") or {}).get(name) or {}
            z.append(f"        {coin:<4} {('keins' if name == 'keins' else regel_name(name)):<16} {_tsd(q_.get('n')):>6} Ursprünge · "
                     f"{_de((_zahl(q_.get('anteil')) or 0) * 100, 1)} % (angewandt {_de((_zahl(q_.get('angewandt')) or 0) * 100, 1)} %) · "
                     f"{p_text(q_.get('p_ohne'))} -> {p_text(q_.get('p_mit'))}")
        z.append(f"        {coin:<4} {'zusammen':<16} {_tsd(t_.get('n')):>6} Ursprünge · {p_text(t_.get('p_ohne'))} -> {p_text(t_.get('p_mit'))}")
    return z


def auf_nachweis_zeilen(M: dict | None = None) -> list:
    """Die Messung aus Abschnitt 14.6 in Worten (leer, solange keine Messung eingetragen ist). M: {"datum", "welten", je Fall „ohne“,
    „r1“, „beide“: {"basis": Reihen, in denen die Zahl ohne Aufschlag bestand, "auf": davon mit geltendem Aufschlag, "or": gemessenes
    Chancenverhältnis}}."""
    M = AUF_NACHWEIS if M is None else M
    if not M:
        return []

    def teil(name: str) -> str:
        t = M.get(name) or {}; nb = int(t.get("basis") or 0); na = int(t.get("auf") or 0)
        return f"in {_tsd(na)} von {_tsd(nb)}" + (" Reihen" if name == "ohne" else "") + (f" ({_de(100.0 * na / nb, 1)} %)" if nb else "")
    return [f"      Nachweis vor dem echten Lauf (gemessen am {M.get('datum')} auf erfundenen Reihen, je Fall {_tsd(M.get('welten'))}; gezählt sind "
            f"die Reihen, in denen die Zahl ohne Aufschlag bestand): Tragen die Zeichen nichts, galt der Aufschlag {teil('ohne')}. Trägt nur R1 "
            f"ein Chancenverhältnis von {_de((M.get('r1') or {}).get('or'), 1)}, {teil('r1')}. Tragen R1 und R7 je "
            f"{_de((M.get('beide') or {}).get('or'), 1)}, {teil('beide')}. „Nicht bestätigt“ heißt bei Zeichen dieser Stärke deshalb „nicht "
            "nachweisbar“ -- nicht „wirkt nicht“."]


# ================================================================================================ Rückblick des Grundrisikos (Abschnitt 3)

def grundrate_laufend(tau: np.ndarray, ja: np.ndarray, h_tage: int, mind: int = GRUNDRATE_MIN) -> np.ndarray:
    """g(τ) je Ursprung eines Coins (tau aufsteigend): Anteil der früheren Ursprünge mit eingetretenem Ereignis, deren Frist bei τ
    abgelaufen war (τ' + h Tage ≤ τ); unter `mind` solchen Ursprüngen NaN."""
    tau = np.asarray(tau, dtype=np.int64); ja = np.asarray(ja, dtype=float)
    cs = np.concatenate([[0.0], np.cumsum(ja)])
    k = np.searchsorted(tau, tau - int(h_tage) * TAG, side="right")
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(k >= mind, cs[k] / np.maximum(k, 1), np.nan)


def rueckblick_coin(A: dict, Fk: np.ndarray, B: dict, f_fn, je_tag: int, oos_ab: int) -> dict:
    """
    Beide Zahlen an jedem Tagesursprung (00:00 UTC) ab `oos_ab` nachrechnen -- mit den Szenarien des Ausblicks (hl_ausblick.szenarien:
    Tief = (ZL − m̄) · √F, ohne Drift), nur aus Fenstern der Bibliothek, die vor τ vollständig abgelaufen waren. f_fn(Tag) gibt den
    Faktor des Monats oder None. Jede Zahl ist wie in der Anzeige auf das Raster der abgelegten Verteilung begrenzt (0,5 % bis 99,5 %):
    Erreicht kein Szenario die Schwelle, zählt der Ursprung mit 0,5 % -- so wie die Karte dann „unter 0,5 %“ zeigt.
    -> {tau, p7, p2, ja7, ja2, ohne_bib, ohne_faktor}
    """
    import hl_ausblick as AU
    p_min, p_max = float(AU.LAUF_Q[0]), float(AU.LAUF_Q[-1])
    tau = np.asarray(A["tau"], dtype=np.int64); n = int(A["n"])
    with np.errstate(invalid="ignore", divide="ignore"):
        lc = np.log(np.asarray(A["C"], dtype=float)); ll = np.log(np.asarray(A["L"], dtype=float))
    order = np.argsort(B["ende"], kind="stable"); ende = np.asarray(B["ende"])[order]
    Z7 = np.asarray(B["Z"])[order][:, :7].astype(float); ZL7 = np.asarray(B["ZL"])[order][:, :7].astype(float)
    cz = np.cumsum(Z7, axis=0)
    rec = {k: [] for k in ("tau", "p7", "p2", "ja7", "ja2")}
    ohne_bib = ohne_faktor = 0
    x7, x2 = EREIGNIS["e7"]["x"], EREIGNIS["e2"]["x"]
    for j in range(n):
        t = int(tau[j])
        if t < oos_ab or t % TAG:
            continue
        if j + je_tag * 7 >= n:
            break
        k = int(np.searchsorted(ende, t - TAG, side="right"))
        if k < BIB_MIN or not np.all(np.isfinite(Fk[j, :7])) or not np.isfinite(lc[j]):
            ohne_bib += 1; continue
        f = f_fn(t // TAG)
        if f is None or EREIGNIS["e7"]["x"] * f >= 0.9:
            ohne_faktor += 1; continue
        lo = (ZL7[:k] - cz[k - 1] / k) * np.sqrt(Fk[j, :7])
        d7 = math.log(1 - x7 * f); d2 = math.log(1 - x2 * f)
        tief = ll[j + je_tag: j + je_tag * 7 + 1: je_tag] - lc[j]
        if not np.isfinite(tief).any():
            ohne_bib += 1; continue
        rec["tau"].append(t)
        rec["p7"].append(min(max(float(np.mean(lo.min(axis=1) <= d7)), p_min), p_max))
        rec["p2"].append(min(max(float(np.mean(lo[:, :2].min(axis=1) <= d2)), p_min), p_max))
        rec["ja7"].append(float(np.nanmin(tief) <= d7))
        rec["ja2"].append(float(np.nanmin(tief[:2]) <= d2) if np.isfinite(tief[:2]).any() else float("nan"))
    out = {k: np.array(v, dtype=(np.int64 if k == "tau" else float)) for k, v in rec.items()}
    out["ohne_bib"] = ohne_bib; out["ohne_faktor"] = ohne_faktor
    return out


def g_urteil(key: str, tau, coin_i, p, ja, g, seed: int = 0) -> dict:
    """Urteil G7 bzw. G2 über alle Coins: Brier-Skill gegen die laufende Grundrate, Steigung, Zuverlässigkeit, Block-Bootstrap."""
    import hl_ausblick as AU
    import hl_aktien as AK
    tau = np.asarray(tau, dtype=np.int64); p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float); g = np.asarray(g, dtype=float)
    ok = np.isfinite(p) & np.isfinite(g) & np.isfinite(ja)
    out = {"n": int(ok.sum()), "n_tage": 0, "n_ereignisse": 0, "brier": None, "brier_grund": None, "skill": None, "steigung": None, "p": None,
           "zuverlaessigkeit": [], "besteht": False, "grund": None, "von": None, "bis": None, "je_coin": {}, "niveau": None}
    if not ok.any():
        out["grund"] = "keine auswertbaren Ursprünge"; return out
    t, p_, y, g_ = tau[ok], p[ok], ja[ok], g[ok]
    tage, inv = np.unique(t // TAG, return_inverse=True)
    out["n_tage"] = int(len(tage)); out["n_ereignisse"] = int(y.sum()); out["von"] = int(t.min()); out["bis"] = int(t.max())
    bp = float(np.mean((p_ - y) ** 2)); bg = float(np.mean((g_ - y) ** 2))
    out["brier"] = bp; out["brier_grund"] = bg; out["skill"] = (1 - bp / bg) if bg > 0 else None
    out["steigung"] = float(AU.logit_steigung(y, p_))
    out["niveau"] = float(p_.mean() / y.mean()) if y.mean() > 0 else None
    d = (g_ - y) ** 2 - (p_ - y) ** 2
    f = np.bincount(inv, weights=d) / np.maximum(np.bincount(inv), 1)
    bt = AU.boot_p(f, G_BLOCK, G_BOOT, seed)
    out["p"] = bt.get("p")
    for a, b in zip(ZUV_KLASSEN[:-1], ZUV_KLASSEN[1:]):
        m = (p_ >= a) & (p_ < b)
        if m.any():
            lo, hi = AK.wilson(int(y[m].sum()), int(m.sum()), 1.645)
            out["zuverlaessigkeit"].append([a, min(b, 1.0), int(m.sum()), float(p_[m].mean()), float(y[m].mean()), lo, hi])
    ci = np.asarray(coin_i)[ok]
    for c in np.unique(ci):
        m = ci == c
        out["je_coin"][str(c)] = {"n": int(m.sum()), "ereignisse": int(y[m].sum()), "p": float(p_[m].mean()), "quote": float(y[m].mean())}
    sk, st, pw, nv = out["skill"], out["steigung"], out["p"], out["niveau"]
    if out["n_tage"] < G_MIN_TAGE or out["n_ereignisse"] < G_MIN_EREIGNISSE:
        out["grund"] = (f"zu wenig Historie für ein Urteil ({out['n_tage']} Ursprungstage, {out['n_ereignisse']} Ereignisse; "
                        f"gebraucht werden {G_MIN_TAGE} und {G_MIN_EREIGNISSE})")
    elif sk is None or not sk > 0 or pw is None or not math.isfinite(pw) or not pw < G_ALPHA:
        out["grund"] = (f"die Zahl trifft nicht belegbar besser als die Grundrate (Skill {_de((sk or 0) * 100, 1, True)} %, "
                        f"{p_wert_text(pw)}; verlangt ist p unter {_de(G_ALPHA, 2)})")
    elif not math.isfinite(st) or not G_STEIGUNG[0] <= st <= G_STEIGUNG[1]:
        out["grund"] = (f"Steigung {_de(st, 2)} außerhalb von {_de(G_STEIGUNG[0], 1)} bis {_de(G_STEIGUNG[1], 1)} "
                        + ("(die Zahl schlägt zu stark aus)" if math.isfinite(st) and st < G_STEIGUNG[0] else "(die Zahl schlägt zu schwach aus)"))
    elif nv is None or not G_NIVEAU[0] <= nv <= G_NIVEAU[1]:
        out["grund"] = (f"Niveau: die Zahl lag im Mittel beim {_de(nv, 2)}-Fachen der eingetretenen Quote "
                        f"(zulässig {_de(G_NIVEAU[0], 1)} bis {_de(G_NIVEAU[1], 2)})")
    else:
        out["besteht"] = True
    return out


def schwellen_bauen(p, ja) -> dict:
    """Grundrate und Perzentile der Rückblick-Werte eines Coins für ein Ereignis."""
    p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float)
    ok = np.isfinite(p) & np.isfinite(ja)
    if ok.sum() < GRUNDRATE_MIN:
        return {"n": int(ok.sum()), "grundrate": None, "q": {}, "niveau": None}
    gr = float(ja[ok].mean())
    return {"n": int(ok.sum()), "grundrate": gr, "q": {_qk(q): float(np.quantile(p[ok], q)) for q in PZ_ABLAGE},
            "niveau": (float(p[ok].mean()) / gr if gr > 0 else None)}


def alarm_tabelle(tau, p, ja, s_hoch) -> dict:
    """
    Beschreibend: die Regel aus Abschnitt 6 auf den Tageswerten des Rückblicks. Eintritte in „hoch“ (Beginn bei p ≥ Schwelle, Ende unter
    0,8 · Schwelle), Eintritte je Jahr, Anteil der Eintritte, nach denen das Ereignis in der Frist kam, und Anteil der Ereignis-Episoden
    (aufeinanderfolgende Ursprungstage mit Ereignis), in denen das Radar an mindestens einem Tag auf „hoch“ stand.
    """
    tau = np.asarray(tau, dtype=np.int64); p = np.asarray(p, dtype=float); ja = np.asarray(ja, dtype=float)
    s = _zahl(s_hoch)
    out = {"schwelle": s, "eintritte": 0, "je_jahr": None, "treffer": 0, "episoden": 0, "gedeckt": 0, "tage_hoch": 0, "n": int(len(tau))}
    if s is None or len(tau) < 2:
        return out
    hoch = False; zust = np.zeros(len(tau), dtype=bool); ein = []
    for i in range(len(tau)):
        if np.isfinite(p[i]):
            if not hoch and p[i] >= s:
                hoch = True; ein.append(i)
            elif hoch and p[i] < HYSTERESE * s:
                hoch = False
        zust[i] = hoch
    out["eintritte"] = len(ein); out["tage_hoch"] = int(zust.sum())
    jahre = (int(tau[-1]) - int(tau[0])) / (365.25 * TAG)
    out["je_jahr"] = len(ein) / jahre if jahre > 0 else None
    out["treffer"] = int(sum(1 for i in ein if ja[i] == 1))
    i = 0
    while i < len(tau):
        if ja[i] == 1:
            j = i
            while j + 1 < len(tau) and ja[j + 1] == 1 and tau[j + 1] - tau[j] <= TAG:
                j += 1
            out["episoden"] += 1; out["gedeckt"] += int(zust[i:j + 1].any())
            i = j + 1
        else:
            i += 1
    return out


def alarme_fuer(tk, pk, jk, sw: dict) -> dict:
    """Tabelle der Alarme eines Coins für die Vorgabe (95. Perzentil) und -- seit 23.124 -- für die anderen wählbaren Schwellen."""
    q = sw.get("q") or {}
    sw["alarme"] = alarm_tabelle(tk, pk, jk, q.get(_qk(PZ_HOCH)))
    sw["alarme_wahl"] = {_qk(w): alarm_tabelle(tk, pk, jk, q.get(_qk(w))) for w in PZ_WAHL if abs(w - PZ_HOCH) > 1e-9}
    return sw


def pz_wort(pz) -> str:
    v = _zahl(pz)
    return "95." if v is not None and abs(v - 0.95) < 1e-9 else ("97,5." if v is not None and abs(v - 0.975) < 1e-9 else "99.")


def pz_kurz(pz) -> str:
    """23.127 (U314): Anteil der riskantesten Tage, ab dem die Stufe „hoch“ gilt -- 5 %, 2,5 % oder 1 % (Wahl im Dashboard, wie pz_wort)."""
    v = _zahl(pz)
    return "5 %" if v is not None and abs(v - 0.95) < 1e-9 else ("2,5 %" if v is not None and abs(v - 0.975) < 1e-9 else "1 %")


def stufen_satz(pz) -> str:
    """23.127 (U314): die Stufen in einem Satz mit der eingestellten Schwelle „hoch“ (Beleg der Karte, Kopf von Debug 160)."""
    return (f"erhöht = riskanteste 20 % der Tage im Rückblick, hoch = riskanteste {pz_kurz(pz)} (eingestellt: {pz_wort(pz)} Perzentil, "
            f"im Dashboard wählbar 5 %, 2,5 % oder 1 %)")


def eingestellte_schwelle(db: str):
    """Die im Dashboard gewählte Schwelle „hoch“ (0,95 · 0,975 · 0,99) oder None."""
    try:
        con = lesen(pfad(db))
        try:
            return einstellung_lesen(con)["pz"]
        finally:
            if con is not None:
                con.close()
    except Exception:  # noqa: BLE001 -- ohne Einstellung steht nur die Vorgabe im Bericht
        return None


def wahl_zeilen(rb: dict, pz) -> list:
    """Debug 161: die Zählung der Alarme für die eingestellte Schwelle „hoch“, wenn sie von der Vorgabe (95. Perzentil) abweicht --
    für die große Zahl der Karte (LEIT) in der Fassung, die gilt (Rohzahl, nachkalibriert oder mit Aufschlag)."""
    pzv = _zahl(pz)
    if pzv is None or abs(pzv - PZ_HOCH) < 1e-9 or not isinstance(rb, dict):
        return []
    anz = (rb.get("anzeige") or {}).get(LEIT)
    if anz == "auf":
        quelle = ((rb.get("auf") or {}).get(LEIT) or {}).get("coins") or {}; fass = "mit Aufschlag"
    elif anz == "kal":
        quelle = ((rb.get("kal") or {}).get(LEIT) or {}).get("coins") or {}; fass = "nachkalibriert"
    else:
        quelle = {c: (v or {}).get(LEIT) or {} for c, v in (rb.get("coins") or {}).items()}; fass = "Rohzahl"
    z = []
    for coin in COINS:
        s = quelle.get(coin) or {}; al = (s.get("alarme_wahl") or {}).get(_qk(pzv))
        if not al or s.get("grundrate") is None:
            continue
        z.append(f"   {coin:<5} hoch ab {p_text((s.get('q') or {}).get(_qk(pzv)))} · Eintritte in „hoch“ {_tsd(al.get('eintritte'))} "
                 f"({_de(al.get('je_jahr'), 1)} je Jahr), danach kam das Ereignis {_tsd(al.get('treffer'))}-mal · von {_tsd(al.get('episoden'))} "
                 f"Ereignis-Episoden bei {_tsd(al.get('gedeckt'))} auf „hoch“")
    if not z:
        return []
    return ["", f"== Eingestellte Schwelle „hoch“: {pz_wort(pzv)} Perzentil -- {EREIGNIS[LEIT]['kurz']}, {fass} (beschreibend; die Tabellen oben "
                f"zählen für das {pz_wort(PZ_HOCH)} Perzentil)"] + z


def rueckblick_auswerten(R: dict, bis_tag: int | None = None, auf: dict | None = None) -> dict:
    """Aus den Ursprüngen je Coin ({coin: rueckblick_coin}) die beiden Urteile, Grundraten, Schwellen und die Tabelle der Alarme;
    seit 23.123 dazu die nachkalibrierte Fassung jeder Zahl (Regel K) mit eigenem Urteil. bis_tag: der Tag des Laufs (für die Anpassung
    des laufenden Monats); ohne Angabe der letzte Ursprungstag. auf: seit 23.124 die Zustände und Faktoren der belegten Zeichen
    (hl_radar_regeln.auf_daten) für den Aufschlag auf die 48-Stunden-Zahl (Regel A); ohne sie gibt es keinen."""
    out = {"urteil": {}, "coins": {}, "ohne": {}}
    for key, E in EREIGNIS.items():
        pk, jk = ("p7", "ja7") if key == "e7" else ("p2", "ja2")
        tau = []; ci = []; p = []; ja = []; g = []
        for coin, r in R.items():
            if not len(r["tau"]):
                continue
            ok = np.isfinite(r[jk])
            gl = np.full(len(r["tau"]), np.nan)
            gl[ok] = grundrate_laufend(r["tau"][ok], r[jk][ok], E["tage"])
            tau.append(r["tau"]); ci.append(np.full(len(r["tau"]), coin)); p.append(r[pk]); ja.append(r[jk]); g.append(gl)
            sw = schwellen_bauen(r[pk], r[jk])
            alarme_fuer(r["tau"][ok], r[pk][ok], r[jk][ok], sw)
            out["coins"].setdefault(coin, {})[key] = sw
            out["ohne"][coin] = {"bibliothek": int(r.get("ohne_bib") or 0), "faktor": int(r.get("ohne_faktor") or 0)}
        if tau:
            out["urteil"][key] = g_urteil(key, np.concatenate(tau), np.concatenate(ci), np.concatenate(p), np.concatenate(ja),
                                          np.concatenate(g), seed=7 if key == "e7" else 2)
            pkal = kal_auswerten(out, key, E, R, np.concatenate(tau), np.concatenate(ci), np.concatenate(p), np.concatenate(ja), np.concatenate(g), bis_tag)
            if key == AUF_KEY:
                auf_auswerten(out, key, R, np.concatenate(tau), np.concatenate(ci), pkal, np.concatenate(ja), np.concatenate(g), bis_tag, auf)
        else:
            out["urteil"][key] = {"n": 0, "n_tage": 0, "n_ereignisse": 0, "besteht": False, "grund": "keine Ursprünge (der Ausblick hat keine Historie geliefert)"}
    kal_abschluss(out)
    return out


def rueckblick_rechnen(db: str, log=print, jetzt: int | None = None, schreiben: bool = True) -> dict:
    """
    Der Lauf von Debug 161: Daten des Ausblicks laden, je Coin nachrechnen, auswerten, in radar.db ablegen (rd_meta „rueckblick“).
    Rechnet schon ein anderer Lauf (RbSperre), rechnet dieser nicht: -> {"laeuft": True}.
    """
    sperre = RbSperre(db) if schreiben else None
    if sperre is not None and not sperre.nehmen():
        return {"laeuft": True}
    try:
        return _rueckblick_rechnen(db, log, jetzt, schreiben)
    finally:
        if sperre is not None:
            sperre.lassen()


def rueckblick_holen(db: str, log=print, warten_s: float = RUECKBLICK_WARTEN_S, schlaf=time.sleep, uhr=time.time, rechnen=None) -> tuple:
    """
    Für Debug 161: den gespeicherten Rückblick dieser Fassung lesen; fehlt er, rechnen; rechnet schon ein anderer Lauf, auf ihn warten
    (höchstens warten_s). -> (Rückblick oder None, gerechnet: bool, gewartet: bool).
    """
    rechnen = rechnen or rueckblick_rechnen
    ende = uhr() + float(warten_s)
    gewartet = False
    while True:
        con = lesen(pfad(db))
        try:
            rb = meta(con, "rueckblick")
        finally:
            if con is not None:
                con.close()
        if isinstance(rb, dict) and rb.get("version") == VERSION_MODUL:
            return rb, False, gewartet
        if not gewartet:
            log("Der Rückblick fehlt oder stammt von einer anderen Fassung -- dieser Lauf rechnet ihn jetzt.")
        r = rechnen(db, log=log)
        if not r.get("laeuft"):
            return r, True, gewartet
        if not gewartet:
            log(f"Ein anderer Lauf (der Takt des Dashboards) rechnet ihn gerade -- dieser Lauf wartet bis zu {int(warten_s) // 60} Minuten.")
        if uhr() >= ende:
            return None, False, True
        gewartet = True
        schlaf(5)


def _rueckblick_rechnen(db: str, log, jetzt: int | None, schreiben: bool) -> dict:
    import hl_ausblick as AU
    t0 = time.time(); jetzt = int(jetzt or time.time())
    G = AU.lade(db, log=lambda *a: None)
    wahl = None
    ac = AU.lesen(AU.ausblick_pfad(db))
    if ac is not None:
        try:
            wahl = AU._json_meta(ac, "breite_wahl", None)
        finally:
            ac.close()
    V = {}
    for c in AU.COINS:
        if c in G["coins"]:
            v = AU.vorbereiten(c, G, wahl)
            if v is not None:
                V[c] = v
    K = kerzen_lesen(db, COINS)
    rend = {c: _renditen_je_tag(K[c]["tag"], K[c]["c"]) for c in K}
    R = {}; fehlt = list(G.get("fehlt") or [])
    if "BTC" not in rend:
        fehlt.append("hebel.db: keine Tagesschlüsse für BTC -- ohne sie gibt es keinen Faktor und keinen Rückblick")
    for coin in COINS:
        if coin not in V:
            fehlt.append(f"{coin}: keine Historie im Ausblick"); continue
        B, bart = AU.bibliothek_fuer(coin, V)
        if B is None or not len(B["ende"]):
            fehlt.append(f"{coin}: keine Bibliothek ({bart})"); continue
        fm: dict = {}
        def f_fn(tag, coin=coin, fm=fm):
            st = monatserster(tag)
            if st not in fm:
                fm[st] = faktor_rechnen(coin, rend.get(coin), rend.get("BTC"), st)["f"] if (coin == "BTC" or "BTC" in rend) else None
            return fm[st]
        R[coin] = rueckblick_coin(V[coin]["A"], V[coin]["Fk"], B, f_fn, AU.JE_TAG, AU.OOS_AB)
        log(f"  {coin}: {len(R[coin]['tau'])} Ursprünge, Bibliothek {bart}; ausgelassen {R[coin]['ohne_bib']} (Bibliothek oder Prognose), "
            f"{R[coin]['ohne_faktor']} (Faktor)")
    erg = rueckblick_auswerten(R, jetzt // TAG, auf_holen(db, jetzt))
    erg.update({"stand": jetzt, "version": VERSION_MODUL, "dauer": time.time() - t0, "fehlt": fehlt, "breite_wahl": wahl,
                "ausblick_version": getattr(AU, "VERSION_MODUL", None)})
    if schreiben:
        con = verbinden(pfad(db))
        try:
            meta_setzen(con, "rueckblick", erg)
        finally:
            con.close()
    return erg


def auf_holen(db: str, jetzt: int, laden=None) -> dict:
    """Für den Rückblick (Regel A5): Zustände und Faktoren der Zeichen, die im abgelegten Urteil für die 48-Stunden-Zahl belegt sind
    (hl_radar_regeln.auf_laden). Ohne Urteil, ohne belegtes Zeichen oder bei einem Fehler: {"grund": …} -- dann gibt es keinen Aufschlag."""
    try:
        con = lesen(pfad(db))
        try:
            kurz = regeln_kurz(meta(con, "regeln")) if con is not None else None
        finally:
            if con is not None:
                con.close()
        if not kurz:
            return {"grund": "Die Prüfung der Regeln hat noch kein Urteil abgelegt (Debug 163)."}
        belegt = [rk for rk in REGELN_NAMEN if rk in set((kurz.get("belegt") or {}).get(AUF_KEY) or [])]
        if not belegt:
            return {"grund": "Für die 48-Stunden-Zahl ist kein Zeichen belegt (Debug 163)."}
        if laden is None:
            import hl_radar_regeln as RG
            laden = RG.auf_laden
        return laden(db, belegt, int(jetzt) // TAG)
    except Exception as e:  # noqa: BLE001 -- der Rückblick der Zahlen steht auch ohne den Aufschlag
        return {"grund": f"Die Tagesreihen der Regel-Prüfung sind nicht lesbar ({type(e).__name__}: {e})."[:200]}


def rueckblick_text(rb: dict | None, pz: float | None = None) -> str:
    """Debug 161 als Text. pz: die eingestellte Schwelle „hoch“ -- weicht sie von der Vorgabe ab, steht die Zählung der Alarme auch für sie da."""
    z = []; a = z.append
    a("★ Risikoradar: Rückblick des Grundrisikos (U307, KONZEPT_Risikoradar.md 3) -- beide Zahlen ab 2022 an Tagesursprüngen nachgerechnet")
    if not isinstance(rb, dict):
        a("  Der Rückblick hat auf diesem Rechner noch nicht gerechnet. Der Takt startet ihn von selbst; dieser Lauf rechnet ihn sonst jetzt.")
        return "\n".join(z)
    a(f"  Modul {rb.get('version')} · gerechnet {_dt(rb.get('stand'))} in {_de(rb.get('dauer'), 0)} s · Regeln vorab fest: mindestens "
      f"{G_MIN_TAGE} Ursprungstage und {G_MIN_EREIGNISSE} Ereignisse, Skill > 0 mit p < {_de(G_ALPHA, 2)}, Steigung {_de(G_STEIGUNG[0], 1)} bis {_de(G_STEIGUNG[1], 1)}, "
      f"Niveau (Mittel der Zahl ÷ Quote) {_de(G_NIVEAU[0], 1)} bis {_de(G_NIVEAU[1], 2)}")
    for f in rb.get("fehlt") or []:
        a(f"  fehlt: {f}")
    for key, E in EREIGNIS.items():
        u = (rb.get("urteil") or {}).get(key) or {}
        name = "G7" if key == "e7" else "G2"
        a("")
        a(f"== {name} · Tief mindestens {x_text(E['x'])} · Faktor unter dem Kurs, binnen {E['name']} (BTC: Faktor 1)")
        a("   " + urteil_satz(key, u, rb))
        if u.get("n"):
            a(f"   Ursprünge vom {_tag_txt((u.get('von') or 0) // TAG)} bis {_tag_txt((u.get('bis') or 0) // TAG)} · Brier {_de(u.get('brier'), 4)} gegen Grundrate {_de(u.get('brier_grund'), 4)}")
            a("   Zuverlässigkeit (vorhergesagt · eingetreten, 90-%-Band):")
            for kl in u.get("zuverlaessigkeit") or []:
                a(f"     {_de(kl[0] * 100, 0):>3}–{_de(kl[1] * 100, 0):<3} %  {_tsd(kl[2]):>6} Ursprünge   vorhergesagt {_de(kl[3] * 100, 1):>5} %   "
                  f"eingetreten {_de(kl[4] * 100, 1):>5} %  ({_de(kl[5] * 100, 1)}–{_de(kl[6] * 100, 1)} %)")
            a("   Je Coin (Mittel der Zahl · Quote): " + " · ".join(
                f"{c} {_de(v['p'] * 100, 1)} % · {_de(v['quote'] * 100, 1)} % ({_tsd(v['ereignisse'])} von {_tsd(v['n'])})" for c, v in (u.get("je_coin") or {}).items()))
    a("")
    a("== Grundrate, Schwellen und Alarme im Rückblick je Coin (beschreibend)")
    for coin in COINS:
        c = (rb.get("coins") or {}).get(coin)
        if not c:
            a(f"   {coin}: kein Rückblick"); continue
        for key, E in EREIGNIS.items():
            s = c.get(key) or {}
            if s.get("grundrate") is None:
                a(f"   {coin} {E['kurz']}: zu wenige Ursprünge ({_tsd(s.get('n'))})"); continue
            q = s.get("q") or {}; al = s.get("alarme") or {}
            a(f"   {coin} {E['kurz']:<10} Grundrate {_de(s['grundrate'] * 100, 1):>5} % · erhöht ab {p_text(q.get(_qk(PZ_ERHOEHT)))} · hoch ab "
              f"{p_text(q.get(_qk(PZ_HOCH)))} (97,5.: {p_text(q.get(_qk(0.975)))}, 99.: {p_text(q.get(_qk(0.99)))}) · Eintritte in „hoch“ {_tsd(al.get('eintritte'))} "
              f"({_de(al.get('je_jahr'), 1)} je Jahr), danach kam das Ereignis {_tsd(al.get('treffer'))}-mal · von {_tsd(al.get('episoden'))} "
              f"Ereignis-Episoden stand das Radar bei {_tsd(al.get('gedeckt'))} auf „hoch“")
    z.extend(kal_zeilen(rb))
    z.extend(auf_zeilen(rb))
    z.extend(wahl_zeilen(rb, pz))
    a("")
    a("Lesart: „besteht“ heißt, die Zahl traf im Rückblick besser als die Grundrate und war richtig gestuft -- nicht, dass sie den nächsten")
    a("Rücksetzer ankündigt. Die Eintritte sind auf Tageswerten gezählt; live prüft das Radar alle 5 Minuten und kann öfter melden.")
    return "\n".join(_umbruch(z))


# ================================================================================================ Karte und Bericht

def meldungen_lesen(con, n: int = 5) -> list:
    if con is None:
        return []
    try:
        rows = con.execute("SELECT id, ts, coin, ereignis, art, p, titel, text, ansage, push, push_fehler FROM rd_alarm ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    except sqlite3.Error:
        return []
    wort = {PUSH_AUS: "kein Push", PUSH_OFFEN: "Push offen", PUSH_GESENDET: "Push gesendet", PUSH_AUFGEGEBEN: "Push nicht gesendet"}
    return [{"id": r[0], "ts": r[1], "coin": r[2], "ereignis": r[3], "art": r[4], "p": r[5], "titel": r[6], "text": r[7], "ansage": r[8],
             "push": wort.get(r[9], "—"), "push_fehler": r[10]} for r in rows]


def alle_stufen(con, coin_jetzt: str | None = None, S: dict | None = None) -> list:
    """Stufe der großen Zahl (LEIT, seit 23.124 die 48-Stunden-Zahl) je Coin aus der letzten Ablage (für die Zeile „alle Coins“); der
    gewählte Coin aus dem frischen Stand."""
    out = []
    for c in COINS:
        e = None
        if S is not None and c == coin_jetzt:
            e = {"p": S["ereignis"][LEIT].get("p"), "stufe": S["ereignis"][LEIT].get("stufe"), "ts": S.get("jetzt")}
        elif con is not None:
            try:
                r = con.execute("SELECT ts, json FROM rd_stand WHERE coin=? ORDER BY stunde DESC LIMIT 1", (c,)).fetchone()
                if r:
                    d = (json.loads(r[1]).get("e") or {}).get(LEIT) or {}
                    e = {"p": d.get("p"), "stufe": d.get("stufe"), "ts": r[0]}
            except (sqlite3.Error, ValueError, TypeError):
                e = None
        e = e or {"p": None, "stufe": "ohne", "ts": None}
        out.append({"coin": c, "p": e.get("p"), "p_text": p_text(e.get("p")) if e.get("p") is not None else "—", "stufe": e.get("stufe") or "ohne",
                    "stufe_wort": STUFEN_WORT.get(e.get("stufe") or "ohne", "ohne Stufe"), "ts": e.get("ts")})
    return out


def nutzlast(db: str, coin: str = "BTC", jetzt: int | None = None) -> dict:
    """Antwort für die Karte „Risikoradar“ (/cockpit/radar)."""
    t0 = time.time()
    jetzt = int(jetzt or time.time())
    S = stand(db, coin, jetzt)
    if not S.get("ok"):
        return S
    con = lesen(pfad(db))
    try:
        einst = einstellung_lesen(con)
        S["meldungen"] = meldungen_lesen(con)
        S["alle"] = alle_stufen(con, coin, S)
        takt = meta(con, "takt")
    finally:
        if con is not None:
            con.close()
    S = karte_bauen(S, einst, S.pop("meldungen"), S.pop("alle"), takt, bool(push_einstellung().get("thema")), jetzt)
    S["rechenzeit_ms"] = int((time.time() - t0) * 1000)
    return S


def karte_bauen(S: dict, einst: dict, meldungen: list, alle: list, takt: dict | None, push_ok: bool, jetzt: int) -> dict:
    """Die Antwort der Karte aus dem Stand und dem, was aus radar.db kommt -- ohne Zugriff auf Dateien."""
    S = dict(S)
    S["meldungen"] = meldungen; S["alle"] = alle
    S["einstellung"] = einst
    S["push_eingerichtet"] = bool(push_ok)
    S["takt"] = {"ts": (takt or {}).get("ts"), "laeuft": bool(takt and jetzt - int(takt.get("ts") or 0) <= 3 * TAKT_S)}
    S["pz_wahl"] = [{"pz": w, "text": ("95." if w == 0.95 else "97,5." if w == 0.975 else "99.") + " Perzentil",
                     "kurz": _de((1 - w) * 100, 1 if w == 0.975 else 0) + " %"} for w in PZ_WAHL]
    S["beleg"] = {"zahl": ("Beide Zahlen kommen aus der Verteilung des Ausblicks am jetzigen Kurs -- dieselbe Quelle wie der Kurs-Rechner. "
                           f"Stufen: {stufen_satz((einst or {}).get('pz'))}."),
                  "achsen": ("Achsen von 0 bis 100: höher heißt mehr Druck. Gemessen, keine Vorhersage. Der Druck-Index zählt A1, A2, A3, A4 und A7. "
                             "Markttiefe und Liquidations-Nähe messen seit 23.125 die Gebote bis −1 % im Hyperliquid-Buch (je Minute aus "
                             "gerundeten Preisstufen, auf eine Stufe genau); ihr eigener Verlauf beginnt damit neu."),
                  "grenzen": GRENZEN, "meldung_alt_s": MELDUNG_ALT_S}
    if any((e or {}).get("kal") for e in (S.get("ereignis") or {}).values()):
        S["beleg"]["kal"] = KAL_VERMERK                                    # Regel K: was „nachkalibriert“ heißt
    if any((e or {}).get("auf") for e in (S.get("ereignis") or {}).values()):
        S["beleg"]["auf"] = AUF_VERMERK                                    # Regel A: was der Aufschlag ist
    S["leit"] = LEIT; S["leit_kurz"] = EREIGNIS[LEIT]["kurz"]
    return S


def meldungen_json(db: str) -> bytes:
    """Antwort für /cockpit/radar/meldungen: nur die letzten Meldungen (für Ton und Ansage bei geschlossenem Cockpit-Abschnitt)."""
    con = lesen(pfad(db))
    try:
        m = meldungen_lesen(con)
    finally:
        if con is not None:
            con.close()
    return json.dumps({"ok": True, "meldungen": _ohne_nan(m), "meldung_alt_s": MELDUNG_ALT_S}, ensure_ascii=False, allow_nan=False).encode("utf-8")


def payload_json(db: str, coin: str = "BTC", jetzt: int | None = None) -> bytes:
    return json.dumps(_ohne_nan(nutzlast(db, coin, jetzt)), ensure_ascii=False, allow_nan=False).encode("utf-8")


def stand_text(S: dict, mit_urteil: bool = True) -> list:
    """Ein Coin als Text (Debug 160). mit_urteil=False: ohne den Satz des Rückblicks je Zahl (der Bericht nennt ihn einmal im Kopf)."""
    z = []; a = z.append
    if not S.get("ok"):
        return [f"== {S.get('coin')}: " + " ".join(S.get("fehlt") or [])]
    k = S["kurs"]
    a(f"== {S['coin']} · Kurs {_px(k.get('px'))} ({'frisch' if k.get('frisch') else 'nicht frisch'}, Stand {_dt(k.get('ts'))})"
      + (f" · Faktor gegenüber BTC {_de(S['faktor'].get('f'), 2)}" if S["faktor"].get("f") is not None and S["coin"] != "BTC" else ""))
    for key in REIHE:
        e = S["ereignis"][key]
        a("   " + e["satz"])
        if e.get("schwellen"):
            a("      Schwellen: " + e["schwellen"])
        if mit_urteil:
            a("      " + e["urteil"])
        if e.get("niveau"):
            a("      " + e["niveau"])
    if S.get("trend"):
        a("   " + S["trend"])
    a("   Achsen (0 bis 100, höher = mehr Druck; „—“ = grau):")
    for x in S["achsen"]:
        a(f"      {x['key'].upper()} {x['name']:<18} {(_de(x['wert'], 0) if x.get('wert') is not None else '—'):>3}  {x['leit']}"
          + (f" · {x['vergleich']}" if x.get("wert") is not None and x.get("vergleich") else "") + f" · Stand {x['stand']}"
          + (f" · grau: {x['grau']}" if x.get("grau") else "")
          + ((" · fehlt im Index" if x.get("wert") is None else " · im Index") if x.get("index") else ""))
    a("   " + S["index"]["text"])
    a("   " + S["treiber"])
    a("   " + S["warnzeichen"]["text"])
    if (S.get("zeichen") or {}).get("text"):
        a("   " + S["zeichen"]["text"])
    return z


def text(db: str, coins=COINS, jetzt: int | None = None) -> str:
    """Debug 160: Stand je Coin, Einstellungen, letzte Meldungen, Vorwärtsbilanz in Zahlen."""
    jetzt = int(jetzt or time.time()); t0 = time.time()
    z = []; a = z.append
    a(f"★ Risikoradar (U307) · Modul {VERSION_MODUL} · {_dt(jetzt)} · Risiko eines Rücksetzers in Prozent, acht Achsen, Alarm")
    con = lesen(pfad(db))
    try:
        rb = meta(con, "rueckblick"); einst = einstellung_lesen(con); takt = meta(con, "takt"); meld = meldungen_lesen(con, 8)
        regeln_roh = meta(con, "regeln"); zeichen_roh = meta(con, "zeichen"); takt_voll = meta(con, "takt_voll")   # 23.125 (U312)
        n_stand = n_alarm = None; erste = None
        if con is not None:
            try:
                n_stand, erste = con.execute("SELECT COUNT(*), MIN(ts) FROM rd_stand").fetchone()
                n_alarm = con.execute("SELECT COUNT(*) FROM rd_alarm WHERE art='alarm'").fetchone()[0]
            except sqlite3.Error:
                pass
    finally:
        if con is not None:
            con.close()
    a("Zwei Zahlen je Coin: −7 % · Faktor in 48 Stunden (in der Karte groß) und −10 % · Faktor in 7 Tagen (BTC: Faktor 1). Stufen: normal · "
      f"{stufen_satz((einst or {}).get('pz'))}. Achsen und Druck-Index sind Messwerte, keine Vorhersage.")   # 23.127 (U314): eingestellt
    if con is None:
        a("radar.db fehlt noch -- der Takt legt sie rund 90 Sekunden nach dem Start des Dashboards an.")
    a("Rückblick: " + (f"gerechnet {_dt(rb.get('stand'))} in {_de(rb.get('dauer'), 0)} s (Debug 161)" if isinstance(rb, dict)
                       else "noch nicht gerechnet (Debug 161) -- bis dahin gibt es keine Stufe und keinen Alarm"))
    if isinstance(rb, dict):
        for key in REIHE:
            a("   " + urteil_satz(key, (rb.get("urteil") or {}).get(key), rb))
        for key in REIHE:                                                 # Regel K: das Urteil der nachkalibrierten Fassung dazu
            kk = (rb.get("kal") or {}).get(key)
            if kk and kk.get("urteil"):
                anz_ = (rb.get("anzeige") or {}).get(key); roh_ok_ = bool(((rb.get("urteil") or {}).get(key) or {}).get("besteht"))
                a("   " + kal_urteil_satz(key, kk.get("urteil"), rb)
                  + (" Die Karte zeigt die nachkalibrierte Zahl." if anz_ in ("kal", "auf") else
                     (" Die Karte bleibt bei der Rohzahl." if roh_ok_ else " Die Zahl bleibt matt, ohne Stufe und ohne Alarm.")))
        A_ = (rb.get("auf") or {}).get(AUF_KEY)                            # Regel A: das Urteil der Zahl mit Aufschlag
        if isinstance(A_, dict) and A_.get("urteil"):
            a("   " + auf_urteil_satz(A_, rb) + (" Die Karte zeigt die Zahl mit Aufschlag." if (rb.get("anzeige") or {}).get(AUF_KEY) == "auf"
                                                  else " Die Karte bleibt bei der Zahl ohne Aufschlag."))
        elif isinstance(A_, dict) and A_.get("grund"):
            a("   Aufschlag (Regel A): kein Urteil -- " + str(A_["grund"]))
    a(regeln_satz(regeln_kurz(regeln_roh)))
    zs_ = zeichen_stand_satz(zeichen_roh)
    if zs_:
        a(zs_)
    if isinstance(takt, dict) and takt.get("ts"):
        ohne_s = jetzt - int(takt["ts"])
        takt_txt = (f"zuletzt {_dt(takt['ts'])}{takt_dauer_satz(takt)}{takt_voll_satz(takt_voll, takt)}" if ohne_s <= 3 * TAKT_S else
                    f"steht seit {_dt(takt['ts'])} (seit {_tsd(ohne_s // 60)} Minuten kein Schritt -- ohne Takt gibt es keinen Alarm; läuft das Dashboard?)")
    else:
        takt_txt = "noch kein Schritt"
    a(f"Meldungen: Push {'an' if einst['push'] else 'aus'} ({'eingerichtet' if push_einstellung().get('thema') else 'Benachrichtigung nicht eingerichtet'}) · "
      f"Coins {', '.join(einst['coins']) or 'keiner'} · Schwelle „hoch“ = {pz_wort(einst['pz'])} Perzentil · "
      f"Takt: {takt_txt}")
    for f in (takt.get("fehler") or [] if isinstance(takt, dict) else []):
        a(f"   Fehler im letzten Schritt des Takts: {f}")
    a("")
    G = None; zsum = {}; tg_ = time.time()
    try:
        import hl_cockpit as HC
        G = HC.gemeinsam_lesen(db, jetzt)                                 # einmal für alle Coins
    except Exception:  # noqa: BLE001 -- dann liest stand() je Coin selbst und nennt den Grund
        G = None
    tg_ = time.time() - tg_
    for coin in coins:
        try:
            S_ = stand(db, coin, jetzt, gemeinsam=G)
            for k_, v_ in (S_.get("zeit") or {}).items():
                zsum[k_] = zsum.get(k_, 0.0) + float(v_)
            z.extend(stand_text(S_, mit_urteil=not isinstance(rb, dict)))
        except Exception as e:  # noqa: BLE001
            a(f"== {coin}: {type(e).__name__}: {e}")
        a("")
    a(f"Vorwärtsbilanz: {_tsd(n_stand or 0)} abgelegte Stände" + (f" seit {_dt(erste)}" if erste else "") + f" · {_tsd(n_alarm or 0)} {'Alarm' if n_alarm == 1 else 'Alarme'}. "
      "Ausgewertet wird sie, wenn genug Ereignisse zusammengekommen sind (Paket 2).")
    if meld:
        a("Letzte Meldungen:")
        for m in meld:
            a(f"   {_dt(m['ts'])} · {m['art']} · {m['titel']} · {m['push']}" + (f" ({m['push_fehler']})" if m.get("push_fehler") else ""))
            a(f"      {m['text']}")
    else:
        a("Letzte Meldungen: keine.")
    a("")
    a(GRENZEN)
    a(f"Rechenzeit dieses Berichts: {_de(time.time() - t0, 1)} s -- " + zeit_satz(zsum, tg_))
    return "\n".join(_umbruch(z))


# ================================================================================================ erfundene Reihen für den Aufschlag (Abschnitt 14.6)

def welt_zahl(sig, f, x: float, tage: int) -> np.ndarray:
    """
    Rohzahl der erfundenen Welt: Chance, dass ein Kurs mit der Tagesschwankung sig binnen `tage` Tagen x · f tiefer berührt wird --
    Spiegelungsprinzip ohne Drift: 2 · Φ(ln(1 − x·f) ÷ (sig · √tage)), auf 0,5 % … 99,5 %. NaN ohne Schwankung oder Faktor.
    Nur für die Probe: Auf dem Pi kommt die Zahl aus der Verteilung des Ausblicks.
    """
    sig = np.asarray(sig, dtype=float); f = np.asarray(f, dtype=float)
    out = np.full(len(sig), np.nan)
    for i in range(len(sig)):
        s = float(sig[i]); xf = x * float(f[i])
        if math.isfinite(s) and s > 0 and math.isfinite(xf) and 0 < xf < 1:
            out[i] = min(max(math.erfc(-math.log(1.0 - xf) / (s * math.sqrt(tage)) / math.sqrt(2.0)), KAL_P[0]), KAL_P[1])
    return out


def auf_welt(saat: int, staerke: float = 1.0, pflanz=("r1",), belegt=("r1", "r7"), n: int = 2520, ursprung_tage: int | None = None) -> dict:
    """
    Eine erfundene Welt für Regel A, ganz durchgerechnet: der Markt aus hl_radar_regeln.welt_bauen (zwei Coins, kein echter Kurs, Zeichen
    ohne Bezug zum Kurs), je Auswertungstag ein Ursprung am Folgetag 00:00 UTC mit der Rohzahl aus der Schwankung (welt_zahl) und dem
    Ereignis der Regel-Prüfung; darauf der ganze Rückblick (Regel K, dann Regel A mit den als belegt gesetzten Regeln).
    staerke > 1 pflanzt einen Effekt in die Regeln aus `pflanz` ein, der wie Regel A auf die Chance wirkt: Nach einem Tag, an dem eines
    dieser Zeichen ansteht, folgt am nächsten Tag ein Tief (12 % · Faktor unter dem Schluss) mit der Wahrscheinlichkeit, die die Chance
    des Ereignisses an diesem Tag auf das `staerke`-Fache hebt (die Chance ohne Effekt aus der Rohzahl, einmal über die ganze Welt
    angepasst). Das gemessene Chancenverhältnis liegt höher als `staerke`, weil ein gepflanztes Tief auch das Ereignis des Vortags
    auslöst -- genannt wird immer das gemessene.
    ursprung_tage: Ursprünge nur aus den letzten so vielen Tagen der Welt (wie auf dem Pi, wo der Rückblick des Radars kürzer ist als
    die Historie der Regel-Prüfung); die Faktoren kommen weiter aus der ganzen Historie. None: alle Auswertungstage.
    -> {"erg": Rückblick, "D": Zustände und Faktoren, "ursprung": Reihen je Coin, "R": Tagesreihen}
    """
    import hl_radar_regeln as RG
    W = RG.welt_bauen(saat, n=n)
    R = dict(W["R"]); x2 = EREIGNIS[AUF_KEY]["x"]; h2 = EREIGNIS[AUF_KEY]["tage"]
    if staerke > 1.0:
        rng = np.random.default_rng(1_000_003 * int(saat) + 17)
        pp = []; yy = []
        for r in R.values():
            e2, g2 = r["E"][AUF_KEY]; m = np.asarray(r["ev"], dtype=bool) & g2
            pp.append(welt_zahl(r["sig"], r["f1"], x2, h2)[m]); yy.append(e2[m].astype(float))
        ab = logit_anpassen(np.concatenate(yy), np.concatenate(pp)) or (0.0, 1.0)
        for coin, r in list(R.items()):
            roh = W["roh"][coin]; T = dict(roh["T"]); tief = np.array(T["l"], dtype=float); c = T["c"]; f1 = roh["f1"]
            pr = welt_zahl(r["sig"], f1, x2, h2); an = np.zeros(len(tief), dtype=bool)
            for rk in pflanz:
                an |= r["regeln"][rk][0] & r["regeln"][rk][1]
            for t in np.nonzero(an & np.isfinite(pr))[0]:
                if t + 1 >= len(tief):
                    continue
                pn = kal_zahl(pr[t], ab[0], ab[1]); o = staerke * pn / (1.0 - pn)
                if rng.random() < (o / (1.0 + o) - pn) / (1.0 - pn):
                    tief[t + 1] = min(tief[t + 1], c[t] * (1.0 - 0.12 * f1[t]))
            T["l"] = tief
            R[coin] = RG.reihen_bauen(coin, T, roh["L"], W["kal"], f1)
    Ro = {}; ende = 0
    for coin, r in R.items():
        d = np.nonzero(np.asarray(r["ev"], dtype=bool))[0]
        if ursprung_tage is not None:
            d = d[d >= int(r["n"]) - int(ursprung_tage)]
        e2, g2 = r["E"]["e2"]; e7, g7 = r["E"]["e7"]
        Ro[coin] = {"tau": (int(r["tag0"]) + d + 1).astype(np.int64) * TAG,
                    "p7": welt_zahl(r["sig"][d], r["f1"][d], EREIGNIS["e7"]["x"], EREIGNIS["e7"]["tage"]),
                    "p2": welt_zahl(r["sig"][d], r["f1"][d], EREIGNIS["e2"]["x"], EREIGNIS["e2"]["tage"]),
                    "ja7": np.where(g7[d], e7[d].astype(float), np.nan), "ja2": np.where(g2[d], e2[d].astype(float), np.nan),
                    "ohne_bib": 0, "ohne_faktor": 0}
        ende = max(ende, int(r["tag0"]) + int(r["n"]))
    D = RG.auf_daten(R, list(belegt), ende)
    return {"erg": rueckblick_auswerten(Ro, ende, D), "D": D, "ursprung": Ro, "R": R}


def auf_nachweis_kurz(erg: dict) -> dict:
    """Ein fertiger Rückblick in Kurzform für die Messung: besteht die Grundlage (G2k), besteht G2a, trifft die Zahl besser, gilt der
    Aufschlag; dazu je belegter Regel das gemessene Chancenverhältnis und die Signaltage des letzten Monats und der p-Wert des Vergleichs."""
    A = ((erg or {}).get("auf") or {}).get(AUF_KEY) or {}
    nn = (A.get("aktuell") or {}).get("n") or {}
    return {"basis": bool(((((erg or {}).get("kal") or {}).get(AUF_KEY) or {}).get("besteht"))), "g2a": bool((A.get("urteil") or {}).get("besteht")),
            "besser": auf_besser_ok(A.get("besser")), "auf": bool(A.get("besteht")),
            "or": {rk: _zahl((nn.get(rk) or {}).get("or")) for rk in A.get("regeln") or []},
            "tage": {rk: (nn.get(rk) or {}).get("tage") for rk in A.get("regeln") or []},
            "diff": _zahl((A.get("besser") or {}).get("diff")), "p": _zahl((A.get("besser") or {}).get("p"))}


AUF_NACHWEIS_TAGE = 1681                      # 14.6: so viele Ursprungstage hatte der Rückblick der 48-Stunden-Zahl auf dem Pi (Debug 161 vom
                                              # 24.11.2026: G2 an 1.681 Tagen, davon nachkalibriert -- G2k -- an 1.386)


def auf_nachweis_welt(saat: int, staerke: float, pflanz=("r1",)) -> dict:
    """Eine erfundene Welt, ganz durchgerechnet, in Kurzform (auf_nachweis_kurz) -- mit Ursprüngen nur aus den letzten AUF_NACHWEIS_TAGE
    Tagen wie auf dem Pi."""
    return auf_nachweis_kurz(auf_welt(saat, staerke, pflanz, ursprung_tage=AUF_NACHWEIS_TAGE)["erg"])


def auf_nachweis_zaehlen(plan, erg: list, n_welten: int) -> dict:
    """Die Welten der Messung je Fall zusammenzählen. Gezählt werden nur Welten, in denen die Grundlage (G2k) besteht: „basis“ ist ihre
    Zahl, „auf“ die Zahl derer mit geltendem Aufschlag; dazu G2a allein, „trifft besser“ allein, Unterschied über 0 und je Regel der
    Median des gemessenen Chancenverhältnisses und der Signaltage."""
    out = {"welten": int(n_welten)}
    for j, (name, st, pf) in enumerate(plan):
        teil = [e for e in erg[j * n_welten:(j + 1) * n_welten] if e["basis"]]
        z = {"staerke": float(st), "pflanz": list(pf), "basis": len(teil), "auf": sum(1 for e in teil if e["auf"]), "g2a": sum(1 for e in teil if e["g2a"]),
             "besser": sum(1 for e in teil if e["besser"]), "diff_plus": sum(1 for e in teil if (e["diff"] or 0) > 0), "or_median": {}, "tage_median": {}}
        for rk in ("r1", "r7"):
            ors = [e["or"].get(rk) for e in teil if e["or"].get(rk) is not None]
            tg = [e["tage"].get(rk) for e in teil if e["tage"].get(rk) is not None]
            z["or_median"][rk] = float(np.median(ors)) if ors else None
            z["tage_median"][rk] = float(np.median(tg)) if tg else None
        out[name] = z
    return out


AUF_NACHWEIS_PLAN = (("ohne", 1.0, ()), ("r1", 1.75, ("r1",)), ("beide", 1.75, ("r1", "r7")))


def auf_nachweis(n_welten: int = 400, saat0: int = 40000, plan=AUF_NACHWEIS_PLAN, log=print, prozesse: int = 1) -> dict:
    """
    Abschnitt 14.6: auf erfundenen Reihen messen, wie oft der Aufschlag gilt (G2a besteht, die Zahl trifft besser, ein Faktor liegt
    vor) -- wenn die Zeichen nichts tragen, wenn nur R1 einen eingepflanzten Effekt trägt und wenn R1 und R7 ihn tragen. Gezählt
    werden die Welten, in denen die Grundlage (G2k) besteht, denn ohne sie gibt es keinen Aufschlag (Regel A1; auf dem Pi besteht sie).
    Genannt wird das gemessene Chancenverhältnis (Median über diese Welten). Rechnet lange -- nur in der Probe, nicht auf dem Pi.
    Die Saat der Welt j des Falls i ist saat0 + 1000 · i + j.
    """
    aufgaben = [(saat0 + 1000 * j + i, st, pf) for j, (_n, st, pf) in enumerate(plan) for i in range(n_welten)]
    if prozesse > 1:
        import multiprocessing as mp
        with mp.Pool(prozesse) as pool:
            erg = pool.starmap(auf_nachweis_welt, aufgaben, chunksize=4)
    else:
        erg = [auf_nachweis_welt(*a) for a in aufgaben]
    out = auf_nachweis_zaehlen(plan, erg, n_welten)
    for name, _st, _pf in plan:
        log(f"{name}: " + json.dumps(out[name], ensure_ascii=False))
    return out


# ================================================================================================ Proben zu Regel A (Aufschlag, 23.124)

def _o0_hand(p: float, F: float, pi: float) -> float:
    """Gegenrechnung zu auf_o0 für EINEN Zustand mit Faktor F und Anteil pi -- die positive Lösung von
    F·(1 − p)·o² + (pi·F + 1 − pi − p·(F + 1))·o − p = 0 (aus pi·F·o/(1 + F·o) + (1 − pi)·o/(1 + o) = p)."""
    a = F * (1.0 - p); b = pi * F + 1.0 - pi - p * (F + 1.0)
    return (-b + math.sqrt(b * b + 4.0 * a * p)) / (2.0 * a)


def _probe_rb_auf(jetzt: int, **kw) -> dict:
    """Rückblick der Probe mit Regel A: Die 48-Stunden-Zahl gilt mit Aufschlag (R1 mit Faktor 3, R7 ohne Faktor); BTC und ETH haben
    Anteile, HYPE nicht. kw ändert Einträge von auf.e2."""
    r_ = _probe_rb_kal(jetzt)
    q2a = {"0.8": 0.30, "0.9": 0.38, "0.95": 0.45, "0.975": 0.50, "0.99": 0.60}
    r_["kal"]["e2"]["coins"]["HYPE"] = {"n": 900, "grundrate": 0.05, "q": dict(r_["kal"]["e2"]["coins"]["BTC"]["q"]), "niveau": 1.0}
    r_["kal"]["e2"]["coins"]["ETH"] = {"n": 1300, "grundrate": 0.04, "q": dict(r_["kal"]["e2"]["coins"]["BTC"]["q"]), "niveau": 1.0}
    r_["auf"] = {"e2": {"regeln": ["r1", "r7"], "besteht": True, "grund": None,
                        "urteil": {"besteht": True, "n": 6000, "n_tage": 1300, "n_ereignisse": 400, "skill": 0.081, "p": 0.001, "steigung": 0.97,
                                   "niveau": 1.02, "grund": None},
                        "besser": {"n": 6000, "geaendert": 2500, "brier_ohne": 0.0612, "brier_mit": 0.0601, "diff": 0.0011, "p": 0.012},
                        "aktuell": {"monat": 20758, "f": {"r1": 3.0, "r7": None},
                                    "anteil": {"BTC": {"r1": 0.5, "r7": 0.25}, "ETH": {"r1": 0.2, "r7": 0.0}},
                                    "n": {"r1": {"tage": 380, "episoden": 80, "ohne": 2900, "or": 3.4},
                                          "r7": {"tage": 20, "episoden": 4, "ohne": 2900, "or": None}}, "tage": 1700},
                        "coins": {"BTC": {"n": 1300, "grundrate": 0.03, "q": q2a, "niveau": 1.02,
                                          "alarme": {"schwelle": 0.45, "eintritte": 9, "je_jahr": 2.5, "treffer": 4, "episoden": 40, "gedeckt": 8},
                                          "alarme_wahl": {"0.975": {"schwelle": 0.50, "eintritte": 5, "je_jahr": 1.4, "treffer": 3, "episoden": 40, "gedeckt": 5},
                                                          "0.99": {"schwelle": 0.60, "eintritte": 2, "je_jahr": 0.6, "treffer": 1, "episoden": 40, "gedeckt": 2}}},
                                  "ETH": {"n": 1300, "grundrate": 0.04, "q": q2a, "niveau": 0.98}},
                        "zaehlung": {"keins": 2100, "unbekannt": 40, "r1": 300, "r7": 160},
                        "monate": {"r1": {"n": 40, "min": 1.8, "max": 3.0}, "r7": {"n": 0, "min": None, "max": None}},
                        "coins_auf": ["BTC", "ETH"], "fehlt": []}}
    r_["anzeige"]["e2"] = "auf"
    r_["auf"]["e2"].update(kw)
    return r_


def _probe_zeichen(jetzt: int, k_btc=1, k_eth=0, alt_tage: int = 1, regeln=("r1", "r7")) -> dict:
    """Abgelegter Stand der belegten Zeichen (rd_meta „zeichen“) in der Form von zeichen_pflegen."""
    tag = int(jetzt) // TAG - alt_tage
    name = lambda k: (list(regeln)[k - 1] if isinstance(k, int) and not isinstance(k, bool) and 1 <= k <= len(regeln) else None)   # noqa: E731
    return {"ts": jetzt - 600, "versuch": jetzt - 600, "regeln": list(regeln),
            "coins": {"BTC": {"tag": tag, "k": k_btc, "regel": name(k_btc)}, "ETH": {"tag": tag, "k": k_eth, "regel": name(k_eth)}}}


def _proben_auf_rechnen(ok, jetzt: int) -> None:
    """Regel A, die Rechnung: Aufteilung (A4), Reihe im Rückblick (A5), Vergleich (A5 b)."""
    # ---------------------------------------------------------------- A4: Aufteilung, die das Mittel hält
    o_a = float(auf_o0(np.array([0.2]), [3.0], [0.5])[0]); o_b = auf_o0(np.array([0.2, 0.05]), [], [])
    o_c = float(auf_o0(np.array([0.2]), [2.0], [1.0])[0])
    pv = np.array([0.02, 0.1, 0.6]); o_d = auf_o0(pv, [3.0, 1.5], [0.1, 0.2])
    links = 0.1 * 3 * o_d / (1 + 3 * o_d) + 0.2 * 1.5 * o_d / (1 + 1.5 * o_d) + 0.7 * o_d / (1 + o_d)
    o_e = auf_o0(np.array([0.2, 0.2]), [np.array([1.0, 3.0])], [np.array([0.5, 0.5])])
    ok("AU1 Regel A4, die Chance o₀ für „keins“: Bei p = 20 %, einem Zeichen mit Faktor 3 an der Hälfte der Tage ist o₀ die Lösung von "
       "2,4·o² + 1,2·o − 0,2 = 0, also 0,13188 (von Hand); ohne Zeichen ist o₀ die Chance selbst (0,25); steht das Zeichen immer an "
       "(Anteil 1, Faktor 2), ist o₀ = 0,125; mit zwei Zeichen (Faktor 3 an 10 %, Faktor 1,5 an 20 % der Tage) ergibt das Mittel über die drei "
       "Zustände wieder die Zahl (2 %, 10 %, 60 %); Faktor und Anteil dürfen je Ursprung verschieden sein",
       abs(o_a - (-1.2 + math.sqrt(3.36)) / 4.8) < 1e-9 and abs(o_a - 0.1318813) < 1e-6 and abs(o_a - _o0_hand(0.2, 3.0, 0.5)) < 1e-9
       and np.allclose(o_b, [0.25, 0.05 / 0.95], rtol=0, atol=1e-9) and abs(o_c - 0.125) < 1e-9 and np.allclose(links, pv, rtol=0, atol=1e-9)
       and abs(float(o_e[0]) - 0.25) < 1e-9 and abs(float(o_e[1]) - o_a) < 1e-12, f"o₀ {o_a:.7f}; zwei Zeichen {np.round(links, 6)}")
    z0 = auf_zahl(0.2, 0, [3.0], [0.5]); z1 = auf_zahl(0.2, 1, [3.0], [0.5])
    zz = [auf_zahl(0.1, k_, [3.0, 1.5], [0.1, 0.2]) for k_ in (0, 1, 2)]
    ok("AU2 Regel A4, die Zahl je Zustand: aus 20 % werden ohne Zeichen 11,65 % und mit Zeichen (Faktor 3) 28,35 % -- im Mittel der beiden "
       "Hälften wieder 20 %; mit zwei Zeichen stimmt das Mittel ebenso; ein unbekannter Zustand (−1, nichts, ein Wahrheitswert, eine "
       "Kommazahl, ein Text, eine Nummer über der Zahl der Regeln) lässt die Zahl, wie sie ist; ein fehlender Faktor zählt als 1 (R7 ohne "
       "Faktor: wie „keins“); die Zahl zählt beim Eingang wie in der Anzeige mit höchstens 99,5 % und mindestens 0,5 %, und das Ergebnis "
       "bleibt in diesen Grenzen; ohne Zahl kein Ergebnis",
       abs(z0 - o_a / (1 + o_a)) < 1e-12 and abs(z0 - 0.116516) < 1e-5 and abs(z1 - 3 * o_a / (1 + 3 * o_a)) < 1e-12 and abs(z1 - 0.283484) < 1e-5
       and abs(0.5 * z0 + 0.5 * z1 - 0.2) < 1e-9 and abs(0.7 * zz[0] + 0.1 * zz[1] + 0.2 * zz[2] - 0.1) < 1e-9 and zz[0] < 0.1 < zz[2] < zz[1]
       and all(auf_zahl(0.2, k_, [3.0], [0.5]) == 0.2 for k_ in (-1, None, True, 1.0, "1", 2))
       and auf_zahl(0.2, np.int16(1), [3.0], [0.5]) == z1
       and abs(auf_zahl(0.2, 1, [None], [0.5]) - 0.2) < 1e-9 and abs(auf_zahl(0.2, 0, [None], [0.5]) - 0.2) < 1e-9
       and abs(auf_zahl(0.2, 2, [3.0, None], [0.5, 0.25]) - z0) < 1e-9 and abs(auf_zahl(0.2, 1, [3.0, None], [0.5, 0.25]) - z1) < 1e-9
       and auf_zahl(0.99, 1, [3.0], [0.01]) == 0.995 and auf_zahl(0.004, 0, [3.0], [0.5]) == 0.005 and auf_zahl(None, 1, [3.0], [0.5]) is None
       and auf_zahl(0.999, 0, [3.0], [0.5]) == auf_zahl(0.995, 0, [3.0], [0.5]) < 0.995 and auf_zahl(0.001, 1, [3.0], [0.5]) == auf_zahl(0.005, 1, [3.0], [0.5]) > 0.005
       and abs(auf_zahl(0.2, 0, [], []) - 0.2) < 1e-9, f"ohne {z0:.6f}, mit {z1:.6f}")
    # ---------------------------------------------------------------- A5: die Reihe im Rückblick
    T0 = 19000                                                            # 08.01.2022; 01.02.2022 = 19024, 01.03.2022 = 19052
    zB = np.zeros(60, dtype=np.int16); zB[23] = 1; zB[24] = 2; zB[25] = -1
    zE = np.zeros(30, dtype=np.int16); zE[24] = 1
    an_ = {"BTC": {"r1": 0.5, "r7": 0.25}, "ETH": {"r1": 0.2, "r7": 0.0}}
    Dh = {"regeln": ["r1", "r7"], "coins": {"BTC": {"tag0": T0, "zustand": zB}, "ETH": {"tag0": T0, "zustand": zE}},
          "monate": {18993: {"monat": 18993, "f": {"r1": None, "r7": None}, "anteil": an_},
                     19024: {"monat": 19024, "f": {"r1": 3.0, "r7": None}, "anteil": an_}}}
    ur = [(19000, "BTC", 0.2), (19023, "BTC", 0.2), (19024, "BTC", 0.2), (19025, "BTC", 0.2), (19026, "BTC", 0.2), (19027, "BTC", 0.2),
          (19027, "BTC", float("nan")), (19025, "ETH", 0.2), (19026, "ETH", 0.2), (19031, "ETH", 0.2), (19025, "HYPE", 0.2), (19053, "BTC", 0.2),
          (19024, "BTC", 0.999), (19025, "BTC", 0.999)]
    tau_h = np.array([u[0] * TAG for u in ur], dtype=np.int64); ci_h = np.array([u[1] for u in ur]); p_h = np.array([u[2] for u in ur])
    Sh = auf_reihe(tau_h, ci_h, p_h, Dh)
    oE = _o0_hand(0.2, 3.0, 0.2)
    oN = _o0_hand(0.995, 3.0, 0.5)
    soll = [0.2, 0.2, z1, z0, 0.2, z0, float("nan"), 3 * oE / (1 + 3 * oE), oE / (1 + oE), 0.2, 0.2, 0.2, 0.995, oN / (1 + oN)]
    S_leer = auf_reihe(tau_h, ci_h, p_h, {"regeln": [], "coins": Dh["coins"], "monate": Dh["monate"]}); S_kein = auf_reihe(tau_h, ci_h, p_h, None)
    ok("AU3 Regel A5, die Zahl mit Aufschlag je Ursprung: Es gilt der Zustand des VORTAGS und der Faktor des Monats des Ursprungs. BTC am "
       "01.02.2022 (Vortag: R1 steht an) 20 % -> 28,35 %; am 02.02. (Vortag: nur R7, das keinen Faktor hat) -> 11,65 % wie „keins“; am 03.02. "
       "(Vortag unbekannt) bleibt 20 %; im Januar (kein Faktor) und im März (Monat fehlt) bleibt die Zahl; vor dem Beginn und nach dem Ende "
       "der Tagesreihe ist der Zustand unbekannt; ETH mit eigenem Anteil (20 % der Tage): 36,25 % und 15,94 %; ein Coin ohne Tagesreihe "
       "bleibt; eine fehlende Zahl bleibt fehlend; 99,9 % zählt wie 99,5 % (mit R1: 99,5 %; mit R7 ohne Faktor: die Aufteilung von 99,5 %, "
       "darunter); ohne belegte Regeln oder ohne Daten bleibt alles",
       np.allclose(Sh["p"], soll, rtol=0, atol=1e-9, equal_nan=True) and [int(v) for v in Sh["z"]] == [-1, 0, 1, 2, -1, 0, 0, 1, 0, -1, -2, 0, 1, 2]
       and Sh["p"][-1] < 0.995
       and abs(soll[7] - 0.362541) < 1e-5 and abs(soll[8] - 0.159364) < 1e-5
       and np.array_equal(S_leer["p"], p_h, equal_nan=True) and set(int(v) for v in S_leer["z"]) == {-2}
       and np.array_equal(S_kein["p"], p_h, equal_nan=True) and Sh["p"] is not p_h and p_h[2] == 0.2,
       f"{[round(float(v), 4) for v in Sh['p']]} {[int(v) for v in Sh['z']]}")
    # ---------------------------------------------------------------- A5 (b): trifft die Zahl besser?
    tg40 = np.arange(40, dtype=np.int64) * TAG + 19000 * TAG; y40 = (np.arange(40) < 10).astype(float)
    a40 = np.full(40, 0.2); b40 = np.where(y40 == 1, 0.4, 0.1)
    Bg = auf_besser(tg40, a40, b40, y40); Bs = auf_besser(tg40, b40, a40, y40)
    a41 = np.concatenate([a40, [float("nan"), 0.2]]); b41 = np.concatenate([b40, [0.3, 0.2]]); y41 = np.concatenate([y40, [1.0, 0.0]])
    Bn = auf_besser(np.concatenate([tg40, [tg40[0], tg40[1]]]), a41, b41, y41); Bk = auf_besser(tg40[:20], a40[:20], b40[:20], y40[:20])
    import hl_ausblick as AUb
    rq = np.random.default_rng(4); tq = np.repeat(np.arange(60, dtype=np.int64) + 19000, 3) * TAG
    aq = rq.uniform(0.05, 0.4, 180); bq = np.clip(aq + rq.normal(0.01, 0.05, 180), 0.01, 0.9); yq = (rq.random(180) < 0.2).astype(float)
    Bq = auf_besser(tq, aq, bq, yq); dq = ((aq - yq) ** 2 - (bq - yq) ** 2).reshape(60, 3).mean(axis=1)
    ok("AU4 Regel A5 (b), der Vergleich: 40 Tage, 10 Ereignisse, ohne Aufschlag überall 20 %, mit Aufschlag 40 % vor einem Ereignis und "
       "10 % sonst -> Brier 0,19 gegen 0,0975, Unterschied 0,0925 (von Hand), p unter 0,05: trifft besser; vertauscht: Unterschied −0,0925, "
       "trifft nicht besser; ein Ursprung ohne Zahl zählt nicht, ein unveränderter zählt mit (41 Ursprünge, 40 geändert); unter 30 Tagen "
       "gibt es keinen p-Wert und damit kein „besser“. Der p-Wert kommt aus den Tagesmitteln (drei Ursprünge je Tag: von Hand gemittelt) "
       "mit demselben Bootstrap wie beim Skill (Blöcke von 28 Tagen, 2000 Ziehungen). Grenzen: Unterschied genau 0 oder p genau 0,05 "
       "reicht nicht",
       Bg["n"] == 40 and Bg["geaendert"] == 40 and abs(Bg["brier_ohne"] - 0.19) < 1e-12 and abs(Bg["brier_mit"] - 0.0975) < 1e-12
       and abs(Bg["diff"] - 0.0925) < 1e-12 and Bg["p"] < 0.05 and auf_besser_ok(Bg) is True
       and abs(Bs["diff"] + 0.0925) < 1e-12 and auf_besser_ok(Bs) is False and Bs["p"] > 0.5
       and Bn["n"] == 41 and Bn["geaendert"] == 40 and abs(Bn["brier_ohne"] - (0.19 * 40 + 0.04) / 41) < 1e-12
       and abs(Bn["diff"] - (Bn["brier_ohne"] - Bn["brier_mit"])) < 1e-12
       and Bq["n"] == 180 and Bq["p"] == AUb.boot_p(dq, 28, 2000, 23)["p"] and abs(Bq["diff"] - float(dq.mean())) < 1e-15 and 0.0 < Bq["p"] < 1.0
       and Bq["p"] != AUb.boot_p(((aq - yq) ** 2 - (bq - yq) ** 2), 28, 2000, 23)["p"]
       and Bk["n"] == 20 and auf_besser_ok(Bk) is False and auf_besser(tg40, a40 * np.nan, b40, y40) == {
           "n": 0, "geaendert": 0, "brier_ohne": None, "brier_mit": None, "diff": None, "p": None}
       and auf_besser_ok({"diff": 1e-9, "p": 0.0499}) is True and auf_besser_ok({"diff": 1e-9, "p": 0.05}) is False
       and auf_besser_ok({"diff": 0.0, "p": 0.001}) is False and auf_besser_ok({"diff": -1e-9, "p": 0.001}) is False
       and auf_besser_ok({"diff": 0.1, "p": None}) is False and auf_besser_ok({"diff": None, "p": 0.01}) is False and auf_besser_ok(None) is False,
       f"Unterschied {Bg['diff']:.4f}, p {Bg['p']:.4f}; vertauscht p {Bs['p']:.3f}; kurz p {Bk['p']}")


def _proben_auf_welt(ok, jetzt: int) -> None:
    """Regel A auf einer erfundenen Welt, ganz durchgerechnet (A5, A6), und Debug 161."""
    import hl_radar_regeln as RG
    WP = auf_welt(112, 2.5, ("r1", "r7")); EP = WP["erg"]; AP = EP["auf"]["e2"]; DP = WP["D"]; RoP = WP["ursprung"]
    ende = 18262 + 2520; mon_e = monatserster(ende)
    uP = AP.get("urteil") or {}; bP = AP.get("besser") or {}; aP = AP.get("aktuell") or {}
    ok("AU5 erfundene Welt mit einem eingepflanzten Effekt in R1 und R7 (zwei Coins, 2.520 Tage; die Zahl ohne Aufschlag kommt aus der "
       "Schwankung und kennt die Zeichen nicht): Die nachkalibrierte Zahl besteht, die Zahl mit Aufschlag besteht dieselben vier Kriterien "
       "(G2a) auf denselben Ursprüngen und trifft besser (Brier kleiner, p unter 0,01) -> die Anzeige wechselt auf „mit Aufschlag“; die "
       "Faktoren des laufenden Monats liegen zwischen 1 und 3, die Anteile zwischen 0 und 1; jeder Ursprung ist genau einem Zustand "
       "zugeordnet; Schwellen und Alarm-Zählung je Coin gibt es für die Zahl mit Aufschlag (auch für die wählbaren Schwellen), ihre "
       "Schwelle „hoch“ liegt über der ohne Aufschlag",
       EP["anzeige"]["e2"] == "auf" and AP["besteht"] is True and AP["grund"] is None and uP.get("besteht") is True
       and EP["kal"]["e2"]["besteht"] is True and uP["n"] == EP["kal"]["e2"]["urteil"]["n"] == bP["n"] and bP["diff"] > 0 and bP["p"] < 0.01
       and bP["brier_mit"] < bP["brier_ohne"] and abs(uP["brier"] - bP["brier_mit"]) < 1e-12
       and abs(EP["kal"]["e2"]["urteil"]["brier"] - bP["brier_ohne"]) < 1e-12
       and AP["regeln"] == ["r1", "r7"] and AP["coins_auf"] == ["BTC", "ETH"] and aP.get("monat") == mon_e
       and all(1.0 <= aP["f"][rk] <= AUF_DECKEL for rk in ("r1", "r7")) and all(0.0 < aP["anteil"][c_][rk] < 0.5 for c_ in ("BTC", "ETH") for rk in ("r1", "r7"))
       and sum(AP["zaehlung"].values()) == bP["n"] and AP["zaehlung"]["r1"] > 100 and AP["zaehlung"]["r7"] > 100 and AP["zaehlung"]["unbekannt"] == 0
       and AP["coins"]["BTC"]["q"]["0.95"] > EP["kal"]["e2"]["coins"]["BTC"]["q"]["0.95"]
       and AP["coins"]["BTC"]["alarme"]["schwelle"] == AP["coins"]["BTC"]["q"]["0.95"]
       and set(AP["coins"]["BTC"]["alarme_wahl"]) == {"0.975", "0.99"} and AP["coins"]["BTC"]["alarme_wahl"]["0.99"]["schwelle"] == AP["coins"]["BTC"]["q"]["0.99"]
       and set(EP["kal"]["e2"]["coins"]["BTC"]["alarme_wahl"]) == {"0.975", "0.99"} and set(EP["coins"]["BTC"]["e2"]["alarme_wahl"]) == {"0.975", "0.99"}
       and AP["monate"]["r1"]["n"] > 40 and 1.0 <= AP["monate"]["r1"]["min"] <= AP["monate"]["r1"]["max"] <= AUF_DECKEL
       and EP["anzeige"]["e7"] in ("kal", "roh") and "e7" not in EP["auf"] and json.dumps(_ohne_nan(EP), allow_nan=False) is not None,
       f"G2a {uP.get('besteht')} (Steigung {uP.get('steigung')}, Niveau {uP.get('niveau')}); Brier {bP.get('brier_mit')} gegen {bP.get('brier_ohne')}, "
       f"p {bP.get('p')}; Faktoren {aP.get('f')}; Zählung {AP.get('zaehlung')}")
    tau_p = np.concatenate([RoP[c_]["tau"] for c_ in RoP]); ci_p = np.concatenate([np.full(len(RoP[c_]["tau"]), c_) for c_ in RoP])
    ja_p = np.concatenate([RoP[c_]["ja2"] for c_ in RoP]); g_p = []
    for c_ in RoP:
        okj = np.isfinite(RoP[c_]["ja2"]); gl_ = np.full(len(okj), np.nan)
        gl_[okj] = grundrate_laufend(RoP[c_]["tau"][okj], RoP[c_]["ja2"][okj], 2); g_p.append(gl_)
    g_p = np.concatenate(g_p); pk_p = kal_reihen(tau_p, np.concatenate([RoP[c_]["p2"] for c_ in RoP]), ja_p, 2, ende)["p"]
    neu_ = lambda: {"anzeige": {"e2": "kal"}}                             # noqa: E731
    O1 = neu_(); auf_auswerten(O1, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, DP)
    R_roll = {c_: dict(r_, regeln={rk: (np.roll(s_, 700), np.roll(d_, 700)) for rk, (s_, d_) in r_["regeln"].items()}) for c_, r_ in WP["R"].items()}
    O2 = neu_(); auf_auswerten(O2, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, RG.auf_daten(R_roll, ["r1", "r7"], ende))
    D_of = dict(DP, monate={m_: (dict(v_, f={rk: None for rk in v_["f"]}) if m_ == mon_e else v_) for m_, v_ in DP["monate"].items()})
    O3 = neu_(); auf_auswerten(O3, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, D_of)
    O4 = {"anzeige": {"e2": "roh"}}; auf_auswerten(O4, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, DP)
    O5 = neu_(); auf_auswerten(O5, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, None)
    O6 = neu_(); auf_auswerten(O6, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, {"grund": "Probe: kein Urteil"})
    O7 = neu_(); auf_auswerten(O7, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, {"regeln": ["r1"], "coins": {}, "monate": {}})
    alt_gu = globals()["g_urteil"]
    try:                                                                   # G2a besteht nicht (hier erzwungen), obwohl die Zahl besser trifft
        globals()["g_urteil"] = lambda *a_, **k_: dict(alt_gu(*a_, **k_), besteht=False, grund="Probe: Steigung 0,71 außerhalb")
        O8 = neu_(); auf_auswerten(O8, "e2", RoP, tau_p, ci_p, pk_p, ja_p, g_p, ende, DP)
    finally:
        globals()["g_urteil"] = alt_gu
    A2_ = O2["auf"]["e2"]; A3_ = O3["auf"]["e2"]; A8_ = O8["auf"]["e2"]
    ok("AU6 Regel A6, wann der Aufschlag NICHT gilt (dieselbe Welt): (1) Zeichen ohne Bezug zum Ereignis (die Signale um 700 Tage "
       "verschoben) -> die Zahl trifft nicht belegbar besser, die Anzeige bleibt „nachkalibriert“; (2) für den laufenden Monat liegt kein "
       "Faktor vor -> G2a und der Vergleich bestehen, der Aufschlag gilt trotzdem nicht; (3) die nachkalibrierte Zahl gilt nicht -> kein "
       "Aufschlag (Regel A1), nichts wird gerechnet; (4) ohne Daten der Regel-Prüfung steht deren Grund da; (5) G2a besteht nicht, obwohl "
       "die Zahl besser trifft -> kein Aufschlag, der Grund nennt G2a. Derselbe Aufruf mit den richtigen Daten ergibt wieder das Urteil "
       "des ganzen Rückblicks",
       O1["anzeige"]["e2"] == "auf" and O1["auf"]["e2"]["besteht"] is True and O1["auf"]["e2"]["besser"] == AP["besser"]
       and O1["auf"]["e2"]["urteil"]["brier"] == uP["brier"]
       and O2["anzeige"]["e2"] == "kal" and A2_["besteht"] is False and auf_besser_ok(A2_["besser"]) is False
       and (_drin("trifft nicht belegbar besser als ohne", A2_["grund"]) or _drin("G2a besteht nicht", A2_["grund"]))
       and A2_["besser"]["diff"] < bP["diff"] / 4
       and O3["anzeige"]["e2"] == "kal" and A3_["besteht"] is False and A3_["urteil"]["besteht"] is True and auf_besser_ok(A3_["besser"]) is True
       and A3_["grund"] == "Für den laufenden Monat liegt kein Faktor vor."
       and O4["anzeige"]["e2"] == "roh" and O4["auf"]["e2"] == {"regeln": ["r1", "r7"], "besteht": False,
                                                              "grund": "Die nachkalibrierte Zahl besteht nicht -- ohne sie gibt es keinen Aufschlag (Regel A1)."}
       and O5["anzeige"]["e2"] == "kal" and O5["auf"]["e2"]["besteht"] is False and _drin("kein Zeichen belegt", O5["auf"]["e2"]["grund"])
       and "urteil" not in O5["auf"]["e2"] and O6["auf"]["e2"]["grund"] == "Probe: kein Urteil" and O6["auf"]["e2"]["regeln"] == []
       and O7["auf"]["e2"]["besteht"] is False and "urteil" not in O7["auf"]["e2"] and O7["auf"]["e2"]["regeln"] == ["r1"]
       and O8["anzeige"]["e2"] == "kal" and A8_["besteht"] is False and auf_besser_ok(A8_["besser"]) is True
       and A8_["grund"] == "G2a besteht nicht: Probe: Steigung 0,71 außerhalb.",
       f"verschoben: {A2_.get('grund')} (Unterschied {A2_['besser']['diff']:.2e}, p {A2_['besser']['p']:.3f}); ohne Faktor: {A3_.get('grund')}")
    rbP = dict(_ohne_nan(EP), stand=jetzt, version=VERSION_MODUL, dauer=3.0, fehlt=[])
    rt_a = rueckblick_text(rbP, 0.975); rt_v = rueckblick_text(rbP, 0.95); rt_o = rueckblick_text(rbP)
    rb2 = dict(_ohne_nan(dict(EP, auf={"e2": A2_}, anzeige=dict(EP["anzeige"], e2="kal"))), stand=jetzt, version=VERSION_MODUL, dauer=3.0, fehlt=[])
    rt_n = rueckblick_text(rb2, 0.975); ein_ = lambda s_: " ".join(s_.split())                                                    # noqa: E731
    nw_ = {"datum": "24.11.2026", "welten": 400, "ohne": {"basis": 240, "auf": 2}, "r1": {"basis": 250, "auf": 20, "or": 2.34},
           "beide": {"basis": 244, "auf": 122, "or": 2.46}}
    nz_ = ein_(" ".join(auf_nachweis_zeilen(nw_)))
    ok("AU7 Debug 161 mit Regel A: der Abschnitt „Aufschlag für belegte Zeichen“ nennt die Regel, das Urteil G2a, den Vergleich (Brier mit "
       "und ohne, p), die Ursprünge je Zustand, je Regel den Faktor des laufenden Monats mit dem Chancenverhältnis und seinen Tagen, je Coin "
       "Anteile und Beispiele, die Folge und die Schwellen der Zahl mit Aufschlag; der Abschnitt der Nachkalibrierung nennt sie dann als "
       "Grundlage; ist „hoch“ auf das 97,5. Perzentil gestellt, steht die Alarm-Zählung auch dafür da (für die Zahl, die gilt), bei der "
       "Vorgabe nicht; besteht der Aufschlag nicht, steht „bleibt bei der nachkalibrierten Zahl“ und der Grund, und die Zählung gilt der "
       "nachkalibrierten Zahl (gilt nur die Rohzahl, dann ihr); keine Zeile über 150 Zeichen. Die Messung auf erfundenen Reihen in Worten: je Fall die Zahl der Reihen "
       "und der Anteil",
       "== Aufschlag für belegte Zeichen (Regel A, KONZEPT_Risikoradar.md 14.4" in rt_a and "dritte Prüfung der 48-Stunden-Zahl" in ein_(rt_a)
       and "G2a · 48 Stunden: Rückblick G2a (mit Aufschlag)" in rt_a and "— besteht." in ein_(rt_a).split("G2a · 48 Stunden:")[1].split("Vergleich auf")[0]
       and f"Vergleich auf {_tsd(bP['n'])} Ursprüngen ({_tsd(bP['geaendert'])} davon mit geänderter Zahl): Brier mit Aufschlag" in ein_(rt_a)
       and f"nach Zustand des Vortags: R1 Kontenquote {_tsd(AP['zaehlung']['r1'])} · R7 Druck-Index {_tsd(AP['zaehlung']['r7'])} · keins" in ein_(rt_a)
       and f"R1 Kontenquote: Faktor in {AP['monate']['r1']['n']} Monaten zwischen" in ein_(rt_a) and f"laufender Monat ({_tag_txt(mon_e)}): Faktor {_de(aP['f']['r1'], 2)} (Chancenverhältnis" in ein_(rt_a)
       and "BTC: Anteil der Tage R1 Kontenquote" in ein_(rt_a) and "Beispiele (ohne Aufschlag -> ohne Zeichen / R1 / R7): 5,0 % ->" in ein_(rt_a)
       and "Folge: Die Karte zeigt die Zahl mit Aufschlag; Stufen, Schwellen und Alarm gelten für sie." in ein_(rt_a)
       and (f"Brier mit Aufschlag {_de(bP['brier_mit'], 5)}, ohne {_de(bP['brier_ohne'], 5)}, Unterschied {_de(bP['diff'] * 1e4, 2, True)} · 10⁻⁴ "
            f"({p_wert_text(bP['p'])})") in ein_(rt_a)
       and (f"(Chancenverhältnis {_de(aP['n']['r1']['or'], 2)} aus {_tsd(aP['n']['r1']['tage'])} Tagen in {_tsd(aP['n']['r1']['episoden'])} Episoden "
            f"gegen {_tsd(aP['n']['r1']['ohne'])} Tage ohne Zeichen)") in ein_(rt_a)
       and ("5,0 % -> " + " / ".join(p_text(auf_zahl(0.05, k_, [aP["f"]["r1"], aP["f"]["r7"]], [aP["anteil"]["BTC"]["r1"], aP["anteil"]["BTC"]["r7"]]))
                                     for k_ in (0, 1, 2)) + " · 10 % -> ") in ein_(rt_a)
       and (f"BTC erhöht ab {p_text(AP['coins']['BTC']['q']['0.8'])} · hoch ab {p_text(AP['coins']['BTC']['q']['0.95'])} (97,5.: "
            f"{p_text(AP['coins']['BTC']['q']['0.975'])}, 99.: {p_text(AP['coins']['BTC']['q']['0.99'])}) · Eintritte in „hoch“ "
            f"{_tsd(AP['coins']['BTC']['alarme']['eintritte'])} (") in ein_(rt_a)
       and ("Nachweis vor dem echten Lauf" in rt_a) == bool(AUF_NACHWEIS)
       and "   Kein Urteil: Probe-Grund" in rueckblick_text(dict(rbP, auf={"e2": {"regeln": ["r1"], "besteht": False, "grund": "Probe-Grund"}}))
       and "Folge: Die nachkalibrierte Zahl ist die Grundlage; die Karte zeigt sie mit Aufschlag (nächster Abschnitt)." in ein_(rt_a)
       and "== Eingestellte Schwelle „hoch“: 97,5. Perzentil -- 48 Stunden, mit Aufschlag (beschreibend" in ein_(rt_a)
       and f"BTC hoch ab {p_text(AP['coins']['BTC']['q']['0.975'])} · Eintritte in „hoch“ {_tsd(AP['coins']['BTC']['alarme_wahl']['0.975']['eintritte'])} (" in ein_(rt_a)
       and "Eingestellte Schwelle" not in rt_v and "Eingestellte Schwelle" not in rt_o and rt_v == rt_o
       and max(len(z_) for z_ in rt_a.split("\n")) <= ZEILE_MAX and max(len(z_) for z_ in rt_n.split("\n")) <= ZEILE_MAX
       and "— nicht bestätigt: " in ein_(rt_n).split("G2a · 48 Stunden:")[1].split("Vergleich auf")[0]
       and "Folge: Die Karte bleibt bei der nachkalibrierten Zahl ohne Aufschlag. Ein anstehendes belegtes Zeichen steht als Hinweis da." in ein_(rt_n)
       and "Folge: Die Karte zeigt die nachkalibrierte Zahl; Stufen, Schwellen und Alarm gelten für sie." in ein_(rt_n).split("G2k · 48 Stunden:")[1]
       and "== Eingestellte Schwelle „hoch“: 97,5. Perzentil -- 48 Stunden, nachkalibriert (beschreibend" in ein_(rt_n)
       and f"BTC hoch ab {p_text(EP['kal']['e2']['coins']['BTC']['q']['0.975'])} ·" in ein_(rt_n).split("Eingestellte Schwelle")[1]
       and wahl_zeilen(rbP, None) == [] and wahl_zeilen(None, 0.975) == [] and wahl_zeilen(dict(rbP, auf={}), 0.975) == []
       and "-- 48 Stunden, Rohzahl (beschreibend" in wahl_zeilen(dict(rbP, anzeige={"e7": "roh", "e2": "roh"}), 0.975)[1]
       and f"hoch ab {p_text(EP['coins']['BTC']['e2']['q']['0.975'])} ·" in wahl_zeilen(dict(rbP, anzeige={"e7": "roh", "e2": "roh"}), 0.975)[2]
       and wahl_zeilen(rbP, 0.95) == []
       and wahl_zeilen(dict(rbP, auf={"e2": dict(rbP["auf"]["e2"], coins={"BTC": dict(rbP["auf"]["e2"]["coins"]["BTC"],
                                                                                        alarme_wahl={"0.95": rbP["auf"]["e2"]["coins"]["BTC"]["alarme"]})})}), 0.95) == []
       and len(wahl_zeilen(rbP, 0.99)) == 4 and "99. Perzentil" in wahl_zeilen(rbP, 0.99)[1]
       and nz_ == ("Nachweis vor dem echten Lauf (gemessen am 24.11.2026 auf erfundenen Reihen, je Fall 400; gezählt sind die Reihen, in denen "
                   "die Zahl ohne Aufschlag bestand): Tragen die Zeichen nichts, galt der Aufschlag in 2 von 240 Reihen (0,8 %). Trägt nur R1 "
                   "ein Chancenverhältnis von 2,3, in 20 von 250 (8,0 %). Tragen R1 und R7 je 2,5, in 122 von 244 (50,0 %). „Nicht bestätigt“ "
                   "heißt bei Zeichen dieser Stärke deshalb „nicht nachweisbar“ -- nicht „wirkt nicht“.")
       and auf_nachweis_zeilen({}) == [] and (AUF_NACHWEIS is None or len(auf_nachweis_zeilen()) >= 1),
       f"{len(rt_a.splitlines())} Zeilen, längste {max(len(z_) for z_ in rt_a.split(chr(10)))}; Nachweis: {nz_[:90]}")
    # 23.125 (Konzept 15.1): die Aufteilung je Coin und Zustand, beschreibend -- von Hand aus der Reihe mit Aufschlag nachgerechnet
    S19 = auf_reihe(tau_p, ci_p, pk_p, DP); T19 = O1["auf"]["e2"].get("aufteilung") or {}
    hand19 = {}
    for c_ in ("BTC", "ETH"):
        m_ = S19["auf"] & (ci_p == c_) & np.isfinite(pk_p) & np.isfinite(ja_p); n_ = int(m_.sum())
        zz_ = {}
        for k_, nm_ in ((0, "keins"), (1, "r1"), (2, "r7")):
            mk_ = m_ & (S19["z"] == k_)
            zz_[nm_] = (int(mk_.sum()), int(mk_.sum()) / n_, float(np.mean(pk_p[mk_])), float(np.mean(S19["p"][mk_])))
        ang_ = {"r1": float(np.mean(S19["pi"][0, m_])), "r7": float(np.mean(S19["pi"][1, m_]))}
        ang_["keins"] = 1.0 - ang_["r1"] - ang_["r7"]
        hand19[c_] = (n_, zz_, ang_)
    gleich19 = all(T19[c_]["n"] == hand19[c_][0] and all(T19[c_]["zustaende"][nm_]["n"] == hand19[c_][1][nm_][0]
                                                        and abs(T19[c_]["zustaende"][nm_]["anteil"] - hand19[c_][1][nm_][1]) < 1e-12
                                                        and abs(T19[c_]["zustaende"][nm_]["p_ohne"] - hand19[c_][1][nm_][2]) < 1e-12
                                                        and abs(T19[c_]["zustaende"][nm_]["p_mit"] - hand19[c_][1][nm_][3]) < 1e-12
                                                        and abs(T19[c_]["zustaende"][nm_]["angewandt"] - hand19[c_][2][nm_]) < 1e-12
                                                        for nm_ in ("keins", "r1", "r7"))
                   and abs(sum(T19[c_]["zustaende"][nm_]["anteil"] for nm_ in ("keins", "r1", "r7")) - 1.0) < 1e-12
                   and abs(T19[c_]["p_mit"] - float(np.mean(S19["p"][S19["auf"] & (ci_p == c_) & np.isfinite(pk_p) & np.isfinite(ja_p)]))) < 1e-12
                   for c_ in ("BTC", "ETH")) if set(T19) == {"BTC", "ETH"} else False
    zl19 = [z_ for z_ in rt_a.split("\n") if z_.startswith("        BTC  ") or z_.startswith("        ETH  ")]
    soll19 = (f"        BTC  {'R1 Kontenquote':<16} {_tsd(hand19['BTC'][1]['r1'][0]):>6} Ursprünge · {_de(hand19['BTC'][1]['r1'][1] * 100, 1)} % "
              f"(angewandt {_de(hand19['BTC'][2]['r1'] * 100, 1)} %) · {p_text(hand19['BTC'][1]['r1'][2])} -> {p_text(hand19['BTC'][1]['r1'][3])}")
    leer19 = auf_reihe(tau_p, ci_p, pk_p, None)
    ok("AU19 Debug 161, Aufteilung je Coin und Zustand (seit 23.125, beschreibend): an den Ursprüngen mit Aufschlag je Coin und Zustand die "
       "Zahl, ihr Anteil, der angewandte Anteil im Mittel („keins“ = 1 − Summe der Regeln), das Mittel der Zahl ohne und mit Aufschlag -- "
       "alles von Hand aus der Reihe nachgerechnet; die Anteile eines Coins ergeben zusammen 1; im Bericht je Coin drei Zeilen und eine "
       "Zeile „zusammen“; ohne Regeln bleibt die Reihe ohne Anteile und ohne Aufschlag",
       gleich19 and "Aufteilung (A4, beschreibend, seit 23.125)" in rt_a and soll19 in rt_a and len(zl19) == 8
       and sum(1 for z_ in zl19 if "zusammen" in z_) == 2 and not leer19["auf"].any() and np.isnan(leer19["pi"]).all()
       and aufteilung_zeilen({}) == [] and aufteilung_zeilen({"aufteilung": {}}) == [],
       f"BTC {hand19.get('BTC', ('?',))[0]} Ursprünge; {zl19[:1]}")
    import statistics
    nd = statistics.NormalDist()
    wz = welt_zahl(np.array([0.03, 0.03, 0.0, float("nan"), 0.03, 0.001, 0.5]), np.array([1.0, 1.35, 1.0, 1.0, 20.0, 1.0, 1.0]), 0.07, 2)
    W0 = auf_welt(112, 1.0); R0o = W0["ursprung"]; Rb = WP["R"]["BTC"]; evb = np.nonzero(np.asarray(Rb["ev"], dtype=bool))[0]
    an1 = lambda R_: sum(int(np.nansum(np.where(np.isin(R_[c_]["tau"] // TAG - 1 - 18262, np.nonzero(WP["R"][c_]["regeln"]["r1"][0])[0]), R_[c_]["ja2"], 0.0)))   # noqa: E731
                         for c_ in R_)
    kz_ = auf_nachweis_kurz(EP); kz0 = auf_nachweis_kurz({})
    Wk = auf_welt(112, 2.5, ("r1", "r7"), ursprung_tage=400); Rk_ = Wk["ursprung"]["BTC"]
    e_ = lambda b_, a_, o_=2.0, t_=100, d_=1e-4: {"basis": b_, "auf": a_, "g2a": a_, "besser": a_, "or": {"r1": o_, "r7": None}, "tage": {"r1": t_, "r7": 7},   # noqa: E731
                                                  "diff": d_, "p": 0.5}
    zl = auf_nachweis_zaehlen((("ohne", 1.0, ()), ("beide", 1.75, ("r1", "r7"))),
                              [e_(True, False, 1.0, 90, -1e-5), e_(False, False), e_(True, False, 1.4, 110), e_(True, True, 2.0), e_(True, True, 3.0), e_(False, True, 9.0)], 3)
    ok("AU17 die erfundene Welt der Messung (Abschnitt 14.6): Rohzahl von Hand -- Tagesschwankung 3 %, Schwelle 7 % in 2 Tagen: "
       "2 · Φ(ln 0,93 ÷ (0,03 · √2)) = 8,7 %; mit Faktor 1,35 kleiner; ohne Schwankung, ohne Wert oder mit einer Schwelle ab 100 % kein "
       "Wert; begrenzt auf 0,5 % bis 99,5 %. Je Auswertungstag ein Ursprung am FOLGETAG 00:00 UTC mit dem Ereignis dieses Tages; ohne "
       "Einpflanzen bleibt der Markt der Regel-Prüfung, mit Einpflanzen folgen auf Tage mit R1 mehr Ereignisse. Kurzform einer Welt und "
       "Zählung der Messung von Hand: gezählt werden nur Welten mit bestandener Grundlage (2 und 2 von je 3), davon mit geltendem "
       "Aufschlag 0 und 2; Median des Chancenverhältnisses 1,2 und 2,5. Mit 400 Ursprungstagen kommen die Ursprünge nur aus den letzten "
       "400 Tagen der Welt, Zustände und Faktoren weiter aus der ganzen Historie; die Messung nimmt so viele Tage wie der Rückblick auf "
       "dem Pi (1.681)",
       abs(wz[0] - 2.0 * nd.cdf(math.log(0.93) / (0.03 * math.sqrt(2.0)))) < 1e-12 and abs(wz[0] - 0.0872) < 5e-4 and wz[1] < wz[0]
       and abs(wz[1] - 2.0 * nd.cdf(math.log(1 - 0.07 * 1.35) / (0.03 * math.sqrt(2.0)))) < 1e-12 and np.isnan(wz[2:5]).all()
       and wz[5] == 0.005 and wz[6] > 0.5 and abs(welt_zahl(np.array([0.03]), np.array([1.0]), 0.10, 7)[0] - 2.0 * nd.cdf(math.log(0.9) / (0.03 * math.sqrt(7.0)))) < 1e-12
       and welt_zahl(np.array([5.0]), np.array([1.0]), 0.07, 2)[0] <= 0.995
       and sorted(RoP) == ["BTC", "ETH"] and np.array_equal(RoP["BTC"]["tau"], (18262 + evb + 1).astype(np.int64) * TAG) and int(evb[0]) >= 245
       and np.array_equal(RoP["BTC"]["ja2"][:-2], Rb["E"]["e2"][0][evb][:-2].astype(float)) and np.isnan(RoP["BTC"]["ja2"][-2:]).all()
       and np.array_equal(RoP["BTC"]["p2"], welt_zahl(Rb["sig"][evb], Rb["f1"][evb], 0.07, 2)) and np.array_equal(RoP["BTC"]["p2"], R0o["BTC"]["p2"])
       and np.array_equal(R0o["BTC"]["tau"], RoP["BTC"]["tau"]) and np.nansum(RoP["BTC"]["ja2"]) > np.nansum(R0o["BTC"]["ja2"])
       and an1(RoP) > 1.5 * an1(R0o) > 0 and WP["D"]["regeln"] == ["r1", "r7"] and W0["erg"]["auf"]["e2"].get("besteht") is False
       and kz_["basis"] is True and kz_["g2a"] is True and kz_["besser"] is True and kz_["auf"] is True and set(kz_["or"]) == {"r1", "r7"}
       and kz_["or"]["r1"] == aP["n"]["r1"]["or"] > 2 and kz_["tage"]["r7"] == aP["n"]["r7"]["tage"] and kz_["diff"] == bP["diff"] and kz_["p"] == bP["p"]
       and kz0 == {"basis": False, "g2a": False, "besser": False, "auf": False, "or": {}, "tage": {}, "diff": None, "p": None}
       and zl["welten"] == 3 and zl["ohne"]["basis"] == 2 and zl["ohne"]["auf"] == 0 and zl["ohne"]["diff_plus"] == 1 and abs(zl["ohne"]["or_median"]["r1"] - 1.2) < 1e-12
       and zl["ohne"]["tage_median"] == {"r1": 100.0, "r7": 7.0} and zl["ohne"]["or_median"]["r7"] is None and zl["ohne"]["pflanz"] == []
       and zl["beide"]["basis"] == 2 and zl["beide"]["auf"] == 2 and zl["beide"]["g2a"] == 2 and zl["beide"]["or_median"]["r1"] == 2.5
       and zl["beide"]["staerke"] == 1.75 and zl["beide"]["pflanz"] == ["r1", "r7"]
       and AUF_NACHWEIS_PLAN == (("ohne", 1.0, ()), ("r1", 1.75, ("r1",)), ("beide", 1.75, ("r1", "r7"))) and AUF_NACHWEIS_TAGE == 1681
       and np.array_equal(Rk_["tau"], RoP["BTC"]["tau"][-len(Rk_["tau"]):]) and len(Rk_["tau"]) == 400 and int(Rk_["tau"][0] // TAG) == 18262 + 2520 - 400 + 1
       and np.array_equal(Rk_["p2"], RoP["BTC"]["p2"][-400:]) and Wk["D"]["monate"].keys() == WP["D"]["monate"].keys()
       and all(Wk["D"]["monate"][m_]["f"] == WP["D"]["monate"][m_]["f"] for m_ in WP["D"]["monate"])
       and 0 < Wk["erg"]["urteil"]["e2"]["n_tage"] <= 398 < WP["erg"]["urteil"]["e2"]["n_tage"] and Wk["erg"]["urteil"]["e2"]["n"] <= 2 * 398,
       f"Rohzahl {wz[0]:.4f}; Ereignisse nach R1-Tagen {an1(RoP)} gegen {an1(R0o)} ohne Einpflanzen; Kurzform {kz_}; Zählung {zl['ohne']} {zl['beide']}")


def _proben_auf_karte(ok, jetzt: int) -> None:
    """Regel A in Karte, Stand, Debug 160 und Alarmtext (A6, A7)."""
    Lk = _probe_lauf(jetzt); rbA = _probe_rb_auf(jetzt); ZS = _probe_zeichen(jetzt)
    eb = lambda coin, f_, kurs_, rb_, z_, pz_=PZ_HOCH: ereignisse_bauen(coin, Lk, None, {"f": f_}, kurs_, True, jetzt, rb_, None, pz_, z_)   # noqa: E731
    Ea = eb("BTC", 1.0, 60000.0, rbA, ZS); Ek_ = eb("BTC", 1.0, 60000.0, _probe_rb_kal(jetzt), ZS)
    E0_ = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, k_btc=0)); Eu_ = eb("BTC", 1.0, 60000.0, rbA, None)
    E2_ = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, k_btc=2)); Ealt = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, alt_tage=3))
    Egr = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, alt_tage=2)); Ereg = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, regeln=("r1",)))
    Ebad = eb("BTC", 1.0, 60000.0, rbA, _probe_zeichen(jetzt, k_btc=3)); Ee = eb("ETH", 1.38, 2000.0, rbA, ZS); Eh = eb("HYPE", 1.2, 30.0, rbA, ZS)
    pk2 = Ek_["e2"]["p"]; oB = _o0_hand(pk2, 3.0, 0.5); pkE = eb("ETH", 1.38, 2000.0, _probe_rb_kal(jetzt), None)["e2"]["p"]; oEt = _o0_hand(pkE, 3.0, 0.2)
    ok("AU8 Karte nach Regel A6: Gilt der Aufschlag, zeigt die Karte für BTC mit anstehendem R1 die nachkalibrierte Zahl mit dem Faktor 3 "
       "auf die Chance (Gegenrechnung von Hand über die quadratische Gleichung), nennt die Zahl ohne Aufschlag und das Zeichen, und stuft "
       "mit den Schwellen der Zahl mit Aufschlag (hoch ab 45 %); ohne Zeichen liegt sie unter der Zahl ohne Aufschlag; steht nur R7 an (ohne "
       "Faktor), ebenso; ist der Stand der Zeichen unbekannt (keiner abgelegt, älter als zwei Tage, andere Regeln, unbrauchbare Nummer), "
       "bleibt die nachkalibrierte Zahl -- genau zwei Tage alt gilt noch; ETH rechnet mit seinem eigenen Anteil; HYPE hat keinen Aufschlag "
       "und behält Schwellen und Urteil der nachkalibrierten Zahl; die 7-Tage-Zahl bleibt, wie sie ohne Regel A wäre",
       abs(Ea["e2"]["p"] - 3 * oB / (1 + 3 * oB)) < 1e-9 and Ea["e2"]["p_ohne"] == pk2 and Ea["e2"]["p_roh"] == Ek_["e2"]["p_roh"] and Ea["e2"]["kal"] is True
       and Ea["e2"]["auf"] == {"k": 1, "regel": "r1", "tag": jetzt // TAG - 1, "grund": None, "name": "R1 Kontenquote"}
       and Ea["e2"]["s_hoch"] == 0.45 and Ea["e2"]["s_erhoeht"] == 0.30 and Ea["e2"]["stufe"] == "hoch" and Ea["e2"]["p"] > 0.45 > pk2 and Ek_["e2"]["s_hoch"] == 0.30
       and Ea["e2"]["grundrate"] == 0.031 and _drin("G2a (mit Aufschlag)", Ea["e2"]["urteil"]) and _drin("— besteht.", Ea["e2"]["urteil"])
       and _drin(f" · mit Aufschlag für R1 Kontenquote (ohne {p_text(pk2)}).", Ea["e2"]["satz"]) and _drin(f": {p_text(Ea['e2']['p'])} ", Ea["e2"]["satz"])
       and abs(E0_["e2"]["p"] - oB / (1 + oB)) < 1e-9 and E0_["e2"]["p"] < pk2 and E0_["e2"]["auf"]["k"] == 0 and E0_["e2"]["auf"]["name"] is None
       and _drin(f" · kein belegtes Zeichen an (ohne Aufschlag {p_text(pk2)}).", E0_["e2"]["satz"]) and E0_["e2"]["stufe"] == "normal"
       and abs(E2_["e2"]["p"] - E0_["e2"]["p"]) < 1e-12 and E2_["e2"]["auf"]["regel"] == "r7" and E2_["e2"]["auf"]["name"] == "R7 Druck-Index"
       and all(E_["e2"]["p"] == pk2 and E_["e2"]["auf"]["k"] == -1 and E_["e2"]["s_hoch"] == 0.45 and _drin("Stand der Zeichen unbekannt, ohne Aufschlag", E_["e2"]["satz"])
               for E_ in (Eu_, Ealt, Ereg, Ebad))
       and _drin("liegt noch nicht vor", Eu_["e2"]["auf"]["grund"]) and _drin("älter als zwei Tage", Ealt["e2"]["auf"]["grund"])
       and _drin("liegt noch nicht vor", Ereg["e2"]["auf"]["grund"]) and _drin("nicht bestimmbar", Ebad["e2"]["auf"]["grund"])
       and Egr["e2"]["p"] == Ea["e2"]["p"] and Egr["e2"]["auf"]["tag"] == jetzt // TAG - 2
       and abs(Ee["e2"]["p"] - oEt / (1 + oEt)) < 1e-9 and Ee["e2"]["auf"]["k"] == 0 and Ee["e2"]["s_hoch"] == 0.45
       and "auf" not in Eh["e2"] and "p_ohne" not in Eh["e2"] and Eh["e2"]["s_hoch"] == 0.30 and _drin("G2k (nachkalibriert)", Eh["e2"]["urteil"])
       and Ea["e7"] == Ek_["e7"] and "auf" not in Ea["e7"] and "auf" not in Ek_["e2"],
       f"{Ea['e2']['satz']} | {E0_['e2']['satz']} | {Eu_['e2']['satz']}")
    rbX = _probe_rb_auf(jetzt); rbX["auf"]["e2"]["urteil"] = dict(rbX["auf"]["e2"]["urteil"], besteht=False)
    rbY = _probe_rb_auf(jetzt); rbY["auf"]["e2"]["aktuell"]["anteil"].pop("BTC")
    rb7 = _probe_rb(jetzt); rb7["urteil"]["e7"] = dict(rb7["urteil"]["e7"], besteht=False, grund="Probe: Steigung 0,77")
    E7_ = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, rb7, None)
    ok("AU9 wann die Karte den Aufschlag NICHT nimmt, und der Satz zur 7-Tage-Zahl: Zeigt der Rückblick „nachkalibriert“ statt „mit "
       "Aufschlag“, ist der Aufschlag als nicht bestanden vermerkt, besteht sein Urteil nicht, fehlen die Regeln oder der Anteil des Coins, "
       "gibt es keinen Aufschlag. Eine 7-Tage-Zahl, die im Rückblick nicht bestätigt ist, trägt den Satz „Ein niedriger Wert ist keine "
       "Entwarnung.“ (Feld und Ende des Satzes); eine bestätigte und die 48-Stunden-Zahl tragen ihn nicht",
       auf_fuer(rbA, "BTC", "e2")["F"] == [3.0, None] and auf_fuer(rbA, "BTC", "e2")["PI"] == [0.5, 0.25] and auf_fuer(rbA, "ETH", "e2")["PI"] == [0.2, 0.0]
       and auf_fuer(rbA, "BTC", "e2")["r"]["q"]["0.95"] == 0.45 and auf_fuer(rbA, "BTC", "e2")["monat"] == 20758
       and auf_fuer(rbA, "HYPE", "e2") is None and auf_fuer(rbA, "BTC", "e7") is None and auf_fuer(None, "BTC", "e2") is None
       and auf_fuer(_probe_rb_kal(jetzt), "BTC", "e2") is None and auf_fuer(dict(rbA, anzeige={"e7": "kal", "e2": "kal"}), "BTC", "e2") is None
       and auf_fuer(_probe_rb_auf(jetzt, besteht=False), "BTC", "e2") is None and auf_fuer(rbX, "BTC", "e2") is None
       and auf_fuer(_probe_rb_auf(jetzt, regeln=[]), "BTC", "e2") is None and auf_fuer(rbY, "BTC", "e2") is None and auf_fuer(rbY, "ETH", "e2") is not None
       and "auf" not in eb("BTC", 1.0, 60000.0, rbX, ZS)["e2"] and eb("BTC", 1.0, 60000.0, rbX, ZS)["e2"]["p"] == pk2
       and E7_["e7"]["besteht"] is False and E7_["e7"]["hinweis"] == NIEDRIG_HINWEIS == "Ein niedriger Wert ist keine Entwarnung."
       and E7_["e7"]["satz"].endswith(". Ein niedriger Wert ist keine Entwarnung.") and "hinweis" not in E7_["e2"]
       and "hinweis" not in Ea["e7"] and "hinweis" not in Ea["e2"] and not _drin("Entwarnung", Ea["e7"]["satz"])
       and "hinweis" not in ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, None, None)["e7"], f"{E7_['e7']['satz']}")
    ZL = zeichen_lage
    rg2 = _probe_regeln(jetzt, belegt7=("r1",), belegt2=("r7", "r1"))
    grau_l = {k_: {"roh": None, "pz": None, "tag": None, "grau": "Probe"} for k_ in ("a3", "a4", "a7")}
    grau_k = {"a5": {"roh": None, "pz": None, "grau": "Probe"}, "a6": {"roh": None, "pz": None, "grau": "Probe"}}
    def st_(coin, rb_, z_, regeln_=rg2, f_=1.0, kurs_=60000.0):
        S_ = stand_bauen(coin, jetzt, kurs_, jetzt - 30, True, Lk, None, {"f": f_}, rb_, None, None, _probe_cockpit(), grau_l, grau_k, None, None, z_)
        regeln_anhaengen(S_, regeln_)
        return zeichen_anhaengen(S_, z_, jetzt, rb_)
    Sa = st_("BTC", rbA, ZS); Sn = st_("BTC", _probe_rb_kal(jetzt), ZS); Sx = st_("BTC", rbX, ZS); S0 = st_("ETH", rbA, ZS, f_=1.38, kurs_=2000.0)
    Su = st_("BTC", rbA, None); Sh_ = st_("HYPE", rbA, ZS, f_=1.2, kurs_=30.0); So = st_("BTC", rbA, ZS, regeln_=_probe_regeln(jetzt)); Sk0 = st_("BTC", rbA, ZS, regeln_=None)
    Ka = karte_bauen(Sa, dict(EINSTELLUNG_VORGABE), [], [], None, True, jetzt); tg_txt = _tag_txt(jetzt // TAG - 1)
    ta = "\n".join(_umbruch(stand_text(Sa, mit_urteil=False)))
    ok("AU10 Stand, Karte und Debug 160 mit belegten Zeichen (Regel A7): Der Stand trägt für die Coins des Urteils den Zustand der für "
       "48 Stunden belegten Zeichen in der Reihenfolge R1 … R7, mit dem Tag und einem Satz: steht eines an und gilt der Aufschlag -> „Das "
       "steckt in der 48-Stunden-Zahl“; gilt er nicht -> „Die 48-Stunden-Zahl enthält es nicht“ mit dem Grund (nicht bestanden / noch nicht "
       "geprüft); steht keines an und gilt der Aufschlag -> die Zahl liegt etwas tiefer; ohne Stand -> „kein Stand“ mit Grund. Ein Coin "
       "außerhalb des Urteils und ein Urteil ohne belegtes Zeichen für 48 Stunden haben keinen Satz. Die Karte nennt die große Zahl "
       "(48 Stunden) und erklärt den Aufschlag im Beleg nur, wenn eine Zahl ihn trägt; Debug 160 führt die 48-Stunden-Zahl zuerst und den "
       "Satz der Zeichen am Ende",
       Sa["zeichen"] == {"regeln": ["r1", "r7"], "k": 1, "regel": "r1", "tag": jetzt // TAG - 1, "in_zahl": True,
                         "text": f"Belegte Zeichen (R1 Kontenquote, R7 Druck-Index), Stand Tagesschluss {tg_txt}: R1 Kontenquote steht an. Das steckt in "
                                 "der 48-Stunden-Zahl (Aufschlag nach Regel A)."}
       and Sn["zeichen"]["in_zahl"] is False and Sn["zeichen"]["text"].endswith(
           "R1 Kontenquote steht an. Die 48-Stunden-Zahl enthält es nicht (der Aufschlag ist im Rückblick noch nicht geprüft).")
       and Sx["zeichen"]["text"].endswith("Die 48-Stunden-Zahl enthält es nicht (der Aufschlag hat den Rückblick nicht bestanden).")
       and S0["zeichen"]["k"] == 0 and S0["zeichen"]["text"].endswith(": keines steht an. Die 48-Stunden-Zahl liegt deshalb etwas unter der Zahl ohne Aufschlag.")
       and st_("ETH", _probe_rb_kal(jetzt), ZS, f_=1.38, kurs_=2000.0)["zeichen"]["text"].endswith(": keines steht an.")
       and Su["zeichen"]["k"] == -1 and Su["zeichen"]["text"] == ("Belegte Zeichen (R1 Kontenquote, R7 Druck-Index): kein Stand. Der Stand der Zeichen "
                                                                  "liegt noch nicht vor (der Takt holt ihn einmal am Tag).")
       and Sh_["zeichen"] is None and So["zeichen"] is None and Sk0["zeichen"] is None
       and "leit" not in Sa and Ka["leit"] == "e2" and Ka["leit_kurz"] == "48 Stunden" and Ka["beleg"].get("auf") == AUF_VERMERK and Ka["beleg"].get("kal") == KAL_VERMERK
       and "auf" not in karte_bauen(Sn, dict(EINSTELLUNG_VORGABE), [], [], None, True, jetzt)["beleg"] and json.dumps(_ohne_nan(Ka), allow_nan=False) is not None
       and Ka["ereignis"]["e2"]["auf"]["name"] == "R1 Kontenquote" and Ka["ereignis"]["e2"]["p_ohne_text"] == p_text(pk2)
       and 0 < ta.index("in 48 Stunden") < ta.index("in 7 Tagen") < ta.index("Belegte Zeichen (R1 Kontenquote") and ta.rstrip().endswith("(Aufschlag nach Regel A).")
       and max(len(z_) for z_ in ta.split("\n")) <= ZEILE_MAX and len(AUF_VERMERK) < 560 and "dritte Prüfung" in AUF_VERMERK and "BTC und ETH" in AUF_VERMERK,
       f"{Sa['zeichen']['text']} | {Su['zeichen']['text']}")
    ok("AU11 Lage der Zeichen an den Grenzen: Stand von gestern und von vorgestern gilt, drei Tage alt nicht; ohne Eintrag für den Coin, "
       "ohne Tag, mit anderen Regeln (auch in anderer Reihenfolge) oder mit einer Nummer außerhalb von 0 … Zahl der Regeln ist der Zustand "
       "unbekannt -- ein Wahrheitswert zählt nicht als Nummer; die Regel zur Nummer kommt aus der Reihenfolge",
       ZL(ZS, "BTC", jetzt, ["r1", "r7"]) == {"k": 1, "regel": "r1", "tag": jetzt // TAG - 1, "grund": None}
       and ZL(_probe_zeichen(jetzt, k_btc=2), "BTC", jetzt, ["r1", "r7"])["regel"] == "r7" and ZL(ZS, "ETH", jetzt, ["r1", "r7"])["k"] == 0
       and ZL(_probe_zeichen(jetzt, alt_tage=2), "BTC", jetzt, ["r1", "r7"])["k"] == 1 and ZL(_probe_zeichen(jetzt, alt_tage=3), "BTC", jetzt, ["r1", "r7"])["k"] == -1
       and ZL(_probe_zeichen(jetzt, alt_tage=3), "BTC", jetzt, ["r1", "r7"])["tag"] == jetzt // TAG - 3
       and all(ZL(z_, "BTC", jetzt, ["r1", "r7"])["k"] == -1 for z_ in (None, {}, "x", {"regeln": ["r1", "r7"], "coins": {}}, {"regeln": ["r1", "r7"], "coins": {"BTC": {"k": 1}}},
                                                                          _probe_zeichen(jetzt, regeln=("r7", "r1")), _probe_zeichen(jetzt, regeln=("r1",)),
                                                                          _probe_zeichen(jetzt, k_btc=3), _probe_zeichen(jetzt, k_btc=-1), _probe_zeichen(jetzt, k_btc=True),
                                                                          _probe_zeichen(jetzt, k_btc=None)))
       and ZL(ZS, "HYPE", jetzt, ["r1", "r7"])["k"] == -1 and ZL(ZS, "BTC", jetzt, [])["k"] == -1 and (AUF_ALT_TAGE, ZEICHEN_WIEDER_S) == (2, 3600))
    Mz, Ma = alarm_schritt(None, Sa, jetzt)
    m2 = next((m_ for m_ in Ma if m_.get("ereignis") == "e2" and m_.get("art") == "alarm"), {})
    m7 = next((m_ for m_ in Ma if m_.get("ereignis") == "e7" and m_.get("art") == "alarm"), {})
    m0 = meldung_bauen("alarm", S0, "e2"); mu = meldung_bauen("alarm", Su, "e2"); mn = meldung_bauen("alarm", Sn, "e2")
    ok("AU12 Alarm mit Aufschlag (Regel A6: der Alarm kann von einem Zeichen kommen): Der Text des Alarms nennt nach der Zahl, dass der "
       "Aufschlag für das anstehende Warnzeichen darin steckt, und die Zahl ohne ihn; Titel und Ansage bleiben; steht kein Zeichen an, ist "
       "der Stand unbekannt oder gilt kein Aufschlag, steht nichts dazu; die Meldung zur 7-Tage-Zahl nennt keinen Aufschlag",
       (Mz.get("e2") or {}).get("hoch") is True and m2.get("titel") == "Risikoradar BTC: Risiko hoch" and m2.get("prio") == 5
       and _drin(f"−7 % in 48 Stunden: {p_text(Sa['ereignis']['e2']['p'])} (üblich 3,1 %). Darin der Aufschlag für das Warnzeichen R1 Kontenquote "
                 f"(ohne ihn {p_text(Sa['ereignis']['e2']['p_ohne'])}). ", m2.get("text"))
       and _drin("Risikoradar. Bitcoin. Risiko hoch.", m2.get("ansage")) and not _drin("Aufschlag", m2.get("ansage"))
       and not _drin("Aufschlag", m7.get("text")) and _drin("in 7 Tagen", m7.get("text"))
       and not _drin("Aufschlag", m0["text"]) and not _drin("Aufschlag", mu["text"]) and not _drin("Aufschlag", mn["text"])
       and _drin("in 48 Stunden", m0["text"]) and len(m2.get("text") or "") < 400, f"{m2.get('text')}")


def _proben_u314(ok, jetzt: int) -> None:
    """23.127 (U314): Die Stufe „hoch“ nennt die eingestellte Schwelle -- Beleg der Karte und Kopf von Debug 160."""
    import inspect
    import tempfile
    S_ = {"meldungen": [], "alle": [], "ereignis": {}}
    k95 = karte_bauen(dict(S_), {"pz": 0.95}, [], [], None, True, jetzt)["beleg"]["zahl"]
    k975 = karte_bauen(dict(S_), {"pz": 0.975}, [], [], None, True, jetzt)["beleg"]["zahl"]
    k99 = karte_bauen(dict(S_), {"pz": 0.99}, [], [], None, True, jetzt)["beleg"]["zahl"]
    tmp = tempfile.mkdtemp(prefix="rd_u314_")
    try:
        db_ = os.path.join(tmp, "hl_liq.db")
        einstellung_setzen(db_, {"pz": 0.975})
        t975 = text(db_, coins=("BTC",), jetzt=jetzt).split("\n")
        einstellung_setzen(db_, {"pz": 0.99})
        t99 = text(db_, coins=("BTC",), jetzt=jetzt).split("\n")
        k975_ = " ".join(" ".join(t975[1:6]).split()); k99_ = " ".join(" ".join(t99[1:6]).split())      # Kopf über mehrere Zeilen umbrochen
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    q_t = inspect.getsource(text)
    ok("AU13 (23.127, U314) Stufe „hoch“ nennt die eingestellte Schwelle: im Beleg der Karte und im Kopf von Debug 160 „riskanteste 5 %“, "
       "„2,5 %“ oder „1 %“ je nach Wahl (95., 97,5., 99. Perzentil); nirgends mehr fest „hoch = riskanteste 5 %“",
       "hoch = riskanteste 5 % (eingestellt: 95. Perzentil" in k95 and "hoch = riskanteste 2,5 % (eingestellt: 97,5. Perzentil" in k975
       and "hoch = riskanteste 1 % (eingestellt: 99. Perzentil" in k99 and pz_kurz(None) == "1 %" and pz_kurz(0.975) == "2,5 %"
       and t975[1].startswith("Zwei Zahlen je Coin:") and "hoch = riskanteste 2,5 % (eingestellt: 97,5. Perzentil" in k975_
       and "hoch = riskanteste 1 % (eingestellt: 99. Perzentil" in k99_ and "hoch (riskanteste 5 %)" not in q_t
       and q_t.index("einst = einstellung_lesen(con)") < q_t.index('a("Zwei Zahlen je Coin:'),
       f"{k975_[:200]}")


def _proben_auf_takt(ok, jetzt: int) -> None:
    """Regel A im Takt (A7): Stand der Zeichen holen, Ablage, Rückblick nach neuem Urteil, Zugriff des Rückblicks auf die Regel-Prüfung."""
    import calendar
    import contextlib
    import io
    import shutil
    import tempfile
    rg2 = _probe_regeln(jetzt, belegt7=("r1",), belegt2=("r7", "r1"))
    tmpa = tempfile.mkdtemp(prefix="hl_radar_au_"); alt_db = os.environ.get("HL_RADAR_DB"); alt_start = _TAKT["letzter_rueckblick_start"]
    try:
        dba = os.path.join(tmpa, "hl_liq.db"); os.environ["HL_RADAR_DB"] = os.path.join(tmpa, "radar.db"); cona = verbinden(pfad(dba))
        hol = []; coins_1 = {"BTC": {"tag": jetzt // TAG - 1, "k": 2, "regel": "r7"}, "ETH": {"tag": jetzt // TAG - 1, "k": 0, "regel": None}}
        antwort = {"v": {"regeln": ["r1", "r7"], "coins": coins_1}}

        def holen_(db, belegt):
            hol.append((db, list(belegt)))
            if antwort["v"] == "fehler":
                raise OSError("Probe: hebel.db nicht lesbar")
            return antwort["v"]
        r0 = zeichen_pflegen(dba, cona, jetzt, holen_)
        meta_setzen(cona, "regeln", _probe_regeln(jetzt)); r1 = zeichen_pflegen(dba, cona, jetzt, holen_)
        meta_setzen(cona, "regeln", rg2); r2 = zeichen_pflegen(dba, cona, jetzt, holen_); z2 = meta(cona, "zeichen")
        r3 = zeichen_pflegen(dba, cona, jetzt + 7200, holen_)                              # frisch: Tagesschluss von gestern
        j2 = (jetzt // TAG + 1) * TAG + 60                                                 # nächster Tag 00:01 UTC: der Stand ist von vorgestern
        antwort["v"] = "fehler"; r4 = zeichen_pflegen(dba, cona, j2, holen_); z4 = meta(cona, "zeichen")
        r5 = zeichen_pflegen(dba, cona, j2 + ZEICHEN_WIEDER_S - 1, holen_)                 # binnen einer Stunde kein neuer Versuch
        antwort["v"] = {"regeln": ["r1", "r7"], "coins": {"BTC": {"tag": j2 // TAG - 1, "k": 0, "regel": None}}}
        r6 = zeichen_pflegen(dba, cona, j2 + ZEICHEN_WIEDER_S, holen_); z6 = meta(cona, "zeichen")
        meta_setzen(cona, "regeln", _probe_regeln(jetzt, belegt2=("r1",))); r7 = zeichen_pflegen(dba, cona, j2 + 2 * ZEICHEN_WIEDER_S, holen_)
        z7 = meta(cona, "zeichen")
        antwort["v"] = {"regeln": ["r1"], "coins": {}}; r8 = zeichen_pflegen(dba, cona, j2 + 3 * ZEICHEN_WIEDER_S, holen_)
        r9 = zeichen_pflegen(dba, cona, j2 + 4 * ZEICHEN_WIEDER_S, holen_)
        zs6 = zeichen_stand_satz(z6); zs4 = zeichen_stand_satz(z4)
        ok("AU13 Regel A7, der Takt holt den Stand der Zeichen: ohne abgelegtes Urteil oder ohne belegtes Zeichen für 48 Stunden nichts; sonst "
           "einmal, mit den belegten Regeln in der Reihenfolge R1 … R7, und legt ihn mit Zeit ab; solange jeder Coin den Tagesschluss von "
           "gestern hat, kein neuer Abruf; nach dem Tageswechsel wieder; scheitert der Abruf, bleibt der alte Stand mit dem Fehler stehen und "
           "der nächste Versuch kommt frühestens nach einer Stunde (eine Sekunde davor nicht); wechseln die belegten Regeln, wird neu geholt; "
           "ein Stand ohne einen einzigen Coin gilt nicht als frisch. "
           "Der Satz für Debug 160 nennt Zeit, Stand je Coin und einen gescheiterten Versuch",
           (r0, r1, r2, r3, r4, r5, r6, r7) == (False, False, True, False, True, False, True, True)
           and hol == [(dba, ["r1", "r7"])] * 3 + [(dba, ["r1"])] * 3 and (r8, r9) == (True, True)
           and z2 == {"ts": jetzt, "versuch": jetzt, "regeln": ["r1", "r7"], "coins": coins_1}
           and z4 == dict(z2, versuch=j2, fehler="OSError: Probe: hebel.db nicht lesbar")
           and z6 == {"ts": j2 + ZEICHEN_WIEDER_S, "versuch": j2 + ZEICHEN_WIEDER_S, "regeln": ["r1", "r7"],
                      "coins": {"BTC": {"tag": j2 // TAG - 1, "k": 0, "regel": None}}}
           and (z7 or {}).get("regeln") == ["r1", "r7"] and (z7 or {}).get("ts") == j2 + 2 * ZEICHEN_WIEDER_S
           and zs6 == f"Belegte Zeichen für den Aufschlag (Regel A): Stand geholt {_dt(j2 + ZEICHEN_WIEDER_S)} -- BTC {_tag_txt(j2 // TAG - 1)}: keines."
           and zs4 == (f"Belegte Zeichen für den Aufschlag (Regel A): Stand geholt {_dt(jetzt)} -- BTC {_tag_txt(jetzt // TAG - 1)}: R7 Druck-Index · "
                       f"ETH {_tag_txt(jetzt // TAG - 1)}: keines · letzter Versuch {_dt(j2)} gescheitert: OSError: Probe: hebel.db nicht lesbar.")
           and zeichen_stand_satz(None) is None and zeichen_stand_satz({}) is None
           and zeichen_stand_satz({"versuch": j2, "fehler": "X"}) == ("Belegte Zeichen für den Aufschlag (Regel A): Stand geholt noch nie · letzter "
                                                                    f"Versuch {_dt(j2)} gescheitert: X."),
           f"{(r0, r1, r2, r3, r4, r5, r6, r7)} {hol} {zs4}")
        # ---- der Takt ruft den Abruf, hält seine Dauer fest und legt Zustand und Zahl ohne Aufschlag mit ab
        cona.execute("DELETE FROM rd_meta WHERE k IN ('regeln', 'zeichen')")
        zf = {"rufe": [], "art": True}

        def zeichen_f(db, con_, j_):
            zf["rufe"].append((db, j_))
            if zf["art"] == "fehler":
                raise RuntimeError("Probe-Zeichen")
            return zf["art"]

        def stand_a(db, coin, jetzt_, gemeinsam=None, rb=None, zust=None, einst=None, con_r=None):
            S_ = _probe_stand(coin, jetzt_, 0.1, "normal", p2=0.28, stufe2="normal")
            if coin == "BTC":
                S_["ereignis"]["e2"].update({"kal": True, "p_roh": 0.3, "p_ohne": 0.2,
                                             "auf": {"k": 1, "regel": "r1", "tag": jetzt_ // TAG - 1, "grund": None, "name": "R1 Kontenquote"}})
            if coin == "ETH":
                S_["ereignis"]["e2"].update({"kal": True, "p_roh": 0.3, "p_ohne": 0.28,
                                             "auf": {"k": -1, "regel": None, "tag": None, "grund": "Probe", "name": None}})
            return S_
        kw_ = dict(http_fn=lambda *a_, **k_: (200, "ok"), push_ein={"thema": None}, starte_rb=lambda d_: False, stand_fn=stand_a,
                   gemeinsam_fn=lambda db_, j_: {}, zeichen_fn=zeichen_f)
        ta1 = takt_schritt(dba, cona, jetzt, **kw_); takt_a1 = meta(cona, "takt") or {}
        za = {c_: json.loads(j_) for c_, j_ in cona.execute("SELECT coin, json FROM rd_stand")}
        zf["art"] = False; ta2 = takt_schritt(dba, cona, jetzt + 300, **kw_); takt_a2 = meta(cona, "takt") or {}
        zf["art"] = "fehler"; ta3 = takt_schritt(dba, cona, jetzt + 600, **kw_); takt_a3 = meta(cona, "takt") or {}
        ok("AU14 Takt mit Regel A: Jeder Schritt ruft den Abruf des Stands der Zeichen; wurde geholt, steht die Dauer im Ergebnis und im "
           "festgehaltenen Schritt (Debug 160 nennt sie: „dazu … s für den Stand der Zeichen“), sonst nicht; ein Fehler dabei steht bei den "
           "Fehlern des Schritts und hält die Coins nicht auf. Ablage je Stunde: Trägt eine Zahl den Aufschlag, stehen ihr Zustand (auch "
           "„unbekannt“ = −1) und die Zahl ohne Aufschlag mit im abgelegten Stand; bei einem Coin ohne Aufschlag steht nichts dazu",
           zf["rufe"] == [(dba, jetzt), (dba, jetzt + 300), (dba, jetzt + 600)]
           and isinstance(ta1.get("zeichen_s"), float) and ta1["zeichen_s"] >= 0 and takt_a1.get("zeichen_s") == ta1["zeichen_s"]
           and "zeichen_s" not in ta2 and "zeichen_s" not in takt_a2 and "zeichen_s" not in ta3 and "zeichen_s" not in takt_a3
           and ta3["fehler"] == ["Zeichen: RuntimeError: Probe-Zeichen"] == takt_a3.get("fehler") and ta3["coins"] == ["BTC"] and ta1["fehler"] == []
           and ta1["abgelegt"] == 5 and (za.get("BTC") or {}).get("ohne") == {"e2": 0.2} and (za.get("BTC") or {}).get("zeichen") == {"e2": 1}
           and (za.get("BTC") or {}).get("roh") == {"e2": 0.3} and (za.get("BTC") or {}).get("e", {}).get("e2", {}).get("p") == 0.28
           and (za.get("ETH") or {}).get("zeichen") == {"e2": -1} and (za.get("ETH") or {}).get("ohne") == {"e2": 0.28}
           and "ohne" not in (za.get("HYPE") or {"ohne": 1}) and "zeichen" not in (za.get("HYPE") or {"zeichen": 1})
           and takt_dauer_satz({"dauer_s": 12.34, "coins": ["BTC"], "zeit": {}, "zeichen_s": 3.21}) == (" · der Schritt dauerte 12,3 s für 1 Coin, dazu "
                                                                                                      "3,2 s für den Stand der Zeichen")
           and takt_dauer_satz({"dauer_s": 12.34, "coins": ["BTC"], "zeit": {}}) == " · der Schritt dauerte 12,3 s für 1 Coin",
           f"{ta1.get('zeichen_s')} {ta3.get('fehler')} {za.get('BTC')}")
        # ---- Rückblick neu, sobald das Urteil der Regeln jünger ist als er
        m0 = calendar.timegm((2027, 1, 1, 0, 0, 0)); rbv = lambda st: {"version": VERSION_MODUL, "stand": st}   # noqa: E731
        gestartet = []
        kw2 = dict(kw_, starte_rb=lambda d_: gestartet.append(d_) or True, zeichen_fn=lambda *a_: False)
        meta_setzen(cona, "rueckblick", rbv(jetzt - 7200)); meta_setzen(cona, "regeln", _probe_regeln(jetzt))      # Urteil von jetzt − 1 h
        _TAKT["letzter_rueckblick_start"] = 0.0; tb1 = takt_schritt(dba, cona, jetzt + 900, **kw2)
        meta_setzen(cona, "rueckblick", rbv(jetzt - 1800))                                                          # Rückblick jünger als das Urteil
        _TAKT["letzter_rueckblick_start"] = 0.0; tb2 = takt_schritt(dba, cona, jetzt + 1200, **kw2)
        ok("AU15 Rückblick nach neuem Urteil der Regeln: Ist das abgelegte Urteil jünger als der Rückblick dieser Fassung, ist der Rückblick "
           "fällig (er prüft dann den Aufschlag) -- gleich alt oder älter nicht, ohne Urteil nicht, und nicht binnen 6 Stunden nach dem "
           "letzten Start; der Takt gibt die Zeit des Urteils weiter und startet ihn",
           rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0, m0 + 1) is True and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0, m0) is False
           and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0, m0 - 1) is False and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0, None) is False
           and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0) is False and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, m0 + 5 * 86400 - 3600, m0 + 1) is False
           and rueckblick_faellig({"version": "alt", "stand": m0}, m0 + 5 * 86400, 0, m0 - 1) is True and rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0, "x") is False
           and tb1["rueckblick_gestartet"] is True and tb2["rueckblick_gestartet"] is False and gestartet == [dba],
           f"{tb1.get('rueckblick_gestartet')} {tb2.get('rueckblick_gestartet')} {gestartet}")
        # ---- der Rückblick holt Zustände und Faktoren aus der Regel-Prüfung
        lad = []

        def laden_(db, belegt, tag):
            lad.append((db, list(belegt), tag))
            return {"regeln": list(belegt), "coins": {}, "monate": {}}

        def laden_kaputt(db, belegt, tag):
            raise KeyError("Probe")
        cona.execute("DELETE FROM rd_meta WHERE k='regeln'"); h0 = auf_holen(dba, jetzt, laden_)
        meta_setzen(cona, "regeln", _probe_regeln(jetzt)); h1 = auf_holen(dba, jetzt, laden_)
        meta_setzen(cona, "regeln", rg2); h2 = auf_holen(dba, jetzt, laden_); h3 = auf_holen(dba, jetzt, laden_kaputt)
        meta_setzen(cona, "einstellung", dict(EINSTELLUNG_VORGABE, pz=0.975)); pz_a = eingestellte_schwelle(dba)
        meta_setzen(cona, "rueckblick", _probe_rb_auf(jetzt))
        puf = io.StringIO()
        with contextlib.redirect_stdout(puf):
            rc_r = haupt(["--rueckblick-text", "--db", dba])
        t161 = " ".join(puf.getvalue().split())
        ok("AU16 der Rückblick und die Regel-Prüfung: Ohne abgelegtes Urteil oder ohne belegtes Zeichen für 48 Stunden gibt es keine Daten "
           "für den Aufschlag, sondern den Grund; sonst werden Zustände und Faktoren für die belegten Regeln in der Reihenfolge R1 … R7 und "
           "den Tag des Laufs geholt; ein Fehler dabei wird zum Grund (der Rückblick der Zahlen läuft weiter). Debug 161 liest die im "
           "Dashboard eingestellte Schwelle „hoch“ und nennt die Alarm-Zählung dafür; die Wörter für 95., 97,5. und 99. Perzentil",
           h0 == {"grund": "Die Prüfung der Regeln hat noch kein Urteil abgelegt (Debug 163)."}
           and h1 == {"grund": "Für die 48-Stunden-Zahl ist kein Zeichen belegt (Debug 163)."}
           and h2 == {"regeln": ["r1", "r7"], "coins": {}, "monate": {}} and lad == [(dba, ["r1", "r7"], jetzt // TAG)]
           and h3 == {"grund": "Die Tagesreihen der Regel-Prüfung sind nicht lesbar (KeyError: 'Probe')."}
           and pz_a == 0.975
           and (pz_wort(0.95), pz_wort(0.975), pz_wort(0.99), pz_wort(None)) == ("95.", "97,5.", "99.", "99.")
           and rc_r == 0 and "== Aufschlag für belegte Zeichen (Regel A" in t161
           and "== Eingestellte Schwelle „hoch“: 97,5. Perzentil -- 48 Stunden, mit Aufschlag (beschreibend" in t161
           and "BTC hoch ab 50 % · Eintritte in „hoch“ 5 (1,4 je Jahr), danach kam das Ereignis 3-mal · von 40 Ereignis-Episoden bei 5 auf „hoch“" in t161
           and "ETH hoch ab" not in t161.split("Eingestellte Schwelle")[1].split("Lesart:")[0],
           f"{h0} {h1} {h3} {pz_a} {len(t161)} Zeichen")
        meta_setzen(cona, "zeichen", _probe_zeichen(jetzt)); meta_setzen(cona, "einstellung", dict(EINSTELLUNG_VORGABE))
        Sd = stand(dba, "BTC", jetzt); Se = stand(dba, "ETH", jetzt); Sy = stand(dba, "HYPE", jetzt)
        t160 = " ".join(text(dba, ("BTC",), jetzt).split())
        rufe_r = []; alt_h, alt_w = globals()["auf_holen"], globals()["rueckblick_auswerten"]
        try:
            globals()["auf_holen"] = lambda db_, j_, laden=None: rufe_r.append(("holen", db_, j_)) or {"grund": "Probe: geholt"}
            globals()["rueckblick_auswerten"] = lambda R_, bis_tag=None, auf=None: rufe_r.append(("auswerten", bis_tag, auf)) or {"urteil": {}, "coins": {}, "ohne": {}}
            erg_r = _rueckblick_rechnen(dba, lambda *a_: None, jetzt, False)
        finally:
            globals()["auf_holen"], globals()["rueckblick_auswerten"] = alt_h, alt_w
        rb_m = _probe_rb_auf(jetzt)
        rb_m["urteil"]["e7"] = dict(rb_m["urteil"]["e7"], besteht=False, grund="Probe: Steigung 0,77")
        rb_m["kal"]["e7"]["urteil"] = dict(rb_m["kal"]["e7"]["urteil"], besteht=False, grund="Probe: Steigung 0,76"); rb_m["kal"]["e7"]["besteht"] = False
        rb_m["anzeige"]["e7"] = "roh"; rb_m["auf"]["e2"] = {"regeln": ["r1", "r7"], "besteht": False, "grund": "Probe: kein Urteil der Regeln"}
        rb_m["anzeige"]["e2"] = "kal"; meta_setzen(cona, "rueckblick", rb_m)
        t160m = " ".join(text(dba, ("BTC",), jetzt).split()); meta_setzen(cona, "rueckblick", _probe_rb_auf(jetzt))
        ok("AU18 aus der Datei: stand() liest den abgelegten Stand der Zeichen und den Rückblick mit Aufschlag -- BTC trägt den Zustand "
           "(R1 steht an) an der 48-Stunden-Zahl und den Satz der Zeichen, ETH „keines“, HYPE nichts; Debug 160 nennt im Kopf zuerst das "
           "Urteil der 48-Stunden-Zahl, dann das der 7-Tage-Zahl, das Urteil G2a mit der Folge und wann der Stand der Zeichen geholt "
           "wurde. Der Lauf des Rückblicks holt Zustände und Faktoren mit seiner Zeit und gibt sie mit dem Tag des Laufs an die Auswertung "
           "weiter. Der Kopf nennt die 48-Stunden-Zahl zuerst; ist die 7-Tage-Zahl roh und nachkalibriert nicht bestätigt, steht „Die Zahl "
           "bleibt matt, ohne Stufe und ohne Alarm.“ (nicht mehr „Die Karte bleibt bei der Rohzahl“); hat der Aufschlag kein Urteil, steht "
           "sein Grund",
           Sd.get("ok") is True and ((Sd.get("ereignis") or {}).get("e2") or {}).get("auf", {}).get("k") == 1 and (Sd.get("zeichen") or {}).get("k") == 1
           and _drin("R1 Kontenquote steht an. Das steckt in der 48-Stunden-Zahl (Aufschlag nach Regel A).", (Sd.get("zeichen") or {}).get("text"))
           and ((Se.get("ereignis") or {}).get("e2") or {}).get("auf", {}).get("k") == 0 and (Se.get("zeichen") or {}).get("k") == 0
           and Sy.get("zeichen") is None and "auf" not in ((Sy.get("ereignis") or {}).get("e2") or {"auf": 1})
           and 0 < t160.find("Rückblick G2 vom ") < t160.find("Rückblick G7 vom ") < t160.find("Rückblick G2k (nachkalibriert) vom ")
           < t160.find("Rückblick G7k (nachkalibriert) vom ") < t160.find("Rückblick G2a (mit Aufschlag) vom ") < t160.find("Warnzeichen R1 bis R7 (Debug 163")
           and "— besteht. Die Karte zeigt die Zahl mit Aufschlag." in t160
           and f"Belegte Zeichen für den Aufschlag (Regel A): Stand geholt {_dt(jetzt - 600)} -- BTC {_tag_txt(jetzt // TAG - 1)}: R1 Kontenquote · ETH" in t160
           and rufe_r == [("holen", dba, jetzt), ("auswerten", jetzt // TAG, {"grund": "Probe: geholt"})] and erg_r.get("version") == VERSION_MODUL
           and t160.startswith("★ Risikoradar (U307)") and "Zwei Zahlen je Coin: −7 % · Faktor in 48 Stunden (in der Karte groß) und −10 % · Faktor in 7 Tagen" in t160
           and "Probe: Steigung 0,76 Die Zahl bleibt matt, ohne Stufe und ohne Alarm." in t160m.replace(". Die Zahl", " Die Zahl")
           and "Aufschlag (Regel A): kein Urteil -- Probe: kein Urteil der Regeln" in t160m and "Rückblick G2a" not in t160m,
           f"{(Sd.get('zeichen') or {}).get('text')} | {rufe_r}")
        cona.close()
    finally:
        _TAKT["letzter_rueckblick_start"] = alt_start
        if alt_db is None:
            os.environ.pop("HL_RADAR_DB", None)
        else:
            os.environ["HL_RADAR_DB"] = alt_db
        shutil.rmtree(tmpa, ignore_errors=True)


PROBEN_AUF = (_proben_auf_rechnen, _proben_auf_welt, _proben_auf_karte, _proben_auf_takt, _proben_u314)      # 23.127: U314


# ================================================================================================ Selbsttest (ohne Netz)

def _drin(teil: str, text) -> bool:
    """„teil in text“ für die Proben -- ohne Ausnahme, wenn der Text fehlt (None): Die Probe soll dann scheitern, nicht abbrechen."""
    return isinstance(text, str) and teil in text


def _probe_lauf(jetzt: int, alter_s: int = 600, mit2: bool = True) -> dict:
    """Abgelegte Verteilung in der Form von hl_ausblick.lauf_quantile: laufendes Tief als gerade Linie über dem Raster."""
    n = 199
    h = {"7": {"hoch": [0.003 + 0.0015 * i for i in range(n)], "tief": [-0.300 + 0.0015 * i for i in range(n)]},
         "14": {"hoch": [0.004 + 0.002 * i for i in range(n)], "tief": [-0.400 + 0.002 * i for i in range(n)]}}
    if mit2:
        h["2"] = {"hoch": [0.001 + 0.0006 * i for i in range(n)], "tief": [-0.1200 + 0.0006 * i for i in range(n)]}
    return {"anker": jetzt - alter_s, "p0": 60000.0, "erzeugt": jetzt - alter_s + 60, "n": 3000, "h": h}


def _probe_rb(jetzt: int) -> dict:
    """Rückblick in der abgelegten Form: G7 besteht, G2 nicht; Schwellen für BTC und ETH."""
    q7 = {"0.8": 0.50, "0.9": 0.58, "0.95": 0.64, "0.975": 0.70, "0.99": 0.80}
    q2 = {"0.8": 0.30, "0.9": 0.50, "0.95": 0.70, "0.975": 0.80, "0.99": 0.90}
    return {"stand": jetzt - 7200, "version": VERSION_MODUL,
            "urteil": {"e7": {"besteht": True, "n": 8000, "n_tage": 1700, "n_ereignisse": 700, "skill": 0.061, "p": 0.001, "steigung": 0.95,
                              "niveau": 1.04, "grund": None},
                       "e2": {"besteht": False, "n": 8000, "n_tage": 1700, "n_ereignisse": 300, "skill": 0.004, "p": 0.31, "steigung": 0.9,
                              "niveau": 1.1, "grund": "die Zahl trifft nicht belegbar besser als die Grundrate (Skill +0,4 %, p 0,310; verlangt ist p unter 0,05)"}},
            "coins": {"BTC": {"e7": {"n": 1700, "grundrate": 0.09, "q": q7, "niveau": 1.37}, "e2": {"n": 1700, "grundrate": 0.031, "q": q2, "niveau": 1.0}},
                      "ETH": {"e7": {"n": 1700, "grundrate": 0.12, "q": q7, "niveau": 0.7}, "e2": {"n": 1700, "grundrate": 0.04, "q": q2, "niveau": 1.0}}}}


def _probe_cockpit(konten=3.45, konten_pz=0.9722, oi_pz=0.51, wochenende="aus", termin="aus", aktien="aus", jetzt=1_795_000_000) -> dict:
    """Antwort des Cockpits in der Form von hl_cockpit.bauen, nur die Teile, die das Radar liest."""
    pzn = lambda v: None if v is None else int(v * 100 + 1e-9)             # noqa: E731 -- wie hl_cockpit.pz_zahl: die Perzentilzahl, abgeschnitten
    return {"messwerte": [{"key": "oi", "wert": 97074.0, "pz": oi_pz, "pz_n": pzn(oi_pz), "stand": jetzt - 60, "text": "97.074 BTC"},
                          {"key": "konten", "wert": konten, "pz": konten_pz, "pz_n": pzn(konten_pz), "stand": jetzt - 120,
                           "text": "—" if konten is None else f"{konten:.2f}".replace(".", ",")},
                          {"key": "funding_hl", "wert": 0.000011, "pz": 0.29, "pz_n": 29, "text": "+0,0011 %/h"}],
            "lampen": [{"key": "hebel", "zustand": "hinweis" if (konten or 0) >= 3 else "aus", "wert": "3,45 ≥ 3"},
                       {"key": "termin", "zustand": termin, "wert": "Arbeitsmarktbericht"}, {"key": "wochenende", "zustand": wochenende, "wert": "Sa"},
                       {"key": "aktien", "zustand": aktien, "wert": "S&P −2,6 %"}, {"key": "schwankung", "zustand": "hinweis", "wert": "80. Perzentil"}]}


def _probe_stand(coin: str, jetzt: int, p7, stufe7: str, p2=0.02, stufe2: str = "normal", konten=2.0) -> dict:
    """Stand eines Coins in der Form von stand(), für die Proben des Alarms und des Takts."""
    e = lambda key, p, st, x, frist: {"key": key, "p": p, "stufe": st, "x": x, "x_text": x_text(x), "frist": frist, "p_text": p_text(p) if p is not None else "—",  # noqa: E731
                                     "grundrate": 0.09 if key == "e7" else 0.031}
    return {"ok": True, "coin": coin, "jetzt": jetzt, "kurs": {"px": 60000.0, "ts": jetzt - 30, "frisch": True},
            "ereignis": {"e7": e("e7", p7, stufe7, 0.10, "7 Tagen"), "e2": e("e2", p2, stufe2, 0.07, "48 Stunden")},
            "achsen": [{"key": "a1", "name": "Positionierung", "wert": 97.0}, {"key": "a7", "name": "Schwankung", "wert": 80.0},
                       {"key": "a2", "name": "Hebel-Menge", "wert": 51.0}, {"key": "a3", "name": "Preis des Hebels", "wert": None}],
            "index": {"wert": 62.0}, "warnzeichen": {"aktiv": konten >= 3 if konten is not None else None, "wert": konten},
            "a5_roh": 1.5, "a6_roh": 4.0e6}


def _probe_rb_kal(jetzt: int, anz7: str = "kal", anz2: str = "kal", **kw) -> dict:
    """Rückblick der Probe mit Regel K: für beide Zahlen eine bestandene nachkalibrierte Fassung (kw ändert einzelne Einträge)."""
    q7k = {"0.8": 0.40, "0.9": 0.47, "0.95": 0.52, "0.975": 0.60, "0.99": 0.70}; q2k = {"0.8": 0.20, "0.9": 0.26, "0.95": 0.30, "0.975": 0.35, "0.99": 0.40}
    uk_ = {"besteht": True, "n": 6000, "n_tage": 1300, "n_ereignisse": 600, "skill": 0.07, "p": 0.001, "steigung": 1.02, "niveau": 1.0, "grund": None}
    r_ = _probe_rb(jetzt)
    r_["kal"] = {"e7": {"urteil": dict(uk_), "aktuell": {"monat": 20758, "a": -0.3, "b": 0.7, "n_tage": 1600, "n_ereignisse": 800}, "besteht": True,
                        "coins": {"BTC": {"n": 1300, "grundrate": 0.08, "q": q7k, "niveau": 1.0}}},
                 "e2": {"urteil": dict(uk_), "aktuell": {"monat": 20758, "a": -0.2, "b": 0.8, "n_tage": 1600, "n_ereignisse": 400}, "besteht": True,
                        "coins": {"BTC": {"n": 1300, "grundrate": 0.03, "q": q2k, "niveau": 1.0}}}}
    r_["anzeige"] = {"e7": anz7, "e2": anz2}
    for k_, v_ in kw.items():
        r_["kal"][k_].update(v_)
    return r_


def _probe_regeln(jetzt: int, belegt7=("r1", "r7"), belegt2=(), fassung: int | None = None, voll: bool = True) -> dict:
    """Abgelegtes Urteil der Regeln in der Form, in der hl_radar_regeln es in radar.db schreibt (nur die Felder, die das Radar liest)."""
    def tafel(belegt):
        return {f"r{i}": {"belegt": f"r{i}" in belegt, "pruefbar": i != 6, "mh": 1.8 if f"r{i}" in belegt else 1.0, "p_holm": 0.01 if f"r{i}" in belegt else 0.6}
                for i in range(1, 8)}
    return {"fassung": REGELN_FASSUNG if fassung is None else fassung, "vollstaendig": voll, "ts": jetzt - 3600, "coins": ["BTC", "ETH"],
            "tests": {"e7": tafel(belegt7), "e2": tafel(belegt2)}}


def _probe_nutzlast(jetzt: int, coin: str = "BTC", mit_rb: bool = True, konten=3.45, meldungen: list | None = None, kal: bool = False,
                    regeln: dict | None = None, auf: bool = False, zeichen: dict | None = None) -> dict:
    """Antwort der Karte von Hand, in der Form von nutzlast(): alle acht Achsen (A7 und A5 mit Wert), G7 besteht, G2 nicht.
    kal=True: beide Zahlen nachkalibriert (Regel K). regeln: abgelegtes Urteil der Regeln (sonst „noch nicht geprüft“).
    auf=True (23.124): wie auf dem Pi -- die 48-Stunden-Zahl gilt mit Aufschlag (Regel A), die 7-Tage-Zahl ist nicht bestätigt (roh und
    nachkalibriert); zeichen: der abgelegte Stand der belegten Zeichen (Vorgabe: bei BTC steht R1 an, bei ETH keines)."""
    n_ = 420; tg = np.arange(20350, 20350 + n_)
    cc = 100.0 * np.exp(np.cumsum(np.where(np.arange(n_) % 2 == 0, 0.02, -0.02) * np.where(np.arange(n_) >= n_ - 20, 1.5, 1.0)))
    K_ = {"tag": tg, "c": cc, "pv": np.full(n_, 1000.0), "pt": np.full(n_, 520.0), "stag": tg, "sv": np.full(n_, 500.0), "st": np.full(n_, 240.0)}
    K_["st"][-7:] = 200.0
    f_ts = np.array([int(t) * TAG + h * 3600 for t in tg for h in (0, 8, 16)]); f_rate = np.full(len(f_ts), 0.0001); f_rate[-21:] = 0.0004
    LA = lange_achsen_aus(lange_reihen(K_, f_ts, f_rate), int(tg[-1]) + 1)
    zl = [(57000.0, "long", 5e6, 3), (59999.0, "long", 2e6, 2), (61000.0, "short", 8e6, 2)]
    KA = kurze_achsen({"ts": jetzt - 600, "zeilen": zl, "fehlt": [], "abdeckung": {"anteil": 0.29}}, 60000.0, True,
                      {"usd": 3.5e6, "n": 700, "stunden": [1e6 + 1e4 * i for i in range(300)], "fehlt": None, "schritt": 100.0}, [0.1 * i for i in range(A5_MIN)], jetzt)
    f = {"f": 1.0} if coin == "BTC" else {"f": 1.38}
    einst = {"push": True, "coins": ["BTC"], "pz": 0.95}
    rb_ = (_probe_rb_kal(jetzt) if kal else _probe_rb(jetzt)) if mit_rb else None
    if auf:
        rb_ = _probe_rb_auf(jetzt)
        rb_["urteil"]["e7"] = dict(rb_["urteil"]["e7"], besteht=False, grund="Steigung 0,77 außerhalb von 0,8 bis 1,2 (die Zahl schlägt zu stark aus)")
        rb_["kal"]["e7"]["urteil"] = dict(rb_["kal"]["e7"]["urteil"], besteht=False, grund="Steigung 0,76 außerhalb von 0,8 bis 1,2 (die Zahl schlägt zu stark aus)")
        rb_["kal"]["e7"]["besteht"] = False; rb_["anzeige"]["e7"] = "roh"
        zeichen = _probe_zeichen(jetzt) if zeichen is None else zeichen
    S = stand_bauen(coin, jetzt, 60000.0 if coin == "BTC" else 2000.0, jetzt - 30, True, _probe_lauf(jetzt), None, f, rb_,
                    {}, einst, _probe_cockpit(konten=konten, konten_pz=0.9722 if konten is not None else None, termin="hinweis", jetzt=jetzt), LA, KA, None,
                    None, zeichen)
    regeln_anhaengen(S, regeln)
    zeichen_anhaengen(S, zeichen, jetzt, rb_)
    alle = [{"coin": c, "p": (S["ereignis"][LEIT]["p"] if c == coin else None), "p_text": (S["ereignis"][LEIT]["p_text"] if c == coin else "—"),
             "stufe": (S["ereignis"][LEIT]["stufe"] if c == coin else "ohne"), "stufe_wort": STUFEN_WORT[S["ereignis"][LEIT]["stufe"] if c == coin else "ohne"],
             "ts": jetzt if c == coin else None} for c in COINS]
    return karte_bauen(S, einst, meldungen or [], alle, {"ts": jetzt - 120}, True, jetzt)


def _kleine_welt(verz: str, jetzt: int) -> str:
    """
    Kleine Welt aus echten Dateien für die Proben E1 bis E9 (alles erzeugt, keine echten Kurse): hebel.db mit 420 Tagesschlüssen für
    BTC und ETH (ETH mit doppelter Schwankung; Spot nur für ETH, in den letzten 7 Tagen mit schwächerer Nachfrage), swing.db mit
    Funding (in den letzten 7 Tagen doppelt so hoch; an einem Tag fehlt einem Spot-Paar die Taker-Angabe), ausblick.db mit der abgelegten Verteilung für beide und einer Rechnung mit Trend
    für ETH, die Hauptdatenbank mit dem Orderbuch (5-s-Tabelle für die letzten 300 Stunden, Minutentabelle für ältere) und radar.db
    mit 340 eigenen Stundenwerten der Liquidations-Nähe. -> Pfad der Hauptdatenbank
    """
    import hl_ausblick as AU
    import hl_hebel as HB
    import hl_swing as SW
    db = os.path.join(verz, "hl_liq.db")
    heute = jetzt // TAG; st = jetzt // 3600
    hb = HB.verbinden(os.path.join(verz, "hebel.db"))
    zeilen = []
    for coin, amp in (("BTC", 0.01), ("ETH", 0.02)):
        c = 100.0
        for i in range(420, 0, -1):
            tag = heute - i
            c *= math.exp((amp if tag % 2 == 0 else -amp) * (1.5 if i <= 30 else 1.0))
            zeilen.append(("um", coin + "USDT", tag, c, c, c, c, 10.0, 1000.0, 520.0, 100))
            if coin == "ETH":
                for q, vol in (("USDT", 400.0), ("FDUSD", 100.0)):
                    tk = None if (i == 200 and q == "FDUSD") else vol * (0.48 if i <= 7 else 0.52)   # Tag −200: ein Paar ohne Taker-Angabe
                    zeilen.append(("spot", coin + q, tag, c, c, c, c, 1.0, vol, tk, 10))
    HB._schreiben(hb, "INSERT OR REPLACE INTO hb_kerzen VALUES (?,?,?,?,?,?,?,?,?,?,?)", zeilen); hb.close()
    sw = SW.verbinden(os.path.join(verz, "swing.db"))
    SW._schreiben(sw, "INSERT OR REPLACE INTO sw_funding VALUES (?,?,?)",
                  [(coin, (heute - i) * TAG + h * 3600, 0.0002 if i <= 7 else 0.0001) for coin in ("BTC", "ETH") for i in range(420, 0, -1) for h in (0, 8, 16)])
    sw.close()
    ac = AU.verbinden(os.path.join(verz, "ausblick.db"))
    L = _probe_lauf(jetzt)
    AU.meta_setzen(ac, {"lauf": json.dumps({"version": AU.LAUF_VERSION, "raster": list(AU.LAUF_Q), "coins": {"BTC": L, "ETH": L}})})
    AU._tx(ac, lambda: ac.execute("INSERT OR REPLACE INTO au_prognose VALUES (?,?,?,?,?)",
                                  ("ETH", L["anker"], L["erzeugt"], "stuendlich", json.dumps({"coin": "ETH", "anker": L["anker"], "richtung": {"mhat": {"7": 0.12}}}))))
    AU._tx(ac, lambda: ac.execute("INSERT OR REPLACE INTO au_prognose VALUES (?,?,?,?,?)",
                                  ("BTC", L["anker"] - 3600, L["erzeugt"] - 3600, "stuendlich", json.dumps({"coin": "BTC", "anker": L["anker"] - 3600, "richtung": {"mhat": {"7": 0.3}}}))))
    ac.close()
    hc = sqlite3.connect(db)                                              # 23.125 (U311): die Tiefe bis −1 % aus book_tiefe (Spalten wie im Recorder)
    hc.execute("CREATE TABLE book_tiefe (ts INTEGER, coin TEXT, nsig INTEGER, schritt REAL, mitte REAL, bid_1 REAL, ask_1 REAL, stufen_b INTEGER, "
               "stufen_a INTEGER, voll INTEGER, PRIMARY KEY (ts, coin)) WITHOUT ROWID")
    zt = lambda ts, coin, b1, voll=3, schritt=100.0: (int(ts), coin, 3, schritt, 60000.0, float(b1), 1.0, 20, 20, voll)   # noqa: E731
    roh = []
    for k in range(2, 301):                                               # Stunden st−2 … st−300: je zwei Zeilen um den Stundenwert 1 Mio. + 10.000 · k
        roh += [zt((st - k) * 3600 + 60, "BTC", 1e6 + 1e4 * k - 1000), zt((st - k) * 3600 + 3000, "BTC", 1e6 + 1e4 * k + 1000),
                zt((st - k) * 3600 + 60, "ETH", 7e5, schritt=1.0)]
    roh += [zt((st - k) * 3600 + 1200, "BTC", 9e9, voll=2) for k in (10, 50)]   # Gebote nicht bis −1 % vollständig: zählen nicht
    roh += [zt(jetzt - 3600 + 60 * i, "BTC", 2.0e6) for i in range(1, 41)]   # die letzten 60 Minuten: 40 vollständige Zeilen zu 2,0 Mio.
    roh += [zt(jetzt - 3600, "BTC", 2.0e6), zt(jetzt - 1801, "BTC", 0.0), zt(jetzt + 5, "BTC", 9e9, schritt=10.0),   # genau 60 min alt, ohne Gebot,
            zt(jetzt - 1799, "BTC", 9e9, voll=0)]                                                                    # in der Zukunft, unvollständig: nicht
    roh += [zt(jetzt - 3600 + 600 * i, "ETH", 7e5, schritt=1.0) for i in range(1, 6)]   # ETH: nur fünf Zeilen in der letzten Stunde
    roh += [zt((st - 30 * 24 - 5) * 3600, "BTC", 9e9)]                    # älter als 30 Tage: zählt nicht
    hc.executemany("INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)", roh)
    hc.commit(); hc.close()
    rc = verbinden(os.path.join(verz, "radar.db"))
    rc.executemany("INSERT OR REPLACE INTO rd_stand (stunde, coin, ts, p7, p2, idx, a5, a6, json) VALUES (?,?,?,?,?,?,?,?,?)",
                   [(st - i - 1, "BTC", (st - i - 1) * 3600, None, None, None, i / 10, None, "{}") for i in range(340)]
                   + [(st - 401 - i, "BTC", (st - 401 - i) * 3600, None, None, None, 99.0, None, "{}") for i in range(20)])   # vor „tiefe_ab“
    meta_setzen(rc, "tiefe_ab", st - 400)                                 # 23.125: der eigene Verlauf von A5 zählt ab hier (die 20 älteren nicht)
    rc.close()
    return db


def selbsttest(verbose: bool = True) -> bool:
    import contextlib
    import io
    import shutil
    import tempfile
    import hl_ausblick as AU
    erg = []

    def ok(name, bed, info=""):
        erg.append(bool(bed))
        if verbose or not bed:
            print(("  ok   " if bed else "  FEHLER  ") + name + (f"  {info}" if info else ""), flush=True)

    print("hl_radar -- Selbsttest (Risikoradar: Zahlen, Faktor, Grundrisiko, Achsen, Alarm, Push an einen nachgebauten Server, Rückblick; ohne Netz)", flush=True)
    jetzt = 1_795_000_000 // 300 * 300                                   # fester Zeitpunkt (19.11.2026), Viertelstunde
    alt_env = {k: os.environ.get(k) for k in ("HL_RADAR_DB",)}
    tmp = tempfile.mkdtemp(prefix="hl_radar_test_")
    try:
        # ---------------------------------------------------------------- Zahlen
        ok("Z1 Zahlen: kaufmännisch gerundet (32,5 -> 33; 0,125 -> 0,13), deutsches Format, eine gerundete Null ohne Vorzeichen",
           _de(32.5, 0) == "33" and _de(0.125, 2) == "0,13" and _de(-0.004, 2) == "0,00" and _de(-0.006, 2) == "−0,01" and _de(1234567.8, 1) == "1.234.567,8"
           and _de(2.5, 0, True) == "+3" and _de(None) == "—" and _de(float("nan")) == "—", f"{_de(32.5, 0)} {_de(-0.004, 2)} {_de(1234567.8, 1)}")
        ok("Z2 Wahrscheinlichkeit: unter 10 % mit einer Stelle, sonst ganzzahlig; die Ränder des Rasters als Schranke",
           p_text(0.0049) == "unter 0,5 %" and p_text(0.005) == "0,5 %" and p_text(0.0994) == "9,9 %" and p_text(0.0995) == "10 %"
           and p_text(0.325) == "33 %" and p_text(0.995) == "100 %" and p_text(0.9951) == "über 99,5 %" and p_text(0.3, "unter") == "unter 0,5 %"
           and p_text(0.3, "ueber") == "über 99,5 %" and p_text(None) == "—" and p_text(0.3, "fehlt") == "—",
           f"{p_text(0.0995)} {p_text(0.325)} {p_text(0.995)}")
        ok("Z3 Abstand der Schwelle: 10 % · 13,8 % · 9,7 % (7 % · 1,38 = 9,66 %)",
           x_text(0.10) == "10 %" and x_text(0.10 * 1.38) == "13,8 %" and x_text(0.07 * 1.38) == "9,7 %" and x_text(0.07) == "7 %" and x_text(None) == "—",
           f"{x_text(0.138)} {x_text(0.0966)}")
        ok("Z4 Monatserster: 19.11.2026 -> 01.11.2026; der Erste selbst; Jahreswechsel",
           monatserster(20776) == calendar.timegm((2026, 11, 1, 0, 0, 0)) // TAG and monatserster(calendar.timegm((2026, 11, 1, 0, 0, 0)) // TAG) == monatserster(20776)
           and monatserster(calendar.timegm((2027, 1, 1, 0, 0, 0)) // TAG - 1) == calendar.timegm((2026, 12, 1, 0, 0, 0)) // TAG, str(monatserster(20776)))
        r_ = [float(i % 10) for i in range(360)]
        ok("Z5 Perzentil gegen die Stellen davor: Mittelrang (gleiche zählen halb), mindestens 180 Werte, nicht alle gleich; nur die 365 Stellen davor zählen",
           pz_davor(r_ + [4.0], 360) == 0.45 and pz_davor(r_ + [9.5], 360) == 1.0 and pz_davor(r_ + [-1.0], 360) == 0.0
           and pz_davor(r_[:179] + [4.0], 179) is None and pz_davor(r_[:180] + [4.0], 180) is not None and pz_davor([2.0] * 360 + [2.0], 360) is None
           and pz_davor(r_ + [float("nan")], 360) is None and pz_davor(r_, 360) is None
           and pz_davor([100.0] * 40 + r_ + [50.0], 400) == 360 / 365
           and pz_unter(4.0, r_, 240) == 0.45 and pz_unter(4.0, r_[:239], 240) is None, f"{pz_davor(r_ + [4.0], 360)} {pz_davor([100.0] * 40 + r_ + [50.0], 400)}")
        lz = _umbruch(["   " + "Wort " * 60, "kurz"])
        ok("Z6 Berichte: keine Zeile über 150 Zeichen; Folgezeilen eingerückt; der Text bleibt vollständig",
           all(len(z) <= ZEILE_MAX for z in lz) and len(lz) == 4 and lz[-1] == "kurz" and lz[1].startswith("     Wort") and not lz[1].startswith("      ")
           and " ".join(" ".join(lz[:3]).split()) == " ".join(("Wort " * 60).split()), f"{[len(z) for z in lz]}")

        # ---------------------------------------------------------------- Faktor
        tage = list(range(20000, 20400)); rb_ = {t: (0.02 if t % 2 else -0.02) for t in tage}
        st = 20400
        f3 = faktor_rechnen("XMR", {t: 3 * v for t, v in rb_.items()}, rb_, st)
        f1 = faktor_rechnen("ETH", dict(rb_), rb_, st)
        fr = faktor_rechnen("PAX", {t: 0.5 * v for t, v in rb_.items()}, rb_, st)
        fk = faktor_rechnen("HYPE", {t: 2 * v for t, v in rb_.items() if t >= st - 179}, rb_, st)
        fg = faktor_rechnen("HYPE", {t: 2 * v for t, v in rb_.items() if t >= st - 180}, rb_, st)
        rand = dict(rb_); rand[st] = 9.0; rand[st - 366] = 9.0            # der Stichtag selbst und ein Tag vor dem Fenster zählen nicht
        fw = faktor_rechnen("ZEC", {t: 1.385 * v for t, v in rand.items()}, rand, st)
        ok("F1 Faktor: Schwankung 3-mal so groß -> 3,00; gleich -> 1,00; ruhiger -> 1,00 (Untergrenze); BTC immer 1",
           f3["f"] == 3.0 and f3["n"] == 365 and f1["f"] == 1.0 and fr["f"] == 1.0 and abs(fr["roh"] - 0.5) < 1e-12
           and faktor_rechnen("BTC", None, None, st) == {"f": 1.0, "n": None, "stichtag": st, "grund": None}, f"{f3} {fr}")
        ok("F2 Faktor: unter 180 gemeinsamen Tagen keiner (mit Grund und Zahl), mit 180 einer; ohne Reihen keiner",
           fk["f"] is None and fk["n"] == 179 and "179 gemeinsame Tage" in fk["grund"] and fg["f"] == 2.0 and fg["n"] == 180
           and faktor_rechnen("ETH", None, rb_, st)["f"] is None and faktor_rechnen("ETH", rb_, {}, st)["f"] is None, f"{fk}")
        ok("F3 Faktor: Fenster sind die 365 Tage vor dem Monatsersten (der Erste selbst und ältere Tage zählen nicht); auf zwei Stellen, 5 nach oben",
           fw["n"] == 365 and fw["f"] == 1.39 and abs(fw["roh"] - 1.385) < 1e-9, f"{fw}")
        ok("F4 Tagesrenditen: nur wenn der Tag und der Vortag einen Schluss haben (eine Lücke gibt keine Rendite über zwei Tage)",
           _renditen_je_tag([10, 11, 13, 14], [100.0, 110.0, 121.0, 133.1]) == {11: math.log(1.1), 14: math.log(133.1 / 121.0)}
           and _renditen_je_tag([10, 11], [100.0, float("nan")]) == {} and _renditen_je_tag([10, 11], [0.0, 5.0]) == {})

        # ---------------------------------------------------------------- Grundrisiko und Stufe
        L = _probe_lauf(jetzt); RB = _probe_rb(jetzt)
        soll7 = 0.005 + ((math.log(0.9) + 0.300) / 0.0015) * 0.005; soll2 = 0.005 + ((math.log(0.93) + 0.1200) / 0.0006) * 0.005
        E = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        ok("G1 Grundrisiko BTC: p7 und p2 aus der abgelegten Verteilung, von Hand nachgerechnet; Schwelle 10 % und 7 % als Kurs",
           abs(E["e7"]["p"] - soll7) < 1e-9 and abs(E["e2"]["p"] - soll2) < 1e-9 and E["e7"]["x"] == 0.10 and E["e2"]["x"] == 0.07
           and abs(E["e7"]["kurs_schwelle"] - 54000.0) < 1e-6 and abs(E["e2"]["kurs_schwelle"] - 55800.0) < 1e-6 and E["e7"]["lage"] == "innen",
           f"{E['e7']['p']:.6f} gegen {soll7:.6f}; {E['e2']['p']:.6f} gegen {soll2:.6f}")
        pa, la = AU.erreichen_aus_lauf(L["h"], math.log(0.9), 7)
        ok("G2 dieselbe Quelle wie der Kurs-Rechner: p7 für BTC ist hl_ausblick.erreichen_aus_lauf am Abstand −10 % über 7 Tage",
           E["e7"]["p"] == float(pa) and la == "innen")
        Ee = ereignisse_bauen("ETH", L, None, {"f": 1.38}, 2000.0, True, jetzt, RB, {})
        s7e = 0.005 + ((math.log(1 - 0.138) + 0.300) / 0.0015) * 0.005
        ok("G3 anderer Coin: Schwelle = 10 % · Faktor (13,8 %) und 7 % · Faktor (9,7 %), Zahl am größeren Abstand kleiner",
           abs(Ee["e7"]["p"] - s7e) < 1e-9 and Ee["e7"]["x_text"] == "13,8 %" and Ee["e2"]["x_text"] == "9,7 %" and Ee["e7"]["p"] < E["e7"]["p"]
           and abs(Ee["e7"]["kurs_schwelle"] - 2000.0 * (1 - 0.138)) < 1e-9, f"{Ee['e7']['p']:.6f} gegen {s7e:.6f}")
        Ealt = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, False, jetzt, RB, {})
        Eal = ereignisse_bauen("BTC", _probe_lauf(jetzt, FRISCH_AUSBLICK_S + 1), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Egr = ereignisse_bauen("BTC", _probe_lauf(jetzt, FRISCH_AUSBLICK_S), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eo2 = ereignisse_bauen("BTC", _probe_lauf(jetzt, mit2=False), None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eol = ereignisse_bauen("BTC", None, "Der Ausblick hat noch nicht gerechnet (ausblick.db fehlt).", {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Eof = ereignisse_bauen("HYPE", L, None, {"f": None, "grund": "Für HYPE gibt es erst 90 gemeinsame Tage mit BTC (gebraucht werden 180)."}, 30.0, True, jetzt, RB, {})
        Egf = ereignisse_bauen("XMR", L, None, {"f": 9.5}, 300.0, True, jetzt, RB, {})
        ok("G4 ohne frische Quelle steht der Grund statt der Zahl: alter Kurs; Rechnung des Ausblicks älter als 3 Stunden (genau 3 Stunden gilt noch); "
           "kein Ausblick; kein Faktor; Schwelle über 90 %",
           Ealt["e7"]["p"] is None and "Kein frischer Kurs" in Ealt["e7"]["fehlt"] and Ealt["e7"]["stufe"] == "ohne" and Ealt["e7"]["kurs_schwelle"] == 54000.0
           and Eal["e7"]["p"] is None and "älter als 3 Stunden" in Eal["e7"]["fehlt"] and Egr["e7"]["p"] is not None
           and Eol["e2"]["p"] is None and "ausblick.db fehlt" in Eol["e2"]["fehlt"]
           and Eof["e7"]["p"] is None and "90 gemeinsame Tage" in Eof["e7"]["fehlt"] and Eof["e7"]["x"] is None and "90 gemeinsame Tage" in Eof["e7"]["satz"]
           and Egf["e7"]["p"] is None and "95 %" in Egf["e7"]["fehlt"] and Egf["e2"]["p"] is not None, f"{Eal['e7']['fehlt']} | {Egf['e7']['fehlt']}")
        ok("G5 der Ausblick hat Tag 2 noch nicht abgelegt (Rechnung von vor dem Einspielen): die 48-Stunden-Zahl nennt den Grund, die 7-Tage-Zahl steht",
           Eo2["e2"]["p"] is None and "für 2 Tage noch nicht abgelegt" in Eo2["e2"]["fehlt"] and Eo2["e7"]["p"] is not None)
        Lr = _probe_lauf(jetzt); Lr["h"]["7"]["tief"] = [-0.05 + 0.0001 * i for i in range(199)]
        Er = ereignisse_bauen("BTC", Lr, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        Lu = _probe_lauf(jetzt); Lu["h"]["7"]["tief"] = [-0.9 + 0.001 * i for i in range(199)]
        Eu = ereignisse_bauen("BTC", Lu, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {})
        ok("G6 Ränder des Rasters: Schwelle tiefer als alle Szenarien -> „unter 0,5 %“; höher als alle -> „über 99,5 %“",
           Er["e7"]["lage"] == "unter" and Er["e7"]["p_text"] == "unter 0,5 %" and Eu["e7"]["lage"] == "ueber" and Eu["e7"]["p_text"] == "über 99,5 %",
           f"{Er['e7']['p_text']} {Eu['e7']['p_text']}")
        ok("S1 Stufe: unter der Schwelle „erhöht“ normal, ab ihr erhöht, ab „hoch“ hoch; ohne Zahl oder Schwelle keine Stufe",
           stufe_von(0.49, 0.5, 0.64, False) == "normal" and stufe_von(0.50, 0.5, 0.64, False) == "erhoeht" and stufe_von(0.6399, 0.5, 0.64, False) == "erhoeht"
           and stufe_von(0.64, 0.5, 0.64, False) == "hoch" and stufe_von(None, 0.5, 0.64, False) == "ohne" and stufe_von(0.7, 0.5, None, True) == "ohne"
           and stufe_von(0.3, None, 0.64, False) == "normal")
        ok("S2 „hoch“ endet erst unter 0,8 · Schwelle: 0,512 bleibt hoch, wenn es schon hoch war; 0,5119 nicht mehr; ohne Vorzustand ist 0,6 erhöht",
           stufe_von(0.512, 0.5, 0.64, True) == "hoch" and stufe_von(0.5119, 0.5, 0.64, True) == "erhoeht" and stufe_von(0.6, 0.5, 0.64, False) == "erhoeht"
           and abs(HYSTERESE * 0.64 - 0.512) < 1e-12)
        ok("S3 Stufe der Karte: G7 besteht -> Stufe aus den Schwellen des Coins (p7 0,654 ≥ 0,64: hoch); G2 besteht nicht -> keine Stufe, Satz „nicht bestätigt“",
           E["e7"]["stufe"] == "hoch" and E["e7"]["s_hoch"] == 0.64 and E["e7"]["s_erhoeht"] == 0.50 and E["e7"]["besteht"] is True
           and E["e2"]["stufe"] == "ohne" and E["e2"]["besteht"] is False and "im Rückblick nicht bestätigt" in E["e2"]["satz"] and E["e2"]["s_hoch"] is None
           and "Stufe hoch" in E["e7"]["satz"] and "üblich 9,0 %" in E["e7"]["satz"], E["e7"]["satz"])
        E975 = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {}, 0.975)
        E975h = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, RB, {"e7": {"hoch": True}}, 0.975)
        ok("S4 Schwelle verstellt (97,5. Perzentil = 0,70): p7 0,654 ist nur noch erhöht; war der Zustand schon hoch, bleibt er es (über 0,8 · 0,70)",
           E975["e7"]["stufe"] == "erhoeht" and E975["e7"]["s_hoch"] == 0.70 and E975h["e7"]["stufe"] == "hoch")
        Eor = ereignisse_bauen("BTC", L, None, {"f": 1.0}, 60000.0, True, jetzt, None, {})
        ok("S5 ohne Rückblick: Zahl ja, Stufe nein, Satz „noch nicht geprüft“, Hinweis auf Debug 161",
           Eor["e7"]["p"] is not None and Eor["e7"]["stufe"] == "ohne" and Eor["e7"]["besteht"] is None and "noch nicht geprüft" in Eor["e7"]["satz"]
           and "Debug 161" in Eor["e7"]["urteil"] and Eor["e7"]["grundrate"] is None and "üblich" not in Eor["e7"]["satz"])
        ok("S6 Hinweis zum Niveau je Coin: BTC lag im Rückblick beim 1,37-Fachen der Quote (kann zu hoch sein), ETH beim 0,70-Fachen (zu niedrig); im Band kein Hinweis",
           _drin("1,37-Fachen", E["e7"]["niveau"]) and _drin("zu hoch", E["e7"]["niveau"]) and _drin("0,70-Fachen", Ee["e7"]["niveau"])
           and _drin("zu niedrig", Ee["e7"]["niveau"])
           and E["e2"]["niveau"] is None and niveau_satz("BTC", 1.25) is None and niveau_satz("BTC", 0.8) is None and niveau_satz("BTC", 1.2501) is not None
           and niveau_satz("BTC", 0.7999) is not None and niveau_satz("BTC", None) is None, str(E["e7"]["niveau"]))
        RBo = _probe_rb(jetzt); RBo["coins"]["HYPE"] = {"e7": {"n": 60, "grundrate": None, "q": {}, "niveau": None}, "e2": {"n": 60, "grundrate": None, "q": {}, "niveau": None}}
        Eh = ereignisse_bauen("HYPE", L, None, {"f": 1.5}, 30.0, True, jetzt, RBo, {})
        ok("S9 G7 besteht, aber der Coin hat im Rückblick keine Schwellen (unter 100 Ursprünge): Zahl ja, keine Stufe -- der Satz sagt „ohne Stufe“ "
           "mit dem Grund und nicht „Stufe ohne Stufe“; ohne Grundrate steht kein „üblich“",
           Eh["e7"]["p"] is not None and Eh["e7"]["besteht"] is True and Eh["e7"]["stufe"] == "ohne" and Eh["e7"]["s_hoch"] is None and Eh["e7"]["schwellen"] is None
           and Eh["e7"]["satz"].endswith(": " + Eh["e7"]["p_text"] + " · ohne Stufe (für diesen Coin gibt es im Rückblick keine Schwellen).")
           and "Stufe ohne" not in Eh["e7"]["satz"] and "üblich" not in Eh["e7"]["satz"] and Eh["e7"]["x_text"] == "15 %", Eh["e7"]["satz"])
        St_ = stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, _probe_lauf(jetzt), None, {"f": 1.0}, None, {}, None, _probe_cockpit(jetzt=jetzt), {},
                          {"a5": {}, "a6": {}}, None, {"7": 0.12, "14": -0.3, "28": 0.004})
        ok("S8 Trend im Ausblick: enthält die jüngste Rechnung einen Trend (Tor offen), sagt der Stand es mit den Werten je Horizont; ohne Trend, "
           "mit lauter Nullen oder ohne Angabe steht nichts",
           St_["trend"] == ("Die jüngste Rechnung des Ausblicks enthält einen Trend (7 Tage +0,12 σ, 14 Tage −0,30 σ); er steckt in beiden Zahlen. "
                            "Der Rückblick des Radars hat die Zahlen ohne Trend geprüft.")
           and trend_satz(None) is None and trend_satz({}) is None and trend_satz({"7": 0.0, "14": None, "28": 0.004}) is None
           and stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, _probe_lauf(jetzt), None, {"f": 1.0}, None, {}, None, _probe_cockpit(jetzt=jetzt), {},
                           {"a5": {}, "a6": {}}, None)["trend"] is None and "enthält einen Trend" in "\n".join(stand_text(St_)), str(St_["trend"]))
        ok("S7 Satz zum Urteil: Zahl der Ursprünge, Tage, Ereignisse, Skill, p, Steigung, Niveau und das Wort „besteht“; sonst der Grund",
           "8.000 Ursprünge an 1.700 Tagen, 700 Ereignisse, Skill +6,1 % (p 0,001), Steigung 0,95, Niveau 1,04 — besteht." in E["e7"]["urteil"]
           and p_wert_text(0.0005) == "p unter 0,001" and p_wert_text(0.001) == "p 0,001" and p_wert_text(0.31) == "p 0,310" and p_wert_text(None) == "p —"
           and "(p unter 0,001)" in urteil_satz("e7", dict(RB["urteil"]["e7"], p=0.0004998), RB)
           and "nicht bestätigt: die Zahl trifft nicht belegbar besser" in E["e2"]["urteil"], E["e7"]["urteil"])

        # ---------------------------------------------------------------- lange Achsen
        n_ = 420; tg = np.arange(20350, 20350 + n_)
        cc = 100.0 * np.exp(np.cumsum(np.where(np.arange(n_) % 2 == 0, 0.02, -0.02)))
        K_ = {"tag": tg, "c": cc, "pv": np.full(n_, 1000.0), "pt": np.full(n_, 520.0), "stag": tg, "sv": np.full(n_, 500.0), "st": np.full(n_, 240.0)}
        f_ts = np.array([int(t) * TAG + h * 3600 for t in tg for h in (0, 8, 16)]); f_rate = np.full(len(f_ts), 0.0001)
        R_ = lange_reihen(K_, f_ts, f_rate)
        ok("A1 Tagesreihen von Hand: Funding 3 Zahlungen zu 0,01 % je Tag = 10,95 % im Jahr; Spot-Saldo (2·240 − 500) ÷ 500 = −4 %; Perp +4 %; σ = 2 %",
           abs(R_["fund7"][-1] - 0.0003 * 365) < 1e-12 and abs(R_["spot7"][-1] + 0.04) < 1e-12 and abs(R_["perp7"][-1] - 0.04) < 1e-12
           and abs(R_["sig"][-1] - 0.02) < 1e-9 and R_["tag0"] == 20350 and R_["n"] == n_, f"{R_['fund7'][-1]:.6f} {R_['spot7'][-1]:.4f} {R_['sig'][-1]:.5f}")
        K1 = {k: v.copy() for k, v in K_.items()}; K1["sv"][-3] = float("nan")
        K2 = {k: v.copy() for k, v in K_.items()}; K2["sv"][-3] = float("nan"); K2["st"][-5] = float("nan")
        K3 = {k: v.copy() for k, v in K_.items()}; K3["st"][-1] = 300.0
        ok("A2 sieben Tage mit Lücke: ein fehlender Tag zählt nicht mit (sechs genügen), zwei fehlende geben keinen Wert; ein Tag mit 60 % Taker-Kauf hebt den Saldo",
           abs(lange_reihen(K1, f_ts, f_rate)["spot7"][-1] + 0.04) < 1e-12 and not np.isfinite(lange_reihen(K2, f_ts, f_rate)["spot7"][-1])
           and abs(lange_reihen(K3, f_ts, f_rate)["spot7"][-1] - (6 * (-20.0) + 100.0) / 3500.0) < 1e-12)
        f2 = f_rate.copy(); f2[-21:] = 0.0004                                # die letzten 7 Tage: 0,12 % je Tag = 43,8 % im Jahr
        K4 = {k: v.copy() for k, v in K_.items()}; K4["st"][-7:] = 200.0      # die letzten 7 Tage: Saldo −20 %
        Rh = lange_reihen(K4, f_ts, f2); heute = int(tg[-1]) + 1
        LAh = lange_achsen_aus(Rh, heute)
        ok("A3 Achsen aus den Tagesreihen: höchstes Funding und schwächster Spot-Saldo der 365 Tage davor -> Perzentil 1 bzw. 0; Stand = letzter Tag der Achse",
           LAh["a3"]["pz"] == 1.0 and abs(LAh["a3"]["roh"] - 0.0012 * 365) < 1e-12 and LAh["a4"]["pz"] == 0.0 and abs(LAh["a4"]["roh"] + 0.2) < 1e-12
           and LAh["a3"]["tag"] == int(tg[-1]) and LAh["a3"]["grau"] is None and LAh["a7"]["grau"] is not None, f"{LAh['a3']} {LAh['a7']['grau']}")
        LAalt = lange_achsen_aus(Rh, heute + 3); LAgr = lange_achsen_aus(Rh, heute + 2)   # letzter Tageswert 4 bzw. 3 Tage alt
        Kk = {k: v[-170:].copy() for k, v in K4.items()}
        LAk = lange_achsen_aus(lange_reihen(Kk, f_ts, f2), heute)
        Ko = dict(K4); Ko["stag"] = np.array([], dtype=np.int64); Ko["sv"] = np.array([]); Ko["st"] = np.array([])
        LAo = lange_achsen_aus(lange_reihen(Ko, f_ts, f2), heute)
        LAf = lange_achsen_aus(lange_reihen(K4, None, None), heute)
        ok("A4 grau mit Grund: Tageswerte älter als 3 Tage (genau 3 Tage gelten noch); unter 180 Tagen Verlauf; Coin ohne Spot-Kerzen in hebel.db; "
           "ohne Funding; ohne Kerzen",
           _drin("Tageswerte nur bis", LAalt["a3"]["grau"]) and _drin("Tageswerte nur bis", LAalt["a7"]["grau"]) and LAgr["a3"]["grau"] is None
           and LAgr["a3"]["pz"] == 1.0 and _drin("fehlt Verlauf", LAk["a3"]["grau"]) and LAk["a3"]["roh"] is not None
           and _drin("keine Spot-Kerzen von Binance", LAo["a4"]["grau"]) and LAo["a3"]["grau"] is None and _drin("kein Wert", LAf["a3"]["grau"])
           and LAf["a4"]["grau"] is None and all(_drin("fehlen Tageskerzen", v["grau"]) for v in lange_achsen_aus(None, heute).values()),
           f"{LAalt['a3']['grau']} | {LAk['a3']['grau']} | {LAo['a4']['grau']}")

        # ---------------------------------------------------------------- kurze Achsen, Umfeld, Zusammenbau
        zl = [(57000.0, "long", 5e6, 3), (57000.0 - 0.01, "long", 7e6, 1), (59999.0, "long", 2e6, 2), (60000.0, "long", 9e6, 1), (58000.0, "short", 4e6, 1),
              (61000.0, "short", 8e6, 2)]
        ok("K1 Liquidations-Nähe: Long-Positionen mit Liquidationspreis von genau −5 % bis knapp unter dem Kurs zählen; der Kurs selbst, tiefer liegende und Short nicht",
           liq_naehe(zl, 60000.0) == 7e6 and liq_naehe(zl, None) == 0.0 and liq_naehe([], 60000.0) == 0.0 and liq_naehe(zl, 60000.0, 0.06) == 14e6)
        Lq = {"ts": jetzt - 600, "zeilen": zl, "fehlt": [], "abdeckung": {"anteil": 0.29}}
        T_ = {"usd": 3.5e6, "n": 700, "stunden": [1e6 + 1e4 * i for i in range(300)], "fehlt": None, "schritt": 100.0}
        h5 = [0.1 * i for i in range(A5_MIN)]
        KA = kurze_achsen(Lq, 60000.0, True, T_, h5, jetzt)
        ok("K2 A5 = 7 Mio. ÷ 3,5 Mio. = 2,0-mal die Gebote; Perzentil gegen 336 eigene Stundenwerte (14 Tage); A6 umgekehrt: 3,5 Mio. Gebote sind mehr als 250 von 300 Stunden -> Wert 16,7",
           KA["a5"]["roh"] == 2.0 and KA["a5"]["liq_usd"] == 7e6 and abs(KA["a5"]["pz"] - (20 + 0.5) / 336) < 1e-12 and KA["a5"]["grau"] is None and A5_MIN == 336 and A6_MIN == 240
           and KA["a5"]["abdeckung"] == 0.29 and abs(KA["a6"]["pz"] - (1 - 250.5 / 300)) < 1e-12 and KA["a6"]["grau"] is None, f"{KA['a5']['pz']} {KA['a6']['pz']}")
        Kg1 = kurze_achsen(Lq, 60000.0, True, T_, h5[:335], jetzt); Kg2 = kurze_achsen(dict(Lq, ts=jetzt - 1801), 60000.0, True, T_, h5, jetzt)
        Kg3 = kurze_achsen(Lq, 60000.0, False, T_, h5, jetzt); Kg4 = kurze_achsen(None, 60000.0, True, T_, h5, jetzt)
        Kg5 = kurze_achsen(Lq, 60000.0, True, {"usd": None, "n": 3, "stunden": [], "fehlt": "Tiefe des Buchs: in den letzten 60 Minuten nur 3 Werte bis −1 % (gebraucht werden 30)."}, h5, jetzt)
        Kg6 = kurze_achsen(dict(Lq, ts=jetzt - 1800), 60000.0, True, dict(T_, stunden=T_["stunden"][:239]), h5, jetzt)
        ok("K3 grau mit Grund: 335 eigene Stundenwerte (einer zu wenig); Heatmap älter als 30 Minuten (genau 30 gilt); kein frischer Kurs; keine Heatmap; kein Orderbuch; Markttiefe mit 239 Stundenwerten",
           _drin("335 von 336", Kg1["a5"]["grau"]) and Kg1["a5"]["roh"] == 2.0 and _drin("nicht frisch", Kg2["a5"]["grau"]) and Kg6["a5"]["grau"] is None
           and _drin("Kein frischer Kurs", Kg3["a5"]["grau"]) and _drin("noch kein Schnappschuss", Kg4["a5"]["grau"]) and _drin("nur 3 Werte", Kg5["a5"]["grau"])
           and _drin("nur 3 Werte", Kg5["a6"]["grau"]) and _drin("239 von 240", Kg6["a6"]["grau"]) and _drin("seit 23.125", Kg6["a6"]["grau"])
           and _drin("seit 23.125 neu, mit den Geboten bis −1 %", Kg1["a5"]["grau"]), f"{Kg1['a5']['grau']} | {Kg2['a5']['grau']}")
        lpd = lambda **kw: {m["key"]: m for m in _probe_cockpit(**kw)["lampen"]}   # noqa: E731
        ug1 = umfeld(lpd(aktien="grau", termin="grau"), 0); ug2 = umfeld(lpd(aktien="grau", termin="hinweis"), None); ug3 = umfeld(lpd(aktien="hinweis", termin="grau"), None)
        ug4 = umfeld({k: v for k, v in lpd().items() if k != "termin"}, None); ug5 = umfeld(lpd(aktien="grau"), 1)
        axg = [a for a in achsen_bauen(_probe_cockpit(aktien="grau", termin="grau", jetzt=jetzt), {}, {"a5": {}, "a6": {}}, None, "BTC") if a["key"] == "a8"][0]
        Bg = _probe_cockpit(aktien="grau", jetzt=jetzt)
        for m_ in Bg["lampen"]:
            if m_["key"] == "aktien":
                m_["detail"] = "Ob der Ausblick die Aktien-Regel gerade prüft, ist nicht bekannt."
        axd = [a for a in achsen_bauen(Bg, {}, {"a5": {}, "a6": {}}, None, "BTC") if a["key"] == "a8"][0]
        ok("U3 Umfeld grau: Nennt das Cockpit für die graue Lampe einen Grund, steht er im Satz der Achse („Grund laut Cockpit -- Aktien: …“); "
           "ohne Grund des Cockpits bleibt der Satz, wie er war; eine Lampe, die nicht offen ist, wird nicht genannt",
           axd["grau"] == ("Lampe Aktien grau -- ob das Umfeld belastet ist, ist nicht belegt. Grund laut Cockpit -- Aktien: Ob der Ausblick die "
                           "Aktien-Regel gerade prüft, ist nicht bekannt.") and axd["wert"] is None
           and umfeld_grund({"aktien": {"detail": "A."}, "termin": {"detail": "T."}}, ["Termin", "Aktien"]) == " Grund laut Cockpit -- Termin: T. Aktien: A."
           and umfeld_grund({"aktien": {"detail": "A."}}, ["Termin"]) == "" and umfeld_grund({}, []) == "", axd["grau"])
        ok("U2 Umfeld mit grauer Lampe: könnte die graue Lampe mehr bedeuten als das Bekannte, gibt es keinen Wert (grau mit Grund) statt „0“; "
           "ist schon die höchste Stufe erreicht, bleibt der Wert; eine fehlende Lampe zählt wie eine graue",
           ug1["wert"] is None and ug1["offen"] == ["Termin", "Aktien"] and ug2["wert"] is None and ug2["offen"] == ["Aktien"] and ug2["gruende"][0].startswith("Termin")
           and ug3["wert"] == 100 and ug3["offen"] == [] and ug4["wert"] is None and ug4["offen"] == ["Termin"] and ug5["wert"] == 100
           and axg["wert"] is None and axg["grau"] == "Lampen Termin und Aktien grau -- ob das Umfeld belastet ist, ist nicht belegt."
           and axg["leit"] == "Umfeld: nichts Bekanntes", f"{ug1} {axg['grau']}")
        ok("U1 Umfeld in Stufen: nichts 0 · Wochenende 33 · Termin 66 · Aktien-Lampe 100 · Notbremse ab Stufe 1 100; der höchste Wert gilt, alle Gründe stehen da",
           umfeld(lpd(), None)["wert"] == 0 and umfeld(lpd(wochenende="hinweis"), 0)["wert"] == 33 and umfeld(lpd(termin="hinweis", wochenende="hinweis"), None)["wert"] == 66
           and umfeld(lpd(termin="warnung"), None)["wert"] == 66 and umfeld(lpd(aktien="hinweis"), None)["wert"] == 100 and umfeld(lpd(), 1)["wert"] == 100
           and umfeld(lpd(), 2)["gruende"] == ["Notbremse Stufe 2"] and umfeld(lpd(), 0)["offen"] == []
           and len(umfeld(lpd(termin="hinweis", wochenende="hinweis", aktien="hinweis"), 1)["gruende"]) == 4)
        Bc = _probe_cockpit(jetzt=jetzt)
        AX = achsen_bauen(Bc, LAh, KA, None, "BTC")
        w = {a["key"]: a["wert"] for a in AX}
        ok("B1 acht Achsen in fester Reihenfolge; Werte: A1 97 (Perzentil 0,9722), A2 51, A3 100, A4 100 (schwächste Nachfrage), A5 6 (20,5 von 336), A6 17, A7 grau, A8 0",
           [a["key"] for a in AX] == ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8"] and w == {"a1": 97.0, "a2": 51.0, "a3": 100.0, "a4": 100.0, "a5": 6.0, "a6": 17.0, "a7": None, "a8": 0.0}
           and [a["index"] for a in AX] == [True, True, True, True, False, False, True, False] and AX[0]["leit"] == "Kontenquote Binance 3,45"
           and AX[1]["leit"] == "Open Interest Binance 97.074 BTC" and "+43,8 % im Jahr" in AX[2]["leit"] and "−20,00 % des Umsatzes" in AX[3]["leit"]
           and "2,0-mal die Gebote bis −1 % (3,5 Mio. USD)" in AX[4]["leit"] and "erfasst sind 29 % des Open Interest" in AX[4]["leit"]
           and AX[5]["leit"] == "Gebote bis −1 % im Hyperliquid-Buch: 3,5 Mio. USD (Stufen zu 100 USD)"
           and "obersten 10" not in AX[4]["leit"] + AX[5]["leit"] and schritt_text(0.1) == "Stufen zu 0,1 USD" and schritt_text(1.0) == "Stufen zu 1 USD"
           and schritt_text(None) == "" and schritt_text(0) == "", f"{w}")
        I5 = index_bauen(achsen_bauen(Bc, dict(LAh, a7={"roh": 0.03, "pz": 0.805, "tag": 1, "grau": None}), KA, None, "BTC"))
        I4 = index_bauen(AX)
        I3 = index_bauen(achsen_bauen(_probe_cockpit(konten=None, konten_pz=None), LAh, KA, None, "BTC"))
        ok("B2 Druck-Index: Mittel der fünf Achsen (97 + 51 + 100 + 100 + 81) ÷ 5 = 85,8 -> 86; mit vier Achsen 87; mit drei kein Wert, mit Namen der fehlenden",
           I5["wert"] == 86.0 and I5["n"] == 5 and I4["wert"] == 87.0 and I4["n"] == 4 and I4["fehlen"] == ["Schwankung"] and "ohne Schwankung" in I4["text"]
           and "gemessen, ungeprüft" in I4["text"] and I3["wert"] is None and I3["n"] == 3 and "Positionierung" in I3["text"] and "gebraucht werden 4" in I3["text"],
           f"{I5['wert']} {I4['wert']} {I3['text']}")
        ag1 = achsen_bauen(_probe_cockpit(konten=None, konten_pz=None), LAh, KA, None)[0]
        ag2 = achsen_bauen({"messwerte": [{"key": "konten", "wert": None, "pz": None, "text": "—", "fehlt": "Stand älter als 30 Minuten"},
                                          {"key": "oi", "wert": 5.0, "pz": None, "pz_n": None, "text": "5 BTC"}], "lampen": []}, LAh, KA, None, "BTC")
        ok("B3 graue Achse nennt den Grund: Kontenquote ohne Wert; mit dem Grund des Cockpits, wenn es einen nennt; Open Interest ohne Perzentil "
           "(der formatierte Wert des Cockpits ist kein Grund); der Vergleich nennt die 90 Tagesstände",
           ag1["grau"] == "Kontenquote Binance: kein Wert." and ag1["wert"] is None and ag2[0]["grau"] == "Kontenquote Binance: Stand älter als 30 Minuten"
           and ag2[1]["grau"] == "Open Interest Binance: für das Perzentil fehlt Verlauf (gebraucht werden 60 Tagesstände)." and ag2[1]["wert"] is None
           and ag2[1]["leit"] == "Open Interest Binance 5 BTC" and AX[0]["vergleich"] == "Perzentil gegen die letzten 90 Tagesstände" == AX[1]["vergleich"],
           f"{ag1['grau']} | {ag2[0]['grau']} | {ag2[1]['grau']}")
        ok("B4 „Was den Druck treibt“: die zwei höchsten Achsen (bei Gleichstand die frühere); nur Nullen -> eigener Satz; nichts -> eigener Satz",
           treiber_satz(AX) == "Am höchsten: Preis des Hebels (100) und Spot-Nachfrage (100)."
           and treiber_satz([{"key": "a8", "name": "Umfeld", "wert": 0.0}, {"key": "a1", "name": "Positionierung", "wert": None}]).startswith("Keine Achse zeigt Druck")
           and treiber_satz([{"key": "a1", "name": "Positionierung", "wert": None}]) == "Keine Achse hat einen Wert."
           and treiber_satz([{"key": "a8", "name": "Umfeld", "wert": 33.0}, {"key": "a1", "name": "Positionierung", "wert": 0.0}]) == "Am höchsten: Umfeld (33).")
        ok("B5 Warnzeichen Kontenquote: 2,99 aus, 3,00 an (mit dem Beleg aus U142 und dem Hinweis auf das andere Ereignis); ohne Wert kein Zustand",
           warnzeichen_bauen(_probe_cockpit(konten=2.99))["aktiv"] is False and warnzeichen_bauen(_probe_cockpit(konten=3.0))["aktiv"] is True
           and "Kontenquote Binance 3,00 (ab 3)" in warnzeichen_bauen(_probe_cockpit(konten=3.0))["text"] and warnzeichen_bauen(_probe_cockpit(konten=None))["aktiv"] is None
           and "20,3 %" in BELEG_U142 and "anderes Ereignis" in BELEG_U142)
        try:
            import hl_cockpit as HC
            Bv = HC.bauen(HC._probe_quellen(jetzt, "BTC"))
            mk = {m.get("key"): m for m in Bv.get("messwerte") or []}; lk = {m.get("key"): m for m in Bv.get("lampen") or []}
            import hl_chartbild as CBv
            axv = {a["key"]: a for a in achsen_bauen(Bv, {}, {"a5": {}, "a6": {}}, None, "BTC")}
            ok("V1 Vertrag mit dem Cockpit: Messwerte „konten“ und „oi“ mit wert, pz (Anteil 0 … 1), stand; pz_n ist die abgeschnittene Perzentilzahl "
               "(keine Anzahl), text der formatierte Wert (kein Grund); das Perzentil kommt aus 90 Tagesständen, mindestens 60; A1 und A2 der Karte "
               "sind dieses Perzentil mal 100; fünf Lampen mit Zustand aus der bekannten Menge",
               all(k in mk and all(f in mk[k] for f in ("wert", "pz", "pz_n", "stand", "text")) for k in ("konten", "oi"))
               and all(mk[k]["pz"] is not None and 0 <= mk[k]["pz"] <= 1 and mk[k]["pz_n"] == HC.pz_zahl(mk[k]["pz"]) for k in ("konten", "oi"))
               and mk["konten"]["text"] == _de(mk["konten"]["wert"], 2) and mk["oi"]["text"].endswith(" BTC")
               and CBv.PERZ_FENSTER == 90 and not np.isfinite(CBv.perzentil(1.0, np.arange(59.0))) and np.isfinite(CBv.perzentil(1.0, np.arange(60.0)))
               and axv["a1"]["wert"] == float(_hu(mk["konten"]["pz"] * 100, 0)) and axv["a2"]["wert"] == float(_hu(mk["oi"]["pz"] * 100, 0))
               and axv["a1"]["grau"] is None and axv["a1"]["leit"] == "Kontenquote Binance " + mk["konten"]["text"]
               and set(lk) >= {"hebel", "termin", "wochenende", "aktien", "schwankung"}
               and all(lk[k].get("zustand") in ("aus", "hinweis", "warnung", "grau") for k in lk) and HC.FRISCH_LIQ_S == 1800 and HC.FRISCH_KURS_S == FRISCH_KURS_S,
               f"{sorted(mk)} {sorted(lk)}; pz_n {mk['konten']['pz_n']} bei pz {mk['konten']['pz']}; A1 {axv['a1']['wert']}")
        except Exception as e_:  # noqa: BLE001
            ok("V1 Vertrag mit dem Cockpit", False, f"{type(e_).__name__}: {e_}")

        # ---------------------------------------------------------------- Alarm
        Sn = lambda p7, st7, **kw: _probe_stand("BTC", jetzt, p7, st7, **kw)   # noqa: E731
        Z0, M0 = alarm_schritt(None, Sn(0.3, "normal"), jetzt)
        Z1, M1 = alarm_schritt(Z0, Sn(0.66, "hoch"), jetzt + 300)
        Z2, M2 = alarm_schritt(Z1, Sn(0.60, "hoch"), jetzt + 600)
        Z3, M3 = alarm_schritt(Z2, Sn(0.40, "normal"), jetzt + 900)
        Z4, M4 = alarm_schritt(Z3, Sn(0.70, "hoch"), jetzt + 1200)                       # erneut hoch binnen 12 h: gesperrt
        Z5, M5 = alarm_schritt(Z4, Sn(0.40, "erhoeht"), jetzt + 1500)                    # Ende ohne gemeldeten Beginn: keine Entwarnung
        Z6, M6 = alarm_schritt(Z5, Sn(0.70, "hoch"), jetzt + 300 + SPERRZEIT_S - 1)      # eine Sekunde vor Ablauf der Sperrzeit
        Z7, M7 = alarm_schritt(Z5, Sn(0.70, "hoch"), jetzt + 300 + SPERRZEIT_S)          # genau 12 h nach dem Alarm
        ok("M1 Alarm: Beginn von „hoch“ -> ein Alarm; solange hoch -> nichts; Ende -> eine Entwarnung",
           M0 == [] and [m["art"] for m in M1] == ["alarm"] and M2 == [] and [m["art"] for m in M3] == ["entwarnung"] and Z1["e7"]["hoch"] is True
           and Z1["e7"]["alarm_ts"] == jetzt + 300 and Z3["e7"]["hoch"] is False and Z0 == {"e7": {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False},
           "e2": {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False}, "konten": {"scharf": True, "hinweis_ts": 0}}, f"{Z0}")
        ok("M2 Sperrzeit 12 Stunden: erneuter Beginn davor -> kein Alarm und am Ende keine Entwarnung; genau nach 12 Stunden wieder ein Alarm",
           M4 == [] and Z4["e7"]["hoch"] is True and Z4["e7"]["gemeldet"] is False and M5 == [] and M6 == [] and [m["art"] for m in M7] == ["alarm"]
           and Z7["e7"]["alarm_ts"] == jetzt + 300 + SPERRZEIT_S)
        Zl, Ml = alarm_schritt(Z1, _probe_stand("BTC", jetzt, None, "ohne"), jetzt + 600)
        ok("M3 eine Lücke (keine Zahl, keine Stufe) löst nichts aus und beendet nichts: der Zustand bleibt hoch, keine Meldung",
           Ml == [] and Zl["e7"] == Z1["e7"])
        Zb, Mb = alarm_schritt(None, _probe_stand("BTC", jetzt, 0.7, "hoch", p2=0.75, stufe2="hoch"), jetzt)
        ok("M4 beide Zahlen werden für sich geführt: beide beginnen -> zwei Alarme (7 Tage und 48 Stunden)",
           [(m["art"], m["ereignis"]) for m in Mb] == [("alarm", "e7"), ("alarm", "e2")] and Zb["e2"]["hoch"] is True)
        a1 = M1[0]
        ok("M5 Text des Alarms: Titel, Zahl mit Grundrate, die zwei höchsten Achsen, Stand; Priorität 5; Ansage in ganzen Wörtern",
           a1["titel"] == "Risikoradar BTC: Risiko hoch" and a1["prio"] == 5 and a1["coin"] == "BTC" and a1["ereignis"] == "e7" and a1["p"] == 0.66
           and a1["text"] == f"−10 % in 7 Tagen: 66 % (üblich 9,0 %). Höchste Achsen: Positionierung 97, Schwankung 80. Stand {_orts(jetzt)}."
           and a1["ansage"] == "Risikoradar. Bitcoin. Risiko hoch. 66 Prozent für minus 10 Prozent in 7 Tagen.", a1["text"] + " | " + str(a1["ansage"]))
        Se = _probe_stand("ETH", jetzt, 0.087, "hoch", konten=3.2); Se["ereignis"]["e7"]["x"] = 0.138; Se["ereignis"]["e7"]["x_text"] = "13,8 %"
        ae = alarm_schritt(None, Se, jetzt)[1][0]
        ok("M6 Ansage mit Komma-Zahlen („8 Komma 7 Prozent für minus 13 Komma 8 Prozent“); aktives Warnzeichen steht im Text",
           ae["ansage"] == "Risikoradar. Ethereum. Risiko hoch. 8 Komma 7 Prozent für minus 13 Komma 8 Prozent in 7 Tagen."
           and "Warnzeichen: Kontenquote 3,20." in ae["text"] and ae["titel"] == "Risikoradar ETH: Risiko hoch", str(ae["ansage"]))
        alt_tz = os.environ.get("TZ"); orts_ = None
        if hasattr(time, "tzset"):
            try:
                os.environ["TZ"] = "Europe/Berlin"; time.tzset()
                orts_ = (_orts(calendar.timegm((2026, 11, 23, 20, 29, 0))), _orts(calendar.timegm((2026, 7, 1, 12, 0, 0))), _orts(None))
            finally:
                if alt_tz is None:
                    os.environ.pop("TZ", None)
                else:
                    os.environ["TZ"] = alt_tz
                time.tzset()
        ok("M12 Zeit in den Meldungen: Ortszeit des Rechners mit dem Kürzel der Zeitzone (in Berlin: 20:29 UTC = 21:29 CET, im Sommer CEST); Berichte nennen UTC",
           (orts_ is None or orts_ == ("23.11. 21:29 CET", "01.07. 14:00 CEST", "—")) and _dt(calendar.timegm((2026, 11, 23, 20, 29, 0))) == "23.11. 20:29 UTC"
           and a1["text"].endswith(f"Stand {_orts(jetzt)}."), f"{orts_}")
        e3 = M3[0]
        ok("M7 Entwarnung: leise (Priorität 2), ohne Ansage, mit der Zahl; Titel „nicht mehr hoch“",
           e3["prio"] == 2 and e3["ansage"] is None and e3["titel"] == "Risikoradar BTC: nicht mehr hoch" and "Die Stufe „hoch“ ist beendet." in e3["text"]
           and "−10 % in 7 Tagen: 40 %" in e3["text"])
        Zk0, Mk0 = alarm_schritt(None, Sn(0.1, "normal", konten=3.4), jetzt)                                 # erster Blick, schon über 3: kein Hinweis
        Zk1, Mk1 = alarm_schritt(Zk0, Sn(0.1, "normal", konten=2.85), jetzt + 300)                           # zwischen 2,8 und 3: nicht scharf
        Zk2, Mk2 = alarm_schritt(Zk1, Sn(0.1, "normal", konten=3.1), jetzt + 600)
        Zk3, Mk3 = alarm_schritt(Zk2, Sn(0.1, "normal", konten=2.79), jetzt + 900)                           # unter 2,8: scharf
        Zk4, Mk4 = alarm_schritt(Zk3, Sn(0.1, "normal", konten=2.99), jetzt + 1200)
        Zk5, Mk5 = alarm_schritt(Zk4, Sn(0.1, "normal", konten=3.0), jetzt + 1500)                           # steigt auf 3: Hinweis
        Zk6, Mk6 = alarm_schritt(Zk5, Sn(0.1, "normal", konten=2.5), jetzt + 1800)
        Zk7, Mk7 = alarm_schritt(Zk6, Sn(0.1, "normal", konten=3.3), jetzt + 1500 + HINWEIS_SPERRE_S - 1)     # binnen 7 Tagen: kein zweiter
        Zk8, Mk8 = alarm_schritt(Zk6, Sn(0.1, "normal", konten=3.3), jetzt + 1500 + HINWEIS_SPERRE_S)
        Zk9, Mk9 = alarm_schritt(Zk5, Sn(0.1, "normal", konten=None), jetzt + 1800)
        ok("M8 Hinweis Warnzeichen: nur wenn die Kontenquote auf 3 steigt, nachdem sie unter 2,8 lag; beim ersten Blick über 3 keiner; höchstens einer in 7 Tagen",
           Mk0 == [] and Zk0["konten"]["scharf"] is False and Mk1 == [] and Zk1["konten"]["scharf"] is False and Mk2 == [] and Zk3["konten"]["scharf"] is True
           and Mk4 == [] and Zk4["konten"]["scharf"] is True and [m["art"] for m in Mk5] == ["hinweis"] and Zk5["konten"] == {"scharf": False, "hinweis_ts": jetzt + 1500}
           and Zk6["konten"]["scharf"] is True and Mk7 == [] and Zk7["konten"]["scharf"] is False and [m["art"] for m in Mk8] == ["hinweis"]
           and Mk9 == [] and Zk9["konten"] == Zk5["konten"])
        h5_ = Mk5[0]
        ok("M9 Text des Hinweises: Priorität 3, ohne Ansage, mit dem gemessenen Verhältnis aus U142",
           h5_["prio"] == 3 and h5_["ansage"] is None and h5_["titel"] == "Risikoradar BTC: Warnzeichen Kontenquote"
           and h5_["text"].startswith("Kontenquote Binance 3,00 (ab 3). In solchen Lagen folgte in 7 Tagen häufiger ein Rücksetzer (U142: 20,3 % gegen 7,3 %)."))
        alle_texte = " ".join(str(v) for m in (M1 + M3 + Mk5 + [ae]) for v in (m["titel"], m["text"], m.get("ansage") or "")) + " " + GRENZEN + " " + BELEG_U142
        ok("M10 Wortprobe: kein Pfeil, kein Empfehlungswort in Meldungen, Beleg und Grenzen",
           not any(w_ in alle_texte.lower() for w_ in ("kaufen", "verkaufen", "empfehl", "einsteigen", "aussteigen", "short gehen", "long gehen", "jetzt handeln", "↑", "↓", "➚", "➘", "▲", "▼")))

        # ---------------------------------------------------------------- Speicher, Meldungen, Push
        os.environ["HL_RADAR_DB"] = os.path.join(tmp, "radar.db")
        dbp = os.path.join(tmp, "hl_liq.db")
        con = verbinden(pfad(dbp))
        ok("P1 Speicher: radar.db am umgelenkten Ort, drei Tabellen; ohne Umlenkung neben der Hauptdatenbank; Meta hin und zurück ohne NaN",
           pfad(dbp) == os.path.join(tmp, "radar.db") and {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")} >= {"rd_stand", "rd_alarm", "rd_meta"}
           and (meta_setzen(con, "x", {"a": float("nan"), "b": np.float64(2.5), "c": [np.int64(3)]}) or meta(con, "x") == {"a": None, "b": 2.5, "c": [3]})
           and meta(con, "fehlt", "vorgabe") == "vorgabe" and meta(None, "x", 7) == 7 and lesen(os.path.join(tmp, "gibt_es_nicht.db")) is None)
        os.environ.pop("HL_RADAR_DB")
        ok("P2 Ort ohne Umlenkung: radar.db neben der Hauptdatenbank", pfad("/daten/x/hl_liq.db") == "/daten/x/radar.db")
        os.environ["HL_RADAR_DB"] = os.path.join(tmp, "radar.db")
        ok("P3 Einstellung: Vorgabe Push an, nur BTC, 95. Perzentil; Unbekanntes fällt weg (fremder Coin, anderes Perzentil); Reihenfolge der Coins fest",
           einstellung_lesen(con) == {"push": True, "coins": ["BTC"], "pz": 0.95} and einstellung_pruefen({"coins": ["XMR", "DOGE", "BTC"], "pz": 0.9, "push": 0})
           == {"push": False, "coins": ["BTC", "XMR"], "pz": 0.95} and einstellung_pruefen({"coins": [], "pz": 0.975})["coins"] == []
           and einstellung_pruefen({"pz": "0.99"})["pz"] == 0.99 and einstellung_pruefen("unsinn") == {"push": True, "coins": ["BTC"], "pz": 0.95})
        e_neu = einstellung_setzen(dbp, {"coins": ["BTC", "ETH"], "pz": 0.975, "fremd": 1})
        ok("P4 Einstellung setzen: nur die bekannten Felder, gespeichert und wieder gelesen",
           e_neu == {"push": True, "coins": ["BTC", "ETH"], "pz": 0.975} and einstellung_lesen(con) == e_neu and einstellung_setzen(dbp, {"push": False})["coins"] == ["BTC", "ETH"])
        einstellung_setzen(dbp, {"push": True, "coins": ["BTC"], "pz": 0.95})
        thema = "abcdefghijklmnopqrstuvwxyz0123456"; gesendet = []
        def http_ok(url, rumpf, timeout):
            gesendet.append((url, json.loads(rumpf.decode("utf-8")))); return 200, "ok"
        def http_500(url, rumpf, timeout):
            gesendet.append((url, json.loads(rumpf.decode("utf-8")))); return 500, "kaputt " + thema
        ein = {"thema": thema, "server": "https://ntfy.example.org"}
        ids = meldungen_ablegen(con, M1 + M3 + Mk5, einstellung_lesen(con), jetzt, True)
        fremd = meldungen_ablegen(con, [dict(M1[0], coin="ETH")], einstellung_lesen(con), jetzt, True)
        r1 = push_senden(con, jetzt + 5, http_fn=http_ok, einstellung=ein)
        ok("P5 Push über eine nachgebaute Sendefunktion: drei Meldungen (Alarm 5, Entwarnung 2, Hinweis 3) an die Wurzel des Servers, Thema nur im Rumpf; "
           "für einen nicht gewählten Coin wird nichts abgelegt",
           len(ids) == 3 and fremd == [] and r1 == {"gesendet": 3, "fehler": 0, "aufgegeben": 0} and [g[1]["priority"] for g in gesendet] == [5, 2, 3]
           and all(g[0] == "https://ntfy.example.org/" and g[1]["topic"] == thema for g in gesendet) and gesendet[0][1]["title"] == "Risikoradar BTC: Risiko hoch"
           and gesendet[0][1]["tags"] == ["rotating_light"] and gesendet[1][1]["tags"] == ["information_source"] and thema not in gesendet[0][1]["message"]
           and [r[0] for r in con.execute("SELECT push FROM rd_alarm ORDER BY id")] == [PUSH_GESENDET] * 3
           and push_senden(con, jetzt + 6, http_fn=http_ok, einstellung=ein) == {"gesendet": 0, "fehler": 0, "aufgegeben": 0}, f"{r1} {[g[1]['priority'] for g in gesendet]}")
        gesendet.clear()
        id_f = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 10, True)[0]
        rf = [push_senden(con, jetzt + 10 + i, http_fn=http_500, einstellung=ein) for i in range(1, 7)]
        zf = con.execute("SELECT push, versuche, push_fehler FROM rd_alarm WHERE id=?", (id_f,)).fetchone()
        ok("P6 Fehlversuche: fünf Versuche, dann aufgegeben; der Fehlertext nennt das Thema nicht",
           [r["fehler"] for r in rf] == [1, 1, 1, 1, 1, 0] and rf[5]["aufgegeben"] == 1 and len(gesendet) == 5 and zf[0] == PUSH_AUFGEGEBEN and zf[1] == 5
           and thema not in (zf[2] or "") and "HTTP 500" in (zf[2] or ""), f"{zf}")
        gesendet.clear()
        id_g = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 100, True)[0]
        rg = push_senden(con, jetzt + 100 + 3600, http_fn=http_ok, einstellung=ein)            # genau eine Stunde offen: wird noch gesendet
        n_g = len(gesendet); gesendet.clear()
        id_a = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 100, True)[0]
        ra = push_senden(con, jetzt + 100 + 3601, http_fn=http_ok, einstellung=ein)            # eine Sekunde länger: aufgegeben
        id_n = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 200, True)[0]
        rn = push_senden(con, jetzt + 201, http_fn=http_ok, einstellung={"thema": "", "server": ""})
        ok("P7 eine Meldung, die länger als eine Stunde offen ist, wird nicht mehr gesendet (genau eine Stunde gilt noch); ohne eingerichtetes "
           "Thema wird nichts gesendet",
           rg == {"gesendet": 1, "fehler": 0, "aufgegeben": 0} and n_g == 1 and ra == {"gesendet": 0, "fehler": 0, "aufgegeben": 1} and rn["aufgegeben"] == 1
           and gesendet == [] and con.execute("SELECT push FROM rd_alarm WHERE id IN (?,?,?) ORDER BY id", (id_g, id_a, id_n)).fetchall()
           == [(PUSH_GESENDET,), (PUSH_AUFGEGEBEN,), (PUSH_AUFGEGEBEN,)], f"{rg} {ra} {rn}")
        aus1 = meldungen_ablegen(con, M1, {"push": False, "coins": ["BTC"], "pz": 0.95}, jetzt + 300, True)[0]
        aus2 = meldungen_ablegen(con, M1, {"push": True, "coins": ["BTC"], "pz": 0.95}, jetzt + 300, False)[0]
        ok("P8 Schalter „Push“ aus oder Benachrichtigung nicht eingerichtet: die Meldung steht in der Liste (für Ton und Ansage), gesendet wird nichts",
           con.execute("SELECT push FROM rd_alarm WHERE id IN (?,?)", (aus1, aus2)).fetchall() == [(PUSH_AUS,), (PUSH_AUS,)]
           and push_senden(con, jetzt + 301, http_fn=http_ok, einstellung=ein)["gesendet"] == 0 and gesendet == [])
        # echter Versand über hl_berichte (urllib) an einen Webserver auf diesem Rechner: was wirklich über die Leitung geht
        import http.server
        emp = []; antw = {"status": 200}
        class _Ntfy(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                n_ = int(self.headers.get("Content-Length") or 0)
                emp.append((self.path, self.headers.get("Content-Type"), self.rfile.read(n_)))
                self.send_response(antw["status"]); self.send_header("Content-Length", "2"); self.end_headers(); self.wfile.write(b"{}")
            def log_message(self, *a_):
                pass
        nt = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Ntfy)
        threading.Thread(target=nt.serve_forever, daemon=True).start()
        try:
            ein_l = {"thema": thema, "server": f"http://127.0.0.1:{nt.server_address[1]}"}
            id_l = meldungen_ablegen(con, M1, einstellung_lesen(con), jetzt + 400, True)[0]
            rl1 = push_senden(con, jetzt + 401, einstellung=ein_l)
            antw["status"] = 500
            id_l2 = meldungen_ablegen(con, M3, einstellung_lesen(con), jetzt + 402, True)[0]
            rl2 = push_senden(con, jetzt + 403, einstellung=ein_l)
            zl2 = con.execute("SELECT push, versuche, push_fehler FROM rd_alarm WHERE id=?", (id_l2,)).fetchone()
        finally:
            nt.shutdown(); nt.server_close()
        rumpf_l = json.loads(emp[0][2].decode("utf-8")) if emp else {}
        ok("P10 echter Versand an einen Webserver auf diesem Rechner (über hl_berichte, ohne nachgebaute Sendefunktion): POST an die Wurzel, "
           "JSON in UTF-8 mit Thema, Titel, Text (Minuszeichen und Umlaute unversehrt), Priorität 5 und Zeichen; Antwort 500 zählt als "
           "Fehlversuch, der Fehlertext nennt das Thema nicht",
           rl1 == {"gesendet": 1, "fehler": 0, "aufgegeben": 0} and len(emp) == 2 and emp[0][0] == "/" and "application/json" in (emp[0][1] or "")
           and rumpf_l == {"topic": thema, "title": "Risikoradar BTC: Risiko hoch", "message": M1[0]["text"], "tags": ["rotating_light"], "priority": 5}
           and "−10 % in 7 Tagen" in rumpf_l["message"] and "üblich" in rumpf_l["message"] and "−10 %".encode("utf-8") in emp[0][2]
           and con.execute("SELECT push FROM rd_alarm WHERE id=?", (id_l,)).fetchone()[0] == PUSH_GESENDET
           and rl2 == {"gesendet": 0, "fehler": 1, "aufgegeben": 0} and zl2[0] == PUSH_OFFEN and zl2[1] == 1 and "HTTP 500" in (zl2[2] or "")
           and thema not in (zl2[2] or ""), f"{rl1} {rl2} {zl2} {len(emp)} Anfragen")
        con.execute("DELETE FROM rd_alarm WHERE id IN (?,?)", (id_l, id_l2))
        ml = meldungen_lesen(con, 3)
        ok("P9 Liste der Meldungen für die Karte: die jüngsten zuerst, mit Art, Text, Ansage und dem Stand des Push in Worten",
           len(ml) == 3 and ml[0]["id"] == aus2 and ml[0]["push"] == "kein Push" and ml[2]["push"] == "Push nicht gesendet" and ml[0]["art"] == "alarm"
           and ml[0]["ansage"].startswith("Risikoradar. Bitcoin.") and meldungen_lesen(None) == [])

        # ---------------------------------------------------------------- Takt
        con.execute("DELETE FROM rd_alarm"); gesendet.clear()
        aufrufe = []; rb_starts = []; stufe_jetzt = {"BTC": ("hoch", 0.66)}
        zust_e7 = lambda coin_: ((meta(con, "zustand") or {}).get(coin_) or {}).get("e7") or {}   # noqa: E731 -- fehlt der Zustand, scheitert die Probe (kein Abbruch)
        def stand_fn(db, coin, jetzt_, gemeinsam=None, rb=None, zust=None, einst=None, con_r=None):
            aufrufe.append((coin, gemeinsam, bool(rb), dict(zust or {}).get("e7", {}).get("hoch")))
            if coin == "ZEC":
                raise RuntimeError("Probe-Fehler")
            st_, p_ = stufe_jetzt.get(coin, ("normal", 0.1))
            return _probe_stand(coin, jetzt_, p_, st_)
        gem = lambda db, j: {"gemeinsam": j}                                   # noqa: E731
        _TAKT["letzter_rueckblick_start"] = 0.0
        t1 = takt_schritt(dbp, con, jetzt, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: rb_starts.append(d) or True, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T1 erster Schritt: alle fünf Coins gerechnet und abgelegt (volle Stunde neu), der Rückblick wird gestartet (noch keiner da), "
           "ein Fehler bei einem Coin hält die anderen nicht auf",
           t1["coins"] == ["BTC", "ETH", "HYPE", "XMR"] and t1["abgelegt"] == 4 and t1["rueckblick_gestartet"] is True and rb_starts == [dbp]
           and len(t1["fehler"]) == 1 and t1["fehler"][0].startswith("ZEC: RuntimeError: Probe-Fehler") and [a[0] for a in aufrufe] == list(COINS)
           and all(a[1] == {"gemeinsam": jetzt} for a in aufrufe) and con.execute("SELECT COUNT(*) FROM rd_stand").fetchone()[0] == 4, f"{t1}")
        zeile = con.execute("SELECT stunde, ts, p7, p2, idx, a5, a6, json FROM rd_stand WHERE coin='BTC'").fetchone()
        ok("T2 Ablage je Stunde: p7, p2, Index, Rohwerte von A5 und A6 und der Stand in Kurzform",
           zeile[0] == jetzt // 3600 and zeile[1] == jetzt and zeile[2] == 0.66 and zeile[3] == 0.02 and zeile[4] == 62.0 and zeile[5] == 1.5 and zeile[6] == 4.0e6
           and json.loads(zeile[7])["e"]["e7"] == {"p": 0.66, "stufe": "hoch", "x": 0.10} and json.loads(zeile[7])["achsen"]["a1"] == 97.0
           and json.loads(zeile[7])["konten"] == 2.0, f"{zeile[:7]}")
        ok("T3 Alarm im Takt: BTC beginnt „hoch“ -> eine Meldung abgelegt und gesendet (Priorität 5); Zustand gespeichert",
           t1["meldungen"] == 1 and t1["push"]["gesendet"] == 1 and [g[1]["priority"] for g in gesendet] == [5] and zust_e7("BTC").get("hoch") is True
           and zust_e7("ETH").get("hoch") is False and (meta(con, "takt") or {}).get("ts") == jetzt and meta(con, "letzte_ablage") == jetzt // 3600)
        aufrufe.clear()
        t2 = takt_schritt(dbp, con, jetzt + 300, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: rb_starts.append(d) or True, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T4 zweiter Schritt in derselben Stunde: nur die gewählten Coins (BTC), nichts abgelegt, kein zweiter Alarm, der Vorzustand geht in den Stand ein; "
           "der Rückblick wird binnen 6 Stunden nicht noch einmal gestartet",
           t2["coins"] == ["BTC"] and t2["abgelegt"] == 0 and t2["meldungen"] == 0 and aufrufe == [("BTC", {"gemeinsam": jetzt + 300}, False, True)]
           and t2["rueckblick_gestartet"] is False and len(rb_starts) == 1 and len(gesendet) == 1, f"{t2} {aufrufe}")
        tv_t4 = dict(meta(con, "takt_voll") or {})
        stufe_jetzt["ETH"] = ("hoch", 0.7); stufe_jetzt["BTC"] = ("normal", 0.2); aufrufe.clear()
        t3 = takt_schritt(dbp, con, jetzt + 3600, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: False, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T5 nächste Stunde: wieder alle Coins abgelegt; BTC endet -> Entwarnung gesendet (Priorität 2); ETH beginnt „hoch“, ist aber nicht gewählt: "
           "Zustand läuft mit, keine Meldung",
           t3["abgelegt"] == 4 and t3["meldungen"] == 1 and [g[1]["priority"] for g in gesendet] == [5, 2] and zust_e7("ETH").get("hoch") is True
           and zust_e7("BTC").get("hoch") is False and con.execute("SELECT COUNT(*) FROM rd_alarm").fetchone()[0] == 2
           and con.execute("SELECT COUNT(*) FROM rd_stand").fetchone()[0] == 8, f"{t3}")
        tv_t5 = dict(meta(con, "takt_voll") or {})
        vs_ = {"ts": jetzt, "coins": list(COINS), "dauer_s": 9.84, "zeit": {"cockpit": 8.0}}
        ok("T5b Schritt zur vollen Stunde (U312, seit 23.125): der Takt hält ihn eigens fest -- Zeit, Coins, Dauer und Teile wie im Schritt; ein "
           "Schritt in derselben Stunde ändert ihn nicht, der nächste zur vollen Stunde ersetzt ihn. Debug 160 nennt ihn hinter dem letzten "
           "Schritt, wenn er nicht selbst der letzte war",
           tv_t4.get("ts") == jetzt and tv_t4.get("coins") == t1["coins"] and tv_t4.get("dauer_s") == t1["dauer_s"] and tv_t4.get("zeit") == t1["zeit"]
           and tv_t5.get("ts") == jetzt + 3600 and tv_t5.get("coins") == t3["coins"] and len(tv_t5["coins"]) == 4
           and takt_voll_satz(vs_, {"ts": jetzt + 300}) == ("; zur vollen Stunde zuletzt " + _dt(jetzt) + ": der Schritt dauerte 9,8 s für 5 Coins "
                                                             "(davon Quellen des Cockpits 8,0 s · Ausblick 0,0 s · Tagesreihen 0,0 s · Orderbuch 0,0 s · Notbremse 0,0 s)")
           and takt_voll_satz(vs_, {"ts": jetzt}) == "" and takt_voll_satz(None) == "" and takt_voll_satz({"ts": jetzt}) == ""
           and takt_voll_satz(dict(vs_, ts=None), None) == "",
           f"{tv_t4.get('ts')} {tv_t5.get('ts')}; {takt_voll_satz(vs_, {'ts': jetzt + 300})}")
        m0 = calendar.timegm((2027, 1, 1, 0, 0, 0)); rbv = lambda st: {"version": VERSION_MODUL, "stand": st}   # noqa: E731 -- Januar: 31 Tage
        ok("T6 wann der Rückblick fällig ist: keiner da; andere Fassung; älter als 30 Tage (genau 30 Tage noch nicht); seit 23.123 auch, sobald "
           "der Monat gewechselt hat (Regel K5: neue Anpassung) -- im selben Monat nicht; nicht binnen 6 Stunden nach dem letzten Start (genau "
           "6 Stunden danach wieder), auch nicht nach einem Monatswechsel",
           rueckblick_faellig(None, 1e9, 0) and rueckblick_faellig({"version": "alt", "stand": 1e9}, 1e9, 0)
           and rueckblick_faellig(rbv(m0), m0 + 30 * 86400 + 1, 0) and not rueckblick_faellig(rbv(m0), m0 + 30 * 86400, 0)
           and rueckblick_faellig(rbv(m0 - 1), m0 + 10, 0) and not rueckblick_faellig(rbv(m0), m0 + 5 * 86400, 0)
           and not rueckblick_faellig(rbv(m0 - 1), m0 + 10, m0 + 10 - 3600)
           and not rueckblick_faellig(None, 1e9, 1e9 - 6 * 3600 + 1) and rueckblick_faellig(None, 1e9, 1e9 - 6 * 3600))
        al = alle_stufen(con, "BTC", _probe_stand("BTC", jetzt + 3700, 0.3, "erhoeht", p2=0.12, stufe2="hoch"))
        ok("T7 Zeile „alle Coins“ (seit 23.124 die 48-Stunden-Zahl, die in der Karte groß steht): der gewählte Coin aus dem frischen Stand "
           "(12 %, hoch -- nicht die 7-Tage-Zahl mit 30 %), die anderen aus der letzten Ablage (ETH: 2,0 %, normal -- nicht 70 %, hoch); ein Coin "
           "ohne Ablage ohne Stufe",
           [a["coin"] for a in al] == list(COINS) and al[0]["stufe"] == "hoch" and al[0]["p_text"] == "12 %" and al[1]["stufe"] == "normal" and al[1]["p_text"] == "2,0 %"
           and al[3]["stufe"] == "ohne" and al[3]["p_text"] == "—" and al[3]["stufe_wort"] == "ohne Stufe" and LEIT == "e2",
           f"{[(a['coin'], a['stufe'], a['p_text']) for a in al]}")
        # Ein Coin, der nicht gewählt ist: der Zustand läuft mit, aber nichts gilt als gemeldet
        Zn1, Mn1 = alarm_schritt(None, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=2.5), jetzt, melden=False)
        Zn2, Mn2 = alarm_schritt(Zn1, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 300, melden=False)
        Zn3, Mn3 = alarm_schritt(Zn2, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 600)       # jetzt gewählt, schon hoch: kein Alarm nachträglich
        Zn4, Mn4 = alarm_schritt(Zn3, _probe_stand("ETH", jetzt, 0.2, "normal", konten=2.5), jetzt + 900)    # Ende: keine Entwarnung ohne Alarm
        Zn5, Mn5 = alarm_schritt(Zn4, _probe_stand("ETH", jetzt, 0.7, "hoch", konten=3.2), jetzt + 1200)     # neuer Beginn: Alarm und Hinweis, keine Sperrzeit
        Zn6, Mn6 = alarm_schritt(Zn5, _probe_stand("ETH", jetzt, 0.2, "normal", konten=3.2), jetzt + 1500, melden=False)   # abgewählt: Ende ohne Entwarnung
        ok("M11 ein Coin, der nicht für Meldungen gewählt ist: „hoch“ und die Kontenquote laufen mit, aber ohne Meldung, ohne Sperrzeit und ohne "
           "spätere Entwarnung; wird er dazugeschaltet, kommt der Alarm erst beim nächsten Beginn",
           Mn1 == [] and Zn1["e7"] == {"hoch": True, "seit": jetzt, "alarm_ts": 0, "gemeldet": False} and Mn2 == [] and Zn2["konten"] == {"scharf": False, "hinweis_ts": 0}
           and Mn3 == [] and Mn4 == [] and Zn4["e7"]["hoch"] is False and [m["art"] for m in Mn5] == ["alarm", "hinweis"] and Zn5["e7"]["alarm_ts"] == jetzt + 1200
           and Mn6 == [] and Zn6["e7"]["hoch"] is False and Zn6["e7"]["gemeldet"] is False, f"{Zn1['e7']} {[m['art'] for m in Mn5]}")
        a5v = a5_verlauf(con, "BTC", jetzt + 3700)
        ab_t8 = meta(con, "tiefe_ab")
        con.execute("INSERT OR REPLACE INTO rd_stand (stunde, coin, ts, p7, p2, idx, a5, a6, json) VALUES (?,?,?,?,?,?,?,?,?)",
                    (jetzt // 3600 - 1, "BTC", jetzt - 3600, None, None, None, 99.0, None, "{}")); con.commit()
        a5v_vor = a5_verlauf(con, "BTC", jetzt + 3700)
        con.execute("DELETE FROM rd_stand WHERE stunde=? AND coin='BTC'", (jetzt // 3600 - 1,)); con.commit()
        con_ohne = verbinden(os.path.join(tmp, "ohne_ab.db"))
        con_ohne.execute("INSERT OR REPLACE INTO rd_stand (stunde, coin, ts, p7, p2, idx, a5, a6, json) VALUES (?,?,?,?,?,?,?,?,?)",
                         (jetzt // 3600, "BTC", jetzt, None, None, None, 1.5, None, "{}")); con_ohne.commit()
        a5v_ohne = a5_verlauf(con_ohne, "BTC", jetzt + 3700); con_ohne.close()
        ok("T8 eigener Verlauf von A5: die abgelegten Rohwerte des Coins -- seit 23.125 erst ab der ersten Stunde, die der Takt mit den Geboten "
           "bis −1 % abgelegt hat (rd_meta „tiefe_ab“, gesetzt bei der ersten Ablage, danach unverändert); ein älterer Wert zählt nicht; ohne den "
           "Vermerk gibt es keinen Verlauf (die Werte stammen dann von vor 23.125)",
           a5v == [1.5, 1.5] and a5_verlauf(None, "BTC", jetzt) == [] and ab_t8 == jetzt // 3600 and a5v_vor == [1.5, 1.5] and a5v_ohne == [],
           f"{a5v} tiefe_ab {ab_t8} (Stunde {jetzt // 3600}); mit älterem {a5v_vor}; ohne Vermerk {a5v_ohne}")
        stufe_jetzt["ETH"] = ("normal", 0.1); con.execute("DELETE FROM rd_alarm"); gesendet.clear()
        meta_setzen(con, "einstellung", {"push": True, "coins": ["BTC", "ETH"], "pz": 0.95})
        t4 = takt_schritt(dbp, con, jetzt + 7200, http_fn=http_ok, push_ein=ein, starte_rb=lambda d: False, stand_fn=stand_fn, gemeinsam_fn=gem)
        ok("T9 ETH war „hoch“, ohne gewählt zu sein, wird dann gewählt und endet: keine Entwarnung (es gab keinen Alarm), nichts gesendet",
           t4["meldungen"] == 0 and gesendet == [] and zust_e7("ETH") == {"hoch": False, "seit": None, "alarm_ts": 0, "gemeldet": False}
           and con.execute("SELECT COUNT(*) FROM rd_alarm").fetchone()[0] == 0, f"{t4}")
        meta_setzen(con, "einstellung", {"push": True, "coins": ["BTC"], "pz": 0.95})
        con.close()
        alt_hr = os.environ.get("HL_RADAR"); alt_takt = (_TAKT["gestartet"], _TAKT["stop"])
        try:
            _TAKT["gestartet"] = False; _TAKT["stop"] = None
            os.environ["HL_RADAR"] = "0"
            aus_s = starten(os.path.join(tmp, "aus.db")); aus_t = starte(os.path.join(tmp, "aus.db")); aus_g = _TAKT["gestartet"]
            os.environ.pop("HL_RADAR")
            st_s = starten("/probe/_selftest.db"); st_g = _TAKT["gestartet"]
            los = starten(os.path.join(tmp, "dienst.db")); los_g = _TAKT["gestartet"]; los_stop = _TAKT["stop"]; nochmal = starten(os.path.join(tmp, "dienst.db"))
            if los_stop is not None:
                los_stop.set()                                           # der Faden wartet 90 s auf seinen ersten Schritt: gleich wieder anhalten
            ok("D1 Dienst: nicht für Selbsttest-Datenbanken; aus mit HL_RADAR=0 (nichts gestartet, nichts gemerkt); nicht ohne Datenbank; "
               "sonst startet er genau einmal",
               st_s is False and st_g is False and starte(":memory:") is None and starte("") is None and aus_s is False and aus_t is None and aus_g is False
               and los is True and los_g is True and los_stop is not None and nochmal is False and _TAKT["stop"] is los_stop)
            _TAKT["gestartet"] = False; _TAKT["stop"] = None
            ev_f = threading.Event(); rufe_f = []

            def schritt_probe(db_, con_):
                rufe_f.append((db_, con_, con_.execute("SELECT COUNT(*) FROM rd_meta").fetchone()[0]))
                if len(rufe_f) == 1:
                    raise RuntimeError("Probe-Fehler im Schritt")
                if len(rufe_f) == 2:
                    raise sqlite3.OperationalError("Probe: Datenbank gesperrt")
                ev_f.set()
            puf_f = io.StringIO()
            with contextlib.redirect_stdout(puf_f):
                fd_ = starte(dbp, stop=ev_f, verzoegerung=0.0, schritt=schritt_probe, takt_s=0.01)
                if fd_ is not None:
                    fd_.join(20)
            ev_n = threading.Event(); ev_n.set()
            fd_n = starte(dbp, stop=ev_n, verzoegerung=30.0, schritt=lambda db_, con_: rufe_f.append("nie"))
            if fd_n is not None:
                fd_n.join(20)
            ok("D2 Faden „radar“: läuft als Daemon mit eigener Verbindung zu radar.db; ein Fehler im Schritt beendet ihn nicht (gemeldet in der "
               "Ausgabe, nächster Schritt mit derselben Verbindung); nach einem Fehler der Datenbank öffnet er eine neue Verbindung; "
               "wird er vor dem ersten Schritt angehalten, rechnet er nicht",
               fd_ is not None and not fd_.is_alive() and fd_.name == "radar" and fd_.daemon is True and len(rufe_f) == 3
               and all(r_[0] == dbp and r_[2] >= 1 for r_ in rufe_f) and rufe_f[1][1] is rufe_f[0][1] and rufe_f[2][1] is not rufe_f[1][1]
               and "Risikoradar: RuntimeError: Probe-Fehler im Schritt" in puf_f.getvalue()
               and "Risikoradar: OperationalError: Probe: Datenbank gesperrt" in puf_f.getvalue() and _TAKT["fehler"] is None
               and fd_n is not None and not fd_n.is_alive(), f"{len(rufe_f)} Schritte; {puf_f.getvalue().strip().splitlines()}")
        finally:
            if _TAKT["stop"] is not None and _TAKT["stop"] is not alt_takt[1]:
                _TAKT["stop"].set()
            _TAKT["gestartet"], _TAKT["stop"] = alt_takt
            if alt_hr is None:
                os.environ.pop("HL_RADAR", None)
            else:
                os.environ["HL_RADAR"] = alt_hr

        # ---------------------------------------------------------------- Rückblick
        tau_ = np.arange(0, 400) * TAG; ja_ = (np.arange(400) % 10 == 0).astype(float)
        g_ = grundrate_laufend(tau_, ja_, 7)
        ok("R1 laufende Grundrate: nur Ursprünge, deren Frist abgelaufen war (7 Tage), mindestens 100; von Hand an zwei Stellen",
           np.isnan(g_[:106]).all() and abs(g_[106] - 10 / 100) < 1e-12 and abs(g_[399] - 40 / 393) < 1e-12 and np.isnan(grundrate_laufend(tau_[:50], ja_[:50], 7)).all(),
           f"{g_[106]} {g_[399]}")
        rng = np.random.default_rng(7)
        nA = 4 * 700; tauA = AU.OOS_AB - 200 * TAG + np.arange(nA) * 6 * 3600
        rr = rng.normal(0, 0.012, nA) * (1 + 0.8 * np.sin(np.arange(nA) / 300.0))
        lcA = np.log(100.0) + np.cumsum(rr); CA = np.exp(lcA)
        HA = CA * np.exp(np.abs(rng.normal(0, 0.01, nA))); LA_ = CA * np.exp(-np.abs(rng.normal(0, 0.012, nA)))
        A_ = {"tau": tauA, "C": CA, "H": HA, "L": LA_, "n": nA}
        Fk_ = np.outer(0.0006 * (1 + 0.8 * np.sin(np.arange(nA) / 300.0)) ** 2, np.arange(1, AU.K_MAX + 1))
        alt_lib = AU.LIB_AB
        try:
            AU.LIB_AB = int(tauA[0])
            B_ = AU.bibliothek(A_, Fk_, "BTC")
        finally:
            AU.LIB_AB = alt_lib
        Rc = rueckblick_coin(A_, Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
        abw = []
        for i_ in (0, len(Rc["tau"]) // 2, len(Rc["tau"]) - 1):
            j_ = int(np.searchsorted(tauA, Rc["tau"][i_]))
            S_ = AU.szenarien(B_, AU.bib_bis(B_, int(tauA[j_])), Fk_[j_])
            gr_ = lambda v_: min(max(v_, 0.005), 0.995)                 # noqa: E731 -- wie die Anzeige: Raster 0,5 % bis 99,5 %
            abw.append(abs(gr_(AU.erreichen(S_, math.log(0.9), 7)[0]) - Rc["p7"][i_]) + abs(gr_(AU.erreichen(S_, math.log(0.93), 2)[0]) - Rc["p2"][i_]))
            lo7 = np.nanmin(np.log(LA_[j_ + 4: j_ + 29: 4])) - lcA[j_]; lo2 = np.nanmin(np.log(LA_[j_ + 4: j_ + 9: 4])) - lcA[j_]
            abw.append(abs(float(lo7 <= math.log(0.9)) - Rc["ja7"][i_]) + abs(float(lo2 <= math.log(0.93)) - Rc["ja2"][i_]))
        ok("R2 Rückblick eines Coins gegen den Ausblick selbst: p7 und p2 an drei Ursprüngen gleich hl_ausblick.szenarien/erreichen; "
           "eingetreten = kleinstes Tief der Tagesblöcke der nächsten 7 bzw. 2 Tage, von Hand",
           len(Rc["tau"]) > 300 and max(abw) < 1e-12 and all(int(t) % TAG == 0 and t >= AU.OOS_AB for t in Rc["tau"]) and Rc["ohne_faktor"] == 0
           and 0 < Rc["ja7"].mean() < 1 and Rc["ja2"].sum() <= Rc["ja7"].sum(), f"{len(Rc['tau'])} Ursprünge, größte Abweichung {max(abw):.2e}, Quote {Rc['ja7'].mean():.3f}")
        i0 = next((i_ for i_ in range(1, len(Rc["tau"])) if Rc["ja7"][i_] == 0 and Rc["ja7"][i_ - 1] == 0 and Rc["ja2"][i_] == 0 and Rc["ja2"][i_ - 1] == 0
                   and Rc["tau"][i_] - Rc["tau"][i_ - 1] == TAG), None)
        if i0 is not None:
            j0 = int(np.searchsorted(tauA, Rc["tau"][i0]))
            L7_ = LA_.copy(); L7_[j0 + 28] = CA[j0] * 0.5                    # ein Tief von −50 % genau im siebten Tagesblock nach dem Ursprung
            L2_ = LA_.copy(); L2_[j0 + 8] = CA[j0] * 0.5                     # … genau im zweiten Tagesblock
            R7_ = rueckblick_coin(dict(A_, L=L7_), Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
            R2_ = rueckblick_coin(dict(A_, L=L2_), Fk_, B_, lambda tag: 1.0, AU.JE_TAG, AU.OOS_AB)
        ok("R14 Fristen des Rückblicks von Hand: ein Tief im siebten Tagesblock zählt für 7 Tage, für den Ursprung des Vortags (achter Block) nicht; "
           "ein Tief im zweiten Block zählt für 48 Stunden, für den Ursprung des Vortags (dritter Block) nur für 7 Tage; die Zahlen selbst ändern sich nicht",
           i0 is not None and len(R7_["tau"]) == len(Rc["tau"]) and R7_["ja7"][i0] == 1 and R7_["ja7"][i0 - 1] == 0 and R7_["ja2"][i0] == 0
           and R2_["ja2"][i0] == 1 and R2_["ja7"][i0] == 1 and R2_["ja2"][i0 - 1] == 0 and R2_["ja7"][i0 - 1] == 1
           and np.array_equal(R7_["p7"], Rc["p7"]) and np.array_equal(R2_["p2"], Rc["p2"]), f"Ursprung {i0}")
        Rf = rueckblick_coin(A_, Fk_, B_, lambda tag: (None if tag % 2 else 1.5), AU.JE_TAG, AU.OOS_AB)
        Rsp = rueckblick_coin(A_, Fk_, B_, lambda tag: 1.0, AU.JE_TAG, int(tauA[-1]) + TAG)
        Rgr = rueckblick_coin(A_, Fk_, B_, lambda tag: 8.0, AU.JE_TAG, AU.OOS_AB)                # Schwelle −80 %: kein Szenario erreicht sie
        ok("R13 Rückblick wie die Anzeige: Die Zahl ist auf das Raster 0,5 % bis 99,5 % begrenzt -- erreicht kein Szenario die Schwelle, zählt der "
           "Ursprung mit 0,5 % (nicht mit 0); nichts liegt außerhalb",
           len(Rgr["tau"]) == len(Rc["tau"]) and float(Rgr["p7"].max()) == 0.005 == float(Rgr["p7"].min()) and Rgr["ja7"].sum() == 0
           and Rc["p7"].min() >= 0.005 and Rc["p7"].max() <= 0.995 and Rc["p2"].min() >= 0.005 and (Rc["p2"] == 0.005).any() and AU.LAUF_Q[0] == 0.005
           and AU.LAUF_Q[-1] == 0.995, f"p7 {Rgr['p7'].min()}–{Rgr['p7'].max()}; p2 kleinste {Rc['p2'].min()}")
        ok("R3 Rückblick: ohne Faktor zählt der Ursprung nicht (gezählt als ausgelassen); größerer Faktor -> kleinere Zahl; keine Ursprünge vor dem Beginn",
           Rf["ohne_faktor"] > 100 and len(Rf["tau"]) + Rf["ohne_faktor"] == len(Rc["tau"]) and Rf["p7"].mean() < Rc["p7"].mean() and len(Rsp["tau"]) == 0)
        nG = 6000; tG = np.repeat(np.arange(3000) * TAG, 2); cG = np.tile(np.array(["BTC", "ETH"]), 3000)
        pw = np.clip(rng.beta(1.2, 9.0, nG), 0.002, 0.9); yG = (rng.random(nG) < pw).astype(float); gG = np.full(nG, yG.mean())
        U1 = g_urteil("e7", tG, cG, pw, yG, gG, seed=1)
        U2 = g_urteil("e7", tG, cG, np.clip(pw ** 2 * 4, 0.0005, 0.99), yG, gG, seed=1)        # zu stark gespreizt: Steigung um 0,5
        U3 = g_urteil("e7", tG, cG, rng.permutation(pw), yG, gG, seed=1)                        # ohne Zusammenhang
        pb = np.where(rng.random(nG) < 0.5, 0.02, 0.40); yb = (rng.random(nG) < pb).astype(float); gb = np.full(nG, yb.mean())
        U4 = g_urteil("e7", tG, cG, pb * 1.3, yb, gb, seed=1)                                   # trennt gut, liegt aber im Mittel 1,3-mal zu hoch
        U4k = g_urteil("e7", tG, cG, pb, yb, gb, seed=1)                                        # dieselbe Zahl ohne den Fehler besteht
        U5 = g_urteil("e7", tG[:1200], cG[:1200], pw[:1200], yG[:1200], gG[:1200], seed=1)      # 600 Tage
        ok("R4 Urteil: eine richtig gestufte Zahl besteht (Skill > 0, p < 0,05, Steigung 0,8–1,2, Niveau 0,8–1,25)",
           U1["besteht"] is True and U1["skill"] > 0.02 and U1["p"] < 0.05 and 0.8 <= U1["steigung"] <= 1.2 and 0.8 <= U1["niveau"] <= 1.25 and U1["n"] == nG
           and U1["n_tage"] == 3000 and U1["n_ereignisse"] == int(yG.sum()) and U1["grund"] is None and set(U1["je_coin"]) == {"BTC", "ETH"},
           f"Skill {U1['skill']:.3f}, p {U1['p']:.4f}, Steigung {U1['steigung']:.2f}, Niveau {U1['niveau']:.2f}")
        ok("R5 Urteil fällt durch -- mit dem Grund: zu stark gespreizte Zahl an der Steigung; Zahl ohne Zusammenhang am Skill; im Mittel zu hohe Zahl am Niveau; "
           "600 Tage an der Historie",
           U2["besteht"] is False and "schlägt zu stark aus" in (U2["grund"] or "") and U3["besteht"] is False and "nicht belegbar besser" in (U3["grund"] or "")
           and U4["besteht"] is False and (U4["grund"] or "").startswith("Niveau") and 1.25 < U4["niveau"] < 1.36 and U4["skill"] > 0 and U4["p"] < 0.05
           and 0.8 <= U4["steigung"] <= 1.2 and U4k["besteht"] is True
           and U5["besteht"] is False and "zu wenig Historie" in (U5["grund"] or "") and U5["n_tage"] == 600,
           f"{U2['grund']} | {U3['grund']} | {U4['grund']} | {U5['grund']}")
        nD = 2000; iD = np.arange(nD); yD = (iD % 10 == 0).astype(float)      # jeder zehnte Tag ein Ereignis; Grundrate 0,1
        pD = np.where(iD < 1000, np.where(yD == 1, 0.6, 0.05), np.where(yD == 1, 0.03, 0.26))   # erste Hälfte trifft gut, zweite daneben
        U6 = g_urteil("e7", iD * TAG, np.full(nD, "BTC"), pD, yD, np.full(nD, 0.1), seed=1)
        bg_h = 0.1 * 0.81 + 0.9 * 0.01; bp_h = 0.5 * (0.1 * 0.16 + 0.9 * 0.0025) + 0.5 * (0.1 * 0.9409 + 0.9 * 0.0676)
        ok("R15 Urteil von Hand: Brier der Zahl 0,08659 gegen Brier der Grundrate 0,09 -> Skill +3,8 %; der Vorsprung kommt nur aus der ersten "
           "Hälfte der Tage und ist nicht belegt (p über 0,05) -> besteht nicht, mit dem Grund",
           abs(U6["brier"] - bp_h) < 1e-12 and abs(U6["brier_grund"] - bg_h) < 1e-12 and abs(U6["skill"] - (1 - bp_h / bg_h)) < 1e-12
           and abs(bp_h - 0.08659) < 1e-12 and U6["p"] is not None and U6["p"] >= 0.05 and U6["besteht"] is False and U6["n_tage"] == 2000
           and U6["n_ereignisse"] == 200 and _drin("nicht belegbar besser", U6["grund"]) and _drin("Skill +3,8 %", U6["grund"]),
           f"Skill {U6['skill']:.4f}, p {U6['p']}, {U6['grund']}")
        zv = U1["zuverlaessigkeit"]
        ok("R6 Zuverlässigkeit in den sechs Klassen: Zahl der Ursprünge summiert sich, vorhergesagt liegt in der Klasse, eingetreten im Band",
           sum(k[2] for k in zv) == nG and all(k[0] <= k[3] < k[1] + 1e-9 for k in zv) and all(k[5] <= k[4] <= k[6] for k in zv) and len(zv) >= 5, f"{[(k[0], k[2]) for k in zv]}")
        ps = np.linspace(0.0, 0.99, 100); js = (np.arange(100) % 4 == 0).astype(float)
        sw = schwellen_bauen(ps, js)
        ok("R7 Grundrate und Schwellen eines Coins: Anteil der Ereignisse; 80., 90., 95., 97,5. und 99. Perzentil der Rückblick-Werte; Niveau = Mittel ÷ Quote; "
           "unter 100 Ursprüngen nichts",
           sw["grundrate"] == 0.25 and abs(sw["q"]["0.8"] - 0.792) < 1e-9 and abs(sw["q"]["0.95"] - 0.9405) < 1e-9 and set(sw["q"]) == {"0.8", "0.9", "0.95", "0.975", "0.99"}
           and abs(sw["niveau"] - 0.495 / 0.25) < 1e-9 and schwellen_bauen(ps[:99], js[:99]) == {"n": 99, "grundrate": None, "q": {}, "niveau": None}, f"{sw}")
        tt = np.arange(0, 20) * TAG
        pp = np.array([0.1, 0.5, 0.45, 0.41, 0.39, 0.2, 0.6, 0.3, 0.5, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.55, 0.5, 0.1, 0.1, 0.1])
        jj = np.array([0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0], dtype=float)
        at = alarm_tabelle(tt, pp, jj, 0.5)
        ok("R8 Tabelle der Alarme von Hand (Schwelle 0,5, Ende unter 0,4): vier Eintritte, sieben Tage „hoch“, ein Treffer; drei Ereignis-Episoden, eine davon gedeckt",
           at["eintritte"] == 4 and at["tage_hoch"] == 7 and at["treffer"] == 1 and at["episoden"] == 3 and at["gedeckt"] == 1
           and abs(at["je_jahr"] - 4 / (19 / 365.25)) < 1e-9 and alarm_tabelle(tt, pp, jj, None)["eintritte"] == 0, f"{at}")
        Rw = {"BTC": {"tau": tG[::2], "p7": pw[::2], "p2": pw[::2] * 0.5, "ja7": yG[::2], "ja2": (rng.random(3000) < pw[::2] * 0.5).astype(float), "ohne_bib": 3, "ohne_faktor": 0},
              "ETH": {"tau": tG[1::2], "p7": pw[1::2], "p2": pw[1::2] * 0.5, "ja7": yG[1::2], "ja2": (rng.random(3000) < pw[1::2] * 0.5).astype(float), "ohne_bib": 0, "ohne_faktor": 5},
              "HYPE": {"tau": np.array([], dtype=np.int64), "p7": np.array([]), "p2": np.array([]), "ja7": np.array([]), "ja2": np.array([]), "ohne_bib": 0, "ohne_faktor": 0}}
        RA = rueckblick_auswerten(Rw)
        ok("R9 Auswertung über alle Coins: zwei Urteile (G7, G2), je Coin und Ereignis Grundrate, Schwellen und Tabelle; ein Coin ohne Ursprünge fehlt",
           set(RA["urteil"]) == {"e7", "e2"} and RA["urteil"]["e7"]["besteht"] is True and set(RA["coins"]) == {"BTC", "ETH"} and RA["urteil"]["e7"]["n"] < nG
           and abs(RA["coins"]["BTC"]["e7"]["grundrate"] - yG[::2].mean()) < 1e-12 and RA["coins"]["BTC"]["e7"]["alarme"]["schwelle"] == RA["coins"]["BTC"]["e7"]["q"]["0.95"]
           and RA["ohne"]["ETH"] == {"bibliothek": 0, "faktor": 5} and rueckblick_auswerten({})["urteil"]["e7"]["besteht"] is False,
           f"G7 {RA['urteil']['e7']['besteht']}, G2 {RA['urteil']['e2']['besteht']}")
        rt = rueckblick_text(dict(RA, stand=jetzt, version=VERSION_MODUL, dauer=12.3, fehlt=["Probe-Hinweis"]))
        ok("R10 Bericht des Rückblicks: Kopf mit den Regeln, je Urteil ein Satz, Zuverlässigkeit, je Coin Grundrate und Schwellen, Lesart; keine Zeile über 150 Zeichen",
           "Rückblick des Grundrisikos" in rt and "== G7" in rt and "== G2" in rt and "— besteht." in " ".join(rt.split()) and "fehlt: Probe-Hinweis" in rt
           and "Zuverlässigkeit" in rt
           and "BTC 7 Tage" in rt and "Lesart:" in rt and max(len(z) for z in rt.split("\n")) <= ZEILE_MAX and "noch nicht gerechnet" in rueckblick_text(None),
           f"längste Zeile {max(len(z) for z in rt.split(chr(10)))}")

        # ---------------------------------------------------------------- Regel K: Nachkalibrierung (23.123)
        lgt = lambda v: np.log(v / (1 - v))                                     # noqa: E731
        p_od = np.clip(1 / (1 + np.exp(-(lgt(pw) + 0.3) / 0.7)), 0.005, 0.995)     # Rohzahl, die zu stark ausschlägt: logit(wahr) = −0,3 + 0,7 · logit(roh)
        ab = logit_anpassen(yG, p_od)
        ok("NK1 Anpassung von Hand geprüft: Schlägt die Rohzahl zu stark aus (wahr ist logit p = −0,3 + 0,7 · logit roh), findet die Regression "
           "a nahe −0,3 und b nahe 0,7; b ist die Steigung von hl_ausblick.logit_steigung; unter 30 Werten oder mit nur einem Ausgang keine Anpassung",
           ab is not None and abs(ab[0] + 0.3) < 0.2 and abs(ab[1] - 0.7) < 0.07 and abs(ab[1] - AU.logit_steigung(yG, p_od)) < 1e-9
           and logit_anpassen(yG[:29], p_od[:29]) is None and logit_anpassen(np.zeros(200), p_od[:200]) is None
           and logit_anpassen(np.r_[yG[:100], np.nan], np.r_[p_od[:100], 0.5]) == logit_anpassen(yG[:100], p_od[:100]), f"a {ab[0]:.3f}, b {ab[1]:.3f}")
        kz = kal_zahl(0.2, -0.3, 0.7)
        ok("NK2 kalibrierte Zahl von Hand: roh 20 %, a −0,3, b 0,7 -> logit −1,3863 · 0,7 − 0,3 = −1,2704 -> 21,9 %; die Rohzahl wird vorher auf "
           "0,5 % … 99,5 % begrenzt, das Ergebnis auch; ohne Zahl oder ohne Anpassung nichts",
           abs(kz - 1 / (1 + math.exp(1.3 * 0.7 * math.log(4) / 1.3 + 0.3))) < 1e-12 and abs(kz - 0.21917) < 1e-4
           and kal_zahl(0.00001, -0.3, 0.7) == kal_zahl(0.005, -0.3, 0.7) and kal_zahl(0.005, -9.0, 1.0) == 0.005 and kal_zahl(0.99, 9.0, 1.0) == 0.995
           and kal_zahl(None, 0.0, 1.0) is None and kal_zahl(0.2, None, 1.0) is None and abs(kal_zahl(0.37, 0.0, 1.0) - 0.37) < 1e-12, f"{kz:.5f}")
        d0 = calendar.timegm((2021, 12, 31, 0, 0, 0)) // TAG; jan23 = calendar.timegm((2023, 1, 1, 0, 0, 0)) // TAG; feb23 = calendar.timegm((2023, 2, 1, 0, 0, 0)) // TAG
        nK = 800; tK = (d0 + np.arange(nK)) * TAG; rk_ = np.random.default_rng(5)
        pK = np.clip(rk_.beta(1.5, 8.0, nK), 0.01, 0.9); yK = np.zeros(nK); yK[np.arange(1, 345, 7)] = 1.0; yK[400::5] = 1.0   # 50 Ereignisse an den Tagen 1, 8, … 344
        KA = kal_reihen(tK, pK, yK, 2, d0 + nK - 1)                              # Frist 2 Tage: am 01.01.2023 sind genau 365 Tage abgelaufen
        KB = kal_reihen(tK[1:], pK[1:], yK[1:], 2, d0 + nK - 1)                  # ein Tag weniger: 364
        y49 = yK.copy(); y49[344] = 0.0
        KC = kal_reihen(tK, pK, y49, 2, d0 + nK - 1)                             # 49 Ereignisse
        KD = kal_reihen(tK, pK, yK, 7, d0 + nK - 1)                              # Frist 7 Tage: am 01.01.2023 erst 360 Tage
        fA = {f[0]: f for f in KA["fits"]}; fB = {f[0]: f for f in KB["fits"]}; fC = {f[0]: f for f in KC["fits"]}; fD = {f[0]: f for f in KD["fits"]}
        i_jan = int(jan23 - d0) + 10; hand = logit_anpassen(yK[:365], pK[:365])
        ok("NK3 Anpassung je Monatserstem von Hand: Am 01.01.2023 sind bei 2 Tagen Frist genau 365 Ursprungstage mit 50 Ereignissen abgelaufen -> "
           "Anpassung (gleich der Regression über genau diese Tage), sie gilt für die Ursprünge des Januars; mit 364 Tagen oder 49 Ereignissen keine "
           "(erst im Februar); bei 7 Tagen Frist sind es am 01.01. erst 360 Tage; Ursprünge in Monaten ohne Anpassung haben keine kalibrierte Zahl",
           fA[jan23][3:] == [365, 50] and fA[jan23][1] is not None and abs(fA[jan23][1] - hand[0]) < 1e-12 and abs(fA[jan23][2] - hand[1]) < 1e-12
           and fB[jan23][3:] == [364, 50] and fB[jan23][1] is None and fB[feb23][1] is not None and fC[jan23][3:] == [365, 49] and fC[jan23][1] is None
           and fD[jan23][3] == 360 and fD[jan23][1] is None and fD[feb23][3] == 391
           and abs(KA["p"][i_jan] - kal_zahl(pK[i_jan], fA[jan23][1], fA[jan23][2])) < 1e-12 and not np.isfinite(KA["p"][:int(jan23 - d0)]).any()
           and np.isfinite(KA["p"][int(jan23 - d0):]).all() and not np.isfinite(KB["p"][:int(feb23 - d0) - 1]).any()
           and KA["fits"][0][0] == monatserster(d0) and KA["fits"][-1][0] == monatserster(d0 + nK - 1) and KA["aktuell"]["monat"] == KA["fits"][-1][0]
           and KA["aktuell"]["a"] == KA["fits"][-1][1] and kal_reihen(tK[:300], pK[:300], yK[:300], 2, d0 + 299)["aktuell"] is None
           and kal_reihen(np.array([], dtype=np.int64), np.array([]), np.array([]), 2, d0)["fits"] == [], f"01.01.2023: {fA[jan23]}")
        tgZ = np.arange(200); tZ = (19000 + tgZ).astype(np.int64) * TAG; rz_ = np.random.default_rng(8)
        pZ = np.where(tgZ % 4 == 0, 0.3, 0.1); yZ = (rz_.random(200) < pZ * 1.5).astype(float)
        KZ = kal_reihen(np.concatenate([tZ, tZ]), np.concatenate([pZ, pZ]), np.concatenate([yZ, yZ]), 2, 19000 + 260)
        ok("NK3b Ursprungstage, nicht Ursprünge: Zwei Coins über dieselben 200 Tage sind 400 Ursprünge, aber 200 Ursprungstage -- keine "
           "Anpassung (verlangt sind 365 Tage), auch wenn die Ereignisse reichen",
           KZ["fits"][-1][3] == 200 and KZ["fits"][-1][4] == int(2 * yZ.sum()) >= KAL_MIN_EREIGNISSE and all(f_[1] is None for f_ in KZ["fits"])
           and KZ["aktuell"] is None and not np.isfinite(KZ["p"]).any(), f"letzter Monat: {KZ['fits'][-1]}")
        p2K = pK.copy(); y2K = yK.copy(); schnitt = 560; p2K[schnitt:] = np.clip(p2K[schnitt:] * 3, 0.01, 0.9); y2K[schnitt:] = 1 - y2K[schnitt:]
        KE = kal_reihen(tK, p2K, y2K, 2, d0 + nK - 1); fE = {f[0]: f for f in KE["fits"]}
        frueh = [m_ for m_ in fA if m_ <= d0 + schnitt]; spaet = [m_ for m_ in fA if m_ > d0 + schnitt + 40]
        ok("NK4 kein Blick voraus: Werden Zahlen und Ausgänge ab einem Tag verändert, bleiben alle Anpassungen bis zu diesem Tag und alle "
           "kalibrierten Zahlen davor gleich; spätere Anpassungen ändern sich",
           all(fA[m_] == fE[m_] for m_ in frueh) and np.array_equal(KA["p"][:schnitt], KE["p"][:schnitt], equal_nan=True)
           and any(fA[m_] != fE[m_] for m_ in spaet) and len(frueh) > 15 and len(spaet) > 3, f"{len(frueh)} Monate gleich, {len(spaet)} später")
        y2G = (rng.random(nG) < pw * 0.5).astype(float); p2_od = np.clip(1 / (1 + np.exp(-(lgt(pw * 0.5) + 0.3) / 0.7)), 0.005, 0.995)
        Rod = {c_: {"tau": tG[i_::2], "p7": p_od[i_::2], "p2": p2_od[i_::2], "ja7": yG[i_::2], "ja2": y2G[i_::2], "ohne_bib": 0, "ohne_faktor": 0}
               for i_, c_ in ((0, "BTC"), (1, "ETH"))}
        RO = rueckblick_auswerten(Rod, 2999); k7 = RO["kal"]["e7"]; RA_k = RA["kal"]["e7"]
        ok("NK5 Rückblick mit Regel K: Eine Rohzahl, die zu stark ausschlägt, besteht nicht (Steigung um 0,7); die nachkalibrierte Fassung "
           "besteht dieselben Kriterien (Steigung näher an 1 als die der Rohzahl) -> die Karte nimmt sie; ihre Schwelle „hoch“ liegt tiefer als die der Rohzahl; die "
           "Anpassung des laufenden Monats liegt bei a −0,3, b 0,7",
           RO["urteil"]["e7"]["besteht"] is False and _drin("schlägt zu stark aus", RO["urteil"]["e7"]["grund"]) and k7["urteil"]["besteht"] is True
           and 0.8 <= k7["urteil"]["steigung"] <= 1.2 and abs(k7["urteil"]["steigung"] - 1) < abs(RO["urteil"]["e7"]["steigung"] - 1) and k7["besteht"] is True and RO["anzeige"] == {"e7": "kal", "e2": "kal"}
           and abs(k7["aktuell"]["a"] + 0.3) < 0.2 and abs(k7["aktuell"]["b"] - 0.7) < 0.07 and k7["aktuell"]["monat"] == monatserster(2999)
           and k7["coins"]["BTC"]["q"]["0.95"] < RO["coins"]["BTC"]["e7"]["q"]["0.95"] and k7["urteil"]["n_tage"] < RO["urteil"]["e7"]["n_tage"]
           and k7["coins"]["BTC"]["alarme"]["schwelle"] == k7["coins"]["BTC"]["q"]["0.95"] and len(k7["fits"]) > 90,
           f"roh Steigung {RO['urteil']['e7']['steigung']:.2f}; kalibriert {k7['urteil']['steigung']:.2f}, a {k7['aktuell']['a']:.2f}, b {k7['aktuell']['b']:.2f}")
        Rkurz = {c_: {k_: (v_[:600] if isinstance(v_, np.ndarray) else v_) for k_, v_ in Rod[c_].items()} for c_ in Rod}
        RK_ = rueckblick_auswerten(Rkurz, 599); leer_ = rueckblick_auswerten({})
        ok("NK6 Folge je Zahl: Besteht auch die Rohzahl (richtig gestuft), gilt trotzdem die nachkalibrierte (b nahe 1, fast dieselbe Zahl); mit zu "
           "kurzer Historie besteht die kalibrierte Fassung nicht -> es bleibt bei der Rohzahl; ohne Ursprünge ebenso",
           RA["urteil"]["e7"]["besteht"] is True and RA["anzeige"]["e7"] == "kal" and abs(RA_k["aktuell"]["b"] - 1.0) < 0.1 and abs(RA_k["aktuell"]["a"]) < 0.25
           and RK_["anzeige"] == {"e7": "roh", "e2": "roh"} and RK_["kal"]["e7"]["besteht"] is False and _drin("zu wenig Historie", RK_["kal"]["e7"]["urteil"]["grund"])
           and leer_["anzeige"] == {"e7": "roh", "e2": "roh"} and leer_["kal"] == {}, f"b {RA_k['aktuell']['b']:.2f}; kurz: {RK_['kal']['e7']['urteil']['grund']}")
        uk_ = {"besteht": True, "n": 6000, "n_tage": 1300, "n_ereignisse": 600, "skill": 0.07, "p": 0.001, "steigung": 1.02, "niveau": 1.0, "grund": None}

        def rb_kal(anz7="kal", anz2="kal", **kw):
            return _probe_rb_kal(jetzt, anz7, anz2, **kw)
        Lk = _probe_lauf(jetzt)
        Ek = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, rb_kal(), None)
        Er = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, rb_kal("roh", "roh"), None)
        E0 = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, _probe_rb(jetzt), None)
        Eo = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, rb_kal(e7={"aktuell": None}), None)
        Eu = ereignisse_bauen("BTC", Lk, None, {"f": 1.0}, 60000.0, True, jetzt, rb_kal(e7={"urteil": dict(uk_, besteht=False)}), None)
        p7r = E0["e7"]["p"]; p7k = kal_zahl(p7r, -0.3, 0.7); p2r = E0["e2"]["p"]
        ok("NK7 Anzeige nach Regel K4: gilt die nachkalibrierte Fassung, zeigt die Karte sie (7 Tage: roh 65 % -> 54 %, Stufe aus den Schwellen "
           "der kalibrierten Zahl: hoch ab 52 %), die Rohzahl steht als Vermerk dabei, der Satz des Urteils nennt G7k; die 48-Stunden-Zahl, deren "
           "Rohfassung nicht bestand, bekommt mit bestandener Kalibrierung Stufen; besteht die Kalibrierung nicht, bleibt alles wie ohne Regel K "
           "(7 Tage mit den Schwellen der Rohzahl, 48 Stunden „nicht bestätigt“); ohne Anpassung oder ohne bestandenes Urteil ebenso",
           abs(Ek["e7"]["p"] - p7k) < 1e-12 and abs(p7k - 0.5362) < 2e-3 and Ek["e7"]["p_roh"] == p7r and Ek["e7"]["kal"] is True and Ek["e7"]["stufe"] == "hoch"
           and Ek["e7"]["s_hoch"] == 0.52 and Ek["e7"]["s_erhoeht"] == 0.40 and _drin("nachkalibriert (roh 65 %)", Ek["e7"]["satz"]) and _drin("54 %", Ek["e7"]["satz"])
           and _drin("G7k (nachkalibriert)", Ek["e7"]["urteil"]) and _drin("besteht", Ek["e7"]["urteil"]) and Ek["e7"]["grundrate"] == 0.09
           and Ek["e2"]["kal"] is True and Ek["e2"]["besteht"] is True and Ek["e2"]["stufe"] in ("normal", "erhoeht", "hoch") and _drin("Stufe", Ek["e2"]["satz"])
           and abs(Ek["e2"]["p"] - kal_zahl(p2r, -0.2, 0.8)) < 1e-12
           and Er["e7"] == E0["e7"] and Er["e2"] == E0["e2"] and not Er["e7"].get("kal") and _drin("im Rückblick nicht bestätigt", Er["e2"]["satz"])
           and Eo["e7"] == E0["e7"] and Eu["e7"] == E0["e7"] and E0["e7"]["s_hoch"] == 0.64, f"{Ek['e7']['satz']} | {Ek['e2']['satz']}")
        Ee_ = ereignisse_bauen("ETH", Lk, None, {"f": 3.5}, 2000.0, True, jetzt, rb_kal(), None)["e7"]
        Ef_ = ereignisse_bauen("BTC", None, "kein Lauf", {"f": 1.0}, 60000.0, True, jetzt, rb_kal(), None)["e7"]
        ok("NK8 Ränder: Liegt die Rohzahl unter dem Raster („unter 0,5 %“), zählt sie wie im Rückblick mit 0,5 % -> kalibriert 1,8 %, die Rohzahl "
           "steht als „roh unter 0,5 %“ dabei; ein Coin ohne Schwellen der kalibrierten Zahl bleibt ohne Stufe; ohne Zahl (keine Verteilung) "
           "steht der Grund da, das Urteil ist trotzdem das der kalibrierten Fassung",
           abs(Ee_["p"] - kal_zahl(0.005, -0.3, 0.7)) < 1e-12 and Ee_["p_text"] == "1,8 %" and Ee_["p_roh_text"] == "unter 0,5 %" and Ee_["stufe"] == "ohne"
           and _drin("roh unter 0,5 %", Ee_["satz"]) and _drin("ohne Stufe", Ee_["satz"]) and Ef_["p"] is None and Ef_["kal"] is True
           and "p_roh" not in Ef_ and _drin("G7k", Ef_["urteil"]) and _drin("keine Zahl", Ef_["satz"]), f"{Ee_['satz']}")
        rt_k = rueckblick_text(dict(RO, stand=jetzt, version=VERSION_MODUL, dauer=3.0, fehlt=[]))
        rt_r = rueckblick_text(dict(RK_, stand=jetzt, version=VERSION_MODUL, dauer=3.0, fehlt=[]))
        Sk = stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, Lk, None, {"f": 1.0}, rb_kal(), None, None, _probe_cockpit(),
                         {k_: {"roh": None, "pz": None, "tag": None, "grau": "Probe"} for k_ in ("a3", "a4", "a7")},
                         {"a5": {"roh": None, "pz": None, "grau": "Probe"}, "a6": {"roh": None, "pz": None, "grau": "Probe"}}, None)
        Kk = karte_bauen(Sk, dict(EINSTELLUNG_VORGABE), [], [], None, True, jetzt)
        Sr = stand_bauen("BTC", jetzt, 60000.0, jetzt - 30, True, Lk, None, {"f": 1.0}, _probe_rb(jetzt), None, None, _probe_cockpit(),
                         {k_: {"roh": None, "pz": None, "tag": None, "grau": "Probe"} for k_ in ("a3", "a4", "a7")},
                         {"a5": {"roh": None, "pz": None, "grau": "Probe"}, "a6": {"roh": None, "pz": None, "grau": "Probe"}}, None)
        ok("NK9 Bericht und Karte: Debug 161 trägt den Abschnitt „Nachkalibrierung“ mit dem Urteil G7k und G2k, der Anpassung des laufenden Monats, "
           "Beispielen roh -> kalibriert, der Folge und den Schwellen der kalibrierten Zahl (keine Zeile über 150 Zeichen); besteht sie nicht, steht "
           "„bleibt bei der Rohzahl“ bzw. „bleibt matt“; die Karte erklärt „nachkalibriert“ im Beleg nur, wenn eine Zahl nachkalibriert ist",
           "== Nachkalibrierung (Regel K" in rt_k and "G7k · 7 Tage:" in rt_k and "G2k · 48 Stunden:" in rt_k and "Beispiele (roh -> kalibriert):" in rt_k
           and "Folge: Die Karte zeigt die nachkalibrierte Zahl" in rt_k and "laufender Monat" in rt_k and "zweite Prüfung auf denselben Daten" in rt_k
           and max(len(z_) for z_ in rt_k.split("\n")) <= ZEILE_MAX and ("Die Zahl bleibt matt" in rt_r or "bleibt bei der Rohzahl" in rt_r)
           and max(len(z_) for z_ in rt_r.split("\n")) <= ZEILE_MAX and Kk["beleg"].get("kal") == KAL_VERMERK and "kal" not in karte_bauen(Sr, dict(EINSTELLUNG_VORGABE), [], [], None, True, jetzt)["beleg"]
           and json.dumps(_ohne_nan(Kk), allow_nan=False) is not None and Kk["ereignis"]["e7"]["p_roh_text"] == "65 %",
           f"{len(rt_k.splitlines())} Zeilen, längste {max(len(z_) for z_ in rt_k.split(chr(10)))}")

        import copy
        X1 = copy.deepcopy(RO); X1["anzeige"]["e7"] = "roh"; X1["kal"]["e7"]["besteht"] = False
        X1["kal"]["e7"]["urteil"] = dict(X1["kal"]["e7"]["urteil"], besteht=False, grund="Probe: Steigung 0,71 außerhalb")
        X2 = copy.deepcopy(RA); X2["anzeige"]["e7"] = "roh"
        eins_ = lambda R_: " ".join(rueckblick_text(dict(R_, stand=jetzt, version=VERSION_MODUL, dauer=3.0, fehlt=[])).split())
        rt_1, rt_2, rt_ke = eins_(X1), eins_(X2), " ".join(rt_k.split())
        t7 = lambda s_: s_.split("G7k · 7 Tage:")[1].split("G2k · 48 Stunden:")[0] if "G7k · 7 Tage:" in s_ and "G2k · 48 Stunden:" in s_ else ""
        t2_ = lambda s_: s_.split("G2k · 48 Stunden:")[1] if "G2k · 48 Stunden:" in s_ else ""
        f_kal = "Folge: Die Karte zeigt die nachkalibrierte Zahl; Stufen, Schwellen und Alarm gelten für sie."
        ok("NK9b Debug 161, Folge und Namen je Fall: Gilt die kalibrierte Fassung, heißt es „Die Karte zeigt die nachkalibrierte Zahl“; gilt sie "
           "nicht und die Rohzahl bestand, „bleibt bei der Rohzahl“; gilt sie nicht und die Rohzahl fiel durch, „bleibt matt“. Jeder Satz "
           "nennt sein eigenes Urteil (G7k für 7 Tage, G2k für 48 Stunden) und bei „nicht bestätigt“ den Grund",
           RO["urteil"]["e7"]["besteht"] is False and RA["urteil"]["e7"]["besteht"] is True
           and f_kal in t7(rt_ke) and f_kal in t2_(rt_ke) and " Rückblick G7k (nachkalibriert) vom " in t7(rt_ke) and " Rückblick G2k (nachkalibriert) vom " in t2_(rt_ke)
           and "G7k" not in t2_(rt_ke) and "— besteht." in t7(rt_ke) and "— besteht." in t2_(rt_ke)
           and "— nicht bestätigt: Probe: Steigung 0,71 außerhalb." in t7(rt_1) and "— besteht." not in t7(rt_1)
           and "Folge: Die Zahl bleibt matt, ohne Stufe und ohne Alarm." in t7(rt_1) and "bleibt bei der Rohzahl" not in t7(rt_1) and f_kal in t2_(rt_1)
           and "Folge: Die Karte bleibt bei der Rohzahl mit ihren Stufen und ihrem Alarm." in t7(rt_2) and "bleibt matt" not in t7(rt_2),
           t7(rt_1)[-120:])
        # K4, beide Bedingungen -- Urteil und Anpassung des laufenden Monats (die Rechnung dahinter für die Dauer der Probe ersetzt)
        alt_gu, alt_kr = globals()["g_urteil"], globals()["kal_reihen"]
        ak_ = {"monat": 19000, "a": 0.0, "b": 1.0, "n_tage": 400, "n_ereignisse": 60}
        try:
            arg_ = ("e7", EREIGNIS["e7"], {"BTC": {}}, np.arange(5, dtype=np.int64) * TAG, np.array(["BTC"] * 5), np.full(5, 0.1), np.zeros(5), np.full(5, 0.1), 19010)
            globals()["g_urteil"] = lambda key_, *a_, **k_: {"besteht": True, "n": 5, "grund": None}
            globals()["kal_reihen"] = lambda tau_, p_, ja_, h_, bt_: {"p": np.asarray(p_, dtype=float), "fits": [[19000, None, None, 5, 0]], "aktuell": None}
            o_a = {}; kal_auswerten(o_a, *arg_)
            globals()["kal_reihen"] = lambda tau_, p_, ja_, h_, bt_: {"p": np.asarray(p_, dtype=float), "fits": [[19000, 0.0, 1.0, 400, 60]], "aktuell": dict(ak_)}
            o_b = {}; kal_auswerten(o_b, *arg_)
            globals()["g_urteil"] = lambda key_, *a_, **k_: {"besteht": False, "n": 5, "grund": "Probe"}
            o_c = {}; kal_auswerten(o_c, *arg_)
        finally:
            globals()["g_urteil"], globals()["kal_reihen"] = alt_gu, alt_kr
        ok("NK11 Regel K4, beide Bedingungen: Die kalibrierte Fassung gilt nur, wenn ihr Urteil besteht UND die Anpassung des laufenden Monats "
           "vorliegt -- besteht das Urteil ohne Anpassung, bleibt es bei der Rohzahl; liegt die Anpassung vor und das Urteil besteht nicht, ebenso",
           o_a["anzeige"]["e7"] == "roh" and o_a["kal"]["e7"]["besteht"] is False and o_b["anzeige"]["e7"] == "kal" and o_b["kal"]["e7"]["besteht"] is True
           and o_b["kal"]["e7"]["aktuell"] == ak_ and o_c["anzeige"]["e7"] == "roh" and o_c["kal"]["e7"]["besteht"] is False,
           f"{o_a['anzeige']} {o_b['anzeige']} {o_c['anzeige']}")

        tmpk = tempfile.mkdtemp(prefix="hl_radar_nk_")
        try:
            dbk = os.path.join(tmpk, "hl_liq.db"); conk = verbinden(os.path.join(tmpk, "radar.db"))   # eigene Datei, nicht der umgelenkte Ort der Proben davor
            def stand_k(db, coin, jetzt_, gemeinsam=None, rb=None, zust=None, einst=None, con_r=None):
                S_ = _probe_stand(coin, jetzt_, 0.54, "normal")
                if coin == "BTC":
                    S_["ereignis"]["e7"].update({"kal": True, "p_roh": 0.65})
                S_["zeit"] = {"cockpit": 0.5, "orderbuch": 0.25}
                return S_
            tk_ = takt_schritt(dbk, conk, jetzt, http_fn=lambda *a_, **k_: (200, "ok"), push_ein={"thema": None}, starte_rb=lambda d_: False,
                               stand_fn=stand_k, gemeinsam_fn=lambda db_, j_: {})
            zk = {c_: json.loads(j_) for c_, j_ in conk.execute("SELECT coin, json FROM rd_stand")}
            takt_k = meta(conk, "takt")
            conk.close()
        finally:
            shutil.rmtree(tmpk, ignore_errors=True)
        ok("NK10 Ablage je Stunde: Bei einer nachkalibrierten Zahl steht die Rohzahl mit im abgelegten Stand (für die spätere Bilanz); bei einem "
           "Coin ohne nachkalibrierte Zahl steht nichts dazu",
           tk_["abgelegt"] == 5 and zk["BTC"].get("roh") == {"e7": 0.65} and zk["BTC"]["e"]["e7"]["p"] == 0.54 and "roh" not in zk["ETH"], f"{zk.get('BTC')}")
        ok("NK10b Rechenzeit im Takt: Die Teile aller gerechneten Coins werden zusammengezählt (fünf Coins mit je 0,5 s und 0,25 s -> 2,5 s und "
           "1,25 s) und mit der Dauer des Schritts festgehalten",
           tk_.get("zeit") == {"cockpit": 2.5, "orderbuch": 1.25} and (takt_k or {}).get("zeit") == {"cockpit": 2.5, "orderbuch": 1.25}
           and isinstance((takt_k or {}).get("dauer_s"), float) and takt_k["dauer_s"] == tk_["dauer_s"] and len(takt_k.get("coins") or []) == 5, f"{takt_k}")
        # ---------------------------------------------------------------- Urteil der Regeln R1 bis R7 in Karte und Bericht (23.123)
        rg = _probe_regeln(jetzt)
        kz = regeln_kurz(rg)
        ok("RG1 Kurzform des abgelegten Urteils der Regeln: je Ereignis die belegten und die prüfbaren Regeln; kein Urteil, solange nichts "
           "abgelegt ist, die Historie unvollständig war, die Fassung eine andere ist oder die Tafel leer ist",
           kz == {"ts": jetzt - 3600, "fassung": REGELN_FASSUNG, "belegt": {"e7": ["r1", "r7"], "e2": []},
                  "pruefbar": {"e7": ["r1", "r2", "r3", "r4", "r5", "r7"], "e2": ["r1", "r2", "r3", "r4", "r5", "r7"]}, "coins": ["BTC", "ETH"]}
           and regeln_kurz(dict(rg, coins=None))["coins"] == []
           and regeln_kurz(None) is None and regeln_kurz("x") is None and regeln_kurz(_probe_regeln(jetzt, voll=False)) is None
           and regeln_kurz(_probe_regeln(jetzt, fassung=REGELN_FASSUNG + 1)) is None and regeln_kurz(dict(rg, tests={})) is None
           and regeln_kurz(dict(rg, tests=None)) is None, f"{kz}")
        S_rg = {"index": {"wert": 61.0, "text": "Druck-Index 61 von 100 (Mittel aus 5 Achsen) — gemessen, ungeprüft."}}
        S_r7 = regeln_anhaengen(json.loads(json.dumps(S_rg)), rg)
        S_n7 = regeln_anhaengen(json.loads(json.dumps(S_rg)), _probe_regeln(jetzt, belegt7=("r1",), belegt2=()))
        S_b7 = regeln_anhaengen(json.loads(json.dumps(S_rg)), _probe_regeln(jetzt, belegt7=("r7",), belegt2=("r7", "r3")))
        S_o = regeln_anhaengen(json.loads(json.dumps(S_rg)), None)
        S_k = regeln_anhaengen({"index": {"wert": None, "text": "Druck-Index: kein Wert (3 von 5 Achsen, gebraucht werden 4; es fehlen X)."}}, rg)
        ok("RG2 Satz und Vermerk: Ohne Urteil steht „noch nicht geprüft“ und der Druck-Index bleibt „gemessen, ungeprüft“; mit Urteil nennt der "
           "Satz je Zahl die belegten Regeln mit Nummer und Namen (oder „keine belegt“) und sagt, was „belegt“ heißt; der Druck-Index trägt das Ergebnis von R7 "
           "(belegt für … / nicht belegt); ein Index ohne Wert bleibt unverändert; der Satz der Grenzen verweist auf die Prüfung der Regeln "
           "(nicht mehr auf ein kommendes Paket)",
           S_o["regeln"] is None and S_o["regeln_satz"].startswith("Warnzeichen R1 bis R7: noch nicht geprüft (Debug 163")
           and S_o["index"]["text"] == S_rg["index"]["text"]
           and S_r7["regeln_satz"] == (f"Warnzeichen R1 bis R7 (Debug 163, geprüft {_dt(jetzt - 3600)}): für 7 Tage belegt: R1 Kontenquote, R7 Druck-Index; "
                                       "für 48 Stunden keine belegt. Belegt heißt: häufiger als sonst, nicht: es kommt.")
           and S_r7["index"]["text"] == "Druck-Index 61 von 100 (Mittel aus 5 Achsen) — gemessen; als Warnzeichen geprüft (R7): belegt für 7 Tage."
           and S_n7["index"]["text"] == "Druck-Index 61 von 100 (Mittel aus 5 Achsen) — gemessen; als Warnzeichen geprüft (R7): nicht belegt."
           and S_b7["index"]["text"].endswith("(R7): belegt für 7 Tage und 48 Stunden.") and "für 48 Stunden belegt: R3 Funding-Niveau, R7 Druck-Index" in S_b7["regeln_satz"]
           and regeln_satz({"ts": jetzt, "belegt": {"e7": ["r9"], "e2": []}}).count("belegt: R9;") == 1 and len(REGELN_NAMEN) == 7
           and S_k["index"]["text"] == "Druck-Index: kein Wert (3 von 5 Achsen, gebraucht werden 4; es fehlen X)." and S_k["regeln"] == kz
           and S_r7["regeln"] == kz and GRENZEN.endswith("sagt die Prüfung der Regeln R1 bis R7 (Debug 163; das Urteil steht im Beleg).")
           and "Paket 23.123" not in GRENZEN, S_r7["regeln_satz"])
        nk_ = _probe_nutzlast(jetzt, kal=True, regeln=rg)
        ok("RG3 Vorlage der Karte mit Regel K und Urteil der Regeln: beide Zahlen tragen „kal“ und die Rohzahl, der Beleg erklärt „nachkalibriert“, "
           "der Satz der Regeln und der Vermerk am Druck-Index stehen in der Antwort; ohne beides fehlt der Vermerk und der Satz sagt „noch nicht geprüft“",
           nk_["ereignis"]["e7"]["kal"] is True and nk_["ereignis"]["e7"]["p_roh_text"] == "65 %" and nk_["ereignis"]["e2"]["kal"] is True
           and nk_["beleg"]["kal"] == KAL_VERMERK and nk_["regeln_satz"] == S_r7["regeln_satz"] and "(R7): belegt für 7 Tage." in nk_["index"]["text"]
           and "kal" not in _probe_nutzlast(jetzt)["beleg"] and "noch nicht geprüft" in _probe_nutzlast(jetzt)["regeln_satz"]
           and _probe_nutzlast(jetzt)["index"]["text"].endswith("— gemessen, ungeprüft.") and not _probe_nutzlast(jetzt)["ereignis"]["e7"].get("kal"),
           f"{nk_['ereignis']['e7']['p_text']} (roh {nk_['ereignis']['e7'].get('p_roh_text')})")

        # Sperre: ein Rückblick zur selben Zeit
        sp1 = RbSperre(dbp); sp2 = RbSperre(dbp)
        n1 = sp1.nehmen(); n2 = sp2.nehmen(); belegt = rueckblick_rechnen(dbp, log=lambda *a: None)
        sp1.lassen(); n3 = sp2.nehmen(); sp2.lassen(); sp2.lassen()
        ok("R11 Sperre: während ein Lauf den Rückblick rechnet, rechnet ein zweiter nicht (Antwort „läuft“); nach dem Ende ist sie wieder frei; "
           "die Sperrdatei liegt neben radar.db",
           n1 is True and n2 is False and belegt == {"laeuft": True} and n3 is True and sp1.datei == pfad(dbp) + ".rueckblick.lock"
           and os.path.exists(sp1.datei) and sp1.fd is None and sp2.fd is None, f"{n1} {n2} {belegt} {n3}")
        zeit_ = {"t": 0.0}; logs_ = []; rufe_ = []
        def rechnen_belegt(db, log=None):
            rufe_.append(zeit_["t"])
            return {"laeuft": True}
        cs = verbinden(pfad(dbp))
        cs.execute("DELETE FROM rd_meta WHERE k='rueckblick'")
        h1 = rueckblick_holen(dbp, log=logs_.append, warten_s=12, schlaf=lambda s_: zeit_.__setitem__("t", zeit_["t"] + s_), uhr=lambda: zeit_["t"], rechnen=rechnen_belegt)
        def rechnen_fertig(db, log=None):
            rufe_.append("fertig")
            return {"version": VERSION_MODUL, "stand": jetzt, "neu": True}
        h2 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        meta_setzen(cs, "rueckblick", {"version": VERSION_MODUL, "stand": jetzt, "alt": True})
        h3 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        meta_setzen(cs, "rueckblick", {"version": "2026-09-23.000", "stand": jetzt})
        h4 = rueckblick_holen(dbp, log=logs_.append, rechnen=rechnen_fertig)
        cs.execute("DELETE FROM rd_meta WHERE k='rueckblick'"); cs.close()
        ok("R12 Debug 161 holt den Rückblick: rechnet ein anderer Lauf, wartet er (alle 5 s ein Blick, höchstens die Frist) und meldet dann „nichts“; "
           "fehlt er, rechnet er; liegt einer dieser Fassung vor, liest er nur; einer aus einer anderen Fassung wird neu gerechnet",
           h1 == (None, False, True) and rufe_[:5] == [0.0, 5.0, 10.0, 15.0, "fertig"] and h2 == ({"version": VERSION_MODUL, "stand": jetzt, "neu": True}, True, False)
           and h3 == ({"version": VERSION_MODUL, "stand": jetzt, "alt": True}, False, False) and h4[1] is True and h4[0]["neu"] is True
           and rufe_.count("fertig") == 2 and sum("wartet bis zu 0 Minuten" in l_ for l_ in logs_) == 1
           and sum("rechnet ihn jetzt" in l_ for l_ in logs_) == 3, f"{h1} {rufe_} {len(logs_)}")

        # ---------------------------------------------------------------- Regel A: Aufschlag für belegte Zeichen (23.124)
        for abschnitt in PROBEN_AUF:
            try:
                abschnitt(ok, jetzt)
            except Exception as e:  # noqa: BLE001 -- ein Abbruch in einem Abschnitt ist eine gescheiterte Probe, kein Abbruch des Selbsttests
                ok(f"{abschnitt.__name__}: Abbruch -- die Proben dieses Abschnitts ab hier fehlen", False, f"{type(e).__name__}: {e}"[:300])

        # ---------------------------------------------------------------- Bericht
        S_voll = {"ok": True, "coin": "BTC", "jetzt": jetzt, "kurs": {"px": 60000.0, "ts": jetzt - 30, "frisch": True}, "faktor": {"f": 1.0}, "ereignis": E,
                  "achsen": AX, "index": I4, "treiber": treiber_satz(AX), "warnzeichen": warnzeichen_bauen(Bc)}
        st_ = "\n".join(_umbruch(stand_text(S_voll)))
        ok("X1 Stand eines Coins als Text: Kurs, beide Sätze mit Schwellen und Urteil, Hinweis zum Niveau, acht Achsen, Index, Treiber, Warnzeichen",
           "== BTC · Kurs 60.000 (frisch" in st_ and "Risiko, dass BTC in 7 Tagen 10 % tiefer berührt wird (bei 54.000): 65 %" in st_
           and "Schwellen: erhöht ab 50 %, hoch ab 64 % (endet unter 51 %)" in st_ and "1,37-Fachen" in st_ and st_.count("\n      A") >= 8
           and "Druck-Index 87 von 100" in st_ and "Am höchsten:" in st_ and "Warnzeichen an: Kontenquote Binance 3,45 (ab 3)." in st_
           and max(len(z) for z in st_.split("\n")) <= ZEILE_MAX, st_.split("\n")[1])
        N_ = _probe_nutzlast(jetzt)
        roh_ = json.dumps(_ohne_nan(N_), ensure_ascii=False, allow_nan=False)
        ok("X3 Antwort der Karte: Stand, Einstellung, Meldungen, Stufe je Coin, Wahl der Schwelle, Belege; gültiges JSON ohne NaN; kein Thema, kein Schlüssel",
           N_["ok"] is True and set(N_) >= {"ereignis", "achsen", "index", "treiber", "warnzeichen", "einstellung", "meldungen", "alle", "pz_wahl", "beleg", "takt",
                                          "push_eingerichtet"} and [w_["pz"] for w_ in N_["pz_wahl"]] == [0.95, 0.975, 0.99] and N_["takt"]["laeuft"] is True
           and N_["beleg"]["meldung_alt_s"] == 600 and "NaN" not in roh_ and "thema" not in roh_.lower() and "api_key" not in roh_
           and [a["wert"] is not None for a in N_["achsen"]] == [True] * 8 and N_["index"]["n"] == 5, f"{len(roh_)} Zeichen")
        # ---------------------------------------------------------------- Ende zu Ende auf echten Dateien (kleine Welt, erzeugt)
        import contextlib
        import io
        import subprocess as _sp
        import hl_cockpit as HCe
        tmp_e = tempfile.mkdtemp(prefix="hl_radar_e2e_")
        umg_e = ("HL_RADAR_DB", "HL_HEBEL_DB", "HL_SWING_DB", "HL_AUSBLICK_DB")
        alt_e = {k: os.environ.pop(k, None) for k in umg_e}
        alt_q, alt_g, alt_popen = HCe.quellen_lesen, HCe.gemeinsam_lesen, _sp.Popen
        zl_e = [(57000.0, "long", 5e6, 3), (59999.0, "long", 2e6, 2), (61000.0, "short", 8e6, 2)]
        try:
            _FAKTOR_CACHE.clear(); _LANG_CACHE.clear(); _TIEFE_CACHE.clear()
            dbe = _kleine_welt(tmp_e, jetzt)
            st_e = jetzt // 3600

            alter_e = {"s": 30}

            def q_probe(db_, coin_, jetzt_, gemeinsam=None):
                Q_ = HCe._probe_quellen(jetzt_, coin_)
                Q_["kurs"] = {"px": 60000.0 if coin_ == "BTC" else 2000.0, "ts": jetzt_ - alter_e["s"]}
                Q_["liqdichte"] = {"ts": jetzt_ - 600, "zeilen": zl_e, "fehlt": [], "abdeckung": {"anteil": 0.29}}
                return Q_
            HCe.quellen_lesen = q_probe; HCe.gemeinsam_lesen = lambda db_, j_: {"probe": True}
            hc_ = HCe._ro(dbe)
            TS = tiefen_stunden(hc_, jetzt); TB = tiefe_lesen(hc_, "BTC", jetzt); TE = tiefe_lesen(hc_, "ETH", jetzt)
            hc_.close()
            ok("E1 Stundenmittel der Gebote bis −1 % (book_tiefe, seit 23.125): 299 Stunden je das Mittel ihrer Zeilen, die Stunde davor aus den "
               "Zeilen der letzten 60 Minuten; Zeilen, deren Gebote nicht bis −1 % vollständig sind (9 Mrd. in zwei Stunden), Zeilen älter als "
               "30 Tage, die laufende Stunde und Zeilen ohne Gebot zählen nicht; je Coin getrennt",
               len(TS["BTC"]) == 300 and TS["BTC"][st_e - 10] == 1e6 + 1e5 and TS["BTC"][st_e - 50] == 1e6 + 5e5 and TS["BTC"][st_e - 300] == 4e6
               and st_e not in TS["BTC"] and (st_e - 30 * 24 - 5) not in TS["BTC"] and max(TS["BTC"].values()) == 4e6
               and abs(TS["BTC"][st_e - 1] - 2.0e6) < 1e-6 and len(TS["ETH"]) == 300 and set(TS["ETH"].values()) == {7e5},
               f"{len(TS['BTC'])} Stunden BTC, {len(TS['ETH'])} ETH; größter Wert {max(TS['BTC'].values()):.0f}")
            hl_ = sqlite3.connect(os.path.join(tmp_e, "leer.db")); TL = tiefe_lesen(hl_, "BTC", jetzt); hl_.close()
            ok("E2 Gebote bis −1 % der letzten 60 Minuten: Mittel der 40 vollständigen Zeilen (2,0 Mio.) -- die Zeile von genau vor 60 Minuten, "
               "die ohne Gebot, die unvollständige und die aus der Zukunft zählen nicht; unter 30 Zeilen kein Wert, mit Grund; die Stufe kommt "
               "aus der jüngsten Zeile bis jetzt (100 USD, nicht die aus der Zukunft); ohne die Tabelle der Grund „fehlt“; ohne Datenbank der Grund",
               TB["usd"] == 2.0e6 and TB["n"] == 40 and TB["fehlt"] is None and len(TB["stunden"]) == 300 and TB["schritt"] == 100.0
               and TE["usd"] is None and TE["n"] == 5 and TE["schritt"] == 1.0 and "nur 5 Werte bis −1 % (gebraucht werden 30;" in TE["fehlt"]
               and TL["usd"] is None and "Tabelle book_tiefe fehlt" in TL["fehlt"] and TIEFE_MIN_ZEILEN == 30
               and "Datenbank des Recorders fehlt" in tiefe_lesen(None, "BTC", jetzt)["fehlt"], f"{TB['usd']} {TB['n']} | {TE['fehlt']} | {TL['fehlt']}")
            Ke = kerzen_lesen(dbe, ("BTC", "ETH", "XMR")); Kab = kerzen_lesen(dbe, ("ETH",), jetzt // TAG - 10)
            ok("E3 Tageskerzen aus hebel.db: je Coin 420 Schlüsse des Perpetuals mit Umsatz und Taker-Kauf; Spot als Summe der Paare je Tag "
               "(400 + 100 = 500, Taker 0,52 · 500 = 260); fehlt einem Paar an einem Tag die Taker-Angabe, hat der Tag keinen Taker-Wert "
               "(nicht die Teilsumme); ein Coin ohne Kerzen fehlt; „ab Tag“ schneidet ab",
               set(Ke) == {"BTC", "ETH"} and len(Ke["ETH"]["tag"]) == 420 and Ke["ETH"]["tag"][-1] == jetzt // TAG - 1 and Ke["ETH"]["pv"][0] == 1000.0
               and Ke["ETH"]["pt"][0] == 520.0 and len(Ke["ETH"]["stag"]) == 420 and abs(Ke["ETH"]["sv"][0] - 500.0) < 1e-9 and abs(Ke["ETH"]["st"][0] - 260.0) < 1e-9
               and abs(Ke["ETH"]["st"][-1] - 240.0) < 1e-9 and math.isnan(Ke["ETH"]["st"][220]) and abs(Ke["ETH"]["sv"][220] - 500.0) < 1e-9
               and Ke["ETH"]["stag"][220] == jetzt // TAG - 200 and not math.isnan(Ke["ETH"]["st"][219]) and len(Ke["BTC"]["stag"]) == 0 and len(Kab["ETH"]["tag"]) == 10 and len(Kab["ETH"]["stag"]) == 10,
               f"{sorted(Ke)}; ETH {len(Ke['ETH']['tag'])} Tage, Spot {Ke['ETH']['sv'][0]} / {Ke['ETH']['st'][0]}")
            fe = faktor(dbe, "ETH", jetzt); fe2 = faktor(dbe, "ETH", jetzt); fb = faktor(dbe, "BTC", jetzt); fx = faktor(dbe, "XMR", jetzt)
            ok("E4 Faktor aus der Datei: ETH schwankt doppelt so stark wie BTC -> 2,00 aus 365 gemeinsamen Tagen vor dem Monatsersten (01.11.2026); "
               "der zweite Aufruf kommt aus dem Speicher; BTC 1; ein Coin ohne Kerzen bekommt den Grund",
               fe["f"] == 2.0 and fe["n"] == 365 and fe["stichtag"] == monatserster(jetzt // TAG) and fe2 is fe and fb["f"] == 1.0 and fx["f"] is None
               and "fehlen Tagesschlüsse" in fx["grund"] and _tag_txt(fe["stichtag"]) == "01.11.2026", f"{fe}")
            LE = lange_achsen(dbe, "ETH", jetzt); LB_ = lange_achsen(dbe, "BTC", jetzt); LX = lange_achsen(dbe, "XMR", jetzt)
            ok("E5 Tagesachsen aus den Dateien: Funding der letzten 7 Tage 3 · 0,02 % · 365 = 21,9 % im Jahr, höher als an allen Tagen davor "
               "(Perzentil 1); Spot-Saldo ETH (2 · 240 − 500) ÷ 500 = −4 %, tiefer als an allen Tagen davor (Perzentil 0); Schwankung gestiegen; "
               "Stand ist der Vortag; BTC ohne Spot-Kerzen: grau mit Grund; ein Coin ohne Kerzen: alles grau",
               abs(LE["a3"]["roh"] - 0.219) < 1e-9 and LE["a3"]["pz"] == 1.0 and abs(LE["a4"]["roh"] + 0.04) < 1e-9 and LE["a4"]["pz"] == 0.0
               and LE["a7"]["pz"] is not None and LE["a7"]["pz"] > 0.9 and LE["a3"]["tag"] == jetzt // TAG - 1 and LE["a3"]["grau"] is None
               and LB_["a4"]["pz"] is None and "keine Spot-Kerzen von Binance" in LB_["a4"]["grau"] and abs(LB_["a3"]["roh"] - 0.219) < 1e-9
               and all(LX[k]["grau"] == "Für diesen Coin fehlen Tageskerzen in hebel.db." for k in ("a3", "a4", "a7")) and lange_achsen(dbe, "ETH", jetzt) is LE,
               f"A3 {LE['a3']['roh']} pz {LE['a3']['pz']}; A4 {LE['a4']['roh']} pz {LE['a4']['pz']}; A7 pz {LE['a7']['pz']}")
            SB = stand(dbe, "BTC", jetzt); SE = stand(dbe, "ETH", jetzt)
            axb = {a["key"]: a for a in SB["achsen"]}; axe = {a["key"]: a for a in SE["achsen"]}
            p7_hand = AU.erreichen_aus_lauf(_probe_lauf(jetzt)["h"], math.log(0.9), 7)[0]
            p7e_hand = AU.erreichen_aus_lauf(_probe_lauf(jetzt)["h"], math.log(1 - 0.10 * 2.0), 7)[0]
            ok("E6 Stand aus den Dateien (das Cockpit liefert Kurs, Messwerte und Heatmap aus seiner Probe): BTC p7 aus der abgelegten Verteilung "
               "am Abstand −10 %, ETH am Abstand −20 % (Faktor 2,00, Schwelle 1.600); A5 = 7 Mio. ÷ 2 Mio. = 3,5-mal die Gebote, Perzentil gegen "
               "340 eigene Stundenwerte (35,5 von 340 -> 10; die 20 Werte vor „tiefe_ab“ zählen nicht); A6 = 100 − 99 von 300 -> 67; ETH ohne eigene "
               "Stundenwerte und ohne 30 Zeilen: beide grau mit Grund; der Trend-Hinweis steht nur, wo die Rechnung desselben Ankers einen Trend trägt (ETH)",
               SB["ok"] and abs(SB["ereignis"]["e7"]["p"] - p7_hand) < 1e-12 and SB["ereignis"]["e7"]["kurs_schwelle"] == 54000.0 and SB["faktor"]["f"] == 1.0
               and abs(SE["ereignis"]["e7"]["p"] - p7e_hand) < 1e-12 and SE["ereignis"]["e7"]["x_text"] == "20 %" and SE["ereignis"]["e7"]["kurs_schwelle"] == 1600.0
               and SE["ereignis"]["e7"]["p"] < SB["ereignis"]["e7"]["p"] and SB["a5_roh"] == 3.5 and axb["a5"]["wert"] == 10.0 and SB["a6_roh"] == 2.0e6
               and axb["a6"]["wert"] == 67.0 and "Gebote bis −1 % im Hyperliquid-Buch: 2,0 Mio. USD (Stufen zu 100 USD)" == axb["a6"]["leit"]
               and axb["a3"]["wert"] == 100.0 and axb["a4"]["wert"] is None and axe["a4"]["wert"] == 100.0
               and axe["a5"]["wert"] is None and "nur 5 Werte" in axe["a5"]["grau"] and axe["a6"]["wert"] is None
               and SB["trend"] is None and SE["trend"] is not None and "7 Tage +0,12 σ" in SE["trend"] and SB["ereignis"]["e7"]["stufe"] == "ohne"
               and "noch nicht gerechnet" in SB["ereignis"]["e7"]["urteil"],
               f"BTC p7 {SB['ereignis']['e7']['p']:.4f}, ETH {SE['ereignis']['e7']['p']:.4f}; A5 {axb['a5']['wert']} A6 {axb['a6']['wert']}; ETH A5 {axe['a5']['grau']}")
            alter_e["s"] = 301; SBa = stand(dbe, "BTC", jetzt); alter_e["s"] = 300; SBg = stand(dbe, "BTC", jetzt); alter_e["s"] = 30
            axa = {a["key"]: a for a in SBa.get("achsen") or []}
            ok("E11 Kurs im Stand: älter als 5 Minuten -> beide Zahlen und die Liquidations-Nähe nennen den Grund statt eines Werts, der Kurs "
               "gilt als nicht frisch; genau 5 Minuten alt gilt noch",
               SBa["ok"] and SBa["kurs"]["frisch"] is False and SBa["ereignis"]["e7"]["p"] is None and SBa["ereignis"]["e2"]["p"] is None
               and _drin("Kein frischer Kurs", SBa["ereignis"]["e7"]["fehlt"]) and (axa.get("a5") or {}).get("wert") is None
               and _drin("Kein frischer Kurs", (axa.get("a5") or {}).get("grau")) and SBa["ereignis"]["e7"]["kurs_schwelle"] == 54000.0
               and SBg["kurs"]["frisch"] is True and SBg["ereignis"]["e7"]["p"] == SB["ereignis"]["e7"]["p"], f"{SBa['ereignis']['e7']['fehlt']}")
            Ne = nutzlast(dbe, "BTC", jetzt); roh_e = payload_json(dbe, "BTC", jetzt).decode("utf-8"); Mj = json.loads(meldungen_json(dbe).decode("utf-8"))
            puf = io.StringIO()
            with contextlib.redirect_stdout(puf):
                rc_t = haupt(["--text", "--coin", "ETH", "--db", dbe])
            te = puf.getvalue()
            ok("E7 Antwort der Karte und Debug 160 aus den Dateien: gültiges JSON ohne NaN mit Stand, Einstellung, Meldungen und der Zeile „Stufe je "
               "Coin“; der Bericht (hl_radar.py --text --coin ETH) nennt Faktor, beide Sätze, die Achsen und die Rechenzeit mit ihren Teilen (gemeinsame "
               "Quellen, Quellen des Cockpits, Ausblick, Tagesreihen, Orderbuch, Notbremse; seit 23.123), keine Zeile über 150 Zeichen",
               Ne["ok"] and Ne["einstellung"] == EINSTELLUNG_VORGABE and Ne["meldungen"] == [] and [a["coin"] for a in Ne["alle"]] == list(COINS)
               and Ne["alle"][0]["p_text"] == SB["ereignis"]["e2"]["p_text"] != SB["ereignis"]["e7"]["p_text"] and Ne["leit"] == "e2"
               and Ne["leit_kurz"] == "48 Stunden" and json.loads(roh_e)["coin"] == "BTC" and "NaN" not in roh_e
               and Mj == {"ok": True, "meldungen": [], "meldung_alt_s": 600} and rc_t == 0 and "== ETH · Kurs 2.000 (frisch" in te
               and "Faktor gegenüber BTC 2,00" in te and "Risiko, dass ETH in 7 Tagen 20 % tiefer berührt wird (bei 1.600)" in te and "A4 Spot-Nachfrage" in te
               and "enthält einen Trend (7 Tage +0,12 σ)" in te and "Rechenzeit dieses Berichts:" in te and "== BTC" not in te
               and "s -- davon gemeinsame Quellen " in te and all(n_ + " " in te.split("Rechenzeit dieses Berichts:")[1] for _k, n_ in ZEIT_NAMEN)
               and set(SB.get("zeit") or {}) == {k_ for k_, _n in ZEIT_NAMEN} and all(v_ >= 0 for v_ in SB["zeit"].values())
               and zeit_satz({"cockpit": 18.24, "orderbuch": 4.96}, 1.23) == ("davon gemeinsame Quellen 1,2 s · Quellen des Cockpits 18,2 s · "
                                                                          "Ausblick 0,0 s · Tagesreihen 0,0 s · Orderbuch 5,0 s · Notbremse 0,0 s")
               and zeit_satz({}).startswith("davon Quellen des Cockpits 0,0 s")
               and max(len(z_) for z_ in te.split("\n")) <= 150, f"{len(roh_e)} Zeichen JSON; Bericht {len(te.splitlines())} Zeilen")
            # Rückblick auf einer Welt ohne Historie des Ausblicks: kein Urteil, aber ein abgelegtes Ergebnis mit Grund -- und der Bericht dazu
            puf = io.StringIO()
            with contextlib.redirect_stdout(puf):
                rc_r = haupt(["--rueckblick-text", "--db", dbe])
            tr = puf.getvalue()
            cr = lesen(pfad(dbe)); rb_e = meta(cr, "rueckblick"); cr.close()
            sp_e = RbSperre(dbe); frei_e = sp_e.nehmen(); sp_e.lassen()
            puf2 = io.StringIO()
            with contextlib.redirect_stdout(puf2):
                rc_r2 = haupt(["--rueckblick-text", "--db", dbe])
            ok("E8 Debug 161 (hl_radar.py --rueckblick-text) auf einer Welt ohne Historie des Ausblicks: rechnet, legt das Ergebnis mit Fassung "
               "und Zeit in radar.db ab und sagt, warum es kein Urteil gibt (keine Ursprünge); danach ist die Sperre wieder frei; der zweite "
               "Aufruf rechnet nicht noch einmal",
               rc_r == 0 and "rechnet ihn jetzt" in tr and isinstance(rb_e, dict) and rb_e.get("version") == VERSION_MODUL and frei_e is True
               and ((rb_e.get("urteil") or {}).get("e7") or {}).get("besteht") is False
               and _drin("keine Ursprünge", ((rb_e.get("urteil") or {}).get("e7") or {}).get("grund")) and "Rückblick des Grundrisikos" in tr and rc_r2 == 0
               and "rechnet ihn jetzt" not in puf2.getvalue() and "Rückblick des Grundrisikos" in puf2.getvalue()
               and not os.path.exists(pfad(dbe) + ".rueckblick.lock.x") and os.path.exists(pfad(dbe) + ".rueckblick.lock"), f"{rb_e and rb_e.get('fehlt')}")
            # Start des Rückblicks als eigener Prozess: Befehl, Umgebung, kein preexec_fn; kein zweiter, solange der erste läuft
            rufe_p = []

            class _FakePopen:
                def __init__(self, cmd, **kw):
                    rufe_p.append((list(cmd), dict(kw)))

                def poll(self):
                    return None
            _TAKT["proc"] = None
            _sp.Popen = _FakePopen
            try:
                s1_ = _starte_rueckblick(dbe); s2_ = _starte_rueckblick(dbe)
            finally:
                _sp.Popen = alt_popen; _TAKT["proc"] = None
            kw_p = rufe_p[0][1] if rufe_p else {}
            ok("E9 Start des Rückblicks aus dem Takt: eigener Prozess „hl_radar.py --rueckblick --db …“ mit der Umgebung für gesenkte Priorität "
               "(HL_NICE), ohne preexec_fn; Ausgabe in radar_takt.log neben radar.db; solange er läuft, kein zweiter",
               s1_ is True and s2_ is False and len(rufe_p) == 1 and rufe_p[0][0][1:] == [os.path.abspath(__file__), "--rueckblick", "--db", dbe]
               and "preexec_fn" not in kw_p and (kw_p.get("env") or {}).get(AU.NICE_VAR) == str(AU.NICE_KIND)
               and os.path.exists(os.path.join(tmp_e, "radar_takt.log")) and "Start Rückblick" in open(os.path.join(tmp_e, "radar_takt.log")).read(),
               f"{rufe_p[0][0][1:] if rufe_p else None}")
            ev_e = threading.Event(); erg_e = []; ges_e = []

            def schritt_e(db_, con_):
                try:
                    erg_e.append(takt_schritt(db_, con_, jetzt, http_fn=lambda u_, r_, t_: ges_e.append(u_) or (200, "ok"),
                                              push_ein={"thema": "probethemaprobethemaprobethema123", "server": "https://ntfy.example.org"},
                                              starte_rb=lambda d_: False))
                finally:
                    ev_e.set()
            fd_e = starte(dbe, stop=ev_e, verzoegerung=0.0, schritt=schritt_e, takt_s=0.01)
            if fd_e is not None:
                fd_e.join(60)
            ce = lesen(pfad(dbe))
            ze = ce.execute("SELECT stunde, ts, p7, p2, a5, a6, json FROM rd_stand WHERE coin='BTC' AND stunde=?", (st_e,)).fetchone()
            ne_ = ce.execute("SELECT COUNT(*) FROM rd_stand WHERE stunde=?", (st_e,)).fetchone()[0]; takt_e = meta(ce, "takt"); zu_e = meta(ce, "zustand")
            ce.close()
            t_e = erg_e[0] if erg_e else {}
            ok("E10 ein Schritt des Fadens auf den echten Dateien: alle fünf Coins gerechnet und für die Stunde abgelegt (BTC mit p7, p2 und den "
               "Rohwerten von A5 und A6 wie im Stand), Zustand und Zeit des Takts gespeichert -- seit 23.123 mit der Dauer des Schritts und "
               "ihren Teilen; ohne Schwellen keine Meldung, nichts gesendet",
               fd_e is not None and not fd_e.is_alive() and len(erg_e) == 1 and t_e.get("coins") == list(COINS) and t_e.get("abgelegt") == 5
               and isinstance((takt_e or {}).get("dauer_s"), float) and 0 <= takt_e["dauer_s"] < 120 and takt_e["dauer_s"] == t_e.get("dauer_s")
               and set(takt_e.get("zeit") or {}) == {k_ for k_, _n in ZEIT_NAMEN} and all(v_ >= 0 for v_ in takt_e["zeit"].values())
               and sum(takt_e["zeit"].values()) <= takt_e["dauer_s"] + 0.05
               and t_e.get("fehler") == [] and t_e.get("meldungen") == 0 and ges_e == [] and ne_ == 5 and ze is not None and ze[1] == jetzt
               and abs(ze[2] - SB["ereignis"]["e7"]["p"]) < 1e-12 and abs(ze[3] - SB["ereignis"]["e2"]["p"]) < 1e-12 and ze[4] == 3.5 and ze[5] == 2.0e6
               and json.loads(ze[6])["e"]["e7"]["stufe"] == "ohne" and json.loads(ze[6])["achsen"]["a6"] == 67.0 and (takt_e or {}).get("ts") == jetzt
               and set(zu_e or {}) == set(COINS) and ((zu_e or {}).get("BTC") or {}).get("e7", {}).get("hoch") is False, f"{t_e}")
            tx_l = text(dbe, ("BTC",), jetzt + 900); tx_s = text(dbe, ("BTC",), jetzt + 901)
            cv_ = verbinden(pfad(dbe)); tv_alt = meta(cv_, "takt_voll")
            meta_setzen(cv_, "takt_voll", {"ts": jetzt - 3000, "coins": list(COINS), "dauer_s": 12.5, "zeit": {"cockpit": 10.0, "orderbuch": 2.0}}); cv_.close()
            tx_v = " ".join(text(dbe, ("BTC",), jetzt + 900).split())
            cv_ = verbinden(pfad(dbe)); meta_setzen(cv_, "takt_voll", tv_alt); cv_.close()
            ok("E12b Debug 160 nennt hinter dem letzten Schritt den Schritt zur vollen Stunde, wenn ein anderer der letzte war (U312): Zeit, Dauer "
               "für fünf Coins und die Teile; ist der letzte Schritt selbst der zur vollen Stunde, steht er nur einmal da",
               ("Takt: zuletzt " + _dt(jetzt) + " · der Schritt dauerte ") in tx_v and ("; zur vollen Stunde zuletzt " + _dt(jetzt - 3000)
                                                                                         + ": der Schritt dauerte 12,5 s für 5 Coins (davon ") in tx_v
               and "zur vollen Stunde" not in tx_l and tv_alt and tv_alt.get("ts") == jetzt,
               next((z_.strip() for z_ in tx_v.split("Meldungen:")[1:2]), "ohne Zeile")[:300])
            ok("E12 steht der Takt (kein Schritt seit mehr als 15 Minuten), sagen es Debug 160 und die Antwort der Karte; genau 15 Minuten "
               "gelten noch als laufend",
               "Takt: zuletzt " + _dt(jetzt) + " · der Schritt dauerte " in " ".join(tx_l.split()) and "steht seit" not in tx_l
               and " s für 5 Coins (davon Quellen des Cockpits " in " ".join(tx_l.split()) and "der Schritt dauerte" not in tx_s
               and takt_dauer_satz({"ts": 1, "coins": ["BTC"], "dauer_s": 4.26, "zeit": {"cockpit": 3.0, "orderbuch": 1.04}})
               == " · der Schritt dauerte 4,3 s für 1 Coin (davon Quellen des Cockpits 3,0 s · Ausblick 0,0 s · Tagesreihen 0,0 s · Orderbuch 1,0 s · Notbremse 0,0 s)"
               and takt_dauer_satz({"ts": 1, "coins": ["BTC", "ETH"], "dauer_s": 2.0}) == " · der Schritt dauerte 2,0 s für 2 Coins"
               and takt_dauer_satz({"ts": 1, "coins": ["BTC"]}) == "" and takt_dauer_satz(None) == ""
               and "keine Spot-Kerzen von Binance). · fehlt im Index" in " ".join(tx_l.split()) and " ".join(tx_l.split()).count(" · im Index") == 4
               and " ".join(tx_l.split()).count("fehlt im Index") == 1
               and ("Takt: steht seit " + _dt(jetzt) + " (seit 15 Minuten kein Schritt -- ohne Takt gibt es keinen Alarm; läuft das Dashboard?)") in " ".join(tx_s.split())
               and max(len(z_) for z_ in tx_s.split("\n")) <= 150
               and nutzlast(dbe, "BTC", jetzt + 900)["takt"] == {"ts": jetzt, "laeuft": True}
               and nutzlast(dbe, "BTC", jetzt + 901)["takt"] == {"ts": jetzt, "laeuft": False},
               next((z_.strip() for z_ in tx_s.split("\n") if "steht seit" in z_), "ohne Zeile"))
            alt_stand = globals()["stand"]

            def stand_z(db_, coin_, jetzt_=None, **kw_):
                S_ = alt_stand(db_, coin_, jetzt_, **kw_)
                S_["zeit"] = {"cockpit": 1.25, "ausblick": 0.5, "tagesreihen": 0.25, "orderbuch": 2.0, "notbremse": 0.0}
                return S_
            globals()["stand"] = stand_z
            try:
                tz_ = " ".join(text(dbe, ("BTC", "ETH"), jetzt + 900).split())
            finally:
                globals()["stand"] = alt_stand
            ok("E14 Rechenzeit über mehrere Coins: Debug 160 zählt die Teile aller Coins zusammen (zwei Coins mit je 1,25 · 0,5 · 0,25 · 2,0 · 0 s "
               "-> 2,5 · 1,0 · 0,5 · 4,0 · 0,0 s)",
               "Quellen des Cockpits 2,5 s · Ausblick 1,0 s · Tagesreihen 0,5 s · Orderbuch 4,0 s · Notbremse 0,0 s" in tz_ and "== BTC" in tz_ and "== ETH" in tz_,
               tz_.split("Rechenzeit dieses Berichts:")[-1][:140])
            n_vor = nutzlast(dbe, "BTC", jetzt + 900)
            con_g = verbinden(pfad(dbe))
            try:
                meta_setzen(con_g, "regeln", _probe_regeln(jetzt, belegt7=("r7",), belegt2=()))
            finally:
                con_g.close()
            S_g = stand(dbe, "BTC", jetzt + 900); n_g = nutzlast(dbe, "BTC", jetzt + 900); tx_g = " ".join(text(dbe, ("BTC",), jetzt + 900).split())
            ok("E13 Urteil der Regeln aus radar.db: Solange keines abgelegt ist, sagen Karte und Debug 160 „noch nicht geprüft“ und der Druck-Index "
               "bleibt „gemessen, ungeprüft“; liegt eines dort (R7 für 7 Tage belegt), stehen der Satz in Stand, Antwort der Karte und Debug 160 "
               "und der Vermerk am Druck-Index",
               "Warnzeichen R1 bis R7: noch nicht geprüft (Debug 163" in " ".join(tx_l.split()) and n_vor["regeln"] is None
               and n_vor["index"]["text"].endswith("— gemessen, ungeprüft.") and "noch nicht geprüft" in n_vor["regeln_satz"]
               and S_g["regeln"]["belegt"] == {"e7": ["r7"], "e2": []} and n_g["regeln_satz"] == S_g["regeln_satz"]
               and "für 7 Tage belegt: R7 Druck-Index; für 48 Stunden keine belegt." in S_g["regeln_satz"] and S_g["regeln_satz"] in tx_g
               and S_g["index"]["text"].endswith("— gemessen; als Warnzeichen geprüft (R7): belegt für 7 Tage.") and S_g["index"]["text"] in tx_g
               and json.dumps(_ohne_nan(n_g), allow_nan=False) is not None, S_g["index"]["text"])
        except Exception as e_:  # noqa: BLE001
            import traceback
            ok("E Proben auf echten Dateien ohne Ausnahme", False, f"{type(e_).__name__}: {e_} -- {traceback.format_exc().splitlines()[-3].strip()}")
        finally:
            HCe.quellen_lesen, HCe.gemeinsam_lesen = alt_q, alt_g
            _sp.Popen = alt_popen
            for k, v in alt_e.items():
                if v is not None:
                    os.environ[k] = v
            _FAKTOR_CACHE.clear(); _LANG_CACHE.clear(); _TIEFE_CACHE.clear()
            shutil.rmtree(tmp_e, ignore_errors=True)
        # ---------------------------------------------------------------- Vertrag mit dem Paket
        hier = os.path.dirname(os.path.abspath(__file__))
        qu = {}
        for n_ in ("version.py", "update.py", "install.py", "hl_viz.py", "hl_cockpit.py", "hl_cockpit_js.py", "hl_recorder.py", "hl_ausblick.py", "KONZEPT_Risikoradar.md"):
            try:
                with open(os.path.join(hier, n_), encoding="utf-8") as fh:
                    qu[n_] = fh.read()
            except OSError:
                qu[n_] = None
        if all(v_ is not None for n_, v_ in qu.items() if n_ != "KONZEPT_Risikoradar.md"):
            ok("VP1 Vertrag mit dem Paket: hl_radar.py, hl_radar_js.py und (seit 23.123) hl_radar_regeln.py in der Prüfsumme (version.py), mit "
               "dem Konzept in Sicherung und Wiederherstellung (update.py), im Übersetzungs- und in den Prüfschritten des Installers (Radar, "
               "Regel-Prüfung, Karte) und mit drei Adressen in seinem Dashboard-Schritt; radar.db im täglichen Backup; der "
               "Recorder führt seit 23.125 die Tabelle book_tiefe mit denselben Spalten, die das Radar liest, und füllt sie mit der Aufgabe "
               "„Buch-Tiefe“ (Abfrage l2Book mit gerundeten Stufen, Gebote bis 1 % unter der Mitte, Vollständigkeit je Seite) -- darauf beruhen "
               "Markttiefe und Liquidations-Nähe",
               '"hl_radar.py", "hl_radar_js.py",' in qu["version.py"] and '"hl_radar_regeln.py")' in qu["version.py"]
               and '"hl_radar.py", "hl_radar_js.py", "KONZEPT_Risikoradar.md",' in qu["update.py"] and '"hl_radar_regeln.py"}' in qu["update.py"]
               and 'str(ROOT / "hl_radar.py"), str(ROOT / "hl_radar_js.py"), str(ROOT / "hl_radar_regeln.py"),' in qu["install.py"]
               and '[py, str(ROOT / "hl_radar.py"), "--selbsttest"]' in qu["install.py"] and '[py, str(ROOT / "hl_viz.py"), "--selbsttest-radar"]' in qu["install.py"]
               and '[py, str(ROOT / "hl_radar_regeln.py"), "--selbsttest"]' in qu["install.py"]
               and all(t_ in qu["install.py"] for t_ in ('("/cockpit/radar?coin=BTC", lambda b:', '("/radar.js", lambda b: b"function rdKarte" in b',
                                                          '("/cockpit/radar/meldungen", lambda b:'))
               and '"engine", "staking", "radar")' in qu["hl_recorder.py"]
               and "CREATE TABLE IF NOT EXISTS book_tiefe (" in qu["hl_recorder.py"]
               and all(t_ in qu["hl_recorder.py"] for t_ in ("    ts       INTEGER,", "    coin     TEXT,", "    nsig     INTEGER,", "    schritt  REAL,",
                                                            "    mitte    REAL,", "    bid_1    REAL,", "    ask_1    REAL,",
                                                            "    stufen_b INTEGER, stufen_a INTEGER,", "    voll     INTEGER,"))
               and '("Buch-Tiefe", self.run_tiefe)' in qu["hl_recorder.py"] and '{"type": "l2Book", "coin": sym, "nSigFigs": n}' in qu["hl_recorder.py"]
               and "TIEFE_ABSTAND = 0.01 " in qu["hl_recorder.py"] and "TIEFE_TAGE = 35 " in qu["hl_recorder.py"]
               and "INSERT OR REPLACE INTO book_tiefe VALUES (?,?,?,?,?,?,?,?,?,?)" in qu["hl_recorder.py"],
               ", ".join(n_ for n_, q_ in qu.items() if q_ and "hl_radar" in q_))
            ok("VP2 Vertrag mit dem Dashboard: Adressen /cockpit/radar, /cockpit/radar/meldungen, /radar.js und die Einstellung per POST; der Faden "
               "startet mit dem Dashboard; Debug-Läufe 160 bis 164 mit ihren Befehlen; /radar.js steht vor /cockpit.js; das Cockpit ruft "
               "Karte und Daten nur, wenn es das Skript gibt; der Ausblick legt Tag 2 ab",
               all(t_ in qu["hl_viz.py"] for t_ in ('elif u.path == "/cockpit/radar":', 'elif u.path == "/cockpit/radar/meldungen":', 'elif u.path == "/radar.js":',
                                                      'elif u.path == "/cockpit/radar/einstellung":', "    radar_start(db) ", "if hl_radar.starten(db):",
                                                      '[py, "hl_radar.py", "--text", "--db", db]', '[py, "hl_radar.py", "--rueckblick-text", "--db", db]',
                                                      '[py, "hl_radar.py", "--selbsttest"]', '"/cockpit/radar": 30, "/cockpit/radar/meldungen": 20}',
                                                      '[py, "hl_radar_regeln.py", "--text", "--db", db]', '[py, "hl_radar_regeln.py", "--selbsttest"]'))
               and """'<script src="/radar.js"></script><script src="/cockpit.js"></script></body></html>'""" in qu["hl_cockpit.py"]
               and "(typeof rdKarte==='function'?rdKarte(d):'')" in qu["hl_cockpit_js.py"] and "if(typeof rdLaden==='function') rdLaden(false);" in qu["hl_cockpit_js.py"]
               and "LAUF_H = (2,) + H_ZIEL" in qu["hl_ausblick.py"] and AU.LAUF_H == (2, 7, 14, 28))
        else:
            ok("VP1 Vertrag mit dem Paket (die übrigen Dateien des Pakets liegen nicht neben dem Modul -- nicht geprüft)", True,
               "fehlen: " + ", ".join(n_ for n_, v_ in qu.items() if v_ is None))
        ok("VP3 Zahlen des Konzepts im Modul (festgehalten): 10 % in 7 Tagen und 7 % in 48 Stunden; Faktor aus 365 Tagen (mindestens 180); Frische 5 Minuten und "
           "3 Stunden; Stufen am 80. und 95. Perzentil; Ende unter 0,8; Sperrzeit 12 Stunden; Kontenquote 3 und 2,8, höchstens einmal in 7 Tagen; "
           "Rückblick ab 1000 Tagen und 50 Ereignissen, Steigung 0,8 bis 1,2, Niveau 0,8 bis 1,25, Block 28, 2000 Ziehungen; Index aus fünf Achsen, "
           "mindestens vier; Regel K: Anpassung ab 365 Ursprungstagen und 50 Ereignissen, Zahl auf 0,5 % bis 99,5 %",
           (EREIGNIS["e7"]["tage"], EREIGNIS["e7"]["x"], EREIGNIS["e2"]["tage"], EREIGNIS["e2"]["x"]) == (7, 0.10, 2, 0.07) and (FAKTOR_TAGE, FAKTOR_MIN) == (365, 180)
           and (FRISCH_KURS_S, FRISCH_AUSBLICK_S) == (300, 10800) and (PZ_ERHOEHT, PZ_HOCH, PZ_WAHL) == (0.80, 0.95, (0.95, 0.975, 0.99)) and HYSTERESE == 0.8
           and SPERRZEIT_S == 43200 and (KONTEN_AN, KONTEN_AUS, HINWEIS_SPERRE_S) == (3.0, 2.8, 7 * TAG) and (G_MIN_TAGE, G_MIN_EREIGNISSE) == (1000, 50)
           and G_STEIGUNG == (0.8, 1.2) and G_NIVEAU == (0.8, 1.25) and (G_ALPHA, G_BLOCK, G_BOOT) == (0.05, 28, 2000) and INDEX_ACHSEN == ("a1", "a2", "a3", "a4", "a7")
           and INDEX_MIN == 4 and (TAKT_S, ABLAGE_S) == (300, 3600) and (A5_GRENZE, A5_TAGE, A5_MIN, A6_TAGE, A6_MIN) == (0.05, 90, 336, 30, 240)
           and (KAL_MIN_TAGE, KAL_MIN_EREIGNISSE, KAL_P) == (365, 50, (0.005, 0.995)))
        if qu["KONZEPT_Risikoradar.md"] is not None:
            kz = " ".join(qu["KONZEPT_Risikoradar.md"].split())
            ok("VP4 dieselben Zahlen stehen im Konzept (KONZEPT_Risikoradar.md neben dem Modul)",
               all(t_ in kz for t_ in ("P · (1 − 0,10 · f_c)", "P · (1 − 0,07 · f_c)", "mindestens 180 solche Tage", "Kurs höchstens 5 Minuten alt",
                                            "höchstens 3 Stunden alt", "80. Perzentil", "95. Perzentil", "unter 0,8 · Schwelle „hoch“", "letzten 12 Stunden",
                                            "unter 2,8 lag", "mindestens 1000 Ursprungstage und 50 eingetretene Ereignisse", "zwischen 0,8 und 1,2",
                                            "Niveau zwischen 0,8 und 1,25", "Block 28 Tage, 2000 Ziehungen", "(mindestens vier)", "mindestens 14 Tage, höchstens 90",
                                            # Fassung 3 (23.123): Regel K und die berichtigte Leitgröße von A5 und A6
                                            "logit p′ = a + b · logit p", "mindestens 365 Ursprungstage und 50 Ereignisse", "auf 0,5 % bis 99,5 % begrenzt",
                                            "Kein dritter Versuch", "sobald der Monat gewechselt hat",
                                            # Fassung 5 (23.125): die Gebote bis −1 % für A5 und A6 (U311)
                                            "÷ Gebote bis −1 % im Hyperliquid-Buch (Fassung 5", "19 Stufen noch 1 % des Kurses überdecken",
                                            "Mittel der vollständigen Zeilen der letzten 60 Minuten (mindestens 30)", "rd_meta „tiefe_ab“", "35 Tage",
                                            "Gebote mit einem Preis ab 99 % der Mitte")),
               f"{len(kz)} Zeichen")
        else:
            ok("VP4 Konzept nicht geprüft: KONZEPT_Risikoradar.md liegt nicht neben dem Modul", True)
        import hl_radar_regeln as RGv
        ok("VP5 Zahlen von Regel A im Modul und in der Regel-Prüfung (festgehalten; Konzept 14.3 und 14.4): groß steht die 48-Stunden-Zahl; "
           "Aufschlag nur für sie, Faktor höchstens 3, aus Tagen mit abgelaufener Frist (2 Tage), ab 365 Tagen mit bekanntem Zustand, 30 Tagen "
           "in 5 Episoden im Zustand und 30 Tagen ohne Zeichen; nur BTC und ETH; der Stand der Zeichen gilt höchstens zwei Tage, der Takt "
           "versucht den Abruf höchstens einmal je Stunde; der Vergleich mit p unter 0,05 und demselben Bootstrap (Block 28, 2000 Ziehungen); "
           "beide Module führen dieselben Regeln in derselben Reihenfolge",
           (LEIT, REIHE, AUF_KEY, AUF_DECKEL, AUF_ALT_TAGE, ZEICHEN_WIEDER_S) == ("e2", ("e2", "e7"), "e2", 3.0, 2, 3600)
           and (RGv.AUF_EREIGNIS, RGv.AUF_FRIST, RGv.AUF_DECKEL, RGv.AUF_MIN_TAGE) == ("e2", 2, 3.0, 365) and RGv.AUF_FRIST == EREIGNIS["e2"]["tage"]
           and (RGv.MIN_SIGNALTAGE, RGv.MIN_EPISODEN, RGv.MIN_OHNE) == (30, 5, 30) and tuple(RGv.COINS_URTEIL) == ("BTC", "ETH")
           and (G_ALPHA, G_BLOCK, G_BOOT) == (0.05, 28, 2000) and NIEDRIG_HINWEIS == "Ein niedriger Wert ist keine Entwarnung."
           and [r_[0] for r_ in RGv.REGELN] == list(REGELN_NAMEN) and RGv.VERSION_MODUL == VERSION_MODUL)
        if qu["KONZEPT_Risikoradar.md"] is not None:
            kz4 = " ".join(qu["KONZEPT_Risikoradar.md"].split()); nw = AUF_NACHWEIS or {}
            zeile_nw = lambda k_: f"| {(nw.get(k_) or {}).get('basis')} | {(nw.get(k_) or {}).get('auf')} |"                 # noqa: E731
            ok("VP6 Regel A steht so im Konzept (KONZEPT_Risikoradar.md, Fassung 4, Abschnitt 14): die Karte, die Regel mit ihren Zahlen, die "
               "Prüfung G2a, die Folge -- und die Messung auf erfundenen Reihen mit denselben Zahlen wie im Modul (Reihen mit bestandener "
               "Grundlage und Reihen mit geltendem Aufschlag je Fall, gemessenes Chancenverhältnis)",
               all(t_ in kz4 for t_ in ("Die 48-Stunden-Zahl steht groß oben", "„Ein niedriger Wert ist keine Entwarnung.“",
                                        "das Mantel-Haenszel-**Chancenverhältnis**", "mindestens 365 Tage mit bekanntem Zustand",
                                        "30 Tage in 5 Episoden und 30 Tage „keins“", "Der Faktor liegt zwischen 1 und 3",
                                        "Σ π_r · P(F_r · o₀) + π₀ · P(o₀) = p′", "begrenzt auf 0,5 % bis 99,5 %",
                                        "mittlerer Brier-Unterschied über 0 mit p unter 0,05", "Blöcke von 28 Tagen, 2000 Ziehungen",
                                        "Ist er älter als zwei Tage, gilt „unbekannt“", "Kein weiterer Versuch auf diesen Daten",
                                        "G2a ist die dritte Prüfung der 48-Stunden-Zahl auf denselben Daten"))
               and isinstance(AUF_NACHWEIS, dict) and all(isinstance(nw.get(k_), dict) for k_ in ("ohne", "r1", "beide"))
               and f"gemessen am {nw.get('datum')}" in kz4 and f"Je Fall {_tsd(nw.get('welten'))} erfundene Reihen" in kz4
               and f"| Die Zeichen tragen nichts {zeile_nw('ohne')}" in kz4
               and f"| Nur R1 trägt (gemessenes Chancenverhältnis {_de((nw.get('r1') or {}).get('or'), 1)}) {zeile_nw('r1')}" in kz4
               and f"| R1 und R7 tragen (je {_de((nw.get('beide') or {}).get('or'), 1)}) {zeile_nw('beide')}" in kz4
               and 0 <= nw["ohne"]["auf"] <= nw["ohne"]["basis"] <= nw["welten"] and nw["ohne"]["auf"] / max(1, nw["ohne"]["basis"]) < 0.10,
               f"{nw}")
        else:
            ok("VP6 Konzept nicht geprüft: KONZEPT_Risikoradar.md liegt nicht neben dem Modul", True)
        ok("X2 ein Coin außerhalb der Liste bekommt eine Absage mit Grund", stand(dbp, "DOGE", jetzt)["ok"] is False and "nur BTC, ETH, HYPE, ZEC, XMR" in stand(dbp, "DOGE", jetzt)["fehlt"][0])
    finally:
        for k, v in alt_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"hl_radar -- Selbsttest: {sum(erg)} von {len(erg)} Proben bestanden", flush=True)
    return all(erg)


def haupt(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    db_ = argv[argv.index("--db") + 1] if "--db" in argv else os.environ.get("HL_DB", "hl_liq.db")
    if "--selbsttest" in argv:
        return 0 if selbsttest() else 1
    if "--rueckblick" in argv:
        try:
            import hl_ausblick as AU
            AU.nice_aus_umgebung()                                      # der vom Dashboard gestartete Lauf senkt seine Priorität selbst
        except Exception:  # noqa: BLE001
            pass
        t0 = time.time()
        rb = rueckblick_rechnen(db_, log=lambda s: print(s, flush=True))
        if rb.get("laeuft"):
            print("Ein anderer Lauf rechnet den Rückblick gerade -- dieser Lauf endet, ohne zu rechnen.", flush=True)
            return 0
        print(rueckblick_text(rb, eingestellte_schwelle(db_)))
        print(f"\nRückblick abgelegt in {pfad(db_)} · {time.time() - t0:.0f} s")
        return 0
    if "--rueckblick-text" in argv:
        rb, _gerechnet, _gewartet = rueckblick_holen(db_, log=lambda s: print(s, flush=True))
        if rb is None:
            print(f"Nach {RUECKBLICK_WARTEN_S // 60} Minuten liegt noch kein Rückblick vor -- bitte Debug 161 später noch einmal starten.")
            return 0
        print(rueckblick_text(rb, eingestellte_schwelle(db_)))
        return 0
    if "--text" in argv:
        coins_ = (argv[argv.index("--coin") + 1].upper(),) if "--coin" in argv else COINS
        print(text(db_, coins_))
        return 0
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(haupt())
