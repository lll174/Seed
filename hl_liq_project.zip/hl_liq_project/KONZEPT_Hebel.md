# KONZEPT Hebel (U142) — Positionierung und Hebel: Binance-Top-Trader, Konten und Perp-Anteil vor Liquidationswellen

Stand 09.10.2026, Version 2026-09-23.63 (Opus 5.5). **Status: gebaut** (`hl_hebel.py`, eigene Datei `hebel.db`, Hebel-Takt im
Dashboard, Debug-Berichte, Berichtsplan 10.10. 08:15). Vorab festgelegt am 09.10.2026 gegen 03:00 Uhr, **bevor eine
einzige echte Zahl dieser Studie gerechnet wurde** und bevor das Ergebnis der Zyklus-Studie (U141, Lauf 09.10. 12:00) bekannt war.
Die Kalibrierung lief nur auf synthetischen Märkten; vor dem ersten echten Lauf an fünf Stellen präzisiert (Abschnitt 12).

**Frage des Nutzers (09.10. 02:05, gekürzt):** „Gibt es Schnittstellen bzw. API-Befehle, um auf die Top-Trader-Daten und deren
Aktionen zuzugreifen und die auszuwerten? Die geben oftmals auch starke Hinweise, ebenso die Market-Maker-Aktivitäten. Wenn es
Leverage bei 95 % gegenüber 5 % Spot ist, dann wird fast immer erfahrungsgemäß eine Liquidierung durchgeführt. Die Frage ist, kann
man auf Binance-Daten zugreifen und diese Daten auswerten?“ Danach (02:48): „Warum machst du heute Nacht nichts?“ — gelesen als
Auftrag, U142 zu bauen (Bewertung in UEBERGABE 3νν und `RECHERCHE_Positionierung_ChartTrader_09-10-2026.md`).

**Zusage bis 25.10. bleibt:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen bleiben unberührt. Keine neue Labor-Strategie; die
Konfluenz bleibt, wie sie ist, bis zum Urteil. `hl_zyklus.py` bleibt unverändert (der Lauf 09.10. 12:00 ist nicht berührt).

## 0. Kurzfassung

- **Eigene Studie, nur lesend, eigene Datei `hebel.db`** neben der Hauptdatenbank (wie `swing.db`). Ein Takt im Dashboard-Prozess
  lädt das Binance-Archiv (data.binance.vision) im Hintergrund: die Tagesdateien „metrics“ (5-min-Zeilen, gespeichert wird eine
  Zeile je Stunde) für BTC, ETH, ZEC, XMR, HYPE ab 01.09.2020 und die Tageskerzen der Spot-, USDⓈ-M- und COIN-M-Märkte ab 2020.
  Zusätzlich sichert er die Liquidationen von Bybit/OKX und die Binance-Buchtiefe aus der Hauptdatenbank, bevor deren Vorhaltefrist
  (90 bzw. 60 Tage) sie löscht.
- **Vier Hauptprüfungen (Holm über die prüfbaren):**
  - **H1** „Konten ≥ 3“ (Hinweis „Kaskadenrisiko nach unten“ im Dashboard) kündigt einen Rücksetzer in 7 Tagen an.
  - **H2** Die Top-Trader-Regel der Konfluenz (Positionsverhältnis ≥ 1,5 Kauf, ≤ 0,67 Verkauf) sagt die Richtung des nächsten Tages.
  - **H3** Perp-Anteil am Volumen ≥ 95 % (die Regel des Nutzers, wie formuliert) kündigt eine Liquidationswelle in 7 Tagen an.
  - **H4** Perp-Anteil im obersten Zehntel der eigenen 90 Tage kündigt eine Liquidationswelle in 7 Tagen an.
- **Liquidationswelle** (Historie): binnen 7 Tagen fällt das Open Interest (in Coins, stündlich) um mindestens 1,5 seiner eigenen
  Schwankung × √7, und der Kurs schlägt um mindestens 1,5 σ × √7 aus (Hoch oder Tief) — erzwungener Abbau plus große Bewegung.
- **Nullmodelle:** H1 und H2 messen Richtung — 1000 Vorzeichen-Surrogate wie U141 Teil C (Drift und Schwankung bleiben). H3 und H4
  messen Risiko — Zeitverschiebung des Signals um 30–365 Tage (beide Richtungen), damit bleibt jede Ballung von Signal und
  Ereignis erhalten, nur die Zuordnung „Signal vor Ereignis“ wird gelöst.
- **Beschreibend:** Perzentil-Varianten aller Verhältnisse, Horizonte 3 und 14 Tage, Richtung der Wellen, je Coin und Jahr,
  Verteilung des Perp-Anteils (Null-Gebühren-Brüche sichtbar), Abgleich Archiv gegen die Live-Reihe in `bnc_metrics`, Stand heute.
- **Urteil nur bei vollständig geladener Historie;** vorher „vorläufig“.

## 1. Die Fragen, messbar gemacht

| Frage | Messung | Prüfung |
|---|---|---|
| Kündigen viele Long-Konten (Konten ≥ 3) einen Absturz an? | Rücksetzer: tiefster Schluss der nächsten 7 Tage ≤ c·e^{−1,5 σ √7} | H1, Vorzeichen-Surrogate |
| Sagt die Positionierung der größten Konten die Richtung? | vorzeichenrichtige Rendite des nächsten Tages in σ | H2, Vorzeichen-Surrogate, zweiseitig (folgen oder dagegen) |
| Folgt auf 95 % Hebel eine Liquidierung? | Liquidationswelle in 7 Tagen nach Perp-Anteil ≥ 0,95 | H3, Zeitverschiebung |
| Folgt auf ungewöhnlich hohen Hebel eine Liquidierung? | dasselbe nach Perp-Anteil im obersten Zehntel der 90 Tage | H4, Zeitverschiebung |
| Aktionen einzelner Top-Trader, Market Maker | auf Binance nicht abrufbar (Aggregat, anonym); auf Hyperliquid schon gemessen (Darwin, Elite, `hl_score`) | — (UEBERGABE 3νν) |

„Fast immer“ heißt in dieser Studie: Die Quote nach dem Signal wird gegen die Quote an allen anderen Tagen gestellt (relatives Risiko
RR) — eine hohe Quote allein beweist nichts, wenn Wellen ohnehin häufig sind.

## 2. Erwartung (ehrlich, vorab)

- Literatur (`RECHERCHE_Regime_07-10-2026.md`): Positionierung und Flüsse messen Risiko, nicht Richtung; hoher Carry kündigt Crashs an
  (BIS WP 1087); für OI und Long/Short-Quoten als 1–7-Tage-Prädiktoren keine außerhalb der Stichprobe geprüfte Studie.
- Eigene Befunde: U130 0 von 45; Magnet und Anker ohne Beleg; die Konfluenz als Ganzes 54 % gegen 52 % Zufall (07.10.).
- Erwartet: **H2 ohne Beleg** (Richtung). **H1** schwach oder ohne Beleg. **H4** am ehesten ein Risikosignal (RR um 1,2–1,5), falls
  überhaupt. **H3** hängt daran, wie oft 95 % in der hier gemessenen Abgrenzung erreicht werden — womöglich nicht prüfbar.
- Geometrie vorab: Für einen Zufallsweg liegt die Quote „tiefster Schluss binnen 7 Tagen ≤ −1,5 σ √7“ um 10–13 %; ein
  zweiseitiger Ausschlag (Hoch oder Tief) um 25 %; zusammen mit dem OI-Abbau erwartet: 5–10 % der Tage.

## 3. Daten

### 3a. Quellen und Abgrenzung

| Reihe | Quelle (data.binance.vision) | Zeitraum | Gespeichert |
|---|---|---|---|
| OI (Coins und USD), Top-Trader nach Konten, Top-Trader nach Positionen, alle Konten, Taker | `data/futures/um/daily/metrics/<COIN>USDT/` (Tagesdatei, 5-min-Zeilen) | ab 01.09.2020 bzw. Listung | `hb_metrics`: je Coin und Stunde die früheste Zeile der Stunde |
| Tageskerzen Perpetual (Kurs, Volumen, Taker-Kauf) | `data/futures/um/monthly/klines/<SYM>/1d/` (abgeschlossene Monate), `…/daily/klines/…` (laufender Monat) | ab 01.2020 | `hb_kerzen` |
| Tageskerzen COIN-M | `data/futures/cm/monthly/klines/<COIN>USD_PERP/1d/` | ab 01.2020 | `hb_kerzen` |
| Tageskerzen Spot | `data/spot/monthly/klines/<SYM>/1d/` | ab 01.2020 | `hb_kerzen` |

- **Coins:** BTC, ETH, ZEC, XMR, HYPE (die Labor-Coins mit Binance-Perpetual). Positionierung (H1, H2): alle fünf, gepoolt.
  Perp-Anteil (H3, H4): **BTC und ETH** (dauerhaft am Binance-Spot gelistet; XMR-Spot wurde 2024 entfernt, HYPE hat keinen).
- **Zuordnung der Archivspalten:** `count_long_short_ratio` = alle Konten (REST `globalLongShortAccountRatio`, im Dashboard „Konten“),
  `count_toptrader_long_short_ratio` = Top-Trader nach Konten (`topLongShortAccountRatio`), `sum_toptrader_long_short_ratio` =
  Top-Trader nach Positionswert (`topLongShortPositionRatio`, in der Konfluenz), `sum_taker_long_short_vol_ratio` = Taker,
  `sum_open_interest` = OI in Coins, `sum_open_interest_value` = OI in USD. Die Zuordnung prüft der Abgleich gegen die Live-Reihe
  (Abschnitt 6).
- **Perp-Anteil je Tag** = Derivate ÷ (Derivate + Spot), alles in USD:
  - Derivate = USDⓈ-M-Perpetuals `<COIN>USDT`, `<COIN>USDC`, `<COIN>BUSD` (Quote-Volumen) + COIN-M `<COIN>USD_PERP` (Kontrakte ×
    Kontraktgröße 100 USD bei BTC, 10 USD bei ETH). Quartalskontrakte nicht (viele Symbole, kleiner Anteil).
  - Spot = `<COIN>USDT`, `<COIN>FDUSD`, `<COIN>USDC`, `<COIN>BUSD`, `<COIN>TUSD` (Quote-Volumen; Stablecoin = 1 USD). Fiat-Paare
    (TRY, EUR, BRL …) nicht.
  - Definiert nur an Tagen mit Perp `<COIN>USDT` und Spot `<COIN>USDT` (beide > 0); ein Paar ohne Datei im Monat zählt als nicht
    gelistet (0). Null-Gebühren-Aktionen (BTC-Spot 2022/23) verschieben Spotvolumen zwischen Paaren — die Summe über alle Paare
    fängt das auf; den Bruch selbst zeigt der Bericht je Jahr.
- **Kurs:** Tageskerze des Perpetuals `<COIN>USDT` (Schluss, Hoch, Tief); Tag = UTC-Kalendertag.

### 3b. Zeitpunkt der Entscheidung (kausal)

Entscheidung am Ende von Tag d (00:00 UTC von d+1). Verhältnisse und OI: die jüngste Stundenzeile mit Zeitstempel in
[(d+1)·86400 − 7200, (d+1)·86400], sonst fehlt der Tag. Perp-Anteil: Volumen des ganzen Tages d. σ_d: EWMA der quadrierten
Tagesrenditen mit Halbwertszeit 20 Tagen einschließlich d (wie `hl_swing`, `hl_zyklus`). Das 90-Tage-Perzentil (Mittelrang) zählt
die 90 Tage VOR d (mindestens 60 Werte), wie `hl_zyklus.oi_perzentil`.

### 3c. Laden und Sichern (Takt `hebel`)

- Alle 5 min: ist etwas zu tun, lädt der Takt höchstens 240 s lang, 0,35 s Pause zwischen zwei Dateien. Reihenfolge je Runde:
  (1) Sicherung (stündlich), (2) frische Tage (gestern, laufender Monat), (3) Historie: erst alle Monatsdateien der Kerzen, dann
  „metrics“ je Coin rückwärts vom jüngsten Tag bis 01.09.2020; 30 Tage in Folge ohne Datei (404) = vor der Listung, Coin fertig.
- 404 in der Historie zählt als fehlend (Tabelle `hb_dateien`, nie erneut). Die jüngsten 2 Tage werden bei 404 stündlich erneut
  versucht, die Monatsdatei des Vormonats bis zum 7. des Monats (bis dahin decken Tagesdateien den Vormonat ab). Tagesdateien nur für
  Symbole mit Monatsdatei im Vormonat oder im Monat davor (nicht mehr gelistete Paare wie BUSD/TUSD kosten so keine Abrufe).
  Netzfehler: Pause 15 min, verdoppelt bis 6 h.
- Sicherung (nur lesend aus `hl_liq.db`): `ext_liquidations` (Bybit vollständig, OKX) nach `hb_liq`, `bnc_book` ohne Wände nach
  `hb_buch`; je Runde bis 50.000 Zeilen, ab dem jüngsten gesicherten Zeitstempel. Kein Löschen in `hebel.db`.
- Schreiben nur mit BEGIN IMMEDIATE (Projektregel); Sperre gegen gleichzeitiges Laden (Takt und Debug-Eintrag).
- Erwarteter Umfang: rund 9.400 metrics-Dateien und 1.700 Monatsdateien; auf dem Pi rund 2–3 h, danach täglich wenige Dateien.

## 4. Größen

- **Rendite, σ:** r_d = ln(c_d/c_{d−1}); σ_d wie 3b.
- **Rücksetzer E_A(h):** min(c_{d+1} … c_{d+h}) ≤ c_d·e^{−1,5 σ_d √h} (Schlusskurse, wie U141 Teil C mit h = 7 statt 14).
- **Ausschlag:** min(Tief_{d+1} … Tief_{d+h}) ≤ c_d·e^{−1,5 σ_d √h} (ab) bzw. max(Hoch…) ≥ c_d·e^{+1,5 σ_d √h} (auf).
- **OI-Abbau O(h):** min der stündlichen ln OI (Coins) in (Ende d, Ende d+h] ≤ ln OI_d − 1,5 s_d √h, s_d = EWMA-Schwankung der
  täglichen ln-OI-Änderung (00:00-Stände, Halbwertszeit 20 T, einschließlich d); gültig mit ≥ 80 % der Stunden. OI in Coins, weil
  das USD-OI schon durch den Kurs fällt.
- **Liquidationswelle E_D(h) = O(h) und Ausschlag (ab oder auf).** Richtung: ab, auf oder beide.
- **Signale:** S1 Konten_d ≥ 3,0; S2 Top-Trader-Positionen_d ≥ 1,5 (+1) bzw. ≤ 0,67 (−1); S3 Perp-Anteil_d ≥ 0,95;
  S4 Perzentil des Perp-Anteils_d ≥ 0,90.
- **Episoden:** Signaltage, getrennt durch mehr als h Tage ohne Signal.

## 5. Hauptprüfungen (vorab festgelegt)

| | Signal | Ereignis | Coins | Statistik | Null | Richtung |
|---|---|---|---|---|---|---|
| H1 | Konten ≥ 3 | E_A(7) | 5, gepoolt | RR | 1000 Vorzeichen-Surrogate (Signal fest, Kurse neu), ein Vorzeichen je Kalendertag für alle Coins, Drift bleibt | einseitig (RR größer) |
| H2 | Top-Trader-Positionen ≥ 1,5 / ≤ 0,67 | Rendite d+1 | 5, gepoolt | T = Mittel von s_d·r_{d+1}/σ_d | dieselben Surrogate (σ neu je Surrogat) | zweiseitig |
| H3 | Perp-Anteil ≥ 0,95 | E_D(7) | BTC, ETH | RR | Zeitverschiebung des Signals um jedes τ von 30 bis 365 Tagen in beide Richtungen (672 Verschiebungen), zirkulär, gleich für beide Coins | einseitig |
| H4 | Perzentil Perp-Anteil ≥ 0,90 | E_D(7) | BTC, ETH | RR | wie H3 | einseitig |

- **Prüfbar** ist ein Test mit ≥ 30 Signaltagen und ≥ 3 Episoden; bei RR (H1, H3, H4) zusätzlich ≥ 30 gültige Tage ohne Signal.
  Holm über die prüfbaren.
- **Belegt** = p Holm < 0,05 **und** beide Kalenderhälften (Mitte der Spanne mit Signal) in dieselbe Richtung: H1/H3/H4 RR über dem
  Median der Null in jeder Hälfte; H2 T auf derselben Seite des Null-Medians wie im Ganzen.
- **Intervall:** 90-%-Band aus dem zirkulären Kalender-Blockbootstrap (Block 60 Tage, 1000 Ziehungen, dieselben Blöcke für alle
  Coins) — für RR bzw. T.
- **Urteil nur, wenn die Historie vollständig geladen ist** (alle fünf Coins „metrics fertig“, alle Monatskerzen bearbeitet); sonst
  heißt jede Zeile „vorläufig“.
- Warum zwei Nullmodelle: Vorzeichen-Surrogate behalten die Schwankung; ein Signal, das nur hohe Schwankung anzeigt, erzeugt auf
  ihnen genauso viele Ereignisse — richtig für Richtungsfragen (H1, H2), falsch für die Risikofrage „kommt eine Welle“ (H3, H4).
  Die Zeitverschiebung behält Kurse, OI und Signal je für sich vollständig und löst nur die zeitliche Zuordnung; die Begrenzung auf
  ein Jahr hält lange Trends (mehr Wellen 2020–2022) aus dem Vergleich.

## 6. Beschreibend (kein Urteil)

1. Perzentil-Varianten (≥ 0,90 bzw. ≤ 0,10 der eigenen 90 Tage) für Konten, Top-Trader nach Konten, Top-Trader nach Positionen und
   Taker: RR für E_A(7) und vorzeichenrichtige Rendite über 1, 3, 7 Tage gegen dieselben Surrogate.
2. H1, H3, H4 mit h = 3 und 14; H2 mit 3 und 7 Tagen.
3. Wellen nach H3/H4: ab, auf, beide; dazu das Funding-Vorzeichen am Signaltag (`swing.db`, überfüllte Seite).
4. Je Coin und je Jahr: Signaltage, Ereignisquote mit und ohne Signal.
5. Perp-Anteil: Median und 10/90-%-Quantil je Jahr und Coin, Tage ≥ 0,95, Anteile der Spotpaare am Spotvolumen je Jahr.
6. OI ÷ Spotvolumen (Perzentil ≥ 0,90) gegen E_D(7).
7. **Abgleich Archiv gegen Live:** `bnc_metrics` in `hl_liq.db` (seit 14.09. alle 5 min, nur lesen) gegen `hb_metrics` an
   denselben Stunden; je Kennzahl Zahl der Paare, Median der relativen Abweichung, Anteil ≤ 0,5 %, bester Versatz (0, ±300 s).
   Dazu: Zeilen mit Zeitstempel in Millisekunden in `bnc_metrics` (das alte `hl_binance.py --backfill` schrieb ms).
8. Gesicherte Liquidationen und Buchtiefe: Zeilen, Zeitraum, Tagessummen je Börse.

## 7. Stand heute (nur Lage)

Je Coin: letzter Archivtag, Konten, Top-Trader (Konten und Positionen), dazu der jüngste Live-Wert; ob S1/S2 heute an sind. BTC und
ETH: Perp-Anteil gestern und sein Perzentil, ob S3/S4 an sind, OI ÷ Spotvolumen. Daneben die gemessene Quote mit und ohne Signal.
Keine Empfehlung.

## 8. Folgen (vorab)

- **H1 belegt:** Der Hinweis „Kaskadenrisiko nach unten“ bekommt eine gemessene Grundlage (Quote mit/ohne). **Nicht belegt:**
  Vorschlag an den Nutzer, den Hinweis zu entfernen oder als „ungeprüft“ zu kennzeichnen.
- **H2 belegt „folgen“:** Der Konfluenz-Punkt bleibt. **Belegt „dagegen“:** Vorschlag, ihn umzudrehen. **Nicht belegt:** Vorschlag,
  ihn zu entfernen (er zählt sonst Rauschen mit). Jede Änderung der Konfluenz entscheidet der Nutzer.
- **H3/H4 belegt:** Kandidat für eine Warnkachel „Hebel-Anteil hoch“ mit der gemessenen Quote (eigener Plan-Punkt). **Nicht belegt:**
  nur Anzeige im Bericht.
- Kein Echtgeld, keine Labor-Strategie aus dieser Studie ohne neuen, vorab festgelegten Plan-Punkt.

## 9. Bericht

Debug „★ Hebel: Positionierung und Hebel gegen Spot (U142)“ (`hl_hebel.py --studie`): Daten (Abdeckung je Coin und Symbol, fehlende
Dateien, Ladestand), Ergebnis H1–H4 (Signaltage, Episoden, Quote mit/ohne, RR oder T mit 90-%-Band, Null-Median, p, p Holm, Hälften,
Urteil), Stand heute, beschreibende Teile 1–8, Lesart. Dazu „Hebel: Historie laden“ (höchstens 10 min im Vordergrund, geplante Berichte enden nach 15 min) und
„Hebel: Selbsttest“.

## 10. Proben (Selbsttest ohne Netz)

Parser (metrics mit Kopfzeile, leere Felder, Doppelte, Stundenauswahl; Kerzen mit und ohne Kopfzeile, Mikrosekunden ab 2025,
COIN-M-Kontraktgröße), Laden ohne Netz (rückwärts, Ende nach 30 × 404, frische Tage, Monat ersetzt Tage, Sperre, Budget), Sicherung
(inkrementell, doppelt sicher), Tafel je Coin (Entscheidungszeitpunkt, Kausalität), Ereignisse von Hand, Perp-Anteil von Hand,
Surrogat-Identität, Verschiebungen (ohne τ = 0, Bereich), Urteile (Holm, Hälften, prüfbar), Abgleich (Versatz erkannt, vertauschte
Spalten erkannt), Bericht; Statistik: Nulltests (kein Beleg) und Positivkontrollen je Hauptprüfung.

Gebaut (23.63): 51 Prüfungen, rund 19 s in der Sandbox — Parser (7), Laden ohne Netz (12, darunter Netzfehler mit Pause, Sperre,
Budget, Vormonat bis zum 7., eine Datei von gestern kommt später, Bericht mit echtem Ladestand), Sicherung (2), Tafel und Kausalität
(5), Ereignisse von Hand (5, darunter √h in der Schwelle), Verschiebungen und Surrogat-Identität (2), Urteile (5), Abgleich und
Bericht (2), Ende zu Ende über eine synthetische `hebel.db` mit `studie()` (2), Signale an der Schwelle (1), Nulltest (2), Bericht
der Studie (1), Positivkontrollen H1, H2 folgen, H2 dagegen, H3, H4 (5). Installationsschritt 37.

## 11. Entscheidungen beim Nutzer

1. Nach dem Urteil: Konfluenz-Regeln und Dashboard-Hinweis behalten, ändern oder entfernen (Abschnitt 8).
2. Ob die 95 % in einer anderen Abgrenzung gemeint sind (etwa eine Coinglass- oder CryptoQuant-Kennzahl) — dann neuer Test mit
   eigener Nummer, nicht diese Zahl umdeuten.

## 12. Änderungen vor dem ersten echten Lauf (09.10. 03:10–03:45, nur synthetische Märkte gesehen)

**12.1 Präzisiert (keine Regel der Urteile verschoben):**
0. **Gegenüber dem Vorkonzept** (`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` 7, 02:30, vor dem Bau) wurden in diesem Konzept
   (gegen 03:00, vor jeder Zahl) festgelegt: H2 über **einen** Tag statt drei (die Konfluenz arbeitet auf 4–24 h; 3 und 7 Tage
   beschreibend) und H1 nur mit 7 Tagen (3 und 14 beschreibend).
1. **Prüfbar bei H2** ohne „≥ 30 Tage ohne Signal“: T nutzt nur die Signaltage; die Bedingung gehört zu den RR-Tests (Abschnitt 5).
2. **RR an den Rändern:** ohne Signal- oder Vergleichstage NaN, ohne Ereignis im Vergleich ∞ (vorher brach die Rechnung mit einer
   Division durch null ab, gefunden in der Positivkontrolle H2).
3. **Laden** (Abschnitt 3c): frisch heißen die jüngsten 2 Tage (nicht 3); die Monatsdatei des Vormonats bis zum 7.; Tagesdateien
   nur für Symbole, die im Vormonat oder im Monat davor eine Monatsdatei hatten. Gefunden in der Ladeprobe: ein Symbol ohne
   Monatsdatei im Vormonat bekam sonst auch den laufenden Monat nicht, nicht gelistete Paare kosteten je rund 37 Abrufe.
4. **Stundenzeile** = die früheste Zeile der Stunde mit ihren eigenen Werten (keine Mischung über Zeilen); fehlt dort ein Feld,
   fehlt es für diese Stunde.

**12.2 Kalibrierung auf synthetischen Märkten** (5 Coins, GARCH mit gemeinsamem Faktor, persistente Verhältnisse, Perp-Anteil mit
„Null-Gebühren-Zeit“, stündliches OI als Zufallsweg; Skripte `kalib_null.py`, `kalib_risiko.py`, `kalib_trend.py`,
`kalib_power.py` im Arbeitsordner der Sitzung):
- **Nullreplikationen H1–H4** (30 Universen, 200 Surrogate): p < 0,05 bei H1 1, H2 1, H3 4, H4 1 von 30; die volle Bedingung
  (Holm, Hälften) einmal (H1, 3 %).
- **Zeitverschiebung allein** (120 Universen, BTC+ETH): p < 0,05 bei H3 4 von 98 prüfbaren, H4 8 von 120, Horizonte 3/14 T 4–6
  von 120, OI ÷ Spotvolumen 4 von 120 — im Rahmen von 5 %.
- **Trend-Null** (60 Universen: Schwankung und Perp-Anteil fallen gemeinsam über die Jahre, ohne Verbindung von Tag zu Tag): H3 2,
  H4 0, OI ÷ Spot 2 von 60; Median-RR 0,85 / 1,00 / 1,03. Gemeinsame Trends erzeugen keinen Scheinbefund — die Ereignisse sind in σ
  gemessen, die Verschiebung bleibt im Jahr.
- **Trennschärfe** (gepflanzte Effekte, Holm, Hälften): H4 bei RR ≈ 2 in 8 von 16 belegt, bei RR ≈ 3,6 in 16 von 16; H3 (wenige
  Signaltage) bei RR ≈ 2 in 3 von 16, bei RR ≈ 6 in 6 von 16; H1 bei RR ≈ 1,9 in 5 von 8; H2 bei T ≈ 0,17 σ in 7 von 8 (bei H3/H4
  Holm nur über die Risiko-Tests gerechnet, also eher zu günstig). **Lesart:** Ein RR um 1,2–1,5 ist mit sechs Jahren und zwei
  Coins nicht nachweisbar; „nicht belegt“ heißt dann „nicht nachweisbar“, nicht „wirkungslos“.
- **Mutationen** (`mut142.py`): 26 von 26 rot. Fünf blieben zuerst grün und bekamen eigene Proben: H2 einseitig statt zweiseitig
  (nur eine Positivkontrolle „dagegen“ deckt das auf), eine fehlende Datei von gestern sofort als fehlend gemerkt, die Schwelle ohne
  √h, Konten > 3,5 statt ≥ 3, die vertauschte Top-Trader-Regel.

## 13. Ergebnis des ersten Laufs

(steht aus — Berichtsplan 10.10. 08:15 `u142-hebel`, sonst 11.10. 08:15; vorher lädt der Hebel-Takt das Archiv, rund 2–3 h nach
dem Einspielen)
