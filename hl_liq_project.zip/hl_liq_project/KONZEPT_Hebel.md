# KONZEPT Hebel (U142) — Positionierung und Hebel: Binance-Top-Trader, Konten und Perp-Anteil vor Liquidationswellen

Stand 11.10.2026, Version 2026-09-23.64 (Opus 5.5). **Status: endgültig (Lauf 11.10. 08:16, Abschnitt 13.5) — H1 belegt (Konten ≥ 3
→ Rücksetzer in 7 Tagen, RR 2,77, auch geschichtet nach der Vorwoche), H2 nicht belegt, H3 nicht prüfbar (der Perp-Anteil erreichte
nie 95 %), H4 nicht belegt (eher seltener). Folgen entscheidet der Nutzer (Abschnitt 8 und 11).** Erster Lauf 10.10. 08:16 mit
Ladefehler von mir (13.3), behoben in 23.64.
Gebaut in 23.63 (`hl_hebel.py`, eigene Datei `hebel.db`, Hebel-Takt im Dashboard, Debug-Berichte, Berichtsplan 10.10./11.10. 08:15);
23.64 behebt den Ladefehler und ergänzt H1 beschreibend (Abschnitt 12.3). Vorab festgelegt am 09.10.2026 gegen 03:00 Uhr, **bevor
eine einzige echte Zahl dieser Studie gerechnet wurde** und bevor das Ergebnis der Zyklus-Studie (U141, Lauf 09.10. 12:00) bekannt
war. Die Kalibrierung lief nur auf synthetischen Märkten; vor dem ersten echten Lauf an fünf Stellen präzisiert (Abschnitt 12.1).

**Frage des Nutzers (09.10. 02:05, gekürzt):** „Gibt es Schnittstellen bzw. API-Befehle, um auf die Top-Trader-Daten und deren
Aktionen zuzugreifen und die auszuwerten? Die geben oftmals auch starke Hinweise, ebenso die Market-Maker-Aktivitäten. Wenn es
Leverage bei 95 % gegenüber 5 % Spot ist, dann wird fast immer erfahrungsgemäß eine Liquidierung durchgeführt. Die Frage ist, kann
man auf Binance-Daten zugreifen und diese Daten auswerten?“ Danach (02:48): „Warum machst du heute Nacht nichts?“ — gelesen als
Auftrag, U142 zu bauen (Bewertung in UEBERGABE 3νν und `RECHERCHE_Positionierung_ChartTrader_09-10-2026.md`).

**Zusage bis 25.10. bleibt:** Fusion, v3, Kaskaden-Rechnung und v1-Lernen bleiben unberührt. Keine neue Labor-Strategie; die
Konfluenz bleibt, wie sie ist, bis zum Urteil. `hl_zyklus.py` bleibt unverändert (der Lauf 09.10. 12:00 ist nicht berührt).

## 0. Kurzfassung

- **Eigene Studie, nur lesend, eigene Datei `hebel.db`** neben der Hauptdatenbank (wie `swing.db`). Ein Takt im Dashboard-Prozess
  lädt das Binance-Archiv (data.binance.vision) im Hintergrund: die Tagesdateien „metrics“ (5-min-Zeilen, gespeichert wird eine
  Zeile je Stunde) für BTC, ETH, ZEC, XMR, HYPE ab 01.09.2020 und die Tageskerzen der Spot-, USDⓈ-M- und COIN-M-Märkte ab 2020.
  Zusätzlich sichert er die Liquidationen von Bybit/OKX und die Binance-Buchtiefe aus der Hauptdatenbank, bevor deren Vorhaltefrist
  (90 bzw. 60 Tage) sie löscht.
- **Vier Hauptprüfungen (Holm über die prüfbaren):**
  - **H1** „Konten ≥ 3“ (Hinweis „Kaskadenrisiko nach unten“ im Dashboard) kündigt einen Rücksetzer in 7 Tagen an.
  - **H2** Die Top-Trader-Regel der Konfluenz (Positionsverhältnis ≥ 1,5 Kauf, ≤ 0,67 Verkauf) sagt die Richtung des nächsten Tages.
  - **H3** Perp-Anteil am Volumen ≥ 95 % (die Regel des Nutzers, wie formuliert) kündigt eine Liquidationswelle in 7 Tagen an.
  - **H4** Perp-Anteil im obersten Zehntel der eigenen 90 Tage kündigt eine Liquidationswelle in 7 Tagen an.
- **Liquidationswelle** (Historie): binnen 7 Tagen fällt das Open Interest (in Coins, stündlich) um mindestens 1,5 seiner eigenen
  Schwankung × √7, und der Kurs schlägt um mindestens 1,5 σ × √7 aus (Hoch oder Tief) — erzwungener Abbau plus große Bewegung.
- **Nullmodelle:** H1 und H2 messen Richtung — 1000 Vorzeichen-Surrogate wie U141 Teil C (Drift und Schwankung bleiben). H3 und H4
  messen Risiko — Zeitverschiebung des Signals um 30–365 Tage (beide Richtungen), damit bleibt jede Ballung von Signal und
  Ereignis erhalten, nur die Zuordnung „Signal vor Ereignis“ wird gelöst.
- **Beschreibend:** Perzentil-Varianten aller Verhältnisse, Horizonte 3 und 14 Tage, Richtung der Wellen, je Coin und Jahr,
  Verteilung des Perp-Anteils (Null-Gebühren-Brüche sichtbar), Abgleich Archiv gegen die Live-Reihe in `bnc_metrics`, Stand heute.
- **Urteil nur bei vollständig geladener Historie;** vorher „vorläufig“.

## 1. Die Fragen, messbar gemacht

| Frage | Messung | Prüfung |
|---|---|---|
| Kündigen viele Long-Konten (Konten ≥ 3) einen Absturz an? | Rücksetzer: tiefster Schluss der nächsten 7 Tage ≤ c·e^{−1,5 σ √7} | H1, Vorzeichen-Surrogate |
| Sagt die Positionierung der größten Konten die Richtung? | vorzeichenrichtige Rendite des nächsten Tages in σ | H2, Vorzeichen-Surrogate, zweiseitig (folgen oder dagegen) |
| Folgt auf 95 % Hebel eine Liquidierung? | Liquidationswelle in 7 Tagen nach Perp-Anteil ≥ 0,95 | H3, Zeitverschiebung |
| Folgt auf ungewöhnlich hohen Hebel eine Liquidierung? | dasselbe nach Perp-Anteil im obersten Zehntel der 90 Tage | H4, Zeitverschiebung |
| Aktionen einzelner Top-Trader, Market Maker | auf Binance nicht abrufbar (Aggregat, anonym); auf Hyperliquid schon gemessen (Darwin, Elite, `hl_score`) | — (UEBERGABE 3νν) |

„Fast immer“ heißt in dieser Studie: Die Quote nach dem Signal wird gegen die Quote an allen anderen Tagen gestellt (relatives Risiko
RR) — eine hohe Quote allein beweist nichts, wenn Wellen ohnehin häufig sind.

## 2. Erwartung (ehrlich, vorab)

- Literatur (`RECHERCHE_Regime_07-10-2026.md`): Positionierung und Flüsse messen Risiko, nicht Richtung; hoher Carry kündigt Crashs an
  (BIS WP 1087); für OI und Long/Short-Quoten als 1–7-Tage-Prädiktoren keine außerhalb der Stichprobe geprüfte Studie.
- Eigene Befunde: U130 0 von 45; Magnet und Anker ohne Beleg; die Konfluenz als Ganzes 54 % gegen 52 % Zufall (07.10.).
- Erwartet: **H2 ohne Beleg** (Richtung). **H1** schwach oder ohne Beleg. **H4** am ehesten ein Risikosignal (RR um 1,2–1,5), falls
  überhaupt. **H3** hängt daran, wie oft 95 % in der hier gemessenen Abgrenzung erreicht werden — womöglich nicht prüfbar.
- Geometrie vorab: Für einen Zufallsweg liegt die Quote „tiefster Schluss binnen 7 Tagen ≤ −1,5 σ √7“ um 10–13 %; ein
  zweiseitiger Ausschlag (Hoch oder Tief) um 25 %; zusammen mit dem OI-Abbau erwartet: 5–10 % der Tage.

## 3. Daten

### 3a. Quellen und Abgrenzung

| Reihe | Quelle (data.binance.vision) | Zeitraum | Gespeichert |
|---|---|---|---|
| OI (Coins und USD), Top-Trader nach Konten, Top-Trader nach Positionen, alle Konten, Taker | `data/futures/um/daily/metrics/<COIN>USDT/` (Tagesdatei, 5-min-Zeilen) | ab 01.09.2020 bzw. Listung | `hb_metrics`: je Coin und Stunde die früheste Zeile der Stunde |
| Tageskerzen Perpetual (Kurs, Volumen, Taker-Kauf) | `data/futures/um/monthly/klines/<SYM>/1d/` (abgeschlossene Monate), `…/daily/klines/…` (laufender Monat) | ab 01.2020 | `hb_kerzen` |
| Tageskerzen COIN-M | `data/futures/cm/monthly/klines/<COIN>USD_PERP/1d/` | ab 01.2020 | `hb_kerzen` |
| Tageskerzen Spot | `data/spot/monthly/klines/<SYM>/1d/` | ab 01.2020 | `hb_kerzen` |

- **Coins:** BTC, ETH, ZEC, XMR, HYPE (die Labor-Coins mit Binance-Perpetual). Positionierung (H1, H2): alle fünf, gepoolt.
  Perp-Anteil (H3, H4): **BTC und ETH** (dauerhaft am Binance-Spot gelistet; XMR-Spot wurde 2024 entfernt, HYPE hat keinen).
- **Zuordnung der Archivspalten:** `count_long_short_ratio` = alle Konten (REST `globalLongShortAccountRatio`, im Dashboard „Konten“),
  `count_toptrader_long_short_ratio` = Top-Trader nach Konten (`topLongShortAccountRatio`), `sum_toptrader_long_short_ratio` =
  Top-Trader nach Positionswert (`topLongShortPositionRatio`, in der Konfluenz), `sum_taker_long_short_vol_ratio` = Taker,
  `sum_open_interest` = OI in Coins, `sum_open_interest_value` = OI in USD. Die Zuordnung prüft der Abgleich gegen die Live-Reihe
  (Abschnitt 6).
- **Perp-Anteil je Tag** = Derivate ÷ (Derivate + Spot), alles in USD:
  - Derivate = USDⓈ-M-Perpetuals `<COIN>USDT`, `<COIN>USDC`, `<COIN>BUSD` (Quote-Volumen) + COIN-M `<COIN>USD_PERP` (Kontrakte ×
    Kontraktgröße 100 USD bei BTC, 10 USD bei ETH). Quartalskontrakte nicht (viele Symbole, kleiner Anteil).
  - Spot = `<COIN>USDT`, `<COIN>FDUSD`, `<COIN>USDC`, `<COIN>BUSD`, `<COIN>TUSD` (Quote-Volumen; Stablecoin = 1 USD). Fiat-Paare
    (TRY, EUR, BRL …) nicht.
  - Definiert nur an Tagen mit Perp `<COIN>USDT` und Spot `<COIN>USDT` (beide > 0); ein Paar ohne Datei im Monat zählt als nicht
    gelistet (0). Null-Gebühren-Aktionen (BTC-Spot 2022/23) verschieben Spotvolumen zwischen Paaren — die Summe über alle Paare
    fängt das auf; den Bruch selbst zeigt der Bericht je Jahr.
- **Kurs:** Tageskerze des Perpetuals `<COIN>USDT` (Schluss, Hoch, Tief); Tag = UTC-Kalendertag.

### 3b. Zeitpunkt der Entscheidung (kausal)

Entscheidung am Ende von Tag d (00:00 UTC von d+1). Verhältnisse und OI: die jüngste Stundenzeile mit Zeitstempel in
[(d+1)·86400 − 7200, (d+1)·86400], sonst fehlt der Tag. Perp-Anteil: Volumen des ganzen Tages d. σ_d: EWMA der quadrierten
Tagesrenditen mit Halbwertszeit 20 Tagen einschließlich d (wie `hl_swing`, `hl_zyklus`). Das 90-Tage-Perzentil (Mittelrang) zählt
die 90 Tage VOR d (mindestens 60 Werte), wie `hl_zyklus.oi_perzentil`.

### 3c. Laden und Sichern (Takt `hebel`)

- Alle 5 min: ist etwas zu tun, lädt der Takt höchstens 240 s lang, 0,35 s Pause zwischen zwei Dateien. Reihenfolge je Runde:
  (1) Sicherung (stündlich), (2) frische Tage (gestern, laufender Monat), (3) Historie: erst alle Monatsdateien der Kerzen, dann
  „metrics“ je Coin rückwärts vom jüngsten Tag bis 01.09.2020; 30 Tage in Folge ohne Datei (404) = vor der Listung, Coin fertig.
- 404 in der Historie zählt als fehlend (Tabelle `hb_dateien`, nie erneut; Kerzendateien seit 23.64 unter „markt:symbol“, weil
  BTCUSDT, BTCUSDC, BTCBUSD und die ETH-Paare als Spotpaar und als Perp denselben Namen tragen, Abschnitt 13.3). Die jüngsten 2 Tage werden bei 404 stündlich erneut
  versucht, die Monatsdatei des Vormonats bis zum 7. des Monats (bis dahin decken Tagesdateien den Vormonat ab). Tagesdateien nur für
  Symbole mit Monatsdatei im Vormonat oder im Monat davor (nicht mehr gelistete Paare wie BUSD/TUSD kosten so keine Abrufe).
  Netzfehler: Pause 15 min, verdoppelt bis 6 h.
- Sicherung (nur lesend aus `hl_liq.db`): `ext_liquidations` (Bybit vollständig, OKX) nach `hb_liq`, `bnc_book` ohne Wände nach
  `hb_buch`; je Runde bis 50.000 Zeilen, ab dem jüngsten gesicherten Zeitstempel. Kein Löschen in `hebel.db`.
- Schreiben nur mit BEGIN IMMEDIATE (Projektregel); Sperre gegen gleichzeitiges Laden (Takt und Debug-Eintrag).
- Erwarteter Umfang: rund 9.400 metrics-Dateien und 1.700 Monatsdateien; auf dem Pi rund 2–3 h, danach täglich wenige Dateien.

## 4. Größen

- **Rendite, σ:** r_d = ln(c_d/c_{d−1}); σ_d wie 3b.
- **Rücksetzer E_A(h):** min(c_{d+1} … c_{d+h}) ≤ c_d·e^{−1,5 σ_d √h} (Schlusskurse, wie U141 Teil C mit h = 7 statt 14).
- **Ausschlag:** min(Tief_{d+1} … Tief_{d+h}) ≤ c_d·e^{−1,5 σ_d √h} (ab) bzw. max(Hoch…) ≥ c_d·e^{+1,5 σ_d √h} (auf).
- **OI-Abbau O(h):** min der stündlichen ln OI (Coins) in (Ende d, Ende d+h] ≤ ln OI_d − 1,5 s_d √h, s_d = EWMA-Schwankung der
  täglichen ln-OI-Änderung (00:00-Stände, Halbwertszeit 20 T, einschließlich d); gültig mit ≥ 80 % der Stunden. OI in Coins, weil
  das USD-OI schon durch den Kurs fällt.
- **Liquidationswelle E_D(h) = O(h) und Ausschlag (ab oder auf).** Richtung: ab, auf oder beide.
- **Signale:** S1 Konten_d ≥ 3,0; S2 Top-Trader-Positionen_d ≥ 1,5 (+1) bzw. ≤ 0,67 (−1); S3 Perp-Anteil_d ≥ 0,95;
  S4 Perzentil des Perp-Anteils_d ≥ 0,90.
- **Episoden:** Signaltage, getrennt durch mehr als h Tage ohne Signal.

## 5. Hauptprüfungen (vorab festgelegt)

| | Signal | Ereignis | Coins | Statistik | Null | Richtung |
|---|---|---|---|---|---|---|
| H1 | Konten ≥ 3 | E_A(7) | 5, gepoolt | RR | 1000 Vorzeichen-Surrogate (Signal fest, Kurse neu), ein Vorzeichen je Kalendertag für alle Coins, Drift bleibt | einseitig (RR größer) |
| H2 | Top-Trader-Positionen ≥ 1,5 / ≤ 0,67 | Rendite d+1 | 5, gepoolt | T = Mittel von s_d·r_{d+1}/σ_d | dieselben Surrogate (σ neu je Surrogat) | zweiseitig |
| H3 | Perp-Anteil ≥ 0,95 | E_D(7) | BTC, ETH | RR | Zeitverschiebung des Signals um jedes τ von 30 bis 365 Tagen in beide Richtungen (672 Verschiebungen), zirkulär, gleich für beide Coins | einseitig |
| H4 | Perzentil Perp-Anteil ≥ 0,90 | E_D(7) | BTC, ETH | RR | wie H3 | einseitig |

- **Prüfbar** ist ein Test mit ≥ 30 Signaltagen und ≥ 3 Episoden; bei RR (H1, H3, H4) zusätzlich ≥ 30 gültige Tage ohne Signal.
  Holm über die prüfbaren.
- **Belegt** = p Holm < 0,05 **und** beide Kalenderhälften (Mitte der Spanne mit Signal) in dieselbe Richtung: H1/H3/H4 RR über dem
  Median der Null in jeder Hälfte; H2 T auf derselben Seite des Null-Medians wie im Ganzen.
- **Intervall:** 90-%-Band aus dem zirkulären Kalender-Blockbootstrap (Block 60 Tage, 1000 Ziehungen, dieselben Blöcke für alle
  Coins) — für RR bzw. T.
- **Urteil nur, wenn die Historie vollständig geladen ist** (alle fünf Coins „metrics fertig“, alle Monatskerzen bearbeitet); sonst
  heißt jede Zeile „vorläufig“.
- Warum zwei Nullmodelle: Vorzeichen-Surrogate behalten die Schwankung; ein Signal, das nur hohe Schwankung anzeigt, erzeugt auf
  ihnen genauso viele Ereignisse — richtig für Richtungsfragen (H1, H2), falsch für die Risikofrage „kommt eine Welle“ (H3, H4).
  Die Zeitverschiebung behält Kurse, OI und Signal je für sich vollständig und löst nur die zeitliche Zuordnung; die Begrenzung auf
  ein Jahr hält lange Trends (mehr Wellen 2020–2022) aus dem Vergleich.

## 6. Beschreibend (kein Urteil)

1. Perzentil-Varianten (≥ 0,90 bzw. ≤ 0,10 der eigenen 90 Tage) für Konten, Top-Trader nach Konten, Top-Trader nach Positionen und
   Taker: RR für E_A(7) und vorzeichenrichtige Rendite über 1, 3, 7 Tage gegen dieselben Surrogate.
2. H1, H3, H4 mit h = 3 und 14; H2 mit 3 und 7 Tagen.
3. Wellen nach H3/H4: ab, auf, beide; dazu das Funding-Vorzeichen am Signaltag (`swing.db`, überfüllte Seite).
4. Je Coin und je Jahr: Signaltage, Ereignisquote mit und ohne Signal.
5. Perp-Anteil: Median und 10/90-%-Quantil je Jahr und Coin, Tage ≥ 0,95, Anteile der Spotpaare am Spotvolumen je Jahr.
6. OI ÷ Spotvolumen (Perzentil ≥ 0,90) gegen E_D(7).
7. **Abgleich Archiv gegen Live:** `bnc_metrics` in `hl_liq.db` (seit 14.09. alle 5 min, nur lesen) gegen `hb_metrics` an
   denselben Stunden; je Kennzahl Zahl der Paare, Median der relativen Abweichung, Anteil ≤ 0,5 %, bester Versatz (0, ±300 s).
   Dazu: Zeilen mit Zeitstempel in Millisekunden in `bnc_metrics` (das alte `hl_binance.py --backfill` schrieb ms).
8. Gesicherte Liquidationen und Buchtiefe: Zeilen, Zeitraum, Tagessummen je Börse.

## 7. Stand heute (nur Lage)

Je Coin: letzter Archivtag, Konten, Top-Trader (Konten und Positionen), dazu der jüngste Live-Wert; ob S1/S2 heute an sind. BTC und
ETH: Perp-Anteil gestern und sein Perzentil, ob S3/S4 an sind, OI ÷ Spotvolumen. Daneben die gemessene Quote mit und ohne Signal.
Keine Empfehlung.

## 8. Folgen (vorab)

- **H1 belegt:** Der Hinweis „Kaskadenrisiko nach unten“ bekommt eine gemessene Grundlage (Quote mit/ohne). **Nicht belegt:**
  Vorschlag an den Nutzer, den Hinweis zu entfernen oder als „ungeprüft“ zu kennzeichnen.
- **H2 belegt „folgen“:** Der Konfluenz-Punkt bleibt. **Belegt „dagegen“:** Vorschlag, ihn umzudrehen. **Nicht belegt:** Vorschlag,
  ihn zu entfernen (er zählt sonst Rauschen mit). Jede Änderung der Konfluenz entscheidet der Nutzer.
- **H3/H4 belegt:** Kandidat für eine Warnkachel „Hebel-Anteil hoch“ mit der gemessenen Quote (eigener Plan-Punkt). **Nicht belegt:**
  nur Anzeige im Bericht.
- Kein Echtgeld, keine Labor-Strategie aus dieser Studie ohne neuen, vorab festgelegten Plan-Punkt.

## 9. Bericht

Debug „★ Hebel: Positionierung und Hebel gegen Spot (U142)“ (`hl_hebel.py --studie`): Daten (Abdeckung je Coin und Symbol, fehlende
Dateien, Ladestand), Ergebnis H1–H4 (Signaltage, Episoden, Quote mit/ohne, RR oder T mit 90-%-Band, Null-Median, p, p Holm, Hälften,
Urteil), Stand heute, beschreibende Teile 1–8, seit 23.64 „Nachträglich ergänzt“ (Abschnitt 12.3, eigens gekennzeichnet), Lesart.
Dazu „Hebel: Historie laden“ (höchstens 10 min im Vordergrund, geplante Berichte enden nach 15 min) und „Hebel: Selbsttest“.

## 10. Proben (Selbsttest ohne Netz)

Parser (metrics mit Kopfzeile, leere Felder, Doppelte, Stundenauswahl; Kerzen mit und ohne Kopfzeile, Mikrosekunden ab 2025,
COIN-M-Kontraktgröße), Laden ohne Netz (rückwärts, Ende nach 30 × 404, frische Tage, Monat ersetzt Tage, Sperre, Budget), Sicherung
(inkrementell, doppelt sicher), Tafel je Coin (Entscheidungszeitpunkt, Kausalität), Ereignisse von Hand, Perp-Anteil von Hand,
Surrogat-Identität, Verschiebungen (ohne τ = 0, Bereich), Urteile (Holm, Hälften, prüfbar), Abgleich (Versatz erkannt, vertauschte
Spalten erkannt), Bericht; Statistik: Nulltests (kein Beleg) und Positivkontrollen je Hauptprüfung.

Gebaut (23.63): 51 Prüfungen, rund 19 s in der Sandbox — Parser (7), Laden ohne Netz (12, darunter Netzfehler mit Pause, Sperre,
Budget, Vormonat bis zum 7., eine Datei von gestern kommt später, Bericht mit echtem Ladestand), Sicherung (2), Tafel und Kausalität
(5), Ereignisse von Hand (5, darunter √h in der Schwelle), Verschiebungen und Surrogat-Identität (2), Urteile (5), Abgleich und
Bericht (2), Ende zu Ende über eine synthetische `hebel.db` mit `studie()` (2), Signale an der Schwelle (1), Nulltest (2), Bericht
der Studie (1), Positivkontrollen H1, H2 folgen, H2 dagegen, H3, H4 (5). Installationsschritt 37.

Seit 23.64: 63 Prüfungen, rund 26 s — dazu Spotpaar und gleichnamiges Perp getrennt geladen (1), Umstellung eines nachgestellten
23.63-Stands und Nachladen nur der Spotpaare (2), Ladestand gegen die Zeilen (gemerkte Monatsdatei ohne Zeilen = Widerspruch, 1),
Konten-Stand 1 h und 24 h früher (1), Schichtung von Hand, kausal, Mantel-Haenszel von Hand (3), geschichtetes H1: eine Schicht =
H1 mit derselben Null, Nulltest, Negativkontrolle Momentum, Positivkontrolle (4). Die Ende-zu-Ende-Probe holt die Kerzen jetzt über
den Lader aus einem Archiv ohne Netz (bis 23.63 schrieb sie am Lader vorbei) und verlangt „vollständig“ und H4 mit Daten.
Mutationen 37 von 37 rot (`mut142b.py`, Abschnitt 12.3).

## 11. Entscheidungen beim Nutzer

1. Nach dem Urteil: Konfluenz-Regeln und Dashboard-Hinweis behalten, ändern oder entfernen (Abschnitt 8).
2. Ob die 95 % in einer anderen Abgrenzung gemeint sind (etwa eine Coinglass- oder CryptoQuant-Kennzahl) — dann neuer Test mit
   eigener Nummer, nicht diese Zahl umdeuten.
3. Nach dem endgültigen Lauf (11.10.): H2 — Vorschlag nach Abschnitt 8, den Top-Trader-Punkt der Konfluenz zu entfernen; H1 — Text
   des Hinweises je nach Schichtung (12.3, Punkt 3); ob die beschreibenden Konten-Befunde (13.2) einen eigenen, vorab festgelegten
   Breitentest auf weiteren Binance-Perps bekommen (Vorschlag U144).

**Entschieden 11.10.2026 23:30 (Nutzer, Auswahl mit Vorschlag):**
- **1 und 3:**
  - Der Hinweis „Kaskadenrisiko nach unten“ (Binance, Konten ≥ 3) bekommt die gemessenen Quoten.
  - Der Top-Trader-Punkt fällt aus der Konfluenz.
  - Umsetzung U151 mit 23.67. H3/H4 bleiben nur im Bericht (wie vorab).
- **2:** Die 95 % stammten aus einer anderen Kennzahl; die Quelle ist dem Nutzer nicht mehr bekannt. U152: Liste gängiger
  Kennzahlen, er wählt, dann ein neuer Test mit eigener Nummer.
- **U144:** ja, als eigene Studie mit vorab festgelegten Regeln.

**Umgesetzt mit 23.67 (13.10.2026):**
- **U151:**
  - Der Top-Trader-Punkt (±1) ist aus der Konfluenz entfernt.
  - Der Konten-Hinweis (Binance, Konten ≥ 3) nennt die Quoten aus H1: „Geprüft an Binance-Daten seit 2020 (BTC, ETH, ZEC, XMR, HYPE):
    danach binnen 7 Tagen ein Rücksetzer um mehr als das 1,5-Fache der üblichen Wochenschwankung in 20 % der Fälle, sonst in 7 % —
    in 4 von 5 Fällen keiner“. Er bleibt ein Hinweis ohne Punkt.
  - Die Bilanz der Konfluenz trennt die Fälle seit dem Regelwechsel. Stichtag ist die erste Meldung eines Browsers mit dem neuen
    Regelstand (Tabelle `konfluenz_regel`). Gezeigt wird das im Dashboard („Seit der Regeländerung“) und in `hl_forecast.py --konfluenz`.
- **U152:** Die Liste steht in `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md`. Wörtlich bei „95 zu 5“ liegt nur der
  Perp-Anteil auf Hyperliquid (dort ≈ 97 %, der Normalfall). An den Börsen kommt nur CryptoQuants BTC-Messung über alle Börsen
  heran (an Einzeltagen 2025 aus genannten Volumen 95–98 %, als Verhältnisreihe höchstens 94,3 %). Der Nutzer wählt.

**Entschieden 13.10.2026 (Nutzer, Auswahl):**
- **Gemeint war die CryptoQuant-Messung:** Bitcoin, Derivate gegen Spot über alle Börsen („9 von 10 Trades sind Futures“).
- **Daten: kostenlos ab jetzt sammeln.** Der Nutzer legt ein kostenloses Konto mit Schlüssel an. Der Pi holt die Werte täglich; der
  letzte Monat kommt beim ersten Abruf mit.
- Test als **U158**, vorab festgelegt in Abschnitt 14, Bau mit 23.68.

## 12. Änderungen am Plan

**12.1 Vor dem ersten echten Lauf präzisiert (09.10. 03:10–03:45, nur synthetische Märkte gesehen; keine Regel der Urteile
verschoben):**
0. **Gegenüber dem Vorkonzept** (`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` 7, 02:30, vor dem Bau) wurden in diesem Konzept
   (gegen 03:00, vor jeder Zahl) festgelegt: H2 über **einen** Tag statt drei (die Konfluenz arbeitet auf 4–24 h; 3 und 7 Tage
   beschreibend) und H1 nur mit 7 Tagen (3 und 14 beschreibend).
1. **Prüfbar bei H2** ohne „≥ 30 Tage ohne Signal“: T nutzt nur die Signaltage; die Bedingung gehört zu den RR-Tests (Abschnitt 5).
2. **RR an den Rändern:** ohne Signal- oder Vergleichstage NaN, ohne Ereignis im Vergleich ∞ (vorher brach die Rechnung mit einer
   Division durch null ab, gefunden in der Positivkontrolle H2).
3. **Laden** (Abschnitt 3c): frisch heißen die jüngsten 2 Tage (nicht 3); die Monatsdatei des Vormonats bis zum 7.; Tagesdateien
   nur für Symbole, die im Vormonat oder im Monat davor eine Monatsdatei hatten. Gefunden in der Ladeprobe: ein Symbol ohne
   Monatsdatei im Vormonat bekam sonst auch den laufenden Monat nicht, nicht gelistete Paare kosteten je rund 37 Abrufe.
4. **Stundenzeile** = die früheste Zeile der Stunde mit ihren eigenen Werten (keine Mischung über Zeilen); fehlt dort ein Feld,
   fehlt es für diese Stunde.

**12.2 Kalibrierung auf synthetischen Märkten** (5 Coins, GARCH mit gemeinsamem Faktor, persistente Verhältnisse, Perp-Anteil mit
„Null-Gebühren-Zeit“, stündliches OI als Zufallsweg; Skripte `kalib_null.py`, `kalib_risiko.py`, `kalib_trend.py`,
`kalib_power.py` im Arbeitsordner der Sitzung):
- **Nullreplikationen H1–H4** (30 Universen, 200 Surrogate): p < 0,05 bei H1 1, H2 1, H3 4, H4 1 von 30; die volle Bedingung
  (Holm, Hälften) einmal (H1, 3 %).
- **Zeitverschiebung allein** (120 Universen, BTC+ETH): p < 0,05 bei H3 4 von 98 prüfbaren, H4 8 von 120, Horizonte 3/14 T 4–6
  von 120, OI ÷ Spotvolumen 4 von 120 — im Rahmen von 5 %.
- **Trend-Null** (60 Universen: Schwankung und Perp-Anteil fallen gemeinsam über die Jahre, ohne Verbindung von Tag zu Tag): H3 2,
  H4 0, OI ÷ Spot 2 von 60; Median-RR 0,85 / 1,00 / 1,03. Gemeinsame Trends erzeugen keinen Scheinbefund — die Ereignisse sind in σ
  gemessen, die Verschiebung bleibt im Jahr.
- **Trennschärfe** (gepflanzte Effekte, Holm, Hälften): H4 bei RR ≈ 2 in 8 von 16 belegt, bei RR ≈ 3,6 in 16 von 16; H3 (wenige
  Signaltage) bei RR ≈ 2 in 3 von 16, bei RR ≈ 6 in 6 von 16; H1 bei RR ≈ 1,9 in 5 von 8; H2 bei T ≈ 0,17 σ in 7 von 8 (bei H3/H4
  Holm nur über die Risiko-Tests gerechnet, also eher zu günstig). **Lesart:** Ein RR um 1,2–1,5 ist mit sechs Jahren und zwei
  Coins nicht nachweisbar; „nicht belegt“ heißt dann „nicht nachweisbar“, nicht „wirkungslos“.
- **Mutationen** (`mut142.py`): 26 von 26 rot. Fünf blieben zuerst grün und bekamen eigene Proben: H2 einseitig statt zweiseitig
  (nur eine Positivkontrolle „dagegen“ deckt das auf), eine fehlende Datei von gestern sofort als fehlend gemerkt, die Schwelle ohne
  √h, Konten > 3,5 statt ≥ 3, die vertauschte Top-Trader-Regel.

**12.3 Nach dem ersten Lauf (10.10.2026 ab 13:00, Ergebnis gesehen) — eine Korrektur, drei beschreibende Ergänzungen, ausdrücklich
nachträglich:**
1. **Ladefehler behoben (23.64), keine Regel geändert:** Kerzendateien stehen in `hb_dateien` unter „markt:symbol“ (Abschnitt 13.3).
   Beim ersten Öffnen stellt `verbinden()` die alten Einträge einmalig um: Sie bekommen den Markt des ersten gleichnamigen Symbols in
   `symbole()` — das Perp, denn die Laderunde arbeitet in dieser Reihenfolge, und der gemeinsame Schlüssel ließ das Spotpaar aus;
   danach `k_fertig = 0`, der Takt lädt die ausgelassenen Spotpaare nach (rund 490 Monats- und 40 Tagesdateien, 10–20 min).
   Neue Proben: Spotpaar und gleichnamiges Perp werden getrennt geladen; ein nachgestellter 23.63-Stand wird richtig umgestellt
   (metrics unverändert, nur einmal), danach lädt der nächste Lauf nur die Spotpaare nach, kein Perp erneut. Zusätzlich prüft der
   Ladestand die Buchführung gegen die Zeilen, die die Studie liest: Eine als geladen gemerkte Monatsdatei ohne Zeilen in ihrem Monat
   heißt „Widerspruch“ und „nicht vollständig“ — so wäre der Fehler sofort aufgefallen. Die Ende-zu-Ende-Probe lädt die Kerzen über den
   Lader.
2. **Beschreibend ergänzt, kein Urteil** (eigener Berichtsteil „Nachträglich ergänzt“, p roh):
   - **H1 mit dem Konten-Stand 1 h früher** (jüngste Zeile ≤ 23:00 UTC, höchstens 2 h alt). Der Abgleich (13.2) zeigt: Die
     Archivzeile „00:00“ entspricht der Live-Zeile 00:05 — der Stand zum Tagesende kann bis zu 5 min nach Mitternacht enthalten.
     Klein, aber ein Blick in die Zukunft; die 1-h-Variante schließt ihn aus.
   - **H1 mit dem Stand 24 h früher** (Ende des Vortags): Wie lange trägt der Stand?
   - **H1 geschichtet nach der Rendite der 7 Tage davor:** Schichten Coin × 5 Klassen von (ln c_d − ln c_{d−7}) ÷ (σ_d √7) mit den
     Grenzen −1, −⅓, +⅓, +1 (an der Grenze die untere Klasse); Mantel-Haenszel-RR; Null aus denselben 1000 Vorzeichen-Surrogaten wie
     H1 (gleiche Saat), Schichten fest aus den echten Kursen. **Grund — eine Lücke im vorab festgelegten Nullmodell, die ich beim
     Entwurf übersehen habe:** Die Vorzeichen-Surrogate zerstören auch Momentum. Steigt „Konten“ nach einem Rückgang (viele kaufen
     den Dip) und läuft ein Rückgang weiter, besteht H1, ohne dass die Konten selbst etwas sagen. Im Selbsttest belegt:
     synthetischer Markt mit Momentum, Konten hängen nur an der Vorwoche → H1 roh p < 0,05 in **30 von 30** Universen, geschichtet
     **0 von 30**; echter Konten-Effekt: 30 und 30 von 30; Zufallsmarkt: 0 und 0 von 30 (`kalib_mh.py`, 200 Surrogate).
   Die Ergänzungen ändern keine Zahl von H1–H4 und keiner bisherigen beschreibenden Zeile (geprüft: identische Ergebnisse von 23.63
   und 23.64 auf fünf synthetischen Märkten).
3. **Lesart der Schichtung, festgelegt bevor ihr Wert bekannt ist:** Bleibt der geschichtete RR über der Null (p < 0,05), trägt der
   Konten-Stand Information über die Vorwoche hinaus → Vorschlag: Hinweis „Kaskadenrisiko nach unten“ mit den gemessenen Quoten.
   Fällt er auf die Null (p ≥ 0,05), heißt H1 „Bedingung erfüllt, aber vermutlich ein Spiegel der Vorwoche“ → Vorschlag: den Hinweis
   so kennzeichnen oder entfernen. Beides entscheidet der Nutzer; das Urteil H1 nach Abschnitt 5 bleibt, wie es ist.
4. **Mutationen** (`mut142b.py`): die 26 bisherigen und 11 neue — Schlüssel ohne Markt (der Fehler bis 23.63), Umstellung mit dem
   letzten statt dem ersten Markt, ohne Neustart des Ladens, bei jedem Öffnen, Bedarf übersieht die Umstellung, Ladestand ohne Markt,
   Ladestand ohne Abgleich mit den Zeilen, Stand 1 h früher ohne Versatz, Schichtung mit der Rendite danach, geschichtete Null mit
   anderen Surrogaten, Schichtung ohne Klassen.

## 13. Ergebnis des ersten Laufs (10.10.2026 08:16, Modul 23.63, geplanter Bericht `u142-hebel`)

**13.1 Daten.** metrics: BTC ab 01.09.2020 (53.474 Stunden), ETH, ZEC, XMR ab 01.12.2021 (das Archiv beginnt für sie erst dort),
HYPE ab 30.05.2025; alle bis 08.10.2026 23:00 UTC, je 30–32 Tage ohne Datei. Kerzen aller Perps und COIN-M vollständig; Spot nur
BTC/ETH gegen FDUSD und TUSD — **die Spotpaare gegen USDT, USDC und BUSD fehlten (13.3)**. Rechenzeit 7 s.

**13.2 Ergebnis nach den vorab festgelegten Regeln — vorläufig (13.3):**

| | Wert (90-%-Band) | Null-Median | p | p Holm | Hälften (echt gegen Null) | Signaltage / Episoden | Bedingung |
|---|---|---|---|---|---|---|---|
| H1 Konten ≥ 3 → Rücksetzer 7 T | RR 2,77 (2,10–3,73); 20,3 % nach Signal gegen 7,4 % sonst | 1,57 | 0,003 | 0,006 (Holm über 2) | 3,55/1,58 und 2,56/1,54 ✓ | 526 / 61 | erfüllt |
| H2 Top-Trader-Regel → Richtung 1 T | T −0,018 σ (−0,066…+0,029), Treffer 49 % | +0,024 | 0,148 | 0,148 | ✓ | 2.466 / 176 | nicht erfüllt |
| H3 Perp-Anteil ≥ 95 % | ohne Daten | | | | | | — |
| H4 Perp-Anteil oberstes Zehntel | ohne Daten | | | | | | — |

- **H1 im Einzelnen:** je Coin BTC RR 4,63 (26 von 80 Signaltagen gegen 149 von 2.121), ETH 1,97, ZEC 3,38, XMR 2,26, HYPE 2,21
  (1 von 6); je Jahr (Quote mit/ohne Signal) 2021 25 %/5 %, 2022 30 %/9 %, 2023 42 %/6 %, 2024 15 %/8 % (262 Signaltage), 2025
  17 %/8 %, 2026 50 %/7 % (16 Tage); andere Horizonte: 3 Tage RR 2,53 (Null 1,66, p 0,001), 14 Tage RR 2,64 (Null 1,48, p 0,012).
  Lesart: nach dem Signal in rund 4 von 5 Fällen **kein** solcher Rücksetzer; die Konten-Regel ist ein Risikohinweis, keine
  Vorhersage. Ob sie mehr sagt als der Kursverlauf der Vorwoche, zeigt erst die Schichtung (12.3).
- **H2 im Einzelnen:** Die Regel steht fast immer auf „Kauf“ — BTC 540 Kauf / 0 Verkauf, ETH 875/0, ZEC 465/3, HYPE 344/0, nur XMR
  27/212. Die Top-Trader sind nach Positionswert fast immer netto long; der Konfluenz-Punkt ist damit nahezu eine Konstante.
- **Beschreibend (p roh, viele Vergleiche, kein Urteil):** Perzentil der eigenen 90 Tage als Gegenrichtung — oberstes Zehntel +1,
  unterstes −1: Konten T −0,092 σ über 1 Tag (p 0,002), −0,121 über 3 Tage (p 0,006), −0,127 über 7 Tage (p 0,024); Top-Trader nach
  Konten −0,100 (p 0,002), −0,109, −0,130; Top-Trader nach Positionen −0,047 (p 0,09); Taker +0,036 (p 0,20). Rücksetzer nach dem
  obersten Zehntel: Konten RR 1,78 (p 0,051), Top-Trader nach Konten 1,94 (p 0,028). Dieselbe Lücke wie bei H1 (Momentum) gilt
  hier; ein Breitentest müsste die Schichtung von vornherein enthalten.
- **Abgleich Archiv gegen Live:** Zuordnung aller fünf Kennzahlen richtig, je 3.000 Paare (OI 2.309), Median der Abweichung
  0,00–0,07 %; Verhältnisse mit Versatz 300 s (Archivzeile T = Live-Zeile T + 5 min, deshalb 12.3), OI und Taker 0 s; keine Zeilen
  mit Millisekunden.
- **Sicherung:** 200.126 Liquidationen Bybit/OKX und 45.429 Buchzeilen seit 13.09.; größter Tag 08.10. (Bybit 77,9 Mio USD,
  OKX 85,6 Mio USD).
- **Stand heute (nur Lage):** ETH S1 an (Konten 3,41 zum Tagesende 08.10., live 3,07 um 08:10), BTC/ZEC/XMR/HYPE aus; S2 überall
  „Kauf“ außer XMR.

**13.3 Mein Fehler: „Ladestand vollständig“ war falsch.** `hb_dateien` merkte Kerzendateien unter (art, symbol, periode) — ohne
Markt. Sechs Spotpaare heißen wie ein USDⓈ-M-Perp (BTCUSDT, BTCUSDC, BTCBUSD, ETHUSDT, ETHUSDC, ETHBUSD): Das Perp lud zuerst, das
Spotpaar galt danach als „schon da“ und wurde nie geholt. Folgen: ohne Spot-USDT (Pflichtpaar) kein Perp-Anteil → H3/H4 „ohne
Daten“; der Ladestand zählte die Einträge des Perps mit → „vollständig“. Der Selbsttest fand es nicht, weil die Ladeprobe nur
Perp-Zeilen zählte und die Ende-zu-Ende-Probe die Kerzen direkt in die Datenbank schrieb, am Lader vorbei. Nach Abschnitt 5 (Urteil
nur mit vollständiger Historie) ist damit **jedes Urteil dieses Laufs vorläufig**, auch H1 und H2. Was der Fehler nicht berührt:
H1, H2 und alle Positionierungsteile lesen nur metrics und die Perp-Kerzen `<COIN>USDT`, beide vollständig. Werden H3/H4 prüfbar,
steigt Holm auf vier Tests: H1 p Holm ≤ 4 × 0,003 = 0,012 — die Bedingung bleibt erfüllt, solange RR und Hälften im zweiten Lauf
halten (zwei Tage mehr Daten). Behoben in 23.64 (12.3).

**13.4 Endgültig:** Lauf `u142-hebel-2` am 11.10.2026 08:15 (Laden höchstens 600 s, dann Studie) mit 23.64, nachdem der Takt die
Spotpaare nachgeladen hat. Ergebnis wird hier als 13.5 nachgetragen.

**13.5 Endgültiges Ergebnis (Lauf `u142-hebel-2`, 11.10.2026 08:16, Modul 23.64, Sammeldatei 08:25):**

*Daten:* Ladestand **vollständig** (seit 23.64 gegen die Zeilen geprüft). metrics wie 13.1, jetzt bis 09.10.2026 23:00 UTC
(BTC 53.498 Stunden, ETH 42.566, ZEC 42.542, XMR 42.518, HYPE 11.942; je 30–32 Tage ohne Datei bei ETH, ZEC, XMR, HYPE — dort fehlt
die Datei im Archiv). Kerzen jetzt mit allen Spotpaaren: BTC und ETH gegen USDT, FDUSD, USDC, BUSD (bis 15.12.2023), TUSD (bis
17.04.2026); Perps USDT, USDC, BUSD und COIN-M. Rechenzeit 12 s, Laufzeit 15 s.

| | Wert (90-%-Band) | Null-Median | p | p Holm (über 3 prüfbare) | Hälften (echt gegen Null) | Signaltage / Episoden | Urteil |
|---|---|---|---|---|---|---|---|
| H1 Konten ≥ 3 → Rücksetzer 7 T | RR 2,77 (2,12–3,71); 20,3 % nach Signal gegen 7,3 % sonst | 1,59 | 0,004 | 0,012 | 3,55/1,62 und 2,56/1,55 ✓ | 526 / 61 | **belegt** |
| H2 Top-Trader-Regel → Richtung 1 T | T −0,018 σ (−0,066…+0,029), Treffer 50 % | +0,025 | 0,188 | 0,376 | ✓ | 2.470 / 176 | **nicht belegt** |
| H3 Perp-Anteil ≥ 95 % | 0 Signaltage | — | — | — | — | 0 / 0 | **nicht prüfbar** |
| H4 Perp-Anteil oberstes Zehntel | RR 0,53 (0,29–0,81); 2,9 % nach Signal gegen 5,5 % sonst | 0,95 | 0,951 | 0,951 | 0,48/1,09 und 0,58/0,87 (beide unter der Null) | 750 / 85 | **nicht belegt** |

- **H1:** wie im ersten Lauf (RR 2,77, je Coin BTC 4,63 · ZEC 3,38 · XMR 2,27 · HYPE 2,21 bei nur 6 Signaltagen · ETH 1,97; jedes
  Jahr mit Signal höher, 2021–2026). Nach dem Signal folgte in rund 4 von 5 Fällen **kein** solcher Rücksetzer — ein Risikohinweis,
  keine Vorhersage. **Schichtung nach der Vorwoche (12.3, vorab gelesen):** Mantel-Haenszel-RR 2,52 gegen Null 1,56, p 0,012 (roh),
  in allen fünf Klassen über 2 (2,00 · 2,65 · 2,75 · 3,24 · 2,63); die Signale fallen meist nach schwachen Wochen (58 % in den beiden
  unteren Klassen), der Effekt bleibt in jeder. Nach der vorab festgelegten Lesart (12.3 Punkt 3) trägt der Konten-Stand Information
  über die Vorwoche hinaus. Stand 1 h früher RR 2,68 (p 0,006), 24 h früher RR 2,64 (p 0,002): Der 5-min-Versatz des Archivs
  erklärt nichts, der Stand trägt mindestens einen Tag.
- **H2:** Die Regel steht weiter fast immer auf „Kauf“ (BTC 541/0, ETH 876/0, ZEC 466/3, HYPE 345/0, XMR 27/212); über 3 und 7 Tage
  ebenso ohne Richtung (p 0,196 und 0,340).
- **H3 — die 95-%-Regel des Nutzers, wie formuliert:** Der Perp-Anteil am Binance-Volumen lag bei BTC und ETH von 2020 bis heute
  an **keinem einzigen Tag** bei 95 % oder darüber (BTC Median je Jahr 78–90 %, 90-%-Quantil höchstens 91,0 %; ETH 68–92 %, höchstens
  93,8 %, beide 2026). Die Regel ist mit dieser Abgrenzung nicht prüfbar; ob die 95 % aus einer anderen Kennzahl stammen, entscheidet
  der Nutzer (11 Punkt 2, dann neuer Test mit eigener Nummer).
- **H4:** nicht belegt — beschreibend sogar seltener: nach einem Perp-Anteil im obersten Zehntel folgte eine Liquidationswelle in
  2,9 % der Fälle gegen 5,5 % sonst, in beiden Hälften unter der Null, auch über die Schwankungsdrittel (Mantel-Haenszel-RR 0,57);
  BTC 0,75, ETH 0,27; Wellen danach 17× ab, 5× auf.
- **Beschreibend (p roh, viele Vergleiche):** Konten-Perzentil als Gegenrichtung wie im ersten Lauf (oberstes Zehntel → nächster Tag
  −0,091 σ, p 0,002; 3 T −0,121, 7 T −0,128); Top-Trader nach Konten ähnlich (−0,099, p 0,002); Rücksetzer nach dem obersten Zehntel
  Konten RR 1,78 (p 0,053), Top-Trader nach Konten 1,93 (p 0,024). Abgleich Archiv gegen Live richtig (Median-Abweichung 0,00–0,07 %).
  Gesichert: 200.991 Liquidationen Bybit/OKX und 47.151 Buchzeilen (13.09.–11.10.).
- **Folgen nach Abschnitt 8 (vorab), Entscheidung beim Nutzer:** H1 → Hinweis „Kaskadenrisiko nach unten“ mit den gemessenen Quoten
  (Vorschlag nach 12.3 Punkt 3); H2 → Vorschlag, den Top-Trader-Punkt der Konfluenz zu entfernen; H3/H4 → nur Anzeige im Bericht,
  keine Warnkachel; U144 (Breitentest) und die Abgrenzung der 95 % offen. Konfluenz und Hinweis bleiben bis zur Entscheidung, wie
  sie sind. **Entschieden 11.10. 23:30, siehe 11.** Der Prüfstand des Chartbilds („konten“, „top_pos“) wird mit dem nächsten Paket auf dieses Urteil gesetzt.

## 14. U158: CryptoQuant-Anteil der Derivate (Bitcoin, alle Börsen) ≥ 95 % vor Liquidationswellen — festgelegt 13.10.2026, vor dem Bau und vor jeder Zahl

**Anlass.** Die 95 % der Regel des Nutzers stammen nach seiner Wahl (11, 13.10.) aus CryptoQuants Bitcoin-Messung über alle Börsen.
In der Abgrenzung von H3 (Binance allein) gab es seit 2020 keinen Tag mit 95 %; in CryptoQuants Abgrenzung kommt der Wert vor
(`RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md`, K2). Die Zahl wird nicht umgedeutet: Geprüft wird die Regel, wie formuliert,
auf der Reihe, die der Nutzer meint.

**Daten:**
- CryptoQuant API mit dem kostenlosen Schlüssel des Nutzers (Stufe „Basic“: Marktdaten je Tag, 30 Tage Rückschau, 10 Abrufe je
  Minute, 10.000 Credits im Monat; laut cryptoquant.com/apis, 13.10.2026 gelesen: „No asset or endpoint is withheld — only the
  resolution changes by plan“).
- Endpunkt `btc/market-data/price-ohlcv`, je einmal `market=spot` und `market=perpetual`, `exchange=all_exchange`,
  `window=day`; Feld `volume`, bei `all_exchange` laut Doku in BTC. Parameter und Einheit sind beim Bau gegen die Doku und beim
  ersten Abruf auf dem Pi gegen die echte Antwort zu prüfen (die Sandbox erreicht die API nicht).
- **Abgrenzung:** Die API kennt Spot und Perpetuals, keine Termin-Futures. Die Kennzahl ist deshalb D = Perps ÷ (Perps + Spot), in
  BTC, je UTC-Tag. In den Artikeln heißt die Größe „Derivate“; Perps machen rund 92–93 % der Derivate aus (K11). Der Unterschied
  senkt den Anteil leicht.
- **Speicher:** `hebel.db`, eigene Tabelle mit Abrufzeit (Reihe, Tag, abgerufen, Wert; Schlüssel aus allen drei). Ein gleicher Wert
  gibt keine Zeile, eine Korrektur eine neue, die alte bleibt (wie `ak_wert`).
- **Takt:** einmal am Tag nach 01:00 UTC (der Vortag ist geschlossen), zwei Abrufe. Jeder Abruf holt die letzten 30 Tage. Ausfälle
  bis 30 Tage füllen sich damit von selbst, auch ein späterer Bau verliert nichts. Ohne Schlüssel kein Abruf; der Schlüssel erscheint
  in keinem Fehlertext und keinem Bericht (wie bei FRED).
- **Eingabe:** Feld „CryptoQuant-Schlüssel (kostenlos)“ im Dashboard neben dem FRED-Schlüssel (Makro, Tab „Daten“), oder
  `accesstokens.json` → `cryptoquant.api_key`.

**Signal und Ereignis:**
- **S5:** D_d ≥ 0,95, die Regel wie formuliert. Entscheidung am Ende von Tag d wie 3b.
- **Ereignis:** Liquidationswelle E_D(7) bei BTC, genau wie H3 (4): OI in Coins aus `hb_metrics` (Binance BTCUSDT) und der Ausschlag
  der Perp-Tageskerze. So bleibt H3 vergleichbar; die Reihen liegen schon vollständig vor.
- **Statistik:** RR = Quote von E_D(7) nach S5-Tagen ÷ Quote an den übrigen gültigen Tagen.

**Prüfung:**
- **Null:** zirkuläre Zeitverschiebung des Signals um jedes τ von 30 Tagen bis L − 30 Tage (L = Länge der gesammelten Reihe), einseitig.
  Anders als bei H3 nicht bis 365 Tage: Die Reihe wird lange kürzer als zwei Jahre sein.
- **Prüfbar** wie 5: mindestens 30 Signaltage in mindestens 3 Episoden, mindestens 30 gültige Tage ohne Signal, dazu L ≥ 180 Tage.
  Vorher steht nur beschreibend „noch nicht prüfbar (n Signaltage, m Episoden, L Tage)“.
- **Belegt:** p < 0,05 und RR über dem Median der Null in beiden Kalenderhälften.
- **Intervall:** 90 % aus dem zirkulären Kalender-Blockbootstrap mit Block 30 Tage (die Reihe ist kurz; H3 nutzte 60).
- **Ausgewertet** wird beim ersten Termin nach Erreichen der Prüfbarkeit, danach nicht erneut mit anderem Ergebnis „bis es passt“: Die
  erste prüfbare Auswertung ist das Urteil.

**Beschreibend (ohne Urteil):** Verlauf von D mit der 95-%-Linie (Tab Makro, „Hebel & Stimmung“); Tage ≥ 0,95 je Monat; das Perzentil
der eigenen 90 Tage (ab 60 Werten) gegen E_D(7) wie H4; Wellen ab, auf oder beide; der Abstand zu Binance allein (Perp-Anteil aus H3)
am selben Tag.

**Wirkung:** keine, bis zu einem Urteil und einer eigenen Entscheidung des Nutzers. Nicht in Konfluenz, Labor, Prognose, Treiber oder
Ausblick.

**Proben (für den Bau festgelegt, je mit Mutation):**
- Parser gegen die dokumentierte Antwortform, Einheit BTC, „kein Wert“ fällt weg.
- Archiv mit Abrufzeit: Korrektur neue Zeile, gleicher Wert keine; 30-Tage-Rückschau füllt eine Lücke.
- Ohne Schlüssel kein Abruf; der Schlüssel steht in keinem Fehlertext; Pause bei Fehler und bei der Abrufgrenze.
- Kennzahl von Hand (Perps ÷ Summe).
- Positivkontrolle: synthetischer Markt mit eingepflanztem RR ≈ 3 nach S5-Tagen → belegt in den meisten Märkten; Nullprobe ohne
  Effekt → höchstens 10 % belegt.
- Sperre „prüfbar“: unter 30 Signaltagen, unter 3 Episoden oder unter 180 Tagen kein Urteil.

**Erwartung vorab:**
- Tage mit 95 % sind selten (in den Artikeln einzelne Tage 2025). Die Prüfbarkeit kann deshalb ein Jahr oder länger dauern, vielleicht
  wird sie nie erreicht.
- Wird sie erreicht, erwarte ich RR nahe 1 bis 1,5. Nach hohem Binance-Anteil kamen Wellen eher seltener (H4: RR 0,53).

**Stand 17.10.2026: gebaut mit 23.68** (`hl_hebel`: Tabelle `hb_cq`, `cq_abruf`, `s5_rechnen`, `s5_bericht`; Debug „★ Hebel:
CryptoQuant-Anteil der Derivate (U158)“ im Wochenbericht, „CryptoQuant jetzt abrufen“; Chart und Schlüsselfeld im Makro-Abschnitt).
- **Doku-Abgleich 17.10.** (userguide.cryptoquant.com, docs.cryptoquant.com):
  - Basis `https://api.cryptoquant.com/v1`; Token als Kopfzeile `Authorization: Bearer …`. Die API nimmt ihn auch als Parameter
    `api_key`; das nutzen wir nicht, damit er nie in einer Adresse steht.
  - Antwort `status` und `result.data` mit `date` (JJJJ-MM-TT) und `volume`; `all_exchange` laut Doku in BTC.
  - Basic: Tageswerte, 30 Tage, 10 Abrufe je Minute; Fehlercodes 400/401/402/403/404/429/500.
  - **Widerspruch in der Doku:** Der ältere Userguide sagt „Token erst ab Professional“. Die neuere Seite „Plans and Limits“ führt
    `market-data/price-ohlcv` für Basic (Tag). Erst der erste Abruf auf dem Pi klärt das (Bericht 19.10. 20:15).
  - Das Schema schreibt beim Datum einmal „YYYY-DD-MM“, vermutlich ein Tippfehler. Der Bericht zählt unlesbare Daten eigens.
- **Ablauf:**
  - Abruf je Runde des Hebel-Takts, wenn fällig: ab 01:00 UTC, einmal am Tag, zwei Abrufe im Abstand von 7 s.
  - Erst wenn beide Märkte gelesen sind, gilt der Tag als abgerufen.
  - Pausen: 429 → 15 min; 401/403 und 402 → 24 h; Netz- und andere Fehler → 1 h.
  - Fehlertexte ohne Schlüssel (auch nicht als „Bearer …“).
- **Schlüssel eintragen:**
  - Format 16–256 Zeichen ohne Leerzeichen; ein Probeabruf (Spot, 3 Tage).
  - Nur ein abgelehnter Schlüssel (401/403) wird nicht geschrieben; bei jedem anderen Fehler wird er mit Warnung gespeichert.
  - Die Umgebungsvariable `CRYPTOQUANT_API_KEY` hat Vorrang vor `accesstokens.json`.
- **Urteil:** Das erste prüfbare Urteil wird einmal in `hb_meta` „s5_urteil“ abgelegt und nie überschrieben, auch nicht, wenn ein
  späterer Stand nicht prüfbar wäre. Danach sind die Zahlen beschreibend.
- **Proben** (15 neue im Hebel-Selbsttest, grün):
  - Parser, Adresse, ohne Schlüssel, Takt, Archiv (Korrektur, Kennzahl von Hand), Rückschau über 5 Tage Ausfall, Pausen, Schlüssel in
    keinem Text, Eintragen;
  - S5 von Hand (Zählung, RR, Episoden, L − 59 Verschiebungen); Sperre (150 Tage, 1 Episode, 12 Signaltage; genau 95 % zählt);
    Hälften (Effekt nur in der ersten Hälfte: p 0,003, nicht belegt); Urteil festgehalten;
  - Bericht Ende zu Ende über eine Attrappe der API in 30-Tage-Abrufen;
  - **Positivkontrolle:** RR ≈ 3 (gepoolt 2,97) mit 1.095 Tagen Reihe → belegt in 16 von 20 Märkten;
  - **Nullprobe:** 450 Tage → 2 von 40 belegt.
  - Mutationen 18 von 18 rot; Browserprobe 19 von 19, Mutationen 7 von 7 rot.
- **Nachweisgrenze** (gemessen 17.10.; synthetische Märkte mit rund 4 % Wellenquote ohne Signal, wie H4 auf echten Daten mit 5,5 %):
  - bei RR ≈ 3 belegt: mit 450 Tagen Reihe 8 von 30, mit 720 Tagen 14–19 von 30, mit 1.095 Tagen 23 von 30;
  - ohne Effekt belegt: 4 von 80, 3 von 80, 1 von 60.
  - **Folge:** In den ersten ein bis zwei Jahren wäre selbst ein dreifaches Risiko oft nicht belegbar. Das ist kein Grund, die Regel
    zu ändern; das erste prüfbare Urteil gilt wie festgelegt. Es heißt aber: „nicht belegt“ bei kurzer Reihe ist schwach.
