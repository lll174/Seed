#!/usr/bin/env python3
"""
hl_score.py -- Konto-Score: Wer hat recht, nicht nur wer ist groß.

Die goldene Regel des Projekts lautet: Bei den größten Konten liegt das meiste Wissen und
das beste Signal. Dieses Modul macht sie messbar statt behauptet. Je Konto und Coin ein
Score in [0, 1] aus fünf Komponenten, alle aus Daten, die bereits aufgezeichnet werden:

  Vorlauf (35 %)     Läuft das Konto dem Kurs voraus? Rendite eines Portfolios, das jedem
                     Schritt des Kontos folgt (1 h / 4 h / 24 h), abzüglich der Marktdrift
                     im selben Zeitraum. Ein Konto zählt je Stunde EINEN Schritt (Netto der
                     Stunde) -- ein Bot mit 200 Fills in einer Stunde hat nicht 200 Meinungen.
                     Bayes-geschrumpft: alpha * n / (n + 20).
  Edge je Umsatz (25 %)   PnL / Umsatz aus dem Leaderboard (30 Tage, sonst 7). Trennt Market
                     Maker (Milliarden Umsatz, Promille Edge) von Händlern. Kostenlos.
  Konsistenz (20 %)  Vorzeichen des PnL über Tag / Woche / Monat / Gesamt.
  Größe (10 %)       log10 des Positions- bzw. Kontowerts, rangnormiert. Bewusst klein: Größe
                     ist die HYPOTHESE der goldenen Regel, nicht ihr Beweis.
  Klasse (10 %)      direktional 1,0 · gemischt 0,6 · Hedge / Market Maker 0,0.

Jede Komponente wird über die bewerteten Konten rangnormiert (0-1), damit keine Skala
dominiert. Fehlt eine Komponente, zählt sie neutral (0,5).

Score-Test (wöchentlich): Rangkorrelation (Spearman) zwischen dem Score von vor sieben
Tagen und dem Vorlauf der Folgewoche, je Komponente. Liegt die Korrelation der Komponente
"Größe" bei null, ist die goldene Regel in ihrer Größen-Form für diesen Markt widerlegt --
und das wäre ein wichtiges Ergebnis. Die Regel wird von einer Behauptung zu einer
Hypothese mit Messung.

Tabellen (forecasts.db): account_score (Tages-Schnappschuss je Coin), learned.score_test.
"""
from __future__ import annotations

import bisect
import json
import math
import sqlite3
import time

GEWICHTE = {"vorlauf": 0.35, "edge": 0.25, "konsistenz": 0.20, "groesse": 0.10, "klasse": 0.10}
SHRINK_K = 20            # Bayes-Schrumpfung des Vorlaufs: alpha * n / (n + K)
HORIZONTE = (1, 4, 24)   # Stunden
WAL_SCHWELLE = 20e6      # Positionswert, ab dem ein Konto als Wal geführt wird (wie im Recorder)


# ---------------------------------------------------------------------------
# Rohdaten
# ---------------------------------------------------------------------------

def _signed(event: str, side: str, delta) -> float:
    """Kaufdruck positiv: Long eröffnet/aufgestockt oder Short reduziert/geschlossen."""
    d = abs(delta or 0)
    if event in ("open", "add", "flip"):
        return d if side == "long" else -d
    return -d if side == "long" else d


def lade_schritte(con, coin: str, seit: int, bis: int | None = None) -> dict:
    """
    Schritte je Konto: {addr: [(ts, richtung ±1, notional)]}, je Konto und Stunde EIN Schritt
    (Netto der Stunde). Quellen: whale_positions (Wale) und lb_events (Leaderboard-Konten).
    Ein Konto, das in BEIDEN Tabellen vorkommt (Wal und Leaderboard-Konto), wird nur aus
    whale_positions gelesen -- dort steht dieselbe Positionsänderung feiner aufgelöst; beide
    Quellen zu addieren zählte sie doppelt (Re-Audit N13).
    """
    bis = bis or int(time.time())
    roh: dict = {}
    wale: set = set()
    try:
        for ts, addr, event, side, delta in con.execute(
                "SELECT ts, addr, event, side, delta_usd FROM whale_positions WHERE coin=? AND ts>=? AND ts<? "
                "AND event IN ('open','add','reduce','close','flip')", (coin, seit, bis)):
            wale.add(addr.lower())
            v = _signed(event, side, delta)
            if v:
                roh.setdefault(addr.lower(), {}).setdefault(ts // 3600, [ts, 0.0])
                b = roh[addr.lower()][ts // 3600]; b[0] = min(b[0], ts); b[1] += v
    except sqlite3.OperationalError:
        pass
    try:
        for ts, addr, event, side, delta in con.execute(
                "SELECT ts, addr, event, side, delta_usd FROM lb_events WHERE coin=? AND ts>=? AND ts<?", (coin, seit, bis)):
            if addr.lower() in wale:
                continue
            v = _signed(event, side, delta)
            if v:
                roh.setdefault(addr.lower(), {}).setdefault(ts // 3600, [ts, 0.0])
                b = roh[addr.lower()][ts // 3600]; b[0] = min(b[0], ts); b[1] += v
    except sqlite3.OperationalError:
        pass
    out = {}
    for addr, stunden in roh.items():
        out[addr] = sorted((t0, 1.0 if v > 0 else -1.0, abs(v)) for t0, v in stunden.values() if v)
    return out


class Kurs:
    """Minutenbars eines Coins als sortierte Reihe; Preis zum Zeitpunkt und Vorwärtsrendite."""

    def __init__(self, con, coin: str, seit: int, bis: int | None = None):
        bis = bis or int(time.time())
        rows = con.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                           (coin, seit, bis)).fetchall()
        self.ts = [r[0] for r in rows]; self.px = [r[1] for r in rows]

    def at(self, t: int):
        i = bisect.bisect_right(self.ts, t) - 1
        return self.px[i] if i >= 0 else None

    def rendite(self, t: int, h: int):
        p0 = self.at(t); p1 = self.at(t + h * 3600)
        if not p0 or not p1 or t + h * 3600 > self.ts[-1]:
            return None
        return p1 / p0 - 1

    def drift(self, h: int, schritt: int = 900) -> float:
        """Unbedingte mittlere Vorwärtsrendite über den Zeitraum (alle 15 min ein Punkt)."""
        if not self.ts:
            return 0.0
        acc = []; t = self.ts[0]
        while t + h * 3600 <= self.ts[-1]:
            r = self.rendite(t, h)
            if r is not None:
                acc.append(r)
            t += schritt
        return sum(acc) / len(acc) if acc else 0.0


# ---------------------------------------------------------------------------
# Komponenten
# ---------------------------------------------------------------------------

def vorlauf(schritte: dict, kurs: Kurs) -> dict:
    """
    Je Konto: n Schritte, mittlere Folgerendite je Horizont (driftbereinigt), t-Wert (4 h),
    geschrumpfter Vorlauf alpha_4h. Folgerendite = Richtung * (Rendite - Drift).
    """
    drift = {h: kurs.drift(h) for h in HORIZONTE}
    out = {}
    for addr, lst in schritte.items():
        f = {h: [] for h in HORIZONTE}
        for ts, d, _ in lst:
            for h in HORIZONTE:
                r = kurs.rendite(ts, h)
                if r is not None:
                    f[h].append(d * (r - drift[h]))
        n = len(f[4])
        if not n:
            continue
        m = {h: (sum(v) / len(v) if v else None) for h, v in f.items()}
        sd = (sum((x - m[4]) ** 2 for x in f[4]) / max(1, n - 1)) ** 0.5 if n > 1 else None
        t = (m[4] / (sd / math.sqrt(n))) if sd and sd > 0 else 0.0
        out[addr] = {"n": n, "mean_1h": m[1], "mean_4h": m[4], "mean_24h": m[24],
                     "t_4h": round(t, 2), "alpha_4h": m[4] * n / (n + SHRINK_K)}
    return out


def kennzahlen(con) -> dict:
    """Leaderboard-Kennzahlen je Konto (lb_stats; Rückfall lb_accounts, dort ohne Umsatz)."""
    out = {}
    try:
        for r in con.execute("SELECT addr, account_value, pnl_1d, vlm_1d, pnl_7d, vlm_7d, pnl_30d, vlm_30d, pnl_all, vlm_all FROM lb_stats"):
            out[r[0].lower()] = {"account_value": r[1], "pnl_1d": r[2], "vlm_1d": r[3], "pnl_7d": r[4], "vlm_7d": r[5],
                                 "pnl_30d": r[6], "vlm_30d": r[7], "pnl_all": r[8], "vlm_all": r[9]}
    except sqlite3.OperationalError:
        pass
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
        if last:
            for r in con.execute("SELECT addr, account_value, pnl_30d, pnl_7d FROM lb_accounts WHERE ts=?", (last,)):
                out.setdefault(r[0].lower(), {"account_value": r[1], "pnl_30d": r[2], "pnl_7d": r[3]})
    except sqlite3.OperationalError:
        pass
    return out


def edge(k: dict):
    """PnL je Umsatz: 30 Tage, sonst 7 Tage; None ohne Umsatz."""
    for p, v in (("pnl_30d", "vlm_30d"), ("pnl_7d", "vlm_7d")):
        if k.get(v) and k[v] > 0 and k.get(p) is not None:
            return k[p] / k[v]
    return None


def konsistenz(k: dict):
    """Anteil positiver Fenster von Tag / Woche / Monat / Gesamt; None ohne Fensterdaten."""
    vals = [k.get(x) for x in ("pnl_1d", "pnl_7d", "pnl_30d", "pnl_all")]
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    return sum(1 for v in vals if v > 0) / len(vals)


def groessen(con, addrs: set) -> dict:
    out = {}
    try:
        for a, pv in con.execute("SELECT addr, pos_value FROM addresses WHERE pos_value > 0"):
            if a.lower() in addrs:
                out[a.lower()] = pv
    except sqlite3.OperationalError:
        pass
    return out


def _rang(werte: dict) -> dict:
    """Rangnormierung 0..1 (Mittelwert-Rang bei Gleichstand); leere Eingabe -> {}."""
    items = [(v, k) for k, v in werte.items() if v is not None]
    if len(items) < 2:
        return {k: 0.5 for _, k in items}
    items.sort()
    out = {}; i = 0
    while i < len(items):
        j = i
        while j + 1 < len(items) and items[j + 1][0] == items[i][0]:
            j += 1
        r = (i + j) / 2 / (len(items) - 1)
        for _, k in items[i:j + 1]:
            out[k] = r
        i = j + 1
    return out


# ---------------------------------------------------------------------------
# Score
# ---------------------------------------------------------------------------

def compute_scores(con, coin: str, klasse_of, days: int = 28, bis: int | None = None) -> dict:
    """
    Score je Konto für diesen Coin. klasse_of(addr) -> 'dir' | 'mixed' | 'hedge' | 'mm'.
    Liefert {addr: {score, vorlauf, edge, konsistenz, groesse, klasse, n, alpha_4h, t_4h, comps}}.
    """
    bis = bis or int(time.time())
    seit = bis - days * 86400
    schritte = lade_schritte(con, coin, seit, bis)
    kurs = Kurs(con, coin, seit - 3600, bis)
    V = vorlauf(schritte, kurs) if kurs.ts else {}
    K = kennzahlen(con)
    addrs = set(schritte) | {a for a in K if K[a].get("vlm_30d") or K[a].get("vlm_7d")}
    # Nur Konten, über die es etwas zu wissen gibt: Schritte im Coin ODER Leaderboard-Kennzahlen
    G = groessen(con, addrs)
    kl_wert = {"dir": 1.0, "mixed": 0.6, "hedge": 0.0, "mm": 0.0}
    roh = {}
    for a in addrs:
        k = K.get(a, {})
        v = V.get(a)
        g = G.get(a) or k.get("account_value")
        roh[a] = {"vorlauf": v["alpha_4h"] if v else None, "edge": edge(k), "konsistenz": konsistenz(k),
                  "groesse": math.log10(g) if g and g > 0 else None,
                  "klasse": kl_wert.get(klasse_of(a) if klasse_of else "dir", 1.0),
                  "n": v["n"] if v else 0, "alpha_4h": v["alpha_4h"] if v else None, "t_4h": v["t_4h"] if v else None,
                  "mean_1h": v["mean_1h"] if v else None, "mean_24h": v["mean_24h"] if v else None}
    R = {c: _rang({a: roh[a][c] for a in roh}) for c in ("vorlauf", "edge", "konsistenz", "groesse")}
    out = {}
    for a, r in roh.items():
        comps = {c: R[c].get(a, 0.5) for c in R}
        comps["klasse"] = r["klasse"]
        score = sum(GEWICHTE[c] * comps[c] for c in GEWICHTE)
        out[a] = {"score": round(score, 4), "n": r["n"], "alpha_4h": r["alpha_4h"], "t_4h": r["t_4h"],
                  "mean_1h": r["mean_1h"], "mean_24h": r["mean_24h"], "klasse": r["klasse"],
                  "edge_roh": r["edge"], "konsistenz_roh": r["konsistenz"], "groesse_roh": r["groesse"], "comps": comps}
    return out


# ---------------------------------------------------------------------------
# Speicher und Score-Test
# ---------------------------------------------------------------------------

def store_init(st: sqlite3.Connection) -> None:
    st.execute("""CREATE TABLE IF NOT EXISTS account_score (
        ts INTEGER, coin TEXT, addr TEXT, score REAL, vorlauf REAL, edge REAL, konsistenz REAL, groesse REAL, klasse REAL,
        n INTEGER, alpha_4h REAL, payload TEXT, PRIMARY KEY (ts, coin, addr))""")
    st.execute("CREATE INDEX IF NOT EXISTS ix_as_coin_ts ON account_score(coin, ts)")


def save_scores(st: sqlite3.Connection, coin: str, scores: dict, ts: int | None = None) -> None:
    store_init(st)
    ts = ts or int(time.time())
    st.executemany("INSERT OR REPLACE INTO account_score VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   [(ts, coin, a, v["score"], v["comps"]["vorlauf"], v["comps"]["edge"], v["comps"]["konsistenz"],
                     v["comps"]["groesse"], v["comps"]["klasse"], v["n"], v["alpha_4h"],
                     json.dumps({k: v[k] for k in ("t_4h", "mean_1h", "mean_24h", "edge_roh", "konsistenz_roh", "groesse_roh")}))
                    for a, v in scores.items()])
    st.execute("DELETE FROM account_score WHERE ts < ?", (ts - 120 * 86400,))
    st.commit()


def load_scores(st: sqlite3.Connection, coin: str, ts: int | None = None) -> tuple[int | None, dict]:
    """Jüngster Schnappschuss (oder jüngster vor ts): (ts, {addr: {score, klasse, n, alpha_4h, comps}})."""
    store_init(st)
    if ts is None:
        r = st.execute("SELECT MAX(ts) FROM account_score WHERE coin=?", (coin,)).fetchone()
    else:
        r = st.execute("SELECT MAX(ts) FROM account_score WHERE coin=? AND ts<=?", (coin, ts)).fetchone()
    if not r or not r[0]:
        return None, {}
    t0 = r[0]
    rows = st.execute("SELECT addr, score, vorlauf, edge, konsistenz, groesse, klasse, n, alpha_4h FROM account_score WHERE coin=? AND ts=?",
                      (coin, t0)).fetchall()
    return t0, {x[0]: {"score": x[1], "comps": {"vorlauf": x[2], "edge": x[3], "konsistenz": x[4], "groesse": x[5], "klasse": x[6]},
                       "klasse": x[6], "n": x[7], "alpha_4h": x[8]} for x in rows}


def spearman(x: list, y: list):
    n = len(x)
    if n < 5:
        return None
    rx = _rang({i: v for i, v in enumerate(x)}); ry = _rang({i: v for i, v in enumerate(y)})
    mx = sum(rx.values()) / n; my = sum(ry.values()) / n
    sxy = sum((rx[i] - mx) * (ry[i] - my) for i in range(n))
    sxx = sum((rx[i] - mx) ** 2 for i in range(n)); syy = sum((ry[i] - my) ** 2 for i in range(n))
    if sxx <= 0 or syy <= 0:
        return None
    return sxy / math.sqrt(sxx * syy)


def score_test(con, st: sqlite3.Connection, coin: str, tage: int = 7, min_n: int = 3) -> dict | None:
    """
    Out-of-sample: Score von vor `tage` Tagen gegen den Vorlauf der Schritte SEIT diesem
    Zeitpunkt (nur Schritte, die nach der Einstufung entstanden). Rangkorrelation je
    Komponente, mit ungefährem 95-%-Intervall (SE ≈ 1 / sqrt(n - 1)).
    """
    now = int(time.time())
    t0, alt = load_scores(st, coin, now - tage * 86400)
    if not t0 or len(alt) < 5:
        return None
    schritte = lade_schritte(con, coin, t0, now)
    kurs = Kurs(con, coin, t0 - 3600, now)
    if not kurs.ts:
        return None
    V = vorlauf(schritte, kurs)
    gemeinsam = [a for a in alt if a in V and V[a]["n"] >= min_n]
    if len(gemeinsam) < 5:
        return {"ts": now, "t0": t0, "n": len(gemeinsam), "zu_wenig": True}
    ziel = [V[a]["mean_4h"] for a in gemeinsam]
    out = {"ts": now, "t0": t0, "n": len(gemeinsam), "se": 1 / math.sqrt(len(gemeinsam) - 1)}
    out["rho"] = spearman([alt[a]["score"] for a in gemeinsam], ziel)
    for c in ("vorlauf", "edge", "konsistenz", "groesse", "klasse"):
        out[f"rho_{c}"] = spearman([alt[a]["comps"][c] for a in gemeinsam], ziel)
    return out


def elite(scores: dict, n: int = 10, nur_direktional: bool = True) -> list:
    """
    Die n Konten mit dem höchsten Score (Kandidaten für WebSocket-Abonnements) -- nur Konten,
    die in diesem Coin auch Schritte hatten; ein Leaderboard-Konto ohne Aktivität im Coin
    gehört nicht in dessen Elite (Re-Audit N14).
    """
    lst = [(v["score"], a) for a, v in scores.items()
           if (not nur_direktional or v.get("klasse", 1.0) >= 0.6) and (v.get("n") or 0) >= 1]
    lst.sort(reverse=True)
    return [a for _, a in lst[:n]]


if __name__ == "__main__":
    # Selbsttest: synthetische Konten, drei davon mit echtem Vorlauf, der Rest Rauschen.
    import random
    rng = random.Random(3)
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, close REAL)"); con.execute("CREATE INDEX i ON bars(coin, ts)")
    con.execute("CREATE TABLE whale_positions (ts, addr, coin, event, side, size, pos_value, entry_px, liq_px, leverage, upnl, mark_px, delta_usd)")
    con.execute("CREATE TABLE lb_events (ts, addr, coin, event, side, delta_usd, pos_value, mark_px)")
    con.execute("CREATE TABLE addresses (addr TEXT PRIMARY KEY, pos_value REAL)")
    con.execute("CREATE TABLE lb_stats (addr TEXT PRIMARY KEY, ts, account_value, pnl_1d, roi_1d, vlm_1d, pnl_7d, roi_7d, vlm_7d, pnl_30d, roi_30d, vlm_30d, pnl_all, roi_all, vlm_all)")
    now = int(time.time()) // 60 * 60; start = now - 28 * 86400; px = 60000.0; closes = {}
    for t in range(start - 3600, now + 60, 60):
        px *= math.exp(rng.gauss(0, 0.006 / math.sqrt(60))); closes[t] = px
    con.executemany("INSERT INTO bars VALUES (?,?,?)", [(t, "BTC", p) for t, p in closes.items()])
    konten = {f"0xgut{i}": 0.62 for i in range(3)} | {f"0xnull{i}": 0.5 for i in range(12)} | {"0xschlecht0": 0.38}
    ev = []
    for a, p in konten.items():
        t = start + rng.randint(0, 6 * 3600)
        while t < now - 5 * 3600:
            up = closes[t + 4 * 3600 - (t % 60)] > closes[t - (t % 60)]
            richtig = rng.random() < p
            side = "long" if (up == richtig) else "short"
            ev.append((t, a, "BTC", "add", side, 2e6 * rng.uniform(0.5, 2)))
            t += rng.randint(3 * 3600, 9 * 3600)
    con.executemany("INSERT INTO whale_positions (ts, addr, coin, event, side, delta_usd) VALUES (?,?,?,?,?,?)", ev)
    con.executemany("INSERT INTO addresses VALUES (?,?)", [(a, 30e6 if a.startswith("0xgut") else 25e6) for a in konten])
    con.executemany("INSERT INTO lb_stats VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(a, now, 30e6, 1e5, 0.01, 5e7, 5e5, 0.02, 3e8, 2e6 if a.startswith("0xgut") else 1e5, 0.05, 1e9 if a.startswith("0xgut") else 5e10, 5e6, 0.1, 1e10) for a in konten])
    con.commit()
    sc = compute_scores(con, "BTC", lambda a: "dir")
    print(f"Konto-Score Selbsttest: {len(sc)} Konten bewertet")
    for a, v in sorted(sc.items(), key=lambda x: -x[1]["score"])[:6]:
        print(f"  {a:<12} Score {v['score']:.2f} · Vorlauf α₄ {v['alpha_4h']*100:+.2f} % (t {v['t_4h']:+.1f}, n {v['n']}) · Edge {v['edge_roh']:.5f}")
    top = elite(sc, 3)
    assert all(a.startswith("0xgut") for a in top), top
    print("  Elite-3 sind die drei Konten mit echtem Vorlauf: ok")
    # Score-Test: Schnappschuss von vor 7 Tagen, dann out-of-sample
    # Score-Test: Schnappschuss von vor 14 Tagen (aus den 14 Tagen davor), dann out-of-sample.
    # Mit 16 Konten ist die Standardabweichung von rho etwa 0,26 -- der Test zeigt hier vor
    # allem, dass die Rechnung läuft; Aussagekraft braucht Hunderte Konten, wie auf dem Pi.
    st = sqlite3.connect(":memory:"); store_init(st)
    alt = compute_scores(con, "BTC", lambda a: "dir", days=14, bis=now - 14 * 86400)
    save_scores(st, "BTC", alt, ts=now - 14 * 86400)
    r = score_test(con, st, "BTC", tage=14)
    print(f"  Score-Test out-of-sample (14 T): n {r['n']} · ρ gesamt {r['rho']:+.2f} · Vorlauf {r['rho_vorlauf']:+.2f} · Edge {r['rho_edge']:+.2f} · Größe {r['rho_groesse']:+.2f} · SE {r['se']:.2f}")
    assert r["rho"] is not None and r["n"] >= 5
    print("  ok")
