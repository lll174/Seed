#!/usr/bin/env python3
"""
hl_fusion.py -- Stufe 1 des Konzepts KONZEPT_Fusion.md (04.10.2026, Version 2026-09-23.42): Kostenschwelle, Kalibrierung v3
und Fusionsprognose. Alles läuft im SCHATTEN: Die angezeigte P(aufwärts) bleibt v1 (bzw. v2, wenn deren Schalter gesetzt ist).

1. KOSTENSCHWELLE je Coin und Horizont h
   Ein Richtungsurteil mit Trefferquote p bringt im Mittel (2p − 1) · E|r_h| (r_h = Log-Rendite über h, Betrag unabhängig
   davon, ob das Urteil stimmt). Es lohnt sich erst, wenn das die Kosten K eines Hin- und Rückwegs deckt:
       p* = 1/2 + K / (2 · E|r_h|)
   E|r_h| wird gemessen (Mittel über die letzten 30 Tage, 15-min-Raster), nicht aus einer Normalverteilung angenommen.
   K Taker = 2 · (Taker-Gebühr + halber Spread, Median der letzten Stunde), K Maker = 2 · Maker-Gebühr; Gebührensätze wie im
   TradeLabor (XMR als HIP-3-Markt doppelt, angenommen).

2. KALIBRIERUNG v3 -- v2 über alle Coins geteilt, auf Familienwerten
       p = sig( a_c + c · Σ_f (β_f + δ_f,c) · x_f / s_c,f )
   x_f    Familienwert = Mittel der vorhandenen Treiber-Scores der Richtungsfamilie f (hl_familien; ohne „Stärke“, die die GRÖSSE
          einer Bewegung vorhersagt, ohne die Schatten-Familie „Pool-Konten“ und ohne den Live-Profi-Flow)
   s_c,f  Streuung des Familienwerts je Coin im Trainingsfenster (mind. 0,05) -- β wirkt je Standardabweichung
   β_f    gemeinsames Gewicht aller Coins; δ_f,c Abweichung eines Coins, L2 gegen null mit λ_δ = r · λ_β (r = ∞: ganz geteilt)
   a_c    Achsenabschnitt je Coin (eigene Drift), c Kalibrierfaktor aus den OOF-Vorhersagen (vorsichtigste 1-SE-Regel, wie v2)
   Daten: eine Prognose je h-Block und Coin (die früheste), 90 Tage aus forecast_slim/forecast_drivers, Toleranz-Labels (M7),
   Alters-Gewicht 14 Tage. λ_β, r per geblockter Kreuzvalidierung über die Zeit (alle Coins eines Zeitraums im selben Fold,
   Embargo h), 1-SE-Regel mit Vorrang für das Teilen (größtes r), dann das größte λ_β. Der Standardfehler des Kalibrierschritts
   zählt Zeitblöcke, nicht Coin-Fälle (Fälle verschiedener Coins im selben Block hängen zusammen).

3. FUSIONSPROGNOSE -- Expertenmischung
       p_Fusion(t) = Σ_m π_m(t) · p_m(t) / Σ_m π_m(t)   über die Experten m mit einer Vorhersage
   Experten: Basisrate (geglättete Aufwärtsquote der aufgelösten Blöcke, 14 Tage Halbwertszeit), v1, v2, v3, Analog-Suche
   (Anteil steigender Analoge, mit 50 Pseudo-Fällen zur eigenen Basisrate geschrumpft). Alle p werden auf [0,02; 0,98] geklemmt.
   Lernen nach jedem aufgelösten Block (Richtung y nach h Stunden; unter der Toleranz kein Urteil):
       π_m ← π_m · q_m(y) / q_Fusion(y)   für wache Experten (q = vorhergesagte Wahrscheinlichkeit des Eingetretenen),
       schlafende bleiben, danach Fixed Share  π ← (1 − α) · π + α / M,   α = min(0,05; h / (14 · 24)).
   Garantie (Log-Verlust, für jede Folge, auch für schlafende Experten über ihre wachen Runden):
       L_Fusion − L_m ≤ ln M + (T − 1) · ln(1 / (1 − α))          (α = 0: höchstens ln M = 1,61 bei M = 5)
   Jede Fusionszahl steht fest, bevor das Ergebnis bekannt ist (prequential); gespeichert in fusion_fall (eine Zeile je Coin,
   Horizont und Block). Beim ersten Lauf wird aus den gespeicherten Prognosen (60 Tage) nachgetragen -- ebenfalls
   prequential: Jeder nachgetragene Block sieht nur Ergebnisse, die zu seinem Zeitpunkt schon feststanden.

Selbsttest (Selbsttest-Schritt der Installation): python3 hl_fusion.py --nulltest
Stand je Coin (Debug):                             python3 hl_fusion.py --stand --db PFAD
"""
import json
import math
import os
import sqlite3
import sys
import time

import numpy as np

import hl_forecast as F
import hl_kalib as K2

VERSION = 1
HORIZONTE = (4, 24)

# ------------------------------------------------------------------------------------------------ Kostenschwelle
KOSTEN_TAGE = 30
KOSTEN_HORIZONTE = (1, 4, 12, 24)
KOSTEN_CACHE_S = 3600
KOSTEN_MIN_PUNKTE = 288                      # mindestens 3 Tage im 15-min-Raster, sonst keine Schwelle
_KOSTEN: dict = {}


def gebuehren(coin: str) -> tuple:
    """(Taker, Maker) je Seite -- dieselben Sätze wie im TradeLabor (XMR als HIP-3-Markt doppelt, angenommen)."""
    import hl_labor
    return hl_labor.gebuehr(coin, hl_labor.GEB_TAKER), hl_labor.gebuehr(coin, hl_labor.GEB_MAKER)


def mittlere_bewegung(con, coin: str, now: int | None = None, tage: int = KOSTEN_TAGE, horizonte: tuple = KOSTEN_HORIZONTE) -> dict:
    """E|ln(P(t+h) / P(t))| über die letzten `tage` Tage, t im 15-min-Raster (überlappende Fenster -- der Mittelwert bleibt
    unverzerrt). Kurs zur Minute t oder bis zu zwei Minuten davor (1-min-Kerzen)."""
    now = int(now or time.time())
    try:
        rows = con.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<=? AND (ts % 900) IN (0, 780, 840)",
                           (coin, now - tage * 86_400 - 900, now)).fetchall()
    except sqlite3.Error:
        return {}
    px = {}
    for ts, c in rows:
        if c and c > 0:
            px[int(ts) // 60] = float(c)

    def kurs(m):
        for k in (m, m - 1, m - 2):
            v = px.get(k)
            if v:
                return v
        return None
    start = (now - tage * 86_400) // 900 * 900 + 900
    out = {}
    for h in horizonte:
        s = 0.0; n = 0
        for t in range(start, now - h * 3600 + 1, 900):
            a = kurs(t // 60); b = kurs((t + h * 3600) // 60)
            if a and b:
                s += abs(math.log(b / a)); n += 1
        out[h] = {"er": (s / n) if n >= KOSTEN_MIN_PUNKTE else None, "n": n}
    return out


def halber_spread_bps(con, coin: str, now: int | None = None) -> float | None:
    """Halber Spread in bps: Median der Buch-Snapshots der letzten Stunde (book_summary)."""
    now = int(now or time.time())
    try:
        v = sorted(float(r[0]) for r in con.execute("SELECT spread_bps FROM book_summary WHERE ts>=? AND ts<=? AND coin=?",
                                                    (now - 3600, now, coin)) if r[0] is not None and r[0] >= 0)
    except sqlite3.Error:
        return None
    if len(v) < 10:
        return None
    return v[len(v) // 2] / 2


def schwelle(er: float | None, kosten: float | None) -> float | None:
    """Nötige Trefferquote p* = 1/2 + K / (2 · E|r|). Kann über 1 liegen: dann ist der Horizont mit diesen Kosten nicht zu schlagen."""
    if er is None or er <= 0 or kosten is None:
        return None
    return 0.5 + kosten / (2.0 * er)


def kostenschwelle(con, coin: str, now: int | None = None, cache: bool = True) -> dict | None:
    """Kostenschwelle je Horizont (flache Schlüssel, damit das Labor sie per json_extract lesen kann): er_h, p_taker_h, p_maker_h."""
    now = int(now or time.time())
    c = _KOSTEN.get(coin)
    if cache and c and 0 <= now - c[0] < KOSTEN_CACHE_S:
        return c[1]
    mb = mittlere_bewegung(con, coin, now)
    tk, mk = gebuehren(coin)
    hs = halber_spread_bps(con, coin, now)
    k_t = 2.0 * (tk + (hs or 0.0) / 1e4); k_m = 2.0 * mk
    out = {"ts": now, "tage": KOSTEN_TAGE, "taker": tk, "maker": mk, "halbspread_bps": (round(hs, 3) if hs is not None else None),
           "k_taker": round(k_t, 7), "k_maker": round(k_m, 7)}
    for h in KOSTEN_HORIZONTE:
        e = mb.get(h) or {}
        er = e.get("er")
        out[f"er_{h}"] = round(er, 7) if er is not None else None
        pt, pm = schwelle(er, k_t), schwelle(er, k_m)
        out[f"p_taker_{h}"] = round(pt, 5) if pt is not None else None
        out[f"p_maker_{h}"] = round(pm, 5) if pm is not None else None
    if cache:
        _KOSTEN[coin] = (now, out)
    return out


# ------------------------------------------------------------------------------------------------ v3
V3_TAGE = 90
V3_LAMBDAS = (0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
V3_R = (None, 64.0, 16.0, 4.0, 1.0)            # λ_δ = r · λ_β; None = ganz geteilt (keine Abweichung je Coin)
V3_FOLDS = 5
V3_KALIB_C = tuple(i / 10 for i in range(11))
V3_MIN_FAELLE = 60
V3_MIN_COIN = 15
V3_W_CLIP = 4.0
V3_A_STRAFE = 1e-4                              # winzige Strafe auf die Achsenabschnitte: endlich, auch wenn ein Coin nur steigt


def _v3_familien() -> dict:
    """Richtungsfamilien aus hl_familien: ohne „Stärke“ (sagt die Größe vorher, nicht die Richtung), ohne die Schatten-Familie
    „Pool-Konten“ (deren Treiber sind auch aus v1 und v2 ausgenommen) und ohne den Live-Profi-Flow (keine Treiber)."""
    import hl_familien as H
    return {f: list(d["treiber"]) for f, d in H.FAMILIEN.items()
            if d.get("art") == "richtung" and not d.get("live") and f != "Pool-Konten" and d.get("treiber")}


V3_FAMILIEN = _v3_familien()


def familienwerte(scores: dict) -> dict:
    """Je Familie das Mittel der vorhandenen Treiber-Scores (None, wenn keiner vorhanden ist)."""
    out = {}
    for f, namen in V3_FAMILIEN.items():
        v = [float(scores[n]) for n in namen if scores.get(n) is not None]
        out[f] = (sum(v) / len(v)) if v else None
    return out


def _kurs_bei(con, coin: str, t: int) -> float | None:
    """Schlusskurs der 1-min-Kerze zur Zeit t oder bis 120 s davor (wie v2, H4)."""
    try:
        r = con.execute("SELECT close FROM bars WHERE coin=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1", (coin, int(t), int(t) - 120)).fetchone()
    except sqlite3.Error:
        return None
    return float(r[0]) if r and r[0] else None


def _stuecke(liste: list, n: int = 400):
    for i in range(0, len(liste), n):
        yield liste[i:i + n]


def v3_faelle(con_main, st, h: int, now: int, tage: int = V3_TAGE, coins: list | None = None) -> dict:
    """Fälle aller Coins: je Coin und h-Block die früheste Prognose; Familienwerte aus forecast_drivers, Label aus den Kerzen."""
    block = h * 3600
    if coins is None:
        coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_slim WHERE ts>=? ORDER BY coin", (now - tage * 86_400,))]
    cb_ab = F.cb_seite_ab(con_main)
    fam = list(V3_FAMILIEN)
    X, P, y, sw, T, CI, behalten = [], [], [], [], [], [], []
    tol = ohne = 0
    n_coin = {}
    for coin in coins:
        erste = {}
        for ts, px in st.execute("SELECT ts, price FROM forecast_slim WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                                 (coin, now - tage * 86_400, now - block)):
            b = int(ts) // block
            if b not in erste:
                erste[b] = (int(ts), px)
        if not erste:
            continue
        ts_liste = [v[0] for v in erste.values()]
        drv: dict = {}
        for teil in _stuecke(ts_liste):
            for ts, name, sc in st.execute(f"SELECT ts, name, score FROM forecast_drivers WHERE coin=? AND ts IN ({','.join('?' * len(teil))})",
                                           (coin, *teil)):
                drv.setdefault(int(ts), {})[name] = sc
        zeilen = []
        for b in sorted(erste):
            ts, p0 = erste[b]
            real = _kurs_bei(con_main, coin, ts + block)
            if not real or not p0:
                ohne += 1; continue
            r = real / p0 - 1.0
            if abs(r) < F.TOLERANZ:
                tol += 1; continue
            sc = dict(drv.get(ts) or {})
            if cb_ab and ts < cb_ab:
                sc.pop(F.CB_TREIBER, None)                                        # U41: vor der Seiten-Umstellung vertauscht
            fw = familienwerte(sc)
            zeilen.append(([fw[f] if fw[f] is not None else 0.0 for f in fam], [1.0 if fw[f] is not None else 0.0 for f in fam],
                           1.0 if r > 0 else 0.0, 0.5 ** ((now - ts) / (F.HALF_LIFE_DAYS * 86_400)), ts))
        n_coin[coin] = len(zeilen)
        if len(zeilen) < V3_MIN_COIN:
            continue
        behalten.append(coin); k = len(behalten) - 1
        for x, pr, yy, w, ts in zeilen:
            X.append(x); P.append(pr); y.append(yy); sw.append(w); T.append(ts); CI.append(k)
    d = len(fam)
    return {"X": np.array(X, dtype=float).reshape(-1, d), "P": np.array(P, dtype=float).reshape(-1, d), "y": np.array(y, dtype=float),
            "sw": np.array(sw, dtype=float), "T": np.array(T, dtype=float), "ci": np.array(CI, dtype=int), "coins": behalten,
            "familien": fam, "n_coin": n_coin, "tol_ausgelassen": tol, "ohne_kurs": ohne, "h": h}


def _v3_skalen(X, P, ci, C) -> np.ndarray:
    """Streuung je Coin und Familie über die vorhandenen Werte (mind. 0,05; unter 10 Werten 1,0) -- wie v2 je Treiber."""
    S = np.ones((C, X.shape[1]))
    for c in range(C):
        m = ci == c
        for j in range(X.shape[1]):
            v = X[m & (P[:, j] > 0), j]
            S[c, j] = max(float(np.std(v)), 0.05) if v.size >= 10 else 1.0
    return S


def _v3_design(Xs, ci, C: int, mit_delta: bool) -> np.ndarray:
    n, d = Xs.shape
    A0 = np.zeros((n, C)); A0[np.arange(n), ci] = 1.0
    if not mit_delta:
        return np.hstack([A0, Xs])
    D = np.zeros((n, C * d))
    for c in range(C):
        m = ci == c
        D[m, c * d:(c + 1) * d] = Xs[m]
    return np.hstack([A0, Xs, D])


def _v3_strafe(C: int, d: int, lam_b: float, lam_d: float | None) -> np.ndarray:
    """Diagonale der Strafe (Gradient): Verlust = Σ W·logloss + λ_β·Σβ²/d + λ_δ·Σδ²/d (+ winzig auf a)."""
    pen = np.full(C + d + (C * d if lam_d is not None else 0), 0.0)
    pen[:C] = V3_A_STRAFE
    pen[C:C + d] = 2.0 * lam_b / d
    if lam_d is not None:
        pen[C + d:] = 2.0 * lam_d / d
    return pen


def _v3_fit(A, y, W, pen, theta0=None, iters: int = 60) -> np.ndarray:
    """Gewichtete L2-Logit (W summiert zu 1), Newton mit Schrittweiten-Halbierung."""
    dim = A.shape[1]
    th = np.zeros(dim) if theta0 is None else theta0.copy()

    def verlust(t):
        p = K2._sig(A @ t)
        return float(-np.sum(W * (y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12)))) + 0.5 * float(np.sum(pen * t * t))
    v = verlust(th)
    for _ in range(iters):
        p = K2._sig(A @ th)
        g = A.T @ (W * (p - y)) + pen * th
        H = (A * (W * p * (1 - p))[:, None]).T @ A + np.diag(pen) + 1e-9 * np.eye(dim)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        t = 1.0; neu = th - step; vn = verlust(neu)
        while vn > v + 1e-12 and t > 1e-4:
            t *= 0.5; neu = th - t * step; vn = verlust(neu)
        if vn > v + 1e-12:
            break
        fertig = float(np.max(np.abs(neu - th))) < 1e-7
        th, v = neu, vn
        if fertig:
            break
    return th


def _v3_folds(T, ci, C: int, h: int) -> list:
    """Zusammenhängende Zeitblöcke über ALLE Coins (ein Zeitraum = ein Fold), Embargo h um den Testblock."""
    n = len(T)
    order = np.argsort(T, kind="stable"); grenzen = np.linspace(0, n, V3_FOLDS + 1).astype(int)
    emb = h * 3600; out = []
    for k in range(V3_FOLDS):
        test = order[grenzen[k]:grenzen[k + 1]]
        if len(test) < 10:
            continue
        t_lo, t_hi = T[test].min(), T[test].max()
        train = np.ones(n, dtype=bool); train[test] = False
        train &= ~((T >= t_lo - emb) & (T <= t_hi + emb))
        tr = np.where(train)[0]
        if len(tr) < 30:
            continue
        n_tr = np.bincount(ci[tr], minlength=C)
        test = test[n_tr[ci[test]] >= 5]                                    # Coins ohne Training in diesem Fold: kein Urteil
        if len(test) >= 5:
            out.append((tr, test))
    return out


def _cluster_se(W, d, mw: float, blk) -> float:
    """Standardfehler des gewichteten Mittels Σ W·d, Abhängigkeit innerhalb eines Zeitblocks (alle Coins desselben Blocks)."""
    u = W * (d - mw); s: dict = {}
    for b, v in zip(blk.tolist(), u.tolist()):
        s[b] = s.get(b, 0.0) + v
    G = len(s)
    if G < 2:
        return 0.0
    return math.sqrt(G / (G - 1) * sum(v * v for v in s.values()))


def _v3_cv(Xs, ci, C: int, y, sw, T, h: int) -> dict:
    d = Xs.shape[1]
    folds = _v3_folds(T, ci, C, h)
    n = len(y)
    if not folds:
        return {"lam": V3_LAMBDAS[-1], "r": None, "tabelle": {}, "eta": None, "folds": 0}
    designs = {False: _v3_design(Xs, ci, C, False), True: _v3_design(Xs, ci, C, True)}
    erg: dict = {}
    for r in V3_R:
        mit = r is not None; A = designs[mit]
        for tr, te in folds:
            W = sw[tr] / max(sw[tr].sum(), 1e-12)
            th = None
            for lam in sorted(V3_LAMBDAS, reverse=True):                    # vom stärksten zum schwächsten: warm starten
                th = _v3_fit(A[tr], y[tr], W, _v3_strafe(C, d, lam, r * lam if mit else None), th)
                e = erg.setdefault((lam, r), {"eta": np.full(n, np.nan)})
                e["eta"][te] = A[te, C:] @ th[C:]                           # Treiberanteil ohne Achsenabschnitt, out-of-fold
    # Verglichen wird der TREIBERANTEIL: je Einstellung p = sig(a_c + η_OOF) mit dem Achsenabschnitt je Coin aus denselben OOF-Fällen
    # (genau so rechnet danach der Kalibrierschritt mit c = 1). Mit den Achsenabschnitten der Trainingsfolds lag der OOF-Verlust in der
    # Probe bei jeder Einstellung über ln 2: Die Drift eines Zeitraums passt nicht auf den nächsten, und dieses Rauschen überdeckte die
    # Kante. Dazu die 1-SE-Regel mit GEPAARTEM Standardfehler (Zeitblöcke als Klumpen) statt der Streuung der Fold-Mittel, die die
    # gemeinsamen Unterschiede zwischen den Folds mitzählt -- mit ihr wählte die Regel fast immer das stärkste λ.
    m = np.isfinite(next(iter(erg.values()))["eta"])
    W = sw[m] / max(sw[m].sum(), 1e-12); bb = (T[m] // (h * 3600)).astype(int); cm = ci[m]; ym = y[m]
    for e in erg.values():
        eta = e["eta"][m]; a = np.zeros(C)
        for k in range(C):
            mk = cm == k
            a[k] = K2._fit_a(eta[mk], ym[mk], sw[m][mk]) if mk.sum() else 0.0
        p = K2._sig(a[cm] + eta)
        e["verl"] = np.full(n, np.nan); e["verl"][m] = -(ym * np.log(p + 1e-12) + (1 - ym) * np.log(1 - p + 1e-12))
    loss = {k: float(np.sum(W * v["verl"][m])) for k, v in erg.items()}
    best = min(loss, key=loss.get)
    tab = {}
    for k, v in erg.items():
        diff = v["verl"][m] - erg[best]["verl"][m]; mw = float(np.sum(W * diff))
        tab[k] = {"loss": loss[k], "diff": mw, "se": _cluster_se(W, diff, mw, bb)}
    kand = [k for k in tab if tab[k]["diff"] <= tab[k]["se"]]
    wahl = max(kand, key=lambda k: (float("inf") if k[1] is None else k[1], k[0]))     # Teilen vor Abweichung, dann das größte λ
    return {"lam": wahl[0], "r": wahl[1], "eta": erg[wahl]["eta"], "folds": len(folds), "bester": {"lam": best[0], "r": best[1]},
            "tabelle": {f"{k[0]}|{'inf' if k[1] is None else k[1]}": {"loss": round(v["loss"], 5), "diff": round(v["diff"], 5), "se": round(v["se"], 5)}
                        for k, v in tab.items()}}


def _v3_kalibrierschritt(eta, ci, C: int, y, sw, blk) -> dict:
    """p = sig(a_c + c · η) auf den OOF-Vorhersagen; das KLEINSTE c innerhalb eines (blockweisen) Standardfehlers des besten.
    Ohne Beleg c = 0: dann nennt v3 je Coin die Basisrate."""
    def basis_a(m):
        pb = float(np.clip(np.average(y[m], weights=sw[m]), 0.02, 0.98)) if m.sum() else 0.5
        return math.log(pb / (1 - pb))
    m = np.isfinite(eta) if eta is not None else np.zeros(len(y), dtype=bool)
    if m.sum() < 30:
        return {"c": 0.0, "a": [basis_a(ci == k) for k in range(C)], "tabelle": {}, "n": int(m.sum()), "bestes_c": None}
    e, cc, yy, ww, bb = eta[m], ci[m], y[m], sw[m], blk[m]
    W = ww / ww.sum(); fall = {}; tab = {}
    for c in V3_KALIB_C:
        a = np.zeros(C)
        for k in range(C):
            mk = cc == k
            a[k] = K2._fit_a(c * e[mk], yy[mk], ww[mk]) if mk.sum() else basis_a(ci == k)
        p = K2._sig(a[cc] + c * e)
        verl = -(yy * np.log(p + 1e-12) + (1 - yy) * np.log(1 - p + 1e-12))
        fall[c] = (a, verl); tab[c] = round(float(np.sum(W * verl)), 6)
    best = min(tab, key=tab.get)
    wahl = best
    for c in V3_KALIB_C:                                                    # aufsteigend: das vorsichtigste zuerst
        diff = fall[c][1] - fall[best][1]
        mw = float(np.sum(W * diff))
        if mw <= _cluster_se(W, diff, mw, bb):
            wahl = c; break
    return {"c": wahl, "a": [float(x) for x in fall[wahl][0]], "tabelle": {str(c): v for c, v in tab.items()}, "n": int(m.sum()), "bestes_c": best,
            "p_oof": K2._sig(fall[wahl][0][cc] + wahl * e), "p_basis": K2._sig(fall[0.0][0][cc]), "maske": m}


def _kennzahlen(p, yv, w, p_ref=None) -> dict:
    if len(yv) == 0:
        return {"n": 0}
    br = float(np.average((p - yv) ** 2, weights=w))
    ruf = np.abs(p - 0.5) >= 0.02
    out = {"n": int(len(yv)), "logloss": round(K2._logloss(p, yv, w), 4), "brier": round(br, 4),
           "hit_rate": round(float(np.average(((p > 0.5) == (yv > 0.5))[ruf], weights=w[ruf])), 4) if ruf.sum() else None,
           "enthalten": int((~ruf).sum())}
    if p_ref is not None:
        brr = float(np.average((p_ref - yv) ** 2, weights=w))
        out["brier_basis"] = round(brr, 4)
        out["brier_skill"] = round(1 - br / brr, 4) if brr > 1e-9 else None
    return out


def v3_kalibrieren(con_main, h: int = 4, path: str | None = None, now: int | None = None, speichern: bool = True, coins: list | None = None) -> dict:
    path = path or F.STORE; now = int(now or time.time())
    st = F.store_connect(path)
    try:
        D = v3_faelle(con_main, st, h, now, coins=coins)
    finally:
        st.close()
    X, P, y, sw, T, ci, ks = D["X"], D["P"], D["y"], D["sw"], D["T"], D["ci"], D["coins"]
    C = len(ks); n = len(y); fam = D["familien"]; d = len(fam)
    basis = {"version": VERSION, "h": h, "ts": now, "n": n, "n_coin": D["n_coin"], "coins": ks, "familien": fam,
             "tol_ausgelassen": D["tol_ausgelassen"], "ohne_kurs": D["ohne_kurs"], "min_faelle": V3_MIN_FAELLE, "min_coin": V3_MIN_COIN}
    if n < V3_MIN_FAELLE or C == 0:
        aus = dict(basis, zu_wenig=True)
        if speichern:
            F.learned_save("*", f"kalib3_{h}", aus, path=path)
        return aus
    S = _v3_skalen(X, P, ci, C)
    Xs = X / S[ci]
    blk = (T // (h * 3600)).astype(int)
    cv = _v3_cv(Xs, ci, C, y, sw, T, h)
    mit = cv["r"] is not None
    A = _v3_design(Xs, ci, C, mit)
    th = _v3_fit(A, y, sw / sw.sum(), _v3_strafe(C, d, cv["lam"], cv["r"] * cv["lam"] if mit else None))
    th[C:] = np.clip(th[C:], -V3_W_CLIP, V3_W_CLIP)
    beta = th[C:C + d]
    delta = th[C + d:].reshape(C, d) if mit else np.zeros((C, d))
    kal = _v3_kalibrierschritt(cv["eta"], ci, C, y, sw, blk)
    cfak = float(kal["c"])
    eta_in = A[:, C:] @ th[C:]                                                  # Treiberanteil der Trainingsfälle, wie im Training gerechnet
    a_k = np.array(kal["a"], dtype=float)
    stich = [(ks[int(ci[i])], int(T[i]), float(K2._sig(a_k[ci[i]] + cfak * eta_in[i]))) for i in range(0, n, max(1, n // 25))]
    aus = dict(basis, zu_wenig=False, n_eff=int(len(set(blk.tolist()))), lam_b=cv["lam"], r=cv["r"], folds=cv["folds"],
               lam_tabelle=cv.get("tabelle"), bester=cv.get("bester"),
               beta={f: round(float(beta[j]), 5) for j, f in enumerate(fam)},
               delta={k: {f: round(float(delta[c, j]), 5) for j, f in enumerate(fam)} for c, k in enumerate(ks)} if mit else {},
               skalen={k: {f: round(float(S[c, j]), 5) for j, f in enumerate(fam)} for c, k in enumerate(ks)},
               kalib={"c": cfak, "a": {k: round(float(kal["a"][c]), 5) for c, k in enumerate(ks)}, "bestes_c": kal.get("bestes_c"),
                      "n": kal.get("n"), "tabelle": kal.get("tabelle")},
               # Wirkung in Log-Odds je Einheit Familienwert (Score-Skala -1..1) und Coin -- für die Anzeige
               gewicht={k: {f: round(cfak * float(beta[j] + delta[c, j]) / float(S[c, j]), 4) for j, f in enumerate(fam)} for c, k in enumerate(ks)},
               base_up={k: round(float(np.average(y[ci == c], weights=sw[ci == c])), 4) for c, k in enumerate(ks)},
               oof=None, oof_coin=None, zuverlaessigkeit=None)
    if kal.get("p_oof") is not None:
        m = kal["maske"]; po, pb = kal["p_oof"], kal["p_basis"]
        aus["oof"] = _kennzahlen(po, y[m], sw[m], pb)
        aus["oof_coin"] = {k: _kennzahlen(po[ci[m] == c], y[m][ci[m] == c], sw[m][ci[m] == c], pb[ci[m] == c]) for c, k in enumerate(ks)}
        aus["zuverlaessigkeit"] = K2.zuverlaessigkeit(po, y[m], sw[m])
    if speichern:
        F.learned_save("*", f"kalib3_{h}", aus, path=path)
    aus["_stichprobe"] = stich                                                  # nur für die Probe, nicht gespeichert
    return aus


def _learned(st, key: str, max_alter: int | None = None):
    """learned '*'/key über eine offene Verbindung (None: fehlt, zu alt, unlesbar)."""
    r = st.execute("SELECT value, updated FROM learned WHERE coin='*' AND key=?", (key,)).fetchone()
    if not r or not r[0] or (max_alter is not None and time.time() - int(r[1] or 0) > max_alter):
        return None
    try:
        return json.loads(r[0])
    except (ValueError, TypeError):
        return None


def v3_laden(h: int = 4, path: str | None = None) -> dict | None:
    try:
        st = F.store_connect(path or F.STORE)
        r = st.execute("SELECT value FROM learned WHERE coin='*' AND key=?", (f"kalib3_{h}",)).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


def p_up_v3(model: dict | None, coin: str, drivers: list) -> float | None:
    """Wahrscheinlichkeit aus dem gespeicherten v3-Modell für die aktuellen Treiber eines Coins (None: kein Modell, Coin fehlt)."""
    if not model or model.get("zu_wenig") or int(model.get("version") or 0) < VERSION or coin not in (model.get("coins") or []):
        return None
    k = model.get("kalib") or {}
    a = (k.get("a") or {}).get(coin)
    if a is None:
        return None
    c = float(k.get("c") or 0.0)
    fw = familienwerte({d.get("name"): d.get("score") for d in (drivers or []) if d.get("name")})
    eta = 0.0
    for f in model.get("familien") or []:
        v = fw.get(f)
        if v is None:
            continue
        s = float(((model.get("skalen") or {}).get(coin) or {}).get(f) or 1.0)
        b = float((model.get("beta") or {}).get(f) or 0.0) + float(((model.get("delta") or {}).get(coin) or {}).get(f) or 0.0)
        eta += b * v / s
    return float(K2._sig(np.array(float(a) + c * eta)))


def v3_kurz(m: dict | None, coin: str | None = None) -> dict | None:
    """Zusammenfassung für die Kachel (nur Anzeige, nicht im gespeicherten Payload): Zustand, Wahl, OOF, Gewichte DIESES Coins."""
    if not m:
        return None
    if m.get("zu_wenig"):
        return {k: m.get(k) for k in ("zu_wenig", "n", "min_faelle", "min_coin", "ts")}
    o = m.get("oof") or {}
    return {k: m.get(k) for k in ("n", "n_eff", "lam_b", "r", "ts")} | {
        "coins": len(m.get("coins") or []), "im_modell": coin in (m.get("coins") or []), "c": (m.get("kalib") or {}).get("c"),
        "oof": {k: o.get(k) for k in ("n", "hit_rate", "brier_skill")}, "gewicht": (m.get("gewicht") or {}).get(coin)}


def v3_takt(con_main, path: str | None = None, now: int | None = None) -> dict:
    """Stündlich aus dem Familien-Takt des Dashboards: beide Horizonte, Fehler sichtbar im Prognosespeicher."""
    out = {}
    for h in HORIZONTE:
        try:
            m = v3_kalibrieren(con_main, h, path=path, now=now)
            out[h] = {"n": m.get("n"), "zu_wenig": m.get("zu_wenig"), "c": (m.get("kalib") or {}).get("c")}
            F.learned_save("*", f"kalib3_{h}_fehler", None, path=path or F.STORE)
        except Exception as e:
            out[h] = {"fehler": f"{type(e).__name__}: {e}"}
            F.learned_save("*", f"kalib3_{h}_fehler", out[h]["fehler"], path=path or F.STORE)
    return out


# ------------------------------------------------------------------------------------------------ Fusion
EXPERTEN = ("Basisrate", "v1", "v2", "v3", "Analog")
P_MIN, P_MAX = 0.02, 0.98
FUSION_TAGE = 120
BASIS_PSEUDO = 1.0                 # je ein Pseudo-Fall auf und ab
ANALOG_PSEUDO = 50.0               # die Analog-Quote aus ~50 Analogen schwankt ±7 Punkte ohne Inhalt: halb zur Basisrate
ENTHALTUNG = 0.02
FUSION_SCHEMA = """CREATE TABLE IF NOT EXISTS fusion_fall (coin TEXT, h INTEGER, block INTEGER, ts INTEGER, px REAL, experten TEXT,
    p_fusion REAL, gewichte TEXT, quelle TEXT, r REAL, y INTEGER, aufgeloest INTEGER, PRIMARY KEY (coin, h, block));"""
_SCHEMA_OK: set = set()


def alpha(h: int) -> float:
    """Fixed-Share-Rate je Block: 1 / (typische Regimedauer von 14 Tagen in Blöcken), höchstens 0,05."""
    return min(0.05, h / (14.0 * 24.0))


def _klemmen(p) -> float:
    return min(P_MAX, max(P_MIN, float(p)))


class Mischung:
    """Bayes-Mischung über feste Experten mit schlafenden Experten (Specialists) und Fixed Share (Herbster/Warmuth 1998)."""

    def __init__(self, namen=EXPERTEN, alpha_: float = 0.0):
        self.namen = list(namen); self.alpha = float(alpha_)
        self.lw = {m: -math.log(len(self.namen)) for m in self.namen}
        self.L = {m: 0.0 for m in self.namen}                # Log-Verlust je Experte in seinen wachen Runden
        self.L_mix_wach = {m: 0.0 for m in self.namen}       # Log-Verlust der Mischung in denselben Runden
        self.L_mix = 0.0; self.T = 0

    def gewichte(self) -> dict:
        mx = max(self.lw.values()); e = {m: math.exp(v - mx) for m, v in self.lw.items()}; s = sum(e.values())
        return {m: e[m] / s for m in self.namen}

    def anteile(self, experten: dict) -> dict:
        """Gewicht der wachen Experten an DIESER Vorhersage (normiert auf die Wachen)."""
        w = self.gewichte(); wach = [m for m in self.namen if experten.get(m) is not None]
        s = sum(w[m] for m in wach)
        return {m: (w[m] / s if m in wach and s > 0 else None) for m in self.namen}

    def vorhersage(self, experten: dict) -> float | None:
        w = self.gewichte(); wach = [m for m in self.namen if experten.get(m) is not None]
        if not wach:
            return None
        s = sum(w[m] for m in wach)
        return sum(w[m] * _klemmen(experten[m]) for m in wach) / s

    def lernen(self, experten: dict, y: int) -> float | None:
        """Ein aufgelöster Block. Gibt den Log-Verlust der Mischung zurück (None: kein wacher Experte)."""
        p = self.vorhersage(experten)
        if p is None:
            return None
        q_mix = p if y == 1 else 1.0 - p
        l_mix = -math.log(q_mix)
        self.L_mix += l_mix; self.T += 1
        for m in self.namen:
            if experten.get(m) is None:
                continue                                      # schlafend: Gewicht bleibt (Specialists)
            pm = _klemmen(experten[m]); q = pm if y == 1 else 1.0 - pm
            self.lw[m] += math.log(q) - math.log(q_mix)       # Summe der wachen Gewichte bleibt gleich
            self.L[m] += -math.log(q); self.L_mix_wach[m] += l_mix
        w = self.gewichte(); M = len(self.namen)
        self.lw = {m: math.log((1.0 - self.alpha) * w[m] + self.alpha / M) for m in self.namen}
        return l_mix

    def grenze(self) -> float:
        """Obere Grenze für L_Mischung − L_m (wache Runden von m), für jeden Experten m."""
        M = len(self.namen)
        return math.log(M) + (max(self.T - 1, 0) * math.log(1.0 / (1.0 - self.alpha)) if self.alpha > 0 else 0.0)


def basis_p(zeilen: list, h: int, t: int) -> float:
    """Geglättete Aufwärtsquote der bis t aufgelösten Blöcke (Halbwertszeit 14 Tage, je ein Pseudo-Fall auf und ab)."""
    s = n = 0.0
    for z in zeilen:
        if z["y"] in (0, 1) and z["ts"] + h * 3600 <= t:
            w = 0.5 ** ((t - z["ts"]) / (F.HALF_LIFE_DAYS * 86_400))
            s += w * z["y"]; n += w
    return (s + BASIS_PSEUDO) / (n + 2 * BASIS_PSEUDO)


def analog_p(an: dict | None, h: int) -> float | None:
    """Analog-Suche als Experte: Anteil steigender Analoge, mit ANALOG_PSEUDO Pseudo-Fällen zur Basisrate derselben Historie."""
    if not isinstance(an, dict):
        return None
    ret = an.get("ret") or {}
    r = ret.get(h) if h in ret else ret.get(str(h))
    if not isinstance(r, dict) or r.get("p_up") is None:
        return None
    n = float(an.get("n") or 0)
    if n <= 0:
        return None
    base = r.get("p_up_base")
    base = 0.5 if base is None else float(base)
    return (float(r["p_up"]) * n + ANALOG_PSEUDO * base) / (n + ANALOG_PSEUDO)


def experten_aus(fc: dict, h: int, p_basis: float, p_v3: float | None) -> dict:
    """Experten-Wahrscheinlichkeiten aus einer Prognose (live) oder einem gespeicherten Payload (Nachtrag), geklemmt."""
    kal = fc.get("kalib") or "v1"
    if h == 4:
        v1 = fc.get("p_up_v1")
        if v1 is None and kal == "v1":
            v1 = fc.get("p_up")
        v2 = fc.get("p_up_v2")
    else:
        v1 = fc.get("p_up_24_v1")
        if v1 is None and kal == "v1":
            v1 = fc.get("p_up_24")
        v2 = fc.get("p_up_24_v2")
    if v2 is not None and float(((fc.get("kalib2") or {}).get("version")) or 0) < 2:
        v2 = None                                             # alte, übersicherte v2-Modelle (vor 23.26) nicht
    roh = {"Basisrate": p_basis, "v1": v1, "v2": v2, "v3": p_v3, "Analog": analog_p(fc.get("analog"), h)}
    return {m: (round(_klemmen(v), 5) if v is not None else None) for m, v in roh.items()}


def _schreiben(st, sql: str, werte: list) -> None:
    """Schreiben mit BEGIN IMMEDIATE (Lehre aus 23.41: eine Transaktion, die nach dem Lesen schreibt, nie mit einfachem BEGIN)."""
    if not werte:
        return
    if not st.in_transaction:
        st.execute("BEGIN IMMEDIATE")
    try:
        st.executemany(sql, werte)
        st.commit()
    except Exception:
        st.rollback()
        raise


def schema(st) -> None:
    st.executescript(FUSION_SCHEMA)


def zeilen_laden(st, coin: str, h: int, seit: int) -> list:
    out = []
    for block, ts, px, ex, pf, y, r, q in st.execute("SELECT block, ts, px, experten, p_fusion, y, r, quelle FROM fusion_fall "
                                                     "WHERE coin=? AND h=? AND ts>=? ORDER BY ts", (coin, h, seit)):
        try:
            e = json.loads(ex) if ex else {}
        except ValueError:
            e = {}
        out.append({"block": int(block), "ts": int(ts), "px": px, "experten": e, "p_fusion": pf, "y": y, "r": r, "quelle": q})
    return out


def mischung_aus(zeilen: list, h: int, bis_ts: int | None = None, alpha_: float | None = None) -> Mischung:
    """Die Mischung nach allen Blöcken, deren Ergebnis bis bis_ts feststand (in Zeitfolge)."""
    M = Mischung(alpha_=alpha(h) if alpha_ is None else alpha_)
    for z in sorted(zeilen, key=lambda z: z["ts"]):
        if z["y"] not in (0, 1):
            continue
        if bis_ts is not None and z["ts"] + h * 3600 > bis_ts:
            continue
        M.lernen(z["experten"], int(z["y"]))
    return M


def aufloesen(con_main, st, coin: str, h: int, now: int) -> int:
    """Offene Blöcke, deren Horizont abgelaufen ist: Rendite und Richtung eintragen (unter der Toleranz y = -1, ohne Kurs nach
    einem Tag y = -2)."""
    upd = []
    for block, ts, px in st.execute("SELECT block, ts, px FROM fusion_fall WHERE coin=? AND h=? AND y IS NULL AND ts<=?", (coin, h, now - h * 3600)).fetchall():
        real = _kurs_bei(con_main, coin, ts + h * 3600)
        if real and px:
            r = real / px - 1.0
            upd.append((r, -1 if abs(r) < F.TOLERANZ else (1 if r > 0 else 0), now, coin, h, block))
        elif now - (ts + h * 3600) > 86_400:
            upd.append((None, -2, now, coin, h, block))
    _schreiben(st, "UPDATE fusion_fall SET r=?, y=?, aufgeloest=? WHERE coin=? AND h=? AND block=?", upd)
    return len(upd)


def nachtragen(con_main, st, coin: str, h: int, now: int) -> int:
    """Einmal je Coin und Horizont, solange fusion_fall dort leer ist: die gespeicherten Prognosen (Payload, 60 Tage) als Blöcke
    nachtragen. Prequential: Jeder Block sieht nur Ergebnisse, die zu seinem Zeitpunkt feststanden; v3 gab es damals nicht."""
    if st.execute("SELECT 1 FROM fusion_fall WHERE coin=? AND h=? LIMIT 1", (coin, h)).fetchone():
        return 0
    block = h * 3600
    ts_liste = [int(r[0]) for r in st.execute("SELECT MIN(ts) FROM forecast WHERE coin=? AND ts>=? AND ts<? GROUP BY ts / ?",
                                              (coin, now - FUSION_TAGE * 86_400, now // block * block, block))]
    if not ts_liste:
        return 0
    rows = []
    for teil in _stuecke(sorted(ts_liste)):
        rows += st.execute(f"SELECT ts, price, p_up, p_up_24, payload FROM forecast WHERE coin=? AND ts IN ({','.join('?' * len(teil))})",
                           (coin, *teil)).fetchall()
    rows.sort(key=lambda r: r[0])
    zeilen = []
    for ts, price, p_up, p_up_24, payload in rows:
        try:
            fc_ = json.loads(payload) if payload else {}
        except ValueError:
            fc_ = {}
        if not isinstance(fc_, dict):
            fc_ = {}
        fc_.setdefault("p_up", p_up); fc_.setdefault("p_up_24", p_up_24)
        roh = experten_aus(fc_, h, 0.5, None)
        z = {"block": int(ts) // block, "ts": int(ts), "px": price, "roh": roh, "y": None, "r": None}
        if int(ts) + block <= now:
            real = _kurs_bei(con_main, coin, int(ts) + block)
            if real and price:
                z["r"] = real / price - 1.0
                z["y"] = -1 if abs(z["r"]) < F.TOLERANZ else (1 if z["r"] > 0 else 0)
            elif now - (int(ts) + block) > 86_400:
                z["y"] = -2
        zeilen.append(z)
    M = Mischung(alpha_=alpha(h)); j = 0; out = []
    for k, z in enumerate(zeilen):
        while j < k and zeilen[j]["ts"] + block <= z["ts"]:               # Ergebnisse, die zum Zeitpunkt dieses Blocks feststanden
            if zeilen[j]["y"] in (0, 1):
                M.lernen(zeilen[j]["experten"], int(zeilen[j]["y"]))
            j += 1
        z["experten"] = dict(z["roh"], Basisrate=round(_klemmen(basis_p(zeilen[:k], h, z["ts"])), 5))
        pf = M.vorhersage(z["experten"])
        out.append((coin, h, z["block"], z["ts"], z["px"], json.dumps(z["experten"]), round(pf, 5) if pf is not None else None,
                    json.dumps({m: round(v, 5) for m, v in M.gewichte().items()}), "nachtrag", z["r"], z["y"], now if z["y"] is not None else None))
    _schreiben(st, "INSERT OR IGNORE INTO fusion_fall VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", out)
    return len(out)


def bilanz(zeilen: list, h: int, mischung: Mischung | None = None) -> dict:
    """Bilanz der GESTELLTEN Fusionszahlen (prequential) auf den aufgelösten Blöcken, gegen die Experten auf denselben Blöcken."""
    fall = [z for z in zeilen if z["y"] in (0, 1) and z.get("p_fusion") is not None]
    out = {"n": len(fall), "nachtrag": sum(1 for z in fall if z.get("quelle") == "nachtrag")}
    if not fall:
        return out
    ll = lambda p, y: -math.log(_klemmen(p) if y == 1 else 1.0 - _klemmen(p))
    lf = [ll(z["p_fusion"], z["y"]) for z in fall]
    out["seit"] = fall[0]["ts"]
    out["ll_fusion"] = round(sum(lf) / len(lf), 5)
    br = [(z["p_fusion"] - z["y"]) ** 2 for z in fall]
    out["brier"] = round(sum(br) / len(br), 5)
    ruf = [z for z in fall if abs(z["p_fusion"] - 0.5) >= ENTHALTUNG]
    out["quote"] = round(sum(1 for z in ruf if (z["p_fusion"] > 0.5) == (z["y"] == 1)) / len(ruf), 4) if ruf else None
    out["enthalten"] = len(fall) - len(ruf)
    je = {}
    for m in EXPERTEN:
        sub = [(z, lf[i]) for i, z in enumerate(fall) if z["experten"].get(m) is not None]
        if not sub:
            continue
        lm = sum(ll(z["experten"][m], z["y"]) for z, _ in sub)
        lfm = sum(x for _, x in sub)
        je[m] = {"n": len(sub), "ll": round(lm / len(sub), 5), "fusion_minus": round(lfm - lm, 4)}
    out["experten"] = je
    b = je.get("Basisrate")
    if b:
        brb = [(z["experten"]["Basisrate"] - z["y"]) ** 2 for z in fall if z["experten"].get("Basisrate") is not None]
        out["brier_basis"] = round(sum(brb) / len(brb), 5)
        out["skill"] = round(1 - out["brier"] / out["brier_basis"], 4) if out["brier_basis"] > 1e-9 else None
        out["ll_basis"] = b["ll"]
        # Abstand zur Basisrate MIT Standardfehler (gepaart je Block; die Blöcke eines Coins und Horizonts überlappen nicht):
        # negativ = die Fusion verliert weniger als die Basisrate. Belegt erst, wenn der Abstand mehr als 2 Standardfehler beträgt
        d = [lf[i] - ll(z["experten"]["Basisrate"], z["y"]) for i, z in enumerate(fall) if z["experten"].get("Basisrate") is not None]
        if len(d) >= 2:
            md = sum(d) / len(d)
            out["d_basis"] = round(md, 5)
            out["se_basis"] = round(math.sqrt(sum((x - md) ** 2 for x in d) / (len(d) - 1) / len(d)), 5)
    if je:
        out["bester"] = min(je, key=lambda m: je[m]["ll"])
    if mischung is not None:
        out["grenze"] = round(mischung.grenze(), 3); out["T"] = mischung.T
    return out


def gepoolt(zeilen: list) -> dict:
    """Bilanz über alle Coins eines Horizonts (Auswertung U108): Abstand Fusion − Experte je Block, auf den Blöcken, in denen der
    Experte wach war. Standardfehler mit Zeitblöcken als Klumpen -- Blöcke verschiedener Coins zur selben Zeit hängen zusammen
    (gemeinsamer Markt); sie als unabhängig zu zählen, machte den Standardfehler zu klein. Zeilen brauchen „coin“ und „block“."""
    fall = [z for z in zeilen if z["y"] in (0, 1) and z.get("p_fusion") is not None]
    out = {"n": len(fall), "coins": len({z.get("coin") for z in fall}), "zeitbloecke": len({z["block"] for z in fall}), "experten": {}}
    ll = lambda p, y: -math.log(_klemmen(p) if y == 1 else 1.0 - _klemmen(p))
    for m in EXPERTEN:
        sub = [z for z in fall if z["experten"].get(m) is not None]
        if len(sub) < 2:
            continue
        d = np.array([ll(z["p_fusion"], z["y"]) - ll(z["experten"][m], z["y"]) for z in sub])
        md = float(d.mean())
        se = _cluster_se(np.full(len(d), 1.0 / len(d)), d, md, np.array([z["block"] for z in sub]))
        out["experten"][m] = {"n": len(sub), "d": round(md, 5), "se": round(se, 5) if se > 0 else None}
    return out


def ergaenzen(con_main, fc: dict, path: str | None = None, now: int | None = None) -> dict:
    """Hängt Kostenschwelle, v3 und Fusion an eine frisch berechnete Prognose (vor store_forecast). Gespeichert werden nur die
    schlanken Teile (fusion: p und Anteile, kosten, p_up_v3); fusion_info, kalib3 und kalib3_24 sind Anzeige (hl_forecast lässt sie
    im Payload weg -- sonst wüchse jede Prognosezeile um rund 4 kB). Fehler bleiben hier: Sie stehen in fc["fusion"]["fehler"] bzw.
    fc["kalib3"]["fehler"] und halten die Prognose nie an."""
    path = path or F.STORE; coin = fc["coin"]; now = int(now or fc.get("ts") or time.time())
    try:
        fc["kosten"] = kostenschwelle(con_main, coin, now)
    except Exception as e:
        fc["kosten"] = {"fehler": f"{type(e).__name__}: {e}"}
    fu: dict = {"version": VERSION}; info: dict = {}; p3: dict = {}
    try:
        st = F.store_connect(path)
    except sqlite3.Error as e:
        fc["fusion"] = {"version": VERSION, "fehler": [f"Prognosespeicher: {e}"]}
        return fc
    try:
        for h in HORIZONTE:
            try:
                m = _learned(st, f"kalib3_{h}")
                p3[h] = p_up_v3(m, coin, fc.get("drivers") or [])
                kurz = v3_kurz(m, coin)
                fehl = _learned(st, f"kalib3_{h}_fehler", 10 * 86_400)
                if fehl:
                    kurz = dict(kurz or {}, fehler=fehl)
                fc["kalib3" if h == 4 else "kalib3_24"] = kurz
            except Exception as e:
                p3[h] = None
                fc["kalib3" if h == 4 else "kalib3_24"] = {"fehler": f"{type(e).__name__}: {e}"}
        fc["p_up_v3"] = round(p3[4], 4) if p3.get(4) is not None else None
        fc["p_up_24_v3"] = round(p3[24], 4) if p3.get(24) is not None else None
        if path not in _SCHEMA_OK:
            schema(st); _SCHEMA_OK.add(path)
        for h in HORIZONTE:
            try:
                nachtragen(con_main, st, coin, h, now)
                aufloesen(con_main, st, coin, h, now)
                zeilen = zeilen_laden(st, coin, h, now - FUSION_TAGE * 86_400)
                M = mischung_aus(zeilen, h, bis_ts=now)
                ex = experten_aus(fc, h, round(_klemmen(basis_p(zeilen, h, now)), 5), p3.get(h))
                pf = M.vorhersage(ex); w = M.gewichte()
                if not st.execute("SELECT 1 FROM fusion_fall WHERE coin=? AND h=? AND block=?", (coin, h, now // (h * 3600))).fetchone():
                    _schreiben(st, "INSERT OR IGNORE INTO fusion_fall (coin, h, block, ts, px, experten, p_fusion, gewichte, quelle) VALUES (?,?,?,?,?,?,?,?,?)",
                               [(coin, h, now // (h * 3600), now, fc.get("price"), json.dumps(ex), round(pf, 5) if pf is not None else None,
                                 json.dumps({m: round(v, 5) for m, v in w.items()}), "live")])
                fu[f"p_{h}"] = round(pf, 4) if pf is not None else None
                fu[f"anteile_{h}"] = {m: round(v, 3) for m, v in M.anteile(ex).items() if v is not None}
                b = bilanz(zeilen, h, M)
                info[f"bilanz_{h}"] = {k: b.get(k) for k in ("n", "nachtrag", "ll_fusion", "ll_basis", "d_basis", "se_basis", "bester", "quote", "skill",
                                                             "grenze", "T")}
                info[f"experten_{h}"] = {m: v for m, v in ex.items() if v is not None}
                info[f"gewichte_{h}"] = {m: round(v, 4) for m, v in w.items()}
            except Exception as e:
                fu.setdefault("fehler", []).append(f"{h} h: {type(e).__name__}: {e}")
    finally:
        st.close()
    fc["fusion"] = fu
    fc["fusion_info"] = info
    return fc


# ------------------------------------------------------------------------------------------------ Stand (Debug)
def _pc(x, d: int = 1) -> str:
    return "—" if x is None else f"{x * 100:.{d}f} %".replace(".", ",")


def stand_text(con_main, path: str | None = None, now: int | None = None) -> str:
    path = path or F.STORE; now = int(now or time.time())
    z = ["Fusion, v3 und Kostenschwelle -- Stand je Coin (alles im Schatten; die angezeigte P(aufwärts) bleibt v1 bzw. v2)",
         "Fusion = Mischung der Experten Basisrate, v1, v2, v3, Analog (Bayes, schlafende Experten, Fixed Share); jede Zahl steht vor dem Ergebnis fest.", ""]
    for h in HORIZONTE:
        m = v3_laden(h, path)
        if not m:
            z.append(f"v3 {h} h: noch kein Modell (stündlich im Familien-Takt des Dashboards)"); continue
        if m.get("zu_wenig"):
            z.append(f"v3 {h} h: zu wenige Fälle ({m.get('n')} von mindestens {m.get('min_faelle')}; je Coin {json.dumps(m.get('n_coin'), ensure_ascii=False)})"); continue
        k = m.get("kalib") or {}
        o = m.get("oof") or {}
        z.append(f"v3 {h} h: n {m.get('n')} (Coins {', '.join(m.get('coins') or [])}) · n_eff {m.get('n_eff')} Zeitblöcke · λ_β {m.get('lam_b')} · "
                 f"Teilen {'ganz' if m.get('r') is None else 'r = ' + str(m.get('r'))} · c {k.get('c')} (bestes {k.get('bestes_c')}) · "
                 f"OOF: Quote {_pc(o.get('hit_rate'))}, Brier-Skill {o.get('brier_skill')} (n {o.get('n')})")
        g = m.get("gewicht") or {}
        for coin in m.get("coins") or []:
            w = sorted((g.get(coin) or {}).items(), key=lambda x: -abs(x[1]))
            z.append(f"   {coin}: Basis {_pc((m.get('base_up') or {}).get(coin), 0)} · a {((k.get('a') or {}).get(coin))} · Log-Odds je Familienwert 1,0: "
                     + " · ".join(f"{f} {v:+.2f}" for f, v in w[:7]))
    z.append("")
    st = F.store_connect(path)
    alle: dict = {h: [] for h in HORIZONTE}                                     # für die Bilanz über alle Coins (U108)
    try:
        schema(st)
        coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM fusion_fall ORDER BY coin")]
        for coin in coins:
            ks = kostenschwelle(con_main, coin, now, cache=False) if con_main is not None else None
            if ks:
                z.append(f"{coin} · Kostenschwelle (E|r| aus {KOSTEN_TAGE} Tagen; Taker {ks['taker'] * 100:.3f} %, Maker {ks['maker'] * 100:.3f} % je Seite, "
                         f"halber Spread {ks.get('halbspread_bps') if ks.get('halbspread_bps') is not None else '—'} bps):")
                z.append("   " + " · ".join(f"{h} h: E|r| {_pc(ks.get(f'er_{h}'), 2)} → Taker {_pc(ks.get(f'p_taker_{h}'))} / Maker {_pc(ks.get(f'p_maker_{h}'))}"
                                            for h in KOSTEN_HORIZONTE))
            for h in HORIZONTE:
                zeilen = zeilen_laden(st, coin, h, now - FUSION_TAGE * 86_400)
                alle[h] += [dict(x, coin=coin) for x in zeilen]
                M = mischung_aus(zeilen, h, bis_ts=now)
                b = bilanz(zeilen, h, M)
                letzte = zeilen[-1] if zeilen else None
                z.append(f"   Fusion {h} h: {b.get('n', 0)} bewertete Blöcke ({b.get('nachtrag', 0)} nachgetragen) · offen "
                         f"{sum(1 for x in zeilen if x['y'] is None)} · Gewichte " + " · ".join(f"{m_} {_pc(v, 0)}" for m_, v in M.gewichte().items()))
                if letzte:
                    z.append(f"      zuletzt {time.strftime('%d.%m. %H:%M', time.localtime(letzte['ts']))}: Fusion {_pc(letzte.get('p_fusion'))} aus "
                             + " · ".join(f"{m_} {_pc(v)}" for m_, v in (letzte.get('experten') or {}).items() if v is not None))
                if b.get("n"):
                    je = b.get("experten") or {}
                    z.append(f"      Log-Verlust je Block: Fusion {b['ll_fusion']:.4f} · " + " · ".join(f"{m_} {v['ll']:.4f} (n {v['n']})" for m_, v in je.items())
                             + f" · bester {b.get('bester')}")
                    if b.get("se_basis") is not None:
                        z.append(f"      Fusion minus Basisrate je Block {b['d_basis']:+.4f} ± {b['se_basis']:.4f} (1 Standardfehler; belegt erst unter "
                                 f"−2 SE = {-2 * b['se_basis']:+.4f})")
                    z.append(f"      Fusion minus Experte (Summe, Nats, auf dessen Blöcken): " + " · ".join(f"{m_} {v['fusion_minus']:+.2f}" for m_, v in je.items())
                             + f" · Grenze der Nachrechnung ≤ {b.get('grenze')} (ln 5 + Fixed-Share-Zuschlag über {b.get('T')} Blöcke)")
                    z.append(f"      Quote {_pc(b.get('quote'))} ({b.get('enthalten')} Enthaltungen unter 2 Punkten) · Brier {b.get('brier')} gegen Basisrate "
                             f"{b.get('brier_basis')} → Skill {b.get('skill')}")
                    # Auswertung U108: nur die live gestellten Blöcke (mit v3); die nachgetragenen stammen aus älteren Prognoseständen ohne v3
                    bl = bilanz([x for x in zeilen if x.get("quelle") == "live"], h)
                    if bl.get("n"):
                        z.append(f"      nur live gestellt (seit 23.42, mit v3): {bl['n']} Blöcke · Log-Verlust Fusion {bl['ll_fusion']:.4f} gegen Basisrate "
                                 f"{bl.get('ll_basis')} · Abstand " + (f"{bl['d_basis']:+.4f} ± {bl['se_basis']:.4f}" if bl.get("se_basis") is not None else "—")
                                 + f" · bester {bl.get('bester')}")
                    else:
                        z.append("      nur live gestellt (seit 23.42, mit v3): noch keine bewerteten Blöcke")
            z.append("")
    finally:
        st.close()
    z.append("Alle Coins (Auswertung U108): Fusion minus Experte, Log-Verlust je Block ± 1 Standardfehler mit Zeitblöcken als Klumpen; "
             "negativ = Fusion besser, belegt erst jenseits von 2 Standardfehlern")
    for h in HORIZONTE:
        for titel, auswahl in (("alle Blöcke", alle[h]), ("nur live gestellt", [x for x in alle[h] if x.get("quelle") == "live"])):
            g = gepoolt(auswahl)
            if not g["experten"]:
                z.append(f"   {h} h, {titel}: noch keine bewerteten Blöcke"); continue
            z.append(f"   {h} h, {titel}: {g['n']} Blöcke aus {g['coins']} Coins in {g['zeitbloecke']} Zeitblöcken · " + " · ".join(
                f"{m_} {v['d']:+.4f} ± {v['se']:.4f}{' ✓' if v['d'] < -2 * v['se'] else ' ✗' if v['d'] > 2 * v['se'] else ''} (n {v['n']})" if v["se"] is not None
                else f"{m_} {v['d']:+.4f} (n {v['n']})" for m_, v in g["experten"].items()))
    z.append("   ✓ = Fusion belegt besser als dieser Experte, ✗ = belegt schlechter, ohne Zeichen = nicht belegt")
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
PROBE_NOW = 1_790_006_400
PROBE_SEEDS = (1, 2, 3, 4, 5)
_PROBE_TREIBER = {"Großkonten-Fluss": "Wal-Flow 30 min", "Trend lang": "MA 200 Tage", "Momentum kurz": "60-min-Trend", "Orderfluss": "Taker-Flow",
                  "Funding": "Funding", "ETF": "ETF-Flows", "Analog": "Analog-Suche"}


def _probe_daten(tmp: str, seed: int, tage: int = 30, kante: float = 0.5, coins=("A1", "A2", "A3", "A4", "A5", "A6"), signal: str = "Taker-Flow",
                 nur_coin: str | None = None, gleichlauf: bool = False, korrelation: float = 0.5, mit_payload: bool = False) -> tuple:
    """Synthetischer Markt: korrelierte Kurse (gemeinsamer Faktor), alle 15 min eine Prognose je Coin mit einem Treiber je Familie.
    Der Signal-Treiber kennt die Richtung der nächsten 4 h mit Wahrscheinlichkeit `kante` (je 4-h-Block gezogen); bei nur_coin nur
    in diesem Coin. gleichlauf: alle Treiber folgen einem gemeinsamen, langsamen Faktor ohne Signal."""
    import random as _r
    rng = _r.Random(seed); now = PROBE_NOW // 900 * 900; start = now - tage * 86_400
    con = sqlite3.connect(os.path.join(tmp, f"m{seed}.db"))
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin))")
    # Kurse im 15-min-Raster (mehr brauchen Label und Nachtrag nicht): Schwankung 0,06 % je Minute, also 0,06 % · √15 je Schritt
    kurs = {c: {} for c in coins}; px = {c: 100.0 for c in coins}; rows = []
    t = start - 6 * 3600; s15 = 0.0006 * math.sqrt(15)
    while t <= now + 25 * 3600:
        g = rng.gauss(0, 1)
        for c in coins:
            e = korrelation ** 0.5 * g + (1 - korrelation) ** 0.5 * rng.gauss(0, 1)
            px[c] *= math.exp(s15 * e); kurs[c][t] = px[c]; rows.append((t, c, px[c], px[c], px[c], px[c], 1, 1))
        t += 900
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); con.commit()
    sp = os.path.join(tmp, f"f{seed}.db"); st = F.store_connect(sp)
    slim, drv, fc = [], [], []; fak = 0.0
    for ts in range(start, now - 4 * 3600 + 1, 900):
        fak = max(-0.8, min(0.8, fak + rng.gauss(0, 0.05)))
        for i_c, c in enumerate(coins):
            p0 = kurs[c][ts]; up = kurs[c][ts + 4 * 3600] > p0
            werte = {}
            for f, n in _PROBE_TREIBER.items():
                werte[n] = max(-1.0, min(1.0, fak + rng.gauss(0, 0.1))) if gleichlauf else rng.uniform(-0.6, 0.6)
            if not gleichlauf and (nur_coin is None or nur_coin == c):
                # je Coin und 4-h-Block EINE Ziehung (deterministisch, ohne hash(): der ist für Texte je Prozess zufällig)
                richtig = _r.Random(seed * 1_000_003 + i_c * 7_919 + ts // 14_400).random() < kante
                werte[signal] = 0.6 * ((1 if up else -1) if richtig else (-1 if up else 1))
            slim.append((ts, c, p0, 0.0, p0, p0, p0, p0, 0.5, 0.5))
            drv += [(ts, c, n, v) for n, v in werte.items()]
            if mit_payload:
                fc.append((ts, c, p0, 0.0, p0, p0, json.dumps({"drivers": [{"name": n, "score": v} for n, v in werte.items()]})))
    st.executemany("INSERT OR REPLACE INTO forecast_slim VALUES (?,?,?,?,?,?,?,?,?,?)", slim)
    st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
    if fc:
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)", fc)
    st.commit(); st.close()
    return con, sp, now


def _dlogit(m, coin, wert, signal="Taker-Flow"):
    lo = lambda p: math.log(p / (1 - p))
    p1 = p_up_v3(m, coin, [{"name": signal, "score": wert}]); p0 = p_up_v3(m, coin, [{"name": signal, "score": 0.0}])
    if p1 is None or p0 is None:
        return None, p1, p0
    return lo(p1) - lo(p0), p1, p0


def v3_probe(verbose: bool = True) -> tuple:
    """Tor für v3 (wie v2): Positivkontrolle Kante 0,65 in allen Coins → Log-Odds-Beitrag bei Familienwert +0,6 zwischen 0,20 und 1,00
    (wahr 0,62); Rauschen → p bewegt sich um < 5 Punkte, Brier-Skill ≤ 0,02; Gleichlauf ohne Signal → ≤ 7 Punkte. Dazu: Teilen
    über Coins findet eine gemeinsame Kante (0,62, 30 Tage) im Mittel mindestens doppelt so stark wie v2 je Coin allein (Probe mit 20
    Szenarien bei 0,60: dreimal so stark); eine Kante nur in einem Coin nutzt die Abweichung je Coin und bleibt dort mindestens doppelt
    so groß wie im Mittel der übrigen."""
    import tempfile
    pruef = []
    tmp = tempfile.mkdtemp(prefix="hl_fusion_v3_")
    try:
        dl65, d50, bs50, gl, pool3, pool2, einzel, wahl50, abw_tv = [], [], [], [], [], [], [], [], []
        for s_ in PROBE_SEEDS:
            con, sp, now = _probe_daten(tmp, s_, kante=0.65)
            m = v3_kalibrieren(con, 4, path=sp, now=now, speichern=False); con.close()
            dl65.append(sum((_dlogit(m, c, 0.6)[0] or 0.0) for c in m.get("coins") or []) / max(len(m.get("coins") or []), 1))
            st = F.store_connect(sp)                                           # Training und Vorhersage rechnen dieselbe Zahl
            for coin, ts, p_train in m.get("_stichprobe") or []:
                drv = [{"name": n_, "score": v_} for n_, v_ in st.execute("SELECT name, score FROM forecast_drivers WHERE coin=? AND ts=?", (coin, ts))]
                abw_tv.append(abs((p_up_v3(m, coin, drv) or -1.0) - p_train))
            st.close()
            con, sp, now = _probe_daten(tmp, 100 + s_, kante=0.5)
            m = v3_kalibrieren(con, 4, path=sp, now=now, speichern=False); con.close()
            bew = [_dlogit(m, c, 0.6) for c in m.get("coins") or []]
            d50.append(max(abs((p1 or 0) - (p0 or 0)) for _, p1, p0 in bew) if bew else 1.0)
            bs50.append((m.get("oof") or {}).get("brier_skill") or 0.0)
            wahl50.append((m.get("lam_b"), m.get("r"), (m.get("kalib") or {}).get("c")))
            con, sp, now = _probe_daten(tmp, 200 + s_, gleichlauf=True)
            m = v3_kalibrieren(con, 4, path=sp, now=now, speichern=False); con.close()
            alle = [{"name": n, "score": 0.6} for n in _PROBE_TREIBER.values()]; null = [{"name": n, "score": 0.0} for n in _PROBE_TREIBER.values()]
            gl.append(max(abs((p_up_v3(m, c, alle) or 0) - (p_up_v3(m, c, null) or 0)) for c in m.get("coins") or ["-"]) if m.get("coins") else 1.0)
            con, sp, now = _probe_daten(tmp, 300 + s_, kante=0.62, tage=30, mit_payload=True)
            m = v3_kalibrieren(con, 4, path=sp, now=now, speichern=False)
            pool3.append(sum((_dlogit(m, c, 0.6)[0] or 0.0) for c in m.get("coins") or []) / max(len(m.get("coins") or []), 1))
            d2 = []
            for c in m.get("coins") or []:                                     # dieselben Daten durch v2, je Coin allein
                m2 = K2.kalibrieren(con, c, 4, path=sp, now=now, speichern=False)
                p1 = K2.p_up(m2, [{"name": "Taker-Flow", "score": 0.6}]); p0 = K2.p_up(m2, [{"name": "Taker-Flow", "score": 0.0}])
                d2.append(math.log(p1 / (1 - p1)) - math.log(p0 / (1 - p0)) if p1 is not None and p0 is not None else 0.0)
            pool2.append(sum(d2) / max(len(d2), 1)); con.close()
            con, sp, now = _probe_daten(tmp, 400 + s_, kante=0.80, nur_coin="A1")
            m = v3_kalibrieren(con, 4, path=sp, now=now, speichern=False); con.close()
            d_a1 = _dlogit(m, "A1", 0.6)[0] or 0.0
            d_rest = [(_dlogit(m, c, 0.6)[0] or 0.0) for c in (m.get("coins") or []) if c != "A1"]
            einzel.append((d_a1, sum(d_rest) / len(d_rest) if d_rest else 0.0, m.get("r")))
        con, sp, now = _probe_daten(tmp, 777, tage=10, coins=("A1",))
        st = F.store_connect(sp)
        ts_alle = [r[0] for r in st.execute("SELECT DISTINCT ts FROM forecast_drivers ORDER BY ts")]
        t_u = ts_alle[len(ts_alle) // 2]
        st.execute("DELETE FROM forecast_drivers WHERE name IN ('Taker-Flow', 'Spot-Taker-Flow', 'Orderbuch', 'Spot-Orderbuch')")
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", [(t, "A1", F.CB_TREIBER, 0.9) for t in ts_alle]); st.commit()
        con.execute("CREATE TABLE cb_meta (k TEXT PRIMARY KEY, v TEXT)")
        con.execute("INSERT INTO cb_meta VALUES ('seite_umstellung', ?)", (json.dumps({"status": "gefunden", "ts": t_u}),)); con.commit()
        D = v3_faelle(con, st, 4, now); st.close(); con.close()
        j = D["familien"].index("Orderfluss")
        vor = [D["P"][i, j] for i in range(len(D["y"])) if D["T"][i] < t_u]; nach = [D["P"][i, j] for i in range(len(D["y"])) if D["T"][i] >= t_u]
        pruef.append(("v3 U41: Spot-Taker-Flow erst ab der Seiten-Umstellung", vor and nach and not any(vor) and all(nach),
                      f"Familie Orderfluss vorhanden: vor der Umstellung {int(sum(vor))} von {len(vor)} Fällen, danach {int(sum(nach))} von {len(nach)}"))
        mittel = lambda x: sum(x) / len(x)
        pruef.append(("v3 Tor: Kante 0,65 → Log-Odds-Beitrag 0,20–1,00 (wahr +0,62)", 0.20 <= mittel(dl65) <= 1.00,
                      f"Mittel {mittel(dl65):+.2f}, je Szenario " + " ".join(f"{x:+.2f}" for x in dl65)))
        pruef.append(("v3 Rauschen: p bewegt sich < 5 Punkte, Brier-Skill ≤ 0,02", mittel(d50) < 0.05 and mittel(bs50) <= 0.02,
                      f"größte Bewegung im Mittel {mittel(d50) * 100:.1f} Punkte, Brier-Skill {mittel(bs50):+.3f}"))
        pruef.append(("v3 Rauschen: vorsichtige Wahl (stärkstes λ, ganz geteilt, c = 0)",
                      sum(1 for l_, r_, _ in wahl50 if l_ == max(V3_LAMBDAS) and r_ is None) >= 4 and sum(1 for *_, c_ in wahl50 if c_ == 0.0) >= 3,
                      " · ".join(f"λ {l_} {'ganz' if r_ is None else 'r ' + str(r_)} c {c_}" for l_, r_, c_ in wahl50)))
        pruef.append(("v3 Training und Vorhersage rechnen dieselbe Zahl", abw_tv and max(abw_tv) < 1e-4,
                      f"{len(abw_tv)} Trainingsfälle über p_up_v3 aus forecast_drivers nachgerechnet, größte Abweichung {max(abw_tv or [1.0]):.1e} "
                      "(gespeicherte Koeffizienten auf 5 Stellen gerundet)"))
        pruef.append(("v3 Gleichlauf ohne Signal: ≤ 7 Punkte", max(gl) <= 0.07, "je Szenario " + " ".join(f"{x * 100:.1f}" for x in gl) + " Punkte"))
        pruef.append(("v3 Teilen: Kante 0,62 in 30 Tagen, mind. doppelt so stark wie v2", mittel(pool3) > 0.15 and mittel(pool3) >= 2 * mittel(pool2),
                      f"Log-Odds-Beitrag (wahr +0,49) im Mittel v3 {mittel(pool3):+.2f} gegen v2 je Coin allein {mittel(pool2):+.2f} · v3 "
                      + " ".join(f"{x:+.2f}" for x in pool3) + " · v2 " + " ".join(f"{x:+.2f}" for x in pool2)))
        pruef.append(("v3 Kante nur in einem Coin: Abweichung je Coin genutzt", sum(1 for _, _, r in einzel if r is not None) >= 4
                      and mittel([a for a, _, _ in einzel]) >= 2 * mittel([b for _, b, _ in einzel]),
                      " · ".join(f"A1 {a:+.2f} gegen übrige {b:+.2f} (r {'ganz' if r is None else r})" for a, b, r in einzel)))
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<58} {txt}")
    return all(p[1] for p in pruef), pruef


def fusion_probe(verbose: bool = True) -> tuple:
    """Mathematik der Mischung: Grenze ln M (+ Fixed-Share-Zuschlag) auf beliebigen Folgen, auch mit schlafenden Experten;
    Rauschen → Basisrate; ein guter Experte setzt sich durch; Regimewechsel mit Fixed Share schneller; kein Blick in die Zukunft;
    Toleranzblöcke ändern nichts."""
    import random as _r
    pruef = []
    # 1. Grenze auf zufälligen und feindlichen Folgen (α = 0: ln M; α > 0: ln M + (T-1)·ln(1/(1-α))), mit Schläfern
    verletzt = 0; groesst = -1e9
    for seed in range(30):
        rng = _r.Random(seed)
        for a_ in (0.0, 0.012, 0.05):
            M = Mischung(alpha_=a_)
            for t in range(400):
                ex = {m: (rng.choice([0.02, 0.98, rng.random()]) if rng.random() > 0.2 else None) for m in EXPERTEN}
                ex["Basisrate"] = rng.random()                                  # einer ist immer wach
                y = 1 if rng.random() < 0.5 else 0
                if seed % 3 == 0:                                               # feindlich: das Gegenteil der Mischung
                    p = M.vorhersage(ex); y = 0 if p >= 0.5 else 1
                M.lernen(ex, y)
            for m in EXPERTEN:
                if M.L[m] or M.L_mix_wach[m]:
                    r_ = M.L_mix_wach[m] - M.L[m]
                    groesst = max(groesst, r_ - M.grenze())
                    if r_ > M.grenze() + 1e-9:
                        verletzt += 1
    pruef.append(("Fusion: Grenze L_Fusion − L_m ≤ ln M (+ Fixed-Share-Zuschlag)", verletzt == 0,
                  f"90 Folgen × 5 Experten, auch feindliche und mit Schläfern: {verletzt} Verletzungen, größter Abstand zur Grenze {groesst:+.3f}"))
    # 2. Rauschen: Experten ohne Wissen, Ergebnis mit Drift 55 % → die Fusion bleibt nahe der Basisrate
    rng = _r.Random(7); M = Mischung(alpha_=alpha(4)); zeilen = []; ll_f = ll_b = 0.0; sicher_f = []; sicher_b = []
    for t in range(600):
        y = 1 if rng.random() < 0.55 else 0
        pb = basis_p(zeilen, 4, t * 14_400)
        ex = {"Basisrate": pb, "v1": 0.5 + rng.uniform(-0.1, 0.1), "v2": 0.5 + rng.uniform(-0.15, 0.15), "v3": None, "Analog": 0.5 + rng.uniform(-0.08, 0.08)}
        p = M.vorhersage(ex)
        ll_f += -math.log(p if y else 1 - p); ll_b += -math.log(pb if y else 1 - pb); sicher_f.append(abs(p - 0.5)); sicher_b.append(abs(pb - 0.5))
        M.lernen(ex, y); zeilen.append({"ts": t * 14_400, "y": y})
    pruef.append(("Fusion: Rauschen → wie die Basisrate, keine Scheinsicherheit", ll_f - ll_b <= M.grenze() and sum(sicher_f) / len(sicher_f) <= sum(sicher_b) / len(sicher_b) + 0.01,
                  f"Fusion minus Basisrate {ll_f - ll_b:+.2f} Nats über 600 Blöcke (Grenze {M.grenze():.2f}) · mittlerer Abstand von 50 %: Fusion "
                  f"{sum(sicher_f) / len(sicher_f) * 100:.1f} gegen Basisrate {sum(sicher_b) / len(sicher_b) * 100:.1f} Punkte"))
    # 3. Ein guter Experte (kennt die wahre Wahrscheinlichkeit) setzt sich durch
    rng = _r.Random(11); M = Mischung(alpha_=alpha(4))
    for t in range(500):
        q = 0.5 + 0.25 * math.sin(t / 7.0)
        y = 1 if rng.random() < q else 0
        M.lernen({"Basisrate": 0.5, "v1": 0.5 + rng.uniform(-0.1, 0.1), "v2": q, "v3": 0.5, "Analog": 0.5}, y)
    w = M.gewichte()
    pruef.append(("Fusion: guter Experte setzt sich durch", w["v2"] >= 0.8, f"Gewicht des guten Experten {w['v2'] * 100:.0f} %"))
    # 4. Regimewechsel: A gut, dann B gut -- Fixed Share holt schneller auf als die reine Bayes-Mischung
    rng = _r.Random(5); fs = Mischung(alpha_=alpha(4)); by = Mischung(alpha_=0.0); l_fs = l_by = 0.0
    folge = []
    for t in range(800):
        q = 0.5 + 0.3 * math.sin(t / 5.0)
        folge.append((q, 1 if rng.random() < q else 0, rng.uniform(-0.2, 0.2)))
    for t, (q, y, rausch) in enumerate(folge):
        ex = {"Basisrate": 0.5, "v1": q if t < 400 else 0.5 + rausch, "v2": 0.5 + rausch if t < 400 else q, "v3": None, "Analog": None}
        if t >= 400:
            l_fs += -math.log((fs.vorhersage(ex) if y else 1 - fs.vorhersage(ex))); l_by += -math.log((by.vorhersage(ex) if y else 1 - by.vorhersage(ex)))
        fs.lernen(ex, y); by.lernen(ex, y)
    pruef.append(("Fusion: Regimewechsel -- Fixed Share holt schneller auf", l_fs < l_by - 5.0 and abs(alpha(4) - 4 / 336) < 1e-12 and alpha(24) == 0.05,
                  f"Log-Verlust nach dem Wechsel (400 Blöcke): Fixed Share (α {alpha(4):.4f} wie bei 4 h) {l_fs:.1f} gegen reine Bayes-Mischung {l_by:.1f}"))
    # 5. Schläfer: ein Experte, der schläft, verändert die Wachen nicht und behält sein Gewicht
    M1 = Mischung(alpha_=0.0); M2 = Mischung(namen=("Basisrate", "v1"), alpha_=0.0); rng = _r.Random(3)
    for t in range(200):
        ex = {"Basisrate": rng.random(), "v1": rng.random(), "v2": None, "v3": None, "Analog": None}; y = rng.randint(0, 1)
        M1.lernen(ex, y); M2.lernen(ex, y)
    w1, w2 = M1.gewichte(), M2.gewichte()
    gleich = abs(w1["Basisrate"] / (w1["Basisrate"] + w1["v1"]) - w2["Basisrate"]) < 1e-9 and abs(w1["v2"] - 0.2) < 1e-9
    pruef.append(("Fusion: schlafende Experten stören die Wachen nicht", gleich,
                  f"Anteil Basisrate unter den Wachen {w1['Basisrate'] / (w1['Basisrate'] + w1['v1']):.6f} = {w2['Basisrate']:.6f}; Schläfer {w1['v2']:.3f}"))
    # 6. Kein Blick in die Zukunft: ein Block, dessen Ergebnis bis t noch nicht feststand, bewegt die Gewichte nicht
    zeilen = [{"ts": 0, "y": 1, "experten": {"Basisrate": 0.6, "v1": 0.9}}, {"ts": 14_400, "y": 0, "experten": {"Basisrate": 0.6, "v1": 0.98}}]
    w_a = mischung_aus(zeilen, 4, bis_ts=14_400 + 3_600).gewichte(); w_b = mischung_aus(zeilen[:1], 4).gewichte()
    w_c = mischung_aus(zeilen, 4, bis_ts=14_400 + 14_400).gewichte()
    pruef.append(("Fusion: nur Ergebnisse, die feststanden (prequential)", w_a == w_b and w_c != w_b,
                  f"v1 vor dem Ende des zweiten Blocks {w_a['v1'] * 100:.1f} %, danach {w_c['v1'] * 100:.1f} %"))
    # 7. Toleranzblöcke (y = -1) und fehlende Kurse (y = -2) ändern nichts
    z2 = zeilen[:1] + [{"ts": 14_400, "y": -1, "experten": {"Basisrate": 0.6, "v1": 0.98}}, {"ts": 28_800, "y": -2, "experten": {"v1": 0.02}}]
    pruef.append(("Fusion: Blöcke ohne Urteil zählen nicht", mischung_aus(z2, 4).gewichte() == w_b, "Toleranz und fehlender Kurs ohne Wirkung"))
    # 8. Basisrate prequential und geglättet
    z3 = [{"ts": i * 14_400, "y": 1} for i in range(10)]
    pruef.append(("Fusion: Basisrate nur aus Feststehendem", abs(basis_p(z3, 4, 0) - 0.5) < 1e-12 and basis_p(z3, 4, 10 * 14_400) > 0.85
                  and basis_p(z3, 4, 14_400) == basis_p(z3[:1], 4, 14_400), f"ohne Ergebnis 50 %, nach 10 Aufwärtsblöcken {basis_p(z3, 4, 10 * 14_400) * 100:.1f} %"))
    # 9. Bilanz: Abstand zur Basisrate mit Standardfehler, unabhängig nachgerechnet (offene, Toleranz- und Blöcke ohne Fusionszahl zählen nicht)
    rng = _r.Random(13); z4 = []
    for i in range(40):
        y_ = 1 if rng.random() < 0.6 else 0
        z4.append({"ts": i * 14_400, "y": y_, "p_fusion": round(0.5 + rng.uniform(-0.2, 0.2), 5),
                   "experten": {"Basisrate": round(0.45 + rng.uniform(0, 0.1), 5), "v1": 0.5}, "quelle": "live"})
    z4 += [{"ts": 41 * 14_400, "y": -1, "p_fusion": 0.9, "experten": {"Basisrate": 0.5}}, {"ts": 42 * 14_400, "y": None, "p_fusion": 0.9, "experten": {"Basisrate": 0.5}},
           {"ts": 43 * 14_400, "y": 1, "p_fusion": None, "experten": {"Basisrate": 0.5}}]
    b4 = bilanz(z4, 4)
    dd = [math.log(z["experten"]["Basisrate"] if z["y"] else 1 - z["experten"]["Basisrate"]) - math.log(z["p_fusion"] if z["y"] else 1 - z["p_fusion"]) for z in z4[:40]]
    m_ = sum(dd) / len(dd); se_ = (sum((x - m_) ** 2 for x in dd) / (len(dd) - 1)) ** 0.5 / len(dd) ** 0.5
    pruef.append(("Fusion: Abstand zur Basisrate mit Standardfehler", b4["n"] == 40 and abs(b4["d_basis"] - m_) < 1e-5 and abs(b4["se_basis"] - se_) < 1e-5,
                  f"40 Blöcke: Fusion minus Basisrate {b4['d_basis']:+.4f} ± {b4['se_basis']:.4f} je Block, nachgerechnet {m_:+.4f} ± {se_:.4f}"))
    # 10. Über alle Coins (U108): drei Coins im selben Markt -- gleiche Richtung je Zeitblock. Standardfehler mit Zeitblöcken als Klumpen,
    # unabhängig nachgerechnet; er muss größer sein als der naive, der die drei Coins eines Blocks als unabhängig zählt
    rng = _r.Random(17); z5 = []
    for b_ in range(60):
        y_ = 1 if rng.random() < 0.55 else 0; pf_ = round(0.5 + rng.uniform(-0.15, 0.15), 5)
        for c_ in ("A", "B", "C"):
            z5.append({"coin": c_, "block": b_, "ts": b_ * 14_400, "y": y_, "p_fusion": pf_, "quelle": "live",
                       "experten": {"Basisrate": 0.5, "v2": None if c_ == "C" else round(pf_ + rng.uniform(-0.02, 0.02), 5)}})
    z5.append({"coin": "A", "block": 61, "ts": 61 * 14_400, "y": -1, "p_fusion": 0.9, "experten": {"Basisrate": 0.5}})
    g5 = gepoolt(z5)
    def _nach(m):
        sub = [z for z in z5 if z["y"] in (0, 1) and z["experten"].get(m) is not None]
        d_ = [math.log(z["experten"][m] if z["y"] else 1 - z["experten"][m]) - math.log(z["p_fusion"] if z["y"] else 1 - z["p_fusion"]) for z in sub]
        md_ = sum(d_) / len(d_); S_ = {}
        for z, x in zip(sub, d_):
            S_[z["block"]] = S_.get(z["block"], 0.0) + x - md_
        G_ = len(S_)
        return md_, math.sqrt(G_ / (G_ - 1) * sum(v * v for v in S_.values())) / len(d_), math.sqrt(sum((x - md_) ** 2 for x in d_) / (len(d_) - 1) / len(d_)), len(sub)
    mb_, sb_, naiv_, nb_ = _nach("Basisrate"); mv_, sv_, _, nv_ = _nach("v2")
    eb, ev = g5["experten"].get("Basisrate") or {}, g5["experten"].get("v2") or {}
    pruef.append(("Fusion: über alle Coins, Zeitblöcke als Klumpen", g5["n"] == 180 and g5["coins"] == 3 and g5["zeitbloecke"] == 60 and eb.get("n") == nb_ == 180
                  and ev.get("n") == nv_ == 120 and abs(eb["d"] - mb_) < 1e-5 and abs(eb["se"] - sb_) < 1e-5 and abs(ev["d"] - mv_) < 1e-5
                  and abs(ev["se"] - sv_) < 1e-5 and sb_ > 1.5 * naiv_,
                  f"180 Blöcke aus 3 Coins in 60 Zeitblöcken: Fusion − Basisrate {eb.get('d', 0):+.4f} ± {eb.get('se', 0):.4f} (nachgerechnet "
                  f"{mb_:+.4f} ± {sb_:.4f}; naiv ± {naiv_:.4f}, zu klein) · Fusion − v2 auf dessen 120 Blöcken {ev.get('d', 0):+.4f} ± {ev.get('se', 0):.4f}"))
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<58} {txt}")
    return all(p[1] for p in pruef), pruef


def kosten_probe(verbose: bool = True) -> tuple:
    """Kostenschwelle: gemessenes E|r| eines Zufallspfads gegen die Theorie σ·√(2/π)·√h, Schwelle aus der Formel, XMR doppelt."""
    import random as _r
    pruef = []
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin))")
    # Zufallspfad im 15-min-Raster (mehr liest die Messung nicht): 0,06 % je Minute, 400 Tage für den Theorie-Vergleich
    rng = _r.Random(2); now = PROBE_NOW; px = 100.0; rows = []; s1 = 0.0006; tage = 400
    for t in range(now - tage * 86_400 - 2 * 86_400, now + 60, 900):
        px *= math.exp(rng.gauss(0, s1 * math.sqrt(15))); rows.append((t, "BTC", px, px, px, px, 1, 1)); rows.append((t, "XMR", px, px, px, px, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.execute("CREATE TABLE book_summary (ts INTEGER, coin TEXT, bid REAL, ask REAL, spread_bps REAL, PRIMARY KEY (ts, coin))")
    con.executemany("INSERT INTO book_summary VALUES (?,?,?,?,?)", [(t, "BTC", 99.99, 100.01, 2.0) for t in range(now - 3500, now, 5)])
    mb = mittlere_bewegung(con, "BTC", now, tage=tage)
    # Abweichung in Standardfehlern: E|r| einer Normalverteilung hat die relative Streuung √(π/2 − 1) = 0,755 je unabhängigem Fenster
    abw = {h: (mb[h]["er"] / (s1 * math.sqrt(60 * h) * math.sqrt(2 / math.pi)) - 1) for h in KOSTEN_HORIZONTE}
    se = {h: math.sqrt(math.pi / 2 - 1) / math.sqrt(tage * 24 / h) for h in KOSTEN_HORIZONTE}
    pruef.append(("Kosten: E|r| gemessen = Theorie σ·√h·√(2/π)", max(abs(abw[h]) / se[h] for h in KOSTEN_HORIZONTE) < 3,
                  " · ".join(f"{h} h {abw[h] * 100:+.1f} % ({abw[h] / se[h]:+.1f} SE)" for h in KOSTEN_HORIZONTE) + f" über {tage} Tage"))
    ks = kostenschwelle(con, "BTC", now, cache=False); kx = kostenschwelle(con, "XMR", now, cache=False)
    p4 = 0.5 + ks["k_taker"] / (2 * ks["er_4"])
    pruef.append(("Kosten: Schwelle p* = 1/2 + K / (2 E|r|), Spread je Seite", abs(ks["p_taker_4"] - p4) < 1e-4 and abs(ks["k_taker"] - 2 * (0.00045 + 0.0001)) < 1e-12
                  and ks["halbspread_bps"] == 1.0 and abs(ks["k_maker"] - 2 * 0.00015) < 1e-12
                  and ks["p_taker_1"] > ks["p_taker_4"] > ks["p_taker_24"] and ks["p_maker_4"] < ks["p_taker_4"],
                  f"4 h: Taker {ks['p_taker_4'] * 100:.1f} %, Maker {ks['p_maker_4'] * 100:.1f} % · 1 h {ks['p_taker_1'] * 100:.1f} % · 24 h {ks['p_taker_24'] * 100:.1f} %"))
    pruef.append(("Kosten: XMR (HIP-3) doppelt", abs(kx["k_taker"] - 2 * 0.0009) < 1e-12 and kx["halbspread_bps"] is None and kx["p_taker_4"] > ks["p_taker_4"],
                  f"XMR 4 h Taker {kx['p_taker_4'] * 100:.1f} % gegen BTC {ks['p_taker_4'] * 100:.1f} % bei gleichem Pfad"))
    leer = kostenschwelle(con, "ETH", now, cache=False)
    pruef.append(("Kosten: ohne Kurse keine Schwelle", leer["er_4"] is None and leer["p_taker_4"] is None, "ETH ohne Kerzen → —"))
    con.close()
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<58} {txt}")
    return all(p[1] for p in pruef), pruef


def ende_zu_ende_probe(verbose: bool = True) -> tuple:
    """Der Weg durch ergaenzen(): Nachtrag aus gespeicherten Prognosen, Auflösen, Mischung, Zeile je Block, Bilanz; zweite Prognose
    im selben Block ändert die Zeile nicht (die früheste zählt)."""
    import tempfile
    import shutil
    pruef = []
    tmp = tempfile.mkdtemp(prefix="hl_fusion_e2e_")
    try:
        con, sp, now = _probe_daten(tmp, 9, tage=12, kante=0.75, coins=("BTC",), mit_payload=False)
        st = F.store_connect(sp)
        rows = []; rz = __import__("random").Random(4)
        for ts in range(now - 10 * 86_400, now - 3600, 900):
            p0 = _kurs_bei(con, "BTC", ts); fut = _kurs_bei(con, "BTC", ts + 4 * 3600)
            if not p0 or (ts % 14_400 < 3_600 and rz.random() < 0.5):          # Lücken am Blockanfang: erster Wert je Block 0–60 min später
                continue
            p_gut = 0.62 if (fut and fut > p0) else 0.38
            rows.append((ts, "BTC", p0, 0.0, p0, p0, json.dumps({"p_up_v1": 0.5, "kalib": "v1", "p_up_v2": p_gut, "kalib2": {"version": 2},
                                                                 "p_up_24": 0.5, "p_up_24_v2": None}), 0.5, 0.5))
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?)", rows)
        st.commit(); st.close()
        fc = {"coin": "BTC", "ts": now, "price": _kurs_bei(con, "BTC", now), "p_up_v1": 0.5, "p_up": 0.5, "kalib": "v1", "p_up_v2": 0.6,
              "kalib2": {"version": 2}, "p_up_24": 0.5, "p_up_24_v1": 0.5, "p_up_24_v2": None, "drivers": [], "analog": None}
        ergaenzen(con, fc, path=sp, now=now)
        fu = fc["fusion"]; b4 = (fc.get("fusion_info") or {}).get("bilanz_4") or {}
        st = F.store_connect(sp); b4_voll = bilanz(zeilen_laden(st, "BTC", 4, 0), 4); st.close()
        st = F.store_connect(sp)
        n_live = st.execute("SELECT COUNT(*) FROM fusion_fall WHERE quelle='live'").fetchone()[0]
        n_nach = st.execute("SELECT COUNT(*) FROM fusion_fall WHERE quelle='nachtrag' AND h=4").fetchone()[0]
        st.close()
        pruef.append(("Ende zu Ende: Nachtrag, Mischung, Zeile je Block", not fu.get("fehler") and n_nach >= 50 and n_live == 2 and b4.get("n", 0) >= 40
                      and (fu.get("anteile_4") or {}).get("v2", 0) > 0.9 and (b4_voll.get("experten") or {}).get("Basisrate", {}).get("fusion_minus", 9) < 0
                      and (b4_voll.get("experten") or {}).get("v2", {}).get("fusion_minus", 99) <= (b4.get("grenze") or 0),
                      f"{n_nach} Blöcke nachgetragen, {b4.get('n')} bewertet; Anteil von v2 (Richtung immer richtig, mit 62 %) an der Fusion "
                      f"{(fu.get('anteile_4') or {}).get('v2', 0) * 100:.0f} % (schlafende v3/Analog halten ihr Gewicht); Fusion jetzt {fu.get('p_4')} · "
                      f"Fehler: {fu.get('fehler') or 'keine'}"))
        fc2 = dict(fc, ts=now + 600, p_up_v2=0.99)
        ergaenzen(con, fc2, path=sp, now=now + 600)
        st = F.store_connect(sp)
        z = st.execute("SELECT ts, experten FROM fusion_fall WHERE quelle='live' AND h=4").fetchall(); st.close()
        pruef.append(("Ende zu Ende: zweite Prognose im Block ändert nichts", len(z) == 1 and z[0][0] == now and json.loads(z[0][1]).get("v2") == 0.6,
                      f"Zeile vom {time.strftime('%H:%M', time.localtime(z[0][0])) if z else '—'} mit v2 {json.loads(z[0][1]).get('v2') if z else '—'}"))
        st = F.store_connect(sp); nach = [x for x in zeilen_laden(st, "BTC", 4, 0) if x["quelle"] == "nachtrag"]; st.close()
        abw = max(abs(x["p_fusion"] - mischung_aus(nach[:i], 4, bis_ts=x["ts"]).vorhersage(x["experten"])) for i, x in enumerate(nach))
        tol = [x for x in nach if x["r"] is not None and abs(x["r"]) < F.TOLERANZ]
        pruef.append(("Ende zu Ende: Bewegung unter der Toleranz ohne Urteil", tol and all(x["y"] == -1 for x in tol)
                      and all(x["y"] == (1 if x["r"] > 0 else 0) for x in nach if x["r"] is not None and abs(x["r"]) >= F.TOLERANZ),
                      f"{len(tol)} Blöcke unter {F.TOLERANZ * 100:.1f} % ohne Urteil (wie v2 und die Trefferbilanz, M7), alle übrigen mit Richtung"))
        pruef.append(("Ende zu Ende: Nachtrag ohne Blick in die Zukunft", all(x["ts"] < now for x in nach) and abw < 2e-5 and all(
            abs(x["experten"]["Basisrate"] - round(_klemmen(basis_p(nach[:i], 4, x["ts"])), 5)) < 1e-9 for i, x in enumerate(nach)),
            f"{len(nach)} Blöcke: Basisrate und Fusionszahl je Block unabhängig nachgerechnet, nur aus Ergebnissen davor (größte Abweichung {abw:.1e})"))
        try:                                                                    # der Debug-Bericht „★ Fusion und v3“ auf demselben Stand
            txt = stand_text(con, path=sp, now=now + 600); txt_fehler = None
        except Exception as e:
            txt = ""; txt_fehler = f"{type(e).__name__}: {e}"
        pruef.append(("Ende zu Ende: Debug-Bericht läuft", not txt_fehler and "BTC · Kostenschwelle" in txt and "Fusion 4 h:" in txt and "Fusion 24 h:" in txt
                      and "Fusion minus Basisrate je Block" in txt and "nur live gestellt" in txt and "v3 4 h: noch kein Modell" in txt
                      and "Alle Coins (Auswertung U108)" in txt and "4 h, alle Blöcke: " in txt and "Zeitblöcken · Basisrate" in txt,
                      f"{len(txt.splitlines())} Zeilen" + (f", Fehler {txt_fehler}" if txt_fehler else "")))
        con.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if verbose:
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<58} {txt}")
    return all(p[1] for p in pruef), pruef


def nulltest(verbose: bool = True) -> bool:
    t0 = time.time()
    if verbose:
        print("Fusion, v3 und Kostenschwelle -- Selbsttest (feste Szenarien)")
    ok = True
    for teil in (kosten_probe, fusion_probe, ende_zu_ende_probe, v3_probe):
        try:
            gut, _ = teil(verbose)
        except Exception as e:
            import traceback
            gut = False
            if verbose:
                print(f"  FEHL {teil.__name__}: {type(e).__name__}: {e}")
                traceback.print_exc()
        ok = ok and gut
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok else 'NICHT bestanden'} ({time.time() - t0:.0f} s)")
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--stand" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True) if os.path.exists(_db) else None
        print(stand_text(_con))
        sys.exit(0)
    print(__doc__)
