#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hl_marktschicht.py -- Markt-Schicht des 24-Monats-Charts. Teil 1: Optionen von Deribit (U280, U292; seit 23.118). Teil 2a: was die
Prognosemärkte hergeben, als Text (U280; seit 23.120 -- nur lesen, im Chart steht davon noch nichts).

Was das Modul tut (KONZEPT_Langfrist.md 9.3, Regeln O1 bis O8 -- vor dem Bau festgelegt):
  O1 Ein Abruf der BTC-Optionen bei Deribit je New-York-Tag, fällig ab 15:45 Uhr New York (auch am Wochenende). Der Makro-Takt
     ruft takt_schritt() in jeder Runde; der prüft nur, ob ein Abruf fällig ist. Wiederholung nach einem Fehlschlag frühestens
     nach 10 Minuten, bis der New-York-Tag endet. Ist noch nichts gespeichert, einmal sofort („Erstabruf“); der Abruf zur
     festen Zeit desselben Tages ersetzt ihn.
  O3 Terminkurs je Verfalltag aus der Put-Call-Parität am Geld: F = K ÷ (1 − (Call − Put)) -- inverse Optionen, Kurse in BTC,
     ohne Zins. Das Feld underlying_price ist nur die Gegenprobe.
  O4 Brauchbar wie in 9.2: je Seite fünf Strikes mit Geld- und Briefkurs, Spanne am Geld höchstens 15 %.
  O5 Ränder (10, 25, 50, 75, 90 %) aus den Preisen: Call-Preis in USD ohne Zins an den Strikes der beiden Seiten, zwischen
     benachbarten Strikes die Wahrscheinlichkeit über ihrer Mitte, auf 0 bis 1 begrenzt; Paare, zwischen denen sie steigt,
     werden zu einem Paar über die ganze Strecke zusammengelegt; der Rand ist der kleinste Kurs, an dem die Marke erreicht ist. Außerhalb der Strikes gibt es keinen Rand. Gegenprobe aus der Schwankung
     am Geld (Normalverteilung in ln), nur im Bericht.
  O6 Gespeichert werden Kennzahlen je Abruf-Tag und Verfalltag (makro.db, lf_option) und je Abruf-Tag eine Zeile über den
     Abruf (lf_option_abruf). Die Kette selbst wird nicht gespeichert.
  O7 Für den Chart: der jüngste gespeicherte Abruf, wenn er höchstens 3 Tage vor dem Stichtag liegt; Zeichen nur für
     brauchbare Verfalltage ab 28 Tagen.
  O8 Lesart: risikoneutral, keine Prognose; die Schicht geht nicht in den Fächer ein.
  O9 Diagnose (seit 23.119, nur für den Bericht -- kein Rand ändert sich): wo zusammengelegt wurde (im Bereich der Ränder oder
     außerhalb), die Enden der Reihe, und eine zweite Gegenprobe aus den Schwankungen der Börse je Strike (Black-76 mit dem
     Terminkurs aus O3) -- gespeichert je Verfalltag in der Spalte diag.
  O10 Prüflauf ohne Speichern (Debug 158): ein Abruf, dieselbe Rechnung, dazu die Paare im Bereich der Ränder.

Das Lesen der Antwort (Kennungen, Geld- und Briefkurs, Verfall um 08:00 UTC) kommt aus hl_optionen.py (Erstlauf, Debug 154);
dessen Zählweise und Urteil bleiben unberührt.

Teil 2a (KONZEPT_Langfrist.md 9.4): Der Lauf --prognosemarkt liest prognosemarkt.db (gesammelt von hl_prognosemarkt.py) nur lesend
und zeigt die BTC-Märkte mit Frist ab 7 Tagen -- Schwellen-Leitern (eine Frist, mehrere Niveaus), Fristen-Leitern (ein Niveau,
mehrere Fristen), den Kurs am Stichtag aus Spannen -- je Markt roh und rekalibriert (KONZEPT_Prognosemaerkte.md, Regel 1.6), dazu den
Fed-Pfad aus Kalshi KXFED. Kein Abruf, nichts wird gespeichert, nichts geht in den Fächer. Die Regeln für die Punkte im Chart werden
nach dem ersten Bericht vom Pi festgelegt.

Aufruf:  python3 hl_marktschicht.py --stand --db PFAD     gespeicherter Stand als Text (liest nur)
         python3 hl_marktschicht.py --prognosemarkt --db PFAD   Prognosemärkte und Fed-Pfad als Text (liest nur; Debug 159)
         python3 hl_marktschicht.py --pruefen             ein Abruf bei Deribit, Rechnung und Diagnose als Text (speichert nichts)
         python3 hl_marktschicht.py --selbsttest          ohne Netz, erzeugte Ketten
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import statistics
import sys
import textwrap
import time
from datetime import date, datetime, timezone
from pathlib import Path

import hl_aktien as AK
import hl_optionen as OP

VERSION_MODUL = "2026-09-23.120"
PLAN = "U280"
REGEL = "KONZEPT_Langfrist.md 9.3, O1–O10 vom 22.11.2026"
TAG = 86_400
RAENDER = (10, 25, 50, 75, 90)
Z_WERT = {10: -1.2816, 25: -0.6745, 50: 0.0, 75: 0.6745, 90: 1.2816}       # O5.5: Normalverteilung
ABRUF_STUNDE, ABRUF_MINUTE = 15, 45                                       # O1: New York
WIEDER_S = 600                                                            # O1: nächster Versuch frühestens nach 10 Minuten
MIN_STRIKES = OP.MIN_STRIKES                                              # O4 (9.2): 5 je Seite
MAX_SPANNE = OP.MAX_SPANNE                                                # O4 (9.2): 15 %
ABW_MELDEN = 0.01                                                         # O3: Parität gegen Feld
MIN_TAGE_CHART = 28                                                       # O7: bis dahin reicht der Ausblick
MAX_ALTER_TAGE = 3                                                        # O7: Abruf höchstens so viele Tage vor dem Stichtag
PRUEF_MITTE = 0.03                                                        # O9: Mitte aus den Preisen gegen die zweite Gegenprobe
PRUEF_RAND = 0.06                                                         # O9: ein anderer Rand gegen die zweite Gegenprobe
PRUEF_ANTEIL = 1.0 / 3.0                                                  # O9: Anteil zusammengelegter Paare im Bereich der Ränder
DEBUG_NR_PRUEFEN = 158                                                    # O10: Prüflauf ohne Speichern
EPS = 1e-12
TABELLE = ("CREATE TABLE IF NOT EXISTS lf_option (tag TEXT NOT NULL, verfall TEXT NOT NULL, ts INTEGER NOT NULL, art TEXT NOT NULL, "
           "tage REAL NOT NULL, termin REAL, termin_art TEXT, feld REAL, iv REAL, q10 REAL, q25 REAL, q50 REAL, q75 REAL, q90 REAL, "
           "unter INTEGER, ueber INTEGER, spanne REAL, stufe TEXT NOT NULL, grund TEXT, glatt INTEGER, strikes INTEGER, "
           "diag TEXT, PRIMARY KEY (tag, verfall))")
TABELLE_ABRUF = ("CREATE TABLE IF NOT EXISTS lf_option_abruf (tag TEXT PRIMARY KEY, ts INTEGER, art TEXT, status INTEGER, bytes INTEGER, "
                 "dauer REAL, kontrakte INTEGER, verfalltage INTEGER, versuche INTEGER NOT NULL DEFAULT 0, letzter_versuch INTEGER, "
                 "fehler TEXT, modul TEXT)")
SPALTEN = ("tag", "verfall", "ts", "art", "tage", "termin", "termin_art", "feld", "iv", "q10", "q25", "q50", "q75", "q90", "unter", "ueber",
           "spanne", "stufe", "grund", "glatt", "strikes", "diag")
LESART = ("Optionspreise sind risikoneutral: Sie zeigen, zu welchen Preisen sich der Markt absichert, keine Prognose; ihre Mitte liegt nahe "
          "am Terminkurs. Die Schicht geht nicht in den Fächer ein.")
STUFE_TXT = {"quantile": "Ränder", "iv": "nur Schwankung am Geld", "entfaellt": "entfällt"}


# ================================================================================================ Rechenweg (O3 bis O5)

def seiten(K: list) -> tuple:
    """Kontrakte EINES Verfalltags -> (Calls, Puts) je Strike; ein doppelter Strike zählt einmal (der erste)."""
    calls, puts = {}, {}
    for k in K:
        ziel = calls if k["typ"] == "C" else puts
        ziel.setdefault(k["strike"], k)
    return calls, puts


def terminkurs(calls: dict, puts: dict) -> dict:
    """O3: Terminkurs aus der Put-Call-Parität am Strike mit dem kleinsten |Call − Put|; das Feld ist die Gegenprobe."""
    tf = [k["termin"] for k in list(calls.values()) + list(puts.values()) if k.get("termin") is not None and k["termin"] > 0]
    feld = float(statistics.median(tf)) if tf else None
    paare = [(abs(OP.mitte(calls[s]) - OP.mitte(puts[s])), s) for s in sorted(set(calls) & set(puts)) if OP.beide(calls[s]) and OP.beide(puts[s])]
    f, art, k_par = None, None, None
    if paare:
        _, k_par = min(paare)                                              # kleinster Abstand; bei Gleichstand der niedrigere Strike
        nenner = 1.0 - (OP.mitte(calls[k_par]) - OP.mitte(puts[k_par]))
        if nenner > 0.2:                                                   # sonst sind die Kurse keine einer inversen Option am Geld
            f, art = k_par / nenner, "paritaet"
    if f is None and feld is not None:
        f, art, k_par = feld, "feld", None
    abw = f / feld - 1.0 if art == "paritaet" and feld else None
    return {"f": f, "art": art, "k": k_par, "feld": feld, "abw": abw}


def call_reihe(calls: dict, puts: dict, f: float) -> list:
    """O5.1: (Strike, Call-Preis in USD ohne Zins) an den Strikes der beiden Seiten -- unter F aus dem Put (Parität), über F der Call."""
    reihe = []
    for s in sorted(set(calls) | set(puts)):
        if s < f and s in puts and OP.beide(puts[s]):
            reihe.append((s, f * OP.mitte(puts[s]) + f - s))
        elif s > f and s in calls and OP.beide(calls[s]):
            reihe.append((s, f * OP.mitte(calls[s])))
    return reihe


def ueber_wkt(reihe: list) -> tuple:
    """
    O5.2 und O5.3: je Paar benachbarter Strikes die Wahrscheinlichkeit, dass der Kurs am Verfalltag über ihrer Mitte liegt
    (Abnahme des Call-Preises je USD Strike), auf 0 bis 1 begrenzt. Steigt sie von einem Paar zum nächsten, werden die beiden
    zu EINEM Paar über die ganze Strecke zusammengelegt (Wert = Mittel, gewichtet mit dem Abstand der Strikes; Mitte = Mitte
    der Strecke) -- so oft, bis sie mit dem Kurs nirgends mehr steigt. Rückgabe: (Mitten, Werte, Zahl der Zusammenlegungen).
    """
    bloecke = []                                                           # [Summe Wert × Gewicht, Summe Gewicht, unterer Strike, oberer Strike]
    n = 0
    for (k1, c1), (k2, c2) in zip(reihe, reihe[1:]):
        n += 1
        w = k2 - k1
        bloecke.append([min(1.0, max(0.0, (c1 - c2) / w)) * w, w, k1, k2])
        while len(bloecke) > 1 and bloecke[-2][0] / bloecke[-2][1] < bloecke[-1][0] / bloecke[-1][1] - EPS:
            b = bloecke.pop()
            bloecke[-1][0] += b[0]; bloecke[-1][1] += b[1]; bloecke[-1][3] = b[3]
    return [(b[2] + b[3]) / 2.0 for b in bloecke], [b[0] / b[1] for b in bloecke], n - len(bloecke)


def raender(mitten: list, s: list) -> dict:
    """O5.4: je Marke q der kleinste Kurs, an dem 1 − s sie erreicht; zwischen den Mitten gerade verbunden; außerhalb: None."""
    g = [1.0 - x for x in s]
    out = {}
    for q in RAENDER:
        z = q / 100.0
        j = next((i for i, gi in enumerate(g) if gi >= z - EPS), None)
        if j is None:
            out[q] = None                                                  # die Marke liegt über dem größten Strike-Paar
        elif j == 0:
            out[q] = mitten[0] if abs(g[0] - z) <= EPS else None           # schon am kleinsten Strike-Paar überschritten
        else:
            out[q] = mitten[j - 1] + (z - g[j - 1]) / (g[j] - g[j - 1]) * (mitten[j] - mitten[j - 1])
    return out


def gegenprobe(f, iv, tage) -> dict:
    """O5.5: Ränder einer Normalverteilung in ln um F mit der Schwankung am Geld (iv in Prozent pro Jahr)."""
    if f is None or iv is None or iv <= 0 or tage is None or tage <= 0:
        return {q: None for q in RAENDER}
    sig, t = iv / 100.0, tage / 365.0
    return {q: f * math.exp(-sig * sig * t / 2.0 + Z_WERT[q] * sig * math.sqrt(t)) for q in RAENDER}


def strecken(reihe: list, mitten: list) -> list:
    """
    O9.1: die Paare nach dem Zusammenlegen als Strecken [(unterer Strike, oberer Strike, Zahl der Paare darin)] -- aus den Strikes
    der Reihe und den Mitten von ueber_wkt (die Strecke eines Paars beginnt, wo die vorige endet).
    """
    ks = [k for k, _ in reihe]
    out, i = [], 0
    for m in mitten:
        ende = 2.0 * m - ks[i]
        j = min(range(i + 1, len(ks)), key=lambda n: abs(ks[n] - ende))
        out.append((ks[i], ks[j], j - i))
        i = j
    return out


def mark_reihe(calls: dict, puts: dict, f, tage) -> list:
    """
    O9.3: (Strike, Call-Preis in USD ohne Zins nach Black-76) an jedem gelisteten Strike mit einer Schwankung der Börse (mark_iv) --
    unter F die des Puts, über F die des Calls; fehlt sie dort, die der anderen Seite. Hängt an keinem Geld- oder Briefkurs.
    """
    if f is None or f <= 0 or tage is None or tage <= 0:
        return []
    t = tage / 365.0
    reihe = []
    for s in sorted(set(calls) | set(puts)):
        if s <= 0 or s == f:
            continue
        erst, zweit = (puts.get(s), calls.get(s)) if s < f else (calls.get(s), puts.get(s))
        iv = next((k["iv"] for k in (erst, zweit) if k is not None and k.get("iv") is not None and k["iv"] > 0), None)
        if iv is not None:
            reihe.append((s, _b76(f, s, iv / 100.0, t)[0]))
    return reihe


def diagnose(calls: dict, puts: dict, f: float, tage, reihe: list, mitten: list, s: list, q: dict) -> dict:
    """
    O9 (nur für den Bericht): wo zusammengelegt wurde (zi im Bereich der Ränder von pi Paaren dort, za außerhalb), die Enden der
    Reihe (kmin, kmax mit Kursen; gmin, gmax gelistet; pu unter der untersten Mitte mu, po über der obersten Mitte mo) und die
    zweite Gegenprobe aus den Schwankungen der Börse (mark: Ränder, mn Strikes, mg Zusammenlegungen).
    """
    S = strecken(reihe, mitten)
    da = [q[r] for r in RAENDER if q.get(r) is not None]
    innen = paare_innen = None
    if da:
        lo, hi = min(da), max(da)
        im = [p for a, b, p in S if b >= lo and a <= hi]
        innen, paare_innen = sum(p - 1 for p in im), sum(im)
    gesamt = sum(p - 1 for _, _, p in S)
    gelistet = sorted(set(calls) | set(puts))
    mr = mark_reihe(calls, puts, f, tage)
    qm, glatt_m = {r: None for r in RAENDER}, None
    if len(mr) >= 3:
        mm, sm, glatt_m = ueber_wkt(mr)
        qm = raender(mm, sm)
    return {"zi": innen, "za": None if innen is None else gesamt - innen, "pi": paare_innen,
            "kmin": reihe[0][0] if reihe else None, "kmax": reihe[-1][0] if reihe else None,
            "gmin": gelistet[0] if gelistet else None, "gmax": gelistet[-1] if gelistet else None,
            "pu": 1.0 - s[0] if s else None, "po": s[-1] if s else None,
            "mu": mitten[0] if mitten else None, "mo": mitten[-1] if mitten else None,
            "mark": {str(r): qm[r] for r in RAENDER}, "mn": len(mr), "mg": glatt_m}


def pruef_gruende(d: dict) -> list:
    """O9 („Wozu die Diagnose dient“): Gründe, einen Verfalltag im Bericht mit „prüfen“ zu markieren. Ohne Diagnose: keine."""
    g = d.get("diag")
    if not g or d.get("stufe") != "quantile":
        return []
    q, m = d["q"], g.get("mark") or {}

    def neben(r):
        a, b = q.get(str(r)), m.get(str(r))
        return None if a is None or b is None or b <= 0 else a / b - 1.0
    out = []
    x = neben(50)
    if x is not None and abs(x) > PRUEF_MITTE:
        out.append(f"Mitte {'+' if x >= 0 else '−'}{OP.de(abs(x) * 100, 1)} % neben der zweiten Gegenprobe (über {OP.pz(PRUEF_MITTE, 0)})")
    for r in (10, 25, 75, 90):
        x = neben(r)
        if x is not None and abs(x) > PRUEF_RAND:
            out.append(f"{r}-%-Rand {'+' if x >= 0 else '−'}{OP.de(abs(x) * 100, 1)} % neben der zweiten Gegenprobe (über {OP.pz(PRUEF_RAND, 0)})")
    if g.get("zi") is not None and g.get("pi") and g["zi"] / g["pi"] > PRUEF_ANTEIL:
        out.append(f"im Bereich der Ränder {g['zi']} von {g['pi']} Paaren zusammengelegt (über ein Drittel)")
    return out


def kennzahlen(K: list, tage=None) -> dict:
    """
    Kennzahlen EINES Verfalltags nach O3 bis O5 (Terminkurs aus der Parität, Stufe nach 9.2, Ränder aus den Preisen). Mit tage
    (Tage bis zum Verfall) dazu die Diagnose nach O9 -- sie ändert keinen Rand.
    """
    calls, puts = seiten(K)
    T = terminkurs(calls, puts)
    f = T["f"]
    strikes = sorted(set(calls) | set(puts))
    unter = sum(1 for s in strikes if f is not None and s < f and s in puts and OP.beide(puts[s]))
    ueber = sum(1 for s in strikes if f is not None and s > f and s in calls and OP.beide(calls[s]))
    gemeinsam = [s for s in strikes if s in calls and s in puts]
    k_geld = min(gemeinsam, key=lambda s: (abs(s - f), s)) if gemeinsam and f is not None else None
    spanne = iv = None
    if k_geld is not None:
        c, p = calls[k_geld], puts[k_geld]
        if OP.beide(c) and OP.beide(p):
            spanne = (c["ask"] + p["ask"] - c["bid"] - p["bid"]) / ((c["ask"] + p["ask"] + c["bid"] + p["bid"]) / 2.0)
        ivs = [k["iv"] for k in (c, p) if k.get("iv") is not None and k["iv"] > 0]
        iv = sum(ivs) / len(ivs) if ivs else None
    gruende = []
    if f is None:
        gruende.append("kein Terminkurs")
    else:
        if T["art"] != "paritaet":
            gruende.append("kein Strike mit Geld- und Briefkurs für Call und Put (Terminkurs nur aus dem Feld)")
        if unter < MIN_STRIKES:
            gruende.append(f"unter dem Terminkurs nur {unter} {'Strike' if unter == 1 else 'Strikes'} mit beiden Kursen")
        if ueber < MIN_STRIKES:
            gruende.append(f"darüber nur {ueber} {'Strike' if ueber == 1 else 'Strikes'} mit beiden Kursen")
        if k_geld is None:
            gruende.append("kein Strike mit Call und Put")
        elif spanne is None:
            gruende.append("am Geld fehlt ein Geld- oder Briefkurs")
        elif spanne > MAX_SPANNE + 1e-9:
            gruende.append(f"Spanne am Geld {OP.pz(spanne)} über {OP.pz(MAX_SPANNE, 0)}")
    q = {r: None for r in RAENDER}
    glatt = diag = None
    if not gruende:
        reihe = call_reihe(calls, puts, f)
        mitten, s, glatt = ueber_wkt(reihe)
        q = raender(mitten, s)
        if tage is not None:
            try:
                diag = diagnose(calls, puts, f, tage, reihe, mitten, s, q)
            except Exception as e:                                         # O9: nur Bericht -- ein Fehler hier darf den Abruf nicht kosten
                diag = {"fehler": f"{type(e).__name__}: {e}"[:160]}
    stufe = "quantile" if not gruende else ("iv" if iv is not None else "entfaellt")
    return {"termin": f, "termin_art": T["art"], "k_par": T["k"], "feld": T["feld"], "abw": T["abw"], "iv": iv, "q": q, "unter": unter,
            "ueber": ueber, "k_geld": k_geld, "spanne": spanne, "stufe": stufe, "grund": "; ".join(gruende) or None, "glatt": glatt,
            "strikes": len(strikes), "diag": diag}


def nach_verfall(kontrakte: list, jetzt: float) -> dict:
    """Die Kontrakte der kommenden Verfalltage, je Verfall-Zeitpunkt eine Liste (O2: vergangene entfallen)."""
    gruppen = {}
    for k in kontrakte:
        if k["verfall"] > jetzt:
            gruppen.setdefault(k["verfall"], []).append(k)
    return gruppen


def auswerten(kontrakte: list, jetzt: float) -> list:
    """Alle kommenden Verfalltage einer gelesenen Kette (OP.deribit_lesen), aufsteigend, je mit Kennzahlen, Verfalltag und Tagen."""
    gruppen = nach_verfall(kontrakte, jetzt)
    out = []
    for ts in sorted(gruppen):
        tage = (ts - jetzt) / TAG
        v = kennzahlen(gruppen[ts], tage)
        v.update(verfall=gruppen[ts][0]["tag"].isoformat(), verfall_ts=ts, tage=tage)
        out.append(v)
    return out


# ================================================================================================ Abruf und Ablage (O1, O6)

def ny_tag(jetzt: float) -> date:
    return AK.ny_jetzt(jetzt).date()


def plan_ts(tag: date) -> int:
    """O1: Zeitpunkt, ab dem der Abruf des New-York-Tags fällig ist."""
    return AK.ny_ts(tag, ABRUF_STUNDE, ABRUF_MINUTE)


def _tabellen(con) -> None:
    con.execute(TABELLE); con.execute(TABELLE_ABRUF)


def faellig(con, jetzt: float) -> tuple:
    """O1: ("plan" | "erst" | None, Grund als Text, nächster möglicher Zeitpunkt oder None). Liest nur."""
    tag = ny_tag(jetzt)
    z = con.execute("SELECT ts, art, letzter_versuch FROM lf_option_abruf WHERE tag=?", (tag.isoformat(),)).fetchone()
    ts, art, versuch = z if z else (None, None, None)
    warten = versuch is not None and jetzt - versuch < WIEDER_S
    ab = plan_ts(tag)
    if jetzt >= ab:
        if ts is not None and art == "plan":
            return None, "der Abruf dieses Tages ist gespeichert", plan_ts(date.fromordinal(tag.toordinal() + 1))
        if warten:
            return None, "letzter Versuch vor weniger als 10 Minuten", int(versuch + WIEDER_S)
        return "plan", "fällig", None
    if con.execute("SELECT 1 FROM lf_option_abruf WHERE ts IS NOT NULL LIMIT 1").fetchone():
        return None, "fällig ab 15:45 Uhr New York", ab
    if warten:
        return None, "letzter Versuch vor weniger als 10 Minuten", int(versuch + WIEDER_S)
    return "erst", "noch kein Abruf gespeichert", None


def _spalten_da(con) -> set:
    return {r[1] for r in con.execute("PRAGMA table_info(lf_option)")}


def holen(http_fn, jetzt: float) -> tuple:
    """
    EIN Aufruf bei Deribit und die Auswertung -- der einzige Weg ins Netz, für den Tagesabruf (O1) und den Prüflauf (O10).
    Rückgabe: (Abruf, gelesene Antwort oder None, Kennzahlen je Verfalltag, Fehlertext oder None).
    """
    a = OP.abruf(OP.DERIBIT_URL, http_fn or OP._http)
    fehler = a["fehler"]
    V = []
    gelesen = None
    if not fehler:
        gelesen = OP.deribit_lesen(a["obj"])
        if not gelesen["ok"]:
            fehler = gelesen["grund"]
        else:
            V = auswerten(gelesen["kontrakte"], jetzt)
            if not V:
                fehler = "kein kommender Verfalltag in der Antwort"
    if fehler:
        kopf = f"HTTP {a['status']}: " if a["status"] is not None and not str(fehler).startswith("HTTP") else ""
        fehler = OP.sauber(kopf + str(fehler), 200)
    return a, gelesen, V, fehler


def tagesabruf(pfad: str, http_fn=None, jetzt: float | None = None) -> dict:
    """
    O1 und O6: prüft, ob ein Abruf fällig ist; wenn ja: EIN Aufruf bei Deribit, auswerten, Kennzahlen speichern. Wirft nie.
    Rückgabe: {"art": "plan" | "erst" | None, "grund", "tag", "gespeichert": Zahl der Verfalltage, "fehler"}.
    """
    jetzt = time.time() if jetzt is None else float(jetzt)
    out = {"art": None, "grund": None, "tag": None, "gespeichert": 0, "fehler": None, "ts": int(jetzt)}
    try:
        con = sqlite3.connect(pfad, timeout=30)
    except Exception as e:
        out["fehler"] = f"{type(e).__name__}: {e}"
        return out
    try:
        if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('lf_option', 'lf_option_abruf')").fetchone()[0] != 2:
            _tabellen(con); con.commit()                                   # nur beim ersten Mal: sonst liest die Prüfung der Fälligkeit bloß
        elif "diag" not in _spalten_da(con):
            con.execute("ALTER TABLE lf_option ADD COLUMN diag TEXT"); con.commit()   # 23.119 (O9): einmal je Datenbank aus 23.118
        art, grund, _ = faellig(con, jetzt)
        tag = ny_tag(jetzt).isoformat()
        out.update(art=art, grund=grund, tag=tag)
        if art is None:
            return out
        con.execute("INSERT OR IGNORE INTO lf_option_abruf (tag, versuche) VALUES (?, 0)", (tag,))
        con.execute("UPDATE lf_option_abruf SET versuche = versuche + 1, letzter_versuch = ?, modul = ? WHERE tag = ?", (int(jetzt), VERSION_MODUL, tag))
        con.commit()                                                       # der Versuch zählt, auch wenn der Abruf hängt oder scheitert
        a, gelesen, V, fehler = holen(http_fn, jetzt)
        if fehler:
            out["fehler"] = fehler
            con.execute("UPDATE lf_option_abruf SET fehler = ? WHERE tag = ?", (out["fehler"], tag))
            con.commit()
            return out
        con.execute("DELETE FROM lf_option WHERE tag = ?", (tag,))         # nur der Erstabruf desselben Tages kann hier stehen (O1)
        for v in V:
            con.execute("INSERT INTO lf_option (" + ", ".join(SPALTEN) + ") VALUES (" + ", ".join("?" * len(SPALTEN)) + ")",
                        (tag, v["verfall"], int(jetzt), art, round(v["tage"], 4), v["termin"], v["termin_art"], v["feld"], v["iv"],
                         v["q"][10], v["q"][25], v["q"][50], v["q"][75], v["q"][90], v["unter"], v["ueber"], v["spanne"], v["stufe"],
                         v["grund"], v["glatt"], v["strikes"],
                         json.dumps(v["diag"], ensure_ascii=False, separators=(",", ":")) if v.get("diag") is not None else None))
        con.execute("UPDATE lf_option_abruf SET ts = ?, art = ?, status = ?, bytes = ?, dauer = ?, kontrakte = ?, verfalltage = ?, fehler = NULL "
                    "WHERE tag = ?", (int(jetzt), art, a["status"], a["bytes"], round(a["dauer"], 2), len(gelesen["kontrakte"]), len(V), tag))
        con.commit()
        out["gespeichert"] = len(V)
        return out
    except Exception as e:
        out["fehler"] = f"{type(e).__name__}: {e}"
        return out
    finally:
        con.close()


def takt_schritt(pfad: str, jetzt: float | None = None, http_fn=None) -> dict:
    """Vom Makro-Takt in JEDER Runde gerufen: Abruf nur, wenn er fällig ist (sonst ein Lesen der Datenbank). Wirft nie."""
    try:
        return tagesabruf(pfad, http_fn=http_fn, jetzt=jetzt)
    except Exception as e:                                                 # der Makro-Takt hängt nicht an dieser Schicht
        return {"art": None, "grund": None, "tag": None, "gespeichert": 0, "fehler": f"{type(e).__name__}: {e}"}


# ================================================================================================ Stand für Chart und Bericht (O7)

def _zeile(z, spalten: tuple = SPALTEN) -> dict:
    d = dict(zip(spalten, z))
    d["q"] = {str(r): d.pop(f"q{r}") for r in RAENDER}                     # Schlüssel als Text: die Antwort geht als JSON an die Seite
    try:
        d["diag"] = json.loads(d["diag"]) if d.get("diag") else None       # O9; ein Abruf vor 23.119 hat keine
    except (TypeError, ValueError):
        d["diag"] = None
    if not isinstance(d["diag"], dict):
        d["diag"] = None
    return d


def zeichen(d: dict) -> bool:
    """O7: Ein Verfalltag bekommt ein Zeichen im Chart, wenn er brauchbar ist, mindestens 28 Tage läuft und Mitte und innere Ränder hat."""
    return d["stufe"] == "quantile" and d["tage"] >= MIN_TAGE_CHART and all(d["q"][r] is not None for r in ("25", "50", "75"))


def stand(pfad: str, stichtag: int | None = None, jetzt: float | None = None) -> dict:
    """
    Der jüngste gespeicherte Abruf für Chart und Bericht. stichtag = Tag seit 1970 (UTC) des Fächers; liegt der Abruf mehr als
    3 Tage davor, gibt es keine Zeichen (O7). Liest nur; legt nichts an; wirft nie.
    """
    jetzt = time.time() if jetzt is None else float(jetzt)
    out = {"ok": False, "grund": None, "tag": None, "ts": None, "art": None, "alter_tage": None, "zeilen": [], "punkte": [],
           "abruf": None, "heute": None, "naechster": None, "lesart": LESART}
    try:
        con = sqlite3.connect(Path(os.path.abspath(pfad)).as_uri() + "?mode=ro", uri=True, timeout=10)
    except Exception as e:
        out["grund"] = f"makro.db nicht lesbar ({type(e).__name__})"
        return out
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='lf_option_abruf'").fetchone():
            out["grund"] = "Noch kein Abruf der Optionen gespeichert (der erste folgt kurz nach dem Start des Dashboards)."
            return out
        spalten_a = ("tag", "ts", "art", "status", "bytes", "dauer", "kontrakte", "verfalltage", "versuche", "letzter_versuch", "fehler")
        h = con.execute("SELECT " + ", ".join(spalten_a) + " FROM lf_option_abruf WHERE tag=?", (ny_tag(jetzt).isoformat(),)).fetchone()
        out["heute"] = dict(zip(spalten_a, h)) if h else None
        _, _, out["naechster"] = faellig(con, jetzt)
        a = con.execute("SELECT " + ", ".join(spalten_a) + " FROM lf_option_abruf WHERE ts IS NOT NULL ORDER BY tag DESC LIMIT 1").fetchone()
        if not a:
            f = (out["heute"] or {}).get("fehler")
            out["grund"] = "Noch kein Abruf der Optionen gespeichert" + (f" (letzter Versuch: {f})." if f else ".")
            return out
        out["abruf"] = dict(zip(spalten_a, a))
        out.update(tag=a[0], ts=a[1], art=a[2])
        sp = SPALTEN if "diag" in _spalten_da(con) else SPALTEN[:-1]       # Tabelle aus 23.118, bevor der Takt die Spalte angelegt hat
        zeilen = [_zeile(z, sp) for z in con.execute("SELECT " + ", ".join(sp) + " FROM lf_option WHERE tag=? ORDER BY verfall", (a[0],))]
        for d in zeilen:
            d["gegen"] = {str(r): v for r, v in gegenprobe(d["termin"], d["iv"], d["tage"]).items()}
            d["tag_verfall"] = date.fromisoformat(d["verfall"]).toordinal() - date(1970, 1, 1).toordinal()
            d["zeichen"] = zeichen(d)
            try:
                d["pruefen"] = pruef_gruende(d)                            # O9: nur Bericht -- ein Fehler hier darf die Zeichen nicht kosten
            except Exception:
                d["pruefen"] = []
        out["zeilen"] = zeilen
        if stichtag is not None:
            out["alter_tage"] = int(stichtag) - int(a[1] // TAG)
            if out["alter_tage"] > MAX_ALTER_TAGE:
                out["grund"] = (f"Der jüngste Abruf der Optionen ist vom {_tag_txt(a[1])} -- mehr als {MAX_ALTER_TAGE} Tage vor dem "
                                "Stichtag; er wird nicht gezeigt.")
                for d in zeilen:
                    d["zeichen"] = False
                return out
        out["punkte"] = [{"verfall": d["verfall"], "tag": d["tag_verfall"], "tage": d["tage"], "termin": d["termin"],
                          **{f"q{r}": d["q"][str(r)] for r in RAENDER}} for d in zeilen if d["zeichen"]]
        out["ok"] = True
        if not out["punkte"]:
            out["grund"] = f"Im Abruf vom {_tag_txt(a[1])} ist kein Verfalltag ab {MIN_TAGE_CHART} Tagen brauchbar für Ränder."
        return out
    except Exception as e:
        out["ok"] = False; out["punkte"] = []
        out["grund"] = f"Optionen nicht lesbar ({type(e).__name__}: {e})"
        return out
    finally:
        con.close()


# ================================================================================================ Text

def _tag_txt(ts) -> str:
    return time.strftime("%d.%m.%Y", time.localtime(ts)) if ts is not None else "—"


def _uhr(ts) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(ts)) if ts is not None else "—"


def _usd(x) -> str:
    return "—" if x is None else OP.de(x, 0)


def _wkt(x) -> str:
    return "—" if x is None else OP.de(x * 100.0, 1) + " %"


def _neben(a, b) -> str:
    if a is None or b is None or b <= 0:
        return "—"
    x = a / b - 1.0
    return ("+" if x >= 0 else "−") + OP.de(abs(x) * 100, 1) + " %"


def diagnose_text(Z: list) -> list:
    """O9 für den Bericht: je Verfalltag mit Diagnose eine Zeile zu den Zusammenlegungen und Enden, dann die zweite Gegenprobe."""
    z = []
    a = z.append
    D = [d for d in Z if d.get("diag")]
    if not D:
        if any(d.get("stufe") == "quantile" for d in Z):
            a("")
            a("  Diagnose (O9): noch keine -- dieser Abruf wurde vor 23.119 gespeichert; der nächste trägt sie.")
        return z
    a("")
    a("  Diagnose (O9) -- nur für den Bericht, kein Rand ändert sich. Je Verfalltag: zusammengelegte Paare im Bereich der Ränder (vom")
    a("  untersten bis zum obersten Rand) und außerhalb; Strikes der Reihe mit Geld- und Briefkurs und alle gelisteten; Wahrscheinlichkeit")
    a("  unter dem untersten und über dem obersten Paar -- liegt sie über 10 %, fehlt dort der äußere Rand.")
    for d in D:
        g = d["diag"]
        if g.get("fehler"):                                                # die Rechnung scheiterte an diesem Verfalltag -- seine Ränder sind gespeichert
            a(f"    {_iso_txt(d['verfall'])}  nicht gerechnet -- {g['fehler']}")
            continue
        lage = "ohne Rand" if g.get("zi") is None else f"im Bereich {g['zi']} von {g['pi']}, außerhalb {g['za']}"
        a(f"    {_iso_txt(d['verfall'])}  {lage} · Kurse {_usd(g.get('kmin'))}–{_usd(g.get('kmax'))} (gelistet "
          f"{_usd(g.get('gmin'))}–{_usd(g.get('gmax'))}) · unter {_usd(g.get('mu'))}: {_wkt(g.get('pu'))} · über {_usd(g.get('mo'))}: {_wkt(g.get('po'))}")
    D = [d for d in D if not d["diag"].get("fehler")]
    if not D:
        return z
    a("")
    a("  Zweite Gegenprobe (O9.3): dieselben Ränder aus den Schwankungen der Börse je Strike -- alle gelisteten Strikes, ohne Geld- und")
    a("  Briefkurse, Terminkurs aus der Parität. Rechts: Mitte und äußere Ränder aus den Preisen gegen diese (Abstand in %).")
    a("    Verfall        10 %     25 %    Mitte     75 %     90 %   Strikes   Preise gegen Börse: 10 % · Mitte · 90 %")
    for d in D:
        g = d["diag"]; m = g.get("mark") or {}
        a(f"    {_iso_txt(d['verfall'])}  " + "  ".join(f"{_usd(m.get(str(r))):>7}" for r in RAENDER)
          + f"   {g.get('mn') if g.get('mn') is not None else '—':>5}     "
          + " · ".join(_neben(d["q"].get(str(r)), m.get(str(r))) for r in (10, 50, 90))
          + (f"   ({g['mg']} zusammengelegt)" if g.get("mg") else ""))
    for d in D:
        for grund in d.get("pruefen") or []:
            a(f"    <-- prüfen {_iso_txt(d['verfall'])}: {grund}")
    return z


def stand_text(S: dict, faecher: dict | None = None, lesart: bool = True) -> list:
    """
    Abschnitt „Optionen“ für Debug 156 aus stand(). faecher: je Verfalltag (ISO) die Ränder des Fächers am selben Tag
    ({"2026-12-25": {"10": …, "50": …, "90": …}}), vom Aufrufer gerechnet. lesart=False: ohne den Satz zur Lesart (der Aufrufer
    zeigt ihn schon). Rückgabe: Zeilen.
    """
    z = []
    a = z.append
    ab = S.get("abruf")
    if ab:
        a(f"  Abruf vom {_uhr(ab['ts'])} ({'zur festen Zeit' if ab['art'] == 'plan' else 'Erstabruf außer der Reihe'}) · HTTP {ab['status']} · "
          f"{OP.groesse_txt(ab['bytes'] or 0)} · {OP.de(ab['dauer'] or 0.0, 1)} s · {ab['kontrakte']} Kontrakte · {ab['verfalltage']} Verfalltage · "
          f"New-York-Tag {_iso_txt(ab['tag'])}")
    h = S.get("heute")
    if h and h.get("fehler"):
        a(f"  Heute (New-York-Tag {_iso_txt(h['tag'])}): {h['versuche']} {'Versuch' if h['versuche'] == 1 else 'Versuche'}, zuletzt {_uhr(h['letzter_versuch'])} -- {h['fehler']}")
    if S.get("naechster"):
        a(f"  Nächster Abruf: ab {_uhr(S['naechster'])} (täglich 15:45 Uhr New York; nach einem Fehlschlag frühestens nach 10 Minuten)")
    if S.get("grund"):
        a(f"  {S['grund']}")
    Z = S.get("zeilen") or []
    if not Z:
        if lesart:
            a(f"  Lesart: {LESART}")
        return _umbrochen(z)
    a("")
    a("  Ränder aus den Preisen (O5), je Verfalltag; „—“ = außerhalb der Strikes oder nicht brauchbar. * = Zeichen im Chart.")
    a("    Verfall       Tage  Terminkurs    10 %     25 %    Mitte     75 %     90 %   Strikes  Spanne  Schwankung  Stufe")
    for d in Z:
        q = d["q"]
        a(f"  {'*' if d.get('zeichen') else ' '} {_iso_txt(d['verfall'])} {OP.de(d['tage'], 0):>5}  {_usd(d['termin']):>10}  "
          + "  ".join(f"{_usd(q[str(r)]):>7}" for r in RAENDER)
          + f"  {d['unter'] if d['unter'] is not None else '—':>3}+{d['ueber'] if d['ueber'] is not None else '—':<3}  "
          + f"{OP.pz(d['spanne']) if d['spanne'] is not None else '—':>6}  {(OP.de(d['iv'], 1) + ' %') if d['iv'] is not None else '—':>9}   "
          + STUFE_TXT.get(d["stufe"], d["stufe"]) + (f" · {d['glatt']} zusammengelegt" if d.get("glatt") else ""))
        if d.get("grund"):
            a(f"        Grund: {d['grund']}")
    a("")
    a("  Gegenprobe (O5.5): dieselben Ränder aus der Schwankung am Geld, als wäre der Kurs in ln normalverteilt -- weicht ab, wo die")
    a("  Schwankung über die Strikes schief ist. Und der Terminkurs aus der Parität gegen das Feld der Börse (O3).")
    a("    Verfall        10 %     25 %    Mitte     75 %     90 %    Terminkurs: Parität · Feld · Abweichung")
    for d in Z:
        g = d.get("gegen") or {}
        abw = d["termin"] / d["feld"] - 1.0 if d.get("termin_art") == "paritaet" and d.get("feld") and d.get("termin") else None
        a(f"    {_iso_txt(d['verfall'])}  " + "  ".join(f"{_usd(g.get(str(r))):>7}" for r in RAENDER)
          + f"    {_usd(d['termin']) if d.get('termin_art') == 'paritaet' else '—':>8} · {_usd(d['feld']):>7} · "
          + (("+" if abw >= 0 else "−") + OP.de(abs(abw) * 100, 2) + " %" if abw is not None else "—")
          + ("  <-- über 1 %" if abw is not None and abs(abw) > ABW_MELDEN else ""))
    z.extend(diagnose_text(Z))
    if faecher:
        a("")
        a("  Zum Vergleich der Fächer am selben Tag (10-%-Rand · Mitte · 90-%-Rand; er beginnt beim letzten Tagesschluss, die Optionen")
        a("  beim Terminkurs zur Abrufzeit):")
        for d in Z:
            f = faecher.get(d["verfall"])
            if f:
                a(f"    {_iso_txt(d['verfall'])}  Fächer {_usd(f.get('10'))} · {_usd(f.get('50'))} · {_usd(f.get('90'))}   "
                  f"Optionen {_usd(d['q']['10'])} · {_usd(d['q']['50'])} · {_usd(d['q']['90'])}")
    if lesart:
        a("")
        a(f"  Lesart: {LESART}")
    return _umbrochen(z)


def pruefen(http_fn=None, jetzt: float | None = None) -> list:
    """
    O10 (Debug 158): EIN Aufruf bei Deribit, dieselbe Rechnung wie der Tagesabruf (O2 bis O5, O9), dazu je brauchbarem Verfalltag
    ab 28 Tagen die Paare im Bereich der Ränder. Öffnet keine Datenbank und speichert nichts. Wirft nie. Rückgabe: Zeilen.
    """
    jetzt = time.time() if jetzt is None else float(jetzt)
    z = []
    a = z.append
    try:
        ab, gelesen, V, fehler = holen(http_fn, jetzt)
        a(f"  Abruf {_uhr(jetzt)} · {OP.abruf_txt(ab)}" + ("" if gelesen is None else f" · {len(gelesen['kontrakte'])} Kontrakte · {len(V)} Verfalltage"))
        if fehler:
            a(f"  Kein Ergebnis: {fehler}")
            a("  Gespeichert wurde nichts; der Tagesabruf (täglich 15:45 Uhr New York) ist davon unberührt.")
            return _umbrochen(z)
        zeilen = []
        for v in V:
            d = {"verfall": v["verfall"], "tage": v["tage"], "termin": v["termin"], "termin_art": v["termin_art"], "feld": v["feld"],
                 "iv": v["iv"], "q": {str(r): v["q"][r] for r in RAENDER}, "unter": v["unter"], "ueber": v["ueber"], "spanne": v["spanne"],
                 "stufe": v["stufe"], "grund": v["grund"], "glatt": v["glatt"], "strikes": v["strikes"], "diag": v.get("diag")}
            d["gegen"] = {str(r): x for r, x in gegenprobe(d["termin"], d["iv"], d["tage"]).items()}
            d["zeichen"] = zeichen(d)
            d["pruefen"] = pruef_gruende(d)
            zeilen.append(d)
        z.extend(stand_text({"abruf": None, "heute": None, "naechster": None, "grund": None, "zeilen": zeilen}, None, lesart=False))
        G = nach_verfall(gelesen["kontrakte"], jetzt)
        gezeigt = [(v, d) for v, d in zip(V, zeilen) if d["zeichen"]]
        a("")
        if not gezeigt:
            a(f"  Paare: kein brauchbarer Verfalltag ab {MIN_TAGE_CHART} Tagen mit Mitte und inneren Rändern.")
        else:
            a(f"  Paare im Bereich der Ränder (O10), je brauchbarem Verfalltag ab {MIN_TAGE_CHART} Tagen -- je Paar benachbarter Strikes die")
            a("  Wahrscheinlichkeit, dass der Kurs am Verfalltag über der Mitte des Paars liegt: aus den Kursen (O5.2), nach dem Zusammenlegen")
            a("  (O5.3) und aus den Schwankungen der Börse (O9.3). Ein Paar davor und eines danach stehen mit da.")
        for v, d in gezeigt:
            calls, puts = seiten(G[v["verfall_ts"]])
            reihe = call_reihe(calls, puts, v["termin"])
            roh = [min(1.0, max(0.0, (c1 - c2) / (k2 - k1))) for (k1, c1), (k2, c2) in zip(reihe, reihe[1:])]
            mitten, s, _ = ueber_wkt(reihe)
            S = strecken(reihe, mitten)
            mr = dict(mark_reihe(calls, puts, v["termin"], v["tage"]))
            da = [x for x in v["q"].values() if x is not None]
            lo, hi = min(da), max(da)
            im = [i for i in range(len(roh)) if reihe[i + 1][0] >= lo and reihe[i][0] <= hi]
            a("")
            a(f"  {_iso_txt(v['verfall'])} ({OP.de(v['tage'], 0)} Tage) · Terminkurs {_usd(v['termin'])} · Ränder "
              + " · ".join(_usd(v["q"][r]) for r in RAENDER))
            a("      Strike-Paar              aus den Kursen   nach dem Zusammenlegen   aus der Schwankung der Börse")
            for i in range(max(0, im[0] - 1), min(len(roh) - 1, im[-1] + 1) + 1) if im else []:
                k1, k2 = reihe[i][0], reihe[i + 1][0]
                j = next(n for n, (u, o, _p) in enumerate(S) if u <= k1 and k2 <= o)
                sm = (mr[k1] - mr[k2]) / (k2 - k1) if k1 in mr and k2 in mr else None
                a(f"      {_usd(k1):>8} – {_usd(k2):<8}      {_wkt(roh[i]):>8}            {_wkt(s[j]):>8}{'  *' if S[j][2] > 1 else '   '}                 {_wkt(sm):>8}")
            if any(S[j][2] > 1 for j in range(len(S))):
                a("      * = Teil eines zusammengelegten Paars (alle seine Paare tragen denselben Wert)")
        a("")
        a("  Gespeichert wurde nichts; der Tagesabruf (täglich 15:45 Uhr New York) ist davon unberührt.")
        a(f"  Lesart: {LESART}")
    except Exception as e:                                                 # ein Prüflauf bricht nie mit einer Ausnahme ab
        a(f"  Prüflauf abgebrochen: {type(e).__name__}: {OP.sauber(e, 160)}")
    return _umbrochen(z)


def _umbrochen(zeilen: list, breite: int = 150) -> list:
    """Zeilen über der Breite umbrechen (Folgezeilen eingerückt) -- der Bericht bleibt ohne Rollen lesbar."""
    out = []
    for x in zeilen:
        if len(x) <= breite:
            out.append(x)
        else:
            out.extend(textwrap.wrap(x, width=breite, subsequent_indent="        ", break_long_words=False, break_on_hyphens=False))
    return out


def _iso_txt(s) -> str:
    try:
        d = date.fromisoformat(str(s))
        return f"{d.day:02d}.{d.month:02d}.{d.year}"
    except ValueError:
        return str(s)


# ================================================================================================ Teil 2a: Prognosemärkte (nur lesen)
# 23.120 (U280 Teil 2a, KONZEPT_Langfrist.md 9.4): Was die Prognosemärkte für den 24-Monats-Chart hergeben -- als Text (Debug 159).
# Gelesen wird nur prognosemarkt.db (hl_prognosemarkt.py sammelt sie); kein Abruf, nichts wird gespeichert, nichts geht in den Fächer.
# Im Chart steht davon noch nichts: Die Regeln für die Punkte (9.4, P-Regeln) werden nach dem ersten Bericht vom Pi festgelegt.

DEBUG_NR_PM = 159
PM_KALSHI_BTC = ("KXBTCY", "KXBTCMAXY", "KXBTCMINY", "KXBTCMAX150", "KXBTCPRICE")      # Jahresendkurs, Jahreshoch, Jahrestief, Fristen
PM_POLY_BTC = ("PMberuehrung", "PMschwelle", "PMfrist")                                # Berührleitern, Schwellen, Fristen-Leiter
PM_FED = ("KXFED",)                                                                    # Obergrenze des Zielbands je Sitzung
PM_FED_EREIGNIS = ("KXFEDDECISION", "KXRATECUTCOUNT", "KXRECSSNBER")
PM_POLY_MAKRO = ("PMmakro",)
PM_MIN_TAGE = 7                       # Bestand: Fristen ab 7 Tagen (darunter liegen die Stunden- und Tagesleitern)
PM_FRISCH_S = 3 * 3600                # ein Kurs gilt als frisch, wenn sein letzter Abruf höchstens 3 Stunden zurückliegt
PM_FED_SCHRITT = 0.25                 # Raster des Leitzinses in Prozentpunkten
PM_SPRUNG = 0.02                      # Hinweis, wenn eine Leiter um mehr als 2 Punkte gegen ihre Ordnung läuft
PM_RAND_OFFEN = 0.05                  # Hinweis, wenn unter oder über einer Zins-Leiter mehr als 5 % liegen
PM_LESART = ("Kurse von Prognosemärkten sind Preise von Wetten (mit Gebühren, Spannen und der Vorliebe für Außenseiter), keine "
             "Prognose des Systems. „rekal.“ streckt den Rohwert nach KONZEPT_Prognosemaerkte.md, Regel 1.6 (Steigung 1,09 bei 7 bis 30 "
             "Tagen, 1,36 darüber); der Rohwert steht immer daneben. Die Schicht geht nicht in den Fächer ein.")
PM_ART_TXT = {("beruehrung", "ueber"): "berührt nach oben", ("beruehrung", "unter"): "berührt nach unten",
              ("schwelle", "ueber"): "Schluss darüber", ("schwelle", "unter"): "Schluss darunter"}
PM_FORM_TXT = {"schwellen": "Schwellen", "fristen": "Fristen", "spannen": "Spannen", "gemischt": "gemischt"}


def _pm():
    import hl_prognosemarkt as PM          # erst hier: die Optionen-Schicht braucht das Modul nicht
    return PM


def _et_tag(ts) -> str:
    """Kalendertag in New York -- die Börsen nennen ihre Fristen in New Yorker Zeit."""
    if ts is None:
        return "—"
    t = _pm().et(ts)
    return f"{t.day:02d}.{t.month:02d}.{t.year}"


def _frist_txt(ende) -> str:
    """Frist als letzter Tag in New York: eine Frist um 00:00 Uhr des Folgetags heißt „bis Ende des Vortags“."""
    return _et_tag(ende - 1) if ende is not None else "—"


def _alter_txt(s) -> str:
    if s is None:
        return "—"
    if s < 5400:
        return f"{max(0, int(round(s / 60.0)))} min"
    if s < 2 * TAG:
        return OP.de(s / 3600.0, 1) + " h"
    return OP.de(s / TAG, 1) + " Tage"


def _pkt(x) -> str:
    """Kurs in Punkten (Cent je Dollar): 0,53 -> 53,0."""
    return "—" if x is None else OP.de(x * 100.0, 1)


def _niv_txt(x) -> str:
    return "—" if x is None else OP.strike_txt(x)


def _satz(x) -> str:
    return "—" if x is None else OP.de(x, 2) + " %"


def pm_kurs(con, plattform: str, markt: str, jetzt: float) -> dict | None:
    """Jüngster Live-Kurs eines Markts -- auch ein alter, das Alter steht dabei. Wahrscheinlichkeit aus der Mitte von Geld und Brief
    (beide Seiten da, Spread höchstens 4 Punkte -- hl_prognosemarkt.mitte), sonst aus dem letzten Handel."""
    r = con.execute("SELECT ts, geld, brief, letzter, bis FROM pm_kurs WHERE plattform=? AND markt=? AND quelle='live' AND ts<=? "
                    "ORDER BY ts DESC LIMIT 1", (plattform, markt, int(jetzt))).fetchone()
    if not r:
        return None
    m = _pm().mitte(r[1], r[2])
    p = m / 10000.0 if m is not None else (r[3] / 10000.0 if r[3] is not None else None)
    bis = min(int(r[4] or r[0]), int(jetzt))            # bei einem Stand in der Vergangenheit (Proben) nie später als dieser Stand
    return {"p": p, "aus": "Mitte" if m is not None else ("Handel" if r[3] is not None else None),
            "geld": None if r[1] is None else r[1] / 10000.0, "brief": None if r[2] is None else r[2] / 10000.0,
            "letzter": None if r[3] is None else r[3] / 10000.0,
            "spread": (r[2] - r[1]) / 10000.0 if r[1] is not None and r[2] is not None else None,
            "ts": int(r[0]), "bis": bis, "alter_s": int(jetzt) - bis}


PM_SPALTEN = ("markt", "ereignis", "reihe", "titel", "art", "basis", "strike_typ", "unten", "oben", "ende", "ablauf", "regeln", "slug",
              "erstmals", "zuletzt")
PM_ABFRAGE = ("SELECT " + ", ".join(PM_SPALTEN) + " FROM pm_markt WHERE plattform=? AND reihe=? AND ende>? ORDER BY ende, markt")


def pm_maerkte(con, plattform: str, reihen: tuple, ab_ts: float, basis: str | None = "BTC") -> list:
    """Märkte der genannten Reihen mit Frist nach ab_ts (über den Index plattform, reihe, ende -- die Tabelle hat Hunderttausende
    Zeilen), je Markt mit dem Ergebnis, falls er schon entschieden ist."""
    out = []
    for reihe in reihen:
        for z in con.execute(PM_ABFRAGE, (plattform, reihe, int(ab_ts))).fetchall():
            d = dict(zip(PM_SPALTEN, z))
            if basis and d["basis"] != basis:
                continue
            d["plattform"] = plattform
            e = con.execute("SELECT ergebnis FROM pm_ergebnis WHERE plattform=? AND markt=? ORDER BY fassung DESC LIMIT 1",
                            (plattform, d["markt"])).fetchone()
            d["ergebnis"] = e[0] if e else None
            out.append(d)
    return out


def pm_niveau(m: dict) -> tuple:
    """(Richtung, Niveau) eines Schwellen- oder Berührungsmarkts: „ueber“ mit der unteren Grenze, „unter“ mit der oberen."""
    st = (m.get("strike_typ") or "").lower()
    if st.startswith("less"):
        k = m.get("oben") if m.get("oben") is not None else m.get("unten")
        return ("unter", float(k)) if k is not None else (None, None)
    if m.get("unten") is not None:
        return "ueber", float(m["unten"])
    if m.get("oben") is not None:
        return "unter", float(m["oben"])
    return None, None


def pm_zeile(con, m: dict, jetzt: float) -> dict:
    """Ein Markt mit Kurs: roh, rekalibriert (Regel 1.6, mit der Frist DIESES Markts), frisch oder nicht, entschieden, noch gelistet."""
    k = pm_kurs(con, m["plattform"], m["markt"], jetzt)
    richtung, niveau = pm_niveau(m)
    rest = float(m["ende"]) - jetzt
    p = k["p"] if k else None
    z = dict(m)
    z.update(richtung=richtung, niveau=niveau, tage=rest / TAG, kurs=k, p=p, aus=k["aus"] if k else None,
             spread=k["spread"] if k else None, alter_s=k["alter_s"] if k else None,
             frisch=bool(k) and p is not None and k["alter_s"] <= PM_FRISCH_S and m.get("ergebnis") is None,
             p_rekal=_pm().rekalibriert(p, rest) if p is not None else None,
             gelistet=m.get("zuletzt") is not None and jetzt - float(m["zuletzt"]) <= PM_FRISCH_S)
    return z


def pm_gruppen(zeilen: list) -> list:
    """Märkte je (Börse, Ereignis) gruppieren und die Form bestimmen: „spannen“ (Kurs am Stichtag in Spannen), „fristen“ (ein Niveau,
    mehrere Fristen), „schwellen“ (eine Frist, ein oder mehrere Niveaus) oder „gemischt“ (mehrere Niveaus UND mehrere Fristen)."""
    je: dict = {}
    for z in zeilen:
        je.setdefault((z["plattform"], z["ereignis"] or z["markt"]), []).append(z)
    out = []
    for (plattform, ereignis), zl in je.items():
        fristen = sorted({int(z["ende"]) for z in zl})
        niveaus = sorted({(z["richtung"], z["niveau"]) for z in zl if z["niveau"] is not None}, key=lambda x: (x[1], str(x[0])))
        if all(z["art"] == "spanne" for z in zl):
            form = "spannen"
        elif len(niveaus) <= 1 and len(fristen) > 1:
            form = "fristen"
        elif len(fristen) == 1:
            form = "schwellen"
        else:
            form = "gemischt"
        zl = sorted(zl, key=lambda z: (int(z["ende"]), z["niveau"] if z["niveau"] is not None else (z["unten"] if z["unten"] is not None else -1.0)))
        regel = next((" ".join(str(z["regeln"]).split()) for z in zl if z.get("regeln")), "")
        out.append({"plattform": plattform, "ereignis": ereignis, "reihe": zl[0]["reihe"], "art": zl[0]["art"], "form": form, "zeilen": zl,
                    "fristen": fristen, "niveaus": niveaus, "regel": regel, "titel": next((z["titel"] for z in zl if z.get("titel")), ""),
                    "frisch": sum(1 for z in zl if z["frisch"]), "entschieden": sum(1 for z in zl if z["ergebnis"] is not None)})
    return sorted(out, key=lambda g: (g["fristen"][0], g["plattform"], g["ereignis"]))


def pm_ordnung(g: dict) -> list:
    """Läuft eine Leiter gegen ihre Ordnung? Schwellen: Je weiter das Niveau vom Kurs weg liegt, desto kleiner muss die
    Wahrscheinlichkeit sein (nach oben fallend mit dem Niveau, nach unten steigend). Fristen: Eine spätere Frist kann nicht
    unwahrscheinlicher sein als eine frühere. Gemeldet wird ab mehr als 2 Punkten, nur für frische Kurse."""
    out = []
    fr = [z for z in g["zeilen"] if z["frisch"]]
    if g["form"] == "fristen":
        for a, b in zip(fr, fr[1:]):
            if b["p"] < a["p"] - PM_SPRUNG:
                out.append(f"{g['ereignis']}: Frist {_frist_txt(b['ende'])} steht mit {_wkt(b['p'])} unter der früheren Frist "
                           f"{_frist_txt(a['ende'])} mit {_wkt(a['p'])}")
    elif g["form"] == "schwellen" and g["art"] != "spanne":
        for richtung in ("ueber", "unter"):
            zl = sorted((z for z in fr if z["richtung"] == richtung), key=lambda z: z["niveau"])
            for a, b in zip(zl, zl[1:]):
                falsch = b["p"] > a["p"] + PM_SPRUNG if richtung == "ueber" else b["p"] < a["p"] - PM_SPRUNG
                if falsch:
                    out.append(f"{g['ereignis']}: Niveau {_niv_txt(b['niveau'])} steht mit {_wkt(b['p'])} gegen die Ordnung neben "
                               f"{_niv_txt(a['niveau'])} mit {_wkt(a['p'])}")
    return out


def _quantil(punkte: list, q: float):
    """Kurs, über dem noch 1 − q der Wahrscheinlichkeit liegt: gerade zwischen zwei Grenzen, außerhalb der Grenzen keiner."""
    ziel = 1.0 - q
    for (k0, s0), (k1, s1) in zip(punkte, punkte[1:]):
        if s0 + EPS >= ziel >= s1 - EPS:           # mit Spielraum: 1 − 0,9 ist als Gleitkommazahl knapp kleiner als 0,1
            return k0 if s0 - s1 < EPS else min(k1, max(k0, k0 + (s0 - ziel) / (s0 - s1) * (k1 - k0)))
    return None


def pm_spannen(zeilen: list, rest_s: float) -> dict | None:
    """Kurs am Stichtag aus Spannen: je Spanne die Wahrscheinlichkeit (frischer Kurs, sonst 0), auf Summe 1 gebracht; daraus je
    Spannengrenze die Wahrscheinlichkeit darüber und die Ränder 10/25/50/75/90 %. Rekalibriert: Regel 1.6 auf die Wahrscheinlichkeit
    „über der Grenze“ angewandt -- eine eigene Übertragung auf Spannen, im Bericht so benannt."""
    sp = []
    for z in zeilen:
        st = (z.get("strike_typ") or "").lower()
        unten = None if st.startswith("less") else z.get("unten")
        if unten is None and z.get("oben") is None:
            continue
        sp.append({"unten": None if unten is None else float(unten), "oben": None if z.get("oben") is None else float(z["oben"]),
                   "p": float(z["p"]) if z["frisch"] else 0.0, "frisch": z["frisch"]})
    summe = sum(s["p"] for s in sp)
    if len(sp) < 3 or summe <= 0:
        return None
    grenzen = sorted({s["unten"] for s in sp if s["unten"] is not None})
    punkte = [(k, sum(s["p"] for s in sp if s["unten"] is not None and s["unten"] >= k) / summe) for k in grenzen]
    rek = _pm().rekalibriert
    punkte_r = [(k, s if rek(s, rest_s) is None else rek(s, rest_s)) for k, s in punkte]
    beste = max(sp, key=lambda s: s["p"])
    return {"n": len(sp), "ohne_kurs": sum(1 for s in sp if not s["frisch"]), "summe": summe, "punkte": punkte, "punkte_rekal": punkte_r,
            "q": {r: _quantil(punkte, r / 100.0) for r in RAENDER}, "q_rekal": {r: _quantil(punkte_r, r / 100.0) for r in RAENDER},
            "beste": (beste["unten"], beste["oben"], beste["p"] / summe)}


def pm_stufen(punkte: list, schritt: float = PM_FED_SCHRITT) -> dict | None:
    """Zins-Leiter -> Verteilung auf dem Raster. punkte: [(Grenze, P(Satz > Grenze))], die Grenzen liegen mitten zwischen zwei
    Rasterwerten (hl_prognosemarkt._leiter_punkt). Die Wahrscheinlichkeiten werden fallend geglättet (isotone Regression). Masse
    unter der untersten Grenze zählt am Rasterwert darunter, über der obersten am Rasterwert darüber; fehlt dazwischen eine
    Schwelle, zählt die Masse in der Mitte der Lücke (im Bericht als Lücke gezählt)."""
    je: dict = {}
    for g, s in punkte:
        je.setdefault(round(float(g), 6), []).append(min(1.0, max(0.0, float(s))))
    gr = sorted(je)
    if len(gr) < 2:
        return None
    s = _pm()._pava_fallend([sum(je[g]) / len(je[g]) for g in gr])
    werte = [(gr[0] - schritt / 2.0, 1.0 - s[0])]
    luecken = 0
    for i in range(len(gr) - 1):
        n = int(round((gr[i + 1] - gr[i]) / schritt))
        if n <= 1:
            werte.append((gr[i] + schritt / 2.0, s[i] - s[i + 1]))
        else:
            luecken += 1
            werte.append(((gr[i] + gr[i + 1]) / 2.0, s[i] - s[i + 1]))
    werte.append((gr[-1] + schritt / 2.0, s[-1]))
    i_h = max(range(len(werte)), key=lambda i: werte[i][1])
    return {"n": len(gr), "grenzen": list(zip(gr, s)), "werte": werte, "mittel": sum(w * m for w, m in werte), "haeufig": werte[i_h],
            "haeufig_rand": "unter" if i_h == 0 else ("ueber" if i_h == len(werte) - 1 else None),
            "unter": 1.0 - s[0], "ueber": s[-1], "luecken": luecken}


def pm_fed(con, jetzt: float) -> dict:
    """Fed-Pfad aus Kalshi KXFED: je offener Sitzung die Verteilung der Obergrenze des Zielbands (pm_stufen); dazu der Satz nach der
    zuletzt abgerechneten Sitzung (Wert der Börse), wenn er gespeichert ist."""
    PM = _pm()
    letzt = con.execute("SELECT m.ereignis, m.ende, e.wert FROM pm_markt m JOIN pm_ergebnis e ON e.plattform=m.plattform AND "
                        "e.markt=m.markt WHERE m.plattform='kalshi' AND m.reihe='KXFED' AND m.ende<=? AND e.wert IS NOT NULL "
                        "ORDER BY m.ende DESC LIMIT 1", (int(jetzt),)).fetchone()
    heute = {"ereignis": letzt[0], "ende": int(letzt[1]), "satz": float(letzt[2])} if letzt else None
    je: dict = {}
    for m in pm_maerkte(con, "kalshi", PM_FED, jetzt, basis=None):
        je.setdefault(m["ereignis"] or m["markt"], []).append(pm_zeile(con, m, jetzt))
    sitzungen = []
    for ereignis, zl in je.items():
        punkte = []
        for z in zl:
            if z["frisch"]:
                pkt = PM._leiter_punkt(z["strike_typ"], z["unten"], z["oben"], z["p"], PM_FED_SCHRITT)
                if pkt:
                    punkte.append(pkt)
        v = pm_stufen(punkte)
        spr = [z["spread"] for z in zl if z["frisch"] and z["spread"] is not None]
        alt = [z["alter_s"] for z in zl if z["frisch"]]
        sitzungen.append({"ereignis": ereignis, "ende": min(int(z["ende"]) for z in zl), "maerkte": len(zl), "frisch": len(punkte),
                          "v": v, "spread": sum(spr) / len(spr) if spr else None, "alter_s": max(alt) if alt else None,
                          "gegen_heute": v["mittel"] - heute["satz"] if v and heute else None})
    return {"heute": heute, "sitzungen": sorted(sitzungen, key=lambda x: (x["ende"], x["ereignis"]))}


def pm_ereignisse(con, plattform: str, reihen: tuple, jetzt: float, wort: str | None = None, hoechstens: int = 12) -> list:
    """Ja/Nein-Märkte je Ereignis (Entscheid der Fed, Zahl der Senkungen, Rezession): Kennung, Titel, Kurs -- nur als Liste."""
    je: dict = {}
    for m in pm_maerkte(con, plattform, reihen, jetzt, basis=None):
        if wort and wort not in ((m.get("titel") or "") + " " + (m.get("ereignis") or "") + " " + (m.get("slug") or "")).lower():
            continue
        je.setdefault(m["ereignis"] or m["markt"], []).append(pm_zeile(con, m, jetzt))
    out = []
    for ereignis, zl in je.items():
        zl = sorted(zl, key=lambda z: -(z["p"] if z["p"] is not None and z["frisch"] else -1.0))
        out.append({"plattform": plattform, "ereignis": ereignis, "reihe": zl[0]["reihe"], "ende": min(int(z["ende"]) for z in zl),
                    "zeilen": zl, "frisch": sum(1 for z in zl if z["frisch"])})
    return sorted(out, key=lambda e: (e["ende"], e["ereignis"]))[:hoechstens]


def pm_bestand(pfad: str, jetzt: float | None = None) -> dict:
    """Was die Prognosemärkte für den 24-Monats-Chart hergeben (nur lesen): BTC-Leitern mit Frist ab 7 Tagen, der Kurs am Stichtag
    aus Spannen, der Fed-Pfad und die Ereignisse dazu. {'ok': False, 'grund': …}, wenn die Datei fehlt oder nicht lesbar ist."""
    PM = _pm()
    jetzt = float(jetzt if jetzt is not None else time.time())
    con = PM.lesen(pfad)
    if con is None:
        return {"ok": False, "jetzt": jetzt, "grund": f"prognosemarkt.db fehlt ({pfad}) -- der Takt der Prognosemärkte hat hier noch nichts gespeichert"}
    try:
        ab = jetzt + PM_MIN_TAGE * TAG
        zeilen = [pm_zeile(con, m, jetzt) for m in pm_maerkte(con, "kalshi", PM_KALSHI_BTC, ab) + pm_maerkte(con, "polymarket", PM_POLY_BTC, ab)]
        gruppen = pm_gruppen(zeilen)
        for g in gruppen:
            g["hinweise"] = pm_ordnung(g)
            g["spannen"] = pm_spannen(g["zeilen"], g["fristen"][0] - jetzt) if g["form"] == "spannen" else None
        fed = pm_fed(con, jetzt)
        frische: dict = {}                    # jüngster Kurs je Börse unter den gelesenen Märkten (kein Durchlauf der großen Tabelle)
        for x in zeilen:
            if x["kurs"]:
                frische[x["plattform"]] = max(frische.get(x["plattform"], 0), x["kurs"]["bis"])
        return {"ok": True, "jetzt": jetzt, "pfad": pfad, "gruppen": gruppen, "fed": fed,
                "ereignisse": pm_ereignisse(con, "kalshi", PM_FED_EREIGNIS, jetzt),
                "poly_fed": pm_ereignisse(con, "polymarket", PM_POLY_MAKRO, jetzt, wort="fed", hoechstens=8),
                "frische": frische, "spot": PM._spot_jetzt(con, "BTC", int(jetzt))}
    except sqlite3.Error as e:
        return {"ok": False, "jetzt": jetzt, "grund": f"prognosemarkt.db nicht lesbar ({type(e).__name__}: {e})"}
    finally:
        con.close()


PM_BOERSE = {"kalshi": "Kalshi", "polymarket": "Polymarket"}


def _pm_kopfzeile(g: dict) -> str:
    return f"{PM_BOERSE.get(g['plattform'], g['plattform'])} {g['ereignis']}"


def _pm_kopf(erste: str) -> str:
    """Spaltenkopf zu _pm_zeile_txt; „erste“ ist die erste Spaltengruppe (34 Zeichen)."""
    return f"    {erste}  {'roh':>7}  {'rekal.':>7}   {'Geld · Brief':<13}  {'woraus':<7} {'Alter':>9}   Hinweis"


def _pm_zeile_txt(z: dict, erste: str) -> str:
    k = z["kurs"] or {}
    hin = []
    if z["ergebnis"] is not None:
        hin.append("entschieden: " + ("Ja" if z["ergebnis"] == 1 else "Nein"))
    elif z["kurs"] is None:
        hin.append("kein Kurs gespeichert")
    elif z["p"] is None:
        hin.append("kein Kurs lesbar (keine Mitte, kein Handel)")
    elif not z["frisch"]:
        hin.append("Kurs alt" + ("" if z["gelistet"] else " -- der Markt ist nicht mehr gelistet"))
    if z["niveau"] is None and z["art"] != "spanne":
        hin.append("Niveau fehlt")
    return (f"    {erste}  {_wkt(z['p']):>7}  {_wkt(z['p_rekal']):>7}   {_pkt(k.get('geld')):>5} · {_pkt(k.get('brief')):<5}  "
            f"{(z['aus'] or '—'):<7} {_alter_txt(z['alter_s']):>9}   {'; '.join(hin)}").rstrip()


def pm_text(B: dict) -> list:
    """Der Bestand als Text (Debug 159)."""
    z = []
    a = z.append
    if not B.get("ok"):
        a(f"  Kein Ergebnis: {B.get('grund')}")
        return z
    jetzt = B["jetzt"]
    fr = B.get("frische") or {}
    sp = B.get("spot")
    a("  Stand: jüngster Kurs der gelesenen BTC-Märkte -- Kalshi " + _uhr(fr.get("kalshi")) + " · Polymarket "
      + _uhr(fr.get("polymarket")) + " · Spot " + (f"{_usd(sp['kurs'])} USD ({sp['quelle']}, {_uhr(sp['ts'])[-5:]} Uhr)" if sp else "—"))
    G = B["gruppen"]
    a("")
    a(f"1 BESTAND: BTC-Märkte mit Frist ab {PM_MIN_TAGE} Tagen (Fristen als letzter Tag in New York; „frisch“ = Kurs höchstens "
      f"{PM_FRISCH_S // 3600} h alt und nicht entschieden)")
    if not G:
        a("    keine -- in prognosemarkt.db steht kein offener BTC-Markt der Jahres- und Fristen-Leitern mit so langer Frist")
    else:
        a(f"    {'Börse':<11}{'Ereignis':<44}{'Form':<11}{'Märkte':>6}  {'frisch':>6}  {'entschieden':>11}   {'Fristen':<23}  Niveaus")
        for g in G:
            f0, f1 = _frist_txt(g["fristen"][0]), _frist_txt(g["fristen"][-1])
            nv = [n for _, n in g["niveaus"]]
            a(f"    {PM_BOERSE.get(g['plattform'], g['plattform']):<11}{str(g['ereignis'])[:42]:<44}"
              f"{PM_FORM_TXT[g['form']]:<11}{len(g['zeilen']):>6}  {g['frisch']:>6}  {g['entschieden']:>11}   "
              f"{(f0 if f0 == f1 else f0 + '–' + f1):<23}  "
              + ("—" if not nv else (_niv_txt(nv[0]) if len(nv) == 1 else _niv_txt(nv[0]) + "–" + _niv_txt(nv[-1]))))

    def regel(g):
        x0 = g["zeilen"][0]                  # ein Beispiel je Ereignis: an Kennung und Titel lässt sich prüfen, ob Niveau und Frist stimmen
        kenn = x0["markt"] if g["plattform"] == "kalshi" else (x0.get("slug") or x0["markt"])
        a("    Erster Markt: Kennung " + str(kenn)[:70] + " · Titel „" + " ".join(str(x0.get("titel") or "").split())[:110] + "“")
        if g["reihe"] == "PMfrist":
            tage = sorted({_frist_txt(x["ablauf"]) for x in g["zeilen"] if x.get("ablauf") is not None})
            wie_frist = bool(tage) and all(x.get("ablauf") is not None and abs(x["ablauf"] - x["ende"]) <= 2 * TAG for x in g["zeilen"])
            a("    Handelsende laut Börse (Feld endDate): " + ("nicht gespeichert" if not tage else ("je Markt wie die Frist" if wie_frist else
              ("für alle " + tage[0] if len(tage) == 1 else ", ".join(tage)))) + " -- die Frist oben stammt aus dem Gruppentitel")
        if g["regel"]:
            a("    Regel der Börse (Anfang): „" + g["regel"][:320] + ("…" if len(g["regel"]) > 320 else "") + "“")

    a("")
    a("2 SCHWELLEN-LEITERN (eine Frist, ein oder mehrere Niveaus)")
    sch = [g for g in G if g["form"] in ("schwellen", "gemischt")]
    if not sch:
        a("    keine")
    for g in sch:
        a(f"  {_pm_kopfzeile(g)} · Frist {_frist_txt(g['fristen'][0])}"
          + (f" bis {_frist_txt(g['fristen'][-1])}" if len(g["fristen"]) > 1 else f" (in {OP.de((g['fristen'][0] - jetzt) / TAG, 0)} Tagen)")
          + f" · {len(g['zeilen'])} " + ("Markt" if len(g["zeilen"]) == 1 else "Märkte"))
        a(_pm_kopf(f"{'Niveau':>10}  {'Art':<22}"))
        for x in g["zeilen"]:
            art = PM_ART_TXT.get((x["art"], x["richtung"]), {"beruehrung": "Berührung", "schwelle": "Schwelle"}.get(x["art"], x["art"] or "—"))
            erste = f"{_niv_txt(x['niveau']):>10}  {art:<22}"
            if g["form"] == "gemischt":
                erste = f"{_niv_txt(x['niveau']):>10}  {(art + ' bis ' + _frist_txt(x['ende']))[:22]:<22}"
            a(_pm_zeile_txt(x, erste))
        regel(g)
    a("")
    a("3 FRISTEN-LEITERN (ein Niveau, mehrere Fristen)")
    fri = [g for g in G if g["form"] == "fristen"]
    if not fri:
        a("    keine")
    for g in fri:
        x0 = g["zeilen"][0]
        a(f"  {_pm_kopfzeile(g)} · Niveau {_niv_txt(x0['niveau'])} · {PM_ART_TXT.get((x0['art'], x0['richtung']), x0['art'] or '—')}"
          f" · {len(g['zeilen'])} Fristen")
        a(_pm_kopf(f"{'Frist':>10}  {'in Tagen':>8}{'':<14}"))
        for x in g["zeilen"]:
            a(_pm_zeile_txt(x, f"{_frist_txt(x['ende']):>10}  {OP.de(x['tage'], 0):>8}{'':<14}"))
        regel(g)
    a("")
    a("4 KURS AM STICHTAG AUS SPANNEN")
    spg = [g for g in G if g["form"] == "spannen"]
    if not spg:
        a("    keine")
    for g in spg:
        s = g["spannen"]
        a(f"  {_pm_kopfzeile(g)} · Frist {_frist_txt(g['fristen'][0])} (in {OP.de((g['fristen'][0] - jetzt) / TAG, 0)} Tagen) · "
          f"{len(g['zeilen'])} Spannen")
        if not s:
            a("    keine Verteilung: weniger als drei Spannen mit Grenze oder kein frischer Kurs")
            regel(g)
            continue
        a(f"    {s['ohne_kurs']} von {s['n']} Spannen ohne frischen Kurs (als 0 gezählt) · Summe der Rohkurse {OP.de(s['summe'], 2)} "
          "(auf 1 gebracht)")
        a("    Ränder 10 · 25 · 50 · 75 · 90 %:  roh " + " · ".join(_usd(s["q"][r]) for r in RAENDER)
          + "    rekalibriert " + " · ".join(_usd(s["q_rekal"][r]) for r in RAENDER))
        a("    (rekalibriert: Regel 1.6 auf die Wahrscheinlichkeit „über der Grenze“ angewandt -- eine eigene Übertragung auf Spannen, "
          "noch nicht entschieden)")
        b = s["beste"]
        a(f"    wahrscheinlichste Spanne: {_niv_txt(b[0]) if b[0] is not None else 'unter'} bis {_niv_txt(b[1]) if b[1] is not None else 'darüber'} "
          f"mit {_wkt(b[2])}")
        a("    Wahrscheinlichkeit über der Grenze (roh): " + " · ".join(f"{_niv_txt(k)} {OP.de(w * 100, 0)} %" for k, w in s["punkte"]
                                                                       if 0.005 <= w <= 0.995))
        regel(g)
    F = B["fed"]
    a("")
    a("5 FED-PFAD (Kalshi KXFED: Obergrenze des Zielbands nach der Sitzung) und Ereignisse dazu")
    if F["heute"]:
        a(f"  Satz nach der zuletzt abgerechneten Sitzung ({F['heute']['ereignis']}, {_et_tag(F['heute']['ende'])}): {_satz(F['heute']['satz'])} "
          "(Wert der Börse)")
    else:
        a("  Satz nach der zuletzt abgerechneten Sitzung: nicht gespeichert -- die Spalte „gegen heute“ bleibt leer")
    if not F["sitzungen"]:
        a("    keine offene Sitzung in prognosemarkt.db")
    else:
        a(f"    {'Handelsschluss (New York)':<27}{'Ereignis':<14}{'in Tagen':>8}  {'Schwellen':>10}  {'häufigster Satz':<17}{'Mittel':>8}  "
          f"{'gegen heute':>11}  {'darunter · darüber':<19}{'Spread':>7}  {'Alter':>8}")
        for s in F["sitzungen"]:
            v = s["v"]
            t = _pm().et(s["ende"])
            wann = f"{t.day:02d}.{t.month:02d}.{t.year} {t.hour:02d}:{t.minute:02d}"
            if not v:
                a(f"    {wann:<27}{str(s['ereignis'])[:13]:<14}{OP.de((s['ende'] - jetzt) / TAG, 0):>8}  {s['frisch']:>3} von {s['maerkte']:<3}  "
                  "keine Verteilung (weniger als zwei Schwellen mit frischem Kurs)")
                continue
            gh = s["gegen_heute"]
            a(f"    {wann:<27}{str(s['ereignis'])[:13]:<14}{OP.de((s['ende'] - jetzt) / TAG, 0):>8}  {s['frisch']:>3} von {s['maerkte']:<3}  "
              f"{({'unter': '≤ ', 'ueber': '≥ '}.get(v['haeufig_rand'], '') + _satz(v['haeufig'][0]) + ' (' + OP.de(v['haeufig'][1] * 100, 0) + ' %)'):<17}{_satz(v['mittel']):>8}  "
              f"{('—' if gh is None else ('+' if gh >= 0 else '−') + OP.de(abs(gh), 2)):>11}  "
              f"{(_wkt(v['unter']) + ' · ' + _wkt(v['ueber'])):<19}{_pkt(s['spread']):>7}  {_alter_txt(s['alter_s']):>8}")
            a("      über der Grenze: " + " · ".join(f"{OP.de(g_, 3)} {OP.de(w * 100, 0)} %" for g_, w in v["grenzen"])
              + (f"   ({v['luecken']} Lücke: dazwischen fehlt eine Schwelle mit frischem Kurs)" if v["luecken"] == 1 else
                 (f"   ({v['luecken']} Lücken: dazwischen fehlen Schwellen mit frischem Kurs)" if v["luecken"] else "")))
        a("    Lesart: „häufigster Satz“ ist der Rasterwert mit der größten Wahrscheinlichkeit, „Mittel“ der Erwartungswert; „darunter · "
          "darüber“ ist die Wahrscheinlichkeit jenseits der Leiter (liegt dort viel, deckt die Leiter die Verteilung nicht; „≤“ und „≥“ "
          "vor dem häufigsten Satz heißen: Er ist nur das Ende der Leiter).")
    for titel, liste in (("Ereignisse bei Kalshi (Entscheid je Sitzung, Zahl der Senkungen, Rezession)", B["ereignisse"]),
                         ("Polymarket: Ereignisse mit „Fed“ im Titel", B["poly_fed"])):
        a(f"  {titel}:")
        if not liste:
            a("    keine")
        for e in liste:
            teile = []
            for x in e["zeilen"][:8]:
                if str(x["markt"]).startswith(str(e["ereignis"]) + "-"):
                    name = str(x["markt"])[len(str(e["ereignis"])) + 1:]
                elif str(x["markt"]) == str(e["ereignis"]):
                    name = "Ja"
                else:
                    name = "„" + " ".join(str(x.get("titel") or x["markt"]).split())[:80] + "“"
                teile.append(f"{name} {_wkt(x['p']) if x['frisch'] else '(kein frischer Kurs)'}")
            a(f"    {e['ereignis']} · Frist {_frist_txt(e['ende'])} · {e['frisch']} von {len(e['zeilen'])} frisch: " + " · ".join(teile)
              + (" · …" if len(e["zeilen"]) > 8 else ""))
            t0 = " ".join(str(e["zeilen"][0].get("titel") or "").split())
            if t0 and e["plattform"] == "kalshi":
                a(f"      Titel: „{t0[:140]}“")
    hin = [h for g in G for h in g["hinweise"]]
    for g in G:
        fehl = [x for x in g["zeilen"] if x["niveau"] is None and g["form"] != "spannen"]
        if fehl:
            hin.append(f"{g['ereignis']}: {len(fehl)} {'Markt' if len(fehl) == 1 else 'Märkte'} ohne Niveau -- die Felder der Börse und "
                       "die Kennung tragen keines")
        if g["frisch"] == 0:
            hin.append(f"{g['ereignis']}: kein Markt mit frischem Kurs")
    for s in F["sitzungen"]:
        if s["v"] and max(s["v"]["unter"], s["v"]["ueber"]) > PM_RAND_OFFEN:
            hin.append(f"{s['ereignis']}: jenseits der Leiter liegen {_wkt(s['v']['unter'])} darunter und {_wkt(s['v']['ueber'])} darüber "
                       "-- Mittel und häufigster Satz sind dort nur eine Grenze")
    a("")
    a("6 HINWEISE")
    if not hin:
        a("    keine" + (" -- keine Leiter läuft um mehr als 2 Punkte gegen ihre Ordnung, jedes Ereignis hat frische Kurse" if G else ""))
    for h in hin:
        a("    " + h)
    a("")
    a("  Gespeichert wurde nichts; im Chart steht von diesen Zahlen noch nichts (die Regeln für die Punkte folgen nach diesem Bericht).")
    a("  Lesart: " + PM_LESART)
    return _umbrochen(z)


# ================================================================================================ Selbsttest

def _N(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _b76(f: float, k: float, sig: float, t: float) -> tuple:
    """(Call, Put) in USD ohne Zins (Black 76)."""
    w = sig * math.sqrt(t)
    d1 = (math.log(f / k) + 0.5 * w * w) / w
    d2 = d1 - w
    return f * _N(d1) - k * _N(d2), k * _N(-d2) - f * _N(-d1)


def _kette(tag: date, strikes, teile, t: float, spanne: float = 0.02, feld=None, rausch=None, iv=None) -> list:
    """
    Erzeugte Kette EINES Verfalltags in der Form der Deribit-Antwort. teile = [(Gewicht, Terminkurs, Schwankung)] -- eine oder
    mehrere Lognormalverteilungen (mehrere: schiefe Mischung). Kurse in BTC (Preis in USD ÷ Terminkurs der Mischung).
    """
    f = sum(w * fi for w, fi, _ in teile)
    mon = {v: k for k, v in OP.MONATE.items()}[tag.month]
    out = []
    for i, k in enumerate(strikes):
        c = sum(w * _b76(fi, k, si, t)[0] for w, fi, si in teile) / f
        p = sum(w * _b76(fi, k, si, t)[1] for w, fi, si in teile) / f
        for typ, m in (("C", c), ("P", p)):
            if rausch is not None:
                m = m * (1.0 + rausch(i, typ))
            out.append({"instrument_name": f"BTC-{tag.day}{mon}{tag.year % 100:02d}-{int(k)}-{typ}", "bid_price": m * (1 - spanne / 2),
                        "ask_price": m * (1 + spanne / 2), "mark_iv": (iv if iv is not None else teile[0][2] * 100.0), "open_interest": 10.0,
                        "underlying_price": f if feld is None else feld})
    return out


def _wahr(teile, t: float, q: float) -> float:
    """Wahrer Rand einer Mischung von Lognormalverteilungen (Halbierung)."""
    def cdf(k):
        return sum(w * _N(-((math.log(fi / k) + 0.5 * si * si * t) / (si * math.sqrt(t)) - si * math.sqrt(t))) for w, fi, si in teile)
    lo, hi = 1.0, 1e8
    for _ in range(200):
        m = math.sqrt(lo * hi)
        lo, hi = (m, hi) if cdf(m) < q else (lo, m)
    return math.sqrt(lo * hi)


def _iv_aus(f: float, k: float, call: float, t: float) -> float:
    """Schwankung, mit der Black-76 den Call-Preis trifft (Halbierung) -- für erzeugte Ketten mit einer Schwankung je Strike."""
    lo, hi = 0.01, 5.0
    for _ in range(80):
        m = (lo + hi) / 2.0
        lo, hi = (m, hi) if _b76(f, k, m, t)[0] < call else (lo, m)
    return (lo + hi) / 2.0


def _kette_mark(tag: date, strikes, teile, t: float, **kw) -> list:
    """Wie _kette, aber mark_iv je Strike so, dass Black-76 den wahren Preis der Mischung trifft (so nennt eine Börse ihre Schwankung)."""
    K = _kette(tag, strikes, teile, t, **kw)
    f = sum(w * fi for w, fi, _ in teile)
    for e in K:
        k = float(e["instrument_name"].split("-")[2])
        e["mark_iv"] = _iv_aus(f, k, sum(w * _b76(fi, k, si, t)[0] for w, fi, si in teile), t) * 100.0
    return K


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_marktschicht -- Selbsttest (Markt-Schicht des 24-Monats-Charts; ohne Netz: Optionen an erzeugten Ketten in der Form von "
              "Deribit, Prognosemärkte an einer erzeugten prognosemarkt.db)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_marktschicht_test_")
    try:
        utc = timezone.utc
        nah = lambda a, b, tol=1e-9: a is not None and b is not None and abs(a - b) <= tol
        rel = lambda a, b: abs(a / b - 1.0) if a is not None and b else 9.9
        JETZT = datetime(2026, 11, 23, 20, 50, tzinfo=utc).timestamp()          # Montag, 15:50 in New York
        VERF = date(2027, 6, 25)
        T = (datetime(2027, 6, 25, 8, tzinfo=utc).timestamp() - JETZT) / TAG / 365.0
        lesen = lambda liste: OP.deribit_lesen({"result": liste})["kontrakte"]
        STRIKES = [20_000 + 2_500 * i for i in range(73)]                       # 20.000 bis 200.000
        EIN = [(1.0, 60_000.0, 0.55)]

        # ---- M1 Terminkurs aus der Parität (O3, U292)
        K1 = lesen(_kette(VERF, STRIKES, EIN, T, feld=58_060.0))
        c1, p1 = seiten(K1); t1 = terminkurs(c1, p1)
        K1b = lesen([e for e in _kette(VERF, STRIKES, EIN, T) if not (e["instrument_name"].endswith("-P") and "-60000-" in e["instrument_name"])])
        t1b = terminkurs(*seiten(K1b))
        K1c = lesen([e for e in _kette(VERF, STRIKES, EIN, T, feld=61_000.0) if e["instrument_name"].endswith("-C")])
        t1c = terminkurs(*seiten(K1c))
        gleich = {"C": {50.0: {"bid": 0.10, "ask": 0.10}, 60.0: {"bid": 0.05, "ask": 0.05}}, "P": {50.0: {"bid": 0.05, "ask": 0.05}, 60.0: {"bid": 0.10, "ask": 0.10}}}
        t1d = terminkurs(gleich["C"], gleich["P"])
        ok("M1 Terminkurs (O3, U292): aus der Parität am Strike mit dem kleinsten |Call − Put| -- F = K ÷ (1 − (Call − Put)); trägt das Feld "
           "der Börse einen anderen Wert (58.060 statt 60.000), gilt die Parität und die Abweichung steht da; fehlt am Geld der Put, nimmt "
           "sie den nächsten Strike mit beiden; ohne ein Paar gilt das Feld; bei gleichem Abstand der niedrigere Strike",
           nah(t1["f"], 60_000.0, 1e-6) and t1["art"] == "paritaet" and t1["k"] == 60_000.0 and t1["feld"] == 58_060.0
           and nah(t1["abw"], 60_000.0 / 58_060.0 - 1.0, 1e-9) and abs(t1["abw"]) > ABW_MELDEN
           and nah(t1b["f"], 60_000.0, 1e-6) and t1b["k"] in (57_500.0, 62_500.0)
           and t1c == {"f": 61_000.0, "art": "feld", "k": None, "feld": 61_000.0, "abw": None}
           and t1d["k"] == 50.0 and nah(t1d["f"], 50.0 / (1.0 - 0.05)),
           f"F {t1['f']:.2f} am Strike {t1['k']:.0f}; Feld {t1['feld']:.0f}; Abweichung {t1['abw'] * 100:+.2f} %")
        # ---- M2 Call-Preis in USD an den Strikes der beiden Seiten (O5.1)
        hand_c = {90.0: {"bid": 0.20, "ask": 0.22}, 110.0: {"bid": 0.04, "ask": 0.06}, 100.0: {"bid": 0.1, "ask": 0.1}, 120.0: {"bid": 0.0, "ask": 0.02}}
        hand_p = {90.0: {"bid": 0.05, "ask": 0.07}, 110.0: {"bid": 0.15, "ask": 0.17}, 100.0: {"bid": 0.1, "ask": 0.1}, 80.0: {"bid": 0.02, "ask": 0.04}}
        r2 = call_reihe(hand_c, hand_p, 100.0)
        ok("M2 Call-Preis ohne Zins in USD (O5.1): über dem Terminkurs F · Call, darunter aus dem Put (F · Put + F − K); ein Strike genau "
           "auf dem Terminkurs zählt für keine Seite; ein Kontrakt ohne Geldkurs zählt nicht",
           [k for k, _ in r2] == [80.0, 90.0, 110.0] and nah(r2[0][1], 100 * 0.03 + 20) and nah(r2[1][1], 100 * 0.06 + 10) and nah(r2[2][1], 100 * 0.05),
           f"{[(k, round(c, 2)) for k, c in r2]}")
        # ---- M3 Wahrscheinlichkeit über der Mitte, begrenzt und monoton (O5.2, O5.3)
        m3, s3, n3 = ueber_wkt([(10.0, 50.0), (20.0, 41.0), (30.0, 31.5), (50.0, 16.5), (60.0, 15.0), (70.0, 16.0), (80.0, 2.0)])
        m3b, s3b, n3b = ueber_wkt([(10.0, 50.0), (20.0, 41.0), (30.0, 33.0), (40.0, 27.0)])
        ok("M3 Wahrscheinlichkeit über der Mitte je Strike-Paar (O5.2, O5.3): Abnahme des Call-Preises je USD Strike; auf 0 bis 1 begrenzt "
           "(ein Paar mit steigendem Preis gibt 0, eines über 1 gibt 1); steigt sie von einem Paar zum nächsten, werden die Paare zu EINEM "
           "über die ganze Strecke zusammengelegt (Wert = Mittel, gewichtet mit dem Abstand der Strikes; Mitte = Mitte der Strecke) -- "
           "auch über mehrere Paare; eine fallende Folge bleibt, wie sie ist",
           m3 == [20.0, 40.0, 65.0] and all(nah(a, b) for a, b in zip(s3, [0.925, 0.75, (0.15 * 10 + 0.0 * 10 + 1.0 * 10) / 30])) and n3 == 3
           and m3b == [15.0, 25.0, 35.0] and all(nah(a, b) for a, b in zip(s3b, [0.9, 0.8, 0.6])) and n3b == 0,
           f"Mitten {m3}, Werte {[round(x, 3) for x in s3]} · {n3} zusammengelegt")
        # ---- M4 Ränder (O5.4)
        r4 = raender([10.0, 20.0, 30.0, 40.0, 50.0], [0.95, 0.8, 0.5, 0.2, 0.05])
        r4b = raender([10.0, 20.0, 30.0], [0.7, 0.5, 0.3])
        r4c = raender([10.0, 20.0, 30.0, 40.0], [0.9, 0.5, 0.5, 0.1])
        ok("M4 Ränder (O5.4): der kleinste Kurs, an dem 1 − s die Marke erreicht, zwischen den Mitten gerade verbunden; liegt die Marke "
           "außerhalb der Mitten, gibt es den Rand nicht (kein Verlängern); eine Marke genau auf der ersten Mitte zählt; auf einer flachen "
           "Strecke gilt ihr Anfang",
           nah(r4[10], 10 + 10 * (0.10 - 0.05) / 0.15) and nah(r4[25], 20 + 10 * (0.25 - 0.20) / 0.30) and nah(r4[50], 30.0)
           and nah(r4[75], 30 + 10 * (0.75 - 0.5) / 0.3) and nah(r4[90], 40 + 10 * (0.90 - 0.8) / 0.15)
           and r4b == {10: None, 25: None, 50: 20.0, 75: None, 90: None} and nah(r4c[10], 10.0) and nah(r4c[50], 20.0) and nah(r4c[90], 40.0),
           f"{ {q: (round(v, 2) if v is not None else None) for q, v in r4.items()} } · außerhalb: {r4b}")
        # ---- M5 bekannte Verteilung
        v5 = kennzahlen(K1)
        wahr5 = {q: _wahr(EIN, T, q / 100.0) for q in RAENDER}
        g5 = gegenprobe(v5["termin"], v5["iv"], T * 365.0)
        ok("M5 Bekannte Verteilung (eine Lognormalverteilung, Strikes alle 2.500 USD, Spanne 2 %): Die Ränder aus den Preisen treffen die "
           "wahren auf 1 %; die Gegenprobe aus der Schwankung am Geld trifft sie hier auf 0,01 % (ohne Schiefe sind beide Wege gleich); "
           "nichts musste zusammengelegt werden",
           v5["stufe"] == "quantile" and all(rel(v5["q"][q], wahr5[q]) < 0.01 for q in RAENDER) and all(rel(g5[q], wahr5[q]) < 1e-4 for q in RAENDER)
           and v5["glatt"] == 0 and v5["unter"] == 16 and v5["ueber"] == 56 and nah(v5["iv"], 55.0),
           " · ".join(f"{q} %: {v5['q'][q]:.0f} (wahr {wahr5[q]:.0f})" for q in RAENDER))
        # ---- M6 schiefe Verteilung
        MIX = [(0.35, 42_000.0, 0.75), (0.65, 60_000.0 / 0.65 - 0.35 * 42_000.0 / 0.65, 0.40)]
        v6 = kennzahlen(lesen(_kette(VERF, STRIKES, MIX, T, iv=52.0)))
        wahr6 = {q: _wahr(MIX, T, q / 100.0) for q in RAENDER}
        g6 = gegenprobe(v6["termin"], v6["iv"], T * 365.0)
        ok("M6 Schiefe Verteilung (Mischung zweier Lognormalverteilungen, Terminkurs 60.000): Die Ränder aus den Preisen treffen die wahren "
           "auf 1,5 %; die Gegenprobe aus EINER Schwankung liegt am 10-%-Rand um mehr als 5 % daneben -- deshalb kommen die Ränder aus den "
           "Preisen und nicht aus der Schwankung am Geld",
           nah(v6["termin"], 60_000.0, 1e-6) and all(rel(v6["q"][q], wahr6[q]) < 0.015 for q in RAENDER) and rel(g6[10], wahr6[10]) > 0.05,
           " · ".join(f"{q} %: {v6['q'][q]:.0f} (wahr {wahr6[q]:.0f}, Gegenprobe {g6[q]:.0f})" for q in RAENDER))
        # ---- M7 verrauschte Kurse
        import random
        GROB = [20_000 + 5_000 * i for i in range(37)]                         # Strikes alle 5.000 USD -- wie bei langen Verfalltagen
        abw7 = {q: [] for q in RAENDER}; glatt7 = []; steigt7 = True
        for saat in range(40):
            rnd = random.Random(saat); zufall = {}
            v7 = kennzahlen(lesen(_kette(VERF, GROB, EIN, T, spanne=0.06, rausch=lambda i, typ: zufall.setdefault((i, typ), rnd.uniform(-0.01, 0.01)))))
            glatt7.append(v7["glatt"])
            steigt7 = steigt7 and v7["stufe"] == "quantile" and all(v7["q"][q] is not None for q in RAENDER) and all(v7["q"][a] <= v7["q"][b] for a, b in zip(RAENDER, RAENDER[1:]))
            for q in RAENDER:
                abw7[q].append(rel(v7["q"][q], wahr5[q]) if v7["q"][q] is not None else 9.9)
        hart = kennzahlen(lesen(_kette(VERF, STRIKES, EIN, T, spanne=0.06, rausch=lambda i, typ: zufall.setdefault((i, typ, "h"), rnd.uniform(-0.03, 0.03)))))
        ok("M7 Verrauschte Kurse (40 erzeugte Ketten, Strikes alle 5.000 USD, jede Mitte um bis zu 1 % verschoben, Spanne 6 %): Die Ränder "
           "steigen immer von 10 bis 90 %; die größte Abweichung vom wahren Rand bleibt unter 6 %, die mittlere unter 2 %. Bei dreimal so "
           "starkem Rauschen und doppelt so dichten Strikes wird zusammengelegt; die Ränder steigen weiter und bleiben innerhalb von 10 % "
           "(die Mitte liegt hier 7 % daneben -- die Grenze des Rechenwegs, im Konzept genannt)",
           steigt7 and max(max(v) for v in abw7.values()) < 0.06 and max(sum(v) / len(v) for v in abw7.values()) < 0.02
           and hart["stufe"] == "quantile" and hart["glatt"] > 0 and all(hart["q"][q] is not None for q in RAENDER)
           and all(hart["q"][a] <= hart["q"][b] for a, b in zip(RAENDER, RAENDER[1:])) and all(rel(hart["q"][q], wahr5[q]) < 0.10 for q in RAENDER),
           "größte Abweichung je Rand: " + " · ".join(f"{q} %: {max(abw7[q]) * 100:.1f} %" for q in RAENDER)
           + f"; im Mittel höchstens {max(sum(v) / len(v) for v in abw7.values()) * 100:.1f} %; zusammengelegt 0 bis {max(glatt7)}; hart: {hart['glatt']} zusammengelegt, "
           + " · ".join(f"{hart['q'][q]:.0f}" for q in RAENDER))
        # ---- M8 Strikes reichen nicht bis an die Ränder
        ENG = [45_000 + 2_500 * i for i in range(13)]                         # 45.000 bis 75.000
        v8 = kennzahlen(lesen(_kette(VERF, ENG, EIN, T)))
        d8 = {"stufe": v8["stufe"], "tage": 200.0, "q": {str(k): v for k, v in v8["q"].items()}}
        ok("M8 Strikes von 45.000 bis 75.000 bei einer Verteilung von rund 33.000 bis 96.000: Die äußeren Ränder gibt es nicht -- sie werden "
           "nicht geschätzt; Mitte und die inneren Ränder stehen da (sofern innerhalb), der Verfalltag bleibt brauchbar",
           v8["stufe"] == "quantile" and v8["q"][10] is None and v8["q"][90] is None and v8["q"][50] is not None and rel(v8["q"][50], wahr5[50]) < 0.01
           and (v8["q"][25] is None) == (wahr5[25] < 46_250.0) and (v8["q"][75] is None) == (wahr5[75] > 73_750.0) and zeichen(d8) == (v8["q"][25] is not None and v8["q"][75] is not None),
           f"{ {q: (round(v) if v is not None else None) for q, v in v8['q'].items()} } (wahr 25 %: {wahr5[25]:.0f}, 75 %: {wahr5[75]:.0f})")
        # ---- M9 nicht brauchbar (O4)
        WENIG = [50_000, 52_500, 55_000, 57_500, 60_000, 62_500, 65_000, 67_500, 70_000, 72_500, 75_000]     # unter F nur 4
        v9a = kennzahlen(lesen(_kette(VERF, WENIG, EIN, T)))
        v9b = kennzahlen(lesen(_kette(VERF, STRIKES, EIN, T, spanne=0.20)))
        k9c = _kette(VERF, WENIG, EIN, T)
        for e in k9c:
            e["mark_iv"] = None
        v9c = kennzahlen(lesen(k9c))
        k9d = _kette(VERF, STRIKES, EIN, T, feld=61_000.0)
        for e in k9d:
            if e["instrument_name"].endswith("-P"):
                e["bid_price"] = 0.0                                           # kein Put mit Geldkurs: kein Paar für die Parität
        v9d = kennzahlen(lesen(k9d))
        ok("M9 Nicht brauchbar (O4, wie 9.2): unter dem Terminkurs nur vier Strikes -> keine Ränder, nur die Schwankung am Geld, mit Grund; "
           "Spanne am Geld über 15 % -> ebenso; fehlt auch die Schwankung, entfällt der Verfalltag; Terminkurs nur aus dem Feld -> keine Ränder",
           v9a["stufe"] == "iv" and v9a["q"] == {q: None for q in RAENDER} and v9a["unter"] == 4 and "unter dem Terminkurs nur 4 Strikes" in v9a["grund"]
           and v9b["stufe"] == "iv" and "Spanne am Geld 20,0 % über 15 %" in v9b["grund"] and v9c["stufe"] == "entfaellt"
           and v9d["stufe"] == "iv" and v9d["termin"] == 61_000.0 and v9d["termin_art"] == "feld" and "Terminkurs nur aus dem Feld" in v9d["grund"]
           and v9d["q"][50] is None and kennzahlen(K1c)["stufe"] == "entfaellt",
           f"{v9a['grund']} | {v9b['grund']}")
        # ---- M10 Fälligkeit (O1)
        db = os.path.join(tmp, "makro.db")
        con = sqlite3.connect(db); _tabellen(con); con.commit()
        ny = lambda j, mo, t_, h, mi: datetime(j, mo, t_, h, mi, tzinfo=AK.NY).timestamp()
        f_a = faellig(con, ny(2026, 11, 23, 10, 0))                             # nichts gespeichert, vormittags
        f_l = faellig(con, ny(2026, 11, 23, 20, 0))                             # nichts gespeichert, abends in New York (in UTC schon der 24.11.)
        f_b = faellig(con, ny(2026, 11, 23, 15, 45))
        con.execute("INSERT INTO lf_option_abruf (tag, ts, art, versuche, letzter_versuch) VALUES ('2026-11-23', ?, 'erst', 1, ?)",
                    (int(ny(2026, 11, 23, 10, 0)), int(ny(2026, 11, 23, 10, 0)))); con.commit()
        f_c = faellig(con, ny(2026, 11, 23, 15, 44))
        f_d = faellig(con, ny(2026, 11, 23, 15, 45))
        con.execute("UPDATE lf_option_abruf SET letzter_versuch = ? WHERE tag = '2026-11-23'", (int(ny(2026, 11, 23, 15, 45)),)); con.commit()
        f_e = faellig(con, ny(2026, 11, 23, 15, 54))
        f_f = faellig(con, ny(2026, 11, 23, 15, 55))
        con.execute("UPDATE lf_option_abruf SET art = 'plan' WHERE tag = '2026-11-23'"); con.commit()
        f_g = faellig(con, ny(2026, 11, 23, 23, 59))
        f_h = faellig(con, ny(2026, 11, 24, 0, 1))
        f_i = faellig(con, ny(2026, 11, 28, 15, 45))                            # Samstag
        f_j = faellig(con, datetime(2027, 6, 21, 19, 44, tzinfo=utc).timestamp())   # Sommer: 15:44 in New York
        f_k = faellig(con, datetime(2027, 6, 21, 19, 45, tzinfo=utc).timestamp())
        con.close()
        ok("M10 Fälligkeit (O1): ohne gespeicherten Abruf sofort ein Erstabruf; danach erst ab 15:45 Uhr New York; der Abruf zur festen Zeit "
           "ersetzt den Erstabruf desselben Tages; nach einem Versuch frühestens nach 10 Minuten der nächste; ist der Abruf des Tages "
           "gespeichert, bis zum nächsten Tag keiner; der Tag ist der in New York (abends dort ist in UTC schon der nächste -- der Abruf "
           "gehört trotzdem zum New Yorker Tag); am Samstag wie an jedem Tag; im Sommer 19:45 UTC, im Winter 20:45 UTC",
           f_a[0] == "erst" and f_b[0] == "plan" and f_l[0] == "plan" and ny_tag(ny(2026, 11, 23, 20, 0)) == date(2026, 11, 23)
           and ny_tag(ny(2026, 11, 24, 0, 1)) == date(2026, 11, 24) and f_c[0] is None and f_c[2] == int(ny(2026, 11, 23, 15, 45)) and f_d[0] == "plan"
           and f_e[0] is None and f_e[2] == int(ny(2026, 11, 23, 15, 55)) and f_f[0] == "plan" and f_g[0] is None
           and f_g[2] == int(ny(2026, 11, 24, 15, 45)) and f_h[0] is None and f_h[2] == int(ny(2026, 11, 24, 15, 45)) and f_i[0] == "plan"
           and f_j[0] is None and f_k[0] == "plan"
           and plan_ts(date(2026, 11, 23)) == int(datetime(2026, 11, 23, 20, 45, tzinfo=utc).timestamp()) and WIEDER_S == 600,
           f"{[x[0] for x in (f_a, f_b, f_c, f_d, f_e, f_f, f_g, f_h, f_i, f_j, f_k)]}")
        # ---- M11 Abruf und Ablage (O1, O6)
        db2 = os.path.join(tmp, "makro2.db")
        KURZ = date(2026, 12, 11); T_K = (datetime(2026, 12, 11, 8, tzinfo=utc).timestamp() - JETZT) / TAG / 365.0
        VORBEI = date(2026, 11, 20)
        kette = (_kette(VERF, STRIKES, EIN, T, feld=58_060.0) + _kette(KURZ, STRIKES, [(1.0, 59_000.0, 0.50)], T_K)
                 + _kette(date(2027, 9, 24), WENIG, [(1.0, 60_000.0, 0.60)], T + 91 / 365.0) + _kette(VORBEI, STRIKES, EIN, 0.01))
        rufe = []

        def http_ok(url, timeout):
            rufe.append(url)
            return json.dumps({"result": kette}).encode(), None, 200

        def http_fehler(url, timeout):
            rufe.append(url)
            return None, "HTTP 503: Service Unavailable", 503
        a1 = tagesabruf(db2, http_fn=http_fehler, jetzt=JETZT)
        a2 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 300)                # nach 5 Minuten: noch kein neuer Versuch
        a3 = tagesabruf(db2, http_fn=lambda u, t: (b"<html><body>gesperrt</body></html>", None, 200), jetzt=JETZT + 600)
        a4 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 1200)
        import hashlib
        bild5 = hashlib.sha256(open(db2, "rb").read()).hexdigest()
        a5 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 1800)               # gespeichert: kein weiterer Abruf
        still5 = hashlib.sha256(open(db2, "rb").read()).hexdigest() == bild5    # und kein Schreiben in die Datenbank
        con = sqlite3.connect(db2)
        tabs = sorted(r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'"))
        zl, ab = [], []
        if tabs == ["lf_option", "lf_option_abruf"]:                            # fehlen sie, trägt M11 das als Aussage (kein Abbruch)
            zl = [_zeile(z) for z in con.execute("SELECT " + ", ".join(SPALTEN) + " FROM lf_option ORDER BY verfall")]
            ab = con.execute("SELECT tag, ts, art, status, kontrakte, verfalltage, versuche, fehler, modul FROM lf_option_abruf").fetchall()
        con.close()
        ok("M11 Abruf und Ablage (O1, O6): Ein Fehlschlag (HTTP 503) zählt als Versuch mit Grund; fünf Minuten später wird nicht abgerufen; "
           "eine HTML-Seite statt JSON ist ein Fehlschlag mit Grund; der nächste gelungene Abruf speichert je kommendem Verfalltag eine "
           "Zeile (der vergangene fehlt) und die Zeile über den Abruf; danach wird an dem Tag nicht mehr abgerufen, und die Prüfung der "
           "Fälligkeit schreibt nichts in die Datenbank. Genau ein Aufruf je "
           "Versuch, immer an die feste Adresse. Gespeichert sind nur Kennzahlen -- zwei Tabellen, keine Kette",
           a1["art"] == "plan" and a1["fehler"] == "HTTP 503: Service Unavailable" and a1["gespeichert"] == 0
           and a2["art"] is None and "weniger als 10 Minuten" in (a2["grund"] or "") and a3["art"] == "plan" and "HTML statt JSON" in a3["fehler"]
           and a4 == {"art": "plan", "grund": "fällig", "tag": "2026-11-23", "gespeichert": 3, "fehler": None, "ts": int(JETZT + 1200)}
           and a5["art"] is None and a5["grund"] == "der Abruf dieses Tages ist gespeichert" and still5
           and rufe == [OP.DERIBIT_URL] * 2 and [z["verfall"] for z in zl] == ["2026-12-11", "2027-06-25", "2027-09-24"]
           and [z["stufe"] for z in zl] == ["quantile", "quantile", "iv"] and all(z["ts"] == int(JETZT + 1200) and z["art"] == "plan" for z in zl)
           and nah(zl[1]["termin"], 60_000.0, 1e-6) and zl[1]["feld"] == 58_060.0 and rel(zl[1]["q"]["50"], wahr5[50]) < 0.012
           and ab == [("2026-11-23", int(JETZT + 1200), "plan", 200, 73 * 2 * 3 + 11 * 2, 3, 3, None, VERSION_MODUL)]
           and tabs == ["lf_option", "lf_option_abruf"] and os.path.getsize(db2) < 40_000,
           f"{[(z['verfall'], z['stufe']) for z in zl]}; Abruf {ab[0][:7] if ab else None}; Datei {os.path.getsize(db2)} Bytes")
        # ---- M11b Erstabruf und sein Ersatz
        db3 = os.path.join(tmp, "makro3.db")
        FRUEH = datetime(2026, 11, 23, 14, 0, tzinfo=utc).timestamp()           # 09:00 in New York
        e1 = tagesabruf(db3, http_fn=http_ok, jetzt=FRUEH)
        e2 = tagesabruf(db3, http_fn=http_ok, jetzt=FRUEH + 3600)
        con = sqlite3.connect(db3); n_e = con.execute("SELECT COUNT(*), MIN(art), MAX(ts) FROM lf_option").fetchone(); con.close()
        kette_spaet = _kette(VERF, STRIKES, [(1.0, 63_000.0, 0.55)], T)
        e3 = tagesabruf(db3, http_fn=lambda u, t: (json.dumps({"result": kette_spaet}).encode(), None, 200), jetzt=JETZT)
        con = sqlite3.connect(db3)
        n_p = con.execute("SELECT COUNT(*), MIN(art), MAX(ts), MIN(termin) FROM lf_option").fetchone()
        ab3 = con.execute("SELECT tag, art, versuche FROM lf_option_abruf").fetchall(); con.close()
        e4 = tagesabruf(db3, http_fn=http_ok, jetzt=JETZT + 86_400 - 7200)      # nächster Tag, 13:50 in New York: kein Erstabruf mehr
        ok("M11b Erstabruf (O1): Ist noch nichts gespeichert, wird sofort abgerufen und als „erst“ abgelegt; bis 15:45 Uhr New York folgt "
           "keiner; der Abruf zur festen Zeit desselben Tages ersetzt die Zeilen des Erstabrufs ganz; am nächsten Tag vor 15:45 wird nicht "
           "abgerufen",
           e1["art"] == "erst" and e1["gespeichert"] == 3 and e2["art"] is None and e2["grund"] == "fällig ab 15:45 Uhr New York"
           and n_e == (3, "erst", int(FRUEH)) and e3["art"] == "plan" and e3["gespeichert"] == 1 and n_p[:3] == (1, "plan", int(JETZT))
           and nah(n_p[3], 63_000.0, 1e-6) and ab3 == [("2026-11-23", "plan", 2)] and e4["art"] is None and e4["tag"] == "2026-11-24",
           f"erst {n_e}; danach {n_p[:3]}; Abruf {ab3}")
        # ---- M12 Stand für den Chart (O7)
        TAG_J = int(JETZT // TAG)
        s12 = stand(db2, stichtag=TAG_J - 1, jetzt=JETZT + 2000)
        s12b = stand(db2, stichtag=TAG_J + 3, jetzt=JETZT + 3 * TAG)
        s12c = stand(db2, stichtag=TAG_J + 4, jetzt=JETZT + 4 * TAG)
        s12d = stand(os.path.join(tmp, "fehlt.db"), stichtag=TAG_J)
        leer = os.path.join(tmp, "leer.db"); sqlite3.connect(leer).close()
        s12e = stand(leer, stichtag=TAG_J)
        gr_vor = os.path.getsize(leer)
        ok("M12 Stand für den Chart (O7): Zeichen nur für brauchbare Verfalltage ab 28 Tagen mit Mitte und inneren Rändern (der Verfalltag in "
           "18 Tagen und der nicht brauchbare stehen nur in der Tabelle); der Abruf darf höchstens 3 Tage vor dem Stichtag liegen -- am "
           "vierten Tag keine Zeichen, mit Grund; ohne Tabellen oder ohne Datei der Grund statt eines Fehlers; das Lesen legt nichts an",
           s12["ok"] and [p["verfall"] for p in s12["punkte"]] == ["2027-06-25"] and len(s12["zeilen"]) == 3 and s12["alter_tage"] == -1
           and s12["punkte"][0]["tag"] == date(2027, 6, 25).toordinal() - date(1970, 1, 1).toordinal() and nah(s12["punkte"][0]["termin"], 60_000.0, 1e-6)
           and all(rel(s12["punkte"][0][f"q{q}"], wahr5[q]) < 0.012 for q in RAENDER) and [float(z["q"]["50"] is not None) for z in s12["zeilen"]] == [1.0, 1.0, 0.0]
           and [z["zeichen"] for z in s12["zeilen"]] == [False, True, False] and s12["naechster"] == int(ny(2026, 11, 24, 15, 45))
           and s12b["ok"] and s12b["alter_tage"] == 3 and len(s12b["punkte"]) == 1
           and s12c["ok"] is False and s12c["punkte"] == [] and "mehr als 3 Tage vor dem Stichtag" in (s12c["grund"] or "") and len(s12c["zeilen"]) == 3
           and not any(z["zeichen"] for z in s12c["zeilen"]) and json.loads(json.dumps(s12, allow_nan=False)) == s12
           and s12d["ok"] is False and s12d["grund"] and s12e["ok"] is False and "Noch kein Abruf der Optionen gespeichert" in s12e["grund"]
           and os.path.getsize(leer) == gr_vor and not os.path.exists(os.path.join(tmp, "fehlt.db")),
           f"Zeichen {[p['verfall'] for p in s12['punkte']]}; nach 4 Tagen: {(s12c['grund'] or 'kein Grund')[:70]}")
        # ---- M13 Text
        t13 = "\n".join(stand_text(s12, {"2027-06-25": {"10": 40_000.0, "50": 70_000.0, "90": 120_000.0}}))
        t13o = "\n".join(stand_text(s12, None, lesart=False))
        t13e = "\n".join(stand_text(s12e))
        db13 = os.path.join(tmp, "makro13.db"); shutil.copyfile(db2, db13)
        tagesabruf(db13, http_fn=lambda u, t: (None, "HTTP 503: Service Unavailable -- " + "sehr lange Meldung der Gegenstelle " * 6, 503), jetzt=JETZT + TAG)
        t13f = "\n".join(stand_text(stand(db13, stichtag=TAG_J, jetzt=JETZT + TAG + 60)))
        z13 = next((x for x in t13.splitlines() if x.startswith("  * 25.06.2027")), "")
        ok("M13 Text für Debug 156: Kopf mit Abrufzeit, Größe und Zahl der Kontrakte; je Verfalltag eine Zeile mit Tagen, Terminkurs, den "
           "fünf Rändern, Strikes je Seite, Spanne, Schwankung und Stufe -- der Stern nur am Zeichen im Chart, der Grund am nicht brauchbaren; "
           "die Gegenprobe mit Parität gegen Feld und dem Vermerk über 1 %; der Fächer am selben Tag; die Lesart; ohne Abruf nur Grund und "
           "Lesart; ein Fehlschlag von heute steht mit Zahl der Versuche und Grund da; keine Zeile über 150 Zeichen; keine Kauf- oder "
           "Verkaufswörter",
           "Abruf vom " in t13 and "zur festen Zeit" in t13 and "460 Kontrakte" in t13 and "3 Verfalltage" in t13 and "New-York-Tag 23.11.2026" in t13
           and "60.000" in z13 and z13.rstrip().endswith("Ränder") and " 16+56 " in z13 and "55,0 %" in z13
           and "    11.12.2026" in t13 and "nur Schwankung am Geld\n        Grund: unter dem Terminkurs nur 4 Strikes mit beiden Kursen\n" in t13
           and max(len(x) for x in (t13 + "\n" + t13e + "\n" + t13f).splitlines()) <= 150 and "<-- über 1 %" in t13f and "Service Unavailable" in t13f
           and "60.000 ·  58.060 · +3,34 %  <-- über 1 %" in t13 and "Fächer 40.000 · 70.000 · 120.000   Optionen " in t13
           and " ".join(t13.split()).count(LESART) == 1 and "Nächster Abruf: ab " in t13
           and "Noch kein Abruf der Optionen gespeichert" in t13e and LESART in " ".join(t13e.split()) and "Verfall" not in t13e
           and "Lesart" not in t13o and "Zum Vergleich der Fächer" not in t13o and "Gegenprobe (O5.5)" in t13o
           and not any(w in (t13 + t13e).lower() for w in ("kaufen", "verkaufen", "einstieg", "ausstieg", "empfehl", "long gehen", "short gehen")),
           z13.strip()[:120])
        # ---- M14 wirft nie
        kein = os.path.join(tmp, "gibt", "es", "nicht.db")
        w1 = takt_schritt(kein, jetzt=JETZT, http_fn=http_ok)
        w2 = tagesabruf(os.path.join(tmp, "m14.db"), http_fn=lambda u, t: (_ for _ in ()).throw(RuntimeError("Leitung tot")), jetzt=JETZT)
        w3 = tagesabruf(os.path.join(tmp, "m14b.db"), http_fn=lambda u, t: (json.dumps({"error": {"message": "too many requests", "code": 10028}}).encode(), None, 200), jetzt=JETZT)
        w4 = tagesabruf(os.path.join(tmp, "m14c.db"), http_fn=lambda u, t: (json.dumps({"result": _kette(VORBEI, STRIKES, EIN, 0.01)}).encode(), None, 200), jetzt=JETZT)
        w5 = kennzahlen([])
        ok("M14 Wirft nie: Pfad ohne Ordner, Ausnahme im Abruf, Fehlerantwort der Börse, Antwort nur mit vergangenen Verfalltagen, leere "
           "Kette -- je ein Ergebnis mit Grund, nichts gespeichert",
           w1["fehler"] and w1["gespeichert"] == 0 and "Leitung tot" in w2["fehler"] and "too many requests" in w3["fehler"]
           and w4["fehler"] == "HTTP 200: kein kommender Verfalltag in der Antwort" and w4["gespeichert"] == 0 and w5["stufe"] == "entfaellt"
           and w5["termin"] is None,
           f"{w2['fehler'][:50]} | {w3['fehler'][:60]}")
        # ---- M15 Diagnose: wo zusammengelegt wurde (O9.1)
        def reihe_aus(ks, ss, c0=1000.0):
            r = [(ks[0], c0)]
            for i, x in enumerate(ss):
                r.append((ks[i + 1], r[-1][1] - x * (ks[i + 1] - ks[i])))
            return r
        hk = {k: {"iv": 50.0} for k in (10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0)}
        r15 = reihe_aus([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], [0.9, 0.6, 0.7, 0.4, 0.1])
        m15, s15, g15 = ueber_wkt(r15)
        st15 = strecken(r15, m15)
        q15 = raender(m15, s15)
        d15 = diagnose(hk, hk, 35.0, 30.0, r15, m15, s15, q15)
        d15b = diagnose(hk, hk, 35.0, 30.0, r15, m15, s15, {10: None, 25: 24.0, 50: 40.0, 75: None, 90: None})   # stößt bei 40 an das nächste Paar
        d15e = diagnose(hk, hk, 35.0, 30.0, r15, m15, s15, {10: None, 25: 24.0, 50: 39.0, 75: None, 90: None})
        r15c = reihe_aus([10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0], [0.9, 0.5, 0.1, 0.02, 0.05, 0.01])
        m15c, s15c, g15c = ueber_wkt(r15c)
        q15c = raender(m15c, s15c)
        d15c = diagnose(hk, hk, 35.0, 30.0, r15c, m15c, s15c, q15c)
        d15d = diagnose(hk, hk, 35.0, 30.0, r15, m15, s15, {r: None for r in RAENDER})
        ok("M15 Diagnose, Lage der Zusammenlegungen (O9.1): Die Strecken der Paare folgen aus Strikes und Mitten (ein zusammengelegtes Paar "
           "reicht über beide Strecken); im Bereich der Ränder zählt, was den Bereich vom untersten bis zum obersten VORHANDENEN Rand "
           "berührt -- ein Paar, das nur an der Grenze anstößt, zählt mit, eines im fernen Ende nicht; ohne Rand gibt es keine Zählung",
           st15 == [(10.0, 20.0, 1), (20.0, 40.0, 2), (40.0, 50.0, 1), (50.0, 60.0, 1)] and g15 == 1
           and all(nah(q15[r], w) for r, w in ((10, 15.0), (25, 24.0), (50, 39.0), (75, 50.0), (90, 55.0)))
           and (d15["zi"], d15["pi"], d15["za"]) == (1, 5, 0)
           and (d15b["zi"], d15b["pi"], d15b["za"]) == (1, 3, 0) and (d15e["zi"], d15e["pi"], d15e["za"]) == (1, 2, 0)
           and g15c == 1 and strecken(r15c, m15c)[-2:] == [(40.0, 60.0, 2), (60.0, 70.0, 1)]
           and q15c[90] is not None and q15c[90] < 40.0 and (d15c["zi"], d15c["za"]) == (0, 1) and d15c["pi"] == 3
           and (d15d["zi"], d15d["pi"], d15d["za"]) == (None, None, None),
           f"Strecken {st15} · Ränder {[round(q15[r], 1) for r in RAENDER]} · alle Ränder {d15['zi']}/{d15['pi']}/{d15['za']} · Bereich 24 bis 40 "
           f"{d15b['zi']}/{d15b['pi']}/{d15b['za']} · 24 bis 39 {d15e['zi']}/{d15e['pi']}/{d15e['za']} · fernes Ende {d15c['zi']}/{d15c['pi']}/{d15c['za']} (90-%-Rand {q15c[90]:.1f})")
        # ---- M16 Diagnose: die Enden (O9.2)
        v16 = kennzahlen(lesen(_kette(VERF, ENG, EIN, T)), T * 365.0)
        k16 = _kette(VERF, STRIKES, EIN, T)
        for e_ in k16:                                                        # gelistet von 20.000 bis 200.000, Kurse nur von 45.000 bis 75.000
            if not 45_000 <= float(e_["instrument_name"].split("-")[2]) <= 75_000:
                e_["bid_price"] = 0.0
        v16b = kennzahlen(lesen(k16), T * 365.0)
        class _Ohne(dict):                                                     # fehlt die Diagnose, scheitert die Probe an ihrer Aussage
            def __missing__(self, k):
                return None
        g16, g16b = v16["diag"] or _Ohne(), v16b["diag"] or _Ohne()
        ok("M16 Diagnose, die Enden (O9.2): kleinster und größter Strike der Reihe und der gelisteten, die Wahrscheinlichkeit unter dem "
           "untersten und über dem obersten Paar -- reichen die Kurse nur von 45.000 bis 75.000, liegt unter dem untersten Paar mehr als "
           "10 %, und genau dort fehlt der 10-%-Rand; gelistete Strikes ohne Geldkurs zählen nur als gelistet; ohne Tage keine Diagnose",
           v16["q"][10] is None and v16["q"][50] is not None and (g16["kmin"], g16["kmax"], g16["gmin"], g16["gmax"]) == (45_000.0, 75_000.0, 45_000.0, 75_000.0)
           and g16["mu"] == 46_250.0 and g16["mo"] == 73_750.0 and g16["pu"] > 0.10 and nah(g16["pu"], 1.0 - _N((math.log(60_000.0 / 46_250.0) - 0.5 * 0.55 ** 2 * T) / (0.55 * math.sqrt(T))), 0.01)
           and nah(g16["po"], _N((math.log(60_000.0 / 73_750.0) - 0.5 * 0.55 ** 2 * T) / (0.55 * math.sqrt(T))), 0.01) and g16["po"] > 0.10
           and v16["q"][90] is None and (g16b["kmin"], g16b["kmax"], g16b["gmin"], g16b["gmax"]) == (45_000.0, 75_000.0, 20_000.0, 200_000.0)
           and v16b["q"] == v16["q"] and kennzahlen(lesen(_kette(VERF, ENG, EIN, T)))["diag"] is None and kennzahlen([], 10.0)["diag"] is None,
           f"unter {_usd(g16['mu'])}: {_wkt(g16['pu'])} · über {_usd(g16['mo'])}: {_wkt(g16['po'])} · gelistet {_usd(g16b['gmin'])}–{_usd(g16b['gmax'])}")
        # ---- M17 Diagnose: zweite Gegenprobe aus den Schwankungen der Börse (O9.3)
        v17 = kennzahlen(lesen(_kette(VERF, STRIKES, EIN, T)), T * 365.0)       # eine Schwankung für alle Strikes: die wahre
        km17 = _kette_mark(VERF, STRIKES, MIX, T)
        v17b = kennzahlen(lesen(km17), T * 365.0)
        rnd17 = random.Random(7); zuf17 = {}
        v17c = kennzahlen(lesen(_kette_mark(VERF, STRIKES, MIX, T, spanne=0.04,
                                            rausch=lambda i, typ: zuf17.setdefault((i, typ), rnd17.uniform(-0.02, 0.02)))), T * 365.0)
        km17d = _kette_mark(VERF, STRIKES, MIX, T)
        for e_ in km17d:
            if not 45_000 <= float(e_["instrument_name"].split("-")[2]) <= 75_000:
                e_["ask_price"] = 0.0
        v17d = kennzahlen(lesen(km17d), T * 365.0)
        mk17 = lambda v_: {r: v_["diag"]["mark"][str(r)] for r in RAENDER}
        abw17 = max(rel(mk17(v17)[r], wahr5[r]) for r in RAENDER)
        abw17b = max(rel(mk17(v17b)[r], wahr6[r]) for r in RAENDER)
        abw17g = max(rel(gegenprobe(v17b["termin"], v17b["iv"], T * 365.0)[r], wahr6[r]) for r in RAENDER)
        mr17 = mark_reihe(*seiten(lesen(km17)), 60_000.0, T * 365.0)
        halb = {60_000.0: {"iv": None}, 50_000.0: {"iv": 40.0}}
        mr17e = mark_reihe({40_000.0: {"iv": 45.0}, 50_000.0: {"iv": 0.0}, 70_000.0: {"iv": 55.0}, 60_000.0: {"iv": 50.0}},
                           {40_000.0: {"iv": None}, 50_000.0: {"iv": 40.0}, 70_000.0: {"iv": 99.0}, 80_000.0: {"iv": 60.0}}, 60_000.0, 100.0)
        nahe17 = lambda a_, b_: max(rel(a_[r], b_[r]) for r in RAENDER)
        ok("M17 Diagnose, zweite Gegenprobe (O9.3): Call-Preise nach Black-76 aus der Schwankung der Börse je Strike, dann O5.2 bis O5.4 -- "
           "bei einer bekannten Verteilung und bei der schiefen Mischung trifft sie die wahren Ränder auf 1 % (die Gegenprobe aus EINER "
           "Schwankung liegt bei der Mischung über 10 % daneben); verrauschte Geld- und Briefkurse erreichen sie nur über den Terminkurs "
           "(hier unter 1 %), während die Mitte aus den Kursen über 3 % daneben liegt; sie reicht über alle gelisteten Strikes -- auch wo "
           "den Kursen der äußere Rand fehlt; unter F zählt die Schwankung des Puts, darüber die des Calls, fehlt sie dort, die der "
           "anderen Seite; ein Strike genau bei F zählt nicht",
           abw17 < 0.01 and abw17b < 0.01 and abw17g > 0.10 and v17b["diag"]["mn"] in (len(STRIKES) - 1, len(STRIKES)) and v17b["diag"]["mg"] == 0
           and nahe17(mk17(v17c), mk17(v17b)) < 0.01 and v17c["q"] != v17b["q"] and rel(v17c["q"][50], wahr6[50]) > 0.03
           and rel(mk17(v17c)[50], wahr6[50]) < 0.01
           and v17d["q"][10] is None and v17d["q"][90] is None and mk17(v17d) == mk17(v17b) and v17d["diag"]["mn"] == v17b["diag"]["mn"]
           and len(mr17) == len(STRIKES) - 1 and all(k_ != 60_000.0 for k_, _ in mr17)
           and [k_ for k_, _ in mr17e] == [40_000.0, 50_000.0, 70_000.0, 80_000.0]
           and nah(mr17e[0][1], _b76(60_000.0, 40_000.0, 0.45, 100.0 / 365.0)[0]) and nah(mr17e[1][1], _b76(60_000.0, 50_000.0, 0.40, 100.0 / 365.0)[0])
           and nah(mr17e[2][1], _b76(60_000.0, 70_000.0, 0.55, 100.0 / 365.0)[0]) and nah(mr17e[3][1], _b76(60_000.0, 80_000.0, 0.60, 100.0 / 365.0)[0])
           and mark_reihe(halb, halb, None, 10.0) == [] and mark_reihe(halb, halb, 60_000.0, 0.0) == [],
           f"bekannt {abw17 * 100:.2f} % · schief {abw17b * 100:.2f} % (Gegenprobe aus einer Schwankung {abw17g * 100:.0f} %) · verrauscht: Mitte aus "
           f"den Kursen {rel(v17c['q'][50], wahr6[50]) * 100:.1f} % daneben, aus der Schwankung der Börse {rel(mk17(v17c)[50], wahr6[50]) * 100:.2f} %")
        # ---- M18 Markierung „prüfen“ (O9, Schwellen vorab)
        def zeile18(q50=100.0, q10=80.0, q90=120.0, zi=0, pi=10, stufe="quantile", diag=True):
            return {"stufe": stufe, "q": {"10": q10, "25": 90.0, "50": q50, "75": 110.0, "90": q90},
                    "diag": {"mark": {"10": 80.0, "25": 90.0, "50": 100.0, "75": 110.0, "90": 120.0}, "zi": zi, "pi": pi} if diag else None}
        p18 = {n: pruef_gruende(z_) for n, z_ in (
            ("ruhig", zeile18()), ("mitte_knapp", zeile18(q50=102.9)), ("mitte_drueber", zeile18(q50=103.1)), ("mitte_drunter", zeile18(q50=96.8)),
            ("rand_knapp", zeile18(q10=84.7)), ("rand_drueber", zeile18(q10=84.9)), ("rand90", zeile18(q90=112.0)),
            ("drittel", zeile18(zi=3, pi=9)), ("ueber_drittel", zeile18(zi=4, pi=9)), ("ohne_diag", zeile18(q50=150.0, diag=False)),
            ("nicht_brauchbar", zeile18(q50=150.0, stufe="iv")), ("ohne_rand", zeile18(q10=None, q90=None)))}
        z17c = dict(q={str(r): v17c["q"][r] for r in RAENDER}, stufe=v17c["stufe"], diag=v17c["diag"])
        ok("M18 Markierung „prüfen“ (O9, Schwellen vorab): Mitte mehr als 3 % neben der zweiten Gegenprobe, ein anderer Rand mehr als 6 %, "
           "oder im Bereich der Ränder mehr als ein Drittel der Paare zusammengelegt -- knapp darunter nichts, knapp darüber der Grund mit "
           "der Zahl; ohne Diagnose, bei einem nicht brauchbaren Verfalltag und bei fehlendem Rand nichts; die verrauschte Kette aus M17 "
           "wird markiert",
           p18["ruhig"] == [] and p18["mitte_knapp"] == [] and p18["mitte_drueber"] == ["Mitte +3,1 % neben der zweiten Gegenprobe (über 3 %)"]
           and p18["mitte_drunter"] == ["Mitte −3,2 % neben der zweiten Gegenprobe (über 3 %)"] and p18["rand_knapp"] == []
           and p18["rand_drueber"] == ["10-%-Rand +6,1 % neben der zweiten Gegenprobe (über 6 %)"]
           and p18["rand90"] == ["90-%-Rand −6,7 % neben der zweiten Gegenprobe (über 6 %)"] and p18["drittel"] == []
           and p18["ueber_drittel"] == ["im Bereich der Ränder 4 von 9 Paaren zusammengelegt (über ein Drittel)"]
           and p18["ohne_diag"] == [] and p18["nicht_brauchbar"] == [] and p18["ohne_rand"] == []
           and any(g_.startswith("Mitte +") for g_ in pruef_gruende(z17c)) and (PRUEF_MITTE, PRUEF_RAND) == (0.03, 0.06) and nah(PRUEF_ANTEIL, 1.0 / 3.0),
           f"{p18['mitte_drueber']} | {p18['rand90']} | {p18['ueber_drittel']} | verrauscht: {pruef_gruende(z17c)}")
        # ---- M19 Ablage der Diagnose und eine Tabelle aus 23.118 (O6, O9)
        ab19 = sqlite3.connect(db2).execute("SELECT verfall, stufe, diag FROM lf_option ORDER BY verfall").fetchall()
        s19 = stand(db2, stichtag=TAG_J, jetzt=JETZT + 2000)
        z19 = {z_["verfall"]: z_ for z_ in s19["zeilen"]}
        alt19 = os.path.join(tmp, "makro_alt.db")
        ca = sqlite3.connect(alt19)
        ca.execute(TABELLE.replace("diag TEXT, ", "")); ca.execute(TABELLE_ABRUF)
        ca.execute("INSERT INTO lf_option (" + ", ".join(SPALTEN[:-1]) + ") VALUES (" + ", ".join("?" * (len(SPALTEN) - 1)) + ")",
                   ("2026-11-23", "2027-06-25", int(JETZT) - 3600, "erst", 213.5, 60_000.0, "paritaet", 60_000.0, 55.0, 30_000.0, 45_000.0, 58_000.0,
                    72_000.0, 95_000.0, 16, 56, 0.02, "quantile", None, 3, 73))
        ca.execute("INSERT INTO lf_option_abruf (tag, ts, art, status, bytes, dauer, kontrakte, verfalltage, versuche) VALUES "
                   "('2026-11-23', ?, 'erst', 200, 1000, 0.5, 146, 1, 1)", (int(JETZT) - 3600,))
        ca.commit(); ca.close()
        vor19 = hashlib.sha256(open(alt19, "rb").read()).hexdigest()
        s19a = stand(alt19, stichtag=TAG_J, jetzt=JETZT - 1800)                  # vor dem ersten Schritt des Takts: Spalte fehlt noch
        gleich19 = hashlib.sha256(open(alt19, "rb").read()).hexdigest() == vor19
        t19a = "\n".join(stand_text(s19a))
        FRUEH19 = JETZT - 1800                                                  # 15:20 in New York: kein Abruf fällig
        u1 = tagesabruf(alt19, http_fn=lambda u, t: (_ for _ in ()).throw(RuntimeError("darf nicht rufen")), jetzt=FRUEH19)
        nach19 = hashlib.sha256(open(alt19, "rb").read()).hexdigest()
        sp19 = [r[1] for r in sqlite3.connect(alt19).execute("PRAGMA table_info(lf_option)")]
        u2 = tagesabruf(alt19, http_fn=lambda u, t: (_ for _ in ()).throw(RuntimeError("darf nicht rufen")), jetzt=FRUEH19 + 60)
        still19 = hashlib.sha256(open(alt19, "rb").read()).hexdigest() == nach19
        s19b = stand(alt19, stichtag=TAG_J, jetzt=FRUEH19 + 120)
        u3 = tagesabruf(alt19, http_fn=http_ok, jetzt=JETZT)                    # 15:50 in New York: der Abruf zur festen Zeit ersetzt den Erstabruf
        s19c = stand(alt19, stichtag=TAG_J, jetzt=JETZT + 60)
        dg19 = (z19.get("2027-06-25") or {}).get("diag") or {}
        db19r = os.path.join(tmp, "makro_rausch.db")
        rnd19 = random.Random(7); zuf19 = {}
        k19r = _kette_mark(VERF, STRIKES, MIX, T, spanne=0.04, rausch=lambda i, typ: zuf19.setdefault((i, typ), rnd19.uniform(-0.02, 0.02)))
        u19r = tagesabruf(db19r, http_fn=lambda u, t: (json.dumps({"result": k19r}).encode(), None, 200), jetzt=JETZT)
        s19r = stand(db19r, stichtag=TAG_J, jetzt=JETZT + 60)
        t19r = "\n".join(stand_text(s19r))
        ok("M19 Ablage der Diagnose (O6, O9) und eine Tabelle aus 23.118: Der Abruf speichert die Diagnose je Verfalltag mit Rändern als "
           "JSON in der Spalte diag (ein Verfalltag ohne Ränder hat keine), der Stand liest sie und trägt die Markierung; eine Tabelle ohne die Spalte liest der Stand, ohne "
           "etwas zu ändern (Diagnose „noch keine“), der nächste Schritt des Takts legt die Spalte EINMAL an (auch ohne fälligen Abruf), "
           "danach schreibt er nichts mehr; die alte Zeile bleibt, bis der Abruf zur festen Zeit sie ersetzt -- der trägt die Diagnose",
           len(ab19) == 3 and [x[1] for x in ab19] == ["quantile", "quantile", "iv"] and all((x[2] is not None) == (x[1] == "quantile") for x in ab19)
           and all(json.loads(x[2])["mark"]["50"] for x in ab19 if x[2]) and s19["ok"]
           and set(dg19) == {"zi", "za", "pi", "kmin", "kmax", "gmin", "gmax", "pu", "po", "mu", "mo", "mark", "mn", "mg"}
           and dg19["kmin"] == 20_000.0 and dg19["mn"] in (len(STRIKES) - 1, len(STRIKES)) and all(z_["pruefen"] == [] for z_ in s19["zeilen"])
           and u19r["gespeichert"] == 1 and len(s19r["zeilen"]) == 1 and s19r["zeilen"][0]["pruefen"] == pruef_gruende(z17c) != []
           and s19r["zeilen"][0]["diag"] == json.loads(json.dumps(v17c["diag"])) and s19r["zeilen"][0]["zeichen"]
           and f"    <-- prüfen 25.06.2027: {pruef_gruende(z17c)[0]}" in t19r
           and s19a["ok"] and gleich19 and s19a["zeilen"][0]["diag"] is None and s19a["zeilen"][0]["pruefen"] == [] and s19a["zeilen"][0]["q"]["50"] == 58_000.0
           and "Diagnose (O9): noch keine -- dieser Abruf wurde vor 23.119 gespeichert" in t19a and "Zweite Gegenprobe" not in t19a
           and u1["art"] is None and u1["fehler"] is None and nach19 != vor19 and sp19 == list(SPALTEN) and u2["fehler"] is None and still19
           and s19b["zeilen"][0]["diag"] is None and s19b["zeilen"][0]["q"]["50"] == 58_000.0 and s19b["abruf"]["art"] == "erst"
           and u3["art"] == "plan" and u3["fehler"] is None and s19c["abruf"]["art"] == "plan"
           and [bool(z_["diag"]) for z_ in s19c["zeilen"]] == [True, True, False] and [z_["stufe"] for z_ in s19c["zeilen"]] == ["quantile", "quantile", "iv"],
           f"Spalten danach {sp19[-2:]} · vor dem Takt: {[z_['diag'] for z_ in s19a['zeilen'][:1]]} · nach dem Abruf zur festen Zeit: mn {[z_['diag']['mn'] for z_ in s19c['zeilen'] if z_['diag']]}")
        # ---- M20 Prüflauf ohne Speichern (O10, Debug 158)
        rufe20 = []
        def http20(url, timeout):
            rufe20.append(url)
            return json.dumps({"result": _kette_mark(VERF, STRIKES, MIX, T, spanne=0.04) + _kette(KURZ, STRIKES, [(1.0, 59_000.0, 0.50)], T_K)}).encode(), None, 200
        hier20 = os.getcwd(); leer20 = os.path.join(tmp, "leer20"); os.makedirs(leer20)
        os.chdir(leer20)
        try:
            t20 = pruefen(http_fn=http20, jetzt=JETZT)
            t20f = pruefen(http_fn=http_fehler, jetzt=JETZT)
            t20x = pruefen(http_fn=lambda u, t: (_ for _ in ()).throw(RuntimeError("Leitung tot")), jetzt=JETZT)
            t20k = pruefen(http_fn=lambda u, t: (json.dumps({"result": _kette(KURZ, STRIKES, [(1.0, 59_000.0, 0.50)], T_K)}).encode(), None, 200), jetzt=JETZT)
            dateien20 = os.listdir(leer20)
        finally:
            os.chdir(hier20)
        j20 = "\n".join(t20)
        paar20 = [x for x in t20 if " – " in x and x.strip()[:1].isdigit() and x.rstrip().endswith("%")]
        k20 = lesen(_kette_mark(VERF, STRIKES, MIX, T, spanne=0.04))
        v20 = kennzahlen(k20, T * 365.0)
        r20 = call_reihe(*seiten(k20), v20["termin"])
        im20 = [i_ for i_ in range(len(r20) - 1) if r20[i_ + 1][0] >= v20["q"][10] and r20[i_][0] <= v20["q"][90]]
        soll20 = len(range(max(0, im20[0] - 1), min(len(r20) - 2, im20[-1] + 1) + 1))
        zahl20 = lambda x: float(x.replace("*", "").replace(".", "").replace(",", ".").strip())
        drei20 = [[zahl20(t_) for t_ in x.split(" – ", 1)[1].split(None, 1)[1].split("%")[:3]] for x in paar20]
        erste20 = paar20[0].split(" – ")[0].strip() if paar20 else ""
        ok("M20 Prüflauf ohne Speichern (O10, Debug 158): EIN Aufruf, dieselben Tabellen wie im Bericht (Ränder, Gegenprobe, Diagnose, "
           "zweite Gegenprobe), dazu je brauchbarem Verfalltag ab 28 Tagen die Paare im Bereich der Ränder mit drei Wahrscheinlichkeiten; "
           "der kurze Verfalltag hat keine Paar-Tabelle; ein Fehlschlag steht in genau drei Zeilen da (ohne Tabellen, ohne Abbruch); der Lauf legt keine Datei an, und keine Zeile "
           "ist breiter als 150 Zeichen",
           len(rufe20) == 1 and rufe20[0] == OP.DERIBIT_URL and "HTTP 200" in t20[0] and "2 Verfalltage" in t20[0] and "292 Kontrakte" in t20[0]
           and "Ränder aus den Preisen (O5)" in j20 and "Gegenprobe (O5.5)" in j20 and "Diagnose (O9)" in j20 and "Zweite Gegenprobe (O9.3)" in j20
           and "Paare im Bereich der Ränder (O10)" in j20 and j20.count("  25.06.2027 (213 Tage) · Terminkurs ") == 1 and "  11.12.2026 (17 Tage)" not in j20
           and len(paar20) == soll20 >= 15 and all(x.count("%") == 3 for x in paar20) and "Gespeichert wurde nichts" in j20 and "Lesart: " in j20
           and erste20 == _usd(r20[max(0, im20[0] - 1)][0]) and all(0.0 <= a_ <= 100.0 and abs(a_ - b_) < 0.05 and abs(a_ - c_) < 3.0 for a_, b_, c_ in drei20)
           and all(drei20[i_][0] >= drei20[i_ + 1][0] for i_ in range(len(drei20) - 1)) and "  *" not in "".join(paar20)
           and max(len(x) for x in t20) <= 150 and dateien20 == []
           and "Kein Ergebnis: HTTP 503" in "\n".join(t20f) and "Gespeichert wurde nichts" in "\n".join(t20f) and "Ränder aus den Preisen" not in "\n".join(t20f)
           and len(t20f) == 3 and "abgebrochen" not in "\n".join(t20f) and "Paare" not in "\n".join(t20f)
           and "Kein Ergebnis: " in "\n".join(t20x) and "Leitung tot" in "\n".join(t20x) and len(t20x) == 3 and "abgebrochen" not in "\n".join(t20x)
           and "kein brauchbarer Verfalltag ab 28 Tagen" in "\n".join(t20k) and "Strike-Paar" not in "\n".join(t20k),
           f"{len(t20)} Zeilen, {len(paar20)} Paare (Soll {soll20}), längste {max(len(x) for x in t20)} · Fehlschlag: {t20f[1][:60] if len(t20f) > 1 else t20f}")
        # ---- M21 Text der Diagnose (O9)
        def zeile21(verfall, **kw):
            z_ = zeile18(**kw); z_["verfall"] = verfall
            if z_["diag"]:
                z_["diag"].update(za=2, kmin=40_000.0, kmax=140_000.0, gmin=20_000.0, gmax=300_000.0, pu=0.031, po=0.002, mu=41_250.0, mo=137_500.0, mn=61, mg=0)
            z_["pruefen"] = pruef_gruende(z_)
            return z_
        z21 = [zeile21("2026-12-25", zi=1, pi=14), zeile21("2027-01-29", q50=104.0, zi=5, pi=12, q10=None), zeile21("2027-03-26", stufe="iv", diag=False)]
        z21[1]["diag"]["mark"]["10"] = None; z21[1]["diag"]["mg"] = 2; z21[1]["diag"]["zi"] = None; z21[1]["diag"]["pi"] = None; z21[1]["diag"]["za"] = None
        z21[1]["pruefen"] = pruef_gruende(z21[1])
        t21 = diagnose_text(z21)
        t21alt = diagnose_text([zeile21("2026-12-25", diag=False)])
        t21leer = diagnose_text([zeile21("2027-03-26", stufe="iv", diag=False)])
        ok("M21 Text der Diagnose (O9): je Verfalltag mit Diagnose eine Zeile -- zusammengelegt im Bereich x von y und außerhalb, Strikes mit "
           "Kursen und gelistet, Wahrscheinlichkeit unter dem untersten und über dem obersten Paar --, dann die zweite Gegenprobe mit dem "
           "Abstand der Ränder aus den Preisen (10 %, Mitte, 90 %) und zuletzt die Markierungen; ein Verfalltag ohne Diagnose hat keine "
           "Zeile; ein Abruf vor 23.119 trägt den Hinweis „noch keine“; ohne brauchbaren Verfalltag steht nichts da",
           "    25.12.2026  im Bereich 1 von 14, außerhalb 2 · Kurse 40.000–140.000 (gelistet 20.000–300.000) · unter 41.250: 3,1 % · über 137.500: 0,2 %" in t21
           and "    29.01.2027  ohne Rand · Kurse 40.000–140.000 (gelistet 20.000–300.000) · unter 41.250: 3,1 % · über 137.500: 0,2 %" in t21
           and "    25.12.2026       80       90      100      110      120      61     +0,0 % · +0,0 % · +0,0 %" in t21
           and "    29.01.2027        —       90      100      110      120      61     — · +4,0 % · +0,0 %   (2 zusammengelegt)" in t21
           and t21[-1] == "    <-- prüfen 29.01.2027: Mitte +4,0 % neben der zweiten Gegenprobe (über 3 %)" and sum(1 for x in t21 if "<-- prüfen" in x) == 1
           and not any("26.03.2027" in x for x in t21) and sum(1 for x in t21 if x.startswith("    2")) == 4 and max(len(x) for x in t21) <= 150
           and t21alt == ["", "  Diagnose (O9): noch keine -- dieser Abruf wurde vor 23.119 gespeichert; der nächste trägt sie."] and t21leer == [],
           f"{len(t21)} Zeilen; {t21[-1].strip()[:70]}")
        # ---- M22 die Diagnose ist nur Bericht: Sie darf weder den Abruf noch die Zeichen kosten (O9, Nachtrag beim Bau)
        def kaputt22(*a_, **k_):
            raise RuntimeError("Probe: Diagnose scheitert")
        db22 = os.path.join(tmp, "makro_m22.db")
        echt22 = globals()["diagnose"]
        globals()["diagnose"] = kaputt22
        try:
            u22 = takt_schritt(db22, jetzt=JETZT, http_fn=http_ok)             # derselbe Abruf wie u3 in M19, nur scheitert die Diagnose
        finally:
            globals()["diagnose"] = echt22
        s22 = stand(db22, stichtag=TAG_J, jetzt=JETZT + 60)
        t22 = stand_text(s22)
        echt22p = globals()["pruef_gruende"]
        globals()["pruef_gruende"] = kaputt22
        try:
            s22p = stand(db19r, stichtag=TAG_J, jetzt=JETZT + 60)               # der verrauschte Abruf aus M19 trägt Markierungen
        finally:
            globals()["pruef_gruende"] = echt22p
        try:
            c22 = sqlite3.connect(db22); c22.execute("UPDATE lf_option SET diag='[1, 2]' WHERE diag IS NOT NULL"); c22.commit(); c22.close()
        except sqlite3.Error:
            pass
        s22l = stand(db22, stichtag=TAG_J, jetzt=JETZT + 60)
        q22 = [z_ for z_ in s22["zeilen"] if z_["stufe"] == "quantile"]
        ok("M22 Die Diagnose ist nur Bericht (O9): Scheitert ihre Rechnung, speichert der Abruf die Ränder trotzdem -- dieselben Ränder und Zeichen "
           "wie sonst; die Zeile trägt den Fehler statt der Zahlen, der Bericht sagt „nicht gerechnet“ und führt keine zweite Gegenprobe; scheitert "
           "die Markierung beim Lesen, bleiben die Zeichen und keine Zeile gilt als markiert; eine gespeicherte Diagnose, die kein Verzeichnis "
           "ist, gilt als keine",
           u22.get("gespeichert") == 3 and u22.get("fehler") is None and s22["ok"] and len(q22) == 2
           and s22["punkte"] == s19c["punkte"] and len(s22["punkte"]) >= 1 and [z_["q"] for z_ in s22["zeilen"]] == [z_["q"] for z_ in s19c["zeilen"]]
           and all(z_["diag"] == {"fehler": "RuntimeError: Probe: Diagnose scheitert"} for z_ in q22)
           and all(z_["diag"] is None for z_ in s22["zeilen"] if z_["stufe"] != "quantile") and all(z_["pruefen"] == [] for z_ in s22["zeilen"])
           and sum(1 for x in t22 if x.endswith("  nicht gerechnet -- RuntimeError: Probe: Diagnose scheitert")) == 2
           and any("Diagnose (O9) -- nur für den Bericht" in x for x in t22) and not any("Zweite Gegenprobe" in x for x in t22)
           and not any("noch keine" in x for x in t22) and not any("<-- prüfen" in x for x in t22)
           and any(z_["pruefen"] for z_ in s19r["zeilen"]) and s22p["ok"] and s22p["punkte"] == s19r["punkte"] and len(s22p["punkte"]) >= 1
           and all(z_["pruefen"] == [] for z_ in s22p["zeilen"]) and all(z_["diag"] for z_ in s22p["zeilen"] if z_["stufe"] == "quantile")
           and s22l["ok"] and s22l["punkte"] == s22["punkte"] and all(z_["diag"] is None for z_ in s22l["zeilen"]),
           f"Abruf: {u22.get('gespeichert')} Verfalltage, Fehler {u22.get('fehler')}; {len(s22['punkte'])} Zeichen; "
           f"{next((x.strip()[:80] for x in t22 if 'nicht gerechnet' in x), 'Zeile fehlt')}")
        # ---- K1 Vertrag mit dem Konzept
        hier = os.path.dirname(os.path.abspath(__file__))
        try:
            kz = open(os.path.join(hier, "KONZEPT_Langfrist.md"), encoding="utf-8").read()
        except OSError:
            kz = ""
        kz1 = " ".join(kz.split())
        ok("K1 Vertrag mit dem Konzept (9.3, O1 bis O10): Abrufzeit 15:45 Uhr New York, 10 Minuten bis zum nächsten Versuch, Abweichung 1 %, "
           "fünf Strikes je Seite und 15 % Spanne, die fünf Marken und ihre z-Werte, 28 Tage und 3 Tage, die beiden Tabellen; seit 23.119 "
           "die Diagnose (Spalte diag, Black-76, Schwellen 3 %, 6 % und ein Drittel) und der Prüflauf Debug 158 -- so stehen sie im "
           "Konzept und so rechnet das Modul",
           "### 9.3 Rechenweg und Abruf der Optionen-Schicht" in kz and all(f"**O{i} " in kz for i in range(1, 11))
           and "Spalte `diag`" in kz1 and "C(K) = F · N(d₁) − K · N(d₂)" in kz1 and "F ist der Terminkurs aus O3" in kz1
           and "um mehr als 3 % neben der Mitte der zweiten Gegenprobe" in kz1 and PRUEF_MITTE == 0.03 and "um mehr als 6 % daneben" in kz1
           and PRUEF_RAND == 0.06 and "mehr als ein Drittel der Paare zusammengelegt" in kz1 and abs(PRUEF_ANTEIL - 1.0 / 3.0) < 1e-12
           and "**O10 Prüflauf ohne Speichern (Debug 158, U302).**" in kz and DEBUG_NR_PRUEFEN == 158 and "O1–O10" in REGEL
           and "fällig ab 15:45 Uhr New York" in kz1 and (ABRUF_STUNDE, ABRUF_MINUTE) == (15, 45) and "(frühestens nach 10 Minuten)" in kz1 and WIEDER_S == 600
           and "F = K ÷ (1 − (Call − Put))" in kz1 and "um mehr als 1 % ab" in kz1 and ABW_MELDEN == 0.01
           and "mindestens fünf Puts und über F mindestens fünf Calls" in kz1 and MIN_STRIKES == 5 and "höchstens 15 %" in kz1 and MAX_SPANNE == 0.15
           and "C(K) = F · Put(K) + F − K" in kz1 and "z = −1,2816 / −0,6745 / 0 / +0,6745 / +1,2816" in kz1
           and [Z_WERT[q] for q in RAENDER] == [-1.2816, -0.6745, 0.0, 0.6745, 1.2816] and RAENDER == (10, 25, 50, 75, 90)
           and "brauchbarem Verfalltag ab 28 Tagen" in kz1 and MIN_TAGE_CHART == 28 and "höchstens 3 Tage vor dem Stichtag" in kz1 and MAX_ALTER_TAGE == 3
           and "Tabelle `lf_option`" in kz1 and "`lf_option_abruf`" in kz1 and "Die Kette selbst wird nicht gespeichert" in kz1,
           "Konzept gelesen" if kz else "KONZEPT_Langfrist.md fehlt")
        # ---- K2 Vertrag: was das Modul anfasst
        try:
            quelle = open(os.path.abspath(__file__), encoding="utf-8").read()
        except OSError:
            quelle = ""
        rumpf = quelle.split("\ndef selbsttest(", 1)[0]
        lauf20 = rumpf.split("\ndef pruefen(", 1)[-1].split("\ndef _umbrochen(", 1)[0] if "\ndef pruefen(" in rumpf else "sqlite3"
        ok("K2 Vertrag: Das Modul schreibt nur in seine zwei Tabellen (kein Löschen von Dateien, keine andere Tabelle), ruft nur die feste "
           "Adresse von Deribit über den Abruf des Erstlaufs -- an EINER Stelle, für Tagesabruf und Prüflauf --, der Stand für den Chart "
           "öffnet die Datenbank nur lesend, und der Prüflauf (Debug 158) öffnet gar keine",
           "sqlite3" not in lauf20 and "connect(" not in lauf20 and "open(" not in lauf20 and lauf20.count("holen(http_fn, jetzt)") == 1
           and rumpf.count("holen(http_fn, jetzt)") == 2 and rumpf.count("ALTER TABLE lf_option ADD COLUMN diag TEXT") == 1 and
           bool(rumpf) and not any(w in rumpf for w in ("os.remove", "os.unlink", "shutil", "subprocess", "DROP TABLE", "urllib", "requests"))
           and rumpf.count("OP.abruf(OP.DERIBIT_URL") == 1 and rumpf.count("OP.abruf(") == 1 and rumpf.count("INSERT INTO lf_option ") == 1
           and rumpf.count("INSERT OR IGNORE INTO lf_option_abruf") == 1 and "INSERT INTO mk_" not in rumpf and "UPDATE mk_" not in rumpf
           and rumpf.count("?mode=ro") == 1 and OP.DERIBIT_URL.startswith("https://www.deribit.com/api/v2/public/"),
           f"{len(rumpf)} Zeichen vor dem Selbsttest")
        # ================================================================ Teil 2a: Prognosemärkte als Text (23.120, U280 Teil 2a)
        import hashlib
        import subprocess
        import hl_prognosemarkt as PMt
        JP = datetime(2026, 11, 22, 21, 0, tzinfo=utc).timestamp()               # 22.11.2026, 16:00 Uhr in New York
        pm_db = os.path.join(tmp, "prognosemarkt.db")
        cp = PMt.verbinden(pm_db)
        E = PMt.et_zu_ts

        def pmm(plattform, name, ereignis, reihe, art, st, unten, oben, ende, basis="BTC", titel="", regeln="", gesehen_vor=600,
                ablauf=None, slug=None):
            with PMt.schreiben(cp):
                PMt.markt_speichern(cp, {"plattform": plattform, "markt": name, "ereignis": ereignis, "reihe": reihe, "art": art,
                                         "basis": basis, "strike_typ": st, "unten": unten, "oben": oben, "ende": int(ende),
                                         "titel": titel, "regeln": regeln, "ablauf": ablauf, "slug": slug}, int(JP - gesehen_vor))

        def pmk(plattform, name, geld, brief, letzter=None, alter=600):
            with PMt.schreiben(cp):
                PMt.kurs_speichern(cp, plattform, name, int(JP - alter), "live", geld, brief, letzter, None, int(JP - alter))

        JE = E(2027, 1, 1, 0, 0)                                                 # 00:00 Uhr New York am 01.01.2027 = Ende des 31.12.2026
        # (a) Kalshi Jahrestief: Schwellen nach unten; eine mit weitem Spread (letzter Handel), eine ohne lesbaren Kurs, eine gegen die Ordnung
        for k_, g_, b_, l_ in ((55000, 5300, 5500, None), (50000, 2700, 2900, 3500), (45000, 1000, 2200, 1600), (40000, None, 1500, None),
                               (35000, 2900, 3100, None)):
            pmm("kalshi", f"KXBTCMINY-27JAN01-{k_}", "KXBTCMINY-27JAN01", "KXBTCMINY", "beruehrung", "less", None, float(k_), JE,
                titel="How low will Bitcoin get in 2026?", regeln="If the price of Bitcoin is below the\n  threshold at any time before Jan 1, 2027, then the market resolves to Yes.")
            if k_ == 55000:                                                  # dieselben Werte schon eine gute Stunde früher gesehen
                pmk("kalshi", f"KXBTCMINY-27JAN01-{k_}", g_, b_, l_, alter=4000)
            pmk("kalshi", f"KXBTCMINY-27JAN01-{k_}", g_, b_, l_)
        # (b) Kalshi Jahreshoch: ein Markt nicht mehr gelistet (Kurs zwei Tage alt), einer frisch
        pmm("kalshi", "KXBTCMAXY-26DEC31-99999.99", "KXBTCMAXY-26DEC31", "KXBTCMAXY", "beruehrung", "greater", 99999.99, None,
            E(2026, 12, 31, 23, 59), gesehen_vor=2 * TAG)
        pmk("kalshi", "KXBTCMAXY-26DEC31-99999.99", 100, 300, None, alter=2 * TAG)
        pmm("kalshi", "KXBTCMAXY-26DEC31-109999.99", "KXBTCMAXY-26DEC31", "KXBTCMAXY", "beruehrung", "greater", 109999.99, None,
            E(2026, 12, 31, 23, 59))
        pmk("kalshi", "KXBTCMAXY-26DEC31-109999.99", 100, 300)
        # (c) Kalshi Fristen-Leiter am Niveau 130.000, die letzte Frist gegen die Ordnung; dazu ein Markt ohne Niveau
        for mon_, tag_, g_, b_ in ((5, 13, 700, 900), (6, 10, 900, 1100), (7, 8, 400, 600)):
            n_ = f"KXBTCPRICE-130000-27{PMt.MONATE_KALSHI[mon_ - 1]}{tag_:02d}"
            pmm("kalshi", n_, "KXBTCPRICE-130000", "KXBTCPRICE", "beruehrung", "greater", 130000.0, None, E(2027, mon_, tag_, 23, 59))
            pmk("kalshi", n_, g_, b_)
        pmm("kalshi", "KXBTCPRICE-X-27JUL08", "KXBTCPRICE-X", "KXBTCPRICE", "beruehrung", None, None, None, E(2027, 7, 8, 23, 59))
        pmk("kalshi", "KXBTCPRICE-X-27JUL08", 400, 600)
        # (d) Kalshi Fristen-Leiter mit zwei Horizonten: 20 Tage (Steigung 1,09) und 202 Tage (1,36), derselbe Rohwert
        pmm("kalshi", "KXBTCMAX150-A", "KXBTCMAX150-26", "KXBTCMAX150", "beruehrung", "greater", 149999.99, None, JP + 20 * TAG)
        pmk("kalshi", "KXBTCMAX150-A", 2900, 3100)
        pmm("kalshi", "KXBTCMAX150-B", "KXBTCMAX150-26", "KXBTCMAX150", "beruehrung", "greater", 149999.99, None, JP + 202 * TAG)
        pmk("kalshi", "KXBTCMAX150-B", 2900, 3100)
        # (e) Kalshi Jahresendkurs in Spannen; die oberste Spanne mit altem Kurs (5 Stunden) -- sie zählt 0
        for i_, (st_, u_, o_, g_, b_) in enumerate((("less", None, 44999.99, 300, 500), ("between", 45000.0, 49999.99, 500, 700),
                                                    ("between", 50000.0, 54999.99, 1900, 2100), ("between", 55000.0, 59999.99, 2900, 3100),
                                                    ("between", 60000.0, 64999.99, 2500, 2700), ("between", 65000.0, 69999.99, 1300, 1500),
                                                    ("between", 70000.0, 74999.99, 400, 600), ("greater", 75000.0, None, 900, 1100))):
            pmm("kalshi", f"KXBTCY-27JAN0100-B{i_}", "KXBTCY-27JAN0100", "KXBTCY", "spanne", st_, u_, o_, JE)
            pmk("kalshi", f"KXBTCY-27JAN0100-B{i_}", g_, b_, alter=5 * 3600 if st_ == "greater" else 600)
        # (f) Polymarket Fristen-Leiter am Niveau 100.000 (eine Frist in 3 Tagen bleibt außen vor), Jahresleiter mit einem entschiedenen Markt
        for i_, (ende_, g_, b_) in enumerate(((E(2026, 11, 26, 0, 0), 50, 150), (JE, 150, 250), (E(2027, 4, 1, 0, 0), 1100, 1300),
                                              (E(2027, 7, 1, 0, 0), 2000, 2200), (E(2027, 10, 1, 0, 0), 3200, 3400),
                                              (E(2028, 1, 1, 0, 0), 4500, 4700))):
            pmm("polymarket", f"0xfrist{i_}", "when-will-bitcoin-hit-100k", "PMfrist", "beruehrung", "greater", 100000.0, None, ende_,
                ablauf=E(2028, 1, 1, 0, 0), slug=f"will-bitcoin-hit-100k-by-frist-{i_}",
                titel="Will Bitcoin hit $100k?", regeln="This market will resolve to Yes if any Binance 1 minute candle for BTC/USDT has a final High price of 100,000 or higher.")
            pmk("polymarket", f"0xfrist{i_}", g_, b_)
        for name_, st_, k_, g_, b_ in (("0xj1", "greater", 70000.0, 1900, 2100), ("0xj0", "greater", 80000.0, 500, 700),
                                       ("0xj3", "less", 55000.0, 4900, 5100), ("0xj4", "less", 50000.0, 2400, 2600),
                                       ("0xj60", "less", 60000.0, 9800, 9990)):
            pmm("polymarket", name_, "what-price-will-bitcoin-hit-before-2027", "PMberuehrung", "beruehrung", st_,
                k_ if st_ == "greater" else None, k_ if st_ == "less" else None, JE)
            pmk("polymarket", name_, g_, b_)
        with PMt.schreiben(cp):                                              # zwei Fassungen: erst „Nein“ gemeldet, dann „Ja“ -- die jüngste gilt
            PMt.ergebnis_speichern(cp, "polymarket", "0xj60", 0, None, None, int(JP - 6 * TAG), int(JP - 6 * TAG))
            PMt.ergebnis_speichern(cp, "polymarket", "0xj60", 1, None, None, int(JP - 5 * TAG), int(JP - 5 * TAG))
        # außen vor: ETH-Leiter (anderer Basiswert), Tagesleiter für morgen (Frist unter 7 Tagen)
        pmm("polymarket", "0xeth", "what-price-will-ethereum-hit-before-2027", "PMberuehrung", "beruehrung", "greater", 3000.0, None, JE, basis="ETH")
        pmk("polymarket", "0xeth", 1900, 2100)
        pmm("polymarket", "0xtag", "what-price-will-bitcoin-hit-on-november-23-2026", "PMberuehrung", "beruehrung", "greater", 62000.0, None, JP + TAG)
        pmk("polymarket", "0xtag", 1900, 2100)
        # (g) Fed: abgerechnete Sitzung (Satz 4,00), Dezember sauber, Januar mit Lücke und einer Stelle gegen die Ordnung, März nur eine Schwelle
        pmm("kalshi", "KXFED-26OCT-T3.75", "KXFED-26OCT", "KXFED", "makro", "greater", 3.75, None, JP - 25 * TAG, basis=None)
        with PMt.schreiben(cp):
            PMt.ergebnis_speichern(cp, "kalshi", "KXFED-26OCT-T3.75", 1, None, 4.0, int(JP - 25 * TAG), int(JP - 25 * TAG))
        pmm("kalshi", "KXFED-26SEP-T4.00", "KXFED-26SEP", "KXFED", "makro", "greater", 4.0, None, JP - 67 * TAG, basis=None)
        with PMt.schreiben(cp):
            PMt.ergebnis_speichern(cp, "kalshi", "KXFED-26SEP-T4.00", 1, None, 4.25, int(JP - 67 * TAG), int(JP - 67 * TAG))
        FD, FJ, FM = JP + 17 * TAG - 7200, JP + 66 * TAG - 7200, JP + 115 * TAG - 7200
        for k_, g_, b_ in ((3.25, 9700, 9900), (3.50, 8900, 9100), (3.75, 2900, 3100), (4.00, 100, 300)):
            pmm("kalshi", f"KXFED-26DEC-T{k_:.2f}", "KXFED-26DEC", "KXFED", "makro", "greater", k_, None, FD, basis=None)
            pmk("kalshi", f"KXFED-26DEC-T{k_:.2f}", g_, b_)
        for k_, g_, b_, alter_ in ((3.00, 9600, 9800, 600), (3.25, 7900, 8100, 600), (3.75, 3900, 4100, 600), (4.00, 4300, 4500, 600),
                                   (4.25, 100, 300, 5 * 3600)):
            pmm("kalshi", f"KXFED-27JAN-T{k_:.2f}", "KXFED-27JAN", "KXFED", "makro", "greater", k_, None, FJ, basis=None)
            pmk("kalshi", f"KXFED-27JAN-T{k_:.2f}", g_, b_, alter=alter_)
        pmm("kalshi", "KXFED-27MAR-T3.50", "KXFED-27MAR", "KXFED", "makro", "greater", 3.5, None, FM, basis=None)
        pmk("kalshi", "KXFED-27MAR-T3.50", 4900, 5100)
        # (h) Ereignisse: Entscheid im Dezember (Kalshi), Rezession; Polymarket mit und ohne „Fed“ im Titel
        for kenn_, g_, b_ in (("C25", 5900, 6100), ("H0", 3700, 3900), ("C26", 100, 300)):
            pmm("kalshi", f"KXFEDDECISION-26DEC-{kenn_}", "KXFEDDECISION-26DEC", "KXFEDDECISION", "ereignis", None, None, None, FD,
                basis=None, titel="Fed decision in Dec 2026?")
            pmk("kalshi", f"KXFEDDECISION-26DEC-{kenn_}", g_, b_)
        pmm("kalshi", "KXRECSSNBER-27", "KXRECSSNBER-27", "KXRECSSNBER", "ereignis", None, None, None, JP + 400 * TAG, basis=None,
            titel="Will there be a recession in 2027?")
        pmk("kalshi", "KXRECSSNBER-27", 2100, 2300)
        pmm("polymarket", "0xfed1", "fed-decision-in-december", "PMmakro", "makro", None, None, None, FD, basis=None,
            titel="Fed decreases interest rates by 25 bps after December 2026 meeting?")
        pmk("polymarket", "0xfed1", 5800, 6000)
        pmm("polymarket", "0xcpi1", "november-inflation-us-monthly", "PMmakro", "makro", None, None, None, FD, basis=None,
            titel="Will inflation be 0.3% in November?")
        pmk("polymarket", "0xcpi1", 3000, 3200)
        with PMt.schreiben(cp):
            PMt.spot_speichern(cp, "BTC", [(int(JP) - 120, 60800.0, 60850.0, 60790.0, 60812.0)], PMt.SPOT_QUELLE["BTC"][0], int(JP))
        cp.close()

        cl = PMt.lesen(pm_db)
        k55 = pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-55000", JP)
        k45 = pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-45000", JP)
        k40 = pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-40000", JP)
        k50 = pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-50000", JP)
        ok("P1 Kurs eines Markts (nur lesen): Mitte aus Geld und Brief bei höchstens 4 Punkten Spread (53 · 55 -> 54,0 %); bei weitem "
           "Spread (10 · 22) der letzte Handel (16,0 %, „Handel“); gibt es Mitte UND Handel (27 · 29, Handel 35), gilt die Mitte; ohne "
           "Mitte und ohne Handel kein Wert; das Alter zählt ab dem letzten Abruf mit denselben Werten (erste Beobachtung vor 4.000 s, "
           "letzter Abruf vor 600 s -> 600 s); ein Markt ohne gespeicherten Kurs gibt nichts; kein Kurs aus der Zukunft (Stand eine Stunde früher: der erst vor 600 s "
           "gesehene Kurs fehlt; der seit 4.000 s unveränderte gilt mit Alter 0; eine Sekunde vor seiner ersten Beobachtung fehlt auch er)",
           k55 and nah(k55["p"], 0.54) and k55["aus"] == "Mitte" and nah(k55["spread"], 0.02) and k55["alter_s"] == 600
           and nah(k55["geld"], 0.53) and nah(k55["brief"], 0.55) and k55["ts"] == int(JP - 4000) and k55["bis"] == int(JP - 600)
           and k50 and nah(k50["p"], 0.28) and k50["aus"] == "Mitte" and nah(k50["letzter"], 0.35)
           and k45 and nah(k45["p"], 0.16) and k45["aus"] == "Handel" and nah(k45["spread"], 0.12)
           and k40 is not None and k40["p"] is None and k40["aus"] is None
           and pm_kurs(cl, "kalshi", "GIBT-ES-NICHT", JP) is None and pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-50000", JP - 3600) is None
           and pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-55000", JP - 3600)["alter_s"] == 0
           and nah(pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-55000", JP - 3600)["p"], 0.54)
           and pm_kurs(cl, "kalshi", "KXBTCMINY-27JAN01-55000", JP - 4001) is None,
           f"55.000: {k55 and (k55['p'], k55['aus'], k55['alter_s'])} · 45.000: {k45 and (k45['p'], k45['aus'])} · 40.000: {k40 and k40['p']}")
        ok("P2 Niveau und Richtung: „less“ mit der oberen Grenze heißt „unter“, sonst die untere Grenze „ueber“; nur eine obere Grenze "
           "heißt „unter“; ohne Grenze nichts",
           pm_niveau({"strike_typ": "less", "oben": 55000.0}) == ("unter", 55000.0)
           and pm_niveau({"strike_typ": "greater", "unten": 99999.99}) == ("ueber", 99999.99)
           and pm_niveau({"strike_typ": "greater_or_equal", "unten": 3.5, "oben": 9.0}) == ("ueber", 3.5)
           and pm_niveau({"strike_typ": None, "oben": 7.0}) == ("unter", 7.0) and pm_niveau({"strike_typ": "less_or_equal", "unten": 2.0}) == ("unter", 2.0)
           and pm_niveau({"strike_typ": "less", "unten": 1.0, "oben": 2.0}) == ("unter", 2.0)
           and pm_niveau({"strike_typ": "greater"}) == (None, None) and pm_niveau({}) == (None, None))
        cl.close()
        vorher = (os.path.getsize(pm_db), hashlib.sha256(open(pm_db, "rb").read()).hexdigest())
        PB = pm_bestand(pm_db, JP)
        nachher = (os.path.getsize(pm_db), hashlib.sha256(open(pm_db, "rb").read()).hexdigest())
        G = {(g["plattform"], g["ereignis"]): g for g in (PB.get("gruppen") or [])}
        soll_g = {("kalshi", "KXBTCMINY-27JAN01"): ("schwellen", 5, 4, 0), ("kalshi", "KXBTCMAXY-26DEC31"): ("schwellen", 2, 1, 0),
                  ("kalshi", "KXBTCPRICE-130000"): ("fristen", 3, 3, 0), ("kalshi", "KXBTCPRICE-X"): ("schwellen", 1, 1, 0),
                  ("kalshi", "KXBTCMAX150-26"): ("fristen", 2, 2, 0), ("kalshi", "KXBTCY-27JAN0100"): ("spannen", 8, 7, 0),
                  ("polymarket", "when-will-bitcoin-hit-100k"): ("fristen", 5, 5, 0),
                  ("polymarket", "what-price-will-bitcoin-hit-before-2027"): ("schwellen", 5, 4, 1)}
        ist_g = {k_: (g["form"], len(g["zeilen"]), g["frisch"], g["entschieden"]) for k_, g in G.items()}
        ok("P3 Bestand: acht Ereignisse mit Form, Zahl der Märkte, frischen Kursen und entschiedenen Märkten -- Schwellen (eine Frist), "
           "Fristen (ein Niveau, mehrere Fristen), Spannen; außen vor bleiben der andere Basiswert (ETH), die Frist in 3 Tagen und die "
           "Tagesleiter für morgen; geordnet nach der ersten Frist; die Datei ist danach Byte für Byte dieselbe",
           PB.get("ok") is True and ist_g == soll_g and vorher == nachher
           and [g["fristen"][0] for g in PB["gruppen"]] == sorted(g["fristen"][0] for g in PB["gruppen"])
           and PB["gruppen"][0]["ereignis"] == "KXBTCMAX150-26" and nah(PB["spot"]["kurs"], 60812.0)
           and [z_["niveau"] for z_ in G[("polymarket", "what-price-will-bitcoin-hit-before-2027")]["zeilen"]] == [50000.0, 55000.0, 60000.0, 70000.0, 80000.0]
           and [z_["ende"] for z_ in G[("polymarket", "when-will-bitcoin-hit-100k")]["zeilen"]] == [JE, E(2027, 4, 1, 0, 0), E(2027, 7, 1, 0, 0), E(2027, 10, 1, 0, 0), E(2028, 1, 1, 0, 0)],
           str({k_[1]: v for k_, v in ist_g.items() if soll_g.get(k_) != v}) + f" · {len(ist_g)} Ereignisse")
        zr = lambda ereignis, art, richtung, niveau, ende: {"plattform": "kalshi", "markt": f"{ereignis}-{niveau}-{ende}", "ereignis": ereignis,
                                                           "reihe": "R", "art": art, "richtung": richtung, "niveau": niveau, "unten": niveau,
                                                           "ende": ende, "frisch": True, "ergebnis": None, "regeln": "", "titel": ""}
        gf = {g["ereignis"]: g["form"] for g in pm_gruppen(
            [zr("GEM", "beruehrung", "ueber", 1.0, 100), zr("GEM", "beruehrung", "ueber", 2.0, 100), zr("GEM", "beruehrung", "ueber", 1.0, 200),
             zr("ART", "spanne", None, 1.0, 100), zr("ART", "beruehrung", "ueber", 2.0, 100),
             zr("EIN", "beruehrung", "ueber", 1.0, 100), zr("SPA", "spanne", None, 1.0, 100), zr("SPA", "spanne", None, 2.0, 100),
             zr("ZWEI", "beruehrung", "ueber", 5.0, 100), zr("ZWEI", "beruehrung", "ueber", 5.0, 200)])}
        ok("P3b Form einer Gruppe: zwei Niveaus UND zwei Fristen heißen „gemischt“ (nicht Fristen); eine Spanne neben einem "
           "Berührungsmarkt ist keine Spannen-Gruppe; ein einzelner Markt und eine Frist mit mehreren Niveaus sind „schwellen“; ein "
           "Niveau mit zwei Fristen ist „fristen“; nur Spannen sind „spannen“",
           gf == {"GEM": "gemischt", "ART": "schwellen", "EIN": "schwellen", "SPA": "spannen", "ZWEI": "fristen"}, str(gf))
        rz = {z["markt"]: z for g in G.values() for z in g["zeilen"]}
        lg = lambda p_, st_: 1.0 / (1.0 + math.exp(-st_ * math.log(p_ / (1.0 - p_))))
        ok("P4 Zeilen: der rekalibrierte Wert rechnet mit der Frist des einzelnen Markts (Regel 1.6) -- 54,0 % bei 39 Tagen -> 55,4 %; "
           "28,0 % -> 21,7 %; 16,0 % -> 9,5 %; derselbe Rohwert 30,0 % bei 20 Tagen -> 28,4 % (Steigung 1,09) und bei 202 Tagen -> "
           "24,0 % (1,36); frisch ist ein Kurs bis 3 Stunden nach dem letzten Abruf und nur, wenn der Markt nicht entschieden ist; "
           "ein Markt, den die Börse nicht mehr listet, ist als solcher erkannt",
           nah(rz["KXBTCMINY-27JAN01-55000"]["p_rekal"], lg(0.54, 1.36)) and abs(rz["KXBTCMINY-27JAN01-55000"]["p_rekal"] - 0.5543) < 5e-5
           and abs(rz["KXBTCMINY-27JAN01-50000"]["p_rekal"] - 0.2168) < 5e-5 and abs(rz["KXBTCMINY-27JAN01-45000"]["p_rekal"] - 0.0949) < 5e-5
           and nah(rz["KXBTCMAX150-A"]["p_rekal"], lg(0.30, 1.09)) and nah(rz["KXBTCMAX150-B"]["p_rekal"], lg(0.30, 1.36))
           and abs(rz["KXBTCMAX150-A"]["p_rekal"] - 0.2842) < 1e-4 and abs(rz["KXBTCMAX150-B"]["p_rekal"] - 0.2401) < 1e-4
           and nah(rz["KXBTCMAX150-A"]["tage"], 20.0) and nah(rz["KXBTCMAX150-B"]["tage"], 202.0)
           and nah(rz["0xfrist2"]["p_rekal"], lg(0.12, 1.36)) and abs(rz["0xfrist2"]["p_rekal"] - 0.0624) < 5e-5
           and rz["KXBTCMINY-27JAN01-40000"]["frisch"] is False and rz["KXBTCMINY-27JAN01-40000"]["p_rekal"] is None
           and rz["0xj60"]["frisch"] is False and rz["0xj60"]["ergebnis"] == 1 and rz["0xj60"]["gelistet"] is True
           and rz["KXBTCMAXY-26DEC31-99999.99"]["frisch"] is False and rz["KXBTCMAXY-26DEC31-99999.99"]["gelistet"] is False
           and rz["KXBTCMAXY-26DEC31-109999.99"]["frisch"] is True and rz["KXBTCMAXY-26DEC31-109999.99"]["gelistet"] is True,
           f"55.000: {rz['KXBTCMINY-27JAN01-55000']['p_rekal']:.4f} · 20 T: {rz['KXBTCMAX150-A']['p_rekal']:.4f} · 202 T: {rz['KXBTCMAX150-B']['p_rekal']:.4f}")
        # eine Grenze je Seite der 3 Stunden
        cg = PMt.verbinden(os.path.join(tmp, "pm_grenze.db"))
        for name_, alter_ in (("A", PM_FRISCH_S), ("B", PM_FRISCH_S + 1)):
            with PMt.schreiben(cg):
                PMt.markt_speichern(cg, {"plattform": "kalshi", "markt": "KXBTCMAXY-G-" + name_, "ereignis": "KXBTCMAXY-G", "reihe": "KXBTCMAXY",
                                         "art": "beruehrung", "basis": "BTC", "strike_typ": "greater", "unten": 90000.0, "ende": int(JP + 40 * TAG)},
                                    int(JP - alter_))
                PMt.kurs_speichern(cg, "kalshi", "KXBTCMAXY-G-" + name_, int(JP - alter_), "live", 2900, 3100, None, None, int(JP - alter_))
        cg.close()
        gz = {z["markt"][-1]: z for g in pm_bestand(os.path.join(tmp, "pm_grenze.db"), JP)["gruppen"] for z in g["zeilen"]}
        ok("P4b Grenze „frisch“: genau 3 Stunden nach dem letzten Abruf noch frisch und gelistet, eine Sekunde später nicht mehr",
           gz["A"]["frisch"] is True and gz["A"]["gelistet"] is True and gz["B"]["frisch"] is False and gz["B"]["gelistet"] is False
           and nah(gz["A"]["p"], 0.30) and nah(gz["B"]["p"], 0.30), str({k_: (v["frisch"], v["gelistet"]) for k_, v in gz.items()}))
        sp = G[("kalshi", "KXBTCY-27JAN0100")]["spannen"] or {}
        s_soll = {45000.0: 1.01 / 1.05, 50000.0: 0.95 / 1.05, 55000.0: 0.75 / 1.05, 60000.0: 0.45 / 1.05, 65000.0: 0.19 / 1.05,
                  70000.0: 0.05 / 1.05, 75000.0: 0.0}
        rest_sp = JE - JP
        r50 = lg(0.75 / 1.05, 1.36); r60 = lg(0.45 / 1.05, 1.36)
        q50r_hand = 55000.0 + (r50 - 0.5) / (r50 - r60) * 5000.0
        ok("P5 Kurs am Stichtag aus Spannen: Rohkurse 4 · 6 · 20 · 30 · 26 · 14 · 5 Punkte (Summe 1,05, auf 1 gebracht), die oberste "
           "Spanne ohne Kurs zählt 0; über 50.000 liegen 90,5 %, über 55.000 71,4 %; Ränder roh 50.125 · 54.062,5 · 58.750 · 63.605,8 · "
           "68.035,7 (gerade zwischen den Grenzen); rekalibriert liegt die Mitte bei 58.706 und die Ränder rücken zur Mitte; die "
           "wahrscheinlichste Spanne ist 55.000 bis 59.999,99 mit 28,6 %",
           sp.get("n") == 8 and sp.get("ohne_kurs") == 1 and nah(sp.get("summe"), 1.05)
           and len(sp.get("punkte", [])) == 7 and all(nah(s_, s_soll[k_], 1e-12) for k_, s_ in sp["punkte"])
           and nah(sp["q"][10], 50125.0, 1e-6) and nah(sp["q"][25], 54062.5, 1e-6) and nah(sp["q"][50], 58750.0, 1e-6)
           and nah(sp["q"][75], 60000.0 + (0.45 - 0.2625) / 0.26 * 5000.0, 1e-6) and abs(sp["q"][75] - 63605.77) < 0.01
           and nah(sp["q"][90], 65000.0 + (0.19 - 0.105) / 0.14 * 5000.0, 1e-6) and abs(sp["q"][90] - 68035.71) < 0.01
           and nah(sp["q_rekal"][50], q50r_hand, 1e-6) and abs(q50r_hand - 58706.1) < 0.1 and 39 < rest_sp / TAG < 40
           and sp["q_rekal"][10] > sp["q"][10] and sp["q_rekal"][90] < sp["q"][90]
           and sp["beste"][0] == 55000.0 and sp["beste"][1] == 59999.99 and nah(sp["beste"][2], 0.30 / 1.05),
           f"Ränder roh {[round(sp['q'][r], 1) if sp.get('q', {}).get(r) else None for r in RAENDER]} · Mitte rekal. {sp.get('q_rekal', {}).get(50)}")
        dreh = pm_spannen([{"strike_typ": "less", "unten": None, "oben": 9.99, "p": 0.6, "frisch": True},
                           {"strike_typ": "between", "unten": 10.0, "oben": 19.99, "p": 0.3, "frisch": True},
                           {"strike_typ": "greater", "unten": 20.0, "oben": None, "p": 0.1, "frisch": True}], 40 * TAG)
        ok("P5b Spannen am Rand: Liegt die Marke unter der untersten oder über der obersten Grenze, gibt es keinen Rand (kein Wert "
           "jenseits der Leiter); zwei Spannen reichen nicht für eine Verteilung; ohne frischen Kurs keine",
           dreh and dreh["q"][10] is None and dreh["q"][25] is None and dreh["q"][50] is None and nah(dreh["q"][75], 10.0 + (0.4 - 0.25) / 0.3 * 10.0)
           and nah(dreh["q"][90], 20.0) and nah(dreh["punkte"][0][1], 0.4) and nah(dreh["punkte"][1][1], 0.1)
           and pm_spannen([{"strike_typ": "less", "unten": None, "oben": 9.99, "p": 0.6, "frisch": True},
                           {"strike_typ": "greater", "unten": 10.0, "oben": None, "p": 0.4, "frisch": True}], 40 * TAG) is None
           and pm_spannen([{"strike_typ": "between", "unten": float(i_), "oben": i_ + 0.99, "p": 0.3, "frisch": False} for i_ in range(4)], 40 * TAG) is None,
           str(dreh and dreh["q"]))
        FED = PB.get("fed") or {}
        S = {s_["ereignis"]: s_ for s_ in FED.get("sitzungen", [])}
        vd, vj = (S.get("KXFED-26DEC") or {}).get("v") or {}, (S.get("KXFED-27JAN") or {}).get("v") or {}
        ok("P6 Fed-Pfad: Dezember -- über 3,25 / 3,50 / 3,75 / 4,00 stehen 98 · 90 · 30 · 2 %, also 3,25: 2 %, 3,50: 8 %, 3,75: 60 %, "
           "4,00: 28 %, 4,25: 2 %; häufigster Satz 3,75 % (60 %), Mittel 3,80 %, gegen den Satz nach der JÜNGSTEN abgerechneten Sitzung "
           "(Oktober 4,00 %, nicht September 4,25 %) −0,20. Januar -- die Schwelle 3,50 fehlt (eine Lücke, ihre Masse zählt in der Mitte bei 3,625), 40 % und 44 % "
           "laufen gegen die Ordnung und werden zu 42 % geglättet, die alte Schwelle 4,25 zählt nicht: Mittel 3,805 %, über der Leiter "
           "42 %. März: eine Schwelle, keine Verteilung",
           FED.get("heute") == {"ereignis": "KXFED-26OCT", "ende": int(JP - 25 * TAG), "satz": 4.0}
           and [s_["ereignis"] for s_ in FED["sitzungen"]] == ["KXFED-26DEC", "KXFED-27JAN", "KXFED-27MAR"]
           and vd.get("n") == 4 and [round(w_, 6) for w_, _ in vd["werte"]] == [3.25, 3.5, 3.75, 4.0, 4.25]
           and all(nah(m_, s_, 1e-12) for (_, m_), s_ in zip(vd["werte"], (0.02, 0.08, 0.60, 0.28, 0.02)))
           and nah(vd["mittel"], 3.80, 1e-12) and nah(vd["haeufig"][0], 3.75) and nah(vd["haeufig"][1], 0.60, 1e-12)
           and nah(vd["unter"], 0.02, 1e-12) and nah(vd["ueber"], 0.02, 1e-12) and vd["luecken"] == 0
           and nah(S["KXFED-26DEC"]["gegen_heute"], -0.20, 1e-12) and S["KXFED-26DEC"]["frisch"] == 4 and S["KXFED-26DEC"]["maerkte"] == 4
           and vj.get("n") == 4 and vj["luecken"] == 1 and S["KXFED-27JAN"]["frisch"] == 4 and S["KXFED-27JAN"]["maerkte"] == 5
           and [round(w_, 6) for w_, _ in vj["werte"]] == [3.0, 3.25, 3.625, 4.0, 4.25]
           and all(nah(m_, s_, 1e-12) for (_, m_), s_ in zip(vj["werte"], (0.03, 0.17, 0.38, 0.0, 0.42)))
           and nah(vj["mittel"], 3.805, 1e-12) and nah(vj["ueber"], 0.42, 1e-12) and nah(vj["haeufig"][0], 4.25)
           and vj["haeufig_rand"] == "ueber" and vd["haeufig_rand"] is None
           and pm_stufen([(3.375, 0.3), (3.625, 0.1)])["haeufig_rand"] == "unter"
           and S["KXFED-27MAR"]["v"] is None and S["KXFED-27MAR"]["frisch"] == 1 and S["KXFED-27MAR"]["gegen_heute"] is None,
           f"Dez {vd.get('mittel')} {vd.get('haeufig')} · Jan {vj.get('mittel')} Lücken {vj.get('luecken')} · heute {FED.get('heute')}")
        ok("P6b Zins-Leiter allein: eine Schwelle „≥ 3,50“ und eine „> 3,50“ liegen auf verschiedenen Grenzen (3,375 und 3,625); zwei "
           "Kurse an derselben Grenze werden gemittelt; eine einzelne Grenze gibt keine Verteilung",
           PMt._leiter_punkt("greater_or_equal", 3.5, None, 0.9, PM_FED_SCHRITT) == (3.375, 0.9)
           and PMt._leiter_punkt("greater", 3.5, None, 0.6, PM_FED_SCHRITT) == (3.625, 0.6)
           and pm_stufen([(3.375, 0.9), (3.625, 0.5), (3.625, 0.7)])["werte"] == [(3.25, 1.0 - 0.9), (3.5, 0.9 - 0.6), (3.75, 0.6)]
           and pm_stufen([(3.375, 0.9)]) is None and pm_stufen([]) is None)
        hin = [h for g in PB["gruppen"] for h in g["hinweise"]]
        ok("P7 Ordnung: Am Jahrestief steht 45.000 mit 16,0 % unter 35.000 mit 30,0 % -- gemeldet; an der Fristen-Leiter 130.000 steht "
           "die Frist 08.07.2027 mit 5,0 % unter der Frist 10.06.2027 mit 10,0 % -- gemeldet; Abstände bis 2 Punkte und saubere Leitern "
           "bleiben ohne Hinweis (genau zwei Hinweise)",
           len(hin) == 2 and any("KXBTCMINY-27JAN01" in h and "45.000" in h and "16,0 %" in h and "35.000" in h and "30,0 %" in h for h in hin)
           and any("KXBTCPRICE-130000" in h and "08.07.2027" in h and "5,0 %" in h and "10.06.2027" in h and "10,0 %" in h for h in hin)
           and pm_ordnung({"form": "fristen", "art": "beruehrung", "ereignis": "E", "zeilen": [
               {"frisch": True, "p": 0.30, "ende": JE}, {"frisch": True, "p": 0.28, "ende": JE + TAG}, {"frisch": False, "p": 0.01, "ende": JE + 2 * TAG}]}) == []
           and len(pm_ordnung({"form": "schwellen", "art": "beruehrung", "ereignis": "E", "zeilen": [
               {"frisch": True, "p": 0.30, "richtung": "ueber", "niveau": 1.0}, {"frisch": True, "p": 0.33, "richtung": "ueber", "niveau": 2.0},
               {"frisch": True, "p": 0.50, "richtung": "unter", "niveau": 0.5}, {"frisch": True, "p": 0.47, "richtung": "unter", "niveau": 0.6}]})) == 2
           and pm_ordnung({"form": "schwellen", "art": "beruehrung", "ereignis": "E", "zeilen": [
               {"frisch": True, "p": 0.30, "richtung": "ueber", "niveau": 1.0}, {"frisch": True, "p": 0.31, "richtung": "ueber", "niveau": 2.0},
               {"frisch": True, "p": 0.50, "richtung": "unter", "niveau": 0.5}, {"frisch": True, "p": 0.49, "richtung": "unter", "niveau": 0.6}]}) == [],
           " | ".join(hin))
        EV = {e_["ereignis"]: e_ for e_ in PB.get("ereignisse", [])}
        PF = [e_["ereignis"] for e_ in PB.get("poly_fed", [])]
        ok("P8 Ereignisse: der Entscheid im Dezember mit drei Ausgängen, nach Kurs geordnet (C25 60 %, H0 38 %, C26 2 %), die Rezession "
           "mit 22 %; bei Polymarket nur das Ereignis mit „Fed“ im Titel, das zur Inflation nicht",
           set(EV) == {"KXFEDDECISION-26DEC", "KXRECSSNBER-27"}
           and [(z_["markt"][-3:].lstrip("-"), round(z_["p"], 4)) for z_ in EV["KXFEDDECISION-26DEC"]["zeilen"]] == [("C25", 0.60), ("H0", 0.38), ("C26", 0.02)]
           and nah(EV["KXRECSSNBER-27"]["zeilen"][0]["p"], 0.22) and PF == ["fed-decision-in-december"], str(sorted(EV)) + " " + str(PF))
        T2 = pm_text(PB)
        t2 = "\n".join(T2)
        z55 = next((x for x in T2 if x.strip().startswith("55.000") and "berührt nach unten" in x and "Mitte" in x and "53,0" in x), "")
        z45 = next((x for x in T2 if x.strip().startswith("45.000") and "Handel" in x), "")
        z40 = next((x for x in T2 if x.strip().startswith("40.000")), "")
        zdez = next((x for x in T2 if "KXFED-26DEC" in x), "")
        zjan = next((x for x in T2 if "KXFED-27JAN" in x), "")
        t9 = {"Abschnitte": all(f"\n{i_} " in "\n" + t2 for i_ in range(1, 7)) and "1 BESTAND" in t2 and "6 HINWEISE" in t2,
              "Zeile 55.000": "54,0 %" in z55 and "55,4 %" in z55 and "53,0 · 55,0" in z55 and "10 min" in z55,
              "Zeile 45.000": "16,0 %" in z45 and "9,5 %" in z45 and "10,0 · 22,0" in z45,
              "Zeile 40.000": "kein Kurs lesbar" in z40,
              "Hinweise je Markt": "entschieden: Ja" in t2 and "der Markt ist nicht mehr gelistet" in t2 and "Niveau fehlt" in t2,
              "Abschnitt 6": "KXBTCPRICE-X: 1 Markt ohne Niveau" in t2 and "KXFED-27JAN: jenseits der Leiter liegen 3,0 % darunter und 42,0 % darüber" in t2
              and "KXFED-26DEC: jenseits" not in t2 and t2.count("gegen die Ordnung neben") == 1 and t2.count("unter der früheren Frist") == 1,
              "Kopf der Fristen-Leiter": "Polymarket when-will-bitcoin-hit-100k · Niveau 100.000 · berührt nach oben · 5 Fristen" in t2,
              "Fristen als Tag in New York": all(f"{d_}  " in t2 for d_ in ("31.12.2026", "31.03.2027", "30.06.2027", "30.09.2027", "31.12.2027")),
              "Ränder aus Spannen": "Ränder 10 · 25 · 50 · 75 · 90 %:  roh 50.125 · 54.062 · 58.750 · 63.606 · 68.036" in t2 and "rekalibriert " in t2,
              "wahrscheinlichste Spanne": "wahrscheinlichste Spanne: 55.000 bis 59.999,99 mit 28,6 %" in t2,
              "Satz heute": "Satz nach der zuletzt abgerechneten Sitzung (KXFED-26OCT" in t2 and "4,00 %" in t2,
              "Dezember": "3,75 % (60 %)" in zdez and "3,80 %" in zdez and "−0,20" in zdez and "4 von 4" in zdez,
              "Januar": "≥ 4,25 % (42 %)" in zjan and "4 von 5" in zjan and "3,0 % · 42,0 %" in zjan
              and "3,875 42 % · 4,125 42 %   (1 Lücke: dazwischen fehlt eine Schwelle mit frischem Kurs)" in t2,
              "März": "keine Verteilung" in t2,
              "Regel der Börse": "Regel der Börse (Anfang): „If the price of Bitcoin is below the threshold at any time" in t2,
              "erster Markt": "Erster Markt: Kennung KXBTCMINY-27JAN01-35000 · Titel „How low will Bitcoin get in 2026?“" in t2
              and "Erster Markt: Kennung will-bitcoin-hit-100k-by-frist-1 · Titel „Will Bitcoin hit $100k?“" in t2
              and "Erster Markt: Kennung 0xj4 · Titel „“" in t2 and t2.count("Erster Markt: Kennung ") == 8,
              "Handelsende": "Handelsende laut Börse (Feld endDate): für alle 31.12.2027 -- die Frist oben stammt aus dem Gruppentitel" in t2
              and t2.count("Handelsende laut Börse") == 1,
              "Ereignisse": "KXFEDDECISION-26DEC · Frist 09.12.2026 · 3 von 3 frisch: C25 60,0 % · H0 38,0 % · C26 2,0 %" in t2
              and "KXRECSSNBER-27 · Frist 27.12.2027 · 1 von 1 frisch: Ja 22,0 %" in t2
              and "fed-decision-in-december · Frist 09.12.2026 · 1 von 1 frisch: „Fed decreases interest rates by 25 bps after December 2026 meeting?“ 59,0 %" in t2,
              "Einzahl und Art": "· 1 Markt\n" in t2 and "Berührung " in t2 and "· 2 Märkte\n" in t2,
              "Stand": T2[0].startswith("  Stand: jüngster Kurs der gelesenen BTC-Märkte -- Kalshi ") and "Spot 60.812 USD (coinbase, " in T2[0],
              "außen vor": "november-inflation" not in t2 and "what-price-will-ethereum" not in t2 and "november-23-2026" not in t2,
              "Breite": max(len(x) for x in T2) <= 150,
              "Schluss": any("Gespeichert wurde nichts" in x for x in T2[-6:]) and "Lesart: " in t2 and "Regel 1.6" in t2}
        ok("P9 Text (Debug 159): sechs Abschnitte; die Zeile 55.000 des Jahrestiefs trägt „berührt nach unten“, 54,0 %, 55,4 %, "
           "„53,0 · 55,0“, „Mitte“ und „10 min“; 45.000 trägt „Handel“; 40.000 „kein Kurs lesbar“; der entschiedene Markt „entschieden: "
           "Ja“; der nicht mehr gelistete „nicht mehr gelistet“; der Markt ohne Niveau „Niveau fehlt“; die Fristen-Leiter 100.000 nennt "
           "ihre Fristen als letzten Tag in New York (31.12.2026 bis 31.12.2027); Spannen mit beiden Reihen von Rändern; der Fed-Pfad "
           "mit Dezember (3,75 % (60 %), 3,80 %, −0,20) und Januar (eine Lücke); die Regel der Börse steht als eine Zeile da; keine "
           "Zeile über 150 Zeichen; am Ende „Gespeichert wurde nichts“",
           all(t9.values()),
           "nicht erfüllt: " + (", ".join(k_ for k_, v_ in t9.items() if not v_) or "—") + " · " +
           f"{len(T2)} Zeilen, längste {max(len(x) for x in T2)} · {z55.strip()[:110]}")
        leer_db = os.path.join(tmp, "pm_leer.db")
        PMt.verbinden(leer_db).close()
        tl = "\n".join(pm_text(pm_bestand(leer_db, JP)))
        tf = pm_text(pm_bestand(os.path.join(tmp, "gibt_es_nicht", "prognosemarkt.db"), JP))
        kaputt = os.path.join(tmp, "pm_kaputt.db")
        with open(kaputt, "wb") as f_:
            f_.write(b"das ist keine Datenbank " * 200)
        try:
            tk_ = pm_text(pm_bestand(kaputt, JP))
        except Exception as e_:
            tk_ = ["AUSNAHME " + type(e_).__name__ + ": " + str(e_)]
        ok("P10 Ohne Daten bricht nichts: leere Datenbank -> jeder Abschnitt sagt „keine“ und der Satz der Fed „nicht gespeichert“; "
           "fehlende Datei -> eine Zeile „Kein Ergebnis: prognosemarkt.db fehlt“; unlesbare Datei -> „Kein Ergebnis: … nicht lesbar“",
           "keine -- in prognosemarkt.db steht kein offener BTC-Markt" in tl and tl.count("    keine") >= 6 and "nicht gespeichert" in tl
           and "keine offene Sitzung" in tl
           and len(tf) == 1 and tf[0].startswith("  Kein Ergebnis: prognosemarkt.db fehlt")
           and len(tk_) == 1 and tk_[0].startswith("  Kein Ergebnis: prognosemarkt.db nicht lesbar"), f"{tf[0][:70]} | {tk_[0][:80]}")
        cq = PMt.lesen(pm_db)
        plan_m = " ".join(str(r_[-1]) for r_ in cq.execute("EXPLAIN QUERY PLAN " + PM_ABFRAGE, ("kalshi", "KXBTCY", 0)))
        plan_k = " ".join(str(r_[-1]) for r_ in cq.execute(
            "EXPLAIN QUERY PLAN SELECT ts, geld, brief, letzter, bis FROM pm_kurs WHERE plattform=? AND markt=? AND quelle='live' AND ts<=? "
            "ORDER BY ts DESC LIMIT 1", ("kalshi", "X", 0)))
        try:
            cq.execute("INSERT INTO pm_meta VALUES ('probe', '1')")
            schreibbar = True
        except sqlite3.Error:
            schreibbar = False
        cq.close()
        ok("P11 Last und Schreibschutz: Die Märkte werden über den Index (Börse, Reihe, Frist) gesucht und die Kurse über den "
           "Schlüssel -- kein Durchlauf der großen Tabellen (auf dem Pi rund 700.000 Märkte und 10 Millionen Kurse); die Verbindung des "
           "Berichts ist nur lesend (ein Schreibversuch scheitert)",
           "USING INDEX pm_markt_reihe" in plan_m and "SCAN" not in plan_m and "USING PRIMARY KEY" in plan_k and "SCAN" not in plan_k
           and schreibbar is False, plan_m[:90] + " | " + plan_k[:80])
        lauf159 = subprocess.run([sys.executable, "-B", os.path.abspath(__file__), "--prognosemarkt", "--db", os.path.join(tmp, "hl_liq.db"),
                                  "--jetzt", str(JP)], capture_output=True, text=True, timeout=120,
                                 env={k_: v_ for k_, v_ in os.environ.items() if k_ != "HL_PM_DB"})
        lauf_ohne = subprocess.run([sys.executable, "-B", os.path.abspath(__file__), "--prognosemarkt", "--db",
                                    os.path.join(tmp, "anderswo", "hl_liq.db")], capture_output=True, text=True, timeout=120,
                                   env={k_: v_ for k_, v_ in os.environ.items() if k_ != "HL_PM_DB"})
        ok("P12 Lauf von der Befehlszeile (Debug 159): findet prognosemarkt.db neben der Hauptdatenbank, Kopfzeile mit Debug-Nummer und "
           "Modulversion, derselbe Text wie die Funktion, Exit 0; ohne Datei eine Zeile „Kein Ergebnis“ und ebenfalls Exit 0",
           lauf159.returncode == 0 and lauf159.stdout.splitlines()[0].startswith("★ Langfrist: Prognosemärkte und Fed-Pfad als Text (U280 Teil 2, Debug 159) · Modul " + VERSION_MODUL)
           and "\n".join(lauf159.stdout.splitlines()[2:]) == t2 and lauf159.stderr == ""
           and lauf_ohne.returncode == 0 and "Kein Ergebnis: prognosemarkt.db fehlt" in lauf_ohne.stdout and lauf_ohne.stderr == "",
           f"rc {lauf159.returncode}/{lauf_ohne.returncode}, {len(lauf159.stdout.splitlines())} Zeilen {lauf159.stderr[-200:]}")
        teil2 = rumpf.split("# ================================================================================================ Teil 2a: Prognosemärkte", 1)[-1] \
            .split("# ================================================================================================ Selbsttest", 1)[0] \
            if "Teil 2a: Prognosemärkte" in rumpf else "INSERT"
        ok("K3 Vertrag Teil 2a: Der Bericht der Prognosemärkte öffnet prognosemarkt.db an EINER Stelle und nur lesend (hl_prognosemarkt.lesen), "
           "schreibt in keine Tabelle, legt keine an, ruft nichts ab und fasst makro.db nicht an; Frist ab 7 Tagen, frisch bis 3 Stunden, "
           "Raster 0,25, Hinweise ab 2 Punkten und 5 %; Debug-Nummer 159",
           teil2.count("PM.lesen(pfad)") == 1 and not any(w in teil2 for w in ("INSERT", "UPDATE ", "DELETE", "CREATE ", "ALTER ", "verbinden(",
                                                                                "schreiben(", "OP.abruf(", "holen(", "http", "makro_pfad", "lf_option"))
           and "sqlite3.connect" not in teil2 and PM_MIN_TAGE == 7 and PM_FRISCH_S == 3 * 3600 and PM_FED_SCHRITT == 0.25
           and PM_SPRUNG == 0.02 and PM_RAND_OFFEN == 0.05 and DEBUG_NR_PM == 159
           and PM_KALSHI_BTC == ("KXBTCY", "KXBTCMAXY", "KXBTCMINY", "KXBTCMAX150", "KXBTCPRICE") and PM_POLY_BTC == ("PMberuehrung", "PMschwelle", "PMfrist")
           and "KXBTCPRICE" in PMt.KALSHI_REIHEN and PMt.REIHE_FRIST == "PMfrist" and PM_FED == ("KXFED",),
           f"{len(teil2)} Zeichen in Teil 2a")
        ok("K4 Vertrag mit dem Konzept (9.4, PM1 bis PM9): die Reihen des Berichts, Frist ab 7 Tagen, frisch bis 3 Stunden, Mitte bis 4 "
           "Punkte Spread, Steigungen 1,09 und 1,36, Raster 0,25, Hinweise ab 2 Punkten und 5 %, zwei Tage Spielraum bei Kalshi, Debug 159 "
           "-- so stehen sie im Konzept und so rechnen die Module",
           "### 9.4 Prognosemärkte für den Chart, Schritt 2a: Sammeln und Bestand als Text" in kz and all(f"**PM{i} " in kz for i in range(1, 10))
           and "Debug 159 (`hl_marktschicht.py --prognosemarkt`) öffnet `prognosemarkt.db` nur lesend" in kz1 and DEBUG_NR_PM == 159
           and "`KXBTCY`, `KXBTCMAXY`, `KXBTCMINY`, `KXBTCMAX150`, `KXBTCPRICE` (Kalshi) und `PMberuehrung`, `PMschwelle`, `PMfrist` (Polymarket)" in kz1
           and "mit einer Frist ab 7 Tagen" in kz1 and PM_MIN_TAGE == 7
           and "höchstens 3 Stunden zurückliegt und der Markt nicht entschieden ist" in kz1 and PM_FRISCH_S == 3 * 3600
           and "höchstens 4 Punkte auseinanderliegen" in kz1 and PMt.mitte(5000, 5400) == 5200 and PMt.mitte(5000, 5401) is None
           and "Steigung 1,09 bei 7 bis 30 Tagen, 1,36 darüber" in kz1 and PMt.LE_STEIGUNG == ((7 * 86400, 30 * 86400, 1.09), (30 * 86400, 10 ** 10, 1.36))
           and "auf dem Raster 0,25 Prozentpunkte" in kz1 and PM_FED_SCHRITT == 0.25
           and "um mehr als 2 Punkte gegen ihre Ordnung" in kz1 and PM_SPRUNG == 0.02
           and "unter oder über der mehr als 5 % liegen" in kz1 and PM_RAND_OFFEN == 0.05
           and "mehr als zwei Tage hinter dem Datum im Titel" in kz1 and PMt.FRIST_SPIELRAUM_S == 2 * 86400
           and "Niveau 100.000 USD nach oben" in kz1 and PMt.PM_FRISTEN[0]["niveau"] == 100000.0 and PMt.PM_FRISTEN[0]["richtung"] == "greater"
           and "`when-will-bitcoin-hit-100k`" in kz1 and PMt.PM_FRISTEN[0]["slug"] == "when-will-bitcoin-hit-100k" and len(PMt.PM_FRISTEN) == 1,
           "Konzept gelesen" if kz else "KONZEPT_Langfrist.md fehlt")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-900:].replace("\n", " | "))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--stand", action="store_true", help="gespeicherter Stand der Optionen-Schicht als Text (liest nur)")
    p.add_argument("--db", default=None, help="Pfad der Hauptdatenbank (makro.db liegt daneben)")
    p.add_argument("--pruefen", action="store_true", help="ein Abruf bei Deribit, Rechnung und Diagnose als Text (speichert nichts; Debug 158)")
    p.add_argument("--prognosemarkt", action="store_true",
                   help="Prognosemärkte und Fed-Pfad für den 24-Monats-Chart als Text (liest nur prognosemarkt.db; Debug 159)")
    p.add_argument("--jetzt", type=float, default=None, help=argparse.SUPPRESS)        # nur für Proben: fester Zeitpunkt
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz (erzeugte Ketten, erzeugte prognosemarkt.db)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.pruefen:
        print(f"★ Optionen: Kette jetzt prüfen (U302, Debug {DEBUG_NR_PRUEFEN}) · Modul {VERSION_MODUL} · {_uhr(time.time())}")
        print("  Ein Abruf bei Deribit, dieselbe Rechnung wie der Tagesabruf (KONZEPT_Langfrist.md 9.3: O2 bis O5, O9). Der Lauf speichert nichts.")
        print("\n".join(pruefen()))
        return
    if a.prognosemarkt:
        print(f"★ Langfrist: Prognosemärkte und Fed-Pfad als Text (U280 Teil 2, Debug {DEBUG_NR_PM}) · Modul {VERSION_MODUL} · {_uhr(time.time())}")
        print("  Gelesen wird nur prognosemarkt.db -- kein Abruf, nichts wird gespeichert. Gezeigt ist, was die Prognosemärkte für den "
              "24-Monats-Chart hergeben.")
        print("\n".join(pm_text(pm_bestand(_pm().pfad(a.db or "hl_liq.db"), a.jetzt))))
        return
    if a.stand:
        import hl_makro as M
        pfad = M.makro_pfad(a.db) if a.db else M.makro_pfad("hl_liq.db")
        print(f"Optionen-Schicht des 24-Monats-Charts (U280) · Modul {VERSION_MODUL} · {_uhr(time.time())}")
        print("\n".join(stand_text(stand(pfad))))
        return
    p.print_help()


if __name__ == "__main__":
    main()
