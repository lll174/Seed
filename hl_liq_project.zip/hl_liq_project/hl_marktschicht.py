#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hl_marktschicht.py -- Markt-Schicht des 24-Monats-Charts, Teil 1: Optionen von Deribit (U280, U292; seit 23.118).

Was das Modul tut (KONZEPT_Langfrist.md 9.3, Regeln O1 bis O8 -- vor dem Bau festgelegt):
  O1 Ein Abruf der BTC-Optionen bei Deribit je New-York-Tag, fällig ab 15:45 Uhr New York (auch am Wochenende). Der Makro-Takt
     ruft takt_schritt() in jeder Runde; der prüft nur, ob ein Abruf fällig ist. Wiederholung nach einem Fehlschlag frühestens
     nach 10 Minuten, bis der New-York-Tag endet. Ist noch nichts gespeichert, einmal sofort („Erstabruf“); der Abruf zur
     festen Zeit desselben Tages ersetzt ihn.
  O3 Terminkurs je Verfalltag aus der Put-Call-Parität am Geld: F = K ÷ (1 − (Call − Put)) -- inverse Optionen, Kurse in BTC,
     ohne Zins. Das Feld underlying_price ist nur die Gegenprobe.
  O4 Brauchbar wie in 9.2: je Seite fünf Strikes mit Geld- und Briefkurs, Spanne am Geld höchstens 15 %.
  O5 Ränder (10, 25, 50, 75, 90 %) aus den Preisen: Call-Preis in USD ohne Zins an den Strikes der beiden Seiten, zwischen
     benachbarten Strikes die Wahrscheinlichkeit über ihrer Mitte, auf 0 bis 1 begrenzt; Paare, zwischen denen sie steigt,
     werden zu einem Paar über die ganze Strecke zusammengelegt; der Rand ist der kleinste Kurs, an dem die Marke erreicht ist. Außerhalb der Strikes gibt es keinen Rand. Gegenprobe aus der Schwankung
     am Geld (Normalverteilung in ln), nur im Bericht.
  O6 Gespeichert werden Kennzahlen je Abruf-Tag und Verfalltag (makro.db, lf_option) und je Abruf-Tag eine Zeile über den
     Abruf (lf_option_abruf). Die Kette selbst wird nicht gespeichert.
  O7 Für den Chart: der jüngste gespeicherte Abruf, wenn er höchstens 3 Tage vor dem Stichtag liegt; Zeichen nur für
     brauchbare Verfalltage ab 28 Tagen.
  O8 Lesart: risikoneutral, keine Prognose; die Schicht geht nicht in den Fächer ein.

Das Lesen der Antwort (Kennungen, Geld- und Briefkurs, Verfall um 08:00 UTC) kommt aus hl_optionen.py (Erstlauf, Debug 154);
dessen Zählweise und Urteil bleiben unberührt.

Aufruf:  python3 hl_marktschicht.py --stand --db PFAD     gespeicherter Stand als Text (liest nur)
         python3 hl_marktschicht.py --selbsttest          ohne Netz, erzeugte Ketten
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sqlite3
import statistics
import sys
import textwrap
import time
from datetime import date, datetime, timezone
from pathlib import Path

import hl_aktien as AK
import hl_optionen as OP

VERSION_MODUL = "2026-09-23.118"
PLAN = "U280"
REGEL = "KONZEPT_Langfrist.md 9.3, O1–O8 vom 22.11.2026"
TAG = 86_400
RAENDER = (10, 25, 50, 75, 90)
Z_WERT = {10: -1.2816, 25: -0.6745, 50: 0.0, 75: 0.6745, 90: 1.2816}       # O5.5: Normalverteilung
ABRUF_STUNDE, ABRUF_MINUTE = 15, 45                                       # O1: New York
WIEDER_S = 600                                                            # O1: nächster Versuch frühestens nach 10 Minuten
MIN_STRIKES = OP.MIN_STRIKES                                              # O4 (9.2): 5 je Seite
MAX_SPANNE = OP.MAX_SPANNE                                                # O4 (9.2): 15 %
ABW_MELDEN = 0.01                                                         # O3: Parität gegen Feld
MIN_TAGE_CHART = 28                                                       # O7: bis dahin reicht der Ausblick
MAX_ALTER_TAGE = 3                                                        # O7: Abruf höchstens so viele Tage vor dem Stichtag
EPS = 1e-12
TABELLE = ("CREATE TABLE IF NOT EXISTS lf_option (tag TEXT NOT NULL, verfall TEXT NOT NULL, ts INTEGER NOT NULL, art TEXT NOT NULL, "
           "tage REAL NOT NULL, termin REAL, termin_art TEXT, feld REAL, iv REAL, q10 REAL, q25 REAL, q50 REAL, q75 REAL, q90 REAL, "
           "unter INTEGER, ueber INTEGER, spanne REAL, stufe TEXT NOT NULL, grund TEXT, glatt INTEGER, strikes INTEGER, "
           "PRIMARY KEY (tag, verfall))")
TABELLE_ABRUF = ("CREATE TABLE IF NOT EXISTS lf_option_abruf (tag TEXT PRIMARY KEY, ts INTEGER, art TEXT, status INTEGER, bytes INTEGER, "
                 "dauer REAL, kontrakte INTEGER, verfalltage INTEGER, versuche INTEGER NOT NULL DEFAULT 0, letzter_versuch INTEGER, "
                 "fehler TEXT, modul TEXT)")
SPALTEN = ("tag", "verfall", "ts", "art", "tage", "termin", "termin_art", "feld", "iv", "q10", "q25", "q50", "q75", "q90", "unter", "ueber",
           "spanne", "stufe", "grund", "glatt", "strikes")
LESART = ("Optionspreise sind risikoneutral: Sie zeigen, zu welchen Preisen sich der Markt absichert, keine Prognose; ihre Mitte liegt nahe "
          "am Terminkurs. Die Schicht geht nicht in den Fächer ein.")
STUFE_TXT = {"quantile": "Ränder", "iv": "nur Schwankung am Geld", "entfaellt": "entfällt"}


# ================================================================================================ Rechenweg (O3 bis O5)

def seiten(K: list) -> tuple:
    """Kontrakte EINES Verfalltags -> (Calls, Puts) je Strike; ein doppelter Strike zählt einmal (der erste)."""
    calls, puts = {}, {}
    for k in K:
        ziel = calls if k["typ"] == "C" else puts
        ziel.setdefault(k["strike"], k)
    return calls, puts


def terminkurs(calls: dict, puts: dict) -> dict:
    """O3: Terminkurs aus der Put-Call-Parität am Strike mit dem kleinsten |Call − Put|; das Feld ist die Gegenprobe."""
    tf = [k["termin"] for k in list(calls.values()) + list(puts.values()) if k.get("termin") is not None and k["termin"] > 0]
    feld = float(statistics.median(tf)) if tf else None
    paare = [(abs(OP.mitte(calls[s]) - OP.mitte(puts[s])), s) for s in sorted(set(calls) & set(puts)) if OP.beide(calls[s]) and OP.beide(puts[s])]
    f, art, k_par = None, None, None
    if paare:
        _, k_par = min(paare)                                              # kleinster Abstand; bei Gleichstand der niedrigere Strike
        nenner = 1.0 - (OP.mitte(calls[k_par]) - OP.mitte(puts[k_par]))
        if nenner > 0.2:                                                   # sonst sind die Kurse keine einer inversen Option am Geld
            f, art = k_par / nenner, "paritaet"
    if f is None and feld is not None:
        f, art, k_par = feld, "feld", None
    abw = f / feld - 1.0 if art == "paritaet" and feld else None
    return {"f": f, "art": art, "k": k_par, "feld": feld, "abw": abw}


def call_reihe(calls: dict, puts: dict, f: float) -> list:
    """O5.1: (Strike, Call-Preis in USD ohne Zins) an den Strikes der beiden Seiten -- unter F aus dem Put (Parität), über F der Call."""
    reihe = []
    for s in sorted(set(calls) | set(puts)):
        if s < f and s in puts and OP.beide(puts[s]):
            reihe.append((s, f * OP.mitte(puts[s]) + f - s))
        elif s > f and s in calls and OP.beide(calls[s]):
            reihe.append((s, f * OP.mitte(calls[s])))
    return reihe


def ueber_wkt(reihe: list) -> tuple:
    """
    O5.2 und O5.3: je Paar benachbarter Strikes die Wahrscheinlichkeit, dass der Kurs am Verfalltag über ihrer Mitte liegt
    (Abnahme des Call-Preises je USD Strike), auf 0 bis 1 begrenzt. Steigt sie von einem Paar zum nächsten, werden die beiden
    zu EINEM Paar über die ganze Strecke zusammengelegt (Wert = Mittel, gewichtet mit dem Abstand der Strikes; Mitte = Mitte
    der Strecke) -- so oft, bis sie mit dem Kurs nirgends mehr steigt. Rückgabe: (Mitten, Werte, Zahl der Zusammenlegungen).
    """
    bloecke = []                                                           # [Summe Wert × Gewicht, Summe Gewicht, unterer Strike, oberer Strike]
    n = 0
    for (k1, c1), (k2, c2) in zip(reihe, reihe[1:]):
        n += 1
        w = k2 - k1
        bloecke.append([min(1.0, max(0.0, (c1 - c2) / w)) * w, w, k1, k2])
        while len(bloecke) > 1 and bloecke[-2][0] / bloecke[-2][1] < bloecke[-1][0] / bloecke[-1][1] - EPS:
            b = bloecke.pop()
            bloecke[-1][0] += b[0]; bloecke[-1][1] += b[1]; bloecke[-1][3] = b[3]
    return [(b[2] + b[3]) / 2.0 for b in bloecke], [b[0] / b[1] for b in bloecke], n - len(bloecke)


def raender(mitten: list, s: list) -> dict:
    """O5.4: je Marke q der kleinste Kurs, an dem 1 − s sie erreicht; zwischen den Mitten gerade verbunden; außerhalb: None."""
    g = [1.0 - x for x in s]
    out = {}
    for q in RAENDER:
        z = q / 100.0
        j = next((i for i, gi in enumerate(g) if gi >= z - EPS), None)
        if j is None:
            out[q] = None                                                  # die Marke liegt über dem größten Strike-Paar
        elif j == 0:
            out[q] = mitten[0] if abs(g[0] - z) <= EPS else None           # schon am kleinsten Strike-Paar überschritten
        else:
            out[q] = mitten[j - 1] + (z - g[j - 1]) / (g[j] - g[j - 1]) * (mitten[j] - mitten[j - 1])
    return out


def gegenprobe(f, iv, tage) -> dict:
    """O5.5: Ränder einer Normalverteilung in ln um F mit der Schwankung am Geld (iv in Prozent pro Jahr)."""
    if f is None or iv is None or iv <= 0 or tage is None or tage <= 0:
        return {q: None for q in RAENDER}
    sig, t = iv / 100.0, tage / 365.0
    return {q: f * math.exp(-sig * sig * t / 2.0 + Z_WERT[q] * sig * math.sqrt(t)) for q in RAENDER}


def kennzahlen(K: list) -> dict:
    """Kennzahlen EINES Verfalltags nach O3 bis O5 (Terminkurs aus der Parität, Stufe nach 9.2, Ränder aus den Preisen)."""
    calls, puts = seiten(K)
    T = terminkurs(calls, puts)
    f = T["f"]
    strikes = sorted(set(calls) | set(puts))
    unter = sum(1 for s in strikes if f is not None and s < f and s in puts and OP.beide(puts[s]))
    ueber = sum(1 for s in strikes if f is not None and s > f and s in calls and OP.beide(calls[s]))
    gemeinsam = [s for s in strikes if s in calls and s in puts]
    k_geld = min(gemeinsam, key=lambda s: (abs(s - f), s)) if gemeinsam and f is not None else None
    spanne = iv = None
    if k_geld is not None:
        c, p = calls[k_geld], puts[k_geld]
        if OP.beide(c) and OP.beide(p):
            spanne = (c["ask"] + p["ask"] - c["bid"] - p["bid"]) / ((c["ask"] + p["ask"] + c["bid"] + p["bid"]) / 2.0)
        ivs = [k["iv"] for k in (c, p) if k.get("iv") is not None and k["iv"] > 0]
        iv = sum(ivs) / len(ivs) if ivs else None
    gruende = []
    if f is None:
        gruende.append("kein Terminkurs")
    else:
        if T["art"] != "paritaet":
            gruende.append("kein Strike mit Geld- und Briefkurs für Call und Put (Terminkurs nur aus dem Feld)")
        if unter < MIN_STRIKES:
            gruende.append(f"unter dem Terminkurs nur {unter} {'Strike' if unter == 1 else 'Strikes'} mit beiden Kursen")
        if ueber < MIN_STRIKES:
            gruende.append(f"darüber nur {ueber} {'Strike' if ueber == 1 else 'Strikes'} mit beiden Kursen")
        if k_geld is None:
            gruende.append("kein Strike mit Call und Put")
        elif spanne is None:
            gruende.append("am Geld fehlt ein Geld- oder Briefkurs")
        elif spanne > MAX_SPANNE + 1e-9:
            gruende.append(f"Spanne am Geld {OP.pz(spanne)} über {OP.pz(MAX_SPANNE, 0)}")
    q = {r: None for r in RAENDER}
    glatt = None
    if not gruende:
        mitten, s, glatt = ueber_wkt(call_reihe(calls, puts, f))
        q = raender(mitten, s)
    stufe = "quantile" if not gruende else ("iv" if iv is not None else "entfaellt")
    return {"termin": f, "termin_art": T["art"], "k_par": T["k"], "feld": T["feld"], "abw": T["abw"], "iv": iv, "q": q, "unter": unter,
            "ueber": ueber, "k_geld": k_geld, "spanne": spanne, "stufe": stufe, "grund": "; ".join(gruende) or None, "glatt": glatt,
            "strikes": len(strikes)}


def auswerten(kontrakte: list, jetzt: float) -> list:
    """Alle kommenden Verfalltage einer gelesenen Kette (OP.deribit_lesen), aufsteigend, je mit Kennzahlen, Verfalltag und Tagen."""
    gruppen = {}
    for k in kontrakte:
        if k["verfall"] > jetzt:
            gruppen.setdefault(k["verfall"], []).append(k)
    out = []
    for ts in sorted(gruppen):
        v = kennzahlen(gruppen[ts])
        v.update(verfall=gruppen[ts][0]["tag"].isoformat(), verfall_ts=ts, tage=(ts - jetzt) / TAG)
        out.append(v)
    return out


# ================================================================================================ Abruf und Ablage (O1, O6)

def ny_tag(jetzt: float) -> date:
    return AK.ny_jetzt(jetzt).date()


def plan_ts(tag: date) -> int:
    """O1: Zeitpunkt, ab dem der Abruf des New-York-Tags fällig ist."""
    return AK.ny_ts(tag, ABRUF_STUNDE, ABRUF_MINUTE)


def _tabellen(con) -> None:
    con.execute(TABELLE); con.execute(TABELLE_ABRUF)


def faellig(con, jetzt: float) -> tuple:
    """O1: ("plan" | "erst" | None, Grund als Text, nächster möglicher Zeitpunkt oder None). Liest nur."""
    tag = ny_tag(jetzt)
    z = con.execute("SELECT ts, art, letzter_versuch FROM lf_option_abruf WHERE tag=?", (tag.isoformat(),)).fetchone()
    ts, art, versuch = z if z else (None, None, None)
    warten = versuch is not None and jetzt - versuch < WIEDER_S
    ab = plan_ts(tag)
    if jetzt >= ab:
        if ts is not None and art == "plan":
            return None, "der Abruf dieses Tages ist gespeichert", plan_ts(date.fromordinal(tag.toordinal() + 1))
        if warten:
            return None, "letzter Versuch vor weniger als 10 Minuten", int(versuch + WIEDER_S)
        return "plan", "fällig", None
    if con.execute("SELECT 1 FROM lf_option_abruf WHERE ts IS NOT NULL LIMIT 1").fetchone():
        return None, "fällig ab 15:45 Uhr New York", ab
    if warten:
        return None, "letzter Versuch vor weniger als 10 Minuten", int(versuch + WIEDER_S)
    return "erst", "noch kein Abruf gespeichert", None


def tagesabruf(pfad: str, http_fn=None, jetzt: float | None = None) -> dict:
    """
    O1 und O6: prüft, ob ein Abruf fällig ist; wenn ja: EIN Aufruf bei Deribit, auswerten, Kennzahlen speichern. Wirft nie.
    Rückgabe: {"art": "plan" | "erst" | None, "grund", "tag", "gespeichert": Zahl der Verfalltage, "fehler"}.
    """
    jetzt = time.time() if jetzt is None else float(jetzt)
    out = {"art": None, "grund": None, "tag": None, "gespeichert": 0, "fehler": None, "ts": int(jetzt)}
    try:
        con = sqlite3.connect(pfad, timeout=30)
    except Exception as e:
        out["fehler"] = f"{type(e).__name__}: {e}"
        return out
    try:
        if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('lf_option', 'lf_option_abruf')").fetchone()[0] != 2:
            _tabellen(con); con.commit()                                   # nur beim ersten Mal: sonst liest die Prüfung der Fälligkeit bloß
        art, grund, _ = faellig(con, jetzt)
        tag = ny_tag(jetzt).isoformat()
        out.update(art=art, grund=grund, tag=tag)
        if art is None:
            return out
        con.execute("INSERT OR IGNORE INTO lf_option_abruf (tag, versuche) VALUES (?, 0)", (tag,))
        con.execute("UPDATE lf_option_abruf SET versuche = versuche + 1, letzter_versuch = ?, modul = ? WHERE tag = ?", (int(jetzt), VERSION_MODUL, tag))
        con.commit()                                                       # der Versuch zählt, auch wenn der Abruf hängt oder scheitert
        a = OP.abruf(OP.DERIBIT_URL, http_fn or OP._http)
        fehler = a["fehler"]
        V = []
        gelesen = None
        if not fehler:
            gelesen = OP.deribit_lesen(a["obj"])
            if not gelesen["ok"]:
                fehler = gelesen["grund"]
            else:
                V = auswerten(gelesen["kontrakte"], jetzt)
                if not V:
                    fehler = "kein kommender Verfalltag in der Antwort"
        if fehler:
            kopf = f"HTTP {a['status']}: " if a["status"] is not None and not str(fehler).startswith("HTTP") else ""
            out["fehler"] = OP.sauber(kopf + str(fehler), 200)
            con.execute("UPDATE lf_option_abruf SET fehler = ? WHERE tag = ?", (out["fehler"], tag))
            con.commit()
            return out
        con.execute("DELETE FROM lf_option WHERE tag = ?", (tag,))         # nur der Erstabruf desselben Tages kann hier stehen (O1)
        for v in V:
            con.execute("INSERT INTO lf_option (" + ", ".join(SPALTEN) + ") VALUES (" + ", ".join("?" * len(SPALTEN)) + ")",
                        (tag, v["verfall"], int(jetzt), art, round(v["tage"], 4), v["termin"], v["termin_art"], v["feld"], v["iv"],
                         v["q"][10], v["q"][25], v["q"][50], v["q"][75], v["q"][90], v["unter"], v["ueber"], v["spanne"], v["stufe"],
                         v["grund"], v["glatt"], v["strikes"]))
        con.execute("UPDATE lf_option_abruf SET ts = ?, art = ?, status = ?, bytes = ?, dauer = ?, kontrakte = ?, verfalltage = ?, fehler = NULL "
                    "WHERE tag = ?", (int(jetzt), art, a["status"], a["bytes"], round(a["dauer"], 2), len(gelesen["kontrakte"]), len(V), tag))
        con.commit()
        out["gespeichert"] = len(V)
        return out
    except Exception as e:
        out["fehler"] = f"{type(e).__name__}: {e}"
        return out
    finally:
        con.close()


def takt_schritt(pfad: str, jetzt: float | None = None, http_fn=None) -> dict:
    """Vom Makro-Takt in JEDER Runde gerufen: Abruf nur, wenn er fällig ist (sonst ein Lesen der Datenbank). Wirft nie."""
    try:
        return tagesabruf(pfad, http_fn=http_fn, jetzt=jetzt)
    except Exception as e:                                                 # der Makro-Takt hängt nicht an dieser Schicht
        return {"art": None, "grund": None, "tag": None, "gespeichert": 0, "fehler": f"{type(e).__name__}: {e}"}


# ================================================================================================ Stand für Chart und Bericht (O7)

def _zeile(z) -> dict:
    d = dict(zip(SPALTEN, z))
    d["q"] = {str(r): d.pop(f"q{r}") for r in RAENDER}                     # Schlüssel als Text: die Antwort geht als JSON an die Seite
    return d


def zeichen(d: dict) -> bool:
    """O7: Ein Verfalltag bekommt ein Zeichen im Chart, wenn er brauchbar ist, mindestens 28 Tage läuft und Mitte und innere Ränder hat."""
    return d["stufe"] == "quantile" and d["tage"] >= MIN_TAGE_CHART and all(d["q"][r] is not None for r in ("25", "50", "75"))


def stand(pfad: str, stichtag: int | None = None, jetzt: float | None = None) -> dict:
    """
    Der jüngste gespeicherte Abruf für Chart und Bericht. stichtag = Tag seit 1970 (UTC) des Fächers; liegt der Abruf mehr als
    3 Tage davor, gibt es keine Zeichen (O7). Liest nur; legt nichts an; wirft nie.
    """
    jetzt = time.time() if jetzt is None else float(jetzt)
    out = {"ok": False, "grund": None, "tag": None, "ts": None, "art": None, "alter_tage": None, "zeilen": [], "punkte": [],
           "abruf": None, "heute": None, "naechster": None, "lesart": LESART}
    try:
        con = sqlite3.connect(Path(os.path.abspath(pfad)).as_uri() + "?mode=ro", uri=True, timeout=10)
    except Exception as e:
        out["grund"] = f"makro.db nicht lesbar ({type(e).__name__})"
        return out
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='lf_option_abruf'").fetchone():
            out["grund"] = "Noch kein Abruf der Optionen gespeichert (der erste folgt kurz nach dem Start des Dashboards)."
            return out
        spalten_a = ("tag", "ts", "art", "status", "bytes", "dauer", "kontrakte", "verfalltage", "versuche", "letzter_versuch", "fehler")
        h = con.execute("SELECT " + ", ".join(spalten_a) + " FROM lf_option_abruf WHERE tag=?", (ny_tag(jetzt).isoformat(),)).fetchone()
        out["heute"] = dict(zip(spalten_a, h)) if h else None
        _, _, out["naechster"] = faellig(con, jetzt)
        a = con.execute("SELECT " + ", ".join(spalten_a) + " FROM lf_option_abruf WHERE ts IS NOT NULL ORDER BY tag DESC LIMIT 1").fetchone()
        if not a:
            f = (out["heute"] or {}).get("fehler")
            out["grund"] = "Noch kein Abruf der Optionen gespeichert" + (f" (letzter Versuch: {f})." if f else ".")
            return out
        out["abruf"] = dict(zip(spalten_a, a))
        out.update(tag=a[0], ts=a[1], art=a[2])
        zeilen = [_zeile(z) for z in con.execute("SELECT " + ", ".join(SPALTEN) + " FROM lf_option WHERE tag=? ORDER BY verfall", (a[0],))]
        for d in zeilen:
            d["gegen"] = {str(r): v for r, v in gegenprobe(d["termin"], d["iv"], d["tage"]).items()}
            d["tag_verfall"] = date.fromisoformat(d["verfall"]).toordinal() - date(1970, 1, 1).toordinal()
            d["zeichen"] = zeichen(d)
        out["zeilen"] = zeilen
        if stichtag is not None:
            out["alter_tage"] = int(stichtag) - int(a[1] // TAG)
            if out["alter_tage"] > MAX_ALTER_TAGE:
                out["grund"] = (f"Der jüngste Abruf der Optionen ist vom {_tag_txt(a[1])} -- mehr als {MAX_ALTER_TAGE} Tage vor dem "
                                "Stichtag; er wird nicht gezeigt.")
                for d in zeilen:
                    d["zeichen"] = False
                return out
        out["punkte"] = [{"verfall": d["verfall"], "tag": d["tag_verfall"], "tage": d["tage"], "termin": d["termin"],
                          **{f"q{r}": d["q"][str(r)] for r in RAENDER}} for d in zeilen if d["zeichen"]]
        out["ok"] = True
        if not out["punkte"]:
            out["grund"] = f"Im Abruf vom {_tag_txt(a[1])} ist kein Verfalltag ab {MIN_TAGE_CHART} Tagen brauchbar für Ränder."
        return out
    except Exception as e:
        out["ok"] = False; out["punkte"] = []
        out["grund"] = f"Optionen nicht lesbar ({type(e).__name__}: {e})"
        return out
    finally:
        con.close()


# ================================================================================================ Text

def _tag_txt(ts) -> str:
    return time.strftime("%d.%m.%Y", time.localtime(ts)) if ts is not None else "—"


def _uhr(ts) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(ts)) if ts is not None else "—"


def _usd(x) -> str:
    return "—" if x is None else OP.de(x, 0)


def stand_text(S: dict, faecher: dict | None = None, lesart: bool = True) -> list:
    """
    Abschnitt „Optionen“ für Debug 156 aus stand(). faecher: je Verfalltag (ISO) die Ränder des Fächers am selben Tag
    ({"2026-12-25": {"10": …, "50": …, "90": …}}), vom Aufrufer gerechnet. lesart=False: ohne den Satz zur Lesart (der Aufrufer
    zeigt ihn schon). Rückgabe: Zeilen.
    """
    z = []
    a = z.append
    ab = S.get("abruf")
    if ab:
        a(f"  Abruf vom {_uhr(ab['ts'])} ({'zur festen Zeit' if ab['art'] == 'plan' else 'Erstabruf außer der Reihe'}) · HTTP {ab['status']} · "
          f"{OP.groesse_txt(ab['bytes'] or 0)} · {OP.de(ab['dauer'] or 0.0, 1)} s · {ab['kontrakte']} Kontrakte · {ab['verfalltage']} Verfalltage · "
          f"New-York-Tag {_iso_txt(ab['tag'])}")
    h = S.get("heute")
    if h and h.get("fehler"):
        a(f"  Heute (New-York-Tag {_iso_txt(h['tag'])}): {h['versuche']} {'Versuch' if h['versuche'] == 1 else 'Versuche'}, zuletzt {_uhr(h['letzter_versuch'])} -- {h['fehler']}")
    if S.get("naechster"):
        a(f"  Nächster Abruf: ab {_uhr(S['naechster'])} (täglich 15:45 Uhr New York; nach einem Fehlschlag frühestens nach 10 Minuten)")
    if S.get("grund"):
        a(f"  {S['grund']}")
    Z = S.get("zeilen") or []
    if not Z:
        if lesart:
            a(f"  Lesart: {LESART}")
        return _umbrochen(z)
    a("")
    a("  Ränder aus den Preisen (O5), je Verfalltag; „—“ = außerhalb der Strikes oder nicht brauchbar. * = Zeichen im Chart.")
    a("    Verfall       Tage  Terminkurs    10 %     25 %    Mitte     75 %     90 %   Strikes  Spanne  Schwankung  Stufe")
    for d in Z:
        q = d["q"]
        a(f"  {'*' if d.get('zeichen') else ' '} {_iso_txt(d['verfall'])} {OP.de(d['tage'], 0):>5}  {_usd(d['termin']):>10}  "
          + "  ".join(f"{_usd(q[str(r)]):>7}" for r in RAENDER)
          + f"  {d['unter'] if d['unter'] is not None else '—':>3}+{d['ueber'] if d['ueber'] is not None else '—':<3}  "
          + f"{OP.pz(d['spanne']) if d['spanne'] is not None else '—':>6}  {(OP.de(d['iv'], 1) + ' %') if d['iv'] is not None else '—':>9}   "
          + STUFE_TXT.get(d["stufe"], d["stufe"]) + (f" · {d['glatt']} zusammengelegt" if d.get("glatt") else ""))
        if d.get("grund"):
            a(f"        Grund: {d['grund']}")
    a("")
    a("  Gegenprobe (O5.5): dieselben Ränder aus der Schwankung am Geld, als wäre der Kurs in ln normalverteilt -- weicht ab, wo die")
    a("  Schwankung über die Strikes schief ist. Und der Terminkurs aus der Parität gegen das Feld der Börse (O3).")
    a("    Verfall        10 %     25 %    Mitte     75 %     90 %    Terminkurs: Parität · Feld · Abweichung")
    for d in Z:
        g = d.get("gegen") or {}
        abw = d["termin"] / d["feld"] - 1.0 if d.get("termin_art") == "paritaet" and d.get("feld") and d.get("termin") else None
        a(f"    {_iso_txt(d['verfall'])}  " + "  ".join(f"{_usd(g.get(str(r))):>7}" for r in RAENDER)
          + f"    {_usd(d['termin']) if d.get('termin_art') == 'paritaet' else '—':>8} · {_usd(d['feld']):>7} · "
          + (("+" if abw >= 0 else "−") + OP.de(abs(abw) * 100, 2) + " %" if abw is not None else "—")
          + ("  <-- über 1 %" if abw is not None and abs(abw) > ABW_MELDEN else ""))
    if faecher:
        a("")
        a("  Zum Vergleich der Fächer am selben Tag (10-%-Rand · Mitte · 90-%-Rand; er beginnt beim letzten Tagesschluss, die Optionen")
        a("  beim Terminkurs zur Abrufzeit):")
        for d in Z:
            f = faecher.get(d["verfall"])
            if f:
                a(f"    {_iso_txt(d['verfall'])}  Fächer {_usd(f.get('10'))} · {_usd(f.get('50'))} · {_usd(f.get('90'))}   "
                  f"Optionen {_usd(d['q']['10'])} · {_usd(d['q']['50'])} · {_usd(d['q']['90'])}")
    if lesart:
        a("")
        a(f"  Lesart: {LESART}")
    return _umbrochen(z)


def _umbrochen(zeilen: list, breite: int = 150) -> list:
    """Zeilen über der Breite umbrechen (Folgezeilen eingerückt) -- der Bericht bleibt ohne Rollen lesbar."""
    out = []
    for x in zeilen:
        if len(x) <= breite:
            out.append(x)
        else:
            out.extend(textwrap.wrap(x, width=breite, subsequent_indent="        ", break_long_words=False, break_on_hyphens=False))
    return out


def _iso_txt(s) -> str:
    try:
        d = date.fromisoformat(str(s))
        return f"{d.day:02d}.{d.month:02d}.{d.year}"
    except ValueError:
        return str(s)


# ================================================================================================ Selbsttest

def _N(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _b76(f: float, k: float, sig: float, t: float) -> tuple:
    """(Call, Put) in USD ohne Zins (Black 76)."""
    w = sig * math.sqrt(t)
    d1 = (math.log(f / k) + 0.5 * w * w) / w
    d2 = d1 - w
    return f * _N(d1) - k * _N(d2), k * _N(-d2) - f * _N(-d1)


def _kette(tag: date, strikes, teile, t: float, spanne: float = 0.02, feld=None, rausch=None, iv=None) -> list:
    """
    Erzeugte Kette EINES Verfalltags in der Form der Deribit-Antwort. teile = [(Gewicht, Terminkurs, Schwankung)] -- eine oder
    mehrere Lognormalverteilungen (mehrere: schiefe Mischung). Kurse in BTC (Preis in USD ÷ Terminkurs der Mischung).
    """
    f = sum(w * fi for w, fi, _ in teile)
    mon = {v: k for k, v in OP.MONATE.items()}[tag.month]
    out = []
    for i, k in enumerate(strikes):
        c = sum(w * _b76(fi, k, si, t)[0] for w, fi, si in teile) / f
        p = sum(w * _b76(fi, k, si, t)[1] for w, fi, si in teile) / f
        for typ, m in (("C", c), ("P", p)):
            if rausch is not None:
                m = m * (1.0 + rausch(i, typ))
            out.append({"instrument_name": f"BTC-{tag.day}{mon}{tag.year % 100:02d}-{int(k)}-{typ}", "bid_price": m * (1 - spanne / 2),
                        "ask_price": m * (1 + spanne / 2), "mark_iv": (iv if iv is not None else teile[0][2] * 100.0), "open_interest": 10.0,
                        "underlying_price": f if feld is None else feld})
    return out


def _wahr(teile, t: float, q: float) -> float:
    """Wahrer Rand einer Mischung von Lognormalverteilungen (Halbierung)."""
    def cdf(k):
        return sum(w * _N(-((math.log(fi / k) + 0.5 * si * si * t) / (si * math.sqrt(t)) - si * math.sqrt(t))) for w, fi, si in teile)
    lo, hi = 1.0, 1e8
    for _ in range(200):
        m = math.sqrt(lo * hi)
        lo, hi = (m, hi) if cdf(m) < q else (lo, m)
    return math.sqrt(lo * hi)


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    pruef = []
    t_start = time.time()

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed)))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}  {text}", flush=True)
    if verbose:
        print("hl_marktschicht -- Selbsttest (Optionen-Schicht des 24-Monats-Charts; ohne Netz, erzeugte Ketten in der Form von Deribit)", flush=True)
    tmp = tempfile.mkdtemp(prefix="hl_marktschicht_test_")
    try:
        utc = timezone.utc
        nah = lambda a, b, tol=1e-9: a is not None and b is not None and abs(a - b) <= tol
        rel = lambda a, b: abs(a / b - 1.0) if a is not None and b else 9.9
        JETZT = datetime(2026, 11, 23, 20, 50, tzinfo=utc).timestamp()          # Montag, 15:50 in New York
        VERF = date(2027, 6, 25)
        T = (datetime(2027, 6, 25, 8, tzinfo=utc).timestamp() - JETZT) / TAG / 365.0
        lesen = lambda liste: OP.deribit_lesen({"result": liste})["kontrakte"]
        STRIKES = [20_000 + 2_500 * i for i in range(73)]                       # 20.000 bis 200.000
        EIN = [(1.0, 60_000.0, 0.55)]

        # ---- M1 Terminkurs aus der Parität (O3, U292)
        K1 = lesen(_kette(VERF, STRIKES, EIN, T, feld=58_060.0))
        c1, p1 = seiten(K1); t1 = terminkurs(c1, p1)
        K1b = lesen([e for e in _kette(VERF, STRIKES, EIN, T) if not (e["instrument_name"].endswith("-P") and "-60000-" in e["instrument_name"])])
        t1b = terminkurs(*seiten(K1b))
        K1c = lesen([e for e in _kette(VERF, STRIKES, EIN, T, feld=61_000.0) if e["instrument_name"].endswith("-C")])
        t1c = terminkurs(*seiten(K1c))
        gleich = {"C": {50.0: {"bid": 0.10, "ask": 0.10}, 60.0: {"bid": 0.05, "ask": 0.05}}, "P": {50.0: {"bid": 0.05, "ask": 0.05}, 60.0: {"bid": 0.10, "ask": 0.10}}}
        t1d = terminkurs(gleich["C"], gleich["P"])
        ok("M1 Terminkurs (O3, U292): aus der Parität am Strike mit dem kleinsten |Call − Put| -- F = K ÷ (1 − (Call − Put)); trägt das Feld "
           "der Börse einen anderen Wert (58.060 statt 60.000), gilt die Parität und die Abweichung steht da; fehlt am Geld der Put, nimmt "
           "sie den nächsten Strike mit beiden; ohne ein Paar gilt das Feld; bei gleichem Abstand der niedrigere Strike",
           nah(t1["f"], 60_000.0, 1e-6) and t1["art"] == "paritaet" and t1["k"] == 60_000.0 and t1["feld"] == 58_060.0
           and nah(t1["abw"], 60_000.0 / 58_060.0 - 1.0, 1e-9) and abs(t1["abw"]) > ABW_MELDEN
           and nah(t1b["f"], 60_000.0, 1e-6) and t1b["k"] in (57_500.0, 62_500.0)
           and t1c == {"f": 61_000.0, "art": "feld", "k": None, "feld": 61_000.0, "abw": None}
           and t1d["k"] == 50.0 and nah(t1d["f"], 50.0 / (1.0 - 0.05)),
           f"F {t1['f']:.2f} am Strike {t1['k']:.0f}; Feld {t1['feld']:.0f}; Abweichung {t1['abw'] * 100:+.2f} %")
        # ---- M2 Call-Preis in USD an den Strikes der beiden Seiten (O5.1)
        hand_c = {90.0: {"bid": 0.20, "ask": 0.22}, 110.0: {"bid": 0.04, "ask": 0.06}, 100.0: {"bid": 0.1, "ask": 0.1}, 120.0: {"bid": 0.0, "ask": 0.02}}
        hand_p = {90.0: {"bid": 0.05, "ask": 0.07}, 110.0: {"bid": 0.15, "ask": 0.17}, 100.0: {"bid": 0.1, "ask": 0.1}, 80.0: {"bid": 0.02, "ask": 0.04}}
        r2 = call_reihe(hand_c, hand_p, 100.0)
        ok("M2 Call-Preis ohne Zins in USD (O5.1): über dem Terminkurs F · Call, darunter aus dem Put (F · Put + F − K); ein Strike genau "
           "auf dem Terminkurs zählt für keine Seite; ein Kontrakt ohne Geldkurs zählt nicht",
           [k for k, _ in r2] == [80.0, 90.0, 110.0] and nah(r2[0][1], 100 * 0.03 + 20) and nah(r2[1][1], 100 * 0.06 + 10) and nah(r2[2][1], 100 * 0.05),
           f"{[(k, round(c, 2)) for k, c in r2]}")
        # ---- M3 Wahrscheinlichkeit über der Mitte, begrenzt und monoton (O5.2, O5.3)
        m3, s3, n3 = ueber_wkt([(10.0, 50.0), (20.0, 41.0), (30.0, 31.5), (50.0, 16.5), (60.0, 15.0), (70.0, 16.0), (80.0, 2.0)])
        m3b, s3b, n3b = ueber_wkt([(10.0, 50.0), (20.0, 41.0), (30.0, 33.0), (40.0, 27.0)])
        ok("M3 Wahrscheinlichkeit über der Mitte je Strike-Paar (O5.2, O5.3): Abnahme des Call-Preises je USD Strike; auf 0 bis 1 begrenzt "
           "(ein Paar mit steigendem Preis gibt 0, eines über 1 gibt 1); steigt sie von einem Paar zum nächsten, werden die Paare zu EINEM "
           "über die ganze Strecke zusammengelegt (Wert = Mittel, gewichtet mit dem Abstand der Strikes; Mitte = Mitte der Strecke) -- "
           "auch über mehrere Paare; eine fallende Folge bleibt, wie sie ist",
           m3 == [20.0, 40.0, 65.0] and all(nah(a, b) for a, b in zip(s3, [0.925, 0.75, (0.15 * 10 + 0.0 * 10 + 1.0 * 10) / 30])) and n3 == 3
           and m3b == [15.0, 25.0, 35.0] and all(nah(a, b) for a, b in zip(s3b, [0.9, 0.8, 0.6])) and n3b == 0,
           f"Mitten {m3}, Werte {[round(x, 3) for x in s3]} · {n3} zusammengelegt")
        # ---- M4 Ränder (O5.4)
        r4 = raender([10.0, 20.0, 30.0, 40.0, 50.0], [0.95, 0.8, 0.5, 0.2, 0.05])
        r4b = raender([10.0, 20.0, 30.0], [0.7, 0.5, 0.3])
        r4c = raender([10.0, 20.0, 30.0, 40.0], [0.9, 0.5, 0.5, 0.1])
        ok("M4 Ränder (O5.4): der kleinste Kurs, an dem 1 − s die Marke erreicht, zwischen den Mitten gerade verbunden; liegt die Marke "
           "außerhalb der Mitten, gibt es den Rand nicht (kein Verlängern); eine Marke genau auf der ersten Mitte zählt; auf einer flachen "
           "Strecke gilt ihr Anfang",
           nah(r4[10], 10 + 10 * (0.10 - 0.05) / 0.15) and nah(r4[25], 20 + 10 * (0.25 - 0.20) / 0.30) and nah(r4[50], 30.0)
           and nah(r4[75], 30 + 10 * (0.75 - 0.5) / 0.3) and nah(r4[90], 40 + 10 * (0.90 - 0.8) / 0.15)
           and r4b == {10: None, 25: None, 50: 20.0, 75: None, 90: None} and nah(r4c[10], 10.0) and nah(r4c[50], 20.0) and nah(r4c[90], 40.0),
           f"{ {q: (round(v, 2) if v is not None else None) for q, v in r4.items()} } · außerhalb: {r4b}")
        # ---- M5 bekannte Verteilung
        v5 = kennzahlen(K1)
        wahr5 = {q: _wahr(EIN, T, q / 100.0) for q in RAENDER}
        g5 = gegenprobe(v5["termin"], v5["iv"], T * 365.0)
        ok("M5 Bekannte Verteilung (eine Lognormalverteilung, Strikes alle 2.500 USD, Spanne 2 %): Die Ränder aus den Preisen treffen die "
           "wahren auf 1 %; die Gegenprobe aus der Schwankung am Geld trifft sie hier auf 0,01 % (ohne Schiefe sind beide Wege gleich); "
           "nichts musste zusammengelegt werden",
           v5["stufe"] == "quantile" and all(rel(v5["q"][q], wahr5[q]) < 0.01 for q in RAENDER) and all(rel(g5[q], wahr5[q]) < 1e-4 for q in RAENDER)
           and v5["glatt"] == 0 and v5["unter"] == 16 and v5["ueber"] == 56 and nah(v5["iv"], 55.0),
           " · ".join(f"{q} %: {v5['q'][q]:.0f} (wahr {wahr5[q]:.0f})" for q in RAENDER))
        # ---- M6 schiefe Verteilung
        MIX = [(0.35, 42_000.0, 0.75), (0.65, 60_000.0 / 0.65 - 0.35 * 42_000.0 / 0.65, 0.40)]
        v6 = kennzahlen(lesen(_kette(VERF, STRIKES, MIX, T, iv=52.0)))
        wahr6 = {q: _wahr(MIX, T, q / 100.0) for q in RAENDER}
        g6 = gegenprobe(v6["termin"], v6["iv"], T * 365.0)
        ok("M6 Schiefe Verteilung (Mischung zweier Lognormalverteilungen, Terminkurs 60.000): Die Ränder aus den Preisen treffen die wahren "
           "auf 1,5 %; die Gegenprobe aus EINER Schwankung liegt am 10-%-Rand um mehr als 5 % daneben -- deshalb kommen die Ränder aus den "
           "Preisen und nicht aus der Schwankung am Geld",
           nah(v6["termin"], 60_000.0, 1e-6) and all(rel(v6["q"][q], wahr6[q]) < 0.015 for q in RAENDER) and rel(g6[10], wahr6[10]) > 0.05,
           " · ".join(f"{q} %: {v6['q'][q]:.0f} (wahr {wahr6[q]:.0f}, Gegenprobe {g6[q]:.0f})" for q in RAENDER))
        # ---- M7 verrauschte Kurse
        import random
        GROB = [20_000 + 5_000 * i for i in range(37)]                         # Strikes alle 5.000 USD -- wie bei langen Verfalltagen
        abw7 = {q: [] for q in RAENDER}; glatt7 = []; steigt7 = True
        for saat in range(40):
            rnd = random.Random(saat); zufall = {}
            v7 = kennzahlen(lesen(_kette(VERF, GROB, EIN, T, spanne=0.06, rausch=lambda i, typ: zufall.setdefault((i, typ), rnd.uniform(-0.01, 0.01)))))
            glatt7.append(v7["glatt"])
            steigt7 = steigt7 and v7["stufe"] == "quantile" and all(v7["q"][q] is not None for q in RAENDER) and all(v7["q"][a] <= v7["q"][b] for a, b in zip(RAENDER, RAENDER[1:]))
            for q in RAENDER:
                abw7[q].append(rel(v7["q"][q], wahr5[q]) if v7["q"][q] is not None else 9.9)
        hart = kennzahlen(lesen(_kette(VERF, STRIKES, EIN, T, spanne=0.06, rausch=lambda i, typ: zufall.setdefault((i, typ, "h"), rnd.uniform(-0.03, 0.03)))))
        ok("M7 Verrauschte Kurse (40 erzeugte Ketten, Strikes alle 5.000 USD, jede Mitte um bis zu 1 % verschoben, Spanne 6 %): Die Ränder "
           "steigen immer von 10 bis 90 %; die größte Abweichung vom wahren Rand bleibt unter 6 %, die mittlere unter 2 %. Bei dreimal so "
           "starkem Rauschen und doppelt so dichten Strikes wird zusammengelegt; die Ränder steigen weiter und bleiben innerhalb von 10 % "
           "(die Mitte liegt hier 7 % daneben -- die Grenze des Rechenwegs, im Konzept genannt)",
           steigt7 and max(max(v) for v in abw7.values()) < 0.06 and max(sum(v) / len(v) for v in abw7.values()) < 0.02
           and hart["stufe"] == "quantile" and hart["glatt"] > 0 and all(hart["q"][q] is not None for q in RAENDER)
           and all(hart["q"][a] <= hart["q"][b] for a, b in zip(RAENDER, RAENDER[1:])) and all(rel(hart["q"][q], wahr5[q]) < 0.10 for q in RAENDER),
           "größte Abweichung je Rand: " + " · ".join(f"{q} %: {max(abw7[q]) * 100:.1f} %" for q in RAENDER)
           + f"; im Mittel höchstens {max(sum(v) / len(v) for v in abw7.values()) * 100:.1f} %; zusammengelegt 0 bis {max(glatt7)}; hart: {hart['glatt']} zusammengelegt, "
           + " · ".join(f"{hart['q'][q]:.0f}" for q in RAENDER))
        # ---- M8 Strikes reichen nicht bis an die Ränder
        ENG = [45_000 + 2_500 * i for i in range(13)]                         # 45.000 bis 75.000
        v8 = kennzahlen(lesen(_kette(VERF, ENG, EIN, T)))
        d8 = {"stufe": v8["stufe"], "tage": 200.0, "q": {str(k): v for k, v in v8["q"].items()}}
        ok("M8 Strikes von 45.000 bis 75.000 bei einer Verteilung von rund 33.000 bis 96.000: Die äußeren Ränder gibt es nicht -- sie werden "
           "nicht geschätzt; Mitte und die inneren Ränder stehen da (sofern innerhalb), der Verfalltag bleibt brauchbar",
           v8["stufe"] == "quantile" and v8["q"][10] is None and v8["q"][90] is None and v8["q"][50] is not None and rel(v8["q"][50], wahr5[50]) < 0.01
           and (v8["q"][25] is None) == (wahr5[25] < 46_250.0) and (v8["q"][75] is None) == (wahr5[75] > 73_750.0) and zeichen(d8) == (v8["q"][25] is not None and v8["q"][75] is not None),
           f"{ {q: (round(v) if v is not None else None) for q, v in v8['q'].items()} } (wahr 25 %: {wahr5[25]:.0f}, 75 %: {wahr5[75]:.0f})")
        # ---- M9 nicht brauchbar (O4)
        WENIG = [50_000, 52_500, 55_000, 57_500, 60_000, 62_500, 65_000, 67_500, 70_000, 72_500, 75_000]     # unter F nur 4
        v9a = kennzahlen(lesen(_kette(VERF, WENIG, EIN, T)))
        v9b = kennzahlen(lesen(_kette(VERF, STRIKES, EIN, T, spanne=0.20)))
        k9c = _kette(VERF, WENIG, EIN, T)
        for e in k9c:
            e["mark_iv"] = None
        v9c = kennzahlen(lesen(k9c))
        k9d = _kette(VERF, STRIKES, EIN, T, feld=61_000.0)
        for e in k9d:
            if e["instrument_name"].endswith("-P"):
                e["bid_price"] = 0.0                                           # kein Put mit Geldkurs: kein Paar für die Parität
        v9d = kennzahlen(lesen(k9d))
        ok("M9 Nicht brauchbar (O4, wie 9.2): unter dem Terminkurs nur vier Strikes -> keine Ränder, nur die Schwankung am Geld, mit Grund; "
           "Spanne am Geld über 15 % -> ebenso; fehlt auch die Schwankung, entfällt der Verfalltag; Terminkurs nur aus dem Feld -> keine Ränder",
           v9a["stufe"] == "iv" and v9a["q"] == {q: None for q in RAENDER} and v9a["unter"] == 4 and "unter dem Terminkurs nur 4 Strikes" in v9a["grund"]
           and v9b["stufe"] == "iv" and "Spanne am Geld 20,0 % über 15 %" in v9b["grund"] and v9c["stufe"] == "entfaellt"
           and v9d["stufe"] == "iv" and v9d["termin"] == 61_000.0 and v9d["termin_art"] == "feld" and "Terminkurs nur aus dem Feld" in v9d["grund"]
           and v9d["q"][50] is None and kennzahlen(K1c)["stufe"] == "entfaellt",
           f"{v9a['grund']} | {v9b['grund']}")
        # ---- M10 Fälligkeit (O1)
        db = os.path.join(tmp, "makro.db")
        con = sqlite3.connect(db); _tabellen(con); con.commit()
        ny = lambda j, mo, t_, h, mi: datetime(j, mo, t_, h, mi, tzinfo=AK.NY).timestamp()
        f_a = faellig(con, ny(2026, 11, 23, 10, 0))                             # nichts gespeichert, vormittags
        f_l = faellig(con, ny(2026, 11, 23, 20, 0))                             # nichts gespeichert, abends in New York (in UTC schon der 24.11.)
        f_b = faellig(con, ny(2026, 11, 23, 15, 45))
        con.execute("INSERT INTO lf_option_abruf (tag, ts, art, versuche, letzter_versuch) VALUES ('2026-11-23', ?, 'erst', 1, ?)",
                    (int(ny(2026, 11, 23, 10, 0)), int(ny(2026, 11, 23, 10, 0)))); con.commit()
        f_c = faellig(con, ny(2026, 11, 23, 15, 44))
        f_d = faellig(con, ny(2026, 11, 23, 15, 45))
        con.execute("UPDATE lf_option_abruf SET letzter_versuch = ? WHERE tag = '2026-11-23'", (int(ny(2026, 11, 23, 15, 45)),)); con.commit()
        f_e = faellig(con, ny(2026, 11, 23, 15, 54))
        f_f = faellig(con, ny(2026, 11, 23, 15, 55))
        con.execute("UPDATE lf_option_abruf SET art = 'plan' WHERE tag = '2026-11-23'"); con.commit()
        f_g = faellig(con, ny(2026, 11, 23, 23, 59))
        f_h = faellig(con, ny(2026, 11, 24, 0, 1))
        f_i = faellig(con, ny(2026, 11, 28, 15, 45))                            # Samstag
        f_j = faellig(con, datetime(2027, 6, 21, 19, 44, tzinfo=utc).timestamp())   # Sommer: 15:44 in New York
        f_k = faellig(con, datetime(2027, 6, 21, 19, 45, tzinfo=utc).timestamp())
        con.close()
        ok("M10 Fälligkeit (O1): ohne gespeicherten Abruf sofort ein Erstabruf; danach erst ab 15:45 Uhr New York; der Abruf zur festen Zeit "
           "ersetzt den Erstabruf desselben Tages; nach einem Versuch frühestens nach 10 Minuten der nächste; ist der Abruf des Tages "
           "gespeichert, bis zum nächsten Tag keiner; der Tag ist der in New York (abends dort ist in UTC schon der nächste -- der Abruf "
           "gehört trotzdem zum New Yorker Tag); am Samstag wie an jedem Tag; im Sommer 19:45 UTC, im Winter 20:45 UTC",
           f_a[0] == "erst" and f_b[0] == "plan" and f_l[0] == "plan" and ny_tag(ny(2026, 11, 23, 20, 0)) == date(2026, 11, 23)
           and ny_tag(ny(2026, 11, 24, 0, 1)) == date(2026, 11, 24) and f_c[0] is None and f_c[2] == int(ny(2026, 11, 23, 15, 45)) and f_d[0] == "plan"
           and f_e[0] is None and f_e[2] == int(ny(2026, 11, 23, 15, 55)) and f_f[0] == "plan" and f_g[0] is None
           and f_g[2] == int(ny(2026, 11, 24, 15, 45)) and f_h[0] is None and f_h[2] == int(ny(2026, 11, 24, 15, 45)) and f_i[0] == "plan"
           and f_j[0] is None and f_k[0] == "plan"
           and plan_ts(date(2026, 11, 23)) == int(datetime(2026, 11, 23, 20, 45, tzinfo=utc).timestamp()) and WIEDER_S == 600,
           f"{[x[0] for x in (f_a, f_b, f_c, f_d, f_e, f_f, f_g, f_h, f_i, f_j, f_k)]}")
        # ---- M11 Abruf und Ablage (O1, O6)
        db2 = os.path.join(tmp, "makro2.db")
        KURZ = date(2026, 12, 11); T_K = (datetime(2026, 12, 11, 8, tzinfo=utc).timestamp() - JETZT) / TAG / 365.0
        VORBEI = date(2026, 11, 20)
        kette = (_kette(VERF, STRIKES, EIN, T, feld=58_060.0) + _kette(KURZ, STRIKES, [(1.0, 59_000.0, 0.50)], T_K)
                 + _kette(date(2027, 9, 24), WENIG, [(1.0, 60_000.0, 0.60)], T + 91 / 365.0) + _kette(VORBEI, STRIKES, EIN, 0.01))
        rufe = []

        def http_ok(url, timeout):
            rufe.append(url)
            return json.dumps({"result": kette}).encode(), None, 200

        def http_fehler(url, timeout):
            rufe.append(url)
            return None, "HTTP 503: Service Unavailable", 503
        a1 = tagesabruf(db2, http_fn=http_fehler, jetzt=JETZT)
        a2 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 300)                # nach 5 Minuten: noch kein neuer Versuch
        a3 = tagesabruf(db2, http_fn=lambda u, t: (b"<html><body>gesperrt</body></html>", None, 200), jetzt=JETZT + 600)
        a4 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 1200)
        import hashlib
        bild5 = hashlib.sha256(open(db2, "rb").read()).hexdigest()
        a5 = tagesabruf(db2, http_fn=http_ok, jetzt=JETZT + 1800)               # gespeichert: kein weiterer Abruf
        still5 = hashlib.sha256(open(db2, "rb").read()).hexdigest() == bild5    # und kein Schreiben in die Datenbank
        con = sqlite3.connect(db2)
        tabs = sorted(r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'"))
        zl, ab = [], []
        if tabs == ["lf_option", "lf_option_abruf"]:                            # fehlen sie, trägt M11 das als Aussage (kein Abbruch)
            zl = [_zeile(z) for z in con.execute("SELECT " + ", ".join(SPALTEN) + " FROM lf_option ORDER BY verfall")]
            ab = con.execute("SELECT tag, ts, art, status, kontrakte, verfalltage, versuche, fehler, modul FROM lf_option_abruf").fetchall()
        con.close()
        ok("M11 Abruf und Ablage (O1, O6): Ein Fehlschlag (HTTP 503) zählt als Versuch mit Grund; fünf Minuten später wird nicht abgerufen; "
           "eine HTML-Seite statt JSON ist ein Fehlschlag mit Grund; der nächste gelungene Abruf speichert je kommendem Verfalltag eine "
           "Zeile (der vergangene fehlt) und die Zeile über den Abruf; danach wird an dem Tag nicht mehr abgerufen, und die Prüfung der "
           "Fälligkeit schreibt nichts in die Datenbank. Genau ein Aufruf je "
           "Versuch, immer an die feste Adresse. Gespeichert sind nur Kennzahlen -- zwei Tabellen, keine Kette",
           a1["art"] == "plan" and a1["fehler"] == "HTTP 503: Service Unavailable" and a1["gespeichert"] == 0
           and a2["art"] is None and "weniger als 10 Minuten" in a2["grund"] and a3["art"] == "plan" and "HTML statt JSON" in a3["fehler"]
           and a4 == {"art": "plan", "grund": "fällig", "tag": "2026-11-23", "gespeichert": 3, "fehler": None, "ts": int(JETZT + 1200)}
           and a5["art"] is None and a5["grund"] == "der Abruf dieses Tages ist gespeichert" and still5
           and rufe == [OP.DERIBIT_URL] * 2 and [z["verfall"] for z in zl] == ["2026-12-11", "2027-06-25", "2027-09-24"]
           and [z["stufe"] for z in zl] == ["quantile", "quantile", "iv"] and all(z["ts"] == int(JETZT + 1200) and z["art"] == "plan" for z in zl)
           and nah(zl[1]["termin"], 60_000.0, 1e-6) and zl[1]["feld"] == 58_060.0 and rel(zl[1]["q"]["50"], wahr5[50]) < 0.012
           and ab == [("2026-11-23", int(JETZT + 1200), "plan", 200, 73 * 2 * 3 + 11 * 2, 3, 3, None, VERSION_MODUL)]
           and tabs == ["lf_option", "lf_option_abruf"] and os.path.getsize(db2) < 40_000,
           f"{[(z['verfall'], z['stufe']) for z in zl]}; Abruf {ab[0][:7] if ab else None}; Datei {os.path.getsize(db2)} Bytes")
        # ---- M11b Erstabruf und sein Ersatz
        db3 = os.path.join(tmp, "makro3.db")
        FRUEH = datetime(2026, 11, 23, 14, 0, tzinfo=utc).timestamp()           # 09:00 in New York
        e1 = tagesabruf(db3, http_fn=http_ok, jetzt=FRUEH)
        e2 = tagesabruf(db3, http_fn=http_ok, jetzt=FRUEH + 3600)
        con = sqlite3.connect(db3); n_e = con.execute("SELECT COUNT(*), MIN(art), MAX(ts) FROM lf_option").fetchone(); con.close()
        kette_spaet = _kette(VERF, STRIKES, [(1.0, 63_000.0, 0.55)], T)
        e3 = tagesabruf(db3, http_fn=lambda u, t: (json.dumps({"result": kette_spaet}).encode(), None, 200), jetzt=JETZT)
        con = sqlite3.connect(db3)
        n_p = con.execute("SELECT COUNT(*), MIN(art), MAX(ts), MIN(termin) FROM lf_option").fetchone()
        ab3 = con.execute("SELECT tag, art, versuche FROM lf_option_abruf").fetchall(); con.close()
        e4 = tagesabruf(db3, http_fn=http_ok, jetzt=JETZT + 86_400 - 7200)      # nächster Tag, 13:50 in New York: kein Erstabruf mehr
        ok("M11b Erstabruf (O1): Ist noch nichts gespeichert, wird sofort abgerufen und als „erst“ abgelegt; bis 15:45 Uhr New York folgt "
           "keiner; der Abruf zur festen Zeit desselben Tages ersetzt die Zeilen des Erstabrufs ganz; am nächsten Tag vor 15:45 wird nicht "
           "abgerufen",
           e1["art"] == "erst" and e1["gespeichert"] == 3 and e2["art"] is None and e2["grund"] == "fällig ab 15:45 Uhr New York"
           and n_e == (3, "erst", int(FRUEH)) and e3["art"] == "plan" and e3["gespeichert"] == 1 and n_p[:3] == (1, "plan", int(JETZT))
           and nah(n_p[3], 63_000.0, 1e-6) and ab3 == [("2026-11-23", "plan", 2)] and e4["art"] is None and e4["tag"] == "2026-11-24",
           f"erst {n_e}; danach {n_p[:3]}; Abruf {ab3}")
        # ---- M12 Stand für den Chart (O7)
        TAG_J = int(JETZT // TAG)
        s12 = stand(db2, stichtag=TAG_J - 1, jetzt=JETZT + 2000)
        s12b = stand(db2, stichtag=TAG_J + 3, jetzt=JETZT + 3 * TAG)
        s12c = stand(db2, stichtag=TAG_J + 4, jetzt=JETZT + 4 * TAG)
        s12d = stand(os.path.join(tmp, "fehlt.db"), stichtag=TAG_J)
        leer = os.path.join(tmp, "leer.db"); sqlite3.connect(leer).close()
        s12e = stand(leer, stichtag=TAG_J)
        gr_vor = os.path.getsize(leer)
        ok("M12 Stand für den Chart (O7): Zeichen nur für brauchbare Verfalltage ab 28 Tagen mit Mitte und inneren Rändern (der Verfalltag in "
           "18 Tagen und der nicht brauchbare stehen nur in der Tabelle); der Abruf darf höchstens 3 Tage vor dem Stichtag liegen -- am "
           "vierten Tag keine Zeichen, mit Grund; ohne Tabellen oder ohne Datei der Grund statt eines Fehlers; das Lesen legt nichts an",
           s12["ok"] and [p["verfall"] for p in s12["punkte"]] == ["2027-06-25"] and len(s12["zeilen"]) == 3 and s12["alter_tage"] == -1
           and s12["punkte"][0]["tag"] == date(2027, 6, 25).toordinal() - date(1970, 1, 1).toordinal() and nah(s12["punkte"][0]["termin"], 60_000.0, 1e-6)
           and all(rel(s12["punkte"][0][f"q{q}"], wahr5[q]) < 0.012 for q in RAENDER) and [float(z["q"]["50"] is not None) for z in s12["zeilen"]] == [1.0, 1.0, 0.0]
           and [z["zeichen"] for z in s12["zeilen"]] == [False, True, False] and s12["naechster"] == int(ny(2026, 11, 24, 15, 45))
           and s12b["ok"] and s12b["alter_tage"] == 3 and len(s12b["punkte"]) == 1
           and s12c["ok"] is False and s12c["punkte"] == [] and "mehr als 3 Tage vor dem Stichtag" in (s12c["grund"] or "") and len(s12c["zeilen"]) == 3
           and not any(z["zeichen"] for z in s12c["zeilen"]) and json.loads(json.dumps(s12, allow_nan=False)) == s12
           and s12d["ok"] is False and s12d["grund"] and s12e["ok"] is False and "Noch kein Abruf der Optionen gespeichert" in s12e["grund"]
           and os.path.getsize(leer) == gr_vor and not os.path.exists(os.path.join(tmp, "fehlt.db")),
           f"Zeichen {[p['verfall'] for p in s12['punkte']]}; nach 4 Tagen: {(s12c['grund'] or 'kein Grund')[:70]}")
        # ---- M13 Text
        t13 = "\n".join(stand_text(s12, {"2027-06-25": {"10": 40_000.0, "50": 70_000.0, "90": 120_000.0}}))
        t13o = "\n".join(stand_text(s12, None, lesart=False))
        t13e = "\n".join(stand_text(s12e))
        db13 = os.path.join(tmp, "makro13.db"); shutil.copyfile(db2, db13)
        tagesabruf(db13, http_fn=lambda u, t: (None, "HTTP 503: Service Unavailable -- " + "sehr lange Meldung der Gegenstelle " * 6, 503), jetzt=JETZT + TAG)
        t13f = "\n".join(stand_text(stand(db13, stichtag=TAG_J, jetzt=JETZT + TAG + 60)))
        z13 = next((x for x in t13.splitlines() if x.startswith("  * 25.06.2027")), "")
        ok("M13 Text für Debug 156: Kopf mit Abrufzeit, Größe und Zahl der Kontrakte; je Verfalltag eine Zeile mit Tagen, Terminkurs, den "
           "fünf Rändern, Strikes je Seite, Spanne, Schwankung und Stufe -- der Stern nur am Zeichen im Chart, der Grund am nicht brauchbaren; "
           "die Gegenprobe mit Parität gegen Feld und dem Vermerk über 1 %; der Fächer am selben Tag; die Lesart; ohne Abruf nur Grund und "
           "Lesart; ein Fehlschlag von heute steht mit Zahl der Versuche und Grund da; keine Zeile über 150 Zeichen; keine Kauf- oder "
           "Verkaufswörter",
           "Abruf vom " in t13 and "zur festen Zeit" in t13 and "460 Kontrakte" in t13 and "3 Verfalltage" in t13 and "New-York-Tag 23.11.2026" in t13
           and "60.000" in z13 and z13.rstrip().endswith("Ränder") and " 16+56 " in z13 and "55,0 %" in z13
           and "    11.12.2026" in t13 and "nur Schwankung am Geld\n        Grund: unter dem Terminkurs nur 4 Strikes mit beiden Kursen\n" in t13
           and max(len(x) for x in (t13 + "\n" + t13e + "\n" + t13f).splitlines()) <= 150 and "<-- über 1 %" in t13f and "Service Unavailable" in t13f
           and "60.000 ·  58.060 · +3,34 %  <-- über 1 %" in t13 and "Fächer 40.000 · 70.000 · 120.000   Optionen " in t13
           and " ".join(t13.split()).count(LESART) == 1 and "Nächster Abruf: ab " in t13
           and "Noch kein Abruf der Optionen gespeichert" in t13e and LESART in " ".join(t13e.split()) and "Verfall" not in t13e
           and "Lesart" not in t13o and "Zum Vergleich der Fächer" not in t13o and "Gegenprobe (O5.5)" in t13o
           and not any(w in (t13 + t13e).lower() for w in ("kaufen", "verkaufen", "einstieg", "ausstieg", "empfehl", "long gehen", "short gehen")),
           z13.strip()[:120])
        # ---- M14 wirft nie
        kein = os.path.join(tmp, "gibt", "es", "nicht.db")
        w1 = takt_schritt(kein, jetzt=JETZT, http_fn=http_ok)
        w2 = tagesabruf(os.path.join(tmp, "m14.db"), http_fn=lambda u, t: (_ for _ in ()).throw(RuntimeError("Leitung tot")), jetzt=JETZT)
        w3 = tagesabruf(os.path.join(tmp, "m14b.db"), http_fn=lambda u, t: (json.dumps({"error": {"message": "too many requests", "code": 10028}}).encode(), None, 200), jetzt=JETZT)
        w4 = tagesabruf(os.path.join(tmp, "m14c.db"), http_fn=lambda u, t: (json.dumps({"result": _kette(VORBEI, STRIKES, EIN, 0.01)}).encode(), None, 200), jetzt=JETZT)
        w5 = kennzahlen([])
        ok("M14 Wirft nie: Pfad ohne Ordner, Ausnahme im Abruf, Fehlerantwort der Börse, Antwort nur mit vergangenen Verfalltagen, leere "
           "Kette -- je ein Ergebnis mit Grund, nichts gespeichert",
           w1["fehler"] and w1["gespeichert"] == 0 and "Leitung tot" in w2["fehler"] and "too many requests" in w3["fehler"]
           and w4["fehler"] == "HTTP 200: kein kommender Verfalltag in der Antwort" and w4["gespeichert"] == 0 and w5["stufe"] == "entfaellt"
           and w5["termin"] is None,
           f"{w2['fehler'][:50]} | {w3['fehler'][:60]}")
        # ---- K1 Vertrag mit dem Konzept
        hier = os.path.dirname(os.path.abspath(__file__))
        try:
            kz = open(os.path.join(hier, "KONZEPT_Langfrist.md"), encoding="utf-8").read()
        except OSError:
            kz = ""
        kz1 = " ".join(kz.split())
        ok("K1 Vertrag mit dem Konzept (9.3, O1 bis O8): Abrufzeit 15:45 Uhr New York, 10 Minuten bis zum nächsten Versuch, Abweichung 1 %, "
           "fünf Strikes je Seite und 15 % Spanne, die fünf Marken und ihre z-Werte, 28 Tage und 3 Tage, die beiden Tabellen -- so stehen "
           "sie im Konzept und so rechnet das Modul",
           "### 9.3 Rechenweg und Abruf der Optionen-Schicht" in kz and all(f"**O{i} " in kz for i in range(1, 9))
           and "fällig ab 15:45 Uhr New York" in kz1 and (ABRUF_STUNDE, ABRUF_MINUTE) == (15, 45) and "(frühestens nach 10 Minuten)" in kz1 and WIEDER_S == 600
           and "F = K ÷ (1 − (Call − Put))" in kz1 and "um mehr als 1 % ab" in kz1 and ABW_MELDEN == 0.01
           and "mindestens fünf Puts und über F mindestens fünf Calls" in kz1 and MIN_STRIKES == 5 and "höchstens 15 %" in kz1 and MAX_SPANNE == 0.15
           and "C(K) = F · Put(K) + F − K" in kz1 and "z = −1,2816 / −0,6745 / 0 / +0,6745 / +1,2816" in kz1
           and [Z_WERT[q] for q in RAENDER] == [-1.2816, -0.6745, 0.0, 0.6745, 1.2816] and RAENDER == (10, 25, 50, 75, 90)
           and "brauchbarem Verfalltag ab 28 Tagen" in kz1 and MIN_TAGE_CHART == 28 and "höchstens 3 Tage vor dem Stichtag" in kz1 and MAX_ALTER_TAGE == 3
           and "Tabelle `lf_option`" in kz1 and "`lf_option_abruf`" in kz1 and "Die Kette selbst wird nicht gespeichert" in kz1,
           "Konzept gelesen" if kz else "KONZEPT_Langfrist.md fehlt")
        # ---- K2 Vertrag: was das Modul anfasst
        try:
            quelle = open(os.path.abspath(__file__), encoding="utf-8").read()
        except OSError:
            quelle = ""
        rumpf = quelle.split("\ndef selbsttest(", 1)[0]
        ok("K2 Vertrag: Das Modul schreibt nur in seine zwei Tabellen (kein Löschen von Dateien, keine andere Tabelle), ruft nur die feste "
           "Adresse von Deribit über den Abruf des Erstlaufs, und der Stand für den Chart öffnet die Datenbank nur lesend",
           bool(rumpf) and not any(w in rumpf for w in ("os.remove", "os.unlink", "shutil", "subprocess", "DROP TABLE", "urllib", "requests"))
           and rumpf.count("OP.abruf(OP.DERIBIT_URL") == 1 and rumpf.count("OP.abruf(") == 1 and rumpf.count("INSERT INTO lf_option ") == 1
           and rumpf.count("INSERT OR IGNORE INTO lf_option_abruf") == 1 and "INSERT INTO mk_" not in rumpf and "UPDATE mk_" not in rumpf
           and rumpf.count("?mode=ro") == 1 and OP.DERIBIT_URL.startswith("https://www.deribit.com/api/v2/public/"),
           f"{len(rumpf)} Zeichen vor dem Selbsttest")
    except Exception as e:
        import traceback
        ok("Ablauf ohne Ausnahme", False, f"{type(e).__name__}: {e} " + traceback.format_exc()[-900:].replace("\n", " | "))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    alles = bool(pruef) and all(p[1] for p in pruef)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({sum(p[1] for p in pruef)} von {len(pruef)}, {time.time() - t_start:.0f} s)")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--stand", action="store_true", help="gespeicherter Stand der Optionen-Schicht als Text (liest nur)")
    p.add_argument("--db", default=None, help="Pfad der Hauptdatenbank (makro.db liegt daneben)")
    p.add_argument("--selbsttest", action="store_true", help="Proben ohne Netz (erzeugte Ketten)")
    a = p.parse_args()
    if a.selbsttest:
        sys.exit(0 if selbsttest() else 1)
    if a.stand:
        import hl_makro as M
        pfad = M.makro_pfad(a.db) if a.db else M.makro_pfad("hl_liq.db")
        print(f"Optionen-Schicht des 24-Monats-Charts (U280) · Modul {VERSION_MODUL} · {_uhr(time.time())}")
        print("\n".join(stand_text(stand(pfad))))
        return
    p.print_help()


if __name__ == "__main__":
    main()
