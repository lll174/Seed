#!/usr/bin/env python3
"""
check_profis.py -- "Aktive Profis", Phase 2: Bewertung des Pools ausgeben (nur lesen).

  python3 check_profis.py --db PFAD [--alle]     (--alle: auch die Nicht-Qualifizierten mit Gründen)
"""
import argparse
import sqlite3
import time

import hl_profis as P


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--alle", action="store_true")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    t0 = time.time()
    r = P.bewerten(con)
    print(f"Aktive Profis -- Bewertung in {time.time() - t0:.1f} s · Coins {', '.join(r['coins'])}")
    print(f"Pool {r['n_pool']} (gesperrt {r['n_gesperrt']}) · aktiv 5–{P.PROFI_MAX_TRADES} Trades/Tag mit Gewinn 7 T: {r['n_aktiv']} · qualifiziert (Exit-Lift > 0, t ≥ 1): {r['n_qualifiziert']}")
    print(f"Rang: {r['rang_basis']}\n")
    print(f"{'#':>2} {'Konto':<14}{'Kontowert':>10}{'ROI 1T':>8}{'PnL 7T':>8}{'Tr/T':>6}{'Exits':>6}{'ExitLift':>9}{'t':>5}{'EntryLift':>10}{'Reakt.':>7} {'Coin':<5} Bot")
    for i, k in enumerate(r["top"], 1):
        nm = k["name"][:12] if k["name"] else k["addr"][:6] + "…" + k["addr"][-4:]
        print(f"{i:>2} {nm:<14}{(k['account_value'] or 0) / 1e6:>8.1f} M{(k['roi_1d'] or 0) * 100:>7.1f}%{(k['pnl_7d'] or 0) / 1e6:>+7.2f}M{k['trades_tag']:>6.0f}{k['n_exits']:>6}"
              f"{(k['exit_lift'] or 0) * 100:>+8.0f}pp{(k['exit_t'] or 0):>5.1f}{((k['entry_lift'] or 0) * 100):>+9.0f}pp{(k['reaktion_min'] if k['reaktion_min'] is not None else float('nan')):>7.0f} {str(k['bester_coin'] or '—'):<5} {'[bot]' if k['bot'] else ''}")
    if a.alle:
        print("\nNicht qualifiziert (erster Grund):")
        for k in [x for x in r["alle"] if not x["qualifiziert"]][:80]:
            nm = k["name"][:12] if k["name"] else k["addr"][:6] + "…" + k["addr"][-4:]
            print(f"   {nm:<14} Tr/T {k['trades_tag']:>5.0f} · {k['gruende'][0] if k['gruende'] else ''}")
    # Verteilung
    grund_z: dict = {}
    for k in r["alle"]:
        if k["gruende"]:
            g = k["gruende"][0].split(" (")[0].split(":")[0]
            key = "Aktivität" if "Trades/Tag" in k["gruende"][0] else "Gewinn 7 T" if "Gewinn" in k["gruende"][0] else "zu wenige Ausstiege" if "Ausstiege" in k["gruende"][0] else "Exit-Lift"
            grund_z[key] = grund_z.get(key, 0) + 1
    print("\nAusschlussgründe (erster Grund je Konto): " + ", ".join(f"{k} {v}" for k, v in sorted(grund_z.items(), key=lambda kv: -kv[1])))
    print("Lesart: Exit-Lift = Anteil der Ausstiege mit ≥ 2 % Korrektur binnen 12 h minus Placebo (200 Zufallszeitpunkte); t gegen n_eff (12-h-Blöcke).")
    con.close()


if __name__ == "__main__":
    main()
