#!/usr/bin/env python3
"""
check_profis.py -- "Aktive Profis", Phase 2: Bewertung des Pools ausgeben (nur lesen).

  python3 check_profis.py --db PFAD [--alle]     (--alle: auch die Nicht-Qualifizierten mit Gründen)
"""
import argparse
import sqlite3
import time

import hl_profis as P


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--alle", action="store_true")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    t0 = time.time()
    r = P.bewerten(con)
    print(f"Aktive Profis -- Bewertung in {time.time() - t0:.1f} s · Coins {', '.join(r['coins'])}")
    print(f"Pool {r['n_pool']} (gesperrt {r['n_gesperrt']}) · aktiv {P.PROFI_MIN_TRADES}–{P.PROFI_MAX_TRADES} Trades/Tag mit Gewinn 7 T: {r['n_aktiv']} · "
          f"qualifiziert (Timing: ≥ {P.MIN_ENTSCHEIDUNGEN} Ein-/Ausstiege, Glück ≤ {P.P_GLUECK_MAX * 100:.0f} %): {r['n_qualifiziert']}")
    q = r.get("quellen") or {}
    print(f"Ereignisse der Aktiven (7 T): {sum(q.values())} -- " + " · ".join(f"{n} {v}" for n, v in q.items())
          + f" · Konten mit Ereignissen {r.get('n_mit_ereignissen', 0)} von {r['n_aktiv']}")
    print(f"Rang: {r['rang_basis']}\n")
    print(f"{'#':>2} {'Konto':<14}{'Kontowert':>10}{'ROI 1T':>8}{'PnL 7T':>8}{'Tr/T':>6}{'Ein/Aus':>8}{'richtig':>8}{'Zufall':>7}{'Glück':>7}{'ExitLift':>9}{'Reakt.':>7} {'Coin':<5} Bot")
    pz = lambda v: f"{v * 100:.0f}%" if v is not None else "—"
    for i, k in enumerate(r["top"], 1):
        nm = k["name"][:12] if k["name"] else k["addr"][:6] + "…" + k["addr"][-4:]
        t_ = k.get("timing") or {}
        el = f"{k['exit_lift'] * 100:+.0f}pp" if k.get("exit_lift") is not None else "—"
        rk = f"{k['reaktion_min']:.0f}" if k.get("reaktion_min") is not None else "—"
        print(f"{i:>2} {nm:<14}{(k['account_value'] or 0) / 1e6:>8.1f} M{(k['roi_1d'] or 0) * 100:>7.1f}%{(k['pnl_7d'] or 0) / 1e6:>+7.2f}M{k['trades_tag']:>6.0f}"
              f"{t_.get('n_ein', 0):>4}/{t_.get('n_aus', 0):<3}{t_.get('treffer', 0):>8}{pz(t_.get('zufall')):>7}{pz(t_.get('p_glueck')):>7}{el:>9}{rk:>7} "
              f"{str(k['bester_coin'] or '—'):<5} {'[bot]' if k['bot'] else ''}")
    if a.alle:
        print("\nNicht qualifiziert (erster Grund; die knappsten zuerst: Timing, dann zu wenige Ein-/Ausstiege, Gewinn, Aktivität):")
        rang_k = {"Timing nicht belegt": 0, "Einstiege widerlegt": 1, "zu wenige Ein-/Ausstiege": 2, "Gewinn 7 T": 3, "Aktivität": 4}
        nq = sorted([x for x in r["alle"] if not x["qualifiziert"]],
                    key=lambda x: (rang_k.get(P.grund_kategorie(x["gruende"][0] if x["gruende"] else ""), 5),
                                   ((x.get("timing") or {}).get("p_glueck") if (x.get("timing") or {}).get("p_glueck") is not None else 1.0), -(x["trades_tag"] or 0)))
        for k in nq[:80]:
            nm = k["name"][:12] if k["name"] else k["addr"][:6] + "…" + k["addr"][-4:]
            print(f"   {nm:<14} Tr/T {k['trades_tag']:>5.0f} · {k['gruende'][0] if k['gruende'] else ''}")
    # Verteilung (23.34: eigene Kategorien -- vorher zählte „Glückswahrscheinlichkeit zu hoch“ als „zu wenige Ausstiege“)
    grund_z = r.get("gruende") or P.grund_zaehlung(r["alle"])
    print("\nAusschlussgründe (erster Grund je Konto): " + ", ".join(f"{k} {v}" for k, v in grund_z.items()))
    print(f"Lesart: Ein Ein- oder Ausstieg ist richtig, wenn binnen 12 h eine Bewegung ≥ 2 % in seine Richtung folgt (Ausstieg Long: Rückgang). "
          f"Qualifiziert, wer mindestens {P.MIN_ENTSCHEIDUNGEN} bewertbare Ein-/Ausstiege hat (gleichgerichtete im selben 4-h-Block einmal) und dessen "
          f"Trefferbilanz höchstens mit {P.P_GLUECK_MAX * 100:.0f} % Wahrscheinlichkeit Glück ist -- gegen die Zufallsquote je Coin und Richtung "
          f"(200 Zufallszeitpunkte). Exit-/Entry-Lift nur zur Anzeige; Einstiege ab {P.ENTRY_VETO_MIN} als Veto.")
    con.close()


if __name__ == "__main__":
    main()
