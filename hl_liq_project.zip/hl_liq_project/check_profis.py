#!/usr/bin/env python3
"""
check_profis.py -- "Aktive Profis": Bewertung des Pools und Stand der Darwin-Liste ausgeben (nur lesen).

Seit 23.37 (Regeln v2): Aufnahme streng, Verbleib großzügig; seit 23.38 (v3) gilt die Schonung nur für streng Aufgenommene.
Gezeigt werden die Mitglieder mit ihrem Verbleib-Urteil und den Fehltagen, Mitglieder ohne Bewertung (gesperrt, nicht mehr im
Pool), die Zu- und Abgänge der letzten 7 Tage mit Grund und die Konten, die die Aufnahme jetzt erfüllen. Mit --alle zusätzlich
alle übrigen mit dem ersten Grund gegen die Aufnahme.

  python3 check_profis.py --db PFAD [--alle]
"""
import argparse
import os
import sqlite3
import time

import hl_profis as P


def _darwin_stand(db: str) -> tuple:
    """Stand der Darwin-Liste aus dem Prognosespeicher neben der Datenbank (sonst dem üblichen), nur lesen."""
    import hl_forecast
    kand = [os.path.join(os.path.dirname(os.path.abspath(db)), "forecasts.db"), hl_forecast.STORE]
    for pfad in kand:
        if not os.path.exists(pfad):
            continue
        try:
            st = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True)
            row = st.execute("SELECT value, updated FROM learned WHERE coin='*' AND key='darwin'").fetchone()
            st.close()
        except sqlite3.Error:
            continue
        if row:
            import json
            try:
                return json.loads(row[0]), pfad
            except ValueError:
                return {}, pfad
    return {}, None


def _t(ts) -> str:
    return time.strftime("%d.%m. %H:%M", time.localtime(int(ts or 0)))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--alle", action="store_true")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    st, pfad = _darwin_stand(a.db)
    liste = [str(x).lower() for x in (st.get("liste") or [])]
    t0 = time.time()
    r = P.bewerten(con, mitglieder=liste)
    alle = {k["addr"]: k for k in r["alle"]}
    pz = lambda v: f"{v * 100:.0f}%" if v is not None else "—"
    pg = lambda v: ("—" if v is None else f"{v * 100:.1f}%" if v < 0.1 else f"{v * 100:.0f}%")     # Glück: kleine Werte mit einer Stelle
    print(f"Aktive Profis -- Bewertung in {time.time() - t0:.1f} s · Coins {', '.join(r['coins'])}")
    print(f"Regeln v{P.REGEL_VERSION} (23.38). Aufnahme: {P.PROFI_MIN_TRADES}–{P.PROFI_MAX_TRADES} Trades/Tag, Gewinn 7 T und 30 T > 0, "
          f"≥ {P.AUFNAHME_MIN_ENTSCH} Ein-/Ausstiege in {P.TIMING_TAGE} T, Glück ≤ {P.AUFNAHME_P_GLUECK * 100:.0f} %, "
          f"Vorsprung ≥ {P.AUFNAHME_MIN_VORSPRUNG * 100:.0f} Punkte.")
    print(f"             Verbleib: {P.VERBLEIB_MIN_TRADES}–{P.PROFI_MAX_TRADES} Trades/Tag, Gewinn 30 T > 0, ≥ {P.VERBLEIB_MIN_ENTSCH} Ein-/Ausstiege, "
          f"Glück ≤ {P.VERBLEIB_P_GLUECK * 100:.0f} %. Abstieg nach {P.DARWIN_ABSTIEG_TAGE} Tagen in Folge ohne Verbleib.")
    print("             Diese Schonung nur für Konten, die über die strenge Aufnahme kamen; jeder Weg auf die Liste verlangt sie (v3).")
    print(f"Pool {r['n_pool']} (gesperrt {r['n_gesperrt']}) · vorab aufnahmefähig (Aktivität, Gewinn 7 T und 30 T): {r['n_aktiv']} · "
          f"erfüllen die Aufnahme jetzt: {r['n_qualifiziert']}")
    q = r.get("quellen") or {}
    print(f"Ereignisse ({P.TIMING_TAGE} T): {sum(q.values())} -- " + " · ".join(f"{n} {v}" for n, v in q.items())
          + f" · Konten mit Ereignissen {r.get('n_mit_ereignissen', 0)}")
    kf = r.get("kleinfill") or {}
    if kf.get("ts"):
        print(f"Neubewertung der Masterregel (Zählfehler 23.34–23.36) am {_t(kf['ts'])}: {len(kf.get('frei') or [])} Konten freigegeben"
              + (f" -- {', '.join(x[:6] + '…' + x[-4:] for x in kf['frei'])}" if kf.get("frei") else "")
              + (f" · zurückgenommen am {_t(kf.get('zurueck_ts'))} (ohne kleine Bündel, 23.38): {', '.join(x[:6] + '…' + x[-4:] for x in kf['zurueck'])}"
                 if kf.get("zurueck") else ""))

    kopf = f"   {'Konto':<16}{'Kontowert':>10}{'ROI 7T':>8}{'PnL 7T':>8}{'PnL 30T':>9}{'Tr/T':>6}{'richtig':>9}{'Zufall':>7}{'Glück':>7}{'Vorspr.':>8}"
    nm = lambda k: (k.get("name") or "")[:14] or (k["addr"][:6] + "…" + k["addr"][-4:])

    def zeile(k, extra=""):
        t_ = k.get("timing") or {}
        vs = t_.get("lift_s")
        return (f"   {nm(k):<16}{(k.get('account_value') or 0) / 1e6:>8.1f} M{(k.get('roi_7d') or 0) * 100:>7.1f}%{(k.get('pnl_7d') or 0) / 1e6:>+7.2f}M"
                f"{(k.get('pnl_30d') or 0) / 1e6:>+8.2f}M{k.get('trades_tag') or 0:>6.0f}{str(t_.get('treffer', 0)) + '/' + str(t_.get('n', 0)):>9}"
                f"{pz(t_.get('zufall')):>7}{pg(t_.get('p_glueck')):>7}{(f'{vs * 100:+.0f}' if vs is not None else '—'):>8}{extra}")

    print(f"\nDarwin-Liste: {len(liste)} Mitglieder · Tagesentscheidung {_t((st.get('tag') or 0) * 86_400)} · Stand aus {pfad or '—'}"
          f" · Regeln v{st.get('regel') or 1}")
    if st and st.get("regel") != P.REGEL_VERSION:                     # 23.38: Umstieg steht noch aus -- Vorschau auf einer Kopie
        import copy
        sim = P.darwin_tag(copy.deepcopy(st), r)
        neu_ab = [e for e in (sim.get("abgaenge") or []) if e not in (st.get("abgaenge") or [])]
        neu_zu = [e for e in (sim.get("zugaenge") or []) if e not in (st.get("zugaenge") or [])]
        kz = lambda e: (e.get("name") or "")[:14] or (e["addr"][:6] + "…" + e["addr"][-4:])
        print(f"   Umstieg auf v{P.REGEL_VERSION} bei der nächsten Bewertung des Dashboards (stündlich) -- Vorschau: bleiben/kommen "
              f"{', '.join(kz({'addr': a_, 'name': (alle.get(a_) or {}).get('name')}) for a_ in sim.get('liste') or []) or 'niemand'}"
              + (f" · raus: {', '.join(kz(e) for e in neu_ab)}" if neu_ab else "") + (f" · neu: {', '.join(kz(e) for e in neu_zu)}" if neu_zu else ""))
    if liste:
        streng = st.get("streng") if isinstance(st.get("streng"), dict) else None
        print(kopf + "  Fehltage · Verbleib jetzt")
        for a_ in liste:
            k = alle.get(a_)
            ft = int((st.get("verfehlt") or {}).get(a_, 0))
            sm = ("" if streng is None else f" · streng seit {_t(streng[a_])[:6]}" if a_ in streng else " · OHNE strenge Aufnahme")
            if not k:
                print(f"   {a_[:6] + '…' + a_[-4:]:<16}  ohne Bewertung: {(r.get('fehlend') or {}).get(a_, 'nicht bewertet')} · Fehltage {ft}{sm}")
                continue
            urteil = "erfüllt" if k.get("verbleib") else "VERFEHLT: " + ((k.get("gruende_verbleib") or ["—"])[0])
            print(zeile(k, f"  {ft}/{P.DARWIN_ABSTIEG_TAGE} · {urteil}{sm}"))
    sieben = time.time() - 7 * 86_400
    prot = [("rein", e) for e in (st.get("zugaenge") or []) if (e.get("ts") or 0) >= sieben] + \
           [("raus", e) for e in (st.get("abgaenge") or []) if (e.get("ts") or 0) >= sieben]
    print(f"\nZu- und Abgänge der letzten 7 Tage: {len(prot)}" + ("" if prot else " (Protokoll gibt es seit 23.37)"))
    for art, e in sorted(prot, key=lambda x: -(x[1].get("ts") or 0)):
        n_ = (e.get("name") or "")[:14] or (e["addr"][:6] + "…" + e["addr"][-4:])
        print(f"   {_t(e.get('ts'))}  {'▲ rein' if art == 'rein' else '▼ raus'}  {n_:<16} {e.get('grund', '')}")
    neu = [k for k in r["alle"] if k.get("aufnahme") and k["addr"] not in liste]
    print(f"\nErfüllen die Aufnahme, noch nicht auf der Liste (kommen bei der nächsten Tagesentscheidung dazu): {len(neu)}")
    if neu:
        print(kopf)
        for k in sorted(neu, key=lambda k: -((k.get("timing") or {}).get("lcb") or -9)):
            print(zeile(k))
    if a.alle:
        print("\nNicht aufnahmefähig (erster Grund; die knappsten zuerst):")
        rang_k = {"Vorsprung zu klein": 0, "Timing nicht belegt": 1, "Einstiege widerlegt": 2, "zu wenige Ein-/Ausstiege": 3, "Gewinn 30 T": 4,
                  "Gewinn 7 T": 5, "Aktivität": 6}
        nq = sorted([x for x in r["alle"] if not x.get("aufnahme") and x["addr"] not in liste],
                    key=lambda x: (rang_k.get(P.grund_kategorie(x["gruende"][0] if x["gruende"] else ""), 7),
                                   ((x.get("timing") or {}).get("p_glueck") if (x.get("timing") or {}).get("p_glueck") is not None else 1.0), -(x["trades_tag"] or 0)))
        for k in nq[:80]:
            print(f"   {nm(k):<16} Tr/T {k['trades_tag']:>5.0f} · {k['gruende'][0] if k['gruende'] else ''}")
    grund_z = r.get("gruende") or P.grund_zaehlung(r["alle"])
    print("\nGründe gegen die Aufnahme (erster je Konto): " + ", ".join(f"{k} {v}" for k, v in grund_z.items()))
    print(f"Lesart: Ein Ein- oder Ausstieg ist richtig, wenn binnen 12 h eine Bewegung ≥ 2 % in seine Richtung folgt (Ausstieg Long: Rückgang); "
          f"gleichgerichtete im selben 4-h-Block zählen einmal. Glück = Wahrscheinlichkeit, die Trefferzahl rein zufällig zu erreichen (gegen die "
          f"Zufallsquote je Coin und Richtung aus 200 Zufallszeitpunkten). Vorsprung = gedämpfte Trefferquote minus Zufall in Punkten. "
          f"Einstiege ab {P.ENTRY_VETO_MIN} als Veto.")
    con.close()


if __name__ == "__main__":
    main()
