# KONZEPT Chartbild (U143 Stufe 1) — die Lage je Coin in Worten: Trend, Bein, Niveaus, Schwankung, Positionierung

Stand 10.10.2026, Version 2026-09-23.65 (Opus 5.5). **Status: gebaut in 23.65** (`hl_chartbild.py`, `hl_chartbild_js.py`, Abschnitt
„CB Chartbild“ im Dashboard). Was sich beim Bau gegenüber der ersten Fassung geändert hat, steht mit Grund in Abschnitt 9.1. Auftrag des Nutzers 10.10. 22:20 („Ja“ zur Frage, Stufe 1 als 23.65 zu bauen). Grundlage:
`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` Abschnitt 6.5 und die Antwort vom 10.10. 22:16.

**Wunsch des Nutzers (09.10. 02:05, gekürzt):** eine vollwertige Chartanalyse wie bei TradingView, gestützt durch alle gesammelten
Daten als untere Schicht, als virtueller algorithmischer Trader. **Stufe 1** ist davon die Anzeige: Sie beschreibt die Lage, sie
handelt nicht und gibt kein Signal. Stufe 2 (Niveau-Test) und Stufe 3 (Chart-Trader im Labor) sind eigene Schritte.

**Zusage bis 25.10. bleibt:** Fusion, v3, Kaskaden-Rechnung, v1-Lernen, Konfluenz, Labor und Prognose bleiben unberührt. Das Chartbild
liest nur und schreibt nichts.

## 0. Kurzfassung

- **Ein Abschnitt je Coin** (Coin-Auswahl im Kopf des Dashboards): eine Lesart in fünf bis sechs Sätzen, ein Tageschart mit den
  gezeigten Bausteinen, Tabellen mit allen Zahlen und daneben, was davon geprüft ist.
- **Bausteine:** Trendlage (200- und 50-Tage-Linie), laufendes Bein im Directional Change (Schwellen der Zyklus-Studie U141),
  nächste Niveaus (Wände, Take-Profits und Stops der Großkonten, Liquidationscluster, Swing-Hochs und -Tiefs, runde Zahlen), RSI 14,
  erwartete Schwankung als 80-%-Band für 1 und 7 Tage (dasselbe HAR wie die Regime-Vorprüfung P0.2) samt gemessener Trefferquote,
  daneben Funding-Druck, OI-, Konten- und Top-Trader-Perzentil und Fear & Greed.
- **Ohne Punkte, ohne Richtung:** Die Studien U141, U142 und U110 haben für keinen dieser Bausteine ein belegtes Timing gezeigt.
  Jede Zeile nennt ihren Prüfstand. Die Niveaus sind ungeprüft, bis Stufe 2 sie testet.
- **Nur lesend** aus `hl_liq.db`, `swing.db`, `regime.db` (nur PAXG), `hebel.db` und `makro.db`. Fehlt eine Quelle oder ist sie zu
  alt, steht dort „—“ mit dem Grund; der Rest erscheint trotzdem.

## 1. Was das Chartbild zeigt und was nicht

| zeigt | zeigt nicht |
|---|---|
| Lage in Zahlen und Worten, jede mit Quelle, Alter und Prüfstand | Kauf, Verkauf, Ziel, Stop, Punktzahl, „bullisch/bärisch“ |
| erwartete Schwankung als Band mit gemessener Trefferquote | eine Richtung für heute oder die Woche |
| Niveaus, an denen echte Orders oder Positionen liegen | Fibonacci, Elliott, frei gezogene Trendlinien (zu viele Freiheitsgrade, RECHERCHE 6.6) |
| typische Größe abgeschlossener Beine | ein „sicheres“ Prozentziel (U141: Größen wie ein Zufallsweg) |

## 2. Daten und Frische

| Baustein | Quelle | Frische, sonst „—“ |
|---|---|---|
| Tageskerzen, 200/50-Tage-Linie, RSI, Bein, Swing-Hochs/-Tiefs | `daily_bars` in `hl_liq.db` (hl_binance, alle 6 h; Binance-Futures, sonst Spot, sonst Hyperliquid) | letzter abgeschlossener Tag höchstens 3 Tage alt |
| Kurs jetzt | jüngste 1-min-Kerze in `hl_liq.db` (Hyperliquid) | höchstens 15 min |
| Wände, Take-Profits, Stops | `trigger_orders` (Konten ab 250k USD, jüngster Stand je Konto aus 6 h), Rechnung wie `keyLevels()` im Live-Chart | Stand höchstens 6 h |
| Liquidationscluster | jüngster Heatmap-Stand (`heatmap`), Stundenvolumen aus `bars` | höchstens 30 min |
| Schwankungsband | 30-min-Kerzen: `swing.db` (BTC, ETH, ZEC, XMR, HYPE), `regime.db` (PAXG), die letzten 1.096 Tage | letzte Kerze höchstens 2 Tage alt |
| Funding-Druck | `swing.db` (`sw_funding`) | letzter Tag höchstens 3 Tage alt |
| OI, Konten, Top-Trader | `hebel.db` (Tagesstände aus dem Binance-Archiv) und live `bnc_metrics` in `hl_liq.db` | Archiv höchstens 4 Tage, live höchstens 3 h |
| Fear & Greed | `makro.db` (`fng:wert`) | höchstens 3 Tage |

Ein Tag ist abgeschlossen, wenn er vor 00:00 UTC heute liegt. Alles außer „Kurs jetzt“, den Niveaus und den Live-Werten beschreibt
den Stand am letzten Tagesschluss.

## 3. Bausteine (Definitionen, fest)

### 3.1 Trendlage
- SMA 200 und SMA 50 der Tagesschlüsse (abgeschlossene Tage). Abstand des letzten Schlusses zur 200-Tage-Linie in %.
- Steigung der 50-Tage-Linie: Vorzeichen von SMA50_d − SMA50_{d−1}; „seit k Tagen“ = Tage in Folge mit demselben Vorzeichen.
- Lage der 50- zur 200-Tage-Linie und der letzte Wechsel (Golden/Death Cross) mit Datum.
- Prüfstand: „über der 200-Tage-Linie“ ist T200 aus U141 — nicht sicherer als Halten (ΔSR +0,20, p Holm 0,52).

### 3.2 Bein (Directional Change)
- Wie U141 Teil A (`hl_zyklus.dc_batch`, `beine`, `_dc_stand`): Tief bestätigt, wenn der Schluss um X über dem laufenden Tief
  liegt, Hoch bestätigt bei X darunter; X = 10/20/30 % (PAXG 3/5/10 %); auf den Tagesschlüssen von `daily_bars` (Lücken bis
  3 Tage aufgefüllt, `hl_zyklus.achse`).
- Je Schwelle: Richtung des laufenden Beins, sein Extrem (Tief oder Hoch) mit Datum, Größe bisher, Abstand des Schlusses zum
  Extrem, die Bestätigungsschwelle der Gegenrichtung.
- Abgeschlossene Beine derselben Reihe: Zahl, Median und Quartile von Größe und Dauer, getrennt für Rallyes und Rücksetzer.
- Prüfstand: U141 Teil A — Größe und Dauer wie ein Zufallsweg mit derselben Drift und Schwankung (p Holm 0,89/0,89/0,93); der
  Median ist eine Beschreibung, kein Ziel.

### 3.3 Niveaus
- **Großkonten (Hyperliquid):** je Art das größte Cluster im 0,25-%-Raster innerhalb ±30 % (wie `keyLevels()`): Kaufwand unter dem
  Kurs (Support), Verkaufswand darüber (Resistance), Take-Profits der Longs (oben) und der Shorts (unten), Sell-Stops (unten),
  Buy-Stops (oben); dazu das nächste Stop-Cluster je Seite. Größe in USD, Zahl der Konten.
- **Liquidationscluster:** jüngster Heatmap-Stand, unten Long- und oben Short-Liquidationen innerhalb −12 %/+15 %: je Seite das
  größte und das nächste, das mindestens das halbe Stundenvolumen erreicht (die Grenze der durchgezogenen Linien im Live-Chart).
- **Swing-Hochs und -Tiefs:** Tageshoch über den 5 Tagen davor und mindestens so hoch wie die 5 Tage danach (Tief spiegelbildlich),
  also erst nach 5 Tagen bestätigt; aus den letzten 365 Tagen die zwei nächsten über bzw. unter dem Kurs, wie die Orders höchstens
  ±30 % entfernt (beim Bau ergänzt, 9.1).
- **Runde Zahlen:** Schritt 1, 2 oder 5 Einheiten der zweiten Stelle nach der führenden Ziffer, also immer 4–10 % des Kurses
  (BTC um 62.000: 5.000; ETH um 2.400: 200; PAXG um 2.650: 200; XMR um 310: 20; ZEC um 52: 5; HYPE um 38: 2); die nächste darüber und
  darunter, liegt der Kurs genau auf einer, die nächste davon weg (beim Bau geändert, 9.1).
- Je Niveau: Abstand in % zum Kurs jetzt und in σ (σ = √ der HAR-Erwartung für 1 Tag, sonst σ_Tag aus EWMA), Quelle, Alter.
- Prüfstand: Wände, Take-Profits, Stops und Swings ungeprüft (Stufe 2); Liquidationscluster: Anziehung bisher nicht belegt (Magnet
  U110, Urteil ab 25.10.); runde Zahlen bei BTC ohne Renditemuster (Urquhart 2017), hier ungeprüft.

### 3.4 RSI 14
- Nach Wilder auf den Tagesschlüssen (`hl_swing.rsi_wilder`). Prüfstand: RSI ≥ 80 vor Rücksetzern kein Effekt (U141 C3, RR 1,01).

### 3.5 Erwartete Schwankung (80-%-Band, 1 und 7 Tage)
- Das HAR-log der Regime-Vorprüfung P0.2 (`hl_regime.har_prognosen`): log der Ziel-Varianz auf log RV des Tags, der Woche und des
  Monats. Für das Chartbild einmal auf allen Tagen geschätzt, deren Ziel vollständig vor dem Prognosetag liegt (dieselbe Sperre
  wie P0.2), Prognose am letzten Tag mit voller RV. Band = Schluss · e^(q₁₀·√F) bis Schluss · e^(q₉₀·√F), q aus den
  standardisierten h-Tage-Renditen der Schätztage.
- **Trefferquote live:** dieselbe rollierende Rechnung wie P0.2 (`har_prognosen`, monatlich neu geschätzt) über die letzten
  365 Tage: Anteil der Tage, an denen die h-Tage-Rendite im Band lag, mit Standardfehler √(0,16 · h / n); erst ab 90 Prognosetagen
  (sonst „—“ mit der Zahl; beim Bau ergänzt, 9.1).
- Prüfstand P0.2: HAR schlägt EWMA bei 1 Tag in allen sechs Coins; das 80-%-Band hielt bei BTC, ETH und HYPE (79,5–84,4 %), bei ZEC
  (74–76 %), XMR (76–77 %) und PAXG (69–72 %) war es zu schmal. Das Chartbild nennt beides, die Bandkalibrierung für ZEC, XMR und
  PAXG bleibt der Regime-Phase 1 vorbehalten (Entscheidung 9 in `KONZEPT_Regime.md`).

### 3.6 Lage daneben
- **Funding-Druck z30** wie U141 C2: (Tagesmittel − Mittel der 30 Tage davor) ÷ deren Standardabweichung (`hl_swing.Kennzahlen.fz`),
  dazu die jüngste Rate je 8 h. Prüfstand: z ≥ 2 vor Rücksetzern eher weniger (RR 0,67), nicht belegt.
- **OI-Perzentil** wie U141 C1: Mittelrang des OI (in Coins) unter den 90 Tagesständen davor; jetzt = Live-Wert gegen die letzten
  90 Tagesstände. Prüfstand: ≥ 0,90 Hinweis (RR 1,60), nicht belegt.
- **Konten** (Long/Short aller Konten) und **Top-Trader nach Positionen:** Wert und Perzentil wie OI. Prüfstand: Konten ≥ 3 vor
  Rücksetzern — U142 H1, Bedingung erfüllt, vorläufig (Stand 10.10., endgültig mit dem Lauf 11.10.); Top-Trader-Regel — U142 H2
  nicht belegt, sie steht fast immer auf „Kauf“.
- **Fear & Greed** (alternative.me) mit Klasse: 0–24 extreme Angst, 25–44 Angst, 45–55 neutral, 56–75 Gier, 76–100 extreme Gier.
  Prüfstand: ≥ 80 vor Rücksetzern eher weniger (U141 C4, RR 0,37), nicht belegt. Nicht für PAXG (ein Krypto-Stimmungsindex sagt über
  Gold nichts); PAXG hat auch kein Funding und keine Binance-Positionierung -- das steht als „bewusst nicht gezeigt“, nicht als Lücke.

### 3.7 Prüfstände
Fest im Modul (`PRUEFSTAND`) mit Datum; jede neue Auswertung aktualisiert sie mit dem nächsten Paket. Die Anzeige liest keine
Berichte aus, damit kein halbfertiger Lauf als Befund erscheint.

## 4. Lesart (Regeln für die Sätze)

Fünf bis sechs kurze Sätze, nur aus den Zahlen oben, in fester Reihenfolge; ohne Wörter einer Empfehlung („kaufen“, „verkaufen“,
„Ziel“, „bullisch“, „bärisch“, „Signal“ nur als „kein Signal“).
1. **Trend:** über/unter der 200-Tage-Linie (Abstand), 50-Tage-Linie steigt/fällt seit k Tagen.
2. **Bein (kleinste Schwelle):** Richtung seit Extrem und Datum, Größe bisher, Bestätigungsschwelle der Gegenrichtung; Median der
   abgeschlossenen Beine dieser Richtung — „Größen wie ein Zufallsweg (U141), kein Ziel“.
3. **Niveaus:** das nächste darunter und darüber (Art, Preis, Abstand in % und σ) — „alle ungeprüft“; ohne runde Zahlen und ohne
   das nächste Stop-Cluster, das keine Mindestgröße hat (beides steht in der Tabelle).
4. **Schwankung:** 80-%-Band für den nächsten Tagesschluss und für 7 Tage in Preis und %, Trefferquote zuletzt.
5. **Lage daneben:** RSI, Funding-Druck, OI- und Konten-Perzentil, Fear & Greed, je mit Prüfstand in Kurzform, nur wenn vorhanden.
6. **Schluss:** „Lagebeschreibung, kein Signal.“

Fehlt ein Baustein, entfällt sein Satz; die Tabelle nennt den Grund.

## 5. Anzeige

- Abschnitt **„CB Chartbild“** direkt nach dem Live-Chart, Eintrag „Chartbild“ in der Navigation; fragt nur, solange er offen und
  sichtbar ist (alle 2 min, beim Coin-Wechsel sofort); Antwort im Server 60 s gespeichert, die Tagesrechnung 10 min.
- **Kopf:** Kurs jetzt mit Quelle und Uhrzeit (ohne frische 1-min-Kerze: der letzte Tagesschluss, mit Grund), Stand der Tageskerzen,
  Datum der Prüfstände.
- **Lesart** als Liste, der Schlusssatz „Lagebeschreibung, kein Signal.“ abgesetzt.
- **Filterzeile:** Zeitraum 1/3/6/12/24 Monate (Standard 6, auf dem Handy 3), Ebenen Bein, Swings, Niveaus, Spanne einzeln ein/aus,
  Tabelle statt Bild (alles im Browser gemerkt).
- **Tageschart** auf log. Skala: Kerzen neutral -- hohl = Tag im Plus, gefüllt = Tag im Minus (ab 4 px je Tag; darunter Schlusslinie
  mit der Tagesspanne als Fläche); 50-Tage-Linie blau, 200-Tage-Linie gelbbraun, Bein der kleinsten Schwelle als Zickzack der
  bestätigten Extreme (pink), das laufende Bein gestrichelt, danach bis zum letzten Schluss gepunktet, die Bestätigungsschwelle der
  Gegenrichtung als gestrichelte Linie mit Beschriftung; Swing-Hochs ▼ über dem Hoch, -Tiefs ▲ unter dem Tief. Rechts der Linie
  „heute“ die Zone „jetzt und danach“: Niveaus als Linien in den Farben des Live-Charts (Stops gepunktet, Liquidationscluster
  gestrichelt) mit Nummer wie in der Tabelle und -- ab 700 px Breite -- einer Beschriftungsspalte (Name, Preis, Abstand); Orders und
  Liquidationscluster sind Momentaufnahmen und reichen deshalb nicht in die Vergangenheit, Swing-Linien beginnen an ihrem Tag, runde
  Zahlen gehen leise über die ganze Breite. Das 80-%-Band als Fächer vom letzten Schluss zu den Strichen „heute“ und „+7 T“
  (dazwischen nur verbunden), Kurs jetzt als Linie mit Punkt an der Uhrzeit und Kasten an der Preisachse. Der y-Bereich folgt Kerzen,
  Kurs, Band und Bestätigungsschwelle; eine Linie, die mehr als 15 % darüber hinausragt, wird am Rand beschriftet („MA 200 … ▲
  außerhalb“) statt die Kerzen zusammenzudrücken; Niveaus außerhalb stehen nur in der Tabelle („▲ n weitere darüber“).
  Darunter RSI 14 im eigenen Feld (Skala 0–100, Linien 30/50/70, gleiche Zeitachse, gemeinsames Fadenkreuz -- nie eine zweite Achse
  im selben Feld). Fadenkreuz mit Tageswerten (Eröffnung bis Schluss, Veränderung, MA, RSI, Swing, Bein), in der Zone mit dem Band,
  dazu der Preis an der Zeigerhöhe und Niveaus in seiner Nähe. Legende immer, Tabellenansicht mit allen Tageswerten.
- **Tabellen:** Niveaus von oben nach unten mit der Zeile „Kurs jetzt“ an ihrem Platz, Bein je Schwelle, Spanne, Lage daneben (mit
  90-Tage-Verlauf als Kleinstchart), Prüfstände (aufklappbar), Was fehlt, Bewusst nicht gezeigt.
- Handy: Chart volle Breite, Nummern statt Beschriftungsspalte, Tabellen scrollen im eigenen Rahmen, keine Seitenbreite über den
  Bildschirm.

## 6. Abgrenzung

- Kein Treiber, kein Punkt in der Konfluenz, keine Labor-Strategie, keine Prognose. Was das Chartbild zeigt, geht in nichts ein.
- Das Bein auf 30-min-Kerzen mit D/θ (Regime RG5) und die Bandkalibrierung für ZEC, XMR, PAXG gehören zur Regime-Phase 1
  (Entscheidungen 8 und 9 in `KONZEPT_Regime.md`) und sind hier bewusst nicht enthalten.

## 7. Proben (Selbsttest ohne Netz)

Stand 23.65: 42 Prüfungen in rund 5 s (Sandbox), Mutationen 51 von 51 rot (vier davon an `hl_viz.chartbild_live`); dazu die Browserprobe (unten). Geplant waren:

1. **Bausteine von Hand:** SMA und Steigung, Kreuzung mit Datum, Swing-Hochs/-Tiefs auf einer gebauten Reihe (Bestätigung erst nach
   5 Tagen), runde Zahlen je Größenordnung, Liquidations- und Ordermarken auf gebauten Daten, Perzentil wie `hl_zyklus.oi_perzentil`,
   Funding-Druck wie `hl_swing.Kennzahlen.fz`, RSI wie `hl_swing.rsi_wilder`.
2. **Gleich der Studie:** Beinstand und Beinstatistik identisch mit `hl_zyklus` auf derselben Reihe; die HAR-Prognose am Tag vor
   einem Monatsanfang identisch mit `hl_regime.har_prognosen` (gleiche Sperre).
3. **Kausalität:** Daten nach dem Tag d geändert → Trendlage, Bein, Swings, Band und Perzentile am Tag d unverändert.
4. **Kontrolle des Bands:** auf einem synthetischen Markt mit wechselnder Schwankung trifft das 80-%-Band 80 % ± 2 SE (1 und
   7 Tage); ein Band mit halber Breite trifft deutlich weniger (die Trefferquote erkennt ein falsches Band).
5. **Lesart:** feste Sätze für gebaute Lagen (über/unter, steigend/fallend, Bein auf/ab, fehlende Bausteine), keine Wörter einer
   Empfehlung, immer „kein Signal“.
6. **Frische und Lücken:** fehlende oder alte Quellen → „—“ mit Grund, der Rest bleibt; JSON ohne NaN.
7. **Ende zu Ende:** synthetische `hl_liq.db`, `swing.db`, `hebel.db`, `makro.db` und `regime.db` → Antwort für alle sechs Coins wie
   auf dem Pi.
Dazu `node --check` für das Skript und Bildschirmfotos (Desktop und Handy) mit Demo-Daten vor der Lieferung; Mutationen.

Beim Bau dazugekommen (jede, weil eine Mutation sonst grün geblieben wäre oder eine Lücke sichtbar wurde): Tageskerzen mit Lücke von
1 Tag (aufgefüllt), mehr als 3 Tagen (Reihe beginnt neu), laufender Tag ohne Wirkung und ein Hoch unter dem Schluss (auf den Schluss
angehoben); Schritt der runden Zahl lesbar; ein Swing bei −40 % erscheint nicht; Band-Grenzen = Schluss · e^(Quantil · √F), 7 Tage
breiter als 1 Tag, σ in der Größe der Tagesrenditen; Trefferquote nur aus den letzten 365 Tagen (Zählung von Hand); Funding-Druck am
letzten vollen Tag, RSI gleich Wilder auf den gelieferten Schlüssen, Zickzack ab dem Chartfenster samt dem einen Punkt davor, Swings
nur aus 365 Tagen und erst nach 5 Tagen; Kurs ohne frische 1-min-Kerze → letzter Tagesschluss mit Grund; Positionierung ohne frische
Live-Zeile → Tagesstand von gestern mit Perzentil gegen die 90 Stände davor (von Hand); PAXG: „bewusst nicht gezeigt“ statt „fehlt“;
Live-Teil je Teil für sich (ohne Heatmap-Tabelle bleibt der Kurs, eine scheiternde Order-Abfrage nimmt weder Kurs noch
Liquidationscluster mit).

**Browserprobe** (in der Sandbox vor jeder Lieferung, durch Claude; braucht Chromium und ist deshalb nicht im Paket): das gezeichnete SVG gegen die Nutzlast des Servers, gemessen an der
beschrifteten Preisachse -- nicht mit den JS-Funktionen selbst (sonst bestätigt die Probe nur sich selbst). Vier Szenarien (BTC 6 M
und 1 J, PAXG 3 M am Desktop, HYPE 3 M am Handy), je 20–23 Prüfungen: Vorbedingung Kurs live, Achse log. (Rest unter 0,3 px), Zahl
und Form der Kerzen (hohl genau an Plus-Tagen), Körper bzw. Linie auf den Kursen, erste Kerze eine halbe Tagesbreite hinter dem Rand,
MA-Enden, Linie „heute“, Kurslinie und Kasten, Band-Striche an Grenzen und Tagen, je Niveau Nummer, Linie und Beschriftung, Swings
an Tag und Preis, Zickzack auf den Extremen, RSI an der 30/70-Skala. Mutationen des Skripts 13 von 13 rot; vier waren zuerst
grün: Ohne frischen Kurs prüfte die Probe den Ersatzwert (eine falsche Kurslinie fiel nicht auf, bis die Vorbedingung dazukam);
relative Lagen allein sehen eine um einen Tag verschobene Zeitachse und Swings am Folgetag nicht (erst der Bezug zum Rand des Bilds
und die Lage je Swing); „Zickzack mit dem Schluss statt dem Extrem“ war gleichwertig, weil das Bein auf Schlusskursen läuft, und wurde
durch „ohne den letzten Punkt“ ersetzt.

## 8. Entscheidungen beim Nutzer

1. Nach dem endgültigen U142-Urteil (11.10.): ob der Prüfstand „Konten ≥ 3“ im Chartbild die gemessenen Quoten nennt (heute nur
   Wert, Perzentil und Prüfstand).
2. Stufe 2 (Niveau-Test, vorab festgelegt) als nächster Schritt — Vorschlag nach dem 25.10., wenn die Magnet-Auswertung vorliegt.
3. Ob das Chartbild auch als Debug-Bericht in den Berichtsplan soll (heute nur von Hand: „Chartbild: Lage aller Coins als Text“).

## 9. Ergebnis und Nachträge

### 9.1 Beim Bau geändert oder ergänzt (10./11.10., vor dem ersten Lauf auf echten Daten)

Das Chartbild ist eine Anzeige ohne Urteil; geändert wurden Darstellung und Definitionen, keine vorab festgelegte Auswertung.

1. **Runde Zahlen:** Die erste Regel s = ½ · 10^⌊log₁₀ Kurs⌋ springt an Zehnerpotenzen (bei 9.999 → 10.000 von 500 auf 5.000) und
   gab XMR um 310 einen Schritt von 50 (16 % des Kurses). Jetzt 1/2/5 Einheiten der zweiten Stelle: immer 4–10 % des Kurses.
2. **Swings:** die zwei nächsten je Seite statt des nächsten, und wie die Orders höchstens ±30 % (sonst erschien ein Tief vom Vorjahr
   bei −40 % als „nächstes Niveau“).
3. **Lesart:** Das nächste Stop-Cluster hat keine Mindestgröße (ein einzelnes kleines Konto reicht) und steht deshalb nur in der
   Tabelle, nicht im Satz „Nächste Niveaus“.
4. **PAXG:** Fear & Greed nicht gezeigt (Krypto-Index), Funding und Binance-Positionierung gibt es nicht -- als „bewusst nicht
   gezeigt“ getrennt von echten Lücken („Was fehlt“).
5. **Trefferquote** erst ab 90 Prognosetagen (HYPE hat kürzere Historie; mit wenigen Tagen ist die Quote zu verrauscht).
6. **Band-Kontrolle im Selbsttest:** Mittel über acht vorab gewählte synthetische Märkte (Saaten 100–107) gegen 80 % ± 2 SE des
   Mittels. Die Kalibrierung über 20 Märkte (1 Tag Mittel 80,3 %, sd 2,0 Pp.; 7 Tage 79,1 %, sd 3,4 Pp.) zeigte: Ein einzelner Markt
   streut um ± 2 sd -- eine Probe mit einem Markt wäre an der Grenze ein Münzwurf.
7. **Anzeige:** Kerzen neutral mit Form (hohl/gefüllt) statt Grün/Rot -- das Prüfskript für Farbpaletten trennt #3ba55d/#e04b4b für
   Rot-Grün-Fehlsichtige nicht (ΔE 3,0 deutan), die Form schon; MA 50 #3987e5, MA 200 #c98500 und Bein #d55181 bestehen alle Prüfungen
   (alle Paare, Fläche #01030a). Zeitraum „1 M“ ergänzt (auf dem Handy sonst nie Kerzen). Linien mehr als 15 % außerhalb der Kerzen
   bestimmen den y-Bereich nicht mehr (im 1-M-Bild drückte die 200-Tage-Linie die Kerzen in ein Drittel des Felds).
8. **Zickzack:** die Nutzlast enthält den einen bestätigten Punkt vor dem Chartfenster, damit die Linie im 2-J-Bild von links einläuft.
9. **Nebenbei gefunden (nicht Chartbild):** Die Seite war am Desktop 1.881 px breit statt 1.280 -- die Auswahl der Debug-Läufe wuchs
   mit der längsten Beschreibung (gemessen an 23.64 mit denselben Demo-Daten; seit welchem Paket, ist nicht nachgeprüft). Jetzt
   höchstens 760 px breit.
10. **Live-Teil je Teil für sich** (`hl_viz.chartbild_live`): Scheitert die Heatmap- oder die Order-Abfrage, bleiben Kurs und Rest;
   der Grund steht unter „Was fehlt“ („Heatmap nicht lesbar …“, „Orders der Großkonten nicht lesbar …“). In der ersten Fassung hätte
   ein Fehler der Heatmap-Abfrage auch den Kurs mitgenommen (gefunden mit einer neuen Probe kurz vor der Lieferung).

### 9.2 Erster Lauf auf dem Pi

(nach dem ersten Blick auf echten Daten)
