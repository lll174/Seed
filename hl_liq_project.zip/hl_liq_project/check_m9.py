#!/usr/bin/env python3
"""
check_m9.py -- Vorher-Nachher für das Ereignis-Signal (Übergabe M9).

Spielt die letzten 7 Tage Stunde für Stunde nach und zählt, wie oft das Wal-Flow-Signal
und das Leaderboard-Flow-Signal gefeuert hätten:

  alt:  |Z| >= 2,5 gegen die aktiven Stunden der zurückliegenden Woche (+ Breite)
  neu:  Rang in der VOLLSTÄNDIGEN Wochenreihe (inklusive Nullstunden) >= 98 %,
        absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto) und Breite

Die Live-Regel für Wale arbeitet mit 30-min-Fenstern (auf die Stunde hochgerechnet);
hier wird stundenweise gerechnet -- eine Näherung, die für den Vergleich der Feuerraten
ausreicht. Läuft nur lesend.

    python3 check_m9.py --db /media/seed/marketdatabase/hl_liq/hl_liq.db [--coin BTC] [--days 7]
"""
import argparse
import time

import hl_forecast
import hl_viz


def signed(event: str, side: str, delta) -> float:
    d = abs(delta or 0)
    if event in ("open", "add", "flip"):
        return d if side == "long" else -d
    return -d if side == "long" else d


def replay(con, coin: str, days: int, tabelle: str, dir_of, breite: int, floor: float, label: str) -> None:
    now = int(time.time()) // 3600 * 3600
    seit = now - (days + 7) * 86400
    if tabelle == "whale_positions":
        rows = con.execute("SELECT ts, addr, event, side, delta_usd FROM whale_positions WHERE coin=? AND ts>=? "
                           "AND event IN ('open','add','reduce','close','flip') ORDER BY ts", (coin, seit)).fetchall()
    else:
        rows = con.execute("SELECT ts, addr, event, side, delta_usd FROM lb_events WHERE coin=? AND ts>=? ORDER BY ts", (coin, seit)).fetchall()
    ev = [(r[0], r[1].lower(), r[2], r[3], r[4]) for r in rows if dir_of(r[1].lower())]
    if not ev:
        print(f"  {label}: keine Ereignisse direktionaler Konten in {tabelle} -- nichts zu vergleichen")
        return
    # Stundenreihe: Fluss und Konten je Seite
    hourly: dict = {}; konten: dict = {}
    for ts, addr, event, side, delta in ev:
        v = signed(event, side, delta)
        if not v:
            continue
        h = ts // 3600
        hourly[h] = hourly.get(h, 0.0) + v
        k = konten.setdefault(h, [set(), set()])
        (k[0] if v > 0 else k[1]).add(addr)
    alt = []; neu = []; beide = []
    for H in range(now // 3600 - days * 24, now // 3600):
        fluss = hourly.get(H, 0.0)
        if not fluss:
            continue
        aktive = [v for h, v in hourly.items() if H - 168 < h < H and v]      # Vergleichsreihe ohne die Stunde selbst
        k = konten.get(H, [set(), set()]); same = len(k[0]) if fluss > 0 else len(k[1])
        # alt: Z gegen aktive Stunden
        z = None
        if len(aktive) >= 24:
            m = sum(aktive) / len(aktive); sd = (sum((v - m) ** 2 for v in aktive) / max(1, len(aktive) - 1)) ** 0.5
            z = (fluss - m) / sd if sd > 0 else 0.0
        f_alt = z is not None and abs(z) >= 2.5 and same >= breite
        # neu: Rang in der vollständigen Reihe, Untergrenze, Breite
        hist_h = (H * 3600 - ev[0][0]) / 3600
        r = hl_forecast.rang_in_reihe(fluss, aktive) if hist_h >= 48 else None
        f_neu = r is not None and r >= 98 and abs(fluss) >= floor and same >= breite
        stamp = time.strftime("%d.%m. %H:00", time.localtime(H * 3600))
        if f_alt:
            alt.append((stamp, fluss, z, same))
        if f_neu:
            neu.append((stamp, fluss, r, same))
        if f_alt and f_neu:
            beide.append(stamp)
    n_h = days * 24
    print(f"  {label}: {len(ev):,} Ereignisse direktionaler Konten, {len(hourly):,} aktive Stunden in {days + 7} Tagen")
    print(f"    alt (Z >= 2,5):            {len(alt):3d} von {n_h} Stunden = {len(alt) / n_h:.1%}")
    print(f"    neu (Rang >= 98 %, Floor): {len(neu):3d} von {n_h} Stunden = {len(neu) / n_h:.1%}   (Nennrate des Rangs allein: ~2 %)")
    print(f"    in beiden Regeln:          {len(beide):3d}")
    for name, lst in (("alt", alt), ("neu", neu)):
        for stamp, fluss, kenn, same in lst[-6:]:
            print(f"      {name}  {stamp}  netto {fluss / 1e6:+7.2f} Mio  {'Z' if name == 'alt' else 'Rang'} {kenn:6.1f}  {same} Konten")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--days", type=int, default=7)
    a = p.parse_args()
    a.days = max(1, min(a.days, 60))                    # Re-Audit N12: --days 0 teilte durch null
    con = hl_viz.connect(a.db)
    bmap = hl_viz.behavior_map(con); pc = hl_viz.behavior_per_coin(con)

    def wal_dir(addr_l: str) -> bool:
        e = pc.get((addr_l, a.coin))
        if e:
            return e["group"] == "dir"
        cls = bmap.get(addr_l, "")
        return not (cls.startswith("Market-Maker") or cls.startswith("Hedge") or cls.startswith("gemischt"))

    lb_dir = hl_forecast.lb_directional_addrs(con, a.coin)
    print(f"M9 Vorher-Nachher für {a.coin}, letzte {a.days} Tage (Datenbank: {a.db})")
    replay(con, a.coin, a.days, "whale_positions", wal_dir, 4, 1e6, "Wal-Flow")
    replay(con, a.coin, a.days, "lb_events", lambda x: x in lb_dir, 3, 5e5, "Leaderboard-Flow")
    print("\nLesart: Feuert die neue Regel deutlich seltener als 5 % der Stunden und trifft die alten Fälle mit")
    print("großem Fluss weiterhin, ist die Umstellung wie beabsichtigt. Feuert sie öfter, die Untergrenze anheben.")


if __name__ == "__main__":
    main()
