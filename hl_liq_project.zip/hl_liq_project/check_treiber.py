#!/usr/bin/env python3
"""
check_treiber.py -- Funktionstest ALLER Treiber der Prognose mit Soll-Szenarien.

Für jeden Treiber werden kontrollierte Eingaben gebaut, bei denen das Ergebnis bekannt ist:
ein AUFWÄRTS-Szenario (Score muss positiv sein, Betrag wie die Formel es verlangt), ein
ABWÄRTS-Szenario (negativ), und wo es Bedingungen gibt, ein GESPERRT-Szenario (Treiber darf
nicht erscheinen: zu wenig Konten, zu wenig Umsatz, veraltete Daten, falsche Klasse). Dazu die
Regime-Flags. Jede Zeile: Treiber · Szenario · Soll · Ist · Urteil. Exit 1 bei einem FEHL.

Das prüft die Funktion (Vorzeichen, Skalierung, Sättigung, Sperren, Quellenwahl), nicht die
Vorhersagekraft -- die misst die Kalibrierung im Betrieb. Läuft ohne Netz, ohne Datenbank
(alles synthetisch, in-memory); Bestandteil des Selbsttests.

    python3 check_treiber.py            # Soll-Szenarien
    python3 check_treiber.py --db PFAD  # zusätzlich: Plausibilität auf der echten Datenbank (welche Treiber liegen an, warum fehlen andere)
"""
from __future__ import annotations

import argparse
import math
import sqlite3
import sys
import time

import hl_forecast as F
import hl_indikatoren as I

ERG: list = []
NOW = int(time.time())
PX = 60000.0


def urteil(treiber: str, szenario: str, soll: str, ist, ok: bool) -> None:
    ERG.append((treiber, szenario, soll, ist, ok))
    print(f"  {'ok  ' if ok else 'FEHL'} {treiber:<34} {szenario:<12} Soll {soll:<26} Ist {ist}")


# ---------------------------------------------------------------------------
# Grundwelt: Datenbank mit den Tabellen, die compute_forecast liest, und ein flacher Kurs
# ---------------------------------------------------------------------------

def welt() -> sqlite3.Connection:
    con = sqlite3.connect(":memory:")
    con.executescript("""
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER);
        CREATE INDEX ix_bars ON bars(coin, ts);
        CREATE TABLE lb_positions (ts INTEGER, rank INTEGER, addr TEXT, coin TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL, liq_px REAL, leverage REAL, upnl REAL, mark_px REAL);
        CREATE TABLE lb_fills (ts INTEGER, addr TEXT, coin TEXT, market TEXT, dir TEXT, side TEXT, px REAL, sz REAL, notional REAL, closed_pnl REAL, fee REAL, tid INTEGER, buy INTEGER);
        CREATE TABLE whale_positions (ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL, liq_px REAL, leverage REAL, upnl REAL, mark_px REAL, delta_usd REAL);
        CREATE TABLE lb_events (ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL, liq_px REAL, leverage REAL, upnl REAL, mark_px REAL, delta_usd REAL);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, symbol TEXT, side TEXT, price REAL, qty REAL, notional REAL);
        CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER, lev_wavg REAL, entry_wavg REAL, cross_share REAL);
    """)
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", [(NOW - i * 60, "BTC", PX, PX, PX, PX, 1.0, 1) for i in range(30 * 24 * 60, 0, -1)])
    con.commit()
    return con


def basis_chart(**extra) -> dict:
    ch = {"candles": [{"t": NOW - 3600 * i, "o": PX, "h": PX, "l": PX, "c": PX, "v": 1.0} for i in range(200, 0, -1)],
          "price": PX, "levels": [], "stops": {"clusters": []}, "mas": {}, "vol_1h": 1e7, "vol_split": {"hl": 1e7}}
    ch.update(extra)
    return ch


def prognose(con, chart=None, **kw) -> dict:
    """compute_forecast mit Vorgaben; liefert {Treibername: Score} und die Liste der fehlenden."""
    args = {"whales": None, "smart": None, "lb": None, "lb_act": None, "etf": None, "bnc": None, "cdc": None,
            "bybit": None, "okx": None, "learned": None, "coinbase": None}
    args.update(kw)
    # Wie der Lernzyklus des Dashboards: das Kapitulationssignal wird außerhalb berechnet und über learned übergeben
    learned = dict(args["learned"] or {})
    if "capitulation" not in learned:
        try:
            learned["capitulation"] = F.capitulation_signal(con, "BTC")
        except Exception:
            learned["capitulation"] = None
    args["learned"] = learned
    fc = F.compute_forecast(con, "BTC", chart or basis_chart(), args["whales"], args["smart"], args["lb"], args["lb_act"],
                            args["etf"], args["bnc"], args["cdc"], args["bybit"], args["okx"], args["learned"], args["coinbase"])
    return {d["name"]: d["score"] for d in fc["drivers"]}, fc.get("missing") or [], fc


def pruefe(name: str, szenario: str, scores: dict, soll_lo: float, soll_hi: float) -> None:
    ist = scores.get(name)
    ok = ist is not None and soll_lo - 1e-6 <= ist <= soll_hi + 1e-6
    urteil(name, szenario, f"[{soll_lo:+.2f}, {soll_hi:+.2f}]", "fehlt" if ist is None else f"{ist:+.3f}", ok)


def pruefe_fehlt(name: str, szenario: str, scores: dict) -> None:
    urteil(name, szenario, "nicht vorhanden", "fehlt" if name not in scores else f"{scores[name]:+.3f}", name not in scores)


# ---------------------------------------------------------------------------
# 1. Technische Treiber (aus dem Chart)
# ---------------------------------------------------------------------------

def test_technik(con):
    print("\n1. Regime und Drift")
    s, _, _ = prognose(con, basis_chart(mas={"ma200d": PX / 1.05}))          # Kurs 5 % über MA -> +0,3
    pruefe("MA 200 Tage", "aufwärts", s, 0.28, 0.32)
    s, _, _ = prognose(con, basis_chart(mas={"ma200d": PX / 0.95}))          # 5 % darunter -> -0,3
    pruefe("MA 200 Tage", "abwärts", s, -0.32, -0.28)
    s, _, _ = prognose(con, basis_chart(mas={"ma200d": PX / 1.50}))          # Sättigung bei 10 %: +0,6
    pruefe("MA 200 Tage", "Sättigung", s, 0.6, 0.6)
    s, _, _ = prognose(con, basis_chart(mas={"ma50w": PX / 1.05}))
    pruefe("MA 50 Wochen", "aufwärts", s, 0.23, 0.27)
    s, _, _ = prognose(con, basis_chart(trend_60m=0.02))
    pruefe("60-min-Trend", "aufwärts", s, 0.5, 0.5)
    s, _, _ = prognose(con, basis_chart(trend_60m=-0.005))
    pruefe("60-min-Trend", "abwärts", s, -0.25, -0.25)
    s, _, _ = prognose(con, basis_chart(rsi14=80))
    pruefe("RSI 14 (1 h)", "überkauft", s, -0.5, -0.5)
    s, _, _ = prognose(con, basis_chart(rsi14=20))
    pruefe("RSI 14 (1 h)", "überverkauft", s, 0.5, 0.5)
    # 7-Tage-Drift: Kerzen mit Aufwärtsdrift und Rauschen
    import random
    rng = random.Random(1); p = PX; C = []
    for i in range(200, 0, -1):
        p *= math.exp(0.0015 + rng.gauss(0, 0.004)); C.append({"t": NOW - 3600 * i, "o": p, "h": p, "l": p, "c": p, "v": 1.0})
    s, _, _ = prognose(con, basis_chart(candles=C))
    pruefe("7-Tage-Drift", "aufwärts", s, 0.05, 0.4)
    p = PX; C = []
    for i in range(200, 0, -1):
        p *= math.exp(-0.0015 + rng.gauss(0, 0.004)); C.append({"t": NOW - 3600 * i, "o": p, "h": p, "l": p, "c": p, "v": 1.0})
    s, _, _ = prognose(con, basis_chart(candles=C))
    pruefe("7-Tage-Drift", "abwärts", s, -0.4, -0.05)


# ---------------------------------------------------------------------------
# 2. Positionierung und Fluss der Konten
# ---------------------------------------------------------------------------

def test_konten(con):
    print("\n2. Positionierung und Fluss der Konten")
    W = {"directional": {"n_directional": 5, "n_long": 4, "n_short": 1, "usd_long": 80e6, "usd_short": 20e6}}
    s, _, _ = prognose(con, whales=W); pruefe("Direktionale Wale", "aufwärts", s, 0.6, 0.6)
    W = {"directional": {"n_directional": 5, "n_long": 1, "n_short": 4, "usd_long": 20e6, "usd_short": 80e6}}
    s, _, _ = prognose(con, whales=W); pruefe("Direktionale Wale", "abwärts", s, -0.6, -0.6)
    s, _, _ = prognose(con, whales={"directional": {"n_directional": 0}}); pruefe_fehlt("Direktionale Wale", "keine Wale", s)

    fl = lambda buy, sell, nb, ns, z, ev=False: {"flow": {"groups": {"dir": {"w30": {"buy_usd": buy, "sell_usd": sell, "net_usd": buy - sell, "n_buy": nb, "n_sell": ns}, "z30": z, "event_signal": ev}}}}
    s, _, _ = prognose(con, whales=fl(2e6, 0.5e6, 3, 1, 3.0)); pruefe("Wal-Flow 30 min", "aufwärts", s, 0.59, 0.61)          # 0,6 · clip(3/2,5)=1
    s, _, _ = prognose(con, whales=fl(2e6, 0.5e6, 3, 1, 3.0, True)); pruefe("Wal-Flow 30 min", "Ereignis", s, 0.89, 0.91)   # ×1,5
    s, _, _ = prognose(con, whales=fl(0.5e6, 2e6, 1, 3, 1.0)); pruefe("Wal-Flow 30 min", "abwärts", s, -0.25, -0.23)        # -0,6 · 0,4
    s, _, _ = prognose(con, whales=fl(1e5, 2e4, 1, 0, 3.0)); pruefe_fehlt("Wal-Flow 30 min", "zu klein", s)                  # Brutto < 150k / 1 Konto

    LB = {"flow": {"w60": {"buy_usd": 4e6, "sell_usd": 1e6, "net_usd": 3e6, "n_buy": 4, "n_sell": 1}, "z60": 2.5}}
    s, _, _ = prognose(con, lb=LB); pruefe("Leaderboard-Flow 60 min", "aufwärts", s, 0.59, 0.61)
    LB = {"flow": {"w60": {"buy_usd": 1e6, "sell_usd": 4e6, "net_usd": -3e6, "n_buy": 1, "n_sell": 4}, "z60": 2.5, "event_signal": True}}
    s, _, _ = prognose(con, lb=LB); pruefe("Leaderboard-Flow 60 min", "abwärts+Ereignis", s, -0.91, -0.89)

    LB = {"summary": {"usd_long": 100e6, "usd_short": 50e6, "net_usd": 50e6}, "trend": [{"ts": NOW - 90000, "net_usd": 0.0}, {"ts": NOW, "net_usd": 50e6}]}
    s, _, _ = prognose(con, lb=LB); pruefe("Top-20-Trend 24 h", "aufwärts", s, 0.38, 0.42)                                   # Δ=0,333 -> 0,667·0,6
    LB = {"summary": {"usd_long": 50e6, "usd_short": 100e6, "net_usd": -50e6}, "trend": [{"ts": NOW - 90000, "net_usd": 50e6}, {"ts": NOW, "net_usd": -50e6}]}
    s, _, _ = prognose(con, lb=LB); pruefe("Top-20-Trend 24 h", "abwärts", s, -0.6, -0.6)                                     # Δ=-0,667 -> gesättigt

    # Smart Money / Käufe-Verkäufe: Leaderboard-Schnappschuss mit direktionalen Konten (eine Seite je Konto)
    con.execute("DELETE FROM lb_positions"); con.execute("DELETE FROM lb_fills")
    acc = [f"0x{i:040x}" for i in range(6)]
    rows = [(NOW, i + 1, acc[i], "BTC", "long", 1.0, 10e6, PX, PX * 0.8, 5, 0, PX) for i in range(4)] + [(NOW, 5, acc[4], "BTC", "short", 1.0, 5e6, PX, PX * 1.2, 5, 0, PX)]
    rows += [(NOW, 6, acc[5], "ETH", "long", 1.0, 5e6, 3000, 2400, 5, 0, 3000), (NOW, 6, acc[5], "SOL", "long", 1.0, 5e6, 100, 80, 5, 0, 100), (NOW, 6, acc[5], "XRP", "long", 1.0, 5e6, 1, 0.8, 5, 0, 1)]   # Hedge-Konto: 3 Coins, eine Seite
    con.executemany("INSERT INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows); con.commit()
    s, _, _ = prognose(con, smart={"x": 1}); pruefe("Smart Money (direktional)", "aufwärts", s, 0.77, 0.79)                   # (40-5)/45
    con.execute("UPDATE lb_positions SET side='short' WHERE coin='BTC'"); con.commit()
    s, _, _ = prognose(con, smart={"x": 1}); pruefe("Smart Money (direktional)", "abwärts", s, -1.0, -1.0)
    con.execute("DELETE FROM lb_positions WHERE rank>2"); con.commit()
    s, _, _ = prognose(con, smart={"x": 1}); pruefe_fehlt("Smart Money (direktional)", "< 3 Konten", s)
    con.execute("DELETE FROM lb_positions"); con.executemany("INSERT INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows); con.commit()
    fills = [(NOW - 3600 * i, acc[i % 4], "BTC", "perp", "Open Long", "B", PX, 0.05, 3e5, 0, 1, 1000 + i, 1) for i in range(6)] + \
            [(NOW - 3600 * i, acc[i % 4], "BTC", "perp", "Close Long", "A", PX, 0.01, 6e4, 0, 1, 2000 + i, 0) for i in range(3)]
    fills += [(NOW - 100, acc[5], "BTC", "perp", "Open Short", "A", PX, 1.0, 9e6, 0, 1, 3000, 0)]                         # Hedge-Konto: darf nicht zählen
    con.executemany("INSERT INTO lb_fills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", fills); con.commit()
    s, _, _ = prognose(con); pruefe("Käufe/Verkäufe 24 h (direktional)", "aufwärts, Hedge ignoriert", s, 0.81, 0.83)         # (1,8-0,18)/1,98
    con.execute("UPDATE lb_fills SET buy=0 WHERE buy=1"); con.execute("UPDATE lb_fills SET buy=1 WHERE tid>=2000 AND tid<3000"); con.commit()
    s, _, _ = prognose(con); pruefe("Käufe/Verkäufe 24 h (direktional)", "abwärts", s, -0.83, -0.81)
    con.execute("DELETE FROM lb_fills"); con.commit()

    # Smart-Flow / Gegen-Flow / Elite über Konto-Score
    con.execute("DELETE FROM whale_positions")
    gut = [f"0xa{i:039x}" for i in range(3)]; schlecht = [f"0xb{i:039x}" for i in range(3)]
    ev = [(NOW - 1800 - i * 60, a, "BTC", "add", "long", 1.0, 5e6, PX, PX * 0.8, 5, 0, PX, 5e6) for i, a in enumerate(gut)] + \
         [(NOW - 1800 - i * 60, a, "BTC", "add", "short", 1.0, 5e6, PX, PX * 1.2, 5, 0, PX, 5e6) for i, a in enumerate(schlecht)]
    con.executemany("INSERT INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ev); con.commit()
    SC = {a: {"score": 0.8, "comps": {}, "klasse": 1.0, "n": 30, "alpha_4h": 0.002} for a in gut}
    SC.update({a: {"score": 0.2, "comps": {}, "klasse": 1.0, "n": 30, "alpha_4h": -0.002} for a in schlecht})
    L = {"scores": SC, "elite": gut}
    con.execute("DELETE FROM lb_positions"); con.executemany("INSERT INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                                                              [(NOW, i + 1, a, "BTC", "long", 1.0, 10e6, PX, PX * 0.8, 5, 0, PX) for i, a in enumerate(gut)]); con.commit()
    s, m, _ = prognose(con, learned=L)
    pruefe("Smart-Flow 4 h", "gut kauft, schwach verkauft", s, 0.59, 0.61)          # (3·0,8 − 3·0,2)/(3·0,8 + 3·0,2): der Score ist das Gewicht
    pruefe("Gegen-Flow", "Verlierer verkaufen -> +", s, 0.99, 1.0)                     # Verlierer short -> invertiert +1
    pruefe("Elite-Positionierung", "Elite long, gleich groß", s, 0.99, 1.0)
    con.execute("UPDATE lb_positions SET pos_value=80e6 WHERE addr=?", (gut[0],)); con.commit()   # ein Konto dominiert: 80 %
    s, _, _ = prognose(con, learned=L); pruefe("Elite-Positionierung", "Dominanz 80 %", s, 0.49, 0.51)   # ×clip((1-0,8)/0,5)=0,5
    con.execute("UPDATE lb_positions SET pos_value=10e6"); con.executemany("INSERT INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        [(NOW, 9, gut[0], "ETH", "long", 1, 1e6, 3000, 2400, 3, 0, 3000), (NOW, 9, gut[0], "SOL", "long", 1, 1e6, 100, 80, 3, 0, 100)]); con.commit()   # gut[0] wird Hedge (3 Coins, eine Seite, Hebel ≤ 10)
    s, _, _ = prognose(con, learned=L); pruefe_fehlt("Elite-Positionierung", "Hedge raus, 2 bleiben", s)          # Regel: mindestens 3 zählbare
    vierte = "0xa" + "9" * 39
    con.execute("INSERT INTO lb_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (NOW, 7, vierte, "BTC", "long", 1.0, 10e6, PX, PX * 0.8, 5, 0, PX)); con.commit()
    L2 = {"scores": dict(SC, **{vierte: {"score": 0.7, "comps": {}, "klasse": 1.0, "n": 30, "alpha_4h": 0.001}}), "elite": gut + [vierte]}
    s, _, _ = prognose(con, learned=L2); pruefe("Elite-Positionierung", "Hedge raus, 3 bleiben", s, 0.99, 1.0)
    con.execute("DELETE FROM lb_positions WHERE addr=?", (gut[0],)); con.execute("DELETE FROM whale_positions"); con.commit()


# ---------------------------------------------------------------------------
# 3. Mikrostruktur, Coinbase, ETF, Analog
# ---------------------------------------------------------------------------

def test_markt(con):
    print("\n3. Mikrostruktur, Coinbase, ETF, Analog-Suche")
    s, _, _ = prognose(con, bnc={"metrics": {"taker_ls": 2.0}}, cdc={"taker_ls": 2.0, "taker_span_s": 120}); pruefe("Taker-Flow", "aufwärts 2:1", s, 0.7, 0.7)
    s, _, _ = prognose(con, bnc={"metrics": {"taker_ls": 0.5}}); pruefe("Taker-Flow", "abwärts 1:2", s, -0.7, -0.7)
    s, _, _ = prognose(con, bnc={"metrics": {"taker_ls": 1.2}}); pruefe("Taker-Flow", "mild 1,2", s, 0.3, 0.33)               # ln1,2/ln1,5=0,45·0,7
    s, _, _ = prognose(con, cdc={"taker_ls": 3.0, "taker_span_s": 20}); pruefe_fehlt("Taker-Flow", "Spanne < 60 s", s)
    s, _, _ = prognose(con, basis_chart(funding={"ts": NOW, "funding": 0.0002, "oi": 1})); pruefe("Funding", "Longs zahlen -> −", s, -0.4, -0.4)
    s, _, _ = prognose(con, basis_chart(funding={"ts": NOW, "funding": -0.0001, "oi": 1})); pruefe("Funding", "Shorts zahlen -> +", s, 0.2, 0.2)
    s, _, _ = prognose(con, basis_chart(book={"imb_50": 0.25})); pruefe("Orderbuch", "Gebot überwiegt", s, 0.2, 0.2)
    s, _, _ = prognose(con, basis_chart(book={"imb_50": -1.0})); pruefe("Orderbuch", "Angebot, gesättigt", s, -0.4, -0.4)
    # Kapitulation: 3 Tage Grundrauschen, Schub vor 30-60 min
    con.execute("DELETE FROM bnc_liquidations")
    basis = [(NOW - 3 * 86400 + i * 1800 + 10, "BTC", "BTCUSDT", "long", PX, 0.01, 2e5) for i in range(140)] + \
            [(NOW - 3 * 86400 + i * 1800 + 20, "BTC", "BTCUSDT", "short", PX, 0.01, 2e5) for i in range(140)]
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", basis); con.commit()
    s, _, _ = prognose(con); pruefe_fehlt("Kapitulation", "kein Schub", s)
    jb = NOW // 1800 * 1800
    con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", [(jb - 1800 + 5 * k, "BTC", "BTCUSDT", "long", PX, 0.1, 5e5) for k in range(12)]); con.commit()   # 6 Mio Long-Liquidationen
    s, _, _ = prognose(con); pruefe("Kapitulation", "Long-Schub -> +", s, 0.8, 0.8)
    con.execute("DELETE FROM bnc_liquidations WHERE notional=5e5"); con.executemany("INSERT INTO bnc_liquidations VALUES (?,?,?,?,?,?,?)", [(jb - 1800 + 5 * k, "BTC", "BTCUSDT", "short", PX, 0.1, 5e5) for k in range(12)]); con.commit()
    s, _, _ = prognose(con); pruefe("Kapitulation", "Short-Schub -> −", s, -0.8, -0.8)
    con.execute("DELETE FROM bnc_liquidations"); con.commit()
    # Coinbase
    CB = {"aktiv": True, "premium_z": 2.5, "premium_bps": 5, "premium_mittel": 1, "premium_n": 1000,
          "flow60": {"buy_usd": 1e6, "sell_usd": 2e5, "net_usd": 8e5}, "flow_z": 2.5, "book": {"imbalance": 0.3, "bid25": 2e5, "ask25": 1e5}}
    s, _, _ = prognose(con, coinbase=CB)
    pruefe("Coinbase-Prämie", "Z +2,5", s, 1.0, 1.0); pruefe("Spot-Taker-Flow", "Käufe", s, 0.66, 0.68); pruefe("Spot-Orderbuch", "Gebot", s, 0.6, 0.6)
    CB2 = dict(CB, premium_z=-1.25, flow60={"buy_usd": 2e5, "sell_usd": 1e6, "net_usd": -8e5}, flow_z=-1.0, book={"imbalance": -0.6, "bid25": 1e5, "ask25": 4e5})
    s, _, _ = prognose(con, coinbase=CB2)
    pruefe("Coinbase-Prämie", "Z −1,25", s, -0.5, -0.5); pruefe("Spot-Taker-Flow", "Verkäufe, Z 1", s, -0.27, -0.26); pruefe("Spot-Orderbuch", "Angebot", s, -1.0, -1.0)
    s, _, _ = prognose(con, coinbase={"aktiv": False}); pruefe_fehlt("Coinbase-Prämie", "Dienst aus", s)
    # ETF
    s, _, _ = prognose(con, etf={"last": 200, "sum5": 800, "last_date": "2026-09-14"}); pruefe("ETF-Flows", "Zufluss", s, 0.48, 0.48)
    s, _, _ = prognose(con, etf={"last": -200, "sum5": -800, "last_date": "2026-09-14"}); pruefe("ETF-Flows", "Abfluss", s, -0.48, -0.48)
    s, _, _ = prognose(con, etf={"last": -50, "sum5": 800, "last_date": "2026-09-14"}); pruefe("ETF-Flows", "Vorzeichen uneins -> 0", s, 0.0, 0.0)
    # Analog
    an = lambda p: {"ret": {h: {"p_up": p, "p_up_base": 0.5, "med": 0.01, "q20": -0.01, "q80": 0.02} for h in (1, 4, 12, 24, 48, 72, 168)}, "n": 50, "span_days": 900}
    fc = F.compute_forecast(con, "BTC", basis_chart(), None, None, None, None, None, None, None, None, None, None, None)
    # compute_forecast holt die Analog-Suche aus learned -> über learned übergeben
    s, _, _ = prognose(con, learned={"analog": an(0.75)}); pruefe("Analog-Suche", "75 % aufwärts", s, 0.8, 0.8)
    s, _, _ = prognose(con, learned={"analog": an(0.35)}); pruefe("Analog-Suche", "35 % aufwärts", s, -0.48, -0.48)


# ---------------------------------------------------------------------------
# 4. Indikatoren (hl_indikatoren) und Regime
# ---------------------------------------------------------------------------

def test_indikatoren():
    print("\n4. Indikatoren aus Tabellen und Regime")
    con = sqlite3.connect(":memory:")
    con.executescript("""
        CREATE TABLE bnc_metrics (ts INTEGER, coin TEXT, metric TEXT, value REAL, PRIMARY KEY (ts, coin, metric));
        CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, funding REAL, oi REAL);
        CREATE TABLE lb_trend (ts INTEGER, coin TEXT, top_n INTEGER, n_long INTEGER, n_short INTEGER, usd_long REAL, usd_short REAL, net_usd REAL, n_accounts INTEGER, mark_px REAL);
        CREATE TABLE etf_flows (day TEXT, coin TEXT, flow_musd REAL, fetched INTEGER);
        CREATE TABLE ext_metrics (ts INTEGER, exchange TEXT, coin TEXT, metric TEXT, value REAL);
        CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
        CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, order_id TEXT);
        CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER);
        CREATE TABLE bars10 (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, vol_buy REAL, vol_sell REAL);
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER);
    """)
    h0 = NOW // 3600 * 3600
    stunden = [h0 - k * 3600 for k in range(40 * 24, -1, -1)]
    # OI: 40 Tage flach, dann Anstieg auf Rekord -> überhitzt, Score < 0
    con.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t, "BTC", "open_interest", 1e5 + (k % 7) * 100 + (5e4 if k > len(stunden) - 30 else 0)) for k, t in enumerate(stunden)])
    con.commit()
    r = I.oi_perzentil(con, "BTC"); urteil("OI-Überhitzung", "Rekord-OI (30 h Plateau)", "ü ≥ 0,7, Score ≤ −0,4", f"ü={r['ueberhitzt']:.2f}, {r['score']:+.2f}" if r else "None", bool(r) and r["ueberhitzt"] >= 0.7 and r["score"] <= -0.4)   # Midrank: die 30 hohen Stunden teilen sich den Rang
    con.execute("DELETE FROM bnc_metrics"); con.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t, "BTC", "open_interest", 1e5 + (k % 7) * 100) for k, t in enumerate(stunden)]); con.commit()
    r = I.oi_perzentil(con, "BTC"); urteil("OI-Überhitzung", "OI mittig", "ü=0", f"ü={r['ueberhitzt']:.2f}" if r else "None", bool(r) and r["ueberhitzt"] == 0)
    con.execute("DELETE FROM bnc_metrics"); con.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t, "BTC", "open_interest", 1e5) for t in stunden]); con.commit()
    r = I.oi_perzentil(con, "BTC"); urteil("OI-Überhitzung", "konstant (Plateau)", "None", str(r), r is None)
    # Crowding: 40 Tage um 0, zuletzt extrem short-lastig -> Kontra +; extrem long-lastig -> −0,5
    def crowd_reihe(ende):
        return [(t, "BTC", 20, 10, 10, 5e8 * (1 + 0.1 * math.sin(k)), 5e8 * (1 - 0.1 * math.sin(k)), 0, 20, PX) for k, t in enumerate(stunden[:-1])] + [(stunden[-1], "BTC", 20, 10, 10, 5e8 * (1 + ende), 5e8 * (1 - ende), 0, 20, PX)]
    con.executemany("INSERT INTO lb_trend VALUES (?,?,?,?,?,?,?,?,?,?)", crowd_reihe(-0.5)); con.commit()
    r = I.crowding(con, "BTC"); urteil("Crowding-Extrem", "extrem short", "kontra = +1", f"{r['kontra']:+.2f}" if r else "None", bool(r) and r["kontra"] >= 0.99)
    con.execute("DELETE FROM lb_trend"); con.executemany("INSERT INTO lb_trend VALUES (?,?,?,?,?,?,?,?,?,?)", crowd_reihe(0.5)); con.commit()
    r = I.crowding(con, "BTC"); urteil("Crowding-Extrem", "extrem long", "kontra = −0,5", f"{r['kontra']:+.2f}" if r else "None", bool(r) and abs(r["kontra"] + 0.5) < 1e-6)
    urteil("Crowding-Trend 7 T", "Umschichtung long", "trend > 0", f"{r['trend']:+.2f}" if r and r.get("trend") is not None else "None", bool(r) and (r.get("trend") or 0) > 0)
    # ETF-Momentum
    tage = [time.strftime("%Y-%m-%d", time.gmtime(NOW - d * 86400)) for d in range(40)]
    con.executemany("INSERT INTO etf_flows VALUES (?,?,?,?)", [(tage[d], "BTC", (300 if d < 3 else 0) + 50 * math.sin(d), 0) for d in range(40)]); con.commit()
    r = I.etf_momentum(con, "BTC"); urteil("ETF-Momentum", "3 T beschleunigt", "> 0", f"{r['score']:+.2f}" if r else "None", bool(r) and r["score"] > 0.3)
    con.execute("DELETE FROM etf_flows"); con.executemany("INSERT INTO etf_flows VALUES (?,?,?,?)", [(tage[d], "BTC", (-300 if d < 3 else 0) + 50 * math.sin(d), 0) for d in range(40)]); con.commit()
    r = I.etf_momentum(con, "BTC"); urteil("ETF-Momentum", "3 T Abfluss", "< 0", f"{r['score']:+.2f}" if r else "None", bool(r) and r["score"] < -0.3)
    con.execute("DELETE FROM etf_flows"); con.executemany("INSERT INTO etf_flows VALUES (?,?,?,?)", [(tage[d + 6], "BTC", 100, 0) for d in range(30)]); con.commit()
    r = I.etf_momentum(con, "BTC"); urteil("ETF-Momentum", "jüngster Tag 6 T alt", "None", str(r), r is None)
    # Vol-Regime: 20 ruhige Tage, dann 24 h Spike nach oben -> Reversion < 0, band_mult > 1
    import random
    rng = random.Random(4); p = PX; rows = []
    for t in range(NOW - 21 * 86400, NOW + 1, 60):
        sig = 0.0004 if t < NOW - 24 * 3600 else 0.0025
        drift = 0.0 if t < NOW - 24 * 3600 else 0.00003
        o = p; p *= math.exp(drift + rng.gauss(0, sig)); rows.append((t, "BTC", o, max(o, p) * (1 + sig / 2), min(o, p) * (1 - sig / 2), p, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); con.commit()
    r = I.vol_regime(con, "BTC"); urteil("Vol-Spike-Reversion", "Spike nach Anstieg", "Score < 0, Band > 1", f"{r['score']:+.2f}, Band {r['band_mult']:.2f}, ratio {r['ratio']:.2f}" if r else "None", bool(r) and r["score"] < 0 and r["band_mult"] > 1.0)
    # Funding-Spread: HL zuletzt teuer -> Kontra −
    con.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?)", [(t, "BTC", PX, (0.00001 if k < len(stunden) - 3 else 0.00010), 1e5) for k, t in enumerate(stunden)])
    con.executemany("INSERT INTO ext_metrics VALUES (?,?,?,?,?)", [(t, "bybit", "BTC", "funding_8h", 0.0001 + 0.00001 * math.sin(k)) for k, t in enumerate(stunden)]); con.commit()
    r = I.funding_spread(con, "BTC"); urteil("Funding-Spread", "HL teuer", "Score < −0,5", f"{r['score']:+.2f} (pct {r['pct']:.2f})" if r else "None", bool(r) and r["score"] < -0.5)
    con.execute("UPDATE ctx_bars SET funding=-0.0002 WHERE ts>=?", (stunden[-3],)); con.commit()
    r = I.funding_spread(con, "BTC"); urteil("Funding-Spread", "HL billig", "Score > +0,5", f"{r['score']:+.2f}" if r else "None", bool(r) and r["score"] > 0.5)
    # Liquidationsdruck: Grundrauschen, dann Long-Welle in den letzten 2 h -> +, intens 1
    con.executemany("INSERT INTO ext_liquidations VALUES (?,?,?,?,?,?,?,?)", [(t + j * 600, "bybit", "BTC", ("long" if j % 2 else "short"), PX, 0.01, 2e5, f"u{k}-{j}") for k, t in enumerate(stunden[:-2]) for j in range(4)])
    con.executemany("INSERT INTO ext_liquidations VALUES (?,?,?,?,?,?,?,?)", [(NOW - 100 - j * 30, "bybit", "BTC", "long", PX, 1.0, 2e6, f"w{j}") for j in range(30)]); con.commit()
    r = I.liquidationsdruck(con, "BTC"); urteil("Liquidationsdruck (3 Börsen)", "Long-Welle", "Score > +0,8", f"{r['score']:+.2f} (pct {r['pct']:.2f})" if r else "None", bool(r) and r["score"] > 0.8)
    con.execute("UPDATE ext_liquidations SET side='short' WHERE uid LIKE 'w%'"); con.commit()
    r = I.liquidationsdruck(con, "BTC"); urteil("Liquidationsdruck (3 Börsen)", "Short-Welle", "Score < −0,8", f"{r['score']:+.2f}" if r else "None", bool(r) and r["score"] < -0.8)
    # Varianz-Kompression: 30 Tage lebhafte Salden, letzte Stunde fast konstant -> Kompression 1
    I._VAR_CACHE.clear()
    con.executemany("INSERT INTO bars10 VALUES (?,?,?,?,?,?,?,?)", [(t, "BTC", 1, 1, 1, PX, (10 + 5 * math.sin(t) if t < NOW // 3600 * 3600 - 3600 else 10.0), 10.0) for t in range(NOW - 31 * 86400, NOW + 1, 10)]); con.commit()
    r = I.varianz_kompression(con, "BTC"); urteil("Varianz-Kompression", "ruhige Stunde", "kompr = 1", f"{r['kompression']:.2f} (pct {r['pct']:.2f})" if r else "None", bool(r) and r["kompression"] >= 0.99)
    reg = I.regime({"pct": 0.99, "ueberhitzt": 0.9}, {"ratio": 1.4, "band_mult": 1.4}, {"pct": 0.95, "intens": 0.5}, {"pct": 0.05, "kompression": 0.5})
    urteil("Regime", "alle Flags", "Band = 1,4·1,225·1,125·1,1 ≈ 2,12", f"{reg['band_mult']:.3f}", abs(reg["band_mult"] - 1.4 * 1.225 * 1.125 * 1.1) < 0.01)
    reg = I.regime(None, None, None, None); urteil("Regime", "keine Daten", "Band = 1,0", f"{reg['band_mult']:.3f}", abs(reg["band_mult"] - 1.0) < 1e-9)


# ---------------------------------------------------------------------------
# 5. Plausibilität auf der echten Datenbank
# ---------------------------------------------------------------------------

def live(db: str) -> None:
    import hl_viz
    print(f"\n5. Plausibilität auf {db}")
    for coin in ("BTC", "ETH"):
        fc = hl_viz.forecast_compute(db, coin)
        if not fc or fc.get("error"):
            print(f"  {coin}: keine Prognose ({(fc or {}).get('error')})"); continue
        print(f"  {coin}: {len(fc['drivers'])} Treiber · Bias {fc['bias']:+.2f} · P(auf) {fc.get('p_up', 0):.2f} · Regime {(fc.get('regime') or {}).get('text') or '—'}")
        for d in sorted(fc["drivers"], key=lambda x: -abs(x["score"] * x["weight"])):
            warn = " <- Betrag außerhalb [-1,1]" if abs(d["score"]) > 1.0001 else ""
            print(f"     {d['name']:<34} {d['score']:+.2f} × {d['weight']:.2f}{'*' if d.get('learned') else ' '}  {d['text'][:80]}{warn}")
        if fc.get("missing"):
            print(f"     fehlend: {', '.join(fc['missing'])}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", help="zusätzlich Plausibilität auf der echten Datenbank")
    a = p.parse_args()
    print(f"Treiber-Funktionstest · {time.strftime('%d.%m.%Y %H:%M')}")
    con = welt()
    test_technik(con); test_konten(con); test_markt(con); test_indikatoren()
    if a.db:
        try:
            live(a.db)
        except Exception as e:
            print(f"  Plausibilität: {type(e).__name__}: {e}")
    fehl = [e for e in ERG if not e[4]]
    namen = {e[0] for e in ERG}
    print(f"\n{len(ERG)} Prüfungen für {len(namen)} Treiber/Flags · {len(ERG) - len(fehl)} ok · {len(fehl)} FEHL")
    if fehl:
        for t, sz, so, ist, _ in fehl:
            print(f"  FEHL {t} · {sz}: Soll {so}, Ist {ist}")
        sys.exit(1)
    print("Alles in Ordnung.")


if __name__ == "__main__":
    main()
