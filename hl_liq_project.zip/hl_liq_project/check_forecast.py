#!/usr/bin/env python3
"""
Diagnose der AI-Prognose: rechnet die Prognose für einen Coin mit vollständigem Traceback
und zeigt den Lernstand (Gewichte, Analog, Magneten, Zeitprofil) und die Datentypen der
Eingaben -- damit ein Fehler wie "'<=' not supported" sofort mit Zeile und Werten sichtbar ist.

  python3 check_forecast.py --db /pfad/hl_liq.db --coin BTC
"""
import argparse, json, re, sqlite3, sys, time, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def db_path() -> str:
    try:
        m = re.search(r"--db\s+(\S+)", Path("/etc/systemd/system/hl-recorder.service").read_text())
        if m:
            return m.group(1)
    except OSError:
        pass
    return str(ROOT / "hl_liq.db")


def types_of(d, depth=0, max_items=12):
    if isinstance(d, dict):
        return "{" + ", ".join(f"{k}: {types_of(v, depth + 1)}" for k, v in list(d.items())[:max_items]) + ("…" if len(d) > max_items else "") + "}"
    if isinstance(d, list):
        return f"list[{len(d)}]" + (f" of {types_of(d[0], depth + 1)}" if d and depth < 2 else "")
    return type(d).__name__ + (f"={d!r}" if isinstance(d, (str, bool)) or d is None else "")


def main():
    p = argparse.ArgumentParser(); p.add_argument("--db", default=db_path()); p.add_argument("--coin", default="BTC")
    a = p.parse_args()
    import hl_viz, hl_forecast
    hl_viz.Handler.db = a.db
    print(f"Datenbank {a.db} · Coin {a.coin}\n")
    con = hl_viz.connect(a.db)
    try:
        print("1) Eingaben")
        chart = hl_viz.load_chart(con, a.coin, minutes=7 * 1440, agg=60)
        chart = hl_viz.attach_binance(con, chart, a.coin, 60, 7 * 1440, "fusion")
        chart = hl_viz.attach_sources(chart, a.coin, "fusion", con)
        for k in ("price", "funding", "mas", "rsi14", "trend_60m", "vol_1h", "book", "etf"):
            print(f"   chart.{k:<10} {types_of(chart.get(k))}")
        print(f"   candles {len(chart.get('candles') or [])} · levels {len(chart.get('levels') or [])} · stops {len((chart.get('stops') or {}).get('clusters') or [])}")
        lv = chart.get("levels") or []; sc_ = (chart.get("stops") or {}).get("clusters") or []
        if lv: print(f"   levels[0] {types_of(lv[0])}")
        if sc_: print(f"   clusters[0] {types_of(sc_[0])}")
        whales = hl_viz.load_whales(con, a.coin, 72); print(f"   whales.directional {types_of(whales.get('directional'))}\n   whales.flow {types_of(whales.get('flow'))}")
        smart = hl_viz.smart_money(con, a.coin); print(f"   smart {types_of(smart)}")
        lb = hl_viz.load_leaderboard(con, a.coin, 20); print(f"   lb.summary {types_of(lb.get('summary'))} · lb.trend {types_of(lb.get('trend'))}")
        if lb.get("trend"): print(f"   lb.trend[0] {types_of(lb['trend'][0])}")
        print("\n2) Lernstand")
        L = hl_viz.forecast_learn(con, a.coin)
        for k in ("weights", "analog", "tprof", "magnets", "capitulation", "ensemble"):
            v = L.get(k)
            if k == "analog" and v: print(f"   analog: n={v.get('n')} · ret-Schlüssel {list((v.get('ret') or {}).keys())} (Typen {[type(x).__name__ for x in (v.get('ret') or {})]})")
            elif k == "weights" and v: print(f"   weights: {len(v)} Treiber, gelernt: {[n for n, w in v.items() if abs(w['weight'] - w['prior']) > 0.02]}")
            else: print(f"   {k}: {types_of(v)[:160]}")
        if L.get("errors"): print("   Lernfehler:", L["errors"])
        print("\n3) Prognose")
        fc = hl_forecast.compute_forecast(con, a.coin, chart, whales, smart, lb, None, chart.get("etf"), chart.get("bnc"), chart.get("cdc"),
                                          chart.get("bybit"), chart.get("okx"), learned=L)
        if fc:
            print(f"   ok · Bias {fc['bias']:+.2f} ({fc['label']}) · Konfidenz {fc['confidence']:.0%} · Kauf {fc['buy']['px']:,.0f} · Verkauf {fc['sell']['px']:,.0f} · Treiber {len(fc['drivers'])} · fehlend {fc['missing']}")
        else:
            print("   None (zu wenige Kerzen oder kein Kurs)")
    except Exception:
        print("\nFEHLER — vollständiger Traceback:\n" + traceback.format_exc())
    finally:
        con.close()


if __name__ == "__main__":
    main()
