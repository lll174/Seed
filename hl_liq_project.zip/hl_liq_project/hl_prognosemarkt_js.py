"""
hl_prognosemarkt_js.py -- Skript des Abschnitts „PM Prognosemärkte“ im Dashboard (U235, 23.88), ausgeliefert unter /prognosemarkt.js.

Eigene Datei wie hl_makro_js.py: wird mit `node --check` geprüft (A7) und ändert den Seiten-Text von hl_viz kaum. Baut auf den
Helfern der Seite auf ($, getJSON, esc) und muss deshalb NACH dem Hauptskript geladen werden.

Nur lesen, kein Signal: Der Abschnitt zeigt Kurse der Prognosemärkte (Kalshi, Polymarket, Hyperliquid HIP-4) mit Quelle und
Zeitpunkt. Vor dem gemeinsamen Urteil (KONZEPT_Prognosemaerkte.md, Nachtrag R4) enthält die Nutzlast keine Größe, die Kurse mit
Ergebnissen verbindet; die Bilanz zeigt dann nur Zählungen. Keine Kauf- oder Verkaufswörter, keine Ampel für Richtungen: Farben
nur für Zustände (fertig, Warnung, Fehler) und immer mit Zeichen und Wort.
"""

PM_JS = r"""// 23.88 Prognosemärkte (U235): Kalshi, Polymarket und Hyperliquid-Ereignismärkte (HIP-4) -- nur lesen, kein Signal.
// Daten: /prognosemarkt?tab=.. (hl_prognosemarkt.py, eigene prognosemarkt.db). Die Seite fragt nur, solange der Abschnitt offen und
// sichtbar ist (höchstens einmal je Minute und Reiter; der Server hält die Antwort 60 s).
// R4 (Nachtrag 13.1): vor dem gemeinsamen Urteil enthält die Nutzlast keine Größe, die Kurse mit Ergebnissen verbindet -- die
// Bilanz zeigt dann nur Zählungen, der Reiter Makro nur die Erwartung vor dem Termin.
const PM={tab:'ueberblick', cache:{}, laeuft:{}, d:null};
try{ const s_=JSON.parse(localStorage.getItem('hl_pm')||'{}'); if(s_&&typeof s_.tab==='string') PM.tab=s_.tab; }catch(e){}
const PM_TABS=[['ueberblick','Überblick'],['krypto','Krypto'],['makro','Makro'],['ereignisse','Ereignisse'],['bilanz','Bilanz'],
 ['rueckblick','Rückblick'],['daten','Daten']];
if(!PM_TABS.some(t=>t[0]===PM.tab)) PM.tab='ueberblick';
function pmMerken(){ try{ localStorage.setItem('hl_pm', JSON.stringify({tab:PM.tab})); }catch(e){} }
const PM_PLATTFORM={kalshi:'Kalshi', polymarket:'Polymarket', hip4:'Hyperliquid HIP-4'};
const PM_ART={aufab:'Auf/Ab', schwelle:'Schwellen', spanne:'Spannen', beruehrung:'Berührung', makro:'Makro', ereignis:'Ereignis'};
const PM_STRIKE={greater:'über', greater_or_equal:'ab', less:'unter', less_or_equal:'bis', between:'zwischen'};
// Makro-Reihen: Name, Einheit, Stellen (Schwellen in der Einheit der Kalshi-Leiter)
const PM_MAKRO={KXCPI:['Verbraucherpreise USA, Monat',' %',2], KXCPIYOY:['Verbraucherpreise USA, Jahr',' %',2],
 KXU3:['Arbeitslosenquote USA',' %',2], KXPAYROLLS:['Stellen außerhalb der Landwirtschaft USA','',0]};

// ---------- Zahlen und Zeiten (Dezimalkomma; Zeiten lokal) ----------
function pmZ(x,d){ if(x==null||!isFinite(x)) return '—'; return (+x).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d}).replace('-','−'); }
function pmPr(p,d){ return p==null||!isFinite(p)?'—':pmZ(p*100,d==null?1:d)+' %'; }
function pmPp(x){ if(x==null||!isFinite(x)) return '—'; const v=x*100; return (v>0.05?'+':v<-0.05?'−':'±')+pmZ(Math.abs(v),1)+' Pp'; }
function pmSpread(s){ return s==null||!isFinite(s)?'—':pmZ(s*100,1)+' Pp'; }
function pmPx(x){ if(x==null||!isFinite(x)) return '—'; const a=Math.abs(x); return pmZ(x, a>=1000?0:a>=10?2:4); }
function pmDat(ts){ return ts?new Date(ts*1000).toLocaleString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—'; }
function pmZeit(ts){ return ts?new Date(ts*1000).toLocaleString('de-DE',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'—'; }
function pmUhr(ts){ return ts?new Date(ts*1000).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}):'—'; }
function pmDauer(s){ s=Math.abs(s); if(s<90) return pmZ(s,0)+' s'; if(s<5400) return pmZ(s/60,0)+' min'; if(s<172800) return pmZ(s/3600,s<36000?1:0)+' h';
 return pmZ(s/86400,s<864000?1:0)+' T'; }
function pmAlter(ts,jetzt){ return ts?'vor '+pmDauer(jetzt-ts):'—'; }
function pmIn(ts,jetzt){ if(!ts) return '—'; return ts>=jetzt?'in '+pmDauer(ts-jetzt):'vor '+pmDauer(jetzt-ts); }
function pmBalken(p){ if(p==null||!isFinite(p)) return ''; const w=Math.max(0,Math.min(100,p*100));
 return `<span class="pmbalken" title="${pmPr(p)}"><span class="pmfill" style="width:${w.toFixed(1)}%"></span><span class="pmmitte"></span></span>`; }
function pmFortschritt(ist,soll){ if(!soll) return ''; const a=Math.max(0,Math.min(1,(ist||0)/soll));
 return `<span class="pmbalken" title="${pmZ(a*100,0)} % der Mindestzahl"><span class="pmfill${a>=1?' pmvoll':''}" style="width:${(a*100).toFixed(1)}%"></span></span>`; }
function pmLeer(t){ return `<div class="pmleer">${t}</div>`; }
function pmName(pl){ return esc(PM_PLATTFORM[pl]||pl||''); }
function pmKurz(v){ if(v==null) return '—'; if(typeof v==='number') return Number.isInteger(v)?pmZ(v,0):pmZ(v,Math.abs(v)>=100?1:4);
 if(typeof v==='boolean') return v?'ja':'nein'; if(Array.isArray(v)) return v.slice(0,6).map(pmKurz).join(', ')+(v.length>6?' …':'');
 if(typeof v==='object') return Object.keys(v).slice(0,8).map(k=>`${esc(k)} ${typeof v[k]==='object'&&v[k]!==null&&!Array.isArray(v[k])?'{…}':pmKurz(v[k])}`).join(' · ');
 return esc(String(v)); }

// ---------- Laden und Reiter ----------
function pmOffen(){ const p=$('sec-prognosemarkt'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function pmLeiste(){ const el=$('pmbar'); if(!el) return;
 el.innerHTML=`<div id="pmtabs" class="pmzeile">${PM_TABS.map(([k,n])=>`<button class="tog ${k===PM.tab?'on':'off'}" onclick="pmTab('${k}')">${n}</button>`).join('')}`
  +`<span id="pmstand" class="sub pmstand"></span></div>`; }
function pmTab(k){ if(!PM_TABS.some(t=>t[0]===k)) return; PM.tab=k; pmMerken(); pmLeiste(); pmLaden(false); }
async function pmLaden(zwang){ if(!pmOffen()) return; const el=$('pmbody'); if(!el) return; pmCss();
 if(!$('pmtabs')) pmLeiste();
 const tab=PM.tab, c=PM.cache[tab];
 if(c&&!zwang&&Date.now()-c.zeit<55000){ pmZeigen(c.d); return; }
 if(PM.laeuft[tab]) return; PM.laeuft[tab]=true; el.style.opacity=c?'0.55':'1';
 try{ const d=await getJSON('/prognosemarkt?tab='+tab); PM.cache[tab]={d, zeit:Date.now()}; if(PM.tab===tab) pmZeigen(d); }
 catch(e){ if(!c&&PM.tab===tab) el.innerHTML='<div class="sub">Prognosemärkte nicht erreichbar.</div>'; }
 finally{ PM.laeuft[tab]=false; el.style.opacity='1'; } }
function pmZeigen(d){ const el=$('pmbody'); if(!el) return; PM.d=d;
 const st=$('pmstand'); if(st) st.textContent=d&&d.stand?'Stand '+pmUhr(d.stand)+' · Zeiten lokal':'';
 if(!d||!d.ok){ el.innerHTML=pmLeer(((d&&d.fehlt)||['keine Daten']).map(x=>esc(x)).join('<br>'))
   +'<div class="sub">Debug „Prognosemärkte: Stand und Quellen“ zeigt Erstlauf, Abrufe und Fehler.</div>'; return; }
 const f={ueberblick:pmUeberblick, krypto:pmKrypto, makro:pmMakro, ereignisse:pmEreignisse, bilanz:pmBilanz, rueckblick:pmRueckblick,
  daten:pmDaten}[d.tab]||pmUeberblick;
 el.innerHTML=pmKopf(d)+f(d)+pmFuss(d); }
function pmKopf(d){
 const u=d.urteil_vom?`Gemeinsames Urteil vom ${pmDat(d.urteil_vom)} (Reiter Bilanz)`
  :d.abschluss?`Rückblick ohne Urteil abgeschlossen am ${pmDat(d.abschluss.vom)} – nur noch beschreibend, ohne p-Werte (Reiter Bilanz)`
  :'Gemeinsames Urteil noch offen – bis dahin nur Zählungen (R4)';
 return `<div class="pmhinweis">⚠ ${esc(d.hinweis||'Echo des Spots, kein Signal.')}</div>`
  +`<div class="pmkopf">${u} · Stichtag des Rückblicks ${d.stichtag?pmDat(d.stichtag):'noch nicht gesetzt (Erstlauf)'}</div>`; }
function pmFuss(d){ return `<div class="pmfuss">Quelle: prognosemarkt.db (nur lesen) · Auswertung ${esc(d.version||'—')} · Kurse von Kalshi, `
 +`Polymarket und Hyperliquid HIP-4, Spot von Coinbase · Ja-Kurs = Mitte aus Geld und Brief (sonst letzter Handel) · Zeiten lokal</div>`; }

// ---------- Überblick: laufende und nächste Auf/Ab-Fenster, HIP-4, Spot ----------
function pmSpot(sp){ if(!sp) return ''; const t=['BTC','ETH'].filter(c=>sp[c]).map(c=>`<b>${c}</b> ${pmPx(sp[c].kurs)} USD <span class="pmzeit">(${esc(sp[c].quelle||'')}, Minute bis ${pmUhr(sp[c].ts)})</span>`);
 return t.length?`<div class="pmsatz">Spot: ${t.join(' · ')}</div>`:''; }
function pmUeberblick(d){ const j=d.stand, F=d.fenster||[], H=d.hip4||[];
 let h=pmSpot(d.spot);
 h+=`<h3 class="pmh3">Auf/Ab-Fenster: laufend und in den nächsten 30 min</h3>`;
 h+=F.length?`<div class="pmscroll"><table class="w"><tr><th>Basis</th><th class="n">Ja-Kurs (steigt)</th><th></th><th class="n">Spotmodell</th><th>Fenster</th><th>Zustand</th><th>Plattform</th><th class="n">Spread</th><th class="n">Stand</th><th>Reihe</th></tr>`
  +F.map(f=>`<tr><td>${esc(f.basis||'')}</td><td class="n">${pmPr(f.p)}</td><td>${pmBalken(f.p)}</td><td class="n pmecho">${pmPr(f.p_s)}</td>`
   +`<td>${pmUhr(f.beginn)}–${pmUhr(f.ende)}${f.bezug!=null?`<span class="pmklein">Bezug ${pmPx(f.bezug)}</span>`:''}</td>`
   +`<td>${f.laeuft?'läuft, Ende '+pmIn(f.ende,j):'beginnt '+pmIn(f.beginn,j)}</td><td>${pmName(f.plattform)}</td>`
   +`<td class="n">${pmSpread(f.spread)}</td><td class="n pmzeit">${pmAlter(f.ts,j)}</td><td class="mono">${esc(f.reihe||'')}</td></tr>`).join('')+`</table></div>`
  :pmLeer('Keine offenen Auf/Ab-Fenster mit Kurs (der Takt fragt Kalshi und Polymarket jede Minute; Kurse älter als 5 min fallen weg).');
 h+=`<h3 class="pmh3">Hyperliquid HIP-4: Kursziele</h3>`;
 h+=H.length?`<div class="pmscroll"><table class="w"><tr><th>Basis</th><th class="n">Ziel</th><th class="n">Ja-Kurs</th><th></th><th class="n">Spotmodell</th><th>Ablauf</th><th class="n">Stand</th><th>Ausgang</th></tr>`
  +H.map(x=>`<tr><td>${esc(x.basis||'')}</td><td class="n">${pmPx(x.ziel)}</td><td class="n">${pmPr(x.p)}</td><td>${pmBalken(x.p)}</td><td class="n pmecho">${pmPr(x.p_s)}</td>`
   +`<td>${pmZeit(x.ende)} <span class="pmzeit">(${pmIn(x.ende,j)})</span></td><td class="n pmzeit">${pmAlter(x.ts,j)}</td><td class="mono">${esc(x.markt||'')}</td></tr>`).join('')+`</table></div>`
  :pmLeer('Keine offenen HIP-4-Ausgänge mit Kurs.');
 return h+`<div class="sub pmnotiz">${esc(d.hinweis_spot||'')} Ja-Kurse sind Preise, keine geprüften Wahrscheinlichkeiten. Ob sie mehr wissen als der Spot, klärt erst das gemeinsame Urteil (Reiter Bilanz).</div>`; }

// ---------- Krypto: Leitern (Schwellen, Spannen, Berührung) ----------
function pmKrypto(d){ const j=d.stand, L=d.leitern||[];
 if(!L.length) return pmSpot(d.spot)+pmLeer('Keine offenen Krypto-Leitern mit Kurs aus der letzten Stunde (Kalshi, Polymarket).');
 const rekal=L.some(l=>(l.punkte||[]).some(p=>p.p_rekal!=null));
 return pmSpot(d.spot)+L.map(l=>`<h3 class="pmh3">${pmName(l.plattform)} · ${esc(l.reihe||'')} · ${esc(PM_ART[l.art]||l.art||'')} · Ablauf ${pmZeit(l.ende)} (${pmIn(l.ende,j)})</h3>`
  +`<div class="pmscroll pmhoch"><table class="w"><tr><th class="n">Schwelle</th><th class="n">Ja-Kurs</th>${rekal?'<th class="n">rekalibriert</th>':''}<th class="n">Spotmodell</th><th class="n">Spread</th><th class="n">Stand</th><th>Art</th></tr>`
  +(l.punkte||[]).map(p=>`<tr><td class="n">${pmPx(p.k)}</td><td class="n">${pmPr(p.p)}</td>`
   +`${rekal?`<td class="n">${pmPr(p.p_rekal)}</td>`:''}<td class="n pmecho">${pmPr(p.p_s)}</td><td class="n">${pmSpread(p.spread)}</td><td class="n pmzeit">${pmAlter(p.ts,j)}</td><td>${esc(PM_STRIKE[p.art]||p.art||'')}</td></tr>`).join('')
  +`</table></div>`).join('')+(rekal?`<div class="sub pmnotiz">${esc(d.hinweis_rekal||'')}</div>`:'')
  +`<div class="sub pmnotiz">Spotmodell: driftfrei aus dem 1-min-Spot und der Schwankung der letzten 1, 7 und 30 Tage zum Zeitpunkt der jüngsten Spotminute (Berührung: Spiegelungsnäherung). Nur Anzeige.</div>`; }

// ---------- Makro: Erwartung vor dem Termin; vergangene Termine erst nach dem Urteil ----------
function pmMakroName(r){ const m=PM_MAKRO[r]; return m?`${esc(m[0])} <span class="pmklein mono">${esc(r)}</span>`:`<span class="mono">${esc(r||'')}</span>`; }
function pmMakroWert(r,v){ const m=PM_MAKRO[r]||['','',2]; return v==null||!isFinite(v)?'—':pmZ(v,m[2])+m[1]; }
function pmMakro(d){ const E=d.erwartung||[];
 let h=`<div class="pmsatz">Erwartung des Marktes vor dem nächsten Termin: Median und halbe Breite zwischen dem 16- und 84-%-Punkt der Kalshi-Leiter `
  +`(Kurse der letzten Stunde, monoton geglättet, ohne Hochrechnung über die Leiter hinaus).</div>`;
 h+=E.length?`<div class="pmscroll"><table class="w"><tr><th>Reihe</th><th>Termin</th><th class="n">Median</th><th class="n">± Streuung</th><th class="n">Schwellen</th></tr>`
  +E.map(e=>`<tr><td class="pmtitel">${pmMakroName(e.reihe)}</td><td>${pmDat(e.termin)}</td><td class="n">${pmMakroWert(e.reihe,e.median)}</td>`
   +`<td class="n">${pmMakroWert(e.reihe,e.streuung)}</td><td class="n">${pmZ(e.schwellen,0)}</td></tr>`).join('')+`</table></div>`
  :pmLeer('Keine offene Makro-Leiter mit mindestens vier Schwellen und Kursen der letzten Stunde (KXCPI, KXCPIYOY, KXU3, KXPAYROLLS).');
 if(d.termine){ const T=d.termine;
  h+=`<h3 class="pmh3">${d.termine_ohne_urteil?'Vergangene Termine (beschreibend, ohne Urteil – Rückblick abgeschlossen)':'Vergangene Termine (nach dem gemeinsamen Urteil)'}</h3>`+(T.length?`<div class="pmscroll pmhoch"><table class="w"><tr><th>Reihe</th><th>Termin</th><th class="n">Median</th><th class="n">± Streuung</th><th class="n">Ist</th><th class="n">u = Ist − Median</th><th class="n">z</th><th class="n">BTC 30 min</th></tr>`
   +T.map(t=>`<tr><td class="pmtitel">${pmMakroName(t.reihe)}</td><td>${pmDat(t.termin)}</td><td class="n">${pmMakroWert(t.reihe,t.median)}</td><td class="n">${pmMakroWert(t.reihe,t.streuung)}</td>`
    +`<td class="n">${pmMakroWert(t.reihe,t.ist)}</td><td class="n">${pmZ(t.u,2)}</td><td class="n">${pmZ(t.z,2)}</td><td class="n">${t.r30_btc==null?'—':pmZ(t.r30_btc*100,2)+' %'}</td></tr>`).join('')+`</table></div>`
   :pmLeer('Noch keine Termine berechnet.'));
 } else h+=`<div class="sub pmnotiz">${esc(d.termine_hinweis||'')}</div>`;
 return h; }

// ---------- Ereignisse: Ja-Kurse mit Änderung gegen 1 h und 24 h ----------
function pmEreignisse(d){ const j=d.stand, E=d.ereignisse||[];
 if(!E.length) return pmLeer('Keine offenen Ereignis- oder Makromärkte mit Kurs aus der letzten Stunde.');
 return `<div class="pmsatz">Ja-Kurse offener Ereignismärkte mit Änderung gegen vor 1 h und vor 24 h; ⚑ markiert Sprünge ab 10 Prozentpunkten.</div>`
  +E.map(e=>`<h3 class="pmh3">${pmName(e.plattform)} · ${esc(e.reihe||e.ereignis||'')}${e.ende?` · Ablauf ${pmZeit(e.ende)} (${pmIn(e.ende,j)})`:''}</h3>`
   +`<div class="pmscroll"><table class="w"><tr><th>Markt</th><th class="n">Ja-Kurs</th><th class="n">Δ 1 h</th><th class="n">Δ 24 h</th><th class="n">Spread</th><th class="n">Stand</th></tr>`
   +(e.maerkte||[]).map(m=>{ const s=[m.d1h,m.d24h].some(x=>x!=null&&Math.abs(x)>=0.1);
     return `<tr${s?' class="pmsprung"':''}><td class="pmtitel">${s?'<span title="Sprung ab 10 Prozentpunkten">⚑</span> ':''}${esc(m.titel||m.markt||'')}</td>`
      +`<td class="n">${pmPr(m.p)}</td><td class="n">${pmPp(m.d1h)}</td><td class="n">${pmPp(m.d24h)}</td><td class="n">${pmSpread(m.spread)}</td><td class="n pmzeit">${pmAlter(m.ts,j)}</td></tr>`; }).join('')
   +`</table></div>`).join(''); }

// ---------- Bilanz: vor dem Urteil nur Zählung (R4), danach das gemeinsame Urteil (R5) ----------
function pmUrteil(t){ t=String(t||'—'); if(t==='belegt') return '<span class="pmok">✓ belegt</span>';
 if(t==='nicht belegt') return 'nicht belegt'; if(t==='nicht prüfbar') return '<span class="pmwarn">⚠ nicht prüfbar</span>';
 return `<span class="pmwarn">⚠ ${esc(t)}</span>`; }
function pmVorUrteil(d){ const V=d.vor_urteil; if(!V||!V.length) return '';
 return `<h3 class="pmh3">Prüfungen vor dem Urteil (R12: Positivkontrollen und Nullproben auf echten Daten)</h3><div class="pmscroll"><table class="w"><tr><th></th><th>Prüfung</th><th>Wert</th></tr>`
  +V.map(v=>`<tr><td>${v[1]?'<span class="pmok">✓</span>':'<span class="pmnein">✗</span>'}</td><td class="pmtitel">${esc(v[0])}</td><td class="pmtitel">${esc(v[2]||'')}</td></tr>`).join('')
  +`</table></div>`; }
function pmVorlaeufe(vl){ const a=vl&&vl.anteile; if(!a) return ''; const k=Object.keys(a).map(Number).sort((x,y)=>y-x);
 return `<div class="sub pmnotiz">H2-Vorlauf (R9: der längste mit Kurs bei mindestens 80 % der ${pmZ(vl.ereignisse||0,0)} Tagesleitern): `
  +k.map(s=>`${pmZ(s/3600,0)} h ${pmPr(a[s],0)}`).join(' · ')+`</div>`; }
// 23.91 (Nachtrag 13.6, Wahl A): Rückblick ohne Urteil abgeschlossen -- nur Größen mit Intervall, kein p, kein „belegt“
function pmAbschluss(d){ const T=d.titel||{}, W=d.abschluss_werte||{}, a=d.abschluss||{}, pl=(W.H3||{}).placebo||{};
 const zeile=k=>{ const e=W[k]||{}, leer=!e.n;
  return `<tr><td class="pmtitel">${esc(T[k]||k)}</td><td><span class="pmwarn">kein Urteil</span>${leer?' <span class="pmklein">keine Fälle</span>':''}</td>`
   +`<td class="n">${leer?'—':pmZ(e.mass,4)}</td><td class="n">${!leer&&e.lo!=null&&e.hi!=null?pmZ(e.lo,4)+' … '+pmZ(e.hi,4):'—'}</td>`
   +`<td class="n">${!leer&&e.h1!=null&&e.h2!=null?pmZ(e.h1,4)+' / '+pmZ(e.h2,4):'—'}</td><td class="n">${pmZ(e.n||0,0)}</td><td class="n">${pmZ(e.tage||0,0)}</td></tr>`; };
 return `<div class="pmsatz">${esc(a.text||'Rückblick ohne Urteil abgeschlossen.')}</div>`
  +`<div class="pmkopf">Abgeschlossen am ${pmDat(a.vom)} · keine p-Werte und kein „belegt“ – nur Größen mit 90-%-Intervall (R13)</div>`
  +`<div class="pmscroll"><table class="w"><tr><th>Prüfung</th><th>Urteil</th><th class="n">Maß</th><th class="n">90-%-Intervall</th><th class="n">Hälften</th><th class="n">n</th><th class="n">Tage</th></tr>`
  +['H1','H2','H3'].map(zeile).join('')+`</table></div>`
  +`<div class="sub pmnotiz">Maß: H1 Kovarianz c (Kurs vor dem Fensterbeginn gegen 50 %); H2 mittlerer gewichteter Brier-Zugewinn je Tag gegen das `
  +`Modell (positiv = Markt besser); H3 Spearman ρ zwischen Überraschung und BTC 08:30–09:00 ET (erwartet negativ), Placebos ρ gegen `
  +`08:00–08:30 ET ${pmZ(pl.davor,3)} und gegen die Vorwoche ${pmZ(pl.vorwoche,3)}.</div>`
  +pmVorUrteil(d)
  +(d.beschreibend?`<details class="pmdetails"><summary>Beschreibend (R13: nur Effektgrößen, ohne p-Werte)</summary><div class="pmscroll"><table class="w">`
   +Object.keys(d.beschreibend).map(k=>`<tr><td class="mono">${esc(k)}</td><td class="pmtitel">${pmKurz(d.beschreibend[k])}</td></tr>`).join('')+`</table></div></details>`:''); }
function pmBilanz(d){ const T=d.titel||{};
 if(!d.urteil&&d.abschluss_werte) return pmAbschluss(d);
 if(!d.urteil){ const z=d.zaehlung||{}, Z=z.zaehlung||{};
  if(!z.lauf) return pmLeer('Noch keine Zählung. Die erste läuft eine Stunde nach dem Start des Dienstes, danach täglich; von Hand: Debug „Prognosemärkte: Auswertung“.')+pmVorUrteil(d);
  const h1=Z.H1||{}, vl=Z.H2_vorlauf||{}, h2=Z.H2||{}, q=Z.H3_quelle||{};
  const zeile=(name,ist,soll,rest)=>`<tr><td class="pmtitel">${name}</td><td class="n">${pmZ(ist,0)}</td><td class="n">${pmZ(soll,0)}</td><td>${pmFortschritt(ist,soll)}</td><td class="pmtitel">${rest||''}</td></tr>`;
  return `<div class="pmsatz">Vor dem gemeinsamen Urteil zeigt die Bilanz nur Zählungen – keine Treffer, keine Brier-Werte, keine Renditen (Nachtrag R4). `
   +`Das Urteil fällt einmal, sobald der Rückblick vollständig ist (R3, R5).</div>`
   +`<div class="pmkopf">Zählung vom ${pmDat(z.lauf)} · Freigabe: ${z.freigabe?'<span class="pmok">✓ ja</span>':'<span class="pmwarn">⏳ noch nicht</span> – '+esc(z.grund||'')}</div>`
   +`<div class="pmscroll"><table class="w"><tr><th>Prüfung</th><th class="n">gezählt</th><th class="n">mindestens</th><th></th><th>dazu</th></tr>`
   +zeile(esc(T.H1||'H1')+' – Fenster mit gültigem Kurs vor dem Beginn',h1.mit_kurs,4000,`von ${pmZ(h1.maerkte,0)} Fenstern im Rückblick`)
   +zeile('H1 – Tage mit solchen Fenstern',h1.tage,60,'')
   +zeile(esc(T.H2||'H2')+' – Tagesleitern mit Fall',h2.tage,100,vl.vorlauf?`Vorlauf ${pmZ(vl.vorlauf/3600,0)} h`+(h2.kein_spot||h2.keine_schwelle?` · ohne Spot ${pmZ(h2.kein_spot||0,0)}, ohne Schwelle im Bereich ${pmZ(h2.keine_schwelle||0,0)}`:''):'Vorlauf noch offen (keiner mit Kurs bei 80 % der Leitern)')
   +zeile(esc(T.H3||'H3')+' – Termine',q.termine,30,q.art?`Kursquelle ${q.art==='mitte'?'Mitte aus Geld und Brief':'letzte Trades'} (Mitte bei ${pmPr(q.anteil_mitte,0)} der Termine)`:'')
   +`</table></div>`+pmVorlaeufe(vl)+pmVorUrteil(d); }
 const U=d.urteil;
 // 23.89 (U236): Gewichte nach R5 auf die prüfbaren Tests normiert (bis 23.88 stand hier immer 0,25 / 0,25 / 0,5)
 const W_={H1:0.25,H2:0.25,H3:0.5}, pb_=U.filter(u=>u.p_holm!=null).map(u=>u.pruefung), sw_=pb_.reduce((a,k)=>a+(W_[k]||0),0);
 const gew_=(pb_.length&&pb_.length<U.length&&sw_>0)
  ?'gewichteter Holm, auf die prüfbaren Tests normiert ('+pb_.map(k=>esc(k)+' '+pmZ(W_[k]/sw_,2)).join(' · ')+'; nicht prüfbar: '
   +U.filter(u=>u.p_holm==null).map(u=>esc(u.pruefung)).join(', ')+')'
  :'gewichteter Holm (H1 0,25 · H2 0,25 · H3 0,5)';
 return `<div class="pmsatz">Gemeinsames Urteil vom ${pmDat(d.urteil_vom)}: ${gew_}, studentisierter Block-Bootstrap `
  +`über 7-Tage-Blöcke; belegt nur mit angepasstem p unter 0,05, richtigem Vorzeichen in beiden Hälften und erreichten Mindestzahlen.</div>`
  +`<div class="pmscroll"><table class="w"><tr><th>Prüfung</th><th>Urteil</th><th class="n">Maß</th><th class="n">90-%-Intervall</th><th class="n">p (Holm)</th><th class="n">p</th><th class="n">Hälften</th><th class="n">n</th><th class="n">Tage</th></tr>`
  +U.map(u=>`<tr><td class="pmtitel">${esc(T[u.pruefung]||u.pruefung)}</td><td>${pmUrteil(u.urteil)}</td><td class="n">${pmZ(u.mass,4)}</td>`
   +`<td class="n">${u.lo!=null&&u.hi!=null?pmZ(u.lo,4)+' … '+pmZ(u.hi,4):'—'}</td><td class="n">${pmZ(u.p_holm,4)}</td><td class="n">${pmZ(u.p,4)}</td>`
   +`<td class="n">${u.h1!=null?pmZ(u.h1,4)+' / '+pmZ(u.h2,4):'—'}</td><td class="n">${pmZ(u.n,0)}</td><td class="n">${pmZ(u.tage,0)}</td></tr>`).join('')
  +`</table></div>`+pmVorUrteil(d)
  +(d.beschreibend?`<details class="pmdetails"><summary>Beschreibend (R13: nur Effektgrößen, ohne p-Werte)</summary><div class="pmscroll"><table class="w">`
   +Object.keys(d.beschreibend).map(k=>`<tr><td class="mono">${esc(k)}</td><td class="pmtitel">${pmKurz(d.beschreibend[k])}</td></tr>`).join('')+`</table></div></details>`:''); }

// ---------- Rückblick: Teile, Abdeckung, Stichtag ----------
function pmRueckblick(d){ const A=d.abdeckung||{}, T=d.teile||[];
 const offen=Object.keys(A).filter(k=>!A[k].fertig||A[k].anteil<0.95);
 const rows=T.map(t=>{ const a=A[t.teil];
  const st=t.abgebrochen?'<span class="pmwarn">⚠ abgebrochen</span>':t.fertig?'<span class="pmok">✓ fertig</span>':(t.schritte?'läuft':'wartet');
  const n=t.n!=null?t.n:(t.n_live!=null||t.n_hist!=null)?(t.n_live||0)+(t.n_hist||0):null;
  return `<tr><td class="mono">${a?'★ ':''}${esc(t.teil)}</td><td>${st}</td>`
   +`<td class="n">${a?(a.liste?pmPr(a.anteil,1)+`<span class="pmklein">${pmZ(a.erledigt,0)} von ${pmZ(a.liste,0)}</span>`:'—'):''}</td>`
   +`<td class="n">${pmZ(t.schritte||0,0)}</td><td class="n">${t.fehler?pmZ(t.fehler,0):'—'}</td><td class="n">${pmZ(n,0)}</td><td>${esc(t.quelle||'')}</td>`
   +`<td class="pmtitel">${esc(t.abgebrochen||t.hinweis||'')}${t.fertig_ts?` <span class="pmzeit">fertig ${pmZeit(t.fertig_ts)}</span>`:''}</td></tr>`; }).join('');
 return `<div class="pmkopf">Stichtag ${d.stichtag?pmDat(d.stichtag):'—'} (Märkte mit Handelsschluss davor, R2) · Kalshi-Archivgrenze ${d.grenze?pmDat(d.grenze):'—'} · Erstlauf ${d.erstlauf?pmDat(d.erstlauf):'noch nicht'}</div>`
  +`<div class="pmsatz">Für das gemeinsame Urteil müssen die mit ★ markierten Teile fertig sein und mindestens 95 % ihrer Arbeitsschritte erledigt haben (R3). `
  +(offen.length?'Noch offen: '+esc(offen.join(', ')):'<span class="pmok">✓ alle fertig</span>')+`</div>`
  +(T.length?`<div class="pmscroll"><table class="w"><tr><th>Teil</th><th>Stand</th><th class="n">Abdeckung</th><th class="n">Schritte</th><th class="n">Fehler in Folge</th><th class="n">Anzahl</th><th>Quelle</th><th>Hinweis</th></tr>${rows}</table></div>`
   :pmLeer('Noch kein Rückblick.')); }

// ---------- Daten: Abrufe, Hyperliquid-Gewicht, Frische, Fehler ----------
function pmDaten(d){ const j=d.stand, Q=d.quellen||[], z=d.zustand||{}, P=z.pausen||{}, Fr=d.frische||[], Fe=d.fehler||[], Zl=d.zeilen||{};
 const dienst=z.ts?`Dienst: letzter Zustand ${pmAlter(z.ts,j)}${j-z.ts>300?' <span class="pmwarn">⚠ älter als 5 min – Takt steht?</span>':''}`
  :'Dienst: noch kein Zustand (der Takt beginnt 60 s nach dem Start des Dashboards)';
 const g=d.hl_gewicht_je_minute, gd=d.hl_deckel;
 let h=`<div class="pmkopf">${dienst} · Hyperliquid: im Mittel ${pmZ(g,1)} Gewicht je Minute (letzte Stunde), eigener Deckel ${pmZ(gd,0)}`
  +`${g!=null&&gd&&g>gd?' <span class="pmwarn">⚠ über dem Deckel</span>':''} (der Recorder nutzt 1.080 von 1.200 je Minute und IP)</div>`;
 h+=`<h3 class="pmh3">Abrufe der letzten 24 h je Quelle</h3>`+(Q.length?`<div class="pmscroll"><table class="w"><tr><th>Quelle</th><th class="n">ok</th><th class="n">404</th><th class="n">429</th><th class="n">gesperrt</th><th class="n">Fehler</th><th class="n">⌀ ms</th><th class="n">letzter Abruf</th></tr>`
  +Q.map(x=>`<tr><td class="mono">${esc(x.quelle)}</td><td class="n">${pmZ(x.ok,0)}</td><td class="n">${pmZ(x.fehlt,0)}</td>`
   +`<td class="n">${x.zu_viele?'<span class="pmwarn">⚠ '+pmZ(x.zu_viele,0)+'</span>':'0'}</td><td class="n">${x.gesperrt?'<span class="pmnein">✗ '+pmZ(x.gesperrt,0)+' (Region?)</span>':'0'}</td>`
   +`<td class="n">${x.fehler?'<span class="pmwarn">⚠ '+pmZ(x.fehler,0)+'</span>':'0'}</td><td class="n">${pmZ(x.ms,0)}</td>`
   +`<td class="n pmzeit">${pmAlter(x.letzter,j)}${P[x.quelle]?` · <span class="pmwarn">Pause bis ${pmUhr(P[x.quelle])}</span>`:''}</td></tr>`).join('')+`</table></div>`
  :pmLeer('Noch keine Abrufe in den letzten 24 h.'));
 h+=`<h3 class="pmh3">Frische der Live-Kurse</h3>`+(Fr.length?`<div class="pmscroll"><table class="w"><tr><th>Plattform</th><th>jüngster Kurs</th><th class="n">Alter</th></tr>`
  +Fr.map(x=>`<tr><td>${pmName(x.plattform)}</td><td>${pmDat(x.ts)}</td><td class="n${j-x.ts>900?' pmwarn':''}">${j-x.ts>900?'⚠ ':''}${pmAlter(x.ts,j)}</td></tr>`).join('')+`</table></div>`
  :pmLeer('Noch keine Live-Kurse.'));
 if(Fe.length) h+=`<h3 class="pmh3">Fehler der letzten 24 h</h3><div class="pmscroll"><table class="w"><tr><th>Aufgabe</th><th>Zeit</th><th>Grund</th></tr>`
  +Fe.map(x=>`<tr><td class="mono">${esc(x.aufgabe)}</td><td>${pmZeit(x.ts)}</td><td class="pmtitel">${esc(x.fehler||'')}</td></tr>`).join('')+`</table></div>`;
 h+=`<div class="sub pmnotiz">Zeilen: ${Object.keys(Zl).map(k=>`${esc(k)} ${pmZ(Zl[k],0)}`).join(' · ')||'—'}. Taktung: Kalshi 2 je Sekunde, Polymarket 3–5, Coinbase und Binance 4; `
  +`429 → Pause 60 s (verdoppelt bis 15 min), drei Fehler in Folge → 15 min (verdoppelt bis 6 h).</div>`;
 return h; }

// ---------- Gestaltung (nur in diesem Abschnitt) und Start ----------
function pmCss(){ if($('pmcss')) return; const st=document.createElement('style'); st.id='pmcss';
 st.textContent=`#sec-prognosemarkt .pmzeile{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0 8px}
 #sec-prognosemarkt button.tog{min-width:0;padding:4px 9px}
 #sec-prognosemarkt .pmstand{margin-left:auto}
 #sec-prognosemarkt .pmhinweis{margin:6px 0;padding:6px 10px;border:1px solid #30363d;border-radius:6px;background:#0d1117;color:#c9d1d9;font-size:12px;line-height:1.45}
 #sec-prognosemarkt .pmkopf{font-size:11px;color:#8b949e;margin:6px 0 4px;line-height:1.5}
 #sec-prognosemarkt .pmsatz{font-size:12px;color:#c9d1d9;line-height:1.5;margin:6px 0 8px}
 #sec-prognosemarkt .pmscroll{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #sec-prognosemarkt .pmhoch{max-height:420px;overflow-y:auto}
 #sec-prognosemarkt h3.pmh3{font-size:12px;color:#e6edf3;margin:14px 0 4px;font-weight:600;line-height:1.4}
 #sec-prognosemarkt .pmleer{padding:14px 8px;border:1px dashed #21262d;border-radius:6px;color:#8b949e;font-size:12px;margin:8px 0;line-height:1.45}
 #sec-prognosemarkt .pmzeit{color:#8b949e} #sec-prognosemarkt td.pmecho{color:#8b949e}
 #sec-prognosemarkt .pmklein{display:block;font-size:10px;color:#8b949e}
 #sec-prognosemarkt .pmtitel{white-space:normal;min-width:150px;max-width:420px;line-height:1.35}
 #sec-prognosemarkt .pmok{color:#3fb950} #sec-prognosemarkt .pmwarn{color:#d29922} #sec-prognosemarkt .pmnein{color:#f85149}
 #sec-prognosemarkt .pmbalken{position:relative;display:inline-block;width:64px;height:8px;background:#161b22;border:1px solid #30363d;border-radius:4px;vertical-align:middle;overflow:hidden}
 #sec-prognosemarkt .pmfill{position:absolute;left:0;top:0;bottom:0;background:#8b949e;border-radius:3px 0 0 3px}
 #sec-prognosemarkt .pmfill.pmvoll{background:#c9d1d9}
 #sec-prognosemarkt .pmmitte{position:absolute;left:50%;top:0;bottom:0;width:1px;background:#e6edf3;opacity:.55}
 #sec-prognosemarkt tr.pmsprung td{background:#1c1606}
 #sec-prognosemarkt .pmnotiz{margin:8px 0 2px;white-space:normal;line-height:1.45}
 #sec-prognosemarkt details.pmdetails{margin:12px 0 4px} #sec-prognosemarkt details.pmdetails summary{cursor:pointer;color:#c9d1d9;font-size:12px}
 #sec-prognosemarkt .pmfuss{font-size:10px;color:#6e7681;margin-top:12px;line-height:1.45}
 @media (max-width:700px){ #sec-prognosemarkt button.tog{padding:6px 10px} #sec-prognosemarkt .pmstand{margin-left:0;width:100%}
  #sec-prognosemarkt .pmtitel{min-width:130px} }`;
 document.head.appendChild(st); }
function pmStart(){ if(!$('sec-prognosemarkt')) return; pmCss(); pmLeiste(); pmLaden(false);
 setInterval(()=>{ if(pmOffen()) pmLaden(false); }, 60000);
 document.addEventListener('visibilitychange',()=>{ if(pmOffen()) pmLaden(false); }); }
pmStart();
"""
