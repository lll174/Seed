#!/usr/bin/env python3
"""
hl_datentage.py -- Studie U154 (Version 2026-09-23.67): Schwanken BTC und ETH an US-Datentagen stärker?

Vorab festgelegt in KONZEPT_Makro.md 11.7 (13.10.2026, vor dem Bau und vor jeder Zahl auf echten Daten):
  * Termine: Veröffentlichungstage aus makro.db (mk_termin, FRED fred/release/dates, U153) -- H1 Verbraucherpreise (Reihe
    CPIAUCSL), H2 Arbeitsmarktbericht (UNRATE); beschreibend Erzeugerpreise (PPIFIS) und Erstanträge (ICSA). Ab 01.01.2020.
  * Fenster 8:30–10:30 New York: vier Renditen der Kerzen ab 8:30, 9:00, 9:30, 10:00 gegen den Schluss der Kerze davor
    (30-min-Kerzen der Binance-Perps aus swing.db); RV_w = Σ r².
  * Vergleich: Werktage desselben Monats ohne einen der vier Termine und ohne NYSE-Feiertag (mindestens 5).
  * Maß x_e = Mittel über BTC und ETH von ln(RV_w(e) + ε) − Mittel der Vergleichstage; T = Mittel über die Termine; exp(T) Faktor.
  * Null: jeder Termin auf einen zufälligen Vergleichstag desselben Monats verschoben (10.000 Ziehungen, einseitig);
    Intervall: Blockbootstrap über Monate; Urteil: p nach Holm über H1/H2 < 0,05 und T > 0 in beiden Hälften.
Nur Bericht: liest swing.db, makro.db, schreibt nichts, wirkt auf nichts (keine Konfluenz, kein Labor, keine Prognose, kein
Treiber, kein Ausblick).

Debug: python3 hl_datentage.py --studie --db <hl_liq.db> · python3 hl_datentage.py --selbsttest
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import sys
import time
from datetime import date, datetime, timedelta, timezone

import numpy as np

VERSION_MODUL = "2026-09-23.67"
TAG = 86_400
BAR = 1800
EPS = 1e-8
N_NULL = 10_000
N_BOOT = 2_000
SAAT = 154
AB = "2020-01-01"
MIN_VERGLEICH = 5
COINS = ("BTC", "ETH")
HYPOTHESEN = (("H1", "CPIAUCSL", "Verbraucherpreise"), ("H2", "UNRATE", "Arbeitsmarktbericht"))
BESCHREIBEND = (("PPIFIS", "Erzeugerpreise"), ("ICSA", "Erstanträge"))
HYP_REIHEN = tuple(s for _, s, _ in HYPOTHESEN)
ALLE_TERMINE = HYP_REIHEN + tuple(s for s, _ in BESCHREIBEND)
UTC = timezone.utc


def _ny830(d: date) -> int:
    from zoneinfo import ZoneInfo
    return int(datetime(d.year, d.month, d.day, 8, 30, tzinfo=ZoneInfo("America/New_York")).timestamp())


def _tag(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), UTC).date()


def _tag_ts(d: date) -> int:
    return int(datetime(d.year, d.month, d.day, tzinfo=UTC).timestamp())


def _de(x, nd: int = 2) -> str:
    return "—" if x is None or not np.isfinite(x) else f"{x:.{nd}f}".replace(".", ",")


# ================================================================================================ Bausteine (rein)

def fenster_rv(ts: np.ndarray, c: np.ndarray, tage: list) -> tuple:
    """
    RV im Fenster 8:30–10:30 New York je Tag: Σ r² der Kerzen ab 8:30, 9:00, 9:30, 10:00, je gegen den Schluss der Kerze davor;
    NaN, wenn eine der fünf Kerzen (ab 8:00) fehlt. Dazu die Fensterrendite ln(c[10:00-Kerze]/c[8:00-Kerze]).
    ts: Beginn der Kerzen (s, aufsteigend), c: Schluss. tage: Kalendertage (date). -> (rv, rendite)
    """
    ts = np.asarray(ts, dtype=np.int64); c = np.asarray(c, dtype=float)
    starts = np.array([[_ny830(d) + k * BAR for k in (-1, 0, 1, 2, 3)] for d in tage], dtype=np.int64).reshape(-1, 5) if tage else np.zeros((0, 5), np.int64)
    rv = np.full(len(tage), np.nan); re = np.full(len(tage), np.nan)
    if not len(ts) or not len(tage):
        return rv, re
    i = np.searchsorted(ts, starts)
    i = np.clip(i, 0, len(ts) - 1)
    da = (ts[i] == starts).all(axis=1)
    if da.any():
        cc = c[i[da]]
        with np.errstate(invalid="ignore", divide="ignore"):
            r = np.diff(np.log(cc), axis=1)
        rv[da] = np.sum(r ** 2, axis=1)
        re[da] = np.log(cc[:, -1] / cc[:, 0])
    return rv, re


def tag_rv(ts: np.ndarray, c: np.ndarray, tage: list) -> np.ndarray:
    """RV über den ganzen UTC-Tag: Σ r² der 48 Kerzen des Tags gegen den Schluss der jeweils vorigen (49 Kerzen ab 23:30 des Vortags)."""
    ts = np.asarray(ts, dtype=np.int64); c = np.asarray(c, dtype=float)
    out = np.full(len(tage), np.nan)
    if not len(ts):
        return out
    for j, d in enumerate(tage):
        t0 = _tag_ts(d) - BAR
        a = np.searchsorted(ts, t0)
        if a + 49 > len(ts) or ts[a] != t0 or ts[a + 48] != t0 + 48 * BAR:
            continue
        with np.errstate(invalid="ignore", divide="ignore"):
            out[j] = float(np.sum(np.diff(np.log(c[a:a + 49])) ** 2))
    return out


def werktage(von: date, bis: date, handelstag_fn) -> list:
    """Mo–Fr zwischen von und bis (einschließlich), an denen die NYSE geöffnet war."""
    out = []; d = von
    while d <= bis:
        if d.weekday() < 5 and handelstag_fn(d):
            out.append(d)
        d += timedelta(days=1)
    return out


def ereignisse_bauen(termine: list, alle_termine: set, kandidaten: list, L: dict, min_vergleich: int = MIN_VERGLEICH) -> list:
    """
    Je Termin e: Vergleichstage = Werktage (kandidaten) desselben Monats ohne einen Termin (alle_termine), mit vollständigen Kerzen
    in allen Coins; mindestens min_vergleich, sonst fällt e weg. L: {coin: {Tag: ln(RV + ε)}} (nur vollständige Tage).
    -> [{"tag", "monat", "le": Array (Coins), "lc": Matrix (Vergleichstage × Coins)}]
    """
    je_monat: dict = {}
    for d in kandidaten:
        if d in alle_termine:
            continue
        if all(d in L[k] for k in L):
            je_monat.setdefault((d.year, d.month), []).append(d)
    out = []
    for e in sorted(set(termine)):
        if not all(e in L[k] for k in L):
            continue
        C = je_monat.get((e.year, e.month), [])
        if len(C) < min_vergleich:
            continue
        out.append({"tag": e, "monat": (e.year, e.month), "le": np.array([L[k][e] for k in L]),
                    "lc": np.array([[L[k][c] for k in L] for c in C])})
    return out


def x_wert(ev: dict) -> float:
    """x_e = Mittel über die Coins von ln RV(e) − Mittel der Vergleichstage."""
    return float(np.mean(ev["le"] - ev["lc"].mean(axis=0)))


def null_werte(ev: dict) -> np.ndarray:
    """Alle möglichen x* bei Verschiebung auf einen Vergleichstag c*: Mittel über Coins von L(c*) − Mittel der übrigen Vergleichstage."""
    lc = ev["lc"]; n = len(lc)
    rest = (lc.sum(axis=0)[None, :] - lc) / (n - 1)
    return np.mean(lc - rest, axis=1)


def holm(p: list) -> list:
    m = len(p); o = sorted(range(m), key=lambda i: p[i]); out = [0.0] * m; laufend = 0.0
    for r, i in enumerate(o):
        laufend = max(laufend, min(1.0, (m - r) * p[i]))
        out[i] = laufend
    return out


def urteil(p_holm, e: dict) -> bool:
    """Vorab festgelegt (11.7): belegt, wenn p nach Holm < 0,05 und T > 0 in beiden Hälften (zeitlich geteilt)."""
    return bool(p_holm is not None and p_holm < 0.05 and e.get("h1", 0) > 0 and e.get("h2", 0) > 0)


def auswerten(evs: list, n_null: int = N_NULL, n_boot: int = N_BOOT, saat: int = SAAT) -> dict:
    """T, Faktor, p (Verschiebungs-Null, einseitig), 90-%-Intervall (Blockbootstrap über Monate), Hälften, je Jahr."""
    n = len(evs)
    if n < 10:
        return {"n": n, "grund": "zu wenige Termine mit vollständigen Kerzen und Vergleichstagen"}
    x = np.array([x_wert(e) for e in evs]); T = float(x.mean())
    rng = np.random.default_rng(saat)
    summe = np.zeros(n_null)
    for e in evs:
        nv = null_werte(e)
        summe += nv[rng.integers(0, len(nv), size=n_null)]
    Tn = summe / n
    p = float((1 + np.sum(Tn >= T - 1e-15)) / (1 + n_null))
    monate = sorted({e["monat"] for e in evs}); mi = {m: i for i, m in enumerate(monate)}
    mx = np.zeros(len(monate)); mn = np.zeros(len(monate))
    for e, xe in zip(evs, x):
        mx[mi[e["monat"]]] += xe; mn[mi[e["monat"]]] += 1
    rb = np.random.default_rng(saat + 1)
    zug = rb.integers(0, len(monate), size=(n_boot, len(monate)))
    Tb = mx[zug].sum(axis=1) / np.maximum(mn[zug].sum(axis=1), 1)
    lo, hi = np.quantile(Tb, [0.05, 0.95])
    h = n // 2
    jahre = {}
    for e, xe in zip(evs, x):
        jahre.setdefault(e["tag"].year, []).append(xe)
    return {"n": n, "T": T, "faktor": math.exp(T), "lo": math.exp(lo), "hi": math.exp(hi), "p": p,
            "h1": float(x[:h].mean()), "h2": float(x[h:].mean()), "mitte": evs[h]["tag"].isoformat(),
            "von": evs[0]["tag"].isoformat(), "bis": evs[-1]["tag"].isoformat(),
            "jahre": {str(j): {"n": len(v), "faktor": math.exp(float(np.mean(v)))} for j, v in sorted(jahre.items())}}


# ================================================================================================ Daten (nur lesend)

def termine_laden(db: str) -> dict:
    """{Reihe: [date, …]} aus makro.db (mk_meta release:<Reihe> -> Nummer, mk_termin -> Tage); nur vergangene Tage."""
    import hl_makro as MK
    pfad = MK.makro_pfad(db)
    out = {"fehlt": None, "termine": {}, "erst": {}}
    if not os.path.exists(pfad):
        out["fehlt"] = "makro.db fehlt"; return out
    con = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)
    try:
        heute = datetime.now(UTC).date()
        for sid in ALLE_TERMINE:
            z = con.execute("SELECT v FROM mk_meta WHERE k=?", (f"release:{sid}",)).fetchone()
            try:
                rid = int(json.loads(z[0]).get("id")) if z else None
            except (ValueError, TypeError):
                rid = None
            if rid is None:
                continue
            try:
                tage = [_tag(t) for (t,) in con.execute("SELECT tag FROM mk_termin WHERE release=? ORDER BY tag", (rid,))]
            except sqlite3.Error:
                tage = []
            out["termine"][sid] = [d for d in tage if d < heute]
            try:                                                     # Gegenprobe: Tage der Erstveröffentlichung (ALFRED)
                out["erst"][sid] = sorted({_tag(int(a)) for (a,) in con.execute(
                    "SELECT abgerufen FROM mk_fassung WHERE reihe=? AND art='erst'", (f"fred:{sid}",))})
            except sqlite3.Error:
                out["erst"][sid] = []
    finally:
        con.close()
    if not out["termine"]:
        out["fehlt"] = "noch keine Termine in makro.db (der Makro-Takt holt sie einmal am Tag mit dem FRED-Schlüssel, U153)"
    return out


def studie(db: str, n_null: int = N_NULL, n_boot: int = N_BOOT, jetzt: float | None = None) -> dict:
    import hl_aktien as AK
    t0 = time.time()
    TD = termine_laden(db)
    out = {"version": VERSION_MODUL, "erzeugt": int(time.time()), "fehlt": TD["fehlt"]}
    if TD["fehlt"]:
        return out
    K = {k: AK.kerzen_30m(db, k) for k in COINS}
    if any(v is None for v in K.values()):
        out["fehlt"] = "keine 30-min-Kerzen für BTC oder ETH (swing.db)"; return out
    von = date.fromisoformat(AB)
    letzt = min(int(v["ts"][-1]) for v in K.values())
    bis = _tag(letzt - TAG)                                             # letzter Tag mit sicher vollständigem Fenster
    kand = werktage(von, bis, AK.handelstag)
    termin_tage = {sid: [d for d in v if von <= d <= bis] for sid, v in TD["termine"].items()}
    alle = {d for v in termin_tage.values() for d in v}
    tage = sorted(set(kand) | alle)
    L = {}; Ltag = {}; R = {}
    for k, v in K.items():
        rv, re = fenster_rv(v["ts"], v["c"], tage)
        L[k] = {d: math.log(x + EPS) for d, x in zip(tage, rv) if np.isfinite(x)}
        R[k] = {d: abs(y) for d, y in zip(tage, re) if np.isfinite(y)}
        rt = tag_rv(v["ts"], v["c"], tage)
        Ltag[k] = {d: math.log(x + EPS) for d, x in zip(tage, rt) if np.isfinite(x)}
    out.update(von=von.isoformat(), bis=bis.isoformat(), n_werktage=len(kand), n_termine={s: len(v) for s, v in termin_tage.items()})
    erg = {}
    for key, sid, name in HYPOTHESEN:
        evs = ereignisse_bauen(termin_tage.get(sid, []), alle, kand, L)
        erg[key] = dict(auswerten(evs, n_null, n_boot), name=name, reihe=sid)
    ps = [erg[k].get("p", 1.0) for k, _, _ in HYPOTHESEN]
    for (k, _, _), ph in zip(HYPOTHESEN, holm(ps)):
        e = erg[k]; e["p_holm"] = ph if "p" in e else None
        e["belegt"] = urteil(e["p_holm"], e)
    out["hypothesen"] = erg
    # beschreibend
    besch = {}
    for sid, name in tuple((s, n) for _, s, n in HYPOTHESEN) + BESCHREIBEND:
        evs = ereignisse_bauen(termin_tage.get(sid, []), alle, kand, L)
        b = {"name": name}
        if len(evs) >= 10:
            for k in COINS:
                xs = [float(e["le"][list(L).index(k)] - e["lc"][:, list(L).index(k)].mean()) for e in evs]
                b[k] = math.exp(float(np.mean(xs)))
            a = auswerten(evs, n_null=2000, n_boot=500) if sid not in HYP_REIHEN else None
            b["faktor"] = math.exp(float(np.mean([x_wert(e) for e in evs]))); b["n"] = len(evs)
            if a:
                b["p_roh"] = a["p"]
            evd = ereignisse_bauen(termin_tage.get(sid, []), alle, kand, Ltag)
            b["tag_faktor"] = math.exp(float(np.mean([x_wert(e) for e in evd]))) if len(evd) >= 10 else None
            # mittlere absolute Fensterrendite gegen die Vergleichstage (Richtung nicht geprüft)
            ra = []
            for e in evs:
                C = [d for d in kand if (d.year, d.month) == e["monat"] and d not in alle and all(d in R[k] for k in COINS)]
                if all(e["tag"] in R[k] for k in COINS) and len(C) >= MIN_VERGLEICH:
                    ra.append((np.mean([R[k][e["tag"]] for k in COINS]), np.mean([np.mean([R[k][c] for c in C]) for k in COINS])))
            b["abs_verh"] = float(np.mean([a_ for a_, _ in ra]) / np.mean([c_ for _, c_ in ra])) if ra else None
        else:
            b["n"] = len(evs)
        besch[sid] = b
    out["beschreibend"] = besch
    # Gegenprobe: Tag der Erstveröffentlichung (ALFRED) gegen den Kalender der Veröffentlichung
    gp = {}
    for sid in HYP_REIHEN:
        er = {d for d in TD["erst"].get(sid, []) if von <= d <= bis}; kal = set(termin_tage.get(sid, []))
        gp[sid] = {"erst": len(er), "kalender": len(kal), "nur_erst": len(er - kal), "nur_kalender": len(kal - er) if er else None}
    out["gegenprobe"] = gp
    out["dauer"] = time.time() - t0
    return out


def text(E: dict) -> str:
    Z = []; a = Z.append
    a(f"★ Datentage: Schwankung an US-Terminen (U154) · Modul {VERSION_MODUL} · {time.strftime('%d.%m.%Y %H:%M')}")
    a("Vorab festgelegt (KONZEPT_Makro.md 11.7, 13.10.2026). Fenster 8:30–10:30 New York (vier 30-min-Renditen); Vergleich: Werktage "
      "desselben Monats ohne Termin. Nur Schwankung, nicht Richtung. Wirkt auf nichts.")
    if E.get("fehlt"):
        a(f"fehlt: {E['fehlt']}"); return "\n".join(Z)
    a(f"Daten: BTC und ETH (swing.db) {E['von']} bis {E['bis']}, {E['n_werktage']} Werktage; Termine: "
      + ", ".join(f"{s} {n}" for s, n in E["n_termine"].items()))
    a("")
    a("URTEILE (Holm über H1/H2, beide Hälften)")
    for k, e in E["hypothesen"].items():
        if e.get("grund"):
            a(f"  {k} {e['name']}: {e['grund']} (n {e['n']})"); continue
        a(f"  {k} {e['name']}: n {e['n']} Termine ({e['von']}–{e['bis']}) · Faktor der Varianz {_de(e['faktor'])} (90 %: {_de(e['lo'])}–"
          f"{_de(e['hi'])}) · p {_de(e['p'], 4)} · p Holm {_de(e['p_holm'], 4)} · Hälften {_de(math.exp(e['h1']))} / {_de(math.exp(e['h2']))} "
          f"(Teilung {e['mitte']}) -> {'belegt' if e['belegt'] else 'nicht belegt'}")
        a("     je Jahr: " + " · ".join(f"{j} {_de(v['faktor'])} (n {v['n']})" for j, v in e["jahre"].items()))
    a("")
    a("BESCHREIBEND (ohne Urteil): Faktor je Coin, ganzer UTC-Tag, mittlere absolute Fensterrendite gegen die Vergleichstage")
    for sid, b in E["beschreibend"].items():
        if b.get("n", 0) < 10:
            a(f"  {b['name']}: zu wenige Termine ({b.get('n', 0)})"); continue
        a(f"  {b['name']:<20} n {b['n']:>3} · Fenster {_de(b['faktor'])} (BTC {_de(b.get('BTC'))}, ETH {_de(b.get('ETH'))}) · ganzer Tag "
          f"{_de(b.get('tag_faktor'))} · |Rendite| {_de(b.get('abs_verh'))}×" + (f" · p roh {_de(b['p_roh'], 4)}" if b.get("p_roh") is not None else ""))
    a("")
    a("GEGENPROBE: Tag der Erstveröffentlichung (ALFRED) gegen den Kalender der Veröffentlichung (erwartet: keine Abweichung)")
    for sid, g in E["gegenprobe"].items():
        a(f"  {sid}: ALFRED {g['erst']} Tage, Kalender {g['kalender']} Tage; nur in ALFRED {g['nur_erst']}, nur im Kalender "
          f"{g['nur_kalender'] if g['nur_kalender'] is not None else '— (ALFRED noch nicht geladen)'}")
    a("")
    a("Erwartung vorab: H1 belegt mit Faktor 1,5–3, H2 belegt mit Faktor 1,3–2; seit 2024 kleiner; über den ganzen Tag kleiner.")
    a("Folge: belegt -> der Nutzer entscheidet, ob Ausblick (Breite) oder Strukturgleichung (U116) die Termine nutzen; jede Nutzung "
      "muss außerhalb der Stichprobe gegen das bestehende HAR gewinnen. Nicht belegt -> die Termine bleiben Anzeige.")
    a(f"Rechenzeit {E.get('dauer', 0):.1f} s")
    return "\n".join(Z)


# ================================================================================================ Selbsttest (synthetisch)

def _markt(seed: int, von: date, bis: date, termine: list, faktor: float, handelstag_fn) -> dict:
    """Synthetische 30-min-Kerzen für BTC und ETH: Tagesprofil (US-Stunden lebhafter), Schwankungsballung über Tage (AR(1) in
    log σ), t-Ränder (ν = 4, auf Varianz 1 normiert), Gleichlauf der Coins 0,7; an den Terminen Varianz × faktor im Fenster."""
    rng = np.random.default_rng(seed)
    t0 = _tag_ts(von) - BAR; t1 = _tag_ts(bis) + TAG
    ts = np.arange(t0, t1, BAR, dtype=np.int64); n = len(ts)
    stunde = ((ts % TAG) / 3600.0)
    profil = 1.0 + 0.6 * np.exp(-0.5 * ((stunde - 15.0) / 2.5) ** 2)               # Buckel um 15 UTC
    tag_i = (ts - ts[0]) // TAG
    nd = int(tag_i.max()) + 1
    ls = np.zeros(nd)
    for i in range(1, nd):
        ls[i] = 0.97 * ls[i - 1] + rng.normal(0, 0.12)
    sig = 0.004 * np.exp(ls[tag_i]) * profil
    nu = 4.0
    z1 = rng.standard_t(nu, n) / math.sqrt(nu / (nu - 2)); z2 = rng.standard_t(nu, n) / math.sqrt(nu / (nu - 2))
    m = np.ones(n)
    for d in termine:
        a = np.searchsorted(ts, _ny830(d))
        for k in range(4):
            if a + k < n and ts[a + k] == _ny830(d) + k * BAR:
                m[a + k] = math.sqrt(faktor)
    r1 = sig * m * z1; r2 = sig * m * (0.7 * z1 + math.sqrt(1 - 0.49) * z2)
    return {"BTC": {"ts": ts, "c": 50000.0 * np.exp(np.cumsum(r1))}, "ETH": {"ts": ts, "c": 3000.0 * np.exp(np.cumsum(r2))}}


def _synth_termine(seed: int, kand: list) -> list:
    rng = np.random.default_rng(seed + 999)
    je = {}
    for d in kand:
        je.setdefault((d.year, d.month), []).append(d)
    out = []
    for m_, tage in sorted(je.items()):
        out += [tage[i] for i in sorted(rng.choice(len(tage), size=2, replace=False))]
    return out


def _lauf_synth(K: dict, termine: list, kand: list, n_null: int) -> dict:
    tage = sorted(set(kand) | set(termine))
    L = {}
    for k, v in K.items():
        rv, _ = fenster_rv(v["ts"], v["c"], tage)
        L[k] = {d: math.log(x + EPS) for d, x in zip(tage, rv) if np.isfinite(x)}
    evs = ereignisse_bauen(termine, set(termine), kand, L)
    e = auswerten(evs, n_null=n_null, n_boot=200)
    e["belegt"] = urteil(e.get("p"), e)                                # eine Hypothese: Holm = p
    return e


def selbsttest(verbose: bool = True, schnell: bool = False) -> bool:
    import tempfile
    import shutil
    import hl_aktien as AK
    ok_all = [True]; t_start = time.time()

    def ok(name, bed, detail=""):
        ok_all[0] &= bool(bed)
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name}" + (f" — {detail}" if detail else ""), flush=True)

    if verbose:
        print("Datentage (U154) -- Selbsttest: Fenster von Hand, Vergleichstage, Null, Holm, Positivkontrolle, Nullprobe, Ende zu Ende", flush=True)
    # 1) Fenster von Hand, Sommer- und Winterzeit, fehlende Kerze
    d_s, d_w = date(2026, 7, 15), date(2026, 12, 10)
    t_s = _ny830(d_s); t_w = _ny830(d_w)
    ts = np.array([t_s - BAR + k * BAR for k in range(5)] + [t_w - BAR + k * BAR for k in range(4)], dtype=np.int64)
    c = np.array([100, 101, 99, 100, 102, 50, 51, 52, 53], dtype=float)
    rv, re = fenster_rv(ts, c, [d_s, d_w])
    hand = sum(math.log(b / a) ** 2 for a, b in zip([100, 101, 99, 100], [101, 99, 100, 102]))
    ok("Fenster von Hand: vier Renditen ab 8:30 New York (Juli 12:30 UTC, Dezember 13:30 UTC), Fensterrendite; fehlt eine der fünf "
       "Kerzen, NaN", abs(rv[0] - hand) < 1e-15 and abs(re[0] - math.log(102 / 100)) < 1e-15 and not np.isfinite(rv[1])
       and t_s % TAG == 12 * 3600 + 1800 and t_w % TAG == 13 * 3600 + 1800, f"{rv} {hand}")
    # 2) Vergleichstage: ohne Termine, ohne Feiertage, mindestens 5; x und Null von Hand
    kand = werktage(date(2026, 11, 1), date(2026, 11, 30), AK.handelstag)
    L = {"BTC": {d: float(i) for i, d in enumerate(kand)}, "ETH": {d: float(2 * i) for i, d in enumerate(kand)}}
    term = [date(2026, 11, 13)]; alle = {date(2026, 11, 13), date(2026, 11, 6), date(2026, 11, 19)}
    evs = ereignisse_bauen(term, alle, kand, L)
    C = [d for d in kand if d not in alle]
    ok_v = (len(evs) == 1 and date(2026, 11, 26) not in kand and len(evs[0]["lc"]) == len(C)
            and abs(x_wert(evs[0]) - np.mean([L["BTC"][date(2026, 11, 13)] - np.mean([L["BTC"][c_] for c_ in C]),
                                               L["ETH"][date(2026, 11, 13)] - np.mean([L["ETH"][c_] for c_ in C])])) < 1e-12)
    nv = null_werte(evs[0]); c0 = 0
    hand0 = np.mean([evs[0]["lc"][c0, j] - (evs[0]["lc"][:, j].sum() - evs[0]["lc"][c0, j]) / (len(C) - 1) for j in range(2)])
    zu_wenig = ereignisse_bauen(term, alle, kand[:5], L)               # 2.–6.11. ohne den 6.: nur 4 Vergleichstage
    ok("Vergleichstage: Werktage des Monats ohne die vier Termine und ohne NYSE-Feiertag (Thanksgiving), x und Null-Werte von Hand, "
       "unter 5 Vergleichstagen fällt der Termin weg", ok_v and abs(nv[c0] - hand0) < 1e-12 and zu_wenig == [], f"{len(C)} Vergleichstage")
    ok("Holm von Hand (0,01/0,04 -> 0,02/0,04; 0,03/0,02 -> 0,04/0,04)", holm([0.01, 0.04]) == [0.02, 0.04] and holm([0.03, 0.02]) == [0.04, 0.04])
    ur = [urteil(0.02, {"h1": 0.1, "h2": 0.2}), urteil(0.02, {"h1": 0.1, "h2": -0.01}), urteil(0.02, {"h1": -0.1, "h2": 0.3}),
          urteil(0.06, {"h1": 0.1, "h2": 0.2}), urteil(None, {"h1": 0.1, "h2": 0.2}), urteil(0.0499, {"h1": 1e-9, "h2": 1e-9})]
    ok("Urteil wie vorab: p Holm < 0,05 und T > 0 in beiden Hälften (eine negative Hälfte, p 0,06 oder kein p -> nicht belegt)",
       ur == [True, False, False, False, False, True], str(ur))
    # Hälften zeitlich: die ersten zehn Termine x = −1, die letzten zehn x = +3 (Vergleichstage null) -> T 1, Hälften −1 und 3, nicht belegt
    ev_h = [{"tag": date(2021 + i // 12, i % 12 + 1, 10), "monat": (2021 + i // 12, i % 12 + 1),
             "le": np.full(2, -1.0 if i < 10 else 3.0), "lc": np.zeros((6, 2))} for i in range(20)]
    ah = auswerten(ev_h, n_null=500, n_boot=200)
    ok("Hälften von Hand: erste zehn Termine −1, letzte zehn +3 -> T 1, Hälften −1/3 (Teilung am elften), Urteil nicht belegt",
       abs(ah["T"] - 1.0) < 1e-12 and abs(ah["h1"] + 1.0) < 1e-12 and abs(ah["h2"] - 3.0) < 1e-12 and ah["mitte"] == "2021-11-10"
       and not urteil(ah["p"], ah), f"T {ah['T']:.3f}, Hälften {ah['h1']:.1f}/{ah['h2']:.1f}, p {ah['p']:.4f}")
    # 3) Null ohne Effekt: gleichverteilte p; Positivkontrolle und Nachweisgrenze auf synthetischen Märkten
    von, bis = date(2020, 1, 1), date(2026, 9, 30)
    kand = werktage(von, bis, AK.handelstag)
    n_m = 12 if schnell else 40
    faktoren = (1.0, 1.5) if schnell else (1.0, 1.2, 1.3, 1.5, 2.0)
    quote = {f: 0 for f in faktoren}; faktor_mittel = {f: [] for f in faktoren}; deckt = 0
    for s in range(n_m):
        termine = _synth_termine(s, kand)
        for f in faktoren:
            K = _markt(1000 + s, von, bis, termine, f, AK.handelstag)
            e = _lauf_synth(K, termine, kand, 2000)
            quote[f] += int(e["belegt"]); faktor_mittel[f].append(e.get("faktor", float("nan")))
            deckt += int(e.get("lo", math.inf) <= f <= e.get("hi", -math.inf))
    q15, q0 = quote[1.5] / n_m, quote[1.0]
    ok(f"Positivkontrolle: eingepflanzter Faktor 1,5 im Fenster „belegt“ in mindestens 80 % von {n_m} Märkten; Faktor getroffen",
       q15 >= 0.8 and abs(float(np.median(faktor_mittel[1.5])) - 1.5) < 0.15,
       f"{quote[1.5]} von {n_m}, Median Faktor {float(np.median(faktor_mittel[1.5])):.3f}")
    ok(f"Nullprobe: ohne Effekt „belegt“ in höchstens 10 % von {n_m} Märkten (Soll 5 %)", q0 <= 0.1 * n_m,
       f"{q0} von {n_m}, Median Faktor {float(np.median(faktor_mittel[1.0])):.3f}")
    n_dk = n_m * len(faktoren)
    ok(f"Intervall: das 90-%-Intervall (Blockbootstrap über Monate) enthält den eingepflanzten Faktor in mindestens "
       f"{'80' if not schnell else '70'} % von {n_dk} Läufen (Soll 90 %)", deckt >= (0.8 if not schnell else 0.7) * n_dk,
       f"{deckt} von {n_dk} ({deckt / n_dk * 100:.0f} %)")
    if verbose and not schnell:
        print("     Nachweisgrenze: " + " · ".join(f"Faktor {_de(f, 1)}: {quote[f]} von {n_m}" for f in faktoren), flush=True)
    # 4) Ende zu Ende auf Demo-Datenbanken (swing.db, makro.db mit Terminen)
    tmp = tempfile.mkdtemp(prefix="dt_test_")
    alt = {k: os.environ.get(k) for k in ("HL_SWING_DB", "HL_MAKRO_DB")}
    try:
        db = os.path.join(tmp, "hl_liq.db")
        os.environ["HL_SWING_DB"] = os.path.join(tmp, "swing.db"); os.environ["HL_MAKRO_DB"] = os.path.join(tmp, "makro.db")
        import hl_makro as MK
        import hl_swing as SW
        cpi = _synth_termine(7, kand); es = _synth_termine(8, kand)
        es = [d for d in es if d not in set(cpi)]
        K = _markt(77, von, bis, cpi, 2.0, AK.handelstag)
        sc = SW.verbinden(os.environ["HL_SWING_DB"])
        for k in COINS:
            sc.execute("BEGIN IMMEDIATE")
            sc.executemany("INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)",
                           [(k, int(t), float(x), float(x), float(x), float(x), 1.0) for t, x in zip(K[k]["ts"], K[k]["c"])])
            sc.execute("COMMIT")
        sc.close()
        mc = MK.verbinden(os.environ["HL_MAKRO_DB"])
        for sid, rid, tage_ in (("CPIAUCSL", 10, cpi), ("UNRATE", 50, es), ("PPIFIS", 46, []), ("ICSA", 180, [])):
            MK._meta_setzen(mc, {f"release:{sid}": json.dumps({"id": rid, "name": f"R{rid}"})})
            if tage_:
                MK.termine_schreiben(mc, rid, [_tag_ts(d) for d in tage_], int(time.time()))
        extra = next(d for d in kand if d not in set(cpi) and d not in set(es))       # eingepflanzt: ein Tag nur in ALFRED
        MK.erst_schreiben(mc, [("fred:CPIAUCSL", _tag_ts(d) - 40 * TAG, _ny830(d), 300.0) for d in cpi + [extra]])
        mc.close()
        E = studie(db, n_null=2000, n_boot=300)
        T = text(E)
        h1, h2 = (E.get("hypothesen") or {}).get("H1", {}), (E.get("hypothesen") or {}).get("H2", {})
        gp = (E.get("gegenprobe") or {}).get("CPIAUCSL", {})
        hp = holm([h1.get("p", 1.0), h2.get("p", 1.0)])
        ok("Ende zu Ende: H1 (eingepflanzt, Faktor 2) belegt, H2 (ohne Effekt) nicht; p nach Holm über beide; Gegenprobe ALFRED findet "
           "den eingepflanzten Tag (nur in ALFRED 1, nur im Kalender 0); Text vollständig",
           h1.get("belegt") and not h2.get("belegt") and abs(h1.get("faktor", 0) - 2.0) < 0.35 and gp.get("nur_erst") == 1
           and gp.get("nur_kalender") == 0 and h1.get("p_holm") == hp[0] and h2.get("p_holm") == hp[1] and h1["p_holm"] > h1["p"]
           and "URTEILE" in T and "GEGENPROBE" in T and "Erwartung vorab" in T,
           f"H1 {_de(h1.get('faktor'))} p {_de(h1.get('p'), 4)} Holm {_de(h1.get('p_holm'), 4)} · H2 {_de(h2.get('faktor'))} p {_de(h2.get('p'), 4)} · {gp}")
        os.environ["HL_MAKRO_DB"] = os.path.join(tmp, "leer.db")
        E0 = studie(db, n_null=200, n_boot=50)
        ok("Ohne makro.db: Hinweis statt Fehler, nichts angelegt", bool(E0.get("fehlt")) and not os.path.exists(os.path.join(tmp, "leer.db")),
           str(E0.get("fehlt")))
    finally:
        for k, v in alt.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)
    if verbose:
        print(f"  Ergebnis: {'bestanden' if ok_all[0] else 'NICHT bestanden'} ({time.time() - t_start:.0f} s)", flush=True)
    return ok_all[0]


if __name__ == "__main__":
    if "--selbsttest" in sys.argv:
        sys.exit(0 if selbsttest(schnell="--schnell" in sys.argv) else 1)
    if "--studie" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        print(text(studie(_db)))
        sys.exit(0)
    print(__doc__)
