#!/usr/bin/env python3
"""
hl_staking.py -- Unstaking bei Ethereum: wann wird gestaktes ETH frei? (U254, KONZEPT_Unstaking.md; Paket 23.100)

Anlass (Nutzer, 14.11.2026): „wenn sehr große Mengen Ethereum vom Staking abgerufen werden, [kommt] es häufig zu signifikanten
Kursrückgängen … erstelle einen Indikator in den Cockpit hinein, welcher einen Termin nennt, wann größere Mengen unstaked werden.“

Was das Modul tut -- nur lesen, nur messen:
  1. Beacon-Knoten (Standard-API der Ethereum-Konsensschicht, ohne Schlüssel): alle angemeldeten Vollabzüge (Status active_exiting
     und exited_unslashed) mit dem Zeitpunkt, den die Kette ihnen fest zugeteilt hat; dazu die angemeldeten Teilabzüge
     (pending_partial_withdrawals). Abgezogen werden die Zusammenlegungen (pending_consolidations): Ihre Quelle sieht in der Liste
     aus wie ein Abzug, das ETH bleibt aber gestakt.
  2. Tagesdatei von validatorqueue.com (GitHub, ohne Schlüssel): Warteschlangen je Tag seit Mai 2023 -- Rückblick, Gegenseite
     (ETH, das gestakt werden soll) und Ersatz, wenn der Knoten nicht antwortet.
  3. Daraus: Kalender „frei ab“ je UTC-Tag, „alles Angemeldete frei bis“, die nächste große Freigabe, die größten Abzieher.

Begriffe: „frei ab“ = Epoche, ab der die Kette das ETH auszahlen darf (withdrawable_epoch = Austritt + 256 Epochen, rund 27 h).
Teilabzüge werden dann sofort ausgezahlt, Vollabzüge mit dem Auszahlungslauf (16 je Block über alle Validatoren, derzeit knapp 7 Tage
für eine Runde). Das Protokoll lässt je Epoche höchstens 256 ETH aus dem Staking -- 57.600 ETH am Tag.

Das Modul urteilt nicht. Ob auf große Abzüge Kursrückgänge folgen, prüft seit 23.101 hl_staking_studie.py nach vorab festgelegten
Regeln (U255, KONZEPT_Unstaking.md 6); sein Urteil liegt in dieser staking.db (st_meta „studie_u255“) und wird hier nur genannt.
23.106 (U259): Die zweite Prüfung (U255/2, KONZEPT_Unstaking.md 6c) misst neue Wellen in der eigenen Tagesreihe -- an den angemeldeten
Abzügen (angemeldet_eth) und nur an Tagen, deren Messung vor 03:00 UTC liegt (tageswert_gueltig). Damit ein Tag nicht an einem
misslungenen Abruf um Mitternacht scheitert, holt der Dienst ihn bis 03:00 UTC alle 5 Minuten nach (nachholen_faellig).
Eigene Datei staking.db neben der Hauptdatenbank; wirkt auf nichts anderes; importiert kein Projektmodul.

Aufruf:  hl_staking.py --stand [--db hl_liq.db] [--ohne-abruf]     Text für Debug 145
         hl_staking.py --selbsttest                                 ohne Netz
"""
import argparse
import calendar
import json
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from contextlib import contextmanager

VERSION_MODUL = "2026-09-23.106"
NAME = "Unstaking (U254)"
TAG = 86_400
WOCHENTAGE = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")

# ---- Protokoll (Konsens-Spezifikation Electra; geprüft 14.11.2026, Quellen in KONZEPT_Unstaking.md 2)
GENESIS = 1_606_824_023                       # Beginn der Beacon-Chain (01.12.2020 12:00:23 UTC) -- nur zur Prüfung, ob der Knoten mitkommt
SLOT_S = 12
SLOTS_EPOCHE = 32
EPOCHE_S = SLOT_S * SLOTS_EPOCHE              # 384 s
SPERR_EPOCHEN = 256                           # MIN_VALIDATOR_WITHDRAWABILITY_DELAY
SPERR_S = SPERR_EPOCHEN * EPOCHE_S            # 98.304 s, rund 27,3 h
CHURN_ETH = 256                               # MAX_PER_EPOCH_ACTIVATION_EXIT_CHURN_LIMIT, in ETH je Epoche
DURCHSATZ_TAG = CHURN_ETH * TAG // EPOCHE_S   # 57.600 ETH je Tag
AUSZAHLUNGEN_JE_SLOT = 16                     # MAX_WITHDRAWALS_PER_PAYLOAD
FERN = 2 ** 63                                # darüber: FAR_FUTURE_EPOCH (kein Zeitpunkt vergeben)
GWEI = 1_000_000_000

# ---- Schwellen, fest und vorab (KONZEPT_Unstaking.md 4)
GROSS_TAG_ETH = DURCHSATZ_TAG // 2            # 28.800 ETH: ab der Hälfte des Höchstdurchsatzes zählt ein Tag zur „großen Freigabe“
GROSS_ADRESSE_ETH = 10_000                    # ab hier wird ein einzelner Abzieher genannt
KALENDER_TAGE = 60
ADRESSEN_MAX = 10

# ---- Quellen und Takt
KNOTEN_STANDARD = ("https://ethereum-beacon-api.publicnode.com",)
TAGESDATEI_URL = "https://raw.githubusercontent.com/etheralpha/validatorqueue-com/main/historical_data.json"
UA = "hl-dashboard/1.0 (staking)"
TAKT_S = 3600                                 # Knoten: einmal je Stunde (die Schlange bewegt sich um höchstens 2.400 ETH je Stunde)
TAGESDATEI_TAKT_S = 6 * 3600
TAGESBEGINN_NACH_S = 120                      # 23.102: so bald nach Mitternacht UTC fragt der Dienst den Knoten außer der Reihe -- die eigene
                                              # Tagesreihe hält die erste Messung des Tages fest, und die soll am Tagesbeginn liegen
TAGESWERT_BIS_S = 3 * 3600                    # 23.106 (U259): eine Zeile der Tagesreihe gilt als „zu Tagesbeginn gemessen“, wenn ihre Messung
                                              # vor 03:00 UTC liegt. Nur solche Tage zählt die zweite Prüfung (U255/2): Der Zuwachs gegen den
                                              # Vortag muss zu Beginn des Falltags bekannt sein, sonst sähe die Prüfung in die Zukunft.
NACHHOLEN_S = 300                             # 23.106: fehlt die Zeile des Tages noch, fragt der Dienst in diesem Fenster alle 5 Minuten
WELLE_AB_ETH = 57_600                         # Schwelle der Welle in der Prüfung der Kursfolge (U255): Zuwachs gegen den Vortag. Fest --
                                              # sie bleibt, auch wenn die Kette ihr Tageskontingent ändert (EIP-8061, KONZEPT_Unstaking 6c).
FRISCH_KNOTEN_S = 3 * 3600                    # älter: der Stand des Knotens gilt nicht mehr
FRISCH_TAGESDATEI_TAGE = 2                    # die Tagesdatei darf als Ersatz (und für die Gegenseite) höchstens so viele Tage zurückliegen
LAUF_TAGE_FRISCH = 120                        # die Zahl der Validatoren (Dauer des Auszahlungslaufs) ändert sich langsam. Bis 23.101: 30
                                              # Tage. Seit 23.102: 120 -- die Tagesdatei endet am 25.10.2026, die Angabe fiele sonst am
                                              # 24.11.2026 weg; Karte und Bericht nennen dafür den Tag, von dem die Zahl stammt.
ABBAU_GRENZE_ETH = DURCHSATZ_TAG * 105 // 100 # 60.480 ETH: fällt die Schlange der Tagesdatei an einem Tag stärker, reichen Abzüge allein nicht
ABBAU_AB_TAG = "2025-05-22"                   # erster verlässlicher Tag nach Pectra (davor galt ein Kontingent in Validatoren, nicht in ETH)
SLOT_TOLERANZ = 150                           # der Knoten darf höchstens 30 min hinter der Uhr liegen
MAX_BYTES = 300_000_000
ZEIT_MAX_S = 240.0                            # eine einzelne Antwort
GESAMT_MAX_S = 150.0                          # ein ganzer Abruf am Knoten (alle Fragen zusammen) -- ein Debug-Lauf soll nicht hängen
TAGESDATEI_MAX_S = 60.0
REST_MAX = 2_000_000
LAUF_BEHALTEN_TAGE = 400
ABRUF_FRISCH_S = 600                          # Debug 145 ruft selbst ab, wenn der letzte Abruf älter ist
SICHERUNG_NAME = "staking_backup.db"          # 23.103 (U257): so heißt die Kopie im Backup-Ordner des Recorders (hl_recorder.BACKUP_NEBEN)
SICHERUNG_ALT_S = 2 * TAG                     # das Backup läuft täglich; ist der letzte Lauf älter, sagt Debug 145 das
TAGESDATEI_UNSICHER = ("2025-05-07", "2025-05-21")   # laut Quelle in dieser Zeit Validatoren statt ETH (Fehler nach Pectra)

SCHEMA = (
    "CREATE TABLE IF NOT EXISTS st_meta (schluessel TEXT PRIMARY KEY, wert TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS st_lauf (ts INTEGER NOT NULL, quelle TEXT NOT NULL, ok INTEGER NOT NULL, dauer_ms INTEGER, bytes INTEGER, "
    "voll_eth REAL, teil_eth REAL, konsol_eth REAL, ende_ts INTEGER, fehler TEXT, PRIMARY KEY (ts, quelle))",
    "CREATE TABLE IF NOT EXISTS st_tag (tag TEXT PRIMARY KEY, ts INTEGER NOT NULL, exit_eth REAL, exit_tage REAL, eintritt_eth REAL, "
    "eintritt_tage REAL, validatoren REAL, gestakt_eth REAL, umlauf_eth REAL, apr REAL)",
    # 23.102: eigene Tagesreihe -- je UTC-Tag der erste Stand des Knotens. Anlass: Die Tagesdatei der Quelle endet am 25.10.2026
    # (Debug 145 vom 15.11.2026); ohne eigene Reihe hinge jeder Rückblick an einer fremden Datei, die nicht mehr fortgeschrieben wird.
    "CREATE TABLE IF NOT EXISTS st_tag_knoten (tag TEXT PRIMARY KEY, ts INTEGER NOT NULL, schlange_eth REAL, schlange_tage REAL, "
    "sperr_eth REAL, teil_eth REAL, konsol_eth REAL, frei_bis_ts INTEGER)",
)


class AbrufFehler(Exception):
    pass


# ================================================================================================ kleine Helfer

def _zahl(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if v == v and abs(v) != float("inf") else None


def _de(x, nd: int = 0) -> str:
    if x is None:
        return "—"
    s = f"{abs(x):,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("−" if x < 0 and float(s.replace(".", "").replace(",", ".")) != 0 else "") + s


def _datum(ts) -> str:
    if ts is None:
        return "—"
    t = time.gmtime(int(ts))
    return f"{t.tm_mday:02d}.{t.tm_mon:02d}. {t.tm_hour:02d}:{t.tm_min:02d} UTC"


def _tag(ts) -> str:
    t = time.gmtime(int(ts))
    return f"{WOCHENTAGE[t.tm_wday]} {t.tm_mday:02d}.{t.tm_mon:02d}."


def _groesse(n) -> str:
    n = int(n or 0)
    return f"{_de(n / 1e6, 1)} MB" if n >= 1_000_000 else f"{_de(n / 1e3, 1)} kB"


def tag_beginn(ts: int) -> int:
    return int(ts) // TAG * TAG


def epoche_ts(epoche: int, kopf_slot: int, kopf_ts: int, slot_s: int = SLOT_S, slots: int = SLOTS_EPOCHE) -> int:
    """Zeitpunkt einer Epoche, gerechnet vom Kopf der Kette aus (Slot des Kopfes = jetzt)."""
    return int(kopf_ts + (int(epoche) * slots - int(kopf_slot)) * slot_s)


def slot_soll(ts: int) -> int:
    return (int(ts) - GENESIS) // SLOT_S


def adresse(cred: str) -> str | None:
    """Auszahlungsadresse aus den withdrawal_credentials: 0x01… und 0x02… tragen sie in den letzten 20 Bytes; 0x00… (BLS) hat keine."""
    c = (cred or "").lower()
    if len(c) == 66 and c[:4] in ("0x01", "0x02") and re.fullmatch(r"[0-9a-f]{64}", c[2:]):
        return "0x" + c[-40:]
    return None


def adresse_kurz(a: str | None) -> str:
    return "ohne Adresse" if not a else a[:6] + "…" + a[-4:]


# ================================================================================================ Antworten lesen

def kopf_slot_lesen(o) -> int:
    """/eth/v1/beacon/headers/head -> Slot des Kopfes."""
    try:
        return int(o["data"]["header"]["message"]["slot"])
    except (KeyError, TypeError, ValueError):
        raise AbrufFehler("Kopf der Kette: Slot nicht gefunden") from None


def konsolidierungen_lesen(o) -> set:
    """/eth/v1/beacon/states/…/pending_consolidations -> Indizes der Quell-Validatoren (ihr ETH bleibt gestakt)."""
    if not isinstance(o, dict) or not isinstance(o.get("data"), list):
        raise AbrufFehler("Zusammenlegungen: keine Liste")
    out = set()
    for e in o["data"]:
        try:
            out.add(int(e["source_index"]))
        except (KeyError, TypeError, ValueError):
            raise AbrufFehler("Zusammenlegungen: Eintrag ohne source_index") from None
    return out


def teilabzuege_lesen(o) -> list:
    """/eth/v1/beacon/states/…/pending_partial_withdrawals -> [(Validator, Gwei, frei ab Epoche)]."""
    if not isinstance(o, dict) or not isinstance(o.get("data"), list):
        raise AbrufFehler("Teilabzüge: keine Liste")
    out = []
    for e in o["data"]:
        try:
            idx = e["validator_index"] if "validator_index" in e else e["index"]      # ältere Prysm-Fassungen nannten das Feld „index“
            out.append((int(idx), int(e["amount"]), int(e["withdrawable_epoch"])))
        except (KeyError, TypeError, ValueError):
            raise AbrufFehler("Teilabzüge: Eintrag nicht lesbar") from None
    return out


def validator_lesen(o) -> dict | None:
    """Ein Eintrag aus /eth/v1/beacon/states/…/validators. None = nicht lesbar."""
    if not isinstance(o, dict) or not isinstance(o.get("validator"), dict):
        return None
    v = o["validator"]
    try:
        return {"index": int(o["index"]), "gwei": int(o["balance"]), "status": str(o.get("status") or ""),
                "cred": str(v.get("withdrawal_credentials") or ""), "austritt": int(v["exit_epoch"]),
                "frei": int(v["withdrawable_epoch"]), "slashed": bool(v.get("slashed"))}
    except (KeyError, TypeError, ValueError):
        return None


_VAL_RE = re.compile(rb"\{[^{}]*\{[^{}]*\}[^{}]*\}")


def validator_strom(stuecke, nimm) -> tuple[int, int]:
    """
    Die Validatorenliste stückweise lesen, ohne sie ganz im Speicher zu halten (bei einer vollen Schlange einige 10 MB): Jeder Eintrag
    ist ein Objekt mit genau einem inneren Objekt („validator“). nimm(v) bekommt jeden lesbaren Eintrag. Rückgabe: (gelesen, unlesbar).
    """
    rest = b""; n = 0; schlecht = 0
    for b in stuecke:
        rest += b
        ende = 0
        for m in _VAL_RE.finditer(rest):
            ende = m.end()
            try:
                o = json.loads(m.group(0))
            except ValueError:
                schlecht += 1; continue
            v = validator_lesen(o)
            if v is None:
                if isinstance(o, dict) and "validator" in o:
                    schlecht += 1
                continue
            n += 1; nimm(v)
        if ende:
            rest = rest[ende:]
        elif len(rest) > REST_MAX:
            raise AbrufFehler("Validatorenliste: Form nicht erkannt")
    return n, schlecht


def tagesdatei_lesen(o) -> list:
    """historical_data.json von validatorqueue.com: je UTC-Tag die erste Messung. Schlangen in ETH, Wartezeiten in Tagen."""
    if not isinstance(o, list):
        raise AbrufFehler("Tagesdatei: keine Liste")
    je_tag = {}
    for e in o:
        if not isinstance(e, dict):
            continue
        tag = str(e.get("date") or "")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", tag):
            continue
        try:
            ts = calendar.timegm(time.strptime(tag, "%Y-%m-%d"))
        except ValueError:
            continue
        je_tag[tag] = {"tag": tag, "ts": ts, "exit_eth": _zahl(e.get("exit_queue")), "exit_tage": _zahl(e.get("exit_wait")),
                       "eintritt_eth": _zahl(e.get("entry_queue")), "eintritt_tage": _zahl(e.get("entry_wait")),
                       "validatoren": _zahl(e.get("validators")), "gestakt_eth": _zahl(e.get("staked_amount")),
                       "umlauf_eth": _zahl(e.get("supply")), "apr": _zahl(e.get("apr"))}
    if not je_tag:
        raise AbrufFehler("Tagesdatei: kein lesbarer Tag")
    return [je_tag[k] for k in sorted(je_tag)]


# ================================================================================================ Auswertung

def auswerten(validatoren, konsol: set, teil: list, kopf_slot: int, kopf_ts: int) -> dict:
    """
    Aus den Listen des Knotens den Stand bilden. validatoren: Einträge wie von validator_lesen. Gezählt wird der Kontostand (balance):
    das, was ausgezahlt wird. Zusammenlegungen (Index in konsol) werden getrennt gezählt und fließen in nichts ein.
    """
    heute = tag_beginn(kopf_ts)
    tage: dict = {}
    adr: dict = {}
    S = {"voll": 0, "voll_n": 0, "warte": 0, "sperr": 0, "konsol": 0, "konsol_n": 0, "teil": 0, "teil_n": 0, "ohne_adresse": 0,
         "uebersprungen": 0, "ende_ts": None, "schlange_ende_ts": None}

    def buchen(ts: int, gwei: int, art: int) -> None:
        e = tage.setdefault(max(heute, tag_beginn(ts)), [0, 0])
        e[art] += gwei
        if S["ende_ts"] is None or ts > S["ende_ts"]:
            S["ende_ts"] = ts

    for v in validatoren:
        if v["status"] not in ("active_exiting", "exited_unslashed") or v["frei"] >= FERN or v["austritt"] >= FERN or v["slashed"]:
            S["uebersprungen"] += 1; continue
        if v["index"] in konsol:
            S["konsol"] += v["gwei"]; S["konsol_n"] += 1; continue
        ts = epoche_ts(v["frei"], kopf_slot, kopf_ts)
        S["voll"] += v["gwei"]; S["voll_n"] += 1
        if v["status"] == "active_exiting":
            S["warte"] += v["gwei"]
            t_aus = epoche_ts(v["austritt"], kopf_slot, kopf_ts)
            if S["schlange_ende_ts"] is None or t_aus > S["schlange_ende_ts"]:
                S["schlange_ende_ts"] = t_aus
        else:
            S["sperr"] += v["gwei"]
        buchen(ts, v["gwei"], 0)
        a = adresse(v["cred"])
        if a is None:
            S["ohne_adresse"] += v["gwei"]; continue
        e = adr.get(a)
        if e is None:
            adr[a] = [v["gwei"], 1, ts, ts]
        else:
            e[0] += v["gwei"]; e[1] += 1; e[2] = min(e[2], ts); e[3] = max(e[3], ts)
    for _idx, gwei, frei in teil:
        if frei >= FERN or gwei <= 0:
            S["uebersprungen"] += 1; continue
        S["teil"] += gwei; S["teil_n"] += 1
        buchen(epoche_ts(frei, kopf_slot, kopf_ts), gwei, 1)
    eth = lambda g: round(g / GWEI, 3)                                    # noqa: E731
    kal = [[t, eth(tage[t][0]), eth(tage[t][1])] for t in sorted(tage)]
    if len(kal) > KALENDER_TAGE:                                          # alles Spätere in einen letzten Eintrag
        rest = kal[KALENDER_TAGE - 1:]
        kal = kal[:KALENDER_TAGE - 1] + [[rest[0][0], round(sum(r[1] for r in rest), 3), round(sum(r[2] for r in rest), 3)]]
    top = sorted(adr.items(), key=lambda kv: (-kv[1][0], kv[0]))[:ADRESSEN_MAX]
    return {"ts": int(kopf_ts), "quelle": "knoten", "kopf_slot": int(kopf_slot), "voll_eth": eth(S["voll"]), "voll_n": S["voll_n"],
            "warte_eth": eth(S["warte"]), "sperr_eth": eth(S["sperr"]), "teil_eth": eth(S["teil"]), "teil_n": S["teil_n"],
            "konsol_eth": eth(S["konsol"]), "konsol_n": S["konsol_n"], "ohne_adresse_eth": eth(S["ohne_adresse"]),
            "uebersprungen": S["uebersprungen"], "ende_ts": S["ende_ts"], "schlange_ende_ts": S["schlange_ende_ts"], "kalender": kal,
            "adressen": [{"adresse": a, "eth": eth(e[0]), "n": e[1], "von_ts": e[2], "bis_ts": e[3]} for a, e in top],
            "hinweise": []}


def kalender_schaetzen(q_eth: float, ab_ts: int, jetzt: int) -> tuple[list, int | None]:
    """
    Ersatz ohne Knoten: aus der Länge der Schlange (ETH) zum Zeitpunkt ab_ts einen Kalender schätzen -- der Reihe nach höchstens
    DURCHSATZ_TAG je Tag, „frei ab“ = Austritt + Sperrfrist. Neue Anmeldungen seit ab_ts sind unbekannt. Rückgabe: (Kalender, Ende).
    """
    q = max(0.0, float(q_eth or 0.0))
    if q <= 0:
        return [], None
    heute = tag_beginn(jetzt)
    tage: dict = {}
    k = 0; rest = q
    while rest > 1e-9 and k < 10_000:
        menge = min(float(DURCHSATZ_TAG), rest)
        frei = int(ab_ts + k * TAG + menge / DURCHSATZ_TAG * TAG / 2 + SPERR_S)      # Mitte des Tagesanteils, dann die Sperrfrist
        if frei + TAG / 2 > jetzt:                                                # was schon frei wäre, steht nicht mehr im Kalender
            t = max(heute, tag_beginn(frei))
            tage[t] = tage.get(t, 0.0) + menge
        rest -= menge; k += 1
    ende = int(ab_ts + q / DURCHSATZ_TAG * TAG + SPERR_S)
    kal = [[t, round(tage[t], 3), 0.0] for t in sorted(tage)][:KALENDER_TAGE]
    return kal, (ende if ende > jetzt else None)


def grosse_freigabe(kalender: list, schwelle: float = GROSS_TAG_ETH) -> dict | None:
    """Die nächste Folge aufeinanderfolgender UTC-Tage mit mindestens `schwelle` ETH „frei ab“. kalender: [[tag_ts, voll, teil], …]."""
    K = sorted(kalender, key=lambda e: e[0])
    for i, e in enumerate(K):
        if e[1] + e[2] >= schwelle:
            j = i
            while j + 1 < len(K) and K[j + 1][0] == K[j][0] + TAG and K[j + 1][1] + K[j + 1][2] >= schwelle:
                j += 1
            return {"von_ts": K[i][0], "bis_ts": K[j][0], "tage": j - i + 1, "eth": round(sum(x[1] + x[2] for x in K[i:j + 1]), 3)}
    return None


def lauf_dauer_tage(validatoren) -> float | None:
    """Dauer einer Runde des Auszahlungslaufs: 16 Auszahlungen je Slot über alle aktiven Validatoren."""
    n = _zahl(validatoren)
    return None if not n or n <= 0 else n * SLOT_S / AUSZAHLUNGEN_JE_SLOT / TAG


# ================================================================================================ Abruf

def entpacken(roh_stuecke, gepackt: bool):
    """Stücke einer Antwort, bei gzip laufend entpackt (die Validatorenliste schrumpft gepackt auf einen Bruchteil)."""
    dec = zlib.decompressobj(16 + zlib.MAX_WBITS) if gepackt else None
    for b in roh_stuecke:
        if dec is not None:
            b = dec.decompress(b)
        if b:
            yield b
    if dec is not None:
        b = dec.flush()
        if b:
            yield b


def urllib_strom(url: str, timeout: float = 60.0):
    """(Status, Kopfzeilen, Stücke der entpackten Antwort). HTTP-Fehler kommen als Status zurück, Netzfehler als Ausnahme."""
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json", "Accept-Encoding": "gzip"})
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        try:
            text = e.read(2000)
        except Exception:  # noqa: BLE001 -- der Fehlertext ist Beiwerk
            text = b""
        return e.code, {}, iter([text])

    def roh():
        try:
            while True:
                b = r.read(65536)
                if not b:
                    break
                yield b
        finally:
            r.close()
    return r.status, dict(r.headers), entpacken(roh(), (r.headers.get("Content-Encoding") or "").lower() == "gzip")


class Abruf:
    """Ein Lauf über eine Quelle; jeder Schritt steht mit Status, Größe, Dauer und Fehler im Protokoll."""

    def __init__(self, transport=None, timeout: float = 30.0, frist_s: float | None = None):
        self.transport = transport or urllib_strom
        self.timeout = timeout                                           # je Lesevorgang am Netz
        self.ende = (time.time() + frist_s) if frist_s else None         # gemeinsame Frist aller Fragen dieses Abrufs
        self.protokoll: list = []

    def _lesen(self, name: str, url: str, verarbeite):
        e = {"name": name, "url": url, "status": None, "bytes": 0, "ms": None, "n": None, "fehler": None}
        self.protokoll.append(e)
        t0 = time.time()
        grenze = ZEIT_MAX_S if self.ende is None else min(ZEIT_MAX_S, self.ende - t0)

        def gezaehlt(st):
            for b in st:
                e["bytes"] += len(b)
                if e["bytes"] > MAX_BYTES:
                    raise AbrufFehler(f"Antwort größer als {MAX_BYTES // 1_000_000} MB")
                if time.time() - t0 > grenze:
                    raise AbrufFehler(f"Antwort dauert länger als {max(0, int(round(grenze)))} s (Frist dieses Abrufs)")
                yield b
        try:
            if grenze <= 0:
                raise AbrufFehler("Frist dieses Abrufs aufgebraucht")
            status, _kopf, st = self.transport(url, self.timeout if self.ende is None else max(1.0, min(self.timeout, grenze)))
            e["status"] = int(status)
            if int(status) != 200:
                text = b"".join(list(gezaehlt(st)))[:200].decode("utf-8", "replace").strip()
                raise AbrufFehler(f"HTTP {status}" + (f": {text}" if text else ""))
            return verarbeite(gezaehlt(st), e)
        except AbrufFehler as x:
            e["fehler"] = str(x)[:300]
            raise
        except Exception as x:  # noqa: BLE001 -- Netz, Zeitüberschreitung, kaputte Antwort: als Fehler dieses Schritts melden
            e["fehler"] = f"{type(x).__name__}: {x}"[:300]
            raise AbrufFehler(e["fehler"]) from None
        finally:
            e["ms"] = int((time.time() - t0) * 1000)

    def json(self, name: str, url: str):
        return self._lesen(name, url, lambda st, e: json.loads(b"".join(st).decode("utf-8")))

    def validatoren(self, name: str, url: str, nimm) -> tuple[int, int]:
        def v(st, e):
            n, schlecht = validator_strom(st, nimm)
            e["n"] = n
            if schlecht:
                e["fehler"] = f"{schlecht} Einträge nicht lesbar"
            return n, schlecht
        return self._lesen(name, url, v)


def knoten_liste() -> tuple:
    roh = os.environ.get("HL_STAKING_KNOTEN") or ""
    eigene = tuple(u.strip().rstrip("/") for u in roh.split(",") if u.strip().startswith("http"))
    return eigene or KNOTEN_STANDARD


def knoten_abrufen(basis: str, ab: Abruf, jetzt: int | None = None) -> dict:
    """Ein vollständiger Abruf an einem Knoten. Wirft AbrufFehler, wenn ein nötiger Teil fehlt; der Stand bleibt dann der alte."""
    b = basis.rstrip("/")
    kopf = ab.json("Kopf der Kette", b + "/eth/v1/beacon/headers/head")
    kopf_ts = int(jetzt or time.time())
    slot = kopf_slot_lesen(kopf)
    abw = slot - slot_soll(kopf_ts)
    if abs(abw) > SLOT_TOLERANZ:
        ab.protokoll[-1]["fehler"] = f"Slot {slot}, erwartet {slot_soll(kopf_ts)}"
        raise AbrufFehler(f"Der Knoten liegt {abs(abw)} Slots {'hinter' if abw < 0 else 'vor'} der Uhr (erlaubt {SLOT_TOLERANZ}) -- "
                          "er kommt nicht mit oder die Zeitrechnung der Kette hat sich geändert; seine Zeitpunkte werden nicht verwendet")
    st = b + "/eth/v1/beacon/states/finalized"
    konsol = konsolidierungen_lesen(ab.json("Zusammenlegungen", st + "/pending_consolidations"))
    ab.protokoll[-1]["n"] = len(konsol)
    eintraege: list = []
    unlesbar = 0
    _n, s1 = ab.validatoren("Vollabzüge in der Schlange", st + "/validators?status=active_exiting", eintraege.append)
    unlesbar += s1
    hinweise = []
    try:
        _n, s2 = ab.validatoren("Vollabzüge in der Sperrfrist", st + "/validators?status=exited_unslashed", eintraege.append)
        unlesbar += s2
    except AbrufFehler as x:
        hinweise.append(f"Vollabzüge in der Sperrfrist (bis rund 27 h vor „frei ab“) nicht lesbar: {x}"[:200])
    teil = []
    try:
        teil = teilabzuege_lesen(ab.json("Teilabzüge", st + "/pending_partial_withdrawals"))
        ab.protokoll[-1]["n"] = len(teil)
    except AbrufFehler as x:
        hinweise.append(f"Teilabzüge nicht lesbar -- die Summe ist eine Untergrenze: {x}"[:200])
    S = auswerten(eintraege, konsol, teil, slot, kopf_ts)
    S["knoten"] = b; S["slot_abweichung"] = abw; S["unlesbar"] = unlesbar
    if unlesbar:
        hinweise.append(f"{unlesbar} Einträge der Validatorenliste nicht lesbar")
    S["hinweise"] = hinweise
    return S


# ================================================================================================ Datenbank

@contextmanager
def schreiben(con: sqlite3.Connection):
    con.execute("BEGIN IMMEDIATE")
    try:
        yield con
    except BaseException:
        con.execute("ROLLBACK")
        raise
    else:
        con.execute("COMMIT")


def verbinden(p: str) -> sqlite3.Connection:
    con = sqlite3.connect(p, timeout=30, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA busy_timeout=30000")
    with schreiben(con):
        for s in SCHEMA:
            con.execute(s)
    return con


def lesen(p: str):
    """Nur-Lese-Verbindung; None, wenn die Datei fehlt."""
    if not p or not os.path.exists(p):
        return None
    con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=10, check_same_thread=False)
    con.execute("PRAGMA busy_timeout=10000")
    return con


def pfad(db: str) -> str:
    """staking.db liegt neben der Hauptdatenbank; HL_STAKING_DB lenkt um (Selbsttest)."""
    p = os.environ.get("HL_STAKING_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "staking.db")


def meta(con, schluessel: str, standard=None):
    try:
        r = con.execute("SELECT wert FROM st_meta WHERE schluessel=?", (schluessel,)).fetchone()
    except sqlite3.Error:
        return standard
    if r is None:
        return standard
    try:
        return json.loads(r[0])
    except (TypeError, ValueError):
        return standard


def meta_setzen(con, schluessel: str, wert) -> None:
    con.execute("INSERT INTO st_meta VALUES (?,?) ON CONFLICT(schluessel) DO UPDATE SET wert=excluded.wert",
                (schluessel, json.dumps(wert, ensure_ascii=False)))


def tagesreihe_zeile(stand: dict) -> tuple:
    """
    Zeile der eigenen Tagesreihe aus einem Stand des Knotens. Schlange = Vollabzüge, die noch nicht ausgetreten sind (ohne Sperrfrist,
    ohne Zusammenlegungen); Wartezeit = Tage bis zum letzten zugeteilten Austritt; dazu Sperrfrist, Teilabzüge, Zusammenlegungen und
    der Zeitpunkt, zu dem alles Angemeldete frei ist.
    """
    ts = int(stand["ts"])
    ende = stand.get("schlange_ende_ts")
    return (time.strftime("%Y-%m-%d", time.gmtime(ts)), ts, stand.get("warte_eth"),
            round(max(0, int(ende) - ts) / TAG, 3) if ende else 0.0, stand.get("sperr_eth"), stand.get("teil_eth"), stand.get("konsol_eth"),
            stand.get("ende_ts"))


_REIHE_SPALTEN = ("tag", "ts", "schlange_eth", "schlange_tage", "sperr_eth", "teil_eth", "konsol_eth", "frei_bis_ts")


def tagesreihe_lesen(con, limit: int | None = None) -> list:
    """Die eigene Tagesreihe, älteste zuerst. Leer, solange die Tabelle fehlt (Datenbank von vor 23.102, noch nicht neu geöffnet)."""
    try:
        q = "SELECT " + ",".join(_REIHE_SPALTEN) + " FROM st_tag_knoten ORDER BY ts DESC" + (f" LIMIT {int(limit)}" if limit else "")
        return [dict(zip(_REIHE_SPALTEN, r)) for r in con.execute(q).fetchall()][::-1]
    except sqlite3.Error:
        return []


def tageswert_gueltig(ts) -> bool:
    """23.106 (U259): Liegt die Messung nah genug am Beginn ihres UTC-Tags (vor 03:00 UTC)? Nur dann zählt der Tag in der zweiten Prüfung."""
    return ts is not None and 0 <= int(ts) % TAG < TAGESWERT_BIS_S


def angemeldet_eth(zeile: dict):
    """
    23.106 (U259): angemeldete Abzüge, die noch nicht frei sind = Vollabzüge in der Schlange + Vollabzüge in der Sperrfrist + Teilabzüge
    (ohne Zusammenlegungen) -- die Zahl im Kopf der Karte. An ihr misst die zweite Prüfung neue Wellen: Sie hält jeden Antrag mindestens
    27,3 Stunden fest, gleich wie schnell die Kette die Schlange abbaut. None, wenn ein Teil fehlt.
    """
    teile = [_zahl((zeile or {}).get(k)) for k in ("schlange_eth", "sperr_eth", "teil_eth")]
    if any(t is None or t < 0 for t in teile):
        return None
    return float(sum(teile))


def tagesreihe_zeilen(reihe: list, letzte: int = 8) -> list:
    """
    Debug 145: die eigene Tagesreihe als Text. Seit 23.106 (U259) mit der Summe „angemeldet“, ihrem Zuwachs gegen den Vortag (nur wenn
    beide Tage zu Tagesbeginn gemessen sind) und dem Vermerk an Zeilen, die zu spät am Tag gemessen wurden.
    """
    uhr = f"{TAGESWERT_BIS_S // 3600:02d}:00 UTC"
    gut = sum(1 for t in reihe if tageswert_gueltig(t.get("ts")))
    Z = [f"Eigene Tagesreihe vom Knoten (erste Messung je UTC-Tag, seit Paket 23.102): {_de(len(reihe))} Tag(e) von {reihe[0]['tag']} "
         f"bis {reihe[-1]['tag']} · davon zu Tagesbeginn gemessen (vor {uhr}): {_de(gut)}",
         "  Angemeldet = Schlange + Sperrfrist + Teilabzüge (ohne Zusammenlegungen). An ihrem Zuwachs gegen den Vortag misst die zweite "
         f"Prüfung der Kursfolge neue Wellen: ab {_de(WELLE_AB_ETH)} ETH, nur an Tagen, die zu Tagesbeginn gemessen sind (Debug 147)."]
    je_tag = {int(t["ts"]) // TAG: t for t in reihe if t.get("ts") is not None}
    for t in reihe[-letzte:]:
        v = angemeldet_eth(t)
        u = je_tag.get(int(t["ts"]) // TAG - 1)
        zu = None
        if v is not None and u is not None and tageswert_gueltig(t["ts"]) and tageswert_gueltig(u["ts"]) and angemeldet_eth(u) is not None:
            zu = v - angemeldet_eth(u)
        Z.append(f"  {t['tag']} {time.strftime('%H:%M', time.gmtime(t['ts']))} UTC  Schlange {_de(t['schlange_eth']):>10} ETH "
                 f"({_de(t['schlange_tage'], 1)} T)  ·  Sperrfrist "
                 f"{_de(t['sperr_eth']):>9} ETH  ·  Teilabzüge {_de(t['teil_eth']):>9} ETH  ·  Zusammenlegungen "
                 f"{_de(t['konsol_eth']):>9} ETH (nicht in der Schlange gezählt)"
                 + (f"  ·  angemeldet {_de(v):>9} ETH" if v is not None else "  ·  angemeldet —")
                 + ((f" (gegen den Vortag {'+' if zu >= 0 else '−'}{_de(abs(zu))}" + (", Tag mit Zuwachs" if zu >= WELLE_AB_ETH else "") + ")")
                    if zu is not None else "")
                 + ("" if tageswert_gueltig(t["ts"]) else f"  ·  nach {uhr} gemessen: zählt nicht als Tagesbeginn"))
    return Z


def nachholen_faellig(con, jetzt: int, letzter: int) -> bool:
    """
    23.106 (U259): Hat der UTC-Tag noch keine Zeile in der Tagesreihe, wird im Fenster des Tagesbeginns (von TAGESBEGINN_NACH_S bis
    TAGESWERT_BIS_S nach Mitternacht) alle NACHHOLEN_S Sekunden erneut gefragt -- sonst bekäme ein Tag, dessen erster Abruf misslingt,
    seine Zeile erst im Stundentakt. Nach 03:00 UTC gilt wieder nur der Stundentakt: Eine spätere Zeile zählt ohnehin nicht als Tagesbeginn.
    """
    seit = int(jetzt) - tag_beginn(jetzt)
    if not TAGESBEGINN_NACH_S <= seit < TAGESWERT_BIS_S or int(jetzt) - int(letzter) < NACHHOLEN_S:
        return False
    try:
        return con.execute("SELECT 1 FROM st_tag_knoten WHERE tag = ?", (time.strftime("%Y-%m-%d", time.gmtime(jetzt)),)).fetchone() is None
    except sqlite3.Error:
        return False


def lauf_knoten(con, ab: Abruf | None = None, jetzt: int | None = None) -> dict:
    """Alle Knoten der Reihe nach, bis einer vollständig antwortet. Schreibt Stand oder Fehler; gibt {ok, stand, fehler, protokoll}."""
    jetzt = int(jetzt or time.time())
    ab = ab or Abruf(frist_s=GESAMT_MAX_S)
    fehler = []
    stand = None
    t0 = time.time()
    for basis in knoten_liste():
        try:
            stand = knoten_abrufen(basis, ab, jetzt)
            break
        except AbrufFehler as x:
            fehler.append(f"{basis}: {x}"[:400])
    groesse = sum(e["bytes"] for e in ab.protokoll)
    with schreiben(con):
        meta_setzen(con, "knoten_versuch", {"ts": jetzt, "protokoll": ab.protokoll[-12:]})
        if stand is not None:
            meta_setzen(con, "stand", stand)
            con.execute("INSERT OR IGNORE INTO st_tag_knoten VALUES (?,?,?,?,?,?,?,?)", tagesreihe_zeile(stand))    # erste Messung des Tages bleibt
            con.execute("INSERT OR REPLACE INTO st_lauf VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (jetzt, "knoten", 1, int((time.time() - t0) * 1000), groesse, stand["voll_eth"], stand["teil_eth"],
                         stand["konsol_eth"], stand["ende_ts"], "; ".join(stand["hinweise"])[:400] or None))
        else:
            meta_setzen(con, "fehler_knoten", {"ts": jetzt, "fehler": " | ".join(fehler)[:800]})
            con.execute("INSERT OR REPLACE INTO st_lauf VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (jetzt, "knoten", 0, int((time.time() - t0) * 1000), groesse, None, None, None, None, " | ".join(fehler)[:400]))
        con.execute("DELETE FROM st_lauf WHERE ts < ?", (jetzt - LAUF_BEHALTEN_TAGE * TAG,))
    return {"ok": stand is not None, "stand": stand, "fehler": fehler, "protokoll": ab.protokoll}


def lauf_tagesdatei(con, ab: Abruf | None = None, jetzt: int | None = None, url: str = TAGESDATEI_URL) -> dict:
    jetzt = int(jetzt or time.time())
    ab = ab or Abruf(frist_s=TAGESDATEI_MAX_S)
    t0 = time.time()
    try:
        zeilen = tagesdatei_lesen(ab.json("Tagesdatei", url))
        ab.protokoll[-1]["n"] = len(zeilen)
    except AbrufFehler as x:
        with schreiben(con):
            meta_setzen(con, "fehler_tagesdatei", {"ts": jetzt, "fehler": str(x)[:400]})
            meta_setzen(con, "tagesdatei_versuch", {"ts": jetzt, "protokoll": ab.protokoll[-1:]})
            con.execute("INSERT OR REPLACE INTO st_lauf VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (jetzt, "tagesdatei", 0, int((time.time() - t0) * 1000), ab.protokoll[-1]["bytes"], None, None, None, None, str(x)[:400]))
        return {"ok": False, "fehler": [str(x)], "protokoll": ab.protokoll}
    with schreiben(con):
        con.executemany("INSERT OR REPLACE INTO st_tag VALUES (?,?,?,?,?,?,?,?,?,?)",
                        [(z["tag"], z["ts"], z["exit_eth"], z["exit_tage"], z["eintritt_eth"], z["eintritt_tage"], z["validatoren"],
                          z["gestakt_eth"], z["umlauf_eth"], z["apr"]) for z in zeilen])
        meta_setzen(con, "tagesdatei", {"ts": jetzt, "n": len(zeilen), "letzter": zeilen[-1]["tag"]})
        meta_setzen(con, "tagesdatei_versuch", {"ts": jetzt, "protokoll": ab.protokoll[-1:]})
        con.execute("INSERT OR REPLACE INTO st_lauf VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (jetzt, "tagesdatei", 1, int((time.time() - t0) * 1000), ab.protokoll[-1]["bytes"], None, None, None, None, None))
    return {"ok": True, "n": len(zeilen), "letzter": zeilen[-1]["tag"], "fehler": [], "protokoll": ab.protokoll}


# ================================================================================================ Antwort für Cockpit und Bericht

_TAG_SPALTEN = ("tag", "ts", "exit_eth", "exit_tage", "eintritt_eth", "eintritt_tage", "validatoren", "gestakt_eth", "umlauf_eth", "apr")


def tage_lesen(con, limit: int | None = None) -> list:
    try:
        q = "SELECT " + ",".join(_TAG_SPALTEN) + " FROM st_tag ORDER BY ts DESC" + (f" LIMIT {int(limit)}" if limit else "")
        return [dict(zip(_TAG_SPALTEN, r)) for r in con.execute(q).fetchall()][::-1]
    except sqlite3.Error:
        return []


def nutzlast(p: str, jetzt: int | None = None) -> dict:
    """
    Der Stand für Cockpit und Bericht. Reihenfolge der Quellen: frischer Stand des Knotens; sonst die Tagesdatei, wenn ihr letzter Tag
    höchstens FRISCH_TAGESDATEI_TAGE alt ist (Kalender dann geschätzt); sonst ok=False mit Gründen. Nichts wird erfunden.
    """
    jetzt = int(jetzt or time.time())
    out = {"ok": False, "jetzt": jetzt, "version": VERSION_MODUL, "quelle": None, "stand": None, "frisch": False, "geschaetzt": False,
           "fehlt": [], "hinweise": [], "kalender": [], "adressen": [], "gross": None, "schwelle_tag_eth": GROSS_TAG_ETH,
           "durchsatz_tag_eth": DURCHSATZ_TAG, "sperr_h": round(SPERR_S / 3600, 1)}
    con = lesen(p)
    if con is None:
        out["fehlt"].append("staking.db fehlt noch (erster Abruf rund 90 s nach dem Start des Dashboards).")
        return out
    try:
        S = meta(con, "stand")
        letzte = tage_lesen(con, 1)
        fk = meta(con, "fehler_knoten") or {}
        ft = meta(con, "fehler_tagesdatei") or {}
        td = meta(con, "tagesdatei") or {}
    finally:
        con.close()
    T = letzte[-1] if letzte else None
    t_jung = False
    if T:
        t_jung = 0 <= jetzt - int(T["ts"]) < (FRISCH_TAGESDATEI_TAGE + 1) * TAG       # heute, gestern oder vorgestern (UTC)
        out["tagesdatei"] = {"tag": T["tag"], "ts": T["ts"], "exit_eth": T["exit_eth"], "exit_tage": T["exit_tage"], "frisch": t_jung,
                             "alt_tage": int((tag_beginn(jetzt) - int(T["ts"])) // TAG),
                             "eintritt_eth": T["eintritt_eth"], "eintritt_tage": T["eintritt_tage"],
                             "unsicher": TAGESDATEI_UNSICHER[0] <= T["tag"] <= TAGESDATEI_UNSICHER[1]}
        if t_jung and T["eintritt_eth"] is not None:                              # eine alte Gegenseite wäre irreführend: dann lieber keine
            out["eintritt"] = {"eth": T["eintritt_eth"], "tage": T["eintritt_tage"], "tag": T["tag"], "ts": T["ts"]}
        if 0 <= jetzt - int(T["ts"]) < LAUF_TAGE_FRISCH * TAG:
            out["lauf_tage"] = lauf_dauer_tage(T["validatoren"])
            out["validatoren"] = T["validatoren"]
    knoten_frisch = isinstance(S, dict) and S.get("ts") is not None and 0 <= jetzt - int(S["ts"]) <= FRISCH_KNOTEN_S
    tages_frisch = bool(T) and T.get("exit_eth") is not None and t_jung and not out["tagesdatei"]["unsicher"]
    if knoten_frisch:
        heute = tag_beginn(jetzt)
        tage: dict = {}
        for t, voll, teil in S.get("kalender") or []:
            e = tage.setdefault(max(heute, int(t)), [0.0, 0.0]); e[0] += voll; e[1] += teil
        kal = [[t, round(tage[t][0], 3), round(tage[t][1], 3)] for t in sorted(tage)]
        out.update({"ok": True, "quelle": "knoten", "stand": int(S["ts"]), "frisch": True, "knoten": S.get("knoten"),
                    "voll_eth": S.get("voll_eth"), "voll_n": S.get("voll_n"), "warte_eth": S.get("warte_eth"),
                    "sperr_eth": S.get("sperr_eth"), "teil_eth": S.get("teil_eth"), "teil_n": S.get("teil_n"),
                    "summe_eth": round((S.get("voll_eth") or 0.0) + (S.get("teil_eth") or 0.0), 3), "konsol_eth": S.get("konsol_eth"),
                    "ende_ts": S.get("ende_ts"), "schlange_ende_ts": S.get("schlange_ende_ts"), "kalender": kal,
                    "adressen": [a for a in (S.get("adressen") or []) if (a.get("eth") or 0) >= GROSS_ADRESSE_ETH][:3],
                    "ohne_adresse_eth": S.get("ohne_adresse_eth"), "hinweise": list(S.get("hinweise") or [])})
    elif tages_frisch:
        kal, ende = kalender_schaetzen(T["exit_eth"], int(T["ts"]), jetzt)
        out.update({"ok": True, "quelle": "tagesdatei", "stand": int(T["ts"]), "frisch": True, "geschaetzt": True,
                    "voll_eth": T["exit_eth"], "teil_eth": None, "summe_eth": T["exit_eth"], "konsol_eth": None, "ende_ts": ende,
                    "schlange_ende_ts": None, "kalender": kal})
        out["hinweise"].append("Der Beacon-Knoten liefert keinen frischen Stand" + (f" ({fk.get('fehler')})" if fk.get("fehler") else "")
                               + "; Kalender aus der Tagesdatei geschätzt (ohne Teilabzüge, ohne Anmeldungen seit dem Tagesstand).")
    else:
        if isinstance(S, dict) and S.get("ts") is not None:
            out["fehlt"].append(f"Stand des Beacon-Knotens vom {_datum(S['ts'])} -- älter als {FRISCH_KNOTEN_S // 3600} h.")
        else:
            out["fehlt"].append("Noch kein Stand vom Beacon-Knoten.")
        if fk.get("fehler"):
            out["fehlt"].append(f"Letzter Fehler am Knoten ({_datum(fk.get('ts'))}): {fk['fehler']}"[:300])
        if T:
            out["fehlt"].append(f"Tagesdatei: letzter Tag {T['tag']} -- als Ersatz zu alt (höchstens {FRISCH_TAGESDATEI_TAGE} Tage)."
                                if not out["tagesdatei"]["unsicher"] else f"Tagesdatei: Tag {T['tag']} laut Quelle fehlerhaft.")
        else:
            out["fehlt"].append("Noch keine Tagesdatei." + (f" Letzter Fehler ({_datum(ft.get('ts'))}): {ft['fehler']}"[:200] if ft.get("fehler") else ""))
    if out["ok"]:
        out["gross"] = grosse_freigabe(out["kalender"])
    out["tagesdatei_stand"] = td or None
    return out


def _tag_de(t) -> str | None:
    """„2026-10-25“ -> „25.10.2026“; alles andere -> None."""
    t = str(t or "")
    return f"{t[8:10]}.{t[5:7]}.{t[:4]}" if len(t) == 10 and t[4] == "-" and t[7] == "-" and (t[:4] + t[5:7] + t[8:]).isdigit() else None


def sicherung_stand(db: str) -> dict:
    """
    23.103 (U257): Liegt staking.db im täglichen Backup des Recorders? Nur lesen: der Backup-Ordner aus der Hauptdatenbank (Tabelle
    meta, Schlüssel backup_dir -- dort trägt der Recorder den gültigen Ordner ein; ohne Eintrag gilt wie beim Recorder „dbbackup“ neben
    der Datenbank), darin backup.json (letzter Lauf) und die Kopie. Dieses Modul sichert nichts selbst und importiert kein Projektmodul.
    """
    ordner = None
    try:
        if db and os.path.exists(db):
            con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(db)) + "?mode=ro", uri=True, timeout=10)
            try:
                r = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
                ordner = str(r[0]) if r and r[0] else None
            finally:
                con.close()
    except sqlite3.Error:
        ordner = None
    aus_meta = ordner is not None
    if ordner is None:
        ordner = os.path.join(os.path.dirname(os.path.abspath(db or ".")), "dbbackup")
    out = {"ordner": ordner, "aus_meta": aus_meta, "kopie_ts": None, "kopie_bytes": None, "lauf_ts": None, "lauf_ok": None, "fehler": None}
    try:
        st = os.stat(os.path.join(ordner, SICHERUNG_NAME))
        out["kopie_ts"] = int(st.st_mtime); out["kopie_bytes"] = int(st.st_size)
    except OSError:
        pass
    try:
        with open(os.path.join(ordner, "backup.json"), encoding="utf-8") as f:
            B = json.load(f)
        if isinstance(B, dict):
            out["lauf_ts"] = int(B["ts"]) if isinstance(B.get("ts"), (int, float)) else None
            out["lauf_ok"] = bool(B.get("ok"))
            out["fehler"] = (str(B["staking_db_error"])[:200] if B.get("staking_db_error") else None)
            out["im_lauf"] = bool(B.get("staking_db"))
    except (OSError, ValueError):
        pass
    return out


def sicherung_zeile(S: dict, jetzt: int) -> str:
    """Eine Zeile für Debug 145: steht die Kopie da, von wann ist sie, ist der letzte Lauf gelungen?"""
    wo = f"im Backup-Ordner {S['ordner']}" + ("" if S.get("aus_meta") else " (Vorgabe neben der Datenbank)")
    kopie = (f"{SICHERUNG_NAME} vom {_datum(S['kopie_ts'])}, {_groesse(S['kopie_bytes'])}" if S.get("kopie_ts") is not None else None)
    if S.get("fehler"):
        return (f"Sicherung: beim letzten Backup ({_datum(S.get('lauf_ts'))}) ist die Kopie von staking.db NICHT gelungen: {S['fehler']} -- "
                + (f"es bleibt die vorige: {kopie}, {wo}." if kopie else f"es gibt keine Kopie {wo}."))
    if kopie is None:
        return (f"Sicherung: noch keine Kopie von staking.db {wo}. Der Recorder nimmt die Datei seit Paket 23.103 beim täglichen Backup "
                "mit -- beim nächsten Lauf, oder sofort mit „Jetzt sichern“ im Abschnitt System.")
    zusatz = ""
    if S.get("lauf_ok") is False:
        zusatz = f" Das letzte Backup ({_datum(S.get('lauf_ts'))}) ist insgesamt nicht gelungen; diese Kopie stammt von einem früheren Lauf."
    elif S.get("lauf_ts") is not None and S.get("im_lauf") is False:
        zusatz = f" Im letzten Backup ({_datum(S.get('lauf_ts'))}) war staking.db nicht dabei; diese Kopie stammt von einem früheren Lauf."
    if jetzt - int(S["kopie_ts"]) > SICHERUNG_ALT_S:
        zusatz += f" Sie ist älter als {SICHERUNG_ALT_S // TAG} Tage -- das Backup läuft sonst täglich."
    return f"Sicherung (täglich, mit dem Backup des Recorders): {kopie}, {wo}." + zusatz


def rueckblick(tage: list) -> dict:
    """Beschreibung der Tagesdatei -- ohne Kurs, ohne Urteil: Umfang, Lücken, größte Schlangen."""
    gut = [t for t in tage if t.get("exit_eth") is not None and not (TAGESDATEI_UNSICHER[0] <= t["tag"] <= TAGESDATEI_UNSICHER[1])]
    if not gut:
        return {"n": 0}
    luecken = sum(1 for a, b in zip(tage, tage[1:]) if b["ts"] - a["ts"] > TAG)
    spitze = max(gut, key=lambda t: t["exit_eth"])
    ueber = sum(1 for t in gut if t["exit_eth"] >= 10 * DURCHSATZ_TAG)
    # 23.102: Abzüge können die Schlange um höchstens DURCHSATZ_TAG am Tag verkleinern. Fällt sie stärker, enthält die Tagesdatei etwas,
    # das nicht durch dieses Kontingent muss. Anlass: 19. bis 25.10.2026 fiel sie an fünf von sieben Tagen um 76.000 bis 122.000 ETH.
    paare = [(a, b) for a, b in zip(gut, gut[1:]) if b["ts"] - a["ts"] == TAG and a["tag"] >= ABBAU_AB_TAG]
    schnell = [(a["exit_eth"] - b["exit_eth"], b["tag"]) for a, b in paare if a["exit_eth"] - b["exit_eth"] > ABBAU_GRENZE_ETH]
    return {"n": len(tage), "von": tage[0]["tag"], "bis": tage[-1]["tag"], "luecken": luecken, "spitze_eth": spitze["exit_eth"],
            "spitze_tag": spitze["tag"], "tage_ueber_10": ueber, "abbau_paare": len(paare), "abbau_zu_schnell": len(schnell),
            "abbau_max_eth": max(schnell)[0] if schnell else None, "abbau_max_tag": max(schnell)[1] if schnell else None}


def _protokoll_zeilen(protokoll: list) -> list:
    Z = []
    for e in protokoll or []:
        teil = [f"HTTP {e['status']}" if e.get("status") is not None else "keine Antwort", _groesse(e.get("bytes")), f"{_de(e.get('ms') or 0)} ms"]
        if e.get("n") is not None:
            teil.append(f"{_de(e['n'])} Einträge")
        if e.get("fehler"):
            teil.append("FEHLER: " + str(e["fehler"]))
        Z.append(f"  {e['name']:<30} " + " · ".join(teil))
    return Z


def stand_text(p: str, jetzt: int | None = None, abruf: dict | None = None, haupt_db: str | None = None) -> str:
    """Debug 145: Abruf, Stand, Kalender, Abzieher, Gegenseite, Rückblick -- dieselben Zahlen wie im Cockpit."""
    jetzt = int(jetzt or time.time())
    Z = []; a = Z.append
    a(f"★ Unstaking bei Ethereum (U254) · Modul {VERSION_MODUL} · {_datum(jetzt)}")
    a("Gemessen, kein Urteil: Wann wird gestaktes ETH frei? Ob danach der Kurs fällt, prüft eine eigene, vorab festgelegte Prüfung "
      "(Debug 147; KONZEPT_Unstaking.md 6).")
    a(f"Regeln der Kette: höchstens {CHURN_ETH} ETH je Epoche ({_de(DURCHSATZ_TAG)} ETH am Tag) verlassen das Staking; „frei ab“ = Austritt + "
      f"{SPERR_EPOCHEN} Epochen ({_de(SPERR_S / 3600, 1)} h). Große Freigabe: Tage ab {_de(GROSS_TAG_ETH)} ETH.")
    a("")
    if abruf is not None:
        a(f"Abruf jetzt -- Beacon-Knoten ({', '.join(knoten_liste())}):")
        Z.extend(_protokoll_zeilen((abruf.get("knoten") or {}).get("protokoll")) or ["  kein Abruf"])
        for f in (abruf.get("knoten") or {}).get("fehler") or []:
            a(f"  NICHT GELUNGEN: {f}")
        a("Abruf jetzt -- Tagesdatei (validatorqueue.com über GitHub):")
        Z.extend(_protokoll_zeilen((abruf.get("tagesdatei") or {}).get("protokoll")) or ["  kein Abruf"])
        a("")
    N = nutzlast(p, jetzt)
    if not N["ok"]:
        a("Stand: KEIN WERT")
        for f in N["fehlt"]:
            a(f"  fehlt: {f}")
    else:
        quelle = "Beacon-Knoten" if N["quelle"] == "knoten" else "Tagesdatei (Kalender geschätzt)"
        a(f"Stand ({quelle}, {_datum(N['stand'])})")
        a(f"  Angemeldet, noch nicht frei: {_de(N['summe_eth'])} ETH")
        if N["quelle"] == "knoten":
            a(f"    Vollabzüge {_de(N['voll_eth'])} ETH ({_de(N['voll_n'])} Validatoren; davon {_de(N['sperr_eth'])} ETH schon ausgetreten, in der Sperrfrist)")
            a(f"    Teilabzüge {_de(N['teil_eth'])} ETH ({_de(N['teil_n'])} Anträge)")
            a(f"  Nicht mitgezählt: {_de(N['konsol_eth'])} ETH in Zusammenlegungen (bleiben gestakt)")
            if N.get("schlange_ende_ts"):
                a(f"  Die Schlange der Vollabzüge ist abgearbeitet am {_datum(N['schlange_ende_ts'])}")
        a(f"  Alles Angemeldete ist frei bis {_datum(N['ende_ts'])}" if N.get("ende_ts") else "  Nichts Angemeldetes steht aus.")
        lt = N.get("lauf_tage")
        Tv = N.get("tagesdatei") or {}
        a("  Auszahlung: Teilabzüge mit „frei ab“; Vollabzüge danach mit dem Auszahlungslauf"
          + (f", binnen bis zu {_de(lt, 1)} Tagen ({_de(N.get('validatoren'))} Validatoren"
             + ("" if Tv.get("frisch") else f" laut Tagesdatei vom {Tv.get('tag')}") + ", 16 je Block)"
             if lt else f" (Dauer unbekannt: Tagesdatei fehlt oder ist älter als {LAUF_TAGE_FRISCH} Tage)"))
        g = N["gross"]
        a(f"  Nächste große Freigabe: {_tag(g['von_ts'])}" + (f" bis {_tag(g['bis_ts'])}" if g["tage"] > 1 else "") + f" · {_de(g['eth'])} ETH"
          if g else f"  Keine große Freigabe angemeldet (kein Tag ab {_de(GROSS_TAG_ETH)} ETH).")
        for h in N["hinweise"]:
            a(f"  Hinweis: {h}")
        a("Kalender „frei ab“ (UTC-Tage)" + (" -- geschätzt" if N["geschaetzt"] else ""))
        for t, voll, teil in N["kalender"][:21]:
            s = voll + teil
            a(f"  {_tag(t):<10} {_de(s):>10} ETH  " + "█" * max(0, min(40, int(round(s / DURCHSATZ_TAG * 20))))
              + (f"  (davon Teilabzüge {_de(teil)})" if teil >= 1 else ""))
        if len(N["kalender"]) > 21:
            a(f"  … und {len(N['kalender']) - 21} weitere Tage")
        if not N["kalender"]:
            a("  leer")
        if N["quelle"] == "knoten":
            a(f"Größte Abzieher (Vollabzüge je Auszahlungsadresse, ab {_de(GROSS_ADRESSE_ETH)} ETH)")
            for e in N["adressen"]:
                anteil = e["eth"] / N["voll_eth"] if N.get("voll_eth") else 0.0
                a(f"  {e['adresse']}  {_de(e['eth']):>10} ETH ({_de(anteil * 100)} %)  frei {_tag(e['von_ts'])} bis {_tag(e['bis_ts'])}  "
                  f"{_de(e['n'])} Validatoren")
            if not N["adressen"]:
                a("  keiner")
            if (N.get("ohne_adresse_eth") or 0) >= 1:
                a(f"  ohne Auszahlungsadresse (alte BLS-Kennung, nicht auszahlbar): {_de(N['ohne_adresse_eth'])} ETH")
    T = N.get("tagesdatei")
    if T and T.get("eintritt_eth") is not None:
        a(f"Gegenseite: {_de(T['eintritt_eth'])} ETH warten darauf, gestakt zu werden (Tagesdatei {T['tag']}; Wartezeit {_de(T.get('eintritt_tage'), 1)} Tage)"
          + ("" if T.get("frisch") else " -- VERALTET, im Cockpit nicht gezeigt"))
    if T and not T.get("frisch"):
        a(f"Tagesdatei der Quelle: letzter Tag {T['tag']} -- seit {_de(T.get('alt_tage') or 0)} Tagen ohne neuen Eintrag. Gegenseite und "
          "Ersatzkalender entfallen, solange das so bleibt; der Kalender oben kommt vom Knoten und ist davon nicht betroffen.")
    if T and N.get("quelle") == "knoten":
        if T.get("frisch"):
            a(f"Abgleich: Vollabzüge in der Schlange laut Knoten {_de(N.get('warte_eth'))} ETH · laut Tagesdatei {_de(T['exit_eth'])} ETH "
              f"(erste Messung des {T['tag']}; andere Uhrzeit, deshalb nur ungefähr gleich). Zum Vergleich der Zählweise: Knoten mit "
              f"Sperrfrist {_de(N.get('voll_eth'))} ETH, mit Sperrfrist und Zusammenlegungen "
              f"{_de((N.get('voll_eth') or 0) + (N.get('konsol_eth') or 0))} ETH.")
        else:
            a(f"Abgleich mit der Tagesdatei entfällt: Ihr letzter Tag ({T['tag']}) ist zu alt für einen Vergleich.")
    con = lesen(p)
    if con is not None:
        try:
            R = rueckblick(tage_lesen(con))
            if R.get("n"):
                a(f"Rückblick aus der Tagesdatei: {_de(R['n'])} Tage von {R['von']} bis {R['bis']}, {R['luecken']} Lücke(n); größte Schlange "
                  f"{_de(R['spitze_eth'])} ETH am {R['spitze_tag']}; Tage mit einer Schlange ab {_de(10 * DURCHSATZ_TAG)} ETH: {R['tage_ueber_10']}")
                for t in tage_lesen(con, 8):
                    a(f"  {t['tag']}  Abzug {_de(t['exit_eth']):>10} ETH ({_de(t['exit_tage'], 1)} T)  ·  Zugang {_de(t['eintritt_eth']):>10} ETH")
                if R.get("abbau_paare"):
                    a(f"  Seit {ABBAU_AB_TAG}: An {_de(R['abbau_zu_schnell'])} von {_de(R['abbau_paare'])} Tagen fiel diese Schlange um mehr als "
                      f"{_de(ABBAU_GRENZE_ETH)} ETH"
                      + (f" (am stärksten um {_de(R['abbau_max_eth'])} ETH am {R['abbau_max_tag']})" if R["abbau_zu_schnell"] else "")
                      + f". Abzüge allein lassen höchstens {_de(DURCHSATZ_TAG)} ETH am Tag zu."
                      + (" Mögliche Erklärung: Die Quelle zählt Zusammenlegungen mit (sie bleiben gestakt und haben ein eigenes Kontingent) -- "
                         "nicht geprüft. Der Stand oben vom Knoten zählt sie nicht." if R["abbau_zu_schnell"] else ""))
            reihe = tagesreihe_lesen(con)                                # 23.102: eigene Tagesreihe aus dem Knoten
            if reihe:
                Z.extend(tagesreihe_zeilen(reihe))
            else:
                a("Eigene Tagesreihe vom Knoten (seit Paket 23.102): noch kein Tag -- sie beginnt mit dem nächsten Stand des Knotens.")
            if haupt_db:                                                 # 23.103 (U257): liegt die Datei im Backup des Recorders?
                a(sicherung_zeile(sicherung_stand(haupt_db), jetzt))
            pr = meta(con, "studie_u255")                                # 23.101 (U255): Urteil von hl_staking_studie, hier nur genannt
            a("Prüfung der Kursfolge (U255): "
              + (f"{pr.get('urteil')} -- gerechnet am {time.strftime('%d.%m.%Y', time.gmtime(int(pr['ts'])))}"
                 + (f" für die Wellen bis {_tag_de((pr.get('daten') or {}).get('raster_bis'))}" if _tag_de((pr.get("daten") or {}).get("raster_bis")) else "")
                 + "; Einzelheiten in Debug 147."
                 if isinstance(pr, dict) and pr.get("ok") and pr.get("ts") else
                 "noch nicht gerechnet -- Debug 147 rechnet sie einmal und hält das Urteil fest."))
            laeufe = con.execute("SELECT ts, quelle, ok, dauer_ms, bytes, fehler FROM st_lauf ORDER BY ts DESC LIMIT 8").fetchall()
            if laeufe:
                a("Letzte Abrufe:")
                for ts, quelle, ok, ms, groesse, fehler in laeufe:
                    a(f"  {_datum(ts)}  {quelle:<10} {'ok' if ok else 'FEHLER'}  {_de(ms or 0)} ms  {_groesse(groesse)}" + (f"  {fehler}" if fehler else ""))
        except sqlite3.Error as x:
            a(f"staking.db nicht lesbar: {x}")
        finally:
            con.close()
    a("")
    a("Nicht enthalten: ETH, das schon frei ist und auf den Auszahlungslauf wartet; Abzüge aus Liquid-Staking-Pools, die ohne Austritt "
      "eines Validators bedient werden; ob frei gewordenes ETH an den Markt kommt.")
    return "\n".join(Z)


# ================================================================================================ Takt im Dashboard

_TAKT = {"gestartet": False, "stop": None}


def lauf_einmal(con, transport=None, jetzt: int | None = None, erzwungen: bool = False) -> dict:
    """Ein Schritt des Takts: Tagesdatei, wenn fällig; Knoten, wenn fällig. Fehler bleiben in der Datenbank stehen, nichts bricht ab."""
    jetzt = int(jetzt or time.time())
    out = {}
    td = meta(con, "tagesdatei_versuch") or {}
    if erzwungen or jetzt - int(td.get("ts") or 0) >= TAGESDATEI_TAKT_S:
        out["tagesdatei"] = lauf_tagesdatei(con, Abruf(transport, frist_s=TAGESDATEI_MAX_S), jetzt)
    kv = meta(con, "knoten_versuch") or {}
    letzter = int(kv.get("ts") or 0)
    tagesanfang = tag_beginn(jetzt)
    neuer_tag = letzter < tagesanfang and jetzt - tagesanfang >= TAGESBEGINN_NACH_S       # heute noch kein Versuch: einmal außer der Reihe
    if erzwungen or jetzt - letzter >= TAKT_S - 60 or neuer_tag:
        out["knoten"] = lauf_knoten(con, Abruf(transport, frist_s=GESAMT_MAX_S), jetzt)
    elif nachholen_faellig(con, jetzt, letzter):                          # 23.106 (U259): die Zeile des Tages fehlt noch
        out["knoten"] = lauf_knoten(con, Abruf(transport, frist_s=GESAMT_MAX_S), jetzt)
    return out


def starte(db_pfad: str, stop: threading.Event | None = None, verzoegerung: float = 90.0, transport=None):
    """Eigener Faden „staking“ im Dashboard-Prozess: nach 90 s der erste Abruf, dann jede Minute prüfen, ob etwas fällig ist."""
    if os.environ.get("HL_STAKING", "1") == "0" or not db_pfad or db_pfad == ":memory:":
        return None
    stop = stop or threading.Event()

    def lauf():
        if stop.wait(verzoegerung):
            return
        try:
            con = verbinden(db_pfad)
        except Exception as e:  # noqa: BLE001 -- z. B. Laufwerk nicht eingehängt: melden, nicht still sterben
            print("Unstaking: " + db_pfad + " nicht nutzbar: " + type(e).__name__ + ": " + str(e)[:200], flush=True)
            return
        while not stop.is_set():
            try:
                lauf_einmal(con, transport)
            except Exception as e:  # noqa: BLE001 -- der Faden läuft weiter (z. B. Datenbank kurz gesperrt)
                print("Unstaking: " + type(e).__name__ + ": " + str(e)[:200], flush=True)
            stop.wait(60)

    t = threading.Thread(target=lauf, name="staking", daemon=True)
    t.start()
    return t


def starten(db: str) -> bool:
    """Vom Dashboard beim Start aufgerufen. Nicht für Selbsttest-Datenbanken; aus mit HL_STAKING=0."""
    if _TAKT["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_STAKING") == "0":
        return False
    _TAKT["gestartet"] = True
    _TAKT["stop"] = threading.Event()
    return starte(pfad(db), stop=_TAKT["stop"]) is not None


def bericht(db: str, mit_abruf: bool = True, transport=None, jetzt: int | None = None) -> str:
    """Debug 145: ruft selbst ab, wenn der letzte Abruf älter als 10 min ist -- der Bericht zeigt, ob der Abruf JETZT gelingt."""
    p = pfad(db)
    abruf = None
    jetzt_ = int(jetzt or time.time())
    if mit_abruf:
        con = verbinden(p)
        try:
            kv = meta(con, "knoten_versuch") or {}
            td = meta(con, "tagesdatei_versuch") or {}
            if jetzt_ - int(kv.get("ts") or 0) > ABRUF_FRISCH_S or jetzt_ - int(td.get("ts") or 0) > ABRUF_FRISCH_S:
                abruf = lauf_einmal(con, transport, jetzt_, erzwungen=True)
            else:
                abruf = {"knoten": {"protokoll": kv.get("protokoll"), "fehler": []}, "tagesdatei": {"protokoll": td.get("protokoll")}}
        finally:
            con.close()
    return stand_text(p, jetzt_, abruf, haupt_db=db)


# ================================================================================================ Selbsttest (ohne Netz)

def _probe_welt(jetzt: int) -> dict:
    """Eine kleine Kette von Hand: Antworten in der Form der Beacon-API, mit bekanntem Ergebnis."""
    slot = slot_soll(jetzt)
    e0 = slot // SLOTS_EPOCHE
    X = "0x01" + "00" * 11 + "aa" * 20
    Y = "0x02" + "00" * 11 + "bb" * 20
    BLS = "0x00" + "cc" * 31

    def val(index, eth, status, cred, austritt, frei=None, slashed=False):
        return {"index": str(index), "balance": str(int(eth * GWEI)), "status": status,
                "validator": {"pubkey": "0x" + "ab" * 48, "withdrawal_credentials": cred, "effective_balance": str(int(min(eth, 2048) // 1 * GWEI)),
                              "slashed": slashed, "activation_eligibility_epoch": "1", "activation_epoch": "2",
                              "exit_epoch": str(austritt), "withdrawable_epoch": str(austritt + SPERR_EPOCHEN if frei is None else frei)}}
    schlange = [val(1000 + i, 32.5, "active_exiting", X, e0 + 10 + i) for i in range(100)]            # 100 × 32,5 ETH an Adresse X
    schlange += [val(5000, 2048.0, "active_exiting", Y, e0 + 500), val(5001, 2048.0, "active_exiting", Y, e0 + 1400)]
    schlange += [val(7000 + i, 32.0, "active_exiting", X, e0 + 40) for i in range(3)]                 # Quellen von Zusammenlegungen
    schlange += [val(8000, 32.0, "active_exiting", BLS, e0 + 60)]                                     # ohne Auszahlungsadresse
    schlange += [val(8100, 32.0, "active_exiting", X, 2 ** 64 - 1, frei=2 ** 64 - 1)]                 # kein Zeitpunkt: übersprungen
    schlange += [val(8200, 32.0, "active_slashed", X, e0 + 70, slashed=True)]                         # anderer Status: übersprungen
    sperr = [val(9000 + i, 32.0, "exited_unslashed", X, e0 - 100) for i in range(5)]                  # frei ab e0 + 156
    teil = [{"validator_index": "5000", "amount": str(1000 * GWEI), "withdrawable_epoch": str(e0 + 300)},
            {"validator_index": "5001", "amount": str(500 * GWEI), "withdrawable_epoch": str(e0 - 300)}, # seit 32 h fällig: zählt unter heute
            {"index": "5002", "amount": str(250 * GWEI), "withdrawable_epoch": str(e0 + 300)}]           # alte Feldbezeichnung
    return {"jetzt": jetzt, "slot": slot, "e0": e0, "X": "0x" + "aa" * 20, "Y": "0x" + "bb" * 20,
            "kopf": {"execution_optimistic": False, "finalized": False,
                     "data": {"root": "0x00", "canonical": True, "header": {"message": {"slot": str(slot), "proposer_index": "1"}, "signature": "0x"}}},
            "konsol": {"version": "electra", "data": [{"source_index": str(7000 + i), "target_index": "42"} for i in range(3)]},
            "schlange": {"execution_optimistic": False, "finalized": True, "data": schlange},
            "sperr": {"execution_optimistic": False, "finalized": True, "data": sperr},
            "teil": {"version": "electra", "data": teil}}


def _probe_transport(W: dict, tagesdatei=None, fehler: dict | None = None, stueck: int = 777, gzip: bool = False, aufrufe: list | None = None):
    """Falscher Transport: liefert die Probe-Welt in krummen Stücken; fehler: {Teil der URL: Status oder Ausnahme}."""
    antworten = (("/headers/head", W["kopf"]), ("/pending_consolidations", W["konsol"]), ("status=active_exiting", W["schlange"]),
                 ("status=exited_unslashed", W["sperr"]), ("/pending_partial_withdrawals", W["teil"]), ("historical_data.json", tagesdatei))

    def transport(url, timeout):
        if aufrufe is not None:
            aufrufe.append(url)
        for teil_, f in (fehler or {}).items():
            if teil_ in url:
                if isinstance(f, BaseException):
                    raise f
                return int(f), {}, iter([b'{"message":"nicht erlaubt"}'])
        for teil_, antwort in antworten:
            if teil_ in url:
                if antwort is None:
                    return 404, {}, iter([b"Not Found"])
                roh = antwort if isinstance(antwort, bytes) else json.dumps(antwort).encode()
                if gzip:
                    roh = _gzip(roh)
                return 200, {}, entpacken((roh[i:i + stueck] for i in range(0, len(roh), stueck)), gzip)
        return 404, {}, iter([b"Not Found"])
    return transport


def _gzip(roh: bytes) -> bytes:
    c = zlib.compressobj(6, zlib.DEFLATED, 16 + zlib.MAX_WBITS)
    return c.compress(roh) + c.flush()


def _probe_server(W: dict):
    """Ein Webserver auf 127.0.0.1 mit den Antworten der Probe-Welt: prüft den echten Abruf (urllib, gzip, HTTP-Fehler) ohne Netz."""
    import http.server

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            self.server.kopf.append((self.path, self.headers.get("User-Agent"), self.headers.get("Accept-Encoding")))
            if "pending_partial_withdrawals" in self.path:
                self.send_response(404); self.send_header("Content-Type", "application/json"); self.end_headers()
                self.wfile.write(b'{"code":404,"message":"gibt es hier nicht"}'); return
            for teil_, antwort, packen in (("/headers/head", W["kopf"], False), ("/pending_consolidations", W["konsol"], True),
                                            ("status=active_exiting", W["schlange"], True), ("status=exited_unslashed", W["sperr"], False)):
                if teil_ in self.path:
                    roh = json.dumps(antwort).encode()
                    self.send_response(200); self.send_header("Content-Type", "application/json")
                    if packen:
                        roh = _gzip(roh); self.send_header("Content-Encoding", "gzip")
                    self.send_header("Content-Length", str(len(roh))); self.end_headers(); self.wfile.write(roh); return
            self.send_response(500); self.end_headers()

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    srv.kopf = []
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def _probe_tagesdatei(jetzt: int, tage: int = 40, letzter_vor: int = 0) -> list:
    """Tagesdatei in der Form von validatorqueue.com: alte und neue Schlüsselnamen, eine Lücke, ein kaputter Eintrag."""
    out = []
    ende = tag_beginn(jetzt) - letzter_vor * TAG
    for i in range(tage, -1, -1):
        ts = ende - i * TAG
        if i == 20:
            continue                                                         # Lücke
        e = {"date": time.strftime("%Y-%m-%d", time.gmtime(ts)), "validators": 800000 + i, "entry_queue": 900000 + 1000 * i,
             "entry_wait": round((900000 + 1000 * i) / DURCHSATZ_TAG, 2), "exit_queue": 115200 if i == 0 else 4000 + 100 * i,
             "exit_wait": 2.0 if i == 0 else round((4000 + 100 * i) / DURCHSATZ_TAG, 2), "supply": 122000000, "staked_amount": 44600000,
             "staked_percent": 36.5, "apr": None if i == tage else 2.5}
        e.update({"churn": 8, "entry_churn": 8.8, "exit_churn": 8} if i > 30 else
                 {"current_entry_churn": 256, "current_exit_churn": 256, "ave_entry_churn": 256, "ave_exit_churn": 256})
        out.append(e)
    out.insert(3, {"date": "kaputt", "exit_queue": 1}); out.insert(5, "kein Objekt")
    return out


def selbsttest(verbose: bool = True) -> bool:
    import tempfile
    pruef = []

    def ok(name, bed, info=""):
        pruef.append((name, bool(bed)))
        if verbose or not bed:
            print(("  ok   " if bed else "  FEHL ") + name + (f" -- {info}" if info else ""))

    jetzt = 1_794_000_000 + 7 * 3600 + 123                                   # 07.11.2026, mitten am UTC-Tag
    W = _probe_welt(jetzt)
    e0, slot = W["e0"], W["slot"]
    heute = tag_beginn(jetzt)

    # ---- Zeitrechnung
    ok("Protokollwerte: Epoche 384 s, Sperrfrist 256 Epochen = 27,3 h, Durchsatz 57.600 ETH am Tag, große Freigabe ab 28.800 ETH",
       EPOCHE_S == 384 and SPERR_S == 98_304 and DURCHSATZ_TAG == 57_600 and GROSS_TAG_ETH == 28_800, f"{EPOCHE_S} {SPERR_S} {DURCHSATZ_TAG}")
    t_bsp = calendar.timegm((2026, 6, 13, 4, 57, 59))
    ok("Zeitpunkt einer Epoche: Epoche 454.434 beginnt am 13.06.2026 04:57:59 UTC (Angabe einer fremden Auswertung desselben Knotens)",
       GENESIS + 454_434 * EPOCHE_S == t_bsp and epoche_ts(454_434, slot_soll(jetzt), slot_soll(jetzt) * SLOT_S + GENESIS) == t_bsp,
       f"{GENESIS + 454_434 * EPOCHE_S} gegen {t_bsp}")
    ok("Zeitpunkt vom Kopf aus: eine Epoche später = 384 s später; der Kopf selbst liegt beim Abruf",
       epoche_ts(e0 + 1, e0 * 32, jetzt) == jetzt + 384 and epoche_ts(e0, e0 * 32 + 5, jetzt) == jetzt - 60)

    # ---- Antworten lesen
    try:
        TEIL = teilabzuege_lesen(W["teil"])
    except AbrufFehler as x:
        TEIL = [str(x)]
    ok("Kopf der Kette: Slot aus der Antwort; ohne Slot ein Fehler", kopf_slot_lesen(W["kopf"]) == slot
       and _wirft(lambda: kopf_slot_lesen({"data": {}})))
    ok("Zusammenlegungen: Quell-Indizes; fremde Form ist ein Fehler, kein leeres Ergebnis",
       konsolidierungen_lesen(W["konsol"]) == {7000, 7001, 7002} and konsolidierungen_lesen({"data": []}) == set()
       and _wirft(lambda: konsolidierungen_lesen({"data": [{"target_index": "1"}]})) and _wirft(lambda: konsolidierungen_lesen({})))
    ok("Teilabzüge: beide Feldnamen (validator_index, index); fremde Form ist ein Fehler",
       TEIL == [(5000, 1000 * GWEI, e0 + 300), (5001, 500 * GWEI, e0 - 300), (5002, 250 * GWEI, e0 + 300)]
       and _wirft(lambda: teilabzuege_lesen({"data": [{"amount": "1"}]})), f"{TEIL}")
    ok("Auszahlungsadresse: 0x01 und 0x02 tragen sie, 0x00 (BLS) und Kaputtes nicht",
       adresse("0x01" + "00" * 11 + "AA" * 20) == "0x" + "aa" * 20 and adresse("0x02" + "00" * 11 + "bb" * 20) == "0x" + "bb" * 20
       and adresse("0x00" + "cc" * 31) is None and adresse("0x01zz") is None and adresse("") is None
       and adresse_kurz("0x" + "aa" * 20) == "0xaaaa…aaaa" and adresse_kurz(None) == "ohne Adresse")

    # ---- Validatorenliste stückweise
    roh = json.dumps(W["schlange"]).encode()
    soll_n = len(W["schlange"]["data"])
    for stueck in (1, 7, 64, 777, 65536, len(roh)):
        got = []
        n, schlecht = validator_strom((roh[i:i + stueck] for i in range(0, len(roh), stueck)), got.append)
        if not (n == soll_n and schlecht == 0 and [g["index"] for g in got] == [int(d["index"]) for d in W["schlange"]["data"]]):
            ok(f"Validatorenliste in Stücken von {stueck} Bytes", False, f"{n} von {soll_n}, unlesbar {schlecht}")
            break
    else:
        ok(f"Validatorenliste stückweise gelesen: jeder der {soll_n} Einträge genau einmal, bei jeder Stückgröße (1 Byte bis alles auf einmal)", True)
    schoen = json.dumps(W["schlange"], indent=2).encode()
    um = json.dumps({"data": [{"validator": d["validator"], "status": d["status"], "balance": d["balance"], "index": d["index"]}
                              for d in W["schlange"]["data"]], "finalized": True}).encode()
    g1, g2 = [], []
    ok("Validatorenliste: auch eingerückt und mit anderer Reihenfolge der Felder; leere Liste = 0 Einträge; fremdes Objekt wird nicht gezählt",
       validator_strom(iter([schoen]), g1.append) == (soll_n, 0) and validator_strom(iter([um[:900], um[900:]]), g2.append) == (soll_n, 0)
       and g1 == g2 and validator_strom(iter([b'{"execution_optimistic":false,"finalized":true,"data":[]}']), g1.append) == (0, 0)
       and validator_strom(iter([b'{"data":[],"meta":{}}']), g1.append) == (0, 0))
    kaputt = roh.replace(b'"balance": "32500000000"', b'"balance": "viel"', 1)
    g3 = []
    ok("Validatorenliste: ein Eintrag mit kaputter Zahl wird als unlesbar gezählt, die übrigen bleiben; endlose Form bricht ab",
       validator_strom(iter([kaputt]), g3.append) == (soll_n - 1, 1) and _wirft(lambda: validator_strom(iter([b"{" + b"x" * (REST_MAX + 10)]), g3.append)))

    # ---- Auswertung (Soll von Hand)
    eintraege = [validator_lesen(d) for d in W["schlange"]["data"] + W["sperr"]["data"]]
    S = auswerten(eintraege, konsolidierungen_lesen(W["konsol"]), [t for t in TEIL if isinstance(t, tuple)], slot, jetzt)
    voll_soll = 100 * 32.5 + 2 * 2048.0 + 32.0 + 5 * 32.0                    # X in der Schlange, Y, BLS, X in der Sperrfrist
    ok("Summen: Vollabzüge = Schlange + Sperrfrist ohne Zusammenlegungen; Teilabzüge getrennt; Zusammenlegungen nur genannt",
       S["voll_eth"] == voll_soll and S["voll_n"] == 108 and S["warte_eth"] == voll_soll - 160.0 and S["sperr_eth"] == 160.0
       and S["teil_eth"] == 1750.0 and S["teil_n"] == 3 and S["konsol_eth"] == 96.0 and S["konsol_n"] == 3 and S["uebersprungen"] == 2
       and S["ohne_adresse_eth"] == 32.0, f"voll {S['voll_eth']} (Soll {voll_soll}), teil {S['teil_eth']}, konsol {S['konsol_eth']}, übersprungen {S['uebersprungen']}")
    frei = lambda ep: epoche_ts(ep, slot, jetzt)                             # noqa: E731
    soll_tage: dict = {}
    for i in range(100):
        soll_tage.setdefault(tag_beginn(frei(e0 + 10 + i + 256)), [0.0, 0.0])[0] += 32.5
    for ep in (e0 + 500 + 256, e0 + 1400 + 256):
        soll_tage.setdefault(tag_beginn(frei(ep)), [0.0, 0.0])[0] += 2048.0
    soll_tage.setdefault(tag_beginn(frei(e0 + 60 + 256)), [0.0, 0.0])[0] += 32.0
    soll_tage.setdefault(tag_beginn(frei(e0 + 156)), [0.0, 0.0])[0] += 160.0
    soll_tage.setdefault(tag_beginn(frei(e0 + 300)), [0.0, 0.0])[1] += 1250.0
    soll_tage.setdefault(heute, [0.0, 0.0])[1] += 500.0                      # seit 32 h fällig: steht unter heute, nicht unter einem vergangenen Tag
    ok("Kalender „frei ab“: je UTC-Tag Vollabzüge und Teilabzüge; schon Fälliges (auch seit über einem Tag) steht unter heute; nichts fehlt, nichts doppelt",
       [[t, round(v[0], 3), round(v[1], 3)] for t, v in sorted(soll_tage.items())] == S["kalender"] and S["kalender"][0][0] == heute
       and tag_beginn(epoche_ts(e0 - 300, slot, jetzt)) < heute
       and abs(sum(k[1] + k[2] for k in S["kalender"]) - (S["voll_eth"] + S["teil_eth"])) < 1e-6,
       f"{len(S['kalender'])} Tage, Summe {sum(k[1] + k[2] for k in S['kalender'])}")
    ok("Ende: „alles frei bis“ = spätester Zeitpunkt (Y mit Austritt in 1.400 Epochen + Sperrfrist); Ende der Schlange = spätester Austritt",
       S["ende_ts"] == frei(e0 + 1400 + 256) and S["schlange_ende_ts"] == frei(e0 + 1400) and S["ende_ts"] - S["schlange_ende_ts"] == SPERR_S)
    A = {a["adresse"]: a for a in S["adressen"]}
    ok("Abzieher: je Auszahlungsadresse Summe, Zahl, erster und letzter Zeitpunkt; größter zuerst; BLS und Zusammenlegungen nicht dabei",
       [a["adresse"] for a in S["adressen"]] == [W["Y"], W["X"]] and A[W["Y"]]["eth"] == 4096.0 and A[W["Y"]]["n"] == 2
       and A[W["X"]]["eth"] == 3250.0 + 160.0 and A[W["X"]]["n"] == 105 and A[W["X"]]["von_ts"] == frei(e0 + 156)
       and A[W["X"]]["bis_ts"] == frei(e0 + 109 + 256) and A[W["Y"]]["bis_ts"] == frei(e0 + 1400 + 256))
    ohne = auswerten(eintraege, set(), [], slot, jetzt)
    ok("Gegenprobe: ohne die Liste der Zusammenlegungen wäre die Summe um deren 96 ETH zu hoch", ohne["voll_eth"] == voll_soll + 96.0)
    viele = [dict(eintraege[0], index=50_000 + i, frei=e0 + 256 + i * 225) for i in range(KALENDER_TAGE + 30)]
    SV = auswerten(viele, set(), [], slot, jetzt)
    ok(f"Kalender: höchstens {KALENDER_TAGE} Einträge, alles Spätere im letzten -- die Summe bleibt",
       len(SV["kalender"]) == KALENDER_TAGE and abs(sum(k[1] for k in SV["kalender"]) - SV["voll_eth"]) < 1e-6)

    # ---- Große Freigabe
    T0 = heute
    kal = [[T0, 1000.0, 0.0], [T0 + TAG, 28_800.0, 0.0], [T0 + 2 * TAG, 20_000.0, 9_000.0], [T0 + 3 * TAG, 28_799.9, 0.0], [T0 + 4 * TAG, 57_600.0, 0.0]]
    g = grosse_freigabe(kal)
    ok("Große Freigabe: erste Folge von Tagen ab 28.800 ETH (Voll- und Teilabzüge zusammen); 28.799,9 ETH beendet sie",
       g == {"von_ts": T0 + TAG, "bis_ts": T0 + 2 * TAG, "tage": 2, "eth": 57_800.0}, f"{g}")
    ok("Große Freigabe: eine Lücke im Kalender trennt; kein Tag ab der Schwelle = keine",
       grosse_freigabe([[T0, 30_000.0, 0.0], [T0 + 2 * TAG, 30_000.0, 0.0]]) == {"von_ts": T0, "bis_ts": T0, "tage": 1, "eth": 30_000.0}
       and grosse_freigabe([[T0, 28_799.0, 0.0]]) is None and grosse_freigabe([]) is None
       and grosse_freigabe([[T0, 20_000.0, 8_800.0], [T0 + TAG, 100.0, 0.0]]) == {"von_ts": T0, "bis_ts": T0, "tage": 1, "eth": 28_800.0})

    # ---- Tagesdatei und Ersatzkalender
    TD = _probe_tagesdatei(jetzt)
    Z = tagesdatei_lesen(TD)
    ok("Tagesdatei: alte und neue Schlüsselnamen, kaputte Einträge übergangen, nach Tag geordnet, „apr“ darf fehlen",
       len(Z) == 40 and Z[-1]["tag"] == time.strftime("%Y-%m-%d", time.gmtime(jetzt)) and Z[-1]["exit_eth"] == 115200.0
       and Z[-1]["exit_tage"] == 2.0 and Z[0]["apr"] is None and Z[-1]["eintritt_eth"] == 900000.0 and Z[-1]["validatoren"] == 800000.0
       and [z["ts"] for z in Z] == sorted(z["ts"] for z in Z) and _wirft(lambda: tagesdatei_lesen({"a": 1})) and _wirft(lambda: tagesdatei_lesen([{"x": 1}])),
       f"{len(Z)} Tage, letzter {Z[-1]['tag']}")
    kal_s, ende_s = kalender_schaetzen(115_200.0, heute, jetzt)
    ok("Ersatzkalender aus der Tagesdatei: 115.200 ETH = zwei Tage Höchstdurchsatz, frei nach der Sperrfrist; Ende = Schlange ÷ Durchsatz + 27,3 h",
       abs(sum(k[1] for k in kal_s) - 115_200.0) < 1e-6 and all(k[2] == 0.0 for k in kal_s) and ende_s == heute + 2 * TAG + SPERR_S
       and [k[0] for k in kal_s] == [heute + TAG, heute + 2 * TAG], f"{kal_s}, Ende {ende_s - heute}")
    kal_alt, ende_alt = kalender_schaetzen(57_600.0, heute - 10 * TAG, jetzt)
    ok("Ersatzkalender: eine Schlange, die seit dem Tagesstand abgelaufen sein muss, ergibt keinen Kalender; leere Schlange auch nicht",
       kal_alt == [] and ende_alt is None and kalender_schaetzen(0.0, heute, jetzt) == ([], None))
    ok("Dauer des Auszahlungslaufs: 796.121 Validatoren ÷ 16 je Slot = 6,9 Tage (so zeigt es validatorqueue.com am 14.11.2026)",
       abs(lauf_dauer_tage(796_121) - 6.91) < 0.005 and lauf_dauer_tage(None) is None and lauf_dauer_tage(0) is None)

    # ---- Abruf mit falschem Transport, Datenbank, Antwort für das Cockpit
    tmp = tempfile.mkdtemp(prefix="hl_staking_")
    try:
        p = os.path.join(tmp, "staking.db")
        con = verbinden(p)
        aufrufe: list = []
        R = lauf_einmal(con, _probe_transport(W, TD, aufrufe=aufrufe), jetzt, erzwungen=True)
        N = nutzlast(p, jetzt)
        ok("Abruf: fünf Fragen an den Knoten (Zustand „finalized“, Kopf „head“) und die Tagesdatei; Stand gleich der Auswertung von Hand",
           R["knoten"]["ok"] and R["tagesdatei"]["ok"] and len(aufrufe) == 6 and sum("states/finalized" in u for u in aufrufe) == 4
           and sum("headers/head" in u for u in aufrufe) == 1 and N["ok"] and N["quelle"] == "knoten" and N["voll_eth"] == voll_soll
           and N["teil_eth"] == 1750.0 and N["summe_eth"] == voll_soll + 1750.0 and N["konsol_eth"] == 96.0 and N["kalender"] == S["kalender"]
           and N["ende_ts"] == S["ende_ts"] and not N["geschaetzt"] and N["hinweise"] == [], f"{len(aufrufe)} Aufrufe; {N.get('fehlt')}")
        ok("Antwort: Abzieher erst ab 10.000 ETH genannt (hier keiner); Gegenseite, Laufdauer und Abgleich aus der Tagesdatei",
           N["adressen"] == [] and N["eintritt"]["eth"] == 900000.0 and abs(N["lauf_tage"] - 800000 * 12 / 16 / TAG) < 1e-9
           and N["tagesdatei"]["exit_eth"] == 115200.0 and N["gross"] is None)
        Rg = lauf_einmal(con, _probe_transport(W, TD, gzip=True, stueck=333), jetzt, erzwungen=True)
        ok("Abruf: gepackte Antworten (gzip) in kleinen Stücken ergeben denselben Stand", Rg["knoten"]["ok"]
           and Rg["knoten"]["stand"] == R["knoten"]["stand"]
           and b"".join(entpacken(iter([_gzip(b"abc" * 5000)[i:i + 7] for i in range(0, 400, 7)] + [_gzip(b"abc" * 5000)[406:]]), True)) == b"abc" * 5000
           and list(entpacken(iter([b"x", b"", b"y"]), False)) == [b"x", b"y"])
        srv = _probe_server(W)
        try:
            ab = Abruf(timeout=10.0)
            SS = knoten_abrufen(f"http://127.0.0.1:{srv.server_address[1]}/", ab, jetzt)
            pr = {e["name"]: e for e in ab.protokoll}
            ok("Echter Abruf gegen einen Webserver auf diesem Rechner (urllib): Kennung gesendet, gzip angefragt und entpackt, HTTP 404 der "
               "Teilabzüge wird zum Hinweis mit dem Text des Servers, der Rest ergibt den Stand",
               SS["voll_eth"] == voll_soll and SS["teil_eth"] == 0.0 and SS["konsol_eth"] == 96.0 and len(SS["hinweise"]) == 1
               and "HTTP 404" in SS["hinweise"][0] and "gibt es hier nicht" in SS["hinweise"][0] and len(srv.kopf) == 5
               and all(k[1] == UA and k[2] == "gzip" for k in srv.kopf) and pr["Vollabzüge in der Schlange"]["status"] == 200
               and pr["Vollabzüge in der Schlange"]["n"] == soll_n and pr["Teilabzüge"]["status"] == 404
               and pr["Vollabzüge in der Schlange"]["bytes"] == len(roh) and SS["knoten"] == f"http://127.0.0.1:{srv.server_address[1]}",
               f"{SS['hinweise']}; {[(e['name'], e['status'], e['bytes'], e['n']) for e in ab.protokoll]}")
            srv.shutdown(); srv.server_close()
            ab2 = Abruf(timeout=3.0)
            ok("Echter Abruf: ein Knoten, der nicht antwortet, ist ein Fehler dieses Schritts mit Grund (kein Absturz)",
               _wirft(lambda: knoten_abrufen(f"http://127.0.0.1:{srv.server_address[1]}", ab2, jetzt)) and ab2.protokoll[0]["status"] is None
               and ab2.protokoll[0]["fehler"], f"{ab2.protokoll[0]['fehler']}")
        finally:
            try:
                srv.server_close()
            except Exception:  # noqa: BLE001
                pass
        # nicht fällig: kein neuer Abruf
        aufrufe.clear()
        lauf_einmal(con, _probe_transport(W, TD, aufrufe=aufrufe), jetzt + 600)
        ok("Takt: zehn Minuten nach einem Abruf ist nichts fällig; nach einer Stunde der Knoten, nach sechs Stunden auch die Tagesdatei",
           aufrufe == [] and (lauf_einmal(con, _probe_transport(_probe_welt(jetzt + 3600), TD, aufrufe=aufrufe), jetzt + 3600) or True)
           and len(aufrufe) == 5 and (aufrufe.clear() or True)
           and (lauf_einmal(con, _probe_transport(_probe_welt(jetzt + 6 * 3600 + 5), TD, aufrufe=aufrufe), jetzt + 6 * 3600 + 5) or True)
           and len(aufrufe) == 6, f"{len(aufrufe)} Aufrufe")
        con.close()

        # Frist eines ganzen Abrufs: ein Knoten, der tröpfelt, hält den Lauf nicht auf
        def traege(url, timeout):
            def st():
                roh_ = json.dumps(W["kopf"]).encode()
                for i_ in range(0, len(roh_), 40):
                    time.sleep(0.06); yield roh_[i_:i_ + 40]
            return 200, {}, st()
        abf = Abruf(traege, frist_s=0.15)
        t_f = time.time()
        f1 = _wirft(lambda: abf.json("Kopf der Kette", "http://x/eth/v1/beacon/headers/head"))
        f2 = _wirft(lambda: abf.json("Zusammenlegungen", "http://x/pending_consolidations"))
        ok("Frist: ein tröpfelnder Knoten wird nach der gemeinsamen Frist des Abrufs abgebrochen, die nächste Frage beginnt gar nicht erst; "
           "ohne Frist liest derselbe Transport zu Ende",
           f1 and f2 and time.time() - t_f < 1.0 and "dauert länger" in abf.protokoll[0]["fehler"] and "aufgebraucht" in abf.protokoll[1]["fehler"]
           and abf.protokoll[1]["status"] is None and kopf_slot_lesen(Abruf(traege).json("Kopf", "http://x/headers/head")) == slot
           and GESAMT_MAX_S == 150.0 and TAGESDATEI_MAX_S == 60.0,
           f"{[e_['fehler'] for e_ in abf.protokoll]} in {time.time() - t_f:.2f} s")

        # Fehlerfälle je Quelle
        def frisch(name):
            q = os.path.join(tmp, name)
            return q, verbinden(q)
        p2, c2 = frisch("f1.db")
        R2 = lauf_einmal(c2, _probe_transport(W, TD, fehler={"/pending_consolidations": 404}), jetzt, erzwungen=True)
        N2 = nutzlast(p2, jetzt)
        ok("Ohne die Liste der Zusammenlegungen gibt es keinen Stand vom Knoten (die Summe wäre zu hoch) -- Ersatz ist die Tagesdatei, "
           "als Schätzung gekennzeichnet",
           not R2["knoten"]["ok"] and "HTTP 404" in " ".join(R2["knoten"]["fehler"]) and N2["ok"] and N2["quelle"] == "tagesdatei"
           and N2["geschaetzt"] and N2["summe_eth"] == 115200.0 and N2["teil_eth"] is None and N2["konsol_eth"] is None
           and "keinen frischen Stand" in " ".join(N2["hinweise"]) and "HTTP 404" in " ".join(N2["hinweise"])
           and N2["gross"] == {"von_ts": heute + TAG, "bis_ts": heute + 2 * TAG, "tage": 2, "eth": 115200.0}, f"{N2.get('hinweise')}")
        c2.close()
        p3, c3 = frisch("f2.db")
        R3 = lauf_einmal(c3, _probe_transport(W, TD, fehler={"/pending_partial_withdrawals": 400, "status=exited_unslashed": TimeoutError("zu langsam")}),
                         jetzt, erzwungen=True)
        N3 = nutzlast(p3, jetzt)
        ok("Fehlen nur Teilabzüge und Sperrfrist-Liste, gilt der Stand mit Hinweis („Untergrenze“); die Schlange selbst ist vollständig",
           R3["knoten"]["ok"] and N3["quelle"] == "knoten" and N3["teil_eth"] == 0.0 and N3["voll_eth"] == voll_soll - 160.0
           and len(N3["hinweise"]) == 2 and "Untergrenze" in " ".join(N3["hinweise"]) and "zu langsam" in " ".join(N3["hinweise"]), f"{N3['hinweise']}")
        c3.close()
        p4, c4 = frisch("f3.db")
        W_alt = _probe_welt(jetzt - 3 * 3600)                                 # Knoten drei Stunden hinter der Uhr
        R4 = lauf_einmal(c4, _probe_transport(W_alt, None), jetzt, erzwungen=True)
        N4 = nutzlast(p4, jetzt)
        ok("Ein Knoten, der hinter der Uhr liegt, liefert keinen Stand (seine Zeitpunkte wären falsch); ohne Tagesdatei bleibt das "
           "Instrument ohne Wert und nennt beide Gründe",
           not R4["knoten"]["ok"] and "hinter der Uhr" in " ".join(R4["knoten"]["fehler"]) and not R4["tagesdatei"]["ok"] and not N4["ok"]
           and "Noch kein Stand" in " ".join(N4["fehlt"]) and "hinter der Uhr" in " ".join(N4["fehlt"]) and "Noch keine Tagesdatei" in " ".join(N4["fehlt"])
           and N4["kalender"] == [] and N4["gross"] is None, f"{N4['fehlt']}")
        c4.close()
        p5, c5 = frisch("f4.db")
        lauf_einmal(c5, _probe_transport(W, _probe_tagesdatei(jetzt, letzter_vor=4), fehler={"/headers/head": OSError("Netz nicht erreichbar")}),
                    jetzt, erzwungen=True)
        N5 = nutzlast(p5, jetzt)
        ok("Netzfehler am Knoten und eine Tagesdatei, deren letzter Tag vier Tage alt ist: kein Wert, mit Gründen; auch die Gegenseite "
           "wird dann nicht gezeigt (sie wäre veraltet), die Dauer des Auszahlungslaufs schon (ändert sich langsam)",
           not N5["ok"] and "Netz nicht erreichbar" in " ".join(N5["fehlt"]) and "zu alt" in " ".join(N5["fehlt"]) and "eintritt" not in N5
           and N5["tagesdatei"]["frisch"] is False and N5["tagesdatei"]["eintritt_eth"] is not None and N5.get("lauf_tage") is not None
           and LAUF_TAGE_FRISCH == 120 and "lauf_tage" not in nutzlast(p5, jetzt + 116 * TAG) and "lauf_tage" in nutzlast(p5, jetzt + 115 * TAG)
           and nutzlast(p, heute + 3 * TAG - 1).get("eintritt") is not None and nutzlast(p, heute + 3 * TAG).get("eintritt") is None,
           f"{N5['fehlt']}")
        c5.close()
        t_stand = jetzt + 6 * 3600 + 5                                       # letzter Stand des Knotens in dieser Datenbank
        N7 = nutzlast(p, t_stand + 10_800)
        N6 = nutzlast(p, t_stand + 10_801)
        ok("Frische: genau drei Stunden (10.800 s) nach dem Abruf gilt der Stand des Knotens noch, eine Sekunde später der Ersatz aus der Tagesdatei",
           N7["quelle"] == "knoten" and N7["stand"] == t_stand and N6["quelle"] == "tagesdatei" and N6["geschaetzt"] and FRISCH_KNOTEN_S == 10_800,
           f"{N7['quelle']} / {N6['quelle']}")
        pm, cm = os.path.join(tmp, "nacht.db"), verbinden(os.path.join(tmp, "nacht.db"))
        t23 = heute + 23 * 3600 + 1800                                       # Stand von 23:30 UTC, gelesen um 00:30 des nächsten Tages
        with schreiben(cm):
            meta_setzen(cm, "stand", {"ts": t23, "quelle": "knoten", "voll_eth": 300.0, "teil_eth": 0.0, "konsol_eth": 0.0, "ende_ts": t23 + TAG,
                                      "kalender": [[heute, 100.0, 0.0], [heute + TAG, 150.0, 50.0]], "adressen": [], "hinweise": []})
        cm.close()
        Nn = nutzlast(pm, t23 + 3600)
        ok("Über Mitternacht: was im gespeicherten Kalender unter gestern stand, zählt beim Lesen unter heute -- die Summe bleibt",
           Nn["ok"] and Nn["kalender"] == [[heute + TAG, 250.0, 50.0]] and Nn["summe_eth"] == 300.0, f"{Nn.get('kalender')}")
        ok("Fehlt staking.db, sagt die Antwort das und erfindet nichts", (lambda n: not n["ok"] and "staking.db fehlt" in n["fehlt"][0]
                                                                         and n["kalender"] == [])(nutzlast(os.path.join(tmp, "gibtsnicht.db"), jetzt)))

        # ---- Große Abzieher und große Freigabe in der Antwort
        p8, c8 = frisch("gross.db")
        WG = _probe_welt(jetzt)
        Zg = "0x01" + "00" * 11 + "dd" * 20
        WG["schlange"]["data"] += [{"index": str(20_000 + i), "balance": str(2048 * GWEI), "status": "active_exiting",
                                    "validator": {"withdrawal_credentials": Zg, "effective_balance": str(2048 * GWEI), "slashed": False,
                                                  "exit_epoch": str(e0 + 225 + i * 8), "withdrawable_epoch": str(e0 + 225 + i * 8 + 256)}}
                                   for i in range(60)]                        # 122.880 ETH einer Adresse über gut zwei Tage
        lauf_einmal(c8, _probe_transport(WG, TD), jetzt, erzwungen=True)
        N8 = nutzlast(p8, jetzt)
        ok("Antwort: ein Abzieher mit 122.880 ETH wird mit Adresse und Zeitraum genannt; die große Freigabe umfasst genau die Tage ab 28.800 ETH",
           [a["adresse"] for a in N8["adressen"]] == ["0x" + "dd" * 20] and N8["adressen"][0]["eth"] == 122_880.0 and N8["gross"] is not None
           and all(k[1] + k[2] >= GROSS_TAG_ETH for k in N8["kalender"] if N8["gross"]["von_ts"] <= k[0] <= N8["gross"]["bis_ts"])
           and abs(N8["gross"]["eth"] - sum(k[1] + k[2] for k in N8["kalender"] if N8["gross"]["von_ts"] <= k[0] <= N8["gross"]["bis_ts"])) < 1e-6,
           f"{N8['gross']}")
        os.environ["HL_STAKING_DB"] = p8
        try:
            txt = bericht("/nirgends/hl_liq.db", mit_abruf=True, transport=_probe_transport(WG, TD), jetzt=jetzt + 700)
            txt_ohne = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=jetzt + 700)
        finally:
            del os.environ["HL_STAKING_DB"]
        ok("Bericht (Debug 145): ruft selbst ab und zeigt je Frage Status, Größe und Dauer; dann Stand, Kalender, Abzieher, Gegenseite, "
           "Abgleich, Rückblick, letzte Abrufe",
           all(s in txt for s in ("Abruf jetzt -- Beacon-Knoten", "Kopf der Kette", "HTTP 200", "Vollabzüge in der Schlange", "Tagesdatei",
                                  "Stand (Beacon-Knoten", "Angemeldet, noch nicht frei:", "Nicht mitgezählt: 96 ETH", "Kalender „frei ab“",
                                  "Größte Abzieher", "0x" + "dd" * 20, "122.880 ETH", "Nächste große Freigabe:", "Gegenseite: 900.000 ETH",
                                  "Abgleich:", "Rückblick aus der Tagesdatei: 40 Tage", "Letzte Abrufe:", "Nicht enthalten:"))
           and "VERALTET" not in txt
           and "Abruf jetzt" not in txt_ohne and "Stand (Beacon-Knoten" in txt_ohne, "")
        # ---- 23.102: eigene Tagesreihe aus dem Knoten; stehengebliebene Tagesdatei
        p9, c9 = frisch("reihe.db")
        R9 = lauf_einmal(c9, _probe_transport(_probe_welt(jetzt), TD), jetzt, erzwungen=True)
        S9 = R9["knoten"]["stand"]
        Z1 = tagesreihe_lesen(c9)
        W9b = _probe_welt(jetzt + 3600)                                      # eine Stunde später ist die Schlange gewachsen
        W9b["schlange"]["data"] += [{"index": "30000", "balance": str(2048 * GWEI), "status": "active_exiting",
                                     "validator": {"withdrawal_credentials": "0x01" + "00" * 11 + "ee" * 20, "effective_balance": str(2048 * GWEI),
                                                   "slashed": False, "exit_epoch": str(W9b["e0"] + 2000), "withdrawable_epoch": str(W9b["e0"] + 2256)}}]
        R9b = lauf_einmal(c9, _probe_transport(W9b, TD), jetzt + 3600, erzwungen=True)
        Z2 = tagesreihe_lesen(c9)
        R9c = lauf_einmal(c9, _probe_transport(W9b, TD, fehler={"/headers/head": OSError("Netz nicht erreichbar")}), jetzt + 7200, erzwungen=True)
        Z2f = tagesreihe_lesen(c9)
        W9d = _probe_welt(jetzt + TAG)
        R9d = lauf_einmal(c9, _probe_transport(W9d, TD), jetzt + TAG, erzwungen=True)
        Z3 = tagesreihe_lesen(c9)
        ok("Eigene Tagesreihe (23.102): je UTC-Tag hält das Modul den ersten Stand des Knotens fest -- Schlange ohne Sperrfrist und ohne "
           "Zusammenlegungen (7.378 ETH), Wartezeit bis zum letzten zugeteilten Austritt (1.400 Epochen = 6,22 Tage), Sperrfrist, "
           "Teilabzüge, „alles frei bis“; ein späterer Stand desselben Tages und ein misslungener Abruf ändern die Zeile nicht, der "
           "nächste Tag bekommt eine neue",
           R9["knoten"]["ok"] and len(Z1) == 1 and Z1[0]["tag"] == "2026-11-07" and Z1[0]["ts"] == S9["ts"] and Z1[0]["schlange_eth"] == 7378.0
           and S9["warte_eth"] == 7378.0 and S9["voll_eth"] == 7538.0 and Z1[0]["sperr_eth"] == 160.0 and Z1[0]["teil_eth"] == 1750.0
           and Z1[0]["konsol_eth"] == 96.0 and Z1[0]["frei_bis_ts"] == S9["ende_ts"]
           and abs(Z1[0]["schlange_tage"] - 1400 * EPOCHE_S / TAG) < 0.01 and abs(Z1[0]["schlange_tage"] - (S9["schlange_ende_ts"] - S9["ts"]) / TAG) < 1e-3
           and R9b["knoten"]["ok"] and R9b["knoten"]["stand"]["warte_eth"] == 9426.0 and Z2 == Z1 and not R9c["knoten"]["ok"] and Z2f == Z1
           and R9d["knoten"]["ok"] and len(Z3) == 2 and Z3[0] == Z1[0] and Z3[1]["tag"] == "2026-11-08" and Z3[1]["schlange_eth"] == 7378.0
           and tagesreihe_zeile({"ts": jetzt, "warte_eth": 0.0, "schlange_ende_ts": None})[3] == 0.0
           and tagesreihe_zeile({"ts": jetzt, "warte_eth": 5.0, "schlange_ende_ts": jetzt - 50})[3] == 0.0
           and tagesreihe_zeile({"ts": heute + 23 * 3600 + 1800, "warte_eth": 1.0})[0] == "2026-11-07"          # UTC-Tag, nicht Ortszeit
           and tagesreihe_zeile({"ts": heute + TAG, "warte_eth": 1.0})[0] == "2026-11-08",
           f"{Z1[0] if Z1 else None}; danach {len(Z3)} Tage")
        c9.close()
        p_alt9 = os.path.join(tmp, "alt_schema.db")                          # Datenbank von vor 23.102: ohne die neue Tabelle, nur gelesen
        c_alt9 = sqlite3.connect(p_alt9)
        for q_ in SCHEMA:
            if "st_tag_knoten" not in q_:
                c_alt9.execute(q_)
        c_alt9.commit(); c_alt9.close()
        c_les9 = lesen(p_alt9)
        leer9 = tagesreihe_lesen(c_les9)
        c_les9.close()
        p10, c10 = frisch("steht.db")                                        # Tagesdatei, deren letzter Tag 21 Tage zurückliegt
        lauf_einmal(c10, _probe_transport(_probe_welt(jetzt), _probe_tagesdatei(jetzt, letzter_vor=21)), jetzt, erzwungen=True)
        c10.close()
        N10 = nutzlast(p10, jetzt)
        os.environ["HL_STAKING_DB"] = p10
        try:
            txt10 = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=jetzt)
            os.environ["HL_STAKING_DB"] = p_alt9
            txt_alt9 = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=jetzt)
        finally:
            del os.environ["HL_STAKING_DB"]
        c_neu9 = verbinden(p_alt9)                                           # mit 23.102 geöffnet: die Tabelle entsteht, der nächste Stand zählt
        try:
            R_alt9 = lauf_einmal(c_neu9, _probe_transport(_probe_welt(jetzt), TD), jetzt, erzwungen=True)
            Z_alt9 = tagesreihe_lesen(c_neu9)
        except sqlite3.Error as x_:                                          # fehlte die Tabelle, bräche hier jeder Abruf ab -- als FEHL melden
            R_alt9, Z_alt9 = {"knoten": {"ok": False, "fehler": [str(x_)]}}, []
        c_neu9.close()
        # Takt: letzter Versuch gestern 23:30 UTC; heute 00:01:30 noch nichts, ab 00:02:00 einmal außer der Reihe, dann wieder stündlich
        p11, c11 = frisch("takt.db")
        t2330 = heute + 23 * 3600 + 1800
        m0 = heute + TAG
        lauf_einmal(c11, _probe_transport(_probe_welt(t2330), TD), t2330, erzwungen=True)

        def schritt(t_):
            return "knoten" in lauf_einmal(c11, _probe_transport(_probe_welt(t_), TD), t_)
        takt = [schritt(m0 + 90), schritt(m0 + 120), schritt(m0 + 180), schritt(m0 + 3600), schritt(m0 + 120 + 3540), schritt(m0 + 120 + 3540 + 60)]
        Z11 = tagesreihe_lesen(c11)
        kv_fehl = m0 + TAG + 120                                             # am Tag darauf misslingt der Abruf zu Tagesbeginn
        f1 = lauf_einmal(c11, _probe_transport(_probe_welt(kv_fehl), TD, fehler={"/headers/head": OSError("Netz nicht erreichbar")}), kv_fehl)
        f2 = "knoten" in lauf_einmal(c11, _probe_transport(_probe_welt(kv_fehl + 60), TD), kv_fehl + 60)
        f3 = "knoten" in lauf_einmal(c11, _probe_transport(_probe_welt(kv_fehl + 3540), TD), kv_fehl + 3540)
        Z11b = tagesreihe_lesen(c11)
        c11.close()
        ok("Takt zu Tagesbeginn (23.102): Der Dienst fragt den Knoten 2 Minuten nach Mitternacht UTC einmal außer der Reihe -- so liegt die "
           "erste Messung des Tages am Tagesbeginn (wie in der Tagesdatei); davor nicht, danach nicht jede Minute, sondern wieder im "
           "Stundentakt; misslingt dieser Abruf, trägt die Zeile des Tages die Uhrzeit des nächsten gelungenen Versuchs",
           TAGESBEGINN_NACH_S == 120 and takt == [False, True, False, False, True, False]
           and [z_["tag"] for z_ in Z11] == ["2026-11-07", "2026-11-08"] and Z11[1]["ts"] - m0 in range(100, 140)
           and "knoten" in f1 and not f1["knoten"]["ok"] and f2 is False and f3 is True
           and [z_["tag"] for z_ in Z11b] == ["2026-11-07", "2026-11-08", "2026-11-09"] and Z11b[2]["ts"] - (m0 + TAG) in range(3640, 3680),
           f"Takt {takt}; erste Messung am 08.11. {Z11[1]['ts'] - m0 if len(Z11) > 1 else None} s nach Mitternacht")

        # 23.106 (U259): Nachholen zu Tagesbeginn -- 0 = kein Versuch, 1 = Versuch misslungen, 2 = Versuch gelungen
        p12, c12 = frisch("nachholen.db")
        lauf_einmal(c12, _probe_transport(_probe_welt(t2330), TD), t2330, erzwungen=True)
        aus12 = {"/headers/head": OSError("Netz nicht erreichbar")}

        def schritt12(sek, fehl=False):
            t_ = m0 + sek
            r_ = lauf_einmal(c12, _probe_transport(_probe_welt(t_), TD, fehler=aus12 if fehl else None), t_)
            return 0 if "knoten" not in r_ else (2 if r_["knoten"]["ok"] else 1)
        folge12 = [schritt12(120, True),                                     # 00:02 erster Abruf des Tages: misslingt
                   schritt12(180, True),                                     # eine Minute später: noch nicht
                   schritt12(419, True),                                     # 4 min 59 s nach dem Versuch: noch nicht
                   schritt12(420, True),                                     # 5 min danach: zweiter Versuch, misslingt wieder
                   schritt12(720),                                           # weitere 5 min: gelingt -- die Zeile steht (00:12 UTC)
                   schritt12(1020),                                          # die Zeile ist da: kein Nachholen mehr
                   schritt12(720 + 3539),                                    # kurz vor dem Stundentakt: nichts
                   schritt12(720 + 3540)]                                    # Stundentakt
        Z12 = tagesreihe_lesen(c12)
        bis12 = TAGESWERT_BIS_S
        folge12b = [schritt12(TAG + 120, True),                              # am Tag darauf: Ausfall bis nach 03:00 UTC
                    schritt12(TAG + bis12 - 1, True),                        # 02:59:59: noch im Fenster, Versuch
                    schritt12(TAG + bis12 + 299, True),                      # 03:04:59: Fenster vorbei -- kein Nachholen mehr
                    schritt12(TAG + bis12 - 1 + 3540)]                       # Stundentakt: gelingt, die Zeile kommt zu spät am Tag
        Z12b = tagesreihe_lesen(c12)
        c12.close()
        ok("Nachholen zu Tagesbeginn (23.106, U259): Misslingt der erste Abruf des Tages, fragt der Dienst alle 5 Minuten erneut (nicht "
           "früher), bis die Zeile des Tages steht -- danach wieder nur im Stundentakt; nach 03:00 UTC holt er nicht mehr nach, und die "
           "späte Zeile gilt nicht als Tagesbeginn",
           NACHHOLEN_S == 300 and TAGESWERT_BIS_S == 10_800 and folge12 == [1, 0, 0, 1, 2, 0, 0, 2]
           and len(Z12) == 2 and Z12[1]["ts"] - m0 == 720 and tageswert_gueltig(Z12[1]["ts"])
           and folge12b == [1, 1, 0, 2] and len(Z12b) == 3 and Z12b[2]["ts"] - (m0 + TAG) == bis12 - 1 + 3540
           and not tageswert_gueltig(Z12b[2]["ts"]),
           f"{folge12} {folge12b}; Zeilen {[z_['ts'] - m0 for z_ in Z12b[1:]]}")
        p14, c14 = frisch("mitternacht.db")                                  # letzter Versuch eine Minute vor Mitternacht
        lauf_einmal(c14, _probe_transport(_probe_welt(m0 - 60), TD), m0 - 60, erzwungen=True)
        kurz14 = ["knoten" in lauf_einmal(c14, _probe_transport(_probe_welt(m0 + s_), TD), m0 + s_) for s_ in (60, 119, 120, 180)]
        Z14 = tagesreihe_lesen(c14)
        c14.close()
        ok("Takt zu Tagesbeginn nach einem Versuch kurz vor Mitternacht (23.106): Auch dann kommt der Abruf des neuen Tages 2 Minuten nach "
           "Mitternacht (nicht früher, nicht doppelt) -- das Nachholen wartet 5 Minuten seit dem letzten Versuch und ersetzt den Abruf zu "
           "Tagesbeginn nicht",
           kurz14 == [False, False, True, False] and len(Z14) == 2 and Z14[-1]["ts"] == m0 + 120
           and Z14[-1]["tag"] == time.strftime("%Y-%m-%d", time.gmtime(m0)), f"{kurz14}; Zeilen {[z_['tag'] for z_ in Z14]}")
        ok("Tagesbeginn (23.106, U259): Eine Messung zählt als Tagesbeginn von 00:00:00 bis 02:59:59 UTC, ab 03:00:00 nicht mehr; ohne "
           "Zeit nie. Angemeldet = Schlange + Sperrfrist + Teilabzüge, ohne Zusammenlegungen; fehlt ein Teil oder ist er negativ, gibt es "
           "keine Summe. Die Schwelle der Welle ist fest 57.600 ETH",
           tageswert_gueltig(m0) and tageswert_gueltig(m0 + 10_799) and not tageswert_gueltig(m0 + 10_800) and not tageswert_gueltig(m0 + TAG - 1)
           and not tageswert_gueltig(None) and WELLE_AB_ETH == 57_600
           and angemeldet_eth({"schlange_eth": 147_225, "sperr_eth": 65_951, "teil_eth": 35_047, "konsol_eth": 187_419}) == 248_223.0
           and angemeldet_eth({"schlange_eth": 0, "sperr_eth": 0, "teil_eth": 0}) == 0.0
           and angemeldet_eth({"schlange_eth": 1.0, "sperr_eth": None, "teil_eth": 2.0}) is None
           and angemeldet_eth({"schlange_eth": 1.0, "sperr_eth": 2.0}) is None and angemeldet_eth({"schlange_eth": -1, "sperr_eth": 2, "teil_eth": 3}) is None
           and angemeldet_eth(None) is None)

        def zeile13(tag_plus, sek, schlange, sperr, teil):
            ts_ = m0 + tag_plus * TAG + sek
            return {"tag": time.strftime("%Y-%m-%d", time.gmtime(ts_)), "ts": ts_, "schlange_eth": schlange, "schlange_tage": 1.5,
                    "sperr_eth": sperr, "teil_eth": teil, "konsol_eth": 5_000.0, "frei_bis_ts": ts_ + 3 * TAG}
        R13 = [zeile13(0, 34_380, 160_003.0, 65_135.0, 35_023.0),            # 09:33 UTC: zu spät am Tag (wie die erste echte Zeile)
               zeile13(1, 120, 147_225.0, 65_951.0, 35_047.0),               # 00:02 UTC: gültig, aber der Vortag nicht -- kein Zuwachs
               zeile13(2, 120, 190_000.0, 65_000.0, 60_000.0),               # gültig, Vortag gültig: +66.777 -> Tag mit Zuwachs
               zeile13(3, 600, 180_000.0, 64_000.0, 61_000.0),               # −10.000
               zeile13(5, 120, 200_000.0, 64_000.0, 61_000.0),               # Vortag fehlt: kein Zuwachs
               zeile13(6, 120, 257_599.0, 64_000.0, 61_000.0),               # +57.599: einen ETH unter der Schwelle
               zeile13(7, 120, 315_199.0, 64_000.0, 61_000.0)]               # +57.600: genau die Schwelle
        T13 = tagesreihe_zeilen(R13)
        R13k = [dict(z_) for z_ in R13]
        R13k[2]["sperr_eth"] = None                                          # ein Teil fehlt: keine Summe, kein Zuwachs -- auch am Folgetag nicht
        T13k = tagesreihe_zeilen(R13k)
        ok("Debug 145, Tagesreihe (23.106, U259): Kopf nennt die Zahl der Tage, die zu Tagesbeginn gemessen sind; je Zeile die Summe "
           "„angemeldet“, ihr Zuwachs gegen den Vortag nur, wenn beide Tage zu Tagesbeginn gemessen sind (nicht nach einer späten Zeile, "
           "nicht nach einem fehlenden Tag, nicht ohne Summe), „Tag mit Zuwachs“ genau ab 57.600 ETH, und der Vermerk an der späten Zeile",
           len(T13) == 9 and T13[0].endswith("7 Tag(e) von 2026-11-08 bis 2026-11-15 · davon zu Tagesbeginn gemessen (vor 03:00 UTC): 6")
           and "ab 57.600 ETH" in T13[1]
           and T13[2].endswith("angemeldet   260.161 ETH  ·  nach 03:00 UTC gemessen: zählt nicht als Tagesbeginn") and "09:33 UTC" in T13[2]
           and T13[3].endswith("angemeldet   248.223 ETH") and "00:02 UTC" in T13[3]
           and T13[4].endswith("angemeldet   315.000 ETH (gegen den Vortag +66.777, Tag mit Zuwachs)")
           and T13[5].endswith("angemeldet   305.000 ETH (gegen den Vortag −10.000)")
           and T13[6].endswith("angemeldet   325.000 ETH")
           and T13[7].endswith("angemeldet   382.599 ETH (gegen den Vortag +57.599)")
           and T13[8].endswith("angemeldet   440.199 ETH (gegen den Vortag +57.600, Tag mit Zuwachs)")
           and T13k[4].endswith("angemeldet —") and T13k[5].endswith("angemeldet   305.000 ETH")
           and len(tagesreihe_zeilen(R13, letzte=2)) == 4,
           " | ".join(z_[-70:] for z_ in T13[2:]))
        ok("Stehengebliebene Tagesdatei (wie am 15.11.2026: letzter Tag 21 Tage alt): Der Stand vom Knoten gilt weiter; der Bericht nennt "
           "das Alter, zeigt die Gegenseite als veraltet und gleicht nicht mehr ab; mit frischer Tagesdatei gleicht er ab und meldet "
           "nichts; die eigene Tagesreihe steht im Bericht; eine Datenbank ohne die neue Tabelle wird ohne Fehler gelesen und beim "
           "nächsten Öffnen ergänzt",
           N10["ok"] and N10["quelle"] == "knoten" and N10["tagesdatei"]["alt_tage"] == 21 and N10["tagesdatei"]["frisch"] is False
           and "eintritt" not in N10 and N["tagesdatei"]["alt_tage"] == 0
           and "seit 21 Tagen ohne neuen Eintrag" in txt10 and "Abgleich mit der Tagesdatei entfällt" in txt10 and "Abgleich: Vollabzüge" not in txt10
           and "VERALTET, im Cockpit nicht gezeigt" in txt10 and "andere Uhrzeit" not in txt10
           and "Eigene Tagesreihe vom Knoten (erste Messung je UTC-Tag, seit Paket 23.102): 1 Tag(e) von 2026-11-07 bis 2026-11-07" in txt10
           and "  2026-11-07 04:22 UTC  Schlange      7.378 ETH (6,2 T)" in txt10
           and "Abgleich: Vollabzüge in der Schlange laut Knoten 130.258 ETH · laut Tagesdatei 115.200 ETH" in txt
           and "Zum Vergleich der Zählweise: Knoten mit Sperrfrist 130.418 ETH, mit Sperrfrist und Zusammenlegungen 130.514 ETH." in txt
           and "ohne neuen Eintrag" not in txt and "Abgleich mit der Tagesdatei entfällt" not in txt
           and "Eigene Tagesreihe vom Knoten (erste Messung je UTC-Tag, seit Paket 23.102): 1 Tag(e)" in txt
           and leer9 == [] and "Eigene Tagesreihe vom Knoten (seit Paket 23.102): noch kein Tag" in txt_alt9 and "Traceback" not in txt_alt9
           and R_alt9["knoten"]["ok"] and len(Z_alt9) == 1 and Z_alt9[0]["schlange_eth"] == 7378.0,
           f"Alter {N10['tagesdatei']['alt_tage']} Tage; alte Datenbank: {len(leer9)} Zeilen")
        # Die letzten acht Tage der Tagesdatei, wie sie Debug 145 am 15.11.2026 zeigte (18. bis 25.10.2026)
        werte8 = [928_024, 809_405, 793_730, 671_770, 595_381, 546_056, 457_584, 364_665]
        t18 = calendar.timegm((2026, 10, 18, 0, 0, 0))

        def tage_aus(start_ts, werte):
            return [{"tag": time.strftime("%Y-%m-%d", time.gmtime(start_ts + i_ * TAG)), "ts": start_ts + i_ * TAG, "exit_eth": float(w_)}
                    for i_, w_ in enumerate(werte) if w_ is not None]
        Rb = rueckblick(tage_aus(t18, werte8))
        g0 = ABBAU_GRENZE_ETH
        Rb_grenze = rueckblick(tage_aus(t18, [200_000, 200_000 - g0, 200_000 - 2 * g0 - 1, 300_000, None, 100_000, 90_000]))
        t_pectra = calendar.timegm((2025, 5, 20, 0, 0, 0))                   # 20./21.05.2025 laut Quelle unsicher; 22.05. erster guter Tag
        Rb_frueh = rueckblick(tage_aus(t_pectra, [900_000, 500_000, 400_000, 300_000, 290_000]))
        Rb_alt = rueckblick(tage_aus(calendar.timegm((2024, 3, 1, 0, 0, 0)), [900_000, 700_000, 500_000]))
        ok("Rückblick, Abbau der Schlange (23.102): Abzüge allein verkleinern sie um höchstens 57.600 ETH am Tag; gezählt werden die Tage "
           "seit 22.05.2025, an denen die Tagesdatei um mehr als 60.480 ETH fiel -- in den letzten acht Tagen der Datei fünf von sieben, "
           "am stärksten 121.960 ETH am 21.10.2026; genau die Grenze zählt nicht, ein Tag nach einer Lücke nicht, ein Anstieg nicht, die "
           "unsichere Zeit und alles vor Pectra nicht",
           ABBAU_GRENZE_ETH == 60_480.0 and ABBAU_AB_TAG == "2025-05-22"
           and Rb["abbau_paare"] == 7 and Rb["abbau_zu_schnell"] == 5 and Rb["abbau_max_eth"] == 121_960.0 and Rb["abbau_max_tag"] == "2026-10-21"
           and Rb["n"] == 8 and Rb["spitze_eth"] == 928_024.0 and Rb["luecken"] == 0
           and Rb_grenze["abbau_paare"] == 4 and Rb_grenze["abbau_zu_schnell"] == 1 and Rb_grenze["abbau_max_eth"] == g0 + 1
           and Rb_grenze["abbau_max_tag"] == "2026-10-20" and Rb_grenze["luecken"] == 1
           and Rb_frueh["abbau_paare"] == 2 and Rb_frueh["abbau_zu_schnell"] == 1 and Rb_frueh["abbau_max_tag"] == "2025-05-23"
           and Rb_alt["abbau_paare"] == 0 and Rb_alt["abbau_zu_schnell"] == 0 and Rb_alt["abbau_max_eth"] is None,
           f"letzte acht Tage: {Rb['abbau_zu_schnell']} von {Rb['abbau_paare']}, größter Rückgang {Rb['abbau_max_eth']} am {Rb['abbau_max_tag']}")
        # Nachstellung des Stands auf dem Pi am 15.11.2026: Tagesdatei bis 25.10., Knoten frisch, Urteil mit Daten bis 25.10. gespeichert
        j15 = calendar.timegm((2026, 11, 15, 3, 23, 0))
        TD15 = [{"date": time.strftime("%Y-%m-%d", time.gmtime(t18 + i_ * TAG)), "validators": 819_745, "entry_queue": 1_309_352,
                 "entry_wait": 22.7, "exit_queue": w_, "exit_wait": round(w_ / DURCHSATZ_TAG, 1), "supply": 122_000_000,
                 "staked_amount": 36_000_000, "staked_percent": 29.5, "apr": 2.8} for i_, w_ in enumerate(werte8)]
        p15, c15 = frisch("pi.db")
        R15 = lauf_einmal(c15, _probe_transport(_probe_welt(j15), TD15), j15, erzwungen=True)
        with schreiben(c15):
            meta_setzen(c15, "studie_u255", {"ok": True, "urteil": "nicht belegt", "ts": j15 + 60, "daten": {"raster_bis": "2026-10-25"}})
        c15.close()
        N15 = nutzlast(p15, j15)
        os.environ["HL_STAKING_DB"] = p15
        try:
            txt15 = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=j15)
        finally:
            del os.environ["HL_STAKING_DB"]
        ok("Nachstellung des 15.11.2026 (Tagesdatei bis 25.10., Knoten frisch): Stand und Kalender kommen vom Knoten; die Dauer des "
           "Auszahlungslaufs bleibt (Zahl der Validatoren 21 Tage alt) und nennt ihren Tag; die Gegenseite fehlt in der Antwort; der Bericht "
           "nennt die Tage mit zu schnellem Abbau samt möglicher Erklärung und sagt beim Urteil der Prüfung, bis wohin es reicht; mit "
           "frischer Tagesdatei steht bei der Dauer kein Datum und beim Abbau keine Erklärung",
           R15["knoten"]["ok"] and R15["tagesdatei"]["ok"] and N15["ok"] and N15["quelle"] == "knoten" and N15["tagesdatei"]["alt_tage"] == 21
           and "eintritt" not in N15 and abs(N15["lauf_tage"] - 819_745 * 12 / 16 / TAG) < 1e-9 and N15["validatoren"] == 819_745
           and "binnen bis zu 7,1 Tagen (819.745 Validatoren laut Tagesdatei vom 2026-10-25, 16 je Block)" in txt15
           and "seit 21 Tagen ohne neuen Eintrag" in txt15 and "Abgleich mit der Tagesdatei entfällt" in txt15
           and ("  Seit 2025-05-22: An 5 von 7 Tagen fiel diese Schlange um mehr als 60.480 ETH (am stärksten um 121.960 ETH am 2026-10-21). "
                "Abzüge allein lassen höchstens 57.600 ETH am Tag zu. Mögliche Erklärung: Die Quelle zählt Zusammenlegungen mit") in txt15
           and "Prüfung der Kursfolge (U255): nicht belegt -- gerechnet am 15.11.2026 für die Wellen bis 25.10.2026; Einzelheiten in Debug 147." in txt15
           and "Eigene Tagesreihe vom Knoten (erste Messung je UTC-Tag, seit Paket 23.102): 1 Tag(e) von 2026-11-15 bis 2026-11-15" in txt15
           and "(800.000 Validatoren, 16 je Block)" in txt and "laut Tagesdatei vom" not in txt
           and "  Seit 2025-05-22: An 0 von 38 Tagen fiel diese Schlange um mehr als 60.480 ETH. Abzüge allein lassen höchstens 57.600 ETH am Tag zu." in txt
           and "Mögliche Erklärung" not in txt and "(800.000 Validatoren laut Tagesdatei vom 2026-10-17, 16 je Block)" in txt10
           and _tag_de("2026-10-25") == "25.10.2026" and _tag_de("x") is None and _tag_de(None) is None,
           f"Alter {N15['tagesdatei']['alt_tage']} Tage; Laufdauer {N15.get('lauf_tage'):.2f} Tage")
        # ---- 23.103 (U257): Zeile zur Sicherung in Debug 145
        o_b = os.path.join(tmp, "sich"); bd_b = os.path.join(o_b, "anderswo", "backup"); os.makedirs(bd_b)
        hdb = os.path.join(o_b, "hl_liq.db")
        hc = sqlite3.connect(hdb); hc.execute("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
        hc.execute("INSERT INTO meta VALUES ('backup_dir', ?)", (bd_b,)); hc.commit(); hc.close()
        S_leer = sicherung_stand(hdb)
        z_leer = sicherung_zeile(S_leer, jetzt)
        t_lauf = jetzt - 3 * 3600
        with open(os.path.join(bd_b, SICHERUNG_NAME), "wb") as f_:
            f_.write(b"x" * 1_234_000)
        os.utime(os.path.join(bd_b, SICHERUNG_NAME), (t_lauf, t_lauf))

        def bj(inhalt):
            with open(os.path.join(bd_b, "backup.json"), "w", encoding="utf-8") as f_:
                json.dump(inhalt, f_)
            return sicherung_zeile(sicherung_stand(hdb), jetzt)
        z_gut = bj({"ok": True, "ts": t_lauf, "size": 5, "staking_db": 1_234_000})
        z_grenze = (sicherung_zeile(sicherung_stand(hdb), t_lauf + SICHERUNG_ALT_S), sicherung_zeile(sicherung_stand(hdb), t_lauf + SICHERUNG_ALT_S + 1))
        z_fehler = bj({"ok": True, "ts": jetzt - 600, "size": 5, "staking_db_error": "database disk image is malformed"})
        z_ohne = bj({"ok": True, "ts": jetzt - 600, "size": 5, "makro_db": 7})
        z_lauf_fehl = bj({"ok": False, "ts": jetzt - 600, "error": "zu wenig Platz"})
        z_alt = sicherung_zeile(sicherung_stand(hdb), jetzt + 2 * TAG)
        os.remove(os.path.join(bd_b, "backup.json"))
        z_nur_datei = sicherung_zeile(sicherung_stand(hdb), jetzt)
        with open(os.path.join(bd_b, "backup.json"), "w", encoding="utf-8") as f_:
            f_.write("{kaputt")
        z_kaputt = sicherung_zeile(sicherung_stand(hdb), jetzt)
        os.remove(os.path.join(bd_b, SICHERUNG_NAME))
        z_fehler_ohne = bj({"ok": True, "ts": jetzt - 600, "staking_db_error": "unable to open database file"})
        hdb2 = os.path.join(o_b, "ohne_meta", "hl_liq.db"); os.makedirs(os.path.dirname(hdb2))
        sqlite3.connect(hdb2).close()                                        # Hauptdatenbank ohne Tabelle meta: Vorgabe „dbbackup“ daneben
        S_vor = sicherung_stand(hdb2); S_nix = sicherung_stand(os.path.join(o_b, "gibtsnicht", "hl_liq.db"))
        datum_lauf = _datum(t_lauf)
        ok("Sicherung (23.103, U257): Debug 145 sagt, ob staking.db im täglichen Backup des Recorders liegt -- Ordner aus der "
           "Hauptdatenbank (sonst die Vorgabe „dbbackup“ daneben), Kopie mit Datum und Größe; ohne Kopie steht das da; ein Fehler der "
           "Kopie steht mit seinem Wortlaut da und nennt die vorige; fehlt die Datei im letzten Lauf, ist der Lauf misslungen oder die "
           "Kopie älter als zwei Tage, steht es dabei; ohne lesbare backup.json zählt die Datei",
           S_leer["ordner"] == bd_b and S_leer["aus_meta"] and S_leer["kopie_ts"] is None
           and z_leer == (f"Sicherung: noch keine Kopie von staking.db im Backup-Ordner {bd_b}. Der Recorder nimmt die Datei seit Paket "
                          "23.103 beim täglichen Backup mit -- beim nächsten Lauf, oder sofort mit „Jetzt sichern“ im Abschnitt System.")
           and z_gut == f"Sicherung (täglich, mit dem Backup des Recorders): staking_backup.db vom {datum_lauf}, 1,2 MB, im Backup-Ordner {bd_b}."
           and z_fehler == (f"Sicherung: beim letzten Backup ({_datum(jetzt - 600)}) ist die Kopie von staking.db NICHT gelungen: database disk "
                            f"image is malformed -- es bleibt die vorige: staking_backup.db vom {datum_lauf}, 1,2 MB, im Backup-Ordner {bd_b}.")
           and z_ohne == z_gut + f" Im letzten Backup ({_datum(jetzt - 600)}) war staking.db nicht dabei; diese Kopie stammt von einem früheren Lauf."
           and z_lauf_fehl == z_gut + (f" Das letzte Backup ({_datum(jetzt - 600)}) ist insgesamt nicht gelungen; diese Kopie stammt von einem "
                                       "früheren Lauf.")
           and z_alt.endswith(" Sie ist älter als 2 Tage -- das Backup läuft sonst täglich.") and "älter als" not in z_gut
           and z_grenze[0] == z_gut and z_grenze[1] == z_gut + " Sie ist älter als 2 Tage -- das Backup läuft sonst täglich."
           and z_nur_datei == z_gut and z_kaputt == z_gut
           and z_fehler_ohne == (f"Sicherung: beim letzten Backup ({_datum(jetzt - 600)}) ist die Kopie von staking.db NICHT gelungen: unable to "
                                 f"open database file -- es gibt keine Kopie im Backup-Ordner {bd_b}.")
           and S_vor["ordner"] == os.path.join(o_b, "ohne_meta", "dbbackup") and not S_vor["aus_meta"]
           and S_nix["ordner"] == os.path.join(o_b, "gibtsnicht", "dbbackup") and not S_nix["aus_meta"]
           and sicherung_zeile(S_vor, jetzt).startswith("Sicherung: noch keine Kopie von staking.db im Backup-Ordner "
                                                        + os.path.join(o_b, "ohne_meta", "dbbackup") + " (Vorgabe neben der Datenbank). ")
           and SICHERUNG_NAME == "staking_backup.db",
           z_gut[:110])
        bj({"ok": True, "ts": t_lauf, "size": 5, "staking_db": 1_234_000})
        with open(os.path.join(bd_b, SICHERUNG_NAME), "wb") as f_:
            f_.write(b"x" * 1_234_000)
        os.utime(os.path.join(bd_b, SICHERUNG_NAME), (t_lauf, t_lauf))
        os.environ["HL_STAKING_DB"] = p8
        try:
            txt_s = bericht(hdb, mit_abruf=False, jetzt=jetzt + 700)
        finally:
            del os.environ["HL_STAKING_DB"]
        ok("Sicherung im Bericht: Debug 145 trägt die Zeile zur Sicherung (einmal), mit dem Ordner aus der Hauptdatenbank, die er als "
           "--db bekommt; ohne erreichbare Hauptdatenbank nennt er die Vorgabe und „noch keine Kopie“ -- kein Abbruch",
           txt_s.count("Sicherung") == 1
           and f"Sicherung (täglich, mit dem Backup des Recorders): staking_backup.db vom {datum_lauf}, 1,2 MB, im Backup-Ordner {bd_b}." in txt_s
           and txt.count("Sicherung") == 1 and "Sicherung: noch keine Kopie von staking.db im Backup-Ordner /nirgends/dbbackup (Vorgabe neben der Datenbank)." in txt
           and "Sicherung" not in stand_text(p8, jetzt + 700), txt_s[txt_s.find("Sicherung"):][:90])
        verboten = ("kaufen", "verkaufen", "kaufsignal", "verkaufssignal", "bullisch", "bärisch", "kursziel", "einstieg", "ausstieg", "empfehl",
                    "long gehen", "short gehen")
        with schreiben(c8):
            meta_setzen(c8, "studie_u255", {"ok": True, "urteil": "nicht belegt", "ts": 20772 * TAG + 8 * 3600})
        os.environ["HL_STAKING_DB"] = p8
        try:
            txt_pr = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=jetzt + 700)
        finally:
            del os.environ["HL_STAKING_DB"]
        ok("Wortprobe: der Bericht enthält kein Empfehlungswort, nennt sich selbst „kein Urteil“ und verweist auf die vorab festgelegte "
           "Prüfung der Kursfolge (Debug 147) -- erst „noch nicht gerechnet“, mit gespeichertem Urteil dessen Wortlaut und Datum",
           not [w for w in verboten if w in txt.lower()] and "kein Urteil" in txt and "vorab festgelegte Prüfung (Debug 147" in txt
           and "Prüfung der Kursfolge (U255): noch nicht gerechnet -- Debug 147" in txt
           and "Prüfung der Kursfolge (U255): nicht belegt -- gerechnet am 15.11.2026; Einzelheiten in Debug 147." in txt_pr,
           f"{[w for w in verboten if w in txt.lower()]}")
        c8.close()
        os.environ["HL_STAKING_DB"] = os.path.join(tmp, "f3.db")
        try:
            txt4 = bericht("/nirgends/hl_liq.db", mit_abruf=False, jetzt=jetzt)
        finally:
            del os.environ["HL_STAKING_DB"]
        ok("Bericht ohne Wert: „KEIN WERT“ mit den Gründen statt leerer Zahlen", "Stand: KEIN WERT" in txt4 and "hinter der Uhr" in txt4)
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)

    # ---- Umgebung und Abgrenzung
    alt = os.environ.get("HL_STAKING_KNOTEN")
    try:
        os.environ["HL_STAKING_KNOTEN"] = " https://eins.example/ , kein-url, http://zwei.example "
        liste = knoten_liste()
        os.environ["HL_STAKING_KNOTEN"] = ""
        leer = knoten_liste()
    finally:
        if alt is None:
            os.environ.pop("HL_STAKING_KNOTEN", None)
        else:
            os.environ["HL_STAKING_KNOTEN"] = alt
    ok("Knoten: Standard ist der öffentliche Knoten von PublicNode; HL_STAKING_KNOTEN setzt eigene (mehrere mit Komma, der Reihe nach)",
       liste == ("https://eins.example", "http://zwei.example") and leer == KNOTEN_STANDARD and KNOTEN_STANDARD[0].startswith("https://"))
    ok("Dienst: startet nicht für Selbsttest-Datenbanken und nicht mit HL_STAKING=0; staking.db liegt neben der Hauptdatenbank",
       starten("/x/_selftest_1.db") is False and starte(":memory:") is None and pfad("/daten/hl_liq.db") == "/daten/staking.db")
    with open(os.path.abspath(__file__), encoding="utf-8") as fh:
        quelltext = fh.read()
    imp = set(re.findall(r"^\s*(?:import|from)\s+(hl_[a-z_0-9]+|version|update|install)\b", quelltext, re.M))
    ok("Abgrenzung: das Modul importiert kein Projektmodul (wirkt auf nichts anderes)", not imp, f"{sorted(imp)}")

    alles = all(b for _, b in pruef)
    print(f"Unstaking (U254): Selbsttest {'bestanden' if alles else 'NICHT bestanden'} ({sum(1 for _, b in pruef if b)} von {len(pruef)})")
    return alles


def _wirft(f) -> bool:
    try:
        f()
    except AbrufFehler:
        return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser(description="Unstaking bei Ethereum (U254): wann wird gestaktes ETH frei?")
    ap.add_argument("--db", default="hl_liq.db")
    ap.add_argument("--stand", action="store_true", help="Bericht für Debug 145 (ruft selbst ab, wenn der letzte Abruf älter als 10 min ist)")
    ap.add_argument("--ohne-abruf", action="store_true", help="nur den gespeicherten Stand zeigen")
    ap.add_argument("--selbsttest", action="store_true")
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.stand:
        if not a.ohne_abruf:
            print(f"Abruf läuft (Beacon-Knoten höchstens {int(GESAMT_MAX_S)} s, Tagesdatei höchstens {int(TAGESDATEI_MAX_S)} s) …\n", flush=True)
        print(bericht(a.db, mit_abruf=not a.ohne_abruf))
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
